
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_multi_retuprobe_v61.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <filter_64ty>:
       0:      	pushq	%rax
       1:      	movl	0x4(%rdi), %ecx
       4:      	xorl	%eax, %eax
       6:      	cmpq	$0x20, %rcx
       a:      	ja	0x45 <filter_64ty+0x45>
       c:      	movl	$0x101e, %edx           # imm = 0x101E
      11:      	btq	%rcx, %rdx
      15:      	jae	0x1e <filter_64ty+0x1e>
      17:      	callq	0x140 <filter_64ty_selector_val>
      1c:      	popq	%rcx
      1d:      	retq
      1e:      	movl	$0xc00, %edx            # imm = 0xC00
      23:      	btq	%rcx, %rdx
      27:      	jb	0x40 <filter_64ty+0x40>
      29:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
      33:      	btq	%rcx, %rdx
      37:      	jae	0x45 <filter_64ty+0x45>
      39:      	callq	0x400 <filter_64ty_range>
      3e:      	popq	%rcx
      3f:      	retq
      40:      	callq	0x380 <filter_64ty_map>
      45:      	popq	%rcx
      46:      	retq
      47:      	nopw	(%rax,%rax)

0000000000000050 <filter_32ty>:
      50:      	pushq	%rax
      51:      	movl	0x4(%rdi), %ecx
      54:      	xorl	%eax, %eax
      56:      	cmpq	$0x20, %rcx
      5a:      	ja	0x95 <filter_32ty+0x45>
      5c:      	movl	$0x101e, %edx           # imm = 0x101E
      61:      	btq	%rcx, %rdx
      65:      	jae	0x6e <filter_32ty+0x1e>
      67:      	callq	0x5e0 <filter_32ty_selector_val>
      6c:      	popq	%rcx
      6d:      	retq
      6e:      	movl	$0xc00, %edx            # imm = 0xC00
      73:      	btq	%rcx, %rdx
      77:      	jb	0x90 <filter_32ty+0x40>
      79:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
      83:      	btq	%rcx, %rdx
      87:      	jae	0x95 <filter_32ty+0x45>
      89:      	callq	0x890 <filter_32ty_range>
      8e:      	popq	%rcx
      8f:      	retq
      90:      	callq	0x800 <filter_32ty_map>
      95:      	popq	%rcx
      96:      	retq
      97:      	nopw	(%rax,%rax)

00000000000000a0 <filter_16ty>:
      a0:      	pushq	%rax
      a1:      	movl	0x4(%rdi), %ecx
      a4:      	xorl	%eax, %eax
      a6:      	cmpq	$0x20, %rcx
      aa:      	ja	0xe5 <filter_16ty+0x45>
      ac:      	movl	$0x101e, %edx           # imm = 0x101E
      b1:      	btq	%rcx, %rdx
      b5:      	jae	0xbe <filter_16ty+0x1e>
      b7:      	callq	0xa50 <filter_16ty_selector_val>
      bc:      	popq	%rcx
      bd:      	retq
      be:      	movl	$0xc00, %edx            # imm = 0xC00
      c3:      	btq	%rcx, %rdx
      c7:      	jb	0xe0 <filter_16ty+0x40>
      c9:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
      d3:      	btq	%rcx, %rdx
      d7:      	jae	0xe5 <filter_16ty+0x45>
      d9:      	callq	0xd00 <filter_16ty_range>
      de:      	popq	%rcx
      df:      	retq
      e0:      	callq	0xc70 <filter_16ty_map>
      e5:      	popq	%rcx
      e6:      	retq
      e7:      	nopw	(%rax,%rax)

00000000000000f0 <filter_8ty>:
      f0:      	pushq	%rax
      f1:      	movl	0x4(%rdi), %ecx
      f4:      	xorl	%eax, %eax
      f6:      	cmpq	$0x20, %rcx
      fa:      	ja	0x135 <filter_8ty+0x45>
      fc:      	movl	$0x101e, %edx           # imm = 0x101E
     101:      	btq	%rcx, %rdx
     105:      	jae	0x10e <filter_8ty+0x1e>
     107:      	callq	0xec0 <filter_8ty_selector_val>
     10c:      	popq	%rcx
     10d:      	retq
     10e:      	movl	$0xc00, %edx            # imm = 0xC00
     113:      	btq	%rcx, %rdx
     117:      	jb	0x130 <filter_8ty+0x40>
     119:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     123:      	btq	%rcx, %rdx
     127:      	jae	0x135 <filter_8ty+0x45>
     129:      	callq	0x1170 <filter_8ty_range>
     12e:      	popq	%rcx
     12f:      	retq
     130:      	callq	0x10e0 <filter_8ty_map>
     135:      	popq	%rcx
     136:      	retq
     137:      	nopw	(%rax,%rax)

0000000000000140 <filter_64ty_selector_val>:
     140:      	movl	0x4(%rdi), %ecx
     143:      	movl	$0x1, %eax
     148:      	cmpq	$0x25, %rcx
     14c:      	ja	0x1c4 <filter_64ty_selector_val+0x84>
     14e:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     158:      	btq	%rcx, %rdx
     15c:      	jae	0x15f <filter_64ty_selector_val+0x1f>
     15e:      	retq
     15f:      	movl	$0x18, %edx
     164:      	btq	%rcx, %rdx
     168:      	jae	0x180 <filter_64ty_selector_val+0x40>
     16a:      	movq	(%rsi), %rdx
     16d:      	cmpq	0x10(%rdi), %rdx
     171:      	jne	0x2a2 <filter_64ty_selector_val+0x162>
     177:      	xorl	%eax, %eax
     179:      	cmpl	$0x3, %ecx
     17c:      	sete	%al
     17f:      	retq
     180:      	cmpq	$0xc, %rcx
     184:      	jne	0x1c4 <filter_64ty_selector_val+0x84>
     186:      	movq	(%rsi), %rcx
     189:      	testq	%rcx, 0x10(%rdi)
     18d:      	jne	0x15e <filter_64ty_selector_val+0x1e>
     18f:      	movl	0x8(%rdi), %edx
     192:      	cmpl	$0x11, %edx
     195:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     19b:      	testq	%rcx, 0x18(%rdi)
     19f:      	jne	0x15e <filter_64ty_selector_val+0x1e>
     1a1:      	cmpl	$0x19, %edx
     1a4:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     1aa:      	testq	%rcx, 0x20(%rdi)
     1ae:      	jne	0x15e <filter_64ty_selector_val+0x1e>
     1b0:      	cmpl	$0x21, %edx
     1b3:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     1b9:      	testq	%rcx, 0x28(%rdi)
     1bd:      	jne	0x15e <filter_64ty_selector_val+0x1e>
     1bf:      	jmp	0x36f <filter_64ty_selector_val+0x22f>
     1c4:      	cmpl	$0x1, %ecx
     1c7:      	je	0x23a <filter_64ty_selector_val+0xfa>
     1c9:      	cmpl	$0x2, %ecx
     1cc:      	jne	0x36f <filter_64ty_selector_val+0x22f>
     1d2:      	movl	0xc(%rdi), %ecx
     1d5:      	cmpl	$0xc, %ecx
     1d8:      	ja	0x332 <filter_64ty_selector_val+0x1f2>
     1de:      	movl	$0x1402, %edx           # imm = 0x1402
     1e3:      	btl	%ecx, %edx
     1e6:      	jae	0x332 <filter_64ty_selector_val+0x1f2>
     1ec:      	movq	(%rsi), %rcx
     1ef:      	cmpq	0x10(%rdi), %rcx
     1f3:      	jl	0x15e <filter_64ty_selector_val+0x1e>
     1f9:      	movl	0x8(%rdi), %edx
     1fc:      	cmpl	$0x11, %edx
     1ff:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     205:      	cmpq	0x18(%rdi), %rcx
     209:      	jl	0x15e <filter_64ty_selector_val+0x1e>
     20f:      	cmpl	$0x19, %edx
     212:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     218:      	cmpq	0x20(%rdi), %rcx
     21c:      	jl	0x15e <filter_64ty_selector_val+0x1e>
     222:      	cmpl	$0x21, %edx
     225:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     22b:      	cmpq	0x28(%rdi), %rcx
     22f:      	jl	0x15e <filter_64ty_selector_val+0x1e>
     235:      	jmp	0x36f <filter_64ty_selector_val+0x22f>
     23a:      	movl	0xc(%rdi), %ecx
     23d:      	cmpl	$0xc, %ecx
     240:      	ja	0x2f3 <filter_64ty_selector_val+0x1b3>
     246:      	movl	$0x1402, %edx           # imm = 0x1402
     24b:      	btl	%ecx, %edx
     24e:      	jae	0x2f3 <filter_64ty_selector_val+0x1b3>
     254:      	movq	(%rsi), %rcx
     257:      	cmpq	0x10(%rdi), %rcx
     25b:      	jg	0x15e <filter_64ty_selector_val+0x1e>
     261:      	movl	0x8(%rdi), %edx
     264:      	cmpl	$0x11, %edx
     267:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     26d:      	cmpq	0x18(%rdi), %rcx
     271:      	jg	0x15e <filter_64ty_selector_val+0x1e>
     277:      	cmpl	$0x19, %edx
     27a:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     280:      	cmpq	0x20(%rdi), %rcx
     284:      	jg	0x15e <filter_64ty_selector_val+0x1e>
     28a:      	cmpl	$0x21, %edx
     28d:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     293:      	cmpq	0x28(%rdi), %rcx
     297:      	jg	0x15e <filter_64ty_selector_val+0x1e>
     29d:      	jmp	0x36f <filter_64ty_selector_val+0x22f>
     2a2:      	movl	0x8(%rdi), %esi
     2a5:      	cmpl	$0x11, %esi
     2a8:      	jb	0x2d2 <filter_64ty_selector_val+0x192>
     2aa:      	cmpq	0x18(%rdi), %rdx
     2ae:      	je	0x177 <filter_64ty_selector_val+0x37>
     2b4:      	cmpl	$0x19, %esi
     2b7:      	jb	0x2d2 <filter_64ty_selector_val+0x192>
     2b9:      	cmpq	0x20(%rdi), %rdx
     2bd:      	je	0x177 <filter_64ty_selector_val+0x37>
     2c3:      	cmpl	$0x21, %esi
     2c6:      	jb	0x2d2 <filter_64ty_selector_val+0x192>
     2c8:      	cmpq	0x28(%rdi), %rdx
     2cc:      	je	0x177 <filter_64ty_selector_val+0x37>
     2d2:      	cmpl	$0x25, %ecx
     2d5:      	ja	0x36f <filter_64ty_selector_val+0x22f>
     2db:      	movl	%ecx, %ecx
     2dd:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     2e7:      	btq	%rcx, %rdx
     2eb:      	jb	0x15e <filter_64ty_selector_val+0x1e>
     2f1:      	jmp	0x36f <filter_64ty_selector_val+0x22f>
     2f3:      	movq	(%rsi), %rcx
     2f6:      	cmpq	0x10(%rdi), %rcx
     2fa:      	ja	0x15e <filter_64ty_selector_val+0x1e>
     300:      	movl	0x8(%rdi), %edx
     303:      	cmpl	$0x11, %edx
     306:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     308:      	cmpq	0x18(%rdi), %rcx
     30c:      	ja	0x15e <filter_64ty_selector_val+0x1e>
     312:      	cmpl	$0x19, %edx
     315:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     317:      	cmpq	0x20(%rdi), %rcx
     31b:      	ja	0x15e <filter_64ty_selector_val+0x1e>
     321:      	cmpl	$0x21, %edx
     324:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     326:      	cmpq	0x28(%rdi), %rcx
     32a:      	ja	0x15e <filter_64ty_selector_val+0x1e>
     330:      	jmp	0x36f <filter_64ty_selector_val+0x22f>
     332:      	movq	(%rsi), %rcx
     335:      	cmpq	0x10(%rdi), %rcx
     339:      	jb	0x15e <filter_64ty_selector_val+0x1e>
     33f:      	movl	0x8(%rdi), %edx
     342:      	cmpl	$0x11, %edx
     345:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     347:      	cmpq	0x18(%rdi), %rcx
     34b:      	jb	0x15e <filter_64ty_selector_val+0x1e>
     351:      	cmpl	$0x19, %edx
     354:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     356:      	cmpq	0x20(%rdi), %rcx
     35a:      	jb	0x15e <filter_64ty_selector_val+0x1e>
     360:      	cmpl	$0x21, %edx
     363:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     365:      	cmpq	0x28(%rdi), %rcx
     369:      	jb	0x15e <filter_64ty_selector_val+0x1e>
     36f:      	xorl	%eax, %eax
     371:      	retq
     372:      	nopw	%cs:(%rax,%rax)

0000000000000380 <filter_64ty_map>:
     380:      	pushq	%r14
     382:      	pushq	%rbx
     383:      	subq	$0x18, %rsp
     387:      	movq	%rsi, %r14
     38a:      	movq	%rdi, %rbx
     38d:      	movzbl	0x10(%rdi), %eax
     391:      	movl	%eax, 0xc(%rsp)
     395:      	movq	(%rip), %rdi            # 0x39c <filter_64ty_map+0x1c>
     39c:      	leaq	0xc(%rsp), %rsi
     3a1:      	movl	$0x1, %eax
     3a6:      	callq	*%rax
     3a8:      	testq	%rax, %rax
     3ab:      	je	0x3d9 <filter_64ty_map+0x59>
     3ad:      	movq	%rax, %rdi
     3b0:      	movq	(%r14), %rax
     3b3:      	movq	%rax, 0x10(%rsp)
     3b8:      	leaq	0x10(%rsp), %rsi
     3bd:      	movl	$0x1, %eax
     3c2:      	callq	*%rax
     3c4:      	movl	0x4(%rbx), %ecx
     3c7:      	cmpl	$0xb, %ecx
     3ca:      	je	0x3e3 <filter_64ty_map+0x63>
     3cc:      	cmpl	$0xa, %ecx
     3cf:      	jne	0x3eb <filter_64ty_map+0x6b>
     3d1:      	testq	%rax, %rax
     3d4:      	setne	%al
     3d7:      	jmp	0x3ed <filter_64ty_map+0x6d>
     3d9:      	xorl	%eax, %eax
     3db:      	addq	$0x18, %rsp
     3df:      	popq	%rbx
     3e0:      	popq	%r14
     3e2:      	retq
     3e3:      	testq	%rax, %rax
     3e6:      	sete	%al
     3e9:      	jmp	0x3ed <filter_64ty_map+0x6d>
     3eb:      	xorl	%eax, %eax
     3ed:      	movzbl	%al, %eax
     3f0:      	addq	$0x18, %rsp
     3f4:      	popq	%rbx
     3f5:      	popq	%r14
     3f7:      	retq
     3f8:      	nopl	(%rax,%rax)

0000000000000400 <filter_64ty_range>:
     400:      	movl	0x4(%rdi), %ecx
     403:      	movl	0xc(%rdi), %eax
     406:      	cmpl	$0xc, %eax
     409:      	ja	0x500 <filter_64ty_range+0x100>
     40f:      	movl	$0x1402, %edx           # imm = 0x1402
     414:      	btl	%eax, %edx
     417:      	jae	0x500 <filter_64ty_range+0x100>
     41d:      	movq	(%rsi), %rsi
     420:      	cmpl	$0x1f, %ecx
     423:      	jne	0x493 <filter_64ty_range+0x93>
     425:      	movl	$0x1, %eax
     42a:      	cmpq	%rsi, 0x10(%rdi)
     42e:      	jg	0x43a <filter_64ty_range+0x3a>
     430:      	cmpq	0x18(%rdi), %rsi
     434:      	jle	0x519 <filter_64ty_range+0x119>
     43a:      	movl	0x8(%rdi), %edx
     43d:      	cmpl	$0x19, %edx
     440:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     446:      	cmpq	%rsi, 0x20(%rdi)
     44a:      	jg	0x456 <filter_64ty_range+0x56>
     44c:      	cmpq	0x28(%rdi), %rsi
     450:      	jle	0x519 <filter_64ty_range+0x119>
     456:      	cmpl	$0x29, %edx
     459:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     45f:      	cmpq	%rsi, 0x30(%rdi)
     463:      	jg	0x46f <filter_64ty_range+0x6f>
     465:      	cmpq	0x38(%rdi), %rsi
     469:      	jle	0x519 <filter_64ty_range+0x119>
     46f:      	cmpl	$0x39, %edx
     472:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     478:      	xorl	%edx, %edx
     47a:      	cmpq	%rsi, 0x40(%rdi)
     47e:      	jg	0x5c9 <filter_64ty_range+0x1c9>
     484:      	cmpq	0x48(%rdi), %rsi
     488:      	jle	0x519 <filter_64ty_range+0x119>
     48e:      	jmp	0x5c9 <filter_64ty_range+0x1c9>
     493:      	movl	0x8(%rdi), %eax
     496:      	cmpq	%rsi, 0x10(%rdi)
     49a:      	setle	%r8b
     49e:      	cmpq	0x18(%rdi), %rsi
     4a2:      	setle	%dl
     4a5:      	andb	%r8b, %dl
     4a8:      	cmpl	$0x19, %eax
     4ab:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     4b1:      	cmpq	%rsi, 0x20(%rdi)
     4b5:      	setle	%r8b
     4b9:      	cmpq	0x28(%rdi), %rsi
     4bd:      	setle	%r9b
     4c1:      	andb	%r8b, %r9b
     4c4:      	orb	%r9b, %dl
     4c7:      	cmpl	$0x29, %eax
     4ca:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     4d0:      	cmpq	%rsi, 0x30(%rdi)
     4d4:      	setle	%r8b
     4d8:      	cmpq	0x38(%rdi), %rsi
     4dc:      	setle	%r9b
     4e0:      	andb	%r8b, %r9b
     4e3:      	orb	%r9b, %dl
     4e6:      	cmpl	$0x39, %eax
     4e9:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     4ef:      	cmpq	%rsi, 0x40(%rdi)
     4f3:      	setle	%al
     4f6:      	cmpq	0x48(%rdi), %rsi
     4fa:      	setle	%sil
     4fe:      	jmp	0x57d <filter_64ty_range+0x17d>
     500:      	movq	(%rsi), %rsi
     503:      	cmpl	$0x1f, %ecx
     506:      	jne	0x51a <filter_64ty_range+0x11a>
     508:      	movl	$0x1, %eax
     50d:      	cmpq	%rsi, 0x10(%rdi)
     511:      	ja	0x585 <filter_64ty_range+0x185>
     513:      	cmpq	0x18(%rdi), %rsi
     517:      	ja	0x585 <filter_64ty_range+0x185>
     519:      	retq
     51a:      	movl	0x8(%rdi), %eax
     51d:      	cmpq	%rsi, 0x10(%rdi)
     521:      	setbe	%r8b
     525:      	cmpq	0x18(%rdi), %rsi
     529:      	setbe	%dl
     52c:      	andb	%r8b, %dl
     52f:      	cmpl	$0x19, %eax
     532:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     538:      	cmpq	%rsi, 0x20(%rdi)
     53c:      	setbe	%r8b
     540:      	cmpq	0x28(%rdi), %rsi
     544:      	setbe	%r9b
     548:      	andb	%r8b, %r9b
     54b:      	orb	%r9b, %dl
     54e:      	cmpl	$0x29, %eax
     551:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     553:      	cmpq	%rsi, 0x30(%rdi)
     557:      	setbe	%r8b
     55b:      	cmpq	0x38(%rdi), %rsi
     55f:      	setbe	%r9b
     563:      	andb	%r8b, %r9b
     566:      	orb	%r9b, %dl
     569:      	cmpl	$0x39, %eax
     56c:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     56e:      	cmpq	%rsi, 0x40(%rdi)
     572:      	setbe	%al
     575:      	cmpq	0x48(%rdi), %rsi
     579:      	setbe	%sil
     57d:      	andb	%al, %sil
     580:      	orb	%sil, %dl
     583:      	jmp	0x5c9 <filter_64ty_range+0x1c9>
     585:      	movl	0x8(%rdi), %edx
     588:      	cmpl	$0x19, %edx
     58b:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     58d:      	cmpq	%rsi, 0x20(%rdi)
     591:      	ja	0x599 <filter_64ty_range+0x199>
     593:      	cmpq	0x28(%rdi), %rsi
     597:      	jbe	0x519 <filter_64ty_range+0x119>
     599:      	cmpl	$0x29, %edx
     59c:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     59e:      	cmpq	%rsi, 0x30(%rdi)
     5a2:      	ja	0x5ae <filter_64ty_range+0x1ae>
     5a4:      	cmpq	0x38(%rdi), %rsi
     5a8:      	jbe	0x519 <filter_64ty_range+0x119>
     5ae:      	cmpl	$0x39, %edx
     5b1:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     5b3:      	xorl	%edx, %edx
     5b5:      	cmpq	%rsi, 0x40(%rdi)
     5b9:      	ja	0x5c9 <filter_64ty_range+0x1c9>
     5bb:      	cmpq	0x48(%rdi), %rsi
     5bf:      	jbe	0x519 <filter_64ty_range+0x119>
     5c5:      	jmp	0x5c9 <filter_64ty_range+0x1c9>
     5c7:      	xorl	%edx, %edx
     5c9:      	cmpl	$0x20, %ecx
     5cc:      	sete	%al
     5cf:      	xorb	$0x1, %dl
     5d2:      	andb	%al, %dl
     5d4:      	movzbl	%dl, %eax
     5d7:      	retq
     5d8:      	nopl	(%rax,%rax)

00000000000005e0 <filter_32ty_selector_val>:
     5e0:      	movl	0x4(%rdi), %ecx
     5e3:      	movl	$0x1, %eax
     5e8:      	cmpq	$0x25, %rcx
     5ec:      	ja	0x65d <filter_32ty_selector_val+0x7d>
     5ee:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     5f8:      	btq	%rcx, %rdx
     5fc:      	jae	0x5ff <filter_32ty_selector_val+0x1f>
     5fe:      	retq
     5ff:      	movl	$0x18, %edx
     604:      	btq	%rcx, %rdx
     608:      	jae	0x61e <filter_32ty_selector_val+0x3e>
     60a:      	movl	(%rsi), %edx
     60c:      	cmpl	0x10(%rdi), %edx
     60f:      	jne	0x731 <filter_32ty_selector_val+0x151>
     615:      	xorl	%eax, %eax
     617:      	cmpl	$0x3, %ecx
     61a:      	sete	%al
     61d:      	retq
     61e:      	cmpq	$0xc, %rcx
     622:      	jne	0x65d <filter_32ty_selector_val+0x7d>
     624:      	movl	(%rsi), %ecx
     626:      	testl	%ecx, 0x10(%rdi)
     629:      	jne	0x5fe <filter_32ty_selector_val+0x1e>
     62b:      	movl	0x8(%rdi), %edx
     62e:      	cmpl	$0xd, %edx
     631:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     637:      	testl	%ecx, 0x14(%rdi)
     63a:      	jne	0x5fe <filter_32ty_selector_val+0x1e>
     63c:      	cmpl	$0x11, %edx
     63f:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     645:      	testl	%ecx, 0x18(%rdi)
     648:      	jne	0x5fe <filter_32ty_selector_val+0x1e>
     64a:      	cmpl	$0x15, %edx
     64d:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     653:      	testl	%ecx, 0x1c(%rdi)
     656:      	jne	0x5fe <filter_32ty_selector_val+0x1e>
     658:      	jmp	0x7f1 <filter_32ty_selector_val+0x211>
     65d:      	cmpl	$0x1, %ecx
     660:      	je	0x6ce <filter_32ty_selector_val+0xee>
     662:      	cmpl	$0x2, %ecx
     665:      	jne	0x7f1 <filter_32ty_selector_val+0x211>
     66b:      	movl	0xc(%rdi), %ecx
     66e:      	cmpl	$0xc, %ecx
     671:      	ja	0x7b9 <filter_32ty_selector_val+0x1d9>
     677:      	movl	$0x1402, %edx           # imm = 0x1402
     67c:      	btl	%ecx, %edx
     67f:      	jae	0x7b9 <filter_32ty_selector_val+0x1d9>
     685:      	movl	(%rsi), %ecx
     687:      	cmpl	0x10(%rdi), %ecx
     68a:      	jl	0x5fe <filter_32ty_selector_val+0x1e>
     690:      	movl	0x8(%rdi), %edx
     693:      	cmpl	$0xd, %edx
     696:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     69c:      	cmpl	0x14(%rdi), %ecx
     69f:      	jl	0x5fe <filter_32ty_selector_val+0x1e>
     6a5:      	cmpl	$0x11, %edx
     6a8:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     6ae:      	cmpl	0x18(%rdi), %ecx
     6b1:      	jl	0x5fe <filter_32ty_selector_val+0x1e>
     6b7:      	cmpl	$0x15, %edx
     6ba:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     6c0:      	cmpl	0x1c(%rdi), %ecx
     6c3:      	jl	0x5fe <filter_32ty_selector_val+0x1e>
     6c9:      	jmp	0x7f1 <filter_32ty_selector_val+0x211>
     6ce:      	movl	0xc(%rdi), %ecx
     6d1:      	cmpl	$0xc, %ecx
     6d4:      	ja	0x77f <filter_32ty_selector_val+0x19f>
     6da:      	movl	$0x1402, %edx           # imm = 0x1402
     6df:      	btl	%ecx, %edx
     6e2:      	jae	0x77f <filter_32ty_selector_val+0x19f>
     6e8:      	movl	(%rsi), %ecx
     6ea:      	cmpl	0x10(%rdi), %ecx
     6ed:      	jg	0x5fe <filter_32ty_selector_val+0x1e>
     6f3:      	movl	0x8(%rdi), %edx
     6f6:      	cmpl	$0xd, %edx
     6f9:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     6ff:      	cmpl	0x14(%rdi), %ecx
     702:      	jg	0x5fe <filter_32ty_selector_val+0x1e>
     708:      	cmpl	$0x11, %edx
     70b:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     711:      	cmpl	0x18(%rdi), %ecx
     714:      	jg	0x5fe <filter_32ty_selector_val+0x1e>
     71a:      	cmpl	$0x15, %edx
     71d:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     723:      	cmpl	0x1c(%rdi), %ecx
     726:      	jg	0x5fe <filter_32ty_selector_val+0x1e>
     72c:      	jmp	0x7f1 <filter_32ty_selector_val+0x211>
     731:      	movl	0x8(%rdi), %esi
     734:      	cmpl	$0xd, %esi
     737:      	jb	0x75e <filter_32ty_selector_val+0x17e>
     739:      	cmpl	0x14(%rdi), %edx
     73c:      	je	0x615 <filter_32ty_selector_val+0x35>
     742:      	cmpl	$0x11, %esi
     745:      	jb	0x75e <filter_32ty_selector_val+0x17e>
     747:      	cmpl	0x18(%rdi), %edx
     74a:      	je	0x615 <filter_32ty_selector_val+0x35>
     750:      	cmpl	$0x15, %esi
     753:      	jb	0x75e <filter_32ty_selector_val+0x17e>
     755:      	cmpl	0x1c(%rdi), %edx
     758:      	je	0x615 <filter_32ty_selector_val+0x35>
     75e:      	cmpl	$0x25, %ecx
     761:      	ja	0x7f1 <filter_32ty_selector_val+0x211>
     767:      	movl	%ecx, %ecx
     769:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     773:      	btq	%rcx, %rdx
     777:      	jb	0x5fe <filter_32ty_selector_val+0x1e>
     77d:      	jmp	0x7f1 <filter_32ty_selector_val+0x211>
     77f:      	movl	(%rsi), %ecx
     781:      	cmpl	0x10(%rdi), %ecx
     784:      	ja	0x5fe <filter_32ty_selector_val+0x1e>
     78a:      	movl	0x8(%rdi), %edx
     78d:      	cmpl	$0xd, %edx
     790:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     792:      	cmpl	0x14(%rdi), %ecx
     795:      	ja	0x5fe <filter_32ty_selector_val+0x1e>
     79b:      	cmpl	$0x11, %edx
     79e:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     7a0:      	cmpl	0x18(%rdi), %ecx
     7a3:      	ja	0x5fe <filter_32ty_selector_val+0x1e>
     7a9:      	cmpl	$0x15, %edx
     7ac:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     7ae:      	cmpl	0x1c(%rdi), %ecx
     7b1:      	ja	0x5fe <filter_32ty_selector_val+0x1e>
     7b7:      	jmp	0x7f1 <filter_32ty_selector_val+0x211>
     7b9:      	movl	(%rsi), %ecx
     7bb:      	cmpl	0x10(%rdi), %ecx
     7be:      	jb	0x5fe <filter_32ty_selector_val+0x1e>
     7c4:      	movl	0x8(%rdi), %edx
     7c7:      	cmpl	$0xd, %edx
     7ca:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     7cc:      	cmpl	0x14(%rdi), %ecx
     7cf:      	jb	0x5fe <filter_32ty_selector_val+0x1e>
     7d5:      	cmpl	$0x11, %edx
     7d8:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     7da:      	cmpl	0x18(%rdi), %ecx
     7dd:      	jb	0x5fe <filter_32ty_selector_val+0x1e>
     7e3:      	cmpl	$0x15, %edx
     7e6:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     7e8:      	cmpl	0x1c(%rdi), %ecx
     7eb:      	jb	0x5fe <filter_32ty_selector_val+0x1e>
     7f1:      	xorl	%eax, %eax
     7f3:      	retq
     7f4:      	nopw	%cs:(%rax,%rax)

0000000000000800 <filter_32ty_map>:
     800:      	pushq	%r14
     802:      	pushq	%rbx
     803:      	subq	$0x18, %rsp
     807:      	movq	%rsi, %r14
     80a:      	movq	%rdi, %rbx
     80d:      	movzbl	0x10(%rdi), %eax
     811:      	movl	%eax, 0xc(%rsp)
     815:      	movq	(%rip), %rdi            # 0x81c <filter_32ty_map+0x1c>
     81c:      	leaq	0xc(%rsp), %rsi
     821:      	movl	$0x1, %eax
     826:      	callq	*%rax
     828:      	testq	%rax, %rax
     82b:      	je	0x860 <filter_32ty_map+0x60>
     82d:      	movq	%rax, %rdi
     830:      	movl	(%r14), %eax
     833:      	movq	%rax, 0x10(%rsp)
     838:      	leaq	0x10(%rsp), %rsi
     83d:      	movl	$0x1, %eax
     842:      	callq	*%rax
     844:      	movl	0x4(%rbx), %edx
     847:      	xorl	%ecx, %ecx
     849:      	cmpl	$0x1d, %edx
     84c:      	ja	0x87a <filter_32ty_map+0x7a>
     84e:      	movl	$0x30038400, %esi       # imm = 0x30038400
     853:      	btl	%edx, %esi
     856:      	jae	0x86a <filter_32ty_map+0x6a>
     858:      	testq	%rax, %rax
     85b:      	setne	%cl
     85e:      	jmp	0x87a <filter_32ty_map+0x7a>
     860:      	xorl	%eax, %eax
     862:      	addq	$0x18, %rsp
     866:      	popq	%rbx
     867:      	popq	%r14
     869:      	retq
     86a:      	movl	$0xc0800, %esi          # imm = 0xC0800
     86f:      	btl	%edx, %esi
     872:      	jae	0x87a <filter_32ty_map+0x7a>
     874:      	testq	%rax, %rax
     877:      	sete	%cl
     87a:      	movzbl	%cl, %eax
     87d:      	addq	$0x18, %rsp
     881:      	popq	%rbx
     882:      	popq	%r14
     884:      	retq
     885:      	nopw	%cs:(%rax,%rax)

0000000000000890 <filter_32ty_range>:
     890:      	movl	0x4(%rdi), %ecx
     893:      	movl	0xc(%rdi), %eax
     896:      	cmpl	$0xc, %eax
     899:      	ja	0x97f <filter_32ty_range+0xef>
     89f:      	movl	$0x1402, %edx           # imm = 0x1402
     8a4:      	btl	%eax, %edx
     8a7:      	jae	0x97f <filter_32ty_range+0xef>
     8ad:      	movl	(%rsi), %esi
     8af:      	cmpl	$0x1f, %ecx
     8b2:      	jne	0x91a <filter_32ty_range+0x8a>
     8b4:      	movl	$0x1, %eax
     8b9:      	cmpl	%esi, 0x10(%rdi)
     8bc:      	jg	0x8c7 <filter_32ty_range+0x37>
     8be:      	cmpl	0x14(%rdi), %esi
     8c1:      	jle	0x995 <filter_32ty_range+0x105>
     8c7:      	movl	0x8(%rdi), %edx
     8ca:      	cmpl	$0x11, %edx
     8cd:      	jb	0xa35 <filter_32ty_range+0x1a5>
     8d3:      	cmpl	%esi, 0x18(%rdi)
     8d6:      	jg	0x8e1 <filter_32ty_range+0x51>
     8d8:      	cmpl	0x1c(%rdi), %esi
     8db:      	jle	0x995 <filter_32ty_range+0x105>
     8e1:      	cmpl	$0x19, %edx
     8e4:      	jb	0xa35 <filter_32ty_range+0x1a5>
     8ea:      	cmpl	%esi, 0x20(%rdi)
     8ed:      	jg	0x8f8 <filter_32ty_range+0x68>
     8ef:      	cmpl	0x24(%rdi), %esi
     8f2:      	jle	0x995 <filter_32ty_range+0x105>
     8f8:      	cmpl	$0x21, %edx
     8fb:      	jb	0xa35 <filter_32ty_range+0x1a5>
     901:      	xorl	%edx, %edx
     903:      	cmpl	%esi, 0x28(%rdi)
     906:      	jg	0xa37 <filter_32ty_range+0x1a7>
     90c:      	cmpl	0x2c(%rdi), %esi
     90f:      	jle	0x995 <filter_32ty_range+0x105>
     915:      	jmp	0xa37 <filter_32ty_range+0x1a7>
     91a:      	movl	0x8(%rdi), %eax
     91d:      	cmpl	%esi, 0x10(%rdi)
     920:      	setle	%r8b
     924:      	cmpl	0x14(%rdi), %esi
     927:      	setle	%dl
     92a:      	andb	%r8b, %dl
     92d:      	cmpl	$0x11, %eax
     930:      	jb	0xa37 <filter_32ty_range+0x1a7>
     936:      	cmpl	%esi, 0x18(%rdi)
     939:      	setle	%r8b
     93d:      	cmpl	0x1c(%rdi), %esi
     940:      	setle	%r9b
     944:      	andb	%r8b, %r9b
     947:      	orb	%r9b, %dl
     94a:      	cmpl	$0x19, %eax
     94d:      	jb	0xa37 <filter_32ty_range+0x1a7>
     953:      	cmpl	%esi, 0x20(%rdi)
     956:      	setle	%r8b
     95a:      	cmpl	0x24(%rdi), %esi
     95d:      	setle	%r9b
     961:      	andb	%r8b, %r9b
     964:      	orb	%r9b, %dl
     967:      	cmpl	$0x21, %eax
     96a:      	jb	0xa37 <filter_32ty_range+0x1a7>
     970:      	cmpl	%esi, 0x28(%rdi)
     973:      	setle	%al
     976:      	cmpl	0x2c(%rdi), %esi
     979:      	setle	%sil
     97d:      	jmp	0x9f1 <filter_32ty_range+0x161>
     97f:      	movl	(%rsi), %esi
     981:      	cmpl	$0x1f, %ecx
     984:      	jne	0x996 <filter_32ty_range+0x106>
     986:      	movl	$0x1, %eax
     98b:      	cmpl	%esi, 0x10(%rdi)
     98e:      	ja	0x9f9 <filter_32ty_range+0x169>
     990:      	cmpl	0x14(%rdi), %esi
     993:      	ja	0x9f9 <filter_32ty_range+0x169>
     995:      	retq
     996:      	movl	0x8(%rdi), %eax
     999:      	cmpl	%esi, 0x10(%rdi)
     99c:      	setbe	%r8b
     9a0:      	cmpl	0x14(%rdi), %esi
     9a3:      	setbe	%dl
     9a6:      	andb	%r8b, %dl
     9a9:      	cmpl	$0x11, %eax
     9ac:      	jb	0xa37 <filter_32ty_range+0x1a7>
     9b2:      	cmpl	%esi, 0x18(%rdi)
     9b5:      	setbe	%r8b
     9b9:      	cmpl	0x1c(%rdi), %esi
     9bc:      	setbe	%r9b
     9c0:      	andb	%r8b, %r9b
     9c3:      	orb	%r9b, %dl
     9c6:      	cmpl	$0x19, %eax
     9c9:      	jb	0xa37 <filter_32ty_range+0x1a7>
     9cb:      	cmpl	%esi, 0x20(%rdi)
     9ce:      	setbe	%r8b
     9d2:      	cmpl	0x24(%rdi), %esi
     9d5:      	setbe	%r9b
     9d9:      	andb	%r8b, %r9b
     9dc:      	orb	%r9b, %dl
     9df:      	cmpl	$0x21, %eax
     9e2:      	jb	0xa37 <filter_32ty_range+0x1a7>
     9e4:      	cmpl	%esi, 0x28(%rdi)
     9e7:      	setbe	%al
     9ea:      	cmpl	0x2c(%rdi), %esi
     9ed:      	setbe	%sil
     9f1:      	andb	%al, %sil
     9f4:      	orb	%sil, %dl
     9f7:      	jmp	0xa37 <filter_32ty_range+0x1a7>
     9f9:      	movl	0x8(%rdi), %edx
     9fc:      	cmpl	$0x11, %edx
     9ff:      	jb	0xa35 <filter_32ty_range+0x1a5>
     a01:      	cmpl	%esi, 0x18(%rdi)
     a04:      	ja	0xa0b <filter_32ty_range+0x17b>
     a06:      	cmpl	0x1c(%rdi), %esi
     a09:      	jbe	0x995 <filter_32ty_range+0x105>
     a0b:      	cmpl	$0x19, %edx
     a0e:      	jb	0xa35 <filter_32ty_range+0x1a5>
     a10:      	cmpl	%esi, 0x20(%rdi)
     a13:      	ja	0xa1e <filter_32ty_range+0x18e>
     a15:      	cmpl	0x24(%rdi), %esi
     a18:      	jbe	0x995 <filter_32ty_range+0x105>
     a1e:      	cmpl	$0x21, %edx
     a21:      	jb	0xa35 <filter_32ty_range+0x1a5>
     a23:      	xorl	%edx, %edx
     a25:      	cmpl	%esi, 0x28(%rdi)
     a28:      	ja	0xa37 <filter_32ty_range+0x1a7>
     a2a:      	cmpl	0x2c(%rdi), %esi
     a2d:      	jbe	0x995 <filter_32ty_range+0x105>
     a33:      	jmp	0xa37 <filter_32ty_range+0x1a7>
     a35:      	xorl	%edx, %edx
     a37:      	cmpl	$0x20, %ecx
     a3a:      	sete	%al
     a3d:      	xorb	$0x1, %dl
     a40:      	andb	%al, %dl
     a42:      	movzbl	%dl, %eax
     a45:      	retq
     a46:      	nopw	%cs:(%rax,%rax)

0000000000000a50 <filter_16ty_selector_val>:
     a50:      	movl	0x4(%rdi), %ecx
     a53:      	movl	$0x1, %eax
     a58:      	cmpq	$0x25, %rcx
     a5c:      	ja	0xacf <filter_16ty_selector_val+0x7f>
     a5e:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     a68:      	btq	%rcx, %rdx
     a6c:      	jae	0xa6f <filter_16ty_selector_val+0x1f>
     a6e:      	retq
     a6f:      	movl	$0x18, %edx
     a74:      	btq	%rcx, %rdx
     a78:      	jae	0xa8f <filter_16ty_selector_val+0x3f>
     a7a:      	movzwl	(%rsi), %edx
     a7d:      	cmpl	%edx, 0x10(%rdi)
     a80:      	jne	0xba5 <filter_16ty_selector_val+0x155>
     a86:      	xorl	%eax, %eax
     a88:      	cmpl	$0x3, %ecx
     a8b:      	sete	%al
     a8e:      	retq
     a8f:      	cmpq	$0xc, %rcx
     a93:      	jne	0xacf <filter_16ty_selector_val+0x7f>
     a95:      	movzwl	(%rsi), %ecx
     a98:      	testl	%ecx, 0x10(%rdi)
     a9b:      	jne	0xa6e <filter_16ty_selector_val+0x1e>
     a9d:      	movl	0x8(%rdi), %edx
     aa0:      	cmpl	$0xd, %edx
     aa3:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     aa9:      	testl	%ecx, 0x14(%rdi)
     aac:      	jne	0xa6e <filter_16ty_selector_val+0x1e>
     aae:      	cmpl	$0x11, %edx
     ab1:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     ab7:      	testl	%ecx, 0x18(%rdi)
     aba:      	jne	0xa6e <filter_16ty_selector_val+0x1e>
     abc:      	cmpl	$0x15, %edx
     abf:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     ac5:      	testl	%ecx, 0x1c(%rdi)
     ac8:      	jne	0xa6e <filter_16ty_selector_val+0x1e>
     aca:      	jmp	0xc67 <filter_16ty_selector_val+0x217>
     acf:      	cmpl	$0x1, %ecx
     ad2:      	je	0xb41 <filter_16ty_selector_val+0xf1>
     ad4:      	cmpl	$0x2, %ecx
     ad7:      	jne	0xc67 <filter_16ty_selector_val+0x217>
     add:      	movl	0xc(%rdi), %ecx
     ae0:      	cmpl	$0xc, %ecx
     ae3:      	ja	0xc2e <filter_16ty_selector_val+0x1de>
     ae9:      	movl	$0x1402, %edx           # imm = 0x1402
     aee:      	btl	%ecx, %edx
     af1:      	jae	0xc2e <filter_16ty_selector_val+0x1de>
     af7:      	movswl	(%rsi), %ecx
     afa:      	cmpl	%ecx, 0x10(%rdi)
     afd:      	jg	0xa6e <filter_16ty_selector_val+0x1e>
     b03:      	movl	0x8(%rdi), %edx
     b06:      	cmpl	$0xd, %edx
     b09:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b0f:      	cmpl	%ecx, 0x14(%rdi)
     b12:      	jg	0xa6e <filter_16ty_selector_val+0x1e>
     b18:      	cmpl	$0x11, %edx
     b1b:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b21:      	cmpl	%ecx, 0x18(%rdi)
     b24:      	jg	0xa6e <filter_16ty_selector_val+0x1e>
     b2a:      	cmpl	$0x15, %edx
     b2d:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b33:      	cmpl	%ecx, 0x1c(%rdi)
     b36:      	jg	0xa6e <filter_16ty_selector_val+0x1e>
     b3c:      	jmp	0xc67 <filter_16ty_selector_val+0x217>
     b41:      	movl	0xc(%rdi), %ecx
     b44:      	cmpl	$0xc, %ecx
     b47:      	ja	0xbf3 <filter_16ty_selector_val+0x1a3>
     b4d:      	movl	$0x1402, %edx           # imm = 0x1402
     b52:      	btl	%ecx, %edx
     b55:      	jae	0xbf3 <filter_16ty_selector_val+0x1a3>
     b5b:      	movswl	(%rsi), %ecx
     b5e:      	cmpl	%ecx, 0x10(%rdi)
     b61:      	jl	0xa6e <filter_16ty_selector_val+0x1e>
     b67:      	movl	0x8(%rdi), %edx
     b6a:      	cmpl	$0xd, %edx
     b6d:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b73:      	cmpl	%ecx, 0x14(%rdi)
     b76:      	jl	0xa6e <filter_16ty_selector_val+0x1e>
     b7c:      	cmpl	$0x11, %edx
     b7f:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b85:      	cmpl	%ecx, 0x18(%rdi)
     b88:      	jl	0xa6e <filter_16ty_selector_val+0x1e>
     b8e:      	cmpl	$0x15, %edx
     b91:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b97:      	cmpl	%ecx, 0x1c(%rdi)
     b9a:      	jl	0xa6e <filter_16ty_selector_val+0x1e>
     ba0:      	jmp	0xc67 <filter_16ty_selector_val+0x217>
     ba5:      	movl	0x8(%rdi), %esi
     ba8:      	cmpl	$0xd, %esi
     bab:      	jb	0xbd2 <filter_16ty_selector_val+0x182>
     bad:      	cmpl	%edx, 0x14(%rdi)
     bb0:      	je	0xa86 <filter_16ty_selector_val+0x36>
     bb6:      	cmpl	$0x11, %esi
     bb9:      	jb	0xbd2 <filter_16ty_selector_val+0x182>
     bbb:      	cmpl	%edx, 0x18(%rdi)
     bbe:      	je	0xa86 <filter_16ty_selector_val+0x36>
     bc4:      	cmpl	$0x15, %esi
     bc7:      	jb	0xbd2 <filter_16ty_selector_val+0x182>
     bc9:      	cmpl	%edx, 0x1c(%rdi)
     bcc:      	je	0xa86 <filter_16ty_selector_val+0x36>
     bd2:      	cmpl	$0x25, %ecx
     bd5:      	ja	0xc67 <filter_16ty_selector_val+0x217>
     bdb:      	movl	%ecx, %ecx
     bdd:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     be7:      	btq	%rcx, %rdx
     beb:      	jb	0xa6e <filter_16ty_selector_val+0x1e>
     bf1:      	jmp	0xc67 <filter_16ty_selector_val+0x217>
     bf3:      	movzwl	(%rsi), %ecx
     bf6:      	cmpl	%ecx, 0x10(%rdi)
     bf9:      	jb	0xa6e <filter_16ty_selector_val+0x1e>
     bff:      	movl	0x8(%rdi), %edx
     c02:      	cmpl	$0xd, %edx
     c05:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c07:      	cmpl	%ecx, 0x14(%rdi)
     c0a:      	jb	0xa6e <filter_16ty_selector_val+0x1e>
     c10:      	cmpl	$0x11, %edx
     c13:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c15:      	cmpl	%ecx, 0x18(%rdi)
     c18:      	jb	0xa6e <filter_16ty_selector_val+0x1e>
     c1e:      	cmpl	$0x15, %edx
     c21:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c23:      	cmpl	%ecx, 0x1c(%rdi)
     c26:      	jb	0xa6e <filter_16ty_selector_val+0x1e>
     c2c:      	jmp	0xc67 <filter_16ty_selector_val+0x217>
     c2e:      	movzwl	(%rsi), %ecx
     c31:      	cmpl	%ecx, 0x10(%rdi)
     c34:      	ja	0xa6e <filter_16ty_selector_val+0x1e>
     c3a:      	movl	0x8(%rdi), %edx
     c3d:      	cmpl	$0xd, %edx
     c40:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c42:      	cmpl	%ecx, 0x14(%rdi)
     c45:      	ja	0xa6e <filter_16ty_selector_val+0x1e>
     c4b:      	cmpl	$0x11, %edx
     c4e:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c50:      	cmpl	%ecx, 0x18(%rdi)
     c53:      	ja	0xa6e <filter_16ty_selector_val+0x1e>
     c59:      	cmpl	$0x15, %edx
     c5c:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c5e:      	cmpl	%ecx, 0x1c(%rdi)
     c61:      	ja	0xa6e <filter_16ty_selector_val+0x1e>
     c67:      	xorl	%eax, %eax
     c69:      	retq
     c6a:      	nopw	(%rax,%rax)

0000000000000c70 <filter_16ty_map>:
     c70:      	pushq	%r14
     c72:      	pushq	%rbx
     c73:      	subq	$0x18, %rsp
     c77:      	movq	%rsi, %r14
     c7a:      	movq	%rdi, %rbx
     c7d:      	movzbl	0x10(%rdi), %eax
     c81:      	movl	%eax, 0xc(%rsp)
     c85:      	movq	(%rip), %rdi            # 0xc8c <filter_16ty_map+0x1c>
     c8c:      	leaq	0xc(%rsp), %rsi
     c91:      	movl	$0x1, %eax
     c96:      	callq	*%rax
     c98:      	testq	%rax, %rax
     c9b:      	je	0xcd1 <filter_16ty_map+0x61>
     c9d:      	movq	%rax, %rdi
     ca0:      	movzwl	(%r14), %eax
     ca4:      	movq	%rax, 0x10(%rsp)
     ca9:      	leaq	0x10(%rsp), %rsi
     cae:      	movl	$0x1, %eax
     cb3:      	callq	*%rax
     cb5:      	movl	0x4(%rbx), %edx
     cb8:      	xorl	%ecx, %ecx
     cba:      	cmpl	$0x1d, %edx
     cbd:      	ja	0xceb <filter_16ty_map+0x7b>
     cbf:      	movl	$0x30038400, %esi       # imm = 0x30038400
     cc4:      	btl	%edx, %esi
     cc7:      	jae	0xcdb <filter_16ty_map+0x6b>
     cc9:      	testq	%rax, %rax
     ccc:      	setne	%cl
     ccf:      	jmp	0xceb <filter_16ty_map+0x7b>
     cd1:      	xorl	%eax, %eax
     cd3:      	addq	$0x18, %rsp
     cd7:      	popq	%rbx
     cd8:      	popq	%r14
     cda:      	retq
     cdb:      	movl	$0xc0800, %esi          # imm = 0xC0800
     ce0:      	btl	%edx, %esi
     ce3:      	jae	0xceb <filter_16ty_map+0x7b>
     ce5:      	testq	%rax, %rax
     ce8:      	sete	%cl
     ceb:      	movzbl	%cl, %eax
     cee:      	addq	$0x18, %rsp
     cf2:      	popq	%rbx
     cf3:      	popq	%r14
     cf5:      	retq
     cf6:      	nopw	%cs:(%rax,%rax)

0000000000000d00 <filter_16ty_range>:
     d00:      	movl	0x4(%rdi), %ecx
     d03:      	movl	0xc(%rdi), %eax
     d06:      	cmpl	$0xc, %eax
     d09:      	ja	0xdf0 <filter_16ty_range+0xf0>
     d0f:      	movl	$0x1402, %edx           # imm = 0x1402
     d14:      	btl	%eax, %edx
     d17:      	jae	0xdf0 <filter_16ty_range+0xf0>
     d1d:      	movswl	(%rsi), %esi
     d20:      	cmpl	$0x1f, %ecx
     d23:      	jne	0xd8b <filter_16ty_range+0x8b>
     d25:      	movl	$0x1, %eax
     d2a:      	cmpl	%esi, 0x10(%rdi)
     d2d:      	jg	0xd38 <filter_16ty_range+0x38>
     d2f:      	cmpl	%esi, 0x14(%rdi)
     d32:      	jge	0xe07 <filter_16ty_range+0x107>
     d38:      	movl	0x8(%rdi), %edx
     d3b:      	cmpl	$0x11, %edx
     d3e:      	jb	0xea7 <filter_16ty_range+0x1a7>
     d44:      	cmpl	%esi, 0x18(%rdi)
     d47:      	jg	0xd52 <filter_16ty_range+0x52>
     d49:      	cmpl	%esi, 0x1c(%rdi)
     d4c:      	jge	0xe07 <filter_16ty_range+0x107>
     d52:      	cmpl	$0x19, %edx
     d55:      	jb	0xea7 <filter_16ty_range+0x1a7>
     d5b:      	cmpl	%esi, 0x20(%rdi)
     d5e:      	jg	0xd69 <filter_16ty_range+0x69>
     d60:      	cmpl	%esi, 0x24(%rdi)
     d63:      	jge	0xe07 <filter_16ty_range+0x107>
     d69:      	cmpl	$0x21, %edx
     d6c:      	jb	0xea7 <filter_16ty_range+0x1a7>
     d72:      	xorl	%edx, %edx
     d74:      	cmpl	%esi, 0x28(%rdi)
     d77:      	jg	0xea9 <filter_16ty_range+0x1a9>
     d7d:      	cmpl	%esi, 0x2c(%rdi)
     d80:      	jge	0xe07 <filter_16ty_range+0x107>
     d86:      	jmp	0xea9 <filter_16ty_range+0x1a9>
     d8b:      	movl	0x8(%rdi), %eax
     d8e:      	cmpl	%esi, 0x10(%rdi)
     d91:      	setle	%r8b
     d95:      	cmpl	%esi, 0x14(%rdi)
     d98:      	setge	%dl
     d9b:      	andb	%r8b, %dl
     d9e:      	cmpl	$0x11, %eax
     da1:      	jb	0xea9 <filter_16ty_range+0x1a9>
     da7:      	cmpl	%esi, 0x18(%rdi)
     daa:      	setle	%r8b
     dae:      	cmpl	%esi, 0x1c(%rdi)
     db1:      	setge	%r9b
     db5:      	andb	%r8b, %r9b
     db8:      	orb	%r9b, %dl
     dbb:      	cmpl	$0x19, %eax
     dbe:      	jb	0xea9 <filter_16ty_range+0x1a9>
     dc4:      	cmpl	%esi, 0x20(%rdi)
     dc7:      	setle	%r8b
     dcb:      	cmpl	%esi, 0x24(%rdi)
     dce:      	setge	%r9b
     dd2:      	andb	%r8b, %r9b
     dd5:      	orb	%r9b, %dl
     dd8:      	cmpl	$0x21, %eax
     ddb:      	jb	0xea9 <filter_16ty_range+0x1a9>
     de1:      	cmpl	%esi, 0x28(%rdi)
     de4:      	setle	%al
     de7:      	cmpl	%esi, 0x2c(%rdi)
     dea:      	setge	%sil
     dee:      	jmp	0xe63 <filter_16ty_range+0x163>
     df0:      	movzwl	(%rsi), %esi
     df3:      	cmpl	$0x1f, %ecx
     df6:      	jne	0xe08 <filter_16ty_range+0x108>
     df8:      	movl	$0x1, %eax
     dfd:      	cmpl	%esi, 0x10(%rdi)
     e00:      	ja	0xe6b <filter_16ty_range+0x16b>
     e02:      	cmpl	%esi, 0x14(%rdi)
     e05:      	jb	0xe6b <filter_16ty_range+0x16b>
     e07:      	retq
     e08:      	movl	0x8(%rdi), %eax
     e0b:      	cmpl	%esi, 0x10(%rdi)
     e0e:      	setbe	%r8b
     e12:      	cmpl	%esi, 0x14(%rdi)
     e15:      	setae	%dl
     e18:      	andb	%r8b, %dl
     e1b:      	cmpl	$0x11, %eax
     e1e:      	jb	0xea9 <filter_16ty_range+0x1a9>
     e24:      	cmpl	%esi, 0x18(%rdi)
     e27:      	setbe	%r8b
     e2b:      	cmpl	%esi, 0x1c(%rdi)
     e2e:      	setae	%r9b
     e32:      	andb	%r8b, %r9b
     e35:      	orb	%r9b, %dl
     e38:      	cmpl	$0x19, %eax
     e3b:      	jb	0xea9 <filter_16ty_range+0x1a9>
     e3d:      	cmpl	%esi, 0x20(%rdi)
     e40:      	setbe	%r8b
     e44:      	cmpl	%esi, 0x24(%rdi)
     e47:      	setae	%r9b
     e4b:      	andb	%r8b, %r9b
     e4e:      	orb	%r9b, %dl
     e51:      	cmpl	$0x21, %eax
     e54:      	jb	0xea9 <filter_16ty_range+0x1a9>
     e56:      	cmpl	%esi, 0x28(%rdi)
     e59:      	setbe	%al
     e5c:      	cmpl	%esi, 0x2c(%rdi)
     e5f:      	setae	%sil
     e63:      	andb	%al, %sil
     e66:      	orb	%sil, %dl
     e69:      	jmp	0xea9 <filter_16ty_range+0x1a9>
     e6b:      	movl	0x8(%rdi), %edx
     e6e:      	cmpl	$0x11, %edx
     e71:      	jb	0xea7 <filter_16ty_range+0x1a7>
     e73:      	cmpl	%esi, 0x18(%rdi)
     e76:      	ja	0xe7d <filter_16ty_range+0x17d>
     e78:      	cmpl	%esi, 0x1c(%rdi)
     e7b:      	jae	0xe07 <filter_16ty_range+0x107>
     e7d:      	cmpl	$0x19, %edx
     e80:      	jb	0xea7 <filter_16ty_range+0x1a7>
     e82:      	cmpl	%esi, 0x20(%rdi)
     e85:      	ja	0xe90 <filter_16ty_range+0x190>
     e87:      	cmpl	%esi, 0x24(%rdi)
     e8a:      	jae	0xe07 <filter_16ty_range+0x107>
     e90:      	cmpl	$0x21, %edx
     e93:      	jb	0xea7 <filter_16ty_range+0x1a7>
     e95:      	xorl	%edx, %edx
     e97:      	cmpl	%esi, 0x28(%rdi)
     e9a:      	ja	0xea9 <filter_16ty_range+0x1a9>
     e9c:      	cmpl	%esi, 0x2c(%rdi)
     e9f:      	jae	0xe07 <filter_16ty_range+0x107>
     ea5:      	jmp	0xea9 <filter_16ty_range+0x1a9>
     ea7:      	xorl	%edx, %edx
     ea9:      	cmpl	$0x20, %ecx
     eac:      	sete	%al
     eaf:      	xorb	$0x1, %dl
     eb2:      	andb	%al, %dl
     eb4:      	movzbl	%dl, %eax
     eb7:      	retq
     eb8:      	nopl	(%rax,%rax)

0000000000000ec0 <filter_8ty_selector_val>:
     ec0:      	movl	0x4(%rdi), %ecx
     ec3:      	movl	$0x1, %eax
     ec8:      	cmpq	$0x25, %rcx
     ecc:      	ja	0xf3f <filter_8ty_selector_val+0x7f>
     ece:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     ed8:      	btq	%rcx, %rdx
     edc:      	jae	0xedf <filter_8ty_selector_val+0x1f>
     ede:      	retq
     edf:      	movl	$0x18, %edx
     ee4:      	btq	%rcx, %rdx
     ee8:      	jae	0xeff <filter_8ty_selector_val+0x3f>
     eea:      	movzbl	(%rsi), %edx
     eed:      	cmpl	%edx, 0x10(%rdi)
     ef0:      	jne	0x1015 <filter_8ty_selector_val+0x155>
     ef6:      	xorl	%eax, %eax
     ef8:      	cmpl	$0x3, %ecx
     efb:      	sete	%al
     efe:      	retq
     eff:      	cmpq	$0xc, %rcx
     f03:      	jne	0xf3f <filter_8ty_selector_val+0x7f>
     f05:      	movzbl	(%rsi), %ecx
     f08:      	testl	%ecx, 0x10(%rdi)
     f0b:      	jne	0xede <filter_8ty_selector_val+0x1e>
     f0d:      	movl	0x8(%rdi), %edx
     f10:      	cmpl	$0xd, %edx
     f13:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     f19:      	testl	%ecx, 0x14(%rdi)
     f1c:      	jne	0xede <filter_8ty_selector_val+0x1e>
     f1e:      	cmpl	$0x11, %edx
     f21:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     f27:      	testl	%ecx, 0x18(%rdi)
     f2a:      	jne	0xede <filter_8ty_selector_val+0x1e>
     f2c:      	cmpl	$0x15, %edx
     f2f:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     f35:      	testl	%ecx, 0x1c(%rdi)
     f38:      	jne	0xede <filter_8ty_selector_val+0x1e>
     f3a:      	jmp	0x10d7 <filter_8ty_selector_val+0x217>
     f3f:      	cmpl	$0x1, %ecx
     f42:      	je	0xfb1 <filter_8ty_selector_val+0xf1>
     f44:      	cmpl	$0x2, %ecx
     f47:      	jne	0x10d7 <filter_8ty_selector_val+0x217>
     f4d:      	movl	0xc(%rdi), %ecx
     f50:      	cmpl	$0xc, %ecx
     f53:      	ja	0x109e <filter_8ty_selector_val+0x1de>
     f59:      	movl	$0x1402, %edx           # imm = 0x1402
     f5e:      	btl	%ecx, %edx
     f61:      	jae	0x109e <filter_8ty_selector_val+0x1de>
     f67:      	movsbl	(%rsi), %ecx
     f6a:      	cmpl	%ecx, 0x10(%rdi)
     f6d:      	jg	0xede <filter_8ty_selector_val+0x1e>
     f73:      	movl	0x8(%rdi), %edx
     f76:      	cmpl	$0xd, %edx
     f79:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     f7f:      	cmpl	%ecx, 0x14(%rdi)
     f82:      	jg	0xede <filter_8ty_selector_val+0x1e>
     f88:      	cmpl	$0x11, %edx
     f8b:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     f91:      	cmpl	%ecx, 0x18(%rdi)
     f94:      	jg	0xede <filter_8ty_selector_val+0x1e>
     f9a:      	cmpl	$0x15, %edx
     f9d:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     fa3:      	cmpl	%ecx, 0x1c(%rdi)
     fa6:      	jg	0xede <filter_8ty_selector_val+0x1e>
     fac:      	jmp	0x10d7 <filter_8ty_selector_val+0x217>
     fb1:      	movl	0xc(%rdi), %ecx
     fb4:      	cmpl	$0xc, %ecx
     fb7:      	ja	0x1063 <filter_8ty_selector_val+0x1a3>
     fbd:      	movl	$0x1402, %edx           # imm = 0x1402
     fc2:      	btl	%ecx, %edx
     fc5:      	jae	0x1063 <filter_8ty_selector_val+0x1a3>
     fcb:      	movsbl	(%rsi), %ecx
     fce:      	cmpl	%ecx, 0x10(%rdi)
     fd1:      	jl	0xede <filter_8ty_selector_val+0x1e>
     fd7:      	movl	0x8(%rdi), %edx
     fda:      	cmpl	$0xd, %edx
     fdd:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     fe3:      	cmpl	%ecx, 0x14(%rdi)
     fe6:      	jl	0xede <filter_8ty_selector_val+0x1e>
     fec:      	cmpl	$0x11, %edx
     fef:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     ff5:      	cmpl	%ecx, 0x18(%rdi)
     ff8:      	jl	0xede <filter_8ty_selector_val+0x1e>
     ffe:      	cmpl	$0x15, %edx
    1001:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    1007:      	cmpl	%ecx, 0x1c(%rdi)
    100a:      	jl	0xede <filter_8ty_selector_val+0x1e>
    1010:      	jmp	0x10d7 <filter_8ty_selector_val+0x217>
    1015:      	movl	0x8(%rdi), %esi
    1018:      	cmpl	$0xd, %esi
    101b:      	jb	0x1042 <filter_8ty_selector_val+0x182>
    101d:      	cmpl	%edx, 0x14(%rdi)
    1020:      	je	0xef6 <filter_8ty_selector_val+0x36>
    1026:      	cmpl	$0x11, %esi
    1029:      	jb	0x1042 <filter_8ty_selector_val+0x182>
    102b:      	cmpl	%edx, 0x18(%rdi)
    102e:      	je	0xef6 <filter_8ty_selector_val+0x36>
    1034:      	cmpl	$0x15, %esi
    1037:      	jb	0x1042 <filter_8ty_selector_val+0x182>
    1039:      	cmpl	%edx, 0x1c(%rdi)
    103c:      	je	0xef6 <filter_8ty_selector_val+0x36>
    1042:      	cmpl	$0x25, %ecx
    1045:      	ja	0x10d7 <filter_8ty_selector_val+0x217>
    104b:      	movl	%ecx, %ecx
    104d:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1057:      	btq	%rcx, %rdx
    105b:      	jb	0xede <filter_8ty_selector_val+0x1e>
    1061:      	jmp	0x10d7 <filter_8ty_selector_val+0x217>
    1063:      	movzbl	(%rsi), %ecx
    1066:      	cmpl	%ecx, 0x10(%rdi)
    1069:      	jb	0xede <filter_8ty_selector_val+0x1e>
    106f:      	movl	0x8(%rdi), %edx
    1072:      	cmpl	$0xd, %edx
    1075:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    1077:      	cmpl	%ecx, 0x14(%rdi)
    107a:      	jb	0xede <filter_8ty_selector_val+0x1e>
    1080:      	cmpl	$0x11, %edx
    1083:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    1085:      	cmpl	%ecx, 0x18(%rdi)
    1088:      	jb	0xede <filter_8ty_selector_val+0x1e>
    108e:      	cmpl	$0x15, %edx
    1091:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    1093:      	cmpl	%ecx, 0x1c(%rdi)
    1096:      	jb	0xede <filter_8ty_selector_val+0x1e>
    109c:      	jmp	0x10d7 <filter_8ty_selector_val+0x217>
    109e:      	movzbl	(%rsi), %ecx
    10a1:      	cmpl	%ecx, 0x10(%rdi)
    10a4:      	ja	0xede <filter_8ty_selector_val+0x1e>
    10aa:      	movl	0x8(%rdi), %edx
    10ad:      	cmpl	$0xd, %edx
    10b0:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    10b2:      	cmpl	%ecx, 0x14(%rdi)
    10b5:      	ja	0xede <filter_8ty_selector_val+0x1e>
    10bb:      	cmpl	$0x11, %edx
    10be:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    10c0:      	cmpl	%ecx, 0x18(%rdi)
    10c3:      	ja	0xede <filter_8ty_selector_val+0x1e>
    10c9:      	cmpl	$0x15, %edx
    10cc:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    10ce:      	cmpl	%ecx, 0x1c(%rdi)
    10d1:      	ja	0xede <filter_8ty_selector_val+0x1e>
    10d7:      	xorl	%eax, %eax
    10d9:      	retq
    10da:      	nopw	(%rax,%rax)

00000000000010e0 <filter_8ty_map>:
    10e0:      	pushq	%r14
    10e2:      	pushq	%rbx
    10e3:      	subq	$0x18, %rsp
    10e7:      	movq	%rsi, %r14
    10ea:      	movq	%rdi, %rbx
    10ed:      	movzbl	0x10(%rdi), %eax
    10f1:      	movl	%eax, 0xc(%rsp)
    10f5:      	movq	(%rip), %rdi            # 0x10fc <filter_8ty_map+0x1c>
    10fc:      	leaq	0xc(%rsp), %rsi
    1101:      	movl	$0x1, %eax
    1106:      	callq	*%rax
    1108:      	testq	%rax, %rax
    110b:      	je	0x1141 <filter_8ty_map+0x61>
    110d:      	movq	%rax, %rdi
    1110:      	movzbl	(%r14), %eax
    1114:      	movq	%rax, 0x10(%rsp)
    1119:      	leaq	0x10(%rsp), %rsi
    111e:      	movl	$0x1, %eax
    1123:      	callq	*%rax
    1125:      	movl	0x4(%rbx), %edx
    1128:      	xorl	%ecx, %ecx
    112a:      	cmpl	$0x1d, %edx
    112d:      	ja	0x115b <filter_8ty_map+0x7b>
    112f:      	movl	$0x30038400, %esi       # imm = 0x30038400
    1134:      	btl	%edx, %esi
    1137:      	jae	0x114b <filter_8ty_map+0x6b>
    1139:      	testq	%rax, %rax
    113c:      	setne	%cl
    113f:      	jmp	0x115b <filter_8ty_map+0x7b>
    1141:      	xorl	%eax, %eax
    1143:      	addq	$0x18, %rsp
    1147:      	popq	%rbx
    1148:      	popq	%r14
    114a:      	retq
    114b:      	movl	$0xc0800, %esi          # imm = 0xC0800
    1150:      	btl	%edx, %esi
    1153:      	jae	0x115b <filter_8ty_map+0x7b>
    1155:      	testq	%rax, %rax
    1158:      	sete	%cl
    115b:      	movzbl	%cl, %eax
    115e:      	addq	$0x18, %rsp
    1162:      	popq	%rbx
    1163:      	popq	%r14
    1165:      	retq
    1166:      	nopw	%cs:(%rax,%rax)

0000000000001170 <filter_8ty_range>:
    1170:      	movl	0x4(%rdi), %ecx
    1173:      	movl	0xc(%rdi), %eax
    1176:      	cmpl	$0xc, %eax
    1179:      	ja	0x1260 <filter_8ty_range+0xf0>
    117f:      	movl	$0x1402, %edx           # imm = 0x1402
    1184:      	btl	%eax, %edx
    1187:      	jae	0x1260 <filter_8ty_range+0xf0>
    118d:      	movsbl	(%rsi), %esi
    1190:      	cmpl	$0x1f, %ecx
    1193:      	jne	0x11fb <filter_8ty_range+0x8b>
    1195:      	movl	$0x1, %eax
    119a:      	cmpl	%esi, 0x10(%rdi)
    119d:      	jg	0x11a8 <filter_8ty_range+0x38>
    119f:      	cmpl	%esi, 0x14(%rdi)
    11a2:      	jge	0x1277 <filter_8ty_range+0x107>
    11a8:      	movl	0x8(%rdi), %edx
    11ab:      	cmpl	$0x11, %edx
    11ae:      	jb	0x1317 <filter_8ty_range+0x1a7>
    11b4:      	cmpl	%esi, 0x18(%rdi)
    11b7:      	jg	0x11c2 <filter_8ty_range+0x52>
    11b9:      	cmpl	%esi, 0x1c(%rdi)
    11bc:      	jge	0x1277 <filter_8ty_range+0x107>
    11c2:      	cmpl	$0x19, %edx
    11c5:      	jb	0x1317 <filter_8ty_range+0x1a7>
    11cb:      	cmpl	%esi, 0x20(%rdi)
    11ce:      	jg	0x11d9 <filter_8ty_range+0x69>
    11d0:      	cmpl	%esi, 0x24(%rdi)
    11d3:      	jge	0x1277 <filter_8ty_range+0x107>
    11d9:      	cmpl	$0x21, %edx
    11dc:      	jb	0x1317 <filter_8ty_range+0x1a7>
    11e2:      	xorl	%edx, %edx
    11e4:      	cmpl	%esi, 0x28(%rdi)
    11e7:      	jg	0x1319 <filter_8ty_range+0x1a9>
    11ed:      	cmpl	%esi, 0x2c(%rdi)
    11f0:      	jge	0x1277 <filter_8ty_range+0x107>
    11f6:      	jmp	0x1319 <filter_8ty_range+0x1a9>
    11fb:      	movl	0x8(%rdi), %eax
    11fe:      	cmpl	%esi, 0x10(%rdi)
    1201:      	setle	%r8b
    1205:      	cmpl	%esi, 0x14(%rdi)
    1208:      	setge	%dl
    120b:      	andb	%r8b, %dl
    120e:      	cmpl	$0x11, %eax
    1211:      	jb	0x1319 <filter_8ty_range+0x1a9>
    1217:      	cmpl	%esi, 0x18(%rdi)
    121a:      	setle	%r8b
    121e:      	cmpl	%esi, 0x1c(%rdi)
    1221:      	setge	%r9b
    1225:      	andb	%r8b, %r9b
    1228:      	orb	%r9b, %dl
    122b:      	cmpl	$0x19, %eax
    122e:      	jb	0x1319 <filter_8ty_range+0x1a9>
    1234:      	cmpl	%esi, 0x20(%rdi)
    1237:      	setle	%r8b
    123b:      	cmpl	%esi, 0x24(%rdi)
    123e:      	setge	%r9b
    1242:      	andb	%r8b, %r9b
    1245:      	orb	%r9b, %dl
    1248:      	cmpl	$0x21, %eax
    124b:      	jb	0x1319 <filter_8ty_range+0x1a9>
    1251:      	cmpl	%esi, 0x28(%rdi)
    1254:      	setle	%al
    1257:      	cmpl	%esi, 0x2c(%rdi)
    125a:      	setge	%sil
    125e:      	jmp	0x12d3 <filter_8ty_range+0x163>
    1260:      	movzbl	(%rsi), %esi
    1263:      	cmpl	$0x1f, %ecx
    1266:      	jne	0x1278 <filter_8ty_range+0x108>
    1268:      	movl	$0x1, %eax
    126d:      	cmpl	%esi, 0x10(%rdi)
    1270:      	ja	0x12db <filter_8ty_range+0x16b>
    1272:      	cmpl	%esi, 0x14(%rdi)
    1275:      	jb	0x12db <filter_8ty_range+0x16b>
    1277:      	retq
    1278:      	movl	0x8(%rdi), %eax
    127b:      	cmpl	%esi, 0x10(%rdi)
    127e:      	setbe	%r8b
    1282:      	cmpl	%esi, 0x14(%rdi)
    1285:      	setae	%dl
    1288:      	andb	%r8b, %dl
    128b:      	cmpl	$0x11, %eax
    128e:      	jb	0x1319 <filter_8ty_range+0x1a9>
    1294:      	cmpl	%esi, 0x18(%rdi)
    1297:      	setbe	%r8b
    129b:      	cmpl	%esi, 0x1c(%rdi)
    129e:      	setae	%r9b
    12a2:      	andb	%r8b, %r9b
    12a5:      	orb	%r9b, %dl
    12a8:      	cmpl	$0x19, %eax
    12ab:      	jb	0x1319 <filter_8ty_range+0x1a9>
    12ad:      	cmpl	%esi, 0x20(%rdi)
    12b0:      	setbe	%r8b
    12b4:      	cmpl	%esi, 0x24(%rdi)
    12b7:      	setae	%r9b
    12bb:      	andb	%r8b, %r9b
    12be:      	orb	%r9b, %dl
    12c1:      	cmpl	$0x21, %eax
    12c4:      	jb	0x1319 <filter_8ty_range+0x1a9>
    12c6:      	cmpl	%esi, 0x28(%rdi)
    12c9:      	setbe	%al
    12cc:      	cmpl	%esi, 0x2c(%rdi)
    12cf:      	setae	%sil
    12d3:      	andb	%al, %sil
    12d6:      	orb	%sil, %dl
    12d9:      	jmp	0x1319 <filter_8ty_range+0x1a9>
    12db:      	movl	0x8(%rdi), %edx
    12de:      	cmpl	$0x11, %edx
    12e1:      	jb	0x1317 <filter_8ty_range+0x1a7>
    12e3:      	cmpl	%esi, 0x18(%rdi)
    12e6:      	ja	0x12ed <filter_8ty_range+0x17d>
    12e8:      	cmpl	%esi, 0x1c(%rdi)
    12eb:      	jae	0x1277 <filter_8ty_range+0x107>
    12ed:      	cmpl	$0x19, %edx
    12f0:      	jb	0x1317 <filter_8ty_range+0x1a7>
    12f2:      	cmpl	%esi, 0x20(%rdi)
    12f5:      	ja	0x1300 <filter_8ty_range+0x190>
    12f7:      	cmpl	%esi, 0x24(%rdi)
    12fa:      	jae	0x1277 <filter_8ty_range+0x107>
    1300:      	cmpl	$0x21, %edx
    1303:      	jb	0x1317 <filter_8ty_range+0x1a7>
    1305:      	xorl	%edx, %edx
    1307:      	cmpl	%esi, 0x28(%rdi)
    130a:      	ja	0x1319 <filter_8ty_range+0x1a9>
    130c:      	cmpl	%esi, 0x2c(%rdi)
    130f:      	jae	0x1277 <filter_8ty_range+0x107>
    1315:      	jmp	0x1319 <filter_8ty_range+0x1a9>
    1317:      	xorl	%edx, %edx
    1319:      	cmpl	$0x20, %ecx
    131c:      	sete	%al
    131f:      	xorb	$0x1, %dl
    1322:      	andb	%al, %dl
    1324:      	movzbl	%dl, %eax
    1327:      	retq
    1328:      	nopl	(%rax,%rax)

0000000000001330 <filter_file_buf>:
    1330:      	pushq	%rbx
    1331:      	movq	%rdi, %rbx
    1334:      	movl	(%rsi), %edx
    1336:      	movl	0x4(%rdi), %ecx
    1339:      	testl	%edx, %edx
    133b:      	jne	0x134b <filter_file_buf+0x1b>
    133d:      	movl	%ecx, %eax
    133f:      	andl	$-0x2, %eax
    1342:      	cmpl	$0x24, %eax
    1345:      	je	0x134b <filter_file_buf+0x1b>
    1347:      	xorl	%eax, %eax
    1349:      	popq	%rbx
    134a:      	retq
    134b:      	cmpl	$0x25, %ecx
    134e:      	ja	0x138a <filter_file_buf+0x5a>
    1350:      	movl	%ecx, %eax
    1352:      	movl	$0x4000100, %edi        # imm = 0x4000100
    1357:      	btq	%rax, %rdi
    135b:      	jb	0x13be <filter_file_buf+0x8e>
    135d:      	movl	$0x8000200, %edi        # imm = 0x8000200
    1362:      	btq	%rax, %rdi
    1366:      	jb	0x13a8 <filter_file_buf+0x78>
    1368:      	movabsq	$0x3000000000, %rdi     # imm = 0x3000000000
    1372:      	btq	%rax, %rdi
    1376:      	jae	0x138a <filter_file_buf+0x5a>
    1378:      	movq	%rbx, %rdi
    137b:      	callq	0x1e20 <filter_file_type>
    1380:      	movl	0x4(%rbx), %ecx
    1383:      	cmpl	$0x25, %ecx
    1386:      	jbe	0x13db <filter_file_buf+0xab>
    1388:      	jmp	0x13f1 <filter_file_buf+0xc1>
    138a:      	leal	-0x3(%rcx), %eax
    138d:      	cmpl	$0x2, %eax
    1390:      	jae	0x13d4 <filter_file_buf+0xa4>
    1392:      	addq	$0x4, %rsi
    1396:      	movq	%rbx, %rdi
    1399:      	callq	0x18b0 <filter_char_buf_equal>
    139e:      	movl	0x4(%rbx), %ecx
    13a1:      	cmpl	$0x25, %ecx
    13a4:      	jbe	0x13db <filter_file_buf+0xab>
    13a6:      	jmp	0x13f1 <filter_file_buf+0xc1>
    13a8:      	addq	$0x4, %rsi
    13ac:      	movl	0x10(%rbx), %edi
    13af:      	callq	0x1cd0 <filter_char_buf_postfix>
    13b4:      	movl	0x4(%rbx), %ecx
    13b7:      	cmpl	$0x25, %ecx
    13ba:      	jbe	0x13db <filter_file_buf+0xab>
    13bc:      	jmp	0x13f1 <filter_file_buf+0xc1>
    13be:      	addq	$0x4, %rsi
    13c2:      	movl	0x10(%rbx), %edi
    13c5:      	callq	0x1c30 <filter_char_buf_prefix>
    13ca:      	movl	0x4(%rbx), %ecx
    13cd:      	cmpl	$0x25, %ecx
    13d0:      	jbe	0x13db <filter_file_buf+0xab>
    13d2:      	jmp	0x13f1 <filter_file_buf+0xc1>
    13d4:      	xorl	%eax, %eax
    13d6:      	cmpl	$0x25, %ecx
    13d9:      	ja	0x13f1 <filter_file_buf+0xc1>
    13db:      	movl	%ecx, %ecx
    13dd:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    13e7:      	btq	%rcx, %rdx
    13eb:      	jae	0x13f1 <filter_file_buf+0xc1>
    13ed:      	xorq	$0x1, %rax
    13f1:      	popq	%rbx
    13f2:      	retq
    13f3:      	nopw	%cs:(%rax,%rax)

0000000000001400 <filter_char_buf>:
    1400:      	pushq	%rbx
    1401:      	movq	%rsi, %rax
    1404:      	movq	%rdi, %rbx
    1407:      	movslq	%edx, %rcx
    140a:      	movl	-0x4(%rsi,%rcx), %edx
    140e:      	movl	%ecx, %esi
    1410:      	addq	%rax, %rsi
    1413:      	movl	0x4(%rdi), %ecx
    1416:      	xorl	%eax, %eax
    1418:      	cmpl	$0x19, %ecx
    141b:      	jg	0x1431 <filter_char_buf+0x31>
    141d:      	leal	-0x3(%rcx), %edi
    1420:      	cmpl	$0x2, %edi
    1423:      	jb	0x1468 <filter_char_buf+0x68>
    1425:      	cmpl	$0x8, %ecx
    1428:      	je	0x145e <filter_char_buf+0x5e>
    142a:      	cmpl	$0x9, %ecx
    142d:      	je	0x1440 <filter_char_buf+0x40>
    142f:      	jmp	0x147f <filter_char_buf+0x7f>
    1431:      	cmpl	$0x20, %ecx
    1434:      	jg	0x144a <filter_char_buf+0x4a>
    1436:      	cmpl	$0x1a, %ecx
    1439:      	je	0x145e <filter_char_buf+0x5e>
    143b:      	cmpl	$0x1b, %ecx
    143e:      	jne	0x147f <filter_char_buf+0x7f>
    1440:      	movl	0x10(%rbx), %edi
    1443:      	callq	0x1cd0 <filter_char_buf_postfix>
    1448:      	jmp	0x147c <filter_char_buf+0x7c>
    144a:      	cmpl	$0x21, %ecx
    144d:      	je	0x1472 <filter_char_buf+0x72>
    144f:      	cmpl	$0x22, %ecx
    1452:      	jne	0x147f <filter_char_buf+0x7f>
    1454:      	movq	%rbx, %rdi
    1457:      	movl	$0x1, %ecx
    145c:      	jmp	0x1477 <filter_char_buf+0x77>
    145e:      	movl	0x10(%rbx), %edi
    1461:      	callq	0x1c30 <filter_char_buf_prefix>
    1466:      	jmp	0x147c <filter_char_buf+0x7c>
    1468:      	movq	%rbx, %rdi
    146b:      	callq	0x18b0 <filter_char_buf_equal>
    1470:      	jmp	0x147c <filter_char_buf+0x7c>
    1472:      	movq	%rbx, %rdi
    1475:      	xorl	%ecx, %ecx
    1477:      	callq	0x1ed0 <filter_char_substring>
    147c:      	movl	0x4(%rbx), %ecx
    147f:      	cmpl	$0x25, %ecx
    1482:      	ja	0x14a1 <filter_char_buf+0xa1>
    1484:      	movl	%ecx, %ecx
    1486:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1490:      	btq	%rcx, %rdx
    1494:      	jae	0x14a1 <filter_char_buf+0xa1>
    1496:      	xorl	%ecx, %ecx
    1498:      	testq	%rax, %rax
    149b:      	sete	%cl
    149e:      	movq	%rcx, %rax
    14a1:      	popq	%rbx
    14a2:      	retq
    14a3:      	nopw	%cs:(%rax,%rax)

00000000000014b0 <filter_inet>:
    14b0:      	pushq	%r15
    14b2:      	pushq	%r14
    14b4:      	pushq	%r12
    14b6:      	pushq	%rbx
    14b7:      	subq	$0x48, %rsp
    14bb:      	movq	$0x0, 0x40(%rsp)
    14c4:      	movq	$0x0, 0x38(%rsp)
    14cd:      	movq	$0x0, 0x30(%rsp)
    14d6:      	movq	$0x0, 0x28(%rsp)
    14df:      	movq	$0x0, 0x20(%rsp)
    14e8:      	movl	$0x0, (%rsp)
    14ef:      	movl	$0x0, 0x4(%rsp)
    14f7:      	movl	0xc(%rdi), %edx
    14fa:      	xorl	%eax, %eax
    14fc:      	cmpl	$0x27, %edx
    14ff:      	jg	0x1517 <filter_inet+0x67>
    1501:      	cmpl	$0x5, %edx
    1504:      	je	0x159c <filter_inet+0xec>
    150a:      	movq	%rsi, %r8
    150d:      	cmpl	$0x7, %edx
    1510:      	je	0x1528 <filter_inet+0x78>
    1512:      	jmp	0x17ad <filter_inet+0x2fd>
    1517:      	cmpl	$0x28, %edx
    151a:      	je	0x1574 <filter_inet+0xc4>
    151c:      	movq	%rsi, %r8
    151f:      	cmpl	$0x29, %edx
    1522:      	jne	0x17ad <filter_inet+0x2fd>
    1528:      	movl	0x4(%rdi), %ecx
    152b:      	xorl	%eax, %eax
    152d:      	cmpl	$0x13, %ecx
    1530:      	jle	0x15a9 <filter_inet+0xf9>
    1532:      	cmpl	$0x17, %ecx
    1535:      	jg	0x1554 <filter_inet+0xa4>
    1537:      	leal	-0x14(%rcx), %edx
    153a:      	cmpl	$0x2, %edx
    153d:      	jb	0x15fa <filter_inet+0x14a>
    1543:      	leal	-0x16(%rcx), %edx
    1546:      	cmpl	$0x2, %edx
    1549:      	jb	0x15f4 <filter_inet+0x144>
    154f:      	jmp	0x17ad <filter_inet+0x2fd>
    1554:      	cmpl	$0x1b, %ecx
    1557:      	jg	0x1637 <filter_inet+0x187>
    155d:      	cmpl	$0x18, %ecx
    1560:      	je	0x166a <filter_inet+0x1ba>
    1566:      	cmpl	$0x19, %ecx
    1569:      	je	0x1660 <filter_inet+0x1b0>
    156f:      	jmp	0x17ad <filter_inet+0x2fd>
    1574:      	movzwl	(%rsi), %eax
    1577:      	movw	%ax, 0x46(%rsp)
    157c:      	movzwl	0x2(%rsi), %eax
    1580:      	movw	%ax, 0x40(%rsp)
    1585:      	movq	0x8(%rsi), %rax
    1589:      	movq	%rax, 0x20(%rsp)
    158e:      	movq	0x10(%rsi), %rax
    1592:      	movq	%rax, 0x28(%rsp)
    1597:      	leaq	0x20(%rsp), %rsi
    159c:      	xorl	%r8d, %r8d
    159f:      	movl	0x4(%rdi), %ecx
    15a2:      	xorl	%eax, %eax
    15a4:      	cmpl	$0x13, %ecx
    15a7:      	jg	0x1532 <filter_inet+0x82>
    15a9:      	cmpl	$0xf, %ecx
    15ac:      	jle	0x15ca <filter_inet+0x11a>
    15ae:      	cmpl	$0x11, %ecx
    15b1:      	jg	0x15e6 <filter_inet+0x136>
    15b3:      	cmpl	$0x10, %ecx
    15b6:      	je	0x15f4 <filter_inet+0x144>
    15b8:      	cmpl	$0x11, %ecx
    15bb:      	jne	0x17ad <filter_inet+0x2fd>
    15c1:      	movzwl	0x24(%rsi), %eax
    15c5:      	jmp	0x17a2 <filter_inet+0x2f2>
    15ca:      	cmpl	$0xd, %ecx
    15cd:      	je	0x166a <filter_inet+0x1ba>
    15d3:      	cmpl	$0xe, %ecx
    15d6:      	je	0x1660 <filter_inet+0x1b0>
    15dc:      	cmpl	$0xf, %ecx
    15df:      	je	0x15fa <filter_inet+0x14a>
    15e1:      	jmp	0x17ad <filter_inet+0x2fd>
    15e6:      	cmpl	$0x12, %ecx
    15e9:      	je	0x15fa <filter_inet+0x14a>
    15eb:      	cmpl	$0x13, %ecx
    15ee:      	jne	0x17ad <filter_inet+0x2fd>
    15f4:      	movzwl	0x22(%rsi), %edx
    15f8:      	jmp	0x15fe <filter_inet+0x14e>
    15fa:      	movzwl	0x20(%rsi), %edx
    15fe:      	movl	%edx, 0x4(%rsp)
    1602:      	xorl	%ebx, %ebx
    1604:      	xorl	%r15d, %r15d
    1607:      	xorl	%r14d, %r14d
    160a:      	xorl	%eax, %eax
    160c:      	cmpl	$0x11, %ecx
    160f:      	jg	0x1681 <filter_inet+0x1d1>
    1611:      	leal	-0xd(%rcx), %edx
    1614:      	cmpl	$0x2, %edx
    1617:      	jb	0x16a8 <filter_inet+0x1f8>
    161d:      	leal	-0xf(%rcx), %edx
    1620:      	cmpl	$0x2, %edx
    1623:      	jb	0x16fd <filter_inet+0x24d>
    1629:      	cmpl	$0x11, %ecx
    162c:      	je	0x17a5 <filter_inet+0x2f5>
    1632:      	jmp	0x17ad <filter_inet+0x2fd>
    1637:      	cmpl	$0x1c, %ecx
    163a:      	je	0x179e <filter_inet+0x2ee>
    1640:      	cmpl	$0x1d, %ecx
    1643:      	jne	0x17ad <filter_inet+0x2fd>
    1649:      	cmpl	$0x7, %edx
    164c:      	jne	0x17d1 <filter_inet+0x321>
    1652:      	testq	%r8, %r8
    1655:      	jne	0x17db <filter_inet+0x32b>
    165b:      	jmp	0x17a5 <filter_inet+0x2f5>
    1660:      	movq	0x10(%rsi), %rbx
    1664:      	movq	0x18(%rsi), %r14
    1668:      	jmp	0x1671 <filter_inet+0x1c1>
    166a:      	movq	(%rsi), %rbx
    166d:      	movq	0x8(%rsi), %r14
    1671:      	movq	%rbx, %r15
    1674:      	shrq	$0x20, %r15
    1678:      	xorl	%edx, %edx
    167a:      	xorl	%eax, %eax
    167c:      	cmpl	$0x11, %ecx
    167f:      	jle	0x1611 <filter_inet+0x161>
    1681:      	cmpl	$0x19, %ecx
    1684:      	ja	0x16f1 <filter_inet+0x241>
    1686:      	movl	$0x500000, %r8d         # imm = 0x500000
    168c:      	btl	%ecx, %r8d
    1690:      	jb	0x1707 <filter_inet+0x257>
    1692:      	movl	$0xa00000, %r8d         # imm = 0xA00000
    1698:      	btl	%ecx, %r8d
    169c:      	jb	0x1717 <filter_inet+0x267>
    169e:      	movl	$0x3000000, %edx        # imm = 0x3000000
    16a3:      	btl	%ecx, %edx
    16a6:      	jae	0x16f1 <filter_inet+0x241>
    16a8:      	movzwl	0x26(%rsi), %eax
    16ac:      	cmpl	$0xa, %eax
    16af:      	je	0x1727 <filter_inet+0x277>
    16b1:      	cmpl	$0x2, %eax
    16b4:      	jne	0x1797 <filter_inet+0x2e7>
    16ba:      	movq	%rdi, %r12
    16bd:      	movl	0x10(%rdi), %eax
    16c0:      	movl	%eax, 0x8(%rsp)
    16c4:      	movq	(%rip), %rdi            # 0x16cb <filter_inet+0x21b>
    16cb:      	leaq	0x8(%rsp), %rsi
    16d0:      	movl	$0x1, %eax
    16d5:      	callq	*%rax
    16d7:      	testq	%rax, %rax
    16da:      	je	0x17b9 <filter_inet+0x309>
    16e0:      	movq	%rax, %rdi
    16e3:      	movl	$0x20, 0xc(%rsp)
    16eb:      	movl	%ebx, 0x10(%rsp)
    16ef:      	jmp	0x176b <filter_inet+0x2bb>
    16f1:      	addl	$-0x12, %ecx
    16f4:      	cmpl	$0x2, %ecx
    16f7:      	jae	0x17ad <filter_inet+0x2fd>
    16fd:      	leaq	0x4(%rsp), %rsi
    1702:      	jmp	0x17a8 <filter_inet+0x2f8>
    1707:      	xorl	%eax, %eax
    1709:      	cmpl	$0x400, %edx            # imm = 0x400
    170f:      	setb	%al
    1712:      	jmp	0x17ad <filter_inet+0x2fd>
    1717:      	xorl	%eax, %eax
    1719:      	cmpl	$0x400, %edx            # imm = 0x400
    171f:      	setae	%al
    1722:      	jmp	0x17ad <filter_inet+0x2fd>
    1727:      	movq	%rdi, %r12
    172a:      	movl	0x14(%rdi), %eax
    172d:      	movl	%eax, 0x8(%rsp)
    1731:      	movq	(%rip), %rdi            # 0x1738 <filter_inet+0x288>
    1738:      	leaq	0x8(%rsp), %rsi
    173d:      	movl	$0x1, %eax
    1742:      	callq	*%rax
    1744:      	testq	%rax, %rax
    1747:      	je	0x17b9 <filter_inet+0x309>
    1749:      	movq	%rax, %rdi
    174c:      	movl	$0x80, 0xc(%rsp)
    1754:      	movl	%ebx, 0x10(%rsp)
    1758:      	movl	%r15d, 0x14(%rsp)
    175d:      	movl	%r14d, 0x18(%rsp)
    1762:      	shrq	$0x20, %r14
    1766:      	movl	%r14d, 0x1c(%rsp)
    176b:      	leaq	0xc(%rsp), %rsi
    1770:      	movl	$0x1, %eax
    1775:      	callq	*%rax
    1777:      	movl	0x4(%r12), %ecx
    177c:      	leal	-0x18(%rcx), %edx
    177f:      	cmpl	$0x2, %edx
    1782:      	jb	0x17c6 <filter_inet+0x316>
    1784:      	addl	$-0xd, %ecx
    1787:      	cmpl	$0x1, %ecx
    178a:      	ja	0x1797 <filter_inet+0x2e7>
    178c:      	testq	%rax, %rax
    178f:      	setne	%al
    1792:      	movzbl	%al, %eax
    1795:      	jmp	0x17ad <filter_inet+0x2fd>
    1797:      	xorl	%eax, %eax
    1799:      	movzbl	%al, %eax
    179c:      	jmp	0x17ad <filter_inet+0x2fd>
    179e:      	movzwl	0x26(%rsi), %eax
    17a2:      	movl	%eax, (%rsp)
    17a5:      	movq	%rsp, %rsi
    17a8:      	callq	0x800 <filter_32ty_map>
    17ad:      	addq	$0x48, %rsp
    17b1:      	popq	%rbx
    17b2:      	popq	%r12
    17b4:      	popq	%r14
    17b6:      	popq	%r15
    17b8:      	retq
    17b9:      	movl	0x4(%r12), %eax
    17be:      	andl	$-0x2, %eax
    17c1:      	cmpl	$0x18, %eax
    17c4:      	jmp	0x17c9 <filter_inet+0x319>
    17c6:      	testq	%rax, %rax
    17c9:      	sete	%al
    17cc:      	movzbl	%al, %eax
    17cf:      	jmp	0x17ad <filter_inet+0x2fd>
    17d1:      	cmpl	$0x29, %edx
    17d4:      	jne	0x17e3 <filter_inet+0x333>
    17d6:      	testq	%r8, %r8
    17d9:      	je	0x17e3 <filter_inet+0x333>
    17db:      	movzbl	0x3a(%r8), %eax
    17e0:      	movl	%eax, (%rsp)
    17e3:      	cmpl	$0x29, %edx
    17e6:      	je	0x17a5 <filter_inet+0x2f5>
    17e8:      	cmpl	$0x7, %edx
    17eb:      	je	0x17a5 <filter_inet+0x2f5>
    17ed:      	xorl	%eax, %eax
    17ef:      	jmp	0x17ad <filter_inet+0x2fd>
    17f1:      	nopw	%cs:(%rax,%rax)

0000000000001800 <filter_sockaddr_un>:
    1800:      	pushq	%rbx
    1801:      	subq	$0x10, %rsp
    1805:      	movq	%rsi, %rcx
    1808:      	addq	$0x4, %rsi
    180c:      	movzbl	0x3(%rcx), %edx
    1810:      	movl	0x4(%rdi), %r8d
    1814:      	xorl	%eax, %eax
    1816:      	cmpl	$0x19, %r8d
    181a:      	jg	0x1850 <filter_sockaddr_un+0x50>
    181c:      	leal	-0x3(%r8), %ecx
    1820:      	cmpl	$0x2, %ecx
    1823:      	jae	0x185e <filter_sockaddr_un+0x5e>
    1825:      	movq	%rdi, %rbx
    1828:      	callq	0x18b0 <filter_char_buf_equal>
    182d:      	movl	0x4(%rbx), %ecx
    1830:      	cmpq	$0x25, %rcx
    1834:      	ja	0x184a <filter_sockaddr_un+0x4a>
    1836:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1840:      	btq	%rcx, %rdx
    1844:      	jae	0x184a <filter_sockaddr_un+0x4a>
    1846:      	xorq	$0x1, %rax
    184a:      	addq	$0x10, %rsp
    184e:      	popq	%rbx
    184f:      	retq
    1850:      	cmpl	$0x1c, %r8d
    1854:      	je	0x1894 <filter_sockaddr_un+0x94>
    1856:      	cmpl	$0x1a, %r8d
    185a:      	je	0x1864 <filter_sockaddr_un+0x64>
    185c:      	jmp	0x184a <filter_sockaddr_un+0x4a>
    185e:      	cmpl	$0x8, %r8d
    1862:      	jne	0x184a <filter_sockaddr_un+0x4a>
    1864:      	movl	0x10(%rdi), %eax
    1867:      	movq	%rdi, %rbx
    186a:      	movl	%eax, %edi
    186c:      	callq	0x1c30 <filter_char_buf_prefix>
    1871:      	movl	0x4(%rbx), %ecx
    1874:      	cmpq	$0x25, %rcx
    1878:      	ja	0x184a <filter_sockaddr_un+0x4a>
    187a:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1884:      	btq	%rcx, %rdx
    1888:      	jae	0x184a <filter_sockaddr_un+0x4a>
    188a:      	xorq	$0x1, %rax
    188e:      	addq	$0x10, %rsp
    1892:      	popq	%rbx
    1893:      	retq
    1894:      	movzwl	(%rcx), %eax
    1897:      	movl	%eax, 0xc(%rsp)
    189b:      	leaq	0xc(%rsp), %rsi
    18a0:      	callq	0x800 <filter_32ty_map>
    18a5:      	addq	$0x10, %rsp
    18a9:      	popq	%rbx
    18aa:      	retq
    18ab:      	nopl	(%rax,%rax)

00000000000018b0 <filter_char_buf_equal>:
    18b0:      	pushq	%rbp
    18b1:      	pushq	%r15
    18b3:      	pushq	%r14
    18b5:      	pushq	%r13
    18b7:      	pushq	%r12
    18b9:      	pushq	%rbx
    18ba:      	subq	$0x28, %rsp
    18be:      	movl	$0x0, 0x14(%rsp)
    18c6:      	cmpl	$0x1000, %edx           # imm = 0x1000
    18cc:      	ja	0x1c1e <filter_char_buf_equal+0x36e>
    18d2:      	movl	%edx, %ebp
    18d4:      	movzwl	%bp, %eax
    18d7:      	cmpl	$0x90, %eax
    18dc:      	ja	0x1925 <filter_char_buf_equal+0x75>
    18de:      	testw	%bp, %bp
    18e1:      	je	0x18f4 <filter_char_buf_equal+0x44>
    18e3:      	movl	$0x18, %ecx
    18e8:      	movl	%ebp, %eax
    18ea:      	cltd
    18eb:      	idivl	%ecx
    18ed:      	movl	%ebp, %r14d
    18f0:      	testl	%edx, %edx
    18f2:      	je	0x1914 <filter_char_buf_equal+0x64>
    18f4:      	movl	$0x18, %ecx
    18f9:      	movl	%ebp, %eax
    18fb:      	cltd
    18fc:      	idivl	%ecx
    18fe:      	shll	$0x3, %eax
    1901:      	leal	(%rax,%rax,2), %eax
    1904:      	addl	$0x18, %eax
    1907:      	movzwl	%ax, %r14d
    190b:      	cmpl	$0x90, %r14d
    1912:      	ja	0x1963 <filter_char_buf_equal+0xb3>
    1914:      	movl	%r14d, %eax
    1917:      	cltd
    1918:      	idivl	%ecx
    191a:      	movl	%eax, %r15d
    191d:      	decl	%r15d
    1920:      	jmp	0x19ae <filter_char_buf_equal+0xfe>
    1925:      	movl	$0x100, %r14d           # imm = 0x100
    192b:      	cmpl	$0x101, %eax            # imm = 0x101
    1930:      	jb	0x1963 <filter_char_buf_equal+0xb3>
    1932:      	movl	$0x200, %r14d           # imm = 0x200
    1938:      	cmpl	$0x201, %eax            # imm = 0x201
    193d:      	jb	0x1963 <filter_char_buf_equal+0xb3>
    193f:      	movl	$0x400, %r14d           # imm = 0x400
    1945:      	cmpl	$0x401, %eax            # imm = 0x401
    194a:      	jb	0x1963 <filter_char_buf_equal+0xb3>
    194c:      	xorl	%r14d, %r14d
    194f:      	cmpl	$0x801, %eax            # imm = 0x801
    1954:      	setae	%r14b
    1958:      	shll	$0xb, %r14d
    195c:      	addl	$0x800, %r14d           # imm = 0x800
    1963:      	leal	-0x100(%r14), %eax
    196a:      	rorxl	$0x8, %eax, %eax
    1970:      	cmpl	$0x2, %eax
    1973:      	jg	0x1986 <filter_char_buf_equal+0xd6>
    1975:      	testl	%eax, %eax
    1977:      	je	0x19a0 <filter_char_buf_equal+0xf0>
    1979:      	cmpl	$0x1, %eax
    197c:      	jne	0x1998 <filter_char_buf_equal+0xe8>
    197e:      	movl	$0x7, %r15d
    1984:      	jmp	0x19ae <filter_char_buf_equal+0xfe>
    1986:      	cmpl	$0x3, %eax
    1989:      	je	0x19a8 <filter_char_buf_equal+0xf8>
    198b:      	cmpl	$0x7, %eax
    198e:      	jne	0x1998 <filter_char_buf_equal+0xe8>
    1990:      	movl	$0x9, %r15d
    1996:      	jmp	0x19ae <filter_char_buf_equal+0xfe>
    1998:      	movl	$0xa, %r15d
    199e:      	jmp	0x19ae <filter_char_buf_equal+0xfe>
    19a0:      	movl	$0x6, %r15d
    19a6:      	jmp	0x19ae <filter_char_buf_equal+0xfe>
    19a8:      	movl	$0x8, %r15d
    19ae:      	movl	%r15d, %eax
    19b1:      	andl	$0xf, %eax
    19b4:      	movl	0x10(%rdi,%rax,4), %r13d
    19b9:      	cmpl	$-0x1, %r13d
    19bd:      	je	0x1c1e <filter_char_buf_equal+0x36e>
    19c3:      	movq	%rsi, 0x20(%rsp)
    19c8:      	movq	(%rip), %rdi            # 0x19cf <filter_char_buf_equal+0x11f>
    19cf:      	leaq	0x14(%rsp), %r12
    19d4:      	movl	$0x1, %eax
    19d9:      	movq	%r12, %rsi
    19dc:      	callq	*%rax
    19de:      	movq	%rax, %rbx
    19e1:      	movq	(%rip), %rdi            # 0x19e8 <filter_char_buf_equal+0x138>
    19e8:      	movl	$0x1, %eax
    19ed:      	movq	%r12, %rsi
    19f0:      	callq	*%rax
    19f2:      	movq	%rax, %rcx
    19f5:      	xorl	%eax, %eax
    19f7:      	movq	%rbx, 0x8(%rsp)
    19fc:      	testq	%rbx, %rbx
    19ff:      	je	0x1c20 <filter_char_buf_equal+0x370>
    1a05:      	testq	%rcx, %rcx
    1a08:      	je	0x1c20 <filter_char_buf_equal+0x370>
    1a0e:      	movq	%rcx, 0x18(%rsp)
    1a13:      	cmpl	$0x5, %r15d
    1a17:      	jg	0x1a5a <filter_char_buf_equal+0x1aa>
    1a19:      	movq	0x8(%rsp), %rax
    1a1e:      	movb	%bpl, (%rax)
    1a21:      	leaq	0x1(%rax), %rdi
    1a25:      	movl	%ebp, %r12d
    1a28:      	movl	$0x4, %eax
    1a2d:      	movq	0x20(%rsp), %rdx
    1a32:      	movl	%ebp, %esi
    1a34:      	callq	*%rax
    1a36:      	subl	%ebp, %r14d
    1a39:      	jbe	0x1a9f <filter_char_buf_equal+0x1ef>
    1a3b:      	movq	0x8(%rsp), %rax
    1a40:      	leaq	(%rax,%r12), %rdi
    1a44:      	incq	%rdi
    1a47:      	andl	$0xfff, %r14d           # imm = 0xFFF
    1a4e:      	movl	$0x4, %eax
    1a53:      	movq	0x18(%rsp), %rdx
    1a58:      	jmp	0x1a9a <filter_char_buf_equal+0x1ea>
    1a5a:      	movq	0x8(%rsp), %rax
    1a5f:      	movw	%bp, (%rax)
    1a62:      	leaq	0x2(%rax), %rdi
    1a66:      	movl	%ebp, %r12d
    1a69:      	movl	$0x4, %eax
    1a6e:      	movq	0x20(%rsp), %rdx
    1a73:      	movl	%ebp, %esi
    1a75:      	callq	*%rax
    1a77:      	subl	%ebp, %r14d
    1a7a:      	jbe	0x1a9f <filter_char_buf_equal+0x1ef>
    1a7c:      	movq	0x8(%rsp), %rax
    1a81:      	leaq	(%rax,%r12), %rdi
    1a85:      	addq	$0x2, %rdi
    1a89:      	andl	$0xfff, %r14d           # imm = 0xFFF
    1a90:      	movl	$0x4, %eax
    1a95:      	movq	0x18(%rsp), %rdx
    1a9a:      	movl	%r14d, %esi
    1a9d:      	callq	*%rax
    1a9f:      	movl	%r13d, 0x4(%rsp)
    1aa4:      	cmpl	$0x4, %r15d
    1aa8:      	jle	0x1ae4 <filter_char_buf_equal+0x234>
    1aaa:      	cmpl	$0x7, %r15d
    1aae:      	jg	0x1b1e <filter_char_buf_equal+0x26e>
    1ab0:      	cmpl	$0x5, %r15d
    1ab4:      	je	0x1bd2 <filter_char_buf_equal+0x322>
    1aba:      	cmpl	$0x6, %r15d
    1abe:      	je	0x1b99 <filter_char_buf_equal+0x2e9>
    1ac4:      	cmpl	$0x7, %r15d
    1ac8:      	jne	0x1c1e <filter_char_buf_equal+0x36e>
    1ace:      	movq	(%rip), %rdi            # 0x1ad5 <filter_char_buf_equal+0x225>
    1ad5:      	leaq	0x4(%rsp), %rcx
    1ada:      	movl	$0x1, %eax
    1adf:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1ae4:      	cmpl	$0x1, %r15d
    1ae8:      	jle	0x1b4e <filter_char_buf_equal+0x29e>
    1aea:      	cmpl	$0x2, %r15d
    1aee:      	je	0x1bbf <filter_char_buf_equal+0x30f>
    1af4:      	cmpl	$0x3, %r15d
    1af8:      	je	0x1b86 <filter_char_buf_equal+0x2d6>
    1afe:      	cmpl	$0x4, %r15d
    1b02:      	jne	0x1c1e <filter_char_buf_equal+0x36e>
    1b08:      	movq	(%rip), %rdi            # 0x1b0f <filter_char_buf_equal+0x25f>
    1b0f:      	leaq	0x4(%rsp), %rcx
    1b14:      	movl	$0x1, %eax
    1b19:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1b1e:      	cmpl	$0x8, %r15d
    1b22:      	je	0x1be5 <filter_char_buf_equal+0x335>
    1b28:      	cmpl	$0x9, %r15d
    1b2c:      	je	0x1bac <filter_char_buf_equal+0x2fc>
    1b2e:      	cmpl	$0xa, %r15d
    1b32:      	jne	0x1c1e <filter_char_buf_equal+0x36e>
    1b38:      	movq	(%rip), %rdi            # 0x1b3f <filter_char_buf_equal+0x28f>
    1b3f:      	leaq	0x4(%rsp), %rcx
    1b44:      	movl	$0x1, %eax
    1b49:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1b4e:      	testl	%r15d, %r15d
    1b51:      	je	0x1b73 <filter_char_buf_equal+0x2c3>
    1b53:      	cmpl	$0x1, %r15d
    1b57:      	jne	0x1c1e <filter_char_buf_equal+0x36e>
    1b5d:      	movq	(%rip), %rdi            # 0x1b64 <filter_char_buf_equal+0x2b4>
    1b64:      	leaq	0x4(%rsp), %rcx
    1b69:      	movl	$0x1, %eax
    1b6e:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1b73:      	movq	(%rip), %rdi            # 0x1b7a <filter_char_buf_equal+0x2ca>
    1b7a:      	leaq	0x4(%rsp), %rcx
    1b7f:      	movl	$0x1, %eax
    1b84:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1b86:      	movq	(%rip), %rdi            # 0x1b8d <filter_char_buf_equal+0x2dd>
    1b8d:      	leaq	0x4(%rsp), %rcx
    1b92:      	movl	$0x1, %eax
    1b97:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1b99:      	movq	(%rip), %rdi            # 0x1ba0 <filter_char_buf_equal+0x2f0>
    1ba0:      	leaq	0x4(%rsp), %rcx
    1ba5:      	movl	$0x1, %eax
    1baa:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1bac:      	movq	(%rip), %rdi            # 0x1bb3 <filter_char_buf_equal+0x303>
    1bb3:      	leaq	0x4(%rsp), %rcx
    1bb8:      	movl	$0x1, %eax
    1bbd:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1bbf:      	movq	(%rip), %rdi            # 0x1bc6 <filter_char_buf_equal+0x316>
    1bc6:      	leaq	0x4(%rsp), %rcx
    1bcb:      	movl	$0x1, %eax
    1bd0:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1bd2:      	movq	(%rip), %rdi            # 0x1bd9 <filter_char_buf_equal+0x329>
    1bd9:      	leaq	0x4(%rsp), %rcx
    1bde:      	movl	$0x1, %eax
    1be3:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1be5:      	movq	(%rip), %rdi            # 0x1bec <filter_char_buf_equal+0x33c>
    1bec:      	leaq	0x4(%rsp), %rcx
    1bf1:      	movl	$0x1, %eax
    1bf6:      	leaq	0x4(%rsp), %rsi
    1bfb:      	callq	*%rax
    1bfd:      	testq	%rax, %rax
    1c00:      	je	0x1c1e <filter_char_buf_equal+0x36e>
    1c02:      	movq	%rax, %rdi
    1c05:      	movl	$0x1, %eax
    1c0a:      	movq	0x8(%rsp), %rsi
    1c0f:      	callq	*%rax
    1c11:      	movq	%rax, %rcx
    1c14:      	xorl	%eax, %eax
    1c16:      	testq	%rcx, %rcx
    1c19:      	setne	%al
    1c1c:      	jmp	0x1c20 <filter_char_buf_equal+0x370>
    1c1e:      	xorl	%eax, %eax
    1c20:      	addq	$0x28, %rsp
    1c24:      	popq	%rbx
    1c25:      	popq	%r12
    1c27:      	popq	%r13
    1c29:      	popq	%r14
    1c2b:      	popq	%r15
    1c2d:      	popq	%rbp
    1c2e:      	retq
    1c2f:      	nop

0000000000001c30 <filter_char_buf_prefix>:
    1c30:      	pushq	%rbp
    1c31:      	pushq	%r15
    1c33:      	pushq	%r14
    1c35:      	pushq	%rbx
    1c36:      	pushq	%rax
    1c37:      	movl	%edx, %ebp
    1c39:      	movq	%rsi, %rbx
    1c3c:      	movl	%edi, 0x4(%rsp)
    1c40:      	movl	$0x0, (%rsp)
    1c47:      	movq	(%rip), %rdi            # 0x1c4e <filter_char_buf_prefix+0x1e>
    1c4e:      	leaq	0x4(%rsp), %rsi
    1c53:      	movl	$0x1, %eax
    1c58:      	callq	*%rax
    1c5a:      	movq	%rax, %r14
    1c5d:      	xorl	%eax, %eax
    1c5f:      	testl	%ebp, %ebp
    1c61:      	je	0x1cc5 <filter_char_buf_prefix+0x95>
    1c63:      	testq	%r14, %r14
    1c66:      	je	0x1cc5 <filter_char_buf_prefix+0x95>
    1c68:      	movq	(%rip), %rdi            # 0x1c6f <filter_char_buf_prefix+0x3f>
    1c6f:      	movq	%rsp, %rsi
    1c72:      	movl	$0x1, %eax
    1c77:      	callq	*%rax
    1c79:      	testq	%rax, %rax
    1c7c:      	je	0x1cc3 <filter_char_buf_prefix+0x93>
    1c7e:      	cmpl	$0xff, %ebp
    1c84:      	movl	$0xff, %esi
    1c89:      	cmovbl	%ebp, %esi
    1c8c:      	leal	(,%rsi,8), %ecx
    1c93:      	movl	%ecx, (%rax)
    1c95:      	movq	%rax, %rdi
    1c98:      	addq	$0x4, %rdi
    1c9c:      	movq	%rax, %r15
    1c9f:      	movl	$0x4, %eax
    1ca4:      	movq	%rbx, %rdx
    1ca7:      	callq	*%rax
    1ca9:      	movl	$0x1, %eax
    1cae:      	movq	%r14, %rdi
    1cb1:      	movq	%r15, %rsi
    1cb4:      	callq	*%rax
    1cb6:      	movq	%rax, %rcx
    1cb9:      	xorl	%eax, %eax
    1cbb:      	testq	%rcx, %rcx
    1cbe:      	setne	%al
    1cc1:      	jmp	0x1cc5 <filter_char_buf_prefix+0x95>
    1cc3:      	xorl	%eax, %eax
    1cc5:      	addq	$0x8, %rsp
    1cc9:      	popq	%rbx
    1cca:      	popq	%r14
    1ccc:      	popq	%r15
    1cce:      	popq	%rbp
    1ccf:      	retq

0000000000001cd0 <filter_char_buf_postfix>:
    1cd0:      	pushq	%r15
    1cd2:      	pushq	%r14
    1cd4:      	pushq	%rbx
    1cd5:      	subq	$0x10, %rsp
    1cd9:      	movl	%edx, %ebx
    1cdb:      	movq	%rsi, %r14
    1cde:      	movl	%edi, 0xc(%rsp)
    1ce2:      	movl	$0x0, 0x8(%rsp)
    1cea:      	movq	(%rip), %rdi            # 0x1cf1 <filter_char_buf_postfix+0x21>
    1cf1:      	leaq	0xc(%rsp), %rsi
    1cf6:      	movl	$0x1, %eax
    1cfb:      	callq	*%rax
    1cfd:      	movq	%rax, %r15
    1d00:      	xorl	%eax, %eax
    1d02:      	testl	%ebx, %ebx
    1d04:      	je	0x1e10 <filter_char_buf_postfix+0x140>
    1d0a:      	testq	%r15, %r15
    1d0d:      	je	0x1e10 <filter_char_buf_postfix+0x140>
    1d13:      	movq	(%rip), %rdi            # 0x1d1a <filter_char_buf_postfix+0x4a>
    1d1a:      	leaq	0x8(%rsp), %rsi
    1d1f:      	movl	$0x1, %eax
    1d24:      	callq	*%rax
    1d26:      	testq	%rax, %rax
    1d29:      	je	0x1e0e <filter_char_buf_postfix+0x13e>
    1d2f:      	movq	%rax, %rsi
    1d32:      	cmpl	$0x7f, %ebx
    1d35:      	movl	$0x7f, %eax
    1d3a:      	cmovbl	%ebx, %eax
    1d3d:      	shll	$0x3, %eax
    1d40:      	movl	%eax, (%rsi)
    1d42:      	movl	%ebx, %eax
    1d44:      	leal	-0x4(%rbx), %ecx
    1d47:      	movq	%rsi, %rdx
    1d4a:      	addq	$0x7, %rdx
    1d4e:      	leal	-0x3(%rbx), %edi
    1d51:      	leal	-0x2(%rbx), %r8d
    1d55:      	decl	%ebx
    1d57:      	movq	$-0x3, %r9
    1d5e:      	nop
    1d60:      	leal	(%rbx,%r9), %r10d
    1d64:      	addl	$0x3, %r10d
    1d68:      	andl	$0xfff, %r10d           # imm = 0xFFF
    1d6f:      	movzbl	(%r14,%r10), %r10d
    1d74:      	movb	%r10b, -0x3(%rdx)
    1d78:      	leaq	(%rax,%r9), %r10
    1d7c:      	cmpq	$-0x2, %r10
    1d80:      	je	0x1df7 <filter_char_buf_postfix+0x127>
    1d82:      	leal	(%r8,%r9), %r11d
    1d86:      	addl	$0x3, %r11d
    1d8a:      	andl	$0xfff, %r11d           # imm = 0xFFF
    1d91:      	movzbl	(%r14,%r11), %r11d
    1d96:      	movb	%r11b, -0x2(%rdx)
    1d9a:      	cmpq	$-0x1, %r10
    1d9e:      	je	0x1df7 <filter_char_buf_postfix+0x127>
    1da0:      	leal	(%rdi,%r9), %r10d
    1da4:      	addl	$0x3, %r10d
    1da8:      	andl	$0xfff, %r10d           # imm = 0xFFF
    1daf:      	movzbl	(%r14,%r10), %r10d
    1db4:      	movb	%r10b, -0x1(%rdx)
    1db8:      	movq	%rax, %r10
    1dbb:      	addq	%r9, %r10
    1dbe:      	je	0x1df7 <filter_char_buf_postfix+0x127>
    1dc0:      	cmpq	$-0x7f, %r9
    1dc4:      	je	0x1df7 <filter_char_buf_postfix+0x127>
    1dc6:      	leal	(%rcx,%r9), %r10d
    1dca:      	addl	$0x3, %r10d
    1dce:      	andl	$0xfff, %r10d           # imm = 0xFFF
    1dd5:      	movzbl	(%r14,%r10), %r10d
    1dda:      	movb	%r10b, (%rdx)
    1ddd:      	addq	$0x4, %rdx
    1de1:      	leaq	(%rax,%r9), %r10
    1de5:      	addq	$-0x4, %r10
    1de9:      	addq	$-0x4, %r9
    1ded:      	cmpq	$-0x3, %r10
    1df1:      	jne	0x1d60 <filter_char_buf_postfix+0x90>
    1df7:      	movl	$0x1, %eax
    1dfc:      	movq	%r15, %rdi
    1dff:      	callq	*%rax
    1e01:      	movq	%rax, %rcx
    1e04:      	xorl	%eax, %eax
    1e06:      	testq	%rcx, %rcx
    1e09:      	setne	%al
    1e0c:      	jmp	0x1e10 <filter_char_buf_postfix+0x140>
    1e0e:      	xorl	%eax, %eax
    1e10:      	addq	$0x10, %rsp
    1e14:      	popq	%rbx
    1e15:      	popq	%r14
    1e17:      	popq	%r15
    1e19:      	retq
    1e1a:      	nopw	(%rax,%rax)

0000000000001e20 <filter_file_type>:
    1e20:      	pushq	%rbx
    1e21:      	subq	$0x10, %rsp
    1e25:      	movw	$0x0, 0xe(%rsp)
    1e2c:      	movl	(%rsi), %eax
    1e2e:      	cmpq	$0x1000, %rax           # imm = 0x1000
    1e34:      	ja	0x1ebc <filter_file_type+0x9c>
    1e3a:      	movq	%rdi, %rbx
    1e3d:      	leaq	(%rsi,%rax), %rcx
    1e41:      	addq	$0x8, %rcx
    1e45:      	leaq	0xe(%rsp), %rdi
    1e4a:      	movl	$0x2, %edx
    1e4f:      	movl	$0x4, %eax
    1e54:      	movl	(%rsi), %ecx
    1e56:      	leaq	(%rsi,%rcx), %rdx
    1e5a:      	addq	$0x8, %rdx
    1e5e:      	movl	$0x2, %esi
    1e63:      	callq	*%rax
    1e65:      	movl	0x10(%rbx), %edx
    1e68:      	testl	%edx, %edx
    1e6a:      	je	0x1ebc <filter_file_type+0x9c>
    1e6c:      	movzwl	0xe(%rsp), %ecx
    1e71:      	andl	$0xf000, %ecx           # imm = 0xF000
    1e77:      	movl	$0x1, %eax
    1e7c:      	cmpl	%ecx, %edx
    1e7e:      	je	0x1ebe <filter_file_type+0x9e>
    1e80:      	movl	0x8(%rbx), %edx
    1e83:      	cmpl	$0xc, %edx
    1e86:      	jbe	0x1ebc <filter_file_type+0x9c>
    1e88:      	movl	0x14(%rbx), %esi
    1e8b:      	testl	%esi, %esi
    1e8d:      	je	0x1ebc <filter_file_type+0x9c>
    1e8f:      	cmpl	%ecx, %esi
    1e91:      	je	0x1ebe <filter_file_type+0x9e>
    1e93:      	cmpl	$0x11, %edx
    1e96:      	jb	0x1ebc <filter_file_type+0x9c>
    1e98:      	movl	0x18(%rbx), %esi
    1e9b:      	testl	%esi, %esi
    1e9d:      	je	0x1ebc <filter_file_type+0x9c>
    1e9f:      	cmpl	%ecx, %esi
    1ea1:      	je	0x1ebe <filter_file_type+0x9e>
    1ea3:      	cmpl	$0x15, %edx
    1ea6:      	jb	0x1ebc <filter_file_type+0x9c>
    1ea8:      	movl	0x1c(%rbx), %edx
    1eab:      	testl	%edx, %edx
    1ead:      	je	0x1ebc <filter_file_type+0x9c>
    1eaf:      	xorl	%eax, %eax
    1eb1:      	cmpl	%ecx, %edx
    1eb3:      	sete	%al
    1eb6:      	addq	$0x10, %rsp
    1eba:      	popq	%rbx
    1ebb:      	retq
    1ebc:      	xorl	%eax, %eax
    1ebe:      	addq	$0x10, %rsp
    1ec2:      	popq	%rbx
    1ec3:      	retq
    1ec4:      	nopw	%cs:(%rax,%rax)

0000000000001ed0 <filter_char_substring>:
    1ed0:      	pushq	%rbp
    1ed1:      	pushq	%r15
    1ed3:      	pushq	%r14
    1ed5:      	pushq	%r13
    1ed7:      	pushq	%r12
    1ed9:      	pushq	%rbx
    1eda:      	pushq	%rax
    1edb:      	movq	%rsi, %r15
    1ede:      	movq	%rdi, %r14
    1ee1:      	movl	%edx, %ebp
    1ee3:      	testl	%ecx, %ecx
    1ee5:      	je	0x1fbd <filter_char_substring+0xed>
    1eeb:      	testl	%edx, %edx
    1eed:      	je	0x206d <filter_char_substring+0x19d>
    1ef3:      	leaq	0x4(%rsp), %r13
    1ef8:      	xorl	%ebx, %ebx
    1efa:      	xorl	%r12d, %r12d
    1efd:      	nopl	(%rax)
    1f00:      	movl	0x10(%r14,%rbx,4), %eax
    1f05:      	movl	%eax, 0x4(%rsp)
    1f09:      	movl	$0x1, %eax
    1f0e:      	movq	(%rip), %rdi            # 0x1f15 <filter_char_substring+0x45>
    1f15:      	movq	%r13, %rsi
    1f18:      	callq	*%rax
    1f1a:      	testq	%rax, %rax
    1f1d:      	je	0x2100 <filter_char_substring+0x230>
    1f23:      	movq	%r15, %rdx
    1f26:      	xorl	%ecx, %ecx
    1f28:      	jmp	0x1f3b <filter_char_substring+0x6b>
    1f2a:      	nopw	(%rax,%rax)
    1f30:      	incq	%rcx
    1f33:      	incq	%rdx
    1f36:      	cmpq	%rbp, %rcx
    1f39:      	je	0x1f98 <filter_char_substring+0xc8>
    1f3b:      	xorl	%esi, %esi
    1f3d:      	nopl	(%rax)
    1f40:      	leaq	(%rcx,%rsi), %rdi
    1f44:      	cmpq	%rbp, %rdi
    1f47:      	jae	0x1f30 <filter_char_substring+0x60>
    1f49:      	movsbl	(%rax,%rsi), %edi
    1f4d:      	testl	%edi, %edi
    1f4f:      	je	0x1f90 <filter_char_substring+0xc0>
    1f51:      	movsbl	(%rdx,%rsi), %r9d
    1f56:      	leal	-0x41(%r9), %r10d
    1f5a:      	movl	%r9d, %r8d
    1f5d:      	orl	$0x20, %r8d
    1f61:      	cmpl	$0x1a, %r10d
    1f65:      	cmovael	%r9d, %r8d
    1f69:      	leal	-0x41(%rdi), %r10d
    1f6d:      	movl	%edi, %r9d
    1f70:      	orl	$0x20, %r9d
    1f74:      	cmpl	$0x1a, %r10d
    1f78:      	cmovael	%edi, %r9d
    1f7c:      	cmpq	$0x62, %rsi
    1f80:      	ja	0x1f30 <filter_char_substring+0x60>
    1f82:      	incq	%rsi
    1f85:      	cmpl	%r9d, %r8d
    1f88:      	je	0x1f40 <filter_char_substring+0x70>
    1f8a:      	jmp	0x1f30 <filter_char_substring+0x60>
    1f8c:      	nopl	(%rax)
    1f90:      	testl	%ecx, %ecx
    1f92:      	jns	0x2111 <filter_char_substring+0x241>
    1f98:      	leal	0xc(%r12), %eax
    1f9d:      	cmpl	0x8(%r14), %eax
    1fa1:      	jae	0x2100 <filter_char_substring+0x230>
    1fa7:      	addl	$0x4, %r12d
    1fab:      	incq	%rbx
    1fae:      	cmpq	$0x64, %rbx
    1fb2:      	jne	0x1f00 <filter_char_substring+0x30>
    1fb8:      	jmp	0x2100 <filter_char_substring+0x230>
    1fbd:      	testl	%edx, %edx
    1fbf:      	je	0x20b2 <filter_char_substring+0x1e2>
    1fc5:      	leaq	0x4(%rsp), %r13
    1fca:      	xorl	%ebx, %ebx
    1fcc:      	xorl	%r12d, %r12d
    1fcf:      	nop
    1fd0:      	movl	0x10(%r14,%rbx,4), %eax
    1fd5:      	movl	%eax, 0x4(%rsp)
    1fd9:      	movl	$0x1, %eax
    1fde:      	movq	(%rip), %rdi            # 0x1fe5 <filter_char_substring+0x115>
    1fe5:      	movq	%r13, %rsi
    1fe8:      	callq	*%rax
    1fea:      	testq	%rax, %rax
    1fed:      	je	0x2100 <filter_char_substring+0x230>
    1ff3:      	movq	%r15, %rdx
    1ff6:      	xorl	%ecx, %ecx
    1ff8:      	jmp	0x200b <filter_char_substring+0x13b>
    1ffa:      	nopw	(%rax,%rax)
    2000:      	incq	%rcx
    2003:      	incq	%rdx
    2006:      	cmpq	%rbp, %rcx
    2009:      	je	0x2048 <filter_char_substring+0x178>
    200b:      	xorl	%esi, %esi
    200d:      	nopl	(%rax)
    2010:      	leaq	(%rcx,%rsi), %rdi
    2014:      	cmpq	%rbp, %rdi
    2017:      	jae	0x2000 <filter_char_substring+0x130>
    2019:      	movzbl	(%rax,%rsi), %edi
    201d:      	testb	%dil, %dil
    2020:      	je	0x2040 <filter_char_substring+0x170>
    2022:      	cmpq	$0x62, %rsi
    2026:      	ja	0x2000 <filter_char_substring+0x130>
    2028:      	leaq	0x1(%rsi), %r8
    202c:      	cmpb	%dil, (%rdx,%rsi)
    2030:      	movq	%r8, %rsi
    2033:      	je	0x2010 <filter_char_substring+0x140>
    2035:      	jmp	0x2000 <filter_char_substring+0x130>
    2037:      	nopw	(%rax,%rax)
    2040:      	testl	%ecx, %ecx
    2042:      	jns	0x2111 <filter_char_substring+0x241>
    2048:      	leal	0xc(%r12), %eax
    204d:      	cmpl	0x8(%r14), %eax
    2051:      	jae	0x2100 <filter_char_substring+0x230>
    2057:      	addl	$0x4, %r12d
    205b:      	incq	%rbx
    205e:      	cmpq	$0x64, %rbx
    2062:      	jne	0x1fd0 <filter_char_substring+0x100>
    2068:      	jmp	0x2100 <filter_char_substring+0x230>
    206d:      	movl	$0x10, %ebx
    2072:      	movq	(%rip), %r15            # 0x2079 <filter_char_substring+0x1a9>
    2079:      	leaq	0x4(%rsp), %r12
    207e:      	nop
    2080:      	movl	(%r14,%rbx), %eax
    2084:      	movl	%eax, 0x4(%rsp)
    2088:      	movl	$0x1, %eax
    208d:      	movq	%r15, %rdi
    2090:      	movq	%r12, %rsi
    2093:      	callq	*%rax
    2095:      	testq	%rax, %rax
    2098:      	je	0x2100 <filter_char_substring+0x230>
    209a:      	addq	$0x4, %rbx
    209e:      	leal	-0x8(%rbx), %eax
    20a1:      	cmpl	0x8(%r14), %eax
    20a5:      	jae	0x2100 <filter_char_substring+0x230>
    20a7:      	cmpq	$0x1a0, %rbx            # imm = 0x1A0
    20ae:      	jne	0x2080 <filter_char_substring+0x1b0>
    20b0:      	jmp	0x2100 <filter_char_substring+0x230>
    20b2:      	movl	$0x10, %ebx
    20b7:      	movq	(%rip), %r15            # 0x20be <filter_char_substring+0x1ee>
    20be:      	leaq	0x4(%rsp), %r12
    20c3:      	nopw	%cs:(%rax,%rax)
    20d0:      	movl	(%r14,%rbx), %eax
    20d4:      	movl	%eax, 0x4(%rsp)
    20d8:      	movl	$0x1, %eax
    20dd:      	movq	%r15, %rdi
    20e0:      	movq	%r12, %rsi
    20e3:      	callq	*%rax
    20e5:      	testq	%rax, %rax
    20e8:      	je	0x2100 <filter_char_substring+0x230>
    20ea:      	addq	$0x4, %rbx
    20ee:      	leal	-0x8(%rbx), %eax
    20f1:      	cmpl	0x8(%r14), %eax
    20f5:      	jae	0x2100 <filter_char_substring+0x230>
    20f7:      	cmpq	$0x1a0, %rbx            # imm = 0x1A0
    20fe:      	jne	0x20d0 <filter_char_substring+0x200>
    2100:      	xorl	%eax, %eax
    2102:      	addq	$0x8, %rsp
    2106:      	popq	%rbx
    2107:      	popq	%r12
    2109:      	popq	%r13
    210b:      	popq	%r14
    210d:      	popq	%r15
    210f:      	popq	%rbp
    2110:      	retq
    2111:      	movl	$0x1, %eax
    2116:      	jmp	0x2102 <filter_char_substring+0x232>
    2118:      	nopl	(%rax,%rax)

0000000000002120 <do_action>:
    2120:      	pushq	%rbp
    2121:      	pushq	%r15
    2123:      	pushq	%r14
    2125:      	pushq	%r13
    2127:      	pushq	%r12
    2129:      	pushq	%rbx
    212a:      	subq	$0x78, %rsp
    212e:      	movl	%r8d, %ebp
    2131:      	movq	%rcx, 0x38(%rsp)
    2136:      	movq	%rdx, %r15
    2139:      	movl	%esi, %ebx
    213b:      	movq	%rdi, %r14
    213e:      	movl	%esi, %eax
    2140:      	movslq	0x4(%rdx,%rax,4), %r12
    2145:      	movl	$0x0, 0x50(%rsp)
    214d:      	movq	(%rip), %rdi            # 0x2154 <do_action+0x34>
    2154:      	leaq	0x50(%rsp), %rsi
    2159:      	movl	$0x1, %eax
    215e:      	callq	*%rax
    2160:      	movq	%rax, %r13
    2163:      	xorl	%eax, %eax
    2165:      	testq	%r13, %r13
    2168:      	je	0x2980 <do_action+0x860>
    216e:      	cmpl	$0x7, %r12d
    2172:      	jg	0x219c <do_action+0x7c>
    2174:      	cmpl	$0x3, %r12d
    2178:      	jg	0x21d4 <do_action+0xb4>
    217a:      	cmpl	$0x1, %r12d
    217e:      	jg	0x2307 <do_action+0x1e7>
    2184:      	testl	%r12d, %r12d
    2187:      	je	0x25ac <do_action+0x48c>
    218d:      	cmpl	$0x1, %r12d
    2191:      	je	0x2320 <do_action+0x200>
    2197:      	jmp	0x2978 <do_action+0x858>
    219c:      	cmpl	$0xb, %r12d
    21a0:      	jg	0x22d9 <do_action+0x1b9>
    21a6:      	leal	-0xa(%r12), %ecx
    21ab:      	cmpl	$0x2, %ecx
    21ae:      	jb	0x242b <do_action+0x30b>
    21b4:      	cmpl	$0x8, %r12d
    21b8:      	je	0x2518 <do_action+0x3f8>
    21be:      	cmpl	$0x9, %r12d
    21c2:      	jne	0x2978 <do_action+0x858>
    21c8:      	incl	%ebx
    21ca:      	movl	0x4(%r15,%rbx,4), %eax
    21cf:      	jmp	0x24e4 <do_action+0x3c4>
    21d4:      	leal	-0x6(%r12), %eax
    21d9:      	cmpl	$0x2, %eax
    21dc:      	jb	0x2508 <do_action+0x3e8>
    21e2:      	cmpl	$0x4, %r12d
    21e6:      	je	0x2525 <do_action+0x405>
    21ec:      	cmpl	$0x5, %r12d
    21f0:      	jne	0x2978 <do_action+0x858>
    21f6:      	leal	0x1(%rbx), %eax
    21f9:      	movl	0x4(%r15,%rax,4), %eax
    21fe:      	addl	$0x2, %ebx
    2201:      	andl	$0x7, %eax
    2204:      	cmpl	$0x4, %eax
    2207:      	ja	0x2978 <do_action+0x858>
    220d:      	cmpl	$0x0, 0x5ea0(%r13,%rax,4)
    2216:      	jne	0x2978 <do_action+0x858>
    221c:      	movl	0x4(%r15,%rbx,4), %r14d
    2221:      	movq	0x5e78(%r13,%rax,8), %rax
    2229:      	movl	$0x0, 0xc(%rsp)
    2231:      	andl	$0x7ff, %eax            # imm = 0x7FF
    2236:      	movl	0x90(%r13,%rax), %eax
    223e:      	movl	%eax, 0x8(%rsp)
    2242:      	movl	$0xe, %eax
    2247:      	callq	*%rax
    2249:      	shrq	$0x20, %rax
    224d:      	movq	%rax, (%rsp)
    2251:      	movq	(%rip), %rdi            # 0x2258 <do_action+0x138>
    2258:      	movq	%rsp, %rsi
    225b:      	movl	$0x1, %eax
    2260:      	callq	*%rax
    2262:      	testq	%rax, %rax
    2265:      	je	0x2978 <do_action+0x858>
    226b:      	andl	$0x7, %r14d
    226f:      	cmpl	$0x4, %r14d
    2273:      	ja	0x2978 <do_action+0x858>
    2279:      	cmpl	$0x0, 0x5ea0(%r13,%r14,4)
    2282:      	jne	0x2978 <do_action+0x858>
    2288:      	movq	0x5e78(%r13,%r14,8), %rcx
    2290:      	movl	$0x0, 0xc(%rsp)
    2298:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    229e:      	movl	0x90(%r13,%rcx), %ecx
    22a6:      	movl	%ecx, 0x8(%rsp)
    22aa:      	movq	%rax, %r15
    22ad:      	movl	$0xe, %eax
    22b2:      	callq	*%rax
    22b4:      	shrq	$0x20, %rax
    22b8:      	movq	%rax, (%rsp)
    22bc:      	movq	(%rip), %rdi            # 0x22c3 <do_action+0x1a3>
    22c3:      	xorl	%ecx, %ecx
    22c5:      	movq	%rsp, %rsi
    22c8:      	movl	$0x2, %eax
    22cd:      	movq	%r15, %rdx
    22d0:      	xorl	%ecx, %ecx
    22d2:      	callq	*%rax
    22d4:      	jmp	0x2978 <do_action+0x858>
    22d9:      	cmpl	$0xc, %r12d
    22dd:      	je	0x2668 <do_action+0x548>
    22e3:      	cmpl	$0xd, %r12d
    22e7:      	je	0x2534 <do_action+0x414>
    22ed:      	cmpl	$0xe, %r12d
    22f1:      	jne	0x2978 <do_action+0x858>
    22f7:      	addl	$0x2, %ebx
    22fa:      	movzbl	%bpl, %r14d
    22fe:      	xorq	$0x9, %r14
    2302:      	jmp	0x2673 <do_action+0x553>
    2307:      	movl	$0x9, %eax
    230c:      	cmpl	$0x2, %r12d
    2310:      	je	0x24e4 <do_action+0x3c4>
    2316:      	cmpl	$0x3, %r12d
    231a:      	jne	0x2978 <do_action+0x858>
    2320:      	leal	0x1(%rbx), %eax
    2323:      	movl	0x4(%r15,%rax,4), %ebp
    2328:      	addl	$0x2, %ebx
    232b:      	movl	0x4(%r15,%rbx,4), %r14d
    2330:      	movl	$0x0, 0x10(%rsp)
    2338:      	movq	(%rip), %rdi            # 0x233f <do_action+0x21f>
    233f:      	leaq	0x10(%rsp), %rsi
    2344:      	movl	$0x1, %eax
    2349:      	callq	*%rax
    234b:      	xorl	%r15d, %r15d
    234e:      	testq	%rax, %rax
    2351:      	je	0x272b <do_action+0x60b>
    2357:      	movq	%rax, 0x38(%rsp)
    235c:      	andl	$0x7, %ebp
    235f:      	cmpl	$0x4, %ebp
    2362:      	movl	$0x0, %eax
    2367:      	ja	0x272d <do_action+0x60d>
    236d:      	cmpl	$0x0, 0x5ea0(%r13,%rbp,4)
    2376:      	jne	0x272d <do_action+0x60d>
    237c:      	movq	0x5e78(%r13,%rbp,8), %rax
    2384:      	movl	$0x0, 0xc(%rsp)
    238c:      	andl	$0x7ff, %eax            # imm = 0x7FF
    2391:      	movl	0x90(%r13,%rax), %eax
    2399:      	movl	%eax, 0x8(%rsp)
    239d:      	movl	$0xe, %eax
    23a2:      	callq	*%rax
    23a4:      	shrq	$0x20, %rax
    23a8:      	movq	%rax, (%rsp)
    23ac:      	cmpl	$0x1, %r12d
    23b0:      	jne	0x2704 <do_action+0x5e4>
    23b6:      	andl	$0x7, %r14d
    23ba:      	cmpl	$0x4, %r14d
    23be:      	ja	0x272b <do_action+0x60b>
    23c4:      	cmpl	$0x0, 0x5ea0(%r13,%r14,4)
    23cd:      	movl	$0x0, %eax
    23d2:      	jne	0x272d <do_action+0x60d>
    23d8:      	movq	0x5e78(%r13,%r14,8), %rax
    23e0:      	andl	$0x7ff, %eax            # imm = 0x7FF
    23e5:      	leaq	(%rax,%r13), %rdx
    23e9:      	addq	$0x90, %rdx
    23f0:      	movl	0x90(%r13,%rax), %esi
    23f8:      	andl	$0xfff, %esi            # imm = 0xFFF
    23fe:      	addq	$0x8, %rsi
    2402:      	movl	$0x4, %eax
    2407:      	movq	0x38(%rsp), %r14
    240c:      	movq	%r14, %rdi
    240f:      	callq	*%rax
    2411:      	movq	(%rip), %rdi            # 0x2418 <do_action+0x2f8>
    2418:      	xorl	%r15d, %r15d
    241b:      	movq	%rsp, %rsi
    241e:      	movl	$0x2, %eax
    2423:      	movq	%r14, %rdx
    2426:      	jmp	0x24db <do_action+0x3bb>
    242b:      	incl	%ebx
    242d:      	movl	0x4(%r15,%rbx,4), %ecx
    2432:      	andl	$0x7, %ecx
    2435:      	xorl	%r15d, %r15d
    2438:      	cmpl	$0x4, %ecx
    243b:      	ja	0x272d <do_action+0x60d>
    2441:      	cmpl	$0x0, 0x5ea0(%r13,%rcx,4)
    244a:      	jne	0x272d <do_action+0x60d>
    2450:      	movq	0x5e78(%r13,%rcx,8), %rcx
    2458:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    245e:      	movq	0xb8(%r13,%rcx), %rcx
    2466:      	movq	%rcx, 0x10(%rsp)
    246b:      	testq	%rcx, %rcx
    246e:      	je	0x272d <do_action+0x60d>
    2474:      	cmpl	$0xa, %r12d
    2478:      	jne	0x2715 <do_action+0x5f5>
    247e:      	movl	$0xe, %eax
    2483:      	callq	*%rax
    2485:      	movq	%rax, %r14
    2488:      	shrq	$0x20, %rax
    248c:      	movl	%eax, (%rsp)
    248f:      	movq	(%rip), %rdi            # 0x2496 <do_action+0x376>
    2496:      	movq	%rsp, %rsi
    2499:      	movl	$0x1, %eax
    249e:      	callq	*%rax
    24a0:      	movq	%rax, %rcx
    24a3:      	testq	%rax, %rax
    24a6:      	movl	$0x0, %eax
    24ab:      	je	0x272d <do_action+0x60d>
    24b1:      	movl	(%rcx), %eax
    24b3:      	movl	%eax, (%rsp)
    24b6:      	movl	%r14d, 0x4(%rsp)
    24bb:      	movq	0x8(%rcx), %rax
    24bf:      	movq	%rax, 0x8(%rsp)
    24c4:      	movq	(%rip), %rdi            # 0x24cb <do_action+0x3ab>
    24cb:      	xorl	%r15d, %r15d
    24ce:      	leaq	0x10(%rsp), %rsi
    24d3:      	movq	%rsp, %rdx
    24d6:      	movl	$0x2, %eax
    24db:      	xorl	%ecx, %ecx
    24dd:      	callq	*%rax
    24df:      	jmp	0x272b <do_action+0x60b>
    24e4:      	movl	$0x3, %r14d
    24ea:      	testb	%bpl, %bpl
    24ed:      	je	0x2673 <do_action+0x553>
    24f3:      	movslq	%eax, %rdi
    24f6:      	movl	$0x6d, %eax
    24fb:      	callq	*%rax
    24fd:      	movl	$0x2, %r14d
    2503:      	jmp	0x2673 <do_action+0x553>
    2508:      	incl	%ebx
    250a:      	movl	0x4(%r15,%rbx,4), %eax
    250f:      	movl	%eax, 0x78(%r13)
    2513:      	jmp	0x2978 <do_action+0x858>
    2518:      	movq	0x38(%rsp), %rax
    251d:      	movb	$0x0, (%rax)
    2520:      	jmp	0x2978 <do_action+0x858>
    2525:      	incl	%ebx
    2527:      	movzbl	%bpl, %r14d
    252b:      	xorq	$0x5, %r14
    252f:      	jmp	0x2673 <do_action+0x553>
    2534:      	movl	$0xe, %eax
    2539:      	callq	*%rax
    253b:      	movq	%rax, 0x20(%rsp)
    2540:      	movq	(%rip), %rdi            # 0x2547 <do_action+0x427>
    2547:      	leaq	0x20(%rsp), %rsi
    254c:      	movl	$0x1, %eax
    2551:      	callq	*%rax
    2553:      	testq	%rax, %rax
    2556:      	je	0x2978 <do_action+0x858>
    255c:      	movq	0x4(%rax), %rax
    2560:      	movq	%rax, 0x10(%rsp)
    2565:      	movl	$0x2, 0x18(%rsp)
    256d:      	movq	(%rip), %rdi            # 0x2574 <do_action+0x454>
    2574:      	leaq	0x10(%rsp), %rsi
    2579:      	movl	$0x1, %eax
    257e:      	callq	*%rax
    2580:      	movl	$0x1, 0x2c(%rsp)
    2588:      	testq	%rax, %rax
    258b:      	je	0x269e <do_action+0x57e>
    2591:      	lock
    2592:      	incl	(%rax)
    2594:      	movq	(%rip), %rdi            # 0x259b <do_action+0x47b>
    259b:      	leaq	0x20(%rsp), %rsi
    25a0:      	movl	$0x3, %eax
    25a5:      	callq	*%rax
    25a7:      	jmp	0x2978 <do_action+0x858>
    25ac:      	leal	0x1(%rbx), %eax
    25af:      	movl	0x4(%r15,%rax,4), %ebp
    25b4:      	leal	0x2(%rbx), %eax
    25b7:      	movl	0x4(%r15,%rax,4), %eax
    25bc:      	movl	%eax, 0x30(%rsp)
    25c0:      	movl	$0x7d, %eax
    25c5:      	callq	*%rax
    25c7:      	movq	%rax, 0x68(%rsp)
    25cc:      	movq	%rax, (%rsp)
    25d0:      	movl	$0x0, 0x20(%rsp)
    25d8:      	movq	%rbp, 0x70(%rsp)
    25dd:      	testq	%rbp, %rbp
    25e0:      	je	0x290a <do_action+0x7ea>
    25e6:      	movq	(%rip), %rdi            # 0x25ed <do_action+0x4cd>
    25ed:      	leaq	0x20(%rsp), %rsi
    25f2:      	movl	$0x1, %eax
    25f7:      	callq	*%rax
    25f9:      	testq	%rax, %rax
    25fc:      	je	0x290a <do_action+0x7ea>
    2602:      	movq	%rax, 0x48(%rsp)
    2607:      	movq	%rax, %rbp
    260a:      	movq	(%rip), %rdi            # 0x2611 <do_action+0x4f1>
    2611:      	leaq	0x20(%rsp), %rsi
    2616:      	movl	$0x1, %eax
    261b:      	callq	*%rax
    261d:      	movq	%rax, %rdx
    2620:      	movq	0x60(%r13), %rax
    2624:      	movq	%rax, (%rbp)
    2628:      	movq	0x70(%r13), %rax
    262c:      	movq	%rbp, 0x40(%rsp)
    2631:      	movq	%rax, 0x8(%rbp)
    2635:      	xorl	%eax, %eax
    2637:      	movq	%rax, 0x60(%rsp)
    263c:      	movl	$0x0, %eax
    2641:      	movl	0x30(%rsp), %ecx
    2645:      	cmpl	$0x2, %ecx
    2648:      	je	0x273f <do_action+0x61f>
    264e:      	cmpl	$0x1, %ecx
    2651:      	je	0x273b <do_action+0x61b>
    2657:      	testl	%ecx, %ecx
    2659:      	jne	0x290a <do_action+0x7ea>
    265f:      	movl	0x7c(%r13), %eax
    2663:      	jmp	0x273f <do_action+0x61f>
    2668:      	addl	$0x3, %ebx
    266b:      	movzbl	%bpl, %r14d
    266f:      	xorq	$0x7, %r14
    2673:      	movl	$0x0, (%rsp)
    267a:      	movq	(%rip), %rdi            # 0x2681 <do_action+0x561>
    2681:      	movq	%rsp, %rsi
    2684:      	movl	$0x1, %eax
    2689:      	callq	*%rax
    268b:      	testq	%rax, %rax
    268e:      	je	0x2978 <do_action+0x858>
    2694:      	lock
    2695:      	incq	(%rax,%r14,8)
    2699:      	jmp	0x2978 <do_action+0x858>
    269e:      	movq	(%rip), %rdi            # 0x26a5 <do_action+0x585>
    26a5:      	leaq	0x10(%rsp), %rsi
    26aa:      	leaq	0x2c(%rsp), %rdx
    26af:      	movl	$0x1, %ecx
    26b4:      	movl	$0x2, %eax
    26b9:      	callq	*%rax
    26bb:      	testq	%rax, %rax
    26be:      	je	0x2594 <do_action+0x474>
    26c4:      	movq	%rax, %r15
    26c7:      	negl	%eax
    26c9:      	movw	%ax, (%rsp)
    26cd:      	movw	$0x3, 0x2(%rsp)
    26d4:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    26de:      	movq	%rax, 0x4(%rsp)
    26e3:      	movq	(%rip), %rdi            # 0x26ea <do_action+0x5ca>
    26ea:      	movq	%rsp, %rsi
    26ed:      	movl	$0x1, %eax
    26f2:      	callq	*%rax
    26f4:      	testq	%rax, %rax
    26f7:      	je	0x298f <do_action+0x86f>
    26fd:      	incl	(%rax)
    26ff:      	jmp	0x29b1 <do_action+0x891>
    2704:      	movq	(%rip), %rdi            # 0x270b <do_action+0x5eb>
    270b:      	movq	%rsp, %rsi
    270e:      	movl	$0x3, %eax
    2713:      	jmp	0x2726 <do_action+0x606>
    2715:      	movq	(%rip), %rdi            # 0x271c <do_action+0x5fc>
    271c:      	leaq	0x10(%rsp), %rsi
    2721:      	movl	$0x3, %eax
    2726:      	callq	*%rax
    2728:      	movq	%rax, %r15
    272b:      	xorl	%eax, %eax
    272d:      	testl	%r15d, %r15d
    2730:      	jne	0x2980 <do_action+0x860>
    2736:      	jmp	0x2978 <do_action+0x858>
    273b:      	movl	0x10(%r13), %eax
    273f:      	movq	%r14, 0x30(%rsp)
    2744:      	movl	%eax, %eax
    2746:      	movq	0x40(%rsp), %rcx
    274b:      	movq	%rax, 0x10(%rcx)
    274f:      	movq	0x48(%rsp), %rdi
    2754:      	addq	$0x18, %rdi
    2758:      	movl	$0xc8, %ecx
    275d:      	movl	$0x4, %eax
    2762:      	movq	%rdi, 0x48(%rsp)
    2767:      	movl	$0xc8, %esi
    276c:      	callq	*%rax
    276e:      	xorl	%r14d, %r14d
    2771:      	movq	%r13, 0x58(%rsp)
    2776:      	jmp	0x2786 <do_action+0x666>
    2778:      	addq	$0x4, %r14
    277c:      	cmpq	$0x14, %r14
    2780:      	je	0x28b3 <do_action+0x793>
    2786:      	movl	$0x0, 0x10(%rsp)
    278e:      	movl	$0x1, %eax
    2793:      	movq	(%rip), %rdi            # 0x279a <do_action+0x67a>
    279a:      	leaq	0x10(%rsp), %rsi
    279f:      	callq	*%rax
    27a1:      	testq	%rax, %rax
    27a4:      	je	0x28b3 <do_action+0x793>
    27aa:      	movq	%rax, %rsi
    27ad:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    27b4:      	movl	$0x1, %eax
    27b9:      	movq	(%rip), %rdi            # 0x27c0 <do_action+0x6a0>
    27c0:      	callq	*%rax
    27c2:      	testq	%rax, %rax
    27c5:      	je	0x28b3 <do_action+0x793>
    27cb:      	cmpl	$-0x1, 0x40(%rax,%r14)
    27d1:      	je	0x28b3 <do_action+0x793>
    27d7:      	movq	0x5e78(%r13,%r14,2), %rax
    27df:      	movl	0x4(%r13), %ecx
    27e3:      	cmpq	%rcx, %rax
    27e6:      	jge	0x28b3 <do_action+0x793>
    27ec:      	cmpq	$0x10, %r14
    27f0:      	je	0x2853 <do_action+0x733>
    27f2:      	movl	$0x0, 0x10(%rsp)
    27fa:      	movl	$0x1, %eax
    27ff:      	movq	(%rip), %rdi            # 0x2806 <do_action+0x6e6>
    2806:      	leaq	0x10(%rsp), %rsi
    280b:      	callq	*%rax
    280d:      	testq	%rax, %rax
    2810:      	je	0x284b <do_action+0x72b>
    2812:      	movq	%rax, %rsi
    2815:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    281c:      	movl	$0x1, %eax
    2821:      	movq	(%rip), %rdi            # 0x2828 <do_action+0x708>
    2828:      	callq	*%rax
    282a:      	testq	%rax, %rax
    282d:      	je	0x284b <do_action+0x72b>
    282f:      	cmpl	$-0x1, 0x44(%rax,%r14)
    2835:      	movq	0x5e78(%r13,%r14,2), %rax
    283d:      	je	0x2853 <do_action+0x733>
    283f:      	movl	0x5e80(%r13,%r14,2), %ebp
    2847:      	subl	%eax, %ebp
    2849:      	jmp	0x285c <do_action+0x73c>
    284b:      	movq	0x5e78(%r13,%r14,2), %rax
    2853:      	movl	0x4(%r13), %ebp
    2857:      	subl	%eax, %ebp
    2859:      	addl	$0x4, %ebp
    285c:      	testl	%ebp, %ebp
    285e:      	jle	0x2778 <do_action+0x658>
    2864:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    2869:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    286e:      	cmpl	$0x28, %ebp
    2871:      	movl	$0x28, %ecx
    2876:      	cmovgel	%ecx, %ebp
    2879:      	movzbl	0x60(%rsp), %r13d
    287f:      	movq	0x48(%rsp), %rcx
    2884:      	leaq	(%rcx,%r13), %rdi
    2888:      	movq	0x58(%rsp), %rcx
    288d:      	leaq	(%rcx,%rax), %rdx
    2891:      	addq	$0x90, %rdx
    2898:      	movl	$0x4, %eax
    289d:      	movl	%ebp, %esi
    289f:      	callq	*%rax
    28a1:      	addl	%r13d, %ebp
    28a4:      	movq	0x58(%rsp), %r13
    28a9:      	movq	%rbp, 0x60(%rsp)
    28ae:      	jmp	0x2778 <do_action+0x658>
    28b3:      	movq	(%rip), %rdi            # 0x28ba <do_action+0x79a>
    28ba:      	movl	$0x1, %eax
    28bf:      	movq	0x40(%rsp), %rsi
    28c4:      	callq	*%rax
    28c6:      	testq	%rax, %rax
    28c9:      	je	0x28eb <do_action+0x7cb>
    28cb:      	imulq	$-0xf4240, 0x70(%rsp), %rcx # imm = 0xFFF0BDC0
    28d4:      	movq	0x68(%rsp), %rdx
    28d9:      	addq	%rcx, %rdx
    28dc:      	cmpq	%rdx, (%rax)
    28df:      	jbe	0x28eb <do_action+0x7cb>
    28e1:      	movq	0x38(%rsp), %rax
    28e6:      	movb	$0x0, (%rax)
    28e9:      	jmp	0x2905 <do_action+0x7e5>
    28eb:      	movq	(%rip), %rdi            # 0x28f2 <do_action+0x7d2>
    28f2:      	xorl	%ecx, %ecx
    28f4:      	movq	%rsp, %rdx
    28f7:      	movl	$0x2, %eax
    28fc:      	movq	0x40(%rsp), %rsi
    2901:      	xorl	%ecx, %ecx
    2903:      	callq	*%rax
    2905:      	movq	0x30(%rsp), %r14
    290a:      	leal	0x3(%rbx), %eax
    290d:      	cmpl	$0x0, 0x4(%r15,%rax,4)
    2913:      	je	0x2936 <do_action+0x816>
    2915:      	orb	$0x2, 0x1(%r13)
    291a:      	movq	(%rip), %rsi            # 0x2921 <do_action+0x801>
    2921:      	xorl	%ecx, %ecx
    2923:      	movl	$0x1b, %eax
    2928:      	movq	%r14, %rdi
    292b:      	xorl	%edx, %edx
    292d:      	callq	*%rax
    292f:      	movq	%rax, 0x80(%r13)
    2936:      	leal	0x4(%rbx), %eax
    2939:      	cmpl	$0x0, 0x4(%r15,%rax,4)
    293f:      	je	0x2968 <do_action+0x848>
    2941:      	orb	$0x4, 0x1(%r13)
    2946:      	movq	(%rip), %rsi            # 0x294d <do_action+0x82d>
    294d:      	movl	$0x100, %ecx            # imm = 0x100
    2952:      	movl	$0x1b, %eax
    2957:      	movl	$0x100, %edx            # imm = 0x100
    295c:      	movq	%r14, %rdi
    295f:      	callq	*%rax
    2961:      	movq	%rax, 0x88(%r13)
    2968:      	addl	$0x5, %ebx
    296b:      	cmpl	$0x0, 0x4(%r15,%rbx,4)
    2971:      	je	0x2978 <do_action+0x858>
    2973:      	orb	$0x8, 0x1(%r13)
    2978:      	movq	%r12, 0x70(%r13)
    297c:      	incl	%ebx
    297e:      	movl	%ebx, %eax
    2980:      	addq	$0x78, %rsp
    2984:      	popq	%rbx
    2985:      	popq	%r12
    2987:      	popq	%r13
    2989:      	popq	%r14
    298b:      	popq	%r15
    298d:      	popq	%rbp
    298e:      	retq
    298f:      	movl	$0x1, 0x54(%rsp)
    2997:      	movq	(%rip), %rdi            # 0x299e <do_action+0x87e>
    299e:      	xorl	%ecx, %ecx
    29a0:      	movq	%rsp, %rsi
    29a3:      	leaq	0x54(%rsp), %rdx
    29a8:      	movl	$0x2, %eax
    29ad:      	xorl	%ecx, %ecx
    29af:      	callq	*%rax
    29b1:      	testl	%r15d, %r15d
    29b4:      	je	0x2594 <do_action+0x474>
    29ba:      	movq	(%rip), %rdi            # 0x29c1 <do_action+0x8a1>
    29c1:      	leaq	0x10(%rsp), %rsi
    29c6:      	movl	$0x1, %eax
    29cb:      	callq	*%rax
    29cd:      	testq	%rax, %rax
    29d0:      	je	0x2594 <do_action+0x474>
    29d6:      	movl	0x2c(%rsp), %ecx
    29da:      	lock
    29db:      	addl	%ecx, (%rax)
    29dd:      	jmp	0x2594 <do_action+0x474>

Disassembly of section uprobe.multi:

0000000000000000 <generic_retuprobe_filter_arg>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x28, %rsp
       e:      	movq	%rdi, %rbx
      11:      	movl	$0x0, 0x4(%rsp)
      19:      	movq	(%rip), %rdi            # 0x20 <generic_retuprobe_filter_arg+0x20>
      20:      	leaq	0x4(%rsp), %rsi
      25:      	movl	$0x1, %eax
      2a:      	callq	*%rax
      2c:      	testq	%rax, %rax
      2f:      	je	0x398 <generic_retuprobe_filter_arg+0x398>
      35:      	movq	%rax, %r14
      38:      	movl	0x5f00(%rax), %r12d
      3f:      	leaq	0x5ef8(%rax), %rsi
      46:      	movq	(%rip), %rdi            # 0x4d <generic_retuprobe_filter_arg+0x4d>
      4d:      	movl	$0x1, %eax
      52:      	callq	*%rax
      54:      	testq	%rax, %rax
      57:      	je	0x37d <generic_retuprobe_filter_arg+0x37d>
      5d:      	cmpb	$0x0, 0x5ee0(%r14)
      65:      	je	0x37d <generic_retuprobe_filter_arg+0x37d>
      6b:      	movq	%rax, %r15
      6e:      	movl	%r12d, %eax
      71:      	andl	$0x7, %eax
      74:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
      7d:      	je	0xb7 <generic_retuprobe_filter_arg+0xb7>
      7f:      	movl	%eax, %eax
      81:      	movl	0x4(%r15,%rax,4), %ecx
      86:      	leaq	(%rcx,%rax,4), %r13
      8a:      	addq	$0x8, %r13
      8e:      	movq	%r13, %rax
      91:      	movq	%r13, 0x10(%rsp)
      96:      	andl	$0x3ff, %r13d           # imm = 0x3FF
      9d:      	cmpl	$0x19, (%r15,%r13)
      a2:      	jae	0x10c <generic_retuprobe_filter_arg+0x10c>
      a4:      	cmpq	$0x1, %r13
      a8:      	je	0x37d <generic_retuprobe_filter_arg+0x37d>
      ae:      	testl	%r13d, %r13d
      b1:      	jne	0x35b <generic_retuprobe_filter_arg+0x35b>
      b7:      	cmpl	$0x1, %r12d
      bb:      	jg	0xdc <generic_retuprobe_filter_arg+0xdc>
      bd:      	cmpl	$-0x1, %r12d
      c1:      	je	0x3a9 <generic_retuprobe_filter_arg+0x3a9>
      c7:      	testl	%r12d, %r12d
      ca:      	je	0x3b6 <generic_retuprobe_filter_arg+0x3b6>
      d0:      	cmpl	$0x1, %r12d
      d4:      	je	0x3c6 <generic_retuprobe_filter_arg+0x3c6>
      da:      	jmp	0xfa <generic_retuprobe_filter_arg+0xfa>
      dc:      	cmpl	$0x2, %r12d
      e0:      	je	0x3d6 <generic_retuprobe_filter_arg+0x3d6>
      e6:      	cmpl	$0x3, %r12d
      ea:      	je	0x3e6 <generic_retuprobe_filter_arg+0x3e6>
      f0:      	cmpl	$0x4, %r12d
      f4:      	je	0x3f6 <generic_retuprobe_filter_arg+0x3f6>
      fa:      	cmpl	$0x4, %r12d
      fe:      	jg	0x428 <generic_retuprobe_filter_arg+0x428>
     104:      	incl	%r12d
     107:      	jmp	0x406 <generic_retuprobe_filter_arg+0x406>
     10c:      	leaq	(%r15,%r13), %rax
     110:      	movq	%rax, 0x8(%rsp)
     115:      	movl	$0x1, %ebp
     11a:      	nopw	(%rax,%rax)
     120:      	movq	0x8(%rsp), %rax
     125:      	movl	(%rax,%rbp,4), %edi
     128:      	testl	$0x3ff, %edi            # imm = 0x3FF
     12e:      	je	0xa4 <generic_retuprobe_filter_arg+0xa4>
     134:      	addl	0x10(%rsp), %edi
     138:      	andl	$0x3ff, %edi            # imm = 0x3FF
     13e:      	movl	0x4(%r15,%rdi), %ecx
     143:      	cmpl	$0x23, %ecx
     146:      	je	0xb7 <generic_retuprobe_filter_arg+0xb7>
     14c:      	addq	%r15, %rdi
     14f:      	movl	(%rdi), %eax
     151:      	cmpq	$0x4, %rax
     155:      	ja	0xb7 <generic_retuprobe_filter_arg+0xb7>
     15b:      	cmpl	$0x0, 0x5ea0(%r14,%rax,4)
     164:      	jne	0xb7 <generic_retuprobe_filter_arg+0xb7>
     16a:      	movq	0x5e78(%r14,%rax,8), %rax
     172:      	andl	$0x7ff, %eax            # imm = 0x7FF
     177:      	leaq	(%r14,%rax), %rsi
     17b:      	addq	$0x90, %rsi
     182:      	movl	0xc(%rdi), %eax
     185:      	cmpl	$0x1b, %eax
     188:      	jle	0x1a9 <generic_retuprobe_filter_arg+0x1a9>
     18a:      	cmpl	$0x25, %eax
     18d:      	jg	0x1d9 <generic_retuprobe_filter_arg+0x1d9>
     18f:      	leal	-0x1c(%rax), %edx
     192:      	cmpl	$0x9, %edx
     195:      	jb	0x21f <generic_retuprobe_filter_arg+0x21f>
     19b:      	cmpl	$0x25, %eax
     19e:      	je	0x302 <generic_retuprobe_filter_arg+0x302>
     1a4:      	jmp	0x349 <generic_retuprobe_filter_arg+0x349>
     1a9:      	cmpl	$0x9, %eax
     1ac:      	jle	0x1ff <generic_retuprobe_filter_arg+0x1ff>
     1ae:      	leal	-0xa(%rax), %edx
     1b1:      	cmpl	$0x4, %edx
     1b4:      	jb	0x21f <generic_retuprobe_filter_arg+0x21f>
     1b6:      	leal	-0xf(%rax), %ecx
     1b9:      	cmpl	$0x2, %ecx
     1bc:      	jb	0x302 <generic_retuprobe_filter_arg+0x302>
     1c2:      	cmpl	$0x11, %eax
     1c5:      	jne	0x349 <generic_retuprobe_filter_arg+0x349>
     1cb:      	addq	$0x4, %rsi
     1cf:      	callq	0x1d4 <generic_retuprobe_filter_arg+0x1d4>
     1d4:      	jmp	0x340 <generic_retuprobe_filter_arg+0x340>
     1d9:      	cmpl	$0x29, %eax
     1dc:      	jg	0x2f1 <generic_retuprobe_filter_arg+0x2f1>
     1e2:      	leal	-0x26(%rax), %ecx
     1e5:      	cmpl	$0x2, %ecx
     1e8:      	jb	0x2ac <generic_retuprobe_filter_arg+0x2ac>
     1ee:      	addl	$-0x28, %eax
     1f1:      	cmpl	$0x2, %eax
     1f4:      	jb	0x2a2 <generic_retuprobe_filter_arg+0x2a2>
     1fa:      	jmp	0x349 <generic_retuprobe_filter_arg+0x349>
     1ff:      	cmpl	$0x4, %eax
     202:      	jg	0x28f <generic_retuprobe_filter_arg+0x28f>
     208:      	cmpl	$0x1, %eax
     20b:      	je	0x21f <generic_retuprobe_filter_arg+0x21f>
     20d:      	cmpl	$0x2, %eax
     210:      	je	0x31f <generic_retuprobe_filter_arg+0x31f>
     216:      	cmpl	$0x4, %eax
     219:      	jne	0x349 <generic_retuprobe_filter_arg+0x349>
     21f:      	cmpl	$0xb, %eax
     222:      	jle	0x26c <generic_retuprobe_filter_arg+0x26c>
     224:      	cmpl	$0x24, %eax
     227:      	ja	0x309 <generic_retuprobe_filter_arg+0x309>
     22d:      	movl	%eax, %edx
     22f:      	movabsq	$0x1e00000000, %r8      # imm = 0x1E00000000
     239:      	btq	%rdx, %r8
     23d:      	jb	0x2b3 <generic_retuprobe_filter_arg+0x2b3>
     23f:      	movl	$0x60000000, %ecx       # imm = 0x60000000
     244:      	btq	%rdx, %rcx
     248:      	jb	0x318 <generic_retuprobe_filter_arg+0x318>
     24e:      	movabsq	$0x180000000, %rcx      # imm = 0x180000000
     258:      	btq	%rdx, %rcx
     25c:      	jae	0x309 <generic_retuprobe_filter_arg+0x309>
     262:      	callq	0x267 <generic_retuprobe_filter_arg+0x267>
     267:      	jmp	0x340 <generic_retuprobe_filter_arg+0x340>
     26c:      	leal	-0xa(%rax), %ecx
     26f:      	cmpl	$0x2, %ecx
     272:      	jb	0x330 <generic_retuprobe_filter_arg+0x330>
     278:      	cmpl	$0x1, %eax
     27b:      	je	0x311 <generic_retuprobe_filter_arg+0x311>
     281:      	cmpl	$0x4, %eax
     284:      	je	0x311 <generic_retuprobe_filter_arg+0x311>
     28a:      	jmp	0x349 <generic_retuprobe_filter_arg+0x349>
     28f:      	cmpl	$0x5, %eax
     292:      	je	0x2a2 <generic_retuprobe_filter_arg+0x2a2>
     294:      	cmpl	$0x6, %eax
     297:      	je	0x2ac <generic_retuprobe_filter_arg+0x2ac>
     299:      	cmpl	$0x7, %eax
     29c:      	jne	0x349 <generic_retuprobe_filter_arg+0x349>
     2a2:      	callq	0x2a7 <generic_retuprobe_filter_arg+0x2a7>
     2a7:      	jmp	0x340 <generic_retuprobe_filter_arg+0x340>
     2ac:      	movl	$0x4, %edx
     2b1:      	jmp	0x324 <generic_retuprobe_filter_arg+0x324>
     2b3:      	cmpl	$0x1e, %ecx
     2b6:      	jne	0x330 <generic_retuprobe_filter_arg+0x330>
     2b8:      	movl	0x10(%rdi), %eax
     2bb:      	andl	$0x7, %eax
     2be:      	movl	%eax, %ecx
     2c0:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
     2c9:      	jne	0xb7 <generic_retuprobe_filter_arg+0xb7>
     2cf:      	movq	(%rsi), %rcx
     2d2:      	movq	0x5e78(%r14,%rax,8), %rdx
     2da:      	andl	$0x7ff, %edx            # imm = 0x7FF
     2e0:      	xorl	%eax, %eax
     2e2:      	andnq	0x90(%r14,%rdx), %rcx, %rcx
     2ec:      	setne	%al
     2ef:      	jmp	0x340 <generic_retuprobe_filter_arg+0x340>
     2f1:      	cmpl	$0x2a, %eax
     2f4:      	je	0x302 <generic_retuprobe_filter_arg+0x302>
     2f6:      	cmpl	$0x2c, %eax
     2f9:      	jne	0x349 <generic_retuprobe_filter_arg+0x349>
     2fb:      	callq	0x300 <generic_retuprobe_filter_arg+0x300>
     300:      	jmp	0x340 <generic_retuprobe_filter_arg+0x340>
     302:      	callq	0x307 <generic_retuprobe_filter_arg+0x307>
     307:      	jmp	0x340 <generic_retuprobe_filter_arg+0x340>
     309:      	leal	-0xc(%rax), %ecx
     30c:      	cmpl	$0x2, %ecx
     30f:      	jae	0x32b <generic_retuprobe_filter_arg+0x32b>
     311:      	callq	0x316 <generic_retuprobe_filter_arg+0x316>
     316:      	jmp	0x340 <generic_retuprobe_filter_arg+0x340>
     318:      	callq	0x31d <generic_retuprobe_filter_arg+0x31d>
     31d:      	jmp	0x340 <generic_retuprobe_filter_arg+0x340>
     31f:      	movl	$0x8, %edx
     324:      	callq	0x329 <generic_retuprobe_filter_arg+0x329>
     329:      	jmp	0x340 <generic_retuprobe_filter_arg+0x340>
     32b:      	cmpl	$0x1c, %eax
     32e:      	jne	0x349 <generic_retuprobe_filter_arg+0x349>
     330:      	callq	0x335 <generic_retuprobe_filter_arg+0x335>
     335:      	nopw	%cs:(%rax,%rax)
     340:      	testq	%rax, %rax
     343:      	je	0xb7 <generic_retuprobe_filter_arg+0xb7>
     349:      	incq	%rbp
     34c:      	cmpq	$0x6, %rbp
     350:      	jne	0x120 <generic_retuprobe_filter_arg+0x120>
     356:      	jmp	0xa4 <generic_retuprobe_filter_arg+0xa4>
     35b:      	movl	%r13d, 0x5f04(%r14)
     362:      	movq	(%rip), %rsi            # 0x369 <generic_retuprobe_filter_arg+0x369>
     369:      	movl	$0x4, %ecx
     36e:      	movl	$0xc, %eax
     373:      	movq	%rbx, %rdi
     376:      	movl	$0x4, %edx
     37b:      	callq	*%rax
     37d:      	movq	(%rip), %rsi            # 0x384 <generic_retuprobe_filter_arg+0x384>
     384:      	movl	$0x5, %ecx
     389:      	movl	$0xc, %eax
     38e:      	movq	%rbx, %rdi
     391:      	movl	$0x5, %edx
     396:      	callq	*%rax
     398:      	xorl	%eax, %eax
     39a:      	addq	$0x28, %rsp
     39e:      	popq	%rbx
     39f:      	popq	%r12
     3a1:      	popq	%r13
     3a3:      	popq	%r14
     3a5:      	popq	%r15
     3a7:      	popq	%rbp
     3a8:      	retq
     3a9:      	xorl	%r12d, %r12d
     3ac:      	cmpb	$0x0, 0x5ec1(%r14)
     3b4:      	jne	0x406 <generic_retuprobe_filter_arg+0x406>
     3b6:      	movl	$0x1, %r12d
     3bc:      	cmpb	$0x0, 0x5ec2(%r14)
     3c4:      	jne	0x406 <generic_retuprobe_filter_arg+0x406>
     3c6:      	movl	$0x2, %r12d
     3cc:      	cmpb	$0x0, 0x5ec3(%r14)
     3d4:      	jne	0x406 <generic_retuprobe_filter_arg+0x406>
     3d6:      	movl	$0x3, %r12d
     3dc:      	cmpb	$0x0, 0x5ec4(%r14)
     3e4:      	jne	0x406 <generic_retuprobe_filter_arg+0x406>
     3e6:      	movl	$0x4, %r12d
     3ec:      	cmpb	$0x0, 0x5ec5(%r14)
     3f4:      	jne	0x406 <generic_retuprobe_filter_arg+0x406>
     3f6:      	movl	$0x5, %r12d
     3fc:      	cmpb	$0x0, 0x5ec6(%r14)
     404:      	je	0x428 <generic_retuprobe_filter_arg+0x428>
     406:      	movl	%r12d, 0x5f00(%r14)
     40d:      	movq	(%rip), %rsi            # 0x414 <generic_retuprobe_filter_arg+0x414>
     414:      	movl	$0x3, %ecx
     419:      	movl	$0xc, %eax
     41e:      	movq	%rbx, %rdi
     421:      	movl	$0x3, %edx
     426:      	callq	*%rax
     428:      	movq	0x60(%r14), %rbx
     42c:      	movl	$0xe, %eax
     431:      	callq	*%rax
     433:      	movq	%rbx, 0x18(%rsp)
     438:      	movq	%rax, 0x20(%rsp)
     43d:      	movq	(%rip), %rdi            # 0x444 <generic_retuprobe_filter_arg+0x444>
     444:      	leaq	0x18(%rsp), %rsi
     449:      	movl	$0x1, %eax
     44e:      	callq	*%rax
     450:      	testq	%rax, %rax
     453:      	je	0x398 <generic_retuprobe_filter_arg+0x398>
     459:      	movq	(%rip), %rdi            # 0x460 <generic_retuprobe_filter_arg+0x460>
     460:      	leaq	0x18(%rsp), %rsi
     465:      	movl	$0x3, %eax
     46a:      	callq	*%rax
     46c:      	jmp	0x398 <generic_retuprobe_filter_arg+0x398>
     471:      	nopw	%cs:(%rax,%rax)

0000000000000480 <generic_retuprobe_actions>:
     480:      	pushq	%rbp
     481:      	pushq	%r14
     483:      	pushq	%rbx
     484:      	subq	$0x10, %rsp
     488:      	movq	%rdi, %rbx
     48b:      	movl	$0x0, 0x8(%rsp)
     493:      	movq	(%rip), %rdi            # 0x49a <generic_retuprobe_actions+0x1a>
     49a:      	leaq	0x8(%rsp), %rsi
     49f:      	movl	$0x1, %eax
     4a4:      	callq	*%rax
     4a6:      	testq	%rax, %rax
     4a9:      	je	0x5b2 <generic_retuprobe_actions+0x132>
     4af:      	movq	%rax, %rsi
     4b2:      	movl	0x5f04(%rax), %r14d
     4b9:      	cmpl	$0x2, %r14d
     4bd:      	jl	0x5b2 <generic_retuprobe_actions+0x132>
     4c3:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     4ca:      	movq	(%rip), %rdi            # 0x4d1 <generic_retuprobe_actions+0x51>
     4d1:      	movl	$0x1, %eax
     4d6:      	callq	*%rax
     4d8:      	testq	%rax, %rax
     4db:      	je	0x5b2 <generic_retuprobe_actions+0x132>
     4e1:      	movl	%r14d, %ecx
     4e4:      	andl	$0x7ff, %ecx            # imm = 0x7FF
     4ea:      	addl	(%rax,%rcx), %r14d
     4ee:      	movb	$0x1, 0x7(%rsp)
     4f3:      	movl	$0x0, 0xc(%rsp)
     4fb:      	movq	(%rip), %rdi            # 0x502 <generic_retuprobe_actions+0x82>
     502:      	leaq	0xc(%rsp), %rsi
     507:      	movq	%rax, %rcx
     50a:      	movl	$0x1, %eax
     50f:      	andl	$0x7ff, %r14d           # imm = 0x7FF
     516:      	addq	%rcx, %r14
     519:      	callq	*%rax
     51b:      	testq	%rax, %rax
     51e:      	je	0x52e <generic_retuprobe_actions+0xae>
     520:      	cmpb	$0x0, (%rax)
     523:      	sete	%al
     526:      	cmpl	$0x5, (%r14)
     52a:      	jae	0x536 <generic_retuprobe_actions+0xb6>
     52c:      	jmp	0x590 <generic_retuprobe_actions+0x110>
     52e:      	movb	$0x1, %al
     530:      	cmpl	$0x5, (%r14)
     534:      	jb	0x590 <generic_retuprobe_actions+0x110>
     536:      	movzbl	%al, %ebp
     539:      	leaq	0x7(%rsp), %rcx
     53e:      	movq	%rbx, %rdi
     541:      	xorl	%esi, %esi
     543:      	movq	%r14, %rdx
     546:      	movl	%ebp, %r8d
     549:      	callq	0x54e <generic_retuprobe_actions+0xce>
     54e:      	leal	0x4(,%rax,4), %ecx
     555:      	cmpl	(%r14), %ecx
     558:      	jae	0x590 <generic_retuprobe_actions+0x110>
     55a:      	leaq	0x7(%rsp), %rcx
     55f:      	movq	%rbx, %rdi
     562:      	movl	%eax, %esi
     564:      	movq	%r14, %rdx
     567:      	movl	%ebp, %r8d
     56a:      	callq	0x56f <generic_retuprobe_actions+0xef>
     56f:      	leal	0x4(,%rax,4), %ecx
     576:      	cmpl	(%r14), %ecx
     579:      	jae	0x590 <generic_retuprobe_actions+0x110>
     57b:      	leaq	0x7(%rsp), %rcx
     580:      	movq	%rbx, %rdi
     583:      	movl	%eax, %esi
     585:      	movq	%r14, %rdx
     588:      	movl	%ebp, %r8d
     58b:      	callq	0x590 <generic_retuprobe_actions+0x110>
     590:      	cmpb	$0x0, 0x7(%rsp)
     595:      	je	0x5b2 <generic_retuprobe_actions+0x132>
     597:      	movq	(%rip), %rsi            # 0x59e <generic_retuprobe_actions+0x11e>
     59e:      	movl	$0x5, %ecx
     5a3:      	movl	$0xc, %eax
     5a8:      	movq	%rbx, %rdi
     5ab:      	movl	$0x5, %edx
     5b0:      	callq	*%rax
     5b2:      	xorl	%eax, %eax
     5b4:      	addq	$0x10, %rsp
     5b8:      	popq	%rbx
     5b9:      	popq	%r14
     5bb:      	popq	%rbp
     5bc:      	retq
     5bd:      	nopl	(%rax)

00000000000005c0 <generic_retuprobe_output>:
     5c0:      	pushq	%r15
     5c2:      	pushq	%r14
     5c4:      	pushq	%rbx
     5c5:      	subq	$0x10, %rsp
     5c9:      	movq	%rdi, %r14
     5cc:      	movl	$0x0, 0x8(%rsp)
     5d4:      	movq	(%rip), %rdi            # 0x5db <generic_retuprobe_output+0x1b>
     5db:      	leaq	0x8(%rsp), %rsi
     5e0:      	movl	$0x1, %eax
     5e5:      	callq	*%rax
     5e7:      	testq	%rax, %rax
     5ea:      	je	0x6c3 <generic_retuprobe_output+0x103>
     5f0:      	movq	%rax, %rbx
     5f3:      	movl	$0x90, %eax
     5f8:      	addl	0x4(%rbx), %eax
     5fb:      	andl	$0x7fff, %eax           # imm = 0x7FFF
     600:      	cmpl	$0x2328, %eax           # imm = 0x2328
     605:      	movl	$0x2328, %r15d          # imm = 0x2328
     60b:      	cmovbl	%eax, %r15d
     60f:      	movl	$0x0, 0xc(%rsp)
     617:      	movq	(%rip), %rdi            # 0x61e <generic_retuprobe_output+0x5e>
     61e:      	leaq	0xc(%rsp), %rsi
     623:      	movl	$0x1, %eax
     628:      	callq	*%rax
     62a:      	testq	%rax, %rax
     62d:      	je	0x681 <generic_retuprobe_output+0xc1>
     62f:      	cmpb	$0x0, 0x28(%rax)
     633:      	je	0x681 <generic_retuprobe_output+0xc1>
     635:      	movq	(%rip), %rsi            # 0x63c <generic_retuprobe_output+0x7c>
     63c:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     641:      	movl	$0x19, %eax
     646:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     64b:      	movq	%r14, %rdi
     64e:      	movq	%rbx, %rcx
     651:      	movq	%r15, %r8
     654:      	callq	*%rax
     656:      	testq	%rax, %rax
     659:      	js	0x71e <generic_retuprobe_output+0x15e>
     65f:      	movl	$0x0, 0x4(%rsp)
     667:      	movq	(%rip), %rdi            # 0x66e <generic_retuprobe_output+0xae>
     66e:      	leaq	0x4(%rsp), %rsi
     673:      	movl	$0x1, %eax
     678:      	callq	*%rax
     67a:      	testq	%rax, %rax
     67d:      	jne	0x6be <generic_retuprobe_output+0xfe>
     67f:      	jmp	0x6c3 <generic_retuprobe_output+0x103>
     681:      	movq	(%rip), %rdi            # 0x688 <generic_retuprobe_output+0xc8>
     688:      	xorl	%ecx, %ecx
     68a:      	movl	$0x82, %eax
     68f:      	movq	%rbx, %rsi
     692:      	movq	%r15, %rdx
     695:      	xorl	%ecx, %ecx
     697:      	callq	*%rax
     699:      	testq	%rax, %rax
     69c:      	js	0x6cf <generic_retuprobe_output+0x10f>
     69e:      	movl	$0x0, 0x4(%rsp)
     6a6:      	movq	(%rip), %rdi            # 0x6ad <generic_retuprobe_output+0xed>
     6ad:      	leaq	0x4(%rsp), %rsi
     6b2:      	movl	$0x1, %eax
     6b7:      	callq	*%rax
     6b9:      	testq	%rax, %rax
     6bc:      	je	0x6c3 <generic_retuprobe_output+0x103>
     6be:      	lock
     6bf:      	incq	0x8(%rax)
     6c3:      	xorl	%eax, %eax
     6c5:      	addq	$0x10, %rsp
     6c9:      	popq	%rbx
     6ca:      	popq	%r14
     6cc:      	popq	%r15
     6ce:      	retq
     6cf:      	movq	%rax, %rbx
     6d2:      	movl	$0x0, 0x4(%rsp)
     6da:      	movq	(%rip), %rdi            # 0x6e1 <generic_retuprobe_output+0x121>
     6e1:      	leaq	0x4(%rsp), %rsi
     6e6:      	movl	$0x1, %eax
     6eb:      	callq	*%rax
     6ed:      	testq	%rax, %rax
     6f0:      	je	0x6c3 <generic_retuprobe_output+0x103>
     6f2:      	cmpq	$-0xc, %rbx
     6f6:      	jg	0x762 <generic_retuprobe_output+0x1a2>
     6f8:      	cmpq	$-0x1c, %rbx
     6fc:      	je	0x7a4 <generic_retuprobe_output+0x1e4>
     702:      	cmpq	$-0x16, %rbx
     706:      	je	0x753 <generic_retuprobe_output+0x193>
     708:      	cmpq	$-0x10, %rbx
     70c:      	jne	0x795 <generic_retuprobe_output+0x1d5>
     712:      	addq	$0x360, %rax            # imm = 0x360
     718:      	lock
     719:      	incq	(%rax)
     71c:      	jmp	0x6c3 <generic_retuprobe_output+0x103>
     71e:      	movq	%rax, %rbx
     721:      	movl	$0x0, 0x4(%rsp)
     729:      	movq	(%rip), %rdi            # 0x730 <generic_retuprobe_output+0x170>
     730:      	leaq	0x4(%rsp), %rsi
     735:      	movl	$0x1, %eax
     73a:      	callq	*%rax
     73c:      	testq	%rax, %rax
     73f:      	je	0x6c3 <generic_retuprobe_output+0x103>
     741:      	cmpq	$-0xc, %rbx
     745:      	jg	0x783 <generic_retuprobe_output+0x1c3>
     747:      	cmpq	$-0x1c, %rbx
     74b:      	je	0x7a4 <generic_retuprobe_output+0x1e4>
     74d:      	cmpq	$-0x16, %rbx
     751:      	jne	0x708 <generic_retuprobe_output+0x148>
     753:      	addq	$0x368, %rax            # imm = 0x368
     759:      	lock
     75a:      	incq	(%rax)
     75d:      	jmp	0x6c3 <generic_retuprobe_output+0x103>
     762:      	cmpq	$-0xb, %rbx
     766:      	je	0x7b3 <generic_retuprobe_output+0x1f3>
     768:      	cmpq	$-0x7, %rbx
     76c:      	je	0x7c2 <generic_retuprobe_output+0x202>
     76e:      	cmpq	$-0x2, %rbx
     772:      	jne	0x795 <generic_retuprobe_output+0x1d5>
     774:      	addq	$0x350, %rax            # imm = 0x350
     77a:      	lock
     77b:      	incq	(%rax)
     77e:      	jmp	0x6c3 <generic_retuprobe_output+0x103>
     783:      	cmpq	$-0xb, %rbx
     787:      	je	0x7b3 <generic_retuprobe_output+0x1f3>
     789:      	cmpq	$-0x7, %rbx
     78d:      	je	0x7c2 <generic_retuprobe_output+0x202>
     78f:      	cmpq	$-0x2, %rbx
     793:      	je	0x774 <generic_retuprobe_output+0x1b4>
     795:      	addq	$0x348, %rax            # imm = 0x348
     79b:      	lock
     79c:      	incq	(%rax)
     79f:      	jmp	0x6c3 <generic_retuprobe_output+0x103>
     7a4:      	addq	$0x370, %rax            # imm = 0x370
     7aa:      	lock
     7ab:      	incq	(%rax)
     7ae:      	jmp	0x6c3 <generic_retuprobe_output+0x103>
     7b3:      	addq	$0x378, %rax            # imm = 0x378
     7b9:      	lock
     7ba:      	incq	(%rax)
     7bd:      	jmp	0x6c3 <generic_retuprobe_output+0x103>
     7c2:      	addq	$0x358, %rax            # imm = 0x358
     7c8:      	lock
     7c9:      	incq	(%rax)
     7cc:      	jmp	0x6c3 <generic_retuprobe_output+0x103>

Disassembly of section uprobe.multi/generic_retuprobe:

0000000000000000 <generic_retuprobe_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xf8, %rsp
      11:      	movq	%rdi, %r13
      14:      	movq	0x50(%rdi), %r14
      18:      	movl	$0x0, 0xf0(%rsp)
      23:      	movq	(%rip), %rdi            # 0x2a <generic_retuprobe_event+0x2a>
      2a:      	leaq	0xf0(%rsp), %rsi
      32:      	movl	$0x1, %eax
      37:      	callq	*%rax
      39:      	xorl	%ebp, %ebp
      3b:      	testq	%rax, %rax
      3e:      	je	0x31ec <generic_retuprobe_event+0x31ec>
      44:      	movq	%rax, %r15
      47:      	movq	%rax, %rbx
      4a:      	movl	$0xae, %eax
      4f:      	movq	%r13, %rdi
      52:      	callq	*%rax
      54:      	leaq	0x5ef8(%r15), %rsi
      5b:      	movl	%eax, 0x5ef8(%r15)
      62:      	movq	(%rip), %rdi            # 0x69 <generic_retuprobe_event+0x69>
      69:      	movl	$0x1, %eax
      6e:      	callq	*%rax
      70:      	testq	%rax, %rax
      73:      	je	0x31ec <generic_retuprobe_event+0x31ec>
      79:      	movq	%rax, %r12
      7c:      	movl	(%rax), %eax
      7e:      	movq	%rax, 0x60(%rbx)
      82:      	movl	$0xe, %eax
      87:      	callq	*%rax
      89:      	cmpq	$-0x16, %rax
      8d:      	jne	0xae <generic_retuprobe_event+0xae>
      8f:      	leaq	0x20(%r13), %rdx
      93:      	leaq	0x38(%rsp), %rdi
      98:      	movl	$0x8, %ecx
      9d:      	movl	$0x4, %eax
      a2:      	movl	$0x8, %esi
      a7:      	callq	*%rax
      a9:      	movq	0x38(%rsp), %rax
      ae:      	movq	%rax, 0x68(%rbx)
      b2:      	movl	$0xe, %eax
      b7:      	callq	*%rax
      b9:      	movl	%eax, 0x7c(%rbx)
      bc:      	movq	0x60(%rbx), %rax
      c0:      	movq	0x68(%rbx), %rcx
      c4:      	movq	%rax, 0x38(%rsp)
      c9:      	movq	%rcx, 0x40(%rsp)
      ce:      	movq	(%rip), %rdi            # 0xd5 <generic_retuprobe_event+0xd5>
      d5:      	leaq	0x38(%rsp), %rsi
      da:      	movl	$0x1, %eax
      df:      	callq	*%rax
      e1:      	testq	%rax, %rax
      e4:      	je	0x31ec <generic_retuprobe_event+0x31ec>
      ea:      	movq	%r14, 0x8(%rsp)
      ef:      	movq	(%rax), %r14
      f2:      	movq	0x8(%rax), %rbp
      f6:      	movq	0x10(%rax), %rax
      fa:      	movq	%rax, 0xb8(%rsp)
     102:      	movq	(%rip), %rdi            # 0x109 <generic_retuprobe_event+0x109>
     109:      	leaq	0x38(%rsp), %rsi
     10e:      	movl	$0x3, %eax
     113:      	callq	*%rax
     115:      	movq	%r14, 0x90(%rbx)
     11c:      	movl	0x58(%r12), %eax
     121:      	movl	0x5c(%r12), %r14d
     126:      	testl	%r14d, %r14d
     129:      	je	0x199 <generic_retuprobe_event+0x199>
     12b:      	movl	%eax, 0x28(%rsp)
     12f:      	movl	$0x0, 0x5ea0(%rbx)
     139:      	movl	$0x0, 0xf4(%rsp)
     144:      	movq	(%rip), %rdi            # 0x14b <generic_retuprobe_event+0x14b>
     14b:      	leaq	0xf4(%rsp), %rsi
     153:      	movl	$0x1, %eax
     158:      	callq	*%rax
     15a:      	testq	%rax, %rax
     15d:      	je	0x29c <generic_retuprobe_event+0x29c>
     163:      	movq	%rax, %rcx
     166:      	movl	0x5ea0(%rax), %eax
     16c:      	movl	%eax, 0x98(%rcx)
     172:      	movq	$0xc, 0x5e78(%rcx)
     17d:      	testl	%eax, %eax
     17f:      	je	0x2ad <generic_retuprobe_event+0x2ad>
     185:      	movq	0x8(%rsp), %r8
     18a:      	movl	$0x4, %r14d
     190:      	movl	0x28(%rsp), %eax
     194:      	jmp	0x2eb4 <generic_retuprobe_event+0x2eb4>
     199:      	movl	$0x8, %r14d
     19f:      	movq	0x8(%rsp), %r8
     1a4:      	addq	$0x90, %r15
     1ab:      	cmpl	$0x3, %eax
     1ae:      	jne	0x2ecf <generic_retuprobe_event+0x2ecf>
     1b4:      	movq	%r14, %rax
     1b7:      	movl	$0x0, (%r15,%r14)
     1bf:      	leaq	0x4(%r14), %rax
     1c3:      	cmpq	$0x0, 0xb8(%rsp)
     1cc:      	movq	%r13, 0xc8(%rsp)
     1d4:      	movq	%r12, 0xa8(%rsp)
     1dc:      	je	0x31e <generic_retuprobe_event+0x31e>
     1e2:      	movq	%rax, 0x28(%rsp)
     1e7:      	leaq	0x38(%rsp), %rdi
     1ec:      	movl	$0x4, %r12d
     1f2:      	movl	$0x10, %ecx
     1f7:      	movl	$0x4, %eax
     1fc:      	movl	$0x10, %esi
     201:      	movq	%rbp, %rdx
     204:      	callq	*%rax
     206:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     20b:      	testl	%eax, %eax
     20d:      	js	0xbc3 <generic_retuprobe_event+0xbc3>
     213:      	movq	%rbp, 0x88(%rsp)
     21b:      	movq	0x40(%rsp), %r13
     220:      	movq	0x8(%rsp), %rax
     225:      	cmpq	%rax, %r13
     228:      	movq	%rax, %rbp
     22b:      	cmovbq	%r13, %rbp
     22f:      	testq	%rax, %rax
     232:      	cmovneq	%rbp, %r13
     236:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
     23b:      	cmpq	$0xffe, %r13            # imm = 0xFFE
     242:      	ja	0xbc3 <generic_retuprobe_event+0xbc3>
     248:      	addq	$0xc, %r14
     24c:      	movq	%r14, 0x20(%rsp)
     251:      	leaq	(%r15,%r14), %rdi
     255:      	movq	0x38(%rsp), %rcx
     25a:      	movl	$0x4, %eax
     25f:      	movq	0x38(%rsp), %rdx
     264:      	movl	%r13d, %esi
     267:      	callq	*%rax
     269:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     26e:      	testl	%eax, %eax
     270:      	js	0xbc3 <generic_retuprobe_event+0xbc3>
     276:      	movq	0x8(%rsp), %rax
     27b:      	testq	%rax, %rax
     27e:      	je	0xaf8 <generic_retuprobe_event+0xaf8>
     284:      	subq	%rbp, %rax
     287:      	movq	%rax, 0x8(%rsp)
     28c:      	movq	0x28(%rsp), %rax
     291:      	jne	0xb04 <generic_retuprobe_event+0xb04>
     297:      	jmp	0x320 <generic_retuprobe_event+0x320>
     29c:      	xorl	%r14d, %r14d
     29f:      	movq	0x8(%rsp), %r8
     2a4:      	movl	0x28(%rsp), %eax
     2a8:      	jmp	0x2eb4 <generic_retuprobe_event+0x2eb4>
     2ad:      	leaq	0x9c(%rcx), %rdx
     2b4:      	movq	0x8(%rsp), %rax
     2b9:      	movq	%rax, 0x38(%rsp)
     2be:      	movq	$0x0, 0x78(%rsp)
     2c7:      	cmpl	$0x17, %r14d
     2cb:      	movq	%rcx, (%rsp)
     2cf:      	movq	%r15, 0x20(%rsp)
     2d4:      	movq	%r13, 0xc8(%rsp)
     2dc:      	jle	0x335 <generic_retuprobe_event+0x335>
     2de:      	cmpl	$0x18, %r14d
     2e2:      	je	0x350 <generic_retuprobe_event+0x350>
     2e4:      	cmpl	$0x25, %r14d
     2e8:      	je	0x393 <generic_retuprobe_event+0x393>
     2ee:      	cmpl	$0x2a, %r14d
     2f2:      	jne	0xa35 <generic_retuprobe_event+0xa35>
     2f8:      	movq	$0x0, 0x90(%rsp)
     304:      	movq	0x8(%rsp), %rax
     309:      	movq	%rax, 0x98(%rsp)
     311:      	leaq	0x90(%rsp), %rax
     319:      	jmp	0x3c5 <generic_retuprobe_event+0x3c5>
     31e:      	xorl	%ebp, %ebp
     320:      	movl	%ebp, (%r15,%rax)
     324:      	movl	%ebp, 0x4(%r15,%rax)
     329:      	addq	$0x8, %rbp
     32d:      	movq	%rbp, %r12
     330:      	jmp	0xbcc <generic_retuprobe_event+0xbcc>
     335:      	cmpl	$0xf, %r14d
     339:      	je	0x96c <generic_retuprobe_event+0x96c>
     33f:      	cmpl	$0x10, %r14d
     343:      	jne	0xa35 <generic_retuprobe_event+0xa35>
     349:      	leaq	0x18(%rsp), %r14
     34e:      	jmp	0x37d <generic_retuprobe_event+0x37d>
     350:      	leaq	0x18(%rsp), %r14
     355:      	movl	$0x8, %ecx
     35a:      	movl	$0x4, %eax
     35f:      	movq	0x8(%rsp), %rdx
     364:      	movq	0x38(%rsp), %rdx
     369:      	movq	%r14, %rdi
     36c:      	movl	$0x8, %esi
     371:      	callq	*%rax
     373:      	movq	0x18(%rsp), %rax
     378:      	movq	%rax, 0x38(%rsp)
     37d:      	leaq	0x38(%rsp), %rdx
     382:      	movl	$0x8, %ecx
     387:      	movl	$0x4, %eax
     38c:      	leaq	0x18(%rsp), %rdi
     391:      	jmp	0x3b5 <generic_retuprobe_event+0x3b5>
     393:      	movq	0x8(%rsp), %rax
     398:      	leaq	0x40(%rax), %rcx
     39c:      	movq	%rcx, 0x38(%rsp)
     3a1:      	leaq	0x18(%rsp), %rdi
     3a6:      	movl	$0x8, %edx
     3ab:      	movl	$0x4, %eax
     3b0:      	movq	0x38(%rsp), %rdx
     3b5:      	movl	$0x8, %esi
     3ba:      	callq	*%rax
     3bc:      	movq	0x18(%rsp), %rax
     3c1:      	addq	$0x40, %rax
     3c5:      	movq	%rax, 0xa0(%rsp)
     3cd:      	movl	$0x0, 0xc4(%rsp)
     3d8:      	movq	(%rip), %rdi            # 0x3df <generic_retuprobe_event+0x3df>
     3df:      	leaq	0xc4(%rsp), %rsi
     3e7:      	movl	$0x1, %eax
     3ec:      	callq	*%rax
     3ee:      	testq	%rax, %rax
     3f1:      	je	0x4b2 <generic_retuprobe_event+0x4b2>
     3f7:      	movq	%rax, %r13
     3fa:      	movq	%rbp, 0x88(%rsp)
     402:      	movq	%r12, 0xa8(%rsp)
     40a:      	addq	$0x1000, %rax           # imm = 0x1000
     410:      	movq	%rax, 0x10(%rsp)
     415:      	movl	$0x23, %eax
     41a:      	callq	*%rax
     41c:      	leaq	0xd50(%rax), %rdx
     423:      	leaq	0xd0(%rsp), %rdi
     42b:      	movl	$0x8, %ecx
     430:      	movl	$0x4, %eax
     435:      	movl	$0x8, %esi
     43a:      	callq	*%rax
     43c:      	movq	0xd0(%rsp), %r12
     444:      	movq	0xa0(%rsp), %rax
     44c:      	leaq	0x8(%rax), %rdx
     450:      	leaq	0xd8(%rsp), %rdi
     458:      	movl	$0x8, %ecx
     45d:      	movl	$0x4, %eax
     462:      	leaq	0x18(%r12), %rcx
     467:      	movq	%rcx, 0xe8(%rsp)
     46f:      	movl	$0x8, %esi
     474:      	movq	%rdx, 0x30(%rsp)
     479:      	callq	*%rax
     47b:      	movq	0xd8(%rsp), %rbp
     483:      	leaq	0x10(%rbp), %rdx
     487:      	leaq	0x38(%rsp), %rdi
     48c:      	movl	$0x8, %ecx
     491:      	movl	$0x4, %eax
     496:      	movl	$0x8, %esi
     49b:      	callq	*%rax
     49d:      	cmpq	$0x0, 0x38(%rsp)
     4a3:      	movl	$0x1000, %r14d          # imm = 0x1000
     4a9:      	je	0x4bf <generic_retuprobe_event+0x4bf>
     4ab:      	movq	0x10(%rsp), %rcx
     4b0:      	jmp	0x510 <generic_retuprobe_event+0x510>
     4b2:      	xorl	%r13d, %r13d
     4b5:      	movq	0x8(%rsp), %r8
     4ba:      	jmp	0xd16 <generic_retuprobe_event+0xd16>
     4bf:      	leaq	0x18(%rbp), %rdx
     4c3:      	leaq	0x38(%rsp), %rdi
     4c8:      	movl	$0x8, %ecx
     4cd:      	movl	$0x4, %eax
     4d2:      	movl	$0x8, %esi
     4d7:      	callq	*%rax
     4d9:      	cmpq	%rbp, 0x38(%rsp)
     4de:      	movq	0x10(%rsp), %rcx
     4e3:      	je	0x510 <generic_retuprobe_event+0x510>
     4e5:      	movq	%r13, %rcx
     4e8:      	addq	$0xff6, %rcx            # imm = 0xFF6
     4ef:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
     4f9:      	movq	%rax, 0xff6(%r13)
     500:      	movw	$0x2964, 0xffe(%r13)    # imm = 0x2964
     50a:      	movl	$0xff6, %r14d           # imm = 0xFF6
     510:      	movq	$0x0, 0x40(%rsp)
     519:      	movq	$0x0, 0x38(%rsp)
     522:      	movq	%r13, 0x48(%rsp)
     527:      	movq	$0x0, 0x50(%rsp)
     530:      	movq	$0x0, 0x58(%rsp)
     539:      	movq	$0x0, 0x60(%rsp)
     542:      	movq	%rcx, 0x10(%rsp)
     547:      	movq	%rcx, 0x68(%rsp)
     54c:      	movl	%r14d, 0x70(%rsp)
     551:      	movb	$0x0, 0x74(%rsp)
     556:      	addq	$0x20, %r12
     55a:      	leaq	0x38(%rsp), %rdi
     55f:      	movl	$0x8, %ecx
     564:      	movl	$0x4, %eax
     569:      	leaq	0x40(%rsp), %r13
     56e:      	leaq	0x50(%rsp), %rbp
     573:      	leaq	0x58(%rsp), %r14
     578:      	movl	$0x8, %esi
     57d:      	movq	%r12, %rdx
     580:      	callq	*%rax
     582:      	movl	$0x8, %ecx
     587:      	movl	$0x4, %eax
     58c:      	movq	0xe8(%rsp), %rdx
     594:      	movq	%r13, %rdi
     597:      	movl	$0x8, %esi
     59c:      	callq	*%rax
     59e:      	movl	$0x8, %ecx
     5a3:      	movl	$0x4, %eax
     5a8:      	movq	0x30(%rsp), %rdx
     5ad:      	movq	%rbp, %rdi
     5b0:      	movl	$0x8, %esi
     5b5:      	callq	*%rax
     5b7:      	movl	$0x8, %ecx
     5bc:      	movl	$0x4, %eax
     5c1:      	movq	0xa0(%rsp), %rdx
     5c9:      	movq	%r14, %rdi
     5cc:      	movl	$0x8, %esi
     5d1:      	callq	*%rax
     5d3:      	movq	0x58(%rsp), %rax
     5d8:      	addq	$-0x20, %rax
     5dc:      	movq	%rax, 0x60(%rsp)
     5e1:      	movq	(%rip), %rax            # 0x5e8 <generic_retuprobe_event+0x5e8>
     5e8:      	cmpb	$0x0, (%rax)
     5eb:      	je	0x7b5 <generic_retuprobe_event+0x7b5>
     5f1:      	movl	$0x800, %r13d           # imm = 0x800
     5f7:      	movl	$0x8, %ebp
     5fc:      	movq	0x50(%rsp), %r14
     601:      	movq	0x58(%rsp), %rdx
     606:      	movq	0x60(%rsp), %r12
     60b:      	cmpq	0x38(%rsp), %r14
     610:      	jne	0x61d <generic_retuprobe_event+0x61d>
     612:      	cmpq	0x40(%rsp), %rdx
     617:      	je	0xaee <generic_retuprobe_event+0xaee>
     61d:      	movl	$0x4, %eax
     622:      	leaq	0xb0(%rsp), %rdi
     62a:      	movl	$0x8, %esi
     62f:      	callq	*%rax
     631:      	cmpq	0xb0(%rsp), %r14
     639:      	movl	$0x8, %r15d
     63f:      	je	0x74c <generic_retuprobe_event+0x74c>
     645:      	leaq	0x18(%r14), %rbp
     649:      	movl	$0x4, %eax
     64e:      	leaq	0x18(%rsp), %rdi
     653:      	movl	$0x8, %esi
     658:      	movq	%rbp, %rdx
     65b:      	callq	*%rax
     65d:      	cmpq	%r14, 0x18(%rsp)
     662:      	je	0x74c <generic_retuprobe_event+0x74c>
     668:      	movl	$0x4, %eax
     66d:      	leaq	0xe0(%rsp), %rdi
     675:      	movl	$0x8, %esi
     67a:      	movq	%rbp, %rdx
     67d:      	callq	*%rax
     67f:      	addq	$0x20, %r14
     683:      	movl	$0x4, %eax
     688:      	leaq	0x78(%rsp), %rdi
     68d:      	movl	$0x10, %ecx
     692:      	movl	$0x10, %esi
     697:      	movq	%r14, %rdx
     69a:      	callq	*%rax
     69c:      	movq	0x48(%rsp), %r14
     6a1:      	movq	0x68(%rsp), %rax
     6a6:      	movl	0x7c(%rsp), %ebp
     6aa:      	subq	%r14, %rax
     6ad:      	movl	0x70(%rsp), %r12d
     6b2:      	movl	%ebp, %edx
     6b4:      	subl	%r12d, %edx
     6b7:      	movl	$0x0, %ecx
     6bc:      	cmovbl	%ecx, %edx
     6bf:      	addq	0x80(%rsp), %rdx
     6c7:      	xorl	%esi, %esi
     6c9:      	cmpl	%ebp, %r12d
     6cc:      	seta	%sil
     6d0:      	movl	%ebp, %ecx
     6d2:      	cmovbl	%r12d, %ecx
     6d6:      	addl	%ecx, %esi
     6d8:      	movl	%r12d, %edi
     6db:      	subl	%esi, %edi
     6dd:      	movl	%edi, 0x70(%rsp)
     6e1:      	subq	%rsi, %rax
     6e4:      	movq	0x20(%rsp), %r15
     6e9:      	jb	0xbfc <generic_retuprobe_event+0xbfc>
     6ef:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     6f5:      	ja	0xbfc <generic_retuprobe_event+0xbfc>
     6fb:      	cmpl	%ebp, %r12d
     6fe:      	jbe	0x705 <generic_retuprobe_event+0x705>
     700:      	movb	$0x2f, (%r14,%rax)
     705:      	xorl	%edi, %edi
     707:      	cmpl	%ebp, %r12d
     70a:      	seta	%dil
     70e:      	movzbl	%cl, %esi
     711:      	addq	%rax, %r14
     714:      	addq	%r14, %rdi
     717:      	movl	$0x4, %eax
     71c:      	callq	*%rax
     71e:      	movq	%r14, 0x68(%rsp)
     723:      	cmpl	%ebp, %r12d
     726:      	jbe	0xbfc <generic_retuprobe_event+0xbfc>
     72c:      	movq	0xe0(%rsp), %rax
     734:      	movq	%rax, 0x50(%rsp)
     739:      	movl	$0x8, %ebp
     73e:      	decl	%r13d
     741:      	jne	0x5fc <generic_retuprobe_event+0x5fc>
     747:      	jmp	0xbfc <generic_retuprobe_event+0xbfc>
     74c:      	leaq	0x10(%r12), %rdx
     751:      	movl	$0x4, %eax
     756:      	leaq	0x18(%rsp), %rdi
     75b:      	movl	$0x8, %esi
     760:      	callq	*%rax
     762:      	movq	0x60(%rsp), %rax
     767:      	cmpq	0x18(%rsp), %rax
     76c:      	movl	$0x8, %ebp
     771:      	je	0xbf2 <generic_retuprobe_event+0xbf2>
     777:      	addq	$0x18, %r12
     77b:      	movl	$0x4, %eax
     780:      	leaq	0x50(%rsp), %rdi
     785:      	movl	$0x8, %esi
     78a:      	movq	%r12, %rdx
     78d:      	callq	*%rax
     78f:      	movq	0x18(%rsp), %rax
     794:      	movq	%rax, 0x60(%rsp)
     799:      	addq	$0x20, %rax
     79d:      	movq	%rax, 0x58(%rsp)
     7a2:      	movq	0x20(%rsp), %r15
     7a7:      	decl	%r13d
     7aa:      	jne	0x5fc <generic_retuprobe_event+0x5fc>
     7b0:      	jmp	0xbfc <generic_retuprobe_event+0xbfc>
     7b5:      	movl	$0x800, %r13d           # imm = 0x800
     7bb:      	movl	$0x8, %ebp
     7c0:      	jmp	0x7cb <generic_retuprobe_event+0x7cb>
     7c2:      	decl	%r13d
     7c5:      	je	0xbfc <generic_retuprobe_event+0xbfc>
     7cb:      	movq	0x50(%rsp), %r14
     7d0:      	movq	0x58(%rsp), %rdx
     7d5:      	movq	0x60(%rsp), %r12
     7da:      	cmpq	0x38(%rsp), %r14
     7df:      	jne	0x7ec <generic_retuprobe_event+0x7ec>
     7e1:      	cmpq	0x40(%rsp), %rdx
     7e6:      	je	0xaee <generic_retuprobe_event+0xaee>
     7ec:      	movl	$0x4, %eax
     7f1:      	leaq	0xb0(%rsp), %rdi
     7f9:      	movl	$0x8, %esi
     7fe:      	callq	*%rax
     800:      	cmpq	0xb0(%rsp), %r14
     808:      	movl	$0x8, %ecx
     80d:      	je	0x911 <generic_retuprobe_event+0x911>
     813:      	leaq	0x18(%r14), %rbp
     817:      	movl	$0x4, %eax
     81c:      	leaq	0x18(%rsp), %rdi
     821:      	movl	$0x8, %esi
     826:      	movq	%rbp, %rdx
     829:      	callq	*%rax
     82b:      	movl	$0x8, %ecx
     830:      	cmpq	%r14, 0x18(%rsp)
     835:      	je	0x911 <generic_retuprobe_event+0x911>
     83b:      	movl	$0x4, %eax
     840:      	leaq	0xe0(%rsp), %rdi
     848:      	movl	$0x8, %esi
     84d:      	movq	%rbp, %rdx
     850:      	callq	*%rax
     852:      	addq	$0x20, %r14
     856:      	movl	$0x4, %eax
     85b:      	leaq	0x78(%rsp), %rdi
     860:      	movl	$0x10, %ecx
     865:      	movl	$0x10, %esi
     86a:      	movq	%r14, %rdx
     86d:      	callq	*%rax
     86f:      	movq	0x48(%rsp), %r14
     874:      	movq	0x68(%rsp), %rax
     879:      	movl	0x7c(%rsp), %ebp
     87d:      	subq	%r14, %rax
     880:      	movl	0x70(%rsp), %r12d
     885:      	movl	%ebp, %edx
     887:      	subl	%r12d, %edx
     88a:      	movl	$0x0, %ecx
     88f:      	cmovbl	%ecx, %edx
     892:      	addq	0x80(%rsp), %rdx
     89a:      	xorl	%esi, %esi
     89c:      	cmpl	%ebp, %r12d
     89f:      	seta	%sil
     8a3:      	movl	%ebp, %ecx
     8a5:      	cmovbl	%r12d, %ecx
     8a9:      	addl	%ecx, %esi
     8ab:      	movl	%r12d, %edi
     8ae:      	subl	%esi, %edi
     8b0:      	movl	%edi, 0x70(%rsp)
     8b4:      	subq	%rsi, %rax
     8b7:      	jb	0xbfc <generic_retuprobe_event+0xbfc>
     8bd:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     8c3:      	ja	0xbfc <generic_retuprobe_event+0xbfc>
     8c9:      	cmpl	%ebp, %r12d
     8cc:      	jbe	0x8d3 <generic_retuprobe_event+0x8d3>
     8ce:      	movb	$0x2f, (%r14,%rax)
     8d3:      	xorl	%edi, %edi
     8d5:      	cmpl	%ebp, %r12d
     8d8:      	seta	%dil
     8dc:      	movzbl	%cl, %esi
     8df:      	addq	%rax, %r14
     8e2:      	addq	%r14, %rdi
     8e5:      	movl	$0x4, %eax
     8ea:      	callq	*%rax
     8ec:      	movq	%r14, 0x68(%rsp)
     8f1:      	cmpl	%ebp, %r12d
     8f4:      	jbe	0xbfc <generic_retuprobe_event+0xbfc>
     8fa:      	movq	0xe0(%rsp), %rax
     902:      	movq	%rax, 0x50(%rsp)
     907:      	movl	$0x8, %ebp
     90c:      	jmp	0x7c2 <generic_retuprobe_event+0x7c2>
     911:      	leaq	0x10(%r12), %rdx
     916:      	movl	$0x4, %eax
     91b:      	leaq	0x18(%rsp), %rdi
     920:      	movl	$0x8, %esi
     925:      	callq	*%rax
     927:      	movq	0x60(%rsp), %rax
     92c:      	cmpq	0x18(%rsp), %rax
     931:      	movl	$0x8, %ebp
     936:      	je	0xaee <generic_retuprobe_event+0xaee>
     93c:      	addq	$0x18, %r12
     940:      	movl	$0x4, %eax
     945:      	leaq	0x50(%rsp), %rdi
     94a:      	movl	$0x8, %esi
     94f:      	movq	%r12, %rdx
     952:      	callq	*%rax
     954:      	movq	0x18(%rsp), %rax
     959:      	movq	%rax, 0x60(%rsp)
     95e:      	addq	$0x20, %rax
     962:      	movq	%rax, 0x58(%rsp)
     967:      	jmp	0x7c2 <generic_retuprobe_event+0x7c2>
     96c:      	movq	%rdx, 0x30(%rsp)
     971:      	leaq	0x78(%rsp), %rdi
     976:      	leaq	0x38(%rsp), %rdx
     97b:      	movl	$0x8, %ecx
     980:      	movl	$0x4, %eax
     985:      	movl	$0x8, %esi
     98a:      	callq	*%rax
     98c:      	movq	0x78(%rsp), %rax
     991:      	movq	%rax, 0xa0(%rsp)
     999:      	testq	%rax, %rax
     99c:      	jne	0x3cd <generic_retuprobe_event+0x3cd>
     9a2:      	movl	$0x0, 0x90(%rsp)
     9ad:      	movq	(%rip), %rdi            # 0x9b4 <generic_retuprobe_event+0x9b4>
     9b4:      	leaq	0x90(%rsp), %rsi
     9bc:      	movl	$0x1, %eax
     9c1:      	callq	*%rax
     9c3:      	xorl	%r13d, %r13d
     9c6:      	testq	%rax, %rax
     9c9:      	je	0xea0 <generic_retuprobe_event+0xea0>
     9cf:      	cmpl	$0x19, %r14d
     9d3:      	movq	(%rsp), %rcx
     9d7:      	jg	0xf66 <generic_retuprobe_event+0xf66>
     9dd:      	cmpl	$0x12, %r14d
     9e1:      	movq	0x30(%rsp), %rdi
     9e6:      	jle	0x10c6 <generic_retuprobe_event+0x10c6>
     9ec:      	cmpl	$0x14, %r14d
     9f0:      	jle	0x1409 <generic_retuprobe_event+0x1409>
     9f6:      	cmpl	$0x15, %r14d
     9fa:      	je	0x1e4d <generic_retuprobe_event+0x1e4d>
     a00:      	cmpl	$0x16, %r14d
     a04:      	je	0x1db5 <generic_retuprobe_event+0x1db5>
     a0a:      	cmpl	$0x17, %r14d
     a0e:      	movq	0x8(%rsp), %r8
     a13:      	jne	0x2e71 <generic_retuprobe_event+0x2e71>
     a19:      	movl	$0x0, 0xa0(%rcx)
     a23:      	movl	%r8d, 0x9c(%rcx)
     a2a:      	movl	$0x8, %r13d
     a30:      	jmp	0x2e71 <generic_retuprobe_event+0x2e71>
     a35:      	movq	%rdx, 0x30(%rsp)
     a3a:      	cmpl	$0x2c, %r14d
     a3e:      	ja	0x9a2 <generic_retuprobe_event+0x9a2>
     a44:      	movl	%r14d, %eax
     a47:      	movabsq	$0x11c1f2027cf2, %rcx   # imm = 0x11C1F2027CF2
     a51:      	btq	%rax, %rcx
     a55:      	jae	0x9a2 <generic_retuprobe_event+0x9a2>
     a5b:      	movq	0x8(%rsp), %rax
     a60:      	movq	%rax, 0x18(%rsp)
     a65:      	movl	$0x0, 0xe0(%rsp)
     a70:      	movq	(%rip), %rdi            # 0xa77 <generic_retuprobe_event+0xa77>
     a77:      	leaq	0xe0(%rsp), %rsi
     a7f:      	movl	$0x1, %eax
     a84:      	callq	*%rax
     a86:      	testq	%rax, %rax
     a89:      	movq	%rbp, 0x88(%rsp)
     a91:      	je	0xbe7 <generic_retuprobe_event+0xbe7>
     a97:      	xorl	%r13d, %r13d
     a9a:      	cmpl	$0x10, %r14d
     a9e:      	jle	0xd1f <generic_retuprobe_event+0xd1f>
     aa4:      	cmpl	$0x1e, %r14d
     aa8:      	movq	0x30(%rsp), %rdi
     aad:      	movq	%r12, %rbp
     ab0:      	jle	0xeaa <generic_retuprobe_event+0xeaa>
     ab6:      	cmpl	$0x26, %r14d
     aba:      	jg	0xfa4 <generic_retuprobe_event+0xfa4>
     ac0:      	leal	-0x1f(%r14), %eax
     ac4:      	cmpl	$0x2, %eax
     ac7:      	jae	0x14f1 <generic_retuprobe_event+0x14f1>
     acd:      	leaq	0x18(%rsp), %rdx
     ad2:      	movl	$0x4, %r13d
     ad8:      	movl	$0x1, %ecx
     add:      	movl	$0x4, %eax
     ae2:      	movl	$0x1, %esi
     ae7:      	callq	*%rax
     ae9:      	jmp	0x2e5d <generic_retuprobe_event+0x2e5d>
     aee:      	movb	$0x1, 0x74(%rsp)
     af3:      	jmp	0xbfc <generic_retuprobe_event+0xbfc>
     af8:      	xorl	%eax, %eax
     afa:      	movq	%rax, 0x8(%rsp)
     aff:      	movq	0x28(%rsp), %rax
     b04:      	cmpq	$0x1, 0xb8(%rsp)
     b0d:      	jne	0xb17 <generic_retuprobe_event+0xb17>
     b0f:      	movq	%r13, %rbp
     b12:      	jmp	0x320 <generic_retuprobe_event+0x320>
     b17:      	movq	0x88(%rsp), %rax
     b1f:      	leaq	0x10(%rax), %rdx
     b23:      	leaq	0x38(%rsp), %rdi
     b28:      	movl	$0x4, %r12d
     b2e:      	movl	$0x10, %ecx
     b33:      	movl	$0x4, %eax
     b38:      	movl	$0x10, %esi
     b3d:      	callq	*%rax
     b3f:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     b44:      	testl	%eax, %eax
     b46:      	js	0xbc3 <generic_retuprobe_event+0xbc3>
     b48:      	movq	0x40(%rsp), %r14
     b4d:      	movq	0x8(%rsp), %rax
     b52:      	cmpq	%rax, %r14
     b55:      	movq	%rax, %rbp
     b58:      	cmovbq	%r14, %rbp
     b5c:      	testq	%rax, %rax
     b5f:      	cmovneq	%rbp, %r14
     b63:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
     b68:      	cmpq	$0xffe, %r14            # imm = 0xFFE
     b6f:      	ja	0xbc3 <generic_retuprobe_event+0xbc3>
     b71:      	movq	0x20(%rsp), %rax
     b76:      	addq	%r13, %rax
     b79:      	movq	%rax, 0x20(%rsp)
     b7e:      	leaq	(%r15,%rax), %rdi
     b82:      	movq	0x38(%rsp), %rcx
     b87:      	movl	$0x4, %eax
     b8c:      	movq	0x38(%rsp), %rdx
     b91:      	movl	%r14d, %esi
     b94:      	callq	*%rax
     b96:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     b9b:      	testl	%eax, %eax
     b9d:      	js	0xbc3 <generic_retuprobe_event+0xbc3>
     b9f:      	addq	%r14, %r13
     ba2:      	movq	0x8(%rsp), %rax
     ba7:      	testq	%rax, %rax
     baa:      	je	0x19ab <generic_retuprobe_event+0x19ab>
     bb0:      	subq	%rbp, %rax
     bb3:      	movq	%rax, 0x8(%rsp)
     bb8:      	jne	0x19b2 <generic_retuprobe_event+0x19b2>
     bbe:      	jmp	0x1a82 <generic_retuprobe_event+0x1a82>
     bc3:      	movq	0x28(%rsp), %rax
     bc8:      	movl	%ecx, (%r15,%rax)
     bcc:      	addq	%rax, %r12
     bcf:      	movq	%r12, %rbp
     bd2:      	movq	0xc8(%rsp), %r13
     bda:      	movq	0xa8(%rsp), %r12
     be2:      	jmp	0x2f53 <generic_retuprobe_event+0x2f53>
     be7:      	movq	%r12, %rbp
     bea:      	xorl	%r13d, %r13d
     bed:      	jmp	0x2e5d <generic_retuprobe_event+0x2e5d>
     bf2:      	movb	$0x1, 0x74(%rsp)
     bf7:      	movq	0x20(%rsp), %r15
     bfc:      	movq	0x68(%rsp), %rax
     c01:      	movq	0x10(%rsp), %rdx
     c06:      	xorl	%ebp, %ebp
     c08:      	cmpq	%rdx, %rax
     c0b:      	je	0xc48 <generic_retuprobe_event+0xc48>
     c0d:      	cmpb	$0x0, 0x74(%rsp)
     c12:      	sete	%cl
     c15:      	movl	0x70(%rsp), %edx
     c19:      	movl	$0x1000, %r13d          # imm = 0x1000
     c1f:      	subl	%edx, %r13d
     c22:      	testl	%edx, %edx
     c24:      	cmovlel	%edx, %r13d
     c28:      	testq	%rax, %rax
     c2b:      	movq	0xa8(%rsp), %r12
     c33:      	movq	0x8(%rsp), %r8
     c38:      	je	0xd0b <generic_retuprobe_event+0xd0b>
     c3e:      	movb	%cl, %bpl
     c41:      	addl	%ebp, %ebp
     c43:      	movq	%rax, %rdx
     c46:      	jmp	0xc53 <generic_retuprobe_event+0xc53>
     c48:      	xorl	%r13d, %r13d
     c4b:      	movq	0xa8(%rsp), %r12
     c53:      	movq	(%rsp), %r14
     c57:      	movq	%r14, %rdi
     c5a:      	addq	$0xa0, %rdi
     c61:      	andl	$0xfff, %r13d           # imm = 0xFFF
     c68:      	movl	$0x4, %eax
     c6d:      	movl	%r13d, %esi
     c70:      	callq	*%rax
     c72:      	movl	%r13d, 0x9c(%r14)
     c79:      	leaq	0x38(%rsp), %rdi
     c7e:      	movl	$0x8, %ecx
     c83:      	movl	$0x4, %eax
     c88:      	movq	0x30(%rsp), %rdx
     c8d:      	movl	$0x8, %esi
     c92:      	callq	*%rax
     c94:      	movq	0x38(%rsp), %rcx
     c99:      	addq	$0x30, %rcx
     c9d:      	leaq	0x78(%rsp), %rdi
     ca2:      	movl	$0x8, %edx
     ca7:      	movl	$0x4, %eax
     cac:      	movq	0x38(%rsp), %rdx
     cb1:      	addq	$0x30, %rdx
     cb5:      	movl	$0x8, %esi
     cba:      	callq	*%rax
     cbc:      	movq	0x78(%rsp), %rcx
     cc1:      	leaq	0x18(%rsp), %rdi
     cc6:      	movl	$0x2, %edx
     ccb:      	movl	$0x4, %eax
     cd0:      	movq	0x78(%rsp), %rdx
     cd5:      	movl	$0x2, %esi
     cda:      	callq	*%rax
     cdc:      	movq	%r14, %rcx
     cdf:      	movl	%ebp, 0xa0(%r14,%r13)
     ce7:      	movzwl	0x18(%rsp), %eax
     cec:      	movw	%ax, 0xa4(%r14,%r13)
     cf5:      	addl	$0xa, %r13d
     cf9:      	movq	0x88(%rsp), %rbp
     d01:      	movq	0x8(%rsp), %r8
     d06:      	jmp	0x2e71 <generic_retuprobe_event+0x2e71>
     d0b:      	xorl	%r13d, %r13d
     d0e:      	movq	0x88(%rsp), %rbp
     d16:      	movl	0x28(%rsp), %eax
     d1a:      	jmp	0x2e7a <generic_retuprobe_event+0x2e7a>
     d1f:      	movq	%r12, %rbp
     d22:      	cmpl	$0x9, %r14d
     d26:      	movq	0x30(%rsp), %rdi
     d2b:      	jg	0xedb <generic_retuprobe_event+0xedb>
     d31:      	cmpl	$0x4, %r14d
     d35:      	movq	(%rsp), %rcx
     d39:      	jle	0x1120 <generic_retuprobe_event+0x1120>
     d3f:      	cmpl	$0x5, %r14d
     d43:      	je	0x16f7 <generic_retuprobe_event+0x16f7>
     d49:      	cmpl	$0x6, %r14d
     d4d:      	je	0xf43 <generic_retuprobe_event+0xf43>
     d53:      	movq	%rax, 0x10(%rsp)
     d58:      	cmpl	$0x7, %r14d
     d5c:      	jne	0x2e61 <generic_retuprobe_event+0x2e61>
     d62:      	movq	0x18(%rsp), %r13
     d67:      	movq	%r13, 0xc4(%rcx)
     d6e:      	leaq	0xc2(%rcx), %rdi
     d75:      	leaq	0x10(%r13), %rdx
     d79:      	movq	%rcx, %r12
     d7c:      	movl	$0x2, %ecx
     d81:      	movl	$0x4, %eax
     d86:      	movl	$0x2, %esi
     d8b:      	callq	*%rax
     d8d:      	leaq	0xd6(%r12), %rdi
     d95:      	leaq	0x12(%r13), %rdx
     d99:      	movl	$0x1, %ecx
     d9e:      	movl	$0x4, %eax
     da3:      	movl	$0x1, %esi
     da8:      	callq	*%rax
     daa:      	leaq	0xd4(%r12), %rdi
     db2:      	leaq	0x226(%r13), %rdx
     db9:      	movl	$0x2, %ecx
     dbe:      	movl	$0x4, %eax
     dc3:      	movl	$0x2, %esi
     dc8:      	callq	*%rax
     dca:      	leaq	0xc0(%r12), %rdi
     dd2:      	leaq	0x224(%r13), %rdx
     dd9:      	movl	$0x2, %ecx
     dde:      	movl	$0x4, %eax
     de3:      	movl	$0x2, %esi
     de8:      	callq	*%rax
     dea:      	leaq	0xcc(%r12), %rdi
     df2:      	leaq	0x21c(%r13), %rdx
     df9:      	movl	$0x4, %ecx
     dfe:      	movl	$0x4, %eax
     e03:      	movl	$0x4, %esi
     e08:      	callq	*%rax
     e0a:      	leaq	0xd0(%r12), %rdi
     e12:      	leaq	0x218(%r13), %rdx
     e19:      	movl	$0x4, %ecx
     e1e:      	movl	$0x4, %eax
     e23:      	movl	$0x4, %esi
     e28:      	callq	*%rax
     e2a:      	movq	0x30(%rsp), %rdi
     e2f:      	leaq	0xac(%r12), %r14
     e37:      	movq	$0x0, (%rdi)
     e3e:      	movq	$0x0, 0x8(%rdi)
     e46:      	movq	$0x0, 0x10(%rdi)
     e4e:      	movq	$0x0, 0x18(%rdi)
     e56:      	movzwl	0xc2(%r12), %eax
     e5f:      	cmpl	$0xa, %eax
     e62:      	je	0x21f9 <generic_retuprobe_event+0x21f9>
     e68:      	cmpl	$0x2, %eax
     e6b:      	jne	0x2226 <generic_retuprobe_event+0x2226>
     e71:      	leaq	0x4(%r13), %rdx
     e75:      	movl	$0x4, %ecx
     e7a:      	movl	$0x4, %eax
     e7f:      	movl	$0x4, %esi
     e84:      	callq	*%rax
     e86:      	movl	$0x4, %ecx
     e8b:      	movl	$0x4, %eax
     e90:      	movq	%r14, %rdi
     e93:      	movl	$0x4, %esi
     e98:      	movq	%r13, %rdx
     e9b:      	jmp	0x2224 <generic_retuprobe_event+0x2224>
     ea0:      	movq	0x8(%rsp), %r8
     ea5:      	jmp	0x1400 <generic_retuprobe_event+0x1400>
     eaa:      	cmpl	$0x1c, %r14d
     eae:      	jg	0x10ff <generic_retuprobe_event+0x10ff>
     eb4:      	cmpl	$0x11, %r14d
     eb8:      	je	0x152e <generic_retuprobe_event+0x152e>
     ebe:      	cmpl	$0x19, %r14d
     ec2:      	je	0x15fd <generic_retuprobe_event+0x15fd>
     ec8:      	cmpl	$0x1c, %r14d
     ecc:      	movq	(%rsp), %rcx
     ed0:      	je	0x1130 <generic_retuprobe_event+0x1130>
     ed6:      	jmp	0x2e61 <generic_retuprobe_event+0x2e61>
     edb:      	leal	-0xa(%r14), %eax
     edf:      	cmpl	$0x2, %eax
     ee2:      	movq	(%rsp), %rcx
     ee6:      	jb	0x1130 <generic_retuprobe_event+0x1130>
     eec:      	leal	-0xc(%r14), %eax
     ef0:      	cmpl	$0x2, %eax
     ef3:      	jb	0x1151 <generic_retuprobe_event+0x1151>
     ef9:      	cmpl	$0xe, %r14d
     efd:      	jne	0x2e61 <generic_retuprobe_event+0x2e61>
     f03:      	leaq	0x38(%rsp), %rdi
     f08:      	leaq	0x18(%rsp), %r14
     f0d:      	movl	$0x8, %ecx
     f12:      	movl	$0x4, %eax
     f17:      	movl	$0x8, %esi
     f1c:      	movq	%r14, %rdx
     f1f:      	callq	*%rax
     f21:      	movq	0x38(%rsp), %rcx
     f26:      	movl	$0x8, %edx
     f2b:      	movl	$0x4, %eax
     f30:      	movq	0x38(%rsp), %rdx
     f35:      	movq	%r14, %rdi
     f38:      	movl	$0x8, %esi
     f3d:      	callq	*%rax
     f3f:      	movq	(%rsp), %rcx
     f43:      	movq	0x18(%rsp), %rdx
     f48:      	movq	%rcx, %rdi
     f4b:      	addq	$0xa0, %rdi
     f52:      	movl	$0x1001, %ecx           # imm = 0x1001
     f57:      	movl	$0x2d, %eax
     f5c:      	movl	$0x1001, %esi           # imm = 0x1001
     f61:      	jmp	0x18ef <generic_retuprobe_event+0x18ef>
     f66:      	cmpl	$0x20, %r14d
     f6a:      	movq	0x30(%rsp), %rdi
     f6f:      	jle	0x1309 <generic_retuprobe_event+0x1309>
     f75:      	leal	-0x21(%r14), %ecx
     f79:      	cmpl	$0x4, %ecx
     f7c:      	jae	0x1172 <generic_retuprobe_event+0x1172>
     f82:      	movl	$0x8, %r13d
     f88:      	movl	$0x8, %ecx
     f8d:      	movl	$0x4, %eax
     f92:      	movq	0x8(%rsp), %r14
     f97:      	movl	$0x8, %esi
     f9c:      	movq	%r14, %rdx
     f9f:      	jmp	0x13fb <generic_retuprobe_event+0x13fb>
     fa4:      	cmpl	$0x27, %r14d
     fa8:      	je	0x18cb <generic_retuprobe_event+0x18cb>
     fae:      	cmpl	$0x28, %r14d
     fb2:      	je	0x1911 <generic_retuprobe_event+0x1911>
     fb8:      	cmpl	$0x2c, %r14d
     fbc:      	movq	(%rsp), %rcx
     fc0:      	jne	0x2e61 <generic_retuprobe_event+0x2e61>
     fc6:      	movq	0x18(%rsp), %r12
     fcb:      	movb	$0x0, 0x38(%rsp)
     fd0:      	movq	$0x0, 0x68(%rdi)
     fd8:      	movq	$0x0, 0x60(%rdi)
     fe0:      	movq	$0x0, 0x58(%rdi)
     fe8:      	movq	$0x0, 0x50(%rdi)
     ff0:      	movq	$0x0, 0x48(%rdi)
     ff8:      	movq	$0x0, 0x40(%rdi)
    1000:      	movq	$0x0, 0x38(%rdi)
    1008:      	movq	$0x0, 0x30(%rdi)
    1010:      	movq	$0x0, 0x28(%rdi)
    1018:      	movq	$0x0, 0x20(%rdi)
    1020:      	movq	$0x0, 0x18(%rdi)
    1028:      	movq	$0x0, 0x10(%rdi)
    1030:      	movq	$0x0, 0x8(%rdi)
    1038:      	movq	$0x0, (%rdi)
    103f:      	movl	$0x2, %ecx
    1044:      	movl	$0x4, %eax
    1049:      	movl	$0x2, %esi
    104e:      	movq	%r12, %rdx
    1051:      	callq	*%rax
    1053:      	testq	%rax, %rax
    1056:      	js	0x2474 <generic_retuprobe_event+0x2474>
    105c:      	leaq	0x2(%r12), %r14
    1061:      	leaq	0x38(%rsp), %rdi
    1066:      	movl	$0x1, %ecx
    106b:      	movl	$0x4, %eax
    1070:      	movl	$0x1, %esi
    1075:      	movq	%r14, %rdx
    1078:      	callq	*%rax
    107a:      	testq	%rax, %rax
    107d:      	js	0x2474 <generic_retuprobe_event+0x2474>
    1083:      	movq	(%rsp), %rax
    1087:      	movq	%rax, %rdi
    108a:      	addq	$0xa0, %rdi
    1091:      	cmpb	$0x0, 0x38(%rsp)
    1096:      	sete	0x9e(%rax)
    109d:      	je	0x2449 <generic_retuprobe_event+0x2449>
    10a3:      	movl	$0x6c, %ecx
    10a8:      	movl	$0x2d, %eax
    10ad:      	movl	$0x6c, %esi
    10b2:      	movq	%r14, %rdx
    10b5:      	callq	*%rax
    10b7:      	testl	%eax, %eax
    10b9:      	js	0x2474 <generic_retuprobe_event+0x2474>
    10bf:      	decb	%al
    10c1:      	jmp	0x246a <generic_retuprobe_event+0x246a>
    10c6:      	cmpl	$0x7, %r14d
    10ca:      	jg	0x13d2 <generic_retuprobe_event+0x13d2>
    10d0:      	cmpl	$0x2, %r14d
    10d4:      	je	0x1aa2 <generic_retuprobe_event+0x1aa2>
    10da:      	cmpl	$0x3, %r14d
    10de:      	movq	0x8(%rsp), %r8
    10e3:      	jne	0x2e71 <generic_retuprobe_event+0x2e71>
    10e9:      	movq	$0x0, 0x9c(%rax)
    10f4:      	movl	$0x8, %r13d
    10fa:      	jmp	0x2e71 <generic_retuprobe_event+0x2e71>
    10ff:      	leaq	0x18(%rsp), %rdx
    1104:      	movl	$0x4, %r13d
    110a:      	movl	$0x2, %ecx
    110f:      	movl	$0x4, %eax
    1114:      	movl	$0x2, %esi
    1119:      	callq	*%rax
    111b:      	jmp	0x2e5d <generic_retuprobe_event+0x2e5d>
    1120:      	cmpl	$0x1, %r14d
    1124:      	je	0x1151 <generic_retuprobe_event+0x1151>
    1126:      	cmpl	$0x4, %r14d
    112a:      	jne	0x2e61 <generic_retuprobe_event+0x2e61>
    1130:      	movl	$0x8, %r13d
    1136:      	leaq	0x18(%rsp), %rdx
    113b:      	movl	$0x8, %ecx
    1140:      	movl	$0x4, %eax
    1145:      	movl	$0x8, %esi
    114a:      	callq	*%rax
    114c:      	jmp	0x2e5d <generic_retuprobe_event+0x2e5d>
    1151:      	leaq	0x18(%rsp), %rdx
    1156:      	movl	$0x4, %r13d
    115c:      	movl	$0x4, %ecx
    1161:      	movl	$0x4, %eax
    1166:      	movl	$0x4, %esi
    116b:      	callq	*%rax
    116d:      	jmp	0x2e5d <generic_retuprobe_event+0x2e5d>
    1172:      	cmpl	$0x2b, %r14d
    1176:      	je	0x1f67 <generic_retuprobe_event+0x1f67>
    117c:      	cmpl	$0x29, %r14d
    1180:      	movq	0x8(%rsp), %r8
    1185:      	movq	(%rsp), %rcx
    1189:      	jne	0x2e71 <generic_retuprobe_event+0x2e71>
    118f:      	movq	%rdi, 0x30(%rsp)
    1194:      	movq	%rbp, 0x88(%rsp)
    119c:      	movq	%r12, %rbp
    119f:      	movq	%rax, 0x10(%rsp)
    11a4:      	leaq	0x18(%r8), %rdx
    11a8:      	leaq	0x38(%rsp), %rdi
    11ad:      	movl	$0x4, %r14d
    11b3:      	movl	$0x8, %ecx
    11b8:      	movl	$0x4, %eax
    11bd:      	movl	$0x8, %esi
    11c2:      	callq	*%rax
    11c4:      	movq	0x38(%rsp), %r13
    11c9:      	testq	%r13, %r13
    11cc:      	je	0x250b <generic_retuprobe_event+0x250b>
    11d2:      	movq	(%rsp), %r12
    11d6:      	movq	%r13, 0xc4(%r12)
    11de:      	leaq	0xc2(%r12), %rdi
    11e6:      	leaq	0x10(%r13), %rdx
    11ea:      	movl	$0x2, %ecx
    11ef:      	movl	$0x4, %eax
    11f4:      	movl	$0x2, %esi
    11f9:      	callq	*%rax
    11fb:      	leaq	0xd6(%r12), %rdi
    1203:      	leaq	0x12(%r13), %rdx
    1207:      	movl	$0x1, %ecx
    120c:      	movl	$0x4, %eax
    1211:      	movl	$0x1, %esi
    1216:      	callq	*%rax
    1218:      	leaq	0xd4(%r12), %rdi
    1220:      	leaq	0x226(%r13), %rdx
    1227:      	movl	$0x2, %ecx
    122c:      	movl	$0x4, %eax
    1231:      	movl	$0x2, %esi
    1236:      	callq	*%rax
    1238:      	leaq	0xc0(%r12), %rdi
    1240:      	leaq	0x224(%r13), %rdx
    1247:      	movl	$0x2, %ecx
    124c:      	movl	$0x4, %eax
    1251:      	movl	$0x2, %esi
    1256:      	callq	*%rax
    1258:      	leaq	0xcc(%r12), %rdi
    1260:      	leaq	0x21c(%r13), %rdx
    1267:      	movl	$0x4, %eax
    126c:      	movl	$0x4, %esi
    1271:      	callq	*%rax
    1273:      	leaq	0xd0(%r12), %rdi
    127b:      	leaq	0x218(%r13), %rdx
    1282:      	movl	$0x4, %eax
    1287:      	movl	$0x4, %esi
    128c:      	callq	*%rax
    128e:      	leaq	0xac(%r12), %r14
    1296:      	movq	0x30(%rsp), %rax
    129b:      	movq	$0x0, (%rax)
    12a2:      	movq	$0x0, 0x8(%rax)
    12aa:      	movq	$0x0, 0x10(%rax)
    12b2:      	movq	$0x0, 0x18(%rax)
    12ba:      	movzwl	0xc2(%r12), %eax
    12c3:      	cmpl	$0xa, %eax
    12c6:      	je	0x247f <generic_retuprobe_event+0x247f>
    12cc:      	cmpl	$0x2, %eax
    12cf:      	jne	0x24b1 <generic_retuprobe_event+0x24b1>
    12d5:      	leaq	0x4(%r13), %rdx
    12d9:      	movl	$0x4, %ecx
    12de:      	movl	$0x4, %eax
    12e3:      	movq	0x30(%rsp), %rdi
    12e8:      	movl	$0x4, %esi
    12ed:      	callq	*%rax
    12ef:      	movl	$0x4, %ecx
    12f4:      	movl	$0x4, %eax
    12f9:      	movq	%r14, %rdi
    12fc:      	movl	$0x4, %esi
    1301:      	movq	%r13, %rdx
    1304:      	jmp	0x24af <generic_retuprobe_event+0x24af>
    1309:      	cmpl	$0x1a, %r14d
    130d:      	je	0x2012 <generic_retuprobe_event+0x2012>
    1313:      	cmpl	$0x1b, %r14d
    1317:      	movq	0x8(%rsp), %r8
    131c:      	jne	0x2e71 <generic_retuprobe_event+0x2e71>
    1322:      	movq	$0x0, 0x48(%rdi)
    132a:      	movq	$0x0, 0x40(%rdi)
    1332:      	movq	$0x0, 0x38(%rdi)
    133a:      	movq	$0x0, 0x30(%rdi)
    1342:      	movq	$0x0, 0x28(%rdi)
    134a:      	movq	$0x0, 0x20(%rdi)
    1352:      	movq	$0x0, 0x18(%rdi)
    135a:      	movq	$0x0, 0x10(%rdi)
    1362:      	movq	$0x0, 0x8(%rdi)
    136a:      	movq	$0x0, (%rdi)
    1371:      	leaq	0xac(%rcx), %rdi
    1378:      	leaq	0x18(%r8), %rdx
    137c:      	movl	$0x3f, %ecx
    1381:      	movl	$0x2d, %eax
    1386:      	movl	$0x3f, %esi
    138b:      	callq	*%rax
    138d:      	testq	%rax, %rax
    1390:      	js	0x2404 <generic_retuprobe_event+0x2404>
    1396:      	movq	(%rsp), %r14
    139a:      	movq	%r14, %rdi
    139d:      	addq	$0xa4, %rdi
    13a4:      	movq	0x8(%rsp), %r13
    13a9:      	leaq	0x348(%r13), %rdx
    13b0:      	movl	$0x8, %ecx
    13b5:      	movl	$0x4, %eax
    13ba:      	movl	$0x8, %esi
    13bf:      	callq	*%rax
    13c1:      	movq	%r13, %r8
    13c4:      	movq	%r14, %rcx
    13c7:      	movl	$0x50, %r13d
    13cd:      	jmp	0x2e71 <generic_retuprobe_event+0x2e71>
    13d2:      	cmpl	$0x8, %r14d
    13d6:      	je	0x1b5f <generic_retuprobe_event+0x1b5f>
    13dc:      	cmpl	$0x12, %r14d
    13e0:      	movq	0x8(%rsp), %r8
    13e5:      	jne	0x2e71 <generic_retuprobe_event+0x2e71>
    13eb:      	xorl	%r13d, %r13d
    13ee:      	movl	$0x4, %eax
    13f3:      	xorl	%esi, %esi
    13f5:      	movq	%r8, %rdx
    13f8:      	movq	%r8, %r14
    13fb:      	callq	*%rax
    13fd:      	movq	%r14, %r8
    1400:      	movq	(%rsp), %rcx
    1404:      	jmp	0x2e71 <generic_retuprobe_event+0x2e71>
    1409:      	cmpl	$0x13, %r14d
    140d:      	je	0x1efc <generic_retuprobe_event+0x1efc>
    1413:      	cmpl	$0x14, %r14d
    1417:      	movq	0x8(%rsp), %r8
    141c:      	jne	0x2e71 <generic_retuprobe_event+0x2e71>
    1422:      	movq	$0x0, 0x38(%rsp)
    142b:      	leaq	0x110(%r8), %rdx
    1432:      	movq	%rdi, %r13
    1435:      	leaq	0x38(%rsp), %rdi
    143a:      	movl	$0x8, %ecx
    143f:      	movl	$0x4, %eax
    1444:      	movq	0x8(%rsp), %rcx
    1449:      	leaq	0xd8(%rcx), %r14
    1450:      	movl	$0x8, %esi
    1455:      	callq	*%rax
    1457:      	movq	0x38(%rsp), %rcx
    145c:      	movl	$0x80, %edx
    1461:      	movl	$0x2d, %eax
    1466:      	movq	0x38(%rsp), %rdx
    146b:      	movq	%r13, %rdi
    146e:      	movl	$0x80, %esi
    1473:      	callq	*%rax
    1475:      	movq	(%rsp), %rax
    1479:      	leaq	0x12c(%rax), %rdi
    1480:      	movl	$0x4, %ecx
    1485:      	movl	$0x4, %eax
    148a:      	movl	$0x4, %esi
    148f:      	movq	%r14, %rdx
    1492:      	movq	0x8(%rsp), %r14
    1497:      	callq	*%rax
    1499:      	movq	(%rsp), %rax
    149d:      	leaq	0x11c(%rax), %rdi
    14a4:      	leaq	0xe0(%r14), %rdx
    14ab:      	movl	$0x8, %ecx
    14b0:      	movl	$0x4, %eax
    14b5:      	movl	$0x8, %esi
    14ba:      	callq	*%rax
    14bc:      	movq	(%rsp), %rdi
    14c0:      	addq	$0x124, %rdi            # imm = 0x124
    14c7:      	leaq	0x118(%r14), %rdx
    14ce:      	movl	$0x8, %ecx
    14d3:      	movl	$0x4, %eax
    14d8:      	movl	$0x8, %esi
    14dd:      	callq	*%rax
    14df:      	movq	%r14, %r8
    14e2:      	movq	(%rsp), %rcx
    14e6:      	movl	$0x98, %r13d
    14ec:      	jmp	0x2e71 <generic_retuprobe_event+0x2e71>
    14f1:      	cmpl	$0x26, %r14d
    14f5:      	movq	(%rsp), %rcx
    14f9:      	jne	0x2e61 <generic_retuprobe_event+0x2e61>
    14ff:      	movq	0x18(%rsp), %rsi
    1504:      	movzwl	%si, %edx
    1507:      	addq	0xc8(%rsp), %rdx
    150f:      	shrl	$0x10, %esi
    1512:      	andl	$0xfff, %esi            # imm = 0xFFF
    1518:      	movq	%rcx, %rdi
    151b:      	addq	$0xa0, %rdi
    1522:      	incl	%esi
    1524:      	movl	$0x2d, %eax
    1529:      	jmp	0x18ef <generic_retuprobe_event+0x18ef>
    152e:      	movq	$0x0, 0x40(%rsp)
    1537:      	movq	$0x0, 0x38(%rsp)
    1540:      	movl	$0xe, %eax
    1545:      	callq	*%rax
    1547:      	shrq	$0x20, %rax
    154b:      	movq	%rax, 0x38(%rsp)
    1550:      	leaq	0x78(%rsp), %rdi
    1555:      	leaq	0x18(%rsp), %rdx
    155a:      	movl	$0x4, %ecx
    155f:      	movl	$0x4, %eax
    1564:      	movl	$0x4, %esi
    1569:      	callq	*%rax
    156b:      	movl	0x78(%rsp), %eax
    156f:      	movl	%eax, 0x40(%rsp)
    1573:      	movq	(%rip), %rdi            # 0x157a <generic_retuprobe_event+0x157a>
    157a:      	leaq	0x38(%rsp), %rsi
    157f:      	movl	$0x1, %eax
    1584:      	callq	*%rax
    1586:      	testq	%rax, %rax
    1589:      	je	0x2097 <generic_retuprobe_event+0x2097>
    158f:      	movl	(%rax), %r13d
    1592:      	leaq	0x78(%rsp), %rdx
    1597:      	movq	%rax, %r14
    159a:      	movl	$0x4, %eax
    159f:      	movq	0x30(%rsp), %r12
    15a4:      	movl	$0x4, %ecx
    15a9:      	movq	%r12, %rdi
    15ac:      	movl	$0x4, %esi
    15b1:      	callq	*%rax
    15b3:      	andl	$0xfff, %r13d           # imm = 0xFFF
    15ba:      	movq	(%rsp), %rdi
    15be:      	addq	$0xa0, %rdi
    15c5:      	leaq	0x4(%r13), %rsi
    15c9:      	movl	$0x4, %eax
    15ce:      	movq	%r14, %rdx
    15d1:      	callq	*%rax
    15d3:      	leaq	(%r12,%r13), %rdi
    15d7:      	addq	$0x8, %rdi
    15db:      	leaq	(%r14,%r13), %rdx
    15df:      	addq	$0x4, %rdx
    15e3:      	movl	$0x4, %eax
    15e8:      	movl	$0x4, %ecx
    15ed:      	movl	$0x4, %esi
    15f2:      	callq	*%rax
    15f4:      	addq	$0xc, %r13
    15f8:      	jmp	0x2e5d <generic_retuprobe_event+0x2e5d>
    15fd:      	movq	%rax, 0x10(%rsp)
    1602:      	movq	0x18(%rsp), %r14
    1607:      	leaq	0xb0(%rsp), %rdi
    160f:      	movl	$0x1, %ecx
    1614:      	movl	$0x4, %eax
    1619:      	movl	$0x1, %esi
    161e:      	movq	%r14, %rdx
    1621:      	callq	*%rax
    1623:      	movzbl	0xb0(%rsp), %eax
    162b:      	testl	%eax, %eax
    162d:      	je	0x20a3 <generic_retuprobe_event+0x20a3>
    1633:      	cmpl	$0x1, %eax
    1636:      	jne	0x22c8 <generic_retuprobe_event+0x22c8>
    163c:      	addq	$0x10, %r14
    1640:      	leaq	0x38(%rsp), %rdi
    1645:      	movl	$0x4, %r13d
    164b:      	movl	$0x8, %ecx
    1650:      	movl	$0x4, %eax
    1655:      	movl	$0x8, %esi
    165a:      	movq	%r14, %rdx
    165d:      	callq	*%rax
    165f:      	movq	0x38(%rsp), %rdx
    1664:      	leaq	0x78(%rsp), %rdi
    1669:      	movl	$0x8, %ecx
    166e:      	movl	$0x4, %eax
    1673:      	movl	$0x8, %esi
    1678:      	callq	*%rax
    167a:      	movq	0x38(%rsp), %rdx
    167f:      	addq	$0x8, %rdx
    1683:      	leaq	0x90(%rsp), %rdi
    168b:      	movl	$0x8, %ecx
    1690:      	movl	$0x4, %eax
    1695:      	movl	$0x8, %esi
    169a:      	callq	*%rax
    169c:      	movq	0x78(%rsp), %rdx
    16a1:      	movq	0x90(%rsp), %r12
    16a9:      	cmpq	$0xfff, %r12            # imm = 0xFFF
    16b0:      	movl	$0xfff, %r14d           # imm = 0xFFF
    16b6:      	cmovbq	%r12, %r14
    16ba:      	movq	0x10(%rsp), %rdi
    16bf:      	addq	$0xa4, %rdi
    16c6:      	movl	$0x4, %eax
    16cb:      	movl	%r14d, %esi
    16ce:      	callq	*%rax
    16d0:      	testl	%eax, %eax
    16d2:      	js	0x2415 <generic_retuprobe_event+0x2415>
    16d8:      	movq	0x10(%rsp), %rax
    16dd:      	movl	%r12d, 0x9c(%rax)
    16e4:      	movl	%r14d, 0xa0(%rax)
    16eb:      	addq	$0x8, %r14
    16ef:      	movq	%r14, %r13
    16f2:      	jmp	0x243b <generic_retuprobe_event+0x243b>
    16f7:      	movq	0x18(%rsp), %r13
    16fc:      	leaq	0xc4(%rcx), %rdi
    1703:      	leaq	0x98(%r13), %rdx
    170a:      	movq	%rcx, %r14
    170d:      	movl	$0x4, %ecx
    1712:      	movl	$0x4, %eax
    1717:      	movl	$0x4, %esi
    171c:      	callq	*%rax
    171e:      	leaq	0xc8(%r14), %rdi
    1725:      	leaq	0x70(%r13), %rdx
    1729:      	movl	$0x4, %ecx
    172e:      	movl	$0x4, %eax
    1733:      	movl	$0x4, %esi
    1738:      	callq	*%rax
    173a:      	leaq	0xcc(%r14), %rdi
    1741:      	leaq	0x90(%r13), %rdx
    1748:      	movl	$0x4, %ecx
    174d:      	movl	$0x4, %eax
    1752:      	movl	$0x4, %esi
    1757:      	callq	*%rax
    1759:      	leaq	0xd0(%r14), %rdi
    1760:      	leaq	0xa8(%r13), %rdx
    1767:      	movl	$0x4, %ecx
    176c:      	movl	$0x4, %eax
    1771:      	movl	$0x4, %esi
    1776:      	callq	*%rax
    1778:      	movq	$0x0, 0x38(%rsp)
    1781:      	leaq	0xc8(%r13), %rdx
    1788:      	leaq	0x38(%rsp), %rdi
    178d:      	movl	$0x8, %ecx
    1792:      	movl	$0x4, %eax
    1797:      	movl	$0x8, %esi
    179c:      	callq	*%rax
    179e:      	leaq	0xb8(%r13), %rdx
    17a5:      	leaq	0xb0(%rsp), %rdi
    17ad:      	movl	$0x2, %ecx
    17b2:      	movl	$0x4, %eax
    17b7:      	movl	$0x2, %esi
    17bc:      	callq	*%rax
    17be:      	movzwl	0xb0(%rsp), %r12d
    17c7:      	addq	0x38(%rsp), %r12
    17cc:      	leaq	0xc4(%rsp), %rdi
    17d4:      	movl	$0x1, %ecx
    17d9:      	movl	$0x4, %eax
    17de:      	movl	$0x1, %esi
    17e3:      	movq	%r12, %rdx
    17e6:      	callq	*%rax
    17e8:      	movzbl	0xc4(%rsp), %eax
    17f0:      	shrl	$0x4, %eax
    17f3:      	cmpl	$0x6, %eax
    17f6:      	je	0x2137 <generic_retuprobe_event+0x2137>
    17fc:      	cmpl	$0x4, %eax
    17ff:      	jne	0x2e57 <generic_retuprobe_event+0x2e57>
    1805:      	movq	%rbx, 0x10(%rsp)
    180a:      	leaq	0x9(%r12), %rdx
    180f:      	leaq	0xd0(%rsp), %rdi
    1817:      	movl	$0x1, %ecx
    181c:      	movl	$0x4, %eax
    1821:      	movl	$0x1, %esi
    1826:      	callq	*%rax
    1828:      	movzbl	0xd0(%rsp), %eax
    1830:      	movq	(%rsp), %rsi
    1834:      	movw	%ax, 0xc0(%rsi)
    183b:      	movw	$0x2, 0xc2(%rsi)
    1844:      	leaq	0xc(%r12), %rdx
    1849:      	movq	0x30(%rsp), %rdi
    184e:      	movq	$0x0, (%rdi)
    1855:      	movq	$0x0, 0x8(%rdi)
    185d:      	movq	$0x0, 0x10(%rdi)
    1865:      	movq	$0x0, 0x18(%rdi)
    186d:      	movl	$0x4, %ecx
    1872:      	movl	$0x4, %eax
    1877:      	leaq	0xac(%rsi), %r14
    187e:      	movl	$0x4, %esi
    1883:      	callq	*%rax
    1885:      	addq	$0x10, %r12
    1889:      	movl	$0x4, %ecx
    188e:      	movl	$0x4, %eax
    1893:      	movq	%r14, %rdi
    1896:      	movl	$0x4, %esi
    189b:      	movq	%r12, %rdx
    189e:      	callq	*%rax
    18a0:      	movq	%r13, 0xa0(%rsp)
    18a8:      	leaq	0xb6(%r13), %rdx
    18af:      	leaq	0xd8(%rsp), %rdi
    18b7:      	movl	$0x2, %ecx
    18bc:      	movl	$0x4, %eax
    18c1:      	movl	$0x2, %esi
    18c6:      	jmp	0x2cc5 <generic_retuprobe_event+0x2cc5>
    18cb:      	movl	$0x120, %edx            # imm = 0x120
    18d0:      	addq	0x18(%rsp), %rdx
    18d5:      	movq	(%rsp), %rdi
    18d9:      	addq	$0xa0, %rdi
    18e0:      	movl	$0x11, %ecx
    18e5:      	movl	$0x2d, %eax
    18ea:      	movl	$0x11, %esi
    18ef:      	callq	*%rax
    18f1:      	movq	%rax, %r13
    18f4:      	testq	%rax, %rax
    18f7:      	js	0x2e5d <generic_retuprobe_event+0x2e5d>
    18fd:      	leal	-0x1(%r13), %eax
    1901:      	movq	0x30(%rsp), %rcx
    1906:      	movl	%eax, (%rcx)
    1908:      	addq	$0x3, %r13
    190c:      	jmp	0x2e5d <generic_retuprobe_event+0x2e5d>
    1911:      	movq	0x18(%rsp), %r12
    1916:      	movq	$0x0, 0x10(%rdi)
    191e:      	movq	$0x0, 0x8(%rdi)
    1926:      	movq	$0x0, (%rdi)
    192d:      	movl	$0x2, %ecx
    1932:      	movl	$0x4, %eax
    1937:      	movq	%rdi, %r14
    193a:      	movl	$0x2, %esi
    193f:      	movq	%r12, %rdx
    1942:      	callq	*%rax
    1944:      	testq	%rax, %rax
    1947:      	movq	(%rsp), %rcx
    194b:      	js	0x233e <generic_retuprobe_event+0x233e>
    1951:      	movzwl	(%r14), %eax
    1955:      	cmpl	$0xa, %eax
    1958:      	je	0x22e3 <generic_retuprobe_event+0x22e3>
    195e:      	cmpl	$0x2, %eax
    1961:      	jne	0x2325 <generic_retuprobe_event+0x2325>
    1967:      	leaq	0x4(%r12), %rdx
    196c:      	leaq	0x38(%rsp), %rdi
    1971:      	movl	$0x4, %ecx
    1976:      	movl	$0x4, %eax
    197b:      	movl	$0x4, %esi
    1980:      	callq	*%rax
    1982:      	movl	0x38(%rsp), %eax
    1986:      	movq	(%rsp), %rdi
    198a:      	movq	%rax, 0xa4(%rdi)
    1991:      	addq	$0x9e, %rdi
    1998:      	addq	$0x2, %r12
    199c:      	movl	$0x2, %ecx
    19a1:      	movl	$0x4, %eax
    19a6:      	jmp	0x231b <generic_retuprobe_event+0x231b>
    19ab:      	xorl	%eax, %eax
    19ad:      	movq	%rax, 0x8(%rsp)
    19b2:      	cmpq	$0x3, 0xb8(%rsp)
    19bb:      	jb	0x1a82 <generic_retuprobe_event+0x1a82>
    19c1:      	movq	%r14, %rbp
    19c4:      	movq	%rbx, 0x10(%rsp)
    19c9:      	movq	0x88(%rsp), %rax
    19d1:      	leaq	0x20(%rax), %rdx
    19d5:      	leaq	0x38(%rsp), %rdi
    19da:      	movl	$0x4, %r12d
    19e0:      	movl	$0x10, %ecx
    19e5:      	movl	$0x4, %eax
    19ea:      	movl	$0x10, %esi
    19ef:      	callq	*%rax
    19f1:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    19f6:      	testl	%eax, %eax
    19f8:      	js	0x1a8f <generic_retuprobe_event+0x1a8f>
    19fe:      	movq	0x40(%rsp), %r14
    1a03:      	movq	0x8(%rsp), %rax
    1a08:      	cmpq	%rax, %r14
    1a0b:      	movq	%rax, %rcx
    1a0e:      	cmovbq	%r14, %rcx
    1a12:      	testq	%rax, %rax
    1a15:      	movq	%rcx, %rbx
    1a18:      	cmovneq	%rcx, %r14
    1a1c:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    1a21:      	cmpq	$0xffe, %r14            # imm = 0xFFE
    1a28:      	ja	0x1a8f <generic_retuprobe_event+0x1a8f>
    1a2a:      	addq	0x20(%rsp), %rbp
    1a2f:      	movq	%rbp, (%rsp)
    1a33:      	movl	%ebp, %edi
    1a35:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    1a3b:      	addq	%r15, %rdi
    1a3e:      	movq	0x38(%rsp), %rcx
    1a43:      	movl	$0x4, %eax
    1a48:      	movq	0x38(%rsp), %rdx
    1a4d:      	movl	%r14d, %esi
    1a50:      	callq	*%rax
    1a52:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1a57:      	testl	%eax, %eax
    1a59:      	js	0x1a8f <generic_retuprobe_event+0x1a8f>
    1a5b:      	movq	%r15, 0x20(%rsp)
    1a60:      	movq	%r14, %r15
    1a63:      	addq	%r14, %r13
    1a66:      	cmpq	$0x0, 0x8(%rsp)
    1a6c:      	je	0x25ae <generic_retuprobe_event+0x25ae>
    1a72:      	subq	%rbx, 0x8(%rsp)
    1a77:      	jne	0x25b5 <generic_retuprobe_event+0x25b5>
    1a7d:      	jmp	0x25c0 <generic_retuprobe_event+0x25c0>
    1a82:      	movq	%r13, %rbp
    1a85:      	movq	0x28(%rsp), %rax
    1a8a:      	jmp	0x320 <generic_retuprobe_event+0x320>
    1a8f:      	movq	0x28(%rsp), %rax
    1a94:      	movl	%ecx, (%r15,%rax)
    1a98:      	movq	0x10(%rsp), %rbx
    1a9d:      	jmp	0xbcc <generic_retuprobe_event+0xbcc>
    1aa2:      	movq	%rbp, 0x88(%rsp)
    1aaa:      	movq	%r12, 0xa8(%rsp)
    1ab2:      	movq	$0x0, 0x78(%rsp)
    1abb:      	movq	$0x0, 0x38(%rsp)
    1ac4:      	leaq	0x78(%rsp), %rdi
    1ac9:      	leaq	0x38(%rsp), %rdx
    1ace:      	movl	$0x8, %ecx
    1ad3:      	movq	%rax, %r12
    1ad6:      	movl	$0x4, %eax
    1adb:      	movl	$0x4, %r13d
    1ae1:      	movl	$0x8, %esi
    1ae6:      	callq	*%rax
    1ae8:      	movq	0x78(%rsp), %rbp
    1aed:      	cmpq	$0xfff, %rbp            # imm = 0xFFF
    1af4:      	movl	$0xfff, %r14d           # imm = 0xFFF
    1afa:      	cmovbq	%rbp, %r14
    1afe:      	movq	%r12, 0x10(%rsp)
    1b03:      	addq	$0xa4, %r12
    1b0a:      	movl	$0x4, %eax
    1b0f:      	movq	0x8(%rsp), %rdx
    1b14:      	movq	%r12, %rdi
    1b17:      	movl	%r14d, %esi
    1b1a:      	callq	*%rax
    1b1c:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1b21:      	testl	%eax, %eax
    1b23:      	js	0x1b3a <generic_retuprobe_event+0x1b3a>
    1b25:      	movq	0x10(%rsp), %rax
    1b2a:      	movl	%r14d, 0xa0(%rax)
    1b31:      	addq	$0x8, %r14
    1b35:      	movl	%ebp, %ecx
    1b37:      	movq	%r14, %r13
    1b3a:      	movq	0x10(%rsp), %rax
    1b3f:      	movl	%ecx, 0x9c(%rax)
    1b45:      	movq	0xa8(%rsp), %r12
    1b4d:      	movq	0x8(%rsp), %r8
    1b52:      	movq	0x88(%rsp), %rbp
    1b5a:      	jmp	0x1400 <generic_retuprobe_event+0x1400>
    1b5f:      	movq	%rbp, %r14
    1b62:      	leaq	0xc4(%rcx), %rbp
    1b69:      	leaq	0xdc(%rcx), %rax
    1b70:      	movq	%rax, 0x10(%rsp)
    1b75:      	movq	0x8(%rsp), %r13
    1b7a:      	leaq	0x8(%r13), %rdx
    1b7e:      	movl	$0x4, %ecx
    1b83:      	movl	$0x4, %eax
    1b88:      	movl	$0x4, %esi
    1b8d:      	callq	*%rax
    1b8f:      	movq	(%rsp), %rax
    1b93:      	leaq	0xa0(%rax), %rdi
    1b9a:      	leaq	0xc(%r13), %rdx
    1b9e:      	movl	$0x4, %ecx
    1ba3:      	movl	$0x4, %eax
    1ba8:      	movl	$0x4, %esi
    1bad:      	callq	*%rax
    1baf:      	movq	(%rsp), %rax
    1bb3:      	leaq	0xac(%rax), %rdi
    1bba:      	leaq	0x18(%r13), %rdx
    1bbe:      	movl	$0x4, %ecx
    1bc3:      	movl	$0x4, %eax
    1bc8:      	movl	$0x4, %esi
    1bcd:      	callq	*%rax
    1bcf:      	movq	(%rsp), %rax
    1bd3:      	leaq	0xb0(%rax), %rdi
    1bda:      	leaq	0x1c(%r13), %rdx
    1bde:      	movl	$0x4, %ecx
    1be3:      	movl	$0x4, %eax
    1be8:      	movl	$0x4, %esi
    1bed:      	callq	*%rax
    1bef:      	movq	(%rsp), %rax
    1bf3:      	leaq	0xa4(%rax), %rdi
    1bfa:      	leaq	0x10(%r13), %rdx
    1bfe:      	movl	$0x4, %ecx
    1c03:      	movl	$0x4, %eax
    1c08:      	movl	$0x4, %esi
    1c0d:      	callq	*%rax
    1c0f:      	movq	(%rsp), %rax
    1c13:      	leaq	0xa8(%rax), %rdi
    1c1a:      	leaq	0x14(%r13), %rdx
    1c1e:      	movl	$0x4, %ecx
    1c23:      	movl	$0x4, %eax
    1c28:      	movl	$0x4, %esi
    1c2d:      	callq	*%rax
    1c2f:      	movq	(%rsp), %rax
    1c33:      	leaq	0xb4(%rax), %rdi
    1c3a:      	leaq	0x20(%r13), %rdx
    1c3e:      	movl	$0x4, %ecx
    1c43:      	movl	$0x4, %eax
    1c48:      	movl	$0x4, %esi
    1c4d:      	callq	*%rax
    1c4f:      	movq	(%rsp), %rax
    1c53:      	leaq	0xb8(%rax), %rdi
    1c5a:      	leaq	0x24(%r13), %rdx
    1c5e:      	movl	$0x4, %ecx
    1c63:      	movl	$0x4, %eax
    1c68:      	movl	$0x4, %esi
    1c6d:      	callq	*%rax
    1c6f:      	movq	(%rsp), %rax
    1c73:      	movl	$0x0, 0xc0(%rax)
    1c7d:      	movq	(%rsp), %rax
    1c81:      	leaq	0xbc(%rax), %rdi
    1c88:      	leaq	0x28(%r13), %rdx
    1c8c:      	movl	$0x4, %ecx
    1c91:      	movl	$0x4, %eax
    1c96:      	movl	$0x4, %esi
    1c9b:      	callq	*%rax
    1c9d:      	movq	(%rsp), %rax
    1ca1:      	leaq	0xcc(%rax), %rdi
    1ca8:      	leaq	0x40(%r13), %rdx
    1cac:      	movl	$0x8, %ecx
    1cb1:      	movl	$0x4, %eax
    1cb6:      	movl	$0x8, %esi
    1cbb:      	callq	*%rax
    1cbd:      	movq	(%rsp), %rax
    1cc1:      	leaq	0xd4(%rax), %rdi
    1cc8:      	leaq	0x30(%r13), %rdx
    1ccc:      	movl	$0x8, %ecx
    1cd1:      	movl	$0x4, %eax
    1cd6:      	movl	$0x8, %esi
    1cdb:      	callq	*%rax
    1cdd:      	leaq	0x38(%r13), %rdx
    1ce1:      	movl	$0x8, %ecx
    1ce6:      	movl	$0x4, %eax
    1ceb:      	movq	%rbp, %rdi
    1cee:      	movq	%r14, %rbp
    1cf1:      	movl	$0x8, %esi
    1cf6:      	callq	*%rax
    1cf8:      	leaq	0x90(%r13), %rdx
    1cff:      	leaq	0x38(%rsp), %rdi
    1d04:      	movl	$0x8, %ecx
    1d09:      	movl	$0x4, %eax
    1d0e:      	movl	$0x8, %esi
    1d13:      	callq	*%rax
    1d15:      	movq	0x38(%rsp), %r14
    1d1a:      	leaq	0xc8(%r14), %rdx
    1d21:      	movl	$0x4, %ecx
    1d26:      	movl	$0x4, %eax
    1d2b:      	movq	0x10(%rsp), %rdi
    1d30:      	movl	$0x4, %esi
    1d35:      	callq	*%rax
    1d37:      	movq	(%rsp), %rax
    1d3b:      	leaq	0xe0(%rax), %rdi
    1d42:      	leaq	0xcc(%r14), %rdx
    1d49:      	movl	$0x4, %ecx
    1d4e:      	movl	$0x4, %eax
    1d53:      	movl	$0x4, %esi
    1d58:      	callq	*%rax
    1d5a:      	movq	(%rsp), %rax
    1d5e:      	leaq	0xe4(%rax), %rdi
    1d65:      	leaq	0xd0(%r14), %rdx
    1d6c:      	movl	$0x4, %ecx
    1d71:      	movl	$0x4, %eax
    1d76:      	movl	$0x4, %esi
    1d7b:      	callq	*%rax
    1d7d:      	movq	(%rsp), %rdi
    1d81:      	addq	$0xe8, %rdi
    1d88:      	addq	$0x158, %r14            # imm = 0x158
    1d8f:      	movl	$0x4, %ecx
    1d94:      	movl	$0x4, %eax
    1d99:      	movl	$0x4, %esi
    1d9e:      	movq	%r14, %rdx
    1da1:      	callq	*%rax
    1da3:      	movq	%r13, %r8
    1da6:      	movq	(%rsp), %rcx
    1daa:      	movl	$0x50, %r13d
    1db0:      	jmp	0x2e71 <generic_retuprobe_event+0x2e71>
    1db5:      	movq	0x8(%rsp), %r14
    1dba:      	leaq	0xc8(%r14), %rdx
    1dc1:      	movl	$0x4, %ecx
    1dc6:      	movl	$0x4, %eax
    1dcb:      	movl	$0x4, %esi
    1dd0:      	callq	*%rax
    1dd2:      	movq	(%rsp), %rax
    1dd6:      	leaq	0xa0(%rax), %rdi
    1ddd:      	leaq	0xcc(%r14), %rdx
    1de4:      	movl	$0x4, %ecx
    1de9:      	movl	$0x4, %eax
    1dee:      	movl	$0x4, %esi
    1df3:      	callq	*%rax
    1df5:      	movq	(%rsp), %rax
    1df9:      	leaq	0xa4(%rax), %rdi
    1e00:      	leaq	0xd0(%r14), %rdx
    1e07:      	movl	$0x4, %ecx
    1e0c:      	movl	$0x4, %eax
    1e11:      	movl	$0x4, %esi
    1e16:      	callq	*%rax
    1e18:      	movq	(%rsp), %rdi
    1e1c:      	addq	$0xa8, %rdi
    1e23:      	leaq	0x158(%r14), %rdx
    1e2a:      	movl	$0x4, %ecx
    1e2f:      	movl	$0x4, %eax
    1e34:      	movl	$0x4, %esi
    1e39:      	callq	*%rax
    1e3b:      	movq	%r14, %r8
    1e3e:      	movq	(%rsp), %rcx
    1e42:      	movl	$0x10, %r13d
    1e48:      	jmp	0x2e71 <generic_retuprobe_event+0x2e71>
    1e4d:      	movq	0x8(%rsp), %r14
    1e52:      	leaq	0x38(%r14), %rdx
    1e56:      	movl	$0x4, %ecx
    1e5b:      	movl	$0x4, %eax
    1e60:      	movl	$0x4, %esi
    1e65:      	callq	*%rax
    1e67:      	movq	(%rsp), %rax
    1e6b:      	leaq	0xa0(%rax), %rdi
    1e72:      	leaq	0x3c(%r14), %rdx
    1e76:      	movl	$0x4, %ecx
    1e7b:      	movl	$0x4, %eax
    1e80:      	movl	$0x4, %esi
    1e85:      	callq	*%rax
    1e87:      	movq	(%rsp), %rax
    1e8b:      	leaq	0xa4(%rax), %rdi
    1e92:      	leaq	0x40(%r14), %rdx
    1e96:      	movl	$0x4, %ecx
    1e9b:      	movl	$0x4, %eax
    1ea0:      	movl	$0x4, %esi
    1ea5:      	callq	*%rax
    1ea7:      	movq	(%rsp), %rax
    1eab:      	leaq	0xa8(%rax), %rdi
    1eb2:      	leaq	0x44(%r14), %rdx
    1eb6:      	movl	$0x4, %ecx
    1ebb:      	movl	$0x4, %eax
    1ec0:      	movl	$0x4, %esi
    1ec5:      	callq	*%rax
    1ec7:      	movq	(%rsp), %rdi
    1ecb:      	addq	$0xac, %rdi
    1ed2:      	leaq	0x80(%r14), %rdx
    1ed9:      	movl	$0x10, %ecx
    1ede:      	movl	$0x4, %eax
    1ee3:      	movl	$0x10, %esi
    1ee8:      	callq	*%rax
    1eea:      	movq	%r14, %r8
    1eed:      	movq	(%rsp), %rcx
    1ef1:      	movl	$0x20, %r13d
    1ef7:      	jmp	0x2e71 <generic_retuprobe_event+0x2e71>
    1efc:      	movl	$0x4, %ecx
    1f01:      	movl	$0x4, %eax
    1f06:      	movq	0x8(%rsp), %r14
    1f0b:      	movl	$0x4, %esi
    1f10:      	movq	%r14, %rdx
    1f13:      	callq	*%rax
    1f15:      	movq	(%rsp), %rax
    1f19:      	leaq	0xa0(%rax), %rdi
    1f20:      	leaq	0x4(%r14), %rdx
    1f24:      	movl	$0x4, %ecx
    1f29:      	movl	$0x4, %eax
    1f2e:      	movl	$0x4, %esi
    1f33:      	callq	*%rax
    1f35:      	movq	(%rsp), %rdi
    1f39:      	addq	$0xa4, %rdi
    1f40:      	leaq	0x30(%r14), %rdx
    1f44:      	movl	$0x10, %ecx
    1f49:      	movl	$0x4, %eax
    1f4e:      	movl	$0x10, %esi
    1f53:      	callq	*%rax
    1f55:      	movq	%r14, %r8
    1f58:      	movq	(%rsp), %rcx
    1f5c:      	movl	$0x18, %r13d
    1f62:      	jmp	0x2e71 <generic_retuprobe_event+0x2e71>
    1f67:      	movq	0x8(%rsp), %r13
    1f6c:      	leaq	0x4(%r13), %rdx
    1f70:      	leaq	0x38(%rsp), %rdi
    1f75:      	movl	$0x4, %ecx
    1f7a:      	movl	$0x4, %eax
    1f7f:      	movl	$0x4, %esi
    1f84:      	callq	*%rax
    1f86:      	movl	0x38(%rsp), %eax
    1f8a:      	movq	(%rsp), %r14
    1f8e:      	movl	%eax, 0x9c(%r14)
    1f95:      	leaq	0xc(%r13), %rdx
    1f99:      	leaq	0x38(%rsp), %rdi
    1f9e:      	movl	$0x4, %ecx
    1fa3:      	movl	$0x4, %eax
    1fa8:      	movl	$0x4, %esi
    1fad:      	callq	*%rax
    1faf:      	movl	0x38(%rsp), %eax
    1fb3:      	movl	%eax, 0xa0(%r14)
    1fba:      	leaq	0x50(%r13), %rdx
    1fbe:      	leaq	0x38(%rsp), %rdi
    1fc3:      	movl	$0x8, %ecx
    1fc8:      	movl	$0x2d, %eax
    1fcd:      	movl	$0x8, %esi
    1fd2:      	callq	*%rax
    1fd4:      	movq	%r14, %rdi
    1fd7:      	addq	$0xa4, %rdi
    1fde:      	movl	$0x3f8, %edx            # imm = 0x3F8
    1fe3:      	movq	0x38(%rsp), %rcx
    1fe8:      	addq	%rdx, %rcx
    1feb:      	movl	$0x10, %esi
    1ff0:      	movl	$0x2d, %eax
    1ff5:      	addq	0x38(%rsp), %rdx
    1ffa:      	movl	$0x10, %esi
    1fff:      	callq	*%rax
    2001:      	movq	%r13, %r8
    2004:      	movq	%r14, %rcx
    2007:      	movl	$0x18, %r13d
    200d:      	jmp	0x2e71 <generic_retuprobe_event+0x2e71>
    2012:      	movq	$0x0, 0x48(%rdi)
    201a:      	movq	$0x0, 0x40(%rdi)
    2022:      	movq	$0x0, 0x38(%rdi)
    202a:      	movq	$0x0, 0x30(%rdi)
    2032:      	movq	$0x0, 0x28(%rdi)
    203a:      	movq	$0x0, 0x20(%rdi)
    2042:      	movq	$0x0, 0x18(%rdi)
    204a:      	movq	$0x0, 0x10(%rdi)
    2052:      	movq	$0x0, 0x8(%rdi)
    205a:      	movq	%rdi, 0x30(%rsp)
    205f:      	movq	$0x0, (%rdi)
    2066:      	leaq	0x38(%rsp), %rdi
    206b:      	movl	$0x8, %ecx
    2070:      	movl	$0x4, %eax
    2075:      	movq	0x8(%rsp), %rdx
    207a:      	movl	$0x8, %esi
    207f:      	callq	*%rax
    2081:      	testq	%rax, %rax
    2084:      	je	0x2349 <generic_retuprobe_event+0x2349>
    208a:      	xorl	%r13d, %r13d
    208d:      	movq	0x8(%rsp), %r8
    2092:      	jmp	0x2566 <generic_retuprobe_event+0x2566>
    2097:      	movq	$-0x1, %r13
    209e:      	jmp	0x2e5d <generic_retuprobe_event+0x2e5d>
    20a3:      	leaq	0x10(%r14), %rdx
    20a7:      	leaq	0x78(%rsp), %rdi
    20ac:      	movl	$0x8, %ecx
    20b1:      	movl	$0x4, %eax
    20b6:      	movl	$0x8, %esi
    20bb:      	callq	*%rax
    20bd:      	addq	$0x18, %r14
    20c1:      	leaq	0x90(%rsp), %rdi
    20c9:      	movl	$0x8, %ecx
    20ce:      	movl	$0x4, %eax
    20d3:      	movl	$0x8, %esi
    20d8:      	movq	%r14, %rdx
    20db:      	callq	*%rax
    20dd:      	movq	0x78(%rsp), %rdx
    20e2:      	movq	0x90(%rsp), %r14
    20ea:      	cmpq	$0xfff, %r14            # imm = 0xFFF
    20f1:      	movl	$0xfff, %r13d           # imm = 0xFFF
    20f7:      	cmovbq	%r14, %r13
    20fb:      	movq	0x10(%rsp), %rdi
    2100:      	addq	$0xa4, %rdi
    2107:      	movl	$0x4, %eax
    210c:      	movl	%r13d, %esi
    210f:      	callq	*%rax
    2111:      	testl	%eax, %eax
    2113:      	js	0x2426 <generic_retuprobe_event+0x2426>
    2119:      	movq	0x10(%rsp), %r12
    211e:      	movl	%r14d, 0x9c(%r12)
    2126:      	movl	%r13d, 0xa0(%r12)
    212e:      	addq	$0x8, %r13
    2132:      	jmp	0x243b <generic_retuprobe_event+0x243b>
    2137:      	movq	%r13, 0xa0(%rsp)
    213f:      	movq	%rbx, 0x10(%rsp)
    2144:      	movq	0x38(%rsp), %r14
    2149:      	movl	$0x0, 0x78(%rsp)
    2151:      	movzwl	0xb0(%rsp), %r12d
    215a:      	movq	(%rip), %rdi            # 0x2161 <generic_retuprobe_event+0x2161>
    2161:      	leaq	0x78(%rsp), %rsi
    2166:      	movl	$0x1, %eax
    216b:      	leaq	(%r14,%r12), %rcx
    216f:      	movq	%rcx, 0xe8(%rsp)
    2177:      	callq	*%rax
    2179:      	testq	%rax, %rax
    217c:      	je	0x2c66 <generic_retuprobe_event+0x2c66>
    2182:      	movq	%rax, %r13
    2185:      	movw	%r12w, (%rax)
    2189:      	movb	$-0x1, 0x5(%rax)
    218d:      	movb	$0x0, 0x7(%rax)
    2191:      	movq	%rax, %rbx
    2194:      	addq	$0x6, %rbx
    2198:      	movq	0xe8(%rsp), %rax
    21a0:      	leaq	0x6(%rax), %rdx
    21a4:      	movl	$0x1, %ecx
    21a9:      	movl	$0x4, %eax
    21ae:      	movq	%rbx, %rdi
    21b1:      	movl	$0x1, %esi
    21b6:      	callq	*%rax
    21b8:      	testq	%rax, %rax
    21bb:      	js	0x2c66 <generic_retuprobe_event+0x2c66>
    21c1:      	movzbl	0x5(%r13), %eax
    21c6:      	cmpl	$0x32, %eax
    21c9:      	jg	0x2574 <generic_retuprobe_event+0x2574>
    21cf:      	testl	%eax, %eax
    21d1:      	je	0x259d <generic_retuprobe_event+0x259d>
    21d7:      	cmpl	$0x2b, %eax
    21da:      	je	0x259d <generic_retuprobe_event+0x259d>
    21e0:      	cmpl	$0x2c, %eax
    21e3:      	jne	0x2754 <generic_retuprobe_event+0x2754>
    21e9:      	movw	$0x8, 0x2(%r13)
    21f0:      	movw	$0x8, %ax
    21f4:      	jmp	0x26a2 <generic_retuprobe_event+0x26a2>
    21f9:      	leaq	0x48(%r13), %rdx
    21fd:      	movl	$0x10, %ecx
    2202:      	movl	$0x4, %eax
    2207:      	movl	$0x10, %esi
    220c:      	callq	*%rax
    220e:      	leaq	0x38(%r13), %rdx
    2212:      	movl	$0x10, %ecx
    2217:      	movl	$0x4, %eax
    221c:      	movq	%r14, %rdi
    221f:      	movl	$0x10, %esi
    2224:      	callq	*%rax
    2226:      	movq	(%rsp), %r12
    222a:      	leaq	0xbc(%r12), %rdi
    2232:      	leaq	0xc(%r13), %r14
    2236:      	addq	$0xe, %r13
    223a:      	movl	$0x2, %ecx
    223f:      	movl	$0x4, %eax
    2244:      	movl	$0x2, %esi
    2249:      	movq	%r13, %rdx
    224c:      	callq	*%rax
    224e:      	movq	%r12, %rdi
    2251:      	addq	$0xbe, %rdi
    2258:      	movl	$0x2, %ecx
    225d:      	movl	$0x4, %eax
    2262:      	movl	$0x2, %esi
    2267:      	movq	%r14, %rdx
    226a:      	callq	*%rax
    226c:      	movzwl	0xbe(%r12), %eax
    2275:      	movbew	%ax, 0xbe(%r12)
    2280:      	movq	0x18(%rsp), %rax
    2285:      	movq	%rax, 0x38(%rsp)
    228a:      	movq	(%rip), %rdi            # 0x2291 <generic_retuprobe_event+0x2291>
    2291:      	leaq	0x38(%rsp), %rsi
    2296:      	movl	$0x1, %eax
    229b:      	callq	*%rax
    229d:      	testq	%rax, %rax
    22a0:      	je	0x2e57 <generic_retuprobe_event+0x2e57>
    22a6:      	movl	(%rax), %ecx
    22a8:      	movq	0x10(%rsp), %r12
    22ad:      	movl	%ecx, 0x10(%r12)
    22b2:      	movq	0x8(%rax), %rcx
    22b6:      	movq	%rcx, 0x18(%r12)
    22bb:      	movl	0x4(%rax), %eax
    22be:      	movl	%eax, 0x7c(%r12)
    22c3:      	jmp	0x2e57 <generic_retuprobe_event+0x2e57>
    22c8:      	movq	0x10(%rsp), %rax
    22cd:      	movq	$0x0, 0x9c(%rax)
    22d8:      	movl	$0x8, %r13d
    22de:      	jmp	0x2e5d <generic_retuprobe_event+0x2e5d>
    22e3:      	leaq	0xa4(%rcx), %rdi
    22ea:      	leaq	0x8(%r12), %rdx
    22ef:      	movq	%rcx, %r14
    22f2:      	movl	$0x10, %ecx
    22f7:      	movl	$0x4, %eax
    22fc:      	movl	$0x10, %esi
    2301:      	callq	*%rax
    2303:      	movq	%r14, %rdi
    2306:      	addq	$0x9e, %rdi
    230d:      	addq	$0x2, %r12
    2311:      	movl	$0x2, %ecx
    2316:      	movl	$0x4, %eax
    231b:      	movl	$0x2, %esi
    2320:      	movq	%r12, %rdx
    2323:      	callq	*%rax
    2325:      	movq	(%rsp), %rcx
    2329:      	movzwl	0x9e(%rcx), %eax
    2330:      	movbew	%ax, 0x9e(%rcx)
    2339:      	movq	0x20(%rsp), %r15
    233e:      	movl	$0x18, %r13d
    2344:      	jmp	0x2e61 <generic_retuprobe_event+0x2e61>
    2349:      	movq	(%rsp), %rax
    234d:      	leaq	0xac(%rax), %rdi
    2354:      	movq	0x38(%rsp), %rcx
    2359:      	movl	$0x3f, %edx
    235e:      	movl	$0x2d, %eax
    2363:      	movq	0x38(%rsp), %rdx
    2368:      	movl	$0x3f, %esi
    236d:      	callq	*%rax
    236f:      	testq	%rax, %rax
    2372:      	js	0x208a <generic_retuprobe_event+0x208a>
    2378:      	movq	0x8(%rsp), %r14
    237d:      	leaq	0x8(%r14), %rdx
    2381:      	leaq	0x78(%rsp), %rdi
    2386:      	movl	$0x8, %ecx
    238b:      	movl	$0x4, %eax
    2390:      	movl	$0x8, %esi
    2395:      	callq	*%rax
    2397:      	movq	(%rsp), %rdi
    239b:      	addq	$0xa4, %rdi
    23a2:      	movl	$0x348, %edx            # imm = 0x348
    23a7:      	movq	0x78(%rsp), %rcx
    23ac:      	addq	%rdx, %rcx
    23af:      	movl	$0x8, %esi
    23b4:      	movl	$0x4, %eax
    23b9:      	addq	0x78(%rsp), %rdx
    23be:      	movl	$0x8, %esi
    23c3:      	callq	*%rax
    23c5:      	leaq	0x58(%r14), %rdx
    23c9:      	leaq	0x78(%rsp), %rdi
    23ce:      	movl	$0x4, %ecx
    23d3:      	movl	$0x4, %eax
    23d8:      	movl	$0x4, %esi
    23dd:      	callq	*%rax
    23df:      	movl	$0x50, %r13d
    23e5:      	testq	%rax, %rax
    23e8:      	jne	0x208d <generic_retuprobe_event+0x208d>
    23ee:      	xorl	%eax, %eax
    23f0:      	cmpl	$0x0, 0x78(%rsp)
    23f5:      	setne	%al
    23f8:      	movq	0x30(%rsp), %rcx
    23fd:      	movl	%eax, (%rcx)
    23ff:      	jmp	0x208d <generic_retuprobe_event+0x208d>
    2404:      	xorl	%r13d, %r13d
    2407:      	movq	(%rsp), %rcx
    240b:      	movq	0x8(%rsp), %r8
    2410:      	jmp	0x2e71 <generic_retuprobe_event+0x2e71>
    2415:      	movq	0x10(%rsp), %rax
    241a:      	movl	$0xfffffffe, 0x9c(%rax) # imm = 0xFFFFFFFE
    2424:      	jmp	0x243b <generic_retuprobe_event+0x243b>
    2426:      	movq	0x10(%rsp), %rax
    242b:      	movl	$0xfffffffe, 0x9c(%rax) # imm = 0xFFFFFFFE
    2435:      	movl	$0x4, %r13d
    243b:      	movq	(%rsp), %rcx
    243f:      	movq	0x20(%rsp), %r15
    2444:      	jmp	0x2e61 <generic_retuprobe_event+0x2e61>
    2449:      	addq	$0x3, %r12
    244d:      	movl	$0x6b, %ecx
    2452:      	movl	$0x71, %eax
    2457:      	movl	$0x6b, %esi
    245c:      	movq	%r12, %rdx
    245f:      	callq	*%rax
    2461:      	movq	%rax, %rcx
    2464:      	movb	$0x6b, %al
    2466:      	testl	%ecx, %ecx
    2468:      	js	0x2474 <generic_retuprobe_event+0x2474>
    246a:      	movq	(%rsp), %rcx
    246e:      	movb	%al, 0x9f(%rcx)
    2474:      	movl	$0x70, %r13d
    247a:      	jmp	0x2e5d <generic_retuprobe_event+0x2e5d>
    247f:      	leaq	0x48(%r13), %rdx
    2483:      	movl	$0x10, %ecx
    2488:      	movl	$0x4, %eax
    248d:      	movq	0x30(%rsp), %rdi
    2492:      	movl	$0x10, %esi
    2497:      	callq	*%rax
    2499:      	leaq	0x38(%r13), %rdx
    249d:      	movl	$0x10, %ecx
    24a2:      	movl	$0x4, %eax
    24a7:      	movq	%r14, %rdi
    24aa:      	movl	$0x10, %esi
    24af:      	callq	*%rax
    24b1:      	movq	(%rsp), %r12
    24b5:      	leaq	0xbc(%r12), %rdi
    24bd:      	leaq	0xc(%r13), %r14
    24c1:      	addq	$0xe, %r13
    24c5:      	movl	$0x2, %ecx
    24ca:      	movl	$0x4, %eax
    24cf:      	movl	$0x2, %esi
    24d4:      	movq	%r13, %rdx
    24d7:      	callq	*%rax
    24d9:      	movq	%r12, %rdi
    24dc:      	addq	$0xbe, %rdi
    24e3:      	movl	$0x2, %ecx
    24e8:      	movl	$0x4, %eax
    24ed:      	movl	$0x2, %esi
    24f2:      	movq	%r14, %rdx
    24f5:      	callq	*%rax
    24f7:      	movzwl	0xbe(%r12), %eax
    2500:      	movbew	%ax, 0xbe(%r12)
    250b:      	movq	(%rsp), %rax
    250f:      	movq	0xc4(%rax), %rax
    2516:      	movq	%rax, 0x38(%rsp)
    251b:      	movq	(%rip), %rdi            # 0x2522 <generic_retuprobe_event+0x2522>
    2522:      	leaq	0x38(%rsp), %rsi
    2527:      	movl	$0x1, %eax
    252c:      	callq	*%rax
    252e:      	testq	%rax, %rax
    2531:      	je	0x2550 <generic_retuprobe_event+0x2550>
    2533:      	movl	(%rax), %ecx
    2535:      	movq	0x10(%rsp), %r12
    253a:      	movl	%ecx, 0x10(%r12)
    253f:      	movq	0x8(%rax), %rcx
    2543:      	movq	%rcx, 0x18(%r12)
    2548:      	movl	0x4(%rax), %eax
    254b:      	movl	%eax, 0x7c(%r12)
    2550:      	movl	$0x40, %r13d
    2556:      	movq	%rbp, %r12
    2559:      	movq	0x8(%rsp), %r8
    255e:      	movq	0x88(%rsp), %rbp
    2566:      	movq	(%rsp), %rcx
    256a:      	movq	0x20(%rsp), %r15
    256f:      	jmp	0x2e71 <generic_retuprobe_event+0x2e71>
    2574:      	cmpl	$0x33, %eax
    2577:      	je	0x2691 <generic_retuprobe_event+0x2691>
    257d:      	cmpl	$0x3c, %eax
    2580:      	je	0x259d <generic_retuprobe_event+0x259d>
    2582:      	cmpl	$0xff, %eax
    2587:      	jne	0x2754 <generic_retuprobe_event+0x2754>
    258d:      	movw	$0x28, 0x2(%r13)
    2594:      	movw	$0x28, %ax
    2598:      	jmp	0x26a2 <generic_retuprobe_event+0x26a2>
    259d:      	movzbl	0x7(%r13), %eax
    25a2:      	leal	0x8(,%rax,8), %eax
    25a9:      	jmp	0x269d <generic_retuprobe_event+0x269d>
    25ae:      	xorl	%eax, %eax
    25b0:      	movq	%rax, 0x8(%rsp)
    25b5:      	cmpq	$0x3, 0xb8(%rsp)
    25be:      	jne	0x25d7 <generic_retuprobe_event+0x25d7>
    25c0:      	movq	%r13, %rbp
    25c3:      	movq	0x10(%rsp), %rbx
    25c8:      	movq	0x28(%rsp), %rax
    25cd:      	movq	0x20(%rsp), %r15
    25d2:      	jmp	0x320 <generic_retuprobe_event+0x320>
    25d7:      	movq	0x88(%rsp), %rax
    25df:      	leaq	0x30(%rax), %rdx
    25e3:      	leaq	0x38(%rsp), %rdi
    25e8:      	movl	$0x4, %r12d
    25ee:      	movl	$0x10, %ecx
    25f3:      	movl	$0x4, %eax
    25f8:      	movl	$0x10, %esi
    25fd:      	callq	*%rax
    25ff:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2604:      	testl	%eax, %eax
    2606:      	js	0x3378 <generic_retuprobe_event+0x3378>
    260c:      	movq	0x40(%rsp), %rdx
    2611:      	movq	0x8(%rsp), %rax
    2616:      	cmpq	%rax, %rdx
    2619:      	movq	%rax, %rbx
    261c:      	cmovbq	%rdx, %rbx
    2620:      	testq	%rax, %rax
    2623:      	cmovneq	%rbx, %rdx
    2627:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    262c:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    2633:      	ja	0x3378 <generic_retuprobe_event+0x3378>
    2639:      	movq	%rdx, %r14
    263c:      	movq	%r15, %rdi
    263f:      	addq	(%rsp), %rdi
    2643:      	movq	%rdi, %r15
    2646:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    264c:      	addq	0x20(%rsp), %rdi
    2651:      	movq	0x38(%rsp), %rcx
    2656:      	movl	$0x4, %eax
    265b:      	movq	%rdx, %rsi
    265e:      	movq	0x38(%rsp), %rdx
    2663:      	callq	*%rax
    2665:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    266a:      	testl	%eax, %eax
    266c:      	js	0x3378 <generic_retuprobe_event+0x3378>
    2672:      	addq	%r14, %r13
    2675:      	cmpq	$0x0, 0x8(%rsp)
    267b:      	je	0x29b3 <generic_retuprobe_event+0x29b3>
    2681:      	subq	%rbx, 0x8(%rsp)
    2686:      	jne	0x29ba <generic_retuprobe_event+0x29ba>
    268c:      	jmp	0x25c0 <generic_retuprobe_event+0x25c0>
    2691:      	movzbl	0x7(%r13), %eax
    2696:      	leal	0x8(,%rax,4), %eax
    269d:      	movw	%ax, 0x2(%r13)
    26a2:      	addw	(%r13), %ax
    26a7:      	movw	%ax, (%r13)
    26ac:      	movzbl	0x6(%r13), %ecx
    26b1:      	cmpq	$0x3c, %rcx
    26b5:      	ja	0x3200 <generic_retuprobe_event+0x3200>
    26bb:      	movabsq	$0x1008180000000001, %r12 # imm = 0x1008180000000001
    26c5:      	btq	%rcx, %r12
    26c9:      	jae	0x3200 <generic_retuprobe_event+0x3200>
    26cf:      	movb	%cl, 0x5(%r13)
    26d3:      	movzwl	%ax, %ecx
    26d6:      	addq	%r14, %rcx
    26d9:      	movl	$0x2, %edx
    26de:      	movl	$0x4, %eax
    26e3:      	movzwl	(%r13), %edx
    26e8:      	addq	%r14, %rdx
    26eb:      	movq	%rbx, %rdi
    26ee:      	movl	$0x2, %esi
    26f3:      	callq	*%rax
    26f5:      	testq	%rax, %rax
    26f8:      	js	0x2c66 <generic_retuprobe_event+0x2c66>
    26fe:      	movzbl	0x5(%r13), %eax
    2703:      	cmpl	$0x32, %eax
    2706:      	jg	0x2723 <generic_retuprobe_event+0x2723>
    2708:      	testl	%eax, %eax
    270a:      	je	0x2741 <generic_retuprobe_event+0x2741>
    270c:      	cmpl	$0x2b, %eax
    270f:      	je	0x2741 <generic_retuprobe_event+0x2741>
    2711:      	cmpl	$0x2c, %eax
    2714:      	jne	0x2771 <generic_retuprobe_event+0x2771>
    2716:      	movw	$0x8, 0x2(%r13)
    271d:      	movw	$0x8, %ax
    2721:      	jmp	0x2776 <generic_retuprobe_event+0x2776>
    2723:      	cmpl	$0x33, %eax
    2726:      	je	0x275e <generic_retuprobe_event+0x275e>
    2728:      	cmpl	$0x3c, %eax
    272b:      	je	0x2741 <generic_retuprobe_event+0x2741>
    272d:      	cmpl	$0xff, %eax
    2732:      	jne	0x2771 <generic_retuprobe_event+0x2771>
    2734:      	movw	$0x28, 0x2(%r13)
    273b:      	movw	$0x28, %ax
    273f:      	jmp	0x2776 <generic_retuprobe_event+0x2776>
    2741:      	movzbl	0x7(%r13), %eax
    2746:      	leal	0x8(,%rax,8), %eax
    274d:      	movw	%ax, 0x2(%r13)
    2752:      	jmp	0x2776 <generic_retuprobe_event+0x2776>
    2754:      	movzwl	0x2(%r13), %eax
    2759:      	jmp	0x26a2 <generic_retuprobe_event+0x26a2>
    275e:      	movzbl	0x7(%r13), %eax
    2763:      	leal	0x8(,%rax,4), %eax
    276a:      	movw	%ax, 0x2(%r13)
    276f:      	jmp	0x2776 <generic_retuprobe_event+0x2776>
    2771:      	movzwl	0x2(%r13), %eax
    2776:      	addw	(%r13), %ax
    277b:      	movw	%ax, (%r13)
    2780:      	movzbl	0x6(%r13), %ecx
    2785:      	cmpq	$0x3c, %rcx
    2789:      	ja	0x3200 <generic_retuprobe_event+0x3200>
    278f:      	btq	%rcx, %r12
    2793:      	jae	0x3200 <generic_retuprobe_event+0x3200>
    2799:      	movb	%cl, 0x5(%r13)
    279d:      	movzwl	%ax, %ecx
    27a0:      	addq	%r14, %rcx
    27a3:      	movl	$0x2, %edx
    27a8:      	movl	$0x4, %eax
    27ad:      	movzwl	(%r13), %edx
    27b2:      	addq	%r14, %rdx
    27b5:      	movq	%rbx, %rdi
    27b8:      	movl	$0x2, %esi
    27bd:      	callq	*%rax
    27bf:      	testq	%rax, %rax
    27c2:      	js	0x2c66 <generic_retuprobe_event+0x2c66>
    27c8:      	movzbl	0x5(%r13), %eax
    27cd:      	cmpl	$0x32, %eax
    27d0:      	jg	0x27ed <generic_retuprobe_event+0x27ed>
    27d2:      	testl	%eax, %eax
    27d4:      	je	0x280b <generic_retuprobe_event+0x280b>
    27d6:      	cmpl	$0x2b, %eax
    27d9:      	je	0x280b <generic_retuprobe_event+0x280b>
    27db:      	cmpl	$0x2c, %eax
    27de:      	jne	0x2831 <generic_retuprobe_event+0x2831>
    27e0:      	movw	$0x8, 0x2(%r13)
    27e7:      	movw	$0x8, %ax
    27eb:      	jmp	0x2836 <generic_retuprobe_event+0x2836>
    27ed:      	cmpl	$0x33, %eax
    27f0:      	je	0x281e <generic_retuprobe_event+0x281e>
    27f2:      	cmpl	$0x3c, %eax
    27f5:      	je	0x280b <generic_retuprobe_event+0x280b>
    27f7:      	cmpl	$0xff, %eax
    27fc:      	jne	0x2831 <generic_retuprobe_event+0x2831>
    27fe:      	movw	$0x28, 0x2(%r13)
    2805:      	movw	$0x28, %ax
    2809:      	jmp	0x2836 <generic_retuprobe_event+0x2836>
    280b:      	movzbl	0x7(%r13), %eax
    2810:      	leal	0x8(,%rax,8), %eax
    2817:      	movw	%ax, 0x2(%r13)
    281c:      	jmp	0x2836 <generic_retuprobe_event+0x2836>
    281e:      	movzbl	0x7(%r13), %eax
    2823:      	leal	0x8(,%rax,4), %eax
    282a:      	movw	%ax, 0x2(%r13)
    282f:      	jmp	0x2836 <generic_retuprobe_event+0x2836>
    2831:      	movzwl	0x2(%r13), %eax
    2836:      	addw	(%r13), %ax
    283b:      	movw	%ax, (%r13)
    2840:      	movzbl	0x6(%r13), %ecx
    2845:      	cmpq	$0x3c, %rcx
    2849:      	ja	0x3200 <generic_retuprobe_event+0x3200>
    284f:      	btq	%rcx, %r12
    2853:      	jae	0x3200 <generic_retuprobe_event+0x3200>
    2859:      	movb	%cl, 0x5(%r13)
    285d:      	movzwl	%ax, %ecx
    2860:      	addq	%r14, %rcx
    2863:      	movl	$0x2, %edx
    2868:      	movl	$0x4, %eax
    286d:      	movzwl	(%r13), %edx
    2872:      	addq	%r14, %rdx
    2875:      	movq	%rbx, %rdi
    2878:      	movl	$0x2, %esi
    287d:      	callq	*%rax
    287f:      	testq	%rax, %rax
    2882:      	js	0x2c66 <generic_retuprobe_event+0x2c66>
    2888:      	movzbl	0x5(%r13), %eax
    288d:      	cmpl	$0x32, %eax
    2890:      	jg	0x28ad <generic_retuprobe_event+0x28ad>
    2892:      	testl	%eax, %eax
    2894:      	je	0x28cb <generic_retuprobe_event+0x28cb>
    2896:      	cmpl	$0x2b, %eax
    2899:      	je	0x28cb <generic_retuprobe_event+0x28cb>
    289b:      	cmpl	$0x2c, %eax
    289e:      	jne	0x28f1 <generic_retuprobe_event+0x28f1>
    28a0:      	movw	$0x8, 0x2(%r13)
    28a7:      	movw	$0x8, %ax
    28ab:      	jmp	0x28f6 <generic_retuprobe_event+0x28f6>
    28ad:      	cmpl	$0x33, %eax
    28b0:      	je	0x28de <generic_retuprobe_event+0x28de>
    28b2:      	cmpl	$0x3c, %eax
    28b5:      	je	0x28cb <generic_retuprobe_event+0x28cb>
    28b7:      	cmpl	$0xff, %eax
    28bc:      	jne	0x28f1 <generic_retuprobe_event+0x28f1>
    28be:      	movw	$0x28, 0x2(%r13)
    28c5:      	movw	$0x28, %ax
    28c9:      	jmp	0x28f6 <generic_retuprobe_event+0x28f6>
    28cb:      	movzbl	0x7(%r13), %eax
    28d0:      	leal	0x8(,%rax,8), %eax
    28d7:      	movw	%ax, 0x2(%r13)
    28dc:      	jmp	0x28f6 <generic_retuprobe_event+0x28f6>
    28de:      	movzbl	0x7(%r13), %eax
    28e3:      	leal	0x8(,%rax,4), %eax
    28ea:      	movw	%ax, 0x2(%r13)
    28ef:      	jmp	0x28f6 <generic_retuprobe_event+0x28f6>
    28f1:      	movzwl	0x2(%r13), %eax
    28f6:      	addw	(%r13), %ax
    28fb:      	movw	%ax, (%r13)
    2900:      	movzbl	0x6(%r13), %ecx
    2905:      	cmpq	$0x3c, %rcx
    2909:      	ja	0x3200 <generic_retuprobe_event+0x3200>
    290f:      	btq	%rcx, %r12
    2913:      	jae	0x3200 <generic_retuprobe_event+0x3200>
    2919:      	movb	%cl, 0x5(%r13)
    291d:      	movzwl	%ax, %ecx
    2920:      	addq	%r14, %rcx
    2923:      	movl	$0x2, %edx
    2928:      	movl	$0x4, %eax
    292d:      	movzwl	(%r13), %edx
    2932:      	addq	%r14, %rdx
    2935:      	movq	%rbx, %rdi
    2938:      	movl	$0x2, %esi
    293d:      	callq	*%rax
    293f:      	testq	%rax, %rax
    2942:      	js	0x2c66 <generic_retuprobe_event+0x2c66>
    2948:      	movzbl	0x5(%r13), %eax
    294d:      	cmpl	$0x32, %eax
    2950:      	jg	0x2974 <generic_retuprobe_event+0x2974>
    2952:      	testl	%eax, %eax
    2954:      	je	0x299d <generic_retuprobe_event+0x299d>
    2956:      	cmpl	$0x2b, %eax
    2959:      	je	0x299d <generic_retuprobe_event+0x299d>
    295b:      	cmpl	$0x2c, %eax
    295e:      	jne	0x2a98 <generic_retuprobe_event+0x2a98>
    2964:      	movw	$0x8, 0x2(%r13)
    296b:      	movw	$0x8, %ax
    296f:      	jmp	0x2a9d <generic_retuprobe_event+0x2a9d>
    2974:      	cmpl	$0x33, %eax
    2977:      	je	0x2a85 <generic_retuprobe_event+0x2a85>
    297d:      	cmpl	$0x3c, %eax
    2980:      	je	0x299d <generic_retuprobe_event+0x299d>
    2982:      	cmpl	$0xff, %eax
    2987:      	jne	0x2a98 <generic_retuprobe_event+0x2a98>
    298d:      	movw	$0x28, 0x2(%r13)
    2994:      	movw	$0x28, %ax
    2998:      	jmp	0x2a9d <generic_retuprobe_event+0x2a9d>
    299d:      	movzbl	0x7(%r13), %eax
    29a2:      	leal	0x8(,%rax,8), %eax
    29a9:      	movw	%ax, 0x2(%r13)
    29ae:      	jmp	0x2a9d <generic_retuprobe_event+0x2a9d>
    29b3:      	xorl	%eax, %eax
    29b5:      	movq	%rax, 0x8(%rsp)
    29ba:      	cmpq	$0x5, 0xb8(%rsp)
    29c3:      	jb	0x25c0 <generic_retuprobe_event+0x25c0>
    29c9:      	movq	0x88(%rsp), %rax
    29d1:      	leaq	0x40(%rax), %rdx
    29d5:      	leaq	0x38(%rsp), %rdi
    29da:      	movl	$0x4, %r12d
    29e0:      	movl	$0x10, %ecx
    29e5:      	movl	$0x4, %eax
    29ea:      	movl	$0x10, %esi
    29ef:      	callq	*%rax
    29f1:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    29f6:      	testl	%eax, %eax
    29f8:      	js	0x3378 <generic_retuprobe_event+0x3378>
    29fe:      	movq	0x40(%rsp), %rdx
    2a03:      	movq	0x8(%rsp), %rax
    2a08:      	cmpq	%rax, %rdx
    2a0b:      	movq	%rax, %rbx
    2a0e:      	cmovbq	%rdx, %rbx
    2a12:      	testq	%rax, %rax
    2a15:      	cmovneq	%rbx, %rdx
    2a19:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2a1e:      	movq	%rdx, (%rsp)
    2a22:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    2a29:      	ja	0x3378 <generic_retuprobe_event+0x3378>
    2a2f:      	movq	%r14, %rdi
    2a32:      	addq	%r15, %rdi
    2a35:      	movq	%rdi, %r14
    2a38:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2a3e:      	addq	0x20(%rsp), %rdi
    2a43:      	movq	0x38(%rsp), %rcx
    2a48:      	movl	$0x4, %eax
    2a4d:      	movq	(%rsp), %rsi
    2a51:      	movq	0x38(%rsp), %rdx
    2a56:      	callq	*%rax
    2a58:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2a5d:      	testl	%eax, %eax
    2a5f:      	js	0x3378 <generic_retuprobe_event+0x3378>
    2a65:      	addq	(%rsp), %r13
    2a69:      	cmpq	$0x0, 0x8(%rsp)
    2a6f:      	je	0x320d <generic_retuprobe_event+0x320d>
    2a75:      	subq	%rbx, 0x8(%rsp)
    2a7a:      	jne	0x3214 <generic_retuprobe_event+0x3214>
    2a80:      	jmp	0x25c0 <generic_retuprobe_event+0x25c0>
    2a85:      	movzbl	0x7(%r13), %eax
    2a8a:      	leal	0x8(,%rax,4), %eax
    2a91:      	movw	%ax, 0x2(%r13)
    2a96:      	jmp	0x2a9d <generic_retuprobe_event+0x2a9d>
    2a98:      	movzwl	0x2(%r13), %eax
    2a9d:      	addw	(%r13), %ax
    2aa2:      	movw	%ax, (%r13)
    2aa7:      	movzbl	0x6(%r13), %ecx
    2aac:      	cmpq	$0x3c, %rcx
    2ab0:      	ja	0x3200 <generic_retuprobe_event+0x3200>
    2ab6:      	btq	%rcx, %r12
    2aba:      	jae	0x3200 <generic_retuprobe_event+0x3200>
    2ac0:      	movb	%cl, 0x5(%r13)
    2ac4:      	movzwl	%ax, %ecx
    2ac7:      	addq	%r14, %rcx
    2aca:      	movl	$0x2, %edx
    2acf:      	movl	$0x4, %eax
    2ad4:      	movzwl	(%r13), %edx
    2ad9:      	addq	%r14, %rdx
    2adc:      	movq	%rbx, %rdi
    2adf:      	movl	$0x2, %esi
    2ae4:      	callq	*%rax
    2ae6:      	testq	%rax, %rax
    2ae9:      	js	0x2c66 <generic_retuprobe_event+0x2c66>
    2aef:      	movzbl	0x5(%r13), %eax
    2af4:      	cmpl	$0x32, %eax
    2af7:      	jg	0x2b14 <generic_retuprobe_event+0x2b14>
    2af9:      	testl	%eax, %eax
    2afb:      	je	0x2b32 <generic_retuprobe_event+0x2b32>
    2afd:      	cmpl	$0x2b, %eax
    2b00:      	je	0x2b32 <generic_retuprobe_event+0x2b32>
    2b02:      	cmpl	$0x2c, %eax
    2b05:      	jne	0x2b58 <generic_retuprobe_event+0x2b58>
    2b07:      	movw	$0x8, 0x2(%r13)
    2b0e:      	movw	$0x8, %ax
    2b12:      	jmp	0x2b5d <generic_retuprobe_event+0x2b5d>
    2b14:      	cmpl	$0x33, %eax
    2b17:      	je	0x2b45 <generic_retuprobe_event+0x2b45>
    2b19:      	cmpl	$0x3c, %eax
    2b1c:      	je	0x2b32 <generic_retuprobe_event+0x2b32>
    2b1e:      	cmpl	$0xff, %eax
    2b23:      	jne	0x2b58 <generic_retuprobe_event+0x2b58>
    2b25:      	movw	$0x28, 0x2(%r13)
    2b2c:      	movw	$0x28, %ax
    2b30:      	jmp	0x2b5d <generic_retuprobe_event+0x2b5d>
    2b32:      	movzbl	0x7(%r13), %eax
    2b37:      	leal	0x8(,%rax,8), %eax
    2b3e:      	movw	%ax, 0x2(%r13)
    2b43:      	jmp	0x2b5d <generic_retuprobe_event+0x2b5d>
    2b45:      	movzbl	0x7(%r13), %eax
    2b4a:      	leal	0x8(,%rax,4), %eax
    2b51:      	movw	%ax, 0x2(%r13)
    2b56:      	jmp	0x2b5d <generic_retuprobe_event+0x2b5d>
    2b58:      	movzwl	0x2(%r13), %eax
    2b5d:      	addw	(%r13), %ax
    2b62:      	movw	%ax, (%r13)
    2b67:      	movzbl	0x6(%r13), %ecx
    2b6c:      	cmpq	$0x3c, %rcx
    2b70:      	ja	0x3200 <generic_retuprobe_event+0x3200>
    2b76:      	btq	%rcx, %r12
    2b7a:      	jae	0x3200 <generic_retuprobe_event+0x3200>
    2b80:      	movb	%cl, 0x5(%r13)
    2b84:      	movzwl	%ax, %ecx
    2b87:      	addq	%r14, %rcx
    2b8a:      	movl	$0x2, %edx
    2b8f:      	movl	$0x4, %eax
    2b94:      	movzwl	(%r13), %edx
    2b99:      	addq	%r14, %rdx
    2b9c:      	movq	%rbx, %rdi
    2b9f:      	movl	$0x2, %esi
    2ba4:      	callq	*%rax
    2ba6:      	testq	%rax, %rax
    2ba9:      	js	0x2c66 <generic_retuprobe_event+0x2c66>
    2baf:      	movzbl	0x5(%r13), %eax
    2bb4:      	cmpl	$0x32, %eax
    2bb7:      	jg	0x2bd4 <generic_retuprobe_event+0x2bd4>
    2bb9:      	testl	%eax, %eax
    2bbb:      	je	0x2bf2 <generic_retuprobe_event+0x2bf2>
    2bbd:      	cmpl	$0x2b, %eax
    2bc0:      	je	0x2bf2 <generic_retuprobe_event+0x2bf2>
    2bc2:      	cmpl	$0x2c, %eax
    2bc5:      	jne	0x2c18 <generic_retuprobe_event+0x2c18>
    2bc7:      	movw	$0x8, 0x2(%r13)
    2bce:      	movw	$0x8, %ax
    2bd2:      	jmp	0x2c1d <generic_retuprobe_event+0x2c1d>
    2bd4:      	cmpl	$0x33, %eax
    2bd7:      	je	0x2c05 <generic_retuprobe_event+0x2c05>
    2bd9:      	cmpl	$0x3c, %eax
    2bdc:      	je	0x2bf2 <generic_retuprobe_event+0x2bf2>
    2bde:      	cmpl	$0xff, %eax
    2be3:      	jne	0x2c18 <generic_retuprobe_event+0x2c18>
    2be5:      	movw	$0x28, 0x2(%r13)
    2bec:      	movw	$0x28, %ax
    2bf0:      	jmp	0x2c1d <generic_retuprobe_event+0x2c1d>
    2bf2:      	movzbl	0x7(%r13), %eax
    2bf7:      	leal	0x8(,%rax,8), %eax
    2bfe:      	movw	%ax, 0x2(%r13)
    2c03:      	jmp	0x2c1d <generic_retuprobe_event+0x2c1d>
    2c05:      	movzbl	0x7(%r13), %eax
    2c0a:      	leal	0x8(,%rax,4), %eax
    2c11:      	movw	%ax, 0x2(%r13)
    2c16:      	jmp	0x2c1d <generic_retuprobe_event+0x2c1d>
    2c18:      	movzwl	0x2(%r13), %eax
    2c1d:      	addw	(%r13), %ax
    2c22:      	movw	%ax, (%r13)
    2c27:      	movzbl	0x6(%r13), %ecx
    2c2c:      	cmpq	$0x3c, %rcx
    2c30:      	ja	0x3200 <generic_retuprobe_event+0x3200>
    2c36:      	btq	%rcx, %r12
    2c3a:      	jae	0x3200 <generic_retuprobe_event+0x3200>
    2c40:      	movb	%cl, 0x5(%r13)
    2c44:      	movzwl	%ax, %ecx
    2c47:      	addq	%r14, %rcx
    2c4a:      	movl	$0x2, %edx
    2c4f:      	movl	$0x4, %eax
    2c54:      	movzwl	(%r13), %edx
    2c59:      	addq	%r14, %rdx
    2c5c:      	movq	%rbx, %rdi
    2c5f:      	movl	$0x2, %esi
    2c64:      	callq	*%rax
    2c66:      	xorl	%ecx, %ecx
    2c68:      	movb	%cl, 0xd0(%rsp)
    2c6f:      	movzbl	%cl, %eax
    2c72:      	movq	(%rsp), %rbx
    2c76:      	movw	%ax, 0xc0(%rbx)
    2c7d:      	movw	$0xa, 0xc2(%rbx)
    2c86:      	movq	0xe8(%rsp), %r14
    2c8e:      	leaq	0x8(%r14), %rdx
    2c92:      	movl	$0x10, %ecx
    2c97:      	movl	$0x4, %eax
    2c9c:      	movq	0x30(%rsp), %rdi
    2ca1:      	movl	$0x10, %esi
    2ca6:      	callq	*%rax
    2ca8:      	leaq	0xac(%rbx), %rdi
    2caf:      	addq	$0x18, %r14
    2cb3:      	movl	$0x10, %ecx
    2cb8:      	movl	$0x4, %eax
    2cbd:      	movl	$0x10, %esi
    2cc2:      	movq	%r14, %rdx
    2cc5:      	callq	*%rax
    2cc7:      	movzbl	0xd0(%rsp), %eax
    2ccf:      	cmpl	$0x11, %eax
    2cd2:      	je	0x2d26 <generic_retuprobe_event+0x2d26>
    2cd4:      	cmpl	$0x6, %eax
    2cd7:      	jne	0x2d76 <generic_retuprobe_event+0x2d76>
    2cdd:      	movq	0x38(%rsp), %r14
    2ce2:      	movzwl	0xd8(%rsp), %r12d
    2ceb:      	leaq	(%r14,%r12), %rdx
    2cef:      	movq	(%rsp), %r13
    2cf3:      	leaq	0xbc(%r13), %rdi
    2cfa:      	movl	$0x2, %ecx
    2cff:      	movl	$0x4, %eax
    2d04:      	movl	$0x2, %esi
    2d09:      	callq	*%rax
    2d0b:      	leaq	0xbe(%r13), %rdi
    2d12:      	leaq	(%r14,%r12), %rdx
    2d16:      	addq	$0x2, %rdx
    2d1a:      	movl	$0x2, %ecx
    2d1f:      	movl	$0x4, %eax
    2d24:      	jmp	0x2d6d <generic_retuprobe_event+0x2d6d>
    2d26:      	movq	0x38(%rsp), %r14
    2d2b:      	movzwl	0xd8(%rsp), %r12d
    2d34:      	leaq	(%r14,%r12), %rdx
    2d38:      	movq	(%rsp), %r13
    2d3c:      	leaq	0xbc(%r13), %rdi
    2d43:      	movl	$0x2, %ecx
    2d48:      	movl	$0x4, %eax
    2d4d:      	movl	$0x2, %esi
    2d52:      	callq	*%rax
    2d54:      	leaq	0xbe(%r13), %rdi
    2d5b:      	leaq	(%r14,%r12), %rdx
    2d5f:      	addq	$0x2, %rdx
    2d63:      	movl	$0x2, %ecx
    2d68:      	movl	$0x4, %eax
    2d6d:      	movl	$0x2, %esi
    2d72:      	callq	*%rax
    2d74:      	jmp	0x2d85 <generic_retuprobe_event+0x2d85>
    2d76:      	movq	(%rsp), %r13
    2d7a:      	movl	$0x0, 0xbc(%r13)
    2d85:      	movzwl	0xbc(%r13), %eax
    2d8d:      	movzwl	0xbe(%r13), %ecx
    2d95:      	movbew	%ax, 0xbc(%r13)
    2d9f:      	movbew	%cx, 0xbe(%r13)
    2da9:      	movq	0xa0(%rsp), %rdx
    2db1:      	addq	$0xe0, %rdx
    2db8:      	leaq	0x78(%rsp), %rdi
    2dbd:      	movl	$0x8, %ecx
    2dc2:      	movl	$0x4, %eax
    2dc7:      	movl	$0x4, %ebx
    2dcc:      	movl	$0x8, %esi
    2dd1:      	callq	*%rax
    2dd3:      	movq	0x78(%rsp), %rcx
    2dd8:      	testq	%rcx, %rcx
    2ddb:      	je	0x2e4d <generic_retuprobe_event+0x2e4d>
    2ddd:      	addq	$0x5, %rcx
    2de1:      	leaq	0x90(%rsp), %rdi
    2de9:      	movl	$0x8, %edx
    2dee:      	movl	$0x4, %eax
    2df3:      	movq	0x78(%rsp), %rdx
    2df8:      	addq	$0x5, %rdx
    2dfc:      	movl	$0x8, %esi
    2e01:      	callq	*%rax
    2e03:      	movq	0x78(%rsp), %r12
    2e08:      	movq	0x90(%rsp), %r13
    2e10:      	movq	(%rsp), %r14
    2e14:      	leaq	0xd4(%r14), %rdi
    2e1b:      	leaq	(%r12,%r13,8), %rdx
    2e1f:      	addq	$0x44, %rdx
    2e23:      	movl	$0x4, %eax
    2e28:      	movl	$0x4, %esi
    2e2d:      	callq	*%rax
    2e2f:      	addq	$0xd8, %r14
    2e36:      	leaq	(%r12,%r13,8), %rdx
    2e3a:      	addq	$0x45, %rdx
    2e3e:      	movl	$0x4, %eax
    2e43:      	movq	%r14, %rdi
    2e46:      	movl	$0x4, %esi
    2e4b:      	callq	*%rax
    2e4d:      	movq	0x10(%rsp), %rbx
    2e52:      	movq	0x20(%rsp), %r15
    2e57:      	movl	$0x40, %r13d
    2e5d:      	movq	(%rsp), %rcx
    2e61:      	movq	%rbp, %r12
    2e64:      	movq	0x8(%rsp), %r8
    2e69:      	movq	0x88(%rsp), %rbp
    2e71:      	testl	%r13d, %r13d
    2e74:      	movl	0x28(%rsp), %eax
    2e78:      	js	0x2e92 <generic_retuprobe_event+0x2e92>
    2e7a:      	andl	$0x7fffffff, %r13d      # imm = 0x7FFFFFFF
    2e81:      	addq	$0x4, %r13
    2e85:      	movq	%r13, %r14
    2e88:      	movq	0xc8(%rsp), %r13
    2e90:      	jmp	0x2eb4 <generic_retuprobe_event+0x2eb4>
    2e92:      	movl	$0xffffffff, 0x5ea0(%rcx) # imm = 0xFFFFFFFF
    2e9c:      	movl	$0xffffffff, 0x98(%rcx) # imm = 0xFFFFFFFF
    2ea6:      	movq	0xc8(%rsp), %r13
    2eae:      	movl	$0x4, %r14d
    2eb4:      	addl	$0x8, %r14d
    2eb8:      	andl	$0x1fff, %r14d          # imm = 0x1FFF
    2ebf:      	addq	$0x90, %r15
    2ec6:      	cmpl	$0x3, %eax
    2ec9:      	je	0x1b4 <generic_retuprobe_event+0x1b4>
    2ecf:      	cmpl	$0x2, %eax
    2ed2:      	jne	0x2f50 <generic_retuprobe_event+0x2f50>
    2ed4:      	movq	%rbx, 0x10(%rsp)
    2ed9:      	movq	%rbp, %rdx
    2edc:      	movq	%r12, 0xa8(%rsp)
    2ee4:      	movq	%r14, %rcx
    2ee7:      	movl	$0x0, (%r15,%r14)
    2eef:      	cmpq	$0xfff, %r8             # imm = 0xFFF
    2ef6:      	movq	%r8, %rbx
    2ef9:      	movl	$0xfff, %r14d           # imm = 0xFFF
    2eff:      	cmovbq	%r8, %r14
    2f03:      	leaq	(%r15,%rcx), %rdi
    2f07:      	addq	$0xc, %rdi
    2f0b:      	movl	$0x4, %eax
    2f10:      	leaq	0x4(%rcx), %r12
    2f14:      	addq	%rcx, %r15
    2f17:      	addq	$0x4, %r15
    2f1b:      	movl	$0x4, %ebp
    2f20:      	movl	%r14d, %esi
    2f23:      	callq	*%rax
    2f25:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2f2a:      	testl	%eax, %eax
    2f2c:      	js	0x2f3b <generic_retuprobe_event+0x2f3b>
    2f2e:      	movl	%r14d, 0x4(%r15)
    2f32:      	addq	$0x8, %r14
    2f36:      	movl	%ebx, %ecx
    2f38:      	movq	%r14, %rbp
    2f3b:      	addq	%r12, %rbp
    2f3e:      	movl	%ecx, (%r15)
    2f41:      	movq	0xa8(%rsp), %r12
    2f49:      	movq	0x10(%rsp), %rbx
    2f4e:      	jmp	0x2f53 <generic_retuprobe_event+0x2f53>
    2f50:      	movq	%r14, %rbp
    2f53:      	movl	$0x23, %eax
    2f58:      	callq	*%rax
    2f5a:      	movq	%rax, %rcx
    2f5d:      	movq	%rax, 0x38(%rsp)
    2f62:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    2f69:      	leaq	0x90(%rsp), %rdi
    2f71:      	movl	$0x4, %edx
    2f76:      	movl	$0x71, %eax
    2f7b:      	movl	$0xaf4, %edx            # imm = 0xAF4
    2f80:      	addq	0x38(%rsp), %rdx
    2f85:      	movl	$0x4, %esi
    2f8a:      	callq	*%rax
    2f8c:      	movl	0x90(%rsp), %eax
    2f93:      	movl	%eax, 0x78(%rsp)
    2f97:      	movq	(%rip), %rdi            # 0x2f9e <generic_retuprobe_event+0x2f9e>
    2f9e:      	leaq	0x78(%rsp), %rsi
    2fa3:      	movl	$0x1, %eax
    2fa8:      	callq	*%rax
    2faa:      	testq	%rax, %rax
    2fad:      	je	0x2fbd <generic_retuprobe_event+0x2fbd>
    2faf:      	movq	%rax, %r15
    2fb2:      	cmpq	$0x0, 0x8(%rax)
    2fb7:      	jne	0x3193 <generic_retuprobe_event+0x3193>
    2fbd:      	movl	$0xb00, %edx            # imm = 0xB00
    2fc2:      	movq	0x38(%rsp), %rcx
    2fc7:      	addq	%rdx, %rcx
    2fca:      	leaq	0x38(%rsp), %rdi
    2fcf:      	movl	$0x8, %esi
    2fd4:      	movl	$0x71, %eax
    2fd9:      	addq	0x38(%rsp), %rdx
    2fde:      	movl	$0x8, %esi
    2fe3:      	callq	*%rax
    2fe5:      	movq	0x38(%rsp), %rcx
    2fea:      	testq	%rcx, %rcx
    2fed:      	je	0x3190 <generic_retuprobe_event+0x3190>
    2ff3:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    2ffa:      	leaq	0x90(%rsp), %rdi
    3002:      	movl	$0x4, %edx
    3007:      	movl	$0x71, %eax
    300c:      	movl	$0xaf4, %edx            # imm = 0xAF4
    3011:      	addq	0x38(%rsp), %rdx
    3016:      	movl	$0x4, %esi
    301b:      	callq	*%rax
    301d:      	movl	0x90(%rsp), %eax
    3024:      	movl	%eax, 0x78(%rsp)
    3028:      	movq	(%rip), %rdi            # 0x302f <generic_retuprobe_event+0x302f>
    302f:      	leaq	0x78(%rsp), %rsi
    3034:      	movl	$0x1, %eax
    3039:      	callq	*%rax
    303b:      	testq	%rax, %rax
    303e:      	je	0x304e <generic_retuprobe_event+0x304e>
    3040:      	movq	%rax, %r15
    3043:      	cmpq	$0x0, 0x8(%rax)
    3048:      	jne	0x3193 <generic_retuprobe_event+0x3193>
    304e:      	movl	$0xb00, %edx            # imm = 0xB00
    3053:      	movq	0x38(%rsp), %rcx
    3058:      	addq	%rdx, %rcx
    305b:      	leaq	0x38(%rsp), %rdi
    3060:      	movl	$0x8, %esi
    3065:      	movl	$0x71, %eax
    306a:      	addq	0x38(%rsp), %rdx
    306f:      	movl	$0x8, %esi
    3074:      	callq	*%rax
    3076:      	movq	0x38(%rsp), %rcx
    307b:      	testq	%rcx, %rcx
    307e:      	je	0x3190 <generic_retuprobe_event+0x3190>
    3084:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    308b:      	leaq	0x90(%rsp), %rdi
    3093:      	movl	$0x4, %edx
    3098:      	movl	$0x71, %eax
    309d:      	movl	$0xaf4, %edx            # imm = 0xAF4
    30a2:      	addq	0x38(%rsp), %rdx
    30a7:      	movl	$0x4, %esi
    30ac:      	callq	*%rax
    30ae:      	movl	0x90(%rsp), %eax
    30b5:      	movl	%eax, 0x78(%rsp)
    30b9:      	movq	(%rip), %rdi            # 0x30c0 <generic_retuprobe_event+0x30c0>
    30c0:      	leaq	0x78(%rsp), %rsi
    30c5:      	movl	$0x1, %eax
    30ca:      	callq	*%rax
    30cc:      	testq	%rax, %rax
    30cf:      	je	0x30df <generic_retuprobe_event+0x30df>
    30d1:      	movq	%rax, %r15
    30d4:      	cmpq	$0x0, 0x8(%rax)
    30d9:      	jne	0x3193 <generic_retuprobe_event+0x3193>
    30df:      	movl	$0xb00, %edx            # imm = 0xB00
    30e4:      	movq	0x38(%rsp), %rcx
    30e9:      	addq	%rdx, %rcx
    30ec:      	leaq	0x38(%rsp), %rdi
    30f1:      	movl	$0x8, %esi
    30f6:      	movl	$0x71, %eax
    30fb:      	addq	0x38(%rsp), %rdx
    3100:      	movl	$0x8, %esi
    3105:      	callq	*%rax
    3107:      	movq	0x38(%rsp), %rcx
    310c:      	testq	%rcx, %rcx
    310f:      	je	0x3190 <generic_retuprobe_event+0x3190>
    3111:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3118:      	leaq	0x90(%rsp), %rdi
    3120:      	movl	$0x4, %edx
    3125:      	movl	$0x71, %eax
    312a:      	movl	$0xaf4, %edx            # imm = 0xAF4
    312f:      	addq	0x38(%rsp), %rdx
    3134:      	movl	$0x4, %esi
    3139:      	callq	*%rax
    313b:      	movl	0x90(%rsp), %eax
    3142:      	movl	%eax, 0x78(%rsp)
    3146:      	movq	(%rip), %rdi            # 0x314d <generic_retuprobe_event+0x314d>
    314d:      	leaq	0x78(%rsp), %rsi
    3152:      	movl	$0x1, %eax
    3157:      	callq	*%rax
    3159:      	testq	%rax, %rax
    315c:      	je	0x3168 <generic_retuprobe_event+0x3168>
    315e:      	movq	%rax, %r15
    3161:      	cmpq	$0x0, 0x8(%rax)
    3166:      	jne	0x3193 <generic_retuprobe_event+0x3193>
    3168:      	movl	$0xb00, %edx            # imm = 0xB00
    316d:      	movq	0x38(%rsp), %rcx
    3172:      	addq	%rdx, %rcx
    3175:      	leaq	0x38(%rsp), %rdi
    317a:      	movl	$0x8, %esi
    317f:      	movl	$0x71, %eax
    3184:      	addq	0x38(%rsp), %rdx
    3189:      	movl	$0x8, %esi
    318e:      	callq	*%rax
    3190:      	xorl	%r15d, %r15d
    3193:      	movl	$0x10f, (%rbx)          # imm = 0x10F
    3199:      	movl	%ebp, 0x4(%rbx)
    319c:      	movl	$0x7d, %eax
    31a1:      	callq	*%rax
    31a3:      	movq	%rax, 0x8(%rbx)
    31a7:      	testq	%r15, %r15
    31aa:      	je	0x31ba <generic_retuprobe_event+0x31ba>
    31ac:      	movl	(%r15), %eax
    31af:      	movl	%eax, 0x10(%rbx)
    31b2:      	movq	0x8(%r15), %rax
    31b6:      	movq	%rax, 0x18(%rbx)
    31ba:      	movl	$0x0, 0x14(%rbx)
    31c1:      	movl	(%r12), %eax
    31c5:      	movq	%rax, 0x60(%rbx)
    31c9:      	movl	%ebp, 0x4(%rbx)
    31cc:      	movq	(%rip), %rsi            # 0x31d3 <generic_retuprobe_event+0x31d3>
    31d3:      	movl	$0x3, %ecx
    31d8:      	movl	$0xc, %eax
    31dd:      	movq	%r13, %rdi
    31e0:      	movl	$0x3, %edx
    31e5:      	callq	*%rax
    31e7:      	movl	$0x1, %ebp
    31ec:      	movl	%ebp, %eax
    31ee:      	addq	$0xf8, %rsp
    31f5:      	popq	%rbx
    31f6:      	popq	%r12
    31f8:      	popq	%r13
    31fa:      	popq	%r14
    31fc:      	popq	%r15
    31fe:      	popq	%rbp
    31ff:      	retq
    3200:      	movw	%ax, 0xd8(%rsp)
    3208:      	jmp	0x2c68 <generic_retuprobe_event+0x2c68>
    320d:      	xorl	%eax, %eax
    320f:      	movq	%rax, 0x8(%rsp)
    3214:      	cmpq	$0x5, 0xb8(%rsp)
    321d:      	je	0x25c0 <generic_retuprobe_event+0x25c0>
    3223:      	movq	0x88(%rsp), %rax
    322b:      	leaq	0x50(%rax), %rdx
    322f:      	leaq	0x38(%rsp), %rdi
    3234:      	movl	$0x4, %r12d
    323a:      	movl	$0x10, %ecx
    323f:      	movl	$0x4, %eax
    3244:      	movl	$0x10, %esi
    3249:      	callq	*%rax
    324b:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3250:      	testl	%eax, %eax
    3252:      	js	0x3378 <generic_retuprobe_event+0x3378>
    3258:      	movq	0x40(%rsp), %r15
    325d:      	movq	0x8(%rsp), %rax
    3262:      	cmpq	%rax, %r15
    3265:      	movq	%rax, %rbx
    3268:      	cmovbq	%r15, %rbx
    326c:      	testq	%rax, %rax
    326f:      	cmovneq	%rbx, %r15
    3273:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    3278:      	cmpq	$0xffe, %r15            # imm = 0xFFE
    327f:      	ja	0x3378 <generic_retuprobe_event+0x3378>
    3285:      	movq	(%rsp), %rdi
    3289:      	addq	%r14, %rdi
    328c:      	movq	%rdi, %r14
    328f:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    3295:      	addq	0x20(%rsp), %rdi
    329a:      	movq	0x38(%rsp), %rcx
    329f:      	movl	$0x4, %eax
    32a4:      	movq	0x38(%rsp), %rdx
    32a9:      	movl	%r15d, %esi
    32ac:      	callq	*%rax
    32ae:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    32b3:      	testl	%eax, %eax
    32b5:      	js	0x3378 <generic_retuprobe_event+0x3378>
    32bb:      	addq	%r15, %r13
    32be:      	cmpq	$0x0, 0x8(%rsp)
    32c4:      	je	0x32d2 <generic_retuprobe_event+0x32d2>
    32c6:      	subq	%rbx, 0x8(%rsp)
    32cb:      	jne	0x32d9 <generic_retuprobe_event+0x32d9>
    32cd:      	jmp	0x25c0 <generic_retuprobe_event+0x25c0>
    32d2:      	xorl	%eax, %eax
    32d4:      	movq	%rax, 0x8(%rsp)
    32d9:      	cmpq	$0x7, 0xb8(%rsp)
    32e2:      	jb	0x25c0 <generic_retuprobe_event+0x25c0>
    32e8:      	movq	0x88(%rsp), %rdx
    32f0:      	addq	$0x60, %rdx
    32f4:      	leaq	0x38(%rsp), %rdi
    32f9:      	movl	$0x4, %r12d
    32ff:      	movl	$0x10, %ecx
    3304:      	movl	$0x4, %eax
    3309:      	movl	$0x10, %esi
    330e:      	callq	*%rax
    3310:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3315:      	testl	%eax, %eax
    3317:      	js	0x3378 <generic_retuprobe_event+0x3378>
    3319:      	movq	0x40(%rsp), %rax
    331e:      	movq	0x8(%rsp), %rcx
    3323:      	cmpq	%rcx, %rax
    3326:      	movq	%rcx, %rbp
    3329:      	cmovbq	%rax, %rbp
    332d:      	testq	%rcx, %rcx
    3330:      	cmoveq	%rax, %rbp
    3334:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    3339:      	cmpq	$0xffe, %rbp            # imm = 0xFFE
    3340:      	ja	0x3378 <generic_retuprobe_event+0x3378>
    3342:      	addq	%r14, %r15
    3345:      	andl	$0x3fff, %r15d          # imm = 0x3FFF
    334c:      	addq	0x20(%rsp), %r15
    3351:      	movq	0x38(%rsp), %rcx
    3356:      	movl	$0x4, %eax
    335b:      	movq	0x38(%rsp), %rdx
    3360:      	movq	%r15, %rdi
    3363:      	movl	%ebp, %esi
    3365:      	callq	*%rax
    3367:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    336c:      	testl	%eax, %eax
    336e:      	js	0x3378 <generic_retuprobe_event+0x3378>
    3370:      	addq	%r13, %rbp
    3373:      	jmp	0x25c3 <generic_retuprobe_event+0x25c3>
    3378:      	movq	0x28(%rsp), %rax
    337d:      	movq	0x20(%rsp), %rdx
    3382:      	movl	%ecx, (%rdx,%rax)
    3385:      	movq	0x10(%rsp), %rbx
    338a:      	jmp	0xbcc <generic_retuprobe_event+0xbcc>
