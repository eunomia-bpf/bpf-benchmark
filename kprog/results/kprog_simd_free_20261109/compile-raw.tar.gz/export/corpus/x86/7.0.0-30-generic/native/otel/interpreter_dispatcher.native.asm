
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/otel/interpreter_dispatcher.native.o:	file format elf64-x86-64

Disassembly of section perf_event/unwind_stop:

0000000000000000 <perf_unwind_stop>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x98, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, (%rsp)
      1b:      	movq	(%rip), %rdi            # 0x22 <perf_unwind_stop+0x22>
      22:      	movq	%rsp, %rsi
      25:      	movl	$0x1, %eax
      2a:      	callq	*%rax
      2c:      	testq	%rax, %rax
      2f:      	je	0xde <perf_unwind_stop+0xde>
      35:      	movq	%rax, %r14
      38:      	movl	(%rax), %eax
      3a:      	movl	%eax, 0x8c(%rsp)
      41:      	movq	(%rip), %rdi            # 0x48 <perf_unwind_stop+0x48>
      48:      	leaq	0x8c(%rsp), %rsi
      50:      	movl	$0x1, %eax
      55:      	callq	*%rax
      57:      	testq	%rax, %rax
      5a:      	je	0x5ab <perf_unwind_stop+0x5ab>
      60:      	movq	%rax, %r15
      63:      	movq	(%rip), %r12            # 0x6a <perf_unwind_stop+0x6a>
      6a:      	cmpl	$0x0, (%r12)
      6f:      	jne	0x706 <perf_unwind_stop+0x706>
      75:      	movl	$0x23, %eax
      7a:      	callq	*%rax
      7c:      	movq	(%rip), %rcx            # 0x83 <perf_unwind_stop+0x83>
      83:      	addq	(%rcx), %rax
      86:      	leaq	0x58(%rsp), %rdi
      8b:      	movl	$0x8, %ecx
      90:      	movl	$0x71, %r8d
      96:      	movl	$0x8, %esi
      9b:      	movq	%rax, %rdx
      9e:      	callq	*%r8
      a1:      	movl	(%r12), %ecx
      a5:      	testq	%rax, %rax
      a8:      	je	0xe8 <perf_unwind_stop+0xe8>
      aa:      	testl	%ecx, %ecx
      ac:      	jne	0x1259 <perf_unwind_stop+0x1259>
      b2:      	movl	$0x4, 0x60(%rsp)
      ba:      	movq	(%rip), %rdi            # 0xc1 <perf_unwind_stop+0xc1>
      c1:      	leaq	0x60(%rsp), %rsi
      c6:      	movl	$0x1, %eax
      cb:      	callq	*%rax
      cd:      	testq	%rax, %rax
      d0:      	je	0x1c3 <perf_unwind_stop+0x1c3>
      d6:      	incq	(%rax)
      d9:      	jmp	0x1ce <perf_unwind_stop+0x1ce>
      de:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
      e3:      	jmp	0x1529 <perf_unwind_stop+0x1529>
      e8:      	testl	%ecx, %ecx
      ea:      	jne	0x13f0 <perf_unwind_stop+0x13f0>
      f0:      	movq	(%r15), %rax
      f3:      	addq	0x58(%rsp), %rax
      f8:      	leaq	0x50(%rsp), %rdi
      fd:      	movl	$0x8, %ecx
     102:      	movl	$0x70, %r8d
     108:      	movq	(%r15), %rdx
     10b:      	addq	0x58(%rsp), %rdx
     110:      	movl	$0x8, %esi
     115:      	callq	*%r8
     118:      	testq	%rax, %rax
     11b:      	je	0x2f7 <perf_unwind_stop+0x2f7>
     121:      	movl	$0x57, 0x60(%rsp)
     129:      	movq	(%rip), %rdi            # 0x130 <perf_unwind_stop+0x130>
     130:      	leaq	0x60(%rsp), %rsi
     135:      	movl	$0x1, %eax
     13a:      	callq	*%rax
     13c:      	testq	%rax, %rax
     13f:      	je	0x3b5 <perf_unwind_stop+0x3b5>
     145:      	incq	(%rax)
     148:      	cmpl	$0x0, (%r12)
     14d:      	je	0x5ab <perf_unwind_stop+0x5ab>
     153:      	movabsq	$0xa7265746e696f, %rax  # imm = 0xA7265746E696F
     15d:      	movq	%rax, 0x27(%rsp)
     162:      	movabsq	$0x6f70207265666675, %rax # imm = 0x6F70207265666675
     16c:      	movq	%rax, 0x20(%rsp)
     171:      	movabsq	$0x62206e6f6974616c, %rax # imm = 0x62206E6F6974616C
     17b:      	movq	%rax, 0x18(%rsp)
     180:      	movabsq	$0x6572726f63204d50, %rax # imm = 0x6572726F63204D50
     18a:      	movq	%rax, 0x10(%rsp)
     18f:      	movabsq	$0x412064616572206f, %rax # imm = 0x412064616572206F
     199:      	movq	%rax, 0x8(%rsp)
     19e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     1a8:      	movq	%rax, (%rsp)
     1ac:      	movq	%rsp, %rdi
     1af:      	movl	$0x2f, %eax
     1b4:      	movl	$0x6, %ecx
     1b9:      	movl	$0x2f, %esi
     1be:      	jmp	0x260 <perf_unwind_stop+0x260>
     1c3:      	cmpl	$0x0, (%r12)
     1c8:      	jne	0x153b <perf_unwind_stop+0x153b>
     1ce:      	movl	$0x56, 0x60(%rsp)
     1d6:      	movq	(%rip), %rdi            # 0x1dd <perf_unwind_stop+0x1dd>
     1dd:      	leaq	0x60(%rsp), %rsi
     1e2:      	movl	$0x1, %eax
     1e7:      	callq	*%rax
     1e9:      	testq	%rax, %rax
     1ec:      	je	0x269 <perf_unwind_stop+0x269>
     1ee:      	incq	(%rax)
     1f1:      	cmpl	$0x0, (%r12)
     1f6:      	je	0x5ab <perf_unwind_stop+0x5ab>
     1fc:      	movabsq	$0x697461726765746e, %rax # imm = 0x697461726765746E
     206:      	movq	%rax, 0x20(%rsp)
     20b:      	movabsq	$0x69204d504120726f, %rax # imm = 0x69204D504120726F
     215:      	movq	%rax, 0x18(%rsp)
     21a:      	movabsq	$0x6620657361622044, %rax # imm = 0x6620657361622044
     224:      	movq	%rax, 0x10(%rsp)
     229:      	movabsq	$0x535420746567206f, %rax # imm = 0x535420746567206F
     233:      	movq	%rax, 0x8(%rsp)
     238:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     242:      	movq	%rax, (%rsp)
     246:      	movl	$0xa6e6f, 0x28(%rsp)    # imm = 0xA6E6F
     24e:      	movq	%rsp, %rdi
     251:      	movl	$0x2c, %eax
     256:      	movl	$0x6, %ecx
     25b:      	movl	$0x2c, %esi
     260:      	xorl	%eax, %eax
     262:      	callq	*%rcx
     264:      	jmp	0x5ab <perf_unwind_stop+0x5ab>
     269:      	cmpl	$0x0, (%r12)
     26e:      	je	0x5ab <perf_unwind_stop+0x5ab>
     274:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     27e:      	movq	%rax, 0x26(%rsp)
     283:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     28d:      	movq	%rax, 0x20(%rsp)
     292:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     29c:      	movq	%rax, 0x18(%rsp)
     2a1:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     2ab:      	movq	%rax, 0x10(%rsp)
     2b0:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     2ba:      	movq	%rax, 0x8(%rsp)
     2bf:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     2c9:      	movq	%rax, (%rsp)
     2cd:      	movq	%rsp, %rdi
     2d0:      	movl	$0x2e, %eax
     2d5:      	movl	$0x6, %ecx
     2da:      	movl	0x60(%rsp), %edx
     2de:      	movl	$0x2e, %esi
     2e3:      	xorl	%eax, %eax
     2e5:      	callq	*%rcx
     2e7:      	cmpl	$0x0, (%r12)
     2ec:      	je	0x5ab <perf_unwind_stop+0x5ab>
     2f2:      	jmp	0x1fc <perf_unwind_stop+0x1fc>
     2f7:      	movq	0x50(%rsp), %rax
     2fc:      	leaq	0x60(%rsp), %rdi
     301:      	movl	$0x25, %ecx
     306:      	movl	$0x70, %r8d
     30c:      	movq	0x50(%rsp), %rdx
     311:      	movl	$0x25, %esi
     316:      	callq	*%r8
     319:      	testq	%rax, %rax
     31c:      	je	0x443 <perf_unwind_stop+0x443>
     322:      	movl	$0x58, 0x48(%rsp)
     32a:      	movq	(%rip), %rdi            # 0x331 <perf_unwind_stop+0x331>
     331:      	leaq	0x48(%rsp), %rsi
     336:      	movl	$0x1, %eax
     33b:      	callq	*%rax
     33d:      	testq	%rax, %rax
     340:      	je	0x516 <perf_unwind_stop+0x516>
     346:      	incq	(%rax)
     349:      	cmpl	$0x0, (%r12)
     34e:      	je	0x5ab <perf_unwind_stop+0x5ab>
     354:      	movabsq	$0xa726566667562, %rax  # imm = 0xA726566667562
     35e:      	movq	%rax, 0x1f(%rsp)
     363:      	movabsq	$0x62206e6f6974616c, %rax # imm = 0x62206E6F6974616C
     36d:      	movq	%rax, 0x18(%rsp)
     372:      	movabsq	$0x6572726f63204d50, %rax # imm = 0x6572726F63204D50
     37c:      	movq	%rax, 0x10(%rsp)
     381:      	movabsq	$0x412064616572206f, %rax # imm = 0x412064616572206F
     38b:      	movq	%rax, 0x8(%rsp)
     390:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     39a:      	movq	%rax, (%rsp)
     39e:      	movq	%rsp, %rdi
     3a1:      	movl	$0x27, %eax
     3a6:      	movl	$0x6, %ecx
     3ab:      	movl	$0x27, %esi
     3b0:      	jmp	0x260 <perf_unwind_stop+0x260>
     3b5:      	cmpl	$0x0, (%r12)
     3ba:      	je	0x5ab <perf_unwind_stop+0x5ab>
     3c0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     3ca:      	movq	%rax, 0x26(%rsp)
     3cf:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     3d9:      	movq	%rax, 0x20(%rsp)
     3de:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     3e8:      	movq	%rax, 0x18(%rsp)
     3ed:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     3f7:      	movq	%rax, 0x10(%rsp)
     3fc:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     406:      	movq	%rax, 0x8(%rsp)
     40b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     415:      	movq	%rax, (%rsp)
     419:      	movq	%rsp, %rdi
     41c:      	movl	$0x2e, %eax
     421:      	movl	$0x6, %ecx
     426:      	movl	0x60(%rsp), %edx
     42a:      	movl	$0x2e, %esi
     42f:      	xorl	%eax, %eax
     431:      	callq	*%rcx
     433:      	cmpl	$0x0, (%r12)
     438:      	je	0x5ab <perf_unwind_stop+0x5ab>
     43e:      	jmp	0x153 <perf_unwind_stop+0x153>
     443:      	cmpb	$0x0, 0x63(%rsp)
     448:      	je	0x46c <perf_unwind_stop+0x46c>
     44a:      	cmpb	$0x0, 0x62(%rsp)
     44f:      	je	0x46c <perf_unwind_stop+0x46c>
     451:      	movq	0x6d(%rsp), %rax
     456:      	movq	%rax, 0x30(%r14)
     45a:      	movq	0x65(%rsp), %rax
     45f:      	movq	%rax, 0x28(%r14)
     463:      	movq	0x7d(%rsp), %rax
     468:      	movq	%rax, 0x20(%r14)
     46c:      	movl	$0x59, 0x48(%rsp)
     474:      	movq	(%rip), %rdi            # 0x47b <perf_unwind_stop+0x47b>
     47b:      	leaq	0x48(%rsp), %rsi
     480:      	movl	$0x1, %eax
     485:      	callq	*%rax
     487:      	testq	%rax, %rax
     48a:      	je	0x5a0 <perf_unwind_stop+0x5a0>
     490:      	incq	(%rax)
     493:      	cmpl	$0x0, (%r12)
     498:      	je	0x5ab <perf_unwind_stop+0x5ab>
     49e:      	movabsq	$0x30257830203a7367, %rax # imm = 0x30257830203A7367
     4a8:      	movq	%rax, 0x20(%rsp)
     4ad:      	movabsq	$0x616c66202c586c6c, %rax # imm = 0x616C66202C586C6C
     4b7:      	movq	%rax, 0x18(%rsp)
     4bc:      	movabsq	$0x36313025203a4449, %rax # imm = 0x36313025203A4449
     4c6:      	movq	%rax, 0x10(%rsp)
     4cb:      	movabsq	$0x206e6f6974636173, %rax # imm = 0x206E6F6974636173
     4d5:      	movq	%rax, 0x8(%rsp)
     4da:      	movabsq	$0x6e617274204d5041, %rax # imm = 0x6E617274204D5041
     4e4:      	movq	%rax, (%rsp)
     4e8:      	movl	$0xa5832, 0x28(%rsp)    # imm = 0xA5832
     4f0:      	movq	%rsp, %rdi
     4f3:      	movl	$0x2c, %eax
     4f8:      	movl	$0x6, %r8d
     4fe:      	movq	0x20(%r14), %rdx
     502:      	movzbl	0x64(%rsp), %ecx
     507:      	movl	$0x2c, %esi
     50c:      	xorl	%eax, %eax
     50e:      	callq	*%r8
     511:      	jmp	0x5ab <perf_unwind_stop+0x5ab>
     516:      	cmpl	$0x0, (%r12)
     51b:      	je	0x5ab <perf_unwind_stop+0x5ab>
     521:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     52b:      	movq	%rax, 0x26(%rsp)
     530:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     53a:      	movq	%rax, 0x20(%rsp)
     53f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     549:      	movq	%rax, 0x18(%rsp)
     54e:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     558:      	movq	%rax, 0x10(%rsp)
     55d:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     567:      	movq	%rax, 0x8(%rsp)
     56c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     576:      	movq	%rax, (%rsp)
     57a:      	movq	%rsp, %rdi
     57d:      	movl	$0x2e, %eax
     582:      	movl	$0x6, %ecx
     587:      	movl	0x48(%rsp), %edx
     58b:      	movl	$0x2e, %esi
     590:      	xorl	%eax, %eax
     592:      	callq	*%rcx
     594:      	cmpl	$0x0, (%r12)
     599:      	je	0x5ab <perf_unwind_stop+0x5ab>
     59b:      	jmp	0x354 <perf_unwind_stop+0x354>
     5a0:      	cmpl	$0x0, (%r12)
     5a5:      	jne	0x1a43 <perf_unwind_stop+0x1a43>
     5ab:      	cmpl	$0x0, 0x2c0(%r14)
     5b3:      	jne	0x61e <perf_unwind_stop+0x61e>
     5b5:      	cmpl	$0x0, 0x2bc(%r14)
     5bd:      	jns	0x61e <perf_unwind_stop+0x61e>
     5bf:      	movq	(%rip), %r15            # 0x5c6 <perf_unwind_stop+0x5c6>
     5c6:      	cmpl	$0x0, (%r15)
     5ca:      	jne	0x1622 <perf_unwind_stop+0x1622>
     5d0:      	movl	$0x28, 0x60(%rsp)
     5d8:      	movq	(%rip), %rdi            # 0x5df <perf_unwind_stop+0x5df>
     5df:      	leaq	0x60(%rsp), %rsi
     5e4:      	movl	$0x1, %eax
     5e9:      	callq	*%rax
     5eb:      	testq	%rax, %rax
     5ee:      	je	0x60a <perf_unwind_stop+0x60a>
     5f0:      	incq	(%rax)
     5f3:      	cmpl	$0x0, 0xf2c(%r14)
     5fb:      	jne	0x61e <perf_unwind_stop+0x61e>
     5fd:      	movl	$0x3, 0xf2c(%r14)
     608:      	jmp	0x61e <perf_unwind_stop+0x61e>
     60a:      	cmpl	$0x0, (%r15)
     60e:      	jne	0x17f0 <perf_unwind_stop+0x17f0>
     614:      	cmpl	$0x0, 0xf2c(%r14)
     61c:      	je	0x5fd <perf_unwind_stop+0x5fd>
     61e:      	movl	0xf2c(%r14), %eax
     625:      	testl	%eax, %eax
     627:      	je	0x864 <perf_unwind_stop+0x864>
     62d:      	movq	(%rip), %r15            # 0x634 <perf_unwind_stop+0x634>
     634:      	cmpl	$0x0, (%r15)
     638:      	jne	0x789 <perf_unwind_stop+0x789>
     63e:      	movl	0x2c0(%r14), %ecx
     645:      	cmpq	$0x80, %rcx
     64c:      	jb	0x81f <perf_unwind_stop+0x81f>
     652:      	cmpl	$0x0, (%r15)
     656:      	jne	0x1305 <perf_unwind_stop+0x1305>
     65c:      	movl	$0x2, 0x60(%rsp)
     664:      	movq	(%rip), %rdi            # 0x66b <perf_unwind_stop+0x66b>
     66b:      	leaq	0x60(%rsp), %rsi
     670:      	movl	$0x1, %eax
     675:      	callq	*%rax
     677:      	testq	%rax, %rax
     67a:      	je	0x684 <perf_unwind_stop+0x684>
     67c:      	incq	(%rax)
     67f:      	jmp	0x864 <perf_unwind_stop+0x864>
     684:      	cmpl	$0x0, (%r15)
     688:      	je	0x864 <perf_unwind_stop+0x864>
     68e:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     698:      	movq	%rax, 0x26(%rsp)
     69d:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     6a7:      	movq	%rax, 0x20(%rsp)
     6ac:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     6b6:      	movq	%rax, 0x18(%rsp)
     6bb:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     6c5:      	movq	%rax, 0x10(%rsp)
     6ca:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     6d4:      	movq	%rax, 0x8(%rsp)
     6d9:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     6e3:      	movq	%rax, (%rsp)
     6e7:      	movq	%rsp, %rdi
     6ea:      	movl	$0x2e, %eax
     6ef:      	movl	$0x6, %ecx
     6f4:      	movl	0x60(%rsp), %edx
     6f8:      	movl	$0x2e, %esi
     6fd:      	xorl	%eax, %eax
     6ff:      	callq	*%rcx
     701:      	jmp	0x864 <perf_unwind_stop+0x864>
     706:      	movabsq	$0xa64656c62616e, %rax  # imm = 0xA64656C62616E
     710:      	movq	%rax, 0x30(%rsp)
     715:      	movabsq	$0x65206e6f69746172, %rax # imm = 0x65206E6F69746172
     71f:      	movq	%rax, 0x28(%rsp)
     724:      	movabsq	$0x6765746e69204d50, %rax # imm = 0x6765746E69204D50
     72e:      	movq	%rax, 0x20(%rsp)
     733:      	movabsq	$0x4120687469772073, %rax # imm = 0x4120687469772073
     73d:      	movq	%rax, 0x18(%rsp)
     742:      	movabsq	$0x7365636f72702061, %rax # imm = 0x7365636F72702061
     74c:      	movq	%rax, 0x10(%rsp)
     751:      	movabsq	$0x206e696874697720, %rax # imm = 0x206E696874697720
     75b:      	movq	%rax, 0x8(%rsp)
     760:      	movabsq	$0x7369206563617254, %rax # imm = 0x7369206563617254
     76a:      	movq	%rax, (%rsp)
     76e:      	movq	%rsp, %rdi
     771:      	movl	$0x38, %eax
     776:      	movl	$0x6, %ecx
     77b:      	movl	$0x38, %esi
     780:      	xorl	%eax, %eax
     782:      	callq	*%rcx
     784:      	jmp	0x75 <perf_unwind_stop+0x75>
     789:      	movabsq	$0xa64252065646f63, %rax # imm = 0xA64252065646F63
     793:      	movq	%rax, 0x28(%rsp)
     798:      	movabsq	$0x20726f727265206f, %rax # imm = 0x20726F727265206F
     7a2:      	movq	%rax, 0x20(%rsp)
     7a7:      	movabsq	$0x742065756420676e, %rax # imm = 0x742065756420676E
     7b1:      	movq	%rax, 0x18(%rsp)
     7b6:      	movabsq	$0x69646e69776e7520, %rax # imm = 0x69646E69776E7520
     7c0:      	movq	%rax, 0x10(%rsp)
     7c5:      	movabsq	$0x7265687472756620, %rax # imm = 0x7265687472756620
     7cf:      	movq	%rax, 0x8(%rsp)
     7d4:      	movabsq	$0x676e6974726f6241, %rax # imm = 0x676E6974726F6241
     7de:      	movq	%rax, (%rsp)
     7e2:      	movb	$0x0, 0x30(%rsp)
     7e7:      	movq	%rsp, %rdi
     7ea:      	movl	$0x31, %eax
     7ef:      	movl	$0x6, %ecx
     7f4:      	movl	0xf2c(%r14), %edx
     7fb:      	movl	$0x31, %esi
     800:      	xorl	%eax, %eax
     802:      	callq	*%rcx
     804:      	movl	0xf2c(%r14), %eax
     80b:      	movl	0x2c0(%r14), %ecx
     812:      	cmpq	$0x80, %rcx
     819:      	jae	0x652 <perf_unwind_stop+0x652>
     81f:      	leal	0x1(%rcx), %edx
     822:      	movl	%edx, 0x2c0(%r14)
     829:      	movl	%eax, %eax
     82b:      	leaq	(%rcx,%rcx,2), %rcx
     82f:      	movq	$0x0, 0x2d0(%r14,%rcx,8)
     83b:      	movq	%rax, 0x2d8(%r14,%rcx,8)
     843:      	movb	$-0x1, 0x2e0(%r14,%rcx,8)
     84c:      	movl	$0x0, 0x2e1(%r14,%rcx,8)
     858:      	movl	$0x0, 0x2e4(%r14,%rcx,8)
     864:      	movl	0xf28(%r14), %eax
     86b:      	cmpl	$-0x1, %eax
     86e:      	je	0xd03 <perf_unwind_stop+0xd03>
     874:      	cmpl	$0xc, %eax
     877:      	jne	0xcc1 <perf_unwind_stop+0xcc1>
     87d:      	movl	(%r14), %eax
     880:      	movl	0x4(%r14), %ecx
     884:      	movzbl	0x1385(%r14), %ebp
     88c:      	movl	%eax, 0x8c(%rsp)
     893:      	movl	%eax, 0x48(%rsp)
     897:      	shlq	$0x20, %rax
     89b:      	orq	%rax, %rcx
     89e:      	movq	%rcx, 0x58(%rsp)
     8a3:      	movq	(%rip), %rdi            # 0x8aa <perf_unwind_stop+0x8aa>
     8aa:      	leaq	0x48(%rsp), %rsi
     8af:      	movl	$0x1, %eax
     8b4:      	callq	*%rax
     8b6:      	movq	%rax, %r15
     8b9:      	movl	$0x5, %eax
     8be:      	callq	*%rax
     8c0:      	cmpb	$0x2, %bpl
     8c4:      	sete	%r13b
     8c8:      	testb	%bpl, %bpl
     8cb:      	je	0xa99 <perf_unwind_stop+0xa99>
     8d1:      	shlb	$0x4, %r13b
     8d5:      	testq	%r15, %r15
     8d8:      	je	0x99f <perf_unwind_stop+0x99f>
     8de:      	movq	(%r15), %rcx
     8e1:      	movq	%rcx, %rsi
     8e4:      	andq	$-0x20, %rsi
     8e8:      	movq	%rax, %rdx
     8eb:      	subq	%rsi, %rdx
     8ee:      	movl	%ecx, %esi
     8f0:      	andb	$0xf, %sil
     8f4:      	movl	$0x5f5e100, %edi        # imm = 0x5F5E100
     8f9:      	shlxq	%rsi, %rdi, %rsi
     8fe:      	cmpq	%rsi, %rdx
     901:      	jae	0x969 <perf_unwind_stop+0x969>
     903:      	movq	(%rip), %rax            # 0x90a <perf_unwind_stop+0x90a>
     90a:      	cmpl	$0x0, (%rax)
     90d:      	je	0xcc1 <perf_unwind_stop+0xcc1>
     913:      	movabsq	$0xa74736166206f, %rax  # imm = 0xA74736166206F
     91d:      	movq	%rax, 0x18(%rsp)
     922:      	movabsq	$0x6f74203a64657469, %rax # imm = 0x6F74203A64657469
     92c:      	movq	%rax, 0x10(%rsp)
     931:      	movabsq	$0x6d696c20746e6576, %rax # imm = 0x6D696C20746E6576
     93b:      	movq	%rax, 0x8(%rsp)
     940:      	movabsq	$0x6520642520444950, %rax # imm = 0x6520642520444950
     94a:      	movq	%rax, (%rsp)
     94e:      	movq	%rsp, %rdi
     951:      	movl	$0x20, %eax
     956:      	movl	$0x6, %ecx
     95b:      	movl	0x48(%rsp), %edx
     95f:      	movl	$0x20, %esi
     964:      	jmp	0x114b <perf_unwind_stop+0x114b>
     969:      	movl	%ecx, %edi
     96b:      	andb	$0x10, %dil
     96f:      	orb	%dil, %r13b
     972:      	movl	$0xffffffff, %edi       # imm = 0xFFFFFFFF
     977:      	addq	%rdi, %rsi
     97a:      	addq	$0x2a05f201, %rsi       # imm = 0x2A05F201
     981:      	cmpq	%rsi, %rdx
     984:      	jae	0x99f <perf_unwind_stop+0x99f>
     986:      	andl	$0xf, %ecx
     989:      	xorl	%edx, %edx
     98b:      	testb	%r13b, %r13b
     98e:      	sete	%dl
     991:      	leal	0x4(,%rdx,4), %edx
     998:      	cmpl	%edx, %ecx
     99a:      	adcb	$0x0, %cl
     99d:      	jmp	0x9a1 <perf_unwind_stop+0x9a1>
     99f:      	xorl	%ecx, %ecx
     9a1:      	movq	(%rip), %r12            # 0x9a8 <perf_unwind_stop+0x9a8>
     9a8:      	cmpl	$0x0, (%r12)
     9ad:      	movzbl	%cl, %r15d
     9b1:      	jne	0x15b3 <perf_unwind_stop+0x15b3>
     9b7:      	andq	$-0x20, %rax
     9bb:      	movzbl	%r13b, %ecx
     9bf:      	orq	%rax, %rcx
     9c2:      	orq	%rcx, %r15
     9c5:      	movq	%r15, 0x60(%rsp)
     9ca:      	movq	(%rip), %rdi            # 0x9d1 <perf_unwind_stop+0x9d1>
     9d1:      	xorl	%eax, %eax
     9d3:      	leaq	0x48(%rsp), %rsi
     9d8:      	leaq	0x60(%rsp), %rdx
     9dd:      	movl	$0x2, %r8d
     9e3:      	xorl	%ecx, %ecx
     9e5:      	callq	*%r8
     9e8:      	testl	%eax, %eax
     9ea:      	je	0xa99 <perf_unwind_stop+0xa99>
     9f0:      	cmpl	$0x0, (%r12)
     9f5:      	jne	0x1722 <perf_unwind_stop+0x1722>
     9fb:      	movl	$0x3d, 0x50(%rsp)
     a03:      	movq	(%rip), %rdi            # 0xa0a <perf_unwind_stop+0xa0a>
     a0a:      	leaq	0x50(%rsp), %rsi
     a0f:      	movl	$0x1, %eax
     a14:      	callq	*%rax
     a16:      	testq	%rax, %rax
     a19:      	jne	0xcbe <perf_unwind_stop+0xcbe>
     a1f:      	cmpl	$0x0, (%r12)
     a24:      	je	0xcc1 <perf_unwind_stop+0xcc1>
     a2a:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     a34:      	movq	%rax, 0x26(%rsp)
     a39:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     a43:      	movq	%rax, 0x20(%rsp)
     a48:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     a52:      	movq	%rax, 0x18(%rsp)
     a57:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     a61:      	movq	%rax, 0x10(%rsp)
     a66:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     a70:      	movq	%rax, 0x8(%rsp)
     a75:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     a7f:      	movq	%rax, (%rsp)
     a83:      	movq	%rsp, %rdi
     a86:      	movl	$0x2e, %eax
     a8b:      	movl	$0x6, %ecx
     a90:      	movl	0x50(%rsp), %edx
     a94:      	jmp	0x1146 <perf_unwind_stop+0x1146>
     a99:      	movb	$0x1, 0x4f(%rsp)
     a9e:      	movq	(%rip), %rdi            # 0xaa5 <perf_unwind_stop+0xaa5>
     aa5:      	xorl	%eax, %eax
     aa7:      	leaq	0x58(%rsp), %rsi
     aac:      	leaq	0x4f(%rsp), %rdx
     ab1:      	movl	$0x2, %r8d
     ab7:      	xorl	%ecx, %ecx
     ab9:      	callq	*%r8
     abc:      	testl	%eax, %eax
     abe:      	je	0xb6e <perf_unwind_stop+0xb6e>
     ac4:      	movq	(%rip), %r15            # 0xacb <perf_unwind_stop+0xacb>
     acb:      	cmpl	$0x0, (%r15)
     acf:      	jne	0x168f <perf_unwind_stop+0x168f>
     ad5:      	movl	$0x3e, 0x60(%rsp)
     add:      	movq	(%rip), %rdi            # 0xae4 <perf_unwind_stop+0xae4>
     ae4:      	leaq	0x60(%rsp), %rsi
     ae9:      	movl	$0x1, %eax
     aee:      	callq	*%rax
     af0:      	testq	%rax, %rax
     af3:      	jne	0xcbe <perf_unwind_stop+0xcbe>
     af9:      	cmpl	$0x0, (%r15)
     afd:      	je	0xcc1 <perf_unwind_stop+0xcc1>
     b03:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     b0d:      	movq	%rax, 0x26(%rsp)
     b12:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     b1c:      	movq	%rax, 0x20(%rsp)
     b21:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     b2b:      	movq	%rax, 0x18(%rsp)
     b30:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     b3a:      	movq	%rax, 0x10(%rsp)
     b3f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     b49:      	movq	%rax, 0x8(%rsp)
     b4e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     b58:      	movq	%rax, (%rsp)
     b5c:      	movq	%rsp, %rdi
     b5f:      	movl	$0x2e, %eax
     b64:      	movl	$0x6, %ecx
     b69:      	jmp	0x1142 <perf_unwind_stop+0x1142>
     b6e:      	testb	%bpl, %bpl
     b71:      	jne	0xb89 <perf_unwind_stop+0xb89>
     b73:      	movq	(%rip), %rdi            # 0xb7a <perf_unwind_stop+0xb7a>
     b7a:      	leaq	0x8c(%rsp), %rsi
     b82:      	movl	$0x3, %eax
     b87:      	callq	*%rax
     b89:      	movl	$0x1, 0x50(%rsp)
     b91:      	movb	$0x1, 0x48(%rsp)
     b96:      	movq	(%rip), %rdi            # 0xb9d <perf_unwind_stop+0xb9d>
     b9d:      	leaq	0x50(%rsp), %rsi
     ba2:      	leaq	0x48(%rsp), %rdx
     ba7:      	movl	$0x1, %eax
     bac:      	movl	$0x2, %r8d
     bb2:      	movl	$0x1, %ecx
     bb7:      	callq	*%r8
     bba:      	testl	%eax, %eax
     bbc:      	js	0xbe3 <perf_unwind_stop+0xbe3>
     bbe:      	movl	$0x42, 0x60(%rsp)
     bc6:      	movq	(%rip), %rdi            # 0xbcd <perf_unwind_stop+0xbcd>
     bcd:      	leaq	0x60(%rsp), %rsi
     bd2:      	movl	$0x1, %eax
     bd7:      	callq	*%rax
     bd9:      	testq	%rax, %rax
     bdc:      	je	0xc41 <perf_unwind_stop+0xc41>
     bde:      	incq	(%rax)
     be1:      	jmp	0xc51 <perf_unwind_stop+0xc51>
     be3:      	movq	(%rip), %rax            # 0xbea <perf_unwind_stop+0xbea>
     bea:      	cmpl	$0x0, (%rax)
     bed:      	je	0xc9a <perf_unwind_stop+0xc9a>
     bf3:      	movabsq	$0xa64657469626968, %rax # imm = 0xA64657469626968
     bfd:      	movq	%rax, 0x10(%rsp)
     c02:      	movabsq	$0x6e69206425206570, %rax # imm = 0x6E69206425206570
     c0c:      	movq	%rax, 0x8(%rsp)
     c11:      	movabsq	$0x797420746e657645, %rax # imm = 0x797420746E657645
     c1b:      	movq	%rax, (%rsp)
     c1f:      	movb	$0x0, 0x18(%rsp)
     c24:      	movq	%rsp, %rdi
     c27:      	movl	$0x19, %eax
     c2c:      	movl	$0x6, %ecx
     c31:      	movl	$0x19, %esi
     c36:      	movl	$0x1, %edx
     c3b:      	xorl	%eax, %eax
     c3d:      	callq	*%rcx
     c3f:      	jmp	0xc9a <perf_unwind_stop+0xc9a>
     c41:      	movq	(%rip), %rax            # 0xc48 <perf_unwind_stop+0xc48>
     c48:      	cmpl	$0x0, (%rax)
     c4b:      	jne	0x19cb <perf_unwind_stop+0x19cb>
     c51:      	movl	$0x1, 0x60(%rsp)
     c59:      	movq	(%rip), %rsi            # 0xc60 <perf_unwind_stop+0xc60>
     c60:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     c65:      	leaq	0x60(%rsp), %rcx
     c6a:      	movl	$0x4, %edx
     c6f:      	movl	$0x19, %r9d
     c75:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     c7a:      	movq	%rbx, %rdi
     c7d:      	movl	$0x4, %r8d
     c83:      	callq	*%r9
     c86:      	testl	%eax, %eax
     c88:      	jns	0xc9a <perf_unwind_stop+0xc9a>
     c8a:      	movq	(%rip), %rcx            # 0xc91 <perf_unwind_stop+0xc91>
     c91:      	cmpl	$0x0, (%rcx)
     c94:      	jne	0x18e5 <perf_unwind_stop+0x18e5>
     c9a:      	movl	$0x41, 0x60(%rsp)
     ca2:      	movq	(%rip), %rdi            # 0xca9 <perf_unwind_stop+0xca9>
     ca9:      	leaq	0x60(%rsp), %rsi
     cae:      	movl	$0x1, %eax
     cb3:      	callq	*%rax
     cb5:      	testq	%rax, %rax
     cb8:      	je	0x10cc <perf_unwind_stop+0x10cc>
     cbe:      	incq	(%rax)
     cc1:      	movl	0xf28(%r14), %eax
     cc8:      	movl	%eax, 0x60(%rsp)
     ccc:      	movq	(%rip), %rdi            # 0xcd3 <perf_unwind_stop+0xcd3>
     cd3:      	leaq	0x60(%rsp), %rsi
     cd8:      	movl	$0x1, %eax
     cdd:      	callq	*%rax
     cdf:      	testq	%rax, %rax
     ce2:      	je	0xcf3 <perf_unwind_stop+0xcf3>
     ce4:      	incq	(%rax)
     ce7:      	cmpl	$0x1, 0x2c0(%r14)
     cef:      	je	0xd0d <perf_unwind_stop+0xd0d>
     cf1:      	jmp	0xd1b <perf_unwind_stop+0xd1b>
     cf3:      	movq	(%rip), %rax            # 0xcfa <perf_unwind_stop+0xcfa>
     cfa:      	cmpl	$0x0, (%rax)
     cfd:      	jne	0x136a <perf_unwind_stop+0x136a>
     d03:      	cmpl	$0x1, 0x2c0(%r14)
     d0b:      	jne	0xd1b <perf_unwind_stop+0xd1b>
     d0d:      	cmpl	$0x0, 0x2bc(%r14)
     d15:      	js	0xf91 <perf_unwind_stop+0xf91>
     d1b:      	movl	(%r14), %eax
     d1e:      	movl	%eax, 0x48(%rsp)
     d22:      	movq	(%rip), %rdi            # 0xd29 <perf_unwind_stop+0xd29>
     d29:      	leaq	0x48(%rsp), %rsi
     d2e:      	movl	$0x1, %eax
     d33:      	callq	*%rax
     d35:      	testq	%rax, %rax
     d38:      	je	0xe41 <perf_unwind_stop+0xe41>
     d3e:      	movq	%rax, %r15
     d41:      	movq	$0x0, 0x60(%rsp)
     d4a:      	movq	$0x0, 0x58(%rsp)
     d53:      	movl	$0x23, %eax
     d58:      	callq	*%rax
     d5a:      	movq	(%rip), %rcx            # 0xd61 <perf_unwind_stop+0xd61>
     d61:      	addq	(%rcx), %rax
     d64:      	leaq	0x58(%rsp), %rdi
     d69:      	movl	$0x8, %ecx
     d6e:      	movl	$0x71, %r8d
     d74:      	movl	$0x8, %esi
     d79:      	movq	%rax, %rdx
     d7c:      	callq	*%r8
     d7f:      	movq	(%rip), %r12            # 0xd86 <perf_unwind_stop+0xd86>
     d86:      	movl	(%r12), %ecx
     d8a:      	testq	%rax, %rax
     d8d:      	je	0xed0 <perf_unwind_stop+0xed0>
     d93:      	testl	%ecx, %ecx
     d95:      	jne	0x12af <perf_unwind_stop+0x12af>
     d9b:      	movl	$0x4, 0x50(%rsp)
     da3:      	movq	(%rip), %rdi            # 0xdaa <perf_unwind_stop+0xdaa>
     daa:      	leaq	0x50(%rsp), %rsi
     daf:      	movl	$0x1, %eax
     db4:      	callq	*%rax
     db6:      	testq	%rax, %rax
     db9:      	je	0xfb6 <perf_unwind_stop+0xfb6>
     dbf:      	incq	(%rax)
     dc2:      	cmpl	$0x0, (%r12)
     dc7:      	je	0x14df <perf_unwind_stop+0x14df>
     dcd:      	movabsq	$0xa7274705f6d20, %rax  # imm = 0xA7274705F6D20
     dd7:      	movq	%rax, 0x26(%rsp)
     ddc:      	movabsq	$0x6d20646165722074, %rax # imm = 0x6D20646165722074
     de6:      	movq	%rax, 0x20(%rsp)
     deb:      	movabsq	$0x276e6163203b6573, %rax # imm = 0x276E6163203B6573
     df5:      	movq	%rax, 0x18(%rsp)
     dfa:      	movabsq	$0x6162206473742074, %rax # imm = 0x6162206473742074
     e04:      	movq	%rax, 0x10(%rsp)
     e09:      	movabsq	$0x6567206f74206465, %rax # imm = 0x6567206F74206465
     e13:      	movq	%rax, 0x8(%rsp)
     e18:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
     e22:      	movq	%rax, (%rsp)
     e26:      	movq	%rsp, %rdi
     e29:      	movl	$0x2e, %eax
     e2e:      	movl	$0x6, %ecx
     e33:      	movl	$0x2e, %esi
     e38:      	xorl	%eax, %eax
     e3a:      	callq	*%rcx
     e3c:      	jmp	0x14df <perf_unwind_stop+0x14df>
     e41:      	movq	(%rip), %rax            # 0xe48 <perf_unwind_stop+0xe48>
     e48:      	cmpl	$0x0, (%rax)
     e4b:      	je	0x14df <perf_unwind_stop+0x14df>
     e51:      	movabsq	$0x7972616e6962206f, %rax # imm = 0x7972616E6962206F
     e5b:      	movq	%rax, 0x28(%rsp)
     e60:      	movabsq	$0x6720612073612064, %rax # imm = 0x6720612073612064
     e6a:      	movq	%rax, 0x20(%rsp)
     e6f:      	movabsq	$0x657a696e676f6365, %rax # imm = 0x657A696E676F6365
     e79:      	movq	%rax, 0x18(%rsp)
     e7e:      	movabsq	$0x7220746f6e206425, %rax # imm = 0x7220746F6E206425
     e88:      	movq	%rax, 0x10(%rsp)
     e8d:      	movabsq	$0x202c737465736666, %rax # imm = 0x202C737465736666
     e97:      	movq	%rax, 0x8(%rsp)
     e9c:      	movabsq	$0x6f206f6e203a6c63, %rax # imm = 0x6F206F6E203A6C63
     ea6:      	movq	%rax, (%rsp)
     eaa:      	movw	$0xa, 0x30(%rsp)
     eb1:      	movq	%rsp, %rdi
     eb4:      	movl	$0x32, %eax
     eb9:      	movl	$0x6, %ecx
     ebe:      	movl	0x48(%rsp), %edx
     ec2:      	movl	$0x32, %esi
     ec7:      	xorl	%eax, %eax
     ec9:      	callq	*%rcx
     ecb:      	jmp	0x14df <perf_unwind_stop+0x14df>
     ed0:      	testl	%ecx, %ecx
     ed2:      	jne	0x1455 <perf_unwind_stop+0x1455>
     ed8:      	movslq	0x18(%r15), %rax
     edc:      	testq	%rax, %rax
     edf:      	je	0x14d4 <perf_unwind_stop+0x14d4>
     ee5:      	addq	0x58(%rsp), %rax
     eea:      	leaq	0x60(%rsp), %rdi
     eef:      	movl	$0x8, %ecx
     ef4:      	movl	$0x70, %r8d
     efa:      	movslq	0x18(%r15), %rdx
     efe:      	addq	0x58(%rsp), %rdx
     f03:      	movl	$0x8, %esi
     f08:      	callq	*%r8
     f0b:      	movl	(%r12), %ecx
     f0f:      	testq	%rax, %rax
     f12:      	je	0x1044 <perf_unwind_stop+0x1044>
     f18:      	testl	%ecx, %ecx
     f1a:      	je	0x14df <perf_unwind_stop+0x14df>
     f20:      	movabsq	$0x29786c2528657361, %rax # imm = 0x29786C2528657361
     f2a:      	movq	%rax, 0x20(%rsp)
     f2f:      	movabsq	$0x625f736c74202c72, %rax # imm = 0x625F736C74202C72
     f39:      	movq	%rax, 0x18(%rsp)
     f3e:      	movabsq	$0x6464615f67206461, %rax # imm = 0x6464615F67206461
     f48:      	movq	%rax, 0x10(%rsp)
     f4d:      	movabsq	$0x6572206f74206465, %rax # imm = 0x6572206F74206465
     f57:      	movq	%rax, 0x8(%rsp)
     f5c:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
     f66:      	movq	%rax, (%rsp)
     f6a:      	movw	$0xa, 0x28(%rsp)
     f71:      	movq	%rsp, %rdi
     f74:      	movl	$0x2a, %eax
     f79:      	movl	$0x6, %ecx
     f7e:      	movq	0x58(%rsp), %rdx
     f83:      	movl	$0x2a, %esi
     f88:      	xorl	%eax, %eax
     f8a:      	callq	*%rcx
     f8c:      	jmp	0x14df <perf_unwind_stop+0x14df>
     f91:      	cmpl	$0x0, 0xf2c(%r14)
     f99:      	je	0xd1b <perf_unwind_stop+0xd1b>
     f9f:      	xorl	%eax, %eax
     fa1:      	movq	(%rip), %rcx            # 0xfa8 <perf_unwind_stop+0xfa8>
     fa8:      	cmpb	$0x0, (%rcx)
     fab:      	jne	0x1529 <perf_unwind_stop+0x1529>
     fb1:      	jmp	0xd1b <perf_unwind_stop+0xd1b>
     fb6:      	cmpl	$0x0, (%r12)
     fbb:      	je	0x14df <perf_unwind_stop+0x14df>
     fc1:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     fcb:      	movq	%rax, 0x26(%rsp)
     fd0:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     fda:      	movq	%rax, 0x20(%rsp)
     fdf:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     fe9:      	movq	%rax, 0x18(%rsp)
     fee:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     ff8:      	movq	%rax, 0x10(%rsp)
     ffd:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1007:      	movq	%rax, 0x8(%rsp)
    100c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1016:      	movq	%rax, (%rsp)
    101a:      	movq	%rsp, %rdi
    101d:      	movl	$0x2e, %eax
    1022:      	movl	$0x6, %ecx
    1027:      	movl	0x50(%rsp), %edx
    102b:      	movl	$0x2e, %esi
    1030:      	xorl	%eax, %eax
    1032:      	callq	*%rcx
    1034:      	cmpl	$0x0, (%r12)
    1039:      	je	0x14df <perf_unwind_stop+0x14df>
    103f:      	jmp	0xdcd <perf_unwind_stop+0xdcd>
    1044:      	testl	%ecx, %ecx
    1046:      	jne	0x1876 <perf_unwind_stop+0x1876>
    104c:      	movl	(%r15), %eax
    104f:      	addq	0x60(%rsp), %rax
    1054:      	leaq	0x50(%rsp), %rdi
    1059:      	movl	$0x8, %ecx
    105e:      	movl	$0x70, %r8d
    1064:      	movl	(%r15), %edx
    1067:      	addq	0x60(%rsp), %rdx
    106c:      	movl	$0x8, %esi
    1071:      	callq	*%r8
    1074:      	movl	(%r12), %ecx
    1078:      	testq	%rax, %rax
    107b:      	je	0x1154 <perf_unwind_stop+0x1154>
    1081:      	testl	%ecx, %ecx
    1083:      	je	0x14df <perf_unwind_stop+0x14df>
    1089:      	movabsq	$0xa726464615f72, %rax  # imm = 0xA726464615F72
    1093:      	movq	%rax, 0xf(%rsp)
    1098:      	movabsq	$0x7274705f6d206465, %rax # imm = 0x7274705F6D206465
    10a2:      	movq	%rax, 0x8(%rsp)
    10a7:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
    10b1:      	movq	%rax, (%rsp)
    10b5:      	movq	%rsp, %rdi
    10b8:      	movl	$0x17, %eax
    10bd:      	movl	$0x6, %ecx
    10c2:      	movl	$0x17, %esi
    10c7:      	jmp	0xe38 <perf_unwind_stop+0xe38>
    10cc:      	movq	(%rip), %rax            # 0x10d3 <perf_unwind_stop+0x10d3>
    10d3:      	cmpl	$0x0, (%rax)
    10d6:      	je	0xcc1 <perf_unwind_stop+0xcc1>
    10dc:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    10e6:      	movq	%rax, 0x26(%rsp)
    10eb:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    10f5:      	movq	%rax, 0x20(%rsp)
    10fa:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1104:      	movq	%rax, 0x18(%rsp)
    1109:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1113:      	movq	%rax, 0x10(%rsp)
    1118:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1122:      	movq	%rax, 0x8(%rsp)
    1127:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1131:      	movq	%rax, (%rsp)
    1135:      	movq	%rsp, %rdi
    1138:      	movl	$0x2e, %eax
    113d:      	movl	$0x6, %ecx
    1142:      	movl	0x60(%rsp), %edx
    1146:      	movl	$0x2e, %esi
    114b:      	xorl	%eax, %eax
    114d:      	callq	*%rcx
    114f:      	jmp	0xcc1 <perf_unwind_stop+0xcc1>
    1154:      	testl	%ecx, %ecx
    1156:      	jne	0x1971 <perf_unwind_stop+0x1971>
    115c:      	movq	0x50(%rsp), %rax
    1161:      	testq	%rax, %rax
    1164:      	je	0x14df <perf_unwind_stop+0x14df>
    116a:      	movq	%rax, 0xf78(%r14)
    1171:      	cmpl	$0x0, (%r12)
    1176:      	jne	0x1ac6 <perf_unwind_stop+0x1ac6>
    117c:      	movl	$0x60, 0x60(%rsp)
    1184:      	movq	(%rip), %rdi            # 0x118b <perf_unwind_stop+0x118b>
    118b:      	leaq	0x60(%rsp), %rsi
    1190:      	movl	$0x1, %eax
    1195:      	callq	*%rax
    1197:      	testq	%rax, %rax
    119a:      	je	0x11a1 <perf_unwind_stop+0x11a1>
    119c:      	incq	(%rax)
    119f:      	jmp	0x11ac <perf_unwind_stop+0x11ac>
    11a1:      	cmpl	$0x0, (%r12)
    11a6:      	jne	0x1b58 <perf_unwind_stop+0x1b58>
    11ac:      	movl	$0x0, (%rsp)
    11b3:      	movq	(%rip), %rdi            # 0x11ba <perf_unwind_stop+0x11ba>
    11ba:      	movq	%rsp, %rsi
    11bd:      	movl	$0x1, %eax
    11c2:      	callq	*%rax
    11c4:      	testq	%rax, %rax
    11c7:      	je	0x120c <perf_unwind_stop+0x120c>
    11c9:      	movzbl	0x1384(%rax), %ecx
    11d0:      	movl	$0x9, %edx
    11d5:      	cmpb	$0x1d, %cl
    11d8:      	jb	0x1239 <perf_unwind_stop+0x1239>
    11da:      	movq	%rax, %r15
    11dd:      	movl	$0x5, 0xf2c(%rax)
    11e7:      	movl	$0x44, 0x60(%rsp)
    11ef:      	movq	(%rip), %rdi            # 0x11f6 <perf_unwind_stop+0x11f6>
    11f6:      	leaq	0x60(%rsp), %rsi
    11fb:      	movl	$0x1, %eax
    1200:      	callq	*%rax
    1202:      	testq	%rax, %rax
    1205:      	je	0x1221 <perf_unwind_stop+0x1221>
    1207:      	incq	(%rax)
    120a:      	jmp	0x122c <perf_unwind_stop+0x122c>
    120c:      	movq	(%rip), %rsi            # 0x1213 <perf_unwind_stop+0x1213>
    1213:      	xorl	%eax, %eax
    1215:      	movl	$0xc, %ecx
    121a:      	movq	%rbx, %rdi
    121d:      	xorl	%edx, %edx
    121f:      	jmp	0x1252 <perf_unwind_stop+0x1252>
    1221:      	cmpl	$0x0, (%r12)
    1226:      	jne	0x1bd0 <perf_unwind_stop+0x1bd0>
    122c:      	movq	%r15, %rax
    122f:      	movzbl	0x1384(%r15), %ecx
    1237:      	xorl	%edx, %edx
    1239:      	incb	%cl
    123b:      	movb	%cl, 0x1384(%rax)
    1241:      	movl	%edx, %eax
    1243:      	movq	(%rip), %rsi            # 0x124a <perf_unwind_stop+0x124a>
    124a:      	movl	$0xc, %ecx
    124f:      	movq	%rbx, %rdi
    1252:      	callq	*%rcx
    1254:      	jmp	0x14df <perf_unwind_stop+0x14df>
    1259:      	movabsq	$0xa65756c617620, %rax  # imm = 0xA65756C617620
    1263:      	movq	%rax, 0x15(%rsp)
    1268:      	movabsq	$0x6176206573616270, %rax # imm = 0x6176206573616270
    1272:      	movq	%rax, 0x10(%rsp)
    1277:      	movabsq	$0x742064616572206f, %rax # imm = 0x742064616572206F
    1281:      	movq	%rax, 0x8(%rsp)
    1286:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1290:      	movq	%rax, (%rsp)
    1294:      	movq	%rsp, %rdi
    1297:      	movl	$0x1d, %eax
    129c:      	movl	$0x6, %ecx
    12a1:      	movl	$0x1d, %esi
    12a6:      	xorl	%eax, %eax
    12a8:      	callq	*%rcx
    12aa:      	jmp	0xb2 <perf_unwind_stop+0xb2>
    12af:      	movabsq	$0xa65756c617620, %rax  # imm = 0xA65756C617620
    12b9:      	movq	%rax, 0x15(%rsp)
    12be:      	movabsq	$0x6176206573616270, %rax # imm = 0x6176206573616270
    12c8:      	movq	%rax, 0x10(%rsp)
    12cd:      	movabsq	$0x742064616572206f, %rax # imm = 0x742064616572206F
    12d7:      	movq	%rax, 0x8(%rsp)
    12dc:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    12e6:      	movq	%rax, (%rsp)
    12ea:      	movq	%rsp, %rdi
    12ed:      	movl	$0x1d, %eax
    12f2:      	movl	$0x6, %ecx
    12f7:      	movl	$0x1d, %esi
    12fc:      	xorl	%eax, %eax
    12fe:      	callq	*%rcx
    1300:      	jmp	0xd9b <perf_unwind_stop+0xd9b>
    1305:      	movabsq	$0xa6c6c75662073, %rax  # imm = 0xA6C6C75662073
    130f:      	movq	%rax, 0x1d(%rsp)
    1314:      	movabsq	$0x66207369206b6361, %rax # imm = 0x66207369206B6361
    131e:      	movq	%rax, 0x18(%rsp)
    1323:      	movabsq	$0x7473203a656d6172, %rax # imm = 0x7473203A656D6172
    132d:      	movq	%rax, 0x10(%rsp)
    1332:      	movabsq	$0x662068737570206f, %rax # imm = 0x662068737570206F
    133c:      	movq	%rax, 0x8(%rsp)
    1341:      	movabsq	$0x7420656c62616e75, %rax # imm = 0x7420656C62616E75
    134b:      	movq	%rax, (%rsp)
    134f:      	movq	%rsp, %rdi
    1352:      	movl	$0x25, %eax
    1357:      	movl	$0x6, %ecx
    135c:      	movl	$0x25, %esi
    1361:      	xorl	%eax, %eax
    1363:      	callq	*%rcx
    1365:      	jmp	0x65c <perf_unwind_stop+0x65c>
    136a:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1374:      	movq	%rax, 0x26(%rsp)
    1379:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1383:      	movq	%rax, 0x20(%rsp)
    1388:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1392:      	movq	%rax, 0x18(%rsp)
    1397:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    13a1:      	movq	%rax, 0x10(%rsp)
    13a6:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    13b0:      	movq	%rax, 0x8(%rsp)
    13b5:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    13bf:      	movq	%rax, (%rsp)
    13c3:      	movq	%rsp, %rdi
    13c6:      	movl	$0x2e, %eax
    13cb:      	movl	$0x6, %ecx
    13d0:      	movl	0x60(%rsp), %edx
    13d4:      	movl	$0x2e, %esi
    13d9:      	xorl	%eax, %eax
    13db:      	callq	*%rcx
    13dd:      	cmpl	$0x1, 0x2c0(%r14)
    13e5:      	je	0xd0d <perf_unwind_stop+0xd0d>
    13eb:      	jmp	0xd1b <perf_unwind_stop+0xd1b>
    13f0:      	movabsq	$0x786c6c2578302074, %rax # imm = 0x786C6C2578302074
    13fa:      	movq	%rax, 0x18(%rsp)
    13ff:      	movabsq	$0x6120656220646c75, %rax # imm = 0x6120656220646C75
    1409:      	movq	%rax, 0x10(%rsp)
    140e:      	movabsq	$0x6f68732072747020, %rax # imm = 0x6F68732072747020
    1418:      	movq	%rax, 0x8(%rsp)
    141d:      	movabsq	$0x72726f63204d5041, %rax # imm = 0x72726F63204D5041
    1427:      	movq	%rax, (%rsp)
    142b:      	movw	$0xa, 0x20(%rsp)
    1432:      	movq	%rsp, %rdi
    1435:      	movl	$0x22, %eax
    143a:      	movl	$0x6, %ecx
    143f:      	movq	(%r15), %rdx
    1442:      	addq	0x58(%rsp), %rdx
    1447:      	movl	$0x22, %esi
    144c:      	xorl	%eax, %eax
    144e:      	callq	*%rcx
    1450:      	jmp	0xf0 <perf_unwind_stop+0xf0>
    1455:      	movabsq	$0x6425203a74657366, %rax # imm = 0x6425203A74657366
    145f:      	movq	%rax, 0x20(%rsp)
    1464:      	movabsq	$0x666f2067202c786c, %rax # imm = 0x666F2067202C786C
    146e:      	movq	%rax, 0x18(%rsp)
    1473:      	movabsq	$0x2578302074612065, %rax # imm = 0x2578302074612065
    147d:      	movq	%rax, 0x10(%rsp)
    1482:      	movabsq	$0x7361625f64737420, %rax # imm = 0x7361625F64737420
    148c:      	movq	%rax, 0x8(%rsp)
    1491:      	movabsq	$0x64616572203a6c63, %rax # imm = 0x64616572203A6C63
    149b:      	movq	%rax, (%rsp)
    149f:      	movw	$0xa, 0x28(%rsp)
    14a6:      	movq	%rsp, %rdi
    14a9:      	movl	$0x2a, %eax
    14ae:      	movl	$0x6, %r8d
    14b4:      	movq	0x58(%rsp), %rdx
    14b9:      	movl	0x18(%r15), %ecx
    14bd:      	movl	$0x2a, %esi
    14c2:      	xorl	%eax, %eax
    14c4:      	callq	*%r8
    14c7:      	movslq	0x18(%r15), %rax
    14cb:      	testq	%rax, %rax
    14ce:      	jne	0xee5 <perf_unwind_stop+0xee5>
    14d4:      	cmpl	$0x0, (%r12)
    14d9:      	jne	0x1780 <perf_unwind_stop+0x1780>
    14df:      	movl	$0x80, %eax
    14e4:      	subl	0x2c0(%r14), %eax
    14eb:      	shlq	$0x3, %rax
    14ef:      	leaq	(%rax,%rax,2), %rax
    14f3:      	movl	$0xed0, %r8d            # imm = 0xED0
    14f9:      	subq	%rax, %r8
    14fc:      	xorl	%eax, %eax
    14fe:      	cmpq	$0xed0, %r8             # imm = 0xED0
    1505:      	ja	0x1529 <perf_unwind_stop+0x1529>
    1507:      	movq	(%rip), %rsi            # 0x150e <perf_unwind_stop+0x150e>
    150e:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
    1513:      	movl	$0x19, %r9d
    1519:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    151e:      	movq	%rbx, %rdi
    1521:      	movq	%r14, %rcx
    1524:      	callq	*%r9
    1527:      	xorl	%eax, %eax
    1529:      	addq	$0x98, %rsp
    1530:      	popq	%rbx
    1531:      	popq	%r12
    1533:      	popq	%r13
    1535:      	popq	%r14
    1537:      	popq	%r15
    1539:      	popq	%rbp
    153a:      	retq
    153b:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1545:      	movq	%rax, 0x26(%rsp)
    154a:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1554:      	movq	%rax, 0x20(%rsp)
    1559:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1563:      	movq	%rax, 0x18(%rsp)
    1568:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1572:      	movq	%rax, 0x10(%rsp)
    1577:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1581:      	movq	%rax, 0x8(%rsp)
    1586:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1590:      	movq	%rax, (%rsp)
    1594:      	movq	%rsp, %rdi
    1597:      	movl	$0x2e, %eax
    159c:      	movl	$0x6, %ecx
    15a1:      	movl	0x60(%rsp), %edx
    15a5:      	movl	$0x2e, %esi
    15aa:      	xorl	%eax, %eax
    15ac:      	callq	*%rcx
    15ae:      	jmp	0x1ce <perf_unwind_stop+0x1ce>
    15b3:      	movabsq	$0xa64253d74706d, %rcx  # imm = 0xA64253D74706D
    15bd:      	movq	%rcx, 0x17(%rsp)
    15c2:      	movabsq	$0x6d65747461202c64, %rcx # imm = 0x6D65747461202C64
    15cc:      	movq	%rcx, 0x10(%rsp)
    15d1:      	movabsq	$0x6e657320746e6576, %rcx # imm = 0x6E657320746E6576
    15db:      	movq	%rcx, 0x8(%rsp)
    15e0:      	movabsq	$0x6520642520444950, %rcx # imm = 0x6520642520444950
    15ea:      	movq	%rcx, (%rsp)
    15ee:      	movq	%rsp, %rdi
    15f1:      	movl	$0x1f, %ecx
    15f6:      	movl	$0x6, %r8d
    15fc:      	movl	0x48(%rsp), %edx
    1600:      	movl	$0x1f, %esi
    1605:      	movl	%r15d, %ecx
    1608:      	movq	%rax, 0x90(%rsp)
    1610:      	xorl	%eax, %eax
    1612:      	callq	*%r8
    1615:      	movq	0x90(%rsp), %rax
    161d:      	jmp	0x9b7 <perf_unwind_stop+0x9b7>
    1622:      	movabsq	$0x74706d6520736920, %rax # imm = 0x74706D6520736920
    162c:      	movq	%rax, 0x20(%rsp)
    1631:      	movabsq	$0x6b63617473206568, %rax # imm = 0x6B63617473206568
    163b:      	movq	%rax, 0x18(%rsp)
    1640:      	movabsq	$0x7420747562206465, %rax # imm = 0x7420747562206465
    164a:      	movq	%rax, 0x10(%rsp)
    164f:      	movabsq	$0x6c6c616320706f74, %rax # imm = 0x6C6C616320706F74
    1659:      	movq	%rax, 0x8(%rsp)
    165e:      	movabsq	$0x735f646e69776e75, %rax # imm = 0x735F646E69776E75
    1668:      	movq	%rax, (%rsp)
    166c:      	movl	$0xa7974, 0x27(%rsp)    # imm = 0xA7974
    1674:      	movq	%rsp, %rdi
    1677:      	movl	$0x2b, %eax
    167c:      	movl	$0x6, %ecx
    1681:      	movl	$0x2b, %esi
    1686:      	xorl	%eax, %eax
    1688:      	callq	*%rcx
    168a:      	jmp	0x5d0 <perf_unwind_stop+0x5d0>
    168f:      	movabsq	$0xa6425203a6425, %rcx  # imm = 0xA6425203A6425
    1699:      	movq	%rcx, 0x2d(%rsp)
    169e:      	movabsq	$0x3a6425203a444954, %rcx # imm = 0x3A6425203A444954
    16a8:      	movq	%rcx, 0x28(%rsp)
    16ad:      	movabsq	$0x2064252044495020, %rcx # imm = 0x2064252044495020
    16b7:      	movq	%rcx, 0x20(%rsp)
    16bc:      	movabsq	$0x687469772073746e, %rcx # imm = 0x687469772073746E
    16c6:      	movq	%rcx, 0x18(%rsp)
    16cb:      	movabsq	$0x6576655f64697020, %rcx # imm = 0x6576655F64697020
    16d5:      	movq	%rcx, 0x10(%rsp)
    16da:      	movabsq	$0x657461647075206f, %rcx # imm = 0x657461647075206F
    16e4:      	movq	%rcx, 0x8(%rsp)
    16e9:      	movabsq	$0x742064656c696146, %rcx # imm = 0x742064656C696146
    16f3:      	movq	%rcx, (%rsp)
    16f7:      	movl	0x58(%rsp), %ecx
    16fb:      	movq	%rsp, %rdi
    16fe:      	movl	$0x35, %edx
    1703:      	movl	$0x6, %r9d
    1709:      	movl	0x8c(%rsp), %edx
    1710:      	movl	$0x35, %esi
    1715:      	movl	%eax, %r8d
    1718:      	xorl	%eax, %eax
    171a:      	callq	*%r9
    171d:      	jmp	0xad5 <perf_unwind_stop+0xad5>
    1722:      	movabsq	$0xa6425203a6425, %rcx  # imm = 0xA6425203A6425
    172c:      	movq	%rcx, 0x15(%rsp)
    1731:      	movabsq	$0x3a64252044495020, %rcx # imm = 0x3A64252044495020
    173b:      	movq	%rcx, 0x10(%rsp)
    1740:      	movabsq	$0x74726f706572206f, %rcx # imm = 0x74726F706572206F
    174a:      	movq	%rcx, 0x8(%rsp)
    174f:      	movabsq	$0x742064656c696146, %rcx # imm = 0x742064656C696146
    1759:      	movq	%rcx, (%rsp)
    175d:      	movq	%rsp, %rdi
    1760:      	movl	$0x1d, %ecx
    1765:      	movl	$0x6, %r8d
    176b:      	movl	0x48(%rsp), %edx
    176f:      	movl	$0x1d, %esi
    1774:      	movl	%eax, %ecx
    1776:      	xorl	%eax, %eax
    1778:      	callq	*%r8
    177b:      	jmp	0x9fb <perf_unwind_stop+0x9fb>
    1780:      	movabsq	$0xa3436646d6120, %rax  # imm = 0xA3436646D6120
    178a:      	movq	%rax, 0x28(%rsp)
    178f:      	movabsq	$0x726f6620676e6973, %rax # imm = 0x726F6620676E6973
    1799:      	movq	%rax, 0x20(%rsp)
    179e:      	movabsq	$0x73696d207265746e, %rax # imm = 0x73696D207265746E
    17a8:      	movq	%rax, 0x18(%rsp)
    17ad:      	movabsq	$0x696f70206720726f, %rax # imm = 0x696F70206720726F
    17b7:      	movq	%rax, 0x10(%rsp)
    17bc:      	movabsq	$0x662074657366666f, %rax # imm = 0x662074657366666F
    17c6:      	movq	%rax, 0x8(%rsp)
    17cb:      	movabsq	$0x20534c54203a6c63, %rax # imm = 0x20534C54203A6C63
    17d5:      	movq	%rax, (%rsp)
    17d9:      	movq	%rsp, %rdi
    17dc:      	movl	$0x30, %eax
    17e1:      	movl	$0x6, %ecx
    17e6:      	movl	$0x30, %esi
    17eb:      	jmp	0xe38 <perf_unwind_stop+0xe38>
    17f0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    17fa:      	movq	%rax, 0x26(%rsp)
    17ff:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1809:      	movq	%rax, 0x20(%rsp)
    180e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1818:      	movq	%rax, 0x18(%rsp)
    181d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1827:      	movq	%rax, 0x10(%rsp)
    182c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1836:      	movq	%rax, 0x8(%rsp)
    183b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1845:      	movq	%rax, (%rsp)
    1849:      	movq	%rsp, %rdi
    184c:      	movl	$0x2e, %eax
    1851:      	movl	$0x6, %ecx
    1856:      	movl	0x60(%rsp), %edx
    185a:      	movl	$0x2e, %esi
    185f:      	xorl	%eax, %eax
    1861:      	callq	*%rcx
    1863:      	cmpl	$0x0, 0xf2c(%r14)
    186b:      	jne	0x61e <perf_unwind_stop+0x61e>
    1871:      	jmp	0x5fd <perf_unwind_stop+0x5fd>
    1876:      	movabsq	$0xa78257830202b, %rax  # imm = 0xA78257830202B
    1880:      	movq	%rax, 0x20(%rsp)
    1885:      	movabsq	$0x20786c2578302074, %rax # imm = 0x20786C2578302074
    188f:      	movq	%rax, 0x18(%rsp)
    1894:      	movabsq	$0x6120726464615f72, %rax # imm = 0x6120726464615F72
    189e:      	movq	%rax, 0x10(%rsp)
    18a3:      	movabsq	$0x74705f6d20676e69, %rax # imm = 0x74705F6D20676E69
    18ad:      	movq	%rax, 0x8(%rsp)
    18b2:      	movabsq	$0x64616572203a6c63, %rax # imm = 0x64616572203A6C63
    18bc:      	movq	%rax, (%rsp)
    18c0:      	movq	%rsp, %rdi
    18c3:      	movl	$0x28, %eax
    18c8:      	movl	$0x6, %r8d
    18ce:      	movq	0x60(%rsp), %rdx
    18d3:      	movl	(%r15), %ecx
    18d6:      	movl	$0x28, %esi
    18db:      	xorl	%eax, %eax
    18dd:      	callq	*%r8
    18e0:      	jmp	0x104c <perf_unwind_stop+0x104c>
    18e5:      	movabsq	$0xa642520726f72, %rcx  # imm = 0xA642520726F72
    18ef:      	movq	%rcx, 0x2e(%rsp)
    18f4:      	movabsq	$0x6f727265203a6425, %rcx # imm = 0x6F727265203A6425
    18fe:      	movq	%rcx, 0x28(%rsp)
    1903:      	movabsq	$0x20746e6576652064, %rcx # imm = 0x20746E6576652064
    190d:      	movq	%rcx, 0x20(%rsp)
    1912:      	movabsq	$0x6e6573206f742064, %rcx # imm = 0x6E6573206F742064
    191c:      	movq	%rcx, 0x18(%rsp)
    1921:      	movabsq	$0x656c696166207265, %rcx # imm = 0x656C696166207265
    192b:      	movq	%rcx, 0x10(%rsp)
    1930:      	movabsq	$0x67676972745f646e, %rcx # imm = 0x67676972745F646E
    193a:      	movq	%rcx, 0x8(%rsp)
    193f:      	movabsq	$0x65735f746e657665, %rcx # imm = 0x65735F746E657665
    1949:      	movq	%rcx, (%rsp)
    194d:      	movq	%rsp, %rdi
    1950:      	movl	$0x36, %ecx
    1955:      	movl	$0x6, %r8d
    195b:      	movl	$0x36, %esi
    1960:      	movl	$0x1, %edx
    1965:      	movl	%eax, %ecx
    1967:      	xorl	%eax, %eax
    1969:      	callq	*%r8
    196c:      	jmp	0xc9a <perf_unwind_stop+0xc9a>
    1971:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    197b:      	movq	%rax, 0xe(%rsp)
    1980:      	movabsq	$0x3020726464615f72, %rax # imm = 0x3020726464615F72
    198a:      	movq	%rax, 0x8(%rsp)
    198f:      	movabsq	$0x74705f6d203a6c63, %rax # imm = 0x74705F6D203A6C63
    1999:      	movq	%rax, (%rsp)
    199d:      	movq	%rsp, %rdi
    19a0:      	movl	$0x16, %eax
    19a5:      	movl	$0x6, %ecx
    19aa:      	movq	0x50(%rsp), %rdx
    19af:      	movl	$0x16, %esi
    19b4:      	xorl	%eax, %eax
    19b6:      	callq	*%rcx
    19b8:      	movq	0x50(%rsp), %rax
    19bd:      	testq	%rax, %rax
    19c0:      	jne	0x116a <perf_unwind_stop+0x116a>
    19c6:      	jmp	0x14df <perf_unwind_stop+0x14df>
    19cb:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    19d5:      	movq	%rax, 0x26(%rsp)
    19da:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    19e4:      	movq	%rax, 0x20(%rsp)
    19e9:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    19f3:      	movq	%rax, 0x18(%rsp)
    19f8:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1a02:      	movq	%rax, 0x10(%rsp)
    1a07:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1a11:      	movq	%rax, 0x8(%rsp)
    1a16:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1a20:      	movq	%rax, (%rsp)
    1a24:      	movq	%rsp, %rdi
    1a27:      	movl	$0x2e, %eax
    1a2c:      	movl	$0x6, %ecx
    1a31:      	movl	0x60(%rsp), %edx
    1a35:      	movl	$0x2e, %esi
    1a3a:      	xorl	%eax, %eax
    1a3c:      	callq	*%rcx
    1a3e:      	jmp	0xc51 <perf_unwind_stop+0xc51>
    1a43:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1a4d:      	movq	%rax, 0x26(%rsp)
    1a52:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1a5c:      	movq	%rax, 0x20(%rsp)
    1a61:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1a6b:      	movq	%rax, 0x18(%rsp)
    1a70:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1a7a:      	movq	%rax, 0x10(%rsp)
    1a7f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1a89:      	movq	%rax, 0x8(%rsp)
    1a8e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1a98:      	movq	%rax, (%rsp)
    1a9c:      	movq	%rsp, %rdi
    1a9f:      	movl	$0x2e, %eax
    1aa4:      	movl	$0x6, %ecx
    1aa9:      	movl	0x48(%rsp), %edx
    1aad:      	movl	$0x2e, %esi
    1ab2:      	xorl	%eax, %eax
    1ab4:      	callq	*%rcx
    1ab6:      	cmpl	$0x0, (%r12)
    1abb:      	je	0x5ab <perf_unwind_stop+0x5ab>
    1ac1:      	jmp	0x49e <perf_unwind_stop+0x49e>
    1ac6:      	movabsq	$0xa64656c62616e, %rax  # imm = 0xA64656C62616E
    1ad0:      	movq	%rax, 0x35(%rsp)
    1ad5:      	movabsq	$0x62616e6520736c65, %rax # imm = 0x62616E6520736C65
    1adf:      	movq	%rax, 0x30(%rsp)
    1ae4:      	movabsq	$0x62616c206d6f7473, %rax # imm = 0x62616C206D6F7473
    1aee:      	movq	%rax, 0x28(%rsp)
    1af3:      	movabsq	$0x7563206f47206874, %rax # imm = 0x7563206F47206874
    1afd:      	movq	%rax, 0x20(%rsp)
    1b02:      	movabsq	$0x697720737365636f, %rax # imm = 0x697720737365636F
    1b0c:      	movq	%rax, 0x18(%rsp)
    1b11:      	movabsq	$0x72702061206e6968, %rax # imm = 0x72702061206E6968
    1b1b:      	movq	%rax, 0x10(%rsp)
    1b20:      	movabsq	$0x7469772073692065, %rax # imm = 0x7469772073692065
    1b2a:      	movq	%rax, 0x8(%rsp)
    1b2f:      	movabsq	$0x63617274203a6c63, %rax # imm = 0x63617274203A6C63
    1b39:      	movq	%rax, (%rsp)
    1b3d:      	movq	%rsp, %rdi
    1b40:      	movl	$0x3d, %eax
    1b45:      	movl	$0x6, %ecx
    1b4a:      	movl	$0x3d, %esi
    1b4f:      	xorl	%eax, %eax
    1b51:      	callq	*%rcx
    1b53:      	jmp	0x117c <perf_unwind_stop+0x117c>
    1b58:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1b62:      	movq	%rax, 0x26(%rsp)
    1b67:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1b71:      	movq	%rax, 0x20(%rsp)
    1b76:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1b80:      	movq	%rax, 0x18(%rsp)
    1b85:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1b8f:      	movq	%rax, 0x10(%rsp)
    1b94:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1b9e:      	movq	%rax, 0x8(%rsp)
    1ba3:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1bad:      	movq	%rax, (%rsp)
    1bb1:      	movq	%rsp, %rdi
    1bb4:      	movl	$0x2e, %eax
    1bb9:      	movl	$0x6, %ecx
    1bbe:      	movl	0x60(%rsp), %edx
    1bc2:      	movl	$0x2e, %esi
    1bc7:      	xorl	%eax, %eax
    1bc9:      	callq	*%rcx
    1bcb:      	jmp	0x11ac <perf_unwind_stop+0x11ac>
    1bd0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1bda:      	movq	%rax, 0x26(%rsp)
    1bdf:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1be9:      	movq	%rax, 0x20(%rsp)
    1bee:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1bf8:      	movq	%rax, 0x18(%rsp)
    1bfd:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1c07:      	movq	%rax, 0x10(%rsp)
    1c0c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1c16:      	movq	%rax, 0x8(%rsp)
    1c1b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1c25:      	movq	%rax, (%rsp)
    1c29:      	movq	%rsp, %rdi
    1c2c:      	movl	$0x2e, %eax
    1c31:      	movl	$0x6, %ecx
    1c36:      	movl	0x60(%rsp), %edx
    1c3a:      	movl	$0x2e, %esi
    1c3f:      	xorl	%eax, %eax
    1c41:      	callq	*%rcx
    1c43:      	jmp	0x122c <perf_unwind_stop+0x122c>

Disassembly of section kprobe/unwind_stop:

0000000000000000 <kprobe_unwind_stop>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x98, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, (%rsp)
      1b:      	movq	(%rip), %rdi            # 0x22 <kprobe_unwind_stop+0x22>
      22:      	movq	%rsp, %rsi
      25:      	movl	$0x1, %eax
      2a:      	callq	*%rax
      2c:      	testq	%rax, %rax
      2f:      	je	0xde <kprobe_unwind_stop+0xde>
      35:      	movq	%rax, %r14
      38:      	movl	(%rax), %eax
      3a:      	movl	%eax, 0x8c(%rsp)
      41:      	movq	(%rip), %rdi            # 0x48 <kprobe_unwind_stop+0x48>
      48:      	leaq	0x8c(%rsp), %rsi
      50:      	movl	$0x1, %eax
      55:      	callq	*%rax
      57:      	testq	%rax, %rax
      5a:      	je	0x5ab <kprobe_unwind_stop+0x5ab>
      60:      	movq	%rax, %r15
      63:      	movq	(%rip), %r12            # 0x6a <kprobe_unwind_stop+0x6a>
      6a:      	cmpl	$0x0, (%r12)
      6f:      	jne	0x706 <kprobe_unwind_stop+0x706>
      75:      	movl	$0x23, %eax
      7a:      	callq	*%rax
      7c:      	movq	(%rip), %rcx            # 0x83 <kprobe_unwind_stop+0x83>
      83:      	addq	(%rcx), %rax
      86:      	leaq	0x58(%rsp), %rdi
      8b:      	movl	$0x8, %ecx
      90:      	movl	$0x71, %r8d
      96:      	movl	$0x8, %esi
      9b:      	movq	%rax, %rdx
      9e:      	callq	*%r8
      a1:      	movl	(%r12), %ecx
      a5:      	testq	%rax, %rax
      a8:      	je	0xe8 <kprobe_unwind_stop+0xe8>
      aa:      	testl	%ecx, %ecx
      ac:      	jne	0x1259 <kprobe_unwind_stop+0x1259>
      b2:      	movl	$0x4, 0x60(%rsp)
      ba:      	movq	(%rip), %rdi            # 0xc1 <kprobe_unwind_stop+0xc1>
      c1:      	leaq	0x60(%rsp), %rsi
      c6:      	movl	$0x1, %eax
      cb:      	callq	*%rax
      cd:      	testq	%rax, %rax
      d0:      	je	0x1c3 <kprobe_unwind_stop+0x1c3>
      d6:      	incq	(%rax)
      d9:      	jmp	0x1ce <kprobe_unwind_stop+0x1ce>
      de:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
      e3:      	jmp	0x1529 <kprobe_unwind_stop+0x1529>
      e8:      	testl	%ecx, %ecx
      ea:      	jne	0x13f0 <kprobe_unwind_stop+0x13f0>
      f0:      	movq	(%r15), %rax
      f3:      	addq	0x58(%rsp), %rax
      f8:      	leaq	0x50(%rsp), %rdi
      fd:      	movl	$0x8, %ecx
     102:      	movl	$0x70, %r8d
     108:      	movq	(%r15), %rdx
     10b:      	addq	0x58(%rsp), %rdx
     110:      	movl	$0x8, %esi
     115:      	callq	*%r8
     118:      	testq	%rax, %rax
     11b:      	je	0x2f7 <kprobe_unwind_stop+0x2f7>
     121:      	movl	$0x57, 0x60(%rsp)
     129:      	movq	(%rip), %rdi            # 0x130 <kprobe_unwind_stop+0x130>
     130:      	leaq	0x60(%rsp), %rsi
     135:      	movl	$0x1, %eax
     13a:      	callq	*%rax
     13c:      	testq	%rax, %rax
     13f:      	je	0x3b5 <kprobe_unwind_stop+0x3b5>
     145:      	incq	(%rax)
     148:      	cmpl	$0x0, (%r12)
     14d:      	je	0x5ab <kprobe_unwind_stop+0x5ab>
     153:      	movabsq	$0xa7265746e696f, %rax  # imm = 0xA7265746E696F
     15d:      	movq	%rax, 0x27(%rsp)
     162:      	movabsq	$0x6f70207265666675, %rax # imm = 0x6F70207265666675
     16c:      	movq	%rax, 0x20(%rsp)
     171:      	movabsq	$0x62206e6f6974616c, %rax # imm = 0x62206E6F6974616C
     17b:      	movq	%rax, 0x18(%rsp)
     180:      	movabsq	$0x6572726f63204d50, %rax # imm = 0x6572726F63204D50
     18a:      	movq	%rax, 0x10(%rsp)
     18f:      	movabsq	$0x412064616572206f, %rax # imm = 0x412064616572206F
     199:      	movq	%rax, 0x8(%rsp)
     19e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     1a8:      	movq	%rax, (%rsp)
     1ac:      	movq	%rsp, %rdi
     1af:      	movl	$0x2f, %eax
     1b4:      	movl	$0x6, %ecx
     1b9:      	movl	$0x2f, %esi
     1be:      	jmp	0x260 <kprobe_unwind_stop+0x260>
     1c3:      	cmpl	$0x0, (%r12)
     1c8:      	jne	0x153b <kprobe_unwind_stop+0x153b>
     1ce:      	movl	$0x56, 0x60(%rsp)
     1d6:      	movq	(%rip), %rdi            # 0x1dd <kprobe_unwind_stop+0x1dd>
     1dd:      	leaq	0x60(%rsp), %rsi
     1e2:      	movl	$0x1, %eax
     1e7:      	callq	*%rax
     1e9:      	testq	%rax, %rax
     1ec:      	je	0x269 <kprobe_unwind_stop+0x269>
     1ee:      	incq	(%rax)
     1f1:      	cmpl	$0x0, (%r12)
     1f6:      	je	0x5ab <kprobe_unwind_stop+0x5ab>
     1fc:      	movabsq	$0x697461726765746e, %rax # imm = 0x697461726765746E
     206:      	movq	%rax, 0x20(%rsp)
     20b:      	movabsq	$0x69204d504120726f, %rax # imm = 0x69204D504120726F
     215:      	movq	%rax, 0x18(%rsp)
     21a:      	movabsq	$0x6620657361622044, %rax # imm = 0x6620657361622044
     224:      	movq	%rax, 0x10(%rsp)
     229:      	movabsq	$0x535420746567206f, %rax # imm = 0x535420746567206F
     233:      	movq	%rax, 0x8(%rsp)
     238:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     242:      	movq	%rax, (%rsp)
     246:      	movl	$0xa6e6f, 0x28(%rsp)    # imm = 0xA6E6F
     24e:      	movq	%rsp, %rdi
     251:      	movl	$0x2c, %eax
     256:      	movl	$0x6, %ecx
     25b:      	movl	$0x2c, %esi
     260:      	xorl	%eax, %eax
     262:      	callq	*%rcx
     264:      	jmp	0x5ab <kprobe_unwind_stop+0x5ab>
     269:      	cmpl	$0x0, (%r12)
     26e:      	je	0x5ab <kprobe_unwind_stop+0x5ab>
     274:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     27e:      	movq	%rax, 0x26(%rsp)
     283:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     28d:      	movq	%rax, 0x20(%rsp)
     292:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     29c:      	movq	%rax, 0x18(%rsp)
     2a1:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     2ab:      	movq	%rax, 0x10(%rsp)
     2b0:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     2ba:      	movq	%rax, 0x8(%rsp)
     2bf:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     2c9:      	movq	%rax, (%rsp)
     2cd:      	movq	%rsp, %rdi
     2d0:      	movl	$0x2e, %eax
     2d5:      	movl	$0x6, %ecx
     2da:      	movl	0x60(%rsp), %edx
     2de:      	movl	$0x2e, %esi
     2e3:      	xorl	%eax, %eax
     2e5:      	callq	*%rcx
     2e7:      	cmpl	$0x0, (%r12)
     2ec:      	je	0x5ab <kprobe_unwind_stop+0x5ab>
     2f2:      	jmp	0x1fc <kprobe_unwind_stop+0x1fc>
     2f7:      	movq	0x50(%rsp), %rax
     2fc:      	leaq	0x60(%rsp), %rdi
     301:      	movl	$0x25, %ecx
     306:      	movl	$0x70, %r8d
     30c:      	movq	0x50(%rsp), %rdx
     311:      	movl	$0x25, %esi
     316:      	callq	*%r8
     319:      	testq	%rax, %rax
     31c:      	je	0x443 <kprobe_unwind_stop+0x443>
     322:      	movl	$0x58, 0x48(%rsp)
     32a:      	movq	(%rip), %rdi            # 0x331 <kprobe_unwind_stop+0x331>
     331:      	leaq	0x48(%rsp), %rsi
     336:      	movl	$0x1, %eax
     33b:      	callq	*%rax
     33d:      	testq	%rax, %rax
     340:      	je	0x516 <kprobe_unwind_stop+0x516>
     346:      	incq	(%rax)
     349:      	cmpl	$0x0, (%r12)
     34e:      	je	0x5ab <kprobe_unwind_stop+0x5ab>
     354:      	movabsq	$0xa726566667562, %rax  # imm = 0xA726566667562
     35e:      	movq	%rax, 0x1f(%rsp)
     363:      	movabsq	$0x62206e6f6974616c, %rax # imm = 0x62206E6F6974616C
     36d:      	movq	%rax, 0x18(%rsp)
     372:      	movabsq	$0x6572726f63204d50, %rax # imm = 0x6572726F63204D50
     37c:      	movq	%rax, 0x10(%rsp)
     381:      	movabsq	$0x412064616572206f, %rax # imm = 0x412064616572206F
     38b:      	movq	%rax, 0x8(%rsp)
     390:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     39a:      	movq	%rax, (%rsp)
     39e:      	movq	%rsp, %rdi
     3a1:      	movl	$0x27, %eax
     3a6:      	movl	$0x6, %ecx
     3ab:      	movl	$0x27, %esi
     3b0:      	jmp	0x260 <kprobe_unwind_stop+0x260>
     3b5:      	cmpl	$0x0, (%r12)
     3ba:      	je	0x5ab <kprobe_unwind_stop+0x5ab>
     3c0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     3ca:      	movq	%rax, 0x26(%rsp)
     3cf:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     3d9:      	movq	%rax, 0x20(%rsp)
     3de:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     3e8:      	movq	%rax, 0x18(%rsp)
     3ed:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     3f7:      	movq	%rax, 0x10(%rsp)
     3fc:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     406:      	movq	%rax, 0x8(%rsp)
     40b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     415:      	movq	%rax, (%rsp)
     419:      	movq	%rsp, %rdi
     41c:      	movl	$0x2e, %eax
     421:      	movl	$0x6, %ecx
     426:      	movl	0x60(%rsp), %edx
     42a:      	movl	$0x2e, %esi
     42f:      	xorl	%eax, %eax
     431:      	callq	*%rcx
     433:      	cmpl	$0x0, (%r12)
     438:      	je	0x5ab <kprobe_unwind_stop+0x5ab>
     43e:      	jmp	0x153 <kprobe_unwind_stop+0x153>
     443:      	cmpb	$0x0, 0x63(%rsp)
     448:      	je	0x46c <kprobe_unwind_stop+0x46c>
     44a:      	cmpb	$0x0, 0x62(%rsp)
     44f:      	je	0x46c <kprobe_unwind_stop+0x46c>
     451:      	movq	0x6d(%rsp), %rax
     456:      	movq	%rax, 0x30(%r14)
     45a:      	movq	0x65(%rsp), %rax
     45f:      	movq	%rax, 0x28(%r14)
     463:      	movq	0x7d(%rsp), %rax
     468:      	movq	%rax, 0x20(%r14)
     46c:      	movl	$0x59, 0x48(%rsp)
     474:      	movq	(%rip), %rdi            # 0x47b <kprobe_unwind_stop+0x47b>
     47b:      	leaq	0x48(%rsp), %rsi
     480:      	movl	$0x1, %eax
     485:      	callq	*%rax
     487:      	testq	%rax, %rax
     48a:      	je	0x5a0 <kprobe_unwind_stop+0x5a0>
     490:      	incq	(%rax)
     493:      	cmpl	$0x0, (%r12)
     498:      	je	0x5ab <kprobe_unwind_stop+0x5ab>
     49e:      	movabsq	$0x30257830203a7367, %rax # imm = 0x30257830203A7367
     4a8:      	movq	%rax, 0x20(%rsp)
     4ad:      	movabsq	$0x616c66202c586c6c, %rax # imm = 0x616C66202C586C6C
     4b7:      	movq	%rax, 0x18(%rsp)
     4bc:      	movabsq	$0x36313025203a4449, %rax # imm = 0x36313025203A4449
     4c6:      	movq	%rax, 0x10(%rsp)
     4cb:      	movabsq	$0x206e6f6974636173, %rax # imm = 0x206E6F6974636173
     4d5:      	movq	%rax, 0x8(%rsp)
     4da:      	movabsq	$0x6e617274204d5041, %rax # imm = 0x6E617274204D5041
     4e4:      	movq	%rax, (%rsp)
     4e8:      	movl	$0xa5832, 0x28(%rsp)    # imm = 0xA5832
     4f0:      	movq	%rsp, %rdi
     4f3:      	movl	$0x2c, %eax
     4f8:      	movl	$0x6, %r8d
     4fe:      	movq	0x20(%r14), %rdx
     502:      	movzbl	0x64(%rsp), %ecx
     507:      	movl	$0x2c, %esi
     50c:      	xorl	%eax, %eax
     50e:      	callq	*%r8
     511:      	jmp	0x5ab <kprobe_unwind_stop+0x5ab>
     516:      	cmpl	$0x0, (%r12)
     51b:      	je	0x5ab <kprobe_unwind_stop+0x5ab>
     521:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     52b:      	movq	%rax, 0x26(%rsp)
     530:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     53a:      	movq	%rax, 0x20(%rsp)
     53f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     549:      	movq	%rax, 0x18(%rsp)
     54e:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     558:      	movq	%rax, 0x10(%rsp)
     55d:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     567:      	movq	%rax, 0x8(%rsp)
     56c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     576:      	movq	%rax, (%rsp)
     57a:      	movq	%rsp, %rdi
     57d:      	movl	$0x2e, %eax
     582:      	movl	$0x6, %ecx
     587:      	movl	0x48(%rsp), %edx
     58b:      	movl	$0x2e, %esi
     590:      	xorl	%eax, %eax
     592:      	callq	*%rcx
     594:      	cmpl	$0x0, (%r12)
     599:      	je	0x5ab <kprobe_unwind_stop+0x5ab>
     59b:      	jmp	0x354 <kprobe_unwind_stop+0x354>
     5a0:      	cmpl	$0x0, (%r12)
     5a5:      	jne	0x1a43 <kprobe_unwind_stop+0x1a43>
     5ab:      	cmpl	$0x0, 0x2c0(%r14)
     5b3:      	jne	0x61e <kprobe_unwind_stop+0x61e>
     5b5:      	cmpl	$0x0, 0x2bc(%r14)
     5bd:      	jns	0x61e <kprobe_unwind_stop+0x61e>
     5bf:      	movq	(%rip), %r15            # 0x5c6 <kprobe_unwind_stop+0x5c6>
     5c6:      	cmpl	$0x0, (%r15)
     5ca:      	jne	0x1622 <kprobe_unwind_stop+0x1622>
     5d0:      	movl	$0x28, 0x60(%rsp)
     5d8:      	movq	(%rip), %rdi            # 0x5df <kprobe_unwind_stop+0x5df>
     5df:      	leaq	0x60(%rsp), %rsi
     5e4:      	movl	$0x1, %eax
     5e9:      	callq	*%rax
     5eb:      	testq	%rax, %rax
     5ee:      	je	0x60a <kprobe_unwind_stop+0x60a>
     5f0:      	incq	(%rax)
     5f3:      	cmpl	$0x0, 0xf2c(%r14)
     5fb:      	jne	0x61e <kprobe_unwind_stop+0x61e>
     5fd:      	movl	$0x3, 0xf2c(%r14)
     608:      	jmp	0x61e <kprobe_unwind_stop+0x61e>
     60a:      	cmpl	$0x0, (%r15)
     60e:      	jne	0x17f0 <kprobe_unwind_stop+0x17f0>
     614:      	cmpl	$0x0, 0xf2c(%r14)
     61c:      	je	0x5fd <kprobe_unwind_stop+0x5fd>
     61e:      	movl	0xf2c(%r14), %eax
     625:      	testl	%eax, %eax
     627:      	je	0x864 <kprobe_unwind_stop+0x864>
     62d:      	movq	(%rip), %r15            # 0x634 <kprobe_unwind_stop+0x634>
     634:      	cmpl	$0x0, (%r15)
     638:      	jne	0x789 <kprobe_unwind_stop+0x789>
     63e:      	movl	0x2c0(%r14), %ecx
     645:      	cmpq	$0x80, %rcx
     64c:      	jb	0x81f <kprobe_unwind_stop+0x81f>
     652:      	cmpl	$0x0, (%r15)
     656:      	jne	0x1305 <kprobe_unwind_stop+0x1305>
     65c:      	movl	$0x2, 0x60(%rsp)
     664:      	movq	(%rip), %rdi            # 0x66b <kprobe_unwind_stop+0x66b>
     66b:      	leaq	0x60(%rsp), %rsi
     670:      	movl	$0x1, %eax
     675:      	callq	*%rax
     677:      	testq	%rax, %rax
     67a:      	je	0x684 <kprobe_unwind_stop+0x684>
     67c:      	incq	(%rax)
     67f:      	jmp	0x864 <kprobe_unwind_stop+0x864>
     684:      	cmpl	$0x0, (%r15)
     688:      	je	0x864 <kprobe_unwind_stop+0x864>
     68e:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     698:      	movq	%rax, 0x26(%rsp)
     69d:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     6a7:      	movq	%rax, 0x20(%rsp)
     6ac:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     6b6:      	movq	%rax, 0x18(%rsp)
     6bb:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     6c5:      	movq	%rax, 0x10(%rsp)
     6ca:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     6d4:      	movq	%rax, 0x8(%rsp)
     6d9:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     6e3:      	movq	%rax, (%rsp)
     6e7:      	movq	%rsp, %rdi
     6ea:      	movl	$0x2e, %eax
     6ef:      	movl	$0x6, %ecx
     6f4:      	movl	0x60(%rsp), %edx
     6f8:      	movl	$0x2e, %esi
     6fd:      	xorl	%eax, %eax
     6ff:      	callq	*%rcx
     701:      	jmp	0x864 <kprobe_unwind_stop+0x864>
     706:      	movabsq	$0xa64656c62616e, %rax  # imm = 0xA64656C62616E
     710:      	movq	%rax, 0x30(%rsp)
     715:      	movabsq	$0x65206e6f69746172, %rax # imm = 0x65206E6F69746172
     71f:      	movq	%rax, 0x28(%rsp)
     724:      	movabsq	$0x6765746e69204d50, %rax # imm = 0x6765746E69204D50
     72e:      	movq	%rax, 0x20(%rsp)
     733:      	movabsq	$0x4120687469772073, %rax # imm = 0x4120687469772073
     73d:      	movq	%rax, 0x18(%rsp)
     742:      	movabsq	$0x7365636f72702061, %rax # imm = 0x7365636F72702061
     74c:      	movq	%rax, 0x10(%rsp)
     751:      	movabsq	$0x206e696874697720, %rax # imm = 0x206E696874697720
     75b:      	movq	%rax, 0x8(%rsp)
     760:      	movabsq	$0x7369206563617254, %rax # imm = 0x7369206563617254
     76a:      	movq	%rax, (%rsp)
     76e:      	movq	%rsp, %rdi
     771:      	movl	$0x38, %eax
     776:      	movl	$0x6, %ecx
     77b:      	movl	$0x38, %esi
     780:      	xorl	%eax, %eax
     782:      	callq	*%rcx
     784:      	jmp	0x75 <kprobe_unwind_stop+0x75>
     789:      	movabsq	$0xa64252065646f63, %rax # imm = 0xA64252065646F63
     793:      	movq	%rax, 0x28(%rsp)
     798:      	movabsq	$0x20726f727265206f, %rax # imm = 0x20726F727265206F
     7a2:      	movq	%rax, 0x20(%rsp)
     7a7:      	movabsq	$0x742065756420676e, %rax # imm = 0x742065756420676E
     7b1:      	movq	%rax, 0x18(%rsp)
     7b6:      	movabsq	$0x69646e69776e7520, %rax # imm = 0x69646E69776E7520
     7c0:      	movq	%rax, 0x10(%rsp)
     7c5:      	movabsq	$0x7265687472756620, %rax # imm = 0x7265687472756620
     7cf:      	movq	%rax, 0x8(%rsp)
     7d4:      	movabsq	$0x676e6974726f6241, %rax # imm = 0x676E6974726F6241
     7de:      	movq	%rax, (%rsp)
     7e2:      	movb	$0x0, 0x30(%rsp)
     7e7:      	movq	%rsp, %rdi
     7ea:      	movl	$0x31, %eax
     7ef:      	movl	$0x6, %ecx
     7f4:      	movl	0xf2c(%r14), %edx
     7fb:      	movl	$0x31, %esi
     800:      	xorl	%eax, %eax
     802:      	callq	*%rcx
     804:      	movl	0xf2c(%r14), %eax
     80b:      	movl	0x2c0(%r14), %ecx
     812:      	cmpq	$0x80, %rcx
     819:      	jae	0x652 <kprobe_unwind_stop+0x652>
     81f:      	leal	0x1(%rcx), %edx
     822:      	movl	%edx, 0x2c0(%r14)
     829:      	movl	%eax, %eax
     82b:      	leaq	(%rcx,%rcx,2), %rcx
     82f:      	movq	$0x0, 0x2d0(%r14,%rcx,8)
     83b:      	movq	%rax, 0x2d8(%r14,%rcx,8)
     843:      	movb	$-0x1, 0x2e0(%r14,%rcx,8)
     84c:      	movl	$0x0, 0x2e1(%r14,%rcx,8)
     858:      	movl	$0x0, 0x2e4(%r14,%rcx,8)
     864:      	movl	0xf28(%r14), %eax
     86b:      	cmpl	$-0x1, %eax
     86e:      	je	0xd03 <kprobe_unwind_stop+0xd03>
     874:      	cmpl	$0xc, %eax
     877:      	jne	0xcc1 <kprobe_unwind_stop+0xcc1>
     87d:      	movl	(%r14), %eax
     880:      	movl	0x4(%r14), %ecx
     884:      	movzbl	0x1385(%r14), %ebp
     88c:      	movl	%eax, 0x8c(%rsp)
     893:      	movl	%eax, 0x48(%rsp)
     897:      	shlq	$0x20, %rax
     89b:      	orq	%rax, %rcx
     89e:      	movq	%rcx, 0x58(%rsp)
     8a3:      	movq	(%rip), %rdi            # 0x8aa <kprobe_unwind_stop+0x8aa>
     8aa:      	leaq	0x48(%rsp), %rsi
     8af:      	movl	$0x1, %eax
     8b4:      	callq	*%rax
     8b6:      	movq	%rax, %r15
     8b9:      	movl	$0x5, %eax
     8be:      	callq	*%rax
     8c0:      	cmpb	$0x2, %bpl
     8c4:      	sete	%r13b
     8c8:      	testb	%bpl, %bpl
     8cb:      	je	0xa99 <kprobe_unwind_stop+0xa99>
     8d1:      	shlb	$0x4, %r13b
     8d5:      	testq	%r15, %r15
     8d8:      	je	0x99f <kprobe_unwind_stop+0x99f>
     8de:      	movq	(%r15), %rcx
     8e1:      	movq	%rcx, %rsi
     8e4:      	andq	$-0x20, %rsi
     8e8:      	movq	%rax, %rdx
     8eb:      	subq	%rsi, %rdx
     8ee:      	movl	%ecx, %esi
     8f0:      	andb	$0xf, %sil
     8f4:      	movl	$0x5f5e100, %edi        # imm = 0x5F5E100
     8f9:      	shlxq	%rsi, %rdi, %rsi
     8fe:      	cmpq	%rsi, %rdx
     901:      	jae	0x969 <kprobe_unwind_stop+0x969>
     903:      	movq	(%rip), %rax            # 0x90a <kprobe_unwind_stop+0x90a>
     90a:      	cmpl	$0x0, (%rax)
     90d:      	je	0xcc1 <kprobe_unwind_stop+0xcc1>
     913:      	movabsq	$0xa74736166206f, %rax  # imm = 0xA74736166206F
     91d:      	movq	%rax, 0x18(%rsp)
     922:      	movabsq	$0x6f74203a64657469, %rax # imm = 0x6F74203A64657469
     92c:      	movq	%rax, 0x10(%rsp)
     931:      	movabsq	$0x6d696c20746e6576, %rax # imm = 0x6D696C20746E6576
     93b:      	movq	%rax, 0x8(%rsp)
     940:      	movabsq	$0x6520642520444950, %rax # imm = 0x6520642520444950
     94a:      	movq	%rax, (%rsp)
     94e:      	movq	%rsp, %rdi
     951:      	movl	$0x20, %eax
     956:      	movl	$0x6, %ecx
     95b:      	movl	0x48(%rsp), %edx
     95f:      	movl	$0x20, %esi
     964:      	jmp	0x114b <kprobe_unwind_stop+0x114b>
     969:      	movl	%ecx, %edi
     96b:      	andb	$0x10, %dil
     96f:      	orb	%dil, %r13b
     972:      	movl	$0xffffffff, %edi       # imm = 0xFFFFFFFF
     977:      	addq	%rdi, %rsi
     97a:      	addq	$0x2a05f201, %rsi       # imm = 0x2A05F201
     981:      	cmpq	%rsi, %rdx
     984:      	jae	0x99f <kprobe_unwind_stop+0x99f>
     986:      	andl	$0xf, %ecx
     989:      	xorl	%edx, %edx
     98b:      	testb	%r13b, %r13b
     98e:      	sete	%dl
     991:      	leal	0x4(,%rdx,4), %edx
     998:      	cmpl	%edx, %ecx
     99a:      	adcb	$0x0, %cl
     99d:      	jmp	0x9a1 <kprobe_unwind_stop+0x9a1>
     99f:      	xorl	%ecx, %ecx
     9a1:      	movq	(%rip), %r12            # 0x9a8 <kprobe_unwind_stop+0x9a8>
     9a8:      	cmpl	$0x0, (%r12)
     9ad:      	movzbl	%cl, %r15d
     9b1:      	jne	0x15b3 <kprobe_unwind_stop+0x15b3>
     9b7:      	andq	$-0x20, %rax
     9bb:      	movzbl	%r13b, %ecx
     9bf:      	orq	%rax, %rcx
     9c2:      	orq	%rcx, %r15
     9c5:      	movq	%r15, 0x60(%rsp)
     9ca:      	movq	(%rip), %rdi            # 0x9d1 <kprobe_unwind_stop+0x9d1>
     9d1:      	xorl	%eax, %eax
     9d3:      	leaq	0x48(%rsp), %rsi
     9d8:      	leaq	0x60(%rsp), %rdx
     9dd:      	movl	$0x2, %r8d
     9e3:      	xorl	%ecx, %ecx
     9e5:      	callq	*%r8
     9e8:      	testl	%eax, %eax
     9ea:      	je	0xa99 <kprobe_unwind_stop+0xa99>
     9f0:      	cmpl	$0x0, (%r12)
     9f5:      	jne	0x1722 <kprobe_unwind_stop+0x1722>
     9fb:      	movl	$0x3d, 0x50(%rsp)
     a03:      	movq	(%rip), %rdi            # 0xa0a <kprobe_unwind_stop+0xa0a>
     a0a:      	leaq	0x50(%rsp), %rsi
     a0f:      	movl	$0x1, %eax
     a14:      	callq	*%rax
     a16:      	testq	%rax, %rax
     a19:      	jne	0xcbe <kprobe_unwind_stop+0xcbe>
     a1f:      	cmpl	$0x0, (%r12)
     a24:      	je	0xcc1 <kprobe_unwind_stop+0xcc1>
     a2a:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     a34:      	movq	%rax, 0x26(%rsp)
     a39:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     a43:      	movq	%rax, 0x20(%rsp)
     a48:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     a52:      	movq	%rax, 0x18(%rsp)
     a57:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     a61:      	movq	%rax, 0x10(%rsp)
     a66:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     a70:      	movq	%rax, 0x8(%rsp)
     a75:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     a7f:      	movq	%rax, (%rsp)
     a83:      	movq	%rsp, %rdi
     a86:      	movl	$0x2e, %eax
     a8b:      	movl	$0x6, %ecx
     a90:      	movl	0x50(%rsp), %edx
     a94:      	jmp	0x1146 <kprobe_unwind_stop+0x1146>
     a99:      	movb	$0x1, 0x4f(%rsp)
     a9e:      	movq	(%rip), %rdi            # 0xaa5 <kprobe_unwind_stop+0xaa5>
     aa5:      	xorl	%eax, %eax
     aa7:      	leaq	0x58(%rsp), %rsi
     aac:      	leaq	0x4f(%rsp), %rdx
     ab1:      	movl	$0x2, %r8d
     ab7:      	xorl	%ecx, %ecx
     ab9:      	callq	*%r8
     abc:      	testl	%eax, %eax
     abe:      	je	0xb6e <kprobe_unwind_stop+0xb6e>
     ac4:      	movq	(%rip), %r15            # 0xacb <kprobe_unwind_stop+0xacb>
     acb:      	cmpl	$0x0, (%r15)
     acf:      	jne	0x168f <kprobe_unwind_stop+0x168f>
     ad5:      	movl	$0x3e, 0x60(%rsp)
     add:      	movq	(%rip), %rdi            # 0xae4 <kprobe_unwind_stop+0xae4>
     ae4:      	leaq	0x60(%rsp), %rsi
     ae9:      	movl	$0x1, %eax
     aee:      	callq	*%rax
     af0:      	testq	%rax, %rax
     af3:      	jne	0xcbe <kprobe_unwind_stop+0xcbe>
     af9:      	cmpl	$0x0, (%r15)
     afd:      	je	0xcc1 <kprobe_unwind_stop+0xcc1>
     b03:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     b0d:      	movq	%rax, 0x26(%rsp)
     b12:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     b1c:      	movq	%rax, 0x20(%rsp)
     b21:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     b2b:      	movq	%rax, 0x18(%rsp)
     b30:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     b3a:      	movq	%rax, 0x10(%rsp)
     b3f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     b49:      	movq	%rax, 0x8(%rsp)
     b4e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     b58:      	movq	%rax, (%rsp)
     b5c:      	movq	%rsp, %rdi
     b5f:      	movl	$0x2e, %eax
     b64:      	movl	$0x6, %ecx
     b69:      	jmp	0x1142 <kprobe_unwind_stop+0x1142>
     b6e:      	testb	%bpl, %bpl
     b71:      	jne	0xb89 <kprobe_unwind_stop+0xb89>
     b73:      	movq	(%rip), %rdi            # 0xb7a <kprobe_unwind_stop+0xb7a>
     b7a:      	leaq	0x8c(%rsp), %rsi
     b82:      	movl	$0x3, %eax
     b87:      	callq	*%rax
     b89:      	movl	$0x1, 0x50(%rsp)
     b91:      	movb	$0x1, 0x48(%rsp)
     b96:      	movq	(%rip), %rdi            # 0xb9d <kprobe_unwind_stop+0xb9d>
     b9d:      	leaq	0x50(%rsp), %rsi
     ba2:      	leaq	0x48(%rsp), %rdx
     ba7:      	movl	$0x1, %eax
     bac:      	movl	$0x2, %r8d
     bb2:      	movl	$0x1, %ecx
     bb7:      	callq	*%r8
     bba:      	testl	%eax, %eax
     bbc:      	js	0xbe3 <kprobe_unwind_stop+0xbe3>
     bbe:      	movl	$0x42, 0x60(%rsp)
     bc6:      	movq	(%rip), %rdi            # 0xbcd <kprobe_unwind_stop+0xbcd>
     bcd:      	leaq	0x60(%rsp), %rsi
     bd2:      	movl	$0x1, %eax
     bd7:      	callq	*%rax
     bd9:      	testq	%rax, %rax
     bdc:      	je	0xc41 <kprobe_unwind_stop+0xc41>
     bde:      	incq	(%rax)
     be1:      	jmp	0xc51 <kprobe_unwind_stop+0xc51>
     be3:      	movq	(%rip), %rax            # 0xbea <kprobe_unwind_stop+0xbea>
     bea:      	cmpl	$0x0, (%rax)
     bed:      	je	0xc9a <kprobe_unwind_stop+0xc9a>
     bf3:      	movabsq	$0xa64657469626968, %rax # imm = 0xA64657469626968
     bfd:      	movq	%rax, 0x10(%rsp)
     c02:      	movabsq	$0x6e69206425206570, %rax # imm = 0x6E69206425206570
     c0c:      	movq	%rax, 0x8(%rsp)
     c11:      	movabsq	$0x797420746e657645, %rax # imm = 0x797420746E657645
     c1b:      	movq	%rax, (%rsp)
     c1f:      	movb	$0x0, 0x18(%rsp)
     c24:      	movq	%rsp, %rdi
     c27:      	movl	$0x19, %eax
     c2c:      	movl	$0x6, %ecx
     c31:      	movl	$0x19, %esi
     c36:      	movl	$0x1, %edx
     c3b:      	xorl	%eax, %eax
     c3d:      	callq	*%rcx
     c3f:      	jmp	0xc9a <kprobe_unwind_stop+0xc9a>
     c41:      	movq	(%rip), %rax            # 0xc48 <kprobe_unwind_stop+0xc48>
     c48:      	cmpl	$0x0, (%rax)
     c4b:      	jne	0x19cb <kprobe_unwind_stop+0x19cb>
     c51:      	movl	$0x1, 0x60(%rsp)
     c59:      	movq	(%rip), %rsi            # 0xc60 <kprobe_unwind_stop+0xc60>
     c60:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     c65:      	leaq	0x60(%rsp), %rcx
     c6a:      	movl	$0x4, %edx
     c6f:      	movl	$0x19, %r9d
     c75:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     c7a:      	movq	%rbx, %rdi
     c7d:      	movl	$0x4, %r8d
     c83:      	callq	*%r9
     c86:      	testl	%eax, %eax
     c88:      	jns	0xc9a <kprobe_unwind_stop+0xc9a>
     c8a:      	movq	(%rip), %rcx            # 0xc91 <kprobe_unwind_stop+0xc91>
     c91:      	cmpl	$0x0, (%rcx)
     c94:      	jne	0x18e5 <kprobe_unwind_stop+0x18e5>
     c9a:      	movl	$0x41, 0x60(%rsp)
     ca2:      	movq	(%rip), %rdi            # 0xca9 <kprobe_unwind_stop+0xca9>
     ca9:      	leaq	0x60(%rsp), %rsi
     cae:      	movl	$0x1, %eax
     cb3:      	callq	*%rax
     cb5:      	testq	%rax, %rax
     cb8:      	je	0x10cc <kprobe_unwind_stop+0x10cc>
     cbe:      	incq	(%rax)
     cc1:      	movl	0xf28(%r14), %eax
     cc8:      	movl	%eax, 0x60(%rsp)
     ccc:      	movq	(%rip), %rdi            # 0xcd3 <kprobe_unwind_stop+0xcd3>
     cd3:      	leaq	0x60(%rsp), %rsi
     cd8:      	movl	$0x1, %eax
     cdd:      	callq	*%rax
     cdf:      	testq	%rax, %rax
     ce2:      	je	0xcf3 <kprobe_unwind_stop+0xcf3>
     ce4:      	incq	(%rax)
     ce7:      	cmpl	$0x1, 0x2c0(%r14)
     cef:      	je	0xd0d <kprobe_unwind_stop+0xd0d>
     cf1:      	jmp	0xd1b <kprobe_unwind_stop+0xd1b>
     cf3:      	movq	(%rip), %rax            # 0xcfa <kprobe_unwind_stop+0xcfa>
     cfa:      	cmpl	$0x0, (%rax)
     cfd:      	jne	0x136a <kprobe_unwind_stop+0x136a>
     d03:      	cmpl	$0x1, 0x2c0(%r14)
     d0b:      	jne	0xd1b <kprobe_unwind_stop+0xd1b>
     d0d:      	cmpl	$0x0, 0x2bc(%r14)
     d15:      	js	0xf91 <kprobe_unwind_stop+0xf91>
     d1b:      	movl	(%r14), %eax
     d1e:      	movl	%eax, 0x48(%rsp)
     d22:      	movq	(%rip), %rdi            # 0xd29 <kprobe_unwind_stop+0xd29>
     d29:      	leaq	0x48(%rsp), %rsi
     d2e:      	movl	$0x1, %eax
     d33:      	callq	*%rax
     d35:      	testq	%rax, %rax
     d38:      	je	0xe41 <kprobe_unwind_stop+0xe41>
     d3e:      	movq	%rax, %r15
     d41:      	movq	$0x0, 0x60(%rsp)
     d4a:      	movq	$0x0, 0x58(%rsp)
     d53:      	movl	$0x23, %eax
     d58:      	callq	*%rax
     d5a:      	movq	(%rip), %rcx            # 0xd61 <kprobe_unwind_stop+0xd61>
     d61:      	addq	(%rcx), %rax
     d64:      	leaq	0x58(%rsp), %rdi
     d69:      	movl	$0x8, %ecx
     d6e:      	movl	$0x71, %r8d
     d74:      	movl	$0x8, %esi
     d79:      	movq	%rax, %rdx
     d7c:      	callq	*%r8
     d7f:      	movq	(%rip), %r12            # 0xd86 <kprobe_unwind_stop+0xd86>
     d86:      	movl	(%r12), %ecx
     d8a:      	testq	%rax, %rax
     d8d:      	je	0xed0 <kprobe_unwind_stop+0xed0>
     d93:      	testl	%ecx, %ecx
     d95:      	jne	0x12af <kprobe_unwind_stop+0x12af>
     d9b:      	movl	$0x4, 0x50(%rsp)
     da3:      	movq	(%rip), %rdi            # 0xdaa <kprobe_unwind_stop+0xdaa>
     daa:      	leaq	0x50(%rsp), %rsi
     daf:      	movl	$0x1, %eax
     db4:      	callq	*%rax
     db6:      	testq	%rax, %rax
     db9:      	je	0xfb6 <kprobe_unwind_stop+0xfb6>
     dbf:      	incq	(%rax)
     dc2:      	cmpl	$0x0, (%r12)
     dc7:      	je	0x14df <kprobe_unwind_stop+0x14df>
     dcd:      	movabsq	$0xa7274705f6d20, %rax  # imm = 0xA7274705F6D20
     dd7:      	movq	%rax, 0x26(%rsp)
     ddc:      	movabsq	$0x6d20646165722074, %rax # imm = 0x6D20646165722074
     de6:      	movq	%rax, 0x20(%rsp)
     deb:      	movabsq	$0x276e6163203b6573, %rax # imm = 0x276E6163203B6573
     df5:      	movq	%rax, 0x18(%rsp)
     dfa:      	movabsq	$0x6162206473742074, %rax # imm = 0x6162206473742074
     e04:      	movq	%rax, 0x10(%rsp)
     e09:      	movabsq	$0x6567206f74206465, %rax # imm = 0x6567206F74206465
     e13:      	movq	%rax, 0x8(%rsp)
     e18:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
     e22:      	movq	%rax, (%rsp)
     e26:      	movq	%rsp, %rdi
     e29:      	movl	$0x2e, %eax
     e2e:      	movl	$0x6, %ecx
     e33:      	movl	$0x2e, %esi
     e38:      	xorl	%eax, %eax
     e3a:      	callq	*%rcx
     e3c:      	jmp	0x14df <kprobe_unwind_stop+0x14df>
     e41:      	movq	(%rip), %rax            # 0xe48 <kprobe_unwind_stop+0xe48>
     e48:      	cmpl	$0x0, (%rax)
     e4b:      	je	0x14df <kprobe_unwind_stop+0x14df>
     e51:      	movabsq	$0x7972616e6962206f, %rax # imm = 0x7972616E6962206F
     e5b:      	movq	%rax, 0x28(%rsp)
     e60:      	movabsq	$0x6720612073612064, %rax # imm = 0x6720612073612064
     e6a:      	movq	%rax, 0x20(%rsp)
     e6f:      	movabsq	$0x657a696e676f6365, %rax # imm = 0x657A696E676F6365
     e79:      	movq	%rax, 0x18(%rsp)
     e7e:      	movabsq	$0x7220746f6e206425, %rax # imm = 0x7220746F6E206425
     e88:      	movq	%rax, 0x10(%rsp)
     e8d:      	movabsq	$0x202c737465736666, %rax # imm = 0x202C737465736666
     e97:      	movq	%rax, 0x8(%rsp)
     e9c:      	movabsq	$0x6f206f6e203a6c63, %rax # imm = 0x6F206F6E203A6C63
     ea6:      	movq	%rax, (%rsp)
     eaa:      	movw	$0xa, 0x30(%rsp)
     eb1:      	movq	%rsp, %rdi
     eb4:      	movl	$0x32, %eax
     eb9:      	movl	$0x6, %ecx
     ebe:      	movl	0x48(%rsp), %edx
     ec2:      	movl	$0x32, %esi
     ec7:      	xorl	%eax, %eax
     ec9:      	callq	*%rcx
     ecb:      	jmp	0x14df <kprobe_unwind_stop+0x14df>
     ed0:      	testl	%ecx, %ecx
     ed2:      	jne	0x1455 <kprobe_unwind_stop+0x1455>
     ed8:      	movslq	0x18(%r15), %rax
     edc:      	testq	%rax, %rax
     edf:      	je	0x14d4 <kprobe_unwind_stop+0x14d4>
     ee5:      	addq	0x58(%rsp), %rax
     eea:      	leaq	0x60(%rsp), %rdi
     eef:      	movl	$0x8, %ecx
     ef4:      	movl	$0x70, %r8d
     efa:      	movslq	0x18(%r15), %rdx
     efe:      	addq	0x58(%rsp), %rdx
     f03:      	movl	$0x8, %esi
     f08:      	callq	*%r8
     f0b:      	movl	(%r12), %ecx
     f0f:      	testq	%rax, %rax
     f12:      	je	0x1044 <kprobe_unwind_stop+0x1044>
     f18:      	testl	%ecx, %ecx
     f1a:      	je	0x14df <kprobe_unwind_stop+0x14df>
     f20:      	movabsq	$0x29786c2528657361, %rax # imm = 0x29786C2528657361
     f2a:      	movq	%rax, 0x20(%rsp)
     f2f:      	movabsq	$0x625f736c74202c72, %rax # imm = 0x625F736C74202C72
     f39:      	movq	%rax, 0x18(%rsp)
     f3e:      	movabsq	$0x6464615f67206461, %rax # imm = 0x6464615F67206461
     f48:      	movq	%rax, 0x10(%rsp)
     f4d:      	movabsq	$0x6572206f74206465, %rax # imm = 0x6572206F74206465
     f57:      	movq	%rax, 0x8(%rsp)
     f5c:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
     f66:      	movq	%rax, (%rsp)
     f6a:      	movw	$0xa, 0x28(%rsp)
     f71:      	movq	%rsp, %rdi
     f74:      	movl	$0x2a, %eax
     f79:      	movl	$0x6, %ecx
     f7e:      	movq	0x58(%rsp), %rdx
     f83:      	movl	$0x2a, %esi
     f88:      	xorl	%eax, %eax
     f8a:      	callq	*%rcx
     f8c:      	jmp	0x14df <kprobe_unwind_stop+0x14df>
     f91:      	cmpl	$0x0, 0xf2c(%r14)
     f99:      	je	0xd1b <kprobe_unwind_stop+0xd1b>
     f9f:      	xorl	%eax, %eax
     fa1:      	movq	(%rip), %rcx            # 0xfa8 <kprobe_unwind_stop+0xfa8>
     fa8:      	cmpb	$0x0, (%rcx)
     fab:      	jne	0x1529 <kprobe_unwind_stop+0x1529>
     fb1:      	jmp	0xd1b <kprobe_unwind_stop+0xd1b>
     fb6:      	cmpl	$0x0, (%r12)
     fbb:      	je	0x14df <kprobe_unwind_stop+0x14df>
     fc1:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     fcb:      	movq	%rax, 0x26(%rsp)
     fd0:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     fda:      	movq	%rax, 0x20(%rsp)
     fdf:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     fe9:      	movq	%rax, 0x18(%rsp)
     fee:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     ff8:      	movq	%rax, 0x10(%rsp)
     ffd:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1007:      	movq	%rax, 0x8(%rsp)
    100c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1016:      	movq	%rax, (%rsp)
    101a:      	movq	%rsp, %rdi
    101d:      	movl	$0x2e, %eax
    1022:      	movl	$0x6, %ecx
    1027:      	movl	0x50(%rsp), %edx
    102b:      	movl	$0x2e, %esi
    1030:      	xorl	%eax, %eax
    1032:      	callq	*%rcx
    1034:      	cmpl	$0x0, (%r12)
    1039:      	je	0x14df <kprobe_unwind_stop+0x14df>
    103f:      	jmp	0xdcd <kprobe_unwind_stop+0xdcd>
    1044:      	testl	%ecx, %ecx
    1046:      	jne	0x1876 <kprobe_unwind_stop+0x1876>
    104c:      	movl	(%r15), %eax
    104f:      	addq	0x60(%rsp), %rax
    1054:      	leaq	0x50(%rsp), %rdi
    1059:      	movl	$0x8, %ecx
    105e:      	movl	$0x70, %r8d
    1064:      	movl	(%r15), %edx
    1067:      	addq	0x60(%rsp), %rdx
    106c:      	movl	$0x8, %esi
    1071:      	callq	*%r8
    1074:      	movl	(%r12), %ecx
    1078:      	testq	%rax, %rax
    107b:      	je	0x1154 <kprobe_unwind_stop+0x1154>
    1081:      	testl	%ecx, %ecx
    1083:      	je	0x14df <kprobe_unwind_stop+0x14df>
    1089:      	movabsq	$0xa726464615f72, %rax  # imm = 0xA726464615F72
    1093:      	movq	%rax, 0xf(%rsp)
    1098:      	movabsq	$0x7274705f6d206465, %rax # imm = 0x7274705F6D206465
    10a2:      	movq	%rax, 0x8(%rsp)
    10a7:      	movabsq	$0x6c696166203a6c63, %rax # imm = 0x6C696166203A6C63
    10b1:      	movq	%rax, (%rsp)
    10b5:      	movq	%rsp, %rdi
    10b8:      	movl	$0x17, %eax
    10bd:      	movl	$0x6, %ecx
    10c2:      	movl	$0x17, %esi
    10c7:      	jmp	0xe38 <kprobe_unwind_stop+0xe38>
    10cc:      	movq	(%rip), %rax            # 0x10d3 <kprobe_unwind_stop+0x10d3>
    10d3:      	cmpl	$0x0, (%rax)
    10d6:      	je	0xcc1 <kprobe_unwind_stop+0xcc1>
    10dc:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    10e6:      	movq	%rax, 0x26(%rsp)
    10eb:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    10f5:      	movq	%rax, 0x20(%rsp)
    10fa:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1104:      	movq	%rax, 0x18(%rsp)
    1109:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1113:      	movq	%rax, 0x10(%rsp)
    1118:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1122:      	movq	%rax, 0x8(%rsp)
    1127:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1131:      	movq	%rax, (%rsp)
    1135:      	movq	%rsp, %rdi
    1138:      	movl	$0x2e, %eax
    113d:      	movl	$0x6, %ecx
    1142:      	movl	0x60(%rsp), %edx
    1146:      	movl	$0x2e, %esi
    114b:      	xorl	%eax, %eax
    114d:      	callq	*%rcx
    114f:      	jmp	0xcc1 <kprobe_unwind_stop+0xcc1>
    1154:      	testl	%ecx, %ecx
    1156:      	jne	0x1971 <kprobe_unwind_stop+0x1971>
    115c:      	movq	0x50(%rsp), %rax
    1161:      	testq	%rax, %rax
    1164:      	je	0x14df <kprobe_unwind_stop+0x14df>
    116a:      	movq	%rax, 0xf78(%r14)
    1171:      	cmpl	$0x0, (%r12)
    1176:      	jne	0x1ac6 <kprobe_unwind_stop+0x1ac6>
    117c:      	movl	$0x60, 0x60(%rsp)
    1184:      	movq	(%rip), %rdi            # 0x118b <kprobe_unwind_stop+0x118b>
    118b:      	leaq	0x60(%rsp), %rsi
    1190:      	movl	$0x1, %eax
    1195:      	callq	*%rax
    1197:      	testq	%rax, %rax
    119a:      	je	0x11a1 <kprobe_unwind_stop+0x11a1>
    119c:      	incq	(%rax)
    119f:      	jmp	0x11ac <kprobe_unwind_stop+0x11ac>
    11a1:      	cmpl	$0x0, (%r12)
    11a6:      	jne	0x1b58 <kprobe_unwind_stop+0x1b58>
    11ac:      	movl	$0x0, (%rsp)
    11b3:      	movq	(%rip), %rdi            # 0x11ba <kprobe_unwind_stop+0x11ba>
    11ba:      	movq	%rsp, %rsi
    11bd:      	movl	$0x1, %eax
    11c2:      	callq	*%rax
    11c4:      	testq	%rax, %rax
    11c7:      	je	0x120c <kprobe_unwind_stop+0x120c>
    11c9:      	movzbl	0x1384(%rax), %ecx
    11d0:      	movl	$0x9, %edx
    11d5:      	cmpb	$0x1d, %cl
    11d8:      	jb	0x1239 <kprobe_unwind_stop+0x1239>
    11da:      	movq	%rax, %r15
    11dd:      	movl	$0x5, 0xf2c(%rax)
    11e7:      	movl	$0x44, 0x60(%rsp)
    11ef:      	movq	(%rip), %rdi            # 0x11f6 <kprobe_unwind_stop+0x11f6>
    11f6:      	leaq	0x60(%rsp), %rsi
    11fb:      	movl	$0x1, %eax
    1200:      	callq	*%rax
    1202:      	testq	%rax, %rax
    1205:      	je	0x1221 <kprobe_unwind_stop+0x1221>
    1207:      	incq	(%rax)
    120a:      	jmp	0x122c <kprobe_unwind_stop+0x122c>
    120c:      	movq	(%rip), %rsi            # 0x1213 <kprobe_unwind_stop+0x1213>
    1213:      	xorl	%eax, %eax
    1215:      	movl	$0xc, %ecx
    121a:      	movq	%rbx, %rdi
    121d:      	xorl	%edx, %edx
    121f:      	jmp	0x1252 <kprobe_unwind_stop+0x1252>
    1221:      	cmpl	$0x0, (%r12)
    1226:      	jne	0x1bd0 <kprobe_unwind_stop+0x1bd0>
    122c:      	movq	%r15, %rax
    122f:      	movzbl	0x1384(%r15), %ecx
    1237:      	xorl	%edx, %edx
    1239:      	incb	%cl
    123b:      	movb	%cl, 0x1384(%rax)
    1241:      	movl	%edx, %eax
    1243:      	movq	(%rip), %rsi            # 0x124a <kprobe_unwind_stop+0x124a>
    124a:      	movl	$0xc, %ecx
    124f:      	movq	%rbx, %rdi
    1252:      	callq	*%rcx
    1254:      	jmp	0x14df <kprobe_unwind_stop+0x14df>
    1259:      	movabsq	$0xa65756c617620, %rax  # imm = 0xA65756C617620
    1263:      	movq	%rax, 0x15(%rsp)
    1268:      	movabsq	$0x6176206573616270, %rax # imm = 0x6176206573616270
    1272:      	movq	%rax, 0x10(%rsp)
    1277:      	movabsq	$0x742064616572206f, %rax # imm = 0x742064616572206F
    1281:      	movq	%rax, 0x8(%rsp)
    1286:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1290:      	movq	%rax, (%rsp)
    1294:      	movq	%rsp, %rdi
    1297:      	movl	$0x1d, %eax
    129c:      	movl	$0x6, %ecx
    12a1:      	movl	$0x1d, %esi
    12a6:      	xorl	%eax, %eax
    12a8:      	callq	*%rcx
    12aa:      	jmp	0xb2 <kprobe_unwind_stop+0xb2>
    12af:      	movabsq	$0xa65756c617620, %rax  # imm = 0xA65756C617620
    12b9:      	movq	%rax, 0x15(%rsp)
    12be:      	movabsq	$0x6176206573616270, %rax # imm = 0x6176206573616270
    12c8:      	movq	%rax, 0x10(%rsp)
    12cd:      	movabsq	$0x742064616572206f, %rax # imm = 0x742064616572206F
    12d7:      	movq	%rax, 0x8(%rsp)
    12dc:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    12e6:      	movq	%rax, (%rsp)
    12ea:      	movq	%rsp, %rdi
    12ed:      	movl	$0x1d, %eax
    12f2:      	movl	$0x6, %ecx
    12f7:      	movl	$0x1d, %esi
    12fc:      	xorl	%eax, %eax
    12fe:      	callq	*%rcx
    1300:      	jmp	0xd9b <kprobe_unwind_stop+0xd9b>
    1305:      	movabsq	$0xa6c6c75662073, %rax  # imm = 0xA6C6C75662073
    130f:      	movq	%rax, 0x1d(%rsp)
    1314:      	movabsq	$0x66207369206b6361, %rax # imm = 0x66207369206B6361
    131e:      	movq	%rax, 0x18(%rsp)
    1323:      	movabsq	$0x7473203a656d6172, %rax # imm = 0x7473203A656D6172
    132d:      	movq	%rax, 0x10(%rsp)
    1332:      	movabsq	$0x662068737570206f, %rax # imm = 0x662068737570206F
    133c:      	movq	%rax, 0x8(%rsp)
    1341:      	movabsq	$0x7420656c62616e75, %rax # imm = 0x7420656C62616E75
    134b:      	movq	%rax, (%rsp)
    134f:      	movq	%rsp, %rdi
    1352:      	movl	$0x25, %eax
    1357:      	movl	$0x6, %ecx
    135c:      	movl	$0x25, %esi
    1361:      	xorl	%eax, %eax
    1363:      	callq	*%rcx
    1365:      	jmp	0x65c <kprobe_unwind_stop+0x65c>
    136a:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1374:      	movq	%rax, 0x26(%rsp)
    1379:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1383:      	movq	%rax, 0x20(%rsp)
    1388:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1392:      	movq	%rax, 0x18(%rsp)
    1397:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    13a1:      	movq	%rax, 0x10(%rsp)
    13a6:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    13b0:      	movq	%rax, 0x8(%rsp)
    13b5:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    13bf:      	movq	%rax, (%rsp)
    13c3:      	movq	%rsp, %rdi
    13c6:      	movl	$0x2e, %eax
    13cb:      	movl	$0x6, %ecx
    13d0:      	movl	0x60(%rsp), %edx
    13d4:      	movl	$0x2e, %esi
    13d9:      	xorl	%eax, %eax
    13db:      	callq	*%rcx
    13dd:      	cmpl	$0x1, 0x2c0(%r14)
    13e5:      	je	0xd0d <kprobe_unwind_stop+0xd0d>
    13eb:      	jmp	0xd1b <kprobe_unwind_stop+0xd1b>
    13f0:      	movabsq	$0x786c6c2578302074, %rax # imm = 0x786C6C2578302074
    13fa:      	movq	%rax, 0x18(%rsp)
    13ff:      	movabsq	$0x6120656220646c75, %rax # imm = 0x6120656220646C75
    1409:      	movq	%rax, 0x10(%rsp)
    140e:      	movabsq	$0x6f68732072747020, %rax # imm = 0x6F68732072747020
    1418:      	movq	%rax, 0x8(%rsp)
    141d:      	movabsq	$0x72726f63204d5041, %rax # imm = 0x72726F63204D5041
    1427:      	movq	%rax, (%rsp)
    142b:      	movw	$0xa, 0x20(%rsp)
    1432:      	movq	%rsp, %rdi
    1435:      	movl	$0x22, %eax
    143a:      	movl	$0x6, %ecx
    143f:      	movq	(%r15), %rdx
    1442:      	addq	0x58(%rsp), %rdx
    1447:      	movl	$0x22, %esi
    144c:      	xorl	%eax, %eax
    144e:      	callq	*%rcx
    1450:      	jmp	0xf0 <kprobe_unwind_stop+0xf0>
    1455:      	movabsq	$0x6425203a74657366, %rax # imm = 0x6425203A74657366
    145f:      	movq	%rax, 0x20(%rsp)
    1464:      	movabsq	$0x666f2067202c786c, %rax # imm = 0x666F2067202C786C
    146e:      	movq	%rax, 0x18(%rsp)
    1473:      	movabsq	$0x2578302074612065, %rax # imm = 0x2578302074612065
    147d:      	movq	%rax, 0x10(%rsp)
    1482:      	movabsq	$0x7361625f64737420, %rax # imm = 0x7361625F64737420
    148c:      	movq	%rax, 0x8(%rsp)
    1491:      	movabsq	$0x64616572203a6c63, %rax # imm = 0x64616572203A6C63
    149b:      	movq	%rax, (%rsp)
    149f:      	movw	$0xa, 0x28(%rsp)
    14a6:      	movq	%rsp, %rdi
    14a9:      	movl	$0x2a, %eax
    14ae:      	movl	$0x6, %r8d
    14b4:      	movq	0x58(%rsp), %rdx
    14b9:      	movl	0x18(%r15), %ecx
    14bd:      	movl	$0x2a, %esi
    14c2:      	xorl	%eax, %eax
    14c4:      	callq	*%r8
    14c7:      	movslq	0x18(%r15), %rax
    14cb:      	testq	%rax, %rax
    14ce:      	jne	0xee5 <kprobe_unwind_stop+0xee5>
    14d4:      	cmpl	$0x0, (%r12)
    14d9:      	jne	0x1780 <kprobe_unwind_stop+0x1780>
    14df:      	movl	$0x80, %eax
    14e4:      	subl	0x2c0(%r14), %eax
    14eb:      	shlq	$0x3, %rax
    14ef:      	leaq	(%rax,%rax,2), %rax
    14f3:      	movl	$0xed0, %r8d            # imm = 0xED0
    14f9:      	subq	%rax, %r8
    14fc:      	xorl	%eax, %eax
    14fe:      	cmpq	$0xed0, %r8             # imm = 0xED0
    1505:      	ja	0x1529 <kprobe_unwind_stop+0x1529>
    1507:      	movq	(%rip), %rsi            # 0x150e <kprobe_unwind_stop+0x150e>
    150e:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
    1513:      	movl	$0x19, %r9d
    1519:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    151e:      	movq	%rbx, %rdi
    1521:      	movq	%r14, %rcx
    1524:      	callq	*%r9
    1527:      	xorl	%eax, %eax
    1529:      	addq	$0x98, %rsp
    1530:      	popq	%rbx
    1531:      	popq	%r12
    1533:      	popq	%r13
    1535:      	popq	%r14
    1537:      	popq	%r15
    1539:      	popq	%rbp
    153a:      	retq
    153b:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1545:      	movq	%rax, 0x26(%rsp)
    154a:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1554:      	movq	%rax, 0x20(%rsp)
    1559:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1563:      	movq	%rax, 0x18(%rsp)
    1568:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1572:      	movq	%rax, 0x10(%rsp)
    1577:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1581:      	movq	%rax, 0x8(%rsp)
    1586:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1590:      	movq	%rax, (%rsp)
    1594:      	movq	%rsp, %rdi
    1597:      	movl	$0x2e, %eax
    159c:      	movl	$0x6, %ecx
    15a1:      	movl	0x60(%rsp), %edx
    15a5:      	movl	$0x2e, %esi
    15aa:      	xorl	%eax, %eax
    15ac:      	callq	*%rcx
    15ae:      	jmp	0x1ce <kprobe_unwind_stop+0x1ce>
    15b3:      	movabsq	$0xa64253d74706d, %rcx  # imm = 0xA64253D74706D
    15bd:      	movq	%rcx, 0x17(%rsp)
    15c2:      	movabsq	$0x6d65747461202c64, %rcx # imm = 0x6D65747461202C64
    15cc:      	movq	%rcx, 0x10(%rsp)
    15d1:      	movabsq	$0x6e657320746e6576, %rcx # imm = 0x6E657320746E6576
    15db:      	movq	%rcx, 0x8(%rsp)
    15e0:      	movabsq	$0x6520642520444950, %rcx # imm = 0x6520642520444950
    15ea:      	movq	%rcx, (%rsp)
    15ee:      	movq	%rsp, %rdi
    15f1:      	movl	$0x1f, %ecx
    15f6:      	movl	$0x6, %r8d
    15fc:      	movl	0x48(%rsp), %edx
    1600:      	movl	$0x1f, %esi
    1605:      	movl	%r15d, %ecx
    1608:      	movq	%rax, 0x90(%rsp)
    1610:      	xorl	%eax, %eax
    1612:      	callq	*%r8
    1615:      	movq	0x90(%rsp), %rax
    161d:      	jmp	0x9b7 <kprobe_unwind_stop+0x9b7>
    1622:      	movabsq	$0x74706d6520736920, %rax # imm = 0x74706D6520736920
    162c:      	movq	%rax, 0x20(%rsp)
    1631:      	movabsq	$0x6b63617473206568, %rax # imm = 0x6B63617473206568
    163b:      	movq	%rax, 0x18(%rsp)
    1640:      	movabsq	$0x7420747562206465, %rax # imm = 0x7420747562206465
    164a:      	movq	%rax, 0x10(%rsp)
    164f:      	movabsq	$0x6c6c616320706f74, %rax # imm = 0x6C6C616320706F74
    1659:      	movq	%rax, 0x8(%rsp)
    165e:      	movabsq	$0x735f646e69776e75, %rax # imm = 0x735F646E69776E75
    1668:      	movq	%rax, (%rsp)
    166c:      	movl	$0xa7974, 0x27(%rsp)    # imm = 0xA7974
    1674:      	movq	%rsp, %rdi
    1677:      	movl	$0x2b, %eax
    167c:      	movl	$0x6, %ecx
    1681:      	movl	$0x2b, %esi
    1686:      	xorl	%eax, %eax
    1688:      	callq	*%rcx
    168a:      	jmp	0x5d0 <kprobe_unwind_stop+0x5d0>
    168f:      	movabsq	$0xa6425203a6425, %rcx  # imm = 0xA6425203A6425
    1699:      	movq	%rcx, 0x2d(%rsp)
    169e:      	movabsq	$0x3a6425203a444954, %rcx # imm = 0x3A6425203A444954
    16a8:      	movq	%rcx, 0x28(%rsp)
    16ad:      	movabsq	$0x2064252044495020, %rcx # imm = 0x2064252044495020
    16b7:      	movq	%rcx, 0x20(%rsp)
    16bc:      	movabsq	$0x687469772073746e, %rcx # imm = 0x687469772073746E
    16c6:      	movq	%rcx, 0x18(%rsp)
    16cb:      	movabsq	$0x6576655f64697020, %rcx # imm = 0x6576655F64697020
    16d5:      	movq	%rcx, 0x10(%rsp)
    16da:      	movabsq	$0x657461647075206f, %rcx # imm = 0x657461647075206F
    16e4:      	movq	%rcx, 0x8(%rsp)
    16e9:      	movabsq	$0x742064656c696146, %rcx # imm = 0x742064656C696146
    16f3:      	movq	%rcx, (%rsp)
    16f7:      	movl	0x58(%rsp), %ecx
    16fb:      	movq	%rsp, %rdi
    16fe:      	movl	$0x35, %edx
    1703:      	movl	$0x6, %r9d
    1709:      	movl	0x8c(%rsp), %edx
    1710:      	movl	$0x35, %esi
    1715:      	movl	%eax, %r8d
    1718:      	xorl	%eax, %eax
    171a:      	callq	*%r9
    171d:      	jmp	0xad5 <kprobe_unwind_stop+0xad5>
    1722:      	movabsq	$0xa6425203a6425, %rcx  # imm = 0xA6425203A6425
    172c:      	movq	%rcx, 0x15(%rsp)
    1731:      	movabsq	$0x3a64252044495020, %rcx # imm = 0x3A64252044495020
    173b:      	movq	%rcx, 0x10(%rsp)
    1740:      	movabsq	$0x74726f706572206f, %rcx # imm = 0x74726F706572206F
    174a:      	movq	%rcx, 0x8(%rsp)
    174f:      	movabsq	$0x742064656c696146, %rcx # imm = 0x742064656C696146
    1759:      	movq	%rcx, (%rsp)
    175d:      	movq	%rsp, %rdi
    1760:      	movl	$0x1d, %ecx
    1765:      	movl	$0x6, %r8d
    176b:      	movl	0x48(%rsp), %edx
    176f:      	movl	$0x1d, %esi
    1774:      	movl	%eax, %ecx
    1776:      	xorl	%eax, %eax
    1778:      	callq	*%r8
    177b:      	jmp	0x9fb <kprobe_unwind_stop+0x9fb>
    1780:      	movabsq	$0xa3436646d6120, %rax  # imm = 0xA3436646D6120
    178a:      	movq	%rax, 0x28(%rsp)
    178f:      	movabsq	$0x726f6620676e6973, %rax # imm = 0x726F6620676E6973
    1799:      	movq	%rax, 0x20(%rsp)
    179e:      	movabsq	$0x73696d207265746e, %rax # imm = 0x73696D207265746E
    17a8:      	movq	%rax, 0x18(%rsp)
    17ad:      	movabsq	$0x696f70206720726f, %rax # imm = 0x696F70206720726F
    17b7:      	movq	%rax, 0x10(%rsp)
    17bc:      	movabsq	$0x662074657366666f, %rax # imm = 0x662074657366666F
    17c6:      	movq	%rax, 0x8(%rsp)
    17cb:      	movabsq	$0x20534c54203a6c63, %rax # imm = 0x20534C54203A6C63
    17d5:      	movq	%rax, (%rsp)
    17d9:      	movq	%rsp, %rdi
    17dc:      	movl	$0x30, %eax
    17e1:      	movl	$0x6, %ecx
    17e6:      	movl	$0x30, %esi
    17eb:      	jmp	0xe38 <kprobe_unwind_stop+0xe38>
    17f0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    17fa:      	movq	%rax, 0x26(%rsp)
    17ff:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1809:      	movq	%rax, 0x20(%rsp)
    180e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1818:      	movq	%rax, 0x18(%rsp)
    181d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1827:      	movq	%rax, 0x10(%rsp)
    182c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1836:      	movq	%rax, 0x8(%rsp)
    183b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1845:      	movq	%rax, (%rsp)
    1849:      	movq	%rsp, %rdi
    184c:      	movl	$0x2e, %eax
    1851:      	movl	$0x6, %ecx
    1856:      	movl	0x60(%rsp), %edx
    185a:      	movl	$0x2e, %esi
    185f:      	xorl	%eax, %eax
    1861:      	callq	*%rcx
    1863:      	cmpl	$0x0, 0xf2c(%r14)
    186b:      	jne	0x61e <kprobe_unwind_stop+0x61e>
    1871:      	jmp	0x5fd <kprobe_unwind_stop+0x5fd>
    1876:      	movabsq	$0xa78257830202b, %rax  # imm = 0xA78257830202B
    1880:      	movq	%rax, 0x20(%rsp)
    1885:      	movabsq	$0x20786c2578302074, %rax # imm = 0x20786C2578302074
    188f:      	movq	%rax, 0x18(%rsp)
    1894:      	movabsq	$0x6120726464615f72, %rax # imm = 0x6120726464615F72
    189e:      	movq	%rax, 0x10(%rsp)
    18a3:      	movabsq	$0x74705f6d20676e69, %rax # imm = 0x74705F6D20676E69
    18ad:      	movq	%rax, 0x8(%rsp)
    18b2:      	movabsq	$0x64616572203a6c63, %rax # imm = 0x64616572203A6C63
    18bc:      	movq	%rax, (%rsp)
    18c0:      	movq	%rsp, %rdi
    18c3:      	movl	$0x28, %eax
    18c8:      	movl	$0x6, %r8d
    18ce:      	movq	0x60(%rsp), %rdx
    18d3:      	movl	(%r15), %ecx
    18d6:      	movl	$0x28, %esi
    18db:      	xorl	%eax, %eax
    18dd:      	callq	*%r8
    18e0:      	jmp	0x104c <kprobe_unwind_stop+0x104c>
    18e5:      	movabsq	$0xa642520726f72, %rcx  # imm = 0xA642520726F72
    18ef:      	movq	%rcx, 0x2e(%rsp)
    18f4:      	movabsq	$0x6f727265203a6425, %rcx # imm = 0x6F727265203A6425
    18fe:      	movq	%rcx, 0x28(%rsp)
    1903:      	movabsq	$0x20746e6576652064, %rcx # imm = 0x20746E6576652064
    190d:      	movq	%rcx, 0x20(%rsp)
    1912:      	movabsq	$0x6e6573206f742064, %rcx # imm = 0x6E6573206F742064
    191c:      	movq	%rcx, 0x18(%rsp)
    1921:      	movabsq	$0x656c696166207265, %rcx # imm = 0x656C696166207265
    192b:      	movq	%rcx, 0x10(%rsp)
    1930:      	movabsq	$0x67676972745f646e, %rcx # imm = 0x67676972745F646E
    193a:      	movq	%rcx, 0x8(%rsp)
    193f:      	movabsq	$0x65735f746e657665, %rcx # imm = 0x65735F746E657665
    1949:      	movq	%rcx, (%rsp)
    194d:      	movq	%rsp, %rdi
    1950:      	movl	$0x36, %ecx
    1955:      	movl	$0x6, %r8d
    195b:      	movl	$0x36, %esi
    1960:      	movl	$0x1, %edx
    1965:      	movl	%eax, %ecx
    1967:      	xorl	%eax, %eax
    1969:      	callq	*%r8
    196c:      	jmp	0xc9a <kprobe_unwind_stop+0xc9a>
    1971:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    197b:      	movq	%rax, 0xe(%rsp)
    1980:      	movabsq	$0x3020726464615f72, %rax # imm = 0x3020726464615F72
    198a:      	movq	%rax, 0x8(%rsp)
    198f:      	movabsq	$0x74705f6d203a6c63, %rax # imm = 0x74705F6D203A6C63
    1999:      	movq	%rax, (%rsp)
    199d:      	movq	%rsp, %rdi
    19a0:      	movl	$0x16, %eax
    19a5:      	movl	$0x6, %ecx
    19aa:      	movq	0x50(%rsp), %rdx
    19af:      	movl	$0x16, %esi
    19b4:      	xorl	%eax, %eax
    19b6:      	callq	*%rcx
    19b8:      	movq	0x50(%rsp), %rax
    19bd:      	testq	%rax, %rax
    19c0:      	jne	0x116a <kprobe_unwind_stop+0x116a>
    19c6:      	jmp	0x14df <kprobe_unwind_stop+0x14df>
    19cb:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    19d5:      	movq	%rax, 0x26(%rsp)
    19da:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    19e4:      	movq	%rax, 0x20(%rsp)
    19e9:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    19f3:      	movq	%rax, 0x18(%rsp)
    19f8:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1a02:      	movq	%rax, 0x10(%rsp)
    1a07:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1a11:      	movq	%rax, 0x8(%rsp)
    1a16:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1a20:      	movq	%rax, (%rsp)
    1a24:      	movq	%rsp, %rdi
    1a27:      	movl	$0x2e, %eax
    1a2c:      	movl	$0x6, %ecx
    1a31:      	movl	0x60(%rsp), %edx
    1a35:      	movl	$0x2e, %esi
    1a3a:      	xorl	%eax, %eax
    1a3c:      	callq	*%rcx
    1a3e:      	jmp	0xc51 <kprobe_unwind_stop+0xc51>
    1a43:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1a4d:      	movq	%rax, 0x26(%rsp)
    1a52:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1a5c:      	movq	%rax, 0x20(%rsp)
    1a61:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1a6b:      	movq	%rax, 0x18(%rsp)
    1a70:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1a7a:      	movq	%rax, 0x10(%rsp)
    1a7f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1a89:      	movq	%rax, 0x8(%rsp)
    1a8e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1a98:      	movq	%rax, (%rsp)
    1a9c:      	movq	%rsp, %rdi
    1a9f:      	movl	$0x2e, %eax
    1aa4:      	movl	$0x6, %ecx
    1aa9:      	movl	0x48(%rsp), %edx
    1aad:      	movl	$0x2e, %esi
    1ab2:      	xorl	%eax, %eax
    1ab4:      	callq	*%rcx
    1ab6:      	cmpl	$0x0, (%r12)
    1abb:      	je	0x5ab <kprobe_unwind_stop+0x5ab>
    1ac1:      	jmp	0x49e <kprobe_unwind_stop+0x49e>
    1ac6:      	movabsq	$0xa64656c62616e, %rax  # imm = 0xA64656C62616E
    1ad0:      	movq	%rax, 0x35(%rsp)
    1ad5:      	movabsq	$0x62616e6520736c65, %rax # imm = 0x62616E6520736C65
    1adf:      	movq	%rax, 0x30(%rsp)
    1ae4:      	movabsq	$0x62616c206d6f7473, %rax # imm = 0x62616C206D6F7473
    1aee:      	movq	%rax, 0x28(%rsp)
    1af3:      	movabsq	$0x7563206f47206874, %rax # imm = 0x7563206F47206874
    1afd:      	movq	%rax, 0x20(%rsp)
    1b02:      	movabsq	$0x697720737365636f, %rax # imm = 0x697720737365636F
    1b0c:      	movq	%rax, 0x18(%rsp)
    1b11:      	movabsq	$0x72702061206e6968, %rax # imm = 0x72702061206E6968
    1b1b:      	movq	%rax, 0x10(%rsp)
    1b20:      	movabsq	$0x7469772073692065, %rax # imm = 0x7469772073692065
    1b2a:      	movq	%rax, 0x8(%rsp)
    1b2f:      	movabsq	$0x63617274203a6c63, %rax # imm = 0x63617274203A6C63
    1b39:      	movq	%rax, (%rsp)
    1b3d:      	movq	%rsp, %rdi
    1b40:      	movl	$0x3d, %eax
    1b45:      	movl	$0x6, %ecx
    1b4a:      	movl	$0x3d, %esi
    1b4f:      	xorl	%eax, %eax
    1b51:      	callq	*%rcx
    1b53:      	jmp	0x117c <kprobe_unwind_stop+0x117c>
    1b58:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1b62:      	movq	%rax, 0x26(%rsp)
    1b67:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1b71:      	movq	%rax, 0x20(%rsp)
    1b76:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1b80:      	movq	%rax, 0x18(%rsp)
    1b85:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1b8f:      	movq	%rax, 0x10(%rsp)
    1b94:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1b9e:      	movq	%rax, 0x8(%rsp)
    1ba3:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1bad:      	movq	%rax, (%rsp)
    1bb1:      	movq	%rsp, %rdi
    1bb4:      	movl	$0x2e, %eax
    1bb9:      	movl	$0x6, %ecx
    1bbe:      	movl	0x60(%rsp), %edx
    1bc2:      	movl	$0x2e, %esi
    1bc7:      	xorl	%eax, %eax
    1bc9:      	callq	*%rcx
    1bcb:      	jmp	0x11ac <kprobe_unwind_stop+0x11ac>
    1bd0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1bda:      	movq	%rax, 0x26(%rsp)
    1bdf:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1be9:      	movq	%rax, 0x20(%rsp)
    1bee:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1bf8:      	movq	%rax, 0x18(%rsp)
    1bfd:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1c07:      	movq	%rax, 0x10(%rsp)
    1c0c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1c16:      	movq	%rax, 0x8(%rsp)
    1c1b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1c25:      	movq	%rax, (%rsp)
    1c29:      	movq	%rsp, %rdi
    1c2c:      	movl	$0x2e, %eax
    1c31:      	movl	$0x6, %ecx
    1c36:      	movl	0x60(%rsp), %edx
    1c3a:      	movl	$0x2e, %esi
    1c3f:      	xorl	%eax, %eax
    1c41:      	callq	*%rcx
    1c43:      	jmp	0x122c <kprobe_unwind_stop+0x122c>
