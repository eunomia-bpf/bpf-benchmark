
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_execve_event_v310.native.o:	file format elf64-x86-64

Disassembly of section tracepoint:

0000000000000000 <execve_rate>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x48, %rsp
       e:      	movq	%rdi, %rbx
      11:      	movl	$0x0, 0x8(%rsp)
      19:      	movq	(%rip), %rdi            # 0x20 <execve_rate+0x20>
      20:      	leaq	0x8(%rsp), %rsi
      25:      	movl	$0x1, %eax
      2a:      	callq	*%rax
      2c:      	testq	%rax, %rax
      2f:      	je	0x2a7 <execve_rate+0x2a7>
      35:      	movq	0x8(%rax), %r15
      39:      	movq	%rax, %r12
      3c:      	movq	0x10(%rax), %rax
      40:      	movq	%rax, 0x18(%rsp)
      45:      	movl	$0x0, 0xc(%rsp)
      4d:      	movq	(%rip), %rdi            # 0x54 <execve_rate+0x54>
      54:      	leaq	0xc(%rsp), %rsi
      59:      	movl	$0x1, %eax
      5e:      	callq	*%rax
      60:      	testq	%rax, %rax
      63:      	je	0x28c <execve_rate+0x28c>
      69:      	movq	0x8(%rax), %r13
      6d:      	testq	%r13, %r13
      70:      	je	0x28c <execve_rate+0x28c>
      76:      	movq	%rax, %rbp
      79:      	movq	(%rip), %rdi            # 0x80 <execve_rate+0x80>
      80:      	leaq	0x18(%rsp), %rsi
      85:      	movl	$0x1, %eax
      8a:      	callq	*%rax
      8c:      	testq	%rax, %rax
      8f:      	je	0xc6 <execve_rate+0xc6>
      91:      	movq	%rax, %r14
      94:      	movq	0x10(%rax), %rax
      98:      	movq	%r15, %rcx
      9b:      	subq	%rax, %rcx
      9e:      	cmpq	%r13, %rcx
      a1:      	jbe	0x11c <execve_rate+0x11c>
      a3:      	leaq	(,%r13,2), %rdx
      ab:      	cmpq	%rdx, %rcx
      ae:      	jbe	0x124 <execve_rate+0x124>
      b0:      	movq	$0x0, 0x8(%r14)
      b8:      	movq	%r15, %rax
      bb:      	xorl	%edx, %edx
      bd:      	divq	%r13
      c0:      	imulq	%r13, %rax
      c4:      	jmp	0x12e <execve_rate+0x12e>
      c6:      	movq	$0x1, 0x20(%rsp)
      cf:      	movq	$0x0, 0x28(%rsp)
      d8:      	movq	%r15, %rax
      db:      	xorl	%edx, %edx
      dd:      	divq	%r13
      e0:      	imulq	%r13, %rax
      e4:      	movq	%rax, 0x30(%rsp)
      e9:      	movq	$0x0, 0x38(%rsp)
      f2:      	movq	$0x0, 0x40(%rsp)
      fb:      	movq	(%rip), %rdi            # 0x102 <execve_rate+0x102>
     102:      	xorl	%ecx, %ecx
     104:      	leaq	0x18(%rsp), %rsi
     109:      	leaq	0x20(%rsp), %rdx
     10e:      	movl	$0x2, %eax
     113:      	xorl	%ecx, %ecx
     115:      	callq	*%rax
     117:      	jmp	0x28c <execve_rate+0x28c>
     11c:      	movq	(%r14), %rcx
     11f:      	incq	%rcx
     122:      	jmp	0x137 <execve_rate+0x137>
     124:      	movq	(%r14), %rcx
     127:      	movq	%rcx, 0x8(%r14)
     12b:      	addq	%r13, %rax
     12e:      	movq	%rax, 0x10(%r14)
     132:      	movl	$0x1, %ecx
     137:      	movq	%rcx, (%r14)
     13a:      	movq	%r13, %rcx
     13d:      	subq	%r15, %rcx
     140:      	addq	%rax, %rcx
     143:      	imulq	0x8(%r14), %rcx
     148:      	movq	%rcx, %rax
     14b:      	xorl	%edx, %edx
     14d:      	divq	%r13
     150:      	addq	(%r14), %rax
     153:      	movq	%rax, 0x18(%r14)
     157:      	cmpq	$0x0, 0x20(%r14)
     15c:      	jne	0x2a7 <execve_rate+0x2a7>
     162:      	cmpq	(%rbp), %rax
     166:      	jb	0x28c <execve_rate+0x28c>
     16c:      	movq	%r15, 0x20(%r14)
     170:      	movl	$0x0, 0x14(%rsp)
     178:      	movq	(%rip), %rdi            # 0x17f <execve_rate+0x17f>
     17f:      	leaq	0x14(%rsp), %rcx
     184:      	movl	$0x1, %eax
     189:      	movl	$0x0, 0x10(%rsp)
     191:      	leaq	0x10(%rsp), %rsi
     196:      	callq	*%rax
     198:      	testq	%rax, %rax
     19b:      	je	0x285 <execve_rate+0x285>
     1a1:      	movl	$0xa0, 0x4(%rax)
     1a8:      	movq	%r12, %rsi
     1ab:      	addq	$0x10, %rsi
     1af:      	movq	%r15, 0x8(%rax)
     1b3:      	movw	$0x1b, (%rax)
     1b8:      	movq	%rax, %rdi
     1bb:      	addq	$0x10, %rdi
     1bf:      	movl	$0x90, %edx
     1c4:      	movq	%rax, %r15
     1c7:      	callq	0x1cc <execve_rate+0x1cc>
     1cc:      	movq	(%rip), %rsi            # 0x1d3 <execve_rate+0x1d3>
     1d3:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     1d8:      	movl	$0xa0, %edx
     1dd:      	movl	$0x19, %eax
     1e2:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     1e7:      	movl	$0xa0, %r8d
     1ed:      	movq	%rbx, %rdi
     1f0:      	movq	%r15, %rcx
     1f3:      	callq	*%rax
     1f5:      	testq	%rax, %rax
     1f8:      	jns	0x285 <execve_rate+0x285>
     1fe:      	movq	%rax, %r15
     201:      	movl	$0x0, 0x20(%rsp)
     209:      	movq	(%rip), %rdi            # 0x210 <execve_rate+0x210>
     210:      	leaq	0x20(%rsp), %rsi
     215:      	movl	$0x1, %eax
     21a:      	callq	*%rax
     21c:      	testq	%rax, %rax
     21f:      	je	0x285 <execve_rate+0x285>
     221:      	cmpq	$-0xc, %r15
     225:      	jg	0x241 <execve_rate+0x241>
     227:      	cmpq	$-0x1c, %r15
     22b:      	je	0x25b <execve_rate+0x25b>
     22d:      	cmpq	$-0x16, %r15
     231:      	je	0x273 <execve_rate+0x273>
     233:      	cmpq	$-0x10, %r15
     237:      	jne	0x26b <execve_rate+0x26b>
     239:      	addq	$0x600, %rax            # imm = 0x600
     23f:      	jmp	0x281 <execve_rate+0x281>
     241:      	cmpq	$-0xb, %r15
     245:      	je	0x263 <execve_rate+0x263>
     247:      	cmpq	$-0x7, %r15
     24b:      	je	0x27b <execve_rate+0x27b>
     24d:      	cmpq	$-0x2, %r15
     251:      	jne	0x26b <execve_rate+0x26b>
     253:      	addq	$0x5f0, %rax            # imm = 0x5F0
     259:      	jmp	0x281 <execve_rate+0x281>
     25b:      	addq	$0x610, %rax            # imm = 0x610
     261:      	jmp	0x281 <execve_rate+0x281>
     263:      	addq	$0x618, %rax            # imm = 0x618
     269:      	jmp	0x281 <execve_rate+0x281>
     26b:      	addq	$0x5e8, %rax            # imm = 0x5E8
     271:      	jmp	0x281 <execve_rate+0x281>
     273:      	addq	$0x608, %rax            # imm = 0x608
     279:      	jmp	0x281 <execve_rate+0x281>
     27b:      	addq	$0x5f8, %rax            # imm = 0x5F8
     281:      	lock
     282:      	incq	(%rax)
     285:      	cmpq	$0x0, 0x20(%r14)
     28a:      	jne	0x2a7 <execve_rate+0x2a7>
     28c:      	movq	(%rip), %rsi            # 0x293 <execve_rate+0x293>
     293:      	movl	$0x1, %ecx
     298:      	movl	$0xc, %eax
     29d:      	movq	%rbx, %rdi
     2a0:      	movl	$0x1, %edx
     2a5:      	callq	*%rax
     2a7:      	xorl	%eax, %eax
     2a9:      	addq	$0x48, %rsp
     2ad:      	popq	%rbx
     2ae:      	popq	%r12
     2b0:      	popq	%r13
     2b2:      	popq	%r14
     2b4:      	popq	%r15
     2b6:      	popq	%rbp
     2b7:      	retq
     2b8:      	nopl	(%rax,%rax)

00000000000002c0 <execve_send>:
     2c0:      	pushq	%r15
     2c2:      	pushq	%r14
     2c4:      	pushq	%r12
     2c6:      	pushq	%rbx
     2c7:      	subq	$0x18, %rsp
     2cb:      	movq	%rdi, %rbx
     2ce:      	movl	$0x0, 0x14(%rsp)
     2d6:      	movq	(%rip), %rdi            # 0x2dd <execve_send+0x1d>
     2dd:      	leaq	0x14(%rsp), %rsi
     2e2:      	movl	$0x1, %eax
     2e7:      	callq	*%rax
     2e9:      	testq	%rax, %rax
     2ec:      	je	0x6ea <execve_send+0x42a>
     2f2:      	movq	%rax, %r14
     2f5:      	movl	$0xe, %eax
     2fa:      	callq	*%rax
     2fc:      	shrq	$0x20, %rax
     300:      	movl	%eax, (%rsp)
     303:      	movq	(%rip), %rdi            # 0x30a <execve_send+0x4a>
     30a:      	movq	%rsp, %rsi
     30d:      	movl	$0x1, %eax
     312:      	callq	*%rax
     314:      	testq	%rax, %rax
     317:      	je	0x61d <execve_send+0x35d>
     31d:      	movq	%rax, %r15
     320:      	movq	%rax, %r12
     323:      	movq	(%r15), %rax
     326:      	movq	0x8(%r15), %rcx
     32a:      	movq	%rcx, 0x138(%r14)
     331:      	movq	%rax, 0x130(%r14)
     338:      	movl	0x144(%r14), %eax
     33f:      	movl	%eax, (%r15)
     342:      	movq	0x170(%r14), %rax
     349:      	movq	%rax, 0x8(%r15)
     34d:      	movl	0x14c(%r14), %eax
     354:      	movl	%eax, 0x24(%r15)
     358:      	movq	0xa0(%r14), %rcx
     35f:      	movq	0xa8(%r14), %rdx
     366:      	movq	%rcx, 0x10(%r15)
     36a:      	movq	%rdx, 0x18(%r15)
     36e:      	movl	0x20(%r15), %ecx
     372:      	testb	$0x1, %cl
     375:      	je	0x37f <execve_send+0xbf>
     377:      	orb	$0x40, 0x15d(%r14)
     37f:      	andl	$-0x2, %ecx
     382:      	movl	%ecx, %edx
     384:      	orl	$0x2000000, %edx        # imm = 0x2000000
     38a:      	cmpl	$0x1, %eax
     38d:      	cmovnel	%ecx, %edx
     390:      	movl	%edx, 0x20(%r12)
     395:      	testl	$0x2000000, %edx        # imm = 0x2000000
     39b:      	je	0x3a5 <execve_send+0xe5>
     39d:      	orb	$0x2, 0x15f(%r14)
     3a5:      	leaq	0x68(%r15), %rdi
     3a9:      	movl	$0x308, %edx            # imm = 0x308
     3ae:      	xorl	%esi, %esi
     3b0:      	callq	0x3b5 <execve_send+0xf5>
     3b5:      	movzwl	0x8(%rbx), %edx
     3b9:      	addq	%rbx, %rdx
     3bc:      	addq	$0x70, %r15
     3c0:      	movl	$0x100, %ecx            # imm = 0x100
     3c5:      	movl	$0x2d, %eax
     3ca:      	movq	%r15, %rdi
     3cd:      	movl	$0x100, %esi            # imm = 0x100
     3d2:      	callq	*%rax
     3d4:      	xorl	%ecx, %ecx
     3d6:      	cmpl	$0x2, %eax
     3d9:      	setge	%cl
     3dc:      	subl	%ecx, %eax
     3de:      	movl	%eax, 0x68(%r12)
     3e3:      	movl	$0x23, %eax
     3e8:      	callq	*%rax
     3ea:      	movq	%rax, %rcx
     3ed:      	movq	%rax, (%rsp)
     3f1:      	addq	$0xb00, %rcx            # imm = 0xB00
     3f8:      	movq	%rsp, %rdi
     3fb:      	movl	$0x8, %edx
     400:      	movl	$0x71, %eax
     405:      	movl	$0xb00, %edx            # imm = 0xB00
     40a:      	addq	(%rsp), %rdx
     40e:      	movl	$0x8, %esi
     413:      	callq	*%rax
     415:      	movq	(%rsp), %rcx
     419:      	testq	%rcx, %rcx
     41c:      	je	0x5fc <execve_send+0x33c>
     422:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     429:      	leaq	0xc(%rsp), %rdi
     42e:      	movl	$0x4, %edx
     433:      	movl	$0x71, %eax
     438:      	movl	$0xaf4, %edx            # imm = 0xAF4
     43d:      	addq	(%rsp), %rdx
     441:      	movl	$0x4, %esi
     446:      	callq	*%rax
     448:      	movl	0xc(%rsp), %eax
     44c:      	movl	%eax, 0x10(%rsp)
     450:      	movq	(%rip), %rdi            # 0x457 <execve_send+0x197>
     457:      	leaq	0x10(%rsp), %rsi
     45c:      	movl	$0x1, %eax
     461:      	callq	*%rax
     463:      	testq	%rax, %rax
     466:      	je	0x473 <execve_send+0x1b3>
     468:      	cmpq	$0x0, 0x8(%rax)
     46d:      	jne	0x5ed <execve_send+0x32d>
     473:      	movl	$0xb00, %edx            # imm = 0xB00
     478:      	movq	(%rsp), %rcx
     47c:      	addq	%rdx, %rcx
     47f:      	movq	%rsp, %rdi
     482:      	movl	$0x8, %esi
     487:      	movl	$0x71, %eax
     48c:      	addq	(%rsp), %rdx
     490:      	movl	$0x8, %esi
     495:      	callq	*%rax
     497:      	movq	(%rsp), %rcx
     49b:      	testq	%rcx, %rcx
     49e:      	je	0x5fc <execve_send+0x33c>
     4a4:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     4ab:      	leaq	0xc(%rsp), %rdi
     4b0:      	movl	$0x4, %edx
     4b5:      	movl	$0x71, %eax
     4ba:      	movl	$0xaf4, %edx            # imm = 0xAF4
     4bf:      	addq	(%rsp), %rdx
     4c3:      	movl	$0x4, %esi
     4c8:      	callq	*%rax
     4ca:      	movl	0xc(%rsp), %eax
     4ce:      	movl	%eax, 0x10(%rsp)
     4d2:      	movq	(%rip), %rdi            # 0x4d9 <execve_send+0x219>
     4d9:      	leaq	0x10(%rsp), %rsi
     4de:      	movl	$0x1, %eax
     4e3:      	callq	*%rax
     4e5:      	testq	%rax, %rax
     4e8:      	je	0x4f5 <execve_send+0x235>
     4ea:      	cmpq	$0x0, 0x8(%rax)
     4ef:      	jne	0x5ed <execve_send+0x32d>
     4f5:      	movl	$0xb00, %edx            # imm = 0xB00
     4fa:      	movq	(%rsp), %rcx
     4fe:      	addq	%rdx, %rcx
     501:      	movq	%rsp, %rdi
     504:      	movl	$0x8, %esi
     509:      	movl	$0x71, %eax
     50e:      	addq	(%rsp), %rdx
     512:      	movl	$0x8, %esi
     517:      	callq	*%rax
     519:      	movq	(%rsp), %rcx
     51d:      	testq	%rcx, %rcx
     520:      	je	0x5fc <execve_send+0x33c>
     526:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     52d:      	leaq	0xc(%rsp), %rdi
     532:      	movl	$0x4, %edx
     537:      	movl	$0x71, %eax
     53c:      	movl	$0xaf4, %edx            # imm = 0xAF4
     541:      	addq	(%rsp), %rdx
     545:      	movl	$0x4, %esi
     54a:      	callq	*%rax
     54c:      	movl	0xc(%rsp), %eax
     550:      	movl	%eax, 0x10(%rsp)
     554:      	movq	(%rip), %rdi            # 0x55b <execve_send+0x29b>
     55b:      	leaq	0x10(%rsp), %rsi
     560:      	movl	$0x1, %eax
     565:      	callq	*%rax
     567:      	testq	%rax, %rax
     56a:      	je	0x573 <execve_send+0x2b3>
     56c:      	cmpq	$0x0, 0x8(%rax)
     571:      	jne	0x5ed <execve_send+0x32d>
     573:      	movl	$0xb00, %edx            # imm = 0xB00
     578:      	movq	(%rsp), %rcx
     57c:      	addq	%rdx, %rcx
     57f:      	movq	%rsp, %rdi
     582:      	movl	$0x8, %esi
     587:      	movl	$0x71, %eax
     58c:      	addq	(%rsp), %rdx
     590:      	movl	$0x8, %esi
     595:      	callq	*%rax
     597:      	movq	(%rsp), %rcx
     59b:      	testq	%rcx, %rcx
     59e:      	je	0x5fc <execve_send+0x33c>
     5a0:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     5a7:      	leaq	0xc(%rsp), %rdi
     5ac:      	movl	$0x4, %edx
     5b1:      	movl	$0x71, %eax
     5b6:      	movl	$0xaf4, %edx            # imm = 0xAF4
     5bb:      	addq	(%rsp), %rdx
     5bf:      	movl	$0x4, %esi
     5c4:      	callq	*%rax
     5c6:      	movl	0xc(%rsp), %eax
     5ca:      	movl	%eax, 0x10(%rsp)
     5ce:      	movq	(%rip), %rdi            # 0x5d5 <execve_send+0x315>
     5d5:      	leaq	0x10(%rsp), %rsi
     5da:      	movl	$0x1, %eax
     5df:      	callq	*%rax
     5e1:      	testq	%rax, %rax
     5e4:      	je	0x5fc <execve_send+0x33c>
     5e6:      	cmpq	$0x0, 0x8(%rax)
     5eb:      	je	0x5fc <execve_send+0x33c>
     5ed:      	movq	0x370(%rax), %rax
     5f4:      	orq	%rax, 0x370(%r12)
     5fc:      	movq	(%rip), %rdi            # 0x603 <execve_send+0x343>
     603:      	movl	$0x1, %eax
     608:      	movq	%r15, %rsi
     60b:      	callq	*%rax
     60d:      	testq	%rax, %rax
     610:      	je	0x61d <execve_send+0x35d>
     612:      	movq	(%rax), %rax
     615:      	orq	%rax, 0x370(%r12)
     61d:      	movb	$0x0, 0x1(%r14)
     622:      	movl	0x140(%r14), %eax
     629:      	cmpl	$0x1580, %eax           # imm = 0x1580
     62e:      	movl	$0x1580, %r8d           # imm = 0x1580
     634:      	cmovbl	%eax, %r8d
     638:      	addl	$0x140, %r8d            # imm = 0x140
     63f:      	movq	(%rip), %rsi            # 0x646 <execve_send+0x386>
     646:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     64b:      	movl	$0x19, %eax
     650:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     655:      	movq	%rbx, %rdi
     658:      	movq	%r14, %rcx
     65b:      	callq	*%rax
     65d:      	testq	%rax, %rax
     660:      	jns	0x6ea <execve_send+0x42a>
     666:      	movq	%rax, %rbx
     669:      	movl	$0x0, (%rsp)
     670:      	movq	(%rip), %rdi            # 0x677 <execve_send+0x3b7>
     677:      	movq	%rsp, %rsi
     67a:      	movl	$0x1, %eax
     67f:      	callq	*%rax
     681:      	testq	%rax, %rax
     684:      	je	0x6ea <execve_send+0x42a>
     686:      	cmpq	$-0xc, %rbx
     68a:      	jg	0x6a6 <execve_send+0x3e6>
     68c:      	cmpq	$-0x1c, %rbx
     690:      	je	0x6c0 <execve_send+0x400>
     692:      	cmpq	$-0x16, %rbx
     696:      	je	0x6d8 <execve_send+0x418>
     698:      	cmpq	$-0x10, %rbx
     69c:      	jne	0x6d0 <execve_send+0x410>
     69e:      	addq	$0x130, %rax            # imm = 0x130
     6a4:      	jmp	0x6e6 <execve_send+0x426>
     6a6:      	cmpq	$-0xb, %rbx
     6aa:      	je	0x6c8 <execve_send+0x408>
     6ac:      	cmpq	$-0x7, %rbx
     6b0:      	je	0x6e0 <execve_send+0x420>
     6b2:      	cmpq	$-0x2, %rbx
     6b6:      	jne	0x6d0 <execve_send+0x410>
     6b8:      	addq	$0x120, %rax            # imm = 0x120
     6be:      	jmp	0x6e6 <execve_send+0x426>
     6c0:      	addq	$0x140, %rax            # imm = 0x140
     6c6:      	jmp	0x6e6 <execve_send+0x426>
     6c8:      	addq	$0x148, %rax            # imm = 0x148
     6ce:      	jmp	0x6e6 <execve_send+0x426>
     6d0:      	addq	$0x118, %rax            # imm = 0x118
     6d6:      	jmp	0x6e6 <execve_send+0x426>
     6d8:      	addq	$0x138, %rax            # imm = 0x138
     6de:      	jmp	0x6e6 <execve_send+0x426>
     6e0:      	addq	$0x128, %rax            # imm = 0x128
     6e6:      	lock
     6e7:      	incq	(%rax)
     6ea:      	xorl	%eax, %eax
     6ec:      	addq	$0x18, %rsp
     6f0:      	popq	%rbx
     6f1:      	popq	%r12
     6f3:      	popq	%r14
     6f5:      	popq	%r15
     6f7:      	retq

Disassembly of section tracepoint/sys_execve:

0000000000000000 <event_execve>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xc8, %rsp
      11:      	movq	%rdi, %r15
      14:      	movl	$0x23, %eax
      19:      	callq	*%rax
      1b:      	movq	%rax, %rbp
      1e:      	movzwl	0x8(%r15), %r12d
      23:      	movl	$0x0, 0xa8(%rsp)
      2e:      	movq	(%rip), %rdi            # 0x35 <event_execve+0x35>
      35:      	leaq	0xa8(%rsp), %rsi
      3d:      	movl	$0x1, %eax
      42:      	callq	*%rax
      44:      	testq	%rax, %rax
      47:      	je	0x2299 <event_execve+0x2299>
      4d:      	movq	%rax, %r14
      50:      	movl	$0xe, %eax
      55:      	callq	*%rax
      57:      	movq	%rax, %r13
      5a:      	movl	$0x23, %eax
      5f:      	callq	*%rax
      61:      	movq	%rax, %rcx
      64:      	movq	%rax, 0x28(%rsp)
      69:      	addq	$0xb00, %rcx            # imm = 0xB00
      70:      	leaq	0x28(%rsp), %rdi
      75:      	movl	$0x8, %edx
      7a:      	movl	$0x71, %eax
      7f:      	movl	$0xb00, %edx            # imm = 0xB00
      84:      	addq	0x28(%rsp), %rdx
      89:      	movl	$0x8, %esi
      8e:      	callq	*%rax
      90:      	movq	0x28(%rsp), %rcx
      95:      	testq	%rcx, %rcx
      98:      	je	0x289 <event_execve+0x289>
      9e:      	addq	$0xaf4, %rcx            # imm = 0xAF4
      a5:      	movq	%rsp, %rdi
      a8:      	movl	$0x4, %edx
      ad:      	movl	$0x71, %eax
      b2:      	movl	$0xaf4, %edx            # imm = 0xAF4
      b7:      	addq	0x28(%rsp), %rdx
      bc:      	movl	$0x4, %esi
      c1:      	callq	*%rax
      c3:      	movl	(%rsp), %eax
      c6:      	movl	%eax, 0x8(%rsp)
      ca:      	movq	(%rip), %rdi            # 0xd1 <event_execve+0xd1>
      d1:      	leaq	0x8(%rsp), %rsi
      d6:      	movl	$0x1, %eax
      db:      	callq	*%rax
      dd:      	testq	%rax, %rax
      e0:      	je	0xed <event_execve+0xed>
      e2:      	cmpq	$0x0, 0x8(%rax)
      e7:      	jne	0x270 <event_execve+0x270>
      ed:      	movl	$0xb00, %edx            # imm = 0xB00
      f2:      	movq	0x28(%rsp), %rcx
      f7:      	addq	%rdx, %rcx
      fa:      	leaq	0x28(%rsp), %rdi
      ff:      	movl	$0x8, %esi
     104:      	movl	$0x71, %eax
     109:      	addq	0x28(%rsp), %rdx
     10e:      	movl	$0x8, %esi
     113:      	callq	*%rax
     115:      	movq	0x28(%rsp), %rcx
     11a:      	testq	%rcx, %rcx
     11d:      	je	0x289 <event_execve+0x289>
     123:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     12a:      	movq	%rsp, %rdi
     12d:      	movl	$0x4, %edx
     132:      	movl	$0x71, %eax
     137:      	movl	$0xaf4, %edx            # imm = 0xAF4
     13c:      	addq	0x28(%rsp), %rdx
     141:      	movl	$0x4, %esi
     146:      	callq	*%rax
     148:      	movl	(%rsp), %eax
     14b:      	movl	%eax, 0x8(%rsp)
     14f:      	movq	(%rip), %rdi            # 0x156 <event_execve+0x156>
     156:      	leaq	0x8(%rsp), %rsi
     15b:      	movl	$0x1, %eax
     160:      	callq	*%rax
     162:      	testq	%rax, %rax
     165:      	je	0x172 <event_execve+0x172>
     167:      	cmpq	$0x0, 0x8(%rax)
     16c:      	jne	0x270 <event_execve+0x270>
     172:      	movl	$0xb00, %edx            # imm = 0xB00
     177:      	movq	0x28(%rsp), %rcx
     17c:      	addq	%rdx, %rcx
     17f:      	leaq	0x28(%rsp), %rdi
     184:      	movl	$0x8, %esi
     189:      	movl	$0x71, %eax
     18e:      	addq	0x28(%rsp), %rdx
     193:      	movl	$0x8, %esi
     198:      	callq	*%rax
     19a:      	movq	0x28(%rsp), %rcx
     19f:      	testq	%rcx, %rcx
     1a2:      	je	0x289 <event_execve+0x289>
     1a8:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     1af:      	movq	%rsp, %rdi
     1b2:      	movl	$0x4, %edx
     1b7:      	movl	$0x71, %eax
     1bc:      	movl	$0xaf4, %edx            # imm = 0xAF4
     1c1:      	addq	0x28(%rsp), %rdx
     1c6:      	movl	$0x4, %esi
     1cb:      	callq	*%rax
     1cd:      	movl	(%rsp), %eax
     1d0:      	movl	%eax, 0x8(%rsp)
     1d4:      	movq	(%rip), %rdi            # 0x1db <event_execve+0x1db>
     1db:      	leaq	0x8(%rsp), %rsi
     1e0:      	movl	$0x1, %eax
     1e5:      	callq	*%rax
     1e7:      	testq	%rax, %rax
     1ea:      	je	0x1f3 <event_execve+0x1f3>
     1ec:      	cmpq	$0x0, 0x8(%rax)
     1f1:      	jne	0x270 <event_execve+0x270>
     1f3:      	movl	$0xb00, %edx            # imm = 0xB00
     1f8:      	movq	0x28(%rsp), %rcx
     1fd:      	addq	%rdx, %rcx
     200:      	leaq	0x28(%rsp), %rdi
     205:      	movl	$0x8, %esi
     20a:      	movl	$0x71, %eax
     20f:      	addq	0x28(%rsp), %rdx
     214:      	movl	$0x8, %esi
     219:      	callq	*%rax
     21b:      	movq	0x28(%rsp), %rcx
     220:      	testq	%rcx, %rcx
     223:      	je	0x289 <event_execve+0x289>
     225:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     22c:      	movq	%rsp, %rdi
     22f:      	movl	$0x4, %edx
     234:      	movl	$0x71, %eax
     239:      	movl	$0xaf4, %edx            # imm = 0xAF4
     23e:      	addq	0x28(%rsp), %rdx
     243:      	movl	$0x4, %esi
     248:      	callq	*%rax
     24a:      	movl	(%rsp), %eax
     24d:      	movl	%eax, 0x8(%rsp)
     251:      	movq	(%rip), %rdi            # 0x258 <event_execve+0x258>
     258:      	leaq	0x8(%rsp), %rsi
     25d:      	movl	$0x1, %eax
     262:      	callq	*%rax
     264:      	testq	%rax, %rax
     267:      	je	0x289 <event_execve+0x289>
     269:      	cmpq	$0x0, 0x8(%rax)
     26e:      	je	0x289 <event_execve+0x289>
     270:      	movq	(%rax), %rcx
     273:      	movq	0x8(%rax), %rax
     277:      	movq	%rax, 0xa8(%r14)
     27e:      	movq	%rcx, 0xa0(%r14)
     285:      	xorl	%eax, %eax
     287:      	jmp	0x2ec <event_execve+0x2ec>
     289:      	leaq	0xb00(%rbp), %rdx
     290:      	leaq	0x28(%rsp), %rdi
     295:      	movl	$0x8, %ecx
     29a:      	movl	$0x71, %eax
     29f:      	movl	$0x8, %esi
     2a4:      	callq	*%rax
     2a6:      	movq	0x28(%rsp), %rdx
     2ab:      	testq	%rdx, %rdx
     2ae:      	je	0x2d3 <event_execve+0x2d3>
     2b0:      	addq	$0xaf4, %rdx            # imm = 0xAF4
     2b7:      	leaq	0x28(%rsp), %rdi
     2bc:      	movl	$0x4, %ecx
     2c1:      	movl	$0x71, %eax
     2c6:      	movl	$0x4, %esi
     2cb:      	callq	*%rax
     2cd:      	movl	0x28(%rsp), %eax
     2d1:      	jmp	0x2d5 <event_execve+0x2d5>
     2d3:      	xorl	%eax, %eax
     2d5:      	movl	%eax, 0xa0(%r14)
     2dc:      	movq	$0x0, 0xa8(%r14)
     2e7:      	movl	$0x40, %eax
     2ec:      	movq	%rax, 0xb0(%r14)
     2f3:      	movl	$0x1, 0x15c(%r14)
     2fe:      	movq	%r13, %rax
     301:      	shrq	$0x20, %rax
     305:      	movq	$0x0, 0x178(%r14)
     310:      	movl	%eax, 0x144(%r14)
     317:      	movl	%r13d, 0x148(%r14)
     31e:      	movl	$0x23, %eax
     323:      	callq	*%rax
     325:      	leaq	0x60(%rax), %rdx
     329:      	leaq	0x8(%rsp), %rdi
     32e:      	movl	$0x8, %ecx
     333:      	movl	$0x71, %eax
     338:      	movl	$0x8, %esi
     33d:      	callq	*%rax
     33f:      	movq	0x8(%rsp), %rcx
     344:      	xorl	%ebx, %ebx
     346:      	testq	%rcx, %rcx
     349:      	je	0x3b4 <event_execve+0x3b4>
     34b:      	addq	$0x4, %rcx
     34f:      	movq	%rsp, %rdi
     352:      	movl	$0x4, %edx
     357:      	movl	$0x71, %eax
     35c:      	movq	0x8(%rsp), %rdx
     361:      	addq	$0x4, %rdx
     365:      	movl	$0x4, %esi
     36a:      	callq	*%rax
     36c:      	movl	(%rsp), %eax
     36f:      	testl	%eax, %eax
     371:      	je	0x3b4 <event_execve+0x3b4>
     373:      	movq	0x8(%rsp), %rcx
     378:      	shll	$0x4, %eax
     37b:      	addq	%rax, %rcx
     37e:      	addq	$0x80, %rcx
     385:      	leaq	0x28(%rsp), %rdi
     38a:      	movl	$0x10, %edx
     38f:      	movl	$0x71, %eax
     394:      	movq	0x8(%rsp), %rcx
     399:      	movl	(%rsp), %edx
     39c:      	shll	$0x4, %edx
     39f:      	addq	%rcx, %rdx
     3a2:      	addq	$0x80, %rdx
     3a9:      	movl	$0x10, %esi
     3ae:      	callq	*%rax
     3b0:      	movl	0x28(%rsp), %ebx
     3b4:      	movl	%ebx, 0x14c(%r14)
     3bb:      	movl	$0x5, %eax
     3c0:      	callq	*%rax
     3c2:      	movq	%rax, 0x170(%r14)
     3c9:      	movl	$0x40, 0x140(%r14)
     3d4:      	movl	$0x23, %eax
     3d9:      	callq	*%rax
     3db:      	movq	$0x0, 0x28(%rsp)
     3e4:      	testq	%rax, %rax
     3e7:      	je	0x40d <event_execve+0x40d>
     3e9:      	movq	%rax, %rdx
     3ec:      	addq	$0x70, %rdx
     3f0:      	leaq	0x28(%rsp), %rdi
     3f5:      	movl	$0x8, %ecx
     3fa:      	movl	$0x4, %eax
     3ff:      	movl	$0x8, %esi
     404:      	callq	*%rax
     406:      	movq	0x28(%rsp), %rax
     40b:      	jmp	0x40f <event_execve+0x40f>
     40d:      	xorl	%eax, %eax
     40f:      	movl	%eax, 0x158(%r14)
     416:      	movq	%r13, 0x28(%rsp)
     41b:      	movq	(%rip), %rdi            # 0x422 <event_execve+0x422>
     422:      	leaq	0x28(%rsp), %rsi
     427:      	movl	$0x1, %eax
     42c:      	addq	%r15, %r12
     42f:      	callq	*%rax
     431:      	testq	%rax, %rax
     434:      	je	0x495 <event_execve+0x495>
     436:      	movl	(%rax), %ecx
     438:      	movl	%ecx, 0x150(%r14)
     43f:      	movq	0x8(%rax), %rcx
     443:      	movq	%rcx, 0x168(%r14)
     44a:      	movl	0x4(%rax), %eax
     44d:      	movl	%eax, 0x160(%r14)
     454:      	movq	%r13, 0x28(%rsp)
     459:      	movq	(%rip), %rdi            # 0x460 <event_execve+0x460>
     460:      	leaq	0x28(%rsp), %rsi
     465:      	movl	$0x3, %eax
     46a:      	callq	*%rax
     46c:      	testl	%eax, %eax
     46e:      	je	0x4b8 <event_execve+0x4b8>
     470:      	movl	$0x2, 0x8(%rsp)
     478:      	movq	(%rip), %rdi            # 0x47f <event_execve+0x47f>
     47f:      	leaq	0x8(%rsp), %rsi
     484:      	movl	$0x1, %eax
     489:      	callq	*%rax
     48b:      	testq	%rax, %rax
     48e:      	je	0x4db <event_execve+0x4db>
     490:      	incq	(%rax)
     493:      	jmp	0x4db <event_execve+0x4db>
     495:      	movl	$0x0, 0x150(%r14)
     4a0:      	movq	$0x0, 0x168(%r14)
     4ab:      	movl	$0x0, 0x160(%r14)
     4b6:      	jmp	0x4db <event_execve+0x4db>
     4b8:      	movl	$0x0, 0x8(%rsp)
     4c0:      	movq	(%rip), %rdi            # 0x4c7 <event_execve+0x4c7>
     4c7:      	leaq	0x8(%rsp), %rsi
     4cc:      	movl	$0x1, %eax
     4d1:      	callq	*%rax
     4d3:      	testq	%rax, %rax
     4d6:      	je	0x4db <event_execve+0x4db>
     4d8:      	decq	(%rax)
     4db:      	leaq	0x180(%r14), %rdi
     4e2:      	movl	$0xff, %ecx
     4e7:      	movl	$0x2d, %eax
     4ec:      	movl	$0xff, %esi
     4f1:      	movq	%r12, %rdx
     4f4:      	callq	*%rax
     4f6:      	testl	%eax, %eax
     4f8:      	movq	%r15, 0x78(%rsp)
     4fd:      	movq	%rbp, 0xb0(%rsp)
     505:      	js	0x655 <event_execve+0x655>
     50b:      	je	0x661 <event_execve+0x661>
     511:      	cmpl	$0xff, %eax
     516:      	jne	0x668 <event_execve+0x668>
     51c:      	movl	$0x0, 0x8(%rsp)
     524:      	movq	(%rip), %rdi            # 0x52b <event_execve+0x52b>
     52b:      	leaq	0x8(%rsp), %rsi
     530:      	movl	$0x1, %eax
     535:      	callq	*%rax
     537:      	testq	%rax, %rax
     53a:      	je	0x655 <event_execve+0x655>
     540:      	movq	%rax, %rbp
     543:      	movq	%rax, %r13
     546:      	movl	$0x18, (%rbp)
     54d:      	movl	$0xe, %eax
     552:      	callq	*%rax
     554:      	leaq	0x10(%rbp), %rbx
     558:      	movq	%rax, 0x10(%rbp)
     55c:      	cmpq	$-0x16, %rax
     560:      	jne	0x589 <event_execve+0x589>
     562:      	movq	0x78(%rsp), %rax
     567:      	leaq	0x20(%rax), %rdx
     56b:      	leaq	0x28(%rsp), %rdi
     570:      	movl	$0x8, %ecx
     575:      	movl	$0x4, %eax
     57a:      	movl	$0x8, %esi
     57f:      	callq	*%rax
     581:      	movq	0x28(%rsp), %rax
     586:      	movq	%rax, (%rbx)
     589:      	movl	$0x5, %eax
     58e:      	callq	*%rax
     590:      	movq	%rax, 0x18(%r13)
     594:      	movq	(%rbx), %rax
     597:      	movq	0x8(%rbx), %rcx
     59b:      	movq	%rax, 0x190(%r14)
     5a2:      	movq	%rcx, 0x198(%r14)
     5a9:      	addq	$0x20, %rbp
     5ad:      	movl	$0x7fdf, %ecx           # imm = 0x7FDF
     5b2:      	movl	$0x2d, %eax
     5b7:      	movq	%rbp, %rdi
     5ba:      	movl	$0x7fdf, %esi           # imm = 0x7FDF
     5bf:      	movq	%r12, %rdx
     5c2:      	callq	*%rax
     5c4:      	movq	%rax, %rbx
     5c7:      	testq	%rax, %rax
     5ca:      	js	0x7c9 <event_execve+0x7c9>
     5d0:      	je	0x673 <event_execve+0x673>
     5d6:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     5db:      	leal	0x1f(%rbx), %r8d
     5df:      	andl	$0x7fff, %r8d           # imm = 0x7FFF
     5e6:      	movl	%r8d, 0x4(%r13)
     5ea:      	movq	(%rip), %rsi            # 0x5f1 <event_execve+0x5f1>
     5f1:      	movl	$0x19, %eax
     5f6:      	movq	0x78(%rsp), %rdi
     5fb:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     600:      	movq	%r13, %rcx
     603:      	callq	*%rax
     605:      	testq	%rax, %rax
     608:      	jns	0x6c0 <event_execve+0x6c0>
     60e:      	movq	%rax, %r15
     611:      	movl	$0x0, 0x28(%rsp)
     619:      	movq	(%rip), %rdi            # 0x620 <event_execve+0x620>
     620:      	leaq	0x28(%rsp), %rsi
     625:      	movl	$0x1, %eax
     62a:      	callq	*%rax
     62c:      	testq	%rax, %rax
     62f:      	je	0x6c0 <event_execve+0x6c0>
     635:      	cmpq	$-0xc, %r15
     639:      	jg	0x67c <event_execve+0x67c>
     63b:      	cmpq	$-0x1c, %r15
     63f:      	je	0x696 <event_execve+0x696>
     641:      	cmpq	$-0x16, %r15
     645:      	je	0x6ae <event_execve+0x6ae>
     647:      	cmpq	$-0x10, %r15
     64b:      	jne	0x6a6 <event_execve+0x6a6>
     64d:      	addq	$0x558, %rax            # imm = 0x558
     653:      	jmp	0x6bc <event_execve+0x6bc>
     655:      	xorl	%ecx, %ecx
     657:      	movl	$0x100, %eax            # imm = 0x100
     65c:      	jmp	0x7fa <event_execve+0x7fa>
     661:      	movl	%eax, %ecx
     663:      	jmp	0x7fa <event_execve+0x7fa>
     668:      	movl	%eax, %ecx
     66a:      	decl	%ecx
     66c:      	xorl	%eax, %eax
     66e:      	jmp	0x7fa <event_execve+0x7fa>
     673:      	xorl	%eax, %eax
     675:      	xorl	%ecx, %ecx
     677:      	jmp	0x7d7 <event_execve+0x7d7>
     67c:      	cmpq	$-0xb, %r15
     680:      	je	0x69e <event_execve+0x69e>
     682:      	cmpq	$-0x7, %r15
     686:      	je	0x6b6 <event_execve+0x6b6>
     688:      	cmpq	$-0x2, %r15
     68c:      	jne	0x6a6 <event_execve+0x6a6>
     68e:      	addq	$0x548, %rax            # imm = 0x548
     694:      	jmp	0x6bc <event_execve+0x6bc>
     696:      	addq	$0x568, %rax            # imm = 0x568
     69c:      	jmp	0x6bc <event_execve+0x6bc>
     69e:      	addq	$0x570, %rax            # imm = 0x570
     6a4:      	jmp	0x6bc <event_execve+0x6bc>
     6a6:      	addq	$0x540, %rax            # imm = 0x540
     6ac:      	jmp	0x6bc <event_execve+0x6bc>
     6ae:      	addq	$0x560, %rax            # imm = 0x560
     6b4:      	jmp	0x6bc <event_execve+0x6bc>
     6b6:      	addq	$0x550, %rax            # imm = 0x550
     6bc:      	lock
     6bd:      	incq	(%rax)
     6c0:      	leaq	-0x1(%rbx), %r15
     6c4:      	cmpq	$0x7fdf, %rbx           # imm = 0x7FDF
     6cb:      	jne	0x77a <event_execve+0x77a>
     6d1:      	addq	%r15, %r12
     6d4:      	movl	$0x7fdf, %ecx           # imm = 0x7FDF
     6d9:      	movl	$0x2d, %eax
     6de:      	movq	%rbp, %rdi
     6e1:      	movl	$0x7fdf, %esi           # imm = 0x7FDF
     6e6:      	movq	%r12, %rdx
     6e9:      	callq	*%rax
     6eb:      	movq	%rax, %rbx
     6ee:      	testq	%rax, %rax
     6f1:      	js	0x7c9 <event_execve+0x7c9>
     6f7:      	movq	0x78(%rsp), %rdi
     6fc:      	je	0x77a <event_execve+0x77a>
     6fe:      	leal	0x1f(%rbx), %r8d
     702:      	andl	$0x7fff, %r8d           # imm = 0x7FFF
     709:      	movl	%r8d, 0x4(%r13)
     70d:      	movq	(%rip), %rsi            # 0x714 <event_execve+0x714>
     714:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     719:      	movl	$0x19, %eax
     71e:      	movq	%rbx, %r12
     721:      	decq	%r12
     724:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     729:      	movq	%r13, %rcx
     72c:      	callq	*%rax
     72e:      	testq	%rax, %rax
     731:      	jns	0x7c3 <event_execve+0x7c3>
     737:      	movq	%rax, %rbx
     73a:      	movl	$0x0, 0x28(%rsp)
     742:      	movq	(%rip), %rdi            # 0x749 <event_execve+0x749>
     749:      	leaq	0x28(%rsp), %rsi
     74e:      	movl	$0x1, %eax
     753:      	callq	*%rax
     755:      	testq	%rax, %rax
     758:      	je	0x7c3 <event_execve+0x7c3>
     75a:      	cmpq	$-0xc, %rbx
     75e:      	jg	0x77f <event_execve+0x77f>
     760:      	cmpq	$-0x1c, %rbx
     764:      	je	0x799 <event_execve+0x799>
     766:      	cmpq	$-0x16, %rbx
     76a:      	je	0x7b1 <event_execve+0x7b1>
     76c:      	cmpq	$-0x10, %rbx
     770:      	jne	0x7a9 <event_execve+0x7a9>
     772:      	addq	$0x558, %rax            # imm = 0x558
     778:      	jmp	0x7bf <event_execve+0x7bf>
     77a:      	movq	%r15, %rbx
     77d:      	jmp	0x7c9 <event_execve+0x7c9>
     77f:      	cmpq	$-0xb, %rbx
     783:      	je	0x7a1 <event_execve+0x7a1>
     785:      	cmpq	$-0x7, %rbx
     789:      	je	0x7b9 <event_execve+0x7b9>
     78b:      	cmpq	$-0x2, %rbx
     78f:      	jne	0x7a9 <event_execve+0x7a9>
     791:      	addq	$0x548, %rax            # imm = 0x548
     797:      	jmp	0x7bf <event_execve+0x7bf>
     799:      	addq	$0x568, %rax            # imm = 0x568
     79f:      	jmp	0x7bf <event_execve+0x7bf>
     7a1:      	addq	$0x570, %rax            # imm = 0x570
     7a7:      	jmp	0x7bf <event_execve+0x7bf>
     7a9:      	addq	$0x540, %rax            # imm = 0x540
     7af:      	jmp	0x7bf <event_execve+0x7bf>
     7b1:      	addq	$0x560, %rax            # imm = 0x560
     7b7:      	jmp	0x7bf <event_execve+0x7bf>
     7b9:      	addq	$0x550, %rax            # imm = 0x550
     7bf:      	lock
     7c0:      	incq	(%rax)
     7c3:      	addq	%r15, %r12
     7c6:      	movq	%r12, %rbx
     7c9:      	movl	%ebx, %eax
     7cb:      	sarl	$0x1f, %eax
     7ce:      	andl	%ebx, %eax
     7d0:      	xorl	%ecx, %ecx
     7d2:      	testl	%ebx, %ebx
     7d4:      	cmovgl	%ebx, %ecx
     7d7:      	movl	%eax, 0x180(%r14)
     7de:      	movq	$0x0, 0x184(%r14)
     7e9:      	movl	%ecx, 0x18c(%r14)
     7f0:      	movl	$0x20, %ecx
     7f5:      	movl	$0x800000, %eax         # imm = 0x800000
     7fa:      	movw	%cx, 0x178(%r14)
     802:      	orl	%eax, 0x15c(%r14)
     809:      	addl	%ecx, 0x140(%r14)
     810:      	movl	$0x23, %eax
     815:      	callq	*%rax
     817:      	movl	$0x0, 0xa0(%rsp)
     822:      	leaq	0xa78(%rax), %rdx
     829:      	leaq	0x20(%rsp), %rdi
     82e:      	movl	$0x8, %ecx
     833:      	movl	$0x4, %eax
     838:      	movl	$0x8, %esi
     83d:      	callq	*%rax
     83f:      	testq	%rax, %rax
     842:      	je	0x8a1 <event_execve+0x8a1>
     844:      	negl	%eax
     846:      	movw	%ax, 0x28(%rsp)
     84b:      	movw	$0x9, 0x2a(%rsp)
     852:      	movabsq	$0x400000042, %rax      # imm = 0x400000042
     85c:      	movq	%rax, 0x2c(%rsp)
     861:      	movq	(%rip), %rdi            # 0x868 <event_execve+0x868>
     868:      	leaq	0x28(%rsp), %rsi
     86d:      	movl	$0x1, %eax
     872:      	callq	*%rax
     874:      	testq	%rax, %rax
     877:      	je	0x87d <event_execve+0x87d>
     879:      	incl	(%rax)
     87b:      	jmp	0x8a1 <event_execve+0x8a1>
     87d:      	movl	$0x1, 0x8(%rsp)
     885:      	movq	(%rip), %rdi            # 0x88c <event_execve+0x88c>
     88c:      	xorl	%ecx, %ecx
     88e:      	leaq	0x28(%rsp), %rsi
     893:      	leaq	0x8(%rsp), %rdx
     898:      	movl	$0x2, %eax
     89d:      	xorl	%ecx, %ecx
     89f:      	callq	*%rax
     8a1:      	leaq	0x140(%r14), %r15
     8a8:      	movq	0x20(%rsp), %rcx
     8ad:      	xorl	%ebp, %ebp
     8af:      	movl	$0x0, %r12d
     8b5:      	testq	%rcx, %rcx
     8b8:      	je	0x1234 <event_execve+0x1234>
     8be:      	addq	$0x2b8, %rcx            # imm = 0x2B8
     8c5:      	leaq	0x8(%rsp), %rdi
     8ca:      	movl	$0x8, %edx
     8cf:      	movl	$0x4, %eax
     8d4:      	movl	$0x2b8, %edx            # imm = 0x2B8
     8d9:      	addq	0x20(%rsp), %rdx
     8de:      	movl	$0x8, %esi
     8e3:      	callq	*%rax
     8e5:      	testq	%rax, %rax
     8e8:      	je	0x944 <event_execve+0x944>
     8ea:      	negl	%eax
     8ec:      	movw	%ax, 0x28(%rsp)
     8f1:      	movw	$0x9, 0x2a(%rsp)
     8f8:      	movabsq	$0x400000047, %rax      # imm = 0x400000047
     902:      	movq	%rax, 0x2c(%rsp)
     907:      	movq	(%rip), %rdi            # 0x90e <event_execve+0x90e>
     90e:      	leaq	0x28(%rsp), %rsi
     913:      	movl	$0x1, %eax
     918:      	callq	*%rax
     91a:      	testq	%rax, %rax
     91d:      	je	0x923 <event_execve+0x923>
     91f:      	incl	(%rax)
     921:      	jmp	0x944 <event_execve+0x944>
     923:      	movl	$0x1, (%rsp)
     92a:      	movq	(%rip), %rdi            # 0x931 <event_execve+0x931>
     931:      	xorl	%ecx, %ecx
     933:      	leaq	0x28(%rsp), %rsi
     938:      	movq	%rsp, %rdx
     93b:      	movl	$0x2, %eax
     940:      	xorl	%ecx, %ecx
     942:      	callq	*%rax
     944:      	movl	$0x2c0, %edx            # imm = 0x2C0
     949:      	movq	0x20(%rsp), %rcx
     94e:      	addq	%rdx, %rcx
     951:      	movq	%rsp, %rdi
     954:      	movl	$0x8, %esi
     959:      	movl	$0x4, %eax
     95e:      	addq	0x20(%rsp), %rdx
     963:      	movl	$0x8, %esi
     968:      	callq	*%rax
     96a:      	testq	%rax, %rax
     96d:      	je	0x9aa <event_execve+0x9aa>
     96f:      	negl	%eax
     971:      	movw	%ax, 0x28(%rsp)
     976:      	movw	$0x9, 0x2a(%rsp)
     97d:      	movabsq	$0x400000048, %rax      # imm = 0x400000048
     987:      	movq	%rax, 0x2c(%rsp)
     98c:      	movq	(%rip), %rdi            # 0x993 <event_execve+0x993>
     993:      	leaq	0x28(%rsp), %rsi
     998:      	movl	$0x1, %eax
     99d:      	callq	*%rax
     99f:      	testq	%rax, %rax
     9a2:      	je	0xaf7 <event_execve+0xaf7>
     9a8:      	incl	(%rax)
     9aa:      	cmpq	$0x0, 0x8(%rsp)
     9b0:      	movl	$0x0, %r12d
     9b6:      	je	0x1234 <event_execve+0x1234>
     9bc:      	cmpq	$0x0, (%rsp)
     9c1:      	movl	$0x0, %r12d
     9c7:      	je	0x1234 <event_execve+0x1234>
     9cd:      	movq	(%rip), %rdi            # 0x9d4 <event_execve+0x9d4>
     9d4:      	leaq	0xa0(%rsp), %rsi
     9dc:      	movl	$0x1, %eax
     9e1:      	callq	*%rax
     9e3:      	movl	$0x0, %r12d
     9e9:      	testq	%rax, %rax
     9ec:      	je	0x1234 <event_execve+0x1234>
     9f2:      	movq	%rax, %rdi
     9f5:      	movq	0x8(%rsp), %rcx
     9fa:      	movl	$0x1000, %edx           # imm = 0x1000
     9ff:      	movl	$0x2d, %eax
     a04:      	movq	0x8(%rsp), %rdx
     a09:      	movl	$0x1000, %esi           # imm = 0x1000
     a0e:      	callq	*%rax
     a10:      	movl	$0x0, %r12d
     a16:      	testq	%rax, %rax
     a19:      	js	0x1234 <event_execve+0x1234>
     a1f:      	movq	%rax, %r13
     a22:      	movq	%r15, 0x90(%rsp)
     a2a:      	addq	0x8(%rsp), %r13
     a2f:      	movq	%r13, 0x8(%rsp)
     a34:      	movl	0x140(%r14), %ebx
     a3b:      	andl	$0x1ff, %ebx            # imm = 0x1FF
     a41:      	movq	(%rsp), %rax
     a45:      	movq	%rax, %r12
     a48:      	subq	%r13, %r12
     a4b:      	cmpq	$0x3ff, %r12            # imm = 0x3FF
     a52:      	ja	0xb32 <event_execve+0xb32>
     a58:      	leaq	(%r14,%rbx), %rdi
     a5c:      	addq	$0x140, %rdi            # imm = 0x140
     a63:      	movq	0x90(%rsp), %rcx
     a6b:      	subq	%rdi, %rcx
     a6e:      	addq	$0x400, %rcx            # imm = 0x400
     a75:      	cmpq	%rcx, %r12
     a78:      	jae	0xb32 <event_execve+0xb32>
     a7e:      	decl	%r12d
     a81:      	andl	$0x3ff, %r12d           # imm = 0x3FF
     a88:      	xorl	%ecx, %ecx
     a8a:      	cmpq	%r13, %rax
     a8d:      	cmovnel	%r12d, %ecx
     a91:      	movq	%rcx, %r12
     a94:      	movl	$0x4, %eax
     a99:      	movq	0x8(%rsp), %rdx
     a9e:      	movl	%r12d, %esi
     aa1:      	callq	*%rax
     aa3:      	testq	%rax, %rax
     aa6:      	je	0x1224 <event_execve+0x1224>
     aac:      	movq	%rax, %rbx
     aaf:      	negl	%eax
     ab1:      	movw	%ax, 0x28(%rsp)
     ab6:      	movw	$0x9, 0x2a(%rsp)
     abd:      	movabsq	$0x40000006c, %rax      # imm = 0x40000006C
     ac7:      	movq	%rax, 0x2c(%rsp)
     acc:      	movq	(%rip), %rdi            # 0xad3 <event_execve+0xad3>
     ad3:      	leaq	0x28(%rsp), %rsi
     ad8:      	movl	$0x1, %eax
     add:      	callq	*%rax
     adf:      	testq	%rax, %rax
     ae2:      	movq	0x90(%rsp), %r15
     aea:      	je	0x1107 <event_execve+0x1107>
     af0:      	incl	(%rax)
     af2:      	jmp	0x112b <event_execve+0x112b>
     af7:      	movl	$0x1, 0x70(%rsp)
     aff:      	movq	(%rip), %rdi            # 0xb06 <event_execve+0xb06>
     b06:      	xorl	%ecx, %ecx
     b08:      	leaq	0x28(%rsp), %rsi
     b0d:      	leaq	0x70(%rsp), %rdx
     b12:      	movl	$0x2, %eax
     b17:      	xorl	%ecx, %ecx
     b19:      	callq	*%rax
     b1b:      	cmpq	$0x0, 0x8(%rsp)
     b21:      	movl	$0x0, %r12d
     b27:      	jne	0x9bc <event_execve+0x9bc>
     b2d:      	jmp	0x1234 <event_execve+0x1234>
     b32:      	movl	$0x0, 0x70(%rsp)
     b3a:      	movq	(%rip), %rdi            # 0xb41 <event_execve+0xb41>
     b41:      	leaq	0x70(%rsp), %rsi
     b46:      	movl	$0x1, %eax
     b4b:      	callq	*%rax
     b4d:      	testq	%rax, %rax
     b50:      	je	0x10f4 <event_execve+0x10f4>
     b56:      	addq	%r14, %rbx
     b59:      	movq	%rbx, 0x98(%rsp)
     b61:      	movl	$0x18, (%rax)
     b67:      	movq	%rax, %rcx
     b6a:      	movl	$0xe, %eax
     b6f:      	movq	%rcx, %r15
     b72:      	callq	*%rax
     b74:      	leaq	0x10(%r15), %rbx
     b78:      	movq	%r15, 0x80(%rsp)
     b80:      	movq	%rax, 0x10(%r15)
     b84:      	cmpq	$-0x16, %rax
     b88:      	jne	0xbb1 <event_execve+0xbb1>
     b8a:      	movq	0x78(%rsp), %rax
     b8f:      	leaq	0x20(%rax), %rdx
     b93:      	leaq	0x28(%rsp), %rdi
     b98:      	movl	$0x8, %ecx
     b9d:      	movl	$0x4, %eax
     ba2:      	movl	$0x8, %esi
     ba7:      	callq	*%rax
     ba9:      	movq	0x28(%rsp), %rax
     bae:      	movq	%rax, (%rbx)
     bb1:      	movl	$0x5, %eax
     bb6:      	callq	*%rax
     bb8:      	movq	0x80(%rsp), %r15
     bc0:      	movq	%rax, 0x18(%r15)
     bc4:      	movq	(%rbx), %rax
     bc7:      	movq	0x8(%rbx), %rcx
     bcb:      	movq	0x98(%rsp), %rdx
     bd3:      	movq	%rax, 0x150(%rdx)
     bda:      	movq	%rcx, 0x158(%rdx)
     be1:      	testq	%r12, %r12
     be4:      	js	0x10fc <event_execve+0x10fc>
     bea:      	movq	$-0x1, 0x18(%rsp)
     bf3:      	cmpq	$0x7fe0, %r12           # imm = 0x7FE0
     bfa:      	movl	$0x7fe0, %ebx           # imm = 0x7FE0
     bff:      	cmovbq	%r12, %rbx
     c03:      	andl	$0x3fff, %ebx           # imm = 0x3FFF
     c09:      	movq	%r15, %rdi
     c0c:      	addq	$0x20, %rdi
     c10:      	movl	$0x4, %eax
     c15:      	movq	%rdi, 0x88(%rsp)
     c1d:      	movl	%ebx, %esi
     c1f:      	movq	%r13, %rdx
     c22:      	callq	*%rax
     c24:      	testl	%eax, %eax
     c26:      	js	0xc54 <event_execve+0xc54>
     c28:      	leal	0x20(%rbx), %r8d
     c2c:      	movl	%r8d, 0x4(%r15)
     c30:      	movq	(%rip), %rsi            # 0xc37 <event_execve+0xc37>
     c37:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     c3c:      	movl	$0x19, %eax
     c41:      	movq	0x78(%rsp), %rdi
     c46:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     c4b:      	movq	%r15, %rcx
     c4e:      	callq	*%rax
     c50:      	testl	%eax, %eax
     c52:      	jns	0xc57 <event_execve+0xc57>
     c54:      	movslq	%eax, %rbx
     c57:      	testl	%ebx, %ebx
     c59:      	js	0x1143 <event_execve+0x1143>
     c5f:      	movq	%r12, %rcx
     c62:      	movq	%r12, %rax
     c65:      	subq	%rbx, %rcx
     c68:      	je	0x11d4 <event_execve+0x11d4>
     c6e:      	js	0x1148 <event_execve+0x1148>
     c74:      	leaq	(%rbx,%r13), %rdx
     c78:      	cmpq	$0x7fe0, %rcx           # imm = 0x7FE0
     c7f:      	movl	$0x7fe0, %r15d          # imm = 0x7FE0
     c85:      	cmovbq	%rcx, %r15
     c89:      	andl	$0x3fff, %r15d          # imm = 0x3FFF
     c90:      	movl	$0x4, %eax
     c95:      	movq	0x88(%rsp), %rdi
     c9d:      	movl	%r15d, %esi
     ca0:      	callq	*%rax
     ca2:      	testl	%eax, %eax
     ca4:      	js	0xcd2 <event_execve+0xcd2>
     ca6:      	leal	0x20(%r15), %r8d
     caa:      	movq	0x80(%rsp), %rcx
     cb2:      	movl	%r8d, 0x4(%rcx)
     cb6:      	movq	(%rip), %rsi            # 0xcbd <event_execve+0xcbd>
     cbd:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     cc2:      	movl	$0x19, %eax
     cc7:      	movq	0x78(%rsp), %rdi
     ccc:      	callq	*%rax
     cce:      	testl	%eax, %eax
     cd0:      	jns	0xcd5 <event_execve+0xcd5>
     cd2:      	movslq	%eax, %r15
     cd5:      	testl	%r15d, %r15d
     cd8:      	js	0x2756 <event_execve+0x2756>
     cde:      	addq	%rbx, %r15
     ce1:      	movq	%r12, %rcx
     ce4:      	movq	%r12, %rax
     ce7:      	subq	%r15, %rcx
     cea:      	je	0x11d4 <event_execve+0x11d4>
     cf0:      	js	0x1148 <event_execve+0x1148>
     cf6:      	leaq	(%r15,%r13), %rdx
     cfa:      	cmpq	$0x7fe0, %rcx           # imm = 0x7FE0
     d01:      	movl	$0x7fe0, %ebx           # imm = 0x7FE0
     d06:      	cmovbq	%rcx, %rbx
     d0a:      	andl	$0x3fff, %ebx           # imm = 0x3FFF
     d10:      	movl	$0x4, %eax
     d15:      	movq	0x88(%rsp), %rdi
     d1d:      	movl	%ebx, %esi
     d1f:      	callq	*%rax
     d21:      	testl	%eax, %eax
     d23:      	js	0xd51 <event_execve+0xd51>
     d25:      	leal	0x20(%rbx), %r8d
     d29:      	movq	0x80(%rsp), %rcx
     d31:      	movl	%r8d, 0x4(%rcx)
     d35:      	movq	(%rip), %rsi            # 0xd3c <event_execve+0xd3c>
     d3c:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     d41:      	movl	$0x19, %eax
     d46:      	movq	0x78(%rsp), %rdi
     d4b:      	callq	*%rax
     d4d:      	testl	%eax, %eax
     d4f:      	jns	0xd54 <event_execve+0xd54>
     d51:      	movslq	%eax, %rbx
     d54:      	testl	%ebx, %ebx
     d56:      	js	0x1143 <event_execve+0x1143>
     d5c:      	addq	%r15, %rbx
     d5f:      	movq	%r12, %rcx
     d62:      	movq	%r12, %rax
     d65:      	subq	%rbx, %rcx
     d68:      	je	0x11d4 <event_execve+0x11d4>
     d6e:      	js	0x1148 <event_execve+0x1148>
     d74:      	leaq	(%rbx,%r13), %rdx
     d78:      	cmpq	$0x7fe0, %rcx           # imm = 0x7FE0
     d7f:      	movl	$0x7fe0, %r15d          # imm = 0x7FE0
     d85:      	cmovbq	%rcx, %r15
     d89:      	andl	$0x3fff, %r15d          # imm = 0x3FFF
     d90:      	movl	$0x4, %eax
     d95:      	movq	0x88(%rsp), %rdi
     d9d:      	movl	%r15d, %esi
     da0:      	callq	*%rax
     da2:      	testl	%eax, %eax
     da4:      	js	0xdd2 <event_execve+0xdd2>
     da6:      	leal	0x20(%r15), %r8d
     daa:      	movq	0x80(%rsp), %rcx
     db2:      	movl	%r8d, 0x4(%rcx)
     db6:      	movq	(%rip), %rsi            # 0xdbd <event_execve+0xdbd>
     dbd:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     dc2:      	movl	$0x19, %eax
     dc7:      	movq	0x78(%rsp), %rdi
     dcc:      	callq	*%rax
     dce:      	testl	%eax, %eax
     dd0:      	jns	0xdd5 <event_execve+0xdd5>
     dd2:      	movslq	%eax, %r15
     dd5:      	testl	%r15d, %r15d
     dd8:      	js	0x2756 <event_execve+0x2756>
     dde:      	addq	%rbx, %r15
     de1:      	movq	%r12, %rcx
     de4:      	movq	%r12, %rax
     de7:      	subq	%r15, %rcx
     dea:      	je	0x11d4 <event_execve+0x11d4>
     df0:      	js	0x1148 <event_execve+0x1148>
     df6:      	leaq	(%r15,%r13), %rdx
     dfa:      	cmpq	$0x7fe0, %rcx           # imm = 0x7FE0
     e01:      	movl	$0x7fe0, %ebx           # imm = 0x7FE0
     e06:      	cmovbq	%rcx, %rbx
     e0a:      	andl	$0x3fff, %ebx           # imm = 0x3FFF
     e10:      	movl	$0x4, %eax
     e15:      	movq	0x88(%rsp), %rdi
     e1d:      	movl	%ebx, %esi
     e1f:      	callq	*%rax
     e21:      	testl	%eax, %eax
     e23:      	js	0xe51 <event_execve+0xe51>
     e25:      	leal	0x20(%rbx), %r8d
     e29:      	movq	0x80(%rsp), %rcx
     e31:      	movl	%r8d, 0x4(%rcx)
     e35:      	movq	(%rip), %rsi            # 0xe3c <event_execve+0xe3c>
     e3c:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     e41:      	movl	$0x19, %eax
     e46:      	movq	0x78(%rsp), %rdi
     e4b:      	callq	*%rax
     e4d:      	testl	%eax, %eax
     e4f:      	jns	0xe54 <event_execve+0xe54>
     e51:      	movslq	%eax, %rbx
     e54:      	testl	%ebx, %ebx
     e56:      	js	0x1143 <event_execve+0x1143>
     e5c:      	addq	%r15, %rbx
     e5f:      	movq	%r12, %rcx
     e62:      	movq	%r12, %rax
     e65:      	subq	%rbx, %rcx
     e68:      	je	0x11d4 <event_execve+0x11d4>
     e6e:      	js	0x1148 <event_execve+0x1148>
     e74:      	leaq	(%rbx,%r13), %rdx
     e78:      	cmpq	$0x7fe0, %rcx           # imm = 0x7FE0
     e7f:      	movl	$0x7fe0, %r15d          # imm = 0x7FE0
     e85:      	cmovbq	%rcx, %r15
     e89:      	andl	$0x3fff, %r15d          # imm = 0x3FFF
     e90:      	movl	$0x4, %eax
     e95:      	movq	0x88(%rsp), %rdi
     e9d:      	movl	%r15d, %esi
     ea0:      	callq	*%rax
     ea2:      	testl	%eax, %eax
     ea4:      	js	0xed2 <event_execve+0xed2>
     ea6:      	leal	0x20(%r15), %r8d
     eaa:      	movq	0x80(%rsp), %rcx
     eb2:      	movl	%r8d, 0x4(%rcx)
     eb6:      	movq	(%rip), %rsi            # 0xebd <event_execve+0xebd>
     ebd:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     ec2:      	movl	$0x19, %eax
     ec7:      	movq	0x78(%rsp), %rdi
     ecc:      	callq	*%rax
     ece:      	testl	%eax, %eax
     ed0:      	jns	0xed5 <event_execve+0xed5>
     ed2:      	movslq	%eax, %r15
     ed5:      	testl	%r15d, %r15d
     ed8:      	js	0x2756 <event_execve+0x2756>
     ede:      	addq	%rbx, %r15
     ee1:      	movq	%r12, %rcx
     ee4:      	movq	%r12, %rax
     ee7:      	subq	%r15, %rcx
     eea:      	je	0x11d4 <event_execve+0x11d4>
     ef0:      	js	0x1148 <event_execve+0x1148>
     ef6:      	leaq	(%r15,%r13), %rdx
     efa:      	cmpq	$0x7fe0, %rcx           # imm = 0x7FE0
     f01:      	movl	$0x7fe0, %ebx           # imm = 0x7FE0
     f06:      	cmovbq	%rcx, %rbx
     f0a:      	andl	$0x3fff, %ebx           # imm = 0x3FFF
     f10:      	movl	$0x4, %eax
     f15:      	movq	0x88(%rsp), %rdi
     f1d:      	movl	%ebx, %esi
     f1f:      	callq	*%rax
     f21:      	testl	%eax, %eax
     f23:      	js	0xf51 <event_execve+0xf51>
     f25:      	leal	0x20(%rbx), %r8d
     f29:      	movq	0x80(%rsp), %rcx
     f31:      	movl	%r8d, 0x4(%rcx)
     f35:      	movq	(%rip), %rsi            # 0xf3c <event_execve+0xf3c>
     f3c:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     f41:      	movl	$0x19, %eax
     f46:      	movq	0x78(%rsp), %rdi
     f4b:      	callq	*%rax
     f4d:      	testl	%eax, %eax
     f4f:      	jns	0xf54 <event_execve+0xf54>
     f51:      	movslq	%eax, %rbx
     f54:      	testl	%ebx, %ebx
     f56:      	js	0x1143 <event_execve+0x1143>
     f5c:      	addq	%r15, %rbx
     f5f:      	movq	%r12, %rcx
     f62:      	movq	%r12, %rax
     f65:      	subq	%rbx, %rcx
     f68:      	je	0x11d4 <event_execve+0x11d4>
     f6e:      	js	0x1148 <event_execve+0x1148>
     f74:      	leaq	(%rbx,%r13), %rdx
     f78:      	cmpq	$0x7fe0, %rcx           # imm = 0x7FE0
     f7f:      	movl	$0x7fe0, %r15d          # imm = 0x7FE0
     f85:      	cmovbq	%rcx, %r15
     f89:      	andl	$0x3fff, %r15d          # imm = 0x3FFF
     f90:      	movl	$0x4, %eax
     f95:      	movq	0x88(%rsp), %rdi
     f9d:      	movl	%r15d, %esi
     fa0:      	callq	*%rax
     fa2:      	testl	%eax, %eax
     fa4:      	js	0xfd2 <event_execve+0xfd2>
     fa6:      	leal	0x20(%r15), %r8d
     faa:      	movq	0x80(%rsp), %rcx
     fb2:      	movl	%r8d, 0x4(%rcx)
     fb6:      	movq	(%rip), %rsi            # 0xfbd <event_execve+0xfbd>
     fbd:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     fc2:      	movl	$0x19, %eax
     fc7:      	movq	0x78(%rsp), %rdi
     fcc:      	callq	*%rax
     fce:      	testl	%eax, %eax
     fd0:      	jns	0xfd5 <event_execve+0xfd5>
     fd2:      	movslq	%eax, %r15
     fd5:      	testl	%r15d, %r15d
     fd8:      	js	0x2756 <event_execve+0x2756>
     fde:      	addq	%rbx, %r15
     fe1:      	movq	%r12, %rcx
     fe4:      	movq	%r12, %rax
     fe7:      	subq	%r15, %rcx
     fea:      	je	0x11d4 <event_execve+0x11d4>
     ff0:      	js	0x1148 <event_execve+0x1148>
     ff6:      	leaq	(%r15,%r13), %rdx
     ffa:      	cmpq	$0x7fe0, %rcx           # imm = 0x7FE0
    1001:      	movl	$0x7fe0, %ebx           # imm = 0x7FE0
    1006:      	cmovbq	%rcx, %rbx
    100a:      	andl	$0x3fff, %ebx           # imm = 0x3FFF
    1010:      	movl	$0x4, %eax
    1015:      	movq	0x88(%rsp), %rdi
    101d:      	movl	%ebx, %esi
    101f:      	callq	*%rax
    1021:      	testl	%eax, %eax
    1023:      	js	0x1051 <event_execve+0x1051>
    1025:      	leal	0x20(%rbx), %r8d
    1029:      	movq	0x80(%rsp), %rcx
    1031:      	movl	%r8d, 0x4(%rcx)
    1035:      	movq	(%rip), %rsi            # 0x103c <event_execve+0x103c>
    103c:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    1041:      	movl	$0x19, %eax
    1046:      	movq	0x78(%rsp), %rdi
    104b:      	callq	*%rax
    104d:      	testl	%eax, %eax
    104f:      	jns	0x1054 <event_execve+0x1054>
    1051:      	movslq	%eax, %rbx
    1054:      	testl	%ebx, %ebx
    1056:      	js	0x1143 <event_execve+0x1143>
    105c:      	addq	%r15, %rbx
    105f:      	movq	%r12, %rcx
    1062:      	movq	%r12, %rax
    1065:      	subq	%rbx, %rcx
    1068:      	je	0x11d4 <event_execve+0x11d4>
    106e:      	js	0x1148 <event_execve+0x1148>
    1074:      	addq	%rbx, %r13
    1077:      	cmpq	$0x7fe0, %rcx           # imm = 0x7FE0
    107e:      	movl	$0x7fe0, %esi           # imm = 0x7FE0
    1083:      	cmovbq	%rcx, %rsi
    1087:      	andl	$0x3fff, %esi           # imm = 0x3FFF
    108d:      	movl	$0x4, %eax
    1092:      	movq	0x88(%rsp), %rdi
    109a:      	movq	%rsi, 0x18(%rsp)
    109f:      	movq	%r13, %rdx
    10a2:      	callq	*%rax
    10a4:      	testl	%eax, %eax
    10a6:      	js	0x10d9 <event_execve+0x10d9>
    10a8:      	movq	0x18(%rsp), %rax
    10ad:      	leal	0x20(%rax), %r8d
    10b1:      	movq	0x80(%rsp), %rcx
    10b9:      	movl	%r8d, 0x4(%rcx)
    10bd:      	movq	(%rip), %rsi            # 0x10c4 <event_execve+0x10c4>
    10c4:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    10c9:      	movl	$0x19, %eax
    10ce:      	movq	0x78(%rsp), %rdi
    10d3:      	callq	*%rax
    10d5:      	testl	%eax, %eax
    10d7:      	jns	0x10e0 <event_execve+0x10e0>
    10d9:      	cltq
    10db:      	movq	%rax, 0x18(%rsp)
    10e0:      	cmpl	$0x0, 0x18(%rsp)
    10e5:      	js	0x1148 <event_execve+0x1148>
    10e7:      	movq	0x18(%rsp), %rax
    10ec:      	addq	%rbx, %rax
    10ef:      	jmp	0x11d4 <event_execve+0x11d4>
    10f4:      	xorl	%r12d, %r12d
    10f7:      	jmp	0x1224 <event_execve+0x1224>
    10fc:      	movq	$-0x1, 0x18(%rsp)
    1105:      	jmp	0x1148 <event_execve+0x1148>
    1107:      	movl	$0x1, 0x70(%rsp)
    110f:      	movq	(%rip), %rdi            # 0x1116 <event_execve+0x1116>
    1116:      	xorl	%ecx, %ecx
    1118:      	leaq	0x28(%rsp), %rsi
    111d:      	leaq	0x70(%rsp), %rdx
    1122:      	movl	$0x2, %eax
    1127:      	xorl	%ecx, %ecx
    1129:      	callq	*%rax
    112b:      	testl	%ebx, %ebx
    112d:      	jns	0x122c <event_execve+0x122c>
    1133:      	orb	$0x2, 0x15d(%r14)
    113b:      	xorl	%r12d, %r12d
    113e:      	jmp	0x122c <event_execve+0x122c>
    1143:      	movq	%rbx, 0x18(%rsp)
    1148:      	movl	$0x0, 0x28(%rsp)
    1150:      	movq	(%rip), %rdi            # 0x1157 <event_execve+0x1157>
    1157:      	leaq	0x28(%rsp), %rsi
    115c:      	movl	$0x1, %eax
    1161:      	callq	*%rax
    1163:      	testq	%rax, %rax
    1166:      	movq	0x18(%rsp), %rcx
    116b:      	je	0x11d1 <event_execve+0x11d1>
    116d:      	cmpq	$-0xc, %rcx
    1171:      	jg	0x118d <event_execve+0x118d>
    1173:      	cmpq	$-0x1c, %rcx
    1177:      	je	0x11a7 <event_execve+0x11a7>
    1179:      	cmpq	$-0x16, %rcx
    117d:      	je	0x11bf <event_execve+0x11bf>
    117f:      	cmpq	$-0x10, %rcx
    1183:      	jne	0x11b7 <event_execve+0x11b7>
    1185:      	addq	$0x558, %rax            # imm = 0x558
    118b:      	jmp	0x11cd <event_execve+0x11cd>
    118d:      	cmpq	$-0xb, %rcx
    1191:      	je	0x11af <event_execve+0x11af>
    1193:      	cmpq	$-0x7, %rcx
    1197:      	je	0x11c7 <event_execve+0x11c7>
    1199:      	cmpq	$-0x2, %rcx
    119d:      	jne	0x11b7 <event_execve+0x11b7>
    119f:      	addq	$0x548, %rax            # imm = 0x548
    11a5:      	jmp	0x11cd <event_execve+0x11cd>
    11a7:      	addq	$0x568, %rax            # imm = 0x568
    11ad:      	jmp	0x11cd <event_execve+0x11cd>
    11af:      	addq	$0x570, %rax            # imm = 0x570
    11b5:      	jmp	0x11cd <event_execve+0x11cd>
    11b7:      	addq	$0x540, %rax            # imm = 0x540
    11bd:      	jmp	0x11cd <event_execve+0x11cd>
    11bf:      	addq	$0x560, %rax            # imm = 0x560
    11c5:      	jmp	0x11cd <event_execve+0x11cd>
    11c7:      	addq	$0x550, %rax            # imm = 0x550
    11cd:      	lock
    11ce:      	incq	(%rax)
    11d1:      	movq	%rcx, %rax
    11d4:      	movl	%r12d, %ecx
    11d7:      	subl	%eax, %ecx
    11d9:      	xorl	%edx, %edx
    11db:      	cmpq	$-0x1, %r12
    11df:      	cmovel	%edx, %ecx
    11e2:      	testl	%eax, %eax
    11e4:      	movl	$0x0, %esi
    11e9:      	cmovsl	%eax, %esi
    11ec:      	cmovsl	%edx, %ecx
    11ef:      	cmovgl	%eax, %edx
    11f2:      	movq	0x98(%rsp), %rax
    11fa:      	movl	%esi, 0x140(%rax)
    1200:      	movl	$0x0, 0x144(%rax)
    120a:      	movl	%ecx, 0x148(%rax)
    1210:      	movl	%edx, 0x14c(%rax)
    1216:      	orb	$0x1, 0x15f(%r14)
    121e:      	movl	$0x20, %r12d
    1224:      	movq	0x90(%rsp), %r15
    122c:      	movw	%r12w, 0x17a(%r14)
    1234:      	addl	0x140(%r14), %r12d
    123b:      	movl	%r12d, 0x140(%r14)
    1242:      	testb	$0x20, 0x15d(%r14)
    124a:      	jne	0x1d45 <event_execve+0x1d45>
    1250:      	movl	0x144(%r14), %ebx
    1257:      	movl	$0x23, %eax
    125c:      	callq	*%rax
    125e:      	movl	$0x0, 0x8(%rsp)
    1266:      	testq	%rax, %rax
    1269:      	je	0x1903 <event_execve+0x1903>
    126f:      	movq	%rax, %r13
    1272:      	leaq	0xaf4(%rax), %rdx
    1279:      	leaq	0x8(%rsp), %rdi
    127e:      	movl	$0x4, %ecx
    1283:      	movl	$0x71, %eax
    1288:      	movl	$0x4, %esi
    128d:      	callq	*%rax
    128f:      	cmpl	%ebx, 0x8(%rsp)
    1293:      	je	0x1906 <event_execve+0x1906>
    1299:      	addq	$0xb00, %r13            # imm = 0xB00
    12a0:      	leaq	0x28(%rsp), %rdi
    12a5:      	movl	$0x8, %ecx
    12aa:      	movl	$0x71, %eax
    12af:      	movl	$0x8, %esi
    12b4:      	movq	%r13, %rdx
    12b7:      	callq	*%rax
    12b9:      	movq	0x28(%rsp), %r13
    12be:      	testq	%r13, %r13
    12c1:      	je	0x1903 <event_execve+0x1903>
    12c7:      	leaq	0xaf4(%r13), %rdx
    12ce:      	leaq	0x8(%rsp), %rdi
    12d3:      	movl	$0x4, %ecx
    12d8:      	movl	$0x71, %eax
    12dd:      	movl	$0x4, %esi
    12e2:      	callq	*%rax
    12e4:      	cmpl	%ebx, 0x8(%rsp)
    12e8:      	je	0x1906 <event_execve+0x1906>
    12ee:      	addq	$0xb00, %r13            # imm = 0xB00
    12f5:      	leaq	0x28(%rsp), %rdi
    12fa:      	movl	$0x8, %ecx
    12ff:      	movl	$0x71, %eax
    1304:      	movl	$0x8, %esi
    1309:      	movq	%r13, %rdx
    130c:      	callq	*%rax
    130e:      	movq	0x28(%rsp), %r13
    1313:      	testq	%r13, %r13
    1316:      	je	0x1903 <event_execve+0x1903>
    131c:      	leaq	0xaf4(%r13), %rdx
    1323:      	leaq	0x8(%rsp), %rdi
    1328:      	movl	$0x4, %ecx
    132d:      	movl	$0x71, %eax
    1332:      	movl	$0x4, %esi
    1337:      	callq	*%rax
    1339:      	cmpl	%ebx, 0x8(%rsp)
    133d:      	je	0x1906 <event_execve+0x1906>
    1343:      	addq	$0xb00, %r13            # imm = 0xB00
    134a:      	leaq	0x28(%rsp), %rdi
    134f:      	movl	$0x8, %ecx
    1354:      	movl	$0x71, %eax
    1359:      	movl	$0x8, %esi
    135e:      	movq	%r13, %rdx
    1361:      	callq	*%rax
    1363:      	movq	0x28(%rsp), %r13
    1368:      	testq	%r13, %r13
    136b:      	je	0x1903 <event_execve+0x1903>
    1371:      	leaq	0xaf4(%r13), %rdx
    1378:      	leaq	0x8(%rsp), %rdi
    137d:      	movl	$0x4, %ecx
    1382:      	movl	$0x71, %eax
    1387:      	movl	$0x4, %esi
    138c:      	callq	*%rax
    138e:      	cmpl	%ebx, 0x8(%rsp)
    1392:      	je	0x1906 <event_execve+0x1906>
    1398:      	addq	$0xb00, %r13            # imm = 0xB00
    139f:      	leaq	0x28(%rsp), %rdi
    13a4:      	movl	$0x8, %ecx
    13a9:      	movl	$0x71, %eax
    13ae:      	movl	$0x8, %esi
    13b3:      	movq	%r13, %rdx
    13b6:      	callq	*%rax
    13b8:      	movq	0x28(%rsp), %r13
    13bd:      	testq	%r13, %r13
    13c0:      	je	0x1903 <event_execve+0x1903>
    13c6:      	leaq	0xaf4(%r13), %rdx
    13cd:      	leaq	0x8(%rsp), %rdi
    13d2:      	movl	$0x4, %ecx
    13d7:      	movl	$0x71, %eax
    13dc:      	movl	$0x4, %esi
    13e1:      	callq	*%rax
    13e3:      	cmpl	%ebx, 0x8(%rsp)
    13e7:      	je	0x1906 <event_execve+0x1906>
    13ed:      	addq	$0xb00, %r13            # imm = 0xB00
    13f4:      	leaq	0x28(%rsp), %rdi
    13f9:      	movl	$0x8, %ecx
    13fe:      	movl	$0x71, %eax
    1403:      	movl	$0x8, %esi
    1408:      	movq	%r13, %rdx
    140b:      	callq	*%rax
    140d:      	movq	0x28(%rsp), %r13
    1412:      	testq	%r13, %r13
    1415:      	je	0x1903 <event_execve+0x1903>
    141b:      	leaq	0xaf4(%r13), %rdx
    1422:      	leaq	0x8(%rsp), %rdi
    1427:      	movl	$0x4, %ecx
    142c:      	movl	$0x71, %eax
    1431:      	movl	$0x4, %esi
    1436:      	callq	*%rax
    1438:      	cmpl	%ebx, 0x8(%rsp)
    143c:      	je	0x1906 <event_execve+0x1906>
    1442:      	addq	$0xb00, %r13            # imm = 0xB00
    1449:      	leaq	0x28(%rsp), %rdi
    144e:      	movl	$0x8, %ecx
    1453:      	movl	$0x71, %eax
    1458:      	movl	$0x8, %esi
    145d:      	movq	%r13, %rdx
    1460:      	callq	*%rax
    1462:      	movq	0x28(%rsp), %r13
    1467:      	testq	%r13, %r13
    146a:      	je	0x1903 <event_execve+0x1903>
    1470:      	leaq	0xaf4(%r13), %rdx
    1477:      	leaq	0x8(%rsp), %rdi
    147c:      	movl	$0x4, %ecx
    1481:      	movl	$0x71, %eax
    1486:      	movl	$0x4, %esi
    148b:      	callq	*%rax
    148d:      	cmpl	%ebx, 0x8(%rsp)
    1491:      	je	0x1906 <event_execve+0x1906>
    1497:      	addq	$0xb00, %r13            # imm = 0xB00
    149e:      	leaq	0x28(%rsp), %rdi
    14a3:      	movl	$0x8, %ecx
    14a8:      	movl	$0x71, %eax
    14ad:      	movl	$0x8, %esi
    14b2:      	movq	%r13, %rdx
    14b5:      	callq	*%rax
    14b7:      	movq	0x28(%rsp), %r13
    14bc:      	testq	%r13, %r13
    14bf:      	je	0x1903 <event_execve+0x1903>
    14c5:      	leaq	0xaf4(%r13), %rdx
    14cc:      	leaq	0x8(%rsp), %rdi
    14d1:      	movl	$0x4, %ecx
    14d6:      	movl	$0x71, %eax
    14db:      	movl	$0x4, %esi
    14e0:      	callq	*%rax
    14e2:      	cmpl	%ebx, 0x8(%rsp)
    14e6:      	je	0x1906 <event_execve+0x1906>
    14ec:      	addq	$0xb00, %r13            # imm = 0xB00
    14f3:      	leaq	0x28(%rsp), %rdi
    14f8:      	movl	$0x8, %ecx
    14fd:      	movl	$0x71, %eax
    1502:      	movl	$0x8, %esi
    1507:      	movq	%r13, %rdx
    150a:      	callq	*%rax
    150c:      	movq	0x28(%rsp), %r13
    1511:      	testq	%r13, %r13
    1514:      	je	0x1903 <event_execve+0x1903>
    151a:      	leaq	0xaf4(%r13), %rdx
    1521:      	leaq	0x8(%rsp), %rdi
    1526:      	movl	$0x4, %ecx
    152b:      	movl	$0x71, %eax
    1530:      	movl	$0x4, %esi
    1535:      	callq	*%rax
    1537:      	cmpl	%ebx, 0x8(%rsp)
    153b:      	je	0x1906 <event_execve+0x1906>
    1541:      	addq	$0xb00, %r13            # imm = 0xB00
    1548:      	leaq	0x28(%rsp), %rdi
    154d:      	movl	$0x8, %ecx
    1552:      	movl	$0x71, %eax
    1557:      	movl	$0x8, %esi
    155c:      	movq	%r13, %rdx
    155f:      	callq	*%rax
    1561:      	movq	0x28(%rsp), %r13
    1566:      	testq	%r13, %r13
    1569:      	je	0x1903 <event_execve+0x1903>
    156f:      	leaq	0xaf4(%r13), %rdx
    1576:      	leaq	0x8(%rsp), %rdi
    157b:      	movl	$0x4, %ecx
    1580:      	movl	$0x71, %eax
    1585:      	movl	$0x4, %esi
    158a:      	callq	*%rax
    158c:      	cmpl	%ebx, 0x8(%rsp)
    1590:      	je	0x1906 <event_execve+0x1906>
    1596:      	addq	$0xb00, %r13            # imm = 0xB00
    159d:      	leaq	0x28(%rsp), %rdi
    15a2:      	movl	$0x8, %ecx
    15a7:      	movl	$0x71, %eax
    15ac:      	movl	$0x8, %esi
    15b1:      	movq	%r13, %rdx
    15b4:      	callq	*%rax
    15b6:      	movq	0x28(%rsp), %r13
    15bb:      	testq	%r13, %r13
    15be:      	je	0x1903 <event_execve+0x1903>
    15c4:      	leaq	0xaf4(%r13), %rdx
    15cb:      	leaq	0x8(%rsp), %rdi
    15d0:      	movl	$0x4, %ecx
    15d5:      	movl	$0x71, %eax
    15da:      	movl	$0x4, %esi
    15df:      	callq	*%rax
    15e1:      	cmpl	%ebx, 0x8(%rsp)
    15e5:      	je	0x1906 <event_execve+0x1906>
    15eb:      	addq	$0xb00, %r13            # imm = 0xB00
    15f2:      	leaq	0x28(%rsp), %rdi
    15f7:      	movl	$0x8, %ecx
    15fc:      	movl	$0x71, %eax
    1601:      	movl	$0x8, %esi
    1606:      	movq	%r13, %rdx
    1609:      	callq	*%rax
    160b:      	movq	0x28(%rsp), %r13
    1610:      	testq	%r13, %r13
    1613:      	je	0x1903 <event_execve+0x1903>
    1619:      	leaq	0xaf4(%r13), %rdx
    1620:      	leaq	0x8(%rsp), %rdi
    1625:      	movl	$0x4, %ecx
    162a:      	movl	$0x71, %eax
    162f:      	movl	$0x4, %esi
    1634:      	callq	*%rax
    1636:      	cmpl	%ebx, 0x8(%rsp)
    163a:      	je	0x1906 <event_execve+0x1906>
    1640:      	addq	$0xb00, %r13            # imm = 0xB00
    1647:      	leaq	0x28(%rsp), %rdi
    164c:      	movl	$0x8, %ecx
    1651:      	movl	$0x71, %eax
    1656:      	movl	$0x8, %esi
    165b:      	movq	%r13, %rdx
    165e:      	callq	*%rax
    1660:      	movq	0x28(%rsp), %r13
    1665:      	testq	%r13, %r13
    1668:      	je	0x1903 <event_execve+0x1903>
    166e:      	leaq	0xaf4(%r13), %rdx
    1675:      	leaq	0x8(%rsp), %rdi
    167a:      	movl	$0x4, %ecx
    167f:      	movl	$0x71, %eax
    1684:      	movl	$0x4, %esi
    1689:      	callq	*%rax
    168b:      	cmpl	%ebx, 0x8(%rsp)
    168f:      	je	0x1906 <event_execve+0x1906>
    1695:      	addq	$0xb00, %r13            # imm = 0xB00
    169c:      	leaq	0x28(%rsp), %rdi
    16a1:      	movl	$0x8, %ecx
    16a6:      	movl	$0x71, %eax
    16ab:      	movl	$0x8, %esi
    16b0:      	movq	%r13, %rdx
    16b3:      	callq	*%rax
    16b5:      	movq	0x28(%rsp), %r13
    16ba:      	testq	%r13, %r13
    16bd:      	je	0x1903 <event_execve+0x1903>
    16c3:      	leaq	0xaf4(%r13), %rdx
    16ca:      	leaq	0x8(%rsp), %rdi
    16cf:      	movl	$0x4, %ecx
    16d4:      	movl	$0x71, %eax
    16d9:      	movl	$0x4, %esi
    16de:      	callq	*%rax
    16e0:      	cmpl	%ebx, 0x8(%rsp)
    16e4:      	je	0x1906 <event_execve+0x1906>
    16ea:      	addq	$0xb00, %r13            # imm = 0xB00
    16f1:      	leaq	0x28(%rsp), %rdi
    16f6:      	movl	$0x8, %ecx
    16fb:      	movl	$0x71, %eax
    1700:      	movl	$0x8, %esi
    1705:      	movq	%r13, %rdx
    1708:      	callq	*%rax
    170a:      	movq	0x28(%rsp), %r13
    170f:      	testq	%r13, %r13
    1712:      	je	0x1903 <event_execve+0x1903>
    1718:      	leaq	0xaf4(%r13), %rdx
    171f:      	leaq	0x8(%rsp), %rdi
    1724:      	movl	$0x4, %ecx
    1729:      	movl	$0x71, %eax
    172e:      	movl	$0x4, %esi
    1733:      	callq	*%rax
    1735:      	cmpl	%ebx, 0x8(%rsp)
    1739:      	je	0x1906 <event_execve+0x1906>
    173f:      	addq	$0xb00, %r13            # imm = 0xB00
    1746:      	leaq	0x28(%rsp), %rdi
    174b:      	movl	$0x8, %ecx
    1750:      	movl	$0x71, %eax
    1755:      	movl	$0x8, %esi
    175a:      	movq	%r13, %rdx
    175d:      	callq	*%rax
    175f:      	movq	0x28(%rsp), %r13
    1764:      	testq	%r13, %r13
    1767:      	je	0x1903 <event_execve+0x1903>
    176d:      	leaq	0xaf4(%r13), %rdx
    1774:      	leaq	0x8(%rsp), %rdi
    1779:      	movl	$0x4, %ecx
    177e:      	movl	$0x71, %eax
    1783:      	movl	$0x4, %esi
    1788:      	callq	*%rax
    178a:      	cmpl	%ebx, 0x8(%rsp)
    178e:      	je	0x1906 <event_execve+0x1906>
    1794:      	addq	$0xb00, %r13            # imm = 0xB00
    179b:      	leaq	0x28(%rsp), %rdi
    17a0:      	movl	$0x8, %ecx
    17a5:      	movl	$0x71, %eax
    17aa:      	movl	$0x8, %esi
    17af:      	movq	%r13, %rdx
    17b2:      	callq	*%rax
    17b4:      	movq	0x28(%rsp), %r13
    17b9:      	testq	%r13, %r13
    17bc:      	je	0x1903 <event_execve+0x1903>
    17c2:      	leaq	0xaf4(%r13), %rdx
    17c9:      	leaq	0x8(%rsp), %rdi
    17ce:      	movl	$0x4, %ecx
    17d3:      	movl	$0x71, %eax
    17d8:      	movl	$0x4, %esi
    17dd:      	callq	*%rax
    17df:      	cmpl	%ebx, 0x8(%rsp)
    17e3:      	je	0x1906 <event_execve+0x1906>
    17e9:      	addq	$0xb00, %r13            # imm = 0xB00
    17f0:      	leaq	0x28(%rsp), %rdi
    17f5:      	movl	$0x8, %ecx
    17fa:      	movl	$0x71, %eax
    17ff:      	movl	$0x8, %esi
    1804:      	movq	%r13, %rdx
    1807:      	callq	*%rax
    1809:      	movq	0x28(%rsp), %r13
    180e:      	testq	%r13, %r13
    1811:      	je	0x1903 <event_execve+0x1903>
    1817:      	leaq	0xaf4(%r13), %rdx
    181e:      	leaq	0x8(%rsp), %rdi
    1823:      	movl	$0x4, %ecx
    1828:      	movl	$0x71, %eax
    182d:      	movl	$0x4, %esi
    1832:      	callq	*%rax
    1834:      	cmpl	%ebx, 0x8(%rsp)
    1838:      	je	0x1906 <event_execve+0x1906>
    183e:      	addq	$0xb00, %r13            # imm = 0xB00
    1845:      	leaq	0x28(%rsp), %rdi
    184a:      	movl	$0x8, %ecx
    184f:      	movl	$0x71, %eax
    1854:      	movl	$0x8, %esi
    1859:      	movq	%r13, %rdx
    185c:      	callq	*%rax
    185e:      	movq	0x28(%rsp), %r13
    1863:      	testq	%r13, %r13
    1866:      	je	0x1903 <event_execve+0x1903>
    186c:      	leaq	0xaf4(%r13), %rdx
    1873:      	leaq	0x8(%rsp), %rdi
    1878:      	movl	$0x4, %ecx
    187d:      	movl	$0x71, %eax
    1882:      	movl	$0x4, %esi
    1887:      	callq	*%rax
    1889:      	cmpl	%ebx, 0x8(%rsp)
    188d:      	je	0x1906 <event_execve+0x1906>
    188f:      	addq	$0xb00, %r13            # imm = 0xB00
    1896:      	leaq	0x28(%rsp), %rdi
    189b:      	movl	$0x8, %ecx
    18a0:      	movl	$0x71, %eax
    18a5:      	movl	$0x8, %esi
    18aa:      	movq	%r13, %rdx
    18ad:      	callq	*%rax
    18af:      	movq	0x28(%rsp), %r13
    18b4:      	testq	%r13, %r13
    18b7:      	je	0x1903 <event_execve+0x1903>
    18b9:      	leaq	0xaf4(%r13), %rdx
    18c0:      	leaq	0x8(%rsp), %rdi
    18c5:      	movl	$0x4, %ecx
    18ca:      	movl	$0x71, %eax
    18cf:      	movl	$0x4, %esi
    18d4:      	callq	*%rax
    18d6:      	cmpl	%ebx, 0x8(%rsp)
    18da:      	je	0x1906 <event_execve+0x1906>
    18dc:      	addq	$0xb00, %r13            # imm = 0xB00
    18e3:      	leaq	0x28(%rsp), %rdi
    18e8:      	movl	$0x8, %ecx
    18ed:      	movl	$0x71, %eax
    18f2:      	movl	$0x8, %esi
    18f7:      	movq	%r13, %rdx
    18fa:      	callq	*%rax
    18fc:      	movq	0x28(%rsp), %r13
    1901:      	jmp	0x1906 <event_execve+0x1906>
    1903:      	xorl	%r13d, %r13d
    1906:      	xorl	%ebp, %ebp
    1908:      	cmpl	%ebx, 0x8(%rsp)
    190c:      	cmovneq	%rbp, %r13
    1910:      	addq	$0xd50, %r13            # imm = 0xD50
    1917:      	leaq	0xb8(%rsp), %rdi
    191f:      	movl	$0x8, %ecx
    1924:      	movl	$0x4, %eax
    1929:      	movl	$0x8, %esi
    192e:      	movq	%r13, %rdx
    1931:      	callq	*%rax
    1933:      	movq	0xb8(%rsp), %r13
    193b:      	testq	%r13, %r13
    193e:      	je	0x1a2e <event_execve+0x1a2e>
    1944:      	movl	$0x0, 0xac(%rsp)
    194f:      	movq	(%rip), %rdi            # 0x1956 <event_execve+0x1956>
    1956:      	leaq	0xac(%rsp), %rsi
    195e:      	movl	$0x1, %eax
    1963:      	callq	*%rax
    1965:      	testq	%rax, %rax
    1968:      	je	0x1bc4 <event_execve+0x1bc4>
    196e:      	movq	%rax, %rbp
    1971:      	movq	%r12, 0x18(%rsp)
    1976:      	movq	%r15, 0x90(%rsp)
    197e:      	leaq	0x28(%r13), %rax
    1982:      	movq	%rax, 0x80(%rsp)
    198a:      	leaq	0x1000(%rbp), %rax
    1991:      	movq	%rax, 0x98(%rsp)
    1999:      	movl	$0x23, %eax
    199e:      	callq	*%rax
    19a0:      	leaq	0xd50(%rax), %rdx
    19a7:      	leaq	0xc0(%rsp), %rdi
    19af:      	movl	$0x8, %ecx
    19b4:      	movl	$0x4, %eax
    19b9:      	movl	$0x8, %esi
    19be:      	callq	*%rax
    19c0:      	movq	0xc0(%rsp), %r12
    19c8:      	addq	$0x30, %r13
    19cc:      	leaq	0xa0(%rsp), %rdi
    19d4:      	movl	$0x8, %ecx
    19d9:      	movl	$0x4, %eax
    19de:      	leaq	0x18(%r12), %rcx
    19e3:      	movq	%rcx, 0x88(%rsp)
    19eb:      	movl	$0x8, %esi
    19f0:      	movq	%r13, %rdx
    19f3:      	callq	*%rax
    19f5:      	movq	0xa0(%rsp), %r15
    19fd:      	leaq	0x10(%r15), %rdx
    1a01:      	leaq	0x28(%rsp), %rdi
    1a06:      	movl	$0x8, %ecx
    1a0b:      	movl	$0x4, %eax
    1a10:      	movl	$0x8, %esi
    1a15:      	callq	*%rax
    1a17:      	cmpq	$0x0, 0x28(%rsp)
    1a1d:      	movl	$0x1000, %ebx           # imm = 0x1000
    1a22:      	je	0x1a3b <event_execve+0x1a3b>
    1a24:      	movq	0x98(%rsp), %rcx
    1a2c:      	jmp	0x1a8d <event_execve+0x1a8d>
    1a2e:      	orb	$0x20, 0x15d(%r14)
    1a36:      	jmp	0x1d42 <event_execve+0x1d42>
    1a3b:      	leaq	0x18(%r15), %rdx
    1a3f:      	leaq	0x28(%rsp), %rdi
    1a44:      	movl	$0x8, %ecx
    1a49:      	movl	$0x4, %eax
    1a4e:      	movl	$0x8, %esi
    1a53:      	callq	*%rax
    1a55:      	cmpq	%r15, 0x28(%rsp)
    1a5a:      	movq	0x98(%rsp), %rcx
    1a62:      	je	0x1a8d <event_execve+0x1a8d>
    1a64:      	movq	%rbp, %rcx
    1a67:      	addq	$0xff6, %rcx            # imm = 0xFF6
    1a6e:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    1a78:      	movq	%rax, 0xff6(%rbp)
    1a7f:      	movw	$0x2964, 0xffe(%rbp)    # imm = 0x2964
    1a88:      	movl	$0xff6, %ebx            # imm = 0xFF6
    1a8d:      	movq	$0x0, 0x30(%rsp)
    1a96:      	movq	$0x0, 0x28(%rsp)
    1a9f:      	movq	%rbp, 0x38(%rsp)
    1aa4:      	movq	$0x0, 0x40(%rsp)
    1aad:      	movq	$0x0, 0x48(%rsp)
    1ab6:      	movq	$0x0, 0x50(%rsp)
    1abf:      	movq	%rcx, 0x98(%rsp)
    1ac7:      	movq	%rcx, 0x58(%rsp)
    1acc:      	movl	%ebx, 0x60(%rsp)
    1ad0:      	movb	$0x0, 0x64(%rsp)
    1ad5:      	addq	$0x20, %r12
    1ad9:      	leaq	0x28(%rsp), %rdi
    1ade:      	movl	$0x8, %ecx
    1ae3:      	movl	$0x4, %eax
    1ae8:      	leaq	0x30(%rsp), %rbx
    1aed:      	leaq	0x40(%rsp), %r15
    1af2:      	leaq	0x48(%rsp), %rbp
    1af7:      	movl	$0x8, %esi
    1afc:      	movq	%r12, %rdx
    1aff:      	callq	*%rax
    1b01:      	movl	$0x8, %ecx
    1b06:      	movl	$0x4, %eax
    1b0b:      	movq	0x88(%rsp), %rdx
    1b13:      	movq	%rbx, %rdi
    1b16:      	movl	$0x8, %esi
    1b1b:      	callq	*%rax
    1b1d:      	movl	$0x8, %ecx
    1b22:      	movl	$0x4, %eax
    1b27:      	movq	%r15, %rdi
    1b2a:      	movl	$0x8, %esi
    1b2f:      	movq	%r13, %rdx
    1b32:      	callq	*%rax
    1b34:      	movl	$0x8, %ecx
    1b39:      	movl	$0x4, %eax
    1b3e:      	movq	0x80(%rsp), %rdx
    1b46:      	movq	%rbp, %rdi
    1b49:      	movl	$0x8, %esi
    1b4e:      	callq	*%rax
    1b50:      	movq	0x48(%rsp), %rbx
    1b55:      	leaq	-0x20(%rbx), %rax
    1b59:      	movq	%rax, 0x50(%rsp)
    1b5e:      	movq	0x40(%rsp), %r15
    1b63:      	cmpq	0x28(%rsp), %r15
    1b68:      	jne	0x1bcb <event_execve+0x1bcb>
    1b6a:      	cmpq	0x30(%rsp), %rbx
    1b6f:      	jne	0x1bcb <event_execve+0x1bcb>
    1b71:      	movb	$0x1, 0x64(%rsp)
    1b76:      	movq	0x18(%rsp), %rdi
    1b7b:      	movq	0x58(%rsp), %rax
    1b80:      	movq	0x98(%rsp), %rdx
    1b88:      	cmpq	%rdx, %rax
    1b8b:      	movq	0x90(%rsp), %r15
    1b93:      	je	0x1cf2 <event_execve+0x1cf2>
    1b99:      	xorl	%ebx, %ebx
    1b9b:      	cmpb	$0x0, 0x64(%rsp)
    1ba0:      	sete	%cl
    1ba3:      	movl	0x60(%rsp), %edx
    1ba7:      	movl	$0x1000, %ebp           # imm = 0x1000
    1bac:      	subl	%edx, %ebp
    1bae:      	testl	%edx, %edx
    1bb0:      	cmovlel	%edx, %ebp
    1bb3:      	testq	%rax, %rax
    1bb6:      	je	0x1bc4 <event_execve+0x1bc4>
    1bb8:      	movb	%cl, %bl
    1bba:      	addl	%ebx, %ebx
    1bbc:      	movq	%rax, %rdx
    1bbf:      	jmp	0x1cf6 <event_execve+0x1cf6>
    1bc4:      	xorl	%ebp, %ebp
    1bc6:      	jmp	0x1d42 <event_execve+0x1d42>
    1bcb:      	leaq	0x70(%rsp), %rdi
    1bd0:      	movl	$0x8, %ecx
    1bd5:      	movl	$0x4, %eax
    1bda:      	movl	$0x8, %esi
    1bdf:      	movq	%rbx, %rdx
    1be2:      	callq	*%rax
    1be4:      	cmpq	0x70(%rsp), %r15
    1be9:      	je	0x22ad <event_execve+0x22ad>
    1bef:      	leaq	0x18(%r15), %r12
    1bf3:      	movq	%rsp, %rdi
    1bf6:      	movl	$0x8, %ecx
    1bfb:      	movl	$0x4, %eax
    1c00:      	movl	$0x8, %esi
    1c05:      	movq	%r12, %rdx
    1c08:      	callq	*%rax
    1c0a:      	cmpq	%r15, (%rsp)
    1c0e:      	je	0x22ad <event_execve+0x22ad>
    1c14:      	leaq	0x20(%rsp), %rdi
    1c19:      	movl	$0x8, %ecx
    1c1e:      	movl	$0x4, %eax
    1c23:      	movl	$0x8, %esi
    1c28:      	movq	%r12, %rdx
    1c2b:      	callq	*%rax
    1c2d:      	addq	$0x20, %r15
    1c31:      	leaq	0x8(%rsp), %rdi
    1c36:      	movl	$0x10, %ecx
    1c3b:      	movl	$0x4, %eax
    1c40:      	movl	$0x10, %esi
    1c45:      	movq	%r15, %rdx
    1c48:      	callq	*%rax
    1c4a:      	movq	0x38(%rsp), %rbx
    1c4f:      	movq	0x58(%rsp), %rax
    1c54:      	movl	0xc(%rsp), %ebp
    1c58:      	subq	%rbx, %rax
    1c5b:      	movl	0x60(%rsp), %r15d
    1c60:      	xorl	%ecx, %ecx
    1c62:      	movl	%ebp, %edx
    1c64:      	subl	%r15d, %edx
    1c67:      	cmovbl	%ecx, %edx
    1c6a:      	addq	0x10(%rsp), %rdx
    1c6f:      	xorl	%esi, %esi
    1c71:      	cmpl	%ebp, %r15d
    1c74:      	seta	%sil
    1c78:      	movl	%ebp, %ecx
    1c7a:      	cmovbl	%r15d, %ecx
    1c7e:      	addl	%ecx, %esi
    1c80:      	movl	%r15d, %edi
    1c83:      	subl	%esi, %edi
    1c85:      	movl	%edi, 0x60(%rsp)
    1c89:      	subq	%rsi, %rax
    1c8c:      	movq	0x18(%rsp), %rdi
    1c91:      	jb	0x1b7b <event_execve+0x1b7b>
    1c97:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    1c9d:      	ja	0x1b7b <event_execve+0x1b7b>
    1ca3:      	movq	%rdi, %r12
    1ca6:      	cmpl	%ebp, %r15d
    1ca9:      	jbe	0x1caf <event_execve+0x1caf>
    1cab:      	movb	$0x2f, (%rbx,%rax)
    1caf:      	xorl	%edi, %edi
    1cb1:      	cmpl	%ebp, %r15d
    1cb4:      	seta	%dil
    1cb8:      	movzbl	%cl, %esi
    1cbb:      	addq	%rax, %rbx
    1cbe:      	addq	%rbx, %rdi
    1cc1:      	movl	$0x4, %eax
    1cc6:      	callq	*%rax
    1cc8:      	movq	%rbx, 0x58(%rsp)
    1ccd:      	cmpl	%ebp, %r15d
    1cd0:      	movq	%r12, %rdi
    1cd3:      	jbe	0x1b7b <event_execve+0x1b7b>
    1cd9:      	movq	0x20(%rsp), %r15
    1cde:      	movq	%r15, 0x40(%rsp)
    1ce3:      	movq	0x48(%rsp), %rdx
    1ce8:      	movq	0x50(%rsp), %rbx
    1ced:      	jmp	0x2308 <event_execve+0x2308>
    1cf2:      	xorl	%ebp, %ebp
    1cf4:      	xorl	%ebx, %ebx
    1cf6:      	andl	$0x3ff, %edi            # imm = 0x3FF
    1cfc:      	andl	$0xfff, %ebp            # imm = 0xFFF
    1d02:      	addq	%r15, %rdi
    1d05:      	movl	$0x4, %eax
    1d0a:      	movl	%ebp, %esi
    1d0c:      	callq	*%rax
    1d0e:      	movl	0x15c(%r14), %eax
    1d15:      	movl	%eax, %ecx
    1d17:      	orl	$0x1000, %ecx           # imm = 0x1000
    1d1d:      	testl	%ebp, %ebp
    1d1f:      	cmovnel	%eax, %ecx
    1d22:      	movl	%ecx, %eax
    1d24:      	orl	$0x400000, %eax         # imm = 0x400000
    1d29:      	testl	%ebx, %ebx
    1d2b:      	cmovel	%ecx, %eax
    1d2e:      	andl	$0xffffdbff, %eax       # imm = 0xFFFFDBFF
    1d33:      	movl	%eax, 0x15c(%r14)
    1d3a:      	movw	%bp, 0x17c(%r14)
    1d42:      	movl	(%r15), %r12d
    1d45:      	leal	(%r12,%rbp), %eax
    1d49:      	movl	%eax, 0x140(%r14)
    1d50:      	movw	$0x5, (%r14)
    1d56:      	movq	0x170(%r14), %rax
    1d5d:      	movq	%rax, 0x8(%r14)
    1d61:      	leal	0x140(%r12,%rbp), %eax
    1d69:      	movl	%eax, 0x4(%r14)
    1d6d:      	movq	0xb0(%rsp), %rbp
    1d75:      	leaq	0xd00(%rbp), %r12
    1d7c:      	leaq	0x28(%rsp), %rdi
    1d81:      	movl	$0x8, %ecx
    1d86:      	movl	$0x4, %eax
    1d8b:      	leaq	0xb8(%r14), %rbx
    1d92:      	movl	$0x4, %r13d
    1d98:      	movl	$0x8, %esi
    1d9d:      	movq	%r12, %rdx
    1da0:      	callq	*%rax
    1da2:      	movq	0x28(%rsp), %rcx
    1da7:      	addq	$0x8, %rcx
    1dab:      	movl	$0x4, %edx
    1db0:      	movl	$0x4, %eax
    1db5:      	movq	0x28(%rsp), %rdx
    1dba:      	addq	$0x8, %rdx
    1dbe:      	movq	%rbx, %rdi
    1dc1:      	movl	$0x4, %esi
    1dc6:      	callq	*%rax
    1dc8:      	leaq	0xbc(%r14), %rdi
    1dcf:      	movq	0x28(%rsp), %rcx
    1dd4:      	addq	$0xc, %rcx
    1dd8:      	movl	$0x4, %edx
    1ddd:      	movl	$0x4, %eax
    1de2:      	movq	0x28(%rsp), %rdx
    1de7:      	addq	$0xc, %rdx
    1deb:      	movl	$0x4, %esi
    1df0:      	callq	*%rax
    1df2:      	leaq	0xc8(%r14), %rdi
    1df9:      	movq	0x28(%rsp), %rcx
    1dfe:      	addq	$0x18, %rcx
    1e02:      	movl	$0x4, %edx
    1e07:      	movl	$0x4, %eax
    1e0c:      	movq	0x28(%rsp), %rdx
    1e11:      	addq	$0x18, %rdx
    1e15:      	movl	$0x4, %esi
    1e1a:      	callq	*%rax
    1e1c:      	leaq	0xcc(%r14), %rdi
    1e23:      	movq	0x28(%rsp), %rcx
    1e28:      	addq	$0x1c, %rcx
    1e2c:      	movl	$0x4, %edx
    1e31:      	movl	$0x4, %eax
    1e36:      	movq	0x28(%rsp), %rdx
    1e3b:      	addq	$0x1c, %rdx
    1e3f:      	movl	$0x4, %esi
    1e44:      	callq	*%rax
    1e46:      	leaq	0xc0(%r14), %rdi
    1e4d:      	movq	0x28(%rsp), %rcx
    1e52:      	addq	$0x10, %rcx
    1e56:      	movl	$0x4, %edx
    1e5b:      	movl	$0x4, %eax
    1e60:      	movq	0x28(%rsp), %rdx
    1e65:      	addq	$0x10, %rdx
    1e69:      	movl	$0x4, %esi
    1e6e:      	callq	*%rax
    1e70:      	leaq	0xc4(%r14), %rdi
    1e77:      	movq	0x28(%rsp), %rcx
    1e7c:      	addq	$0x14, %rcx
    1e80:      	movl	$0x4, %edx
    1e85:      	movl	$0x4, %eax
    1e8a:      	movq	0x28(%rsp), %rdx
    1e8f:      	addq	$0x14, %rdx
    1e93:      	movl	$0x4, %esi
    1e98:      	callq	*%rax
    1e9a:      	leaq	0xd0(%r14), %rdi
    1ea1:      	movq	0x28(%rsp), %rcx
    1ea6:      	addq	$0x20, %rcx
    1eaa:      	movl	$0x4, %edx
    1eaf:      	movl	$0x4, %eax
    1eb4:      	movq	0x28(%rsp), %rdx
    1eb9:      	addq	$0x20, %rdx
    1ebd:      	movl	$0x4, %esi
    1ec2:      	callq	*%rax
    1ec4:      	leaq	0xd4(%r14), %rdi
    1ecb:      	movq	0x28(%rsp), %rcx
    1ed0:      	addq	$0x24, %rcx
    1ed4:      	movl	$0x4, %edx
    1ed9:      	movl	$0x4, %eax
    1ede:      	movq	0x28(%rsp), %rdx
    1ee3:      	addq	$0x24, %rdx
    1ee7:      	movl	$0x4, %esi
    1eec:      	callq	*%rax
    1eee:      	leaq	0xd8(%r14), %rdi
    1ef5:      	movq	0x28(%rsp), %rcx
    1efa:      	addq	$0x28, %rcx
    1efe:      	movl	$0x4, %edx
    1f03:      	movl	$0x4, %eax
    1f08:      	movq	0x28(%rsp), %rdx
    1f0d:      	addq	$0x28, %rdx
    1f11:      	movl	$0x4, %esi
    1f16:      	callq	*%rax
    1f18:      	movq	0x28(%rsp), %rbx
    1f1d:      	leaq	0xe8(%r14), %rdi
    1f24:      	leaq	0x40(%rbx), %rdx
    1f28:      	movl	$0x8, %ecx
    1f2d:      	movl	$0x4, %eax
    1f32:      	leaq	0xe0(%r14), %r15
    1f39:      	movl	$0x8, %esi
    1f3e:      	callq	*%rax
    1f40:      	leaq	0xf0(%r14), %rdi
    1f47:      	leaq	0x30(%rbx), %rdx
    1f4b:      	movl	$0x8, %ecx
    1f50:      	movl	$0x4, %eax
    1f55:      	movl	$0x8, %esi
    1f5a:      	callq	*%rax
    1f5c:      	addq	$0x38, %rbx
    1f60:      	movl	$0x8, %ecx
    1f65:      	movl	$0x4, %eax
    1f6a:      	movq	%r15, %rdi
    1f6d:      	movl	$0x8, %esi
    1f72:      	movq	%rbx, %rdx
    1f75:      	callq	*%rax
    1f77:      	movl	0xc8(%r14), %eax
    1f7e:      	movl	%eax, 0x154(%r14)
    1f85:      	leaq	0xd70(%rbp), %rdx
    1f8c:      	movq	%rsp, %rdi
    1f8f:      	movl	$0x8, %ecx
    1f94:      	movl	$0x4, %eax
    1f99:      	leaq	0x108(%r14), %rbx
    1fa0:      	movl	$0x8, %esi
    1fa5:      	callq	*%rax
    1fa7:      	movq	(%rsp), %rcx
    1fab:      	leaq	0x28(%rsp), %rdi
    1fb0:      	movl	$0x48, %edx
    1fb5:      	movl	$0x4, %eax
    1fba:      	movq	(%rsp), %rdx
    1fbe:      	movl	$0x48, %esi
    1fc3:      	callq	*%rax
    1fc5:      	movl	$0x218, %edx            # imm = 0x218
    1fca:      	movq	0x30(%rsp), %rcx
    1fcf:      	addq	%rdx, %rcx
    1fd2:      	movl	$0x4, %esi
    1fd7:      	movl	$0x4, %eax
    1fdc:      	addq	0x30(%rsp), %rdx
    1fe1:      	movq	%rbx, %rdi
    1fe4:      	movl	$0x4, %esi
    1fe9:      	callq	*%rax
    1feb:      	leaq	0x10c(%r14), %rdi
    1ff2:      	movl	$0x4d8, %edx            # imm = 0x4D8
    1ff7:      	movq	0x38(%rsp), %rcx
    1ffc:      	addq	%rdx, %rcx
    1fff:      	movl	$0x4, %esi
    2004:      	movl	$0x4, %eax
    2009:      	addq	0x38(%rsp), %rdx
    200e:      	movl	$0x4, %esi
    2013:      	callq	*%rax
    2015:      	leaq	0x110(%r14), %rdi
    201c:      	movq	0x40(%rsp), %rcx
    2021:      	addq	$0x58, %rcx
    2025:      	movl	$0x4, %edx
    202a:      	movl	$0x4, %eax
    202f:      	movq	0x40(%rsp), %rdx
    2034:      	addq	$0x58, %rdx
    2038:      	movl	$0x4, %esi
    203d:      	callq	*%rax
    203f:      	movq	$0x0, 0x20(%rsp)
    2048:      	addq	$0xb58, %rbp            # imm = 0xB58
    204f:      	leaq	0x20(%rsp), %rdi
    2054:      	movl	$0x8, %ecx
    2059:      	movl	$0x4, %eax
    205e:      	movl	$0x8, %esi
    2063:      	movq	%rbp, %rdx
    2066:      	callq	*%rax
    2068:      	movq	0x20(%rsp), %rcx
    206d:      	testq	%rcx, %rcx
    2070:      	je	0x2109 <event_execve+0x2109>
    2076:      	movl	$0x0, 0x70(%rsp)
    207e:      	addq	$0x4, %rcx
    2082:      	leaq	0x70(%rsp), %rdi
    2087:      	movl	$0x4, %eax
    208c:      	movq	0x20(%rsp), %rdx
    2091:      	addq	$0x4, %rdx
    2095:      	movl	$0x4, %esi
    209a:      	callq	*%rax
    209c:      	movq	0x20(%rsp), %rax
    20a1:      	movslq	0x70(%rsp), %rcx
    20a6:      	shlq	$0x4, %rcx
    20aa:      	addq	%rax, %rcx
    20ad:      	addq	$0x80, %rcx
    20b4:      	leaq	0x8(%rsp), %rdi
    20b9:      	movl	$0x10, %edx
    20be:      	movl	$0x4, %eax
    20c3:      	movq	0x20(%rsp), %rcx
    20c8:      	movslq	0x70(%rsp), %rdx
    20cd:      	shlq	$0x4, %rdx
    20d1:      	addq	%rcx, %rdx
    20d4:      	addq	$0x80, %rdx
    20db:      	movl	$0x10, %esi
    20e0:      	callq	*%rax
    20e2:      	leaq	0x114(%r14), %rdi
    20e9:      	movl	$0x158, %edx            # imm = 0x158
    20ee:      	movq	0x10(%rsp), %rcx
    20f3:      	addq	%rdx, %rcx
    20f6:      	movl	$0x4, %eax
    20fb:      	addq	0x10(%rsp), %rdx
    2100:      	movl	$0x4, %esi
    2105:      	callq	*%rax
    2107:      	jmp	0x2114 <event_execve+0x2114>
    2109:      	movl	$0x0, 0x114(%r14)
    2114:      	movq	0x78(%rsp), %r13
    2119:      	leaq	0x118(%r14), %rdi
    2120:      	movl	$0x158, %ebx            # imm = 0x158
    2125:      	movq	0x48(%rsp), %rcx
    212a:      	addq	%rbx, %rcx
    212d:      	movl	$0x4, %edx
    2132:      	movl	$0x4, %eax
    2137:      	movq	0x48(%rsp), %rdx
    213c:      	addq	%rbx, %rdx
    213f:      	movl	$0x4, %esi
    2144:      	callq	*%rax
    2146:      	leaq	0x11c(%r14), %rdi
    214d:      	movl	$0x118, %edx            # imm = 0x118
    2152:      	movq	0x50(%rsp), %rcx
    2157:      	addq	%rdx, %rcx
    215a:      	movl	$0x4, %esi
    215f:      	movl	$0x4, %eax
    2164:      	addq	0x50(%rsp), %rdx
    2169:      	movl	$0x4, %esi
    216e:      	callq	*%rax
    2170:      	leaq	0x120(%r14), %rdi
    2177:      	movl	$0x98, %r15d
    217d:      	movq	0x58(%rsp), %rcx
    2182:      	addq	%r15, %rcx
    2185:      	movl	$0x4, %edx
    218a:      	movl	$0x4, %eax
    218f:      	movq	0x58(%rsp), %rdx
    2194:      	addq	%r15, %rdx
    2197:      	movl	$0x4, %esi
    219c:      	callq	*%rax
    219e:      	leaq	0x124(%r14), %rdi
    21a5:      	movq	0x60(%rsp), %rcx
    21aa:      	addq	%r15, %rcx
    21ad:      	movl	$0x4, %edx
    21b2:      	movl	$0x4, %eax
    21b7:      	addq	0x60(%rsp), %r15
    21bc:      	movl	$0x4, %esi
    21c1:      	movq	%r15, %rdx
    21c4:      	callq	*%rax
    21c6:      	leaq	0x128(%r14), %rdi
    21cd:      	movq	0x68(%rsp), %rcx
    21d2:      	addq	$0x58, %rcx
    21d6:      	movl	$0x4, %edx
    21db:      	movl	$0x4, %eax
    21e0:      	movq	0x68(%rsp), %rdx
    21e5:      	addq	$0x58, %rdx
    21e9:      	movl	$0x4, %esi
    21ee:      	callq	*%rax
    21f0:      	movq	$0x0, 0x8(%rsp)
    21f9:      	movq	$0x0, 0x20(%rsp)
    2202:      	leaq	0x8(%rsp), %rdi
    2207:      	movl	$0x8, %ecx
    220c:      	movl	$0x4, %eax
    2211:      	movl	$0x8, %esi
    2216:      	movq	%r12, %rdx
    2219:      	callq	*%rax
    221b:      	movl	$0x90, %edx
    2220:      	movq	0x8(%rsp), %rcx
    2225:      	addq	%rdx, %rcx
    2228:      	leaq	0x20(%rsp), %rdi
    222d:      	movl	$0x8, %esi
    2232:      	movl	$0x4, %eax
    2237:      	addq	0x8(%rsp), %rdx
    223c:      	movl	$0x8, %esi
    2241:      	callq	*%rax
    2243:      	movq	%r14, %rdi
    2246:      	addq	$0x12c, %rdi            # imm = 0x12C
    224d:      	movq	0x20(%rsp), %rcx
    2252:      	addq	%rbx, %rcx
    2255:      	movl	$0x4, %edx
    225a:      	movl	$0x4, %eax
    225f:      	addq	0x20(%rsp), %rbx
    2264:      	movl	$0x4, %esi
    2269:      	movq	%rbx, %rdx
    226c:      	callq	*%rax
    226e:      	movq	$0x0, 0x138(%r14)
    2279:      	movq	$0x0, 0x130(%r14)
    2284:      	movq	(%rip), %rsi            # 0x228b <event_execve+0x228b>
    228b:      	xorl	%ecx, %ecx
    228d:      	movl	$0xc, %eax
    2292:      	movq	%r13, %rdi
    2295:      	xorl	%edx, %edx
    2297:      	callq	*%rax
    2299:      	xorl	%eax, %eax
    229b:      	addq	$0xc8, %rsp
    22a2:      	popq	%rbx
    22a3:      	popq	%r12
    22a5:      	popq	%r13
    22a7:      	popq	%r14
    22a9:      	popq	%r15
    22ab:      	popq	%rbp
    22ac:      	retq
    22ad:      	leaq	-0x10(%rbx), %rdx
    22b1:      	movq	%rsp, %rdi
    22b4:      	movl	$0x8, %ecx
    22b9:      	movl	$0x4, %eax
    22be:      	movl	$0x8, %esi
    22c3:      	callq	*%rax
    22c5:      	movq	0x50(%rsp), %rax
    22ca:      	cmpq	(%rsp), %rax
    22ce:      	je	0x1b71 <event_execve+0x1b71>
    22d4:      	addq	$-0x8, %rbx
    22d8:      	movl	$0x8, %ecx
    22dd:      	movl	$0x4, %eax
    22e2:      	leaq	0x40(%rsp), %rdi
    22e7:      	movl	$0x8, %esi
    22ec:      	movq	%rbx, %rdx
    22ef:      	callq	*%rax
    22f1:      	movq	(%rsp), %rbx
    22f5:      	movq	%rbx, 0x50(%rsp)
    22fa:      	leaq	0x20(%rbx), %rdx
    22fe:      	movq	%rdx, 0x48(%rsp)
    2303:      	movq	0x40(%rsp), %r15
    2308:      	cmpq	0x28(%rsp), %r15
    230d:      	jne	0x231a <event_execve+0x231a>
    230f:      	cmpq	0x30(%rsp), %rdx
    2314:      	je	0x1b71 <event_execve+0x1b71>
    231a:      	leaq	0x70(%rsp), %rdi
    231f:      	movl	$0x8, %ecx
    2324:      	movl	$0x4, %eax
    2329:      	movl	$0x8, %esi
    232e:      	callq	*%rax
    2330:      	cmpq	0x70(%rsp), %r15
    2335:      	je	0x243b <event_execve+0x243b>
    233b:      	leaq	0x18(%r15), %r12
    233f:      	movq	%rsp, %rdi
    2342:      	movl	$0x8, %ecx
    2347:      	movl	$0x4, %eax
    234c:      	movl	$0x8, %esi
    2351:      	movq	%r12, %rdx
    2354:      	callq	*%rax
    2356:      	cmpq	%r15, (%rsp)
    235a:      	je	0x243b <event_execve+0x243b>
    2360:      	leaq	0x20(%rsp), %rdi
    2365:      	movl	$0x8, %ecx
    236a:      	movl	$0x4, %eax
    236f:      	movl	$0x8, %esi
    2374:      	movq	%r12, %rdx
    2377:      	callq	*%rax
    2379:      	addq	$0x20, %r15
    237d:      	leaq	0x8(%rsp), %rdi
    2382:      	movl	$0x10, %ecx
    2387:      	movl	$0x4, %eax
    238c:      	movl	$0x10, %esi
    2391:      	movq	%r15, %rdx
    2394:      	callq	*%rax
    2396:      	movq	0x38(%rsp), %rbx
    239b:      	movq	0x58(%rsp), %rax
    23a0:      	movl	0xc(%rsp), %ebp
    23a4:      	subq	%rbx, %rax
    23a7:      	movl	0x60(%rsp), %r15d
    23ac:      	xorl	%ecx, %ecx
    23ae:      	movl	%ebp, %edx
    23b0:      	subl	%r15d, %edx
    23b3:      	cmovbl	%ecx, %edx
    23b6:      	addq	0x10(%rsp), %rdx
    23bb:      	xorl	%esi, %esi
    23bd:      	cmpl	%ebp, %r15d
    23c0:      	seta	%sil
    23c4:      	movl	%ebp, %ecx
    23c6:      	cmovbl	%r15d, %ecx
    23ca:      	addl	%ecx, %esi
    23cc:      	movl	%r15d, %edi
    23cf:      	subl	%esi, %edi
    23d1:      	movl	%edi, 0x60(%rsp)
    23d5:      	subq	%rsi, %rax
    23d8:      	movq	0x18(%rsp), %rdi
    23dd:      	jb	0x1b7b <event_execve+0x1b7b>
    23e3:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    23e9:      	ja	0x1b7b <event_execve+0x1b7b>
    23ef:      	movq	%rdi, %r12
    23f2:      	cmpl	%ebp, %r15d
    23f5:      	jbe	0x23fb <event_execve+0x23fb>
    23f7:      	movb	$0x2f, (%rbx,%rax)
    23fb:      	xorl	%edi, %edi
    23fd:      	cmpl	%ebp, %r15d
    2400:      	seta	%dil
    2404:      	movzbl	%cl, %esi
    2407:      	addq	%rax, %rbx
    240a:      	addq	%rbx, %rdi
    240d:      	movl	$0x4, %eax
    2412:      	callq	*%rax
    2414:      	movq	%rbx, 0x58(%rsp)
    2419:      	cmpl	%ebp, %r15d
    241c:      	movq	%r12, %rdi
    241f:      	jbe	0x1b7b <event_execve+0x1b7b>
    2425:      	movq	0x20(%rsp), %r15
    242a:      	movq	%r15, 0x40(%rsp)
    242f:      	movq	0x48(%rsp), %rdx
    2434:      	movq	0x50(%rsp), %rbx
    2439:      	jmp	0x2496 <event_execve+0x2496>
    243b:      	leaq	0x10(%rbx), %rdx
    243f:      	movq	%rsp, %rdi
    2442:      	movl	$0x8, %ecx
    2447:      	movl	$0x4, %eax
    244c:      	movl	$0x8, %esi
    2451:      	callq	*%rax
    2453:      	movq	0x50(%rsp), %rax
    2458:      	cmpq	(%rsp), %rax
    245c:      	je	0x1b71 <event_execve+0x1b71>
    2462:      	addq	$0x18, %rbx
    2466:      	movl	$0x8, %ecx
    246b:      	movl	$0x4, %eax
    2470:      	leaq	0x40(%rsp), %rdi
    2475:      	movl	$0x8, %esi
    247a:      	movq	%rbx, %rdx
    247d:      	callq	*%rax
    247f:      	movq	(%rsp), %rbx
    2483:      	movq	%rbx, 0x50(%rsp)
    2488:      	leaq	0x20(%rbx), %rdx
    248c:      	movq	%rdx, 0x48(%rsp)
    2491:      	movq	0x40(%rsp), %r15
    2496:      	cmpq	0x28(%rsp), %r15
    249b:      	jne	0x24a8 <event_execve+0x24a8>
    249d:      	cmpq	0x30(%rsp), %rdx
    24a2:      	je	0x1b71 <event_execve+0x1b71>
    24a8:      	leaq	0x70(%rsp), %rdi
    24ad:      	movl	$0x8, %ecx
    24b2:      	movl	$0x4, %eax
    24b7:      	movl	$0x8, %esi
    24bc:      	callq	*%rax
    24be:      	cmpq	0x70(%rsp), %r15
    24c3:      	je	0x25c9 <event_execve+0x25c9>
    24c9:      	leaq	0x18(%r15), %r12
    24cd:      	movq	%rsp, %rdi
    24d0:      	movl	$0x8, %ecx
    24d5:      	movl	$0x4, %eax
    24da:      	movl	$0x8, %esi
    24df:      	movq	%r12, %rdx
    24e2:      	callq	*%rax
    24e4:      	cmpq	%r15, (%rsp)
    24e8:      	je	0x25c9 <event_execve+0x25c9>
    24ee:      	leaq	0x20(%rsp), %rdi
    24f3:      	movl	$0x8, %ecx
    24f8:      	movl	$0x4, %eax
    24fd:      	movl	$0x8, %esi
    2502:      	movq	%r12, %rdx
    2505:      	callq	*%rax
    2507:      	addq	$0x20, %r15
    250b:      	leaq	0x8(%rsp), %rdi
    2510:      	movl	$0x10, %ecx
    2515:      	movl	$0x4, %eax
    251a:      	movl	$0x10, %esi
    251f:      	movq	%r15, %rdx
    2522:      	callq	*%rax
    2524:      	movq	0x38(%rsp), %rbx
    2529:      	movq	0x58(%rsp), %rax
    252e:      	movl	0xc(%rsp), %ebp
    2532:      	subq	%rbx, %rax
    2535:      	movl	0x60(%rsp), %r15d
    253a:      	xorl	%ecx, %ecx
    253c:      	movl	%ebp, %edx
    253e:      	subl	%r15d, %edx
    2541:      	cmovbl	%ecx, %edx
    2544:      	addq	0x10(%rsp), %rdx
    2549:      	xorl	%esi, %esi
    254b:      	cmpl	%ebp, %r15d
    254e:      	seta	%sil
    2552:      	movl	%ebp, %ecx
    2554:      	cmovbl	%r15d, %ecx
    2558:      	addl	%ecx, %esi
    255a:      	movl	%r15d, %edi
    255d:      	subl	%esi, %edi
    255f:      	movl	%edi, 0x60(%rsp)
    2563:      	subq	%rsi, %rax
    2566:      	movq	0x18(%rsp), %rdi
    256b:      	jb	0x1b7b <event_execve+0x1b7b>
    2571:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    2577:      	ja	0x1b7b <event_execve+0x1b7b>
    257d:      	movq	%rdi, %r12
    2580:      	cmpl	%ebp, %r15d
    2583:      	jbe	0x2589 <event_execve+0x2589>
    2585:      	movb	$0x2f, (%rbx,%rax)
    2589:      	xorl	%edi, %edi
    258b:      	cmpl	%ebp, %r15d
    258e:      	seta	%dil
    2592:      	movzbl	%cl, %esi
    2595:      	addq	%rax, %rbx
    2598:      	addq	%rbx, %rdi
    259b:      	movl	$0x4, %eax
    25a0:      	callq	*%rax
    25a2:      	movq	%rbx, 0x58(%rsp)
    25a7:      	cmpl	%ebp, %r15d
    25aa:      	movq	%r12, %rdi
    25ad:      	jbe	0x1b7b <event_execve+0x1b7b>
    25b3:      	movq	0x20(%rsp), %r15
    25b8:      	movq	%r15, 0x40(%rsp)
    25bd:      	movq	0x48(%rsp), %rdx
    25c2:      	movq	0x50(%rsp), %rbx
    25c7:      	jmp	0x2624 <event_execve+0x2624>
    25c9:      	leaq	0x10(%rbx), %rdx
    25cd:      	movq	%rsp, %rdi
    25d0:      	movl	$0x8, %ecx
    25d5:      	movl	$0x4, %eax
    25da:      	movl	$0x8, %esi
    25df:      	callq	*%rax
    25e1:      	movq	0x50(%rsp), %rax
    25e6:      	cmpq	(%rsp), %rax
    25ea:      	je	0x1b71 <event_execve+0x1b71>
    25f0:      	addq	$0x18, %rbx
    25f4:      	movl	$0x8, %ecx
    25f9:      	movl	$0x4, %eax
    25fe:      	leaq	0x40(%rsp), %rdi
    2603:      	movl	$0x8, %esi
    2608:      	movq	%rbx, %rdx
    260b:      	callq	*%rax
    260d:      	movq	(%rsp), %rbx
    2611:      	movq	%rbx, 0x50(%rsp)
    2616:      	leaq	0x20(%rbx), %rdx
    261a:      	movq	%rdx, 0x48(%rsp)
    261f:      	movq	0x40(%rsp), %r15
    2624:      	cmpq	0x28(%rsp), %r15
    2629:      	jne	0x2636 <event_execve+0x2636>
    262b:      	cmpq	0x30(%rsp), %rdx
    2630:      	je	0x1b71 <event_execve+0x1b71>
    2636:      	leaq	0x70(%rsp), %rdi
    263b:      	movl	$0x8, %ecx
    2640:      	movl	$0x4, %eax
    2645:      	movl	$0x8, %esi
    264a:      	callq	*%rax
    264c:      	cmpq	0x70(%rsp), %r15
    2651:      	je	0x2760 <event_execve+0x2760>
    2657:      	leaq	0x18(%r15), %r12
    265b:      	movq	%rsp, %rdi
    265e:      	movl	$0x8, %ecx
    2663:      	movl	$0x4, %eax
    2668:      	movl	$0x8, %esi
    266d:      	movq	%r12, %rdx
    2670:      	callq	*%rax
    2672:      	cmpq	%r15, (%rsp)
    2676:      	je	0x2760 <event_execve+0x2760>
    267c:      	leaq	0x20(%rsp), %rdi
    2681:      	movl	$0x8, %ecx
    2686:      	movl	$0x4, %eax
    268b:      	movl	$0x8, %esi
    2690:      	movq	%r12, %rdx
    2693:      	callq	*%rax
    2695:      	addq	$0x20, %r15
    2699:      	leaq	0x8(%rsp), %rdi
    269e:      	movl	$0x10, %ecx
    26a3:      	movl	$0x4, %eax
    26a8:      	movl	$0x10, %esi
    26ad:      	movq	%r15, %rdx
    26b0:      	callq	*%rax
    26b2:      	movq	0x38(%rsp), %rbx
    26b7:      	movq	0x58(%rsp), %rax
    26bc:      	movl	0xc(%rsp), %ebp
    26c0:      	subq	%rbx, %rax
    26c3:      	movl	0x60(%rsp), %r15d
    26c8:      	xorl	%ecx, %ecx
    26ca:      	movl	%ebp, %edx
    26cc:      	subl	%r15d, %edx
    26cf:      	cmovbl	%ecx, %edx
    26d2:      	addq	0x10(%rsp), %rdx
    26d7:      	xorl	%esi, %esi
    26d9:      	cmpl	%ebp, %r15d
    26dc:      	seta	%sil
    26e0:      	movl	%ebp, %ecx
    26e2:      	cmovbl	%r15d, %ecx
    26e6:      	addl	%ecx, %esi
    26e8:      	movl	%r15d, %edi
    26eb:      	subl	%esi, %edi
    26ed:      	movl	%edi, 0x60(%rsp)
    26f1:      	subq	%rsi, %rax
    26f4:      	movq	0x18(%rsp), %rdi
    26f9:      	jb	0x1b7b <event_execve+0x1b7b>
    26ff:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    2705:      	ja	0x1b7b <event_execve+0x1b7b>
    270b:      	cmpl	%ebp, %r15d
    270e:      	jbe	0x2714 <event_execve+0x2714>
    2710:      	movb	$0x2f, (%rbx,%rax)
    2714:      	xorl	%edi, %edi
    2716:      	cmpl	%ebp, %r15d
    2719:      	seta	%dil
    271d:      	movzbl	%cl, %esi
    2720:      	addq	%rax, %rbx
    2723:      	addq	%rbx, %rdi
    2726:      	movl	$0x4, %eax
    272b:      	callq	*%rax
    272d:      	movq	%rbx, 0x58(%rsp)
    2732:      	cmpl	%ebp, %r15d
    2735:      	movq	0x18(%rsp), %rdi
    273a:      	jbe	0x1b7b <event_execve+0x1b7b>
    2740:      	movq	0x20(%rsp), %r15
    2745:      	movq	%r15, 0x40(%rsp)
    274a:      	movq	0x48(%rsp), %rdx
    274f:      	movq	0x50(%rsp), %rbx
    2754:      	jmp	0x27bb <event_execve+0x27bb>
    2756:      	movq	%r15, 0x18(%rsp)
    275b:      	jmp	0x1148 <event_execve+0x1148>
    2760:      	leaq	0x10(%rbx), %rdx
    2764:      	movq	%rsp, %rdi
    2767:      	movl	$0x8, %ecx
    276c:      	movl	$0x4, %eax
    2771:      	movl	$0x8, %esi
    2776:      	callq	*%rax
    2778:      	movq	0x50(%rsp), %rax
    277d:      	cmpq	(%rsp), %rax
    2781:      	je	0x1b71 <event_execve+0x1b71>
    2787:      	addq	$0x18, %rbx
    278b:      	movl	$0x8, %ecx
    2790:      	movl	$0x4, %eax
    2795:      	leaq	0x40(%rsp), %rdi
    279a:      	movl	$0x8, %esi
    279f:      	movq	%rbx, %rdx
    27a2:      	callq	*%rax
    27a4:      	movq	(%rsp), %rbx
    27a8:      	movq	%rbx, 0x50(%rsp)
    27ad:      	leaq	0x20(%rbx), %rdx
    27b1:      	movq	%rdx, 0x48(%rsp)
    27b6:      	movq	0x40(%rsp), %r15
    27bb:      	cmpq	0x28(%rsp), %r15
    27c0:      	jne	0x27cd <event_execve+0x27cd>
    27c2:      	cmpq	0x30(%rsp), %rdx
    27c7:      	je	0x1b71 <event_execve+0x1b71>
    27cd:      	leaq	0x70(%rsp), %rdi
    27d2:      	movl	$0x8, %ecx
    27d7:      	movl	$0x4, %eax
    27dc:      	movl	$0x8, %esi
    27e1:      	callq	*%rax
    27e3:      	cmpq	0x70(%rsp), %r15
    27e8:      	je	0x28ed <event_execve+0x28ed>
    27ee:      	leaq	0x18(%r15), %r12
    27f2:      	movq	%rsp, %rdi
    27f5:      	movl	$0x8, %ecx
    27fa:      	movl	$0x4, %eax
    27ff:      	movl	$0x8, %esi
    2804:      	movq	%r12, %rdx
    2807:      	callq	*%rax
    2809:      	cmpq	%r15, (%rsp)
    280d:      	je	0x28ed <event_execve+0x28ed>
    2813:      	leaq	0x20(%rsp), %rdi
    2818:      	movl	$0x8, %ecx
    281d:      	movl	$0x4, %eax
    2822:      	movl	$0x8, %esi
    2827:      	movq	%r12, %rdx
    282a:      	callq	*%rax
    282c:      	addq	$0x20, %r15
    2830:      	leaq	0x8(%rsp), %rdi
    2835:      	movl	$0x10, %ecx
    283a:      	movl	$0x4, %eax
    283f:      	movl	$0x10, %esi
    2844:      	movq	%r15, %rdx
    2847:      	callq	*%rax
    2849:      	movq	0x38(%rsp), %rbx
    284e:      	movq	0x58(%rsp), %rax
    2853:      	movl	0xc(%rsp), %ebp
    2857:      	subq	%rbx, %rax
    285a:      	movl	0x60(%rsp), %r15d
    285f:      	xorl	%ecx, %ecx
    2861:      	movl	%ebp, %edx
    2863:      	subl	%r15d, %edx
    2866:      	cmovbl	%ecx, %edx
    2869:      	addq	0x10(%rsp), %rdx
    286e:      	xorl	%esi, %esi
    2870:      	cmpl	%ebp, %r15d
    2873:      	seta	%sil
    2877:      	movl	%ebp, %ecx
    2879:      	cmovbl	%r15d, %ecx
    287d:      	addl	%ecx, %esi
    287f:      	movl	%r15d, %edi
    2882:      	subl	%esi, %edi
    2884:      	movl	%edi, 0x60(%rsp)
    2888:      	subq	%rsi, %rax
    288b:      	movq	0x18(%rsp), %rdi
    2890:      	jb	0x1b7b <event_execve+0x1b7b>
    2896:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    289c:      	ja	0x1b7b <event_execve+0x1b7b>
    28a2:      	cmpl	%ebp, %r15d
    28a5:      	jbe	0x28ab <event_execve+0x28ab>
    28a7:      	movb	$0x2f, (%rbx,%rax)
    28ab:      	xorl	%edi, %edi
    28ad:      	cmpl	%ebp, %r15d
    28b0:      	seta	%dil
    28b4:      	movzbl	%cl, %esi
    28b7:      	addq	%rax, %rbx
    28ba:      	addq	%rbx, %rdi
    28bd:      	movl	$0x4, %eax
    28c2:      	callq	*%rax
    28c4:      	movq	%rbx, 0x58(%rsp)
    28c9:      	cmpl	%ebp, %r15d
    28cc:      	movq	0x18(%rsp), %rdi
    28d1:      	jbe	0x1b7b <event_execve+0x1b7b>
    28d7:      	movq	0x20(%rsp), %r15
    28dc:      	movq	%r15, 0x40(%rsp)
    28e1:      	movq	0x48(%rsp), %rdx
    28e6:      	movq	0x50(%rsp), %rbx
    28eb:      	jmp	0x2948 <event_execve+0x2948>
    28ed:      	leaq	0x10(%rbx), %rdx
    28f1:      	movq	%rsp, %rdi
    28f4:      	movl	$0x8, %ecx
    28f9:      	movl	$0x4, %eax
    28fe:      	movl	$0x8, %esi
    2903:      	callq	*%rax
    2905:      	movq	0x50(%rsp), %rax
    290a:      	cmpq	(%rsp), %rax
    290e:      	je	0x1b71 <event_execve+0x1b71>
    2914:      	addq	$0x18, %rbx
    2918:      	movl	$0x8, %ecx
    291d:      	movl	$0x4, %eax
    2922:      	leaq	0x40(%rsp), %rdi
    2927:      	movl	$0x8, %esi
    292c:      	movq	%rbx, %rdx
    292f:      	callq	*%rax
    2931:      	movq	(%rsp), %rbx
    2935:      	movq	%rbx, 0x50(%rsp)
    293a:      	leaq	0x20(%rbx), %rdx
    293e:      	movq	%rdx, 0x48(%rsp)
    2943:      	movq	0x40(%rsp), %r15
    2948:      	cmpq	0x28(%rsp), %r15
    294d:      	jne	0x295a <event_execve+0x295a>
    294f:      	cmpq	0x30(%rsp), %rdx
    2954:      	je	0x1b71 <event_execve+0x1b71>
    295a:      	leaq	0x70(%rsp), %rdi
    295f:      	movl	$0x8, %ecx
    2964:      	movl	$0x4, %eax
    2969:      	movl	$0x8, %esi
    296e:      	callq	*%rax
    2970:      	cmpq	0x70(%rsp), %r15
    2975:      	je	0x2a7a <event_execve+0x2a7a>
    297b:      	leaq	0x18(%r15), %r12
    297f:      	movq	%rsp, %rdi
    2982:      	movl	$0x8, %ecx
    2987:      	movl	$0x4, %eax
    298c:      	movl	$0x8, %esi
    2991:      	movq	%r12, %rdx
    2994:      	callq	*%rax
    2996:      	cmpq	%r15, (%rsp)
    299a:      	je	0x2a7a <event_execve+0x2a7a>
    29a0:      	leaq	0x20(%rsp), %rdi
    29a5:      	movl	$0x8, %ecx
    29aa:      	movl	$0x4, %eax
    29af:      	movl	$0x8, %esi
    29b4:      	movq	%r12, %rdx
    29b7:      	callq	*%rax
    29b9:      	addq	$0x20, %r15
    29bd:      	leaq	0x8(%rsp), %rdi
    29c2:      	movl	$0x10, %ecx
    29c7:      	movl	$0x4, %eax
    29cc:      	movl	$0x10, %esi
    29d1:      	movq	%r15, %rdx
    29d4:      	callq	*%rax
    29d6:      	movq	0x38(%rsp), %rbx
    29db:      	movq	0x58(%rsp), %rax
    29e0:      	movl	0xc(%rsp), %ebp
    29e4:      	subq	%rbx, %rax
    29e7:      	movl	0x60(%rsp), %r15d
    29ec:      	xorl	%ecx, %ecx
    29ee:      	movl	%ebp, %edx
    29f0:      	subl	%r15d, %edx
    29f3:      	cmovbl	%ecx, %edx
    29f6:      	addq	0x10(%rsp), %rdx
    29fb:      	xorl	%esi, %esi
    29fd:      	cmpl	%ebp, %r15d
    2a00:      	seta	%sil
    2a04:      	movl	%ebp, %ecx
    2a06:      	cmovbl	%r15d, %ecx
    2a0a:      	addl	%ecx, %esi
    2a0c:      	movl	%r15d, %edi
    2a0f:      	subl	%esi, %edi
    2a11:      	movl	%edi, 0x60(%rsp)
    2a15:      	subq	%rsi, %rax
    2a18:      	movq	0x18(%rsp), %rdi
    2a1d:      	jb	0x1b7b <event_execve+0x1b7b>
    2a23:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    2a29:      	ja	0x1b7b <event_execve+0x1b7b>
    2a2f:      	cmpl	%ebp, %r15d
    2a32:      	jbe	0x2a38 <event_execve+0x2a38>
    2a34:      	movb	$0x2f, (%rbx,%rax)
    2a38:      	xorl	%edi, %edi
    2a3a:      	cmpl	%ebp, %r15d
    2a3d:      	seta	%dil
    2a41:      	movzbl	%cl, %esi
    2a44:      	addq	%rax, %rbx
    2a47:      	addq	%rbx, %rdi
    2a4a:      	movl	$0x4, %eax
    2a4f:      	callq	*%rax
    2a51:      	movq	%rbx, 0x58(%rsp)
    2a56:      	cmpl	%ebp, %r15d
    2a59:      	movq	0x18(%rsp), %rdi
    2a5e:      	jbe	0x1b7b <event_execve+0x1b7b>
    2a64:      	movq	0x20(%rsp), %r15
    2a69:      	movq	%r15, 0x40(%rsp)
    2a6e:      	movq	0x48(%rsp), %rdx
    2a73:      	movq	0x50(%rsp), %rbx
    2a78:      	jmp	0x2ad5 <event_execve+0x2ad5>
    2a7a:      	leaq	0x10(%rbx), %rdx
    2a7e:      	movq	%rsp, %rdi
    2a81:      	movl	$0x8, %ecx
    2a86:      	movl	$0x4, %eax
    2a8b:      	movl	$0x8, %esi
    2a90:      	callq	*%rax
    2a92:      	movq	0x50(%rsp), %rax
    2a97:      	cmpq	(%rsp), %rax
    2a9b:      	je	0x1b71 <event_execve+0x1b71>
    2aa1:      	addq	$0x18, %rbx
    2aa5:      	movl	$0x8, %ecx
    2aaa:      	movl	$0x4, %eax
    2aaf:      	leaq	0x40(%rsp), %rdi
    2ab4:      	movl	$0x8, %esi
    2ab9:      	movq	%rbx, %rdx
    2abc:      	callq	*%rax
    2abe:      	movq	(%rsp), %rbx
    2ac2:      	movq	%rbx, 0x50(%rsp)
    2ac7:      	leaq	0x20(%rbx), %rdx
    2acb:      	movq	%rdx, 0x48(%rsp)
    2ad0:      	movq	0x40(%rsp), %r15
    2ad5:      	cmpq	0x28(%rsp), %r15
    2ada:      	jne	0x2ae7 <event_execve+0x2ae7>
    2adc:      	cmpq	0x30(%rsp), %rdx
    2ae1:      	je	0x1b71 <event_execve+0x1b71>
    2ae7:      	leaq	0x70(%rsp), %rdi
    2aec:      	movl	$0x8, %ecx
    2af1:      	movl	$0x4, %eax
    2af6:      	movl	$0x8, %esi
    2afb:      	callq	*%rax
    2afd:      	cmpq	0x70(%rsp), %r15
    2b02:      	je	0x2c07 <event_execve+0x2c07>
    2b08:      	leaq	0x18(%r15), %r12
    2b0c:      	movq	%rsp, %rdi
    2b0f:      	movl	$0x8, %ecx
    2b14:      	movl	$0x4, %eax
    2b19:      	movl	$0x8, %esi
    2b1e:      	movq	%r12, %rdx
    2b21:      	callq	*%rax
    2b23:      	cmpq	%r15, (%rsp)
    2b27:      	je	0x2c07 <event_execve+0x2c07>
    2b2d:      	leaq	0x20(%rsp), %rdi
    2b32:      	movl	$0x8, %ecx
    2b37:      	movl	$0x4, %eax
    2b3c:      	movl	$0x8, %esi
    2b41:      	movq	%r12, %rdx
    2b44:      	callq	*%rax
    2b46:      	addq	$0x20, %r15
    2b4a:      	leaq	0x8(%rsp), %rdi
    2b4f:      	movl	$0x10, %ecx
    2b54:      	movl	$0x4, %eax
    2b59:      	movl	$0x10, %esi
    2b5e:      	movq	%r15, %rdx
    2b61:      	callq	*%rax
    2b63:      	movq	0x38(%rsp), %rbx
    2b68:      	movq	0x58(%rsp), %rax
    2b6d:      	movl	0xc(%rsp), %ebp
    2b71:      	subq	%rbx, %rax
    2b74:      	movl	0x60(%rsp), %r15d
    2b79:      	xorl	%ecx, %ecx
    2b7b:      	movl	%ebp, %edx
    2b7d:      	subl	%r15d, %edx
    2b80:      	cmovbl	%ecx, %edx
    2b83:      	addq	0x10(%rsp), %rdx
    2b88:      	xorl	%esi, %esi
    2b8a:      	cmpl	%ebp, %r15d
    2b8d:      	seta	%sil
    2b91:      	movl	%ebp, %ecx
    2b93:      	cmovbl	%r15d, %ecx
    2b97:      	addl	%ecx, %esi
    2b99:      	movl	%r15d, %edi
    2b9c:      	subl	%esi, %edi
    2b9e:      	movl	%edi, 0x60(%rsp)
    2ba2:      	subq	%rsi, %rax
    2ba5:      	movq	0x18(%rsp), %rdi
    2baa:      	jb	0x1b7b <event_execve+0x1b7b>
    2bb0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    2bb6:      	ja	0x1b7b <event_execve+0x1b7b>
    2bbc:      	cmpl	%ebp, %r15d
    2bbf:      	jbe	0x2bc5 <event_execve+0x2bc5>
    2bc1:      	movb	$0x2f, (%rbx,%rax)
    2bc5:      	xorl	%edi, %edi
    2bc7:      	cmpl	%ebp, %r15d
    2bca:      	seta	%dil
    2bce:      	movzbl	%cl, %esi
    2bd1:      	addq	%rax, %rbx
    2bd4:      	addq	%rbx, %rdi
    2bd7:      	movl	$0x4, %eax
    2bdc:      	callq	*%rax
    2bde:      	movq	%rbx, 0x58(%rsp)
    2be3:      	cmpl	%ebp, %r15d
    2be6:      	movq	0x18(%rsp), %rdi
    2beb:      	jbe	0x1b7b <event_execve+0x1b7b>
    2bf1:      	movq	0x20(%rsp), %r15
    2bf6:      	movq	%r15, 0x40(%rsp)
    2bfb:      	movq	0x48(%rsp), %rdx
    2c00:      	movq	0x50(%rsp), %rbx
    2c05:      	jmp	0x2c62 <event_execve+0x2c62>
    2c07:      	leaq	0x10(%rbx), %rdx
    2c0b:      	movq	%rsp, %rdi
    2c0e:      	movl	$0x8, %ecx
    2c13:      	movl	$0x4, %eax
    2c18:      	movl	$0x8, %esi
    2c1d:      	callq	*%rax
    2c1f:      	movq	0x50(%rsp), %rax
    2c24:      	cmpq	(%rsp), %rax
    2c28:      	je	0x1b71 <event_execve+0x1b71>
    2c2e:      	addq	$0x18, %rbx
    2c32:      	movl	$0x8, %ecx
    2c37:      	movl	$0x4, %eax
    2c3c:      	leaq	0x40(%rsp), %rdi
    2c41:      	movl	$0x8, %esi
    2c46:      	movq	%rbx, %rdx
    2c49:      	callq	*%rax
    2c4b:      	movq	(%rsp), %rbx
    2c4f:      	movq	%rbx, 0x50(%rsp)
    2c54:      	leaq	0x20(%rbx), %rdx
    2c58:      	movq	%rdx, 0x48(%rsp)
    2c5d:      	movq	0x40(%rsp), %r15
    2c62:      	cmpq	0x28(%rsp), %r15
    2c67:      	jne	0x2c74 <event_execve+0x2c74>
    2c69:      	cmpq	0x30(%rsp), %rdx
    2c6e:      	je	0x1b71 <event_execve+0x1b71>
    2c74:      	leaq	0x70(%rsp), %rdi
    2c79:      	movl	$0x8, %ecx
    2c7e:      	movl	$0x4, %eax
    2c83:      	movl	$0x8, %esi
    2c88:      	callq	*%rax
    2c8a:      	cmpq	0x70(%rsp), %r15
    2c8f:      	je	0x2d94 <event_execve+0x2d94>
    2c95:      	leaq	0x18(%r15), %r12
    2c99:      	movq	%rsp, %rdi
    2c9c:      	movl	$0x8, %ecx
    2ca1:      	movl	$0x4, %eax
    2ca6:      	movl	$0x8, %esi
    2cab:      	movq	%r12, %rdx
    2cae:      	callq	*%rax
    2cb0:      	cmpq	%r15, (%rsp)
    2cb4:      	je	0x2d94 <event_execve+0x2d94>
    2cba:      	leaq	0x20(%rsp), %rdi
    2cbf:      	movl	$0x8, %ecx
    2cc4:      	movl	$0x4, %eax
    2cc9:      	movl	$0x8, %esi
    2cce:      	movq	%r12, %rdx
    2cd1:      	callq	*%rax
    2cd3:      	addq	$0x20, %r15
    2cd7:      	leaq	0x8(%rsp), %rdi
    2cdc:      	movl	$0x10, %ecx
    2ce1:      	movl	$0x4, %eax
    2ce6:      	movl	$0x10, %esi
    2ceb:      	movq	%r15, %rdx
    2cee:      	callq	*%rax
    2cf0:      	movq	0x38(%rsp), %rbx
    2cf5:      	movq	0x58(%rsp), %rax
    2cfa:      	movl	0xc(%rsp), %ebp
    2cfe:      	subq	%rbx, %rax
    2d01:      	movl	0x60(%rsp), %r15d
    2d06:      	xorl	%ecx, %ecx
    2d08:      	movl	%ebp, %edx
    2d0a:      	subl	%r15d, %edx
    2d0d:      	cmovbl	%ecx, %edx
    2d10:      	addq	0x10(%rsp), %rdx
    2d15:      	xorl	%esi, %esi
    2d17:      	cmpl	%ebp, %r15d
    2d1a:      	seta	%sil
    2d1e:      	movl	%ebp, %ecx
    2d20:      	cmovbl	%r15d, %ecx
    2d24:      	addl	%ecx, %esi
    2d26:      	movl	%r15d, %edi
    2d29:      	subl	%esi, %edi
    2d2b:      	movl	%edi, 0x60(%rsp)
    2d2f:      	subq	%rsi, %rax
    2d32:      	movq	0x18(%rsp), %rdi
    2d37:      	jb	0x1b7b <event_execve+0x1b7b>
    2d3d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    2d43:      	ja	0x1b7b <event_execve+0x1b7b>
    2d49:      	cmpl	%ebp, %r15d
    2d4c:      	jbe	0x2d52 <event_execve+0x2d52>
    2d4e:      	movb	$0x2f, (%rbx,%rax)
    2d52:      	xorl	%edi, %edi
    2d54:      	cmpl	%ebp, %r15d
    2d57:      	seta	%dil
    2d5b:      	movzbl	%cl, %esi
    2d5e:      	addq	%rax, %rbx
    2d61:      	addq	%rbx, %rdi
    2d64:      	movl	$0x4, %eax
    2d69:      	callq	*%rax
    2d6b:      	movq	%rbx, 0x58(%rsp)
    2d70:      	cmpl	%ebp, %r15d
    2d73:      	movq	0x18(%rsp), %rdi
    2d78:      	jbe	0x1b7b <event_execve+0x1b7b>
    2d7e:      	movq	0x20(%rsp), %r15
    2d83:      	movq	%r15, 0x40(%rsp)
    2d88:      	movq	0x48(%rsp), %rdx
    2d8d:      	movq	0x50(%rsp), %rbx
    2d92:      	jmp	0x2def <event_execve+0x2def>
    2d94:      	leaq	0x10(%rbx), %rdx
    2d98:      	movq	%rsp, %rdi
    2d9b:      	movl	$0x8, %ecx
    2da0:      	movl	$0x4, %eax
    2da5:      	movl	$0x8, %esi
    2daa:      	callq	*%rax
    2dac:      	movq	0x50(%rsp), %rax
    2db1:      	cmpq	(%rsp), %rax
    2db5:      	je	0x1b71 <event_execve+0x1b71>
    2dbb:      	addq	$0x18, %rbx
    2dbf:      	movl	$0x8, %ecx
    2dc4:      	movl	$0x4, %eax
    2dc9:      	leaq	0x40(%rsp), %rdi
    2dce:      	movl	$0x8, %esi
    2dd3:      	movq	%rbx, %rdx
    2dd6:      	callq	*%rax
    2dd8:      	movq	(%rsp), %rbx
    2ddc:      	movq	%rbx, 0x50(%rsp)
    2de1:      	leaq	0x20(%rbx), %rdx
    2de5:      	movq	%rdx, 0x48(%rsp)
    2dea:      	movq	0x40(%rsp), %r15
    2def:      	cmpq	0x28(%rsp), %r15
    2df4:      	jne	0x2e01 <event_execve+0x2e01>
    2df6:      	cmpq	0x30(%rsp), %rdx
    2dfb:      	je	0x1b71 <event_execve+0x1b71>
    2e01:      	leaq	0x70(%rsp), %rdi
    2e06:      	movl	$0x8, %ecx
    2e0b:      	movl	$0x4, %eax
    2e10:      	movl	$0x8, %esi
    2e15:      	callq	*%rax
    2e17:      	cmpq	0x70(%rsp), %r15
    2e1c:      	je	0x2f21 <event_execve+0x2f21>
    2e22:      	leaq	0x18(%r15), %r12
    2e26:      	movq	%rsp, %rdi
    2e29:      	movl	$0x8, %ecx
    2e2e:      	movl	$0x4, %eax
    2e33:      	movl	$0x8, %esi
    2e38:      	movq	%r12, %rdx
    2e3b:      	callq	*%rax
    2e3d:      	cmpq	%r15, (%rsp)
    2e41:      	je	0x2f21 <event_execve+0x2f21>
    2e47:      	leaq	0x20(%rsp), %rdi
    2e4c:      	movl	$0x8, %ecx
    2e51:      	movl	$0x4, %eax
    2e56:      	movl	$0x8, %esi
    2e5b:      	movq	%r12, %rdx
    2e5e:      	callq	*%rax
    2e60:      	addq	$0x20, %r15
    2e64:      	leaq	0x8(%rsp), %rdi
    2e69:      	movl	$0x10, %ecx
    2e6e:      	movl	$0x4, %eax
    2e73:      	movl	$0x10, %esi
    2e78:      	movq	%r15, %rdx
    2e7b:      	callq	*%rax
    2e7d:      	movq	0x38(%rsp), %rbx
    2e82:      	movq	0x58(%rsp), %rax
    2e87:      	movl	0xc(%rsp), %ebp
    2e8b:      	subq	%rbx, %rax
    2e8e:      	movl	0x60(%rsp), %r15d
    2e93:      	xorl	%ecx, %ecx
    2e95:      	movl	%ebp, %edx
    2e97:      	subl	%r15d, %edx
    2e9a:      	cmovbl	%ecx, %edx
    2e9d:      	addq	0x10(%rsp), %rdx
    2ea2:      	xorl	%esi, %esi
    2ea4:      	cmpl	%ebp, %r15d
    2ea7:      	seta	%sil
    2eab:      	movl	%ebp, %ecx
    2ead:      	cmovbl	%r15d, %ecx
    2eb1:      	addl	%ecx, %esi
    2eb3:      	movl	%r15d, %edi
    2eb6:      	subl	%esi, %edi
    2eb8:      	movl	%edi, 0x60(%rsp)
    2ebc:      	subq	%rsi, %rax
    2ebf:      	movq	0x18(%rsp), %rdi
    2ec4:      	jb	0x1b7b <event_execve+0x1b7b>
    2eca:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    2ed0:      	ja	0x1b7b <event_execve+0x1b7b>
    2ed6:      	cmpl	%ebp, %r15d
    2ed9:      	jbe	0x2edf <event_execve+0x2edf>
    2edb:      	movb	$0x2f, (%rbx,%rax)
    2edf:      	xorl	%edi, %edi
    2ee1:      	cmpl	%ebp, %r15d
    2ee4:      	seta	%dil
    2ee8:      	movzbl	%cl, %esi
    2eeb:      	addq	%rax, %rbx
    2eee:      	addq	%rbx, %rdi
    2ef1:      	movl	$0x4, %eax
    2ef6:      	callq	*%rax
    2ef8:      	movq	%rbx, 0x58(%rsp)
    2efd:      	cmpl	%ebp, %r15d
    2f00:      	movq	0x18(%rsp), %rdi
    2f05:      	jbe	0x1b7b <event_execve+0x1b7b>
    2f0b:      	movq	0x20(%rsp), %r15
    2f10:      	movq	%r15, 0x40(%rsp)
    2f15:      	movq	0x48(%rsp), %rdx
    2f1a:      	movq	0x50(%rsp), %rbx
    2f1f:      	jmp	0x2f7c <event_execve+0x2f7c>
    2f21:      	leaq	0x10(%rbx), %rdx
    2f25:      	movq	%rsp, %rdi
    2f28:      	movl	$0x8, %ecx
    2f2d:      	movl	$0x4, %eax
    2f32:      	movl	$0x8, %esi
    2f37:      	callq	*%rax
    2f39:      	movq	0x50(%rsp), %rax
    2f3e:      	cmpq	(%rsp), %rax
    2f42:      	je	0x1b71 <event_execve+0x1b71>
    2f48:      	addq	$0x18, %rbx
    2f4c:      	movl	$0x8, %ecx
    2f51:      	movl	$0x4, %eax
    2f56:      	leaq	0x40(%rsp), %rdi
    2f5b:      	movl	$0x8, %esi
    2f60:      	movq	%rbx, %rdx
    2f63:      	callq	*%rax
    2f65:      	movq	(%rsp), %rbx
    2f69:      	movq	%rbx, 0x50(%rsp)
    2f6e:      	leaq	0x20(%rbx), %rdx
    2f72:      	movq	%rdx, 0x48(%rsp)
    2f77:      	movq	0x40(%rsp), %r15
    2f7c:      	cmpq	0x28(%rsp), %r15
    2f81:      	jne	0x2f8e <event_execve+0x2f8e>
    2f83:      	cmpq	0x30(%rsp), %rdx
    2f88:      	je	0x1b71 <event_execve+0x1b71>
    2f8e:      	leaq	0x70(%rsp), %rdi
    2f93:      	movl	$0x8, %ecx
    2f98:      	movl	$0x4, %eax
    2f9d:      	movl	$0x8, %esi
    2fa2:      	callq	*%rax
    2fa4:      	cmpq	0x70(%rsp), %r15
    2fa9:      	je	0x30ae <event_execve+0x30ae>
    2faf:      	leaq	0x18(%r15), %r12
    2fb3:      	movq	%rsp, %rdi
    2fb6:      	movl	$0x8, %ecx
    2fbb:      	movl	$0x4, %eax
    2fc0:      	movl	$0x8, %esi
    2fc5:      	movq	%r12, %rdx
    2fc8:      	callq	*%rax
    2fca:      	cmpq	%r15, (%rsp)
    2fce:      	je	0x30ae <event_execve+0x30ae>
    2fd4:      	leaq	0x20(%rsp), %rdi
    2fd9:      	movl	$0x8, %ecx
    2fde:      	movl	$0x4, %eax
    2fe3:      	movl	$0x8, %esi
    2fe8:      	movq	%r12, %rdx
    2feb:      	callq	*%rax
    2fed:      	addq	$0x20, %r15
    2ff1:      	leaq	0x8(%rsp), %rdi
    2ff6:      	movl	$0x10, %ecx
    2ffb:      	movl	$0x4, %eax
    3000:      	movl	$0x10, %esi
    3005:      	movq	%r15, %rdx
    3008:      	callq	*%rax
    300a:      	movq	0x38(%rsp), %rbx
    300f:      	movq	0x58(%rsp), %rax
    3014:      	movl	0xc(%rsp), %ebp
    3018:      	subq	%rbx, %rax
    301b:      	movl	0x60(%rsp), %r15d
    3020:      	xorl	%ecx, %ecx
    3022:      	movl	%ebp, %edx
    3024:      	subl	%r15d, %edx
    3027:      	cmovbl	%ecx, %edx
    302a:      	addq	0x10(%rsp), %rdx
    302f:      	xorl	%esi, %esi
    3031:      	cmpl	%ebp, %r15d
    3034:      	seta	%sil
    3038:      	movl	%ebp, %ecx
    303a:      	cmovbl	%r15d, %ecx
    303e:      	addl	%ecx, %esi
    3040:      	movl	%r15d, %edi
    3043:      	subl	%esi, %edi
    3045:      	movl	%edi, 0x60(%rsp)
    3049:      	subq	%rsi, %rax
    304c:      	movq	0x18(%rsp), %rdi
    3051:      	jb	0x1b7b <event_execve+0x1b7b>
    3057:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    305d:      	ja	0x1b7b <event_execve+0x1b7b>
    3063:      	cmpl	%ebp, %r15d
    3066:      	jbe	0x306c <event_execve+0x306c>
    3068:      	movb	$0x2f, (%rbx,%rax)
    306c:      	xorl	%edi, %edi
    306e:      	cmpl	%ebp, %r15d
    3071:      	seta	%dil
    3075:      	movzbl	%cl, %esi
    3078:      	addq	%rax, %rbx
    307b:      	addq	%rbx, %rdi
    307e:      	movl	$0x4, %eax
    3083:      	callq	*%rax
    3085:      	movq	%rbx, 0x58(%rsp)
    308a:      	cmpl	%ebp, %r15d
    308d:      	movq	0x18(%rsp), %rdi
    3092:      	jbe	0x1b7b <event_execve+0x1b7b>
    3098:      	movq	0x20(%rsp), %r15
    309d:      	movq	%r15, 0x40(%rsp)
    30a2:      	movq	0x48(%rsp), %rdx
    30a7:      	movq	0x50(%rsp), %rbx
    30ac:      	jmp	0x3109 <event_execve+0x3109>
    30ae:      	leaq	0x10(%rbx), %rdx
    30b2:      	movq	%rsp, %rdi
    30b5:      	movl	$0x8, %ecx
    30ba:      	movl	$0x4, %eax
    30bf:      	movl	$0x8, %esi
    30c4:      	callq	*%rax
    30c6:      	movq	0x50(%rsp), %rax
    30cb:      	cmpq	(%rsp), %rax
    30cf:      	je	0x1b71 <event_execve+0x1b71>
    30d5:      	addq	$0x18, %rbx
    30d9:      	movl	$0x8, %ecx
    30de:      	movl	$0x4, %eax
    30e3:      	leaq	0x40(%rsp), %rdi
    30e8:      	movl	$0x8, %esi
    30ed:      	movq	%rbx, %rdx
    30f0:      	callq	*%rax
    30f2:      	movq	(%rsp), %rbx
    30f6:      	movq	%rbx, 0x50(%rsp)
    30fb:      	leaq	0x20(%rbx), %rdx
    30ff:      	movq	%rdx, 0x48(%rsp)
    3104:      	movq	0x40(%rsp), %r15
    3109:      	cmpq	0x28(%rsp), %r15
    310e:      	jne	0x311b <event_execve+0x311b>
    3110:      	cmpq	0x30(%rsp), %rdx
    3115:      	je	0x1b71 <event_execve+0x1b71>
    311b:      	leaq	0x70(%rsp), %rdi
    3120:      	movl	$0x8, %ecx
    3125:      	movl	$0x4, %eax
    312a:      	movl	$0x8, %esi
    312f:      	callq	*%rax
    3131:      	cmpq	0x70(%rsp), %r15
    3136:      	je	0x3234 <event_execve+0x3234>
    313c:      	leaq	0x18(%r15), %r12
    3140:      	movq	%rsp, %rdi
    3143:      	movl	$0x8, %ecx
    3148:      	movl	$0x4, %eax
    314d:      	movl	$0x8, %esi
    3152:      	movq	%r12, %rdx
    3155:      	callq	*%rax
    3157:      	cmpq	%r15, (%rsp)
    315b:      	je	0x3234 <event_execve+0x3234>
    3161:      	leaq	0x20(%rsp), %rdi
    3166:      	movl	$0x8, %ecx
    316b:      	movl	$0x4, %eax
    3170:      	movl	$0x8, %esi
    3175:      	movq	%r12, %rdx
    3178:      	callq	*%rax
    317a:      	addq	$0x20, %r15
    317e:      	leaq	0x8(%rsp), %rdi
    3183:      	movl	$0x10, %ecx
    3188:      	movl	$0x4, %eax
    318d:      	movl	$0x10, %esi
    3192:      	movq	%r15, %rdx
    3195:      	callq	*%rax
    3197:      	movq	0x38(%rsp), %rbx
    319c:      	movq	0x58(%rsp), %rax
    31a1:      	movl	0xc(%rsp), %ebp
    31a5:      	subq	%rbx, %rax
    31a8:      	movl	0x60(%rsp), %r15d
    31ad:      	xorl	%ecx, %ecx
    31af:      	movl	%ebp, %edx
    31b1:      	subl	%r15d, %edx
    31b4:      	cmovbl	%ecx, %edx
    31b7:      	addq	0x10(%rsp), %rdx
    31bc:      	xorl	%esi, %esi
    31be:      	cmpl	%ebp, %r15d
    31c1:      	seta	%sil
    31c5:      	movl	%ebp, %ecx
    31c7:      	cmovbl	%r15d, %ecx
    31cb:      	addl	%ecx, %esi
    31cd:      	movl	%r15d, %edi
    31d0:      	subl	%esi, %edi
    31d2:      	movl	%edi, 0x60(%rsp)
    31d6:      	subq	%rsi, %rax
    31d9:      	movq	0x18(%rsp), %rdi
    31de:      	jb	0x1b7b <event_execve+0x1b7b>
    31e4:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    31ea:      	ja	0x1b7b <event_execve+0x1b7b>
    31f0:      	cmpl	%ebp, %r15d
    31f3:      	jbe	0x31f9 <event_execve+0x31f9>
    31f5:      	movb	$0x2f, (%rbx,%rax)
    31f9:      	xorl	%edi, %edi
    31fb:      	cmpl	%ebp, %r15d
    31fe:      	seta	%dil
    3202:      	movzbl	%cl, %esi
    3205:      	addq	%rax, %rbx
    3208:      	addq	%rbx, %rdi
    320b:      	movl	$0x4, %eax
    3210:      	callq	*%rax
    3212:      	movq	%rbx, 0x58(%rsp)
    3217:      	cmpl	%ebp, %r15d
    321a:      	movq	0x18(%rsp), %rdi
    321f:      	jbe	0x1b7b <event_execve+0x1b7b>
    3225:      	movq	0x20(%rsp), %rax
    322a:      	movq	%rax, 0x40(%rsp)
    322f:      	jmp	0x1b7b <event_execve+0x1b7b>
    3234:      	leaq	0x10(%rbx), %rdx
    3238:      	movq	%rsp, %rdi
    323b:      	movl	$0x8, %ecx
    3240:      	movl	$0x4, %eax
    3245:      	movl	$0x8, %esi
    324a:      	callq	*%rax
    324c:      	movq	0x50(%rsp), %rax
    3251:      	cmpq	(%rsp), %rax
    3255:      	je	0x1b71 <event_execve+0x1b71>
    325b:      	addq	$0x18, %rbx
    325f:      	movl	$0x8, %ecx
    3264:      	movl	$0x4, %eax
    3269:      	leaq	0x40(%rsp), %rdi
    326e:      	movl	$0x8, %esi
    3273:      	movq	%rbx, %rdx
    3276:      	callq	*%rax
    3278:      	jmp	0x1b76 <event_execve+0x1b76>
