
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_generic_fentry_v511.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
       5:      	testq	%rdx, %rdx
       8:      	je	0x74 <native_bpf_strncasestr+0x74>
       a:      	pushq	%rbx
       b:      	xorl	%ecx, %ecx
       d:      	jmp	0x1b <native_bpf_strncasestr+0x1b>
       f:      	nop
      10:      	incq	%rcx
      13:      	incq	%rdi
      16:      	cmpq	%rdx, %rcx
      19:      	je	0x73 <native_bpf_strncasestr+0x73>
      1b:      	xorl	%r8d, %r8d
      1e:      	nop
      20:      	leaq	(%rcx,%r8), %r9
      24:      	cmpq	%rdx, %r9
      27:      	jae	0x10 <native_bpf_strncasestr+0x10>
      29:      	movsbl	(%rsi,%r8), %r9d
      2e:      	testl	%r9d, %r9d
      31:      	je	0x71 <native_bpf_strncasestr+0x71>
      33:      	movsbl	(%rdi,%r8), %r10d
      38:      	leal	-0x41(%r10), %r11d
      3c:      	movl	%r10d, %ebx
      3f:      	orl	$0x20, %ebx
      42:      	cmpl	$0x1a, %r11d
      46:      	cmovael	%r10d, %ebx
      4a:      	leal	-0x41(%r9), %r10d
      4e:      	movl	%r9d, %r11d
      51:      	orl	$0x20, %r11d
      55:      	cmpl	$0x1a, %r10d
      59:      	cmovael	%r9d, %r11d
      5d:      	cmpl	%r11d, %ebx
      60:      	jne	0x10 <native_bpf_strncasestr+0x10>
      62:      	leaq	0x1(%r8), %r9
      66:      	cmpq	$0x63, %r8
      6a:      	movq	%r9, %r8
      6d:      	jb	0x20 <native_bpf_strncasestr+0x20>
      6f:      	jmp	0x10 <native_bpf_strncasestr+0x10>
      71:      	movl	%ecx, %eax
      73:      	popq	%rbx
      74:      	retq

Disassembly of section fentry/generic_fentry_tail:

0000000000000000 <generic_fentry_setup_event>:
       0:      	pushq	%r15
       2:      	pushq	%r14
       4:      	pushq	%r12
       6:      	pushq	%rbx
       7:      	subq	$0x48, %rsp
       b:      	movq	%rdi, %rbx
       e:      	movl	$0x0, 0x24(%rsp)
      16:      	movq	(%rip), %rdi            # 0x1d <generic_fentry_setup_event+0x1d>
      1d:      	leaq	0x24(%rsp), %rsi
      22:      	movl	$0x1, %eax
      27:      	callq	*%rax
      29:      	testq	%rax, %rax
      2c:      	je	0x394 <generic_fentry_setup_event+0x394>
      32:      	movq	%rax, %r14
      35:      	leaq	0x5ef8(%rax), %rsi
      3c:      	movq	(%rip), %rdi            # 0x43 <generic_fentry_setup_event+0x43>
      43:      	movl	$0x1, %eax
      48:      	callq	*%rax
      4a:      	testq	%rax, %rax
      4d:      	je	0x394 <generic_fentry_setup_event+0x394>
      53:      	movq	%rax, %r15
      56:      	cmpl	$0x0, 0x54(%rax)
      5a:      	je	0x143 <generic_fentry_setup_event+0x143>
      60:      	leaq	0x8(%rsp), %rdi
      65:      	movl	$0x8, %ecx
      6a:      	movl	$0x4, %eax
      6f:      	movl	$0x8, %esi
      74:      	movq	%rbx, %rdx
      77:      	callq	*%rax
      79:      	movq	0x8(%rsp), %r12
      7e:      	testq	%r12, %r12
      81:      	je	0x394 <generic_fentry_setup_event+0x394>
      87:      	leaq	0x70(%r12), %rdx
      8c:      	leaq	0x8(%rsp), %rdi
      91:      	movl	$0x8, %ecx
      96:      	movl	$0x4, %eax
      9b:      	movl	$0x8, %esi
      a0:      	callq	*%rax
      a2:      	movq	0x8(%rsp), %rax
      a7:      	movq	%rax, 0x5e50(%r14)
      ae:      	leaq	0x68(%r12), %rdx
      b3:      	leaq	0x8(%rsp), %rdi
      b8:      	movl	$0x8, %ecx
      bd:      	movl	$0x4, %eax
      c2:      	movl	$0x8, %esi
      c7:      	callq	*%rax
      c9:      	movq	0x8(%rsp), %rax
      ce:      	movq	%rax, 0x5e58(%r14)
      d5:      	leaq	0x60(%r12), %rdx
      da:      	leaq	0x8(%rsp), %rdi
      df:      	movl	$0x8, %ecx
      e4:      	movl	$0x4, %eax
      e9:      	movl	$0x8, %esi
      ee:      	callq	*%rax
      f0:      	movq	0x8(%rsp), %rax
      f5:      	movq	%rax, 0x5e60(%r14)
      fc:      	leaq	0x38(%r12), %rdx
     101:      	leaq	0x8(%rsp), %rdi
     106:      	movl	$0x8, %ecx
     10b:      	movl	$0x4, %eax
     110:      	movl	$0x8, %esi
     115:      	callq	*%rax
     117:      	movq	0x8(%rsp), %rax
     11c:      	movq	%rax, 0x5e68(%r14)
     123:      	addq	$0x48, %r12
     127:      	leaq	0x8(%rsp), %rdi
     12c:      	movl	$0x8, %ecx
     131:      	movl	$0x4, %eax
     136:      	movl	$0x8, %esi
     13b:      	movq	%r12, %rdx
     13e:      	jmp	0x1f2 <generic_fentry_setup_event+0x1f2>
     143:      	leaq	0x8(%rsp), %rdi
     148:      	movl	$0x8, %ecx
     14d:      	movl	$0x4, %eax
     152:      	movl	$0x8, %esi
     157:      	movq	%rbx, %rdx
     15a:      	callq	*%rax
     15c:      	movq	0x8(%rsp), %rax
     161:      	movq	%rax, 0x5e50(%r14)
     168:      	leaq	0x8(%rbx), %rdx
     16c:      	leaq	0x8(%rsp), %rdi
     171:      	movl	$0x8, %ecx
     176:      	movl	$0x4, %eax
     17b:      	movl	$0x8, %esi
     180:      	callq	*%rax
     182:      	movq	0x8(%rsp), %rax
     187:      	movq	%rax, 0x5e58(%r14)
     18e:      	leaq	0x10(%rbx), %rdx
     192:      	leaq	0x8(%rsp), %rdi
     197:      	movl	$0x8, %ecx
     19c:      	movl	$0x4, %eax
     1a1:      	movl	$0x8, %esi
     1a6:      	callq	*%rax
     1a8:      	movq	0x8(%rsp), %rax
     1ad:      	movq	%rax, 0x5e60(%r14)
     1b4:      	leaq	0x18(%rbx), %rdx
     1b8:      	leaq	0x8(%rsp), %rdi
     1bd:      	movl	$0x8, %ecx
     1c2:      	movl	$0x4, %eax
     1c7:      	movl	$0x8, %esi
     1cc:      	callq	*%rax
     1ce:      	movq	0x8(%rsp), %rax
     1d3:      	movq	%rax, 0x5e68(%r14)
     1da:      	leaq	0x20(%rbx), %rdx
     1de:      	leaq	0x8(%rsp), %rdi
     1e3:      	movl	$0x8, %ecx
     1e8:      	movl	$0x4, %eax
     1ed:      	movl	$0x8, %esi
     1f2:      	callq	*%rax
     1f4:      	movq	0x8(%rsp), %rax
     1f9:      	movq	%rax, 0x5e70(%r14)
     200:      	movb	$0xd, (%r14)
     204:      	movw	$0x0, 0x2(%r14)
     20b:      	movl	$0x0, 0x4(%r14)
     213:      	movl	$0x7d, %eax
     218:      	callq	*%rax
     21a:      	movq	%rax, 0x8(%r14)
     21e:      	movq	$0x0, 0x70(%r14)
     226:      	movl	$0x0, 0x14(%r14)
     22e:      	movl	$0xe, %eax
     233:      	callq	*%rax
     235:      	movl	%eax, 0x7c(%r14)
     239:      	movl	$0xe, %eax
     23e:      	callq	*%rax
     240:      	cmpq	$-0x16, %rax
     244:      	jne	0x265 <generic_fentry_setup_event+0x265>
     246:      	leaq	0x20(%rbx), %rdx
     24a:      	leaq	0x8(%rsp), %rdi
     24f:      	movl	$0x8, %ecx
     254:      	movl	$0x4, %eax
     259:      	movl	$0x8, %esi
     25e:      	callq	*%rax
     260:      	movq	0x8(%rsp), %rax
     265:      	movq	%rax, 0x68(%r14)
     269:      	cmpl	$0x0, 0x5c(%r15)
     26e:      	jle	0x31b <generic_fentry_setup_event+0x31b>
     274:      	movq	0x8(%r14), %rcx
     278:      	movq	0x60(%r14), %rdx
     27c:      	movq	%rcx, 0x8(%rsp)
     281:      	movq	$0x1, 0x10(%rsp)
     28a:      	movq	$0x0, 0x18(%rsp)
     293:      	movq	%rdx, 0x38(%rsp)
     298:      	movq	%rax, 0x40(%rsp)
     29d:      	movq	(%rip), %rdi            # 0x2a4 <generic_fentry_setup_event+0x2a4>
     2a4:      	xorl	%ecx, %ecx
     2a6:      	leaq	0x38(%rsp), %rsi
     2ab:      	leaq	0x8(%rsp), %rdx
     2b0:      	movl	$0x2, %eax
     2b5:      	xorl	%ecx, %ecx
     2b7:      	callq	*%rax
     2b9:      	testq	%rax, %rax
     2bc:      	je	0x31b <generic_fentry_setup_event+0x31b>
     2be:      	negl	%eax
     2c0:      	movw	%ax, 0x2c(%rsp)
     2c5:      	movw	$0x5, 0x2e(%rsp)
     2cc:      	movabsq	$0x200000046, %rax      # imm = 0x200000046
     2d6:      	movq	%rax, 0x30(%rsp)
     2db:      	movq	(%rip), %rdi            # 0x2e2 <generic_fentry_setup_event+0x2e2>
     2e2:      	leaq	0x2c(%rsp), %rsi
     2e7:      	movl	$0x1, %eax
     2ec:      	callq	*%rax
     2ee:      	testq	%rax, %rax
     2f1:      	je	0x2f7 <generic_fentry_setup_event+0x2f7>
     2f3:      	incl	(%rax)
     2f5:      	jmp	0x31b <generic_fentry_setup_event+0x31b>
     2f7:      	movl	$0x1, 0x28(%rsp)
     2ff:      	movq	(%rip), %rdi            # 0x306 <generic_fentry_setup_event+0x306>
     306:      	xorl	%ecx, %ecx
     308:      	leaq	0x2c(%rsp), %rsi
     30d:      	leaq	0x28(%rsp), %rdx
     312:      	movl	$0x2, %eax
     317:      	xorl	%ecx, %ecx
     319:      	callq	*%rax
     31b:      	movl	$0x0, 0x8(%rsp)
     323:      	movq	(%rip), %rdi            # 0x32a <generic_fentry_setup_event+0x32a>
     32a:      	leaq	0x8(%rsp), %rsi
     32f:      	movl	$0x1, %eax
     334:      	callq	*%rax
     336:      	testq	%rax, %rax
     339:      	je	0x35e <generic_fentry_setup_event+0x35e>
     33b:      	movq	%rax, %rsi
     33e:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     345:      	movq	(%rip), %rdi            # 0x34c <generic_fentry_setup_event+0x34c>
     34c:      	movl	$0x1, %eax
     351:      	callq	*%rax
     353:      	testq	%rax, %rax
     356:      	je	0x35e <generic_fentry_setup_event+0x35e>
     358:      	cmpl	$-0x1, 0x40(%rax)
     35c:      	jne	0x379 <generic_fentry_setup_event+0x379>
     35e:      	movq	(%rip), %rsi            # 0x365 <generic_fentry_setup_event+0x365>
     365:      	movl	$0x3, %ecx
     36a:      	movl	$0xc, %eax
     36f:      	movq	%rbx, %rdi
     372:      	movl	$0x3, %edx
     377:      	callq	*%rax
     379:      	movq	(%rip), %rsi            # 0x380 <generic_fentry_setup_event+0x380>
     380:      	movl	$0x1, %ecx
     385:      	movl	$0xc, %eax
     38a:      	movq	%rbx, %rdi
     38d:      	movl	$0x1, %edx
     392:      	callq	*%rax
     394:      	xorl	%eax, %eax
     396:      	addq	$0x48, %rsp
     39a:      	popq	%rbx
     39b:      	popq	%r12
     39d:      	popq	%r14
     39f:      	popq	%r15
     3a1:      	retq
     3a2:      	nopw	%cs:(%rax,%rax)

00000000000003b0 <generic_fentry_process_event>:
     3b0:      	pushq	%rbp
     3b1:      	pushq	%r15
     3b3:      	pushq	%r14
     3b5:      	pushq	%r13
     3b7:      	pushq	%r12
     3b9:      	pushq	%rbx
     3ba:      	subq	$0x108, %rsp            # imm = 0x108
     3c1:      	movq	%rdi, %rbx
     3c4:      	movl	$0x0, 0xf4(%rsp)
     3cf:      	movq	(%rip), %rdi            # 0x3d6 <generic_fentry_process_event+0x26>
     3d6:      	leaq	0xf4(%rsp), %rsi
     3de:      	movl	$0x1, %eax
     3e3:      	callq	*%rax
     3e5:      	testq	%rax, %rax
     3e8:      	je	0x103f <generic_fentry_process_event+0xc8f>
     3ee:      	movq	%rax, %r14
     3f1:      	movl	0x5efc(%rax), %r12d
     3f8:      	movl	0x4(%rax), %ebp
     3fb:      	cmpq	$0x2327, %rbp           # imm = 0x2327
     402:      	ja	0xfa0 <generic_fentry_process_event+0xbf0>
     408:      	movl	$0x0, 0xf8(%rsp)
     413:      	movq	(%rip), %rdi            # 0x41a <generic_fentry_process_event+0x6a>
     41a:      	leaq	0xf8(%rsp), %rsi
     422:      	movl	$0x1, %eax
     427:      	callq	*%rax
     429:      	testq	%rax, %rax
     42c:      	je	0xfa0 <generic_fentry_process_event+0xbf0>
     432:      	movq	%rax, %r15
     435:      	leaq	0x5ef8(%rax), %rsi
     43c:      	movq	(%rip), %rdi            # 0x443 <generic_fentry_process_event+0x93>
     443:      	movl	$0x1, %eax
     448:      	callq	*%rax
     44a:      	cmpl	$0x4, %r12d
     44e:      	jg	0xfa0 <generic_fentry_process_event+0xbf0>
     454:      	testq	%rax, %rax
     457:      	je	0xfa0 <generic_fentry_process_event+0xbf0>
     45d:      	movq	%r12, 0x100(%rsp)
     465:      	movl	%r12d, %edx
     468:      	andl	$0x7, %edx
     46b:      	movl	%edx, %ecx
     46d:      	movl	0x4(%rax,%rcx,4), %r13d
     472:      	movslq	0x18(%rax,%rcx,4), %r12
     477:      	movl	%r12d, %esi
     47a:      	movl	$0x0, 0x5ea0(%r15,%rcx,4)
     486:      	testl	$0x100, %r12d           # imm = 0x100
     48d:      	movq	%rbp, 0xc8(%rsp)
     495:      	movq	%rdx, 0x20(%rsp)
     49a:      	jne	0x4b8 <generic_fentry_process_event+0x108>
     49c:      	testb	%r12b, %r12b
     49f:      	js	0x4c6 <generic_fentry_process_event+0x116>
     4a1:      	testb	$0x40, %sil
     4a5:      	jne	0x4d3 <generic_fentry_process_event+0x123>
     4a7:      	movl	0x40(%rax,%rdx,4), %ecx
     4ab:      	andl	$0x7, %ecx
     4ae:      	movq	0x5e50(%r15,%rcx,8), %rcx
     4b6:      	jmp	0x504 <generic_fentry_process_event+0x154>
     4b8:      	movq	$0x0, 0x8(%rsp)
     4c1:      	jmp	0xbc9 <generic_fentry_process_event+0x819>
     4c6:      	movq	$0x0, 0x8(%rsp)
     4cf:      	xorl	%ecx, %ecx
     4d1:      	jmp	0x509 <generic_fentry_process_event+0x159>
     4d3:      	movq	%rax, 0x10(%rsp)
     4d8:      	movl	$0x23, %eax
     4dd:      	movq	%r14, %rbp
     4e0:      	movq	%r13, %r14
     4e3:      	movq	%r12, %r13
     4e6:      	movq	%rsi, %r12
     4e9:      	callq	*%rax
     4eb:      	movq	%r12, %rsi
     4ee:      	movq	%r13, %r12
     4f1:      	movq	%r14, %r13
     4f4:      	movq	%rbp, %r14
     4f7:      	movq	0x20(%rsp), %rdx
     4fc:      	movq	%rax, %rcx
     4ff:      	movq	0x10(%rsp), %rax
     504:      	movq	%rcx, 0x8(%rsp)
     509:      	cmpl	$0x4, %edx
     50c:      	ja	0xbc9 <generic_fentry_process_event+0x819>
     512:      	leaq	(%rdx,%rdx,4), %rdx
     516:      	shll	$0x4, %edx
     519:      	cmpw	$0x0, 0x76(%rax,%rdx)
     51f:      	je	0xbc9 <generic_fentry_process_event+0x819>
     525:      	leaq	(%rax,%rdx), %rdi
     529:      	addq	$0x70, %rdi
     52d:      	movq	(%rip), %rax            # 0x534 <generic_fentry_process_event+0x184>
     534:      	movzbl	(%rax), %edx
     537:      	movl	(%rdi), %eax
     539:      	addq	%rax, %rcx
     53c:      	movq	%rcx, 0x8(%rsp)
     541:      	movzwl	0x4(%rdi), %eax
     545:      	testb	%dl, %dl
     547:      	movq	%rdi, 0x10(%rsp)
     54c:      	je	0x882 <generic_fentry_process_event+0x4d2>
     552:      	testw	%ax, %ax
     555:      	je	0x58f <generic_fentry_process_event+0x1df>
     557:      	leaq	0x8(%rsp), %rdi
     55c:      	movl	$0x8, %edx
     561:      	movl	$0x4, %eax
     566:      	movq	0x8(%rsp), %rdx
     56b:      	movq	%rsi, %rbp
     56e:      	movl	$0x8, %esi
     573:      	callq	*%rax
     575:      	movq	0x10(%rsp), %rdi
     57a:      	movq	%rbp, %rsi
     57d:      	movq	0x20(%rsp), %rcx
     582:      	movl	$0x1, %ebp
     587:      	testl	%eax, %eax
     589:      	js	0xbc1 <generic_fentry_process_event+0x811>
     58f:      	cmpw	$0x0, 0xe(%rdi)
     594:      	je	0xbc9 <generic_fentry_process_event+0x819>
     59a:      	movl	0x8(%rdi), %ecx
     59d:      	addq	0x8(%rsp), %rcx
     5a2:      	movq	%rcx, 0x8(%rsp)
     5a7:      	cmpw	$0x0, 0xc(%rdi)
     5ac:      	je	0x5e6 <generic_fentry_process_event+0x236>
     5ae:      	leaq	0x8(%rsp), %rdi
     5b3:      	movl	$0x8, %edx
     5b8:      	movl	$0x4, %eax
     5bd:      	movq	0x8(%rsp), %rdx
     5c2:      	movq	%rsi, %rbp
     5c5:      	movl	$0x8, %esi
     5ca:      	callq	*%rax
     5cc:      	movq	0x10(%rsp), %rdi
     5d1:      	movq	%rbp, %rsi
     5d4:      	movq	0x20(%rsp), %rcx
     5d9:      	movl	$0x2, %ebp
     5de:      	testl	%eax, %eax
     5e0:      	js	0xbc1 <generic_fentry_process_event+0x811>
     5e6:      	cmpw	$0x0, 0x16(%rdi)
     5eb:      	je	0xbc9 <generic_fentry_process_event+0x819>
     5f1:      	movl	0x10(%rdi), %ecx
     5f4:      	addq	0x8(%rsp), %rcx
     5f9:      	movq	%rcx, 0x8(%rsp)
     5fe:      	cmpw	$0x0, 0x14(%rdi)
     603:      	je	0x63d <generic_fentry_process_event+0x28d>
     605:      	leaq	0x8(%rsp), %rdi
     60a:      	movl	$0x8, %edx
     60f:      	movl	$0x4, %eax
     614:      	movq	0x8(%rsp), %rdx
     619:      	movq	%rsi, %rbp
     61c:      	movl	$0x8, %esi
     621:      	callq	*%rax
     623:      	movq	0x10(%rsp), %rdi
     628:      	movq	%rbp, %rsi
     62b:      	movq	0x20(%rsp), %rcx
     630:      	movl	$0x3, %ebp
     635:      	testl	%eax, %eax
     637:      	js	0xbc1 <generic_fentry_process_event+0x811>
     63d:      	cmpw	$0x0, 0x1e(%rdi)
     642:      	je	0xbc9 <generic_fentry_process_event+0x819>
     648:      	movl	0x18(%rdi), %ecx
     64b:      	addq	0x8(%rsp), %rcx
     650:      	movq	%rcx, 0x8(%rsp)
     655:      	cmpw	$0x0, 0x1c(%rdi)
     65a:      	je	0x694 <generic_fentry_process_event+0x2e4>
     65c:      	leaq	0x8(%rsp), %rdi
     661:      	movl	$0x8, %edx
     666:      	movl	$0x4, %eax
     66b:      	movq	0x8(%rsp), %rdx
     670:      	movq	%rsi, %rbp
     673:      	movl	$0x8, %esi
     678:      	callq	*%rax
     67a:      	movq	0x10(%rsp), %rdi
     67f:      	movq	%rbp, %rsi
     682:      	movq	0x20(%rsp), %rcx
     687:      	movl	$0x4, %ebp
     68c:      	testl	%eax, %eax
     68e:      	js	0xbc1 <generic_fentry_process_event+0x811>
     694:      	cmpw	$0x0, 0x26(%rdi)
     699:      	je	0xbc9 <generic_fentry_process_event+0x819>
     69f:      	movl	0x20(%rdi), %ecx
     6a2:      	addq	0x8(%rsp), %rcx
     6a7:      	movq	%rcx, 0x8(%rsp)
     6ac:      	cmpw	$0x0, 0x24(%rdi)
     6b1:      	je	0x6eb <generic_fentry_process_event+0x33b>
     6b3:      	leaq	0x8(%rsp), %rdi
     6b8:      	movl	$0x8, %edx
     6bd:      	movl	$0x4, %eax
     6c2:      	movq	0x8(%rsp), %rdx
     6c7:      	movq	%rsi, %rbp
     6ca:      	movl	$0x8, %esi
     6cf:      	callq	*%rax
     6d1:      	movq	0x10(%rsp), %rdi
     6d6:      	movq	%rbp, %rsi
     6d9:      	movq	0x20(%rsp), %rcx
     6de:      	movl	$0x5, %ebp
     6e3:      	testl	%eax, %eax
     6e5:      	js	0xbc1 <generic_fentry_process_event+0x811>
     6eb:      	cmpw	$0x0, 0x2e(%rdi)
     6f0:      	je	0xbc9 <generic_fentry_process_event+0x819>
     6f6:      	movl	0x28(%rdi), %ecx
     6f9:      	addq	0x8(%rsp), %rcx
     6fe:      	movq	%rcx, 0x8(%rsp)
     703:      	cmpw	$0x0, 0x2c(%rdi)
     708:      	je	0x742 <generic_fentry_process_event+0x392>
     70a:      	leaq	0x8(%rsp), %rdi
     70f:      	movl	$0x8, %edx
     714:      	movl	$0x4, %eax
     719:      	movq	0x8(%rsp), %rdx
     71e:      	movq	%rsi, %rbp
     721:      	movl	$0x8, %esi
     726:      	callq	*%rax
     728:      	movq	0x10(%rsp), %rdi
     72d:      	movq	%rbp, %rsi
     730:      	movq	0x20(%rsp), %rcx
     735:      	movl	$0x6, %ebp
     73a:      	testl	%eax, %eax
     73c:      	js	0xbc1 <generic_fentry_process_event+0x811>
     742:      	cmpw	$0x0, 0x36(%rdi)
     747:      	je	0xbc9 <generic_fentry_process_event+0x819>
     74d:      	movl	0x30(%rdi), %ecx
     750:      	addq	0x8(%rsp), %rcx
     755:      	movq	%rcx, 0x8(%rsp)
     75a:      	cmpw	$0x0, 0x34(%rdi)
     75f:      	je	0x799 <generic_fentry_process_event+0x3e9>
     761:      	leaq	0x8(%rsp), %rdi
     766:      	movl	$0x8, %edx
     76b:      	movl	$0x4, %eax
     770:      	movq	0x8(%rsp), %rdx
     775:      	movq	%rsi, %rbp
     778:      	movl	$0x8, %esi
     77d:      	callq	*%rax
     77f:      	movq	0x10(%rsp), %rdi
     784:      	movq	%rbp, %rsi
     787:      	movq	0x20(%rsp), %rcx
     78c:      	movl	$0x7, %ebp
     791:      	testl	%eax, %eax
     793:      	js	0xbc1 <generic_fentry_process_event+0x811>
     799:      	cmpw	$0x0, 0x3e(%rdi)
     79e:      	je	0xbc9 <generic_fentry_process_event+0x819>
     7a4:      	movl	0x38(%rdi), %ecx
     7a7:      	addq	0x8(%rsp), %rcx
     7ac:      	movq	%rcx, 0x8(%rsp)
     7b1:      	cmpw	$0x0, 0x3c(%rdi)
     7b6:      	je	0x7f4 <generic_fentry_process_event+0x444>
     7b8:      	leaq	0x8(%rsp), %rdi
     7bd:      	movl	$0x8, %edx
     7c2:      	movl	$0x4, %eax
     7c7:      	movq	0x8(%rsp), %rdx
     7cc:      	movl	$0x8, %ebp
     7d1:      	movq	%rsi, 0x40(%rsp)
     7d6:      	movl	$0x8, %esi
     7db:      	callq	*%rax
     7dd:      	movq	0x10(%rsp), %rdi
     7e2:      	movq	0x40(%rsp), %rsi
     7e7:      	movq	0x20(%rsp), %rcx
     7ec:      	testl	%eax, %eax
     7ee:      	js	0xbc1 <generic_fentry_process_event+0x811>
     7f4:      	cmpw	$0x0, 0x46(%rdi)
     7f9:      	je	0xbc9 <generic_fentry_process_event+0x819>
     7ff:      	movl	0x40(%rdi), %ecx
     802:      	addq	0x8(%rsp), %rcx
     807:      	movq	%rcx, 0x8(%rsp)
     80c:      	cmpw	$0x0, 0x44(%rdi)
     811:      	je	0x84b <generic_fentry_process_event+0x49b>
     813:      	leaq	0x8(%rsp), %rdi
     818:      	movl	$0x8, %edx
     81d:      	movl	$0x4, %eax
     822:      	movq	0x8(%rsp), %rdx
     827:      	movq	%rsi, %rbp
     82a:      	movl	$0x8, %esi
     82f:      	callq	*%rax
     831:      	movq	0x10(%rsp), %rdi
     836:      	movq	%rbp, %rsi
     839:      	movq	0x20(%rsp), %rcx
     83e:      	movl	$0x9, %ebp
     843:      	testl	%eax, %eax
     845:      	js	0xbc1 <generic_fentry_process_event+0x811>
     84b:      	cmpw	$0x0, 0x4e(%rdi)
     850:      	je	0xbc9 <generic_fentry_process_event+0x819>
     856:      	movl	0x48(%rdi), %ecx
     859:      	addq	0x8(%rsp), %rcx
     85e:      	movq	%rcx, 0x8(%rsp)
     863:      	cmpw	$0x0, 0x4c(%rdi)
     868:      	je	0xbc9 <generic_fentry_process_event+0x819>
     86e:      	leaq	0x8(%rsp), %rdi
     873:      	movl	$0x8, %edx
     878:      	movl	$0x4, %eax
     87d:      	jmp	0xba1 <generic_fentry_process_event+0x7f1>
     882:      	testw	%ax, %ax
     885:      	je	0x8bf <generic_fentry_process_event+0x50f>
     887:      	leaq	0x8(%rsp), %rdi
     88c:      	movl	$0x8, %edx
     891:      	movl	$0x4, %eax
     896:      	movq	0x8(%rsp), %rdx
     89b:      	movq	%rsi, %rbp
     89e:      	movl	$0x8, %esi
     8a3:      	callq	*%rax
     8a5:      	movq	0x10(%rsp), %rdi
     8aa:      	movq	%rbp, %rsi
     8ad:      	movq	0x20(%rsp), %rcx
     8b2:      	movl	$0x1, %ebp
     8b7:      	testl	%eax, %eax
     8b9:      	js	0xbc1 <generic_fentry_process_event+0x811>
     8bf:      	cmpw	$0x0, 0xe(%rdi)
     8c4:      	je	0xbc9 <generic_fentry_process_event+0x819>
     8ca:      	movl	0x8(%rdi), %ecx
     8cd:      	addq	0x8(%rsp), %rcx
     8d2:      	movq	%rcx, 0x8(%rsp)
     8d7:      	cmpw	$0x0, 0xc(%rdi)
     8dc:      	je	0x916 <generic_fentry_process_event+0x566>
     8de:      	leaq	0x8(%rsp), %rdi
     8e3:      	movl	$0x8, %edx
     8e8:      	movl	$0x4, %eax
     8ed:      	movq	0x8(%rsp), %rdx
     8f2:      	movq	%rsi, %rbp
     8f5:      	movl	$0x8, %esi
     8fa:      	callq	*%rax
     8fc:      	movq	0x10(%rsp), %rdi
     901:      	movq	%rbp, %rsi
     904:      	movq	0x20(%rsp), %rcx
     909:      	movl	$0x2, %ebp
     90e:      	testl	%eax, %eax
     910:      	js	0xbc1 <generic_fentry_process_event+0x811>
     916:      	cmpw	$0x0, 0x16(%rdi)
     91b:      	je	0xbc9 <generic_fentry_process_event+0x819>
     921:      	movl	0x10(%rdi), %ecx
     924:      	addq	0x8(%rsp), %rcx
     929:      	movq	%rcx, 0x8(%rsp)
     92e:      	cmpw	$0x0, 0x14(%rdi)
     933:      	je	0x96d <generic_fentry_process_event+0x5bd>
     935:      	leaq	0x8(%rsp), %rdi
     93a:      	movl	$0x8, %edx
     93f:      	movl	$0x4, %eax
     944:      	movq	0x8(%rsp), %rdx
     949:      	movq	%rsi, %rbp
     94c:      	movl	$0x8, %esi
     951:      	callq	*%rax
     953:      	movq	0x10(%rsp), %rdi
     958:      	movq	%rbp, %rsi
     95b:      	movq	0x20(%rsp), %rcx
     960:      	movl	$0x3, %ebp
     965:      	testl	%eax, %eax
     967:      	js	0xbc1 <generic_fentry_process_event+0x811>
     96d:      	cmpw	$0x0, 0x1e(%rdi)
     972:      	je	0xbc9 <generic_fentry_process_event+0x819>
     978:      	movl	0x18(%rdi), %ecx
     97b:      	addq	0x8(%rsp), %rcx
     980:      	movq	%rcx, 0x8(%rsp)
     985:      	cmpw	$0x0, 0x1c(%rdi)
     98a:      	je	0x9c4 <generic_fentry_process_event+0x614>
     98c:      	leaq	0x8(%rsp), %rdi
     991:      	movl	$0x8, %edx
     996:      	movl	$0x4, %eax
     99b:      	movq	0x8(%rsp), %rdx
     9a0:      	movq	%rsi, %rbp
     9a3:      	movl	$0x8, %esi
     9a8:      	callq	*%rax
     9aa:      	movq	0x10(%rsp), %rdi
     9af:      	movq	%rbp, %rsi
     9b2:      	movq	0x20(%rsp), %rcx
     9b7:      	movl	$0x4, %ebp
     9bc:      	testl	%eax, %eax
     9be:      	js	0xbc1 <generic_fentry_process_event+0x811>
     9c4:      	cmpw	$0x0, 0x26(%rdi)
     9c9:      	je	0xbc9 <generic_fentry_process_event+0x819>
     9cf:      	movl	0x20(%rdi), %ecx
     9d2:      	addq	0x8(%rsp), %rcx
     9d7:      	movq	%rcx, 0x8(%rsp)
     9dc:      	cmpw	$0x0, 0x24(%rdi)
     9e1:      	je	0xa1b <generic_fentry_process_event+0x66b>
     9e3:      	leaq	0x8(%rsp), %rdi
     9e8:      	movl	$0x8, %edx
     9ed:      	movl	$0x4, %eax
     9f2:      	movq	0x8(%rsp), %rdx
     9f7:      	movq	%rsi, %rbp
     9fa:      	movl	$0x8, %esi
     9ff:      	callq	*%rax
     a01:      	movq	0x10(%rsp), %rdi
     a06:      	movq	%rbp, %rsi
     a09:      	movq	0x20(%rsp), %rcx
     a0e:      	movl	$0x5, %ebp
     a13:      	testl	%eax, %eax
     a15:      	js	0xbc1 <generic_fentry_process_event+0x811>
     a1b:      	cmpw	$0x0, 0x2e(%rdi)
     a20:      	je	0xbc9 <generic_fentry_process_event+0x819>
     a26:      	movl	0x28(%rdi), %ecx
     a29:      	addq	0x8(%rsp), %rcx
     a2e:      	movq	%rcx, 0x8(%rsp)
     a33:      	cmpw	$0x0, 0x2c(%rdi)
     a38:      	je	0xa72 <generic_fentry_process_event+0x6c2>
     a3a:      	leaq	0x8(%rsp), %rdi
     a3f:      	movl	$0x8, %edx
     a44:      	movl	$0x4, %eax
     a49:      	movq	0x8(%rsp), %rdx
     a4e:      	movq	%rsi, %rbp
     a51:      	movl	$0x8, %esi
     a56:      	callq	*%rax
     a58:      	movq	0x10(%rsp), %rdi
     a5d:      	movq	%rbp, %rsi
     a60:      	movq	0x20(%rsp), %rcx
     a65:      	movl	$0x6, %ebp
     a6a:      	testl	%eax, %eax
     a6c:      	js	0xbc1 <generic_fentry_process_event+0x811>
     a72:      	cmpw	$0x0, 0x36(%rdi)
     a77:      	je	0xbc9 <generic_fentry_process_event+0x819>
     a7d:      	movl	0x30(%rdi), %ecx
     a80:      	addq	0x8(%rsp), %rcx
     a85:      	movq	%rcx, 0x8(%rsp)
     a8a:      	cmpw	$0x0, 0x34(%rdi)
     a8f:      	je	0xac9 <generic_fentry_process_event+0x719>
     a91:      	leaq	0x8(%rsp), %rdi
     a96:      	movl	$0x8, %edx
     a9b:      	movl	$0x4, %eax
     aa0:      	movq	0x8(%rsp), %rdx
     aa5:      	movq	%rsi, %rbp
     aa8:      	movl	$0x8, %esi
     aad:      	callq	*%rax
     aaf:      	movq	0x10(%rsp), %rdi
     ab4:      	movq	%rbp, %rsi
     ab7:      	movq	0x20(%rsp), %rcx
     abc:      	movl	$0x7, %ebp
     ac1:      	testl	%eax, %eax
     ac3:      	js	0xbc1 <generic_fentry_process_event+0x811>
     ac9:      	cmpw	$0x0, 0x3e(%rdi)
     ace:      	je	0xbc9 <generic_fentry_process_event+0x819>
     ad4:      	movl	0x38(%rdi), %ecx
     ad7:      	addq	0x8(%rsp), %rcx
     adc:      	movq	%rcx, 0x8(%rsp)
     ae1:      	cmpw	$0x0, 0x3c(%rdi)
     ae6:      	je	0xb24 <generic_fentry_process_event+0x774>
     ae8:      	leaq	0x8(%rsp), %rdi
     aed:      	movl	$0x8, %edx
     af2:      	movl	$0x4, %eax
     af7:      	movq	0x8(%rsp), %rdx
     afc:      	movl	$0x8, %ebp
     b01:      	movq	%rsi, 0x40(%rsp)
     b06:      	movl	$0x8, %esi
     b0b:      	callq	*%rax
     b0d:      	movq	0x10(%rsp), %rdi
     b12:      	movq	0x40(%rsp), %rsi
     b17:      	movq	0x20(%rsp), %rcx
     b1c:      	testl	%eax, %eax
     b1e:      	js	0xbc1 <generic_fentry_process_event+0x811>
     b24:      	cmpw	$0x0, 0x46(%rdi)
     b29:      	je	0xbc9 <generic_fentry_process_event+0x819>
     b2f:      	movl	0x40(%rdi), %ecx
     b32:      	addq	0x8(%rsp), %rcx
     b37:      	movq	%rcx, 0x8(%rsp)
     b3c:      	cmpw	$0x0, 0x44(%rdi)
     b41:      	je	0xb77 <generic_fentry_process_event+0x7c7>
     b43:      	leaq	0x8(%rsp), %rdi
     b48:      	movl	$0x8, %edx
     b4d:      	movl	$0x4, %eax
     b52:      	movq	0x8(%rsp), %rdx
     b57:      	movq	%rsi, %rbp
     b5a:      	movl	$0x8, %esi
     b5f:      	callq	*%rax
     b61:      	movq	0x10(%rsp), %rdi
     b66:      	movq	%rbp, %rsi
     b69:      	movq	0x20(%rsp), %rcx
     b6e:      	movl	$0x9, %ebp
     b73:      	testl	%eax, %eax
     b75:      	js	0xbc1 <generic_fentry_process_event+0x811>
     b77:      	cmpw	$0x0, 0x4e(%rdi)
     b7c:      	je	0xbc9 <generic_fentry_process_event+0x819>
     b7e:      	movl	0x48(%rdi), %ecx
     b81:      	addq	0x8(%rsp), %rcx
     b86:      	movq	%rcx, 0x8(%rsp)
     b8b:      	cmpw	$0x0, 0x4c(%rdi)
     b90:      	je	0xbc9 <generic_fentry_process_event+0x819>
     b92:      	leaq	0x8(%rsp), %rdi
     b97:      	movl	$0x8, %edx
     b9c:      	movl	$0x4, %eax
     ba1:      	movq	0x8(%rsp), %rdx
     ba6:      	movq	%rsi, %rbp
     ba9:      	movl	$0x8, %esi
     bae:      	callq	*%rax
     bb0:      	movq	%rbp, %rsi
     bb3:      	movq	0x20(%rsp), %rcx
     bb8:      	movl	$0xa, %ebp
     bbd:      	testl	%eax, %eax
     bbf:      	jns	0xbc9 <generic_fentry_process_event+0x819>
     bc1:      	movl	%ebp, 0x5ea0(%r15,%rcx,4)
     bc9:      	movl	%r13d, %ebp
     bcc:      	cmpl	$0x2a, %r13d
     bd0:      	ja	0xdbb <generic_fentry_process_event+0xa0b>
     bd6:      	movabsq	$0x42001018000, %rax    # imm = 0x42001018000
     be0:      	btq	%rbp, %rax
     be4:      	jae	0xdbb <generic_fentry_process_event+0xa0b>
     bea:      	movq	0x8(%rsp), %rbp
     bef:      	movl	$0x0, 0x30(%rsp)
     bf7:      	movq	(%rip), %rdi            # 0xbfe <generic_fentry_process_event+0x84e>
     bfe:      	leaq	0x30(%rsp), %rsi
     c03:      	movl	$0x1, %eax
     c08:      	callq	*%rax
     c0a:      	testq	%rax, %rax
     c0d:      	je	0xf8d <generic_fentry_process_event+0xbdd>
     c13:      	movq	%rax, %r12
     c16:      	cmpl	$0x0, 0x6420(%rax)
     c1d:      	je	0xd63 <generic_fentry_process_event+0x9b3>
     c23:      	movl	$0x0, 0x6420(%r12)
     c2f:      	movq	(%rip), %rdi            # 0xc36 <generic_fentry_process_event+0x886>
     c36:      	leaq	0x30(%rsp), %rsi
     c3b:      	movl	$0x1, %eax
     c40:      	callq	*%rax
     c42:      	testq	%rax, %rax
     c45:      	je	0xf8d <generic_fentry_process_event+0xbdd>
     c4b:      	movq	%rax, %rdx
     c4e:      	movq	0x20(%rsp), %rcx
     c53:      	movl	0x5ea0(%r12,%rcx,4), %eax
     c5b:      	movq	0xc8(%rsp), %rbp
     c63:      	movl	%eax, 0x90(%r12,%rbp)
     c6b:      	addq	$0x4, %rbp
     c6f:      	movq	%rbp, 0x5e78(%r12,%rcx,8)
     c77:      	movl	$0x4, %esi
     c7c:      	testl	%eax, %eax
     c7e:      	jne	0xf8f <generic_fentry_process_event+0xbdf>
     c84:      	movq	%r12, %r15
     c87:      	addq	$0x90, %r15
     c8e:      	movl	0x6424(%r12), %eax
     c96:      	movq	%rbx, 0x18(%rsp)
     c9b:      	movl	$0xfff, %ebx            # imm = 0xFFF
     ca0:      	subl	%eax, %ebx
     ca2:      	andl	$0xfff, %eax            # imm = 0xFFF
     ca7:      	addq	%rax, %rdx
     caa:      	movq	0x6440(%r12), %r13
     cb2:      	leaq	(%r15,%rbp), %rdi
     cb6:      	addq	$0x4, %rdi
     cba:      	andl	$0xfff, %ebx            # imm = 0xFFF
     cc0:      	movl	$0x4, %eax
     cc5:      	addq	%rbp, %r15
     cc8:      	movl	%ebx, %esi
     cca:      	callq	*%rax
     ccc:      	movl	%ebx, 0x90(%r12,%rbp)
     cd4:      	addq	$0x8, %r13
     cd8:      	leaq	0x68(%rsp), %rdi
     cdd:      	movl	$0x8, %ecx
     ce2:      	movl	$0x4, %eax
     ce7:      	movl	$0x8, %esi
     cec:      	movq	%r13, %rdx
     cef:      	callq	*%rax
     cf1:      	movq	0x68(%rsp), %rcx
     cf6:      	addq	$0x30, %rcx
     cfa:      	leaq	0x58(%rsp), %rdi
     cff:      	movl	$0x8, %edx
     d04:      	movl	$0x4, %eax
     d09:      	movq	0x68(%rsp), %rdx
     d0e:      	addq	$0x30, %rdx
     d12:      	movl	$0x8, %esi
     d17:      	callq	*%rax
     d19:      	movq	0x58(%rsp), %rcx
     d1e:      	leaq	0xb0(%rsp), %rdi
     d26:      	movl	$0x2, %edx
     d2b:      	movl	$0x4, %eax
     d30:      	movq	0x58(%rsp), %rdx
     d35:      	movl	$0x2, %esi
     d3a:      	callq	*%rax
     d3c:      	movq	%rbx, %rsi
     d3f:      	movq	0x18(%rsp), %rbx
     d44:      	movl	$0x0, 0x4(%rsi,%r15)
     d4d:      	movzwl	0xb0(%rsp), %eax
     d55:      	movw	%ax, 0x8(%rsi,%r15)
     d5b:      	addl	$0xe, %esi
     d5e:      	jmp	0xf8f <generic_fentry_process_event+0xbdf>
     d63:      	movq	%rbp, 0x68(%rsp)
     d68:      	movq	$0x0, 0x58(%rsp)
     d71:      	cmpl	$0x17, %r13d
     d75:      	jle	0xe49 <generic_fentry_process_event+0xa99>
     d7b:      	cmpl	$0x18, %r13d
     d7f:      	je	0xec7 <generic_fentry_process_event+0xb17>
     d85:      	cmpl	$0x25, %r13d
     d89:      	je	0xf0e <generic_fentry_process_event+0xb5e>
     d8f:      	cmpl	$0x2a, %r13d
     d93:      	jne	0xf8d <generic_fentry_process_event+0xbdd>
     d99:      	movq	%r12, %rax
     d9c:      	addq	$0x6430, %rax           # imm = 0x6430
     da2:      	movq	$0x0, 0x6430(%r12)
     dae:      	movq	%rbp, 0x6438(%r12)
     db6:      	jmp	0xf41 <generic_fentry_process_event+0xb91>
     dbb:      	movq	0x8(%rsp), %rax
     dc0:      	movq	%rax, 0x10(%rsp)
     dc5:      	cmpl	$0x15, %r13d
     dc9:      	movq	%rsi, 0x40(%rsp)
     dce:      	jg	0xe1d <generic_fentry_process_event+0xa6d>
     dd0:      	movl	$0x1000, %r15d          # imm = 0x1000
     dd6:      	cmpl	$0x9, %r13d
     dda:      	jle	0xe6a <generic_fentry_process_event+0xaba>
     de0:      	cmpl	$0x10, %r13d
     de4:      	jle	0x1053 <generic_fentry_process_event+0xca3>
     dea:      	cmpl	$0x12, %r13d
     dee:      	jle	0x10d5 <generic_fentry_process_event+0xd25>
     df4:      	cmpl	$0x13, %r13d
     df8:      	je	0x10cd <generic_fentry_process_event+0xd1d>
     dfe:      	cmpl	$0x14, %r13d
     e02:      	je	0x1102 <generic_fentry_process_event+0xd52>
     e08:      	cmpl	$0x15, %r13d
     e0c:      	jne	0x1110 <generic_fentry_process_event+0xd60>
     e12:      	movl	$0x20, %r15d
     e18:      	jmp	0x1113 <generic_fentry_process_event+0xd63>
     e1d:      	cmpl	$0x20, %r13d
     e21:      	jle	0xe9a <generic_fentry_process_event+0xaea>
     e23:      	cmpl	$0x27, %r13d
     e27:      	jg	0x1075 <generic_fentry_process_event+0xcc5>
     e2d:      	leal	-0x21(%r13), %eax
     e31:      	cmpl	$0x4, %eax
     e34:      	jb	0x106a <generic_fentry_process_event+0xcba>
     e3a:      	cmpl	$0x27, %r13d
     e3e:      	je	0x10b1 <generic_fentry_process_event+0xd01>
     e44:      	jmp	0x1110 <generic_fentry_process_event+0xd60>
     e49:      	cmpl	$0xf, %r13d
     e4d:      	je	0xf68 <generic_fentry_process_event+0xbb8>
     e53:      	cmpl	$0x10, %r13d
     e57:      	jne	0xf8d <generic_fentry_process_event+0xbdd>
     e5d:      	leaq	0xb0(%rsp), %r15
     e65:      	jmp	0xef5 <generic_fentry_process_event+0xb45>
     e6a:      	cmpl	$0x4, %r13d
     e6e:      	jg	0x108c <generic_fentry_process_event+0xcdc>
     e74:      	leal	-0x2(%r13), %eax
     e78:      	cmpl	$0x2, %eax
     e7b:      	jb	0x10a9 <generic_fentry_process_event+0xcf9>
     e81:      	cmpl	$0x1, %r13d
     e85:      	je	0x10a9 <generic_fentry_process_event+0xcf9>
     e8b:      	cmpl	$0x4, %r13d
     e8f:      	je	0x106a <generic_fentry_process_event+0xcba>
     e95:      	jmp	0x1110 <generic_fentry_process_event+0xd60>
     e9a:      	cmpl	$0x1a, %r13d
     e9e:      	jg	0x10a0 <generic_fentry_process_event+0xcf0>
     ea4:      	cmpl	$0x16, %r13d
     ea8:      	je	0x10b1 <generic_fentry_process_event+0xd01>
     eae:      	cmpl	$0x17, %r13d
     eb2:      	je	0x106a <generic_fentry_process_event+0xcba>
     eb8:      	cmpl	$0x1a, %r13d
     ebc:      	je	0x10f2 <generic_fentry_process_event+0xd42>
     ec2:      	jmp	0x1110 <generic_fentry_process_event+0xd60>
     ec7:      	leaq	0xb0(%rsp), %r15
     ecf:      	movl	$0x8, %ecx
     ed4:      	movl	$0x4, %eax
     ed9:      	movq	0x68(%rsp), %rdx
     ede:      	movq	%r15, %rdi
     ee1:      	movl	$0x8, %esi
     ee6:      	callq	*%rax
     ee8:      	movq	0xb0(%rsp), %rax
     ef0:      	movq	%rax, 0x68(%rsp)
     ef5:      	leaq	0x68(%rsp), %rdx
     efa:      	movl	$0x8, %ecx
     eff:      	movl	$0x4, %eax
     f04:      	leaq	0xb0(%rsp), %rdi
     f0c:      	jmp	0xf2e <generic_fentry_process_event+0xb7e>
     f0e:      	addq	$0x40, %rbp
     f12:      	movq	%rbp, 0x68(%rsp)
     f17:      	leaq	0xb0(%rsp), %rdi
     f1f:      	movl	$0x8, %ecx
     f24:      	movl	$0x4, %eax
     f29:      	movq	0x68(%rsp), %rdx
     f2e:      	movl	$0x8, %esi
     f33:      	callq	*%rax
     f35:      	movq	0xb0(%rsp), %rax
     f3d:      	addq	$0x40, %rax
     f41:      	movq	%rax, 0x6440(%r12)
     f49:      	movq	(%rip), %rsi            # 0xf50 <generic_fentry_process_event+0xba0>
     f50:      	movl	$0x6, %ecx
     f55:      	movl	$0xc, %eax
     f5a:      	movq	%rbx, %rdi
     f5d:      	movl	$0x6, %edx
     f62:      	callq	*%rax
     f64:      	xorl	%esi, %esi
     f66:      	jmp	0xf8f <generic_fentry_process_event+0xbdf>
     f68:      	leaq	0x58(%rsp), %rdi
     f6d:      	leaq	0x68(%rsp), %rdx
     f72:      	movl	$0x8, %ecx
     f77:      	movl	$0x4, %eax
     f7c:      	movl	$0x8, %esi
     f81:      	callq	*%rax
     f83:      	movq	0x58(%rsp), %rax
     f88:      	testq	%rax, %rax
     f8b:      	jne	0xf41 <generic_fentry_process_event+0xb91>
     f8d:      	xorl	%esi, %esi
     f8f:      	addl	0xc8(%rsp), %esi
     f96:      	movl	%esi, %ebp
     f98:      	movq	0x100(%rsp), %r12
     fa0:      	movl	%ebp, 0x4(%r14)
     fa4:      	cmpl	$0x3, %r12d
     fa8:      	jg	0x1019 <generic_fentry_process_event+0xc69>
     faa:      	movl	$0x0, 0x68(%rsp)
     fb2:      	movq	(%rip), %rdi            # 0xfb9 <generic_fentry_process_event+0xc09>
     fb9:      	leaq	0x68(%rsp), %rsi
     fbe:      	movl	$0x1, %eax
     fc3:      	callq	*%rax
     fc5:      	testq	%rax, %rax
     fc8:      	je	0x1019 <generic_fentry_process_event+0xc69>
     fca:      	movq	%rax, %rsi
     fcd:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     fd4:      	movq	(%rip), %rdi            # 0xfdb <generic_fentry_process_event+0xc2b>
     fdb:      	movl	$0x1, %eax
     fe0:      	callq	*%rax
     fe2:      	testq	%rax, %rax
     fe5:      	je	0x1019 <generic_fentry_process_event+0xc69>
     fe7:      	incl	%r12d
     fea:      	movl	%r12d, %ecx
     fed:      	andl	$0x7, %ecx
     ff0:      	cmpl	$-0x1, 0x40(%rax,%rcx,4)
     ff5:      	je	0x1019 <generic_fentry_process_event+0xc69>
     ff7:      	movl	%r12d, 0x5efc(%r14)
     ffe:      	movq	(%rip), %rsi            # 0x1005 <generic_fentry_process_event+0xc55>
    1005:      	movl	$0x1, %ecx
    100a:      	movl	$0xc, %eax
    100f:      	movq	%rbx, %rdi
    1012:      	movl	$0x1, %edx
    1017:      	callq	*%rax
    1019:      	movl	$0x0, 0x5efc(%r14)
    1024:      	movq	(%rip), %rsi            # 0x102b <generic_fentry_process_event+0xc7b>
    102b:      	movl	$0x3, %ecx
    1030:      	movl	$0xc, %eax
    1035:      	movq	%rbx, %rdi
    1038:      	movl	$0x3, %edx
    103d:      	callq	*%rax
    103f:      	xorl	%eax, %eax
    1041:      	addq	$0x108, %rsp            # imm = 0x108
    1048:      	popq	%rbx
    1049:      	popq	%r12
    104b:      	popq	%r13
    104d:      	popq	%r14
    104f:      	popq	%r15
    1051:      	popq	%rbp
    1052:      	retq
    1053:      	leal	-0xa(%r13), %eax
    1057:      	cmpl	$0x2, %eax
    105a:      	jb	0x106a <generic_fentry_process_event+0xcba>
    105c:      	leal	-0xc(%r13), %eax
    1060:      	cmpl	$0x2, %eax
    1063:      	jb	0x10a9 <generic_fentry_process_event+0xcf9>
    1065:      	jmp	0x1110 <generic_fentry_process_event+0xd60>
    106a:      	movl	$0x8, %r15d
    1070:      	jmp	0x1113 <generic_fentry_process_event+0xd63>
    1075:      	cmpl	$0x2a, %r13d
    1079:      	jg	0x10b9 <generic_fentry_process_event+0xd09>
    107b:      	cmpl	$0x28, %r13d
    107f:      	je	0x10cd <generic_fentry_process_event+0xd1d>
    1081:      	cmpl	$0x29, %r13d
    1085:      	je	0x10fa <generic_fentry_process_event+0xd4a>
    1087:      	jmp	0x1110 <generic_fentry_process_event+0xd60>
    108c:      	cmpl	$0x6, %r13d
    1090:      	jg	0x10e6 <generic_fentry_process_event+0xd36>
    1092:      	cmpl	$0x5, %r13d
    1096:      	je	0x10fa <generic_fentry_process_event+0xd4a>
    1098:      	cmpl	$0x6, %r13d
    109c:      	je	0x1113 <generic_fentry_process_event+0xd63>
    109e:      	jmp	0x1110 <generic_fentry_process_event+0xd60>
    10a0:      	leal	-0x1d(%r13), %eax
    10a4:      	cmpl	$0x4, %eax
    10a7:      	jae	0x110a <generic_fentry_process_event+0xd5a>
    10a9:      	movl	$0x4, %r15d
    10af:      	jmp	0x1113 <generic_fentry_process_event+0xd63>
    10b1:      	movl	$0x10, %r15d
    10b7:      	jmp	0x1113 <generic_fentry_process_event+0xd63>
    10b9:      	cmpl	$0x2b, %r13d
    10bd:      	je	0x10cd <generic_fentry_process_event+0xd1d>
    10bf:      	cmpl	$0x2c, %r13d
    10c3:      	jne	0x1110 <generic_fentry_process_event+0xd60>
    10c5:      	movl	$0x70, %r15d
    10cb:      	jmp	0x1113 <generic_fentry_process_event+0xd63>
    10cd:      	movl	$0x18, %r15d
    10d3:      	jmp	0x1113 <generic_fentry_process_event+0xd63>
    10d5:      	cmpl	$0x11, %r13d
    10d9:      	je	0x1113 <generic_fentry_process_event+0xd63>
    10db:      	movq	%r12, %r15
    10de:      	cmpl	$0x12, %r13d
    10e2:      	je	0x1113 <generic_fentry_process_event+0xd63>
    10e4:      	jmp	0x1110 <generic_fentry_process_event+0xd60>
    10e6:      	cmpl	$0x7, %r13d
    10ea:      	je	0x10fa <generic_fentry_process_event+0xd4a>
    10ec:      	cmpl	$0x8, %r13d
    10f0:      	jne	0x1110 <generic_fentry_process_event+0xd60>
    10f2:      	movl	$0x50, %r15d
    10f8:      	jmp	0x1113 <generic_fentry_process_event+0xd63>
    10fa:      	movl	$0x40, %r15d
    1100:      	jmp	0x1113 <generic_fentry_process_event+0xd63>
    1102:      	movl	$0x98, %r15d
    1108:      	jmp	0x1113 <generic_fentry_process_event+0xd63>
    110a:      	cmpl	$0x1b, %r13d
    110e:      	je	0x10f2 <generic_fentry_process_event+0xd42>
    1110:      	xorl	%r15d, %r15d
    1113:      	movl	$0x0, 0xfc(%rsp)
    111e:      	movq	(%rip), %rdi            # 0x1125 <generic_fentry_process_event+0xd75>
    1125:      	leaq	0xfc(%rsp), %rsi
    112d:      	movl	$0x1, %eax
    1132:      	callq	*%rax
    1134:      	xorl	%esi, %esi
    1136:      	testq	%rax, %rax
    1139:      	je	0xf8f <generic_fentry_process_event+0xbdf>
    113f:      	movl	$0x3ffb, %ecx           # imm = 0x3FFB
    1144:      	subq	%r15, %rcx
    1147:      	cmpq	0xc8(%rsp), %rcx
    114f:      	jbe	0xf8f <generic_fentry_process_event+0xbdf>
    1155:      	movq	0x20(%rsp), %rsi
    115a:      	movl	0x5ea0(%rax,%rsi,4), %ecx
    1161:      	movq	0xc8(%rsp), %rdx
    1169:      	movl	%ecx, 0x90(%rax,%rdx)
    1170:      	leaq	0x4(%rdx), %rdi
    1174:      	movq	%rdi, 0x5e78(%rax,%rsi,8)
    117c:      	movl	$0x4, %esi
    1181:      	testl	%ecx, %ecx
    1183:      	jne	0xf8f <generic_fentry_process_event+0xbdf>
    1189:      	movq	%rax, %r15
    118c:      	addq	$0x90, %r15
    1193:      	addq	%rdi, %r15
    1196:      	movq	0x10(%rsp), %rdx
    119b:      	movq	%rdx, 0x68(%rsp)
    11a0:      	movq	$0x0, 0x58(%rsp)
    11a9:      	cmpl	$0x17, %r13d
    11ad:      	movq	%rax, 0x38(%rsp)
    11b2:      	jle	0x11ef <generic_fentry_process_event+0xe3f>
    11b4:      	cmpl	$0x18, %r13d
    11b8:      	je	0x120a <generic_fentry_process_event+0xe5a>
    11ba:      	cmpl	$0x25, %r13d
    11be:      	je	0x1248 <generic_fentry_process_event+0xe98>
    11c4:      	cmpl	$0x2a, %r13d
    11c8:      	jne	0x1a5c <generic_fentry_process_event+0x16ac>
    11ce:      	movq	$0x0, 0xb0(%rsp)
    11da:      	movq	%rdx, 0xb8(%rsp)
    11e2:      	leaq	0xb0(%rsp), %rax
    11ea:      	jmp	0x1275 <generic_fentry_process_event+0xec5>
    11ef:      	cmpl	$0xf, %r13d
    11f3:      	je	0x198b <generic_fentry_process_event+0x15db>
    11f9:      	cmpl	$0x10, %r13d
    11fd:      	jne	0x1a5c <generic_fentry_process_event+0x16ac>
    1203:      	leaq	0x30(%rsp), %r12
    1208:      	jmp	0x1232 <generic_fentry_process_event+0xe82>
    120a:      	leaq	0x30(%rsp), %r12
    120f:      	movl	$0x8, %ecx
    1214:      	movl	$0x4, %eax
    1219:      	movq	0x68(%rsp), %rdx
    121e:      	movq	%r12, %rdi
    1221:      	movl	$0x8, %esi
    1226:      	callq	*%rax
    1228:      	movq	0x30(%rsp), %rax
    122d:      	movq	%rax, 0x68(%rsp)
    1232:      	leaq	0x68(%rsp), %rdx
    1237:      	movl	$0x8, %ecx
    123c:      	movl	$0x4, %eax
    1241:      	leaq	0x30(%rsp), %rdi
    1246:      	jmp	0x1265 <generic_fentry_process_event+0xeb5>
    1248:      	addq	$0x40, %rdx
    124c:      	movq	%rdx, 0x68(%rsp)
    1251:      	leaq	0x30(%rsp), %rdi
    1256:      	movl	$0x8, %ecx
    125b:      	movl	$0x4, %eax
    1260:      	movq	0x68(%rsp), %rdx
    1265:      	movl	$0x8, %esi
    126a:      	callq	*%rax
    126c:      	movq	0x30(%rsp), %rax
    1271:      	addq	$0x40, %rax
    1275:      	movq	%rax, 0xa8(%rsp)
    127d:      	movl	$0x0, 0xdc(%rsp)
    1288:      	movq	(%rip), %rdi            # 0x128f <generic_fentry_process_event+0xedf>
    128f:      	leaq	0xdc(%rsp), %rsi
    1297:      	movl	$0x1, %eax
    129c:      	callq	*%rax
    129e:      	testq	%rax, %rax
    12a1:      	je	0x18a0 <generic_fentry_process_event+0x14f0>
    12a7:      	movq	%rax, %r12
    12aa:      	movq	%r15, 0x48(%rsp)
    12af:      	addq	$0x1000, %rax           # imm = 0x1000
    12b5:      	movq	%rax, 0x10(%rsp)
    12ba:      	movl	$0x23, %eax
    12bf:      	callq	*%rax
    12c1:      	leaq	0xd50(%rax), %rdx
    12c8:      	leaq	0xd0(%rsp), %rdi
    12d0:      	movl	$0x8, %ecx
    12d5:      	movl	$0x4, %eax
    12da:      	movl	$0x8, %esi
    12df:      	callq	*%rax
    12e1:      	movq	0xd0(%rsp), %rbp
    12e9:      	movq	0xa8(%rsp), %rax
    12f1:      	leaq	0x8(%rax), %rdx
    12f5:      	leaq	0xe0(%rsp), %rdi
    12fd:      	movl	$0x8, %ecx
    1302:      	movl	$0x4, %eax
    1307:      	leaq	0x18(%rbp), %rcx
    130b:      	movq	%rcx, 0xe8(%rsp)
    1313:      	movl	$0x8, %esi
    1318:      	movq	%rdx, 0x40(%rsp)
    131d:      	callq	*%rax
    131f:      	movq	0xe0(%rsp), %r13
    1327:      	leaq	0x10(%r13), %rdx
    132b:      	leaq	0x68(%rsp), %rdi
    1330:      	movl	$0x8, %ecx
    1335:      	movl	$0x4, %eax
    133a:      	movl	$0x8, %esi
    133f:      	callq	*%rax
    1341:      	cmpq	$0x0, 0x68(%rsp)
    1347:      	movl	$0x1000, %r15d          # imm = 0x1000
    134d:      	je	0x1356 <generic_fentry_process_event+0xfa6>
    134f:      	movq	0x10(%rsp), %rcx
    1354:      	jmp	0x13a9 <generic_fentry_process_event+0xff9>
    1356:      	leaq	0x18(%r13), %rdx
    135a:      	leaq	0x68(%rsp), %rdi
    135f:      	movl	$0x8, %ecx
    1364:      	movl	$0x4, %eax
    1369:      	movl	$0x8, %esi
    136e:      	callq	*%rax
    1370:      	cmpq	%r13, 0x68(%rsp)
    1375:      	movq	0x10(%rsp), %rcx
    137a:      	je	0x13a9 <generic_fentry_process_event+0xff9>
    137c:      	movq	%r12, %rcx
    137f:      	addq	$0xff6, %rcx            # imm = 0xFF6
    1386:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    1390:      	movq	%rax, 0xff6(%r12)
    1398:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
    13a3:      	movl	$0xff6, %r15d           # imm = 0xFF6
    13a9:      	movq	$0x0, 0x70(%rsp)
    13b2:      	movq	$0x0, 0x68(%rsp)
    13bb:      	movq	%r12, 0x78(%rsp)
    13c0:      	movq	$0x0, 0x80(%rsp)
    13cc:      	movq	$0x0, 0x88(%rsp)
    13d8:      	movq	$0x0, 0x90(%rsp)
    13e4:      	movq	%rcx, 0x10(%rsp)
    13e9:      	movq	%rcx, 0x98(%rsp)
    13f1:      	movl	%r15d, 0xa0(%rsp)
    13f9:      	movb	$0x0, 0xa4(%rsp)
    1401:      	addq	$0x20, %rbp
    1405:      	leaq	0x68(%rsp), %rdi
    140a:      	movl	$0x8, %ecx
    140f:      	movl	$0x4, %eax
    1414:      	leaq	0x70(%rsp), %r12
    1419:      	leaq	0x80(%rsp), %r15
    1421:      	leaq	0x88(%rsp), %r13
    1429:      	movl	$0x8, %esi
    142e:      	movq	%rbp, %rdx
    1431:      	callq	*%rax
    1433:      	movl	$0x8, %ecx
    1438:      	movl	$0x4, %eax
    143d:      	movq	0xe8(%rsp), %rdx
    1445:      	movq	%r12, %rdi
    1448:      	movl	$0x8, %esi
    144d:      	callq	*%rax
    144f:      	movl	$0x8, %ecx
    1454:      	movl	$0x4, %eax
    1459:      	movq	0x40(%rsp), %rdx
    145e:      	movq	%r15, %rdi
    1461:      	movl	$0x8, %esi
    1466:      	callq	*%rax
    1468:      	movl	$0x8, %ecx
    146d:      	movl	$0x4, %eax
    1472:      	movq	0xa8(%rsp), %rdx
    147a:      	movq	%r13, %rdi
    147d:      	movl	$0x8, %esi
    1482:      	callq	*%rax
    1484:      	movq	0x88(%rsp), %rax
    148c:      	addq	$-0x20, %rax
    1490:      	movq	%rax, 0x90(%rsp)
    1498:      	movq	(%rip), %rax            # 0x149f <generic_fentry_process_event+0x10ef>
    149f:      	cmpb	$0x0, (%rax)
    14a2:      	je	0x167d <generic_fentry_process_event+0x12cd>
    14a8:      	movl	$0x80, %r15d
    14ae:      	movl	$0x8, %r13d
    14b4:      	jmp	0x14bf <generic_fentry_process_event+0x110f>
    14b6:      	decl	%r15d
    14b9:      	je	0x1857 <generic_fentry_process_event+0x14a7>
    14bf:      	movq	0x80(%rsp), %rbp
    14c7:      	movq	0x88(%rsp), %rdx
    14cf:      	movq	0x90(%rsp), %r12
    14d7:      	cmpq	0x68(%rsp), %rbp
    14dc:      	jne	0x14e9 <generic_fentry_process_event+0x1139>
    14de:      	cmpq	0x70(%rsp), %rdx
    14e3:      	je	0x184f <generic_fentry_process_event+0x149f>
    14e9:      	movl	$0x4, %eax
    14ee:      	leaq	0xc0(%rsp), %rdi
    14f6:      	movl	$0x8, %esi
    14fb:      	callq	*%rax
    14fd:      	cmpq	0xc0(%rsp), %rbp
    1505:      	movl	$0x8, %ecx
    150a:      	je	0x1615 <generic_fentry_process_event+0x1265>
    1510:      	leaq	0x18(%rbp), %r13
    1514:      	movl	$0x4, %eax
    1519:      	leaq	0x30(%rsp), %rdi
    151e:      	movl	$0x8, %esi
    1523:      	movq	%r13, %rdx
    1526:      	callq	*%rax
    1528:      	movl	$0x8, %ecx
    152d:      	cmpq	%rbp, 0x30(%rsp)
    1532:      	je	0x1615 <generic_fentry_process_event+0x1265>
    1538:      	movl	$0x4, %eax
    153d:      	leaq	0x50(%rsp), %rdi
    1542:      	movl	$0x8, %esi
    1547:      	movq	%r13, %rdx
    154a:      	callq	*%rax
    154c:      	addq	$0x20, %rbp
    1550:      	movl	$0x4, %eax
    1555:      	leaq	0x58(%rsp), %rdi
    155a:      	movl	$0x10, %ecx
    155f:      	movl	$0x10, %esi
    1564:      	movq	%rbp, %rdx
    1567:      	callq	*%rax
    1569:      	movq	0x78(%rsp), %r12
    156e:      	movq	0x98(%rsp), %rax
    1576:      	movl	0x5c(%rsp), %ebp
    157a:      	subq	%r12, %rax
    157d:      	movl	0xa0(%rsp), %r13d
    1585:      	movl	%ebp, %edx
    1587:      	subl	%r13d, %edx
    158a:      	movl	$0x0, %ecx
    158f:      	cmovbl	%ecx, %edx
    1592:      	addq	0x60(%rsp), %rdx
    1597:      	xorl	%esi, %esi
    1599:      	cmpl	%ebp, %r13d
    159c:      	seta	%sil
    15a0:      	movl	%ebp, %ecx
    15a2:      	cmovbl	%r13d, %ecx
    15a6:      	addl	%ecx, %esi
    15a8:      	movl	%r13d, %edi
    15ab:      	subl	%esi, %edi
    15ad:      	movl	%edi, 0xa0(%rsp)
    15b4:      	subq	%rsi, %rax
    15b7:      	jb	0x1857 <generic_fentry_process_event+0x14a7>
    15bd:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    15c3:      	ja	0x1857 <generic_fentry_process_event+0x14a7>
    15c9:      	cmpl	%ebp, %r13d
    15cc:      	jbe	0x15d3 <generic_fentry_process_event+0x1223>
    15ce:      	movb	$0x2f, (%r12,%rax)
    15d3:      	xorl	%edi, %edi
    15d5:      	cmpl	%ebp, %r13d
    15d8:      	seta	%dil
    15dc:      	movzbl	%cl, %esi
    15df:      	addq	%rax, %r12
    15e2:      	addq	%r12, %rdi
    15e5:      	movl	$0x4, %eax
    15ea:      	callq	*%rax
    15ec:      	movq	%r12, 0x98(%rsp)
    15f4:      	cmpl	%ebp, %r13d
    15f7:      	jbe	0x1857 <generic_fentry_process_event+0x14a7>
    15fd:      	movq	0x50(%rsp), %rax
    1602:      	movq	%rax, 0x80(%rsp)
    160a:      	movl	$0x8, %r13d
    1610:      	jmp	0x14b6 <generic_fentry_process_event+0x1106>
    1615:      	leaq	0x10(%r12), %rdx
    161a:      	movl	$0x4, %eax
    161f:      	leaq	0x30(%rsp), %rdi
    1624:      	movl	$0x8, %esi
    1629:      	callq	*%rax
    162b:      	movq	0x90(%rsp), %rax
    1633:      	cmpq	0x30(%rsp), %rax
    1638:      	movl	$0x8, %r13d
    163e:      	je	0x184f <generic_fentry_process_event+0x149f>
    1644:      	addq	$0x18, %r12
    1648:      	movl	$0x4, %eax
    164d:      	leaq	0x80(%rsp), %rdi
    1655:      	movl	$0x8, %esi
    165a:      	movq	%r12, %rdx
    165d:      	callq	*%rax
    165f:      	movq	0x30(%rsp), %rax
    1664:      	movq	%rax, 0x90(%rsp)
    166c:      	addq	$0x20, %rax
    1670:      	movq	%rax, 0x88(%rsp)
    1678:      	jmp	0x14b6 <generic_fentry_process_event+0x1106>
    167d:      	movl	$0x80, %r15d
    1683:      	movl	$0x8, %r13d
    1689:      	movq	0x80(%rsp), %rbp
    1691:      	movq	0x88(%rsp), %rdx
    1699:      	movq	0x90(%rsp), %r12
    16a1:      	cmpq	0x68(%rsp), %rbp
    16a6:      	jne	0x16b3 <generic_fentry_process_event+0x1303>
    16a8:      	cmpq	0x70(%rsp), %rdx
    16ad:      	je	0x184f <generic_fentry_process_event+0x149f>
    16b3:      	movl	$0x4, %eax
    16b8:      	leaq	0xc0(%rsp), %rdi
    16c0:      	movl	$0x8, %esi
    16c5:      	callq	*%rax
    16c7:      	cmpq	0xc0(%rsp), %rbp
    16cf:      	movl	$0x8, %ecx
    16d4:      	je	0x17e5 <generic_fentry_process_event+0x1435>
    16da:      	leaq	0x18(%rbp), %r13
    16de:      	movl	$0x4, %eax
    16e3:      	leaq	0x30(%rsp), %rdi
    16e8:      	movl	$0x8, %esi
    16ed:      	movq	%r13, %rdx
    16f0:      	callq	*%rax
    16f2:      	movl	$0x8, %ecx
    16f7:      	cmpq	%rbp, 0x30(%rsp)
    16fc:      	je	0x17e5 <generic_fentry_process_event+0x1435>
    1702:      	movl	$0x4, %eax
    1707:      	leaq	0x50(%rsp), %rdi
    170c:      	movl	$0x8, %esi
    1711:      	movq	%r13, %rdx
    1714:      	callq	*%rax
    1716:      	addq	$0x20, %rbp
    171a:      	movl	$0x4, %eax
    171f:      	leaq	0x58(%rsp), %rdi
    1724:      	movl	$0x10, %ecx
    1729:      	movl	$0x10, %esi
    172e:      	movq	%rbp, %rdx
    1731:      	callq	*%rax
    1733:      	movq	0x78(%rsp), %r12
    1738:      	movq	0x98(%rsp), %rax
    1740:      	movl	0x5c(%rsp), %ebp
    1744:      	subq	%r12, %rax
    1747:      	movl	0xa0(%rsp), %r13d
    174f:      	movl	%ebp, %edx
    1751:      	subl	%r13d, %edx
    1754:      	movl	$0x0, %ecx
    1759:      	cmovbl	%ecx, %edx
    175c:      	addq	0x60(%rsp), %rdx
    1761:      	xorl	%esi, %esi
    1763:      	cmpl	%ebp, %r13d
    1766:      	seta	%sil
    176a:      	movl	%ebp, %ecx
    176c:      	cmovbl	%r13d, %ecx
    1770:      	addl	%ecx, %esi
    1772:      	movl	%r13d, %edi
    1775:      	subl	%esi, %edi
    1777:      	movl	%edi, 0xa0(%rsp)
    177e:      	subq	%rsi, %rax
    1781:      	jb	0x1857 <generic_fentry_process_event+0x14a7>
    1787:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    178d:      	ja	0x1857 <generic_fentry_process_event+0x14a7>
    1793:      	cmpl	%ebp, %r13d
    1796:      	jbe	0x179d <generic_fentry_process_event+0x13ed>
    1798:      	movb	$0x2f, (%r12,%rax)
    179d:      	xorl	%edi, %edi
    179f:      	cmpl	%ebp, %r13d
    17a2:      	seta	%dil
    17a6:      	movzbl	%cl, %esi
    17a9:      	addq	%rax, %r12
    17ac:      	addq	%r12, %rdi
    17af:      	movl	$0x4, %eax
    17b4:      	callq	*%rax
    17b6:      	movq	%r12, 0x98(%rsp)
    17be:      	cmpl	%ebp, %r13d
    17c1:      	jbe	0x1857 <generic_fentry_process_event+0x14a7>
    17c7:      	movq	0x50(%rsp), %rax
    17cc:      	movq	%rax, 0x80(%rsp)
    17d4:      	movl	$0x8, %r13d
    17da:      	decl	%r15d
    17dd:      	jne	0x1689 <generic_fentry_process_event+0x12d9>
    17e3:      	jmp	0x1857 <generic_fentry_process_event+0x14a7>
    17e5:      	leaq	0x10(%r12), %rdx
    17ea:      	movl	$0x4, %eax
    17ef:      	leaq	0x30(%rsp), %rdi
    17f4:      	movl	$0x8, %esi
    17f9:      	callq	*%rax
    17fb:      	movq	0x90(%rsp), %rax
    1803:      	cmpq	0x30(%rsp), %rax
    1808:      	movl	$0x8, %r13d
    180e:      	je	0x184f <generic_fentry_process_event+0x149f>
    1810:      	addq	$0x18, %r12
    1814:      	movl	$0x4, %eax
    1819:      	leaq	0x80(%rsp), %rdi
    1821:      	movl	$0x8, %esi
    1826:      	movq	%r12, %rdx
    1829:      	callq	*%rax
    182b:      	movq	0x30(%rsp), %rax
    1830:      	movq	%rax, 0x90(%rsp)
    1838:      	addq	$0x20, %rax
    183c:      	movq	%rax, 0x88(%rsp)
    1844:      	decl	%r15d
    1847:      	jne	0x1689 <generic_fentry_process_event+0x12d9>
    184d:      	jmp	0x1857 <generic_fentry_process_event+0x14a7>
    184f:      	movb	$0x1, 0xa4(%rsp)
    1857:      	movq	0x98(%rsp), %rax
    185f:      	movq	0x10(%rsp), %rdx
    1864:      	cmpq	%rdx, %rax
    1867:      	je	0x18a8 <generic_fentry_process_event+0x14f8>
    1869:      	xorl	%ebp, %ebp
    186b:      	cmpb	$0x0, 0xa4(%rsp)
    1873:      	sete	%cl
    1876:      	movl	0xa0(%rsp), %edx
    187d:      	movl	$0x1000, %r13d          # imm = 0x1000
    1883:      	subl	%edx, %r13d
    1886:      	testl	%edx, %edx
    1888:      	cmovlel	%edx, %r13d
    188c:      	testq	%rax, %rax
    188f:      	movq	0x48(%rsp), %r15
    1894:      	je	0x18a0 <generic_fentry_process_event+0x14f0>
    1896:      	movb	%cl, %bpl
    1899:      	addl	%ebp, %ebp
    189b:      	movq	%rax, %rdx
    189e:      	jmp	0x18b2 <generic_fentry_process_event+0x1502>
    18a0:      	xorl	%r13d, %r13d
    18a3:      	jmp	0x1955 <generic_fentry_process_event+0x15a5>
    18a8:      	xorl	%r13d, %r13d
    18ab:      	xorl	%ebp, %ebp
    18ad:      	movq	0x48(%rsp), %r15
    18b2:      	leaq	0x4(%r15), %rdi
    18b6:      	andl	$0xfff, %r13d           # imm = 0xFFF
    18bd:      	movl	$0x4, %eax
    18c2:      	movl	%r13d, %esi
    18c5:      	callq	*%rax
    18c7:      	movl	%r13d, (%r15)
    18ca:      	leaq	0x68(%rsp), %rdi
    18cf:      	movl	$0x8, %ecx
    18d4:      	movl	$0x4, %eax
    18d9:      	movq	0x40(%rsp), %rdx
    18de:      	movl	$0x8, %esi
    18e3:      	callq	*%rax
    18e5:      	movq	0x68(%rsp), %rcx
    18ea:      	addq	$0x30, %rcx
    18ee:      	leaq	0x58(%rsp), %rdi
    18f3:      	movl	$0x8, %edx
    18f8:      	movl	$0x4, %eax
    18fd:      	movq	0x68(%rsp), %rdx
    1902:      	addq	$0x30, %rdx
    1906:      	movl	$0x8, %esi
    190b:      	callq	*%rax
    190d:      	movq	0x58(%rsp), %rcx
    1912:      	leaq	0x30(%rsp), %rdi
    1917:      	movl	$0x2, %edx
    191c:      	movl	$0x4, %eax
    1921:      	movq	0x58(%rsp), %rdx
    1926:      	movl	$0x2, %esi
    192b:      	callq	*%rax
    192d:      	movl	%ebp, 0x4(%r15,%r13)
    1932:      	movzwl	0x30(%rsp), %eax
    1937:      	movw	%ax, 0x8(%r15,%r13)
    193d:      	addl	$0xa, %r13d
    1941:      	movq	0x38(%rsp), %rax
    1946:      	movq	0x20(%rsp), %rcx
    194b:      	movl	$0x4, %esi
    1950:      	testl	%r13d, %r13d
    1953:      	js	0x1968 <generic_fentry_process_event+0x15b8>
    1955:      	andl	$0x7fffffff, %r13d      # imm = 0x7FFFFFFF
    195c:      	addq	$0x4, %r13
    1960:      	movq	%r13, %rsi
    1963:      	jmp	0xf8f <generic_fentry_process_event+0xbdf>
    1968:      	movl	$0xffffffff, 0x5ea0(%rax,%rcx,4) # imm = 0xFFFFFFFF
    1973:      	movq	0xc8(%rsp), %rcx
    197b:      	movl	$0xffffffff, 0x90(%rax,%rcx) # imm = 0xFFFFFFFF
    1986:      	jmp	0xf8f <generic_fentry_process_event+0xbdf>
    198b:      	movq	%rdi, 0x48(%rsp)
    1990:      	leaq	0x58(%rsp), %rdi
    1995:      	leaq	0x68(%rsp), %rdx
    199a:      	movl	$0x8, %ecx
    199f:      	movl	$0x4, %eax
    19a4:      	movl	$0x8, %esi
    19a9:      	callq	*%rax
    19ab:      	movq	0x58(%rsp), %rax
    19b0:      	movq	%rax, 0xa8(%rsp)
    19b8:      	testq	%rax, %rax
    19bb:      	jne	0x127d <generic_fentry_process_event+0xecd>
    19c1:      	movl	$0x0, 0xe0(%rsp)
    19cc:      	movq	(%rip), %rdi            # 0x19d3 <generic_fentry_process_event+0x1623>
    19d3:      	leaq	0xe0(%rsp), %rsi
    19db:      	movl	$0x1, %eax
    19e0:      	callq	*%rax
    19e2:      	testq	%rax, %rax
    19e5:      	je	0x1b00 <generic_fentry_process_event+0x1750>
    19eb:      	cmpl	$0x19, %r13d
    19ef:      	movq	%rbx, 0x18(%rsp)
    19f4:      	movq	%r14, 0x28(%rsp)
    19f9:      	jg	0x1d82 <generic_fentry_process_event+0x19d2>
    19ff:      	cmpl	$0x12, %r13d
    1a03:      	jle	0x1efb <generic_fentry_process_event+0x1b4b>
    1a09:      	movq	%r13, %rax
    1a0c:      	cmpl	$0x14, %r13d
    1a10:      	jle	0x228c <generic_fentry_process_event+0x1edc>
    1a16:      	cmpl	$0x15, %eax
    1a19:      	je	0x2c2e <generic_fentry_process_event+0x287e>
    1a1f:      	cmpl	$0x16, %eax
    1a22:      	je	0x2ba6 <generic_fentry_process_event+0x27f6>
    1a28:      	cmpl	$0x17, %eax
    1a2b:      	movq	0x18(%rsp), %rbx
    1a30:      	movq	0x28(%rsp), %r14
    1a35:      	movl	$0x0, %r13d
    1a3b:      	jne	0x1941 <generic_fentry_process_event+0x1591>
    1a41:      	movl	$0x0, 0x4(%r15)
    1a49:      	movq	0x10(%rsp), %rax
    1a4e:      	movl	%eax, (%r15)
    1a51:      	movl	$0x8, %r13d
    1a57:      	jmp	0x1941 <generic_fentry_process_event+0x1591>
    1a5c:      	movq	%rdi, 0x48(%rsp)
    1a61:      	cmpl	$0x2c, %r13d
    1a65:      	ja	0x19c1 <generic_fentry_process_event+0x1611>
    1a6b:      	movabsq	$0x11c1f2027cf2, %rax   # imm = 0x11C1F2027CF2
    1a75:      	btq	%rbp, %rax
    1a79:      	jae	0x19c1 <generic_fentry_process_event+0x1611>
    1a7f:      	movq	%rdx, 0x50(%rsp)
    1a84:      	movl	$0x0, 0xe0(%rsp)
    1a8f:      	movq	(%rip), %rdi            # 0x1a96 <generic_fentry_process_event+0x16e6>
    1a96:      	leaq	0xe0(%rsp), %rsi
    1a9e:      	movl	$0x1, %eax
    1aa3:      	callq	*%rax
    1aa5:      	testq	%rax, %rax
    1aa8:      	je	0x1b00 <generic_fentry_process_event+0x1750>
    1aaa:      	movq	%r15, %rbp
    1aad:      	cmpl	$0x10, %r13d
    1ab1:      	jle	0x1b08 <generic_fentry_process_event+0x1758>
    1ab3:      	cmpl	$0x1e, %r13d
    1ab7:      	jle	0x1c88 <generic_fentry_process_event+0x18d8>
    1abd:      	movq	%r14, %r15
    1ac0:      	movq	%rbx, 0x18(%rsp)
    1ac5:      	cmpl	$0x26, %r13d
    1ac9:      	jg	0x1dc5 <generic_fentry_process_event+0x1a15>
    1acf:      	leal	-0x1f(%r13), %eax
    1ad3:      	cmpl	$0x2, %eax
    1ad6:      	jae	0x2368 <generic_fentry_process_event+0x1fb8>
    1adc:      	leaq	0x50(%rsp), %rdx
    1ae1:      	movl	$0x4, %r13d
    1ae7:      	movl	$0x1, %ecx
    1aec:      	movl	$0x4, %eax
    1af1:      	movq	%rbp, %rdi
    1af4:      	movl	$0x1, %esi
    1af9:      	callq	*%rax
    1afb:      	jmp	0x31c6 <generic_fentry_process_event+0x2e16>
    1b00:      	xorl	%r13d, %r13d
    1b03:      	jmp	0x1941 <generic_fentry_process_event+0x1591>
    1b08:      	cmpl	$0x9, %r13d
    1b0c:      	jg	0x1cc1 <generic_fentry_process_event+0x1911>
    1b12:      	movq	%r14, 0x28(%rsp)
    1b17:      	movq	%rbx, 0x18(%rsp)
    1b1c:      	cmpl	$0x4, %r13d
    1b20:      	jle	0x1f92 <generic_fentry_process_event+0x1be2>
    1b26:      	cmpl	$0x5, %r13d
    1b2a:      	je	0x26dd <generic_fentry_process_event+0x232d>
    1b30:      	movq	%rax, %r15
    1b33:      	movq	%r13, %rax
    1b36:      	cmpl	$0x6, %eax
    1b39:      	je	0x1d4c <generic_fentry_process_event+0x199c>
    1b3f:      	cmpl	$0x7, %eax
    1b42:      	movq	0x38(%rsp), %rax
    1b47:      	movq	0x20(%rsp), %rcx
    1b4c:      	movl	$0x4, %esi
    1b51:      	movq	0x18(%rsp), %rbx
    1b56:      	movq	0x28(%rsp), %r14
    1b5b:      	movl	$0x0, %r13d
    1b61:      	jne	0x1950 <generic_fentry_process_event+0x15a0>
    1b67:      	movq	0x50(%rsp), %r12
    1b6c:      	movq	%rbp, %rbx
    1b6f:      	movq	%r12, 0x28(%rbp)
    1b73:      	leaq	0x26(%rbp), %rdi
    1b77:      	leaq	0x10(%r12), %rdx
    1b7c:      	movl	$0x2, %ecx
    1b81:      	movl	$0x4, %eax
    1b86:      	movl	$0x2, %esi
    1b8b:      	callq	*%rax
    1b8d:      	leaq	0x3a(%rbp), %rdi
    1b91:      	leaq	0x12(%r12), %rdx
    1b96:      	movl	$0x1, %ecx
    1b9b:      	movl	$0x4, %eax
    1ba0:      	movl	$0x1, %esi
    1ba5:      	callq	*%rax
    1ba7:      	leaq	0x38(%rbp), %rdi
    1bab:      	leaq	0x226(%r12), %rdx
    1bb3:      	movl	$0x2, %ecx
    1bb8:      	movl	$0x4, %eax
    1bbd:      	movl	$0x2, %esi
    1bc2:      	callq	*%rax
    1bc4:      	leaq	0x24(%rbp), %rdi
    1bc8:      	leaq	0x224(%r12), %rdx
    1bd0:      	movl	$0x2, %ecx
    1bd5:      	movl	$0x4, %eax
    1bda:      	movl	$0x2, %esi
    1bdf:      	callq	*%rax
    1be1:      	leaq	0x30(%rbp), %rdi
    1be5:      	leaq	0x21c(%r12), %rdx
    1bed:      	movl	$0x4, %ecx
    1bf2:      	movl	$0x4, %eax
    1bf7:      	movl	$0x4, %esi
    1bfc:      	callq	*%rax
    1bfe:      	leaq	0x34(%rbp), %rdi
    1c02:      	leaq	0x218(%r12), %rdx
    1c0a:      	movl	$0x4, %ecx
    1c0f:      	movl	$0x4, %eax
    1c14:      	movl	$0x4, %esi
    1c19:      	callq	*%rax
    1c1b:      	leaq	0x10(%rbp), %r13
    1c1f:      	movq	$0x0, (%rbp)
    1c27:      	movq	$0x0, 0x8(%rbp)
    1c2f:      	movq	$0x0, 0x10(%rbp)
    1c37:      	movq	$0x0, 0x18(%rbp)
    1c3f:      	movzwl	0x26(%rbp), %eax
    1c43:      	cmpl	$0xa, %eax
    1c46:      	je	0x2efe <generic_fentry_process_event+0x2b4e>
    1c4c:      	cmpl	$0x2, %eax
    1c4f:      	jne	0x2f30 <generic_fentry_process_event+0x2b80>
    1c55:      	leaq	0x4(%r12), %rdx
    1c5a:      	movl	$0x4, %ecx
    1c5f:      	movl	$0x4, %eax
    1c64:      	movq	%rbp, %rdi
    1c67:      	movl	$0x4, %esi
    1c6c:      	callq	*%rax
    1c6e:      	movl	$0x4, %ecx
    1c73:      	movl	$0x4, %eax
    1c78:      	movq	%r13, %rdi
    1c7b:      	movl	$0x4, %esi
    1c80:      	movq	%r12, %rdx
    1c83:      	jmp	0x2f2e <generic_fentry_process_event+0x2b7e>
    1c88:      	cmpl	$0x1c, %r13d
    1c8c:      	jg	0x1f6e <generic_fentry_process_event+0x1bbe>
    1c92:      	movq	%rax, %r15
    1c95:      	movq	%r13, %rax
    1c98:      	cmpl	$0x11, %eax
    1c9b:      	je	0x23b5 <generic_fentry_process_event+0x2005>
    1ca1:      	cmpl	$0x19, %eax
    1ca4:      	je	0x2471 <generic_fentry_process_event+0x20c1>
    1caa:      	cmpl	$0x1c, %eax
    1cad:      	movq	0x38(%rsp), %rax
    1cb2:      	movq	0x20(%rsp), %rcx
    1cb7:      	movl	$0x4, %esi
    1cbc:      	jmp	0x1fb7 <generic_fentry_process_event+0x1c07>
    1cc1:      	leal	-0xa(%r13), %eax
    1cc5:      	cmpl	$0x2, %eax
    1cc8:      	jb	0x1fc3 <generic_fentry_process_event+0x1c13>
    1cce:      	movq	%r13, %rcx
    1cd1:      	movq	%r14, 0x28(%rsp)
    1cd6:      	movq	%rbx, 0x18(%rsp)
    1cdb:      	leal	-0xc(%r13), %eax
    1cdf:      	cmpl	$0x2, %eax
    1ce2:      	jb	0x1ff6 <generic_fentry_process_event+0x1c46>
    1ce8:      	cmpl	$0xe, %ecx
    1ceb:      	movq	0x38(%rsp), %rax
    1cf0:      	movq	0x20(%rsp), %rcx
    1cf5:      	movl	$0x4, %esi
    1cfa:      	movq	0x18(%rsp), %rbx
    1cff:      	movq	0x28(%rsp), %r14
    1d04:      	movl	$0x0, %r13d
    1d0a:      	jne	0x1950 <generic_fentry_process_event+0x15a0>
    1d10:      	leaq	0x68(%rsp), %rdi
    1d15:      	leaq	0x50(%rsp), %r12
    1d1a:      	movl	$0x8, %ecx
    1d1f:      	movl	$0x4, %eax
    1d24:      	movl	$0x8, %esi
    1d29:      	movq	%r12, %rdx
    1d2c:      	callq	*%rax
    1d2e:      	movq	0x68(%rsp), %rcx
    1d33:      	movl	$0x8, %edx
    1d38:      	movl	$0x4, %eax
    1d3d:      	movq	0x68(%rsp), %rdx
    1d42:      	movq	%r12, %rdi
    1d45:      	movl	$0x8, %esi
    1d4a:      	callq	*%rax
    1d4c:      	movq	0x50(%rsp), %rdx
    1d51:      	leaq	0x4(%rbp), %rdi
    1d55:      	movl	$0x1001, %ecx           # imm = 0x1001
    1d5a:      	movl	$0x2d, %eax
    1d5f:      	movl	$0x1001, %esi           # imm = 0x1001
    1d64:      	callq	*%rax
    1d66:      	movq	%rax, %r13
    1d69:      	testq	%rax, %rax
    1d6c:      	js	0x442f <generic_fentry_process_event+0x407f>
    1d72:      	leal	-0x1(%r13), %eax
    1d76:      	movl	%eax, (%rbp)
    1d79:      	addq	$0x3, %r13
    1d7d:      	jmp	0x442f <generic_fentry_process_event+0x407f>
    1d82:      	movq	%rax, 0x40(%rsp)
    1d87:      	movq	%r15, %rbp
    1d8a:      	cmpl	$0x20, %r13d
    1d8e:      	jle	0x2183 <generic_fentry_process_event+0x1dd3>
    1d94:      	leal	-0x21(%r13), %eax
    1d98:      	cmpl	$0x4, %eax
    1d9b:      	jae	0x201a <generic_fentry_process_event+0x1c6a>
    1da1:      	movl	$0x8, %r13d
    1da7:      	movl	$0x8, %ecx
    1dac:      	movl	$0x4, %eax
    1db1:      	movq	0x10(%rsp), %rdx
    1db6:      	movq	%rbp, %rdi
    1db9:      	movl	$0x8, %esi
    1dbe:      	callq	*%rax
    1dc0:      	jmp	0x409a <generic_fentry_process_event+0x3cea>
    1dc5:      	cmpl	$0x27, %r13d
    1dc9:      	je	0x288f <generic_fentry_process_event+0x24df>
    1dcf:      	movq	%r13, %rax
    1dd2:      	cmpl	$0x28, %eax
    1dd5:      	je	0x28ca <generic_fentry_process_event+0x251a>
    1ddb:      	cmpl	$0x2c, %eax
    1dde:      	movq	0x38(%rsp), %rax
    1de3:      	movq	0x20(%rsp), %rcx
    1de8:      	movl	$0x4, %esi
    1ded:      	movq	0x18(%rsp), %rbx
    1df2:      	movq	%r15, %r14
    1df5:      	movl	$0x0, %r13d
    1dfb:      	jne	0x1950 <generic_fentry_process_event+0x15a0>
    1e01:      	movq	0x50(%rsp), %r12
    1e06:      	movb	$0x0, 0x68(%rsp)
    1e0b:      	movq	%rbp, %rdi
    1e0e:      	movq	$0x0, 0x68(%rbp)
    1e16:      	movq	$0x0, 0x60(%rbp)
    1e1e:      	movq	$0x0, 0x58(%rbp)
    1e26:      	movq	$0x0, 0x50(%rbp)
    1e2e:      	movq	$0x0, 0x48(%rbp)
    1e36:      	movq	$0x0, 0x40(%rbp)
    1e3e:      	movq	$0x0, 0x38(%rbp)
    1e46:      	movq	$0x0, 0x30(%rbp)
    1e4e:      	movq	$0x0, 0x28(%rbp)
    1e56:      	movq	$0x0, 0x20(%rbp)
    1e5e:      	movq	$0x0, 0x18(%rbp)
    1e66:      	movq	$0x0, 0x10(%rbp)
    1e6e:      	movq	$0x0, 0x8(%rbp)
    1e76:      	movq	$0x0, (%rbp)
    1e7e:      	movl	$0x2, %ecx
    1e83:      	movl	$0x4, %eax
    1e88:      	movl	$0x2, %esi
    1e8d:      	movq	%r12, %rdx
    1e90:      	callq	*%rax
    1e92:      	testq	%rax, %rax
    1e95:      	js	0x31c0 <generic_fentry_process_event+0x2e10>
    1e9b:      	leaq	0x2(%r12), %r13
    1ea0:      	leaq	0x68(%rsp), %rdi
    1ea5:      	movl	$0x1, %ecx
    1eaa:      	movl	$0x4, %eax
    1eaf:      	movl	$0x1, %esi
    1eb4:      	movq	%r13, %rdx
    1eb7:      	callq	*%rax
    1eb9:      	testq	%rax, %rax
    1ebc:      	js	0x31c0 <generic_fentry_process_event+0x2e10>
    1ec2:      	movq	%rbp, %rax
    1ec5:      	leaq	0x4(%rbp), %rdi
    1ec9:      	cmpb	$0x0, 0x68(%rsp)
    1ece:      	sete	0x2(%rbp)
    1ed2:      	je	0x319c <generic_fentry_process_event+0x2dec>
    1ed8:      	movl	$0x6c, %ecx
    1edd:      	movl	$0x2d, %eax
    1ee2:      	movl	$0x6c, %esi
    1ee7:      	movq	%r13, %rdx
    1eea:      	callq	*%rax
    1eec:      	testl	%eax, %eax
    1eee:      	js	0x31c0 <generic_fentry_process_event+0x2e10>
    1ef4:      	decb	%al
    1ef6:      	jmp	0x31bd <generic_fentry_process_event+0x2e0d>
    1efb:      	movq	%rax, %rbp
    1efe:      	movq	%r13, %rax
    1f01:      	cmpl	$0x7, %r13d
    1f05:      	jg	0x2247 <generic_fentry_process_event+0x1e97>
    1f0b:      	cmpl	$0x2, %eax
    1f0e:      	je	0x2957 <generic_fentry_process_event+0x25a7>
    1f14:      	cmpl	$0x3, %eax
    1f17:      	movq	0x18(%rsp), %rbx
    1f1c:      	movq	0x28(%rsp), %r14
    1f21:      	movl	$0x0, %r13d
    1f27:      	jne	0x1941 <generic_fentry_process_event+0x1591>
    1f2d:      	leaq	0x90(%rbp), %r13
    1f34:      	andl	$0xf, %r12d
    1f38:      	movq	%r12, %rax
    1f3b:      	cmpl	$0x2, %r12d
    1f3f:      	jle	0x3082 <generic_fentry_process_event+0x2cd2>
    1f45:      	cmpl	$0x3, %eax
    1f48:      	je	0x3359 <generic_fentry_process_event+0x2fa9>
    1f4e:      	cmpl	$0x4, %eax
    1f51:      	je	0x3364 <generic_fentry_process_event+0x2fb4>
    1f57:      	cmpl	$0x5, %eax
    1f5a:      	jne	0x3711 <generic_fentry_process_event+0x3361>
    1f60:      	movq	%rbp, %rax
    1f63:      	addq	$0x5e70, %rax           # imm = 0x5E70
    1f69:      	jmp	0x3378 <generic_fentry_process_event+0x2fc8>
    1f6e:      	leaq	0x50(%rsp), %rdx
    1f73:      	movl	$0x4, %r13d
    1f79:      	movl	$0x2, %ecx
    1f7e:      	movl	$0x4, %eax
    1f83:      	movq	%rbp, %rdi
    1f86:      	movl	$0x2, %esi
    1f8b:      	callq	*%rax
    1f8d:      	jmp	0x1941 <generic_fentry_process_event+0x1591>
    1f92:      	cmpl	$0x1, %r13d
    1f96:      	je	0x1ff6 <generic_fentry_process_event+0x1c46>
    1f98:      	movq	%r13, %rax
    1f9b:      	cmpl	$0x4, %eax
    1f9e:      	movq	0x38(%rsp), %rax
    1fa3:      	movq	0x20(%rsp), %rcx
    1fa8:      	movl	$0x4, %esi
    1fad:      	movq	0x18(%rsp), %rbx
    1fb2:      	movq	0x28(%rsp), %r14
    1fb7:      	movl	$0x0, %r13d
    1fbd:      	jne	0x1950 <generic_fentry_process_event+0x15a0>
    1fc3:      	movl	$0x8, %r13d
    1fc9:      	leaq	0x50(%rsp), %rdx
    1fce:      	movl	$0x8, %ecx
    1fd3:      	movl	$0x4, %eax
    1fd8:      	movq	%rbp, %rdi
    1fdb:      	movl	$0x8, %esi
    1fe0:      	callq	*%rax
    1fe2:      	movl	$0x4, %esi
    1fe7:      	movq	0x20(%rsp), %rcx
    1fec:      	movq	0x38(%rsp), %rax
    1ff1:      	jmp	0x1950 <generic_fentry_process_event+0x15a0>
    1ff6:      	leaq	0x50(%rsp), %rdx
    1ffb:      	movl	$0x4, %r13d
    2001:      	movl	$0x4, %ecx
    2006:      	movl	$0x4, %eax
    200b:      	movq	%rbp, %rdi
    200e:      	movl	$0x4, %esi
    2013:      	callq	*%rax
    2015:      	jmp	0x442f <generic_fentry_process_event+0x407f>
    201a:      	movq	%r13, %rcx
    201d:      	cmpl	$0x2b, %ecx
    2020:      	je	0x2d1e <generic_fentry_process_event+0x296e>
    2026:      	cmpl	$0x29, %ecx
    2029:      	movq	0x18(%rsp), %rbx
    202e:      	movq	0x28(%rsp), %r14
    2033:      	movl	$0x0, %r13d
    2039:      	jne	0x1941 <generic_fentry_process_event+0x1591>
    203f:      	movq	0x10(%rsp), %rdx
    2044:      	addq	$0x18, %rdx
    2048:      	leaq	0x68(%rsp), %rdi
    204d:      	movl	$0x4, %ebx
    2052:      	movl	$0x8, %ecx
    2057:      	movl	$0x4, %eax
    205c:      	movl	$0x8, %esi
    2061:      	callq	*%rax
    2063:      	movq	0x68(%rsp), %r12
    2068:      	testq	%r12, %r12
    206b:      	je	0x3315 <generic_fentry_process_event+0x2f65>
    2071:      	movq	%rbp, %r15
    2074:      	movq	%r12, 0x28(%rbp)
    2078:      	leaq	0x26(%rbp), %rdi
    207c:      	leaq	0x10(%r12), %rdx
    2081:      	movl	$0x2, %ecx
    2086:      	movl	$0x4, %eax
    208b:      	movl	$0x2, %esi
    2090:      	callq	*%rax
    2092:      	leaq	0x3a(%rbp), %rdi
    2096:      	leaq	0x12(%r12), %rdx
    209b:      	movl	$0x1, %ecx
    20a0:      	movl	$0x4, %eax
    20a5:      	movl	$0x1, %esi
    20aa:      	callq	*%rax
    20ac:      	leaq	0x38(%rbp), %rdi
    20b0:      	leaq	0x226(%r12), %rdx
    20b8:      	movl	$0x2, %ecx
    20bd:      	movl	$0x4, %eax
    20c2:      	movl	$0x2, %esi
    20c7:      	callq	*%rax
    20c9:      	leaq	0x24(%rbp), %rdi
    20cd:      	leaq	0x224(%r12), %rdx
    20d5:      	movl	$0x2, %ecx
    20da:      	movl	$0x4, %eax
    20df:      	movl	$0x2, %esi
    20e4:      	callq	*%rax
    20e6:      	leaq	0x30(%rbp), %rdi
    20ea:      	leaq	0x21c(%r12), %rdx
    20f2:      	movl	$0x4, %eax
    20f7:      	movl	$0x4, %esi
    20fc:      	callq	*%rax
    20fe:      	leaq	0x34(%rbp), %rdi
    2102:      	leaq	0x218(%r12), %rdx
    210a:      	movl	$0x4, %eax
    210f:      	movl	$0x4, %esi
    2114:      	callq	*%rax
    2116:      	leaq	0x10(%rbp), %r13
    211a:      	movq	$0x0, (%rbp)
    2122:      	movq	$0x0, 0x8(%rbp)
    212a:      	movq	$0x0, 0x10(%rbp)
    2132:      	movq	$0x0, 0x18(%rbp)
    213a:      	movzwl	0x26(%rbp), %eax
    213e:      	cmpl	$0xa, %eax
    2141:      	je	0x329d <generic_fentry_process_event+0x2eed>
    2147:      	cmpl	$0x2, %eax
    214a:      	jne	0x32cf <generic_fentry_process_event+0x2f1f>
    2150:      	leaq	0x4(%r12), %rdx
    2155:      	movl	$0x4, %ecx
    215a:      	movl	$0x4, %eax
    215f:      	movq	%rbp, %rdi
    2162:      	movl	$0x4, %esi
    2167:      	callq	*%rax
    2169:      	movl	$0x4, %ecx
    216e:      	movl	$0x4, %eax
    2173:      	movq	%r13, %rdi
    2176:      	movl	$0x4, %esi
    217b:      	movq	%r12, %rdx
    217e:      	jmp	0x32cd <generic_fentry_process_event+0x2f1d>
    2183:      	cmpl	$0x1a, %r13d
    2187:      	je	0x2db7 <generic_fentry_process_event+0x2a07>
    218d:      	movq	%r13, %rax
    2190:      	cmpl	$0x1b, %eax
    2193:      	movq	0x18(%rsp), %rbx
    2198:      	movq	0x28(%rsp), %r14
    219d:      	movl	$0x0, %r13d
    21a3:      	jne	0x1941 <generic_fentry_process_event+0x1591>
    21a9:      	movq	$0x0, 0x48(%rbp)
    21b1:      	movq	$0x0, 0x40(%rbp)
    21b9:      	movq	$0x0, 0x38(%rbp)
    21c1:      	movq	$0x0, 0x30(%rbp)
    21c9:      	movq	$0x0, 0x28(%rbp)
    21d1:      	movq	$0x0, 0x20(%rbp)
    21d9:      	movq	$0x0, 0x18(%rbp)
    21e1:      	movq	$0x0, 0x10(%rbp)
    21e9:      	movq	$0x0, 0x8(%rbp)
    21f1:      	movq	$0x0, (%rbp)
    21f9:      	leaq	0x10(%rbp), %rdi
    21fd:      	movq	0x10(%rsp), %rax
    2202:      	leaq	0x18(%rax), %rdx
    2206:      	movl	$0x3f, %ecx
    220b:      	movl	$0x2d, %eax
    2210:      	movl	$0x3f, %esi
    2215:      	callq	*%rax
    2217:      	testq	%rax, %rax
    221a:      	js	0x2e2b <generic_fentry_process_event+0x2a7b>
    2220:      	addq	$0x8, %rbp
    2224:      	movq	0x10(%rsp), %rdx
    2229:      	addq	$0x348, %rdx            # imm = 0x348
    2230:      	movl	$0x8, %ecx
    2235:      	movl	$0x4, %eax
    223a:      	movq	%rbp, %rdi
    223d:      	movl	$0x8, %esi
    2242:      	jmp	0x2b99 <generic_fentry_process_event+0x27e9>
    2247:      	cmpl	$0x8, %eax
    224a:      	je	0x29c0 <generic_fentry_process_event+0x2610>
    2250:      	cmpl	$0x12, %eax
    2253:      	movq	0x18(%rsp), %rbx
    2258:      	movq	0x28(%rsp), %r14
    225d:      	movl	$0x0, %r13d
    2263:      	jne	0x1941 <generic_fentry_process_event+0x1591>
    2269:      	movq	0x40(%rsp), %r13
    226e:      	andl	$0x3ff, %r13d           # imm = 0x3FF
    2275:      	movl	$0x4, %eax
    227a:      	movq	0x10(%rsp), %rdx
    227f:      	movq	%r15, %rdi
    2282:      	movl	%r13d, %esi
    2285:      	callq	*%rax
    2287:      	jmp	0x1941 <generic_fentry_process_event+0x1591>
    228c:      	cmpl	$0x13, %eax
    228f:      	je	0x2cc4 <generic_fentry_process_event+0x2914>
    2295:      	cmpl	$0x14, %eax
    2298:      	movq	0x18(%rsp), %rbx
    229d:      	movq	0x28(%rsp), %r14
    22a2:      	movl	$0x0, %r13d
    22a8:      	jne	0x1941 <generic_fentry_process_event+0x1591>
    22ae:      	movq	$0x0, 0x68(%rsp)
    22b7:      	movq	0x10(%rsp), %r13
    22bc:      	leaq	0x110(%r13), %rdx
    22c3:      	leaq	0x68(%rsp), %rdi
    22c8:      	movl	$0x8, %ecx
    22cd:      	movl	$0x4, %eax
    22d2:      	leaq	0xd8(%r13), %r12
    22d9:      	movl	$0x8, %esi
    22de:      	callq	*%rax
    22e0:      	movq	0x68(%rsp), %rcx
    22e5:      	movl	$0x80, %edx
    22ea:      	movl	$0x2d, %eax
    22ef:      	movq	0x68(%rsp), %rdx
    22f4:      	movq	%r15, %rdi
    22f7:      	movl	$0x80, %esi
    22fc:      	callq	*%rax
    22fe:      	leaq	0x90(%r15), %rdi
    2305:      	movl	$0x4, %ecx
    230a:      	movl	$0x4, %eax
    230f:      	movl	$0x4, %esi
    2314:      	movq	%r12, %rdx
    2317:      	callq	*%rax
    2319:      	leaq	0x80(%r15), %rdi
    2320:      	leaq	0xe0(%r13), %rdx
    2327:      	movl	$0x8, %ecx
    232c:      	movl	$0x4, %eax
    2331:      	movl	$0x8, %esi
    2336:      	callq	*%rax
    2338:      	addq	$0x88, %r15
    233f:      	addq	$0x118, %r13            # imm = 0x118
    2346:      	movl	$0x8, %ecx
    234b:      	movl	$0x4, %eax
    2350:      	movq	%r15, %rdi
    2353:      	movl	$0x8, %esi
    2358:      	movq	%r13, %rdx
    235b:      	callq	*%rax
    235d:      	movl	$0x98, %r13d
    2363:      	jmp	0x1941 <generic_fentry_process_event+0x1591>
    2368:      	movq	%r13, %rcx
    236b:      	cmpl	$0x26, %ecx
    236e:      	movq	0x38(%rsp), %rax
    2373:      	movq	0x20(%rsp), %rcx
    2378:      	movl	$0x4, %esi
    237d:      	movq	0x18(%rsp), %rbx
    2382:      	movq	%r15, %r14
    2385:      	movl	$0x0, %r13d
    238b:      	jne	0x1950 <generic_fentry_process_event+0x15a0>
    2391:      	movq	0x50(%rsp), %rsi
    2396:      	movzwl	%si, %edx
    2399:      	addq	%rbx, %rdx
    239c:      	shrl	$0x10, %esi
    239f:      	andl	$0xfff, %esi            # imm = 0xFFF
    23a5:      	leaq	0x4(%rbp), %rdi
    23a9:      	incl	%esi
    23ab:      	movl	$0x2d, %eax
    23b0:      	jmp	0x28ac <generic_fentry_process_event+0x24fc>
    23b5:      	movq	$0x0, 0x70(%rsp)
    23be:      	movl	$0xe, %eax
    23c3:      	callq	*%rax
    23c5:      	shrq	$0x20, %rax
    23c9:      	movq	%rax, 0x68(%rsp)
    23ce:      	leaq	0x58(%rsp), %rdi
    23d3:      	leaq	0x50(%rsp), %rdx
    23d8:      	movl	$0x4, %ecx
    23dd:      	movl	$0x4, %eax
    23e2:      	movl	$0x4, %esi
    23e7:      	callq	*%rax
    23e9:      	movl	0x58(%rsp), %eax
    23ed:      	movl	%eax, 0x70(%rsp)
    23f1:      	movq	(%rip), %rdi            # 0x23f8 <generic_fentry_process_event+0x2048>
    23f8:      	leaq	0x68(%rsp), %rsi
    23fd:      	movl	$0x1, %eax
    2402:      	callq	*%rax
    2404:      	testq	%rax, %rax
    2407:      	je	0x2e4f <generic_fentry_process_event+0x2a9f>
    240d:      	movq	%rax, %r13
    2410:      	movl	(%rax), %r15d
    2413:      	leaq	0x58(%rsp), %rdx
    2418:      	movl	$0x4, %eax
    241d:      	movq	%rbp, %r12
    2420:      	movl	$0x4, %ebp
    2425:      	movq	%r12, %rdi
    2428:      	movl	$0x4, %esi
    242d:      	callq	*%rax
    242f:      	andl	$0xfff, %r15d           # imm = 0xFFF
    2436:      	leaq	0x4(%r12), %rdi
    243b:      	leaq	0x4(%r15), %rsi
    243f:      	movl	$0x4, %eax
    2444:      	movq	%r13, %rdx
    2447:      	callq	*%rax
    2449:      	leaq	(%r12,%r15), %rdi
    244d:      	addq	$0x8, %rdi
    2451:      	leaq	(%r15,%r13), %rdx
    2455:      	addq	$0x4, %rdx
    2459:      	movl	$0x4, %eax
    245e:      	movl	$0x4, %esi
    2463:      	callq	*%rax
    2465:      	addq	$0xc, %r15
    2469:      	movq	%r15, %r13
    246c:      	jmp	0x1941 <generic_fentry_process_event+0x1591>
    2471:      	movq	0x50(%rsp), %r13
    2476:      	leaq	0xd0(%rsp), %rdi
    247e:      	movl	$0x1, %ecx
    2483:      	movl	$0x4, %eax
    2488:      	movl	$0x1, %esi
    248d:      	movq	%r13, %rdx
    2490:      	callq	*%rax
    2492:      	cmpb	$0x1, 0xd0(%rsp)
    249a:      	jne	0x2e33 <generic_fentry_process_event+0x2a83>
    24a0:      	addq	$0x10, %r13
    24a4:      	leaq	0x58(%rsp), %rdi
    24a9:      	movl	$0x8, %ebp
    24ae:      	movl	$0x8, %ecx
    24b3:      	movl	$0x4, %eax
    24b8:      	movl	$0x8, %esi
    24bd:      	movq	%r13, %rdx
    24c0:      	callq	*%rax
    24c2:      	movq	0x58(%rsp), %rdx
    24c7:      	leaq	0xb0(%rsp), %rdi
    24cf:      	movl	$0x8, %ecx
    24d4:      	movl	$0x4, %eax
    24d9:      	movl	$0x8, %esi
    24de:      	callq	*%rax
    24e0:      	movq	0x58(%rsp), %rdx
    24e5:      	addq	$0x8, %rdx
    24e9:      	leaq	0x30(%rsp), %rdi
    24ee:      	movl	$0x8, %ecx
    24f3:      	movl	$0x4, %eax
    24f8:      	movl	$0x8, %esi
    24fd:      	callq	*%rax
    24ff:      	movq	0xb0(%rsp), %rax
    2507:      	movq	%rax, 0xa8(%rsp)
    250f:      	movq	0x30(%rsp), %rax
    2514:      	movq	%rax, 0x10(%rsp)
    2519:      	movq	0x48(%rsp), %rax
    251e:      	addq	%r15, %rax
    2521:      	addq	$0x90, %rax
    2527:      	movq	%rax, 0x40(%rsp)
    252c:      	testb	$0x20, %r12b
    2530:      	je	0x320b <generic_fentry_process_event+0x2e5b>
    2536:      	cmpq	$0x1000, 0x10(%rsp)     # imm = 0x1000
    253f:      	jb	0x31e2 <generic_fentry_process_event+0x2e32>
    2545:      	movq	0x40(%rsp), %rax
    254a:      	movl	$0x1, (%rax)
    2550:      	movl	$0x0, 0xc0(%rsp)
    255b:      	movq	(%rip), %rdi            # 0x2562 <generic_fentry_process_event+0x21b2>
    2562:      	leaq	0xc0(%rsp), %rsi
    256a:      	movl	$0x1, %eax
    256f:      	callq	*%rax
    2571:      	movq	%rax, 0x48(%rsp)
    2576:      	testq	%rax, %rax
    2579:      	je	0x38cc <generic_fentry_process_event+0x351c>
    257f:      	movq	0x48(%rsp), %r12
    2584:      	movl	$0x18, (%r12)
    258c:      	movl	$0xe, %eax
    2591:      	callq	*%rax
    2593:      	leaq	0x10(%r12), %r15
    2598:      	movq	%rax, 0x10(%r12)
    259d:      	cmpq	$-0x16, %rax
    25a1:      	jne	0x25c5 <generic_fentry_process_event+0x2215>
    25a3:      	leaq	0x20(%rbx), %rdx
    25a7:      	leaq	0x68(%rsp), %rdi
    25ac:      	movl	$0x8, %ecx
    25b1:      	movl	$0x4, %eax
    25b6:      	movl	$0x8, %esi
    25bb:      	callq	*%rax
    25bd:      	movq	0x68(%rsp), %rax
    25c2:      	movq	%rax, (%r15)
    25c5:      	movl	$0x7d, %eax
    25ca:      	callq	*%rax
    25cc:      	movq	0x48(%rsp), %rsi
    25d1:      	movq	%rax, 0x18(%rsi)
    25d5:      	movq	(%r15), %rax
    25d8:      	movq	0x8(%r15), %rcx
    25dc:      	movq	0x40(%rsp), %rdx
    25e1:      	movq	%rax, 0x14(%rdx)
    25e5:      	movq	%rcx, 0x1c(%rdx)
    25e9:      	addq	$0x20, %rsi
    25ed:      	movq	%rsi, 0xe8(%rsp)
    25f5:      	movl	$0xa, %r15d
    25fb:      	xorl	%ebp, %ebp
    25fd:      	movq	0x10(%rsp), %r13
    2602:      	subq	%rbp, %r13
    2605:      	js	0x3b41 <generic_fentry_process_event+0x3791>
    260b:      	movq	0xa8(%rsp), %rax
    2613:      	leaq	(%rax,%rbp), %rdx
    2617:      	cmpq	$0x7fe0, %r13           # imm = 0x7FE0
    261e:      	movl	$0x7fe0, %eax           # imm = 0x7FE0
    2623:      	cmovaeq	%rax, %r13
    2627:      	movl	$0x4, %eax
    262c:      	movq	0xe8(%rsp), %rdi
    2634:      	movl	%r13d, %esi
    2637:      	callq	*%rax
    2639:      	testl	%eax, %eax
    263b:      	js	0x26ae <generic_fentry_process_event+0x22fe>
    263d:      	leal	0x20(%r13), %r12d
    2641:      	movq	0x48(%rsp), %rax
    2646:      	movl	%r12d, 0x4(%rax)
    264a:      	movl	$0x0, 0x68(%rsp)
    2652:      	movl	$0x1, %eax
    2657:      	movq	(%rip), %rdi            # 0x265e <generic_fentry_process_event+0x22ae>
    265e:      	leaq	0x68(%rsp), %rsi
    2663:      	callq	*%rax
    2665:      	testq	%rax, %rax
    2668:      	je	0x2690 <generic_fentry_process_event+0x22e0>
    266a:      	cmpb	$0x0, 0x28(%rax)
    266e:      	je	0x2690 <generic_fentry_process_event+0x22e0>
    2670:      	movl	$0x19, %eax
    2675:      	movq	%rbx, %rdi
    2678:      	movq	0x48(%rsp), %rcx
    267d:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    2682:      	movq	(%rip), %rsi            # 0x2689 <generic_fentry_process_event+0x22d9>
    2689:      	movq	%r12, %r8
    268c:      	callq	*%rax
    268e:      	jmp	0x26aa <generic_fentry_process_event+0x22fa>
    2690:      	movl	$0x82, %eax
    2695:      	movq	0x48(%rsp), %rsi
    269a:      	xorl	%ecx, %ecx
    269c:      	movq	(%rip), %rdi            # 0x26a3 <generic_fentry_process_event+0x22f3>
    26a3:      	movq	%r12, %rdx
    26a6:      	xorl	%ecx, %ecx
    26a8:      	callq	*%rax
    26aa:      	testl	%eax, %eax
    26ac:      	jns	0x26b1 <generic_fentry_process_event+0x2301>
    26ae:      	movslq	%eax, %r13
    26b1:      	testl	%r13d, %r13d
    26b4:      	js	0x3b4a <generic_fentry_process_event+0x379a>
    26ba:      	andl	$0x7fffffff, %r13d      # imm = 0x7FFFFFFF
    26c1:      	addq	%r13, %rbp
    26c4:      	cmpq	0x10(%rsp), %rbp
    26c9:      	je	0x3ba4 <generic_fentry_process_event+0x37f4>
    26cf:      	decl	%r15d
    26d2:      	jne	0x25fd <generic_fentry_process_event+0x224d>
    26d8:      	jmp	0x3efc <generic_fentry_process_event+0x3b4c>
    26dd:      	movq	0x50(%rsp), %r13
    26e2:      	movq	%rbp, %rbx
    26e5:      	leaq	0x28(%rbp), %rdi
    26e9:      	leaq	0x98(%r13), %rdx
    26f0:      	movl	$0x4, %ecx
    26f5:      	movl	$0x4, %eax
    26fa:      	movl	$0x4, %esi
    26ff:      	callq	*%rax
    2701:      	leaq	0x2c(%rbp), %rdi
    2705:      	leaq	0x70(%r13), %rdx
    2709:      	movl	$0x4, %ecx
    270e:      	movl	$0x4, %eax
    2713:      	movl	$0x4, %esi
    2718:      	callq	*%rax
    271a:      	leaq	0x30(%rbp), %rdi
    271e:      	leaq	0x90(%r13), %rdx
    2725:      	movl	$0x4, %ecx
    272a:      	movl	$0x4, %eax
    272f:      	movl	$0x4, %esi
    2734:      	callq	*%rax
    2736:      	leaq	0x34(%rbp), %rdi
    273a:      	leaq	0xa8(%r13), %rdx
    2741:      	movl	$0x4, %ecx
    2746:      	movl	$0x4, %eax
    274b:      	movl	$0x4, %esi
    2750:      	callq	*%rax
    2752:      	movq	$0x0, 0x68(%rsp)
    275b:      	leaq	0xc8(%r13), %rdx
    2762:      	leaq	0x68(%rsp), %rdi
    2767:      	movl	$0x8, %ecx
    276c:      	movl	$0x4, %eax
    2771:      	movl	$0x8, %esi
    2776:      	callq	*%rax
    2778:      	leaq	0xb8(%r13), %rdx
    277f:      	leaq	0x30(%rsp), %rdi
    2784:      	movl	$0x2, %ecx
    2789:      	movl	$0x4, %eax
    278e:      	movl	$0x2, %esi
    2793:      	callq	*%rax
    2795:      	movzwl	0x30(%rsp), %r12d
    279b:      	addq	0x68(%rsp), %r12
    27a0:      	leaq	0xdc(%rsp), %rdi
    27a8:      	movl	$0x1, %ecx
    27ad:      	movl	$0x4, %eax
    27b2:      	movl	$0x1, %esi
    27b7:      	movq	%r12, %rdx
    27ba:      	callq	*%rax
    27bc:      	movzbl	0xdc(%rsp), %eax
    27c4:      	shrl	$0x4, %eax
    27c7:      	cmpl	$0x6, %eax
    27ca:      	je	0x2e5b <generic_fentry_process_event+0x2aab>
    27d0:      	cmpl	$0x4, %eax
    27d3:      	jne	0x4429 <generic_fentry_process_event+0x4079>
    27d9:      	leaq	0x9(%r12), %rdx
    27de:      	leaq	0xd0(%rsp), %rdi
    27e6:      	movl	$0x1, %ecx
    27eb:      	movl	$0x4, %eax
    27f0:      	movl	$0x1, %esi
    27f5:      	callq	*%rax
    27f7:      	movzbl	0xd0(%rsp), %eax
    27ff:      	movq	%rbp, %rdi
    2802:      	movw	%ax, 0x24(%rbp)
    2806:      	movw	$0x2, 0x26(%rbp)
    280c:      	leaq	0xc(%r12), %rdx
    2811:      	movq	$0x0, (%rbp)
    2819:      	movq	$0x0, 0x8(%rbp)
    2821:      	movq	$0x0, 0x10(%rbp)
    2829:      	movq	$0x0, 0x18(%rbp)
    2831:      	movl	$0x4, %ecx
    2836:      	movl	$0x4, %eax
    283b:      	leaq	0x10(%rbp), %rbx
    283f:      	movl	$0x4, %esi
    2844:      	callq	*%rax
    2846:      	addq	$0x10, %r12
    284a:      	movl	$0x4, %ecx
    284f:      	movl	$0x4, %eax
    2854:      	movq	%rbx, %rdi
    2857:      	movl	$0x4, %esi
    285c:      	movq	%r12, %rdx
    285f:      	callq	*%rax
    2861:      	leaq	0xb6(%r13), %rdx
    2868:      	leaq	0xc0(%rsp), %rdi
    2870:      	movl	$0x2, %ecx
    2875:      	movl	$0x4, %eax
    287a:      	movl	$0x2, %esi
    287f:      	callq	*%rax
    2881:      	movzbl	0xd0(%rsp), %r15d
    288a:      	jmp	0x42da <generic_fentry_process_event+0x3f2a>
    288f:      	movl	$0x120, %edx            # imm = 0x120
    2894:      	addq	0x50(%rsp), %rdx
    2899:      	leaq	0x4(%rbp), %rdi
    289d:      	movl	$0x11, %ecx
    28a2:      	movl	$0x2d, %eax
    28a7:      	movl	$0x11, %esi
    28ac:      	callq	*%rax
    28ae:      	movq	%rax, %r13
    28b1:      	testq	%rax, %rax
    28b4:      	js	0x31c6 <generic_fentry_process_event+0x2e16>
    28ba:      	leal	-0x1(%r13), %eax
    28be:      	movl	%eax, (%rbp)
    28c1:      	addq	$0x3, %r13
    28c5:      	jmp	0x31c6 <generic_fentry_process_event+0x2e16>
    28ca:      	movq	0x50(%rsp), %r12
    28cf:      	movq	%rbp, %rdi
    28d2:      	movq	$0x0, 0x10(%rbp)
    28da:      	movq	$0x0, 0x8(%rbp)
    28e2:      	movq	$0x0, (%rbp)
    28ea:      	movl	$0x2, %ecx
    28ef:      	movl	$0x4, %eax
    28f4:      	movl	$0x2, %esi
    28f9:      	movq	%r12, %rdx
    28fc:      	callq	*%rax
    28fe:      	testq	%rax, %rax
    2901:      	js	0x30e5 <generic_fentry_process_event+0x2d35>
    2907:      	movzwl	(%rbp), %eax
    290b:      	cmpl	$0xa, %eax
    290e:      	je	0x30a2 <generic_fentry_process_event+0x2cf2>
    2914:      	cmpl	$0x2, %eax
    2917:      	jne	0x30db <generic_fentry_process_event+0x2d2b>
    291d:      	leaq	0x4(%r12), %rdx
    2922:      	leaq	0x68(%rsp), %rdi
    2927:      	movl	$0x4, %ecx
    292c:      	movl	$0x4, %eax
    2931:      	movl	$0x4, %esi
    2936:      	callq	*%rax
    2938:      	movl	0x68(%rsp), %eax
    293c:      	movq	%rax, 0x8(%rbp)
    2940:      	leaq	0x2(%rbp), %rdi
    2944:      	addq	$0x2, %r12
    2948:      	movl	$0x2, %ecx
    294d:      	movl	$0x4, %eax
    2952:      	jmp	0x30d1 <generic_fentry_process_event+0x2d21>
    2957:      	movq	0x48(%rsp), %rax
    295c:      	addq	%rbp, %rax
    295f:      	addq	$0x90, %rax
    2965:      	movq	%rax, 0xa8(%rsp)
    296d:      	movq	$0x0, 0x50(%rsp)
    2976:      	testb	$0x10, %r12b
    297a:      	jne	0x2fb6 <generic_fentry_process_event+0x2c06>
    2980:      	movl	%r12d, %r15d
    2983:      	movq	0x40(%rsp), %rdx
    2988:      	andl	$0xf, %edx
    298b:      	xorl	%eax, %eax
    298d:      	movq	%rdx, %rcx
    2990:      	cmpl	$0x2, %edx
    2993:      	jle	0x327f <generic_fentry_process_event+0x2ecf>
    2999:      	cmpl	$0x3, %ecx
    299c:      	je	0x38d7 <generic_fentry_process_event+0x3527>
    29a2:      	cmpl	$0x4, %ecx
    29a5:      	je	0x38e0 <generic_fentry_process_event+0x3530>
    29ab:      	cmpl	$0x5, %ecx
    29ae:      	jne	0x38f3 <generic_fentry_process_event+0x3543>
    29b4:      	leaq	0x5e70(%rbp), %rax
    29bb:      	jmp	0x38f0 <generic_fentry_process_event+0x3540>
    29c0:      	movq	%r15, %rbx
    29c3:      	leaq	0x28(%r15), %r13
    29c7:      	leaq	0x40(%r15), %r12
    29cb:      	movq	0x10(%rsp), %r15
    29d0:      	leaq	0x8(%r15), %rdx
    29d4:      	movl	$0x4, %ecx
    29d9:      	movl	$0x4, %eax
    29de:      	movq	%rbx, %rdi
    29e1:      	movl	$0x4, %esi
    29e6:      	callq	*%rax
    29e8:      	leaq	0x4(%rbx), %rdi
    29ec:      	leaq	0xc(%r15), %rdx
    29f0:      	movl	$0x4, %ecx
    29f5:      	movl	$0x4, %eax
    29fa:      	movl	$0x4, %esi
    29ff:      	callq	*%rax
    2a01:      	leaq	0x10(%rbx), %rdi
    2a05:      	leaq	0x18(%r15), %rdx
    2a09:      	movl	$0x4, %ecx
    2a0e:      	movl	$0x4, %eax
    2a13:      	movl	$0x4, %esi
    2a18:      	callq	*%rax
    2a1a:      	leaq	0x14(%rbx), %rdi
    2a1e:      	leaq	0x1c(%r15), %rdx
    2a22:      	movl	$0x4, %ecx
    2a27:      	movl	$0x4, %eax
    2a2c:      	movl	$0x4, %esi
    2a31:      	callq	*%rax
    2a33:      	leaq	0x8(%rbx), %rdi
    2a37:      	leaq	0x10(%r15), %rdx
    2a3b:      	movl	$0x4, %ecx
    2a40:      	movl	$0x4, %eax
    2a45:      	movl	$0x4, %esi
    2a4a:      	callq	*%rax
    2a4c:      	leaq	0xc(%rbx), %rdi
    2a50:      	leaq	0x14(%r15), %rdx
    2a54:      	movl	$0x4, %ecx
    2a59:      	movl	$0x4, %eax
    2a5e:      	movl	$0x4, %esi
    2a63:      	callq	*%rax
    2a65:      	leaq	0x18(%rbx), %rdi
    2a69:      	leaq	0x20(%r15), %rdx
    2a6d:      	movl	$0x4, %ecx
    2a72:      	movl	$0x4, %eax
    2a77:      	movl	$0x4, %esi
    2a7c:      	callq	*%rax
    2a7e:      	leaq	0x1c(%rbx), %rdi
    2a82:      	leaq	0x24(%r15), %rdx
    2a86:      	movl	$0x4, %ecx
    2a8b:      	movl	$0x4, %eax
    2a90:      	movl	$0x4, %esi
    2a95:      	callq	*%rax
    2a97:      	movl	$0x0, 0x24(%rbx)
    2a9e:      	leaq	0x20(%rbx), %rdi
    2aa2:      	leaq	0x28(%r15), %rdx
    2aa6:      	movl	$0x4, %ecx
    2aab:      	movl	$0x4, %eax
    2ab0:      	movl	$0x4, %esi
    2ab5:      	callq	*%rax
    2ab7:      	leaq	0x30(%rbx), %rdi
    2abb:      	leaq	0x40(%r15), %rdx
    2abf:      	movl	$0x8, %ecx
    2ac4:      	movl	$0x4, %eax
    2ac9:      	movl	$0x8, %esi
    2ace:      	callq	*%rax
    2ad0:      	leaq	0x38(%rbx), %rdi
    2ad4:      	leaq	0x30(%r15), %rdx
    2ad8:      	movl	$0x8, %ecx
    2add:      	movl	$0x4, %eax
    2ae2:      	movl	$0x8, %esi
    2ae7:      	callq	*%rax
    2ae9:      	leaq	0x38(%r15), %rdx
    2aed:      	movl	$0x8, %ecx
    2af2:      	movl	$0x4, %eax
    2af7:      	movq	%r13, %rdi
    2afa:      	movl	$0x8, %esi
    2aff:      	callq	*%rax
    2b01:      	addq	$0x90, %r15
    2b08:      	leaq	0x68(%rsp), %rdi
    2b0d:      	movl	$0x8, %ecx
    2b12:      	movl	$0x4, %eax
    2b17:      	movl	$0x8, %esi
    2b1c:      	movq	%r15, %rdx
    2b1f:      	callq	*%rax
    2b21:      	movq	0x68(%rsp), %r13
    2b26:      	leaq	0xc8(%r13), %rdx
    2b2d:      	movl	$0x4, %ecx
    2b32:      	movl	$0x4, %eax
    2b37:      	movq	%r12, %rdi
    2b3a:      	movl	$0x4, %esi
    2b3f:      	callq	*%rax
    2b41:      	leaq	0x44(%rbx), %rdi
    2b45:      	leaq	0xcc(%r13), %rdx
    2b4c:      	movl	$0x4, %ecx
    2b51:      	movl	$0x4, %eax
    2b56:      	movl	$0x4, %esi
    2b5b:      	callq	*%rax
    2b5d:      	leaq	0x48(%rbx), %rdi
    2b61:      	leaq	0xd0(%r13), %rdx
    2b68:      	movl	$0x4, %ecx
    2b6d:      	movl	$0x4, %eax
    2b72:      	movl	$0x4, %esi
    2b77:      	callq	*%rax
    2b79:      	addq	$0x4c, %rbx
    2b7d:      	addq	$0x158, %r13            # imm = 0x158
    2b84:      	movl	$0x4, %ecx
    2b89:      	movl	$0x4, %eax
    2b8e:      	movq	%rbx, %rdi
    2b91:      	movl	$0x4, %esi
    2b96:      	movq	%r13, %rdx
    2b99:      	callq	*%rax
    2b9b:      	movl	$0x50, %r13d
    2ba1:      	jmp	0x409a <generic_fentry_process_event+0x3cea>
    2ba6:      	movq	0x10(%rsp), %r12
    2bab:      	leaq	0xc8(%r12), %rdx
    2bb3:      	movl	$0x4, %ecx
    2bb8:      	movl	$0x4, %eax
    2bbd:      	movq	%r15, %rdi
    2bc0:      	movl	$0x4, %esi
    2bc5:      	callq	*%rax
    2bc7:      	leaq	0x4(%r15), %rdi
    2bcb:      	leaq	0xcc(%r12), %rdx
    2bd3:      	movl	$0x4, %ecx
    2bd8:      	movl	$0x4, %eax
    2bdd:      	movl	$0x4, %esi
    2be2:      	callq	*%rax
    2be4:      	leaq	0x8(%r15), %rdi
    2be8:      	leaq	0xd0(%r12), %rdx
    2bf0:      	movl	$0x4, %ecx
    2bf5:      	movl	$0x4, %eax
    2bfa:      	movl	$0x4, %esi
    2bff:      	callq	*%rax
    2c01:      	addq	$0xc, %r15
    2c05:      	addq	$0x158, %r12            # imm = 0x158
    2c0c:      	movl	$0x4, %ecx
    2c11:      	movl	$0x4, %eax
    2c16:      	movq	%r15, %rdi
    2c19:      	movl	$0x4, %esi
    2c1e:      	movq	%r12, %rdx
    2c21:      	callq	*%rax
    2c23:      	movl	$0x10, %r13d
    2c29:      	jmp	0x409a <generic_fentry_process_event+0x3cea>
    2c2e:      	movq	0x10(%rsp), %r12
    2c33:      	leaq	0x38(%r12), %rdx
    2c38:      	movl	$0x4, %ecx
    2c3d:      	movl	$0x4, %eax
    2c42:      	movq	%r15, %rdi
    2c45:      	movl	$0x4, %esi
    2c4a:      	callq	*%rax
    2c4c:      	leaq	0x4(%r15), %rdi
    2c50:      	leaq	0x3c(%r12), %rdx
    2c55:      	movl	$0x4, %ecx
    2c5a:      	movl	$0x4, %eax
    2c5f:      	movl	$0x4, %esi
    2c64:      	callq	*%rax
    2c66:      	leaq	0x8(%r15), %rdi
    2c6a:      	leaq	0x40(%r12), %rdx
    2c6f:      	movl	$0x4, %ecx
    2c74:      	movl	$0x4, %eax
    2c79:      	movl	$0x4, %esi
    2c7e:      	callq	*%rax
    2c80:      	leaq	0xc(%r15), %rdi
    2c84:      	leaq	0x44(%r12), %rdx
    2c89:      	movl	$0x4, %ecx
    2c8e:      	movl	$0x4, %eax
    2c93:      	movl	$0x4, %esi
    2c98:      	callq	*%rax
    2c9a:      	addq	$0x10, %r15
    2c9e:      	subq	$-0x80, %r12
    2ca2:      	movl	$0x10, %ecx
    2ca7:      	movl	$0x4, %eax
    2cac:      	movq	%r15, %rdi
    2caf:      	movl	$0x10, %esi
    2cb4:      	movq	%r12, %rdx
    2cb7:      	callq	*%rax
    2cb9:      	movl	$0x20, %r13d
    2cbf:      	jmp	0x409a <generic_fentry_process_event+0x3cea>
    2cc4:      	movl	$0x4, %ecx
    2cc9:      	movl	$0x4, %eax
    2cce:      	movq	%r15, %rbx
    2cd1:      	movq	0x10(%rsp), %r15
    2cd6:      	movq	%rbx, %rdi
    2cd9:      	movl	$0x4, %esi
    2cde:      	movq	%r15, %rdx
    2ce1:      	callq	*%rax
    2ce3:      	leaq	0x4(%rbx), %rdi
    2ce7:      	leaq	0x4(%r15), %rdx
    2ceb:      	movl	$0x4, %ecx
    2cf0:      	movl	$0x4, %eax
    2cf5:      	movl	$0x4, %esi
    2cfa:      	callq	*%rax
    2cfc:      	addq	$0x8, %rbx
    2d00:      	addq	$0x30, %r15
    2d04:      	movl	$0x10, %ecx
    2d09:      	movl	$0x4, %eax
    2d0e:      	movq	%rbx, %rdi
    2d11:      	movl	$0x10, %esi
    2d16:      	movq	%r15, %rdx
    2d19:      	jmp	0x2daa <generic_fentry_process_event+0x29fa>
    2d1e:      	movq	0x10(%rsp), %r15
    2d23:      	leaq	0x4(%r15), %rdx
    2d27:      	leaq	0x68(%rsp), %rdi
    2d2c:      	movl	$0x4, %ecx
    2d31:      	movl	$0x4, %eax
    2d36:      	movl	$0x4, %esi
    2d3b:      	callq	*%rax
    2d3d:      	movl	0x68(%rsp), %eax
    2d41:      	movl	%eax, (%rbp)
    2d44:      	leaq	0xc(%r15), %rdx
    2d48:      	leaq	0x68(%rsp), %rdi
    2d4d:      	movl	$0x4, %ecx
    2d52:      	movl	$0x4, %eax
    2d57:      	movl	$0x4, %esi
    2d5c:      	callq	*%rax
    2d5e:      	movl	0x68(%rsp), %eax
    2d62:      	movl	%eax, 0x4(%rbp)
    2d65:      	addq	$0x50, %r15
    2d69:      	leaq	0x68(%rsp), %rdi
    2d6e:      	movl	$0x8, %ecx
    2d73:      	movl	$0x2d, %eax
    2d78:      	movl	$0x8, %esi
    2d7d:      	movq	%r15, %rdx
    2d80:      	callq	*%rax
    2d82:      	addq	$0x8, %rbp
    2d86:      	movl	$0x3f8, %edx            # imm = 0x3F8
    2d8b:      	movq	0x68(%rsp), %rcx
    2d90:      	addq	%rdx, %rcx
    2d93:      	movl	$0x10, %esi
    2d98:      	movl	$0x2d, %eax
    2d9d:      	addq	0x68(%rsp), %rdx
    2da2:      	movq	%rbp, %rdi
    2da5:      	movl	$0x10, %esi
    2daa:      	callq	*%rax
    2dac:      	movl	$0x18, %r13d
    2db2:      	jmp	0x409a <generic_fentry_process_event+0x3cea>
    2db7:      	movq	$0x0, 0x48(%rbp)
    2dbf:      	movq	$0x0, 0x40(%rbp)
    2dc7:      	movq	$0x0, 0x38(%rbp)
    2dcf:      	movq	$0x0, 0x30(%rbp)
    2dd7:      	movq	$0x0, 0x28(%rbp)
    2ddf:      	movq	$0x0, 0x20(%rbp)
    2de7:      	movq	$0x0, 0x18(%rbp)
    2def:      	movq	$0x0, 0x10(%rbp)
    2df7:      	movq	$0x0, 0x8(%rbp)
    2dff:      	movq	$0x0, (%rbp)
    2e07:      	leaq	0x68(%rsp), %rdi
    2e0c:      	movl	$0x8, %ecx
    2e11:      	movl	$0x4, %eax
    2e16:      	movq	0x10(%rsp), %rdx
    2e1b:      	movl	$0x8, %esi
    2e20:      	callq	*%rax
    2e22:      	testq	%rax, %rax
    2e25:      	je	0x30f0 <generic_fentry_process_event+0x2d40>
    2e2b:      	xorl	%r13d, %r13d
    2e2e:      	jmp	0x409a <generic_fentry_process_event+0x3cea>
    2e33:      	movq	0x48(%rsp), %rax
    2e38:      	movq	$0x0, 0x90(%r15,%rax)
    2e44:      	movl	$0x8, %r13d
    2e4a:      	jmp	0x1941 <generic_fentry_process_event+0x1591>
    2e4f:      	movq	$-0x1, %r13
    2e56:      	jmp	0x1941 <generic_fentry_process_event+0x1591>
    2e5b:      	movq	0x68(%rsp), %r14
    2e60:      	movl	$0x0, 0x58(%rsp)
    2e68:      	movzwl	0x30(%rsp), %r15d
    2e6e:      	movq	(%rip), %rdi            # 0x2e75 <generic_fentry_process_event+0x2ac5>
    2e75:      	leaq	0x58(%rsp), %rsi
    2e7a:      	movl	$0x1, %eax
    2e7f:      	leaq	(%r14,%r15), %r12
    2e83:      	callq	*%rax
    2e85:      	testq	%rax, %rax
    2e88:      	je	0x4289 <generic_fentry_process_event+0x3ed9>
    2e8e:      	movq	%rax, %rbx
    2e91:      	movw	%r15w, (%rax)
    2e95:      	movb	$-0x1, 0x5(%rax)
    2e99:      	movb	$0x0, 0x7(%rax)
    2e9d:      	movq	%rax, %rdi
    2ea0:      	addq	$0x6, %rdi
    2ea4:      	leaq	0x6(%r12), %rdx
    2ea9:      	movl	$0x1, %ecx
    2eae:      	movl	$0x4, %eax
    2eb3:      	movq	%rdi, 0x10(%rsp)
    2eb8:      	movl	$0x1, %esi
    2ebd:      	callq	*%rax
    2ebf:      	testq	%rax, %rax
    2ec2:      	js	0x4289 <generic_fentry_process_event+0x3ed9>
    2ec8:      	movzbl	0x5(%rbx), %eax
    2ecc:      	cmpl	$0x32, %eax
    2ecf:      	jg	0x380a <generic_fentry_process_event+0x345a>
    2ed5:      	testl	%eax, %eax
    2ed7:      	je	0x38bc <generic_fentry_process_event+0x350c>
    2edd:      	cmpl	$0x2b, %eax
    2ee0:      	je	0x38bc <generic_fentry_process_event+0x350c>
    2ee6:      	cmpl	$0x2c, %eax
    2ee9:      	jne	0x3c7b <generic_fentry_process_event+0x38cb>
    2eef:      	movw	$0x8, 0x2(%rbx)
    2ef5:      	movw	$0x8, %ax
    2ef9:      	jmp	0x3bbd <generic_fentry_process_event+0x380d>
    2efe:      	leaq	0x48(%r12), %rdx
    2f03:      	movl	$0x10, %ecx
    2f08:      	movl	$0x4, %eax
    2f0d:      	movq	%rbp, %rdi
    2f10:      	movl	$0x10, %esi
    2f15:      	callq	*%rax
    2f17:      	leaq	0x38(%r12), %rdx
    2f1c:      	movl	$0x10, %ecx
    2f21:      	movl	$0x4, %eax
    2f26:      	movq	%r13, %rdi
    2f29:      	movl	$0x10, %esi
    2f2e:      	callq	*%rax
    2f30:      	leaq	0x20(%rbp), %rdi
    2f34:      	leaq	0xc(%r12), %r13
    2f39:      	addq	$0xe, %r12
    2f3d:      	movl	$0x2, %ecx
    2f42:      	movl	$0x4, %eax
    2f47:      	movl	$0x2, %esi
    2f4c:      	movq	%r12, %rdx
    2f4f:      	callq	*%rax
    2f51:      	leaq	0x22(%rbp), %rdi
    2f55:      	movl	$0x2, %ecx
    2f5a:      	movl	$0x4, %eax
    2f5f:      	movl	$0x2, %esi
    2f64:      	movq	%r13, %rdx
    2f67:      	callq	*%rax
    2f69:      	movzwl	0x22(%rbp), %eax
    2f6d:      	movbew	%ax, 0x22(%rbp)
    2f73:      	movq	0x50(%rsp), %rax
    2f78:      	movq	%rax, 0x68(%rsp)
    2f7d:      	movq	(%rip), %rdi            # 0x2f84 <generic_fentry_process_event+0x2bd4>
    2f84:      	leaq	0x68(%rsp), %rsi
    2f89:      	movl	$0x1, %eax
    2f8e:      	callq	*%rax
    2f90:      	testq	%rax, %rax
    2f93:      	je	0x4429 <generic_fentry_process_event+0x4079>
    2f99:      	movl	(%rax), %ecx
    2f9b:      	movq	%r15, %rbp
    2f9e:      	movl	%ecx, 0x10(%r15)
    2fa2:      	movq	0x8(%rax), %rcx
    2fa6:      	movq	%rcx, 0x18(%r15)
    2faa:      	movl	0x4(%rax), %eax
    2fad:      	movl	%eax, 0x7c(%r15)
    2fb1:      	jmp	0x4429 <generic_fentry_process_event+0x4079>
    2fb6:      	movl	$0xe, %eax
    2fbb:      	callq	*%rax
    2fbd:      	cmpq	$-0x16, %rax
    2fc1:      	jne	0x2fe7 <generic_fentry_process_event+0x2c37>
    2fc3:      	movq	0x18(%rsp), %rax
    2fc8:      	leaq	0x20(%rax), %rdx
    2fcc:      	leaq	0x68(%rsp), %rdi
    2fd1:      	movl	$0x8, %ecx
    2fd6:      	movl	$0x4, %eax
    2fdb:      	movl	$0x8, %esi
    2fe0:      	callq	*%rax
    2fe2:      	movq	0x68(%rsp), %rax
    2fe7:      	movq	0x8(%rbp), %rcx
    2feb:      	movq	0x60(%rbp), %rdx
    2fef:      	movq	%rcx, 0x68(%rsp)
    2ff4:      	movq	0x10(%rsp), %rcx
    2ff9:      	movq	%rcx, 0x70(%rsp)
    2ffe:      	movq	$0x0, 0x78(%rsp)
    3007:      	movq	%rdx, 0x58(%rsp)
    300c:      	movq	%rax, 0x60(%rsp)
    3011:      	movq	(%rip), %rdi            # 0x3018 <generic_fentry_process_event+0x2c68>
    3018:      	xorl	%ecx, %ecx
    301a:      	leaq	0x58(%rsp), %rsi
    301f:      	leaq	0x68(%rsp), %rdx
    3024:      	movl	$0x2, %eax
    3029:      	xorl	%ecx, %ecx
    302b:      	callq	*%rax
    302d:      	testq	%rax, %rax
    3030:      	je	0x3863 <generic_fentry_process_event+0x34b3>
    3036:      	negl	%eax
    3038:      	movw	%ax, 0xb0(%rsp)
    3040:      	movw	$0x5, 0xb2(%rsp)
    304a:      	movabsq	$0x200000046, %rax      # imm = 0x200000046
    3054:      	movq	%rax, 0xb4(%rsp)
    305c:      	movq	(%rip), %rdi            # 0x3063 <generic_fentry_process_event+0x2cb3>
    3063:      	leaq	0xb0(%rsp), %rsi
    306b:      	movl	$0x1, %eax
    3070:      	callq	*%rax
    3072:      	testq	%rax, %rax
    3075:      	je	0x3836 <generic_fentry_process_event+0x3486>
    307b:      	incl	(%rax)
    307d:      	jmp	0x3863 <generic_fentry_process_event+0x34b3>
    3082:      	cmpl	$0x1, %eax
    3085:      	je	0x336f <generic_fentry_process_event+0x2fbf>
    308b:      	cmpl	$0x2, %eax
    308e:      	jne	0x3711 <generic_fentry_process_event+0x3361>
    3094:      	movq	%rbp, %rax
    3097:      	addq	$0x5e58, %rax           # imm = 0x5E58
    309d:      	jmp	0x3378 <generic_fentry_process_event+0x2fc8>
    30a2:      	movq	%rbp, %rbx
    30a5:      	leaq	0x8(%rbp), %rdi
    30a9:      	leaq	0x8(%r12), %rdx
    30ae:      	movl	$0x10, %ecx
    30b3:      	movl	$0x4, %eax
    30b8:      	movl	$0x10, %esi
    30bd:      	callq	*%rax
    30bf:      	leaq	0x2(%rbp), %rdi
    30c3:      	addq	$0x2, %r12
    30c7:      	movl	$0x2, %ecx
    30cc:      	movl	$0x4, %eax
    30d1:      	movl	$0x2, %esi
    30d6:      	movq	%r12, %rdx
    30d9:      	callq	*%rax
    30db:      	movzwl	0x2(%rbp), %eax
    30df:      	movbew	%ax, 0x2(%rbp)
    30e5:      	movl	$0x18, %r13d
    30eb:      	jmp	0x31c6 <generic_fentry_process_event+0x2e16>
    30f0:      	leaq	0x10(%rbp), %rdi
    30f4:      	movq	0x68(%rsp), %rcx
    30f9:      	movl	$0x3f, %edx
    30fe:      	movl	$0x2d, %eax
    3103:      	movq	0x68(%rsp), %rdx
    3108:      	movl	$0x3f, %esi
    310d:      	callq	*%rax
    310f:      	testq	%rax, %rax
    3112:      	js	0x2e2b <generic_fentry_process_event+0x2a7b>
    3118:      	movq	0x10(%rsp), %rbx
    311d:      	leaq	0x8(%rbx), %rdx
    3121:      	leaq	0x58(%rsp), %rdi
    3126:      	movl	$0x8, %ecx
    312b:      	movl	$0x4, %eax
    3130:      	movl	$0x8, %esi
    3135:      	callq	*%rax
    3137:      	leaq	0x8(%rbp), %rdi
    313b:      	movl	$0x348, %edx            # imm = 0x348
    3140:      	movq	0x58(%rsp), %rcx
    3145:      	addq	%rdx, %rcx
    3148:      	movl	$0x8, %esi
    314d:      	movl	$0x4, %eax
    3152:      	addq	0x58(%rsp), %rdx
    3157:      	movl	$0x8, %esi
    315c:      	callq	*%rax
    315e:      	addq	$0x58, %rbx
    3162:      	leaq	0x58(%rsp), %rdi
    3167:      	movl	$0x4, %ecx
    316c:      	movl	$0x4, %eax
    3171:      	movl	$0x4, %esi
    3176:      	movq	%rbx, %rdx
    3179:      	callq	*%rax
    317b:      	movl	$0x50, %r13d
    3181:      	testq	%rax, %rax
    3184:      	jne	0x409a <generic_fentry_process_event+0x3cea>
    318a:      	xorl	%eax, %eax
    318c:      	cmpl	$0x0, 0x58(%rsp)
    3191:      	setne	%al
    3194:      	movl	%eax, (%rbp)
    3197:      	jmp	0x409a <generic_fentry_process_event+0x3cea>
    319c:      	addq	$0x3, %r12
    31a0:      	movl	$0x6b, %ecx
    31a5:      	movl	$0x71, %eax
    31aa:      	movl	$0x6b, %esi
    31af:      	movq	%r12, %rdx
    31b2:      	callq	*%rax
    31b4:      	movq	%rax, %rcx
    31b7:      	movb	$0x6b, %al
    31b9:      	testl	%ecx, %ecx
    31bb:      	js	0x31c0 <generic_fentry_process_event+0x2e10>
    31bd:      	movb	%al, 0x3(%rbp)
    31c0:      	movl	$0x70, %r13d
    31c6:      	movq	0x38(%rsp), %rax
    31cb:      	movq	0x20(%rsp), %rcx
    31d0:      	movl	$0x4, %esi
    31d5:      	movq	0x18(%rsp), %rbx
    31da:      	movq	%r15, %r14
    31dd:      	jmp	0x1950 <generic_fentry_process_event+0x15a0>
    31e2:      	addq	$0x90, %r15
    31e9:      	movq	0xc8(%rsp), %rax
    31f1:      	movl	$0x0, 0x4(%r15,%rax)
    31fa:      	addq	%r15, %rax
    31fd:      	addq	$0x8, %rax
    3201:      	movq	%rax, 0x40(%rsp)
    3206:      	movl	$0xc, %ebp
    320b:      	movq	0x10(%rsp), %rax
    3210:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    3216:      	movl	$0xfff, %r13d           # imm = 0xFFF
    321c:      	cmovbq	%rax, %r13
    3220:      	movq	0x40(%rsp), %rax
    3225:      	leaq	0x8(%rax), %rdi
    3229:      	movl	$0x4, %eax
    322e:      	movq	0xa8(%rsp), %rdx
    3236:      	movl	%r13d, %esi
    3239:      	callq	*%rax
    323b:      	testl	%eax, %eax
    323d:      	js	0x325a <generic_fentry_process_event+0x2eaa>
    323f:      	movq	0x40(%rsp), %rax
    3244:      	movq	0x10(%rsp), %rcx
    3249:      	movl	%ecx, (%rax)
    324b:      	movl	%r13d, 0x4(%rax)
    324f:      	addq	%r13, %rbp
    3252:      	movq	%rbp, %r13
    3255:      	jmp	0x1941 <generic_fentry_process_event+0x1591>
    325a:      	movq	0x40(%rsp), %rax
    325f:      	movl	$0xfffffffe, (%rax)     # imm = 0xFFFFFFFE
    3265:      	movq	0x38(%rsp), %rax
    326a:      	movq	0x20(%rsp), %rcx
    326f:      	movl	$0x4, %esi
    3274:      	movl	$0x4, %r13d
    327a:      	jmp	0x1950 <generic_fentry_process_event+0x15a0>
    327f:      	cmpl	$0x1, %ecx
    3282:      	je	0x38e9 <generic_fentry_process_event+0x3539>
    3288:      	cmpl	$0x2, %ecx
    328b:      	jne	0x38f3 <generic_fentry_process_event+0x3543>
    3291:      	leaq	0x5e58(%rbp), %rax
    3298:      	jmp	0x38f0 <generic_fentry_process_event+0x3540>
    329d:      	leaq	0x48(%r12), %rdx
    32a2:      	movl	$0x10, %ecx
    32a7:      	movl	$0x4, %eax
    32ac:      	movq	%rbp, %rdi
    32af:      	movl	$0x10, %esi
    32b4:      	callq	*%rax
    32b6:      	leaq	0x38(%r12), %rdx
    32bb:      	movl	$0x10, %ecx
    32c0:      	movl	$0x4, %eax
    32c5:      	movq	%r13, %rdi
    32c8:      	movl	$0x10, %esi
    32cd:      	callq	*%rax
    32cf:      	movq	%rbp, %rbx
    32d2:      	leaq	0x20(%rbp), %rdi
    32d6:      	leaq	0xc(%r12), %r13
    32db:      	addq	$0xe, %r12
    32df:      	movl	$0x2, %ecx
    32e4:      	movl	$0x4, %eax
    32e9:      	movl	$0x2, %esi
    32ee:      	movq	%r12, %rdx
    32f1:      	callq	*%rax
    32f3:      	leaq	0x22(%rbp), %rdi
    32f7:      	movl	$0x2, %ecx
    32fc:      	movl	$0x4, %eax
    3301:      	movl	$0x2, %esi
    3306:      	movq	%r13, %rdx
    3309:      	callq	*%rax
    330b:      	movzwl	0x22(%rbp), %eax
    330f:      	movbew	%ax, 0x22(%rbp)
    3315:      	movq	0x28(%rbp), %rax
    3319:      	movq	%rax, 0x68(%rsp)
    331e:      	movq	(%rip), %rdi            # 0x3325 <generic_fentry_process_event+0x2f75>
    3325:      	leaq	0x68(%rsp), %rsi
    332a:      	movl	$0x1, %eax
    332f:      	callq	*%rax
    3331:      	testq	%rax, %rax
    3334:      	je	0x334e <generic_fentry_process_event+0x2f9e>
    3336:      	movl	(%rax), %ecx
    3338:      	movq	0x40(%rsp), %rdx
    333d:      	movl	%ecx, 0x10(%rdx)
    3340:      	movq	0x8(%rax), %rcx
    3344:      	movq	%rcx, 0x18(%rdx)
    3348:      	movl	0x4(%rax), %eax
    334b:      	movl	%eax, 0x7c(%rdx)
    334e:      	movl	$0x40, %r13d
    3354:      	jmp	0x409a <generic_fentry_process_event+0x3cea>
    3359:      	movq	%rbp, %rax
    335c:      	addq	$0x5e60, %rax           # imm = 0x5E60
    3362:      	jmp	0x3378 <generic_fentry_process_event+0x2fc8>
    3364:      	movq	%rbp, %rax
    3367:      	addq	$0x5e68, %rax           # imm = 0x5E68
    336d:      	jmp	0x3378 <generic_fentry_process_event+0x2fc8>
    336f:      	movq	%rbp, %rax
    3372:      	addq	$0x5e50, %rax           # imm = 0x5E50
    3378:      	movq	(%rax), %rbx
    337b:      	testb	$0x10, 0x40(%rsp)
    3380:      	jne	0x3724 <generic_fentry_process_event+0x3374>
    3386:      	testq	%rbx, %rbx
    3389:      	je	0x37ec <generic_fentry_process_event+0x343c>
    338f:      	leaq	0x68(%rsp), %rdi
    3394:      	movl	$0x10, %ecx
    3399:      	movl	$0x4, %eax
    339e:      	movq	0x10(%rsp), %rdx
    33a3:      	movl	$0x10, %esi
    33a8:      	callq	*%rax
    33aa:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    33af:      	testl	%eax, %eax
    33b1:      	js	0x36f2 <generic_fentry_process_event+0x3342>
    33b7:      	movq	0x70(%rsp), %r14
    33bc:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    33c1:      	cmpq	$0xffe, %r14            # imm = 0xFFE
    33c8:      	ja	0x36f2 <generic_fentry_process_event+0x3342>
    33ce:      	movq	0xc8(%rsp), %rax
    33d6:      	leaq	0xc(%rax), %r15
    33da:      	leaq	(%r15,%r13), %rdi
    33de:      	movq	0x68(%rsp), %rcx
    33e3:      	movl	$0x4, %eax
    33e8:      	movq	0x68(%rsp), %rdx
    33ed:      	movl	%r14d, %esi
    33f0:      	callq	*%rax
    33f2:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    33f7:      	testl	%eax, %eax
    33f9:      	js	0x36f2 <generic_fentry_process_event+0x3342>
    33ff:      	cmpq	$0x1, %rbx
    3403:      	je	0x37ef <generic_fentry_process_event+0x343f>
    3409:      	movq	0x10(%rsp), %rax
    340e:      	leaq	0x10(%rax), %rdx
    3412:      	leaq	0x68(%rsp), %rdi
    3417:      	movl	$0x10, %ecx
    341c:      	movl	$0x4, %eax
    3421:      	movl	$0x10, %esi
    3426:      	callq	*%rax
    3428:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    342d:      	testl	%eax, %eax
    342f:      	js	0x36f2 <generic_fentry_process_event+0x3342>
    3435:      	movq	0x70(%rsp), %r12
    343a:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    343f:      	cmpq	$0xffe, %r12            # imm = 0xFFE
    3446:      	ja	0x36f2 <generic_fentry_process_event+0x3342>
    344c:      	addq	%r14, %r15
    344f:      	leaq	(%r15,%r13), %rdi
    3453:      	movq	0x68(%rsp), %rcx
    3458:      	movl	$0x4, %eax
    345d:      	movq	0x68(%rsp), %rdx
    3462:      	movl	%r12d, %esi
    3465:      	callq	*%rax
    3467:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    346c:      	testl	%eax, %eax
    346e:      	js	0x36f2 <generic_fentry_process_event+0x3342>
    3474:      	addq	%r12, %r14
    3477:      	cmpq	$0x3, %rbx
    347b:      	jb	0x37ef <generic_fentry_process_event+0x343f>
    3481:      	movq	0x10(%rsp), %rax
    3486:      	leaq	0x20(%rax), %rdx
    348a:      	leaq	0x68(%rsp), %rdi
    348f:      	movl	$0x10, %ecx
    3494:      	movl	$0x4, %eax
    3499:      	movl	$0x10, %esi
    349e:      	callq	*%rax
    34a0:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    34a5:      	testl	%eax, %eax
    34a7:      	js	0x36f2 <generic_fentry_process_event+0x3342>
    34ad:      	movq	0x70(%rsp), %rbp
    34b2:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    34b7:      	cmpq	$0xffe, %rbp            # imm = 0xFFE
    34be:      	ja	0x36f2 <generic_fentry_process_event+0x3342>
    34c4:      	addq	%r15, %r12
    34c7:      	movl	%r12d, %edi
    34ca:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    34d0:      	addq	%r13, %rdi
    34d3:      	movq	0x68(%rsp), %rcx
    34d8:      	movl	$0x4, %eax
    34dd:      	movq	0x68(%rsp), %rdx
    34e2:      	movl	%ebp, %esi
    34e4:      	callq	*%rax
    34e6:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    34eb:      	testl	%eax, %eax
    34ed:      	js	0x36f2 <generic_fentry_process_event+0x3342>
    34f3:      	addq	%rbp, %r14
    34f6:      	cmpq	$0x3, %rbx
    34fa:      	je	0x37ef <generic_fentry_process_event+0x343f>
    3500:      	movq	0x10(%rsp), %rax
    3505:      	leaq	0x30(%rax), %rdx
    3509:      	leaq	0x68(%rsp), %rdi
    350e:      	movl	$0x10, %ecx
    3513:      	movl	$0x4, %eax
    3518:      	movl	$0x10, %esi
    351d:      	callq	*%rax
    351f:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3524:      	testl	%eax, %eax
    3526:      	js	0x36f2 <generic_fentry_process_event+0x3342>
    352c:      	movq	0x70(%rsp), %rax
    3531:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    3536:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    353c:      	ja	0x36f2 <generic_fentry_process_event+0x3342>
    3542:      	movq	%rax, %r15
    3545:      	addq	%r12, %rbp
    3548:      	movl	%ebp, %edi
    354a:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    3550:      	addq	%r13, %rdi
    3553:      	movq	0x68(%rsp), %rcx
    3558:      	movl	$0x4, %eax
    355d:      	movq	%r15, %rsi
    3560:      	movq	0x68(%rsp), %rdx
    3565:      	callq	*%rax
    3567:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    356c:      	testl	%eax, %eax
    356e:      	js	0x36f2 <generic_fentry_process_event+0x3342>
    3574:      	addq	%r15, %r14
    3577:      	cmpq	$0x5, %rbx
    357b:      	jb	0x37ef <generic_fentry_process_event+0x343f>
    3581:      	movq	0x10(%rsp), %rax
    3586:      	leaq	0x40(%rax), %rdx
    358a:      	leaq	0x68(%rsp), %rdi
    358f:      	movl	$0x10, %ecx
    3594:      	movl	$0x4, %eax
    3599:      	movl	$0x10, %esi
    359e:      	callq	*%rax
    35a0:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    35a5:      	testl	%eax, %eax
    35a7:      	js	0x36f2 <generic_fentry_process_event+0x3342>
    35ad:      	movq	0x70(%rsp), %rax
    35b2:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    35b7:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    35bd:      	ja	0x36f2 <generic_fentry_process_event+0x3342>
    35c3:      	movq	%rax, %r12
    35c6:      	movq	%r15, %rdi
    35c9:      	addq	%rbp, %rdi
    35cc:      	movq	%rdi, %r15
    35cf:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    35d5:      	addq	%r13, %rdi
    35d8:      	movq	0x68(%rsp), %rcx
    35dd:      	movl	$0x4, %eax
    35e2:      	movq	%r12, %rsi
    35e5:      	movq	0x68(%rsp), %rdx
    35ea:      	callq	*%rax
    35ec:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    35f1:      	testl	%eax, %eax
    35f3:      	js	0x36f2 <generic_fentry_process_event+0x3342>
    35f9:      	addq	%r12, %r14
    35fc:      	cmpq	$0x5, %rbx
    3600:      	je	0x37ef <generic_fentry_process_event+0x343f>
    3606:      	movq	0x10(%rsp), %rax
    360b:      	leaq	0x50(%rax), %rdx
    360f:      	leaq	0x68(%rsp), %rdi
    3614:      	movl	$0x10, %ecx
    3619:      	movl	$0x4, %eax
    361e:      	movl	$0x10, %esi
    3623:      	callq	*%rax
    3625:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    362a:      	testl	%eax, %eax
    362c:      	js	0x36f2 <generic_fentry_process_event+0x3342>
    3632:      	movq	0x70(%rsp), %rbp
    3637:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    363c:      	cmpq	$0xffe, %rbp            # imm = 0xFFE
    3643:      	ja	0x36f2 <generic_fentry_process_event+0x3342>
    3649:      	addq	%r15, %r12
    364c:      	movq	%r12, %r15
    364f:      	movl	%r12d, %edi
    3652:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    3658:      	addq	%r13, %rdi
    365b:      	movq	0x68(%rsp), %rcx
    3660:      	movl	$0x4, %eax
    3665:      	movq	0x68(%rsp), %rdx
    366a:      	movl	%ebp, %esi
    366c:      	callq	*%rax
    366e:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3673:      	testl	%eax, %eax
    3675:      	js	0x36f2 <generic_fentry_process_event+0x3342>
    3677:      	addq	%rbp, %r14
    367a:      	cmpq	$0x7, %rbx
    367e:      	jb	0x37ef <generic_fentry_process_event+0x343f>
    3684:      	movq	0x10(%rsp), %rdx
    3689:      	addq	$0x60, %rdx
    368d:      	leaq	0x68(%rsp), %rdi
    3692:      	movl	$0x10, %ecx
    3697:      	movl	$0x4, %eax
    369c:      	movl	$0x10, %esi
    36a1:      	callq	*%rax
    36a3:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    36a8:      	testl	%eax, %eax
    36aa:      	js	0x36f2 <generic_fentry_process_event+0x3342>
    36ac:      	movq	0x70(%rsp), %rbx
    36b1:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    36b6:      	cmpq	$0xffe, %rbx            # imm = 0xFFE
    36bd:      	ja	0x36f2 <generic_fentry_process_event+0x3342>
    36bf:      	addq	%r15, %rbp
    36c2:      	andl	$0x3fff, %ebp           # imm = 0x3FFF
    36c8:      	addq	%r13, %rbp
    36cb:      	movq	0x68(%rsp), %rcx
    36d0:      	movl	$0x4, %eax
    36d5:      	movq	0x68(%rsp), %rdx
    36da:      	movq	%rbp, %rdi
    36dd:      	movl	%ebx, %esi
    36df:      	callq	*%rax
    36e1:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    36e6:      	testl	%eax, %eax
    36e8:      	js	0x36f2 <generic_fentry_process_event+0x3342>
    36ea:      	addq	%rbx, %r14
    36ed:      	jmp	0x37ef <generic_fentry_process_event+0x343f>
    36f2:      	movq	0x48(%rsp), %rax
    36f7:      	movl	%ecx, (%r13,%rax)
    36fc:      	movq	0x18(%rsp), %rbx
    3701:      	movq	0x28(%rsp), %r14
    3706:      	movl	$0x4, %r13d
    370c:      	jmp	0x1941 <generic_fentry_process_event+0x1591>
    3711:      	xorl	%ebx, %ebx
    3713:      	movl	$0x0, %r14d
    3719:      	testb	$0x10, 0x40(%rsp)
    371e:      	je	0x37ef <generic_fentry_process_event+0x343f>
    3724:      	movl	$0xe, %eax
    3729:      	callq	*%rax
    372b:      	cmpq	$-0x16, %rax
    372f:      	jne	0x3755 <generic_fentry_process_event+0x33a5>
    3731:      	movq	0x18(%rsp), %rax
    3736:      	leaq	0x20(%rax), %rdx
    373a:      	leaq	0x68(%rsp), %rdi
    373f:      	movl	$0x8, %ecx
    3744:      	movl	$0x4, %eax
    3749:      	movl	$0x8, %esi
    374e:      	callq	*%rax
    3750:      	movq	0x68(%rsp), %rax
    3755:      	movq	0x8(%rbp), %rcx
    3759:      	movq	0x60(%rbp), %rdx
    375d:      	movq	%rcx, 0x68(%rsp)
    3762:      	movq	0x10(%rsp), %rcx
    3767:      	movq	%rcx, 0x70(%rsp)
    376c:      	movq	%rbx, 0x78(%rsp)
    3771:      	movq	%rdx, 0x58(%rsp)
    3776:      	movq	%rax, 0x60(%rsp)
    377b:      	movq	(%rip), %rdi            # 0x3782 <generic_fentry_process_event+0x33d2>
    3782:      	xorl	%ecx, %ecx
    3784:      	leaq	0x58(%rsp), %rsi
    3789:      	leaq	0x68(%rsp), %rdx
    378e:      	movl	$0x2, %eax
    3793:      	xorl	%ecx, %ecx
    3795:      	callq	*%rax
    3797:      	testq	%rax, %rax
    379a:      	je	0x38a3 <generic_fentry_process_event+0x34f3>
    37a0:      	negl	%eax
    37a2:      	movw	%ax, 0xb0(%rsp)
    37aa:      	movw	$0x5, 0xb2(%rsp)
    37b4:      	movabsq	$0x200000057, %rax      # imm = 0x200000057
    37be:      	movq	%rax, 0xb4(%rsp)
    37c6:      	movq	(%rip), %rdi            # 0x37cd <generic_fentry_process_event+0x341d>
    37cd:      	leaq	0xb0(%rsp), %rsi
    37d5:      	movl	$0x1, %eax
    37da:      	callq	*%rax
    37dc:      	testq	%rax, %rax
    37df:      	je	0x387c <generic_fentry_process_event+0x34cc>
    37e5:      	incl	(%rax)
    37e7:      	jmp	0x38a3 <generic_fentry_process_event+0x34f3>
    37ec:      	xorl	%r14d, %r14d
    37ef:      	movq	0x48(%rsp), %rax
    37f4:      	movl	%r14d, (%r13,%rax)
    37f9:      	movl	%r14d, 0x4(%r13,%rax)
    37fe:      	addq	$0x8, %r14
    3802:      	movq	%r14, %r13
    3805:      	jmp	0x409a <generic_fentry_process_event+0x3cea>
    380a:      	cmpl	$0x33, %eax
    380d:      	je	0x3bae <generic_fentry_process_event+0x37fe>
    3813:      	cmpl	$0x3c, %eax
    3816:      	je	0x38bc <generic_fentry_process_event+0x350c>
    381c:      	cmpl	$0xff, %eax
    3821:      	jne	0x3c7b <generic_fentry_process_event+0x38cb>
    3827:      	movw	$0x28, 0x2(%rbx)
    382d:      	movw	$0x28, %ax
    3831:      	jmp	0x3bbd <generic_fentry_process_event+0x380d>
    3836:      	movl	$0x1, 0xc0(%rsp)
    3841:      	movq	(%rip), %rdi            # 0x3848 <generic_fentry_process_event+0x3498>
    3848:      	xorl	%ecx, %ecx
    384a:      	leaq	0xb0(%rsp), %rsi
    3852:      	leaq	0xc0(%rsp), %rdx
    385a:      	movl	$0x2, %eax
    385f:      	xorl	%ecx, %ecx
    3861:      	callq	*%rax
    3863:      	movq	0xa8(%rsp), %rax
    386b:      	movl	$0xfffffffc, (%rax)     # imm = 0xFFFFFFFC
    3871:      	movl	$0x4, %r13d
    3877:      	jmp	0x409a <generic_fentry_process_event+0x3cea>
    387c:      	movl	$0x1, 0x30(%rsp)
    3884:      	movq	(%rip), %rdi            # 0x388b <generic_fentry_process_event+0x34db>
    388b:      	xorl	%ecx, %ecx
    388d:      	leaq	0xb0(%rsp), %rsi
    3895:      	leaq	0x30(%rsp), %rdx
    389a:      	movl	$0x2, %eax
    389f:      	xorl	%ecx, %ecx
    38a1:      	callq	*%rax
    38a3:      	movq	0x48(%rsp), %rax
    38a8:      	movl	$0xfffffffc, (%r13,%rax) # imm = 0xFFFFFFFC
    38b1:      	movl	$0x4, %r13d
    38b7:      	jmp	0x409a <generic_fentry_process_event+0x3cea>
    38bc:      	movzbl	0x7(%rbx), %eax
    38c0:      	leal	0x8(,%rax,8), %eax
    38c7:      	jmp	0x3bb9 <generic_fentry_process_event+0x3809>
    38cc:      	movl	$0x4, %r13d
    38d2:      	jmp	0x1941 <generic_fentry_process_event+0x1591>
    38d7:      	leaq	0x5e60(%rbp), %rax
    38de:      	jmp	0x38f0 <generic_fentry_process_event+0x3540>
    38e0:      	leaq	0x5e68(%rbp), %rax
    38e7:      	jmp	0x38f0 <generic_fentry_process_event+0x3540>
    38e9:      	leaq	0x5e50(%rbp), %rax
    38f0:      	movq	(%rax), %rax
    38f3:      	movq	%rax, 0x30(%rsp)
    38f8:      	leaq	0x50(%rsp), %rdi
    38fd:      	leaq	0x30(%rsp), %rdx
    3902:      	movl	$0x8, %ecx
    3907:      	movl	$0x4, %eax
    390c:      	movl	$0x8, %ebx
    3911:      	movl	$0x8, %esi
    3916:      	callq	*%rax
    3918:      	movq	0x50(%rsp), %r14
    391d:      	testb	$0x20, %r15b
    3921:      	je	0x3ade <generic_fentry_process_event+0x372e>
    3927:      	cmpq	$0x1000, %r14           # imm = 0x1000
    392e:      	jb	0x3ab3 <generic_fentry_process_event+0x3703>
    3934:      	movq	0xa8(%rsp), %rax
    393c:      	movl	$0x1, (%rax)
    3942:      	movl	$0x0, 0x58(%rsp)
    394a:      	movq	(%rip), %rdi            # 0x3951 <generic_fentry_process_event+0x35a1>
    3951:      	leaq	0x58(%rsp), %rsi
    3956:      	movl	$0x1, %eax
    395b:      	callq	*%rax
    395d:      	testq	%rax, %rax
    3960:      	je	0x3b36 <generic_fentry_process_event+0x3786>
    3966:      	movq	%rax, %rbx
    3969:      	movl	$0x18, (%rax)
    396f:      	movl	$0xe, %eax
    3974:      	callq	*%rax
    3976:      	leaq	0x10(%rbx), %r15
    397a:      	movq	%rax, 0x10(%rbx)
    397e:      	cmpq	$-0x16, %rax
    3982:      	jne	0x39ab <generic_fentry_process_event+0x35fb>
    3984:      	movq	0x18(%rsp), %rax
    3989:      	leaq	0x20(%rax), %rdx
    398d:      	leaq	0x68(%rsp), %rdi
    3992:      	movl	$0x8, %ecx
    3997:      	movl	$0x4, %eax
    399c:      	movl	$0x8, %esi
    39a1:      	callq	*%rax
    39a3:      	movq	0x68(%rsp), %rax
    39a8:      	movq	%rax, (%r15)
    39ab:      	movl	$0x7d, %eax
    39b0:      	callq	*%rax
    39b2:      	movq	%rax, 0x18(%rbx)
    39b6:      	movq	(%r15), %rax
    39b9:      	movq	0x8(%r15), %rcx
    39bd:      	movq	0xa8(%rsp), %rdx
    39c5:      	movq	%rax, 0x14(%rdx)
    39c9:      	movq	%rcx, 0x1c(%rdx)
    39cd:      	movq	%rbx, %rax
    39d0:      	addq	$0x20, %rax
    39d4:      	movq	%rax, 0x40(%rsp)
    39d9:      	movl	$0xa, %r15d
    39df:      	xorl	%r13d, %r13d
    39e2:      	movq	%r14, %rbp
    39e5:      	subq	%r13, %rbp
    39e8:      	js	0x3cad <generic_fentry_process_event+0x38fd>
    39ee:      	movq	0x10(%rsp), %rax
    39f3:      	leaq	(%rax,%r13), %rdx
    39f7:      	cmpq	$0x7fe0, %rbp           # imm = 0x7FE0
    39fe:      	movl	$0x7fe0, %eax           # imm = 0x7FE0
    3a03:      	cmovaeq	%rax, %rbp
    3a07:      	movl	$0x4, %eax
    3a0c:      	movq	0x40(%rsp), %rdi
    3a11:      	movl	%ebp, %esi
    3a13:      	callq	*%rax
    3a15:      	testl	%eax, %eax
    3a17:      	js	0x3a88 <generic_fentry_process_event+0x36d8>
    3a19:      	leal	0x20(%rbp), %r12d
    3a1d:      	movl	%r12d, 0x4(%rbx)
    3a21:      	movl	$0x0, 0x68(%rsp)
    3a29:      	movl	$0x1, %eax
    3a2e:      	movq	(%rip), %rdi            # 0x3a35 <generic_fentry_process_event+0x3685>
    3a35:      	leaq	0x68(%rsp), %rsi
    3a3a:      	callq	*%rax
    3a3c:      	testq	%rax, %rax
    3a3f:      	je	0x3a6c <generic_fentry_process_event+0x36bc>
    3a41:      	cmpb	$0x0, 0x28(%rax)
    3a45:      	je	0x3a6c <generic_fentry_process_event+0x36bc>
    3a47:      	movl	$0x19, %eax
    3a4c:      	movq	0x18(%rsp), %rdi
    3a51:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    3a56:      	movq	(%rip), %rsi            # 0x3a5d <generic_fentry_process_event+0x36ad>
    3a5d:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    3a62:      	movq	%rbx, %rcx
    3a65:      	movq	%r12, %r8
    3a68:      	callq	*%rax
    3a6a:      	jmp	0x3a84 <generic_fentry_process_event+0x36d4>
    3a6c:      	movl	$0x82, %eax
    3a71:      	xorl	%ecx, %ecx
    3a73:      	movq	(%rip), %rdi            # 0x3a7a <generic_fentry_process_event+0x36ca>
    3a7a:      	movq	%rbx, %rsi
    3a7d:      	movq	%r12, %rdx
    3a80:      	xorl	%ecx, %ecx
    3a82:      	callq	*%rax
    3a84:      	testl	%eax, %eax
    3a86:      	jns	0x3a8b <generic_fentry_process_event+0x36db>
    3a88:      	movslq	%eax, %rbp
    3a8b:      	testl	%ebp, %ebp
    3a8d:      	js	0x3cb6 <generic_fentry_process_event+0x3906>
    3a93:      	andl	$0x7fffffff, %ebp       # imm = 0x7FFFFFFF
    3a99:      	addq	%rbp, %r13
    3a9c:      	cmpq	%r14, %r13
    3a9f:      	je	0x3d10 <generic_fentry_process_event+0x3960>
    3aa5:      	decl	%r15d
    3aa8:      	jne	0x39e2 <generic_fentry_process_event+0x3632>
    3aae:      	jmp	0x4047 <generic_fentry_process_event+0x3c97>
    3ab3:      	addq	$0x90, %rbp
    3aba:      	movq	0xc8(%rsp), %rax
    3ac2:      	movl	$0x0, 0x4(%rbp,%rax)
    3aca:      	addq	%rbp, %rax
    3acd:      	addq	$0x8, %rax
    3ad1:      	movq	%rax, 0xa8(%rsp)
    3ad9:      	movl	$0xc, %ebx
    3ade:      	cmpq	$0xfff, %r14            # imm = 0xFFF
    3ae5:      	movl	$0xfff, %r13d           # imm = 0xFFF
    3aeb:      	cmovbq	%r14, %r13
    3aef:      	movq	0xa8(%rsp), %rax
    3af7:      	leaq	0x8(%rax), %rdi
    3afb:      	movl	$0x4, %eax
    3b00:      	movq	0x10(%rsp), %rdx
    3b05:      	movl	%r13d, %esi
    3b08:      	callq	*%rax
    3b0a:      	testl	%eax, %eax
    3b0c:      	js	0x3b28 <generic_fentry_process_event+0x3778>
    3b0e:      	movq	0xa8(%rsp), %rax
    3b16:      	movl	%r14d, (%rax)
    3b19:      	movl	%r13d, 0x4(%rax)
    3b1d:      	addq	%r13, %rbx
    3b20:      	movq	%rbx, %r13
    3b23:      	jmp	0x409a <generic_fentry_process_event+0x3cea>
    3b28:      	movq	0xa8(%rsp), %rax
    3b30:      	movl	$0xfffffffe, (%rax)     # imm = 0xFFFFFFFE
    3b36:      	movl	$0x4, %r13d
    3b3c:      	jmp	0x409a <generic_fentry_process_event+0x3cea>
    3b41:      	movq	$-0x1, %rbp
    3b48:      	jmp	0x3b4d <generic_fentry_process_event+0x379d>
    3b4a:      	movq	%r13, %rbp
    3b4d:      	movl	$0x0, 0x68(%rsp)
    3b55:      	movq	(%rip), %rdi            # 0x3b5c <generic_fentry_process_event+0x37ac>
    3b5c:      	leaq	0x68(%rsp), %rsi
    3b61:      	movl	$0x1, %eax
    3b66:      	callq	*%rax
    3b68:      	testq	%rax, %rax
    3b6b:      	je	0x3efc <generic_fentry_process_event+0x3b4c>
    3b71:      	cmpq	$-0xc, %rbp
    3b75:      	jg	0x3c84 <generic_fentry_process_event+0x38d4>
    3b7b:      	cmpq	$-0x1c, %rbp
    3b7f:      	je	0x3ed2 <generic_fentry_process_event+0x3b22>
    3b85:      	cmpq	$-0x16, %rbp
    3b89:      	je	0x3eea <generic_fentry_process_event+0x3b3a>
    3b8f:      	cmpq	$-0x10, %rbp
    3b93:      	jne	0x3ee2 <generic_fentry_process_event+0x3b32>
    3b99:      	addq	$0x558, %rax            # imm = 0x558
    3b9f:      	jmp	0x3ef8 <generic_fentry_process_event+0x3b48>
    3ba4:      	movq	0x10(%rsp), %rbp
    3ba9:      	jmp	0x3efc <generic_fentry_process_event+0x3b4c>
    3bae:      	movzbl	0x7(%rbx), %eax
    3bb2:      	leal	0x8(,%rax,4), %eax
    3bb9:      	movw	%ax, 0x2(%rbx)
    3bbd:      	addw	(%rbx), %ax
    3bc0:      	movw	%ax, (%rbx)
    3bc3:      	movzbl	0x6(%rbx), %r15d
    3bc8:      	cmpq	$0x3c, %r15
    3bcc:      	ja	0x444d <generic_fentry_process_event+0x409d>
    3bd2:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3bdc:      	btq	%r15, %rcx
    3be0:      	jae	0x444d <generic_fentry_process_event+0x409d>
    3be6:      	movb	%r15b, 0x5(%rbx)
    3bea:      	movzwl	%ax, %ecx
    3bed:      	addq	%r14, %rcx
    3bf0:      	movl	$0x2, %edx
    3bf5:      	movl	$0x4, %eax
    3bfa:      	movq	0x10(%rsp), %rdi
    3bff:      	movzwl	(%rbx), %edx
    3c02:      	addq	%r14, %rdx
    3c05:      	movl	$0x2, %esi
    3c0a:      	callq	*%rax
    3c0c:      	testq	%rax, %rax
    3c0f:      	js	0x4289 <generic_fentry_process_event+0x3ed9>
    3c15:      	movzbl	0x5(%rbx), %eax
    3c19:      	cmpl	$0x32, %eax
    3c1c:      	jg	0x3c3f <generic_fentry_process_event+0x388f>
    3c1e:      	testl	%eax, %eax
    3c20:      	je	0x3c67 <generic_fentry_process_event+0x38b7>
    3c22:      	cmpl	$0x2b, %eax
    3c25:      	je	0x3c67 <generic_fentry_process_event+0x38b7>
    3c27:      	cmpl	$0x2c, %eax
    3c2a:      	jne	0x3d29 <generic_fentry_process_event+0x3979>
    3c30:      	movw	$0x8, 0x2(%rbx)
    3c36:      	movw	$0x8, %ax
    3c3a:      	jmp	0x3d2d <generic_fentry_process_event+0x397d>
    3c3f:      	cmpl	$0x33, %eax
    3c42:      	je	0x3d18 <generic_fentry_process_event+0x3968>
    3c48:      	cmpl	$0x3c, %eax
    3c4b:      	je	0x3c67 <generic_fentry_process_event+0x38b7>
    3c4d:      	cmpl	$0xff, %eax
    3c52:      	jne	0x3d29 <generic_fentry_process_event+0x3979>
    3c58:      	movw	$0x28, 0x2(%rbx)
    3c5e:      	movw	$0x28, %ax
    3c62:      	jmp	0x3d2d <generic_fentry_process_event+0x397d>
    3c67:      	movzbl	0x7(%rbx), %eax
    3c6b:      	leal	0x8(,%rax,8), %eax
    3c72:      	movw	%ax, 0x2(%rbx)
    3c76:      	jmp	0x3d2d <generic_fentry_process_event+0x397d>
    3c7b:      	movzwl	0x2(%rbx), %eax
    3c7f:      	jmp	0x3bbd <generic_fentry_process_event+0x380d>
    3c84:      	cmpq	$-0xb, %rbp
    3c88:      	je	0x3eda <generic_fentry_process_event+0x3b2a>
    3c8e:      	cmpq	$-0x7, %rbp
    3c92:      	je	0x3ef2 <generic_fentry_process_event+0x3b42>
    3c98:      	cmpq	$-0x2, %rbp
    3c9c:      	jne	0x3ee2 <generic_fentry_process_event+0x3b32>
    3ca2:      	addq	$0x548, %rax            # imm = 0x548
    3ca8:      	jmp	0x3ef8 <generic_fentry_process_event+0x3b48>
    3cad:      	movq	$-0x1, %r13
    3cb4:      	jmp	0x3cb9 <generic_fentry_process_event+0x3909>
    3cb6:      	movq	%rbp, %r13
    3cb9:      	movl	$0x0, 0x68(%rsp)
    3cc1:      	movq	(%rip), %rdi            # 0x3cc8 <generic_fentry_process_event+0x3918>
    3cc8:      	leaq	0x68(%rsp), %rsi
    3ccd:      	movl	$0x1, %eax
    3cd2:      	callq	*%rax
    3cd4:      	testq	%rax, %rax
    3cd7:      	je	0x4047 <generic_fentry_process_event+0x3c97>
    3cdd:      	cmpq	$-0xc, %r13
    3ce1:      	jg	0x3dd6 <generic_fentry_process_event+0x3a26>
    3ce7:      	cmpq	$-0x1c, %r13
    3ceb:      	je	0x401d <generic_fentry_process_event+0x3c6d>
    3cf1:      	cmpq	$-0x16, %r13
    3cf5:      	je	0x4025 <generic_fentry_process_event+0x3c75>
    3cfb:      	cmpq	$-0x10, %r13
    3cff:      	jne	0x403d <generic_fentry_process_event+0x3c8d>
    3d05:      	addq	$0x558, %rax            # imm = 0x558
    3d0b:      	jmp	0x4043 <generic_fentry_process_event+0x3c93>
    3d10:      	movq	%r14, %r13
    3d13:      	jmp	0x4047 <generic_fentry_process_event+0x3c97>
    3d18:      	movzbl	0x7(%rbx), %eax
    3d1c:      	leal	0x8(,%rax,4), %eax
    3d23:      	movw	%ax, 0x2(%rbx)
    3d27:      	jmp	0x3d2d <generic_fentry_process_event+0x397d>
    3d29:      	movzwl	0x2(%rbx), %eax
    3d2d:      	addw	(%rbx), %ax
    3d30:      	movw	%ax, (%rbx)
    3d33:      	movzbl	0x6(%rbx), %r15d
    3d38:      	cmpq	$0x3c, %r15
    3d3c:      	ja	0x444d <generic_fentry_process_event+0x409d>
    3d42:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3d4c:      	btq	%r15, %rcx
    3d50:      	jae	0x444d <generic_fentry_process_event+0x409d>
    3d56:      	movb	%r15b, 0x5(%rbx)
    3d5a:      	movzwl	%ax, %ecx
    3d5d:      	addq	%r14, %rcx
    3d60:      	movl	$0x2, %edx
    3d65:      	movl	$0x4, %eax
    3d6a:      	movq	0x10(%rsp), %rdi
    3d6f:      	movzwl	(%rbx), %edx
    3d72:      	addq	%r14, %rdx
    3d75:      	movl	$0x2, %esi
    3d7a:      	callq	*%rax
    3d7c:      	testq	%rax, %rax
    3d7f:      	js	0x4289 <generic_fentry_process_event+0x3ed9>
    3d85:      	movzbl	0x5(%rbx), %eax
    3d89:      	cmpl	$0x32, %eax
    3d8c:      	jg	0x3da8 <generic_fentry_process_event+0x39f8>
    3d8e:      	testl	%eax, %eax
    3d90:      	je	0x3dc5 <generic_fentry_process_event+0x3a15>
    3d92:      	cmpl	$0x2b, %eax
    3d95:      	je	0x3dc5 <generic_fentry_process_event+0x3a15>
    3d97:      	cmpl	$0x2c, %eax
    3d9a:      	jne	0x3e10 <generic_fentry_process_event+0x3a60>
    3d9c:      	movw	$0x8, 0x2(%rbx)
    3da2:      	movw	$0x8, %ax
    3da6:      	jmp	0x3e14 <generic_fentry_process_event+0x3a64>
    3da8:      	cmpl	$0x33, %eax
    3dab:      	je	0x3dff <generic_fentry_process_event+0x3a4f>
    3dad:      	cmpl	$0x3c, %eax
    3db0:      	je	0x3dc5 <generic_fentry_process_event+0x3a15>
    3db2:      	cmpl	$0xff, %eax
    3db7:      	jne	0x3e10 <generic_fentry_process_event+0x3a60>
    3db9:      	movw	$0x28, 0x2(%rbx)
    3dbf:      	movw	$0x28, %ax
    3dc3:      	jmp	0x3e14 <generic_fentry_process_event+0x3a64>
    3dc5:      	movzbl	0x7(%rbx), %eax
    3dc9:      	leal	0x8(,%rax,8), %eax
    3dd0:      	movw	%ax, 0x2(%rbx)
    3dd4:      	jmp	0x3e14 <generic_fentry_process_event+0x3a64>
    3dd6:      	cmpq	$-0xb, %r13
    3dda:      	je	0x402d <generic_fentry_process_event+0x3c7d>
    3de0:      	cmpq	$-0x7, %r13
    3de4:      	je	0x4035 <generic_fentry_process_event+0x3c85>
    3dea:      	cmpq	$-0x2, %r13
    3dee:      	jne	0x403d <generic_fentry_process_event+0x3c8d>
    3df4:      	addq	$0x548, %rax            # imm = 0x548
    3dfa:      	jmp	0x4043 <generic_fentry_process_event+0x3c93>
    3dff:      	movzbl	0x7(%rbx), %eax
    3e03:      	leal	0x8(,%rax,4), %eax
    3e0a:      	movw	%ax, 0x2(%rbx)
    3e0e:      	jmp	0x3e14 <generic_fentry_process_event+0x3a64>
    3e10:      	movzwl	0x2(%rbx), %eax
    3e14:      	addw	(%rbx), %ax
    3e17:      	movw	%ax, (%rbx)
    3e1a:      	movzbl	0x6(%rbx), %r15d
    3e1f:      	cmpq	$0x3c, %r15
    3e23:      	ja	0x444d <generic_fentry_process_event+0x409d>
    3e29:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3e33:      	btq	%r15, %rcx
    3e37:      	jae	0x444d <generic_fentry_process_event+0x409d>
    3e3d:      	movb	%r15b, 0x5(%rbx)
    3e41:      	movzwl	%ax, %ecx
    3e44:      	addq	%r14, %rcx
    3e47:      	movl	$0x2, %edx
    3e4c:      	movl	$0x4, %eax
    3e51:      	movq	0x10(%rsp), %rdi
    3e56:      	movzwl	(%rbx), %edx
    3e59:      	addq	%r14, %rdx
    3e5c:      	movl	$0x2, %esi
    3e61:      	callq	*%rax
    3e63:      	testq	%rax, %rax
    3e66:      	js	0x4289 <generic_fentry_process_event+0x3ed9>
    3e6c:      	movzbl	0x5(%rbx), %eax
    3e70:      	cmpl	$0x32, %eax
    3e73:      	jg	0x3e96 <generic_fentry_process_event+0x3ae6>
    3e75:      	testl	%eax, %eax
    3e77:      	je	0x3ebe <generic_fentry_process_event+0x3b0e>
    3e79:      	cmpl	$0x2b, %eax
    3e7c:      	je	0x3ebe <generic_fentry_process_event+0x3b0e>
    3e7e:      	cmpl	$0x2c, %eax
    3e81:      	jne	0x3f5b <generic_fentry_process_event+0x3bab>
    3e87:      	movw	$0x8, 0x2(%rbx)
    3e8d:      	movw	$0x8, %ax
    3e91:      	jmp	0x3f5f <generic_fentry_process_event+0x3baf>
    3e96:      	cmpl	$0x33, %eax
    3e99:      	je	0x3f4a <generic_fentry_process_event+0x3b9a>
    3e9f:      	cmpl	$0x3c, %eax
    3ea2:      	je	0x3ebe <generic_fentry_process_event+0x3b0e>
    3ea4:      	cmpl	$0xff, %eax
    3ea9:      	jne	0x3f5b <generic_fentry_process_event+0x3bab>
    3eaf:      	movw	$0x28, 0x2(%rbx)
    3eb5:      	movw	$0x28, %ax
    3eb9:      	jmp	0x3f5f <generic_fentry_process_event+0x3baf>
    3ebe:      	movzbl	0x7(%rbx), %eax
    3ec2:      	leal	0x8(,%rax,8), %eax
    3ec9:      	movw	%ax, 0x2(%rbx)
    3ecd:      	jmp	0x3f5f <generic_fentry_process_event+0x3baf>
    3ed2:      	addq	$0x568, %rax            # imm = 0x568
    3ed8:      	jmp	0x3ef8 <generic_fentry_process_event+0x3b48>
    3eda:      	addq	$0x570, %rax            # imm = 0x570
    3ee0:      	jmp	0x3ef8 <generic_fentry_process_event+0x3b48>
    3ee2:      	addq	$0x540, %rax            # imm = 0x540
    3ee8:      	jmp	0x3ef8 <generic_fentry_process_event+0x3b48>
    3eea:      	addq	$0x560, %rax            # imm = 0x560
    3ef0:      	jmp	0x3ef8 <generic_fentry_process_event+0x3b48>
    3ef2:      	addq	$0x550, %rax            # imm = 0x550
    3ef8:      	lock
    3ef9:      	incq	(%rax)
    3efc:      	testl	%ebp, %ebp
    3efe:      	js	0x3f21 <generic_fentry_process_event+0x3b71>
    3f00:      	movq	0x40(%rsp), %rax
    3f05:      	movq	$0x0, 0x4(%rax)
    3f0d:      	movq	0x10(%rsp), %rdx
    3f12:      	movl	%edx, %ecx
    3f14:      	subl	%ebp, %ecx
    3f16:      	xorl	%eax, %eax
    3f18:      	cmpq	$-0x1, %rdx
    3f1c:      	cmovnel	%ecx, %eax
    3f1f:      	jmp	0x3f34 <generic_fentry_process_event+0x3b84>
    3f21:      	movq	0x40(%rsp), %rax
    3f26:      	movl	%ebp, 0x4(%rax)
    3f29:      	movl	$0x0, 0x8(%rax)
    3f30:      	xorl	%eax, %eax
    3f32:      	xorl	%ebp, %ebp
    3f34:      	movq	0x40(%rsp), %rcx
    3f39:      	movl	%eax, 0xc(%rcx)
    3f3c:      	movl	%ebp, 0x10(%rcx)
    3f3f:      	movl	$0x24, %r13d
    3f45:      	jmp	0x1941 <generic_fentry_process_event+0x1591>
    3f4a:      	movzbl	0x7(%rbx), %eax
    3f4e:      	leal	0x8(,%rax,4), %eax
    3f55:      	movw	%ax, 0x2(%rbx)
    3f59:      	jmp	0x3f5f <generic_fentry_process_event+0x3baf>
    3f5b:      	movzwl	0x2(%rbx), %eax
    3f5f:      	addw	(%rbx), %ax
    3f62:      	movw	%ax, (%rbx)
    3f65:      	movzbl	0x6(%rbx), %r15d
    3f6a:      	cmpq	$0x3c, %r15
    3f6e:      	ja	0x444d <generic_fentry_process_event+0x409d>
    3f74:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3f7e:      	btq	%r15, %rcx
    3f82:      	jae	0x444d <generic_fentry_process_event+0x409d>
    3f88:      	movb	%r15b, 0x5(%rbx)
    3f8c:      	movzwl	%ax, %ecx
    3f8f:      	addq	%r14, %rcx
    3f92:      	movl	$0x2, %edx
    3f97:      	movl	$0x4, %eax
    3f9c:      	movq	0x10(%rsp), %rdi
    3fa1:      	movzwl	(%rbx), %edx
    3fa4:      	addq	%r14, %rdx
    3fa7:      	movl	$0x2, %esi
    3fac:      	callq	*%rax
    3fae:      	testq	%rax, %rax
    3fb1:      	js	0x4289 <generic_fentry_process_event+0x3ed9>
    3fb7:      	movzbl	0x5(%rbx), %eax
    3fbb:      	cmpl	$0x32, %eax
    3fbe:      	jg	0x3fe1 <generic_fentry_process_event+0x3c31>
    3fc0:      	testl	%eax, %eax
    3fc2:      	je	0x4009 <generic_fentry_process_event+0x3c59>
    3fc4:      	cmpl	$0x2b, %eax
    3fc7:      	je	0x4009 <generic_fentry_process_event+0x3c59>
    3fc9:      	cmpl	$0x2c, %eax
    3fcc:      	jne	0x40ba <generic_fentry_process_event+0x3d0a>
    3fd2:      	movw	$0x8, 0x2(%rbx)
    3fd8:      	movw	$0x8, %ax
    3fdc:      	jmp	0x40be <generic_fentry_process_event+0x3d0e>
    3fe1:      	cmpl	$0x33, %eax
    3fe4:      	je	0x40a9 <generic_fentry_process_event+0x3cf9>
    3fea:      	cmpl	$0x3c, %eax
    3fed:      	je	0x4009 <generic_fentry_process_event+0x3c59>
    3fef:      	cmpl	$0xff, %eax
    3ff4:      	jne	0x40ba <generic_fentry_process_event+0x3d0a>
    3ffa:      	movw	$0x28, 0x2(%rbx)
    4000:      	movw	$0x28, %ax
    4004:      	jmp	0x40be <generic_fentry_process_event+0x3d0e>
    4009:      	movzbl	0x7(%rbx), %eax
    400d:      	leal	0x8(,%rax,8), %eax
    4014:      	movw	%ax, 0x2(%rbx)
    4018:      	jmp	0x40be <generic_fentry_process_event+0x3d0e>
    401d:      	addq	$0x568, %rax            # imm = 0x568
    4023:      	jmp	0x4043 <generic_fentry_process_event+0x3c93>
    4025:      	addq	$0x560, %rax            # imm = 0x560
    402b:      	jmp	0x4043 <generic_fentry_process_event+0x3c93>
    402d:      	addq	$0x570, %rax            # imm = 0x570
    4033:      	jmp	0x4043 <generic_fentry_process_event+0x3c93>
    4035:      	addq	$0x550, %rax            # imm = 0x550
    403b:      	jmp	0x4043 <generic_fentry_process_event+0x3c93>
    403d:      	addq	$0x540, %rax            # imm = 0x540
    4043:      	lock
    4044:      	incq	(%rax)
    4047:      	testl	%r13d, %r13d
    404a:      	js	0x406d <generic_fentry_process_event+0x3cbd>
    404c:      	movq	0xa8(%rsp), %rax
    4054:      	movq	$0x0, 0x4(%rax)
    405c:      	movl	%r14d, %ecx
    405f:      	subl	%r13d, %ecx
    4062:      	xorl	%eax, %eax
    4064:      	cmpq	$-0x1, %r14
    4068:      	cmovnel	%ecx, %eax
    406b:      	jmp	0x4085 <generic_fentry_process_event+0x3cd5>
    406d:      	movq	0xa8(%rsp), %rax
    4075:      	movl	%r13d, 0x4(%rax)
    4079:      	movl	$0x0, 0x8(%rax)
    4080:      	xorl	%eax, %eax
    4082:      	xorl	%r13d, %r13d
    4085:      	movq	0xa8(%rsp), %rcx
    408d:      	movl	%eax, 0xc(%rcx)
    4090:      	movl	%r13d, 0x10(%rcx)
    4094:      	movl	$0x24, %r13d
    409a:      	movq	0x18(%rsp), %rbx
    409f:      	movq	0x28(%rsp), %r14
    40a4:      	jmp	0x1941 <generic_fentry_process_event+0x1591>
    40a9:      	movzbl	0x7(%rbx), %eax
    40ad:      	leal	0x8(,%rax,4), %eax
    40b4:      	movw	%ax, 0x2(%rbx)
    40b8:      	jmp	0x40be <generic_fentry_process_event+0x3d0e>
    40ba:      	movzwl	0x2(%rbx), %eax
    40be:      	addw	(%rbx), %ax
    40c1:      	movw	%ax, (%rbx)
    40c4:      	movzbl	0x6(%rbx), %r15d
    40c9:      	cmpq	$0x3c, %r15
    40cd:      	ja	0x444d <generic_fentry_process_event+0x409d>
    40d3:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    40dd:      	btq	%r15, %rcx
    40e1:      	jae	0x444d <generic_fentry_process_event+0x409d>
    40e7:      	movb	%r15b, 0x5(%rbx)
    40eb:      	movzwl	%ax, %ecx
    40ee:      	addq	%r14, %rcx
    40f1:      	movl	$0x2, %edx
    40f6:      	movl	$0x4, %eax
    40fb:      	movq	0x10(%rsp), %rdi
    4100:      	movzwl	(%rbx), %edx
    4103:      	addq	%r14, %rdx
    4106:      	movl	$0x2, %esi
    410b:      	callq	*%rax
    410d:      	testq	%rax, %rax
    4110:      	js	0x4289 <generic_fentry_process_event+0x3ed9>
    4116:      	movzbl	0x5(%rbx), %eax
    411a:      	cmpl	$0x32, %eax
    411d:      	jg	0x4139 <generic_fentry_process_event+0x3d89>
    411f:      	testl	%eax, %eax
    4121:      	je	0x4156 <generic_fentry_process_event+0x3da6>
    4123:      	cmpl	$0x2b, %eax
    4126:      	je	0x4156 <generic_fentry_process_event+0x3da6>
    4128:      	cmpl	$0x2c, %eax
    412b:      	jne	0x4178 <generic_fentry_process_event+0x3dc8>
    412d:      	movw	$0x8, 0x2(%rbx)
    4133:      	movw	$0x8, %ax
    4137:      	jmp	0x417c <generic_fentry_process_event+0x3dcc>
    4139:      	cmpl	$0x33, %eax
    413c:      	je	0x4167 <generic_fentry_process_event+0x3db7>
    413e:      	cmpl	$0x3c, %eax
    4141:      	je	0x4156 <generic_fentry_process_event+0x3da6>
    4143:      	cmpl	$0xff, %eax
    4148:      	jne	0x4178 <generic_fentry_process_event+0x3dc8>
    414a:      	movw	$0x28, 0x2(%rbx)
    4150:      	movw	$0x28, %ax
    4154:      	jmp	0x417c <generic_fentry_process_event+0x3dcc>
    4156:      	movzbl	0x7(%rbx), %eax
    415a:      	leal	0x8(,%rax,8), %eax
    4161:      	movw	%ax, 0x2(%rbx)
    4165:      	jmp	0x417c <generic_fentry_process_event+0x3dcc>
    4167:      	movzbl	0x7(%rbx), %eax
    416b:      	leal	0x8(,%rax,4), %eax
    4172:      	movw	%ax, 0x2(%rbx)
    4176:      	jmp	0x417c <generic_fentry_process_event+0x3dcc>
    4178:      	movzwl	0x2(%rbx), %eax
    417c:      	addw	(%rbx), %ax
    417f:      	movw	%ax, (%rbx)
    4182:      	movzbl	0x6(%rbx), %r15d
    4187:      	cmpq	$0x3c, %r15
    418b:      	ja	0x444d <generic_fentry_process_event+0x409d>
    4191:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    419b:      	btq	%r15, %rcx
    419f:      	jae	0x444d <generic_fentry_process_event+0x409d>
    41a5:      	movb	%r15b, 0x5(%rbx)
    41a9:      	movzwl	%ax, %ecx
    41ac:      	addq	%r14, %rcx
    41af:      	movl	$0x2, %edx
    41b4:      	movl	$0x4, %eax
    41b9:      	movq	0x10(%rsp), %rdi
    41be:      	movzwl	(%rbx), %edx
    41c1:      	addq	%r14, %rdx
    41c4:      	movl	$0x2, %esi
    41c9:      	callq	*%rax
    41cb:      	testq	%rax, %rax
    41ce:      	js	0x4289 <generic_fentry_process_event+0x3ed9>
    41d4:      	movzbl	0x5(%rbx), %eax
    41d8:      	cmpl	$0x32, %eax
    41db:      	jg	0x41f7 <generic_fentry_process_event+0x3e47>
    41dd:      	testl	%eax, %eax
    41df:      	je	0x4214 <generic_fentry_process_event+0x3e64>
    41e1:      	cmpl	$0x2b, %eax
    41e4:      	je	0x4214 <generic_fentry_process_event+0x3e64>
    41e6:      	cmpl	$0x2c, %eax
    41e9:      	jne	0x4236 <generic_fentry_process_event+0x3e86>
    41eb:      	movw	$0x8, 0x2(%rbx)
    41f1:      	movw	$0x8, %ax
    41f5:      	jmp	0x423a <generic_fentry_process_event+0x3e8a>
    41f7:      	cmpl	$0x33, %eax
    41fa:      	je	0x4225 <generic_fentry_process_event+0x3e75>
    41fc:      	cmpl	$0x3c, %eax
    41ff:      	je	0x4214 <generic_fentry_process_event+0x3e64>
    4201:      	cmpl	$0xff, %eax
    4206:      	jne	0x4236 <generic_fentry_process_event+0x3e86>
    4208:      	movw	$0x28, 0x2(%rbx)
    420e:      	movw	$0x28, %ax
    4212:      	jmp	0x423a <generic_fentry_process_event+0x3e8a>
    4214:      	movzbl	0x7(%rbx), %eax
    4218:      	leal	0x8(,%rax,8), %eax
    421f:      	movw	%ax, 0x2(%rbx)
    4223:      	jmp	0x423a <generic_fentry_process_event+0x3e8a>
    4225:      	movzbl	0x7(%rbx), %eax
    4229:      	leal	0x8(,%rax,4), %eax
    4230:      	movw	%ax, 0x2(%rbx)
    4234:      	jmp	0x423a <generic_fentry_process_event+0x3e8a>
    4236:      	movzwl	0x2(%rbx), %eax
    423a:      	addw	(%rbx), %ax
    423d:      	movw	%ax, (%rbx)
    4240:      	movzbl	0x6(%rbx), %r15d
    4245:      	cmpq	$0x3c, %r15
    4249:      	ja	0x444d <generic_fentry_process_event+0x409d>
    424f:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    4259:      	btq	%r15, %rcx
    425d:      	jae	0x444d <generic_fentry_process_event+0x409d>
    4263:      	movb	%r15b, 0x5(%rbx)
    4267:      	movzwl	%ax, %ecx
    426a:      	addq	%r14, %rcx
    426d:      	movl	$0x2, %edx
    4272:      	movl	$0x4, %eax
    4277:      	movq	0x10(%rsp), %rdi
    427c:      	movzwl	(%rbx), %edx
    427f:      	addq	%r14, %rdx
    4282:      	movl	$0x2, %esi
    4287:      	callq	*%rax
    4289:      	xorl	%r15d, %r15d
    428c:      	movb	%r15b, 0xd0(%rsp)
    4294:      	movzbl	%r15b, %eax
    4298:      	movq	%rbp, %rbx
    429b:      	movw	%ax, 0x24(%rbp)
    429f:      	movw	$0xa, 0x26(%rbp)
    42a5:      	leaq	0x8(%r12), %rdx
    42aa:      	movl	$0x10, %ecx
    42af:      	movl	$0x4, %eax
    42b4:      	movq	%rbp, %rdi
    42b7:      	movl	$0x10, %esi
    42bc:      	callq	*%rax
    42be:      	leaq	0x10(%rbp), %rdi
    42c2:      	addq	$0x18, %r12
    42c6:      	movl	$0x10, %ecx
    42cb:      	movl	$0x4, %eax
    42d0:      	movl	$0x10, %esi
    42d5:      	movq	%r12, %rdx
    42d8:      	callq	*%rax
    42da:      	cmpb	$0x11, %r15b
    42de:      	je	0x432f <generic_fentry_process_event+0x3f7f>
    42e0:      	movzbl	%r15b, %eax
    42e4:      	cmpl	$0x6, %eax
    42e7:      	jne	0x4378 <generic_fentry_process_event+0x3fc8>
    42ed:      	movq	0x68(%rsp), %r15
    42f2:      	movzwl	0xc0(%rsp), %r12d
    42fb:      	leaq	(%r15,%r12), %rdx
    42ff:      	movq	%rbp, %rbx
    4302:      	leaq	0x20(%rbp), %rdi
    4306:      	movl	$0x2, %ecx
    430b:      	movl	$0x4, %eax
    4310:      	movl	$0x2, %esi
    4315:      	callq	*%rax
    4317:      	leaq	0x22(%rbp), %rdi
    431b:      	leaq	(%r15,%r12), %rdx
    431f:      	addq	$0x2, %rdx
    4323:      	movl	$0x2, %ecx
    4328:      	movl	$0x4, %eax
    432d:      	jmp	0x436f <generic_fentry_process_event+0x3fbf>
    432f:      	movq	0x68(%rsp), %r15
    4334:      	movzwl	0xc0(%rsp), %r12d
    433d:      	leaq	(%r15,%r12), %rdx
    4341:      	movq	%rbp, %rbx
    4344:      	leaq	0x20(%rbp), %rdi
    4348:      	movl	$0x2, %ecx
    434d:      	movl	$0x4, %eax
    4352:      	movl	$0x2, %esi
    4357:      	callq	*%rax
    4359:      	leaq	0x22(%rbp), %rdi
    435d:      	leaq	(%r15,%r12), %rdx
    4361:      	addq	$0x2, %rdx
    4365:      	movl	$0x2, %ecx
    436a:      	movl	$0x4, %eax
    436f:      	movl	$0x2, %esi
    4374:      	callq	*%rax
    4376:      	jmp	0x437f <generic_fentry_process_event+0x3fcf>
    4378:      	movl	$0x0, 0x20(%rbp)
    437f:      	movzwl	0x20(%rbp), %eax
    4383:      	movzwl	0x22(%rbp), %ecx
    4387:      	movbew	%ax, 0x20(%rbp)
    438d:      	movbew	%cx, 0x22(%rbp)
    4393:      	addq	$0xe0, %r13
    439a:      	leaq	0x58(%rsp), %rdi
    439f:      	movl	$0x8, %ecx
    43a4:      	movl	$0x4, %eax
    43a9:      	movl	$0x4, %r15d
    43af:      	movl	$0x8, %esi
    43b4:      	movq	%r13, %rdx
    43b7:      	callq	*%rax
    43b9:      	movq	0x58(%rsp), %rcx
    43be:      	testq	%rcx, %rcx
    43c1:      	je	0x4429 <generic_fentry_process_event+0x4079>
    43c3:      	addq	$0x5, %rcx
    43c7:      	leaq	0xb0(%rsp), %rdi
    43cf:      	movl	$0x8, %edx
    43d4:      	movl	$0x4, %eax
    43d9:      	movq	0x58(%rsp), %rdx
    43de:      	addq	$0x5, %rdx
    43e2:      	movl	$0x8, %esi
    43e7:      	callq	*%rax
    43e9:      	movq	0x58(%rsp), %r12
    43ee:      	movq	0xb0(%rsp), %r13
    43f6:      	leaq	0x38(%rbp), %rdi
    43fa:      	leaq	(%r12,%r13,8), %rdx
    43fe:      	addq	$0x44, %rdx
    4402:      	movl	$0x4, %eax
    4407:      	movl	$0x4, %esi
    440c:      	callq	*%rax
    440e:      	addq	$0x3c, %rbp
    4412:      	leaq	(%r12,%r13,8), %rdx
    4416:      	addq	$0x45, %rdx
    441a:      	movl	$0x4, %eax
    441f:      	movq	%rbp, %rdi
    4422:      	movl	$0x4, %esi
    4427:      	callq	*%rax
    4429:      	movl	$0x40, %r13d
    442f:      	movq	0x38(%rsp), %rax
    4434:      	movq	0x20(%rsp), %rcx
    4439:      	movl	$0x4, %esi
    443e:      	movq	0x18(%rsp), %rbx
    4443:      	movq	0x28(%rsp), %r14
    4448:      	jmp	0x1950 <generic_fentry_process_event+0x15a0>
    444d:      	movw	%ax, 0xc0(%rsp)
    4455:      	jmp	0x428c <generic_fentry_process_event+0x3edc>
    445a:      	nopw	(%rax,%rax)

0000000000004460 <generic_fentry_process_filter>:
    4460:      	pushq	%rbp
    4461:      	pushq	%r15
    4463:      	pushq	%r14
    4465:      	pushq	%r13
    4467:      	pushq	%r12
    4469:      	pushq	%rbx
    446a:      	subq	$0xe8, %rsp
    4471:      	movq	%rdi, %rbx
    4474:      	movl	$0x0, 0xc8(%rsp)
    447f:      	movq	(%rip), %rdi            # 0x4486 <generic_fentry_process_filter+0x26>
    4486:      	leaq	0xc8(%rsp), %rsi
    448e:      	movl	$0x1, %eax
    4493:      	callq	*%rax
    4495:      	testq	%rax, %rax
    4498:      	je	0x6a83 <generic_fentry_process_filter+0x2623>
    449e:      	movq	%rax, %r14
    44a1:      	movl	$0x23, %eax
    44a6:      	callq	*%rax
    44a8:      	movq	%rax, %rcx
    44ab:      	movq	%rax, 0x60(%rsp)
    44b0:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    44b7:      	leaq	0x10(%rsp), %rdi
    44bc:      	movl	$0x4, %edx
    44c1:      	movl	$0x71, %eax
    44c6:      	movl	$0xaf4, %edx            # imm = 0xAF4
    44cb:      	addq	0x60(%rsp), %rdx
    44d0:      	movl	$0x4, %esi
    44d5:      	callq	*%rax
    44d7:      	movl	0x10(%rsp), %eax
    44db:      	movl	%eax, 0x40(%rsp)
    44df:      	movq	(%rip), %rdi            # 0x44e6 <generic_fentry_process_filter+0x86>
    44e6:      	leaq	0x40(%rsp), %rsi
    44eb:      	movl	$0x1, %eax
    44f0:      	callq	*%rax
    44f2:      	testq	%rax, %rax
    44f5:      	movq	%r14, 0x50(%rsp)
    44fa:      	je	0x450a <generic_fentry_process_filter+0xaa>
    44fc:      	movq	%rax, %r15
    44ff:      	cmpq	$0x0, 0x8(%rax)
    4504:      	jne	0x548f <generic_fentry_process_filter+0x102f>
    450a:      	movl	$0xb00, %edx            # imm = 0xB00
    450f:      	movq	0x60(%rsp), %rcx
    4514:      	addq	%rdx, %rcx
    4517:      	leaq	0x60(%rsp), %rdi
    451c:      	movl	$0x8, %esi
    4521:      	movl	$0x71, %eax
    4526:      	addq	0x60(%rsp), %rdx
    452b:      	movl	$0x8, %esi
    4530:      	callq	*%rax
    4532:      	movq	0x60(%rsp), %rcx
    4537:      	testq	%rcx, %rcx
    453a:      	je	0x46cf <generic_fentry_process_filter+0x26f>
    4540:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    4547:      	leaq	0x10(%rsp), %rdi
    454c:      	movl	$0x4, %edx
    4551:      	movl	$0x71, %eax
    4556:      	movl	$0xaf4, %edx            # imm = 0xAF4
    455b:      	addq	0x60(%rsp), %rdx
    4560:      	movl	$0x4, %esi
    4565:      	callq	*%rax
    4567:      	movl	0x10(%rsp), %eax
    456b:      	movl	%eax, 0x40(%rsp)
    456f:      	movq	(%rip), %rdi            # 0x4576 <generic_fentry_process_filter+0x116>
    4576:      	leaq	0x40(%rsp), %rsi
    457b:      	movl	$0x1, %eax
    4580:      	callq	*%rax
    4582:      	testq	%rax, %rax
    4585:      	je	0x4595 <generic_fentry_process_filter+0x135>
    4587:      	movq	%rax, %r15
    458a:      	cmpq	$0x0, 0x8(%rax)
    458f:      	jne	0x548f <generic_fentry_process_filter+0x102f>
    4595:      	movl	$0xb00, %edx            # imm = 0xB00
    459a:      	movq	0x60(%rsp), %rcx
    459f:      	addq	%rdx, %rcx
    45a2:      	leaq	0x60(%rsp), %rdi
    45a7:      	movl	$0x8, %esi
    45ac:      	movl	$0x71, %eax
    45b1:      	addq	0x60(%rsp), %rdx
    45b6:      	movl	$0x8, %esi
    45bb:      	callq	*%rax
    45bd:      	movq	0x60(%rsp), %rcx
    45c2:      	testq	%rcx, %rcx
    45c5:      	je	0x46cf <generic_fentry_process_filter+0x26f>
    45cb:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    45d2:      	leaq	0x10(%rsp), %rdi
    45d7:      	movl	$0x4, %edx
    45dc:      	movl	$0x71, %eax
    45e1:      	movl	$0xaf4, %edx            # imm = 0xAF4
    45e6:      	addq	0x60(%rsp), %rdx
    45eb:      	movl	$0x4, %esi
    45f0:      	callq	*%rax
    45f2:      	movl	0x10(%rsp), %eax
    45f6:      	movl	%eax, 0x40(%rsp)
    45fa:      	movq	(%rip), %rdi            # 0x4601 <generic_fentry_process_filter+0x1a1>
    4601:      	leaq	0x40(%rsp), %rsi
    4606:      	movl	$0x1, %eax
    460b:      	callq	*%rax
    460d:      	testq	%rax, %rax
    4610:      	je	0x4620 <generic_fentry_process_filter+0x1c0>
    4612:      	movq	%rax, %r15
    4615:      	cmpq	$0x0, 0x8(%rax)
    461a:      	jne	0x548f <generic_fentry_process_filter+0x102f>
    4620:      	movl	$0xb00, %edx            # imm = 0xB00
    4625:      	movq	0x60(%rsp), %rcx
    462a:      	addq	%rdx, %rcx
    462d:      	leaq	0x60(%rsp), %rdi
    4632:      	movl	$0x8, %esi
    4637:      	movl	$0x71, %eax
    463c:      	addq	0x60(%rsp), %rdx
    4641:      	movl	$0x8, %esi
    4646:      	callq	*%rax
    4648:      	movq	0x60(%rsp), %rcx
    464d:      	testq	%rcx, %rcx
    4650:      	je	0x46cf <generic_fentry_process_filter+0x26f>
    4652:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    4659:      	leaq	0x10(%rsp), %rdi
    465e:      	movl	$0x4, %edx
    4663:      	movl	$0x71, %eax
    4668:      	movl	$0xaf4, %edx            # imm = 0xAF4
    466d:      	addq	0x60(%rsp), %rdx
    4672:      	movl	$0x4, %esi
    4677:      	callq	*%rax
    4679:      	movl	0x10(%rsp), %eax
    467d:      	movl	%eax, 0x40(%rsp)
    4681:      	movq	(%rip), %rdi            # 0x4688 <generic_fentry_process_filter+0x228>
    4688:      	leaq	0x40(%rsp), %rsi
    468d:      	movl	$0x1, %eax
    4692:      	callq	*%rax
    4694:      	testq	%rax, %rax
    4697:      	je	0x46a7 <generic_fentry_process_filter+0x247>
    4699:      	movq	%rax, %r15
    469c:      	cmpq	$0x0, 0x8(%rax)
    46a1:      	jne	0x548f <generic_fentry_process_filter+0x102f>
    46a7:      	movl	$0xb00, %edx            # imm = 0xB00
    46ac:      	movq	0x60(%rsp), %rcx
    46b1:      	addq	%rdx, %rcx
    46b4:      	leaq	0x60(%rsp), %rdi
    46b9:      	movl	$0x8, %esi
    46be:      	movl	$0x71, %eax
    46c3:      	addq	0x60(%rsp), %rdx
    46c8:      	movl	$0x8, %esi
    46cd:      	callq	*%rax
    46cf:      	movq	%rbx, 0xb8(%rsp)
    46d7:      	movl	$0x23, %eax
    46dc:      	callq	*%rax
    46de:      	movq	%rax, %r13
    46e1:      	leaq	0xaf4(%rax), %rdx
    46e8:      	leaq	0x60(%rsp), %rdi
    46ed:      	movl	$0x4, %ecx
    46f2:      	movl	$0x4, %eax
    46f7:      	movl	$0x4, %ebp
    46fc:      	movl	$0x4, %esi
    4701:      	callq	*%rax
    4703:      	movl	0x60(%rsp), %eax
    4707:      	movl	%eax, 0x5f10(%r14)
    470e:      	movl	$0x7d, %eax
    4713:      	callq	*%rax
    4715:      	movq	%rax, 0x5f18(%r14)
    471c:      	movl	$0x0, 0x5f20(%r14)
    4727:      	movq	$0x0, 0x5f28(%r14)
    4732:      	movl	$0x0, 0x5f30(%r14)
    473d:      	leaq	0x60(%r13), %rdx
    4741:      	leaq	0x40(%rsp), %rdi
    4746:      	movl	$0x8, %ecx
    474b:      	movl	$0x71, %eax
    4750:      	movl	$0x8, %esi
    4755:      	callq	*%rax
    4757:      	movq	0x40(%rsp), %rcx
    475c:      	xorl	%ebx, %ebx
    475e:      	testq	%rcx, %rcx
    4761:      	je	0x47d0 <generic_fentry_process_filter+0x370>
    4763:      	addq	$0x4, %rcx
    4767:      	leaq	0x10(%rsp), %rdi
    476c:      	movl	$0x4, %edx
    4771:      	movl	$0x71, %eax
    4776:      	movq	0x40(%rsp), %rdx
    477b:      	addq	$0x4, %rdx
    477f:      	movl	$0x4, %esi
    4784:      	callq	*%rax
    4786:      	movl	0x10(%rsp), %eax
    478a:      	testl	%eax, %eax
    478c:      	je	0x47d0 <generic_fentry_process_filter+0x370>
    478e:      	movq	0x40(%rsp), %rcx
    4793:      	shll	$0x4, %eax
    4796:      	addq	%rax, %rcx
    4799:      	addq	$0x80, %rcx
    47a0:      	leaq	0x60(%rsp), %rdi
    47a5:      	movl	$0x10, %edx
    47aa:      	movl	$0x71, %eax
    47af:      	movq	0x40(%rsp), %rcx
    47b4:      	movl	0x10(%rsp), %edx
    47b8:      	shll	$0x4, %edx
    47bb:      	addq	%rcx, %rdx
    47be:      	addq	$0x80, %rdx
    47c5:      	movl	$0x10, %esi
    47ca:      	callq	*%rax
    47cc:      	movl	0x60(%rsp), %ebx
    47d0:      	movl	%ebx, 0x5f34(%r14)
    47d7:      	leaq	0xd00(%r13), %r15
    47de:      	leaq	0x60(%rsp), %rdi
    47e3:      	movl	$0x8, %ecx
    47e8:      	movl	$0x4, %eax
    47ed:      	leaq	0x5f60(%r14), %rbx
    47f4:      	movl	$0x8, %esi
    47f9:      	movq	%r15, %rdx
    47fc:      	callq	*%rax
    47fe:      	movq	0x60(%rsp), %r12
    4803:      	leaq	0x5f68(%r14), %rdi
    480a:      	leaq	0x40(%r12), %rdx
    480f:      	movl	$0x8, %ecx
    4814:      	movl	$0x4, %eax
    4819:      	movl	$0x8, %esi
    481e:      	callq	*%rax
    4820:      	leaq	0x5f70(%r14), %rdi
    4827:      	leaq	0x30(%r12), %rdx
    482c:      	movl	$0x8, %ecx
    4831:      	movl	$0x4, %eax
    4836:      	movl	$0x8, %esi
    483b:      	callq	*%rax
    483d:      	addq	$0x38, %r12
    4841:      	movl	$0x8, %ecx
    4846:      	movl	$0x4, %eax
    484b:      	movq	%rbx, %rdi
    484e:      	movl	$0x8, %esi
    4853:      	movq	%r12, %rdx
    4856:      	callq	*%rax
    4858:      	leaq	0x5f38(%r14), %rbx
    485f:      	leaq	0xd70(%r13), %rdx
    4866:      	leaq	0x10(%rsp), %rdi
    486b:      	movl	$0x8, %ecx
    4870:      	movl	$0x4, %eax
    4875:      	movl	$0x8, %esi
    487a:      	callq	*%rax
    487c:      	movq	0x10(%rsp), %rcx
    4881:      	leaq	0x60(%rsp), %rdi
    4886:      	movl	$0x48, %edx
    488b:      	movl	$0x4, %eax
    4890:      	movq	0x10(%rsp), %rdx
    4895:      	movl	$0x48, %esi
    489a:      	callq	*%rax
    489c:      	movl	$0x218, %edx            # imm = 0x218
    48a1:      	movq	0x68(%rsp), %rcx
    48a6:      	addq	%rdx, %rcx
    48a9:      	movl	$0x4, %eax
    48ae:      	addq	0x68(%rsp), %rdx
    48b3:      	movq	%rbx, %rdi
    48b6:      	movl	$0x4, %esi
    48bb:      	callq	*%rax
    48bd:      	leaq	0x5f3c(%r14), %rdi
    48c4:      	movl	$0x4d8, %edx            # imm = 0x4D8
    48c9:      	movq	0x70(%rsp), %rcx
    48ce:      	addq	%rdx, %rcx
    48d1:      	movl	$0x4, %eax
    48d6:      	addq	0x70(%rsp), %rdx
    48db:      	movl	$0x4, %esi
    48e0:      	callq	*%rax
    48e2:      	leaq	0x5f40(%r14), %rdi
    48e9:      	movq	0x78(%rsp), %rcx
    48ee:      	addq	$0x58, %rcx
    48f2:      	movl	$0x4, %eax
    48f7:      	movq	0x78(%rsp), %rdx
    48fc:      	addq	$0x58, %rdx
    4900:      	movl	$0x4, %esi
    4905:      	callq	*%rax
    4907:      	movq	$0x0, 0x58(%rsp)
    4910:      	leaq	0xb58(%r13), %rdx
    4917:      	leaq	0x58(%rsp), %rdi
    491c:      	movl	$0x8, %ecx
    4921:      	movl	$0x4, %eax
    4926:      	movl	$0x8, %esi
    492b:      	callq	*%rax
    492d:      	movq	0x58(%rsp), %rcx
    4932:      	testq	%rcx, %rcx
    4935:      	je	0x49e4 <generic_fentry_process_filter+0x584>
    493b:      	movl	$0x0, 0xa8(%rsp)
    4946:      	addq	$0x4, %rcx
    494a:      	leaq	0xa8(%rsp), %rdi
    4952:      	movl	$0x4, %edx
    4957:      	movl	$0x4, %eax
    495c:      	movq	0x58(%rsp), %rdx
    4961:      	addq	$0x4, %rdx
    4965:      	movl	$0x4, %esi
    496a:      	callq	*%rax
    496c:      	movq	0x58(%rsp), %rax
    4971:      	movslq	0xa8(%rsp), %rcx
    4979:      	shlq	$0x4, %rcx
    497d:      	addq	%rax, %rcx
    4980:      	addq	$0x80, %rcx
    4987:      	leaq	0x40(%rsp), %rdi
    498c:      	movl	$0x10, %edx
    4991:      	movl	$0x4, %eax
    4996:      	movq	0x58(%rsp), %rcx
    499b:      	movslq	0xa8(%rsp), %rdx
    49a3:      	shlq	$0x4, %rdx
    49a7:      	addq	%rcx, %rdx
    49aa:      	addq	$0x80, %rdx
    49b1:      	movl	$0x10, %esi
    49b6:      	callq	*%rax
    49b8:      	leaq	0x5f44(%r14), %rdi
    49bf:      	movl	$0x158, %edx            # imm = 0x158
    49c4:      	movq	0x48(%rsp), %rcx
    49c9:      	addq	%rdx, %rcx
    49cc:      	movl	$0x4, %esi
    49d1:      	movl	$0x4, %eax
    49d6:      	addq	0x48(%rsp), %rdx
    49db:      	movl	$0x4, %esi
    49e0:      	callq	*%rax
    49e2:      	jmp	0x49ef <generic_fentry_process_filter+0x58f>
    49e4:      	movl	$0x0, 0x5f44(%r14)
    49ef:      	leaq	0x5f48(%r14), %rdi
    49f6:      	movl	$0x158, %ebx            # imm = 0x158
    49fb:      	movq	0x80(%rsp), %rcx
    4a03:      	addq	%rbx, %rcx
    4a06:      	movl	$0x4, %edx
    4a0b:      	movl	$0x4, %eax
    4a10:      	movq	0x80(%rsp), %rdx
    4a18:      	addq	%rbx, %rdx
    4a1b:      	movl	$0x4, %esi
    4a20:      	callq	*%rax
    4a22:      	leaq	0x5f4c(%r14), %rdi
    4a29:      	movl	$0x118, %edx            # imm = 0x118
    4a2e:      	movq	0x88(%rsp), %rcx
    4a36:      	addq	%rdx, %rcx
    4a39:      	movl	$0x4, %esi
    4a3e:      	movl	$0x4, %eax
    4a43:      	addq	0x88(%rsp), %rdx
    4a4b:      	movl	$0x4, %esi
    4a50:      	callq	*%rax
    4a52:      	leaq	0x5f50(%r14), %rdi
    4a59:      	movl	$0x98, %r12d
    4a5f:      	movq	0x90(%rsp), %rcx
    4a67:      	addq	%r12, %rcx
    4a6a:      	movl	$0x4, %edx
    4a6f:      	movl	$0x4, %eax
    4a74:      	movq	0x90(%rsp), %rdx
    4a7c:      	addq	%r12, %rdx
    4a7f:      	movl	$0x4, %esi
    4a84:      	callq	*%rax
    4a86:      	leaq	0x5f54(%r14), %rdi
    4a8d:      	movq	0x98(%rsp), %rcx
    4a95:      	addq	%r12, %rcx
    4a98:      	movl	$0x4, %edx
    4a9d:      	movl	$0x4, %eax
    4aa2:      	addq	0x98(%rsp), %r12
    4aaa:      	movl	$0x4, %esi
    4aaf:      	movq	%r12, %rdx
    4ab2:      	callq	*%rax
    4ab4:      	leaq	0x5f58(%r14), %rdi
    4abb:      	movq	0xa0(%rsp), %rcx
    4ac3:      	addq	$0x58, %rcx
    4ac7:      	movl	$0x4, %edx
    4acc:      	movl	$0x4, %eax
    4ad1:      	movq	0xa0(%rsp), %rdx
    4ad9:      	addq	$0x58, %rdx
    4add:      	movl	$0x4, %esi
    4ae2:      	callq	*%rax
    4ae4:      	movq	$0x0, 0x40(%rsp)
    4aed:      	movq	$0x0, 0x58(%rsp)
    4af6:      	leaq	0x40(%rsp), %rdi
    4afb:      	movl	$0x8, %ecx
    4b00:      	movl	$0x4, %eax
    4b05:      	movl	$0x8, %esi
    4b0a:      	movq	%r15, %rdx
    4b0d:      	callq	*%rax
    4b0f:      	movl	$0x90, %edx
    4b14:      	movq	0x40(%rsp), %rcx
    4b19:      	addq	%rdx, %rcx
    4b1c:      	leaq	0x58(%rsp), %rdi
    4b21:      	movl	$0x8, %esi
    4b26:      	movl	$0x4, %eax
    4b2b:      	addq	0x40(%rsp), %rdx
    4b30:      	movl	$0x8, %esi
    4b35:      	callq	*%rax
    4b37:      	leaq	0x5f5c(%r14), %rdi
    4b3e:      	movq	0x58(%rsp), %rcx
    4b43:      	addq	%rbx, %rcx
    4b46:      	movl	$0x4, %edx
    4b4b:      	movl	$0x4, %eax
    4b50:      	addq	0x58(%rsp), %rbx
    4b55:      	movl	$0x4, %esi
    4b5a:      	movq	%rbx, %rdx
    4b5d:      	callq	*%rax
    4b5f:      	cmpl	$0x1, 0x5f34(%r14)
    4b67:      	jne	0x4b71 <generic_fentry_process_filter+0x711>
    4b69:      	orb	$0x2, 0x5f33(%r14)
    4b71:      	leaq	0x5f78(%r14), %rdi
    4b78:      	movl	$0x308, %edx            # imm = 0x308
    4b7d:      	movq	%rdi, 0x8(%rsp)
    4b82:      	xorl	%esi, %esi
    4b84:      	callq	0x4b89 <generic_fentry_process_filter+0x729>
    4b89:      	leaq	0x6290(%r14), %rbp
    4b90:      	addq	$0xa78, %r13            # imm = 0xA78
    4b97:      	leaq	0x40(%rsp), %rdi
    4b9c:      	movl	$0x8, %ecx
    4ba1:      	movl	$0x4, %eax
    4ba6:      	movl	$0x8, %esi
    4bab:      	movq	%r13, %rdx
    4bae:      	callq	*%rax
    4bb0:      	movl	$0x5f8, %edx            # imm = 0x5F8
    4bb5:      	movq	0x40(%rsp), %rcx
    4bba:      	addq	%rdx, %rcx
    4bbd:      	leaq	0x60(%rsp), %rdi
    4bc2:      	movl	$0x8, %esi
    4bc7:      	movl	$0x4, %eax
    4bcc:      	addq	0x40(%rsp), %rdx
    4bd1:      	movl	$0x8, %esi
    4bd6:      	callq	*%rax
    4bd8:      	movq	0x60(%rsp), %rbx
    4bdd:      	movl	$0x0, 0xcc(%rsp)
    4be8:      	movq	(%rip), %rdi            # 0x4bef <generic_fentry_process_filter+0x78f>
    4bef:      	leaq	0xcc(%rsp), %rsi
    4bf7:      	movl	$0x1, %eax
    4bfc:      	callq	*%rax
    4bfe:      	testq	%rax, %rax
    4c01:      	je	0x5307 <generic_fentry_process_filter+0xea7>
    4c07:      	movq	%rax, %r12
    4c0a:      	movq	%rbp, 0x38(%rsp)
    4c0f:      	movl	$0x1000, 0x6410(%r14)   # imm = 0x1000
    4c1a:      	leaq	0x1000(%rax), %r13
    4c21:      	movl	$0x23, %eax
    4c26:      	callq	*%rax
    4c28:      	leaq	0xd50(%rax), %rdx
    4c2f:      	leaq	0xd8(%rsp), %rdi
    4c37:      	movl	$0x8, %ecx
    4c3c:      	movl	$0x4, %eax
    4c41:      	movl	$0x8, %esi
    4c46:      	callq	*%rax
    4c48:      	movq	0xd8(%rsp), %rbp
    4c50:      	leaq	0x48(%rbx), %r15
    4c54:      	leaq	0xe0(%rsp), %rdi
    4c5c:      	movl	$0x8, %ecx
    4c61:      	movl	$0x4, %eax
    4c66:      	movl	$0x8, %esi
    4c6b:      	movq	%r15, %rdx
    4c6e:      	callq	*%rax
    4c70:      	movq	0xe0(%rsp), %r14
    4c78:      	leaq	0x10(%r14), %rdx
    4c7c:      	leaq	0x60(%rsp), %rdi
    4c81:      	movl	$0x8, %ecx
    4c86:      	movl	$0x4, %eax
    4c8b:      	movl	$0x8, %esi
    4c90:      	callq	*%rax
    4c92:      	cmpq	$0x0, 0x60(%rsp)
    4c98:      	je	0x4f66 <generic_fentry_process_filter+0xb06>
    4c9e:      	movq	0x50(%rsp), %r14
    4ca3:      	movq	$0x0, 0x68(%rsp)
    4cac:      	movq	$0x0, 0x60(%rsp)
    4cb5:      	movq	%r12, 0x70(%rsp)
    4cba:      	movq	$0x0, 0x78(%rsp)
    4cc3:      	movq	$0x0, 0x80(%rsp)
    4ccf:      	movq	$0x0, 0x88(%rsp)
    4cdb:      	movq	%r13, 0xc0(%rsp)
    4ce3:      	movq	%r13, 0x90(%rsp)
    4ceb:      	movl	0x6410(%r14), %eax
    4cf2:      	movl	%eax, 0x98(%rsp)
    4cf9:      	leaq	0x18(%rbp), %r13
    4cfd:      	movb	$0x0, 0x9c(%rsp)
    4d05:      	addq	$0x20, %rbp
    4d09:      	leaq	0x60(%rsp), %rdi
    4d0e:      	movl	$0x8, %ecx
    4d13:      	movl	$0x4, %eax
    4d18:      	addq	$0x40, %rbx
    4d1c:      	leaq	0x68(%rsp), %r12
    4d21:      	leaq	0x78(%rsp), %r14
    4d26:      	movl	$0x8, %esi
    4d2b:      	movq	%rbp, %rdx
    4d2e:      	callq	*%rax
    4d30:      	movl	$0x8, %ecx
    4d35:      	movl	$0x4, %eax
    4d3a:      	movq	%r12, %rdi
    4d3d:      	movl	$0x8, %esi
    4d42:      	movq	%r13, %rdx
    4d45:      	callq	*%rax
    4d47:      	movl	$0x8, %ecx
    4d4c:      	movl	$0x4, %eax
    4d51:      	movq	%r14, %rdi
    4d54:      	movl	$0x8, %esi
    4d59:      	movq	%r15, %rdx
    4d5c:      	callq	*%rax
    4d5e:      	movl	$0x8, %ecx
    4d63:      	movl	$0x4, %eax
    4d68:      	leaq	0x80(%rsp), %rdi
    4d70:      	movl	$0x8, %esi
    4d75:      	movq	%rbx, %rdx
    4d78:      	callq	*%rax
    4d7a:      	movq	0x80(%rsp), %rax
    4d82:      	addq	$-0x20, %rax
    4d86:      	movq	%rax, 0x88(%rsp)
    4d8e:      	movq	(%rip), %rax            # 0x4d95 <generic_fentry_process_filter+0x935>
    4d95:      	cmpb	$0x0, (%rax)
    4d98:      	je	0x4fbd <generic_fentry_process_filter+0xb5d>
    4d9e:      	movl	$0x80, %r14d
    4da4:      	movl	$0x8, %ebp
    4da9:      	leaq	0x10(%rsp), %rbx
    4dae:      	nop
    4db0:      	movq	0x78(%rsp), %r15
    4db5:      	movq	0x80(%rsp), %rdx
    4dbd:      	movq	0x88(%rsp), %r12
    4dc5:      	cmpq	0x60(%rsp), %r15
    4dca:      	jne	0x4dd7 <generic_fentry_process_filter+0x977>
    4dcc:      	cmpq	0x68(%rsp), %rdx
    4dd1:      	je	0x517f <generic_fentry_process_filter+0xd1f>
    4dd7:      	movl	$0x4, %eax
    4ddc:      	leaq	0xa8(%rsp), %rdi
    4de4:      	movl	$0x8, %esi
    4de9:      	callq	*%rax
    4deb:      	cmpq	0xa8(%rsp), %r15
    4df3:      	je	0x4f00 <generic_fentry_process_filter+0xaa0>
    4df9:      	leaq	0x18(%r15), %r13
    4dfd:      	movl	$0x4, %eax
    4e02:      	movq	%rbx, %rdi
    4e05:      	movl	$0x8, %esi
    4e0a:      	movq	%r13, %rdx
    4e0d:      	callq	*%rax
    4e0f:      	cmpq	%r15, 0x10(%rsp)
    4e14:      	je	0x4f00 <generic_fentry_process_filter+0xaa0>
    4e1a:      	movl	$0x4, %eax
    4e1f:      	leaq	0x58(%rsp), %rdi
    4e24:      	movl	$0x8, %esi
    4e29:      	movq	%r13, %rdx
    4e2c:      	callq	*%rax
    4e2e:      	addq	$0x20, %r15
    4e32:      	movl	$0x4, %eax
    4e37:      	leaq	0x40(%rsp), %rdi
    4e3c:      	movl	$0x10, %ecx
    4e41:      	movl	$0x10, %esi
    4e46:      	movq	%r15, %rdx
    4e49:      	callq	*%rax
    4e4b:      	movq	0x70(%rsp), %r15
    4e50:      	movq	0x90(%rsp), %rax
    4e58:      	movl	0x44(%rsp), %r12d
    4e5d:      	subq	%r15, %rax
    4e60:      	movl	0x98(%rsp), %r13d
    4e68:      	movl	%r12d, %edx
    4e6b:      	subl	%r13d, %edx
    4e6e:      	movl	$0x0, %ecx
    4e73:      	cmovbl	%ecx, %edx
    4e76:      	addq	0x48(%rsp), %rdx
    4e7b:      	xorl	%esi, %esi
    4e7d:      	cmpl	%r12d, %r13d
    4e80:      	seta	%sil
    4e84:      	movl	%r12d, %ecx
    4e87:      	cmovbl	%r13d, %ecx
    4e8b:      	addl	%ecx, %esi
    4e8d:      	movl	%r13d, %edi
    4e90:      	subl	%esi, %edi
    4e92:      	movl	%edi, 0x98(%rsp)
    4e99:      	subq	%rsi, %rax
    4e9c:      	jb	0x5187 <generic_fentry_process_filter+0xd27>
    4ea2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    4ea8:      	ja	0x5187 <generic_fentry_process_filter+0xd27>
    4eae:      	cmpl	%r12d, %r13d
    4eb1:      	jbe	0x4eb8 <generic_fentry_process_filter+0xa58>
    4eb3:      	movb	$0x2f, (%r15,%rax)
    4eb8:      	xorl	%edi, %edi
    4eba:      	cmpl	%r12d, %r13d
    4ebd:      	seta	%dil
    4ec1:      	movzbl	%cl, %esi
    4ec4:      	addq	%rax, %r15
    4ec7:      	addq	%r15, %rdi
    4eca:      	movl	$0x4, %eax
    4ecf:      	callq	*%rax
    4ed1:      	movq	%r15, 0x90(%rsp)
    4ed9:      	cmpl	%r12d, %r13d
    4edc:      	jbe	0x5187 <generic_fentry_process_filter+0xd27>
    4ee2:      	movq	0x58(%rsp), %rax
    4ee7:      	movq	%rax, 0x78(%rsp)
    4eec:      	decl	%r14d
    4eef:      	jne	0x4db0 <generic_fentry_process_filter+0x950>
    4ef5:      	jmp	0x5187 <generic_fentry_process_filter+0xd27>
    4efa:      	nopw	(%rax,%rax)
    4f00:      	leaq	0x10(%r12), %rdx
    4f05:      	movl	$0x4, %eax
    4f0a:      	movq	%rbx, %rdi
    4f0d:      	movl	$0x8, %esi
    4f12:      	callq	*%rax
    4f14:      	movq	0x88(%rsp), %rax
    4f1c:      	cmpq	0x10(%rsp), %rax
    4f21:      	je	0x517f <generic_fentry_process_filter+0xd1f>
    4f27:      	addq	$0x18, %r12
    4f2b:      	movl	$0x4, %eax
    4f30:      	leaq	0x78(%rsp), %rdi
    4f35:      	movl	$0x8, %esi
    4f3a:      	movq	%r12, %rdx
    4f3d:      	callq	*%rax
    4f3f:      	movq	0x10(%rsp), %rax
    4f44:      	movq	%rax, 0x88(%rsp)
    4f4c:      	addq	$0x20, %rax
    4f50:      	movq	%rax, 0x80(%rsp)
    4f58:      	decl	%r14d
    4f5b:      	jne	0x4db0 <generic_fentry_process_filter+0x950>
    4f61:      	jmp	0x5187 <generic_fentry_process_filter+0xd27>
    4f66:      	leaq	0x18(%r14), %rdx
    4f6a:      	leaq	0x60(%rsp), %rdi
    4f6f:      	movl	$0x8, %ecx
    4f74:      	movl	$0x4, %eax
    4f79:      	movl	$0x8, %esi
    4f7e:      	callq	*%rax
    4f80:      	cmpq	%r14, 0x60(%rsp)
    4f85:      	je	0x4c9e <generic_fentry_process_filter+0x83e>
    4f8b:      	movq	0x50(%rsp), %r14
    4f90:      	movl	0x6410(%r14), %ecx
    4f97:      	leal	-0xa(%rcx), %eax
    4f9a:      	movl	%eax, 0x6410(%r14)
    4fa1:      	cmpl	$0x9, %ecx
    4fa4:      	jg	0x5944 <generic_fentry_process_filter+0x14e4>
    4faa:      	movl	$0xffffffdc, 0x6414(%r14) # imm = 0xFFFFFFDC
    4fb5:      	movq	%r13, %rbx
    4fb8:      	jmp	0x5208 <generic_fentry_process_filter+0xda8>
    4fbd:      	movl	$0x80, %r14d
    4fc3:      	movl	$0x8, %ebp
    4fc8:      	leaq	0x10(%rsp), %rbx
    4fcd:      	nopl	(%rax)
    4fd0:      	movq	0x78(%rsp), %r15
    4fd5:      	movq	0x80(%rsp), %rdx
    4fdd:      	movq	0x88(%rsp), %r12
    4fe5:      	cmpq	0x60(%rsp), %r15
    4fea:      	jne	0x4ff7 <generic_fentry_process_filter+0xb97>
    4fec:      	cmpq	0x68(%rsp), %rdx
    4ff1:      	je	0x517f <generic_fentry_process_filter+0xd1f>
    4ff7:      	movl	$0x4, %eax
    4ffc:      	leaq	0xa8(%rsp), %rdi
    5004:      	movl	$0x8, %esi
    5009:      	callq	*%rax
    500b:      	cmpq	0xa8(%rsp), %r15
    5013:      	je	0x5120 <generic_fentry_process_filter+0xcc0>
    5019:      	leaq	0x18(%r15), %r13
    501d:      	movl	$0x4, %eax
    5022:      	movq	%rbx, %rdi
    5025:      	movl	$0x8, %esi
    502a:      	movq	%r13, %rdx
    502d:      	callq	*%rax
    502f:      	cmpq	%r15, 0x10(%rsp)
    5034:      	je	0x5120 <generic_fentry_process_filter+0xcc0>
    503a:      	movl	$0x4, %eax
    503f:      	leaq	0x58(%rsp), %rdi
    5044:      	movl	$0x8, %esi
    5049:      	movq	%r13, %rdx
    504c:      	callq	*%rax
    504e:      	addq	$0x20, %r15
    5052:      	movl	$0x4, %eax
    5057:      	leaq	0x40(%rsp), %rdi
    505c:      	movl	$0x10, %ecx
    5061:      	movl	$0x10, %esi
    5066:      	movq	%r15, %rdx
    5069:      	callq	*%rax
    506b:      	movq	0x70(%rsp), %r15
    5070:      	movq	0x90(%rsp), %rax
    5078:      	movl	0x44(%rsp), %r12d
    507d:      	subq	%r15, %rax
    5080:      	movl	0x98(%rsp), %r13d
    5088:      	movl	%r12d, %edx
    508b:      	subl	%r13d, %edx
    508e:      	movl	$0x0, %ecx
    5093:      	cmovbl	%ecx, %edx
    5096:      	addq	0x48(%rsp), %rdx
    509b:      	xorl	%esi, %esi
    509d:      	cmpl	%r12d, %r13d
    50a0:      	seta	%sil
    50a4:      	movl	%r12d, %ecx
    50a7:      	cmovbl	%r13d, %ecx
    50ab:      	addl	%ecx, %esi
    50ad:      	movl	%r13d, %edi
    50b0:      	subl	%esi, %edi
    50b2:      	movl	%edi, 0x98(%rsp)
    50b9:      	subq	%rsi, %rax
    50bc:      	jb	0x5187 <generic_fentry_process_filter+0xd27>
    50c2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    50c8:      	ja	0x5187 <generic_fentry_process_filter+0xd27>
    50ce:      	cmpl	%r12d, %r13d
    50d1:      	jbe	0x50d8 <generic_fentry_process_filter+0xc78>
    50d3:      	movb	$0x2f, (%r15,%rax)
    50d8:      	xorl	%edi, %edi
    50da:      	cmpl	%r12d, %r13d
    50dd:      	seta	%dil
    50e1:      	movzbl	%cl, %esi
    50e4:      	addq	%rax, %r15
    50e7:      	addq	%r15, %rdi
    50ea:      	movl	$0x4, %eax
    50ef:      	callq	*%rax
    50f1:      	movq	%r15, 0x90(%rsp)
    50f9:      	cmpl	%r12d, %r13d
    50fc:      	jbe	0x5187 <generic_fentry_process_filter+0xd27>
    5102:      	movq	0x58(%rsp), %rax
    5107:      	movq	%rax, 0x78(%rsp)
    510c:      	decl	%r14d
    510f:      	jne	0x4fd0 <generic_fentry_process_filter+0xb70>
    5115:      	jmp	0x5187 <generic_fentry_process_filter+0xd27>
    5117:      	nopw	(%rax,%rax)
    5120:      	leaq	0x10(%r12), %rdx
    5125:      	movl	$0x4, %eax
    512a:      	movq	%rbx, %rdi
    512d:      	movl	$0x8, %esi
    5132:      	callq	*%rax
    5134:      	movq	0x88(%rsp), %rax
    513c:      	cmpq	0x10(%rsp), %rax
    5141:      	je	0x517f <generic_fentry_process_filter+0xd1f>
    5143:      	addq	$0x18, %r12
    5147:      	movl	$0x4, %eax
    514c:      	leaq	0x78(%rsp), %rdi
    5151:      	movl	$0x8, %esi
    5156:      	movq	%r12, %rdx
    5159:      	callq	*%rax
    515b:      	movq	0x10(%rsp), %rax
    5160:      	movq	%rax, 0x88(%rsp)
    5168:      	addq	$0x20, %rax
    516c:      	movq	%rax, 0x80(%rsp)
    5174:      	decl	%r14d
    5177:      	jne	0x4fd0 <generic_fentry_process_filter+0xb70>
    517d:      	jmp	0x5187 <generic_fentry_process_filter+0xd27>
    517f:      	movb	$0x1, 0x9c(%rsp)
    5187:      	movq	0x90(%rsp), %rbx
    518f:      	movq	0xc0(%rsp), %rcx
    5197:      	cmpq	%rcx, %rbx
    519a:      	je	0x51e8 <generic_fentry_process_filter+0xd88>
    519c:      	xorl	%ecx, %ecx
    519e:      	cmpb	$0x0, 0x9c(%rsp)
    51a6:      	sete	%cl
    51a9:      	addl	%ecx, %ecx
    51ab:      	movl	0x98(%rsp), %eax
    51b2:      	movq	0x50(%rsp), %r14
    51b7:      	movl	%eax, 0x6410(%r14)
    51be:      	movl	%ecx, 0x6414(%r14)
    51c5:      	testl	%eax, %eax
    51c7:      	movq	0x38(%rsp), %rbp
    51cc:      	jle	0x51de <generic_fentry_process_filter+0xd7e>
    51ce:      	movl	$0x1000, %ecx           # imm = 0x1000
    51d3:      	subl	%eax, %ecx
    51d5:      	movl	%ecx, 0x6410(%r14)
    51dc:      	movl	%ecx, %eax
    51de:      	testq	%rbx, %rbx
    51e1:      	jne	0x520d <generic_fentry_process_filter+0xdad>
    51e3:      	jmp	0x5307 <generic_fentry_process_filter+0xea7>
    51e8:      	movq	0x50(%rsp), %r14
    51ed:      	movl	$0x0, 0x6410(%r14)
    51f8:      	movl	$0x0, 0x6414(%r14)
    5203:      	xorl	%eax, %eax
    5205:      	movq	%rcx, %rbx
    5208:      	movq	0x38(%rsp), %rbp
    520d:      	xorl	%ecx, %ecx
    520f:      	movq	%r14, %rdx
    5212:      	movl	%eax, %r14d
    5215:      	subl	$0x7f, %r14d
    5219:      	movl	$0x7f, %r15d
    521f:      	cmovbl	%eax, %r15d
    5223:      	cmovbl	%ecx, %r14d
    5227:      	cmpl	$0xff, %eax
    522c:      	movl	$0xff, %ecx
    5231:      	cmovbl	%eax, %ecx
    5234:      	movzbl	%cl, %esi
    5237:      	movl	%esi, 0x6410(%rdx)
    523d:      	movl	$0x4, %eax
    5242:      	movq	%rbp, %rdi
    5245:      	movq	%rbx, %rdx
    5248:      	callq	*%rax
    524a:      	testq	%rax, %rax
    524d:      	je	0x52ac <generic_fentry_process_filter+0xe4c>
    524f:      	negl	%eax
    5251:      	movw	%ax, 0x60(%rsp)
    5256:      	movw	$0x8, 0x62(%rsp)
    525d:      	movabsq	$0x4000002de, %rax      # imm = 0x4000002DE
    5267:      	movq	%rax, 0x64(%rsp)
    526c:      	movq	(%rip), %rdi            # 0x5273 <generic_fentry_process_filter+0xe13>
    5273:      	leaq	0x60(%rsp), %rsi
    5278:      	movl	$0x1, %eax
    527d:      	callq	*%rax
    527f:      	testq	%rax, %rax
    5282:      	je	0x5288 <generic_fentry_process_filter+0xe28>
    5284:      	incl	(%rax)
    5286:      	jmp	0x52ac <generic_fentry_process_filter+0xe4c>
    5288:      	movl	$0x1, 0x40(%rsp)
    5290:      	movq	(%rip), %rdi            # 0x5297 <generic_fentry_process_filter+0xe37>
    5297:      	xorl	%ecx, %ecx
    5299:      	leaq	0x60(%rsp), %rsi
    529e:      	leaq	0x40(%rsp), %rdx
    52a3:      	movl	$0x2, %eax
    52a8:      	xorl	%ecx, %ecx
    52aa:      	callq	*%rax
    52ac:      	movq	0x50(%rsp), %rax
    52b1:      	leaq	0x6390(%rax), %rdi
    52b8:      	addq	%r14, %rbx
    52bb:      	movq	%rax, %r14
    52be:      	movl	$0x4, %eax
    52c3:      	movl	%r15d, %esi
    52c6:      	movq	%rbx, %rdx
    52c9:      	callq	*%rax
    52cb:      	testq	%rax, %rax
    52ce:      	je	0x5307 <generic_fentry_process_filter+0xea7>
    52d0:      	negl	%eax
    52d2:      	movw	%ax, 0x60(%rsp)
    52d7:      	movw	$0x8, 0x62(%rsp)
    52de:      	movabsq	$0x4000002e0, %rax      # imm = 0x4000002E0
    52e8:      	movq	%rax, 0x64(%rsp)
    52ed:      	movq	(%rip), %rdi            # 0x52f4 <generic_fentry_process_filter+0xe94>
    52f4:      	leaq	0x60(%rsp), %rsi
    52f9:      	movl	$0x1, %eax
    52fe:      	callq	*%rax
    5300:      	testq	%rax, %rax
    5303:      	je	0x5334 <generic_fentry_process_filter+0xed4>
    5305:      	incl	(%rax)
    5307:      	movl	0x6410(%r14), %eax
    530e:      	leal	-0x101(%rax), %ecx
    5314:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    531a:      	ja	0x536d <generic_fentry_process_filter+0xf0d>
    531c:      	movq	0x8(%rsp), %rax
    5321:      	movl	$0xffffffff, (%rax)     # imm = 0xFFFFFFFF
    5327:      	movq	0xb8(%rsp), %rbx
    532f:      	jmp	0x5483 <generic_fentry_process_filter+0x1023>
    5334:      	movl	$0x1, 0x40(%rsp)
    533c:      	movq	(%rip), %rdi            # 0x5343 <generic_fentry_process_filter+0xee3>
    5343:      	xorl	%ecx, %ecx
    5345:      	leaq	0x60(%rsp), %rsi
    534a:      	leaq	0x40(%rsp), %rdx
    534f:      	movl	$0x2, %eax
    5354:      	xorl	%ecx, %ecx
    5356:      	callq	*%rax
    5358:      	movl	0x6410(%r14), %eax
    535f:      	leal	-0x101(%rax), %ecx
    5365:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    536b:      	jbe	0x531c <generic_fentry_process_filter+0xebc>
    536d:      	movzbl	%al, %ebx
    5370:      	leaq	0x5f80(%r14), %rdi
    5377:      	movl	$0x4, %eax
    537c:      	movl	%ebx, %esi
    537e:      	movq	%rbp, %rdx
    5381:      	callq	*%rax
    5383:      	movq	%rax, %r15
    5386:      	testq	%rax, %rax
    5389:      	je	0x53eb <generic_fentry_process_filter+0xf8b>
    538b:      	movl	%r15d, %eax
    538e:      	negl	%eax
    5390:      	movw	%ax, 0x60(%rsp)
    5395:      	movw	$0xf, 0x62(%rsp)
    539c:      	movabsq	$0x400000164, %rax      # imm = 0x400000164
    53a6:      	movq	%rax, 0x64(%rsp)
    53ab:      	movq	(%rip), %rdi            # 0x53b2 <generic_fentry_process_filter+0xf52>
    53b2:      	leaq	0x60(%rsp), %rsi
    53b7:      	movl	$0x1, %eax
    53bc:      	callq	*%rax
    53be:      	testq	%rax, %rax
    53c1:      	je	0x53c7 <generic_fentry_process_filter+0xf67>
    53c3:      	incl	(%rax)
    53c5:      	jmp	0x53eb <generic_fentry_process_filter+0xf8b>
    53c7:      	movl	$0x1, 0x40(%rsp)
    53cf:      	movq	(%rip), %rdi            # 0x53d6 <generic_fentry_process_filter+0xf76>
    53d6:      	xorl	%ecx, %ecx
    53d8:      	leaq	0x60(%rsp), %rsi
    53dd:      	leaq	0x40(%rsp), %rdx
    53e2:      	movl	$0x2, %eax
    53e7:      	xorl	%ecx, %ecx
    53e9:      	callq	*%rax
    53eb:      	testl	%r15d, %r15d
    53ee:      	cmovel	%ebx, %r15d
    53f2:      	movl	%r15d, 0x5f78(%r14)
    53f9:      	cmpl	$0x7f, %ebx
    53fc:      	movl	$0x7f, %esi
    5401:      	cmovbl	%ebx, %esi
    5404:      	leaq	0x6080(%r14), %rdi
    540b:      	leaq	0x6390(%r14), %rdx
    5412:      	movl	$0x4, %eax
    5417:      	callq	*%rax
    5419:      	testq	%rax, %rax
    541c:      	movq	0xb8(%rsp), %rbx
    5424:      	je	0x5483 <generic_fentry_process_filter+0x1023>
    5426:      	negl	%eax
    5428:      	movw	%ax, 0x60(%rsp)
    542d:      	movw	$0xf, 0x62(%rsp)
    5434:      	movabsq	$0x40000016a, %rax      # imm = 0x40000016A
    543e:      	movq	%rax, 0x64(%rsp)
    5443:      	movq	(%rip), %rdi            # 0x544a <generic_fentry_process_filter+0xfea>
    544a:      	leaq	0x60(%rsp), %rsi
    544f:      	movl	$0x1, %eax
    5454:      	callq	*%rax
    5456:      	testq	%rax, %rax
    5459:      	je	0x545f <generic_fentry_process_filter+0xfff>
    545b:      	incl	(%rax)
    545d:      	jmp	0x5483 <generic_fentry_process_filter+0x1023>
    545f:      	movl	$0x1, 0x40(%rsp)
    5467:      	movq	(%rip), %rdi            # 0x546e <generic_fentry_process_filter+0x100e>
    546e:      	xorl	%ecx, %ecx
    5470:      	leaq	0x60(%rsp), %rsi
    5475:      	leaq	0x40(%rsp), %rdx
    547a:      	movl	$0x2, %eax
    547f:      	xorl	%ecx, %ecx
    5481:      	callq	*%rax
    5483:      	leaq	0x5f10(%r14), %r15
    548a:      	orb	$0x10, 0x1(%r14)
    548f:      	leaq	0x5ef8(%r14), %rsi
    5496:      	movq	(%rip), %rdi            # 0x549d <generic_fentry_process_filter+0x103d>
    549d:      	movl	$0x1, %eax
    54a2:      	callq	*%rax
    54a4:      	testq	%rax, %rax
    54a7:      	je	0x6a83 <generic_fentry_process_filter+0x2623>
    54ad:      	movq	0x5eb8(%r14), %r13
    54b4:      	cmpq	$0x6, %r13
    54b8:      	jae	0x56e6 <generic_fentry_process_filter+0x1286>
    54be:      	movslq	(%rax), %rcx
    54c1:      	testq	%rcx, %rcx
    54c4:      	je	0x5708 <generic_fentry_process_filter+0x12a8>
    54ca:      	cmpq	%rcx, %r13
    54cd:      	jae	0x56e6 <generic_fentry_process_filter+0x1286>
    54d3:      	movq	%rax, 0x8(%rsp)
    54d8:      	movq	%rcx, 0xc0(%rsp)
    54e0:      	movq	%rbx, 0xb8(%rsp)
    54e8:      	movl	%r13d, 0x10(%rsp)
    54ed:      	movl	$0x0, 0x58(%rsp)
    54f5:      	movq	(%rip), %rdi            # 0x54fc <generic_fentry_process_filter+0x109c>
    54fc:      	leaq	0x10(%rsp), %rsi
    5501:      	movl	$0x1, %eax
    5506:      	callq	*%rax
    5508:      	testq	%rax, %rax
    550b:      	movq	%r15, 0x38(%rsp)
    5510:      	je	0x5724 <generic_fentry_process_filter+0x12c4>
    5516:      	movq	%rax, %rbx
    5519:      	movl	(%rax), %eax
    551b:      	testl	%eax, %eax
    551d:      	je	0x5724 <generic_fentry_process_filter+0x12c4>
    5523:      	cmpl	$0x0, 0x68(%r15)
    5528:      	js	0x6a2b <generic_fentry_process_filter+0x25cb>
    552e:      	cmpl	$0x1b, %eax
    5531:      	ja	0x6a2b <generic_fentry_process_filter+0x25cb>
    5537:      	movl	$0x60, %ecx
    553c:      	btl	%eax, %ecx
    553f:      	jb	0x61bc <generic_fentry_process_filter+0x1d5c>
    5545:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    554a:      	btl	%eax, %ecx
    554d:      	jb	0x6129 <generic_fentry_process_filter+0x1cc9>
    5553:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    5558:      	btl	%eax, %ecx
    555b:      	jae	0x6a2b <generic_fentry_process_filter+0x25cb>
    5561:      	movq	%rbx, %rsi
    5564:      	addq	$0x4, %rsi
    5568:      	movq	(%rip), %rdi            # 0x556f <generic_fentry_process_filter+0x110f>
    556f:      	movl	$0x1, %eax
    5574:      	callq	*%rax
    5576:      	testq	%rax, %rax
    5579:      	je	0x6a2b <generic_fentry_process_filter+0x25cb>
    557f:      	movq	%rax, %r12
    5582:      	movq	0x38(%rsp), %rax
    5587:      	movl	0x68(%rax), %eax
    558a:      	cmpl	$0x7f, %eax
    558d:      	movl	$0x7f, %r14d
    5593:      	cmovll	%eax, %r14d
    5597:      	movq	(%rip), %rdi            # 0x559e <generic_fentry_process_filter+0x113e>
    559e:      	leaq	0x58(%rsp), %rsi
    55a3:      	movl	$0x1, %eax
    55a8:      	callq	*%rax
    55aa:      	testq	%rax, %rax
    55ad:      	je	0x6a2b <generic_fentry_process_filter+0x25cb>
    55b3:      	movq	%rax, %rbp
    55b6:      	leal	(,%r14,8), %eax
    55be:      	movl	%eax, (%rbp)
    55c1:      	movq	0x38(%rsp), %rax
    55c6:      	cmpl	$0x0, 0x6c(%rax)
    55ca:      	jne	0x56ad <generic_fentry_process_filter+0x124d>
    55d0:      	movq	0x38(%rsp), %r15
    55d5:      	movl	0x68(%r15), %ecx
    55d9:      	movl	%ecx, %eax
    55db:      	subl	%r14d, %eax
    55de:      	movl	%r14d, %edx
    55e1:      	andl	$0x7f, %edx
    55e4:      	addl	%edx, %eax
    55e6:      	addl	%ecx, %edx
    55e8:      	movl	%r14d, %ecx
    55eb:      	notl	%ecx
    55ed:      	addl	%edx, %ecx
    55ef:      	subl	%r14d, %edx
    55f2:      	leal	-0x4(%rdx), %esi
    55f5:      	leaq	0x1f3(%r15), %rdi
    55fc:      	leal	-0x3(%rdx), %r8d
    5600:      	addl	$-0x2, %edx
    5603:      	movq	$-0x3, %r9
    560a:      	leal	(%rcx,%r9), %r10d
    560e:      	addl	$0x3, %r10d
    5612:      	andl	$0x7f, %r10d
    5616:      	movzbl	0x170(%r15,%r10), %r10d
    561f:      	movb	%r10b, -0x3(%rdi)
    5623:      	leaq	(%rax,%r9), %r10
    5627:      	cmpq	$-0x2, %r10
    562b:      	je	0x56a5 <generic_fentry_process_filter+0x1245>
    562d:      	leal	(%rdx,%r9), %r11d
    5631:      	addl	$0x3, %r11d
    5635:      	andl	$0x7f, %r11d
    5639:      	movzbl	0x170(%r15,%r11), %r11d
    5642:      	movb	%r11b, -0x2(%rdi)
    5646:      	cmpq	$-0x1, %r10
    564a:      	je	0x56a5 <generic_fentry_process_filter+0x1245>
    564c:      	leal	(%r8,%r9), %r10d
    5650:      	addl	$0x3, %r10d
    5654:      	andl	$0x7f, %r10d
    5658:      	movzbl	0x170(%r15,%r10), %r10d
    5661:      	movb	%r10b, -0x1(%rdi)
    5665:      	movq	%rax, %r10
    5668:      	addq	%r9, %r10
    566b:      	je	0x56a5 <generic_fentry_process_filter+0x1245>
    566d:      	cmpq	$-0x7f, %r9
    5671:      	je	0x56a5 <generic_fentry_process_filter+0x1245>
    5673:      	leal	(%rsi,%r9), %r10d
    5677:      	addl	$0x3, %r10d
    567b:      	andl	$0x7f, %r10d
    567f:      	movzbl	0x170(%r15,%r10), %r10d
    5688:      	movb	%r10b, (%rdi)
    568b:      	addq	$0x4, %rdi
    568f:      	leaq	(%rax,%r9), %r10
    5693:      	addq	$-0x4, %r10
    5697:      	addq	$-0x4, %r9
    569b:      	cmpq	$-0x3, %r10
    569f:      	jne	0x560a <generic_fentry_process_filter+0x11aa>
    56a5:      	movl	$0x1, 0x6c(%r15)
    56ad:      	cmpl	$0x7f, %r14d
    56b1:      	ja	0x56d9 <generic_fentry_process_filter+0x1279>
    56b3:      	movslq	%r14d, %rsi
    56b6:      	movq	%rbp, %rdi
    56b9:      	addq	$0x4, %rdi
    56bd:      	movq	0x38(%rsp), %rax
    56c2:      	leaq	0x1f0(%rax), %rdx
    56c9:      	movl	$0x4, %eax
    56ce:      	callq	*%rax
    56d0:      	testq	%rax, %rax
    56d3:      	js	0x6a2b <generic_fentry_process_filter+0x25cb>
    56d9:      	movl	$0x1, %eax
    56de:      	movq	%r12, %rdi
    56e1:      	jmp	0x61b4 <generic_fentry_process_filter+0x1d54>
    56e6:      	movl	(%r15), %eax
    56e9:      	movl	%eax, 0x10(%r14)
    56ed:      	movq	0x8(%r15), %rax
    56f1:      	movq	%rax, 0x18(%r14)
    56f5:      	cmpb	$0x0, 0x5ec0(%r14)
    56fd:      	jne	0x6a6e <generic_fentry_process_filter+0x260e>
    5703:      	jmp	0x6a83 <generic_fentry_process_filter+0x2623>
    5708:      	movb	$0x1, 0x5ec0(%r14)
    5710:      	movl	(%r15), %eax
    5713:      	movl	%eax, 0x10(%r14)
    5717:      	movq	0x8(%r15), %rax
    571b:      	movq	%rax, 0x18(%r14)
    571f:      	jmp	0x6a6e <generic_fentry_process_filter+0x260e>
    5724:      	movq	0x8(%rsp), %r10
    5729:      	movq	(%rip), %rax            # 0x5730 <generic_fentry_process_filter+0x12d0>
    5730:      	cmpb	$0x0, (%rax)
    5733:      	je	0x5975 <generic_fentry_process_filter+0x1515>
    5739:      	movq	(%rip), %rdi            # 0x5740 <generic_fentry_process_filter+0x12e0>
    5740:      	movl	$0x1, %eax
    5745:      	movq	0x38(%rsp), %rsi
    574a:      	callq	*%rax
    574c:      	movq	0x8(%rsp), %r10
    5751:      	testq	%rax, %rax
    5754:      	je	0x5975 <generic_fentry_process_filter+0x1515>
    575a:      	movq	%rax, %rbp
    575d:      	leal	0x5(%r13), %eax
    5761:      	movl	%eax, 0x10(%rsp)
    5765:      	movl	$0x0, 0x58(%rsp)
    576d:      	movq	(%rip), %rdi            # 0x5774 <generic_fentry_process_filter+0x1314>
    5774:      	leaq	0x10(%rsp), %rsi
    5779:      	movl	$0x1, %eax
    577e:      	callq	*%rax
    5780:      	testq	%rax, %rax
    5783:      	je	0x5970 <generic_fentry_process_filter+0x1510>
    5789:      	movq	%rax, %r12
    578c:      	movl	(%rax), %eax
    578e:      	testl	%eax, %eax
    5790:      	je	0x5970 <generic_fentry_process_filter+0x1510>
    5796:      	cmpl	$0x0, (%rbp)
    579a:      	js	0x6a2b <generic_fentry_process_filter+0x25cb>
    57a0:      	cmpl	$0x1b, %eax
    57a3:      	ja	0x6a2b <generic_fentry_process_filter+0x25cb>
    57a9:      	movl	$0x60, %ecx
    57ae:      	btl	%eax, %ecx
    57b1:      	jb	0x6418 <generic_fentry_process_filter+0x1fb8>
    57b7:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    57bc:      	btl	%eax, %ecx
    57bf:      	jb	0x6388 <generic_fentry_process_filter+0x1f28>
    57c5:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    57ca:      	btl	%eax, %ecx
    57cd:      	jae	0x6a2b <generic_fentry_process_filter+0x25cb>
    57d3:      	movq	%r12, %rsi
    57d6:      	addq	$0x4, %rsi
    57da:      	movq	(%rip), %rdi            # 0x57e1 <generic_fentry_process_filter+0x1381>
    57e1:      	movl	$0x1, %eax
    57e6:      	callq	*%rax
    57e8:      	testq	%rax, %rax
    57eb:      	je	0x6a2b <generic_fentry_process_filter+0x25cb>
    57f1:      	movq	%rax, %r15
    57f4:      	movl	(%rbp), %eax
    57f7:      	cmpl	$0x7f, %eax
    57fa:      	movl	$0x7f, %r14d
    5800:      	cmovll	%eax, %r14d
    5804:      	movq	(%rip), %rdi            # 0x580b <generic_fentry_process_filter+0x13ab>
    580b:      	leaq	0x58(%rsp), %rsi
    5810:      	movl	$0x1, %eax
    5815:      	callq	*%rax
    5817:      	testq	%rax, %rax
    581a:      	je	0x6a2b <generic_fentry_process_filter+0x25cb>
    5820:      	movq	%rax, %rbx
    5823:      	leal	(,%r14,8), %eax
    582b:      	movl	%eax, (%rbx)
    582d:      	cmpl	$0x0, 0x4(%rbp)
    5831:      	jne	0x590d <generic_fentry_process_filter+0x14ad>
    5837:      	movl	(%rbp), %ecx
    583a:      	movl	%ecx, %eax
    583c:      	subl	%r14d, %eax
    583f:      	movl	%r14d, %edx
    5842:      	andl	$0x7f, %edx
    5845:      	addl	%edx, %eax
    5847:      	addl	%ecx, %edx
    5849:      	movl	%r14d, %ecx
    584c:      	notl	%ecx
    584e:      	addl	%edx, %ecx
    5850:      	subl	%r14d, %edx
    5853:      	leal	-0x4(%rdx), %esi
    5856:      	leaq	0x18b(%rbp), %rdi
    585d:      	leal	-0x3(%rdx), %r8d
    5861:      	addl	$-0x2, %edx
    5864:      	movq	$-0x3, %r9
    586b:      	leal	(%rcx,%r9), %r10d
    586f:      	addl	$0x3, %r10d
    5873:      	andl	$0x7f, %r10d
    5877:      	movzbl	0x108(%rbp,%r10), %r10d
    5880:      	movb	%r10b, -0x3(%rdi)
    5884:      	leaq	(%rax,%r9), %r10
    5888:      	cmpq	$-0x2, %r10
    588c:      	je	0x5906 <generic_fentry_process_filter+0x14a6>
    588e:      	leal	(%rdx,%r9), %r11d
    5892:      	addl	$0x3, %r11d
    5896:      	andl	$0x7f, %r11d
    589a:      	movzbl	0x108(%rbp,%r11), %r11d
    58a3:      	movb	%r11b, -0x2(%rdi)
    58a7:      	cmpq	$-0x1, %r10
    58ab:      	je	0x5906 <generic_fentry_process_filter+0x14a6>
    58ad:      	leal	(%r8,%r9), %r10d
    58b1:      	addl	$0x3, %r10d
    58b5:      	andl	$0x7f, %r10d
    58b9:      	movzbl	0x108(%rbp,%r10), %r10d
    58c2:      	movb	%r10b, -0x1(%rdi)
    58c6:      	movq	%rax, %r10
    58c9:      	addq	%r9, %r10
    58cc:      	je	0x5906 <generic_fentry_process_filter+0x14a6>
    58ce:      	cmpq	$-0x7f, %r9
    58d2:      	je	0x5906 <generic_fentry_process_filter+0x14a6>
    58d4:      	leal	(%rsi,%r9), %r10d
    58d8:      	addl	$0x3, %r10d
    58dc:      	andl	$0x7f, %r10d
    58e0:      	movzbl	0x108(%rbp,%r10), %r10d
    58e9:      	movb	%r10b, (%rdi)
    58ec:      	addq	$0x4, %rdi
    58f0:      	leaq	(%rax,%r9), %r10
    58f4:      	addq	$-0x4, %r10
    58f8:      	addq	$-0x4, %r9
    58fc:      	cmpq	$-0x3, %r10
    5900:      	jne	0x586b <generic_fentry_process_filter+0x140b>
    5906:      	movl	$0x1, 0x4(%rbp)
    590d:      	cmpl	$0x7f, %r14d
    5911:      	ja	0x5937 <generic_fentry_process_filter+0x14d7>
    5913:      	movslq	%r14d, %rsi
    5916:      	movq	%rbx, %rdi
    5919:      	addq	$0x4, %rdi
    591d:      	addq	$0x188, %rbp            # imm = 0x188
    5924:      	movl	$0x4, %eax
    5929:      	movq	%rbp, %rdx
    592c:      	callq	*%rax
    592e:      	testq	%rax, %rax
    5931:      	js	0x6a2b <generic_fentry_process_filter+0x25cb>
    5937:      	movl	$0x1, %eax
    593c:      	movq	%r15, %rdi
    593f:      	jmp	0x6410 <generic_fentry_process_filter+0x1fb0>
    5944:      	movq	%r12, %r13
    5947:      	addq	$0xff6, %r13            # imm = 0xFF6
    594e:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    5958:      	movq	%rax, 0xff6(%r12)
    5960:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
    596b:      	jmp	0x4ca3 <generic_fentry_process_filter+0x843>
    5970:      	movq	0x8(%rsp), %r10
    5975:      	movl	%r13d, %eax
    5978:      	leaq	0x4(,%rax,4), %rcx
    5980:      	movl	0x4(%r10,%rax,4), %eax
    5985:      	leal	(%rax,%rcx), %r14d
    5989:      	andl	$0x3ff, %r14d           # imm = 0x3FF
    5990:      	addl	%eax, %ecx
    5992:      	addl	$0x4, %ecx
    5995:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    599b:      	leaq	0x8(%r14), %rbp
    599f:      	cmpl	$0x5, (%rcx,%r10)
    59a4:      	jb	0x5ece <generic_fentry_process_filter+0x1a6e>
    59aa:      	movl	(%rbp,%r10), %r12d
    59af:      	movl	0x4(%rbp,%r10), %edi
    59b4:      	movl	0x8(%rbp,%r10), %edx
    59b9:      	movq	$0x0, 0x68(%rsp)
    59c2:      	movq	$0x0, 0x60(%rsp)
    59cb:      	cmpl	$0x4, %edx
    59ce:      	movl	$0x4, %ecx
    59d3:      	cmovbl	%edx, %ecx
    59d6:      	cmpl	$0x6, %r12d
    59da:      	jne	0x59f0 <generic_fentry_process_filter+0x1590>
    59dc:      	movabsq	$0x100000001, %rsi      # imm = 0x100000001
    59e6:      	movq	%rsi, 0x60(%rsp)
    59eb:      	movq	%rsi, 0x68(%rsp)
    59f0:      	testl	%edx, %edx
    59f2:      	je	0x5ed5 <generic_fentry_process_filter+0x1a75>
    59f8:      	movq	0x38(%rsp), %rdx
    59fd:      	leaq	0x24(%rdx), %rsi
    5a01:      	testb	$0x1, %dil
    5a05:      	movq	%rsi, 0xb0(%rsp)
    5a0d:      	movq	%rsi, %r8
    5a10:      	cmoveq	%rdx, %r8
    5a14:      	addq	$0x10, %rdx
    5a18:      	movq	%rdx, 0xd0(%rsp)
    5a20:      	leal	(%rax,%r13,4), %r9d
    5a24:      	addl	$0x4, %r9d
    5a28:      	andl	$0x3ff, %r9d            # imm = 0x3FF
    5a2f:      	addq	$0x14, %r9
    5a33:      	decq	%rcx
    5a36:      	cmpq	$0x3, %rcx
    5a3a:      	movl	$0x3, %eax
    5a3f:      	cmovbq	%rcx, %rax
    5a43:      	movl	%eax, %eax
    5a45:      	leaq	0x4(,%rax,4), %r11
    5a4d:      	xorl	%r13d, %r13d
    5a50:      	movq	%rdi, 0x30(%rsp)
    5a55:      	movq	%r8, 0x28(%rsp)
    5a5a:      	movq	%r9, 0x20(%rsp)
    5a5f:      	movq	%r11, 0x18(%rsp)
    5a64:      	jmp	0x5aa0 <generic_fentry_process_filter+0x1640>
    5a66:      	movq	0x8(%rsp), %r10
    5a6b:      	movq	0x30(%rsp), %rdi
    5a70:      	movq	0x28(%rsp), %r8
    5a75:      	movq	0x20(%rsp), %r9
    5a7a:      	movq	0x18(%rsp), %r11
    5a7f:      	cmpl	$0x6, %r12d
    5a83:      	setne	%al
    5a86:      	xorb	$0x1, %bl
    5a89:      	orb	%al, %bl
    5a8b:      	movzbl	%bl, %eax
    5a8e:      	movl	%eax, 0x60(%rsp,%r13)
    5a93:      	addq	$0x4, %r13
    5a97:      	cmpq	%r13, %r11
    5a9a:      	je	0x5ed5 <generic_fentry_process_filter+0x1a75>
    5aa0:      	leaq	(%r9,%r13), %rax
    5aa4:      	movl	(%r8), %ecx
    5aa7:      	cmpq	$0x3e8, %rax            # imm = 0x3E8
    5aad:      	jbe	0x5cba <generic_fentry_process_filter+0x185a>
    5ab3:      	xorl	%r15d, %r15d
    5ab6:      	testb	$0x2, %dil
    5aba:      	je	0x5cd7 <generic_fentry_process_filter+0x1877>
    5ac0:      	testb	$0x1, %dil
    5ac4:      	jne	0x5cf8 <generic_fentry_process_filter+0x1898>
    5aca:      	movq	0x38(%rsp), %rcx
    5acf:      	movl	(%rcx), %eax
    5ad1:      	movb	$0x1, %bl
    5ad3:      	cmpq	%rax, %r15
    5ad6:      	je	0x5a7f <generic_fentry_process_filter+0x161f>
    5ad8:      	movl	0x10(%rcx), %eax
    5adb:      	cmpq	%rax, %r15
    5ade:      	je	0x5a7f <generic_fentry_process_filter+0x161f>
    5ae0:      	movl	$0x1, %eax
    5ae5:      	movq	0xd0(%rsp), %rsi
    5aed:      	movq	(%rip), %rdi            # 0x5af4 <generic_fentry_process_filter+0x1694>
    5af4:      	callq	*%rax
    5af6:      	testq	%rax, %rax
    5af9:      	je	0x5e9d <generic_fentry_process_filter+0x1a3d>
    5aff:      	movq	%rax, %rsi
    5b02:      	movl	(%rax), %eax
    5b04:      	cmpq	%rax, %r15
    5b07:      	je	0x5a66 <generic_fentry_process_filter+0x1606>
    5b0d:      	movl	0x10(%rsi), %eax
    5b10:      	cmpq	%rax, %r15
    5b13:      	je	0x5a66 <generic_fentry_process_filter+0x1606>
    5b19:      	addq	$0x10, %rsi
    5b1d:      	movl	$0x1, %eax
    5b22:      	movq	(%rip), %rdi            # 0x5b29 <generic_fentry_process_filter+0x16c9>
    5b29:      	callq	*%rax
    5b2b:      	testq	%rax, %rax
    5b2e:      	je	0x5e9d <generic_fentry_process_filter+0x1a3d>
    5b34:      	movq	%rax, %rsi
    5b37:      	movl	(%rax), %eax
    5b39:      	cmpq	%rax, %r15
    5b3c:      	je	0x5a66 <generic_fentry_process_filter+0x1606>
    5b42:      	movl	0x10(%rsi), %eax
    5b45:      	cmpq	%rax, %r15
    5b48:      	je	0x5a66 <generic_fentry_process_filter+0x1606>
    5b4e:      	addq	$0x10, %rsi
    5b52:      	movl	$0x1, %eax
    5b57:      	movq	(%rip), %rdi            # 0x5b5e <generic_fentry_process_filter+0x16fe>
    5b5e:      	callq	*%rax
    5b60:      	testq	%rax, %rax
    5b63:      	je	0x5e9d <generic_fentry_process_filter+0x1a3d>
    5b69:      	movq	%rax, %rsi
    5b6c:      	movl	(%rax), %eax
    5b6e:      	cmpq	%rax, %r15
    5b71:      	je	0x5a66 <generic_fentry_process_filter+0x1606>
    5b77:      	movl	0x10(%rsi), %eax
    5b7a:      	cmpq	%rax, %r15
    5b7d:      	je	0x5a66 <generic_fentry_process_filter+0x1606>
    5b83:      	addq	$0x10, %rsi
    5b87:      	movl	$0x1, %eax
    5b8c:      	movq	(%rip), %rdi            # 0x5b93 <generic_fentry_process_filter+0x1733>
    5b93:      	callq	*%rax
    5b95:      	testq	%rax, %rax
    5b98:      	je	0x5e9d <generic_fentry_process_filter+0x1a3d>
    5b9e:      	movq	%rax, %rsi
    5ba1:      	movl	(%rax), %eax
    5ba3:      	cmpq	%rax, %r15
    5ba6:      	je	0x5a66 <generic_fentry_process_filter+0x1606>
    5bac:      	movl	0x10(%rsi), %eax
    5baf:      	cmpq	%rax, %r15
    5bb2:      	je	0x5a66 <generic_fentry_process_filter+0x1606>
    5bb8:      	addq	$0x10, %rsi
    5bbc:      	movl	$0x1, %eax
    5bc1:      	movq	(%rip), %rdi            # 0x5bc8 <generic_fentry_process_filter+0x1768>
    5bc8:      	callq	*%rax
    5bca:      	testq	%rax, %rax
    5bcd:      	je	0x5e9d <generic_fentry_process_filter+0x1a3d>
    5bd3:      	movq	%rax, %rsi
    5bd6:      	movl	(%rax), %eax
    5bd8:      	cmpq	%rax, %r15
    5bdb:      	je	0x5a66 <generic_fentry_process_filter+0x1606>
    5be1:      	movl	0x10(%rsi), %eax
    5be4:      	cmpq	%rax, %r15
    5be7:      	je	0x5a66 <generic_fentry_process_filter+0x1606>
    5bed:      	addq	$0x10, %rsi
    5bf1:      	movl	$0x1, %eax
    5bf6:      	movq	(%rip), %rdi            # 0x5bfd <generic_fentry_process_filter+0x179d>
    5bfd:      	callq	*%rax
    5bff:      	testq	%rax, %rax
    5c02:      	je	0x5e9d <generic_fentry_process_filter+0x1a3d>
    5c08:      	movq	%rax, %rsi
    5c0b:      	movl	(%rax), %eax
    5c0d:      	cmpq	%rax, %r15
    5c10:      	je	0x5a66 <generic_fentry_process_filter+0x1606>
    5c16:      	movl	0x10(%rsi), %eax
    5c19:      	cmpq	%rax, %r15
    5c1c:      	je	0x5a66 <generic_fentry_process_filter+0x1606>
    5c22:      	addq	$0x10, %rsi
    5c26:      	movl	$0x1, %eax
    5c2b:      	movq	(%rip), %rdi            # 0x5c32 <generic_fentry_process_filter+0x17d2>
    5c32:      	callq	*%rax
    5c34:      	testq	%rax, %rax
    5c37:      	je	0x5e9d <generic_fentry_process_filter+0x1a3d>
    5c3d:      	movq	%rax, %rsi
    5c40:      	movl	(%rax), %eax
    5c42:      	cmpq	%rax, %r15
    5c45:      	je	0x5a66 <generic_fentry_process_filter+0x1606>
    5c4b:      	movl	0x10(%rsi), %eax
    5c4e:      	cmpq	%rax, %r15
    5c51:      	je	0x5a66 <generic_fentry_process_filter+0x1606>
    5c57:      	addq	$0x10, %rsi
    5c5b:      	movl	$0x1, %eax
    5c60:      	movq	(%rip), %rdi            # 0x5c67 <generic_fentry_process_filter+0x1807>
    5c67:      	callq	*%rax
    5c69:      	testq	%rax, %rax
    5c6c:      	je	0x5e9d <generic_fentry_process_filter+0x1a3d>
    5c72:      	movq	%rax, %rsi
    5c75:      	movl	(%rax), %eax
    5c77:      	cmpq	%rax, %r15
    5c7a:      	je	0x5a66 <generic_fentry_process_filter+0x1606>
    5c80:      	movl	0x10(%rsi), %eax
    5c83:      	cmpq	%rax, %r15
    5c86:      	movq	0x8(%rsp), %r10
    5c8b:      	movq	0x30(%rsp), %rdi
    5c90:      	movq	0x28(%rsp), %r8
    5c95:      	movq	0x20(%rsp), %r9
    5c9a:      	movq	0x18(%rsp), %r11
    5c9f:      	je	0x5a7f <generic_fentry_process_filter+0x161f>
    5ca5:      	addq	$0x10, %rsi
    5ca9:      	movl	$0x1, %eax
    5cae:      	movq	(%rip), %rcx            # 0x5cb5 <generic_fentry_process_filter+0x1855>
    5cb5:      	jmp	0x5e94 <generic_fentry_process_filter+0x1a34>
    5cba:      	movl	$0x4, %esi
    5cbf:      	xorl	%edx, %edx
    5cc1:      	divq	%rsi
    5cc4:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5cc9:      	movl	(%r10,%rax,4), %r15d
    5ccd:      	testb	$0x2, %dil
    5cd1:      	jne	0x5ac0 <generic_fentry_process_filter+0x1660>
    5cd7:      	cmpl	$0x5, %r12d
    5cdb:      	jne	0x5ce6 <generic_fentry_process_filter+0x1886>
    5cdd:      	cmpq	%rcx, %r15
    5ce0:      	jne	0x5ec7 <generic_fentry_process_filter+0x1a67>
    5ce6:      	cmpq	%rcx, %r15
    5ce9:      	setne	%al
    5cec:      	cmpl	$0x6, %r12d
    5cf0:      	setne	%bl
    5cf3:      	jmp	0x5a89 <generic_fentry_process_filter+0x1629>
    5cf8:      	movq	0xb0(%rsp), %rax
    5d00:      	movl	(%rax), %eax
    5d02:      	testq	%rax, %rax
    5d05:      	je	0x5ec7 <generic_fentry_process_filter+0x1a67>
    5d0b:      	movb	$0x1, %bl
    5d0d:      	testq	%r15, %r15
    5d10:      	je	0x5a7f <generic_fentry_process_filter+0x161f>
    5d16:      	cmpq	%rax, %r15
    5d19:      	je	0x5a7f <generic_fentry_process_filter+0x161f>
    5d1f:      	movl	$0x1, %eax
    5d24:      	movq	0xd0(%rsp), %rsi
    5d2c:      	movq	(%rip), %rdi            # 0x5d33 <generic_fentry_process_filter+0x18d3>
    5d33:      	callq	*%rax
    5d35:      	testq	%rax, %rax
    5d38:      	je	0x5e9d <generic_fentry_process_filter+0x1a3d>
    5d3e:      	movq	%rax, %rsi
    5d41:      	movl	0x24(%rax), %eax
    5d44:      	cmpq	%rax, %r15
    5d47:      	je	0x5a66 <generic_fentry_process_filter+0x1606>
    5d4d:      	addq	$0x10, %rsi
    5d51:      	movl	$0x1, %eax
    5d56:      	movq	(%rip), %rdi            # 0x5d5d <generic_fentry_process_filter+0x18fd>
    5d5d:      	callq	*%rax
    5d5f:      	testq	%rax, %rax
    5d62:      	je	0x5e9d <generic_fentry_process_filter+0x1a3d>
    5d68:      	movq	%rax, %rsi
    5d6b:      	movl	0x24(%rax), %eax
    5d6e:      	cmpq	%rax, %r15
    5d71:      	je	0x5a66 <generic_fentry_process_filter+0x1606>
    5d77:      	addq	$0x10, %rsi
    5d7b:      	movl	$0x1, %eax
    5d80:      	movq	(%rip), %rdi            # 0x5d87 <generic_fentry_process_filter+0x1927>
    5d87:      	callq	*%rax
    5d89:      	testq	%rax, %rax
    5d8c:      	je	0x5e9d <generic_fentry_process_filter+0x1a3d>
    5d92:      	movq	%rax, %rsi
    5d95:      	movl	0x24(%rax), %eax
    5d98:      	cmpq	%rax, %r15
    5d9b:      	je	0x5a66 <generic_fentry_process_filter+0x1606>
    5da1:      	addq	$0x10, %rsi
    5da5:      	movl	$0x1, %eax
    5daa:      	movq	(%rip), %rdi            # 0x5db1 <generic_fentry_process_filter+0x1951>
    5db1:      	callq	*%rax
    5db3:      	testq	%rax, %rax
    5db6:      	je	0x5e9d <generic_fentry_process_filter+0x1a3d>
    5dbc:      	movq	%rax, %rsi
    5dbf:      	movl	0x24(%rax), %eax
    5dc2:      	cmpq	%rax, %r15
    5dc5:      	je	0x5a66 <generic_fentry_process_filter+0x1606>
    5dcb:      	addq	$0x10, %rsi
    5dcf:      	movl	$0x1, %eax
    5dd4:      	movq	(%rip), %rdi            # 0x5ddb <generic_fentry_process_filter+0x197b>
    5ddb:      	callq	*%rax
    5ddd:      	testq	%rax, %rax
    5de0:      	je	0x5e9d <generic_fentry_process_filter+0x1a3d>
    5de6:      	movq	%rax, %rsi
    5de9:      	movl	0x24(%rax), %eax
    5dec:      	cmpq	%rax, %r15
    5def:      	je	0x5a66 <generic_fentry_process_filter+0x1606>
    5df5:      	addq	$0x10, %rsi
    5df9:      	movl	$0x1, %eax
    5dfe:      	movq	(%rip), %rdi            # 0x5e05 <generic_fentry_process_filter+0x19a5>
    5e05:      	callq	*%rax
    5e07:      	testq	%rax, %rax
    5e0a:      	je	0x5e9d <generic_fentry_process_filter+0x1a3d>
    5e10:      	movq	%rax, %rsi
    5e13:      	movl	0x24(%rax), %eax
    5e16:      	cmpq	%rax, %r15
    5e19:      	je	0x5a66 <generic_fentry_process_filter+0x1606>
    5e1f:      	addq	$0x10, %rsi
    5e23:      	movl	$0x1, %eax
    5e28:      	movq	(%rip), %rdi            # 0x5e2f <generic_fentry_process_filter+0x19cf>
    5e2f:      	callq	*%rax
    5e31:      	testq	%rax, %rax
    5e34:      	je	0x5e9d <generic_fentry_process_filter+0x1a3d>
    5e36:      	movq	%rax, %rsi
    5e39:      	movl	0x24(%rax), %eax
    5e3c:      	cmpq	%rax, %r15
    5e3f:      	je	0x5a66 <generic_fentry_process_filter+0x1606>
    5e45:      	addq	$0x10, %rsi
    5e49:      	movl	$0x1, %eax
    5e4e:      	movq	(%rip), %rdi            # 0x5e55 <generic_fentry_process_filter+0x19f5>
    5e55:      	callq	*%rax
    5e57:      	testq	%rax, %rax
    5e5a:      	je	0x5e9d <generic_fentry_process_filter+0x1a3d>
    5e5c:      	movq	%rax, %rsi
    5e5f:      	movl	0x24(%rax), %eax
    5e62:      	cmpq	%rax, %r15
    5e65:      	movq	0x8(%rsp), %r10
    5e6a:      	movq	0x30(%rsp), %rdi
    5e6f:      	movq	0x28(%rsp), %r8
    5e74:      	movq	0x20(%rsp), %r9
    5e79:      	movq	0x18(%rsp), %r11
    5e7e:      	je	0x5a7f <generic_fentry_process_filter+0x161f>
    5e84:      	addq	$0x10, %rsi
    5e88:      	movl	$0x1, %eax
    5e8d:      	movq	(%rip), %rcx            # 0x5e94 <generic_fentry_process_filter+0x1a34>
    5e94:      	movq	(%rip), %rdi            # 0x5e9b <generic_fentry_process_filter+0x1a3b>
    5e9b:      	callq	*%rax
    5e9d:      	xorl	%ebx, %ebx
    5e9f:      	cmpl	$0x5, %r12d
    5ea3:      	movq	0x8(%rsp), %r10
    5ea8:      	movq	0x30(%rsp), %rdi
    5ead:      	movq	0x28(%rsp), %r8
    5eb2:      	movq	0x20(%rsp), %r9
    5eb7:      	movq	0x18(%rsp), %r11
    5ebc:      	jne	0x5a7f <generic_fentry_process_filter+0x161f>
    5ec2:      	jmp	0x5a8b <generic_fentry_process_filter+0x162b>
    5ec7:      	xorl	%ebx, %ebx
    5ec9:      	jmp	0x5a8b <generic_fentry_process_filter+0x162b>
    5ece:      	movl	$0x1, %eax
    5ed3:      	jmp	0x5f11 <generic_fentry_process_filter+0x1ab1>
    5ed5:      	movl	0x60(%rsp), %esi
    5ed9:      	movl	0x64(%rsp), %ecx
    5edd:      	movl	0x68(%rsp), %eax
    5ee1:      	movl	0x6c(%rsp), %edx
    5ee5:      	cmpl	$0x6, %r12d
    5ee9:      	jne	0x5ef3 <generic_fentry_process_filter+0x1a93>
    5eeb:      	andl	%esi, %ecx
    5eed:      	andl	%edx, %eax
    5eef:      	andl	%ecx, %eax
    5ef1:      	jmp	0x5ef9 <generic_fentry_process_filter+0x1a99>
    5ef3:      	orl	%esi, %ecx
    5ef5:      	orl	%edx, %eax
    5ef7:      	orl	%ecx, %eax
    5ef9:      	testl	%eax, %eax
    5efb:      	je	0x6a2b <generic_fentry_process_filter+0x25cb>
    5f01:      	addl	$0x14, %r14d
    5f05:      	movl	0x8(%r10,%rbp), %ecx
    5f0a:      	andl	$0x7, %ecx
    5f0d:      	leal	(%r14,%rcx,4), %ebp
    5f11:      	movq	0x50(%rsp), %r9
    5f16:      	movl	%ebp, %ecx
    5f18:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5f1e:      	movl	(%rcx,%r10), %ecx
    5f22:      	addl	$0x4, %ebp
    5f25:      	addl	$-0x4, %ecx
    5f28:      	xorl	%esi, %esi
    5f2a:      	movl	$0x4, %r8d
    5f30:      	jmp	0x5f4f <generic_fentry_process_filter+0x1aef>
    5f32:      	nopw	%cs:(%rax,%rax)
    5f40:      	xorl	%ecx, %ecx
    5f42:      	incq	%rsi
    5f45:      	cmpq	$0xa, %rsi
    5f49:      	je	0x60d8 <generic_fentry_process_filter+0x1c78>
    5f4f:      	testl	%ecx, %ecx
    5f51:      	je	0x5f40 <generic_fentry_process_filter+0x1ae0>
    5f53:      	movl	%ebp, %r9d
    5f56:      	andl	$0x3ff, %r9d            # imm = 0x3FF
    5f5d:      	movl	(%r9,%r10), %r11d
    5f61:      	movq	%r10, %rax
    5f64:      	movl	0x4(%r9,%r10), %r10d
    5f69:      	movl	0x8(%r9,%rax), %edx
    5f6e:      	movq	$0x0, 0x68(%rsp)
    5f77:      	movq	$0x0, 0x60(%rsp)
    5f80:      	cmpl	$0x4, %edx
    5f83:      	movl	$0x4, %eax
    5f88:      	cmovbl	%edx, %eax
    5f8b:      	cmpl	$0x6, %r10d
    5f8f:      	jne	0x5fa5 <generic_fentry_process_filter+0x1b45>
    5f91:      	movabsq	$0x100000001, %rdi      # imm = 0x100000001
    5f9b:      	movq	%rdi, 0x60(%rsp)
    5fa0:      	movq	%rdi, 0x68(%rsp)
    5fa5:      	addl	$0xc, %ebp
    5fa8:      	testl	%edx, %edx
    5faa:      	je	0x6080 <generic_fentry_process_filter+0x1c20>
    5fb0:      	andl	$0xf, %r11d
    5fb4:      	decq	%rax
    5fb7:      	cmpq	$0x3, %rax
    5fbb:      	movl	$0x3, %edx
    5fc0:      	cmovaeq	%rdx, %rax
    5fc4:      	leaq	0x4(,%rax,4), %rbx
    5fcc:      	movl	%ebp, %r14d
    5fcf:      	cmpl	$0x9, %r11d
    5fd3:      	jbe	0x600a <generic_fentry_process_filter+0x1baa>
    5fd5:      	xorl	%r11d, %r11d
    5fd8:      	jmp	0x5ff6 <generic_fentry_process_filter+0x1b96>
    5fda:      	nopw	(%rax,%rax)
    5fe0:      	movl	$0x0, 0x60(%rsp,%r11)
    5fe9:      	addq	$0x4, %r11
    5fed:      	cmpq	%r11, %rbx
    5ff0:      	je	0x6080 <generic_fentry_process_filter+0x1c20>
    5ff6:      	leaq	(%r14,%r11), %rax
    5ffa:      	cmpl	$0x3e8, %eax            # imm = 0x3E8
    5fff:      	ja	0x5fe0 <generic_fentry_process_filter+0x1b80>
    6001:      	movl	%eax, %eax
    6003:      	xorl	%edx, %edx
    6005:      	divq	%r8
    6008:      	jmp	0x5fe0 <generic_fentry_process_filter+0x1b80>
    600a:      	xorl	%r15d, %r15d
    600d:      	jmp	0x6051 <generic_fentry_process_filter+0x1bf1>
    600f:      	nop
    6010:      	cmpl	$0x5, %r10d
    6014:      	setne	%dl
    6017:      	movl	%r10d, %r13d
    601a:      	xorl	$0x6, %r13d
    601e:      	movq	0x50(%rsp), %rax
    6023:      	movl	0x20(%rax,%r11,4), %edi
    6028:      	movl	%r12d, %eax
    602b:      	xorl	%edi, %eax
    602d:      	cmpl	%edi, %r12d
    6030:      	sete	%dil
    6034:      	orb	%dl, %dil
    6037:      	orl	%r13d, %eax
    603a:      	setne	%al
    603d:      	andb	%dil, %al
    6040:      	movzbl	%al, %eax
    6043:      	movl	%eax, 0x60(%rsp,%r15)
    6048:      	addq	$0x4, %r15
    604c:      	cmpq	%r15, %rbx
    604f:      	je	0x6080 <generic_fentry_process_filter+0x1c20>
    6051:      	leaq	(%r14,%r15), %rdx
    6055:      	xorl	%r12d, %r12d
    6058:      	cmpl	$0x3e8, %edx            # imm = 0x3E8
    605e:      	ja	0x6010 <generic_fentry_process_filter+0x1bb0>
    6060:      	movl	%edx, %eax
    6062:      	xorl	%edx, %edx
    6064:      	divq	%r8
    6067:      	andl	$0x3ff, %eax            # imm = 0x3FF
    606c:      	movq	0x8(%rsp), %rdx
    6071:      	movl	(%rdx,%rax,4), %r12d
    6075:      	jmp	0x6010 <generic_fentry_process_filter+0x1bb0>
    6077:      	nopw	(%rax,%rax)
    6080:      	movl	0x60(%rsp), %ebx
    6084:      	movl	0x64(%rsp), %edx
    6088:      	movl	0x68(%rsp), %eax
    608c:      	movl	0x6c(%rsp), %r11d
    6091:      	cmpl	$0x6, %r10d
    6095:      	jne	0x60a0 <generic_fentry_process_filter+0x1c40>
    6097:      	andl	%ebx, %edx
    6099:      	andl	%r11d, %eax
    609c:      	andl	%edx, %eax
    609e:      	jmp	0x60a7 <generic_fentry_process_filter+0x1c47>
    60a0:      	orl	%ebx, %edx
    60a2:      	orl	%r11d, %eax
    60a5:      	orl	%edx, %eax
    60a7:      	movq	0x8(%rsp), %r10
    60ac:      	testl	%eax, %eax
    60ae:      	je	0x6a2b <generic_fentry_process_filter+0x25cb>
    60b4:      	movl	0x8(%r10,%r9), %edx
    60b9:      	shll	$0x2, %edx
    60bc:      	subl	%edx, %ecx
    60be:      	andl	$0x1c, %edx
    60c1:      	addl	%edx, %ebp
    60c3:      	addl	$-0xc, %ecx
    60c6:      	movq	0x50(%rsp), %r9
    60cb:      	incq	%rsi
    60ce:      	cmpq	$0xa, %rsi
    60d2:      	jne	0x5f4f <generic_fentry_process_filter+0x1aef>
    60d8:      	movl	%ebp, %ecx
    60da:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    60e0:      	leal	0x4(%rbp), %ebx
    60e3:      	cmpl	$0x4, (%rcx,%r10)
    60e8:      	je	0x62b8 <generic_fentry_process_filter+0x1e58>
    60ee:      	andl	$0x3ff, %ebx            # imm = 0x3FF
    60f4:      	movl	(%rbx,%r10), %ecx
    60f8:      	movl	0x4(%rbx,%r10), %edx
    60fd:      	movl	0x8(%rbx,%r10), %edi
    6102:      	movq	0xc(%rbx,%r10), %rax
    6107:      	testl	%edi, %edi
    6109:      	je	0x628c <generic_fentry_process_filter+0x1e2c>
    610f:      	xorl	%esi, %esi
    6111:      	cmpl	$0x2, %ecx
    6114:      	ja	0x62af <generic_fentry_process_filter+0x1e4f>
    611a:      	cmpl	%edi, 0x44(%r9)
    611e:      	jne	0x6295 <generic_fentry_process_filter+0x1e35>
    6124:      	jmp	0x62af <generic_fentry_process_filter+0x1e4f>
    6129:      	movq	%rbx, %rsi
    612c:      	addq	$0x4, %rsi
    6130:      	movq	(%rip), %rdi            # 0x6137 <generic_fentry_process_filter+0x1cd7>
    6137:      	movl	$0x1, %eax
    613c:      	callq	*%rax
    613e:      	testq	%rax, %rax
    6141:      	je	0x6a2b <generic_fentry_process_filter+0x25cb>
    6147:      	movq	%rax, %r14
    614a:      	movq	(%rip), %rdi            # 0x6151 <generic_fentry_process_filter+0x1cf1>
    6151:      	leaq	0x58(%rsp), %rsi
    6156:      	movl	$0x1, %eax
    615b:      	callq	*%rax
    615d:      	testq	%rax, %rax
    6160:      	je	0x6a2b <generic_fentry_process_filter+0x25cb>
    6166:      	movq	%rax, %rbp
    6169:      	movl	$0x104, %edx            # imm = 0x104
    616e:      	movq	%rax, %rdi
    6171:      	xorl	%esi, %esi
    6173:      	callq	0x6178 <generic_fentry_process_filter+0x1d18>
    6178:      	movq	0x38(%rsp), %rsi
    617d:      	movl	0x68(%rsi), %eax
    6180:      	leal	(,%rax,8), %ecx
    6187:      	movl	%ecx, (%rbp)
    618a:      	movq	%rbp, %rdi
    618d:      	addq	$0x4, %rdi
    6191:      	movzbl	%al, %ecx
    6194:      	leaq	0x70(%rsi), %rdx
    6198:      	movl	$0x4, %eax
    619d:      	movzbl	0x68(%rsi), %esi
    61a1:      	callq	*%rax
    61a3:      	testq	%rax, %rax
    61a6:      	js	0x6a2b <generic_fentry_process_filter+0x25cb>
    61ac:      	movl	$0x1, %eax
    61b1:      	movq	%r14, %rdi
    61b4:      	movq	%rbp, %rsi
    61b7:      	jmp	0x65b7 <generic_fentry_process_filter+0x2157>
    61bc:      	movl	$0x0, 0x40(%rsp)
    61c4:      	movq	(%rip), %rdi            # 0x61cb <generic_fentry_process_filter+0x1d6b>
    61cb:      	leaq	0x40(%rsp), %rsi
    61d0:      	movl	$0x1, %eax
    61d5:      	callq	*%rax
    61d7:      	testq	%rax, %rax
    61da:      	movq	0x38(%rsp), %rdx
    61df:      	je	0x6564 <generic_fentry_process_filter+0x2104>
    61e5:      	movq	(%rax), %rcx
    61e8:      	cmpq	0x378(%rdx), %rcx
    61ef:      	je	0x6564 <generic_fentry_process_filter+0x2104>
    61f5:      	movq	%rax, 0xb0(%rsp)
    61fd:      	movq	(%rip), %rax            # 0x6204 <generic_fentry_process_filter+0x1da4>
    6204:      	cmpb	$0x0, (%rax)
    6207:      	je	0x64db <generic_fentry_process_filter+0x207b>
    620d:      	movl	$0x1869f, %r15d         # imm = 0x1869F
    6213:      	xorl	%r14d, %r14d
    6216:      	movq	(%rip), %r12            # 0x621d <generic_fentry_process_filter+0x1dbd>
    621d:      	movq	0x38(%rsp), %rax
    6222:      	movl	0x10(%rax), %eax
    6225:      	movl	%eax, 0x60(%rsp)
    6229:      	movl	$0x1, %eax
    622e:      	leaq	0x60(%rsp), %rsi
    6233:      	movq	%r12, %rdi
    6236:      	callq	*%rax
    6238:      	testq	%rax, %rax
    623b:      	je	0x654d <generic_fentry_process_filter+0x20ed>
    6241:      	movq	%rax, %rbp
    6244:      	leaq	0x70(%rax), %rsi
    6248:      	movl	$0x1, %eax
    624d:      	movq	(%rip), %rdi            # 0x6254 <generic_fentry_process_filter+0x1df4>
    6254:      	callq	*%rax
    6256:      	testq	%rax, %rax
    6259:      	je	0x6270 <generic_fentry_process_filter+0x1e10>
    625b:      	movq	(%rax), %rax
    625e:      	testq	%rax, %rax
    6261:      	je	0x6270 <generic_fentry_process_filter+0x1e10>
    6263:      	movq	0x38(%rsp), %rcx
    6268:      	lock
    6269:      	orq	%rax, 0x370(%rcx)
    6270:      	subl	$0x1, %r15d
    6274:      	setb	%al
    6277:      	cmpq	%r14, %rbp
    627a:      	je	0x654d <generic_fentry_process_filter+0x20ed>
    6280:      	movq	%rbp, %r14
    6283:      	testb	%al, %al
    6285:      	je	0x621d <generic_fentry_process_filter+0x1dbd>
    6287:      	jmp	0x654d <generic_fentry_process_filter+0x20ed>
    628c:      	cmpl	$0x2, %ecx
    628f:      	jbe	0x6295 <generic_fentry_process_filter+0x1e35>
    6291:      	xorl	%esi, %esi
    6293:      	jmp	0x62af <generic_fentry_process_filter+0x1e4f>
    6295:      	andq	0x48(%r9,%rcx,8), %rax
    629a:      	cmpl	$0x5, %edx
    629d:      	jne	0x62a8 <generic_fentry_process_filter+0x1e48>
    629f:      	testq	%rax, %rax
    62a2:      	setne	%sil
    62a6:      	jmp	0x62af <generic_fentry_process_filter+0x1e4f>
    62a8:      	testq	%rax, %rax
    62ab:      	sete	%sil
    62af:      	addl	$0x18, %ebp
    62b2:      	movzbl	%sil, %eax
    62b6:      	movl	%ebp, %ebx
    62b8:      	testl	%eax, %eax
    62ba:      	je	0x6a2b <generic_fentry_process_filter+0x25cb>
    62c0:      	movl	%ebx, %ecx
    62c2:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    62c8:      	leal	0x4(%rbx), %eax
    62cb:      	cmpl	$0x4, (%rcx,%r10)
    62d0:      	je	0x6933 <generic_fentry_process_filter+0x24d3>
    62d6:      	andl	$0x3ff, %eax            # imm = 0x3FF
    62db:      	movl	(%rax,%r10), %r14d
    62df:      	movl	0x4(%rax,%r10), %ebp
    62e4:      	movl	$0xe, %eax
    62e9:      	callq	*%rax
    62eb:      	shrq	$0x20, %rax
    62ef:      	movl	%eax, 0x60(%rsp)
    62f3:      	movq	(%rip), %rdi            # 0x62fa <generic_fentry_process_filter+0x1e9a>
    62fa:      	leaq	0x60(%rsp), %rsi
    62ff:      	movl	$0x1, %eax
    6304:      	callq	*%rax
    6306:      	movq	0x8(%rsp), %r10
    630b:      	testq	%rax, %rax
    630e:      	je	0x6a2b <generic_fentry_process_filter+0x25cb>
    6314:      	cmpl	$0x5, %r14d
    6318:      	je	0x6356 <generic_fentry_process_filter+0x1ef6>
    631a:      	cmpl	$0x6, %r14d
    631e:      	jne	0x6a2b <generic_fentry_process_filter+0x25cb>
    6324:      	movq	0x50(%rsp), %rsi
    6329:      	movq	%rsi, %rcx
    632c:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    6333:      	testb	$0x1, %bpl
    6337:      	jne	0x65f9 <generic_fentry_process_filter+0x2199>
    633d:      	movl	0x28(%rax), %edx
    6340:      	testl	%edx, %edx
    6342:      	je	0x65f2 <generic_fentry_process_filter+0x2192>
    6348:      	cmpl	0x20(%rsi), %edx
    634b:      	je	0x65f9 <generic_fentry_process_filter+0x2199>
    6351:      	jmp	0x6927 <generic_fentry_process_filter+0x24c7>
    6356:      	movq	0x50(%rsp), %rsi
    635b:      	movq	%rsi, %rcx
    635e:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    6365:      	testb	$0x1, %bpl
    6369:      	je	0x6617 <generic_fentry_process_filter+0x21b7>
    636f:      	movl	0x28(%rax), %edx
    6372:      	testl	%edx, %edx
    6374:      	je	0x6610 <generic_fentry_process_filter+0x21b0>
    637a:      	cmpl	0x20(%rsi), %edx
    637d:      	je	0x6617 <generic_fentry_process_filter+0x21b7>
    6383:      	jmp	0x6927 <generic_fentry_process_filter+0x24c7>
    6388:      	movq	%r12, %rsi
    638b:      	addq	$0x4, %rsi
    638f:      	movq	(%rip), %rdi            # 0x6396 <generic_fentry_process_filter+0x1f36>
    6396:      	movl	$0x1, %eax
    639b:      	callq	*%rax
    639d:      	testq	%rax, %rax
    63a0:      	je	0x6a2b <generic_fentry_process_filter+0x25cb>
    63a6:      	movq	%rax, %r14
    63a9:      	movq	(%rip), %rdi            # 0x63b0 <generic_fentry_process_filter+0x1f50>
    63b0:      	leaq	0x58(%rsp), %rsi
    63b5:      	movl	$0x1, %eax
    63ba:      	callq	*%rax
    63bc:      	testq	%rax, %rax
    63bf:      	je	0x6a2b <generic_fentry_process_filter+0x25cb>
    63c5:      	movq	%rax, %rbx
    63c8:      	movl	$0x104, %edx            # imm = 0x104
    63cd:      	movq	%rax, %rdi
    63d0:      	xorl	%esi, %esi
    63d2:      	callq	0x63d7 <generic_fentry_process_filter+0x1f77>
    63d7:      	movl	(%rbp), %eax
    63da:      	leal	(,%rax,8), %ecx
    63e1:      	movl	%ecx, (%rbx)
    63e3:      	movq	%rbx, %rdi
    63e6:      	addq	$0x4, %rdi
    63ea:      	movzbl	%al, %ecx
    63ed:      	movq	%rbp, %rdx
    63f0:      	addq	$0x8, %rdx
    63f4:      	movl	$0x4, %eax
    63f9:      	movzbl	(%rbp), %esi
    63fd:      	callq	*%rax
    63ff:      	testq	%rax, %rax
    6402:      	js	0x6a2b <generic_fentry_process_filter+0x25cb>
    6408:      	movl	$0x1, %eax
    640d:      	movq	%r14, %rdi
    6410:      	movq	%rbx, %rsi
    6413:      	jmp	0x678d <generic_fentry_process_filter+0x232d>
    6418:      	movl	$0x0, 0x40(%rsp)
    6420:      	movq	(%rip), %rdi            # 0x6427 <generic_fentry_process_filter+0x1fc7>
    6427:      	leaq	0x40(%rsp), %rsi
    642c:      	movl	$0x1, %eax
    6431:      	callq	*%rax
    6433:      	testq	%rax, %rax
    6436:      	je	0x673a <generic_fentry_process_filter+0x22da>
    643c:      	movq	(%rax), %rcx
    643f:      	cmpq	0x310(%rbp), %rcx
    6446:      	je	0x673a <generic_fentry_process_filter+0x22da>
    644c:      	movq	%rax, 0xb0(%rsp)
    6454:      	movq	(%rip), %rax            # 0x645b <generic_fentry_process_filter+0x1ffb>
    645b:      	cmpb	$0x0, (%rax)
    645e:      	je	0x66be <generic_fentry_process_filter+0x225e>
    6464:      	movl	$0x1869f, %r15d         # imm = 0x1869F
    646a:      	xorl	%r14d, %r14d
    646d:      	movq	0x38(%rsp), %rax
    6472:      	movl	0x10(%rax), %eax
    6475:      	movl	%eax, 0x60(%rsp)
    6479:      	movl	$0x1, %eax
    647e:      	movq	(%rip), %rdi            # 0x6485 <generic_fentry_process_filter+0x2025>
    6485:      	leaq	0x60(%rsp), %rsi
    648a:      	callq	*%rax
    648c:      	testq	%rax, %rax
    648f:      	je	0x6728 <generic_fentry_process_filter+0x22c8>
    6495:      	movq	%rax, %rbx
    6498:      	leaq	0x70(%rax), %rsi
    649c:      	movl	$0x1, %eax
    64a1:      	movq	(%rip), %rdi            # 0x64a8 <generic_fentry_process_filter+0x2048>
    64a8:      	callq	*%rax
    64aa:      	testq	%rax, %rax
    64ad:      	je	0x64bf <generic_fentry_process_filter+0x205f>
    64af:      	movq	(%rax), %rax
    64b2:      	testq	%rax, %rax
    64b5:      	je	0x64bf <generic_fentry_process_filter+0x205f>
    64b7:      	lock
    64b8:      	orq	%rax, 0x308(%rbp)
    64bf:      	subl	$0x1, %r15d
    64c3:      	setb	%al
    64c6:      	cmpq	%r14, %rbx
    64c9:      	je	0x6728 <generic_fentry_process_filter+0x22c8>
    64cf:      	movq	%rbx, %r14
    64d2:      	testb	%al, %al
    64d4:      	je	0x646d <generic_fentry_process_filter+0x200d>
    64d6:      	jmp	0x6728 <generic_fentry_process_filter+0x22c8>
    64db:      	movl	$0x3ff, %r15d           # imm = 0x3FF
    64e1:      	xorl	%r14d, %r14d
    64e4:      	movq	(%rip), %r12            # 0x64eb <generic_fentry_process_filter+0x208b>
    64eb:      	movq	0x38(%rsp), %rax
    64f0:      	movl	0x10(%rax), %eax
    64f3:      	movl	%eax, 0x60(%rsp)
    64f7:      	movl	$0x1, %eax
    64fc:      	leaq	0x60(%rsp), %rsi
    6501:      	movq	%r12, %rdi
    6504:      	callq	*%rax
    6506:      	testq	%rax, %rax
    6509:      	je	0x654d <generic_fentry_process_filter+0x20ed>
    650b:      	movq	%rax, %rbp
    650e:      	leaq	0x70(%rax), %rsi
    6512:      	movl	$0x1, %eax
    6517:      	movq	(%rip), %rdi            # 0x651e <generic_fentry_process_filter+0x20be>
    651e:      	callq	*%rax
    6520:      	testq	%rax, %rax
    6523:      	je	0x653a <generic_fentry_process_filter+0x20da>
    6525:      	movq	(%rax), %rax
    6528:      	testq	%rax, %rax
    652b:      	je	0x653a <generic_fentry_process_filter+0x20da>
    652d:      	movq	0x38(%rsp), %rcx
    6532:      	lock
    6533:      	orq	%rax, 0x370(%rcx)
    653a:      	subl	$0x1, %r15d
    653e:      	setb	%al
    6541:      	cmpq	%r14, %rbp
    6544:      	je	0x654d <generic_fentry_process_filter+0x20ed>
    6546:      	movq	%rbp, %r14
    6549:      	testb	%al, %al
    654b:      	je	0x64eb <generic_fentry_process_filter+0x208b>
    654d:      	movq	0xb0(%rsp), %rax
    6555:      	movq	(%rax), %rax
    6558:      	movq	0x38(%rsp), %rdx
    655d:      	movq	%rax, 0x378(%rdx)
    6564:      	movl	0x8(%rbx), %eax
    6567:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    656c:      	cmpq	%rcx, %rax
    656f:      	je	0x658a <generic_fentry_process_filter+0x212a>
    6571:      	movq	0x370(%rdx), %rcx
    6578:      	btq	%rax, %rcx
    657c:      	jae	0x658a <generic_fentry_process_filter+0x212a>
    657e:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    6588:      	jmp	0x65b9 <generic_fentry_process_filter+0x2159>
    658a:      	movq	(%rip), %rdi            # 0x6591 <generic_fentry_process_filter+0x2131>
    6591:      	leaq	0x10(%rsp), %rsi
    6596:      	movl	$0x1, %eax
    659b:      	callq	*%rax
    659d:      	testq	%rax, %rax
    65a0:      	je	0x6a2b <generic_fentry_process_filter+0x25cb>
    65a6:      	movq	%rax, %rdi
    65a9:      	movq	0x38(%rsp), %rax
    65ae:      	leaq	0x70(%rax), %rsi
    65b2:      	movl	$0x1, %eax
    65b7:      	callq	*%rax
    65b9:      	movl	(%rbx), %ecx
    65bb:      	cmpq	$0x25, %rcx
    65bf:      	movq	0x8(%rsp), %r10
    65c4:      	ja	0x65e4 <generic_fentry_process_filter+0x2184>
    65c6:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    65d0:      	btq	%rcx, %rdx
    65d4:      	jae	0x65e4 <generic_fentry_process_filter+0x2184>
    65d6:      	testq	%rax, %rax
    65d9:      	jne	0x6a2b <generic_fentry_process_filter+0x25cb>
    65df:      	jmp	0x5729 <generic_fentry_process_filter+0x12c9>
    65e4:      	testq	%rax, %rax
    65e7:      	jne	0x5729 <generic_fentry_process_filter+0x12c9>
    65ed:      	jmp	0x6a2b <generic_fentry_process_filter+0x25cb>
    65f2:      	movq	$0x1, (%rcx)
    65f9:      	testb	$0x2, %bpl
    65fd:      	jne	0x6635 <generic_fentry_process_filter+0x21d5>
    65ff:      	movl	0x2c(%rax), %edx
    6602:      	testl	%edx, %edx
    6604:      	je	0x662e <generic_fentry_process_filter+0x21ce>
    6606:      	cmpl	0x24(%rsi), %edx
    6609:      	je	0x6635 <generic_fentry_process_filter+0x21d5>
    660b:      	jmp	0x6927 <generic_fentry_process_filter+0x24c7>
    6610:      	movq	$0x1, (%rcx)
    6617:      	testb	$0x2, %bpl
    661b:      	je	0x6653 <generic_fentry_process_filter+0x21f3>
    661d:      	movl	0x2c(%rax), %edx
    6620:      	testl	%edx, %edx
    6622:      	je	0x664c <generic_fentry_process_filter+0x21ec>
    6624:      	cmpl	0x24(%rsi), %edx
    6627:      	je	0x6653 <generic_fentry_process_filter+0x21f3>
    6629:      	jmp	0x6927 <generic_fentry_process_filter+0x24c7>
    662e:      	movq	$0x1, (%rcx)
    6635:      	testb	$0x4, %bpl
    6639:      	jne	0x6671 <generic_fentry_process_filter+0x2211>
    663b:      	movl	0x30(%rax), %edx
    663e:      	testl	%edx, %edx
    6640:      	je	0x666a <generic_fentry_process_filter+0x220a>
    6642:      	cmpl	0x28(%rsi), %edx
    6645:      	je	0x6671 <generic_fentry_process_filter+0x2211>
    6647:      	jmp	0x6927 <generic_fentry_process_filter+0x24c7>
    664c:      	movq	$0x1, (%rcx)
    6653:      	testb	$0x4, %bpl
    6657:      	je	0x669b <generic_fentry_process_filter+0x223b>
    6659:      	movl	0x30(%rax), %edx
    665c:      	testl	%edx, %edx
    665e:      	je	0x6694 <generic_fentry_process_filter+0x2234>
    6660:      	cmpl	0x28(%rsi), %edx
    6663:      	je	0x669b <generic_fentry_process_filter+0x223b>
    6665:      	jmp	0x6927 <generic_fentry_process_filter+0x24c7>
    666a:      	movq	$0x1, (%rcx)
    6671:      	testb	$0x8, %bpl
    6675:      	jne	0x67d1 <generic_fentry_process_filter+0x2371>
    667b:      	movl	0x34(%rax), %edx
    667e:      	testl	%edx, %edx
    6680:      	je	0x67ca <generic_fentry_process_filter+0x236a>
    6686:      	cmpl	0x2c(%rsi), %edx
    6689:      	je	0x67d1 <generic_fentry_process_filter+0x2371>
    668f:      	jmp	0x6927 <generic_fentry_process_filter+0x24c7>
    6694:      	movq	$0x1, (%rcx)
    669b:      	testb	$0x8, %bpl
    669f:      	je	0x67ef <generic_fentry_process_filter+0x238f>
    66a5:      	movl	0x34(%rax), %edx
    66a8:      	testl	%edx, %edx
    66aa:      	je	0x67e8 <generic_fentry_process_filter+0x2388>
    66b0:      	cmpl	0x2c(%rsi), %edx
    66b3:      	je	0x67ef <generic_fentry_process_filter+0x238f>
    66b9:      	jmp	0x6927 <generic_fentry_process_filter+0x24c7>
    66be:      	movl	$0x3ff, %r15d           # imm = 0x3FF
    66c4:      	xorl	%r14d, %r14d
    66c7:      	movq	0x38(%rsp), %rax
    66cc:      	movl	0x10(%rax), %eax
    66cf:      	movl	%eax, 0x60(%rsp)
    66d3:      	movl	$0x1, %eax
    66d8:      	movq	(%rip), %rdi            # 0x66df <generic_fentry_process_filter+0x227f>
    66df:      	leaq	0x60(%rsp), %rsi
    66e4:      	callq	*%rax
    66e6:      	testq	%rax, %rax
    66e9:      	je	0x6728 <generic_fentry_process_filter+0x22c8>
    66eb:      	movq	%rax, %rbx
    66ee:      	leaq	0x70(%rax), %rsi
    66f2:      	movl	$0x1, %eax
    66f7:      	movq	(%rip), %rdi            # 0x66fe <generic_fentry_process_filter+0x229e>
    66fe:      	callq	*%rax
    6700:      	testq	%rax, %rax
    6703:      	je	0x6715 <generic_fentry_process_filter+0x22b5>
    6705:      	movq	(%rax), %rax
    6708:      	testq	%rax, %rax
    670b:      	je	0x6715 <generic_fentry_process_filter+0x22b5>
    670d:      	lock
    670e:      	orq	%rax, 0x308(%rbp)
    6715:      	subl	$0x1, %r15d
    6719:      	setb	%al
    671c:      	cmpq	%r14, %rbx
    671f:      	je	0x6728 <generic_fentry_process_filter+0x22c8>
    6721:      	movq	%rbx, %r14
    6724:      	testb	%al, %al
    6726:      	je	0x66c7 <generic_fentry_process_filter+0x2267>
    6728:      	movq	0xb0(%rsp), %rax
    6730:      	movq	(%rax), %rax
    6733:      	movq	%rax, 0x310(%rbp)
    673a:      	movl	0x8(%r12), %eax
    673f:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    6744:      	cmpq	%rcx, %rax
    6747:      	je	0x6762 <generic_fentry_process_filter+0x2302>
    6749:      	movq	0x308(%rbp), %rcx
    6750:      	btq	%rax, %rcx
    6754:      	jae	0x6762 <generic_fentry_process_filter+0x2302>
    6756:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    6760:      	jmp	0x678f <generic_fentry_process_filter+0x232f>
    6762:      	movq	(%rip), %rdi            # 0x6769 <generic_fentry_process_filter+0x2309>
    6769:      	leaq	0x10(%rsp), %rsi
    676e:      	movl	$0x1, %eax
    6773:      	callq	*%rax
    6775:      	testq	%rax, %rax
    6778:      	je	0x6a2b <generic_fentry_process_filter+0x25cb>
    677e:      	movq	%rax, %rdi
    6781:      	addq	$0x8, %rbp
    6785:      	movl	$0x1, %eax
    678a:      	movq	%rbp, %rsi
    678d:      	callq	*%rax
    678f:      	movl	(%r12), %ecx
    6793:      	cmpq	$0x25, %rcx
    6797:      	movq	0x8(%rsp), %r10
    679c:      	ja	0x67bc <generic_fentry_process_filter+0x235c>
    679e:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    67a8:      	btq	%rcx, %rdx
    67ac:      	jae	0x67bc <generic_fentry_process_filter+0x235c>
    67ae:      	testq	%rax, %rax
    67b1:      	jne	0x6a2b <generic_fentry_process_filter+0x25cb>
    67b7:      	jmp	0x5975 <generic_fentry_process_filter+0x1515>
    67bc:      	testq	%rax, %rax
    67bf:      	jne	0x5975 <generic_fentry_process_filter+0x1515>
    67c5:      	jmp	0x6a2b <generic_fentry_process_filter+0x25cb>
    67ca:      	movq	$0x1, (%rcx)
    67d1:      	testb	$0x10, %bpl
    67d5:      	jne	0x680d <generic_fentry_process_filter+0x23ad>
    67d7:      	movl	0x38(%rax), %edx
    67da:      	testl	%edx, %edx
    67dc:      	je	0x6806 <generic_fentry_process_filter+0x23a6>
    67de:      	cmpl	0x30(%rsi), %edx
    67e1:      	je	0x680d <generic_fentry_process_filter+0x23ad>
    67e3:      	jmp	0x6927 <generic_fentry_process_filter+0x24c7>
    67e8:      	movq	$0x1, (%rcx)
    67ef:      	testb	$0x10, %bpl
    67f3:      	je	0x682b <generic_fentry_process_filter+0x23cb>
    67f5:      	movl	0x38(%rax), %edx
    67f8:      	testl	%edx, %edx
    67fa:      	je	0x6824 <generic_fentry_process_filter+0x23c4>
    67fc:      	cmpl	0x30(%rsi), %edx
    67ff:      	je	0x682b <generic_fentry_process_filter+0x23cb>
    6801:      	jmp	0x6927 <generic_fentry_process_filter+0x24c7>
    6806:      	movq	$0x1, (%rcx)
    680d:      	testb	$0x20, %bpl
    6811:      	jne	0x6849 <generic_fentry_process_filter+0x23e9>
    6813:      	movl	0x3c(%rax), %edx
    6816:      	testl	%edx, %edx
    6818:      	je	0x6842 <generic_fentry_process_filter+0x23e2>
    681a:      	cmpl	0x34(%rsi), %edx
    681d:      	je	0x6849 <generic_fentry_process_filter+0x23e9>
    681f:      	jmp	0x6927 <generic_fentry_process_filter+0x24c7>
    6824:      	movq	$0x1, (%rcx)
    682b:      	testb	$0x20, %bpl
    682f:      	je	0x6867 <generic_fentry_process_filter+0x2407>
    6831:      	movl	0x3c(%rax), %edx
    6834:      	testl	%edx, %edx
    6836:      	je	0x6860 <generic_fentry_process_filter+0x2400>
    6838:      	cmpl	0x34(%rsi), %edx
    683b:      	je	0x6867 <generic_fentry_process_filter+0x2407>
    683d:      	jmp	0x6927 <generic_fentry_process_filter+0x24c7>
    6842:      	movq	$0x1, (%rcx)
    6849:      	testb	$0x40, %bpl
    684d:      	jne	0x6885 <generic_fentry_process_filter+0x2425>
    684f:      	movl	0x40(%rax), %edx
    6852:      	testl	%edx, %edx
    6854:      	je	0x687e <generic_fentry_process_filter+0x241e>
    6856:      	cmpl	0x38(%rsi), %edx
    6859:      	je	0x6885 <generic_fentry_process_filter+0x2425>
    685b:      	jmp	0x6927 <generic_fentry_process_filter+0x24c7>
    6860:      	movq	$0x1, (%rcx)
    6867:      	testb	$0x40, %bpl
    686b:      	je	0x68a2 <generic_fentry_process_filter+0x2442>
    686d:      	movl	0x40(%rax), %edx
    6870:      	testl	%edx, %edx
    6872:      	je	0x689b <generic_fentry_process_filter+0x243b>
    6874:      	cmpl	0x38(%rsi), %edx
    6877:      	je	0x68a2 <generic_fentry_process_filter+0x2442>
    6879:      	jmp	0x6927 <generic_fentry_process_filter+0x24c7>
    687e:      	movq	$0x1, (%rcx)
    6885:      	testb	%bpl, %bpl
    6888:      	js	0x68bc <generic_fentry_process_filter+0x245c>
    688a:      	movl	0x44(%rax), %edx
    688d:      	testl	%edx, %edx
    688f:      	je	0x68b5 <generic_fentry_process_filter+0x2455>
    6891:      	cmpl	0x3c(%rsi), %edx
    6894:      	je	0x68bc <generic_fentry_process_filter+0x245c>
    6896:      	jmp	0x6927 <generic_fentry_process_filter+0x24c7>
    689b:      	movq	$0x1, (%rcx)
    68a2:      	testb	%bpl, %bpl
    68a5:      	jns	0x68d9 <generic_fentry_process_filter+0x2479>
    68a7:      	movl	0x44(%rax), %edx
    68aa:      	testl	%edx, %edx
    68ac:      	je	0x68d2 <generic_fentry_process_filter+0x2472>
    68ae:      	cmpl	0x3c(%rsi), %edx
    68b1:      	je	0x68d9 <generic_fentry_process_filter+0x2479>
    68b3:      	jmp	0x6927 <generic_fentry_process_filter+0x24c7>
    68b5:      	movq	$0x1, (%rcx)
    68bc:      	testl	$0x100, %ebp            # imm = 0x100
    68c2:      	jne	0x6902 <generic_fentry_process_filter+0x24a2>
    68c4:      	movl	0x48(%rax), %edx
    68c7:      	testl	%edx, %edx
    68c9:      	je	0x68fb <generic_fentry_process_filter+0x249b>
    68cb:      	cmpl	0x40(%rsi), %edx
    68ce:      	je	0x6902 <generic_fentry_process_filter+0x24a2>
    68d0:      	jmp	0x6927 <generic_fentry_process_filter+0x24c7>
    68d2:      	movq	$0x1, (%rcx)
    68d9:      	testl	$0x100, %ebp            # imm = 0x100
    68df:      	je	0x6a11 <generic_fentry_process_filter+0x25b1>
    68e5:      	movl	0x48(%rax), %edx
    68e8:      	testl	%edx, %edx
    68ea:      	je	0x6a0a <generic_fentry_process_filter+0x25aa>
    68f0:      	cmpl	0x40(%rsi), %edx
    68f3:      	je	0x6a11 <generic_fentry_process_filter+0x25b1>
    68f9:      	jmp	0x6927 <generic_fentry_process_filter+0x24c7>
    68fb:      	movq	$0x1, (%rcx)
    6902:      	testl	$0x200, %ebp            # imm = 0x200
    6908:      	jne	0x6a2b <generic_fentry_process_filter+0x25cb>
    690e:      	movl	0x4c(%rax), %eax
    6911:      	testl	%eax, %eax
    6913:      	je	0x6a24 <generic_fentry_process_filter+0x25c4>
    6919:      	movq	0x50(%rsp), %rdx
    691e:      	cmpl	0x44(%rdx), %eax
    6921:      	je	0x6a2b <generic_fentry_process_filter+0x25cb>
    6927:      	addl	$0xc, %ebx
    692a:      	movq	$0x1, (%rcx)
    6931:      	movl	%ebx, %eax
    6933:      	movl	%eax, %ecx
    6935:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    693b:      	cmpl	$0x4, (%rcx,%r10)
    6940:      	movq	0x50(%rsp), %rcx
    6945:      	jne	0x696c <generic_fentry_process_filter+0x250c>
    6947:      	movq	0x5eb8(%rcx), %rax
    694e:      	andl	$0x1f, %eax
    6951:      	movb	$0x1, 0x5ec1(%rcx,%rax)
    6959:      	movb	$0x1, 0x5ee0(%rcx)
    6960:      	movb	$0x1, 0x5ec0(%rcx)
    6967:      	jmp	0x6a2b <generic_fentry_process_filter+0x25cb>
    696c:      	addl	$0x4, %eax
    696f:      	andl	$0x3ff, %eax            # imm = 0x3FF
    6974:      	movl	(%rax,%r10), %r14d
    6978:      	movl	0x4(%rax,%r10), %ebx
    697d:      	movl	0x8(%rax,%r10), %ebp
    6982:      	movq	0xc(%rax,%r10), %r15
    6987:      	movl	$0xe, %eax
    698c:      	callq	*%rax
    698e:      	shrq	$0x20, %rax
    6992:      	movl	%eax, 0x60(%rsp)
    6996:      	movq	(%rip), %rdi            # 0x699d <generic_fentry_process_filter+0x253d>
    699d:      	leaq	0x60(%rsp), %rsi
    69a2:      	movl	$0x1, %eax
    69a7:      	callq	*%rax
    69a9:      	testq	%rax, %rax
    69ac:      	je	0x6a2b <generic_fentry_process_filter+0x25cb>
    69ae:      	testl	%ebp, %ebp
    69b0:      	je	0x69c4 <generic_fentry_process_filter+0x2564>
    69b2:      	cmpl	$0x2, %r14d
    69b6:      	ja	0x6a2b <generic_fentry_process_filter+0x25cb>
    69b8:      	movq	0x50(%rsp), %rcx
    69bd:      	cmpl	%ebp, 0x44(%rcx)
    69c0:      	jne	0x69ca <generic_fentry_process_filter+0x256a>
    69c2:      	jmp	0x6a2b <generic_fentry_process_filter+0x25cb>
    69c4:      	cmpl	$0x2, %r14d
    69c8:      	ja	0x6a2b <generic_fentry_process_filter+0x25cb>
    69ca:      	movq	0x50(%rax,%r14,8), %rax
    69cf:      	movq	0x50(%rsp), %rcx
    69d4:      	movq	0x48(%rcx,%r14,8), %rcx
    69d9:      	movq	%rcx, %rdx
    69dc:      	xorq	%rax, %rdx
    69df:      	testq	%r15, %rdx
    69e2:      	je	0x69eb <generic_fentry_process_filter+0x258b>
    69e4:      	cmpl	$0x5, %ebx
    69e7:      	jne	0x6a2b <generic_fentry_process_filter+0x25cb>
    69e9:      	jmp	0x69f5 <generic_fentry_process_filter+0x2595>
    69eb:      	cmpq	%rcx, %rax
    69ee:      	je	0x6a2b <generic_fentry_process_filter+0x25cb>
    69f0:      	cmpl	$0x6, %ebx
    69f3:      	jne	0x6a2b <generic_fentry_process_filter+0x25cb>
    69f5:      	movq	0x50(%rsp), %rcx
    69fa:      	movq	$0x1, 0x5ef0(%rcx)
    6a05:      	jmp	0x6947 <generic_fentry_process_filter+0x24e7>
    6a0a:      	movq	$0x1, (%rcx)
    6a11:      	testl	$0x200, %ebp            # imm = 0x200
    6a17:      	je	0x6a2b <generic_fentry_process_filter+0x25cb>
    6a19:      	movl	0x4c(%rax), %eax
    6a1c:      	testl	%eax, %eax
    6a1e:      	jne	0x6919 <generic_fentry_process_filter+0x24b9>
    6a24:      	movq	$0x1, (%rcx)
    6a2b:      	movq	0x50(%rsp), %rcx
    6a30:      	movq	0x5eb8(%rcx), %rax
    6a37:      	incq	%rax
    6a3a:      	movq	%rax, 0x5eb8(%rcx)
    6a41:      	cmpq	0xc0(%rsp), %rax
    6a49:      	jbe	0x6a97 <generic_fentry_process_filter+0x2637>
    6a4b:      	movq	0x38(%rsp), %rdx
    6a50:      	movl	(%rdx), %eax
    6a52:      	movl	%eax, 0x10(%rcx)
    6a55:      	movq	0x8(%rdx), %rax
    6a59:      	movq	%rax, 0x18(%rcx)
    6a5d:      	cmpb	$0x0, 0x5ec0(%rcx)
    6a64:      	movq	0xb8(%rsp), %rbx
    6a6c:      	je	0x6a83 <generic_fentry_process_filter+0x2623>
    6a6e:      	movq	(%rip), %rsi            # 0x6a75 <generic_fentry_process_filter+0x2615>
    6a75:      	xorl	%ecx, %ecx
    6a77:      	movl	$0xc, %eax
    6a7c:      	movq	%rbx, %rdi
    6a7f:      	xorl	%edx, %edx
    6a81:      	callq	*%rax
    6a83:      	xorl	%eax, %eax
    6a85:      	addq	$0xe8, %rsp
    6a8c:      	popq	%rbx
    6a8d:      	popq	%r12
    6a8f:      	popq	%r13
    6a91:      	popq	%r14
    6a93:      	popq	%r15
    6a95:      	popq	%rbp
    6a96:      	retq
    6a97:      	movq	(%rip), %rsi            # 0x6a9e <generic_fentry_process_filter+0x263e>
    6a9e:      	movl	$0x2, %ecx
    6aa3:      	movl	$0xc, %eax
    6aa8:      	movq	0xb8(%rsp), %rdi
    6ab0:      	movl	$0x2, %edx
    6ab5:      	jmp	0x6a81 <generic_fentry_process_filter+0x2621>
    6ab7:      	nopw	(%rax,%rax)

0000000000006ac0 <generic_fentry_filter_arg>:
    6ac0:      	pushq	%rbp
    6ac1:      	pushq	%r15
    6ac3:      	pushq	%r14
    6ac5:      	pushq	%r13
    6ac7:      	pushq	%r12
    6ac9:      	pushq	%rbx
    6aca:      	subq	$0xb8, %rsp
    6ad1:      	movq	%rdi, %r12
    6ad4:      	movl	$0x0, 0xa4(%rsp)
    6adf:      	movq	(%rip), %rdi            # 0x6ae6 <generic_fentry_filter_arg+0x26>
    6ae6:      	leaq	0xa4(%rsp), %rsi
    6aee:      	movl	$0x1, %eax
    6af3:      	callq	*%rax
    6af5:      	testq	%rax, %rax
    6af8:      	je	0x6cb2 <generic_fentry_filter_arg+0x1f2>
    6afe:      	movq	%rax, %r14
    6b01:      	movl	0x5f00(%rax), %ebx
    6b07:      	leaq	0x5ef8(%rax), %rsi
    6b0e:      	movq	(%rip), %rdi            # 0x6b15 <generic_fentry_filter_arg+0x55>
    6b15:      	movl	$0x1, %eax
    6b1a:      	callq	*%rax
    6b1c:      	testq	%rax, %rax
    6b1f:      	je	0x6c97 <generic_fentry_filter_arg+0x1d7>
    6b25:      	cmpb	$0x0, 0x5ee0(%r14)
    6b2d:      	je	0x6c97 <generic_fentry_filter_arg+0x1d7>
    6b33:      	movq	%rax, %r15
    6b36:      	movq	%r12, 0x98(%rsp)
    6b3e:      	movl	%ebx, %eax
    6b40:      	andl	$0x7, %eax
    6b43:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
    6b4c:      	je	0x6bdd <generic_fentry_filter_arg+0x11d>
    6b52:      	movl	%eax, %eax
    6b54:      	movl	0x4(%r15,%rax,4), %ecx
    6b59:      	leaq	(%rcx,%rax,4), %rdx
    6b5d:      	addq	$0x4, %rdx
    6b61:      	leaq	(%rcx,%rax,4), %rax
    6b65:      	addq	$0x8, %rax
    6b69:      	andl	$0x3ff, %eax            # imm = 0x3FF
    6b6e:      	movl	(%rax,%r15), %eax
    6b72:      	addq	%rdx, %rax
    6b75:      	addq	$0x4, %rax
    6b79:      	movl	%eax, %ecx
    6b7b:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    6b81:      	movl	(%rcx,%r15), %ecx
    6b85:      	addq	%rax, %rcx
    6b88:      	movl	%ecx, %eax
    6b8a:      	andl	$0x3ff, %eax            # imm = 0x3FF
    6b8f:      	movl	(%rax,%r15), %eax
    6b93:      	addq	%rcx, %rax
    6b96:      	movl	%eax, %ecx
    6b98:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    6b9e:      	movl	(%rcx,%r15), %ecx
    6ba2:      	addq	%rax, %rcx
    6ba5:      	movl	%ecx, %eax
    6ba7:      	andl	$0x3ff, %eax            # imm = 0x3FF
    6bac:      	movl	(%rax,%r15), %r9d
    6bb0:      	addq	%rcx, %r9
    6bb3:      	movl	%r9d, %edi
    6bb6:      	andl	$0x3ff, %edi            # imm = 0x3FF
    6bbc:      	cmpl	$0x19, (%r15,%rdi)
    6bc1:      	jae	0x6c39 <generic_fentry_filter_arg+0x179>
    6bc3:      	cmpq	$0x1, %rdi
    6bc7:      	movq	0x98(%rsp), %r12
    6bcf:      	je	0x6c97 <generic_fentry_filter_arg+0x1d7>
    6bd5:      	testl	%edi, %edi
    6bd7:      	jne	0x6c6d <generic_fentry_filter_arg+0x1ad>
    6bdd:      	cmpl	$0x1, %ebx
    6be0:      	jg	0x6c06 <generic_fentry_filter_arg+0x146>
    6be2:      	cmpl	$-0x1, %ebx
    6be5:      	movq	0x98(%rsp), %rdi
    6bed:      	je	0x6cc6 <generic_fentry_filter_arg+0x206>
    6bf3:      	testl	%ebx, %ebx
    6bf5:      	je	0x6cd2 <generic_fentry_filter_arg+0x212>
    6bfb:      	cmpl	$0x1, %ebx
    6bfe:      	je	0x6ce1 <generic_fentry_filter_arg+0x221>
    6c04:      	jmp	0x6c29 <generic_fentry_filter_arg+0x169>
    6c06:      	cmpl	$0x2, %ebx
    6c09:      	movq	0x98(%rsp), %rdi
    6c11:      	je	0x6cf0 <generic_fentry_filter_arg+0x230>
    6c17:      	cmpl	$0x3, %ebx
    6c1a:      	je	0x6cff <generic_fentry_filter_arg+0x23f>
    6c20:      	cmpl	$0x4, %ebx
    6c23:      	je	0x6d0e <generic_fentry_filter_arg+0x24e>
    6c29:      	cmpl	$0x4, %ebx
    6c2c:      	jg	0x6d3c <generic_fentry_filter_arg+0x27c>
    6c32:      	incl	%ebx
    6c34:      	jmp	0x6d1d <generic_fentry_filter_arg+0x25d>
    6c39:      	leaq	(%r15,%rdi), %rax
    6c3d:      	movq	%rax, 0xb0(%rsp)
    6c45:      	xorl	%r11d, %r11d
    6c48:      	leaq	0x70(%rsp), %rax
    6c4d:      	movq	%rax, 0x28(%rsp)
    6c52:      	movq	%rbx, 0xa8(%rsp)
    6c5a:      	movq	%rdi, (%rsp)
    6c5e:      	movq	%r9, 0x8(%rsp)
    6c63:      	movq	%r15, 0x68(%rsp)
    6c68:      	jmp	0x6dae <generic_fentry_filter_arg+0x2ee>
    6c6d:      	movl	%edi, 0x5f04(%r14)
    6c74:      	movq	(%rip), %rsi            # 0x6c7b <generic_fentry_filter_arg+0x1bb>
    6c7b:      	movl	$0x4, %ecx
    6c80:      	movl	$0xc, %eax
    6c85:      	movq	0x98(%rsp), %r12
    6c8d:      	movq	%r12, %rdi
    6c90:      	movl	$0x4, %edx
    6c95:      	callq	*%rax
    6c97:      	movq	(%rip), %rsi            # 0x6c9e <generic_fentry_filter_arg+0x1de>
    6c9e:      	movl	$0x5, %ecx
    6ca3:      	movl	$0xc, %eax
    6ca8:      	movq	%r12, %rdi
    6cab:      	movl	$0x5, %edx
    6cb0:      	callq	*%rax
    6cb2:      	xorl	%eax, %eax
    6cb4:      	addq	$0xb8, %rsp
    6cbb:      	popq	%rbx
    6cbc:      	popq	%r12
    6cbe:      	popq	%r13
    6cc0:      	popq	%r14
    6cc2:      	popq	%r15
    6cc4:      	popq	%rbp
    6cc5:      	retq
    6cc6:      	xorl	%ebx, %ebx
    6cc8:      	cmpb	$0x0, 0x5ec1(%r14)
    6cd0:      	jne	0x6d1d <generic_fentry_filter_arg+0x25d>
    6cd2:      	movl	$0x1, %ebx
    6cd7:      	cmpb	$0x0, 0x5ec2(%r14)
    6cdf:      	jne	0x6d1d <generic_fentry_filter_arg+0x25d>
    6ce1:      	movl	$0x2, %ebx
    6ce6:      	cmpb	$0x0, 0x5ec3(%r14)
    6cee:      	jne	0x6d1d <generic_fentry_filter_arg+0x25d>
    6cf0:      	movl	$0x3, %ebx
    6cf5:      	cmpb	$0x0, 0x5ec4(%r14)
    6cfd:      	jne	0x6d1d <generic_fentry_filter_arg+0x25d>
    6cff:      	movl	$0x4, %ebx
    6d04:      	cmpb	$0x0, 0x5ec5(%r14)
    6d0c:      	jne	0x6d1d <generic_fentry_filter_arg+0x25d>
    6d0e:      	movl	$0x5, %ebx
    6d13:      	cmpb	$0x0, 0x5ec6(%r14)
    6d1b:      	je	0x6d3c <generic_fentry_filter_arg+0x27c>
    6d1d:      	movl	%ebx, 0x5f00(%r14)
    6d24:      	movq	(%rip), %rsi            # 0x6d2b <generic_fentry_filter_arg+0x26b>
    6d2b:      	movl	$0x3, %ecx
    6d30:      	movl	$0xc, %eax
    6d35:      	movl	$0x3, %edx
    6d3a:      	callq	*%rax
    6d3c:      	movq	0x60(%r14), %rbx
    6d40:      	movl	$0xe, %eax
    6d45:      	callq	*%rax
    6d47:      	movq	%rbx, 0x38(%rsp)
    6d4c:      	movq	%rax, 0x40(%rsp)
    6d51:      	movq	(%rip), %rdi            # 0x6d58 <generic_fentry_filter_arg+0x298>
    6d58:      	leaq	0x38(%rsp), %rsi
    6d5d:      	movl	$0x1, %eax
    6d62:      	callq	*%rax
    6d64:      	testq	%rax, %rax
    6d67:      	je	0x6cb2 <generic_fentry_filter_arg+0x1f2>
    6d6d:      	movq	(%rip), %rdi            # 0x6d74 <generic_fentry_filter_arg+0x2b4>
    6d74:      	leaq	0x38(%rsp), %rsi
    6d79:      	movl	$0x3, %eax
    6d7e:      	callq	*%rax
    6d80:      	jmp	0x6cb2 <generic_fentry_filter_arg+0x1f2>
    6d85:      	xorl	%ebx, %ebx
    6d87:      	cmpl	$0x3, %eax
    6d8a:      	sete	%bl
    6d8d:      	nopl	(%rax)
    6d90:      	testq	%rbx, %rbx
    6d93:      	movq	0xa8(%rsp), %rbx
    6d9b:      	je	0x6bdd <generic_fentry_filter_arg+0x11d>
    6da1:      	incq	%r11
    6da4:      	cmpq	$0x5, %r11
    6da8:      	je	0x6bc3 <generic_fentry_filter_arg+0x103>
    6dae:      	movq	0xb0(%rsp), %rax
    6db6:      	movl	0x4(%rax,%r11,4), %r13d
    6dbb:      	testl	$0x3ff, %r13d           # imm = 0x3FF
    6dc2:      	je	0x6bc3 <generic_fentry_filter_arg+0x103>
    6dc8:      	addl	%r9d, %r13d
    6dcb:      	andl	$0x3ff, %r13d           # imm = 0x3FF
    6dd2:      	movl	0x4(%r15,%r13), %eax
    6dd7:      	cmpl	$0x23, %eax
    6dda:      	je	0x6bdd <generic_fentry_filter_arg+0x11d>
    6de0:      	addq	%r15, %r13
    6de3:      	movl	(%r13), %ecx
    6de7:      	cmpq	$0x4, %rcx
    6deb:      	ja	0x6bdd <generic_fentry_filter_arg+0x11d>
    6df1:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    6dfa:      	jne	0x6bdd <generic_fentry_filter_arg+0x11d>
    6e00:      	movq	0x5e78(%r14,%rcx,8), %rcx
    6e08:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    6e0e:      	leaq	(%r14,%rcx), %r12
    6e12:      	addq	$0x90, %r12
    6e19:      	movl	0xc(%r13), %ecx
    6e1d:      	cmpl	$0x1b, %ecx
    6e20:      	jle	0x6e3d <generic_fentry_filter_arg+0x37d>
    6e22:      	cmpl	$0x25, %ecx
    6e25:      	jg	0x6e68 <generic_fentry_filter_arg+0x3a8>
    6e27:      	leal	-0x1c(%rcx), %edx
    6e2a:      	cmpl	$0x9, %edx
    6e2d:      	jb	0x6eae <generic_fentry_filter_arg+0x3ee>
    6e2f:      	cmpl	$0x25, %ecx
    6e32:      	je	0x70c6 <generic_fentry_filter_arg+0x606>
    6e38:      	jmp	0x6da1 <generic_fentry_filter_arg+0x2e1>
    6e3d:      	cmpl	$0x9, %ecx
    6e40:      	jle	0x6e8e <generic_fentry_filter_arg+0x3ce>
    6e42:      	leal	-0xa(%rcx), %edx
    6e45:      	cmpl	$0x4, %edx
    6e48:      	jb	0x6eae <generic_fentry_filter_arg+0x3ee>
    6e4a:      	leal	-0xf(%rcx), %edx
    6e4d:      	cmpl	$0x2, %edx
    6e50:      	jb	0x70c6 <generic_fentry_filter_arg+0x606>
    6e56:      	cmpl	$0x11, %ecx
    6e59:      	jne	0x6da1 <generic_fentry_filter_arg+0x2e1>
    6e5f:      	addq	$0x4, %r12
    6e63:      	jmp	0x70c6 <generic_fentry_filter_arg+0x606>
    6e68:      	cmpl	$0x29, %ecx
    6e6b:      	jg	0x7033 <generic_fentry_filter_arg+0x573>
    6e71:      	leal	-0x26(%rcx), %edx
    6e74:      	cmpl	$0x2, %edx
    6e77:      	jb	0x6fc9 <generic_fentry_filter_arg+0x509>
    6e7d:      	leal	-0x28(%rcx), %edx
    6e80:      	cmpl	$0x2, %edx
    6e83:      	jb	0x6f74 <generic_fentry_filter_arg+0x4b4>
    6e89:      	jmp	0x6da1 <generic_fentry_filter_arg+0x2e1>
    6e8e:      	cmpl	$0x4, %ecx
    6e91:      	jg	0x6f61 <generic_fentry_filter_arg+0x4a1>
    6e97:      	cmpl	$0x1, %ecx
    6e9a:      	je	0x6eae <generic_fentry_filter_arg+0x3ee>
    6e9c:      	cmpl	$0x2, %ecx
    6e9f:      	je	0x76b3 <generic_fentry_filter_arg+0xbf3>
    6ea5:      	cmpl	$0x4, %ecx
    6ea8:      	jne	0x6da1 <generic_fentry_filter_arg+0x2e1>
    6eae:      	cmpl	$0xb, %ecx
    6eb1:      	jle	0x6f3e <generic_fentry_filter_arg+0x47e>
    6eb7:      	cmpl	$0x24, %ecx
    6eba:      	ja	0x71eb <generic_fentry_filter_arg+0x72b>
    6ec0:      	movl	%ecx, %edx
    6ec2:      	movabsq	$0x1e00000000, %rsi     # imm = 0x1E00000000
    6ecc:      	btq	%rdx, %rsi
    6ed0:      	jb	0x7007 <generic_fentry_filter_arg+0x547>
    6ed6:      	movl	$0x60000000, %esi       # imm = 0x60000000
    6edb:      	btq	%rdx, %rsi
    6edf:      	jb	0x7485 <generic_fentry_filter_arg+0x9c5>
    6ee5:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    6eef:      	btq	%rdx, %rsi
    6ef3:      	jae	0x71eb <generic_fentry_filter_arg+0x72b>
    6ef9:      	cmpl	$0x20, %eax
    6efc:      	ja	0x6bdd <generic_fentry_filter_arg+0x11d>
    6f02:      	movl	%eax, %ecx
    6f04:      	movl	$0x101e, %edx           # imm = 0x101E
    6f09:      	btq	%rcx, %rdx
    6f0d:      	jae	0x7bc9 <generic_fentry_filter_arg+0x1109>
    6f13:      	movl	0x10(%r13), %ecx
    6f17:      	cmpl	$0x2, %eax
    6f1a:      	jle	0x80f3 <generic_fentry_filter_arg+0x1633>
    6f20:      	leal	-0x3(%rax), %edx
    6f23:      	cmpl	$0x2, %edx
    6f26:      	jae	0x884e <generic_fentry_filter_arg+0x1d8e>
    6f2c:      	movzbl	(%r12), %edx
    6f31:      	cmpl	%edx, %ecx
    6f33:      	je	0x6d85 <generic_fentry_filter_arg+0x2c5>
    6f39:      	jmp	0x8986 <generic_fentry_filter_arg+0x1ec6>
    6f3e:      	leal	-0xa(%rcx), %edx
    6f41:      	cmpl	$0x2, %edx
    6f44:      	jb	0x7733 <generic_fentry_filter_arg+0xc73>
    6f4a:      	cmpl	$0x1, %ecx
    6f4d:      	je	0x71f7 <generic_fentry_filter_arg+0x737>
    6f53:      	cmpl	$0x4, %ecx
    6f56:      	je	0x71f7 <generic_fentry_filter_arg+0x737>
    6f5c:      	jmp	0x6da1 <generic_fentry_filter_arg+0x2e1>
    6f61:      	cmpl	$0x5, %ecx
    6f64:      	je	0x6f74 <generic_fentry_filter_arg+0x4b4>
    6f66:      	cmpl	$0x6, %ecx
    6f69:      	je	0x6fc9 <generic_fentry_filter_arg+0x509>
    6f6b:      	cmpl	$0x7, %ecx
    6f6e:      	jne	0x6da1 <generic_fentry_filter_arg+0x2e1>
    6f74:      	movq	$0x0, 0x58(%rsp)
    6f7d:      	movq	$0x0, 0x50(%rsp)
    6f86:      	movq	$0x0, 0x48(%rsp)
    6f8f:      	movq	$0x0, 0x40(%rsp)
    6f98:      	movq	$0x0, 0x38(%rsp)
    6fa1:      	cmpl	$0x27, %ecx
    6fa4:      	jg	0x7235 <generic_fentry_filter_arg+0x775>
    6faa:      	cmpl	$0x5, %ecx
    6fad:      	je	0x7898 <generic_fentry_filter_arg+0xdd8>
    6fb3:      	movq	%r12, %rdx
    6fb6:      	movl	$0x0, %ebx
    6fbb:      	cmpl	$0x7, %ecx
    6fbe:      	je	0x789a <generic_fentry_filter_arg+0xdda>
    6fc4:      	jmp	0x6d90 <generic_fentry_filter_arg+0x2d0>
    6fc9:      	movl	(%r12), %ebp
    6fcd:      	addq	$0x4, %r12
    6fd1:      	movq	%r12, 0x18(%rsp)
    6fd6:      	cmpl	$0x19, %eax
    6fd9:      	jg	0x72b8 <generic_fentry_filter_arg+0x7f8>
    6fdf:      	leal	-0x3(%rax), %ecx
    6fe2:      	cmpl	$0x2, %ecx
    6fe5:      	jb	0x7afb <generic_fentry_filter_arg+0x103b>
    6feb:      	cmpl	$0x8, %eax
    6fee:      	je	0x7a65 <generic_fentry_filter_arg+0xfa5>
    6ff4:      	movl	$0x0, %ebx
    6ff9:      	cmpl	$0x9, %eax
    6ffc:      	je	0x72d8 <generic_fentry_filter_arg+0x818>
    7002:      	jmp	0xa0fb <generic_fentry_filter_arg+0x363b>
    7007:      	cmpl	$0x9, %eax
    700a:      	jle	0x76a2 <generic_fentry_filter_arg+0xbe2>
    7010:      	cmpl	$0x1d, %eax
    7013:      	jg	0x7a1f <generic_fentry_filter_arg+0xf5f>
    7019:      	leal	-0xa(%rax), %edx
    701c:      	cmpl	$0x2, %edx
    701f:      	jb	0x77c0 <generic_fentry_filter_arg+0xd00>
    7025:      	cmpl	$0xc, %eax
    7028:      	je	0x7749 <generic_fentry_filter_arg+0xc89>
    702e:      	jmp	0x6bdd <generic_fentry_filter_arg+0x11d>
    7033:      	cmpl	$0x2a, %ecx
    7036:      	je	0x70c6 <generic_fentry_filter_arg+0x606>
    703c:      	cmpl	$0x2c, %ecx
    703f:      	jne	0x6da1 <generic_fentry_filter_arg+0x2e1>
    7045:      	movq	%r12, %rcx
    7048:      	leaq	0x4(%r12), %r8
    704d:      	movzbl	0x3(%r12), %ebp
    7053:      	movzbl	%bpl, %esi
    7057:      	cmpl	$0x19, %eax
    705a:      	jg	0x7e3c <generic_fentry_filter_arg+0x137c>
    7060:      	leal	-0x3(%rax), %ecx
    7063:      	cmpl	$0x2, %ecx
    7066:      	jae	0x83e1 <generic_fentry_filter_arg+0x1921>
    706c:      	movl	$0x0, 0x70(%rsp)
    7074:      	movl	$0x100, %ebx            # imm = 0x100
    7079:      	cmpb	$-0x70, %bpl
    707d:      	ja	0x80c3 <generic_fentry_filter_arg+0x1603>
    7083:      	testb	%bpl, %bpl
    7086:      	je	0x7098 <generic_fentry_filter_arg+0x5d8>
    7088:      	movl	%esi, %eax
    708a:      	movl	$0x18, %ecx
    708f:      	cltd
    7090:      	idivl	%ecx
    7092:      	movl	%esi, %ebx
    7094:      	testl	%edx, %edx
    7096:      	je	0x70ba <generic_fentry_filter_arg+0x5fa>
    7098:      	movl	%esi, %eax
    709a:      	movl	$0x18, %ecx
    709f:      	cltd
    70a0:      	idivl	%ecx
    70a2:      	shll	$0x3, %eax
    70a5:      	leal	(%rax,%rax,2), %eax
    70a8:      	addl	$0x18, %eax
    70ab:      	movzwl	%ax, %ebx
    70ae:      	cmpl	$0x90, %ebx
    70b4:      	ja	0x80c3 <generic_fentry_filter_arg+0x1603>
    70ba:      	movl	%ebx, %eax
    70bc:      	cltd
    70bd:      	idivl	%ecx
    70bf:      	decl	%eax
    70c1:      	jmp	0x8fa9 <generic_fentry_filter_arg+0x24e9>
    70c6:      	movl	(%r12), %ebp
    70ca:      	movl	%eax, %ecx
    70cc:      	andl	$-0x2, %ecx
    70cf:      	cmpl	$0x24, %ecx
    70d2:      	je	0x70dc <generic_fentry_filter_arg+0x61c>
    70d4:      	testl	%ebp, %ebp
    70d6:      	je	0x6bdd <generic_fentry_filter_arg+0x11d>
    70dc:      	cmpl	$0x25, %eax
    70df:      	ja	0x740f <generic_fentry_filter_arg+0x94f>
    70e5:      	movl	%eax, %ecx
    70e7:      	movl	$0x4000100, %edx        # imm = 0x4000100
    70ec:      	btq	%rcx, %rdx
    70f0:      	jb	0x7600 <generic_fentry_filter_arg+0xb40>
    70f6:      	movl	$0x8000200, %edx        # imm = 0x8000200
    70fb:      	btq	%rcx, %rdx
    70ff:      	jb	0x74ca <generic_fentry_filter_arg+0xa0a>
    7105:      	movabsq	$0x3000000000, %rdx     # imm = 0x3000000000
    710f:      	btq	%rcx, %rdx
    7113:      	jae	0x740f <generic_fentry_filter_arg+0x94f>
    7119:      	movw	$0x0, 0x38(%rsp)
    7120:      	cmpl	$0x1000, %ebp           # imm = 0x1000
    7126:      	ja	0x98ac <generic_fentry_filter_arg+0x2dec>
    712c:      	movq	%r11, 0x10(%rsp)
    7131:      	leaq	(%r12,%rbp), %rcx
    7135:      	addq	$0x8, %rcx
    7139:      	movl	$0x4, %eax
    713e:      	leaq	0x38(%rsp), %rdi
    7143:      	movl	$0x2, %edx
    7148:      	movl	(%r12), %ecx
    714c:      	leaq	(%r12,%rcx), %rdx
    7150:      	addq	$0x8, %rdx
    7154:      	movl	$0x2, %esi
    7159:      	callq	*%rax
    715b:      	movl	0x10(%r13), %ecx
    715f:      	testl	%ecx, %ecx
    7161:      	je	0x9d53 <generic_fentry_filter_arg+0x3293>
    7167:      	movzwl	0x38(%rsp), %eax
    716c:      	andl	$0xf000, %eax           # imm = 0xF000
    7171:      	movl	$0x1, %ebx
    7176:      	cmpl	%eax, %ecx
    7178:      	je	0x9d55 <generic_fentry_filter_arg+0x3295>
    717e:      	movl	0x8(%r13), %ecx
    7182:      	cmpl	$0xd, %ecx
    7185:      	movq	(%rsp), %rdi
    7189:      	movq	0x8(%rsp), %r9
    718e:      	movq	0x10(%rsp), %r11
    7193:      	jb	0x98ac <generic_fentry_filter_arg+0x2dec>
    7199:      	movl	0x14(%r13), %edx
    719d:      	testl	%edx, %edx
    719f:      	je	0x98ac <generic_fentry_filter_arg+0x2dec>
    71a5:      	cmpl	%eax, %edx
    71a7:      	je	0x9d63 <generic_fentry_filter_arg+0x32a3>
    71ad:      	cmpl	$0x11, %ecx
    71b0:      	jb	0x98ac <generic_fentry_filter_arg+0x2dec>
    71b6:      	movl	0x18(%r13), %edx
    71ba:      	testl	%edx, %edx
    71bc:      	je	0x98ac <generic_fentry_filter_arg+0x2dec>
    71c2:      	cmpl	%eax, %edx
    71c4:      	je	0x9d63 <generic_fentry_filter_arg+0x32a3>
    71ca:      	cmpl	$0x15, %ecx
    71cd:      	jb	0xa12d <generic_fentry_filter_arg+0x366d>
    71d3:      	movl	0x1c(%r13), %ecx
    71d7:      	testl	%ecx, %ecx
    71d9:      	je	0xa12d <generic_fentry_filter_arg+0x366d>
    71df:      	xorl	%ebx, %ebx
    71e1:      	cmpl	%eax, %ecx
    71e3:      	sete	%bl
    71e6:      	jmp	0xa12f <generic_fentry_filter_arg+0x366f>
    71eb:      	leal	-0xc(%rcx), %edx
    71ee:      	cmpl	$0x2, %edx
    71f1:      	jae	0x772a <generic_fentry_filter_arg+0xc6a>
    71f7:      	cmpl	$0x20, %eax
    71fa:      	ja	0x6bdd <generic_fentry_filter_arg+0x11d>
    7200:      	movl	%eax, %edx
    7202:      	movl	$0x101e, %esi           # imm = 0x101E
    7207:      	btq	%rdx, %rsi
    720b:      	jae	0x7254 <generic_fentry_filter_arg+0x794>
    720d:      	movl	0x10(%r13), %edx
    7211:      	cmpl	$0x2, %eax
    7214:      	jle	0x76f2 <generic_fentry_filter_arg+0xc32>
    721a:      	leal	-0x3(%rax), %esi
    721d:      	cmpl	$0x2, %esi
    7220:      	jae	0x7bb1 <generic_fentry_filter_arg+0x10f1>
    7226:      	cmpl	%edx, (%r12)
    722a:      	je	0x6d85 <generic_fentry_filter_arg+0x2c5>
    7230:      	jmp	0x8ce7 <generic_fentry_filter_arg+0x2227>
    7235:      	cmpl	$0x28, %ecx
    7238:      	je	0x786a <generic_fentry_filter_arg+0xdaa>
    723e:      	movq	%r12, %rdx
    7241:      	movl	$0x0, %ebx
    7246:      	cmpl	$0x29, %ecx
    7249:      	je	0x789a <generic_fentry_filter_arg+0xdda>
    724f:      	jmp	0x6d90 <generic_fentry_filter_arg+0x2d0>
    7254:      	movl	$0xc00, %esi            # imm = 0xC00
    7259:      	btq	%rdx, %rsi
    725d:      	jb	0x7827 <generic_fentry_filter_arg+0xd67>
    7263:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    726d:      	btq	%rdx, %rsi
    7271:      	jae	0x6bdd <generic_fentry_filter_arg+0x11d>
    7277:      	cmpl	$0x1f, %eax
    727a:      	jne	0x7e09 <generic_fentry_filter_arg+0x1349>
    7280:      	movl	0x10(%r13), %esi
    7284:      	movl	0x14(%r13), %edx
    7288:      	cmpl	$0xc, %ecx
    728b:      	ja	0x8a03 <generic_fentry_filter_arg+0x1f43>
    7291:      	movl	$0x1402, %eax           # imm = 0x1402
    7296:      	btl	%ecx, %eax
    7299:      	jae	0x8a03 <generic_fentry_filter_arg+0x1f43>
    729f:      	movl	(%r12), %eax
    72a3:      	cmpl	%eax, %esi
    72a5:      	jg	0x8a13 <generic_fentry_filter_arg+0x1f53>
    72ab:      	cmpl	%edx, %eax
    72ad:      	jle	0x6da1 <generic_fentry_filter_arg+0x2e1>
    72b3:      	jmp	0x8a13 <generic_fentry_filter_arg+0x1f53>
    72b8:      	cmpl	$0x20, %eax
    72bb:      	jg	0x791f <generic_fentry_filter_arg+0xe5f>
    72c1:      	cmpl	$0x1a, %eax
    72c4:      	je	0x7a65 <generic_fentry_filter_arg+0xfa5>
    72ca:      	movl	$0x0, %ebx
    72cf:      	cmpl	$0x1b, %eax
    72d2:      	jne	0xa0fb <generic_fentry_filter_arg+0x363b>
    72d8:      	movq	%r11, 0x10(%rsp)
    72dd:      	movl	0x10(%r13), %eax
    72e1:      	movl	%eax, 0x38(%rsp)
    72e5:      	movl	$0x0, 0x70(%rsp)
    72ed:      	movl	$0x1, %eax
    72f2:      	leaq	0x38(%rsp), %rsi
    72f7:      	movq	(%rip), %rdi            # 0x72fe <generic_fentry_filter_arg+0x83e>
    72fe:      	callq	*%rax
    7300:      	testl	%ebp, %ebp
    7302:      	je	0xa0eb <generic_fentry_filter_arg+0x362b>
    7308:      	movq	%rax, %r12
    730b:      	movl	$0x0, %ebx
    7310:      	testq	%rax, %rax
    7313:      	je	0xa0ed <generic_fentry_filter_arg+0x362d>
    7319:      	movl	$0x1, %eax
    731e:      	movq	0x28(%rsp), %rsi
    7323:      	movq	(%rip), %rdi            # 0x732a <generic_fentry_filter_arg+0x86a>
    732a:      	callq	*%rax
    732c:      	testq	%rax, %rax
    732f:      	je	0xa0eb <generic_fentry_filter_arg+0x362b>
    7335:      	movq	%rax, %rdi
    7338:      	movq	%r12, 0x20(%rsp)
    733d:      	cmpl	$0x7f, %ebp
    7340:      	movl	$0x7f, %eax
    7345:      	cmovbl	%ebp, %eax
    7348:      	shll	$0x3, %eax
    734b:      	movl	%eax, (%rdi)
    734d:      	movq	%rbp, %rax
    7350:      	negq	%rax
    7353:      	movl	$0x3, %ecx
    7358:      	subq	%rbp, %rcx
    735b:      	leal	-0x4(%rbp), %edx
    735e:      	movq	%rdi, 0x60(%rsp)
    7363:      	addq	$0x7, %rdi
    7367:      	movl	$0x2, %r8d
    736d:      	subq	%rbp, %r8
    7370:      	leal	-0x3(%rbp), %r9d
    7374:      	movl	$0x1, %r10d
    737a:      	subq	%rbp, %r10
    737d:      	leal	-0x2(%rbp), %r11d
    7381:      	decl	%ebp
    7383:      	xorl	%ebx, %ebx
    7385:      	movq	0x18(%rsp), %rsi
    738a:      	leal	(%rbx,%rbp), %r12d
    738e:      	andl	$0xfff, %r12d           # imm = 0xFFF
    7395:      	movzbl	(%rsi,%r12), %r12d
    739a:      	movb	%r12b, -0x3(%rdi)
    739e:      	cmpq	%rbx, %r10
    73a1:      	je	0x73fb <generic_fentry_filter_arg+0x93b>
    73a3:      	leal	(%r11,%rbx), %r12d
    73a7:      	andl	$0xfff, %r12d           # imm = 0xFFF
    73ae:      	movzbl	(%rsi,%r12), %r12d
    73b3:      	movb	%r12b, -0x2(%rdi)
    73b7:      	cmpq	%rbx, %r8
    73ba:      	je	0x73fb <generic_fentry_filter_arg+0x93b>
    73bc:      	leal	(%r9,%rbx), %r12d
    73c0:      	andl	$0xfff, %r12d           # imm = 0xFFF
    73c7:      	movzbl	(%rsi,%r12), %r12d
    73cc:      	movb	%r12b, -0x1(%rdi)
    73d0:      	cmpq	%rbx, %rcx
    73d3:      	je	0x73fb <generic_fentry_filter_arg+0x93b>
    73d5:      	cmpq	$-0x7c, %rbx
    73d9:      	je	0x73fb <generic_fentry_filter_arg+0x93b>
    73db:      	leal	(%rdx,%rbx), %r12d
    73df:      	andl	$0xfff, %r12d           # imm = 0xFFF
    73e6:      	movzbl	(%rsi,%r12), %r12d
    73eb:      	movb	%r12b, (%rdi)
    73ee:      	addq	$-0x4, %rbx
    73f2:      	addq	$0x4, %rdi
    73f6:      	cmpq	%rbx, %rax
    73f9:      	jne	0x738a <generic_fentry_filter_arg+0x8ca>
    73fb:      	movl	$0x1, %eax
    7400:      	movq	0x20(%rsp), %rdi
    7405:      	movq	0x60(%rsp), %rsi
    740a:      	jmp	0x85a8 <generic_fentry_filter_arg+0x1ae8>
    740f:      	addl	$-0x3, %eax
    7412:      	cmpl	$0x2, %eax
    7415:      	jae	0x98ac <generic_fentry_filter_arg+0x2dec>
    741b:      	movl	$0x0, 0x70(%rsp)
    7423:      	cmpl	$0x1000, %ebp           # imm = 0x1000
    7429:      	ja	0x98ac <generic_fentry_filter_arg+0x2dec>
    742f:      	movzwl	%bp, %eax
    7432:      	cmpl	$0x90, %eax
    7437:      	movq	%r11, 0x10(%rsp)
    743c:      	ja	0x8203 <generic_fentry_filter_arg+0x1743>
    7442:      	testw	%bp, %bp
    7445:      	je	0x7457 <generic_fentry_filter_arg+0x997>
    7447:      	movl	%ebp, %eax
    7449:      	movl	$0x18, %ecx
    744e:      	cltd
    744f:      	idivl	%ecx
    7451:      	movl	%ebp, %esi
    7453:      	testl	%edx, %edx
    7455:      	je	0x7479 <generic_fentry_filter_arg+0x9b9>
    7457:      	movl	%ebp, %eax
    7459:      	movl	$0x18, %ecx
    745e:      	cltd
    745f:      	idivl	%ecx
    7461:      	shll	$0x3, %eax
    7464:      	leal	(%rax,%rax,2), %eax
    7467:      	addl	$0x18, %eax
    746a:      	movzwl	%ax, %esi
    746d:      	cmpl	$0x90, %esi
    7473:      	ja	0x823b <generic_fentry_filter_arg+0x177b>
    7479:      	movl	%esi, %eax
    747b:      	cltd
    747c:      	idivl	%ecx
    747e:      	decl	%eax
    7480:      	jmp	0x8e0f <generic_fentry_filter_arg+0x234f>
    7485:      	cmpl	$0x20, %eax
    7488:      	ja	0x6bdd <generic_fentry_filter_arg+0x11d>
    748e:      	movl	%eax, %ecx
    7490:      	movl	$0x101e, %edx           # imm = 0x101E
    7495:      	btq	%rcx, %rdx
    7499:      	jae	0x7bfc <generic_fentry_filter_arg+0x113c>
    749f:      	movl	0x10(%r13), %ecx
    74a3:      	cmpl	$0x2, %eax
    74a6:      	jle	0x8117 <generic_fentry_filter_arg+0x1657>
    74ac:      	leal	-0x3(%rax), %edx
    74af:      	cmpl	$0x2, %edx
    74b2:      	jae	0x8869 <generic_fentry_filter_arg+0x1da9>
    74b8:      	movzwl	(%r12), %edx
    74bd:      	cmpl	%edx, %ecx
    74bf:      	je	0x6d85 <generic_fentry_filter_arg+0x2c5>
    74c5:      	jmp	0x89cb <generic_fentry_filter_arg+0x1f0b>
    74ca:      	movq	%r11, 0x10(%rsp)
    74cf:      	movl	0x10(%r13), %eax
    74d3:      	movl	%eax, 0x38(%rsp)
    74d7:      	movl	$0x0, 0x70(%rsp)
    74df:      	movl	$0x1, %eax
    74e4:      	leaq	0x38(%rsp), %rsi
    74e9:      	movq	(%rip), %rdi            # 0x74f0 <generic_fentry_filter_arg+0xa30>
    74f0:      	callq	*%rax
    74f2:      	testl	%ebp, %ebp
    74f4:      	je	0x9d53 <generic_fentry_filter_arg+0x3293>
    74fa:      	movl	$0x0, %ebx
    74ff:      	testq	%rax, %rax
    7502:      	je	0x9d55 <generic_fentry_filter_arg+0x3295>
    7508:      	movq	%rax, 0x18(%rsp)
    750d:      	movl	$0x1, %eax
    7512:      	movq	0x28(%rsp), %rsi
    7517:      	movq	(%rip), %rdi            # 0x751e <generic_fentry_filter_arg+0xa5e>
    751e:      	callq	*%rax
    7520:      	testq	%rax, %rax
    7523:      	je	0x9d53 <generic_fentry_filter_arg+0x3293>
    7529:      	movq	%rax, %rdi
    752c:      	cmpl	$0x7f, %ebp
    752f:      	movl	$0x7f, %eax
    7534:      	cmovbl	%ebp, %eax
    7537:      	shll	$0x3, %eax
    753a:      	movl	%eax, (%rdi)
    753c:      	movq	%rbp, %rax
    753f:      	negq	%rax
    7542:      	movl	$0x3, %ecx
    7547:      	subq	%rbp, %rcx
    754a:      	leal	-0x4(%rbp), %edx
    754d:      	movq	%rdi, 0x20(%rsp)
    7552:      	addq	$0x7, %rdi
    7556:      	movl	$0x2, %r8d
    755c:      	subq	%rbp, %r8
    755f:      	leal	-0x3(%rbp), %r9d
    7563:      	movl	$0x1, %r10d
    7569:      	subq	%rbp, %r10
    756c:      	leal	-0x2(%rbp), %r11d
    7570:      	decl	%ebp
    7572:      	xorl	%ebx, %ebx
    7574:      	movq	%r12, %rsi
    7577:      	leal	(%rbx,%rbp), %r12d
    757b:      	andl	$0xfff, %r12d           # imm = 0xFFF
    7582:      	movzbl	0x4(%rsi,%r12), %r12d
    7588:      	movb	%r12b, -0x3(%rdi)
    758c:      	cmpq	%rbx, %r10
    758f:      	je	0x75ec <generic_fentry_filter_arg+0xb2c>
    7591:      	leal	(%r11,%rbx), %r12d
    7595:      	andl	$0xfff, %r12d           # imm = 0xFFF
    759c:      	movzbl	0x4(%rsi,%r12), %r12d
    75a2:      	movb	%r12b, -0x2(%rdi)
    75a6:      	cmpq	%rbx, %r8
    75a9:      	je	0x75ec <generic_fentry_filter_arg+0xb2c>
    75ab:      	leal	(%r9,%rbx), %r12d
    75af:      	andl	$0xfff, %r12d           # imm = 0xFFF
    75b6:      	movzbl	0x4(%rsi,%r12), %r12d
    75bc:      	movb	%r12b, -0x1(%rdi)
    75c0:      	cmpq	%rbx, %rcx
    75c3:      	je	0x75ec <generic_fentry_filter_arg+0xb2c>
    75c5:      	cmpq	$-0x7c, %rbx
    75c9:      	je	0x75ec <generic_fentry_filter_arg+0xb2c>
    75cb:      	leal	(%rdx,%rbx), %r12d
    75cf:      	andl	$0xfff, %r12d           # imm = 0xFFF
    75d6:      	movzbl	0x4(%rsi,%r12), %r12d
    75dc:      	movb	%r12b, (%rdi)
    75df:      	addq	$-0x4, %rbx
    75e3:      	addq	$0x4, %rdi
    75e7:      	cmpq	%rbx, %rax
    75ea:      	jne	0x7577 <generic_fentry_filter_arg+0xab7>
    75ec:      	movl	$0x1, %eax
    75f1:      	movq	0x18(%rsp), %rdi
    75f6:      	movq	0x20(%rsp), %rsi
    75fb:      	jmp	0x9d47 <generic_fentry_filter_arg+0x3287>
    7600:      	movq	%r11, 0x10(%rsp)
    7605:      	movl	0x10(%r13), %eax
    7609:      	movl	%eax, 0x38(%rsp)
    760d:      	movl	$0x0, 0x70(%rsp)
    7615:      	movl	$0x1, %eax
    761a:      	leaq	0x38(%rsp), %rsi
    761f:      	movq	(%rip), %rdi            # 0x7626 <generic_fentry_filter_arg+0xb66>
    7626:      	callq	*%rax
    7628:      	testl	%ebp, %ebp
    762a:      	je	0x9d53 <generic_fentry_filter_arg+0x3293>
    7630:      	movl	$0x0, %ebx
    7635:      	testq	%rax, %rax
    7638:      	je	0x9d55 <generic_fentry_filter_arg+0x3295>
    763e:      	movq	%rax, 0x18(%rsp)
    7643:      	movl	$0x1, %eax
    7648:      	movq	0x28(%rsp), %rsi
    764d:      	movq	(%rip), %rdi            # 0x7654 <generic_fentry_filter_arg+0xb94>
    7654:      	callq	*%rax
    7656:      	testq	%rax, %rax
    7659:      	je	0x9d53 <generic_fentry_filter_arg+0x3293>
    765f:      	movq	%rax, %rbx
    7662:      	addq	$0x4, %r12
    7666:      	cmpl	$0xff, %ebp
    766c:      	movl	$0xff, %eax
    7671:      	cmovael	%eax, %ebp
    7674:      	leal	(,%rbp,8), %eax
    767b:      	movl	%eax, (%rbx)
    767d:      	movq	%rbx, %rdi
    7680:      	addq	$0x4, %rdi
    7684:      	movl	$0x4, %eax
    7689:      	movl	%ebp, %esi
    768b:      	movq	%r12, %rdx
    768e:      	callq	*%rax
    7690:      	movl	$0x1, %eax
    7695:      	movq	0x18(%rsp), %rdi
    769a:      	movq	%rbx, %rsi
    769d:      	jmp	0x9d47 <generic_fentry_filter_arg+0x3287>
    76a2:      	leal	-0x1(%rax), %edx
    76a5:      	cmpl	$0x4, %edx
    76a8:      	jb	0x7749 <generic_fentry_filter_arg+0xc89>
    76ae:      	jmp	0x6bdd <generic_fentry_filter_arg+0x11d>
    76b3:      	movl	0x4(%r12), %ebp
    76b8:      	addq	$0x8, %r12
    76bc:      	movq	%r12, 0x18(%rsp)
    76c1:      	cmpl	$0x19, %eax
    76c4:      	jg	0x7cb2 <generic_fentry_filter_arg+0x11f2>
    76ca:      	leal	-0x3(%rax), %ecx
    76cd:      	cmpl	$0x2, %ecx
    76d0:      	jb	0x85b7 <generic_fentry_filter_arg+0x1af7>
    76d6:      	cmpl	$0x8, %eax
    76d9:      	je	0x8511 <generic_fentry_filter_arg+0x1a51>
    76df:      	movl	$0x0, %ebx
    76e4:      	cmpl	$0x9, %eax
    76e7:      	je	0x7cd2 <generic_fentry_filter_arg+0x1212>
    76ed:      	jmp	0xa0fb <generic_fentry_filter_arg+0x363b>
    76f2:      	cmpl	$0x1, %eax
    76f5:      	je	0x7fa4 <generic_fentry_filter_arg+0x14e4>
    76fb:      	cmpl	$0x2, %eax
    76fe:      	jne	0x8ce7 <generic_fentry_filter_arg+0x2227>
    7704:      	cmpl	$0xc, %ecx
    7707:      	ja	0x8cdd <generic_fentry_filter_arg+0x221d>
    770d:      	movl	$0x1402, %esi           # imm = 0x1402
    7712:      	btl	%ecx, %esi
    7715:      	jae	0x8cdd <generic_fentry_filter_arg+0x221d>
    771b:      	cmpl	%edx, (%r12)
    771f:      	jl	0x6da1 <generic_fentry_filter_arg+0x2e1>
    7725:      	jmp	0x8ce7 <generic_fentry_filter_arg+0x2227>
    772a:      	cmpl	$0x1c, %ecx
    772d:      	jne	0x6da1 <generic_fentry_filter_arg+0x2e1>
    7733:      	cmpl	$0x20, %eax
    7736:      	ja	0x6bdd <generic_fentry_filter_arg+0x11d>
    773c:      	movl	%eax, %edx
    773e:      	movl	$0x101e, %esi           # imm = 0x101E
    7743:      	btq	%rdx, %rsi
    7747:      	jae	0x776d <generic_fentry_filter_arg+0xcad>
    7749:      	movq	0x10(%r13), %rdx
    774d:      	cmpl	$0x2, %eax
    7750:      	jle	0x7791 <generic_fentry_filter_arg+0xcd1>
    7752:      	leal	-0x3(%rax), %esi
    7755:      	cmpl	$0x2, %esi
    7758:      	jae	0x7a07 <generic_fentry_filter_arg+0xf47>
    775e:      	cmpq	%rdx, (%r12)
    7762:      	je	0x6d85 <generic_fentry_filter_arg+0x2c5>
    7768:      	jmp	0x87d2 <generic_fentry_filter_arg+0x1d12>
    776d:      	movl	$0xc00, %esi            # imm = 0xC00
    7772:      	btq	%rdx, %rsi
    7776:      	jb	0x77c0 <generic_fentry_filter_arg+0xd00>
    7778:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    7782:      	btq	%rdx, %rsi
    7786:      	jb	0x7a2b <generic_fentry_filter_arg+0xf6b>
    778c:      	jmp	0x6bdd <generic_fentry_filter_arg+0x11d>
    7791:      	cmpl	$0x1, %eax
    7794:      	je	0x7c95 <generic_fentry_filter_arg+0x11d5>
    779a:      	cmpl	$0x2, %eax
    779d:      	jne	0x87d2 <generic_fentry_filter_arg+0x1d12>
    77a3:      	cmpl	$0xc, %ecx
    77a6:      	je	0x77b1 <generic_fentry_filter_arg+0xcf1>
    77a8:      	cmpl	$0xa, %ecx
    77ab:      	jne	0x87c8 <generic_fentry_filter_arg+0x1d08>
    77b1:      	cmpq	%rdx, (%r12)
    77b5:      	jl	0x6da1 <generic_fentry_filter_arg+0x2e1>
    77bb:      	jmp	0x87d2 <generic_fentry_filter_arg+0x1d12>
    77c0:      	movq	%r11, %rbp
    77c3:      	movzbl	0x10(%r13), %eax
    77c8:      	movl	%eax, 0x70(%rsp)
    77cc:      	movl	$0x1, %eax
    77d1:      	movq	0x28(%rsp), %rsi
    77d6:      	movq	(%rip), %rdi            # 0x77dd <generic_fentry_filter_arg+0xd1d>
    77dd:      	callq	*%rax
    77df:      	testq	%rax, %rax
    77e2:      	je	0x84fe <generic_fentry_filter_arg+0x1a3e>
    77e8:      	movq	%rax, %rdi
    77eb:      	movq	(%r12), %rax
    77ef:      	movq	%rax, 0x38(%rsp)
    77f4:      	movl	$0x1, %eax
    77f9:      	leaq	0x38(%rsp), %rsi
    77fe:      	callq	*%rax
    7800:      	movl	0x4(%r13), %ecx
    7804:      	cmpl	$0xb, %ecx
    7807:      	je	0x81e9 <generic_fentry_filter_arg+0x1729>
    780d:      	cmpl	$0xa, %ecx
    7810:      	movq	(%rsp), %rdi
    7814:      	movq	0x8(%rsp), %r9
    7819:      	movq	%rbp, %r11
    781c:      	je	0x82ef <generic_fentry_filter_arg+0x182f>
    7822:      	jmp	0x82fd <generic_fentry_filter_arg+0x183d>
    7827:      	movq	%r11, %rbp
    782a:      	movzbl	0x10(%r13), %eax
    782f:      	movl	%eax, 0x70(%rsp)
    7833:      	movl	$0x1, %eax
    7838:      	movq	0x28(%rsp), %rsi
    783d:      	movq	(%rip), %rdi            # 0x7844 <generic_fentry_filter_arg+0xd84>
    7844:      	callq	*%rax
    7846:      	testq	%rax, %rax
    7849:      	je	0x84fe <generic_fentry_filter_arg+0x1a3e>
    784f:      	movq	%rax, %rdi
    7852:      	movl	(%r12), %eax
    7856:      	movq	%rax, 0x38(%rsp)
    785b:      	movl	$0x1, %eax
    7860:      	leaq	0x38(%rsp), %rsi
    7865:      	jmp	0x84c5 <generic_fentry_filter_arg+0x1a05>
    786a:      	movzwl	(%r12), %edx
    786f:      	movw	%dx, 0x5e(%rsp)
    7874:      	movzwl	0x2(%r12), %edx
    787a:      	movw	%dx, 0x58(%rsp)
    787f:      	movq	0x8(%r12), %rdx
    7884:      	movq	%rdx, 0x38(%rsp)
    7889:      	movq	0x10(%r12), %rdx
    788e:      	movq	%rdx, 0x40(%rsp)
    7893:      	leaq	0x38(%rsp), %r12
    7898:      	xorl	%edx, %edx
    789a:      	cmpl	$0x13, %eax
    789d:      	jle	0x78c6 <generic_fentry_filter_arg+0xe06>
    789f:      	cmpl	$0x17, %eax
    78a2:      	jg	0x78fa <generic_fentry_filter_arg+0xe3a>
    78a4:      	leal	-0x14(%rax), %ecx
    78a7:      	cmpl	$0x2, %ecx
    78aa:      	jb	0x7e79 <generic_fentry_filter_arg+0x13b9>
    78b0:      	leal	-0x16(%rax), %ecx
    78b3:      	movl	$0x0, %ebx
    78b8:      	cmpl	$0x2, %ecx
    78bb:      	jb	0x7e6e <generic_fentry_filter_arg+0x13ae>
    78c1:      	jmp	0x6d90 <generic_fentry_filter_arg+0x2d0>
    78c6:      	cmpl	$0xf, %eax
    78c9:      	jle	0x7b60 <generic_fentry_filter_arg+0x10a0>
    78cf:      	cmpl	$0x11, %eax
    78d2:      	jg	0x7e5b <generic_fentry_filter_arg+0x139b>
    78d8:      	cmpl	$0x10, %eax
    78db:      	je	0x7e6e <generic_fentry_filter_arg+0x13ae>
    78e1:      	movl	$0x0, %ebx
    78e6:      	cmpl	$0x11, %eax
    78e9:      	jne	0x6d90 <generic_fentry_filter_arg+0x2d0>
    78ef:      	movzwl	0x24(%r12), %ebx
    78f5:      	jmp	0x8672 <generic_fentry_filter_arg+0x1bb2>
    78fa:      	cmpl	$0x1b, %eax
    78fd:      	jg	0x7eba <generic_fentry_filter_arg+0x13fa>
    7903:      	cmpl	$0x18, %eax
    7906:      	je	0x7ef9 <generic_fentry_filter_arg+0x1439>
    790c:      	movl	$0x0, %ebx
    7911:      	cmpl	$0x19, %eax
    7914:      	je	0x7eea <generic_fentry_filter_arg+0x142a>
    791a:      	jmp	0x6d90 <generic_fentry_filter_arg+0x2d0>
    791f:      	cmpl	$0x21, %eax
    7922:      	je	0x7fca <generic_fentry_filter_arg+0x150a>
    7928:      	movl	$0x0, %ebx
    792d:      	cmpl	$0x22, %eax
    7930:      	jne	0xa0fb <generic_fentry_filter_arg+0x363b>
    7936:      	xorl	%ebx, %ebx
    7938:      	xorl	%r12d, %r12d
    793b:      	movq	%r11, %r15
    793e:      	movl	0x10(%r13,%rbx,4), %eax
    7943:      	movl	%eax, 0x38(%rsp)
    7947:      	movl	$0x1, %eax
    794c:      	leaq	0x38(%rsp), %rsi
    7951:      	movq	(%rip), %rdi            # 0x7958 <generic_fentry_filter_arg+0xe98>
    7958:      	callq	*%rax
    795a:      	testq	%rax, %rax
    795d:      	je	0x8c76 <generic_fentry_filter_arg+0x21b6>
    7963:      	testl	%ebp, %ebp
    7965:      	movq	%r15, %r11
    7968:      	movq	0x68(%rsp), %r15
    796d:      	je	0x79e4 <generic_fentry_filter_arg+0xf24>
    796f:      	movq	0x18(%rsp), %rdx
    7974:      	xorl	%ecx, %ecx
    7976:      	jmp	0x7983 <generic_fentry_filter_arg+0xec3>
    7978:      	incq	%rcx
    797b:      	incq	%rdx
    797e:      	cmpq	%rbp, %rcx
    7981:      	je	0x79e4 <generic_fentry_filter_arg+0xf24>
    7983:      	xorl	%esi, %esi
    7985:      	nopw	%cs:(%rax,%rax)
    7990:      	leaq	(%rcx,%rsi), %rdi
    7994:      	cmpq	%rbp, %rdi
    7997:      	jae	0x7978 <generic_fentry_filter_arg+0xeb8>
    7999:      	movsbl	(%rax,%rsi), %edi
    799d:      	testl	%edi, %edi
    799f:      	je	0x79dc <generic_fentry_filter_arg+0xf1c>
    79a1:      	movsbl	(%rdx,%rsi), %r9d
    79a6:      	leal	-0x41(%r9), %r10d
    79aa:      	movl	%r9d, %r8d
    79ad:      	orl	$0x20, %r8d
    79b1:      	cmpl	$0x1a, %r10d
    79b5:      	cmovael	%r9d, %r8d
    79b9:      	leal	-0x41(%rdi), %r10d
    79bd:      	movl	%edi, %r9d
    79c0:      	orl	$0x20, %r9d
    79c4:      	cmpl	$0x1a, %r10d
    79c8:      	cmovael	%edi, %r9d
    79cc:      	cmpq	$0x62, %rsi
    79d0:      	ja	0x7978 <generic_fentry_filter_arg+0xeb8>
    79d2:      	incq	%rsi
    79d5:      	cmpl	%r9d, %r8d
    79d8:      	je	0x7990 <generic_fentry_filter_arg+0xed0>
    79da:      	jmp	0x7978 <generic_fentry_filter_arg+0xeb8>
    79dc:      	testl	%ecx, %ecx
    79de:      	jns	0x914e <generic_fentry_filter_arg+0x268e>
    79e4:      	leal	0xc(%r12), %eax
    79e9:      	cmpl	0x8(%r13), %eax
    79ed:      	jae	0x7a00 <generic_fentry_filter_arg+0xf40>
    79ef:      	addl	$0x4, %r12d
    79f3:      	incq	%rbx
    79f6:      	cmpq	$0x64, %rbx
    79fa:      	jne	0x793b <generic_fentry_filter_arg+0xe7b>
    7a00:      	xorl	%ebx, %ebx
    7a02:      	jmp	0x9153 <generic_fentry_filter_arg+0x2693>
    7a07:      	cmpl	$0xc, %eax
    7a0a:      	jne	0x87d2 <generic_fentry_filter_arg+0x1d12>
    7a10:      	testq	%rdx, (%r12)
    7a14:      	jne	0x6da1 <generic_fentry_filter_arg+0x2e1>
    7a1a:      	jmp	0x87d2 <generic_fentry_filter_arg+0x1d12>
    7a1f:      	leal	-0x1f(%rax), %edx
    7a22:      	cmpl	$0x2, %edx
    7a25:      	jae	0x8307 <generic_fentry_filter_arg+0x1847>
    7a2b:      	cmpl	$0x1f, %eax
    7a2e:      	jne	0x7b85 <generic_fentry_filter_arg+0x10c5>
    7a34:      	movq	0x10(%r13), %rsi
    7a38:      	movq	0x18(%r13), %rdx
    7a3c:      	cmpl	$0xa, %ecx
    7a3f:      	je	0x7a4a <generic_fentry_filter_arg+0xf8a>
    7a41:      	cmpl	$0xc, %ecx
    7a44:      	jne	0x85d2 <generic_fentry_filter_arg+0x1b12>
    7a4a:      	movq	(%r12), %rax
    7a4e:      	cmpq	%rax, %rsi
    7a51:      	jg	0x85e4 <generic_fentry_filter_arg+0x1b24>
    7a57:      	cmpq	%rdx, %rax
    7a5a:      	jle	0x6da1 <generic_fentry_filter_arg+0x2e1>
    7a60:      	jmp	0x85e4 <generic_fentry_filter_arg+0x1b24>
    7a65:      	movq	%r11, 0x10(%rsp)
    7a6a:      	movl	0x10(%r13), %eax
    7a6e:      	movl	%eax, 0x38(%rsp)
    7a72:      	movl	$0x0, 0x70(%rsp)
    7a7a:      	movl	$0x1, %eax
    7a7f:      	leaq	0x38(%rsp), %rsi
    7a84:      	movq	(%rip), %rdi            # 0x7a8b <generic_fentry_filter_arg+0xfcb>
    7a8b:      	callq	*%rax
    7a8d:      	testl	%ebp, %ebp
    7a8f:      	je	0xa0eb <generic_fentry_filter_arg+0x362b>
    7a95:      	movq	%rax, %r12
    7a98:      	movl	$0x0, %ebx
    7a9d:      	testq	%rax, %rax
    7aa0:      	je	0xa0ed <generic_fentry_filter_arg+0x362d>
    7aa6:      	movl	$0x1, %eax
    7aab:      	movq	0x28(%rsp), %rsi
    7ab0:      	movq	(%rip), %rdi            # 0x7ab7 <generic_fentry_filter_arg+0xff7>
    7ab7:      	callq	*%rax
    7ab9:      	testq	%rax, %rax
    7abc:      	je	0xa0eb <generic_fentry_filter_arg+0x362b>
    7ac2:      	cmpl	$0xff, %ebp
    7ac8:      	movl	$0xff, %ecx
    7acd:      	cmovael	%ecx, %ebp
    7ad0:      	leal	(,%rbp,8), %ecx
    7ad7:      	movl	%ecx, (%rax)
    7ad9:      	movq	%rax, %rdi
    7adc:      	addq	$0x4, %rdi
    7ae0:      	movq	%rax, %rbx
    7ae3:      	movl	$0x4, %eax
    7ae8:      	movq	0x18(%rsp), %rdx
    7aed:      	movl	%ebp, %esi
    7aef:      	callq	*%rax
    7af1:      	movl	$0x1, %eax
    7af6:      	jmp	0x85a2 <generic_fentry_filter_arg+0x1ae2>
    7afb:      	movl	$0x0, 0x70(%rsp)
    7b03:      	cmpl	$0x1000, %ebp           # imm = 0x1000
    7b09:      	ja	0x85cb <generic_fentry_filter_arg+0x1b0b>
    7b0f:      	movzwl	%bp, %eax
    7b12:      	cmpl	$0x90, %eax
    7b17:      	ja	0x8754 <generic_fentry_filter_arg+0x1c94>
    7b1d:      	testw	%bp, %bp
    7b20:      	je	0x7b32 <generic_fentry_filter_arg+0x1072>
    7b22:      	movl	%ebp, %eax
    7b24:      	movl	$0x18, %ecx
    7b29:      	cltd
    7b2a:      	idivl	%ecx
    7b2c:      	movl	%ebp, %esi
    7b2e:      	testl	%edx, %edx
    7b30:      	je	0x7b54 <generic_fentry_filter_arg+0x1094>
    7b32:      	movl	%ebp, %eax
    7b34:      	movl	$0x18, %ecx
    7b39:      	cltd
    7b3a:      	idivl	%ecx
    7b3c:      	shll	$0x3, %eax
    7b3f:      	leal	(%rax,%rax,2), %eax
    7b42:      	addl	$0x18, %eax
    7b45:      	movzwl	%ax, %esi
    7b48:      	cmpl	$0x90, %esi
    7b4e:      	ja	0x878c <generic_fentry_filter_arg+0x1ccc>
    7b54:      	movl	%esi, %eax
    7b56:      	cltd
    7b57:      	idivl	%ecx
    7b59:      	decl	%eax
    7b5b:      	jmp	0x939c <generic_fentry_filter_arg+0x28dc>
    7b60:      	cmpl	$0xd, %eax
    7b63:      	je	0x7ef9 <generic_fentry_filter_arg+0x1439>
    7b69:      	cmpl	$0xe, %eax
    7b6c:      	je	0x7eea <generic_fentry_filter_arg+0x142a>
    7b72:      	movl	$0x0, %ebx
    7b77:      	cmpl	$0xf, %eax
    7b7a:      	je	0x7e79 <generic_fentry_filter_arg+0x13b9>
    7b80:      	jmp	0x6d90 <generic_fentry_filter_arg+0x2d0>
    7b85:      	movq	0x10(%r13), %rsi
    7b89:      	movq	0x18(%r13), %rax
    7b8d:      	cmpl	$0xc, %ecx
    7b90:      	je	0x7b9b <generic_fentry_filter_arg+0x10db>
    7b92:      	cmpl	$0xa, %ecx
    7b95:      	jne	0x8622 <generic_fentry_filter_arg+0x1b62>
    7b9b:      	movq	(%r12), %rdx
    7b9f:      	cmpq	%rdx, %rsi
    7ba2:      	setle	%sil
    7ba6:      	cmpq	%rax, %rdx
    7ba9:      	setle	%al
    7bac:      	jmp	0x8633 <generic_fentry_filter_arg+0x1b73>
    7bb1:      	cmpl	$0xc, %eax
    7bb4:      	jne	0x8ce7 <generic_fentry_filter_arg+0x2227>
    7bba:      	testl	%edx, (%r12)
    7bbe:      	jne	0x6da1 <generic_fentry_filter_arg+0x2e1>
    7bc4:      	jmp	0x8ce7 <generic_fentry_filter_arg+0x2227>
    7bc9:      	movl	$0xc00, %edx            # imm = 0xC00
    7bce:      	btq	%rcx, %rdx
    7bd2:      	jb	0x813b <generic_fentry_filter_arg+0x167b>
    7bd8:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    7be2:      	btq	%rcx, %rdx
    7be6:      	jae	0x6bdd <generic_fentry_filter_arg+0x11d>
    7bec:      	cmpl	$0x1f, %eax
    7bef:      	jne	0x88bd <generic_fentry_filter_arg+0x1dfd>
    7bf5:      	movzbl	(%r12), %eax
    7bfa:      	jmp	0x7c2d <generic_fentry_filter_arg+0x116d>
    7bfc:      	movl	$0xc00, %edx            # imm = 0xC00
    7c01:      	btq	%rcx, %rdx
    7c05:      	jb	0x817f <generic_fentry_filter_arg+0x16bf>
    7c0b:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    7c15:      	btq	%rcx, %rdx
    7c19:      	jae	0x6bdd <generic_fentry_filter_arg+0x11d>
    7c1f:      	cmpl	$0x1f, %eax
    7c22:      	jne	0x88c8 <generic_fentry_filter_arg+0x1e08>
    7c28:      	movzwl	(%r12), %eax
    7c2d:      	cmpl	%eax, 0x10(%r13)
    7c31:      	ja	0x7c3d <generic_fentry_filter_arg+0x117d>
    7c33:      	cmpl	%eax, 0x14(%r13)
    7c37:      	jae	0x6da1 <generic_fentry_filter_arg+0x2e1>
    7c3d:      	movl	0x8(%r13), %ecx
    7c41:      	cmpl	$0x11, %ecx
    7c44:      	jb	0x6bdd <generic_fentry_filter_arg+0x11d>
    7c4a:      	cmpl	%eax, 0x18(%r13)
    7c4e:      	ja	0x7c5a <generic_fentry_filter_arg+0x119a>
    7c50:      	cmpl	%eax, 0x1c(%r13)
    7c54:      	jae	0x6da1 <generic_fentry_filter_arg+0x2e1>
    7c5a:      	cmpl	$0x19, %ecx
    7c5d:      	jb	0x6bdd <generic_fentry_filter_arg+0x11d>
    7c63:      	cmpl	%eax, 0x20(%r13)
    7c67:      	ja	0x7c73 <generic_fentry_filter_arg+0x11b3>
    7c69:      	cmpl	%eax, 0x24(%r13)
    7c6d:      	jae	0x6da1 <generic_fentry_filter_arg+0x2e1>
    7c73:      	cmpl	$0x21, %ecx
    7c76:      	jb	0x6bdd <generic_fentry_filter_arg+0x11d>
    7c7c:      	cmpl	%eax, 0x28(%r13)
    7c80:      	ja	0x6bdd <generic_fentry_filter_arg+0x11d>
    7c86:      	cmpl	%eax, 0x2c(%r13)
    7c8a:      	jae	0x6da1 <generic_fentry_filter_arg+0x2e1>
    7c90:      	jmp	0x6bdd <generic_fentry_filter_arg+0x11d>
    7c95:      	cmpl	$0xc, %ecx
    7c98:      	je	0x7ca3 <generic_fentry_filter_arg+0x11e3>
    7c9a:      	cmpl	$0xa, %ecx
    7c9d:      	jne	0x87bc <generic_fentry_filter_arg+0x1cfc>
    7ca3:      	cmpq	%rdx, (%r12)
    7ca7:      	jg	0x6da1 <generic_fentry_filter_arg+0x2e1>
    7cad:      	jmp	0x87d2 <generic_fentry_filter_arg+0x1d12>
    7cb2:      	cmpl	$0x20, %eax
    7cb5:      	jg	0x834d <generic_fentry_filter_arg+0x188d>
    7cbb:      	cmpl	$0x1a, %eax
    7cbe:      	je	0x8511 <generic_fentry_filter_arg+0x1a51>
    7cc4:      	movl	$0x0, %ebx
    7cc9:      	cmpl	$0x1b, %eax
    7ccc:      	jne	0xa0fb <generic_fentry_filter_arg+0x363b>
    7cd2:      	movq	%r11, 0x10(%rsp)
    7cd7:      	movl	0x10(%r13), %eax
    7cdb:      	movl	%eax, 0x38(%rsp)
    7cdf:      	movl	$0x0, 0x70(%rsp)
    7ce7:      	movl	$0x1, %eax
    7cec:      	leaq	0x38(%rsp), %rsi
    7cf1:      	movq	(%rip), %rdi            # 0x7cf8 <generic_fentry_filter_arg+0x1238>
    7cf8:      	callq	*%rax
    7cfa:      	testl	%ebp, %ebp
    7cfc:      	je	0xa0eb <generic_fentry_filter_arg+0x362b>
    7d02:      	movq	%rax, %r12
    7d05:      	movl	$0x0, %ebx
    7d0a:      	testq	%rax, %rax
    7d0d:      	je	0xa0ed <generic_fentry_filter_arg+0x362d>
    7d13:      	movl	$0x1, %eax
    7d18:      	movq	0x28(%rsp), %rsi
    7d1d:      	movq	(%rip), %rdi            # 0x7d24 <generic_fentry_filter_arg+0x1264>
    7d24:      	callq	*%rax
    7d26:      	testq	%rax, %rax
    7d29:      	je	0xa0eb <generic_fentry_filter_arg+0x362b>
    7d2f:      	movq	%rax, %rdi
    7d32:      	movq	%r12, 0x20(%rsp)
    7d37:      	cmpl	$0x7f, %ebp
    7d3a:      	movl	$0x7f, %eax
    7d3f:      	cmovbl	%ebp, %eax
    7d42:      	shll	$0x3, %eax
    7d45:      	movl	%eax, (%rdi)
    7d47:      	movq	%rbp, %rax
    7d4a:      	negq	%rax
    7d4d:      	movl	$0x3, %ecx
    7d52:      	subq	%rbp, %rcx
    7d55:      	leal	-0x4(%rbp), %edx
    7d58:      	movq	%rdi, 0x60(%rsp)
    7d5d:      	addq	$0x7, %rdi
    7d61:      	movl	$0x2, %r8d
    7d67:      	subq	%rbp, %r8
    7d6a:      	leal	-0x3(%rbp), %r9d
    7d6e:      	movl	$0x1, %r10d
    7d74:      	subq	%rbp, %r10
    7d77:      	leal	-0x2(%rbp), %r11d
    7d7b:      	decl	%ebp
    7d7d:      	xorl	%ebx, %ebx
    7d7f:      	movq	0x18(%rsp), %rsi
    7d84:      	leal	(%rbx,%rbp), %r12d
    7d88:      	andl	$0xfff, %r12d           # imm = 0xFFF
    7d8f:      	movzbl	(%rsi,%r12), %r12d
    7d94:      	movb	%r12b, -0x3(%rdi)
    7d98:      	cmpq	%rbx, %r10
    7d9b:      	je	0x7df5 <generic_fentry_filter_arg+0x1335>
    7d9d:      	leal	(%r11,%rbx), %r12d
    7da1:      	andl	$0xfff, %r12d           # imm = 0xFFF
    7da8:      	movzbl	(%rsi,%r12), %r12d
    7dad:      	movb	%r12b, -0x2(%rdi)
    7db1:      	cmpq	%rbx, %r8
    7db4:      	je	0x7df5 <generic_fentry_filter_arg+0x1335>
    7db6:      	leal	(%r9,%rbx), %r12d
    7dba:      	andl	$0xfff, %r12d           # imm = 0xFFF
    7dc1:      	movzbl	(%rsi,%r12), %r12d
    7dc6:      	movb	%r12b, -0x1(%rdi)
    7dca:      	cmpq	%rbx, %rcx
    7dcd:      	je	0x7df5 <generic_fentry_filter_arg+0x1335>
    7dcf:      	cmpq	$-0x7c, %rbx
    7dd3:      	je	0x7df5 <generic_fentry_filter_arg+0x1335>
    7dd5:      	leal	(%rdx,%rbx), %r12d
    7dd9:      	andl	$0xfff, %r12d           # imm = 0xFFF
    7de0:      	movzbl	(%rsi,%r12), %r12d
    7de5:      	movb	%r12b, (%rdi)
    7de8:      	addq	$-0x4, %rbx
    7dec:      	addq	$0x4, %rdi
    7df0:      	cmpq	%rbx, %rax
    7df3:      	jne	0x7d84 <generic_fentry_filter_arg+0x12c4>
    7df5:      	movl	$0x1, %eax
    7dfa:      	movq	0x20(%rsp), %rdi
    7dff:      	movq	0x60(%rsp), %rsi
    7e04:      	jmp	0x85a8 <generic_fentry_filter_arg+0x1ae8>
    7e09:      	movl	0x10(%r13), %esi
    7e0d:      	movl	0x14(%r13), %eax
    7e11:      	cmpl	$0xc, %ecx
    7e14:      	ja	0x8a5a <generic_fentry_filter_arg+0x1f9a>
    7e1a:      	movl	$0x1402, %edx           # imm = 0x1402
    7e1f:      	btl	%ecx, %edx
    7e22:      	jae	0x8a5a <generic_fentry_filter_arg+0x1f9a>
    7e28:      	movl	(%r12), %edx
    7e2c:      	cmpl	%edx, %esi
    7e2e:      	setle	%sil
    7e32:      	cmpl	%eax, %edx
    7e34:      	setle	%al
    7e37:      	jmp	0x8a69 <generic_fentry_filter_arg+0x1fa9>
    7e3c:      	cmpl	$0x1c, %eax
    7e3f:      	je	0x848a <generic_fentry_filter_arg+0x19ca>
    7e45:      	movq	%r8, 0x18(%rsp)
    7e4a:      	movq	%rsi, %r12
    7e4d:      	cmpl	$0x1a, %eax
    7e50:      	je	0x83f2 <generic_fentry_filter_arg+0x1932>
    7e56:      	jmp	0x6bdd <generic_fentry_filter_arg+0x11d>
    7e5b:      	cmpl	$0x12, %eax
    7e5e:      	je	0x7e79 <generic_fentry_filter_arg+0x13b9>
    7e60:      	movl	$0x0, %ebx
    7e65:      	cmpl	$0x13, %eax
    7e68:      	jne	0x6d90 <generic_fentry_filter_arg+0x2d0>
    7e6e:      	movq	%r12, %rdx
    7e71:      	movzwl	0x22(%r12), %r12d
    7e77:      	jmp	0x7e82 <generic_fentry_filter_arg+0x13c2>
    7e79:      	movq	%r12, %rdx
    7e7c:      	movzwl	0x20(%r12), %r12d
    7e82:      	xorl	%esi, %esi
    7e84:      	xorl	%ebp, %ebp
    7e86:      	xorl	%r8d, %r8d
    7e89:      	xorl	%ebx, %ebx
    7e8b:      	cmpl	$0x11, %eax
    7e8e:      	jg	0x7f1a <generic_fentry_filter_arg+0x145a>
    7e94:      	leal	-0xd(%rax), %ecx
    7e97:      	cmpl	$0x2, %ecx
    7e9a:      	jb	0x7f4d <generic_fentry_filter_arg+0x148d>
    7ea0:      	leal	-0xf(%rax), %ecx
    7ea3:      	cmpl	$0x2, %ecx
    7ea6:      	jb	0x8080 <generic_fentry_filter_arg+0x15c0>
    7eac:      	cmpl	$0x11, %eax
    7eaf:      	je	0x8672 <generic_fentry_filter_arg+0x1bb2>
    7eb5:      	jmp	0x6d90 <generic_fentry_filter_arg+0x2d0>
    7eba:      	cmpl	$0x1c, %eax
    7ebd:      	je	0x866c <generic_fentry_filter_arg+0x1bac>
    7ec3:      	movl	$0x0, %ebx
    7ec8:      	cmpl	$0x1d, %eax
    7ecb:      	jne	0x6d90 <generic_fentry_filter_arg+0x2d0>
    7ed1:      	cmpl	$0x7, %ecx
    7ed4:      	jne	0x8c08 <generic_fentry_filter_arg+0x2148>
    7eda:      	testq	%rdx, %rdx
    7edd:      	jne	0x8c14 <generic_fentry_filter_arg+0x2154>
    7ee3:      	xorl	%ebx, %ebx
    7ee5:      	jmp	0x8c26 <generic_fentry_filter_arg+0x2166>
    7eea:      	movq	0x10(%r12), %rsi
    7eef:      	movq	%r12, %rdx
    7ef2:      	movq	0x18(%r12), %r8
    7ef7:      	jmp	0x7f05 <generic_fentry_filter_arg+0x1445>
    7ef9:      	movq	(%r12), %rsi
    7efd:      	movq	%r12, %rdx
    7f00:      	movq	0x8(%r12), %r8
    7f05:      	movq	%rsi, %rbp
    7f08:      	shrq	$0x20, %rbp
    7f0c:      	xorl	%r12d, %r12d
    7f0f:      	xorl	%ebx, %ebx
    7f11:      	cmpl	$0x11, %eax
    7f14:      	jle	0x7e94 <generic_fentry_filter_arg+0x13d4>
    7f1a:      	cmpl	$0x19, %eax
    7f1d:      	ja	0x8074 <generic_fentry_filter_arg+0x15b4>
    7f23:      	movl	$0x500000, %ecx         # imm = 0x500000
    7f28:      	btl	%eax, %ecx
    7f2b:      	jb	0x81c3 <generic_fentry_filter_arg+0x1703>
    7f31:      	movl	$0xa00000, %ecx         # imm = 0xA00000
    7f36:      	btl	%eax, %ecx
    7f39:      	jb	0x81d6 <generic_fentry_filter_arg+0x1716>
    7f3f:      	movl	$0x3000000, %ecx        # imm = 0x3000000
    7f44:      	btl	%eax, %ecx
    7f47:      	jae	0x8074 <generic_fentry_filter_arg+0x15b4>
    7f4d:      	movzwl	0x26(%rdx), %eax
    7f51:      	cmpl	$0xa, %eax
    7f54:      	je	0x826b <generic_fentry_filter_arg+0x17ab>
    7f5a:      	cmpl	$0x2, %eax
    7f5d:      	jne	0x82fd <generic_fentry_filter_arg+0x183d>
    7f63:      	movq	%rsi, %r12
    7f66:      	movq	%r11, 0x10(%rsp)
    7f6b:      	movl	0x10(%r13), %eax
    7f6f:      	movl	%eax, 0x34(%rsp)
    7f73:      	movl	$0x1, %eax
    7f78:      	leaq	0x34(%rsp), %rsi
    7f7d:      	movq	(%rip), %rdi            # 0x7f84 <generic_fentry_filter_arg+0x14c4>
    7f84:      	callq	*%rax
    7f86:      	testq	%rax, %rax
    7f89:      	je	0x8729 <generic_fentry_filter_arg+0x1c69>
    7f8f:      	movq	%rax, %rdi
    7f92:      	movl	$0x20, 0x70(%rsp)
    7f9a:      	movl	%r12d, 0x74(%rsp)
    7f9f:      	jmp	0x82bd <generic_fentry_filter_arg+0x17fd>
    7fa4:      	cmpl	$0xc, %ecx
    7fa7:      	ja	0x8cd1 <generic_fentry_filter_arg+0x2211>
    7fad:      	movl	$0x1402, %esi           # imm = 0x1402
    7fb2:      	btl	%ecx, %esi
    7fb5:      	jae	0x8cd1 <generic_fentry_filter_arg+0x2211>
    7fbb:      	cmpl	%edx, (%r12)
    7fbf:      	jg	0x6da1 <generic_fentry_filter_arg+0x2e1>
    7fc5:      	jmp	0x8ce7 <generic_fentry_filter_arg+0x2227>
    7fca:      	xorl	%ebx, %ebx
    7fcc:      	xorl	%r12d, %r12d
    7fcf:      	movq	%r11, %r15
    7fd2:      	movl	0x10(%r13,%rbx,4), %eax
    7fd7:      	movl	%eax, 0x38(%rsp)
    7fdb:      	movl	$0x1, %eax
    7fe0:      	leaq	0x38(%rsp), %rsi
    7fe5:      	movq	(%rip), %rdi            # 0x7fec <generic_fentry_filter_arg+0x152c>
    7fec:      	callq	*%rax
    7fee:      	testq	%rax, %rax
    7ff1:      	je	0x8b54 <generic_fentry_filter_arg+0x2094>
    7ff7:      	testl	%ebp, %ebp
    7ff9:      	movq	0x8(%rsp), %r9
    7ffe:      	movq	%r15, %r11
    8001:      	movq	0x68(%rsp), %r15
    8006:      	je	0x804f <generic_fentry_filter_arg+0x158f>
    8008:      	movq	0x18(%rsp), %rdx
    800d:      	xorl	%ecx, %ecx
    800f:      	jmp	0x801c <generic_fentry_filter_arg+0x155c>
    8011:      	incq	%rcx
    8014:      	incq	%rdx
    8017:      	cmpq	%rbp, %rcx
    801a:      	je	0x804f <generic_fentry_filter_arg+0x158f>
    801c:      	xorl	%esi, %esi
    801e:      	nop
    8020:      	leaq	(%rcx,%rsi), %rdi
    8024:      	cmpq	%rbp, %rdi
    8027:      	jae	0x8011 <generic_fentry_filter_arg+0x1551>
    8029:      	movzbl	(%rax,%rsi), %edi
    802d:      	testb	%dil, %dil
    8030:      	je	0x8047 <generic_fentry_filter_arg+0x1587>
    8032:      	cmpq	$0x62, %rsi
    8036:      	ja	0x8011 <generic_fentry_filter_arg+0x1551>
    8038:      	leaq	0x1(%rsi), %r8
    803c:      	cmpb	%dil, (%rdx,%rsi)
    8040:      	movq	%r8, %rsi
    8043:      	je	0x8020 <generic_fentry_filter_arg+0x1560>
    8045:      	jmp	0x8011 <generic_fentry_filter_arg+0x1551>
    8047:      	testl	%ecx, %ecx
    8049:      	jns	0x8dda <generic_fentry_filter_arg+0x231a>
    804f:      	leal	0xc(%r12), %eax
    8054:      	cmpl	0x8(%r13), %eax
    8058:      	jae	0x9957 <generic_fentry_filter_arg+0x2e97>
    805e:      	addl	$0x4, %r12d
    8062:      	incq	%rbx
    8065:      	cmpq	$0x64, %rbx
    8069:      	jne	0x7fcf <generic_fentry_filter_arg+0x150f>
    806f:      	jmp	0x9957 <generic_fentry_filter_arg+0x2e97>
    8074:      	addl	$-0x12, %eax
    8077:      	cmpl	$0x2, %eax
    807a:      	jae	0x6d90 <generic_fentry_filter_arg+0x2d0>
    8080:      	movq	%r11, %rbp
    8083:      	movzbl	0x10(%r13), %eax
    8088:      	movl	%eax, 0x34(%rsp)
    808c:      	movl	$0x1, %eax
    8091:      	movq	(%rip), %rdi            # 0x8098 <generic_fentry_filter_arg+0x15d8>
    8098:      	leaq	0x34(%rsp), %rsi
    809d:      	callq	*%rax
    809f:      	testq	%rax, %rax
    80a2:      	je	0x84fe <generic_fentry_filter_arg+0x1a3e>
    80a8:      	movq	%rax, %rdi
    80ab:      	movzwl	%r12w, %eax
    80af:      	movq	%rax, 0x70(%rsp)
    80b4:      	movl	$0x1, %eax
    80b9:      	movq	0x28(%rsp), %rsi
    80be:      	jmp	0x84c5 <generic_fentry_filter_arg+0x1a05>
    80c3:      	leal	-0x100(%rbx), %eax
    80c9:      	rorxl	$0x8, %eax, %eax
    80cf:      	cmpl	$0x2, %eax
    80d2:      	jg	0x8884 <generic_fentry_filter_arg+0x1dc4>
    80d8:      	testl	%eax, %eax
    80da:      	je	0x8f9d <generic_fentry_filter_arg+0x24dd>
    80e0:      	cmpl	$0x1, %eax
    80e3:      	jne	0x8f96 <generic_fentry_filter_arg+0x24d6>
    80e9:      	movl	$0x7, %eax
    80ee:      	jmp	0x8fa9 <generic_fentry_filter_arg+0x24e9>
    80f3:      	cmpl	$0x1, %eax
    80f6:      	je	0x8979 <generic_fentry_filter_arg+0x1eb9>
    80fc:      	cmpl	$0x2, %eax
    80ff:      	jne	0x8986 <generic_fentry_filter_arg+0x1ec6>
    8105:      	movzbl	(%r12), %edx
    810a:      	cmpl	%edx, %ecx
    810c:      	ja	0x6da1 <generic_fentry_filter_arg+0x2e1>
    8112:      	jmp	0x8986 <generic_fentry_filter_arg+0x1ec6>
    8117:      	cmpl	$0x1, %eax
    811a:      	je	0x89be <generic_fentry_filter_arg+0x1efe>
    8120:      	cmpl	$0x2, %eax
    8123:      	jne	0x89cb <generic_fentry_filter_arg+0x1f0b>
    8129:      	movzwl	(%r12), %edx
    812e:      	cmpl	%edx, %ecx
    8130:      	ja	0x6da1 <generic_fentry_filter_arg+0x2e1>
    8136:      	jmp	0x89cb <generic_fentry_filter_arg+0x1f0b>
    813b:      	movq	%r11, %rbp
    813e:      	movzbl	0x10(%r13), %eax
    8143:      	movl	%eax, 0x70(%rsp)
    8147:      	movl	$0x1, %eax
    814c:      	movq	0x28(%rsp), %rsi
    8151:      	movq	(%rip), %rdi            # 0x8158 <generic_fentry_filter_arg+0x1698>
    8158:      	callq	*%rax
    815a:      	testq	%rax, %rax
    815d:      	je	0x84fe <generic_fentry_filter_arg+0x1a3e>
    8163:      	movq	%rax, %rdi
    8166:      	movzbl	(%r12), %eax
    816b:      	movq	%rax, 0x38(%rsp)
    8170:      	movl	$0x1, %eax
    8175:      	leaq	0x38(%rsp), %rsi
    817a:      	jmp	0x84c5 <generic_fentry_filter_arg+0x1a05>
    817f:      	movq	%r11, %rbp
    8182:      	movzbl	0x10(%r13), %eax
    8187:      	movl	%eax, 0x70(%rsp)
    818b:      	movl	$0x1, %eax
    8190:      	movq	0x28(%rsp), %rsi
    8195:      	movq	(%rip), %rdi            # 0x819c <generic_fentry_filter_arg+0x16dc>
    819c:      	callq	*%rax
    819e:      	testq	%rax, %rax
    81a1:      	je	0x84fe <generic_fentry_filter_arg+0x1a3e>
    81a7:      	movq	%rax, %rdi
    81aa:      	movzwl	(%r12), %eax
    81af:      	movq	%rax, 0x38(%rsp)
    81b4:      	movl	$0x1, %eax
    81b9:      	leaq	0x38(%rsp), %rsi
    81be:      	jmp	0x84c5 <generic_fentry_filter_arg+0x1a05>
    81c3:      	movzwl	%r12w, %eax
    81c7:      	xorl	%ebx, %ebx
    81c9:      	cmpl	$0x400, %eax            # imm = 0x400
    81ce:      	setb	%bl
    81d1:      	jmp	0x6d90 <generic_fentry_filter_arg+0x2d0>
    81d6:      	movzwl	%r12w, %eax
    81da:      	xorl	%ebx, %ebx
    81dc:      	cmpl	$0x400, %eax            # imm = 0x400
    81e1:      	setae	%bl
    81e4:      	jmp	0x6d90 <generic_fentry_filter_arg+0x2d0>
    81e9:      	testq	%rax, %rax
    81ec:      	sete	%al
    81ef:      	movq	(%rsp), %rdi
    81f3:      	movq	0x8(%rsp), %r9
    81f8:      	movq	%rbp, %r11
    81fb:      	movzbl	%al, %ebx
    81fe:      	jmp	0x6d90 <generic_fentry_filter_arg+0x2d0>
    8203:      	movl	$0x100, %esi            # imm = 0x100
    8208:      	cmpl	$0x101, %eax            # imm = 0x101
    820d:      	jb	0x823b <generic_fentry_filter_arg+0x177b>
    820f:      	movl	$0x200, %esi            # imm = 0x200
    8214:      	cmpl	$0x201, %eax            # imm = 0x201
    8219:      	jb	0x823b <generic_fentry_filter_arg+0x177b>
    821b:      	movl	$0x400, %esi            # imm = 0x400
    8220:      	cmpl	$0x401, %eax            # imm = 0x401
    8225:      	jb	0x823b <generic_fentry_filter_arg+0x177b>
    8227:      	xorl	%esi, %esi
    8229:      	cmpl	$0x801, %eax            # imm = 0x801
    822e:      	setae	%sil
    8232:      	shll	$0xb, %esi
    8235:      	addl	$0x800, %esi            # imm = 0x800
    823b:      	leal	-0x100(%rsi), %eax
    8241:      	rorxl	$0x8, %eax, %eax
    8247:      	cmpl	$0x2, %eax
    824a:      	jg	0x8738 <generic_fentry_filter_arg+0x1c78>
    8250:      	testl	%eax, %eax
    8252:      	je	0x8e03 <generic_fentry_filter_arg+0x2343>
    8258:      	cmpl	$0x1, %eax
    825b:      	jne	0x8dfc <generic_fentry_filter_arg+0x233c>
    8261:      	movl	$0x7, %eax
    8266:      	jmp	0x8e0f <generic_fentry_filter_arg+0x234f>
    826b:      	movq	%r8, %rbx
    826e:      	movq	%rsi, %r12
    8271:      	movq	%r11, 0x10(%rsp)
    8276:      	movl	0x14(%r13), %eax
    827a:      	movl	%eax, 0x34(%rsp)
    827e:      	movl	$0x1, %eax
    8283:      	movq	(%rip), %rdi            # 0x828a <generic_fentry_filter_arg+0x17ca>
    828a:      	leaq	0x34(%rsp), %rsi
    828f:      	callq	*%rax
    8291:      	testq	%rax, %rax
    8294:      	je	0x8729 <generic_fentry_filter_arg+0x1c69>
    829a:      	movq	%rax, %rdi
    829d:      	movl	$0x80, 0x70(%rsp)
    82a5:      	movl	%r12d, 0x74(%rsp)
    82aa:      	movl	%ebp, 0x78(%rsp)
    82ae:      	movl	%ebx, 0x7c(%rsp)
    82b2:      	shrq	$0x20, %rbx
    82b6:      	movl	%ebx, 0x80(%rsp)
    82bd:      	movl	$0x1, %eax
    82c2:      	movq	0x28(%rsp), %rsi
    82c7:      	callq	*%rax
    82c9:      	movl	0x4(%r13), %ecx
    82cd:      	leal	-0x18(%rcx), %edx
    82d0:      	cmpl	$0x2, %edx
    82d3:      	jb	0x8941 <generic_fentry_filter_arg+0x1e81>
    82d9:      	addl	$-0xd, %ecx
    82dc:      	cmpl	$0x1, %ecx
    82df:      	movq	(%rsp), %rdi
    82e3:      	movq	0x8(%rsp), %r9
    82e8:      	movq	0x10(%rsp), %r11
    82ed:      	ja	0x82fd <generic_fentry_filter_arg+0x183d>
    82ef:      	testq	%rax, %rax
    82f2:      	setne	%al
    82f5:      	movzbl	%al, %ebx
    82f8:      	jmp	0x6d90 <generic_fentry_filter_arg+0x2d0>
    82fd:      	xorl	%eax, %eax
    82ff:      	movzbl	%al, %ebx
    8302:      	jmp	0x6d90 <generic_fentry_filter_arg+0x2d0>
    8307:      	cmpl	$0x1e, %eax
    830a:      	jne	0x6bdd <generic_fentry_filter_arg+0x11d>
    8310:      	movl	0x10(%r13), %eax
    8314:      	andl	$0x7, %eax
    8317:      	movl	%eax, %ecx
    8319:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    8322:      	jne	0x6bdd <generic_fentry_filter_arg+0x11d>
    8328:      	movq	(%r12), %rcx
    832c:      	movq	0x5e78(%r14,%rax,8), %rax
    8334:      	andl	$0x7ff, %eax            # imm = 0x7FF
    8339:      	xorl	%ebx, %ebx
    833b:      	andnq	0x90(%r14,%rax), %rcx, %rax
    8345:      	setne	%bl
    8348:      	jmp	0x6d90 <generic_fentry_filter_arg+0x2d0>
    834d:      	cmpl	$0x21, %eax
    8350:      	je	0x8aac <generic_fentry_filter_arg+0x1fec>
    8356:      	movl	$0x0, %ebx
    835b:      	cmpl	$0x22, %eax
    835e:      	jne	0xa0fb <generic_fentry_filter_arg+0x363b>
    8364:      	movl	$0x10, %r12d
    836a:      	movq	%r11, %r15
    836d:      	movl	(%r13,%r12), %eax
    8372:      	movl	%eax, 0x38(%rsp)
    8376:      	movl	$0x1, %eax
    837b:      	leaq	0x38(%rsp), %rsi
    8380:      	movq	(%rip), %rdi            # 0x8387 <generic_fentry_filter_arg+0x18c7>
    8387:      	callq	*%rax
    8389:      	testq	%rax, %rax
    838c:      	je	0x9744 <generic_fentry_filter_arg+0x2c84>
    8392:      	movq	0x18(%rsp), %rdi
    8397:      	movq	%rax, %rsi
    839a:      	movq	%rbp, %rdx
    839d:      	callq	0x83a2 <generic_fentry_filter_arg+0x18e2>
    83a2:      	testl	%eax, %eax
    83a4:      	jns	0x9748 <generic_fentry_filter_arg+0x2c88>
    83aa:      	addq	$0x4, %r12
    83ae:      	leal	-0x8(%r12), %eax
    83b3:      	cmpl	0x8(%r13), %eax
    83b7:      	movq	(%rsp), %rdi
    83bb:      	movq	0x8(%rsp), %r9
    83c0:      	movq	%r15, %r11
    83c3:      	jae	0x987d <generic_fentry_filter_arg+0x2dbd>
    83c9:      	movl	$0x0, %ebx
    83ce:      	cmpq	$0x1a0, %r12            # imm = 0x1A0
    83d5:      	movq	0x68(%rsp), %r15
    83da:      	jne	0x836a <generic_fentry_filter_arg+0x18aa>
    83dc:      	jmp	0xa0fb <generic_fentry_filter_arg+0x363b>
    83e1:      	movq	%r8, 0x18(%rsp)
    83e6:      	movq	%rsi, %r12
    83e9:      	cmpl	$0x8, %eax
    83ec:      	jne	0x6bdd <generic_fentry_filter_arg+0x11d>
    83f2:      	movq	%r11, 0x10(%rsp)
    83f7:      	movl	0x10(%r13), %eax
    83fb:      	movl	%eax, 0x38(%rsp)
    83ff:      	movl	$0x0, 0x70(%rsp)
    8407:      	movl	$0x1, %eax
    840c:      	leaq	0x38(%rsp), %rsi
    8411:      	movq	(%rip), %rdi            # 0x8418 <generic_fentry_filter_arg+0x1958>
    8418:      	callq	*%rax
    841a:      	testb	%bpl, %bpl
    841d:      	je	0x86f2 <generic_fentry_filter_arg+0x1c32>
    8423:      	movl	$0x0, %ebx
    8428:      	testq	%rax, %rax
    842b:      	je	0x86f4 <generic_fentry_filter_arg+0x1c34>
    8431:      	movq	%rax, %rbp
    8434:      	movl	$0x1, %eax
    8439:      	movq	0x28(%rsp), %rsi
    843e:      	movq	(%rip), %rdi            # 0x8445 <generic_fentry_filter_arg+0x1985>
    8445:      	callq	*%rax
    8447:      	testq	%rax, %rax
    844a:      	je	0x86f2 <generic_fentry_filter_arg+0x1c32>
    8450:      	movq	%r12, %rsi
    8453:      	movl	%esi, %ecx
    8455:      	shll	$0x3, %ecx
    8458:      	movl	%ecx, (%rax)
    845a:      	movq	%rax, %rdi
    845d:      	addq	$0x4, %rdi
    8461:      	movq	%rax, %rbx
    8464:      	movl	$0x4, %eax
    8469:      	movq	0x18(%rsp), %rdx
    846e:      	callq	*%rax
    8470:      	movl	$0x1, %eax
    8475:      	movq	%rbp, %rdi
    8478:      	movq	%rbx, %rsi
    847b:      	callq	*%rax
    847d:      	xorl	%ebx, %ebx
    847f:      	testq	%rax, %rax
    8482:      	setne	%bl
    8485:      	jmp	0x86f4 <generic_fentry_filter_arg+0x1c34>
    848a:      	movq	%r11, %rbp
    848d:      	movzwl	(%r12), %ebx
    8492:      	movzbl	0x10(%r13), %eax
    8497:      	movl	%eax, 0x70(%rsp)
    849b:      	movl	$0x1, %eax
    84a0:      	movq	0x28(%rsp), %rsi
    84a5:      	movq	(%rip), %rdi            # 0x84ac <generic_fentry_filter_arg+0x19ec>
    84ac:      	callq	*%rax
    84ae:      	testq	%rax, %rax
    84b1:      	je	0x84fe <generic_fentry_filter_arg+0x1a3e>
    84b3:      	movq	%rax, %rdi
    84b6:      	movq	%rbx, 0x38(%rsp)
    84bb:      	movl	$0x1, %eax
    84c0:      	leaq	0x38(%rsp), %rsi
    84c5:      	callq	*%rax
    84c7:      	movl	0x4(%r13), %edx
    84cb:      	xorl	%ecx, %ecx
    84cd:      	cmpl	$0x1d, %edx
    84d0:      	ja	0x8de8 <generic_fentry_filter_arg+0x2328>
    84d6:      	movl	$0x30038400, %esi       # imm = 0x30038400
    84db:      	btl	%edx, %esi
    84de:      	movq	(%rsp), %rdi
    84e2:      	movq	0x8(%rsp), %r9
    84e7:      	movq	%rbp, %r11
    84ea:      	jae	0x86da <generic_fentry_filter_arg+0x1c1a>
    84f0:      	testq	%rax, %rax
    84f3:      	setne	%cl
    84f6:      	movzbl	%cl, %ebx
    84f9:      	jmp	0x6d90 <generic_fentry_filter_arg+0x2d0>
    84fe:      	xorl	%ebx, %ebx
    8500:      	movq	(%rsp), %rdi
    8504:      	movq	0x8(%rsp), %r9
    8509:      	movq	%rbp, %r11
    850c:      	jmp	0x6d90 <generic_fentry_filter_arg+0x2d0>
    8511:      	movq	%r11, 0x10(%rsp)
    8516:      	movl	0x10(%r13), %eax
    851a:      	movl	%eax, 0x38(%rsp)
    851e:      	movl	$0x0, 0x70(%rsp)
    8526:      	movl	$0x1, %eax
    852b:      	leaq	0x38(%rsp), %rsi
    8530:      	movq	(%rip), %rdi            # 0x8537 <generic_fentry_filter_arg+0x1a77>
    8537:      	callq	*%rax
    8539:      	testl	%ebp, %ebp
    853b:      	je	0xa0eb <generic_fentry_filter_arg+0x362b>
    8541:      	movq	%rax, %r12
    8544:      	movl	$0x0, %ebx
    8549:      	testq	%rax, %rax
    854c:      	je	0xa0ed <generic_fentry_filter_arg+0x362d>
    8552:      	movl	$0x1, %eax
    8557:      	movq	0x28(%rsp), %rsi
    855c:      	movq	(%rip), %rdi            # 0x8563 <generic_fentry_filter_arg+0x1aa3>
    8563:      	callq	*%rax
    8565:      	testq	%rax, %rax
    8568:      	je	0xa0eb <generic_fentry_filter_arg+0x362b>
    856e:      	cmpl	$0xff, %ebp
    8574:      	movl	$0xff, %ecx
    8579:      	cmovael	%ecx, %ebp
    857c:      	leal	(,%rbp,8), %ecx
    8583:      	movl	%ecx, (%rax)
    8585:      	movq	%rax, %rdi
    8588:      	addq	$0x4, %rdi
    858c:      	movq	%rax, %rbx
    858f:      	movl	$0x4, %eax
    8594:      	movq	0x18(%rsp), %rdx
    8599:      	movl	%ebp, %esi
    859b:      	callq	*%rax
    859d:      	movl	$0x1, %eax
    85a2:      	movq	%r12, %rdi
    85a5:      	movq	%rbx, %rsi
    85a8:      	callq	*%rax
    85aa:      	xorl	%ebx, %ebx
    85ac:      	testq	%rax, %rax
    85af:      	setne	%bl
    85b2:      	jmp	0xa0ed <generic_fentry_filter_arg+0x362d>
    85b7:      	movl	$0x0, 0x70(%rsp)
    85bf:      	cmpl	$0x1000, %ebp           # imm = 0x1000
    85c5:      	jbe	0x8b6c <generic_fentry_filter_arg+0x20ac>
    85cb:      	xorl	%ebx, %ebx
    85cd:      	jmp	0xa0fb <generic_fentry_filter_arg+0x363b>
    85d2:      	movq	(%r12), %rax
    85d6:      	cmpq	%rax, %rsi
    85d9:      	ja	0x85e4 <generic_fentry_filter_arg+0x1b24>
    85db:      	cmpq	%rdx, %rax
    85de:      	jbe	0x6da1 <generic_fentry_filter_arg+0x2e1>
    85e4:      	movl	0x8(%r13), %edx
    85e8:      	cmpl	$0x19, %edx
    85eb:      	jb	0x6bdd <generic_fentry_filter_arg+0x11d>
    85f1:      	movq	0x20(%r13), %rdi
    85f5:      	movq	0x28(%r13), %rsi
    85f9:      	cmpl	$0xc, %ecx
    85fc:      	je	0x8607 <generic_fentry_filter_arg+0x1b47>
    85fe:      	cmpl	$0xa, %ecx
    8601:      	jne	0x8c85 <generic_fentry_filter_arg+0x21c5>
    8607:      	cmpq	%rax, %rdi
    860a:      	movq	(%rsp), %rdi
    860e:      	jg	0x8c97 <generic_fentry_filter_arg+0x21d7>
    8614:      	cmpq	%rsi, %rax
    8617:      	jle	0x6da1 <generic_fentry_filter_arg+0x2e1>
    861d:      	jmp	0x8c97 <generic_fentry_filter_arg+0x21d7>
    8622:      	movq	(%r12), %rdx
    8626:      	cmpq	%rdx, %rsi
    8629:      	setbe	%sil
    862d:      	cmpq	%rax, %rdx
    8630:      	setbe	%al
    8633:      	andb	%sil, %al
    8636:      	movl	0x8(%r13), %esi
    863a:      	cmpl	$0x19, %esi
    863d:      	jb	0x9b10 <generic_fentry_filter_arg+0x3050>
    8643:      	movq	0x20(%r13), %r8
    8647:      	movq	0x28(%r13), %rdi
    864b:      	cmpl	$0xc, %ecx
    864e:      	je	0x8659 <generic_fentry_filter_arg+0x1b99>
    8650:      	cmpl	$0xa, %ecx
    8653:      	jne	0x8bc2 <generic_fentry_filter_arg+0x2102>
    8659:      	cmpq	%rdx, %r8
    865c:      	setle	%r8b
    8660:      	cmpq	%rdi, %rdx
    8663:      	setle	%dil
    8667:      	jmp	0x8bd0 <generic_fentry_filter_arg+0x2110>
    866c:      	movzwl	0x26(%r12), %ebx
    8672:      	movq	%r11, %r12
    8675:      	movzbl	0x10(%r13), %eax
    867a:      	movl	%eax, 0x34(%rsp)
    867e:      	movl	$0x1, %eax
    8683:      	movq	(%rip), %rdi            # 0x868a <generic_fentry_filter_arg+0x1bca>
    868a:      	leaq	0x34(%rsp), %rsi
    868f:      	callq	*%rax
    8691:      	testq	%rax, %rax
    8694:      	je	0x8c63 <generic_fentry_filter_arg+0x21a3>
    869a:      	movq	%rax, %rdi
    869d:      	movzwl	%bx, %eax
    86a0:      	movq	%rax, 0x70(%rsp)
    86a5:      	movl	$0x1, %eax
    86aa:      	movq	0x28(%rsp), %rsi
    86af:      	callq	*%rax
    86b1:      	movl	0x4(%r13), %edx
    86b5:      	xorl	%ecx, %ecx
    86b7:      	cmpl	$0x1d, %edx
    86ba:      	ja	0x98c1 <generic_fentry_filter_arg+0x2e01>
    86c0:      	movl	$0x30038400, %esi       # imm = 0x30038400
    86c5:      	btl	%edx, %esi
    86c8:      	movq	(%rsp), %rdi
    86cc:      	movq	0x8(%rsp), %r9
    86d1:      	movq	%r12, %r11
    86d4:      	jb	0x84f0 <generic_fentry_filter_arg+0x1a30>
    86da:      	movl	$0xc0800, %esi          # imm = 0xC0800
    86df:      	btl	%edx, %esi
    86e2:      	jae	0x86ea <generic_fentry_filter_arg+0x1c2a>
    86e4:      	testq	%rax, %rax
    86e7:      	sete	%cl
    86ea:      	movzbl	%cl, %ebx
    86ed:      	jmp	0x6d90 <generic_fentry_filter_arg+0x2d0>
    86f2:      	xorl	%ebx, %ebx
    86f4:      	movl	0x4(%r13), %eax
    86f8:      	cmpq	$0x25, %rax
    86fc:      	ja	0x95ef <generic_fentry_filter_arg+0x2b2f>
    8702:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    870c:      	btq	%rax, %rcx
    8710:      	movq	(%rsp), %rdi
    8714:      	movq	0x8(%rsp), %r9
    8719:      	movq	0x10(%rsp), %r11
    871e:      	jb	0x9d85 <generic_fentry_filter_arg+0x32c5>
    8724:      	jmp	0x6d90 <generic_fentry_filter_arg+0x2d0>
    8729:      	movl	0x4(%r13), %eax
    872d:      	andl	$-0x2, %eax
    8730:      	cmpl	$0x18, %eax
    8733:      	jmp	0x8944 <generic_fentry_filter_arg+0x1e84>
    8738:      	cmpl	$0x3, %eax
    873b:      	je	0x8e0a <generic_fentry_filter_arg+0x234a>
    8741:      	cmpl	$0x7, %eax
    8744:      	jne	0x8dfc <generic_fentry_filter_arg+0x233c>
    874a:      	movl	$0x9, %eax
    874f:      	jmp	0x8e0f <generic_fentry_filter_arg+0x234f>
    8754:      	movl	$0x100, %esi            # imm = 0x100
    8759:      	cmpl	$0x101, %eax            # imm = 0x101
    875e:      	jb	0x878c <generic_fentry_filter_arg+0x1ccc>
    8760:      	movl	$0x200, %esi            # imm = 0x200
    8765:      	cmpl	$0x201, %eax            # imm = 0x201
    876a:      	jb	0x878c <generic_fentry_filter_arg+0x1ccc>
    876c:      	movl	$0x400, %esi            # imm = 0x400
    8771:      	cmpl	$0x401, %eax            # imm = 0x401
    8776:      	jb	0x878c <generic_fentry_filter_arg+0x1ccc>
    8778:      	xorl	%esi, %esi
    877a:      	cmpl	$0x801, %eax            # imm = 0x801
    877f:      	setae	%sil
    8783:      	shll	$0xb, %esi
    8786:      	addl	$0x800, %esi            # imm = 0x800
    878c:      	leal	-0x100(%rsi), %eax
    8792:      	rorxl	$0x8, %eax, %eax
    8798:      	cmpl	$0x2, %eax
    879b:      	jg	0x895d <generic_fentry_filter_arg+0x1e9d>
    87a1:      	testl	%eax, %eax
    87a3:      	je	0x9390 <generic_fentry_filter_arg+0x28d0>
    87a9:      	cmpl	$0x1, %eax
    87ac:      	jne	0x9389 <generic_fentry_filter_arg+0x28c9>
    87b2:      	movl	$0x7, %eax
    87b7:      	jmp	0x939c <generic_fentry_filter_arg+0x28dc>
    87bc:      	cmpq	%rdx, (%r12)
    87c0:      	ja	0x6da1 <generic_fentry_filter_arg+0x2e1>
    87c6:      	jmp	0x87d2 <generic_fentry_filter_arg+0x1d12>
    87c8:      	cmpq	%rdx, (%r12)
    87cc:      	jb	0x6da1 <generic_fentry_filter_arg+0x2e1>
    87d2:      	movl	0x8(%r13), %edx
    87d6:      	cmpl	$0x11, %edx
    87d9:      	jb	0xa181 <generic_fentry_filter_arg+0x36c1>
    87df:      	movq	0x18(%r13), %rsi
    87e3:      	cmpl	$0x2, %eax
    87e6:      	jle	0x8803 <generic_fentry_filter_arg+0x1d43>
    87e8:      	leal	-0x3(%rax), %edi
    87eb:      	cmpl	$0x2, %edi
    87ee:      	jae	0x8832 <generic_fentry_filter_arg+0x1d72>
    87f0:      	cmpq	%rsi, (%r12)
    87f4:      	movq	(%rsp), %rdi
    87f8:      	je	0x6d85 <generic_fentry_filter_arg+0x2c5>
    87fe:      	jmp	0x9311 <generic_fentry_filter_arg+0x2851>
    8803:      	cmpl	$0x1, %eax
    8806:      	je	0x88a0 <generic_fentry_filter_arg+0x1de0>
    880c:      	cmpl	$0x2, %eax
    880f:      	jne	0x9311 <generic_fentry_filter_arg+0x2851>
    8815:      	cmpl	$0xc, %ecx
    8818:      	je	0x8823 <generic_fentry_filter_arg+0x1d63>
    881a:      	cmpl	$0xa, %ecx
    881d:      	jne	0x9307 <generic_fentry_filter_arg+0x2847>
    8823:      	cmpq	%rsi, (%r12)
    8827:      	jl	0x6da1 <generic_fentry_filter_arg+0x2e1>
    882d:      	jmp	0x9311 <generic_fentry_filter_arg+0x2851>
    8832:      	cmpl	$0xc, %eax
    8835:      	movq	(%rsp), %rdi
    8839:      	jne	0x9311 <generic_fentry_filter_arg+0x2851>
    883f:      	testq	%rsi, (%r12)
    8843:      	jne	0x6da1 <generic_fentry_filter_arg+0x2e1>
    8849:      	jmp	0x9311 <generic_fentry_filter_arg+0x2851>
    884e:      	cmpl	$0xc, %eax
    8851:      	jne	0x8986 <generic_fentry_filter_arg+0x1ec6>
    8857:      	movzbl	(%r12), %edx
    885c:      	testl	%edx, %ecx
    885e:      	jne	0x6da1 <generic_fentry_filter_arg+0x2e1>
    8864:      	jmp	0x8986 <generic_fentry_filter_arg+0x1ec6>
    8869:      	cmpl	$0xc, %eax
    886c:      	jne	0x89cb <generic_fentry_filter_arg+0x1f0b>
    8872:      	movzwl	(%r12), %edx
    8877:      	testl	%edx, %ecx
    8879:      	jne	0x6da1 <generic_fentry_filter_arg+0x2e1>
    887f:      	jmp	0x89cb <generic_fentry_filter_arg+0x1f0b>
    8884:      	cmpl	$0x3, %eax
    8887:      	je	0x8fa4 <generic_fentry_filter_arg+0x24e4>
    888d:      	cmpl	$0x7, %eax
    8890:      	jne	0x8f96 <generic_fentry_filter_arg+0x24d6>
    8896:      	movl	$0x9, %eax
    889b:      	jmp	0x8fa9 <generic_fentry_filter_arg+0x24e9>
    88a0:      	cmpl	$0xc, %ecx
    88a3:      	je	0x88ae <generic_fentry_filter_arg+0x1dee>
    88a5:      	cmpl	$0xa, %ecx
    88a8:      	jne	0x92fb <generic_fentry_filter_arg+0x283b>
    88ae:      	cmpq	%rsi, (%r12)
    88b2:      	jg	0x6da1 <generic_fentry_filter_arg+0x2e1>
    88b8:      	jmp	0x9311 <generic_fentry_filter_arg+0x2851>
    88bd:      	movl	0x8(%r13), %edx
    88c1:      	movzbl	(%r12), %ecx
    88c6:      	jmp	0x88d1 <generic_fentry_filter_arg+0x1e11>
    88c8:      	movl	0x8(%r13), %edx
    88cc:      	movzwl	(%r12), %ecx
    88d1:      	cmpl	%ecx, 0x10(%r13)
    88d5:      	setbe	%sil
    88d9:      	cmpl	%ecx, 0x14(%r13)
    88dd:      	setae	%al
    88e0:      	andb	%sil, %al
    88e3:      	cmpl	$0x11, %edx
    88e6:      	jb	0x9b10 <generic_fentry_filter_arg+0x3050>
    88ec:      	cmpl	%ecx, 0x18(%r13)
    88f0:      	setbe	%sil
    88f4:      	cmpl	%ecx, 0x1c(%r13)
    88f8:      	setae	%dil
    88fc:      	andb	%sil, %dil
    88ff:      	orb	%dil, %al
    8902:      	cmpl	$0x19, %edx
    8905:      	jb	0x9b0c <generic_fentry_filter_arg+0x304c>
    890b:      	cmpl	%ecx, 0x20(%r13)
    890f:      	setbe	%sil
    8913:      	cmpl	%ecx, 0x24(%r13)
    8917:      	setae	%dil
    891b:      	andb	%sil, %dil
    891e:      	orb	%dil, %al
    8921:      	cmpl	$0x21, %edx
    8924:      	jb	0x9b0c <generic_fentry_filter_arg+0x304c>
    892a:      	cmpl	%ecx, 0x28(%r13)
    892e:      	setbe	%dl
    8931:      	cmpl	%ecx, 0x2c(%r13)
    8935:      	setae	%cl
    8938:      	andb	%dl, %cl
    893a:      	orb	%cl, %al
    893c:      	jmp	0x9b0c <generic_fentry_filter_arg+0x304c>
    8941:      	testq	%rax, %rax
    8944:      	sete	%al
    8947:      	movq	(%rsp), %rdi
    894b:      	movq	0x8(%rsp), %r9
    8950:      	movq	0x10(%rsp), %r11
    8955:      	movzbl	%al, %ebx
    8958:      	jmp	0x6d90 <generic_fentry_filter_arg+0x2d0>
    895d:      	cmpl	$0x3, %eax
    8960:      	je	0x9397 <generic_fentry_filter_arg+0x28d7>
    8966:      	cmpl	$0x7, %eax
    8969:      	jne	0x9389 <generic_fentry_filter_arg+0x28c9>
    896f:      	movl	$0x9, %eax
    8974:      	jmp	0x939c <generic_fentry_filter_arg+0x28dc>
    8979:      	movzbl	(%r12), %edx
    897e:      	cmpl	%edx, %ecx
    8980:      	jb	0x6da1 <generic_fentry_filter_arg+0x2e1>
    8986:      	movl	0x8(%r13), %ecx
    898a:      	cmpl	$0xd, %ecx
    898d:      	jb	0xa181 <generic_fentry_filter_arg+0x36c1>
    8993:      	movl	0x14(%r13), %edx
    8997:      	cmpl	$0x2, %eax
    899a:      	jle	0x8d92 <generic_fentry_filter_arg+0x22d2>
    89a0:      	leal	-0x3(%rax), %esi
    89a3:      	cmpl	$0x2, %esi
    89a6:      	jae	0x953a <generic_fentry_filter_arg+0x2a7a>
    89ac:      	movzbl	(%r12), %esi
    89b1:      	cmpl	%esi, %edx
    89b3:      	je	0x6d85 <generic_fentry_filter_arg+0x2c5>
    89b9:      	jmp	0x962b <generic_fentry_filter_arg+0x2b6b>
    89be:      	movzwl	(%r12), %edx
    89c3:      	cmpl	%edx, %ecx
    89c5:      	jb	0x6da1 <generic_fentry_filter_arg+0x2e1>
    89cb:      	movl	0x8(%r13), %ecx
    89cf:      	cmpl	$0xd, %ecx
    89d2:      	jb	0xa181 <generic_fentry_filter_arg+0x36c1>
    89d8:      	movl	0x14(%r13), %edx
    89dc:      	cmpl	$0x2, %eax
    89df:      	jle	0x8db6 <generic_fentry_filter_arg+0x22f6>
    89e5:      	leal	-0x3(%rax), %esi
    89e8:      	cmpl	$0x2, %esi
    89eb:      	jae	0x9555 <generic_fentry_filter_arg+0x2a95>
    89f1:      	movzwl	(%r12), %esi
    89f6:      	cmpl	%esi, %edx
    89f8:      	je	0x6d85 <generic_fentry_filter_arg+0x2c5>
    89fe:      	jmp	0x966c <generic_fentry_filter_arg+0x2bac>
    8a03:      	movl	(%r12), %eax
    8a07:      	cmpl	%eax, %esi
    8a09:      	ja	0x8a13 <generic_fentry_filter_arg+0x1f53>
    8a0b:      	cmpl	%edx, %eax
    8a0d:      	jbe	0x6da1 <generic_fentry_filter_arg+0x2e1>
    8a13:      	movl	0x8(%r13), %edx
    8a17:      	cmpl	$0x11, %edx
    8a1a:      	jb	0x6bdd <generic_fentry_filter_arg+0x11d>
    8a20:      	movl	0x18(%r13), %edi
    8a24:      	movl	0x1c(%r13), %esi
    8a28:      	cmpl	$0xc, %ecx
    8a2b:      	ja	0x91b7 <generic_fentry_filter_arg+0x26f7>
    8a31:      	movl	$0x1402, %r8d           # imm = 0x1402
    8a37:      	btl	%ecx, %r8d
    8a3b:      	jae	0x91b7 <generic_fentry_filter_arg+0x26f7>
    8a41:      	cmpl	%eax, %edi
    8a43:      	movq	(%rsp), %rdi
    8a47:      	jg	0x91c7 <generic_fentry_filter_arg+0x2707>
    8a4d:      	cmpl	%esi, %eax
    8a4f:      	jle	0x6da1 <generic_fentry_filter_arg+0x2e1>
    8a55:      	jmp	0x91c7 <generic_fentry_filter_arg+0x2707>
    8a5a:      	movl	(%r12), %edx
    8a5e:      	cmpl	%edx, %esi
    8a60:      	setbe	%sil
    8a64:      	cmpl	%eax, %edx
    8a66:      	setbe	%al
    8a69:      	andb	%sil, %al
    8a6c:      	movl	0x8(%r13), %esi
    8a70:      	cmpl	$0x11, %esi
    8a73:      	jb	0x9b10 <generic_fentry_filter_arg+0x3050>
    8a79:      	movl	0x18(%r13), %r8d
    8a7d:      	movl	0x1c(%r13), %edi
    8a81:      	cmpl	$0xc, %ecx
    8a84:      	ja	0x9161 <generic_fentry_filter_arg+0x26a1>
    8a8a:      	movl	$0x1402, %r10d          # imm = 0x1402
    8a90:      	btl	%ecx, %r10d
    8a94:      	jae	0x9161 <generic_fentry_filter_arg+0x26a1>
    8a9a:      	cmpl	%edx, %r8d
    8a9d:      	setle	%r8b
    8aa1:      	cmpl	%edi, %edx
    8aa3:      	setle	%dil
    8aa7:      	jmp	0x916e <generic_fentry_filter_arg+0x26ae>
    8aac:      	xorl	%ebx, %ebx
    8aae:      	xorl	%r12d, %r12d
    8ab1:      	movq	%r11, %r15
    8ab4:      	movl	0x10(%r13,%rbx,4), %eax
    8ab9:      	movl	%eax, 0x38(%rsp)
    8abd:      	movl	$0x1, %eax
    8ac2:      	leaq	0x38(%rsp), %rsi
    8ac7:      	movq	(%rip), %rdi            # 0x8ace <generic_fentry_filter_arg+0x200e>
    8ace:      	callq	*%rax
    8ad0:      	testq	%rax, %rax
    8ad3:      	je	0x8b54 <generic_fentry_filter_arg+0x2094>
    8ad9:      	testl	%ebp, %ebp
    8adb:      	movq	0x8(%rsp), %r9
    8ae0:      	movq	%r15, %r11
    8ae3:      	movq	0x68(%rsp), %r15
    8ae8:      	je	0x8b2f <generic_fentry_filter_arg+0x206f>
    8aea:      	movq	0x18(%rsp), %rdx
    8aef:      	xorl	%ecx, %ecx
    8af1:      	jmp	0x8afe <generic_fentry_filter_arg+0x203e>
    8af3:      	incq	%rcx
    8af6:      	incq	%rdx
    8af9:      	cmpq	%rbp, %rcx
    8afc:      	je	0x8b2f <generic_fentry_filter_arg+0x206f>
    8afe:      	xorl	%esi, %esi
    8b00:      	leaq	(%rcx,%rsi), %rdi
    8b04:      	cmpq	%rbp, %rdi
    8b07:      	jae	0x8af3 <generic_fentry_filter_arg+0x2033>
    8b09:      	movzbl	(%rax,%rsi), %edi
    8b0d:      	testb	%dil, %dil
    8b10:      	je	0x8b27 <generic_fentry_filter_arg+0x2067>
    8b12:      	cmpq	$0x62, %rsi
    8b16:      	ja	0x8af3 <generic_fentry_filter_arg+0x2033>
    8b18:      	leaq	0x1(%rsi), %r8
    8b1c:      	cmpb	%dil, (%rdx,%rsi)
    8b20:      	movq	%r8, %rsi
    8b23:      	je	0x8b00 <generic_fentry_filter_arg+0x2040>
    8b25:      	jmp	0x8af3 <generic_fentry_filter_arg+0x2033>
    8b27:      	testl	%ecx, %ecx
    8b29:      	jns	0x8dda <generic_fentry_filter_arg+0x231a>
    8b2f:      	leal	0xc(%r12), %eax
    8b34:      	cmpl	0x8(%r13), %eax
    8b38:      	jae	0x9957 <generic_fentry_filter_arg+0x2e97>
    8b3e:      	addl	$0x4, %r12d
    8b42:      	incq	%rbx
    8b45:      	cmpq	$0x64, %rbx
    8b49:      	jne	0x8ab1 <generic_fentry_filter_arg+0x1ff1>
    8b4f:      	jmp	0x9957 <generic_fentry_filter_arg+0x2e97>
    8b54:      	xorl	%ebx, %ebx
    8b56:      	movq	0x8(%rsp), %r9
    8b5b:      	movq	%r15, %r11
    8b5e:      	movq	0x68(%rsp), %r15
    8b63:      	movq	(%rsp), %rdi
    8b67:      	jmp	0xa0fb <generic_fentry_filter_arg+0x363b>
    8b6c:      	movzwl	%bp, %eax
    8b6f:      	cmpl	$0x90, %eax
    8b74:      	movq	%r11, 0x10(%rsp)
    8b79:      	ja	0x920a <generic_fentry_filter_arg+0x274a>
    8b7f:      	testw	%bp, %bp
    8b82:      	je	0x8b94 <generic_fentry_filter_arg+0x20d4>
    8b84:      	movl	%ebp, %eax
    8b86:      	movl	$0x18, %ecx
    8b8b:      	cltd
    8b8c:      	idivl	%ecx
    8b8e:      	movl	%ebp, %esi
    8b90:      	testl	%edx, %edx
    8b92:      	je	0x8bb6 <generic_fentry_filter_arg+0x20f6>
    8b94:      	movl	%ebp, %eax
    8b96:      	movl	$0x18, %ecx
    8b9b:      	cltd
    8b9c:      	idivl	%ecx
    8b9e:      	shll	$0x3, %eax
    8ba1:      	leal	(%rax,%rax,2), %eax
    8ba4:      	addl	$0x18, %eax
    8ba7:      	movzwl	%ax, %esi
    8baa:      	cmpl	$0x90, %esi
    8bb0:      	ja	0x9242 <generic_fentry_filter_arg+0x2782>
    8bb6:      	movl	%esi, %eax
    8bb8:      	cltd
    8bb9:      	idivl	%ecx
    8bbb:      	decl	%eax
    8bbd:      	jmp	0x9975 <generic_fentry_filter_arg+0x2eb5>
    8bc2:      	cmpq	%rdx, %r8
    8bc5:      	setbe	%r8b
    8bc9:      	cmpq	%rdi, %rdx
    8bcc:      	setbe	%dil
    8bd0:      	andb	%r8b, %dil
    8bd3:      	orb	%dil, %al
    8bd6:      	cmpl	$0x29, %esi
    8bd9:      	jb	0x9b0c <generic_fentry_filter_arg+0x304c>
    8bdf:      	movq	0x30(%r13), %r8
    8be3:      	movq	0x38(%r13), %rdi
    8be7:      	cmpl	$0xc, %ecx
    8bea:      	je	0x8bf5 <generic_fentry_filter_arg+0x2135>
    8bec:      	cmpl	$0xa, %ecx
    8bef:      	jne	0x9272 <generic_fentry_filter_arg+0x27b2>
    8bf5:      	cmpq	%rdx, %r8
    8bf8:      	setle	%r8b
    8bfc:      	cmpq	%rdi, %rdx
    8bff:      	setle	%dil
    8c03:      	jmp	0x9280 <generic_fentry_filter_arg+0x27c0>
    8c08:      	xorl	%ebx, %ebx
    8c0a:      	cmpl	$0x29, %ecx
    8c0d:      	jne	0x8c18 <generic_fentry_filter_arg+0x2158>
    8c0f:      	testq	%rdx, %rdx
    8c12:      	je	0x8c18 <generic_fentry_filter_arg+0x2158>
    8c14:      	movzbl	0x3a(%rdx), %ebx
    8c18:      	cmpl	$0x29, %ecx
    8c1b:      	je	0x8c26 <generic_fentry_filter_arg+0x2166>
    8c1d:      	cmpl	$0x7, %ecx
    8c20:      	jne	0x91b0 <generic_fentry_filter_arg+0x26f0>
    8c26:      	movq	%r11, %r12
    8c29:      	movzbl	0x10(%r13), %eax
    8c2e:      	movl	%eax, 0x34(%rsp)
    8c32:      	movl	$0x1, %eax
    8c37:      	movq	(%rip), %rdi            # 0x8c3e <generic_fentry_filter_arg+0x217e>
    8c3e:      	leaq	0x34(%rsp), %rsi
    8c43:      	callq	*%rax
    8c45:      	testq	%rax, %rax
    8c48:      	je	0x8c63 <generic_fentry_filter_arg+0x21a3>
    8c4a:      	movq	%rax, %rdi
    8c4d:      	movl	%ebx, %eax
    8c4f:      	movq	%rax, 0x70(%rsp)
    8c54:      	movl	$0x1, %eax
    8c59:      	movq	0x28(%rsp), %rsi
    8c5e:      	jmp	0x86af <generic_fentry_filter_arg+0x1bef>
    8c63:      	xorl	%ebx, %ebx
    8c65:      	movq	(%rsp), %rdi
    8c69:      	movq	0x8(%rsp), %r9
    8c6e:      	movq	%r12, %r11
    8c71:      	jmp	0x6d90 <generic_fentry_filter_arg+0x2d0>
    8c76:      	xorl	%ebx, %ebx
    8c78:      	movq	%r15, %r11
    8c7b:      	movq	0x68(%rsp), %r15
    8c80:      	jmp	0x9153 <generic_fentry_filter_arg+0x2693>
    8c85:      	cmpq	%rax, %rdi
    8c88:      	movq	(%rsp), %rdi
    8c8c:      	ja	0x8c97 <generic_fentry_filter_arg+0x21d7>
    8c8e:      	cmpq	%rsi, %rax
    8c91:      	jbe	0x6da1 <generic_fentry_filter_arg+0x2e1>
    8c97:      	cmpl	$0x29, %edx
    8c9a:      	jb	0x6bdd <generic_fentry_filter_arg+0x11d>
    8ca0:      	movq	0x30(%r13), %rdi
    8ca4:      	movq	0x38(%r13), %rsi
    8ca8:      	cmpl	$0xc, %ecx
    8cab:      	je	0x8cb6 <generic_fentry_filter_arg+0x21f6>
    8cad:      	cmpl	$0xa, %ecx
    8cb0:      	jne	0x92b3 <generic_fentry_filter_arg+0x27f3>
    8cb6:      	cmpq	%rax, %rdi
    8cb9:      	movq	(%rsp), %rdi
    8cbd:      	jg	0x92c5 <generic_fentry_filter_arg+0x2805>
    8cc3:      	cmpq	%rsi, %rax
    8cc6:      	jle	0x6da1 <generic_fentry_filter_arg+0x2e1>
    8ccc:      	jmp	0x92c5 <generic_fentry_filter_arg+0x2805>
    8cd1:      	cmpl	%edx, (%r12)
    8cd5:      	ja	0x6da1 <generic_fentry_filter_arg+0x2e1>
    8cdb:      	jmp	0x8ce7 <generic_fentry_filter_arg+0x2227>
    8cdd:      	cmpl	%edx, (%r12)
    8ce1:      	jb	0x6da1 <generic_fentry_filter_arg+0x2e1>
    8ce7:      	movl	0x8(%r13), %edx
    8ceb:      	cmpl	$0xd, %edx
    8cee:      	jb	0xa181 <generic_fentry_filter_arg+0x36c1>
    8cf4:      	movl	0x14(%r13), %esi
    8cf8:      	cmpl	$0x2, %eax
    8cfb:      	jle	0x8d18 <generic_fentry_filter_arg+0x2258>
    8cfd:      	leal	-0x3(%rax), %edi
    8d00:      	cmpl	$0x2, %edi
    8d03:      	jae	0x8d4e <generic_fentry_filter_arg+0x228e>
    8d05:      	cmpl	%esi, (%r12)
    8d09:      	movq	(%rsp), %rdi
    8d0d:      	je	0x6d85 <generic_fentry_filter_arg+0x2c5>
    8d13:      	jmp	0x97c8 <generic_fentry_filter_arg+0x2d08>
    8d18:      	cmpl	$0x1, %eax
    8d1b:      	je	0x8d6a <generic_fentry_filter_arg+0x22aa>
    8d1d:      	cmpl	$0x2, %eax
    8d20:      	jne	0x97c8 <generic_fentry_filter_arg+0x2d08>
    8d26:      	cmpl	$0xc, %ecx
    8d29:      	ja	0x97be <generic_fentry_filter_arg+0x2cfe>
    8d2f:      	movl	$0x1402, %r8d           # imm = 0x1402
    8d35:      	btl	%ecx, %r8d
    8d39:      	jae	0x97be <generic_fentry_filter_arg+0x2cfe>
    8d3f:      	cmpl	%esi, (%r12)
    8d43:      	jl	0x6da1 <generic_fentry_filter_arg+0x2e1>
    8d49:      	jmp	0x97c8 <generic_fentry_filter_arg+0x2d08>
    8d4e:      	cmpl	$0xc, %eax
    8d51:      	movq	(%rsp), %rdi
    8d55:      	jne	0x97c8 <generic_fentry_filter_arg+0x2d08>
    8d5b:      	testl	%esi, (%r12)
    8d5f:      	jne	0x6da1 <generic_fentry_filter_arg+0x2e1>
    8d65:      	jmp	0x97c8 <generic_fentry_filter_arg+0x2d08>
    8d6a:      	cmpl	$0xc, %ecx
    8d6d:      	ja	0x97b2 <generic_fentry_filter_arg+0x2cf2>
    8d73:      	movl	$0x1402, %r8d           # imm = 0x1402
    8d79:      	btl	%ecx, %r8d
    8d7d:      	jae	0x97b2 <generic_fentry_filter_arg+0x2cf2>
    8d83:      	cmpl	%esi, (%r12)
    8d87:      	jg	0x6da1 <generic_fentry_filter_arg+0x2e1>
    8d8d:      	jmp	0x97c8 <generic_fentry_filter_arg+0x2d08>
    8d92:      	cmpl	$0x1, %eax
    8d95:      	je	0x961e <generic_fentry_filter_arg+0x2b5e>
    8d9b:      	cmpl	$0x2, %eax
    8d9e:      	jne	0x962b <generic_fentry_filter_arg+0x2b6b>
    8da4:      	movzbl	(%r12), %esi
    8da9:      	cmpl	%esi, %edx
    8dab:      	ja	0x6da1 <generic_fentry_filter_arg+0x2e1>
    8db1:      	jmp	0x962b <generic_fentry_filter_arg+0x2b6b>
    8db6:      	cmpl	$0x1, %eax
    8db9:      	je	0x965f <generic_fentry_filter_arg+0x2b9f>
    8dbf:      	cmpl	$0x2, %eax
    8dc2:      	jne	0x966c <generic_fentry_filter_arg+0x2bac>
    8dc8:      	movzwl	(%r12), %esi
    8dcd:      	cmpl	%esi, %edx
    8dcf:      	ja	0x6da1 <generic_fentry_filter_arg+0x2e1>
    8dd5:      	jmp	0x966c <generic_fentry_filter_arg+0x2bac>
    8dda:      	movl	$0x1, %ebx
    8ddf:      	movq	(%rsp), %rdi
    8de3:      	jmp	0xa0fb <generic_fentry_filter_arg+0x363b>
    8de8:      	movq	(%rsp), %rdi
    8dec:      	movq	0x8(%rsp), %r9
    8df1:      	movq	%rbp, %r11
    8df4:      	movzbl	%cl, %ebx
    8df7:      	jmp	0x6d90 <generic_fentry_filter_arg+0x2d0>
    8dfc:      	movl	$0xa, %eax
    8e01:      	jmp	0x8e0f <generic_fentry_filter_arg+0x234f>
    8e03:      	movl	$0x6, %eax
    8e08:      	jmp	0x8e0f <generic_fentry_filter_arg+0x234f>
    8e0a:      	movl	$0x8, %eax
    8e0f:      	movl	%eax, %ecx
    8e11:      	andl	$0xf, %ecx
    8e14:      	movl	0x10(%r13,%rcx,4), %ecx
    8e19:      	cmpl	$-0x1, %ecx
    8e1c:      	je	0x9d53 <generic_fentry_filter_arg+0x3293>
    8e22:      	movl	%ecx, 0x88(%rsp)
    8e29:      	movl	%eax, 0x18(%rsp)
    8e2d:      	movq	%rsi, 0x60(%rsp)
    8e32:      	movl	$0x1, %eax
    8e37:      	movq	(%rip), %rdi            # 0x8e3e <generic_fentry_filter_arg+0x237e>
    8e3e:      	movq	0x28(%rsp), %rbx
    8e43:      	movq	%rbx, %rsi
    8e46:      	callq	*%rax
    8e48:      	movq	%rax, 0x20(%rsp)
    8e4d:      	movl	$0x1, %eax
    8e52:      	movq	(%rip), %rdi            # 0x8e59 <generic_fentry_filter_arg+0x2399>
    8e59:      	movq	%rbx, %rsi
    8e5c:      	callq	*%rax
    8e5e:      	movq	0x20(%rsp), %rdx
    8e63:      	testq	%rdx, %rdx
    8e66:      	je	0x9d53 <generic_fentry_filter_arg+0x3293>
    8e6c:      	movl	$0x0, %ebx
    8e71:      	testq	%rax, %rax
    8e74:      	movq	(%rsp), %rdi
    8e78:      	movq	0x8(%rsp), %r9
    8e7d:      	movq	0x10(%rsp), %r11
    8e82:      	je	0x9d63 <generic_fentry_filter_arg+0x32a3>
    8e88:      	movq	%rdx, %rcx
    8e8b:      	movq	%rax, %rbx
    8e8e:      	movq	%r12, %rdx
    8e91:      	addq	$0x4, %rdx
    8e95:      	cmpl	$0x5, 0x18(%rsp)
    8e9a:      	jg	0x8ecc <generic_fentry_filter_arg+0x240c>
    8e9c:      	movq	%rcx, %r12
    8e9f:      	movb	%bpl, (%rcx)
    8ea2:      	leaq	0x1(%rcx), %rdi
    8ea6:      	movl	$0x4, %eax
    8eab:      	movl	%ebp, %esi
    8ead:      	callq	*%rax
    8eaf:      	movq	0x60(%rsp), %rsi
    8eb4:      	subl	%ebp, %esi
    8eb6:      	jbe	0x8f00 <generic_fentry_filter_arg+0x2440>
    8eb8:      	leaq	(%r12,%rbp), %rdi
    8ebc:      	incq	%rdi
    8ebf:      	andl	$0xfff, %esi            # imm = 0xFFF
    8ec5:      	movl	$0x4, %eax
    8eca:      	jmp	0x8efb <generic_fentry_filter_arg+0x243b>
    8ecc:      	movq	%rcx, %r12
    8ecf:      	movw	%bp, (%rcx)
    8ed2:      	leaq	0x2(%rcx), %rdi
    8ed6:      	movl	$0x4, %eax
    8edb:      	movl	%ebp, %esi
    8edd:      	callq	*%rax
    8edf:      	movq	0x60(%rsp), %rsi
    8ee4:      	subl	%ebp, %esi
    8ee6:      	jbe	0x8f00 <generic_fentry_filter_arg+0x2440>
    8ee8:      	leaq	(%r12,%rbp), %rdi
    8eec:      	addq	$0x2, %rdi
    8ef0:      	andl	$0xfff, %esi            # imm = 0xFFF
    8ef6:      	movl	$0x4, %eax
    8efb:      	movq	%rbx, %rdx
    8efe:      	callq	*%rax
    8f00:      	movl	0x88(%rsp), %eax
    8f07:      	movl	%eax, 0x38(%rsp)
    8f0b:      	movl	0x18(%rsp), %eax
    8f0f:      	cmpl	$0x4, %eax
    8f12:      	movq	(%rsp), %rdi
    8f16:      	movq	0x8(%rsp), %r9
    8f1b:      	movq	0x10(%rsp), %r11
    8f20:      	jle	0x8f5c <generic_fentry_filter_arg+0x249c>
    8f22:      	cmpl	$0x7, %eax
    8f25:      	jg	0x9570 <generic_fentry_filter_arg+0x2ab0>
    8f2b:      	cmpl	$0x5, %eax
    8f2e:      	je	0x9c41 <generic_fentry_filter_arg+0x3181>
    8f34:      	cmpl	$0x6, %eax
    8f37:      	je	0x9c08 <generic_fentry_filter_arg+0x3148>
    8f3d:      	cmpl	$0x7, %eax
    8f40:      	jne	0x98ac <generic_fentry_filter_arg+0x2dec>
    8f46:      	movl	$0x1, %eax
    8f4b:      	leaq	0x38(%rsp), %rsi
    8f50:      	movq	(%rip), %rdi            # 0x8f57 <generic_fentry_filter_arg+0x2497>
    8f57:      	jmp	0x9c65 <generic_fentry_filter_arg+0x31a5>
    8f5c:      	cmpl	$0x1, %eax
    8f5f:      	jle	0x96a0 <generic_fentry_filter_arg+0x2be0>
    8f65:      	cmpl	$0x2, %eax
    8f68:      	je	0x9c2e <generic_fentry_filter_arg+0x316e>
    8f6e:      	cmpl	$0x3, %eax
    8f71:      	je	0x9bf5 <generic_fentry_filter_arg+0x3135>
    8f77:      	cmpl	$0x4, %eax
    8f7a:      	jne	0x98ac <generic_fentry_filter_arg+0x2dec>
    8f80:      	movl	$0x1, %eax
    8f85:      	leaq	0x38(%rsp), %rsi
    8f8a:      	movq	(%rip), %rdi            # 0x8f91 <generic_fentry_filter_arg+0x24d1>
    8f91:      	jmp	0x9c65 <generic_fentry_filter_arg+0x31a5>
    8f96:      	movl	$0xa, %eax
    8f9b:      	jmp	0x8fa9 <generic_fentry_filter_arg+0x24e9>
    8f9d:      	movl	$0x6, %eax
    8fa2:      	jmp	0x8fa9 <generic_fentry_filter_arg+0x24e9>
    8fa4:      	movl	$0x8, %eax
    8fa9:      	movl	%eax, %ecx
    8fab:      	andl	$0xf, %ecx
    8fae:      	movl	0x10(%r13,%rcx,4), %ecx
    8fb3:      	cmpl	$-0x1, %ecx
    8fb6:      	je	0x98ac <generic_fentry_filter_arg+0x2dec>
    8fbc:      	movl	%ecx, 0x90(%rsp)
    8fc3:      	movq	%rbx, 0x88(%rsp)
    8fcb:      	movl	%eax, 0x20(%rsp)
    8fcf:      	movq	%r8, 0x18(%rsp)
    8fd4:      	movq	%rsi, 0x60(%rsp)
    8fd9:      	movq	%r11, 0x10(%rsp)
    8fde:      	movl	$0x1, %eax
    8fe3:      	movq	(%rip), %rdi            # 0x8fea <generic_fentry_filter_arg+0x252a>
    8fea:      	movq	0x28(%rsp), %rbx
    8fef:      	movq	%rbx, %rsi
    8ff2:      	callq	*%rax
    8ff4:      	movq	%rax, %r12
    8ff7:      	movl	$0x1, %eax
    8ffc:      	movq	(%rip), %rdi            # 0x9003 <generic_fentry_filter_arg+0x2543>
    9003:      	movq	%rbx, %rsi
    9006:      	callq	*%rax
    9008:      	testq	%r12, %r12
    900b:      	je	0x9d53 <generic_fentry_filter_arg+0x3293>
    9011:      	movl	$0x0, %ebx
    9016:      	testq	%rax, %rax
    9019:      	movq	(%rsp), %rdi
    901d:      	movq	0x8(%rsp), %r9
    9022:      	movq	0x10(%rsp), %r11
    9027:      	je	0x9d63 <generic_fentry_filter_arg+0x32a3>
    902d:      	movq	%r12, %rcx
    9030:      	movq	%rax, %r12
    9033:      	cmpl	$0x5, 0x20(%rsp)
    9038:      	jg	0x9077 <generic_fentry_filter_arg+0x25b7>
    903a:      	movb	%bpl, (%rcx)
    903d:      	movq	%rcx, %rbp
    9040:      	leaq	0x1(%rcx), %rdi
    9044:      	movl	$0x4, %eax
    9049:      	movq	0x60(%rsp), %rbx
    904e:      	movq	0x18(%rsp), %rdx
    9053:      	movl	%ebx, %esi
    9055:      	callq	*%rax
    9057:      	movq	0x88(%rsp), %rsi
    905f:      	subl	%ebx, %esi
    9061:      	jbe	0x90b8 <generic_fentry_filter_arg+0x25f8>
    9063:      	leaq	(%rbx,%rbp), %rdi
    9067:      	incq	%rdi
    906a:      	andl	$0xfff, %esi            # imm = 0xFFF
    9070:      	movl	$0x4, %eax
    9075:      	jmp	0x90b3 <generic_fentry_filter_arg+0x25f3>
    9077:      	movq	0x60(%rsp), %rbx
    907c:      	movq	%rcx, %rbp
    907f:      	movw	%bx, (%rcx)
    9082:      	leaq	0x2(%rcx), %rdi
    9086:      	movl	$0x4, %eax
    908b:      	movq	0x18(%rsp), %rdx
    9090:      	movl	%ebx, %esi
    9092:      	callq	*%rax
    9094:      	movq	0x88(%rsp), %rsi
    909c:      	subl	%ebx, %esi
    909e:      	jbe	0x90b8 <generic_fentry_filter_arg+0x25f8>
    90a0:      	leaq	(%rbx,%rbp), %rdi
    90a4:      	addq	$0x2, %rdi
    90a8:      	andl	$0xfff, %esi            # imm = 0xFFF
    90ae:      	movl	$0x4, %eax
    90b3:      	movq	%r12, %rdx
    90b6:      	callq	*%rax
    90b8:      	movl	0x90(%rsp), %eax
    90bf:      	movl	%eax, 0x38(%rsp)
    90c3:      	movl	0x20(%rsp), %eax
    90c7:      	cmpl	$0x4, %eax
    90ca:      	movq	(%rsp), %rdi
    90ce:      	movq	0x8(%rsp), %r9
    90d3:      	movq	0x10(%rsp), %r11
    90d8:      	jle	0x9114 <generic_fentry_filter_arg+0x2654>
    90da:      	cmpl	$0x7, %eax
    90dd:      	jg	0x95be <generic_fentry_filter_arg+0x2afe>
    90e3:      	cmpl	$0x5, %eax
    90e6:      	je	0x9d11 <generic_fentry_filter_arg+0x3251>
    90ec:      	cmpl	$0x6, %eax
    90ef:      	je	0x9cd8 <generic_fentry_filter_arg+0x3218>
    90f5:      	cmpl	$0x7, %eax
    90f8:      	jne	0x98ac <generic_fentry_filter_arg+0x2dec>
    90fe:      	movl	$0x1, %eax
    9103:      	leaq	0x38(%rsp), %rsi
    9108:      	movq	(%rip), %rdi            # 0x910f <generic_fentry_filter_arg+0x264f>
    910f:      	jmp	0x9d35 <generic_fentry_filter_arg+0x3275>
    9114:      	cmpl	$0x1, %eax
    9117:      	jle	0x9889 <generic_fentry_filter_arg+0x2dc9>
    911d:      	cmpl	$0x2, %eax
    9120:      	je	0x9cfe <generic_fentry_filter_arg+0x323e>
    9126:      	cmpl	$0x3, %eax
    9129:      	je	0x9cc5 <generic_fentry_filter_arg+0x3205>
    912f:      	cmpl	$0x4, %eax
    9132:      	jne	0x98ac <generic_fentry_filter_arg+0x2dec>
    9138:      	movl	$0x1, %eax
    913d:      	leaq	0x38(%rsp), %rsi
    9142:      	movq	(%rip), %rdi            # 0x9149 <generic_fentry_filter_arg+0x2689>
    9149:      	jmp	0x9d35 <generic_fentry_filter_arg+0x3275>
    914e:      	movl	$0x1, %ebx
    9153:      	movq	(%rsp), %rdi
    9157:      	movq	0x8(%rsp), %r9
    915c:      	jmp	0xa0fb <generic_fentry_filter_arg+0x363b>
    9161:      	cmpl	%edx, %r8d
    9164:      	setbe	%r8b
    9168:      	cmpl	%edi, %edx
    916a:      	setbe	%dil
    916e:      	andb	%r8b, %dil
    9171:      	orb	%dil, %al
    9174:      	cmpl	$0x19, %esi
    9177:      	jb	0x9b0c <generic_fentry_filter_arg+0x304c>
    917d:      	movl	0x20(%r13), %r8d
    9181:      	movl	0x24(%r13), %edi
    9185:      	cmpl	$0xc, %ecx
    9188:      	ja	0x96f8 <generic_fentry_filter_arg+0x2c38>
    918e:      	movl	$0x1402, %r10d          # imm = 0x1402
    9194:      	btl	%ecx, %r10d
    9198:      	jae	0x96f8 <generic_fentry_filter_arg+0x2c38>
    919e:      	cmpl	%edx, %r8d
    91a1:      	setle	%r8b
    91a5:      	cmpl	%edi, %edx
    91a7:      	setle	%dil
    91ab:      	jmp	0x9705 <generic_fentry_filter_arg+0x2c45>
    91b0:      	xorl	%ebx, %ebx
    91b2:      	jmp	0x6d90 <generic_fentry_filter_arg+0x2d0>
    91b7:      	cmpl	%eax, %edi
    91b9:      	movq	(%rsp), %rdi
    91bd:      	ja	0x91c7 <generic_fentry_filter_arg+0x2707>
    91bf:      	cmpl	%esi, %eax
    91c1:      	jbe	0x6da1 <generic_fentry_filter_arg+0x2e1>
    91c7:      	cmpl	$0x19, %edx
    91ca:      	jb	0x6bdd <generic_fentry_filter_arg+0x11d>
    91d0:      	movl	0x20(%r13), %edi
    91d4:      	movl	0x24(%r13), %esi
    91d8:      	cmpl	$0xc, %ecx
    91db:      	ja	0x9763 <generic_fentry_filter_arg+0x2ca3>
    91e1:      	movl	$0x1402, %r8d           # imm = 0x1402
    91e7:      	btl	%ecx, %r8d
    91eb:      	jae	0x9763 <generic_fentry_filter_arg+0x2ca3>
    91f1:      	cmpl	%eax, %edi
    91f3:      	movq	(%rsp), %rdi
    91f7:      	jg	0x9773 <generic_fentry_filter_arg+0x2cb3>
    91fd:      	cmpl	%esi, %eax
    91ff:      	jle	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9205:      	jmp	0x9773 <generic_fentry_filter_arg+0x2cb3>
    920a:      	movl	$0x100, %esi            # imm = 0x100
    920f:      	cmpl	$0x101, %eax            # imm = 0x101
    9214:      	jb	0x9242 <generic_fentry_filter_arg+0x2782>
    9216:      	movl	$0x200, %esi            # imm = 0x200
    921b:      	cmpl	$0x201, %eax            # imm = 0x201
    9220:      	jb	0x9242 <generic_fentry_filter_arg+0x2782>
    9222:      	movl	$0x400, %esi            # imm = 0x400
    9227:      	cmpl	$0x401, %eax            # imm = 0x401
    922c:      	jb	0x9242 <generic_fentry_filter_arg+0x2782>
    922e:      	xorl	%esi, %esi
    9230:      	cmpl	$0x801, %eax            # imm = 0x801
    9235:      	setae	%sil
    9239:      	shll	$0xb, %esi
    923c:      	addl	$0x800, %esi            # imm = 0x800
    9242:      	leal	-0x100(%rsi), %eax
    9248:      	rorxl	$0x8, %eax, %eax
    924e:      	cmpl	$0x2, %eax
    9251:      	jg	0x9602 <generic_fentry_filter_arg+0x2b42>
    9257:      	testl	%eax, %eax
    9259:      	je	0x9969 <generic_fentry_filter_arg+0x2ea9>
    925f:      	cmpl	$0x1, %eax
    9262:      	jne	0x9962 <generic_fentry_filter_arg+0x2ea2>
    9268:      	movl	$0x7, %eax
    926d:      	jmp	0x9975 <generic_fentry_filter_arg+0x2eb5>
    9272:      	cmpq	%rdx, %r8
    9275:      	setbe	%r8b
    9279:      	cmpq	%rdi, %rdx
    927c:      	setbe	%dil
    9280:      	andb	%r8b, %dil
    9283:      	orb	%dil, %al
    9286:      	cmpl	$0x39, %esi
    9289:      	jb	0x9b0c <generic_fentry_filter_arg+0x304c>
    928f:      	movq	0x40(%r13), %rdi
    9293:      	movq	0x48(%r13), %rsi
    9297:      	cmpl	$0xc, %ecx
    929a:      	je	0x92a5 <generic_fentry_filter_arg+0x27e5>
    929c:      	cmpl	$0xa, %ecx
    929f:      	jne	0x986f <generic_fentry_filter_arg+0x2daf>
    92a5:      	cmpq	%rdx, %rdi
    92a8:      	setle	%cl
    92ab:      	cmpq	%rsi, %rdx
    92ae:      	jmp	0x973c <generic_fentry_filter_arg+0x2c7c>
    92b3:      	cmpq	%rax, %rdi
    92b6:      	movq	(%rsp), %rdi
    92ba:      	ja	0x92c5 <generic_fentry_filter_arg+0x2805>
    92bc:      	cmpq	%rsi, %rax
    92bf:      	jbe	0x6da1 <generic_fentry_filter_arg+0x2e1>
    92c5:      	cmpl	$0x39, %edx
    92c8:      	jb	0x6bdd <generic_fentry_filter_arg+0x11d>
    92ce:      	movq	0x40(%r13), %rsi
    92d2:      	movq	0x48(%r13), %rdx
    92d6:      	cmpl	$0xc, %ecx
    92d9:      	je	0x92e4 <generic_fentry_filter_arg+0x2824>
    92db:      	cmpl	$0xa, %ecx
    92de:      	jne	0x98d5 <generic_fentry_filter_arg+0x2e15>
    92e4:      	cmpq	%rax, %rsi
    92e7:      	jg	0x6bdd <generic_fentry_filter_arg+0x11d>
    92ed:      	cmpq	%rdx, %rax
    92f0:      	jle	0x6da1 <generic_fentry_filter_arg+0x2e1>
    92f6:      	jmp	0x6bdd <generic_fentry_filter_arg+0x11d>
    92fb:      	cmpq	%rsi, (%r12)
    92ff:      	ja	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9305:      	jmp	0x9311 <generic_fentry_filter_arg+0x2851>
    9307:      	cmpq	%rsi, (%r12)
    930b:      	jb	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9311:      	cmpl	$0x19, %edx
    9314:      	jb	0xa181 <generic_fentry_filter_arg+0x36c1>
    931a:      	movq	0x20(%r13), %rsi
    931e:      	cmpl	$0x2, %eax
    9321:      	jle	0x933e <generic_fentry_filter_arg+0x287e>
    9323:      	leal	-0x3(%rax), %edi
    9326:      	cmpl	$0x2, %edi
    9329:      	jae	0x936d <generic_fentry_filter_arg+0x28ad>
    932b:      	cmpq	%rsi, (%r12)
    932f:      	movq	(%rsp), %rdi
    9333:      	je	0x6d85 <generic_fentry_filter_arg+0x2c5>
    9339:      	jmp	0x9b33 <generic_fentry_filter_arg+0x3073>
    933e:      	cmpl	$0x1, %eax
    9341:      	je	0x95a1 <generic_fentry_filter_arg+0x2ae1>
    9347:      	cmpl	$0x2, %eax
    934a:      	jne	0x9b33 <generic_fentry_filter_arg+0x3073>
    9350:      	cmpl	$0xc, %ecx
    9353:      	je	0x935e <generic_fentry_filter_arg+0x289e>
    9355:      	cmpl	$0xa, %ecx
    9358:      	jne	0x9b29 <generic_fentry_filter_arg+0x3069>
    935e:      	cmpq	%rsi, (%r12)
    9362:      	jl	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9368:      	jmp	0x9b33 <generic_fentry_filter_arg+0x3073>
    936d:      	cmpl	$0xc, %eax
    9370:      	movq	(%rsp), %rdi
    9374:      	jne	0x9b33 <generic_fentry_filter_arg+0x3073>
    937a:      	testq	%rsi, (%r12)
    937e:      	jne	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9384:      	jmp	0x9b33 <generic_fentry_filter_arg+0x3073>
    9389:      	movl	$0xa, %eax
    938e:      	jmp	0x939c <generic_fentry_filter_arg+0x28dc>
    9390:      	movl	$0x6, %eax
    9395:      	jmp	0x939c <generic_fentry_filter_arg+0x28dc>
    9397:      	movl	$0x8, %eax
    939c:      	movl	%eax, %ecx
    939e:      	andl	$0xf, %ecx
    93a1:      	movl	0x10(%r13,%rcx,4), %ecx
    93a6:      	cmpl	$-0x1, %ecx
    93a9:      	je	0x9957 <generic_fentry_filter_arg+0x2e97>
    93af:      	movl	%ecx, 0x88(%rsp)
    93b6:      	movl	%eax, 0x60(%rsp)
    93ba:      	movq	%rsi, 0x90(%rsp)
    93c2:      	movq	%r11, 0x10(%rsp)
    93c7:      	movl	$0x1, %eax
    93cc:      	movq	(%rip), %rdi            # 0x93d3 <generic_fentry_filter_arg+0x2913>
    93d3:      	movq	0x28(%rsp), %rbx
    93d8:      	movq	%rbx, %rsi
    93db:      	callq	*%rax
    93dd:      	movq	%rax, %r12
    93e0:      	movl	$0x1, %eax
    93e5:      	movq	(%rip), %rdi            # 0x93ec <generic_fentry_filter_arg+0x292c>
    93ec:      	movq	%rbx, %rsi
    93ef:      	callq	*%rax
    93f1:      	movq	%r12, 0x20(%rsp)
    93f6:      	testq	%r12, %r12
    93f9:      	je	0xa0eb <generic_fentry_filter_arg+0x362b>
    93ff:      	movl	$0x0, %ebx
    9404:      	testq	%rax, %rax
    9407:      	movq	(%rsp), %rdi
    940b:      	movq	0x8(%rsp), %r9
    9410:      	movq	0x10(%rsp), %r11
    9415:      	je	0xa0fb <generic_fentry_filter_arg+0x363b>
    941b:      	movq	%rax, %r12
    941e:      	movl	0x60(%rsp), %ebx
    9422:      	cmpl	$0x5, %ebx
    9425:      	jg	0x9469 <generic_fentry_filter_arg+0x29a9>
    9427:      	movq	0x20(%rsp), %rax
    942c:      	movb	%bpl, (%rax)
    942f:      	leaq	0x1(%rax), %rdi
    9433:      	movl	$0x4, %eax
    9438:      	movq	0x18(%rsp), %rdx
    943d:      	movl	%ebp, %esi
    943f:      	callq	*%rax
    9441:      	movq	0x90(%rsp), %rsi
    9449:      	subl	%ebp, %esi
    944b:      	jbe	0x94ac <generic_fentry_filter_arg+0x29ec>
    944d:      	movq	0x20(%rsp), %rax
    9452:      	leaq	(%rax,%rbp), %rdi
    9456:      	incq	%rdi
    9459:      	andl	$0xfff, %esi            # imm = 0xFFF
    945f:      	movl	$0x4, %eax
    9464:      	movq	%r12, %rdx
    9467:      	jmp	0x94aa <generic_fentry_filter_arg+0x29ea>
    9469:      	movq	0x20(%rsp), %rax
    946e:      	movw	%bp, (%rax)
    9471:      	leaq	0x2(%rax), %rdi
    9475:      	movl	$0x4, %eax
    947a:      	movq	0x18(%rsp), %rdx
    947f:      	movl	%ebp, %esi
    9481:      	callq	*%rax
    9483:      	movq	0x90(%rsp), %rsi
    948b:      	subl	%ebp, %esi
    948d:      	jbe	0x94ac <generic_fentry_filter_arg+0x29ec>
    948f:      	movq	0x20(%rsp), %rax
    9494:      	leaq	(%rax,%rbp), %rdi
    9498:      	addq	$0x2, %rdi
    949c:      	andl	$0xfff, %esi            # imm = 0xFFF
    94a2:      	movl	$0x4, %eax
    94a7:      	movq	%r12, %rdx
    94aa:      	callq	*%rax
    94ac:      	movl	0x88(%rsp), %eax
    94b3:      	movl	%eax, 0x38(%rsp)
    94b7:      	cmpl	$0x4, %ebx
    94ba:      	movq	0x8(%rsp), %r9
    94bf:      	movq	0x10(%rsp), %r11
    94c4:      	jle	0x9500 <generic_fentry_filter_arg+0x2a40>
    94c6:      	cmpl	$0x7, %ebx
    94c9:      	jg	0x96c7 <generic_fentry_filter_arg+0x2c07>
    94cf:      	cmpl	$0x5, %ebx
    94d2:      	je	0x9ded <generic_fentry_filter_arg+0x332d>
    94d8:      	cmpl	$0x6, %ebx
    94db:      	je	0x9db4 <generic_fentry_filter_arg+0x32f4>
    94e1:      	cmpl	$0x7, %ebx
    94e4:      	jne	0x9957 <generic_fentry_filter_arg+0x2e97>
    94ea:      	movl	$0x1, %eax
    94ef:      	leaq	0x38(%rsp), %rsi
    94f4:      	movq	(%rip), %rdi            # 0x94fb <generic_fentry_filter_arg+0x2a3b>
    94fb:      	jmp	0x9e11 <generic_fentry_filter_arg+0x3351>
    9500:      	cmpl	$0x1, %ebx
    9503:      	jle	0x9934 <generic_fentry_filter_arg+0x2e74>
    9509:      	cmpl	$0x2, %ebx
    950c:      	je	0x9dda <generic_fentry_filter_arg+0x331a>
    9512:      	cmpl	$0x3, %ebx
    9515:      	je	0x9da1 <generic_fentry_filter_arg+0x32e1>
    951b:      	cmpl	$0x4, %ebx
    951e:      	jne	0x9957 <generic_fentry_filter_arg+0x2e97>
    9524:      	movl	$0x1, %eax
    9529:      	leaq	0x38(%rsp), %rsi
    952e:      	movq	(%rip), %rdi            # 0x9535 <generic_fentry_filter_arg+0x2a75>
    9535:      	jmp	0x9e11 <generic_fentry_filter_arg+0x3351>
    953a:      	cmpl	$0xc, %eax
    953d:      	jne	0x962b <generic_fentry_filter_arg+0x2b6b>
    9543:      	movzbl	(%r12), %esi
    9548:      	testl	%esi, %edx
    954a:      	jne	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9550:      	jmp	0x962b <generic_fentry_filter_arg+0x2b6b>
    9555:      	cmpl	$0xc, %eax
    9558:      	jne	0x966c <generic_fentry_filter_arg+0x2bac>
    955e:      	movzwl	(%r12), %esi
    9563:      	testl	%esi, %edx
    9565:      	jne	0x6da1 <generic_fentry_filter_arg+0x2e1>
    956b:      	jmp	0x966c <generic_fentry_filter_arg+0x2bac>
    9570:      	cmpl	$0x8, %eax
    9573:      	je	0x9c54 <generic_fentry_filter_arg+0x3194>
    9579:      	cmpl	$0x9, %eax
    957c:      	je	0x9c1b <generic_fentry_filter_arg+0x315b>
    9582:      	cmpl	$0xa, %eax
    9585:      	jne	0x98ac <generic_fentry_filter_arg+0x2dec>
    958b:      	movl	$0x1, %eax
    9590:      	leaq	0x38(%rsp), %rsi
    9595:      	movq	(%rip), %rdi            # 0x959c <generic_fentry_filter_arg+0x2adc>
    959c:      	jmp	0x9c65 <generic_fentry_filter_arg+0x31a5>
    95a1:      	cmpl	$0xc, %ecx
    95a4:      	je	0x95af <generic_fentry_filter_arg+0x2aef>
    95a6:      	cmpl	$0xa, %ecx
    95a9:      	jne	0x9b1d <generic_fentry_filter_arg+0x305d>
    95af:      	cmpq	%rsi, (%r12)
    95b3:      	jg	0x6da1 <generic_fentry_filter_arg+0x2e1>
    95b9:      	jmp	0x9b33 <generic_fentry_filter_arg+0x3073>
    95be:      	cmpl	$0x8, %eax
    95c1:      	je	0x9d24 <generic_fentry_filter_arg+0x3264>
    95c7:      	cmpl	$0x9, %eax
    95ca:      	je	0x9ceb <generic_fentry_filter_arg+0x322b>
    95d0:      	cmpl	$0xa, %eax
    95d3:      	jne	0x98ac <generic_fentry_filter_arg+0x2dec>
    95d9:      	movl	$0x1, %eax
    95de:      	leaq	0x38(%rsp), %rsi
    95e3:      	movq	(%rip), %rdi            # 0x95ea <generic_fentry_filter_arg+0x2b2a>
    95ea:      	jmp	0x9d35 <generic_fentry_filter_arg+0x3275>
    95ef:      	movq	(%rsp), %rdi
    95f3:      	movq	0x8(%rsp), %r9
    95f8:      	movq	0x10(%rsp), %r11
    95fd:      	jmp	0x6d90 <generic_fentry_filter_arg+0x2d0>
    9602:      	cmpl	$0x3, %eax
    9605:      	je	0x9970 <generic_fentry_filter_arg+0x2eb0>
    960b:      	cmpl	$0x7, %eax
    960e:      	jne	0x9962 <generic_fentry_filter_arg+0x2ea2>
    9614:      	movl	$0x9, %eax
    9619:      	jmp	0x9975 <generic_fentry_filter_arg+0x2eb5>
    961e:      	movzbl	(%r12), %esi
    9623:      	cmpl	%esi, %edx
    9625:      	jb	0x6da1 <generic_fentry_filter_arg+0x2e1>
    962b:      	cmpl	$0x11, %ecx
    962e:      	jb	0xa181 <generic_fentry_filter_arg+0x36c1>
    9634:      	movl	0x18(%r13), %edx
    9638:      	cmpl	$0x2, %eax
    963b:      	jle	0x98ec <generic_fentry_filter_arg+0x2e2c>
    9641:      	leal	-0x3(%rax), %esi
    9644:      	cmpl	$0x2, %esi
    9647:      	jae	0x9bac <generic_fentry_filter_arg+0x30ec>
    964d:      	movzbl	(%r12), %esi
    9652:      	cmpl	%esi, %edx
    9654:      	je	0x6d85 <generic_fentry_filter_arg+0x2c5>
    965a:      	jmp	0x9e3b <generic_fentry_filter_arg+0x337b>
    965f:      	movzwl	(%r12), %esi
    9664:      	cmpl	%esi, %edx
    9666:      	jb	0x6da1 <generic_fentry_filter_arg+0x2e1>
    966c:      	cmpl	$0x11, %ecx
    966f:      	jb	0xa181 <generic_fentry_filter_arg+0x36c1>
    9675:      	movl	0x18(%r13), %edx
    9679:      	cmpl	$0x2, %eax
    967c:      	jle	0x9910 <generic_fentry_filter_arg+0x2e50>
    9682:      	leal	-0x3(%rax), %esi
    9685:      	cmpl	$0x2, %esi
    9688:      	jae	0x9bc7 <generic_fentry_filter_arg+0x3107>
    968e:      	movzwl	(%r12), %esi
    9693:      	cmpl	%esi, %edx
    9695:      	je	0x6d85 <generic_fentry_filter_arg+0x2c5>
    969b:      	jmp	0x9e83 <generic_fentry_filter_arg+0x33c3>
    96a0:      	testl	%eax, %eax
    96a2:      	je	0x9be2 <generic_fentry_filter_arg+0x3122>
    96a8:      	cmpl	$0x1, %eax
    96ab:      	jne	0x98ac <generic_fentry_filter_arg+0x2dec>
    96b1:      	movl	$0x1, %eax
    96b6:      	leaq	0x38(%rsp), %rsi
    96bb:      	movq	(%rip), %rdi            # 0x96c2 <generic_fentry_filter_arg+0x2c02>
    96c2:      	jmp	0x9c65 <generic_fentry_filter_arg+0x31a5>
    96c7:      	cmpl	$0x8, %ebx
    96ca:      	je	0x9e00 <generic_fentry_filter_arg+0x3340>
    96d0:      	cmpl	$0x9, %ebx
    96d3:      	je	0x9dc7 <generic_fentry_filter_arg+0x3307>
    96d9:      	cmpl	$0xa, %ebx
    96dc:      	jne	0x9957 <generic_fentry_filter_arg+0x2e97>
    96e2:      	movl	$0x1, %eax
    96e7:      	leaq	0x38(%rsp), %rsi
    96ec:      	movq	(%rip), %rdi            # 0x96f3 <generic_fentry_filter_arg+0x2c33>
    96f3:      	jmp	0x9e11 <generic_fentry_filter_arg+0x3351>
    96f8:      	cmpl	%edx, %r8d
    96fb:      	setbe	%r8b
    96ff:      	cmpl	%edi, %edx
    9701:      	setbe	%dil
    9705:      	andb	%r8b, %dil
    9708:      	orb	%dil, %al
    970b:      	cmpl	$0x21, %esi
    970e:      	jb	0x9b0c <generic_fentry_filter_arg+0x304c>
    9714:      	movl	0x28(%r13), %edi
    9718:      	movl	0x2c(%r13), %esi
    971c:      	cmpl	$0xc, %ecx
    971f:      	ja	0x9afe <generic_fentry_filter_arg+0x303e>
    9725:      	movl	$0x1402, %r8d           # imm = 0x1402
    972b:      	btl	%ecx, %r8d
    972f:      	jae	0x9afe <generic_fentry_filter_arg+0x303e>
    9735:      	cmpl	%edx, %edi
    9737:      	setle	%cl
    973a:      	cmpl	%esi, %edx
    973c:      	setle	%dl
    973f:      	jmp	0x9b08 <generic_fentry_filter_arg+0x3048>
    9744:      	xorl	%ebx, %ebx
    9746:      	jmp	0x974d <generic_fentry_filter_arg+0x2c8d>
    9748:      	movl	$0x1, %ebx
    974d:      	movq	(%rsp), %rdi
    9751:      	movq	0x8(%rsp), %r9
    9756:      	movq	%r15, %r11
    9759:      	movq	0x68(%rsp), %r15
    975e:      	jmp	0xa0fb <generic_fentry_filter_arg+0x363b>
    9763:      	cmpl	%eax, %edi
    9765:      	movq	(%rsp), %rdi
    9769:      	ja	0x9773 <generic_fentry_filter_arg+0x2cb3>
    976b:      	cmpl	%esi, %eax
    976d:      	jbe	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9773:      	cmpl	$0x21, %edx
    9776:      	jb	0x6bdd <generic_fentry_filter_arg+0x11d>
    977c:      	movl	0x28(%r13), %esi
    9780:      	movl	0x2c(%r13), %edx
    9784:      	cmpl	$0xc, %ecx
    9787:      	ja	0x9c80 <generic_fentry_filter_arg+0x31c0>
    978d:      	movl	$0x1402, %r8d           # imm = 0x1402
    9793:      	btl	%ecx, %r8d
    9797:      	jae	0x9c80 <generic_fentry_filter_arg+0x31c0>
    979d:      	cmpl	%eax, %esi
    979f:      	jg	0x6bdd <generic_fentry_filter_arg+0x11d>
    97a5:      	cmpl	%edx, %eax
    97a7:      	jle	0x6da1 <generic_fentry_filter_arg+0x2e1>
    97ad:      	jmp	0x6bdd <generic_fentry_filter_arg+0x11d>
    97b2:      	cmpl	%esi, (%r12)
    97b6:      	ja	0x6da1 <generic_fentry_filter_arg+0x2e1>
    97bc:      	jmp	0x97c8 <generic_fentry_filter_arg+0x2d08>
    97be:      	cmpl	%esi, (%r12)
    97c2:      	jb	0x6da1 <generic_fentry_filter_arg+0x2e1>
    97c8:      	cmpl	$0x11, %edx
    97cb:      	jb	0xa181 <generic_fentry_filter_arg+0x36c1>
    97d1:      	movl	0x18(%r13), %esi
    97d5:      	cmpl	$0x2, %eax
    97d8:      	jle	0x97f5 <generic_fentry_filter_arg+0x2d35>
    97da:      	leal	-0x3(%rax), %edi
    97dd:      	cmpl	$0x2, %edi
    97e0:      	jae	0x982b <generic_fentry_filter_arg+0x2d6b>
    97e2:      	cmpl	%esi, (%r12)
    97e6:      	movq	(%rsp), %rdi
    97ea:      	je	0x6d85 <generic_fentry_filter_arg+0x2c5>
    97f0:      	jmp	0x9f10 <generic_fentry_filter_arg+0x3450>
    97f5:      	cmpl	$0x1, %eax
    97f8:      	je	0x9847 <generic_fentry_filter_arg+0x2d87>
    97fa:      	cmpl	$0x2, %eax
    97fd:      	jne	0x9f10 <generic_fentry_filter_arg+0x3450>
    9803:      	cmpl	$0xc, %ecx
    9806:      	ja	0x9f06 <generic_fentry_filter_arg+0x3446>
    980c:      	movl	$0x1402, %r8d           # imm = 0x1402
    9812:      	btl	%ecx, %r8d
    9816:      	jae	0x9f06 <generic_fentry_filter_arg+0x3446>
    981c:      	cmpl	%esi, (%r12)
    9820:      	jl	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9826:      	jmp	0x9f10 <generic_fentry_filter_arg+0x3450>
    982b:      	cmpl	$0xc, %eax
    982e:      	movq	(%rsp), %rdi
    9832:      	jne	0x9f10 <generic_fentry_filter_arg+0x3450>
    9838:      	testl	%esi, (%r12)
    983c:      	jne	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9842:      	jmp	0x9f10 <generic_fentry_filter_arg+0x3450>
    9847:      	cmpl	$0xc, %ecx
    984a:      	ja	0x9efa <generic_fentry_filter_arg+0x343a>
    9850:      	movl	$0x1402, %r8d           # imm = 0x1402
    9856:      	btl	%ecx, %r8d
    985a:      	jae	0x9efa <generic_fentry_filter_arg+0x343a>
    9860:      	cmpl	%esi, (%r12)
    9864:      	jg	0x6da1 <generic_fentry_filter_arg+0x2e1>
    986a:      	jmp	0x9f10 <generic_fentry_filter_arg+0x3450>
    986f:      	cmpq	%rdx, %rdi
    9872:      	setbe	%cl
    9875:      	cmpq	%rsi, %rdx
    9878:      	jmp	0x9b05 <generic_fentry_filter_arg+0x3045>
    987d:      	xorl	%ebx, %ebx
    987f:      	movq	0x68(%rsp), %r15
    9884:      	jmp	0xa0fb <generic_fentry_filter_arg+0x363b>
    9889:      	testl	%eax, %eax
    988b:      	je	0x9cb2 <generic_fentry_filter_arg+0x31f2>
    9891:      	cmpl	$0x1, %eax
    9894:      	jne	0x98ac <generic_fentry_filter_arg+0x2dec>
    9896:      	movl	$0x1, %eax
    989b:      	leaq	0x38(%rsp), %rsi
    98a0:      	movq	(%rip), %rdi            # 0x98a7 <generic_fentry_filter_arg+0x2de7>
    98a7:      	jmp	0x9d35 <generic_fentry_filter_arg+0x3275>
    98ac:      	xorl	%ebx, %ebx
    98ae:      	movl	0x4(%r13), %eax
    98b2:      	cmpq	$0x25, %rax
    98b6:      	jbe	0x9d71 <generic_fentry_filter_arg+0x32b1>
    98bc:      	jmp	0x6d90 <generic_fentry_filter_arg+0x2d0>
    98c1:      	movq	(%rsp), %rdi
    98c5:      	movq	0x8(%rsp), %r9
    98ca:      	movq	%r12, %r11
    98cd:      	movzbl	%cl, %ebx
    98d0:      	jmp	0x6d90 <generic_fentry_filter_arg+0x2d0>
    98d5:      	cmpq	%rax, %rsi
    98d8:      	ja	0x6bdd <generic_fentry_filter_arg+0x11d>
    98de:      	cmpq	%rdx, %rax
    98e1:      	jbe	0x6da1 <generic_fentry_filter_arg+0x2e1>
    98e7:      	jmp	0x6bdd <generic_fentry_filter_arg+0x11d>
    98ec:      	cmpl	$0x1, %eax
    98ef:      	je	0x9e2e <generic_fentry_filter_arg+0x336e>
    98f5:      	cmpl	$0x2, %eax
    98f8:      	jne	0x9e3b <generic_fentry_filter_arg+0x337b>
    98fe:      	movzbl	(%r12), %esi
    9903:      	cmpl	%esi, %edx
    9905:      	ja	0x6da1 <generic_fentry_filter_arg+0x2e1>
    990b:      	jmp	0x9e3b <generic_fentry_filter_arg+0x337b>
    9910:      	cmpl	$0x1, %eax
    9913:      	je	0x9e76 <generic_fentry_filter_arg+0x33b6>
    9919:      	cmpl	$0x2, %eax
    991c:      	jne	0x9e83 <generic_fentry_filter_arg+0x33c3>
    9922:      	movzwl	(%r12), %esi
    9927:      	cmpl	%esi, %edx
    9929:      	ja	0x6da1 <generic_fentry_filter_arg+0x2e1>
    992f:      	jmp	0x9e83 <generic_fentry_filter_arg+0x33c3>
    9934:      	testl	%ebx, %ebx
    9936:      	je	0x9d8e <generic_fentry_filter_arg+0x32ce>
    993c:      	cmpl	$0x1, %ebx
    993f:      	jne	0x9957 <generic_fentry_filter_arg+0x2e97>
    9941:      	movl	$0x1, %eax
    9946:      	leaq	0x38(%rsp), %rsi
    994b:      	movq	(%rip), %rdi            # 0x9952 <generic_fentry_filter_arg+0x2e92>
    9952:      	jmp	0x9e11 <generic_fentry_filter_arg+0x3351>
    9957:      	xorl	%ebx, %ebx
    9959:      	movq	(%rsp), %rdi
    995d:      	jmp	0xa0fb <generic_fentry_filter_arg+0x363b>
    9962:      	movl	$0xa, %eax
    9967:      	jmp	0x9975 <generic_fentry_filter_arg+0x2eb5>
    9969:      	movl	$0x6, %eax
    996e:      	jmp	0x9975 <generic_fentry_filter_arg+0x2eb5>
    9970:      	movl	$0x8, %eax
    9975:      	movl	%eax, %ecx
    9977:      	andl	$0xf, %ecx
    997a:      	movl	0x10(%r13,%rcx,4), %ecx
    997f:      	cmpl	$-0x1, %ecx
    9982:      	je	0xa0eb <generic_fentry_filter_arg+0x362b>
    9988:      	movl	%ecx, 0x90(%rsp)
    998f:      	movl	%eax, 0x88(%rsp)
    9996:      	movq	%rsi, 0x60(%rsp)
    999b:      	movl	$0x1, %eax
    99a0:      	movq	(%rip), %rdi            # 0x99a7 <generic_fentry_filter_arg+0x2ee7>
    99a7:      	movq	0x28(%rsp), %rbx
    99ac:      	movq	%rbx, %rsi
    99af:      	callq	*%rax
    99b1:      	movq	%rax, %r12
    99b4:      	movl	$0x1, %eax
    99b9:      	movq	(%rip), %rdi            # 0x99c0 <generic_fentry_filter_arg+0x2f00>
    99c0:      	movq	%rbx, %rsi
    99c3:      	callq	*%rax
    99c5:      	movq	%r12, 0x20(%rsp)
    99ca:      	testq	%r12, %r12
    99cd:      	je	0xa0eb <generic_fentry_filter_arg+0x362b>
    99d3:      	movl	$0x0, %ebx
    99d8:      	testq	%rax, %rax
    99db:      	movq	(%rsp), %rdi
    99df:      	movq	0x8(%rsp), %r9
    99e4:      	movq	0x10(%rsp), %r11
    99e9:      	je	0xa0fb <generic_fentry_filter_arg+0x363b>
    99ef:      	movq	%rax, %r12
    99f2:      	movl	0x88(%rsp), %ebx
    99f9:      	cmpl	$0x5, %ebx
    99fc:      	jg	0x9a3a <generic_fentry_filter_arg+0x2f7a>
    99fe:      	movq	0x20(%rsp), %rax
    9a03:      	movb	%bpl, (%rax)
    9a06:      	leaq	0x1(%rax), %rdi
    9a0a:      	movl	$0x4, %eax
    9a0f:      	movq	0x18(%rsp), %rdx
    9a14:      	movl	%ebp, %esi
    9a16:      	callq	*%rax
    9a18:      	movq	0x60(%rsp), %rsi
    9a1d:      	subl	%ebp, %esi
    9a1f:      	jbe	0x9a7a <generic_fentry_filter_arg+0x2fba>
    9a21:      	movq	0x20(%rsp), %rax
    9a26:      	leaq	(%rax,%rbp), %rdi
    9a2a:      	incq	%rdi
    9a2d:      	andl	$0xfff, %esi            # imm = 0xFFF
    9a33:      	movl	$0x4, %eax
    9a38:      	jmp	0x9a75 <generic_fentry_filter_arg+0x2fb5>
    9a3a:      	movq	0x20(%rsp), %rax
    9a3f:      	movw	%bp, (%rax)
    9a42:      	leaq	0x2(%rax), %rdi
    9a46:      	movl	$0x4, %eax
    9a4b:      	movq	0x18(%rsp), %rdx
    9a50:      	movl	%ebp, %esi
    9a52:      	callq	*%rax
    9a54:      	movq	0x60(%rsp), %rsi
    9a59:      	subl	%ebp, %esi
    9a5b:      	jbe	0x9a7a <generic_fentry_filter_arg+0x2fba>
    9a5d:      	movq	0x20(%rsp), %rax
    9a62:      	leaq	(%rax,%rbp), %rdi
    9a66:      	addq	$0x2, %rdi
    9a6a:      	andl	$0xfff, %esi            # imm = 0xFFF
    9a70:      	movl	$0x4, %eax
    9a75:      	movq	%r12, %rdx
    9a78:      	callq	*%rax
    9a7a:      	movl	0x90(%rsp), %eax
    9a81:      	movl	%eax, 0x38(%rsp)
    9a85:      	cmpl	$0x4, %ebx
    9a88:      	jle	0x9ac4 <generic_fentry_filter_arg+0x3004>
    9a8a:      	cmpl	$0x7, %ebx
    9a8d:      	jg	0x9ec9 <generic_fentry_filter_arg+0x3409>
    9a93:      	cmpl	$0x5, %ebx
    9a96:      	je	0xa0ae <generic_fentry_filter_arg+0x35ee>
    9a9c:      	cmpl	$0x6, %ebx
    9a9f:      	je	0xa075 <generic_fentry_filter_arg+0x35b5>
    9aa5:      	cmpl	$0x7, %ebx
    9aa8:      	jne	0xa0eb <generic_fentry_filter_arg+0x362b>
    9aae:      	movl	$0x1, %eax
    9ab3:      	leaq	0x38(%rsp), %rsi
    9ab8:      	movq	(%rip), %rdi            # 0x9abf <generic_fentry_filter_arg+0x2fff>
    9abf:      	jmp	0xa0d2 <generic_fentry_filter_arg+0x3612>
    9ac4:      	cmpl	$0x1, %ebx
    9ac7:      	jle	0x9fb4 <generic_fentry_filter_arg+0x34f4>
    9acd:      	cmpl	$0x2, %ebx
    9ad0:      	je	0xa09b <generic_fentry_filter_arg+0x35db>
    9ad6:      	cmpl	$0x3, %ebx
    9ad9:      	je	0xa062 <generic_fentry_filter_arg+0x35a2>
    9adf:      	cmpl	$0x4, %ebx
    9ae2:      	jne	0xa0eb <generic_fentry_filter_arg+0x362b>
    9ae8:      	movl	$0x1, %eax
    9aed:      	leaq	0x38(%rsp), %rsi
    9af2:      	movq	(%rip), %rdi            # 0x9af9 <generic_fentry_filter_arg+0x3039>
    9af9:      	jmp	0xa0d2 <generic_fentry_filter_arg+0x3612>
    9afe:      	cmpl	%edx, %edi
    9b00:      	setbe	%cl
    9b03:      	cmpl	%esi, %edx
    9b05:      	setbe	%dl
    9b08:      	andb	%cl, %dl
    9b0a:      	orb	%dl, %al
    9b0c:      	movq	(%rsp), %rdi
    9b10:      	testb	%al, %al
    9b12:      	je	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9b18:      	jmp	0x6bdd <generic_fentry_filter_arg+0x11d>
    9b1d:      	cmpq	%rsi, (%r12)
    9b21:      	ja	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9b27:      	jmp	0x9b33 <generic_fentry_filter_arg+0x3073>
    9b29:      	cmpq	%rsi, (%r12)
    9b2d:      	jb	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9b33:      	cmpl	$0x21, %edx
    9b36:      	jb	0xa181 <generic_fentry_filter_arg+0x36c1>
    9b3c:      	movq	0x28(%r13), %rdx
    9b40:      	cmpl	$0x2, %eax
    9b43:      	jle	0x9b6e <generic_fentry_filter_arg+0x30ae>
    9b45:      	leal	-0x3(%rax), %ecx
    9b48:      	cmpl	$0x2, %ecx
    9b4b:      	jb	0x9b9d <generic_fentry_filter_arg+0x30dd>
    9b4d:      	cmpl	$0x6, %eax
    9b50:      	je	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9b56:      	cmpl	$0xc, %eax
    9b59:      	jne	0x6bdd <generic_fentry_filter_arg+0x11d>
    9b5f:      	testq	%rdx, (%r12)
    9b63:      	jne	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9b69:      	jmp	0xa181 <generic_fentry_filter_arg+0x36c1>
    9b6e:      	cmpl	$0x1, %eax
    9b71:      	je	0x9c95 <generic_fentry_filter_arg+0x31d5>
    9b77:      	cmpl	$0x2, %eax
    9b7a:      	jne	0x6bdd <generic_fentry_filter_arg+0x11d>
    9b80:      	cmpl	$0xc, %ecx
    9b83:      	je	0x9b8e <generic_fentry_filter_arg+0x30ce>
    9b85:      	cmpl	$0xa, %ecx
    9b88:      	jne	0xa031 <generic_fentry_filter_arg+0x3571>
    9b8e:      	cmpq	%rdx, (%r12)
    9b92:      	jl	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9b98:      	jmp	0xa181 <generic_fentry_filter_arg+0x36c1>
    9b9d:      	cmpq	%rdx, (%r12)
    9ba1:      	jne	0xa181 <generic_fentry_filter_arg+0x36c1>
    9ba7:      	jmp	0x6d85 <generic_fentry_filter_arg+0x2c5>
    9bac:      	cmpl	$0xc, %eax
    9baf:      	jne	0x9e3b <generic_fentry_filter_arg+0x337b>
    9bb5:      	movzbl	(%r12), %esi
    9bba:      	testl	%esi, %edx
    9bbc:      	jne	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9bc2:      	jmp	0x9e3b <generic_fentry_filter_arg+0x337b>
    9bc7:      	cmpl	$0xc, %eax
    9bca:      	jne	0x9e83 <generic_fentry_filter_arg+0x33c3>
    9bd0:      	movzwl	(%r12), %esi
    9bd5:      	testl	%esi, %edx
    9bd7:      	jne	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9bdd:      	jmp	0x9e83 <generic_fentry_filter_arg+0x33c3>
    9be2:      	movl	$0x1, %eax
    9be7:      	movq	(%rip), %rdi            # 0x9bee <generic_fentry_filter_arg+0x312e>
    9bee:      	leaq	0x38(%rsp), %rsi
    9bf3:      	jmp	0x9c65 <generic_fentry_filter_arg+0x31a5>
    9bf5:      	movl	$0x1, %eax
    9bfa:      	leaq	0x38(%rsp), %rsi
    9bff:      	movq	(%rip), %rdi            # 0x9c06 <generic_fentry_filter_arg+0x3146>
    9c06:      	jmp	0x9c65 <generic_fentry_filter_arg+0x31a5>
    9c08:      	movl	$0x1, %eax
    9c0d:      	leaq	0x38(%rsp), %rsi
    9c12:      	movq	(%rip), %rdi            # 0x9c19 <generic_fentry_filter_arg+0x3159>
    9c19:      	jmp	0x9c65 <generic_fentry_filter_arg+0x31a5>
    9c1b:      	movl	$0x1, %eax
    9c20:      	leaq	0x38(%rsp), %rsi
    9c25:      	movq	(%rip), %rdi            # 0x9c2c <generic_fentry_filter_arg+0x316c>
    9c2c:      	jmp	0x9c65 <generic_fentry_filter_arg+0x31a5>
    9c2e:      	movl	$0x1, %eax
    9c33:      	leaq	0x38(%rsp), %rsi
    9c38:      	movq	(%rip), %rdi            # 0x9c3f <generic_fentry_filter_arg+0x317f>
    9c3f:      	jmp	0x9c65 <generic_fentry_filter_arg+0x31a5>
    9c41:      	movl	$0x1, %eax
    9c46:      	leaq	0x38(%rsp), %rsi
    9c4b:      	movq	(%rip), %rdi            # 0x9c52 <generic_fentry_filter_arg+0x3192>
    9c52:      	jmp	0x9c65 <generic_fentry_filter_arg+0x31a5>
    9c54:      	movl	$0x1, %eax
    9c59:      	leaq	0x38(%rsp), %rsi
    9c5e:      	movq	(%rip), %rdi            # 0x9c65 <generic_fentry_filter_arg+0x31a5>
    9c65:      	callq	*%rax
    9c67:      	testq	%rax, %rax
    9c6a:      	je	0x9d53 <generic_fentry_filter_arg+0x3293>
    9c70:      	movq	%rax, %rdi
    9c73:      	movl	$0x1, %eax
    9c78:      	movq	%r12, %rsi
    9c7b:      	jmp	0x9d47 <generic_fentry_filter_arg+0x3287>
    9c80:      	cmpl	%eax, %esi
    9c82:      	ja	0x6bdd <generic_fentry_filter_arg+0x11d>
    9c88:      	cmpl	%edx, %eax
    9c8a:      	jbe	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9c90:      	jmp	0x6bdd <generic_fentry_filter_arg+0x11d>
    9c95:      	cmpl	$0xc, %ecx
    9c98:      	je	0x9ca3 <generic_fentry_filter_arg+0x31e3>
    9c9a:      	cmpl	$0xa, %ecx
    9c9d:      	jne	0xa040 <generic_fentry_filter_arg+0x3580>
    9ca3:      	cmpq	%rdx, (%r12)
    9ca7:      	jg	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9cad:      	jmp	0xa181 <generic_fentry_filter_arg+0x36c1>
    9cb2:      	movl	$0x1, %eax
    9cb7:      	movq	(%rip), %rdi            # 0x9cbe <generic_fentry_filter_arg+0x31fe>
    9cbe:      	leaq	0x38(%rsp), %rsi
    9cc3:      	jmp	0x9d35 <generic_fentry_filter_arg+0x3275>
    9cc5:      	movl	$0x1, %eax
    9cca:      	leaq	0x38(%rsp), %rsi
    9ccf:      	movq	(%rip), %rdi            # 0x9cd6 <generic_fentry_filter_arg+0x3216>
    9cd6:      	jmp	0x9d35 <generic_fentry_filter_arg+0x3275>
    9cd8:      	movl	$0x1, %eax
    9cdd:      	leaq	0x38(%rsp), %rsi
    9ce2:      	movq	(%rip), %rdi            # 0x9ce9 <generic_fentry_filter_arg+0x3229>
    9ce9:      	jmp	0x9d35 <generic_fentry_filter_arg+0x3275>
    9ceb:      	movl	$0x1, %eax
    9cf0:      	leaq	0x38(%rsp), %rsi
    9cf5:      	movq	(%rip), %rdi            # 0x9cfc <generic_fentry_filter_arg+0x323c>
    9cfc:      	jmp	0x9d35 <generic_fentry_filter_arg+0x3275>
    9cfe:      	movl	$0x1, %eax
    9d03:      	leaq	0x38(%rsp), %rsi
    9d08:      	movq	(%rip), %rdi            # 0x9d0f <generic_fentry_filter_arg+0x324f>
    9d0f:      	jmp	0x9d35 <generic_fentry_filter_arg+0x3275>
    9d11:      	movl	$0x1, %eax
    9d16:      	leaq	0x38(%rsp), %rsi
    9d1b:      	movq	(%rip), %rdi            # 0x9d22 <generic_fentry_filter_arg+0x3262>
    9d22:      	jmp	0x9d35 <generic_fentry_filter_arg+0x3275>
    9d24:      	movl	$0x1, %eax
    9d29:      	leaq	0x38(%rsp), %rsi
    9d2e:      	movq	(%rip), %rdi            # 0x9d35 <generic_fentry_filter_arg+0x3275>
    9d35:      	callq	*%rax
    9d37:      	testq	%rax, %rax
    9d3a:      	je	0x9d53 <generic_fentry_filter_arg+0x3293>
    9d3c:      	movq	%rax, %rdi
    9d3f:      	movl	$0x1, %eax
    9d44:      	movq	%rbp, %rsi
    9d47:      	callq	*%rax
    9d49:      	xorl	%ebx, %ebx
    9d4b:      	testq	%rax, %rax
    9d4e:      	setne	%bl
    9d51:      	jmp	0x9d55 <generic_fentry_filter_arg+0x3295>
    9d53:      	xorl	%ebx, %ebx
    9d55:      	movq	(%rsp), %rdi
    9d59:      	movq	0x8(%rsp), %r9
    9d5e:      	movq	0x10(%rsp), %r11
    9d63:      	movl	0x4(%r13), %eax
    9d67:      	cmpq	$0x25, %rax
    9d6b:      	ja	0x6d90 <generic_fentry_filter_arg+0x2d0>
    9d71:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    9d7b:      	btq	%rax, %rcx
    9d7f:      	jae	0x6d90 <generic_fentry_filter_arg+0x2d0>
    9d85:      	xorq	$0x1, %rbx
    9d89:      	jmp	0x6d90 <generic_fentry_filter_arg+0x2d0>
    9d8e:      	movl	$0x1, %eax
    9d93:      	movq	(%rip), %rdi            # 0x9d9a <generic_fentry_filter_arg+0x32da>
    9d9a:      	leaq	0x38(%rsp), %rsi
    9d9f:      	jmp	0x9e11 <generic_fentry_filter_arg+0x3351>
    9da1:      	movl	$0x1, %eax
    9da6:      	leaq	0x38(%rsp), %rsi
    9dab:      	movq	(%rip), %rdi            # 0x9db2 <generic_fentry_filter_arg+0x32f2>
    9db2:      	jmp	0x9e11 <generic_fentry_filter_arg+0x3351>
    9db4:      	movl	$0x1, %eax
    9db9:      	leaq	0x38(%rsp), %rsi
    9dbe:      	movq	(%rip), %rdi            # 0x9dc5 <generic_fentry_filter_arg+0x3305>
    9dc5:      	jmp	0x9e11 <generic_fentry_filter_arg+0x3351>
    9dc7:      	movl	$0x1, %eax
    9dcc:      	leaq	0x38(%rsp), %rsi
    9dd1:      	movq	(%rip), %rdi            # 0x9dd8 <generic_fentry_filter_arg+0x3318>
    9dd8:      	jmp	0x9e11 <generic_fentry_filter_arg+0x3351>
    9dda:      	movl	$0x1, %eax
    9ddf:      	leaq	0x38(%rsp), %rsi
    9de4:      	movq	(%rip), %rdi            # 0x9deb <generic_fentry_filter_arg+0x332b>
    9deb:      	jmp	0x9e11 <generic_fentry_filter_arg+0x3351>
    9ded:      	movl	$0x1, %eax
    9df2:      	leaq	0x38(%rsp), %rsi
    9df7:      	movq	(%rip), %rdi            # 0x9dfe <generic_fentry_filter_arg+0x333e>
    9dfe:      	jmp	0x9e11 <generic_fentry_filter_arg+0x3351>
    9e00:      	movl	$0x1, %eax
    9e05:      	leaq	0x38(%rsp), %rsi
    9e0a:      	movq	(%rip), %rdi            # 0x9e11 <generic_fentry_filter_arg+0x3351>
    9e11:      	callq	*%rax
    9e13:      	testq	%rax, %rax
    9e16:      	je	0xa0eb <generic_fentry_filter_arg+0x362b>
    9e1c:      	movq	%rax, %rdi
    9e1f:      	movl	$0x1, %eax
    9e24:      	movq	0x20(%rsp), %rsi
    9e29:      	jmp	0x85a8 <generic_fentry_filter_arg+0x1ae8>
    9e2e:      	movzbl	(%r12), %esi
    9e33:      	cmpl	%esi, %edx
    9e35:      	jb	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9e3b:      	cmpl	$0x15, %ecx
    9e3e:      	jb	0xa181 <generic_fentry_filter_arg+0x36c1>
    9e44:      	movl	0x1c(%r13), %ecx
    9e48:      	cmpl	$0x2, %eax
    9e4b:      	jle	0x9fdb <generic_fentry_filter_arg+0x351b>
    9e51:      	leal	-0x3(%rax), %edx
    9e54:      	cmpl	$0x2, %edx
    9e57:      	jb	0xa018 <generic_fentry_filter_arg+0x3558>
    9e5d:      	cmpl	$0x6, %eax
    9e60:      	je	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9e66:      	cmpl	$0xc, %eax
    9e69:      	jne	0x6bdd <generic_fentry_filter_arg+0x11d>
    9e6f:      	movzbl	(%r12), %edx
    9e74:      	jmp	0x9ebc <generic_fentry_filter_arg+0x33fc>
    9e76:      	movzwl	(%r12), %esi
    9e7b:      	cmpl	%esi, %edx
    9e7d:      	jb	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9e83:      	cmpl	$0x15, %ecx
    9e86:      	jb	0xa181 <generic_fentry_filter_arg+0x36c1>
    9e8c:      	movl	0x1c(%r13), %ecx
    9e90:      	cmpl	$0x2, %eax
    9e93:      	jle	0x9ff4 <generic_fentry_filter_arg+0x3534>
    9e99:      	leal	-0x3(%rax), %edx
    9e9c:      	cmpl	$0x2, %edx
    9e9f:      	jb	0xa01f <generic_fentry_filter_arg+0x355f>
    9ea5:      	cmpl	$0x6, %eax
    9ea8:      	je	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9eae:      	cmpl	$0xc, %eax
    9eb1:      	jne	0x6bdd <generic_fentry_filter_arg+0x11d>
    9eb7:      	movzwl	(%r12), %edx
    9ebc:      	testl	%edx, %ecx
    9ebe:      	jne	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9ec4:      	jmp	0xa181 <generic_fentry_filter_arg+0x36c1>
    9ec9:      	cmpl	$0x8, %ebx
    9ecc:      	je	0xa0c1 <generic_fentry_filter_arg+0x3601>
    9ed2:      	cmpl	$0x9, %ebx
    9ed5:      	je	0xa088 <generic_fentry_filter_arg+0x35c8>
    9edb:      	cmpl	$0xa, %ebx
    9ede:      	jne	0xa0eb <generic_fentry_filter_arg+0x362b>
    9ee4:      	movl	$0x1, %eax
    9ee9:      	leaq	0x38(%rsp), %rsi
    9eee:      	movq	(%rip), %rdi            # 0x9ef5 <generic_fentry_filter_arg+0x3435>
    9ef5:      	jmp	0xa0d2 <generic_fentry_filter_arg+0x3612>
    9efa:      	cmpl	%esi, (%r12)
    9efe:      	ja	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9f04:      	jmp	0x9f10 <generic_fentry_filter_arg+0x3450>
    9f06:      	cmpl	%esi, (%r12)
    9f0a:      	jb	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9f10:      	cmpl	$0x15, %edx
    9f13:      	jb	0xa181 <generic_fentry_filter_arg+0x36c1>
    9f19:      	movl	0x1c(%r13), %edx
    9f1d:      	cmpl	$0x2, %eax
    9f20:      	jle	0x9f4b <generic_fentry_filter_arg+0x348b>
    9f22:      	leal	-0x3(%rax), %ecx
    9f25:      	cmpl	$0x2, %ecx
    9f28:      	jb	0x9f7f <generic_fentry_filter_arg+0x34bf>
    9f2a:      	cmpl	$0x6, %eax
    9f2d:      	je	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9f33:      	cmpl	$0xc, %eax
    9f36:      	jne	0x6bdd <generic_fentry_filter_arg+0x11d>
    9f3c:      	testl	%edx, (%r12)
    9f40:      	jne	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9f46:      	jmp	0xa181 <generic_fentry_filter_arg+0x36c1>
    9f4b:      	cmpl	$0x1, %eax
    9f4e:      	je	0x9f8e <generic_fentry_filter_arg+0x34ce>
    9f50:      	cmpl	$0x2, %eax
    9f53:      	jne	0x6bdd <generic_fentry_filter_arg+0x11d>
    9f59:      	cmpl	$0xc, %ecx
    9f5c:      	ja	0xa16b <generic_fentry_filter_arg+0x36ab>
    9f62:      	movl	$0x1402, %esi           # imm = 0x1402
    9f67:      	btl	%ecx, %esi
    9f6a:      	jae	0xa16b <generic_fentry_filter_arg+0x36ab>
    9f70:      	cmpl	%edx, (%r12)
    9f74:      	jl	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9f7a:      	jmp	0xa181 <generic_fentry_filter_arg+0x36c1>
    9f7f:      	cmpl	%edx, (%r12)
    9f83:      	je	0x6d85 <generic_fentry_filter_arg+0x2c5>
    9f89:      	jmp	0xa181 <generic_fentry_filter_arg+0x36c1>
    9f8e:      	cmpl	$0xc, %ecx
    9f91:      	ja	0xa177 <generic_fentry_filter_arg+0x36b7>
    9f97:      	movl	$0x1402, %esi           # imm = 0x1402
    9f9c:      	btl	%ecx, %esi
    9f9f:      	jae	0xa177 <generic_fentry_filter_arg+0x36b7>
    9fa5:      	cmpl	%edx, (%r12)
    9fa9:      	jg	0x6da1 <generic_fentry_filter_arg+0x2e1>
    9faf:      	jmp	0xa181 <generic_fentry_filter_arg+0x36c1>
    9fb4:      	testl	%ebx, %ebx
    9fb6:      	je	0xa04f <generic_fentry_filter_arg+0x358f>
    9fbc:      	cmpl	$0x1, %ebx
    9fbf:      	jne	0xa0eb <generic_fentry_filter_arg+0x362b>
    9fc5:      	movl	$0x1, %eax
    9fca:      	leaq	0x38(%rsp), %rsi
    9fcf:      	movq	(%rip), %rdi            # 0x9fd6 <generic_fentry_filter_arg+0x3516>
    9fd6:      	jmp	0xa0d2 <generic_fentry_filter_arg+0x3612>
    9fdb:      	cmpl	$0x1, %eax
    9fde:      	je	0xa155 <generic_fentry_filter_arg+0x3695>
    9fe4:      	cmpl	$0x2, %eax
    9fe7:      	jne	0x6bdd <generic_fentry_filter_arg+0x11d>
    9fed:      	movzbl	(%r12), %edx
    9ff2:      	jmp	0xa00b <generic_fentry_filter_arg+0x354b>
    9ff4:      	cmpl	$0x1, %eax
    9ff7:      	je	0xa15c <generic_fentry_filter_arg+0x369c>
    9ffd:      	cmpl	$0x2, %eax
    a000:      	jne	0x6bdd <generic_fentry_filter_arg+0x11d>
    a006:      	movzwl	(%r12), %edx
    a00b:      	cmpl	%edx, %ecx
    a00d:      	ja	0x6da1 <generic_fentry_filter_arg+0x2e1>
    a013:      	jmp	0xa181 <generic_fentry_filter_arg+0x36c1>
    a018:      	movzbl	(%r12), %edx
    a01d:      	jmp	0xa024 <generic_fentry_filter_arg+0x3564>
    a01f:      	movzwl	(%r12), %edx
    a024:      	cmpl	%edx, %ecx
    a026:      	je	0x6d85 <generic_fentry_filter_arg+0x2c5>
    a02c:      	jmp	0xa181 <generic_fentry_filter_arg+0x36c1>
    a031:      	cmpq	%rdx, (%r12)
    a035:      	jb	0x6da1 <generic_fentry_filter_arg+0x2e1>
    a03b:      	jmp	0xa181 <generic_fentry_filter_arg+0x36c1>
    a040:      	cmpq	%rdx, (%r12)
    a044:      	ja	0x6da1 <generic_fentry_filter_arg+0x2e1>
    a04a:      	jmp	0xa181 <generic_fentry_filter_arg+0x36c1>
    a04f:      	movl	$0x1, %eax
    a054:      	movq	(%rip), %rdi            # 0xa05b <generic_fentry_filter_arg+0x359b>
    a05b:      	leaq	0x38(%rsp), %rsi
    a060:      	jmp	0xa0d2 <generic_fentry_filter_arg+0x3612>
    a062:      	movl	$0x1, %eax
    a067:      	leaq	0x38(%rsp), %rsi
    a06c:      	movq	(%rip), %rdi            # 0xa073 <generic_fentry_filter_arg+0x35b3>
    a073:      	jmp	0xa0d2 <generic_fentry_filter_arg+0x3612>
    a075:      	movl	$0x1, %eax
    a07a:      	leaq	0x38(%rsp), %rsi
    a07f:      	movq	(%rip), %rdi            # 0xa086 <generic_fentry_filter_arg+0x35c6>
    a086:      	jmp	0xa0d2 <generic_fentry_filter_arg+0x3612>
    a088:      	movl	$0x1, %eax
    a08d:      	leaq	0x38(%rsp), %rsi
    a092:      	movq	(%rip), %rdi            # 0xa099 <generic_fentry_filter_arg+0x35d9>
    a099:      	jmp	0xa0d2 <generic_fentry_filter_arg+0x3612>
    a09b:      	movl	$0x1, %eax
    a0a0:      	leaq	0x38(%rsp), %rsi
    a0a5:      	movq	(%rip), %rdi            # 0xa0ac <generic_fentry_filter_arg+0x35ec>
    a0ac:      	jmp	0xa0d2 <generic_fentry_filter_arg+0x3612>
    a0ae:      	movl	$0x1, %eax
    a0b3:      	leaq	0x38(%rsp), %rsi
    a0b8:      	movq	(%rip), %rdi            # 0xa0bf <generic_fentry_filter_arg+0x35ff>
    a0bf:      	jmp	0xa0d2 <generic_fentry_filter_arg+0x3612>
    a0c1:      	movl	$0x1, %eax
    a0c6:      	leaq	0x38(%rsp), %rsi
    a0cb:      	movq	(%rip), %rdi            # 0xa0d2 <generic_fentry_filter_arg+0x3612>
    a0d2:      	callq	*%rax
    a0d4:      	testq	%rax, %rax
    a0d7:      	je	0xa0eb <generic_fentry_filter_arg+0x362b>
    a0d9:      	movq	%rax, %rdi
    a0dc:      	movl	$0x1, %eax
    a0e1:      	movq	0x20(%rsp), %rsi
    a0e6:      	jmp	0x85a8 <generic_fentry_filter_arg+0x1ae8>
    a0eb:      	xorl	%ebx, %ebx
    a0ed:      	movq	(%rsp), %rdi
    a0f1:      	movq	0x8(%rsp), %r9
    a0f6:      	movq	0x10(%rsp), %r11
    a0fb:      	movl	0x4(%r13), %eax
    a0ff:      	cmpq	$0x25, %rax
    a103:      	ja	0x6d90 <generic_fentry_filter_arg+0x2d0>
    a109:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    a113:      	btq	%rax, %rcx
    a117:      	jae	0x6d90 <generic_fentry_filter_arg+0x2d0>
    a11d:      	xorl	%eax, %eax
    a11f:      	testq	%rbx, %rbx
    a122:      	sete	%al
    a125:      	movq	%rax, %rbx
    a128:      	jmp	0x6d90 <generic_fentry_filter_arg+0x2d0>
    a12d:      	xorl	%ebx, %ebx
    a12f:      	movq	(%rsp), %rdi
    a133:      	movq	0x8(%rsp), %r9
    a138:      	movq	0x10(%rsp), %r11
    a13d:      	movq	0x68(%rsp), %r15
    a142:      	movl	0x4(%r13), %eax
    a146:      	cmpq	$0x25, %rax
    a14a:      	jbe	0x9d71 <generic_fentry_filter_arg+0x32b1>
    a150:      	jmp	0x6d90 <generic_fentry_filter_arg+0x2d0>
    a155:      	movzbl	(%r12), %edx
    a15a:      	jmp	0xa161 <generic_fentry_filter_arg+0x36a1>
    a15c:      	movzwl	(%r12), %edx
    a161:      	cmpl	%edx, %ecx
    a163:      	jb	0x6da1 <generic_fentry_filter_arg+0x2e1>
    a169:      	jmp	0xa181 <generic_fentry_filter_arg+0x36c1>
    a16b:      	cmpl	%edx, (%r12)
    a16f:      	jb	0x6da1 <generic_fentry_filter_arg+0x2e1>
    a175:      	jmp	0xa181 <generic_fentry_filter_arg+0x36c1>
    a177:      	cmpl	%edx, (%r12)
    a17b:      	ja	0x6da1 <generic_fentry_filter_arg+0x2e1>
    a181:      	orl	$0x2, %eax
    a184:      	cmpl	$0x6, %eax
    a187:      	je	0x6da1 <generic_fentry_filter_arg+0x2e1>
    a18d:      	jmp	0x6bdd <generic_fentry_filter_arg+0x11d>
    a192:      	nopw	%cs:(%rax,%rax)

000000000000a1a0 <generic_fentry_actions>:
    a1a0:      	pushq	%rbp
    a1a1:      	pushq	%r15
    a1a3:      	pushq	%r14
    a1a5:      	pushq	%r13
    a1a7:      	pushq	%r12
    a1a9:      	pushq	%rbx
    a1aa:      	subq	$0xa8, %rsp
    a1b1:      	movq	%rdi, 0x80(%rsp)
    a1b9:      	movl	$0x0, 0x88(%rsp)
    a1c4:      	movq	(%rip), %rdi            # 0xa1cb <generic_fentry_actions+0x2b>
    a1cb:      	leaq	0x88(%rsp), %rsi
    a1d3:      	movl	$0x1, %eax
    a1d8:      	callq	*%rax
    a1da:      	testq	%rax, %rax
    a1dd:      	je	0xacd8 <generic_fentry_actions+0xb38>
    a1e3:      	movq	%rax, %rsi
    a1e6:      	movl	0x5f04(%rax), %ebx
    a1ec:      	cmpl	$0x2, %ebx
    a1ef:      	jl	0xacd8 <generic_fentry_actions+0xb38>
    a1f5:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    a1fc:      	movq	(%rip), %rdi            # 0xa203 <generic_fentry_actions+0x63>
    a203:      	movl	$0x1, %eax
    a208:      	callq	*%rax
    a20a:      	testq	%rax, %rax
    a20d:      	je	0xacd8 <generic_fentry_actions+0xb38>
    a213:      	movq	%rax, %r14
    a216:      	movl	%ebx, %eax
    a218:      	andl	$0x7ff, %eax            # imm = 0x7FF
    a21d:      	addl	(%r14,%rax), %ebx
    a221:      	movl	$0x0, 0x8c(%rsp)
    a22c:      	movq	(%rip), %rdi            # 0xa233 <generic_fentry_actions+0x93>
    a233:      	leaq	0x8c(%rsp), %rsi
    a23b:      	movl	$0x1, %eax
    a240:      	andl	$0x7ff, %ebx            # imm = 0x7FF
    a246:      	callq	*%rax
    a248:      	testq	%rax, %rax
    a24b:      	je	0xa272 <generic_fentry_actions+0xd2>
    a24d:      	cmpb	$0x0, (%rax)
    a250:      	sete	0x17(%rsp)
    a255:      	je	0xa28d <generic_fentry_actions+0xed>
    a257:      	movl	$0x5, %eax
    a25c:      	movq	%rax, 0x78(%rsp)
    a261:      	movl	$0x9, %eax
    a266:      	movq	%rax, 0x70(%rsp)
    a26b:      	movl	$0x7, %eax
    a270:      	jmp	0xa2a6 <generic_fentry_actions+0x106>
    a272:      	movl	$0x4, %eax
    a277:      	movq	%rax, 0x78(%rsp)
    a27c:      	movl	$0x8, %eax
    a281:      	movq	%rax, 0x70(%rsp)
    a286:      	movb	$0x1, 0x17(%rsp)
    a28b:      	jmp	0xa2a1 <generic_fentry_actions+0x101>
    a28d:      	movl	$0x4, %eax
    a292:      	movq	%rax, 0x78(%rsp)
    a297:      	movl	$0x8, %eax
    a29c:      	movq	%rax, 0x70(%rsp)
    a2a1:      	movl	$0x6, %eax
    a2a6:      	movq	%rax, 0x68(%rsp)
    a2ab:      	addq	%rbx, %r14
    a2ae:      	movb	$0x1, %al
    a2b0:      	movl	%eax, 0x44(%rsp)
    a2b4:      	movq	(%rip), %rbp            # 0xa2bb <generic_fentry_actions+0x11b>
    a2bb:      	xorl	%r12d, %r12d
    a2be:      	xorl	%r15d, %r15d
    a2c1:      	jmp	0xa2ea <generic_fentry_actions+0x14a>
    a2c3:      	incl	%r15d
    a2c6:      	movl	0x4(%r14,%r15,4), %eax
    a2cb:      	movl	%eax, 0x78(%rdx)
    a2ce:      	nop
    a2d0:      	movq	%r13, 0x70(%rdx)
    a2d4:      	incl	%r15d
    a2d7:      	movl	%r15d, %ebx
    a2da:      	incl	%r12d
    a2dd:      	movl	%ebx, %r15d
    a2e0:      	cmpl	$0x3, %r12d
    a2e4:      	je	0xacb1 <generic_fentry_actions+0xb11>
    a2ea:      	leal	0x4(,%r15,4), %eax
    a2f2:      	cmpl	(%r14), %eax
    a2f5:      	jae	0xacb1 <generic_fentry_actions+0xb11>
    a2fb:      	movl	%r15d, %eax
    a2fe:      	movslq	0x4(%r14,%rax,4), %r13
    a303:      	movl	$0x0, 0x90(%rsp)
    a30e:      	movl	$0x1, %eax
    a313:      	leaq	0x90(%rsp), %rsi
    a31b:      	movq	%rbp, %rdi
    a31e:      	callq	*%rax
    a320:      	xorl	%ebx, %ebx
    a322:      	testq	%rax, %rax
    a325:      	je	0xa2da <generic_fentry_actions+0x13a>
    a327:      	movq	%rax, %rdx
    a32a:      	cmpl	$0x7, %r13d
    a32e:      	jg	0xa360 <generic_fentry_actions+0x1c0>
    a330:      	cmpl	$0x3, %r13d
    a334:      	jg	0xa3b6 <generic_fentry_actions+0x216>
    a33a:      	cmpl	$0x1, %r13d
    a33e:      	jg	0xa507 <generic_fentry_actions+0x367>
    a344:      	testl	%r13d, %r13d
    a347:      	je	0xa717 <generic_fentry_actions+0x577>
    a34d:      	cmpl	$0x1, %r13d
    a351:      	je	0xa520 <generic_fentry_actions+0x380>
    a357:      	jmp	0xa2d0 <generic_fentry_actions+0x130>
    a35c:      	nopl	(%rax)
    a360:      	cmpl	$0xb, %r13d
    a364:      	jg	0xa4d0 <generic_fentry_actions+0x330>
    a36a:      	leal	-0xa(%r13), %eax
    a36e:      	cmpl	$0x2, %eax
    a371:      	jb	0xa5af <generic_fentry_actions+0x40f>
    a377:      	cmpl	$0x8, %r13d
    a37b:      	je	0xa671 <generic_fentry_actions+0x4d1>
    a381:      	cmpl	$0x9, %r13d
    a385:      	jne	0xa2d0 <generic_fentry_actions+0x130>
    a38b:      	movq	%r13, 0x8(%rsp)
    a390:      	movq	%r14, %rax
    a393:      	movq	%rbp, %r13
    a396:      	incl	%r15d
    a399:      	movl	0x4(%r14,%r15,4), %eax
    a39e:      	movq	%rdx, %rbp
    a3a1:      	movl	$0x3, %ebx
    a3a6:      	cmpb	$0x0, 0x17(%rsp)
    a3ab:      	jne	0xa7f3 <generic_fentry_actions+0x653>
    a3b1:      	jmp	0xa818 <generic_fentry_actions+0x678>
    a3b6:      	leal	-0x6(%r13), %eax
    a3ba:      	cmpl	$0x2, %eax
    a3bd:      	jb	0xa2c3 <generic_fentry_actions+0x123>
    a3c3:      	cmpl	$0x4, %r13d
    a3c7:      	je	0xa67e <generic_fentry_actions+0x4de>
    a3cd:      	cmpl	$0x5, %r13d
    a3d1:      	jne	0xa2d0 <generic_fentry_actions+0x130>
    a3d7:      	leal	0x1(%r15), %eax
    a3db:      	movl	0x4(%r14,%rax,4), %eax
    a3e0:      	addl	$0x2, %r15d
    a3e4:      	movl	0x4(%r14,%r15,4), %ebx
    a3e9:      	movq	$0x0, 0x20(%rsp)
    a3f2:      	movq	$0x0, 0x18(%rsp)
    a3fb:      	andl	$0x7, %eax
    a3fe:      	cmpl	$0x4, %eax
    a401:      	ja	0xa2d0 <generic_fentry_actions+0x130>
    a407:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    a40f:      	jne	0xa2d0 <generic_fentry_actions+0x130>
    a415:      	movq	0x5e78(%rdx,%rax,8), %rax
    a41d:      	andl	$0x7ff, %eax            # imm = 0x7FF
    a422:      	movl	0x90(%rdx,%rax), %eax
    a429:      	movl	%eax, 0x20(%rsp)
    a42d:      	movl	$0xe, %eax
    a432:      	movq	%rdx, 0x8(%rsp)
    a437:      	callq	*%rax
    a439:      	shrq	$0x20, %rax
    a43d:      	movq	%rax, 0x18(%rsp)
    a442:      	movl	$0x1, %eax
    a447:      	leaq	0x18(%rsp), %rsi
    a44c:      	movq	(%rip), %rdi            # 0xa453 <generic_fentry_actions+0x2b3>
    a453:      	callq	*%rax
    a455:      	movq	0x8(%rsp), %rdx
    a45a:      	testq	%rax, %rax
    a45d:      	je	0xa2d0 <generic_fentry_actions+0x130>
    a463:      	andl	$0x7, %ebx
    a466:      	cmpl	$0x4, %ebx
    a469:      	ja	0xa2d0 <generic_fentry_actions+0x130>
    a46f:      	cmpl	$0x0, 0x5ea0(%rdx,%rbx,4)
    a477:      	jne	0xa2d0 <generic_fentry_actions+0x130>
    a47d:      	movq	0x5e78(%rdx,%rbx,8), %rcx
    a485:      	movl	$0x0, 0x24(%rsp)
    a48d:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    a493:      	movl	0x90(%rdx,%rcx), %ecx
    a49a:      	movl	%ecx, 0x20(%rsp)
    a49e:      	movq	%rax, %rbx
    a4a1:      	movl	$0xe, %eax
    a4a6:      	callq	*%rax
    a4a8:      	shrq	$0x20, %rax
    a4ac:      	movq	%rax, 0x18(%rsp)
    a4b1:      	movl	$0x2, %eax
    a4b6:      	xorl	%ecx, %ecx
    a4b8:      	leaq	0x18(%rsp), %rsi
    a4bd:      	movq	(%rip), %rdi            # 0xa4c4 <generic_fentry_actions+0x324>
    a4c4:      	movq	%rbx, %rdx
    a4c7:      	xorl	%ecx, %ecx
    a4c9:      	callq	*%rax
    a4cb:      	jmp	0xa70d <generic_fentry_actions+0x56d>
    a4d0:      	cmpl	$0xc, %r13d
    a4d4:      	je	0xa804 <generic_fentry_actions+0x664>
    a4da:      	cmpl	$0xd, %r13d
    a4de:      	je	0xa696 <generic_fentry_actions+0x4f6>
    a4e4:      	cmpl	$0xe, %r13d
    a4e8:      	jne	0xa2d0 <generic_fentry_actions+0x130>
    a4ee:      	movq	%r13, 0x8(%rsp)
    a4f3:      	movq	%rbp, %r13
    a4f6:      	movq	%rdx, %rbp
    a4f9:      	addl	$0x2, %r15d
    a4fd:      	movq	0x70(%rsp), %rbx
    a502:      	jmp	0xa818 <generic_fentry_actions+0x678>
    a507:      	movl	$0x9, %eax
    a50c:      	cmpl	$0x2, %r13d
    a510:      	je	0xa7dc <generic_fentry_actions+0x63c>
    a516:      	cmpl	$0x3, %r13d
    a51a:      	jne	0xa2d0 <generic_fentry_actions+0x130>
    a520:      	movq	%rdx, 0x8(%rsp)
    a525:      	leal	0x1(%r15), %eax
    a529:      	movq	%r14, %rcx
    a52c:      	movl	0x4(%r14,%rax,4), %r14d
    a531:      	addl	$0x2, %r15d
    a535:      	movq	%rcx, %rbp
    a538:      	movl	0x4(%rcx,%r15,4), %eax
    a53d:      	movq	%rax, 0x38(%rsp)
    a542:      	movq	$0x0, 0x20(%rsp)
    a54b:      	movq	$0x0, 0x18(%rsp)
    a554:      	movl	$0x0, 0x28(%rsp)
    a55c:      	movl	$0x1, %eax
    a561:      	leaq	0x28(%rsp), %rsi
    a566:      	movq	(%rip), %rdi            # 0xa56d <generic_fentry_actions+0x3cd>
    a56d:      	callq	*%rax
    a56f:      	xorl	%ecx, %ecx
    a571:      	testq	%rax, %rax
    a574:      	je	0xa9a8 <generic_fentry_actions+0x808>
    a57a:      	andl	$0x7, %r14d
    a57e:      	cmpl	$0x4, %r14d
    a582:      	movq	0x8(%rsp), %rdx
    a587:      	ja	0xa598 <generic_fentry_actions+0x3f8>
    a589:      	cmpl	$0x0, 0x5ea0(%rdx,%r14,4)
    a592:      	je	0xa84d <generic_fentry_actions+0x6ad>
    a598:      	movq	%rbp, %r14
    a59b:      	movq	(%rip), %rbp            # 0xa5a2 <generic_fentry_actions+0x402>
    a5a2:      	testl	%ecx, %ecx
    a5a4:      	jne	0xa2da <generic_fentry_actions+0x13a>
    a5aa:      	jmp	0xa2d0 <generic_fentry_actions+0x130>
    a5af:      	incl	%r15d
    a5b2:      	movl	0x4(%r14,%r15,4), %eax
    a5b7:      	andl	$0x7, %eax
    a5ba:      	xorl	%ecx, %ecx
    a5bc:      	cmpl	$0x4, %eax
    a5bf:      	ja	0xa9b7 <generic_fentry_actions+0x817>
    a5c5:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    a5cd:      	jne	0xa9b7 <generic_fentry_actions+0x817>
    a5d3:      	movq	0x5e78(%rdx,%rax,8), %rax
    a5db:      	andl	$0x7ff, %eax            # imm = 0x7FF
    a5e0:      	movq	0xb8(%rdx,%rax), %rax
    a5e8:      	movq	%rax, 0x28(%rsp)
    a5ed:      	testq	%rax, %rax
    a5f0:      	je	0xa9b7 <generic_fentry_actions+0x817>
    a5f6:      	movq	%rdx, 0x8(%rsp)
    a5fb:      	cmpl	$0xa, %r13d
    a5ff:      	jne	0xa9c4 <generic_fentry_actions+0x824>
    a605:      	movl	$0xe, %eax
    a60a:      	callq	*%rax
    a60c:      	movq	%rax, 0x38(%rsp)
    a611:      	shrq	$0x20, %rax
    a615:      	movl	%eax, 0x18(%rsp)
    a619:      	movl	$0x1, %eax
    a61e:      	leaq	0x18(%rsp), %rsi
    a623:      	movq	(%rip), %rdi            # 0xa62a <generic_fentry_actions+0x48a>
    a62a:      	callq	*%rax
    a62c:      	xorl	%ecx, %ecx
    a62e:      	testq	%rax, %rax
    a631:      	movq	0x8(%rsp), %rdx
    a636:      	je	0xa9b7 <generic_fentry_actions+0x817>
    a63c:      	movl	(%rax), %ecx
    a63e:      	movl	%ecx, 0x18(%rsp)
    a642:      	movq	0x38(%rsp), %rcx
    a647:      	movl	%ecx, 0x1c(%rsp)
    a64b:      	movq	0x8(%rax), %rax
    a64f:      	movq	%rax, 0x20(%rsp)
    a654:      	xorl	%ecx, %ecx
    a656:      	movl	$0x2, %eax
    a65b:      	leaq	0x28(%rsp), %rsi
    a660:      	leaq	0x18(%rsp), %rdx
    a665:      	movq	(%rip), %rdi            # 0xa66c <generic_fentry_actions+0x4cc>
    a66c:      	jmp	0xa910 <generic_fentry_actions+0x770>
    a671:      	movl	$0x0, 0x44(%rsp)
    a679:      	jmp	0xa2d0 <generic_fentry_actions+0x130>
    a67e:      	movq	%r13, 0x8(%rsp)
    a683:      	movq	%rbp, %r13
    a686:      	movq	%rdx, %rbp
    a689:      	incl	%r15d
    a68c:      	movq	0x78(%rsp), %rbx
    a691:      	jmp	0xa818 <generic_fentry_actions+0x678>
    a696:      	movq	%rdx, 0x8(%rsp)
    a69b:      	movl	$0xe, %eax
    a6a0:      	callq	*%rax
    a6a2:      	movq	%rax, 0x50(%rsp)
    a6a7:      	movl	$0x1, %eax
    a6ac:      	leaq	0x50(%rsp), %rsi
    a6b1:      	movq	(%rip), %rdi            # 0xa6b8 <generic_fentry_actions+0x518>
    a6b8:      	callq	*%rax
    a6ba:      	testq	%rax, %rax
    a6bd:      	je	0xa70d <generic_fentry_actions+0x56d>
    a6bf:      	movq	0x4(%rax), %rax
    a6c3:      	movq	%rax, 0x28(%rsp)
    a6c8:      	movl	$0x2, 0x30(%rsp)
    a6d0:      	movl	$0x1, %eax
    a6d5:      	leaq	0x28(%rsp), %rsi
    a6da:      	movq	(%rip), %rbx            # 0xa6e1 <generic_fentry_actions+0x541>
    a6e1:      	movq	%rbx, %rdi
    a6e4:      	callq	*%rax
    a6e6:      	movl	$0x1, 0x5c(%rsp)
    a6ee:      	testq	%rax, %rax
    a6f1:      	je	0xa928 <generic_fentry_actions+0x788>
    a6f7:      	lock
    a6f8:      	incl	(%rax)
    a6fa:      	movl	$0x3, %eax
    a6ff:      	leaq	0x50(%rsp), %rsi
    a704:      	movq	(%rip), %rdi            # 0xa70b <generic_fentry_actions+0x56b>
    a70b:      	callq	*%rax
    a70d:      	movq	0x8(%rsp), %rdx
    a712:      	jmp	0xa2d0 <generic_fentry_actions+0x130>
    a717:      	movq	%rdx, 0x8(%rsp)
    a71c:      	leal	0x1(%r15), %eax
    a720:      	movl	0x4(%r14,%rax,4), %ebx
    a725:      	leal	0x2(%r15), %eax
    a729:      	movl	0x4(%r14,%rax,4), %eax
    a72e:      	movl	%eax, 0x60(%rsp)
    a732:      	movl	$0x7d, %eax
    a737:      	callq	*%rax
    a739:      	movq	%rax, 0x18(%rsp)
    a73e:      	movl	$0x0, 0x50(%rsp)
    a746:      	movq	%rbx, 0xa0(%rsp)
    a74e:      	testq	%rbx, %rbx
    a751:      	je	0xabc8 <generic_fentry_actions+0xa28>
    a757:      	movl	$0x1, %eax
    a75c:      	movq	(%rip), %rdi            # 0xa763 <generic_fentry_actions+0x5c3>
    a763:      	leaq	0x50(%rsp), %rsi
    a768:      	callq	*%rax
    a76a:      	testq	%rax, %rax
    a76d:      	je	0xabc8 <generic_fentry_actions+0xa28>
    a773:      	movq	%rax, 0x48(%rsp)
    a778:      	movq	%rax, %rbx
    a77b:      	movl	$0x1, %eax
    a780:      	leaq	0x50(%rsp), %rsi
    a785:      	movq	(%rip), %rdi            # 0xa78c <generic_fentry_actions+0x5ec>
    a78c:      	callq	*%rax
    a78e:      	movq	%rax, %rdx
    a791:      	movq	0x8(%rsp), %rcx
    a796:      	movq	0x60(%rcx), %rax
    a79a:      	movq	%rax, (%rbx)
    a79d:      	movq	0x70(%rcx), %rax
    a7a1:      	movq	%rax, 0x8(%rbx)
    a7a5:      	xorl	%eax, %eax
    a7a7:      	movq	%rax, 0x38(%rsp)
    a7ac:      	movl	$0x0, %eax
    a7b1:      	movl	0x60(%rsp), %esi
    a7b5:      	cmpl	$0x2, %esi
    a7b8:      	je	0xa9ef <generic_fentry_actions+0x84f>
    a7be:      	cmpl	$0x1, %esi
    a7c1:      	je	0xa9ec <generic_fentry_actions+0x84c>
    a7c7:      	testl	%esi, %esi
    a7c9:      	jne	0xabc8 <generic_fentry_actions+0xa28>
    a7cf:      	movq	0x8(%rsp), %rax
    a7d4:      	movl	0x7c(%rax), %eax
    a7d7:      	jmp	0xa9ef <generic_fentry_actions+0x84f>
    a7dc:      	movq	%r13, 0x8(%rsp)
    a7e1:      	movq	%rbp, %r13
    a7e4:      	movq	%rdx, %rbp
    a7e7:      	movl	$0x3, %ebx
    a7ec:      	cmpb	$0x0, 0x17(%rsp)
    a7f1:      	je	0xa818 <generic_fentry_actions+0x678>
    a7f3:      	movslq	%eax, %rdi
    a7f6:      	movl	$0x6d, %eax
    a7fb:      	callq	*%rax
    a7fd:      	movl	$0x2, %ebx
    a802:      	jmp	0xa818 <generic_fentry_actions+0x678>
    a804:      	movq	%r13, 0x8(%rsp)
    a809:      	movq	%rbp, %r13
    a80c:      	movq	%rdx, %rbp
    a80f:      	addl	$0x3, %r15d
    a813:      	movq	0x68(%rsp), %rbx
    a818:      	movl	$0x0, 0x18(%rsp)
    a820:      	movl	$0x1, %eax
    a825:      	leaq	0x18(%rsp), %rsi
    a82a:      	movq	(%rip), %rdi            # 0xa831 <generic_fentry_actions+0x691>
    a831:      	callq	*%rax
    a833:      	testq	%rax, %rax
    a836:      	je	0xa83d <generic_fentry_actions+0x69d>
    a838:      	lock
    a839:      	incq	(%rax,%rbx,8)
    a83d:      	movq	%rbp, %rdx
    a840:      	movq	%r13, %rbp
    a843:      	movq	0x8(%rsp), %r13
    a848:      	jmp	0xa2d0 <generic_fentry_actions+0x130>
    a84d:      	movq	%rax, 0x48(%rsp)
    a852:      	movq	0x5e78(%rdx,%r14,8), %rax
    a85a:      	movl	$0x0, 0x24(%rsp)
    a862:      	andl	$0x7ff, %eax            # imm = 0x7FF
    a867:      	movl	0x90(%rdx,%rax), %eax
    a86e:      	movl	%eax, 0x20(%rsp)
    a872:      	movl	$0xe, %eax
    a877:      	callq	*%rax
    a879:      	shrq	$0x20, %rax
    a87d:      	movq	%rax, 0x18(%rsp)
    a882:      	cmpl	$0x1, %r13d
    a886:      	jne	0xa992 <generic_fentry_actions+0x7f2>
    a88c:      	movq	0x38(%rsp), %rax
    a891:      	andl	$0x7, %eax
    a894:      	cmpl	$0x4, %eax
    a897:      	movq	%rbp, %r14
    a89a:      	movl	$0x0, %ecx
    a89f:      	ja	0xa9ab <generic_fentry_actions+0x80b>
    a8a5:      	movq	0x8(%rsp), %rdx
    a8aa:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    a8b2:      	movq	(%rip), %rbp            # 0xa8b9 <generic_fentry_actions+0x719>
    a8b9:      	jne	0xa9b7 <generic_fentry_actions+0x817>
    a8bf:      	movq	0x5e78(%rdx,%rax,8), %rax
    a8c7:      	andl	$0x7ff, %eax            # imm = 0x7FF
    a8cc:      	addq	%rax, %rdx
    a8cf:      	addq	$0x90, %rdx
    a8d6:      	movq	0x8(%rsp), %rcx
    a8db:      	movl	0x90(%rcx,%rax), %esi
    a8e2:      	andl	$0xfff, %esi            # imm = 0xFFF
    a8e8:      	addq	$0x8, %rsi
    a8ec:      	movl	$0x4, %eax
    a8f1:      	movq	0x48(%rsp), %rdi
    a8f6:      	callq	*%rax
    a8f8:      	xorl	%ecx, %ecx
    a8fa:      	movl	$0x2, %eax
    a8ff:      	leaq	0x18(%rsp), %rsi
    a904:      	movq	(%rip), %rdi            # 0xa90b <generic_fentry_actions+0x76b>
    a90b:      	movq	0x48(%rsp), %rdx
    a910:      	xorl	%ecx, %ecx
    a912:      	callq	*%rax
    a914:      	xorl	%ecx, %ecx
    a916:      	movq	0x8(%rsp), %rdx
    a91b:      	testl	%ecx, %ecx
    a91d:      	jne	0xa2da <generic_fentry_actions+0x13a>
    a923:      	jmp	0xa2d0 <generic_fentry_actions+0x130>
    a928:      	movl	$0x2, %eax
    a92d:      	movl	$0x1, %ecx
    a932:      	leaq	0x5c(%rsp), %rdx
    a937:      	leaq	0x28(%rsp), %rsi
    a93c:      	movq	%rbx, %rdi
    a93f:      	callq	*%rax
    a941:      	testq	%rax, %rax
    a944:      	je	0xa6fa <generic_fentry_actions+0x55a>
    a94a:      	movq	%rax, 0x38(%rsp)
    a94f:      	negl	%eax
    a951:      	movw	%ax, 0x18(%rsp)
    a956:      	movw	$0x3, 0x1a(%rsp)
    a95d:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    a967:      	movq	%rax, 0x1c(%rsp)
    a96c:      	movl	$0x1, %eax
    a971:      	leaq	0x18(%rsp), %rsi
    a976:      	movq	(%rip), %rbx            # 0xa97d <generic_fentry_actions+0x7dd>
    a97d:      	movq	%rbx, %rdi
    a980:      	callq	*%rax
    a982:      	testq	%rax, %rax
    a985:      	je	0xac58 <generic_fentry_actions+0xab8>
    a98b:      	incl	(%rax)
    a98d:      	jmp	0xac7e <generic_fentry_actions+0xade>
    a992:      	movl	$0x3, %eax
    a997:      	leaq	0x18(%rsp), %rsi
    a99c:      	movq	(%rip), %rdi            # 0xa9a3 <generic_fentry_actions+0x803>
    a9a3:      	callq	*%rax
    a9a5:      	movq	%rax, %rcx
    a9a8:      	movq	%rbp, %r14
    a9ab:      	movq	(%rip), %rbp            # 0xa9b2 <generic_fentry_actions+0x812>
    a9b2:      	movq	0x8(%rsp), %rdx
    a9b7:      	testl	%ecx, %ecx
    a9b9:      	jne	0xa2da <generic_fentry_actions+0x13a>
    a9bf:      	jmp	0xa2d0 <generic_fentry_actions+0x130>
    a9c4:      	movl	$0x3, %eax
    a9c9:      	leaq	0x28(%rsp), %rsi
    a9ce:      	movq	(%rip), %rdi            # 0xa9d5 <generic_fentry_actions+0x835>
    a9d5:      	callq	*%rax
    a9d7:      	movq	%rax, %rcx
    a9da:      	movq	0x8(%rsp), %rdx
    a9df:      	testl	%ecx, %ecx
    a9e1:      	jne	0xa2da <generic_fentry_actions+0x13a>
    a9e7:      	jmp	0xa2d0 <generic_fentry_actions+0x130>
    a9ec:      	movl	0x10(%rcx), %eax
    a9ef:      	movq	%r14, 0x60(%rsp)
    a9f4:      	movl	%eax, %eax
    a9f6:      	movq	%rbx, 0x98(%rsp)
    a9fe:      	movq	%rax, 0x10(%rbx)
    aa02:      	movq	0x48(%rsp), %rdi
    aa07:      	addq	$0x18, %rdi
    aa0b:      	movl	$0x4, %eax
    aa10:      	movl	$0xc8, %ecx
    aa15:      	movq	%rdi, 0x48(%rsp)
    aa1a:      	movl	$0xc8, %esi
    aa1f:      	callq	*%rax
    aa21:      	xorl	%r14d, %r14d
    aa24:      	leaq	0x28(%rsp), %rbx
    aa29:      	jmp	0xaa43 <generic_fentry_actions+0x8a3>
    aa2b:      	nopl	(%rax,%rax)
    aa30:      	leaq	0x28(%rsp), %rbx
    aa35:      	addq	$0x4, %r14
    aa39:      	cmpq	$0x14, %r14
    aa3d:      	je	0xab6b <generic_fentry_actions+0x9cb>
    aa43:      	movl	$0x0, 0x28(%rsp)
    aa4b:      	movl	$0x1, %eax
    aa50:      	movq	%rbp, %rdi
    aa53:      	movq	%rbx, %rsi
    aa56:      	callq	*%rax
    aa58:      	testq	%rax, %rax
    aa5b:      	je	0xab6b <generic_fentry_actions+0x9cb>
    aa61:      	movq	%rax, %rsi
    aa64:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    aa6b:      	movl	$0x1, %eax
    aa70:      	movq	(%rip), %rdi            # 0xaa77 <generic_fentry_actions+0x8d7>
    aa77:      	callq	*%rax
    aa79:      	testq	%rax, %rax
    aa7c:      	je	0xab6b <generic_fentry_actions+0x9cb>
    aa82:      	cmpl	$-0x1, 0x40(%rax,%r14)
    aa88:      	movq	0x8(%rsp), %rdx
    aa8d:      	je	0xab6b <generic_fentry_actions+0x9cb>
    aa93:      	movq	0x5e78(%rdx,%r14,2), %rax
    aa9b:      	movl	0x4(%rdx), %ecx
    aa9e:      	cmpq	%rcx, %rax
    aaa1:      	jge	0xab6b <generic_fentry_actions+0x9cb>
    aaa7:      	cmpq	$0x10, %r14
    aaab:      	je	0xab12 <generic_fentry_actions+0x972>
    aaad:      	movl	$0x0, 0x28(%rsp)
    aab5:      	movl	$0x1, %eax
    aaba:      	movq	%rbp, %rdi
    aabd:      	movq	%rbx, %rsi
    aac0:      	callq	*%rax
    aac2:      	testq	%rax, %rax
    aac5:      	je	0xab05 <generic_fentry_actions+0x965>
    aac7:      	movq	%rax, %rsi
    aaca:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    aad1:      	movl	$0x1, %eax
    aad6:      	movq	(%rip), %rdi            # 0xaadd <generic_fentry_actions+0x93d>
    aadd:      	callq	*%rax
    aadf:      	testq	%rax, %rax
    aae2:      	je	0xab05 <generic_fentry_actions+0x965>
    aae4:      	cmpl	$-0x1, 0x44(%rax,%r14)
    aaea:      	movq	0x8(%rsp), %rdx
    aaef:      	movq	0x5e78(%rdx,%r14,2), %rax
    aaf7:      	je	0xab12 <generic_fentry_actions+0x972>
    aaf9:      	movl	0x5e80(%rdx,%r14,2), %ebx
    ab01:      	subl	%eax, %ebx
    ab03:      	jmp	0xab1a <generic_fentry_actions+0x97a>
    ab05:      	movq	0x8(%rsp), %rdx
    ab0a:      	movq	0x5e78(%rdx,%r14,2), %rax
    ab12:      	movl	0x4(%rdx), %ebx
    ab15:      	subl	%eax, %ebx
    ab17:      	addl	$0x4, %ebx
    ab1a:      	testl	%ebx, %ebx
    ab1c:      	jle	0xaa30 <generic_fentry_actions+0x890>
    ab22:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    ab27:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    ab2c:      	cmpl	$0x28, %ebx
    ab2f:      	movl	$0x28, %ecx
    ab34:      	cmovgel	%ecx, %ebx
    ab37:      	movzbl	0x38(%rsp), %ebp
    ab3c:      	movq	0x48(%rsp), %rcx
    ab41:      	leaq	(%rcx,%rbp), %rdi
    ab45:      	addq	%rax, %rdx
    ab48:      	addq	$0x90, %rdx
    ab4f:      	movl	$0x4, %eax
    ab54:      	movl	%ebx, %esi
    ab56:      	callq	*%rax
    ab58:      	addl	%ebp, %ebx
    ab5a:      	movq	(%rip), %rbp            # 0xab61 <generic_fentry_actions+0x9c1>
    ab61:      	movq	%rbx, 0x38(%rsp)
    ab66:      	jmp	0xaa30 <generic_fentry_actions+0x890>
    ab6b:      	movl	$0x1, %eax
    ab70:      	movq	(%rip), %rdi            # 0xab77 <generic_fentry_actions+0x9d7>
    ab77:      	movq	0x98(%rsp), %rbx
    ab7f:      	movq	%rbx, %rsi
    ab82:      	callq	*%rax
    ab84:      	testq	%rax, %rax
    ab87:      	movq	0x60(%rsp), %r14
    ab8c:      	je	0xabae <generic_fentry_actions+0xa0e>
    ab8e:      	imulq	$-0xf4240, 0xa0(%rsp), %rcx # imm = 0xFFF0BDC0
    ab9a:      	addq	0x18(%rsp), %rcx
    ab9f:      	cmpq	%rcx, (%rax)
    aba2:      	jbe	0xabae <generic_fentry_actions+0xa0e>
    aba4:      	movl	$0x0, 0x44(%rsp)
    abac:      	jmp	0xabc8 <generic_fentry_actions+0xa28>
    abae:      	movl	$0x2, %eax
    abb3:      	xorl	%ecx, %ecx
    abb5:      	movq	(%rip), %rdi            # 0xabbc <generic_fentry_actions+0xa1c>
    abbc:      	leaq	0x18(%rsp), %rdx
    abc1:      	movq	%rbx, %rsi
    abc4:      	xorl	%ecx, %ecx
    abc6:      	callq	*%rax
    abc8:      	leal	0x3(%r15), %eax
    abcc:      	cmpl	$0x0, 0x4(%r14,%rax,4)
    abd2:      	movq	0x8(%rsp), %rdx
    abd7:      	je	0xac03 <generic_fentry_actions+0xa63>
    abd9:      	orb	$0x2, 0x1(%rdx)
    abdd:      	movl	$0x1b, %eax
    abe2:      	movq	0x80(%rsp), %rdi
    abea:      	xorl	%ecx, %ecx
    abec:      	movq	(%rip), %rsi            # 0xabf3 <generic_fentry_actions+0xa53>
    abf3:      	xorl	%edx, %edx
    abf5:      	callq	*%rax
    abf7:      	movq	0x8(%rsp), %rdx
    abfc:      	movq	%rax, 0x80(%rdx)
    ac03:      	leal	0x4(%r15), %eax
    ac07:      	cmpl	$0x0, 0x4(%r14,%rax,4)
    ac0d:      	je	0xac3f <generic_fentry_actions+0xa9f>
    ac0f:      	orb	$0x4, 0x1(%rdx)
    ac13:      	movl	$0x1b, %eax
    ac18:      	movq	0x80(%rsp), %rdi
    ac20:      	movq	(%rip), %rsi            # 0xac27 <generic_fentry_actions+0xa87>
    ac27:      	movl	$0x100, %ecx            # imm = 0x100
    ac2c:      	movl	$0x100, %edx            # imm = 0x100
    ac31:      	callq	*%rax
    ac33:      	movq	0x8(%rsp), %rdx
    ac38:      	movq	%rax, 0x88(%rdx)
    ac3f:      	addl	$0x5, %r15d
    ac43:      	cmpl	$0x0, 0x4(%r14,%r15,4)
    ac49:      	je	0xa2d0 <generic_fentry_actions+0x130>
    ac4f:      	orb	$0x8, 0x1(%rdx)
    ac53:      	jmp	0xa2d0 <generic_fentry_actions+0x130>
    ac58:      	movl	$0x1, 0x94(%rsp)
    ac63:      	movl	$0x2, %eax
    ac68:      	xorl	%ecx, %ecx
    ac6a:      	leaq	0x94(%rsp), %rdx
    ac72:      	leaq	0x18(%rsp), %rsi
    ac77:      	movq	%rbx, %rdi
    ac7a:      	xorl	%ecx, %ecx
    ac7c:      	callq	*%rax
    ac7e:      	cmpl	$0x0, 0x38(%rsp)
    ac83:      	je	0xa6fa <generic_fentry_actions+0x55a>
    ac89:      	movl	$0x1, %eax
    ac8e:      	leaq	0x28(%rsp), %rsi
    ac93:      	movq	(%rip), %rdi            # 0xac9a <generic_fentry_actions+0xafa>
    ac9a:      	callq	*%rax
    ac9c:      	testq	%rax, %rax
    ac9f:      	je	0xa6fa <generic_fentry_actions+0x55a>
    aca5:      	movl	0x5c(%rsp), %ecx
    aca9:      	lock
    acaa:      	addl	%ecx, (%rax)
    acac:      	jmp	0xa6fa <generic_fentry_actions+0x55a>
    acb1:      	cmpb	$0x0, 0x44(%rsp)
    acb6:      	je	0xacd8 <generic_fentry_actions+0xb38>
    acb8:      	movq	(%rip), %rsi            # 0xacbf <generic_fentry_actions+0xb1f>
    acbf:      	movl	$0x5, %ecx
    acc4:      	movl	$0xc, %eax
    acc9:      	movq	0x80(%rsp), %rdi
    acd1:      	movl	$0x5, %edx
    acd6:      	callq	*%rax
    acd8:      	xorl	%eax, %eax
    acda:      	addq	$0xa8, %rsp
    ace1:      	popq	%rbx
    ace2:      	popq	%r12
    ace4:      	popq	%r13
    ace6:      	popq	%r14
    ace8:      	popq	%r15
    acea:      	popq	%rbp
    aceb:      	retq
    acec:      	nopl	(%rax)

000000000000acf0 <generic_fentry_output>:
    acf0:      	pushq	%rbp
    acf1:      	pushq	%r15
    acf3:      	pushq	%r14
    acf5:      	pushq	%r13
    acf7:      	pushq	%r12
    acf9:      	pushq	%rbx
    acfa:      	subq	$0x78, %rsp
    acfe:      	movq	%rdi, %r14
    ad01:      	movl	$0x0, 0x24(%rsp)
    ad09:      	movq	(%rip), %rdi            # 0xad10 <generic_fentry_output+0x20>
    ad10:      	leaq	0x24(%rsp), %rsi
    ad15:      	movl	$0x1, %eax
    ad1a:      	callq	*%rax
    ad1c:      	testq	%rax, %rax
    ad1f:      	je	0xb1c9 <generic_fentry_output+0x4d9>
    ad25:      	movq	%rax, %rbx
    ad28:      	cmpq	$0x0, 0x5ee8(%rax)
    ad30:      	je	0xb038 <generic_fentry_output+0x348>
    ad36:      	movl	$0xe, %eax
    ad3b:      	callq	*%rax
    ad3d:      	movq	%rax, %r15
    ad40:      	shrq	$0x20, %r15
    ad44:      	movl	$0x23, %eax
    ad49:      	callq	*%rax
    ad4b:      	movq	%rax, %r12
    ad4e:      	movl	%r15d, 0x28(%rsp)
    ad53:      	movq	(%rip), %rdi            # 0xad5a <generic_fentry_output+0x6a>
    ad5a:      	leaq	0x28(%rsp), %rsi
    ad5f:      	movl	$0x1, %eax
    ad64:      	callq	*%rax
    ad66:      	testq	%rax, %rax
    ad69:      	je	0xb038 <generic_fentry_output+0x348>
    ad6f:      	movq	%rax, %r15
    ad72:      	leaq	0xd70(%r12), %rdx
    ad7a:      	leaq	0x70(%rsp), %rdi
    ad7f:      	movl	$0x8, %ecx
    ad84:      	movl	$0x4, %eax
    ad89:      	leaq	0x28(%r15), %r13
    ad8d:      	movl	$0x4, %ebp
    ad92:      	movl	$0x8, %esi
    ad97:      	callq	*%rax
    ad99:      	movq	0x70(%rsp), %rcx
    ad9e:      	leaq	0x28(%rsp), %rdi
    ada3:      	movl	$0x48, %edx
    ada8:      	movl	$0x4, %eax
    adad:      	movq	0x70(%rsp), %rdx
    adb2:      	movl	$0x48, %esi
    adb7:      	callq	*%rax
    adb9:      	movl	$0x218, %edx            # imm = 0x218
    adbe:      	movq	0x30(%rsp), %rcx
    adc3:      	addq	%rdx, %rcx
    adc6:      	movl	$0x4, %esi
    adcb:      	movl	$0x4, %eax
    add0:      	addq	0x30(%rsp), %rdx
    add5:      	movq	%r13, %rdi
    add8:      	movl	$0x4, %esi
    addd:      	callq	*%rax
    addf:      	leaq	0x2c(%r15), %rdi
    ade3:      	movl	$0x4d8, %edx            # imm = 0x4D8
    ade8:      	movq	0x38(%rsp), %rcx
    aded:      	addq	%rdx, %rcx
    adf0:      	movl	$0x4, %esi
    adf5:      	movl	$0x4, %eax
    adfa:      	addq	0x38(%rsp), %rdx
    adff:      	movl	$0x4, %esi
    ae04:      	callq	*%rax
    ae06:      	leaq	0x30(%r15), %rdi
    ae0a:      	movq	0x40(%rsp), %rcx
    ae0f:      	addq	$0x58, %rcx
    ae13:      	movl	$0x4, %edx
    ae18:      	movl	$0x4, %eax
    ae1d:      	movq	0x40(%rsp), %rdx
    ae22:      	addq	$0x58, %rdx
    ae26:      	movl	$0x4, %esi
    ae2b:      	callq	*%rax
    ae2d:      	movq	$0x0, (%rsp)
    ae35:      	leaq	0xb58(%r12), %rdx
    ae3d:      	movq	%rsp, %rdi
    ae40:      	movl	$0x8, %ecx
    ae45:      	movl	$0x4, %eax
    ae4a:      	movl	$0x8, %esi
    ae4f:      	callq	*%rax
    ae51:      	movq	(%rsp), %rcx
    ae55:      	testq	%rcx, %rcx
    ae58:      	je	0xaeeb <generic_fentry_output+0x1fb>
    ae5e:      	movl	$0x0, 0xc(%rsp)
    ae66:      	addq	$0x4, %rcx
    ae6a:      	leaq	0xc(%rsp), %rdi
    ae6f:      	movl	$0x4, %eax
    ae74:      	movq	(%rsp), %rdx
    ae78:      	addq	$0x4, %rdx
    ae7c:      	movl	$0x4, %esi
    ae81:      	callq	*%rax
    ae83:      	movq	(%rsp), %rax
    ae87:      	movslq	0xc(%rsp), %rcx
    ae8c:      	shlq	$0x4, %rcx
    ae90:      	addq	%rax, %rcx
    ae93:      	addq	$0x80, %rcx
    ae9a:      	leaq	0x10(%rsp), %rdi
    ae9f:      	movl	$0x10, %edx
    aea4:      	movl	$0x4, %eax
    aea9:      	movq	(%rsp), %rcx
    aead:      	movslq	0xc(%rsp), %rdx
    aeb2:      	shlq	$0x4, %rdx
    aeb6:      	addq	%rcx, %rdx
    aeb9:      	addq	$0x80, %rdx
    aec0:      	movl	$0x10, %esi
    aec5:      	callq	*%rax
    aec7:      	leaq	0x34(%r15), %rdi
    aecb:      	movl	$0x158, %edx            # imm = 0x158
    aed0:      	movq	0x18(%rsp), %rcx
    aed5:      	addq	%rdx, %rcx
    aed8:      	movl	$0x4, %eax
    aedd:      	addq	0x18(%rsp), %rdx
    aee2:      	movl	$0x4, %esi
    aee7:      	callq	*%rax
    aee9:      	jmp	0xaef3 <generic_fentry_output+0x203>
    aeeb:      	movl	$0x0, 0x34(%r15)
    aef3:      	leaq	0x38(%r15), %rdi
    aef7:      	movl	$0x158, %r13d           # imm = 0x158
    aefd:      	movq	0x48(%rsp), %rcx
    af02:      	addq	%r13, %rcx
    af05:      	movl	$0x4, %edx
    af0a:      	movl	$0x4, %eax
    af0f:      	movq	0x48(%rsp), %rdx
    af14:      	addq	%r13, %rdx
    af17:      	movl	$0x4, %esi
    af1c:      	callq	*%rax
    af1e:      	leaq	0x3c(%r15), %rdi
    af22:      	movl	$0x118, %edx            # imm = 0x118
    af27:      	movq	0x50(%rsp), %rcx
    af2c:      	addq	%rdx, %rcx
    af2f:      	movl	$0x4, %esi
    af34:      	movl	$0x4, %eax
    af39:      	addq	0x50(%rsp), %rdx
    af3e:      	movl	$0x4, %esi
    af43:      	callq	*%rax
    af45:      	leaq	0x40(%r15), %rdi
    af49:      	movl	$0x98, %ebp
    af4e:      	movq	0x58(%rsp), %rcx
    af53:      	addq	%rbp, %rcx
    af56:      	movl	$0x4, %edx
    af5b:      	movl	$0x4, %eax
    af60:      	movq	0x58(%rsp), %rdx
    af65:      	addq	%rbp, %rdx
    af68:      	movl	$0x4, %esi
    af6d:      	callq	*%rax
    af6f:      	leaq	0x44(%r15), %rdi
    af73:      	movq	0x60(%rsp), %rcx
    af78:      	addq	%rbp, %rcx
    af7b:      	movl	$0x4, %edx
    af80:      	movl	$0x4, %eax
    af85:      	addq	0x60(%rsp), %rbp
    af8a:      	movl	$0x4, %esi
    af8f:      	movq	%rbp, %rdx
    af92:      	callq	*%rax
    af94:      	leaq	0x48(%r15), %rdi
    af98:      	movq	0x68(%rsp), %rcx
    af9d:      	addq	$0x58, %rcx
    afa1:      	movl	$0x4, %edx
    afa6:      	movl	$0x4, %eax
    afab:      	movq	0x68(%rsp), %rdx
    afb0:      	addq	$0x58, %rdx
    afb4:      	movl	$0x4, %esi
    afb9:      	callq	*%rax
    afbb:      	movq	$0x0, 0x10(%rsp)
    afc4:      	movq	$0x0, (%rsp)
    afcc:      	addq	$0xd00, %r12            # imm = 0xD00
    afd3:      	leaq	0x10(%rsp), %rdi
    afd8:      	movl	$0x8, %ecx
    afdd:      	movl	$0x4, %eax
    afe2:      	movl	$0x8, %esi
    afe7:      	movq	%r12, %rdx
    afea:      	callq	*%rax
    afec:      	movl	$0x90, %edx
    aff1:      	movq	0x10(%rsp), %rcx
    aff6:      	addq	%rdx, %rcx
    aff9:      	movq	%rsp, %rdi
    affc:      	movl	$0x8, %esi
    b001:      	movl	$0x4, %eax
    b006:      	addq	0x10(%rsp), %rdx
    b00b:      	movl	$0x8, %esi
    b010:      	callq	*%rax
    b012:      	addq	$0x4c, %r15
    b016:      	movq	(%rsp), %rcx
    b01a:      	addq	%r13, %rcx
    b01d:      	movl	$0x4, %edx
    b022:      	movl	$0x4, %eax
    b027:      	addq	(%rsp), %r13
    b02b:      	movq	%r15, %rdi
    b02e:      	movl	$0x4, %esi
    b033:      	movq	%r13, %rdx
    b036:      	callq	*%rax
    b038:      	cmpq	$0x0, 0x5ef0(%rbx)
    b040:      	je	0xb0f9 <generic_fentry_output+0x409>
    b046:      	movl	$0xe, %eax
    b04b:      	callq	*%rax
    b04d:      	movq	%rax, %r15
    b050:      	shrq	$0x20, %r15
    b054:      	movl	$0x23, %eax
    b059:      	callq	*%rax
    b05b:      	movq	%rax, %r12
    b05e:      	movl	%r15d, 0x28(%rsp)
    b063:      	movq	(%rip), %rdi            # 0xb06a <generic_fentry_output+0x37a>
    b06a:      	leaq	0x28(%rsp), %rsi
    b06f:      	movl	$0x1, %eax
    b074:      	callq	*%rax
    b076:      	testq	%rax, %rax
    b079:      	je	0xb0f9 <generic_fentry_output+0x409>
    b07b:      	leaq	0x50(%rax), %r15
    b07f:      	addq	$0xd00, %r12            # imm = 0xD00
    b086:      	leaq	0x28(%rsp), %rdi
    b08b:      	movl	$0x8, %ecx
    b090:      	movq	%rax, %r13
    b093:      	movl	$0x4, %eax
    b098:      	movl	$0x8, %esi
    b09d:      	movq	%r12, %rdx
    b0a0:      	callq	*%rax
    b0a2:      	movq	0x28(%rsp), %r12
    b0a7:      	leaq	0x58(%r13), %rdi
    b0ab:      	leaq	0x40(%r12), %rdx
    b0b0:      	movl	$0x8, %ecx
    b0b5:      	movl	$0x4, %eax
    b0ba:      	movl	$0x8, %esi
    b0bf:      	callq	*%rax
    b0c1:      	addq	$0x60, %r13
    b0c5:      	leaq	0x30(%r12), %rdx
    b0ca:      	movl	$0x8, %ecx
    b0cf:      	movl	$0x4, %eax
    b0d4:      	movq	%r13, %rdi
    b0d7:      	movl	$0x8, %esi
    b0dc:      	callq	*%rax
    b0de:      	addq	$0x38, %r12
    b0e2:      	movl	$0x8, %ecx
    b0e7:      	movl	$0x4, %eax
    b0ec:      	movq	%r15, %rdi
    b0ef:      	movl	$0x8, %esi
    b0f4:      	movq	%r12, %rdx
    b0f7:      	callq	*%rax
    b0f9:      	movl	$0x90, %eax
    b0fe:      	addl	0x4(%rbx), %eax
    b101:      	andl	$0x7fff, %eax           # imm = 0x7FFF
    b106:      	cmpl	$0x2328, %eax           # imm = 0x2328
    b10b:      	movl	$0x2328, %r15d          # imm = 0x2328
    b111:      	cmovbl	%eax, %r15d
    b115:      	movl	$0x0, 0x10(%rsp)
    b11d:      	movq	(%rip), %rdi            # 0xb124 <generic_fentry_output+0x434>
    b124:      	leaq	0x10(%rsp), %rsi
    b129:      	movl	$0x1, %eax
    b12e:      	callq	*%rax
    b130:      	testq	%rax, %rax
    b133:      	je	0xb187 <generic_fentry_output+0x497>
    b135:      	cmpb	$0x0, 0x28(%rax)
    b139:      	je	0xb187 <generic_fentry_output+0x497>
    b13b:      	movq	(%rip), %rsi            # 0xb142 <generic_fentry_output+0x452>
    b142:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    b147:      	movl	$0x19, %eax
    b14c:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    b151:      	movq	%r14, %rdi
    b154:      	movq	%rbx, %rcx
    b157:      	movq	%r15, %r8
    b15a:      	callq	*%rax
    b15c:      	testq	%rax, %rax
    b15f:      	js	0xb229 <generic_fentry_output+0x539>
    b165:      	movl	$0x0, 0x28(%rsp)
    b16d:      	movq	(%rip), %rdi            # 0xb174 <generic_fentry_output+0x484>
    b174:      	leaq	0x28(%rsp), %rsi
    b179:      	movl	$0x1, %eax
    b17e:      	callq	*%rax
    b180:      	testq	%rax, %rax
    b183:      	jne	0xb1c4 <generic_fentry_output+0x4d4>
    b185:      	jmp	0xb1c9 <generic_fentry_output+0x4d9>
    b187:      	movq	(%rip), %rdi            # 0xb18e <generic_fentry_output+0x49e>
    b18e:      	xorl	%ecx, %ecx
    b190:      	movl	$0x82, %eax
    b195:      	movq	%rbx, %rsi
    b198:      	movq	%r15, %rdx
    b19b:      	xorl	%ecx, %ecx
    b19d:      	callq	*%rax
    b19f:      	testq	%rax, %rax
    b1a2:      	js	0xb1da <generic_fentry_output+0x4ea>
    b1a4:      	movl	$0x0, 0x28(%rsp)
    b1ac:      	movq	(%rip), %rdi            # 0xb1b3 <generic_fentry_output+0x4c3>
    b1b3:      	leaq	0x28(%rsp), %rsi
    b1b8:      	movl	$0x1, %eax
    b1bd:      	callq	*%rax
    b1bf:      	testq	%rax, %rax
    b1c2:      	je	0xb1c9 <generic_fentry_output+0x4d9>
    b1c4:      	lock
    b1c5:      	incq	0x8(%rax)
    b1c9:      	xorl	%eax, %eax
    b1cb:      	addq	$0x78, %rsp
    b1cf:      	popq	%rbx
    b1d0:      	popq	%r12
    b1d2:      	popq	%r13
    b1d4:      	popq	%r14
    b1d6:      	popq	%r15
    b1d8:      	popq	%rbp
    b1d9:      	retq
    b1da:      	movq	%rax, %rbx
    b1dd:      	movl	$0x0, 0x28(%rsp)
    b1e5:      	movq	(%rip), %rdi            # 0xb1ec <generic_fentry_output+0x4fc>
    b1ec:      	leaq	0x28(%rsp), %rsi
    b1f1:      	movl	$0x1, %eax
    b1f6:      	callq	*%rax
    b1f8:      	testq	%rax, %rax
    b1fb:      	je	0xb1c9 <generic_fentry_output+0x4d9>
    b1fd:      	cmpq	$-0xc, %rbx
    b201:      	jg	0xb271 <generic_fentry_output+0x581>
    b203:      	cmpq	$-0x1c, %rbx
    b207:      	je	0xb2b3 <generic_fentry_output+0x5c3>
    b20d:      	cmpq	$-0x16, %rbx
    b211:      	je	0xb262 <generic_fentry_output+0x572>
    b213:      	cmpq	$-0x10, %rbx
    b217:      	jne	0xb2a4 <generic_fentry_output+0x5b4>
    b21d:      	addq	$0x2f0, %rax            # imm = 0x2F0
    b223:      	lock
    b224:      	incq	(%rax)
    b227:      	jmp	0xb1c9 <generic_fentry_output+0x4d9>
    b229:      	movq	%rax, %rbx
    b22c:      	movl	$0x0, 0x28(%rsp)
    b234:      	movq	(%rip), %rdi            # 0xb23b <generic_fentry_output+0x54b>
    b23b:      	leaq	0x28(%rsp), %rsi
    b240:      	movl	$0x1, %eax
    b245:      	callq	*%rax
    b247:      	testq	%rax, %rax
    b24a:      	je	0xb1c9 <generic_fentry_output+0x4d9>
    b250:      	cmpq	$-0xc, %rbx
    b254:      	jg	0xb292 <generic_fentry_output+0x5a2>
    b256:      	cmpq	$-0x1c, %rbx
    b25a:      	je	0xb2b3 <generic_fentry_output+0x5c3>
    b25c:      	cmpq	$-0x16, %rbx
    b260:      	jne	0xb213 <generic_fentry_output+0x523>
    b262:      	addq	$0x2f8, %rax            # imm = 0x2F8
    b268:      	lock
    b269:      	incq	(%rax)
    b26c:      	jmp	0xb1c9 <generic_fentry_output+0x4d9>
    b271:      	cmpq	$-0xb, %rbx
    b275:      	je	0xb2c2 <generic_fentry_output+0x5d2>
    b277:      	cmpq	$-0x7, %rbx
    b27b:      	je	0xb2d1 <generic_fentry_output+0x5e1>
    b27d:      	cmpq	$-0x2, %rbx
    b281:      	jne	0xb2a4 <generic_fentry_output+0x5b4>
    b283:      	addq	$0x2e0, %rax            # imm = 0x2E0
    b289:      	lock
    b28a:      	incq	(%rax)
    b28d:      	jmp	0xb1c9 <generic_fentry_output+0x4d9>
    b292:      	cmpq	$-0xb, %rbx
    b296:      	je	0xb2c2 <generic_fentry_output+0x5d2>
    b298:      	cmpq	$-0x7, %rbx
    b29c:      	je	0xb2d1 <generic_fentry_output+0x5e1>
    b29e:      	cmpq	$-0x2, %rbx
    b2a2:      	je	0xb283 <generic_fentry_output+0x593>
    b2a4:      	addq	$0x2d8, %rax            # imm = 0x2D8
    b2aa:      	lock
    b2ab:      	incq	(%rax)
    b2ae:      	jmp	0xb1c9 <generic_fentry_output+0x4d9>
    b2b3:      	addq	$0x300, %rax            # imm = 0x300
    b2b9:      	lock
    b2ba:      	incq	(%rax)
    b2bd:      	jmp	0xb1c9 <generic_fentry_output+0x4d9>
    b2c2:      	addq	$0x308, %rax            # imm = 0x308
    b2c8:      	lock
    b2c9:      	incq	(%rax)
    b2cc:      	jmp	0xb1c9 <generic_fentry_output+0x4d9>
    b2d1:      	addq	$0x2e8, %rax            # imm = 0x2E8
    b2d7:      	lock
    b2d8:      	incq	(%rax)
    b2db:      	jmp	0xb1c9 <generic_fentry_output+0x4d9>

000000000000b2e0 <generic_fentry_path>:
    b2e0:      	pushq	%rbp
    b2e1:      	pushq	%r15
    b2e3:      	pushq	%r14
    b2e5:      	pushq	%r13
    b2e7:      	pushq	%r12
    b2e9:      	pushq	%rbx
    b2ea:      	subq	$0x88, %rsp
    b2f1:      	movq	%rdi, %rbp
    b2f4:      	movl	$0x0, 0x70(%rsp)
    b2fc:      	movq	(%rip), %rdi            # 0xb303 <generic_fentry_path+0x23>
    b303:      	leaq	0x70(%rsp), %rsi
    b308:      	movl	$0x1, %eax
    b30d:      	callq	*%rax
    b30f:      	testq	%rax, %rax
    b312:      	je	0x17159 <generic_fentry_path+0xbe79>
    b318:      	movq	%rax, %r14
    b31b:      	movl	0x6420(%rax), %eax
    b321:      	cmpl	$0x1, %eax
    b324:      	je	0xb3c6 <generic_fentry_path+0xe6>
    b32a:      	testl	%eax, %eax
    b32c:      	jne	0x17159 <generic_fentry_path+0xbe79>
    b332:      	movq	0x6440(%r14), %r12
    b339:      	movl	$0x0, 0x10(%rsp)
    b341:      	movq	(%rip), %rdi            # 0xb348 <generic_fentry_path+0x68>
    b348:      	leaq	0x10(%rsp), %rsi
    b34d:      	movl	$0x1, %eax
    b352:      	callq	*%rax
    b354:      	testq	%rax, %rax
    b357:      	je	0x17159 <generic_fentry_path+0xbe79>
    b35d:      	movq	%rax, %r15
    b360:      	addq	$0x8, %r12
    b364:      	leaq	0x58(%rsp), %rdi
    b369:      	movl	$0x8, %ecx
    b36e:      	movl	$0x4, %eax
    b373:      	movl	$0x8, %esi
    b378:      	movq	%r12, %rdx
    b37b:      	callq	*%rax
    b37d:      	testq	%rax, %rax
    b380:      	je	0x16e09 <generic_fentry_path+0xbb29>
    b386:      	negl	%eax
    b388:      	movw	%ax, 0x18(%rsp)
    b38d:      	movw	$0x6, 0x1a(%rsp)
    b394:      	movabsq	$0x40000002c, %rax      # imm = 0x40000002C
    b39e:      	movq	%rax, 0x1c(%rsp)
    b3a3:      	movq	(%rip), %rdi            # 0xb3aa <generic_fentry_path+0xca>
    b3aa:      	leaq	0x18(%rsp), %rsi
    b3af:      	movl	$0x1, %eax
    b3b4:      	callq	*%rax
    b3b6:      	testq	%rax, %rax
    b3b9:      	je	0x16de8 <generic_fentry_path+0xbb08>
    b3bf:      	incl	(%rax)
    b3c1:      	jmp	0x16e09 <generic_fentry_path+0xbb29>
    b3c6:      	movq	0x6448(%r14), %rax
    b3cd:      	movq	%rax, 0x18(%rsp)
    b3d2:      	movq	0x6450(%r14), %rax
    b3d9:      	movq	%rax, 0x20(%rsp)
    b3de:      	movq	$0x0, 0x28(%rsp)
    b3e7:      	movq	0x6458(%r14), %rax
    b3ee:      	movq	%rax, 0x30(%rsp)
    b3f3:      	movq	0x6460(%r14), %rax
    b3fa:      	movq	%rax, 0x38(%rsp)
    b3ff:      	movq	0x6468(%r14), %rax
    b406:      	movq	%rax, 0x40(%rsp)
    b40b:      	movq	$0x0, 0x48(%rsp)
    b414:      	movl	$0x0, 0x50(%rsp)
    b41c:      	movb	$0x0, 0x54(%rsp)
    b421:      	movl	$0x0, 0x74(%rsp)
    b429:      	movq	(%rip), %rdi            # 0xb430 <generic_fentry_path+0x150>
    b430:      	leaq	0x74(%rsp), %rsi
    b435:      	movl	$0x1, %eax
    b43a:      	callq	*%rax
    b43c:      	testq	%rax, %rax
    b43f:      	je	0x17159 <generic_fentry_path+0xbe79>
    b445:      	movq	%rbp, 0x78(%rsp)
    b44a:      	movq	%rax, 0x28(%rsp)
    b44f:      	movl	0x6424(%r14), %edx
    b456:      	movl	%edx, %ecx
    b458:      	andl	$0xfff, %ecx            # imm = 0xFFF
    b45e:      	movq	%rax, %rsi
    b461:      	movq	%rax, 0x80(%rsp)
    b469:      	addq	%rax, %rcx
    b46c:      	movq	%rcx, 0x48(%rsp)
    b471:      	movl	%edx, 0x50(%rsp)
    b475:      	movl	$0x200, %eax            # imm = 0x200
    b47a:      	movl	$0x8, %r13d
    b480:      	movq	%rsp, %rbp
    b483:      	movl	%eax, 0x6c(%rsp)
    b487:      	movq	0x30(%rsp), %r12
    b48c:      	movq	0x38(%rsp), %rdx
    b491:      	movq	0x40(%rsp), %r15
    b496:      	cmpq	0x18(%rsp), %r12
    b49b:      	jne	0xb4a8 <generic_fentry_path+0x1c8>
    b49d:      	cmpq	0x20(%rsp), %rdx
    b4a2:      	je	0x16d4d <generic_fentry_path+0xba6d>
    b4a8:      	movl	$0x4, %eax
    b4ad:      	leaq	0x10(%rsp), %rdi
    b4b2:      	movl	$0x8, %esi
    b4b7:      	callq	*%rax
    b4b9:      	cmpq	0x10(%rsp), %r12
    b4be:      	je	0xb5bd <generic_fentry_path+0x2dd>
    b4c4:      	leaq	0x18(%r12), %rbx
    b4c9:      	movl	$0x4, %eax
    b4ce:      	movq	%rbp, %rdi
    b4d1:      	movl	$0x8, %esi
    b4d6:      	movq	%rbx, %rdx
    b4d9:      	callq	*%rax
    b4db:      	cmpq	%r12, (%rsp)
    b4df:      	je	0xb5bd <generic_fentry_path+0x2dd>
    b4e5:      	movl	$0x4, %eax
    b4ea:      	leaq	0x8(%rsp), %rdi
    b4ef:      	movl	$0x8, %esi
    b4f4:      	movq	%rbx, %rdx
    b4f7:      	callq	*%rax
    b4f9:      	addq	$0x20, %r12
    b4fd:      	movl	$0x4, %eax
    b502:      	leaq	0x58(%rsp), %rdi
    b507:      	movl	$0x10, %ecx
    b50c:      	movl	$0x10, %esi
    b511:      	movq	%r12, %rdx
    b514:      	callq	*%rax
    b516:      	movq	0x28(%rsp), %rbx
    b51b:      	movq	0x48(%rsp), %rax
    b520:      	movl	0x5c(%rsp), %r15d
    b525:      	subq	%rbx, %rax
    b528:      	movl	0x50(%rsp), %r12d
    b52d:      	movl	%r15d, %edx
    b530:      	subl	%r12d, %edx
    b533:      	movl	$0x0, %ecx
    b538:      	cmovbl	%ecx, %edx
    b53b:      	addq	0x60(%rsp), %rdx
    b540:      	xorl	%esi, %esi
    b542:      	cmpl	%r15d, %r12d
    b545:      	seta	%sil
    b549:      	movl	%r15d, %ecx
    b54c:      	cmovbl	%r12d, %ecx
    b550:      	addl	%ecx, %esi
    b552:      	movl	%r12d, %edi
    b555:      	subl	%esi, %edi
    b557:      	movl	%edi, 0x50(%rsp)
    b55b:      	subq	%rsi, %rax
    b55e:      	jb	0x16d52 <generic_fentry_path+0xba72>
    b564:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b56a:      	ja	0x16d52 <generic_fentry_path+0xba72>
    b570:      	cmpl	%r15d, %r12d
    b573:      	jbe	0xb579 <generic_fentry_path+0x299>
    b575:      	movb	$0x2f, (%rbx,%rax)
    b579:      	xorl	%edi, %edi
    b57b:      	cmpl	%r15d, %r12d
    b57e:      	seta	%dil
    b582:      	movzbl	%cl, %esi
    b585:      	addq	%rax, %rbx
    b588:      	addq	%rbx, %rdi
    b58b:      	movl	$0x4, %eax
    b590:      	callq	*%rax
    b592:      	movq	%rbx, 0x48(%rsp)
    b597:      	cmpl	%r15d, %r12d
    b59a:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    b5a0:      	movq	0x8(%rsp), %r12
    b5a5:      	movq	%r12, 0x30(%rsp)
    b5aa:      	movq	0x38(%rsp), %rdx
    b5af:      	movq	0x40(%rsp), %r15
    b5b4:      	cmpq	0x18(%rsp), %r12
    b5b9:      	je	0xb615 <generic_fentry_path+0x335>
    b5bb:      	jmp	0xb620 <generic_fentry_path+0x340>
    b5bd:      	leaq	0x10(%r15), %rdx
    b5c1:      	movl	$0x4, %eax
    b5c6:      	movq	%rbp, %rdi
    b5c9:      	movl	$0x8, %esi
    b5ce:      	callq	*%rax
    b5d0:      	movq	0x40(%rsp), %rax
    b5d5:      	cmpq	(%rsp), %rax
    b5d9:      	je	0x16d4d <generic_fentry_path+0xba6d>
    b5df:      	addq	$0x18, %r15
    b5e3:      	movl	$0x4, %eax
    b5e8:      	leaq	0x30(%rsp), %rdi
    b5ed:      	movl	$0x8, %esi
    b5f2:      	movq	%r15, %rdx
    b5f5:      	callq	*%rax
    b5f7:      	movq	(%rsp), %r15
    b5fb:      	movq	%r15, 0x40(%rsp)
    b600:      	leaq	0x20(%r15), %rdx
    b604:      	movq	%rdx, 0x38(%rsp)
    b609:      	movq	0x30(%rsp), %r12
    b60e:      	cmpq	0x18(%rsp), %r12
    b613:      	jne	0xb620 <generic_fentry_path+0x340>
    b615:      	cmpq	0x20(%rsp), %rdx
    b61a:      	je	0x16d4d <generic_fentry_path+0xba6d>
    b620:      	movl	$0x4, %eax
    b625:      	leaq	0x10(%rsp), %rdi
    b62a:      	movl	$0x8, %esi
    b62f:      	callq	*%rax
    b631:      	cmpq	0x10(%rsp), %r12
    b636:      	je	0xb735 <generic_fentry_path+0x455>
    b63c:      	leaq	0x18(%r12), %rbx
    b641:      	movl	$0x4, %eax
    b646:      	movq	%rbp, %rdi
    b649:      	movl	$0x8, %esi
    b64e:      	movq	%rbx, %rdx
    b651:      	callq	*%rax
    b653:      	cmpq	%r12, (%rsp)
    b657:      	je	0xb735 <generic_fentry_path+0x455>
    b65d:      	movl	$0x4, %eax
    b662:      	leaq	0x8(%rsp), %rdi
    b667:      	movl	$0x8, %esi
    b66c:      	movq	%rbx, %rdx
    b66f:      	callq	*%rax
    b671:      	addq	$0x20, %r12
    b675:      	movl	$0x4, %eax
    b67a:      	leaq	0x58(%rsp), %rdi
    b67f:      	movl	$0x10, %ecx
    b684:      	movl	$0x10, %esi
    b689:      	movq	%r12, %rdx
    b68c:      	callq	*%rax
    b68e:      	movq	0x28(%rsp), %rbx
    b693:      	movq	0x48(%rsp), %rax
    b698:      	movl	0x5c(%rsp), %r15d
    b69d:      	subq	%rbx, %rax
    b6a0:      	movl	0x50(%rsp), %r12d
    b6a5:      	movl	%r15d, %edx
    b6a8:      	subl	%r12d, %edx
    b6ab:      	movl	$0x0, %ecx
    b6b0:      	cmovbl	%ecx, %edx
    b6b3:      	addq	0x60(%rsp), %rdx
    b6b8:      	xorl	%esi, %esi
    b6ba:      	cmpl	%r15d, %r12d
    b6bd:      	seta	%sil
    b6c1:      	movl	%r15d, %ecx
    b6c4:      	cmovbl	%r12d, %ecx
    b6c8:      	addl	%ecx, %esi
    b6ca:      	movl	%r12d, %edi
    b6cd:      	subl	%esi, %edi
    b6cf:      	movl	%edi, 0x50(%rsp)
    b6d3:      	subq	%rsi, %rax
    b6d6:      	jb	0x16d52 <generic_fentry_path+0xba72>
    b6dc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b6e2:      	ja	0x16d52 <generic_fentry_path+0xba72>
    b6e8:      	cmpl	%r15d, %r12d
    b6eb:      	jbe	0xb6f1 <generic_fentry_path+0x411>
    b6ed:      	movb	$0x2f, (%rbx,%rax)
    b6f1:      	xorl	%edi, %edi
    b6f3:      	cmpl	%r15d, %r12d
    b6f6:      	seta	%dil
    b6fa:      	movzbl	%cl, %esi
    b6fd:      	addq	%rax, %rbx
    b700:      	addq	%rbx, %rdi
    b703:      	movl	$0x4, %eax
    b708:      	callq	*%rax
    b70a:      	movq	%rbx, 0x48(%rsp)
    b70f:      	cmpl	%r15d, %r12d
    b712:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    b718:      	movq	0x8(%rsp), %r12
    b71d:      	movq	%r12, 0x30(%rsp)
    b722:      	movq	0x38(%rsp), %rdx
    b727:      	movq	0x40(%rsp), %r15
    b72c:      	cmpq	0x18(%rsp), %r12
    b731:      	je	0xb78d <generic_fentry_path+0x4ad>
    b733:      	jmp	0xb798 <generic_fentry_path+0x4b8>
    b735:      	leaq	0x10(%r15), %rdx
    b739:      	movl	$0x4, %eax
    b73e:      	movq	%rbp, %rdi
    b741:      	movl	$0x8, %esi
    b746:      	callq	*%rax
    b748:      	movq	0x40(%rsp), %rax
    b74d:      	cmpq	(%rsp), %rax
    b751:      	je	0x16d4d <generic_fentry_path+0xba6d>
    b757:      	addq	$0x18, %r15
    b75b:      	movl	$0x4, %eax
    b760:      	leaq	0x30(%rsp), %rdi
    b765:      	movl	$0x8, %esi
    b76a:      	movq	%r15, %rdx
    b76d:      	callq	*%rax
    b76f:      	movq	(%rsp), %r15
    b773:      	movq	%r15, 0x40(%rsp)
    b778:      	leaq	0x20(%r15), %rdx
    b77c:      	movq	%rdx, 0x38(%rsp)
    b781:      	movq	0x30(%rsp), %r12
    b786:      	cmpq	0x18(%rsp), %r12
    b78b:      	jne	0xb798 <generic_fentry_path+0x4b8>
    b78d:      	cmpq	0x20(%rsp), %rdx
    b792:      	je	0x16d4d <generic_fentry_path+0xba6d>
    b798:      	movl	$0x4, %eax
    b79d:      	leaq	0x10(%rsp), %rdi
    b7a2:      	movl	$0x8, %esi
    b7a7:      	callq	*%rax
    b7a9:      	cmpq	0x10(%rsp), %r12
    b7ae:      	je	0xb8ad <generic_fentry_path+0x5cd>
    b7b4:      	leaq	0x18(%r12), %rbx
    b7b9:      	movl	$0x4, %eax
    b7be:      	movq	%rbp, %rdi
    b7c1:      	movl	$0x8, %esi
    b7c6:      	movq	%rbx, %rdx
    b7c9:      	callq	*%rax
    b7cb:      	cmpq	%r12, (%rsp)
    b7cf:      	je	0xb8ad <generic_fentry_path+0x5cd>
    b7d5:      	movl	$0x4, %eax
    b7da:      	leaq	0x8(%rsp), %rdi
    b7df:      	movl	$0x8, %esi
    b7e4:      	movq	%rbx, %rdx
    b7e7:      	callq	*%rax
    b7e9:      	addq	$0x20, %r12
    b7ed:      	movl	$0x4, %eax
    b7f2:      	leaq	0x58(%rsp), %rdi
    b7f7:      	movl	$0x10, %ecx
    b7fc:      	movl	$0x10, %esi
    b801:      	movq	%r12, %rdx
    b804:      	callq	*%rax
    b806:      	movq	0x28(%rsp), %rbx
    b80b:      	movq	0x48(%rsp), %rax
    b810:      	movl	0x5c(%rsp), %r15d
    b815:      	subq	%rbx, %rax
    b818:      	movl	0x50(%rsp), %r12d
    b81d:      	movl	%r15d, %edx
    b820:      	subl	%r12d, %edx
    b823:      	movl	$0x0, %ecx
    b828:      	cmovbl	%ecx, %edx
    b82b:      	addq	0x60(%rsp), %rdx
    b830:      	xorl	%esi, %esi
    b832:      	cmpl	%r15d, %r12d
    b835:      	seta	%sil
    b839:      	movl	%r15d, %ecx
    b83c:      	cmovbl	%r12d, %ecx
    b840:      	addl	%ecx, %esi
    b842:      	movl	%r12d, %edi
    b845:      	subl	%esi, %edi
    b847:      	movl	%edi, 0x50(%rsp)
    b84b:      	subq	%rsi, %rax
    b84e:      	jb	0x16d52 <generic_fentry_path+0xba72>
    b854:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b85a:      	ja	0x16d52 <generic_fentry_path+0xba72>
    b860:      	cmpl	%r15d, %r12d
    b863:      	jbe	0xb869 <generic_fentry_path+0x589>
    b865:      	movb	$0x2f, (%rbx,%rax)
    b869:      	xorl	%edi, %edi
    b86b:      	cmpl	%r15d, %r12d
    b86e:      	seta	%dil
    b872:      	movzbl	%cl, %esi
    b875:      	addq	%rax, %rbx
    b878:      	addq	%rbx, %rdi
    b87b:      	movl	$0x4, %eax
    b880:      	callq	*%rax
    b882:      	movq	%rbx, 0x48(%rsp)
    b887:      	cmpl	%r15d, %r12d
    b88a:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    b890:      	movq	0x8(%rsp), %r12
    b895:      	movq	%r12, 0x30(%rsp)
    b89a:      	movq	0x38(%rsp), %rdx
    b89f:      	movq	0x40(%rsp), %r15
    b8a4:      	cmpq	0x18(%rsp), %r12
    b8a9:      	je	0xb905 <generic_fentry_path+0x625>
    b8ab:      	jmp	0xb910 <generic_fentry_path+0x630>
    b8ad:      	leaq	0x10(%r15), %rdx
    b8b1:      	movl	$0x4, %eax
    b8b6:      	movq	%rbp, %rdi
    b8b9:      	movl	$0x8, %esi
    b8be:      	callq	*%rax
    b8c0:      	movq	0x40(%rsp), %rax
    b8c5:      	cmpq	(%rsp), %rax
    b8c9:      	je	0x16d4d <generic_fentry_path+0xba6d>
    b8cf:      	addq	$0x18, %r15
    b8d3:      	movl	$0x4, %eax
    b8d8:      	leaq	0x30(%rsp), %rdi
    b8dd:      	movl	$0x8, %esi
    b8e2:      	movq	%r15, %rdx
    b8e5:      	callq	*%rax
    b8e7:      	movq	(%rsp), %r15
    b8eb:      	movq	%r15, 0x40(%rsp)
    b8f0:      	leaq	0x20(%r15), %rdx
    b8f4:      	movq	%rdx, 0x38(%rsp)
    b8f9:      	movq	0x30(%rsp), %r12
    b8fe:      	cmpq	0x18(%rsp), %r12
    b903:      	jne	0xb910 <generic_fentry_path+0x630>
    b905:      	cmpq	0x20(%rsp), %rdx
    b90a:      	je	0x16d4d <generic_fentry_path+0xba6d>
    b910:      	movl	$0x4, %eax
    b915:      	leaq	0x10(%rsp), %rdi
    b91a:      	movl	$0x8, %esi
    b91f:      	callq	*%rax
    b921:      	cmpq	0x10(%rsp), %r12
    b926:      	je	0xba25 <generic_fentry_path+0x745>
    b92c:      	leaq	0x18(%r12), %rbx
    b931:      	movl	$0x4, %eax
    b936:      	movq	%rbp, %rdi
    b939:      	movl	$0x8, %esi
    b93e:      	movq	%rbx, %rdx
    b941:      	callq	*%rax
    b943:      	cmpq	%r12, (%rsp)
    b947:      	je	0xba25 <generic_fentry_path+0x745>
    b94d:      	movl	$0x4, %eax
    b952:      	leaq	0x8(%rsp), %rdi
    b957:      	movl	$0x8, %esi
    b95c:      	movq	%rbx, %rdx
    b95f:      	callq	*%rax
    b961:      	addq	$0x20, %r12
    b965:      	movl	$0x4, %eax
    b96a:      	leaq	0x58(%rsp), %rdi
    b96f:      	movl	$0x10, %ecx
    b974:      	movl	$0x10, %esi
    b979:      	movq	%r12, %rdx
    b97c:      	callq	*%rax
    b97e:      	movq	0x28(%rsp), %rbx
    b983:      	movq	0x48(%rsp), %rax
    b988:      	movl	0x5c(%rsp), %r15d
    b98d:      	subq	%rbx, %rax
    b990:      	movl	0x50(%rsp), %r12d
    b995:      	movl	%r15d, %edx
    b998:      	subl	%r12d, %edx
    b99b:      	movl	$0x0, %ecx
    b9a0:      	cmovbl	%ecx, %edx
    b9a3:      	addq	0x60(%rsp), %rdx
    b9a8:      	xorl	%esi, %esi
    b9aa:      	cmpl	%r15d, %r12d
    b9ad:      	seta	%sil
    b9b1:      	movl	%r15d, %ecx
    b9b4:      	cmovbl	%r12d, %ecx
    b9b8:      	addl	%ecx, %esi
    b9ba:      	movl	%r12d, %edi
    b9bd:      	subl	%esi, %edi
    b9bf:      	movl	%edi, 0x50(%rsp)
    b9c3:      	subq	%rsi, %rax
    b9c6:      	jb	0x16d52 <generic_fentry_path+0xba72>
    b9cc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b9d2:      	ja	0x16d52 <generic_fentry_path+0xba72>
    b9d8:      	cmpl	%r15d, %r12d
    b9db:      	jbe	0xb9e1 <generic_fentry_path+0x701>
    b9dd:      	movb	$0x2f, (%rbx,%rax)
    b9e1:      	xorl	%edi, %edi
    b9e3:      	cmpl	%r15d, %r12d
    b9e6:      	seta	%dil
    b9ea:      	movzbl	%cl, %esi
    b9ed:      	addq	%rax, %rbx
    b9f0:      	addq	%rbx, %rdi
    b9f3:      	movl	$0x4, %eax
    b9f8:      	callq	*%rax
    b9fa:      	movq	%rbx, 0x48(%rsp)
    b9ff:      	cmpl	%r15d, %r12d
    ba02:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    ba08:      	movq	0x8(%rsp), %r12
    ba0d:      	movq	%r12, 0x30(%rsp)
    ba12:      	movq	0x38(%rsp), %rdx
    ba17:      	movq	0x40(%rsp), %r15
    ba1c:      	cmpq	0x18(%rsp), %r12
    ba21:      	je	0xba7d <generic_fentry_path+0x79d>
    ba23:      	jmp	0xba88 <generic_fentry_path+0x7a8>
    ba25:      	leaq	0x10(%r15), %rdx
    ba29:      	movl	$0x4, %eax
    ba2e:      	movq	%rbp, %rdi
    ba31:      	movl	$0x8, %esi
    ba36:      	callq	*%rax
    ba38:      	movq	0x40(%rsp), %rax
    ba3d:      	cmpq	(%rsp), %rax
    ba41:      	je	0x16d4d <generic_fentry_path+0xba6d>
    ba47:      	addq	$0x18, %r15
    ba4b:      	movl	$0x4, %eax
    ba50:      	leaq	0x30(%rsp), %rdi
    ba55:      	movl	$0x8, %esi
    ba5a:      	movq	%r15, %rdx
    ba5d:      	callq	*%rax
    ba5f:      	movq	(%rsp), %r15
    ba63:      	movq	%r15, 0x40(%rsp)
    ba68:      	leaq	0x20(%r15), %rdx
    ba6c:      	movq	%rdx, 0x38(%rsp)
    ba71:      	movq	0x30(%rsp), %r12
    ba76:      	cmpq	0x18(%rsp), %r12
    ba7b:      	jne	0xba88 <generic_fentry_path+0x7a8>
    ba7d:      	cmpq	0x20(%rsp), %rdx
    ba82:      	je	0x16d4d <generic_fentry_path+0xba6d>
    ba88:      	movl	$0x4, %eax
    ba8d:      	leaq	0x10(%rsp), %rdi
    ba92:      	movl	$0x8, %esi
    ba97:      	callq	*%rax
    ba99:      	cmpq	0x10(%rsp), %r12
    ba9e:      	je	0xbb9d <generic_fentry_path+0x8bd>
    baa4:      	leaq	0x18(%r12), %rbx
    baa9:      	movl	$0x4, %eax
    baae:      	movq	%rbp, %rdi
    bab1:      	movl	$0x8, %esi
    bab6:      	movq	%rbx, %rdx
    bab9:      	callq	*%rax
    babb:      	cmpq	%r12, (%rsp)
    babf:      	je	0xbb9d <generic_fentry_path+0x8bd>
    bac5:      	movl	$0x4, %eax
    baca:      	leaq	0x8(%rsp), %rdi
    bacf:      	movl	$0x8, %esi
    bad4:      	movq	%rbx, %rdx
    bad7:      	callq	*%rax
    bad9:      	addq	$0x20, %r12
    badd:      	movl	$0x4, %eax
    bae2:      	leaq	0x58(%rsp), %rdi
    bae7:      	movl	$0x10, %ecx
    baec:      	movl	$0x10, %esi
    baf1:      	movq	%r12, %rdx
    baf4:      	callq	*%rax
    baf6:      	movq	0x28(%rsp), %rbx
    bafb:      	movq	0x48(%rsp), %rax
    bb00:      	movl	0x5c(%rsp), %r15d
    bb05:      	subq	%rbx, %rax
    bb08:      	movl	0x50(%rsp), %r12d
    bb0d:      	movl	%r15d, %edx
    bb10:      	subl	%r12d, %edx
    bb13:      	movl	$0x0, %ecx
    bb18:      	cmovbl	%ecx, %edx
    bb1b:      	addq	0x60(%rsp), %rdx
    bb20:      	xorl	%esi, %esi
    bb22:      	cmpl	%r15d, %r12d
    bb25:      	seta	%sil
    bb29:      	movl	%r15d, %ecx
    bb2c:      	cmovbl	%r12d, %ecx
    bb30:      	addl	%ecx, %esi
    bb32:      	movl	%r12d, %edi
    bb35:      	subl	%esi, %edi
    bb37:      	movl	%edi, 0x50(%rsp)
    bb3b:      	subq	%rsi, %rax
    bb3e:      	jb	0x16d52 <generic_fentry_path+0xba72>
    bb44:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    bb4a:      	ja	0x16d52 <generic_fentry_path+0xba72>
    bb50:      	cmpl	%r15d, %r12d
    bb53:      	jbe	0xbb59 <generic_fentry_path+0x879>
    bb55:      	movb	$0x2f, (%rbx,%rax)
    bb59:      	xorl	%edi, %edi
    bb5b:      	cmpl	%r15d, %r12d
    bb5e:      	seta	%dil
    bb62:      	movzbl	%cl, %esi
    bb65:      	addq	%rax, %rbx
    bb68:      	addq	%rbx, %rdi
    bb6b:      	movl	$0x4, %eax
    bb70:      	callq	*%rax
    bb72:      	movq	%rbx, 0x48(%rsp)
    bb77:      	cmpl	%r15d, %r12d
    bb7a:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    bb80:      	movq	0x8(%rsp), %r12
    bb85:      	movq	%r12, 0x30(%rsp)
    bb8a:      	movq	0x38(%rsp), %rdx
    bb8f:      	movq	0x40(%rsp), %r15
    bb94:      	cmpq	0x18(%rsp), %r12
    bb99:      	je	0xbbf5 <generic_fentry_path+0x915>
    bb9b:      	jmp	0xbc00 <generic_fentry_path+0x920>
    bb9d:      	leaq	0x10(%r15), %rdx
    bba1:      	movl	$0x4, %eax
    bba6:      	movq	%rbp, %rdi
    bba9:      	movl	$0x8, %esi
    bbae:      	callq	*%rax
    bbb0:      	movq	0x40(%rsp), %rax
    bbb5:      	cmpq	(%rsp), %rax
    bbb9:      	je	0x16d4d <generic_fentry_path+0xba6d>
    bbbf:      	addq	$0x18, %r15
    bbc3:      	movl	$0x4, %eax
    bbc8:      	leaq	0x30(%rsp), %rdi
    bbcd:      	movl	$0x8, %esi
    bbd2:      	movq	%r15, %rdx
    bbd5:      	callq	*%rax
    bbd7:      	movq	(%rsp), %r15
    bbdb:      	movq	%r15, 0x40(%rsp)
    bbe0:      	leaq	0x20(%r15), %rdx
    bbe4:      	movq	%rdx, 0x38(%rsp)
    bbe9:      	movq	0x30(%rsp), %r12
    bbee:      	cmpq	0x18(%rsp), %r12
    bbf3:      	jne	0xbc00 <generic_fentry_path+0x920>
    bbf5:      	cmpq	0x20(%rsp), %rdx
    bbfa:      	je	0x16d4d <generic_fentry_path+0xba6d>
    bc00:      	movl	$0x4, %eax
    bc05:      	leaq	0x10(%rsp), %rdi
    bc0a:      	movl	$0x8, %esi
    bc0f:      	callq	*%rax
    bc11:      	cmpq	0x10(%rsp), %r12
    bc16:      	je	0xbd15 <generic_fentry_path+0xa35>
    bc1c:      	leaq	0x18(%r12), %rbx
    bc21:      	movl	$0x4, %eax
    bc26:      	movq	%rbp, %rdi
    bc29:      	movl	$0x8, %esi
    bc2e:      	movq	%rbx, %rdx
    bc31:      	callq	*%rax
    bc33:      	cmpq	%r12, (%rsp)
    bc37:      	je	0xbd15 <generic_fentry_path+0xa35>
    bc3d:      	movl	$0x4, %eax
    bc42:      	leaq	0x8(%rsp), %rdi
    bc47:      	movl	$0x8, %esi
    bc4c:      	movq	%rbx, %rdx
    bc4f:      	callq	*%rax
    bc51:      	addq	$0x20, %r12
    bc55:      	movl	$0x4, %eax
    bc5a:      	leaq	0x58(%rsp), %rdi
    bc5f:      	movl	$0x10, %ecx
    bc64:      	movl	$0x10, %esi
    bc69:      	movq	%r12, %rdx
    bc6c:      	callq	*%rax
    bc6e:      	movq	0x28(%rsp), %rbx
    bc73:      	movq	0x48(%rsp), %rax
    bc78:      	movl	0x5c(%rsp), %r15d
    bc7d:      	subq	%rbx, %rax
    bc80:      	movl	0x50(%rsp), %r12d
    bc85:      	movl	%r15d, %edx
    bc88:      	subl	%r12d, %edx
    bc8b:      	movl	$0x0, %ecx
    bc90:      	cmovbl	%ecx, %edx
    bc93:      	addq	0x60(%rsp), %rdx
    bc98:      	xorl	%esi, %esi
    bc9a:      	cmpl	%r15d, %r12d
    bc9d:      	seta	%sil
    bca1:      	movl	%r15d, %ecx
    bca4:      	cmovbl	%r12d, %ecx
    bca8:      	addl	%ecx, %esi
    bcaa:      	movl	%r12d, %edi
    bcad:      	subl	%esi, %edi
    bcaf:      	movl	%edi, 0x50(%rsp)
    bcb3:      	subq	%rsi, %rax
    bcb6:      	jb	0x16d52 <generic_fentry_path+0xba72>
    bcbc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    bcc2:      	ja	0x16d52 <generic_fentry_path+0xba72>
    bcc8:      	cmpl	%r15d, %r12d
    bccb:      	jbe	0xbcd1 <generic_fentry_path+0x9f1>
    bccd:      	movb	$0x2f, (%rbx,%rax)
    bcd1:      	xorl	%edi, %edi
    bcd3:      	cmpl	%r15d, %r12d
    bcd6:      	seta	%dil
    bcda:      	movzbl	%cl, %esi
    bcdd:      	addq	%rax, %rbx
    bce0:      	addq	%rbx, %rdi
    bce3:      	movl	$0x4, %eax
    bce8:      	callq	*%rax
    bcea:      	movq	%rbx, 0x48(%rsp)
    bcef:      	cmpl	%r15d, %r12d
    bcf2:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    bcf8:      	movq	0x8(%rsp), %r12
    bcfd:      	movq	%r12, 0x30(%rsp)
    bd02:      	movq	0x38(%rsp), %rdx
    bd07:      	movq	0x40(%rsp), %r15
    bd0c:      	cmpq	0x18(%rsp), %r12
    bd11:      	je	0xbd6d <generic_fentry_path+0xa8d>
    bd13:      	jmp	0xbd78 <generic_fentry_path+0xa98>
    bd15:      	leaq	0x10(%r15), %rdx
    bd19:      	movl	$0x4, %eax
    bd1e:      	movq	%rbp, %rdi
    bd21:      	movl	$0x8, %esi
    bd26:      	callq	*%rax
    bd28:      	movq	0x40(%rsp), %rax
    bd2d:      	cmpq	(%rsp), %rax
    bd31:      	je	0x16d4d <generic_fentry_path+0xba6d>
    bd37:      	addq	$0x18, %r15
    bd3b:      	movl	$0x4, %eax
    bd40:      	leaq	0x30(%rsp), %rdi
    bd45:      	movl	$0x8, %esi
    bd4a:      	movq	%r15, %rdx
    bd4d:      	callq	*%rax
    bd4f:      	movq	(%rsp), %r15
    bd53:      	movq	%r15, 0x40(%rsp)
    bd58:      	leaq	0x20(%r15), %rdx
    bd5c:      	movq	%rdx, 0x38(%rsp)
    bd61:      	movq	0x30(%rsp), %r12
    bd66:      	cmpq	0x18(%rsp), %r12
    bd6b:      	jne	0xbd78 <generic_fentry_path+0xa98>
    bd6d:      	cmpq	0x20(%rsp), %rdx
    bd72:      	je	0x16d4d <generic_fentry_path+0xba6d>
    bd78:      	movl	$0x4, %eax
    bd7d:      	leaq	0x10(%rsp), %rdi
    bd82:      	movl	$0x8, %esi
    bd87:      	callq	*%rax
    bd89:      	cmpq	0x10(%rsp), %r12
    bd8e:      	je	0xbe8d <generic_fentry_path+0xbad>
    bd94:      	leaq	0x18(%r12), %rbx
    bd99:      	movl	$0x4, %eax
    bd9e:      	movq	%rbp, %rdi
    bda1:      	movl	$0x8, %esi
    bda6:      	movq	%rbx, %rdx
    bda9:      	callq	*%rax
    bdab:      	cmpq	%r12, (%rsp)
    bdaf:      	je	0xbe8d <generic_fentry_path+0xbad>
    bdb5:      	movl	$0x4, %eax
    bdba:      	leaq	0x8(%rsp), %rdi
    bdbf:      	movl	$0x8, %esi
    bdc4:      	movq	%rbx, %rdx
    bdc7:      	callq	*%rax
    bdc9:      	addq	$0x20, %r12
    bdcd:      	movl	$0x4, %eax
    bdd2:      	leaq	0x58(%rsp), %rdi
    bdd7:      	movl	$0x10, %ecx
    bddc:      	movl	$0x10, %esi
    bde1:      	movq	%r12, %rdx
    bde4:      	callq	*%rax
    bde6:      	movq	0x28(%rsp), %rbx
    bdeb:      	movq	0x48(%rsp), %rax
    bdf0:      	movl	0x5c(%rsp), %r15d
    bdf5:      	subq	%rbx, %rax
    bdf8:      	movl	0x50(%rsp), %r12d
    bdfd:      	movl	%r15d, %edx
    be00:      	subl	%r12d, %edx
    be03:      	movl	$0x0, %ecx
    be08:      	cmovbl	%ecx, %edx
    be0b:      	addq	0x60(%rsp), %rdx
    be10:      	xorl	%esi, %esi
    be12:      	cmpl	%r15d, %r12d
    be15:      	seta	%sil
    be19:      	movl	%r15d, %ecx
    be1c:      	cmovbl	%r12d, %ecx
    be20:      	addl	%ecx, %esi
    be22:      	movl	%r12d, %edi
    be25:      	subl	%esi, %edi
    be27:      	movl	%edi, 0x50(%rsp)
    be2b:      	subq	%rsi, %rax
    be2e:      	jb	0x16d52 <generic_fentry_path+0xba72>
    be34:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    be3a:      	ja	0x16d52 <generic_fentry_path+0xba72>
    be40:      	cmpl	%r15d, %r12d
    be43:      	jbe	0xbe49 <generic_fentry_path+0xb69>
    be45:      	movb	$0x2f, (%rbx,%rax)
    be49:      	xorl	%edi, %edi
    be4b:      	cmpl	%r15d, %r12d
    be4e:      	seta	%dil
    be52:      	movzbl	%cl, %esi
    be55:      	addq	%rax, %rbx
    be58:      	addq	%rbx, %rdi
    be5b:      	movl	$0x4, %eax
    be60:      	callq	*%rax
    be62:      	movq	%rbx, 0x48(%rsp)
    be67:      	cmpl	%r15d, %r12d
    be6a:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    be70:      	movq	0x8(%rsp), %r12
    be75:      	movq	%r12, 0x30(%rsp)
    be7a:      	movq	0x38(%rsp), %rdx
    be7f:      	movq	0x40(%rsp), %r15
    be84:      	cmpq	0x18(%rsp), %r12
    be89:      	je	0xbee5 <generic_fentry_path+0xc05>
    be8b:      	jmp	0xbef0 <generic_fentry_path+0xc10>
    be8d:      	leaq	0x10(%r15), %rdx
    be91:      	movl	$0x4, %eax
    be96:      	movq	%rbp, %rdi
    be99:      	movl	$0x8, %esi
    be9e:      	callq	*%rax
    bea0:      	movq	0x40(%rsp), %rax
    bea5:      	cmpq	(%rsp), %rax
    bea9:      	je	0x16d4d <generic_fentry_path+0xba6d>
    beaf:      	addq	$0x18, %r15
    beb3:      	movl	$0x4, %eax
    beb8:      	leaq	0x30(%rsp), %rdi
    bebd:      	movl	$0x8, %esi
    bec2:      	movq	%r15, %rdx
    bec5:      	callq	*%rax
    bec7:      	movq	(%rsp), %r15
    becb:      	movq	%r15, 0x40(%rsp)
    bed0:      	leaq	0x20(%r15), %rdx
    bed4:      	movq	%rdx, 0x38(%rsp)
    bed9:      	movq	0x30(%rsp), %r12
    bede:      	cmpq	0x18(%rsp), %r12
    bee3:      	jne	0xbef0 <generic_fentry_path+0xc10>
    bee5:      	cmpq	0x20(%rsp), %rdx
    beea:      	je	0x16d4d <generic_fentry_path+0xba6d>
    bef0:      	movl	$0x4, %eax
    bef5:      	leaq	0x10(%rsp), %rdi
    befa:      	movl	$0x8, %esi
    beff:      	callq	*%rax
    bf01:      	cmpq	0x10(%rsp), %r12
    bf06:      	je	0xc005 <generic_fentry_path+0xd25>
    bf0c:      	leaq	0x18(%r12), %rbx
    bf11:      	movl	$0x4, %eax
    bf16:      	movq	%rbp, %rdi
    bf19:      	movl	$0x8, %esi
    bf1e:      	movq	%rbx, %rdx
    bf21:      	callq	*%rax
    bf23:      	cmpq	%r12, (%rsp)
    bf27:      	je	0xc005 <generic_fentry_path+0xd25>
    bf2d:      	movl	$0x4, %eax
    bf32:      	leaq	0x8(%rsp), %rdi
    bf37:      	movl	$0x8, %esi
    bf3c:      	movq	%rbx, %rdx
    bf3f:      	callq	*%rax
    bf41:      	addq	$0x20, %r12
    bf45:      	movl	$0x4, %eax
    bf4a:      	leaq	0x58(%rsp), %rdi
    bf4f:      	movl	$0x10, %ecx
    bf54:      	movl	$0x10, %esi
    bf59:      	movq	%r12, %rdx
    bf5c:      	callq	*%rax
    bf5e:      	movq	0x28(%rsp), %rbx
    bf63:      	movq	0x48(%rsp), %rax
    bf68:      	movl	0x5c(%rsp), %r15d
    bf6d:      	subq	%rbx, %rax
    bf70:      	movl	0x50(%rsp), %r12d
    bf75:      	movl	%r15d, %edx
    bf78:      	subl	%r12d, %edx
    bf7b:      	movl	$0x0, %ecx
    bf80:      	cmovbl	%ecx, %edx
    bf83:      	addq	0x60(%rsp), %rdx
    bf88:      	xorl	%esi, %esi
    bf8a:      	cmpl	%r15d, %r12d
    bf8d:      	seta	%sil
    bf91:      	movl	%r15d, %ecx
    bf94:      	cmovbl	%r12d, %ecx
    bf98:      	addl	%ecx, %esi
    bf9a:      	movl	%r12d, %edi
    bf9d:      	subl	%esi, %edi
    bf9f:      	movl	%edi, 0x50(%rsp)
    bfa3:      	subq	%rsi, %rax
    bfa6:      	jb	0x16d52 <generic_fentry_path+0xba72>
    bfac:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    bfb2:      	ja	0x16d52 <generic_fentry_path+0xba72>
    bfb8:      	cmpl	%r15d, %r12d
    bfbb:      	jbe	0xbfc1 <generic_fentry_path+0xce1>
    bfbd:      	movb	$0x2f, (%rbx,%rax)
    bfc1:      	xorl	%edi, %edi
    bfc3:      	cmpl	%r15d, %r12d
    bfc6:      	seta	%dil
    bfca:      	movzbl	%cl, %esi
    bfcd:      	addq	%rax, %rbx
    bfd0:      	addq	%rbx, %rdi
    bfd3:      	movl	$0x4, %eax
    bfd8:      	callq	*%rax
    bfda:      	movq	%rbx, 0x48(%rsp)
    bfdf:      	cmpl	%r15d, %r12d
    bfe2:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    bfe8:      	movq	0x8(%rsp), %r12
    bfed:      	movq	%r12, 0x30(%rsp)
    bff2:      	movq	0x38(%rsp), %rdx
    bff7:      	movq	0x40(%rsp), %r15
    bffc:      	cmpq	0x18(%rsp), %r12
    c001:      	je	0xc05d <generic_fentry_path+0xd7d>
    c003:      	jmp	0xc068 <generic_fentry_path+0xd88>
    c005:      	leaq	0x10(%r15), %rdx
    c009:      	movl	$0x4, %eax
    c00e:      	movq	%rbp, %rdi
    c011:      	movl	$0x8, %esi
    c016:      	callq	*%rax
    c018:      	movq	0x40(%rsp), %rax
    c01d:      	cmpq	(%rsp), %rax
    c021:      	je	0x16d4d <generic_fentry_path+0xba6d>
    c027:      	addq	$0x18, %r15
    c02b:      	movl	$0x4, %eax
    c030:      	leaq	0x30(%rsp), %rdi
    c035:      	movl	$0x8, %esi
    c03a:      	movq	%r15, %rdx
    c03d:      	callq	*%rax
    c03f:      	movq	(%rsp), %r15
    c043:      	movq	%r15, 0x40(%rsp)
    c048:      	leaq	0x20(%r15), %rdx
    c04c:      	movq	%rdx, 0x38(%rsp)
    c051:      	movq	0x30(%rsp), %r12
    c056:      	cmpq	0x18(%rsp), %r12
    c05b:      	jne	0xc068 <generic_fentry_path+0xd88>
    c05d:      	cmpq	0x20(%rsp), %rdx
    c062:      	je	0x16d4d <generic_fentry_path+0xba6d>
    c068:      	movl	$0x4, %eax
    c06d:      	leaq	0x10(%rsp), %rdi
    c072:      	movl	$0x8, %esi
    c077:      	callq	*%rax
    c079:      	cmpq	0x10(%rsp), %r12
    c07e:      	je	0xc17d <generic_fentry_path+0xe9d>
    c084:      	leaq	0x18(%r12), %rbx
    c089:      	movl	$0x4, %eax
    c08e:      	movq	%rbp, %rdi
    c091:      	movl	$0x8, %esi
    c096:      	movq	%rbx, %rdx
    c099:      	callq	*%rax
    c09b:      	cmpq	%r12, (%rsp)
    c09f:      	je	0xc17d <generic_fentry_path+0xe9d>
    c0a5:      	movl	$0x4, %eax
    c0aa:      	leaq	0x8(%rsp), %rdi
    c0af:      	movl	$0x8, %esi
    c0b4:      	movq	%rbx, %rdx
    c0b7:      	callq	*%rax
    c0b9:      	addq	$0x20, %r12
    c0bd:      	movl	$0x4, %eax
    c0c2:      	leaq	0x58(%rsp), %rdi
    c0c7:      	movl	$0x10, %ecx
    c0cc:      	movl	$0x10, %esi
    c0d1:      	movq	%r12, %rdx
    c0d4:      	callq	*%rax
    c0d6:      	movq	0x28(%rsp), %rbx
    c0db:      	movq	0x48(%rsp), %rax
    c0e0:      	movl	0x5c(%rsp), %r15d
    c0e5:      	subq	%rbx, %rax
    c0e8:      	movl	0x50(%rsp), %r12d
    c0ed:      	movl	%r15d, %edx
    c0f0:      	subl	%r12d, %edx
    c0f3:      	movl	$0x0, %ecx
    c0f8:      	cmovbl	%ecx, %edx
    c0fb:      	addq	0x60(%rsp), %rdx
    c100:      	xorl	%esi, %esi
    c102:      	cmpl	%r15d, %r12d
    c105:      	seta	%sil
    c109:      	movl	%r15d, %ecx
    c10c:      	cmovbl	%r12d, %ecx
    c110:      	addl	%ecx, %esi
    c112:      	movl	%r12d, %edi
    c115:      	subl	%esi, %edi
    c117:      	movl	%edi, 0x50(%rsp)
    c11b:      	subq	%rsi, %rax
    c11e:      	jb	0x16d52 <generic_fentry_path+0xba72>
    c124:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c12a:      	ja	0x16d52 <generic_fentry_path+0xba72>
    c130:      	cmpl	%r15d, %r12d
    c133:      	jbe	0xc139 <generic_fentry_path+0xe59>
    c135:      	movb	$0x2f, (%rbx,%rax)
    c139:      	xorl	%edi, %edi
    c13b:      	cmpl	%r15d, %r12d
    c13e:      	seta	%dil
    c142:      	movzbl	%cl, %esi
    c145:      	addq	%rax, %rbx
    c148:      	addq	%rbx, %rdi
    c14b:      	movl	$0x4, %eax
    c150:      	callq	*%rax
    c152:      	movq	%rbx, 0x48(%rsp)
    c157:      	cmpl	%r15d, %r12d
    c15a:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    c160:      	movq	0x8(%rsp), %r12
    c165:      	movq	%r12, 0x30(%rsp)
    c16a:      	movq	0x38(%rsp), %rdx
    c16f:      	movq	0x40(%rsp), %r15
    c174:      	cmpq	0x18(%rsp), %r12
    c179:      	je	0xc1d5 <generic_fentry_path+0xef5>
    c17b:      	jmp	0xc1e0 <generic_fentry_path+0xf00>
    c17d:      	leaq	0x10(%r15), %rdx
    c181:      	movl	$0x4, %eax
    c186:      	movq	%rbp, %rdi
    c189:      	movl	$0x8, %esi
    c18e:      	callq	*%rax
    c190:      	movq	0x40(%rsp), %rax
    c195:      	cmpq	(%rsp), %rax
    c199:      	je	0x16d4d <generic_fentry_path+0xba6d>
    c19f:      	addq	$0x18, %r15
    c1a3:      	movl	$0x4, %eax
    c1a8:      	leaq	0x30(%rsp), %rdi
    c1ad:      	movl	$0x8, %esi
    c1b2:      	movq	%r15, %rdx
    c1b5:      	callq	*%rax
    c1b7:      	movq	(%rsp), %r15
    c1bb:      	movq	%r15, 0x40(%rsp)
    c1c0:      	leaq	0x20(%r15), %rdx
    c1c4:      	movq	%rdx, 0x38(%rsp)
    c1c9:      	movq	0x30(%rsp), %r12
    c1ce:      	cmpq	0x18(%rsp), %r12
    c1d3:      	jne	0xc1e0 <generic_fentry_path+0xf00>
    c1d5:      	cmpq	0x20(%rsp), %rdx
    c1da:      	je	0x16d4d <generic_fentry_path+0xba6d>
    c1e0:      	movl	$0x4, %eax
    c1e5:      	leaq	0x10(%rsp), %rdi
    c1ea:      	movl	$0x8, %esi
    c1ef:      	callq	*%rax
    c1f1:      	cmpq	0x10(%rsp), %r12
    c1f6:      	je	0xc2ee <generic_fentry_path+0x100e>
    c1fc:      	leaq	0x18(%r12), %rbx
    c201:      	movl	$0x4, %eax
    c206:      	movq	%rbp, %rdi
    c209:      	movl	$0x8, %esi
    c20e:      	movq	%rbx, %rdx
    c211:      	callq	*%rax
    c213:      	cmpq	%r12, (%rsp)
    c217:      	je	0xc2ee <generic_fentry_path+0x100e>
    c21d:      	movl	$0x4, %eax
    c222:      	leaq	0x8(%rsp), %rdi
    c227:      	movl	$0x8, %esi
    c22c:      	movq	%rbx, %rdx
    c22f:      	callq	*%rax
    c231:      	addq	$0x20, %r12
    c235:      	movl	$0x4, %eax
    c23a:      	leaq	0x58(%rsp), %rdi
    c23f:      	movl	$0x10, %ecx
    c244:      	movl	$0x10, %esi
    c249:      	movq	%r12, %rdx
    c24c:      	callq	*%rax
    c24e:      	movq	0x28(%rsp), %rbx
    c253:      	movq	0x48(%rsp), %rax
    c258:      	movl	0x5c(%rsp), %r15d
    c25d:      	subq	%rbx, %rax
    c260:      	movl	0x50(%rsp), %r12d
    c265:      	movl	%r15d, %edx
    c268:      	subl	%r12d, %edx
    c26b:      	movl	$0x0, %ecx
    c270:      	cmovbl	%ecx, %edx
    c273:      	addq	0x60(%rsp), %rdx
    c278:      	xorl	%esi, %esi
    c27a:      	cmpl	%r15d, %r12d
    c27d:      	seta	%sil
    c281:      	movl	%r15d, %ecx
    c284:      	cmovbl	%r12d, %ecx
    c288:      	addl	%ecx, %esi
    c28a:      	movl	%r12d, %edi
    c28d:      	subl	%esi, %edi
    c28f:      	movl	%edi, 0x50(%rsp)
    c293:      	subq	%rsi, %rax
    c296:      	jb	0x16d52 <generic_fentry_path+0xba72>
    c29c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c2a2:      	ja	0x16d52 <generic_fentry_path+0xba72>
    c2a8:      	cmpl	%r15d, %r12d
    c2ab:      	jbe	0xc2b1 <generic_fentry_path+0xfd1>
    c2ad:      	movb	$0x2f, (%rbx,%rax)
    c2b1:      	xorl	%edi, %edi
    c2b3:      	cmpl	%r15d, %r12d
    c2b6:      	seta	%dil
    c2ba:      	movzbl	%cl, %esi
    c2bd:      	addq	%rax, %rbx
    c2c0:      	addq	%rbx, %rdi
    c2c3:      	movl	$0x4, %eax
    c2c8:      	callq	*%rax
    c2ca:      	movq	%rbx, 0x48(%rsp)
    c2cf:      	cmpl	%r15d, %r12d
    c2d2:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    c2d8:      	movq	0x8(%rsp), %r12
    c2dd:      	movq	%r12, 0x30(%rsp)
    c2e2:      	movq	0x38(%rsp), %rdx
    c2e7:      	movq	0x40(%rsp), %r15
    c2ec:      	jmp	0xc33f <generic_fentry_path+0x105f>
    c2ee:      	leaq	0x10(%r15), %rdx
    c2f2:      	movl	$0x4, %eax
    c2f7:      	movq	%rbp, %rdi
    c2fa:      	movl	$0x8, %esi
    c2ff:      	callq	*%rax
    c301:      	movq	0x40(%rsp), %rax
    c306:      	cmpq	(%rsp), %rax
    c30a:      	je	0x16d4d <generic_fentry_path+0xba6d>
    c310:      	addq	$0x18, %r15
    c314:      	movl	$0x4, %eax
    c319:      	leaq	0x30(%rsp), %rdi
    c31e:      	movl	$0x8, %esi
    c323:      	movq	%r15, %rdx
    c326:      	callq	*%rax
    c328:      	movq	(%rsp), %r15
    c32c:      	movq	%r15, 0x40(%rsp)
    c331:      	leaq	0x20(%r15), %rdx
    c335:      	movq	%rdx, 0x38(%rsp)
    c33a:      	movq	0x30(%rsp), %r12
    c33f:      	cmpq	0x18(%rsp), %r12
    c344:      	jne	0xc351 <generic_fentry_path+0x1071>
    c346:      	cmpq	0x20(%rsp), %rdx
    c34b:      	je	0x16d4d <generic_fentry_path+0xba6d>
    c351:      	movl	$0x4, %eax
    c356:      	leaq	0x10(%rsp), %rdi
    c35b:      	movl	$0x8, %esi
    c360:      	callq	*%rax
    c362:      	cmpq	0x10(%rsp), %r12
    c367:      	je	0xc45f <generic_fentry_path+0x117f>
    c36d:      	leaq	0x18(%r12), %rbx
    c372:      	movl	$0x4, %eax
    c377:      	movq	%rbp, %rdi
    c37a:      	movl	$0x8, %esi
    c37f:      	movq	%rbx, %rdx
    c382:      	callq	*%rax
    c384:      	cmpq	%r12, (%rsp)
    c388:      	je	0xc45f <generic_fentry_path+0x117f>
    c38e:      	movl	$0x4, %eax
    c393:      	leaq	0x8(%rsp), %rdi
    c398:      	movl	$0x8, %esi
    c39d:      	movq	%rbx, %rdx
    c3a0:      	callq	*%rax
    c3a2:      	addq	$0x20, %r12
    c3a6:      	movl	$0x4, %eax
    c3ab:      	leaq	0x58(%rsp), %rdi
    c3b0:      	movl	$0x10, %ecx
    c3b5:      	movl	$0x10, %esi
    c3ba:      	movq	%r12, %rdx
    c3bd:      	callq	*%rax
    c3bf:      	movq	0x28(%rsp), %rbx
    c3c4:      	movq	0x48(%rsp), %rax
    c3c9:      	movl	0x5c(%rsp), %r15d
    c3ce:      	subq	%rbx, %rax
    c3d1:      	movl	0x50(%rsp), %r12d
    c3d6:      	movl	%r15d, %edx
    c3d9:      	subl	%r12d, %edx
    c3dc:      	movl	$0x0, %ecx
    c3e1:      	cmovbl	%ecx, %edx
    c3e4:      	addq	0x60(%rsp), %rdx
    c3e9:      	xorl	%esi, %esi
    c3eb:      	cmpl	%r15d, %r12d
    c3ee:      	seta	%sil
    c3f2:      	movl	%r15d, %ecx
    c3f5:      	cmovbl	%r12d, %ecx
    c3f9:      	addl	%ecx, %esi
    c3fb:      	movl	%r12d, %edi
    c3fe:      	subl	%esi, %edi
    c400:      	movl	%edi, 0x50(%rsp)
    c404:      	subq	%rsi, %rax
    c407:      	jb	0x16d52 <generic_fentry_path+0xba72>
    c40d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c413:      	ja	0x16d52 <generic_fentry_path+0xba72>
    c419:      	cmpl	%r15d, %r12d
    c41c:      	jbe	0xc422 <generic_fentry_path+0x1142>
    c41e:      	movb	$0x2f, (%rbx,%rax)
    c422:      	xorl	%edi, %edi
    c424:      	cmpl	%r15d, %r12d
    c427:      	seta	%dil
    c42b:      	movzbl	%cl, %esi
    c42e:      	addq	%rax, %rbx
    c431:      	addq	%rbx, %rdi
    c434:      	movl	$0x4, %eax
    c439:      	callq	*%rax
    c43b:      	movq	%rbx, 0x48(%rsp)
    c440:      	cmpl	%r15d, %r12d
    c443:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    c449:      	movq	0x8(%rsp), %r12
    c44e:      	movq	%r12, 0x30(%rsp)
    c453:      	movq	0x38(%rsp), %rdx
    c458:      	movq	0x40(%rsp), %r15
    c45d:      	jmp	0xc4b0 <generic_fentry_path+0x11d0>
    c45f:      	leaq	0x10(%r15), %rdx
    c463:      	movl	$0x4, %eax
    c468:      	movq	%rbp, %rdi
    c46b:      	movl	$0x8, %esi
    c470:      	callq	*%rax
    c472:      	movq	0x40(%rsp), %rax
    c477:      	cmpq	(%rsp), %rax
    c47b:      	je	0x16d4d <generic_fentry_path+0xba6d>
    c481:      	addq	$0x18, %r15
    c485:      	movl	$0x4, %eax
    c48a:      	leaq	0x30(%rsp), %rdi
    c48f:      	movl	$0x8, %esi
    c494:      	movq	%r15, %rdx
    c497:      	callq	*%rax
    c499:      	movq	(%rsp), %r15
    c49d:      	movq	%r15, 0x40(%rsp)
    c4a2:      	leaq	0x20(%r15), %rdx
    c4a6:      	movq	%rdx, 0x38(%rsp)
    c4ab:      	movq	0x30(%rsp), %r12
    c4b0:      	cmpq	0x18(%rsp), %r12
    c4b5:      	jne	0xc4c2 <generic_fentry_path+0x11e2>
    c4b7:      	cmpq	0x20(%rsp), %rdx
    c4bc:      	je	0x16d4d <generic_fentry_path+0xba6d>
    c4c2:      	movl	$0x4, %eax
    c4c7:      	leaq	0x10(%rsp), %rdi
    c4cc:      	movl	$0x8, %esi
    c4d1:      	callq	*%rax
    c4d3:      	cmpq	0x10(%rsp), %r12
    c4d8:      	je	0xc5d0 <generic_fentry_path+0x12f0>
    c4de:      	leaq	0x18(%r12), %rbx
    c4e3:      	movl	$0x4, %eax
    c4e8:      	movq	%rbp, %rdi
    c4eb:      	movl	$0x8, %esi
    c4f0:      	movq	%rbx, %rdx
    c4f3:      	callq	*%rax
    c4f5:      	cmpq	%r12, (%rsp)
    c4f9:      	je	0xc5d0 <generic_fentry_path+0x12f0>
    c4ff:      	movl	$0x4, %eax
    c504:      	leaq	0x8(%rsp), %rdi
    c509:      	movl	$0x8, %esi
    c50e:      	movq	%rbx, %rdx
    c511:      	callq	*%rax
    c513:      	addq	$0x20, %r12
    c517:      	movl	$0x4, %eax
    c51c:      	leaq	0x58(%rsp), %rdi
    c521:      	movl	$0x10, %ecx
    c526:      	movl	$0x10, %esi
    c52b:      	movq	%r12, %rdx
    c52e:      	callq	*%rax
    c530:      	movq	0x28(%rsp), %rbx
    c535:      	movq	0x48(%rsp), %rax
    c53a:      	movl	0x5c(%rsp), %r15d
    c53f:      	subq	%rbx, %rax
    c542:      	movl	0x50(%rsp), %r12d
    c547:      	movl	%r15d, %edx
    c54a:      	subl	%r12d, %edx
    c54d:      	movl	$0x0, %ecx
    c552:      	cmovbl	%ecx, %edx
    c555:      	addq	0x60(%rsp), %rdx
    c55a:      	xorl	%esi, %esi
    c55c:      	cmpl	%r15d, %r12d
    c55f:      	seta	%sil
    c563:      	movl	%r15d, %ecx
    c566:      	cmovbl	%r12d, %ecx
    c56a:      	addl	%ecx, %esi
    c56c:      	movl	%r12d, %edi
    c56f:      	subl	%esi, %edi
    c571:      	movl	%edi, 0x50(%rsp)
    c575:      	subq	%rsi, %rax
    c578:      	jb	0x16d52 <generic_fentry_path+0xba72>
    c57e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c584:      	ja	0x16d52 <generic_fentry_path+0xba72>
    c58a:      	cmpl	%r15d, %r12d
    c58d:      	jbe	0xc593 <generic_fentry_path+0x12b3>
    c58f:      	movb	$0x2f, (%rbx,%rax)
    c593:      	xorl	%edi, %edi
    c595:      	cmpl	%r15d, %r12d
    c598:      	seta	%dil
    c59c:      	movzbl	%cl, %esi
    c59f:      	addq	%rax, %rbx
    c5a2:      	addq	%rbx, %rdi
    c5a5:      	movl	$0x4, %eax
    c5aa:      	callq	*%rax
    c5ac:      	movq	%rbx, 0x48(%rsp)
    c5b1:      	cmpl	%r15d, %r12d
    c5b4:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    c5ba:      	movq	0x8(%rsp), %r12
    c5bf:      	movq	%r12, 0x30(%rsp)
    c5c4:      	movq	0x38(%rsp), %rdx
    c5c9:      	movq	0x40(%rsp), %r15
    c5ce:      	jmp	0xc621 <generic_fentry_path+0x1341>
    c5d0:      	leaq	0x10(%r15), %rdx
    c5d4:      	movl	$0x4, %eax
    c5d9:      	movq	%rbp, %rdi
    c5dc:      	movl	$0x8, %esi
    c5e1:      	callq	*%rax
    c5e3:      	movq	0x40(%rsp), %rax
    c5e8:      	cmpq	(%rsp), %rax
    c5ec:      	je	0x16d4d <generic_fentry_path+0xba6d>
    c5f2:      	addq	$0x18, %r15
    c5f6:      	movl	$0x4, %eax
    c5fb:      	leaq	0x30(%rsp), %rdi
    c600:      	movl	$0x8, %esi
    c605:      	movq	%r15, %rdx
    c608:      	callq	*%rax
    c60a:      	movq	(%rsp), %r15
    c60e:      	movq	%r15, 0x40(%rsp)
    c613:      	leaq	0x20(%r15), %rdx
    c617:      	movq	%rdx, 0x38(%rsp)
    c61c:      	movq	0x30(%rsp), %r12
    c621:      	cmpq	0x18(%rsp), %r12
    c626:      	jne	0xc633 <generic_fentry_path+0x1353>
    c628:      	cmpq	0x20(%rsp), %rdx
    c62d:      	je	0x16d4d <generic_fentry_path+0xba6d>
    c633:      	movl	$0x4, %eax
    c638:      	leaq	0x10(%rsp), %rdi
    c63d:      	movl	$0x8, %esi
    c642:      	callq	*%rax
    c644:      	cmpq	0x10(%rsp), %r12
    c649:      	je	0xc741 <generic_fentry_path+0x1461>
    c64f:      	leaq	0x18(%r12), %rbx
    c654:      	movl	$0x4, %eax
    c659:      	movq	%rbp, %rdi
    c65c:      	movl	$0x8, %esi
    c661:      	movq	%rbx, %rdx
    c664:      	callq	*%rax
    c666:      	cmpq	%r12, (%rsp)
    c66a:      	je	0xc741 <generic_fentry_path+0x1461>
    c670:      	movl	$0x4, %eax
    c675:      	leaq	0x8(%rsp), %rdi
    c67a:      	movl	$0x8, %esi
    c67f:      	movq	%rbx, %rdx
    c682:      	callq	*%rax
    c684:      	addq	$0x20, %r12
    c688:      	movl	$0x4, %eax
    c68d:      	leaq	0x58(%rsp), %rdi
    c692:      	movl	$0x10, %ecx
    c697:      	movl	$0x10, %esi
    c69c:      	movq	%r12, %rdx
    c69f:      	callq	*%rax
    c6a1:      	movq	0x28(%rsp), %rbx
    c6a6:      	movq	0x48(%rsp), %rax
    c6ab:      	movl	0x5c(%rsp), %r15d
    c6b0:      	subq	%rbx, %rax
    c6b3:      	movl	0x50(%rsp), %r12d
    c6b8:      	movl	%r15d, %edx
    c6bb:      	subl	%r12d, %edx
    c6be:      	movl	$0x0, %ecx
    c6c3:      	cmovbl	%ecx, %edx
    c6c6:      	addq	0x60(%rsp), %rdx
    c6cb:      	xorl	%esi, %esi
    c6cd:      	cmpl	%r15d, %r12d
    c6d0:      	seta	%sil
    c6d4:      	movl	%r15d, %ecx
    c6d7:      	cmovbl	%r12d, %ecx
    c6db:      	addl	%ecx, %esi
    c6dd:      	movl	%r12d, %edi
    c6e0:      	subl	%esi, %edi
    c6e2:      	movl	%edi, 0x50(%rsp)
    c6e6:      	subq	%rsi, %rax
    c6e9:      	jb	0x16d52 <generic_fentry_path+0xba72>
    c6ef:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c6f5:      	ja	0x16d52 <generic_fentry_path+0xba72>
    c6fb:      	cmpl	%r15d, %r12d
    c6fe:      	jbe	0xc704 <generic_fentry_path+0x1424>
    c700:      	movb	$0x2f, (%rbx,%rax)
    c704:      	xorl	%edi, %edi
    c706:      	cmpl	%r15d, %r12d
    c709:      	seta	%dil
    c70d:      	movzbl	%cl, %esi
    c710:      	addq	%rax, %rbx
    c713:      	addq	%rbx, %rdi
    c716:      	movl	$0x4, %eax
    c71b:      	callq	*%rax
    c71d:      	movq	%rbx, 0x48(%rsp)
    c722:      	cmpl	%r15d, %r12d
    c725:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    c72b:      	movq	0x8(%rsp), %r12
    c730:      	movq	%r12, 0x30(%rsp)
    c735:      	movq	0x38(%rsp), %rdx
    c73a:      	movq	0x40(%rsp), %r15
    c73f:      	jmp	0xc792 <generic_fentry_path+0x14b2>
    c741:      	leaq	0x10(%r15), %rdx
    c745:      	movl	$0x4, %eax
    c74a:      	movq	%rbp, %rdi
    c74d:      	movl	$0x8, %esi
    c752:      	callq	*%rax
    c754:      	movq	0x40(%rsp), %rax
    c759:      	cmpq	(%rsp), %rax
    c75d:      	je	0x16d4d <generic_fentry_path+0xba6d>
    c763:      	addq	$0x18, %r15
    c767:      	movl	$0x4, %eax
    c76c:      	leaq	0x30(%rsp), %rdi
    c771:      	movl	$0x8, %esi
    c776:      	movq	%r15, %rdx
    c779:      	callq	*%rax
    c77b:      	movq	(%rsp), %r15
    c77f:      	movq	%r15, 0x40(%rsp)
    c784:      	leaq	0x20(%r15), %rdx
    c788:      	movq	%rdx, 0x38(%rsp)
    c78d:      	movq	0x30(%rsp), %r12
    c792:      	cmpq	0x18(%rsp), %r12
    c797:      	jne	0xc7a4 <generic_fentry_path+0x14c4>
    c799:      	cmpq	0x20(%rsp), %rdx
    c79e:      	je	0x16d4d <generic_fentry_path+0xba6d>
    c7a4:      	movl	$0x4, %eax
    c7a9:      	leaq	0x10(%rsp), %rdi
    c7ae:      	movl	$0x8, %esi
    c7b3:      	callq	*%rax
    c7b5:      	cmpq	0x10(%rsp), %r12
    c7ba:      	je	0xc8b2 <generic_fentry_path+0x15d2>
    c7c0:      	leaq	0x18(%r12), %rbx
    c7c5:      	movl	$0x4, %eax
    c7ca:      	movq	%rbp, %rdi
    c7cd:      	movl	$0x8, %esi
    c7d2:      	movq	%rbx, %rdx
    c7d5:      	callq	*%rax
    c7d7:      	cmpq	%r12, (%rsp)
    c7db:      	je	0xc8b2 <generic_fentry_path+0x15d2>
    c7e1:      	movl	$0x4, %eax
    c7e6:      	leaq	0x8(%rsp), %rdi
    c7eb:      	movl	$0x8, %esi
    c7f0:      	movq	%rbx, %rdx
    c7f3:      	callq	*%rax
    c7f5:      	addq	$0x20, %r12
    c7f9:      	movl	$0x4, %eax
    c7fe:      	leaq	0x58(%rsp), %rdi
    c803:      	movl	$0x10, %ecx
    c808:      	movl	$0x10, %esi
    c80d:      	movq	%r12, %rdx
    c810:      	callq	*%rax
    c812:      	movq	0x28(%rsp), %rbx
    c817:      	movq	0x48(%rsp), %rax
    c81c:      	movl	0x5c(%rsp), %r15d
    c821:      	subq	%rbx, %rax
    c824:      	movl	0x50(%rsp), %r12d
    c829:      	movl	%r15d, %edx
    c82c:      	subl	%r12d, %edx
    c82f:      	movl	$0x0, %ecx
    c834:      	cmovbl	%ecx, %edx
    c837:      	addq	0x60(%rsp), %rdx
    c83c:      	xorl	%esi, %esi
    c83e:      	cmpl	%r15d, %r12d
    c841:      	seta	%sil
    c845:      	movl	%r15d, %ecx
    c848:      	cmovbl	%r12d, %ecx
    c84c:      	addl	%ecx, %esi
    c84e:      	movl	%r12d, %edi
    c851:      	subl	%esi, %edi
    c853:      	movl	%edi, 0x50(%rsp)
    c857:      	subq	%rsi, %rax
    c85a:      	jb	0x16d52 <generic_fentry_path+0xba72>
    c860:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c866:      	ja	0x16d52 <generic_fentry_path+0xba72>
    c86c:      	cmpl	%r15d, %r12d
    c86f:      	jbe	0xc875 <generic_fentry_path+0x1595>
    c871:      	movb	$0x2f, (%rbx,%rax)
    c875:      	xorl	%edi, %edi
    c877:      	cmpl	%r15d, %r12d
    c87a:      	seta	%dil
    c87e:      	movzbl	%cl, %esi
    c881:      	addq	%rax, %rbx
    c884:      	addq	%rbx, %rdi
    c887:      	movl	$0x4, %eax
    c88c:      	callq	*%rax
    c88e:      	movq	%rbx, 0x48(%rsp)
    c893:      	cmpl	%r15d, %r12d
    c896:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    c89c:      	movq	0x8(%rsp), %r12
    c8a1:      	movq	%r12, 0x30(%rsp)
    c8a6:      	movq	0x38(%rsp), %rdx
    c8ab:      	movq	0x40(%rsp), %r15
    c8b0:      	jmp	0xc903 <generic_fentry_path+0x1623>
    c8b2:      	leaq	0x10(%r15), %rdx
    c8b6:      	movl	$0x4, %eax
    c8bb:      	movq	%rbp, %rdi
    c8be:      	movl	$0x8, %esi
    c8c3:      	callq	*%rax
    c8c5:      	movq	0x40(%rsp), %rax
    c8ca:      	cmpq	(%rsp), %rax
    c8ce:      	je	0x16d4d <generic_fentry_path+0xba6d>
    c8d4:      	addq	$0x18, %r15
    c8d8:      	movl	$0x4, %eax
    c8dd:      	leaq	0x30(%rsp), %rdi
    c8e2:      	movl	$0x8, %esi
    c8e7:      	movq	%r15, %rdx
    c8ea:      	callq	*%rax
    c8ec:      	movq	(%rsp), %r15
    c8f0:      	movq	%r15, 0x40(%rsp)
    c8f5:      	leaq	0x20(%r15), %rdx
    c8f9:      	movq	%rdx, 0x38(%rsp)
    c8fe:      	movq	0x30(%rsp), %r12
    c903:      	cmpq	0x18(%rsp), %r12
    c908:      	jne	0xc915 <generic_fentry_path+0x1635>
    c90a:      	cmpq	0x20(%rsp), %rdx
    c90f:      	je	0x16d4d <generic_fentry_path+0xba6d>
    c915:      	movl	$0x4, %eax
    c91a:      	leaq	0x10(%rsp), %rdi
    c91f:      	movl	$0x8, %esi
    c924:      	callq	*%rax
    c926:      	cmpq	0x10(%rsp), %r12
    c92b:      	je	0xca23 <generic_fentry_path+0x1743>
    c931:      	leaq	0x18(%r12), %rbx
    c936:      	movl	$0x4, %eax
    c93b:      	movq	%rbp, %rdi
    c93e:      	movl	$0x8, %esi
    c943:      	movq	%rbx, %rdx
    c946:      	callq	*%rax
    c948:      	cmpq	%r12, (%rsp)
    c94c:      	je	0xca23 <generic_fentry_path+0x1743>
    c952:      	movl	$0x4, %eax
    c957:      	leaq	0x8(%rsp), %rdi
    c95c:      	movl	$0x8, %esi
    c961:      	movq	%rbx, %rdx
    c964:      	callq	*%rax
    c966:      	addq	$0x20, %r12
    c96a:      	movl	$0x4, %eax
    c96f:      	leaq	0x58(%rsp), %rdi
    c974:      	movl	$0x10, %ecx
    c979:      	movl	$0x10, %esi
    c97e:      	movq	%r12, %rdx
    c981:      	callq	*%rax
    c983:      	movq	0x28(%rsp), %rbx
    c988:      	movq	0x48(%rsp), %rax
    c98d:      	movl	0x5c(%rsp), %r15d
    c992:      	subq	%rbx, %rax
    c995:      	movl	0x50(%rsp), %r12d
    c99a:      	movl	%r15d, %edx
    c99d:      	subl	%r12d, %edx
    c9a0:      	movl	$0x0, %ecx
    c9a5:      	cmovbl	%ecx, %edx
    c9a8:      	addq	0x60(%rsp), %rdx
    c9ad:      	xorl	%esi, %esi
    c9af:      	cmpl	%r15d, %r12d
    c9b2:      	seta	%sil
    c9b6:      	movl	%r15d, %ecx
    c9b9:      	cmovbl	%r12d, %ecx
    c9bd:      	addl	%ecx, %esi
    c9bf:      	movl	%r12d, %edi
    c9c2:      	subl	%esi, %edi
    c9c4:      	movl	%edi, 0x50(%rsp)
    c9c8:      	subq	%rsi, %rax
    c9cb:      	jb	0x16d52 <generic_fentry_path+0xba72>
    c9d1:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c9d7:      	ja	0x16d52 <generic_fentry_path+0xba72>
    c9dd:      	cmpl	%r15d, %r12d
    c9e0:      	jbe	0xc9e6 <generic_fentry_path+0x1706>
    c9e2:      	movb	$0x2f, (%rbx,%rax)
    c9e6:      	xorl	%edi, %edi
    c9e8:      	cmpl	%r15d, %r12d
    c9eb:      	seta	%dil
    c9ef:      	movzbl	%cl, %esi
    c9f2:      	addq	%rax, %rbx
    c9f5:      	addq	%rbx, %rdi
    c9f8:      	movl	$0x4, %eax
    c9fd:      	callq	*%rax
    c9ff:      	movq	%rbx, 0x48(%rsp)
    ca04:      	cmpl	%r15d, %r12d
    ca07:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    ca0d:      	movq	0x8(%rsp), %r12
    ca12:      	movq	%r12, 0x30(%rsp)
    ca17:      	movq	0x38(%rsp), %rdx
    ca1c:      	movq	0x40(%rsp), %r15
    ca21:      	jmp	0xca74 <generic_fentry_path+0x1794>
    ca23:      	leaq	0x10(%r15), %rdx
    ca27:      	movl	$0x4, %eax
    ca2c:      	movq	%rbp, %rdi
    ca2f:      	movl	$0x8, %esi
    ca34:      	callq	*%rax
    ca36:      	movq	0x40(%rsp), %rax
    ca3b:      	cmpq	(%rsp), %rax
    ca3f:      	je	0x16d4d <generic_fentry_path+0xba6d>
    ca45:      	addq	$0x18, %r15
    ca49:      	movl	$0x4, %eax
    ca4e:      	leaq	0x30(%rsp), %rdi
    ca53:      	movl	$0x8, %esi
    ca58:      	movq	%r15, %rdx
    ca5b:      	callq	*%rax
    ca5d:      	movq	(%rsp), %r15
    ca61:      	movq	%r15, 0x40(%rsp)
    ca66:      	leaq	0x20(%r15), %rdx
    ca6a:      	movq	%rdx, 0x38(%rsp)
    ca6f:      	movq	0x30(%rsp), %r12
    ca74:      	cmpq	0x18(%rsp), %r12
    ca79:      	jne	0xca86 <generic_fentry_path+0x17a6>
    ca7b:      	cmpq	0x20(%rsp), %rdx
    ca80:      	je	0x16d4d <generic_fentry_path+0xba6d>
    ca86:      	movl	$0x4, %eax
    ca8b:      	leaq	0x10(%rsp), %rdi
    ca90:      	movl	$0x8, %esi
    ca95:      	callq	*%rax
    ca97:      	cmpq	0x10(%rsp), %r12
    ca9c:      	je	0xcb94 <generic_fentry_path+0x18b4>
    caa2:      	leaq	0x18(%r12), %rbx
    caa7:      	movl	$0x4, %eax
    caac:      	movq	%rbp, %rdi
    caaf:      	movl	$0x8, %esi
    cab4:      	movq	%rbx, %rdx
    cab7:      	callq	*%rax
    cab9:      	cmpq	%r12, (%rsp)
    cabd:      	je	0xcb94 <generic_fentry_path+0x18b4>
    cac3:      	movl	$0x4, %eax
    cac8:      	leaq	0x8(%rsp), %rdi
    cacd:      	movl	$0x8, %esi
    cad2:      	movq	%rbx, %rdx
    cad5:      	callq	*%rax
    cad7:      	addq	$0x20, %r12
    cadb:      	movl	$0x4, %eax
    cae0:      	leaq	0x58(%rsp), %rdi
    cae5:      	movl	$0x10, %ecx
    caea:      	movl	$0x10, %esi
    caef:      	movq	%r12, %rdx
    caf2:      	callq	*%rax
    caf4:      	movq	0x28(%rsp), %rbx
    caf9:      	movq	0x48(%rsp), %rax
    cafe:      	movl	0x5c(%rsp), %r15d
    cb03:      	subq	%rbx, %rax
    cb06:      	movl	0x50(%rsp), %r12d
    cb0b:      	movl	%r15d, %edx
    cb0e:      	subl	%r12d, %edx
    cb11:      	movl	$0x0, %ecx
    cb16:      	cmovbl	%ecx, %edx
    cb19:      	addq	0x60(%rsp), %rdx
    cb1e:      	xorl	%esi, %esi
    cb20:      	cmpl	%r15d, %r12d
    cb23:      	seta	%sil
    cb27:      	movl	%r15d, %ecx
    cb2a:      	cmovbl	%r12d, %ecx
    cb2e:      	addl	%ecx, %esi
    cb30:      	movl	%r12d, %edi
    cb33:      	subl	%esi, %edi
    cb35:      	movl	%edi, 0x50(%rsp)
    cb39:      	subq	%rsi, %rax
    cb3c:      	jb	0x16d52 <generic_fentry_path+0xba72>
    cb42:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    cb48:      	ja	0x16d52 <generic_fentry_path+0xba72>
    cb4e:      	cmpl	%r15d, %r12d
    cb51:      	jbe	0xcb57 <generic_fentry_path+0x1877>
    cb53:      	movb	$0x2f, (%rbx,%rax)
    cb57:      	xorl	%edi, %edi
    cb59:      	cmpl	%r15d, %r12d
    cb5c:      	seta	%dil
    cb60:      	movzbl	%cl, %esi
    cb63:      	addq	%rax, %rbx
    cb66:      	addq	%rbx, %rdi
    cb69:      	movl	$0x4, %eax
    cb6e:      	callq	*%rax
    cb70:      	movq	%rbx, 0x48(%rsp)
    cb75:      	cmpl	%r15d, %r12d
    cb78:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    cb7e:      	movq	0x8(%rsp), %r12
    cb83:      	movq	%r12, 0x30(%rsp)
    cb88:      	movq	0x38(%rsp), %rdx
    cb8d:      	movq	0x40(%rsp), %r15
    cb92:      	jmp	0xcbe5 <generic_fentry_path+0x1905>
    cb94:      	leaq	0x10(%r15), %rdx
    cb98:      	movl	$0x4, %eax
    cb9d:      	movq	%rbp, %rdi
    cba0:      	movl	$0x8, %esi
    cba5:      	callq	*%rax
    cba7:      	movq	0x40(%rsp), %rax
    cbac:      	cmpq	(%rsp), %rax
    cbb0:      	je	0x16d4d <generic_fentry_path+0xba6d>
    cbb6:      	addq	$0x18, %r15
    cbba:      	movl	$0x4, %eax
    cbbf:      	leaq	0x30(%rsp), %rdi
    cbc4:      	movl	$0x8, %esi
    cbc9:      	movq	%r15, %rdx
    cbcc:      	callq	*%rax
    cbce:      	movq	(%rsp), %r15
    cbd2:      	movq	%r15, 0x40(%rsp)
    cbd7:      	leaq	0x20(%r15), %rdx
    cbdb:      	movq	%rdx, 0x38(%rsp)
    cbe0:      	movq	0x30(%rsp), %r12
    cbe5:      	cmpq	0x18(%rsp), %r12
    cbea:      	jne	0xcbf7 <generic_fentry_path+0x1917>
    cbec:      	cmpq	0x20(%rsp), %rdx
    cbf1:      	je	0x16d4d <generic_fentry_path+0xba6d>
    cbf7:      	movl	$0x4, %eax
    cbfc:      	leaq	0x10(%rsp), %rdi
    cc01:      	movl	$0x8, %esi
    cc06:      	callq	*%rax
    cc08:      	cmpq	0x10(%rsp), %r12
    cc0d:      	je	0xcd05 <generic_fentry_path+0x1a25>
    cc13:      	leaq	0x18(%r12), %rbx
    cc18:      	movl	$0x4, %eax
    cc1d:      	movq	%rbp, %rdi
    cc20:      	movl	$0x8, %esi
    cc25:      	movq	%rbx, %rdx
    cc28:      	callq	*%rax
    cc2a:      	cmpq	%r12, (%rsp)
    cc2e:      	je	0xcd05 <generic_fentry_path+0x1a25>
    cc34:      	movl	$0x4, %eax
    cc39:      	leaq	0x8(%rsp), %rdi
    cc3e:      	movl	$0x8, %esi
    cc43:      	movq	%rbx, %rdx
    cc46:      	callq	*%rax
    cc48:      	addq	$0x20, %r12
    cc4c:      	movl	$0x4, %eax
    cc51:      	leaq	0x58(%rsp), %rdi
    cc56:      	movl	$0x10, %ecx
    cc5b:      	movl	$0x10, %esi
    cc60:      	movq	%r12, %rdx
    cc63:      	callq	*%rax
    cc65:      	movq	0x28(%rsp), %rbx
    cc6a:      	movq	0x48(%rsp), %rax
    cc6f:      	movl	0x5c(%rsp), %r15d
    cc74:      	subq	%rbx, %rax
    cc77:      	movl	0x50(%rsp), %r12d
    cc7c:      	movl	%r15d, %edx
    cc7f:      	subl	%r12d, %edx
    cc82:      	movl	$0x0, %ecx
    cc87:      	cmovbl	%ecx, %edx
    cc8a:      	addq	0x60(%rsp), %rdx
    cc8f:      	xorl	%esi, %esi
    cc91:      	cmpl	%r15d, %r12d
    cc94:      	seta	%sil
    cc98:      	movl	%r15d, %ecx
    cc9b:      	cmovbl	%r12d, %ecx
    cc9f:      	addl	%ecx, %esi
    cca1:      	movl	%r12d, %edi
    cca4:      	subl	%esi, %edi
    cca6:      	movl	%edi, 0x50(%rsp)
    ccaa:      	subq	%rsi, %rax
    ccad:      	jb	0x16d52 <generic_fentry_path+0xba72>
    ccb3:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ccb9:      	ja	0x16d52 <generic_fentry_path+0xba72>
    ccbf:      	cmpl	%r15d, %r12d
    ccc2:      	jbe	0xccc8 <generic_fentry_path+0x19e8>
    ccc4:      	movb	$0x2f, (%rbx,%rax)
    ccc8:      	xorl	%edi, %edi
    ccca:      	cmpl	%r15d, %r12d
    cccd:      	seta	%dil
    ccd1:      	movzbl	%cl, %esi
    ccd4:      	addq	%rax, %rbx
    ccd7:      	addq	%rbx, %rdi
    ccda:      	movl	$0x4, %eax
    ccdf:      	callq	*%rax
    cce1:      	movq	%rbx, 0x48(%rsp)
    cce6:      	cmpl	%r15d, %r12d
    cce9:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    ccef:      	movq	0x8(%rsp), %r12
    ccf4:      	movq	%r12, 0x30(%rsp)
    ccf9:      	movq	0x38(%rsp), %rdx
    ccfe:      	movq	0x40(%rsp), %r15
    cd03:      	jmp	0xcd56 <generic_fentry_path+0x1a76>
    cd05:      	leaq	0x10(%r15), %rdx
    cd09:      	movl	$0x4, %eax
    cd0e:      	movq	%rbp, %rdi
    cd11:      	movl	$0x8, %esi
    cd16:      	callq	*%rax
    cd18:      	movq	0x40(%rsp), %rax
    cd1d:      	cmpq	(%rsp), %rax
    cd21:      	je	0x16d4d <generic_fentry_path+0xba6d>
    cd27:      	addq	$0x18, %r15
    cd2b:      	movl	$0x4, %eax
    cd30:      	leaq	0x30(%rsp), %rdi
    cd35:      	movl	$0x8, %esi
    cd3a:      	movq	%r15, %rdx
    cd3d:      	callq	*%rax
    cd3f:      	movq	(%rsp), %r15
    cd43:      	movq	%r15, 0x40(%rsp)
    cd48:      	leaq	0x20(%r15), %rdx
    cd4c:      	movq	%rdx, 0x38(%rsp)
    cd51:      	movq	0x30(%rsp), %r12
    cd56:      	cmpq	0x18(%rsp), %r12
    cd5b:      	jne	0xcd68 <generic_fentry_path+0x1a88>
    cd5d:      	cmpq	0x20(%rsp), %rdx
    cd62:      	je	0x16d4d <generic_fentry_path+0xba6d>
    cd68:      	movl	$0x4, %eax
    cd6d:      	leaq	0x10(%rsp), %rdi
    cd72:      	movl	$0x8, %esi
    cd77:      	callq	*%rax
    cd79:      	cmpq	0x10(%rsp), %r12
    cd7e:      	je	0xce76 <generic_fentry_path+0x1b96>
    cd84:      	leaq	0x18(%r12), %rbx
    cd89:      	movl	$0x4, %eax
    cd8e:      	movq	%rbp, %rdi
    cd91:      	movl	$0x8, %esi
    cd96:      	movq	%rbx, %rdx
    cd99:      	callq	*%rax
    cd9b:      	cmpq	%r12, (%rsp)
    cd9f:      	je	0xce76 <generic_fentry_path+0x1b96>
    cda5:      	movl	$0x4, %eax
    cdaa:      	leaq	0x8(%rsp), %rdi
    cdaf:      	movl	$0x8, %esi
    cdb4:      	movq	%rbx, %rdx
    cdb7:      	callq	*%rax
    cdb9:      	addq	$0x20, %r12
    cdbd:      	movl	$0x4, %eax
    cdc2:      	leaq	0x58(%rsp), %rdi
    cdc7:      	movl	$0x10, %ecx
    cdcc:      	movl	$0x10, %esi
    cdd1:      	movq	%r12, %rdx
    cdd4:      	callq	*%rax
    cdd6:      	movq	0x28(%rsp), %rbx
    cddb:      	movq	0x48(%rsp), %rax
    cde0:      	movl	0x5c(%rsp), %r15d
    cde5:      	subq	%rbx, %rax
    cde8:      	movl	0x50(%rsp), %r12d
    cded:      	movl	%r15d, %edx
    cdf0:      	subl	%r12d, %edx
    cdf3:      	movl	$0x0, %ecx
    cdf8:      	cmovbl	%ecx, %edx
    cdfb:      	addq	0x60(%rsp), %rdx
    ce00:      	xorl	%esi, %esi
    ce02:      	cmpl	%r15d, %r12d
    ce05:      	seta	%sil
    ce09:      	movl	%r15d, %ecx
    ce0c:      	cmovbl	%r12d, %ecx
    ce10:      	addl	%ecx, %esi
    ce12:      	movl	%r12d, %edi
    ce15:      	subl	%esi, %edi
    ce17:      	movl	%edi, 0x50(%rsp)
    ce1b:      	subq	%rsi, %rax
    ce1e:      	jb	0x16d52 <generic_fentry_path+0xba72>
    ce24:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ce2a:      	ja	0x16d52 <generic_fentry_path+0xba72>
    ce30:      	cmpl	%r15d, %r12d
    ce33:      	jbe	0xce39 <generic_fentry_path+0x1b59>
    ce35:      	movb	$0x2f, (%rbx,%rax)
    ce39:      	xorl	%edi, %edi
    ce3b:      	cmpl	%r15d, %r12d
    ce3e:      	seta	%dil
    ce42:      	movzbl	%cl, %esi
    ce45:      	addq	%rax, %rbx
    ce48:      	addq	%rbx, %rdi
    ce4b:      	movl	$0x4, %eax
    ce50:      	callq	*%rax
    ce52:      	movq	%rbx, 0x48(%rsp)
    ce57:      	cmpl	%r15d, %r12d
    ce5a:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    ce60:      	movq	0x8(%rsp), %r12
    ce65:      	movq	%r12, 0x30(%rsp)
    ce6a:      	movq	0x38(%rsp), %rdx
    ce6f:      	movq	0x40(%rsp), %r15
    ce74:      	jmp	0xcec7 <generic_fentry_path+0x1be7>
    ce76:      	leaq	0x10(%r15), %rdx
    ce7a:      	movl	$0x4, %eax
    ce7f:      	movq	%rbp, %rdi
    ce82:      	movl	$0x8, %esi
    ce87:      	callq	*%rax
    ce89:      	movq	0x40(%rsp), %rax
    ce8e:      	cmpq	(%rsp), %rax
    ce92:      	je	0x16d4d <generic_fentry_path+0xba6d>
    ce98:      	addq	$0x18, %r15
    ce9c:      	movl	$0x4, %eax
    cea1:      	leaq	0x30(%rsp), %rdi
    cea6:      	movl	$0x8, %esi
    ceab:      	movq	%r15, %rdx
    ceae:      	callq	*%rax
    ceb0:      	movq	(%rsp), %r15
    ceb4:      	movq	%r15, 0x40(%rsp)
    ceb9:      	leaq	0x20(%r15), %rdx
    cebd:      	movq	%rdx, 0x38(%rsp)
    cec2:      	movq	0x30(%rsp), %r12
    cec7:      	cmpq	0x18(%rsp), %r12
    cecc:      	jne	0xced9 <generic_fentry_path+0x1bf9>
    cece:      	cmpq	0x20(%rsp), %rdx
    ced3:      	je	0x16d4d <generic_fentry_path+0xba6d>
    ced9:      	movl	$0x4, %eax
    cede:      	leaq	0x10(%rsp), %rdi
    cee3:      	movl	$0x8, %esi
    cee8:      	callq	*%rax
    ceea:      	cmpq	0x10(%rsp), %r12
    ceef:      	je	0xcfe7 <generic_fentry_path+0x1d07>
    cef5:      	leaq	0x18(%r12), %rbx
    cefa:      	movl	$0x4, %eax
    ceff:      	movq	%rbp, %rdi
    cf02:      	movl	$0x8, %esi
    cf07:      	movq	%rbx, %rdx
    cf0a:      	callq	*%rax
    cf0c:      	cmpq	%r12, (%rsp)
    cf10:      	je	0xcfe7 <generic_fentry_path+0x1d07>
    cf16:      	movl	$0x4, %eax
    cf1b:      	leaq	0x8(%rsp), %rdi
    cf20:      	movl	$0x8, %esi
    cf25:      	movq	%rbx, %rdx
    cf28:      	callq	*%rax
    cf2a:      	addq	$0x20, %r12
    cf2e:      	movl	$0x4, %eax
    cf33:      	leaq	0x58(%rsp), %rdi
    cf38:      	movl	$0x10, %ecx
    cf3d:      	movl	$0x10, %esi
    cf42:      	movq	%r12, %rdx
    cf45:      	callq	*%rax
    cf47:      	movq	0x28(%rsp), %rbx
    cf4c:      	movq	0x48(%rsp), %rax
    cf51:      	movl	0x5c(%rsp), %r15d
    cf56:      	subq	%rbx, %rax
    cf59:      	movl	0x50(%rsp), %r12d
    cf5e:      	movl	%r15d, %edx
    cf61:      	subl	%r12d, %edx
    cf64:      	movl	$0x0, %ecx
    cf69:      	cmovbl	%ecx, %edx
    cf6c:      	addq	0x60(%rsp), %rdx
    cf71:      	xorl	%esi, %esi
    cf73:      	cmpl	%r15d, %r12d
    cf76:      	seta	%sil
    cf7a:      	movl	%r15d, %ecx
    cf7d:      	cmovbl	%r12d, %ecx
    cf81:      	addl	%ecx, %esi
    cf83:      	movl	%r12d, %edi
    cf86:      	subl	%esi, %edi
    cf88:      	movl	%edi, 0x50(%rsp)
    cf8c:      	subq	%rsi, %rax
    cf8f:      	jb	0x16d52 <generic_fentry_path+0xba72>
    cf95:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    cf9b:      	ja	0x16d52 <generic_fentry_path+0xba72>
    cfa1:      	cmpl	%r15d, %r12d
    cfa4:      	jbe	0xcfaa <generic_fentry_path+0x1cca>
    cfa6:      	movb	$0x2f, (%rbx,%rax)
    cfaa:      	xorl	%edi, %edi
    cfac:      	cmpl	%r15d, %r12d
    cfaf:      	seta	%dil
    cfb3:      	movzbl	%cl, %esi
    cfb6:      	addq	%rax, %rbx
    cfb9:      	addq	%rbx, %rdi
    cfbc:      	movl	$0x4, %eax
    cfc1:      	callq	*%rax
    cfc3:      	movq	%rbx, 0x48(%rsp)
    cfc8:      	cmpl	%r15d, %r12d
    cfcb:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    cfd1:      	movq	0x8(%rsp), %r12
    cfd6:      	movq	%r12, 0x30(%rsp)
    cfdb:      	movq	0x38(%rsp), %rdx
    cfe0:      	movq	0x40(%rsp), %r15
    cfe5:      	jmp	0xd038 <generic_fentry_path+0x1d58>
    cfe7:      	leaq	0x10(%r15), %rdx
    cfeb:      	movl	$0x4, %eax
    cff0:      	movq	%rbp, %rdi
    cff3:      	movl	$0x8, %esi
    cff8:      	callq	*%rax
    cffa:      	movq	0x40(%rsp), %rax
    cfff:      	cmpq	(%rsp), %rax
    d003:      	je	0x16d4d <generic_fentry_path+0xba6d>
    d009:      	addq	$0x18, %r15
    d00d:      	movl	$0x4, %eax
    d012:      	leaq	0x30(%rsp), %rdi
    d017:      	movl	$0x8, %esi
    d01c:      	movq	%r15, %rdx
    d01f:      	callq	*%rax
    d021:      	movq	(%rsp), %r15
    d025:      	movq	%r15, 0x40(%rsp)
    d02a:      	leaq	0x20(%r15), %rdx
    d02e:      	movq	%rdx, 0x38(%rsp)
    d033:      	movq	0x30(%rsp), %r12
    d038:      	cmpq	0x18(%rsp), %r12
    d03d:      	jne	0xd04a <generic_fentry_path+0x1d6a>
    d03f:      	cmpq	0x20(%rsp), %rdx
    d044:      	je	0x16d4d <generic_fentry_path+0xba6d>
    d04a:      	movl	$0x4, %eax
    d04f:      	leaq	0x10(%rsp), %rdi
    d054:      	movl	$0x8, %esi
    d059:      	callq	*%rax
    d05b:      	cmpq	0x10(%rsp), %r12
    d060:      	je	0xd158 <generic_fentry_path+0x1e78>
    d066:      	leaq	0x18(%r12), %rbx
    d06b:      	movl	$0x4, %eax
    d070:      	movq	%rbp, %rdi
    d073:      	movl	$0x8, %esi
    d078:      	movq	%rbx, %rdx
    d07b:      	callq	*%rax
    d07d:      	cmpq	%r12, (%rsp)
    d081:      	je	0xd158 <generic_fentry_path+0x1e78>
    d087:      	movl	$0x4, %eax
    d08c:      	leaq	0x8(%rsp), %rdi
    d091:      	movl	$0x8, %esi
    d096:      	movq	%rbx, %rdx
    d099:      	callq	*%rax
    d09b:      	addq	$0x20, %r12
    d09f:      	movl	$0x4, %eax
    d0a4:      	leaq	0x58(%rsp), %rdi
    d0a9:      	movl	$0x10, %ecx
    d0ae:      	movl	$0x10, %esi
    d0b3:      	movq	%r12, %rdx
    d0b6:      	callq	*%rax
    d0b8:      	movq	0x28(%rsp), %rbx
    d0bd:      	movq	0x48(%rsp), %rax
    d0c2:      	movl	0x5c(%rsp), %r15d
    d0c7:      	subq	%rbx, %rax
    d0ca:      	movl	0x50(%rsp), %r12d
    d0cf:      	movl	%r15d, %edx
    d0d2:      	subl	%r12d, %edx
    d0d5:      	movl	$0x0, %ecx
    d0da:      	cmovbl	%ecx, %edx
    d0dd:      	addq	0x60(%rsp), %rdx
    d0e2:      	xorl	%esi, %esi
    d0e4:      	cmpl	%r15d, %r12d
    d0e7:      	seta	%sil
    d0eb:      	movl	%r15d, %ecx
    d0ee:      	cmovbl	%r12d, %ecx
    d0f2:      	addl	%ecx, %esi
    d0f4:      	movl	%r12d, %edi
    d0f7:      	subl	%esi, %edi
    d0f9:      	movl	%edi, 0x50(%rsp)
    d0fd:      	subq	%rsi, %rax
    d100:      	jb	0x16d52 <generic_fentry_path+0xba72>
    d106:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d10c:      	ja	0x16d52 <generic_fentry_path+0xba72>
    d112:      	cmpl	%r15d, %r12d
    d115:      	jbe	0xd11b <generic_fentry_path+0x1e3b>
    d117:      	movb	$0x2f, (%rbx,%rax)
    d11b:      	xorl	%edi, %edi
    d11d:      	cmpl	%r15d, %r12d
    d120:      	seta	%dil
    d124:      	movzbl	%cl, %esi
    d127:      	addq	%rax, %rbx
    d12a:      	addq	%rbx, %rdi
    d12d:      	movl	$0x4, %eax
    d132:      	callq	*%rax
    d134:      	movq	%rbx, 0x48(%rsp)
    d139:      	cmpl	%r15d, %r12d
    d13c:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    d142:      	movq	0x8(%rsp), %r12
    d147:      	movq	%r12, 0x30(%rsp)
    d14c:      	movq	0x38(%rsp), %rdx
    d151:      	movq	0x40(%rsp), %r15
    d156:      	jmp	0xd1a9 <generic_fentry_path+0x1ec9>
    d158:      	leaq	0x10(%r15), %rdx
    d15c:      	movl	$0x4, %eax
    d161:      	movq	%rbp, %rdi
    d164:      	movl	$0x8, %esi
    d169:      	callq	*%rax
    d16b:      	movq	0x40(%rsp), %rax
    d170:      	cmpq	(%rsp), %rax
    d174:      	je	0x16d4d <generic_fentry_path+0xba6d>
    d17a:      	addq	$0x18, %r15
    d17e:      	movl	$0x4, %eax
    d183:      	leaq	0x30(%rsp), %rdi
    d188:      	movl	$0x8, %esi
    d18d:      	movq	%r15, %rdx
    d190:      	callq	*%rax
    d192:      	movq	(%rsp), %r15
    d196:      	movq	%r15, 0x40(%rsp)
    d19b:      	leaq	0x20(%r15), %rdx
    d19f:      	movq	%rdx, 0x38(%rsp)
    d1a4:      	movq	0x30(%rsp), %r12
    d1a9:      	cmpq	0x18(%rsp), %r12
    d1ae:      	jne	0xd1bb <generic_fentry_path+0x1edb>
    d1b0:      	cmpq	0x20(%rsp), %rdx
    d1b5:      	je	0x16d4d <generic_fentry_path+0xba6d>
    d1bb:      	movl	$0x4, %eax
    d1c0:      	leaq	0x10(%rsp), %rdi
    d1c5:      	movl	$0x8, %esi
    d1ca:      	callq	*%rax
    d1cc:      	cmpq	0x10(%rsp), %r12
    d1d1:      	je	0xd2c9 <generic_fentry_path+0x1fe9>
    d1d7:      	leaq	0x18(%r12), %rbx
    d1dc:      	movl	$0x4, %eax
    d1e1:      	movq	%rbp, %rdi
    d1e4:      	movl	$0x8, %esi
    d1e9:      	movq	%rbx, %rdx
    d1ec:      	callq	*%rax
    d1ee:      	cmpq	%r12, (%rsp)
    d1f2:      	je	0xd2c9 <generic_fentry_path+0x1fe9>
    d1f8:      	movl	$0x4, %eax
    d1fd:      	leaq	0x8(%rsp), %rdi
    d202:      	movl	$0x8, %esi
    d207:      	movq	%rbx, %rdx
    d20a:      	callq	*%rax
    d20c:      	addq	$0x20, %r12
    d210:      	movl	$0x4, %eax
    d215:      	leaq	0x58(%rsp), %rdi
    d21a:      	movl	$0x10, %ecx
    d21f:      	movl	$0x10, %esi
    d224:      	movq	%r12, %rdx
    d227:      	callq	*%rax
    d229:      	movq	0x28(%rsp), %rbx
    d22e:      	movq	0x48(%rsp), %rax
    d233:      	movl	0x5c(%rsp), %r15d
    d238:      	subq	%rbx, %rax
    d23b:      	movl	0x50(%rsp), %r12d
    d240:      	movl	%r15d, %edx
    d243:      	subl	%r12d, %edx
    d246:      	movl	$0x0, %ecx
    d24b:      	cmovbl	%ecx, %edx
    d24e:      	addq	0x60(%rsp), %rdx
    d253:      	xorl	%esi, %esi
    d255:      	cmpl	%r15d, %r12d
    d258:      	seta	%sil
    d25c:      	movl	%r15d, %ecx
    d25f:      	cmovbl	%r12d, %ecx
    d263:      	addl	%ecx, %esi
    d265:      	movl	%r12d, %edi
    d268:      	subl	%esi, %edi
    d26a:      	movl	%edi, 0x50(%rsp)
    d26e:      	subq	%rsi, %rax
    d271:      	jb	0x16d52 <generic_fentry_path+0xba72>
    d277:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d27d:      	ja	0x16d52 <generic_fentry_path+0xba72>
    d283:      	cmpl	%r15d, %r12d
    d286:      	jbe	0xd28c <generic_fentry_path+0x1fac>
    d288:      	movb	$0x2f, (%rbx,%rax)
    d28c:      	xorl	%edi, %edi
    d28e:      	cmpl	%r15d, %r12d
    d291:      	seta	%dil
    d295:      	movzbl	%cl, %esi
    d298:      	addq	%rax, %rbx
    d29b:      	addq	%rbx, %rdi
    d29e:      	movl	$0x4, %eax
    d2a3:      	callq	*%rax
    d2a5:      	movq	%rbx, 0x48(%rsp)
    d2aa:      	cmpl	%r15d, %r12d
    d2ad:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    d2b3:      	movq	0x8(%rsp), %r12
    d2b8:      	movq	%r12, 0x30(%rsp)
    d2bd:      	movq	0x38(%rsp), %rdx
    d2c2:      	movq	0x40(%rsp), %r15
    d2c7:      	jmp	0xd31a <generic_fentry_path+0x203a>
    d2c9:      	leaq	0x10(%r15), %rdx
    d2cd:      	movl	$0x4, %eax
    d2d2:      	movq	%rbp, %rdi
    d2d5:      	movl	$0x8, %esi
    d2da:      	callq	*%rax
    d2dc:      	movq	0x40(%rsp), %rax
    d2e1:      	cmpq	(%rsp), %rax
    d2e5:      	je	0x16d4d <generic_fentry_path+0xba6d>
    d2eb:      	addq	$0x18, %r15
    d2ef:      	movl	$0x4, %eax
    d2f4:      	leaq	0x30(%rsp), %rdi
    d2f9:      	movl	$0x8, %esi
    d2fe:      	movq	%r15, %rdx
    d301:      	callq	*%rax
    d303:      	movq	(%rsp), %r15
    d307:      	movq	%r15, 0x40(%rsp)
    d30c:      	leaq	0x20(%r15), %rdx
    d310:      	movq	%rdx, 0x38(%rsp)
    d315:      	movq	0x30(%rsp), %r12
    d31a:      	cmpq	0x18(%rsp), %r12
    d31f:      	jne	0xd32c <generic_fentry_path+0x204c>
    d321:      	cmpq	0x20(%rsp), %rdx
    d326:      	je	0x16d4d <generic_fentry_path+0xba6d>
    d32c:      	movl	$0x4, %eax
    d331:      	leaq	0x10(%rsp), %rdi
    d336:      	movl	$0x8, %esi
    d33b:      	callq	*%rax
    d33d:      	cmpq	0x10(%rsp), %r12
    d342:      	je	0xd43a <generic_fentry_path+0x215a>
    d348:      	leaq	0x18(%r12), %rbx
    d34d:      	movl	$0x4, %eax
    d352:      	movq	%rbp, %rdi
    d355:      	movl	$0x8, %esi
    d35a:      	movq	%rbx, %rdx
    d35d:      	callq	*%rax
    d35f:      	cmpq	%r12, (%rsp)
    d363:      	je	0xd43a <generic_fentry_path+0x215a>
    d369:      	movl	$0x4, %eax
    d36e:      	leaq	0x8(%rsp), %rdi
    d373:      	movl	$0x8, %esi
    d378:      	movq	%rbx, %rdx
    d37b:      	callq	*%rax
    d37d:      	addq	$0x20, %r12
    d381:      	movl	$0x4, %eax
    d386:      	leaq	0x58(%rsp), %rdi
    d38b:      	movl	$0x10, %ecx
    d390:      	movl	$0x10, %esi
    d395:      	movq	%r12, %rdx
    d398:      	callq	*%rax
    d39a:      	movq	0x28(%rsp), %rbx
    d39f:      	movq	0x48(%rsp), %rax
    d3a4:      	movl	0x5c(%rsp), %r15d
    d3a9:      	subq	%rbx, %rax
    d3ac:      	movl	0x50(%rsp), %r12d
    d3b1:      	movl	%r15d, %edx
    d3b4:      	subl	%r12d, %edx
    d3b7:      	movl	$0x0, %ecx
    d3bc:      	cmovbl	%ecx, %edx
    d3bf:      	addq	0x60(%rsp), %rdx
    d3c4:      	xorl	%esi, %esi
    d3c6:      	cmpl	%r15d, %r12d
    d3c9:      	seta	%sil
    d3cd:      	movl	%r15d, %ecx
    d3d0:      	cmovbl	%r12d, %ecx
    d3d4:      	addl	%ecx, %esi
    d3d6:      	movl	%r12d, %edi
    d3d9:      	subl	%esi, %edi
    d3db:      	movl	%edi, 0x50(%rsp)
    d3df:      	subq	%rsi, %rax
    d3e2:      	jb	0x16d52 <generic_fentry_path+0xba72>
    d3e8:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d3ee:      	ja	0x16d52 <generic_fentry_path+0xba72>
    d3f4:      	cmpl	%r15d, %r12d
    d3f7:      	jbe	0xd3fd <generic_fentry_path+0x211d>
    d3f9:      	movb	$0x2f, (%rbx,%rax)
    d3fd:      	xorl	%edi, %edi
    d3ff:      	cmpl	%r15d, %r12d
    d402:      	seta	%dil
    d406:      	movzbl	%cl, %esi
    d409:      	addq	%rax, %rbx
    d40c:      	addq	%rbx, %rdi
    d40f:      	movl	$0x4, %eax
    d414:      	callq	*%rax
    d416:      	movq	%rbx, 0x48(%rsp)
    d41b:      	cmpl	%r15d, %r12d
    d41e:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    d424:      	movq	0x8(%rsp), %r12
    d429:      	movq	%r12, 0x30(%rsp)
    d42e:      	movq	0x38(%rsp), %rdx
    d433:      	movq	0x40(%rsp), %r15
    d438:      	jmp	0xd48b <generic_fentry_path+0x21ab>
    d43a:      	leaq	0x10(%r15), %rdx
    d43e:      	movl	$0x4, %eax
    d443:      	movq	%rbp, %rdi
    d446:      	movl	$0x8, %esi
    d44b:      	callq	*%rax
    d44d:      	movq	0x40(%rsp), %rax
    d452:      	cmpq	(%rsp), %rax
    d456:      	je	0x16d4d <generic_fentry_path+0xba6d>
    d45c:      	addq	$0x18, %r15
    d460:      	movl	$0x4, %eax
    d465:      	leaq	0x30(%rsp), %rdi
    d46a:      	movl	$0x8, %esi
    d46f:      	movq	%r15, %rdx
    d472:      	callq	*%rax
    d474:      	movq	(%rsp), %r15
    d478:      	movq	%r15, 0x40(%rsp)
    d47d:      	leaq	0x20(%r15), %rdx
    d481:      	movq	%rdx, 0x38(%rsp)
    d486:      	movq	0x30(%rsp), %r12
    d48b:      	cmpq	0x18(%rsp), %r12
    d490:      	jne	0xd49d <generic_fentry_path+0x21bd>
    d492:      	cmpq	0x20(%rsp), %rdx
    d497:      	je	0x16d4d <generic_fentry_path+0xba6d>
    d49d:      	movl	$0x4, %eax
    d4a2:      	leaq	0x10(%rsp), %rdi
    d4a7:      	movl	$0x8, %esi
    d4ac:      	callq	*%rax
    d4ae:      	cmpq	0x10(%rsp), %r12
    d4b3:      	je	0xd5ab <generic_fentry_path+0x22cb>
    d4b9:      	leaq	0x18(%r12), %rbx
    d4be:      	movl	$0x4, %eax
    d4c3:      	movq	%rbp, %rdi
    d4c6:      	movl	$0x8, %esi
    d4cb:      	movq	%rbx, %rdx
    d4ce:      	callq	*%rax
    d4d0:      	cmpq	%r12, (%rsp)
    d4d4:      	je	0xd5ab <generic_fentry_path+0x22cb>
    d4da:      	movl	$0x4, %eax
    d4df:      	leaq	0x8(%rsp), %rdi
    d4e4:      	movl	$0x8, %esi
    d4e9:      	movq	%rbx, %rdx
    d4ec:      	callq	*%rax
    d4ee:      	addq	$0x20, %r12
    d4f2:      	movl	$0x4, %eax
    d4f7:      	leaq	0x58(%rsp), %rdi
    d4fc:      	movl	$0x10, %ecx
    d501:      	movl	$0x10, %esi
    d506:      	movq	%r12, %rdx
    d509:      	callq	*%rax
    d50b:      	movq	0x28(%rsp), %rbx
    d510:      	movq	0x48(%rsp), %rax
    d515:      	movl	0x5c(%rsp), %r15d
    d51a:      	subq	%rbx, %rax
    d51d:      	movl	0x50(%rsp), %r12d
    d522:      	movl	%r15d, %edx
    d525:      	subl	%r12d, %edx
    d528:      	movl	$0x0, %ecx
    d52d:      	cmovbl	%ecx, %edx
    d530:      	addq	0x60(%rsp), %rdx
    d535:      	xorl	%esi, %esi
    d537:      	cmpl	%r15d, %r12d
    d53a:      	seta	%sil
    d53e:      	movl	%r15d, %ecx
    d541:      	cmovbl	%r12d, %ecx
    d545:      	addl	%ecx, %esi
    d547:      	movl	%r12d, %edi
    d54a:      	subl	%esi, %edi
    d54c:      	movl	%edi, 0x50(%rsp)
    d550:      	subq	%rsi, %rax
    d553:      	jb	0x16d52 <generic_fentry_path+0xba72>
    d559:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d55f:      	ja	0x16d52 <generic_fentry_path+0xba72>
    d565:      	cmpl	%r15d, %r12d
    d568:      	jbe	0xd56e <generic_fentry_path+0x228e>
    d56a:      	movb	$0x2f, (%rbx,%rax)
    d56e:      	xorl	%edi, %edi
    d570:      	cmpl	%r15d, %r12d
    d573:      	seta	%dil
    d577:      	movzbl	%cl, %esi
    d57a:      	addq	%rax, %rbx
    d57d:      	addq	%rbx, %rdi
    d580:      	movl	$0x4, %eax
    d585:      	callq	*%rax
    d587:      	movq	%rbx, 0x48(%rsp)
    d58c:      	cmpl	%r15d, %r12d
    d58f:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    d595:      	movq	0x8(%rsp), %r12
    d59a:      	movq	%r12, 0x30(%rsp)
    d59f:      	movq	0x38(%rsp), %rdx
    d5a4:      	movq	0x40(%rsp), %r15
    d5a9:      	jmp	0xd5fc <generic_fentry_path+0x231c>
    d5ab:      	leaq	0x10(%r15), %rdx
    d5af:      	movl	$0x4, %eax
    d5b4:      	movq	%rbp, %rdi
    d5b7:      	movl	$0x8, %esi
    d5bc:      	callq	*%rax
    d5be:      	movq	0x40(%rsp), %rax
    d5c3:      	cmpq	(%rsp), %rax
    d5c7:      	je	0x16d4d <generic_fentry_path+0xba6d>
    d5cd:      	addq	$0x18, %r15
    d5d1:      	movl	$0x4, %eax
    d5d6:      	leaq	0x30(%rsp), %rdi
    d5db:      	movl	$0x8, %esi
    d5e0:      	movq	%r15, %rdx
    d5e3:      	callq	*%rax
    d5e5:      	movq	(%rsp), %r15
    d5e9:      	movq	%r15, 0x40(%rsp)
    d5ee:      	leaq	0x20(%r15), %rdx
    d5f2:      	movq	%rdx, 0x38(%rsp)
    d5f7:      	movq	0x30(%rsp), %r12
    d5fc:      	cmpq	0x18(%rsp), %r12
    d601:      	jne	0xd60e <generic_fentry_path+0x232e>
    d603:      	cmpq	0x20(%rsp), %rdx
    d608:      	je	0x16d4d <generic_fentry_path+0xba6d>
    d60e:      	movl	$0x4, %eax
    d613:      	leaq	0x10(%rsp), %rdi
    d618:      	movl	$0x8, %esi
    d61d:      	callq	*%rax
    d61f:      	cmpq	0x10(%rsp), %r12
    d624:      	je	0xd71c <generic_fentry_path+0x243c>
    d62a:      	leaq	0x18(%r12), %rbx
    d62f:      	movl	$0x4, %eax
    d634:      	movq	%rbp, %rdi
    d637:      	movl	$0x8, %esi
    d63c:      	movq	%rbx, %rdx
    d63f:      	callq	*%rax
    d641:      	cmpq	%r12, (%rsp)
    d645:      	je	0xd71c <generic_fentry_path+0x243c>
    d64b:      	movl	$0x4, %eax
    d650:      	leaq	0x8(%rsp), %rdi
    d655:      	movl	$0x8, %esi
    d65a:      	movq	%rbx, %rdx
    d65d:      	callq	*%rax
    d65f:      	addq	$0x20, %r12
    d663:      	movl	$0x4, %eax
    d668:      	leaq	0x58(%rsp), %rdi
    d66d:      	movl	$0x10, %ecx
    d672:      	movl	$0x10, %esi
    d677:      	movq	%r12, %rdx
    d67a:      	callq	*%rax
    d67c:      	movq	0x28(%rsp), %rbx
    d681:      	movq	0x48(%rsp), %rax
    d686:      	movl	0x5c(%rsp), %r15d
    d68b:      	subq	%rbx, %rax
    d68e:      	movl	0x50(%rsp), %r12d
    d693:      	movl	%r15d, %edx
    d696:      	subl	%r12d, %edx
    d699:      	movl	$0x0, %ecx
    d69e:      	cmovbl	%ecx, %edx
    d6a1:      	addq	0x60(%rsp), %rdx
    d6a6:      	xorl	%esi, %esi
    d6a8:      	cmpl	%r15d, %r12d
    d6ab:      	seta	%sil
    d6af:      	movl	%r15d, %ecx
    d6b2:      	cmovbl	%r12d, %ecx
    d6b6:      	addl	%ecx, %esi
    d6b8:      	movl	%r12d, %edi
    d6bb:      	subl	%esi, %edi
    d6bd:      	movl	%edi, 0x50(%rsp)
    d6c1:      	subq	%rsi, %rax
    d6c4:      	jb	0x16d52 <generic_fentry_path+0xba72>
    d6ca:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d6d0:      	ja	0x16d52 <generic_fentry_path+0xba72>
    d6d6:      	cmpl	%r15d, %r12d
    d6d9:      	jbe	0xd6df <generic_fentry_path+0x23ff>
    d6db:      	movb	$0x2f, (%rbx,%rax)
    d6df:      	xorl	%edi, %edi
    d6e1:      	cmpl	%r15d, %r12d
    d6e4:      	seta	%dil
    d6e8:      	movzbl	%cl, %esi
    d6eb:      	addq	%rax, %rbx
    d6ee:      	addq	%rbx, %rdi
    d6f1:      	movl	$0x4, %eax
    d6f6:      	callq	*%rax
    d6f8:      	movq	%rbx, 0x48(%rsp)
    d6fd:      	cmpl	%r15d, %r12d
    d700:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    d706:      	movq	0x8(%rsp), %r12
    d70b:      	movq	%r12, 0x30(%rsp)
    d710:      	movq	0x38(%rsp), %rdx
    d715:      	movq	0x40(%rsp), %r15
    d71a:      	jmp	0xd76d <generic_fentry_path+0x248d>
    d71c:      	leaq	0x10(%r15), %rdx
    d720:      	movl	$0x4, %eax
    d725:      	movq	%rbp, %rdi
    d728:      	movl	$0x8, %esi
    d72d:      	callq	*%rax
    d72f:      	movq	0x40(%rsp), %rax
    d734:      	cmpq	(%rsp), %rax
    d738:      	je	0x16d4d <generic_fentry_path+0xba6d>
    d73e:      	addq	$0x18, %r15
    d742:      	movl	$0x4, %eax
    d747:      	leaq	0x30(%rsp), %rdi
    d74c:      	movl	$0x8, %esi
    d751:      	movq	%r15, %rdx
    d754:      	callq	*%rax
    d756:      	movq	(%rsp), %r15
    d75a:      	movq	%r15, 0x40(%rsp)
    d75f:      	leaq	0x20(%r15), %rdx
    d763:      	movq	%rdx, 0x38(%rsp)
    d768:      	movq	0x30(%rsp), %r12
    d76d:      	cmpq	0x18(%rsp), %r12
    d772:      	jne	0xd77f <generic_fentry_path+0x249f>
    d774:      	cmpq	0x20(%rsp), %rdx
    d779:      	je	0x16d4d <generic_fentry_path+0xba6d>
    d77f:      	movl	$0x4, %eax
    d784:      	leaq	0x10(%rsp), %rdi
    d789:      	movl	$0x8, %esi
    d78e:      	callq	*%rax
    d790:      	cmpq	0x10(%rsp), %r12
    d795:      	je	0xd88d <generic_fentry_path+0x25ad>
    d79b:      	leaq	0x18(%r12), %rbx
    d7a0:      	movl	$0x4, %eax
    d7a5:      	movq	%rbp, %rdi
    d7a8:      	movl	$0x8, %esi
    d7ad:      	movq	%rbx, %rdx
    d7b0:      	callq	*%rax
    d7b2:      	cmpq	%r12, (%rsp)
    d7b6:      	je	0xd88d <generic_fentry_path+0x25ad>
    d7bc:      	movl	$0x4, %eax
    d7c1:      	leaq	0x8(%rsp), %rdi
    d7c6:      	movl	$0x8, %esi
    d7cb:      	movq	%rbx, %rdx
    d7ce:      	callq	*%rax
    d7d0:      	addq	$0x20, %r12
    d7d4:      	movl	$0x4, %eax
    d7d9:      	leaq	0x58(%rsp), %rdi
    d7de:      	movl	$0x10, %ecx
    d7e3:      	movl	$0x10, %esi
    d7e8:      	movq	%r12, %rdx
    d7eb:      	callq	*%rax
    d7ed:      	movq	0x28(%rsp), %rbx
    d7f2:      	movq	0x48(%rsp), %rax
    d7f7:      	movl	0x5c(%rsp), %r15d
    d7fc:      	subq	%rbx, %rax
    d7ff:      	movl	0x50(%rsp), %r12d
    d804:      	movl	%r15d, %edx
    d807:      	subl	%r12d, %edx
    d80a:      	movl	$0x0, %ecx
    d80f:      	cmovbl	%ecx, %edx
    d812:      	addq	0x60(%rsp), %rdx
    d817:      	xorl	%esi, %esi
    d819:      	cmpl	%r15d, %r12d
    d81c:      	seta	%sil
    d820:      	movl	%r15d, %ecx
    d823:      	cmovbl	%r12d, %ecx
    d827:      	addl	%ecx, %esi
    d829:      	movl	%r12d, %edi
    d82c:      	subl	%esi, %edi
    d82e:      	movl	%edi, 0x50(%rsp)
    d832:      	subq	%rsi, %rax
    d835:      	jb	0x16d52 <generic_fentry_path+0xba72>
    d83b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d841:      	ja	0x16d52 <generic_fentry_path+0xba72>
    d847:      	cmpl	%r15d, %r12d
    d84a:      	jbe	0xd850 <generic_fentry_path+0x2570>
    d84c:      	movb	$0x2f, (%rbx,%rax)
    d850:      	xorl	%edi, %edi
    d852:      	cmpl	%r15d, %r12d
    d855:      	seta	%dil
    d859:      	movzbl	%cl, %esi
    d85c:      	addq	%rax, %rbx
    d85f:      	addq	%rbx, %rdi
    d862:      	movl	$0x4, %eax
    d867:      	callq	*%rax
    d869:      	movq	%rbx, 0x48(%rsp)
    d86e:      	cmpl	%r15d, %r12d
    d871:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    d877:      	movq	0x8(%rsp), %r12
    d87c:      	movq	%r12, 0x30(%rsp)
    d881:      	movq	0x38(%rsp), %rdx
    d886:      	movq	0x40(%rsp), %r15
    d88b:      	jmp	0xd8de <generic_fentry_path+0x25fe>
    d88d:      	leaq	0x10(%r15), %rdx
    d891:      	movl	$0x4, %eax
    d896:      	movq	%rbp, %rdi
    d899:      	movl	$0x8, %esi
    d89e:      	callq	*%rax
    d8a0:      	movq	0x40(%rsp), %rax
    d8a5:      	cmpq	(%rsp), %rax
    d8a9:      	je	0x16d4d <generic_fentry_path+0xba6d>
    d8af:      	addq	$0x18, %r15
    d8b3:      	movl	$0x4, %eax
    d8b8:      	leaq	0x30(%rsp), %rdi
    d8bd:      	movl	$0x8, %esi
    d8c2:      	movq	%r15, %rdx
    d8c5:      	callq	*%rax
    d8c7:      	movq	(%rsp), %r15
    d8cb:      	movq	%r15, 0x40(%rsp)
    d8d0:      	leaq	0x20(%r15), %rdx
    d8d4:      	movq	%rdx, 0x38(%rsp)
    d8d9:      	movq	0x30(%rsp), %r12
    d8de:      	cmpq	0x18(%rsp), %r12
    d8e3:      	jne	0xd8f0 <generic_fentry_path+0x2610>
    d8e5:      	cmpq	0x20(%rsp), %rdx
    d8ea:      	je	0x16d4d <generic_fentry_path+0xba6d>
    d8f0:      	movl	$0x4, %eax
    d8f5:      	leaq	0x10(%rsp), %rdi
    d8fa:      	movl	$0x8, %esi
    d8ff:      	callq	*%rax
    d901:      	cmpq	0x10(%rsp), %r12
    d906:      	je	0xd9fe <generic_fentry_path+0x271e>
    d90c:      	leaq	0x18(%r12), %rbx
    d911:      	movl	$0x4, %eax
    d916:      	movq	%rbp, %rdi
    d919:      	movl	$0x8, %esi
    d91e:      	movq	%rbx, %rdx
    d921:      	callq	*%rax
    d923:      	cmpq	%r12, (%rsp)
    d927:      	je	0xd9fe <generic_fentry_path+0x271e>
    d92d:      	movl	$0x4, %eax
    d932:      	leaq	0x8(%rsp), %rdi
    d937:      	movl	$0x8, %esi
    d93c:      	movq	%rbx, %rdx
    d93f:      	callq	*%rax
    d941:      	addq	$0x20, %r12
    d945:      	movl	$0x4, %eax
    d94a:      	leaq	0x58(%rsp), %rdi
    d94f:      	movl	$0x10, %ecx
    d954:      	movl	$0x10, %esi
    d959:      	movq	%r12, %rdx
    d95c:      	callq	*%rax
    d95e:      	movq	0x28(%rsp), %rbx
    d963:      	movq	0x48(%rsp), %rax
    d968:      	movl	0x5c(%rsp), %r15d
    d96d:      	subq	%rbx, %rax
    d970:      	movl	0x50(%rsp), %r12d
    d975:      	movl	%r15d, %edx
    d978:      	subl	%r12d, %edx
    d97b:      	movl	$0x0, %ecx
    d980:      	cmovbl	%ecx, %edx
    d983:      	addq	0x60(%rsp), %rdx
    d988:      	xorl	%esi, %esi
    d98a:      	cmpl	%r15d, %r12d
    d98d:      	seta	%sil
    d991:      	movl	%r15d, %ecx
    d994:      	cmovbl	%r12d, %ecx
    d998:      	addl	%ecx, %esi
    d99a:      	movl	%r12d, %edi
    d99d:      	subl	%esi, %edi
    d99f:      	movl	%edi, 0x50(%rsp)
    d9a3:      	subq	%rsi, %rax
    d9a6:      	jb	0x16d52 <generic_fentry_path+0xba72>
    d9ac:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d9b2:      	ja	0x16d52 <generic_fentry_path+0xba72>
    d9b8:      	cmpl	%r15d, %r12d
    d9bb:      	jbe	0xd9c1 <generic_fentry_path+0x26e1>
    d9bd:      	movb	$0x2f, (%rbx,%rax)
    d9c1:      	xorl	%edi, %edi
    d9c3:      	cmpl	%r15d, %r12d
    d9c6:      	seta	%dil
    d9ca:      	movzbl	%cl, %esi
    d9cd:      	addq	%rax, %rbx
    d9d0:      	addq	%rbx, %rdi
    d9d3:      	movl	$0x4, %eax
    d9d8:      	callq	*%rax
    d9da:      	movq	%rbx, 0x48(%rsp)
    d9df:      	cmpl	%r15d, %r12d
    d9e2:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    d9e8:      	movq	0x8(%rsp), %r12
    d9ed:      	movq	%r12, 0x30(%rsp)
    d9f2:      	movq	0x38(%rsp), %rdx
    d9f7:      	movq	0x40(%rsp), %r15
    d9fc:      	jmp	0xda4f <generic_fentry_path+0x276f>
    d9fe:      	leaq	0x10(%r15), %rdx
    da02:      	movl	$0x4, %eax
    da07:      	movq	%rbp, %rdi
    da0a:      	movl	$0x8, %esi
    da0f:      	callq	*%rax
    da11:      	movq	0x40(%rsp), %rax
    da16:      	cmpq	(%rsp), %rax
    da1a:      	je	0x16d4d <generic_fentry_path+0xba6d>
    da20:      	addq	$0x18, %r15
    da24:      	movl	$0x4, %eax
    da29:      	leaq	0x30(%rsp), %rdi
    da2e:      	movl	$0x8, %esi
    da33:      	movq	%r15, %rdx
    da36:      	callq	*%rax
    da38:      	movq	(%rsp), %r15
    da3c:      	movq	%r15, 0x40(%rsp)
    da41:      	leaq	0x20(%r15), %rdx
    da45:      	movq	%rdx, 0x38(%rsp)
    da4a:      	movq	0x30(%rsp), %r12
    da4f:      	cmpq	0x18(%rsp), %r12
    da54:      	jne	0xda61 <generic_fentry_path+0x2781>
    da56:      	cmpq	0x20(%rsp), %rdx
    da5b:      	je	0x16d4d <generic_fentry_path+0xba6d>
    da61:      	movl	$0x4, %eax
    da66:      	leaq	0x10(%rsp), %rdi
    da6b:      	movl	$0x8, %esi
    da70:      	callq	*%rax
    da72:      	cmpq	0x10(%rsp), %r12
    da77:      	je	0xdb6f <generic_fentry_path+0x288f>
    da7d:      	leaq	0x18(%r12), %rbx
    da82:      	movl	$0x4, %eax
    da87:      	movq	%rbp, %rdi
    da8a:      	movl	$0x8, %esi
    da8f:      	movq	%rbx, %rdx
    da92:      	callq	*%rax
    da94:      	cmpq	%r12, (%rsp)
    da98:      	je	0xdb6f <generic_fentry_path+0x288f>
    da9e:      	movl	$0x4, %eax
    daa3:      	leaq	0x8(%rsp), %rdi
    daa8:      	movl	$0x8, %esi
    daad:      	movq	%rbx, %rdx
    dab0:      	callq	*%rax
    dab2:      	addq	$0x20, %r12
    dab6:      	movl	$0x4, %eax
    dabb:      	leaq	0x58(%rsp), %rdi
    dac0:      	movl	$0x10, %ecx
    dac5:      	movl	$0x10, %esi
    daca:      	movq	%r12, %rdx
    dacd:      	callq	*%rax
    dacf:      	movq	0x28(%rsp), %rbx
    dad4:      	movq	0x48(%rsp), %rax
    dad9:      	movl	0x5c(%rsp), %r15d
    dade:      	subq	%rbx, %rax
    dae1:      	movl	0x50(%rsp), %r12d
    dae6:      	movl	%r15d, %edx
    dae9:      	subl	%r12d, %edx
    daec:      	movl	$0x0, %ecx
    daf1:      	cmovbl	%ecx, %edx
    daf4:      	addq	0x60(%rsp), %rdx
    daf9:      	xorl	%esi, %esi
    dafb:      	cmpl	%r15d, %r12d
    dafe:      	seta	%sil
    db02:      	movl	%r15d, %ecx
    db05:      	cmovbl	%r12d, %ecx
    db09:      	addl	%ecx, %esi
    db0b:      	movl	%r12d, %edi
    db0e:      	subl	%esi, %edi
    db10:      	movl	%edi, 0x50(%rsp)
    db14:      	subq	%rsi, %rax
    db17:      	jb	0x16d52 <generic_fentry_path+0xba72>
    db1d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    db23:      	ja	0x16d52 <generic_fentry_path+0xba72>
    db29:      	cmpl	%r15d, %r12d
    db2c:      	jbe	0xdb32 <generic_fentry_path+0x2852>
    db2e:      	movb	$0x2f, (%rbx,%rax)
    db32:      	xorl	%edi, %edi
    db34:      	cmpl	%r15d, %r12d
    db37:      	seta	%dil
    db3b:      	movzbl	%cl, %esi
    db3e:      	addq	%rax, %rbx
    db41:      	addq	%rbx, %rdi
    db44:      	movl	$0x4, %eax
    db49:      	callq	*%rax
    db4b:      	movq	%rbx, 0x48(%rsp)
    db50:      	cmpl	%r15d, %r12d
    db53:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    db59:      	movq	0x8(%rsp), %r12
    db5e:      	movq	%r12, 0x30(%rsp)
    db63:      	movq	0x38(%rsp), %rdx
    db68:      	movq	0x40(%rsp), %r15
    db6d:      	jmp	0xdbc0 <generic_fentry_path+0x28e0>
    db6f:      	leaq	0x10(%r15), %rdx
    db73:      	movl	$0x4, %eax
    db78:      	movq	%rbp, %rdi
    db7b:      	movl	$0x8, %esi
    db80:      	callq	*%rax
    db82:      	movq	0x40(%rsp), %rax
    db87:      	cmpq	(%rsp), %rax
    db8b:      	je	0x16d4d <generic_fentry_path+0xba6d>
    db91:      	addq	$0x18, %r15
    db95:      	movl	$0x4, %eax
    db9a:      	leaq	0x30(%rsp), %rdi
    db9f:      	movl	$0x8, %esi
    dba4:      	movq	%r15, %rdx
    dba7:      	callq	*%rax
    dba9:      	movq	(%rsp), %r15
    dbad:      	movq	%r15, 0x40(%rsp)
    dbb2:      	leaq	0x20(%r15), %rdx
    dbb6:      	movq	%rdx, 0x38(%rsp)
    dbbb:      	movq	0x30(%rsp), %r12
    dbc0:      	cmpq	0x18(%rsp), %r12
    dbc5:      	jne	0xdbd2 <generic_fentry_path+0x28f2>
    dbc7:      	cmpq	0x20(%rsp), %rdx
    dbcc:      	je	0x16d4d <generic_fentry_path+0xba6d>
    dbd2:      	movl	$0x4, %eax
    dbd7:      	leaq	0x10(%rsp), %rdi
    dbdc:      	movl	$0x8, %esi
    dbe1:      	callq	*%rax
    dbe3:      	cmpq	0x10(%rsp), %r12
    dbe8:      	je	0xdce0 <generic_fentry_path+0x2a00>
    dbee:      	leaq	0x18(%r12), %rbx
    dbf3:      	movl	$0x4, %eax
    dbf8:      	movq	%rbp, %rdi
    dbfb:      	movl	$0x8, %esi
    dc00:      	movq	%rbx, %rdx
    dc03:      	callq	*%rax
    dc05:      	cmpq	%r12, (%rsp)
    dc09:      	je	0xdce0 <generic_fentry_path+0x2a00>
    dc0f:      	movl	$0x4, %eax
    dc14:      	leaq	0x8(%rsp), %rdi
    dc19:      	movl	$0x8, %esi
    dc1e:      	movq	%rbx, %rdx
    dc21:      	callq	*%rax
    dc23:      	addq	$0x20, %r12
    dc27:      	movl	$0x4, %eax
    dc2c:      	leaq	0x58(%rsp), %rdi
    dc31:      	movl	$0x10, %ecx
    dc36:      	movl	$0x10, %esi
    dc3b:      	movq	%r12, %rdx
    dc3e:      	callq	*%rax
    dc40:      	movq	0x28(%rsp), %rbx
    dc45:      	movq	0x48(%rsp), %rax
    dc4a:      	movl	0x5c(%rsp), %r15d
    dc4f:      	subq	%rbx, %rax
    dc52:      	movl	0x50(%rsp), %r12d
    dc57:      	movl	%r15d, %edx
    dc5a:      	subl	%r12d, %edx
    dc5d:      	movl	$0x0, %ecx
    dc62:      	cmovbl	%ecx, %edx
    dc65:      	addq	0x60(%rsp), %rdx
    dc6a:      	xorl	%esi, %esi
    dc6c:      	cmpl	%r15d, %r12d
    dc6f:      	seta	%sil
    dc73:      	movl	%r15d, %ecx
    dc76:      	cmovbl	%r12d, %ecx
    dc7a:      	addl	%ecx, %esi
    dc7c:      	movl	%r12d, %edi
    dc7f:      	subl	%esi, %edi
    dc81:      	movl	%edi, 0x50(%rsp)
    dc85:      	subq	%rsi, %rax
    dc88:      	jb	0x16d52 <generic_fentry_path+0xba72>
    dc8e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    dc94:      	ja	0x16d52 <generic_fentry_path+0xba72>
    dc9a:      	cmpl	%r15d, %r12d
    dc9d:      	jbe	0xdca3 <generic_fentry_path+0x29c3>
    dc9f:      	movb	$0x2f, (%rbx,%rax)
    dca3:      	xorl	%edi, %edi
    dca5:      	cmpl	%r15d, %r12d
    dca8:      	seta	%dil
    dcac:      	movzbl	%cl, %esi
    dcaf:      	addq	%rax, %rbx
    dcb2:      	addq	%rbx, %rdi
    dcb5:      	movl	$0x4, %eax
    dcba:      	callq	*%rax
    dcbc:      	movq	%rbx, 0x48(%rsp)
    dcc1:      	cmpl	%r15d, %r12d
    dcc4:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    dcca:      	movq	0x8(%rsp), %r12
    dccf:      	movq	%r12, 0x30(%rsp)
    dcd4:      	movq	0x38(%rsp), %rdx
    dcd9:      	movq	0x40(%rsp), %r15
    dcde:      	jmp	0xdd31 <generic_fentry_path+0x2a51>
    dce0:      	leaq	0x10(%r15), %rdx
    dce4:      	movl	$0x4, %eax
    dce9:      	movq	%rbp, %rdi
    dcec:      	movl	$0x8, %esi
    dcf1:      	callq	*%rax
    dcf3:      	movq	0x40(%rsp), %rax
    dcf8:      	cmpq	(%rsp), %rax
    dcfc:      	je	0x16d4d <generic_fentry_path+0xba6d>
    dd02:      	addq	$0x18, %r15
    dd06:      	movl	$0x4, %eax
    dd0b:      	leaq	0x30(%rsp), %rdi
    dd10:      	movl	$0x8, %esi
    dd15:      	movq	%r15, %rdx
    dd18:      	callq	*%rax
    dd1a:      	movq	(%rsp), %r15
    dd1e:      	movq	%r15, 0x40(%rsp)
    dd23:      	leaq	0x20(%r15), %rdx
    dd27:      	movq	%rdx, 0x38(%rsp)
    dd2c:      	movq	0x30(%rsp), %r12
    dd31:      	cmpq	0x18(%rsp), %r12
    dd36:      	jne	0xdd43 <generic_fentry_path+0x2a63>
    dd38:      	cmpq	0x20(%rsp), %rdx
    dd3d:      	je	0x16d4d <generic_fentry_path+0xba6d>
    dd43:      	movl	$0x4, %eax
    dd48:      	leaq	0x10(%rsp), %rdi
    dd4d:      	movl	$0x8, %esi
    dd52:      	callq	*%rax
    dd54:      	cmpq	0x10(%rsp), %r12
    dd59:      	je	0xde51 <generic_fentry_path+0x2b71>
    dd5f:      	leaq	0x18(%r12), %rbx
    dd64:      	movl	$0x4, %eax
    dd69:      	movq	%rbp, %rdi
    dd6c:      	movl	$0x8, %esi
    dd71:      	movq	%rbx, %rdx
    dd74:      	callq	*%rax
    dd76:      	cmpq	%r12, (%rsp)
    dd7a:      	je	0xde51 <generic_fentry_path+0x2b71>
    dd80:      	movl	$0x4, %eax
    dd85:      	leaq	0x8(%rsp), %rdi
    dd8a:      	movl	$0x8, %esi
    dd8f:      	movq	%rbx, %rdx
    dd92:      	callq	*%rax
    dd94:      	addq	$0x20, %r12
    dd98:      	movl	$0x4, %eax
    dd9d:      	leaq	0x58(%rsp), %rdi
    dda2:      	movl	$0x10, %ecx
    dda7:      	movl	$0x10, %esi
    ddac:      	movq	%r12, %rdx
    ddaf:      	callq	*%rax
    ddb1:      	movq	0x28(%rsp), %rbx
    ddb6:      	movq	0x48(%rsp), %rax
    ddbb:      	movl	0x5c(%rsp), %r15d
    ddc0:      	subq	%rbx, %rax
    ddc3:      	movl	0x50(%rsp), %r12d
    ddc8:      	movl	%r15d, %edx
    ddcb:      	subl	%r12d, %edx
    ddce:      	movl	$0x0, %ecx
    ddd3:      	cmovbl	%ecx, %edx
    ddd6:      	addq	0x60(%rsp), %rdx
    dddb:      	xorl	%esi, %esi
    dddd:      	cmpl	%r15d, %r12d
    dde0:      	seta	%sil
    dde4:      	movl	%r15d, %ecx
    dde7:      	cmovbl	%r12d, %ecx
    ddeb:      	addl	%ecx, %esi
    dded:      	movl	%r12d, %edi
    ddf0:      	subl	%esi, %edi
    ddf2:      	movl	%edi, 0x50(%rsp)
    ddf6:      	subq	%rsi, %rax
    ddf9:      	jb	0x16d52 <generic_fentry_path+0xba72>
    ddff:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    de05:      	ja	0x16d52 <generic_fentry_path+0xba72>
    de0b:      	cmpl	%r15d, %r12d
    de0e:      	jbe	0xde14 <generic_fentry_path+0x2b34>
    de10:      	movb	$0x2f, (%rbx,%rax)
    de14:      	xorl	%edi, %edi
    de16:      	cmpl	%r15d, %r12d
    de19:      	seta	%dil
    de1d:      	movzbl	%cl, %esi
    de20:      	addq	%rax, %rbx
    de23:      	addq	%rbx, %rdi
    de26:      	movl	$0x4, %eax
    de2b:      	callq	*%rax
    de2d:      	movq	%rbx, 0x48(%rsp)
    de32:      	cmpl	%r15d, %r12d
    de35:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    de3b:      	movq	0x8(%rsp), %r12
    de40:      	movq	%r12, 0x30(%rsp)
    de45:      	movq	0x38(%rsp), %rdx
    de4a:      	movq	0x40(%rsp), %r15
    de4f:      	jmp	0xdea2 <generic_fentry_path+0x2bc2>
    de51:      	leaq	0x10(%r15), %rdx
    de55:      	movl	$0x4, %eax
    de5a:      	movq	%rbp, %rdi
    de5d:      	movl	$0x8, %esi
    de62:      	callq	*%rax
    de64:      	movq	0x40(%rsp), %rax
    de69:      	cmpq	(%rsp), %rax
    de6d:      	je	0x16d4d <generic_fentry_path+0xba6d>
    de73:      	addq	$0x18, %r15
    de77:      	movl	$0x4, %eax
    de7c:      	leaq	0x30(%rsp), %rdi
    de81:      	movl	$0x8, %esi
    de86:      	movq	%r15, %rdx
    de89:      	callq	*%rax
    de8b:      	movq	(%rsp), %r15
    de8f:      	movq	%r15, 0x40(%rsp)
    de94:      	leaq	0x20(%r15), %rdx
    de98:      	movq	%rdx, 0x38(%rsp)
    de9d:      	movq	0x30(%rsp), %r12
    dea2:      	cmpq	0x18(%rsp), %r12
    dea7:      	jne	0xdeb4 <generic_fentry_path+0x2bd4>
    dea9:      	cmpq	0x20(%rsp), %rdx
    deae:      	je	0x16d4d <generic_fentry_path+0xba6d>
    deb4:      	movl	$0x4, %eax
    deb9:      	leaq	0x10(%rsp), %rdi
    debe:      	movl	$0x8, %esi
    dec3:      	callq	*%rax
    dec5:      	cmpq	0x10(%rsp), %r12
    deca:      	je	0xdfc2 <generic_fentry_path+0x2ce2>
    ded0:      	leaq	0x18(%r12), %rbx
    ded5:      	movl	$0x4, %eax
    deda:      	movq	%rbp, %rdi
    dedd:      	movl	$0x8, %esi
    dee2:      	movq	%rbx, %rdx
    dee5:      	callq	*%rax
    dee7:      	cmpq	%r12, (%rsp)
    deeb:      	je	0xdfc2 <generic_fentry_path+0x2ce2>
    def1:      	movl	$0x4, %eax
    def6:      	leaq	0x8(%rsp), %rdi
    defb:      	movl	$0x8, %esi
    df00:      	movq	%rbx, %rdx
    df03:      	callq	*%rax
    df05:      	addq	$0x20, %r12
    df09:      	movl	$0x4, %eax
    df0e:      	leaq	0x58(%rsp), %rdi
    df13:      	movl	$0x10, %ecx
    df18:      	movl	$0x10, %esi
    df1d:      	movq	%r12, %rdx
    df20:      	callq	*%rax
    df22:      	movq	0x28(%rsp), %rbx
    df27:      	movq	0x48(%rsp), %rax
    df2c:      	movl	0x5c(%rsp), %r15d
    df31:      	subq	%rbx, %rax
    df34:      	movl	0x50(%rsp), %r12d
    df39:      	movl	%r15d, %edx
    df3c:      	subl	%r12d, %edx
    df3f:      	movl	$0x0, %ecx
    df44:      	cmovbl	%ecx, %edx
    df47:      	addq	0x60(%rsp), %rdx
    df4c:      	xorl	%esi, %esi
    df4e:      	cmpl	%r15d, %r12d
    df51:      	seta	%sil
    df55:      	movl	%r15d, %ecx
    df58:      	cmovbl	%r12d, %ecx
    df5c:      	addl	%ecx, %esi
    df5e:      	movl	%r12d, %edi
    df61:      	subl	%esi, %edi
    df63:      	movl	%edi, 0x50(%rsp)
    df67:      	subq	%rsi, %rax
    df6a:      	jb	0x16d52 <generic_fentry_path+0xba72>
    df70:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    df76:      	ja	0x16d52 <generic_fentry_path+0xba72>
    df7c:      	cmpl	%r15d, %r12d
    df7f:      	jbe	0xdf85 <generic_fentry_path+0x2ca5>
    df81:      	movb	$0x2f, (%rbx,%rax)
    df85:      	xorl	%edi, %edi
    df87:      	cmpl	%r15d, %r12d
    df8a:      	seta	%dil
    df8e:      	movzbl	%cl, %esi
    df91:      	addq	%rax, %rbx
    df94:      	addq	%rbx, %rdi
    df97:      	movl	$0x4, %eax
    df9c:      	callq	*%rax
    df9e:      	movq	%rbx, 0x48(%rsp)
    dfa3:      	cmpl	%r15d, %r12d
    dfa6:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    dfac:      	movq	0x8(%rsp), %r12
    dfb1:      	movq	%r12, 0x30(%rsp)
    dfb6:      	movq	0x38(%rsp), %rdx
    dfbb:      	movq	0x40(%rsp), %r15
    dfc0:      	jmp	0xe013 <generic_fentry_path+0x2d33>
    dfc2:      	leaq	0x10(%r15), %rdx
    dfc6:      	movl	$0x4, %eax
    dfcb:      	movq	%rbp, %rdi
    dfce:      	movl	$0x8, %esi
    dfd3:      	callq	*%rax
    dfd5:      	movq	0x40(%rsp), %rax
    dfda:      	cmpq	(%rsp), %rax
    dfde:      	je	0x16d4d <generic_fentry_path+0xba6d>
    dfe4:      	addq	$0x18, %r15
    dfe8:      	movl	$0x4, %eax
    dfed:      	leaq	0x30(%rsp), %rdi
    dff2:      	movl	$0x8, %esi
    dff7:      	movq	%r15, %rdx
    dffa:      	callq	*%rax
    dffc:      	movq	(%rsp), %r15
    e000:      	movq	%r15, 0x40(%rsp)
    e005:      	leaq	0x20(%r15), %rdx
    e009:      	movq	%rdx, 0x38(%rsp)
    e00e:      	movq	0x30(%rsp), %r12
    e013:      	cmpq	0x18(%rsp), %r12
    e018:      	jne	0xe025 <generic_fentry_path+0x2d45>
    e01a:      	cmpq	0x20(%rsp), %rdx
    e01f:      	je	0x16d4d <generic_fentry_path+0xba6d>
    e025:      	movl	$0x4, %eax
    e02a:      	leaq	0x10(%rsp), %rdi
    e02f:      	movl	$0x8, %esi
    e034:      	callq	*%rax
    e036:      	cmpq	0x10(%rsp), %r12
    e03b:      	je	0xe133 <generic_fentry_path+0x2e53>
    e041:      	leaq	0x18(%r12), %rbx
    e046:      	movl	$0x4, %eax
    e04b:      	movq	%rbp, %rdi
    e04e:      	movl	$0x8, %esi
    e053:      	movq	%rbx, %rdx
    e056:      	callq	*%rax
    e058:      	cmpq	%r12, (%rsp)
    e05c:      	je	0xe133 <generic_fentry_path+0x2e53>
    e062:      	movl	$0x4, %eax
    e067:      	leaq	0x8(%rsp), %rdi
    e06c:      	movl	$0x8, %esi
    e071:      	movq	%rbx, %rdx
    e074:      	callq	*%rax
    e076:      	addq	$0x20, %r12
    e07a:      	movl	$0x4, %eax
    e07f:      	leaq	0x58(%rsp), %rdi
    e084:      	movl	$0x10, %ecx
    e089:      	movl	$0x10, %esi
    e08e:      	movq	%r12, %rdx
    e091:      	callq	*%rax
    e093:      	movq	0x28(%rsp), %rbx
    e098:      	movq	0x48(%rsp), %rax
    e09d:      	movl	0x5c(%rsp), %r15d
    e0a2:      	subq	%rbx, %rax
    e0a5:      	movl	0x50(%rsp), %r12d
    e0aa:      	movl	%r15d, %edx
    e0ad:      	subl	%r12d, %edx
    e0b0:      	movl	$0x0, %ecx
    e0b5:      	cmovbl	%ecx, %edx
    e0b8:      	addq	0x60(%rsp), %rdx
    e0bd:      	xorl	%esi, %esi
    e0bf:      	cmpl	%r15d, %r12d
    e0c2:      	seta	%sil
    e0c6:      	movl	%r15d, %ecx
    e0c9:      	cmovbl	%r12d, %ecx
    e0cd:      	addl	%ecx, %esi
    e0cf:      	movl	%r12d, %edi
    e0d2:      	subl	%esi, %edi
    e0d4:      	movl	%edi, 0x50(%rsp)
    e0d8:      	subq	%rsi, %rax
    e0db:      	jb	0x16d52 <generic_fentry_path+0xba72>
    e0e1:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e0e7:      	ja	0x16d52 <generic_fentry_path+0xba72>
    e0ed:      	cmpl	%r15d, %r12d
    e0f0:      	jbe	0xe0f6 <generic_fentry_path+0x2e16>
    e0f2:      	movb	$0x2f, (%rbx,%rax)
    e0f6:      	xorl	%edi, %edi
    e0f8:      	cmpl	%r15d, %r12d
    e0fb:      	seta	%dil
    e0ff:      	movzbl	%cl, %esi
    e102:      	addq	%rax, %rbx
    e105:      	addq	%rbx, %rdi
    e108:      	movl	$0x4, %eax
    e10d:      	callq	*%rax
    e10f:      	movq	%rbx, 0x48(%rsp)
    e114:      	cmpl	%r15d, %r12d
    e117:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    e11d:      	movq	0x8(%rsp), %r12
    e122:      	movq	%r12, 0x30(%rsp)
    e127:      	movq	0x38(%rsp), %rdx
    e12c:      	movq	0x40(%rsp), %r15
    e131:      	jmp	0xe184 <generic_fentry_path+0x2ea4>
    e133:      	leaq	0x10(%r15), %rdx
    e137:      	movl	$0x4, %eax
    e13c:      	movq	%rbp, %rdi
    e13f:      	movl	$0x8, %esi
    e144:      	callq	*%rax
    e146:      	movq	0x40(%rsp), %rax
    e14b:      	cmpq	(%rsp), %rax
    e14f:      	je	0x16d4d <generic_fentry_path+0xba6d>
    e155:      	addq	$0x18, %r15
    e159:      	movl	$0x4, %eax
    e15e:      	leaq	0x30(%rsp), %rdi
    e163:      	movl	$0x8, %esi
    e168:      	movq	%r15, %rdx
    e16b:      	callq	*%rax
    e16d:      	movq	(%rsp), %r15
    e171:      	movq	%r15, 0x40(%rsp)
    e176:      	leaq	0x20(%r15), %rdx
    e17a:      	movq	%rdx, 0x38(%rsp)
    e17f:      	movq	0x30(%rsp), %r12
    e184:      	cmpq	0x18(%rsp), %r12
    e189:      	jne	0xe196 <generic_fentry_path+0x2eb6>
    e18b:      	cmpq	0x20(%rsp), %rdx
    e190:      	je	0x16d4d <generic_fentry_path+0xba6d>
    e196:      	movl	$0x4, %eax
    e19b:      	leaq	0x10(%rsp), %rdi
    e1a0:      	movl	$0x8, %esi
    e1a5:      	callq	*%rax
    e1a7:      	cmpq	0x10(%rsp), %r12
    e1ac:      	je	0xe2a4 <generic_fentry_path+0x2fc4>
    e1b2:      	leaq	0x18(%r12), %rbx
    e1b7:      	movl	$0x4, %eax
    e1bc:      	movq	%rbp, %rdi
    e1bf:      	movl	$0x8, %esi
    e1c4:      	movq	%rbx, %rdx
    e1c7:      	callq	*%rax
    e1c9:      	cmpq	%r12, (%rsp)
    e1cd:      	je	0xe2a4 <generic_fentry_path+0x2fc4>
    e1d3:      	movl	$0x4, %eax
    e1d8:      	leaq	0x8(%rsp), %rdi
    e1dd:      	movl	$0x8, %esi
    e1e2:      	movq	%rbx, %rdx
    e1e5:      	callq	*%rax
    e1e7:      	addq	$0x20, %r12
    e1eb:      	movl	$0x4, %eax
    e1f0:      	leaq	0x58(%rsp), %rdi
    e1f5:      	movl	$0x10, %ecx
    e1fa:      	movl	$0x10, %esi
    e1ff:      	movq	%r12, %rdx
    e202:      	callq	*%rax
    e204:      	movq	0x28(%rsp), %rbx
    e209:      	movq	0x48(%rsp), %rax
    e20e:      	movl	0x5c(%rsp), %r15d
    e213:      	subq	%rbx, %rax
    e216:      	movl	0x50(%rsp), %r12d
    e21b:      	movl	%r15d, %edx
    e21e:      	subl	%r12d, %edx
    e221:      	movl	$0x0, %ecx
    e226:      	cmovbl	%ecx, %edx
    e229:      	addq	0x60(%rsp), %rdx
    e22e:      	xorl	%esi, %esi
    e230:      	cmpl	%r15d, %r12d
    e233:      	seta	%sil
    e237:      	movl	%r15d, %ecx
    e23a:      	cmovbl	%r12d, %ecx
    e23e:      	addl	%ecx, %esi
    e240:      	movl	%r12d, %edi
    e243:      	subl	%esi, %edi
    e245:      	movl	%edi, 0x50(%rsp)
    e249:      	subq	%rsi, %rax
    e24c:      	jb	0x16d52 <generic_fentry_path+0xba72>
    e252:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e258:      	ja	0x16d52 <generic_fentry_path+0xba72>
    e25e:      	cmpl	%r15d, %r12d
    e261:      	jbe	0xe267 <generic_fentry_path+0x2f87>
    e263:      	movb	$0x2f, (%rbx,%rax)
    e267:      	xorl	%edi, %edi
    e269:      	cmpl	%r15d, %r12d
    e26c:      	seta	%dil
    e270:      	movzbl	%cl, %esi
    e273:      	addq	%rax, %rbx
    e276:      	addq	%rbx, %rdi
    e279:      	movl	$0x4, %eax
    e27e:      	callq	*%rax
    e280:      	movq	%rbx, 0x48(%rsp)
    e285:      	cmpl	%r15d, %r12d
    e288:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    e28e:      	movq	0x8(%rsp), %r12
    e293:      	movq	%r12, 0x30(%rsp)
    e298:      	movq	0x38(%rsp), %rdx
    e29d:      	movq	0x40(%rsp), %r15
    e2a2:      	jmp	0xe2f5 <generic_fentry_path+0x3015>
    e2a4:      	leaq	0x10(%r15), %rdx
    e2a8:      	movl	$0x4, %eax
    e2ad:      	movq	%rbp, %rdi
    e2b0:      	movl	$0x8, %esi
    e2b5:      	callq	*%rax
    e2b7:      	movq	0x40(%rsp), %rax
    e2bc:      	cmpq	(%rsp), %rax
    e2c0:      	je	0x16d4d <generic_fentry_path+0xba6d>
    e2c6:      	addq	$0x18, %r15
    e2ca:      	movl	$0x4, %eax
    e2cf:      	leaq	0x30(%rsp), %rdi
    e2d4:      	movl	$0x8, %esi
    e2d9:      	movq	%r15, %rdx
    e2dc:      	callq	*%rax
    e2de:      	movq	(%rsp), %r15
    e2e2:      	movq	%r15, 0x40(%rsp)
    e2e7:      	leaq	0x20(%r15), %rdx
    e2eb:      	movq	%rdx, 0x38(%rsp)
    e2f0:      	movq	0x30(%rsp), %r12
    e2f5:      	cmpq	0x18(%rsp), %r12
    e2fa:      	jne	0xe307 <generic_fentry_path+0x3027>
    e2fc:      	cmpq	0x20(%rsp), %rdx
    e301:      	je	0x16d4d <generic_fentry_path+0xba6d>
    e307:      	movl	$0x4, %eax
    e30c:      	leaq	0x10(%rsp), %rdi
    e311:      	movl	$0x8, %esi
    e316:      	callq	*%rax
    e318:      	cmpq	0x10(%rsp), %r12
    e31d:      	je	0xe415 <generic_fentry_path+0x3135>
    e323:      	leaq	0x18(%r12), %rbx
    e328:      	movl	$0x4, %eax
    e32d:      	movq	%rbp, %rdi
    e330:      	movl	$0x8, %esi
    e335:      	movq	%rbx, %rdx
    e338:      	callq	*%rax
    e33a:      	cmpq	%r12, (%rsp)
    e33e:      	je	0xe415 <generic_fentry_path+0x3135>
    e344:      	movl	$0x4, %eax
    e349:      	leaq	0x8(%rsp), %rdi
    e34e:      	movl	$0x8, %esi
    e353:      	movq	%rbx, %rdx
    e356:      	callq	*%rax
    e358:      	addq	$0x20, %r12
    e35c:      	movl	$0x4, %eax
    e361:      	leaq	0x58(%rsp), %rdi
    e366:      	movl	$0x10, %ecx
    e36b:      	movl	$0x10, %esi
    e370:      	movq	%r12, %rdx
    e373:      	callq	*%rax
    e375:      	movq	0x28(%rsp), %rbx
    e37a:      	movq	0x48(%rsp), %rax
    e37f:      	movl	0x5c(%rsp), %r15d
    e384:      	subq	%rbx, %rax
    e387:      	movl	0x50(%rsp), %r12d
    e38c:      	movl	%r15d, %edx
    e38f:      	subl	%r12d, %edx
    e392:      	movl	$0x0, %ecx
    e397:      	cmovbl	%ecx, %edx
    e39a:      	addq	0x60(%rsp), %rdx
    e39f:      	xorl	%esi, %esi
    e3a1:      	cmpl	%r15d, %r12d
    e3a4:      	seta	%sil
    e3a8:      	movl	%r15d, %ecx
    e3ab:      	cmovbl	%r12d, %ecx
    e3af:      	addl	%ecx, %esi
    e3b1:      	movl	%r12d, %edi
    e3b4:      	subl	%esi, %edi
    e3b6:      	movl	%edi, 0x50(%rsp)
    e3ba:      	subq	%rsi, %rax
    e3bd:      	jb	0x16d52 <generic_fentry_path+0xba72>
    e3c3:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e3c9:      	ja	0x16d52 <generic_fentry_path+0xba72>
    e3cf:      	cmpl	%r15d, %r12d
    e3d2:      	jbe	0xe3d8 <generic_fentry_path+0x30f8>
    e3d4:      	movb	$0x2f, (%rbx,%rax)
    e3d8:      	xorl	%edi, %edi
    e3da:      	cmpl	%r15d, %r12d
    e3dd:      	seta	%dil
    e3e1:      	movzbl	%cl, %esi
    e3e4:      	addq	%rax, %rbx
    e3e7:      	addq	%rbx, %rdi
    e3ea:      	movl	$0x4, %eax
    e3ef:      	callq	*%rax
    e3f1:      	movq	%rbx, 0x48(%rsp)
    e3f6:      	cmpl	%r15d, %r12d
    e3f9:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    e3ff:      	movq	0x8(%rsp), %r12
    e404:      	movq	%r12, 0x30(%rsp)
    e409:      	movq	0x38(%rsp), %rdx
    e40e:      	movq	0x40(%rsp), %r15
    e413:      	jmp	0xe466 <generic_fentry_path+0x3186>
    e415:      	leaq	0x10(%r15), %rdx
    e419:      	movl	$0x4, %eax
    e41e:      	movq	%rbp, %rdi
    e421:      	movl	$0x8, %esi
    e426:      	callq	*%rax
    e428:      	movq	0x40(%rsp), %rax
    e42d:      	cmpq	(%rsp), %rax
    e431:      	je	0x16d4d <generic_fentry_path+0xba6d>
    e437:      	addq	$0x18, %r15
    e43b:      	movl	$0x4, %eax
    e440:      	leaq	0x30(%rsp), %rdi
    e445:      	movl	$0x8, %esi
    e44a:      	movq	%r15, %rdx
    e44d:      	callq	*%rax
    e44f:      	movq	(%rsp), %r15
    e453:      	movq	%r15, 0x40(%rsp)
    e458:      	leaq	0x20(%r15), %rdx
    e45c:      	movq	%rdx, 0x38(%rsp)
    e461:      	movq	0x30(%rsp), %r12
    e466:      	cmpq	0x18(%rsp), %r12
    e46b:      	jne	0xe478 <generic_fentry_path+0x3198>
    e46d:      	cmpq	0x20(%rsp), %rdx
    e472:      	je	0x16d4d <generic_fentry_path+0xba6d>
    e478:      	movl	$0x4, %eax
    e47d:      	leaq	0x10(%rsp), %rdi
    e482:      	movl	$0x8, %esi
    e487:      	callq	*%rax
    e489:      	cmpq	0x10(%rsp), %r12
    e48e:      	je	0xe586 <generic_fentry_path+0x32a6>
    e494:      	leaq	0x18(%r12), %rbx
    e499:      	movl	$0x4, %eax
    e49e:      	movq	%rbp, %rdi
    e4a1:      	movl	$0x8, %esi
    e4a6:      	movq	%rbx, %rdx
    e4a9:      	callq	*%rax
    e4ab:      	cmpq	%r12, (%rsp)
    e4af:      	je	0xe586 <generic_fentry_path+0x32a6>
    e4b5:      	movl	$0x4, %eax
    e4ba:      	leaq	0x8(%rsp), %rdi
    e4bf:      	movl	$0x8, %esi
    e4c4:      	movq	%rbx, %rdx
    e4c7:      	callq	*%rax
    e4c9:      	addq	$0x20, %r12
    e4cd:      	movl	$0x4, %eax
    e4d2:      	leaq	0x58(%rsp), %rdi
    e4d7:      	movl	$0x10, %ecx
    e4dc:      	movl	$0x10, %esi
    e4e1:      	movq	%r12, %rdx
    e4e4:      	callq	*%rax
    e4e6:      	movq	0x28(%rsp), %rbx
    e4eb:      	movq	0x48(%rsp), %rax
    e4f0:      	movl	0x5c(%rsp), %r15d
    e4f5:      	subq	%rbx, %rax
    e4f8:      	movl	0x50(%rsp), %r12d
    e4fd:      	movl	%r15d, %edx
    e500:      	subl	%r12d, %edx
    e503:      	movl	$0x0, %ecx
    e508:      	cmovbl	%ecx, %edx
    e50b:      	addq	0x60(%rsp), %rdx
    e510:      	xorl	%esi, %esi
    e512:      	cmpl	%r15d, %r12d
    e515:      	seta	%sil
    e519:      	movl	%r15d, %ecx
    e51c:      	cmovbl	%r12d, %ecx
    e520:      	addl	%ecx, %esi
    e522:      	movl	%r12d, %edi
    e525:      	subl	%esi, %edi
    e527:      	movl	%edi, 0x50(%rsp)
    e52b:      	subq	%rsi, %rax
    e52e:      	jb	0x16d52 <generic_fentry_path+0xba72>
    e534:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e53a:      	ja	0x16d52 <generic_fentry_path+0xba72>
    e540:      	cmpl	%r15d, %r12d
    e543:      	jbe	0xe549 <generic_fentry_path+0x3269>
    e545:      	movb	$0x2f, (%rbx,%rax)
    e549:      	xorl	%edi, %edi
    e54b:      	cmpl	%r15d, %r12d
    e54e:      	seta	%dil
    e552:      	movzbl	%cl, %esi
    e555:      	addq	%rax, %rbx
    e558:      	addq	%rbx, %rdi
    e55b:      	movl	$0x4, %eax
    e560:      	callq	*%rax
    e562:      	movq	%rbx, 0x48(%rsp)
    e567:      	cmpl	%r15d, %r12d
    e56a:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    e570:      	movq	0x8(%rsp), %r12
    e575:      	movq	%r12, 0x30(%rsp)
    e57a:      	movq	0x38(%rsp), %rdx
    e57f:      	movq	0x40(%rsp), %r15
    e584:      	jmp	0xe5d7 <generic_fentry_path+0x32f7>
    e586:      	leaq	0x10(%r15), %rdx
    e58a:      	movl	$0x4, %eax
    e58f:      	movq	%rbp, %rdi
    e592:      	movl	$0x8, %esi
    e597:      	callq	*%rax
    e599:      	movq	0x40(%rsp), %rax
    e59e:      	cmpq	(%rsp), %rax
    e5a2:      	je	0x16d4d <generic_fentry_path+0xba6d>
    e5a8:      	addq	$0x18, %r15
    e5ac:      	movl	$0x4, %eax
    e5b1:      	leaq	0x30(%rsp), %rdi
    e5b6:      	movl	$0x8, %esi
    e5bb:      	movq	%r15, %rdx
    e5be:      	callq	*%rax
    e5c0:      	movq	(%rsp), %r15
    e5c4:      	movq	%r15, 0x40(%rsp)
    e5c9:      	leaq	0x20(%r15), %rdx
    e5cd:      	movq	%rdx, 0x38(%rsp)
    e5d2:      	movq	0x30(%rsp), %r12
    e5d7:      	cmpq	0x18(%rsp), %r12
    e5dc:      	jne	0xe5e9 <generic_fentry_path+0x3309>
    e5de:      	cmpq	0x20(%rsp), %rdx
    e5e3:      	je	0x16d4d <generic_fentry_path+0xba6d>
    e5e9:      	movl	$0x4, %eax
    e5ee:      	leaq	0x10(%rsp), %rdi
    e5f3:      	movl	$0x8, %esi
    e5f8:      	callq	*%rax
    e5fa:      	cmpq	0x10(%rsp), %r12
    e5ff:      	je	0xe6f7 <generic_fentry_path+0x3417>
    e605:      	leaq	0x18(%r12), %rbx
    e60a:      	movl	$0x4, %eax
    e60f:      	movq	%rbp, %rdi
    e612:      	movl	$0x8, %esi
    e617:      	movq	%rbx, %rdx
    e61a:      	callq	*%rax
    e61c:      	cmpq	%r12, (%rsp)
    e620:      	je	0xe6f7 <generic_fentry_path+0x3417>
    e626:      	movl	$0x4, %eax
    e62b:      	leaq	0x8(%rsp), %rdi
    e630:      	movl	$0x8, %esi
    e635:      	movq	%rbx, %rdx
    e638:      	callq	*%rax
    e63a:      	addq	$0x20, %r12
    e63e:      	movl	$0x4, %eax
    e643:      	leaq	0x58(%rsp), %rdi
    e648:      	movl	$0x10, %ecx
    e64d:      	movl	$0x10, %esi
    e652:      	movq	%r12, %rdx
    e655:      	callq	*%rax
    e657:      	movq	0x28(%rsp), %rbx
    e65c:      	movq	0x48(%rsp), %rax
    e661:      	movl	0x5c(%rsp), %r15d
    e666:      	subq	%rbx, %rax
    e669:      	movl	0x50(%rsp), %r12d
    e66e:      	movl	%r15d, %edx
    e671:      	subl	%r12d, %edx
    e674:      	movl	$0x0, %ecx
    e679:      	cmovbl	%ecx, %edx
    e67c:      	addq	0x60(%rsp), %rdx
    e681:      	xorl	%esi, %esi
    e683:      	cmpl	%r15d, %r12d
    e686:      	seta	%sil
    e68a:      	movl	%r15d, %ecx
    e68d:      	cmovbl	%r12d, %ecx
    e691:      	addl	%ecx, %esi
    e693:      	movl	%r12d, %edi
    e696:      	subl	%esi, %edi
    e698:      	movl	%edi, 0x50(%rsp)
    e69c:      	subq	%rsi, %rax
    e69f:      	jb	0x16d52 <generic_fentry_path+0xba72>
    e6a5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e6ab:      	ja	0x16d52 <generic_fentry_path+0xba72>
    e6b1:      	cmpl	%r15d, %r12d
    e6b4:      	jbe	0xe6ba <generic_fentry_path+0x33da>
    e6b6:      	movb	$0x2f, (%rbx,%rax)
    e6ba:      	xorl	%edi, %edi
    e6bc:      	cmpl	%r15d, %r12d
    e6bf:      	seta	%dil
    e6c3:      	movzbl	%cl, %esi
    e6c6:      	addq	%rax, %rbx
    e6c9:      	addq	%rbx, %rdi
    e6cc:      	movl	$0x4, %eax
    e6d1:      	callq	*%rax
    e6d3:      	movq	%rbx, 0x48(%rsp)
    e6d8:      	cmpl	%r15d, %r12d
    e6db:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    e6e1:      	movq	0x8(%rsp), %r12
    e6e6:      	movq	%r12, 0x30(%rsp)
    e6eb:      	movq	0x38(%rsp), %rdx
    e6f0:      	movq	0x40(%rsp), %r15
    e6f5:      	jmp	0xe748 <generic_fentry_path+0x3468>
    e6f7:      	leaq	0x10(%r15), %rdx
    e6fb:      	movl	$0x4, %eax
    e700:      	movq	%rbp, %rdi
    e703:      	movl	$0x8, %esi
    e708:      	callq	*%rax
    e70a:      	movq	0x40(%rsp), %rax
    e70f:      	cmpq	(%rsp), %rax
    e713:      	je	0x16d4d <generic_fentry_path+0xba6d>
    e719:      	addq	$0x18, %r15
    e71d:      	movl	$0x4, %eax
    e722:      	leaq	0x30(%rsp), %rdi
    e727:      	movl	$0x8, %esi
    e72c:      	movq	%r15, %rdx
    e72f:      	callq	*%rax
    e731:      	movq	(%rsp), %r15
    e735:      	movq	%r15, 0x40(%rsp)
    e73a:      	leaq	0x20(%r15), %rdx
    e73e:      	movq	%rdx, 0x38(%rsp)
    e743:      	movq	0x30(%rsp), %r12
    e748:      	cmpq	0x18(%rsp), %r12
    e74d:      	jne	0xe75a <generic_fentry_path+0x347a>
    e74f:      	cmpq	0x20(%rsp), %rdx
    e754:      	je	0x16d4d <generic_fentry_path+0xba6d>
    e75a:      	movl	$0x4, %eax
    e75f:      	leaq	0x10(%rsp), %rdi
    e764:      	movl	$0x8, %esi
    e769:      	callq	*%rax
    e76b:      	cmpq	0x10(%rsp), %r12
    e770:      	je	0xe868 <generic_fentry_path+0x3588>
    e776:      	leaq	0x18(%r12), %rbx
    e77b:      	movl	$0x4, %eax
    e780:      	movq	%rbp, %rdi
    e783:      	movl	$0x8, %esi
    e788:      	movq	%rbx, %rdx
    e78b:      	callq	*%rax
    e78d:      	cmpq	%r12, (%rsp)
    e791:      	je	0xe868 <generic_fentry_path+0x3588>
    e797:      	movl	$0x4, %eax
    e79c:      	leaq	0x8(%rsp), %rdi
    e7a1:      	movl	$0x8, %esi
    e7a6:      	movq	%rbx, %rdx
    e7a9:      	callq	*%rax
    e7ab:      	addq	$0x20, %r12
    e7af:      	movl	$0x4, %eax
    e7b4:      	leaq	0x58(%rsp), %rdi
    e7b9:      	movl	$0x10, %ecx
    e7be:      	movl	$0x10, %esi
    e7c3:      	movq	%r12, %rdx
    e7c6:      	callq	*%rax
    e7c8:      	movq	0x28(%rsp), %rbx
    e7cd:      	movq	0x48(%rsp), %rax
    e7d2:      	movl	0x5c(%rsp), %r15d
    e7d7:      	subq	%rbx, %rax
    e7da:      	movl	0x50(%rsp), %r12d
    e7df:      	movl	%r15d, %edx
    e7e2:      	subl	%r12d, %edx
    e7e5:      	movl	$0x0, %ecx
    e7ea:      	cmovbl	%ecx, %edx
    e7ed:      	addq	0x60(%rsp), %rdx
    e7f2:      	xorl	%esi, %esi
    e7f4:      	cmpl	%r15d, %r12d
    e7f7:      	seta	%sil
    e7fb:      	movl	%r15d, %ecx
    e7fe:      	cmovbl	%r12d, %ecx
    e802:      	addl	%ecx, %esi
    e804:      	movl	%r12d, %edi
    e807:      	subl	%esi, %edi
    e809:      	movl	%edi, 0x50(%rsp)
    e80d:      	subq	%rsi, %rax
    e810:      	jb	0x16d52 <generic_fentry_path+0xba72>
    e816:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e81c:      	ja	0x16d52 <generic_fentry_path+0xba72>
    e822:      	cmpl	%r15d, %r12d
    e825:      	jbe	0xe82b <generic_fentry_path+0x354b>
    e827:      	movb	$0x2f, (%rbx,%rax)
    e82b:      	xorl	%edi, %edi
    e82d:      	cmpl	%r15d, %r12d
    e830:      	seta	%dil
    e834:      	movzbl	%cl, %esi
    e837:      	addq	%rax, %rbx
    e83a:      	addq	%rbx, %rdi
    e83d:      	movl	$0x4, %eax
    e842:      	callq	*%rax
    e844:      	movq	%rbx, 0x48(%rsp)
    e849:      	cmpl	%r15d, %r12d
    e84c:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    e852:      	movq	0x8(%rsp), %r12
    e857:      	movq	%r12, 0x30(%rsp)
    e85c:      	movq	0x38(%rsp), %rdx
    e861:      	movq	0x40(%rsp), %r15
    e866:      	jmp	0xe8b9 <generic_fentry_path+0x35d9>
    e868:      	leaq	0x10(%r15), %rdx
    e86c:      	movl	$0x4, %eax
    e871:      	movq	%rbp, %rdi
    e874:      	movl	$0x8, %esi
    e879:      	callq	*%rax
    e87b:      	movq	0x40(%rsp), %rax
    e880:      	cmpq	(%rsp), %rax
    e884:      	je	0x16d4d <generic_fentry_path+0xba6d>
    e88a:      	addq	$0x18, %r15
    e88e:      	movl	$0x4, %eax
    e893:      	leaq	0x30(%rsp), %rdi
    e898:      	movl	$0x8, %esi
    e89d:      	movq	%r15, %rdx
    e8a0:      	callq	*%rax
    e8a2:      	movq	(%rsp), %r15
    e8a6:      	movq	%r15, 0x40(%rsp)
    e8ab:      	leaq	0x20(%r15), %rdx
    e8af:      	movq	%rdx, 0x38(%rsp)
    e8b4:      	movq	0x30(%rsp), %r12
    e8b9:      	cmpq	0x18(%rsp), %r12
    e8be:      	jne	0xe8cb <generic_fentry_path+0x35eb>
    e8c0:      	cmpq	0x20(%rsp), %rdx
    e8c5:      	je	0x16d4d <generic_fentry_path+0xba6d>
    e8cb:      	movl	$0x4, %eax
    e8d0:      	leaq	0x10(%rsp), %rdi
    e8d5:      	movl	$0x8, %esi
    e8da:      	callq	*%rax
    e8dc:      	cmpq	0x10(%rsp), %r12
    e8e1:      	je	0xe9d9 <generic_fentry_path+0x36f9>
    e8e7:      	leaq	0x18(%r12), %rbx
    e8ec:      	movl	$0x4, %eax
    e8f1:      	movq	%rbp, %rdi
    e8f4:      	movl	$0x8, %esi
    e8f9:      	movq	%rbx, %rdx
    e8fc:      	callq	*%rax
    e8fe:      	cmpq	%r12, (%rsp)
    e902:      	je	0xe9d9 <generic_fentry_path+0x36f9>
    e908:      	movl	$0x4, %eax
    e90d:      	leaq	0x8(%rsp), %rdi
    e912:      	movl	$0x8, %esi
    e917:      	movq	%rbx, %rdx
    e91a:      	callq	*%rax
    e91c:      	addq	$0x20, %r12
    e920:      	movl	$0x4, %eax
    e925:      	leaq	0x58(%rsp), %rdi
    e92a:      	movl	$0x10, %ecx
    e92f:      	movl	$0x10, %esi
    e934:      	movq	%r12, %rdx
    e937:      	callq	*%rax
    e939:      	movq	0x28(%rsp), %rbx
    e93e:      	movq	0x48(%rsp), %rax
    e943:      	movl	0x5c(%rsp), %r15d
    e948:      	subq	%rbx, %rax
    e94b:      	movl	0x50(%rsp), %r12d
    e950:      	movl	%r15d, %edx
    e953:      	subl	%r12d, %edx
    e956:      	movl	$0x0, %ecx
    e95b:      	cmovbl	%ecx, %edx
    e95e:      	addq	0x60(%rsp), %rdx
    e963:      	xorl	%esi, %esi
    e965:      	cmpl	%r15d, %r12d
    e968:      	seta	%sil
    e96c:      	movl	%r15d, %ecx
    e96f:      	cmovbl	%r12d, %ecx
    e973:      	addl	%ecx, %esi
    e975:      	movl	%r12d, %edi
    e978:      	subl	%esi, %edi
    e97a:      	movl	%edi, 0x50(%rsp)
    e97e:      	subq	%rsi, %rax
    e981:      	jb	0x16d52 <generic_fentry_path+0xba72>
    e987:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e98d:      	ja	0x16d52 <generic_fentry_path+0xba72>
    e993:      	cmpl	%r15d, %r12d
    e996:      	jbe	0xe99c <generic_fentry_path+0x36bc>
    e998:      	movb	$0x2f, (%rbx,%rax)
    e99c:      	xorl	%edi, %edi
    e99e:      	cmpl	%r15d, %r12d
    e9a1:      	seta	%dil
    e9a5:      	movzbl	%cl, %esi
    e9a8:      	addq	%rax, %rbx
    e9ab:      	addq	%rbx, %rdi
    e9ae:      	movl	$0x4, %eax
    e9b3:      	callq	*%rax
    e9b5:      	movq	%rbx, 0x48(%rsp)
    e9ba:      	cmpl	%r15d, %r12d
    e9bd:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    e9c3:      	movq	0x8(%rsp), %r12
    e9c8:      	movq	%r12, 0x30(%rsp)
    e9cd:      	movq	0x38(%rsp), %rdx
    e9d2:      	movq	0x40(%rsp), %r15
    e9d7:      	jmp	0xea2a <generic_fentry_path+0x374a>
    e9d9:      	leaq	0x10(%r15), %rdx
    e9dd:      	movl	$0x4, %eax
    e9e2:      	movq	%rbp, %rdi
    e9e5:      	movl	$0x8, %esi
    e9ea:      	callq	*%rax
    e9ec:      	movq	0x40(%rsp), %rax
    e9f1:      	cmpq	(%rsp), %rax
    e9f5:      	je	0x16d4d <generic_fentry_path+0xba6d>
    e9fb:      	addq	$0x18, %r15
    e9ff:      	movl	$0x4, %eax
    ea04:      	leaq	0x30(%rsp), %rdi
    ea09:      	movl	$0x8, %esi
    ea0e:      	movq	%r15, %rdx
    ea11:      	callq	*%rax
    ea13:      	movq	(%rsp), %r15
    ea17:      	movq	%r15, 0x40(%rsp)
    ea1c:      	leaq	0x20(%r15), %rdx
    ea20:      	movq	%rdx, 0x38(%rsp)
    ea25:      	movq	0x30(%rsp), %r12
    ea2a:      	cmpq	0x18(%rsp), %r12
    ea2f:      	jne	0xea3c <generic_fentry_path+0x375c>
    ea31:      	cmpq	0x20(%rsp), %rdx
    ea36:      	je	0x16d4d <generic_fentry_path+0xba6d>
    ea3c:      	movl	$0x4, %eax
    ea41:      	leaq	0x10(%rsp), %rdi
    ea46:      	movl	$0x8, %esi
    ea4b:      	callq	*%rax
    ea4d:      	cmpq	0x10(%rsp), %r12
    ea52:      	je	0xeb4a <generic_fentry_path+0x386a>
    ea58:      	leaq	0x18(%r12), %rbx
    ea5d:      	movl	$0x4, %eax
    ea62:      	movq	%rbp, %rdi
    ea65:      	movl	$0x8, %esi
    ea6a:      	movq	%rbx, %rdx
    ea6d:      	callq	*%rax
    ea6f:      	cmpq	%r12, (%rsp)
    ea73:      	je	0xeb4a <generic_fentry_path+0x386a>
    ea79:      	movl	$0x4, %eax
    ea7e:      	leaq	0x8(%rsp), %rdi
    ea83:      	movl	$0x8, %esi
    ea88:      	movq	%rbx, %rdx
    ea8b:      	callq	*%rax
    ea8d:      	addq	$0x20, %r12
    ea91:      	movl	$0x4, %eax
    ea96:      	leaq	0x58(%rsp), %rdi
    ea9b:      	movl	$0x10, %ecx
    eaa0:      	movl	$0x10, %esi
    eaa5:      	movq	%r12, %rdx
    eaa8:      	callq	*%rax
    eaaa:      	movq	0x28(%rsp), %rbx
    eaaf:      	movq	0x48(%rsp), %rax
    eab4:      	movl	0x5c(%rsp), %r15d
    eab9:      	subq	%rbx, %rax
    eabc:      	movl	0x50(%rsp), %r12d
    eac1:      	movl	%r15d, %edx
    eac4:      	subl	%r12d, %edx
    eac7:      	movl	$0x0, %ecx
    eacc:      	cmovbl	%ecx, %edx
    eacf:      	addq	0x60(%rsp), %rdx
    ead4:      	xorl	%esi, %esi
    ead6:      	cmpl	%r15d, %r12d
    ead9:      	seta	%sil
    eadd:      	movl	%r15d, %ecx
    eae0:      	cmovbl	%r12d, %ecx
    eae4:      	addl	%ecx, %esi
    eae6:      	movl	%r12d, %edi
    eae9:      	subl	%esi, %edi
    eaeb:      	movl	%edi, 0x50(%rsp)
    eaef:      	subq	%rsi, %rax
    eaf2:      	jb	0x16d52 <generic_fentry_path+0xba72>
    eaf8:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    eafe:      	ja	0x16d52 <generic_fentry_path+0xba72>
    eb04:      	cmpl	%r15d, %r12d
    eb07:      	jbe	0xeb0d <generic_fentry_path+0x382d>
    eb09:      	movb	$0x2f, (%rbx,%rax)
    eb0d:      	xorl	%edi, %edi
    eb0f:      	cmpl	%r15d, %r12d
    eb12:      	seta	%dil
    eb16:      	movzbl	%cl, %esi
    eb19:      	addq	%rax, %rbx
    eb1c:      	addq	%rbx, %rdi
    eb1f:      	movl	$0x4, %eax
    eb24:      	callq	*%rax
    eb26:      	movq	%rbx, 0x48(%rsp)
    eb2b:      	cmpl	%r15d, %r12d
    eb2e:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    eb34:      	movq	0x8(%rsp), %r12
    eb39:      	movq	%r12, 0x30(%rsp)
    eb3e:      	movq	0x38(%rsp), %rdx
    eb43:      	movq	0x40(%rsp), %r15
    eb48:      	jmp	0xeb9b <generic_fentry_path+0x38bb>
    eb4a:      	leaq	0x10(%r15), %rdx
    eb4e:      	movl	$0x4, %eax
    eb53:      	movq	%rbp, %rdi
    eb56:      	movl	$0x8, %esi
    eb5b:      	callq	*%rax
    eb5d:      	movq	0x40(%rsp), %rax
    eb62:      	cmpq	(%rsp), %rax
    eb66:      	je	0x16d4d <generic_fentry_path+0xba6d>
    eb6c:      	addq	$0x18, %r15
    eb70:      	movl	$0x4, %eax
    eb75:      	leaq	0x30(%rsp), %rdi
    eb7a:      	movl	$0x8, %esi
    eb7f:      	movq	%r15, %rdx
    eb82:      	callq	*%rax
    eb84:      	movq	(%rsp), %r15
    eb88:      	movq	%r15, 0x40(%rsp)
    eb8d:      	leaq	0x20(%r15), %rdx
    eb91:      	movq	%rdx, 0x38(%rsp)
    eb96:      	movq	0x30(%rsp), %r12
    eb9b:      	cmpq	0x18(%rsp), %r12
    eba0:      	jne	0xebad <generic_fentry_path+0x38cd>
    eba2:      	cmpq	0x20(%rsp), %rdx
    eba7:      	je	0x16d4d <generic_fentry_path+0xba6d>
    ebad:      	movl	$0x4, %eax
    ebb2:      	leaq	0x10(%rsp), %rdi
    ebb7:      	movl	$0x8, %esi
    ebbc:      	callq	*%rax
    ebbe:      	cmpq	0x10(%rsp), %r12
    ebc3:      	je	0xecbb <generic_fentry_path+0x39db>
    ebc9:      	leaq	0x18(%r12), %rbx
    ebce:      	movl	$0x4, %eax
    ebd3:      	movq	%rbp, %rdi
    ebd6:      	movl	$0x8, %esi
    ebdb:      	movq	%rbx, %rdx
    ebde:      	callq	*%rax
    ebe0:      	cmpq	%r12, (%rsp)
    ebe4:      	je	0xecbb <generic_fentry_path+0x39db>
    ebea:      	movl	$0x4, %eax
    ebef:      	leaq	0x8(%rsp), %rdi
    ebf4:      	movl	$0x8, %esi
    ebf9:      	movq	%rbx, %rdx
    ebfc:      	callq	*%rax
    ebfe:      	addq	$0x20, %r12
    ec02:      	movl	$0x4, %eax
    ec07:      	leaq	0x58(%rsp), %rdi
    ec0c:      	movl	$0x10, %ecx
    ec11:      	movl	$0x10, %esi
    ec16:      	movq	%r12, %rdx
    ec19:      	callq	*%rax
    ec1b:      	movq	0x28(%rsp), %rbx
    ec20:      	movq	0x48(%rsp), %rax
    ec25:      	movl	0x5c(%rsp), %r15d
    ec2a:      	subq	%rbx, %rax
    ec2d:      	movl	0x50(%rsp), %r12d
    ec32:      	movl	%r15d, %edx
    ec35:      	subl	%r12d, %edx
    ec38:      	movl	$0x0, %ecx
    ec3d:      	cmovbl	%ecx, %edx
    ec40:      	addq	0x60(%rsp), %rdx
    ec45:      	xorl	%esi, %esi
    ec47:      	cmpl	%r15d, %r12d
    ec4a:      	seta	%sil
    ec4e:      	movl	%r15d, %ecx
    ec51:      	cmovbl	%r12d, %ecx
    ec55:      	addl	%ecx, %esi
    ec57:      	movl	%r12d, %edi
    ec5a:      	subl	%esi, %edi
    ec5c:      	movl	%edi, 0x50(%rsp)
    ec60:      	subq	%rsi, %rax
    ec63:      	jb	0x16d52 <generic_fentry_path+0xba72>
    ec69:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ec6f:      	ja	0x16d52 <generic_fentry_path+0xba72>
    ec75:      	cmpl	%r15d, %r12d
    ec78:      	jbe	0xec7e <generic_fentry_path+0x399e>
    ec7a:      	movb	$0x2f, (%rbx,%rax)
    ec7e:      	xorl	%edi, %edi
    ec80:      	cmpl	%r15d, %r12d
    ec83:      	seta	%dil
    ec87:      	movzbl	%cl, %esi
    ec8a:      	addq	%rax, %rbx
    ec8d:      	addq	%rbx, %rdi
    ec90:      	movl	$0x4, %eax
    ec95:      	callq	*%rax
    ec97:      	movq	%rbx, 0x48(%rsp)
    ec9c:      	cmpl	%r15d, %r12d
    ec9f:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    eca5:      	movq	0x8(%rsp), %r12
    ecaa:      	movq	%r12, 0x30(%rsp)
    ecaf:      	movq	0x38(%rsp), %rdx
    ecb4:      	movq	0x40(%rsp), %r15
    ecb9:      	jmp	0xed0c <generic_fentry_path+0x3a2c>
    ecbb:      	leaq	0x10(%r15), %rdx
    ecbf:      	movl	$0x4, %eax
    ecc4:      	movq	%rbp, %rdi
    ecc7:      	movl	$0x8, %esi
    eccc:      	callq	*%rax
    ecce:      	movq	0x40(%rsp), %rax
    ecd3:      	cmpq	(%rsp), %rax
    ecd7:      	je	0x16d4d <generic_fentry_path+0xba6d>
    ecdd:      	addq	$0x18, %r15
    ece1:      	movl	$0x4, %eax
    ece6:      	leaq	0x30(%rsp), %rdi
    eceb:      	movl	$0x8, %esi
    ecf0:      	movq	%r15, %rdx
    ecf3:      	callq	*%rax
    ecf5:      	movq	(%rsp), %r15
    ecf9:      	movq	%r15, 0x40(%rsp)
    ecfe:      	leaq	0x20(%r15), %rdx
    ed02:      	movq	%rdx, 0x38(%rsp)
    ed07:      	movq	0x30(%rsp), %r12
    ed0c:      	cmpq	0x18(%rsp), %r12
    ed11:      	jne	0xed1e <generic_fentry_path+0x3a3e>
    ed13:      	cmpq	0x20(%rsp), %rdx
    ed18:      	je	0x16d4d <generic_fentry_path+0xba6d>
    ed1e:      	movl	$0x4, %eax
    ed23:      	leaq	0x10(%rsp), %rdi
    ed28:      	movl	$0x8, %esi
    ed2d:      	callq	*%rax
    ed2f:      	cmpq	0x10(%rsp), %r12
    ed34:      	je	0xee2c <generic_fentry_path+0x3b4c>
    ed3a:      	leaq	0x18(%r12), %rbx
    ed3f:      	movl	$0x4, %eax
    ed44:      	movq	%rbp, %rdi
    ed47:      	movl	$0x8, %esi
    ed4c:      	movq	%rbx, %rdx
    ed4f:      	callq	*%rax
    ed51:      	cmpq	%r12, (%rsp)
    ed55:      	je	0xee2c <generic_fentry_path+0x3b4c>
    ed5b:      	movl	$0x4, %eax
    ed60:      	leaq	0x8(%rsp), %rdi
    ed65:      	movl	$0x8, %esi
    ed6a:      	movq	%rbx, %rdx
    ed6d:      	callq	*%rax
    ed6f:      	addq	$0x20, %r12
    ed73:      	movl	$0x4, %eax
    ed78:      	leaq	0x58(%rsp), %rdi
    ed7d:      	movl	$0x10, %ecx
    ed82:      	movl	$0x10, %esi
    ed87:      	movq	%r12, %rdx
    ed8a:      	callq	*%rax
    ed8c:      	movq	0x28(%rsp), %rbx
    ed91:      	movq	0x48(%rsp), %rax
    ed96:      	movl	0x5c(%rsp), %r15d
    ed9b:      	subq	%rbx, %rax
    ed9e:      	movl	0x50(%rsp), %r12d
    eda3:      	movl	%r15d, %edx
    eda6:      	subl	%r12d, %edx
    eda9:      	movl	$0x0, %ecx
    edae:      	cmovbl	%ecx, %edx
    edb1:      	addq	0x60(%rsp), %rdx
    edb6:      	xorl	%esi, %esi
    edb8:      	cmpl	%r15d, %r12d
    edbb:      	seta	%sil
    edbf:      	movl	%r15d, %ecx
    edc2:      	cmovbl	%r12d, %ecx
    edc6:      	addl	%ecx, %esi
    edc8:      	movl	%r12d, %edi
    edcb:      	subl	%esi, %edi
    edcd:      	movl	%edi, 0x50(%rsp)
    edd1:      	subq	%rsi, %rax
    edd4:      	jb	0x16d52 <generic_fentry_path+0xba72>
    edda:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ede0:      	ja	0x16d52 <generic_fentry_path+0xba72>
    ede6:      	cmpl	%r15d, %r12d
    ede9:      	jbe	0xedef <generic_fentry_path+0x3b0f>
    edeb:      	movb	$0x2f, (%rbx,%rax)
    edef:      	xorl	%edi, %edi
    edf1:      	cmpl	%r15d, %r12d
    edf4:      	seta	%dil
    edf8:      	movzbl	%cl, %esi
    edfb:      	addq	%rax, %rbx
    edfe:      	addq	%rbx, %rdi
    ee01:      	movl	$0x4, %eax
    ee06:      	callq	*%rax
    ee08:      	movq	%rbx, 0x48(%rsp)
    ee0d:      	cmpl	%r15d, %r12d
    ee10:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    ee16:      	movq	0x8(%rsp), %r12
    ee1b:      	movq	%r12, 0x30(%rsp)
    ee20:      	movq	0x38(%rsp), %rdx
    ee25:      	movq	0x40(%rsp), %r15
    ee2a:      	jmp	0xee7d <generic_fentry_path+0x3b9d>
    ee2c:      	leaq	0x10(%r15), %rdx
    ee30:      	movl	$0x4, %eax
    ee35:      	movq	%rbp, %rdi
    ee38:      	movl	$0x8, %esi
    ee3d:      	callq	*%rax
    ee3f:      	movq	0x40(%rsp), %rax
    ee44:      	cmpq	(%rsp), %rax
    ee48:      	je	0x16d4d <generic_fentry_path+0xba6d>
    ee4e:      	addq	$0x18, %r15
    ee52:      	movl	$0x4, %eax
    ee57:      	leaq	0x30(%rsp), %rdi
    ee5c:      	movl	$0x8, %esi
    ee61:      	movq	%r15, %rdx
    ee64:      	callq	*%rax
    ee66:      	movq	(%rsp), %r15
    ee6a:      	movq	%r15, 0x40(%rsp)
    ee6f:      	leaq	0x20(%r15), %rdx
    ee73:      	movq	%rdx, 0x38(%rsp)
    ee78:      	movq	0x30(%rsp), %r12
    ee7d:      	cmpq	0x18(%rsp), %r12
    ee82:      	jne	0xee8f <generic_fentry_path+0x3baf>
    ee84:      	cmpq	0x20(%rsp), %rdx
    ee89:      	je	0x16d4d <generic_fentry_path+0xba6d>
    ee8f:      	movl	$0x4, %eax
    ee94:      	leaq	0x10(%rsp), %rdi
    ee99:      	movl	$0x8, %esi
    ee9e:      	callq	*%rax
    eea0:      	cmpq	0x10(%rsp), %r12
    eea5:      	je	0xef9d <generic_fentry_path+0x3cbd>
    eeab:      	leaq	0x18(%r12), %rbx
    eeb0:      	movl	$0x4, %eax
    eeb5:      	movq	%rbp, %rdi
    eeb8:      	movl	$0x8, %esi
    eebd:      	movq	%rbx, %rdx
    eec0:      	callq	*%rax
    eec2:      	cmpq	%r12, (%rsp)
    eec6:      	je	0xef9d <generic_fentry_path+0x3cbd>
    eecc:      	movl	$0x4, %eax
    eed1:      	leaq	0x8(%rsp), %rdi
    eed6:      	movl	$0x8, %esi
    eedb:      	movq	%rbx, %rdx
    eede:      	callq	*%rax
    eee0:      	addq	$0x20, %r12
    eee4:      	movl	$0x4, %eax
    eee9:      	leaq	0x58(%rsp), %rdi
    eeee:      	movl	$0x10, %ecx
    eef3:      	movl	$0x10, %esi
    eef8:      	movq	%r12, %rdx
    eefb:      	callq	*%rax
    eefd:      	movq	0x28(%rsp), %rbx
    ef02:      	movq	0x48(%rsp), %rax
    ef07:      	movl	0x5c(%rsp), %r15d
    ef0c:      	subq	%rbx, %rax
    ef0f:      	movl	0x50(%rsp), %r12d
    ef14:      	movl	%r15d, %edx
    ef17:      	subl	%r12d, %edx
    ef1a:      	movl	$0x0, %ecx
    ef1f:      	cmovbl	%ecx, %edx
    ef22:      	addq	0x60(%rsp), %rdx
    ef27:      	xorl	%esi, %esi
    ef29:      	cmpl	%r15d, %r12d
    ef2c:      	seta	%sil
    ef30:      	movl	%r15d, %ecx
    ef33:      	cmovbl	%r12d, %ecx
    ef37:      	addl	%ecx, %esi
    ef39:      	movl	%r12d, %edi
    ef3c:      	subl	%esi, %edi
    ef3e:      	movl	%edi, 0x50(%rsp)
    ef42:      	subq	%rsi, %rax
    ef45:      	jb	0x16d52 <generic_fentry_path+0xba72>
    ef4b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ef51:      	ja	0x16d52 <generic_fentry_path+0xba72>
    ef57:      	cmpl	%r15d, %r12d
    ef5a:      	jbe	0xef60 <generic_fentry_path+0x3c80>
    ef5c:      	movb	$0x2f, (%rbx,%rax)
    ef60:      	xorl	%edi, %edi
    ef62:      	cmpl	%r15d, %r12d
    ef65:      	seta	%dil
    ef69:      	movzbl	%cl, %esi
    ef6c:      	addq	%rax, %rbx
    ef6f:      	addq	%rbx, %rdi
    ef72:      	movl	$0x4, %eax
    ef77:      	callq	*%rax
    ef79:      	movq	%rbx, 0x48(%rsp)
    ef7e:      	cmpl	%r15d, %r12d
    ef81:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    ef87:      	movq	0x8(%rsp), %r12
    ef8c:      	movq	%r12, 0x30(%rsp)
    ef91:      	movq	0x38(%rsp), %rdx
    ef96:      	movq	0x40(%rsp), %r15
    ef9b:      	jmp	0xefee <generic_fentry_path+0x3d0e>
    ef9d:      	leaq	0x10(%r15), %rdx
    efa1:      	movl	$0x4, %eax
    efa6:      	movq	%rbp, %rdi
    efa9:      	movl	$0x8, %esi
    efae:      	callq	*%rax
    efb0:      	movq	0x40(%rsp), %rax
    efb5:      	cmpq	(%rsp), %rax
    efb9:      	je	0x16d4d <generic_fentry_path+0xba6d>
    efbf:      	addq	$0x18, %r15
    efc3:      	movl	$0x4, %eax
    efc8:      	leaq	0x30(%rsp), %rdi
    efcd:      	movl	$0x8, %esi
    efd2:      	movq	%r15, %rdx
    efd5:      	callq	*%rax
    efd7:      	movq	(%rsp), %r15
    efdb:      	movq	%r15, 0x40(%rsp)
    efe0:      	leaq	0x20(%r15), %rdx
    efe4:      	movq	%rdx, 0x38(%rsp)
    efe9:      	movq	0x30(%rsp), %r12
    efee:      	cmpq	0x18(%rsp), %r12
    eff3:      	jne	0xf000 <generic_fentry_path+0x3d20>
    eff5:      	cmpq	0x20(%rsp), %rdx
    effa:      	je	0x16d4d <generic_fentry_path+0xba6d>
    f000:      	movl	$0x4, %eax
    f005:      	leaq	0x10(%rsp), %rdi
    f00a:      	movl	$0x8, %esi
    f00f:      	callq	*%rax
    f011:      	cmpq	0x10(%rsp), %r12
    f016:      	je	0xf10e <generic_fentry_path+0x3e2e>
    f01c:      	leaq	0x18(%r12), %rbx
    f021:      	movl	$0x4, %eax
    f026:      	movq	%rbp, %rdi
    f029:      	movl	$0x8, %esi
    f02e:      	movq	%rbx, %rdx
    f031:      	callq	*%rax
    f033:      	cmpq	%r12, (%rsp)
    f037:      	je	0xf10e <generic_fentry_path+0x3e2e>
    f03d:      	movl	$0x4, %eax
    f042:      	leaq	0x8(%rsp), %rdi
    f047:      	movl	$0x8, %esi
    f04c:      	movq	%rbx, %rdx
    f04f:      	callq	*%rax
    f051:      	addq	$0x20, %r12
    f055:      	movl	$0x4, %eax
    f05a:      	leaq	0x58(%rsp), %rdi
    f05f:      	movl	$0x10, %ecx
    f064:      	movl	$0x10, %esi
    f069:      	movq	%r12, %rdx
    f06c:      	callq	*%rax
    f06e:      	movq	0x28(%rsp), %rbx
    f073:      	movq	0x48(%rsp), %rax
    f078:      	movl	0x5c(%rsp), %r15d
    f07d:      	subq	%rbx, %rax
    f080:      	movl	0x50(%rsp), %r12d
    f085:      	movl	%r15d, %edx
    f088:      	subl	%r12d, %edx
    f08b:      	movl	$0x0, %ecx
    f090:      	cmovbl	%ecx, %edx
    f093:      	addq	0x60(%rsp), %rdx
    f098:      	xorl	%esi, %esi
    f09a:      	cmpl	%r15d, %r12d
    f09d:      	seta	%sil
    f0a1:      	movl	%r15d, %ecx
    f0a4:      	cmovbl	%r12d, %ecx
    f0a8:      	addl	%ecx, %esi
    f0aa:      	movl	%r12d, %edi
    f0ad:      	subl	%esi, %edi
    f0af:      	movl	%edi, 0x50(%rsp)
    f0b3:      	subq	%rsi, %rax
    f0b6:      	jb	0x16d52 <generic_fentry_path+0xba72>
    f0bc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f0c2:      	ja	0x16d52 <generic_fentry_path+0xba72>
    f0c8:      	cmpl	%r15d, %r12d
    f0cb:      	jbe	0xf0d1 <generic_fentry_path+0x3df1>
    f0cd:      	movb	$0x2f, (%rbx,%rax)
    f0d1:      	xorl	%edi, %edi
    f0d3:      	cmpl	%r15d, %r12d
    f0d6:      	seta	%dil
    f0da:      	movzbl	%cl, %esi
    f0dd:      	addq	%rax, %rbx
    f0e0:      	addq	%rbx, %rdi
    f0e3:      	movl	$0x4, %eax
    f0e8:      	callq	*%rax
    f0ea:      	movq	%rbx, 0x48(%rsp)
    f0ef:      	cmpl	%r15d, %r12d
    f0f2:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    f0f8:      	movq	0x8(%rsp), %r12
    f0fd:      	movq	%r12, 0x30(%rsp)
    f102:      	movq	0x38(%rsp), %rdx
    f107:      	movq	0x40(%rsp), %r15
    f10c:      	jmp	0xf15f <generic_fentry_path+0x3e7f>
    f10e:      	leaq	0x10(%r15), %rdx
    f112:      	movl	$0x4, %eax
    f117:      	movq	%rbp, %rdi
    f11a:      	movl	$0x8, %esi
    f11f:      	callq	*%rax
    f121:      	movq	0x40(%rsp), %rax
    f126:      	cmpq	(%rsp), %rax
    f12a:      	je	0x16d4d <generic_fentry_path+0xba6d>
    f130:      	addq	$0x18, %r15
    f134:      	movl	$0x4, %eax
    f139:      	leaq	0x30(%rsp), %rdi
    f13e:      	movl	$0x8, %esi
    f143:      	movq	%r15, %rdx
    f146:      	callq	*%rax
    f148:      	movq	(%rsp), %r15
    f14c:      	movq	%r15, 0x40(%rsp)
    f151:      	leaq	0x20(%r15), %rdx
    f155:      	movq	%rdx, 0x38(%rsp)
    f15a:      	movq	0x30(%rsp), %r12
    f15f:      	cmpq	0x18(%rsp), %r12
    f164:      	jne	0xf171 <generic_fentry_path+0x3e91>
    f166:      	cmpq	0x20(%rsp), %rdx
    f16b:      	je	0x16d4d <generic_fentry_path+0xba6d>
    f171:      	movl	$0x4, %eax
    f176:      	leaq	0x10(%rsp), %rdi
    f17b:      	movl	$0x8, %esi
    f180:      	callq	*%rax
    f182:      	cmpq	0x10(%rsp), %r12
    f187:      	je	0xf27f <generic_fentry_path+0x3f9f>
    f18d:      	leaq	0x18(%r12), %rbx
    f192:      	movl	$0x4, %eax
    f197:      	movq	%rbp, %rdi
    f19a:      	movl	$0x8, %esi
    f19f:      	movq	%rbx, %rdx
    f1a2:      	callq	*%rax
    f1a4:      	cmpq	%r12, (%rsp)
    f1a8:      	je	0xf27f <generic_fentry_path+0x3f9f>
    f1ae:      	movl	$0x4, %eax
    f1b3:      	leaq	0x8(%rsp), %rdi
    f1b8:      	movl	$0x8, %esi
    f1bd:      	movq	%rbx, %rdx
    f1c0:      	callq	*%rax
    f1c2:      	addq	$0x20, %r12
    f1c6:      	movl	$0x4, %eax
    f1cb:      	leaq	0x58(%rsp), %rdi
    f1d0:      	movl	$0x10, %ecx
    f1d5:      	movl	$0x10, %esi
    f1da:      	movq	%r12, %rdx
    f1dd:      	callq	*%rax
    f1df:      	movq	0x28(%rsp), %rbx
    f1e4:      	movq	0x48(%rsp), %rax
    f1e9:      	movl	0x5c(%rsp), %r15d
    f1ee:      	subq	%rbx, %rax
    f1f1:      	movl	0x50(%rsp), %r12d
    f1f6:      	movl	%r15d, %edx
    f1f9:      	subl	%r12d, %edx
    f1fc:      	movl	$0x0, %ecx
    f201:      	cmovbl	%ecx, %edx
    f204:      	addq	0x60(%rsp), %rdx
    f209:      	xorl	%esi, %esi
    f20b:      	cmpl	%r15d, %r12d
    f20e:      	seta	%sil
    f212:      	movl	%r15d, %ecx
    f215:      	cmovbl	%r12d, %ecx
    f219:      	addl	%ecx, %esi
    f21b:      	movl	%r12d, %edi
    f21e:      	subl	%esi, %edi
    f220:      	movl	%edi, 0x50(%rsp)
    f224:      	subq	%rsi, %rax
    f227:      	jb	0x16d52 <generic_fentry_path+0xba72>
    f22d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f233:      	ja	0x16d52 <generic_fentry_path+0xba72>
    f239:      	cmpl	%r15d, %r12d
    f23c:      	jbe	0xf242 <generic_fentry_path+0x3f62>
    f23e:      	movb	$0x2f, (%rbx,%rax)
    f242:      	xorl	%edi, %edi
    f244:      	cmpl	%r15d, %r12d
    f247:      	seta	%dil
    f24b:      	movzbl	%cl, %esi
    f24e:      	addq	%rax, %rbx
    f251:      	addq	%rbx, %rdi
    f254:      	movl	$0x4, %eax
    f259:      	callq	*%rax
    f25b:      	movq	%rbx, 0x48(%rsp)
    f260:      	cmpl	%r15d, %r12d
    f263:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    f269:      	movq	0x8(%rsp), %r12
    f26e:      	movq	%r12, 0x30(%rsp)
    f273:      	movq	0x38(%rsp), %rdx
    f278:      	movq	0x40(%rsp), %r15
    f27d:      	jmp	0xf2d0 <generic_fentry_path+0x3ff0>
    f27f:      	leaq	0x10(%r15), %rdx
    f283:      	movl	$0x4, %eax
    f288:      	movq	%rbp, %rdi
    f28b:      	movl	$0x8, %esi
    f290:      	callq	*%rax
    f292:      	movq	0x40(%rsp), %rax
    f297:      	cmpq	(%rsp), %rax
    f29b:      	je	0x16d4d <generic_fentry_path+0xba6d>
    f2a1:      	addq	$0x18, %r15
    f2a5:      	movl	$0x4, %eax
    f2aa:      	leaq	0x30(%rsp), %rdi
    f2af:      	movl	$0x8, %esi
    f2b4:      	movq	%r15, %rdx
    f2b7:      	callq	*%rax
    f2b9:      	movq	(%rsp), %r15
    f2bd:      	movq	%r15, 0x40(%rsp)
    f2c2:      	leaq	0x20(%r15), %rdx
    f2c6:      	movq	%rdx, 0x38(%rsp)
    f2cb:      	movq	0x30(%rsp), %r12
    f2d0:      	cmpq	0x18(%rsp), %r12
    f2d5:      	jne	0xf2e2 <generic_fentry_path+0x4002>
    f2d7:      	cmpq	0x20(%rsp), %rdx
    f2dc:      	je	0x16d4d <generic_fentry_path+0xba6d>
    f2e2:      	movl	$0x4, %eax
    f2e7:      	leaq	0x10(%rsp), %rdi
    f2ec:      	movl	$0x8, %esi
    f2f1:      	callq	*%rax
    f2f3:      	cmpq	0x10(%rsp), %r12
    f2f8:      	je	0xf3f0 <generic_fentry_path+0x4110>
    f2fe:      	leaq	0x18(%r12), %rbx
    f303:      	movl	$0x4, %eax
    f308:      	movq	%rbp, %rdi
    f30b:      	movl	$0x8, %esi
    f310:      	movq	%rbx, %rdx
    f313:      	callq	*%rax
    f315:      	cmpq	%r12, (%rsp)
    f319:      	je	0xf3f0 <generic_fentry_path+0x4110>
    f31f:      	movl	$0x4, %eax
    f324:      	leaq	0x8(%rsp), %rdi
    f329:      	movl	$0x8, %esi
    f32e:      	movq	%rbx, %rdx
    f331:      	callq	*%rax
    f333:      	addq	$0x20, %r12
    f337:      	movl	$0x4, %eax
    f33c:      	leaq	0x58(%rsp), %rdi
    f341:      	movl	$0x10, %ecx
    f346:      	movl	$0x10, %esi
    f34b:      	movq	%r12, %rdx
    f34e:      	callq	*%rax
    f350:      	movq	0x28(%rsp), %rbx
    f355:      	movq	0x48(%rsp), %rax
    f35a:      	movl	0x5c(%rsp), %r15d
    f35f:      	subq	%rbx, %rax
    f362:      	movl	0x50(%rsp), %r12d
    f367:      	movl	%r15d, %edx
    f36a:      	subl	%r12d, %edx
    f36d:      	movl	$0x0, %ecx
    f372:      	cmovbl	%ecx, %edx
    f375:      	addq	0x60(%rsp), %rdx
    f37a:      	xorl	%esi, %esi
    f37c:      	cmpl	%r15d, %r12d
    f37f:      	seta	%sil
    f383:      	movl	%r15d, %ecx
    f386:      	cmovbl	%r12d, %ecx
    f38a:      	addl	%ecx, %esi
    f38c:      	movl	%r12d, %edi
    f38f:      	subl	%esi, %edi
    f391:      	movl	%edi, 0x50(%rsp)
    f395:      	subq	%rsi, %rax
    f398:      	jb	0x16d52 <generic_fentry_path+0xba72>
    f39e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f3a4:      	ja	0x16d52 <generic_fentry_path+0xba72>
    f3aa:      	cmpl	%r15d, %r12d
    f3ad:      	jbe	0xf3b3 <generic_fentry_path+0x40d3>
    f3af:      	movb	$0x2f, (%rbx,%rax)
    f3b3:      	xorl	%edi, %edi
    f3b5:      	cmpl	%r15d, %r12d
    f3b8:      	seta	%dil
    f3bc:      	movzbl	%cl, %esi
    f3bf:      	addq	%rax, %rbx
    f3c2:      	addq	%rbx, %rdi
    f3c5:      	movl	$0x4, %eax
    f3ca:      	callq	*%rax
    f3cc:      	movq	%rbx, 0x48(%rsp)
    f3d1:      	cmpl	%r15d, %r12d
    f3d4:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    f3da:      	movq	0x8(%rsp), %r12
    f3df:      	movq	%r12, 0x30(%rsp)
    f3e4:      	movq	0x38(%rsp), %rdx
    f3e9:      	movq	0x40(%rsp), %r15
    f3ee:      	jmp	0xf441 <generic_fentry_path+0x4161>
    f3f0:      	leaq	0x10(%r15), %rdx
    f3f4:      	movl	$0x4, %eax
    f3f9:      	movq	%rbp, %rdi
    f3fc:      	movl	$0x8, %esi
    f401:      	callq	*%rax
    f403:      	movq	0x40(%rsp), %rax
    f408:      	cmpq	(%rsp), %rax
    f40c:      	je	0x16d4d <generic_fentry_path+0xba6d>
    f412:      	addq	$0x18, %r15
    f416:      	movl	$0x4, %eax
    f41b:      	leaq	0x30(%rsp), %rdi
    f420:      	movl	$0x8, %esi
    f425:      	movq	%r15, %rdx
    f428:      	callq	*%rax
    f42a:      	movq	(%rsp), %r15
    f42e:      	movq	%r15, 0x40(%rsp)
    f433:      	leaq	0x20(%r15), %rdx
    f437:      	movq	%rdx, 0x38(%rsp)
    f43c:      	movq	0x30(%rsp), %r12
    f441:      	cmpq	0x18(%rsp), %r12
    f446:      	jne	0xf453 <generic_fentry_path+0x4173>
    f448:      	cmpq	0x20(%rsp), %rdx
    f44d:      	je	0x16d4d <generic_fentry_path+0xba6d>
    f453:      	movl	$0x4, %eax
    f458:      	leaq	0x10(%rsp), %rdi
    f45d:      	movl	$0x8, %esi
    f462:      	callq	*%rax
    f464:      	cmpq	0x10(%rsp), %r12
    f469:      	je	0xf561 <generic_fentry_path+0x4281>
    f46f:      	leaq	0x18(%r12), %rbx
    f474:      	movl	$0x4, %eax
    f479:      	movq	%rbp, %rdi
    f47c:      	movl	$0x8, %esi
    f481:      	movq	%rbx, %rdx
    f484:      	callq	*%rax
    f486:      	cmpq	%r12, (%rsp)
    f48a:      	je	0xf561 <generic_fentry_path+0x4281>
    f490:      	movl	$0x4, %eax
    f495:      	leaq	0x8(%rsp), %rdi
    f49a:      	movl	$0x8, %esi
    f49f:      	movq	%rbx, %rdx
    f4a2:      	callq	*%rax
    f4a4:      	addq	$0x20, %r12
    f4a8:      	movl	$0x4, %eax
    f4ad:      	leaq	0x58(%rsp), %rdi
    f4b2:      	movl	$0x10, %ecx
    f4b7:      	movl	$0x10, %esi
    f4bc:      	movq	%r12, %rdx
    f4bf:      	callq	*%rax
    f4c1:      	movq	0x28(%rsp), %rbx
    f4c6:      	movq	0x48(%rsp), %rax
    f4cb:      	movl	0x5c(%rsp), %r15d
    f4d0:      	subq	%rbx, %rax
    f4d3:      	movl	0x50(%rsp), %r12d
    f4d8:      	movl	%r15d, %edx
    f4db:      	subl	%r12d, %edx
    f4de:      	movl	$0x0, %ecx
    f4e3:      	cmovbl	%ecx, %edx
    f4e6:      	addq	0x60(%rsp), %rdx
    f4eb:      	xorl	%esi, %esi
    f4ed:      	cmpl	%r15d, %r12d
    f4f0:      	seta	%sil
    f4f4:      	movl	%r15d, %ecx
    f4f7:      	cmovbl	%r12d, %ecx
    f4fb:      	addl	%ecx, %esi
    f4fd:      	movl	%r12d, %edi
    f500:      	subl	%esi, %edi
    f502:      	movl	%edi, 0x50(%rsp)
    f506:      	subq	%rsi, %rax
    f509:      	jb	0x16d52 <generic_fentry_path+0xba72>
    f50f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f515:      	ja	0x16d52 <generic_fentry_path+0xba72>
    f51b:      	cmpl	%r15d, %r12d
    f51e:      	jbe	0xf524 <generic_fentry_path+0x4244>
    f520:      	movb	$0x2f, (%rbx,%rax)
    f524:      	xorl	%edi, %edi
    f526:      	cmpl	%r15d, %r12d
    f529:      	seta	%dil
    f52d:      	movzbl	%cl, %esi
    f530:      	addq	%rax, %rbx
    f533:      	addq	%rbx, %rdi
    f536:      	movl	$0x4, %eax
    f53b:      	callq	*%rax
    f53d:      	movq	%rbx, 0x48(%rsp)
    f542:      	cmpl	%r15d, %r12d
    f545:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    f54b:      	movq	0x8(%rsp), %r12
    f550:      	movq	%r12, 0x30(%rsp)
    f555:      	movq	0x38(%rsp), %rdx
    f55a:      	movq	0x40(%rsp), %r15
    f55f:      	jmp	0xf5b2 <generic_fentry_path+0x42d2>
    f561:      	leaq	0x10(%r15), %rdx
    f565:      	movl	$0x4, %eax
    f56a:      	movq	%rbp, %rdi
    f56d:      	movl	$0x8, %esi
    f572:      	callq	*%rax
    f574:      	movq	0x40(%rsp), %rax
    f579:      	cmpq	(%rsp), %rax
    f57d:      	je	0x16d4d <generic_fentry_path+0xba6d>
    f583:      	addq	$0x18, %r15
    f587:      	movl	$0x4, %eax
    f58c:      	leaq	0x30(%rsp), %rdi
    f591:      	movl	$0x8, %esi
    f596:      	movq	%r15, %rdx
    f599:      	callq	*%rax
    f59b:      	movq	(%rsp), %r15
    f59f:      	movq	%r15, 0x40(%rsp)
    f5a4:      	leaq	0x20(%r15), %rdx
    f5a8:      	movq	%rdx, 0x38(%rsp)
    f5ad:      	movq	0x30(%rsp), %r12
    f5b2:      	cmpq	0x18(%rsp), %r12
    f5b7:      	jne	0xf5c4 <generic_fentry_path+0x42e4>
    f5b9:      	cmpq	0x20(%rsp), %rdx
    f5be:      	je	0x16d4d <generic_fentry_path+0xba6d>
    f5c4:      	movl	$0x4, %eax
    f5c9:      	leaq	0x10(%rsp), %rdi
    f5ce:      	movl	$0x8, %esi
    f5d3:      	callq	*%rax
    f5d5:      	cmpq	0x10(%rsp), %r12
    f5da:      	je	0xf6d2 <generic_fentry_path+0x43f2>
    f5e0:      	leaq	0x18(%r12), %rbx
    f5e5:      	movl	$0x4, %eax
    f5ea:      	movq	%rbp, %rdi
    f5ed:      	movl	$0x8, %esi
    f5f2:      	movq	%rbx, %rdx
    f5f5:      	callq	*%rax
    f5f7:      	cmpq	%r12, (%rsp)
    f5fb:      	je	0xf6d2 <generic_fentry_path+0x43f2>
    f601:      	movl	$0x4, %eax
    f606:      	leaq	0x8(%rsp), %rdi
    f60b:      	movl	$0x8, %esi
    f610:      	movq	%rbx, %rdx
    f613:      	callq	*%rax
    f615:      	addq	$0x20, %r12
    f619:      	movl	$0x4, %eax
    f61e:      	leaq	0x58(%rsp), %rdi
    f623:      	movl	$0x10, %ecx
    f628:      	movl	$0x10, %esi
    f62d:      	movq	%r12, %rdx
    f630:      	callq	*%rax
    f632:      	movq	0x28(%rsp), %rbx
    f637:      	movq	0x48(%rsp), %rax
    f63c:      	movl	0x5c(%rsp), %r15d
    f641:      	subq	%rbx, %rax
    f644:      	movl	0x50(%rsp), %r12d
    f649:      	movl	%r15d, %edx
    f64c:      	subl	%r12d, %edx
    f64f:      	movl	$0x0, %ecx
    f654:      	cmovbl	%ecx, %edx
    f657:      	addq	0x60(%rsp), %rdx
    f65c:      	xorl	%esi, %esi
    f65e:      	cmpl	%r15d, %r12d
    f661:      	seta	%sil
    f665:      	movl	%r15d, %ecx
    f668:      	cmovbl	%r12d, %ecx
    f66c:      	addl	%ecx, %esi
    f66e:      	movl	%r12d, %edi
    f671:      	subl	%esi, %edi
    f673:      	movl	%edi, 0x50(%rsp)
    f677:      	subq	%rsi, %rax
    f67a:      	jb	0x16d52 <generic_fentry_path+0xba72>
    f680:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f686:      	ja	0x16d52 <generic_fentry_path+0xba72>
    f68c:      	cmpl	%r15d, %r12d
    f68f:      	jbe	0xf695 <generic_fentry_path+0x43b5>
    f691:      	movb	$0x2f, (%rbx,%rax)
    f695:      	xorl	%edi, %edi
    f697:      	cmpl	%r15d, %r12d
    f69a:      	seta	%dil
    f69e:      	movzbl	%cl, %esi
    f6a1:      	addq	%rax, %rbx
    f6a4:      	addq	%rbx, %rdi
    f6a7:      	movl	$0x4, %eax
    f6ac:      	callq	*%rax
    f6ae:      	movq	%rbx, 0x48(%rsp)
    f6b3:      	cmpl	%r15d, %r12d
    f6b6:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    f6bc:      	movq	0x8(%rsp), %r12
    f6c1:      	movq	%r12, 0x30(%rsp)
    f6c6:      	movq	0x38(%rsp), %rdx
    f6cb:      	movq	0x40(%rsp), %r15
    f6d0:      	jmp	0xf723 <generic_fentry_path+0x4443>
    f6d2:      	leaq	0x10(%r15), %rdx
    f6d6:      	movl	$0x4, %eax
    f6db:      	movq	%rbp, %rdi
    f6de:      	movl	$0x8, %esi
    f6e3:      	callq	*%rax
    f6e5:      	movq	0x40(%rsp), %rax
    f6ea:      	cmpq	(%rsp), %rax
    f6ee:      	je	0x16d4d <generic_fentry_path+0xba6d>
    f6f4:      	addq	$0x18, %r15
    f6f8:      	movl	$0x4, %eax
    f6fd:      	leaq	0x30(%rsp), %rdi
    f702:      	movl	$0x8, %esi
    f707:      	movq	%r15, %rdx
    f70a:      	callq	*%rax
    f70c:      	movq	(%rsp), %r15
    f710:      	movq	%r15, 0x40(%rsp)
    f715:      	leaq	0x20(%r15), %rdx
    f719:      	movq	%rdx, 0x38(%rsp)
    f71e:      	movq	0x30(%rsp), %r12
    f723:      	cmpq	0x18(%rsp), %r12
    f728:      	jne	0xf735 <generic_fentry_path+0x4455>
    f72a:      	cmpq	0x20(%rsp), %rdx
    f72f:      	je	0x16d4d <generic_fentry_path+0xba6d>
    f735:      	movl	$0x4, %eax
    f73a:      	leaq	0x10(%rsp), %rdi
    f73f:      	movl	$0x8, %esi
    f744:      	callq	*%rax
    f746:      	cmpq	0x10(%rsp), %r12
    f74b:      	je	0xf843 <generic_fentry_path+0x4563>
    f751:      	leaq	0x18(%r12), %rbx
    f756:      	movl	$0x4, %eax
    f75b:      	movq	%rbp, %rdi
    f75e:      	movl	$0x8, %esi
    f763:      	movq	%rbx, %rdx
    f766:      	callq	*%rax
    f768:      	cmpq	%r12, (%rsp)
    f76c:      	je	0xf843 <generic_fentry_path+0x4563>
    f772:      	movl	$0x4, %eax
    f777:      	leaq	0x8(%rsp), %rdi
    f77c:      	movl	$0x8, %esi
    f781:      	movq	%rbx, %rdx
    f784:      	callq	*%rax
    f786:      	addq	$0x20, %r12
    f78a:      	movl	$0x4, %eax
    f78f:      	leaq	0x58(%rsp), %rdi
    f794:      	movl	$0x10, %ecx
    f799:      	movl	$0x10, %esi
    f79e:      	movq	%r12, %rdx
    f7a1:      	callq	*%rax
    f7a3:      	movq	0x28(%rsp), %rbx
    f7a8:      	movq	0x48(%rsp), %rax
    f7ad:      	movl	0x5c(%rsp), %r15d
    f7b2:      	subq	%rbx, %rax
    f7b5:      	movl	0x50(%rsp), %r12d
    f7ba:      	movl	%r15d, %edx
    f7bd:      	subl	%r12d, %edx
    f7c0:      	movl	$0x0, %ecx
    f7c5:      	cmovbl	%ecx, %edx
    f7c8:      	addq	0x60(%rsp), %rdx
    f7cd:      	xorl	%esi, %esi
    f7cf:      	cmpl	%r15d, %r12d
    f7d2:      	seta	%sil
    f7d6:      	movl	%r15d, %ecx
    f7d9:      	cmovbl	%r12d, %ecx
    f7dd:      	addl	%ecx, %esi
    f7df:      	movl	%r12d, %edi
    f7e2:      	subl	%esi, %edi
    f7e4:      	movl	%edi, 0x50(%rsp)
    f7e8:      	subq	%rsi, %rax
    f7eb:      	jb	0x16d52 <generic_fentry_path+0xba72>
    f7f1:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f7f7:      	ja	0x16d52 <generic_fentry_path+0xba72>
    f7fd:      	cmpl	%r15d, %r12d
    f800:      	jbe	0xf806 <generic_fentry_path+0x4526>
    f802:      	movb	$0x2f, (%rbx,%rax)
    f806:      	xorl	%edi, %edi
    f808:      	cmpl	%r15d, %r12d
    f80b:      	seta	%dil
    f80f:      	movzbl	%cl, %esi
    f812:      	addq	%rax, %rbx
    f815:      	addq	%rbx, %rdi
    f818:      	movl	$0x4, %eax
    f81d:      	callq	*%rax
    f81f:      	movq	%rbx, 0x48(%rsp)
    f824:      	cmpl	%r15d, %r12d
    f827:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    f82d:      	movq	0x8(%rsp), %r12
    f832:      	movq	%r12, 0x30(%rsp)
    f837:      	movq	0x38(%rsp), %rdx
    f83c:      	movq	0x40(%rsp), %r15
    f841:      	jmp	0xf894 <generic_fentry_path+0x45b4>
    f843:      	leaq	0x10(%r15), %rdx
    f847:      	movl	$0x4, %eax
    f84c:      	movq	%rbp, %rdi
    f84f:      	movl	$0x8, %esi
    f854:      	callq	*%rax
    f856:      	movq	0x40(%rsp), %rax
    f85b:      	cmpq	(%rsp), %rax
    f85f:      	je	0x16d4d <generic_fentry_path+0xba6d>
    f865:      	addq	$0x18, %r15
    f869:      	movl	$0x4, %eax
    f86e:      	leaq	0x30(%rsp), %rdi
    f873:      	movl	$0x8, %esi
    f878:      	movq	%r15, %rdx
    f87b:      	callq	*%rax
    f87d:      	movq	(%rsp), %r15
    f881:      	movq	%r15, 0x40(%rsp)
    f886:      	leaq	0x20(%r15), %rdx
    f88a:      	movq	%rdx, 0x38(%rsp)
    f88f:      	movq	0x30(%rsp), %r12
    f894:      	cmpq	0x18(%rsp), %r12
    f899:      	jne	0xf8a6 <generic_fentry_path+0x45c6>
    f89b:      	cmpq	0x20(%rsp), %rdx
    f8a0:      	je	0x16d4d <generic_fentry_path+0xba6d>
    f8a6:      	movl	$0x4, %eax
    f8ab:      	leaq	0x10(%rsp), %rdi
    f8b0:      	movl	$0x8, %esi
    f8b5:      	callq	*%rax
    f8b7:      	cmpq	0x10(%rsp), %r12
    f8bc:      	je	0xf9b4 <generic_fentry_path+0x46d4>
    f8c2:      	leaq	0x18(%r12), %rbx
    f8c7:      	movl	$0x4, %eax
    f8cc:      	movq	%rbp, %rdi
    f8cf:      	movl	$0x8, %esi
    f8d4:      	movq	%rbx, %rdx
    f8d7:      	callq	*%rax
    f8d9:      	cmpq	%r12, (%rsp)
    f8dd:      	je	0xf9b4 <generic_fentry_path+0x46d4>
    f8e3:      	movl	$0x4, %eax
    f8e8:      	leaq	0x8(%rsp), %rdi
    f8ed:      	movl	$0x8, %esi
    f8f2:      	movq	%rbx, %rdx
    f8f5:      	callq	*%rax
    f8f7:      	addq	$0x20, %r12
    f8fb:      	movl	$0x4, %eax
    f900:      	leaq	0x58(%rsp), %rdi
    f905:      	movl	$0x10, %ecx
    f90a:      	movl	$0x10, %esi
    f90f:      	movq	%r12, %rdx
    f912:      	callq	*%rax
    f914:      	movq	0x28(%rsp), %rbx
    f919:      	movq	0x48(%rsp), %rax
    f91e:      	movl	0x5c(%rsp), %r15d
    f923:      	subq	%rbx, %rax
    f926:      	movl	0x50(%rsp), %r12d
    f92b:      	movl	%r15d, %edx
    f92e:      	subl	%r12d, %edx
    f931:      	movl	$0x0, %ecx
    f936:      	cmovbl	%ecx, %edx
    f939:      	addq	0x60(%rsp), %rdx
    f93e:      	xorl	%esi, %esi
    f940:      	cmpl	%r15d, %r12d
    f943:      	seta	%sil
    f947:      	movl	%r15d, %ecx
    f94a:      	cmovbl	%r12d, %ecx
    f94e:      	addl	%ecx, %esi
    f950:      	movl	%r12d, %edi
    f953:      	subl	%esi, %edi
    f955:      	movl	%edi, 0x50(%rsp)
    f959:      	subq	%rsi, %rax
    f95c:      	jb	0x16d52 <generic_fentry_path+0xba72>
    f962:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f968:      	ja	0x16d52 <generic_fentry_path+0xba72>
    f96e:      	cmpl	%r15d, %r12d
    f971:      	jbe	0xf977 <generic_fentry_path+0x4697>
    f973:      	movb	$0x2f, (%rbx,%rax)
    f977:      	xorl	%edi, %edi
    f979:      	cmpl	%r15d, %r12d
    f97c:      	seta	%dil
    f980:      	movzbl	%cl, %esi
    f983:      	addq	%rax, %rbx
    f986:      	addq	%rbx, %rdi
    f989:      	movl	$0x4, %eax
    f98e:      	callq	*%rax
    f990:      	movq	%rbx, 0x48(%rsp)
    f995:      	cmpl	%r15d, %r12d
    f998:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    f99e:      	movq	0x8(%rsp), %r12
    f9a3:      	movq	%r12, 0x30(%rsp)
    f9a8:      	movq	0x38(%rsp), %rdx
    f9ad:      	movq	0x40(%rsp), %r15
    f9b2:      	jmp	0xfa05 <generic_fentry_path+0x4725>
    f9b4:      	leaq	0x10(%r15), %rdx
    f9b8:      	movl	$0x4, %eax
    f9bd:      	movq	%rbp, %rdi
    f9c0:      	movl	$0x8, %esi
    f9c5:      	callq	*%rax
    f9c7:      	movq	0x40(%rsp), %rax
    f9cc:      	cmpq	(%rsp), %rax
    f9d0:      	je	0x16d4d <generic_fentry_path+0xba6d>
    f9d6:      	addq	$0x18, %r15
    f9da:      	movl	$0x4, %eax
    f9df:      	leaq	0x30(%rsp), %rdi
    f9e4:      	movl	$0x8, %esi
    f9e9:      	movq	%r15, %rdx
    f9ec:      	callq	*%rax
    f9ee:      	movq	(%rsp), %r15
    f9f2:      	movq	%r15, 0x40(%rsp)
    f9f7:      	leaq	0x20(%r15), %rdx
    f9fb:      	movq	%rdx, 0x38(%rsp)
    fa00:      	movq	0x30(%rsp), %r12
    fa05:      	cmpq	0x18(%rsp), %r12
    fa0a:      	jne	0xfa17 <generic_fentry_path+0x4737>
    fa0c:      	cmpq	0x20(%rsp), %rdx
    fa11:      	je	0x16d4d <generic_fentry_path+0xba6d>
    fa17:      	movl	$0x4, %eax
    fa1c:      	leaq	0x10(%rsp), %rdi
    fa21:      	movl	$0x8, %esi
    fa26:      	callq	*%rax
    fa28:      	cmpq	0x10(%rsp), %r12
    fa2d:      	je	0xfb25 <generic_fentry_path+0x4845>
    fa33:      	leaq	0x18(%r12), %rbx
    fa38:      	movl	$0x4, %eax
    fa3d:      	movq	%rbp, %rdi
    fa40:      	movl	$0x8, %esi
    fa45:      	movq	%rbx, %rdx
    fa48:      	callq	*%rax
    fa4a:      	cmpq	%r12, (%rsp)
    fa4e:      	je	0xfb25 <generic_fentry_path+0x4845>
    fa54:      	movl	$0x4, %eax
    fa59:      	leaq	0x8(%rsp), %rdi
    fa5e:      	movl	$0x8, %esi
    fa63:      	movq	%rbx, %rdx
    fa66:      	callq	*%rax
    fa68:      	addq	$0x20, %r12
    fa6c:      	movl	$0x4, %eax
    fa71:      	leaq	0x58(%rsp), %rdi
    fa76:      	movl	$0x10, %ecx
    fa7b:      	movl	$0x10, %esi
    fa80:      	movq	%r12, %rdx
    fa83:      	callq	*%rax
    fa85:      	movq	0x28(%rsp), %rbx
    fa8a:      	movq	0x48(%rsp), %rax
    fa8f:      	movl	0x5c(%rsp), %r15d
    fa94:      	subq	%rbx, %rax
    fa97:      	movl	0x50(%rsp), %r12d
    fa9c:      	movl	%r15d, %edx
    fa9f:      	subl	%r12d, %edx
    faa2:      	movl	$0x0, %ecx
    faa7:      	cmovbl	%ecx, %edx
    faaa:      	addq	0x60(%rsp), %rdx
    faaf:      	xorl	%esi, %esi
    fab1:      	cmpl	%r15d, %r12d
    fab4:      	seta	%sil
    fab8:      	movl	%r15d, %ecx
    fabb:      	cmovbl	%r12d, %ecx
    fabf:      	addl	%ecx, %esi
    fac1:      	movl	%r12d, %edi
    fac4:      	subl	%esi, %edi
    fac6:      	movl	%edi, 0x50(%rsp)
    faca:      	subq	%rsi, %rax
    facd:      	jb	0x16d52 <generic_fentry_path+0xba72>
    fad3:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    fad9:      	ja	0x16d52 <generic_fentry_path+0xba72>
    fadf:      	cmpl	%r15d, %r12d
    fae2:      	jbe	0xfae8 <generic_fentry_path+0x4808>
    fae4:      	movb	$0x2f, (%rbx,%rax)
    fae8:      	xorl	%edi, %edi
    faea:      	cmpl	%r15d, %r12d
    faed:      	seta	%dil
    faf1:      	movzbl	%cl, %esi
    faf4:      	addq	%rax, %rbx
    faf7:      	addq	%rbx, %rdi
    fafa:      	movl	$0x4, %eax
    faff:      	callq	*%rax
    fb01:      	movq	%rbx, 0x48(%rsp)
    fb06:      	cmpl	%r15d, %r12d
    fb09:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    fb0f:      	movq	0x8(%rsp), %r12
    fb14:      	movq	%r12, 0x30(%rsp)
    fb19:      	movq	0x38(%rsp), %rdx
    fb1e:      	movq	0x40(%rsp), %r15
    fb23:      	jmp	0xfb76 <generic_fentry_path+0x4896>
    fb25:      	leaq	0x10(%r15), %rdx
    fb29:      	movl	$0x4, %eax
    fb2e:      	movq	%rbp, %rdi
    fb31:      	movl	$0x8, %esi
    fb36:      	callq	*%rax
    fb38:      	movq	0x40(%rsp), %rax
    fb3d:      	cmpq	(%rsp), %rax
    fb41:      	je	0x16d4d <generic_fentry_path+0xba6d>
    fb47:      	addq	$0x18, %r15
    fb4b:      	movl	$0x4, %eax
    fb50:      	leaq	0x30(%rsp), %rdi
    fb55:      	movl	$0x8, %esi
    fb5a:      	movq	%r15, %rdx
    fb5d:      	callq	*%rax
    fb5f:      	movq	(%rsp), %r15
    fb63:      	movq	%r15, 0x40(%rsp)
    fb68:      	leaq	0x20(%r15), %rdx
    fb6c:      	movq	%rdx, 0x38(%rsp)
    fb71:      	movq	0x30(%rsp), %r12
    fb76:      	cmpq	0x18(%rsp), %r12
    fb7b:      	jne	0xfb88 <generic_fentry_path+0x48a8>
    fb7d:      	cmpq	0x20(%rsp), %rdx
    fb82:      	je	0x16d4d <generic_fentry_path+0xba6d>
    fb88:      	movl	$0x4, %eax
    fb8d:      	leaq	0x10(%rsp), %rdi
    fb92:      	movl	$0x8, %esi
    fb97:      	callq	*%rax
    fb99:      	cmpq	0x10(%rsp), %r12
    fb9e:      	je	0xfc96 <generic_fentry_path+0x49b6>
    fba4:      	leaq	0x18(%r12), %rbx
    fba9:      	movl	$0x4, %eax
    fbae:      	movq	%rbp, %rdi
    fbb1:      	movl	$0x8, %esi
    fbb6:      	movq	%rbx, %rdx
    fbb9:      	callq	*%rax
    fbbb:      	cmpq	%r12, (%rsp)
    fbbf:      	je	0xfc96 <generic_fentry_path+0x49b6>
    fbc5:      	movl	$0x4, %eax
    fbca:      	leaq	0x8(%rsp), %rdi
    fbcf:      	movl	$0x8, %esi
    fbd4:      	movq	%rbx, %rdx
    fbd7:      	callq	*%rax
    fbd9:      	addq	$0x20, %r12
    fbdd:      	movl	$0x4, %eax
    fbe2:      	leaq	0x58(%rsp), %rdi
    fbe7:      	movl	$0x10, %ecx
    fbec:      	movl	$0x10, %esi
    fbf1:      	movq	%r12, %rdx
    fbf4:      	callq	*%rax
    fbf6:      	movq	0x28(%rsp), %rbx
    fbfb:      	movq	0x48(%rsp), %rax
    fc00:      	movl	0x5c(%rsp), %r15d
    fc05:      	subq	%rbx, %rax
    fc08:      	movl	0x50(%rsp), %r12d
    fc0d:      	movl	%r15d, %edx
    fc10:      	subl	%r12d, %edx
    fc13:      	movl	$0x0, %ecx
    fc18:      	cmovbl	%ecx, %edx
    fc1b:      	addq	0x60(%rsp), %rdx
    fc20:      	xorl	%esi, %esi
    fc22:      	cmpl	%r15d, %r12d
    fc25:      	seta	%sil
    fc29:      	movl	%r15d, %ecx
    fc2c:      	cmovbl	%r12d, %ecx
    fc30:      	addl	%ecx, %esi
    fc32:      	movl	%r12d, %edi
    fc35:      	subl	%esi, %edi
    fc37:      	movl	%edi, 0x50(%rsp)
    fc3b:      	subq	%rsi, %rax
    fc3e:      	jb	0x16d52 <generic_fentry_path+0xba72>
    fc44:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    fc4a:      	ja	0x16d52 <generic_fentry_path+0xba72>
    fc50:      	cmpl	%r15d, %r12d
    fc53:      	jbe	0xfc59 <generic_fentry_path+0x4979>
    fc55:      	movb	$0x2f, (%rbx,%rax)
    fc59:      	xorl	%edi, %edi
    fc5b:      	cmpl	%r15d, %r12d
    fc5e:      	seta	%dil
    fc62:      	movzbl	%cl, %esi
    fc65:      	addq	%rax, %rbx
    fc68:      	addq	%rbx, %rdi
    fc6b:      	movl	$0x4, %eax
    fc70:      	callq	*%rax
    fc72:      	movq	%rbx, 0x48(%rsp)
    fc77:      	cmpl	%r15d, %r12d
    fc7a:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    fc80:      	movq	0x8(%rsp), %r12
    fc85:      	movq	%r12, 0x30(%rsp)
    fc8a:      	movq	0x38(%rsp), %rdx
    fc8f:      	movq	0x40(%rsp), %r15
    fc94:      	jmp	0xfce7 <generic_fentry_path+0x4a07>
    fc96:      	leaq	0x10(%r15), %rdx
    fc9a:      	movl	$0x4, %eax
    fc9f:      	movq	%rbp, %rdi
    fca2:      	movl	$0x8, %esi
    fca7:      	callq	*%rax
    fca9:      	movq	0x40(%rsp), %rax
    fcae:      	cmpq	(%rsp), %rax
    fcb2:      	je	0x16d4d <generic_fentry_path+0xba6d>
    fcb8:      	addq	$0x18, %r15
    fcbc:      	movl	$0x4, %eax
    fcc1:      	leaq	0x30(%rsp), %rdi
    fcc6:      	movl	$0x8, %esi
    fccb:      	movq	%r15, %rdx
    fcce:      	callq	*%rax
    fcd0:      	movq	(%rsp), %r15
    fcd4:      	movq	%r15, 0x40(%rsp)
    fcd9:      	leaq	0x20(%r15), %rdx
    fcdd:      	movq	%rdx, 0x38(%rsp)
    fce2:      	movq	0x30(%rsp), %r12
    fce7:      	cmpq	0x18(%rsp), %r12
    fcec:      	jne	0xfcf9 <generic_fentry_path+0x4a19>
    fcee:      	cmpq	0x20(%rsp), %rdx
    fcf3:      	je	0x16d4d <generic_fentry_path+0xba6d>
    fcf9:      	movl	$0x4, %eax
    fcfe:      	leaq	0x10(%rsp), %rdi
    fd03:      	movl	$0x8, %esi
    fd08:      	callq	*%rax
    fd0a:      	cmpq	0x10(%rsp), %r12
    fd0f:      	je	0xfe07 <generic_fentry_path+0x4b27>
    fd15:      	leaq	0x18(%r12), %rbx
    fd1a:      	movl	$0x4, %eax
    fd1f:      	movq	%rbp, %rdi
    fd22:      	movl	$0x8, %esi
    fd27:      	movq	%rbx, %rdx
    fd2a:      	callq	*%rax
    fd2c:      	cmpq	%r12, (%rsp)
    fd30:      	je	0xfe07 <generic_fentry_path+0x4b27>
    fd36:      	movl	$0x4, %eax
    fd3b:      	leaq	0x8(%rsp), %rdi
    fd40:      	movl	$0x8, %esi
    fd45:      	movq	%rbx, %rdx
    fd48:      	callq	*%rax
    fd4a:      	addq	$0x20, %r12
    fd4e:      	movl	$0x4, %eax
    fd53:      	leaq	0x58(%rsp), %rdi
    fd58:      	movl	$0x10, %ecx
    fd5d:      	movl	$0x10, %esi
    fd62:      	movq	%r12, %rdx
    fd65:      	callq	*%rax
    fd67:      	movq	0x28(%rsp), %rbx
    fd6c:      	movq	0x48(%rsp), %rax
    fd71:      	movl	0x5c(%rsp), %r15d
    fd76:      	subq	%rbx, %rax
    fd79:      	movl	0x50(%rsp), %r12d
    fd7e:      	movl	%r15d, %edx
    fd81:      	subl	%r12d, %edx
    fd84:      	movl	$0x0, %ecx
    fd89:      	cmovbl	%ecx, %edx
    fd8c:      	addq	0x60(%rsp), %rdx
    fd91:      	xorl	%esi, %esi
    fd93:      	cmpl	%r15d, %r12d
    fd96:      	seta	%sil
    fd9a:      	movl	%r15d, %ecx
    fd9d:      	cmovbl	%r12d, %ecx
    fda1:      	addl	%ecx, %esi
    fda3:      	movl	%r12d, %edi
    fda6:      	subl	%esi, %edi
    fda8:      	movl	%edi, 0x50(%rsp)
    fdac:      	subq	%rsi, %rax
    fdaf:      	jb	0x16d52 <generic_fentry_path+0xba72>
    fdb5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    fdbb:      	ja	0x16d52 <generic_fentry_path+0xba72>
    fdc1:      	cmpl	%r15d, %r12d
    fdc4:      	jbe	0xfdca <generic_fentry_path+0x4aea>
    fdc6:      	movb	$0x2f, (%rbx,%rax)
    fdca:      	xorl	%edi, %edi
    fdcc:      	cmpl	%r15d, %r12d
    fdcf:      	seta	%dil
    fdd3:      	movzbl	%cl, %esi
    fdd6:      	addq	%rax, %rbx
    fdd9:      	addq	%rbx, %rdi
    fddc:      	movl	$0x4, %eax
    fde1:      	callq	*%rax
    fde3:      	movq	%rbx, 0x48(%rsp)
    fde8:      	cmpl	%r15d, %r12d
    fdeb:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    fdf1:      	movq	0x8(%rsp), %r12
    fdf6:      	movq	%r12, 0x30(%rsp)
    fdfb:      	movq	0x38(%rsp), %rdx
    fe00:      	movq	0x40(%rsp), %r15
    fe05:      	jmp	0xfe58 <generic_fentry_path+0x4b78>
    fe07:      	leaq	0x10(%r15), %rdx
    fe0b:      	movl	$0x4, %eax
    fe10:      	movq	%rbp, %rdi
    fe13:      	movl	$0x8, %esi
    fe18:      	callq	*%rax
    fe1a:      	movq	0x40(%rsp), %rax
    fe1f:      	cmpq	(%rsp), %rax
    fe23:      	je	0x16d4d <generic_fentry_path+0xba6d>
    fe29:      	addq	$0x18, %r15
    fe2d:      	movl	$0x4, %eax
    fe32:      	leaq	0x30(%rsp), %rdi
    fe37:      	movl	$0x8, %esi
    fe3c:      	movq	%r15, %rdx
    fe3f:      	callq	*%rax
    fe41:      	movq	(%rsp), %r15
    fe45:      	movq	%r15, 0x40(%rsp)
    fe4a:      	leaq	0x20(%r15), %rdx
    fe4e:      	movq	%rdx, 0x38(%rsp)
    fe53:      	movq	0x30(%rsp), %r12
    fe58:      	cmpq	0x18(%rsp), %r12
    fe5d:      	jne	0xfe6a <generic_fentry_path+0x4b8a>
    fe5f:      	cmpq	0x20(%rsp), %rdx
    fe64:      	je	0x16d4d <generic_fentry_path+0xba6d>
    fe6a:      	movl	$0x4, %eax
    fe6f:      	leaq	0x10(%rsp), %rdi
    fe74:      	movl	$0x8, %esi
    fe79:      	callq	*%rax
    fe7b:      	cmpq	0x10(%rsp), %r12
    fe80:      	je	0xff78 <generic_fentry_path+0x4c98>
    fe86:      	leaq	0x18(%r12), %rbx
    fe8b:      	movl	$0x4, %eax
    fe90:      	movq	%rbp, %rdi
    fe93:      	movl	$0x8, %esi
    fe98:      	movq	%rbx, %rdx
    fe9b:      	callq	*%rax
    fe9d:      	cmpq	%r12, (%rsp)
    fea1:      	je	0xff78 <generic_fentry_path+0x4c98>
    fea7:      	movl	$0x4, %eax
    feac:      	leaq	0x8(%rsp), %rdi
    feb1:      	movl	$0x8, %esi
    feb6:      	movq	%rbx, %rdx
    feb9:      	callq	*%rax
    febb:      	addq	$0x20, %r12
    febf:      	movl	$0x4, %eax
    fec4:      	leaq	0x58(%rsp), %rdi
    fec9:      	movl	$0x10, %ecx
    fece:      	movl	$0x10, %esi
    fed3:      	movq	%r12, %rdx
    fed6:      	callq	*%rax
    fed8:      	movq	0x28(%rsp), %rbx
    fedd:      	movq	0x48(%rsp), %rax
    fee2:      	movl	0x5c(%rsp), %r15d
    fee7:      	subq	%rbx, %rax
    feea:      	movl	0x50(%rsp), %r12d
    feef:      	movl	%r15d, %edx
    fef2:      	subl	%r12d, %edx
    fef5:      	movl	$0x0, %ecx
    fefa:      	cmovbl	%ecx, %edx
    fefd:      	addq	0x60(%rsp), %rdx
    ff02:      	xorl	%esi, %esi
    ff04:      	cmpl	%r15d, %r12d
    ff07:      	seta	%sil
    ff0b:      	movl	%r15d, %ecx
    ff0e:      	cmovbl	%r12d, %ecx
    ff12:      	addl	%ecx, %esi
    ff14:      	movl	%r12d, %edi
    ff17:      	subl	%esi, %edi
    ff19:      	movl	%edi, 0x50(%rsp)
    ff1d:      	subq	%rsi, %rax
    ff20:      	jb	0x16d52 <generic_fentry_path+0xba72>
    ff26:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ff2c:      	ja	0x16d52 <generic_fentry_path+0xba72>
    ff32:      	cmpl	%r15d, %r12d
    ff35:      	jbe	0xff3b <generic_fentry_path+0x4c5b>
    ff37:      	movb	$0x2f, (%rbx,%rax)
    ff3b:      	xorl	%edi, %edi
    ff3d:      	cmpl	%r15d, %r12d
    ff40:      	seta	%dil
    ff44:      	movzbl	%cl, %esi
    ff47:      	addq	%rax, %rbx
    ff4a:      	addq	%rbx, %rdi
    ff4d:      	movl	$0x4, %eax
    ff52:      	callq	*%rax
    ff54:      	movq	%rbx, 0x48(%rsp)
    ff59:      	cmpl	%r15d, %r12d
    ff5c:      	jbe	0x16d52 <generic_fentry_path+0xba72>
    ff62:      	movq	0x8(%rsp), %r12
    ff67:      	movq	%r12, 0x30(%rsp)
    ff6c:      	movq	0x38(%rsp), %rdx
    ff71:      	movq	0x40(%rsp), %r15
    ff76:      	jmp	0xffc9 <generic_fentry_path+0x4ce9>
    ff78:      	leaq	0x10(%r15), %rdx
    ff7c:      	movl	$0x4, %eax
    ff81:      	movq	%rbp, %rdi
    ff84:      	movl	$0x8, %esi
    ff89:      	callq	*%rax
    ff8b:      	movq	0x40(%rsp), %rax
    ff90:      	cmpq	(%rsp), %rax
    ff94:      	je	0x16d4d <generic_fentry_path+0xba6d>
    ff9a:      	addq	$0x18, %r15
    ff9e:      	movl	$0x4, %eax
    ffa3:      	leaq	0x30(%rsp), %rdi
    ffa8:      	movl	$0x8, %esi
    ffad:      	movq	%r15, %rdx
    ffb0:      	callq	*%rax
    ffb2:      	movq	(%rsp), %r15
    ffb6:      	movq	%r15, 0x40(%rsp)
    ffbb:      	leaq	0x20(%r15), %rdx
    ffbf:      	movq	%rdx, 0x38(%rsp)
    ffc4:      	movq	0x30(%rsp), %r12
    ffc9:      	cmpq	0x18(%rsp), %r12
    ffce:      	jne	0xffdb <generic_fentry_path+0x4cfb>
    ffd0:      	cmpq	0x20(%rsp), %rdx
    ffd5:      	je	0x16d4d <generic_fentry_path+0xba6d>
    ffdb:      	movl	$0x4, %eax
    ffe0:      	leaq	0x10(%rsp), %rdi
    ffe5:      	movl	$0x8, %esi
    ffea:      	callq	*%rax
    ffec:      	cmpq	0x10(%rsp), %r12
    fff1:      	je	0x100e9 <generic_fentry_path+0x4e09>
    fff7:      	leaq	0x18(%r12), %rbx
    fffc:      	movl	$0x4, %eax
   10001:      	movq	%rbp, %rdi
   10004:      	movl	$0x8, %esi
   10009:      	movq	%rbx, %rdx
   1000c:      	callq	*%rax
   1000e:      	cmpq	%r12, (%rsp)
   10012:      	je	0x100e9 <generic_fentry_path+0x4e09>
   10018:      	movl	$0x4, %eax
   1001d:      	leaq	0x8(%rsp), %rdi
   10022:      	movl	$0x8, %esi
   10027:      	movq	%rbx, %rdx
   1002a:      	callq	*%rax
   1002c:      	addq	$0x20, %r12
   10030:      	movl	$0x4, %eax
   10035:      	leaq	0x58(%rsp), %rdi
   1003a:      	movl	$0x10, %ecx
   1003f:      	movl	$0x10, %esi
   10044:      	movq	%r12, %rdx
   10047:      	callq	*%rax
   10049:      	movq	0x28(%rsp), %rbx
   1004e:      	movq	0x48(%rsp), %rax
   10053:      	movl	0x5c(%rsp), %r15d
   10058:      	subq	%rbx, %rax
   1005b:      	movl	0x50(%rsp), %r12d
   10060:      	movl	%r15d, %edx
   10063:      	subl	%r12d, %edx
   10066:      	movl	$0x0, %ecx
   1006b:      	cmovbl	%ecx, %edx
   1006e:      	addq	0x60(%rsp), %rdx
   10073:      	xorl	%esi, %esi
   10075:      	cmpl	%r15d, %r12d
   10078:      	seta	%sil
   1007c:      	movl	%r15d, %ecx
   1007f:      	cmovbl	%r12d, %ecx
   10083:      	addl	%ecx, %esi
   10085:      	movl	%r12d, %edi
   10088:      	subl	%esi, %edi
   1008a:      	movl	%edi, 0x50(%rsp)
   1008e:      	subq	%rsi, %rax
   10091:      	jb	0x16d52 <generic_fentry_path+0xba72>
   10097:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1009d:      	ja	0x16d52 <generic_fentry_path+0xba72>
   100a3:      	cmpl	%r15d, %r12d
   100a6:      	jbe	0x100ac <generic_fentry_path+0x4dcc>
   100a8:      	movb	$0x2f, (%rbx,%rax)
   100ac:      	xorl	%edi, %edi
   100ae:      	cmpl	%r15d, %r12d
   100b1:      	seta	%dil
   100b5:      	movzbl	%cl, %esi
   100b8:      	addq	%rax, %rbx
   100bb:      	addq	%rbx, %rdi
   100be:      	movl	$0x4, %eax
   100c3:      	callq	*%rax
   100c5:      	movq	%rbx, 0x48(%rsp)
   100ca:      	cmpl	%r15d, %r12d
   100cd:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   100d3:      	movq	0x8(%rsp), %r12
   100d8:      	movq	%r12, 0x30(%rsp)
   100dd:      	movq	0x38(%rsp), %rdx
   100e2:      	movq	0x40(%rsp), %r15
   100e7:      	jmp	0x1013a <generic_fentry_path+0x4e5a>
   100e9:      	leaq	0x10(%r15), %rdx
   100ed:      	movl	$0x4, %eax
   100f2:      	movq	%rbp, %rdi
   100f5:      	movl	$0x8, %esi
   100fa:      	callq	*%rax
   100fc:      	movq	0x40(%rsp), %rax
   10101:      	cmpq	(%rsp), %rax
   10105:      	je	0x16d4d <generic_fentry_path+0xba6d>
   1010b:      	addq	$0x18, %r15
   1010f:      	movl	$0x4, %eax
   10114:      	leaq	0x30(%rsp), %rdi
   10119:      	movl	$0x8, %esi
   1011e:      	movq	%r15, %rdx
   10121:      	callq	*%rax
   10123:      	movq	(%rsp), %r15
   10127:      	movq	%r15, 0x40(%rsp)
   1012c:      	leaq	0x20(%r15), %rdx
   10130:      	movq	%rdx, 0x38(%rsp)
   10135:      	movq	0x30(%rsp), %r12
   1013a:      	cmpq	0x18(%rsp), %r12
   1013f:      	jne	0x1014c <generic_fentry_path+0x4e6c>
   10141:      	cmpq	0x20(%rsp), %rdx
   10146:      	je	0x16d4d <generic_fentry_path+0xba6d>
   1014c:      	movl	$0x4, %eax
   10151:      	leaq	0x10(%rsp), %rdi
   10156:      	movl	$0x8, %esi
   1015b:      	callq	*%rax
   1015d:      	cmpq	0x10(%rsp), %r12
   10162:      	je	0x1025a <generic_fentry_path+0x4f7a>
   10168:      	leaq	0x18(%r12), %rbx
   1016d:      	movl	$0x4, %eax
   10172:      	movq	%rbp, %rdi
   10175:      	movl	$0x8, %esi
   1017a:      	movq	%rbx, %rdx
   1017d:      	callq	*%rax
   1017f:      	cmpq	%r12, (%rsp)
   10183:      	je	0x1025a <generic_fentry_path+0x4f7a>
   10189:      	movl	$0x4, %eax
   1018e:      	leaq	0x8(%rsp), %rdi
   10193:      	movl	$0x8, %esi
   10198:      	movq	%rbx, %rdx
   1019b:      	callq	*%rax
   1019d:      	addq	$0x20, %r12
   101a1:      	movl	$0x4, %eax
   101a6:      	leaq	0x58(%rsp), %rdi
   101ab:      	movl	$0x10, %ecx
   101b0:      	movl	$0x10, %esi
   101b5:      	movq	%r12, %rdx
   101b8:      	callq	*%rax
   101ba:      	movq	0x28(%rsp), %rbx
   101bf:      	movq	0x48(%rsp), %rax
   101c4:      	movl	0x5c(%rsp), %r15d
   101c9:      	subq	%rbx, %rax
   101cc:      	movl	0x50(%rsp), %r12d
   101d1:      	movl	%r15d, %edx
   101d4:      	subl	%r12d, %edx
   101d7:      	movl	$0x0, %ecx
   101dc:      	cmovbl	%ecx, %edx
   101df:      	addq	0x60(%rsp), %rdx
   101e4:      	xorl	%esi, %esi
   101e6:      	cmpl	%r15d, %r12d
   101e9:      	seta	%sil
   101ed:      	movl	%r15d, %ecx
   101f0:      	cmovbl	%r12d, %ecx
   101f4:      	addl	%ecx, %esi
   101f6:      	movl	%r12d, %edi
   101f9:      	subl	%esi, %edi
   101fb:      	movl	%edi, 0x50(%rsp)
   101ff:      	subq	%rsi, %rax
   10202:      	jb	0x16d52 <generic_fentry_path+0xba72>
   10208:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1020e:      	ja	0x16d52 <generic_fentry_path+0xba72>
   10214:      	cmpl	%r15d, %r12d
   10217:      	jbe	0x1021d <generic_fentry_path+0x4f3d>
   10219:      	movb	$0x2f, (%rbx,%rax)
   1021d:      	xorl	%edi, %edi
   1021f:      	cmpl	%r15d, %r12d
   10222:      	seta	%dil
   10226:      	movzbl	%cl, %esi
   10229:      	addq	%rax, %rbx
   1022c:      	addq	%rbx, %rdi
   1022f:      	movl	$0x4, %eax
   10234:      	callq	*%rax
   10236:      	movq	%rbx, 0x48(%rsp)
   1023b:      	cmpl	%r15d, %r12d
   1023e:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   10244:      	movq	0x8(%rsp), %r12
   10249:      	movq	%r12, 0x30(%rsp)
   1024e:      	movq	0x38(%rsp), %rdx
   10253:      	movq	0x40(%rsp), %r15
   10258:      	jmp	0x102ab <generic_fentry_path+0x4fcb>
   1025a:      	leaq	0x10(%r15), %rdx
   1025e:      	movl	$0x4, %eax
   10263:      	movq	%rbp, %rdi
   10266:      	movl	$0x8, %esi
   1026b:      	callq	*%rax
   1026d:      	movq	0x40(%rsp), %rax
   10272:      	cmpq	(%rsp), %rax
   10276:      	je	0x16d4d <generic_fentry_path+0xba6d>
   1027c:      	addq	$0x18, %r15
   10280:      	movl	$0x4, %eax
   10285:      	leaq	0x30(%rsp), %rdi
   1028a:      	movl	$0x8, %esi
   1028f:      	movq	%r15, %rdx
   10292:      	callq	*%rax
   10294:      	movq	(%rsp), %r15
   10298:      	movq	%r15, 0x40(%rsp)
   1029d:      	leaq	0x20(%r15), %rdx
   102a1:      	movq	%rdx, 0x38(%rsp)
   102a6:      	movq	0x30(%rsp), %r12
   102ab:      	cmpq	0x18(%rsp), %r12
   102b0:      	jne	0x102bd <generic_fentry_path+0x4fdd>
   102b2:      	cmpq	0x20(%rsp), %rdx
   102b7:      	je	0x16d4d <generic_fentry_path+0xba6d>
   102bd:      	movl	$0x4, %eax
   102c2:      	leaq	0x10(%rsp), %rdi
   102c7:      	movl	$0x8, %esi
   102cc:      	callq	*%rax
   102ce:      	cmpq	0x10(%rsp), %r12
   102d3:      	je	0x103cb <generic_fentry_path+0x50eb>
   102d9:      	leaq	0x18(%r12), %rbx
   102de:      	movl	$0x4, %eax
   102e3:      	movq	%rbp, %rdi
   102e6:      	movl	$0x8, %esi
   102eb:      	movq	%rbx, %rdx
   102ee:      	callq	*%rax
   102f0:      	cmpq	%r12, (%rsp)
   102f4:      	je	0x103cb <generic_fentry_path+0x50eb>
   102fa:      	movl	$0x4, %eax
   102ff:      	leaq	0x8(%rsp), %rdi
   10304:      	movl	$0x8, %esi
   10309:      	movq	%rbx, %rdx
   1030c:      	callq	*%rax
   1030e:      	addq	$0x20, %r12
   10312:      	movl	$0x4, %eax
   10317:      	leaq	0x58(%rsp), %rdi
   1031c:      	movl	$0x10, %ecx
   10321:      	movl	$0x10, %esi
   10326:      	movq	%r12, %rdx
   10329:      	callq	*%rax
   1032b:      	movq	0x28(%rsp), %rbx
   10330:      	movq	0x48(%rsp), %rax
   10335:      	movl	0x5c(%rsp), %r15d
   1033a:      	subq	%rbx, %rax
   1033d:      	movl	0x50(%rsp), %r12d
   10342:      	movl	%r15d, %edx
   10345:      	subl	%r12d, %edx
   10348:      	movl	$0x0, %ecx
   1034d:      	cmovbl	%ecx, %edx
   10350:      	addq	0x60(%rsp), %rdx
   10355:      	xorl	%esi, %esi
   10357:      	cmpl	%r15d, %r12d
   1035a:      	seta	%sil
   1035e:      	movl	%r15d, %ecx
   10361:      	cmovbl	%r12d, %ecx
   10365:      	addl	%ecx, %esi
   10367:      	movl	%r12d, %edi
   1036a:      	subl	%esi, %edi
   1036c:      	movl	%edi, 0x50(%rsp)
   10370:      	subq	%rsi, %rax
   10373:      	jb	0x16d52 <generic_fentry_path+0xba72>
   10379:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1037f:      	ja	0x16d52 <generic_fentry_path+0xba72>
   10385:      	cmpl	%r15d, %r12d
   10388:      	jbe	0x1038e <generic_fentry_path+0x50ae>
   1038a:      	movb	$0x2f, (%rbx,%rax)
   1038e:      	xorl	%edi, %edi
   10390:      	cmpl	%r15d, %r12d
   10393:      	seta	%dil
   10397:      	movzbl	%cl, %esi
   1039a:      	addq	%rax, %rbx
   1039d:      	addq	%rbx, %rdi
   103a0:      	movl	$0x4, %eax
   103a5:      	callq	*%rax
   103a7:      	movq	%rbx, 0x48(%rsp)
   103ac:      	cmpl	%r15d, %r12d
   103af:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   103b5:      	movq	0x8(%rsp), %r12
   103ba:      	movq	%r12, 0x30(%rsp)
   103bf:      	movq	0x38(%rsp), %rdx
   103c4:      	movq	0x40(%rsp), %r15
   103c9:      	jmp	0x1041c <generic_fentry_path+0x513c>
   103cb:      	leaq	0x10(%r15), %rdx
   103cf:      	movl	$0x4, %eax
   103d4:      	movq	%rbp, %rdi
   103d7:      	movl	$0x8, %esi
   103dc:      	callq	*%rax
   103de:      	movq	0x40(%rsp), %rax
   103e3:      	cmpq	(%rsp), %rax
   103e7:      	je	0x16d4d <generic_fentry_path+0xba6d>
   103ed:      	addq	$0x18, %r15
   103f1:      	movl	$0x4, %eax
   103f6:      	leaq	0x30(%rsp), %rdi
   103fb:      	movl	$0x8, %esi
   10400:      	movq	%r15, %rdx
   10403:      	callq	*%rax
   10405:      	movq	(%rsp), %r15
   10409:      	movq	%r15, 0x40(%rsp)
   1040e:      	leaq	0x20(%r15), %rdx
   10412:      	movq	%rdx, 0x38(%rsp)
   10417:      	movq	0x30(%rsp), %r12
   1041c:      	cmpq	0x18(%rsp), %r12
   10421:      	jne	0x1042e <generic_fentry_path+0x514e>
   10423:      	cmpq	0x20(%rsp), %rdx
   10428:      	je	0x16d4d <generic_fentry_path+0xba6d>
   1042e:      	movl	$0x4, %eax
   10433:      	leaq	0x10(%rsp), %rdi
   10438:      	movl	$0x8, %esi
   1043d:      	callq	*%rax
   1043f:      	cmpq	0x10(%rsp), %r12
   10444:      	je	0x1053c <generic_fentry_path+0x525c>
   1044a:      	leaq	0x18(%r12), %rbx
   1044f:      	movl	$0x4, %eax
   10454:      	movq	%rbp, %rdi
   10457:      	movl	$0x8, %esi
   1045c:      	movq	%rbx, %rdx
   1045f:      	callq	*%rax
   10461:      	cmpq	%r12, (%rsp)
   10465:      	je	0x1053c <generic_fentry_path+0x525c>
   1046b:      	movl	$0x4, %eax
   10470:      	leaq	0x8(%rsp), %rdi
   10475:      	movl	$0x8, %esi
   1047a:      	movq	%rbx, %rdx
   1047d:      	callq	*%rax
   1047f:      	addq	$0x20, %r12
   10483:      	movl	$0x4, %eax
   10488:      	leaq	0x58(%rsp), %rdi
   1048d:      	movl	$0x10, %ecx
   10492:      	movl	$0x10, %esi
   10497:      	movq	%r12, %rdx
   1049a:      	callq	*%rax
   1049c:      	movq	0x28(%rsp), %rbx
   104a1:      	movq	0x48(%rsp), %rax
   104a6:      	movl	0x5c(%rsp), %r15d
   104ab:      	subq	%rbx, %rax
   104ae:      	movl	0x50(%rsp), %r12d
   104b3:      	movl	%r15d, %edx
   104b6:      	subl	%r12d, %edx
   104b9:      	movl	$0x0, %ecx
   104be:      	cmovbl	%ecx, %edx
   104c1:      	addq	0x60(%rsp), %rdx
   104c6:      	xorl	%esi, %esi
   104c8:      	cmpl	%r15d, %r12d
   104cb:      	seta	%sil
   104cf:      	movl	%r15d, %ecx
   104d2:      	cmovbl	%r12d, %ecx
   104d6:      	addl	%ecx, %esi
   104d8:      	movl	%r12d, %edi
   104db:      	subl	%esi, %edi
   104dd:      	movl	%edi, 0x50(%rsp)
   104e1:      	subq	%rsi, %rax
   104e4:      	jb	0x16d52 <generic_fentry_path+0xba72>
   104ea:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   104f0:      	ja	0x16d52 <generic_fentry_path+0xba72>
   104f6:      	cmpl	%r15d, %r12d
   104f9:      	jbe	0x104ff <generic_fentry_path+0x521f>
   104fb:      	movb	$0x2f, (%rbx,%rax)
   104ff:      	xorl	%edi, %edi
   10501:      	cmpl	%r15d, %r12d
   10504:      	seta	%dil
   10508:      	movzbl	%cl, %esi
   1050b:      	addq	%rax, %rbx
   1050e:      	addq	%rbx, %rdi
   10511:      	movl	$0x4, %eax
   10516:      	callq	*%rax
   10518:      	movq	%rbx, 0x48(%rsp)
   1051d:      	cmpl	%r15d, %r12d
   10520:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   10526:      	movq	0x8(%rsp), %r12
   1052b:      	movq	%r12, 0x30(%rsp)
   10530:      	movq	0x38(%rsp), %rdx
   10535:      	movq	0x40(%rsp), %r15
   1053a:      	jmp	0x1058d <generic_fentry_path+0x52ad>
   1053c:      	leaq	0x10(%r15), %rdx
   10540:      	movl	$0x4, %eax
   10545:      	movq	%rbp, %rdi
   10548:      	movl	$0x8, %esi
   1054d:      	callq	*%rax
   1054f:      	movq	0x40(%rsp), %rax
   10554:      	cmpq	(%rsp), %rax
   10558:      	je	0x16d4d <generic_fentry_path+0xba6d>
   1055e:      	addq	$0x18, %r15
   10562:      	movl	$0x4, %eax
   10567:      	leaq	0x30(%rsp), %rdi
   1056c:      	movl	$0x8, %esi
   10571:      	movq	%r15, %rdx
   10574:      	callq	*%rax
   10576:      	movq	(%rsp), %r15
   1057a:      	movq	%r15, 0x40(%rsp)
   1057f:      	leaq	0x20(%r15), %rdx
   10583:      	movq	%rdx, 0x38(%rsp)
   10588:      	movq	0x30(%rsp), %r12
   1058d:      	cmpq	0x18(%rsp), %r12
   10592:      	jne	0x1059f <generic_fentry_path+0x52bf>
   10594:      	cmpq	0x20(%rsp), %rdx
   10599:      	je	0x16d4d <generic_fentry_path+0xba6d>
   1059f:      	movl	$0x4, %eax
   105a4:      	leaq	0x10(%rsp), %rdi
   105a9:      	movl	$0x8, %esi
   105ae:      	callq	*%rax
   105b0:      	cmpq	0x10(%rsp), %r12
   105b5:      	je	0x106ad <generic_fentry_path+0x53cd>
   105bb:      	leaq	0x18(%r12), %rbx
   105c0:      	movl	$0x4, %eax
   105c5:      	movq	%rbp, %rdi
   105c8:      	movl	$0x8, %esi
   105cd:      	movq	%rbx, %rdx
   105d0:      	callq	*%rax
   105d2:      	cmpq	%r12, (%rsp)
   105d6:      	je	0x106ad <generic_fentry_path+0x53cd>
   105dc:      	movl	$0x4, %eax
   105e1:      	leaq	0x8(%rsp), %rdi
   105e6:      	movl	$0x8, %esi
   105eb:      	movq	%rbx, %rdx
   105ee:      	callq	*%rax
   105f0:      	addq	$0x20, %r12
   105f4:      	movl	$0x4, %eax
   105f9:      	leaq	0x58(%rsp), %rdi
   105fe:      	movl	$0x10, %ecx
   10603:      	movl	$0x10, %esi
   10608:      	movq	%r12, %rdx
   1060b:      	callq	*%rax
   1060d:      	movq	0x28(%rsp), %rbx
   10612:      	movq	0x48(%rsp), %rax
   10617:      	movl	0x5c(%rsp), %r15d
   1061c:      	subq	%rbx, %rax
   1061f:      	movl	0x50(%rsp), %r12d
   10624:      	movl	%r15d, %edx
   10627:      	subl	%r12d, %edx
   1062a:      	movl	$0x0, %ecx
   1062f:      	cmovbl	%ecx, %edx
   10632:      	addq	0x60(%rsp), %rdx
   10637:      	xorl	%esi, %esi
   10639:      	cmpl	%r15d, %r12d
   1063c:      	seta	%sil
   10640:      	movl	%r15d, %ecx
   10643:      	cmovbl	%r12d, %ecx
   10647:      	addl	%ecx, %esi
   10649:      	movl	%r12d, %edi
   1064c:      	subl	%esi, %edi
   1064e:      	movl	%edi, 0x50(%rsp)
   10652:      	subq	%rsi, %rax
   10655:      	jb	0x16d52 <generic_fentry_path+0xba72>
   1065b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10661:      	ja	0x16d52 <generic_fentry_path+0xba72>
   10667:      	cmpl	%r15d, %r12d
   1066a:      	jbe	0x10670 <generic_fentry_path+0x5390>
   1066c:      	movb	$0x2f, (%rbx,%rax)
   10670:      	xorl	%edi, %edi
   10672:      	cmpl	%r15d, %r12d
   10675:      	seta	%dil
   10679:      	movzbl	%cl, %esi
   1067c:      	addq	%rax, %rbx
   1067f:      	addq	%rbx, %rdi
   10682:      	movl	$0x4, %eax
   10687:      	callq	*%rax
   10689:      	movq	%rbx, 0x48(%rsp)
   1068e:      	cmpl	%r15d, %r12d
   10691:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   10697:      	movq	0x8(%rsp), %r12
   1069c:      	movq	%r12, 0x30(%rsp)
   106a1:      	movq	0x38(%rsp), %rdx
   106a6:      	movq	0x40(%rsp), %r15
   106ab:      	jmp	0x106fe <generic_fentry_path+0x541e>
   106ad:      	leaq	0x10(%r15), %rdx
   106b1:      	movl	$0x4, %eax
   106b6:      	movq	%rbp, %rdi
   106b9:      	movl	$0x8, %esi
   106be:      	callq	*%rax
   106c0:      	movq	0x40(%rsp), %rax
   106c5:      	cmpq	(%rsp), %rax
   106c9:      	je	0x16d4d <generic_fentry_path+0xba6d>
   106cf:      	addq	$0x18, %r15
   106d3:      	movl	$0x4, %eax
   106d8:      	leaq	0x30(%rsp), %rdi
   106dd:      	movl	$0x8, %esi
   106e2:      	movq	%r15, %rdx
   106e5:      	callq	*%rax
   106e7:      	movq	(%rsp), %r15
   106eb:      	movq	%r15, 0x40(%rsp)
   106f0:      	leaq	0x20(%r15), %rdx
   106f4:      	movq	%rdx, 0x38(%rsp)
   106f9:      	movq	0x30(%rsp), %r12
   106fe:      	cmpq	0x18(%rsp), %r12
   10703:      	jne	0x10710 <generic_fentry_path+0x5430>
   10705:      	cmpq	0x20(%rsp), %rdx
   1070a:      	je	0x16d4d <generic_fentry_path+0xba6d>
   10710:      	movl	$0x4, %eax
   10715:      	leaq	0x10(%rsp), %rdi
   1071a:      	movl	$0x8, %esi
   1071f:      	callq	*%rax
   10721:      	cmpq	0x10(%rsp), %r12
   10726:      	je	0x1081e <generic_fentry_path+0x553e>
   1072c:      	leaq	0x18(%r12), %rbx
   10731:      	movl	$0x4, %eax
   10736:      	movq	%rbp, %rdi
   10739:      	movl	$0x8, %esi
   1073e:      	movq	%rbx, %rdx
   10741:      	callq	*%rax
   10743:      	cmpq	%r12, (%rsp)
   10747:      	je	0x1081e <generic_fentry_path+0x553e>
   1074d:      	movl	$0x4, %eax
   10752:      	leaq	0x8(%rsp), %rdi
   10757:      	movl	$0x8, %esi
   1075c:      	movq	%rbx, %rdx
   1075f:      	callq	*%rax
   10761:      	addq	$0x20, %r12
   10765:      	movl	$0x4, %eax
   1076a:      	leaq	0x58(%rsp), %rdi
   1076f:      	movl	$0x10, %ecx
   10774:      	movl	$0x10, %esi
   10779:      	movq	%r12, %rdx
   1077c:      	callq	*%rax
   1077e:      	movq	0x28(%rsp), %rbx
   10783:      	movq	0x48(%rsp), %rax
   10788:      	movl	0x5c(%rsp), %r15d
   1078d:      	subq	%rbx, %rax
   10790:      	movl	0x50(%rsp), %r12d
   10795:      	movl	%r15d, %edx
   10798:      	subl	%r12d, %edx
   1079b:      	movl	$0x0, %ecx
   107a0:      	cmovbl	%ecx, %edx
   107a3:      	addq	0x60(%rsp), %rdx
   107a8:      	xorl	%esi, %esi
   107aa:      	cmpl	%r15d, %r12d
   107ad:      	seta	%sil
   107b1:      	movl	%r15d, %ecx
   107b4:      	cmovbl	%r12d, %ecx
   107b8:      	addl	%ecx, %esi
   107ba:      	movl	%r12d, %edi
   107bd:      	subl	%esi, %edi
   107bf:      	movl	%edi, 0x50(%rsp)
   107c3:      	subq	%rsi, %rax
   107c6:      	jb	0x16d52 <generic_fentry_path+0xba72>
   107cc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   107d2:      	ja	0x16d52 <generic_fentry_path+0xba72>
   107d8:      	cmpl	%r15d, %r12d
   107db:      	jbe	0x107e1 <generic_fentry_path+0x5501>
   107dd:      	movb	$0x2f, (%rbx,%rax)
   107e1:      	xorl	%edi, %edi
   107e3:      	cmpl	%r15d, %r12d
   107e6:      	seta	%dil
   107ea:      	movzbl	%cl, %esi
   107ed:      	addq	%rax, %rbx
   107f0:      	addq	%rbx, %rdi
   107f3:      	movl	$0x4, %eax
   107f8:      	callq	*%rax
   107fa:      	movq	%rbx, 0x48(%rsp)
   107ff:      	cmpl	%r15d, %r12d
   10802:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   10808:      	movq	0x8(%rsp), %r12
   1080d:      	movq	%r12, 0x30(%rsp)
   10812:      	movq	0x38(%rsp), %rdx
   10817:      	movq	0x40(%rsp), %r15
   1081c:      	jmp	0x1086f <generic_fentry_path+0x558f>
   1081e:      	leaq	0x10(%r15), %rdx
   10822:      	movl	$0x4, %eax
   10827:      	movq	%rbp, %rdi
   1082a:      	movl	$0x8, %esi
   1082f:      	callq	*%rax
   10831:      	movq	0x40(%rsp), %rax
   10836:      	cmpq	(%rsp), %rax
   1083a:      	je	0x16d4d <generic_fentry_path+0xba6d>
   10840:      	addq	$0x18, %r15
   10844:      	movl	$0x4, %eax
   10849:      	leaq	0x30(%rsp), %rdi
   1084e:      	movl	$0x8, %esi
   10853:      	movq	%r15, %rdx
   10856:      	callq	*%rax
   10858:      	movq	(%rsp), %r15
   1085c:      	movq	%r15, 0x40(%rsp)
   10861:      	leaq	0x20(%r15), %rdx
   10865:      	movq	%rdx, 0x38(%rsp)
   1086a:      	movq	0x30(%rsp), %r12
   1086f:      	cmpq	0x18(%rsp), %r12
   10874:      	jne	0x10881 <generic_fentry_path+0x55a1>
   10876:      	cmpq	0x20(%rsp), %rdx
   1087b:      	je	0x16d4d <generic_fentry_path+0xba6d>
   10881:      	movl	$0x4, %eax
   10886:      	leaq	0x10(%rsp), %rdi
   1088b:      	movl	$0x8, %esi
   10890:      	callq	*%rax
   10892:      	cmpq	0x10(%rsp), %r12
   10897:      	je	0x1098f <generic_fentry_path+0x56af>
   1089d:      	leaq	0x18(%r12), %rbx
   108a2:      	movl	$0x4, %eax
   108a7:      	movq	%rbp, %rdi
   108aa:      	movl	$0x8, %esi
   108af:      	movq	%rbx, %rdx
   108b2:      	callq	*%rax
   108b4:      	cmpq	%r12, (%rsp)
   108b8:      	je	0x1098f <generic_fentry_path+0x56af>
   108be:      	movl	$0x4, %eax
   108c3:      	leaq	0x8(%rsp), %rdi
   108c8:      	movl	$0x8, %esi
   108cd:      	movq	%rbx, %rdx
   108d0:      	callq	*%rax
   108d2:      	addq	$0x20, %r12
   108d6:      	movl	$0x4, %eax
   108db:      	leaq	0x58(%rsp), %rdi
   108e0:      	movl	$0x10, %ecx
   108e5:      	movl	$0x10, %esi
   108ea:      	movq	%r12, %rdx
   108ed:      	callq	*%rax
   108ef:      	movq	0x28(%rsp), %rbx
   108f4:      	movq	0x48(%rsp), %rax
   108f9:      	movl	0x5c(%rsp), %r15d
   108fe:      	subq	%rbx, %rax
   10901:      	movl	0x50(%rsp), %r12d
   10906:      	movl	%r15d, %edx
   10909:      	subl	%r12d, %edx
   1090c:      	movl	$0x0, %ecx
   10911:      	cmovbl	%ecx, %edx
   10914:      	addq	0x60(%rsp), %rdx
   10919:      	xorl	%esi, %esi
   1091b:      	cmpl	%r15d, %r12d
   1091e:      	seta	%sil
   10922:      	movl	%r15d, %ecx
   10925:      	cmovbl	%r12d, %ecx
   10929:      	addl	%ecx, %esi
   1092b:      	movl	%r12d, %edi
   1092e:      	subl	%esi, %edi
   10930:      	movl	%edi, 0x50(%rsp)
   10934:      	subq	%rsi, %rax
   10937:      	jb	0x16d52 <generic_fentry_path+0xba72>
   1093d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10943:      	ja	0x16d52 <generic_fentry_path+0xba72>
   10949:      	cmpl	%r15d, %r12d
   1094c:      	jbe	0x10952 <generic_fentry_path+0x5672>
   1094e:      	movb	$0x2f, (%rbx,%rax)
   10952:      	xorl	%edi, %edi
   10954:      	cmpl	%r15d, %r12d
   10957:      	seta	%dil
   1095b:      	movzbl	%cl, %esi
   1095e:      	addq	%rax, %rbx
   10961:      	addq	%rbx, %rdi
   10964:      	movl	$0x4, %eax
   10969:      	callq	*%rax
   1096b:      	movq	%rbx, 0x48(%rsp)
   10970:      	cmpl	%r15d, %r12d
   10973:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   10979:      	movq	0x8(%rsp), %r12
   1097e:      	movq	%r12, 0x30(%rsp)
   10983:      	movq	0x38(%rsp), %rdx
   10988:      	movq	0x40(%rsp), %r15
   1098d:      	jmp	0x109e0 <generic_fentry_path+0x5700>
   1098f:      	leaq	0x10(%r15), %rdx
   10993:      	movl	$0x4, %eax
   10998:      	movq	%rbp, %rdi
   1099b:      	movl	$0x8, %esi
   109a0:      	callq	*%rax
   109a2:      	movq	0x40(%rsp), %rax
   109a7:      	cmpq	(%rsp), %rax
   109ab:      	je	0x16d4d <generic_fentry_path+0xba6d>
   109b1:      	addq	$0x18, %r15
   109b5:      	movl	$0x4, %eax
   109ba:      	leaq	0x30(%rsp), %rdi
   109bf:      	movl	$0x8, %esi
   109c4:      	movq	%r15, %rdx
   109c7:      	callq	*%rax
   109c9:      	movq	(%rsp), %r15
   109cd:      	movq	%r15, 0x40(%rsp)
   109d2:      	leaq	0x20(%r15), %rdx
   109d6:      	movq	%rdx, 0x38(%rsp)
   109db:      	movq	0x30(%rsp), %r12
   109e0:      	cmpq	0x18(%rsp), %r12
   109e5:      	jne	0x109f2 <generic_fentry_path+0x5712>
   109e7:      	cmpq	0x20(%rsp), %rdx
   109ec:      	je	0x16d4d <generic_fentry_path+0xba6d>
   109f2:      	movl	$0x4, %eax
   109f7:      	leaq	0x10(%rsp), %rdi
   109fc:      	movl	$0x8, %esi
   10a01:      	callq	*%rax
   10a03:      	cmpq	0x10(%rsp), %r12
   10a08:      	je	0x10b00 <generic_fentry_path+0x5820>
   10a0e:      	leaq	0x18(%r12), %rbx
   10a13:      	movl	$0x4, %eax
   10a18:      	movq	%rbp, %rdi
   10a1b:      	movl	$0x8, %esi
   10a20:      	movq	%rbx, %rdx
   10a23:      	callq	*%rax
   10a25:      	cmpq	%r12, (%rsp)
   10a29:      	je	0x10b00 <generic_fentry_path+0x5820>
   10a2f:      	movl	$0x4, %eax
   10a34:      	leaq	0x8(%rsp), %rdi
   10a39:      	movl	$0x8, %esi
   10a3e:      	movq	%rbx, %rdx
   10a41:      	callq	*%rax
   10a43:      	addq	$0x20, %r12
   10a47:      	movl	$0x4, %eax
   10a4c:      	leaq	0x58(%rsp), %rdi
   10a51:      	movl	$0x10, %ecx
   10a56:      	movl	$0x10, %esi
   10a5b:      	movq	%r12, %rdx
   10a5e:      	callq	*%rax
   10a60:      	movq	0x28(%rsp), %rbx
   10a65:      	movq	0x48(%rsp), %rax
   10a6a:      	movl	0x5c(%rsp), %r15d
   10a6f:      	subq	%rbx, %rax
   10a72:      	movl	0x50(%rsp), %r12d
   10a77:      	movl	%r15d, %edx
   10a7a:      	subl	%r12d, %edx
   10a7d:      	movl	$0x0, %ecx
   10a82:      	cmovbl	%ecx, %edx
   10a85:      	addq	0x60(%rsp), %rdx
   10a8a:      	xorl	%esi, %esi
   10a8c:      	cmpl	%r15d, %r12d
   10a8f:      	seta	%sil
   10a93:      	movl	%r15d, %ecx
   10a96:      	cmovbl	%r12d, %ecx
   10a9a:      	addl	%ecx, %esi
   10a9c:      	movl	%r12d, %edi
   10a9f:      	subl	%esi, %edi
   10aa1:      	movl	%edi, 0x50(%rsp)
   10aa5:      	subq	%rsi, %rax
   10aa8:      	jb	0x16d52 <generic_fentry_path+0xba72>
   10aae:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10ab4:      	ja	0x16d52 <generic_fentry_path+0xba72>
   10aba:      	cmpl	%r15d, %r12d
   10abd:      	jbe	0x10ac3 <generic_fentry_path+0x57e3>
   10abf:      	movb	$0x2f, (%rbx,%rax)
   10ac3:      	xorl	%edi, %edi
   10ac5:      	cmpl	%r15d, %r12d
   10ac8:      	seta	%dil
   10acc:      	movzbl	%cl, %esi
   10acf:      	addq	%rax, %rbx
   10ad2:      	addq	%rbx, %rdi
   10ad5:      	movl	$0x4, %eax
   10ada:      	callq	*%rax
   10adc:      	movq	%rbx, 0x48(%rsp)
   10ae1:      	cmpl	%r15d, %r12d
   10ae4:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   10aea:      	movq	0x8(%rsp), %r12
   10aef:      	movq	%r12, 0x30(%rsp)
   10af4:      	movq	0x38(%rsp), %rdx
   10af9:      	movq	0x40(%rsp), %r15
   10afe:      	jmp	0x10b51 <generic_fentry_path+0x5871>
   10b00:      	leaq	0x10(%r15), %rdx
   10b04:      	movl	$0x4, %eax
   10b09:      	movq	%rbp, %rdi
   10b0c:      	movl	$0x8, %esi
   10b11:      	callq	*%rax
   10b13:      	movq	0x40(%rsp), %rax
   10b18:      	cmpq	(%rsp), %rax
   10b1c:      	je	0x16d4d <generic_fentry_path+0xba6d>
   10b22:      	addq	$0x18, %r15
   10b26:      	movl	$0x4, %eax
   10b2b:      	leaq	0x30(%rsp), %rdi
   10b30:      	movl	$0x8, %esi
   10b35:      	movq	%r15, %rdx
   10b38:      	callq	*%rax
   10b3a:      	movq	(%rsp), %r15
   10b3e:      	movq	%r15, 0x40(%rsp)
   10b43:      	leaq	0x20(%r15), %rdx
   10b47:      	movq	%rdx, 0x38(%rsp)
   10b4c:      	movq	0x30(%rsp), %r12
   10b51:      	cmpq	0x18(%rsp), %r12
   10b56:      	jne	0x10b63 <generic_fentry_path+0x5883>
   10b58:      	cmpq	0x20(%rsp), %rdx
   10b5d:      	je	0x16d4d <generic_fentry_path+0xba6d>
   10b63:      	movl	$0x4, %eax
   10b68:      	leaq	0x10(%rsp), %rdi
   10b6d:      	movl	$0x8, %esi
   10b72:      	callq	*%rax
   10b74:      	cmpq	0x10(%rsp), %r12
   10b79:      	je	0x10c71 <generic_fentry_path+0x5991>
   10b7f:      	leaq	0x18(%r12), %rbx
   10b84:      	movl	$0x4, %eax
   10b89:      	movq	%rbp, %rdi
   10b8c:      	movl	$0x8, %esi
   10b91:      	movq	%rbx, %rdx
   10b94:      	callq	*%rax
   10b96:      	cmpq	%r12, (%rsp)
   10b9a:      	je	0x10c71 <generic_fentry_path+0x5991>
   10ba0:      	movl	$0x4, %eax
   10ba5:      	leaq	0x8(%rsp), %rdi
   10baa:      	movl	$0x8, %esi
   10baf:      	movq	%rbx, %rdx
   10bb2:      	callq	*%rax
   10bb4:      	addq	$0x20, %r12
   10bb8:      	movl	$0x4, %eax
   10bbd:      	leaq	0x58(%rsp), %rdi
   10bc2:      	movl	$0x10, %ecx
   10bc7:      	movl	$0x10, %esi
   10bcc:      	movq	%r12, %rdx
   10bcf:      	callq	*%rax
   10bd1:      	movq	0x28(%rsp), %rbx
   10bd6:      	movq	0x48(%rsp), %rax
   10bdb:      	movl	0x5c(%rsp), %r15d
   10be0:      	subq	%rbx, %rax
   10be3:      	movl	0x50(%rsp), %r12d
   10be8:      	movl	%r15d, %edx
   10beb:      	subl	%r12d, %edx
   10bee:      	movl	$0x0, %ecx
   10bf3:      	cmovbl	%ecx, %edx
   10bf6:      	addq	0x60(%rsp), %rdx
   10bfb:      	xorl	%esi, %esi
   10bfd:      	cmpl	%r15d, %r12d
   10c00:      	seta	%sil
   10c04:      	movl	%r15d, %ecx
   10c07:      	cmovbl	%r12d, %ecx
   10c0b:      	addl	%ecx, %esi
   10c0d:      	movl	%r12d, %edi
   10c10:      	subl	%esi, %edi
   10c12:      	movl	%edi, 0x50(%rsp)
   10c16:      	subq	%rsi, %rax
   10c19:      	jb	0x16d52 <generic_fentry_path+0xba72>
   10c1f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10c25:      	ja	0x16d52 <generic_fentry_path+0xba72>
   10c2b:      	cmpl	%r15d, %r12d
   10c2e:      	jbe	0x10c34 <generic_fentry_path+0x5954>
   10c30:      	movb	$0x2f, (%rbx,%rax)
   10c34:      	xorl	%edi, %edi
   10c36:      	cmpl	%r15d, %r12d
   10c39:      	seta	%dil
   10c3d:      	movzbl	%cl, %esi
   10c40:      	addq	%rax, %rbx
   10c43:      	addq	%rbx, %rdi
   10c46:      	movl	$0x4, %eax
   10c4b:      	callq	*%rax
   10c4d:      	movq	%rbx, 0x48(%rsp)
   10c52:      	cmpl	%r15d, %r12d
   10c55:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   10c5b:      	movq	0x8(%rsp), %r12
   10c60:      	movq	%r12, 0x30(%rsp)
   10c65:      	movq	0x38(%rsp), %rdx
   10c6a:      	movq	0x40(%rsp), %r15
   10c6f:      	jmp	0x10cc2 <generic_fentry_path+0x59e2>
   10c71:      	leaq	0x10(%r15), %rdx
   10c75:      	movl	$0x4, %eax
   10c7a:      	movq	%rbp, %rdi
   10c7d:      	movl	$0x8, %esi
   10c82:      	callq	*%rax
   10c84:      	movq	0x40(%rsp), %rax
   10c89:      	cmpq	(%rsp), %rax
   10c8d:      	je	0x16d4d <generic_fentry_path+0xba6d>
   10c93:      	addq	$0x18, %r15
   10c97:      	movl	$0x4, %eax
   10c9c:      	leaq	0x30(%rsp), %rdi
   10ca1:      	movl	$0x8, %esi
   10ca6:      	movq	%r15, %rdx
   10ca9:      	callq	*%rax
   10cab:      	movq	(%rsp), %r15
   10caf:      	movq	%r15, 0x40(%rsp)
   10cb4:      	leaq	0x20(%r15), %rdx
   10cb8:      	movq	%rdx, 0x38(%rsp)
   10cbd:      	movq	0x30(%rsp), %r12
   10cc2:      	cmpq	0x18(%rsp), %r12
   10cc7:      	jne	0x10cd4 <generic_fentry_path+0x59f4>
   10cc9:      	cmpq	0x20(%rsp), %rdx
   10cce:      	je	0x16d4d <generic_fentry_path+0xba6d>
   10cd4:      	movl	$0x4, %eax
   10cd9:      	leaq	0x10(%rsp), %rdi
   10cde:      	movl	$0x8, %esi
   10ce3:      	callq	*%rax
   10ce5:      	cmpq	0x10(%rsp), %r12
   10cea:      	je	0x10de2 <generic_fentry_path+0x5b02>
   10cf0:      	leaq	0x18(%r12), %rbx
   10cf5:      	movl	$0x4, %eax
   10cfa:      	movq	%rbp, %rdi
   10cfd:      	movl	$0x8, %esi
   10d02:      	movq	%rbx, %rdx
   10d05:      	callq	*%rax
   10d07:      	cmpq	%r12, (%rsp)
   10d0b:      	je	0x10de2 <generic_fentry_path+0x5b02>
   10d11:      	movl	$0x4, %eax
   10d16:      	leaq	0x8(%rsp), %rdi
   10d1b:      	movl	$0x8, %esi
   10d20:      	movq	%rbx, %rdx
   10d23:      	callq	*%rax
   10d25:      	addq	$0x20, %r12
   10d29:      	movl	$0x4, %eax
   10d2e:      	leaq	0x58(%rsp), %rdi
   10d33:      	movl	$0x10, %ecx
   10d38:      	movl	$0x10, %esi
   10d3d:      	movq	%r12, %rdx
   10d40:      	callq	*%rax
   10d42:      	movq	0x28(%rsp), %rbx
   10d47:      	movq	0x48(%rsp), %rax
   10d4c:      	movl	0x5c(%rsp), %r15d
   10d51:      	subq	%rbx, %rax
   10d54:      	movl	0x50(%rsp), %r12d
   10d59:      	movl	%r15d, %edx
   10d5c:      	subl	%r12d, %edx
   10d5f:      	movl	$0x0, %ecx
   10d64:      	cmovbl	%ecx, %edx
   10d67:      	addq	0x60(%rsp), %rdx
   10d6c:      	xorl	%esi, %esi
   10d6e:      	cmpl	%r15d, %r12d
   10d71:      	seta	%sil
   10d75:      	movl	%r15d, %ecx
   10d78:      	cmovbl	%r12d, %ecx
   10d7c:      	addl	%ecx, %esi
   10d7e:      	movl	%r12d, %edi
   10d81:      	subl	%esi, %edi
   10d83:      	movl	%edi, 0x50(%rsp)
   10d87:      	subq	%rsi, %rax
   10d8a:      	jb	0x16d52 <generic_fentry_path+0xba72>
   10d90:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10d96:      	ja	0x16d52 <generic_fentry_path+0xba72>
   10d9c:      	cmpl	%r15d, %r12d
   10d9f:      	jbe	0x10da5 <generic_fentry_path+0x5ac5>
   10da1:      	movb	$0x2f, (%rbx,%rax)
   10da5:      	xorl	%edi, %edi
   10da7:      	cmpl	%r15d, %r12d
   10daa:      	seta	%dil
   10dae:      	movzbl	%cl, %esi
   10db1:      	addq	%rax, %rbx
   10db4:      	addq	%rbx, %rdi
   10db7:      	movl	$0x4, %eax
   10dbc:      	callq	*%rax
   10dbe:      	movq	%rbx, 0x48(%rsp)
   10dc3:      	cmpl	%r15d, %r12d
   10dc6:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   10dcc:      	movq	0x8(%rsp), %r12
   10dd1:      	movq	%r12, 0x30(%rsp)
   10dd6:      	movq	0x38(%rsp), %rdx
   10ddb:      	movq	0x40(%rsp), %r15
   10de0:      	jmp	0x10e33 <generic_fentry_path+0x5b53>
   10de2:      	leaq	0x10(%r15), %rdx
   10de6:      	movl	$0x4, %eax
   10deb:      	movq	%rbp, %rdi
   10dee:      	movl	$0x8, %esi
   10df3:      	callq	*%rax
   10df5:      	movq	0x40(%rsp), %rax
   10dfa:      	cmpq	(%rsp), %rax
   10dfe:      	je	0x16d4d <generic_fentry_path+0xba6d>
   10e04:      	addq	$0x18, %r15
   10e08:      	movl	$0x4, %eax
   10e0d:      	leaq	0x30(%rsp), %rdi
   10e12:      	movl	$0x8, %esi
   10e17:      	movq	%r15, %rdx
   10e1a:      	callq	*%rax
   10e1c:      	movq	(%rsp), %r15
   10e20:      	movq	%r15, 0x40(%rsp)
   10e25:      	leaq	0x20(%r15), %rdx
   10e29:      	movq	%rdx, 0x38(%rsp)
   10e2e:      	movq	0x30(%rsp), %r12
   10e33:      	cmpq	0x18(%rsp), %r12
   10e38:      	jne	0x10e45 <generic_fentry_path+0x5b65>
   10e3a:      	cmpq	0x20(%rsp), %rdx
   10e3f:      	je	0x16d4d <generic_fentry_path+0xba6d>
   10e45:      	movl	$0x4, %eax
   10e4a:      	leaq	0x10(%rsp), %rdi
   10e4f:      	movl	$0x8, %esi
   10e54:      	callq	*%rax
   10e56:      	cmpq	0x10(%rsp), %r12
   10e5b:      	je	0x10f53 <generic_fentry_path+0x5c73>
   10e61:      	leaq	0x18(%r12), %rbx
   10e66:      	movl	$0x4, %eax
   10e6b:      	movq	%rbp, %rdi
   10e6e:      	movl	$0x8, %esi
   10e73:      	movq	%rbx, %rdx
   10e76:      	callq	*%rax
   10e78:      	cmpq	%r12, (%rsp)
   10e7c:      	je	0x10f53 <generic_fentry_path+0x5c73>
   10e82:      	movl	$0x4, %eax
   10e87:      	leaq	0x8(%rsp), %rdi
   10e8c:      	movl	$0x8, %esi
   10e91:      	movq	%rbx, %rdx
   10e94:      	callq	*%rax
   10e96:      	addq	$0x20, %r12
   10e9a:      	movl	$0x4, %eax
   10e9f:      	leaq	0x58(%rsp), %rdi
   10ea4:      	movl	$0x10, %ecx
   10ea9:      	movl	$0x10, %esi
   10eae:      	movq	%r12, %rdx
   10eb1:      	callq	*%rax
   10eb3:      	movq	0x28(%rsp), %rbx
   10eb8:      	movq	0x48(%rsp), %rax
   10ebd:      	movl	0x5c(%rsp), %r15d
   10ec2:      	subq	%rbx, %rax
   10ec5:      	movl	0x50(%rsp), %r12d
   10eca:      	movl	%r15d, %edx
   10ecd:      	subl	%r12d, %edx
   10ed0:      	movl	$0x0, %ecx
   10ed5:      	cmovbl	%ecx, %edx
   10ed8:      	addq	0x60(%rsp), %rdx
   10edd:      	xorl	%esi, %esi
   10edf:      	cmpl	%r15d, %r12d
   10ee2:      	seta	%sil
   10ee6:      	movl	%r15d, %ecx
   10ee9:      	cmovbl	%r12d, %ecx
   10eed:      	addl	%ecx, %esi
   10eef:      	movl	%r12d, %edi
   10ef2:      	subl	%esi, %edi
   10ef4:      	movl	%edi, 0x50(%rsp)
   10ef8:      	subq	%rsi, %rax
   10efb:      	jb	0x16d52 <generic_fentry_path+0xba72>
   10f01:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10f07:      	ja	0x16d52 <generic_fentry_path+0xba72>
   10f0d:      	cmpl	%r15d, %r12d
   10f10:      	jbe	0x10f16 <generic_fentry_path+0x5c36>
   10f12:      	movb	$0x2f, (%rbx,%rax)
   10f16:      	xorl	%edi, %edi
   10f18:      	cmpl	%r15d, %r12d
   10f1b:      	seta	%dil
   10f1f:      	movzbl	%cl, %esi
   10f22:      	addq	%rax, %rbx
   10f25:      	addq	%rbx, %rdi
   10f28:      	movl	$0x4, %eax
   10f2d:      	callq	*%rax
   10f2f:      	movq	%rbx, 0x48(%rsp)
   10f34:      	cmpl	%r15d, %r12d
   10f37:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   10f3d:      	movq	0x8(%rsp), %r12
   10f42:      	movq	%r12, 0x30(%rsp)
   10f47:      	movq	0x38(%rsp), %rdx
   10f4c:      	movq	0x40(%rsp), %r15
   10f51:      	jmp	0x10fa4 <generic_fentry_path+0x5cc4>
   10f53:      	leaq	0x10(%r15), %rdx
   10f57:      	movl	$0x4, %eax
   10f5c:      	movq	%rbp, %rdi
   10f5f:      	movl	$0x8, %esi
   10f64:      	callq	*%rax
   10f66:      	movq	0x40(%rsp), %rax
   10f6b:      	cmpq	(%rsp), %rax
   10f6f:      	je	0x16d4d <generic_fentry_path+0xba6d>
   10f75:      	addq	$0x18, %r15
   10f79:      	movl	$0x4, %eax
   10f7e:      	leaq	0x30(%rsp), %rdi
   10f83:      	movl	$0x8, %esi
   10f88:      	movq	%r15, %rdx
   10f8b:      	callq	*%rax
   10f8d:      	movq	(%rsp), %r15
   10f91:      	movq	%r15, 0x40(%rsp)
   10f96:      	leaq	0x20(%r15), %rdx
   10f9a:      	movq	%rdx, 0x38(%rsp)
   10f9f:      	movq	0x30(%rsp), %r12
   10fa4:      	cmpq	0x18(%rsp), %r12
   10fa9:      	jne	0x10fb6 <generic_fentry_path+0x5cd6>
   10fab:      	cmpq	0x20(%rsp), %rdx
   10fb0:      	je	0x16d4d <generic_fentry_path+0xba6d>
   10fb6:      	movl	$0x4, %eax
   10fbb:      	leaq	0x10(%rsp), %rdi
   10fc0:      	movl	$0x8, %esi
   10fc5:      	callq	*%rax
   10fc7:      	cmpq	0x10(%rsp), %r12
   10fcc:      	je	0x110c4 <generic_fentry_path+0x5de4>
   10fd2:      	leaq	0x18(%r12), %rbx
   10fd7:      	movl	$0x4, %eax
   10fdc:      	movq	%rbp, %rdi
   10fdf:      	movl	$0x8, %esi
   10fe4:      	movq	%rbx, %rdx
   10fe7:      	callq	*%rax
   10fe9:      	cmpq	%r12, (%rsp)
   10fed:      	je	0x110c4 <generic_fentry_path+0x5de4>
   10ff3:      	movl	$0x4, %eax
   10ff8:      	leaq	0x8(%rsp), %rdi
   10ffd:      	movl	$0x8, %esi
   11002:      	movq	%rbx, %rdx
   11005:      	callq	*%rax
   11007:      	addq	$0x20, %r12
   1100b:      	movl	$0x4, %eax
   11010:      	leaq	0x58(%rsp), %rdi
   11015:      	movl	$0x10, %ecx
   1101a:      	movl	$0x10, %esi
   1101f:      	movq	%r12, %rdx
   11022:      	callq	*%rax
   11024:      	movq	0x28(%rsp), %rbx
   11029:      	movq	0x48(%rsp), %rax
   1102e:      	movl	0x5c(%rsp), %r15d
   11033:      	subq	%rbx, %rax
   11036:      	movl	0x50(%rsp), %r12d
   1103b:      	movl	%r15d, %edx
   1103e:      	subl	%r12d, %edx
   11041:      	movl	$0x0, %ecx
   11046:      	cmovbl	%ecx, %edx
   11049:      	addq	0x60(%rsp), %rdx
   1104e:      	xorl	%esi, %esi
   11050:      	cmpl	%r15d, %r12d
   11053:      	seta	%sil
   11057:      	movl	%r15d, %ecx
   1105a:      	cmovbl	%r12d, %ecx
   1105e:      	addl	%ecx, %esi
   11060:      	movl	%r12d, %edi
   11063:      	subl	%esi, %edi
   11065:      	movl	%edi, 0x50(%rsp)
   11069:      	subq	%rsi, %rax
   1106c:      	jb	0x16d52 <generic_fentry_path+0xba72>
   11072:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11078:      	ja	0x16d52 <generic_fentry_path+0xba72>
   1107e:      	cmpl	%r15d, %r12d
   11081:      	jbe	0x11087 <generic_fentry_path+0x5da7>
   11083:      	movb	$0x2f, (%rbx,%rax)
   11087:      	xorl	%edi, %edi
   11089:      	cmpl	%r15d, %r12d
   1108c:      	seta	%dil
   11090:      	movzbl	%cl, %esi
   11093:      	addq	%rax, %rbx
   11096:      	addq	%rbx, %rdi
   11099:      	movl	$0x4, %eax
   1109e:      	callq	*%rax
   110a0:      	movq	%rbx, 0x48(%rsp)
   110a5:      	cmpl	%r15d, %r12d
   110a8:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   110ae:      	movq	0x8(%rsp), %r12
   110b3:      	movq	%r12, 0x30(%rsp)
   110b8:      	movq	0x38(%rsp), %rdx
   110bd:      	movq	0x40(%rsp), %r15
   110c2:      	jmp	0x11115 <generic_fentry_path+0x5e35>
   110c4:      	leaq	0x10(%r15), %rdx
   110c8:      	movl	$0x4, %eax
   110cd:      	movq	%rbp, %rdi
   110d0:      	movl	$0x8, %esi
   110d5:      	callq	*%rax
   110d7:      	movq	0x40(%rsp), %rax
   110dc:      	cmpq	(%rsp), %rax
   110e0:      	je	0x16d4d <generic_fentry_path+0xba6d>
   110e6:      	addq	$0x18, %r15
   110ea:      	movl	$0x4, %eax
   110ef:      	leaq	0x30(%rsp), %rdi
   110f4:      	movl	$0x8, %esi
   110f9:      	movq	%r15, %rdx
   110fc:      	callq	*%rax
   110fe:      	movq	(%rsp), %r15
   11102:      	movq	%r15, 0x40(%rsp)
   11107:      	leaq	0x20(%r15), %rdx
   1110b:      	movq	%rdx, 0x38(%rsp)
   11110:      	movq	0x30(%rsp), %r12
   11115:      	cmpq	0x18(%rsp), %r12
   1111a:      	jne	0x11127 <generic_fentry_path+0x5e47>
   1111c:      	cmpq	0x20(%rsp), %rdx
   11121:      	je	0x16d4d <generic_fentry_path+0xba6d>
   11127:      	movl	$0x4, %eax
   1112c:      	leaq	0x10(%rsp), %rdi
   11131:      	movl	$0x8, %esi
   11136:      	callq	*%rax
   11138:      	cmpq	0x10(%rsp), %r12
   1113d:      	je	0x11235 <generic_fentry_path+0x5f55>
   11143:      	leaq	0x18(%r12), %rbx
   11148:      	movl	$0x4, %eax
   1114d:      	movq	%rbp, %rdi
   11150:      	movl	$0x8, %esi
   11155:      	movq	%rbx, %rdx
   11158:      	callq	*%rax
   1115a:      	cmpq	%r12, (%rsp)
   1115e:      	je	0x11235 <generic_fentry_path+0x5f55>
   11164:      	movl	$0x4, %eax
   11169:      	leaq	0x8(%rsp), %rdi
   1116e:      	movl	$0x8, %esi
   11173:      	movq	%rbx, %rdx
   11176:      	callq	*%rax
   11178:      	addq	$0x20, %r12
   1117c:      	movl	$0x4, %eax
   11181:      	leaq	0x58(%rsp), %rdi
   11186:      	movl	$0x10, %ecx
   1118b:      	movl	$0x10, %esi
   11190:      	movq	%r12, %rdx
   11193:      	callq	*%rax
   11195:      	movq	0x28(%rsp), %rbx
   1119a:      	movq	0x48(%rsp), %rax
   1119f:      	movl	0x5c(%rsp), %r15d
   111a4:      	subq	%rbx, %rax
   111a7:      	movl	0x50(%rsp), %r12d
   111ac:      	movl	%r15d, %edx
   111af:      	subl	%r12d, %edx
   111b2:      	movl	$0x0, %ecx
   111b7:      	cmovbl	%ecx, %edx
   111ba:      	addq	0x60(%rsp), %rdx
   111bf:      	xorl	%esi, %esi
   111c1:      	cmpl	%r15d, %r12d
   111c4:      	seta	%sil
   111c8:      	movl	%r15d, %ecx
   111cb:      	cmovbl	%r12d, %ecx
   111cf:      	addl	%ecx, %esi
   111d1:      	movl	%r12d, %edi
   111d4:      	subl	%esi, %edi
   111d6:      	movl	%edi, 0x50(%rsp)
   111da:      	subq	%rsi, %rax
   111dd:      	jb	0x16d52 <generic_fentry_path+0xba72>
   111e3:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   111e9:      	ja	0x16d52 <generic_fentry_path+0xba72>
   111ef:      	cmpl	%r15d, %r12d
   111f2:      	jbe	0x111f8 <generic_fentry_path+0x5f18>
   111f4:      	movb	$0x2f, (%rbx,%rax)
   111f8:      	xorl	%edi, %edi
   111fa:      	cmpl	%r15d, %r12d
   111fd:      	seta	%dil
   11201:      	movzbl	%cl, %esi
   11204:      	addq	%rax, %rbx
   11207:      	addq	%rbx, %rdi
   1120a:      	movl	$0x4, %eax
   1120f:      	callq	*%rax
   11211:      	movq	%rbx, 0x48(%rsp)
   11216:      	cmpl	%r15d, %r12d
   11219:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   1121f:      	movq	0x8(%rsp), %r12
   11224:      	movq	%r12, 0x30(%rsp)
   11229:      	movq	0x38(%rsp), %rdx
   1122e:      	movq	0x40(%rsp), %r15
   11233:      	jmp	0x11286 <generic_fentry_path+0x5fa6>
   11235:      	leaq	0x10(%r15), %rdx
   11239:      	movl	$0x4, %eax
   1123e:      	movq	%rbp, %rdi
   11241:      	movl	$0x8, %esi
   11246:      	callq	*%rax
   11248:      	movq	0x40(%rsp), %rax
   1124d:      	cmpq	(%rsp), %rax
   11251:      	je	0x16d4d <generic_fentry_path+0xba6d>
   11257:      	addq	$0x18, %r15
   1125b:      	movl	$0x4, %eax
   11260:      	leaq	0x30(%rsp), %rdi
   11265:      	movl	$0x8, %esi
   1126a:      	movq	%r15, %rdx
   1126d:      	callq	*%rax
   1126f:      	movq	(%rsp), %r15
   11273:      	movq	%r15, 0x40(%rsp)
   11278:      	leaq	0x20(%r15), %rdx
   1127c:      	movq	%rdx, 0x38(%rsp)
   11281:      	movq	0x30(%rsp), %r12
   11286:      	cmpq	0x18(%rsp), %r12
   1128b:      	jne	0x11298 <generic_fentry_path+0x5fb8>
   1128d:      	cmpq	0x20(%rsp), %rdx
   11292:      	je	0x16d4d <generic_fentry_path+0xba6d>
   11298:      	movl	$0x4, %eax
   1129d:      	leaq	0x10(%rsp), %rdi
   112a2:      	movl	$0x8, %esi
   112a7:      	callq	*%rax
   112a9:      	cmpq	0x10(%rsp), %r12
   112ae:      	je	0x113a6 <generic_fentry_path+0x60c6>
   112b4:      	leaq	0x18(%r12), %rbx
   112b9:      	movl	$0x4, %eax
   112be:      	movq	%rbp, %rdi
   112c1:      	movl	$0x8, %esi
   112c6:      	movq	%rbx, %rdx
   112c9:      	callq	*%rax
   112cb:      	cmpq	%r12, (%rsp)
   112cf:      	je	0x113a6 <generic_fentry_path+0x60c6>
   112d5:      	movl	$0x4, %eax
   112da:      	leaq	0x8(%rsp), %rdi
   112df:      	movl	$0x8, %esi
   112e4:      	movq	%rbx, %rdx
   112e7:      	callq	*%rax
   112e9:      	addq	$0x20, %r12
   112ed:      	movl	$0x4, %eax
   112f2:      	leaq	0x58(%rsp), %rdi
   112f7:      	movl	$0x10, %ecx
   112fc:      	movl	$0x10, %esi
   11301:      	movq	%r12, %rdx
   11304:      	callq	*%rax
   11306:      	movq	0x28(%rsp), %rbx
   1130b:      	movq	0x48(%rsp), %rax
   11310:      	movl	0x5c(%rsp), %r15d
   11315:      	subq	%rbx, %rax
   11318:      	movl	0x50(%rsp), %r12d
   1131d:      	movl	%r15d, %edx
   11320:      	subl	%r12d, %edx
   11323:      	movl	$0x0, %ecx
   11328:      	cmovbl	%ecx, %edx
   1132b:      	addq	0x60(%rsp), %rdx
   11330:      	xorl	%esi, %esi
   11332:      	cmpl	%r15d, %r12d
   11335:      	seta	%sil
   11339:      	movl	%r15d, %ecx
   1133c:      	cmovbl	%r12d, %ecx
   11340:      	addl	%ecx, %esi
   11342:      	movl	%r12d, %edi
   11345:      	subl	%esi, %edi
   11347:      	movl	%edi, 0x50(%rsp)
   1134b:      	subq	%rsi, %rax
   1134e:      	jb	0x16d52 <generic_fentry_path+0xba72>
   11354:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1135a:      	ja	0x16d52 <generic_fentry_path+0xba72>
   11360:      	cmpl	%r15d, %r12d
   11363:      	jbe	0x11369 <generic_fentry_path+0x6089>
   11365:      	movb	$0x2f, (%rbx,%rax)
   11369:      	xorl	%edi, %edi
   1136b:      	cmpl	%r15d, %r12d
   1136e:      	seta	%dil
   11372:      	movzbl	%cl, %esi
   11375:      	addq	%rax, %rbx
   11378:      	addq	%rbx, %rdi
   1137b:      	movl	$0x4, %eax
   11380:      	callq	*%rax
   11382:      	movq	%rbx, 0x48(%rsp)
   11387:      	cmpl	%r15d, %r12d
   1138a:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   11390:      	movq	0x8(%rsp), %r12
   11395:      	movq	%r12, 0x30(%rsp)
   1139a:      	movq	0x38(%rsp), %rdx
   1139f:      	movq	0x40(%rsp), %r15
   113a4:      	jmp	0x113f7 <generic_fentry_path+0x6117>
   113a6:      	leaq	0x10(%r15), %rdx
   113aa:      	movl	$0x4, %eax
   113af:      	movq	%rbp, %rdi
   113b2:      	movl	$0x8, %esi
   113b7:      	callq	*%rax
   113b9:      	movq	0x40(%rsp), %rax
   113be:      	cmpq	(%rsp), %rax
   113c2:      	je	0x16d4d <generic_fentry_path+0xba6d>
   113c8:      	addq	$0x18, %r15
   113cc:      	movl	$0x4, %eax
   113d1:      	leaq	0x30(%rsp), %rdi
   113d6:      	movl	$0x8, %esi
   113db:      	movq	%r15, %rdx
   113de:      	callq	*%rax
   113e0:      	movq	(%rsp), %r15
   113e4:      	movq	%r15, 0x40(%rsp)
   113e9:      	leaq	0x20(%r15), %rdx
   113ed:      	movq	%rdx, 0x38(%rsp)
   113f2:      	movq	0x30(%rsp), %r12
   113f7:      	cmpq	0x18(%rsp), %r12
   113fc:      	jne	0x11409 <generic_fentry_path+0x6129>
   113fe:      	cmpq	0x20(%rsp), %rdx
   11403:      	je	0x16d4d <generic_fentry_path+0xba6d>
   11409:      	movl	$0x4, %eax
   1140e:      	leaq	0x10(%rsp), %rdi
   11413:      	movl	$0x8, %esi
   11418:      	callq	*%rax
   1141a:      	cmpq	0x10(%rsp), %r12
   1141f:      	je	0x11517 <generic_fentry_path+0x6237>
   11425:      	leaq	0x18(%r12), %rbx
   1142a:      	movl	$0x4, %eax
   1142f:      	movq	%rbp, %rdi
   11432:      	movl	$0x8, %esi
   11437:      	movq	%rbx, %rdx
   1143a:      	callq	*%rax
   1143c:      	cmpq	%r12, (%rsp)
   11440:      	je	0x11517 <generic_fentry_path+0x6237>
   11446:      	movl	$0x4, %eax
   1144b:      	leaq	0x8(%rsp), %rdi
   11450:      	movl	$0x8, %esi
   11455:      	movq	%rbx, %rdx
   11458:      	callq	*%rax
   1145a:      	addq	$0x20, %r12
   1145e:      	movl	$0x4, %eax
   11463:      	leaq	0x58(%rsp), %rdi
   11468:      	movl	$0x10, %ecx
   1146d:      	movl	$0x10, %esi
   11472:      	movq	%r12, %rdx
   11475:      	callq	*%rax
   11477:      	movq	0x28(%rsp), %rbx
   1147c:      	movq	0x48(%rsp), %rax
   11481:      	movl	0x5c(%rsp), %r15d
   11486:      	subq	%rbx, %rax
   11489:      	movl	0x50(%rsp), %r12d
   1148e:      	movl	%r15d, %edx
   11491:      	subl	%r12d, %edx
   11494:      	movl	$0x0, %ecx
   11499:      	cmovbl	%ecx, %edx
   1149c:      	addq	0x60(%rsp), %rdx
   114a1:      	xorl	%esi, %esi
   114a3:      	cmpl	%r15d, %r12d
   114a6:      	seta	%sil
   114aa:      	movl	%r15d, %ecx
   114ad:      	cmovbl	%r12d, %ecx
   114b1:      	addl	%ecx, %esi
   114b3:      	movl	%r12d, %edi
   114b6:      	subl	%esi, %edi
   114b8:      	movl	%edi, 0x50(%rsp)
   114bc:      	subq	%rsi, %rax
   114bf:      	jb	0x16d52 <generic_fentry_path+0xba72>
   114c5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   114cb:      	ja	0x16d52 <generic_fentry_path+0xba72>
   114d1:      	cmpl	%r15d, %r12d
   114d4:      	jbe	0x114da <generic_fentry_path+0x61fa>
   114d6:      	movb	$0x2f, (%rbx,%rax)
   114da:      	xorl	%edi, %edi
   114dc:      	cmpl	%r15d, %r12d
   114df:      	seta	%dil
   114e3:      	movzbl	%cl, %esi
   114e6:      	addq	%rax, %rbx
   114e9:      	addq	%rbx, %rdi
   114ec:      	movl	$0x4, %eax
   114f1:      	callq	*%rax
   114f3:      	movq	%rbx, 0x48(%rsp)
   114f8:      	cmpl	%r15d, %r12d
   114fb:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   11501:      	movq	0x8(%rsp), %r12
   11506:      	movq	%r12, 0x30(%rsp)
   1150b:      	movq	0x38(%rsp), %rdx
   11510:      	movq	0x40(%rsp), %r15
   11515:      	jmp	0x11568 <generic_fentry_path+0x6288>
   11517:      	leaq	0x10(%r15), %rdx
   1151b:      	movl	$0x4, %eax
   11520:      	movq	%rbp, %rdi
   11523:      	movl	$0x8, %esi
   11528:      	callq	*%rax
   1152a:      	movq	0x40(%rsp), %rax
   1152f:      	cmpq	(%rsp), %rax
   11533:      	je	0x16d4d <generic_fentry_path+0xba6d>
   11539:      	addq	$0x18, %r15
   1153d:      	movl	$0x4, %eax
   11542:      	leaq	0x30(%rsp), %rdi
   11547:      	movl	$0x8, %esi
   1154c:      	movq	%r15, %rdx
   1154f:      	callq	*%rax
   11551:      	movq	(%rsp), %r15
   11555:      	movq	%r15, 0x40(%rsp)
   1155a:      	leaq	0x20(%r15), %rdx
   1155e:      	movq	%rdx, 0x38(%rsp)
   11563:      	movq	0x30(%rsp), %r12
   11568:      	cmpq	0x18(%rsp), %r12
   1156d:      	jne	0x1157a <generic_fentry_path+0x629a>
   1156f:      	cmpq	0x20(%rsp), %rdx
   11574:      	je	0x16d4d <generic_fentry_path+0xba6d>
   1157a:      	movl	$0x4, %eax
   1157f:      	leaq	0x10(%rsp), %rdi
   11584:      	movl	$0x8, %esi
   11589:      	callq	*%rax
   1158b:      	cmpq	0x10(%rsp), %r12
   11590:      	je	0x11688 <generic_fentry_path+0x63a8>
   11596:      	leaq	0x18(%r12), %rbx
   1159b:      	movl	$0x4, %eax
   115a0:      	movq	%rbp, %rdi
   115a3:      	movl	$0x8, %esi
   115a8:      	movq	%rbx, %rdx
   115ab:      	callq	*%rax
   115ad:      	cmpq	%r12, (%rsp)
   115b1:      	je	0x11688 <generic_fentry_path+0x63a8>
   115b7:      	movl	$0x4, %eax
   115bc:      	leaq	0x8(%rsp), %rdi
   115c1:      	movl	$0x8, %esi
   115c6:      	movq	%rbx, %rdx
   115c9:      	callq	*%rax
   115cb:      	addq	$0x20, %r12
   115cf:      	movl	$0x4, %eax
   115d4:      	leaq	0x58(%rsp), %rdi
   115d9:      	movl	$0x10, %ecx
   115de:      	movl	$0x10, %esi
   115e3:      	movq	%r12, %rdx
   115e6:      	callq	*%rax
   115e8:      	movq	0x28(%rsp), %rbx
   115ed:      	movq	0x48(%rsp), %rax
   115f2:      	movl	0x5c(%rsp), %r15d
   115f7:      	subq	%rbx, %rax
   115fa:      	movl	0x50(%rsp), %r12d
   115ff:      	movl	%r15d, %edx
   11602:      	subl	%r12d, %edx
   11605:      	movl	$0x0, %ecx
   1160a:      	cmovbl	%ecx, %edx
   1160d:      	addq	0x60(%rsp), %rdx
   11612:      	xorl	%esi, %esi
   11614:      	cmpl	%r15d, %r12d
   11617:      	seta	%sil
   1161b:      	movl	%r15d, %ecx
   1161e:      	cmovbl	%r12d, %ecx
   11622:      	addl	%ecx, %esi
   11624:      	movl	%r12d, %edi
   11627:      	subl	%esi, %edi
   11629:      	movl	%edi, 0x50(%rsp)
   1162d:      	subq	%rsi, %rax
   11630:      	jb	0x16d52 <generic_fentry_path+0xba72>
   11636:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1163c:      	ja	0x16d52 <generic_fentry_path+0xba72>
   11642:      	cmpl	%r15d, %r12d
   11645:      	jbe	0x1164b <generic_fentry_path+0x636b>
   11647:      	movb	$0x2f, (%rbx,%rax)
   1164b:      	xorl	%edi, %edi
   1164d:      	cmpl	%r15d, %r12d
   11650:      	seta	%dil
   11654:      	movzbl	%cl, %esi
   11657:      	addq	%rax, %rbx
   1165a:      	addq	%rbx, %rdi
   1165d:      	movl	$0x4, %eax
   11662:      	callq	*%rax
   11664:      	movq	%rbx, 0x48(%rsp)
   11669:      	cmpl	%r15d, %r12d
   1166c:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   11672:      	movq	0x8(%rsp), %r12
   11677:      	movq	%r12, 0x30(%rsp)
   1167c:      	movq	0x38(%rsp), %rdx
   11681:      	movq	0x40(%rsp), %r15
   11686:      	jmp	0x116d9 <generic_fentry_path+0x63f9>
   11688:      	leaq	0x10(%r15), %rdx
   1168c:      	movl	$0x4, %eax
   11691:      	movq	%rbp, %rdi
   11694:      	movl	$0x8, %esi
   11699:      	callq	*%rax
   1169b:      	movq	0x40(%rsp), %rax
   116a0:      	cmpq	(%rsp), %rax
   116a4:      	je	0x16d4d <generic_fentry_path+0xba6d>
   116aa:      	addq	$0x18, %r15
   116ae:      	movl	$0x4, %eax
   116b3:      	leaq	0x30(%rsp), %rdi
   116b8:      	movl	$0x8, %esi
   116bd:      	movq	%r15, %rdx
   116c0:      	callq	*%rax
   116c2:      	movq	(%rsp), %r15
   116c6:      	movq	%r15, 0x40(%rsp)
   116cb:      	leaq	0x20(%r15), %rdx
   116cf:      	movq	%rdx, 0x38(%rsp)
   116d4:      	movq	0x30(%rsp), %r12
   116d9:      	cmpq	0x18(%rsp), %r12
   116de:      	jne	0x116eb <generic_fentry_path+0x640b>
   116e0:      	cmpq	0x20(%rsp), %rdx
   116e5:      	je	0x16d4d <generic_fentry_path+0xba6d>
   116eb:      	movl	$0x4, %eax
   116f0:      	leaq	0x10(%rsp), %rdi
   116f5:      	movl	$0x8, %esi
   116fa:      	callq	*%rax
   116fc:      	cmpq	0x10(%rsp), %r12
   11701:      	je	0x117f9 <generic_fentry_path+0x6519>
   11707:      	leaq	0x18(%r12), %rbx
   1170c:      	movl	$0x4, %eax
   11711:      	movq	%rbp, %rdi
   11714:      	movl	$0x8, %esi
   11719:      	movq	%rbx, %rdx
   1171c:      	callq	*%rax
   1171e:      	cmpq	%r12, (%rsp)
   11722:      	je	0x117f9 <generic_fentry_path+0x6519>
   11728:      	movl	$0x4, %eax
   1172d:      	leaq	0x8(%rsp), %rdi
   11732:      	movl	$0x8, %esi
   11737:      	movq	%rbx, %rdx
   1173a:      	callq	*%rax
   1173c:      	addq	$0x20, %r12
   11740:      	movl	$0x4, %eax
   11745:      	leaq	0x58(%rsp), %rdi
   1174a:      	movl	$0x10, %ecx
   1174f:      	movl	$0x10, %esi
   11754:      	movq	%r12, %rdx
   11757:      	callq	*%rax
   11759:      	movq	0x28(%rsp), %rbx
   1175e:      	movq	0x48(%rsp), %rax
   11763:      	movl	0x5c(%rsp), %r15d
   11768:      	subq	%rbx, %rax
   1176b:      	movl	0x50(%rsp), %r12d
   11770:      	movl	%r15d, %edx
   11773:      	subl	%r12d, %edx
   11776:      	movl	$0x0, %ecx
   1177b:      	cmovbl	%ecx, %edx
   1177e:      	addq	0x60(%rsp), %rdx
   11783:      	xorl	%esi, %esi
   11785:      	cmpl	%r15d, %r12d
   11788:      	seta	%sil
   1178c:      	movl	%r15d, %ecx
   1178f:      	cmovbl	%r12d, %ecx
   11793:      	addl	%ecx, %esi
   11795:      	movl	%r12d, %edi
   11798:      	subl	%esi, %edi
   1179a:      	movl	%edi, 0x50(%rsp)
   1179e:      	subq	%rsi, %rax
   117a1:      	jb	0x16d52 <generic_fentry_path+0xba72>
   117a7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   117ad:      	ja	0x16d52 <generic_fentry_path+0xba72>
   117b3:      	cmpl	%r15d, %r12d
   117b6:      	jbe	0x117bc <generic_fentry_path+0x64dc>
   117b8:      	movb	$0x2f, (%rbx,%rax)
   117bc:      	xorl	%edi, %edi
   117be:      	cmpl	%r15d, %r12d
   117c1:      	seta	%dil
   117c5:      	movzbl	%cl, %esi
   117c8:      	addq	%rax, %rbx
   117cb:      	addq	%rbx, %rdi
   117ce:      	movl	$0x4, %eax
   117d3:      	callq	*%rax
   117d5:      	movq	%rbx, 0x48(%rsp)
   117da:      	cmpl	%r15d, %r12d
   117dd:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   117e3:      	movq	0x8(%rsp), %r12
   117e8:      	movq	%r12, 0x30(%rsp)
   117ed:      	movq	0x38(%rsp), %rdx
   117f2:      	movq	0x40(%rsp), %r15
   117f7:      	jmp	0x1184a <generic_fentry_path+0x656a>
   117f9:      	leaq	0x10(%r15), %rdx
   117fd:      	movl	$0x4, %eax
   11802:      	movq	%rbp, %rdi
   11805:      	movl	$0x8, %esi
   1180a:      	callq	*%rax
   1180c:      	movq	0x40(%rsp), %rax
   11811:      	cmpq	(%rsp), %rax
   11815:      	je	0x16d4d <generic_fentry_path+0xba6d>
   1181b:      	addq	$0x18, %r15
   1181f:      	movl	$0x4, %eax
   11824:      	leaq	0x30(%rsp), %rdi
   11829:      	movl	$0x8, %esi
   1182e:      	movq	%r15, %rdx
   11831:      	callq	*%rax
   11833:      	movq	(%rsp), %r15
   11837:      	movq	%r15, 0x40(%rsp)
   1183c:      	leaq	0x20(%r15), %rdx
   11840:      	movq	%rdx, 0x38(%rsp)
   11845:      	movq	0x30(%rsp), %r12
   1184a:      	cmpq	0x18(%rsp), %r12
   1184f:      	jne	0x1185c <generic_fentry_path+0x657c>
   11851:      	cmpq	0x20(%rsp), %rdx
   11856:      	je	0x16d4d <generic_fentry_path+0xba6d>
   1185c:      	movl	$0x4, %eax
   11861:      	leaq	0x10(%rsp), %rdi
   11866:      	movl	$0x8, %esi
   1186b:      	callq	*%rax
   1186d:      	cmpq	0x10(%rsp), %r12
   11872:      	je	0x1196a <generic_fentry_path+0x668a>
   11878:      	leaq	0x18(%r12), %rbx
   1187d:      	movl	$0x4, %eax
   11882:      	movq	%rbp, %rdi
   11885:      	movl	$0x8, %esi
   1188a:      	movq	%rbx, %rdx
   1188d:      	callq	*%rax
   1188f:      	cmpq	%r12, (%rsp)
   11893:      	je	0x1196a <generic_fentry_path+0x668a>
   11899:      	movl	$0x4, %eax
   1189e:      	leaq	0x8(%rsp), %rdi
   118a3:      	movl	$0x8, %esi
   118a8:      	movq	%rbx, %rdx
   118ab:      	callq	*%rax
   118ad:      	addq	$0x20, %r12
   118b1:      	movl	$0x4, %eax
   118b6:      	leaq	0x58(%rsp), %rdi
   118bb:      	movl	$0x10, %ecx
   118c0:      	movl	$0x10, %esi
   118c5:      	movq	%r12, %rdx
   118c8:      	callq	*%rax
   118ca:      	movq	0x28(%rsp), %rbx
   118cf:      	movq	0x48(%rsp), %rax
   118d4:      	movl	0x5c(%rsp), %r15d
   118d9:      	subq	%rbx, %rax
   118dc:      	movl	0x50(%rsp), %r12d
   118e1:      	movl	%r15d, %edx
   118e4:      	subl	%r12d, %edx
   118e7:      	movl	$0x0, %ecx
   118ec:      	cmovbl	%ecx, %edx
   118ef:      	addq	0x60(%rsp), %rdx
   118f4:      	xorl	%esi, %esi
   118f6:      	cmpl	%r15d, %r12d
   118f9:      	seta	%sil
   118fd:      	movl	%r15d, %ecx
   11900:      	cmovbl	%r12d, %ecx
   11904:      	addl	%ecx, %esi
   11906:      	movl	%r12d, %edi
   11909:      	subl	%esi, %edi
   1190b:      	movl	%edi, 0x50(%rsp)
   1190f:      	subq	%rsi, %rax
   11912:      	jb	0x16d52 <generic_fentry_path+0xba72>
   11918:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1191e:      	ja	0x16d52 <generic_fentry_path+0xba72>
   11924:      	cmpl	%r15d, %r12d
   11927:      	jbe	0x1192d <generic_fentry_path+0x664d>
   11929:      	movb	$0x2f, (%rbx,%rax)
   1192d:      	xorl	%edi, %edi
   1192f:      	cmpl	%r15d, %r12d
   11932:      	seta	%dil
   11936:      	movzbl	%cl, %esi
   11939:      	addq	%rax, %rbx
   1193c:      	addq	%rbx, %rdi
   1193f:      	movl	$0x4, %eax
   11944:      	callq	*%rax
   11946:      	movq	%rbx, 0x48(%rsp)
   1194b:      	cmpl	%r15d, %r12d
   1194e:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   11954:      	movq	0x8(%rsp), %r12
   11959:      	movq	%r12, 0x30(%rsp)
   1195e:      	movq	0x38(%rsp), %rdx
   11963:      	movq	0x40(%rsp), %r15
   11968:      	jmp	0x119bb <generic_fentry_path+0x66db>
   1196a:      	leaq	0x10(%r15), %rdx
   1196e:      	movl	$0x4, %eax
   11973:      	movq	%rbp, %rdi
   11976:      	movl	$0x8, %esi
   1197b:      	callq	*%rax
   1197d:      	movq	0x40(%rsp), %rax
   11982:      	cmpq	(%rsp), %rax
   11986:      	je	0x16d4d <generic_fentry_path+0xba6d>
   1198c:      	addq	$0x18, %r15
   11990:      	movl	$0x4, %eax
   11995:      	leaq	0x30(%rsp), %rdi
   1199a:      	movl	$0x8, %esi
   1199f:      	movq	%r15, %rdx
   119a2:      	callq	*%rax
   119a4:      	movq	(%rsp), %r15
   119a8:      	movq	%r15, 0x40(%rsp)
   119ad:      	leaq	0x20(%r15), %rdx
   119b1:      	movq	%rdx, 0x38(%rsp)
   119b6:      	movq	0x30(%rsp), %r12
   119bb:      	cmpq	0x18(%rsp), %r12
   119c0:      	jne	0x119cd <generic_fentry_path+0x66ed>
   119c2:      	cmpq	0x20(%rsp), %rdx
   119c7:      	je	0x16d4d <generic_fentry_path+0xba6d>
   119cd:      	movl	$0x4, %eax
   119d2:      	leaq	0x10(%rsp), %rdi
   119d7:      	movl	$0x8, %esi
   119dc:      	callq	*%rax
   119de:      	cmpq	0x10(%rsp), %r12
   119e3:      	je	0x11adb <generic_fentry_path+0x67fb>
   119e9:      	leaq	0x18(%r12), %rbx
   119ee:      	movl	$0x4, %eax
   119f3:      	movq	%rbp, %rdi
   119f6:      	movl	$0x8, %esi
   119fb:      	movq	%rbx, %rdx
   119fe:      	callq	*%rax
   11a00:      	cmpq	%r12, (%rsp)
   11a04:      	je	0x11adb <generic_fentry_path+0x67fb>
   11a0a:      	movl	$0x4, %eax
   11a0f:      	leaq	0x8(%rsp), %rdi
   11a14:      	movl	$0x8, %esi
   11a19:      	movq	%rbx, %rdx
   11a1c:      	callq	*%rax
   11a1e:      	addq	$0x20, %r12
   11a22:      	movl	$0x4, %eax
   11a27:      	leaq	0x58(%rsp), %rdi
   11a2c:      	movl	$0x10, %ecx
   11a31:      	movl	$0x10, %esi
   11a36:      	movq	%r12, %rdx
   11a39:      	callq	*%rax
   11a3b:      	movq	0x28(%rsp), %rbx
   11a40:      	movq	0x48(%rsp), %rax
   11a45:      	movl	0x5c(%rsp), %r15d
   11a4a:      	subq	%rbx, %rax
   11a4d:      	movl	0x50(%rsp), %r12d
   11a52:      	movl	%r15d, %edx
   11a55:      	subl	%r12d, %edx
   11a58:      	movl	$0x0, %ecx
   11a5d:      	cmovbl	%ecx, %edx
   11a60:      	addq	0x60(%rsp), %rdx
   11a65:      	xorl	%esi, %esi
   11a67:      	cmpl	%r15d, %r12d
   11a6a:      	seta	%sil
   11a6e:      	movl	%r15d, %ecx
   11a71:      	cmovbl	%r12d, %ecx
   11a75:      	addl	%ecx, %esi
   11a77:      	movl	%r12d, %edi
   11a7a:      	subl	%esi, %edi
   11a7c:      	movl	%edi, 0x50(%rsp)
   11a80:      	subq	%rsi, %rax
   11a83:      	jb	0x16d52 <generic_fentry_path+0xba72>
   11a89:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11a8f:      	ja	0x16d52 <generic_fentry_path+0xba72>
   11a95:      	cmpl	%r15d, %r12d
   11a98:      	jbe	0x11a9e <generic_fentry_path+0x67be>
   11a9a:      	movb	$0x2f, (%rbx,%rax)
   11a9e:      	xorl	%edi, %edi
   11aa0:      	cmpl	%r15d, %r12d
   11aa3:      	seta	%dil
   11aa7:      	movzbl	%cl, %esi
   11aaa:      	addq	%rax, %rbx
   11aad:      	addq	%rbx, %rdi
   11ab0:      	movl	$0x4, %eax
   11ab5:      	callq	*%rax
   11ab7:      	movq	%rbx, 0x48(%rsp)
   11abc:      	cmpl	%r15d, %r12d
   11abf:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   11ac5:      	movq	0x8(%rsp), %r12
   11aca:      	movq	%r12, 0x30(%rsp)
   11acf:      	movq	0x38(%rsp), %rdx
   11ad4:      	movq	0x40(%rsp), %r15
   11ad9:      	jmp	0x11b2c <generic_fentry_path+0x684c>
   11adb:      	leaq	0x10(%r15), %rdx
   11adf:      	movl	$0x4, %eax
   11ae4:      	movq	%rbp, %rdi
   11ae7:      	movl	$0x8, %esi
   11aec:      	callq	*%rax
   11aee:      	movq	0x40(%rsp), %rax
   11af3:      	cmpq	(%rsp), %rax
   11af7:      	je	0x16d4d <generic_fentry_path+0xba6d>
   11afd:      	addq	$0x18, %r15
   11b01:      	movl	$0x4, %eax
   11b06:      	leaq	0x30(%rsp), %rdi
   11b0b:      	movl	$0x8, %esi
   11b10:      	movq	%r15, %rdx
   11b13:      	callq	*%rax
   11b15:      	movq	(%rsp), %r15
   11b19:      	movq	%r15, 0x40(%rsp)
   11b1e:      	leaq	0x20(%r15), %rdx
   11b22:      	movq	%rdx, 0x38(%rsp)
   11b27:      	movq	0x30(%rsp), %r12
   11b2c:      	cmpq	0x18(%rsp), %r12
   11b31:      	jne	0x11b3e <generic_fentry_path+0x685e>
   11b33:      	cmpq	0x20(%rsp), %rdx
   11b38:      	je	0x16d4d <generic_fentry_path+0xba6d>
   11b3e:      	movl	$0x4, %eax
   11b43:      	leaq	0x10(%rsp), %rdi
   11b48:      	movl	$0x8, %esi
   11b4d:      	callq	*%rax
   11b4f:      	cmpq	0x10(%rsp), %r12
   11b54:      	je	0x11c4c <generic_fentry_path+0x696c>
   11b5a:      	leaq	0x18(%r12), %rbx
   11b5f:      	movl	$0x4, %eax
   11b64:      	movq	%rbp, %rdi
   11b67:      	movl	$0x8, %esi
   11b6c:      	movq	%rbx, %rdx
   11b6f:      	callq	*%rax
   11b71:      	cmpq	%r12, (%rsp)
   11b75:      	je	0x11c4c <generic_fentry_path+0x696c>
   11b7b:      	movl	$0x4, %eax
   11b80:      	leaq	0x8(%rsp), %rdi
   11b85:      	movl	$0x8, %esi
   11b8a:      	movq	%rbx, %rdx
   11b8d:      	callq	*%rax
   11b8f:      	addq	$0x20, %r12
   11b93:      	movl	$0x4, %eax
   11b98:      	leaq	0x58(%rsp), %rdi
   11b9d:      	movl	$0x10, %ecx
   11ba2:      	movl	$0x10, %esi
   11ba7:      	movq	%r12, %rdx
   11baa:      	callq	*%rax
   11bac:      	movq	0x28(%rsp), %rbx
   11bb1:      	movq	0x48(%rsp), %rax
   11bb6:      	movl	0x5c(%rsp), %r15d
   11bbb:      	subq	%rbx, %rax
   11bbe:      	movl	0x50(%rsp), %r12d
   11bc3:      	movl	%r15d, %edx
   11bc6:      	subl	%r12d, %edx
   11bc9:      	movl	$0x0, %ecx
   11bce:      	cmovbl	%ecx, %edx
   11bd1:      	addq	0x60(%rsp), %rdx
   11bd6:      	xorl	%esi, %esi
   11bd8:      	cmpl	%r15d, %r12d
   11bdb:      	seta	%sil
   11bdf:      	movl	%r15d, %ecx
   11be2:      	cmovbl	%r12d, %ecx
   11be6:      	addl	%ecx, %esi
   11be8:      	movl	%r12d, %edi
   11beb:      	subl	%esi, %edi
   11bed:      	movl	%edi, 0x50(%rsp)
   11bf1:      	subq	%rsi, %rax
   11bf4:      	jb	0x16d52 <generic_fentry_path+0xba72>
   11bfa:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11c00:      	ja	0x16d52 <generic_fentry_path+0xba72>
   11c06:      	cmpl	%r15d, %r12d
   11c09:      	jbe	0x11c0f <generic_fentry_path+0x692f>
   11c0b:      	movb	$0x2f, (%rbx,%rax)
   11c0f:      	xorl	%edi, %edi
   11c11:      	cmpl	%r15d, %r12d
   11c14:      	seta	%dil
   11c18:      	movzbl	%cl, %esi
   11c1b:      	addq	%rax, %rbx
   11c1e:      	addq	%rbx, %rdi
   11c21:      	movl	$0x4, %eax
   11c26:      	callq	*%rax
   11c28:      	movq	%rbx, 0x48(%rsp)
   11c2d:      	cmpl	%r15d, %r12d
   11c30:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   11c36:      	movq	0x8(%rsp), %r12
   11c3b:      	movq	%r12, 0x30(%rsp)
   11c40:      	movq	0x38(%rsp), %rdx
   11c45:      	movq	0x40(%rsp), %r15
   11c4a:      	jmp	0x11c9d <generic_fentry_path+0x69bd>
   11c4c:      	leaq	0x10(%r15), %rdx
   11c50:      	movl	$0x4, %eax
   11c55:      	movq	%rbp, %rdi
   11c58:      	movl	$0x8, %esi
   11c5d:      	callq	*%rax
   11c5f:      	movq	0x40(%rsp), %rax
   11c64:      	cmpq	(%rsp), %rax
   11c68:      	je	0x16d4d <generic_fentry_path+0xba6d>
   11c6e:      	addq	$0x18, %r15
   11c72:      	movl	$0x4, %eax
   11c77:      	leaq	0x30(%rsp), %rdi
   11c7c:      	movl	$0x8, %esi
   11c81:      	movq	%r15, %rdx
   11c84:      	callq	*%rax
   11c86:      	movq	(%rsp), %r15
   11c8a:      	movq	%r15, 0x40(%rsp)
   11c8f:      	leaq	0x20(%r15), %rdx
   11c93:      	movq	%rdx, 0x38(%rsp)
   11c98:      	movq	0x30(%rsp), %r12
   11c9d:      	cmpq	0x18(%rsp), %r12
   11ca2:      	jne	0x11caf <generic_fentry_path+0x69cf>
   11ca4:      	cmpq	0x20(%rsp), %rdx
   11ca9:      	je	0x16d4d <generic_fentry_path+0xba6d>
   11caf:      	movl	$0x4, %eax
   11cb4:      	leaq	0x10(%rsp), %rdi
   11cb9:      	movl	$0x8, %esi
   11cbe:      	callq	*%rax
   11cc0:      	cmpq	0x10(%rsp), %r12
   11cc5:      	je	0x11dbd <generic_fentry_path+0x6add>
   11ccb:      	leaq	0x18(%r12), %rbx
   11cd0:      	movl	$0x4, %eax
   11cd5:      	movq	%rbp, %rdi
   11cd8:      	movl	$0x8, %esi
   11cdd:      	movq	%rbx, %rdx
   11ce0:      	callq	*%rax
   11ce2:      	cmpq	%r12, (%rsp)
   11ce6:      	je	0x11dbd <generic_fentry_path+0x6add>
   11cec:      	movl	$0x4, %eax
   11cf1:      	leaq	0x8(%rsp), %rdi
   11cf6:      	movl	$0x8, %esi
   11cfb:      	movq	%rbx, %rdx
   11cfe:      	callq	*%rax
   11d00:      	addq	$0x20, %r12
   11d04:      	movl	$0x4, %eax
   11d09:      	leaq	0x58(%rsp), %rdi
   11d0e:      	movl	$0x10, %ecx
   11d13:      	movl	$0x10, %esi
   11d18:      	movq	%r12, %rdx
   11d1b:      	callq	*%rax
   11d1d:      	movq	0x28(%rsp), %rbx
   11d22:      	movq	0x48(%rsp), %rax
   11d27:      	movl	0x5c(%rsp), %r15d
   11d2c:      	subq	%rbx, %rax
   11d2f:      	movl	0x50(%rsp), %r12d
   11d34:      	movl	%r15d, %edx
   11d37:      	subl	%r12d, %edx
   11d3a:      	movl	$0x0, %ecx
   11d3f:      	cmovbl	%ecx, %edx
   11d42:      	addq	0x60(%rsp), %rdx
   11d47:      	xorl	%esi, %esi
   11d49:      	cmpl	%r15d, %r12d
   11d4c:      	seta	%sil
   11d50:      	movl	%r15d, %ecx
   11d53:      	cmovbl	%r12d, %ecx
   11d57:      	addl	%ecx, %esi
   11d59:      	movl	%r12d, %edi
   11d5c:      	subl	%esi, %edi
   11d5e:      	movl	%edi, 0x50(%rsp)
   11d62:      	subq	%rsi, %rax
   11d65:      	jb	0x16d52 <generic_fentry_path+0xba72>
   11d6b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11d71:      	ja	0x16d52 <generic_fentry_path+0xba72>
   11d77:      	cmpl	%r15d, %r12d
   11d7a:      	jbe	0x11d80 <generic_fentry_path+0x6aa0>
   11d7c:      	movb	$0x2f, (%rbx,%rax)
   11d80:      	xorl	%edi, %edi
   11d82:      	cmpl	%r15d, %r12d
   11d85:      	seta	%dil
   11d89:      	movzbl	%cl, %esi
   11d8c:      	addq	%rax, %rbx
   11d8f:      	addq	%rbx, %rdi
   11d92:      	movl	$0x4, %eax
   11d97:      	callq	*%rax
   11d99:      	movq	%rbx, 0x48(%rsp)
   11d9e:      	cmpl	%r15d, %r12d
   11da1:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   11da7:      	movq	0x8(%rsp), %r12
   11dac:      	movq	%r12, 0x30(%rsp)
   11db1:      	movq	0x38(%rsp), %rdx
   11db6:      	movq	0x40(%rsp), %r15
   11dbb:      	jmp	0x11e0e <generic_fentry_path+0x6b2e>
   11dbd:      	leaq	0x10(%r15), %rdx
   11dc1:      	movl	$0x4, %eax
   11dc6:      	movq	%rbp, %rdi
   11dc9:      	movl	$0x8, %esi
   11dce:      	callq	*%rax
   11dd0:      	movq	0x40(%rsp), %rax
   11dd5:      	cmpq	(%rsp), %rax
   11dd9:      	je	0x16d4d <generic_fentry_path+0xba6d>
   11ddf:      	addq	$0x18, %r15
   11de3:      	movl	$0x4, %eax
   11de8:      	leaq	0x30(%rsp), %rdi
   11ded:      	movl	$0x8, %esi
   11df2:      	movq	%r15, %rdx
   11df5:      	callq	*%rax
   11df7:      	movq	(%rsp), %r15
   11dfb:      	movq	%r15, 0x40(%rsp)
   11e00:      	leaq	0x20(%r15), %rdx
   11e04:      	movq	%rdx, 0x38(%rsp)
   11e09:      	movq	0x30(%rsp), %r12
   11e0e:      	cmpq	0x18(%rsp), %r12
   11e13:      	jne	0x11e20 <generic_fentry_path+0x6b40>
   11e15:      	cmpq	0x20(%rsp), %rdx
   11e1a:      	je	0x16d4d <generic_fentry_path+0xba6d>
   11e20:      	movl	$0x4, %eax
   11e25:      	leaq	0x10(%rsp), %rdi
   11e2a:      	movl	$0x8, %esi
   11e2f:      	callq	*%rax
   11e31:      	cmpq	0x10(%rsp), %r12
   11e36:      	je	0x11f2e <generic_fentry_path+0x6c4e>
   11e3c:      	leaq	0x18(%r12), %rbx
   11e41:      	movl	$0x4, %eax
   11e46:      	movq	%rbp, %rdi
   11e49:      	movl	$0x8, %esi
   11e4e:      	movq	%rbx, %rdx
   11e51:      	callq	*%rax
   11e53:      	cmpq	%r12, (%rsp)
   11e57:      	je	0x11f2e <generic_fentry_path+0x6c4e>
   11e5d:      	movl	$0x4, %eax
   11e62:      	leaq	0x8(%rsp), %rdi
   11e67:      	movl	$0x8, %esi
   11e6c:      	movq	%rbx, %rdx
   11e6f:      	callq	*%rax
   11e71:      	addq	$0x20, %r12
   11e75:      	movl	$0x4, %eax
   11e7a:      	leaq	0x58(%rsp), %rdi
   11e7f:      	movl	$0x10, %ecx
   11e84:      	movl	$0x10, %esi
   11e89:      	movq	%r12, %rdx
   11e8c:      	callq	*%rax
   11e8e:      	movq	0x28(%rsp), %rbx
   11e93:      	movq	0x48(%rsp), %rax
   11e98:      	movl	0x5c(%rsp), %r15d
   11e9d:      	subq	%rbx, %rax
   11ea0:      	movl	0x50(%rsp), %r12d
   11ea5:      	movl	%r15d, %edx
   11ea8:      	subl	%r12d, %edx
   11eab:      	movl	$0x0, %ecx
   11eb0:      	cmovbl	%ecx, %edx
   11eb3:      	addq	0x60(%rsp), %rdx
   11eb8:      	xorl	%esi, %esi
   11eba:      	cmpl	%r15d, %r12d
   11ebd:      	seta	%sil
   11ec1:      	movl	%r15d, %ecx
   11ec4:      	cmovbl	%r12d, %ecx
   11ec8:      	addl	%ecx, %esi
   11eca:      	movl	%r12d, %edi
   11ecd:      	subl	%esi, %edi
   11ecf:      	movl	%edi, 0x50(%rsp)
   11ed3:      	subq	%rsi, %rax
   11ed6:      	jb	0x16d52 <generic_fentry_path+0xba72>
   11edc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11ee2:      	ja	0x16d52 <generic_fentry_path+0xba72>
   11ee8:      	cmpl	%r15d, %r12d
   11eeb:      	jbe	0x11ef1 <generic_fentry_path+0x6c11>
   11eed:      	movb	$0x2f, (%rbx,%rax)
   11ef1:      	xorl	%edi, %edi
   11ef3:      	cmpl	%r15d, %r12d
   11ef6:      	seta	%dil
   11efa:      	movzbl	%cl, %esi
   11efd:      	addq	%rax, %rbx
   11f00:      	addq	%rbx, %rdi
   11f03:      	movl	$0x4, %eax
   11f08:      	callq	*%rax
   11f0a:      	movq	%rbx, 0x48(%rsp)
   11f0f:      	cmpl	%r15d, %r12d
   11f12:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   11f18:      	movq	0x8(%rsp), %r12
   11f1d:      	movq	%r12, 0x30(%rsp)
   11f22:      	movq	0x38(%rsp), %rdx
   11f27:      	movq	0x40(%rsp), %r15
   11f2c:      	jmp	0x11f7f <generic_fentry_path+0x6c9f>
   11f2e:      	leaq	0x10(%r15), %rdx
   11f32:      	movl	$0x4, %eax
   11f37:      	movq	%rbp, %rdi
   11f3a:      	movl	$0x8, %esi
   11f3f:      	callq	*%rax
   11f41:      	movq	0x40(%rsp), %rax
   11f46:      	cmpq	(%rsp), %rax
   11f4a:      	je	0x16d4d <generic_fentry_path+0xba6d>
   11f50:      	addq	$0x18, %r15
   11f54:      	movl	$0x4, %eax
   11f59:      	leaq	0x30(%rsp), %rdi
   11f5e:      	movl	$0x8, %esi
   11f63:      	movq	%r15, %rdx
   11f66:      	callq	*%rax
   11f68:      	movq	(%rsp), %r15
   11f6c:      	movq	%r15, 0x40(%rsp)
   11f71:      	leaq	0x20(%r15), %rdx
   11f75:      	movq	%rdx, 0x38(%rsp)
   11f7a:      	movq	0x30(%rsp), %r12
   11f7f:      	cmpq	0x18(%rsp), %r12
   11f84:      	jne	0x11f91 <generic_fentry_path+0x6cb1>
   11f86:      	cmpq	0x20(%rsp), %rdx
   11f8b:      	je	0x16d4d <generic_fentry_path+0xba6d>
   11f91:      	movl	$0x4, %eax
   11f96:      	leaq	0x10(%rsp), %rdi
   11f9b:      	movl	$0x8, %esi
   11fa0:      	callq	*%rax
   11fa2:      	cmpq	0x10(%rsp), %r12
   11fa7:      	je	0x1209f <generic_fentry_path+0x6dbf>
   11fad:      	leaq	0x18(%r12), %rbx
   11fb2:      	movl	$0x4, %eax
   11fb7:      	movq	%rbp, %rdi
   11fba:      	movl	$0x8, %esi
   11fbf:      	movq	%rbx, %rdx
   11fc2:      	callq	*%rax
   11fc4:      	cmpq	%r12, (%rsp)
   11fc8:      	je	0x1209f <generic_fentry_path+0x6dbf>
   11fce:      	movl	$0x4, %eax
   11fd3:      	leaq	0x8(%rsp), %rdi
   11fd8:      	movl	$0x8, %esi
   11fdd:      	movq	%rbx, %rdx
   11fe0:      	callq	*%rax
   11fe2:      	addq	$0x20, %r12
   11fe6:      	movl	$0x4, %eax
   11feb:      	leaq	0x58(%rsp), %rdi
   11ff0:      	movl	$0x10, %ecx
   11ff5:      	movl	$0x10, %esi
   11ffa:      	movq	%r12, %rdx
   11ffd:      	callq	*%rax
   11fff:      	movq	0x28(%rsp), %rbx
   12004:      	movq	0x48(%rsp), %rax
   12009:      	movl	0x5c(%rsp), %r15d
   1200e:      	subq	%rbx, %rax
   12011:      	movl	0x50(%rsp), %r12d
   12016:      	movl	%r15d, %edx
   12019:      	subl	%r12d, %edx
   1201c:      	movl	$0x0, %ecx
   12021:      	cmovbl	%ecx, %edx
   12024:      	addq	0x60(%rsp), %rdx
   12029:      	xorl	%esi, %esi
   1202b:      	cmpl	%r15d, %r12d
   1202e:      	seta	%sil
   12032:      	movl	%r15d, %ecx
   12035:      	cmovbl	%r12d, %ecx
   12039:      	addl	%ecx, %esi
   1203b:      	movl	%r12d, %edi
   1203e:      	subl	%esi, %edi
   12040:      	movl	%edi, 0x50(%rsp)
   12044:      	subq	%rsi, %rax
   12047:      	jb	0x16d52 <generic_fentry_path+0xba72>
   1204d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12053:      	ja	0x16d52 <generic_fentry_path+0xba72>
   12059:      	cmpl	%r15d, %r12d
   1205c:      	jbe	0x12062 <generic_fentry_path+0x6d82>
   1205e:      	movb	$0x2f, (%rbx,%rax)
   12062:      	xorl	%edi, %edi
   12064:      	cmpl	%r15d, %r12d
   12067:      	seta	%dil
   1206b:      	movzbl	%cl, %esi
   1206e:      	addq	%rax, %rbx
   12071:      	addq	%rbx, %rdi
   12074:      	movl	$0x4, %eax
   12079:      	callq	*%rax
   1207b:      	movq	%rbx, 0x48(%rsp)
   12080:      	cmpl	%r15d, %r12d
   12083:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   12089:      	movq	0x8(%rsp), %r12
   1208e:      	movq	%r12, 0x30(%rsp)
   12093:      	movq	0x38(%rsp), %rdx
   12098:      	movq	0x40(%rsp), %r15
   1209d:      	jmp	0x120f0 <generic_fentry_path+0x6e10>
   1209f:      	leaq	0x10(%r15), %rdx
   120a3:      	movl	$0x4, %eax
   120a8:      	movq	%rbp, %rdi
   120ab:      	movl	$0x8, %esi
   120b0:      	callq	*%rax
   120b2:      	movq	0x40(%rsp), %rax
   120b7:      	cmpq	(%rsp), %rax
   120bb:      	je	0x16d4d <generic_fentry_path+0xba6d>
   120c1:      	addq	$0x18, %r15
   120c5:      	movl	$0x4, %eax
   120ca:      	leaq	0x30(%rsp), %rdi
   120cf:      	movl	$0x8, %esi
   120d4:      	movq	%r15, %rdx
   120d7:      	callq	*%rax
   120d9:      	movq	(%rsp), %r15
   120dd:      	movq	%r15, 0x40(%rsp)
   120e2:      	leaq	0x20(%r15), %rdx
   120e6:      	movq	%rdx, 0x38(%rsp)
   120eb:      	movq	0x30(%rsp), %r12
   120f0:      	cmpq	0x18(%rsp), %r12
   120f5:      	jne	0x12102 <generic_fentry_path+0x6e22>
   120f7:      	cmpq	0x20(%rsp), %rdx
   120fc:      	je	0x16d4d <generic_fentry_path+0xba6d>
   12102:      	movl	$0x4, %eax
   12107:      	leaq	0x10(%rsp), %rdi
   1210c:      	movl	$0x8, %esi
   12111:      	callq	*%rax
   12113:      	cmpq	0x10(%rsp), %r12
   12118:      	je	0x12210 <generic_fentry_path+0x6f30>
   1211e:      	leaq	0x18(%r12), %rbx
   12123:      	movl	$0x4, %eax
   12128:      	movq	%rbp, %rdi
   1212b:      	movl	$0x8, %esi
   12130:      	movq	%rbx, %rdx
   12133:      	callq	*%rax
   12135:      	cmpq	%r12, (%rsp)
   12139:      	je	0x12210 <generic_fentry_path+0x6f30>
   1213f:      	movl	$0x4, %eax
   12144:      	leaq	0x8(%rsp), %rdi
   12149:      	movl	$0x8, %esi
   1214e:      	movq	%rbx, %rdx
   12151:      	callq	*%rax
   12153:      	addq	$0x20, %r12
   12157:      	movl	$0x4, %eax
   1215c:      	leaq	0x58(%rsp), %rdi
   12161:      	movl	$0x10, %ecx
   12166:      	movl	$0x10, %esi
   1216b:      	movq	%r12, %rdx
   1216e:      	callq	*%rax
   12170:      	movq	0x28(%rsp), %rbx
   12175:      	movq	0x48(%rsp), %rax
   1217a:      	movl	0x5c(%rsp), %r15d
   1217f:      	subq	%rbx, %rax
   12182:      	movl	0x50(%rsp), %r12d
   12187:      	movl	%r15d, %edx
   1218a:      	subl	%r12d, %edx
   1218d:      	movl	$0x0, %ecx
   12192:      	cmovbl	%ecx, %edx
   12195:      	addq	0x60(%rsp), %rdx
   1219a:      	xorl	%esi, %esi
   1219c:      	cmpl	%r15d, %r12d
   1219f:      	seta	%sil
   121a3:      	movl	%r15d, %ecx
   121a6:      	cmovbl	%r12d, %ecx
   121aa:      	addl	%ecx, %esi
   121ac:      	movl	%r12d, %edi
   121af:      	subl	%esi, %edi
   121b1:      	movl	%edi, 0x50(%rsp)
   121b5:      	subq	%rsi, %rax
   121b8:      	jb	0x16d52 <generic_fentry_path+0xba72>
   121be:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   121c4:      	ja	0x16d52 <generic_fentry_path+0xba72>
   121ca:      	cmpl	%r15d, %r12d
   121cd:      	jbe	0x121d3 <generic_fentry_path+0x6ef3>
   121cf:      	movb	$0x2f, (%rbx,%rax)
   121d3:      	xorl	%edi, %edi
   121d5:      	cmpl	%r15d, %r12d
   121d8:      	seta	%dil
   121dc:      	movzbl	%cl, %esi
   121df:      	addq	%rax, %rbx
   121e2:      	addq	%rbx, %rdi
   121e5:      	movl	$0x4, %eax
   121ea:      	callq	*%rax
   121ec:      	movq	%rbx, 0x48(%rsp)
   121f1:      	cmpl	%r15d, %r12d
   121f4:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   121fa:      	movq	0x8(%rsp), %r12
   121ff:      	movq	%r12, 0x30(%rsp)
   12204:      	movq	0x38(%rsp), %rdx
   12209:      	movq	0x40(%rsp), %r15
   1220e:      	jmp	0x12261 <generic_fentry_path+0x6f81>
   12210:      	leaq	0x10(%r15), %rdx
   12214:      	movl	$0x4, %eax
   12219:      	movq	%rbp, %rdi
   1221c:      	movl	$0x8, %esi
   12221:      	callq	*%rax
   12223:      	movq	0x40(%rsp), %rax
   12228:      	cmpq	(%rsp), %rax
   1222c:      	je	0x16d4d <generic_fentry_path+0xba6d>
   12232:      	addq	$0x18, %r15
   12236:      	movl	$0x4, %eax
   1223b:      	leaq	0x30(%rsp), %rdi
   12240:      	movl	$0x8, %esi
   12245:      	movq	%r15, %rdx
   12248:      	callq	*%rax
   1224a:      	movq	(%rsp), %r15
   1224e:      	movq	%r15, 0x40(%rsp)
   12253:      	leaq	0x20(%r15), %rdx
   12257:      	movq	%rdx, 0x38(%rsp)
   1225c:      	movq	0x30(%rsp), %r12
   12261:      	cmpq	0x18(%rsp), %r12
   12266:      	jne	0x12273 <generic_fentry_path+0x6f93>
   12268:      	cmpq	0x20(%rsp), %rdx
   1226d:      	je	0x16d4d <generic_fentry_path+0xba6d>
   12273:      	movl	$0x4, %eax
   12278:      	leaq	0x10(%rsp), %rdi
   1227d:      	movl	$0x8, %esi
   12282:      	callq	*%rax
   12284:      	cmpq	0x10(%rsp), %r12
   12289:      	je	0x12381 <generic_fentry_path+0x70a1>
   1228f:      	leaq	0x18(%r12), %rbx
   12294:      	movl	$0x4, %eax
   12299:      	movq	%rbp, %rdi
   1229c:      	movl	$0x8, %esi
   122a1:      	movq	%rbx, %rdx
   122a4:      	callq	*%rax
   122a6:      	cmpq	%r12, (%rsp)
   122aa:      	je	0x12381 <generic_fentry_path+0x70a1>
   122b0:      	movl	$0x4, %eax
   122b5:      	leaq	0x8(%rsp), %rdi
   122ba:      	movl	$0x8, %esi
   122bf:      	movq	%rbx, %rdx
   122c2:      	callq	*%rax
   122c4:      	addq	$0x20, %r12
   122c8:      	movl	$0x4, %eax
   122cd:      	leaq	0x58(%rsp), %rdi
   122d2:      	movl	$0x10, %ecx
   122d7:      	movl	$0x10, %esi
   122dc:      	movq	%r12, %rdx
   122df:      	callq	*%rax
   122e1:      	movq	0x28(%rsp), %rbx
   122e6:      	movq	0x48(%rsp), %rax
   122eb:      	movl	0x5c(%rsp), %r15d
   122f0:      	subq	%rbx, %rax
   122f3:      	movl	0x50(%rsp), %r12d
   122f8:      	movl	%r15d, %edx
   122fb:      	subl	%r12d, %edx
   122fe:      	movl	$0x0, %ecx
   12303:      	cmovbl	%ecx, %edx
   12306:      	addq	0x60(%rsp), %rdx
   1230b:      	xorl	%esi, %esi
   1230d:      	cmpl	%r15d, %r12d
   12310:      	seta	%sil
   12314:      	movl	%r15d, %ecx
   12317:      	cmovbl	%r12d, %ecx
   1231b:      	addl	%ecx, %esi
   1231d:      	movl	%r12d, %edi
   12320:      	subl	%esi, %edi
   12322:      	movl	%edi, 0x50(%rsp)
   12326:      	subq	%rsi, %rax
   12329:      	jb	0x16d52 <generic_fentry_path+0xba72>
   1232f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12335:      	ja	0x16d52 <generic_fentry_path+0xba72>
   1233b:      	cmpl	%r15d, %r12d
   1233e:      	jbe	0x12344 <generic_fentry_path+0x7064>
   12340:      	movb	$0x2f, (%rbx,%rax)
   12344:      	xorl	%edi, %edi
   12346:      	cmpl	%r15d, %r12d
   12349:      	seta	%dil
   1234d:      	movzbl	%cl, %esi
   12350:      	addq	%rax, %rbx
   12353:      	addq	%rbx, %rdi
   12356:      	movl	$0x4, %eax
   1235b:      	callq	*%rax
   1235d:      	movq	%rbx, 0x48(%rsp)
   12362:      	cmpl	%r15d, %r12d
   12365:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   1236b:      	movq	0x8(%rsp), %r12
   12370:      	movq	%r12, 0x30(%rsp)
   12375:      	movq	0x38(%rsp), %rdx
   1237a:      	movq	0x40(%rsp), %r15
   1237f:      	jmp	0x123d2 <generic_fentry_path+0x70f2>
   12381:      	leaq	0x10(%r15), %rdx
   12385:      	movl	$0x4, %eax
   1238a:      	movq	%rbp, %rdi
   1238d:      	movl	$0x8, %esi
   12392:      	callq	*%rax
   12394:      	movq	0x40(%rsp), %rax
   12399:      	cmpq	(%rsp), %rax
   1239d:      	je	0x16d4d <generic_fentry_path+0xba6d>
   123a3:      	addq	$0x18, %r15
   123a7:      	movl	$0x4, %eax
   123ac:      	leaq	0x30(%rsp), %rdi
   123b1:      	movl	$0x8, %esi
   123b6:      	movq	%r15, %rdx
   123b9:      	callq	*%rax
   123bb:      	movq	(%rsp), %r15
   123bf:      	movq	%r15, 0x40(%rsp)
   123c4:      	leaq	0x20(%r15), %rdx
   123c8:      	movq	%rdx, 0x38(%rsp)
   123cd:      	movq	0x30(%rsp), %r12
   123d2:      	cmpq	0x18(%rsp), %r12
   123d7:      	jne	0x123e4 <generic_fentry_path+0x7104>
   123d9:      	cmpq	0x20(%rsp), %rdx
   123de:      	je	0x16d4d <generic_fentry_path+0xba6d>
   123e4:      	movl	$0x4, %eax
   123e9:      	leaq	0x10(%rsp), %rdi
   123ee:      	movl	$0x8, %esi
   123f3:      	callq	*%rax
   123f5:      	cmpq	0x10(%rsp), %r12
   123fa:      	je	0x124f2 <generic_fentry_path+0x7212>
   12400:      	leaq	0x18(%r12), %rbx
   12405:      	movl	$0x4, %eax
   1240a:      	movq	%rbp, %rdi
   1240d:      	movl	$0x8, %esi
   12412:      	movq	%rbx, %rdx
   12415:      	callq	*%rax
   12417:      	cmpq	%r12, (%rsp)
   1241b:      	je	0x124f2 <generic_fentry_path+0x7212>
   12421:      	movl	$0x4, %eax
   12426:      	leaq	0x8(%rsp), %rdi
   1242b:      	movl	$0x8, %esi
   12430:      	movq	%rbx, %rdx
   12433:      	callq	*%rax
   12435:      	addq	$0x20, %r12
   12439:      	movl	$0x4, %eax
   1243e:      	leaq	0x58(%rsp), %rdi
   12443:      	movl	$0x10, %ecx
   12448:      	movl	$0x10, %esi
   1244d:      	movq	%r12, %rdx
   12450:      	callq	*%rax
   12452:      	movq	0x28(%rsp), %rbx
   12457:      	movq	0x48(%rsp), %rax
   1245c:      	movl	0x5c(%rsp), %r15d
   12461:      	subq	%rbx, %rax
   12464:      	movl	0x50(%rsp), %r12d
   12469:      	movl	%r15d, %edx
   1246c:      	subl	%r12d, %edx
   1246f:      	movl	$0x0, %ecx
   12474:      	cmovbl	%ecx, %edx
   12477:      	addq	0x60(%rsp), %rdx
   1247c:      	xorl	%esi, %esi
   1247e:      	cmpl	%r15d, %r12d
   12481:      	seta	%sil
   12485:      	movl	%r15d, %ecx
   12488:      	cmovbl	%r12d, %ecx
   1248c:      	addl	%ecx, %esi
   1248e:      	movl	%r12d, %edi
   12491:      	subl	%esi, %edi
   12493:      	movl	%edi, 0x50(%rsp)
   12497:      	subq	%rsi, %rax
   1249a:      	jb	0x16d52 <generic_fentry_path+0xba72>
   124a0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   124a6:      	ja	0x16d52 <generic_fentry_path+0xba72>
   124ac:      	cmpl	%r15d, %r12d
   124af:      	jbe	0x124b5 <generic_fentry_path+0x71d5>
   124b1:      	movb	$0x2f, (%rbx,%rax)
   124b5:      	xorl	%edi, %edi
   124b7:      	cmpl	%r15d, %r12d
   124ba:      	seta	%dil
   124be:      	movzbl	%cl, %esi
   124c1:      	addq	%rax, %rbx
   124c4:      	addq	%rbx, %rdi
   124c7:      	movl	$0x4, %eax
   124cc:      	callq	*%rax
   124ce:      	movq	%rbx, 0x48(%rsp)
   124d3:      	cmpl	%r15d, %r12d
   124d6:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   124dc:      	movq	0x8(%rsp), %r12
   124e1:      	movq	%r12, 0x30(%rsp)
   124e6:      	movq	0x38(%rsp), %rdx
   124eb:      	movq	0x40(%rsp), %r15
   124f0:      	jmp	0x12543 <generic_fentry_path+0x7263>
   124f2:      	leaq	0x10(%r15), %rdx
   124f6:      	movl	$0x4, %eax
   124fb:      	movq	%rbp, %rdi
   124fe:      	movl	$0x8, %esi
   12503:      	callq	*%rax
   12505:      	movq	0x40(%rsp), %rax
   1250a:      	cmpq	(%rsp), %rax
   1250e:      	je	0x16d4d <generic_fentry_path+0xba6d>
   12514:      	addq	$0x18, %r15
   12518:      	movl	$0x4, %eax
   1251d:      	leaq	0x30(%rsp), %rdi
   12522:      	movl	$0x8, %esi
   12527:      	movq	%r15, %rdx
   1252a:      	callq	*%rax
   1252c:      	movq	(%rsp), %r15
   12530:      	movq	%r15, 0x40(%rsp)
   12535:      	leaq	0x20(%r15), %rdx
   12539:      	movq	%rdx, 0x38(%rsp)
   1253e:      	movq	0x30(%rsp), %r12
   12543:      	cmpq	0x18(%rsp), %r12
   12548:      	jne	0x12555 <generic_fentry_path+0x7275>
   1254a:      	cmpq	0x20(%rsp), %rdx
   1254f:      	je	0x16d4d <generic_fentry_path+0xba6d>
   12555:      	movl	$0x4, %eax
   1255a:      	leaq	0x10(%rsp), %rdi
   1255f:      	movl	$0x8, %esi
   12564:      	callq	*%rax
   12566:      	cmpq	0x10(%rsp), %r12
   1256b:      	je	0x12663 <generic_fentry_path+0x7383>
   12571:      	leaq	0x18(%r12), %rbx
   12576:      	movl	$0x4, %eax
   1257b:      	movq	%rbp, %rdi
   1257e:      	movl	$0x8, %esi
   12583:      	movq	%rbx, %rdx
   12586:      	callq	*%rax
   12588:      	cmpq	%r12, (%rsp)
   1258c:      	je	0x12663 <generic_fentry_path+0x7383>
   12592:      	movl	$0x4, %eax
   12597:      	leaq	0x8(%rsp), %rdi
   1259c:      	movl	$0x8, %esi
   125a1:      	movq	%rbx, %rdx
   125a4:      	callq	*%rax
   125a6:      	addq	$0x20, %r12
   125aa:      	movl	$0x4, %eax
   125af:      	leaq	0x58(%rsp), %rdi
   125b4:      	movl	$0x10, %ecx
   125b9:      	movl	$0x10, %esi
   125be:      	movq	%r12, %rdx
   125c1:      	callq	*%rax
   125c3:      	movq	0x28(%rsp), %rbx
   125c8:      	movq	0x48(%rsp), %rax
   125cd:      	movl	0x5c(%rsp), %r15d
   125d2:      	subq	%rbx, %rax
   125d5:      	movl	0x50(%rsp), %r12d
   125da:      	movl	%r15d, %edx
   125dd:      	subl	%r12d, %edx
   125e0:      	movl	$0x0, %ecx
   125e5:      	cmovbl	%ecx, %edx
   125e8:      	addq	0x60(%rsp), %rdx
   125ed:      	xorl	%esi, %esi
   125ef:      	cmpl	%r15d, %r12d
   125f2:      	seta	%sil
   125f6:      	movl	%r15d, %ecx
   125f9:      	cmovbl	%r12d, %ecx
   125fd:      	addl	%ecx, %esi
   125ff:      	movl	%r12d, %edi
   12602:      	subl	%esi, %edi
   12604:      	movl	%edi, 0x50(%rsp)
   12608:      	subq	%rsi, %rax
   1260b:      	jb	0x16d52 <generic_fentry_path+0xba72>
   12611:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12617:      	ja	0x16d52 <generic_fentry_path+0xba72>
   1261d:      	cmpl	%r15d, %r12d
   12620:      	jbe	0x12626 <generic_fentry_path+0x7346>
   12622:      	movb	$0x2f, (%rbx,%rax)
   12626:      	xorl	%edi, %edi
   12628:      	cmpl	%r15d, %r12d
   1262b:      	seta	%dil
   1262f:      	movzbl	%cl, %esi
   12632:      	addq	%rax, %rbx
   12635:      	addq	%rbx, %rdi
   12638:      	movl	$0x4, %eax
   1263d:      	callq	*%rax
   1263f:      	movq	%rbx, 0x48(%rsp)
   12644:      	cmpl	%r15d, %r12d
   12647:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   1264d:      	movq	0x8(%rsp), %r12
   12652:      	movq	%r12, 0x30(%rsp)
   12657:      	movq	0x38(%rsp), %rdx
   1265c:      	movq	0x40(%rsp), %r15
   12661:      	jmp	0x126b4 <generic_fentry_path+0x73d4>
   12663:      	leaq	0x10(%r15), %rdx
   12667:      	movl	$0x4, %eax
   1266c:      	movq	%rbp, %rdi
   1266f:      	movl	$0x8, %esi
   12674:      	callq	*%rax
   12676:      	movq	0x40(%rsp), %rax
   1267b:      	cmpq	(%rsp), %rax
   1267f:      	je	0x16d4d <generic_fentry_path+0xba6d>
   12685:      	addq	$0x18, %r15
   12689:      	movl	$0x4, %eax
   1268e:      	leaq	0x30(%rsp), %rdi
   12693:      	movl	$0x8, %esi
   12698:      	movq	%r15, %rdx
   1269b:      	callq	*%rax
   1269d:      	movq	(%rsp), %r15
   126a1:      	movq	%r15, 0x40(%rsp)
   126a6:      	leaq	0x20(%r15), %rdx
   126aa:      	movq	%rdx, 0x38(%rsp)
   126af:      	movq	0x30(%rsp), %r12
   126b4:      	cmpq	0x18(%rsp), %r12
   126b9:      	jne	0x126c6 <generic_fentry_path+0x73e6>
   126bb:      	cmpq	0x20(%rsp), %rdx
   126c0:      	je	0x16d4d <generic_fentry_path+0xba6d>
   126c6:      	movl	$0x4, %eax
   126cb:      	leaq	0x10(%rsp), %rdi
   126d0:      	movl	$0x8, %esi
   126d5:      	callq	*%rax
   126d7:      	cmpq	0x10(%rsp), %r12
   126dc:      	je	0x127d4 <generic_fentry_path+0x74f4>
   126e2:      	leaq	0x18(%r12), %rbx
   126e7:      	movl	$0x4, %eax
   126ec:      	movq	%rbp, %rdi
   126ef:      	movl	$0x8, %esi
   126f4:      	movq	%rbx, %rdx
   126f7:      	callq	*%rax
   126f9:      	cmpq	%r12, (%rsp)
   126fd:      	je	0x127d4 <generic_fentry_path+0x74f4>
   12703:      	movl	$0x4, %eax
   12708:      	leaq	0x8(%rsp), %rdi
   1270d:      	movl	$0x8, %esi
   12712:      	movq	%rbx, %rdx
   12715:      	callq	*%rax
   12717:      	addq	$0x20, %r12
   1271b:      	movl	$0x4, %eax
   12720:      	leaq	0x58(%rsp), %rdi
   12725:      	movl	$0x10, %ecx
   1272a:      	movl	$0x10, %esi
   1272f:      	movq	%r12, %rdx
   12732:      	callq	*%rax
   12734:      	movq	0x28(%rsp), %rbx
   12739:      	movq	0x48(%rsp), %rax
   1273e:      	movl	0x5c(%rsp), %r15d
   12743:      	subq	%rbx, %rax
   12746:      	movl	0x50(%rsp), %r12d
   1274b:      	movl	%r15d, %edx
   1274e:      	subl	%r12d, %edx
   12751:      	movl	$0x0, %ecx
   12756:      	cmovbl	%ecx, %edx
   12759:      	addq	0x60(%rsp), %rdx
   1275e:      	xorl	%esi, %esi
   12760:      	cmpl	%r15d, %r12d
   12763:      	seta	%sil
   12767:      	movl	%r15d, %ecx
   1276a:      	cmovbl	%r12d, %ecx
   1276e:      	addl	%ecx, %esi
   12770:      	movl	%r12d, %edi
   12773:      	subl	%esi, %edi
   12775:      	movl	%edi, 0x50(%rsp)
   12779:      	subq	%rsi, %rax
   1277c:      	jb	0x16d52 <generic_fentry_path+0xba72>
   12782:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12788:      	ja	0x16d52 <generic_fentry_path+0xba72>
   1278e:      	cmpl	%r15d, %r12d
   12791:      	jbe	0x12797 <generic_fentry_path+0x74b7>
   12793:      	movb	$0x2f, (%rbx,%rax)
   12797:      	xorl	%edi, %edi
   12799:      	cmpl	%r15d, %r12d
   1279c:      	seta	%dil
   127a0:      	movzbl	%cl, %esi
   127a3:      	addq	%rax, %rbx
   127a6:      	addq	%rbx, %rdi
   127a9:      	movl	$0x4, %eax
   127ae:      	callq	*%rax
   127b0:      	movq	%rbx, 0x48(%rsp)
   127b5:      	cmpl	%r15d, %r12d
   127b8:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   127be:      	movq	0x8(%rsp), %r12
   127c3:      	movq	%r12, 0x30(%rsp)
   127c8:      	movq	0x38(%rsp), %rdx
   127cd:      	movq	0x40(%rsp), %r15
   127d2:      	jmp	0x12825 <generic_fentry_path+0x7545>
   127d4:      	leaq	0x10(%r15), %rdx
   127d8:      	movl	$0x4, %eax
   127dd:      	movq	%rbp, %rdi
   127e0:      	movl	$0x8, %esi
   127e5:      	callq	*%rax
   127e7:      	movq	0x40(%rsp), %rax
   127ec:      	cmpq	(%rsp), %rax
   127f0:      	je	0x16d4d <generic_fentry_path+0xba6d>
   127f6:      	addq	$0x18, %r15
   127fa:      	movl	$0x4, %eax
   127ff:      	leaq	0x30(%rsp), %rdi
   12804:      	movl	$0x8, %esi
   12809:      	movq	%r15, %rdx
   1280c:      	callq	*%rax
   1280e:      	movq	(%rsp), %r15
   12812:      	movq	%r15, 0x40(%rsp)
   12817:      	leaq	0x20(%r15), %rdx
   1281b:      	movq	%rdx, 0x38(%rsp)
   12820:      	movq	0x30(%rsp), %r12
   12825:      	cmpq	0x18(%rsp), %r12
   1282a:      	jne	0x12837 <generic_fentry_path+0x7557>
   1282c:      	cmpq	0x20(%rsp), %rdx
   12831:      	je	0x16d4d <generic_fentry_path+0xba6d>
   12837:      	movl	$0x4, %eax
   1283c:      	leaq	0x10(%rsp), %rdi
   12841:      	movl	$0x8, %esi
   12846:      	callq	*%rax
   12848:      	cmpq	0x10(%rsp), %r12
   1284d:      	je	0x12945 <generic_fentry_path+0x7665>
   12853:      	leaq	0x18(%r12), %rbx
   12858:      	movl	$0x4, %eax
   1285d:      	movq	%rbp, %rdi
   12860:      	movl	$0x8, %esi
   12865:      	movq	%rbx, %rdx
   12868:      	callq	*%rax
   1286a:      	cmpq	%r12, (%rsp)
   1286e:      	je	0x12945 <generic_fentry_path+0x7665>
   12874:      	movl	$0x4, %eax
   12879:      	leaq	0x8(%rsp), %rdi
   1287e:      	movl	$0x8, %esi
   12883:      	movq	%rbx, %rdx
   12886:      	callq	*%rax
   12888:      	addq	$0x20, %r12
   1288c:      	movl	$0x4, %eax
   12891:      	leaq	0x58(%rsp), %rdi
   12896:      	movl	$0x10, %ecx
   1289b:      	movl	$0x10, %esi
   128a0:      	movq	%r12, %rdx
   128a3:      	callq	*%rax
   128a5:      	movq	0x28(%rsp), %rbx
   128aa:      	movq	0x48(%rsp), %rax
   128af:      	movl	0x5c(%rsp), %r15d
   128b4:      	subq	%rbx, %rax
   128b7:      	movl	0x50(%rsp), %r12d
   128bc:      	movl	%r15d, %edx
   128bf:      	subl	%r12d, %edx
   128c2:      	movl	$0x0, %ecx
   128c7:      	cmovbl	%ecx, %edx
   128ca:      	addq	0x60(%rsp), %rdx
   128cf:      	xorl	%esi, %esi
   128d1:      	cmpl	%r15d, %r12d
   128d4:      	seta	%sil
   128d8:      	movl	%r15d, %ecx
   128db:      	cmovbl	%r12d, %ecx
   128df:      	addl	%ecx, %esi
   128e1:      	movl	%r12d, %edi
   128e4:      	subl	%esi, %edi
   128e6:      	movl	%edi, 0x50(%rsp)
   128ea:      	subq	%rsi, %rax
   128ed:      	jb	0x16d52 <generic_fentry_path+0xba72>
   128f3:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   128f9:      	ja	0x16d52 <generic_fentry_path+0xba72>
   128ff:      	cmpl	%r15d, %r12d
   12902:      	jbe	0x12908 <generic_fentry_path+0x7628>
   12904:      	movb	$0x2f, (%rbx,%rax)
   12908:      	xorl	%edi, %edi
   1290a:      	cmpl	%r15d, %r12d
   1290d:      	seta	%dil
   12911:      	movzbl	%cl, %esi
   12914:      	addq	%rax, %rbx
   12917:      	addq	%rbx, %rdi
   1291a:      	movl	$0x4, %eax
   1291f:      	callq	*%rax
   12921:      	movq	%rbx, 0x48(%rsp)
   12926:      	cmpl	%r15d, %r12d
   12929:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   1292f:      	movq	0x8(%rsp), %r12
   12934:      	movq	%r12, 0x30(%rsp)
   12939:      	movq	0x38(%rsp), %rdx
   1293e:      	movq	0x40(%rsp), %r15
   12943:      	jmp	0x12996 <generic_fentry_path+0x76b6>
   12945:      	leaq	0x10(%r15), %rdx
   12949:      	movl	$0x4, %eax
   1294e:      	movq	%rbp, %rdi
   12951:      	movl	$0x8, %esi
   12956:      	callq	*%rax
   12958:      	movq	0x40(%rsp), %rax
   1295d:      	cmpq	(%rsp), %rax
   12961:      	je	0x16d4d <generic_fentry_path+0xba6d>
   12967:      	addq	$0x18, %r15
   1296b:      	movl	$0x4, %eax
   12970:      	leaq	0x30(%rsp), %rdi
   12975:      	movl	$0x8, %esi
   1297a:      	movq	%r15, %rdx
   1297d:      	callq	*%rax
   1297f:      	movq	(%rsp), %r15
   12983:      	movq	%r15, 0x40(%rsp)
   12988:      	leaq	0x20(%r15), %rdx
   1298c:      	movq	%rdx, 0x38(%rsp)
   12991:      	movq	0x30(%rsp), %r12
   12996:      	cmpq	0x18(%rsp), %r12
   1299b:      	jne	0x129a8 <generic_fentry_path+0x76c8>
   1299d:      	cmpq	0x20(%rsp), %rdx
   129a2:      	je	0x16d4d <generic_fentry_path+0xba6d>
   129a8:      	movl	$0x4, %eax
   129ad:      	leaq	0x10(%rsp), %rdi
   129b2:      	movl	$0x8, %esi
   129b7:      	callq	*%rax
   129b9:      	cmpq	0x10(%rsp), %r12
   129be:      	je	0x12ab6 <generic_fentry_path+0x77d6>
   129c4:      	leaq	0x18(%r12), %rbx
   129c9:      	movl	$0x4, %eax
   129ce:      	movq	%rbp, %rdi
   129d1:      	movl	$0x8, %esi
   129d6:      	movq	%rbx, %rdx
   129d9:      	callq	*%rax
   129db:      	cmpq	%r12, (%rsp)
   129df:      	je	0x12ab6 <generic_fentry_path+0x77d6>
   129e5:      	movl	$0x4, %eax
   129ea:      	leaq	0x8(%rsp), %rdi
   129ef:      	movl	$0x8, %esi
   129f4:      	movq	%rbx, %rdx
   129f7:      	callq	*%rax
   129f9:      	addq	$0x20, %r12
   129fd:      	movl	$0x4, %eax
   12a02:      	leaq	0x58(%rsp), %rdi
   12a07:      	movl	$0x10, %ecx
   12a0c:      	movl	$0x10, %esi
   12a11:      	movq	%r12, %rdx
   12a14:      	callq	*%rax
   12a16:      	movq	0x28(%rsp), %rbx
   12a1b:      	movq	0x48(%rsp), %rax
   12a20:      	movl	0x5c(%rsp), %r15d
   12a25:      	subq	%rbx, %rax
   12a28:      	movl	0x50(%rsp), %r12d
   12a2d:      	movl	%r15d, %edx
   12a30:      	subl	%r12d, %edx
   12a33:      	movl	$0x0, %ecx
   12a38:      	cmovbl	%ecx, %edx
   12a3b:      	addq	0x60(%rsp), %rdx
   12a40:      	xorl	%esi, %esi
   12a42:      	cmpl	%r15d, %r12d
   12a45:      	seta	%sil
   12a49:      	movl	%r15d, %ecx
   12a4c:      	cmovbl	%r12d, %ecx
   12a50:      	addl	%ecx, %esi
   12a52:      	movl	%r12d, %edi
   12a55:      	subl	%esi, %edi
   12a57:      	movl	%edi, 0x50(%rsp)
   12a5b:      	subq	%rsi, %rax
   12a5e:      	jb	0x16d52 <generic_fentry_path+0xba72>
   12a64:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12a6a:      	ja	0x16d52 <generic_fentry_path+0xba72>
   12a70:      	cmpl	%r15d, %r12d
   12a73:      	jbe	0x12a79 <generic_fentry_path+0x7799>
   12a75:      	movb	$0x2f, (%rbx,%rax)
   12a79:      	xorl	%edi, %edi
   12a7b:      	cmpl	%r15d, %r12d
   12a7e:      	seta	%dil
   12a82:      	movzbl	%cl, %esi
   12a85:      	addq	%rax, %rbx
   12a88:      	addq	%rbx, %rdi
   12a8b:      	movl	$0x4, %eax
   12a90:      	callq	*%rax
   12a92:      	movq	%rbx, 0x48(%rsp)
   12a97:      	cmpl	%r15d, %r12d
   12a9a:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   12aa0:      	movq	0x8(%rsp), %r12
   12aa5:      	movq	%r12, 0x30(%rsp)
   12aaa:      	movq	0x38(%rsp), %rdx
   12aaf:      	movq	0x40(%rsp), %r15
   12ab4:      	jmp	0x12b07 <generic_fentry_path+0x7827>
   12ab6:      	leaq	0x10(%r15), %rdx
   12aba:      	movl	$0x4, %eax
   12abf:      	movq	%rbp, %rdi
   12ac2:      	movl	$0x8, %esi
   12ac7:      	callq	*%rax
   12ac9:      	movq	0x40(%rsp), %rax
   12ace:      	cmpq	(%rsp), %rax
   12ad2:      	je	0x16d4d <generic_fentry_path+0xba6d>
   12ad8:      	addq	$0x18, %r15
   12adc:      	movl	$0x4, %eax
   12ae1:      	leaq	0x30(%rsp), %rdi
   12ae6:      	movl	$0x8, %esi
   12aeb:      	movq	%r15, %rdx
   12aee:      	callq	*%rax
   12af0:      	movq	(%rsp), %r15
   12af4:      	movq	%r15, 0x40(%rsp)
   12af9:      	leaq	0x20(%r15), %rdx
   12afd:      	movq	%rdx, 0x38(%rsp)
   12b02:      	movq	0x30(%rsp), %r12
   12b07:      	cmpq	0x18(%rsp), %r12
   12b0c:      	jne	0x12b19 <generic_fentry_path+0x7839>
   12b0e:      	cmpq	0x20(%rsp), %rdx
   12b13:      	je	0x16d4d <generic_fentry_path+0xba6d>
   12b19:      	movl	$0x4, %eax
   12b1e:      	leaq	0x10(%rsp), %rdi
   12b23:      	movl	$0x8, %esi
   12b28:      	callq	*%rax
   12b2a:      	cmpq	0x10(%rsp), %r12
   12b2f:      	je	0x12c27 <generic_fentry_path+0x7947>
   12b35:      	leaq	0x18(%r12), %rbx
   12b3a:      	movl	$0x4, %eax
   12b3f:      	movq	%rbp, %rdi
   12b42:      	movl	$0x8, %esi
   12b47:      	movq	%rbx, %rdx
   12b4a:      	callq	*%rax
   12b4c:      	cmpq	%r12, (%rsp)
   12b50:      	je	0x12c27 <generic_fentry_path+0x7947>
   12b56:      	movl	$0x4, %eax
   12b5b:      	leaq	0x8(%rsp), %rdi
   12b60:      	movl	$0x8, %esi
   12b65:      	movq	%rbx, %rdx
   12b68:      	callq	*%rax
   12b6a:      	addq	$0x20, %r12
   12b6e:      	movl	$0x4, %eax
   12b73:      	leaq	0x58(%rsp), %rdi
   12b78:      	movl	$0x10, %ecx
   12b7d:      	movl	$0x10, %esi
   12b82:      	movq	%r12, %rdx
   12b85:      	callq	*%rax
   12b87:      	movq	0x28(%rsp), %rbx
   12b8c:      	movq	0x48(%rsp), %rax
   12b91:      	movl	0x5c(%rsp), %r15d
   12b96:      	subq	%rbx, %rax
   12b99:      	movl	0x50(%rsp), %r12d
   12b9e:      	movl	%r15d, %edx
   12ba1:      	subl	%r12d, %edx
   12ba4:      	movl	$0x0, %ecx
   12ba9:      	cmovbl	%ecx, %edx
   12bac:      	addq	0x60(%rsp), %rdx
   12bb1:      	xorl	%esi, %esi
   12bb3:      	cmpl	%r15d, %r12d
   12bb6:      	seta	%sil
   12bba:      	movl	%r15d, %ecx
   12bbd:      	cmovbl	%r12d, %ecx
   12bc1:      	addl	%ecx, %esi
   12bc3:      	movl	%r12d, %edi
   12bc6:      	subl	%esi, %edi
   12bc8:      	movl	%edi, 0x50(%rsp)
   12bcc:      	subq	%rsi, %rax
   12bcf:      	jb	0x16d52 <generic_fentry_path+0xba72>
   12bd5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12bdb:      	ja	0x16d52 <generic_fentry_path+0xba72>
   12be1:      	cmpl	%r15d, %r12d
   12be4:      	jbe	0x12bea <generic_fentry_path+0x790a>
   12be6:      	movb	$0x2f, (%rbx,%rax)
   12bea:      	xorl	%edi, %edi
   12bec:      	cmpl	%r15d, %r12d
   12bef:      	seta	%dil
   12bf3:      	movzbl	%cl, %esi
   12bf6:      	addq	%rax, %rbx
   12bf9:      	addq	%rbx, %rdi
   12bfc:      	movl	$0x4, %eax
   12c01:      	callq	*%rax
   12c03:      	movq	%rbx, 0x48(%rsp)
   12c08:      	cmpl	%r15d, %r12d
   12c0b:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   12c11:      	movq	0x8(%rsp), %r12
   12c16:      	movq	%r12, 0x30(%rsp)
   12c1b:      	movq	0x38(%rsp), %rdx
   12c20:      	movq	0x40(%rsp), %r15
   12c25:      	jmp	0x12c78 <generic_fentry_path+0x7998>
   12c27:      	leaq	0x10(%r15), %rdx
   12c2b:      	movl	$0x4, %eax
   12c30:      	movq	%rbp, %rdi
   12c33:      	movl	$0x8, %esi
   12c38:      	callq	*%rax
   12c3a:      	movq	0x40(%rsp), %rax
   12c3f:      	cmpq	(%rsp), %rax
   12c43:      	je	0x16d4d <generic_fentry_path+0xba6d>
   12c49:      	addq	$0x18, %r15
   12c4d:      	movl	$0x4, %eax
   12c52:      	leaq	0x30(%rsp), %rdi
   12c57:      	movl	$0x8, %esi
   12c5c:      	movq	%r15, %rdx
   12c5f:      	callq	*%rax
   12c61:      	movq	(%rsp), %r15
   12c65:      	movq	%r15, 0x40(%rsp)
   12c6a:      	leaq	0x20(%r15), %rdx
   12c6e:      	movq	%rdx, 0x38(%rsp)
   12c73:      	movq	0x30(%rsp), %r12
   12c78:      	cmpq	0x18(%rsp), %r12
   12c7d:      	jne	0x12c8a <generic_fentry_path+0x79aa>
   12c7f:      	cmpq	0x20(%rsp), %rdx
   12c84:      	je	0x16d4d <generic_fentry_path+0xba6d>
   12c8a:      	movl	$0x4, %eax
   12c8f:      	leaq	0x10(%rsp), %rdi
   12c94:      	movl	$0x8, %esi
   12c99:      	callq	*%rax
   12c9b:      	cmpq	0x10(%rsp), %r12
   12ca0:      	je	0x12d98 <generic_fentry_path+0x7ab8>
   12ca6:      	leaq	0x18(%r12), %rbx
   12cab:      	movl	$0x4, %eax
   12cb0:      	movq	%rbp, %rdi
   12cb3:      	movl	$0x8, %esi
   12cb8:      	movq	%rbx, %rdx
   12cbb:      	callq	*%rax
   12cbd:      	cmpq	%r12, (%rsp)
   12cc1:      	je	0x12d98 <generic_fentry_path+0x7ab8>
   12cc7:      	movl	$0x4, %eax
   12ccc:      	leaq	0x8(%rsp), %rdi
   12cd1:      	movl	$0x8, %esi
   12cd6:      	movq	%rbx, %rdx
   12cd9:      	callq	*%rax
   12cdb:      	addq	$0x20, %r12
   12cdf:      	movl	$0x4, %eax
   12ce4:      	leaq	0x58(%rsp), %rdi
   12ce9:      	movl	$0x10, %ecx
   12cee:      	movl	$0x10, %esi
   12cf3:      	movq	%r12, %rdx
   12cf6:      	callq	*%rax
   12cf8:      	movq	0x28(%rsp), %rbx
   12cfd:      	movq	0x48(%rsp), %rax
   12d02:      	movl	0x5c(%rsp), %r15d
   12d07:      	subq	%rbx, %rax
   12d0a:      	movl	0x50(%rsp), %r12d
   12d0f:      	movl	%r15d, %edx
   12d12:      	subl	%r12d, %edx
   12d15:      	movl	$0x0, %ecx
   12d1a:      	cmovbl	%ecx, %edx
   12d1d:      	addq	0x60(%rsp), %rdx
   12d22:      	xorl	%esi, %esi
   12d24:      	cmpl	%r15d, %r12d
   12d27:      	seta	%sil
   12d2b:      	movl	%r15d, %ecx
   12d2e:      	cmovbl	%r12d, %ecx
   12d32:      	addl	%ecx, %esi
   12d34:      	movl	%r12d, %edi
   12d37:      	subl	%esi, %edi
   12d39:      	movl	%edi, 0x50(%rsp)
   12d3d:      	subq	%rsi, %rax
   12d40:      	jb	0x16d52 <generic_fentry_path+0xba72>
   12d46:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12d4c:      	ja	0x16d52 <generic_fentry_path+0xba72>
   12d52:      	cmpl	%r15d, %r12d
   12d55:      	jbe	0x12d5b <generic_fentry_path+0x7a7b>
   12d57:      	movb	$0x2f, (%rbx,%rax)
   12d5b:      	xorl	%edi, %edi
   12d5d:      	cmpl	%r15d, %r12d
   12d60:      	seta	%dil
   12d64:      	movzbl	%cl, %esi
   12d67:      	addq	%rax, %rbx
   12d6a:      	addq	%rbx, %rdi
   12d6d:      	movl	$0x4, %eax
   12d72:      	callq	*%rax
   12d74:      	movq	%rbx, 0x48(%rsp)
   12d79:      	cmpl	%r15d, %r12d
   12d7c:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   12d82:      	movq	0x8(%rsp), %r12
   12d87:      	movq	%r12, 0x30(%rsp)
   12d8c:      	movq	0x38(%rsp), %rdx
   12d91:      	movq	0x40(%rsp), %r15
   12d96:      	jmp	0x12de9 <generic_fentry_path+0x7b09>
   12d98:      	leaq	0x10(%r15), %rdx
   12d9c:      	movl	$0x4, %eax
   12da1:      	movq	%rbp, %rdi
   12da4:      	movl	$0x8, %esi
   12da9:      	callq	*%rax
   12dab:      	movq	0x40(%rsp), %rax
   12db0:      	cmpq	(%rsp), %rax
   12db4:      	je	0x16d4d <generic_fentry_path+0xba6d>
   12dba:      	addq	$0x18, %r15
   12dbe:      	movl	$0x4, %eax
   12dc3:      	leaq	0x30(%rsp), %rdi
   12dc8:      	movl	$0x8, %esi
   12dcd:      	movq	%r15, %rdx
   12dd0:      	callq	*%rax
   12dd2:      	movq	(%rsp), %r15
   12dd6:      	movq	%r15, 0x40(%rsp)
   12ddb:      	leaq	0x20(%r15), %rdx
   12ddf:      	movq	%rdx, 0x38(%rsp)
   12de4:      	movq	0x30(%rsp), %r12
   12de9:      	cmpq	0x18(%rsp), %r12
   12dee:      	jne	0x12dfb <generic_fentry_path+0x7b1b>
   12df0:      	cmpq	0x20(%rsp), %rdx
   12df5:      	je	0x16d4d <generic_fentry_path+0xba6d>
   12dfb:      	movl	$0x4, %eax
   12e00:      	leaq	0x10(%rsp), %rdi
   12e05:      	movl	$0x8, %esi
   12e0a:      	callq	*%rax
   12e0c:      	cmpq	0x10(%rsp), %r12
   12e11:      	je	0x12f09 <generic_fentry_path+0x7c29>
   12e17:      	leaq	0x18(%r12), %rbx
   12e1c:      	movl	$0x4, %eax
   12e21:      	movq	%rbp, %rdi
   12e24:      	movl	$0x8, %esi
   12e29:      	movq	%rbx, %rdx
   12e2c:      	callq	*%rax
   12e2e:      	cmpq	%r12, (%rsp)
   12e32:      	je	0x12f09 <generic_fentry_path+0x7c29>
   12e38:      	movl	$0x4, %eax
   12e3d:      	leaq	0x8(%rsp), %rdi
   12e42:      	movl	$0x8, %esi
   12e47:      	movq	%rbx, %rdx
   12e4a:      	callq	*%rax
   12e4c:      	addq	$0x20, %r12
   12e50:      	movl	$0x4, %eax
   12e55:      	leaq	0x58(%rsp), %rdi
   12e5a:      	movl	$0x10, %ecx
   12e5f:      	movl	$0x10, %esi
   12e64:      	movq	%r12, %rdx
   12e67:      	callq	*%rax
   12e69:      	movq	0x28(%rsp), %rbx
   12e6e:      	movq	0x48(%rsp), %rax
   12e73:      	movl	0x5c(%rsp), %r15d
   12e78:      	subq	%rbx, %rax
   12e7b:      	movl	0x50(%rsp), %r12d
   12e80:      	movl	%r15d, %edx
   12e83:      	subl	%r12d, %edx
   12e86:      	movl	$0x0, %ecx
   12e8b:      	cmovbl	%ecx, %edx
   12e8e:      	addq	0x60(%rsp), %rdx
   12e93:      	xorl	%esi, %esi
   12e95:      	cmpl	%r15d, %r12d
   12e98:      	seta	%sil
   12e9c:      	movl	%r15d, %ecx
   12e9f:      	cmovbl	%r12d, %ecx
   12ea3:      	addl	%ecx, %esi
   12ea5:      	movl	%r12d, %edi
   12ea8:      	subl	%esi, %edi
   12eaa:      	movl	%edi, 0x50(%rsp)
   12eae:      	subq	%rsi, %rax
   12eb1:      	jb	0x16d52 <generic_fentry_path+0xba72>
   12eb7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12ebd:      	ja	0x16d52 <generic_fentry_path+0xba72>
   12ec3:      	cmpl	%r15d, %r12d
   12ec6:      	jbe	0x12ecc <generic_fentry_path+0x7bec>
   12ec8:      	movb	$0x2f, (%rbx,%rax)
   12ecc:      	xorl	%edi, %edi
   12ece:      	cmpl	%r15d, %r12d
   12ed1:      	seta	%dil
   12ed5:      	movzbl	%cl, %esi
   12ed8:      	addq	%rax, %rbx
   12edb:      	addq	%rbx, %rdi
   12ede:      	movl	$0x4, %eax
   12ee3:      	callq	*%rax
   12ee5:      	movq	%rbx, 0x48(%rsp)
   12eea:      	cmpl	%r15d, %r12d
   12eed:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   12ef3:      	movq	0x8(%rsp), %r12
   12ef8:      	movq	%r12, 0x30(%rsp)
   12efd:      	movq	0x38(%rsp), %rdx
   12f02:      	movq	0x40(%rsp), %r15
   12f07:      	jmp	0x12f5a <generic_fentry_path+0x7c7a>
   12f09:      	leaq	0x10(%r15), %rdx
   12f0d:      	movl	$0x4, %eax
   12f12:      	movq	%rbp, %rdi
   12f15:      	movl	$0x8, %esi
   12f1a:      	callq	*%rax
   12f1c:      	movq	0x40(%rsp), %rax
   12f21:      	cmpq	(%rsp), %rax
   12f25:      	je	0x16d4d <generic_fentry_path+0xba6d>
   12f2b:      	addq	$0x18, %r15
   12f2f:      	movl	$0x4, %eax
   12f34:      	leaq	0x30(%rsp), %rdi
   12f39:      	movl	$0x8, %esi
   12f3e:      	movq	%r15, %rdx
   12f41:      	callq	*%rax
   12f43:      	movq	(%rsp), %r15
   12f47:      	movq	%r15, 0x40(%rsp)
   12f4c:      	leaq	0x20(%r15), %rdx
   12f50:      	movq	%rdx, 0x38(%rsp)
   12f55:      	movq	0x30(%rsp), %r12
   12f5a:      	cmpq	0x18(%rsp), %r12
   12f5f:      	jne	0x12f6c <generic_fentry_path+0x7c8c>
   12f61:      	cmpq	0x20(%rsp), %rdx
   12f66:      	je	0x16d4d <generic_fentry_path+0xba6d>
   12f6c:      	movl	$0x4, %eax
   12f71:      	leaq	0x10(%rsp), %rdi
   12f76:      	movl	$0x8, %esi
   12f7b:      	callq	*%rax
   12f7d:      	cmpq	0x10(%rsp), %r12
   12f82:      	je	0x1307a <generic_fentry_path+0x7d9a>
   12f88:      	leaq	0x18(%r12), %rbx
   12f8d:      	movl	$0x4, %eax
   12f92:      	movq	%rbp, %rdi
   12f95:      	movl	$0x8, %esi
   12f9a:      	movq	%rbx, %rdx
   12f9d:      	callq	*%rax
   12f9f:      	cmpq	%r12, (%rsp)
   12fa3:      	je	0x1307a <generic_fentry_path+0x7d9a>
   12fa9:      	movl	$0x4, %eax
   12fae:      	leaq	0x8(%rsp), %rdi
   12fb3:      	movl	$0x8, %esi
   12fb8:      	movq	%rbx, %rdx
   12fbb:      	callq	*%rax
   12fbd:      	addq	$0x20, %r12
   12fc1:      	movl	$0x4, %eax
   12fc6:      	leaq	0x58(%rsp), %rdi
   12fcb:      	movl	$0x10, %ecx
   12fd0:      	movl	$0x10, %esi
   12fd5:      	movq	%r12, %rdx
   12fd8:      	callq	*%rax
   12fda:      	movq	0x28(%rsp), %rbx
   12fdf:      	movq	0x48(%rsp), %rax
   12fe4:      	movl	0x5c(%rsp), %r15d
   12fe9:      	subq	%rbx, %rax
   12fec:      	movl	0x50(%rsp), %r12d
   12ff1:      	movl	%r15d, %edx
   12ff4:      	subl	%r12d, %edx
   12ff7:      	movl	$0x0, %ecx
   12ffc:      	cmovbl	%ecx, %edx
   12fff:      	addq	0x60(%rsp), %rdx
   13004:      	xorl	%esi, %esi
   13006:      	cmpl	%r15d, %r12d
   13009:      	seta	%sil
   1300d:      	movl	%r15d, %ecx
   13010:      	cmovbl	%r12d, %ecx
   13014:      	addl	%ecx, %esi
   13016:      	movl	%r12d, %edi
   13019:      	subl	%esi, %edi
   1301b:      	movl	%edi, 0x50(%rsp)
   1301f:      	subq	%rsi, %rax
   13022:      	jb	0x16d52 <generic_fentry_path+0xba72>
   13028:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1302e:      	ja	0x16d52 <generic_fentry_path+0xba72>
   13034:      	cmpl	%r15d, %r12d
   13037:      	jbe	0x1303d <generic_fentry_path+0x7d5d>
   13039:      	movb	$0x2f, (%rbx,%rax)
   1303d:      	xorl	%edi, %edi
   1303f:      	cmpl	%r15d, %r12d
   13042:      	seta	%dil
   13046:      	movzbl	%cl, %esi
   13049:      	addq	%rax, %rbx
   1304c:      	addq	%rbx, %rdi
   1304f:      	movl	$0x4, %eax
   13054:      	callq	*%rax
   13056:      	movq	%rbx, 0x48(%rsp)
   1305b:      	cmpl	%r15d, %r12d
   1305e:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   13064:      	movq	0x8(%rsp), %r12
   13069:      	movq	%r12, 0x30(%rsp)
   1306e:      	movq	0x38(%rsp), %rdx
   13073:      	movq	0x40(%rsp), %r15
   13078:      	jmp	0x130cb <generic_fentry_path+0x7deb>
   1307a:      	leaq	0x10(%r15), %rdx
   1307e:      	movl	$0x4, %eax
   13083:      	movq	%rbp, %rdi
   13086:      	movl	$0x8, %esi
   1308b:      	callq	*%rax
   1308d:      	movq	0x40(%rsp), %rax
   13092:      	cmpq	(%rsp), %rax
   13096:      	je	0x16d4d <generic_fentry_path+0xba6d>
   1309c:      	addq	$0x18, %r15
   130a0:      	movl	$0x4, %eax
   130a5:      	leaq	0x30(%rsp), %rdi
   130aa:      	movl	$0x8, %esi
   130af:      	movq	%r15, %rdx
   130b2:      	callq	*%rax
   130b4:      	movq	(%rsp), %r15
   130b8:      	movq	%r15, 0x40(%rsp)
   130bd:      	leaq	0x20(%r15), %rdx
   130c1:      	movq	%rdx, 0x38(%rsp)
   130c6:      	movq	0x30(%rsp), %r12
   130cb:      	cmpq	0x18(%rsp), %r12
   130d0:      	jne	0x130dd <generic_fentry_path+0x7dfd>
   130d2:      	cmpq	0x20(%rsp), %rdx
   130d7:      	je	0x16d4d <generic_fentry_path+0xba6d>
   130dd:      	movl	$0x4, %eax
   130e2:      	leaq	0x10(%rsp), %rdi
   130e7:      	movl	$0x8, %esi
   130ec:      	callq	*%rax
   130ee:      	cmpq	0x10(%rsp), %r12
   130f3:      	je	0x131eb <generic_fentry_path+0x7f0b>
   130f9:      	leaq	0x18(%r12), %rbx
   130fe:      	movl	$0x4, %eax
   13103:      	movq	%rbp, %rdi
   13106:      	movl	$0x8, %esi
   1310b:      	movq	%rbx, %rdx
   1310e:      	callq	*%rax
   13110:      	cmpq	%r12, (%rsp)
   13114:      	je	0x131eb <generic_fentry_path+0x7f0b>
   1311a:      	movl	$0x4, %eax
   1311f:      	leaq	0x8(%rsp), %rdi
   13124:      	movl	$0x8, %esi
   13129:      	movq	%rbx, %rdx
   1312c:      	callq	*%rax
   1312e:      	addq	$0x20, %r12
   13132:      	movl	$0x4, %eax
   13137:      	leaq	0x58(%rsp), %rdi
   1313c:      	movl	$0x10, %ecx
   13141:      	movl	$0x10, %esi
   13146:      	movq	%r12, %rdx
   13149:      	callq	*%rax
   1314b:      	movq	0x28(%rsp), %rbx
   13150:      	movq	0x48(%rsp), %rax
   13155:      	movl	0x5c(%rsp), %r15d
   1315a:      	subq	%rbx, %rax
   1315d:      	movl	0x50(%rsp), %r12d
   13162:      	movl	%r15d, %edx
   13165:      	subl	%r12d, %edx
   13168:      	movl	$0x0, %ecx
   1316d:      	cmovbl	%ecx, %edx
   13170:      	addq	0x60(%rsp), %rdx
   13175:      	xorl	%esi, %esi
   13177:      	cmpl	%r15d, %r12d
   1317a:      	seta	%sil
   1317e:      	movl	%r15d, %ecx
   13181:      	cmovbl	%r12d, %ecx
   13185:      	addl	%ecx, %esi
   13187:      	movl	%r12d, %edi
   1318a:      	subl	%esi, %edi
   1318c:      	movl	%edi, 0x50(%rsp)
   13190:      	subq	%rsi, %rax
   13193:      	jb	0x16d52 <generic_fentry_path+0xba72>
   13199:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1319f:      	ja	0x16d52 <generic_fentry_path+0xba72>
   131a5:      	cmpl	%r15d, %r12d
   131a8:      	jbe	0x131ae <generic_fentry_path+0x7ece>
   131aa:      	movb	$0x2f, (%rbx,%rax)
   131ae:      	xorl	%edi, %edi
   131b0:      	cmpl	%r15d, %r12d
   131b3:      	seta	%dil
   131b7:      	movzbl	%cl, %esi
   131ba:      	addq	%rax, %rbx
   131bd:      	addq	%rbx, %rdi
   131c0:      	movl	$0x4, %eax
   131c5:      	callq	*%rax
   131c7:      	movq	%rbx, 0x48(%rsp)
   131cc:      	cmpl	%r15d, %r12d
   131cf:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   131d5:      	movq	0x8(%rsp), %r12
   131da:      	movq	%r12, 0x30(%rsp)
   131df:      	movq	0x38(%rsp), %rdx
   131e4:      	movq	0x40(%rsp), %r15
   131e9:      	jmp	0x1323c <generic_fentry_path+0x7f5c>
   131eb:      	leaq	0x10(%r15), %rdx
   131ef:      	movl	$0x4, %eax
   131f4:      	movq	%rbp, %rdi
   131f7:      	movl	$0x8, %esi
   131fc:      	callq	*%rax
   131fe:      	movq	0x40(%rsp), %rax
   13203:      	cmpq	(%rsp), %rax
   13207:      	je	0x16d4d <generic_fentry_path+0xba6d>
   1320d:      	addq	$0x18, %r15
   13211:      	movl	$0x4, %eax
   13216:      	leaq	0x30(%rsp), %rdi
   1321b:      	movl	$0x8, %esi
   13220:      	movq	%r15, %rdx
   13223:      	callq	*%rax
   13225:      	movq	(%rsp), %r15
   13229:      	movq	%r15, 0x40(%rsp)
   1322e:      	leaq	0x20(%r15), %rdx
   13232:      	movq	%rdx, 0x38(%rsp)
   13237:      	movq	0x30(%rsp), %r12
   1323c:      	cmpq	0x18(%rsp), %r12
   13241:      	jne	0x1324e <generic_fentry_path+0x7f6e>
   13243:      	cmpq	0x20(%rsp), %rdx
   13248:      	je	0x16d4d <generic_fentry_path+0xba6d>
   1324e:      	movl	$0x4, %eax
   13253:      	leaq	0x10(%rsp), %rdi
   13258:      	movl	$0x8, %esi
   1325d:      	callq	*%rax
   1325f:      	cmpq	0x10(%rsp), %r12
   13264:      	je	0x1335c <generic_fentry_path+0x807c>
   1326a:      	leaq	0x18(%r12), %rbx
   1326f:      	movl	$0x4, %eax
   13274:      	movq	%rbp, %rdi
   13277:      	movl	$0x8, %esi
   1327c:      	movq	%rbx, %rdx
   1327f:      	callq	*%rax
   13281:      	cmpq	%r12, (%rsp)
   13285:      	je	0x1335c <generic_fentry_path+0x807c>
   1328b:      	movl	$0x4, %eax
   13290:      	leaq	0x8(%rsp), %rdi
   13295:      	movl	$0x8, %esi
   1329a:      	movq	%rbx, %rdx
   1329d:      	callq	*%rax
   1329f:      	addq	$0x20, %r12
   132a3:      	movl	$0x4, %eax
   132a8:      	leaq	0x58(%rsp), %rdi
   132ad:      	movl	$0x10, %ecx
   132b2:      	movl	$0x10, %esi
   132b7:      	movq	%r12, %rdx
   132ba:      	callq	*%rax
   132bc:      	movq	0x28(%rsp), %rbx
   132c1:      	movq	0x48(%rsp), %rax
   132c6:      	movl	0x5c(%rsp), %r15d
   132cb:      	subq	%rbx, %rax
   132ce:      	movl	0x50(%rsp), %r12d
   132d3:      	movl	%r15d, %edx
   132d6:      	subl	%r12d, %edx
   132d9:      	movl	$0x0, %ecx
   132de:      	cmovbl	%ecx, %edx
   132e1:      	addq	0x60(%rsp), %rdx
   132e6:      	xorl	%esi, %esi
   132e8:      	cmpl	%r15d, %r12d
   132eb:      	seta	%sil
   132ef:      	movl	%r15d, %ecx
   132f2:      	cmovbl	%r12d, %ecx
   132f6:      	addl	%ecx, %esi
   132f8:      	movl	%r12d, %edi
   132fb:      	subl	%esi, %edi
   132fd:      	movl	%edi, 0x50(%rsp)
   13301:      	subq	%rsi, %rax
   13304:      	jb	0x16d52 <generic_fentry_path+0xba72>
   1330a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13310:      	ja	0x16d52 <generic_fentry_path+0xba72>
   13316:      	cmpl	%r15d, %r12d
   13319:      	jbe	0x1331f <generic_fentry_path+0x803f>
   1331b:      	movb	$0x2f, (%rbx,%rax)
   1331f:      	xorl	%edi, %edi
   13321:      	cmpl	%r15d, %r12d
   13324:      	seta	%dil
   13328:      	movzbl	%cl, %esi
   1332b:      	addq	%rax, %rbx
   1332e:      	addq	%rbx, %rdi
   13331:      	movl	$0x4, %eax
   13336:      	callq	*%rax
   13338:      	movq	%rbx, 0x48(%rsp)
   1333d:      	cmpl	%r15d, %r12d
   13340:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   13346:      	movq	0x8(%rsp), %r12
   1334b:      	movq	%r12, 0x30(%rsp)
   13350:      	movq	0x38(%rsp), %rdx
   13355:      	movq	0x40(%rsp), %r15
   1335a:      	jmp	0x133ad <generic_fentry_path+0x80cd>
   1335c:      	leaq	0x10(%r15), %rdx
   13360:      	movl	$0x4, %eax
   13365:      	movq	%rbp, %rdi
   13368:      	movl	$0x8, %esi
   1336d:      	callq	*%rax
   1336f:      	movq	0x40(%rsp), %rax
   13374:      	cmpq	(%rsp), %rax
   13378:      	je	0x16d4d <generic_fentry_path+0xba6d>
   1337e:      	addq	$0x18, %r15
   13382:      	movl	$0x4, %eax
   13387:      	leaq	0x30(%rsp), %rdi
   1338c:      	movl	$0x8, %esi
   13391:      	movq	%r15, %rdx
   13394:      	callq	*%rax
   13396:      	movq	(%rsp), %r15
   1339a:      	movq	%r15, 0x40(%rsp)
   1339f:      	leaq	0x20(%r15), %rdx
   133a3:      	movq	%rdx, 0x38(%rsp)
   133a8:      	movq	0x30(%rsp), %r12
   133ad:      	cmpq	0x18(%rsp), %r12
   133b2:      	jne	0x133bf <generic_fentry_path+0x80df>
   133b4:      	cmpq	0x20(%rsp), %rdx
   133b9:      	je	0x16d4d <generic_fentry_path+0xba6d>
   133bf:      	movl	$0x4, %eax
   133c4:      	leaq	0x10(%rsp), %rdi
   133c9:      	movl	$0x8, %esi
   133ce:      	callq	*%rax
   133d0:      	cmpq	0x10(%rsp), %r12
   133d5:      	je	0x134cd <generic_fentry_path+0x81ed>
   133db:      	leaq	0x18(%r12), %rbx
   133e0:      	movl	$0x4, %eax
   133e5:      	movq	%rbp, %rdi
   133e8:      	movl	$0x8, %esi
   133ed:      	movq	%rbx, %rdx
   133f0:      	callq	*%rax
   133f2:      	cmpq	%r12, (%rsp)
   133f6:      	je	0x134cd <generic_fentry_path+0x81ed>
   133fc:      	movl	$0x4, %eax
   13401:      	leaq	0x8(%rsp), %rdi
   13406:      	movl	$0x8, %esi
   1340b:      	movq	%rbx, %rdx
   1340e:      	callq	*%rax
   13410:      	addq	$0x20, %r12
   13414:      	movl	$0x4, %eax
   13419:      	leaq	0x58(%rsp), %rdi
   1341e:      	movl	$0x10, %ecx
   13423:      	movl	$0x10, %esi
   13428:      	movq	%r12, %rdx
   1342b:      	callq	*%rax
   1342d:      	movq	0x28(%rsp), %rbx
   13432:      	movq	0x48(%rsp), %rax
   13437:      	movl	0x5c(%rsp), %r15d
   1343c:      	subq	%rbx, %rax
   1343f:      	movl	0x50(%rsp), %r12d
   13444:      	movl	%r15d, %edx
   13447:      	subl	%r12d, %edx
   1344a:      	movl	$0x0, %ecx
   1344f:      	cmovbl	%ecx, %edx
   13452:      	addq	0x60(%rsp), %rdx
   13457:      	xorl	%esi, %esi
   13459:      	cmpl	%r15d, %r12d
   1345c:      	seta	%sil
   13460:      	movl	%r15d, %ecx
   13463:      	cmovbl	%r12d, %ecx
   13467:      	addl	%ecx, %esi
   13469:      	movl	%r12d, %edi
   1346c:      	subl	%esi, %edi
   1346e:      	movl	%edi, 0x50(%rsp)
   13472:      	subq	%rsi, %rax
   13475:      	jb	0x16d52 <generic_fentry_path+0xba72>
   1347b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13481:      	ja	0x16d52 <generic_fentry_path+0xba72>
   13487:      	cmpl	%r15d, %r12d
   1348a:      	jbe	0x13490 <generic_fentry_path+0x81b0>
   1348c:      	movb	$0x2f, (%rbx,%rax)
   13490:      	xorl	%edi, %edi
   13492:      	cmpl	%r15d, %r12d
   13495:      	seta	%dil
   13499:      	movzbl	%cl, %esi
   1349c:      	addq	%rax, %rbx
   1349f:      	addq	%rbx, %rdi
   134a2:      	movl	$0x4, %eax
   134a7:      	callq	*%rax
   134a9:      	movq	%rbx, 0x48(%rsp)
   134ae:      	cmpl	%r15d, %r12d
   134b1:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   134b7:      	movq	0x8(%rsp), %r12
   134bc:      	movq	%r12, 0x30(%rsp)
   134c1:      	movq	0x38(%rsp), %rdx
   134c6:      	movq	0x40(%rsp), %r15
   134cb:      	jmp	0x1351e <generic_fentry_path+0x823e>
   134cd:      	leaq	0x10(%r15), %rdx
   134d1:      	movl	$0x4, %eax
   134d6:      	movq	%rbp, %rdi
   134d9:      	movl	$0x8, %esi
   134de:      	callq	*%rax
   134e0:      	movq	0x40(%rsp), %rax
   134e5:      	cmpq	(%rsp), %rax
   134e9:      	je	0x16d4d <generic_fentry_path+0xba6d>
   134ef:      	addq	$0x18, %r15
   134f3:      	movl	$0x4, %eax
   134f8:      	leaq	0x30(%rsp), %rdi
   134fd:      	movl	$0x8, %esi
   13502:      	movq	%r15, %rdx
   13505:      	callq	*%rax
   13507:      	movq	(%rsp), %r15
   1350b:      	movq	%r15, 0x40(%rsp)
   13510:      	leaq	0x20(%r15), %rdx
   13514:      	movq	%rdx, 0x38(%rsp)
   13519:      	movq	0x30(%rsp), %r12
   1351e:      	cmpq	0x18(%rsp), %r12
   13523:      	jne	0x13530 <generic_fentry_path+0x8250>
   13525:      	cmpq	0x20(%rsp), %rdx
   1352a:      	je	0x16d4d <generic_fentry_path+0xba6d>
   13530:      	movl	$0x4, %eax
   13535:      	leaq	0x10(%rsp), %rdi
   1353a:      	movl	$0x8, %esi
   1353f:      	callq	*%rax
   13541:      	cmpq	0x10(%rsp), %r12
   13546:      	je	0x1363e <generic_fentry_path+0x835e>
   1354c:      	leaq	0x18(%r12), %rbx
   13551:      	movl	$0x4, %eax
   13556:      	movq	%rbp, %rdi
   13559:      	movl	$0x8, %esi
   1355e:      	movq	%rbx, %rdx
   13561:      	callq	*%rax
   13563:      	cmpq	%r12, (%rsp)
   13567:      	je	0x1363e <generic_fentry_path+0x835e>
   1356d:      	movl	$0x4, %eax
   13572:      	leaq	0x8(%rsp), %rdi
   13577:      	movl	$0x8, %esi
   1357c:      	movq	%rbx, %rdx
   1357f:      	callq	*%rax
   13581:      	addq	$0x20, %r12
   13585:      	movl	$0x4, %eax
   1358a:      	leaq	0x58(%rsp), %rdi
   1358f:      	movl	$0x10, %ecx
   13594:      	movl	$0x10, %esi
   13599:      	movq	%r12, %rdx
   1359c:      	callq	*%rax
   1359e:      	movq	0x28(%rsp), %rbx
   135a3:      	movq	0x48(%rsp), %rax
   135a8:      	movl	0x5c(%rsp), %r15d
   135ad:      	subq	%rbx, %rax
   135b0:      	movl	0x50(%rsp), %r12d
   135b5:      	movl	%r15d, %edx
   135b8:      	subl	%r12d, %edx
   135bb:      	movl	$0x0, %ecx
   135c0:      	cmovbl	%ecx, %edx
   135c3:      	addq	0x60(%rsp), %rdx
   135c8:      	xorl	%esi, %esi
   135ca:      	cmpl	%r15d, %r12d
   135cd:      	seta	%sil
   135d1:      	movl	%r15d, %ecx
   135d4:      	cmovbl	%r12d, %ecx
   135d8:      	addl	%ecx, %esi
   135da:      	movl	%r12d, %edi
   135dd:      	subl	%esi, %edi
   135df:      	movl	%edi, 0x50(%rsp)
   135e3:      	subq	%rsi, %rax
   135e6:      	jb	0x16d52 <generic_fentry_path+0xba72>
   135ec:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   135f2:      	ja	0x16d52 <generic_fentry_path+0xba72>
   135f8:      	cmpl	%r15d, %r12d
   135fb:      	jbe	0x13601 <generic_fentry_path+0x8321>
   135fd:      	movb	$0x2f, (%rbx,%rax)
   13601:      	xorl	%edi, %edi
   13603:      	cmpl	%r15d, %r12d
   13606:      	seta	%dil
   1360a:      	movzbl	%cl, %esi
   1360d:      	addq	%rax, %rbx
   13610:      	addq	%rbx, %rdi
   13613:      	movl	$0x4, %eax
   13618:      	callq	*%rax
   1361a:      	movq	%rbx, 0x48(%rsp)
   1361f:      	cmpl	%r15d, %r12d
   13622:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   13628:      	movq	0x8(%rsp), %r12
   1362d:      	movq	%r12, 0x30(%rsp)
   13632:      	movq	0x38(%rsp), %rdx
   13637:      	movq	0x40(%rsp), %r15
   1363c:      	jmp	0x1368f <generic_fentry_path+0x83af>
   1363e:      	leaq	0x10(%r15), %rdx
   13642:      	movl	$0x4, %eax
   13647:      	movq	%rbp, %rdi
   1364a:      	movl	$0x8, %esi
   1364f:      	callq	*%rax
   13651:      	movq	0x40(%rsp), %rax
   13656:      	cmpq	(%rsp), %rax
   1365a:      	je	0x16d4d <generic_fentry_path+0xba6d>
   13660:      	addq	$0x18, %r15
   13664:      	movl	$0x4, %eax
   13669:      	leaq	0x30(%rsp), %rdi
   1366e:      	movl	$0x8, %esi
   13673:      	movq	%r15, %rdx
   13676:      	callq	*%rax
   13678:      	movq	(%rsp), %r15
   1367c:      	movq	%r15, 0x40(%rsp)
   13681:      	leaq	0x20(%r15), %rdx
   13685:      	movq	%rdx, 0x38(%rsp)
   1368a:      	movq	0x30(%rsp), %r12
   1368f:      	cmpq	0x18(%rsp), %r12
   13694:      	jne	0x136a1 <generic_fentry_path+0x83c1>
   13696:      	cmpq	0x20(%rsp), %rdx
   1369b:      	je	0x16d4d <generic_fentry_path+0xba6d>
   136a1:      	movl	$0x4, %eax
   136a6:      	leaq	0x10(%rsp), %rdi
   136ab:      	movl	$0x8, %esi
   136b0:      	callq	*%rax
   136b2:      	cmpq	0x10(%rsp), %r12
   136b7:      	je	0x137af <generic_fentry_path+0x84cf>
   136bd:      	leaq	0x18(%r12), %rbx
   136c2:      	movl	$0x4, %eax
   136c7:      	movq	%rbp, %rdi
   136ca:      	movl	$0x8, %esi
   136cf:      	movq	%rbx, %rdx
   136d2:      	callq	*%rax
   136d4:      	cmpq	%r12, (%rsp)
   136d8:      	je	0x137af <generic_fentry_path+0x84cf>
   136de:      	movl	$0x4, %eax
   136e3:      	leaq	0x8(%rsp), %rdi
   136e8:      	movl	$0x8, %esi
   136ed:      	movq	%rbx, %rdx
   136f0:      	callq	*%rax
   136f2:      	addq	$0x20, %r12
   136f6:      	movl	$0x4, %eax
   136fb:      	leaq	0x58(%rsp), %rdi
   13700:      	movl	$0x10, %ecx
   13705:      	movl	$0x10, %esi
   1370a:      	movq	%r12, %rdx
   1370d:      	callq	*%rax
   1370f:      	movq	0x28(%rsp), %rbx
   13714:      	movq	0x48(%rsp), %rax
   13719:      	movl	0x5c(%rsp), %r15d
   1371e:      	subq	%rbx, %rax
   13721:      	movl	0x50(%rsp), %r12d
   13726:      	movl	%r15d, %edx
   13729:      	subl	%r12d, %edx
   1372c:      	movl	$0x0, %ecx
   13731:      	cmovbl	%ecx, %edx
   13734:      	addq	0x60(%rsp), %rdx
   13739:      	xorl	%esi, %esi
   1373b:      	cmpl	%r15d, %r12d
   1373e:      	seta	%sil
   13742:      	movl	%r15d, %ecx
   13745:      	cmovbl	%r12d, %ecx
   13749:      	addl	%ecx, %esi
   1374b:      	movl	%r12d, %edi
   1374e:      	subl	%esi, %edi
   13750:      	movl	%edi, 0x50(%rsp)
   13754:      	subq	%rsi, %rax
   13757:      	jb	0x16d52 <generic_fentry_path+0xba72>
   1375d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13763:      	ja	0x16d52 <generic_fentry_path+0xba72>
   13769:      	cmpl	%r15d, %r12d
   1376c:      	jbe	0x13772 <generic_fentry_path+0x8492>
   1376e:      	movb	$0x2f, (%rbx,%rax)
   13772:      	xorl	%edi, %edi
   13774:      	cmpl	%r15d, %r12d
   13777:      	seta	%dil
   1377b:      	movzbl	%cl, %esi
   1377e:      	addq	%rax, %rbx
   13781:      	addq	%rbx, %rdi
   13784:      	movl	$0x4, %eax
   13789:      	callq	*%rax
   1378b:      	movq	%rbx, 0x48(%rsp)
   13790:      	cmpl	%r15d, %r12d
   13793:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   13799:      	movq	0x8(%rsp), %r12
   1379e:      	movq	%r12, 0x30(%rsp)
   137a3:      	movq	0x38(%rsp), %rdx
   137a8:      	movq	0x40(%rsp), %r15
   137ad:      	jmp	0x13800 <generic_fentry_path+0x8520>
   137af:      	leaq	0x10(%r15), %rdx
   137b3:      	movl	$0x4, %eax
   137b8:      	movq	%rbp, %rdi
   137bb:      	movl	$0x8, %esi
   137c0:      	callq	*%rax
   137c2:      	movq	0x40(%rsp), %rax
   137c7:      	cmpq	(%rsp), %rax
   137cb:      	je	0x16d4d <generic_fentry_path+0xba6d>
   137d1:      	addq	$0x18, %r15
   137d5:      	movl	$0x4, %eax
   137da:      	leaq	0x30(%rsp), %rdi
   137df:      	movl	$0x8, %esi
   137e4:      	movq	%r15, %rdx
   137e7:      	callq	*%rax
   137e9:      	movq	(%rsp), %r15
   137ed:      	movq	%r15, 0x40(%rsp)
   137f2:      	leaq	0x20(%r15), %rdx
   137f6:      	movq	%rdx, 0x38(%rsp)
   137fb:      	movq	0x30(%rsp), %r12
   13800:      	cmpq	0x18(%rsp), %r12
   13805:      	jne	0x13812 <generic_fentry_path+0x8532>
   13807:      	cmpq	0x20(%rsp), %rdx
   1380c:      	je	0x16d4d <generic_fentry_path+0xba6d>
   13812:      	movl	$0x4, %eax
   13817:      	leaq	0x10(%rsp), %rdi
   1381c:      	movl	$0x8, %esi
   13821:      	callq	*%rax
   13823:      	cmpq	0x10(%rsp), %r12
   13828:      	je	0x13920 <generic_fentry_path+0x8640>
   1382e:      	leaq	0x18(%r12), %rbx
   13833:      	movl	$0x4, %eax
   13838:      	movq	%rbp, %rdi
   1383b:      	movl	$0x8, %esi
   13840:      	movq	%rbx, %rdx
   13843:      	callq	*%rax
   13845:      	cmpq	%r12, (%rsp)
   13849:      	je	0x13920 <generic_fentry_path+0x8640>
   1384f:      	movl	$0x4, %eax
   13854:      	leaq	0x8(%rsp), %rdi
   13859:      	movl	$0x8, %esi
   1385e:      	movq	%rbx, %rdx
   13861:      	callq	*%rax
   13863:      	addq	$0x20, %r12
   13867:      	movl	$0x4, %eax
   1386c:      	leaq	0x58(%rsp), %rdi
   13871:      	movl	$0x10, %ecx
   13876:      	movl	$0x10, %esi
   1387b:      	movq	%r12, %rdx
   1387e:      	callq	*%rax
   13880:      	movq	0x28(%rsp), %rbx
   13885:      	movq	0x48(%rsp), %rax
   1388a:      	movl	0x5c(%rsp), %r15d
   1388f:      	subq	%rbx, %rax
   13892:      	movl	0x50(%rsp), %r12d
   13897:      	movl	%r15d, %edx
   1389a:      	subl	%r12d, %edx
   1389d:      	movl	$0x0, %ecx
   138a2:      	cmovbl	%ecx, %edx
   138a5:      	addq	0x60(%rsp), %rdx
   138aa:      	xorl	%esi, %esi
   138ac:      	cmpl	%r15d, %r12d
   138af:      	seta	%sil
   138b3:      	movl	%r15d, %ecx
   138b6:      	cmovbl	%r12d, %ecx
   138ba:      	addl	%ecx, %esi
   138bc:      	movl	%r12d, %edi
   138bf:      	subl	%esi, %edi
   138c1:      	movl	%edi, 0x50(%rsp)
   138c5:      	subq	%rsi, %rax
   138c8:      	jb	0x16d52 <generic_fentry_path+0xba72>
   138ce:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   138d4:      	ja	0x16d52 <generic_fentry_path+0xba72>
   138da:      	cmpl	%r15d, %r12d
   138dd:      	jbe	0x138e3 <generic_fentry_path+0x8603>
   138df:      	movb	$0x2f, (%rbx,%rax)
   138e3:      	xorl	%edi, %edi
   138e5:      	cmpl	%r15d, %r12d
   138e8:      	seta	%dil
   138ec:      	movzbl	%cl, %esi
   138ef:      	addq	%rax, %rbx
   138f2:      	addq	%rbx, %rdi
   138f5:      	movl	$0x4, %eax
   138fa:      	callq	*%rax
   138fc:      	movq	%rbx, 0x48(%rsp)
   13901:      	cmpl	%r15d, %r12d
   13904:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   1390a:      	movq	0x8(%rsp), %r12
   1390f:      	movq	%r12, 0x30(%rsp)
   13914:      	movq	0x38(%rsp), %rdx
   13919:      	movq	0x40(%rsp), %r15
   1391e:      	jmp	0x13971 <generic_fentry_path+0x8691>
   13920:      	leaq	0x10(%r15), %rdx
   13924:      	movl	$0x4, %eax
   13929:      	movq	%rbp, %rdi
   1392c:      	movl	$0x8, %esi
   13931:      	callq	*%rax
   13933:      	movq	0x40(%rsp), %rax
   13938:      	cmpq	(%rsp), %rax
   1393c:      	je	0x16d4d <generic_fentry_path+0xba6d>
   13942:      	addq	$0x18, %r15
   13946:      	movl	$0x4, %eax
   1394b:      	leaq	0x30(%rsp), %rdi
   13950:      	movl	$0x8, %esi
   13955:      	movq	%r15, %rdx
   13958:      	callq	*%rax
   1395a:      	movq	(%rsp), %r15
   1395e:      	movq	%r15, 0x40(%rsp)
   13963:      	leaq	0x20(%r15), %rdx
   13967:      	movq	%rdx, 0x38(%rsp)
   1396c:      	movq	0x30(%rsp), %r12
   13971:      	cmpq	0x18(%rsp), %r12
   13976:      	jne	0x13983 <generic_fentry_path+0x86a3>
   13978:      	cmpq	0x20(%rsp), %rdx
   1397d:      	je	0x16d4d <generic_fentry_path+0xba6d>
   13983:      	movl	$0x4, %eax
   13988:      	leaq	0x10(%rsp), %rdi
   1398d:      	movl	$0x8, %esi
   13992:      	callq	*%rax
   13994:      	cmpq	0x10(%rsp), %r12
   13999:      	je	0x13a91 <generic_fentry_path+0x87b1>
   1399f:      	leaq	0x18(%r12), %rbx
   139a4:      	movl	$0x4, %eax
   139a9:      	movq	%rbp, %rdi
   139ac:      	movl	$0x8, %esi
   139b1:      	movq	%rbx, %rdx
   139b4:      	callq	*%rax
   139b6:      	cmpq	%r12, (%rsp)
   139ba:      	je	0x13a91 <generic_fentry_path+0x87b1>
   139c0:      	movl	$0x4, %eax
   139c5:      	leaq	0x8(%rsp), %rdi
   139ca:      	movl	$0x8, %esi
   139cf:      	movq	%rbx, %rdx
   139d2:      	callq	*%rax
   139d4:      	addq	$0x20, %r12
   139d8:      	movl	$0x4, %eax
   139dd:      	leaq	0x58(%rsp), %rdi
   139e2:      	movl	$0x10, %ecx
   139e7:      	movl	$0x10, %esi
   139ec:      	movq	%r12, %rdx
   139ef:      	callq	*%rax
   139f1:      	movq	0x28(%rsp), %rbx
   139f6:      	movq	0x48(%rsp), %rax
   139fb:      	movl	0x5c(%rsp), %r15d
   13a00:      	subq	%rbx, %rax
   13a03:      	movl	0x50(%rsp), %r12d
   13a08:      	movl	%r15d, %edx
   13a0b:      	subl	%r12d, %edx
   13a0e:      	movl	$0x0, %ecx
   13a13:      	cmovbl	%ecx, %edx
   13a16:      	addq	0x60(%rsp), %rdx
   13a1b:      	xorl	%esi, %esi
   13a1d:      	cmpl	%r15d, %r12d
   13a20:      	seta	%sil
   13a24:      	movl	%r15d, %ecx
   13a27:      	cmovbl	%r12d, %ecx
   13a2b:      	addl	%ecx, %esi
   13a2d:      	movl	%r12d, %edi
   13a30:      	subl	%esi, %edi
   13a32:      	movl	%edi, 0x50(%rsp)
   13a36:      	subq	%rsi, %rax
   13a39:      	jb	0x16d52 <generic_fentry_path+0xba72>
   13a3f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13a45:      	ja	0x16d52 <generic_fentry_path+0xba72>
   13a4b:      	cmpl	%r15d, %r12d
   13a4e:      	jbe	0x13a54 <generic_fentry_path+0x8774>
   13a50:      	movb	$0x2f, (%rbx,%rax)
   13a54:      	xorl	%edi, %edi
   13a56:      	cmpl	%r15d, %r12d
   13a59:      	seta	%dil
   13a5d:      	movzbl	%cl, %esi
   13a60:      	addq	%rax, %rbx
   13a63:      	addq	%rbx, %rdi
   13a66:      	movl	$0x4, %eax
   13a6b:      	callq	*%rax
   13a6d:      	movq	%rbx, 0x48(%rsp)
   13a72:      	cmpl	%r15d, %r12d
   13a75:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   13a7b:      	movq	0x8(%rsp), %r12
   13a80:      	movq	%r12, 0x30(%rsp)
   13a85:      	movq	0x38(%rsp), %rdx
   13a8a:      	movq	0x40(%rsp), %r15
   13a8f:      	jmp	0x13ae2 <generic_fentry_path+0x8802>
   13a91:      	leaq	0x10(%r15), %rdx
   13a95:      	movl	$0x4, %eax
   13a9a:      	movq	%rbp, %rdi
   13a9d:      	movl	$0x8, %esi
   13aa2:      	callq	*%rax
   13aa4:      	movq	0x40(%rsp), %rax
   13aa9:      	cmpq	(%rsp), %rax
   13aad:      	je	0x16d4d <generic_fentry_path+0xba6d>
   13ab3:      	addq	$0x18, %r15
   13ab7:      	movl	$0x4, %eax
   13abc:      	leaq	0x30(%rsp), %rdi
   13ac1:      	movl	$0x8, %esi
   13ac6:      	movq	%r15, %rdx
   13ac9:      	callq	*%rax
   13acb:      	movq	(%rsp), %r15
   13acf:      	movq	%r15, 0x40(%rsp)
   13ad4:      	leaq	0x20(%r15), %rdx
   13ad8:      	movq	%rdx, 0x38(%rsp)
   13add:      	movq	0x30(%rsp), %r12
   13ae2:      	cmpq	0x18(%rsp), %r12
   13ae7:      	jne	0x13af4 <generic_fentry_path+0x8814>
   13ae9:      	cmpq	0x20(%rsp), %rdx
   13aee:      	je	0x16d4d <generic_fentry_path+0xba6d>
   13af4:      	movl	$0x4, %eax
   13af9:      	leaq	0x10(%rsp), %rdi
   13afe:      	movl	$0x8, %esi
   13b03:      	callq	*%rax
   13b05:      	cmpq	0x10(%rsp), %r12
   13b0a:      	je	0x13c02 <generic_fentry_path+0x8922>
   13b10:      	leaq	0x18(%r12), %rbx
   13b15:      	movl	$0x4, %eax
   13b1a:      	movq	%rbp, %rdi
   13b1d:      	movl	$0x8, %esi
   13b22:      	movq	%rbx, %rdx
   13b25:      	callq	*%rax
   13b27:      	cmpq	%r12, (%rsp)
   13b2b:      	je	0x13c02 <generic_fentry_path+0x8922>
   13b31:      	movl	$0x4, %eax
   13b36:      	leaq	0x8(%rsp), %rdi
   13b3b:      	movl	$0x8, %esi
   13b40:      	movq	%rbx, %rdx
   13b43:      	callq	*%rax
   13b45:      	addq	$0x20, %r12
   13b49:      	movl	$0x4, %eax
   13b4e:      	leaq	0x58(%rsp), %rdi
   13b53:      	movl	$0x10, %ecx
   13b58:      	movl	$0x10, %esi
   13b5d:      	movq	%r12, %rdx
   13b60:      	callq	*%rax
   13b62:      	movq	0x28(%rsp), %rbx
   13b67:      	movq	0x48(%rsp), %rax
   13b6c:      	movl	0x5c(%rsp), %r15d
   13b71:      	subq	%rbx, %rax
   13b74:      	movl	0x50(%rsp), %r12d
   13b79:      	movl	%r15d, %edx
   13b7c:      	subl	%r12d, %edx
   13b7f:      	movl	$0x0, %ecx
   13b84:      	cmovbl	%ecx, %edx
   13b87:      	addq	0x60(%rsp), %rdx
   13b8c:      	xorl	%esi, %esi
   13b8e:      	cmpl	%r15d, %r12d
   13b91:      	seta	%sil
   13b95:      	movl	%r15d, %ecx
   13b98:      	cmovbl	%r12d, %ecx
   13b9c:      	addl	%ecx, %esi
   13b9e:      	movl	%r12d, %edi
   13ba1:      	subl	%esi, %edi
   13ba3:      	movl	%edi, 0x50(%rsp)
   13ba7:      	subq	%rsi, %rax
   13baa:      	jb	0x16d52 <generic_fentry_path+0xba72>
   13bb0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13bb6:      	ja	0x16d52 <generic_fentry_path+0xba72>
   13bbc:      	cmpl	%r15d, %r12d
   13bbf:      	jbe	0x13bc5 <generic_fentry_path+0x88e5>
   13bc1:      	movb	$0x2f, (%rbx,%rax)
   13bc5:      	xorl	%edi, %edi
   13bc7:      	cmpl	%r15d, %r12d
   13bca:      	seta	%dil
   13bce:      	movzbl	%cl, %esi
   13bd1:      	addq	%rax, %rbx
   13bd4:      	addq	%rbx, %rdi
   13bd7:      	movl	$0x4, %eax
   13bdc:      	callq	*%rax
   13bde:      	movq	%rbx, 0x48(%rsp)
   13be3:      	cmpl	%r15d, %r12d
   13be6:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   13bec:      	movq	0x8(%rsp), %r12
   13bf1:      	movq	%r12, 0x30(%rsp)
   13bf6:      	movq	0x38(%rsp), %rdx
   13bfb:      	movq	0x40(%rsp), %r15
   13c00:      	jmp	0x13c53 <generic_fentry_path+0x8973>
   13c02:      	leaq	0x10(%r15), %rdx
   13c06:      	movl	$0x4, %eax
   13c0b:      	movq	%rbp, %rdi
   13c0e:      	movl	$0x8, %esi
   13c13:      	callq	*%rax
   13c15:      	movq	0x40(%rsp), %rax
   13c1a:      	cmpq	(%rsp), %rax
   13c1e:      	je	0x16d4d <generic_fentry_path+0xba6d>
   13c24:      	addq	$0x18, %r15
   13c28:      	movl	$0x4, %eax
   13c2d:      	leaq	0x30(%rsp), %rdi
   13c32:      	movl	$0x8, %esi
   13c37:      	movq	%r15, %rdx
   13c3a:      	callq	*%rax
   13c3c:      	movq	(%rsp), %r15
   13c40:      	movq	%r15, 0x40(%rsp)
   13c45:      	leaq	0x20(%r15), %rdx
   13c49:      	movq	%rdx, 0x38(%rsp)
   13c4e:      	movq	0x30(%rsp), %r12
   13c53:      	cmpq	0x18(%rsp), %r12
   13c58:      	jne	0x13c65 <generic_fentry_path+0x8985>
   13c5a:      	cmpq	0x20(%rsp), %rdx
   13c5f:      	je	0x16d4d <generic_fentry_path+0xba6d>
   13c65:      	movl	$0x4, %eax
   13c6a:      	leaq	0x10(%rsp), %rdi
   13c6f:      	movl	$0x8, %esi
   13c74:      	callq	*%rax
   13c76:      	cmpq	0x10(%rsp), %r12
   13c7b:      	je	0x13d73 <generic_fentry_path+0x8a93>
   13c81:      	leaq	0x18(%r12), %rbx
   13c86:      	movl	$0x4, %eax
   13c8b:      	movq	%rbp, %rdi
   13c8e:      	movl	$0x8, %esi
   13c93:      	movq	%rbx, %rdx
   13c96:      	callq	*%rax
   13c98:      	cmpq	%r12, (%rsp)
   13c9c:      	je	0x13d73 <generic_fentry_path+0x8a93>
   13ca2:      	movl	$0x4, %eax
   13ca7:      	leaq	0x8(%rsp), %rdi
   13cac:      	movl	$0x8, %esi
   13cb1:      	movq	%rbx, %rdx
   13cb4:      	callq	*%rax
   13cb6:      	addq	$0x20, %r12
   13cba:      	movl	$0x4, %eax
   13cbf:      	leaq	0x58(%rsp), %rdi
   13cc4:      	movl	$0x10, %ecx
   13cc9:      	movl	$0x10, %esi
   13cce:      	movq	%r12, %rdx
   13cd1:      	callq	*%rax
   13cd3:      	movq	0x28(%rsp), %rbx
   13cd8:      	movq	0x48(%rsp), %rax
   13cdd:      	movl	0x5c(%rsp), %r15d
   13ce2:      	subq	%rbx, %rax
   13ce5:      	movl	0x50(%rsp), %r12d
   13cea:      	movl	%r15d, %edx
   13ced:      	subl	%r12d, %edx
   13cf0:      	movl	$0x0, %ecx
   13cf5:      	cmovbl	%ecx, %edx
   13cf8:      	addq	0x60(%rsp), %rdx
   13cfd:      	xorl	%esi, %esi
   13cff:      	cmpl	%r15d, %r12d
   13d02:      	seta	%sil
   13d06:      	movl	%r15d, %ecx
   13d09:      	cmovbl	%r12d, %ecx
   13d0d:      	addl	%ecx, %esi
   13d0f:      	movl	%r12d, %edi
   13d12:      	subl	%esi, %edi
   13d14:      	movl	%edi, 0x50(%rsp)
   13d18:      	subq	%rsi, %rax
   13d1b:      	jb	0x16d52 <generic_fentry_path+0xba72>
   13d21:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13d27:      	ja	0x16d52 <generic_fentry_path+0xba72>
   13d2d:      	cmpl	%r15d, %r12d
   13d30:      	jbe	0x13d36 <generic_fentry_path+0x8a56>
   13d32:      	movb	$0x2f, (%rbx,%rax)
   13d36:      	xorl	%edi, %edi
   13d38:      	cmpl	%r15d, %r12d
   13d3b:      	seta	%dil
   13d3f:      	movzbl	%cl, %esi
   13d42:      	addq	%rax, %rbx
   13d45:      	addq	%rbx, %rdi
   13d48:      	movl	$0x4, %eax
   13d4d:      	callq	*%rax
   13d4f:      	movq	%rbx, 0x48(%rsp)
   13d54:      	cmpl	%r15d, %r12d
   13d57:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   13d5d:      	movq	0x8(%rsp), %r12
   13d62:      	movq	%r12, 0x30(%rsp)
   13d67:      	movq	0x38(%rsp), %rdx
   13d6c:      	movq	0x40(%rsp), %r15
   13d71:      	jmp	0x13dc4 <generic_fentry_path+0x8ae4>
   13d73:      	leaq	0x10(%r15), %rdx
   13d77:      	movl	$0x4, %eax
   13d7c:      	movq	%rbp, %rdi
   13d7f:      	movl	$0x8, %esi
   13d84:      	callq	*%rax
   13d86:      	movq	0x40(%rsp), %rax
   13d8b:      	cmpq	(%rsp), %rax
   13d8f:      	je	0x16d4d <generic_fentry_path+0xba6d>
   13d95:      	addq	$0x18, %r15
   13d99:      	movl	$0x4, %eax
   13d9e:      	leaq	0x30(%rsp), %rdi
   13da3:      	movl	$0x8, %esi
   13da8:      	movq	%r15, %rdx
   13dab:      	callq	*%rax
   13dad:      	movq	(%rsp), %r15
   13db1:      	movq	%r15, 0x40(%rsp)
   13db6:      	leaq	0x20(%r15), %rdx
   13dba:      	movq	%rdx, 0x38(%rsp)
   13dbf:      	movq	0x30(%rsp), %r12
   13dc4:      	cmpq	0x18(%rsp), %r12
   13dc9:      	jne	0x13dd6 <generic_fentry_path+0x8af6>
   13dcb:      	cmpq	0x20(%rsp), %rdx
   13dd0:      	je	0x16d4d <generic_fentry_path+0xba6d>
   13dd6:      	movl	$0x4, %eax
   13ddb:      	leaq	0x10(%rsp), %rdi
   13de0:      	movl	$0x8, %esi
   13de5:      	callq	*%rax
   13de7:      	cmpq	0x10(%rsp), %r12
   13dec:      	je	0x13ee4 <generic_fentry_path+0x8c04>
   13df2:      	leaq	0x18(%r12), %rbx
   13df7:      	movl	$0x4, %eax
   13dfc:      	movq	%rbp, %rdi
   13dff:      	movl	$0x8, %esi
   13e04:      	movq	%rbx, %rdx
   13e07:      	callq	*%rax
   13e09:      	cmpq	%r12, (%rsp)
   13e0d:      	je	0x13ee4 <generic_fentry_path+0x8c04>
   13e13:      	movl	$0x4, %eax
   13e18:      	leaq	0x8(%rsp), %rdi
   13e1d:      	movl	$0x8, %esi
   13e22:      	movq	%rbx, %rdx
   13e25:      	callq	*%rax
   13e27:      	addq	$0x20, %r12
   13e2b:      	movl	$0x4, %eax
   13e30:      	leaq	0x58(%rsp), %rdi
   13e35:      	movl	$0x10, %ecx
   13e3a:      	movl	$0x10, %esi
   13e3f:      	movq	%r12, %rdx
   13e42:      	callq	*%rax
   13e44:      	movq	0x28(%rsp), %rbx
   13e49:      	movq	0x48(%rsp), %rax
   13e4e:      	movl	0x5c(%rsp), %r15d
   13e53:      	subq	%rbx, %rax
   13e56:      	movl	0x50(%rsp), %r12d
   13e5b:      	movl	%r15d, %edx
   13e5e:      	subl	%r12d, %edx
   13e61:      	movl	$0x0, %ecx
   13e66:      	cmovbl	%ecx, %edx
   13e69:      	addq	0x60(%rsp), %rdx
   13e6e:      	xorl	%esi, %esi
   13e70:      	cmpl	%r15d, %r12d
   13e73:      	seta	%sil
   13e77:      	movl	%r15d, %ecx
   13e7a:      	cmovbl	%r12d, %ecx
   13e7e:      	addl	%ecx, %esi
   13e80:      	movl	%r12d, %edi
   13e83:      	subl	%esi, %edi
   13e85:      	movl	%edi, 0x50(%rsp)
   13e89:      	subq	%rsi, %rax
   13e8c:      	jb	0x16d52 <generic_fentry_path+0xba72>
   13e92:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13e98:      	ja	0x16d52 <generic_fentry_path+0xba72>
   13e9e:      	cmpl	%r15d, %r12d
   13ea1:      	jbe	0x13ea7 <generic_fentry_path+0x8bc7>
   13ea3:      	movb	$0x2f, (%rbx,%rax)
   13ea7:      	xorl	%edi, %edi
   13ea9:      	cmpl	%r15d, %r12d
   13eac:      	seta	%dil
   13eb0:      	movzbl	%cl, %esi
   13eb3:      	addq	%rax, %rbx
   13eb6:      	addq	%rbx, %rdi
   13eb9:      	movl	$0x4, %eax
   13ebe:      	callq	*%rax
   13ec0:      	movq	%rbx, 0x48(%rsp)
   13ec5:      	cmpl	%r15d, %r12d
   13ec8:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   13ece:      	movq	0x8(%rsp), %r12
   13ed3:      	movq	%r12, 0x30(%rsp)
   13ed8:      	movq	0x38(%rsp), %rdx
   13edd:      	movq	0x40(%rsp), %r15
   13ee2:      	jmp	0x13f35 <generic_fentry_path+0x8c55>
   13ee4:      	leaq	0x10(%r15), %rdx
   13ee8:      	movl	$0x4, %eax
   13eed:      	movq	%rbp, %rdi
   13ef0:      	movl	$0x8, %esi
   13ef5:      	callq	*%rax
   13ef7:      	movq	0x40(%rsp), %rax
   13efc:      	cmpq	(%rsp), %rax
   13f00:      	je	0x16d4d <generic_fentry_path+0xba6d>
   13f06:      	addq	$0x18, %r15
   13f0a:      	movl	$0x4, %eax
   13f0f:      	leaq	0x30(%rsp), %rdi
   13f14:      	movl	$0x8, %esi
   13f19:      	movq	%r15, %rdx
   13f1c:      	callq	*%rax
   13f1e:      	movq	(%rsp), %r15
   13f22:      	movq	%r15, 0x40(%rsp)
   13f27:      	leaq	0x20(%r15), %rdx
   13f2b:      	movq	%rdx, 0x38(%rsp)
   13f30:      	movq	0x30(%rsp), %r12
   13f35:      	cmpq	0x18(%rsp), %r12
   13f3a:      	jne	0x13f47 <generic_fentry_path+0x8c67>
   13f3c:      	cmpq	0x20(%rsp), %rdx
   13f41:      	je	0x16d4d <generic_fentry_path+0xba6d>
   13f47:      	movl	$0x4, %eax
   13f4c:      	leaq	0x10(%rsp), %rdi
   13f51:      	movl	$0x8, %esi
   13f56:      	callq	*%rax
   13f58:      	cmpq	0x10(%rsp), %r12
   13f5d:      	je	0x14055 <generic_fentry_path+0x8d75>
   13f63:      	leaq	0x18(%r12), %rbx
   13f68:      	movl	$0x4, %eax
   13f6d:      	movq	%rbp, %rdi
   13f70:      	movl	$0x8, %esi
   13f75:      	movq	%rbx, %rdx
   13f78:      	callq	*%rax
   13f7a:      	cmpq	%r12, (%rsp)
   13f7e:      	je	0x14055 <generic_fentry_path+0x8d75>
   13f84:      	movl	$0x4, %eax
   13f89:      	leaq	0x8(%rsp), %rdi
   13f8e:      	movl	$0x8, %esi
   13f93:      	movq	%rbx, %rdx
   13f96:      	callq	*%rax
   13f98:      	addq	$0x20, %r12
   13f9c:      	movl	$0x4, %eax
   13fa1:      	leaq	0x58(%rsp), %rdi
   13fa6:      	movl	$0x10, %ecx
   13fab:      	movl	$0x10, %esi
   13fb0:      	movq	%r12, %rdx
   13fb3:      	callq	*%rax
   13fb5:      	movq	0x28(%rsp), %rbx
   13fba:      	movq	0x48(%rsp), %rax
   13fbf:      	movl	0x5c(%rsp), %r15d
   13fc4:      	subq	%rbx, %rax
   13fc7:      	movl	0x50(%rsp), %r12d
   13fcc:      	movl	%r15d, %edx
   13fcf:      	subl	%r12d, %edx
   13fd2:      	movl	$0x0, %ecx
   13fd7:      	cmovbl	%ecx, %edx
   13fda:      	addq	0x60(%rsp), %rdx
   13fdf:      	xorl	%esi, %esi
   13fe1:      	cmpl	%r15d, %r12d
   13fe4:      	seta	%sil
   13fe8:      	movl	%r15d, %ecx
   13feb:      	cmovbl	%r12d, %ecx
   13fef:      	addl	%ecx, %esi
   13ff1:      	movl	%r12d, %edi
   13ff4:      	subl	%esi, %edi
   13ff6:      	movl	%edi, 0x50(%rsp)
   13ffa:      	subq	%rsi, %rax
   13ffd:      	jb	0x16d52 <generic_fentry_path+0xba72>
   14003:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14009:      	ja	0x16d52 <generic_fentry_path+0xba72>
   1400f:      	cmpl	%r15d, %r12d
   14012:      	jbe	0x14018 <generic_fentry_path+0x8d38>
   14014:      	movb	$0x2f, (%rbx,%rax)
   14018:      	xorl	%edi, %edi
   1401a:      	cmpl	%r15d, %r12d
   1401d:      	seta	%dil
   14021:      	movzbl	%cl, %esi
   14024:      	addq	%rax, %rbx
   14027:      	addq	%rbx, %rdi
   1402a:      	movl	$0x4, %eax
   1402f:      	callq	*%rax
   14031:      	movq	%rbx, 0x48(%rsp)
   14036:      	cmpl	%r15d, %r12d
   14039:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   1403f:      	movq	0x8(%rsp), %r12
   14044:      	movq	%r12, 0x30(%rsp)
   14049:      	movq	0x38(%rsp), %rdx
   1404e:      	movq	0x40(%rsp), %r15
   14053:      	jmp	0x140a6 <generic_fentry_path+0x8dc6>
   14055:      	leaq	0x10(%r15), %rdx
   14059:      	movl	$0x4, %eax
   1405e:      	movq	%rbp, %rdi
   14061:      	movl	$0x8, %esi
   14066:      	callq	*%rax
   14068:      	movq	0x40(%rsp), %rax
   1406d:      	cmpq	(%rsp), %rax
   14071:      	je	0x16d4d <generic_fentry_path+0xba6d>
   14077:      	addq	$0x18, %r15
   1407b:      	movl	$0x4, %eax
   14080:      	leaq	0x30(%rsp), %rdi
   14085:      	movl	$0x8, %esi
   1408a:      	movq	%r15, %rdx
   1408d:      	callq	*%rax
   1408f:      	movq	(%rsp), %r15
   14093:      	movq	%r15, 0x40(%rsp)
   14098:      	leaq	0x20(%r15), %rdx
   1409c:      	movq	%rdx, 0x38(%rsp)
   140a1:      	movq	0x30(%rsp), %r12
   140a6:      	cmpq	0x18(%rsp), %r12
   140ab:      	jne	0x140b8 <generic_fentry_path+0x8dd8>
   140ad:      	cmpq	0x20(%rsp), %rdx
   140b2:      	je	0x16d4d <generic_fentry_path+0xba6d>
   140b8:      	movl	$0x4, %eax
   140bd:      	leaq	0x10(%rsp), %rdi
   140c2:      	movl	$0x8, %esi
   140c7:      	callq	*%rax
   140c9:      	cmpq	0x10(%rsp), %r12
   140ce:      	je	0x141c6 <generic_fentry_path+0x8ee6>
   140d4:      	leaq	0x18(%r12), %rbx
   140d9:      	movl	$0x4, %eax
   140de:      	movq	%rbp, %rdi
   140e1:      	movl	$0x8, %esi
   140e6:      	movq	%rbx, %rdx
   140e9:      	callq	*%rax
   140eb:      	cmpq	%r12, (%rsp)
   140ef:      	je	0x141c6 <generic_fentry_path+0x8ee6>
   140f5:      	movl	$0x4, %eax
   140fa:      	leaq	0x8(%rsp), %rdi
   140ff:      	movl	$0x8, %esi
   14104:      	movq	%rbx, %rdx
   14107:      	callq	*%rax
   14109:      	addq	$0x20, %r12
   1410d:      	movl	$0x4, %eax
   14112:      	leaq	0x58(%rsp), %rdi
   14117:      	movl	$0x10, %ecx
   1411c:      	movl	$0x10, %esi
   14121:      	movq	%r12, %rdx
   14124:      	callq	*%rax
   14126:      	movq	0x28(%rsp), %rbx
   1412b:      	movq	0x48(%rsp), %rax
   14130:      	movl	0x5c(%rsp), %r15d
   14135:      	subq	%rbx, %rax
   14138:      	movl	0x50(%rsp), %r12d
   1413d:      	movl	%r15d, %edx
   14140:      	subl	%r12d, %edx
   14143:      	movl	$0x0, %ecx
   14148:      	cmovbl	%ecx, %edx
   1414b:      	addq	0x60(%rsp), %rdx
   14150:      	xorl	%esi, %esi
   14152:      	cmpl	%r15d, %r12d
   14155:      	seta	%sil
   14159:      	movl	%r15d, %ecx
   1415c:      	cmovbl	%r12d, %ecx
   14160:      	addl	%ecx, %esi
   14162:      	movl	%r12d, %edi
   14165:      	subl	%esi, %edi
   14167:      	movl	%edi, 0x50(%rsp)
   1416b:      	subq	%rsi, %rax
   1416e:      	jb	0x16d52 <generic_fentry_path+0xba72>
   14174:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1417a:      	ja	0x16d52 <generic_fentry_path+0xba72>
   14180:      	cmpl	%r15d, %r12d
   14183:      	jbe	0x14189 <generic_fentry_path+0x8ea9>
   14185:      	movb	$0x2f, (%rbx,%rax)
   14189:      	xorl	%edi, %edi
   1418b:      	cmpl	%r15d, %r12d
   1418e:      	seta	%dil
   14192:      	movzbl	%cl, %esi
   14195:      	addq	%rax, %rbx
   14198:      	addq	%rbx, %rdi
   1419b:      	movl	$0x4, %eax
   141a0:      	callq	*%rax
   141a2:      	movq	%rbx, 0x48(%rsp)
   141a7:      	cmpl	%r15d, %r12d
   141aa:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   141b0:      	movq	0x8(%rsp), %r12
   141b5:      	movq	%r12, 0x30(%rsp)
   141ba:      	movq	0x38(%rsp), %rdx
   141bf:      	movq	0x40(%rsp), %r15
   141c4:      	jmp	0x14217 <generic_fentry_path+0x8f37>
   141c6:      	leaq	0x10(%r15), %rdx
   141ca:      	movl	$0x4, %eax
   141cf:      	movq	%rbp, %rdi
   141d2:      	movl	$0x8, %esi
   141d7:      	callq	*%rax
   141d9:      	movq	0x40(%rsp), %rax
   141de:      	cmpq	(%rsp), %rax
   141e2:      	je	0x16d4d <generic_fentry_path+0xba6d>
   141e8:      	addq	$0x18, %r15
   141ec:      	movl	$0x4, %eax
   141f1:      	leaq	0x30(%rsp), %rdi
   141f6:      	movl	$0x8, %esi
   141fb:      	movq	%r15, %rdx
   141fe:      	callq	*%rax
   14200:      	movq	(%rsp), %r15
   14204:      	movq	%r15, 0x40(%rsp)
   14209:      	leaq	0x20(%r15), %rdx
   1420d:      	movq	%rdx, 0x38(%rsp)
   14212:      	movq	0x30(%rsp), %r12
   14217:      	cmpq	0x18(%rsp), %r12
   1421c:      	jne	0x14229 <generic_fentry_path+0x8f49>
   1421e:      	cmpq	0x20(%rsp), %rdx
   14223:      	je	0x16d4d <generic_fentry_path+0xba6d>
   14229:      	movl	$0x4, %eax
   1422e:      	leaq	0x10(%rsp), %rdi
   14233:      	movl	$0x8, %esi
   14238:      	callq	*%rax
   1423a:      	cmpq	0x10(%rsp), %r12
   1423f:      	je	0x14337 <generic_fentry_path+0x9057>
   14245:      	leaq	0x18(%r12), %rbx
   1424a:      	movl	$0x4, %eax
   1424f:      	movq	%rbp, %rdi
   14252:      	movl	$0x8, %esi
   14257:      	movq	%rbx, %rdx
   1425a:      	callq	*%rax
   1425c:      	cmpq	%r12, (%rsp)
   14260:      	je	0x14337 <generic_fentry_path+0x9057>
   14266:      	movl	$0x4, %eax
   1426b:      	leaq	0x8(%rsp), %rdi
   14270:      	movl	$0x8, %esi
   14275:      	movq	%rbx, %rdx
   14278:      	callq	*%rax
   1427a:      	addq	$0x20, %r12
   1427e:      	movl	$0x4, %eax
   14283:      	leaq	0x58(%rsp), %rdi
   14288:      	movl	$0x10, %ecx
   1428d:      	movl	$0x10, %esi
   14292:      	movq	%r12, %rdx
   14295:      	callq	*%rax
   14297:      	movq	0x28(%rsp), %rbx
   1429c:      	movq	0x48(%rsp), %rax
   142a1:      	movl	0x5c(%rsp), %r15d
   142a6:      	subq	%rbx, %rax
   142a9:      	movl	0x50(%rsp), %r12d
   142ae:      	movl	%r15d, %edx
   142b1:      	subl	%r12d, %edx
   142b4:      	movl	$0x0, %ecx
   142b9:      	cmovbl	%ecx, %edx
   142bc:      	addq	0x60(%rsp), %rdx
   142c1:      	xorl	%esi, %esi
   142c3:      	cmpl	%r15d, %r12d
   142c6:      	seta	%sil
   142ca:      	movl	%r15d, %ecx
   142cd:      	cmovbl	%r12d, %ecx
   142d1:      	addl	%ecx, %esi
   142d3:      	movl	%r12d, %edi
   142d6:      	subl	%esi, %edi
   142d8:      	movl	%edi, 0x50(%rsp)
   142dc:      	subq	%rsi, %rax
   142df:      	jb	0x16d52 <generic_fentry_path+0xba72>
   142e5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   142eb:      	ja	0x16d52 <generic_fentry_path+0xba72>
   142f1:      	cmpl	%r15d, %r12d
   142f4:      	jbe	0x142fa <generic_fentry_path+0x901a>
   142f6:      	movb	$0x2f, (%rbx,%rax)
   142fa:      	xorl	%edi, %edi
   142fc:      	cmpl	%r15d, %r12d
   142ff:      	seta	%dil
   14303:      	movzbl	%cl, %esi
   14306:      	addq	%rax, %rbx
   14309:      	addq	%rbx, %rdi
   1430c:      	movl	$0x4, %eax
   14311:      	callq	*%rax
   14313:      	movq	%rbx, 0x48(%rsp)
   14318:      	cmpl	%r15d, %r12d
   1431b:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   14321:      	movq	0x8(%rsp), %r12
   14326:      	movq	%r12, 0x30(%rsp)
   1432b:      	movq	0x38(%rsp), %rdx
   14330:      	movq	0x40(%rsp), %r15
   14335:      	jmp	0x14388 <generic_fentry_path+0x90a8>
   14337:      	leaq	0x10(%r15), %rdx
   1433b:      	movl	$0x4, %eax
   14340:      	movq	%rbp, %rdi
   14343:      	movl	$0x8, %esi
   14348:      	callq	*%rax
   1434a:      	movq	0x40(%rsp), %rax
   1434f:      	cmpq	(%rsp), %rax
   14353:      	je	0x16d4d <generic_fentry_path+0xba6d>
   14359:      	addq	$0x18, %r15
   1435d:      	movl	$0x4, %eax
   14362:      	leaq	0x30(%rsp), %rdi
   14367:      	movl	$0x8, %esi
   1436c:      	movq	%r15, %rdx
   1436f:      	callq	*%rax
   14371:      	movq	(%rsp), %r15
   14375:      	movq	%r15, 0x40(%rsp)
   1437a:      	leaq	0x20(%r15), %rdx
   1437e:      	movq	%rdx, 0x38(%rsp)
   14383:      	movq	0x30(%rsp), %r12
   14388:      	cmpq	0x18(%rsp), %r12
   1438d:      	jne	0x1439a <generic_fentry_path+0x90ba>
   1438f:      	cmpq	0x20(%rsp), %rdx
   14394:      	je	0x16d4d <generic_fentry_path+0xba6d>
   1439a:      	movl	$0x4, %eax
   1439f:      	leaq	0x10(%rsp), %rdi
   143a4:      	movl	$0x8, %esi
   143a9:      	callq	*%rax
   143ab:      	cmpq	0x10(%rsp), %r12
   143b0:      	je	0x144a8 <generic_fentry_path+0x91c8>
   143b6:      	leaq	0x18(%r12), %rbx
   143bb:      	movl	$0x4, %eax
   143c0:      	movq	%rbp, %rdi
   143c3:      	movl	$0x8, %esi
   143c8:      	movq	%rbx, %rdx
   143cb:      	callq	*%rax
   143cd:      	cmpq	%r12, (%rsp)
   143d1:      	je	0x144a8 <generic_fentry_path+0x91c8>
   143d7:      	movl	$0x4, %eax
   143dc:      	leaq	0x8(%rsp), %rdi
   143e1:      	movl	$0x8, %esi
   143e6:      	movq	%rbx, %rdx
   143e9:      	callq	*%rax
   143eb:      	addq	$0x20, %r12
   143ef:      	movl	$0x4, %eax
   143f4:      	leaq	0x58(%rsp), %rdi
   143f9:      	movl	$0x10, %ecx
   143fe:      	movl	$0x10, %esi
   14403:      	movq	%r12, %rdx
   14406:      	callq	*%rax
   14408:      	movq	0x28(%rsp), %rbx
   1440d:      	movq	0x48(%rsp), %rax
   14412:      	movl	0x5c(%rsp), %r15d
   14417:      	subq	%rbx, %rax
   1441a:      	movl	0x50(%rsp), %r12d
   1441f:      	movl	%r15d, %edx
   14422:      	subl	%r12d, %edx
   14425:      	movl	$0x0, %ecx
   1442a:      	cmovbl	%ecx, %edx
   1442d:      	addq	0x60(%rsp), %rdx
   14432:      	xorl	%esi, %esi
   14434:      	cmpl	%r15d, %r12d
   14437:      	seta	%sil
   1443b:      	movl	%r15d, %ecx
   1443e:      	cmovbl	%r12d, %ecx
   14442:      	addl	%ecx, %esi
   14444:      	movl	%r12d, %edi
   14447:      	subl	%esi, %edi
   14449:      	movl	%edi, 0x50(%rsp)
   1444d:      	subq	%rsi, %rax
   14450:      	jb	0x16d52 <generic_fentry_path+0xba72>
   14456:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1445c:      	ja	0x16d52 <generic_fentry_path+0xba72>
   14462:      	cmpl	%r15d, %r12d
   14465:      	jbe	0x1446b <generic_fentry_path+0x918b>
   14467:      	movb	$0x2f, (%rbx,%rax)
   1446b:      	xorl	%edi, %edi
   1446d:      	cmpl	%r15d, %r12d
   14470:      	seta	%dil
   14474:      	movzbl	%cl, %esi
   14477:      	addq	%rax, %rbx
   1447a:      	addq	%rbx, %rdi
   1447d:      	movl	$0x4, %eax
   14482:      	callq	*%rax
   14484:      	movq	%rbx, 0x48(%rsp)
   14489:      	cmpl	%r15d, %r12d
   1448c:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   14492:      	movq	0x8(%rsp), %r12
   14497:      	movq	%r12, 0x30(%rsp)
   1449c:      	movq	0x38(%rsp), %rdx
   144a1:      	movq	0x40(%rsp), %r15
   144a6:      	jmp	0x144f9 <generic_fentry_path+0x9219>
   144a8:      	leaq	0x10(%r15), %rdx
   144ac:      	movl	$0x4, %eax
   144b1:      	movq	%rbp, %rdi
   144b4:      	movl	$0x8, %esi
   144b9:      	callq	*%rax
   144bb:      	movq	0x40(%rsp), %rax
   144c0:      	cmpq	(%rsp), %rax
   144c4:      	je	0x16d4d <generic_fentry_path+0xba6d>
   144ca:      	addq	$0x18, %r15
   144ce:      	movl	$0x4, %eax
   144d3:      	leaq	0x30(%rsp), %rdi
   144d8:      	movl	$0x8, %esi
   144dd:      	movq	%r15, %rdx
   144e0:      	callq	*%rax
   144e2:      	movq	(%rsp), %r15
   144e6:      	movq	%r15, 0x40(%rsp)
   144eb:      	leaq	0x20(%r15), %rdx
   144ef:      	movq	%rdx, 0x38(%rsp)
   144f4:      	movq	0x30(%rsp), %r12
   144f9:      	cmpq	0x18(%rsp), %r12
   144fe:      	jne	0x1450b <generic_fentry_path+0x922b>
   14500:      	cmpq	0x20(%rsp), %rdx
   14505:      	je	0x16d4d <generic_fentry_path+0xba6d>
   1450b:      	movl	$0x4, %eax
   14510:      	leaq	0x10(%rsp), %rdi
   14515:      	movl	$0x8, %esi
   1451a:      	callq	*%rax
   1451c:      	cmpq	0x10(%rsp), %r12
   14521:      	je	0x14619 <generic_fentry_path+0x9339>
   14527:      	leaq	0x18(%r12), %rbx
   1452c:      	movl	$0x4, %eax
   14531:      	movq	%rbp, %rdi
   14534:      	movl	$0x8, %esi
   14539:      	movq	%rbx, %rdx
   1453c:      	callq	*%rax
   1453e:      	cmpq	%r12, (%rsp)
   14542:      	je	0x14619 <generic_fentry_path+0x9339>
   14548:      	movl	$0x4, %eax
   1454d:      	leaq	0x8(%rsp), %rdi
   14552:      	movl	$0x8, %esi
   14557:      	movq	%rbx, %rdx
   1455a:      	callq	*%rax
   1455c:      	addq	$0x20, %r12
   14560:      	movl	$0x4, %eax
   14565:      	leaq	0x58(%rsp), %rdi
   1456a:      	movl	$0x10, %ecx
   1456f:      	movl	$0x10, %esi
   14574:      	movq	%r12, %rdx
   14577:      	callq	*%rax
   14579:      	movq	0x28(%rsp), %rbx
   1457e:      	movq	0x48(%rsp), %rax
   14583:      	movl	0x5c(%rsp), %r15d
   14588:      	subq	%rbx, %rax
   1458b:      	movl	0x50(%rsp), %r12d
   14590:      	movl	%r15d, %edx
   14593:      	subl	%r12d, %edx
   14596:      	movl	$0x0, %ecx
   1459b:      	cmovbl	%ecx, %edx
   1459e:      	addq	0x60(%rsp), %rdx
   145a3:      	xorl	%esi, %esi
   145a5:      	cmpl	%r15d, %r12d
   145a8:      	seta	%sil
   145ac:      	movl	%r15d, %ecx
   145af:      	cmovbl	%r12d, %ecx
   145b3:      	addl	%ecx, %esi
   145b5:      	movl	%r12d, %edi
   145b8:      	subl	%esi, %edi
   145ba:      	movl	%edi, 0x50(%rsp)
   145be:      	subq	%rsi, %rax
   145c1:      	jb	0x16d52 <generic_fentry_path+0xba72>
   145c7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   145cd:      	ja	0x16d52 <generic_fentry_path+0xba72>
   145d3:      	cmpl	%r15d, %r12d
   145d6:      	jbe	0x145dc <generic_fentry_path+0x92fc>
   145d8:      	movb	$0x2f, (%rbx,%rax)
   145dc:      	xorl	%edi, %edi
   145de:      	cmpl	%r15d, %r12d
   145e1:      	seta	%dil
   145e5:      	movzbl	%cl, %esi
   145e8:      	addq	%rax, %rbx
   145eb:      	addq	%rbx, %rdi
   145ee:      	movl	$0x4, %eax
   145f3:      	callq	*%rax
   145f5:      	movq	%rbx, 0x48(%rsp)
   145fa:      	cmpl	%r15d, %r12d
   145fd:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   14603:      	movq	0x8(%rsp), %r12
   14608:      	movq	%r12, 0x30(%rsp)
   1460d:      	movq	0x38(%rsp), %rdx
   14612:      	movq	0x40(%rsp), %r15
   14617:      	jmp	0x1466a <generic_fentry_path+0x938a>
   14619:      	leaq	0x10(%r15), %rdx
   1461d:      	movl	$0x4, %eax
   14622:      	movq	%rbp, %rdi
   14625:      	movl	$0x8, %esi
   1462a:      	callq	*%rax
   1462c:      	movq	0x40(%rsp), %rax
   14631:      	cmpq	(%rsp), %rax
   14635:      	je	0x16d4d <generic_fentry_path+0xba6d>
   1463b:      	addq	$0x18, %r15
   1463f:      	movl	$0x4, %eax
   14644:      	leaq	0x30(%rsp), %rdi
   14649:      	movl	$0x8, %esi
   1464e:      	movq	%r15, %rdx
   14651:      	callq	*%rax
   14653:      	movq	(%rsp), %r15
   14657:      	movq	%r15, 0x40(%rsp)
   1465c:      	leaq	0x20(%r15), %rdx
   14660:      	movq	%rdx, 0x38(%rsp)
   14665:      	movq	0x30(%rsp), %r12
   1466a:      	cmpq	0x18(%rsp), %r12
   1466f:      	jne	0x1467c <generic_fentry_path+0x939c>
   14671:      	cmpq	0x20(%rsp), %rdx
   14676:      	je	0x16d4d <generic_fentry_path+0xba6d>
   1467c:      	movl	$0x4, %eax
   14681:      	leaq	0x10(%rsp), %rdi
   14686:      	movl	$0x8, %esi
   1468b:      	callq	*%rax
   1468d:      	cmpq	0x10(%rsp), %r12
   14692:      	je	0x1478a <generic_fentry_path+0x94aa>
   14698:      	leaq	0x18(%r12), %rbx
   1469d:      	movl	$0x4, %eax
   146a2:      	movq	%rbp, %rdi
   146a5:      	movl	$0x8, %esi
   146aa:      	movq	%rbx, %rdx
   146ad:      	callq	*%rax
   146af:      	cmpq	%r12, (%rsp)
   146b3:      	je	0x1478a <generic_fentry_path+0x94aa>
   146b9:      	movl	$0x4, %eax
   146be:      	leaq	0x8(%rsp), %rdi
   146c3:      	movl	$0x8, %esi
   146c8:      	movq	%rbx, %rdx
   146cb:      	callq	*%rax
   146cd:      	addq	$0x20, %r12
   146d1:      	movl	$0x4, %eax
   146d6:      	leaq	0x58(%rsp), %rdi
   146db:      	movl	$0x10, %ecx
   146e0:      	movl	$0x10, %esi
   146e5:      	movq	%r12, %rdx
   146e8:      	callq	*%rax
   146ea:      	movq	0x28(%rsp), %rbx
   146ef:      	movq	0x48(%rsp), %rax
   146f4:      	movl	0x5c(%rsp), %r15d
   146f9:      	subq	%rbx, %rax
   146fc:      	movl	0x50(%rsp), %r12d
   14701:      	movl	%r15d, %edx
   14704:      	subl	%r12d, %edx
   14707:      	movl	$0x0, %ecx
   1470c:      	cmovbl	%ecx, %edx
   1470f:      	addq	0x60(%rsp), %rdx
   14714:      	xorl	%esi, %esi
   14716:      	cmpl	%r15d, %r12d
   14719:      	seta	%sil
   1471d:      	movl	%r15d, %ecx
   14720:      	cmovbl	%r12d, %ecx
   14724:      	addl	%ecx, %esi
   14726:      	movl	%r12d, %edi
   14729:      	subl	%esi, %edi
   1472b:      	movl	%edi, 0x50(%rsp)
   1472f:      	subq	%rsi, %rax
   14732:      	jb	0x16d52 <generic_fentry_path+0xba72>
   14738:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1473e:      	ja	0x16d52 <generic_fentry_path+0xba72>
   14744:      	cmpl	%r15d, %r12d
   14747:      	jbe	0x1474d <generic_fentry_path+0x946d>
   14749:      	movb	$0x2f, (%rbx,%rax)
   1474d:      	xorl	%edi, %edi
   1474f:      	cmpl	%r15d, %r12d
   14752:      	seta	%dil
   14756:      	movzbl	%cl, %esi
   14759:      	addq	%rax, %rbx
   1475c:      	addq	%rbx, %rdi
   1475f:      	movl	$0x4, %eax
   14764:      	callq	*%rax
   14766:      	movq	%rbx, 0x48(%rsp)
   1476b:      	cmpl	%r15d, %r12d
   1476e:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   14774:      	movq	0x8(%rsp), %r12
   14779:      	movq	%r12, 0x30(%rsp)
   1477e:      	movq	0x38(%rsp), %rdx
   14783:      	movq	0x40(%rsp), %r15
   14788:      	jmp	0x147db <generic_fentry_path+0x94fb>
   1478a:      	leaq	0x10(%r15), %rdx
   1478e:      	movl	$0x4, %eax
   14793:      	movq	%rbp, %rdi
   14796:      	movl	$0x8, %esi
   1479b:      	callq	*%rax
   1479d:      	movq	0x40(%rsp), %rax
   147a2:      	cmpq	(%rsp), %rax
   147a6:      	je	0x16d4d <generic_fentry_path+0xba6d>
   147ac:      	addq	$0x18, %r15
   147b0:      	movl	$0x4, %eax
   147b5:      	leaq	0x30(%rsp), %rdi
   147ba:      	movl	$0x8, %esi
   147bf:      	movq	%r15, %rdx
   147c2:      	callq	*%rax
   147c4:      	movq	(%rsp), %r15
   147c8:      	movq	%r15, 0x40(%rsp)
   147cd:      	leaq	0x20(%r15), %rdx
   147d1:      	movq	%rdx, 0x38(%rsp)
   147d6:      	movq	0x30(%rsp), %r12
   147db:      	cmpq	0x18(%rsp), %r12
   147e0:      	jne	0x147ed <generic_fentry_path+0x950d>
   147e2:      	cmpq	0x20(%rsp), %rdx
   147e7:      	je	0x16d4d <generic_fentry_path+0xba6d>
   147ed:      	movl	$0x4, %eax
   147f2:      	leaq	0x10(%rsp), %rdi
   147f7:      	movl	$0x8, %esi
   147fc:      	callq	*%rax
   147fe:      	cmpq	0x10(%rsp), %r12
   14803:      	je	0x148fb <generic_fentry_path+0x961b>
   14809:      	leaq	0x18(%r12), %rbx
   1480e:      	movl	$0x4, %eax
   14813:      	movq	%rbp, %rdi
   14816:      	movl	$0x8, %esi
   1481b:      	movq	%rbx, %rdx
   1481e:      	callq	*%rax
   14820:      	cmpq	%r12, (%rsp)
   14824:      	je	0x148fb <generic_fentry_path+0x961b>
   1482a:      	movl	$0x4, %eax
   1482f:      	leaq	0x8(%rsp), %rdi
   14834:      	movl	$0x8, %esi
   14839:      	movq	%rbx, %rdx
   1483c:      	callq	*%rax
   1483e:      	addq	$0x20, %r12
   14842:      	movl	$0x4, %eax
   14847:      	leaq	0x58(%rsp), %rdi
   1484c:      	movl	$0x10, %ecx
   14851:      	movl	$0x10, %esi
   14856:      	movq	%r12, %rdx
   14859:      	callq	*%rax
   1485b:      	movq	0x28(%rsp), %rbx
   14860:      	movq	0x48(%rsp), %rax
   14865:      	movl	0x5c(%rsp), %r15d
   1486a:      	subq	%rbx, %rax
   1486d:      	movl	0x50(%rsp), %r12d
   14872:      	movl	%r15d, %edx
   14875:      	subl	%r12d, %edx
   14878:      	movl	$0x0, %ecx
   1487d:      	cmovbl	%ecx, %edx
   14880:      	addq	0x60(%rsp), %rdx
   14885:      	xorl	%esi, %esi
   14887:      	cmpl	%r15d, %r12d
   1488a:      	seta	%sil
   1488e:      	movl	%r15d, %ecx
   14891:      	cmovbl	%r12d, %ecx
   14895:      	addl	%ecx, %esi
   14897:      	movl	%r12d, %edi
   1489a:      	subl	%esi, %edi
   1489c:      	movl	%edi, 0x50(%rsp)
   148a0:      	subq	%rsi, %rax
   148a3:      	jb	0x16d52 <generic_fentry_path+0xba72>
   148a9:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   148af:      	ja	0x16d52 <generic_fentry_path+0xba72>
   148b5:      	cmpl	%r15d, %r12d
   148b8:      	jbe	0x148be <generic_fentry_path+0x95de>
   148ba:      	movb	$0x2f, (%rbx,%rax)
   148be:      	xorl	%edi, %edi
   148c0:      	cmpl	%r15d, %r12d
   148c3:      	seta	%dil
   148c7:      	movzbl	%cl, %esi
   148ca:      	addq	%rax, %rbx
   148cd:      	addq	%rbx, %rdi
   148d0:      	movl	$0x4, %eax
   148d5:      	callq	*%rax
   148d7:      	movq	%rbx, 0x48(%rsp)
   148dc:      	cmpl	%r15d, %r12d
   148df:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   148e5:      	movq	0x8(%rsp), %r12
   148ea:      	movq	%r12, 0x30(%rsp)
   148ef:      	movq	0x38(%rsp), %rdx
   148f4:      	movq	0x40(%rsp), %r15
   148f9:      	jmp	0x1494c <generic_fentry_path+0x966c>
   148fb:      	leaq	0x10(%r15), %rdx
   148ff:      	movl	$0x4, %eax
   14904:      	movq	%rbp, %rdi
   14907:      	movl	$0x8, %esi
   1490c:      	callq	*%rax
   1490e:      	movq	0x40(%rsp), %rax
   14913:      	cmpq	(%rsp), %rax
   14917:      	je	0x16d4d <generic_fentry_path+0xba6d>
   1491d:      	addq	$0x18, %r15
   14921:      	movl	$0x4, %eax
   14926:      	leaq	0x30(%rsp), %rdi
   1492b:      	movl	$0x8, %esi
   14930:      	movq	%r15, %rdx
   14933:      	callq	*%rax
   14935:      	movq	(%rsp), %r15
   14939:      	movq	%r15, 0x40(%rsp)
   1493e:      	leaq	0x20(%r15), %rdx
   14942:      	movq	%rdx, 0x38(%rsp)
   14947:      	movq	0x30(%rsp), %r12
   1494c:      	cmpq	0x18(%rsp), %r12
   14951:      	jne	0x1495e <generic_fentry_path+0x967e>
   14953:      	cmpq	0x20(%rsp), %rdx
   14958:      	je	0x16d4d <generic_fentry_path+0xba6d>
   1495e:      	movl	$0x4, %eax
   14963:      	leaq	0x10(%rsp), %rdi
   14968:      	movl	$0x8, %esi
   1496d:      	callq	*%rax
   1496f:      	cmpq	0x10(%rsp), %r12
   14974:      	je	0x14a6c <generic_fentry_path+0x978c>
   1497a:      	leaq	0x18(%r12), %rbx
   1497f:      	movl	$0x4, %eax
   14984:      	movq	%rbp, %rdi
   14987:      	movl	$0x8, %esi
   1498c:      	movq	%rbx, %rdx
   1498f:      	callq	*%rax
   14991:      	cmpq	%r12, (%rsp)
   14995:      	je	0x14a6c <generic_fentry_path+0x978c>
   1499b:      	movl	$0x4, %eax
   149a0:      	leaq	0x8(%rsp), %rdi
   149a5:      	movl	$0x8, %esi
   149aa:      	movq	%rbx, %rdx
   149ad:      	callq	*%rax
   149af:      	addq	$0x20, %r12
   149b3:      	movl	$0x4, %eax
   149b8:      	leaq	0x58(%rsp), %rdi
   149bd:      	movl	$0x10, %ecx
   149c2:      	movl	$0x10, %esi
   149c7:      	movq	%r12, %rdx
   149ca:      	callq	*%rax
   149cc:      	movq	0x28(%rsp), %rbx
   149d1:      	movq	0x48(%rsp), %rax
   149d6:      	movl	0x5c(%rsp), %r15d
   149db:      	subq	%rbx, %rax
   149de:      	movl	0x50(%rsp), %r12d
   149e3:      	movl	%r15d, %edx
   149e6:      	subl	%r12d, %edx
   149e9:      	movl	$0x0, %ecx
   149ee:      	cmovbl	%ecx, %edx
   149f1:      	addq	0x60(%rsp), %rdx
   149f6:      	xorl	%esi, %esi
   149f8:      	cmpl	%r15d, %r12d
   149fb:      	seta	%sil
   149ff:      	movl	%r15d, %ecx
   14a02:      	cmovbl	%r12d, %ecx
   14a06:      	addl	%ecx, %esi
   14a08:      	movl	%r12d, %edi
   14a0b:      	subl	%esi, %edi
   14a0d:      	movl	%edi, 0x50(%rsp)
   14a11:      	subq	%rsi, %rax
   14a14:      	jb	0x16d52 <generic_fentry_path+0xba72>
   14a1a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14a20:      	ja	0x16d52 <generic_fentry_path+0xba72>
   14a26:      	cmpl	%r15d, %r12d
   14a29:      	jbe	0x14a2f <generic_fentry_path+0x974f>
   14a2b:      	movb	$0x2f, (%rbx,%rax)
   14a2f:      	xorl	%edi, %edi
   14a31:      	cmpl	%r15d, %r12d
   14a34:      	seta	%dil
   14a38:      	movzbl	%cl, %esi
   14a3b:      	addq	%rax, %rbx
   14a3e:      	addq	%rbx, %rdi
   14a41:      	movl	$0x4, %eax
   14a46:      	callq	*%rax
   14a48:      	movq	%rbx, 0x48(%rsp)
   14a4d:      	cmpl	%r15d, %r12d
   14a50:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   14a56:      	movq	0x8(%rsp), %r12
   14a5b:      	movq	%r12, 0x30(%rsp)
   14a60:      	movq	0x38(%rsp), %rdx
   14a65:      	movq	0x40(%rsp), %r15
   14a6a:      	jmp	0x14abd <generic_fentry_path+0x97dd>
   14a6c:      	leaq	0x10(%r15), %rdx
   14a70:      	movl	$0x4, %eax
   14a75:      	movq	%rbp, %rdi
   14a78:      	movl	$0x8, %esi
   14a7d:      	callq	*%rax
   14a7f:      	movq	0x40(%rsp), %rax
   14a84:      	cmpq	(%rsp), %rax
   14a88:      	je	0x16d4d <generic_fentry_path+0xba6d>
   14a8e:      	addq	$0x18, %r15
   14a92:      	movl	$0x4, %eax
   14a97:      	leaq	0x30(%rsp), %rdi
   14a9c:      	movl	$0x8, %esi
   14aa1:      	movq	%r15, %rdx
   14aa4:      	callq	*%rax
   14aa6:      	movq	(%rsp), %r15
   14aaa:      	movq	%r15, 0x40(%rsp)
   14aaf:      	leaq	0x20(%r15), %rdx
   14ab3:      	movq	%rdx, 0x38(%rsp)
   14ab8:      	movq	0x30(%rsp), %r12
   14abd:      	cmpq	0x18(%rsp), %r12
   14ac2:      	jne	0x14acf <generic_fentry_path+0x97ef>
   14ac4:      	cmpq	0x20(%rsp), %rdx
   14ac9:      	je	0x16d4d <generic_fentry_path+0xba6d>
   14acf:      	movl	$0x4, %eax
   14ad4:      	leaq	0x10(%rsp), %rdi
   14ad9:      	movl	$0x8, %esi
   14ade:      	callq	*%rax
   14ae0:      	cmpq	0x10(%rsp), %r12
   14ae5:      	je	0x14bdd <generic_fentry_path+0x98fd>
   14aeb:      	leaq	0x18(%r12), %rbx
   14af0:      	movl	$0x4, %eax
   14af5:      	movq	%rbp, %rdi
   14af8:      	movl	$0x8, %esi
   14afd:      	movq	%rbx, %rdx
   14b00:      	callq	*%rax
   14b02:      	cmpq	%r12, (%rsp)
   14b06:      	je	0x14bdd <generic_fentry_path+0x98fd>
   14b0c:      	movl	$0x4, %eax
   14b11:      	leaq	0x8(%rsp), %rdi
   14b16:      	movl	$0x8, %esi
   14b1b:      	movq	%rbx, %rdx
   14b1e:      	callq	*%rax
   14b20:      	addq	$0x20, %r12
   14b24:      	movl	$0x4, %eax
   14b29:      	leaq	0x58(%rsp), %rdi
   14b2e:      	movl	$0x10, %ecx
   14b33:      	movl	$0x10, %esi
   14b38:      	movq	%r12, %rdx
   14b3b:      	callq	*%rax
   14b3d:      	movq	0x28(%rsp), %rbx
   14b42:      	movq	0x48(%rsp), %rax
   14b47:      	movl	0x5c(%rsp), %r15d
   14b4c:      	subq	%rbx, %rax
   14b4f:      	movl	0x50(%rsp), %r12d
   14b54:      	movl	%r15d, %edx
   14b57:      	subl	%r12d, %edx
   14b5a:      	movl	$0x0, %ecx
   14b5f:      	cmovbl	%ecx, %edx
   14b62:      	addq	0x60(%rsp), %rdx
   14b67:      	xorl	%esi, %esi
   14b69:      	cmpl	%r15d, %r12d
   14b6c:      	seta	%sil
   14b70:      	movl	%r15d, %ecx
   14b73:      	cmovbl	%r12d, %ecx
   14b77:      	addl	%ecx, %esi
   14b79:      	movl	%r12d, %edi
   14b7c:      	subl	%esi, %edi
   14b7e:      	movl	%edi, 0x50(%rsp)
   14b82:      	subq	%rsi, %rax
   14b85:      	jb	0x16d52 <generic_fentry_path+0xba72>
   14b8b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14b91:      	ja	0x16d52 <generic_fentry_path+0xba72>
   14b97:      	cmpl	%r15d, %r12d
   14b9a:      	jbe	0x14ba0 <generic_fentry_path+0x98c0>
   14b9c:      	movb	$0x2f, (%rbx,%rax)
   14ba0:      	xorl	%edi, %edi
   14ba2:      	cmpl	%r15d, %r12d
   14ba5:      	seta	%dil
   14ba9:      	movzbl	%cl, %esi
   14bac:      	addq	%rax, %rbx
   14baf:      	addq	%rbx, %rdi
   14bb2:      	movl	$0x4, %eax
   14bb7:      	callq	*%rax
   14bb9:      	movq	%rbx, 0x48(%rsp)
   14bbe:      	cmpl	%r15d, %r12d
   14bc1:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   14bc7:      	movq	0x8(%rsp), %r12
   14bcc:      	movq	%r12, 0x30(%rsp)
   14bd1:      	movq	0x38(%rsp), %rdx
   14bd6:      	movq	0x40(%rsp), %r15
   14bdb:      	jmp	0x14c2e <generic_fentry_path+0x994e>
   14bdd:      	leaq	0x10(%r15), %rdx
   14be1:      	movl	$0x4, %eax
   14be6:      	movq	%rbp, %rdi
   14be9:      	movl	$0x8, %esi
   14bee:      	callq	*%rax
   14bf0:      	movq	0x40(%rsp), %rax
   14bf5:      	cmpq	(%rsp), %rax
   14bf9:      	je	0x16d4d <generic_fentry_path+0xba6d>
   14bff:      	addq	$0x18, %r15
   14c03:      	movl	$0x4, %eax
   14c08:      	leaq	0x30(%rsp), %rdi
   14c0d:      	movl	$0x8, %esi
   14c12:      	movq	%r15, %rdx
   14c15:      	callq	*%rax
   14c17:      	movq	(%rsp), %r15
   14c1b:      	movq	%r15, 0x40(%rsp)
   14c20:      	leaq	0x20(%r15), %rdx
   14c24:      	movq	%rdx, 0x38(%rsp)
   14c29:      	movq	0x30(%rsp), %r12
   14c2e:      	cmpq	0x18(%rsp), %r12
   14c33:      	jne	0x14c40 <generic_fentry_path+0x9960>
   14c35:      	cmpq	0x20(%rsp), %rdx
   14c3a:      	je	0x16d4d <generic_fentry_path+0xba6d>
   14c40:      	movl	$0x4, %eax
   14c45:      	leaq	0x10(%rsp), %rdi
   14c4a:      	movl	$0x8, %esi
   14c4f:      	callq	*%rax
   14c51:      	cmpq	0x10(%rsp), %r12
   14c56:      	je	0x14d4e <generic_fentry_path+0x9a6e>
   14c5c:      	leaq	0x18(%r12), %rbx
   14c61:      	movl	$0x4, %eax
   14c66:      	movq	%rbp, %rdi
   14c69:      	movl	$0x8, %esi
   14c6e:      	movq	%rbx, %rdx
   14c71:      	callq	*%rax
   14c73:      	cmpq	%r12, (%rsp)
   14c77:      	je	0x14d4e <generic_fentry_path+0x9a6e>
   14c7d:      	movl	$0x4, %eax
   14c82:      	leaq	0x8(%rsp), %rdi
   14c87:      	movl	$0x8, %esi
   14c8c:      	movq	%rbx, %rdx
   14c8f:      	callq	*%rax
   14c91:      	addq	$0x20, %r12
   14c95:      	movl	$0x4, %eax
   14c9a:      	leaq	0x58(%rsp), %rdi
   14c9f:      	movl	$0x10, %ecx
   14ca4:      	movl	$0x10, %esi
   14ca9:      	movq	%r12, %rdx
   14cac:      	callq	*%rax
   14cae:      	movq	0x28(%rsp), %rbx
   14cb3:      	movq	0x48(%rsp), %rax
   14cb8:      	movl	0x5c(%rsp), %r15d
   14cbd:      	subq	%rbx, %rax
   14cc0:      	movl	0x50(%rsp), %r12d
   14cc5:      	movl	%r15d, %edx
   14cc8:      	subl	%r12d, %edx
   14ccb:      	movl	$0x0, %ecx
   14cd0:      	cmovbl	%ecx, %edx
   14cd3:      	addq	0x60(%rsp), %rdx
   14cd8:      	xorl	%esi, %esi
   14cda:      	cmpl	%r15d, %r12d
   14cdd:      	seta	%sil
   14ce1:      	movl	%r15d, %ecx
   14ce4:      	cmovbl	%r12d, %ecx
   14ce8:      	addl	%ecx, %esi
   14cea:      	movl	%r12d, %edi
   14ced:      	subl	%esi, %edi
   14cef:      	movl	%edi, 0x50(%rsp)
   14cf3:      	subq	%rsi, %rax
   14cf6:      	jb	0x16d52 <generic_fentry_path+0xba72>
   14cfc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14d02:      	ja	0x16d52 <generic_fentry_path+0xba72>
   14d08:      	cmpl	%r15d, %r12d
   14d0b:      	jbe	0x14d11 <generic_fentry_path+0x9a31>
   14d0d:      	movb	$0x2f, (%rbx,%rax)
   14d11:      	xorl	%edi, %edi
   14d13:      	cmpl	%r15d, %r12d
   14d16:      	seta	%dil
   14d1a:      	movzbl	%cl, %esi
   14d1d:      	addq	%rax, %rbx
   14d20:      	addq	%rbx, %rdi
   14d23:      	movl	$0x4, %eax
   14d28:      	callq	*%rax
   14d2a:      	movq	%rbx, 0x48(%rsp)
   14d2f:      	cmpl	%r15d, %r12d
   14d32:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   14d38:      	movq	0x8(%rsp), %r12
   14d3d:      	movq	%r12, 0x30(%rsp)
   14d42:      	movq	0x38(%rsp), %rdx
   14d47:      	movq	0x40(%rsp), %r15
   14d4c:      	jmp	0x14d9f <generic_fentry_path+0x9abf>
   14d4e:      	leaq	0x10(%r15), %rdx
   14d52:      	movl	$0x4, %eax
   14d57:      	movq	%rbp, %rdi
   14d5a:      	movl	$0x8, %esi
   14d5f:      	callq	*%rax
   14d61:      	movq	0x40(%rsp), %rax
   14d66:      	cmpq	(%rsp), %rax
   14d6a:      	je	0x16d4d <generic_fentry_path+0xba6d>
   14d70:      	addq	$0x18, %r15
   14d74:      	movl	$0x4, %eax
   14d79:      	leaq	0x30(%rsp), %rdi
   14d7e:      	movl	$0x8, %esi
   14d83:      	movq	%r15, %rdx
   14d86:      	callq	*%rax
   14d88:      	movq	(%rsp), %r15
   14d8c:      	movq	%r15, 0x40(%rsp)
   14d91:      	leaq	0x20(%r15), %rdx
   14d95:      	movq	%rdx, 0x38(%rsp)
   14d9a:      	movq	0x30(%rsp), %r12
   14d9f:      	cmpq	0x18(%rsp), %r12
   14da4:      	jne	0x14db1 <generic_fentry_path+0x9ad1>
   14da6:      	cmpq	0x20(%rsp), %rdx
   14dab:      	je	0x16d4d <generic_fentry_path+0xba6d>
   14db1:      	movl	$0x4, %eax
   14db6:      	leaq	0x10(%rsp), %rdi
   14dbb:      	movl	$0x8, %esi
   14dc0:      	callq	*%rax
   14dc2:      	cmpq	0x10(%rsp), %r12
   14dc7:      	je	0x14ebf <generic_fentry_path+0x9bdf>
   14dcd:      	leaq	0x18(%r12), %rbx
   14dd2:      	movl	$0x4, %eax
   14dd7:      	movq	%rbp, %rdi
   14dda:      	movl	$0x8, %esi
   14ddf:      	movq	%rbx, %rdx
   14de2:      	callq	*%rax
   14de4:      	cmpq	%r12, (%rsp)
   14de8:      	je	0x14ebf <generic_fentry_path+0x9bdf>
   14dee:      	movl	$0x4, %eax
   14df3:      	leaq	0x8(%rsp), %rdi
   14df8:      	movl	$0x8, %esi
   14dfd:      	movq	%rbx, %rdx
   14e00:      	callq	*%rax
   14e02:      	addq	$0x20, %r12
   14e06:      	movl	$0x4, %eax
   14e0b:      	leaq	0x58(%rsp), %rdi
   14e10:      	movl	$0x10, %ecx
   14e15:      	movl	$0x10, %esi
   14e1a:      	movq	%r12, %rdx
   14e1d:      	callq	*%rax
   14e1f:      	movq	0x28(%rsp), %rbx
   14e24:      	movq	0x48(%rsp), %rax
   14e29:      	movl	0x5c(%rsp), %r15d
   14e2e:      	subq	%rbx, %rax
   14e31:      	movl	0x50(%rsp), %r12d
   14e36:      	movl	%r15d, %edx
   14e39:      	subl	%r12d, %edx
   14e3c:      	movl	$0x0, %ecx
   14e41:      	cmovbl	%ecx, %edx
   14e44:      	addq	0x60(%rsp), %rdx
   14e49:      	xorl	%esi, %esi
   14e4b:      	cmpl	%r15d, %r12d
   14e4e:      	seta	%sil
   14e52:      	movl	%r15d, %ecx
   14e55:      	cmovbl	%r12d, %ecx
   14e59:      	addl	%ecx, %esi
   14e5b:      	movl	%r12d, %edi
   14e5e:      	subl	%esi, %edi
   14e60:      	movl	%edi, 0x50(%rsp)
   14e64:      	subq	%rsi, %rax
   14e67:      	jb	0x16d52 <generic_fentry_path+0xba72>
   14e6d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14e73:      	ja	0x16d52 <generic_fentry_path+0xba72>
   14e79:      	cmpl	%r15d, %r12d
   14e7c:      	jbe	0x14e82 <generic_fentry_path+0x9ba2>
   14e7e:      	movb	$0x2f, (%rbx,%rax)
   14e82:      	xorl	%edi, %edi
   14e84:      	cmpl	%r15d, %r12d
   14e87:      	seta	%dil
   14e8b:      	movzbl	%cl, %esi
   14e8e:      	addq	%rax, %rbx
   14e91:      	addq	%rbx, %rdi
   14e94:      	movl	$0x4, %eax
   14e99:      	callq	*%rax
   14e9b:      	movq	%rbx, 0x48(%rsp)
   14ea0:      	cmpl	%r15d, %r12d
   14ea3:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   14ea9:      	movq	0x8(%rsp), %r12
   14eae:      	movq	%r12, 0x30(%rsp)
   14eb3:      	movq	0x38(%rsp), %rdx
   14eb8:      	movq	0x40(%rsp), %r15
   14ebd:      	jmp	0x14f10 <generic_fentry_path+0x9c30>
   14ebf:      	leaq	0x10(%r15), %rdx
   14ec3:      	movl	$0x4, %eax
   14ec8:      	movq	%rbp, %rdi
   14ecb:      	movl	$0x8, %esi
   14ed0:      	callq	*%rax
   14ed2:      	movq	0x40(%rsp), %rax
   14ed7:      	cmpq	(%rsp), %rax
   14edb:      	je	0x16d4d <generic_fentry_path+0xba6d>
   14ee1:      	addq	$0x18, %r15
   14ee5:      	movl	$0x4, %eax
   14eea:      	leaq	0x30(%rsp), %rdi
   14eef:      	movl	$0x8, %esi
   14ef4:      	movq	%r15, %rdx
   14ef7:      	callq	*%rax
   14ef9:      	movq	(%rsp), %r15
   14efd:      	movq	%r15, 0x40(%rsp)
   14f02:      	leaq	0x20(%r15), %rdx
   14f06:      	movq	%rdx, 0x38(%rsp)
   14f0b:      	movq	0x30(%rsp), %r12
   14f10:      	cmpq	0x18(%rsp), %r12
   14f15:      	jne	0x14f22 <generic_fentry_path+0x9c42>
   14f17:      	cmpq	0x20(%rsp), %rdx
   14f1c:      	je	0x16d4d <generic_fentry_path+0xba6d>
   14f22:      	movl	$0x4, %eax
   14f27:      	leaq	0x10(%rsp), %rdi
   14f2c:      	movl	$0x8, %esi
   14f31:      	callq	*%rax
   14f33:      	cmpq	0x10(%rsp), %r12
   14f38:      	je	0x15030 <generic_fentry_path+0x9d50>
   14f3e:      	leaq	0x18(%r12), %rbx
   14f43:      	movl	$0x4, %eax
   14f48:      	movq	%rbp, %rdi
   14f4b:      	movl	$0x8, %esi
   14f50:      	movq	%rbx, %rdx
   14f53:      	callq	*%rax
   14f55:      	cmpq	%r12, (%rsp)
   14f59:      	je	0x15030 <generic_fentry_path+0x9d50>
   14f5f:      	movl	$0x4, %eax
   14f64:      	leaq	0x8(%rsp), %rdi
   14f69:      	movl	$0x8, %esi
   14f6e:      	movq	%rbx, %rdx
   14f71:      	callq	*%rax
   14f73:      	addq	$0x20, %r12
   14f77:      	movl	$0x4, %eax
   14f7c:      	leaq	0x58(%rsp), %rdi
   14f81:      	movl	$0x10, %ecx
   14f86:      	movl	$0x10, %esi
   14f8b:      	movq	%r12, %rdx
   14f8e:      	callq	*%rax
   14f90:      	movq	0x28(%rsp), %rbx
   14f95:      	movq	0x48(%rsp), %rax
   14f9a:      	movl	0x5c(%rsp), %r15d
   14f9f:      	subq	%rbx, %rax
   14fa2:      	movl	0x50(%rsp), %r12d
   14fa7:      	movl	%r15d, %edx
   14faa:      	subl	%r12d, %edx
   14fad:      	movl	$0x0, %ecx
   14fb2:      	cmovbl	%ecx, %edx
   14fb5:      	addq	0x60(%rsp), %rdx
   14fba:      	xorl	%esi, %esi
   14fbc:      	cmpl	%r15d, %r12d
   14fbf:      	seta	%sil
   14fc3:      	movl	%r15d, %ecx
   14fc6:      	cmovbl	%r12d, %ecx
   14fca:      	addl	%ecx, %esi
   14fcc:      	movl	%r12d, %edi
   14fcf:      	subl	%esi, %edi
   14fd1:      	movl	%edi, 0x50(%rsp)
   14fd5:      	subq	%rsi, %rax
   14fd8:      	jb	0x16d52 <generic_fentry_path+0xba72>
   14fde:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14fe4:      	ja	0x16d52 <generic_fentry_path+0xba72>
   14fea:      	cmpl	%r15d, %r12d
   14fed:      	jbe	0x14ff3 <generic_fentry_path+0x9d13>
   14fef:      	movb	$0x2f, (%rbx,%rax)
   14ff3:      	xorl	%edi, %edi
   14ff5:      	cmpl	%r15d, %r12d
   14ff8:      	seta	%dil
   14ffc:      	movzbl	%cl, %esi
   14fff:      	addq	%rax, %rbx
   15002:      	addq	%rbx, %rdi
   15005:      	movl	$0x4, %eax
   1500a:      	callq	*%rax
   1500c:      	movq	%rbx, 0x48(%rsp)
   15011:      	cmpl	%r15d, %r12d
   15014:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   1501a:      	movq	0x8(%rsp), %r12
   1501f:      	movq	%r12, 0x30(%rsp)
   15024:      	movq	0x38(%rsp), %rdx
   15029:      	movq	0x40(%rsp), %r15
   1502e:      	jmp	0x15081 <generic_fentry_path+0x9da1>
   15030:      	leaq	0x10(%r15), %rdx
   15034:      	movl	$0x4, %eax
   15039:      	movq	%rbp, %rdi
   1503c:      	movl	$0x8, %esi
   15041:      	callq	*%rax
   15043:      	movq	0x40(%rsp), %rax
   15048:      	cmpq	(%rsp), %rax
   1504c:      	je	0x16d4d <generic_fentry_path+0xba6d>
   15052:      	addq	$0x18, %r15
   15056:      	movl	$0x4, %eax
   1505b:      	leaq	0x30(%rsp), %rdi
   15060:      	movl	$0x8, %esi
   15065:      	movq	%r15, %rdx
   15068:      	callq	*%rax
   1506a:      	movq	(%rsp), %r15
   1506e:      	movq	%r15, 0x40(%rsp)
   15073:      	leaq	0x20(%r15), %rdx
   15077:      	movq	%rdx, 0x38(%rsp)
   1507c:      	movq	0x30(%rsp), %r12
   15081:      	cmpq	0x18(%rsp), %r12
   15086:      	jne	0x15093 <generic_fentry_path+0x9db3>
   15088:      	cmpq	0x20(%rsp), %rdx
   1508d:      	je	0x16d4d <generic_fentry_path+0xba6d>
   15093:      	movl	$0x4, %eax
   15098:      	leaq	0x10(%rsp), %rdi
   1509d:      	movl	$0x8, %esi
   150a2:      	callq	*%rax
   150a4:      	cmpq	0x10(%rsp), %r12
   150a9:      	je	0x151a1 <generic_fentry_path+0x9ec1>
   150af:      	leaq	0x18(%r12), %rbx
   150b4:      	movl	$0x4, %eax
   150b9:      	movq	%rbp, %rdi
   150bc:      	movl	$0x8, %esi
   150c1:      	movq	%rbx, %rdx
   150c4:      	callq	*%rax
   150c6:      	cmpq	%r12, (%rsp)
   150ca:      	je	0x151a1 <generic_fentry_path+0x9ec1>
   150d0:      	movl	$0x4, %eax
   150d5:      	leaq	0x8(%rsp), %rdi
   150da:      	movl	$0x8, %esi
   150df:      	movq	%rbx, %rdx
   150e2:      	callq	*%rax
   150e4:      	addq	$0x20, %r12
   150e8:      	movl	$0x4, %eax
   150ed:      	leaq	0x58(%rsp), %rdi
   150f2:      	movl	$0x10, %ecx
   150f7:      	movl	$0x10, %esi
   150fc:      	movq	%r12, %rdx
   150ff:      	callq	*%rax
   15101:      	movq	0x28(%rsp), %rbx
   15106:      	movq	0x48(%rsp), %rax
   1510b:      	movl	0x5c(%rsp), %r15d
   15110:      	subq	%rbx, %rax
   15113:      	movl	0x50(%rsp), %r12d
   15118:      	movl	%r15d, %edx
   1511b:      	subl	%r12d, %edx
   1511e:      	movl	$0x0, %ecx
   15123:      	cmovbl	%ecx, %edx
   15126:      	addq	0x60(%rsp), %rdx
   1512b:      	xorl	%esi, %esi
   1512d:      	cmpl	%r15d, %r12d
   15130:      	seta	%sil
   15134:      	movl	%r15d, %ecx
   15137:      	cmovbl	%r12d, %ecx
   1513b:      	addl	%ecx, %esi
   1513d:      	movl	%r12d, %edi
   15140:      	subl	%esi, %edi
   15142:      	movl	%edi, 0x50(%rsp)
   15146:      	subq	%rsi, %rax
   15149:      	jb	0x16d52 <generic_fentry_path+0xba72>
   1514f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15155:      	ja	0x16d52 <generic_fentry_path+0xba72>
   1515b:      	cmpl	%r15d, %r12d
   1515e:      	jbe	0x15164 <generic_fentry_path+0x9e84>
   15160:      	movb	$0x2f, (%rbx,%rax)
   15164:      	xorl	%edi, %edi
   15166:      	cmpl	%r15d, %r12d
   15169:      	seta	%dil
   1516d:      	movzbl	%cl, %esi
   15170:      	addq	%rax, %rbx
   15173:      	addq	%rbx, %rdi
   15176:      	movl	$0x4, %eax
   1517b:      	callq	*%rax
   1517d:      	movq	%rbx, 0x48(%rsp)
   15182:      	cmpl	%r15d, %r12d
   15185:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   1518b:      	movq	0x8(%rsp), %r12
   15190:      	movq	%r12, 0x30(%rsp)
   15195:      	movq	0x38(%rsp), %rdx
   1519a:      	movq	0x40(%rsp), %r15
   1519f:      	jmp	0x151f2 <generic_fentry_path+0x9f12>
   151a1:      	leaq	0x10(%r15), %rdx
   151a5:      	movl	$0x4, %eax
   151aa:      	movq	%rbp, %rdi
   151ad:      	movl	$0x8, %esi
   151b2:      	callq	*%rax
   151b4:      	movq	0x40(%rsp), %rax
   151b9:      	cmpq	(%rsp), %rax
   151bd:      	je	0x16d4d <generic_fentry_path+0xba6d>
   151c3:      	addq	$0x18, %r15
   151c7:      	movl	$0x4, %eax
   151cc:      	leaq	0x30(%rsp), %rdi
   151d1:      	movl	$0x8, %esi
   151d6:      	movq	%r15, %rdx
   151d9:      	callq	*%rax
   151db:      	movq	(%rsp), %r15
   151df:      	movq	%r15, 0x40(%rsp)
   151e4:      	leaq	0x20(%r15), %rdx
   151e8:      	movq	%rdx, 0x38(%rsp)
   151ed:      	movq	0x30(%rsp), %r12
   151f2:      	cmpq	0x18(%rsp), %r12
   151f7:      	jne	0x15204 <generic_fentry_path+0x9f24>
   151f9:      	cmpq	0x20(%rsp), %rdx
   151fe:      	je	0x16d4d <generic_fentry_path+0xba6d>
   15204:      	movl	$0x4, %eax
   15209:      	leaq	0x10(%rsp), %rdi
   1520e:      	movl	$0x8, %esi
   15213:      	callq	*%rax
   15215:      	cmpq	0x10(%rsp), %r12
   1521a:      	je	0x15312 <generic_fentry_path+0xa032>
   15220:      	leaq	0x18(%r12), %rbx
   15225:      	movl	$0x4, %eax
   1522a:      	movq	%rbp, %rdi
   1522d:      	movl	$0x8, %esi
   15232:      	movq	%rbx, %rdx
   15235:      	callq	*%rax
   15237:      	cmpq	%r12, (%rsp)
   1523b:      	je	0x15312 <generic_fentry_path+0xa032>
   15241:      	movl	$0x4, %eax
   15246:      	leaq	0x8(%rsp), %rdi
   1524b:      	movl	$0x8, %esi
   15250:      	movq	%rbx, %rdx
   15253:      	callq	*%rax
   15255:      	addq	$0x20, %r12
   15259:      	movl	$0x4, %eax
   1525e:      	leaq	0x58(%rsp), %rdi
   15263:      	movl	$0x10, %ecx
   15268:      	movl	$0x10, %esi
   1526d:      	movq	%r12, %rdx
   15270:      	callq	*%rax
   15272:      	movq	0x28(%rsp), %rbx
   15277:      	movq	0x48(%rsp), %rax
   1527c:      	movl	0x5c(%rsp), %r15d
   15281:      	subq	%rbx, %rax
   15284:      	movl	0x50(%rsp), %r12d
   15289:      	movl	%r15d, %edx
   1528c:      	subl	%r12d, %edx
   1528f:      	movl	$0x0, %ecx
   15294:      	cmovbl	%ecx, %edx
   15297:      	addq	0x60(%rsp), %rdx
   1529c:      	xorl	%esi, %esi
   1529e:      	cmpl	%r15d, %r12d
   152a1:      	seta	%sil
   152a5:      	movl	%r15d, %ecx
   152a8:      	cmovbl	%r12d, %ecx
   152ac:      	addl	%ecx, %esi
   152ae:      	movl	%r12d, %edi
   152b1:      	subl	%esi, %edi
   152b3:      	movl	%edi, 0x50(%rsp)
   152b7:      	subq	%rsi, %rax
   152ba:      	jb	0x16d52 <generic_fentry_path+0xba72>
   152c0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   152c6:      	ja	0x16d52 <generic_fentry_path+0xba72>
   152cc:      	cmpl	%r15d, %r12d
   152cf:      	jbe	0x152d5 <generic_fentry_path+0x9ff5>
   152d1:      	movb	$0x2f, (%rbx,%rax)
   152d5:      	xorl	%edi, %edi
   152d7:      	cmpl	%r15d, %r12d
   152da:      	seta	%dil
   152de:      	movzbl	%cl, %esi
   152e1:      	addq	%rax, %rbx
   152e4:      	addq	%rbx, %rdi
   152e7:      	movl	$0x4, %eax
   152ec:      	callq	*%rax
   152ee:      	movq	%rbx, 0x48(%rsp)
   152f3:      	cmpl	%r15d, %r12d
   152f6:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   152fc:      	movq	0x8(%rsp), %r12
   15301:      	movq	%r12, 0x30(%rsp)
   15306:      	movq	0x38(%rsp), %rdx
   1530b:      	movq	0x40(%rsp), %r15
   15310:      	jmp	0x15363 <generic_fentry_path+0xa083>
   15312:      	leaq	0x10(%r15), %rdx
   15316:      	movl	$0x4, %eax
   1531b:      	movq	%rbp, %rdi
   1531e:      	movl	$0x8, %esi
   15323:      	callq	*%rax
   15325:      	movq	0x40(%rsp), %rax
   1532a:      	cmpq	(%rsp), %rax
   1532e:      	je	0x16d4d <generic_fentry_path+0xba6d>
   15334:      	addq	$0x18, %r15
   15338:      	movl	$0x4, %eax
   1533d:      	leaq	0x30(%rsp), %rdi
   15342:      	movl	$0x8, %esi
   15347:      	movq	%r15, %rdx
   1534a:      	callq	*%rax
   1534c:      	movq	(%rsp), %r15
   15350:      	movq	%r15, 0x40(%rsp)
   15355:      	leaq	0x20(%r15), %rdx
   15359:      	movq	%rdx, 0x38(%rsp)
   1535e:      	movq	0x30(%rsp), %r12
   15363:      	cmpq	0x18(%rsp), %r12
   15368:      	jne	0x15375 <generic_fentry_path+0xa095>
   1536a:      	cmpq	0x20(%rsp), %rdx
   1536f:      	je	0x16d4d <generic_fentry_path+0xba6d>
   15375:      	movl	$0x4, %eax
   1537a:      	leaq	0x10(%rsp), %rdi
   1537f:      	movl	$0x8, %esi
   15384:      	callq	*%rax
   15386:      	cmpq	0x10(%rsp), %r12
   1538b:      	je	0x15483 <generic_fentry_path+0xa1a3>
   15391:      	leaq	0x18(%r12), %rbx
   15396:      	movl	$0x4, %eax
   1539b:      	movq	%rbp, %rdi
   1539e:      	movl	$0x8, %esi
   153a3:      	movq	%rbx, %rdx
   153a6:      	callq	*%rax
   153a8:      	cmpq	%r12, (%rsp)
   153ac:      	je	0x15483 <generic_fentry_path+0xa1a3>
   153b2:      	movl	$0x4, %eax
   153b7:      	leaq	0x8(%rsp), %rdi
   153bc:      	movl	$0x8, %esi
   153c1:      	movq	%rbx, %rdx
   153c4:      	callq	*%rax
   153c6:      	addq	$0x20, %r12
   153ca:      	movl	$0x4, %eax
   153cf:      	leaq	0x58(%rsp), %rdi
   153d4:      	movl	$0x10, %ecx
   153d9:      	movl	$0x10, %esi
   153de:      	movq	%r12, %rdx
   153e1:      	callq	*%rax
   153e3:      	movq	0x28(%rsp), %rbx
   153e8:      	movq	0x48(%rsp), %rax
   153ed:      	movl	0x5c(%rsp), %r15d
   153f2:      	subq	%rbx, %rax
   153f5:      	movl	0x50(%rsp), %r12d
   153fa:      	movl	%r15d, %edx
   153fd:      	subl	%r12d, %edx
   15400:      	movl	$0x0, %ecx
   15405:      	cmovbl	%ecx, %edx
   15408:      	addq	0x60(%rsp), %rdx
   1540d:      	xorl	%esi, %esi
   1540f:      	cmpl	%r15d, %r12d
   15412:      	seta	%sil
   15416:      	movl	%r15d, %ecx
   15419:      	cmovbl	%r12d, %ecx
   1541d:      	addl	%ecx, %esi
   1541f:      	movl	%r12d, %edi
   15422:      	subl	%esi, %edi
   15424:      	movl	%edi, 0x50(%rsp)
   15428:      	subq	%rsi, %rax
   1542b:      	jb	0x16d52 <generic_fentry_path+0xba72>
   15431:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15437:      	ja	0x16d52 <generic_fentry_path+0xba72>
   1543d:      	cmpl	%r15d, %r12d
   15440:      	jbe	0x15446 <generic_fentry_path+0xa166>
   15442:      	movb	$0x2f, (%rbx,%rax)
   15446:      	xorl	%edi, %edi
   15448:      	cmpl	%r15d, %r12d
   1544b:      	seta	%dil
   1544f:      	movzbl	%cl, %esi
   15452:      	addq	%rax, %rbx
   15455:      	addq	%rbx, %rdi
   15458:      	movl	$0x4, %eax
   1545d:      	callq	*%rax
   1545f:      	movq	%rbx, 0x48(%rsp)
   15464:      	cmpl	%r15d, %r12d
   15467:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   1546d:      	movq	0x8(%rsp), %r12
   15472:      	movq	%r12, 0x30(%rsp)
   15477:      	movq	0x38(%rsp), %rdx
   1547c:      	movq	0x40(%rsp), %r15
   15481:      	jmp	0x154d4 <generic_fentry_path+0xa1f4>
   15483:      	leaq	0x10(%r15), %rdx
   15487:      	movl	$0x4, %eax
   1548c:      	movq	%rbp, %rdi
   1548f:      	movl	$0x8, %esi
   15494:      	callq	*%rax
   15496:      	movq	0x40(%rsp), %rax
   1549b:      	cmpq	(%rsp), %rax
   1549f:      	je	0x16d4d <generic_fentry_path+0xba6d>
   154a5:      	addq	$0x18, %r15
   154a9:      	movl	$0x4, %eax
   154ae:      	leaq	0x30(%rsp), %rdi
   154b3:      	movl	$0x8, %esi
   154b8:      	movq	%r15, %rdx
   154bb:      	callq	*%rax
   154bd:      	movq	(%rsp), %r15
   154c1:      	movq	%r15, 0x40(%rsp)
   154c6:      	leaq	0x20(%r15), %rdx
   154ca:      	movq	%rdx, 0x38(%rsp)
   154cf:      	movq	0x30(%rsp), %r12
   154d4:      	cmpq	0x18(%rsp), %r12
   154d9:      	jne	0x154e6 <generic_fentry_path+0xa206>
   154db:      	cmpq	0x20(%rsp), %rdx
   154e0:      	je	0x16d4d <generic_fentry_path+0xba6d>
   154e6:      	movl	$0x4, %eax
   154eb:      	leaq	0x10(%rsp), %rdi
   154f0:      	movl	$0x8, %esi
   154f5:      	callq	*%rax
   154f7:      	cmpq	0x10(%rsp), %r12
   154fc:      	je	0x155f4 <generic_fentry_path+0xa314>
   15502:      	leaq	0x18(%r12), %rbx
   15507:      	movl	$0x4, %eax
   1550c:      	movq	%rbp, %rdi
   1550f:      	movl	$0x8, %esi
   15514:      	movq	%rbx, %rdx
   15517:      	callq	*%rax
   15519:      	cmpq	%r12, (%rsp)
   1551d:      	je	0x155f4 <generic_fentry_path+0xa314>
   15523:      	movl	$0x4, %eax
   15528:      	leaq	0x8(%rsp), %rdi
   1552d:      	movl	$0x8, %esi
   15532:      	movq	%rbx, %rdx
   15535:      	callq	*%rax
   15537:      	addq	$0x20, %r12
   1553b:      	movl	$0x4, %eax
   15540:      	leaq	0x58(%rsp), %rdi
   15545:      	movl	$0x10, %ecx
   1554a:      	movl	$0x10, %esi
   1554f:      	movq	%r12, %rdx
   15552:      	callq	*%rax
   15554:      	movq	0x28(%rsp), %rbx
   15559:      	movq	0x48(%rsp), %rax
   1555e:      	movl	0x5c(%rsp), %r15d
   15563:      	subq	%rbx, %rax
   15566:      	movl	0x50(%rsp), %r12d
   1556b:      	movl	%r15d, %edx
   1556e:      	subl	%r12d, %edx
   15571:      	movl	$0x0, %ecx
   15576:      	cmovbl	%ecx, %edx
   15579:      	addq	0x60(%rsp), %rdx
   1557e:      	xorl	%esi, %esi
   15580:      	cmpl	%r15d, %r12d
   15583:      	seta	%sil
   15587:      	movl	%r15d, %ecx
   1558a:      	cmovbl	%r12d, %ecx
   1558e:      	addl	%ecx, %esi
   15590:      	movl	%r12d, %edi
   15593:      	subl	%esi, %edi
   15595:      	movl	%edi, 0x50(%rsp)
   15599:      	subq	%rsi, %rax
   1559c:      	jb	0x16d52 <generic_fentry_path+0xba72>
   155a2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   155a8:      	ja	0x16d52 <generic_fentry_path+0xba72>
   155ae:      	cmpl	%r15d, %r12d
   155b1:      	jbe	0x155b7 <generic_fentry_path+0xa2d7>
   155b3:      	movb	$0x2f, (%rbx,%rax)
   155b7:      	xorl	%edi, %edi
   155b9:      	cmpl	%r15d, %r12d
   155bc:      	seta	%dil
   155c0:      	movzbl	%cl, %esi
   155c3:      	addq	%rax, %rbx
   155c6:      	addq	%rbx, %rdi
   155c9:      	movl	$0x4, %eax
   155ce:      	callq	*%rax
   155d0:      	movq	%rbx, 0x48(%rsp)
   155d5:      	cmpl	%r15d, %r12d
   155d8:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   155de:      	movq	0x8(%rsp), %r12
   155e3:      	movq	%r12, 0x30(%rsp)
   155e8:      	movq	0x38(%rsp), %rdx
   155ed:      	movq	0x40(%rsp), %r15
   155f2:      	jmp	0x15645 <generic_fentry_path+0xa365>
   155f4:      	leaq	0x10(%r15), %rdx
   155f8:      	movl	$0x4, %eax
   155fd:      	movq	%rbp, %rdi
   15600:      	movl	$0x8, %esi
   15605:      	callq	*%rax
   15607:      	movq	0x40(%rsp), %rax
   1560c:      	cmpq	(%rsp), %rax
   15610:      	je	0x16d4d <generic_fentry_path+0xba6d>
   15616:      	addq	$0x18, %r15
   1561a:      	movl	$0x4, %eax
   1561f:      	leaq	0x30(%rsp), %rdi
   15624:      	movl	$0x8, %esi
   15629:      	movq	%r15, %rdx
   1562c:      	callq	*%rax
   1562e:      	movq	(%rsp), %r15
   15632:      	movq	%r15, 0x40(%rsp)
   15637:      	leaq	0x20(%r15), %rdx
   1563b:      	movq	%rdx, 0x38(%rsp)
   15640:      	movq	0x30(%rsp), %r12
   15645:      	cmpq	0x18(%rsp), %r12
   1564a:      	jne	0x15657 <generic_fentry_path+0xa377>
   1564c:      	cmpq	0x20(%rsp), %rdx
   15651:      	je	0x16d4d <generic_fentry_path+0xba6d>
   15657:      	movl	$0x4, %eax
   1565c:      	leaq	0x10(%rsp), %rdi
   15661:      	movl	$0x8, %esi
   15666:      	callq	*%rax
   15668:      	cmpq	0x10(%rsp), %r12
   1566d:      	je	0x15765 <generic_fentry_path+0xa485>
   15673:      	leaq	0x18(%r12), %rbx
   15678:      	movl	$0x4, %eax
   1567d:      	movq	%rbp, %rdi
   15680:      	movl	$0x8, %esi
   15685:      	movq	%rbx, %rdx
   15688:      	callq	*%rax
   1568a:      	cmpq	%r12, (%rsp)
   1568e:      	je	0x15765 <generic_fentry_path+0xa485>
   15694:      	movl	$0x4, %eax
   15699:      	leaq	0x8(%rsp), %rdi
   1569e:      	movl	$0x8, %esi
   156a3:      	movq	%rbx, %rdx
   156a6:      	callq	*%rax
   156a8:      	addq	$0x20, %r12
   156ac:      	movl	$0x4, %eax
   156b1:      	leaq	0x58(%rsp), %rdi
   156b6:      	movl	$0x10, %ecx
   156bb:      	movl	$0x10, %esi
   156c0:      	movq	%r12, %rdx
   156c3:      	callq	*%rax
   156c5:      	movq	0x28(%rsp), %rbx
   156ca:      	movq	0x48(%rsp), %rax
   156cf:      	movl	0x5c(%rsp), %r15d
   156d4:      	subq	%rbx, %rax
   156d7:      	movl	0x50(%rsp), %r12d
   156dc:      	movl	%r15d, %edx
   156df:      	subl	%r12d, %edx
   156e2:      	movl	$0x0, %ecx
   156e7:      	cmovbl	%ecx, %edx
   156ea:      	addq	0x60(%rsp), %rdx
   156ef:      	xorl	%esi, %esi
   156f1:      	cmpl	%r15d, %r12d
   156f4:      	seta	%sil
   156f8:      	movl	%r15d, %ecx
   156fb:      	cmovbl	%r12d, %ecx
   156ff:      	addl	%ecx, %esi
   15701:      	movl	%r12d, %edi
   15704:      	subl	%esi, %edi
   15706:      	movl	%edi, 0x50(%rsp)
   1570a:      	subq	%rsi, %rax
   1570d:      	jb	0x16d52 <generic_fentry_path+0xba72>
   15713:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15719:      	ja	0x16d52 <generic_fentry_path+0xba72>
   1571f:      	cmpl	%r15d, %r12d
   15722:      	jbe	0x15728 <generic_fentry_path+0xa448>
   15724:      	movb	$0x2f, (%rbx,%rax)
   15728:      	xorl	%edi, %edi
   1572a:      	cmpl	%r15d, %r12d
   1572d:      	seta	%dil
   15731:      	movzbl	%cl, %esi
   15734:      	addq	%rax, %rbx
   15737:      	addq	%rbx, %rdi
   1573a:      	movl	$0x4, %eax
   1573f:      	callq	*%rax
   15741:      	movq	%rbx, 0x48(%rsp)
   15746:      	cmpl	%r15d, %r12d
   15749:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   1574f:      	movq	0x8(%rsp), %r12
   15754:      	movq	%r12, 0x30(%rsp)
   15759:      	movq	0x38(%rsp), %rdx
   1575e:      	movq	0x40(%rsp), %r15
   15763:      	jmp	0x157b6 <generic_fentry_path+0xa4d6>
   15765:      	leaq	0x10(%r15), %rdx
   15769:      	movl	$0x4, %eax
   1576e:      	movq	%rbp, %rdi
   15771:      	movl	$0x8, %esi
   15776:      	callq	*%rax
   15778:      	movq	0x40(%rsp), %rax
   1577d:      	cmpq	(%rsp), %rax
   15781:      	je	0x16d4d <generic_fentry_path+0xba6d>
   15787:      	addq	$0x18, %r15
   1578b:      	movl	$0x4, %eax
   15790:      	leaq	0x30(%rsp), %rdi
   15795:      	movl	$0x8, %esi
   1579a:      	movq	%r15, %rdx
   1579d:      	callq	*%rax
   1579f:      	movq	(%rsp), %r15
   157a3:      	movq	%r15, 0x40(%rsp)
   157a8:      	leaq	0x20(%r15), %rdx
   157ac:      	movq	%rdx, 0x38(%rsp)
   157b1:      	movq	0x30(%rsp), %r12
   157b6:      	cmpq	0x18(%rsp), %r12
   157bb:      	jne	0x157c8 <generic_fentry_path+0xa4e8>
   157bd:      	cmpq	0x20(%rsp), %rdx
   157c2:      	je	0x16d4d <generic_fentry_path+0xba6d>
   157c8:      	movl	$0x4, %eax
   157cd:      	leaq	0x10(%rsp), %rdi
   157d2:      	movl	$0x8, %esi
   157d7:      	callq	*%rax
   157d9:      	cmpq	0x10(%rsp), %r12
   157de:      	je	0x158d6 <generic_fentry_path+0xa5f6>
   157e4:      	leaq	0x18(%r12), %rbx
   157e9:      	movl	$0x4, %eax
   157ee:      	movq	%rbp, %rdi
   157f1:      	movl	$0x8, %esi
   157f6:      	movq	%rbx, %rdx
   157f9:      	callq	*%rax
   157fb:      	cmpq	%r12, (%rsp)
   157ff:      	je	0x158d6 <generic_fentry_path+0xa5f6>
   15805:      	movl	$0x4, %eax
   1580a:      	leaq	0x8(%rsp), %rdi
   1580f:      	movl	$0x8, %esi
   15814:      	movq	%rbx, %rdx
   15817:      	callq	*%rax
   15819:      	addq	$0x20, %r12
   1581d:      	movl	$0x4, %eax
   15822:      	leaq	0x58(%rsp), %rdi
   15827:      	movl	$0x10, %ecx
   1582c:      	movl	$0x10, %esi
   15831:      	movq	%r12, %rdx
   15834:      	callq	*%rax
   15836:      	movq	0x28(%rsp), %rbx
   1583b:      	movq	0x48(%rsp), %rax
   15840:      	movl	0x5c(%rsp), %r15d
   15845:      	subq	%rbx, %rax
   15848:      	movl	0x50(%rsp), %r12d
   1584d:      	movl	%r15d, %edx
   15850:      	subl	%r12d, %edx
   15853:      	movl	$0x0, %ecx
   15858:      	cmovbl	%ecx, %edx
   1585b:      	addq	0x60(%rsp), %rdx
   15860:      	xorl	%esi, %esi
   15862:      	cmpl	%r15d, %r12d
   15865:      	seta	%sil
   15869:      	movl	%r15d, %ecx
   1586c:      	cmovbl	%r12d, %ecx
   15870:      	addl	%ecx, %esi
   15872:      	movl	%r12d, %edi
   15875:      	subl	%esi, %edi
   15877:      	movl	%edi, 0x50(%rsp)
   1587b:      	subq	%rsi, %rax
   1587e:      	jb	0x16d52 <generic_fentry_path+0xba72>
   15884:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1588a:      	ja	0x16d52 <generic_fentry_path+0xba72>
   15890:      	cmpl	%r15d, %r12d
   15893:      	jbe	0x15899 <generic_fentry_path+0xa5b9>
   15895:      	movb	$0x2f, (%rbx,%rax)
   15899:      	xorl	%edi, %edi
   1589b:      	cmpl	%r15d, %r12d
   1589e:      	seta	%dil
   158a2:      	movzbl	%cl, %esi
   158a5:      	addq	%rax, %rbx
   158a8:      	addq	%rbx, %rdi
   158ab:      	movl	$0x4, %eax
   158b0:      	callq	*%rax
   158b2:      	movq	%rbx, 0x48(%rsp)
   158b7:      	cmpl	%r15d, %r12d
   158ba:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   158c0:      	movq	0x8(%rsp), %r12
   158c5:      	movq	%r12, 0x30(%rsp)
   158ca:      	movq	0x38(%rsp), %rdx
   158cf:      	movq	0x40(%rsp), %r15
   158d4:      	jmp	0x15927 <generic_fentry_path+0xa647>
   158d6:      	leaq	0x10(%r15), %rdx
   158da:      	movl	$0x4, %eax
   158df:      	movq	%rbp, %rdi
   158e2:      	movl	$0x8, %esi
   158e7:      	callq	*%rax
   158e9:      	movq	0x40(%rsp), %rax
   158ee:      	cmpq	(%rsp), %rax
   158f2:      	je	0x16d4d <generic_fentry_path+0xba6d>
   158f8:      	addq	$0x18, %r15
   158fc:      	movl	$0x4, %eax
   15901:      	leaq	0x30(%rsp), %rdi
   15906:      	movl	$0x8, %esi
   1590b:      	movq	%r15, %rdx
   1590e:      	callq	*%rax
   15910:      	movq	(%rsp), %r15
   15914:      	movq	%r15, 0x40(%rsp)
   15919:      	leaq	0x20(%r15), %rdx
   1591d:      	movq	%rdx, 0x38(%rsp)
   15922:      	movq	0x30(%rsp), %r12
   15927:      	cmpq	0x18(%rsp), %r12
   1592c:      	jne	0x15939 <generic_fentry_path+0xa659>
   1592e:      	cmpq	0x20(%rsp), %rdx
   15933:      	je	0x16d4d <generic_fentry_path+0xba6d>
   15939:      	movl	$0x4, %eax
   1593e:      	leaq	0x10(%rsp), %rdi
   15943:      	movl	$0x8, %esi
   15948:      	callq	*%rax
   1594a:      	cmpq	0x10(%rsp), %r12
   1594f:      	je	0x15a47 <generic_fentry_path+0xa767>
   15955:      	leaq	0x18(%r12), %rbx
   1595a:      	movl	$0x4, %eax
   1595f:      	movq	%rbp, %rdi
   15962:      	movl	$0x8, %esi
   15967:      	movq	%rbx, %rdx
   1596a:      	callq	*%rax
   1596c:      	cmpq	%r12, (%rsp)
   15970:      	je	0x15a47 <generic_fentry_path+0xa767>
   15976:      	movl	$0x4, %eax
   1597b:      	leaq	0x8(%rsp), %rdi
   15980:      	movl	$0x8, %esi
   15985:      	movq	%rbx, %rdx
   15988:      	callq	*%rax
   1598a:      	addq	$0x20, %r12
   1598e:      	movl	$0x4, %eax
   15993:      	leaq	0x58(%rsp), %rdi
   15998:      	movl	$0x10, %ecx
   1599d:      	movl	$0x10, %esi
   159a2:      	movq	%r12, %rdx
   159a5:      	callq	*%rax
   159a7:      	movq	0x28(%rsp), %rbx
   159ac:      	movq	0x48(%rsp), %rax
   159b1:      	movl	0x5c(%rsp), %r15d
   159b6:      	subq	%rbx, %rax
   159b9:      	movl	0x50(%rsp), %r12d
   159be:      	movl	%r15d, %edx
   159c1:      	subl	%r12d, %edx
   159c4:      	movl	$0x0, %ecx
   159c9:      	cmovbl	%ecx, %edx
   159cc:      	addq	0x60(%rsp), %rdx
   159d1:      	xorl	%esi, %esi
   159d3:      	cmpl	%r15d, %r12d
   159d6:      	seta	%sil
   159da:      	movl	%r15d, %ecx
   159dd:      	cmovbl	%r12d, %ecx
   159e1:      	addl	%ecx, %esi
   159e3:      	movl	%r12d, %edi
   159e6:      	subl	%esi, %edi
   159e8:      	movl	%edi, 0x50(%rsp)
   159ec:      	subq	%rsi, %rax
   159ef:      	jb	0x16d52 <generic_fentry_path+0xba72>
   159f5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   159fb:      	ja	0x16d52 <generic_fentry_path+0xba72>
   15a01:      	cmpl	%r15d, %r12d
   15a04:      	jbe	0x15a0a <generic_fentry_path+0xa72a>
   15a06:      	movb	$0x2f, (%rbx,%rax)
   15a0a:      	xorl	%edi, %edi
   15a0c:      	cmpl	%r15d, %r12d
   15a0f:      	seta	%dil
   15a13:      	movzbl	%cl, %esi
   15a16:      	addq	%rax, %rbx
   15a19:      	addq	%rbx, %rdi
   15a1c:      	movl	$0x4, %eax
   15a21:      	callq	*%rax
   15a23:      	movq	%rbx, 0x48(%rsp)
   15a28:      	cmpl	%r15d, %r12d
   15a2b:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   15a31:      	movq	0x8(%rsp), %r12
   15a36:      	movq	%r12, 0x30(%rsp)
   15a3b:      	movq	0x38(%rsp), %rdx
   15a40:      	movq	0x40(%rsp), %r15
   15a45:      	jmp	0x15a98 <generic_fentry_path+0xa7b8>
   15a47:      	leaq	0x10(%r15), %rdx
   15a4b:      	movl	$0x4, %eax
   15a50:      	movq	%rbp, %rdi
   15a53:      	movl	$0x8, %esi
   15a58:      	callq	*%rax
   15a5a:      	movq	0x40(%rsp), %rax
   15a5f:      	cmpq	(%rsp), %rax
   15a63:      	je	0x16d4d <generic_fentry_path+0xba6d>
   15a69:      	addq	$0x18, %r15
   15a6d:      	movl	$0x4, %eax
   15a72:      	leaq	0x30(%rsp), %rdi
   15a77:      	movl	$0x8, %esi
   15a7c:      	movq	%r15, %rdx
   15a7f:      	callq	*%rax
   15a81:      	movq	(%rsp), %r15
   15a85:      	movq	%r15, 0x40(%rsp)
   15a8a:      	leaq	0x20(%r15), %rdx
   15a8e:      	movq	%rdx, 0x38(%rsp)
   15a93:      	movq	0x30(%rsp), %r12
   15a98:      	cmpq	0x18(%rsp), %r12
   15a9d:      	jne	0x15aaa <generic_fentry_path+0xa7ca>
   15a9f:      	cmpq	0x20(%rsp), %rdx
   15aa4:      	je	0x16d4d <generic_fentry_path+0xba6d>
   15aaa:      	movl	$0x4, %eax
   15aaf:      	leaq	0x10(%rsp), %rdi
   15ab4:      	movl	$0x8, %esi
   15ab9:      	callq	*%rax
   15abb:      	cmpq	0x10(%rsp), %r12
   15ac0:      	je	0x15bb8 <generic_fentry_path+0xa8d8>
   15ac6:      	leaq	0x18(%r12), %rbx
   15acb:      	movl	$0x4, %eax
   15ad0:      	movq	%rbp, %rdi
   15ad3:      	movl	$0x8, %esi
   15ad8:      	movq	%rbx, %rdx
   15adb:      	callq	*%rax
   15add:      	cmpq	%r12, (%rsp)
   15ae1:      	je	0x15bb8 <generic_fentry_path+0xa8d8>
   15ae7:      	movl	$0x4, %eax
   15aec:      	leaq	0x8(%rsp), %rdi
   15af1:      	movl	$0x8, %esi
   15af6:      	movq	%rbx, %rdx
   15af9:      	callq	*%rax
   15afb:      	addq	$0x20, %r12
   15aff:      	movl	$0x4, %eax
   15b04:      	leaq	0x58(%rsp), %rdi
   15b09:      	movl	$0x10, %ecx
   15b0e:      	movl	$0x10, %esi
   15b13:      	movq	%r12, %rdx
   15b16:      	callq	*%rax
   15b18:      	movq	0x28(%rsp), %rbx
   15b1d:      	movq	0x48(%rsp), %rax
   15b22:      	movl	0x5c(%rsp), %r15d
   15b27:      	subq	%rbx, %rax
   15b2a:      	movl	0x50(%rsp), %r12d
   15b2f:      	movl	%r15d, %edx
   15b32:      	subl	%r12d, %edx
   15b35:      	movl	$0x0, %ecx
   15b3a:      	cmovbl	%ecx, %edx
   15b3d:      	addq	0x60(%rsp), %rdx
   15b42:      	xorl	%esi, %esi
   15b44:      	cmpl	%r15d, %r12d
   15b47:      	seta	%sil
   15b4b:      	movl	%r15d, %ecx
   15b4e:      	cmovbl	%r12d, %ecx
   15b52:      	addl	%ecx, %esi
   15b54:      	movl	%r12d, %edi
   15b57:      	subl	%esi, %edi
   15b59:      	movl	%edi, 0x50(%rsp)
   15b5d:      	subq	%rsi, %rax
   15b60:      	jb	0x16d52 <generic_fentry_path+0xba72>
   15b66:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15b6c:      	ja	0x16d52 <generic_fentry_path+0xba72>
   15b72:      	cmpl	%r15d, %r12d
   15b75:      	jbe	0x15b7b <generic_fentry_path+0xa89b>
   15b77:      	movb	$0x2f, (%rbx,%rax)
   15b7b:      	xorl	%edi, %edi
   15b7d:      	cmpl	%r15d, %r12d
   15b80:      	seta	%dil
   15b84:      	movzbl	%cl, %esi
   15b87:      	addq	%rax, %rbx
   15b8a:      	addq	%rbx, %rdi
   15b8d:      	movl	$0x4, %eax
   15b92:      	callq	*%rax
   15b94:      	movq	%rbx, 0x48(%rsp)
   15b99:      	cmpl	%r15d, %r12d
   15b9c:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   15ba2:      	movq	0x8(%rsp), %r12
   15ba7:      	movq	%r12, 0x30(%rsp)
   15bac:      	movq	0x38(%rsp), %rdx
   15bb1:      	movq	0x40(%rsp), %r15
   15bb6:      	jmp	0x15c09 <generic_fentry_path+0xa929>
   15bb8:      	leaq	0x10(%r15), %rdx
   15bbc:      	movl	$0x4, %eax
   15bc1:      	movq	%rbp, %rdi
   15bc4:      	movl	$0x8, %esi
   15bc9:      	callq	*%rax
   15bcb:      	movq	0x40(%rsp), %rax
   15bd0:      	cmpq	(%rsp), %rax
   15bd4:      	je	0x16d4d <generic_fentry_path+0xba6d>
   15bda:      	addq	$0x18, %r15
   15bde:      	movl	$0x4, %eax
   15be3:      	leaq	0x30(%rsp), %rdi
   15be8:      	movl	$0x8, %esi
   15bed:      	movq	%r15, %rdx
   15bf0:      	callq	*%rax
   15bf2:      	movq	(%rsp), %r15
   15bf6:      	movq	%r15, 0x40(%rsp)
   15bfb:      	leaq	0x20(%r15), %rdx
   15bff:      	movq	%rdx, 0x38(%rsp)
   15c04:      	movq	0x30(%rsp), %r12
   15c09:      	cmpq	0x18(%rsp), %r12
   15c0e:      	jne	0x15c1b <generic_fentry_path+0xa93b>
   15c10:      	cmpq	0x20(%rsp), %rdx
   15c15:      	je	0x16d4d <generic_fentry_path+0xba6d>
   15c1b:      	movl	$0x4, %eax
   15c20:      	leaq	0x10(%rsp), %rdi
   15c25:      	movl	$0x8, %esi
   15c2a:      	callq	*%rax
   15c2c:      	cmpq	0x10(%rsp), %r12
   15c31:      	je	0x15d29 <generic_fentry_path+0xaa49>
   15c37:      	leaq	0x18(%r12), %rbx
   15c3c:      	movl	$0x4, %eax
   15c41:      	movq	%rbp, %rdi
   15c44:      	movl	$0x8, %esi
   15c49:      	movq	%rbx, %rdx
   15c4c:      	callq	*%rax
   15c4e:      	cmpq	%r12, (%rsp)
   15c52:      	je	0x15d29 <generic_fentry_path+0xaa49>
   15c58:      	movl	$0x4, %eax
   15c5d:      	leaq	0x8(%rsp), %rdi
   15c62:      	movl	$0x8, %esi
   15c67:      	movq	%rbx, %rdx
   15c6a:      	callq	*%rax
   15c6c:      	addq	$0x20, %r12
   15c70:      	movl	$0x4, %eax
   15c75:      	leaq	0x58(%rsp), %rdi
   15c7a:      	movl	$0x10, %ecx
   15c7f:      	movl	$0x10, %esi
   15c84:      	movq	%r12, %rdx
   15c87:      	callq	*%rax
   15c89:      	movq	0x28(%rsp), %rbx
   15c8e:      	movq	0x48(%rsp), %rax
   15c93:      	movl	0x5c(%rsp), %r15d
   15c98:      	subq	%rbx, %rax
   15c9b:      	movl	0x50(%rsp), %r12d
   15ca0:      	movl	%r15d, %edx
   15ca3:      	subl	%r12d, %edx
   15ca6:      	movl	$0x0, %ecx
   15cab:      	cmovbl	%ecx, %edx
   15cae:      	addq	0x60(%rsp), %rdx
   15cb3:      	xorl	%esi, %esi
   15cb5:      	cmpl	%r15d, %r12d
   15cb8:      	seta	%sil
   15cbc:      	movl	%r15d, %ecx
   15cbf:      	cmovbl	%r12d, %ecx
   15cc3:      	addl	%ecx, %esi
   15cc5:      	movl	%r12d, %edi
   15cc8:      	subl	%esi, %edi
   15cca:      	movl	%edi, 0x50(%rsp)
   15cce:      	subq	%rsi, %rax
   15cd1:      	jb	0x16d52 <generic_fentry_path+0xba72>
   15cd7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15cdd:      	ja	0x16d52 <generic_fentry_path+0xba72>
   15ce3:      	cmpl	%r15d, %r12d
   15ce6:      	jbe	0x15cec <generic_fentry_path+0xaa0c>
   15ce8:      	movb	$0x2f, (%rbx,%rax)
   15cec:      	xorl	%edi, %edi
   15cee:      	cmpl	%r15d, %r12d
   15cf1:      	seta	%dil
   15cf5:      	movzbl	%cl, %esi
   15cf8:      	addq	%rax, %rbx
   15cfb:      	addq	%rbx, %rdi
   15cfe:      	movl	$0x4, %eax
   15d03:      	callq	*%rax
   15d05:      	movq	%rbx, 0x48(%rsp)
   15d0a:      	cmpl	%r15d, %r12d
   15d0d:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   15d13:      	movq	0x8(%rsp), %r12
   15d18:      	movq	%r12, 0x30(%rsp)
   15d1d:      	movq	0x38(%rsp), %rdx
   15d22:      	movq	0x40(%rsp), %r15
   15d27:      	jmp	0x15d7a <generic_fentry_path+0xaa9a>
   15d29:      	leaq	0x10(%r15), %rdx
   15d2d:      	movl	$0x4, %eax
   15d32:      	movq	%rbp, %rdi
   15d35:      	movl	$0x8, %esi
   15d3a:      	callq	*%rax
   15d3c:      	movq	0x40(%rsp), %rax
   15d41:      	cmpq	(%rsp), %rax
   15d45:      	je	0x16d4d <generic_fentry_path+0xba6d>
   15d4b:      	addq	$0x18, %r15
   15d4f:      	movl	$0x4, %eax
   15d54:      	leaq	0x30(%rsp), %rdi
   15d59:      	movl	$0x8, %esi
   15d5e:      	movq	%r15, %rdx
   15d61:      	callq	*%rax
   15d63:      	movq	(%rsp), %r15
   15d67:      	movq	%r15, 0x40(%rsp)
   15d6c:      	leaq	0x20(%r15), %rdx
   15d70:      	movq	%rdx, 0x38(%rsp)
   15d75:      	movq	0x30(%rsp), %r12
   15d7a:      	cmpq	0x18(%rsp), %r12
   15d7f:      	jne	0x15d8c <generic_fentry_path+0xaaac>
   15d81:      	cmpq	0x20(%rsp), %rdx
   15d86:      	je	0x16d4d <generic_fentry_path+0xba6d>
   15d8c:      	movl	$0x4, %eax
   15d91:      	leaq	0x10(%rsp), %rdi
   15d96:      	movl	$0x8, %esi
   15d9b:      	callq	*%rax
   15d9d:      	cmpq	0x10(%rsp), %r12
   15da2:      	je	0x15e9a <generic_fentry_path+0xabba>
   15da8:      	leaq	0x18(%r12), %rbx
   15dad:      	movl	$0x4, %eax
   15db2:      	movq	%rbp, %rdi
   15db5:      	movl	$0x8, %esi
   15dba:      	movq	%rbx, %rdx
   15dbd:      	callq	*%rax
   15dbf:      	cmpq	%r12, (%rsp)
   15dc3:      	je	0x15e9a <generic_fentry_path+0xabba>
   15dc9:      	movl	$0x4, %eax
   15dce:      	leaq	0x8(%rsp), %rdi
   15dd3:      	movl	$0x8, %esi
   15dd8:      	movq	%rbx, %rdx
   15ddb:      	callq	*%rax
   15ddd:      	addq	$0x20, %r12
   15de1:      	movl	$0x4, %eax
   15de6:      	leaq	0x58(%rsp), %rdi
   15deb:      	movl	$0x10, %ecx
   15df0:      	movl	$0x10, %esi
   15df5:      	movq	%r12, %rdx
   15df8:      	callq	*%rax
   15dfa:      	movq	0x28(%rsp), %rbx
   15dff:      	movq	0x48(%rsp), %rax
   15e04:      	movl	0x5c(%rsp), %r15d
   15e09:      	subq	%rbx, %rax
   15e0c:      	movl	0x50(%rsp), %r12d
   15e11:      	movl	%r15d, %edx
   15e14:      	subl	%r12d, %edx
   15e17:      	movl	$0x0, %ecx
   15e1c:      	cmovbl	%ecx, %edx
   15e1f:      	addq	0x60(%rsp), %rdx
   15e24:      	xorl	%esi, %esi
   15e26:      	cmpl	%r15d, %r12d
   15e29:      	seta	%sil
   15e2d:      	movl	%r15d, %ecx
   15e30:      	cmovbl	%r12d, %ecx
   15e34:      	addl	%ecx, %esi
   15e36:      	movl	%r12d, %edi
   15e39:      	subl	%esi, %edi
   15e3b:      	movl	%edi, 0x50(%rsp)
   15e3f:      	subq	%rsi, %rax
   15e42:      	jb	0x16d52 <generic_fentry_path+0xba72>
   15e48:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15e4e:      	ja	0x16d52 <generic_fentry_path+0xba72>
   15e54:      	cmpl	%r15d, %r12d
   15e57:      	jbe	0x15e5d <generic_fentry_path+0xab7d>
   15e59:      	movb	$0x2f, (%rbx,%rax)
   15e5d:      	xorl	%edi, %edi
   15e5f:      	cmpl	%r15d, %r12d
   15e62:      	seta	%dil
   15e66:      	movzbl	%cl, %esi
   15e69:      	addq	%rax, %rbx
   15e6c:      	addq	%rbx, %rdi
   15e6f:      	movl	$0x4, %eax
   15e74:      	callq	*%rax
   15e76:      	movq	%rbx, 0x48(%rsp)
   15e7b:      	cmpl	%r15d, %r12d
   15e7e:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   15e84:      	movq	0x8(%rsp), %r12
   15e89:      	movq	%r12, 0x30(%rsp)
   15e8e:      	movq	0x38(%rsp), %rdx
   15e93:      	movq	0x40(%rsp), %r15
   15e98:      	jmp	0x15eeb <generic_fentry_path+0xac0b>
   15e9a:      	leaq	0x10(%r15), %rdx
   15e9e:      	movl	$0x4, %eax
   15ea3:      	movq	%rbp, %rdi
   15ea6:      	movl	$0x8, %esi
   15eab:      	callq	*%rax
   15ead:      	movq	0x40(%rsp), %rax
   15eb2:      	cmpq	(%rsp), %rax
   15eb6:      	je	0x16d4d <generic_fentry_path+0xba6d>
   15ebc:      	addq	$0x18, %r15
   15ec0:      	movl	$0x4, %eax
   15ec5:      	leaq	0x30(%rsp), %rdi
   15eca:      	movl	$0x8, %esi
   15ecf:      	movq	%r15, %rdx
   15ed2:      	callq	*%rax
   15ed4:      	movq	(%rsp), %r15
   15ed8:      	movq	%r15, 0x40(%rsp)
   15edd:      	leaq	0x20(%r15), %rdx
   15ee1:      	movq	%rdx, 0x38(%rsp)
   15ee6:      	movq	0x30(%rsp), %r12
   15eeb:      	cmpq	0x18(%rsp), %r12
   15ef0:      	jne	0x15efd <generic_fentry_path+0xac1d>
   15ef2:      	cmpq	0x20(%rsp), %rdx
   15ef7:      	je	0x16d4d <generic_fentry_path+0xba6d>
   15efd:      	movl	$0x4, %eax
   15f02:      	leaq	0x10(%rsp), %rdi
   15f07:      	movl	$0x8, %esi
   15f0c:      	callq	*%rax
   15f0e:      	cmpq	0x10(%rsp), %r12
   15f13:      	je	0x1600b <generic_fentry_path+0xad2b>
   15f19:      	leaq	0x18(%r12), %rbx
   15f1e:      	movl	$0x4, %eax
   15f23:      	movq	%rbp, %rdi
   15f26:      	movl	$0x8, %esi
   15f2b:      	movq	%rbx, %rdx
   15f2e:      	callq	*%rax
   15f30:      	cmpq	%r12, (%rsp)
   15f34:      	je	0x1600b <generic_fentry_path+0xad2b>
   15f3a:      	movl	$0x4, %eax
   15f3f:      	leaq	0x8(%rsp), %rdi
   15f44:      	movl	$0x8, %esi
   15f49:      	movq	%rbx, %rdx
   15f4c:      	callq	*%rax
   15f4e:      	addq	$0x20, %r12
   15f52:      	movl	$0x4, %eax
   15f57:      	leaq	0x58(%rsp), %rdi
   15f5c:      	movl	$0x10, %ecx
   15f61:      	movl	$0x10, %esi
   15f66:      	movq	%r12, %rdx
   15f69:      	callq	*%rax
   15f6b:      	movq	0x28(%rsp), %rbx
   15f70:      	movq	0x48(%rsp), %rax
   15f75:      	movl	0x5c(%rsp), %r15d
   15f7a:      	subq	%rbx, %rax
   15f7d:      	movl	0x50(%rsp), %r12d
   15f82:      	movl	%r15d, %edx
   15f85:      	subl	%r12d, %edx
   15f88:      	movl	$0x0, %ecx
   15f8d:      	cmovbl	%ecx, %edx
   15f90:      	addq	0x60(%rsp), %rdx
   15f95:      	xorl	%esi, %esi
   15f97:      	cmpl	%r15d, %r12d
   15f9a:      	seta	%sil
   15f9e:      	movl	%r15d, %ecx
   15fa1:      	cmovbl	%r12d, %ecx
   15fa5:      	addl	%ecx, %esi
   15fa7:      	movl	%r12d, %edi
   15faa:      	subl	%esi, %edi
   15fac:      	movl	%edi, 0x50(%rsp)
   15fb0:      	subq	%rsi, %rax
   15fb3:      	jb	0x16d52 <generic_fentry_path+0xba72>
   15fb9:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15fbf:      	ja	0x16d52 <generic_fentry_path+0xba72>
   15fc5:      	cmpl	%r15d, %r12d
   15fc8:      	jbe	0x15fce <generic_fentry_path+0xacee>
   15fca:      	movb	$0x2f, (%rbx,%rax)
   15fce:      	xorl	%edi, %edi
   15fd0:      	cmpl	%r15d, %r12d
   15fd3:      	seta	%dil
   15fd7:      	movzbl	%cl, %esi
   15fda:      	addq	%rax, %rbx
   15fdd:      	addq	%rbx, %rdi
   15fe0:      	movl	$0x4, %eax
   15fe5:      	callq	*%rax
   15fe7:      	movq	%rbx, 0x48(%rsp)
   15fec:      	cmpl	%r15d, %r12d
   15fef:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   15ff5:      	movq	0x8(%rsp), %r12
   15ffa:      	movq	%r12, 0x30(%rsp)
   15fff:      	movq	0x38(%rsp), %rdx
   16004:      	movq	0x40(%rsp), %r15
   16009:      	jmp	0x1605c <generic_fentry_path+0xad7c>
   1600b:      	leaq	0x10(%r15), %rdx
   1600f:      	movl	$0x4, %eax
   16014:      	movq	%rbp, %rdi
   16017:      	movl	$0x8, %esi
   1601c:      	callq	*%rax
   1601e:      	movq	0x40(%rsp), %rax
   16023:      	cmpq	(%rsp), %rax
   16027:      	je	0x16d4d <generic_fentry_path+0xba6d>
   1602d:      	addq	$0x18, %r15
   16031:      	movl	$0x4, %eax
   16036:      	leaq	0x30(%rsp), %rdi
   1603b:      	movl	$0x8, %esi
   16040:      	movq	%r15, %rdx
   16043:      	callq	*%rax
   16045:      	movq	(%rsp), %r15
   16049:      	movq	%r15, 0x40(%rsp)
   1604e:      	leaq	0x20(%r15), %rdx
   16052:      	movq	%rdx, 0x38(%rsp)
   16057:      	movq	0x30(%rsp), %r12
   1605c:      	cmpq	0x18(%rsp), %r12
   16061:      	jne	0x1606e <generic_fentry_path+0xad8e>
   16063:      	cmpq	0x20(%rsp), %rdx
   16068:      	je	0x16d4d <generic_fentry_path+0xba6d>
   1606e:      	movl	$0x4, %eax
   16073:      	leaq	0x10(%rsp), %rdi
   16078:      	movl	$0x8, %esi
   1607d:      	callq	*%rax
   1607f:      	cmpq	0x10(%rsp), %r12
   16084:      	je	0x1617c <generic_fentry_path+0xae9c>
   1608a:      	leaq	0x18(%r12), %rbx
   1608f:      	movl	$0x4, %eax
   16094:      	movq	%rbp, %rdi
   16097:      	movl	$0x8, %esi
   1609c:      	movq	%rbx, %rdx
   1609f:      	callq	*%rax
   160a1:      	cmpq	%r12, (%rsp)
   160a5:      	je	0x1617c <generic_fentry_path+0xae9c>
   160ab:      	movl	$0x4, %eax
   160b0:      	leaq	0x8(%rsp), %rdi
   160b5:      	movl	$0x8, %esi
   160ba:      	movq	%rbx, %rdx
   160bd:      	callq	*%rax
   160bf:      	addq	$0x20, %r12
   160c3:      	movl	$0x4, %eax
   160c8:      	leaq	0x58(%rsp), %rdi
   160cd:      	movl	$0x10, %ecx
   160d2:      	movl	$0x10, %esi
   160d7:      	movq	%r12, %rdx
   160da:      	callq	*%rax
   160dc:      	movq	0x28(%rsp), %rbx
   160e1:      	movq	0x48(%rsp), %rax
   160e6:      	movl	0x5c(%rsp), %r15d
   160eb:      	subq	%rbx, %rax
   160ee:      	movl	0x50(%rsp), %r12d
   160f3:      	movl	%r15d, %edx
   160f6:      	subl	%r12d, %edx
   160f9:      	movl	$0x0, %ecx
   160fe:      	cmovbl	%ecx, %edx
   16101:      	addq	0x60(%rsp), %rdx
   16106:      	xorl	%esi, %esi
   16108:      	cmpl	%r15d, %r12d
   1610b:      	seta	%sil
   1610f:      	movl	%r15d, %ecx
   16112:      	cmovbl	%r12d, %ecx
   16116:      	addl	%ecx, %esi
   16118:      	movl	%r12d, %edi
   1611b:      	subl	%esi, %edi
   1611d:      	movl	%edi, 0x50(%rsp)
   16121:      	subq	%rsi, %rax
   16124:      	jb	0x16d52 <generic_fentry_path+0xba72>
   1612a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   16130:      	ja	0x16d52 <generic_fentry_path+0xba72>
   16136:      	cmpl	%r15d, %r12d
   16139:      	jbe	0x1613f <generic_fentry_path+0xae5f>
   1613b:      	movb	$0x2f, (%rbx,%rax)
   1613f:      	xorl	%edi, %edi
   16141:      	cmpl	%r15d, %r12d
   16144:      	seta	%dil
   16148:      	movzbl	%cl, %esi
   1614b:      	addq	%rax, %rbx
   1614e:      	addq	%rbx, %rdi
   16151:      	movl	$0x4, %eax
   16156:      	callq	*%rax
   16158:      	movq	%rbx, 0x48(%rsp)
   1615d:      	cmpl	%r15d, %r12d
   16160:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   16166:      	movq	0x8(%rsp), %r12
   1616b:      	movq	%r12, 0x30(%rsp)
   16170:      	movq	0x38(%rsp), %rdx
   16175:      	movq	0x40(%rsp), %r15
   1617a:      	jmp	0x161cd <generic_fentry_path+0xaeed>
   1617c:      	leaq	0x10(%r15), %rdx
   16180:      	movl	$0x4, %eax
   16185:      	movq	%rbp, %rdi
   16188:      	movl	$0x8, %esi
   1618d:      	callq	*%rax
   1618f:      	movq	0x40(%rsp), %rax
   16194:      	cmpq	(%rsp), %rax
   16198:      	je	0x16d4d <generic_fentry_path+0xba6d>
   1619e:      	addq	$0x18, %r15
   161a2:      	movl	$0x4, %eax
   161a7:      	leaq	0x30(%rsp), %rdi
   161ac:      	movl	$0x8, %esi
   161b1:      	movq	%r15, %rdx
   161b4:      	callq	*%rax
   161b6:      	movq	(%rsp), %r15
   161ba:      	movq	%r15, 0x40(%rsp)
   161bf:      	leaq	0x20(%r15), %rdx
   161c3:      	movq	%rdx, 0x38(%rsp)
   161c8:      	movq	0x30(%rsp), %r12
   161cd:      	cmpq	0x18(%rsp), %r12
   161d2:      	jne	0x161df <generic_fentry_path+0xaeff>
   161d4:      	cmpq	0x20(%rsp), %rdx
   161d9:      	je	0x16d4d <generic_fentry_path+0xba6d>
   161df:      	movl	$0x4, %eax
   161e4:      	leaq	0x10(%rsp), %rdi
   161e9:      	movl	$0x8, %esi
   161ee:      	callq	*%rax
   161f0:      	cmpq	0x10(%rsp), %r12
   161f5:      	je	0x162ed <generic_fentry_path+0xb00d>
   161fb:      	leaq	0x18(%r12), %rbx
   16200:      	movl	$0x4, %eax
   16205:      	movq	%rbp, %rdi
   16208:      	movl	$0x8, %esi
   1620d:      	movq	%rbx, %rdx
   16210:      	callq	*%rax
   16212:      	cmpq	%r12, (%rsp)
   16216:      	je	0x162ed <generic_fentry_path+0xb00d>
   1621c:      	movl	$0x4, %eax
   16221:      	leaq	0x8(%rsp), %rdi
   16226:      	movl	$0x8, %esi
   1622b:      	movq	%rbx, %rdx
   1622e:      	callq	*%rax
   16230:      	addq	$0x20, %r12
   16234:      	movl	$0x4, %eax
   16239:      	leaq	0x58(%rsp), %rdi
   1623e:      	movl	$0x10, %ecx
   16243:      	movl	$0x10, %esi
   16248:      	movq	%r12, %rdx
   1624b:      	callq	*%rax
   1624d:      	movq	0x28(%rsp), %rbx
   16252:      	movq	0x48(%rsp), %rax
   16257:      	movl	0x5c(%rsp), %r15d
   1625c:      	subq	%rbx, %rax
   1625f:      	movl	0x50(%rsp), %r12d
   16264:      	movl	%r15d, %edx
   16267:      	subl	%r12d, %edx
   1626a:      	movl	$0x0, %ecx
   1626f:      	cmovbl	%ecx, %edx
   16272:      	addq	0x60(%rsp), %rdx
   16277:      	xorl	%esi, %esi
   16279:      	cmpl	%r15d, %r12d
   1627c:      	seta	%sil
   16280:      	movl	%r15d, %ecx
   16283:      	cmovbl	%r12d, %ecx
   16287:      	addl	%ecx, %esi
   16289:      	movl	%r12d, %edi
   1628c:      	subl	%esi, %edi
   1628e:      	movl	%edi, 0x50(%rsp)
   16292:      	subq	%rsi, %rax
   16295:      	jb	0x16d52 <generic_fentry_path+0xba72>
   1629b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   162a1:      	ja	0x16d52 <generic_fentry_path+0xba72>
   162a7:      	cmpl	%r15d, %r12d
   162aa:      	jbe	0x162b0 <generic_fentry_path+0xafd0>
   162ac:      	movb	$0x2f, (%rbx,%rax)
   162b0:      	xorl	%edi, %edi
   162b2:      	cmpl	%r15d, %r12d
   162b5:      	seta	%dil
   162b9:      	movzbl	%cl, %esi
   162bc:      	addq	%rax, %rbx
   162bf:      	addq	%rbx, %rdi
   162c2:      	movl	$0x4, %eax
   162c7:      	callq	*%rax
   162c9:      	movq	%rbx, 0x48(%rsp)
   162ce:      	cmpl	%r15d, %r12d
   162d1:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   162d7:      	movq	0x8(%rsp), %r12
   162dc:      	movq	%r12, 0x30(%rsp)
   162e1:      	movq	0x38(%rsp), %rdx
   162e6:      	movq	0x40(%rsp), %r15
   162eb:      	jmp	0x1633e <generic_fentry_path+0xb05e>
   162ed:      	leaq	0x10(%r15), %rdx
   162f1:      	movl	$0x4, %eax
   162f6:      	movq	%rbp, %rdi
   162f9:      	movl	$0x8, %esi
   162fe:      	callq	*%rax
   16300:      	movq	0x40(%rsp), %rax
   16305:      	cmpq	(%rsp), %rax
   16309:      	je	0x16d4d <generic_fentry_path+0xba6d>
   1630f:      	addq	$0x18, %r15
   16313:      	movl	$0x4, %eax
   16318:      	leaq	0x30(%rsp), %rdi
   1631d:      	movl	$0x8, %esi
   16322:      	movq	%r15, %rdx
   16325:      	callq	*%rax
   16327:      	movq	(%rsp), %r15
   1632b:      	movq	%r15, 0x40(%rsp)
   16330:      	leaq	0x20(%r15), %rdx
   16334:      	movq	%rdx, 0x38(%rsp)
   16339:      	movq	0x30(%rsp), %r12
   1633e:      	cmpq	0x18(%rsp), %r12
   16343:      	jne	0x16350 <generic_fentry_path+0xb070>
   16345:      	cmpq	0x20(%rsp), %rdx
   1634a:      	je	0x16d4d <generic_fentry_path+0xba6d>
   16350:      	movl	$0x4, %eax
   16355:      	leaq	0x10(%rsp), %rdi
   1635a:      	movl	$0x8, %esi
   1635f:      	callq	*%rax
   16361:      	cmpq	0x10(%rsp), %r12
   16366:      	je	0x1645e <generic_fentry_path+0xb17e>
   1636c:      	leaq	0x18(%r12), %rbx
   16371:      	movl	$0x4, %eax
   16376:      	movq	%rbp, %rdi
   16379:      	movl	$0x8, %esi
   1637e:      	movq	%rbx, %rdx
   16381:      	callq	*%rax
   16383:      	cmpq	%r12, (%rsp)
   16387:      	je	0x1645e <generic_fentry_path+0xb17e>
   1638d:      	movl	$0x4, %eax
   16392:      	leaq	0x8(%rsp), %rdi
   16397:      	movl	$0x8, %esi
   1639c:      	movq	%rbx, %rdx
   1639f:      	callq	*%rax
   163a1:      	addq	$0x20, %r12
   163a5:      	movl	$0x4, %eax
   163aa:      	leaq	0x58(%rsp), %rdi
   163af:      	movl	$0x10, %ecx
   163b4:      	movl	$0x10, %esi
   163b9:      	movq	%r12, %rdx
   163bc:      	callq	*%rax
   163be:      	movq	0x28(%rsp), %rbx
   163c3:      	movq	0x48(%rsp), %rax
   163c8:      	movl	0x5c(%rsp), %r15d
   163cd:      	subq	%rbx, %rax
   163d0:      	movl	0x50(%rsp), %r12d
   163d5:      	movl	%r15d, %edx
   163d8:      	subl	%r12d, %edx
   163db:      	movl	$0x0, %ecx
   163e0:      	cmovbl	%ecx, %edx
   163e3:      	addq	0x60(%rsp), %rdx
   163e8:      	xorl	%esi, %esi
   163ea:      	cmpl	%r15d, %r12d
   163ed:      	seta	%sil
   163f1:      	movl	%r15d, %ecx
   163f4:      	cmovbl	%r12d, %ecx
   163f8:      	addl	%ecx, %esi
   163fa:      	movl	%r12d, %edi
   163fd:      	subl	%esi, %edi
   163ff:      	movl	%edi, 0x50(%rsp)
   16403:      	subq	%rsi, %rax
   16406:      	jb	0x16d52 <generic_fentry_path+0xba72>
   1640c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   16412:      	ja	0x16d52 <generic_fentry_path+0xba72>
   16418:      	cmpl	%r15d, %r12d
   1641b:      	jbe	0x16421 <generic_fentry_path+0xb141>
   1641d:      	movb	$0x2f, (%rbx,%rax)
   16421:      	xorl	%edi, %edi
   16423:      	cmpl	%r15d, %r12d
   16426:      	seta	%dil
   1642a:      	movzbl	%cl, %esi
   1642d:      	addq	%rax, %rbx
   16430:      	addq	%rbx, %rdi
   16433:      	movl	$0x4, %eax
   16438:      	callq	*%rax
   1643a:      	movq	%rbx, 0x48(%rsp)
   1643f:      	cmpl	%r15d, %r12d
   16442:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   16448:      	movq	0x8(%rsp), %r12
   1644d:      	movq	%r12, 0x30(%rsp)
   16452:      	movq	0x38(%rsp), %rdx
   16457:      	movq	0x40(%rsp), %r15
   1645c:      	jmp	0x164af <generic_fentry_path+0xb1cf>
   1645e:      	leaq	0x10(%r15), %rdx
   16462:      	movl	$0x4, %eax
   16467:      	movq	%rbp, %rdi
   1646a:      	movl	$0x8, %esi
   1646f:      	callq	*%rax
   16471:      	movq	0x40(%rsp), %rax
   16476:      	cmpq	(%rsp), %rax
   1647a:      	je	0x16d4d <generic_fentry_path+0xba6d>
   16480:      	addq	$0x18, %r15
   16484:      	movl	$0x4, %eax
   16489:      	leaq	0x30(%rsp), %rdi
   1648e:      	movl	$0x8, %esi
   16493:      	movq	%r15, %rdx
   16496:      	callq	*%rax
   16498:      	movq	(%rsp), %r15
   1649c:      	movq	%r15, 0x40(%rsp)
   164a1:      	leaq	0x20(%r15), %rdx
   164a5:      	movq	%rdx, 0x38(%rsp)
   164aa:      	movq	0x30(%rsp), %r12
   164af:      	cmpq	0x18(%rsp), %r12
   164b4:      	jne	0x164c1 <generic_fentry_path+0xb1e1>
   164b6:      	cmpq	0x20(%rsp), %rdx
   164bb:      	je	0x16d4d <generic_fentry_path+0xba6d>
   164c1:      	movl	$0x4, %eax
   164c6:      	leaq	0x10(%rsp), %rdi
   164cb:      	movl	$0x8, %esi
   164d0:      	callq	*%rax
   164d2:      	cmpq	0x10(%rsp), %r12
   164d7:      	je	0x165cf <generic_fentry_path+0xb2ef>
   164dd:      	leaq	0x18(%r12), %rbx
   164e2:      	movl	$0x4, %eax
   164e7:      	movq	%rbp, %rdi
   164ea:      	movl	$0x8, %esi
   164ef:      	movq	%rbx, %rdx
   164f2:      	callq	*%rax
   164f4:      	cmpq	%r12, (%rsp)
   164f8:      	je	0x165cf <generic_fentry_path+0xb2ef>
   164fe:      	movl	$0x4, %eax
   16503:      	leaq	0x8(%rsp), %rdi
   16508:      	movl	$0x8, %esi
   1650d:      	movq	%rbx, %rdx
   16510:      	callq	*%rax
   16512:      	addq	$0x20, %r12
   16516:      	movl	$0x4, %eax
   1651b:      	leaq	0x58(%rsp), %rdi
   16520:      	movl	$0x10, %ecx
   16525:      	movl	$0x10, %esi
   1652a:      	movq	%r12, %rdx
   1652d:      	callq	*%rax
   1652f:      	movq	0x28(%rsp), %rbx
   16534:      	movq	0x48(%rsp), %rax
   16539:      	movl	0x5c(%rsp), %r15d
   1653e:      	subq	%rbx, %rax
   16541:      	movl	0x50(%rsp), %r12d
   16546:      	movl	%r15d, %edx
   16549:      	subl	%r12d, %edx
   1654c:      	movl	$0x0, %ecx
   16551:      	cmovbl	%ecx, %edx
   16554:      	addq	0x60(%rsp), %rdx
   16559:      	xorl	%esi, %esi
   1655b:      	cmpl	%r15d, %r12d
   1655e:      	seta	%sil
   16562:      	movl	%r15d, %ecx
   16565:      	cmovbl	%r12d, %ecx
   16569:      	addl	%ecx, %esi
   1656b:      	movl	%r12d, %edi
   1656e:      	subl	%esi, %edi
   16570:      	movl	%edi, 0x50(%rsp)
   16574:      	subq	%rsi, %rax
   16577:      	jb	0x16d52 <generic_fentry_path+0xba72>
   1657d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   16583:      	ja	0x16d52 <generic_fentry_path+0xba72>
   16589:      	cmpl	%r15d, %r12d
   1658c:      	jbe	0x16592 <generic_fentry_path+0xb2b2>
   1658e:      	movb	$0x2f, (%rbx,%rax)
   16592:      	xorl	%edi, %edi
   16594:      	cmpl	%r15d, %r12d
   16597:      	seta	%dil
   1659b:      	movzbl	%cl, %esi
   1659e:      	addq	%rax, %rbx
   165a1:      	addq	%rbx, %rdi
   165a4:      	movl	$0x4, %eax
   165a9:      	callq	*%rax
   165ab:      	movq	%rbx, 0x48(%rsp)
   165b0:      	cmpl	%r15d, %r12d
   165b3:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   165b9:      	movq	0x8(%rsp), %r12
   165be:      	movq	%r12, 0x30(%rsp)
   165c3:      	movq	0x38(%rsp), %rdx
   165c8:      	movq	0x40(%rsp), %r15
   165cd:      	jmp	0x16620 <generic_fentry_path+0xb340>
   165cf:      	leaq	0x10(%r15), %rdx
   165d3:      	movl	$0x4, %eax
   165d8:      	movq	%rbp, %rdi
   165db:      	movl	$0x8, %esi
   165e0:      	callq	*%rax
   165e2:      	movq	0x40(%rsp), %rax
   165e7:      	cmpq	(%rsp), %rax
   165eb:      	je	0x16d4d <generic_fentry_path+0xba6d>
   165f1:      	addq	$0x18, %r15
   165f5:      	movl	$0x4, %eax
   165fa:      	leaq	0x30(%rsp), %rdi
   165ff:      	movl	$0x8, %esi
   16604:      	movq	%r15, %rdx
   16607:      	callq	*%rax
   16609:      	movq	(%rsp), %r15
   1660d:      	movq	%r15, 0x40(%rsp)
   16612:      	leaq	0x20(%r15), %rdx
   16616:      	movq	%rdx, 0x38(%rsp)
   1661b:      	movq	0x30(%rsp), %r12
   16620:      	cmpq	0x18(%rsp), %r12
   16625:      	jne	0x16632 <generic_fentry_path+0xb352>
   16627:      	cmpq	0x20(%rsp), %rdx
   1662c:      	je	0x16d4d <generic_fentry_path+0xba6d>
   16632:      	movl	$0x4, %eax
   16637:      	leaq	0x10(%rsp), %rdi
   1663c:      	movl	$0x8, %esi
   16641:      	callq	*%rax
   16643:      	cmpq	0x10(%rsp), %r12
   16648:      	je	0x16740 <generic_fentry_path+0xb460>
   1664e:      	leaq	0x18(%r12), %rbx
   16653:      	movl	$0x4, %eax
   16658:      	movq	%rbp, %rdi
   1665b:      	movl	$0x8, %esi
   16660:      	movq	%rbx, %rdx
   16663:      	callq	*%rax
   16665:      	cmpq	%r12, (%rsp)
   16669:      	je	0x16740 <generic_fentry_path+0xb460>
   1666f:      	movl	$0x4, %eax
   16674:      	leaq	0x8(%rsp), %rdi
   16679:      	movl	$0x8, %esi
   1667e:      	movq	%rbx, %rdx
   16681:      	callq	*%rax
   16683:      	addq	$0x20, %r12
   16687:      	movl	$0x4, %eax
   1668c:      	leaq	0x58(%rsp), %rdi
   16691:      	movl	$0x10, %ecx
   16696:      	movl	$0x10, %esi
   1669b:      	movq	%r12, %rdx
   1669e:      	callq	*%rax
   166a0:      	movq	0x28(%rsp), %rbx
   166a5:      	movq	0x48(%rsp), %rax
   166aa:      	movl	0x5c(%rsp), %r15d
   166af:      	subq	%rbx, %rax
   166b2:      	movl	0x50(%rsp), %r12d
   166b7:      	movl	%r15d, %edx
   166ba:      	subl	%r12d, %edx
   166bd:      	movl	$0x0, %ecx
   166c2:      	cmovbl	%ecx, %edx
   166c5:      	addq	0x60(%rsp), %rdx
   166ca:      	xorl	%esi, %esi
   166cc:      	cmpl	%r15d, %r12d
   166cf:      	seta	%sil
   166d3:      	movl	%r15d, %ecx
   166d6:      	cmovbl	%r12d, %ecx
   166da:      	addl	%ecx, %esi
   166dc:      	movl	%r12d, %edi
   166df:      	subl	%esi, %edi
   166e1:      	movl	%edi, 0x50(%rsp)
   166e5:      	subq	%rsi, %rax
   166e8:      	jb	0x16d52 <generic_fentry_path+0xba72>
   166ee:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   166f4:      	ja	0x16d52 <generic_fentry_path+0xba72>
   166fa:      	cmpl	%r15d, %r12d
   166fd:      	jbe	0x16703 <generic_fentry_path+0xb423>
   166ff:      	movb	$0x2f, (%rbx,%rax)
   16703:      	xorl	%edi, %edi
   16705:      	cmpl	%r15d, %r12d
   16708:      	seta	%dil
   1670c:      	movzbl	%cl, %esi
   1670f:      	addq	%rax, %rbx
   16712:      	addq	%rbx, %rdi
   16715:      	movl	$0x4, %eax
   1671a:      	callq	*%rax
   1671c:      	movq	%rbx, 0x48(%rsp)
   16721:      	cmpl	%r15d, %r12d
   16724:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   1672a:      	movq	0x8(%rsp), %r12
   1672f:      	movq	%r12, 0x30(%rsp)
   16734:      	movq	0x38(%rsp), %rdx
   16739:      	movq	0x40(%rsp), %r15
   1673e:      	jmp	0x16791 <generic_fentry_path+0xb4b1>
   16740:      	leaq	0x10(%r15), %rdx
   16744:      	movl	$0x4, %eax
   16749:      	movq	%rbp, %rdi
   1674c:      	movl	$0x8, %esi
   16751:      	callq	*%rax
   16753:      	movq	0x40(%rsp), %rax
   16758:      	cmpq	(%rsp), %rax
   1675c:      	je	0x16d4d <generic_fentry_path+0xba6d>
   16762:      	addq	$0x18, %r15
   16766:      	movl	$0x4, %eax
   1676b:      	leaq	0x30(%rsp), %rdi
   16770:      	movl	$0x8, %esi
   16775:      	movq	%r15, %rdx
   16778:      	callq	*%rax
   1677a:      	movq	(%rsp), %r15
   1677e:      	movq	%r15, 0x40(%rsp)
   16783:      	leaq	0x20(%r15), %rdx
   16787:      	movq	%rdx, 0x38(%rsp)
   1678c:      	movq	0x30(%rsp), %r12
   16791:      	cmpq	0x18(%rsp), %r12
   16796:      	jne	0x167a3 <generic_fentry_path+0xb4c3>
   16798:      	cmpq	0x20(%rsp), %rdx
   1679d:      	je	0x16d4d <generic_fentry_path+0xba6d>
   167a3:      	movl	$0x4, %eax
   167a8:      	leaq	0x10(%rsp), %rdi
   167ad:      	movl	$0x8, %esi
   167b2:      	callq	*%rax
   167b4:      	cmpq	0x10(%rsp), %r12
   167b9:      	je	0x168b1 <generic_fentry_path+0xb5d1>
   167bf:      	leaq	0x18(%r12), %rbx
   167c4:      	movl	$0x4, %eax
   167c9:      	movq	%rbp, %rdi
   167cc:      	movl	$0x8, %esi
   167d1:      	movq	%rbx, %rdx
   167d4:      	callq	*%rax
   167d6:      	cmpq	%r12, (%rsp)
   167da:      	je	0x168b1 <generic_fentry_path+0xb5d1>
   167e0:      	movl	$0x4, %eax
   167e5:      	leaq	0x8(%rsp), %rdi
   167ea:      	movl	$0x8, %esi
   167ef:      	movq	%rbx, %rdx
   167f2:      	callq	*%rax
   167f4:      	addq	$0x20, %r12
   167f8:      	movl	$0x4, %eax
   167fd:      	leaq	0x58(%rsp), %rdi
   16802:      	movl	$0x10, %ecx
   16807:      	movl	$0x10, %esi
   1680c:      	movq	%r12, %rdx
   1680f:      	callq	*%rax
   16811:      	movq	0x28(%rsp), %rbx
   16816:      	movq	0x48(%rsp), %rax
   1681b:      	movl	0x5c(%rsp), %r15d
   16820:      	subq	%rbx, %rax
   16823:      	movl	0x50(%rsp), %r12d
   16828:      	movl	%r15d, %edx
   1682b:      	subl	%r12d, %edx
   1682e:      	movl	$0x0, %ecx
   16833:      	cmovbl	%ecx, %edx
   16836:      	addq	0x60(%rsp), %rdx
   1683b:      	xorl	%esi, %esi
   1683d:      	cmpl	%r15d, %r12d
   16840:      	seta	%sil
   16844:      	movl	%r15d, %ecx
   16847:      	cmovbl	%r12d, %ecx
   1684b:      	addl	%ecx, %esi
   1684d:      	movl	%r12d, %edi
   16850:      	subl	%esi, %edi
   16852:      	movl	%edi, 0x50(%rsp)
   16856:      	subq	%rsi, %rax
   16859:      	jb	0x16d52 <generic_fentry_path+0xba72>
   1685f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   16865:      	ja	0x16d52 <generic_fentry_path+0xba72>
   1686b:      	cmpl	%r15d, %r12d
   1686e:      	jbe	0x16874 <generic_fentry_path+0xb594>
   16870:      	movb	$0x2f, (%rbx,%rax)
   16874:      	xorl	%edi, %edi
   16876:      	cmpl	%r15d, %r12d
   16879:      	seta	%dil
   1687d:      	movzbl	%cl, %esi
   16880:      	addq	%rax, %rbx
   16883:      	addq	%rbx, %rdi
   16886:      	movl	$0x4, %eax
   1688b:      	callq	*%rax
   1688d:      	movq	%rbx, 0x48(%rsp)
   16892:      	cmpl	%r15d, %r12d
   16895:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   1689b:      	movq	0x8(%rsp), %r12
   168a0:      	movq	%r12, 0x30(%rsp)
   168a5:      	movq	0x38(%rsp), %rdx
   168aa:      	movq	0x40(%rsp), %r15
   168af:      	jmp	0x16902 <generic_fentry_path+0xb622>
   168b1:      	leaq	0x10(%r15), %rdx
   168b5:      	movl	$0x4, %eax
   168ba:      	movq	%rbp, %rdi
   168bd:      	movl	$0x8, %esi
   168c2:      	callq	*%rax
   168c4:      	movq	0x40(%rsp), %rax
   168c9:      	cmpq	(%rsp), %rax
   168cd:      	je	0x16d4d <generic_fentry_path+0xba6d>
   168d3:      	addq	$0x18, %r15
   168d7:      	movl	$0x4, %eax
   168dc:      	leaq	0x30(%rsp), %rdi
   168e1:      	movl	$0x8, %esi
   168e6:      	movq	%r15, %rdx
   168e9:      	callq	*%rax
   168eb:      	movq	(%rsp), %r15
   168ef:      	movq	%r15, 0x40(%rsp)
   168f4:      	leaq	0x20(%r15), %rdx
   168f8:      	movq	%rdx, 0x38(%rsp)
   168fd:      	movq	0x30(%rsp), %r12
   16902:      	cmpq	0x18(%rsp), %r12
   16907:      	jne	0x16914 <generic_fentry_path+0xb634>
   16909:      	cmpq	0x20(%rsp), %rdx
   1690e:      	je	0x16d4d <generic_fentry_path+0xba6d>
   16914:      	movl	$0x4, %eax
   16919:      	leaq	0x10(%rsp), %rdi
   1691e:      	movl	$0x8, %esi
   16923:      	callq	*%rax
   16925:      	cmpq	0x10(%rsp), %r12
   1692a:      	je	0x16a22 <generic_fentry_path+0xb742>
   16930:      	leaq	0x18(%r12), %rbx
   16935:      	movl	$0x4, %eax
   1693a:      	movq	%rbp, %rdi
   1693d:      	movl	$0x8, %esi
   16942:      	movq	%rbx, %rdx
   16945:      	callq	*%rax
   16947:      	cmpq	%r12, (%rsp)
   1694b:      	je	0x16a22 <generic_fentry_path+0xb742>
   16951:      	movl	$0x4, %eax
   16956:      	leaq	0x8(%rsp), %rdi
   1695b:      	movl	$0x8, %esi
   16960:      	movq	%rbx, %rdx
   16963:      	callq	*%rax
   16965:      	addq	$0x20, %r12
   16969:      	movl	$0x4, %eax
   1696e:      	leaq	0x58(%rsp), %rdi
   16973:      	movl	$0x10, %ecx
   16978:      	movl	$0x10, %esi
   1697d:      	movq	%r12, %rdx
   16980:      	callq	*%rax
   16982:      	movq	0x28(%rsp), %rbx
   16987:      	movq	0x48(%rsp), %rax
   1698c:      	movl	0x5c(%rsp), %r15d
   16991:      	subq	%rbx, %rax
   16994:      	movl	0x50(%rsp), %r12d
   16999:      	movl	%r15d, %edx
   1699c:      	subl	%r12d, %edx
   1699f:      	movl	$0x0, %ecx
   169a4:      	cmovbl	%ecx, %edx
   169a7:      	addq	0x60(%rsp), %rdx
   169ac:      	xorl	%esi, %esi
   169ae:      	cmpl	%r15d, %r12d
   169b1:      	seta	%sil
   169b5:      	movl	%r15d, %ecx
   169b8:      	cmovbl	%r12d, %ecx
   169bc:      	addl	%ecx, %esi
   169be:      	movl	%r12d, %edi
   169c1:      	subl	%esi, %edi
   169c3:      	movl	%edi, 0x50(%rsp)
   169c7:      	subq	%rsi, %rax
   169ca:      	jb	0x16d52 <generic_fentry_path+0xba72>
   169d0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   169d6:      	ja	0x16d52 <generic_fentry_path+0xba72>
   169dc:      	cmpl	%r15d, %r12d
   169df:      	jbe	0x169e5 <generic_fentry_path+0xb705>
   169e1:      	movb	$0x2f, (%rbx,%rax)
   169e5:      	xorl	%edi, %edi
   169e7:      	cmpl	%r15d, %r12d
   169ea:      	seta	%dil
   169ee:      	movzbl	%cl, %esi
   169f1:      	addq	%rax, %rbx
   169f4:      	addq	%rbx, %rdi
   169f7:      	movl	$0x4, %eax
   169fc:      	callq	*%rax
   169fe:      	movq	%rbx, 0x48(%rsp)
   16a03:      	cmpl	%r15d, %r12d
   16a06:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   16a0c:      	movq	0x8(%rsp), %r12
   16a11:      	movq	%r12, 0x30(%rsp)
   16a16:      	movq	0x38(%rsp), %rdx
   16a1b:      	movq	0x40(%rsp), %r15
   16a20:      	jmp	0x16a73 <generic_fentry_path+0xb793>
   16a22:      	leaq	0x10(%r15), %rdx
   16a26:      	movl	$0x4, %eax
   16a2b:      	movq	%rbp, %rdi
   16a2e:      	movl	$0x8, %esi
   16a33:      	callq	*%rax
   16a35:      	movq	0x40(%rsp), %rax
   16a3a:      	cmpq	(%rsp), %rax
   16a3e:      	je	0x16d4d <generic_fentry_path+0xba6d>
   16a44:      	addq	$0x18, %r15
   16a48:      	movl	$0x4, %eax
   16a4d:      	leaq	0x30(%rsp), %rdi
   16a52:      	movl	$0x8, %esi
   16a57:      	movq	%r15, %rdx
   16a5a:      	callq	*%rax
   16a5c:      	movq	(%rsp), %r15
   16a60:      	movq	%r15, 0x40(%rsp)
   16a65:      	leaq	0x20(%r15), %rdx
   16a69:      	movq	%rdx, 0x38(%rsp)
   16a6e:      	movq	0x30(%rsp), %r12
   16a73:      	cmpq	0x18(%rsp), %r12
   16a78:      	jne	0x16a85 <generic_fentry_path+0xb7a5>
   16a7a:      	cmpq	0x20(%rsp), %rdx
   16a7f:      	je	0x16d4d <generic_fentry_path+0xba6d>
   16a85:      	movl	$0x4, %eax
   16a8a:      	leaq	0x10(%rsp), %rdi
   16a8f:      	movl	$0x8, %esi
   16a94:      	callq	*%rax
   16a96:      	cmpq	0x10(%rsp), %r12
   16a9b:      	je	0x16b93 <generic_fentry_path+0xb8b3>
   16aa1:      	leaq	0x18(%r12), %rbx
   16aa6:      	movl	$0x4, %eax
   16aab:      	movq	%rbp, %rdi
   16aae:      	movl	$0x8, %esi
   16ab3:      	movq	%rbx, %rdx
   16ab6:      	callq	*%rax
   16ab8:      	cmpq	%r12, (%rsp)
   16abc:      	je	0x16b93 <generic_fentry_path+0xb8b3>
   16ac2:      	movl	$0x4, %eax
   16ac7:      	leaq	0x8(%rsp), %rdi
   16acc:      	movl	$0x8, %esi
   16ad1:      	movq	%rbx, %rdx
   16ad4:      	callq	*%rax
   16ad6:      	addq	$0x20, %r12
   16ada:      	movl	$0x4, %eax
   16adf:      	leaq	0x58(%rsp), %rdi
   16ae4:      	movl	$0x10, %ecx
   16ae9:      	movl	$0x10, %esi
   16aee:      	movq	%r12, %rdx
   16af1:      	callq	*%rax
   16af3:      	movq	0x28(%rsp), %rbx
   16af8:      	movq	0x48(%rsp), %rax
   16afd:      	movl	0x5c(%rsp), %r15d
   16b02:      	subq	%rbx, %rax
   16b05:      	movl	0x50(%rsp), %r12d
   16b0a:      	movl	%r15d, %edx
   16b0d:      	subl	%r12d, %edx
   16b10:      	movl	$0x0, %ecx
   16b15:      	cmovbl	%ecx, %edx
   16b18:      	addq	0x60(%rsp), %rdx
   16b1d:      	xorl	%esi, %esi
   16b1f:      	cmpl	%r15d, %r12d
   16b22:      	seta	%sil
   16b26:      	movl	%r15d, %ecx
   16b29:      	cmovbl	%r12d, %ecx
   16b2d:      	addl	%ecx, %esi
   16b2f:      	movl	%r12d, %edi
   16b32:      	subl	%esi, %edi
   16b34:      	movl	%edi, 0x50(%rsp)
   16b38:      	subq	%rsi, %rax
   16b3b:      	jb	0x16d52 <generic_fentry_path+0xba72>
   16b41:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   16b47:      	ja	0x16d52 <generic_fentry_path+0xba72>
   16b4d:      	cmpl	%r15d, %r12d
   16b50:      	jbe	0x16b56 <generic_fentry_path+0xb876>
   16b52:      	movb	$0x2f, (%rbx,%rax)
   16b56:      	xorl	%edi, %edi
   16b58:      	cmpl	%r15d, %r12d
   16b5b:      	seta	%dil
   16b5f:      	movzbl	%cl, %esi
   16b62:      	addq	%rax, %rbx
   16b65:      	addq	%rbx, %rdi
   16b68:      	movl	$0x4, %eax
   16b6d:      	callq	*%rax
   16b6f:      	movq	%rbx, 0x48(%rsp)
   16b74:      	cmpl	%r15d, %r12d
   16b77:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   16b7d:      	movq	0x8(%rsp), %r12
   16b82:      	movq	%r12, 0x30(%rsp)
   16b87:      	movq	0x38(%rsp), %rdx
   16b8c:      	movq	0x40(%rsp), %r15
   16b91:      	jmp	0x16be4 <generic_fentry_path+0xb904>
   16b93:      	leaq	0x10(%r15), %rdx
   16b97:      	movl	$0x4, %eax
   16b9c:      	movq	%rbp, %rdi
   16b9f:      	movl	$0x8, %esi
   16ba4:      	callq	*%rax
   16ba6:      	movq	0x40(%rsp), %rax
   16bab:      	cmpq	(%rsp), %rax
   16baf:      	je	0x16d4d <generic_fentry_path+0xba6d>
   16bb5:      	addq	$0x18, %r15
   16bb9:      	movl	$0x4, %eax
   16bbe:      	leaq	0x30(%rsp), %rdi
   16bc3:      	movl	$0x8, %esi
   16bc8:      	movq	%r15, %rdx
   16bcb:      	callq	*%rax
   16bcd:      	movq	(%rsp), %r15
   16bd1:      	movq	%r15, 0x40(%rsp)
   16bd6:      	leaq	0x20(%r15), %rdx
   16bda:      	movq	%rdx, 0x38(%rsp)
   16bdf:      	movq	0x30(%rsp), %r12
   16be4:      	cmpq	0x18(%rsp), %r12
   16be9:      	jne	0x16bf6 <generic_fentry_path+0xb916>
   16beb:      	cmpq	0x20(%rsp), %rdx
   16bf0:      	je	0x16d4d <generic_fentry_path+0xba6d>
   16bf6:      	movl	$0x4, %eax
   16bfb:      	leaq	0x10(%rsp), %rdi
   16c00:      	movl	$0x8, %esi
   16c05:      	callq	*%rax
   16c07:      	cmpq	0x10(%rsp), %r12
   16c0c:      	je	0x16cf6 <generic_fentry_path+0xba16>
   16c12:      	leaq	0x18(%r12), %rbx
   16c17:      	movl	$0x4, %eax
   16c1c:      	movq	%rbp, %rdi
   16c1f:      	movl	$0x8, %esi
   16c24:      	movq	%rbx, %rdx
   16c27:      	callq	*%rax
   16c29:      	cmpq	%r12, (%rsp)
   16c2d:      	je	0x16cf6 <generic_fentry_path+0xba16>
   16c33:      	movl	$0x4, %eax
   16c38:      	leaq	0x8(%rsp), %rdi
   16c3d:      	movl	$0x8, %esi
   16c42:      	movq	%rbx, %rdx
   16c45:      	callq	*%rax
   16c47:      	addq	$0x20, %r12
   16c4b:      	movl	$0x4, %eax
   16c50:      	leaq	0x58(%rsp), %rdi
   16c55:      	movl	$0x10, %ecx
   16c5a:      	movl	$0x10, %esi
   16c5f:      	movq	%r12, %rdx
   16c62:      	callq	*%rax
   16c64:      	movq	0x28(%rsp), %rbx
   16c69:      	movq	0x48(%rsp), %rax
   16c6e:      	movl	0x5c(%rsp), %r15d
   16c73:      	subq	%rbx, %rax
   16c76:      	movl	0x50(%rsp), %r12d
   16c7b:      	movl	%r15d, %edx
   16c7e:      	subl	%r12d, %edx
   16c81:      	movl	$0x0, %ecx
   16c86:      	cmovbl	%ecx, %edx
   16c89:      	addq	0x60(%rsp), %rdx
   16c8e:      	xorl	%esi, %esi
   16c90:      	cmpl	%r15d, %r12d
   16c93:      	seta	%sil
   16c97:      	movl	%r15d, %ecx
   16c9a:      	cmovbl	%r12d, %ecx
   16c9e:      	addl	%ecx, %esi
   16ca0:      	movl	%r12d, %edi
   16ca3:      	subl	%esi, %edi
   16ca5:      	movl	%edi, 0x50(%rsp)
   16ca9:      	subq	%rsi, %rax
   16cac:      	jb	0x16d52 <generic_fentry_path+0xba72>
   16cb2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   16cb8:      	ja	0x16d52 <generic_fentry_path+0xba72>
   16cbe:      	cmpl	%r15d, %r12d
   16cc1:      	jbe	0x16cc7 <generic_fentry_path+0xb9e7>
   16cc3:      	movb	$0x2f, (%rbx,%rax)
   16cc7:      	xorl	%edi, %edi
   16cc9:      	cmpl	%r15d, %r12d
   16ccc:      	seta	%dil
   16cd0:      	movzbl	%cl, %esi
   16cd3:      	addq	%rax, %rbx
   16cd6:      	addq	%rbx, %rdi
   16cd9:      	movl	$0x4, %eax
   16cde:      	callq	*%rax
   16ce0:      	movq	%rbx, 0x48(%rsp)
   16ce5:      	cmpl	%r15d, %r12d
   16ce8:      	jbe	0x16d52 <generic_fentry_path+0xba72>
   16cea:      	movq	0x8(%rsp), %rax
   16cef:      	movq	%rax, 0x30(%rsp)
   16cf4:      	jmp	0x16d3e <generic_fentry_path+0xba5e>
   16cf6:      	leaq	0x10(%r15), %rdx
   16cfa:      	movl	$0x4, %eax
   16cff:      	movq	%rbp, %rdi
   16d02:      	movl	$0x8, %esi
   16d07:      	callq	*%rax
   16d09:      	movq	0x40(%rsp), %rax
   16d0e:      	cmpq	(%rsp), %rax
   16d12:      	je	0x16d4d <generic_fentry_path+0xba6d>
   16d14:      	addq	$0x18, %r15
   16d18:      	movl	$0x4, %eax
   16d1d:      	leaq	0x30(%rsp), %rdi
   16d22:      	movl	$0x8, %esi
   16d27:      	movq	%r15, %rdx
   16d2a:      	callq	*%rax
   16d2c:      	movq	(%rsp), %rax
   16d30:      	movq	%rax, 0x40(%rsp)
   16d35:      	addq	$0x20, %rax
   16d39:      	movq	%rax, 0x38(%rsp)
   16d3e:      	movl	0x6c(%rsp), %eax
   16d42:      	addl	$-0x80, %eax
   16d45:      	jne	0xb483 <generic_fentry_path+0x1a3>
   16d4b:      	jmp	0x16d52 <generic_fentry_path+0xba72>
   16d4d:      	movb	$0x1, 0x54(%rsp)
   16d52:      	movl	0x6428(%r14), %eax
   16d59:      	incl	%eax
   16d5b:      	movl	%eax, 0x6428(%r14)
   16d62:      	movl	0x48(%rsp), %ecx
   16d66:      	subl	0x80(%rsp), %ecx
   16d6d:      	movl	%ecx, 0x6424(%r14)
   16d74:      	cmpb	$0x0, 0x54(%rsp)
   16d79:      	jne	0x16dc1 <generic_fentry_path+0xbae1>
   16d7b:      	cmpl	$0x8, %eax
   16d7e:      	je	0x16dc1 <generic_fentry_path+0xbae1>
   16d80:      	movq	0x30(%rsp), %rax
   16d85:      	movq	%rax, 0x6458(%r14)
   16d8c:      	movq	0x38(%rsp), %rax
   16d91:      	movq	%rax, 0x6460(%r14)
   16d98:      	movq	0x40(%rsp), %rax
   16d9d:      	movq	%rax, 0x6468(%r14)
   16da4:      	movq	(%rip), %rcx            # 0x16dab <generic_fentry_path+0xbacb>
   16dab:      	movl	$0x6, %edx
   16db0:      	movl	$0xc, %eax
   16db5:      	movq	0x78(%rsp), %rdi
   16dba:      	movl	$0x6, %edx
   16dbf:      	jmp	0x16ddc <generic_fentry_path+0xbafc>
   16dc1:      	movq	(%rip), %rcx            # 0x16dc8 <generic_fentry_path+0xbae8>
   16dc8:      	movl	$0x1, %edx
   16dcd:      	movl	$0xc, %eax
   16dd2:      	movq	0x78(%rsp), %rdi
   16dd7:      	movl	$0x1, %edx
   16ddc:      	movq	(%rip), %rsi            # 0x16de3 <generic_fentry_path+0xbb03>
   16de3:      	jmp	0x17157 <generic_fentry_path+0xbe77>
   16de8:      	movl	$0x1, (%rsp)
   16def:      	movq	(%rip), %rdi            # 0x16df6 <generic_fentry_path+0xbb16>
   16df6:      	xorl	%ecx, %ecx
   16df8:      	leaq	0x18(%rsp), %rsi
   16dfd:      	movq	%rsp, %rdx
   16e00:      	movl	$0x2, %eax
   16e05:      	xorl	%ecx, %ecx
   16e07:      	callq	*%rax
   16e09:      	movq	0x58(%rsp), %r12
   16e0e:      	leaq	0x10(%r12), %rdx
   16e13:      	leaq	0x18(%rsp), %rdi
   16e18:      	movl	$0x8, %ecx
   16e1d:      	movl	$0x4, %eax
   16e22:      	leaq	0xfff(%r15), %rbx
   16e29:      	movl	$0x8, %esi
   16e2e:      	callq	*%rax
   16e30:      	cmpq	$0x0, 0x18(%rsp)
   16e36:      	jne	0x16e7f <generic_fentry_path+0xbb9f>
   16e38:      	leaq	0x18(%r12), %rdx
   16e3d:      	leaq	0x18(%rsp), %rdi
   16e42:      	movl	$0x8, %ecx
   16e47:      	movl	$0x4, %eax
   16e4c:      	movl	$0x8, %esi
   16e51:      	callq	*%rax
   16e53:      	cmpq	%r12, 0x18(%rsp)
   16e58:      	je	0x16e7f <generic_fentry_path+0xbb9f>
   16e5a:      	movq	%r15, %rbx
   16e5d:      	addq	$0xff5, %rbx            # imm = 0xFF5
   16e64:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
   16e6e:      	movq	%rax, 0xff5(%r15)
   16e75:      	movw	$0x2964, 0xffd(%r15)    # imm = 0x2964
   16e7f:      	movl	$0x23, %eax
   16e84:      	callq	*%rax
   16e86:      	leaq	0xd50(%rax), %rdx
   16e8d:      	movq	%rsp, %rdi
   16e90:      	movl	$0x8, %ecx
   16e95:      	movl	$0x4, %eax
   16e9a:      	movl	$0x8, %esi
   16e9f:      	callq	*%rax
   16ea1:      	testq	%rax, %rax
   16ea4:      	je	0x16f03 <generic_fentry_path+0xbc23>
   16ea6:      	negl	%eax
   16ea8:      	movw	%ax, 0x18(%rsp)
   16ead:      	movw	$0x6, 0x1a(%rsp)
   16eb4:      	movabsq	$0x400000033, %rax      # imm = 0x400000033
   16ebe:      	movq	%rax, 0x1c(%rsp)
   16ec3:      	movq	(%rip), %rdi            # 0x16eca <generic_fentry_path+0xbbea>
   16eca:      	leaq	0x18(%rsp), %rsi
   16ecf:      	movl	$0x1, %eax
   16ed4:      	callq	*%rax
   16ed6:      	testq	%rax, %rax
   16ed9:      	je	0x16edf <generic_fentry_path+0xbbff>
   16edb:      	incl	(%rax)
   16edd:      	jmp	0x16f03 <generic_fentry_path+0xbc23>
   16edf:      	movl	$0x1, 0x8(%rsp)
   16ee7:      	movq	(%rip), %rdi            # 0x16eee <generic_fentry_path+0xbc0e>
   16eee:      	xorl	%ecx, %ecx
   16ef0:      	leaq	0x18(%rsp), %rsi
   16ef5:      	leaq	0x8(%rsp), %rdx
   16efa:      	movl	$0x2, %eax
   16eff:      	xorl	%ecx, %ecx
   16f01:      	callq	*%rax
   16f03:      	movq	(%rsp), %rdx
   16f07:      	leaq	0x18(%rdx), %r13
   16f0b:      	movq	0x6440(%r14), %r12
   16f12:      	leaq	0x6448(%r14), %rdi
   16f19:      	addq	$0x20, %rdx
   16f1d:      	movl	$0x8, %ecx
   16f22:      	movl	$0x4, %eax
   16f27:      	movl	$0x8, %esi
   16f2c:      	callq	*%rax
   16f2e:      	testq	%rax, %rax
   16f31:      	je	0x16f90 <generic_fentry_path+0xbcb0>
   16f33:      	negl	%eax
   16f35:      	movw	%ax, 0x18(%rsp)
   16f3a:      	movw	$0x6, 0x1a(%rsp)
   16f41:      	movabsq	$0x400000038, %rax      # imm = 0x400000038
   16f4b:      	movq	%rax, 0x1c(%rsp)
   16f50:      	movq	(%rip), %rdi            # 0x16f57 <generic_fentry_path+0xbc77>
   16f57:      	leaq	0x18(%rsp), %rsi
   16f5c:      	movl	$0x1, %eax
   16f61:      	callq	*%rax
   16f63:      	testq	%rax, %rax
   16f66:      	je	0x16f6c <generic_fentry_path+0xbc8c>
   16f68:      	incl	(%rax)
   16f6a:      	jmp	0x16f90 <generic_fentry_path+0xbcb0>
   16f6c:      	movl	$0x1, 0x8(%rsp)
   16f74:      	movq	(%rip), %rdi            # 0x16f7b <generic_fentry_path+0xbc9b>
   16f7b:      	xorl	%ecx, %ecx
   16f7d:      	leaq	0x18(%rsp), %rsi
   16f82:      	leaq	0x8(%rsp), %rdx
   16f87:      	movl	$0x2, %eax
   16f8c:      	xorl	%ecx, %ecx
   16f8e:      	callq	*%rax
   16f90:      	leaq	0x6450(%r14), %rdi
   16f97:      	movl	$0x8, %ecx
   16f9c:      	movl	$0x4, %eax
   16fa1:      	movl	$0x8, %esi
   16fa6:      	movq	%r13, %rdx
   16fa9:      	callq	*%rax
   16fab:      	testq	%rax, %rax
   16fae:      	je	0x1700d <generic_fentry_path+0xbd2d>
   16fb0:      	negl	%eax
   16fb2:      	movw	%ax, 0x18(%rsp)
   16fb7:      	movw	$0x6, 0x1a(%rsp)
   16fbe:      	movabsq	$0x400000039, %rax      # imm = 0x400000039
   16fc8:      	movq	%rax, 0x1c(%rsp)
   16fcd:      	movq	(%rip), %rdi            # 0x16fd4 <generic_fentry_path+0xbcf4>
   16fd4:      	leaq	0x18(%rsp), %rsi
   16fd9:      	movl	$0x1, %eax
   16fde:      	callq	*%rax
   16fe0:      	testq	%rax, %rax
   16fe3:      	je	0x16fe9 <generic_fentry_path+0xbd09>
   16fe5:      	incl	(%rax)
   16fe7:      	jmp	0x1700d <generic_fentry_path+0xbd2d>
   16fe9:      	movl	$0x1, 0x8(%rsp)
   16ff1:      	movq	(%rip), %rdi            # 0x16ff8 <generic_fentry_path+0xbd18>
   16ff8:      	xorl	%ecx, %ecx
   16ffa:      	leaq	0x18(%rsp), %rsi
   16fff:      	leaq	0x8(%rsp), %rdx
   17004:      	movl	$0x2, %eax
   17009:      	xorl	%ecx, %ecx
   1700b:      	callq	*%rax
   1700d:      	leaq	0x6458(%r14), %rdi
   17014:      	leaq	0x8(%r12), %rdx
   17019:      	movl	$0x8, %ecx
   1701e:      	movl	$0x4, %eax
   17023:      	movl	$0x8, %esi
   17028:      	callq	*%rax
   1702a:      	testq	%rax, %rax
   1702d:      	je	0x1708c <generic_fentry_path+0xbdac>
   1702f:      	negl	%eax
   17031:      	movw	%ax, 0x18(%rsp)
   17036:      	movw	$0x6, 0x1a(%rsp)
   1703d:      	movabsq	$0x40000003a, %rax      # imm = 0x40000003A
   17047:      	movq	%rax, 0x1c(%rsp)
   1704c:      	movq	(%rip), %rdi            # 0x17053 <generic_fentry_path+0xbd73>
   17053:      	leaq	0x18(%rsp), %rsi
   17058:      	movl	$0x1, %eax
   1705d:      	callq	*%rax
   1705f:      	testq	%rax, %rax
   17062:      	je	0x17068 <generic_fentry_path+0xbd88>
   17064:      	incl	(%rax)
   17066:      	jmp	0x1708c <generic_fentry_path+0xbdac>
   17068:      	movl	$0x1, 0x8(%rsp)
   17070:      	movq	(%rip), %rdi            # 0x17077 <generic_fentry_path+0xbd97>
   17077:      	xorl	%ecx, %ecx
   17079:      	leaq	0x18(%rsp), %rsi
   1707e:      	leaq	0x8(%rsp), %rdx
   17083:      	movl	$0x2, %eax
   17088:      	xorl	%ecx, %ecx
   1708a:      	callq	*%rax
   1708c:      	movq	%r14, %rdi
   1708f:      	addq	$0x6460, %rdi           # imm = 0x6460
   17096:      	movl	$0x8, %ecx
   1709b:      	movl	$0x4, %eax
   170a0:      	movl	$0x8, %esi
   170a5:      	movq	%r12, %rdx
   170a8:      	callq	*%rax
   170aa:      	testq	%rax, %rax
   170ad:      	je	0x1710c <generic_fentry_path+0xbe2c>
   170af:      	negl	%eax
   170b1:      	movw	%ax, 0x18(%rsp)
   170b6:      	movw	$0x6, 0x1a(%rsp)
   170bd:      	movabsq	$0x40000003b, %rax      # imm = 0x40000003B
   170c7:      	movq	%rax, 0x1c(%rsp)
   170cc:      	movq	(%rip), %rdi            # 0x170d3 <generic_fentry_path+0xbdf3>
   170d3:      	leaq	0x18(%rsp), %rsi
   170d8:      	movl	$0x1, %eax
   170dd:      	callq	*%rax
   170df:      	testq	%rax, %rax
   170e2:      	je	0x170e8 <generic_fentry_path+0xbe08>
   170e4:      	incl	(%rax)
   170e6:      	jmp	0x1710c <generic_fentry_path+0xbe2c>
   170e8:      	movl	$0x1, 0x8(%rsp)
   170f0:      	movq	(%rip), %rdi            # 0x170f7 <generic_fentry_path+0xbe17>
   170f7:      	xorl	%ecx, %ecx
   170f9:      	leaq	0x18(%rsp), %rsi
   170fe:      	leaq	0x8(%rsp), %rdx
   17103:      	movl	$0x2, %eax
   17108:      	xorl	%ecx, %ecx
   1710a:      	callq	*%rax
   1710c:      	movq	0x6460(%r14), %rax
   17113:      	addq	$-0x20, %rax
   17117:      	movq	%rax, 0x6468(%r14)
   1711e:      	movl	$0x0, 0x6428(%r14)
   17129:      	subl	%r15d, %ebx
   1712c:      	movl	%ebx, 0x6424(%r14)
   17133:      	movl	$0x1, 0x6420(%r14)
   1713e:      	movq	(%rip), %rsi            # 0x17145 <generic_fentry_path+0xbe65>
   17145:      	movl	$0x6, %ecx
   1714a:      	movl	$0xc, %eax
   1714f:      	movq	%rbp, %rdi
   17152:      	movl	$0x6, %edx
   17157:      	callq	*%rax
   17159:      	xorl	%eax, %eax
   1715b:      	addq	$0x88, %rsp
   17162:      	popq	%rbx
   17163:      	popq	%r12
   17165:      	popq	%r13
   17167:      	popq	%r14
   17169:      	popq	%r15
   1716b:      	popq	%rbp
   1716c:      	retq

Disassembly of section fentry/generic_fentry:

0000000000000000 <generic_fentry_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x88, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x38(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <generic_fentry_event+0x23>
      23:      	leaq	0x38(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x62d <generic_fentry_event+0x62d>
      38:      	movq	%rax, %r14
      3b:      	leaq	0x5ef8(%rax), %rsi
      42:      	movl	$0x0, 0x5ef8(%rax)
      4c:      	movq	(%rip), %rdi            # 0x53 <generic_fentry_event+0x53>
      53:      	movl	$0x1, %eax
      58:      	callq	*%rax
      5a:      	testq	%rax, %rax
      5d:      	je	0x62d <generic_fentry_event+0x62d>
      63:      	movl	0x64(%rax), %ecx
      66:      	movl	%ecx, 0x14(%rsp)
      6a:      	testl	%ecx, %ecx
      6c:      	je	0x23b <generic_fentry_event+0x23b>
      72:      	movq	%rax, %r12
      75:      	movq	(%rip), %rdi            # 0x7c <generic_fentry_event+0x7c>
      7c:      	leaq	0x14(%rsp), %rsi
      81:      	movl	$0x1, %eax
      86:      	callq	*%rax
      88:      	testq	%rax, %rax
      8b:      	je	0x62d <generic_fentry_event+0x62d>
      91:      	movq	%rax, %r15
      94:      	movl	$0x0, 0x3c(%rsp)
      9c:      	movq	(%rip), %rdi            # 0xa3 <generic_fentry_event+0xa3>
      a3:      	leaq	0x3c(%rsp), %rsi
      a8:      	movl	$0x1, %eax
      ad:      	callq	*%rax
      af:      	testq	%rax, %rax
      b2:      	je	0xd8 <generic_fentry_event+0xd8>
      b4:      	cmpq	$0x63677270, 0x20(%rax) # imm = 0x63677270
      bc:      	jne	0xdc <generic_fentry_event+0xdc>
      be:      	movl	$0x50, %eax
      c3:      	callq	*%rax
      c5:      	movq	%rax, 0x8(%rsp)
      ca:      	testq	%rax, %rax
      cd:      	jne	0x1f6 <generic_fentry_event+0x1f6>
      d3:      	jmp	0x62d <generic_fentry_event+0x62d>
      d8:      	xorl	%ebp, %ebp
      da:      	jmp	0xdf <generic_fentry_event+0xdf>
      dc:      	movl	0x10(%rax), %ebp
      df:      	movl	$0x23, %eax
      e4:      	callq	*%rax
      e6:      	movq	$0x0, 0x20(%rsp)
      ef:      	leaq	0xf90(%rax), %rdx
      f6:      	leaq	0x28(%rsp), %rdi
      fb:      	movl	$0x8, %ecx
     100:      	movl	$0x71, %eax
     105:      	movl	$0x8, %esi
     10a:      	callq	*%rax
     10c:      	movq	0x28(%rsp), %rax
     111:      	testq	%rax, %rax
     114:      	je	0x62d <generic_fentry_event+0x62d>
     11a:      	cmpl	$0xb, %ebp
     11d:      	ja	0x62d <generic_fentry_event+0x62d>
     123:      	movl	%ebp, %edx
     125:      	leaq	(%rax,%rdx,8), %rcx
     129:      	leaq	0x40(%rsp), %rdi
     12e:      	movl	$0x8, %esi
     133:      	movl	$0x71, %eax
     138:      	shlq	$0x3, %rdx
     13c:      	addq	0x28(%rsp), %rdx
     141:      	movl	$0x8, %esi
     146:      	callq	*%rax
     148:      	movq	0x40(%rsp), %rcx
     14d:      	testq	%rcx, %rcx
     150:      	je	0x62d <generic_fentry_event+0x62d>
     156:      	leaq	0x20(%rsp), %rdi
     15b:      	movl	$0x8, %edx
     160:      	movl	$0x71, %eax
     165:      	movq	0x40(%rsp), %rdx
     16a:      	movl	$0x8, %esi
     16f:      	callq	*%rax
     171:      	movq	0x20(%rsp), %rdx
     176:      	testq	%rdx, %rdx
     179:      	je	0x62d <generic_fentry_event+0x62d>
     17f:      	movq	$0x0, 0x40(%rsp)
     188:      	addq	$0x100, %rdx            # imm = 0x100
     18f:      	leaq	0x40(%rsp), %rdi
     194:      	movl	$0x8, %ecx
     199:      	movl	$0x71, %eax
     19e:      	movl	$0x8, %esi
     1a3:      	callq	*%rax
     1a5:      	movq	0x40(%rsp), %rdx
     1aa:      	movq	$0x0, 0x40(%rsp)
     1b3:      	testq	%rdx, %rdx
     1b6:      	je	0x1e6 <generic_fentry_event+0x1e6>
     1b8:      	addq	$0x60, %rdx
     1bc:      	leaq	0x40(%rsp), %rdi
     1c1:      	movl	$0x8, %ecx
     1c6:      	movl	$0x71, %eax
     1cb:      	movl	$0x8, %esi
     1d0:      	callq	*%rax
     1d2:      	movq	0x40(%rsp), %rax
     1d7:      	movq	%rax, 0x8(%rsp)
     1dc:      	testq	%rax, %rax
     1df:      	jne	0x1f6 <generic_fentry_event+0x1f6>
     1e1:      	jmp	0x62d <generic_fentry_event+0x62d>
     1e6:      	xorl	%eax, %eax
     1e8:      	movq	%rax, 0x8(%rsp)
     1ed:      	testq	%rax, %rax
     1f0:      	je	0x62d <generic_fentry_event+0x62d>
     1f6:      	movq	%rax, 0x40(%rsp)
     1fb:      	movq	(%rip), %rdi            # 0x202 <generic_fentry_event+0x202>
     202:      	leaq	0x40(%rsp), %rsi
     207:      	movl	$0x1, %eax
     20c:      	callq	*%rax
     20e:      	testq	%rax, %rax
     211:      	je	0x220 <generic_fentry_event+0x220>
     213:      	movq	(%rax), %rax
     216:      	testq	%rax, %rax
     219:      	je	0x220 <generic_fentry_event+0x220>
     21b:      	movq	%rax, 0x8(%rsp)
     220:      	leaq	0x8(%rsp), %rsi
     225:      	movl	$0x1, %eax
     22a:      	movq	%r15, %rdi
     22d:      	callq	*%rax
     22f:      	testq	%rax, %rax
     232:      	movq	%r12, %rax
     235:      	je	0x641 <generic_fentry_event+0x641>
     23b:      	movl	(%rax), %eax
     23d:      	movq	%rax, 0x60(%r14)
     241:      	movq	$0x0, 0x68(%r14)
     249:      	movq	$0x0, 0x5efc(%r14)
     254:      	movl	$0x0, 0x6420(%r14)
     25f:      	movq	$0x0, 0x5eb8(%r14)
     26a:      	movq	$0x0, 0x5ec0(%r14)
     275:      	movq	$0x0, 0x5ec8(%r14)
     280:      	movq	$0x0, 0x5ed0(%r14)
     28b:      	movq	$0x0, 0x5ed8(%r14)
     296:      	movb	$0x0, 0x5ee0(%r14)
     29e:      	movl	$0x23, %eax
     2a3:      	callq	*%rax
     2a5:      	movq	%rax, %r15
     2a8:      	leaq	0xd70(%rax), %rdx
     2af:      	leaq	0x20(%rsp), %rdi
     2b4:      	movl	$0x8, %ecx
     2b9:      	movl	$0x4, %eax
     2be:      	leaq	0x20(%r14), %r12
     2c2:      	movl	$0x4, %r13d
     2c8:      	movl	$0x8, %esi
     2cd:      	callq	*%rax
     2cf:      	movq	0x20(%rsp), %rcx
     2d4:      	leaq	0x40(%rsp), %rdi
     2d9:      	movl	$0x48, %edx
     2de:      	movl	$0x4, %eax
     2e3:      	movq	0x20(%rsp), %rdx
     2e8:      	movl	$0x48, %esi
     2ed:      	callq	*%rax
     2ef:      	movl	$0x218, %edx            # imm = 0x218
     2f4:      	movq	0x48(%rsp), %rcx
     2f9:      	addq	%rdx, %rcx
     2fc:      	movl	$0x4, %esi
     301:      	movl	$0x4, %eax
     306:      	addq	0x48(%rsp), %rdx
     30b:      	movq	%r12, %rdi
     30e:      	movl	$0x4, %esi
     313:      	callq	*%rax
     315:      	leaq	0x24(%r14), %rdi
     319:      	movl	$0x4d8, %edx            # imm = 0x4D8
     31e:      	movq	0x50(%rsp), %rcx
     323:      	addq	%rdx, %rcx
     326:      	movl	$0x4, %esi
     32b:      	movl	$0x4, %eax
     330:      	addq	0x50(%rsp), %rdx
     335:      	movl	$0x4, %esi
     33a:      	callq	*%rax
     33c:      	leaq	0x28(%r14), %rdi
     340:      	movq	0x58(%rsp), %rcx
     345:      	addq	$0x58, %rcx
     349:      	movl	$0x4, %edx
     34e:      	movl	$0x4, %eax
     353:      	movq	0x58(%rsp), %rdx
     358:      	addq	$0x58, %rdx
     35c:      	movl	$0x4, %esi
     361:      	callq	*%rax
     363:      	movq	$0x0, 0x8(%rsp)
     36c:      	leaq	0xb58(%r15), %rdx
     373:      	leaq	0x8(%rsp), %rdi
     378:      	movl	$0x8, %ecx
     37d:      	movl	$0x4, %eax
     382:      	movl	$0x8, %esi
     387:      	callq	*%rax
     389:      	movq	0x8(%rsp), %rcx
     38e:      	testq	%rcx, %rcx
     391:      	je	0x427 <generic_fentry_event+0x427>
     397:      	movl	$0x0, 0x18(%rsp)
     39f:      	addq	$0x4, %rcx
     3a3:      	leaq	0x18(%rsp), %rdi
     3a8:      	movl	$0x4, %eax
     3ad:      	movq	0x8(%rsp), %rdx
     3b2:      	addq	$0x4, %rdx
     3b6:      	movl	$0x4, %esi
     3bb:      	callq	*%rax
     3bd:      	movq	0x8(%rsp), %rax
     3c2:      	movslq	0x18(%rsp), %rcx
     3c7:      	shlq	$0x4, %rcx
     3cb:      	addq	%rax, %rcx
     3ce:      	addq	$0x80, %rcx
     3d5:      	leaq	0x28(%rsp), %rdi
     3da:      	movl	$0x10, %edx
     3df:      	movl	$0x4, %eax
     3e4:      	movq	0x8(%rsp), %rcx
     3e9:      	movslq	0x18(%rsp), %rdx
     3ee:      	shlq	$0x4, %rdx
     3f2:      	addq	%rcx, %rdx
     3f5:      	addq	$0x80, %rdx
     3fc:      	movl	$0x10, %esi
     401:      	callq	*%rax
     403:      	leaq	0x2c(%r14), %rdi
     407:      	movl	$0x158, %edx            # imm = 0x158
     40c:      	movq	0x30(%rsp), %rcx
     411:      	addq	%rdx, %rcx
     414:      	movl	$0x4, %eax
     419:      	addq	0x30(%rsp), %rdx
     41e:      	movl	$0x4, %esi
     423:      	callq	*%rax
     425:      	jmp	0x42f <generic_fentry_event+0x42f>
     427:      	movl	$0x0, 0x2c(%r14)
     42f:      	leaq	0x30(%r14), %rdi
     433:      	movl	$0x158, %r12d           # imm = 0x158
     439:      	movq	0x60(%rsp), %rcx
     43e:      	addq	%r12, %rcx
     441:      	movl	$0x4, %edx
     446:      	movl	$0x4, %eax
     44b:      	movq	0x60(%rsp), %rdx
     450:      	addq	%r12, %rdx
     453:      	movl	$0x4, %esi
     458:      	callq	*%rax
     45a:      	leaq	0x34(%r14), %rdi
     45e:      	movl	$0x118, %edx            # imm = 0x118
     463:      	movq	0x68(%rsp), %rcx
     468:      	addq	%rdx, %rcx
     46b:      	movl	$0x4, %esi
     470:      	movl	$0x4, %eax
     475:      	addq	0x68(%rsp), %rdx
     47a:      	movl	$0x4, %esi
     47f:      	callq	*%rax
     481:      	leaq	0x38(%r14), %rdi
     485:      	movl	$0x98, %r13d
     48b:      	movq	0x70(%rsp), %rcx
     490:      	addq	%r13, %rcx
     493:      	movl	$0x4, %edx
     498:      	movl	$0x4, %eax
     49d:      	movq	0x70(%rsp), %rdx
     4a2:      	addq	%r13, %rdx
     4a5:      	movl	$0x4, %esi
     4aa:      	callq	*%rax
     4ac:      	leaq	0x3c(%r14), %rdi
     4b0:      	movq	0x78(%rsp), %rcx
     4b5:      	addq	%r13, %rcx
     4b8:      	movl	$0x4, %edx
     4bd:      	movl	$0x4, %eax
     4c2:      	addq	0x78(%rsp), %r13
     4c7:      	movl	$0x4, %esi
     4cc:      	movq	%r13, %rdx
     4cf:      	callq	*%rax
     4d1:      	leaq	0x40(%r14), %rdi
     4d5:      	movq	0x80(%rsp), %rcx
     4dd:      	addq	$0x58, %rcx
     4e1:      	movl	$0x4, %edx
     4e6:      	movl	$0x4, %eax
     4eb:      	movq	0x80(%rsp), %rdx
     4f3:      	addq	$0x58, %rdx
     4f7:      	movl	$0x4, %esi
     4fc:      	callq	*%rax
     4fe:      	movq	$0x0, 0x28(%rsp)
     507:      	movq	$0x0, 0x8(%rsp)
     510:      	addq	$0xd00, %r15            # imm = 0xD00
     517:      	leaq	0x28(%rsp), %rdi
     51c:      	movl	$0x8, %ecx
     521:      	movl	$0x4, %eax
     526:      	movl	$0x8, %esi
     52b:      	movq	%r15, %rdx
     52e:      	callq	*%rax
     530:      	movl	$0x90, %edx
     535:      	movq	0x28(%rsp), %rcx
     53a:      	addq	%rdx, %rcx
     53d:      	leaq	0x8(%rsp), %rdi
     542:      	movl	$0x8, %esi
     547:      	movl	$0x4, %eax
     54c:      	addq	0x28(%rsp), %rdx
     551:      	movl	$0x8, %esi
     556:      	callq	*%rax
     558:      	leaq	0x44(%r14), %rdi
     55c:      	movq	0x8(%rsp), %rcx
     561:      	addq	%r12, %rcx
     564:      	movl	$0x4, %edx
     569:      	movl	$0x4, %eax
     56e:      	addq	0x8(%rsp), %r12
     573:      	movl	$0x4, %esi
     578:      	movq	%r12, %rdx
     57b:      	callq	*%rax
     57d:      	leaq	0x48(%r14), %r12
     581:      	leaq	0x40(%rsp), %rdi
     586:      	movl	$0x8, %ecx
     58b:      	movl	$0x4, %eax
     590:      	movl	$0x8, %esi
     595:      	movq	%r15, %rdx
     598:      	callq	*%rax
     59a:      	movq	0x40(%rsp), %r15
     59f:      	leaq	0x50(%r14), %rdi
     5a3:      	leaq	0x40(%r15), %rdx
     5a7:      	movl	$0x8, %ecx
     5ac:      	movl	$0x4, %eax
     5b1:      	movl	$0x8, %esi
     5b6:      	callq	*%rax
     5b8:      	movq	%r14, %rdi
     5bb:      	addq	$0x58, %rdi
     5bf:      	leaq	0x30(%r15), %rdx
     5c3:      	movl	$0x8, %ecx
     5c8:      	movl	$0x4, %eax
     5cd:      	movl	$0x8, %esi
     5d2:      	callq	*%rax
     5d4:      	addq	$0x38, %r15
     5d8:      	movl	$0x8, %ecx
     5dd:      	movl	$0x4, %eax
     5e2:      	movq	%r12, %rdi
     5e5:      	movl	$0x8, %esi
     5ea:      	movq	%r15, %rdx
     5ed:      	callq	*%rax
     5ef:      	movb	$0x0, 0x5f08(%r14)
     5f7:      	movb	$0x0, 0x1(%r14)
     5fc:      	movq	$0x0, 0x5ee8(%r14)
     607:      	movq	$0x0, 0x5ef0(%r14)
     612:      	movq	(%rip), %rsi            # 0x619 <generic_fentry_event+0x619>
     619:      	movl	$0x2, %ecx
     61e:      	movl	$0xc, %eax
     623:      	movq	%rbx, %rdi
     626:      	movl	$0x2, %edx
     62b:      	callq	*%rax
     62d:      	xorl	%eax, %eax
     62f:      	addq	$0x88, %rsp
     636:      	popq	%rbx
     637:      	popq	%r12
     639:      	popq	%r13
     63b:      	popq	%r14
     63d:      	popq	%r15
     63f:      	popq	%rbp
     640:      	retq
     641:      	movq	$-0x1, 0x18(%rsp)
     64a:      	leaq	0x18(%rsp), %rsi
     64f:      	movl	$0x1, %eax
     654:      	movq	%r15, %rdi
     657:      	callq	*%rax
     659:      	testq	%rax, %rax
     65c:      	je	0x62d <generic_fentry_event+0x62d>
     65e:      	movl	$0x1, 0x14(%rsp)
     666:      	movq	(%rip), %rdi            # 0x66d <generic_fentry_event+0x66d>
     66d:      	leaq	0x14(%rsp), %rsi
     672:      	movl	$0x1, %eax
     677:      	callq	*%rax
     679:      	testq	%rax, %rax
     67c:      	je	0x62d <generic_fentry_event+0x62d>
     67e:      	movq	%rax, %rdi
     681:      	leaq	0x8(%rsp), %rsi
     686:      	movl	$0x1, %eax
     68b:      	callq	*%rax
     68d:      	testq	%rax, %rax
     690:      	movq	%r12, %rax
     693:      	jne	0x62d <generic_fentry_event+0x62d>
     695:      	jmp	0x23b <generic_fentry_event+0x23b>
