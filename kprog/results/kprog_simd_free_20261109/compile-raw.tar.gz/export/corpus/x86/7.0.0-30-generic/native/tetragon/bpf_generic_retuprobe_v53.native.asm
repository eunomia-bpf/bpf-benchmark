
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_generic_retuprobe_v53.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
       5:      	testq	%rdx, %rdx
       8:      	je	0x74 <native_bpf_strncasestr+0x74>
       a:      	pushq	%rbx
       b:      	xorl	%ecx, %ecx
       d:      	jmp	0x1b <native_bpf_strncasestr+0x1b>
       f:      	nop
      10:      	incq	%rcx
      13:      	incq	%rdi
      16:      	cmpq	%rdx, %rcx
      19:      	je	0x73 <native_bpf_strncasestr+0x73>
      1b:      	xorl	%r8d, %r8d
      1e:      	nop
      20:      	leaq	(%rcx,%r8), %r9
      24:      	cmpq	%rdx, %r9
      27:      	jae	0x10 <native_bpf_strncasestr+0x10>
      29:      	movsbl	(%rsi,%r8), %r9d
      2e:      	testl	%r9d, %r9d
      31:      	je	0x71 <native_bpf_strncasestr+0x71>
      33:      	movsbl	(%rdi,%r8), %r10d
      38:      	leal	-0x41(%r10), %r11d
      3c:      	movl	%r10d, %ebx
      3f:      	orl	$0x20, %ebx
      42:      	cmpl	$0x1a, %r11d
      46:      	cmovael	%r10d, %ebx
      4a:      	leal	-0x41(%r9), %r10d
      4e:      	movl	%r9d, %r11d
      51:      	orl	$0x20, %r11d
      55:      	cmpl	$0x1a, %r10d
      59:      	cmovael	%r9d, %r11d
      5d:      	cmpl	%r11d, %ebx
      60:      	jne	0x10 <native_bpf_strncasestr+0x10>
      62:      	leaq	0x1(%r8), %r9
      66:      	cmpq	$0x63, %r8
      6a:      	movq	%r9, %r8
      6d:      	jb	0x20 <native_bpf_strncasestr+0x20>
      6f:      	jmp	0x10 <native_bpf_strncasestr+0x10>
      71:      	movl	%ecx, %eax
      73:      	popq	%rbx
      74:      	retq

Disassembly of section uprobe:

0000000000000000 <generic_retuprobe_filter_arg>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xb8, %rsp
      11:      	movq	%rdi, %r12
      14:      	movl	$0x0, 0xa4(%rsp)
      1f:      	movq	(%rip), %rdi            # 0x26 <generic_retuprobe_filter_arg+0x26>
      26:      	leaq	0xa4(%rsp), %rsi
      2e:      	movl	$0x1, %eax
      33:      	callq	*%rax
      35:      	testq	%rax, %rax
      38:      	je	0x17a <generic_retuprobe_filter_arg+0x17a>
      3e:      	movq	%rax, %r14
      41:      	movl	0x5f00(%rax), %ebx
      47:      	leaq	0x5ef8(%rax), %rsi
      4e:      	movq	(%rip), %rdi            # 0x55 <generic_retuprobe_filter_arg+0x55>
      55:      	movl	$0x1, %eax
      5a:      	callq	*%rax
      5c:      	testq	%rax, %rax
      5f:      	je	0x15f <generic_retuprobe_filter_arg+0x15f>
      65:      	cmpb	$0x0, 0x5ee0(%r14)
      6d:      	je	0x15f <generic_retuprobe_filter_arg+0x15f>
      73:      	movq	%rax, %rdi
      76:      	movl	%ebx, %eax
      78:      	andl	$0x7, %eax
      7b:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
      84:      	je	0xb8 <generic_retuprobe_filter_arg+0xb8>
      86:      	movl	%eax, %eax
      88:      	movl	0x4(%rdi,%rax,4), %ecx
      8c:      	leaq	(%rcx,%rax,4), %r11
      90:      	addq	$0x8, %r11
      94:      	movl	%r11d, %r9d
      97:      	andl	$0x3ff, %r9d            # imm = 0x3FF
      9e:      	cmpl	$0x19, (%rdi,%r9)
      a3:      	jae	0x104 <generic_retuprobe_filter_arg+0x104>
      a5:      	cmpq	$0x1, %r9
      a9:      	je	0x15f <generic_retuprobe_filter_arg+0x15f>
      af:      	testl	%r9d, %r9d
      b2:      	jne	0x13d <generic_retuprobe_filter_arg+0x13d>
      b8:      	cmpl	$0x1, %ebx
      bb:      	jg	0xd9 <generic_retuprobe_filter_arg+0xd9>
      bd:      	cmpl	$-0x1, %ebx
      c0:      	je	0x18e <generic_retuprobe_filter_arg+0x18e>
      c6:      	testl	%ebx, %ebx
      c8:      	je	0x19a <generic_retuprobe_filter_arg+0x19a>
      ce:      	cmpl	$0x1, %ebx
      d1:      	je	0x1a9 <generic_retuprobe_filter_arg+0x1a9>
      d7:      	jmp	0xf4 <generic_retuprobe_filter_arg+0xf4>
      d9:      	cmpl	$0x2, %ebx
      dc:      	je	0x1b8 <generic_retuprobe_filter_arg+0x1b8>
      e2:      	cmpl	$0x3, %ebx
      e5:      	je	0x1c7 <generic_retuprobe_filter_arg+0x1c7>
      eb:      	cmpl	$0x4, %ebx
      ee:      	je	0x1d6 <generic_retuprobe_filter_arg+0x1d6>
      f4:      	cmpl	$0x4, %ebx
      f7:      	jg	0x207 <generic_retuprobe_filter_arg+0x207>
      fd:      	incl	%ebx
      ff:      	jmp	0x1e5 <generic_retuprobe_filter_arg+0x1e5>
     104:      	leaq	(%rdi,%r9), %rax
     108:      	movq	%rax, 0xb0(%rsp)
     110:      	xorl	%r13d, %r13d
     113:      	leaq	0x70(%rsp), %rax
     118:      	movq	%rax, 0x30(%rsp)
     11d:      	movq	%rbx, 0xa8(%rsp)
     125:      	movq	%rdi, (%rsp)
     129:      	movq	%r9, 0x8(%rsp)
     12e:      	movq	%r11, 0x10(%rsp)
     133:      	movq	%r12, 0x68(%rsp)
     138:      	jmp	0x283 <generic_retuprobe_filter_arg+0x283>
     13d:      	movl	%r9d, 0x5f04(%r14)
     144:      	movq	(%rip), %rsi            # 0x14b <generic_retuprobe_filter_arg+0x14b>
     14b:      	movl	$0x4, %ecx
     150:      	movl	$0xc, %eax
     155:      	movq	%r12, %rdi
     158:      	movl	$0x4, %edx
     15d:      	callq	*%rax
     15f:      	movq	(%rip), %rsi            # 0x166 <generic_retuprobe_filter_arg+0x166>
     166:      	movl	$0x5, %ecx
     16b:      	movl	$0xc, %eax
     170:      	movq	%r12, %rdi
     173:      	movl	$0x5, %edx
     178:      	callq	*%rax
     17a:      	xorl	%eax, %eax
     17c:      	addq	$0xb8, %rsp
     183:      	popq	%rbx
     184:      	popq	%r12
     186:      	popq	%r13
     188:      	popq	%r14
     18a:      	popq	%r15
     18c:      	popq	%rbp
     18d:      	retq
     18e:      	xorl	%ebx, %ebx
     190:      	cmpb	$0x0, 0x5ec1(%r14)
     198:      	jne	0x1e5 <generic_retuprobe_filter_arg+0x1e5>
     19a:      	movl	$0x1, %ebx
     19f:      	cmpb	$0x0, 0x5ec2(%r14)
     1a7:      	jne	0x1e5 <generic_retuprobe_filter_arg+0x1e5>
     1a9:      	movl	$0x2, %ebx
     1ae:      	cmpb	$0x0, 0x5ec3(%r14)
     1b6:      	jne	0x1e5 <generic_retuprobe_filter_arg+0x1e5>
     1b8:      	movl	$0x3, %ebx
     1bd:      	cmpb	$0x0, 0x5ec4(%r14)
     1c5:      	jne	0x1e5 <generic_retuprobe_filter_arg+0x1e5>
     1c7:      	movl	$0x4, %ebx
     1cc:      	cmpb	$0x0, 0x5ec5(%r14)
     1d4:      	jne	0x1e5 <generic_retuprobe_filter_arg+0x1e5>
     1d6:      	movl	$0x5, %ebx
     1db:      	cmpb	$0x0, 0x5ec6(%r14)
     1e3:      	je	0x207 <generic_retuprobe_filter_arg+0x207>
     1e5:      	movl	%ebx, 0x5f00(%r14)
     1ec:      	movq	(%rip), %rsi            # 0x1f3 <generic_retuprobe_filter_arg+0x1f3>
     1f3:      	movl	$0x3, %ecx
     1f8:      	movl	$0xc, %eax
     1fd:      	movq	%r12, %rdi
     200:      	movl	$0x3, %edx
     205:      	callq	*%rax
     207:      	movq	0x60(%r14), %rbx
     20b:      	movl	$0xe, %eax
     210:      	callq	*%rax
     212:      	movq	%rbx, 0x38(%rsp)
     217:      	movq	%rax, 0x40(%rsp)
     21c:      	movq	(%rip), %rdi            # 0x223 <generic_retuprobe_filter_arg+0x223>
     223:      	leaq	0x38(%rsp), %rsi
     228:      	movl	$0x1, %eax
     22d:      	callq	*%rax
     22f:      	testq	%rax, %rax
     232:      	je	0x17a <generic_retuprobe_filter_arg+0x17a>
     238:      	movq	(%rip), %rdi            # 0x23f <generic_retuprobe_filter_arg+0x23f>
     23f:      	leaq	0x38(%rsp), %rsi
     244:      	movl	$0x3, %eax
     249:      	callq	*%rax
     24b:      	jmp	0x17a <generic_retuprobe_filter_arg+0x17a>
     250:      	xorl	%ebx, %ebx
     252:      	movq	(%rsp), %rdi
     256:      	movq	0x8(%rsp), %r9
     25b:      	movq	0x10(%rsp), %r11
     260:      	movq	0x68(%rsp), %r12
     265:      	testq	%rbx, %rbx
     268:      	movq	0xa8(%rsp), %rbx
     270:      	je	0xb8 <generic_retuprobe_filter_arg+0xb8>
     276:      	incq	%r13
     279:      	cmpq	$0x5, %r13
     27d:      	je	0xa5 <generic_retuprobe_filter_arg+0xa5>
     283:      	movq	0xb0(%rsp), %rax
     28b:      	movl	0x4(%rax,%r13,4), %r15d
     290:      	testl	$0x3ff, %r15d           # imm = 0x3FF
     297:      	je	0xa5 <generic_retuprobe_filter_arg+0xa5>
     29d:      	addl	%r11d, %r15d
     2a0:      	andl	$0x3ff, %r15d           # imm = 0x3FF
     2a7:      	movl	0x4(%rdi,%r15), %eax
     2ac:      	cmpl	$0x23, %eax
     2af:      	je	0xb8 <generic_retuprobe_filter_arg+0xb8>
     2b5:      	addq	%rdi, %r15
     2b8:      	movl	(%r15), %ecx
     2bb:      	cmpq	$0x4, %rcx
     2bf:      	ja	0xb8 <generic_retuprobe_filter_arg+0xb8>
     2c5:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
     2ce:      	jne	0xb8 <generic_retuprobe_filter_arg+0xb8>
     2d4:      	movq	0x5e78(%r14,%rcx,8), %rcx
     2dc:      	andl	$0x7ff, %ecx            # imm = 0x7FF
     2e2:      	leaq	(%r14,%rcx), %rbp
     2e6:      	addq	$0x90, %rbp
     2ed:      	movl	0xc(%r15), %ecx
     2f1:      	cmpl	$0x10, %ecx
     2f4:      	jle	0x350 <generic_retuprobe_filter_arg+0x350>
     2f6:      	leal	-0x1c(%rcx), %edx
     2f9:      	cmpl	$0x9, %edx
     2fc:      	jb	0x541 <generic_retuprobe_filter_arg+0x541>
     302:      	cmpl	$0x2a, %ecx
     305:      	ja	0x341 <generic_retuprobe_filter_arg+0x341>
     307:      	movl	%ecx, %edx
     309:      	movabsq	$0xc000000000, %rsi     # imm = 0xC000000000
     313:      	btq	%rdx, %rsi
     317:      	jb	0x379 <generic_retuprobe_filter_arg+0x379>
     319:      	movabsq	$0x30000000000, %rsi    # imm = 0x30000000000
     323:      	btq	%rdx, %rsi
     327:      	jb	0x89c <generic_retuprobe_filter_arg+0x89c>
     32d:      	movabsq	$0x42000000000, %rsi    # imm = 0x42000000000
     337:      	btq	%rdx, %rsi
     33b:      	jb	0x3cc <generic_retuprobe_filter_arg+0x3cc>
     341:      	cmpl	$0x11, %ecx
     344:      	jne	0x276 <generic_retuprobe_filter_arg+0x276>
     34a:      	addq	$0x4, %rbp
     34e:      	jmp	0x3cc <generic_retuprobe_filter_arg+0x3cc>
     350:      	cmpl	$0x6, %ecx
     353:      	jg	0x3b4 <generic_retuprobe_filter_arg+0x3b4>
     355:      	cmpl	$0x3, %ecx
     358:      	jle	0x4f3 <generic_retuprobe_filter_arg+0x4f3>
     35e:      	cmpl	$0x4, %ecx
     361:      	je	0x541 <generic_retuprobe_filter_arg+0x541>
     367:      	cmpl	$0x5, %ecx
     36a:      	je	0x89c <generic_retuprobe_filter_arg+0x89c>
     370:      	cmpl	$0x6, %ecx
     373:      	jne	0x276 <generic_retuprobe_filter_arg+0x276>
     379:      	movq	%rbp, %rsi
     37c:      	movl	(%rbp), %ebp
     37f:      	addq	$0x4, %rsi
     383:      	cmpl	$0x19, %eax
     386:      	jg	0x6c6 <generic_retuprobe_filter_arg+0x6c6>
     38c:      	leal	-0x3(%rax), %ecx
     38f:      	cmpl	$0x2, %ecx
     392:      	jb	0xf07 <generic_retuprobe_filter_arg+0xf07>
     398:      	cmpl	$0x8, %eax
     39b:      	je	0xe67 <generic_retuprobe_filter_arg+0xe67>
     3a1:      	movl	$0x0, %ebx
     3a6:      	cmpl	$0x9, %eax
     3a9:      	je	0x6e6 <generic_retuprobe_filter_arg+0x6e6>
     3af:      	jmp	0x2c6b <generic_retuprobe_filter_arg+0x2c6b>
     3b4:      	leal	-0xa(%rcx), %edx
     3b7:      	cmpl	$0x4, %edx
     3ba:      	jb	0x541 <generic_retuprobe_filter_arg+0x541>
     3c0:      	leal	-0xf(%rcx), %edx
     3c3:      	cmpl	$0x2, %edx
     3c6:      	jae	0x893 <generic_retuprobe_filter_arg+0x893>
     3cc:      	movq	%rbp, 0x20(%rsp)
     3d1:      	movl	(%rbp), %ebp
     3d4:      	movl	%eax, %ecx
     3d6:      	andl	$-0x2, %ecx
     3d9:      	cmpl	$0x24, %ecx
     3dc:      	je	0x3e6 <generic_retuprobe_filter_arg+0x3e6>
     3de:      	testl	%ebp, %ebp
     3e0:      	je	0xb8 <generic_retuprobe_filter_arg+0xb8>
     3e6:      	cmpl	$0x25, %eax
     3e9:      	movq	0x20(%rsp), %rsi
     3ee:      	ja	0x829 <generic_retuprobe_filter_arg+0x829>
     3f4:      	movl	%eax, %ecx
     3f6:      	movl	$0x4000100, %edx        # imm = 0x4000100
     3fb:      	btq	%rcx, %rdx
     3ff:      	jb	0xb9d <generic_retuprobe_filter_arg+0xb9d>
     405:      	movl	$0x8000200, %edx        # imm = 0x8000200
     40a:      	btq	%rcx, %rdx
     40e:      	jb	0xa5b <generic_retuprobe_filter_arg+0xa5b>
     414:      	movabsq	$0x3000000000, %rdx     # imm = 0x3000000000
     41e:      	btq	%rcx, %rdx
     422:      	jae	0x829 <generic_retuprobe_filter_arg+0x829>
     428:      	movw	$0x0, 0x38(%rsp)
     42f:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
     435:      	ja	0x845 <generic_retuprobe_filter_arg+0x845>
     43b:      	leaq	(%rsi,%rbp), %rcx
     43f:      	addq	$0x8, %rcx
     443:      	movl	$0x4, %eax
     448:      	leaq	0x38(%rsp), %rdi
     44d:      	movl	$0x2, %edx
     452:      	movl	(%rsi), %ecx
     454:      	leaq	(%rsi,%rcx), %rdx
     458:      	addq	$0x8, %rdx
     45c:      	movl	$0x2, %esi
     461:      	callq	*%rax
     463:      	movl	0x10(%r15), %ecx
     467:      	testl	%ecx, %ecx
     469:      	je	0x2aa6 <generic_retuprobe_filter_arg+0x2aa6>
     46f:      	movzwl	0x38(%rsp), %eax
     474:      	andl	$0xf000, %eax           # imm = 0xF000
     479:      	movl	$0x1, %ebx
     47e:      	cmpl	%eax, %ecx
     480:      	je	0x2aa8 <generic_retuprobe_filter_arg+0x2aa8>
     486:      	movl	0x8(%r15), %ecx
     48a:      	cmpl	$0xd, %ecx
     48d:      	movq	(%rsp), %rdi
     491:      	movq	0x8(%rsp), %r9
     496:      	movq	0x10(%rsp), %r11
     49b:      	jb	0x845 <generic_retuprobe_filter_arg+0x845>
     4a1:      	movl	0x14(%r15), %edx
     4a5:      	testl	%edx, %edx
     4a7:      	je	0x845 <generic_retuprobe_filter_arg+0x845>
     4ad:      	cmpl	%eax, %edx
     4af:      	je	0x2ab6 <generic_retuprobe_filter_arg+0x2ab6>
     4b5:      	cmpl	$0x11, %ecx
     4b8:      	jb	0x845 <generic_retuprobe_filter_arg+0x845>
     4be:      	movl	0x18(%r15), %edx
     4c2:      	testl	%edx, %edx
     4c4:      	je	0x845 <generic_retuprobe_filter_arg+0x845>
     4ca:      	cmpl	%eax, %edx
     4cc:      	je	0x2ab6 <generic_retuprobe_filter_arg+0x2ab6>
     4d2:      	cmpl	$0x15, %ecx
     4d5:      	jb	0x2aa6 <generic_retuprobe_filter_arg+0x2aa6>
     4db:      	movl	0x1c(%r15), %ecx
     4df:      	testl	%ecx, %ecx
     4e1:      	je	0x2aa6 <generic_retuprobe_filter_arg+0x2aa6>
     4e7:      	xorl	%ebx, %ebx
     4e9:      	cmpl	%eax, %ecx
     4eb:      	sete	%bl
     4ee:      	jmp	0x2aa8 <generic_retuprobe_filter_arg+0x2aa8>
     4f3:      	cmpl	$0x1, %ecx
     4f6:      	je	0x541 <generic_retuprobe_filter_arg+0x541>
     4f8:      	cmpl	$0x2, %ecx
     4fb:      	jne	0x276 <generic_retuprobe_filter_arg+0x276>
     501:      	movq	%rbp, %rsi
     504:      	movl	0x4(%rbp), %ebp
     507:      	addq	$0x8, %rsi
     50b:      	cmpl	$0x19, %eax
     50e:      	jg	0xf81 <generic_retuprobe_filter_arg+0xf81>
     514:      	leal	-0x3(%rax), %ecx
     517:      	cmpl	$0x2, %ecx
     51a:      	jb	0x1754 <generic_retuprobe_filter_arg+0x1754>
     520:      	movq	%rsi, 0x20(%rsp)
     525:      	cmpl	$0x8, %eax
     528:      	je	0x16c0 <generic_retuprobe_filter_arg+0x16c0>
     52e:      	movl	$0x0, %ebx
     533:      	cmpl	$0x9, %eax
     536:      	je	0xfa6 <generic_retuprobe_filter_arg+0xfa6>
     53c:      	jmp	0x2ef2 <generic_retuprobe_filter_arg+0x2ef2>
     541:      	cmpl	$0xb, %ecx
     544:      	jle	0x5d3 <generic_retuprobe_filter_arg+0x5d3>
     54a:      	cmpl	$0x24, %ecx
     54d:      	ja	0x61a <generic_retuprobe_filter_arg+0x61a>
     553:      	movl	%ecx, %edx
     555:      	movabsq	$0x1e00000000, %rsi     # imm = 0x1E00000000
     55f:      	btq	%rdx, %rsi
     563:      	jb	0x5ee <generic_retuprobe_filter_arg+0x5ee>
     569:      	movl	$0x60000000, %esi       # imm = 0x60000000
     56e:      	btq	%rdx, %rsi
     572:      	jb	0x84c <generic_retuprobe_filter_arg+0x84c>
     578:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
     582:      	btq	%rdx, %rsi
     586:      	jae	0x61a <generic_retuprobe_filter_arg+0x61a>
     58c:      	cmpl	$0x20, %eax
     58f:      	ja	0xb8 <generic_retuprobe_filter_arg+0xb8>
     595:      	movl	%eax, %ecx
     597:      	movl	$0x101e, %edx           # imm = 0x101E
     59c:      	btq	%rcx, %rdx
     5a0:      	jae	0x10ef <generic_retuprobe_filter_arg+0x10ef>
     5a6:      	movl	0x10(%r15), %ecx
     5aa:      	cmpl	$0x2, %eax
     5ad:      	jle	0x157c <generic_retuprobe_filter_arg+0x157c>
     5b3:      	leal	-0x3(%rax), %edx
     5b6:      	cmpl	$0x2, %edx
     5b9:      	jae	0x1b2c <generic_retuprobe_filter_arg+0x1b2c>
     5bf:      	movq	%rbp, %rdx
     5c2:      	movzbl	(%rbp), %edx
     5c6:      	cmpl	%edx, %ecx
     5c8:      	jne	0x1e23 <generic_retuprobe_filter_arg+0x1e23>
     5ce:      	jmp	0x2e81 <generic_retuprobe_filter_arg+0x2e81>
     5d3:      	leal	-0xa(%rcx), %edx
     5d6:      	cmpl	$0x2, %edx
     5d9:      	jb	0x95f <generic_retuprobe_filter_arg+0x95f>
     5df:      	cmpl	$0x1, %ecx
     5e2:      	je	0x626 <generic_retuprobe_filter_arg+0x626>
     5e4:      	cmpl	$0x4, %ecx
     5e7:      	je	0x626 <generic_retuprobe_filter_arg+0x626>
     5e9:      	jmp	0x276 <generic_retuprobe_filter_arg+0x276>
     5ee:      	cmpl	$0x9, %eax
     5f1:      	jle	0x912 <generic_retuprobe_filter_arg+0x912>
     5f7:      	cmpl	$0x1d, %eax
     5fa:      	jg	0xd40 <generic_retuprobe_filter_arg+0xd40>
     600:      	leal	-0xa(%rax), %edx
     603:      	cmpl	$0x2, %edx
     606:      	jb	0x9ec <generic_retuprobe_filter_arg+0x9ec>
     60c:      	cmpl	$0xc, %eax
     60f:      	je	0x975 <generic_retuprobe_filter_arg+0x975>
     615:      	jmp	0xb8 <generic_retuprobe_filter_arg+0xb8>
     61a:      	leal	-0xc(%rcx), %edx
     61d:      	cmpl	$0x2, %edx
     620:      	jae	0x956 <generic_retuprobe_filter_arg+0x956>
     626:      	cmpl	$0x20, %eax
     629:      	ja	0xb8 <generic_retuprobe_filter_arg+0xb8>
     62f:      	movl	%eax, %edx
     631:      	movl	$0x101e, %esi           # imm = 0x101E
     636:      	btq	%rdx, %rsi
     63a:      	jae	0x663 <generic_retuprobe_filter_arg+0x663>
     63c:      	movl	0x10(%r15), %edx
     640:      	cmpl	$0x2, %eax
     643:      	jle	0x91f <generic_retuprobe_filter_arg+0x91f>
     649:      	leal	-0x3(%rax), %esi
     64c:      	cmpl	$0x2, %esi
     64f:      	jae	0x10d8 <generic_retuprobe_filter_arg+0x10d8>
     655:      	cmpl	%edx, (%rbp)
     658:      	jne	0x2062 <generic_retuprobe_filter_arg+0x2062>
     65e:      	jmp	0x2e81 <generic_retuprobe_filter_arg+0x2e81>
     663:      	movl	$0xc00, %esi            # imm = 0xC00
     668:      	btq	%rdx, %rsi
     66c:      	jb	0xc3c <generic_retuprobe_filter_arg+0xc3c>
     672:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
     67c:      	btq	%rdx, %rsi
     680:      	jae	0xb8 <generic_retuprobe_filter_arg+0xb8>
     686:      	cmpl	$0x1f, %eax
     689:      	jne	0x1227 <generic_retuprobe_filter_arg+0x1227>
     68f:      	movl	0x10(%r15), %esi
     693:      	movl	0x14(%r15), %edx
     697:      	cmpl	$0xc, %ecx
     69a:      	ja	0x1eb9 <generic_retuprobe_filter_arg+0x1eb9>
     6a0:      	movl	$0x1402, %eax           # imm = 0x1402
     6a5:      	btl	%ecx, %eax
     6a8:      	jae	0x1eb9 <generic_retuprobe_filter_arg+0x1eb9>
     6ae:      	movl	(%rbp), %eax
     6b1:      	cmpl	%eax, %esi
     6b3:      	jg	0x1ec8 <generic_retuprobe_filter_arg+0x1ec8>
     6b9:      	cmpl	%edx, %eax
     6bb:      	jle	0x276 <generic_retuprobe_filter_arg+0x276>
     6c1:      	jmp	0x1ec8 <generic_retuprobe_filter_arg+0x1ec8>
     6c6:      	cmpl	$0x20, %eax
     6c9:      	jg	0xd86 <generic_retuprobe_filter_arg+0xd86>
     6cf:      	cmpl	$0x1a, %eax
     6d2:      	je	0xe67 <generic_retuprobe_filter_arg+0xe67>
     6d8:      	movl	$0x0, %ebx
     6dd:      	cmpl	$0x1b, %eax
     6e0:      	jne	0x2c6b <generic_retuprobe_filter_arg+0x2c6b>
     6e6:      	movq	%rsi, 0x20(%rsp)
     6eb:      	movl	0x10(%r15), %eax
     6ef:      	movl	%eax, 0x38(%rsp)
     6f3:      	movl	$0x0, 0x70(%rsp)
     6fb:      	movl	$0x1, %eax
     700:      	leaq	0x38(%rsp), %rsi
     705:      	movq	(%rip), %rdi            # 0x70c <generic_retuprobe_filter_arg+0x70c>
     70c:      	callq	*%rax
     70e:      	testl	%ebp, %ebp
     710:      	je	0x2c5b <generic_retuprobe_filter_arg+0x2c5b>
     716:      	movl	$0x0, %ebx
     71b:      	testq	%rax, %rax
     71e:      	je	0x2c5d <generic_retuprobe_filter_arg+0x2c5d>
     724:      	movq	%rax, 0x18(%rsp)
     729:      	movl	$0x1, %eax
     72e:      	movq	0x30(%rsp), %rsi
     733:      	movq	(%rip), %rdi            # 0x73a <generic_retuprobe_filter_arg+0x73a>
     73a:      	callq	*%rax
     73c:      	testq	%rax, %rax
     73f:      	je	0x2c5b <generic_retuprobe_filter_arg+0x2c5b>
     745:      	movq	%rax, %rdi
     748:      	cmpl	$0x7f, %ebp
     74b:      	movl	$0x7f, %eax
     750:      	cmovbl	%ebp, %eax
     753:      	shll	$0x3, %eax
     756:      	movl	%eax, (%rdi)
     758:      	movq	%rbp, %rax
     75b:      	negq	%rax
     75e:      	movl	$0x3, %ecx
     763:      	subq	%rbp, %rcx
     766:      	leal	-0x4(%rbp), %edx
     769:      	movq	%rdi, 0x60(%rsp)
     76e:      	addq	$0x7, %rdi
     772:      	movl	$0x2, %r8d
     778:      	subq	%rbp, %r8
     77b:      	leal	-0x3(%rbp), %r9d
     77f:      	movl	$0x1, %r10d
     785:      	subq	%rbp, %r10
     788:      	leal	-0x2(%rbp), %r11d
     78c:      	decl	%ebp
     78e:      	xorl	%ebx, %ebx
     790:      	movq	0x20(%rsp), %rsi
     795:      	leal	(%rbx,%rbp), %r12d
     799:      	andl	$0xfff, %r12d           # imm = 0xFFF
     7a0:      	movzbl	(%rsi,%r12), %r12d
     7a5:      	movb	%r12b, -0x3(%rdi)
     7a9:      	cmpq	%rbx, %r10
     7ac:      	je	0x806 <generic_retuprobe_filter_arg+0x806>
     7ae:      	leal	(%r11,%rbx), %r12d
     7b2:      	andl	$0xfff, %r12d           # imm = 0xFFF
     7b9:      	movzbl	(%rsi,%r12), %r12d
     7be:      	movb	%r12b, -0x2(%rdi)
     7c2:      	cmpq	%rbx, %r8
     7c5:      	je	0x806 <generic_retuprobe_filter_arg+0x806>
     7c7:      	leal	(%r9,%rbx), %r12d
     7cb:      	andl	$0xfff, %r12d           # imm = 0xFFF
     7d2:      	movzbl	(%rsi,%r12), %r12d
     7d7:      	movb	%r12b, -0x1(%rdi)
     7db:      	cmpq	%rbx, %rcx
     7de:      	je	0x806 <generic_retuprobe_filter_arg+0x806>
     7e0:      	cmpq	$-0x7c, %rbx
     7e4:      	je	0x806 <generic_retuprobe_filter_arg+0x806>
     7e6:      	leal	(%rdx,%rbx), %r12d
     7ea:      	andl	$0xfff, %r12d           # imm = 0xFFF
     7f1:      	movzbl	(%rsi,%r12), %r12d
     7f6:      	movb	%r12b, (%rdi)
     7f9:      	addq	$-0x4, %rbx
     7fd:      	addq	$0x4, %rdi
     801:      	cmpq	%rbx, %rax
     804:      	jne	0x795 <generic_retuprobe_filter_arg+0x795>
     806:      	movl	$0x1, %eax
     80b:      	movq	0x18(%rsp), %rdi
     810:      	movq	0x60(%rsp), %rsi
     815:      	callq	*%rax
     817:      	xorl	%ebx, %ebx
     819:      	testq	%rax, %rax
     81c:      	setne	%bl
     81f:      	movq	0x68(%rsp), %r12
     824:      	jmp	0x2c5d <generic_retuprobe_filter_arg+0x2c5d>
     829:      	addl	$-0x3, %eax
     82c:      	cmpl	$0x2, %eax
     82f:      	jae	0x845 <generic_retuprobe_filter_arg+0x845>
     831:      	movl	$0x0, 0x70(%rsp)
     839:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
     83f:      	jbe	0x11d6 <generic_retuprobe_filter_arg+0x11d6>
     845:      	xorl	%ebx, %ebx
     847:      	jmp	0x2ab6 <generic_retuprobe_filter_arg+0x2ab6>
     84c:      	cmpl	$0x20, %eax
     84f:      	ja	0xb8 <generic_retuprobe_filter_arg+0xb8>
     855:      	movl	%eax, %ecx
     857:      	movl	$0x101e, %edx           # imm = 0x101E
     85c:      	btq	%rcx, %rdx
     860:      	jae	0x1121 <generic_retuprobe_filter_arg+0x1121>
     866:      	movl	0x10(%r15), %ecx
     86a:      	cmpl	$0x2, %eax
     86d:      	jle	0x159f <generic_retuprobe_filter_arg+0x159f>
     873:      	leal	-0x3(%rax), %edx
     876:      	cmpl	$0x2, %edx
     879:      	jae	0x1b46 <generic_retuprobe_filter_arg+0x1b46>
     87f:      	movq	%rbp, %rdx
     882:      	movzwl	(%rbp), %edx
     886:      	cmpl	%edx, %ecx
     888:      	jne	0x1e66 <generic_retuprobe_filter_arg+0x1e66>
     88e:      	jmp	0x2e81 <generic_retuprobe_filter_arg+0x2e81>
     893:      	cmpl	$0x7, %ecx
     896:      	jne	0x276 <generic_retuprobe_filter_arg+0x276>
     89c:      	movq	$0x0, 0x58(%rsp)
     8a5:      	movq	$0x0, 0x50(%rsp)
     8ae:      	movq	$0x0, 0x48(%rsp)
     8b7:      	movq	$0x0, 0x40(%rsp)
     8c0:      	movq	$0x0, 0x38(%rsp)
     8c9:      	cmpl	$0x27, %ecx
     8cc:      	jg	0x8f0 <generic_retuprobe_filter_arg+0x8f0>
     8ce:      	cmpl	$0x5, %ecx
     8d1:      	movq	%rbp, %rsi
     8d4:      	je	0xcbb <generic_retuprobe_filter_arg+0xcbb>
     8da:      	movq	%rsi, %rdx
     8dd:      	movl	$0x0, %ebx
     8e2:      	cmpl	$0x7, %ecx
     8e5:      	je	0xcbd <generic_retuprobe_filter_arg+0xcbd>
     8eb:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
     8f0:      	cmpl	$0x28, %ecx
     8f3:      	movq	%rbp, %rsi
     8f6:      	je	0xc93 <generic_retuprobe_filter_arg+0xc93>
     8fc:      	movq	%rsi, %rdx
     8ff:      	movl	$0x0, %ebx
     904:      	cmpl	$0x29, %ecx
     907:      	je	0xcbd <generic_retuprobe_filter_arg+0xcbd>
     90d:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
     912:      	leal	-0x1(%rax), %edx
     915:      	cmpl	$0x4, %edx
     918:      	jb	0x975 <generic_retuprobe_filter_arg+0x975>
     91a:      	jmp	0xb8 <generic_retuprobe_filter_arg+0xb8>
     91f:      	cmpl	$0x1, %eax
     922:      	je	0x1382 <generic_retuprobe_filter_arg+0x1382>
     928:      	cmpl	$0x2, %eax
     92b:      	jne	0x2062 <generic_retuprobe_filter_arg+0x2062>
     931:      	cmpl	$0xc, %ecx
     934:      	ja	0x2059 <generic_retuprobe_filter_arg+0x2059>
     93a:      	movl	$0x1402, %esi           # imm = 0x1402
     93f:      	btl	%ecx, %esi
     942:      	jae	0x2059 <generic_retuprobe_filter_arg+0x2059>
     948:      	cmpl	%edx, (%rbp)
     94b:      	jl	0x276 <generic_retuprobe_filter_arg+0x276>
     951:      	jmp	0x2062 <generic_retuprobe_filter_arg+0x2062>
     956:      	cmpl	$0x1c, %ecx
     959:      	jne	0x276 <generic_retuprobe_filter_arg+0x276>
     95f:      	cmpl	$0x20, %eax
     962:      	ja	0xb8 <generic_retuprobe_filter_arg+0xb8>
     968:      	movl	%eax, %edx
     96a:      	movl	$0x101e, %esi           # imm = 0x101E
     96f:      	btq	%rdx, %rsi
     973:      	jae	0x999 <generic_retuprobe_filter_arg+0x999>
     975:      	movq	0x10(%r15), %rdx
     979:      	cmpl	$0x2, %eax
     97c:      	jle	0x9bd <generic_retuprobe_filter_arg+0x9bd>
     97e:      	leal	-0x3(%rax), %esi
     981:      	cmpl	$0x2, %esi
     984:      	jae	0xc7b <generic_retuprobe_filter_arg+0xc7b>
     98a:      	cmpq	%rdx, (%rbp)
     98e:      	jne	0x1ab0 <generic_retuprobe_filter_arg+0x1ab0>
     994:      	jmp	0x2e81 <generic_retuprobe_filter_arg+0x2e81>
     999:      	movl	$0xc00, %esi            # imm = 0xC00
     99e:      	btq	%rdx, %rsi
     9a2:      	jb	0x9ec <generic_retuprobe_filter_arg+0x9ec>
     9a4:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
     9ae:      	btq	%rdx, %rsi
     9b2:      	jb	0xd4c <generic_retuprobe_filter_arg+0xd4c>
     9b8:      	jmp	0xb8 <generic_retuprobe_filter_arg+0xb8>
     9bd:      	cmpl	$0x1, %eax
     9c0:      	je	0x11b9 <generic_retuprobe_filter_arg+0x11b9>
     9c6:      	cmpl	$0x2, %eax
     9c9:      	jne	0x1ab0 <generic_retuprobe_filter_arg+0x1ab0>
     9cf:      	cmpl	$0xc, %ecx
     9d2:      	je	0x9dd <generic_retuprobe_filter_arg+0x9dd>
     9d4:      	cmpl	$0xa, %ecx
     9d7:      	jne	0x1aa6 <generic_retuprobe_filter_arg+0x1aa6>
     9dd:      	cmpq	%rdx, (%rbp)
     9e1:      	jl	0x276 <generic_retuprobe_filter_arg+0x276>
     9e7:      	jmp	0x1ab0 <generic_retuprobe_filter_arg+0x1ab0>
     9ec:      	movzbl	0x10(%r15), %eax
     9f1:      	movl	%eax, 0x70(%rsp)
     9f5:      	movl	$0x1, %eax
     9fa:      	movq	0x30(%rsp), %rsi
     9ff:      	movq	(%rip), %rdi            # 0xa06 <generic_retuprobe_filter_arg+0xa06>
     a06:      	callq	*%rax
     a08:      	testq	%rax, %rax
     a0b:      	je	0x166d <generic_retuprobe_filter_arg+0x166d>
     a11:      	movq	%rax, %rdi
     a14:      	movq	(%rbp), %rax
     a18:      	movq	%rax, 0x38(%rsp)
     a1d:      	movl	$0x1, %eax
     a22:      	leaq	0x38(%rsp), %rsi
     a27:      	callq	*%rax
     a29:      	movl	0x4(%r15), %ecx
     a2d:      	cmpl	$0xb, %ecx
     a30:      	je	0x169a <generic_retuprobe_filter_arg+0x169a>
     a36:      	cmpl	$0xa, %ecx
     a39:      	movq	(%rsp), %rdi
     a3d:      	movq	0x8(%rsp), %r9
     a42:      	movq	0x10(%rsp), %r11
     a47:      	jne	0x16b6 <generic_retuprobe_filter_arg+0x16b6>
     a4d:      	testq	%rax, %rax
     a50:      	setne	%al
     a53:      	movzbl	%al, %ebx
     a56:      	jmp	0x265 <generic_retuprobe_filter_arg+0x265>
     a5b:      	movl	0x10(%r15), %eax
     a5f:      	movl	%eax, 0x38(%rsp)
     a63:      	movl	$0x0, 0x70(%rsp)
     a6b:      	movl	$0x1, %eax
     a70:      	leaq	0x38(%rsp), %rsi
     a75:      	movq	(%rip), %rdi            # 0xa7c <generic_retuprobe_filter_arg+0xa7c>
     a7c:      	callq	*%rax
     a7e:      	testl	%ebp, %ebp
     a80:      	je	0x2aa6 <generic_retuprobe_filter_arg+0x2aa6>
     a86:      	movl	$0x0, %ebx
     a8b:      	testq	%rax, %rax
     a8e:      	je	0x2aa8 <generic_retuprobe_filter_arg+0x2aa8>
     a94:      	movq	%rax, 0x18(%rsp)
     a99:      	movl	$0x1, %eax
     a9e:      	movq	0x30(%rsp), %rsi
     aa3:      	movq	(%rip), %rdi            # 0xaaa <generic_retuprobe_filter_arg+0xaaa>
     aaa:      	callq	*%rax
     aac:      	testq	%rax, %rax
     aaf:      	je	0x2aa6 <generic_retuprobe_filter_arg+0x2aa6>
     ab5:      	movq	%rax, %rdi
     ab8:      	cmpl	$0x7f, %ebp
     abb:      	movl	$0x7f, %eax
     ac0:      	cmovbl	%ebp, %eax
     ac3:      	shll	$0x3, %eax
     ac6:      	movl	%eax, (%rdi)
     ac8:      	movq	%rbp, %rax
     acb:      	negq	%rax
     ace:      	movl	$0x3, %ecx
     ad3:      	subq	%rbp, %rcx
     ad6:      	leal	-0x4(%rbp), %edx
     ad9:      	movq	%rdi, 0x60(%rsp)
     ade:      	addq	$0x7, %rdi
     ae2:      	movl	$0x2, %r8d
     ae8:      	subq	%rbp, %r8
     aeb:      	leal	-0x3(%rbp), %r9d
     aef:      	movl	$0x1, %r10d
     af5:      	subq	%rbp, %r10
     af8:      	leal	-0x2(%rbp), %r11d
     afc:      	decl	%ebp
     afe:      	xorl	%ebx, %ebx
     b00:      	movq	0x20(%rsp), %rsi
     b05:      	leal	(%rbx,%rbp), %r12d
     b09:      	andl	$0xfff, %r12d           # imm = 0xFFF
     b10:      	movzbl	0x4(%rsi,%r12), %r12d
     b16:      	movb	%r12b, -0x3(%rdi)
     b1a:      	cmpq	%rbx, %r10
     b1d:      	je	0xb7a <generic_retuprobe_filter_arg+0xb7a>
     b1f:      	leal	(%r11,%rbx), %r12d
     b23:      	andl	$0xfff, %r12d           # imm = 0xFFF
     b2a:      	movzbl	0x4(%rsi,%r12), %r12d
     b30:      	movb	%r12b, -0x2(%rdi)
     b34:      	cmpq	%rbx, %r8
     b37:      	je	0xb7a <generic_retuprobe_filter_arg+0xb7a>
     b39:      	leal	(%r9,%rbx), %r12d
     b3d:      	andl	$0xfff, %r12d           # imm = 0xFFF
     b44:      	movzbl	0x4(%rsi,%r12), %r12d
     b4a:      	movb	%r12b, -0x1(%rdi)
     b4e:      	cmpq	%rbx, %rcx
     b51:      	je	0xb7a <generic_retuprobe_filter_arg+0xb7a>
     b53:      	cmpq	$-0x7c, %rbx
     b57:      	je	0xb7a <generic_retuprobe_filter_arg+0xb7a>
     b59:      	leal	(%rdx,%rbx), %r12d
     b5d:      	andl	$0xfff, %r12d           # imm = 0xFFF
     b64:      	movzbl	0x4(%rsi,%r12), %r12d
     b6a:      	movb	%r12b, (%rdi)
     b6d:      	addq	$-0x4, %rbx
     b71:      	addq	$0x4, %rdi
     b75:      	cmpq	%rbx, %rax
     b78:      	jne	0xb05 <generic_retuprobe_filter_arg+0xb05>
     b7a:      	movl	$0x1, %eax
     b7f:      	movq	0x18(%rsp), %rdi
     b84:      	movq	0x60(%rsp), %rsi
     b89:      	callq	*%rax
     b8b:      	xorl	%ebx, %ebx
     b8d:      	testq	%rax, %rax
     b90:      	setne	%bl
     b93:      	movq	0x68(%rsp), %r12
     b98:      	jmp	0x2aa8 <generic_retuprobe_filter_arg+0x2aa8>
     b9d:      	movl	0x10(%r15), %eax
     ba1:      	movl	%eax, 0x38(%rsp)
     ba5:      	movl	$0x0, 0x70(%rsp)
     bad:      	movl	$0x1, %eax
     bb2:      	leaq	0x38(%rsp), %rsi
     bb7:      	movq	(%rip), %rdi            # 0xbbe <generic_retuprobe_filter_arg+0xbbe>
     bbe:      	callq	*%rax
     bc0:      	testl	%ebp, %ebp
     bc2:      	je	0x2aa6 <generic_retuprobe_filter_arg+0x2aa6>
     bc8:      	movl	$0x0, %ebx
     bcd:      	testq	%rax, %rax
     bd0:      	je	0x2aa8 <generic_retuprobe_filter_arg+0x2aa8>
     bd6:      	movq	%rax, 0x18(%rsp)
     bdb:      	movl	$0x1, %eax
     be0:      	movq	0x30(%rsp), %rsi
     be5:      	movq	(%rip), %rdi            # 0xbec <generic_retuprobe_filter_arg+0xbec>
     bec:      	callq	*%rax
     bee:      	testq	%rax, %rax
     bf1:      	je	0x2aa6 <generic_retuprobe_filter_arg+0x2aa6>
     bf7:      	movq	%rax, %rbx
     bfa:      	movq	0x20(%rsp), %rdx
     bff:      	addq	$0x4, %rdx
     c03:      	cmpl	$0xff, %ebp
     c09:      	movl	$0xff, %eax
     c0e:      	cmovael	%eax, %ebp
     c11:      	leal	(,%rbp,8), %eax
     c18:      	movl	%eax, (%rbx)
     c1a:      	movq	%rbx, %rdi
     c1d:      	addq	$0x4, %rdi
     c21:      	movl	$0x4, %eax
     c26:      	movl	%ebp, %esi
     c28:      	callq	*%rax
     c2a:      	movl	$0x1, %eax
     c2f:      	movq	0x18(%rsp), %rdi
     c34:      	movq	%rbx, %rsi
     c37:      	jmp	0x2a9a <generic_retuprobe_filter_arg+0x2a9a>
     c3c:      	movzbl	0x10(%r15), %eax
     c41:      	movl	%eax, 0x70(%rsp)
     c45:      	movl	$0x1, %eax
     c4a:      	movq	0x30(%rsp), %rsi
     c4f:      	movq	(%rip), %rdi            # 0xc56 <generic_retuprobe_filter_arg+0xc56>
     c56:      	callq	*%rax
     c58:      	testq	%rax, %rax
     c5b:      	je	0x166d <generic_retuprobe_filter_arg+0x166d>
     c61:      	movq	%rax, %rdi
     c64:      	movl	(%rbp), %eax
     c67:      	movq	%rax, 0x38(%rsp)
     c6c:      	movl	$0x1, %eax
     c71:      	leaq	0x38(%rsp), %rsi
     c76:      	jmp	0x1636 <generic_retuprobe_filter_arg+0x1636>
     c7b:      	cmpl	$0xc, %eax
     c7e:      	jne	0x1ab0 <generic_retuprobe_filter_arg+0x1ab0>
     c84:      	testq	%rdx, (%rbp)
     c88:      	jne	0x276 <generic_retuprobe_filter_arg+0x276>
     c8e:      	jmp	0x1ab0 <generic_retuprobe_filter_arg+0x1ab0>
     c93:      	movzwl	(%rsi), %edx
     c96:      	movw	%dx, 0x5e(%rsp)
     c9b:      	movzwl	0x2(%rsi), %edx
     c9f:      	movw	%dx, 0x58(%rsp)
     ca4:      	movq	0x8(%rsi), %rdx
     ca8:      	movq	%rdx, 0x38(%rsp)
     cad:      	movq	0x10(%rsi), %rdx
     cb1:      	movq	%rdx, 0x40(%rsp)
     cb6:      	leaq	0x38(%rsp), %rsi
     cbb:      	xorl	%edx, %edx
     cbd:      	cmpl	$0x13, %eax
     cc0:      	jle	0xce9 <generic_retuprobe_filter_arg+0xce9>
     cc2:      	cmpl	$0x17, %eax
     cc5:      	jg	0xd1b <generic_retuprobe_filter_arg+0xd1b>
     cc7:      	leal	-0x14(%rax), %ecx
     cca:      	cmpl	$0x2, %ecx
     ccd:      	jb	0x1273 <generic_retuprobe_filter_arg+0x1273>
     cd3:      	leal	-0x16(%rax), %ecx
     cd6:      	movl	$0x0, %ebx
     cdb:      	cmpl	$0x2, %ecx
     cde:      	jb	0x126c <generic_retuprobe_filter_arg+0x126c>
     ce4:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
     ce9:      	cmpl	$0xf, %eax
     cec:      	jle	0xf5c <generic_retuprobe_filter_arg+0xf5c>
     cf2:      	cmpl	$0x11, %eax
     cf5:      	jg	0x1259 <generic_retuprobe_filter_arg+0x1259>
     cfb:      	cmpl	$0x10, %eax
     cfe:      	je	0x126c <generic_retuprobe_filter_arg+0x126c>
     d04:      	movl	$0x0, %ebx
     d09:      	cmpl	$0x11, %eax
     d0c:      	jne	0x260 <generic_retuprobe_filter_arg+0x260>
     d12:      	movzwl	0x24(%rsi), %ebx
     d16:      	jmp	0x1a17 <generic_retuprobe_filter_arg+0x1a17>
     d1b:      	cmpl	$0x1b, %eax
     d1e:      	jg	0x12ac <generic_retuprobe_filter_arg+0x12ac>
     d24:      	cmpl	$0x18, %eax
     d27:      	je	0x12e6 <generic_retuprobe_filter_arg+0x12e6>
     d2d:      	movl	$0x0, %ebx
     d32:      	cmpl	$0x19, %eax
     d35:      	je	0x12dc <generic_retuprobe_filter_arg+0x12dc>
     d3b:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
     d40:      	leal	-0x1f(%rax), %edx
     d43:      	cmpl	$0x2, %edx
     d46:      	jae	0x176f <generic_retuprobe_filter_arg+0x176f>
     d4c:      	cmpl	$0x1f, %eax
     d4f:      	jne	0xf30 <generic_retuprobe_filter_arg+0xf30>
     d55:      	movq	0x10(%r15), %rsi
     d59:      	movq	0x18(%r15), %rdx
     d5d:      	cmpl	$0xa, %ecx
     d60:      	je	0xd6b <generic_retuprobe_filter_arg+0xd6b>
     d62:      	cmpl	$0xc, %ecx
     d65:      	jne	0x1979 <generic_retuprobe_filter_arg+0x1979>
     d6b:      	movq	(%rbp), %rax
     d6f:      	cmpq	%rax, %rsi
     d72:      	jg	0x198b <generic_retuprobe_filter_arg+0x198b>
     d78:      	cmpq	%rdx, %rax
     d7b:      	jle	0x276 <generic_retuprobe_filter_arg+0x276>
     d81:      	jmp	0x198b <generic_retuprobe_filter_arg+0x198b>
     d86:      	cmpl	$0x21, %eax
     d89:      	je	0x13a7 <generic_retuprobe_filter_arg+0x13a7>
     d8f:      	movl	$0x0, %ebx
     d94:      	cmpl	$0x22, %eax
     d97:      	jne	0x2c6b <generic_retuprobe_filter_arg+0x2c6b>
     d9d:      	movq	%rsi, 0x20(%rsp)
     da2:      	xorl	%ebx, %ebx
     da4:      	xorl	%r12d, %r12d
     da7:      	movl	0x10(%r15,%rbx,4), %eax
     dac:      	movl	%eax, 0x38(%rsp)
     db0:      	movl	$0x1, %eax
     db5:      	leaq	0x38(%rsp), %rsi
     dba:      	movq	(%rip), %rdi            # 0xdc1 <generic_retuprobe_filter_arg+0xdc1>
     dc1:      	callq	*%rax
     dc3:      	testq	%rax, %rax
     dc6:      	je	0x211a <generic_retuprobe_filter_arg+0x211a>
     dcc:      	testl	%ebp, %ebp
     dce:      	movq	0x10(%rsp), %r11
     dd3:      	je	0xe44 <generic_retuprobe_filter_arg+0xe44>
     dd5:      	movq	0x20(%rsp), %rdx
     dda:      	xorl	%ecx, %ecx
     ddc:      	jmp	0xde9 <generic_retuprobe_filter_arg+0xde9>
     dde:      	incq	%rcx
     de1:      	incq	%rdx
     de4:      	cmpq	%rbp, %rcx
     de7:      	je	0xe44 <generic_retuprobe_filter_arg+0xe44>
     de9:      	xorl	%esi, %esi
     deb:      	nopl	(%rax,%rax)
     df0:      	leaq	(%rcx,%rsi), %rdi
     df4:      	cmpq	%rbp, %rdi
     df7:      	jae	0xdde <generic_retuprobe_filter_arg+0xdde>
     df9:      	movsbl	(%rax,%rsi), %edi
     dfd:      	testl	%edi, %edi
     dff:      	je	0xe3c <generic_retuprobe_filter_arg+0xe3c>
     e01:      	movsbl	(%rdx,%rsi), %r9d
     e06:      	leal	-0x41(%r9), %r10d
     e0a:      	movl	%r9d, %r8d
     e0d:      	orl	$0x20, %r8d
     e11:      	cmpl	$0x1a, %r10d
     e15:      	cmovael	%r9d, %r8d
     e19:      	leal	-0x41(%rdi), %r10d
     e1d:      	movl	%edi, %r9d
     e20:      	orl	$0x20, %r9d
     e24:      	cmpl	$0x1a, %r10d
     e28:      	cmovael	%edi, %r9d
     e2c:      	cmpq	$0x62, %rsi
     e30:      	ja	0xdde <generic_retuprobe_filter_arg+0xdde>
     e32:      	incq	%rsi
     e35:      	cmpl	%r9d, %r8d
     e38:      	je	0xdf0 <generic_retuprobe_filter_arg+0xdf0>
     e3a:      	jmp	0xdde <generic_retuprobe_filter_arg+0xdde>
     e3c:      	testl	%ecx, %ecx
     e3e:      	jns	0x23f8 <generic_retuprobe_filter_arg+0x23f8>
     e44:      	leal	0xc(%r12), %eax
     e49:      	cmpl	0x8(%r15), %eax
     e4d:      	jae	0xe60 <generic_retuprobe_filter_arg+0xe60>
     e4f:      	addl	$0x4, %r12d
     e53:      	incq	%rbx
     e56:      	cmpq	$0x64, %rbx
     e5a:      	jne	0xda7 <generic_retuprobe_filter_arg+0xda7>
     e60:      	xorl	%ebx, %ebx
     e62:      	jmp	0x23fd <generic_retuprobe_filter_arg+0x23fd>
     e67:      	movq	%rsi, 0x20(%rsp)
     e6c:      	movl	0x10(%r15), %eax
     e70:      	movl	%eax, 0x38(%rsp)
     e74:      	movl	$0x0, 0x70(%rsp)
     e7c:      	movl	$0x1, %eax
     e81:      	leaq	0x38(%rsp), %rsi
     e86:      	movq	(%rip), %rdi            # 0xe8d <generic_retuprobe_filter_arg+0xe8d>
     e8d:      	callq	*%rax
     e8f:      	testl	%ebp, %ebp
     e91:      	je	0x2c5b <generic_retuprobe_filter_arg+0x2c5b>
     e97:      	movl	$0x0, %ebx
     e9c:      	testq	%rax, %rax
     e9f:      	je	0x2c5d <generic_retuprobe_filter_arg+0x2c5d>
     ea5:      	movq	%rax, 0x18(%rsp)
     eaa:      	movl	$0x1, %eax
     eaf:      	movq	0x30(%rsp), %rsi
     eb4:      	movq	(%rip), %rdi            # 0xebb <generic_retuprobe_filter_arg+0xebb>
     ebb:      	callq	*%rax
     ebd:      	testq	%rax, %rax
     ec0:      	je	0x2c5b <generic_retuprobe_filter_arg+0x2c5b>
     ec6:      	cmpl	$0xff, %ebp
     ecc:      	movl	$0xff, %ecx
     ed1:      	cmovael	%ecx, %ebp
     ed4:      	leal	(,%rbp,8), %ecx
     edb:      	movl	%ecx, (%rax)
     edd:      	movq	%rax, %rdi
     ee0:      	addq	$0x4, %rdi
     ee4:      	movq	%rax, %rbx
     ee7:      	movl	$0x4, %eax
     eec:      	movq	0x20(%rsp), %rdx
     ef1:      	movl	%ebp, %esi
     ef3:      	callq	*%rax
     ef5:      	movl	$0x1, %eax
     efa:      	movq	0x18(%rsp), %rdi
     eff:      	movq	%rbx, %rsi
     f02:      	jmp	0x2c4f <generic_retuprobe_filter_arg+0x2c4f>
     f07:      	movl	$0x0, 0x70(%rsp)
     f0f:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
     f15:      	jbe	0x1452 <generic_retuprobe_filter_arg+0x1452>
     f1b:      	xorl	%ebx, %ebx
     f1d:      	movl	0x4(%r15), %eax
     f21:      	cmpq	$0x25, %rax
     f25:      	jbe	0x2c79 <generic_retuprobe_filter_arg+0x2c79>
     f2b:      	jmp	0x265 <generic_retuprobe_filter_arg+0x265>
     f30:      	movq	0x10(%r15), %rsi
     f34:      	movq	0x18(%r15), %rax
     f38:      	cmpl	$0xc, %ecx
     f3b:      	je	0xf46 <generic_retuprobe_filter_arg+0xf46>
     f3d:      	cmpl	$0xa, %ecx
     f40:      	jne	0x19c9 <generic_retuprobe_filter_arg+0x19c9>
     f46:      	movq	(%rbp), %rdx
     f4a:      	cmpq	%rdx, %rsi
     f4d:      	setle	%sil
     f51:      	cmpq	%rax, %rdx
     f54:      	setle	%al
     f57:      	jmp	0x19da <generic_retuprobe_filter_arg+0x19da>
     f5c:      	cmpl	$0xd, %eax
     f5f:      	je	0x12e6 <generic_retuprobe_filter_arg+0x12e6>
     f65:      	cmpl	$0xe, %eax
     f68:      	je	0x12dc <generic_retuprobe_filter_arg+0x12dc>
     f6e:      	movl	$0x0, %ebx
     f73:      	cmpl	$0xf, %eax
     f76:      	je	0x1273 <generic_retuprobe_filter_arg+0x1273>
     f7c:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
     f81:      	cmpl	$0x20, %eax
     f84:      	movq	%rsi, 0x20(%rsp)
     f89:      	jg	0x14ef <generic_retuprobe_filter_arg+0x14ef>
     f8f:      	cmpl	$0x1a, %eax
     f92:      	je	0x16c0 <generic_retuprobe_filter_arg+0x16c0>
     f98:      	movl	$0x0, %ebx
     f9d:      	cmpl	$0x1b, %eax
     fa0:      	jne	0x2ef2 <generic_retuprobe_filter_arg+0x2ef2>
     fa6:      	movl	0x10(%r15), %eax
     faa:      	movl	%eax, 0x38(%rsp)
     fae:      	movl	$0x0, 0x70(%rsp)
     fb6:      	movl	$0x1, %eax
     fbb:      	leaq	0x38(%rsp), %rsi
     fc0:      	movq	(%rip), %rdi            # 0xfc7 <generic_retuprobe_filter_arg+0xfc7>
     fc7:      	callq	*%rax
     fc9:      	testl	%ebp, %ebp
     fcb:      	je	0x2ee2 <generic_retuprobe_filter_arg+0x2ee2>
     fd1:      	movq	%rax, %r12
     fd4:      	movl	$0x0, %ebx
     fd9:      	testq	%rax, %rax
     fdc:      	je	0x2ee4 <generic_retuprobe_filter_arg+0x2ee4>
     fe2:      	movl	$0x1, %eax
     fe7:      	movq	0x30(%rsp), %rsi
     fec:      	movq	(%rip), %rdi            # 0xff3 <generic_retuprobe_filter_arg+0xff3>
     ff3:      	callq	*%rax
     ff5:      	testq	%rax, %rax
     ff8:      	je	0x2ee2 <generic_retuprobe_filter_arg+0x2ee2>
     ffe:      	movq	%rax, %rdi
    1001:      	movq	%r12, 0x18(%rsp)
    1006:      	cmpl	$0x7f, %ebp
    1009:      	movl	$0x7f, %eax
    100e:      	cmovbl	%ebp, %eax
    1011:      	shll	$0x3, %eax
    1014:      	movl	%eax, (%rdi)
    1016:      	movq	%rbp, %rax
    1019:      	negq	%rax
    101c:      	movl	$0x3, %ecx
    1021:      	subq	%rbp, %rcx
    1024:      	leal	-0x4(%rbp), %edx
    1027:      	movq	%rdi, 0x60(%rsp)
    102c:      	addq	$0x7, %rdi
    1030:      	movl	$0x2, %r8d
    1036:      	subq	%rbp, %r8
    1039:      	leal	-0x3(%rbp), %r9d
    103d:      	movl	$0x1, %r10d
    1043:      	subq	%rbp, %r10
    1046:      	leal	-0x2(%rbp), %r11d
    104a:      	decl	%ebp
    104c:      	xorl	%ebx, %ebx
    104e:      	movq	0x20(%rsp), %rsi
    1053:      	leal	(%rbx,%rbp), %r12d
    1057:      	andl	$0xfff, %r12d           # imm = 0xFFF
    105e:      	movzbl	(%rsi,%r12), %r12d
    1063:      	movb	%r12b, -0x3(%rdi)
    1067:      	cmpq	%rbx, %r10
    106a:      	je	0x10c4 <generic_retuprobe_filter_arg+0x10c4>
    106c:      	leal	(%r11,%rbx), %r12d
    1070:      	andl	$0xfff, %r12d           # imm = 0xFFF
    1077:      	movzbl	(%rsi,%r12), %r12d
    107c:      	movb	%r12b, -0x2(%rdi)
    1080:      	cmpq	%rbx, %r8
    1083:      	je	0x10c4 <generic_retuprobe_filter_arg+0x10c4>
    1085:      	leal	(%r9,%rbx), %r12d
    1089:      	andl	$0xfff, %r12d           # imm = 0xFFF
    1090:      	movzbl	(%rsi,%r12), %r12d
    1095:      	movb	%r12b, -0x1(%rdi)
    1099:      	cmpq	%rbx, %rcx
    109c:      	je	0x10c4 <generic_retuprobe_filter_arg+0x10c4>
    109e:      	cmpq	$-0x7c, %rbx
    10a2:      	je	0x10c4 <generic_retuprobe_filter_arg+0x10c4>
    10a4:      	leal	(%rdx,%rbx), %r12d
    10a8:      	andl	$0xfff, %r12d           # imm = 0xFFF
    10af:      	movzbl	(%rsi,%r12), %r12d
    10b4:      	movb	%r12b, (%rdi)
    10b7:      	addq	$-0x4, %rbx
    10bb:      	addq	$0x4, %rdi
    10bf:      	cmpq	%rbx, %rax
    10c2:      	jne	0x1053 <generic_retuprobe_filter_arg+0x1053>
    10c4:      	movl	$0x1, %eax
    10c9:      	movq	0x18(%rsp), %rdi
    10ce:      	movq	0x60(%rsp), %rsi
    10d3:      	jmp	0x2ed6 <generic_retuprobe_filter_arg+0x2ed6>
    10d8:      	cmpl	$0xc, %eax
    10db:      	jne	0x2062 <generic_retuprobe_filter_arg+0x2062>
    10e1:      	testl	%edx, (%rbp)
    10e4:      	jne	0x276 <generic_retuprobe_filter_arg+0x276>
    10ea:      	jmp	0x2062 <generic_retuprobe_filter_arg+0x2062>
    10ef:      	movl	$0xc00, %edx            # imm = 0xC00
    10f4:      	btq	%rcx, %rdx
    10f8:      	jb	0x15c2 <generic_retuprobe_filter_arg+0x15c2>
    10fe:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    1108:      	btq	%rcx, %rdx
    110c:      	jae	0xb8 <generic_retuprobe_filter_arg+0xb8>
    1112:      	cmpl	$0x1f, %eax
    1115:      	jne	0x1c93 <generic_retuprobe_filter_arg+0x1c93>
    111b:      	movzbl	(%rbp), %eax
    111f:      	jmp	0x1151 <generic_retuprobe_filter_arg+0x1151>
    1121:      	movl	$0xc00, %edx            # imm = 0xC00
    1126:      	btq	%rcx, %rdx
    112a:      	jb	0x15ff <generic_retuprobe_filter_arg+0x15ff>
    1130:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    113a:      	btq	%rcx, %rdx
    113e:      	jae	0xb8 <generic_retuprobe_filter_arg+0xb8>
    1144:      	cmpl	$0x1f, %eax
    1147:      	jne	0x1c9d <generic_retuprobe_filter_arg+0x1c9d>
    114d:      	movzwl	(%rbp), %eax
    1151:      	cmpl	%eax, 0x10(%r15)
    1155:      	ja	0x1161 <generic_retuprobe_filter_arg+0x1161>
    1157:      	cmpl	%eax, 0x14(%r15)
    115b:      	jae	0x276 <generic_retuprobe_filter_arg+0x276>
    1161:      	movl	0x8(%r15), %ecx
    1165:      	cmpl	$0x11, %ecx
    1168:      	jb	0xb8 <generic_retuprobe_filter_arg+0xb8>
    116e:      	cmpl	%eax, 0x18(%r15)
    1172:      	ja	0x117e <generic_retuprobe_filter_arg+0x117e>
    1174:      	cmpl	%eax, 0x1c(%r15)
    1178:      	jae	0x276 <generic_retuprobe_filter_arg+0x276>
    117e:      	cmpl	$0x19, %ecx
    1181:      	jb	0xb8 <generic_retuprobe_filter_arg+0xb8>
    1187:      	cmpl	%eax, 0x20(%r15)
    118b:      	ja	0x1197 <generic_retuprobe_filter_arg+0x1197>
    118d:      	cmpl	%eax, 0x24(%r15)
    1191:      	jae	0x276 <generic_retuprobe_filter_arg+0x276>
    1197:      	cmpl	$0x21, %ecx
    119a:      	jb	0xb8 <generic_retuprobe_filter_arg+0xb8>
    11a0:      	cmpl	%eax, 0x28(%r15)
    11a4:      	ja	0xb8 <generic_retuprobe_filter_arg+0xb8>
    11aa:      	cmpl	%eax, 0x2c(%r15)
    11ae:      	jae	0x276 <generic_retuprobe_filter_arg+0x276>
    11b4:      	jmp	0xb8 <generic_retuprobe_filter_arg+0xb8>
    11b9:      	cmpl	$0xc, %ecx
    11bc:      	je	0x11c7 <generic_retuprobe_filter_arg+0x11c7>
    11be:      	cmpl	$0xa, %ecx
    11c1:      	jne	0x1a9a <generic_retuprobe_filter_arg+0x1a9a>
    11c7:      	cmpq	%rdx, (%rbp)
    11cb:      	jg	0x276 <generic_retuprobe_filter_arg+0x276>
    11d1:      	jmp	0x1ab0 <generic_retuprobe_filter_arg+0x1ab0>
    11d6:      	movzwl	%bp, %eax
    11d9:      	cmpl	$0x90, %eax
    11de:      	ja	0x17db <generic_retuprobe_filter_arg+0x17db>
    11e4:      	testw	%bp, %bp
    11e7:      	je	0x11f9 <generic_retuprobe_filter_arg+0x11f9>
    11e9:      	movl	%ebp, %eax
    11eb:      	movl	$0x18, %ecx
    11f0:      	cltd
    11f1:      	idivl	%ecx
    11f3:      	movl	%ebp, %esi
    11f5:      	testl	%edx, %edx
    11f7:      	je	0x121b <generic_retuprobe_filter_arg+0x121b>
    11f9:      	movl	%ebp, %eax
    11fb:      	movl	$0x18, %ecx
    1200:      	cltd
    1201:      	idivl	%ecx
    1203:      	shll	$0x3, %eax
    1206:      	leal	(%rax,%rax,2), %eax
    1209:      	addl	$0x18, %eax
    120c:      	movzwl	%ax, %esi
    120f:      	cmpl	$0x90, %esi
    1215:      	ja	0x17ef <generic_retuprobe_filter_arg+0x17ef>
    121b:      	movl	%esi, %eax
    121d:      	cltd
    121e:      	idivl	%ecx
    1220:      	decl	%eax
    1222:      	jmp	0x1800 <generic_retuprobe_filter_arg+0x1800>
    1227:      	movl	0x10(%r15), %esi
    122b:      	movl	0x14(%r15), %eax
    122f:      	cmpl	$0xc, %ecx
    1232:      	ja	0x1f0f <generic_retuprobe_filter_arg+0x1f0f>
    1238:      	movl	$0x1402, %edx           # imm = 0x1402
    123d:      	btl	%ecx, %edx
    1240:      	jae	0x1f0f <generic_retuprobe_filter_arg+0x1f0f>
    1246:      	movl	(%rbp), %edx
    1249:      	cmpl	%edx, %esi
    124b:      	setle	%sil
    124f:      	cmpl	%eax, %edx
    1251:      	setle	%al
    1254:      	jmp	0x1f1d <generic_retuprobe_filter_arg+0x1f1d>
    1259:      	cmpl	$0x12, %eax
    125c:      	je	0x1273 <generic_retuprobe_filter_arg+0x1273>
    125e:      	movl	$0x0, %ebx
    1263:      	cmpl	$0x13, %eax
    1266:      	jne	0x260 <generic_retuprobe_filter_arg+0x260>
    126c:      	movzwl	0x22(%rsi), %r12d
    1271:      	jmp	0x1278 <generic_retuprobe_filter_arg+0x1278>
    1273:      	movzwl	0x20(%rsi), %r12d
    1278:      	xorl	%edx, %edx
    127a:      	xorl	%ebp, %ebp
    127c:      	xorl	%r8d, %r8d
    127f:      	xorl	%ebx, %ebx
    1281:      	cmpl	$0x11, %eax
    1284:      	jg	0x12fe <generic_retuprobe_filter_arg+0x12fe>
    1286:      	leal	-0xd(%rax), %ecx
    1289:      	cmpl	$0x2, %ecx
    128c:      	jb	0x1331 <generic_retuprobe_filter_arg+0x1331>
    1292:      	leal	-0xf(%rax), %ecx
    1295:      	cmpl	$0x2, %ecx
    1298:      	jb	0x14af <generic_retuprobe_filter_arg+0x14af>
    129e:      	cmpl	$0x11, %eax
    12a1:      	je	0x1a17 <generic_retuprobe_filter_arg+0x1a17>
    12a7:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
    12ac:      	cmpl	$0x1c, %eax
    12af:      	je	0x1a13 <generic_retuprobe_filter_arg+0x1a13>
    12b5:      	movl	$0x0, %ebx
    12ba:      	cmpl	$0x1d, %eax
    12bd:      	jne	0x260 <generic_retuprobe_filter_arg+0x260>
    12c3:      	cmpl	$0x7, %ecx
    12c6:      	jne	0x1ff2 <generic_retuprobe_filter_arg+0x1ff2>
    12cc:      	testq	%rdx, %rdx
    12cf:      	jne	0x1ffe <generic_retuprobe_filter_arg+0x1ffe>
    12d5:      	xorl	%ebx, %ebx
    12d7:      	jmp	0x2010 <generic_retuprobe_filter_arg+0x2010>
    12dc:      	movq	0x10(%rsi), %rdx
    12e0:      	movq	0x18(%rsi), %r8
    12e4:      	jmp	0x12ed <generic_retuprobe_filter_arg+0x12ed>
    12e6:      	movq	(%rsi), %rdx
    12e9:      	movq	0x8(%rsi), %r8
    12ed:      	movq	%rdx, %rbp
    12f0:      	shrq	$0x20, %rbp
    12f4:      	xorl	%r12d, %r12d
    12f7:      	xorl	%ebx, %ebx
    12f9:      	cmpl	$0x11, %eax
    12fc:      	jle	0x1286 <generic_retuprobe_filter_arg+0x1286>
    12fe:      	cmpl	$0x19, %eax
    1301:      	ja	0x14a3 <generic_retuprobe_filter_arg+0x14a3>
    1307:      	movl	$0x500000, %ecx         # imm = 0x500000
    130c:      	btl	%eax, %ecx
    130f:      	jb	0x17b5 <generic_retuprobe_filter_arg+0x17b5>
    1315:      	movl	$0xa00000, %ecx         # imm = 0xA00000
    131a:      	btl	%eax, %ecx
    131d:      	jb	0x17c8 <generic_retuprobe_filter_arg+0x17c8>
    1323:      	movl	$0x3000000, %ecx        # imm = 0x3000000
    1328:      	btl	%eax, %ecx
    132b:      	jae	0x14a3 <generic_retuprobe_filter_arg+0x14a3>
    1331:      	movzwl	0x26(%rsi), %eax
    1335:      	cmpl	$0xa, %eax
    1338:      	je	0x18e1 <generic_retuprobe_filter_arg+0x18e1>
    133e:      	cmpl	$0x2, %eax
    1341:      	jne	0x196f <generic_retuprobe_filter_arg+0x196f>
    1347:      	movq	%rdx, %rbx
    134a:      	movl	0x10(%r15), %eax
    134e:      	movl	%eax, 0x2c(%rsp)
    1352:      	movl	$0x1, %eax
    1357:      	leaq	0x2c(%rsp), %rsi
    135c:      	movq	(%rip), %rdi            # 0x1363 <generic_retuprobe_filter_arg+0x1363>
    1363:      	callq	*%rax
    1365:      	testq	%rax, %rax
    1368:      	je	0x1b60 <generic_retuprobe_filter_arg+0x1b60>
    136e:      	movq	%rax, %rdi
    1371:      	movl	$0x20, 0x70(%rsp)
    1379:      	movl	%ebx, 0x74(%rsp)
    137d:      	jmp	0x192f <generic_retuprobe_filter_arg+0x192f>
    1382:      	cmpl	$0xc, %ecx
    1385:      	ja	0x204e <generic_retuprobe_filter_arg+0x204e>
    138b:      	movl	$0x1402, %esi           # imm = 0x1402
    1390:      	btl	%ecx, %esi
    1393:      	jae	0x204e <generic_retuprobe_filter_arg+0x204e>
    1399:      	cmpl	%edx, (%rbp)
    139c:      	jg	0x276 <generic_retuprobe_filter_arg+0x276>
    13a2:      	jmp	0x2062 <generic_retuprobe_filter_arg+0x2062>
    13a7:      	movq	%rsi, 0x20(%rsp)
    13ac:      	xorl	%ebx, %ebx
    13ae:      	xorl	%r12d, %r12d
    13b1:      	movl	0x10(%r15,%rbx,4), %eax
    13b6:      	movl	%eax, 0x38(%rsp)
    13ba:      	movl	$0x1, %eax
    13bf:      	leaq	0x38(%rsp), %rsi
    13c4:      	movq	(%rip), %rdi            # 0x13cb <generic_retuprobe_filter_arg+0x13cb>
    13cb:      	callq	*%rax
    13cd:      	testq	%rax, %rax
    13d0:      	je	0x2109 <generic_retuprobe_filter_arg+0x2109>
    13d6:      	testl	%ebp, %ebp
    13d8:      	movq	0x8(%rsp), %r9
    13dd:      	movq	0x10(%rsp), %r11
    13e2:      	je	0x142f <generic_retuprobe_filter_arg+0x142f>
    13e4:      	movq	0x20(%rsp), %rdx
    13e9:      	xorl	%ecx, %ecx
    13eb:      	jmp	0x13f8 <generic_retuprobe_filter_arg+0x13f8>
    13ed:      	incq	%rcx
    13f0:      	incq	%rdx
    13f3:      	cmpq	%rbp, %rcx
    13f6:      	je	0x142f <generic_retuprobe_filter_arg+0x142f>
    13f8:      	xorl	%esi, %esi
    13fa:      	nopw	(%rax,%rax)
    1400:      	leaq	(%rcx,%rsi), %rdi
    1404:      	cmpq	%rbp, %rdi
    1407:      	jae	0x13ed <generic_retuprobe_filter_arg+0x13ed>
    1409:      	movzbl	(%rax,%rsi), %edi
    140d:      	testb	%dil, %dil
    1410:      	je	0x1427 <generic_retuprobe_filter_arg+0x1427>
    1412:      	cmpq	$0x62, %rsi
    1416:      	ja	0x13ed <generic_retuprobe_filter_arg+0x13ed>
    1418:      	leaq	0x1(%rsi), %r8
    141c:      	cmpb	%dil, (%rdx,%rsi)
    1420:      	movq	%r8, %rsi
    1423:      	je	0x1400 <generic_retuprobe_filter_arg+0x1400>
    1425:      	jmp	0x13ed <generic_retuprobe_filter_arg+0x13ed>
    1427:      	testl	%ecx, %ecx
    1429:      	jns	0x23d7 <generic_retuprobe_filter_arg+0x23d7>
    142f:      	leal	0xc(%r12), %eax
    1434:      	cmpl	0x8(%r15), %eax
    1438:      	jae	0x144b <generic_retuprobe_filter_arg+0x144b>
    143a:      	addl	$0x4, %r12d
    143e:      	incq	%rbx
    1441:      	cmpq	$0x64, %rbx
    1445:      	jne	0x13b1 <generic_retuprobe_filter_arg+0x13b1>
    144b:      	xorl	%ebx, %ebx
    144d:      	jmp	0x23dc <generic_retuprobe_filter_arg+0x23dc>
    1452:      	movzwl	%bp, %eax
    1455:      	cmpl	$0x90, %eax
    145a:      	ja	0x1b6f <generic_retuprobe_filter_arg+0x1b6f>
    1460:      	testw	%bp, %bp
    1463:      	je	0x1475 <generic_retuprobe_filter_arg+0x1475>
    1465:      	movl	%ebp, %eax
    1467:      	movl	$0x18, %ecx
    146c:      	cltd
    146d:      	idivl	%ecx
    146f:      	movl	%ebp, %edi
    1471:      	testl	%edx, %edx
    1473:      	je	0x1497 <generic_retuprobe_filter_arg+0x1497>
    1475:      	movl	%ebp, %eax
    1477:      	movl	$0x18, %ecx
    147c:      	cltd
    147d:      	idivl	%ecx
    147f:      	shll	$0x3, %eax
    1482:      	leal	(%rax,%rax,2), %eax
    1485:      	addl	$0x18, %eax
    1488:      	movzwl	%ax, %edi
    148b:      	cmpl	$0x90, %edi
    1491:      	ja	0x1b83 <generic_retuprobe_filter_arg+0x1b83>
    1497:      	movl	%edi, %eax
    1499:      	cltd
    149a:      	idivl	%ecx
    149c:      	decl	%eax
    149e:      	jmp	0x1b94 <generic_retuprobe_filter_arg+0x1b94>
    14a3:      	addl	$-0x12, %eax
    14a6:      	cmpl	$0x2, %eax
    14a9:      	jae	0x260 <generic_retuprobe_filter_arg+0x260>
    14af:      	movzbl	0x10(%r15), %eax
    14b4:      	movl	%eax, 0x2c(%rsp)
    14b8:      	movl	$0x1, %eax
    14bd:      	movq	(%rip), %rdi            # 0x14c4 <generic_retuprobe_filter_arg+0x14c4>
    14c4:      	leaq	0x2c(%rsp), %rsi
    14c9:      	callq	*%rax
    14cb:      	testq	%rax, %rax
    14ce:      	je	0x250 <generic_retuprobe_filter_arg+0x250>
    14d4:      	movq	%rax, %rdi
    14d7:      	movzwl	%r12w, %eax
    14db:      	movq	%rax, 0x70(%rsp)
    14e0:      	movl	$0x1, %eax
    14e5:      	movq	0x30(%rsp), %rsi
    14ea:      	jmp	0x1a51 <generic_retuprobe_filter_arg+0x1a51>
    14ef:      	cmpl	$0x21, %eax
    14f2:      	je	0x1d15 <generic_retuprobe_filter_arg+0x1d15>
    14f8:      	movl	$0x0, %ebx
    14fd:      	cmpl	$0x22, %eax
    1500:      	jne	0x2ef2 <generic_retuprobe_filter_arg+0x2ef2>
    1506:      	movl	$0x10, %r12d
    150c:      	movl	(%r15,%r12), %eax
    1510:      	movl	%eax, 0x38(%rsp)
    1514:      	movl	$0x1, %eax
    1519:      	leaq	0x38(%rsp), %rsi
    151e:      	movq	(%rip), %rdi            # 0x1525 <generic_retuprobe_filter_arg+0x1525>
    1525:      	callq	*%rax
    1527:      	testq	%rax, %rax
    152a:      	je	0x2ee2 <generic_retuprobe_filter_arg+0x2ee2>
    1530:      	movq	0x20(%rsp), %rdi
    1535:      	movq	%rax, %rsi
    1538:      	movq	%rbp, %rdx
    153b:      	callq	0x1540 <generic_retuprobe_filter_arg+0x1540>
    1540:      	testl	%eax, %eax
    1542:      	jns	0x26e8 <generic_retuprobe_filter_arg+0x26e8>
    1548:      	addq	$0x4, %r12
    154c:      	leal	-0x8(%r12), %eax
    1551:      	cmpl	0x8(%r15), %eax
    1555:      	movq	(%rsp), %rdi
    1559:      	movq	0x8(%rsp), %r9
    155e:      	movq	0x10(%rsp), %r11
    1563:      	jae	0x1768 <generic_retuprobe_filter_arg+0x1768>
    1569:      	movl	$0x0, %ebx
    156e:      	cmpq	$0x1a0, %r12            # imm = 0x1A0
    1575:      	jne	0x150c <generic_retuprobe_filter_arg+0x150c>
    1577:      	jmp	0x2ef2 <generic_retuprobe_filter_arg+0x2ef2>
    157c:      	cmpl	$0x1, %eax
    157f:      	je	0x1e17 <generic_retuprobe_filter_arg+0x1e17>
    1585:      	cmpl	$0x2, %eax
    1588:      	jne	0x1e23 <generic_retuprobe_filter_arg+0x1e23>
    158e:      	movzbl	(%rbp), %edx
    1592:      	cmpl	%edx, %ecx
    1594:      	ja	0x276 <generic_retuprobe_filter_arg+0x276>
    159a:      	jmp	0x1e23 <generic_retuprobe_filter_arg+0x1e23>
    159f:      	cmpl	$0x1, %eax
    15a2:      	je	0x1e5a <generic_retuprobe_filter_arg+0x1e5a>
    15a8:      	cmpl	$0x2, %eax
    15ab:      	jne	0x1e66 <generic_retuprobe_filter_arg+0x1e66>
    15b1:      	movzwl	(%rbp), %edx
    15b5:      	cmpl	%edx, %ecx
    15b7:      	ja	0x276 <generic_retuprobe_filter_arg+0x276>
    15bd:      	jmp	0x1e66 <generic_retuprobe_filter_arg+0x1e66>
    15c2:      	movzbl	0x10(%r15), %eax
    15c7:      	movl	%eax, 0x70(%rsp)
    15cb:      	movl	$0x1, %eax
    15d0:      	movq	0x30(%rsp), %rsi
    15d5:      	movq	(%rip), %rdi            # 0x15dc <generic_retuprobe_filter_arg+0x15dc>
    15dc:      	callq	*%rax
    15de:      	testq	%rax, %rax
    15e1:      	je	0x166d <generic_retuprobe_filter_arg+0x166d>
    15e7:      	movq	%rax, %rdi
    15ea:      	movzbl	(%rbp), %eax
    15ee:      	movq	%rax, 0x38(%rsp)
    15f3:      	movl	$0x1, %eax
    15f8:      	leaq	0x38(%rsp), %rsi
    15fd:      	jmp	0x1636 <generic_retuprobe_filter_arg+0x1636>
    15ff:      	movzbl	0x10(%r15), %eax
    1604:      	movl	%eax, 0x70(%rsp)
    1608:      	movl	$0x1, %eax
    160d:      	movq	0x30(%rsp), %rsi
    1612:      	movq	(%rip), %rdi            # 0x1619 <generic_retuprobe_filter_arg+0x1619>
    1619:      	callq	*%rax
    161b:      	testq	%rax, %rax
    161e:      	je	0x166d <generic_retuprobe_filter_arg+0x166d>
    1620:      	movq	%rax, %rdi
    1623:      	movzwl	(%rbp), %eax
    1627:      	movq	%rax, 0x38(%rsp)
    162c:      	movl	$0x1, %eax
    1631:      	leaq	0x38(%rsp), %rsi
    1636:      	callq	*%rax
    1638:      	movl	0x4(%r15), %edx
    163c:      	xorl	%ecx, %ecx
    163e:      	cmpl	$0x1d, %edx
    1641:      	ja	0x263d <generic_retuprobe_filter_arg+0x263d>
    1647:      	movl	$0x30038400, %esi       # imm = 0x30038400
    164c:      	btl	%edx, %esi
    164f:      	movq	(%rsp), %rdi
    1653:      	movq	0x8(%rsp), %r9
    1658:      	movq	0x10(%rsp), %r11
    165d:      	jae	0x1682 <generic_retuprobe_filter_arg+0x1682>
    165f:      	testq	%rax, %rax
    1662:      	setne	%cl
    1665:      	movzbl	%cl, %ebx
    1668:      	jmp	0x265 <generic_retuprobe_filter_arg+0x265>
    166d:      	xorl	%ebx, %ebx
    166f:      	movq	(%rsp), %rdi
    1673:      	movq	0x8(%rsp), %r9
    1678:      	movq	0x10(%rsp), %r11
    167d:      	jmp	0x265 <generic_retuprobe_filter_arg+0x265>
    1682:      	movl	$0xc0800, %esi          # imm = 0xC0800
    1687:      	btl	%edx, %esi
    168a:      	jae	0x1692 <generic_retuprobe_filter_arg+0x1692>
    168c:      	testq	%rax, %rax
    168f:      	sete	%cl
    1692:      	movzbl	%cl, %ebx
    1695:      	jmp	0x265 <generic_retuprobe_filter_arg+0x265>
    169a:      	testq	%rax, %rax
    169d:      	sete	%al
    16a0:      	movq	(%rsp), %rdi
    16a4:      	movq	0x8(%rsp), %r9
    16a9:      	movq	0x10(%rsp), %r11
    16ae:      	movzbl	%al, %ebx
    16b1:      	jmp	0x265 <generic_retuprobe_filter_arg+0x265>
    16b6:      	xorl	%eax, %eax
    16b8:      	movzbl	%al, %ebx
    16bb:      	jmp	0x265 <generic_retuprobe_filter_arg+0x265>
    16c0:      	movl	0x10(%r15), %eax
    16c4:      	movl	%eax, 0x38(%rsp)
    16c8:      	movl	$0x0, 0x70(%rsp)
    16d0:      	movl	$0x1, %eax
    16d5:      	leaq	0x38(%rsp), %rsi
    16da:      	movq	(%rip), %rdi            # 0x16e1 <generic_retuprobe_filter_arg+0x16e1>
    16e1:      	callq	*%rax
    16e3:      	testl	%ebp, %ebp
    16e5:      	je	0x2ee2 <generic_retuprobe_filter_arg+0x2ee2>
    16eb:      	movq	%rax, %r12
    16ee:      	movl	$0x0, %ebx
    16f3:      	testq	%rax, %rax
    16f6:      	je	0x2ee4 <generic_retuprobe_filter_arg+0x2ee4>
    16fc:      	movl	$0x1, %eax
    1701:      	movq	0x30(%rsp), %rsi
    1706:      	movq	(%rip), %rdi            # 0x170d <generic_retuprobe_filter_arg+0x170d>
    170d:      	callq	*%rax
    170f:      	testq	%rax, %rax
    1712:      	je	0x2ee2 <generic_retuprobe_filter_arg+0x2ee2>
    1718:      	cmpl	$0xff, %ebp
    171e:      	movl	$0xff, %ecx
    1723:      	cmovael	%ecx, %ebp
    1726:      	leal	(,%rbp,8), %ecx
    172d:      	movl	%ecx, (%rax)
    172f:      	movq	%rax, %rdi
    1732:      	addq	$0x4, %rdi
    1736:      	movq	%rax, %rbx
    1739:      	movl	$0x4, %eax
    173e:      	movq	0x20(%rsp), %rdx
    1743:      	movl	%ebp, %esi
    1745:      	callq	*%rax
    1747:      	movl	$0x1, %eax
    174c:      	movq	%r12, %rdi
    174f:      	jmp	0x2ed3 <generic_retuprobe_filter_arg+0x2ed3>
    1754:      	movl	$0x0, 0x70(%rsp)
    175c:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
    1762:      	jbe	0x1dc6 <generic_retuprobe_filter_arg+0x1dc6>
    1768:      	xorl	%ebx, %ebx
    176a:      	jmp	0x2ef2 <generic_retuprobe_filter_arg+0x2ef2>
    176f:      	cmpl	$0x1e, %eax
    1772:      	jne	0xb8 <generic_retuprobe_filter_arg+0xb8>
    1778:      	movl	0x10(%r15), %eax
    177c:      	andl	$0x7, %eax
    177f:      	movl	%eax, %ecx
    1781:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    178a:      	jne	0xb8 <generic_retuprobe_filter_arg+0xb8>
    1790:      	movq	(%rbp), %rcx
    1794:      	movq	0x5e78(%r14,%rax,8), %rax
    179c:      	andl	$0x7ff, %eax            # imm = 0x7FF
    17a1:      	xorl	%ebx, %ebx
    17a3:      	andnq	0x90(%r14,%rax), %rcx, %rax
    17ad:      	setne	%bl
    17b0:      	jmp	0x265 <generic_retuprobe_filter_arg+0x265>
    17b5:      	movzwl	%r12w, %eax
    17b9:      	xorl	%ebx, %ebx
    17bb:      	cmpl	$0x400, %eax            # imm = 0x400
    17c0:      	setb	%bl
    17c3:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
    17c8:      	movzwl	%r12w, %eax
    17cc:      	xorl	%ebx, %ebx
    17ce:      	cmpl	$0x400, %eax            # imm = 0x400
    17d3:      	setae	%bl
    17d6:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
    17db:      	cmpl	$0x101, %eax            # imm = 0x101
    17e0:      	movl	$0x100, %esi            # imm = 0x100
    17e5:      	movl	$0x1fe, %eax            # imm = 0x1FE
    17ea:      	cmovael	%eax, %esi
    17ed:      	movl	%esi, %eax
    17ef:      	movzwl	%ax, %ecx
    17f2:      	xorl	%eax, %eax
    17f4:      	cmpl	$0x100, %ecx            # imm = 0x100
    17fa:      	sete	%al
    17fd:      	xorl	$0x7, %eax
    1800:      	movl	%eax, %ecx
    1802:      	andl	$0xf, %ecx
    1805:      	movl	0x10(%r15,%rcx,4), %ecx
    180a:      	cmpl	$-0x1, %ecx
    180d:      	je	0x2aa6 <generic_retuprobe_filter_arg+0x2aa6>
    1813:      	movl	%ecx, 0x90(%rsp)
    181a:      	movq	%rsi, 0x88(%rsp)
    1822:      	movl	%eax, 0x60(%rsp)
    1826:      	movl	$0x1, %eax
    182b:      	movq	(%rip), %rdi            # 0x1832 <generic_retuprobe_filter_arg+0x1832>
    1832:      	movq	0x30(%rsp), %rbx
    1837:      	movq	%rbx, %rsi
    183a:      	callq	*%rax
    183c:      	movq	%rax, 0x18(%rsp)
    1841:      	movl	$0x1, %eax
    1846:      	movq	(%rip), %rdi            # 0x184d <generic_retuprobe_filter_arg+0x184d>
    184d:      	movq	%rbx, %rsi
    1850:      	callq	*%rax
    1852:      	cmpq	$0x0, 0x18(%rsp)
    1858:      	je	0x2aa6 <generic_retuprobe_filter_arg+0x2aa6>
    185e:      	movl	$0x0, %ebx
    1863:      	testq	%rax, %rax
    1866:      	movq	(%rsp), %rdi
    186a:      	movq	0x8(%rsp), %r9
    186f:      	movq	0x10(%rsp), %r11
    1874:      	je	0x2ab6 <generic_retuprobe_filter_arg+0x2ab6>
    187a:      	movq	%rax, 0x98(%rsp)
    1882:      	movq	0x20(%rsp), %rdx
    1887:      	addq	$0x4, %rdx
    188b:      	movl	0x60(%rsp), %ebx
    188f:      	cmpl	$0x5, %ebx
    1892:      	jg	0x216c <generic_retuprobe_filter_arg+0x216c>
    1898:      	movq	0x18(%rsp), %rax
    189d:      	movb	%bpl, (%rax)
    18a0:      	leaq	0x1(%rax), %rdi
    18a4:      	movl	$0x4, %eax
    18a9:      	movl	%ebp, %esi
    18ab:      	callq	*%rax
    18ad:      	movq	0x88(%rsp), %rsi
    18b5:      	subl	%ebp, %esi
    18b7:      	jbe	0x21af <generic_retuprobe_filter_arg+0x21af>
    18bd:      	movq	0x18(%rsp), %rax
    18c2:      	leaq	(%rax,%rbp), %rdi
    18c6:      	incq	%rdi
    18c9:      	andl	$0xfff, %esi            # imm = 0xFFF
    18cf:      	movl	$0x4, %eax
    18d4:      	movq	0x98(%rsp), %rdx
    18dc:      	jmp	0x21ad <generic_retuprobe_filter_arg+0x21ad>
    18e1:      	movq	%r8, %r12
    18e4:      	movq	%rdx, %rbx
    18e7:      	movl	0x14(%r15), %eax
    18eb:      	movl	%eax, 0x2c(%rsp)
    18ef:      	movl	$0x1, %eax
    18f4:      	movq	(%rip), %rdi            # 0x18fb <generic_retuprobe_filter_arg+0x18fb>
    18fb:      	leaq	0x2c(%rsp), %rsi
    1900:      	callq	*%rax
    1902:      	testq	%rax, %rax
    1905:      	je	0x1b60 <generic_retuprobe_filter_arg+0x1b60>
    190b:      	movq	%rax, %rdi
    190e:      	movl	$0x80, 0x70(%rsp)
    1916:      	movl	%ebx, 0x74(%rsp)
    191a:      	movl	%ebp, 0x78(%rsp)
    191e:      	movl	%r12d, 0x7c(%rsp)
    1923:      	shrq	$0x20, %r12
    1927:      	movl	%r12d, 0x80(%rsp)
    192f:      	movl	$0x1, %eax
    1934:      	movq	0x30(%rsp), %rsi
    1939:      	callq	*%rax
    193b:      	movl	0x4(%r15), %ecx
    193f:      	leal	-0x18(%rcx), %edx
    1942:      	cmpl	$0x2, %edx
    1945:      	jb	0x1e9d <generic_retuprobe_filter_arg+0x1e9d>
    194b:      	addl	$-0xd, %ecx
    194e:      	cmpl	$0x1, %ecx
    1951:      	movq	(%rsp), %rdi
    1955:      	movq	0x8(%rsp), %r9
    195a:      	movq	0x10(%rsp), %r11
    195f:      	ja	0x196f <generic_retuprobe_filter_arg+0x196f>
    1961:      	testq	%rax, %rax
    1964:      	setne	%al
    1967:      	movzbl	%al, %ebx
    196a:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
    196f:      	xorl	%eax, %eax
    1971:      	movzbl	%al, %ebx
    1974:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
    1979:      	movq	(%rbp), %rax
    197d:      	cmpq	%rax, %rsi
    1980:      	ja	0x198b <generic_retuprobe_filter_arg+0x198b>
    1982:      	cmpq	%rdx, %rax
    1985:      	jbe	0x276 <generic_retuprobe_filter_arg+0x276>
    198b:      	movl	0x8(%r15), %edx
    198f:      	cmpl	$0x19, %edx
    1992:      	jb	0xb8 <generic_retuprobe_filter_arg+0xb8>
    1998:      	movq	0x20(%r15), %rdi
    199c:      	movq	0x28(%r15), %rsi
    19a0:      	cmpl	$0xc, %ecx
    19a3:      	je	0x19ae <generic_retuprobe_filter_arg+0x19ae>
    19a5:      	cmpl	$0xa, %ecx
    19a8:      	jne	0x1fa6 <generic_retuprobe_filter_arg+0x1fa6>
    19ae:      	cmpq	%rax, %rdi
    19b1:      	movq	(%rsp), %rdi
    19b5:      	jg	0x1fb8 <generic_retuprobe_filter_arg+0x1fb8>
    19bb:      	cmpq	%rsi, %rax
    19be:      	jle	0x276 <generic_retuprobe_filter_arg+0x276>
    19c4:      	jmp	0x1fb8 <generic_retuprobe_filter_arg+0x1fb8>
    19c9:      	movq	(%rbp), %rdx
    19cd:      	cmpq	%rdx, %rsi
    19d0:      	setbe	%sil
    19d4:      	cmpq	%rax, %rdx
    19d7:      	setbe	%al
    19da:      	andb	%sil, %al
    19dd:      	movl	0x8(%r15), %esi
    19e1:      	cmpl	$0x19, %esi
    19e4:      	jb	0x2af3 <generic_retuprobe_filter_arg+0x2af3>
    19ea:      	movq	0x20(%r15), %r8
    19ee:      	movq	0x28(%r15), %rdi
    19f2:      	cmpl	$0xc, %ecx
    19f5:      	je	0x1a00 <generic_retuprobe_filter_arg+0x1a00>
    19f7:      	cmpl	$0xa, %ecx
    19fa:      	jne	0x1f60 <generic_retuprobe_filter_arg+0x1f60>
    1a00:      	cmpq	%rdx, %r8
    1a03:      	setle	%r8b
    1a07:      	cmpq	%rdi, %rdx
    1a0a:      	setle	%dil
    1a0e:      	jmp	0x1f6e <generic_retuprobe_filter_arg+0x1f6e>
    1a13:      	movzwl	0x26(%rsi), %ebx
    1a17:      	movzbl	0x10(%r15), %eax
    1a1c:      	movl	%eax, 0x2c(%rsp)
    1a20:      	movl	$0x1, %eax
    1a25:      	movq	(%rip), %rdi            # 0x1a2c <generic_retuprobe_filter_arg+0x1a2c>
    1a2c:      	leaq	0x2c(%rsp), %rsi
    1a31:      	callq	*%rax
    1a33:      	testq	%rax, %rax
    1a36:      	je	0x250 <generic_retuprobe_filter_arg+0x250>
    1a3c:      	movq	%rax, %rdi
    1a3f:      	movzwl	%bx, %eax
    1a42:      	movq	%rax, 0x70(%rsp)
    1a47:      	movl	$0x1, %eax
    1a4c:      	movq	0x30(%rsp), %rsi
    1a51:      	callq	*%rax
    1a53:      	movl	0x4(%r15), %edx
    1a57:      	xorl	%ecx, %ecx
    1a59:      	cmpl	$0x1d, %edx
    1a5c:      	ja	0x2653 <generic_retuprobe_filter_arg+0x2653>
    1a62:      	movl	$0x30038400, %esi       # imm = 0x30038400
    1a67:      	btl	%edx, %esi
    1a6a:      	movq	(%rsp), %rdi
    1a6e:      	movq	0x8(%rsp), %r9
    1a73:      	movq	0x10(%rsp), %r11
    1a78:      	jae	0x1a82 <generic_retuprobe_filter_arg+0x1a82>
    1a7a:      	testq	%rax, %rax
    1a7d:      	setne	%cl
    1a80:      	jmp	0x1a92 <generic_retuprobe_filter_arg+0x1a92>
    1a82:      	movl	$0xc0800, %esi          # imm = 0xC0800
    1a87:      	btl	%edx, %esi
    1a8a:      	jae	0x1a92 <generic_retuprobe_filter_arg+0x1a92>
    1a8c:      	testq	%rax, %rax
    1a8f:      	sete	%cl
    1a92:      	movzbl	%cl, %ebx
    1a95:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
    1a9a:      	cmpq	%rdx, (%rbp)
    1a9e:      	ja	0x276 <generic_retuprobe_filter_arg+0x276>
    1aa4:      	jmp	0x1ab0 <generic_retuprobe_filter_arg+0x1ab0>
    1aa6:      	cmpq	%rdx, (%rbp)
    1aaa:      	jb	0x276 <generic_retuprobe_filter_arg+0x276>
    1ab0:      	movl	0x8(%r15), %edx
    1ab4:      	cmpl	$0x11, %edx
    1ab7:      	jb	0x2f69 <generic_retuprobe_filter_arg+0x2f69>
    1abd:      	movq	0x18(%r15), %rsi
    1ac1:      	cmpl	$0x2, %eax
    1ac4:      	jle	0x1ae1 <generic_retuprobe_filter_arg+0x1ae1>
    1ac6:      	leal	-0x3(%rax), %edi
    1ac9:      	cmpl	$0x2, %edi
    1acc:      	jae	0x1b10 <generic_retuprobe_filter_arg+0x1b10>
    1ace:      	cmpq	%rsi, (%rbp)
    1ad2:      	movq	(%rsp), %rdi
    1ad6:      	jne	0x2591 <generic_retuprobe_filter_arg+0x2591>
    1adc:      	jmp	0x2e81 <generic_retuprobe_filter_arg+0x2e81>
    1ae1:      	cmpl	$0x1, %eax
    1ae4:      	je	0x1c76 <generic_retuprobe_filter_arg+0x1c76>
    1aea:      	cmpl	$0x2, %eax
    1aed:      	jne	0x2591 <generic_retuprobe_filter_arg+0x2591>
    1af3:      	cmpl	$0xc, %ecx
    1af6:      	je	0x1b01 <generic_retuprobe_filter_arg+0x1b01>
    1af8:      	cmpl	$0xa, %ecx
    1afb:      	jne	0x2587 <generic_retuprobe_filter_arg+0x2587>
    1b01:      	cmpq	%rsi, (%rbp)
    1b05:      	jl	0x276 <generic_retuprobe_filter_arg+0x276>
    1b0b:      	jmp	0x2591 <generic_retuprobe_filter_arg+0x2591>
    1b10:      	cmpl	$0xc, %eax
    1b13:      	movq	(%rsp), %rdi
    1b17:      	jne	0x2591 <generic_retuprobe_filter_arg+0x2591>
    1b1d:      	testq	%rsi, (%rbp)
    1b21:      	jne	0x276 <generic_retuprobe_filter_arg+0x276>
    1b27:      	jmp	0x2591 <generic_retuprobe_filter_arg+0x2591>
    1b2c:      	cmpl	$0xc, %eax
    1b2f:      	jne	0x1e23 <generic_retuprobe_filter_arg+0x1e23>
    1b35:      	movzbl	(%rbp), %edx
    1b39:      	testl	%edx, %ecx
    1b3b:      	jne	0x276 <generic_retuprobe_filter_arg+0x276>
    1b41:      	jmp	0x1e23 <generic_retuprobe_filter_arg+0x1e23>
    1b46:      	cmpl	$0xc, %eax
    1b49:      	jne	0x1e66 <generic_retuprobe_filter_arg+0x1e66>
    1b4f:      	movzwl	(%rbp), %edx
    1b53:      	testl	%edx, %ecx
    1b55:      	jne	0x276 <generic_retuprobe_filter_arg+0x276>
    1b5b:      	jmp	0x1e66 <generic_retuprobe_filter_arg+0x1e66>
    1b60:      	movl	0x4(%r15), %eax
    1b64:      	andl	$-0x2, %eax
    1b67:      	cmpl	$0x18, %eax
    1b6a:      	jmp	0x1ea0 <generic_retuprobe_filter_arg+0x1ea0>
    1b6f:      	cmpl	$0x101, %eax            # imm = 0x101
    1b74:      	movl	$0x100, %edi            # imm = 0x100
    1b79:      	movl	$0x1fe, %eax            # imm = 0x1FE
    1b7e:      	cmovael	%eax, %edi
    1b81:      	movl	%edi, %eax
    1b83:      	movzwl	%ax, %ecx
    1b86:      	xorl	%eax, %eax
    1b88:      	cmpl	$0x100, %ecx            # imm = 0x100
    1b8e:      	sete	%al
    1b91:      	xorl	$0x7, %eax
    1b94:      	movl	%eax, %ecx
    1b96:      	andl	$0xf, %ecx
    1b99:      	movl	0x10(%r15,%rcx,4), %ecx
    1b9e:      	cmpl	$-0x1, %ecx
    1ba1:      	je	0x2c5b <generic_retuprobe_filter_arg+0x2c5b>
    1ba7:      	movl	%ecx, 0x90(%rsp)
    1bae:      	movq	%rdi, 0x88(%rsp)
    1bb6:      	movl	%eax, 0x60(%rsp)
    1bba:      	movq	%rsi, 0x20(%rsp)
    1bbf:      	movl	$0x1, %eax
    1bc4:      	movq	(%rip), %rdi            # 0x1bcb <generic_retuprobe_filter_arg+0x1bcb>
    1bcb:      	movq	0x30(%rsp), %rbx
    1bd0:      	movq	%rbx, %rsi
    1bd3:      	callq	*%rax
    1bd5:      	movq	%rax, 0x18(%rsp)
    1bda:      	movl	$0x1, %eax
    1bdf:      	movq	(%rip), %rdi            # 0x1be6 <generic_retuprobe_filter_arg+0x1be6>
    1be6:      	movq	%rbx, %rsi
    1be9:      	callq	*%rax
    1beb:      	cmpq	$0x0, 0x18(%rsp)
    1bf1:      	je	0x2c5b <generic_retuprobe_filter_arg+0x2c5b>
    1bf7:      	movl	$0x0, %ebx
    1bfc:      	testq	%rax, %rax
    1bff:      	movq	(%rsp), %rdi
    1c03:      	movq	0x8(%rsp), %r9
    1c08:      	movq	0x10(%rsp), %r11
    1c0d:      	je	0x2c6b <generic_retuprobe_filter_arg+0x2c6b>
    1c13:      	movq	%rax, 0x98(%rsp)
    1c1b:      	movl	0x60(%rsp), %ebx
    1c1f:      	cmpl	$0x5, %ebx
    1c22:      	jg	0x2466 <generic_retuprobe_filter_arg+0x2466>
    1c28:      	movq	0x18(%rsp), %rax
    1c2d:      	movb	%bpl, (%rax)
    1c30:      	leaq	0x1(%rax), %rdi
    1c34:      	movl	$0x4, %eax
    1c39:      	movq	0x20(%rsp), %rdx
    1c3e:      	movl	%ebp, %esi
    1c40:      	callq	*%rax
    1c42:      	movq	0x88(%rsp), %rsi
    1c4a:      	subl	%ebp, %esi
    1c4c:      	jbe	0x24ae <generic_retuprobe_filter_arg+0x24ae>
    1c52:      	movq	0x18(%rsp), %rax
    1c57:      	leaq	(%rax,%rbp), %rdi
    1c5b:      	incq	%rdi
    1c5e:      	andl	$0xfff, %esi            # imm = 0xFFF
    1c64:      	movl	$0x4, %eax
    1c69:      	movq	0x98(%rsp), %rdx
    1c71:      	jmp	0x24ac <generic_retuprobe_filter_arg+0x24ac>
    1c76:      	cmpl	$0xc, %ecx
    1c79:      	je	0x1c84 <generic_retuprobe_filter_arg+0x1c84>
    1c7b:      	cmpl	$0xa, %ecx
    1c7e:      	jne	0x257b <generic_retuprobe_filter_arg+0x257b>
    1c84:      	cmpq	%rsi, (%rbp)
    1c88:      	jg	0x276 <generic_retuprobe_filter_arg+0x276>
    1c8e:      	jmp	0x2591 <generic_retuprobe_filter_arg+0x2591>
    1c93:      	movl	0x8(%r15), %edx
    1c97:      	movzbl	(%rbp), %ecx
    1c9b:      	jmp	0x1ca5 <generic_retuprobe_filter_arg+0x1ca5>
    1c9d:      	movl	0x8(%r15), %edx
    1ca1:      	movzwl	(%rbp), %ecx
    1ca5:      	cmpl	%ecx, 0x10(%r15)
    1ca9:      	setbe	%sil
    1cad:      	cmpl	%ecx, 0x14(%r15)
    1cb1:      	setae	%al
    1cb4:      	andb	%sil, %al
    1cb7:      	cmpl	$0x11, %edx
    1cba:      	jb	0x2af3 <generic_retuprobe_filter_arg+0x2af3>
    1cc0:      	cmpl	%ecx, 0x18(%r15)
    1cc4:      	setbe	%sil
    1cc8:      	cmpl	%ecx, 0x1c(%r15)
    1ccc:      	setae	%dil
    1cd0:      	andb	%sil, %dil
    1cd3:      	orb	%dil, %al
    1cd6:      	cmpl	$0x19, %edx
    1cd9:      	jb	0x2aef <generic_retuprobe_filter_arg+0x2aef>
    1cdf:      	cmpl	%ecx, 0x20(%r15)
    1ce3:      	setbe	%sil
    1ce7:      	cmpl	%ecx, 0x24(%r15)
    1ceb:      	setae	%dil
    1cef:      	andb	%sil, %dil
    1cf2:      	orb	%dil, %al
    1cf5:      	cmpl	$0x21, %edx
    1cf8:      	jb	0x2aef <generic_retuprobe_filter_arg+0x2aef>
    1cfe:      	cmpl	%ecx, 0x28(%r15)
    1d02:      	setbe	%dl
    1d05:      	cmpl	%ecx, 0x2c(%r15)
    1d09:      	setae	%cl
    1d0c:      	andb	%dl, %cl
    1d0e:      	orb	%cl, %al
    1d10:      	jmp	0x2aef <generic_retuprobe_filter_arg+0x2aef>
    1d15:      	xorl	%ebx, %ebx
    1d17:      	xorl	%r12d, %r12d
    1d1a:      	movl	0x10(%r15,%rbx,4), %eax
    1d1f:      	movl	%eax, 0x38(%rsp)
    1d23:      	movl	$0x1, %eax
    1d28:      	leaq	0x38(%rsp), %rsi
    1d2d:      	movq	(%rip), %rdi            # 0x1d34 <generic_retuprobe_filter_arg+0x1d34>
    1d34:      	callq	*%rax
    1d36:      	testq	%rax, %rax
    1d39:      	je	0x2683 <generic_retuprobe_filter_arg+0x2683>
    1d3f:      	testl	%ebp, %ebp
    1d41:      	movq	0x8(%rsp), %r9
    1d46:      	movq	0x10(%rsp), %r11
    1d4b:      	je	0x1d9f <generic_retuprobe_filter_arg+0x1d9f>
    1d4d:      	movq	0x20(%rsp), %rdx
    1d52:      	xorl	%ecx, %ecx
    1d54:      	jmp	0x1d61 <generic_retuprobe_filter_arg+0x1d61>
    1d56:      	incq	%rcx
    1d59:      	incq	%rdx
    1d5c:      	cmpq	%rbp, %rcx
    1d5f:      	je	0x1d9f <generic_retuprobe_filter_arg+0x1d9f>
    1d61:      	xorl	%esi, %esi
    1d63:      	nopw	%cs:(%rax,%rax)
    1d70:      	leaq	(%rcx,%rsi), %rdi
    1d74:      	cmpq	%rbp, %rdi
    1d77:      	jae	0x1d56 <generic_retuprobe_filter_arg+0x1d56>
    1d79:      	movzbl	(%rax,%rsi), %edi
    1d7d:      	testb	%dil, %dil
    1d80:      	je	0x1d97 <generic_retuprobe_filter_arg+0x1d97>
    1d82:      	cmpq	$0x62, %rsi
    1d86:      	ja	0x1d56 <generic_retuprobe_filter_arg+0x1d56>
    1d88:      	leaq	0x1(%rsi), %r8
    1d8c:      	cmpb	%dil, (%rdx,%rsi)
    1d90:      	movq	%r8, %rsi
    1d93:      	je	0x1d70 <generic_retuprobe_filter_arg+0x1d70>
    1d95:      	jmp	0x1d56 <generic_retuprobe_filter_arg+0x1d56>
    1d97:      	testl	%ecx, %ecx
    1d99:      	jns	0x297d <generic_retuprobe_filter_arg+0x297d>
    1d9f:      	leal	0xc(%r12), %eax
    1da4:      	cmpl	0x8(%r15), %eax
    1da8:      	jae	0x1dbb <generic_retuprobe_filter_arg+0x1dbb>
    1daa:      	addl	$0x4, %r12d
    1dae:      	incq	%rbx
    1db1:      	cmpq	$0x64, %rbx
    1db5:      	jne	0x1d1a <generic_retuprobe_filter_arg+0x1d1a>
    1dbb:      	xorl	%ebx, %ebx
    1dbd:      	movq	(%rsp), %rdi
    1dc1:      	jmp	0x2ef2 <generic_retuprobe_filter_arg+0x2ef2>
    1dc6:      	movzwl	%bp, %eax
    1dc9:      	cmpl	$0x90, %eax
    1dce:      	ja	0x223c <generic_retuprobe_filter_arg+0x223c>
    1dd4:      	testw	%bp, %bp
    1dd7:      	je	0x1de9 <generic_retuprobe_filter_arg+0x1de9>
    1dd9:      	movl	%ebp, %eax
    1ddb:      	movl	$0x18, %ecx
    1de0:      	cltd
    1de1:      	idivl	%ecx
    1de3:      	movl	%ebp, %edi
    1de5:      	testl	%edx, %edx
    1de7:      	je	0x1e0b <generic_retuprobe_filter_arg+0x1e0b>
    1de9:      	movl	%ebp, %eax
    1deb:      	movl	$0x18, %ecx
    1df0:      	cltd
    1df1:      	idivl	%ecx
    1df3:      	shll	$0x3, %eax
    1df6:      	leal	(%rax,%rax,2), %eax
    1df9:      	addl	$0x18, %eax
    1dfc:      	movzwl	%ax, %edi
    1dff:      	cmpl	$0x90, %edi
    1e05:      	ja	0x2250 <generic_retuprobe_filter_arg+0x2250>
    1e0b:      	movl	%edi, %eax
    1e0d:      	cltd
    1e0e:      	idivl	%ecx
    1e10:      	decl	%eax
    1e12:      	jmp	0x2261 <generic_retuprobe_filter_arg+0x2261>
    1e17:      	movzbl	(%rbp), %edx
    1e1b:      	cmpl	%edx, %ecx
    1e1d:      	jb	0x276 <generic_retuprobe_filter_arg+0x276>
    1e23:      	movl	0x8(%r15), %ecx
    1e27:      	cmpl	$0xd, %ecx
    1e2a:      	jb	0x2f69 <generic_retuprobe_filter_arg+0x2f69>
    1e30:      	movl	0x14(%r15), %edx
    1e34:      	cmpl	$0x2, %eax
    1e37:      	jle	0x2126 <generic_retuprobe_filter_arg+0x2126>
    1e3d:      	leal	-0x3(%rax), %esi
    1e40:      	cmpl	$0x2, %esi
    1e43:      	jae	0x2609 <generic_retuprobe_filter_arg+0x2609>
    1e49:      	movzbl	(%rbp), %esi
    1e4d:      	cmpl	%esi, %edx
    1e4f:      	jne	0x26fe <generic_retuprobe_filter_arg+0x26fe>
    1e55:      	jmp	0x2e81 <generic_retuprobe_filter_arg+0x2e81>
    1e5a:      	movzwl	(%rbp), %edx
    1e5e:      	cmpl	%edx, %ecx
    1e60:      	jb	0x276 <generic_retuprobe_filter_arg+0x276>
    1e66:      	movl	0x8(%r15), %ecx
    1e6a:      	cmpl	$0xd, %ecx
    1e6d:      	jb	0x2f69 <generic_retuprobe_filter_arg+0x2f69>
    1e73:      	movl	0x14(%r15), %edx
    1e77:      	cmpl	$0x2, %eax
    1e7a:      	jle	0x2149 <generic_retuprobe_filter_arg+0x2149>
    1e80:      	leal	-0x3(%rax), %esi
    1e83:      	cmpl	$0x2, %esi
    1e86:      	jae	0x2623 <generic_retuprobe_filter_arg+0x2623>
    1e8c:      	movzwl	(%rbp), %esi
    1e90:      	cmpl	%esi, %edx
    1e92:      	jne	0x273d <generic_retuprobe_filter_arg+0x273d>
    1e98:      	jmp	0x2e81 <generic_retuprobe_filter_arg+0x2e81>
    1e9d:      	testq	%rax, %rax
    1ea0:      	sete	%al
    1ea3:      	movq	(%rsp), %rdi
    1ea7:      	movq	0x8(%rsp), %r9
    1eac:      	movq	0x10(%rsp), %r11
    1eb1:      	movzbl	%al, %ebx
    1eb4:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
    1eb9:      	movl	(%rbp), %eax
    1ebc:      	cmpl	%eax, %esi
    1ebe:      	ja	0x1ec8 <generic_retuprobe_filter_arg+0x1ec8>
    1ec0:      	cmpl	%edx, %eax
    1ec2:      	jbe	0x276 <generic_retuprobe_filter_arg+0x276>
    1ec8:      	movl	0x8(%r15), %edx
    1ecc:      	cmpl	$0x11, %edx
    1ecf:      	jb	0xb8 <generic_retuprobe_filter_arg+0xb8>
    1ed5:      	movl	0x18(%r15), %edi
    1ed9:      	movl	0x1c(%r15), %esi
    1edd:      	cmpl	$0xc, %ecx
    1ee0:      	ja	0x2384 <generic_retuprobe_filter_arg+0x2384>
    1ee6:      	movl	$0x1402, %r8d           # imm = 0x1402
    1eec:      	btl	%ecx, %r8d
    1ef0:      	jae	0x2384 <generic_retuprobe_filter_arg+0x2384>
    1ef6:      	cmpl	%eax, %edi
    1ef8:      	movq	(%rsp), %rdi
    1efc:      	jg	0x2394 <generic_retuprobe_filter_arg+0x2394>
    1f02:      	cmpl	%esi, %eax
    1f04:      	jle	0x276 <generic_retuprobe_filter_arg+0x276>
    1f0a:      	jmp	0x2394 <generic_retuprobe_filter_arg+0x2394>
    1f0f:      	movl	(%rbp), %edx
    1f12:      	cmpl	%edx, %esi
    1f14:      	setbe	%sil
    1f18:      	cmpl	%eax, %edx
    1f1a:      	setbe	%al
    1f1d:      	andb	%sil, %al
    1f20:      	movl	0x8(%r15), %esi
    1f24:      	cmpl	$0x11, %esi
    1f27:      	jb	0x2af3 <generic_retuprobe_filter_arg+0x2af3>
    1f2d:      	movl	0x18(%r15), %r8d
    1f31:      	movl	0x1c(%r15), %edi
    1f35:      	cmpl	$0xc, %ecx
    1f38:      	ja	0x2335 <generic_retuprobe_filter_arg+0x2335>
    1f3e:      	movl	$0x1402, %r10d          # imm = 0x1402
    1f44:      	btl	%ecx, %r10d
    1f48:      	jae	0x2335 <generic_retuprobe_filter_arg+0x2335>
    1f4e:      	cmpl	%edx, %r8d
    1f51:      	setle	%r8b
    1f55:      	cmpl	%edi, %edx
    1f57:      	setle	%dil
    1f5b:      	jmp	0x2342 <generic_retuprobe_filter_arg+0x2342>
    1f60:      	cmpq	%rdx, %r8
    1f63:      	setbe	%r8b
    1f67:      	cmpq	%rdi, %rdx
    1f6a:      	setbe	%dil
    1f6e:      	andb	%r8b, %dil
    1f71:      	orb	%dil, %al
    1f74:      	cmpl	$0x29, %esi
    1f77:      	jb	0x2aef <generic_retuprobe_filter_arg+0x2aef>
    1f7d:      	movq	0x30(%r15), %r8
    1f81:      	movq	0x38(%r15), %rdi
    1f85:      	cmpl	$0xc, %ecx
    1f88:      	je	0x1f93 <generic_retuprobe_filter_arg+0x1f93>
    1f8a:      	cmpl	$0xa, %ecx
    1f8d:      	jne	0x241e <generic_retuprobe_filter_arg+0x241e>
    1f93:      	cmpq	%rdx, %r8
    1f96:      	setle	%r8b
    1f9a:      	cmpq	%rdi, %rdx
    1f9d:      	setle	%dil
    1fa1:      	jmp	0x242c <generic_retuprobe_filter_arg+0x242c>
    1fa6:      	cmpq	%rax, %rdi
    1fa9:      	movq	(%rsp), %rdi
    1fad:      	ja	0x1fb8 <generic_retuprobe_filter_arg+0x1fb8>
    1faf:      	cmpq	%rsi, %rax
    1fb2:      	jbe	0x276 <generic_retuprobe_filter_arg+0x276>
    1fb8:      	cmpl	$0x29, %edx
    1fbb:      	jb	0xb8 <generic_retuprobe_filter_arg+0xb8>
    1fc1:      	movq	0x30(%r15), %rdi
    1fc5:      	movq	0x38(%r15), %rsi
    1fc9:      	cmpl	$0xc, %ecx
    1fcc:      	je	0x1fd7 <generic_retuprobe_filter_arg+0x1fd7>
    1fce:      	cmpl	$0xa, %ecx
    1fd1:      	jne	0x2533 <generic_retuprobe_filter_arg+0x2533>
    1fd7:      	cmpq	%rax, %rdi
    1fda:      	movq	(%rsp), %rdi
    1fde:      	jg	0x2545 <generic_retuprobe_filter_arg+0x2545>
    1fe4:      	cmpq	%rsi, %rax
    1fe7:      	jle	0x276 <generic_retuprobe_filter_arg+0x276>
    1fed:      	jmp	0x2545 <generic_retuprobe_filter_arg+0x2545>
    1ff2:      	xorl	%ebx, %ebx
    1ff4:      	cmpl	$0x29, %ecx
    1ff7:      	jne	0x2002 <generic_retuprobe_filter_arg+0x2002>
    1ff9:      	testq	%rdx, %rdx
    1ffc:      	je	0x2002 <generic_retuprobe_filter_arg+0x2002>
    1ffe:      	movzbl	0x3a(%rdx), %ebx
    2002:      	cmpl	$0x29, %ecx
    2005:      	je	0x2010 <generic_retuprobe_filter_arg+0x2010>
    2007:      	cmpl	$0x7, %ecx
    200a:      	jne	0x245f <generic_retuprobe_filter_arg+0x245f>
    2010:      	movzbl	0x10(%r15), %eax
    2015:      	movl	%eax, 0x2c(%rsp)
    2019:      	movl	$0x1, %eax
    201e:      	movq	(%rip), %rdi            # 0x2025 <generic_retuprobe_filter_arg+0x2025>
    2025:      	leaq	0x2c(%rsp), %rsi
    202a:      	callq	*%rax
    202c:      	testq	%rax, %rax
    202f:      	je	0x250 <generic_retuprobe_filter_arg+0x250>
    2035:      	movq	%rax, %rdi
    2038:      	movl	%ebx, %eax
    203a:      	movq	%rax, 0x70(%rsp)
    203f:      	movl	$0x1, %eax
    2044:      	movq	0x30(%rsp), %rsi
    2049:      	jmp	0x1a51 <generic_retuprobe_filter_arg+0x1a51>
    204e:      	cmpl	%edx, (%rbp)
    2051:      	ja	0x276 <generic_retuprobe_filter_arg+0x276>
    2057:      	jmp	0x2062 <generic_retuprobe_filter_arg+0x2062>
    2059:      	cmpl	%edx, (%rbp)
    205c:      	jb	0x276 <generic_retuprobe_filter_arg+0x276>
    2062:      	movl	0x8(%r15), %edx
    2066:      	cmpl	$0xd, %edx
    2069:      	jb	0x2f69 <generic_retuprobe_filter_arg+0x2f69>
    206f:      	movl	0x14(%r15), %esi
    2073:      	cmpl	$0x2, %eax
    2076:      	jle	0x2092 <generic_retuprobe_filter_arg+0x2092>
    2078:      	leal	-0x3(%rax), %edi
    207b:      	cmpl	$0x2, %edi
    207e:      	jae	0x20c7 <generic_retuprobe_filter_arg+0x20c7>
    2080:      	cmpl	%esi, (%rbp)
    2083:      	movq	(%rsp), %rdi
    2087:      	jne	0x281f <generic_retuprobe_filter_arg+0x281f>
    208d:      	jmp	0x2e81 <generic_retuprobe_filter_arg+0x2e81>
    2092:      	cmpl	$0x1, %eax
    2095:      	je	0x20e2 <generic_retuprobe_filter_arg+0x20e2>
    2097:      	cmpl	$0x2, %eax
    209a:      	jne	0x281f <generic_retuprobe_filter_arg+0x281f>
    20a0:      	cmpl	$0xc, %ecx
    20a3:      	ja	0x2816 <generic_retuprobe_filter_arg+0x2816>
    20a9:      	movl	$0x1402, %r8d           # imm = 0x1402
    20af:      	btl	%ecx, %r8d
    20b3:      	jae	0x2816 <generic_retuprobe_filter_arg+0x2816>
    20b9:      	cmpl	%esi, (%rbp)
    20bc:      	jl	0x276 <generic_retuprobe_filter_arg+0x276>
    20c2:      	jmp	0x281f <generic_retuprobe_filter_arg+0x281f>
    20c7:      	cmpl	$0xc, %eax
    20ca:      	movq	(%rsp), %rdi
    20ce:      	jne	0x281f <generic_retuprobe_filter_arg+0x281f>
    20d4:      	testl	%esi, (%rbp)
    20d7:      	jne	0x276 <generic_retuprobe_filter_arg+0x276>
    20dd:      	jmp	0x281f <generic_retuprobe_filter_arg+0x281f>
    20e2:      	cmpl	$0xc, %ecx
    20e5:      	ja	0x280b <generic_retuprobe_filter_arg+0x280b>
    20eb:      	movl	$0x1402, %r8d           # imm = 0x1402
    20f1:      	btl	%ecx, %r8d
    20f5:      	jae	0x280b <generic_retuprobe_filter_arg+0x280b>
    20fb:      	cmpl	%esi, (%rbp)
    20fe:      	jg	0x276 <generic_retuprobe_filter_arg+0x276>
    2104:      	jmp	0x281f <generic_retuprobe_filter_arg+0x281f>
    2109:      	xorl	%ebx, %ebx
    210b:      	movq	0x8(%rsp), %r9
    2110:      	movq	0x10(%rsp), %r11
    2115:      	jmp	0x23dc <generic_retuprobe_filter_arg+0x23dc>
    211a:      	xorl	%ebx, %ebx
    211c:      	movq	0x10(%rsp), %r11
    2121:      	jmp	0x23fd <generic_retuprobe_filter_arg+0x23fd>
    2126:      	cmpl	$0x1, %eax
    2129:      	je	0x26f2 <generic_retuprobe_filter_arg+0x26f2>
    212f:      	cmpl	$0x2, %eax
    2132:      	jne	0x26fe <generic_retuprobe_filter_arg+0x26fe>
    2138:      	movzbl	(%rbp), %esi
    213c:      	cmpl	%esi, %edx
    213e:      	ja	0x276 <generic_retuprobe_filter_arg+0x276>
    2144:      	jmp	0x26fe <generic_retuprobe_filter_arg+0x26fe>
    2149:      	cmpl	$0x1, %eax
    214c:      	je	0x2731 <generic_retuprobe_filter_arg+0x2731>
    2152:      	cmpl	$0x2, %eax
    2155:      	jne	0x273d <generic_retuprobe_filter_arg+0x273d>
    215b:      	movzwl	(%rbp), %esi
    215f:      	cmpl	%esi, %edx
    2161:      	ja	0x276 <generic_retuprobe_filter_arg+0x276>
    2167:      	jmp	0x273d <generic_retuprobe_filter_arg+0x273d>
    216c:      	movq	0x18(%rsp), %rax
    2171:      	movw	%bp, (%rax)
    2174:      	leaq	0x2(%rax), %rdi
    2178:      	movl	$0x4, %eax
    217d:      	movl	%ebp, %esi
    217f:      	callq	*%rax
    2181:      	movq	0x88(%rsp), %rsi
    2189:      	subl	%ebp, %esi
    218b:      	jbe	0x21af <generic_retuprobe_filter_arg+0x21af>
    218d:      	movq	0x18(%rsp), %rax
    2192:      	leaq	(%rax,%rbp), %rdi
    2196:      	addq	$0x2, %rdi
    219a:      	andl	$0xfff, %esi            # imm = 0xFFF
    21a0:      	movl	$0x4, %eax
    21a5:      	movq	0x98(%rsp), %rdx
    21ad:      	callq	*%rax
    21af:      	movl	0x90(%rsp), %eax
    21b6:      	movl	%eax, 0x38(%rsp)
    21ba:      	cmpl	$0x3, %ebx
    21bd:      	jg	0x21fd <generic_retuprobe_filter_arg+0x21fd>
    21bf:      	cmpl	$0x1, %ebx
    21c2:      	movq	(%rsp), %rdi
    21c6:      	movq	0x8(%rsp), %r9
    21cb:      	movq	0x10(%rsp), %r11
    21d0:      	jg	0x2698 <generic_retuprobe_filter_arg+0x2698>
    21d6:      	testl	%ebx, %ebx
    21d8:      	je	0x2a3c <generic_retuprobe_filter_arg+0x2a3c>
    21de:      	cmpl	$0x1, %ebx
    21e1:      	jne	0x845 <generic_retuprobe_filter_arg+0x845>
    21e7:      	movl	$0x1, %eax
    21ec:      	leaq	0x38(%rsp), %rsi
    21f1:      	movq	(%rip), %rdi            # 0x21f8 <generic_retuprobe_filter_arg+0x21f8>
    21f8:      	jmp	0x2a86 <generic_retuprobe_filter_arg+0x2a86>
    21fd:      	cmpl	$0x5, %ebx
    2200:      	movq	(%rsp), %rdi
    2204:      	movq	0x8(%rsp), %r9
    2209:      	movq	0x10(%rsp), %r11
    220e:      	jg	0x26c0 <generic_retuprobe_filter_arg+0x26c0>
    2214:      	cmpl	$0x4, %ebx
    2217:      	je	0x2a4f <generic_retuprobe_filter_arg+0x2a4f>
    221d:      	cmpl	$0x5, %ebx
    2220:      	jne	0x845 <generic_retuprobe_filter_arg+0x845>
    2226:      	movl	$0x1, %eax
    222b:      	leaq	0x38(%rsp), %rsi
    2230:      	movq	(%rip), %rdi            # 0x2237 <generic_retuprobe_filter_arg+0x2237>
    2237:      	jmp	0x2a86 <generic_retuprobe_filter_arg+0x2a86>
    223c:      	cmpl	$0x101, %eax            # imm = 0x101
    2241:      	movl	$0x100, %edi            # imm = 0x100
    2246:      	movl	$0x1fe, %eax            # imm = 0x1FE
    224b:      	cmovael	%eax, %edi
    224e:      	movl	%edi, %eax
    2250:      	movzwl	%ax, %ecx
    2253:      	xorl	%eax, %eax
    2255:      	cmpl	$0x100, %ecx            # imm = 0x100
    225b:      	sete	%al
    225e:      	xorl	$0x7, %eax
    2261:      	movl	%eax, %ecx
    2263:      	andl	$0xf, %ecx
    2266:      	movl	0x10(%r15,%rcx,4), %ecx
    226b:      	cmpl	$-0x1, %ecx
    226e:      	je	0x2ee2 <generic_retuprobe_filter_arg+0x2ee2>
    2274:      	movl	%ecx, 0x88(%rsp)
    227b:      	movq	%rdi, 0x90(%rsp)
    2283:      	movl	%eax, 0x18(%rsp)
    2287:      	movq	%rsi, 0x20(%rsp)
    228c:      	movl	$0x1, %eax
    2291:      	movq	(%rip), %rdi            # 0x2298 <generic_retuprobe_filter_arg+0x2298>
    2298:      	movq	0x30(%rsp), %rbx
    229d:      	movq	%rbx, %rsi
    22a0:      	callq	*%rax
    22a2:      	movq	%rax, 0x60(%rsp)
    22a7:      	movl	$0x1, %eax
    22ac:      	movq	(%rip), %rdi            # 0x22b3 <generic_retuprobe_filter_arg+0x22b3>
    22b3:      	movq	%rbx, %rsi
    22b6:      	callq	*%rax
    22b8:      	movq	0x60(%rsp), %rdx
    22bd:      	testq	%rdx, %rdx
    22c0:      	je	0x2ee2 <generic_retuprobe_filter_arg+0x2ee2>
    22c6:      	movl	$0x0, %ebx
    22cb:      	testq	%rax, %rax
    22ce:      	movq	(%rsp), %rdi
    22d2:      	movq	0x8(%rsp), %r9
    22d7:      	movq	0x10(%rsp), %r11
    22dc:      	je	0x2ef2 <generic_retuprobe_filter_arg+0x2ef2>
    22e2:      	movq	%rdx, %rcx
    22e5:      	movq	%rax, %r12
    22e8:      	cmpl	$0x5, 0x18(%rsp)
    22ed:      	jg	0x298b <generic_retuprobe_filter_arg+0x298b>
    22f3:      	movq	%rcx, %rbx
    22f6:      	movb	%bpl, (%rcx)
    22f9:      	leaq	0x1(%rcx), %rdi
    22fd:      	movl	$0x4, %eax
    2302:      	movq	0x20(%rsp), %rdx
    2307:      	movl	%ebp, %esi
    2309:      	callq	*%rax
    230b:      	movq	0x90(%rsp), %rsi
    2313:      	subl	%ebp, %esi
    2315:      	jbe	0x29c7 <generic_retuprobe_filter_arg+0x29c7>
    231b:      	leaq	(%rbx,%rbp), %rdi
    231f:      	incq	%rdi
    2322:      	andl	$0xfff, %esi            # imm = 0xFFF
    2328:      	movl	$0x4, %eax
    232d:      	movq	%r12, %rdx
    2330:      	jmp	0x29c5 <generic_retuprobe_filter_arg+0x29c5>
    2335:      	cmpl	%edx, %r8d
    2338:      	setbe	%r8b
    233c:      	cmpl	%edi, %edx
    233e:      	setbe	%dil
    2342:      	andb	%r8b, %dil
    2345:      	orb	%dil, %al
    2348:      	cmpl	$0x19, %esi
    234b:      	jb	0x2aef <generic_retuprobe_filter_arg+0x2aef>
    2351:      	movl	0x20(%r15), %r8d
    2355:      	movl	0x24(%r15), %edi
    2359:      	cmpl	$0xc, %ecx
    235c:      	ja	0x2770 <generic_retuprobe_filter_arg+0x2770>
    2362:      	movl	$0x1402, %r10d          # imm = 0x1402
    2368:      	btl	%ecx, %r10d
    236c:      	jae	0x2770 <generic_retuprobe_filter_arg+0x2770>
    2372:      	cmpl	%edx, %r8d
    2375:      	setle	%r8b
    2379:      	cmpl	%edi, %edx
    237b:      	setle	%dil
    237f:      	jmp	0x277d <generic_retuprobe_filter_arg+0x277d>
    2384:      	cmpl	%eax, %edi
    2386:      	movq	(%rsp), %rdi
    238a:      	ja	0x2394 <generic_retuprobe_filter_arg+0x2394>
    238c:      	cmpl	%esi, %eax
    238e:      	jbe	0x276 <generic_retuprobe_filter_arg+0x276>
    2394:      	cmpl	$0x19, %edx
    2397:      	jb	0xb8 <generic_retuprobe_filter_arg+0xb8>
    239d:      	movl	0x20(%r15), %edi
    23a1:      	movl	0x24(%r15), %esi
    23a5:      	cmpl	$0xc, %ecx
    23a8:      	ja	0x27bc <generic_retuprobe_filter_arg+0x27bc>
    23ae:      	movl	$0x1402, %r8d           # imm = 0x1402
    23b4:      	btl	%ecx, %r8d
    23b8:      	jae	0x27bc <generic_retuprobe_filter_arg+0x27bc>
    23be:      	cmpl	%eax, %edi
    23c0:      	movq	(%rsp), %rdi
    23c4:      	jg	0x27cc <generic_retuprobe_filter_arg+0x27cc>
    23ca:      	cmpl	%esi, %eax
    23cc:      	jle	0x276 <generic_retuprobe_filter_arg+0x276>
    23d2:      	jmp	0x27cc <generic_retuprobe_filter_arg+0x27cc>
    23d7:      	movl	$0x1, %ebx
    23dc:      	movq	0x68(%rsp), %r12
    23e1:      	movq	(%rsp), %rdi
    23e5:      	movl	0x4(%r15), %eax
    23e9:      	cmpq	$0x25, %rax
    23ed:      	jbe	0x2c79 <generic_retuprobe_filter_arg+0x2c79>
    23f3:      	jmp	0x265 <generic_retuprobe_filter_arg+0x265>
    23f8:      	movl	$0x1, %ebx
    23fd:      	movq	0x68(%rsp), %r12
    2402:      	movq	(%rsp), %rdi
    2406:      	movq	0x8(%rsp), %r9
    240b:      	movl	0x4(%r15), %eax
    240f:      	cmpq	$0x25, %rax
    2413:      	jbe	0x2c79 <generic_retuprobe_filter_arg+0x2c79>
    2419:      	jmp	0x265 <generic_retuprobe_filter_arg+0x265>
    241e:      	cmpq	%rdx, %r8
    2421:      	setbe	%r8b
    2425:      	cmpq	%rdi, %rdx
    2428:      	setbe	%dil
    242c:      	andb	%r8b, %dil
    242f:      	orb	%dil, %al
    2432:      	cmpl	$0x39, %esi
    2435:      	jb	0x2aef <generic_retuprobe_filter_arg+0x2aef>
    243b:      	movq	0x40(%r15), %rdi
    243f:      	movq	0x48(%r15), %rsi
    2443:      	cmpl	$0xc, %ecx
    2446:      	je	0x2451 <generic_retuprobe_filter_arg+0x2451>
    2448:      	cmpl	$0xa, %ecx
    244b:      	jne	0x28c2 <generic_retuprobe_filter_arg+0x28c2>
    2451:      	cmpq	%rdx, %rdi
    2454:      	setle	%cl
    2457:      	cmpq	%rsi, %rdx
    245a:      	jmp	0x27b4 <generic_retuprobe_filter_arg+0x27b4>
    245f:      	xorl	%ebx, %ebx
    2461:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
    2466:      	movq	0x18(%rsp), %rax
    246b:      	movw	%bp, (%rax)
    246e:      	leaq	0x2(%rax), %rdi
    2472:      	movl	$0x4, %eax
    2477:      	movq	0x20(%rsp), %rdx
    247c:      	movl	%ebp, %esi
    247e:      	callq	*%rax
    2480:      	movq	0x88(%rsp), %rsi
    2488:      	subl	%ebp, %esi
    248a:      	jbe	0x24ae <generic_retuprobe_filter_arg+0x24ae>
    248c:      	movq	0x18(%rsp), %rax
    2491:      	leaq	(%rax,%rbp), %rdi
    2495:      	addq	$0x2, %rdi
    2499:      	andl	$0xfff, %esi            # imm = 0xFFF
    249f:      	movl	$0x4, %eax
    24a4:      	movq	0x98(%rsp), %rdx
    24ac:      	callq	*%rax
    24ae:      	movl	0x90(%rsp), %eax
    24b5:      	movl	%eax, 0x38(%rsp)
    24b9:      	cmpl	$0x3, %ebx
    24bc:      	jg	0x24f8 <generic_retuprobe_filter_arg+0x24f8>
    24be:      	cmpl	$0x1, %ebx
    24c1:      	movq	0x8(%rsp), %r9
    24c6:      	movq	0x10(%rsp), %r11
    24cb:      	jg	0x28d0 <generic_retuprobe_filter_arg+0x28d0>
    24d1:      	testl	%ebx, %ebx
    24d3:      	je	0x2bf1 <generic_retuprobe_filter_arg+0x2bf1>
    24d9:      	cmpl	$0x1, %ebx
    24dc:      	jne	0x2c92 <generic_retuprobe_filter_arg+0x2c92>
    24e2:      	movl	$0x1, %eax
    24e7:      	leaq	0x38(%rsp), %rsi
    24ec:      	movq	(%rip), %rdi            # 0x24f3 <generic_retuprobe_filter_arg+0x24f3>
    24f3:      	jmp	0x2c3b <generic_retuprobe_filter_arg+0x2c3b>
    24f8:      	cmpl	$0x5, %ebx
    24fb:      	movq	0x8(%rsp), %r9
    2500:      	movq	0x10(%rsp), %r11
    2505:      	jg	0x28f8 <generic_retuprobe_filter_arg+0x28f8>
    250b:      	cmpl	$0x4, %ebx
    250e:      	je	0x2c04 <generic_retuprobe_filter_arg+0x2c04>
    2514:      	cmpl	$0x5, %ebx
    2517:      	jne	0x2c92 <generic_retuprobe_filter_arg+0x2c92>
    251d:      	movl	$0x1, %eax
    2522:      	leaq	0x38(%rsp), %rsi
    2527:      	movq	(%rip), %rdi            # 0x252e <generic_retuprobe_filter_arg+0x252e>
    252e:      	jmp	0x2c3b <generic_retuprobe_filter_arg+0x2c3b>
    2533:      	cmpq	%rax, %rdi
    2536:      	movq	(%rsp), %rdi
    253a:      	ja	0x2545 <generic_retuprobe_filter_arg+0x2545>
    253c:      	cmpq	%rsi, %rax
    253f:      	jbe	0x276 <generic_retuprobe_filter_arg+0x276>
    2545:      	cmpl	$0x39, %edx
    2548:      	jb	0xb8 <generic_retuprobe_filter_arg+0xb8>
    254e:      	movq	0x40(%r15), %rsi
    2552:      	movq	0x48(%r15), %rdx
    2556:      	cmpl	$0xc, %ecx
    2559:      	je	0x2564 <generic_retuprobe_filter_arg+0x2564>
    255b:      	cmpl	$0xa, %ecx
    255e:      	jne	0x2920 <generic_retuprobe_filter_arg+0x2920>
    2564:      	cmpq	%rax, %rsi
    2567:      	jg	0xb8 <generic_retuprobe_filter_arg+0xb8>
    256d:      	cmpq	%rdx, %rax
    2570:      	jle	0x276 <generic_retuprobe_filter_arg+0x276>
    2576:      	jmp	0xb8 <generic_retuprobe_filter_arg+0xb8>
    257b:      	cmpq	%rsi, (%rbp)
    257f:      	ja	0x276 <generic_retuprobe_filter_arg+0x276>
    2585:      	jmp	0x2591 <generic_retuprobe_filter_arg+0x2591>
    2587:      	cmpq	%rsi, (%rbp)
    258b:      	jb	0x276 <generic_retuprobe_filter_arg+0x276>
    2591:      	cmpl	$0x19, %edx
    2594:      	jb	0x2f69 <generic_retuprobe_filter_arg+0x2f69>
    259a:      	movq	0x20(%r15), %rsi
    259e:      	cmpl	$0x2, %eax
    25a1:      	jle	0x25be <generic_retuprobe_filter_arg+0x25be>
    25a3:      	leal	-0x3(%rax), %edi
    25a6:      	cmpl	$0x2, %edi
    25a9:      	jae	0x25ed <generic_retuprobe_filter_arg+0x25ed>
    25ab:      	cmpq	%rsi, (%rbp)
    25af:      	movq	(%rsp), %rdi
    25b3:      	jne	0x2b16 <generic_retuprobe_filter_arg+0x2b16>
    25b9:      	jmp	0x2e81 <generic_retuprobe_filter_arg+0x2e81>
    25be:      	cmpl	$0x1, %eax
    25c1:      	je	0x2666 <generic_retuprobe_filter_arg+0x2666>
    25c7:      	cmpl	$0x2, %eax
    25ca:      	jne	0x2b16 <generic_retuprobe_filter_arg+0x2b16>
    25d0:      	cmpl	$0xc, %ecx
    25d3:      	je	0x25de <generic_retuprobe_filter_arg+0x25de>
    25d5:      	cmpl	$0xa, %ecx
    25d8:      	jne	0x2b0c <generic_retuprobe_filter_arg+0x2b0c>
    25de:      	cmpq	%rsi, (%rbp)
    25e2:      	jl	0x276 <generic_retuprobe_filter_arg+0x276>
    25e8:      	jmp	0x2b16 <generic_retuprobe_filter_arg+0x2b16>
    25ed:      	cmpl	$0xc, %eax
    25f0:      	movq	(%rsp), %rdi
    25f4:      	jne	0x2b16 <generic_retuprobe_filter_arg+0x2b16>
    25fa:      	testq	%rsi, (%rbp)
    25fe:      	jne	0x276 <generic_retuprobe_filter_arg+0x276>
    2604:      	jmp	0x2b16 <generic_retuprobe_filter_arg+0x2b16>
    2609:      	cmpl	$0xc, %eax
    260c:      	jne	0x26fe <generic_retuprobe_filter_arg+0x26fe>
    2612:      	movzbl	(%rbp), %esi
    2616:      	testl	%esi, %edx
    2618:      	jne	0x276 <generic_retuprobe_filter_arg+0x276>
    261e:      	jmp	0x26fe <generic_retuprobe_filter_arg+0x26fe>
    2623:      	cmpl	$0xc, %eax
    2626:      	jne	0x273d <generic_retuprobe_filter_arg+0x273d>
    262c:      	movzwl	(%rbp), %esi
    2630:      	testl	%esi, %edx
    2632:      	jne	0x276 <generic_retuprobe_filter_arg+0x276>
    2638:      	jmp	0x273d <generic_retuprobe_filter_arg+0x273d>
    263d:      	movq	(%rsp), %rdi
    2641:      	movq	0x8(%rsp), %r9
    2646:      	movq	0x10(%rsp), %r11
    264b:      	movzbl	%cl, %ebx
    264e:      	jmp	0x265 <generic_retuprobe_filter_arg+0x265>
    2653:      	movq	(%rsp), %rdi
    2657:      	movq	0x8(%rsp), %r9
    265c:      	movq	0x10(%rsp), %r11
    2661:      	jmp	0x1a92 <generic_retuprobe_filter_arg+0x1a92>
    2666:      	cmpl	$0xc, %ecx
    2669:      	je	0x2674 <generic_retuprobe_filter_arg+0x2674>
    266b:      	cmpl	$0xa, %ecx
    266e:      	jne	0x2b00 <generic_retuprobe_filter_arg+0x2b00>
    2674:      	cmpq	%rsi, (%rbp)
    2678:      	jg	0x276 <generic_retuprobe_filter_arg+0x276>
    267e:      	jmp	0x2b16 <generic_retuprobe_filter_arg+0x2b16>
    2683:      	xorl	%ebx, %ebx
    2685:      	movq	0x8(%rsp), %r9
    268a:      	movq	0x10(%rsp), %r11
    268f:      	movq	(%rsp), %rdi
    2693:      	jmp	0x2ef2 <generic_retuprobe_filter_arg+0x2ef2>
    2698:      	cmpl	$0x2, %ebx
    269b:      	je	0x2a62 <generic_retuprobe_filter_arg+0x2a62>
    26a1:      	cmpl	$0x3, %ebx
    26a4:      	jne	0x845 <generic_retuprobe_filter_arg+0x845>
    26aa:      	movl	$0x1, %eax
    26af:      	leaq	0x38(%rsp), %rsi
    26b4:      	movq	(%rip), %rdi            # 0x26bb <generic_retuprobe_filter_arg+0x26bb>
    26bb:      	jmp	0x2a86 <generic_retuprobe_filter_arg+0x2a86>
    26c0:      	cmpl	$0x6, %ebx
    26c3:      	je	0x2a75 <generic_retuprobe_filter_arg+0x2a75>
    26c9:      	cmpl	$0x7, %ebx
    26cc:      	jne	0x845 <generic_retuprobe_filter_arg+0x845>
    26d2:      	movl	$0x1, %eax
    26d7:      	leaq	0x38(%rsp), %rsi
    26dc:      	movq	(%rip), %rdi            # 0x26e3 <generic_retuprobe_filter_arg+0x26e3>
    26e3:      	jmp	0x2a86 <generic_retuprobe_filter_arg+0x2a86>
    26e8:      	movl	$0x1, %ebx
    26ed:      	jmp	0x2ee4 <generic_retuprobe_filter_arg+0x2ee4>
    26f2:      	movzbl	(%rbp), %esi
    26f6:      	cmpl	%esi, %edx
    26f8:      	jb	0x276 <generic_retuprobe_filter_arg+0x276>
    26fe:      	cmpl	$0x11, %ecx
    2701:      	jb	0x2f69 <generic_retuprobe_filter_arg+0x2f69>
    2707:      	movl	0x18(%r15), %edx
    270b:      	cmpl	$0x2, %eax
    270e:      	jle	0x2937 <generic_retuprobe_filter_arg+0x2937>
    2714:      	leal	-0x3(%rax), %esi
    2717:      	cmpl	$0x2, %esi
    271a:      	jae	0x2b8b <generic_retuprobe_filter_arg+0x2b8b>
    2720:      	movzbl	(%rbp), %esi
    2724:      	cmpl	%esi, %edx
    2726:      	jne	0x2cf9 <generic_retuprobe_filter_arg+0x2cf9>
    272c:      	jmp	0x2e81 <generic_retuprobe_filter_arg+0x2e81>
    2731:      	movzwl	(%rbp), %esi
    2735:      	cmpl	%esi, %edx
    2737:      	jb	0x276 <generic_retuprobe_filter_arg+0x276>
    273d:      	cmpl	$0x11, %ecx
    2740:      	jb	0x2f69 <generic_retuprobe_filter_arg+0x2f69>
    2746:      	movl	0x18(%r15), %edx
    274a:      	cmpl	$0x2, %eax
    274d:      	jle	0x295a <generic_retuprobe_filter_arg+0x295a>
    2753:      	leal	-0x3(%rax), %esi
    2756:      	cmpl	$0x2, %esi
    2759:      	jae	0x2ba5 <generic_retuprobe_filter_arg+0x2ba5>
    275f:      	movzwl	(%rbp), %esi
    2763:      	cmpl	%esi, %edx
    2765:      	jne	0x2d3f <generic_retuprobe_filter_arg+0x2d3f>
    276b:      	jmp	0x2e81 <generic_retuprobe_filter_arg+0x2e81>
    2770:      	cmpl	%edx, %r8d
    2773:      	setbe	%r8b
    2777:      	cmpl	%edi, %edx
    2779:      	setbe	%dil
    277d:      	andb	%r8b, %dil
    2780:      	orb	%dil, %al
    2783:      	cmpl	$0x21, %esi
    2786:      	jb	0x2aef <generic_retuprobe_filter_arg+0x2aef>
    278c:      	movl	0x28(%r15), %edi
    2790:      	movl	0x2c(%r15), %esi
    2794:      	cmpl	$0xc, %ecx
    2797:      	ja	0x2ae1 <generic_retuprobe_filter_arg+0x2ae1>
    279d:      	movl	$0x1402, %r8d           # imm = 0x1402
    27a3:      	btl	%ecx, %r8d
    27a7:      	jae	0x2ae1 <generic_retuprobe_filter_arg+0x2ae1>
    27ad:      	cmpl	%edx, %edi
    27af:      	setle	%cl
    27b2:      	cmpl	%esi, %edx
    27b4:      	setle	%dl
    27b7:      	jmp	0x2aeb <generic_retuprobe_filter_arg+0x2aeb>
    27bc:      	cmpl	%eax, %edi
    27be:      	movq	(%rsp), %rdi
    27c2:      	ja	0x27cc <generic_retuprobe_filter_arg+0x27cc>
    27c4:      	cmpl	%esi, %eax
    27c6:      	jbe	0x276 <generic_retuprobe_filter_arg+0x276>
    27cc:      	cmpl	$0x21, %edx
    27cf:      	jb	0xb8 <generic_retuprobe_filter_arg+0xb8>
    27d5:      	movl	0x28(%r15), %esi
    27d9:      	movl	0x2c(%r15), %edx
    27dd:      	cmpl	$0xc, %ecx
    27e0:      	ja	0x2bbf <generic_retuprobe_filter_arg+0x2bbf>
    27e6:      	movl	$0x1402, %r8d           # imm = 0x1402
    27ec:      	btl	%ecx, %r8d
    27f0:      	jae	0x2bbf <generic_retuprobe_filter_arg+0x2bbf>
    27f6:      	cmpl	%eax, %esi
    27f8:      	jg	0xb8 <generic_retuprobe_filter_arg+0xb8>
    27fe:      	cmpl	%edx, %eax
    2800:      	jle	0x276 <generic_retuprobe_filter_arg+0x276>
    2806:      	jmp	0xb8 <generic_retuprobe_filter_arg+0xb8>
    280b:      	cmpl	%esi, (%rbp)
    280e:      	ja	0x276 <generic_retuprobe_filter_arg+0x276>
    2814:      	jmp	0x281f <generic_retuprobe_filter_arg+0x281f>
    2816:      	cmpl	%esi, (%rbp)
    2819:      	jb	0x276 <generic_retuprobe_filter_arg+0x276>
    281f:      	cmpl	$0x11, %edx
    2822:      	jb	0x2f69 <generic_retuprobe_filter_arg+0x2f69>
    2828:      	movl	0x18(%r15), %esi
    282c:      	cmpl	$0x2, %eax
    282f:      	jle	0x284b <generic_retuprobe_filter_arg+0x284b>
    2831:      	leal	-0x3(%rax), %edi
    2834:      	cmpl	$0x2, %edi
    2837:      	jae	0x2880 <generic_retuprobe_filter_arg+0x2880>
    2839:      	cmpl	%esi, (%rbp)
    283c:      	movq	(%rsp), %rdi
    2840:      	jne	0x2d98 <generic_retuprobe_filter_arg+0x2d98>
    2846:      	jmp	0x2e81 <generic_retuprobe_filter_arg+0x2e81>
    284b:      	cmpl	$0x1, %eax
    284e:      	je	0x289b <generic_retuprobe_filter_arg+0x289b>
    2850:      	cmpl	$0x2, %eax
    2853:      	jne	0x2d98 <generic_retuprobe_filter_arg+0x2d98>
    2859:      	cmpl	$0xc, %ecx
    285c:      	ja	0x2d8f <generic_retuprobe_filter_arg+0x2d8f>
    2862:      	movl	$0x1402, %r8d           # imm = 0x1402
    2868:      	btl	%ecx, %r8d
    286c:      	jae	0x2d8f <generic_retuprobe_filter_arg+0x2d8f>
    2872:      	cmpl	%esi, (%rbp)
    2875:      	jl	0x276 <generic_retuprobe_filter_arg+0x276>
    287b:      	jmp	0x2d98 <generic_retuprobe_filter_arg+0x2d98>
    2880:      	cmpl	$0xc, %eax
    2883:      	movq	(%rsp), %rdi
    2887:      	jne	0x2d98 <generic_retuprobe_filter_arg+0x2d98>
    288d:      	testl	%esi, (%rbp)
    2890:      	jne	0x276 <generic_retuprobe_filter_arg+0x276>
    2896:      	jmp	0x2d98 <generic_retuprobe_filter_arg+0x2d98>
    289b:      	cmpl	$0xc, %ecx
    289e:      	ja	0x2d84 <generic_retuprobe_filter_arg+0x2d84>
    28a4:      	movl	$0x1402, %r8d           # imm = 0x1402
    28aa:      	btl	%ecx, %r8d
    28ae:      	jae	0x2d84 <generic_retuprobe_filter_arg+0x2d84>
    28b4:      	cmpl	%esi, (%rbp)
    28b7:      	jg	0x276 <generic_retuprobe_filter_arg+0x276>
    28bd:      	jmp	0x2d98 <generic_retuprobe_filter_arg+0x2d98>
    28c2:      	cmpq	%rdx, %rdi
    28c5:      	setbe	%cl
    28c8:      	cmpq	%rsi, %rdx
    28cb:      	jmp	0x2ae8 <generic_retuprobe_filter_arg+0x2ae8>
    28d0:      	cmpl	$0x2, %ebx
    28d3:      	je	0x2c17 <generic_retuprobe_filter_arg+0x2c17>
    28d9:      	cmpl	$0x3, %ebx
    28dc:      	jne	0x2c92 <generic_retuprobe_filter_arg+0x2c92>
    28e2:      	movl	$0x1, %eax
    28e7:      	leaq	0x38(%rsp), %rsi
    28ec:      	movq	(%rip), %rdi            # 0x28f3 <generic_retuprobe_filter_arg+0x28f3>
    28f3:      	jmp	0x2c3b <generic_retuprobe_filter_arg+0x2c3b>
    28f8:      	cmpl	$0x6, %ebx
    28fb:      	je	0x2c2a <generic_retuprobe_filter_arg+0x2c2a>
    2901:      	cmpl	$0x7, %ebx
    2904:      	jne	0x2c92 <generic_retuprobe_filter_arg+0x2c92>
    290a:      	movl	$0x1, %eax
    290f:      	leaq	0x38(%rsp), %rsi
    2914:      	movq	(%rip), %rdi            # 0x291b <generic_retuprobe_filter_arg+0x291b>
    291b:      	jmp	0x2c3b <generic_retuprobe_filter_arg+0x2c3b>
    2920:      	cmpq	%rax, %rsi
    2923:      	ja	0xb8 <generic_retuprobe_filter_arg+0xb8>
    2929:      	cmpq	%rdx, %rax
    292c:      	jbe	0x276 <generic_retuprobe_filter_arg+0x276>
    2932:      	jmp	0xb8 <generic_retuprobe_filter_arg+0xb8>
    2937:      	cmpl	$0x1, %eax
    293a:      	je	0x2ced <generic_retuprobe_filter_arg+0x2ced>
    2940:      	cmpl	$0x2, %eax
    2943:      	jne	0x2cf9 <generic_retuprobe_filter_arg+0x2cf9>
    2949:      	movzbl	(%rbp), %esi
    294d:      	cmpl	%esi, %edx
    294f:      	ja	0x276 <generic_retuprobe_filter_arg+0x276>
    2955:      	jmp	0x2cf9 <generic_retuprobe_filter_arg+0x2cf9>
    295a:      	cmpl	$0x1, %eax
    295d:      	je	0x2d33 <generic_retuprobe_filter_arg+0x2d33>
    2963:      	cmpl	$0x2, %eax
    2966:      	jne	0x2d3f <generic_retuprobe_filter_arg+0x2d3f>
    296c:      	movzwl	(%rbp), %esi
    2970:      	cmpl	%esi, %edx
    2972:      	ja	0x276 <generic_retuprobe_filter_arg+0x276>
    2978:      	jmp	0x2d3f <generic_retuprobe_filter_arg+0x2d3f>
    297d:      	movl	$0x1, %ebx
    2982:      	movq	(%rsp), %rdi
    2986:      	jmp	0x2ef2 <generic_retuprobe_filter_arg+0x2ef2>
    298b:      	movq	%rcx, %rbx
    298e:      	movw	%bp, (%rcx)
    2991:      	leaq	0x2(%rcx), %rdi
    2995:      	movl	$0x4, %eax
    299a:      	movq	0x20(%rsp), %rdx
    299f:      	movl	%ebp, %esi
    29a1:      	callq	*%rax
    29a3:      	movq	0x90(%rsp), %rsi
    29ab:      	subl	%ebp, %esi
    29ad:      	jbe	0x29c7 <generic_retuprobe_filter_arg+0x29c7>
    29af:      	leaq	(%rbx,%rbp), %rdi
    29b3:      	addq	$0x2, %rdi
    29b7:      	andl	$0xfff, %esi            # imm = 0xFFF
    29bd:      	movl	$0x4, %eax
    29c2:      	movq	%r12, %rdx
    29c5:      	callq	*%rax
    29c7:      	movl	0x88(%rsp), %eax
    29ce:      	movl	%eax, 0x38(%rsp)
    29d2:      	movl	0x18(%rsp), %eax
    29d6:      	cmpl	$0x3, %eax
    29d9:      	jg	0x2a0b <generic_retuprobe_filter_arg+0x2a0b>
    29db:      	cmpl	$0x1, %eax
    29de:      	leaq	0x38(%rsp), %rsi
    29e3:      	jg	0x2ca7 <generic_retuprobe_filter_arg+0x2ca7>
    29e9:      	testl	%eax, %eax
    29eb:      	je	0x2e8e <generic_retuprobe_filter_arg+0x2e8e>
    29f1:      	cmpl	$0x1, %eax
    29f4:      	jne	0x2ee2 <generic_retuprobe_filter_arg+0x2ee2>
    29fa:      	movl	$0x1, %eax
    29ff:      	movq	(%rip), %rdi            # 0x2a06 <generic_retuprobe_filter_arg+0x2a06>
    2a06:      	jmp	0x2ec4 <generic_retuprobe_filter_arg+0x2ec4>
    2a0b:      	cmpl	$0x5, %eax
    2a0e:      	leaq	0x38(%rsp), %rsi
    2a13:      	jg	0x2cca <generic_retuprobe_filter_arg+0x2cca>
    2a19:      	cmpl	$0x4, %eax
    2a1c:      	je	0x2e9c <generic_retuprobe_filter_arg+0x2e9c>
    2a22:      	cmpl	$0x5, %eax
    2a25:      	jne	0x2ee2 <generic_retuprobe_filter_arg+0x2ee2>
    2a2b:      	movl	$0x1, %eax
    2a30:      	movq	(%rip), %rdi            # 0x2a37 <generic_retuprobe_filter_arg+0x2a37>
    2a37:      	jmp	0x2ec4 <generic_retuprobe_filter_arg+0x2ec4>
    2a3c:      	movl	$0x1, %eax
    2a41:      	movq	(%rip), %rdi            # 0x2a48 <generic_retuprobe_filter_arg+0x2a48>
    2a48:      	leaq	0x38(%rsp), %rsi
    2a4d:      	jmp	0x2a86 <generic_retuprobe_filter_arg+0x2a86>
    2a4f:      	movl	$0x1, %eax
    2a54:      	leaq	0x38(%rsp), %rsi
    2a59:      	movq	(%rip), %rdi            # 0x2a60 <generic_retuprobe_filter_arg+0x2a60>
    2a60:      	jmp	0x2a86 <generic_retuprobe_filter_arg+0x2a86>
    2a62:      	movl	$0x1, %eax
    2a67:      	leaq	0x38(%rsp), %rsi
    2a6c:      	movq	(%rip), %rdi            # 0x2a73 <generic_retuprobe_filter_arg+0x2a73>
    2a73:      	jmp	0x2a86 <generic_retuprobe_filter_arg+0x2a86>
    2a75:      	movl	$0x1, %eax
    2a7a:      	leaq	0x38(%rsp), %rsi
    2a7f:      	movq	(%rip), %rdi            # 0x2a86 <generic_retuprobe_filter_arg+0x2a86>
    2a86:      	callq	*%rax
    2a88:      	testq	%rax, %rax
    2a8b:      	je	0x2aa6 <generic_retuprobe_filter_arg+0x2aa6>
    2a8d:      	movq	%rax, %rdi
    2a90:      	movl	$0x1, %eax
    2a95:      	movq	0x18(%rsp), %rsi
    2a9a:      	callq	*%rax
    2a9c:      	xorl	%ebx, %ebx
    2a9e:      	testq	%rax, %rax
    2aa1:      	setne	%bl
    2aa4:      	jmp	0x2aa8 <generic_retuprobe_filter_arg+0x2aa8>
    2aa6:      	xorl	%ebx, %ebx
    2aa8:      	movq	(%rsp), %rdi
    2aac:      	movq	0x8(%rsp), %r9
    2ab1:      	movq	0x10(%rsp), %r11
    2ab6:      	movl	0x4(%r15), %eax
    2aba:      	cmpq	$0x25, %rax
    2abe:      	ja	0x265 <generic_retuprobe_filter_arg+0x265>
    2ac4:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    2ace:      	btq	%rax, %rcx
    2ad2:      	jae	0x265 <generic_retuprobe_filter_arg+0x265>
    2ad8:      	xorq	$0x1, %rbx
    2adc:      	jmp	0x265 <generic_retuprobe_filter_arg+0x265>
    2ae1:      	cmpl	%edx, %edi
    2ae3:      	setbe	%cl
    2ae6:      	cmpl	%esi, %edx
    2ae8:      	setbe	%dl
    2aeb:      	andb	%cl, %dl
    2aed:      	orb	%dl, %al
    2aef:      	movq	(%rsp), %rdi
    2af3:      	testb	%al, %al
    2af5:      	je	0x276 <generic_retuprobe_filter_arg+0x276>
    2afb:      	jmp	0xb8 <generic_retuprobe_filter_arg+0xb8>
    2b00:      	cmpq	%rsi, (%rbp)
    2b04:      	ja	0x276 <generic_retuprobe_filter_arg+0x276>
    2b0a:      	jmp	0x2b16 <generic_retuprobe_filter_arg+0x2b16>
    2b0c:      	cmpq	%rsi, (%rbp)
    2b10:      	jb	0x276 <generic_retuprobe_filter_arg+0x276>
    2b16:      	cmpl	$0x21, %edx
    2b19:      	jb	0x2f69 <generic_retuprobe_filter_arg+0x2f69>
    2b1f:      	movq	0x28(%r15), %rdx
    2b23:      	cmpl	$0x2, %eax
    2b26:      	jle	0x2b51 <generic_retuprobe_filter_arg+0x2b51>
    2b28:      	leal	-0x3(%rax), %ecx
    2b2b:      	cmpl	$0x2, %ecx
    2b2e:      	jb	0x2b7c <generic_retuprobe_filter_arg+0x2b7c>
    2b30:      	cmpl	$0x6, %eax
    2b33:      	je	0x276 <generic_retuprobe_filter_arg+0x276>
    2b39:      	cmpl	$0xc, %eax
    2b3c:      	jne	0xb8 <generic_retuprobe_filter_arg+0xb8>
    2b42:      	testq	%rdx, (%rbp)
    2b46:      	jne	0x276 <generic_retuprobe_filter_arg+0x276>
    2b4c:      	jmp	0x2f69 <generic_retuprobe_filter_arg+0x2f69>
    2b51:      	cmpl	$0x1, %eax
    2b54:      	je	0x2bd4 <generic_retuprobe_filter_arg+0x2bd4>
    2b56:      	cmpl	$0x2, %eax
    2b59:      	jne	0xb8 <generic_retuprobe_filter_arg+0xb8>
    2b5f:      	cmpl	$0xc, %ecx
    2b62:      	je	0x2b6d <generic_retuprobe_filter_arg+0x2b6d>
    2b64:      	cmpl	$0xa, %ecx
    2b67:      	jne	0x2f29 <generic_retuprobe_filter_arg+0x2f29>
    2b6d:      	cmpq	%rdx, (%rbp)
    2b71:      	jl	0x276 <generic_retuprobe_filter_arg+0x276>
    2b77:      	jmp	0x2f69 <generic_retuprobe_filter_arg+0x2f69>
    2b7c:      	cmpq	%rdx, (%rbp)
    2b80:      	je	0x2e81 <generic_retuprobe_filter_arg+0x2e81>
    2b86:      	jmp	0x2f69 <generic_retuprobe_filter_arg+0x2f69>
    2b8b:      	cmpl	$0xc, %eax
    2b8e:      	jne	0x2cf9 <generic_retuprobe_filter_arg+0x2cf9>
    2b94:      	movzbl	(%rbp), %esi
    2b98:      	testl	%esi, %edx
    2b9a:      	jne	0x276 <generic_retuprobe_filter_arg+0x276>
    2ba0:      	jmp	0x2cf9 <generic_retuprobe_filter_arg+0x2cf9>
    2ba5:      	cmpl	$0xc, %eax
    2ba8:      	jne	0x2d3f <generic_retuprobe_filter_arg+0x2d3f>
    2bae:      	movzwl	(%rbp), %esi
    2bb2:      	testl	%esi, %edx
    2bb4:      	jne	0x276 <generic_retuprobe_filter_arg+0x276>
    2bba:      	jmp	0x2d3f <generic_retuprobe_filter_arg+0x2d3f>
    2bbf:      	cmpl	%eax, %esi
    2bc1:      	ja	0xb8 <generic_retuprobe_filter_arg+0xb8>
    2bc7:      	cmpl	%edx, %eax
    2bc9:      	jbe	0x276 <generic_retuprobe_filter_arg+0x276>
    2bcf:      	jmp	0xb8 <generic_retuprobe_filter_arg+0xb8>
    2bd4:      	cmpl	$0xc, %ecx
    2bd7:      	je	0x2be2 <generic_retuprobe_filter_arg+0x2be2>
    2bd9:      	cmpl	$0xa, %ecx
    2bdc:      	jne	0x2f35 <generic_retuprobe_filter_arg+0x2f35>
    2be2:      	cmpq	%rdx, (%rbp)
    2be6:      	jg	0x276 <generic_retuprobe_filter_arg+0x276>
    2bec:      	jmp	0x2f69 <generic_retuprobe_filter_arg+0x2f69>
    2bf1:      	movl	$0x1, %eax
    2bf6:      	movq	(%rip), %rdi            # 0x2bfd <generic_retuprobe_filter_arg+0x2bfd>
    2bfd:      	leaq	0x38(%rsp), %rsi
    2c02:      	jmp	0x2c3b <generic_retuprobe_filter_arg+0x2c3b>
    2c04:      	movl	$0x1, %eax
    2c09:      	leaq	0x38(%rsp), %rsi
    2c0e:      	movq	(%rip), %rdi            # 0x2c15 <generic_retuprobe_filter_arg+0x2c15>
    2c15:      	jmp	0x2c3b <generic_retuprobe_filter_arg+0x2c3b>
    2c17:      	movl	$0x1, %eax
    2c1c:      	leaq	0x38(%rsp), %rsi
    2c21:      	movq	(%rip), %rdi            # 0x2c28 <generic_retuprobe_filter_arg+0x2c28>
    2c28:      	jmp	0x2c3b <generic_retuprobe_filter_arg+0x2c3b>
    2c2a:      	movl	$0x1, %eax
    2c2f:      	leaq	0x38(%rsp), %rsi
    2c34:      	movq	(%rip), %rdi            # 0x2c3b <generic_retuprobe_filter_arg+0x2c3b>
    2c3b:      	callq	*%rax
    2c3d:      	testq	%rax, %rax
    2c40:      	je	0x2c5b <generic_retuprobe_filter_arg+0x2c5b>
    2c42:      	movq	%rax, %rdi
    2c45:      	movl	$0x1, %eax
    2c4a:      	movq	0x18(%rsp), %rsi
    2c4f:      	callq	*%rax
    2c51:      	xorl	%ebx, %ebx
    2c53:      	testq	%rax, %rax
    2c56:      	setne	%bl
    2c59:      	jmp	0x2c5d <generic_retuprobe_filter_arg+0x2c5d>
    2c5b:      	xorl	%ebx, %ebx
    2c5d:      	movq	(%rsp), %rdi
    2c61:      	movq	0x8(%rsp), %r9
    2c66:      	movq	0x10(%rsp), %r11
    2c6b:      	movl	0x4(%r15), %eax
    2c6f:      	cmpq	$0x25, %rax
    2c73:      	ja	0x265 <generic_retuprobe_filter_arg+0x265>
    2c79:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    2c83:      	btq	%rax, %rcx
    2c87:      	jb	0x2f19 <generic_retuprobe_filter_arg+0x2f19>
    2c8d:      	jmp	0x265 <generic_retuprobe_filter_arg+0x265>
    2c92:      	xorl	%ebx, %ebx
    2c94:      	movq	(%rsp), %rdi
    2c98:      	movl	0x4(%r15), %eax
    2c9c:      	cmpq	$0x25, %rax
    2ca0:      	jbe	0x2c79 <generic_retuprobe_filter_arg+0x2c79>
    2ca2:      	jmp	0x265 <generic_retuprobe_filter_arg+0x265>
    2ca7:      	cmpl	$0x2, %eax
    2caa:      	je	0x2eaa <generic_retuprobe_filter_arg+0x2eaa>
    2cb0:      	cmpl	$0x3, %eax
    2cb3:      	jne	0x2ee2 <generic_retuprobe_filter_arg+0x2ee2>
    2cb9:      	movl	$0x1, %eax
    2cbe:      	movq	(%rip), %rdi            # 0x2cc5 <generic_retuprobe_filter_arg+0x2cc5>
    2cc5:      	jmp	0x2ec4 <generic_retuprobe_filter_arg+0x2ec4>
    2cca:      	cmpl	$0x6, %eax
    2ccd:      	je	0x2eb8 <generic_retuprobe_filter_arg+0x2eb8>
    2cd3:      	cmpl	$0x7, %eax
    2cd6:      	jne	0x2ee2 <generic_retuprobe_filter_arg+0x2ee2>
    2cdc:      	movl	$0x1, %eax
    2ce1:      	movq	(%rip), %rdi            # 0x2ce8 <generic_retuprobe_filter_arg+0x2ce8>
    2ce8:      	jmp	0x2ec4 <generic_retuprobe_filter_arg+0x2ec4>
    2ced:      	movzbl	(%rbp), %esi
    2cf1:      	cmpl	%esi, %edx
    2cf3:      	jb	0x276 <generic_retuprobe_filter_arg+0x276>
    2cf9:      	cmpl	$0x15, %ecx
    2cfc:      	jb	0x2f69 <generic_retuprobe_filter_arg+0x2f69>
    2d02:      	movl	0x1c(%r15), %ecx
    2d06:      	cmpl	$0x2, %eax
    2d09:      	jle	0x2e34 <generic_retuprobe_filter_arg+0x2e34>
    2d0f:      	leal	-0x3(%rax), %edx
    2d12:      	cmpl	$0x2, %edx
    2d15:      	jb	0x2e6f <generic_retuprobe_filter_arg+0x2e6f>
    2d1b:      	cmpl	$0x6, %eax
    2d1e:      	je	0x276 <generic_retuprobe_filter_arg+0x276>
    2d24:      	cmpl	$0xc, %eax
    2d27:      	jne	0xb8 <generic_retuprobe_filter_arg+0xb8>
    2d2d:      	movzbl	(%rbp), %edx
    2d31:      	jmp	0x2d77 <generic_retuprobe_filter_arg+0x2d77>
    2d33:      	movzwl	(%rbp), %esi
    2d37:      	cmpl	%esi, %edx
    2d39:      	jb	0x276 <generic_retuprobe_filter_arg+0x276>
    2d3f:      	cmpl	$0x15, %ecx
    2d42:      	jb	0x2f69 <generic_retuprobe_filter_arg+0x2f69>
    2d48:      	movl	0x1c(%r15), %ecx
    2d4c:      	cmpl	$0x2, %eax
    2d4f:      	jle	0x2e4c <generic_retuprobe_filter_arg+0x2e4c>
    2d55:      	leal	-0x3(%rax), %edx
    2d58:      	cmpl	$0x2, %edx
    2d5b:      	jb	0x2e75 <generic_retuprobe_filter_arg+0x2e75>
    2d61:      	cmpl	$0x6, %eax
    2d64:      	je	0x276 <generic_retuprobe_filter_arg+0x276>
    2d6a:      	cmpl	$0xc, %eax
    2d6d:      	jne	0xb8 <generic_retuprobe_filter_arg+0xb8>
    2d73:      	movzwl	(%rbp), %edx
    2d77:      	testl	%edx, %ecx
    2d79:      	jne	0x276 <generic_retuprobe_filter_arg+0x276>
    2d7f:      	jmp	0x2f69 <generic_retuprobe_filter_arg+0x2f69>
    2d84:      	cmpl	%esi, (%rbp)
    2d87:      	ja	0x276 <generic_retuprobe_filter_arg+0x276>
    2d8d:      	jmp	0x2d98 <generic_retuprobe_filter_arg+0x2d98>
    2d8f:      	cmpl	%esi, (%rbp)
    2d92:      	jb	0x276 <generic_retuprobe_filter_arg+0x276>
    2d98:      	cmpl	$0x15, %edx
    2d9b:      	jb	0x2f69 <generic_retuprobe_filter_arg+0x2f69>
    2da1:      	movl	0x1c(%r15), %edx
    2da5:      	cmpl	$0x2, %eax
    2da8:      	jle	0x2dd2 <generic_retuprobe_filter_arg+0x2dd2>
    2daa:      	leal	-0x3(%rax), %ecx
    2dad:      	cmpl	$0x2, %ecx
    2db0:      	jb	0x2e05 <generic_retuprobe_filter_arg+0x2e05>
    2db2:      	cmpl	$0x6, %eax
    2db5:      	je	0x276 <generic_retuprobe_filter_arg+0x276>
    2dbb:      	cmpl	$0xc, %eax
    2dbe:      	jne	0xb8 <generic_retuprobe_filter_arg+0xb8>
    2dc4:      	testl	%edx, (%rbp)
    2dc7:      	jne	0x276 <generic_retuprobe_filter_arg+0x276>
    2dcd:      	jmp	0x2f69 <generic_retuprobe_filter_arg+0x2f69>
    2dd2:      	cmpl	$0x1, %eax
    2dd5:      	je	0x2e0f <generic_retuprobe_filter_arg+0x2e0f>
    2dd7:      	cmpl	$0x2, %eax
    2dda:      	jne	0xb8 <generic_retuprobe_filter_arg+0xb8>
    2de0:      	cmpl	$0xc, %ecx
    2de3:      	ja	0x2f55 <generic_retuprobe_filter_arg+0x2f55>
    2de9:      	movl	$0x1402, %esi           # imm = 0x1402
    2dee:      	btl	%ecx, %esi
    2df1:      	jae	0x2f55 <generic_retuprobe_filter_arg+0x2f55>
    2df7:      	cmpl	%edx, (%rbp)
    2dfa:      	jl	0x276 <generic_retuprobe_filter_arg+0x276>
    2e00:      	jmp	0x2f69 <generic_retuprobe_filter_arg+0x2f69>
    2e05:      	cmpl	%edx, (%rbp)
    2e08:      	je	0x2e81 <generic_retuprobe_filter_arg+0x2e81>
    2e0a:      	jmp	0x2f69 <generic_retuprobe_filter_arg+0x2f69>
    2e0f:      	cmpl	$0xc, %ecx
    2e12:      	ja	0x2f60 <generic_retuprobe_filter_arg+0x2f60>
    2e18:      	movl	$0x1402, %esi           # imm = 0x1402
    2e1d:      	btl	%ecx, %esi
    2e20:      	jae	0x2f60 <generic_retuprobe_filter_arg+0x2f60>
    2e26:      	cmpl	%edx, (%rbp)
    2e29:      	jg	0x276 <generic_retuprobe_filter_arg+0x276>
    2e2f:      	jmp	0x2f69 <generic_retuprobe_filter_arg+0x2f69>
    2e34:      	cmpl	$0x1, %eax
    2e37:      	je	0x2f41 <generic_retuprobe_filter_arg+0x2f41>
    2e3d:      	cmpl	$0x2, %eax
    2e40:      	jne	0xb8 <generic_retuprobe_filter_arg+0xb8>
    2e46:      	movzbl	(%rbp), %edx
    2e4a:      	jmp	0x2e62 <generic_retuprobe_filter_arg+0x2e62>
    2e4c:      	cmpl	$0x1, %eax
    2e4f:      	je	0x2f47 <generic_retuprobe_filter_arg+0x2f47>
    2e55:      	cmpl	$0x2, %eax
    2e58:      	jne	0xb8 <generic_retuprobe_filter_arg+0xb8>
    2e5e:      	movzwl	(%rbp), %edx
    2e62:      	cmpl	%edx, %ecx
    2e64:      	ja	0x276 <generic_retuprobe_filter_arg+0x276>
    2e6a:      	jmp	0x2f69 <generic_retuprobe_filter_arg+0x2f69>
    2e6f:      	movzbl	(%rbp), %edx
    2e73:      	jmp	0x2e79 <generic_retuprobe_filter_arg+0x2e79>
    2e75:      	movzwl	(%rbp), %edx
    2e79:      	cmpl	%edx, %ecx
    2e7b:      	jne	0x2f69 <generic_retuprobe_filter_arg+0x2f69>
    2e81:      	xorl	%ebx, %ebx
    2e83:      	cmpl	$0x3, %eax
    2e86:      	sete	%bl
    2e89:      	jmp	0x265 <generic_retuprobe_filter_arg+0x265>
    2e8e:      	movl	$0x1, %eax
    2e93:      	movq	(%rip), %rdi            # 0x2e9a <generic_retuprobe_filter_arg+0x2e9a>
    2e9a:      	jmp	0x2ec4 <generic_retuprobe_filter_arg+0x2ec4>
    2e9c:      	movl	$0x1, %eax
    2ea1:      	movq	(%rip), %rdi            # 0x2ea8 <generic_retuprobe_filter_arg+0x2ea8>
    2ea8:      	jmp	0x2ec4 <generic_retuprobe_filter_arg+0x2ec4>
    2eaa:      	movl	$0x1, %eax
    2eaf:      	movq	(%rip), %rdi            # 0x2eb6 <generic_retuprobe_filter_arg+0x2eb6>
    2eb6:      	jmp	0x2ec4 <generic_retuprobe_filter_arg+0x2ec4>
    2eb8:      	movl	$0x1, %eax
    2ebd:      	movq	(%rip), %rdi            # 0x2ec4 <generic_retuprobe_filter_arg+0x2ec4>
    2ec4:      	callq	*%rax
    2ec6:      	testq	%rax, %rax
    2ec9:      	je	0x2ee2 <generic_retuprobe_filter_arg+0x2ee2>
    2ecb:      	movq	%rax, %rdi
    2ece:      	movl	$0x1, %eax
    2ed3:      	movq	%rbx, %rsi
    2ed6:      	callq	*%rax
    2ed8:      	xorl	%ebx, %ebx
    2eda:      	testq	%rax, %rax
    2edd:      	setne	%bl
    2ee0:      	jmp	0x2ee4 <generic_retuprobe_filter_arg+0x2ee4>
    2ee2:      	xorl	%ebx, %ebx
    2ee4:      	movq	(%rsp), %rdi
    2ee8:      	movq	0x8(%rsp), %r9
    2eed:      	movq	0x10(%rsp), %r11
    2ef2:      	movl	0x4(%r15), %eax
    2ef6:      	cmpq	$0x25, %rax
    2efa:      	ja	0x260 <generic_retuprobe_filter_arg+0x260>
    2f00:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    2f0a:      	btq	%rax, %rcx
    2f0e:      	movq	0x68(%rsp), %r12
    2f13:      	jae	0x265 <generic_retuprobe_filter_arg+0x265>
    2f19:      	xorl	%eax, %eax
    2f1b:      	testq	%rbx, %rbx
    2f1e:      	sete	%al
    2f21:      	movq	%rax, %rbx
    2f24:      	jmp	0x265 <generic_retuprobe_filter_arg+0x265>
    2f29:      	cmpq	%rdx, (%rbp)
    2f2d:      	jb	0x276 <generic_retuprobe_filter_arg+0x276>
    2f33:      	jmp	0x2f69 <generic_retuprobe_filter_arg+0x2f69>
    2f35:      	cmpq	%rdx, (%rbp)
    2f39:      	ja	0x276 <generic_retuprobe_filter_arg+0x276>
    2f3f:      	jmp	0x2f69 <generic_retuprobe_filter_arg+0x2f69>
    2f41:      	movzbl	(%rbp), %edx
    2f45:      	jmp	0x2f4b <generic_retuprobe_filter_arg+0x2f4b>
    2f47:      	movzwl	(%rbp), %edx
    2f4b:      	cmpl	%edx, %ecx
    2f4d:      	jb	0x276 <generic_retuprobe_filter_arg+0x276>
    2f53:      	jmp	0x2f69 <generic_retuprobe_filter_arg+0x2f69>
    2f55:      	cmpl	%edx, (%rbp)
    2f58:      	jb	0x276 <generic_retuprobe_filter_arg+0x276>
    2f5e:      	jmp	0x2f69 <generic_retuprobe_filter_arg+0x2f69>
    2f60:      	cmpl	%edx, (%rbp)
    2f63:      	ja	0x276 <generic_retuprobe_filter_arg+0x276>
    2f69:      	orl	$0x2, %eax
    2f6c:      	cmpl	$0x6, %eax
    2f6f:      	je	0x276 <generic_retuprobe_filter_arg+0x276>
    2f75:      	jmp	0xb8 <generic_retuprobe_filter_arg+0xb8>
    2f7a:      	nopw	(%rax,%rax)

0000000000002f80 <generic_retuprobe_actions>:
    2f80:      	pushq	%rbp
    2f81:      	pushq	%r15
    2f83:      	pushq	%r14
    2f85:      	pushq	%r13
    2f87:      	pushq	%r12
    2f89:      	pushq	%rbx
    2f8a:      	subq	$0xa8, %rsp
    2f91:      	movq	%rdi, 0x80(%rsp)
    2f99:      	movl	$0x0, 0x88(%rsp)
    2fa4:      	movq	(%rip), %rdi            # 0x2fab <generic_retuprobe_actions+0x2b>
    2fab:      	leaq	0x88(%rsp), %rsi
    2fb3:      	movl	$0x1, %eax
    2fb8:      	callq	*%rax
    2fba:      	testq	%rax, %rax
    2fbd:      	je	0x3aa8 <generic_retuprobe_actions+0xb28>
    2fc3:      	movq	%rax, %rsi
    2fc6:      	movl	0x5f04(%rax), %ebx
    2fcc:      	cmpl	$0x2, %ebx
    2fcf:      	jl	0x3aa8 <generic_retuprobe_actions+0xb28>
    2fd5:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    2fdc:      	movq	(%rip), %rdi            # 0x2fe3 <generic_retuprobe_actions+0x63>
    2fe3:      	movl	$0x1, %eax
    2fe8:      	callq	*%rax
    2fea:      	testq	%rax, %rax
    2fed:      	je	0x3aa8 <generic_retuprobe_actions+0xb28>
    2ff3:      	movq	%rax, %r14
    2ff6:      	movl	%ebx, %eax
    2ff8:      	andl	$0x7ff, %eax            # imm = 0x7FF
    2ffd:      	addl	(%r14,%rax), %ebx
    3001:      	movl	$0x0, 0x8c(%rsp)
    300c:      	movq	(%rip), %rdi            # 0x3013 <generic_retuprobe_actions+0x93>
    3013:      	leaq	0x8c(%rsp), %rsi
    301b:      	movl	$0x1, %eax
    3020:      	andl	$0x7ff, %ebx            # imm = 0x7FF
    3026:      	callq	*%rax
    3028:      	testq	%rax, %rax
    302b:      	je	0x3052 <generic_retuprobe_actions+0xd2>
    302d:      	cmpb	$0x0, (%rax)
    3030:      	sete	0x17(%rsp)
    3035:      	je	0x306d <generic_retuprobe_actions+0xed>
    3037:      	movl	$0x5, %eax
    303c:      	movq	%rax, 0x78(%rsp)
    3041:      	movl	$0x9, %eax
    3046:      	movq	%rax, 0x70(%rsp)
    304b:      	movl	$0x7, %eax
    3050:      	jmp	0x3086 <generic_retuprobe_actions+0x106>
    3052:      	movl	$0x4, %eax
    3057:      	movq	%rax, 0x78(%rsp)
    305c:      	movl	$0x8, %eax
    3061:      	movq	%rax, 0x70(%rsp)
    3066:      	movb	$0x1, 0x17(%rsp)
    306b:      	jmp	0x3081 <generic_retuprobe_actions+0x101>
    306d:      	movl	$0x4, %eax
    3072:      	movq	%rax, 0x78(%rsp)
    3077:      	movl	$0x8, %eax
    307c:      	movq	%rax, 0x70(%rsp)
    3081:      	movl	$0x6, %eax
    3086:      	movq	%rax, 0x68(%rsp)
    308b:      	addq	%rbx, %r14
    308e:      	movb	$0x1, %al
    3090:      	movl	%eax, 0x44(%rsp)
    3094:      	movq	(%rip), %rbp            # 0x309b <generic_retuprobe_actions+0x11b>
    309b:      	xorl	%r12d, %r12d
    309e:      	xorl	%r15d, %r15d
    30a1:      	jmp	0x30ca <generic_retuprobe_actions+0x14a>
    30a3:      	incl	%r15d
    30a6:      	movl	0x4(%r14,%r15,4), %eax
    30ab:      	movl	%eax, 0x78(%rdx)
    30ae:      	nop
    30b0:      	movq	%r13, 0x70(%rdx)
    30b4:      	incl	%r15d
    30b7:      	movl	%r15d, %ebx
    30ba:      	incl	%r12d
    30bd:      	movl	%ebx, %r15d
    30c0:      	cmpl	$0x3, %r12d
    30c4:      	je	0x3a81 <generic_retuprobe_actions+0xb01>
    30ca:      	leal	0x4(,%r15,4), %eax
    30d2:      	cmpl	(%r14), %eax
    30d5:      	jae	0x3a81 <generic_retuprobe_actions+0xb01>
    30db:      	movl	%r15d, %eax
    30de:      	movslq	0x4(%r14,%rax,4), %r13
    30e3:      	movl	$0x0, 0x90(%rsp)
    30ee:      	movl	$0x1, %eax
    30f3:      	leaq	0x90(%rsp), %rsi
    30fb:      	movq	%rbp, %rdi
    30fe:      	callq	*%rax
    3100:      	xorl	%ebx, %ebx
    3102:      	testq	%rax, %rax
    3105:      	je	0x30ba <generic_retuprobe_actions+0x13a>
    3107:      	movq	%rax, %rdx
    310a:      	cmpl	$0x7, %r13d
    310e:      	jg	0x3140 <generic_retuprobe_actions+0x1c0>
    3110:      	cmpl	$0x3, %r13d
    3114:      	jg	0x3196 <generic_retuprobe_actions+0x216>
    311a:      	cmpl	$0x1, %r13d
    311e:      	jg	0x32e7 <generic_retuprobe_actions+0x367>
    3124:      	testl	%r13d, %r13d
    3127:      	je	0x34f7 <generic_retuprobe_actions+0x577>
    312d:      	cmpl	$0x1, %r13d
    3131:      	je	0x3300 <generic_retuprobe_actions+0x380>
    3137:      	jmp	0x30b0 <generic_retuprobe_actions+0x130>
    313c:      	nopl	(%rax)
    3140:      	cmpl	$0xb, %r13d
    3144:      	jg	0x32b0 <generic_retuprobe_actions+0x330>
    314a:      	leal	-0xa(%r13), %eax
    314e:      	cmpl	$0x2, %eax
    3151:      	jb	0x338f <generic_retuprobe_actions+0x40f>
    3157:      	cmpl	$0x8, %r13d
    315b:      	je	0x3451 <generic_retuprobe_actions+0x4d1>
    3161:      	cmpl	$0x9, %r13d
    3165:      	jne	0x30b0 <generic_retuprobe_actions+0x130>
    316b:      	movq	%r13, 0x8(%rsp)
    3170:      	movq	%r14, %rax
    3173:      	movq	%rbp, %r13
    3176:      	incl	%r15d
    3179:      	movl	0x4(%r14,%r15,4), %eax
    317e:      	movq	%rdx, %rbp
    3181:      	movl	$0x3, %ebx
    3186:      	cmpb	$0x0, 0x17(%rsp)
    318b:      	jne	0x35d3 <generic_retuprobe_actions+0x653>
    3191:      	jmp	0x35f8 <generic_retuprobe_actions+0x678>
    3196:      	leal	-0x6(%r13), %eax
    319a:      	cmpl	$0x2, %eax
    319d:      	jb	0x30a3 <generic_retuprobe_actions+0x123>
    31a3:      	cmpl	$0x4, %r13d
    31a7:      	je	0x345e <generic_retuprobe_actions+0x4de>
    31ad:      	cmpl	$0x5, %r13d
    31b1:      	jne	0x30b0 <generic_retuprobe_actions+0x130>
    31b7:      	leal	0x1(%r15), %eax
    31bb:      	movl	0x4(%r14,%rax,4), %eax
    31c0:      	addl	$0x2, %r15d
    31c4:      	movl	0x4(%r14,%r15,4), %ebx
    31c9:      	movq	$0x0, 0x20(%rsp)
    31d2:      	movq	$0x0, 0x18(%rsp)
    31db:      	andl	$0x7, %eax
    31de:      	cmpl	$0x4, %eax
    31e1:      	ja	0x30b0 <generic_retuprobe_actions+0x130>
    31e7:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    31ef:      	jne	0x30b0 <generic_retuprobe_actions+0x130>
    31f5:      	movq	0x5e78(%rdx,%rax,8), %rax
    31fd:      	andl	$0x7ff, %eax            # imm = 0x7FF
    3202:      	movl	0x90(%rdx,%rax), %eax
    3209:      	movl	%eax, 0x20(%rsp)
    320d:      	movl	$0xe, %eax
    3212:      	movq	%rdx, 0x8(%rsp)
    3217:      	callq	*%rax
    3219:      	shrq	$0x20, %rax
    321d:      	movq	%rax, 0x18(%rsp)
    3222:      	movl	$0x1, %eax
    3227:      	leaq	0x18(%rsp), %rsi
    322c:      	movq	(%rip), %rdi            # 0x3233 <generic_retuprobe_actions+0x2b3>
    3233:      	callq	*%rax
    3235:      	movq	0x8(%rsp), %rdx
    323a:      	testq	%rax, %rax
    323d:      	je	0x30b0 <generic_retuprobe_actions+0x130>
    3243:      	andl	$0x7, %ebx
    3246:      	cmpl	$0x4, %ebx
    3249:      	ja	0x30b0 <generic_retuprobe_actions+0x130>
    324f:      	cmpl	$0x0, 0x5ea0(%rdx,%rbx,4)
    3257:      	jne	0x30b0 <generic_retuprobe_actions+0x130>
    325d:      	movq	0x5e78(%rdx,%rbx,8), %rcx
    3265:      	movl	$0x0, 0x24(%rsp)
    326d:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    3273:      	movl	0x90(%rdx,%rcx), %ecx
    327a:      	movl	%ecx, 0x20(%rsp)
    327e:      	movq	%rax, %rbx
    3281:      	movl	$0xe, %eax
    3286:      	callq	*%rax
    3288:      	shrq	$0x20, %rax
    328c:      	movq	%rax, 0x18(%rsp)
    3291:      	movl	$0x2, %eax
    3296:      	xorl	%ecx, %ecx
    3298:      	leaq	0x18(%rsp), %rsi
    329d:      	movq	(%rip), %rdi            # 0x32a4 <generic_retuprobe_actions+0x324>
    32a4:      	movq	%rbx, %rdx
    32a7:      	xorl	%ecx, %ecx
    32a9:      	callq	*%rax
    32ab:      	jmp	0x34ed <generic_retuprobe_actions+0x56d>
    32b0:      	cmpl	$0xc, %r13d
    32b4:      	je	0x35e4 <generic_retuprobe_actions+0x664>
    32ba:      	cmpl	$0xd, %r13d
    32be:      	je	0x3476 <generic_retuprobe_actions+0x4f6>
    32c4:      	cmpl	$0xe, %r13d
    32c8:      	jne	0x30b0 <generic_retuprobe_actions+0x130>
    32ce:      	movq	%r13, 0x8(%rsp)
    32d3:      	movq	%rbp, %r13
    32d6:      	movq	%rdx, %rbp
    32d9:      	addl	$0x2, %r15d
    32dd:      	movq	0x70(%rsp), %rbx
    32e2:      	jmp	0x35f8 <generic_retuprobe_actions+0x678>
    32e7:      	movl	$0x9, %eax
    32ec:      	cmpl	$0x2, %r13d
    32f0:      	je	0x35bc <generic_retuprobe_actions+0x63c>
    32f6:      	cmpl	$0x3, %r13d
    32fa:      	jne	0x30b0 <generic_retuprobe_actions+0x130>
    3300:      	movq	%rdx, 0x8(%rsp)
    3305:      	leal	0x1(%r15), %eax
    3309:      	movq	%r14, %rcx
    330c:      	movl	0x4(%r14,%rax,4), %r14d
    3311:      	addl	$0x2, %r15d
    3315:      	movq	%rcx, %rbp
    3318:      	movl	0x4(%rcx,%r15,4), %eax
    331d:      	movq	%rax, 0x38(%rsp)
    3322:      	movq	$0x0, 0x20(%rsp)
    332b:      	movq	$0x0, 0x18(%rsp)
    3334:      	movl	$0x0, 0x28(%rsp)
    333c:      	movl	$0x1, %eax
    3341:      	leaq	0x28(%rsp), %rsi
    3346:      	movq	(%rip), %rdi            # 0x334d <generic_retuprobe_actions+0x3cd>
    334d:      	callq	*%rax
    334f:      	xorl	%ecx, %ecx
    3351:      	testq	%rax, %rax
    3354:      	je	0x3788 <generic_retuprobe_actions+0x808>
    335a:      	andl	$0x7, %r14d
    335e:      	cmpl	$0x4, %r14d
    3362:      	movq	0x8(%rsp), %rdx
    3367:      	ja	0x3378 <generic_retuprobe_actions+0x3f8>
    3369:      	cmpl	$0x0, 0x5ea0(%rdx,%r14,4)
    3372:      	je	0x362d <generic_retuprobe_actions+0x6ad>
    3378:      	movq	%rbp, %r14
    337b:      	movq	(%rip), %rbp            # 0x3382 <generic_retuprobe_actions+0x402>
    3382:      	testl	%ecx, %ecx
    3384:      	jne	0x30ba <generic_retuprobe_actions+0x13a>
    338a:      	jmp	0x30b0 <generic_retuprobe_actions+0x130>
    338f:      	incl	%r15d
    3392:      	movl	0x4(%r14,%r15,4), %eax
    3397:      	andl	$0x7, %eax
    339a:      	xorl	%ecx, %ecx
    339c:      	cmpl	$0x4, %eax
    339f:      	ja	0x3797 <generic_retuprobe_actions+0x817>
    33a5:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    33ad:      	jne	0x3797 <generic_retuprobe_actions+0x817>
    33b3:      	movq	0x5e78(%rdx,%rax,8), %rax
    33bb:      	andl	$0x7ff, %eax            # imm = 0x7FF
    33c0:      	movq	0xb8(%rdx,%rax), %rax
    33c8:      	movq	%rax, 0x28(%rsp)
    33cd:      	testq	%rax, %rax
    33d0:      	je	0x3797 <generic_retuprobe_actions+0x817>
    33d6:      	movq	%rdx, 0x8(%rsp)
    33db:      	cmpl	$0xa, %r13d
    33df:      	jne	0x37a4 <generic_retuprobe_actions+0x824>
    33e5:      	movl	$0xe, %eax
    33ea:      	callq	*%rax
    33ec:      	movq	%rax, 0x38(%rsp)
    33f1:      	shrq	$0x20, %rax
    33f5:      	movl	%eax, 0x18(%rsp)
    33f9:      	movl	$0x1, %eax
    33fe:      	leaq	0x18(%rsp), %rsi
    3403:      	movq	(%rip), %rdi            # 0x340a <generic_retuprobe_actions+0x48a>
    340a:      	callq	*%rax
    340c:      	xorl	%ecx, %ecx
    340e:      	testq	%rax, %rax
    3411:      	movq	0x8(%rsp), %rdx
    3416:      	je	0x3797 <generic_retuprobe_actions+0x817>
    341c:      	movl	(%rax), %ecx
    341e:      	movl	%ecx, 0x18(%rsp)
    3422:      	movq	0x38(%rsp), %rcx
    3427:      	movl	%ecx, 0x1c(%rsp)
    342b:      	movq	0x8(%rax), %rax
    342f:      	movq	%rax, 0x20(%rsp)
    3434:      	xorl	%ecx, %ecx
    3436:      	movl	$0x2, %eax
    343b:      	leaq	0x28(%rsp), %rsi
    3440:      	leaq	0x18(%rsp), %rdx
    3445:      	movq	(%rip), %rdi            # 0x344c <generic_retuprobe_actions+0x4cc>
    344c:      	jmp	0x36f0 <generic_retuprobe_actions+0x770>
    3451:      	movl	$0x0, 0x44(%rsp)
    3459:      	jmp	0x30b0 <generic_retuprobe_actions+0x130>
    345e:      	movq	%r13, 0x8(%rsp)
    3463:      	movq	%rbp, %r13
    3466:      	movq	%rdx, %rbp
    3469:      	incl	%r15d
    346c:      	movq	0x78(%rsp), %rbx
    3471:      	jmp	0x35f8 <generic_retuprobe_actions+0x678>
    3476:      	movq	%rdx, 0x8(%rsp)
    347b:      	movl	$0xe, %eax
    3480:      	callq	*%rax
    3482:      	movq	%rax, 0x50(%rsp)
    3487:      	movl	$0x1, %eax
    348c:      	leaq	0x50(%rsp), %rsi
    3491:      	movq	(%rip), %rdi            # 0x3498 <generic_retuprobe_actions+0x518>
    3498:      	callq	*%rax
    349a:      	testq	%rax, %rax
    349d:      	je	0x34ed <generic_retuprobe_actions+0x56d>
    349f:      	movq	0x4(%rax), %rax
    34a3:      	movq	%rax, 0x28(%rsp)
    34a8:      	movl	$0x2, 0x30(%rsp)
    34b0:      	movl	$0x1, %eax
    34b5:      	leaq	0x28(%rsp), %rsi
    34ba:      	movq	(%rip), %rbx            # 0x34c1 <generic_retuprobe_actions+0x541>
    34c1:      	movq	%rbx, %rdi
    34c4:      	callq	*%rax
    34c6:      	movl	$0x1, 0x5c(%rsp)
    34ce:      	testq	%rax, %rax
    34d1:      	je	0x3708 <generic_retuprobe_actions+0x788>
    34d7:      	lock
    34d8:      	incl	(%rax)
    34da:      	movl	$0x3, %eax
    34df:      	leaq	0x50(%rsp), %rsi
    34e4:      	movq	(%rip), %rdi            # 0x34eb <generic_retuprobe_actions+0x56b>
    34eb:      	callq	*%rax
    34ed:      	movq	0x8(%rsp), %rdx
    34f2:      	jmp	0x30b0 <generic_retuprobe_actions+0x130>
    34f7:      	movq	%rdx, 0x8(%rsp)
    34fc:      	leal	0x1(%r15), %eax
    3500:      	movl	0x4(%r14,%rax,4), %ebx
    3505:      	leal	0x2(%r15), %eax
    3509:      	movl	0x4(%r14,%rax,4), %eax
    350e:      	movl	%eax, 0x60(%rsp)
    3512:      	movl	$0x7d, %eax
    3517:      	callq	*%rax
    3519:      	movq	%rax, 0x18(%rsp)
    351e:      	movl	$0x0, 0x50(%rsp)
    3526:      	movq	%rbx, 0xa0(%rsp)
    352e:      	testq	%rbx, %rbx
    3531:      	je	0x39a8 <generic_retuprobe_actions+0xa28>
    3537:      	movl	$0x1, %eax
    353c:      	movq	(%rip), %rdi            # 0x3543 <generic_retuprobe_actions+0x5c3>
    3543:      	leaq	0x50(%rsp), %rsi
    3548:      	callq	*%rax
    354a:      	testq	%rax, %rax
    354d:      	je	0x39a8 <generic_retuprobe_actions+0xa28>
    3553:      	movq	%rax, 0x48(%rsp)
    3558:      	movq	%rax, %rbx
    355b:      	movl	$0x1, %eax
    3560:      	leaq	0x50(%rsp), %rsi
    3565:      	movq	(%rip), %rdi            # 0x356c <generic_retuprobe_actions+0x5ec>
    356c:      	callq	*%rax
    356e:      	movq	%rax, %rdx
    3571:      	movq	0x8(%rsp), %rcx
    3576:      	movq	0x60(%rcx), %rax
    357a:      	movq	%rax, (%rbx)
    357d:      	movq	0x70(%rcx), %rax
    3581:      	movq	%rax, 0x8(%rbx)
    3585:      	xorl	%eax, %eax
    3587:      	movq	%rax, 0x38(%rsp)
    358c:      	movl	$0x0, %eax
    3591:      	movl	0x60(%rsp), %esi
    3595:      	cmpl	$0x2, %esi
    3598:      	je	0x37cf <generic_retuprobe_actions+0x84f>
    359e:      	cmpl	$0x1, %esi
    35a1:      	je	0x37cc <generic_retuprobe_actions+0x84c>
    35a7:      	testl	%esi, %esi
    35a9:      	jne	0x39a8 <generic_retuprobe_actions+0xa28>
    35af:      	movq	0x8(%rsp), %rax
    35b4:      	movl	0x7c(%rax), %eax
    35b7:      	jmp	0x37cf <generic_retuprobe_actions+0x84f>
    35bc:      	movq	%r13, 0x8(%rsp)
    35c1:      	movq	%rbp, %r13
    35c4:      	movq	%rdx, %rbp
    35c7:      	movl	$0x3, %ebx
    35cc:      	cmpb	$0x0, 0x17(%rsp)
    35d1:      	je	0x35f8 <generic_retuprobe_actions+0x678>
    35d3:      	movslq	%eax, %rdi
    35d6:      	movl	$0x6d, %eax
    35db:      	callq	*%rax
    35dd:      	movl	$0x2, %ebx
    35e2:      	jmp	0x35f8 <generic_retuprobe_actions+0x678>
    35e4:      	movq	%r13, 0x8(%rsp)
    35e9:      	movq	%rbp, %r13
    35ec:      	movq	%rdx, %rbp
    35ef:      	addl	$0x3, %r15d
    35f3:      	movq	0x68(%rsp), %rbx
    35f8:      	movl	$0x0, 0x18(%rsp)
    3600:      	movl	$0x1, %eax
    3605:      	leaq	0x18(%rsp), %rsi
    360a:      	movq	(%rip), %rdi            # 0x3611 <generic_retuprobe_actions+0x691>
    3611:      	callq	*%rax
    3613:      	testq	%rax, %rax
    3616:      	je	0x361d <generic_retuprobe_actions+0x69d>
    3618:      	lock
    3619:      	incq	(%rax,%rbx,8)
    361d:      	movq	%rbp, %rdx
    3620:      	movq	%r13, %rbp
    3623:      	movq	0x8(%rsp), %r13
    3628:      	jmp	0x30b0 <generic_retuprobe_actions+0x130>
    362d:      	movq	%rax, 0x48(%rsp)
    3632:      	movq	0x5e78(%rdx,%r14,8), %rax
    363a:      	movl	$0x0, 0x24(%rsp)
    3642:      	andl	$0x7ff, %eax            # imm = 0x7FF
    3647:      	movl	0x90(%rdx,%rax), %eax
    364e:      	movl	%eax, 0x20(%rsp)
    3652:      	movl	$0xe, %eax
    3657:      	callq	*%rax
    3659:      	shrq	$0x20, %rax
    365d:      	movq	%rax, 0x18(%rsp)
    3662:      	cmpl	$0x1, %r13d
    3666:      	jne	0x3772 <generic_retuprobe_actions+0x7f2>
    366c:      	movq	0x38(%rsp), %rax
    3671:      	andl	$0x7, %eax
    3674:      	cmpl	$0x4, %eax
    3677:      	movq	%rbp, %r14
    367a:      	movl	$0x0, %ecx
    367f:      	ja	0x378b <generic_retuprobe_actions+0x80b>
    3685:      	movq	0x8(%rsp), %rdx
    368a:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    3692:      	movq	(%rip), %rbp            # 0x3699 <generic_retuprobe_actions+0x719>
    3699:      	jne	0x3797 <generic_retuprobe_actions+0x817>
    369f:      	movq	0x5e78(%rdx,%rax,8), %rax
    36a7:      	andl	$0x7ff, %eax            # imm = 0x7FF
    36ac:      	addq	%rax, %rdx
    36af:      	addq	$0x90, %rdx
    36b6:      	movq	0x8(%rsp), %rcx
    36bb:      	movl	0x90(%rcx,%rax), %esi
    36c2:      	andl	$0xfff, %esi            # imm = 0xFFF
    36c8:      	addq	$0x8, %rsi
    36cc:      	movl	$0x4, %eax
    36d1:      	movq	0x48(%rsp), %rdi
    36d6:      	callq	*%rax
    36d8:      	xorl	%ecx, %ecx
    36da:      	movl	$0x2, %eax
    36df:      	leaq	0x18(%rsp), %rsi
    36e4:      	movq	(%rip), %rdi            # 0x36eb <generic_retuprobe_actions+0x76b>
    36eb:      	movq	0x48(%rsp), %rdx
    36f0:      	xorl	%ecx, %ecx
    36f2:      	callq	*%rax
    36f4:      	xorl	%ecx, %ecx
    36f6:      	movq	0x8(%rsp), %rdx
    36fb:      	testl	%ecx, %ecx
    36fd:      	jne	0x30ba <generic_retuprobe_actions+0x13a>
    3703:      	jmp	0x30b0 <generic_retuprobe_actions+0x130>
    3708:      	movl	$0x2, %eax
    370d:      	movl	$0x1, %ecx
    3712:      	leaq	0x5c(%rsp), %rdx
    3717:      	leaq	0x28(%rsp), %rsi
    371c:      	movq	%rbx, %rdi
    371f:      	callq	*%rax
    3721:      	testq	%rax, %rax
    3724:      	je	0x34da <generic_retuprobe_actions+0x55a>
    372a:      	movq	%rax, 0x38(%rsp)
    372f:      	negl	%eax
    3731:      	movw	%ax, 0x18(%rsp)
    3736:      	movw	$0x3, 0x1a(%rsp)
    373d:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    3747:      	movq	%rax, 0x1c(%rsp)
    374c:      	movl	$0x1, %eax
    3751:      	leaq	0x18(%rsp), %rsi
    3756:      	movq	(%rip), %rbx            # 0x375d <generic_retuprobe_actions+0x7dd>
    375d:      	movq	%rbx, %rdi
    3760:      	callq	*%rax
    3762:      	testq	%rax, %rax
    3765:      	je	0x3a28 <generic_retuprobe_actions+0xaa8>
    376b:      	incl	(%rax)
    376d:      	jmp	0x3a4e <generic_retuprobe_actions+0xace>
    3772:      	movl	$0x3, %eax
    3777:      	leaq	0x18(%rsp), %rsi
    377c:      	movq	(%rip), %rdi            # 0x3783 <generic_retuprobe_actions+0x803>
    3783:      	callq	*%rax
    3785:      	movq	%rax, %rcx
    3788:      	movq	%rbp, %r14
    378b:      	movq	(%rip), %rbp            # 0x3792 <generic_retuprobe_actions+0x812>
    3792:      	movq	0x8(%rsp), %rdx
    3797:      	testl	%ecx, %ecx
    3799:      	jne	0x30ba <generic_retuprobe_actions+0x13a>
    379f:      	jmp	0x30b0 <generic_retuprobe_actions+0x130>
    37a4:      	movl	$0x3, %eax
    37a9:      	leaq	0x28(%rsp), %rsi
    37ae:      	movq	(%rip), %rdi            # 0x37b5 <generic_retuprobe_actions+0x835>
    37b5:      	callq	*%rax
    37b7:      	movq	%rax, %rcx
    37ba:      	movq	0x8(%rsp), %rdx
    37bf:      	testl	%ecx, %ecx
    37c1:      	jne	0x30ba <generic_retuprobe_actions+0x13a>
    37c7:      	jmp	0x30b0 <generic_retuprobe_actions+0x130>
    37cc:      	movl	0x10(%rcx), %eax
    37cf:      	movq	%r14, 0x60(%rsp)
    37d4:      	movl	%eax, %eax
    37d6:      	movq	%rbx, 0x98(%rsp)
    37de:      	movq	%rax, 0x10(%rbx)
    37e2:      	movq	0x48(%rsp), %rdi
    37e7:      	addq	$0x18, %rdi
    37eb:      	movl	$0x4, %eax
    37f0:      	movl	$0xc8, %ecx
    37f5:      	movq	%rdi, 0x48(%rsp)
    37fa:      	movl	$0xc8, %esi
    37ff:      	callq	*%rax
    3801:      	xorl	%r14d, %r14d
    3804:      	leaq	0x28(%rsp), %rbx
    3809:      	jmp	0x3823 <generic_retuprobe_actions+0x8a3>
    380b:      	nopl	(%rax,%rax)
    3810:      	leaq	0x28(%rsp), %rbx
    3815:      	addq	$0x4, %r14
    3819:      	cmpq	$0x14, %r14
    381d:      	je	0x394b <generic_retuprobe_actions+0x9cb>
    3823:      	movl	$0x0, 0x28(%rsp)
    382b:      	movl	$0x1, %eax
    3830:      	movq	%rbp, %rdi
    3833:      	movq	%rbx, %rsi
    3836:      	callq	*%rax
    3838:      	testq	%rax, %rax
    383b:      	je	0x394b <generic_retuprobe_actions+0x9cb>
    3841:      	movq	%rax, %rsi
    3844:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    384b:      	movl	$0x1, %eax
    3850:      	movq	(%rip), %rdi            # 0x3857 <generic_retuprobe_actions+0x8d7>
    3857:      	callq	*%rax
    3859:      	testq	%rax, %rax
    385c:      	je	0x394b <generic_retuprobe_actions+0x9cb>
    3862:      	cmpl	$-0x1, 0x40(%rax,%r14)
    3868:      	movq	0x8(%rsp), %rdx
    386d:      	je	0x394b <generic_retuprobe_actions+0x9cb>
    3873:      	movq	0x5e78(%rdx,%r14,2), %rax
    387b:      	movl	0x4(%rdx), %ecx
    387e:      	cmpq	%rcx, %rax
    3881:      	jge	0x394b <generic_retuprobe_actions+0x9cb>
    3887:      	cmpq	$0x10, %r14
    388b:      	je	0x38f2 <generic_retuprobe_actions+0x972>
    388d:      	movl	$0x0, 0x28(%rsp)
    3895:      	movl	$0x1, %eax
    389a:      	movq	%rbp, %rdi
    389d:      	movq	%rbx, %rsi
    38a0:      	callq	*%rax
    38a2:      	testq	%rax, %rax
    38a5:      	je	0x38e5 <generic_retuprobe_actions+0x965>
    38a7:      	movq	%rax, %rsi
    38aa:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    38b1:      	movl	$0x1, %eax
    38b6:      	movq	(%rip), %rdi            # 0x38bd <generic_retuprobe_actions+0x93d>
    38bd:      	callq	*%rax
    38bf:      	testq	%rax, %rax
    38c2:      	je	0x38e5 <generic_retuprobe_actions+0x965>
    38c4:      	cmpl	$-0x1, 0x44(%rax,%r14)
    38ca:      	movq	0x8(%rsp), %rdx
    38cf:      	movq	0x5e78(%rdx,%r14,2), %rax
    38d7:      	je	0x38f2 <generic_retuprobe_actions+0x972>
    38d9:      	movl	0x5e80(%rdx,%r14,2), %ebx
    38e1:      	subl	%eax, %ebx
    38e3:      	jmp	0x38fa <generic_retuprobe_actions+0x97a>
    38e5:      	movq	0x8(%rsp), %rdx
    38ea:      	movq	0x5e78(%rdx,%r14,2), %rax
    38f2:      	movl	0x4(%rdx), %ebx
    38f5:      	subl	%eax, %ebx
    38f7:      	addl	$0x4, %ebx
    38fa:      	testl	%ebx, %ebx
    38fc:      	jle	0x3810 <generic_retuprobe_actions+0x890>
    3902:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    3907:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    390c:      	cmpl	$0x28, %ebx
    390f:      	movl	$0x28, %ecx
    3914:      	cmovgel	%ecx, %ebx
    3917:      	movzbl	0x38(%rsp), %ebp
    391c:      	movq	0x48(%rsp), %rcx
    3921:      	leaq	(%rcx,%rbp), %rdi
    3925:      	addq	%rax, %rdx
    3928:      	addq	$0x90, %rdx
    392f:      	movl	$0x4, %eax
    3934:      	movl	%ebx, %esi
    3936:      	callq	*%rax
    3938:      	addl	%ebp, %ebx
    393a:      	movq	(%rip), %rbp            # 0x3941 <generic_retuprobe_actions+0x9c1>
    3941:      	movq	%rbx, 0x38(%rsp)
    3946:      	jmp	0x3810 <generic_retuprobe_actions+0x890>
    394b:      	movl	$0x1, %eax
    3950:      	movq	(%rip), %rdi            # 0x3957 <generic_retuprobe_actions+0x9d7>
    3957:      	movq	0x98(%rsp), %rbx
    395f:      	movq	%rbx, %rsi
    3962:      	callq	*%rax
    3964:      	testq	%rax, %rax
    3967:      	movq	0x60(%rsp), %r14
    396c:      	je	0x398e <generic_retuprobe_actions+0xa0e>
    396e:      	imulq	$-0xf4240, 0xa0(%rsp), %rcx # imm = 0xFFF0BDC0
    397a:      	addq	0x18(%rsp), %rcx
    397f:      	cmpq	%rcx, (%rax)
    3982:      	jbe	0x398e <generic_retuprobe_actions+0xa0e>
    3984:      	movl	$0x0, 0x44(%rsp)
    398c:      	jmp	0x39a8 <generic_retuprobe_actions+0xa28>
    398e:      	movl	$0x2, %eax
    3993:      	xorl	%ecx, %ecx
    3995:      	movq	(%rip), %rdi            # 0x399c <generic_retuprobe_actions+0xa1c>
    399c:      	leaq	0x18(%rsp), %rdx
    39a1:      	movq	%rbx, %rsi
    39a4:      	xorl	%ecx, %ecx
    39a6:      	callq	*%rax
    39a8:      	leal	0x3(%r15), %eax
    39ac:      	cmpl	$0x0, 0x4(%r14,%rax,4)
    39b2:      	movq	0x8(%rsp), %rdx
    39b7:      	je	0x39e3 <generic_retuprobe_actions+0xa63>
    39b9:      	orb	$0x2, 0x1(%rdx)
    39bd:      	movl	$0x1b, %eax
    39c2:      	movq	0x80(%rsp), %rdi
    39ca:      	xorl	%ecx, %ecx
    39cc:      	movq	(%rip), %rsi            # 0x39d3 <generic_retuprobe_actions+0xa53>
    39d3:      	xorl	%edx, %edx
    39d5:      	callq	*%rax
    39d7:      	movq	0x8(%rsp), %rdx
    39dc:      	movq	%rax, 0x80(%rdx)
    39e3:      	addl	$0x4, %r15d
    39e7:      	cmpl	$0x0, 0x4(%r14,%r15,4)
    39ed:      	je	0x30b0 <generic_retuprobe_actions+0x130>
    39f3:      	orb	$0x4, 0x1(%rdx)
    39f7:      	movl	$0x1b, %eax
    39fc:      	movq	0x80(%rsp), %rdi
    3a04:      	movq	(%rip), %rsi            # 0x3a0b <generic_retuprobe_actions+0xa8b>
    3a0b:      	movl	$0x100, %ecx            # imm = 0x100
    3a10:      	movl	$0x100, %edx            # imm = 0x100
    3a15:      	callq	*%rax
    3a17:      	movq	0x8(%rsp), %rdx
    3a1c:      	movq	%rax, 0x88(%rdx)
    3a23:      	jmp	0x30b0 <generic_retuprobe_actions+0x130>
    3a28:      	movl	$0x1, 0x94(%rsp)
    3a33:      	movl	$0x2, %eax
    3a38:      	xorl	%ecx, %ecx
    3a3a:      	leaq	0x94(%rsp), %rdx
    3a42:      	leaq	0x18(%rsp), %rsi
    3a47:      	movq	%rbx, %rdi
    3a4a:      	xorl	%ecx, %ecx
    3a4c:      	callq	*%rax
    3a4e:      	cmpl	$0x0, 0x38(%rsp)
    3a53:      	je	0x34da <generic_retuprobe_actions+0x55a>
    3a59:      	movl	$0x1, %eax
    3a5e:      	leaq	0x28(%rsp), %rsi
    3a63:      	movq	(%rip), %rdi            # 0x3a6a <generic_retuprobe_actions+0xaea>
    3a6a:      	callq	*%rax
    3a6c:      	testq	%rax, %rax
    3a6f:      	je	0x34da <generic_retuprobe_actions+0x55a>
    3a75:      	movl	0x5c(%rsp), %ecx
    3a79:      	lock
    3a7a:      	addl	%ecx, (%rax)
    3a7c:      	jmp	0x34da <generic_retuprobe_actions+0x55a>
    3a81:      	cmpb	$0x0, 0x44(%rsp)
    3a86:      	je	0x3aa8 <generic_retuprobe_actions+0xb28>
    3a88:      	movq	(%rip), %rsi            # 0x3a8f <generic_retuprobe_actions+0xb0f>
    3a8f:      	movl	$0x5, %ecx
    3a94:      	movl	$0xc, %eax
    3a99:      	movq	0x80(%rsp), %rdi
    3aa1:      	movl	$0x5, %edx
    3aa6:      	callq	*%rax
    3aa8:      	xorl	%eax, %eax
    3aaa:      	addq	$0xa8, %rsp
    3ab1:      	popq	%rbx
    3ab2:      	popq	%r12
    3ab4:      	popq	%r13
    3ab6:      	popq	%r14
    3ab8:      	popq	%r15
    3aba:      	popq	%rbp
    3abb:      	retq
    3abc:      	nopl	(%rax)

0000000000003ac0 <generic_retuprobe_output>:
    3ac0:      	pushq	%rbx
    3ac1:      	subq	$0x10, %rsp
    3ac5:      	movq	%rdi, %rbx
    3ac8:      	movl	$0x0, 0x4(%rsp)
    3ad0:      	movq	(%rip), %rdi            # 0x3ad7 <generic_retuprobe_output+0x17>
    3ad7:      	leaq	0x4(%rsp), %rsi
    3adc:      	movl	$0x1, %eax
    3ae1:      	callq	*%rax
    3ae3:      	testq	%rax, %rax
    3ae6:      	je	0x3b90 <generic_retuprobe_output+0xd0>
    3aec:      	movq	%rax, %rcx
    3aef:      	movl	$0x90, %eax
    3af4:      	addl	0x4(%rcx), %eax
    3af7:      	andl	$0x7fff, %eax           # imm = 0x7FFF
    3afc:      	cmpl	$0x2328, %eax           # imm = 0x2328
    3b01:      	movl	$0x2328, %r8d           # imm = 0x2328
    3b07:      	cmovbl	%eax, %r8d
    3b0b:      	movq	(%rip), %rsi            # 0x3b12 <generic_retuprobe_output+0x52>
    3b12:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    3b17:      	movl	$0x19, %eax
    3b1c:      	movq	%rbx, %rdi
    3b1f:      	callq	*%rax
    3b21:      	testq	%rax, %rax
    3b24:      	js	0x3b4d <generic_retuprobe_output+0x8d>
    3b26:      	movl	$0x0, 0xc(%rsp)
    3b2e:      	movq	(%rip), %rdi            # 0x3b35 <generic_retuprobe_output+0x75>
    3b35:      	leaq	0xc(%rsp), %rsi
    3b3a:      	movl	$0x1, %eax
    3b3f:      	callq	*%rax
    3b41:      	testq	%rax, %rax
    3b44:      	je	0x3b90 <generic_retuprobe_output+0xd0>
    3b46:      	lock
    3b47:      	incq	0x8(%rax)
    3b4b:      	jmp	0x3b90 <generic_retuprobe_output+0xd0>
    3b4d:      	movq	%rax, %rbx
    3b50:      	movl	$0x0, 0x8(%rsp)
    3b58:      	movq	(%rip), %rdi            # 0x3b5f <generic_retuprobe_output+0x9f>
    3b5f:      	leaq	0x8(%rsp), %rsi
    3b64:      	movl	$0x1, %eax
    3b69:      	callq	*%rax
    3b6b:      	testq	%rax, %rax
    3b6e:      	je	0x3b90 <generic_retuprobe_output+0xd0>
    3b70:      	cmpq	$-0xc, %rbx
    3b74:      	jg	0x3b98 <generic_retuprobe_output+0xd8>
    3b76:      	cmpq	$-0x1c, %rbx
    3b7a:      	je	0x3bb2 <generic_retuprobe_output+0xf2>
    3b7c:      	cmpq	$-0x16, %rbx
    3b80:      	je	0x3bca <generic_retuprobe_output+0x10a>
    3b82:      	cmpq	$-0x10, %rbx
    3b86:      	jne	0x3bc2 <generic_retuprobe_output+0x102>
    3b88:      	addq	$0x360, %rax            # imm = 0x360
    3b8e:      	jmp	0x3bd8 <generic_retuprobe_output+0x118>
    3b90:      	xorl	%eax, %eax
    3b92:      	addq	$0x10, %rsp
    3b96:      	popq	%rbx
    3b97:      	retq
    3b98:      	cmpq	$-0xb, %rbx
    3b9c:      	je	0x3bba <generic_retuprobe_output+0xfa>
    3b9e:      	cmpq	$-0x7, %rbx
    3ba2:      	je	0x3bd2 <generic_retuprobe_output+0x112>
    3ba4:      	cmpq	$-0x2, %rbx
    3ba8:      	jne	0x3bc2 <generic_retuprobe_output+0x102>
    3baa:      	addq	$0x350, %rax            # imm = 0x350
    3bb0:      	jmp	0x3bd8 <generic_retuprobe_output+0x118>
    3bb2:      	addq	$0x370, %rax            # imm = 0x370
    3bb8:      	jmp	0x3bd8 <generic_retuprobe_output+0x118>
    3bba:      	addq	$0x378, %rax            # imm = 0x378
    3bc0:      	jmp	0x3bd8 <generic_retuprobe_output+0x118>
    3bc2:      	addq	$0x348, %rax            # imm = 0x348
    3bc8:      	jmp	0x3bd8 <generic_retuprobe_output+0x118>
    3bca:      	addq	$0x368, %rax            # imm = 0x368
    3bd0:      	jmp	0x3bd8 <generic_retuprobe_output+0x118>
    3bd2:      	addq	$0x358, %rax            # imm = 0x358
    3bd8:      	lock
    3bd9:      	incq	(%rax)
    3bdc:      	xorl	%eax, %eax
    3bde:      	addq	$0x10, %rsp
    3be2:      	popq	%rbx
    3be3:      	retq

Disassembly of section uprobe/generic_retuprobe:

0000000000000000 <generic_retuprobe_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xf8, %rsp
      11:      	movq	%rdi, %r12
      14:      	movq	0x50(%rdi), %rbx
      18:      	movl	$0x0, 0xe8(%rsp)
      23:      	movq	(%rip), %rdi            # 0x2a <generic_retuprobe_event+0x2a>
      2a:      	leaq	0xe8(%rsp), %rsi
      32:      	movl	$0x1, %eax
      37:      	callq	*%rax
      39:      	xorl	%ebp, %ebp
      3b:      	testq	%rax, %rax
      3e:      	je	0xf8e <generic_retuprobe_event+0xf8e>
      44:      	movq	%rax, %r15
      47:      	movq	%rax, %r13
      4a:      	leaq	0x5ef8(%rax), %rsi
      51:      	movl	$0x0, 0x5ef8(%r15)
      5c:      	movq	(%rip), %rdi            # 0x63 <generic_retuprobe_event+0x63>
      63:      	movl	$0x1, %eax
      68:      	callq	*%rax
      6a:      	testq	%rax, %rax
      6d:      	je	0xf8e <generic_retuprobe_event+0xf8e>
      73:      	movq	%rax, %r14
      76:      	movl	(%rax), %eax
      78:      	movq	%rax, 0x60(%r13)
      7c:      	movl	$0xe, %eax
      81:      	callq	*%rax
      83:      	cmpq	$-0x16, %rax
      87:      	jne	0xa9 <generic_retuprobe_event+0xa9>
      89:      	leaq	0x20(%r12), %rdx
      8e:      	leaq	0x38(%rsp), %rdi
      93:      	movl	$0x8, %ecx
      98:      	movl	$0x4, %eax
      9d:      	movl	$0x8, %esi
      a2:      	callq	*%rax
      a4:      	movq	0x38(%rsp), %rax
      a9:      	movq	%rax, 0x68(%r13)
      ad:      	movl	$0xe, %eax
      b2:      	callq	*%rax
      b4:      	movl	%eax, 0x7c(%r13)
      b8:      	movq	0x60(%r13), %rax
      bc:      	movq	0x68(%r13), %rcx
      c0:      	movq	%rax, 0x38(%rsp)
      c5:      	movq	%rcx, 0x40(%rsp)
      ca:      	movq	(%rip), %rdi            # 0xd1 <generic_retuprobe_event+0xd1>
      d1:      	leaq	0x38(%rsp), %rsi
      d6:      	movl	$0x1, %eax
      db:      	callq	*%rax
      dd:      	testq	%rax, %rax
      e0:      	je	0xf8e <generic_retuprobe_event+0xf8e>
      e6:      	movq	%r12, 0xc8(%rsp)
      ee:      	movq	%rbx, 0x10(%rsp)
      f3:      	movq	(%rax), %rbx
      f6:      	movq	0x8(%rax), %r12
      fa:      	movq	0x10(%rax), %rax
      fe:      	movq	%rax, 0xb0(%rsp)
     106:      	movq	(%rip), %rdi            # 0x10d <generic_retuprobe_event+0x10d>
     10d:      	leaq	0x38(%rsp), %rsi
     112:      	movl	$0x3, %eax
     117:      	callq	*%rax
     119:      	movq	%rbx, 0x90(%r13)
     120:      	movl	0x58(%r14), %eax
     124:      	movl	0x5c(%r14), %ebx
     128:      	testl	%ebx, %ebx
     12a:      	je	0x206 <generic_retuprobe_event+0x206>
     130:      	movl	%eax, 0x78(%rsp)
     134:      	movl	$0x0, 0x5ea0(%r13)
     13f:      	movl	$0x0, 0xec(%rsp)
     14a:      	movq	(%rip), %rdi            # 0x151 <generic_retuprobe_event+0x151>
     151:      	leaq	0xec(%rsp), %rsi
     159:      	movl	$0x1, %eax
     15e:      	callq	*%rax
     160:      	testq	%rax, %rax
     163:      	je	0x2fe <generic_retuprobe_event+0x2fe>
     169:      	movl	0x5ea0(%rax), %ecx
     16f:      	movl	%ecx, 0x98(%rax)
     175:      	movq	$0xc, 0x5e78(%rax)
     180:      	movl	$0x4, %ebp
     185:      	testl	%ecx, %ecx
     187:      	jne	0x300 <generic_retuprobe_event+0x300>
     18d:      	leaq	0x9c(%rax), %rbp
     194:      	movq	0x10(%rsp), %rcx
     199:      	movq	%rcx, 0x38(%rsp)
     19e:      	movq	$0x0, 0x80(%rsp)
     1aa:      	cmpl	$0x17, %ebx
     1ad:      	movq	%rax, 0x8(%rsp)
     1b2:      	movq	%r14, 0x98(%rsp)
     1ba:      	movq	%r15, 0x28(%rsp)
     1bf:      	jle	0x3c7 <generic_retuprobe_event+0x3c7>
     1c5:      	cmpl	$0x18, %ebx
     1c8:      	je	0x3e0 <generic_retuprobe_event+0x3e0>
     1ce:      	cmpl	$0x25, %ebx
     1d1:      	je	0x423 <generic_retuprobe_event+0x423>
     1d7:      	cmpl	$0x2a, %ebx
     1da:      	jne	0x9e4 <generic_retuprobe_event+0x9e4>
     1e0:      	movq	$0x0, 0xa0(%rsp)
     1ec:      	movq	0x10(%rsp), %rax
     1f1:      	movq	%rax, 0xa8(%rsp)
     1f9:      	leaq	0xa0(%rsp), %r14
     201:      	jmp	0x455 <generic_retuprobe_event+0x455>
     206:      	movl	$0x8, %ebp
     20b:      	movq	0x10(%rsp), %rbx
     210:      	addq	$0x90, %r15
     217:      	cmpl	$0x3, %eax
     21a:      	jne	0x322 <generic_retuprobe_event+0x322>
     220:      	movq	%r14, 0x98(%rsp)
     228:      	movq	%r15, 0x28(%rsp)
     22d:      	movl	$0x0, (%r15,%rbp)
     235:      	leaq	0x4(%rbp), %r14
     239:      	cmpq	$0x0, 0xb0(%rsp)
     242:      	je	0x3a2 <generic_retuprobe_event+0x3a2>
     248:      	movq	0xc8(%rsp), %r15
     250:      	leaq	0x38(%rsp), %rdi
     255:      	movl	$0x4, %ebx
     25a:      	movl	$0x10, %ecx
     25f:      	movl	$0x4, %eax
     264:      	movl	$0x10, %esi
     269:      	movq	%r12, %rdx
     26c:      	callq	*%rax
     26e:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     273:      	testl	%eax, %eax
     275:      	js	0xcba <generic_retuprobe_event+0xcba>
     27b:      	movq	%rbp, %rdx
     27e:      	movq	%r12, 0x30(%rsp)
     283:      	movq	0x40(%rsp), %rbp
     288:      	movq	0x10(%rsp), %rax
     28d:      	cmpq	%rax, %rbp
     290:      	movq	%rax, %r12
     293:      	cmovbq	%rbp, %r12
     297:      	testq	%rax, %rax
     29a:      	cmovneq	%r12, %rbp
     29e:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
     2a3:      	cmpq	$0xffe, %rbp            # imm = 0xFFE
     2aa:      	ja	0xcba <generic_retuprobe_event+0xcba>
     2b0:      	addq	$0xc, %rdx
     2b4:      	movq	0x28(%rsp), %rax
     2b9:      	movq	%rdx, 0x78(%rsp)
     2be:      	leaq	(%rax,%rdx), %rdi
     2c2:      	movq	0x38(%rsp), %rcx
     2c7:      	movl	$0x4, %eax
     2cc:      	movq	0x38(%rsp), %rdx
     2d1:      	movl	%ebp, %esi
     2d3:      	callq	*%rax
     2d5:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     2da:      	testl	%eax, %eax
     2dc:      	js	0xcba <generic_retuprobe_event+0xcba>
     2e2:      	movq	0x10(%rsp), %rax
     2e7:      	testq	%rax, %rax
     2ea:      	je	0xbe8 <generic_retuprobe_event+0xbe8>
     2f0:      	subq	%r12, %rax
     2f3:      	jne	0xbea <generic_retuprobe_event+0xbea>
     2f9:      	jmp	0x3ad <generic_retuprobe_event+0x3ad>
     2fe:      	xorl	%ebp, %ebp
     300:      	movq	0x10(%rsp), %rbx
     305:      	movl	0x78(%rsp), %eax
     309:      	addl	$0x8, %ebp
     30c:      	andl	$0x1fff, %ebp           # imm = 0x1FFF
     312:      	addq	$0x90, %r15
     319:      	cmpl	$0x3, %eax
     31c:      	je	0x220 <generic_retuprobe_event+0x220>
     322:      	cmpl	$0x2, %eax
     325:      	jne	0x395 <generic_retuprobe_event+0x395>
     327:      	movq	%r12, %rdx
     32a:      	movq	%r13, 0x18(%rsp)
     32f:      	movq	%r14, %r12
     332:      	movl	$0x0, (%r15,%rbp)
     33a:      	cmpq	$0xfff, %rbx            # imm = 0xFFF
     341:      	movl	$0xfff, %r14d           # imm = 0xFFF
     347:      	cmovbq	%rbx, %r14
     34b:      	leaq	(%r15,%rbp), %rdi
     34f:      	addq	$0xc, %rdi
     353:      	movl	$0x4, %eax
     358:      	movq	%rbx, %r13
     35b:      	leaq	0x4(%rbp), %rbx
     35f:      	addq	%rbp, %r15
     362:      	addq	$0x4, %r15
     366:      	movl	$0x4, %ebp
     36b:      	movl	%r14d, %esi
     36e:      	callq	*%rax
     370:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     375:      	testl	%eax, %eax
     377:      	js	0x387 <generic_retuprobe_event+0x387>
     379:      	movl	%r14d, 0x4(%r15)
     37d:      	addq	$0x8, %r14
     381:      	movl	%r13d, %ecx
     384:      	movq	%r14, %rbp
     387:      	addq	%rbx, %rbp
     38a:      	movl	%ecx, (%r15)
     38d:      	movq	%r12, %r14
     390:      	movq	0x18(%rsp), %r13
     395:      	movq	0xc8(%rsp), %rbx
     39d:      	jmp	0xcd4 <generic_retuprobe_event+0xcd4>
     3a2:      	movq	0xc8(%rsp), %r15
     3aa:      	xorl	%r12d, %r12d
     3ad:      	movq	0x28(%rsp), %rax
     3b2:      	movl	%r12d, (%rax,%r14)
     3b6:      	movl	%r12d, 0x4(%rax,%r14)
     3bb:      	addq	$0x8, %r12
     3bf:      	movq	%r12, %rbx
     3c2:      	jmp	0xcc3 <generic_retuprobe_event+0xcc3>
     3c7:      	cmpl	$0xf, %ebx
     3ca:      	je	0x91a <generic_retuprobe_event+0x91a>
     3d0:      	cmpl	$0x10, %ebx
     3d3:      	jne	0x9e4 <generic_retuprobe_event+0x9e4>
     3d9:      	leaq	0x20(%rsp), %r14
     3de:      	jmp	0x40d <generic_retuprobe_event+0x40d>
     3e0:      	leaq	0x20(%rsp), %r14
     3e5:      	movl	$0x8, %ecx
     3ea:      	movl	$0x4, %eax
     3ef:      	movq	0x10(%rsp), %rdx
     3f4:      	movq	0x38(%rsp), %rdx
     3f9:      	movq	%r14, %rdi
     3fc:      	movl	$0x8, %esi
     401:      	callq	*%rax
     403:      	movq	0x20(%rsp), %rax
     408:      	movq	%rax, 0x38(%rsp)
     40d:      	leaq	0x38(%rsp), %rdx
     412:      	movl	$0x8, %ecx
     417:      	movl	$0x4, %eax
     41c:      	leaq	0x20(%rsp), %rdi
     421:      	jmp	0x445 <generic_retuprobe_event+0x445>
     423:      	movq	0x10(%rsp), %rax
     428:      	leaq	0x40(%rax), %rcx
     42c:      	movq	%rcx, 0x38(%rsp)
     431:      	leaq	0x20(%rsp), %rdi
     436:      	movl	$0x8, %edx
     43b:      	movl	$0x4, %eax
     440:      	movq	0x38(%rsp), %rdx
     445:      	movl	$0x8, %esi
     44a:      	callq	*%rax
     44c:      	movq	0x20(%rsp), %r14
     451:      	addq	$0x40, %r14
     455:      	movq	%r12, 0x30(%rsp)
     45a:      	movl	$0x0, 0xbc(%rsp)
     465:      	movq	(%rip), %rdi            # 0x46c <generic_retuprobe_event+0x46c>
     46c:      	leaq	0xbc(%rsp), %rsi
     474:      	movl	$0x1, %eax
     479:      	callq	*%rax
     47b:      	testq	%rax, %rax
     47e:      	je	0x528 <generic_retuprobe_event+0x528>
     484:      	movq	%rax, %r12
     487:      	addq	$0x1000, %rax           # imm = 0x1000
     48d:      	movq	%rax, 0x18(%rsp)
     492:      	movl	$0x23, %eax
     497:      	callq	*%rax
     499:      	leaq	0xd50(%rax), %rdx
     4a0:      	leaq	0xd0(%rsp), %rdi
     4a8:      	movl	$0x8, %ecx
     4ad:      	movl	$0x4, %eax
     4b2:      	movl	$0x8, %esi
     4b7:      	callq	*%rax
     4b9:      	movq	0xd0(%rsp), %rbp
     4c1:      	leaq	0x8(%r14), %rdx
     4c5:      	leaq	0xd8(%rsp), %rdi
     4cd:      	movl	$0x8, %ecx
     4d2:      	movl	$0x4, %eax
     4d7:      	leaq	0x18(%rbp), %rcx
     4db:      	movq	%rcx, 0xf0(%rsp)
     4e3:      	movl	$0x8, %esi
     4e8:      	movq	%rdx, 0x90(%rsp)
     4f0:      	callq	*%rax
     4f2:      	movq	0xd8(%rsp), %r15
     4fa:      	leaq	0x10(%r15), %rdx
     4fe:      	leaq	0x38(%rsp), %rdi
     503:      	movl	$0x8, %ecx
     508:      	movl	$0x4, %eax
     50d:      	movl	$0x8, %esi
     512:      	callq	*%rax
     514:      	cmpq	$0x0, 0x38(%rsp)
     51a:      	movl	$0x1000, %ebx           # imm = 0x1000
     51f:      	je	0x546 <generic_retuprobe_event+0x546>
     521:      	movq	0x18(%rsp), %rcx
     526:      	jmp	0x598 <generic_retuprobe_event+0x598>
     528:      	xorl	%ebp, %ebp
     52a:      	movq	0x98(%rsp), %r14
     532:      	movq	0x28(%rsp), %r15
     537:      	movq	0x10(%rsp), %rbx
     53c:      	movq	0x30(%rsp), %r12
     541:      	jmp	0xbcb <generic_retuprobe_event+0xbcb>
     546:      	leaq	0x18(%r15), %rdx
     54a:      	leaq	0x38(%rsp), %rdi
     54f:      	movl	$0x8, %ecx
     554:      	movl	$0x4, %eax
     559:      	movl	$0x8, %esi
     55e:      	callq	*%rax
     560:      	cmpq	%r15, 0x38(%rsp)
     565:      	movq	0x18(%rsp), %rcx
     56a:      	je	0x598 <generic_retuprobe_event+0x598>
     56c:      	movq	%r12, %rcx
     56f:      	addq	$0xff6, %rcx            # imm = 0xFF6
     576:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
     580:      	movq	%rax, 0xff6(%r12)
     588:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
     593:      	movl	$0xff6, %ebx            # imm = 0xFF6
     598:      	movq	$0x0, 0x40(%rsp)
     5a1:      	movq	$0x0, 0x38(%rsp)
     5aa:      	movq	%r12, 0x48(%rsp)
     5af:      	movq	$0x0, 0x50(%rsp)
     5b8:      	movq	$0x0, 0x58(%rsp)
     5c1:      	movq	$0x0, 0x60(%rsp)
     5ca:      	movq	%rcx, 0x18(%rsp)
     5cf:      	movq	%rcx, 0x68(%rsp)
     5d4:      	movl	%ebx, 0x70(%rsp)
     5d8:      	movb	$0x0, 0x74(%rsp)
     5dd:      	addq	$0x20, %rbp
     5e1:      	leaq	0x38(%rsp), %rdi
     5e6:      	movl	$0x8, %r15d
     5ec:      	movl	$0x4, %eax
     5f1:      	leaq	0x40(%rsp), %rbx
     5f6:      	leaq	0x50(%rsp), %r12
     5fb:      	movl	$0x8, %esi
     600:      	movq	%rbp, %rdx
     603:      	callq	*%rax
     605:      	movl	$0x8, %ecx
     60a:      	movl	$0x4, %eax
     60f:      	movq	0xf0(%rsp), %rdx
     617:      	movq	%rbx, %rdi
     61a:      	movl	$0x8, %esi
     61f:      	callq	*%rax
     621:      	movl	$0x8, %ecx
     626:      	movl	$0x4, %eax
     62b:      	movq	0x90(%rsp), %rdx
     633:      	movq	%r12, %rdi
     636:      	movl	$0x8, %esi
     63b:      	callq	*%rax
     63d:      	movl	$0x8, %ecx
     642:      	movl	$0x4, %eax
     647:      	leaq	0x58(%rsp), %rdi
     64c:      	movl	$0x8, %esi
     651:      	movq	%r14, %rdx
     654:      	callq	*%rax
     656:      	movq	0x58(%rsp), %rax
     65b:      	addq	$-0x20, %rax
     65f:      	movq	%rax, 0x60(%rsp)
     664:      	movl	$0x80, %r12d
     66a:      	movq	0x50(%rsp), %r14
     66f:      	movq	0x58(%rsp), %rdx
     674:      	movq	0x60(%rsp), %rbp
     679:      	cmpq	0x38(%rsp), %r14
     67e:      	jne	0x68b <generic_retuprobe_event+0x68b>
     680:      	cmpq	0x40(%rsp), %rdx
     685:      	je	0x7ff <generic_retuprobe_event+0x7ff>
     68b:      	movl	$0x4, %eax
     690:      	leaq	0xc0(%rsp), %rdi
     698:      	movl	$0x8, %esi
     69d:      	callq	*%rax
     69f:      	cmpq	0xc0(%rsp), %r14
     6a7:      	je	0x7a8 <generic_retuprobe_event+0x7a8>
     6ad:      	leaq	0x18(%r14), %rbx
     6b1:      	movl	$0x4, %eax
     6b6:      	leaq	0x20(%rsp), %rdi
     6bb:      	movl	$0x8, %esi
     6c0:      	movq	%rbx, %rdx
     6c3:      	callq	*%rax
     6c5:      	cmpq	%r14, 0x20(%rsp)
     6ca:      	je	0x7a8 <generic_retuprobe_event+0x7a8>
     6d0:      	movl	$0x4, %eax
     6d5:      	leaq	0xe0(%rsp), %rdi
     6dd:      	movl	$0x8, %esi
     6e2:      	movq	%rbx, %rdx
     6e5:      	callq	*%rax
     6e7:      	addq	$0x20, %r14
     6eb:      	movl	$0x4, %eax
     6f0:      	leaq	0x80(%rsp), %rdi
     6f8:      	movl	$0x10, %ecx
     6fd:      	movl	$0x10, %esi
     702:      	movq	%r14, %rdx
     705:      	callq	*%rax
     707:      	movq	0x48(%rsp), %rbx
     70c:      	movq	0x68(%rsp), %rax
     711:      	movl	0x84(%rsp), %ebp
     718:      	subq	%rbx, %rax
     71b:      	movl	0x70(%rsp), %r14d
     720:      	movl	%ebp, %edx
     722:      	subl	%r14d, %edx
     725:      	movl	$0x0, %ecx
     72a:      	cmovbl	%ecx, %edx
     72d:      	addq	0x88(%rsp), %rdx
     735:      	xorl	%esi, %esi
     737:      	cmpl	%ebp, %r14d
     73a:      	seta	%sil
     73e:      	movl	%ebp, %ecx
     740:      	cmovbl	%r14d, %ecx
     744:      	addl	%ecx, %esi
     746:      	movl	%r14d, %edi
     749:      	subl	%esi, %edi
     74b:      	movl	%edi, 0x70(%rsp)
     74f:      	subq	%rsi, %rax
     752:      	jb	0x804 <generic_retuprobe_event+0x804>
     758:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     75e:      	ja	0x804 <generic_retuprobe_event+0x804>
     764:      	cmpl	%ebp, %r14d
     767:      	jbe	0x76d <generic_retuprobe_event+0x76d>
     769:      	movb	$0x2f, (%rbx,%rax)
     76d:      	xorl	%edi, %edi
     76f:      	cmpl	%ebp, %r14d
     772:      	seta	%dil
     776:      	movzbl	%cl, %esi
     779:      	addq	%rax, %rbx
     77c:      	addq	%rbx, %rdi
     77f:      	movl	$0x4, %eax
     784:      	callq	*%rax
     786:      	movq	%rbx, 0x68(%rsp)
     78b:      	cmpl	%ebp, %r14d
     78e:      	jbe	0x804 <generic_retuprobe_event+0x804>
     790:      	movq	0xe0(%rsp), %rax
     798:      	movq	%rax, 0x50(%rsp)
     79d:      	decl	%r12d
     7a0:      	jne	0x66a <generic_retuprobe_event+0x66a>
     7a6:      	jmp	0x804 <generic_retuprobe_event+0x804>
     7a8:      	leaq	0x10(%rbp), %rdx
     7ac:      	movl	$0x4, %eax
     7b1:      	leaq	0x20(%rsp), %rdi
     7b6:      	movl	$0x8, %esi
     7bb:      	callq	*%rax
     7bd:      	movq	0x60(%rsp), %rax
     7c2:      	cmpq	0x20(%rsp), %rax
     7c7:      	je	0x7ff <generic_retuprobe_event+0x7ff>
     7c9:      	addq	$0x18, %rbp
     7cd:      	movl	$0x4, %eax
     7d2:      	leaq	0x50(%rsp), %rdi
     7d7:      	movl	$0x8, %esi
     7dc:      	movq	%rbp, %rdx
     7df:      	callq	*%rax
     7e1:      	movq	0x20(%rsp), %rax
     7e6:      	movq	%rax, 0x60(%rsp)
     7eb:      	addq	$0x20, %rax
     7ef:      	movq	%rax, 0x58(%rsp)
     7f4:      	decl	%r12d
     7f7:      	jne	0x66a <generic_retuprobe_event+0x66a>
     7fd:      	jmp	0x804 <generic_retuprobe_event+0x804>
     7ff:      	movb	$0x1, 0x74(%rsp)
     804:      	movq	0x68(%rsp), %rax
     809:      	movq	0x18(%rsp), %rdx
     80e:      	cmpq	%rdx, %rax
     811:      	movq	0x98(%rsp), %r14
     819:      	je	0x856 <generic_retuprobe_event+0x856>
     81b:      	xorl	%ebx, %ebx
     81d:      	cmpb	$0x0, 0x74(%rsp)
     822:      	sete	%cl
     825:      	movl	0x70(%rsp), %edx
     829:      	movl	$0x1000, %ebp           # imm = 0x1000
     82e:      	subl	%edx, %ebp
     830:      	testl	%edx, %edx
     832:      	cmovlel	%edx, %ebp
     835:      	testq	%rax, %rax
     838:      	movq	0x8(%rsp), %rdi
     83d:      	movq	0x28(%rsp), %r15
     842:      	movq	0x30(%rsp), %r12
     847:      	je	0xbc4 <generic_retuprobe_event+0xbc4>
     84d:      	movb	%cl, %bl
     84f:      	addl	%ebx, %ebx
     851:      	movq	%rax, %rdx
     854:      	jmp	0x869 <generic_retuprobe_event+0x869>
     856:      	xorl	%ebx, %ebx
     858:      	xorl	%ebp, %ebp
     85a:      	movq	0x8(%rsp), %rdi
     85f:      	movq	0x28(%rsp), %r15
     864:      	movq	0x30(%rsp), %r12
     869:      	addq	$0xa0, %rdi
     870:      	andl	$0xfff, %ebp            # imm = 0xFFF
     876:      	movl	$0x4, %eax
     87b:      	movl	%ebp, %esi
     87d:      	callq	*%rax
     87f:      	movq	0x8(%rsp), %rax
     884:      	movl	%ebp, 0x9c(%rax)
     88a:      	leaq	0x38(%rsp), %rdi
     88f:      	movl	$0x8, %ecx
     894:      	movl	$0x4, %eax
     899:      	movq	0x90(%rsp), %rdx
     8a1:      	movl	$0x8, %esi
     8a6:      	callq	*%rax
     8a8:      	movq	0x38(%rsp), %rcx
     8ad:      	addq	$0x30, %rcx
     8b1:      	leaq	0x80(%rsp), %rdi
     8b9:      	movl	$0x8, %edx
     8be:      	movl	$0x4, %eax
     8c3:      	movq	0x38(%rsp), %rdx
     8c8:      	addq	$0x30, %rdx
     8cc:      	movl	$0x8, %esi
     8d1:      	callq	*%rax
     8d3:      	movq	0x80(%rsp), %rcx
     8db:      	leaq	0x20(%rsp), %rdi
     8e0:      	movl	$0x2, %edx
     8e5:      	movl	$0x4, %eax
     8ea:      	movq	0x80(%rsp), %rdx
     8f2:      	movl	$0x2, %esi
     8f7:      	callq	*%rax
     8f9:      	movq	0x8(%rsp), %rcx
     8fe:      	movl	%ebx, 0xa0(%rcx,%rbp)
     905:      	movzwl	0x20(%rsp), %eax
     90a:      	movw	%ax, 0xa4(%rcx,%rbp)
     912:      	addl	$0xa, %ebp
     915:      	jmp	0x2e40 <generic_retuprobe_event+0x2e40>
     91a:      	leaq	0x80(%rsp), %rdi
     922:      	leaq	0x38(%rsp), %rdx
     927:      	movl	$0x8, %ecx
     92c:      	movl	$0x4, %eax
     931:      	movl	$0x8, %esi
     936:      	callq	*%rax
     938:      	movq	0x80(%rsp), %r14
     940:      	testq	%r14, %r14
     943:      	jne	0x455 <generic_retuprobe_event+0x455>
     949:      	movl	$0x0, 0xa0(%rsp)
     954:      	movq	(%rip), %rdi            # 0x95b <generic_retuprobe_event+0x95b>
     95b:      	leaq	0xa0(%rsp), %rsi
     963:      	movl	$0x1, %eax
     968:      	callq	*%rax
     96a:      	testq	%rax, %rax
     96d:      	je	0xbd4 <generic_retuprobe_event+0xbd4>
     973:      	movq	%rbp, 0x90(%rsp)
     97b:      	xorl	%ebp, %ebp
     97d:      	cmpl	$0x19, %ebx
     980:      	movq	0x8(%rsp), %rcx
     985:      	movq	0x98(%rsp), %r14
     98d:      	movq	0x28(%rsp), %r15
     992:      	jg	0x10be <generic_retuprobe_event+0x10be>
     998:      	cmpl	$0x12, %ebx
     99b:      	jle	0x10f9 <generic_retuprobe_event+0x10f9>
     9a1:      	cmpl	$0x14, %ebx
     9a4:      	jle	0x1535 <generic_retuprobe_event+0x1535>
     9aa:      	cmpl	$0x15, %ebx
     9ad:      	je	0x1e71 <generic_retuprobe_event+0x1e71>
     9b3:      	cmpl	$0x16, %ebx
     9b6:      	je	0x1dd1 <generic_retuprobe_event+0x1dd1>
     9bc:      	cmpl	$0x17, %ebx
     9bf:      	movq	0x10(%rsp), %rbx
     9c4:      	jne	0x2e45 <generic_retuprobe_event+0x2e45>
     9ca:      	movl	$0x0, 0xa0(%rcx)
     9d4:      	movl	%ebx, 0x9c(%rcx)
     9da:      	movl	$0x8, %ebp
     9df:      	jmp	0x2e45 <generic_retuprobe_event+0x2e45>
     9e4:      	cmpl	$0x28, %ebx
     9e7:      	ja	0x949 <generic_retuprobe_event+0x949>
     9ed:      	movl	%ebx, %eax
     9ef:      	movabsq	$0x1c1f2027cf2, %rcx    # imm = 0x1C1F2027CF2
     9f9:      	btq	%rax, %rcx
     9fd:      	jae	0x949 <generic_retuprobe_event+0x949>
     a03:      	movq	0x10(%rsp), %rax
     a08:      	movq	%rax, 0x20(%rsp)
     a0d:      	movl	$0x0, 0xe0(%rsp)
     a18:      	movq	(%rip), %rdi            # 0xa1f <generic_retuprobe_event+0xa1f>
     a1f:      	leaq	0xe0(%rsp), %rsi
     a27:      	movl	$0x1, %eax
     a2c:      	callq	*%rax
     a2e:      	testq	%rax, %rax
     a31:      	je	0xbd4 <generic_retuprobe_event+0xbd4>
     a37:      	movq	%rbp, %r15
     a3a:      	xorl	%ebp, %ebp
     a3c:      	cmpl	$0x10, %ebx
     a3f:      	jg	0xfa2 <generic_retuprobe_event+0xfa2>
     a45:      	cmpl	$0x9, %ebx
     a48:      	movq	0x98(%rsp), %r14
     a50:      	jg	0xfe1 <generic_retuprobe_event+0xfe1>
     a56:      	cmpl	$0x4, %ebx
     a59:      	movq	0x8(%rsp), %rcx
     a5e:      	jle	0x112e <generic_retuprobe_event+0x112e>
     a64:      	cmpl	$0x5, %ebx
     a67:      	je	0x1706 <generic_retuprobe_event+0x1706>
     a6d:      	cmpl	$0x6, %ebx
     a70:      	je	0x1048 <generic_retuprobe_event+0x1048>
     a76:      	movq	%rax, 0x18(%rsp)
     a7b:      	cmpl	$0x7, %ebx
     a7e:      	jne	0x2e3b <generic_retuprobe_event+0x2e3b>
     a84:      	movq	%r12, 0x30(%rsp)
     a89:      	movq	0x20(%rsp), %r12
     a8e:      	movq	%r12, 0xc4(%rcx)
     a95:      	leaq	0xc2(%rcx), %rdi
     a9c:      	leaq	0x10(%r12), %rdx
     aa1:      	movl	$0x2, %esi
     aa6:      	movq	%rcx, %rbx
     aa9:      	movl	$0x4, %eax
     aae:      	movl	$0x2, %esi
     ab3:      	callq	*%rax
     ab5:      	leaq	0xd6(%rbx), %rdi
     abc:      	leaq	0x12(%r12), %rdx
     ac1:      	movl	$0x1, %ecx
     ac6:      	movl	$0x4, %eax
     acb:      	movl	$0x1, %esi
     ad0:      	callq	*%rax
     ad2:      	leaq	0xd4(%rbx), %rdi
     ad9:      	leaq	0x226(%r12), %rdx
     ae1:      	movl	$0x2, %ecx
     ae6:      	movl	$0x4, %eax
     aeb:      	movl	$0x2, %esi
     af0:      	callq	*%rax
     af2:      	leaq	0xc0(%rbx), %rdi
     af9:      	leaq	0x224(%r12), %rdx
     b01:      	movl	$0x2, %ecx
     b06:      	movl	$0x4, %eax
     b0b:      	movl	$0x2, %esi
     b10:      	callq	*%rax
     b12:      	leaq	0xcc(%rbx), %rdi
     b19:      	leaq	0x21c(%r12), %rdx
     b21:      	movl	$0x4, %ecx
     b26:      	movl	$0x4, %eax
     b2b:      	movl	$0x4, %esi
     b30:      	callq	*%rax
     b32:      	leaq	0xd0(%rbx), %rdi
     b39:      	leaq	0x218(%r12), %rdx
     b41:      	movl	$0x4, %ecx
     b46:      	movl	$0x4, %eax
     b4b:      	movl	$0x4, %esi
     b50:      	callq	*%rax
     b52:      	leaq	0xac(%rbx), %r14
     b59:      	movq	$0x0, (%r15)
     b60:      	movq	$0x0, 0x8(%r15)
     b68:      	movq	$0x0, 0x10(%r15)
     b70:      	movq	$0x0, 0x18(%r15)
     b78:      	movzwl	0xc2(%rbx), %eax
     b7f:      	cmpl	$0xa, %eax
     b82:      	je	0x219a <generic_retuprobe_event+0x219a>
     b88:      	cmpl	$0x2, %eax
     b8b:      	jne	0x21cc <generic_retuprobe_event+0x21cc>
     b91:      	leaq	0x4(%r12), %rdx
     b96:      	movl	$0x4, %ecx
     b9b:      	movl	$0x4, %eax
     ba0:      	movq	%r15, %rdi
     ba3:      	movl	$0x4, %esi
     ba8:      	callq	*%rax
     baa:      	movl	$0x4, %ecx
     baf:      	movl	$0x4, %eax
     bb4:      	movq	%r14, %rdi
     bb7:      	movl	$0x4, %esi
     bbc:      	movq	%r12, %rdx
     bbf:      	jmp	0x21ca <generic_retuprobe_event+0x21ca>
     bc4:      	xorl	%ebp, %ebp
     bc6:      	movq	0x10(%rsp), %rbx
     bcb:      	movl	0x78(%rsp), %eax
     bcf:      	jmp	0x2e4d <generic_retuprobe_event+0x2e4d>
     bd4:      	xorl	%ebp, %ebp
     bd6:      	movq	0x8(%rsp), %rcx
     bdb:      	movq	0x98(%rsp), %r14
     be3:      	jmp	0x2e3b <generic_retuprobe_event+0x2e3b>
     be8:      	xorl	%eax, %eax
     bea:      	cmpq	$0x1, 0xb0(%rsp)
     bf3:      	jne	0xbfd <generic_retuprobe_event+0xbfd>
     bf5:      	movq	%rbp, %r12
     bf8:      	jmp	0x3ad <generic_retuprobe_event+0x3ad>
     bfd:      	movq	%rax, 0x10(%rsp)
     c02:      	movq	0x30(%rsp), %rax
     c07:      	leaq	0x10(%rax), %rdx
     c0b:      	leaq	0x38(%rsp), %rdi
     c10:      	movl	$0x4, %ebx
     c15:      	movl	$0x10, %ecx
     c1a:      	movl	$0x4, %eax
     c1f:      	movl	$0x10, %esi
     c24:      	callq	*%rax
     c26:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     c2b:      	testl	%eax, %eax
     c2d:      	js	0xcba <generic_retuprobe_event+0xcba>
     c33:      	movq	0x40(%rsp), %rsi
     c38:      	movq	0x10(%rsp), %rax
     c3d:      	cmpq	%rax, %rsi
     c40:      	movq	%rax, %r12
     c43:      	cmovbq	%rsi, %r12
     c47:      	testq	%rax, %rax
     c4a:      	cmovneq	%r12, %rsi
     c4e:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
     c53:      	cmpq	$0xffe, %rsi            # imm = 0xFFE
     c5a:      	ja	0xcba <generic_retuprobe_event+0xcba>
     c5c:      	movq	0x78(%rsp), %rcx
     c61:      	addq	%rbp, %rcx
     c64:      	movq	0x28(%rsp), %rax
     c69:      	movq	%rcx, 0x78(%rsp)
     c6e:      	leaq	(%rax,%rcx), %rdi
     c72:      	movq	0x38(%rsp), %rcx
     c77:      	movl	$0x4, %eax
     c7c:      	movq	0x38(%rsp), %rdx
     c81:      	movq	%rsi, 0x8(%rsp)
     c86:      	movq	0x8(%rsp), %rsi
     c8b:      	callq	*%rax
     c8d:      	movq	0x8(%rsp), %rdx
     c92:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     c97:      	testl	%eax, %eax
     c99:      	js	0xcba <generic_retuprobe_event+0xcba>
     c9b:      	addq	%rdx, %rbp
     c9e:      	movq	0x10(%rsp), %rax
     ca3:      	testq	%rax, %rax
     ca6:      	je	0x19ed <generic_retuprobe_event+0x19ed>
     cac:      	subq	%r12, %rax
     caf:      	jne	0x19ef <generic_retuprobe_event+0x19ef>
     cb5:      	jmp	0xbf5 <generic_retuprobe_event+0xbf5>
     cba:      	movq	0x28(%rsp), %rax
     cbf:      	movl	%ecx, (%rax,%r14)
     cc3:      	addq	%r14, %rbx
     cc6:      	movq	%rbx, %rbp
     cc9:      	movq	%r15, %rbx
     ccc:      	movq	0x98(%rsp), %r14
     cd4:      	movl	$0x23, %eax
     cd9:      	callq	*%rax
     cdb:      	movq	%rax, %rcx
     cde:      	movq	%rax, 0x38(%rsp)
     ce3:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     cea:      	leaq	0xa0(%rsp), %rdi
     cf2:      	movl	$0x4, %edx
     cf7:      	movl	$0x71, %eax
     cfc:      	movl	$0xaf4, %edx            # imm = 0xAF4
     d01:      	addq	0x38(%rsp), %rdx
     d06:      	movl	$0x4, %esi
     d0b:      	callq	*%rax
     d0d:      	movl	0xa0(%rsp), %eax
     d14:      	movl	%eax, 0x80(%rsp)
     d1b:      	movq	(%rip), %rdi            # 0xd22 <generic_retuprobe_event+0xd22>
     d22:      	leaq	0x80(%rsp), %rsi
     d2a:      	movl	$0x1, %eax
     d2f:      	callq	*%rax
     d31:      	testq	%rax, %rax
     d34:      	je	0xd44 <generic_retuprobe_event+0xd44>
     d36:      	movq	%rax, %r15
     d39:      	cmpq	$0x0, 0x8(%rax)
     d3e:      	jne	0xf30 <generic_retuprobe_event+0xf30>
     d44:      	movl	$0xb00, %edx            # imm = 0xB00
     d49:      	movq	0x38(%rsp), %rcx
     d4e:      	addq	%rdx, %rcx
     d51:      	leaq	0x38(%rsp), %rdi
     d56:      	movl	$0x8, %esi
     d5b:      	movl	$0x71, %eax
     d60:      	addq	0x38(%rsp), %rdx
     d65:      	movl	$0x8, %esi
     d6a:      	callq	*%rax
     d6c:      	movq	0x38(%rsp), %rcx
     d71:      	testq	%rcx, %rcx
     d74:      	je	0xf2d <generic_retuprobe_event+0xf2d>
     d7a:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     d81:      	leaq	0xa0(%rsp), %rdi
     d89:      	movl	$0x4, %edx
     d8e:      	movl	$0x71, %eax
     d93:      	movl	$0xaf4, %edx            # imm = 0xAF4
     d98:      	addq	0x38(%rsp), %rdx
     d9d:      	movl	$0x4, %esi
     da2:      	callq	*%rax
     da4:      	movl	0xa0(%rsp), %eax
     dab:      	movl	%eax, 0x80(%rsp)
     db2:      	movq	(%rip), %rdi            # 0xdb9 <generic_retuprobe_event+0xdb9>
     db9:      	leaq	0x80(%rsp), %rsi
     dc1:      	movl	$0x1, %eax
     dc6:      	callq	*%rax
     dc8:      	testq	%rax, %rax
     dcb:      	je	0xddb <generic_retuprobe_event+0xddb>
     dcd:      	movq	%rax, %r15
     dd0:      	cmpq	$0x0, 0x8(%rax)
     dd5:      	jne	0xf30 <generic_retuprobe_event+0xf30>
     ddb:      	movl	$0xb00, %edx            # imm = 0xB00
     de0:      	movq	0x38(%rsp), %rcx
     de5:      	addq	%rdx, %rcx
     de8:      	leaq	0x38(%rsp), %rdi
     ded:      	movl	$0x8, %esi
     df2:      	movl	$0x71, %eax
     df7:      	addq	0x38(%rsp), %rdx
     dfc:      	movl	$0x8, %esi
     e01:      	callq	*%rax
     e03:      	movq	0x38(%rsp), %rcx
     e08:      	testq	%rcx, %rcx
     e0b:      	je	0xf2d <generic_retuprobe_event+0xf2d>
     e11:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     e18:      	leaq	0xa0(%rsp), %rdi
     e20:      	movl	$0x4, %edx
     e25:      	movl	$0x71, %eax
     e2a:      	movl	$0xaf4, %edx            # imm = 0xAF4
     e2f:      	addq	0x38(%rsp), %rdx
     e34:      	movl	$0x4, %esi
     e39:      	callq	*%rax
     e3b:      	movl	0xa0(%rsp), %eax
     e42:      	movl	%eax, 0x80(%rsp)
     e49:      	movq	(%rip), %rdi            # 0xe50 <generic_retuprobe_event+0xe50>
     e50:      	leaq	0x80(%rsp), %rsi
     e58:      	movl	$0x1, %eax
     e5d:      	callq	*%rax
     e5f:      	testq	%rax, %rax
     e62:      	je	0xe72 <generic_retuprobe_event+0xe72>
     e64:      	movq	%rax, %r15
     e67:      	cmpq	$0x0, 0x8(%rax)
     e6c:      	jne	0xf30 <generic_retuprobe_event+0xf30>
     e72:      	movl	$0xb00, %edx            # imm = 0xB00
     e77:      	movq	0x38(%rsp), %rcx
     e7c:      	addq	%rdx, %rcx
     e7f:      	leaq	0x38(%rsp), %rdi
     e84:      	movl	$0x8, %esi
     e89:      	movl	$0x71, %eax
     e8e:      	addq	0x38(%rsp), %rdx
     e93:      	movl	$0x8, %esi
     e98:      	callq	*%rax
     e9a:      	movq	0x38(%rsp), %rcx
     e9f:      	testq	%rcx, %rcx
     ea2:      	je	0xf2d <generic_retuprobe_event+0xf2d>
     ea8:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     eaf:      	leaq	0xa0(%rsp), %rdi
     eb7:      	movl	$0x4, %edx
     ebc:      	movl	$0x71, %eax
     ec1:      	movl	$0xaf4, %edx            # imm = 0xAF4
     ec6:      	addq	0x38(%rsp), %rdx
     ecb:      	movl	$0x4, %esi
     ed0:      	callq	*%rax
     ed2:      	movl	0xa0(%rsp), %eax
     ed9:      	movl	%eax, 0x80(%rsp)
     ee0:      	movq	(%rip), %rdi            # 0xee7 <generic_retuprobe_event+0xee7>
     ee7:      	leaq	0x80(%rsp), %rsi
     eef:      	movl	$0x1, %eax
     ef4:      	callq	*%rax
     ef6:      	testq	%rax, %rax
     ef9:      	je	0xf05 <generic_retuprobe_event+0xf05>
     efb:      	movq	%rax, %r15
     efe:      	cmpq	$0x0, 0x8(%rax)
     f03:      	jne	0xf30 <generic_retuprobe_event+0xf30>
     f05:      	movl	$0xb00, %edx            # imm = 0xB00
     f0a:      	movq	0x38(%rsp), %rcx
     f0f:      	addq	%rdx, %rcx
     f12:      	leaq	0x38(%rsp), %rdi
     f17:      	movl	$0x8, %esi
     f1c:      	movl	$0x71, %eax
     f21:      	addq	0x38(%rsp), %rdx
     f26:      	movl	$0x8, %esi
     f2b:      	callq	*%rax
     f2d:      	xorl	%r15d, %r15d
     f30:      	movl	$0x10f, (%r13)          # imm = 0x10F
     f38:      	movl	%ebp, 0x4(%r13)
     f3c:      	movl	$0x7d, %eax
     f41:      	callq	*%rax
     f43:      	movq	%rax, 0x8(%r13)
     f47:      	testq	%r15, %r15
     f4a:      	je	0xf5b <generic_retuprobe_event+0xf5b>
     f4c:      	movl	(%r15), %eax
     f4f:      	movl	%eax, 0x10(%r13)
     f53:      	movq	0x8(%r15), %rax
     f57:      	movq	%rax, 0x18(%r13)
     f5b:      	movl	$0x0, 0x14(%r13)
     f63:      	movl	(%r14), %eax
     f66:      	movq	%rax, 0x60(%r13)
     f6a:      	movl	%ebp, 0x4(%r13)
     f6e:      	movq	(%rip), %rsi            # 0xf75 <generic_retuprobe_event+0xf75>
     f75:      	movl	$0x3, %ecx
     f7a:      	movl	$0xc, %eax
     f7f:      	movq	%rbx, %rdi
     f82:      	movl	$0x3, %edx
     f87:      	callq	*%rax
     f89:      	movl	$0x1, %ebp
     f8e:      	movl	%ebp, %eax
     f90:      	addq	$0xf8, %rsp
     f97:      	popq	%rbx
     f98:      	popq	%r12
     f9a:      	popq	%r13
     f9c:      	popq	%r14
     f9e:      	popq	%r15
     fa0:      	popq	%rbp
     fa1:      	retq
     fa2:      	cmpl	$0x1e, %ebx
     fa5:      	movq	0x98(%rsp), %r14
     fad:      	jg	0x1088 <generic_retuprobe_event+0x1088>
     fb3:      	cmpl	$0x1c, %ebx
     fb6:      	jg	0x1178 <generic_retuprobe_event+0x1178>
     fbc:      	cmpl	$0x11, %ebx
     fbf:      	je	0x18df <generic_retuprobe_event+0x18df>
     fc5:      	cmpl	$0x19, %ebx
     fc8:      	je	0x1623 <generic_retuprobe_event+0x1623>
     fce:      	cmpl	$0x1c, %ebx
     fd1:      	movq	0x8(%rsp), %rcx
     fd6:      	je	0x113c <generic_retuprobe_event+0x113c>
     fdc:      	jmp	0x2e3b <generic_retuprobe_event+0x2e3b>
     fe1:      	leal	-0xa(%rbx), %eax
     fe4:      	cmpl	$0x2, %eax
     fe7:      	movq	0x8(%rsp), %rcx
     fec:      	jb	0x113c <generic_retuprobe_event+0x113c>
     ff2:      	leal	-0xc(%rbx), %eax
     ff5:      	cmpl	$0x2, %eax
     ff8:      	jb	0x115a <generic_retuprobe_event+0x115a>
     ffe:      	cmpl	$0xe, %ebx
    1001:      	jne	0x2e3b <generic_retuprobe_event+0x2e3b>
    1007:      	leaq	0x38(%rsp), %rdi
    100c:      	leaq	0x20(%rsp), %rbx
    1011:      	movl	$0x8, %ecx
    1016:      	movl	$0x4, %eax
    101b:      	movl	$0x8, %esi
    1020:      	movq	%rbx, %rdx
    1023:      	callq	*%rax
    1025:      	movq	0x38(%rsp), %rcx
    102a:      	movl	$0x8, %edx
    102f:      	movl	$0x4, %eax
    1034:      	movq	0x38(%rsp), %rdx
    1039:      	movq	%rbx, %rdi
    103c:      	movl	$0x8, %esi
    1041:      	callq	*%rax
    1043:      	movq	0x8(%rsp), %rcx
    1048:      	movq	0x20(%rsp), %rdx
    104d:      	movq	%rcx, %rdi
    1050:      	addq	$0xa0, %rdi
    1057:      	movl	$0x1ff, %ecx            # imm = 0x1FF
    105c:      	movl	$0x2d, %eax
    1061:      	movl	$0x1ff, %esi            # imm = 0x1FF
    1066:      	callq	*%rax
    1068:      	movq	%rax, %rbp
    106b:      	testq	%rax, %rax
    106e:      	js	0x19e3 <generic_retuprobe_event+0x19e3>
    1074:      	leal	-0x1(%rbp), %eax
    1077:      	movl	%eax, (%r15)
    107a:      	addq	$0x3, %rbp
    107e:      	movq	0x8(%rsp), %rcx
    1083:      	jmp	0x2e3b <generic_retuprobe_event+0x2e3b>
    1088:      	cmpl	$0x26, %ebx
    108b:      	jg	0x11a0 <generic_retuprobe_event+0x11a0>
    1091:      	leal	-0x1f(%rbx), %eax
    1094:      	cmpl	$0x2, %eax
    1097:      	jae	0x14b3 <generic_retuprobe_event+0x14b3>
    109d:      	leaq	0x20(%rsp), %rdx
    10a2:      	movl	$0x4, %ebp
    10a7:      	movl	$0x1, %ecx
    10ac:      	movl	$0x4, %eax
    10b1:      	movq	%r15, %rdi
    10b4:      	movl	$0x1, %esi
    10b9:      	jmp	0x1194 <generic_retuprobe_event+0x1194>
    10be:      	cmpl	$0x20, %ebx
    10c1:      	jle	0x13da <generic_retuprobe_event+0x13da>
    10c7:      	leal	-0x21(%rbx), %edx
    10ca:      	cmpl	$0x4, %edx
    10cd:      	jae	0x1253 <generic_retuprobe_event+0x1253>
    10d3:      	movl	$0x8, %ebp
    10d8:      	movl	$0x8, %ecx
    10dd:      	movl	$0x4, %eax
    10e2:      	movq	0x10(%rsp), %rbx
    10e7:      	movq	0x90(%rsp), %rdi
    10ef:      	movl	$0x8, %esi
    10f4:      	jmp	0x1526 <generic_retuprobe_event+0x1526>
    10f9:      	cmpl	$0x7, %ebx
    10fc:      	jg	0x14fe <generic_retuprobe_event+0x14fe>
    1102:      	cmpl	$0x2, %ebx
    1105:      	je	0x1ac8 <generic_retuprobe_event+0x1ac8>
    110b:      	cmpl	$0x3, %ebx
    110e:      	movq	0x10(%rsp), %rbx
    1113:      	jne	0x2e45 <generic_retuprobe_event+0x2e45>
    1119:      	movq	$0x0, 0x9c(%rax)
    1124:      	movl	$0x8, %ebp
    1129:      	jmp	0x2e45 <generic_retuprobe_event+0x2e45>
    112e:      	cmpl	$0x1, %ebx
    1131:      	je	0x115a <generic_retuprobe_event+0x115a>
    1133:      	cmpl	$0x4, %ebx
    1136:      	jne	0x2e3b <generic_retuprobe_event+0x2e3b>
    113c:      	movl	$0x8, %ebp
    1141:      	leaq	0x20(%rsp), %rdx
    1146:      	movl	$0x8, %ecx
    114b:      	movl	$0x4, %eax
    1150:      	movq	%r15, %rdi
    1153:      	movl	$0x8, %esi
    1158:      	jmp	0x1194 <generic_retuprobe_event+0x1194>
    115a:      	leaq	0x20(%rsp), %rdx
    115f:      	movl	$0x4, %ebp
    1164:      	movl	$0x4, %ecx
    1169:      	movl	$0x4, %eax
    116e:      	movq	%r15, %rdi
    1171:      	movl	$0x4, %esi
    1176:      	jmp	0x1194 <generic_retuprobe_event+0x1194>
    1178:      	leaq	0x20(%rsp), %rdx
    117d:      	movl	$0x4, %ebp
    1182:      	movl	$0x2, %ecx
    1187:      	movl	$0x4, %eax
    118c:      	movq	%r15, %rdi
    118f:      	movl	$0x2, %esi
    1194:      	callq	*%rax
    1196:      	movq	0x8(%rsp), %rcx
    119b:      	jmp	0x2e3b <generic_retuprobe_event+0x2e3b>
    11a0:      	cmpl	$0x27, %ebx
    11a3:      	je	0x19b0 <generic_retuprobe_event+0x19b0>
    11a9:      	cmpl	$0x28, %ebx
    11ac:      	movq	0x8(%rsp), %rcx
    11b1:      	jne	0x2e3b <generic_retuprobe_event+0x2e3b>
    11b7:      	movq	%r12, 0x30(%rsp)
    11bc:      	movq	0x20(%rsp), %r12
    11c1:      	movq	$0x0, 0x10(%r15)
    11c9:      	movq	$0x0, 0x8(%r15)
    11d1:      	movq	$0x0, (%r15)
    11d8:      	movl	$0x2, %ecx
    11dd:      	movl	$0x4, %eax
    11e2:      	movq	%r15, %rdi
    11e5:      	movl	$0x2, %esi
    11ea:      	movq	%r12, %rdx
    11ed:      	callq	*%rax
    11ef:      	testq	%rax, %rax
    11f2:      	js	0x22ed <generic_retuprobe_event+0x22ed>
    11f8:      	movzwl	(%r15), %eax
    11fc:      	cmpl	$0xa, %eax
    11ff:      	je	0x2294 <generic_retuprobe_event+0x2294>
    1205:      	cmpl	$0x2, %eax
    1208:      	jne	0x22d8 <generic_retuprobe_event+0x22d8>
    120e:      	leaq	0x4(%r12), %rdx
    1213:      	leaq	0x38(%rsp), %rdi
    1218:      	movl	$0x4, %ecx
    121d:      	movl	$0x4, %eax
    1222:      	movl	$0x4, %esi
    1227:      	callq	*%rax
    1229:      	movl	0x38(%rsp), %eax
    122d:      	movq	0x8(%rsp), %rdi
    1232:      	movq	%rax, 0xa4(%rdi)
    1239:      	addq	$0x9e, %rdi
    1240:      	addq	$0x2, %r12
    1244:      	movl	$0x2, %ecx
    1249:      	movl	$0x4, %eax
    124e:      	jmp	0x22ce <generic_retuprobe_event+0x22ce>
    1253:      	cmpl	$0x2b, %ebx
    1256:      	je	0x1f8a <generic_retuprobe_event+0x1f8a>
    125c:      	cmpl	$0x29, %ebx
    125f:      	movq	0x10(%rsp), %rbx
    1264:      	jne	0x2e45 <generic_retuprobe_event+0x2e45>
    126a:      	movq	%r12, 0x30(%rsp)
    126f:      	movq	%rax, %r15
    1272:      	leaq	0x18(%rbx), %rdx
    1276:      	leaq	0x38(%rsp), %rdi
    127b:      	movl	$0x4, %ebx
    1280:      	movl	$0x8, %ecx
    1285:      	movl	$0x4, %eax
    128a:      	movl	$0x8, %esi
    128f:      	callq	*%rax
    1291:      	movq	0x38(%rsp), %r12
    1296:      	testq	%r12, %r12
    1299:      	je	0x246b <generic_retuprobe_event+0x246b>
    129f:      	movq	0x8(%rsp), %rbp
    12a4:      	movq	%r12, 0xc4(%rbp)
    12ab:      	leaq	0xc2(%rbp), %rdi
    12b2:      	leaq	0x10(%r12), %rdx
    12b7:      	movl	$0x2, %ecx
    12bc:      	movl	$0x4, %eax
    12c1:      	movl	$0x2, %esi
    12c6:      	callq	*%rax
    12c8:      	leaq	0xd6(%rbp), %rdi
    12cf:      	leaq	0x12(%r12), %rdx
    12d4:      	movl	$0x1, %ecx
    12d9:      	movl	$0x4, %eax
    12de:      	movl	$0x1, %esi
    12e3:      	callq	*%rax
    12e5:      	leaq	0xd4(%rbp), %rdi
    12ec:      	leaq	0x226(%r12), %rdx
    12f4:      	movl	$0x2, %ecx
    12f9:      	movl	$0x4, %eax
    12fe:      	movl	$0x2, %esi
    1303:      	callq	*%rax
    1305:      	leaq	0xc0(%rbp), %rdi
    130c:      	leaq	0x224(%r12), %rdx
    1314:      	movl	$0x2, %ecx
    1319:      	movl	$0x4, %eax
    131e:      	movl	$0x2, %esi
    1323:      	callq	*%rax
    1325:      	leaq	0xcc(%rbp), %rdi
    132c:      	leaq	0x21c(%r12), %rdx
    1334:      	movl	$0x4, %eax
    1339:      	movl	$0x4, %esi
    133e:      	callq	*%rax
    1340:      	leaq	0xd0(%rbp), %rdi
    1347:      	leaq	0x218(%r12), %rdx
    134f:      	movl	$0x4, %eax
    1354:      	movl	$0x4, %esi
    1359:      	callq	*%rax
    135b:      	leaq	0xac(%rbp), %r14
    1362:      	movq	0x90(%rsp), %rax
    136a:      	movq	$0x0, (%rax)
    1371:      	movq	$0x0, 0x8(%rax)
    1379:      	movq	$0x0, 0x10(%rax)
    1381:      	movq	$0x0, 0x18(%rax)
    1389:      	movzwl	0xc2(%rbp), %eax
    1390:      	cmpl	$0xa, %eax
    1393:      	je	0x23db <generic_retuprobe_event+0x23db>
    1399:      	cmpl	$0x2, %eax
    139c:      	jne	0x2412 <generic_retuprobe_event+0x2412>
    13a2:      	leaq	0x4(%r12), %rdx
    13a7:      	movl	$0x4, %ecx
    13ac:      	movl	$0x4, %eax
    13b1:      	movq	0x90(%rsp), %rdi
    13b9:      	movl	$0x4, %esi
    13be:      	callq	*%rax
    13c0:      	movl	$0x4, %ecx
    13c5:      	movl	$0x4, %eax
    13ca:      	movq	%r14, %rdi
    13cd:      	movl	$0x4, %esi
    13d2:      	movq	%r12, %rdx
    13d5:      	jmp	0x2410 <generic_retuprobe_event+0x2410>
    13da:      	cmpl	$0x1a, %ebx
    13dd:      	je	0x2039 <generic_retuprobe_event+0x2039>
    13e3:      	cmpl	$0x1b, %ebx
    13e6:      	movq	0x10(%rsp), %rbx
    13eb:      	jne	0x2e45 <generic_retuprobe_event+0x2e45>
    13f1:      	movq	%r13, 0x18(%rsp)
    13f6:      	movq	0x90(%rsp), %rax
    13fe:      	movq	$0x0, 0x48(%rax)
    1406:      	movq	$0x0, 0x40(%rax)
    140e:      	movq	$0x0, 0x38(%rax)
    1416:      	movq	$0x0, 0x30(%rax)
    141e:      	movq	$0x0, 0x28(%rax)
    1426:      	movq	$0x0, 0x20(%rax)
    142e:      	movq	$0x0, 0x18(%rax)
    1436:      	movq	$0x0, 0x10(%rax)
    143e:      	movq	$0x0, 0x8(%rax)
    1446:      	movq	$0x0, (%rax)
    144d:      	leaq	0xac(%rcx), %rdi
    1454:      	leaq	0x18(%rbx), %rdx
    1458:      	movl	$0x3f, %ecx
    145d:      	movl	$0x2d, %eax
    1462:      	movl	$0x3f, %esi
    1467:      	callq	*%rax
    1469:      	testq	%rax, %rax
    146c:      	js	0x23c5 <generic_retuprobe_event+0x23c5>
    1472:      	movq	0x8(%rsp), %rbx
    1477:      	movq	%rbx, %rdi
    147a:      	addq	$0xa4, %rdi
    1481:      	movq	0x10(%rsp), %r13
    1486:      	leaq	0x348(%r13), %rdx
    148d:      	movl	$0x8, %ecx
    1492:      	movl	$0x4, %eax
    1497:      	movl	$0x8, %esi
    149c:      	callq	*%rax
    149e:      	movq	%rbx, %rcx
    14a1:      	movq	%r13, %rbx
    14a4:      	movl	$0x50, %ebp
    14a9:      	movq	0x18(%rsp), %r13
    14ae:      	jmp	0x2e45 <generic_retuprobe_event+0x2e45>
    14b3:      	cmpl	$0x26, %ebx
    14b6:      	movq	0x8(%rsp), %rcx
    14bb:      	jne	0x2e3b <generic_retuprobe_event+0x2e3b>
    14c1:      	movq	0x20(%rsp), %rsi
    14c6:      	movzwl	%si, %edx
    14c9:      	addq	0xc8(%rsp), %rdx
    14d1:      	shrl	$0x10, %esi
    14d4:      	andl	$0xfff, %esi            # imm = 0xFFF
    14da:      	movq	%rcx, %rdi
    14dd:      	addq	$0xa0, %rdi
    14e4:      	incl	%esi
    14e6:      	movl	$0x2d, %eax
    14eb:      	callq	*%rax
    14ed:      	movq	%rax, %rbp
    14f0:      	testq	%rax, %rax
    14f3:      	jns	0x1074 <generic_retuprobe_event+0x1074>
    14f9:      	jmp	0x19e3 <generic_retuprobe_event+0x19e3>
    14fe:      	cmpl	$0x8, %ebx
    1501:      	je	0x1b62 <generic_retuprobe_event+0x1b62>
    1507:      	cmpl	$0x12, %ebx
    150a:      	movq	0x10(%rsp), %rbx
    150f:      	jne	0x2e45 <generic_retuprobe_event+0x2e45>
    1515:      	xorl	%ebp, %ebp
    1517:      	movl	$0x4, %eax
    151c:      	movq	0x90(%rsp), %rdi
    1524:      	xorl	%esi, %esi
    1526:      	movq	%rbx, %rdx
    1529:      	callq	*%rax
    152b:      	movq	0x8(%rsp), %rcx
    1530:      	jmp	0x2e45 <generic_retuprobe_event+0x2e45>
    1535:      	cmpl	$0x13, %ebx
    1538:      	je	0x1f29 <generic_retuprobe_event+0x1f29>
    153e:      	cmpl	$0x14, %ebx
    1541:      	movq	0x10(%rsp), %rbx
    1546:      	jne	0x2e45 <generic_retuprobe_event+0x2e45>
    154c:      	movq	$0x0, 0x38(%rsp)
    1555:      	leaq	0x110(%rbx), %rdx
    155c:      	leaq	0x38(%rsp), %rdi
    1561:      	movl	$0x8, %ecx
    1566:      	movl	$0x4, %eax
    156b:      	movq	%r14, %rbx
    156e:      	movq	0x10(%rsp), %rcx
    1573:      	leaq	0xd8(%rcx), %r14
    157a:      	movl	$0x8, %esi
    157f:      	callq	*%rax
    1581:      	movq	0x38(%rsp), %rcx
    1586:      	movl	$0x80, %edx
    158b:      	movl	$0x2d, %eax
    1590:      	movq	0x90(%rsp), %rdi
    1598:      	movq	0x38(%rsp), %rdx
    159d:      	movl	$0x80, %esi
    15a2:      	callq	*%rax
    15a4:      	movq	0x8(%rsp), %rax
    15a9:      	leaq	0x12c(%rax), %rdi
    15b0:      	movl	$0x4, %ecx
    15b5:      	movl	$0x4, %eax
    15ba:      	movl	$0x4, %esi
    15bf:      	movq	%r14, %rdx
    15c2:      	movq	%rbx, %r14
    15c5:      	movq	0x10(%rsp), %rbx
    15ca:      	callq	*%rax
    15cc:      	movq	0x8(%rsp), %rax
    15d1:      	leaq	0x11c(%rax), %rdi
    15d8:      	leaq	0xe0(%rbx), %rdx
    15df:      	movl	$0x8, %ecx
    15e4:      	movl	$0x4, %eax
    15e9:      	movl	$0x8, %esi
    15ee:      	callq	*%rax
    15f0:      	movq	0x8(%rsp), %rdi
    15f5:      	addq	$0x124, %rdi            # imm = 0x124
    15fc:      	leaq	0x118(%rbx), %rdx
    1603:      	movl	$0x8, %ecx
    1608:      	movl	$0x4, %eax
    160d:      	movl	$0x8, %esi
    1612:      	callq	*%rax
    1614:      	movq	0x8(%rsp), %rcx
    1619:      	movl	$0x98, %ebp
    161e:      	jmp	0x2e45 <generic_retuprobe_event+0x2e45>
    1623:      	movq	%r14, %r15
    1626:      	movq	%rax, %rbx
    1629:      	movq	0x20(%rsp), %r14
    162e:      	leaq	0xc0(%rsp), %rdi
    1636:      	movl	$0x1, %ecx
    163b:      	movl	$0x4, %eax
    1640:      	movl	$0x1, %esi
    1645:      	movq	%r14, %rdx
    1648:      	callq	*%rax
    164a:      	cmpb	$0x1, 0xc0(%rsp)
    1652:      	jne	0x20c5 <generic_retuprobe_event+0x20c5>
    1658:      	addq	$0x10, %r14
    165c:      	leaq	0x38(%rsp), %rdi
    1661:      	movl	$0x8, %ecx
    1666:      	movl	$0x4, %eax
    166b:      	movl	$0x8, %esi
    1670:      	movq	%r14, %rdx
    1673:      	callq	*%rax
    1675:      	movq	0x38(%rsp), %rdx
    167a:      	leaq	0x80(%rsp), %rdi
    1682:      	movl	$0x8, %ecx
    1687:      	movl	$0x4, %eax
    168c:      	movl	$0x8, %esi
    1691:      	callq	*%rax
    1693:      	movq	0x38(%rsp), %rdx
    1698:      	addq	$0x8, %rdx
    169c:      	leaq	0xa0(%rsp), %rdi
    16a4:      	movl	$0x8, %ecx
    16a9:      	movl	$0x4, %eax
    16ae:      	movl	$0x8, %esi
    16b3:      	callq	*%rax
    16b5:      	movq	0x80(%rsp), %rdx
    16bd:      	movq	0xa0(%rsp), %r14
    16c5:      	cmpq	$0xfff, %r14            # imm = 0xFFF
    16cc:      	movl	$0xfff, %ebp            # imm = 0xFFF
    16d1:      	cmovbq	%r14, %rbp
    16d5:      	movq	%rbx, %rdi
    16d8:      	addq	$0xa4, %rdi
    16df:      	movl	$0x4, %eax
    16e4:      	movl	%ebp, %esi
    16e6:      	callq	*%rax
    16e8:      	testl	%eax, %eax
    16ea:      	js	0x2278 <generic_retuprobe_event+0x2278>
    16f0:      	movl	%r14d, 0x9c(%rbx)
    16f7:      	movl	%ebp, 0xa0(%rbx)
    16fd:      	addq	$0x8, %rbp
    1701:      	jmp	0x2287 <generic_retuprobe_event+0x2287>
    1706:      	movq	%r12, 0x30(%rsp)
    170b:      	movq	0x20(%rsp), %r12
    1710:      	leaq	0xc4(%rcx), %rdi
    1717:      	leaq	0x98(%r12), %rdx
    171f:      	movl	$0x4, %esi
    1724:      	movq	%rcx, %rbx
    1727:      	movl	$0x4, %eax
    172c:      	movl	$0x4, %esi
    1731:      	callq	*%rax
    1733:      	leaq	0xc8(%rbx), %rdi
    173a:      	leaq	0x70(%r12), %rdx
    173f:      	movl	$0x4, %ecx
    1744:      	movl	$0x4, %eax
    1749:      	movl	$0x4, %esi
    174e:      	callq	*%rax
    1750:      	leaq	0xcc(%rbx), %rdi
    1757:      	leaq	0x90(%r12), %rdx
    175f:      	movl	$0x4, %ecx
    1764:      	movl	$0x4, %eax
    1769:      	movl	$0x4, %esi
    176e:      	callq	*%rax
    1770:      	leaq	0xd0(%rbx), %rdi
    1777:      	leaq	0xa8(%r12), %rdx
    177f:      	movl	$0x4, %ecx
    1784:      	movl	$0x4, %eax
    1789:      	movl	$0x4, %esi
    178e:      	callq	*%rax
    1790:      	movq	$0x0, 0x38(%rsp)
    1799:      	leaq	0xc8(%r12), %rdx
    17a1:      	leaq	0x38(%rsp), %rdi
    17a6:      	movl	$0x8, %ecx
    17ab:      	movl	$0x4, %eax
    17b0:      	movl	$0x8, %esi
    17b5:      	callq	*%rax
    17b7:      	movq	%r12, %rbp
    17ba:      	leaq	0xb8(%r12), %rdx
    17c2:      	leaq	0xc0(%rsp), %rdi
    17ca:      	movl	$0x2, %ecx
    17cf:      	movl	$0x4, %eax
    17d4:      	movl	$0x2, %esi
    17d9:      	callq	*%rax
    17db:      	movzwl	0xc0(%rsp), %r12d
    17e4:      	addq	0x38(%rsp), %r12
    17e9:      	leaq	0xbc(%rsp), %rdi
    17f1:      	movl	$0x1, %ecx
    17f6:      	movl	$0x4, %eax
    17fb:      	movl	$0x1, %esi
    1800:      	movq	%r12, %rdx
    1803:      	callq	*%rax
    1805:      	movzbl	0xbc(%rsp), %eax
    180d:      	shrl	$0x4, %eax
    1810:      	cmpl	$0x6, %eax
    1813:      	je	0x20e6 <generic_retuprobe_event+0x20e6>
    1819:      	cmpl	$0x4, %eax
    181c:      	jne	0x2e2c <generic_retuprobe_event+0x2e2c>
    1822:      	movq	%r13, 0x18(%rsp)
    1827:      	leaq	0x9(%r12), %rdx
    182c:      	leaq	0xd0(%rsp), %rdi
    1834:      	movl	$0x1, %ecx
    1839:      	movl	$0x4, %eax
    183e:      	movl	$0x1, %esi
    1843:      	callq	*%rax
    1845:      	movzbl	0xd0(%rsp), %eax
    184d:      	movq	0x8(%rsp), %rcx
    1852:      	movw	%ax, 0xc0(%rcx)
    1859:      	movw	$0x2, 0xc2(%rcx)
    1862:      	leaq	0xc(%r12), %rdx
    1867:      	movq	$0x0, (%r15)
    186e:      	movq	$0x0, 0x8(%r15)
    1876:      	movq	$0x0, 0x10(%r15)
    187e:      	movq	$0x0, 0x18(%r15)
    1886:      	movl	$0x4, %esi
    188b:      	movl	$0x4, %eax
    1890:      	leaq	0xac(%rcx), %rbx
    1897:      	movq	%r15, %rdi
    189a:      	movl	$0x4, %esi
    189f:      	callq	*%rax
    18a1:      	addq	$0x10, %r12
    18a5:      	movl	$0x4, %ecx
    18aa:      	movl	$0x4, %eax
    18af:      	movq	%rbx, %rdi
    18b2:      	movl	$0x4, %esi
    18b7:      	movq	%r12, %rdx
    18ba:      	callq	*%rax
    18bc:      	leaq	0xb6(%rbp), %rdx
    18c3:      	leaq	0xd8(%rsp), %rdi
    18cb:      	movl	$0x2, %ecx
    18d0:      	movl	$0x4, %eax
    18d5:      	movl	$0x2, %esi
    18da:      	jmp	0x2c8b <generic_retuprobe_event+0x2c8b>
    18df:      	movq	$0x0, 0x40(%rsp)
    18e8:      	movq	$0x0, 0x38(%rsp)
    18f1:      	movl	$0xe, %eax
    18f6:      	callq	*%rax
    18f8:      	shrq	$0x20, %rax
    18fc:      	movq	%rax, 0x38(%rsp)
    1901:      	leaq	0x80(%rsp), %rdi
    1909:      	leaq	0x20(%rsp), %rdx
    190e:      	movl	$0x4, %ecx
    1913:      	movl	$0x4, %eax
    1918:      	movl	$0x4, %esi
    191d:      	callq	*%rax
    191f:      	movl	0x80(%rsp), %eax
    1926:      	movl	%eax, 0x40(%rsp)
    192a:      	movq	(%rip), %rdi            # 0x1931 <generic_retuprobe_event+0x1931>
    1931:      	leaq	0x38(%rsp), %rsi
    1936:      	movl	$0x1, %eax
    193b:      	callq	*%rax
    193d:      	testq	%rax, %rax
    1940:      	je	0x20da <generic_retuprobe_event+0x20da>
    1946:      	movl	(%rax), %ebp
    1948:      	leaq	0x80(%rsp), %rdx
    1950:      	movq	%rax, %r14
    1953:      	movl	$0x4, %eax
    1958:      	movq	%r15, %rbx
    195b:      	movl	$0x4, %r15d
    1961:      	movq	%rbx, %rdi
    1964:      	movl	$0x4, %esi
    1969:      	callq	*%rax
    196b:      	andl	$0xfff, %ebp            # imm = 0xFFF
    1971:      	movq	0x8(%rsp), %rdi
    1976:      	addq	$0xa0, %rdi
    197d:      	leaq	0x4(%rbp), %rsi
    1981:      	movl	$0x4, %eax
    1986:      	movq	%r14, %rdx
    1989:      	callq	*%rax
    198b:      	leaq	(%rbx,%rbp), %rdi
    198f:      	addq	$0x8, %rdi
    1993:      	leaq	(%r14,%rbp), %rdx
    1997:      	addq	$0x4, %rdx
    199b:      	movl	$0x4, %eax
    19a0:      	movl	$0x4, %esi
    19a5:      	callq	*%rax
    19a7:      	addq	$0xc, %rbp
    19ab:      	jmp	0xbd6 <generic_retuprobe_event+0xbd6>
    19b0:      	movl	$0x120, %edx            # imm = 0x120
    19b5:      	addq	0x20(%rsp), %rdx
    19ba:      	movq	0x8(%rsp), %rdi
    19bf:      	addq	$0xa0, %rdi
    19c6:      	movl	$0x11, %ecx
    19cb:      	movl	$0x2d, %eax
    19d0:      	movl	$0x11, %esi
    19d5:      	callq	*%rax
    19d7:      	movq	%rax, %rbp
    19da:      	testq	%rax, %rax
    19dd:      	jns	0x1074 <generic_retuprobe_event+0x1074>
    19e3:      	movq	0x8(%rsp), %rcx
    19e8:      	jmp	0x2e3b <generic_retuprobe_event+0x2e3b>
    19ed:      	xorl	%eax, %eax
    19ef:      	movq	%rax, 0x10(%rsp)
    19f4:      	cmpq	$0x3, 0xb0(%rsp)
    19fd:      	jb	0xbf5 <generic_retuprobe_event+0xbf5>
    1a03:      	movq	%r13, 0x18(%rsp)
    1a08:      	movq	0x30(%rsp), %rax
    1a0d:      	leaq	0x20(%rax), %rdx
    1a11:      	leaq	0x38(%rsp), %rdi
    1a16:      	movl	$0x4, %ebx
    1a1b:      	movl	$0x10, %ecx
    1a20:      	movl	$0x4, %eax
    1a25:      	movl	$0x10, %esi
    1a2a:      	callq	*%rax
    1a2c:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1a31:      	testl	%eax, %eax
    1a33:      	js	0x2ffa <generic_retuprobe_event+0x2ffa>
    1a39:      	movq	0x40(%rsp), %r12
    1a3e:      	movq	0x10(%rsp), %rax
    1a43:      	cmpq	%rax, %r12
    1a46:      	movq	%rax, %rcx
    1a49:      	cmovbq	%r12, %rcx
    1a4d:      	testq	%rax, %rax
    1a50:      	movq	%rcx, %r13
    1a53:      	cmovneq	%rcx, %r12
    1a57:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    1a5c:      	cmpq	$0xffe, %r12            # imm = 0xFFE
    1a63:      	ja	0x2ffa <generic_retuprobe_event+0x2ffa>
    1a69:      	movq	0x8(%rsp), %rdi
    1a6e:      	addq	0x78(%rsp), %rdi
    1a73:      	movq	%rdi, 0x8(%rsp)
    1a78:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    1a7e:      	addq	0x28(%rsp), %rdi
    1a83:      	movq	0x38(%rsp), %rcx
    1a88:      	movl	$0x4, %eax
    1a8d:      	movq	0x38(%rsp), %rdx
    1a92:      	movl	%r12d, %esi
    1a95:      	callq	*%rax
    1a97:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1a9c:      	testl	%eax, %eax
    1a9e:      	js	0x2ffa <generic_retuprobe_event+0x2ffa>
    1aa4:      	movq	%r12, 0x78(%rsp)
    1aa9:      	addq	%r12, %rbp
    1aac:      	cmpq	$0x0, 0x10(%rsp)
    1ab2:      	je	0x250c <generic_retuprobe_event+0x250c>
    1ab8:      	subq	%r13, 0x10(%rsp)
    1abd:      	jne	0x2513 <generic_retuprobe_event+0x2513>
    1ac3:      	jmp	0x251e <generic_retuprobe_event+0x251e>
    1ac8:      	movq	%r12, 0x30(%rsp)
    1acd:      	movq	$0x0, 0x80(%rsp)
    1ad9:      	movq	$0x0, 0x38(%rsp)
    1ae2:      	leaq	0x80(%rsp), %rdi
    1aea:      	leaq	0x38(%rsp), %rdx
    1aef:      	movl	$0x8, %ecx
    1af4:      	movq	%rax, %r12
    1af7:      	movl	$0x4, %eax
    1afc:      	movl	$0x4, %ebp
    1b01:      	movl	$0x8, %esi
    1b06:      	callq	*%rax
    1b08:      	movq	0x80(%rsp), %r15
    1b10:      	cmpq	$0xfff, %r15            # imm = 0xFFF
    1b17:      	movl	$0xfff, %r14d           # imm = 0xFFF
    1b1d:      	cmovbq	%r15, %r14
    1b21:      	movq	%r12, %rbx
    1b24:      	movq	%r12, %rdi
    1b27:      	addq	$0xa4, %rdi
    1b2e:      	movl	$0x4, %eax
    1b33:      	movq	0x10(%rsp), %rdx
    1b38:      	movl	%r14d, %esi
    1b3b:      	callq	*%rax
    1b3d:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1b42:      	testl	%eax, %eax
    1b44:      	js	0x1b57 <generic_retuprobe_event+0x1b57>
    1b46:      	movl	%r14d, 0xa0(%rbx)
    1b4d:      	addq	$0x8, %r14
    1b51:      	movl	%r15d, %ecx
    1b54:      	movq	%r14, %rbp
    1b57:      	movl	%ecx, 0x9c(%rbx)
    1b5d:      	jmp	0x24ae <generic_retuprobe_event+0x24ae>
    1b62:      	movq	%r12, %rbp
    1b65:      	leaq	0xc4(%rcx), %r12
    1b6c:      	leaq	0xdc(%rcx), %r15
    1b73:      	movq	0x10(%rsp), %rbx
    1b78:      	leaq	0x8(%rbx), %rdx
    1b7c:      	movl	$0x4, %ecx
    1b81:      	movl	$0x4, %eax
    1b86:      	movq	0x90(%rsp), %rdi
    1b8e:      	movl	$0x4, %esi
    1b93:      	callq	*%rax
    1b95:      	movq	0x8(%rsp), %rax
    1b9a:      	leaq	0xa0(%rax), %rdi
    1ba1:      	leaq	0xc(%rbx), %rdx
    1ba5:      	movl	$0x4, %ecx
    1baa:      	movl	$0x4, %eax
    1baf:      	movl	$0x4, %esi
    1bb4:      	callq	*%rax
    1bb6:      	movq	0x8(%rsp), %rax
    1bbb:      	leaq	0xac(%rax), %rdi
    1bc2:      	leaq	0x18(%rbx), %rdx
    1bc6:      	movl	$0x4, %ecx
    1bcb:      	movl	$0x4, %eax
    1bd0:      	movl	$0x4, %esi
    1bd5:      	callq	*%rax
    1bd7:      	movq	0x8(%rsp), %rax
    1bdc:      	leaq	0xb0(%rax), %rdi
    1be3:      	leaq	0x1c(%rbx), %rdx
    1be7:      	movl	$0x4, %ecx
    1bec:      	movl	$0x4, %eax
    1bf1:      	movl	$0x4, %esi
    1bf6:      	callq	*%rax
    1bf8:      	movq	0x8(%rsp), %rax
    1bfd:      	leaq	0xa4(%rax), %rdi
    1c04:      	leaq	0x10(%rbx), %rdx
    1c08:      	movl	$0x4, %ecx
    1c0d:      	movl	$0x4, %eax
    1c12:      	movl	$0x4, %esi
    1c17:      	callq	*%rax
    1c19:      	movq	0x8(%rsp), %rax
    1c1e:      	leaq	0xa8(%rax), %rdi
    1c25:      	leaq	0x14(%rbx), %rdx
    1c29:      	movl	$0x4, %ecx
    1c2e:      	movl	$0x4, %eax
    1c33:      	movl	$0x4, %esi
    1c38:      	callq	*%rax
    1c3a:      	movq	0x8(%rsp), %rax
    1c3f:      	leaq	0xb4(%rax), %rdi
    1c46:      	leaq	0x20(%rbx), %rdx
    1c4a:      	movl	$0x4, %ecx
    1c4f:      	movl	$0x4, %eax
    1c54:      	movl	$0x4, %esi
    1c59:      	callq	*%rax
    1c5b:      	movq	0x8(%rsp), %rax
    1c60:      	leaq	0xb8(%rax), %rdi
    1c67:      	leaq	0x24(%rbx), %rdx
    1c6b:      	movl	$0x4, %ecx
    1c70:      	movl	$0x4, %eax
    1c75:      	movl	$0x4, %esi
    1c7a:      	callq	*%rax
    1c7c:      	movq	0x8(%rsp), %rax
    1c81:      	movl	$0x0, 0xc0(%rax)
    1c8b:      	movq	0x8(%rsp), %rax
    1c90:      	leaq	0xbc(%rax), %rdi
    1c97:      	leaq	0x28(%rbx), %rdx
    1c9b:      	movl	$0x4, %ecx
    1ca0:      	movl	$0x4, %eax
    1ca5:      	movl	$0x4, %esi
    1caa:      	callq	*%rax
    1cac:      	movq	0x8(%rsp), %rax
    1cb1:      	leaq	0xcc(%rax), %rdi
    1cb8:      	leaq	0x40(%rbx), %rdx
    1cbc:      	movl	$0x8, %ecx
    1cc1:      	movl	$0x4, %eax
    1cc6:      	movl	$0x8, %esi
    1ccb:      	callq	*%rax
    1ccd:      	movq	0x8(%rsp), %rax
    1cd2:      	leaq	0xd4(%rax), %rdi
    1cd9:      	leaq	0x30(%rbx), %rdx
    1cdd:      	movl	$0x8, %ecx
    1ce2:      	movl	$0x4, %eax
    1ce7:      	movl	$0x8, %esi
    1cec:      	callq	*%rax
    1cee:      	leaq	0x38(%rbx), %rdx
    1cf2:      	movl	$0x8, %ecx
    1cf7:      	movl	$0x4, %eax
    1cfc:      	movq	%r12, %rdi
    1cff:      	movq	%rbp, %r12
    1d02:      	movl	$0x8, %esi
    1d07:      	callq	*%rax
    1d09:      	leaq	0x90(%rbx), %rdx
    1d10:      	leaq	0x38(%rsp), %rdi
    1d15:      	movl	$0x8, %ecx
    1d1a:      	movl	$0x4, %eax
    1d1f:      	movl	$0x8, %esi
    1d24:      	callq	*%rax
    1d26:      	movq	0x38(%rsp), %r14
    1d2b:      	leaq	0xc8(%r14), %rdx
    1d32:      	movl	$0x4, %ecx
    1d37:      	movl	$0x4, %eax
    1d3c:      	movq	%r15, %rdi
    1d3f:      	movl	$0x4, %esi
    1d44:      	callq	*%rax
    1d46:      	movq	0x8(%rsp), %rax
    1d4b:      	leaq	0xe0(%rax), %rdi
    1d52:      	leaq	0xcc(%r14), %rdx
    1d59:      	movl	$0x4, %ecx
    1d5e:      	movl	$0x4, %eax
    1d63:      	movl	$0x4, %esi
    1d68:      	callq	*%rax
    1d6a:      	movq	0x8(%rsp), %rax
    1d6f:      	leaq	0xe4(%rax), %rdi
    1d76:      	leaq	0xd0(%r14), %rdx
    1d7d:      	movl	$0x4, %ecx
    1d82:      	movl	$0x4, %eax
    1d87:      	movl	$0x4, %esi
    1d8c:      	callq	*%rax
    1d8e:      	movq	0x8(%rsp), %rdi
    1d93:      	addq	$0xe8, %rdi
    1d9a:      	addq	$0x158, %r14            # imm = 0x158
    1da1:      	movl	$0x4, %ecx
    1da6:      	movl	$0x4, %eax
    1dab:      	movl	$0x4, %esi
    1db0:      	movq	%r14, %rdx
    1db3:      	movq	0x98(%rsp), %r14
    1dbb:      	movq	0x28(%rsp), %r15
    1dc0:      	callq	*%rax
    1dc2:      	movq	0x8(%rsp), %rcx
    1dc7:      	movl	$0x50, %ebp
    1dcc:      	jmp	0x2e45 <generic_retuprobe_event+0x2e45>
    1dd1:      	movq	0x10(%rsp), %rbx
    1dd6:      	leaq	0xc8(%rbx), %rdx
    1ddd:      	movl	$0x4, %ecx
    1de2:      	movl	$0x4, %eax
    1de7:      	movq	0x90(%rsp), %rdi
    1def:      	movl	$0x4, %esi
    1df4:      	callq	*%rax
    1df6:      	movq	0x8(%rsp), %rax
    1dfb:      	leaq	0xa0(%rax), %rdi
    1e02:      	leaq	0xcc(%rbx), %rdx
    1e09:      	movl	$0x4, %ecx
    1e0e:      	movl	$0x4, %eax
    1e13:      	movl	$0x4, %esi
    1e18:      	callq	*%rax
    1e1a:      	movq	0x8(%rsp), %rax
    1e1f:      	leaq	0xa4(%rax), %rdi
    1e26:      	leaq	0xd0(%rbx), %rdx
    1e2d:      	movl	$0x4, %ecx
    1e32:      	movl	$0x4, %eax
    1e37:      	movl	$0x4, %esi
    1e3c:      	callq	*%rax
    1e3e:      	movq	0x8(%rsp), %rdi
    1e43:      	addq	$0xa8, %rdi
    1e4a:      	leaq	0x158(%rbx), %rdx
    1e51:      	movl	$0x4, %ecx
    1e56:      	movl	$0x4, %eax
    1e5b:      	movl	$0x4, %esi
    1e60:      	callq	*%rax
    1e62:      	movq	0x8(%rsp), %rcx
    1e67:      	movl	$0x10, %ebp
    1e6c:      	jmp	0x2e45 <generic_retuprobe_event+0x2e45>
    1e71:      	movq	0x10(%rsp), %rbx
    1e76:      	leaq	0x38(%rbx), %rdx
    1e7a:      	movl	$0x4, %ecx
    1e7f:      	movl	$0x4, %eax
    1e84:      	movq	0x90(%rsp), %rdi
    1e8c:      	movl	$0x4, %esi
    1e91:      	callq	*%rax
    1e93:      	movq	0x8(%rsp), %rax
    1e98:      	leaq	0xa0(%rax), %rdi
    1e9f:      	leaq	0x3c(%rbx), %rdx
    1ea3:      	movl	$0x4, %ecx
    1ea8:      	movl	$0x4, %eax
    1ead:      	movl	$0x4, %esi
    1eb2:      	callq	*%rax
    1eb4:      	movq	0x8(%rsp), %rax
    1eb9:      	leaq	0xa4(%rax), %rdi
    1ec0:      	leaq	0x40(%rbx), %rdx
    1ec4:      	movl	$0x4, %ecx
    1ec9:      	movl	$0x4, %eax
    1ece:      	movl	$0x4, %esi
    1ed3:      	callq	*%rax
    1ed5:      	movq	0x8(%rsp), %rax
    1eda:      	leaq	0xa8(%rax), %rdi
    1ee1:      	leaq	0x44(%rbx), %rdx
    1ee5:      	movl	$0x4, %ecx
    1eea:      	movl	$0x4, %eax
    1eef:      	movl	$0x4, %esi
    1ef4:      	callq	*%rax
    1ef6:      	movq	0x8(%rsp), %rdi
    1efb:      	addq	$0xac, %rdi
    1f02:      	leaq	0x80(%rbx), %rdx
    1f09:      	movl	$0x10, %ecx
    1f0e:      	movl	$0x4, %eax
    1f13:      	movl	$0x10, %esi
    1f18:      	callq	*%rax
    1f1a:      	movq	0x8(%rsp), %rcx
    1f1f:      	movl	$0x20, %ebp
    1f24:      	jmp	0x2e45 <generic_retuprobe_event+0x2e45>
    1f29:      	movl	$0x4, %ecx
    1f2e:      	movl	$0x4, %eax
    1f33:      	movq	0x10(%rsp), %rbx
    1f38:      	movq	0x90(%rsp), %rdi
    1f40:      	movl	$0x4, %esi
    1f45:      	movq	%rbx, %rdx
    1f48:      	callq	*%rax
    1f4a:      	movq	0x8(%rsp), %rax
    1f4f:      	leaq	0xa0(%rax), %rdi
    1f56:      	leaq	0x4(%rbx), %rdx
    1f5a:      	movl	$0x4, %ecx
    1f5f:      	movl	$0x4, %eax
    1f64:      	movl	$0x4, %esi
    1f69:      	callq	*%rax
    1f6b:      	movq	0x8(%rsp), %rdi
    1f70:      	addq	$0xa4, %rdi
    1f77:      	leaq	0x30(%rbx), %rdx
    1f7b:      	movl	$0x10, %ecx
    1f80:      	movl	$0x4, %eax
    1f85:      	jmp	0x2023 <generic_retuprobe_event+0x2023>
    1f8a:      	movq	0x10(%rsp), %rbx
    1f8f:      	leaq	0x4(%rbx), %rdx
    1f93:      	leaq	0x38(%rsp), %rdi
    1f98:      	movl	$0x4, %ecx
    1f9d:      	movl	$0x4, %eax
    1fa2:      	movl	$0x4, %esi
    1fa7:      	callq	*%rax
    1fa9:      	movl	0x38(%rsp), %ecx
    1fad:      	movq	0x8(%rsp), %rax
    1fb2:      	movl	%ecx, 0x9c(%rax)
    1fb8:      	leaq	0xc(%rbx), %rdx
    1fbc:      	leaq	0x38(%rsp), %rdi
    1fc1:      	movl	$0x4, %ecx
    1fc6:      	movl	$0x4, %eax
    1fcb:      	movl	$0x4, %esi
    1fd0:      	callq	*%rax
    1fd2:      	movl	0x38(%rsp), %ecx
    1fd6:      	movq	0x8(%rsp), %rax
    1fdb:      	movl	%ecx, 0xa0(%rax)
    1fe1:      	leaq	0x50(%rbx), %rdx
    1fe5:      	leaq	0x38(%rsp), %rdi
    1fea:      	movl	$0x8, %ecx
    1fef:      	movl	$0x2d, %eax
    1ff4:      	movl	$0x8, %esi
    1ff9:      	callq	*%rax
    1ffb:      	movq	0x8(%rsp), %rdi
    2000:      	addq	$0xa4, %rdi
    2007:      	movl	$0x3f8, %edx            # imm = 0x3F8
    200c:      	movq	0x38(%rsp), %rcx
    2011:      	addq	%rdx, %rcx
    2014:      	movl	$0x10, %esi
    2019:      	movl	$0x2d, %eax
    201e:      	addq	0x38(%rsp), %rdx
    2023:      	movl	$0x10, %esi
    2028:      	callq	*%rax
    202a:      	movq	0x8(%rsp), %rcx
    202f:      	movl	$0x18, %ebp
    2034:      	jmp	0x2e45 <generic_retuprobe_event+0x2e45>
    2039:      	movq	%r12, 0x30(%rsp)
    203e:      	movq	0x90(%rsp), %rax
    2046:      	movq	$0x0, 0x48(%rax)
    204e:      	movq	$0x0, 0x40(%rax)
    2056:      	movq	$0x0, 0x38(%rax)
    205e:      	movq	$0x0, 0x30(%rax)
    2066:      	movq	$0x0, 0x28(%rax)
    206e:      	movq	$0x0, 0x20(%rax)
    2076:      	movq	$0x0, 0x18(%rax)
    207e:      	movq	$0x0, 0x10(%rax)
    2086:      	movq	$0x0, 0x8(%rax)
    208e:      	movq	$0x0, (%rax)
    2095:      	leaq	0x38(%rsp), %rdi
    209a:      	movl	$0x8, %ecx
    209f:      	movl	$0x4, %eax
    20a4:      	movq	0x10(%rsp), %rdx
    20a9:      	movl	$0x8, %esi
    20ae:      	callq	*%rax
    20b0:      	testq	%rax, %rax
    20b3:      	je	0x22f7 <generic_retuprobe_event+0x22f7>
    20b9:      	xorl	%ebp, %ebp
    20bb:      	movq	0x8(%rsp), %rcx
    20c0:      	jmp	0x24c0 <generic_retuprobe_event+0x24c0>
    20c5:      	movq	$0x0, 0x9c(%rbx)
    20d0:      	movl	$0x8, %ebp
    20d5:      	jmp	0x2287 <generic_retuprobe_event+0x2287>
    20da:      	movq	$-0x1, %rbp
    20e1:      	jmp	0xbd6 <generic_retuprobe_event+0xbd6>
    20e6:      	movq	%r13, 0x18(%rsp)
    20eb:      	movq	0x38(%rsp), %rbx
    20f0:      	movl	$0x0, 0x80(%rsp)
    20fb:      	movzwl	0xc0(%rsp), %r14d
    2104:      	movq	(%rip), %rdi            # 0x210b <generic_retuprobe_event+0x210b>
    210b:      	leaq	0x80(%rsp), %rsi
    2113:      	movl	$0x1, %eax
    2118:      	leaq	(%rbx,%r14), %r12
    211c:      	callq	*%rax
    211e:      	testq	%rax, %rax
    2121:      	je	0x2c34 <generic_retuprobe_event+0x2c34>
    2127:      	movq	%rax, %r13
    212a:      	movw	%r14w, (%r13)
    212f:      	movb	$-0x1, 0x5(%r13)
    2134:      	movb	$0x0, 0x7(%r13)
    2139:      	movq	%r13, %rdi
    213c:      	addq	$0x6, %rdi
    2140:      	leaq	0x6(%r12), %rdx
    2145:      	movl	$0x1, %ecx
    214a:      	movl	$0x4, %eax
    214f:      	movq	%rdi, %r14
    2152:      	movl	$0x1, %esi
    2157:      	callq	*%rax
    2159:      	testq	%rax, %rax
    215c:      	js	0x2c34 <generic_retuprobe_event+0x2c34>
    2162:      	movzbl	0x5(%r13), %eax
    2167:      	cmpl	$0x32, %eax
    216a:      	jg	0x24cf <generic_retuprobe_event+0x24cf>
    2170:      	testl	%eax, %eax
    2172:      	je	0x24f8 <generic_retuprobe_event+0x24f8>
    2178:      	cmpl	$0x2b, %eax
    217b:      	je	0x24f8 <generic_retuprobe_event+0x24f8>
    2181:      	cmpl	$0x2c, %eax
    2184:      	jne	0x26b2 <generic_retuprobe_event+0x26b2>
    218a:      	movw	$0x8, 0x2(%r13)
    2191:      	movw	$0x8, %ax
    2195:      	jmp	0x25fa <generic_retuprobe_event+0x25fa>
    219a:      	leaq	0x48(%r12), %rdx
    219f:      	movl	$0x10, %ecx
    21a4:      	movl	$0x4, %eax
    21a9:      	movq	%r15, %rdi
    21ac:      	movl	$0x10, %esi
    21b1:      	callq	*%rax
    21b3:      	leaq	0x38(%r12), %rdx
    21b8:      	movl	$0x10, %ecx
    21bd:      	movl	$0x4, %eax
    21c2:      	movq	%r14, %rdi
    21c5:      	movl	$0x10, %esi
    21ca:      	callq	*%rax
    21cc:      	movq	0x8(%rsp), %r14
    21d1:      	leaq	0xbc(%r14), %rdi
    21d8:      	leaq	0xc(%r12), %rbx
    21dd:      	addq	$0xe, %r12
    21e1:      	movl	$0x2, %ecx
    21e6:      	movl	$0x4, %eax
    21eb:      	movl	$0x2, %esi
    21f0:      	movq	%r12, %rdx
    21f3:      	callq	*%rax
    21f5:      	movq	%r14, %rdi
    21f8:      	addq	$0xbe, %rdi
    21ff:      	movl	$0x2, %ecx
    2204:      	movl	$0x4, %eax
    2209:      	movl	$0x2, %esi
    220e:      	movq	%rbx, %rdx
    2211:      	callq	*%rax
    2213:      	movzwl	0xbe(%r14), %eax
    221b:      	movbew	%ax, 0xbe(%r14)
    2225:      	movq	0x20(%rsp), %rax
    222a:      	movq	%rax, 0x38(%rsp)
    222f:      	movq	(%rip), %rdi            # 0x2236 <generic_retuprobe_event+0x2236>
    2236:      	leaq	0x38(%rsp), %rsi
    223b:      	movl	$0x1, %eax
    2240:      	callq	*%rax
    2242:      	testq	%rax, %rax
    2245:      	je	0x2261 <generic_retuprobe_event+0x2261>
    2247:      	movl	(%rax), %ecx
    2249:      	movq	0x18(%rsp), %r15
    224e:      	movl	%ecx, 0x10(%r15)
    2252:      	movq	0x8(%rax), %rcx
    2256:      	movq	%rcx, 0x18(%r15)
    225a:      	movl	0x4(%rax), %eax
    225d:      	movl	%eax, 0x7c(%r15)
    2261:      	movl	$0x40, %ebp
    2266:      	movq	0x8(%rsp), %rcx
    226b:      	movq	0x98(%rsp), %r14
    2273:      	jmp	0x2e36 <generic_retuprobe_event+0x2e36>
    2278:      	movl	$0xfffffffe, 0x9c(%rbx) # imm = 0xFFFFFFFE
    2282:      	movl	$0x4, %ebp
    2287:      	movq	0x8(%rsp), %rcx
    228c:      	movq	%r15, %r14
    228f:      	jmp	0x2e3b <generic_retuprobe_event+0x2e3b>
    2294:      	movq	0x8(%rsp), %rbx
    2299:      	leaq	0xa4(%rbx), %rdi
    22a0:      	leaq	0x8(%r12), %rdx
    22a5:      	movl	$0x10, %ecx
    22aa:      	movl	$0x4, %eax
    22af:      	movl	$0x10, %esi
    22b4:      	callq	*%rax
    22b6:      	movq	%rbx, %rdi
    22b9:      	addq	$0x9e, %rdi
    22c0:      	addq	$0x2, %r12
    22c4:      	movl	$0x2, %ecx
    22c9:      	movl	$0x4, %eax
    22ce:      	movl	$0x2, %esi
    22d3:      	movq	%r12, %rdx
    22d6:      	callq	*%rax
    22d8:      	movq	0x8(%rsp), %rax
    22dd:      	movzwl	0x9e(%rax), %ecx
    22e4:      	movbew	%cx, 0x9e(%rax)
    22ed:      	movl	$0x18, %ebp
    22f2:      	jmp	0x2e31 <generic_retuprobe_event+0x2e31>
    22f7:      	movq	0x8(%rsp), %rax
    22fc:      	leaq	0xac(%rax), %rdi
    2303:      	movq	0x38(%rsp), %rcx
    2308:      	movl	$0x3f, %edx
    230d:      	movl	$0x2d, %eax
    2312:      	movq	0x38(%rsp), %rdx
    2317:      	movl	$0x3f, %esi
    231c:      	callq	*%rax
    231e:      	testq	%rax, %rax
    2321:      	js	0x20b9 <generic_retuprobe_event+0x20b9>
    2327:      	movq	0x10(%rsp), %rbx
    232c:      	leaq	0x8(%rbx), %rdx
    2330:      	leaq	0x80(%rsp), %rdi
    2338:      	movl	$0x8, %ecx
    233d:      	movl	$0x4, %eax
    2342:      	movl	$0x8, %esi
    2347:      	callq	*%rax
    2349:      	movq	0x8(%rsp), %rdi
    234e:      	addq	$0xa4, %rdi
    2355:      	movl	$0x348, %edx            # imm = 0x348
    235a:      	movq	0x80(%rsp), %rcx
    2362:      	addq	%rdx, %rcx
    2365:      	movl	$0x8, %esi
    236a:      	movl	$0x4, %eax
    236f:      	addq	0x80(%rsp), %rdx
    2377:      	movl	$0x8, %esi
    237c:      	callq	*%rax
    237e:      	leaq	0x58(%rbx), %rdx
    2382:      	leaq	0x80(%rsp), %rdi
    238a:      	movl	$0x4, %ecx
    238f:      	movl	$0x4, %eax
    2394:      	movl	$0x4, %esi
    2399:      	callq	*%rax
    239b:      	movl	$0x50, %ebp
    23a0:      	testq	%rax, %rax
    23a3:      	jne	0x20bb <generic_retuprobe_event+0x20bb>
    23a9:      	xorl	%eax, %eax
    23ab:      	cmpl	$0x0, 0x80(%rsp)
    23b3:      	setne	%al
    23b6:      	movq	0x90(%rsp), %rcx
    23be:      	movl	%eax, (%rcx)
    23c0:      	jmp	0x20bb <generic_retuprobe_event+0x20bb>
    23c5:      	xorl	%ebp, %ebp
    23c7:      	movq	0x8(%rsp), %rcx
    23cc:      	movq	0x10(%rsp), %rbx
    23d1:      	movq	0x18(%rsp), %r13
    23d6:      	jmp	0x2e45 <generic_retuprobe_event+0x2e45>
    23db:      	leaq	0x48(%r12), %rdx
    23e0:      	movl	$0x10, %ecx
    23e5:      	movl	$0x4, %eax
    23ea:      	movq	0x90(%rsp), %rdi
    23f2:      	movl	$0x10, %esi
    23f7:      	callq	*%rax
    23f9:      	leaq	0x38(%r12), %rdx
    23fe:      	movl	$0x10, %ecx
    2403:      	movl	$0x4, %eax
    2408:      	movq	%r14, %rdi
    240b:      	movl	$0x10, %esi
    2410:      	callq	*%rax
    2412:      	movq	0x8(%rsp), %r14
    2417:      	leaq	0xbc(%r14), %rdi
    241e:      	leaq	0xc(%r12), %rbx
    2423:      	addq	$0xe, %r12
    2427:      	movl	$0x2, %ecx
    242c:      	movl	$0x4, %eax
    2431:      	movl	$0x2, %esi
    2436:      	movq	%r12, %rdx
    2439:      	callq	*%rax
    243b:      	movq	%r14, %rdi
    243e:      	addq	$0xbe, %rdi
    2445:      	movl	$0x2, %ecx
    244a:      	movl	$0x4, %eax
    244f:      	movl	$0x2, %esi
    2454:      	movq	%rbx, %rdx
    2457:      	callq	*%rax
    2459:      	movzwl	0xbe(%r14), %eax
    2461:      	movbew	%ax, 0xbe(%r14)
    246b:      	movq	0x8(%rsp), %rax
    2470:      	movq	0xc4(%rax), %rax
    2477:      	movq	%rax, 0x38(%rsp)
    247c:      	movq	(%rip), %rdi            # 0x2483 <generic_retuprobe_event+0x2483>
    2483:      	leaq	0x38(%rsp), %rsi
    2488:      	movl	$0x1, %eax
    248d:      	callq	*%rax
    248f:      	testq	%rax, %rax
    2492:      	je	0x24a9 <generic_retuprobe_event+0x24a9>
    2494:      	movl	(%rax), %ecx
    2496:      	movl	%ecx, 0x10(%r15)
    249a:      	movq	0x8(%rax), %rcx
    249e:      	movq	%rcx, 0x18(%r15)
    24a2:      	movl	0x4(%rax), %eax
    24a5:      	movl	%eax, 0x7c(%r15)
    24a9:      	movl	$0x40, %ebp
    24ae:      	movq	0x8(%rsp), %rcx
    24b3:      	movq	0x98(%rsp), %r14
    24bb:      	movq	0x28(%rsp), %r15
    24c0:      	movq	0x10(%rsp), %rbx
    24c5:      	movq	0x30(%rsp), %r12
    24ca:      	jmp	0x2e45 <generic_retuprobe_event+0x2e45>
    24cf:      	cmpl	$0x33, %eax
    24d2:      	je	0x25e6 <generic_retuprobe_event+0x25e6>
    24d8:      	cmpl	$0x3c, %eax
    24db:      	je	0x24f8 <generic_retuprobe_event+0x24f8>
    24dd:      	cmpl	$0xff, %eax
    24e2:      	jne	0x26b2 <generic_retuprobe_event+0x26b2>
    24e8:      	movw	$0x28, 0x2(%r13)
    24ef:      	movw	$0x28, %ax
    24f3:      	jmp	0x25fa <generic_retuprobe_event+0x25fa>
    24f8:      	movq	%r13, %rcx
    24fb:      	movzbl	0x7(%r13), %eax
    2500:      	leal	0x8(,%rax,8), %eax
    2507:      	jmp	0x25f5 <generic_retuprobe_event+0x25f5>
    250c:      	xorl	%eax, %eax
    250e:      	movq	%rax, 0x10(%rsp)
    2513:      	cmpq	$0x3, 0xb0(%rsp)
    251c:      	jne	0x252b <generic_retuprobe_event+0x252b>
    251e:      	movq	%rbp, %r12
    2521:      	movq	0x18(%rsp), %r13
    2526:      	jmp	0x3ad <generic_retuprobe_event+0x3ad>
    252b:      	movq	0x30(%rsp), %rax
    2530:      	leaq	0x30(%rax), %rdx
    2534:      	leaq	0x38(%rsp), %rdi
    2539:      	movl	$0x4, %ebx
    253e:      	movl	$0x10, %ecx
    2543:      	movl	$0x4, %eax
    2548:      	movl	$0x10, %esi
    254d:      	callq	*%rax
    254f:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2554:      	testl	%eax, %eax
    2556:      	js	0x2ffa <generic_retuprobe_event+0x2ffa>
    255c:      	movq	0x40(%rsp), %rdx
    2561:      	movq	0x10(%rsp), %rax
    2566:      	cmpq	%rax, %rdx
    2569:      	movq	%rax, %r13
    256c:      	cmovbq	%rdx, %r13
    2570:      	testq	%rax, %rax
    2573:      	cmovneq	%r13, %rdx
    2577:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    257c:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    2583:      	ja	0x2ffa <generic_retuprobe_event+0x2ffa>
    2589:      	movq	%rdx, %r12
    258c:      	movq	0x78(%rsp), %rdi
    2591:      	addq	0x8(%rsp), %rdi
    2596:      	movq	%rdi, 0x78(%rsp)
    259b:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    25a1:      	addq	0x28(%rsp), %rdi
    25a6:      	movq	0x38(%rsp), %rcx
    25ab:      	movl	$0x4, %eax
    25b0:      	movq	%rdx, %rsi
    25b3:      	movq	0x38(%rsp), %rdx
    25b8:      	callq	*%rax
    25ba:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    25bf:      	testl	%eax, %eax
    25c1:      	js	0x2ffa <generic_retuprobe_event+0x2ffa>
    25c7:      	addq	%r12, %rbp
    25ca:      	cmpq	$0x0, 0x10(%rsp)
    25d0:      	je	0x294a <generic_retuprobe_event+0x294a>
    25d6:      	subq	%r13, 0x10(%rsp)
    25db:      	jne	0x2951 <generic_retuprobe_event+0x2951>
    25e1:      	jmp	0x251e <generic_retuprobe_event+0x251e>
    25e6:      	movq	%r13, %rcx
    25e9:      	movzbl	0x7(%r13), %eax
    25ee:      	leal	0x8(,%rax,4), %eax
    25f5:      	movw	%ax, 0x2(%r13)
    25fa:      	movq	%r13, %rcx
    25fd:      	addw	(%r13), %ax
    2602:      	movw	%ax, (%r13)
    2607:      	movzbl	0x6(%r13), %ecx
    260c:      	cmpq	$0x3c, %rcx
    2610:      	ja	0x2e7a <generic_retuprobe_event+0x2e7a>
    2616:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2620:      	btq	%rcx, %rdx
    2624:      	jae	0x2e7a <generic_retuprobe_event+0x2e7a>
    262a:      	movb	%cl, 0x5(%r13)
    262e:      	movzwl	%ax, %ecx
    2631:      	addq	%rbx, %rcx
    2634:      	movl	$0x2, %edx
    2639:      	movl	$0x4, %eax
    263e:      	movq	%r14, %rdi
    2641:      	movzwl	(%r13), %edx
    2646:      	addq	%rbx, %rdx
    2649:      	movl	$0x2, %esi
    264e:      	callq	*%rax
    2650:      	testq	%rax, %rax
    2653:      	js	0x2c34 <generic_retuprobe_event+0x2c34>
    2659:      	movzbl	0x5(%r13), %eax
    265e:      	cmpl	$0x32, %eax
    2661:      	jg	0x267e <generic_retuprobe_event+0x267e>
    2663:      	testl	%eax, %eax
    2665:      	je	0x269c <generic_retuprobe_event+0x269c>
    2667:      	cmpl	$0x2b, %eax
    266a:      	je	0x269c <generic_retuprobe_event+0x269c>
    266c:      	cmpl	$0x2c, %eax
    266f:      	jne	0x26d2 <generic_retuprobe_event+0x26d2>
    2671:      	movw	$0x8, 0x2(%r13)
    2678:      	movw	$0x8, %ax
    267c:      	jmp	0x26d7 <generic_retuprobe_event+0x26d7>
    267e:      	cmpl	$0x33, %eax
    2681:      	je	0x26bc <generic_retuprobe_event+0x26bc>
    2683:      	cmpl	$0x3c, %eax
    2686:      	je	0x269c <generic_retuprobe_event+0x269c>
    2688:      	cmpl	$0xff, %eax
    268d:      	jne	0x26d2 <generic_retuprobe_event+0x26d2>
    268f:      	movw	$0x28, 0x2(%r13)
    2696:      	movw	$0x28, %ax
    269a:      	jmp	0x26d7 <generic_retuprobe_event+0x26d7>
    269c:      	movq	%r13, %rcx
    269f:      	movzbl	0x7(%r13), %eax
    26a4:      	leal	0x8(,%rax,8), %eax
    26ab:      	movw	%ax, 0x2(%r13)
    26b0:      	jmp	0x26d7 <generic_retuprobe_event+0x26d7>
    26b2:      	movzwl	0x2(%r13), %eax
    26b7:      	jmp	0x25fa <generic_retuprobe_event+0x25fa>
    26bc:      	movq	%r13, %rcx
    26bf:      	movzbl	0x7(%r13), %eax
    26c4:      	leal	0x8(,%rax,4), %eax
    26cb:      	movw	%ax, 0x2(%r13)
    26d0:      	jmp	0x26d7 <generic_retuprobe_event+0x26d7>
    26d2:      	movzwl	0x2(%r13), %eax
    26d7:      	movq	%r13, %rcx
    26da:      	addw	(%r13), %ax
    26df:      	movw	%ax, (%r13)
    26e4:      	movzbl	0x6(%r13), %ecx
    26e9:      	cmpq	$0x3c, %rcx
    26ed:      	ja	0x2e7a <generic_retuprobe_event+0x2e7a>
    26f3:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    26fd:      	btq	%rcx, %rdx
    2701:      	jae	0x2e7a <generic_retuprobe_event+0x2e7a>
    2707:      	movb	%cl, 0x5(%r13)
    270b:      	movzwl	%ax, %ecx
    270e:      	addq	%rbx, %rcx
    2711:      	movl	$0x2, %edx
    2716:      	movl	$0x4, %eax
    271b:      	movq	%r14, %rdi
    271e:      	movzwl	(%r13), %edx
    2723:      	addq	%rbx, %rdx
    2726:      	movl	$0x2, %esi
    272b:      	callq	*%rax
    272d:      	testq	%rax, %rax
    2730:      	js	0x2c34 <generic_retuprobe_event+0x2c34>
    2736:      	movzbl	0x5(%r13), %eax
    273b:      	cmpl	$0x32, %eax
    273e:      	jg	0x275b <generic_retuprobe_event+0x275b>
    2740:      	testl	%eax, %eax
    2742:      	je	0x2779 <generic_retuprobe_event+0x2779>
    2744:      	cmpl	$0x2b, %eax
    2747:      	je	0x2779 <generic_retuprobe_event+0x2779>
    2749:      	cmpl	$0x2c, %eax
    274c:      	jne	0x27a5 <generic_retuprobe_event+0x27a5>
    274e:      	movw	$0x8, 0x2(%r13)
    2755:      	movw	$0x8, %ax
    2759:      	jmp	0x27aa <generic_retuprobe_event+0x27aa>
    275b:      	cmpl	$0x33, %eax
    275e:      	je	0x278f <generic_retuprobe_event+0x278f>
    2760:      	cmpl	$0x3c, %eax
    2763:      	je	0x2779 <generic_retuprobe_event+0x2779>
    2765:      	cmpl	$0xff, %eax
    276a:      	jne	0x27a5 <generic_retuprobe_event+0x27a5>
    276c:      	movw	$0x28, 0x2(%r13)
    2773:      	movw	$0x28, %ax
    2777:      	jmp	0x27aa <generic_retuprobe_event+0x27aa>
    2779:      	movq	%r13, %rcx
    277c:      	movzbl	0x7(%r13), %eax
    2781:      	leal	0x8(,%rax,8), %eax
    2788:      	movw	%ax, 0x2(%r13)
    278d:      	jmp	0x27aa <generic_retuprobe_event+0x27aa>
    278f:      	movq	%r13, %rcx
    2792:      	movzbl	0x7(%r13), %eax
    2797:      	leal	0x8(,%rax,4), %eax
    279e:      	movw	%ax, 0x2(%r13)
    27a3:      	jmp	0x27aa <generic_retuprobe_event+0x27aa>
    27a5:      	movzwl	0x2(%r13), %eax
    27aa:      	movq	%r13, %rcx
    27ad:      	addw	(%r13), %ax
    27b2:      	movw	%ax, (%r13)
    27b7:      	movzbl	0x6(%r13), %ecx
    27bc:      	cmpq	$0x3c, %rcx
    27c0:      	ja	0x2e7a <generic_retuprobe_event+0x2e7a>
    27c6:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    27d0:      	btq	%rcx, %rdx
    27d4:      	jae	0x2e7a <generic_retuprobe_event+0x2e7a>
    27da:      	movb	%cl, 0x5(%r13)
    27de:      	movzwl	%ax, %ecx
    27e1:      	addq	%rbx, %rcx
    27e4:      	movl	$0x2, %edx
    27e9:      	movl	$0x4, %eax
    27ee:      	movq	%r14, %rdi
    27f1:      	movzwl	(%r13), %edx
    27f6:      	addq	%rbx, %rdx
    27f9:      	movl	$0x2, %esi
    27fe:      	callq	*%rax
    2800:      	testq	%rax, %rax
    2803:      	js	0x2c34 <generic_retuprobe_event+0x2c34>
    2809:      	movzbl	0x5(%r13), %eax
    280e:      	cmpl	$0x32, %eax
    2811:      	jg	0x282e <generic_retuprobe_event+0x282e>
    2813:      	testl	%eax, %eax
    2815:      	je	0x284c <generic_retuprobe_event+0x284c>
    2817:      	cmpl	$0x2b, %eax
    281a:      	je	0x284c <generic_retuprobe_event+0x284c>
    281c:      	cmpl	$0x2c, %eax
    281f:      	jne	0x2878 <generic_retuprobe_event+0x2878>
    2821:      	movw	$0x8, 0x2(%r13)
    2828:      	movw	$0x8, %ax
    282c:      	jmp	0x287d <generic_retuprobe_event+0x287d>
    282e:      	cmpl	$0x33, %eax
    2831:      	je	0x2862 <generic_retuprobe_event+0x2862>
    2833:      	cmpl	$0x3c, %eax
    2836:      	je	0x284c <generic_retuprobe_event+0x284c>
    2838:      	cmpl	$0xff, %eax
    283d:      	jne	0x2878 <generic_retuprobe_event+0x2878>
    283f:      	movw	$0x28, 0x2(%r13)
    2846:      	movw	$0x28, %ax
    284a:      	jmp	0x287d <generic_retuprobe_event+0x287d>
    284c:      	movq	%r13, %rcx
    284f:      	movzbl	0x7(%r13), %eax
    2854:      	leal	0x8(,%rax,8), %eax
    285b:      	movw	%ax, 0x2(%r13)
    2860:      	jmp	0x287d <generic_retuprobe_event+0x287d>
    2862:      	movq	%r13, %rcx
    2865:      	movzbl	0x7(%r13), %eax
    286a:      	leal	0x8(,%rax,4), %eax
    2871:      	movw	%ax, 0x2(%r13)
    2876:      	jmp	0x287d <generic_retuprobe_event+0x287d>
    2878:      	movzwl	0x2(%r13), %eax
    287d:      	movq	%r13, %rcx
    2880:      	addw	(%r13), %ax
    2885:      	movw	%ax, (%r13)
    288a:      	movzbl	0x6(%r13), %ecx
    288f:      	cmpq	$0x3c, %rcx
    2893:      	ja	0x2e7a <generic_retuprobe_event+0x2e7a>
    2899:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    28a3:      	btq	%rcx, %rdx
    28a7:      	jae	0x2e7a <generic_retuprobe_event+0x2e7a>
    28ad:      	movb	%cl, 0x5(%r13)
    28b1:      	movzwl	%ax, %ecx
    28b4:      	addq	%rbx, %rcx
    28b7:      	movl	$0x2, %edx
    28bc:      	movl	$0x4, %eax
    28c1:      	movq	%r14, %rdi
    28c4:      	movzwl	(%r13), %edx
    28c9:      	addq	%rbx, %rdx
    28cc:      	movl	$0x2, %esi
    28d1:      	callq	*%rax
    28d3:      	testq	%rax, %rax
    28d6:      	js	0x2c34 <generic_retuprobe_event+0x2c34>
    28dc:      	movzbl	0x5(%r13), %eax
    28e1:      	cmpl	$0x32, %eax
    28e4:      	jg	0x2908 <generic_retuprobe_event+0x2908>
    28e6:      	testl	%eax, %eax
    28e8:      	je	0x2931 <generic_retuprobe_event+0x2931>
    28ea:      	cmpl	$0x2b, %eax
    28ed:      	je	0x2931 <generic_retuprobe_event+0x2931>
    28ef:      	cmpl	$0x2c, %eax
    28f2:      	jne	0x2a33 <generic_retuprobe_event+0x2a33>
    28f8:      	movw	$0x8, 0x2(%r13)
    28ff:      	movw	$0x8, %ax
    2903:      	jmp	0x2a38 <generic_retuprobe_event+0x2a38>
    2908:      	cmpl	$0x33, %eax
    290b:      	je	0x2a1d <generic_retuprobe_event+0x2a1d>
    2911:      	cmpl	$0x3c, %eax
    2914:      	je	0x2931 <generic_retuprobe_event+0x2931>
    2916:      	cmpl	$0xff, %eax
    291b:      	jne	0x2a33 <generic_retuprobe_event+0x2a33>
    2921:      	movw	$0x28, 0x2(%r13)
    2928:      	movw	$0x28, %ax
    292c:      	jmp	0x2a38 <generic_retuprobe_event+0x2a38>
    2931:      	movq	%r13, %rcx
    2934:      	movzbl	0x7(%r13), %eax
    2939:      	leal	0x8(,%rax,8), %eax
    2940:      	movw	%ax, 0x2(%r13)
    2945:      	jmp	0x2a38 <generic_retuprobe_event+0x2a38>
    294a:      	xorl	%eax, %eax
    294c:      	movq	%rax, 0x10(%rsp)
    2951:      	cmpq	$0x5, 0xb0(%rsp)
    295a:      	jb	0x251e <generic_retuprobe_event+0x251e>
    2960:      	movq	0x30(%rsp), %rax
    2965:      	leaq	0x40(%rax), %rdx
    2969:      	leaq	0x38(%rsp), %rdi
    296e:      	movl	$0x4, %ebx
    2973:      	movl	$0x10, %ecx
    2978:      	movl	$0x4, %eax
    297d:      	movl	$0x10, %esi
    2982:      	callq	*%rax
    2984:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2989:      	testl	%eax, %eax
    298b:      	js	0x2ffa <generic_retuprobe_event+0x2ffa>
    2991:      	movq	0x40(%rsp), %rdx
    2996:      	movq	0x10(%rsp), %rax
    299b:      	cmpq	%rax, %rdx
    299e:      	movq	%rax, %r13
    29a1:      	cmovbq	%rdx, %r13
    29a5:      	testq	%rax, %rax
    29a8:      	cmovneq	%r13, %rdx
    29ac:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    29b1:      	movq	%rdx, 0x8(%rsp)
    29b6:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    29bd:      	ja	0x2ffa <generic_retuprobe_event+0x2ffa>
    29c3:      	movq	%r12, %rdi
    29c6:      	addq	0x78(%rsp), %rdi
    29cb:      	movq	%rdi, %r12
    29ce:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    29d4:      	addq	0x28(%rsp), %rdi
    29d9:      	movq	0x38(%rsp), %rcx
    29de:      	movl	$0x4, %eax
    29e3:      	movq	0x8(%rsp), %rsi
    29e8:      	movq	0x38(%rsp), %rdx
    29ed:      	callq	*%rax
    29ef:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    29f4:      	testl	%eax, %eax
    29f6:      	js	0x2ffa <generic_retuprobe_event+0x2ffa>
    29fc:      	addq	0x8(%rsp), %rbp
    2a01:      	cmpq	$0x0, 0x10(%rsp)
    2a07:      	je	0x2e87 <generic_retuprobe_event+0x2e87>
    2a0d:      	subq	%r13, 0x10(%rsp)
    2a12:      	jne	0x2e8e <generic_retuprobe_event+0x2e8e>
    2a18:      	jmp	0x251e <generic_retuprobe_event+0x251e>
    2a1d:      	movq	%r13, %rcx
    2a20:      	movzbl	0x7(%r13), %eax
    2a25:      	leal	0x8(,%rax,4), %eax
    2a2c:      	movw	%ax, 0x2(%r13)
    2a31:      	jmp	0x2a38 <generic_retuprobe_event+0x2a38>
    2a33:      	movzwl	0x2(%r13), %eax
    2a38:      	movq	%r13, %rcx
    2a3b:      	addw	(%r13), %ax
    2a40:      	movw	%ax, (%r13)
    2a45:      	movzbl	0x6(%r13), %ecx
    2a4a:      	cmpq	$0x3c, %rcx
    2a4e:      	ja	0x2e7a <generic_retuprobe_event+0x2e7a>
    2a54:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2a5e:      	btq	%rcx, %rdx
    2a62:      	jae	0x2e7a <generic_retuprobe_event+0x2e7a>
    2a68:      	movb	%cl, 0x5(%r13)
    2a6c:      	movzwl	%ax, %ecx
    2a6f:      	addq	%rbx, %rcx
    2a72:      	movl	$0x2, %edx
    2a77:      	movl	$0x4, %eax
    2a7c:      	movq	%r14, %rdi
    2a7f:      	movzwl	(%r13), %edx
    2a84:      	addq	%rbx, %rdx
    2a87:      	movl	$0x2, %esi
    2a8c:      	callq	*%rax
    2a8e:      	testq	%rax, %rax
    2a91:      	js	0x2c34 <generic_retuprobe_event+0x2c34>
    2a97:      	movzbl	0x5(%r13), %eax
    2a9c:      	cmpl	$0x32, %eax
    2a9f:      	jg	0x2abc <generic_retuprobe_event+0x2abc>
    2aa1:      	testl	%eax, %eax
    2aa3:      	je	0x2ada <generic_retuprobe_event+0x2ada>
    2aa5:      	cmpl	$0x2b, %eax
    2aa8:      	je	0x2ada <generic_retuprobe_event+0x2ada>
    2aaa:      	cmpl	$0x2c, %eax
    2aad:      	jne	0x2b06 <generic_retuprobe_event+0x2b06>
    2aaf:      	movw	$0x8, 0x2(%r13)
    2ab6:      	movw	$0x8, %ax
    2aba:      	jmp	0x2b0b <generic_retuprobe_event+0x2b0b>
    2abc:      	cmpl	$0x33, %eax
    2abf:      	je	0x2af0 <generic_retuprobe_event+0x2af0>
    2ac1:      	cmpl	$0x3c, %eax
    2ac4:      	je	0x2ada <generic_retuprobe_event+0x2ada>
    2ac6:      	cmpl	$0xff, %eax
    2acb:      	jne	0x2b06 <generic_retuprobe_event+0x2b06>
    2acd:      	movw	$0x28, 0x2(%r13)
    2ad4:      	movw	$0x28, %ax
    2ad8:      	jmp	0x2b0b <generic_retuprobe_event+0x2b0b>
    2ada:      	movq	%r13, %rcx
    2add:      	movzbl	0x7(%r13), %eax
    2ae2:      	leal	0x8(,%rax,8), %eax
    2ae9:      	movw	%ax, 0x2(%r13)
    2aee:      	jmp	0x2b0b <generic_retuprobe_event+0x2b0b>
    2af0:      	movq	%r13, %rcx
    2af3:      	movzbl	0x7(%r13), %eax
    2af8:      	leal	0x8(,%rax,4), %eax
    2aff:      	movw	%ax, 0x2(%r13)
    2b04:      	jmp	0x2b0b <generic_retuprobe_event+0x2b0b>
    2b06:      	movzwl	0x2(%r13), %eax
    2b0b:      	movq	%r13, %rcx
    2b0e:      	addw	(%r13), %ax
    2b13:      	movw	%ax, (%r13)
    2b18:      	movzbl	0x6(%r13), %ecx
    2b1d:      	cmpq	$0x3c, %rcx
    2b21:      	ja	0x2e7a <generic_retuprobe_event+0x2e7a>
    2b27:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2b31:      	btq	%rcx, %rdx
    2b35:      	jae	0x2e7a <generic_retuprobe_event+0x2e7a>
    2b3b:      	movb	%cl, 0x5(%r13)
    2b3f:      	movzwl	%ax, %ecx
    2b42:      	addq	%rbx, %rcx
    2b45:      	movl	$0x2, %edx
    2b4a:      	movl	$0x4, %eax
    2b4f:      	movq	%r14, %rdi
    2b52:      	movzwl	(%r13), %edx
    2b57:      	addq	%rbx, %rdx
    2b5a:      	movl	$0x2, %esi
    2b5f:      	callq	*%rax
    2b61:      	testq	%rax, %rax
    2b64:      	js	0x2c34 <generic_retuprobe_event+0x2c34>
    2b6a:      	movzbl	0x5(%r13), %eax
    2b6f:      	cmpl	$0x32, %eax
    2b72:      	jg	0x2b8f <generic_retuprobe_event+0x2b8f>
    2b74:      	testl	%eax, %eax
    2b76:      	je	0x2bad <generic_retuprobe_event+0x2bad>
    2b78:      	cmpl	$0x2b, %eax
    2b7b:      	je	0x2bad <generic_retuprobe_event+0x2bad>
    2b7d:      	cmpl	$0x2c, %eax
    2b80:      	jne	0x2bd9 <generic_retuprobe_event+0x2bd9>
    2b82:      	movw	$0x8, 0x2(%r13)
    2b89:      	movw	$0x8, %ax
    2b8d:      	jmp	0x2bde <generic_retuprobe_event+0x2bde>
    2b8f:      	cmpl	$0x33, %eax
    2b92:      	je	0x2bc3 <generic_retuprobe_event+0x2bc3>
    2b94:      	cmpl	$0x3c, %eax
    2b97:      	je	0x2bad <generic_retuprobe_event+0x2bad>
    2b99:      	cmpl	$0xff, %eax
    2b9e:      	jne	0x2bd9 <generic_retuprobe_event+0x2bd9>
    2ba0:      	movw	$0x28, 0x2(%r13)
    2ba7:      	movw	$0x28, %ax
    2bab:      	jmp	0x2bde <generic_retuprobe_event+0x2bde>
    2bad:      	movq	%r13, %rcx
    2bb0:      	movzbl	0x7(%r13), %eax
    2bb5:      	leal	0x8(,%rax,8), %eax
    2bbc:      	movw	%ax, 0x2(%r13)
    2bc1:      	jmp	0x2bde <generic_retuprobe_event+0x2bde>
    2bc3:      	movq	%r13, %rcx
    2bc6:      	movzbl	0x7(%r13), %eax
    2bcb:      	leal	0x8(,%rax,4), %eax
    2bd2:      	movw	%ax, 0x2(%r13)
    2bd7:      	jmp	0x2bde <generic_retuprobe_event+0x2bde>
    2bd9:      	movzwl	0x2(%r13), %eax
    2bde:      	movq	%r13, %rcx
    2be1:      	addw	(%r13), %ax
    2be6:      	movw	%ax, (%r13)
    2beb:      	movzbl	0x6(%r13), %ecx
    2bf0:      	cmpq	$0x3c, %rcx
    2bf4:      	ja	0x2e7a <generic_retuprobe_event+0x2e7a>
    2bfa:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2c04:      	btq	%rcx, %rdx
    2c08:      	jae	0x2e7a <generic_retuprobe_event+0x2e7a>
    2c0e:      	movb	%cl, 0x5(%r13)
    2c12:      	movzwl	%ax, %ecx
    2c15:      	addq	%rbx, %rcx
    2c18:      	movl	$0x2, %edx
    2c1d:      	movl	$0x4, %eax
    2c22:      	movzwl	(%r13), %edx
    2c27:      	addq	%rbx, %rdx
    2c2a:      	movq	%r14, %rdi
    2c2d:      	movl	$0x2, %esi
    2c32:      	callq	*%rax
    2c34:      	xorl	%ecx, %ecx
    2c36:      	movb	%cl, 0xd0(%rsp)
    2c3d:      	movzbl	%cl, %eax
    2c40:      	movq	0x8(%rsp), %rbx
    2c45:      	movw	%ax, 0xc0(%rbx)
    2c4c:      	movw	$0xa, 0xc2(%rbx)
    2c55:      	leaq	0x8(%r12), %rdx
    2c5a:      	movl	$0x10, %ecx
    2c5f:      	movl	$0x4, %eax
    2c64:      	movq	%r15, %rdi
    2c67:      	movl	$0x10, %esi
    2c6c:      	callq	*%rax
    2c6e:      	leaq	0xac(%rbx), %rdi
    2c75:      	addq	$0x18, %r12
    2c79:      	movl	$0x10, %ecx
    2c7e:      	movl	$0x4, %eax
    2c83:      	movl	$0x10, %esi
    2c88:      	movq	%r12, %rdx
    2c8b:      	callq	*%rax
    2c8d:      	movzbl	0xd0(%rsp), %eax
    2c95:      	cmpl	$0x11, %eax
    2c98:      	je	0x2ced <generic_retuprobe_event+0x2ced>
    2c9a:      	cmpl	$0x6, %eax
    2c9d:      	jne	0x2d3e <generic_retuprobe_event+0x2d3e>
    2ca3:      	movq	0x38(%rsp), %rbx
    2ca8:      	movzwl	0xd8(%rsp), %r14d
    2cb1:      	leaq	(%rbx,%r14), %rdx
    2cb5:      	movq	0x8(%rsp), %r15
    2cba:      	leaq	0xbc(%r15), %rdi
    2cc1:      	movl	$0x2, %ecx
    2cc6:      	movl	$0x4, %eax
    2ccb:      	movl	$0x2, %esi
    2cd0:      	callq	*%rax
    2cd2:      	leaq	0xbe(%r15), %rdi
    2cd9:      	leaq	(%rbx,%r14), %rdx
    2cdd:      	addq	$0x2, %rdx
    2ce1:      	movl	$0x2, %ecx
    2ce6:      	movl	$0x4, %eax
    2ceb:      	jmp	0x2d35 <generic_retuprobe_event+0x2d35>
    2ced:      	movq	0x38(%rsp), %rbx
    2cf2:      	movzwl	0xd8(%rsp), %r14d
    2cfb:      	leaq	(%rbx,%r14), %rdx
    2cff:      	movq	0x8(%rsp), %r15
    2d04:      	leaq	0xbc(%r15), %rdi
    2d0b:      	movl	$0x2, %ecx
    2d10:      	movl	$0x4, %eax
    2d15:      	movl	$0x2, %esi
    2d1a:      	callq	*%rax
    2d1c:      	leaq	0xbe(%r15), %rdi
    2d23:      	leaq	(%rbx,%r14), %rdx
    2d27:      	addq	$0x2, %rdx
    2d2b:      	movl	$0x2, %ecx
    2d30:      	movl	$0x4, %eax
    2d35:      	movl	$0x2, %esi
    2d3a:      	callq	*%rax
    2d3c:      	jmp	0x2d4d <generic_retuprobe_event+0x2d4d>
    2d3e:      	movq	0x8(%rsp), %rax
    2d43:      	movl	$0x0, 0xbc(%rax)
    2d4d:      	movq	0x8(%rsp), %rax
    2d52:      	movzwl	0xbc(%rax), %ecx
    2d59:      	movzwl	0xbe(%rax), %edx
    2d60:      	movbew	%cx, 0xbc(%rax)
    2d69:      	movbew	%dx, 0xbe(%rax)
    2d72:      	addq	$0xe0, %rbp
    2d79:      	leaq	0x80(%rsp), %rdi
    2d81:      	movl	$0x8, %ecx
    2d86:      	movl	$0x4, %eax
    2d8b:      	movl	$0x4, %ebx
    2d90:      	movl	$0x8, %esi
    2d95:      	movq	%rbp, %rdx
    2d98:      	callq	*%rax
    2d9a:      	movq	0x80(%rsp), %rcx
    2da2:      	testq	%rcx, %rcx
    2da5:      	je	0x2e1f <generic_retuprobe_event+0x2e1f>
    2da7:      	addq	$0x5, %rcx
    2dab:      	leaq	0xa0(%rsp), %rdi
    2db3:      	movl	$0x8, %edx
    2db8:      	movl	$0x4, %eax
    2dbd:      	movq	0x80(%rsp), %rdx
    2dc5:      	addq	$0x5, %rdx
    2dc9:      	movl	$0x8, %esi
    2dce:      	callq	*%rax
    2dd0:      	movq	0x80(%rsp), %r14
    2dd8:      	movq	0xa0(%rsp), %r15
    2de0:      	movq	0x8(%rsp), %r12
    2de5:      	leaq	0xd4(%r12), %rdi
    2ded:      	leaq	(%r14,%r15,8), %rdx
    2df1:      	addq	$0x44, %rdx
    2df5:      	movl	$0x4, %eax
    2dfa:      	movl	$0x4, %esi
    2dff:      	callq	*%rax
    2e01:      	movq	%r12, %rdi
    2e04:      	addq	$0xd8, %rdi
    2e0b:      	leaq	(%r14,%r15,8), %rdx
    2e0f:      	addq	$0x45, %rdx
    2e13:      	movl	$0x4, %eax
    2e18:      	movl	$0x4, %esi
    2e1d:      	callq	*%rax
    2e1f:      	movq	0x98(%rsp), %r14
    2e27:      	movq	0x18(%rsp), %r13
    2e2c:      	movl	$0x40, %ebp
    2e31:      	movq	0x8(%rsp), %rcx
    2e36:      	movq	0x30(%rsp), %r12
    2e3b:      	movq	0x28(%rsp), %r15
    2e40:      	movq	0x10(%rsp), %rbx
    2e45:      	testl	%ebp, %ebp
    2e47:      	movl	0x78(%rsp), %eax
    2e4b:      	js	0x2e5c <generic_retuprobe_event+0x2e5c>
    2e4d:      	andl	$0x7fffffff, %ebp       # imm = 0x7FFFFFFF
    2e53:      	addq	$0x4, %rbp
    2e57:      	jmp	0x309 <generic_retuprobe_event+0x309>
    2e5c:      	movl	$0xffffffff, 0x5ea0(%rcx) # imm = 0xFFFFFFFF
    2e66:      	movl	$0xffffffff, 0x98(%rcx) # imm = 0xFFFFFFFF
    2e70:      	movl	$0x4, %ebp
    2e75:      	jmp	0x309 <generic_retuprobe_event+0x309>
    2e7a:      	movw	%ax, 0xd8(%rsp)
    2e82:      	jmp	0x2c36 <generic_retuprobe_event+0x2c36>
    2e87:      	xorl	%eax, %eax
    2e89:      	movq	%rax, 0x10(%rsp)
    2e8e:      	cmpq	$0x5, 0xb0(%rsp)
    2e97:      	je	0x251e <generic_retuprobe_event+0x251e>
    2e9d:      	movq	0x30(%rsp), %rax
    2ea2:      	leaq	0x50(%rax), %rdx
    2ea6:      	leaq	0x38(%rsp), %rdi
    2eab:      	movl	$0x4, %ebx
    2eb0:      	movl	$0x10, %ecx
    2eb5:      	movl	$0x4, %eax
    2eba:      	movl	$0x10, %esi
    2ebf:      	callq	*%rax
    2ec1:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2ec6:      	testl	%eax, %eax
    2ec8:      	js	0x2ffa <generic_retuprobe_event+0x2ffa>
    2ece:      	movq	0x40(%rsp), %rdx
    2ed3:      	movq	0x10(%rsp), %rax
    2ed8:      	cmpq	%rax, %rdx
    2edb:      	movq	%rax, %r13
    2ede:      	cmovbq	%rdx, %r13
    2ee2:      	testq	%rax, %rax
    2ee5:      	cmovneq	%r13, %rdx
    2ee9:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2eee:      	movq	%rdx, 0x78(%rsp)
    2ef3:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    2efa:      	ja	0x2ffa <generic_retuprobe_event+0x2ffa>
    2f00:      	movq	0x8(%rsp), %rdi
    2f05:      	addq	%r12, %rdi
    2f08:      	movq	%rdi, 0x8(%rsp)
    2f0d:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2f13:      	addq	0x28(%rsp), %rdi
    2f18:      	movq	0x38(%rsp), %rcx
    2f1d:      	movl	$0x4, %eax
    2f22:      	movq	0x78(%rsp), %rsi
    2f27:      	movq	0x38(%rsp), %rdx
    2f2c:      	callq	*%rax
    2f2e:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2f33:      	testl	%eax, %eax
    2f35:      	js	0x2ffa <generic_retuprobe_event+0x2ffa>
    2f3b:      	addq	0x78(%rsp), %rbp
    2f40:      	cmpq	$0x0, 0x10(%rsp)
    2f46:      	je	0x2f54 <generic_retuprobe_event+0x2f54>
    2f48:      	subq	%r13, 0x10(%rsp)
    2f4d:      	jne	0x2f5b <generic_retuprobe_event+0x2f5b>
    2f4f:      	jmp	0x251e <generic_retuprobe_event+0x251e>
    2f54:      	xorl	%eax, %eax
    2f56:      	movq	%rax, 0x10(%rsp)
    2f5b:      	cmpq	$0x7, 0xb0(%rsp)
    2f64:      	jb	0x251e <generic_retuprobe_event+0x251e>
    2f6a:      	movq	0x30(%rsp), %rdx
    2f6f:      	addq	$0x60, %rdx
    2f73:      	leaq	0x38(%rsp), %rdi
    2f78:      	movl	$0x4, %ebx
    2f7d:      	movl	$0x10, %ecx
    2f82:      	movl	$0x4, %eax
    2f87:      	movl	$0x10, %esi
    2f8c:      	callq	*%rax
    2f8e:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2f93:      	testl	%eax, %eax
    2f95:      	js	0x2ffa <generic_retuprobe_event+0x2ffa>
    2f97:      	movq	0x40(%rsp), %rax
    2f9c:      	movq	0x10(%rsp), %rcx
    2fa1:      	cmpq	%rcx, %rax
    2fa4:      	movq	%rcx, %r12
    2fa7:      	cmovbq	%rax, %r12
    2fab:      	testq	%rcx, %rcx
    2fae:      	cmoveq	%rax, %r12
    2fb2:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2fb7:      	cmpq	$0xffe, %r12            # imm = 0xFFE
    2fbe:      	ja	0x2ffa <generic_retuprobe_event+0x2ffa>
    2fc0:      	movq	0x78(%rsp), %rdi
    2fc5:      	addq	0x8(%rsp), %rdi
    2fca:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2fd0:      	addq	0x28(%rsp), %rdi
    2fd5:      	movq	0x38(%rsp), %rcx
    2fda:      	movl	$0x4, %eax
    2fdf:      	movq	0x38(%rsp), %rdx
    2fe4:      	movl	%r12d, %esi
    2fe7:      	callq	*%rax
    2fe9:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2fee:      	testl	%eax, %eax
    2ff0:      	js	0x2ffa <generic_retuprobe_event+0x2ffa>
    2ff2:      	addq	%rbp, %r12
    2ff5:      	jmp	0x2521 <generic_retuprobe_event+0x2521>
    2ffa:      	movq	0x28(%rsp), %rax
    2fff:      	movl	%ecx, (%rax,%r14)
    3003:      	movq	0x18(%rsp), %r13
    3008:      	jmp	0xcc3 <generic_retuprobe_event+0xcc3>
