
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/cilium/bpf_alignchecker.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <__check_cluster_id_bits>:
       0:      	movq	(%rip), %rax            # 0x7 <__check_cluster_id_bits+0x7>
       7:      	movl	(%rax), %eax
       9:      	retq

Disassembly of section tc/tail:

0000000000000000 <tail_icmp6_send_time_exceeded>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xb8, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	0x30(%rdi), %r14d
      18:      	movl	0x34(%rdi), %r13d
      1c:      	movl	$0x0, 0x30(%rdi)
      23:      	movq	$0x0, 0x78(%rsp)
      2c:      	movq	$0x0, 0x70(%rsp)
      35:      	movq	$0x0, 0x68(%rsp)
      3e:      	movq	$0x0, 0x60(%rsp)
      47:      	movq	$0x0, 0x58(%rsp)
      50:      	movq	$0x0, 0x50(%rsp)
      59:      	movq	$0x0, 0x48(%rsp)
      62:      	movq	$0x0, 0x40(%rsp)
      6b:      	movq	$0x0, 0x38(%rsp)
      74:      	movq	$0x0, 0x30(%rsp)
      7d:      	movw	$0x0, 0xc(%rsp)
      84:      	movb	$0x3a, 0xf(%rsp)
      89:      	leaq	0x38(%rsp), %rdx
      8e:      	movq	(%rip), %rax            # 0x95 <tail_icmp6_send_time_exceeded+0x95>
      95:      	movq	(%rax), %rcx
      98:      	movq	%rcx, 0x90(%rsp)
      a0:      	movq	0x8(%rax), %rax
      a4:      	movq	%rax, 0x88(%rsp)
      ac:      	movq	$0x3, 0x30(%rsp)
      b5:      	movl	$0x1a, %eax
      ba:      	movl	%r14d, %esi
      bd:      	movl	$0x28, %ecx
      c2:      	callq	*%rax
      c4:      	movl	$0xffffff7a, %ebp       # imm = 0xFFFFFF7A
      c9:      	testl	%eax, %eax
      cb:      	js	0x557 <tail_icmp6_send_time_exceeded+0x557>
      d1:      	movl	$0x9, %eax
      d6:      	leal	0x6(%r14), %esi
      da:      	leaq	0xf(%rsp), %rdx
      df:      	movq	%rbx, %rdi
      e2:      	movl	$0x1, %ecx
      e7:      	xorl	%r8d, %r8d
      ea:      	callq	*%rax
      ec:      	testl	%eax, %eax
      ee:      	js	0x552 <tail_icmp6_send_time_exceeded+0x552>
      f4:      	leaq	0x60(%rsp), %rdx
      f9:      	movzbl	0x3e(%rsp), %eax
      fe:      	cmpl	$0x6, %eax
     101:      	je	0x22c <tail_icmp6_send_time_exceeded+0x22c>
     107:      	cmpl	$0x3a, %eax
     10a:      	je	0x11a <tail_icmp6_send_time_exceeded+0x11a>
     10c:      	movl	$0xffffff72, %ebp       # imm = 0xFFFFFF72
     111:      	cmpl	$0x11, %eax
     114:      	jne	0x557 <tail_icmp6_send_time_exceeded+0x557>
     11a:      	movl	$0x1a, %eax
     11f:      	leal	0x28(%r14), %r15d
     123:      	movq	%rbx, %rdi
     126:      	movl	%r15d, %esi
     129:      	movl	$0x8, %ecx
     12e:      	callq	*%rax
     130:      	movl	$0xffffff7a, %ebp       # imm = 0xFFFFFF7A
     135:      	testl	%eax, %eax
     137:      	js	0x557 <tail_icmp6_send_time_exceeded+0x557>
     13d:      	movl	$0x1c, %eax
     142:      	leaq	0x30(%rsp), %rdx
     147:      	xorl	%edi, %edi
     149:      	xorl	%esi, %esi
     14b:      	movl	$0x38, %ecx
     150:      	xorl	%r8d, %r8d
     153:      	callq	*%rax
     155:      	movl	$0x38000000, 0x10(%rsp) # imm = 0x38000000
     15d:      	movl	$0x3a000000, 0x20(%rsp) # imm = 0x3A000000
     165:      	leaq	0x40(%rsp), %rdx
     16a:      	movl	$0x1c, %r9d
     170:      	xorl	%edi, %edi
     172:      	xorl	%esi, %esi
     174:      	movl	$0x10, %ecx
     179:      	movl	%eax, %r8d
     17c:      	callq	*%r9
     17f:      	leaq	0x50(%rsp), %rdx
     184:      	movl	$0x1c, %r9d
     18a:      	xorl	%edi, %edi
     18c:      	xorl	%esi, %esi
     18e:      	movl	$0x10, %ecx
     193:      	movl	%eax, %r8d
     196:      	callq	*%r9
     199:      	movl	$0x1c, %r9d
     19f:      	leaq	0x10(%rsp), %rdx
     1a4:      	xorl	%edi, %edi
     1a6:      	xorl	%esi, %esi
     1a8:      	movl	$0x4, %ecx
     1ad:      	movl	%eax, %r8d
     1b0:      	callq	*%r9
     1b3:      	movl	$0x1c, %r9d
     1b9:      	leaq	0x20(%rsp), %rdx
     1be:      	xorl	%edi, %edi
     1c0:      	xorl	%esi, %esi
     1c2:      	movl	$0x4, %ecx
     1c7:      	movl	%eax, %r8d
     1ca:      	callq	*%r9
     1cd:      	movl	%eax, %r12d
     1d0:      	movw	$0x3800, 0xc(%rsp)      # imm = 0x3800
     1d7:      	movbew	0x3c(%rsp), %ax
     1de:      	movzwl	%ax, %eax
     1e1:      	movl	$0x26, %ecx
     1e6:      	movl	0x70(%rbx), %edx
     1e9:      	negl	%eax
     1eb:      	leal	(%rdx,%rax), %esi
     1ee:      	addl	$0x38, %esi
     1f1:      	movq	%rbx, %rdi
     1f4:      	xorl	%edx, %edx
     1f6:      	callq	*%rcx
     1f8:      	testl	%eax, %eax
     1fa:      	js	0x552 <tail_icmp6_send_time_exceeded+0x552>
     200:      	movl	$0x9, %eax
     205:      	leaq	0x30(%rsp), %rdx
     20a:      	movq	%rbx, %rdi
     20d:      	movl	%r15d, %esi
     210:      	movl	$0x38, %ecx
     215:      	xorl	%r8d, %r8d
     218:      	callq	*%rax
     21a:      	testl	%eax, %eax
     21c:      	js	0x552 <tail_icmp6_send_time_exceeded+0x552>
     222:      	movl	$0x9, %eax
     227:      	jmp	0x334 <tail_icmp6_send_time_exceeded+0x334>
     22c:      	movl	$0x1a, %eax
     231:      	leal	0x28(%r14), %r15d
     235:      	movq	%rbx, %rdi
     238:      	movl	%r15d, %esi
     23b:      	movl	$0x14, %ecx
     240:      	callq	*%rax
     242:      	testl	%eax, %eax
     244:      	js	0x557 <tail_icmp6_send_time_exceeded+0x557>
     24a:      	movl	$0x1c, %eax
     24f:      	leaq	0x30(%rsp), %rdx
     254:      	xorl	%edi, %edi
     256:      	xorl	%esi, %esi
     258:      	movl	$0x44, %ecx
     25d:      	xorl	%r8d, %r8d
     260:      	callq	*%rax
     262:      	movl	$0x44000000, 0x10(%rsp) # imm = 0x44000000
     26a:      	movl	$0x3a000000, 0x20(%rsp) # imm = 0x3A000000
     272:      	leaq	0x40(%rsp), %rdx
     277:      	movl	$0x1c, %r9d
     27d:      	xorl	%edi, %edi
     27f:      	xorl	%esi, %esi
     281:      	movl	$0x10, %ecx
     286:      	movl	%eax, %r8d
     289:      	callq	*%r9
     28c:      	leaq	0x50(%rsp), %rdx
     291:      	movl	$0x1c, %r9d
     297:      	xorl	%edi, %edi
     299:      	xorl	%esi, %esi
     29b:      	movl	$0x10, %ecx
     2a0:      	movl	%eax, %r8d
     2a3:      	callq	*%r9
     2a6:      	movl	$0x1c, %r9d
     2ac:      	leaq	0x10(%rsp), %rdx
     2b1:      	xorl	%edi, %edi
     2b3:      	xorl	%esi, %esi
     2b5:      	movl	$0x4, %ecx
     2ba:      	movl	%eax, %r8d
     2bd:      	callq	*%r9
     2c0:      	movl	$0x1c, %r9d
     2c6:      	leaq	0x20(%rsp), %rdx
     2cb:      	xorl	%edi, %edi
     2cd:      	xorl	%esi, %esi
     2cf:      	movl	$0x4, %ecx
     2d4:      	movl	%eax, %r8d
     2d7:      	callq	*%r9
     2da:      	movl	%eax, %r12d
     2dd:      	movw	$0x4400, 0xc(%rsp)      # imm = 0x4400
     2e4:      	movbew	0x3c(%rsp), %ax
     2eb:      	movzwl	%ax, %eax
     2ee:      	movl	$0x26, %ecx
     2f3:      	movl	0x70(%rbx), %edx
     2f6:      	negl	%eax
     2f8:      	leal	(%rdx,%rax), %esi
     2fb:      	addl	$0x44, %esi
     2fe:      	movq	%rbx, %rdi
     301:      	xorl	%edx, %edx
     303:      	callq	*%rcx
     305:      	testl	%eax, %eax
     307:      	js	0x552 <tail_icmp6_send_time_exceeded+0x552>
     30d:      	movl	$0x9, %eax
     312:      	leaq	0x30(%rsp), %rdx
     317:      	movq	%rbx, %rdi
     31a:      	movl	%r15d, %esi
     31d:      	movl	$0x44, %ecx
     322:      	xorl	%r8d, %r8d
     325:      	callq	*%rax
     327:      	testl	%eax, %eax
     329:      	js	0x552 <tail_icmp6_send_time_exceeded+0x552>
     32f:      	movl	$0x9, %eax
     334:      	leal	0x4(%r14), %esi
     338:      	leaq	0xc(%rsp), %rdx
     33d:      	movq	%rbx, %rdi
     340:      	movl	$0x2, %ecx
     345:      	xorl	%r8d, %r8d
     348:      	callq	*%rax
     34a:      	movl	$0xffffff73, %ebp       # imm = 0xFFFFFF73
     34f:      	testl	%eax, %eax
     351:      	js	0x557 <tail_icmp6_send_time_exceeded+0x557>
     357:      	leal	0x2a(%r14), %r15d
     35b:      	movl	$0xb, %eax
     360:      	movq	%rbx, %rdi
     363:      	movl	%r15d, %esi
     366:      	xorl	%edx, %edx
     368:      	movl	%r12d, %ecx
     36b:      	movl	$0x10, %r8d
     371:      	callq	*%rax
     373:      	testl	%eax, %eax
     375:      	js	0x5df <tail_icmp6_send_time_exceeded+0x5df>
     37b:      	movq	0x90(%rsp), %rax
     383:      	movq	0x88(%rsp), %rcx
     38b:      	movq	%rax, 0x10(%rsp)
     390:      	movq	%rcx, 0x18(%rsp)
     395:      	movq	(%rip), %rax            # 0x39c <tail_icmp6_send_time_exceeded+0x39c>
     39c:      	movq	(%rax), %rax
     39f:      	movq	%rax, 0x98(%rsp)
     3a7:      	movl	$0x1a, %eax
     3ac:      	leal	0x8(%r14), %r12d
     3b0:      	leaq	0x20(%rsp), %rdx
     3b5:      	movq	%rbx, %rdi
     3b8:      	movl	%r12d, %esi
     3bb:      	movl	$0x10, %ecx
     3c0:      	callq	*%rax
     3c2:      	movl	$0xffffff7a, %ebp       # imm = 0xFFFFFF7A
     3c7:      	testl	%eax, %eax
     3c9:      	js	0x557 <tail_icmp6_send_time_exceeded+0x557>
     3cf:      	movl	$0x1a, %eax
     3d4:      	addl	$0x18, %r14d
     3d8:      	leaq	0xa8(%rsp), %rdx
     3e0:      	movq	%rbx, %rdi
     3e3:      	movl	%r14d, %esi
     3e6:      	movl	$0x10, %ecx
     3eb:      	callq	*%rax
     3ed:      	testl	%eax, %eax
     3ef:      	js	0x557 <tail_icmp6_send_time_exceeded+0x557>
     3f5:      	movl	$0x9, %eax
     3fa:      	leaq	0x10(%rsp), %rdx
     3ff:      	movq	%rbx, %rdi
     402:      	movl	%r12d, %esi
     405:      	movl	$0x10, %ecx
     40a:      	xorl	%r8d, %r8d
     40d:      	callq	*%rax
     40f:      	testl	%eax, %eax
     411:      	js	0x552 <tail_icmp6_send_time_exceeded+0x552>
     417:      	movl	$0x9, %eax
     41c:      	leaq	0x20(%rsp), %rdx
     421:      	movq	%rbx, %rdi
     424:      	movl	%r14d, %esi
     427:      	movl	$0x10, %ecx
     42c:      	xorl	%r8d, %r8d
     42f:      	callq	*%rax
     431:      	testl	%eax, %eax
     433:      	js	0x552 <tail_icmp6_send_time_exceeded+0x552>
     439:      	movl	$0x1c, %eax
     43e:      	leaq	0x20(%rsp), %rdi
     443:      	leaq	0x10(%rsp), %rdx
     448:      	movl	$0x10, %esi
     44d:      	movl	$0x10, %ecx
     452:      	xorl	%r8d, %r8d
     455:      	callq	*%rax
     457:      	movl	$0xb, %r14d
     45d:      	movq	%rbx, %rdi
     460:      	movl	%r15d, %esi
     463:      	xorl	%edx, %edx
     465:      	movl	%eax, %ecx
     467:      	movl	$0x10, %r8d
     46d:      	callq	*%r14
     470:      	movl	$0xffffff66, %ebp       # imm = 0xFFFFFF66
     475:      	testl	%eax, %eax
     477:      	js	0x557 <tail_icmp6_send_time_exceeded+0x557>
     47d:      	movl	$0x1c, %eax
     482:      	leaq	0xa8(%rsp), %rdi
     48a:      	leaq	0x20(%rsp), %rdx
     48f:      	movl	$0x10, %esi
     494:      	movl	$0x10, %ecx
     499:      	xorl	%r8d, %r8d
     49c:      	callq	*%rax
     49e:      	movq	%rbx, %rdi
     4a1:      	movl	%r15d, %esi
     4a4:      	xorl	%edx, %edx
     4a6:      	movl	%eax, %ecx
     4a8:      	movl	$0x10, %r8d
     4ae:      	callq	*%r14
     4b1:      	testl	%eax, %eax
     4b3:      	js	0x557 <tail_icmp6_send_time_exceeded+0x557>
     4b9:      	movl	$0x1a, %eax
     4be:      	leaq	0xa0(%rsp), %rdx
     4c6:      	movq	%rbx, %rdi
     4c9:      	movl	$0x6, %esi
     4ce:      	movl	$0x6, %ecx
     4d3:      	callq	*%rax
     4d5:      	movl	$0xffffff7a, %ebp       # imm = 0xFFFFFF7A
     4da:      	testl	%eax, %eax
     4dc:      	js	0x557 <tail_icmp6_send_time_exceeded+0x557>
     4de:      	movl	$0x9, %eax
     4e3:      	leaq	0xa0(%rsp), %rdx
     4eb:      	movq	%rbx, %rdi
     4ee:      	xorl	%esi, %esi
     4f0:      	movl	$0x6, %ecx
     4f5:      	xorl	%r8d, %r8d
     4f8:      	callq	*%rax
     4fa:      	testl	%eax, %eax
     4fc:      	js	0x552 <tail_icmp6_send_time_exceeded+0x552>
     4fe:      	movl	$0x9, %eax
     503:      	leaq	0x98(%rsp), %rdx
     50b:      	xorl	%r14d, %r14d
     50e:      	movq	%rbx, %rdi
     511:      	movl	$0x6, %esi
     516:      	movl	$0x6, %ecx
     51b:      	xorl	%r8d, %r8d
     51e:      	callq	*%rax
     520:      	movl	$0xffffff73, %ebp       # imm = 0xFFFFFF73
     525:      	testl	%eax, %eax
     527:      	js	0x557 <tail_icmp6_send_time_exceeded+0x557>
     529:      	movq	0x10(%rbx), %rax
     52d:      	testq	%rax, %rax
     530:      	je	0x539 <tail_icmp6_send_time_exceeded+0x539>
     532:      	movl	0xe0(%rax), %r14d
     539:      	movl	$0x17, %eax
     53e:      	movl	%r14d, %edi
     541:      	xorl	%esi, %esi
     543:      	callq	*%rax
     545:      	movl	%eax, %ebp
     547:      	testl	%eax, %eax
     549:      	js	0x557 <tail_icmp6_send_time_exceeded+0x557>
     54b:      	cmpl	$0x2, %ebp
     54e:      	jne	0x5cb <tail_icmp6_send_time_exceeded+0x5cb>
     550:      	jmp	0x557 <tail_icmp6_send_time_exceeded+0x557>
     552:      	movl	$0xffffff73, %ebp       # imm = 0xFFFFFF73
     557:      	movl	%ebp, %eax
     559:      	negl	%eax
     55b:      	cmovsl	%ebp, %eax
     55e:      	movl	0x70(%rbx), %ebx
     561:      	movabsq	$0x6701420000, %rcx     # imm = 0x6701420000
     56b:      	movq	%rcx, 0x10(%rsp)
     570:      	movb	%al, 0x10(%rsp)
     574:      	andb	$0x3, %r13b
     578:      	movb	%r13b, 0x11(%rsp)
     57d:      	movl	$0x1, %eax
     582:      	movq	(%rip), %rdi            # 0x589 <tail_icmp6_send_time_exceeded+0x589>
     589:      	leaq	0x10(%rsp), %rsi
     58e:      	callq	*%rax
     590:      	testq	%rax, %rax
     593:      	je	0x59e <tail_icmp6_send_time_exceeded+0x59e>
     595:      	incq	(%rax)
     598:      	addq	%rbx, 0x8(%rax)
     59c:      	jmp	0x5c6 <tail_icmp6_send_time_exceeded+0x5c6>
     59e:      	movq	$0x1, 0x30(%rsp)
     5a7:      	movq	%rbx, 0x38(%rsp)
     5ac:      	movl	$0x2, %eax
     5b1:      	movq	(%rip), %rdi            # 0x5b8 <tail_icmp6_send_time_exceeded+0x5b8>
     5b8:      	leaq	0x10(%rsp), %rsi
     5bd:      	leaq	0x30(%rsp), %rdx
     5c2:      	xorl	%ecx, %ecx
     5c4:      	callq	*%rax
     5c6:      	movl	$0x2, %ebp
     5cb:      	movl	%ebp, %eax
     5cd:      	addq	$0xb8, %rsp
     5d4:      	popq	%rbx
     5d5:      	popq	%r12
     5d7:      	popq	%r13
     5d9:      	popq	%r14
     5db:      	popq	%r15
     5dd:      	popq	%rbp
     5de:      	retq
     5df:      	movl	$0xffffff66, %ebp       # imm = 0xFFFFFF66
     5e4:      	jmp	0x557 <tail_icmp6_send_time_exceeded+0x557>
     5e9:      	nopl	(%rax)

00000000000005f0 <tail_icmp6_handle_ns>:
     5f0:      	pushq	%rbp
     5f1:      	pushq	%r15
     5f3:      	pushq	%r14
     5f5:      	pushq	%r13
     5f7:      	pushq	%r12
     5f9:      	pushq	%rbx
     5fa:      	subq	$0xb8, %rsp
     601:      	movq	%rdi, %rbx
     604:      	movl	0x30(%rdi), %r14d
     608:      	movl	0x34(%rdi), %r15d
     60c:      	movl	$0x0, 0x30(%rdi)
     613:      	movq	(%rip), %rax            # 0x61a <tail_icmp6_handle_ns+0x2a>
     61a:      	movq	(%rax), %rcx
     61d:      	movq	%rcx, 0xa0(%rsp)
     625:      	movq	0x8(%rax), %rax
     629:      	movq	%rax, 0x98(%rsp)
     631:      	movq	(%rip), %r12            # 0x638 <tail_icmp6_handle_ns+0x48>
     638:      	movzbl	(%r12), %eax
     63d:      	movb	%al, (%rsp)
     640:      	movzbl	0x1(%r12), %eax
     646:      	movb	%al, 0xb(%rsp)
     64a:      	movzbl	0x2(%r12), %eax
     650:      	movb	%al, 0x8(%rsp)
     654:      	movzbl	0x3(%r12), %eax
     65a:      	movb	%al, 0xa(%rsp)
     65e:      	movzbl	0x4(%r12), %eax
     664:      	movb	%al, 0x4(%rsp)
     668:      	movzbl	0x5(%r12), %eax
     66e:      	movb	%al, 0x9(%rsp)
     672:      	movzwl	0x6(%r12), %eax
     678:      	movw	%ax, 0x76(%rsp)
     67d:      	movl	$0x1a, %eax
     682:      	leal	0x30(%r14), %ebp
     686:      	leaq	0x88(%rsp), %rdx
     68e:      	movl	%ebp, %esi
     690:      	movl	$0x10, %ecx
     695:      	callq	*%rax
     697:      	testl	%eax, %eax
     699:      	js	0xdf1 <tail_icmp6_handle_ns+0x801>
     69f:      	movq	0x88(%rsp), %rax
     6a7:      	cmpq	0xa0(%rsp), %rax
     6af:      	jne	0xa32 <tail_icmp6_handle_ns+0x442>
     6b5:      	movq	0x90(%rsp), %rax
     6bd:      	cmpq	0x98(%rsp), %rax
     6c5:      	jne	0xa32 <tail_icmp6_handle_ns+0x442>
     6cb:      	movabsq	$0xc000000088, %rax     # imm = 0xC000000088
     6d5:      	movq	%rax, 0x18(%rsp)
     6da:      	movl	$0x1a, %eax
     6df:      	leal	0x40(%r14), %esi
     6e3:      	leaq	0x58(%rsp), %rdx
     6e8:      	movq	%rbx, %rdi
     6eb:      	movl	%esi, 0x14(%rsp)
     6ef:      	movl	$0x8, %ecx
     6f4:      	callq	*%rax
     6f6:      	xorl	%ecx, %ecx
     6f8:      	testl	%eax, %eax
     6fa:      	js	0xe80 <tail_icmp6_handle_ns+0x890>
     700:      	movl	%ecx, 0x24(%rsp)
     704:      	movl	$0x1a, %eax
     709:      	leal	0x28(%r14), %r13d
     70d:      	leaq	0x50(%rsp), %rdx
     712:      	movq	%rbx, %rdi
     715:      	movl	%r13d, %esi
     718:      	movl	$0x8, %ecx
     71d:      	callq	*%rax
     71f:      	movl	%eax, %ecx
     721:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
     726:      	testl	%ecx, %ecx
     728:      	js	0xf4a <tail_icmp6_handle_ns+0x95a>
     72e:      	movzwl	0x52(%rsp), %eax
     733:      	movw	%ax, 0x1a(%rsp)
     738:      	movl	$0x1a, %eax
     73d:      	leaq	0x78(%rsp), %rdx
     742:      	movq	%rbx, %rdi
     745:      	movl	%ebp, %esi
     747:      	movl	$0x10, %ecx
     74c:      	callq	*%rax
     74e:      	testl	%eax, %eax
     750:      	js	0xe76 <tail_icmp6_handle_ns+0x886>
     756:      	movl	$0x9, %eax
     75b:      	leaq	0x18(%rsp), %rdx
     760:      	movq	%rbx, %rdi
     763:      	movl	%r13d, %esi
     766:      	movl	$0x8, %ecx
     76b:      	xorl	%r8d, %r8d
     76e:      	callq	*%rax
     770:      	testl	%eax, %eax
     772:      	js	0xe76 <tail_icmp6_handle_ns+0x886>
     778:      	movl	$0x1c, %eax
     77d:      	leaq	0x50(%rsp), %rdi
     782:      	leaq	0x18(%rsp), %rdx
     787:      	movl	$0x8, %esi
     78c:      	movl	$0x8, %ecx
     791:      	movl	0x24(%rsp), %r8d
     796:      	callq	*%rax
     798:      	movl	%eax, %r13d
     79b:      	movl	$0x1a, %eax
     7a0:      	leaq	0x58(%rsp), %rdx
     7a5:      	movq	%rbx, %rdi
     7a8:      	movl	0x14(%rsp), %esi
     7ac:      	movl	$0x8, %ecx
     7b1:      	callq	*%rax
     7b3:      	testl	%eax, %eax
     7b5:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
     7ba:      	js	0xf4a <tail_icmp6_handle_ns+0x95a>
     7c0:      	movw	$0x102, 0xc(%rsp)       # imm = 0x102
     7c7:      	movzbl	(%rsp), %eax
     7cb:      	movb	%al, 0xe(%rsp)
     7cf:      	movzbl	0xb(%rsp), %eax
     7d4:      	movb	%al, 0xf(%rsp)
     7d8:      	movzbl	0x8(%rsp), %eax
     7dd:      	movb	%al, 0x10(%rsp)
     7e1:      	movzbl	0xa(%rsp), %eax
     7e6:      	movb	%al, 0x11(%rsp)
     7ea:      	movzbl	0x4(%rsp), %eax
     7ef:      	movb	%al, 0x12(%rsp)
     7f3:      	movzbl	0x9(%rsp), %eax
     7f8:      	movb	%al, 0x13(%rsp)
     7fc:      	movl	$0x9, %eax
     801:      	leaq	0xc(%rsp), %rdx
     806:      	movq	%rbx, %rdi
     809:      	movl	0x14(%rsp), %esi
     80d:      	movl	$0x8, %ecx
     812:      	xorl	%r8d, %r8d
     815:      	callq	*%rax
     817:      	movl	%eax, %ecx
     819:      	movl	$0xffffff73, %eax       # imm = 0xFFFFFF73
     81e:      	testl	%ecx, %ecx
     820:      	js	0xf4a <tail_icmp6_handle_ns+0x95a>
     826:      	leal	0x2a(%r14), %ebp
     82a:      	movl	$0x1c, %eax
     82f:      	leaq	0x58(%rsp), %rdi
     834:      	leaq	0xc(%rsp), %rdx
     839:      	movl	$0x8, %esi
     83e:      	movl	$0x8, %ecx
     843:      	movl	%r13d, %r8d
     846:      	callq	*%rax
     848:      	movl	$0xb, %r9d
     84e:      	movq	%rbx, %rdi
     851:      	movl	%ebp, %esi
     853:      	xorl	%edx, %edx
     855:      	movl	%eax, %ecx
     857:      	movl	$0x10, %r8d
     85d:      	callq	*%r9
     860:      	testl	%eax, %eax
     862:      	js	0xf3e <tail_icmp6_handle_ns+0x94e>
     868:      	movq	0x78(%rsp), %rax
     86d:      	movq	0x80(%rsp), %rcx
     875:      	movq	%rax, 0x38(%rsp)
     87a:      	movq	%rcx, 0x40(%rsp)
     87f:      	movq	(%r12), %rax
     883:      	movq	%rax, 0x60(%rsp)
     888:      	movl	$0x1a, %eax
     88d:      	leal	0x8(%r14), %r12d
     891:      	leaq	0x28(%rsp), %rdx
     896:      	movq	%rbx, %rdi
     899:      	movl	%r12d, %esi
     89c:      	movl	$0x10, %ecx
     8a1:      	callq	*%rax
     8a3:      	movl	%eax, %ecx
     8a5:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
     8aa:      	testl	%ecx, %ecx
     8ac:      	js	0xf4a <tail_icmp6_handle_ns+0x95a>
     8b2:      	movl	$0x1a, %eax
     8b7:      	addl	$0x18, %r14d
     8bb:      	leaq	0xa8(%rsp), %rdx
     8c3:      	movq	%rbx, %rdi
     8c6:      	movl	%r14d, %esi
     8c9:      	movl	$0x10, %ecx
     8ce:      	callq	*%rax
     8d0:      	testl	%eax, %eax
     8d2:      	js	0xf45 <tail_icmp6_handle_ns+0x955>
     8d8:      	movl	$0x9, %eax
     8dd:      	leaq	0x38(%rsp), %rdx
     8e2:      	movq	%rbx, %rdi
     8e5:      	movl	%r12d, %esi
     8e8:      	movl	$0x10, %ecx
     8ed:      	xorl	%r8d, %r8d
     8f0:      	callq	*%rax
     8f2:      	testl	%eax, %eax
     8f4:      	js	0xe76 <tail_icmp6_handle_ns+0x886>
     8fa:      	movl	$0x9, %eax
     8ff:      	leaq	0x28(%rsp), %rdx
     904:      	movq	%rbx, %rdi
     907:      	movl	%r14d, %esi
     90a:      	movl	$0x10, %ecx
     90f:      	xorl	%r8d, %r8d
     912:      	callq	*%rax
     914:      	testl	%eax, %eax
     916:      	js	0xe76 <tail_icmp6_handle_ns+0x886>
     91c:      	movl	$0x1c, %eax
     921:      	leaq	0x28(%rsp), %rdi
     926:      	leaq	0x38(%rsp), %rdx
     92b:      	movl	$0x10, %esi
     930:      	movl	$0x10, %ecx
     935:      	xorl	%r8d, %r8d
     938:      	callq	*%rax
     93a:      	movl	$0xb, %r14d
     940:      	movq	%rbx, %rdi
     943:      	movl	%ebp, %esi
     945:      	xorl	%edx, %edx
     947:      	movl	%eax, %ecx
     949:      	movl	$0x10, %r8d
     94f:      	callq	*%r14
     952:      	movl	%eax, %ecx
     954:      	movl	$0xffffff66, %eax       # imm = 0xFFFFFF66
     959:      	testl	%ecx, %ecx
     95b:      	js	0xf4a <tail_icmp6_handle_ns+0x95a>
     961:      	movl	$0x1c, %eax
     966:      	leaq	0xa8(%rsp), %rdi
     96e:      	leaq	0x28(%rsp), %rdx
     973:      	movl	$0x10, %esi
     978:      	movl	$0x10, %ecx
     97d:      	xorl	%r8d, %r8d
     980:      	callq	*%rax
     982:      	movq	%rbx, %rdi
     985:      	movl	%ebp, %esi
     987:      	xorl	%edx, %edx
     989:      	movl	%eax, %ecx
     98b:      	movl	$0x10, %r8d
     991:      	callq	*%r14
     994:      	movl	%eax, %ecx
     996:      	movl	$0xffffff66, %eax       # imm = 0xFFFFFF66
     99b:      	testl	%ecx, %ecx
     99d:      	js	0xf4a <tail_icmp6_handle_ns+0x95a>
     9a3:      	movl	$0x1a, %eax
     9a8:      	leaq	0x68(%rsp), %rdx
     9ad:      	movq	%rbx, %rdi
     9b0:      	movl	$0x6, %esi
     9b5:      	movl	$0x6, %ecx
     9ba:      	callq	*%rax
     9bc:      	movl	%eax, %ecx
     9be:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
     9c3:      	testl	%ecx, %ecx
     9c5:      	js	0xf4a <tail_icmp6_handle_ns+0x95a>
     9cb:      	movl	$0x9, %eax
     9d0:      	leaq	0x68(%rsp), %rdx
     9d5:      	movq	%rbx, %rdi
     9d8:      	xorl	%esi, %esi
     9da:      	movl	$0x6, %ecx
     9df:      	xorl	%r8d, %r8d
     9e2:      	callq	*%rax
     9e4:      	testl	%eax, %eax
     9e6:      	js	0xe76 <tail_icmp6_handle_ns+0x886>
     9ec:      	movl	$0x9, %eax
     9f1:      	leaq	0x60(%rsp), %rdx
     9f6:      	xorl	%ebp, %ebp
     9f8:      	movq	%rbx, %rdi
     9fb:      	movl	$0x6, %esi
     a00:      	movl	$0x6, %ecx
     a05:      	xorl	%r8d, %r8d
     a08:      	callq	*%rax
     a0a:      	movl	%eax, %ecx
     a0c:      	movl	$0xffffff73, %eax       # imm = 0xFFFFFF73
     a11:      	testl	%ecx, %ecx
     a13:      	js	0xf4a <tail_icmp6_handle_ns+0x95a>
     a19:      	movq	0x10(%rbx), %rax
     a1d:      	testq	%rax, %rax
     a20:      	je	0xa28 <tail_icmp6_handle_ns+0x438>
     a22:      	movl	0xe0(%rax), %ebp
     a28:      	movl	$0x17, %eax
     a2d:      	jmp	0xde6 <tail_icmp6_handle_ns+0x7f6>
     a32:      	movl	$0x0, 0x48(%rsp)
     a3a:      	movq	0x88(%rsp), %rax
     a42:      	movq	0x90(%rsp), %rcx
     a4a:      	movq	%rax, 0x38(%rsp)
     a4f:      	movq	%rcx, 0x40(%rsp)
     a54:      	movb	$0x2, 0x48(%rsp)
     a59:      	movl	$0x1, %eax
     a5e:      	movq	(%rip), %rdi            # 0xa65 <tail_icmp6_handle_ns+0x475>
     a65:      	leaq	0x38(%rsp), %rsi
     a6a:      	callq	*%rax
     a6c:      	testq	%rax, %rax
     a6f:      	je	0xdf8 <tail_icmp6_handle_ns+0x808>
     a75:      	movq	%rax, %rcx
     a78:      	xorl	%eax, %eax
     a7a:      	testb	$0x1, 0x8(%rcx)
     a7e:      	jne	0xf4a <tail_icmp6_handle_ns+0x95a>
     a84:      	movabsq	$0x6000000088, %rax     # imm = 0x6000000088
     a8e:      	movq	%rax, 0x18(%rsp)
     a93:      	movl	$0x1a, %eax
     a98:      	leal	0x40(%r14), %esi
     a9c:      	leaq	0x58(%rsp), %rdx
     aa1:      	movq	%rbx, %rdi
     aa4:      	movl	%esi, 0x14(%rsp)
     aa8:      	movl	$0x8, %ecx
     aad:      	callq	*%rax
     aaf:      	xorl	%ecx, %ecx
     ab1:      	testl	%eax, %eax
     ab3:      	js	0xee3 <tail_icmp6_handle_ns+0x8f3>
     ab9:      	movl	%ecx, 0x24(%rsp)
     abd:      	movl	$0x1a, %eax
     ac2:      	leal	0x28(%r14), %r13d
     ac6:      	leaq	0x50(%rsp), %rdx
     acb:      	movq	%rbx, %rdi
     ace:      	movl	%r13d, %esi
     ad1:      	movl	$0x8, %ecx
     ad6:      	callq	*%rax
     ad8:      	movl	%eax, %ecx
     ada:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
     adf:      	testl	%ecx, %ecx
     ae1:      	js	0xf4a <tail_icmp6_handle_ns+0x95a>
     ae7:      	movzwl	0x52(%rsp), %eax
     aec:      	movw	%ax, 0x1a(%rsp)
     af1:      	movl	$0x1a, %eax
     af6:      	leaq	0x78(%rsp), %rdx
     afb:      	movq	%rbx, %rdi
     afe:      	movl	%ebp, %esi
     b00:      	movl	$0x10, %ecx
     b05:      	callq	*%rax
     b07:      	testl	%eax, %eax
     b09:      	js	0xe76 <tail_icmp6_handle_ns+0x886>
     b0f:      	movl	$0x9, %eax
     b14:      	leaq	0x18(%rsp), %rdx
     b19:      	movq	%rbx, %rdi
     b1c:      	movl	%r13d, %esi
     b1f:      	movl	$0x8, %ecx
     b24:      	xorl	%r8d, %r8d
     b27:      	callq	*%rax
     b29:      	testl	%eax, %eax
     b2b:      	js	0xe76 <tail_icmp6_handle_ns+0x886>
     b31:      	movl	$0x1c, %eax
     b36:      	leaq	0x50(%rsp), %rdi
     b3b:      	leaq	0x18(%rsp), %rdx
     b40:      	movl	$0x8, %esi
     b45:      	movl	$0x8, %ecx
     b4a:      	movl	0x24(%rsp), %r8d
     b4f:      	callq	*%rax
     b51:      	movl	%eax, %r13d
     b54:      	movl	$0x1a, %eax
     b59:      	leaq	0x58(%rsp), %rdx
     b5e:      	movq	%rbx, %rdi
     b61:      	movl	0x14(%rsp), %esi
     b65:      	movl	$0x8, %ecx
     b6a:      	callq	*%rax
     b6c:      	testl	%eax, %eax
     b6e:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
     b73:      	js	0xf4a <tail_icmp6_handle_ns+0x95a>
     b79:      	movw	$0x102, 0xc(%rsp)       # imm = 0x102
     b80:      	movzbl	(%rsp), %eax
     b84:      	movb	%al, 0xe(%rsp)
     b88:      	movzbl	0xb(%rsp), %eax
     b8d:      	movb	%al, 0xf(%rsp)
     b91:      	movzbl	0x8(%rsp), %eax
     b96:      	movb	%al, 0x10(%rsp)
     b9a:      	movzbl	0xa(%rsp), %eax
     b9f:      	movb	%al, 0x11(%rsp)
     ba3:      	movzbl	0x4(%rsp), %eax
     ba8:      	movb	%al, 0x12(%rsp)
     bac:      	movzbl	0x9(%rsp), %eax
     bb1:      	movb	%al, 0x13(%rsp)
     bb5:      	movl	$0x9, %eax
     bba:      	leaq	0xc(%rsp), %rdx
     bbf:      	movq	%rbx, %rdi
     bc2:      	movl	0x14(%rsp), %esi
     bc6:      	movl	$0x8, %ecx
     bcb:      	xorl	%r8d, %r8d
     bce:      	callq	*%rax
     bd0:      	movl	%eax, %ecx
     bd2:      	movl	$0xffffff73, %eax       # imm = 0xFFFFFF73
     bd7:      	testl	%ecx, %ecx
     bd9:      	js	0xf4a <tail_icmp6_handle_ns+0x95a>
     bdf:      	leal	0x2a(%r14), %ebp
     be3:      	movl	$0x1c, %eax
     be8:      	leaq	0x58(%rsp), %rdi
     bed:      	leaq	0xc(%rsp), %rdx
     bf2:      	movl	$0x8, %esi
     bf7:      	movl	$0x8, %ecx
     bfc:      	movl	%r13d, %r8d
     bff:      	callq	*%rax
     c01:      	movl	$0xb, %r9d
     c07:      	movq	%rbx, %rdi
     c0a:      	movl	%ebp, %esi
     c0c:      	xorl	%edx, %edx
     c0e:      	movl	%eax, %ecx
     c10:      	movl	$0x10, %r8d
     c16:      	callq	*%r9
     c19:      	testl	%eax, %eax
     c1b:      	js	0xf3e <tail_icmp6_handle_ns+0x94e>
     c21:      	movq	0x78(%rsp), %rax
     c26:      	movq	0x80(%rsp), %rcx
     c2e:      	movq	%rax, 0x38(%rsp)
     c33:      	movq	%rcx, 0x40(%rsp)
     c38:      	movq	(%r12), %rax
     c3c:      	movq	%rax, 0x60(%rsp)
     c41:      	movl	$0x1a, %eax
     c46:      	leal	0x8(%r14), %r12d
     c4a:      	leaq	0x28(%rsp), %rdx
     c4f:      	movq	%rbx, %rdi
     c52:      	movl	%r12d, %esi
     c55:      	movl	$0x10, %ecx
     c5a:      	callq	*%rax
     c5c:      	movl	%eax, %ecx
     c5e:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
     c63:      	testl	%ecx, %ecx
     c65:      	js	0xf4a <tail_icmp6_handle_ns+0x95a>
     c6b:      	movl	$0x1a, %eax
     c70:      	addl	$0x18, %r14d
     c74:      	leaq	0xa8(%rsp), %rdx
     c7c:      	movq	%rbx, %rdi
     c7f:      	movl	%r14d, %esi
     c82:      	movl	$0x10, %ecx
     c87:      	callq	*%rax
     c89:      	testl	%eax, %eax
     c8b:      	js	0xf45 <tail_icmp6_handle_ns+0x955>
     c91:      	movl	$0x9, %eax
     c96:      	leaq	0x38(%rsp), %rdx
     c9b:      	movq	%rbx, %rdi
     c9e:      	movl	%r12d, %esi
     ca1:      	movl	$0x10, %ecx
     ca6:      	xorl	%r8d, %r8d
     ca9:      	callq	*%rax
     cab:      	testl	%eax, %eax
     cad:      	js	0xe76 <tail_icmp6_handle_ns+0x886>
     cb3:      	movl	$0x9, %eax
     cb8:      	leaq	0x28(%rsp), %rdx
     cbd:      	movq	%rbx, %rdi
     cc0:      	movl	%r14d, %esi
     cc3:      	movl	$0x10, %ecx
     cc8:      	xorl	%r8d, %r8d
     ccb:      	callq	*%rax
     ccd:      	testl	%eax, %eax
     ccf:      	js	0xe76 <tail_icmp6_handle_ns+0x886>
     cd5:      	movl	$0x1c, %eax
     cda:      	leaq	0x28(%rsp), %rdi
     cdf:      	leaq	0x38(%rsp), %rdx
     ce4:      	movl	$0x10, %esi
     ce9:      	movl	$0x10, %ecx
     cee:      	xorl	%r8d, %r8d
     cf1:      	callq	*%rax
     cf3:      	movl	$0xb, %r14d
     cf9:      	movq	%rbx, %rdi
     cfc:      	movl	%ebp, %esi
     cfe:      	xorl	%edx, %edx
     d00:      	movl	%eax, %ecx
     d02:      	movl	$0x10, %r8d
     d08:      	callq	*%r14
     d0b:      	movl	%eax, %ecx
     d0d:      	movl	$0xffffff66, %eax       # imm = 0xFFFFFF66
     d12:      	testl	%ecx, %ecx
     d14:      	js	0xf4a <tail_icmp6_handle_ns+0x95a>
     d1a:      	movl	$0x1c, %eax
     d1f:      	leaq	0xa8(%rsp), %rdi
     d27:      	leaq	0x28(%rsp), %rdx
     d2c:      	movl	$0x10, %esi
     d31:      	movl	$0x10, %ecx
     d36:      	xorl	%r8d, %r8d
     d39:      	callq	*%rax
     d3b:      	movq	%rbx, %rdi
     d3e:      	movl	%ebp, %esi
     d40:      	xorl	%edx, %edx
     d42:      	movl	%eax, %ecx
     d44:      	movl	$0x10, %r8d
     d4a:      	callq	*%r14
     d4d:      	movl	%eax, %ecx
     d4f:      	movl	$0xffffff66, %eax       # imm = 0xFFFFFF66
     d54:      	testl	%ecx, %ecx
     d56:      	js	0xf4a <tail_icmp6_handle_ns+0x95a>
     d5c:      	movl	$0x1a, %eax
     d61:      	leaq	0x68(%rsp), %rdx
     d66:      	movq	%rbx, %rdi
     d69:      	movl	$0x6, %esi
     d6e:      	movl	$0x6, %ecx
     d73:      	callq	*%rax
     d75:      	movl	%eax, %ecx
     d77:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
     d7c:      	testl	%ecx, %ecx
     d7e:      	js	0xf4a <tail_icmp6_handle_ns+0x95a>
     d84:      	movl	$0x9, %eax
     d89:      	leaq	0x68(%rsp), %rdx
     d8e:      	movq	%rbx, %rdi
     d91:      	xorl	%esi, %esi
     d93:      	movl	$0x6, %ecx
     d98:      	xorl	%r8d, %r8d
     d9b:      	callq	*%rax
     d9d:      	testl	%eax, %eax
     d9f:      	js	0xe76 <tail_icmp6_handle_ns+0x886>
     da5:      	movl	$0x9, %eax
     daa:      	leaq	0x60(%rsp), %rdx
     daf:      	xorl	%ebp, %ebp
     db1:      	movq	%rbx, %rdi
     db4:      	movl	$0x6, %esi
     db9:      	movl	$0x6, %ecx
     dbe:      	xorl	%r8d, %r8d
     dc1:      	callq	*%rax
     dc3:      	movl	%eax, %ecx
     dc5:      	movl	$0xffffff73, %eax       # imm = 0xFFFFFF73
     dca:      	testl	%ecx, %ecx
     dcc:      	js	0xf4a <tail_icmp6_handle_ns+0x95a>
     dd2:      	movq	0x10(%rbx), %rax
     dd6:      	testq	%rax, %rax
     dd9:      	je	0xde1 <tail_icmp6_handle_ns+0x7f1>
     ddb:      	movl	0xe0(%rax), %ebp
     de1:      	movl	$0x17, %eax
     de6:      	movl	%ebp, %edi
     de8:      	xorl	%esi, %esi
     dea:      	callq	*%rax
     dec:      	jmp	0xf4a <tail_icmp6_handle_ns+0x95a>
     df1:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
     df6:      	jmp	0xdfd <tail_icmp6_handle_ns+0x80d>
     df8:      	movl	$0xffffff6a, %eax       # imm = 0xFFFFFF6A
     dfd:      	movl	%eax, %ecx
     dff:      	negl	%ecx
     e01:      	cmovsl	%eax, %ecx
     e04:      	movl	0x70(%rbx), %ebx
     e07:      	movabsq	$0x6701960000, %rax     # imm = 0x6701960000
     e11:      	movq	%rax, 0x28(%rsp)
     e16:      	movb	%cl, 0x28(%rsp)
     e1a:      	andb	$0x3, %r15b
     e1e:      	movb	%r15b, 0x29(%rsp)
     e23:      	movl	$0x1, %eax
     e28:      	movq	(%rip), %rdi            # 0xe2f <tail_icmp6_handle_ns+0x83f>
     e2f:      	leaq	0x28(%rsp), %rsi
     e34:      	callq	*%rax
     e36:      	testq	%rax, %rax
     e39:      	je	0xe44 <tail_icmp6_handle_ns+0x854>
     e3b:      	incq	(%rax)
     e3e:      	addq	%rbx, 0x8(%rax)
     e42:      	jmp	0xe6c <tail_icmp6_handle_ns+0x87c>
     e44:      	movq	$0x1, 0x38(%rsp)
     e4d:      	movq	%rbx, 0x40(%rsp)
     e52:      	movl	$0x2, %eax
     e57:      	movq	(%rip), %rdi            # 0xe5e <tail_icmp6_handle_ns+0x86e>
     e5e:      	leaq	0x28(%rsp), %rsi
     e63:      	leaq	0x38(%rsp), %rdx
     e68:      	xorl	%ecx, %ecx
     e6a:      	callq	*%rax
     e6c:      	movl	$0x2, %eax
     e71:      	jmp	0xf5b <tail_icmp6_handle_ns+0x96b>
     e76:      	movl	$0xffffff73, %eax       # imm = 0xFFFFFF73
     e7b:      	jmp	0xf4a <tail_icmp6_handle_ns+0x95a>
     e80:      	movl	$0x26, %eax
     e85:      	movl	0x70(%rbx), %esi
     e88:      	addl	$0x8, %esi
     e8b:      	movq	%rbx, %rdi
     e8e:      	xorl	%edx, %edx
     e90:      	callq	*%rax
     e92:      	movl	%eax, %ecx
     e94:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
     e99:      	testl	%ecx, %ecx
     e9b:      	js	0xf4a <tail_icmp6_handle_ns+0x95a>
     ea1:      	movq	0x50(%rbx), %rdx
     ea5:      	movq	0xd0(%rbx), %rcx
     eac:      	leaq	0x36(%rcx), %rsi
     eb0:      	cmpq	%rdx, %rsi
     eb3:      	ja	0xf4a <tail_icmp6_handle_ns+0x95a>
     eb9:      	movbew	0x12(%rcx), %si
     ebf:      	addl	$0x8, %esi
     ec2:      	movbew	%si, 0x12(%rcx)
     ec8:      	leaq	0x56(%rcx), %rsi
     ecc:      	cmpq	%rdx, %rsi
     ecf:      	ja	0xf4a <tail_icmp6_handle_ns+0x95a>
     ed1:      	movq	$0x0, 0x4e(%rcx)
     ed9:      	movl	$0x8000000, %ecx        # imm = 0x8000000
     ede:      	jmp	0x700 <tail_icmp6_handle_ns+0x110>
     ee3:      	movl	$0x26, %eax
     ee8:      	movl	0x70(%rbx), %esi
     eeb:      	addl	$0x8, %esi
     eee:      	movq	%rbx, %rdi
     ef1:      	xorl	%edx, %edx
     ef3:      	callq	*%rax
     ef5:      	movl	%eax, %ecx
     ef7:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
     efc:      	testl	%ecx, %ecx
     efe:      	js	0xf4a <tail_icmp6_handle_ns+0x95a>
     f00:      	movq	0x50(%rbx), %rdx
     f04:      	movq	0xd0(%rbx), %rcx
     f0b:      	leaq	0x36(%rcx), %rsi
     f0f:      	cmpq	%rdx, %rsi
     f12:      	ja	0xf4a <tail_icmp6_handle_ns+0x95a>
     f14:      	movbew	0x12(%rcx), %si
     f1a:      	addl	$0x8, %esi
     f1d:      	movbew	%si, 0x12(%rcx)
     f23:      	leaq	0x56(%rcx), %rsi
     f27:      	cmpq	%rdx, %rsi
     f2a:      	ja	0xf4a <tail_icmp6_handle_ns+0x95a>
     f2c:      	movq	$0x0, 0x4e(%rcx)
     f34:      	movl	$0x8000000, %ecx        # imm = 0x8000000
     f39:      	jmp	0xab9 <tail_icmp6_handle_ns+0x4c9>
     f3e:      	movl	$0xffffff66, %eax       # imm = 0xFFFFFF66
     f43:      	jmp	0xf4a <tail_icmp6_handle_ns+0x95a>
     f45:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
     f4a:      	testl	%eax, %eax
     f4c:      	js	0xdfd <tail_icmp6_handle_ns+0x80d>
     f52:      	cmpl	$0x2, %eax
     f55:      	je	0xdfd <tail_icmp6_handle_ns+0x80d>
     f5b:      	addq	$0xb8, %rsp
     f62:      	popq	%rbx
     f63:      	popq	%r12
     f65:      	popq	%r13
     f67:      	popq	%r14
     f69:      	popq	%r15
     f6b:      	popq	%rbp
     f6c:      	retq
