
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/otel/ruby_tracer.native.o:	file format elf64-x86-64

Disassembly of section perf_event/unwind_ruby:

0000000000000000 <perf_unwind_ruby>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x98, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x30(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <perf_unwind_ruby+0x23>
      23:      	leaq	0x30(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x3ba <perf_unwind_ruby+0x3ba>
      38:      	movq	%rax, %r14
      3b:      	movl	(%rax), %eax
      3d:      	movl	%eax, 0x84(%rsp)
      44:      	movq	(%rip), %rdi            # 0x4b <perf_unwind_ruby+0x4b>
      4b:      	leaq	0x84(%rsp), %rsi
      53:      	movl	$0x1, %eax
      58:      	callq	*%rax
      5a:      	testq	%rax, %rax
      5d:      	je	0x109 <perf_unwind_ruby+0x109>
      63:      	movq	%rax, %r15
      66:      	movl	$0x35, 0x8(%rsp)
      6e:      	movq	(%rip), %rdi            # 0x75 <perf_unwind_ruby+0x75>
      75:      	leaq	0x8(%rsp), %rsi
      7a:      	movl	$0x1, %eax
      7f:      	callq	*%rax
      81:      	testq	%rax, %rax
      84:      	je	0x146 <perf_unwind_ruby+0x146>
      8a:      	incq	(%rax)
      8d:      	movq	$0x0, 0x78(%rsp)
      96:      	cmpq	$0x0, 0x8(%r15)
      9b:      	jne	0x16a <perf_unwind_ruby+0x16a>
      a1:      	cmpl	$0x30000, (%r15)        # imm = 0x30000
      a8:      	jb	0x333 <perf_unwind_ruby+0x333>
      ae:      	movq	$0x0, 0x30(%rsp)
      b7:      	movq	0x10(%r15), %rax
      bb:      	leaq	0x30(%rsp), %rdi
      c0:      	movl	$0x8, %ecx
      c5:      	movl	$0x70, %r8d
      cb:      	movq	0x10(%r15), %rdx
      cf:      	movl	$0x8, %esi
      d4:      	callq	*%r8
      d7:      	testq	%rax, %rax
      da:      	jne	0x298 <perf_unwind_ruby+0x298>
      e0:      	movzwl	0x24(%r15), %eax
      e5:      	addq	0x30(%rsp), %rax
      ea:      	leaq	0x78(%rsp), %rdi
      ef:      	movl	$0x8, %ecx
      f4:      	movl	$0x70, %r8d
      fa:      	movzwl	0x24(%r15), %edx
      ff:      	addq	0x30(%rsp), %rdx
     104:      	jmp	0x34b <perf_unwind_ruby+0x34b>
     109:      	movq	(%rip), %r15            # 0x110 <perf_unwind_ruby+0x110>
     110:      	cmpl	$0x0, (%r15)
     114:      	jne	0x11da <perf_unwind_ruby+0x11da>
     11a:      	movl	$0x49, 0x8(%rsp)
     122:      	movq	(%rip), %rdi            # 0x129 <perf_unwind_ruby+0x129>
     129:      	leaq	0x8(%rsp), %rsi
     12e:      	movl	$0x1, %eax
     133:      	callq	*%rax
     135:      	testq	%rax, %rax
     138:      	je	0x29d <perf_unwind_ruby+0x29d>
     13e:      	incq	(%rax)
     141:      	jmp	0x2a7 <perf_unwind_ruby+0x2a7>
     146:      	movq	(%rip), %rax            # 0x14d <perf_unwind_ruby+0x14d>
     14d:      	cmpl	$0x0, (%rax)
     150:      	jne	0x1511 <perf_unwind_ruby+0x1511>
     156:      	movq	$0x0, 0x78(%rsp)
     15f:      	cmpq	$0x0, 0x8(%r15)
     164:      	je	0xa1 <perf_unwind_ruby+0xa1>
     16a:      	movl	$0x23, %eax
     16f:      	callq	*%rax
     171:      	movq	(%rip), %rcx            # 0x178 <perf_unwind_ruby+0x178>
     178:      	addq	(%rcx), %rax
     17b:      	leaq	0x8(%rsp), %rdi
     180:      	movl	$0x8, %ecx
     185:      	movl	$0x71, %r8d
     18b:      	movl	$0x8, %esi
     190:      	movq	%rax, %rdx
     193:      	callq	*%r8
     196:      	testq	%rax, %rax
     199:      	je	0x25e <perf_unwind_ruby+0x25e>
     19f:      	movq	(%rip), %rbx            # 0x1a6 <perf_unwind_ruby+0x1a6>
     1a6:      	cmpl	$0x0, (%rbx)
     1a9:      	jne	0x12c0 <perf_unwind_ruby+0x12c0>
     1af:      	movl	$0x4, 0x20(%rsp)
     1b7:      	movq	(%rip), %rdi            # 0x1be <perf_unwind_ruby+0x1be>
     1be:      	leaq	0x20(%rsp), %rsi
     1c3:      	movl	$0x1, %eax
     1c8:      	callq	*%rax
     1ca:      	testq	%rax, %rax
     1cd:      	je	0x373 <perf_unwind_ruby+0x373>
     1d3:      	incq	(%rax)
     1d6:      	cmpl	$0x0, (%rbx)
     1d9:      	je	0x37c <perf_unwind_ruby+0x37c>
     1df:      	movabsq	$0x6b6f6f6c206c6f62, %rax # imm = 0x6B6F6F6C206C6F62
     1e9:      	movq	%rax, 0x58(%rsp)
     1ee:      	movabsq	$0x6d797320534c5420, %rax # imm = 0x6D797320534C5420
     1f8:      	movq	%rax, 0x50(%rsp)
     1fd:      	movabsq	$0x726f662065736162, %rax # imm = 0x726F662065736162
     207:      	movq	%rax, 0x48(%rsp)
     20c:      	movabsq	$0x2044535420746567, %rax # imm = 0x2044535420746567
     216:      	movq	%rax, 0x40(%rsp)
     21b:      	movabsq	$0x206f742064656c69, %rax # imm = 0x206F742064656C69
     225:      	movq	%rax, 0x38(%rsp)
     22a:      	movabsq	$0x6166203a79627572, %rax # imm = 0x6166203A79627572
     234:      	movq	%rax, 0x30(%rsp)
     239:      	movl	$0xa7075, 0x60(%rsp)    # imm = 0xA7075
     241:      	leaq	0x30(%rsp), %rdi
     246:      	movl	$0x34, %eax
     24b:      	movl	$0x6, %ecx
     250:      	movl	$0x34, %esi
     255:      	xorl	%eax, %eax
     257:      	callq	*%rcx
     259:      	jmp	0x37c <perf_unwind_ruby+0x37c>
     25e:      	movq	0x8(%r15), %rdx
     262:      	movq	(%rip), %r13            # 0x269 <perf_unwind_ruby+0x269>
     269:      	addq	0x8(%rsp), %rdx
     26e:      	cmpl	$0x0, (%r13)
     273:      	jne	0x15a0 <perf_unwind_ruby+0x15a0>
     279:      	leaq	0x78(%rsp), %rdi
     27e:      	movl	$0x8, %eax
     283:      	movl	$0x70, %ecx
     288:      	movl	$0x8, %esi
     28d:      	callq	*%rcx
     28f:      	testq	%rax, %rax
     292:      	je	0x3d1 <perf_unwind_ruby+0x3d1>
     298:      	xorl	%r13d, %r13d
     29b:      	jmp	0x2ad <perf_unwind_ruby+0x2ad>
     29d:      	cmpl	$0x0, (%r15)
     2a1:      	jne	0x1627 <perf_unwind_ruby+0x1627>
     2a7:      	movl	$0xbb8, %r13d           # imm = 0xBB8
     2ad:      	movl	$0x1, %ebp
     2b2:      	movl	%r13d, 0xf2c(%r14)
     2b9:      	movl	$0x0, 0x30(%rsp)
     2c1:      	movq	(%rip), %rdi            # 0x2c8 <perf_unwind_ruby+0x2c8>
     2c8:      	leaq	0x30(%rsp), %rsi
     2cd:      	movl	$0x1, %eax
     2d2:      	callq	*%rax
     2d4:      	testq	%rax, %rax
     2d7:      	je	0x31b <perf_unwind_ruby+0x31b>
     2d9:      	movzbl	0x1384(%rax), %ecx
     2e0:      	cmpb	$0x1d, %cl
     2e3:      	jb	0x39d <perf_unwind_ruby+0x39d>
     2e9:      	movq	%rax, %r14
     2ec:      	movl	$0x5, 0xf2c(%rax)
     2f6:      	movl	$0x44, 0x8(%rsp)
     2fe:      	movq	(%rip), %rdi            # 0x305 <perf_unwind_ruby+0x305>
     305:      	leaq	0x8(%rsp), %rsi
     30a:      	movl	$0x1, %eax
     30f:      	callq	*%rax
     311:      	testq	%rax, %rax
     314:      	je	0x380 <perf_unwind_ruby+0x380>
     316:      	incq	(%rax)
     319:      	jmp	0x390 <perf_unwind_ruby+0x390>
     31b:      	movq	(%rip), %rsi            # 0x322 <perf_unwind_ruby+0x322>
     322:      	xorl	%eax, %eax
     324:      	movl	$0xc, %ecx
     329:      	movq	%rbx, %rdi
     32c:      	xorl	%edx, %edx
     32e:      	jmp	0x3b8 <perf_unwind_ruby+0x3b8>
     333:      	movq	0x10(%r15), %rax
     337:      	leaq	0x78(%rsp), %rdi
     33c:      	movl	$0x8, %ecx
     341:      	movl	$0x70, %r8d
     347:      	movq	0x10(%r15), %rdx
     34b:      	movl	$0x8, %esi
     350:      	callq	*%r8
     353:      	xorl	%r13d, %r13d
     356:      	movl	$0x1, %ebp
     35b:      	testq	%rax, %rax
     35e:      	jne	0x2b2 <perf_unwind_ruby+0x2b2>
     364:      	movq	0x78(%rsp), %r12
     369:      	testq	%r12, %r12
     36c:      	jne	0x3ea <perf_unwind_ruby+0x3ea>
     36e:      	jmp	0x2b2 <perf_unwind_ruby+0x2b2>
     373:      	cmpl	$0x0, (%rbx)
     376:      	jne	0x16f2 <perf_unwind_ruby+0x16f2>
     37c:      	xorl	%eax, %eax
     37e:      	jmp	0x3bf <perf_unwind_ruby+0x3bf>
     380:      	movq	(%rip), %rax            # 0x387 <perf_unwind_ruby+0x387>
     387:      	cmpl	$0x0, (%rax)
     38a:      	jne	0x1776 <perf_unwind_ruby+0x1776>
     390:      	movq	%r14, %rax
     393:      	movzbl	0x1384(%r14), %ecx
     39b:      	xorl	%ebp, %ebp
     39d:      	incb	%cl
     39f:      	movb	%cl, 0x1384(%rax)
     3a5:      	movl	%ebp, %eax
     3a7:      	movq	(%rip), %rsi            # 0x3ae <perf_unwind_ruby+0x3ae>
     3ae:      	movl	$0xc, %ecx
     3b3:      	movq	%rbx, %rdi
     3b6:      	movl	%ebp, %edx
     3b8:      	callq	*%rcx
     3ba:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     3bf:      	addq	$0x98, %rsp
     3c6:      	popq	%rbx
     3c7:      	popq	%r12
     3c9:      	popq	%r13
     3cb:      	popq	%r14
     3cd:      	popq	%r15
     3cf:      	popq	%rbp
     3d0:      	retq
     3d1:      	cmpl	$0x0, (%r13)
     3d6:      	jne	0x187b <perf_unwind_ruby+0x187b>
     3dc:      	movq	0x78(%rsp), %r12
     3e1:      	testq	%r12, %r12
     3e4:      	je	0x298 <perf_unwind_ruby+0x298>
     3ea:      	movq	0xf68(%r14), %rax
     3f1:      	movq	%rax, 0x8(%rsp)
     3f6:      	testq	%rax, %rax
     3f9:      	je	0x501 <perf_unwind_ruby+0x501>
     3ff:      	movq	0xf70(%r14), %r13
     406:      	testq	%r13, %r13
     409:      	je	0x501 <perf_unwind_ruby+0x501>
     40f:      	movq	%r13, %r12
     412:      	movq	$0x0, 0x18(%rsp)
     41b:      	movq	$0x0, 0x20(%rsp)
     424:      	movzbl	0x1c(%r15), %ecx
     429:      	addq	%rax, %rcx
     42c:      	leaq	0x20(%rsp), %rdi
     431:      	movl	$0x8, %eax
     436:      	movl	$0x70, %r8d
     43c:      	movzbl	0x1c(%r15), %edx
     441:      	addq	0x8(%rsp), %rdx
     446:      	movl	$0x8, %esi
     44b:      	callq	*%r8
     44e:      	movzbl	0x1b(%r15), %eax
     453:      	addq	0x8(%rsp), %rax
     458:      	leaq	0x18(%rsp), %rdi
     45d:      	movl	$0x8, %ecx
     462:      	movl	$0x70, %r8d
     468:      	movzbl	0x1b(%r15), %edx
     46d:      	addq	0x8(%rsp), %rdx
     472:      	movl	$0x8, %esi
     477:      	callq	*%r8
     47a:      	cmpq	$0x0, 0x18(%rsp)
     480:      	je	0x56f <perf_unwind_ruby+0x56f>
     486:      	movq	0x20(%rsp), %rax
     48b:      	testq	%rax, %rax
     48e:      	je	0x56f <perf_unwind_ruby+0x56f>
     494:      	movzbl	0x1f(%r15), %ecx
     499:      	addq	%rcx, %rax
     49c:      	leaq	0x10(%rsp), %rdi
     4a1:      	movl	$0x8, %ecx
     4a6:      	movl	$0x70, %r8d
     4ac:      	movzbl	0x1f(%r15), %edx
     4b1:      	addq	0x20(%rsp), %rdx
     4b6:      	movl	$0x8, %esi
     4bb:      	callq	*%r8
     4be:      	testq	%rax, %rax
     4c1:      	je	0x86f <perf_unwind_ruby+0x86f>
     4c7:      	movq	(%rip), %r15            # 0x4ce <perf_unwind_ruby+0x4ce>
     4ce:      	cmpl	$0x0, (%r15)
     4d2:      	jne	0x1bdc <perf_unwind_ruby+0x1bdc>
     4d8:      	movl	$0x4e, (%rsp)
     4df:      	movq	(%rip), %rdi            # 0x4e6 <perf_unwind_ruby+0x4e6>
     4e6:      	movq	%rsp, %rsi
     4e9:      	movl	$0x1, %eax
     4ee:      	callq	*%rax
     4f0:      	testq	%rax, %rax
     4f3:      	je	0x8de <perf_unwind_ruby+0x8de>
     4f9:      	incq	(%rax)
     4fc:      	jmp	0x8e8 <perf_unwind_ruby+0x8e8>
     501:      	movzbl	0x18(%r15), %eax
     506:      	addq	%r12, %rax
     509:      	leaq	0x20(%rsp), %rdi
     50e:      	movl	$0x8, %ecx
     513:      	movl	$0x70, %r8d
     519:      	movzbl	0x18(%r15), %edx
     51e:      	addq	%r12, %rdx
     521:      	movl	$0x8, %esi
     526:      	callq	*%r8
     529:      	testq	%rax, %rax
     52c:      	je	0x772 <perf_unwind_ruby+0x772>
     532:      	movq	(%rip), %r15            # 0x539 <perf_unwind_ruby+0x539>
     539:      	cmpl	$0x0, (%r15)
     53d:      	jne	0x1b6c <perf_unwind_ruby+0x1b6c>
     543:      	movl	$0x4a, 0x18(%rsp)
     54b:      	movq	(%rip), %rdi            # 0x552 <perf_unwind_ruby+0x552>
     552:      	leaq	0x18(%rsp), %rsi
     557:      	movl	$0x1, %eax
     55c:      	callq	*%rax
     55e:      	testq	%rax, %rax
     561:      	je	0x858 <perf_unwind_ruby+0x858>
     567:      	incq	(%rax)
     56a:      	jmp	0x862 <perf_unwind_ruby+0x862>
     56f:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
     576:      	jae	0x7e0 <perf_unwind_ruby+0x7e0>
     57c:      	movq	0x8(%rsp), %rax
     581:      	xorl	%r13d, %r13d
     584:      	movl	$0x1, %ebp
     589:      	movq	%r12, %rcx
     58c:      	cmpq	%rax, %r12
     58f:      	jbe	0x2b2 <perf_unwind_ruby+0x2b2>
     595:      	movzbl	0x1e(%r15), %ecx
     59a:      	addq	%rcx, %rax
     59d:      	movq	%rax, 0x8(%rsp)
     5a2:      	movq	$0x0, 0x18(%rsp)
     5ab:      	movq	$0x0, 0x20(%rsp)
     5b4:      	movzbl	0x1c(%r15), %ecx
     5b9:      	addq	%rax, %rcx
     5bc:      	leaq	0x20(%rsp), %rdi
     5c1:      	movl	$0x8, %eax
     5c6:      	movl	$0x70, %r8d
     5cc:      	movzbl	0x1c(%r15), %edx
     5d1:      	addq	0x8(%rsp), %rdx
     5d6:      	movl	$0x8, %esi
     5db:      	callq	*%r8
     5de:      	movzbl	0x1b(%r15), %eax
     5e3:      	addq	0x8(%rsp), %rax
     5e8:      	leaq	0x18(%rsp), %rdi
     5ed:      	movl	$0x8, %ecx
     5f2:      	movl	$0x70, %r8d
     5f8:      	movzbl	0x1b(%r15), %edx
     5fd:      	addq	0x8(%rsp), %rdx
     602:      	movl	$0x8, %esi
     607:      	callq	*%r8
     60a:      	cmpq	$0x0, 0x18(%rsp)
     610:      	je	0x9d8 <perf_unwind_ruby+0x9d8>
     616:      	movq	0x20(%rsp), %rax
     61b:      	testq	%rax, %rax
     61e:      	je	0x9d8 <perf_unwind_ruby+0x9d8>
     624:      	movzbl	0x1f(%r15), %ecx
     629:      	addq	%rcx, %rax
     62c:      	leaq	0x10(%rsp), %rdi
     631:      	movl	$0x8, %ecx
     636:      	movl	$0x70, %r8d
     63c:      	movzbl	0x1f(%r15), %edx
     641:      	addq	0x20(%rsp), %rdx
     646:      	movl	$0x8, %esi
     64b:      	callq	*%r8
     64e:      	testq	%rax, %rax
     651:      	jne	0x4c7 <perf_unwind_ruby+0x4c7>
     657:      	movzbl	0x21(%r15), %eax
     65c:      	addq	0x10(%rsp), %rax
     661:      	leaq	0x68(%rsp), %rdi
     666:      	movl	$0x8, %ecx
     66b:      	movl	$0x70, %r8d
     671:      	movzbl	0x21(%r15), %edx
     676:      	addq	0x10(%rsp), %rdx
     67b:      	movl	$0x8, %esi
     680:      	callq	*%r8
     683:      	testq	%rax, %rax
     686:      	jne	0x8a4 <perf_unwind_ruby+0x8a4>
     68c:      	movzbl	0x22(%r15), %eax
     691:      	addq	0x10(%rsp), %rax
     696:      	leaq	0x2c(%rsp), %rdi
     69b:      	movl	$0x4, %ecx
     6a0:      	movl	$0x70, %r8d
     6a6:      	movzbl	0x22(%r15), %edx
     6ab:      	addq	0x10(%rsp), %rdx
     6b0:      	movl	$0x4, %esi
     6b5:      	callq	*%r8
     6b8:      	testq	%rax, %rax
     6bb:      	jne	0xc08 <perf_unwind_ruby+0xc08>
     6c1:      	movzbl	0x23(%r15), %ecx
     6c6:      	testq	%rcx, %rcx
     6c9:      	je	0x122c <perf_unwind_ruby+0x122c>
     6cf:      	movq	0x18(%rsp), %rax
     6d4:      	subq	0x68(%rsp), %rax
     6d9:      	xorl	%edx, %edx
     6db:      	divq	%rcx
     6de:      	movl	0x2c(%rsp), %ecx
     6e2:      	cmpq	%rcx, %rax
     6e5:      	jbe	0x122c <perf_unwind_ruby+0x122c>
     6eb:      	movq	(%rip), %rax            # 0x6f2 <perf_unwind_ruby+0x6f2>
     6f2:      	cmpl	$0x0, (%rax)
     6f5:      	je	0x9e5 <perf_unwind_ruby+0x9e5>
     6fb:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
     705:      	movq	%rax, 0x55(%rsp)
     70a:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
     714:      	movq	%rax, 0x50(%rsp)
     719:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
     723:      	movq	%rax, 0x48(%rsp)
     728:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
     732:      	movq	%rax, 0x40(%rsp)
     737:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
     741:      	movq	%rax, 0x38(%rsp)
     746:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
     750:      	movq	%rax, 0x30(%rsp)
     755:      	leaq	0x30(%rsp), %rdi
     75a:      	movl	$0x2d, %eax
     75f:      	movl	$0x6, %ecx
     764:      	movl	$0x2d, %esi
     769:      	xorl	%eax, %eax
     76b:      	callq	*%rcx
     76d:      	jmp	0x9e5 <perf_unwind_ruby+0x9e5>
     772:      	movzbl	0x19(%r15), %eax
     777:      	addq	%r12, %rax
     77a:      	leaq	0x10(%rsp), %rdi
     77f:      	movl	$0x8, %ecx
     784:      	movl	$0x70, %r8d
     78a:      	movzbl	0x19(%r15), %edx
     78f:      	addq	%r12, %rdx
     792:      	movl	$0x8, %esi
     797:      	callq	*%r8
     79a:      	testq	%rax, %rax
     79d:      	je	0x8f5 <perf_unwind_ruby+0x8f5>
     7a3:      	movq	(%rip), %r15            # 0x7aa <perf_unwind_ruby+0x7aa>
     7aa:      	cmpl	$0x0, (%r15)
     7ae:      	jne	0x1c85 <perf_unwind_ruby+0x1c85>
     7b4:      	movl	$0x4b, 0x18(%rsp)
     7bc:      	movq	(%rip), %rdi            # 0x7c3 <perf_unwind_ruby+0x7c3>
     7c3:      	leaq	0x18(%rsp), %rsi
     7c8:      	movl	$0x1, %eax
     7cd:      	callq	*%rax
     7cf:      	testq	%rax, %rax
     7d2:      	je	0x9c1 <perf_unwind_ruby+0x9c1>
     7d8:      	incq	(%rax)
     7db:      	jmp	0x9cb <perf_unwind_ruby+0x9cb>
     7e0:      	movq	$0x0, (%rsp)
     7e8:      	movzbl	0x1d(%r15), %eax
     7ed:      	addq	0x8(%rsp), %rax
     7f2:      	movq	%rsp, %rdi
     7f5:      	movl	$0x8, %ecx
     7fa:      	movl	$0x70, %r8d
     800:      	movzbl	0x1d(%r15), %edx
     805:      	addq	0x8(%rsp), %rdx
     80a:      	movl	$0x8, %esi
     80f:      	callq	*%r8
     812:      	testq	%rax, %rax
     815:      	je	0x987 <perf_unwind_ruby+0x987>
     81b:      	movq	(%rip), %r15            # 0x822 <perf_unwind_ruby+0x822>
     822:      	cmpl	$0x0, (%r15)
     826:      	jne	0x1d59 <perf_unwind_ruby+0x1d59>
     82c:      	movl	$0x4d, 0x74(%rsp)
     834:      	movq	(%rip), %rdi            # 0x83b <perf_unwind_ruby+0x83b>
     83b:      	leaq	0x74(%rsp), %rsi
     840:      	movl	$0x1, %eax
     845:      	callq	*%rax
     847:      	testq	%rax, %rax
     84a:      	je	0xc42 <perf_unwind_ruby+0xc42>
     850:      	incq	(%rax)
     853:      	jmp	0xc4c <perf_unwind_ruby+0xc4c>
     858:      	cmpl	$0x0, (%r15)
     85c:      	jne	0x1cde <perf_unwind_ruby+0x1cde>
     862:      	movl	$0xbb9, %r13d           # imm = 0xBB9
     868:      	xorl	%ebp, %ebp
     86a:      	jmp	0x2b2 <perf_unwind_ruby+0x2b2>
     86f:      	movzbl	0x21(%r15), %eax
     874:      	addq	0x10(%rsp), %rax
     879:      	leaq	0x68(%rsp), %rdi
     87e:      	movl	$0x8, %ecx
     883:      	movl	$0x70, %r8d
     889:      	movzbl	0x21(%r15), %edx
     88e:      	addq	0x10(%rsp), %rdx
     893:      	movl	$0x8, %esi
     898:      	callq	*%r8
     89b:      	testq	%rax, %rax
     89e:      	je	0xbd3 <perf_unwind_ruby+0xbd3>
     8a4:      	movq	(%rip), %r15            # 0x8ab <perf_unwind_ruby+0x8ab>
     8ab:      	cmpl	$0x0, (%r15)
     8af:      	jne	0x1ec1 <perf_unwind_ruby+0x1ec1>
     8b5:      	movl	$0x4f, (%rsp)
     8bc:      	movq	(%rip), %rdi            # 0x8c3 <perf_unwind_ruby+0x8c3>
     8c3:      	movq	%rsp, %rsi
     8c6:      	movl	$0x1, %eax
     8cb:      	callq	*%rax
     8cd:      	testq	%rax, %rax
     8d0:      	je	0xc59 <perf_unwind_ruby+0xc59>
     8d6:      	incq	(%rax)
     8d9:      	jmp	0xc63 <perf_unwind_ruby+0xc63>
     8de:      	cmpl	$0x0, (%r15)
     8e2:      	jne	0x1f21 <perf_unwind_ruby+0x1f21>
     8e8:      	movl	$0xbbd, %r13d           # imm = 0xBBD
     8ee:      	xorl	%ebp, %ebp
     8f0:      	jmp	0x2b2 <perf_unwind_ruby+0x2b2>
     8f5:      	movq	0x20(%rsp), %r13
     8fa:      	movzbl	0x23(%r15), %eax
     8ff:      	movq	%rax, 0x88(%rsp)
     907:      	movq	0x10(%rsp), %rbp
     90c:      	movzbl	0x1e(%r15), %eax
     911:      	movq	%rax, 0x90(%rsp)
     919:      	movzbl	0x1a(%r15), %eax
     91e:      	addq	%r12, %rax
     921:      	leaq	0x8(%rsp), %rdi
     926:      	movl	$0x8, %ecx
     92b:      	movl	$0x70, %r8d
     931:      	movzbl	0x1a(%r15), %edx
     936:      	addq	%r12, %rdx
     939:      	movl	$0x8, %esi
     93e:      	callq	*%r8
     941:      	testq	%rax, %rax
     944:      	je	0xc70 <perf_unwind_ruby+0xc70>
     94a:      	movq	(%rip), %r15            # 0x951 <perf_unwind_ruby+0x951>
     951:      	cmpl	$0x0, (%r15)
     955:      	jne	0x2193 <perf_unwind_ruby+0x2193>
     95b:      	movl	$0x4c, 0x18(%rsp)
     963:      	movq	(%rip), %rdi            # 0x96a <perf_unwind_ruby+0x96a>
     96a:      	leaq	0x18(%rsp), %rsi
     96f:      	movl	$0x1, %eax
     974:      	callq	*%rax
     976:      	testq	%rax, %rax
     979:      	je	0xce3 <perf_unwind_ruby+0xce3>
     97f:      	incq	(%rax)
     982:      	jmp	0xced <perf_unwind_ruby+0xced>
     987:      	movl	(%rsp), %eax
     98a:      	notl	%eax
     98c:      	testl	$0x140, %eax            # imm = 0x140
     991:      	je	0x57c <perf_unwind_ruby+0x57c>
     997:      	movzbl	0x1e(%r15), %eax
     99c:      	addq	0x8(%rsp), %rax
     9a1:      	movq	%rax, 0x8(%rsp)
     9a6:      	movl	$0x1, %ebp
     9ab:      	movq	%rax, 0xf68(%r14)
     9b2:      	movq	%r12, 0xf70(%r14)
     9b9:      	xorl	%r13d, %r13d
     9bc:      	jmp	0x2b2 <perf_unwind_ruby+0x2b2>
     9c1:      	cmpl	$0x0, (%r15)
     9c5:      	jne	0x21e2 <perf_unwind_ruby+0x21e2>
     9cb:      	movl	$0xbba, %r13d           # imm = 0xBBA
     9d1:      	xorl	%ebp, %ebp
     9d3:      	jmp	0x2b2 <perf_unwind_ruby+0x2b2>
     9d8:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
     9df:      	jae	0xc93 <perf_unwind_ruby+0xc93>
     9e5:      	movq	0x8(%rsp), %rax
     9ea:      	movq	%r12, %rcx
     9ed:      	cmpq	%rax, %r12
     9f0:      	jbe	0x2b2 <perf_unwind_ruby+0x2b2>
     9f6:      	movzbl	0x1e(%r15), %ecx
     9fb:      	addq	%rcx, %rax
     9fe:      	movq	%rax, 0x8(%rsp)
     a03:      	movq	$0x0, 0x18(%rsp)
     a0c:      	movq	$0x0, 0x20(%rsp)
     a15:      	movzbl	0x1c(%r15), %ecx
     a1a:      	addq	%rax, %rcx
     a1d:      	leaq	0x20(%rsp), %rdi
     a22:      	movl	$0x8, %eax
     a27:      	movl	$0x70, %r8d
     a2d:      	movzbl	0x1c(%r15), %edx
     a32:      	addq	0x8(%rsp), %rdx
     a37:      	movl	$0x8, %esi
     a3c:      	callq	*%r8
     a3f:      	movzbl	0x1b(%r15), %eax
     a44:      	addq	0x8(%rsp), %rax
     a49:      	leaq	0x18(%rsp), %rdi
     a4e:      	movl	$0x8, %ecx
     a53:      	movl	$0x70, %r8d
     a59:      	movzbl	0x1b(%r15), %edx
     a5e:      	addq	0x8(%rsp), %rdx
     a63:      	movl	$0x8, %esi
     a68:      	callq	*%r8
     a6b:      	cmpq	$0x0, 0x18(%rsp)
     a71:      	je	0xe6f <perf_unwind_ruby+0xe6f>
     a77:      	movq	0x20(%rsp), %rax
     a7c:      	testq	%rax, %rax
     a7f:      	je	0xe6f <perf_unwind_ruby+0xe6f>
     a85:      	movzbl	0x1f(%r15), %ecx
     a8a:      	addq	%rcx, %rax
     a8d:      	leaq	0x10(%rsp), %rdi
     a92:      	movl	$0x8, %ecx
     a97:      	movl	$0x70, %r8d
     a9d:      	movzbl	0x1f(%r15), %edx
     aa2:      	addq	0x20(%rsp), %rdx
     aa7:      	movl	$0x8, %esi
     aac:      	callq	*%r8
     aaf:      	testq	%rax, %rax
     ab2:      	jne	0x4c7 <perf_unwind_ruby+0x4c7>
     ab8:      	movzbl	0x21(%r15), %eax
     abd:      	addq	0x10(%rsp), %rax
     ac2:      	leaq	0x68(%rsp), %rdi
     ac7:      	movl	$0x8, %ecx
     acc:      	movl	$0x70, %r8d
     ad2:      	movzbl	0x21(%r15), %edx
     ad7:      	addq	0x10(%rsp), %rdx
     adc:      	movl	$0x8, %esi
     ae1:      	callq	*%r8
     ae4:      	testq	%rax, %rax
     ae7:      	jne	0x8a4 <perf_unwind_ruby+0x8a4>
     aed:      	movzbl	0x22(%r15), %eax
     af2:      	addq	0x10(%rsp), %rax
     af7:      	leaq	0x2c(%rsp), %rdi
     afc:      	movl	$0x4, %ecx
     b01:      	movl	$0x70, %r8d
     b07:      	movzbl	0x22(%r15), %edx
     b0c:      	addq	0x10(%rsp), %rdx
     b11:      	movl	$0x4, %esi
     b16:      	callq	*%r8
     b19:      	testq	%rax, %rax
     b1c:      	jne	0xc08 <perf_unwind_ruby+0xc08>
     b22:      	movzbl	0x23(%r15), %ecx
     b27:      	testq	%rcx, %rcx
     b2a:      	je	0x18e0 <perf_unwind_ruby+0x18e0>
     b30:      	movq	0x18(%rsp), %rax
     b35:      	subq	0x68(%rsp), %rax
     b3a:      	xorl	%edx, %edx
     b3c:      	divq	%rcx
     b3f:      	movl	0x2c(%rsp), %ecx
     b43:      	cmpq	%rcx, %rax
     b46:      	jbe	0x18e0 <perf_unwind_ruby+0x18e0>
     b4c:      	movq	(%rip), %rax            # 0xb53 <perf_unwind_ruby+0xb53>
     b53:      	cmpl	$0x0, (%rax)
     b56:      	je	0xe7c <perf_unwind_ruby+0xe7c>
     b5c:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
     b66:      	movq	%rax, 0x55(%rsp)
     b6b:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
     b75:      	movq	%rax, 0x50(%rsp)
     b7a:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
     b84:      	movq	%rax, 0x48(%rsp)
     b89:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
     b93:      	movq	%rax, 0x40(%rsp)
     b98:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
     ba2:      	movq	%rax, 0x38(%rsp)
     ba7:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
     bb1:      	movq	%rax, 0x30(%rsp)
     bb6:      	leaq	0x30(%rsp), %rdi
     bbb:      	movl	$0x2d, %eax
     bc0:      	movl	$0x6, %ecx
     bc5:      	movl	$0x2d, %esi
     bca:      	xorl	%eax, %eax
     bcc:      	callq	*%rcx
     bce:      	jmp	0xe7c <perf_unwind_ruby+0xe7c>
     bd3:      	movzbl	0x22(%r15), %eax
     bd8:      	addq	0x10(%rsp), %rax
     bdd:      	leaq	0x2c(%rsp), %rdi
     be2:      	movl	$0x4, %ecx
     be7:      	movl	$0x70, %r8d
     bed:      	movzbl	0x22(%r15), %edx
     bf2:      	addq	0x10(%rsp), %rdx
     bf7:      	movl	$0x4, %esi
     bfc:      	callq	*%r8
     bff:      	testq	%rax, %rax
     c02:      	je	0xcfa <perf_unwind_ruby+0xcfa>
     c08:      	movq	(%rip), %r15            # 0xc0f <perf_unwind_ruby+0xc0f>
     c0f:      	cmpl	$0x0, (%r15)
     c13:      	jne	0x22d8 <perf_unwind_ruby+0x22d8>
     c19:      	movl	$0x50, (%rsp)
     c20:      	movq	(%rip), %rdi            # 0xc27 <perf_unwind_ruby+0xc27>
     c27:      	movq	%rsp, %rsi
     c2a:      	movl	$0x1, %eax
     c2f:      	callq	*%rax
     c31:      	testq	%rax, %rax
     c34:      	je	0xdab <perf_unwind_ruby+0xdab>
     c3a:      	incq	(%rax)
     c3d:      	jmp	0xdb5 <perf_unwind_ruby+0xdb5>
     c42:      	cmpl	$0x0, (%r15)
     c46:      	jne	0x225d <perf_unwind_ruby+0x225d>
     c4c:      	movl	$0xbbc, %r13d           # imm = 0xBBC
     c52:      	xorl	%ebp, %ebp
     c54:      	jmp	0x2b2 <perf_unwind_ruby+0x2b2>
     c59:      	cmpl	$0x0, (%r15)
     c5d:      	jne	0x2331 <perf_unwind_ruby+0x2331>
     c63:      	movl	$0xbbe, %r13d           # imm = 0xBBE
     c69:      	xorl	%ebp, %ebp
     c6b:      	jmp	0x2b2 <perf_unwind_ruby+0x2b2>
     c70:      	imulq	0x88(%rsp), %rbp
     c79:      	addq	%rbp, %r13
     c7c:      	movq	0x90(%rsp), %rax
     c84:      	addl	%eax, %eax
     c86:      	subq	%rax, %r13
     c89:      	movq	0x8(%rsp), %rax
     c8e:      	jmp	0x40f <perf_unwind_ruby+0x40f>
     c93:      	movq	$0x0, (%rsp)
     c9b:      	movzbl	0x1d(%r15), %eax
     ca0:      	addq	0x8(%rsp), %rax
     ca5:      	movq	%rsp, %rdi
     ca8:      	movl	$0x8, %ecx
     cad:      	movl	$0x70, %r8d
     cb3:      	movzbl	0x1d(%r15), %edx
     cb8:      	addq	0x8(%rsp), %rdx
     cbd:      	movl	$0x8, %esi
     cc2:      	callq	*%r8
     cc5:      	testq	%rax, %rax
     cc8:      	jne	0x81b <perf_unwind_ruby+0x81b>
     cce:      	movl	(%rsp), %eax
     cd1:      	notl	%eax
     cd3:      	testl	$0x140, %eax            # imm = 0x140
     cd8:      	jne	0x997 <perf_unwind_ruby+0x997>
     cde:      	jmp	0x9e5 <perf_unwind_ruby+0x9e5>
     ce3:      	cmpl	$0x0, (%r15)
     ce7:      	jne	0x23fb <perf_unwind_ruby+0x23fb>
     ced:      	movl	$0xbbb, %r13d           # imm = 0xBBB
     cf3:      	xorl	%ebp, %ebp
     cf5:      	jmp	0x2b2 <perf_unwind_ruby+0x2b2>
     cfa:      	movzbl	0x23(%r15), %ecx
     cff:      	testq	%rcx, %rcx
     d02:      	je	0xdc2 <perf_unwind_ruby+0xdc2>
     d08:      	movq	0x18(%rsp), %rax
     d0d:      	subq	0x68(%rsp), %rax
     d12:      	xorl	%edx, %edx
     d14:      	divq	%rcx
     d17:      	movl	0x2c(%rsp), %ecx
     d1b:      	cmpq	%rcx, %rax
     d1e:      	jbe	0xdc2 <perf_unwind_ruby+0xdc2>
     d24:      	movq	(%rip), %rax            # 0xd2b <perf_unwind_ruby+0xd2b>
     d2b:      	cmpl	$0x0, (%rax)
     d2e:      	je	0x57c <perf_unwind_ruby+0x57c>
     d34:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
     d3e:      	movq	%rax, 0x55(%rsp)
     d43:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
     d4d:      	movq	%rax, 0x50(%rsp)
     d52:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
     d5c:      	movq	%rax, 0x48(%rsp)
     d61:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
     d6b:      	movq	%rax, 0x40(%rsp)
     d70:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
     d7a:      	movq	%rax, 0x38(%rsp)
     d7f:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
     d89:      	movq	%rax, 0x30(%rsp)
     d8e:      	leaq	0x30(%rsp), %rdi
     d93:      	movl	$0x2d, %eax
     d98:      	movl	$0x6, %ecx
     d9d:      	movl	$0x2d, %esi
     da2:      	xorl	%eax, %eax
     da4:      	callq	*%rcx
     da6:      	jmp	0x57c <perf_unwind_ruby+0x57c>
     dab:      	cmpl	$0x0, (%r15)
     daf:      	jne	0x2594 <perf_unwind_ruby+0x2594>
     db5:      	movl	$0xbbf, %r13d           # imm = 0xBBF
     dbb:      	xorl	%ebp, %ebp
     dbd:      	jmp	0x2b2 <perf_unwind_ruby+0x2b2>
     dc2:      	movl	0x2c0(%r14), %eax
     dc9:      	cmpq	$0x7f, %rax
     dcd:      	jb	0x106a <perf_unwind_ruby+0x106a>
     dd3:      	movq	(%rip), %r15            # 0xdda <perf_unwind_ruby+0xdda>
     dda:      	cmpl	$0x0, (%r15)
     dde:      	jne	0x2806 <perf_unwind_ruby+0x2806>
     de4:      	movl	$0x2, 0x74(%rsp)
     dec:      	movq	(%rip), %rdi            # 0xdf3 <perf_unwind_ruby+0xdf3>
     df3:      	leaq	0x74(%rsp), %rsi
     df8:      	movl	$0x1, %eax
     dfd:      	callq	*%rax
     dff:      	testq	%rax, %rax
     e02:      	je	0x1139 <perf_unwind_ruby+0x1139>
     e08:      	incq	(%rax)
     e0b:      	cmpl	$0x0, (%r15)
     e0f:      	movl	$0x2, %r13d
     e15:      	je	0x29ce <perf_unwind_ruby+0x29ce>
     e1b:      	movabsq	$0x6172662068737570, %rax # imm = 0x6172662068737570
     e25:      	movq	%rax, 0x40(%rsp)
     e2a:      	movabsq	$0x206f742064656c69, %rax # imm = 0x206F742064656C69
     e34:      	movq	%rax, 0x38(%rsp)
     e39:      	movabsq	$0x6166203a79627572, %rax # imm = 0x6166203A79627572
     e43:      	movq	%rax, 0x30(%rsp)
     e48:      	movl	$0xa656d, 0x48(%rsp)    # imm = 0xA656D
     e50:      	leaq	0x30(%rsp), %rdi
     e55:      	movl	$0x1c, %eax
     e5a:      	movl	$0x6, %ecx
     e5f:      	xorl	%ebp, %ebp
     e61:      	movl	$0x1c, %esi
     e66:      	xorl	%eax, %eax
     e68:      	callq	*%rcx
     e6a:      	jmp	0x2b2 <perf_unwind_ruby+0x2b2>
     e6f:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
     e76:      	jae	0x10e9 <perf_unwind_ruby+0x10e9>
     e7c:      	movq	0x8(%rsp), %rax
     e81:      	movq	%r12, %rcx
     e84:      	cmpq	%rax, %r12
     e87:      	jbe	0x2b2 <perf_unwind_ruby+0x2b2>
     e8d:      	movzbl	0x1e(%r15), %ecx
     e92:      	addq	%rcx, %rax
     e95:      	movq	%rax, 0x8(%rsp)
     e9a:      	movq	$0x0, 0x18(%rsp)
     ea3:      	movq	$0x0, 0x20(%rsp)
     eac:      	movzbl	0x1c(%r15), %ecx
     eb1:      	addq	%rax, %rcx
     eb4:      	leaq	0x20(%rsp), %rdi
     eb9:      	movl	$0x8, %eax
     ebe:      	movl	$0x70, %r8d
     ec4:      	movzbl	0x1c(%r15), %edx
     ec9:      	addq	0x8(%rsp), %rdx
     ece:      	movl	$0x8, %esi
     ed3:      	callq	*%r8
     ed6:      	movzbl	0x1b(%r15), %eax
     edb:      	addq	0x8(%rsp), %rax
     ee0:      	leaq	0x18(%rsp), %rdi
     ee5:      	movl	$0x8, %ecx
     eea:      	movl	$0x70, %r8d
     ef0:      	movzbl	0x1b(%r15), %edx
     ef5:      	addq	0x8(%rsp), %rdx
     efa:      	movl	$0x8, %esi
     eff:      	callq	*%r8
     f02:      	cmpq	$0x0, 0x18(%rsp)
     f08:      	je	0x1319 <perf_unwind_ruby+0x1319>
     f0e:      	movq	0x20(%rsp), %rax
     f13:      	testq	%rax, %rax
     f16:      	je	0x1319 <perf_unwind_ruby+0x1319>
     f1c:      	movzbl	0x1f(%r15), %ecx
     f21:      	addq	%rcx, %rax
     f24:      	leaq	0x10(%rsp), %rdi
     f29:      	movl	$0x8, %ecx
     f2e:      	movl	$0x70, %r8d
     f34:      	movzbl	0x1f(%r15), %edx
     f39:      	addq	0x20(%rsp), %rdx
     f3e:      	movl	$0x8, %esi
     f43:      	callq	*%r8
     f46:      	testq	%rax, %rax
     f49:      	jne	0x4c7 <perf_unwind_ruby+0x4c7>
     f4f:      	movzbl	0x21(%r15), %eax
     f54:      	addq	0x10(%rsp), %rax
     f59:      	leaq	0x68(%rsp), %rdi
     f5e:      	movl	$0x8, %ecx
     f63:      	movl	$0x70, %r8d
     f69:      	movzbl	0x21(%r15), %edx
     f6e:      	addq	0x10(%rsp), %rdx
     f73:      	movl	$0x8, %esi
     f78:      	callq	*%r8
     f7b:      	testq	%rax, %rax
     f7e:      	jne	0x8a4 <perf_unwind_ruby+0x8a4>
     f84:      	movzbl	0x22(%r15), %eax
     f89:      	addq	0x10(%rsp), %rax
     f8e:      	leaq	0x2c(%rsp), %rdi
     f93:      	movl	$0x4, %ecx
     f98:      	movl	$0x70, %r8d
     f9e:      	movzbl	0x22(%r15), %edx
     fa3:      	addq	0x10(%rsp), %rdx
     fa8:      	movl	$0x4, %esi
     fad:      	callq	*%r8
     fb0:      	testq	%rax, %rax
     fb3:      	jne	0xc08 <perf_unwind_ruby+0xc08>
     fb9:      	movzbl	0x23(%r15), %ecx
     fbe:      	testq	%rcx, %rcx
     fc1:      	je	0x1e2d <perf_unwind_ruby+0x1e2d>
     fc7:      	movq	0x18(%rsp), %rax
     fcc:      	subq	0x68(%rsp), %rax
     fd1:      	xorl	%edx, %edx
     fd3:      	divq	%rcx
     fd6:      	movl	0x2c(%rsp), %ecx
     fda:      	cmpq	%rcx, %rax
     fdd:      	jbe	0x1e2d <perf_unwind_ruby+0x1e2d>
     fe3:      	movq	(%rip), %rax            # 0xfea <perf_unwind_ruby+0xfea>
     fea:      	cmpl	$0x0, (%rax)
     fed:      	je	0x1326 <perf_unwind_ruby+0x1326>
     ff3:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
     ffd:      	movq	%rax, 0x55(%rsp)
    1002:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    100c:      	movq	%rax, 0x50(%rsp)
    1011:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    101b:      	movq	%rax, 0x48(%rsp)
    1020:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    102a:      	movq	%rax, 0x40(%rsp)
    102f:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    1039:      	movq	%rax, 0x38(%rsp)
    103e:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    1048:      	movq	%rax, 0x30(%rsp)
    104d:      	leaq	0x30(%rsp), %rdi
    1052:      	movl	$0x2d, %eax
    1057:      	movl	$0x6, %ecx
    105c:      	movl	$0x2d, %esi
    1061:      	xorl	%eax, %eax
    1063:      	callq	*%rcx
    1065:      	jmp	0x1326 <perf_unwind_ruby+0x1326>
    106a:      	movq	0x10(%rsp), %rcx
    106f:      	movq	0x18(%rsp), %rdx
    1074:      	leal	0x1(%rax), %esi
    1077:      	movl	%esi, 0x2c0(%r14)
    107e:      	leaq	(%rax,%rax,2), %rax
    1082:      	movw	$0x0, 0x4(%rsp)
    1089:      	movl	$0x0, (%rsp)
    1090:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    1098:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    10a0:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    10ab:      	movl	(%rsp), %ecx
    10ae:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    10b6:      	movzwl	0x4(%rsp), %ecx
    10bb:      	movw	%cx, 0x2e6(%r14,%rax,8)
    10c4:      	movl	$0x36, (%rsp)
    10cb:      	movq	(%rip), %rdi            # 0x10d2 <perf_unwind_ruby+0x10d2>
    10d2:      	movq	%rsp, %rsi
    10d5:      	movl	$0x1, %eax
    10da:      	callq	*%rax
    10dc:      	testq	%rax, %rax
    10df:      	je	0x1150 <perf_unwind_ruby+0x1150>
    10e1:      	incq	(%rax)
    10e4:      	jmp	0x57c <perf_unwind_ruby+0x57c>
    10e9:      	movq	$0x0, (%rsp)
    10f1:      	movzbl	0x1d(%r15), %eax
    10f6:      	addq	0x8(%rsp), %rax
    10fb:      	movq	%rsp, %rdi
    10fe:      	movl	$0x8, %ecx
    1103:      	movl	$0x70, %r8d
    1109:      	movzbl	0x1d(%r15), %edx
    110e:      	addq	0x8(%rsp), %rdx
    1113:      	movl	$0x8, %esi
    1118:      	callq	*%r8
    111b:      	testq	%rax, %rax
    111e:      	jne	0x81b <perf_unwind_ruby+0x81b>
    1124:      	movl	(%rsp), %eax
    1127:      	notl	%eax
    1129:      	testl	$0x140, %eax            # imm = 0x140
    112e:      	jne	0x997 <perf_unwind_ruby+0x997>
    1134:      	jmp	0xe7c <perf_unwind_ruby+0xe7c>
    1139:      	cmpl	$0x0, (%r15)
    113d:      	jne	0x2948 <perf_unwind_ruby+0x2948>
    1143:      	movl	$0x2, %r13d
    1149:      	xorl	%ebp, %ebp
    114b:      	jmp	0x2b2 <perf_unwind_ruby+0x2b2>
    1150:      	movq	(%rip), %rax            # 0x1157 <perf_unwind_ruby+0x1157>
    1157:      	cmpl	$0x0, (%rax)
    115a:      	je	0x57c <perf_unwind_ruby+0x57c>
    1160:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    116a:      	movq	%rax, 0x56(%rsp)
    116f:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1179:      	movq	%rax, 0x50(%rsp)
    117e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1188:      	movq	%rax, 0x48(%rsp)
    118d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1197:      	movq	%rax, 0x40(%rsp)
    119c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    11a6:      	movq	%rax, 0x38(%rsp)
    11ab:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    11b5:      	movq	%rax, 0x30(%rsp)
    11ba:      	leaq	0x30(%rsp), %rdi
    11bf:      	movl	$0x2e, %eax
    11c4:      	movl	$0x6, %ecx
    11c9:      	movl	(%rsp), %edx
    11cc:      	movl	$0x2e, %esi
    11d1:      	xorl	%eax, %eax
    11d3:      	callq	*%rcx
    11d5:      	jmp	0x57c <perf_unwind_ruby+0x57c>
    11da:      	movabsq	$0x6164206e6f697463, %rax # imm = 0x6164206E6F697463
    11e4:      	movq	%rax, 0x40(%rsp)
    11e9:      	movabsq	$0x6570736f72746e69, %rax # imm = 0x6570736F72746E69
    11f3:      	movq	%rax, 0x38(%rsp)
    11f8:      	movabsq	$0x2079627552206f4e, %rax # imm = 0x2079627552206F4E
    1202:      	movq	%rax, 0x30(%rsp)
    1207:      	movl	$0xa6174, 0x48(%rsp)    # imm = 0xA6174
    120f:      	leaq	0x30(%rsp), %rdi
    1214:      	movl	$0x1c, %eax
    1219:      	movl	$0x6, %ecx
    121e:      	movl	$0x1c, %esi
    1223:      	xorl	%eax, %eax
    1225:      	callq	*%rcx
    1227:      	jmp	0x11a <perf_unwind_ruby+0x11a>
    122c:      	movl	0x2c0(%r14), %eax
    1233:      	cmpq	$0x7e, %rax
    1237:      	ja	0xdd3 <perf_unwind_ruby+0xdd3>
    123d:      	movq	0x10(%rsp), %rcx
    1242:      	movq	0x18(%rsp), %rdx
    1247:      	leal	0x1(%rax), %esi
    124a:      	movl	%esi, 0x2c0(%r14)
    1251:      	leaq	(%rax,%rax,2), %rax
    1255:      	movw	$0x0, 0x4(%rsp)
    125c:      	movl	$0x0, (%rsp)
    1263:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    126b:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    1273:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    127e:      	movl	(%rsp), %ecx
    1281:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    1289:      	movzwl	0x4(%rsp), %ecx
    128e:      	movw	%cx, 0x2e6(%r14,%rax,8)
    1297:      	movl	$0x36, (%rsp)
    129e:      	movq	(%rip), %rdi            # 0x12a5 <perf_unwind_ruby+0x12a5>
    12a5:      	movq	%rsp, %rsi
    12a8:      	movl	$0x1, %eax
    12ad:      	callq	*%rax
    12af:      	testq	%rax, %rax
    12b2:      	je	0x17f1 <perf_unwind_ruby+0x17f1>
    12b8:      	incq	(%rax)
    12bb:      	jmp	0x9e5 <perf_unwind_ruby+0x9e5>
    12c0:      	movabsq	$0xa65756c617620, %rax  # imm = 0xA65756C617620
    12ca:      	movq	%rax, 0x45(%rsp)
    12cf:      	movabsq	$0x6176206573616270, %rax # imm = 0x6176206573616270
    12d9:      	movq	%rax, 0x40(%rsp)
    12de:      	movabsq	$0x742064616572206f, %rax # imm = 0x742064616572206F
    12e8:      	movq	%rax, 0x38(%rsp)
    12ed:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    12f7:      	movq	%rax, 0x30(%rsp)
    12fc:      	leaq	0x30(%rsp), %rdi
    1301:      	movl	$0x1d, %eax
    1306:      	movl	$0x6, %ecx
    130b:      	movl	$0x1d, %esi
    1310:      	xorl	%eax, %eax
    1312:      	callq	*%rcx
    1314:      	jmp	0x1af <perf_unwind_ruby+0x1af>
    1319:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    1320:      	jae	0x16a2 <perf_unwind_ruby+0x16a2>
    1326:      	movq	0x8(%rsp), %rax
    132b:      	cmpq	%rax, %r12
    132e:      	jbe	0x2b2 <perf_unwind_ruby+0x2b2>
    1334:      	movzbl	0x1e(%r15), %ecx
    1339:      	addq	%rcx, %rax
    133c:      	movq	%rax, 0x8(%rsp)
    1341:      	movq	$0x0, 0x18(%rsp)
    134a:      	movq	$0x0, 0x20(%rsp)
    1353:      	movzbl	0x1c(%r15), %ecx
    1358:      	addq	%rax, %rcx
    135b:      	leaq	0x20(%rsp), %rdi
    1360:      	movl	$0x8, %eax
    1365:      	movl	$0x70, %r8d
    136b:      	movzbl	0x1c(%r15), %edx
    1370:      	addq	0x8(%rsp), %rdx
    1375:      	movl	$0x8, %esi
    137a:      	callq	*%r8
    137d:      	movzbl	0x1b(%r15), %eax
    1382:      	addq	0x8(%rsp), %rax
    1387:      	leaq	0x18(%rsp), %rdi
    138c:      	movl	$0x8, %ecx
    1391:      	movl	$0x70, %r8d
    1397:      	movzbl	0x1b(%r15), %edx
    139c:      	addq	0x8(%rsp), %rdx
    13a1:      	movl	$0x8, %esi
    13a6:      	callq	*%r8
    13a9:      	cmpq	$0x0, 0x18(%rsp)
    13af:      	je	0x1974 <perf_unwind_ruby+0x1974>
    13b5:      	movq	0x20(%rsp), %rax
    13ba:      	testq	%rax, %rax
    13bd:      	je	0x1974 <perf_unwind_ruby+0x1974>
    13c3:      	movzbl	0x1f(%r15), %ecx
    13c8:      	addq	%rcx, %rax
    13cb:      	leaq	0x10(%rsp), %rdi
    13d0:      	movl	$0x8, %ecx
    13d5:      	movl	$0x70, %r8d
    13db:      	movzbl	0x1f(%r15), %edx
    13e0:      	addq	0x20(%rsp), %rdx
    13e5:      	movl	$0x8, %esi
    13ea:      	callq	*%r8
    13ed:      	testq	%rax, %rax
    13f0:      	jne	0x4c7 <perf_unwind_ruby+0x4c7>
    13f6:      	movzbl	0x21(%r15), %eax
    13fb:      	addq	0x10(%rsp), %rax
    1400:      	leaq	0x68(%rsp), %rdi
    1405:      	movl	$0x8, %ecx
    140a:      	movl	$0x70, %r8d
    1410:      	movzbl	0x21(%r15), %edx
    1415:      	addq	0x10(%rsp), %rdx
    141a:      	movl	$0x8, %esi
    141f:      	callq	*%r8
    1422:      	testq	%rax, %rax
    1425:      	jne	0x8a4 <perf_unwind_ruby+0x8a4>
    142b:      	movzbl	0x22(%r15), %eax
    1430:      	addq	0x10(%rsp), %rax
    1435:      	leaq	0x2c(%rsp), %rdi
    143a:      	movl	$0x4, %ecx
    143f:      	movl	$0x70, %r8d
    1445:      	movzbl	0x22(%r15), %edx
    144a:      	addq	0x10(%rsp), %rdx
    144f:      	movl	$0x4, %esi
    1454:      	callq	*%r8
    1457:      	testq	%rax, %rax
    145a:      	jne	0xc08 <perf_unwind_ruby+0xc08>
    1460:      	movzbl	0x23(%r15), %ecx
    1465:      	testq	%rcx, %rcx
    1468:      	je	0x2500 <perf_unwind_ruby+0x2500>
    146e:      	movq	0x18(%rsp), %rax
    1473:      	subq	0x68(%rsp), %rax
    1478:      	xorl	%edx, %edx
    147a:      	divq	%rcx
    147d:      	movl	0x2c(%rsp), %ecx
    1481:      	cmpq	%rcx, %rax
    1484:      	jbe	0x2500 <perf_unwind_ruby+0x2500>
    148a:      	movq	(%rip), %rax            # 0x1491 <perf_unwind_ruby+0x1491>
    1491:      	cmpl	$0x0, (%rax)
    1494:      	je	0x1981 <perf_unwind_ruby+0x1981>
    149a:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    14a4:      	movq	%rax, 0x55(%rsp)
    14a9:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    14b3:      	movq	%rax, 0x50(%rsp)
    14b8:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    14c2:      	movq	%rax, 0x48(%rsp)
    14c7:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    14d1:      	movq	%rax, 0x40(%rsp)
    14d6:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    14e0:      	movq	%rax, 0x38(%rsp)
    14e5:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    14ef:      	movq	%rax, 0x30(%rsp)
    14f4:      	leaq	0x30(%rsp), %rdi
    14f9:      	movl	$0x2d, %eax
    14fe:      	movl	$0x6, %ecx
    1503:      	movl	$0x2d, %esi
    1508:      	xorl	%eax, %eax
    150a:      	callq	*%rcx
    150c:      	jmp	0x1981 <perf_unwind_ruby+0x1981>
    1511:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    151b:      	movq	%rax, 0x56(%rsp)
    1520:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    152a:      	movq	%rax, 0x50(%rsp)
    152f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1539:      	movq	%rax, 0x48(%rsp)
    153e:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1548:      	movq	%rax, 0x40(%rsp)
    154d:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1557:      	movq	%rax, 0x38(%rsp)
    155c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1566:      	movq	%rax, 0x30(%rsp)
    156b:      	leaq	0x30(%rsp), %rdi
    1570:      	movl	$0x2e, %eax
    1575:      	movl	$0x6, %ecx
    157a:      	movl	0x8(%rsp), %edx
    157e:      	movl	$0x2e, %esi
    1583:      	xorl	%eax, %eax
    1585:      	callq	*%rcx
    1587:      	movq	$0x0, 0x78(%rsp)
    1590:      	cmpq	$0x0, 0x8(%r15)
    1595:      	jne	0x16a <perf_unwind_ruby+0x16a>
    159b:      	jmp	0xa1 <perf_unwind_ruby+0xa1>
    15a0:      	movabsq	$0xa786c6c25783020, %rax # imm = 0xA786C6C25783020
    15aa:      	movq	%rax, 0x58(%rsp)
    15af:      	movabsq	$0x6d6f726620786c6c, %rax # imm = 0x6D6F726620786C6C
    15b9:      	movq	%rax, 0x50(%rsp)
    15be:      	movabsq	$0x2578302072646461, %rax # imm = 0x2578302072646461
    15c8:      	movq	%rax, 0x48(%rsp)
    15cd:      	movabsq	$0x206c6f626d797320, %rax # imm = 0x206C6F626D797320
    15d7:      	movq	%rax, 0x40(%rsp)
    15dc:      	movabsq	$0x434520534c542074, %rax # imm = 0x434520534C542074
    15e6:      	movq	%rax, 0x38(%rsp)
    15eb:      	movabsq	$0x6f67203a79627572, %rax # imm = 0x6F67203A79627572
    15f5:      	movq	%rax, 0x30(%rsp)
    15fa:      	movb	$0x0, 0x60(%rsp)
    15ff:      	leaq	0x30(%rsp), %rdi
    1604:      	movl	$0x31, %eax
    1609:      	movl	$0x6, %r8d
    160f:      	movl	$0x31, %esi
    1614:      	movq	%rdx, %r12
    1617:      	movq	%rdx, %rcx
    161a:      	xorl	%eax, %eax
    161c:      	callq	*%r8
    161f:      	movq	%r12, %rdx
    1622:      	jmp	0x279 <perf_unwind_ruby+0x279>
    1627:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1631:      	movq	%rax, 0x56(%rsp)
    1636:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1640:      	movq	%rax, 0x50(%rsp)
    1645:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    164f:      	movq	%rax, 0x48(%rsp)
    1654:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    165e:      	movq	%rax, 0x40(%rsp)
    1663:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    166d:      	movq	%rax, 0x38(%rsp)
    1672:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    167c:      	movq	%rax, 0x30(%rsp)
    1681:      	leaq	0x30(%rsp), %rdi
    1686:      	movl	$0x2e, %eax
    168b:      	movl	$0x6, %ecx
    1690:      	movl	0x8(%rsp), %edx
    1694:      	movl	$0x2e, %esi
    1699:      	xorl	%eax, %eax
    169b:      	callq	*%rcx
    169d:      	jmp	0x2a7 <perf_unwind_ruby+0x2a7>
    16a2:      	movq	$0x0, (%rsp)
    16aa:      	movzbl	0x1d(%r15), %eax
    16af:      	addq	0x8(%rsp), %rax
    16b4:      	movq	%rsp, %rdi
    16b7:      	movl	$0x8, %ecx
    16bc:      	movl	$0x70, %r8d
    16c2:      	movzbl	0x1d(%r15), %edx
    16c7:      	addq	0x8(%rsp), %rdx
    16cc:      	movl	$0x8, %esi
    16d1:      	callq	*%r8
    16d4:      	testq	%rax, %rax
    16d7:      	jne	0x81b <perf_unwind_ruby+0x81b>
    16dd:      	movl	(%rsp), %eax
    16e0:      	notl	%eax
    16e2:      	testl	$0x140, %eax            # imm = 0x140
    16e7:      	jne	0x997 <perf_unwind_ruby+0x997>
    16ed:      	jmp	0x1326 <perf_unwind_ruby+0x1326>
    16f2:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    16fc:      	movq	%rax, 0x56(%rsp)
    1701:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    170b:      	movq	%rax, 0x50(%rsp)
    1710:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    171a:      	movq	%rax, 0x48(%rsp)
    171f:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1729:      	movq	%rax, 0x40(%rsp)
    172e:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1738:      	movq	%rax, 0x38(%rsp)
    173d:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1747:      	movq	%rax, 0x30(%rsp)
    174c:      	leaq	0x30(%rsp), %rdi
    1751:      	movl	$0x2e, %eax
    1756:      	movl	$0x6, %ecx
    175b:      	movl	0x20(%rsp), %edx
    175f:      	movl	$0x2e, %esi
    1764:      	xorl	%eax, %eax
    1766:      	callq	*%rcx
    1768:      	cmpl	$0x0, (%rbx)
    176b:      	je	0x37c <perf_unwind_ruby+0x37c>
    1771:      	jmp	0x1df <perf_unwind_ruby+0x1df>
    1776:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1780:      	movq	%rax, 0x56(%rsp)
    1785:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    178f:      	movq	%rax, 0x50(%rsp)
    1794:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    179e:      	movq	%rax, 0x48(%rsp)
    17a3:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    17ad:      	movq	%rax, 0x40(%rsp)
    17b2:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    17bc:      	movq	%rax, 0x38(%rsp)
    17c1:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    17cb:      	movq	%rax, 0x30(%rsp)
    17d0:      	leaq	0x30(%rsp), %rdi
    17d5:      	movl	$0x2e, %eax
    17da:      	movl	$0x6, %ecx
    17df:      	movl	0x8(%rsp), %edx
    17e3:      	movl	$0x2e, %esi
    17e8:      	xorl	%eax, %eax
    17ea:      	callq	*%rcx
    17ec:      	jmp	0x390 <perf_unwind_ruby+0x390>
    17f1:      	movq	(%rip), %rax            # 0x17f8 <perf_unwind_ruby+0x17f8>
    17f8:      	cmpl	$0x0, (%rax)
    17fb:      	je	0x9e5 <perf_unwind_ruby+0x9e5>
    1801:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    180b:      	movq	%rax, 0x56(%rsp)
    1810:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    181a:      	movq	%rax, 0x50(%rsp)
    181f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1829:      	movq	%rax, 0x48(%rsp)
    182e:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1838:      	movq	%rax, 0x40(%rsp)
    183d:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1847:      	movq	%rax, 0x38(%rsp)
    184c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1856:      	movq	%rax, 0x30(%rsp)
    185b:      	leaq	0x30(%rsp), %rdi
    1860:      	movl	$0x2e, %eax
    1865:      	movl	$0x6, %ecx
    186a:      	movl	(%rsp), %edx
    186d:      	movl	$0x2e, %esi
    1872:      	xorl	%eax, %eax
    1874:      	callq	*%rcx
    1876:      	jmp	0x9e5 <perf_unwind_ruby+0x9e5>
    187b:      	movabsq	$0x6c6c257830203a53, %rax # imm = 0x6C6C257830203A53
    1885:      	movq	%rax, 0x40(%rsp)
    188a:      	movabsq	$0x4c54206d6f726620, %rax # imm = 0x4C54206D6F726620
    1894:      	movq	%rax, 0x38(%rsp)
    1899:      	movabsq	$0x4345203a79627572, %rax # imm = 0x4345203A79627572
    18a3:      	movq	%rax, 0x30(%rsp)
    18a8:      	movl	$0xa786c, 0x47(%rsp)    # imm = 0xA786C
    18b0:      	leaq	0x30(%rsp), %rdi
    18b5:      	movl	$0x1b, %eax
    18ba:      	movl	$0x6, %ecx
    18bf:      	movq	0x78(%rsp), %rdx
    18c4:      	movl	$0x1b, %esi
    18c9:      	xorl	%eax, %eax
    18cb:      	callq	*%rcx
    18cd:      	movq	0x78(%rsp), %r12
    18d2:      	testq	%r12, %r12
    18d5:      	jne	0x3ea <perf_unwind_ruby+0x3ea>
    18db:      	jmp	0x298 <perf_unwind_ruby+0x298>
    18e0:      	movl	0x2c0(%r14), %eax
    18e7:      	cmpq	$0x7e, %rax
    18eb:      	ja	0xdd3 <perf_unwind_ruby+0xdd3>
    18f1:      	movq	0x10(%rsp), %rcx
    18f6:      	movq	0x18(%rsp), %rdx
    18fb:      	leal	0x1(%rax), %esi
    18fe:      	movl	%esi, 0x2c0(%r14)
    1905:      	leaq	(%rax,%rax,2), %rax
    1909:      	movw	$0x0, 0x4(%rsp)
    1910:      	movl	$0x0, (%rsp)
    1917:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    191f:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    1927:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    1932:      	movl	(%rsp), %ecx
    1935:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    193d:      	movzwl	0x4(%rsp), %ecx
    1942:      	movw	%cx, 0x2e6(%r14,%rax,8)
    194b:      	movl	$0x36, (%rsp)
    1952:      	movq	(%rip), %rdi            # 0x1959 <perf_unwind_ruby+0x1959>
    1959:      	movq	%rsp, %rsi
    195c:      	movl	$0x1, %eax
    1961:      	callq	*%rax
    1963:      	testq	%rax, %rax
    1966:      	je	0x1da3 <perf_unwind_ruby+0x1da3>
    196c:      	incq	(%rax)
    196f:      	jmp	0xe7c <perf_unwind_ruby+0xe7c>
    1974:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    197b:      	jae	0x1c35 <perf_unwind_ruby+0x1c35>
    1981:      	movq	0x8(%rsp), %rax
    1986:      	cmpq	%rax, %r12
    1989:      	jbe	0x2b2 <perf_unwind_ruby+0x2b2>
    198f:      	movzbl	0x1e(%r15), %ecx
    1994:      	addq	%rcx, %rax
    1997:      	movq	%rax, 0x8(%rsp)
    199c:      	movq	$0x0, 0x18(%rsp)
    19a5:      	movq	$0x0, 0x20(%rsp)
    19ae:      	movzbl	0x1c(%r15), %ecx
    19b3:      	addq	%rax, %rcx
    19b6:      	leaq	0x20(%rsp), %rdi
    19bb:      	movl	$0x8, %eax
    19c0:      	movl	$0x70, %r8d
    19c6:      	movzbl	0x1c(%r15), %edx
    19cb:      	addq	0x8(%rsp), %rdx
    19d0:      	movl	$0x8, %esi
    19d5:      	callq	*%r8
    19d8:      	movzbl	0x1b(%r15), %eax
    19dd:      	addq	0x8(%rsp), %rax
    19e2:      	leaq	0x18(%rsp), %rdi
    19e7:      	movl	$0x8, %ecx
    19ec:      	movl	$0x70, %r8d
    19f2:      	movzbl	0x1b(%r15), %edx
    19f7:      	addq	0x8(%rsp), %rdx
    19fc:      	movl	$0x8, %esi
    1a01:      	callq	*%r8
    1a04:      	cmpq	$0x0, 0x18(%rsp)
    1a0a:      	je	0x1f9b <perf_unwind_ruby+0x1f9b>
    1a10:      	movq	0x20(%rsp), %rax
    1a15:      	testq	%rax, %rax
    1a18:      	je	0x1f9b <perf_unwind_ruby+0x1f9b>
    1a1e:      	movzbl	0x1f(%r15), %ecx
    1a23:      	addq	%rcx, %rax
    1a26:      	leaq	0x10(%rsp), %rdi
    1a2b:      	movl	$0x8, %ecx
    1a30:      	movl	$0x70, %r8d
    1a36:      	movzbl	0x1f(%r15), %edx
    1a3b:      	addq	0x20(%rsp), %rdx
    1a40:      	movl	$0x8, %esi
    1a45:      	callq	*%r8
    1a48:      	testq	%rax, %rax
    1a4b:      	jne	0x4c7 <perf_unwind_ruby+0x4c7>
    1a51:      	movzbl	0x21(%r15), %eax
    1a56:      	addq	0x10(%rsp), %rax
    1a5b:      	leaq	0x68(%rsp), %rdi
    1a60:      	movl	$0x8, %ecx
    1a65:      	movl	$0x70, %r8d
    1a6b:      	movzbl	0x21(%r15), %edx
    1a70:      	addq	0x10(%rsp), %rdx
    1a75:      	movl	$0x8, %esi
    1a7a:      	callq	*%r8
    1a7d:      	testq	%rax, %rax
    1a80:      	jne	0x8a4 <perf_unwind_ruby+0x8a4>
    1a86:      	movzbl	0x22(%r15), %eax
    1a8b:      	addq	0x10(%rsp), %rax
    1a90:      	leaq	0x2c(%rsp), %rdi
    1a95:      	movl	$0x4, %ecx
    1a9a:      	movl	$0x70, %r8d
    1aa0:      	movzbl	0x22(%r15), %edx
    1aa5:      	addq	0x10(%rsp), %rdx
    1aaa:      	movl	$0x4, %esi
    1aaf:      	callq	*%r8
    1ab2:      	testq	%rax, %rax
    1ab5:      	jne	0xc08 <perf_unwind_ruby+0xc08>
    1abb:      	movzbl	0x23(%r15), %ecx
    1ac0:      	testq	%rcx, %rcx
    1ac3:      	je	0x29d5 <perf_unwind_ruby+0x29d5>
    1ac9:      	movq	0x18(%rsp), %rax
    1ace:      	subq	0x68(%rsp), %rax
    1ad3:      	xorl	%edx, %edx
    1ad5:      	divq	%rcx
    1ad8:      	movl	0x2c(%rsp), %ecx
    1adc:      	cmpq	%rcx, %rax
    1adf:      	jbe	0x29d5 <perf_unwind_ruby+0x29d5>
    1ae5:      	movq	(%rip), %rax            # 0x1aec <perf_unwind_ruby+0x1aec>
    1aec:      	cmpl	$0x0, (%rax)
    1aef:      	je	0x1fa8 <perf_unwind_ruby+0x1fa8>
    1af5:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    1aff:      	movq	%rax, 0x55(%rsp)
    1b04:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    1b0e:      	movq	%rax, 0x50(%rsp)
    1b13:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    1b1d:      	movq	%rax, 0x48(%rsp)
    1b22:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    1b2c:      	movq	%rax, 0x40(%rsp)
    1b31:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    1b3b:      	movq	%rax, 0x38(%rsp)
    1b40:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    1b4a:      	movq	%rax, 0x30(%rsp)
    1b4f:      	leaq	0x30(%rsp), %rdi
    1b54:      	movl	$0x2d, %eax
    1b59:      	movl	$0x6, %ecx
    1b5e:      	movl	$0x2d, %esi
    1b63:      	xorl	%eax, %eax
    1b65:      	callq	*%rcx
    1b67:      	jmp	0x1fa8 <perf_unwind_ruby+0x1fa8>
    1b6c:      	movabsq	$0x746e696f70206b63, %rax # imm = 0x746E696F70206B63
    1b76:      	movq	%rax, 0x50(%rsp)
    1b7b:      	movabsq	$0x61747320746e6572, %rax # imm = 0x61747320746E6572
    1b85:      	movq	%rax, 0x48(%rsp)
    1b8a:      	movabsq	$0x7275632064616572, %rax # imm = 0x7275632064616572
    1b94:      	movq	%rax, 0x40(%rsp)
    1b99:      	movabsq	$0x206f742064656c69, %rax # imm = 0x206F742064656C69
    1ba3:      	movq	%rax, 0x38(%rsp)
    1ba8:      	movabsq	$0x6166203a79627572, %rax # imm = 0x6166203A79627572
    1bb2:      	movq	%rax, 0x30(%rsp)
    1bb7:      	movl	$0xa7265, 0x58(%rsp)    # imm = 0xA7265
    1bbf:      	leaq	0x30(%rsp), %rdi
    1bc4:      	movl	$0x2c, %eax
    1bc9:      	movl	$0x6, %ecx
    1bce:      	movl	$0x2c, %esi
    1bd3:      	xorl	%eax, %eax
    1bd5:      	callq	*%rcx
    1bd7:      	jmp	0x543 <perf_unwind_ruby+0x543>
    1bdc:      	movabsq	$0xa79646f622071, %rax  # imm = 0xA79646F622071
    1be6:      	movq	%rax, 0x47(%rsp)
    1beb:      	movabsq	$0x7165736920746567, %rax # imm = 0x7165736920746567
    1bf5:      	movq	%rax, 0x40(%rsp)
    1bfa:      	movabsq	$0x206f742064656c69, %rax # imm = 0x206F742064656C69
    1c04:      	movq	%rax, 0x38(%rsp)
    1c09:      	movabsq	$0x6166203a79627572, %rax # imm = 0x6166203A79627572
    1c13:      	movq	%rax, 0x30(%rsp)
    1c18:      	leaq	0x30(%rsp), %rdi
    1c1d:      	movl	$0x1f, %eax
    1c22:      	movl	$0x6, %ecx
    1c27:      	movl	$0x1f, %esi
    1c2c:      	xorl	%eax, %eax
    1c2e:      	callq	*%rcx
    1c30:      	jmp	0x4d8 <perf_unwind_ruby+0x4d8>
    1c35:      	movq	$0x0, (%rsp)
    1c3d:      	movzbl	0x1d(%r15), %eax
    1c42:      	addq	0x8(%rsp), %rax
    1c47:      	movq	%rsp, %rdi
    1c4a:      	movl	$0x8, %ecx
    1c4f:      	movl	$0x70, %r8d
    1c55:      	movzbl	0x1d(%r15), %edx
    1c5a:      	addq	0x8(%rsp), %rdx
    1c5f:      	movl	$0x8, %esi
    1c64:      	callq	*%r8
    1c67:      	testq	%rax, %rax
    1c6a:      	jne	0x81b <perf_unwind_ruby+0x81b>
    1c70:      	movl	(%rsp), %eax
    1c73:      	notl	%eax
    1c75:      	testl	$0x140, %eax            # imm = 0x140
    1c7a:      	jne	0x997 <perf_unwind_ruby+0x997>
    1c80:      	jmp	0x1981 <perf_unwind_ruby+0x1981>
    1c85:      	movabsq	$0xa657a6973206b, %rax  # imm = 0xA657A6973206B
    1c8f:      	movq	%rax, 0x48(%rsp)
    1c94:      	movabsq	$0x6361747320746567, %rax # imm = 0x6361747320746567
    1c9e:      	movq	%rax, 0x40(%rsp)
    1ca3:      	movabsq	$0x206f742064656c69, %rax # imm = 0x206F742064656C69
    1cad:      	movq	%rax, 0x38(%rsp)
    1cb2:      	movabsq	$0x6166203a79627572, %rax # imm = 0x6166203A79627572
    1cbc:      	movq	%rax, 0x30(%rsp)
    1cc1:      	leaq	0x30(%rsp), %rdi
    1cc6:      	movl	$0x20, %eax
    1ccb:      	movl	$0x6, %ecx
    1cd0:      	movl	$0x20, %esi
    1cd5:      	xorl	%eax, %eax
    1cd7:      	callq	*%rcx
    1cd9:      	jmp	0x7b4 <perf_unwind_ruby+0x7b4>
    1cde:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1ce8:      	movq	%rax, 0x56(%rsp)
    1ced:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1cf7:      	movq	%rax, 0x50(%rsp)
    1cfc:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1d06:      	movq	%rax, 0x48(%rsp)
    1d0b:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1d15:      	movq	%rax, 0x40(%rsp)
    1d1a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1d24:      	movq	%rax, 0x38(%rsp)
    1d29:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1d33:      	movq	%rax, 0x30(%rsp)
    1d38:      	leaq	0x30(%rsp), %rdi
    1d3d:      	movl	$0x2e, %eax
    1d42:      	movl	$0x6, %ecx
    1d47:      	movl	0x18(%rsp), %edx
    1d4b:      	movl	$0x2e, %esi
    1d50:      	xorl	%eax, %eax
    1d52:      	callq	*%rcx
    1d54:      	jmp	0x862 <perf_unwind_ruby+0x862>
    1d59:      	movabsq	$0xa706520746567, %rax  # imm = 0xA706520746567
    1d63:      	movq	%rax, 0x40(%rsp)
    1d68:      	movabsq	$0x206f742064656c69, %rax # imm = 0x206F742064656C69
    1d72:      	movq	%rax, 0x38(%rsp)
    1d77:      	movabsq	$0x6166203a79627572, %rax # imm = 0x6166203A79627572
    1d81:      	movq	%rax, 0x30(%rsp)
    1d86:      	leaq	0x30(%rsp), %rdi
    1d8b:      	movl	$0x18, %eax
    1d90:      	movl	$0x6, %ecx
    1d95:      	movl	$0x18, %esi
    1d9a:      	xorl	%eax, %eax
    1d9c:      	callq	*%rcx
    1d9e:      	jmp	0x82c <perf_unwind_ruby+0x82c>
    1da3:      	movq	(%rip), %rax            # 0x1daa <perf_unwind_ruby+0x1daa>
    1daa:      	cmpl	$0x0, (%rax)
    1dad:      	je	0xe7c <perf_unwind_ruby+0xe7c>
    1db3:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1dbd:      	movq	%rax, 0x56(%rsp)
    1dc2:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1dcc:      	movq	%rax, 0x50(%rsp)
    1dd1:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1ddb:      	movq	%rax, 0x48(%rsp)
    1de0:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1dea:      	movq	%rax, 0x40(%rsp)
    1def:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1df9:      	movq	%rax, 0x38(%rsp)
    1dfe:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1e08:      	movq	%rax, 0x30(%rsp)
    1e0d:      	leaq	0x30(%rsp), %rdi
    1e12:      	movl	$0x2e, %eax
    1e17:      	movl	$0x6, %ecx
    1e1c:      	movl	(%rsp), %edx
    1e1f:      	movl	$0x2e, %esi
    1e24:      	xorl	%eax, %eax
    1e26:      	callq	*%rcx
    1e28:      	jmp	0xe7c <perf_unwind_ruby+0xe7c>
    1e2d:      	movl	0x2c0(%r14), %eax
    1e34:      	cmpq	$0x7e, %rax
    1e38:      	ja	0xdd3 <perf_unwind_ruby+0xdd3>
    1e3e:      	movq	0x10(%rsp), %rcx
    1e43:      	movq	0x18(%rsp), %rdx
    1e48:      	leal	0x1(%rax), %esi
    1e4b:      	movl	%esi, 0x2c0(%r14)
    1e52:      	leaq	(%rax,%rax,2), %rax
    1e56:      	movw	$0x0, 0x4(%rsp)
    1e5d:      	movl	$0x0, (%rsp)
    1e64:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    1e6c:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    1e74:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    1e7f:      	movl	(%rsp), %ecx
    1e82:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    1e8a:      	movzwl	0x4(%rsp), %ecx
    1e8f:      	movw	%cx, 0x2e6(%r14,%rax,8)
    1e98:      	movl	$0x36, (%rsp)
    1e9f:      	movq	(%rip), %rdi            # 0x1ea6 <perf_unwind_ruby+0x1ea6>
    1ea6:      	movq	%rsp, %rsi
    1ea9:      	movl	$0x1, %eax
    1eae:      	callq	*%rax
    1eb0:      	testq	%rax, %rax
    1eb3:      	je	0x2476 <perf_unwind_ruby+0x2476>
    1eb9:      	incq	(%rax)
    1ebc:      	jmp	0x1326 <perf_unwind_ruby+0x1326>
    1ec1:      	movabsq	$0x6465646f636e6520, %rax # imm = 0x6465646F636E6520
    1ecb:      	movq	%rax, 0x48(%rsp)
    1ed0:      	movabsq	$0x7165736920746567, %rax # imm = 0x7165736920746567
    1eda:      	movq	%rax, 0x40(%rsp)
    1edf:      	movabsq	$0x206f742064656c69, %rax # imm = 0x206F742064656C69
    1ee9:      	movq	%rax, 0x38(%rsp)
    1eee:      	movabsq	$0x6166203a79627572, %rax # imm = 0x6166203A79627572
    1ef8:      	movq	%rax, 0x30(%rsp)
    1efd:      	movw	$0xa, 0x50(%rsp)
    1f04:      	leaq	0x30(%rsp), %rdi
    1f09:      	movl	$0x22, %eax
    1f0e:      	movl	$0x6, %ecx
    1f13:      	movl	$0x22, %esi
    1f18:      	xorl	%eax, %eax
    1f1a:      	callq	*%rcx
    1f1c:      	jmp	0x8b5 <perf_unwind_ruby+0x8b5>
    1f21:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1f2b:      	movq	%rax, 0x56(%rsp)
    1f30:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1f3a:      	movq	%rax, 0x50(%rsp)
    1f3f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1f49:      	movq	%rax, 0x48(%rsp)
    1f4e:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1f58:      	movq	%rax, 0x40(%rsp)
    1f5d:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1f67:      	movq	%rax, 0x38(%rsp)
    1f6c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1f76:      	movq	%rax, 0x30(%rsp)
    1f7b:      	leaq	0x30(%rsp), %rdi
    1f80:      	movl	$0x2e, %eax
    1f85:      	movl	$0x6, %ecx
    1f8a:      	movl	(%rsp), %edx
    1f8d:      	movl	$0x2e, %esi
    1f92:      	xorl	%eax, %eax
    1f94:      	callq	*%rcx
    1f96:      	jmp	0x8e8 <perf_unwind_ruby+0x8e8>
    1f9b:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    1fa2:      	jae	0x23ab <perf_unwind_ruby+0x23ab>
    1fa8:      	movq	0x8(%rsp), %rax
    1fad:      	cmpq	%rax, %r12
    1fb0:      	jbe	0x2b2 <perf_unwind_ruby+0x2b2>
    1fb6:      	movzbl	0x1e(%r15), %ecx
    1fbb:      	addq	%rcx, %rax
    1fbe:      	movq	%rax, 0x8(%rsp)
    1fc3:      	movq	$0x0, 0x18(%rsp)
    1fcc:      	movq	$0x0, 0x20(%rsp)
    1fd5:      	movzbl	0x1c(%r15), %ecx
    1fda:      	addq	%rax, %rcx
    1fdd:      	leaq	0x20(%rsp), %rdi
    1fe2:      	movl	$0x8, %eax
    1fe7:      	movl	$0x70, %r8d
    1fed:      	movzbl	0x1c(%r15), %edx
    1ff2:      	addq	0x8(%rsp), %rdx
    1ff7:      	movl	$0x8, %esi
    1ffc:      	callq	*%r8
    1fff:      	movzbl	0x1b(%r15), %eax
    2004:      	addq	0x8(%rsp), %rax
    2009:      	leaq	0x18(%rsp), %rdi
    200e:      	movl	$0x8, %ecx
    2013:      	movl	$0x70, %r8d
    2019:      	movzbl	0x1b(%r15), %edx
    201e:      	addq	0x8(%rsp), %rdx
    2023:      	movl	$0x8, %esi
    2028:      	callq	*%r8
    202b:      	cmpq	$0x0, 0x18(%rsp)
    2031:      	je	0x260e <perf_unwind_ruby+0x260e>
    2037:      	movq	0x20(%rsp), %rax
    203c:      	testq	%rax, %rax
    203f:      	je	0x260e <perf_unwind_ruby+0x260e>
    2045:      	movzbl	0x1f(%r15), %ecx
    204a:      	addq	%rcx, %rax
    204d:      	leaq	0x10(%rsp), %rdi
    2052:      	movl	$0x8, %ecx
    2057:      	movl	$0x70, %r8d
    205d:      	movzbl	0x1f(%r15), %edx
    2062:      	addq	0x20(%rsp), %rdx
    2067:      	movl	$0x8, %esi
    206c:      	callq	*%r8
    206f:      	testq	%rax, %rax
    2072:      	jne	0x4c7 <perf_unwind_ruby+0x4c7>
    2078:      	movzbl	0x21(%r15), %eax
    207d:      	addq	0x10(%rsp), %rax
    2082:      	leaq	0x68(%rsp), %rdi
    2087:      	movl	$0x8, %ecx
    208c:      	movl	$0x70, %r8d
    2092:      	movzbl	0x21(%r15), %edx
    2097:      	addq	0x10(%rsp), %rdx
    209c:      	movl	$0x8, %esi
    20a1:      	callq	*%r8
    20a4:      	testq	%rax, %rax
    20a7:      	jne	0x8a4 <perf_unwind_ruby+0x8a4>
    20ad:      	movzbl	0x22(%r15), %eax
    20b2:      	addq	0x10(%rsp), %rax
    20b7:      	leaq	0x2c(%rsp), %rdi
    20bc:      	movl	$0x4, %ecx
    20c1:      	movl	$0x70, %r8d
    20c7:      	movzbl	0x22(%r15), %edx
    20cc:      	addq	0x10(%rsp), %rdx
    20d1:      	movl	$0x4, %esi
    20d6:      	callq	*%r8
    20d9:      	testq	%rax, %rax
    20dc:      	jne	0xc08 <perf_unwind_ruby+0xc08>
    20e2:      	movzbl	0x23(%r15), %ecx
    20e7:      	testq	%rcx, %rcx
    20ea:      	je	0x2d3b <perf_unwind_ruby+0x2d3b>
    20f0:      	movq	0x18(%rsp), %rax
    20f5:      	subq	0x68(%rsp), %rax
    20fa:      	xorl	%edx, %edx
    20fc:      	divq	%rcx
    20ff:      	movl	0x2c(%rsp), %ecx
    2103:      	cmpq	%rcx, %rax
    2106:      	jbe	0x2d3b <perf_unwind_ruby+0x2d3b>
    210c:      	movq	(%rip), %rax            # 0x2113 <perf_unwind_ruby+0x2113>
    2113:      	cmpl	$0x0, (%rax)
    2116:      	je	0x261b <perf_unwind_ruby+0x261b>
    211c:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    2126:      	movq	%rax, 0x55(%rsp)
    212b:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    2135:      	movq	%rax, 0x50(%rsp)
    213a:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    2144:      	movq	%rax, 0x48(%rsp)
    2149:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    2153:      	movq	%rax, 0x40(%rsp)
    2158:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    2162:      	movq	%rax, 0x38(%rsp)
    2167:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    2171:      	movq	%rax, 0x30(%rsp)
    2176:      	leaq	0x30(%rsp), %rdi
    217b:      	movl	$0x2d, %eax
    2180:      	movl	$0x6, %ecx
    2185:      	movl	$0x2d, %esi
    218a:      	xorl	%eax, %eax
    218c:      	callq	*%rcx
    218e:      	jmp	0x261b <perf_unwind_ruby+0x261b>
    2193:      	movabsq	$0xa70666320746567, %rax # imm = 0xA70666320746567
    219d:      	movq	%rax, 0x40(%rsp)
    21a2:      	movabsq	$0x206f742064656c69, %rax # imm = 0x206F742064656C69
    21ac:      	movq	%rax, 0x38(%rsp)
    21b1:      	movabsq	$0x6166203a79627572, %rax # imm = 0x6166203A79627572
    21bb:      	movq	%rax, 0x30(%rsp)
    21c0:      	movb	$0x0, 0x48(%rsp)
    21c5:      	leaq	0x30(%rsp), %rdi
    21ca:      	movl	$0x19, %eax
    21cf:      	movl	$0x6, %ecx
    21d4:      	movl	$0x19, %esi
    21d9:      	xorl	%eax, %eax
    21db:      	callq	*%rcx
    21dd:      	jmp	0x95b <perf_unwind_ruby+0x95b>
    21e2:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    21ec:      	movq	%rax, 0x56(%rsp)
    21f1:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    21fb:      	movq	%rax, 0x50(%rsp)
    2200:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    220a:      	movq	%rax, 0x48(%rsp)
    220f:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2219:      	movq	%rax, 0x40(%rsp)
    221e:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2228:      	movq	%rax, 0x38(%rsp)
    222d:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2237:      	movq	%rax, 0x30(%rsp)
    223c:      	leaq	0x30(%rsp), %rdi
    2241:      	movl	$0x2e, %eax
    2246:      	movl	$0x6, %ecx
    224b:      	movl	0x18(%rsp), %edx
    224f:      	movl	$0x2e, %esi
    2254:      	xorl	%eax, %eax
    2256:      	callq	*%rcx
    2258:      	jmp	0x9cb <perf_unwind_ruby+0x9cb>
    225d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2267:      	movq	%rax, 0x56(%rsp)
    226c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2276:      	movq	%rax, 0x50(%rsp)
    227b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2285:      	movq	%rax, 0x48(%rsp)
    228a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2294:      	movq	%rax, 0x40(%rsp)
    2299:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    22a3:      	movq	%rax, 0x38(%rsp)
    22a8:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    22b2:      	movq	%rax, 0x30(%rsp)
    22b7:      	leaq	0x30(%rsp), %rdi
    22bc:      	movl	$0x2e, %eax
    22c1:      	movl	$0x6, %ecx
    22c6:      	movl	0x74(%rsp), %edx
    22ca:      	movl	$0x2e, %esi
    22cf:      	xorl	%eax, %eax
    22d1:      	callq	*%rcx
    22d3:      	jmp	0xc4c <perf_unwind_ruby+0xc4c>
    22d8:      	movabsq	$0xa657a69732071, %rax  # imm = 0xA657A69732071
    22e2:      	movq	%rax, 0x47(%rsp)
    22e7:      	movabsq	$0x7165736920746567, %rax # imm = 0x7165736920746567
    22f1:      	movq	%rax, 0x40(%rsp)
    22f6:      	movabsq	$0x206f742064656c69, %rax # imm = 0x206F742064656C69
    2300:      	movq	%rax, 0x38(%rsp)
    2305:      	movabsq	$0x6166203a79627572, %rax # imm = 0x6166203A79627572
    230f:      	movq	%rax, 0x30(%rsp)
    2314:      	leaq	0x30(%rsp), %rdi
    2319:      	movl	$0x1f, %eax
    231e:      	movl	$0x6, %ecx
    2323:      	movl	$0x1f, %esi
    2328:      	xorl	%eax, %eax
    232a:      	callq	*%rcx
    232c:      	jmp	0xc19 <perf_unwind_ruby+0xc19>
    2331:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    233b:      	movq	%rax, 0x56(%rsp)
    2340:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    234a:      	movq	%rax, 0x50(%rsp)
    234f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2359:      	movq	%rax, 0x48(%rsp)
    235e:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2368:      	movq	%rax, 0x40(%rsp)
    236d:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2377:      	movq	%rax, 0x38(%rsp)
    237c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2386:      	movq	%rax, 0x30(%rsp)
    238b:      	leaq	0x30(%rsp), %rdi
    2390:      	movl	$0x2e, %eax
    2395:      	movl	$0x6, %ecx
    239a:      	movl	(%rsp), %edx
    239d:      	movl	$0x2e, %esi
    23a2:      	xorl	%eax, %eax
    23a4:      	callq	*%rcx
    23a6:      	jmp	0xc63 <perf_unwind_ruby+0xc63>
    23ab:      	movq	$0x0, (%rsp)
    23b3:      	movzbl	0x1d(%r15), %eax
    23b8:      	addq	0x8(%rsp), %rax
    23bd:      	movq	%rsp, %rdi
    23c0:      	movl	$0x8, %ecx
    23c5:      	movl	$0x70, %r8d
    23cb:      	movzbl	0x1d(%r15), %edx
    23d0:      	addq	0x8(%rsp), %rdx
    23d5:      	movl	$0x8, %esi
    23da:      	callq	*%r8
    23dd:      	testq	%rax, %rax
    23e0:      	jne	0x81b <perf_unwind_ruby+0x81b>
    23e6:      	movl	(%rsp), %eax
    23e9:      	notl	%eax
    23eb:      	testl	$0x140, %eax            # imm = 0x140
    23f0:      	jne	0x997 <perf_unwind_ruby+0x997>
    23f6:      	jmp	0x1fa8 <perf_unwind_ruby+0x1fa8>
    23fb:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2405:      	movq	%rax, 0x56(%rsp)
    240a:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2414:      	movq	%rax, 0x50(%rsp)
    2419:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2423:      	movq	%rax, 0x48(%rsp)
    2428:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2432:      	movq	%rax, 0x40(%rsp)
    2437:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2441:      	movq	%rax, 0x38(%rsp)
    2446:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2450:      	movq	%rax, 0x30(%rsp)
    2455:      	leaq	0x30(%rsp), %rdi
    245a:      	movl	$0x2e, %eax
    245f:      	movl	$0x6, %ecx
    2464:      	movl	0x18(%rsp), %edx
    2468:      	movl	$0x2e, %esi
    246d:      	xorl	%eax, %eax
    246f:      	callq	*%rcx
    2471:      	jmp	0xced <perf_unwind_ruby+0xced>
    2476:      	movq	(%rip), %rax            # 0x247d <perf_unwind_ruby+0x247d>
    247d:      	cmpl	$0x0, (%rax)
    2480:      	je	0x1326 <perf_unwind_ruby+0x1326>
    2486:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2490:      	movq	%rax, 0x56(%rsp)
    2495:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    249f:      	movq	%rax, 0x50(%rsp)
    24a4:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    24ae:      	movq	%rax, 0x48(%rsp)
    24b3:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    24bd:      	movq	%rax, 0x40(%rsp)
    24c2:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    24cc:      	movq	%rax, 0x38(%rsp)
    24d1:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    24db:      	movq	%rax, 0x30(%rsp)
    24e0:      	leaq	0x30(%rsp), %rdi
    24e5:      	movl	$0x2e, %eax
    24ea:      	movl	$0x6, %ecx
    24ef:      	movl	(%rsp), %edx
    24f2:      	movl	$0x2e, %esi
    24f7:      	xorl	%eax, %eax
    24f9:      	callq	*%rcx
    24fb:      	jmp	0x1326 <perf_unwind_ruby+0x1326>
    2500:      	movl	0x2c0(%r14), %eax
    2507:      	cmpq	$0x7e, %rax
    250b:      	ja	0xdd3 <perf_unwind_ruby+0xdd3>
    2511:      	movq	0x10(%rsp), %rcx
    2516:      	movq	0x18(%rsp), %rdx
    251b:      	leal	0x1(%rax), %esi
    251e:      	movl	%esi, 0x2c0(%r14)
    2525:      	leaq	(%rax,%rax,2), %rax
    2529:      	movw	$0x0, 0x4(%rsp)
    2530:      	movl	$0x0, (%rsp)
    2537:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    253f:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    2547:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    2552:      	movl	(%rsp), %ecx
    2555:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    255d:      	movzwl	0x4(%rsp), %ecx
    2562:      	movw	%cx, 0x2e6(%r14,%rax,8)
    256b:      	movl	$0x36, (%rsp)
    2572:      	movq	(%rip), %rdi            # 0x2579 <perf_unwind_ruby+0x2579>
    2579:      	movq	%rsp, %rsi
    257c:      	movl	$0x1, %eax
    2581:      	callq	*%rax
    2583:      	testq	%rax, %rax
    2586:      	je	0x28be <perf_unwind_ruby+0x28be>
    258c:      	incq	(%rax)
    258f:      	jmp	0x1981 <perf_unwind_ruby+0x1981>
    2594:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    259e:      	movq	%rax, 0x56(%rsp)
    25a3:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    25ad:      	movq	%rax, 0x50(%rsp)
    25b2:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    25bc:      	movq	%rax, 0x48(%rsp)
    25c1:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    25cb:      	movq	%rax, 0x40(%rsp)
    25d0:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    25da:      	movq	%rax, 0x38(%rsp)
    25df:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    25e9:      	movq	%rax, 0x30(%rsp)
    25ee:      	leaq	0x30(%rsp), %rdi
    25f3:      	movl	$0x2e, %eax
    25f8:      	movl	$0x6, %ecx
    25fd:      	movl	(%rsp), %edx
    2600:      	movl	$0x2e, %esi
    2605:      	xorl	%eax, %eax
    2607:      	callq	*%rcx
    2609:      	jmp	0xdb5 <perf_unwind_ruby+0xdb5>
    260e:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    2615:      	jae	0x286e <perf_unwind_ruby+0x286e>
    261b:      	movq	0x8(%rsp), %rax
    2620:      	cmpq	%rax, %r12
    2623:      	jbe	0x2b2 <perf_unwind_ruby+0x2b2>
    2629:      	movzbl	0x1e(%r15), %ecx
    262e:      	addq	%rcx, %rax
    2631:      	movq	%rax, 0x8(%rsp)
    2636:      	movq	$0x0, 0x18(%rsp)
    263f:      	movq	$0x0, 0x20(%rsp)
    2648:      	movzbl	0x1c(%r15), %ecx
    264d:      	addq	%rax, %rcx
    2650:      	leaq	0x20(%rsp), %rdi
    2655:      	movl	$0x8, %eax
    265a:      	movl	$0x70, %r8d
    2660:      	movzbl	0x1c(%r15), %edx
    2665:      	addq	0x8(%rsp), %rdx
    266a:      	movl	$0x8, %esi
    266f:      	callq	*%r8
    2672:      	movzbl	0x1b(%r15), %eax
    2677:      	addq	0x8(%rsp), %rax
    267c:      	leaq	0x18(%rsp), %rdi
    2681:      	movl	$0x8, %ecx
    2686:      	movl	$0x70, %r8d
    268c:      	movzbl	0x1b(%r15), %edx
    2691:      	addq	0x8(%rsp), %rdx
    2696:      	movl	$0x8, %esi
    269b:      	callq	*%r8
    269e:      	cmpq	$0x0, 0x18(%rsp)
    26a4:      	je	0x2a69 <perf_unwind_ruby+0x2a69>
    26aa:      	movq	0x20(%rsp), %rax
    26af:      	testq	%rax, %rax
    26b2:      	je	0x2a69 <perf_unwind_ruby+0x2a69>
    26b8:      	movzbl	0x1f(%r15), %ecx
    26bd:      	addq	%rcx, %rax
    26c0:      	leaq	0x10(%rsp), %rdi
    26c5:      	movl	$0x8, %ecx
    26ca:      	movl	$0x70, %r8d
    26d0:      	movzbl	0x1f(%r15), %edx
    26d5:      	addq	0x20(%rsp), %rdx
    26da:      	movl	$0x8, %esi
    26df:      	callq	*%r8
    26e2:      	testq	%rax, %rax
    26e5:      	jne	0x4c7 <perf_unwind_ruby+0x4c7>
    26eb:      	movzbl	0x21(%r15), %eax
    26f0:      	addq	0x10(%rsp), %rax
    26f5:      	leaq	0x68(%rsp), %rdi
    26fa:      	movl	$0x8, %ecx
    26ff:      	movl	$0x70, %r8d
    2705:      	movzbl	0x21(%r15), %edx
    270a:      	addq	0x10(%rsp), %rdx
    270f:      	movl	$0x8, %esi
    2714:      	callq	*%r8
    2717:      	testq	%rax, %rax
    271a:      	jne	0x8a4 <perf_unwind_ruby+0x8a4>
    2720:      	movzbl	0x22(%r15), %eax
    2725:      	addq	0x10(%rsp), %rax
    272a:      	leaq	0x2c(%rsp), %rdi
    272f:      	movl	$0x4, %ecx
    2734:      	movl	$0x70, %r8d
    273a:      	movzbl	0x22(%r15), %edx
    273f:      	addq	0x10(%rsp), %rdx
    2744:      	movl	$0x4, %esi
    2749:      	callq	*%r8
    274c:      	testq	%rax, %rax
    274f:      	jne	0xc08 <perf_unwind_ruby+0xc08>
    2755:      	movzbl	0x23(%r15), %ecx
    275a:      	testq	%rcx, %rcx
    275d:      	je	0x30a1 <perf_unwind_ruby+0x30a1>
    2763:      	movq	0x18(%rsp), %rax
    2768:      	subq	0x68(%rsp), %rax
    276d:      	xorl	%edx, %edx
    276f:      	divq	%rcx
    2772:      	movl	0x2c(%rsp), %ecx
    2776:      	cmpq	%rcx, %rax
    2779:      	jbe	0x30a1 <perf_unwind_ruby+0x30a1>
    277f:      	movq	(%rip), %rax            # 0x2786 <perf_unwind_ruby+0x2786>
    2786:      	cmpl	$0x0, (%rax)
    2789:      	je	0x2a76 <perf_unwind_ruby+0x2a76>
    278f:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    2799:      	movq	%rax, 0x55(%rsp)
    279e:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    27a8:      	movq	%rax, 0x50(%rsp)
    27ad:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    27b7:      	movq	%rax, 0x48(%rsp)
    27bc:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    27c6:      	movq	%rax, 0x40(%rsp)
    27cb:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    27d5:      	movq	%rax, 0x38(%rsp)
    27da:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    27e4:      	movq	%rax, 0x30(%rsp)
    27e9:      	leaq	0x30(%rsp), %rdi
    27ee:      	movl	$0x2d, %eax
    27f3:      	movl	$0x6, %ecx
    27f8:      	movl	$0x2d, %esi
    27fd:      	xorl	%eax, %eax
    27ff:      	callq	*%rcx
    2801:      	jmp	0x2a76 <perf_unwind_ruby+0x2a76>
    2806:      	movabsq	$0xa6c6c75662073, %rax  # imm = 0xA6C6C75662073
    2810:      	movq	%rax, 0x4d(%rsp)
    2815:      	movabsq	$0x66207369206b6361, %rax # imm = 0x66207369206B6361
    281f:      	movq	%rax, 0x48(%rsp)
    2824:      	movabsq	$0x7473203a656d6172, %rax # imm = 0x7473203A656D6172
    282e:      	movq	%rax, 0x40(%rsp)
    2833:      	movabsq	$0x662068737570206f, %rax # imm = 0x662068737570206F
    283d:      	movq	%rax, 0x38(%rsp)
    2842:      	movabsq	$0x7420656c62616e75, %rax # imm = 0x7420656C62616E75
    284c:      	movq	%rax, 0x30(%rsp)
    2851:      	leaq	0x30(%rsp), %rdi
    2856:      	movl	$0x25, %eax
    285b:      	movl	$0x6, %ecx
    2860:      	movl	$0x25, %esi
    2865:      	xorl	%eax, %eax
    2867:      	callq	*%rcx
    2869:      	jmp	0xde4 <perf_unwind_ruby+0xde4>
    286e:      	movq	$0x0, (%rsp)
    2876:      	movzbl	0x1d(%r15), %eax
    287b:      	addq	0x8(%rsp), %rax
    2880:      	movq	%rsp, %rdi
    2883:      	movl	$0x8, %ecx
    2888:      	movl	$0x70, %r8d
    288e:      	movzbl	0x1d(%r15), %edx
    2893:      	addq	0x8(%rsp), %rdx
    2898:      	movl	$0x8, %esi
    289d:      	callq	*%r8
    28a0:      	testq	%rax, %rax
    28a3:      	jne	0x81b <perf_unwind_ruby+0x81b>
    28a9:      	movl	(%rsp), %eax
    28ac:      	notl	%eax
    28ae:      	testl	$0x140, %eax            # imm = 0x140
    28b3:      	jne	0x997 <perf_unwind_ruby+0x997>
    28b9:      	jmp	0x261b <perf_unwind_ruby+0x261b>
    28be:      	movq	(%rip), %rax            # 0x28c5 <perf_unwind_ruby+0x28c5>
    28c5:      	cmpl	$0x0, (%rax)
    28c8:      	je	0x1981 <perf_unwind_ruby+0x1981>
    28ce:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    28d8:      	movq	%rax, 0x56(%rsp)
    28dd:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    28e7:      	movq	%rax, 0x50(%rsp)
    28ec:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    28f6:      	movq	%rax, 0x48(%rsp)
    28fb:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2905:      	movq	%rax, 0x40(%rsp)
    290a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2914:      	movq	%rax, 0x38(%rsp)
    2919:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2923:      	movq	%rax, 0x30(%rsp)
    2928:      	leaq	0x30(%rsp), %rdi
    292d:      	movl	$0x2e, %eax
    2932:      	movl	$0x6, %ecx
    2937:      	movl	(%rsp), %edx
    293a:      	movl	$0x2e, %esi
    293f:      	xorl	%eax, %eax
    2941:      	callq	*%rcx
    2943:      	jmp	0x1981 <perf_unwind_ruby+0x1981>
    2948:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2952:      	movq	%rax, 0x56(%rsp)
    2957:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2961:      	movq	%rax, 0x50(%rsp)
    2966:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2970:      	movq	%rax, 0x48(%rsp)
    2975:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    297f:      	movq	%rax, 0x40(%rsp)
    2984:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    298e:      	movq	%rax, 0x38(%rsp)
    2993:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    299d:      	movq	%rax, 0x30(%rsp)
    29a2:      	leaq	0x30(%rsp), %rdi
    29a7:      	movl	$0x2e, %eax
    29ac:      	movl	$0x6, %ecx
    29b1:      	movl	0x74(%rsp), %edx
    29b5:      	movl	$0x2e, %esi
    29ba:      	xorl	%eax, %eax
    29bc:      	callq	*%rcx
    29be:      	cmpl	$0x0, (%r15)
    29c2:      	movl	$0x2, %r13d
    29c8:      	jne	0xe1b <perf_unwind_ruby+0xe1b>
    29ce:      	xorl	%ebp, %ebp
    29d0:      	jmp	0x2b2 <perf_unwind_ruby+0x2b2>
    29d5:      	movl	0x2c0(%r14), %eax
    29dc:      	cmpq	$0x7e, %rax
    29e0:      	ja	0xdd3 <perf_unwind_ruby+0xdd3>
    29e6:      	movq	0x10(%rsp), %rcx
    29eb:      	movq	0x18(%rsp), %rdx
    29f0:      	leal	0x1(%rax), %esi
    29f3:      	movl	%esi, 0x2c0(%r14)
    29fa:      	leaq	(%rax,%rax,2), %rax
    29fe:      	movw	$0x0, 0x4(%rsp)
    2a05:      	movl	$0x0, (%rsp)
    2a0c:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    2a14:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    2a1c:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    2a27:      	movl	(%rsp), %ecx
    2a2a:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    2a32:      	movzwl	0x4(%rsp), %ecx
    2a37:      	movw	%cx, 0x2e6(%r14,%rax,8)
    2a40:      	movl	$0x36, (%rsp)
    2a47:      	movq	(%rip), %rdi            # 0x2a4e <perf_unwind_ruby+0x2a4e>
    2a4e:      	movq	%rsp, %rsi
    2a51:      	movl	$0x1, %eax
    2a56:      	callq	*%rax
    2a58:      	testq	%rax, %rax
    2a5b:      	je	0x2cb1 <perf_unwind_ruby+0x2cb1>
    2a61:      	incq	(%rax)
    2a64:      	jmp	0x1fa8 <perf_unwind_ruby+0x1fa8>
    2a69:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    2a70:      	jae	0x2c61 <perf_unwind_ruby+0x2c61>
    2a76:      	movq	0x8(%rsp), %rax
    2a7b:      	cmpq	%rax, %r12
    2a7e:      	jbe	0x2b2 <perf_unwind_ruby+0x2b2>
    2a84:      	movzbl	0x1e(%r15), %ecx
    2a89:      	addq	%rcx, %rax
    2a8c:      	movq	%rax, 0x8(%rsp)
    2a91:      	movq	$0x0, 0x18(%rsp)
    2a9a:      	movq	$0x0, 0x20(%rsp)
    2aa3:      	movzbl	0x1c(%r15), %ecx
    2aa8:      	addq	%rax, %rcx
    2aab:      	leaq	0x20(%rsp), %rdi
    2ab0:      	movl	$0x8, %eax
    2ab5:      	movl	$0x70, %r8d
    2abb:      	movzbl	0x1c(%r15), %edx
    2ac0:      	addq	0x8(%rsp), %rdx
    2ac5:      	movl	$0x8, %esi
    2aca:      	callq	*%r8
    2acd:      	movzbl	0x1b(%r15), %eax
    2ad2:      	addq	0x8(%rsp), %rax
    2ad7:      	leaq	0x18(%rsp), %rdi
    2adc:      	movl	$0x8, %ecx
    2ae1:      	movl	$0x70, %r8d
    2ae7:      	movzbl	0x1b(%r15), %edx
    2aec:      	addq	0x8(%rsp), %rdx
    2af1:      	movl	$0x8, %esi
    2af6:      	callq	*%r8
    2af9:      	cmpq	$0x0, 0x18(%rsp)
    2aff:      	je	0x2dcf <perf_unwind_ruby+0x2dcf>
    2b05:      	movq	0x20(%rsp), %rax
    2b0a:      	testq	%rax, %rax
    2b0d:      	je	0x2dcf <perf_unwind_ruby+0x2dcf>
    2b13:      	movzbl	0x1f(%r15), %ecx
    2b18:      	addq	%rcx, %rax
    2b1b:      	leaq	0x10(%rsp), %rdi
    2b20:      	movl	$0x8, %ecx
    2b25:      	movl	$0x70, %r8d
    2b2b:      	movzbl	0x1f(%r15), %edx
    2b30:      	addq	0x20(%rsp), %rdx
    2b35:      	movl	$0x8, %esi
    2b3a:      	callq	*%r8
    2b3d:      	testq	%rax, %rax
    2b40:      	jne	0x4c7 <perf_unwind_ruby+0x4c7>
    2b46:      	movzbl	0x21(%r15), %eax
    2b4b:      	addq	0x10(%rsp), %rax
    2b50:      	leaq	0x68(%rsp), %rdi
    2b55:      	movl	$0x8, %ecx
    2b5a:      	movl	$0x70, %r8d
    2b60:      	movzbl	0x21(%r15), %edx
    2b65:      	addq	0x10(%rsp), %rdx
    2b6a:      	movl	$0x8, %esi
    2b6f:      	callq	*%r8
    2b72:      	testq	%rax, %rax
    2b75:      	jne	0x8a4 <perf_unwind_ruby+0x8a4>
    2b7b:      	movzbl	0x22(%r15), %eax
    2b80:      	addq	0x10(%rsp), %rax
    2b85:      	leaq	0x2c(%rsp), %rdi
    2b8a:      	movl	$0x4, %ecx
    2b8f:      	movl	$0x70, %r8d
    2b95:      	movzbl	0x22(%r15), %edx
    2b9a:      	addq	0x10(%rsp), %rdx
    2b9f:      	movl	$0x4, %esi
    2ba4:      	callq	*%r8
    2ba7:      	testq	%rax, %rax
    2baa:      	jne	0xc08 <perf_unwind_ruby+0xc08>
    2bb0:      	movzbl	0x23(%r15), %ecx
    2bb5:      	testq	%rcx, %rcx
    2bb8:      	je	0x3407 <perf_unwind_ruby+0x3407>
    2bbe:      	movq	0x18(%rsp), %rax
    2bc3:      	subq	0x68(%rsp), %rax
    2bc8:      	xorl	%edx, %edx
    2bca:      	divq	%rcx
    2bcd:      	movl	0x2c(%rsp), %ecx
    2bd1:      	cmpq	%rcx, %rax
    2bd4:      	jbe	0x3407 <perf_unwind_ruby+0x3407>
    2bda:      	movq	(%rip), %rax            # 0x2be1 <perf_unwind_ruby+0x2be1>
    2be1:      	cmpl	$0x0, (%rax)
    2be4:      	je	0x2ddc <perf_unwind_ruby+0x2ddc>
    2bea:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    2bf4:      	movq	%rax, 0x55(%rsp)
    2bf9:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    2c03:      	movq	%rax, 0x50(%rsp)
    2c08:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    2c12:      	movq	%rax, 0x48(%rsp)
    2c17:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    2c21:      	movq	%rax, 0x40(%rsp)
    2c26:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    2c30:      	movq	%rax, 0x38(%rsp)
    2c35:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    2c3f:      	movq	%rax, 0x30(%rsp)
    2c44:      	leaq	0x30(%rsp), %rdi
    2c49:      	movl	$0x2d, %eax
    2c4e:      	movl	$0x6, %ecx
    2c53:      	movl	$0x2d, %esi
    2c58:      	xorl	%eax, %eax
    2c5a:      	callq	*%rcx
    2c5c:      	jmp	0x2ddc <perf_unwind_ruby+0x2ddc>
    2c61:      	movq	$0x0, (%rsp)
    2c69:      	movzbl	0x1d(%r15), %eax
    2c6e:      	addq	0x8(%rsp), %rax
    2c73:      	movq	%rsp, %rdi
    2c76:      	movl	$0x8, %ecx
    2c7b:      	movl	$0x70, %r8d
    2c81:      	movzbl	0x1d(%r15), %edx
    2c86:      	addq	0x8(%rsp), %rdx
    2c8b:      	movl	$0x8, %esi
    2c90:      	callq	*%r8
    2c93:      	testq	%rax, %rax
    2c96:      	jne	0x81b <perf_unwind_ruby+0x81b>
    2c9c:      	movl	(%rsp), %eax
    2c9f:      	notl	%eax
    2ca1:      	testl	$0x140, %eax            # imm = 0x140
    2ca6:      	jne	0x997 <perf_unwind_ruby+0x997>
    2cac:      	jmp	0x2a76 <perf_unwind_ruby+0x2a76>
    2cb1:      	movq	(%rip), %rax            # 0x2cb8 <perf_unwind_ruby+0x2cb8>
    2cb8:      	cmpl	$0x0, (%rax)
    2cbb:      	je	0x1fa8 <perf_unwind_ruby+0x1fa8>
    2cc1:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2ccb:      	movq	%rax, 0x56(%rsp)
    2cd0:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2cda:      	movq	%rax, 0x50(%rsp)
    2cdf:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2ce9:      	movq	%rax, 0x48(%rsp)
    2cee:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2cf8:      	movq	%rax, 0x40(%rsp)
    2cfd:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2d07:      	movq	%rax, 0x38(%rsp)
    2d0c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2d16:      	movq	%rax, 0x30(%rsp)
    2d1b:      	leaq	0x30(%rsp), %rdi
    2d20:      	movl	$0x2e, %eax
    2d25:      	movl	$0x6, %ecx
    2d2a:      	movl	(%rsp), %edx
    2d2d:      	movl	$0x2e, %esi
    2d32:      	xorl	%eax, %eax
    2d34:      	callq	*%rcx
    2d36:      	jmp	0x1fa8 <perf_unwind_ruby+0x1fa8>
    2d3b:      	movl	0x2c0(%r14), %eax
    2d42:      	cmpq	$0x7e, %rax
    2d46:      	ja	0xdd3 <perf_unwind_ruby+0xdd3>
    2d4c:      	movq	0x10(%rsp), %rcx
    2d51:      	movq	0x18(%rsp), %rdx
    2d56:      	leal	0x1(%rax), %esi
    2d59:      	movl	%esi, 0x2c0(%r14)
    2d60:      	leaq	(%rax,%rax,2), %rax
    2d64:      	movw	$0x0, 0x4(%rsp)
    2d6b:      	movl	$0x0, (%rsp)
    2d72:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    2d7a:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    2d82:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    2d8d:      	movl	(%rsp), %ecx
    2d90:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    2d98:      	movzwl	0x4(%rsp), %ecx
    2d9d:      	movw	%cx, 0x2e6(%r14,%rax,8)
    2da6:      	movl	$0x36, (%rsp)
    2dad:      	movq	(%rip), %rdi            # 0x2db4 <perf_unwind_ruby+0x2db4>
    2db4:      	movq	%rsp, %rsi
    2db7:      	movl	$0x1, %eax
    2dbc:      	callq	*%rax
    2dbe:      	testq	%rax, %rax
    2dc1:      	je	0x3017 <perf_unwind_ruby+0x3017>
    2dc7:      	incq	(%rax)
    2dca:      	jmp	0x261b <perf_unwind_ruby+0x261b>
    2dcf:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    2dd6:      	jae	0x2fc7 <perf_unwind_ruby+0x2fc7>
    2ddc:      	movq	0x8(%rsp), %rax
    2de1:      	cmpq	%rax, %r12
    2de4:      	jbe	0x2b2 <perf_unwind_ruby+0x2b2>
    2dea:      	movzbl	0x1e(%r15), %ecx
    2def:      	addq	%rcx, %rax
    2df2:      	movq	%rax, 0x8(%rsp)
    2df7:      	movq	$0x0, 0x18(%rsp)
    2e00:      	movq	$0x0, 0x20(%rsp)
    2e09:      	movzbl	0x1c(%r15), %ecx
    2e0e:      	addq	%rax, %rcx
    2e11:      	leaq	0x20(%rsp), %rdi
    2e16:      	movl	$0x8, %eax
    2e1b:      	movl	$0x70, %r8d
    2e21:      	movzbl	0x1c(%r15), %edx
    2e26:      	addq	0x8(%rsp), %rdx
    2e2b:      	movl	$0x8, %esi
    2e30:      	callq	*%r8
    2e33:      	movzbl	0x1b(%r15), %eax
    2e38:      	addq	0x8(%rsp), %rax
    2e3d:      	leaq	0x18(%rsp), %rdi
    2e42:      	movl	$0x8, %ecx
    2e47:      	movl	$0x70, %r8d
    2e4d:      	movzbl	0x1b(%r15), %edx
    2e52:      	addq	0x8(%rsp), %rdx
    2e57:      	movl	$0x8, %esi
    2e5c:      	callq	*%r8
    2e5f:      	cmpq	$0x0, 0x18(%rsp)
    2e65:      	je	0x3135 <perf_unwind_ruby+0x3135>
    2e6b:      	movq	0x20(%rsp), %rax
    2e70:      	testq	%rax, %rax
    2e73:      	je	0x3135 <perf_unwind_ruby+0x3135>
    2e79:      	movzbl	0x1f(%r15), %ecx
    2e7e:      	addq	%rcx, %rax
    2e81:      	leaq	0x10(%rsp), %rdi
    2e86:      	movl	$0x8, %ecx
    2e8b:      	movl	$0x70, %r8d
    2e91:      	movzbl	0x1f(%r15), %edx
    2e96:      	addq	0x20(%rsp), %rdx
    2e9b:      	movl	$0x8, %esi
    2ea0:      	callq	*%r8
    2ea3:      	testq	%rax, %rax
    2ea6:      	jne	0x4c7 <perf_unwind_ruby+0x4c7>
    2eac:      	movzbl	0x21(%r15), %eax
    2eb1:      	addq	0x10(%rsp), %rax
    2eb6:      	leaq	0x68(%rsp), %rdi
    2ebb:      	movl	$0x8, %ecx
    2ec0:      	movl	$0x70, %r8d
    2ec6:      	movzbl	0x21(%r15), %edx
    2ecb:      	addq	0x10(%rsp), %rdx
    2ed0:      	movl	$0x8, %esi
    2ed5:      	callq	*%r8
    2ed8:      	testq	%rax, %rax
    2edb:      	jne	0x8a4 <perf_unwind_ruby+0x8a4>
    2ee1:      	movzbl	0x22(%r15), %eax
    2ee6:      	addq	0x10(%rsp), %rax
    2eeb:      	leaq	0x2c(%rsp), %rdi
    2ef0:      	movl	$0x4, %ecx
    2ef5:      	movl	$0x70, %r8d
    2efb:      	movzbl	0x22(%r15), %edx
    2f00:      	addq	0x10(%rsp), %rdx
    2f05:      	movl	$0x4, %esi
    2f0a:      	callq	*%r8
    2f0d:      	testq	%rax, %rax
    2f10:      	jne	0xc08 <perf_unwind_ruby+0xc08>
    2f16:      	movzbl	0x23(%r15), %ecx
    2f1b:      	testq	%rcx, %rcx
    2f1e:      	je	0x376d <perf_unwind_ruby+0x376d>
    2f24:      	movq	0x18(%rsp), %rax
    2f29:      	subq	0x68(%rsp), %rax
    2f2e:      	xorl	%edx, %edx
    2f30:      	divq	%rcx
    2f33:      	movl	0x2c(%rsp), %ecx
    2f37:      	cmpq	%rcx, %rax
    2f3a:      	jbe	0x376d <perf_unwind_ruby+0x376d>
    2f40:      	movq	(%rip), %rax            # 0x2f47 <perf_unwind_ruby+0x2f47>
    2f47:      	cmpl	$0x0, (%rax)
    2f4a:      	je	0x3142 <perf_unwind_ruby+0x3142>
    2f50:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    2f5a:      	movq	%rax, 0x55(%rsp)
    2f5f:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    2f69:      	movq	%rax, 0x50(%rsp)
    2f6e:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    2f78:      	movq	%rax, 0x48(%rsp)
    2f7d:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    2f87:      	movq	%rax, 0x40(%rsp)
    2f8c:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    2f96:      	movq	%rax, 0x38(%rsp)
    2f9b:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    2fa5:      	movq	%rax, 0x30(%rsp)
    2faa:      	leaq	0x30(%rsp), %rdi
    2faf:      	movl	$0x2d, %eax
    2fb4:      	movl	$0x6, %ecx
    2fb9:      	movl	$0x2d, %esi
    2fbe:      	xorl	%eax, %eax
    2fc0:      	callq	*%rcx
    2fc2:      	jmp	0x3142 <perf_unwind_ruby+0x3142>
    2fc7:      	movq	$0x0, (%rsp)
    2fcf:      	movzbl	0x1d(%r15), %eax
    2fd4:      	addq	0x8(%rsp), %rax
    2fd9:      	movq	%rsp, %rdi
    2fdc:      	movl	$0x8, %ecx
    2fe1:      	movl	$0x70, %r8d
    2fe7:      	movzbl	0x1d(%r15), %edx
    2fec:      	addq	0x8(%rsp), %rdx
    2ff1:      	movl	$0x8, %esi
    2ff6:      	callq	*%r8
    2ff9:      	testq	%rax, %rax
    2ffc:      	jne	0x81b <perf_unwind_ruby+0x81b>
    3002:      	movl	(%rsp), %eax
    3005:      	notl	%eax
    3007:      	testl	$0x140, %eax            # imm = 0x140
    300c:      	jne	0x997 <perf_unwind_ruby+0x997>
    3012:      	jmp	0x2ddc <perf_unwind_ruby+0x2ddc>
    3017:      	movq	(%rip), %rax            # 0x301e <perf_unwind_ruby+0x301e>
    301e:      	cmpl	$0x0, (%rax)
    3021:      	je	0x261b <perf_unwind_ruby+0x261b>
    3027:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3031:      	movq	%rax, 0x56(%rsp)
    3036:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3040:      	movq	%rax, 0x50(%rsp)
    3045:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    304f:      	movq	%rax, 0x48(%rsp)
    3054:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    305e:      	movq	%rax, 0x40(%rsp)
    3063:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    306d:      	movq	%rax, 0x38(%rsp)
    3072:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    307c:      	movq	%rax, 0x30(%rsp)
    3081:      	leaq	0x30(%rsp), %rdi
    3086:      	movl	$0x2e, %eax
    308b:      	movl	$0x6, %ecx
    3090:      	movl	(%rsp), %edx
    3093:      	movl	$0x2e, %esi
    3098:      	xorl	%eax, %eax
    309a:      	callq	*%rcx
    309c:      	jmp	0x261b <perf_unwind_ruby+0x261b>
    30a1:      	movl	0x2c0(%r14), %eax
    30a8:      	cmpq	$0x7e, %rax
    30ac:      	ja	0xdd3 <perf_unwind_ruby+0xdd3>
    30b2:      	movq	0x10(%rsp), %rcx
    30b7:      	movq	0x18(%rsp), %rdx
    30bc:      	leal	0x1(%rax), %esi
    30bf:      	movl	%esi, 0x2c0(%r14)
    30c6:      	leaq	(%rax,%rax,2), %rax
    30ca:      	movw	$0x0, 0x4(%rsp)
    30d1:      	movl	$0x0, (%rsp)
    30d8:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    30e0:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    30e8:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    30f3:      	movl	(%rsp), %ecx
    30f6:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    30fe:      	movzwl	0x4(%rsp), %ecx
    3103:      	movw	%cx, 0x2e6(%r14,%rax,8)
    310c:      	movl	$0x36, (%rsp)
    3113:      	movq	(%rip), %rdi            # 0x311a <perf_unwind_ruby+0x311a>
    311a:      	movq	%rsp, %rsi
    311d:      	movl	$0x1, %eax
    3122:      	callq	*%rax
    3124:      	testq	%rax, %rax
    3127:      	je	0x337d <perf_unwind_ruby+0x337d>
    312d:      	incq	(%rax)
    3130:      	jmp	0x2a76 <perf_unwind_ruby+0x2a76>
    3135:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    313c:      	jae	0x332d <perf_unwind_ruby+0x332d>
    3142:      	movq	0x8(%rsp), %rax
    3147:      	cmpq	%rax, %r12
    314a:      	jbe	0x2b2 <perf_unwind_ruby+0x2b2>
    3150:      	movzbl	0x1e(%r15), %ecx
    3155:      	addq	%rcx, %rax
    3158:      	movq	%rax, 0x8(%rsp)
    315d:      	movq	$0x0, 0x18(%rsp)
    3166:      	movq	$0x0, 0x20(%rsp)
    316f:      	movzbl	0x1c(%r15), %ecx
    3174:      	addq	%rax, %rcx
    3177:      	leaq	0x20(%rsp), %rdi
    317c:      	movl	$0x8, %eax
    3181:      	movl	$0x70, %r8d
    3187:      	movzbl	0x1c(%r15), %edx
    318c:      	addq	0x8(%rsp), %rdx
    3191:      	movl	$0x8, %esi
    3196:      	callq	*%r8
    3199:      	movzbl	0x1b(%r15), %eax
    319e:      	addq	0x8(%rsp), %rax
    31a3:      	leaq	0x18(%rsp), %rdi
    31a8:      	movl	$0x8, %ecx
    31ad:      	movl	$0x70, %r8d
    31b3:      	movzbl	0x1b(%r15), %edx
    31b8:      	addq	0x8(%rsp), %rdx
    31bd:      	movl	$0x8, %esi
    31c2:      	callq	*%r8
    31c5:      	cmpq	$0x0, 0x18(%rsp)
    31cb:      	je	0x349b <perf_unwind_ruby+0x349b>
    31d1:      	movq	0x20(%rsp), %rax
    31d6:      	testq	%rax, %rax
    31d9:      	je	0x349b <perf_unwind_ruby+0x349b>
    31df:      	movzbl	0x1f(%r15), %ecx
    31e4:      	addq	%rcx, %rax
    31e7:      	leaq	0x10(%rsp), %rdi
    31ec:      	movl	$0x8, %ecx
    31f1:      	movl	$0x70, %r8d
    31f7:      	movzbl	0x1f(%r15), %edx
    31fc:      	addq	0x20(%rsp), %rdx
    3201:      	movl	$0x8, %esi
    3206:      	callq	*%r8
    3209:      	testq	%rax, %rax
    320c:      	jne	0x4c7 <perf_unwind_ruby+0x4c7>
    3212:      	movzbl	0x21(%r15), %eax
    3217:      	addq	0x10(%rsp), %rax
    321c:      	leaq	0x68(%rsp), %rdi
    3221:      	movl	$0x8, %ecx
    3226:      	movl	$0x70, %r8d
    322c:      	movzbl	0x21(%r15), %edx
    3231:      	addq	0x10(%rsp), %rdx
    3236:      	movl	$0x8, %esi
    323b:      	callq	*%r8
    323e:      	testq	%rax, %rax
    3241:      	jne	0x8a4 <perf_unwind_ruby+0x8a4>
    3247:      	movzbl	0x22(%r15), %eax
    324c:      	addq	0x10(%rsp), %rax
    3251:      	leaq	0x2c(%rsp), %rdi
    3256:      	movl	$0x4, %ecx
    325b:      	movl	$0x70, %r8d
    3261:      	movzbl	0x22(%r15), %edx
    3266:      	addq	0x10(%rsp), %rdx
    326b:      	movl	$0x4, %esi
    3270:      	callq	*%r8
    3273:      	testq	%rax, %rax
    3276:      	jne	0xc08 <perf_unwind_ruby+0xc08>
    327c:      	movzbl	0x23(%r15), %ecx
    3281:      	testq	%rcx, %rcx
    3284:      	je	0x3ad3 <perf_unwind_ruby+0x3ad3>
    328a:      	movq	0x18(%rsp), %rax
    328f:      	subq	0x68(%rsp), %rax
    3294:      	xorl	%edx, %edx
    3296:      	divq	%rcx
    3299:      	movl	0x2c(%rsp), %ecx
    329d:      	cmpq	%rcx, %rax
    32a0:      	jbe	0x3ad3 <perf_unwind_ruby+0x3ad3>
    32a6:      	movq	(%rip), %rax            # 0x32ad <perf_unwind_ruby+0x32ad>
    32ad:      	cmpl	$0x0, (%rax)
    32b0:      	je	0x34a8 <perf_unwind_ruby+0x34a8>
    32b6:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    32c0:      	movq	%rax, 0x55(%rsp)
    32c5:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    32cf:      	movq	%rax, 0x50(%rsp)
    32d4:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    32de:      	movq	%rax, 0x48(%rsp)
    32e3:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    32ed:      	movq	%rax, 0x40(%rsp)
    32f2:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    32fc:      	movq	%rax, 0x38(%rsp)
    3301:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    330b:      	movq	%rax, 0x30(%rsp)
    3310:      	leaq	0x30(%rsp), %rdi
    3315:      	movl	$0x2d, %eax
    331a:      	movl	$0x6, %ecx
    331f:      	movl	$0x2d, %esi
    3324:      	xorl	%eax, %eax
    3326:      	callq	*%rcx
    3328:      	jmp	0x34a8 <perf_unwind_ruby+0x34a8>
    332d:      	movq	$0x0, (%rsp)
    3335:      	movzbl	0x1d(%r15), %eax
    333a:      	addq	0x8(%rsp), %rax
    333f:      	movq	%rsp, %rdi
    3342:      	movl	$0x8, %ecx
    3347:      	movl	$0x70, %r8d
    334d:      	movzbl	0x1d(%r15), %edx
    3352:      	addq	0x8(%rsp), %rdx
    3357:      	movl	$0x8, %esi
    335c:      	callq	*%r8
    335f:      	testq	%rax, %rax
    3362:      	jne	0x81b <perf_unwind_ruby+0x81b>
    3368:      	movl	(%rsp), %eax
    336b:      	notl	%eax
    336d:      	testl	$0x140, %eax            # imm = 0x140
    3372:      	jne	0x997 <perf_unwind_ruby+0x997>
    3378:      	jmp	0x3142 <perf_unwind_ruby+0x3142>
    337d:      	movq	(%rip), %rax            # 0x3384 <perf_unwind_ruby+0x3384>
    3384:      	cmpl	$0x0, (%rax)
    3387:      	je	0x2a76 <perf_unwind_ruby+0x2a76>
    338d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3397:      	movq	%rax, 0x56(%rsp)
    339c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    33a6:      	movq	%rax, 0x50(%rsp)
    33ab:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    33b5:      	movq	%rax, 0x48(%rsp)
    33ba:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    33c4:      	movq	%rax, 0x40(%rsp)
    33c9:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    33d3:      	movq	%rax, 0x38(%rsp)
    33d8:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    33e2:      	movq	%rax, 0x30(%rsp)
    33e7:      	leaq	0x30(%rsp), %rdi
    33ec:      	movl	$0x2e, %eax
    33f1:      	movl	$0x6, %ecx
    33f6:      	movl	(%rsp), %edx
    33f9:      	movl	$0x2e, %esi
    33fe:      	xorl	%eax, %eax
    3400:      	callq	*%rcx
    3402:      	jmp	0x2a76 <perf_unwind_ruby+0x2a76>
    3407:      	movl	0x2c0(%r14), %eax
    340e:      	cmpq	$0x7e, %rax
    3412:      	ja	0xdd3 <perf_unwind_ruby+0xdd3>
    3418:      	movq	0x10(%rsp), %rcx
    341d:      	movq	0x18(%rsp), %rdx
    3422:      	leal	0x1(%rax), %esi
    3425:      	movl	%esi, 0x2c0(%r14)
    342c:      	leaq	(%rax,%rax,2), %rax
    3430:      	movw	$0x0, 0x4(%rsp)
    3437:      	movl	$0x0, (%rsp)
    343e:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    3446:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    344e:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    3459:      	movl	(%rsp), %ecx
    345c:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    3464:      	movzwl	0x4(%rsp), %ecx
    3469:      	movw	%cx, 0x2e6(%r14,%rax,8)
    3472:      	movl	$0x36, (%rsp)
    3479:      	movq	(%rip), %rdi            # 0x3480 <perf_unwind_ruby+0x3480>
    3480:      	movq	%rsp, %rsi
    3483:      	movl	$0x1, %eax
    3488:      	callq	*%rax
    348a:      	testq	%rax, %rax
    348d:      	je	0x36e3 <perf_unwind_ruby+0x36e3>
    3493:      	incq	(%rax)
    3496:      	jmp	0x2ddc <perf_unwind_ruby+0x2ddc>
    349b:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    34a2:      	jae	0x3693 <perf_unwind_ruby+0x3693>
    34a8:      	movq	0x8(%rsp), %rax
    34ad:      	cmpq	%rax, %r12
    34b0:      	jbe	0x2b2 <perf_unwind_ruby+0x2b2>
    34b6:      	movzbl	0x1e(%r15), %ecx
    34bb:      	addq	%rcx, %rax
    34be:      	movq	%rax, 0x8(%rsp)
    34c3:      	movq	$0x0, 0x18(%rsp)
    34cc:      	movq	$0x0, 0x20(%rsp)
    34d5:      	movzbl	0x1c(%r15), %ecx
    34da:      	addq	%rax, %rcx
    34dd:      	leaq	0x20(%rsp), %rdi
    34e2:      	movl	$0x8, %eax
    34e7:      	movl	$0x70, %r8d
    34ed:      	movzbl	0x1c(%r15), %edx
    34f2:      	addq	0x8(%rsp), %rdx
    34f7:      	movl	$0x8, %esi
    34fc:      	callq	*%r8
    34ff:      	movzbl	0x1b(%r15), %eax
    3504:      	addq	0x8(%rsp), %rax
    3509:      	leaq	0x18(%rsp), %rdi
    350e:      	movl	$0x8, %ecx
    3513:      	movl	$0x70, %r8d
    3519:      	movzbl	0x1b(%r15), %edx
    351e:      	addq	0x8(%rsp), %rdx
    3523:      	movl	$0x8, %esi
    3528:      	callq	*%r8
    352b:      	cmpq	$0x0, 0x18(%rsp)
    3531:      	je	0x3801 <perf_unwind_ruby+0x3801>
    3537:      	movq	0x20(%rsp), %rax
    353c:      	testq	%rax, %rax
    353f:      	je	0x3801 <perf_unwind_ruby+0x3801>
    3545:      	movzbl	0x1f(%r15), %ecx
    354a:      	addq	%rcx, %rax
    354d:      	leaq	0x10(%rsp), %rdi
    3552:      	movl	$0x8, %ecx
    3557:      	movl	$0x70, %r8d
    355d:      	movzbl	0x1f(%r15), %edx
    3562:      	addq	0x20(%rsp), %rdx
    3567:      	movl	$0x8, %esi
    356c:      	callq	*%r8
    356f:      	testq	%rax, %rax
    3572:      	jne	0x4c7 <perf_unwind_ruby+0x4c7>
    3578:      	movzbl	0x21(%r15), %eax
    357d:      	addq	0x10(%rsp), %rax
    3582:      	leaq	0x68(%rsp), %rdi
    3587:      	movl	$0x8, %ecx
    358c:      	movl	$0x70, %r8d
    3592:      	movzbl	0x21(%r15), %edx
    3597:      	addq	0x10(%rsp), %rdx
    359c:      	movl	$0x8, %esi
    35a1:      	callq	*%r8
    35a4:      	testq	%rax, %rax
    35a7:      	jne	0x8a4 <perf_unwind_ruby+0x8a4>
    35ad:      	movzbl	0x22(%r15), %eax
    35b2:      	addq	0x10(%rsp), %rax
    35b7:      	leaq	0x2c(%rsp), %rdi
    35bc:      	movl	$0x4, %ecx
    35c1:      	movl	$0x70, %r8d
    35c7:      	movzbl	0x22(%r15), %edx
    35cc:      	addq	0x10(%rsp), %rdx
    35d1:      	movl	$0x4, %esi
    35d6:      	callq	*%r8
    35d9:      	testq	%rax, %rax
    35dc:      	jne	0xc08 <perf_unwind_ruby+0xc08>
    35e2:      	movzbl	0x23(%r15), %ecx
    35e7:      	testq	%rcx, %rcx
    35ea:      	je	0x3e39 <perf_unwind_ruby+0x3e39>
    35f0:      	movq	0x18(%rsp), %rax
    35f5:      	subq	0x68(%rsp), %rax
    35fa:      	xorl	%edx, %edx
    35fc:      	divq	%rcx
    35ff:      	movl	0x2c(%rsp), %ecx
    3603:      	cmpq	%rcx, %rax
    3606:      	jbe	0x3e39 <perf_unwind_ruby+0x3e39>
    360c:      	movq	(%rip), %rax            # 0x3613 <perf_unwind_ruby+0x3613>
    3613:      	cmpl	$0x0, (%rax)
    3616:      	je	0x380e <perf_unwind_ruby+0x380e>
    361c:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    3626:      	movq	%rax, 0x55(%rsp)
    362b:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    3635:      	movq	%rax, 0x50(%rsp)
    363a:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    3644:      	movq	%rax, 0x48(%rsp)
    3649:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    3653:      	movq	%rax, 0x40(%rsp)
    3658:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    3662:      	movq	%rax, 0x38(%rsp)
    3667:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    3671:      	movq	%rax, 0x30(%rsp)
    3676:      	leaq	0x30(%rsp), %rdi
    367b:      	movl	$0x2d, %eax
    3680:      	movl	$0x6, %ecx
    3685:      	movl	$0x2d, %esi
    368a:      	xorl	%eax, %eax
    368c:      	callq	*%rcx
    368e:      	jmp	0x380e <perf_unwind_ruby+0x380e>
    3693:      	movq	$0x0, (%rsp)
    369b:      	movzbl	0x1d(%r15), %eax
    36a0:      	addq	0x8(%rsp), %rax
    36a5:      	movq	%rsp, %rdi
    36a8:      	movl	$0x8, %ecx
    36ad:      	movl	$0x70, %r8d
    36b3:      	movzbl	0x1d(%r15), %edx
    36b8:      	addq	0x8(%rsp), %rdx
    36bd:      	movl	$0x8, %esi
    36c2:      	callq	*%r8
    36c5:      	testq	%rax, %rax
    36c8:      	jne	0x81b <perf_unwind_ruby+0x81b>
    36ce:      	movl	(%rsp), %eax
    36d1:      	notl	%eax
    36d3:      	testl	$0x140, %eax            # imm = 0x140
    36d8:      	jne	0x997 <perf_unwind_ruby+0x997>
    36de:      	jmp	0x34a8 <perf_unwind_ruby+0x34a8>
    36e3:      	movq	(%rip), %rax            # 0x36ea <perf_unwind_ruby+0x36ea>
    36ea:      	cmpl	$0x0, (%rax)
    36ed:      	je	0x2ddc <perf_unwind_ruby+0x2ddc>
    36f3:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    36fd:      	movq	%rax, 0x56(%rsp)
    3702:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    370c:      	movq	%rax, 0x50(%rsp)
    3711:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    371b:      	movq	%rax, 0x48(%rsp)
    3720:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    372a:      	movq	%rax, 0x40(%rsp)
    372f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3739:      	movq	%rax, 0x38(%rsp)
    373e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3748:      	movq	%rax, 0x30(%rsp)
    374d:      	leaq	0x30(%rsp), %rdi
    3752:      	movl	$0x2e, %eax
    3757:      	movl	$0x6, %ecx
    375c:      	movl	(%rsp), %edx
    375f:      	movl	$0x2e, %esi
    3764:      	xorl	%eax, %eax
    3766:      	callq	*%rcx
    3768:      	jmp	0x2ddc <perf_unwind_ruby+0x2ddc>
    376d:      	movl	0x2c0(%r14), %eax
    3774:      	cmpq	$0x7e, %rax
    3778:      	ja	0xdd3 <perf_unwind_ruby+0xdd3>
    377e:      	movq	0x10(%rsp), %rcx
    3783:      	movq	0x18(%rsp), %rdx
    3788:      	leal	0x1(%rax), %esi
    378b:      	movl	%esi, 0x2c0(%r14)
    3792:      	leaq	(%rax,%rax,2), %rax
    3796:      	movw	$0x0, 0x4(%rsp)
    379d:      	movl	$0x0, (%rsp)
    37a4:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    37ac:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    37b4:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    37bf:      	movl	(%rsp), %ecx
    37c2:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    37ca:      	movzwl	0x4(%rsp), %ecx
    37cf:      	movw	%cx, 0x2e6(%r14,%rax,8)
    37d8:      	movl	$0x36, (%rsp)
    37df:      	movq	(%rip), %rdi            # 0x37e6 <perf_unwind_ruby+0x37e6>
    37e6:      	movq	%rsp, %rsi
    37e9:      	movl	$0x1, %eax
    37ee:      	callq	*%rax
    37f0:      	testq	%rax, %rax
    37f3:      	je	0x3a49 <perf_unwind_ruby+0x3a49>
    37f9:      	incq	(%rax)
    37fc:      	jmp	0x3142 <perf_unwind_ruby+0x3142>
    3801:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    3808:      	jae	0x39f9 <perf_unwind_ruby+0x39f9>
    380e:      	movq	0x8(%rsp), %rax
    3813:      	cmpq	%rax, %r12
    3816:      	jbe	0x2b2 <perf_unwind_ruby+0x2b2>
    381c:      	movzbl	0x1e(%r15), %ecx
    3821:      	addq	%rcx, %rax
    3824:      	movq	%rax, 0x8(%rsp)
    3829:      	movq	$0x0, 0x18(%rsp)
    3832:      	movq	$0x0, 0x20(%rsp)
    383b:      	movzbl	0x1c(%r15), %ecx
    3840:      	addq	%rax, %rcx
    3843:      	leaq	0x20(%rsp), %rdi
    3848:      	movl	$0x8, %eax
    384d:      	movl	$0x70, %r8d
    3853:      	movzbl	0x1c(%r15), %edx
    3858:      	addq	0x8(%rsp), %rdx
    385d:      	movl	$0x8, %esi
    3862:      	callq	*%r8
    3865:      	movzbl	0x1b(%r15), %eax
    386a:      	addq	0x8(%rsp), %rax
    386f:      	leaq	0x18(%rsp), %rdi
    3874:      	movl	$0x8, %ecx
    3879:      	movl	$0x70, %r8d
    387f:      	movzbl	0x1b(%r15), %edx
    3884:      	addq	0x8(%rsp), %rdx
    3889:      	movl	$0x8, %esi
    388e:      	callq	*%r8
    3891:      	cmpq	$0x0, 0x18(%rsp)
    3897:      	je	0x3b67 <perf_unwind_ruby+0x3b67>
    389d:      	movq	0x20(%rsp), %rax
    38a2:      	testq	%rax, %rax
    38a5:      	je	0x3b67 <perf_unwind_ruby+0x3b67>
    38ab:      	movzbl	0x1f(%r15), %ecx
    38b0:      	addq	%rcx, %rax
    38b3:      	leaq	0x10(%rsp), %rdi
    38b8:      	movl	$0x8, %ecx
    38bd:      	movl	$0x70, %r8d
    38c3:      	movzbl	0x1f(%r15), %edx
    38c8:      	addq	0x20(%rsp), %rdx
    38cd:      	movl	$0x8, %esi
    38d2:      	callq	*%r8
    38d5:      	testq	%rax, %rax
    38d8:      	jne	0x4c7 <perf_unwind_ruby+0x4c7>
    38de:      	movzbl	0x21(%r15), %eax
    38e3:      	addq	0x10(%rsp), %rax
    38e8:      	leaq	0x68(%rsp), %rdi
    38ed:      	movl	$0x8, %ecx
    38f2:      	movl	$0x70, %r8d
    38f8:      	movzbl	0x21(%r15), %edx
    38fd:      	addq	0x10(%rsp), %rdx
    3902:      	movl	$0x8, %esi
    3907:      	callq	*%r8
    390a:      	testq	%rax, %rax
    390d:      	jne	0x8a4 <perf_unwind_ruby+0x8a4>
    3913:      	movzbl	0x22(%r15), %eax
    3918:      	addq	0x10(%rsp), %rax
    391d:      	leaq	0x2c(%rsp), %rdi
    3922:      	movl	$0x4, %ecx
    3927:      	movl	$0x70, %r8d
    392d:      	movzbl	0x22(%r15), %edx
    3932:      	addq	0x10(%rsp), %rdx
    3937:      	movl	$0x4, %esi
    393c:      	callq	*%r8
    393f:      	testq	%rax, %rax
    3942:      	jne	0xc08 <perf_unwind_ruby+0xc08>
    3948:      	movzbl	0x23(%r15), %ecx
    394d:      	testq	%rcx, %rcx
    3950:      	je	0x419f <perf_unwind_ruby+0x419f>
    3956:      	movq	0x18(%rsp), %rax
    395b:      	subq	0x68(%rsp), %rax
    3960:      	xorl	%edx, %edx
    3962:      	divq	%rcx
    3965:      	movl	0x2c(%rsp), %ecx
    3969:      	cmpq	%rcx, %rax
    396c:      	jbe	0x419f <perf_unwind_ruby+0x419f>
    3972:      	movq	(%rip), %rax            # 0x3979 <perf_unwind_ruby+0x3979>
    3979:      	cmpl	$0x0, (%rax)
    397c:      	je	0x3b74 <perf_unwind_ruby+0x3b74>
    3982:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    398c:      	movq	%rax, 0x55(%rsp)
    3991:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    399b:      	movq	%rax, 0x50(%rsp)
    39a0:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    39aa:      	movq	%rax, 0x48(%rsp)
    39af:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    39b9:      	movq	%rax, 0x40(%rsp)
    39be:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    39c8:      	movq	%rax, 0x38(%rsp)
    39cd:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    39d7:      	movq	%rax, 0x30(%rsp)
    39dc:      	leaq	0x30(%rsp), %rdi
    39e1:      	movl	$0x2d, %eax
    39e6:      	movl	$0x6, %ecx
    39eb:      	movl	$0x2d, %esi
    39f0:      	xorl	%eax, %eax
    39f2:      	callq	*%rcx
    39f4:      	jmp	0x3b74 <perf_unwind_ruby+0x3b74>
    39f9:      	movq	$0x0, (%rsp)
    3a01:      	movzbl	0x1d(%r15), %eax
    3a06:      	addq	0x8(%rsp), %rax
    3a0b:      	movq	%rsp, %rdi
    3a0e:      	movl	$0x8, %ecx
    3a13:      	movl	$0x70, %r8d
    3a19:      	movzbl	0x1d(%r15), %edx
    3a1e:      	addq	0x8(%rsp), %rdx
    3a23:      	movl	$0x8, %esi
    3a28:      	callq	*%r8
    3a2b:      	testq	%rax, %rax
    3a2e:      	jne	0x81b <perf_unwind_ruby+0x81b>
    3a34:      	movl	(%rsp), %eax
    3a37:      	notl	%eax
    3a39:      	testl	$0x140, %eax            # imm = 0x140
    3a3e:      	jne	0x997 <perf_unwind_ruby+0x997>
    3a44:      	jmp	0x380e <perf_unwind_ruby+0x380e>
    3a49:      	movq	(%rip), %rax            # 0x3a50 <perf_unwind_ruby+0x3a50>
    3a50:      	cmpl	$0x0, (%rax)
    3a53:      	je	0x3142 <perf_unwind_ruby+0x3142>
    3a59:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3a63:      	movq	%rax, 0x56(%rsp)
    3a68:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3a72:      	movq	%rax, 0x50(%rsp)
    3a77:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3a81:      	movq	%rax, 0x48(%rsp)
    3a86:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3a90:      	movq	%rax, 0x40(%rsp)
    3a95:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3a9f:      	movq	%rax, 0x38(%rsp)
    3aa4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3aae:      	movq	%rax, 0x30(%rsp)
    3ab3:      	leaq	0x30(%rsp), %rdi
    3ab8:      	movl	$0x2e, %eax
    3abd:      	movl	$0x6, %ecx
    3ac2:      	movl	(%rsp), %edx
    3ac5:      	movl	$0x2e, %esi
    3aca:      	xorl	%eax, %eax
    3acc:      	callq	*%rcx
    3ace:      	jmp	0x3142 <perf_unwind_ruby+0x3142>
    3ad3:      	movl	0x2c0(%r14), %eax
    3ada:      	cmpq	$0x7e, %rax
    3ade:      	ja	0xdd3 <perf_unwind_ruby+0xdd3>
    3ae4:      	movq	0x10(%rsp), %rcx
    3ae9:      	movq	0x18(%rsp), %rdx
    3aee:      	leal	0x1(%rax), %esi
    3af1:      	movl	%esi, 0x2c0(%r14)
    3af8:      	leaq	(%rax,%rax,2), %rax
    3afc:      	movw	$0x0, 0x4(%rsp)
    3b03:      	movl	$0x0, (%rsp)
    3b0a:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    3b12:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    3b1a:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    3b25:      	movl	(%rsp), %ecx
    3b28:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    3b30:      	movzwl	0x4(%rsp), %ecx
    3b35:      	movw	%cx, 0x2e6(%r14,%rax,8)
    3b3e:      	movl	$0x36, (%rsp)
    3b45:      	movq	(%rip), %rdi            # 0x3b4c <perf_unwind_ruby+0x3b4c>
    3b4c:      	movq	%rsp, %rsi
    3b4f:      	movl	$0x1, %eax
    3b54:      	callq	*%rax
    3b56:      	testq	%rax, %rax
    3b59:      	je	0x3daf <perf_unwind_ruby+0x3daf>
    3b5f:      	incq	(%rax)
    3b62:      	jmp	0x34a8 <perf_unwind_ruby+0x34a8>
    3b67:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    3b6e:      	jae	0x3d5f <perf_unwind_ruby+0x3d5f>
    3b74:      	movq	0x8(%rsp), %rax
    3b79:      	cmpq	%rax, %r12
    3b7c:      	jbe	0x2b2 <perf_unwind_ruby+0x2b2>
    3b82:      	movzbl	0x1e(%r15), %ecx
    3b87:      	addq	%rcx, %rax
    3b8a:      	movq	%rax, 0x8(%rsp)
    3b8f:      	movq	$0x0, 0x18(%rsp)
    3b98:      	movq	$0x0, 0x20(%rsp)
    3ba1:      	movzbl	0x1c(%r15), %ecx
    3ba6:      	addq	%rax, %rcx
    3ba9:      	leaq	0x20(%rsp), %rdi
    3bae:      	movl	$0x8, %eax
    3bb3:      	movl	$0x70, %r8d
    3bb9:      	movzbl	0x1c(%r15), %edx
    3bbe:      	addq	0x8(%rsp), %rdx
    3bc3:      	movl	$0x8, %esi
    3bc8:      	callq	*%r8
    3bcb:      	movzbl	0x1b(%r15), %eax
    3bd0:      	addq	0x8(%rsp), %rax
    3bd5:      	leaq	0x18(%rsp), %rdi
    3bda:      	movl	$0x8, %ecx
    3bdf:      	movl	$0x70, %r8d
    3be5:      	movzbl	0x1b(%r15), %edx
    3bea:      	addq	0x8(%rsp), %rdx
    3bef:      	movl	$0x8, %esi
    3bf4:      	callq	*%r8
    3bf7:      	cmpq	$0x0, 0x18(%rsp)
    3bfd:      	je	0x3ecd <perf_unwind_ruby+0x3ecd>
    3c03:      	movq	0x20(%rsp), %rax
    3c08:      	testq	%rax, %rax
    3c0b:      	je	0x3ecd <perf_unwind_ruby+0x3ecd>
    3c11:      	movzbl	0x1f(%r15), %ecx
    3c16:      	addq	%rcx, %rax
    3c19:      	leaq	0x10(%rsp), %rdi
    3c1e:      	movl	$0x8, %ecx
    3c23:      	movl	$0x70, %r8d
    3c29:      	movzbl	0x1f(%r15), %edx
    3c2e:      	addq	0x20(%rsp), %rdx
    3c33:      	movl	$0x8, %esi
    3c38:      	callq	*%r8
    3c3b:      	testq	%rax, %rax
    3c3e:      	jne	0x4c7 <perf_unwind_ruby+0x4c7>
    3c44:      	movzbl	0x21(%r15), %eax
    3c49:      	addq	0x10(%rsp), %rax
    3c4e:      	leaq	0x68(%rsp), %rdi
    3c53:      	movl	$0x8, %ecx
    3c58:      	movl	$0x70, %r8d
    3c5e:      	movzbl	0x21(%r15), %edx
    3c63:      	addq	0x10(%rsp), %rdx
    3c68:      	movl	$0x8, %esi
    3c6d:      	callq	*%r8
    3c70:      	testq	%rax, %rax
    3c73:      	jne	0x8a4 <perf_unwind_ruby+0x8a4>
    3c79:      	movzbl	0x22(%r15), %eax
    3c7e:      	addq	0x10(%rsp), %rax
    3c83:      	leaq	0x2c(%rsp), %rdi
    3c88:      	movl	$0x4, %ecx
    3c8d:      	movl	$0x70, %r8d
    3c93:      	movzbl	0x22(%r15), %edx
    3c98:      	addq	0x10(%rsp), %rdx
    3c9d:      	movl	$0x4, %esi
    3ca2:      	callq	*%r8
    3ca5:      	testq	%rax, %rax
    3ca8:      	jne	0xc08 <perf_unwind_ruby+0xc08>
    3cae:      	movzbl	0x23(%r15), %ecx
    3cb3:      	testq	%rcx, %rcx
    3cb6:      	je	0x4505 <perf_unwind_ruby+0x4505>
    3cbc:      	movq	0x18(%rsp), %rax
    3cc1:      	subq	0x68(%rsp), %rax
    3cc6:      	xorl	%edx, %edx
    3cc8:      	divq	%rcx
    3ccb:      	movl	0x2c(%rsp), %ecx
    3ccf:      	cmpq	%rcx, %rax
    3cd2:      	jbe	0x4505 <perf_unwind_ruby+0x4505>
    3cd8:      	movq	(%rip), %rax            # 0x3cdf <perf_unwind_ruby+0x3cdf>
    3cdf:      	cmpl	$0x0, (%rax)
    3ce2:      	je	0x3eda <perf_unwind_ruby+0x3eda>
    3ce8:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    3cf2:      	movq	%rax, 0x55(%rsp)
    3cf7:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    3d01:      	movq	%rax, 0x50(%rsp)
    3d06:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    3d10:      	movq	%rax, 0x48(%rsp)
    3d15:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    3d1f:      	movq	%rax, 0x40(%rsp)
    3d24:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    3d2e:      	movq	%rax, 0x38(%rsp)
    3d33:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    3d3d:      	movq	%rax, 0x30(%rsp)
    3d42:      	leaq	0x30(%rsp), %rdi
    3d47:      	movl	$0x2d, %eax
    3d4c:      	movl	$0x6, %ecx
    3d51:      	movl	$0x2d, %esi
    3d56:      	xorl	%eax, %eax
    3d58:      	callq	*%rcx
    3d5a:      	jmp	0x3eda <perf_unwind_ruby+0x3eda>
    3d5f:      	movq	$0x0, (%rsp)
    3d67:      	movzbl	0x1d(%r15), %eax
    3d6c:      	addq	0x8(%rsp), %rax
    3d71:      	movq	%rsp, %rdi
    3d74:      	movl	$0x8, %ecx
    3d79:      	movl	$0x70, %r8d
    3d7f:      	movzbl	0x1d(%r15), %edx
    3d84:      	addq	0x8(%rsp), %rdx
    3d89:      	movl	$0x8, %esi
    3d8e:      	callq	*%r8
    3d91:      	testq	%rax, %rax
    3d94:      	jne	0x81b <perf_unwind_ruby+0x81b>
    3d9a:      	movl	(%rsp), %eax
    3d9d:      	notl	%eax
    3d9f:      	testl	$0x140, %eax            # imm = 0x140
    3da4:      	jne	0x997 <perf_unwind_ruby+0x997>
    3daa:      	jmp	0x3b74 <perf_unwind_ruby+0x3b74>
    3daf:      	movq	(%rip), %rax            # 0x3db6 <perf_unwind_ruby+0x3db6>
    3db6:      	cmpl	$0x0, (%rax)
    3db9:      	je	0x34a8 <perf_unwind_ruby+0x34a8>
    3dbf:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3dc9:      	movq	%rax, 0x56(%rsp)
    3dce:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3dd8:      	movq	%rax, 0x50(%rsp)
    3ddd:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3de7:      	movq	%rax, 0x48(%rsp)
    3dec:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3df6:      	movq	%rax, 0x40(%rsp)
    3dfb:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3e05:      	movq	%rax, 0x38(%rsp)
    3e0a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3e14:      	movq	%rax, 0x30(%rsp)
    3e19:      	leaq	0x30(%rsp), %rdi
    3e1e:      	movl	$0x2e, %eax
    3e23:      	movl	$0x6, %ecx
    3e28:      	movl	(%rsp), %edx
    3e2b:      	movl	$0x2e, %esi
    3e30:      	xorl	%eax, %eax
    3e32:      	callq	*%rcx
    3e34:      	jmp	0x34a8 <perf_unwind_ruby+0x34a8>
    3e39:      	movl	0x2c0(%r14), %eax
    3e40:      	cmpq	$0x7e, %rax
    3e44:      	ja	0xdd3 <perf_unwind_ruby+0xdd3>
    3e4a:      	movq	0x10(%rsp), %rcx
    3e4f:      	movq	0x18(%rsp), %rdx
    3e54:      	leal	0x1(%rax), %esi
    3e57:      	movl	%esi, 0x2c0(%r14)
    3e5e:      	leaq	(%rax,%rax,2), %rax
    3e62:      	movw	$0x0, 0x4(%rsp)
    3e69:      	movl	$0x0, (%rsp)
    3e70:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    3e78:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    3e80:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    3e8b:      	movl	(%rsp), %ecx
    3e8e:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    3e96:      	movzwl	0x4(%rsp), %ecx
    3e9b:      	movw	%cx, 0x2e6(%r14,%rax,8)
    3ea4:      	movl	$0x36, (%rsp)
    3eab:      	movq	(%rip), %rdi            # 0x3eb2 <perf_unwind_ruby+0x3eb2>
    3eb2:      	movq	%rsp, %rsi
    3eb5:      	movl	$0x1, %eax
    3eba:      	callq	*%rax
    3ebc:      	testq	%rax, %rax
    3ebf:      	je	0x4115 <perf_unwind_ruby+0x4115>
    3ec5:      	incq	(%rax)
    3ec8:      	jmp	0x380e <perf_unwind_ruby+0x380e>
    3ecd:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    3ed4:      	jae	0x40c5 <perf_unwind_ruby+0x40c5>
    3eda:      	movq	0x8(%rsp), %rax
    3edf:      	cmpq	%rax, %r12
    3ee2:      	jbe	0x2b2 <perf_unwind_ruby+0x2b2>
    3ee8:      	movzbl	0x1e(%r15), %ecx
    3eed:      	addq	%rcx, %rax
    3ef0:      	movq	%rax, 0x8(%rsp)
    3ef5:      	movq	$0x0, 0x18(%rsp)
    3efe:      	movq	$0x0, 0x20(%rsp)
    3f07:      	movzbl	0x1c(%r15), %ecx
    3f0c:      	addq	%rax, %rcx
    3f0f:      	leaq	0x20(%rsp), %rdi
    3f14:      	movl	$0x8, %eax
    3f19:      	movl	$0x70, %r8d
    3f1f:      	movzbl	0x1c(%r15), %edx
    3f24:      	addq	0x8(%rsp), %rdx
    3f29:      	movl	$0x8, %esi
    3f2e:      	callq	*%r8
    3f31:      	movzbl	0x1b(%r15), %eax
    3f36:      	addq	0x8(%rsp), %rax
    3f3b:      	leaq	0x18(%rsp), %rdi
    3f40:      	movl	$0x8, %ecx
    3f45:      	movl	$0x70, %r8d
    3f4b:      	movzbl	0x1b(%r15), %edx
    3f50:      	addq	0x8(%rsp), %rdx
    3f55:      	movl	$0x8, %esi
    3f5a:      	callq	*%r8
    3f5d:      	cmpq	$0x0, 0x18(%rsp)
    3f63:      	je	0x4233 <perf_unwind_ruby+0x4233>
    3f69:      	movq	0x20(%rsp), %rax
    3f6e:      	testq	%rax, %rax
    3f71:      	je	0x4233 <perf_unwind_ruby+0x4233>
    3f77:      	movzbl	0x1f(%r15), %ecx
    3f7c:      	addq	%rcx, %rax
    3f7f:      	leaq	0x10(%rsp), %rdi
    3f84:      	movl	$0x8, %ecx
    3f89:      	movl	$0x70, %r8d
    3f8f:      	movzbl	0x1f(%r15), %edx
    3f94:      	addq	0x20(%rsp), %rdx
    3f99:      	movl	$0x8, %esi
    3f9e:      	callq	*%r8
    3fa1:      	testq	%rax, %rax
    3fa4:      	jne	0x4c7 <perf_unwind_ruby+0x4c7>
    3faa:      	movzbl	0x21(%r15), %eax
    3faf:      	addq	0x10(%rsp), %rax
    3fb4:      	leaq	0x68(%rsp), %rdi
    3fb9:      	movl	$0x8, %ecx
    3fbe:      	movl	$0x70, %r8d
    3fc4:      	movzbl	0x21(%r15), %edx
    3fc9:      	addq	0x10(%rsp), %rdx
    3fce:      	movl	$0x8, %esi
    3fd3:      	callq	*%r8
    3fd6:      	testq	%rax, %rax
    3fd9:      	jne	0x8a4 <perf_unwind_ruby+0x8a4>
    3fdf:      	movzbl	0x22(%r15), %eax
    3fe4:      	addq	0x10(%rsp), %rax
    3fe9:      	leaq	0x2c(%rsp), %rdi
    3fee:      	movl	$0x4, %ecx
    3ff3:      	movl	$0x70, %r8d
    3ff9:      	movzbl	0x22(%r15), %edx
    3ffe:      	addq	0x10(%rsp), %rdx
    4003:      	movl	$0x4, %esi
    4008:      	callq	*%r8
    400b:      	testq	%rax, %rax
    400e:      	jne	0xc08 <perf_unwind_ruby+0xc08>
    4014:      	movzbl	0x23(%r15), %ecx
    4019:      	testq	%rcx, %rcx
    401c:      	je	0x486b <perf_unwind_ruby+0x486b>
    4022:      	movq	0x18(%rsp), %rax
    4027:      	subq	0x68(%rsp), %rax
    402c:      	xorl	%edx, %edx
    402e:      	divq	%rcx
    4031:      	movl	0x2c(%rsp), %ecx
    4035:      	cmpq	%rcx, %rax
    4038:      	jbe	0x486b <perf_unwind_ruby+0x486b>
    403e:      	movq	(%rip), %rax            # 0x4045 <perf_unwind_ruby+0x4045>
    4045:      	cmpl	$0x0, (%rax)
    4048:      	je	0x4240 <perf_unwind_ruby+0x4240>
    404e:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    4058:      	movq	%rax, 0x55(%rsp)
    405d:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    4067:      	movq	%rax, 0x50(%rsp)
    406c:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    4076:      	movq	%rax, 0x48(%rsp)
    407b:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    4085:      	movq	%rax, 0x40(%rsp)
    408a:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    4094:      	movq	%rax, 0x38(%rsp)
    4099:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    40a3:      	movq	%rax, 0x30(%rsp)
    40a8:      	leaq	0x30(%rsp), %rdi
    40ad:      	movl	$0x2d, %eax
    40b2:      	movl	$0x6, %ecx
    40b7:      	movl	$0x2d, %esi
    40bc:      	xorl	%eax, %eax
    40be:      	callq	*%rcx
    40c0:      	jmp	0x4240 <perf_unwind_ruby+0x4240>
    40c5:      	movq	$0x0, (%rsp)
    40cd:      	movzbl	0x1d(%r15), %eax
    40d2:      	addq	0x8(%rsp), %rax
    40d7:      	movq	%rsp, %rdi
    40da:      	movl	$0x8, %ecx
    40df:      	movl	$0x70, %r8d
    40e5:      	movzbl	0x1d(%r15), %edx
    40ea:      	addq	0x8(%rsp), %rdx
    40ef:      	movl	$0x8, %esi
    40f4:      	callq	*%r8
    40f7:      	testq	%rax, %rax
    40fa:      	jne	0x81b <perf_unwind_ruby+0x81b>
    4100:      	movl	(%rsp), %eax
    4103:      	notl	%eax
    4105:      	testl	$0x140, %eax            # imm = 0x140
    410a:      	jne	0x997 <perf_unwind_ruby+0x997>
    4110:      	jmp	0x3eda <perf_unwind_ruby+0x3eda>
    4115:      	movq	(%rip), %rax            # 0x411c <perf_unwind_ruby+0x411c>
    411c:      	cmpl	$0x0, (%rax)
    411f:      	je	0x380e <perf_unwind_ruby+0x380e>
    4125:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    412f:      	movq	%rax, 0x56(%rsp)
    4134:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    413e:      	movq	%rax, 0x50(%rsp)
    4143:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    414d:      	movq	%rax, 0x48(%rsp)
    4152:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    415c:      	movq	%rax, 0x40(%rsp)
    4161:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    416b:      	movq	%rax, 0x38(%rsp)
    4170:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    417a:      	movq	%rax, 0x30(%rsp)
    417f:      	leaq	0x30(%rsp), %rdi
    4184:      	movl	$0x2e, %eax
    4189:      	movl	$0x6, %ecx
    418e:      	movl	(%rsp), %edx
    4191:      	movl	$0x2e, %esi
    4196:      	xorl	%eax, %eax
    4198:      	callq	*%rcx
    419a:      	jmp	0x380e <perf_unwind_ruby+0x380e>
    419f:      	movl	0x2c0(%r14), %eax
    41a6:      	cmpq	$0x7e, %rax
    41aa:      	ja	0xdd3 <perf_unwind_ruby+0xdd3>
    41b0:      	movq	0x10(%rsp), %rcx
    41b5:      	movq	0x18(%rsp), %rdx
    41ba:      	leal	0x1(%rax), %esi
    41bd:      	movl	%esi, 0x2c0(%r14)
    41c4:      	leaq	(%rax,%rax,2), %rax
    41c8:      	movw	$0x0, 0x4(%rsp)
    41cf:      	movl	$0x0, (%rsp)
    41d6:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    41de:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    41e6:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    41f1:      	movl	(%rsp), %ecx
    41f4:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    41fc:      	movzwl	0x4(%rsp), %ecx
    4201:      	movw	%cx, 0x2e6(%r14,%rax,8)
    420a:      	movl	$0x36, (%rsp)
    4211:      	movq	(%rip), %rdi            # 0x4218 <perf_unwind_ruby+0x4218>
    4218:      	movq	%rsp, %rsi
    421b:      	movl	$0x1, %eax
    4220:      	callq	*%rax
    4222:      	testq	%rax, %rax
    4225:      	je	0x447b <perf_unwind_ruby+0x447b>
    422b:      	incq	(%rax)
    422e:      	jmp	0x3b74 <perf_unwind_ruby+0x3b74>
    4233:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    423a:      	jae	0x442b <perf_unwind_ruby+0x442b>
    4240:      	movq	0x8(%rsp), %rax
    4245:      	cmpq	%rax, %r12
    4248:      	jbe	0x2b2 <perf_unwind_ruby+0x2b2>
    424e:      	movzbl	0x1e(%r15), %ecx
    4253:      	addq	%rcx, %rax
    4256:      	movq	%rax, 0x8(%rsp)
    425b:      	movq	$0x0, 0x18(%rsp)
    4264:      	movq	$0x0, 0x20(%rsp)
    426d:      	movzbl	0x1c(%r15), %ecx
    4272:      	addq	%rax, %rcx
    4275:      	leaq	0x20(%rsp), %rdi
    427a:      	movl	$0x8, %eax
    427f:      	movl	$0x70, %r8d
    4285:      	movzbl	0x1c(%r15), %edx
    428a:      	addq	0x8(%rsp), %rdx
    428f:      	movl	$0x8, %esi
    4294:      	callq	*%r8
    4297:      	movzbl	0x1b(%r15), %eax
    429c:      	addq	0x8(%rsp), %rax
    42a1:      	leaq	0x18(%rsp), %rdi
    42a6:      	movl	$0x8, %ecx
    42ab:      	movl	$0x70, %r8d
    42b1:      	movzbl	0x1b(%r15), %edx
    42b6:      	addq	0x8(%rsp), %rdx
    42bb:      	movl	$0x8, %esi
    42c0:      	callq	*%r8
    42c3:      	cmpq	$0x0, 0x18(%rsp)
    42c9:      	je	0x4599 <perf_unwind_ruby+0x4599>
    42cf:      	movq	0x20(%rsp), %rax
    42d4:      	testq	%rax, %rax
    42d7:      	je	0x4599 <perf_unwind_ruby+0x4599>
    42dd:      	movzbl	0x1f(%r15), %ecx
    42e2:      	addq	%rcx, %rax
    42e5:      	leaq	0x10(%rsp), %rdi
    42ea:      	movl	$0x8, %ecx
    42ef:      	movl	$0x70, %r8d
    42f5:      	movzbl	0x1f(%r15), %edx
    42fa:      	addq	0x20(%rsp), %rdx
    42ff:      	movl	$0x8, %esi
    4304:      	callq	*%r8
    4307:      	testq	%rax, %rax
    430a:      	jne	0x4c7 <perf_unwind_ruby+0x4c7>
    4310:      	movzbl	0x21(%r15), %eax
    4315:      	addq	0x10(%rsp), %rax
    431a:      	leaq	0x68(%rsp), %rdi
    431f:      	movl	$0x8, %ecx
    4324:      	movl	$0x70, %r8d
    432a:      	movzbl	0x21(%r15), %edx
    432f:      	addq	0x10(%rsp), %rdx
    4334:      	movl	$0x8, %esi
    4339:      	callq	*%r8
    433c:      	testq	%rax, %rax
    433f:      	jne	0x8a4 <perf_unwind_ruby+0x8a4>
    4345:      	movzbl	0x22(%r15), %eax
    434a:      	addq	0x10(%rsp), %rax
    434f:      	leaq	0x2c(%rsp), %rdi
    4354:      	movl	$0x4, %ecx
    4359:      	movl	$0x70, %r8d
    435f:      	movzbl	0x22(%r15), %edx
    4364:      	addq	0x10(%rsp), %rdx
    4369:      	movl	$0x4, %esi
    436e:      	callq	*%r8
    4371:      	testq	%rax, %rax
    4374:      	jne	0xc08 <perf_unwind_ruby+0xc08>
    437a:      	movzbl	0x23(%r15), %ecx
    437f:      	testq	%rcx, %rcx
    4382:      	je	0x4bd1 <perf_unwind_ruby+0x4bd1>
    4388:      	movq	0x18(%rsp), %rax
    438d:      	subq	0x68(%rsp), %rax
    4392:      	xorl	%edx, %edx
    4394:      	divq	%rcx
    4397:      	movl	0x2c(%rsp), %ecx
    439b:      	cmpq	%rcx, %rax
    439e:      	jbe	0x4bd1 <perf_unwind_ruby+0x4bd1>
    43a4:      	movq	(%rip), %rax            # 0x43ab <perf_unwind_ruby+0x43ab>
    43ab:      	cmpl	$0x0, (%rax)
    43ae:      	je	0x45a6 <perf_unwind_ruby+0x45a6>
    43b4:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    43be:      	movq	%rax, 0x55(%rsp)
    43c3:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    43cd:      	movq	%rax, 0x50(%rsp)
    43d2:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    43dc:      	movq	%rax, 0x48(%rsp)
    43e1:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    43eb:      	movq	%rax, 0x40(%rsp)
    43f0:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    43fa:      	movq	%rax, 0x38(%rsp)
    43ff:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    4409:      	movq	%rax, 0x30(%rsp)
    440e:      	leaq	0x30(%rsp), %rdi
    4413:      	movl	$0x2d, %eax
    4418:      	movl	$0x6, %ecx
    441d:      	movl	$0x2d, %esi
    4422:      	xorl	%eax, %eax
    4424:      	callq	*%rcx
    4426:      	jmp	0x45a6 <perf_unwind_ruby+0x45a6>
    442b:      	movq	$0x0, (%rsp)
    4433:      	movzbl	0x1d(%r15), %eax
    4438:      	addq	0x8(%rsp), %rax
    443d:      	movq	%rsp, %rdi
    4440:      	movl	$0x8, %ecx
    4445:      	movl	$0x70, %r8d
    444b:      	movzbl	0x1d(%r15), %edx
    4450:      	addq	0x8(%rsp), %rdx
    4455:      	movl	$0x8, %esi
    445a:      	callq	*%r8
    445d:      	testq	%rax, %rax
    4460:      	jne	0x81b <perf_unwind_ruby+0x81b>
    4466:      	movl	(%rsp), %eax
    4469:      	notl	%eax
    446b:      	testl	$0x140, %eax            # imm = 0x140
    4470:      	jne	0x997 <perf_unwind_ruby+0x997>
    4476:      	jmp	0x4240 <perf_unwind_ruby+0x4240>
    447b:      	movq	(%rip), %rax            # 0x4482 <perf_unwind_ruby+0x4482>
    4482:      	cmpl	$0x0, (%rax)
    4485:      	je	0x3b74 <perf_unwind_ruby+0x3b74>
    448b:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4495:      	movq	%rax, 0x56(%rsp)
    449a:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    44a4:      	movq	%rax, 0x50(%rsp)
    44a9:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    44b3:      	movq	%rax, 0x48(%rsp)
    44b8:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    44c2:      	movq	%rax, 0x40(%rsp)
    44c7:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    44d1:      	movq	%rax, 0x38(%rsp)
    44d6:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    44e0:      	movq	%rax, 0x30(%rsp)
    44e5:      	leaq	0x30(%rsp), %rdi
    44ea:      	movl	$0x2e, %eax
    44ef:      	movl	$0x6, %ecx
    44f4:      	movl	(%rsp), %edx
    44f7:      	movl	$0x2e, %esi
    44fc:      	xorl	%eax, %eax
    44fe:      	callq	*%rcx
    4500:      	jmp	0x3b74 <perf_unwind_ruby+0x3b74>
    4505:      	movl	0x2c0(%r14), %eax
    450c:      	cmpq	$0x7e, %rax
    4510:      	ja	0xdd3 <perf_unwind_ruby+0xdd3>
    4516:      	movq	0x10(%rsp), %rcx
    451b:      	movq	0x18(%rsp), %rdx
    4520:      	leal	0x1(%rax), %esi
    4523:      	movl	%esi, 0x2c0(%r14)
    452a:      	leaq	(%rax,%rax,2), %rax
    452e:      	movw	$0x0, 0x4(%rsp)
    4535:      	movl	$0x0, (%rsp)
    453c:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    4544:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    454c:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    4557:      	movl	(%rsp), %ecx
    455a:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    4562:      	movzwl	0x4(%rsp), %ecx
    4567:      	movw	%cx, 0x2e6(%r14,%rax,8)
    4570:      	movl	$0x36, (%rsp)
    4577:      	movq	(%rip), %rdi            # 0x457e <perf_unwind_ruby+0x457e>
    457e:      	movq	%rsp, %rsi
    4581:      	movl	$0x1, %eax
    4586:      	callq	*%rax
    4588:      	testq	%rax, %rax
    458b:      	je	0x47e1 <perf_unwind_ruby+0x47e1>
    4591:      	incq	(%rax)
    4594:      	jmp	0x3eda <perf_unwind_ruby+0x3eda>
    4599:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    45a0:      	jae	0x4791 <perf_unwind_ruby+0x4791>
    45a6:      	movq	0x8(%rsp), %rax
    45ab:      	cmpq	%rax, %r12
    45ae:      	jbe	0x2b2 <perf_unwind_ruby+0x2b2>
    45b4:      	movzbl	0x1e(%r15), %ecx
    45b9:      	addq	%rcx, %rax
    45bc:      	movq	%rax, 0x8(%rsp)
    45c1:      	movq	$0x0, 0x18(%rsp)
    45ca:      	movq	$0x0, 0x20(%rsp)
    45d3:      	movzbl	0x1c(%r15), %ecx
    45d8:      	addq	%rax, %rcx
    45db:      	leaq	0x20(%rsp), %rdi
    45e0:      	movl	$0x8, %eax
    45e5:      	movl	$0x70, %r8d
    45eb:      	movzbl	0x1c(%r15), %edx
    45f0:      	addq	0x8(%rsp), %rdx
    45f5:      	movl	$0x8, %esi
    45fa:      	callq	*%r8
    45fd:      	movzbl	0x1b(%r15), %eax
    4602:      	addq	0x8(%rsp), %rax
    4607:      	leaq	0x18(%rsp), %rdi
    460c:      	movl	$0x8, %ecx
    4611:      	movl	$0x70, %r8d
    4617:      	movzbl	0x1b(%r15), %edx
    461c:      	addq	0x8(%rsp), %rdx
    4621:      	movl	$0x8, %esi
    4626:      	callq	*%r8
    4629:      	cmpq	$0x0, 0x18(%rsp)
    462f:      	je	0x48ff <perf_unwind_ruby+0x48ff>
    4635:      	movq	0x20(%rsp), %rax
    463a:      	testq	%rax, %rax
    463d:      	je	0x48ff <perf_unwind_ruby+0x48ff>
    4643:      	movzbl	0x1f(%r15), %ecx
    4648:      	addq	%rcx, %rax
    464b:      	leaq	0x10(%rsp), %rdi
    4650:      	movl	$0x8, %ecx
    4655:      	movl	$0x70, %r8d
    465b:      	movzbl	0x1f(%r15), %edx
    4660:      	addq	0x20(%rsp), %rdx
    4665:      	movl	$0x8, %esi
    466a:      	callq	*%r8
    466d:      	testq	%rax, %rax
    4670:      	jne	0x4c7 <perf_unwind_ruby+0x4c7>
    4676:      	movzbl	0x21(%r15), %eax
    467b:      	addq	0x10(%rsp), %rax
    4680:      	leaq	0x68(%rsp), %rdi
    4685:      	movl	$0x8, %ecx
    468a:      	movl	$0x70, %r8d
    4690:      	movzbl	0x21(%r15), %edx
    4695:      	addq	0x10(%rsp), %rdx
    469a:      	movl	$0x8, %esi
    469f:      	callq	*%r8
    46a2:      	testq	%rax, %rax
    46a5:      	jne	0x8a4 <perf_unwind_ruby+0x8a4>
    46ab:      	movzbl	0x22(%r15), %eax
    46b0:      	addq	0x10(%rsp), %rax
    46b5:      	leaq	0x2c(%rsp), %rdi
    46ba:      	movl	$0x4, %ecx
    46bf:      	movl	$0x70, %r8d
    46c5:      	movzbl	0x22(%r15), %edx
    46ca:      	addq	0x10(%rsp), %rdx
    46cf:      	movl	$0x4, %esi
    46d4:      	callq	*%r8
    46d7:      	testq	%rax, %rax
    46da:      	jne	0xc08 <perf_unwind_ruby+0xc08>
    46e0:      	movzbl	0x23(%r15), %ecx
    46e5:      	testq	%rcx, %rcx
    46e8:      	je	0x4d48 <perf_unwind_ruby+0x4d48>
    46ee:      	movq	0x18(%rsp), %rax
    46f3:      	subq	0x68(%rsp), %rax
    46f8:      	xorl	%edx, %edx
    46fa:      	divq	%rcx
    46fd:      	movl	0x2c(%rsp), %ecx
    4701:      	cmpq	%rcx, %rax
    4704:      	jbe	0x4d48 <perf_unwind_ruby+0x4d48>
    470a:      	movq	(%rip), %rax            # 0x4711 <perf_unwind_ruby+0x4711>
    4711:      	cmpl	$0x0, (%rax)
    4714:      	je	0x490c <perf_unwind_ruby+0x490c>
    471a:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    4724:      	movq	%rax, 0x55(%rsp)
    4729:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    4733:      	movq	%rax, 0x50(%rsp)
    4738:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    4742:      	movq	%rax, 0x48(%rsp)
    4747:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    4751:      	movq	%rax, 0x40(%rsp)
    4756:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    4760:      	movq	%rax, 0x38(%rsp)
    4765:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    476f:      	movq	%rax, 0x30(%rsp)
    4774:      	leaq	0x30(%rsp), %rdi
    4779:      	movl	$0x2d, %eax
    477e:      	movl	$0x6, %ecx
    4783:      	movl	$0x2d, %esi
    4788:      	xorl	%eax, %eax
    478a:      	callq	*%rcx
    478c:      	jmp	0x490c <perf_unwind_ruby+0x490c>
    4791:      	movq	$0x0, (%rsp)
    4799:      	movzbl	0x1d(%r15), %eax
    479e:      	addq	0x8(%rsp), %rax
    47a3:      	movq	%rsp, %rdi
    47a6:      	movl	$0x8, %ecx
    47ab:      	movl	$0x70, %r8d
    47b1:      	movzbl	0x1d(%r15), %edx
    47b6:      	addq	0x8(%rsp), %rdx
    47bb:      	movl	$0x8, %esi
    47c0:      	callq	*%r8
    47c3:      	testq	%rax, %rax
    47c6:      	jne	0x81b <perf_unwind_ruby+0x81b>
    47cc:      	movl	(%rsp), %eax
    47cf:      	notl	%eax
    47d1:      	testl	$0x140, %eax            # imm = 0x140
    47d6:      	jne	0x997 <perf_unwind_ruby+0x997>
    47dc:      	jmp	0x45a6 <perf_unwind_ruby+0x45a6>
    47e1:      	movq	(%rip), %rax            # 0x47e8 <perf_unwind_ruby+0x47e8>
    47e8:      	cmpl	$0x0, (%rax)
    47eb:      	je	0x3eda <perf_unwind_ruby+0x3eda>
    47f1:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    47fb:      	movq	%rax, 0x56(%rsp)
    4800:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    480a:      	movq	%rax, 0x50(%rsp)
    480f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4819:      	movq	%rax, 0x48(%rsp)
    481e:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4828:      	movq	%rax, 0x40(%rsp)
    482d:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4837:      	movq	%rax, 0x38(%rsp)
    483c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4846:      	movq	%rax, 0x30(%rsp)
    484b:      	leaq	0x30(%rsp), %rdi
    4850:      	movl	$0x2e, %eax
    4855:      	movl	$0x6, %ecx
    485a:      	movl	(%rsp), %edx
    485d:      	movl	$0x2e, %esi
    4862:      	xorl	%eax, %eax
    4864:      	callq	*%rcx
    4866:      	jmp	0x3eda <perf_unwind_ruby+0x3eda>
    486b:      	movl	0x2c0(%r14), %eax
    4872:      	cmpq	$0x7e, %rax
    4876:      	ja	0xdd3 <perf_unwind_ruby+0xdd3>
    487c:      	movq	0x10(%rsp), %rcx
    4881:      	movq	0x18(%rsp), %rdx
    4886:      	leal	0x1(%rax), %esi
    4889:      	movl	%esi, 0x2c0(%r14)
    4890:      	leaq	(%rax,%rax,2), %rax
    4894:      	movw	$0x0, 0x4(%rsp)
    489b:      	movl	$0x0, (%rsp)
    48a2:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    48aa:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    48b2:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    48bd:      	movl	(%rsp), %ecx
    48c0:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    48c8:      	movzwl	0x4(%rsp), %ecx
    48cd:      	movw	%cx, 0x2e6(%r14,%rax,8)
    48d6:      	movl	$0x36, (%rsp)
    48dd:      	movq	(%rip), %rdi            # 0x48e4 <perf_unwind_ruby+0x48e4>
    48e4:      	movq	%rsp, %rsi
    48e7:      	movl	$0x1, %eax
    48ec:      	callq	*%rax
    48ee:      	testq	%rax, %rax
    48f1:      	je	0x4b47 <perf_unwind_ruby+0x4b47>
    48f7:      	incq	(%rax)
    48fa:      	jmp	0x4240 <perf_unwind_ruby+0x4240>
    48ff:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    4906:      	jae	0x4af7 <perf_unwind_ruby+0x4af7>
    490c:      	movq	0x8(%rsp), %rax
    4911:      	cmpq	%rax, %r12
    4914:      	jbe	0x2b2 <perf_unwind_ruby+0x2b2>
    491a:      	movzbl	0x1e(%r15), %ecx
    491f:      	addq	%rcx, %rax
    4922:      	movq	%rax, 0x8(%rsp)
    4927:      	movq	$0x0, 0x18(%rsp)
    4930:      	movq	$0x0, 0x20(%rsp)
    4939:      	movzbl	0x1c(%r15), %ecx
    493e:      	addq	%rax, %rcx
    4941:      	leaq	0x20(%rsp), %rdi
    4946:      	movl	$0x8, %eax
    494b:      	movl	$0x70, %r8d
    4951:      	movzbl	0x1c(%r15), %edx
    4956:      	addq	0x8(%rsp), %rdx
    495b:      	movl	$0x8, %esi
    4960:      	callq	*%r8
    4963:      	movzbl	0x1b(%r15), %eax
    4968:      	addq	0x8(%rsp), %rax
    496d:      	leaq	0x18(%rsp), %rdi
    4972:      	movl	$0x8, %ecx
    4977:      	movl	$0x70, %r8d
    497d:      	movzbl	0x1b(%r15), %edx
    4982:      	addq	0x8(%rsp), %rdx
    4987:      	movl	$0x8, %esi
    498c:      	callq	*%r8
    498f:      	cmpq	$0x0, 0x18(%rsp)
    4995:      	je	0x4c61 <perf_unwind_ruby+0x4c61>
    499b:      	movq	0x20(%rsp), %rax
    49a0:      	testq	%rax, %rax
    49a3:      	je	0x4c61 <perf_unwind_ruby+0x4c61>
    49a9:      	movzbl	0x1f(%r15), %ecx
    49ae:      	addq	%rcx, %rax
    49b1:      	leaq	0x10(%rsp), %rdi
    49b6:      	movl	$0x8, %ecx
    49bb:      	movl	$0x70, %r8d
    49c1:      	movzbl	0x1f(%r15), %edx
    49c6:      	addq	0x20(%rsp), %rdx
    49cb:      	movl	$0x8, %esi
    49d0:      	callq	*%r8
    49d3:      	testq	%rax, %rax
    49d6:      	jne	0x4c7 <perf_unwind_ruby+0x4c7>
    49dc:      	movzbl	0x21(%r15), %eax
    49e1:      	addq	0x10(%rsp), %rax
    49e6:      	leaq	0x68(%rsp), %rdi
    49eb:      	movl	$0x8, %ecx
    49f0:      	movl	$0x70, %r8d
    49f6:      	movzbl	0x21(%r15), %edx
    49fb:      	addq	0x10(%rsp), %rdx
    4a00:      	movl	$0x8, %esi
    4a05:      	callq	*%r8
    4a08:      	testq	%rax, %rax
    4a0b:      	jne	0x8a4 <perf_unwind_ruby+0x8a4>
    4a11:      	movzbl	0x22(%r15), %eax
    4a16:      	addq	0x10(%rsp), %rax
    4a1b:      	leaq	0x2c(%rsp), %rdi
    4a20:      	movl	$0x4, %ecx
    4a25:      	movl	$0x70, %r8d
    4a2b:      	movzbl	0x22(%r15), %edx
    4a30:      	addq	0x10(%rsp), %rdx
    4a35:      	movl	$0x4, %esi
    4a3a:      	callq	*%r8
    4a3d:      	testq	%rax, %rax
    4a40:      	jne	0xc08 <perf_unwind_ruby+0xc08>
    4a46:      	movzbl	0x23(%r15), %ecx
    4a4b:      	testq	%rcx, %rcx
    4a4e:      	je	0x4ddc <perf_unwind_ruby+0x4ddc>
    4a54:      	movq	0x18(%rsp), %rax
    4a59:      	subq	0x68(%rsp), %rax
    4a5e:      	xorl	%edx, %edx
    4a60:      	divq	%rcx
    4a63:      	movl	0x2c(%rsp), %ecx
    4a67:      	cmpq	%rcx, %rax
    4a6a:      	jbe	0x4ddc <perf_unwind_ruby+0x4ddc>
    4a70:      	movq	(%rip), %rax            # 0x4a77 <perf_unwind_ruby+0x4a77>
    4a77:      	cmpl	$0x0, (%rax)
    4a7a:      	je	0x4f7b <perf_unwind_ruby+0x4f7b>
    4a80:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    4a8a:      	movq	%rax, 0x55(%rsp)
    4a8f:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    4a99:      	movq	%rax, 0x50(%rsp)
    4a9e:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    4aa8:      	movq	%rax, 0x48(%rsp)
    4aad:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    4ab7:      	movq	%rax, 0x40(%rsp)
    4abc:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    4ac6:      	movq	%rax, 0x38(%rsp)
    4acb:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    4ad5:      	movq	%rax, 0x30(%rsp)
    4ada:      	leaq	0x30(%rsp), %rdi
    4adf:      	movl	$0x2d, %eax
    4ae4:      	movl	$0x6, %ecx
    4ae9:      	movl	$0x2d, %esi
    4aee:      	xorl	%eax, %eax
    4af0:      	callq	*%rcx
    4af2:      	jmp	0x4f7b <perf_unwind_ruby+0x4f7b>
    4af7:      	movq	$0x0, (%rsp)
    4aff:      	movzbl	0x1d(%r15), %eax
    4b04:      	addq	0x8(%rsp), %rax
    4b09:      	movq	%rsp, %rdi
    4b0c:      	movl	$0x8, %ecx
    4b11:      	movl	$0x70, %r8d
    4b17:      	movzbl	0x1d(%r15), %edx
    4b1c:      	addq	0x8(%rsp), %rdx
    4b21:      	movl	$0x8, %esi
    4b26:      	callq	*%r8
    4b29:      	testq	%rax, %rax
    4b2c:      	jne	0x81b <perf_unwind_ruby+0x81b>
    4b32:      	movl	(%rsp), %eax
    4b35:      	notl	%eax
    4b37:      	testl	$0x140, %eax            # imm = 0x140
    4b3c:      	jne	0x997 <perf_unwind_ruby+0x997>
    4b42:      	jmp	0x490c <perf_unwind_ruby+0x490c>
    4b47:      	movq	(%rip), %rax            # 0x4b4e <perf_unwind_ruby+0x4b4e>
    4b4e:      	cmpl	$0x0, (%rax)
    4b51:      	je	0x4240 <perf_unwind_ruby+0x4240>
    4b57:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4b61:      	movq	%rax, 0x56(%rsp)
    4b66:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4b70:      	movq	%rax, 0x50(%rsp)
    4b75:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4b7f:      	movq	%rax, 0x48(%rsp)
    4b84:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4b8e:      	movq	%rax, 0x40(%rsp)
    4b93:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4b9d:      	movq	%rax, 0x38(%rsp)
    4ba2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4bac:      	movq	%rax, 0x30(%rsp)
    4bb1:      	leaq	0x30(%rsp), %rdi
    4bb6:      	movl	$0x2e, %eax
    4bbb:      	movl	$0x6, %ecx
    4bc0:      	movl	(%rsp), %edx
    4bc3:      	movl	$0x2e, %esi
    4bc8:      	xorl	%eax, %eax
    4bca:      	callq	*%rcx
    4bcc:      	jmp	0x4240 <perf_unwind_ruby+0x4240>
    4bd1:      	movl	0x2c0(%r14), %eax
    4bd8:      	cmpq	$0x7e, %rax
    4bdc:      	ja	0xdd3 <perf_unwind_ruby+0xdd3>
    4be2:      	movq	0x10(%rsp), %rcx
    4be7:      	movq	0x18(%rsp), %rdx
    4bec:      	leal	0x1(%rax), %esi
    4bef:      	movl	%esi, 0x2c0(%r14)
    4bf6:      	leaq	(%rax,%rax,2), %rax
    4bfa:      	movw	$0x0, 0x4(%rsp)
    4c01:      	movl	$0x0, (%rsp)
    4c08:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    4c10:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    4c18:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    4c23:      	movl	(%rsp), %ecx
    4c26:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    4c2e:      	movzwl	0x4(%rsp), %ecx
    4c33:      	movw	%cx, 0x2e6(%r14,%rax,8)
    4c3c:      	movl	$0x36, (%rsp)
    4c43:      	movq	(%rip), %rdi            # 0x4c4a <perf_unwind_ruby+0x4c4a>
    4c4a:      	movq	%rsp, %rsi
    4c4d:      	movl	$0x1, %eax
    4c52:      	callq	*%rax
    4c54:      	testq	%rax, %rax
    4c57:      	je	0x4cbe <perf_unwind_ruby+0x4cbe>
    4c59:      	incq	(%rax)
    4c5c:      	jmp	0x45a6 <perf_unwind_ruby+0x45a6>
    4c61:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    4c68:      	jb	0x4f7b <perf_unwind_ruby+0x4f7b>
    4c6e:      	movq	$0x0, (%rsp)
    4c76:      	movzbl	0x1d(%r15), %eax
    4c7b:      	addq	0x8(%rsp), %rax
    4c80:      	movq	%rsp, %rdi
    4c83:      	movl	$0x8, %ecx
    4c88:      	movl	$0x70, %r8d
    4c8e:      	movzbl	0x1d(%r15), %edx
    4c93:      	addq	0x8(%rsp), %rdx
    4c98:      	movl	$0x8, %esi
    4c9d:      	callq	*%r8
    4ca0:      	testq	%rax, %rax
    4ca3:      	jne	0x81b <perf_unwind_ruby+0x81b>
    4ca9:      	movl	(%rsp), %eax
    4cac:      	notl	%eax
    4cae:      	testl	$0x140, %eax            # imm = 0x140
    4cb3:      	jne	0x997 <perf_unwind_ruby+0x997>
    4cb9:      	jmp	0x4f7b <perf_unwind_ruby+0x4f7b>
    4cbe:      	movq	(%rip), %rax            # 0x4cc5 <perf_unwind_ruby+0x4cc5>
    4cc5:      	cmpl	$0x0, (%rax)
    4cc8:      	je	0x45a6 <perf_unwind_ruby+0x45a6>
    4cce:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4cd8:      	movq	%rax, 0x56(%rsp)
    4cdd:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4ce7:      	movq	%rax, 0x50(%rsp)
    4cec:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4cf6:      	movq	%rax, 0x48(%rsp)
    4cfb:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4d05:      	movq	%rax, 0x40(%rsp)
    4d0a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4d14:      	movq	%rax, 0x38(%rsp)
    4d19:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4d23:      	movq	%rax, 0x30(%rsp)
    4d28:      	leaq	0x30(%rsp), %rdi
    4d2d:      	movl	$0x2e, %eax
    4d32:      	movl	$0x6, %ecx
    4d37:      	movl	(%rsp), %edx
    4d3a:      	movl	$0x2e, %esi
    4d3f:      	xorl	%eax, %eax
    4d41:      	callq	*%rcx
    4d43:      	jmp	0x45a6 <perf_unwind_ruby+0x45a6>
    4d48:      	movl	0x2c0(%r14), %eax
    4d4f:      	cmpq	$0x7e, %rax
    4d53:      	ja	0xdd3 <perf_unwind_ruby+0xdd3>
    4d59:      	movq	0x10(%rsp), %rcx
    4d5e:      	movq	0x18(%rsp), %rdx
    4d63:      	leal	0x1(%rax), %esi
    4d66:      	movl	%esi, 0x2c0(%r14)
    4d6d:      	leaq	(%rax,%rax,2), %rax
    4d71:      	movw	$0x0, 0x4(%rsp)
    4d78:      	movl	$0x0, (%rsp)
    4d7f:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    4d87:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    4d8f:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    4d9a:      	movl	(%rsp), %ecx
    4d9d:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    4da5:      	movzwl	0x4(%rsp), %ecx
    4daa:      	movw	%cx, 0x2e6(%r14,%rax,8)
    4db3:      	movl	$0x36, (%rsp)
    4dba:      	movq	(%rip), %rdi            # 0x4dc1 <perf_unwind_ruby+0x4dc1>
    4dc1:      	movq	%rsp, %rsi
    4dc4:      	movl	$0x1, %eax
    4dc9:      	callq	*%rax
    4dcb:      	testq	%rax, %rax
    4dce:      	je	0x4e70 <perf_unwind_ruby+0x4e70>
    4dd4:      	incq	(%rax)
    4dd7:      	jmp	0x490c <perf_unwind_ruby+0x490c>
    4ddc:      	movl	0x2c0(%r14), %eax
    4de3:      	cmpq	$0x7e, %rax
    4de7:      	ja	0xdd3 <perf_unwind_ruby+0xdd3>
    4ded:      	movq	0x10(%rsp), %rcx
    4df2:      	movq	0x18(%rsp), %rdx
    4df7:      	leal	0x1(%rax), %esi
    4dfa:      	movl	%esi, 0x2c0(%r14)
    4e01:      	leaq	(%rax,%rax,2), %rax
    4e05:      	movw	$0x0, 0x4(%rsp)
    4e0c:      	movl	$0x0, (%rsp)
    4e13:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    4e1b:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    4e23:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    4e2e:      	movl	(%rsp), %ecx
    4e31:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    4e39:      	movzwl	0x4(%rsp), %ecx
    4e3e:      	movw	%cx, 0x2e6(%r14,%rax,8)
    4e47:      	movl	$0x36, (%rsp)
    4e4e:      	movq	(%rip), %rdi            # 0x4e55 <perf_unwind_ruby+0x4e55>
    4e55:      	movq	%rsp, %rsi
    4e58:      	movl	$0x1, %eax
    4e5d:      	callq	*%rax
    4e5f:      	testq	%rax, %rax
    4e62:      	je	0x4efa <perf_unwind_ruby+0x4efa>
    4e68:      	incq	(%rax)
    4e6b:      	jmp	0x4f7b <perf_unwind_ruby+0x4f7b>
    4e70:      	movq	(%rip), %rax            # 0x4e77 <perf_unwind_ruby+0x4e77>
    4e77:      	cmpl	$0x0, (%rax)
    4e7a:      	je	0x490c <perf_unwind_ruby+0x490c>
    4e80:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4e8a:      	movq	%rax, 0x56(%rsp)
    4e8f:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4e99:      	movq	%rax, 0x50(%rsp)
    4e9e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4ea8:      	movq	%rax, 0x48(%rsp)
    4ead:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4eb7:      	movq	%rax, 0x40(%rsp)
    4ebc:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4ec6:      	movq	%rax, 0x38(%rsp)
    4ecb:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4ed5:      	movq	%rax, 0x30(%rsp)
    4eda:      	leaq	0x30(%rsp), %rdi
    4edf:      	movl	$0x2e, %eax
    4ee4:      	movl	$0x6, %ecx
    4ee9:      	movl	(%rsp), %edx
    4eec:      	movl	$0x2e, %esi
    4ef1:      	xorl	%eax, %eax
    4ef3:      	callq	*%rcx
    4ef5:      	jmp	0x490c <perf_unwind_ruby+0x490c>
    4efa:      	movq	(%rip), %rax            # 0x4f01 <perf_unwind_ruby+0x4f01>
    4f01:      	cmpl	$0x0, (%rax)
    4f04:      	je	0x4f7b <perf_unwind_ruby+0x4f7b>
    4f06:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4f10:      	movq	%rax, 0x56(%rsp)
    4f15:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4f1f:      	movq	%rax, 0x50(%rsp)
    4f24:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4f2e:      	movq	%rax, 0x48(%rsp)
    4f33:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4f3d:      	movq	%rax, 0x40(%rsp)
    4f42:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4f4c:      	movq	%rax, 0x38(%rsp)
    4f51:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4f5b:      	movq	%rax, 0x30(%rsp)
    4f60:      	leaq	0x30(%rsp), %rdi
    4f65:      	movl	$0x2e, %eax
    4f6a:      	movl	$0x6, %ecx
    4f6f:      	movl	(%rsp), %edx
    4f72:      	movl	$0x2e, %esi
    4f77:      	xorl	%eax, %eax
    4f79:      	callq	*%rcx
    4f7b:      	movq	0x8(%rsp), %rax
    4f80:      	cmpq	%rax, %r12
    4f83:      	jbe	0x2b2 <perf_unwind_ruby+0x2b2>
    4f89:      	movzbl	0x1e(%r15), %ecx
    4f8e:      	addq	%rcx, %rax
    4f91:      	movq	%rax, 0x8(%rsp)
    4f96:      	movq	$0x0, 0x18(%rsp)
    4f9f:      	movq	$0x0, 0x20(%rsp)
    4fa8:      	movzbl	0x1c(%r15), %ecx
    4fad:      	addq	%rax, %rcx
    4fb0:      	leaq	0x20(%rsp), %rdi
    4fb5:      	movl	$0x8, %eax
    4fba:      	movl	$0x70, %r8d
    4fc0:      	movzbl	0x1c(%r15), %edx
    4fc5:      	addq	0x8(%rsp), %rdx
    4fca:      	movl	$0x8, %esi
    4fcf:      	callq	*%r8
    4fd2:      	movzbl	0x1b(%r15), %eax
    4fd7:      	addq	0x8(%rsp), %rax
    4fdc:      	leaq	0x18(%rsp), %rdi
    4fe1:      	movl	$0x8, %ecx
    4fe6:      	movl	$0x70, %r8d
    4fec:      	movzbl	0x1b(%r15), %edx
    4ff1:      	addq	0x8(%rsp), %rdx
    4ff6:      	movl	$0x8, %esi
    4ffb:      	callq	*%r8
    4ffe:      	cmpq	$0x0, 0x18(%rsp)
    5004:      	je	0x5166 <perf_unwind_ruby+0x5166>
    500a:      	movq	0x20(%rsp), %rax
    500f:      	testq	%rax, %rax
    5012:      	je	0x5166 <perf_unwind_ruby+0x5166>
    5018:      	movzbl	0x1f(%r15), %ecx
    501d:      	addq	%rcx, %rax
    5020:      	leaq	0x10(%rsp), %rdi
    5025:      	movl	$0x8, %ecx
    502a:      	movl	$0x70, %r8d
    5030:      	movzbl	0x1f(%r15), %edx
    5035:      	addq	0x20(%rsp), %rdx
    503a:      	movl	$0x8, %esi
    503f:      	callq	*%r8
    5042:      	testq	%rax, %rax
    5045:      	jne	0x4c7 <perf_unwind_ruby+0x4c7>
    504b:      	movzbl	0x21(%r15), %eax
    5050:      	addq	0x10(%rsp), %rax
    5055:      	leaq	0x68(%rsp), %rdi
    505a:      	movl	$0x8, %ecx
    505f:      	movl	$0x70, %r8d
    5065:      	movzbl	0x21(%r15), %edx
    506a:      	addq	0x10(%rsp), %rdx
    506f:      	movl	$0x8, %esi
    5074:      	callq	*%r8
    5077:      	testq	%rax, %rax
    507a:      	jne	0x8a4 <perf_unwind_ruby+0x8a4>
    5080:      	movzbl	0x22(%r15), %eax
    5085:      	addq	0x10(%rsp), %rax
    508a:      	leaq	0x2c(%rsp), %rdi
    508f:      	movl	$0x4, %ecx
    5094:      	movl	$0x70, %r8d
    509a:      	movzbl	0x22(%r15), %edx
    509f:      	addq	0x10(%rsp), %rdx
    50a4:      	movl	$0x4, %esi
    50a9:      	callq	*%r8
    50ac:      	testq	%rax, %rax
    50af:      	jne	0xc08 <perf_unwind_ruby+0xc08>
    50b5:      	movzbl	0x23(%r15), %ecx
    50ba:      	testq	%rcx, %rcx
    50bd:      	je	0x51c3 <perf_unwind_ruby+0x51c3>
    50c3:      	movq	0x18(%rsp), %rax
    50c8:      	subq	0x68(%rsp), %rax
    50cd:      	xorl	%edx, %edx
    50cf:      	divq	%rcx
    50d2:      	movl	0x2c(%rsp), %ecx
    50d6:      	cmpq	%rcx, %rax
    50d9:      	jbe	0x51c3 <perf_unwind_ruby+0x51c3>
    50df:      	movq	(%rip), %rax            # 0x50e6 <perf_unwind_ruby+0x50e6>
    50e6:      	cmpl	$0x0, (%rax)
    50e9:      	je	0x52d4 <perf_unwind_ruby+0x52d4>
    50ef:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    50f9:      	movq	%rax, 0x55(%rsp)
    50fe:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    5108:      	movq	%rax, 0x50(%rsp)
    510d:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    5117:      	movq	%rax, 0x48(%rsp)
    511c:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    5126:      	movq	%rax, 0x40(%rsp)
    512b:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    5135:      	movq	%rax, 0x38(%rsp)
    513a:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    5144:      	movq	%rax, 0x30(%rsp)
    5149:      	leaq	0x30(%rsp), %rdi
    514e:      	movl	$0x2d, %eax
    5153:      	movl	$0x6, %ecx
    5158:      	movl	$0x2d, %esi
    515d:      	xorl	%eax, %eax
    515f:      	callq	*%rcx
    5161:      	jmp	0x52d4 <perf_unwind_ruby+0x52d4>
    5166:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    516d:      	jb	0x52d4 <perf_unwind_ruby+0x52d4>
    5173:      	movq	$0x0, (%rsp)
    517b:      	movzbl	0x1d(%r15), %eax
    5180:      	addq	0x8(%rsp), %rax
    5185:      	movq	%rsp, %rdi
    5188:      	movl	$0x8, %ecx
    518d:      	movl	$0x70, %r8d
    5193:      	movzbl	0x1d(%r15), %edx
    5198:      	addq	0x8(%rsp), %rdx
    519d:      	movl	$0x8, %esi
    51a2:      	callq	*%r8
    51a5:      	testq	%rax, %rax
    51a8:      	jne	0x81b <perf_unwind_ruby+0x81b>
    51ae:      	movl	(%rsp), %eax
    51b1:      	notl	%eax
    51b3:      	testl	$0x140, %eax            # imm = 0x140
    51b8:      	jne	0x997 <perf_unwind_ruby+0x997>
    51be:      	jmp	0x52d4 <perf_unwind_ruby+0x52d4>
    51c3:      	movl	0x2c0(%r14), %eax
    51ca:      	cmpq	$0x7e, %rax
    51ce:      	ja	0xdd3 <perf_unwind_ruby+0xdd3>
    51d4:      	movq	0x10(%rsp), %rcx
    51d9:      	movq	0x18(%rsp), %rdx
    51de:      	leal	0x1(%rax), %esi
    51e1:      	movl	%esi, 0x2c0(%r14)
    51e8:      	leaq	(%rax,%rax,2), %rax
    51ec:      	movw	$0x0, 0x4(%rsp)
    51f3:      	movl	$0x0, (%rsp)
    51fa:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    5202:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    520a:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    5215:      	movl	(%rsp), %ecx
    5218:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    5220:      	movzwl	0x4(%rsp), %ecx
    5225:      	movw	%cx, 0x2e6(%r14,%rax,8)
    522e:      	movl	$0x36, (%rsp)
    5235:      	movq	(%rip), %rdi            # 0x523c <perf_unwind_ruby+0x523c>
    523c:      	movq	%rsp, %rsi
    523f:      	movl	$0x1, %eax
    5244:      	callq	*%rax
    5246:      	testq	%rax, %rax
    5249:      	je	0x5253 <perf_unwind_ruby+0x5253>
    524b:      	incq	(%rax)
    524e:      	jmp	0x52d4 <perf_unwind_ruby+0x52d4>
    5253:      	movq	(%rip), %rax            # 0x525a <perf_unwind_ruby+0x525a>
    525a:      	cmpl	$0x0, (%rax)
    525d:      	je	0x52d4 <perf_unwind_ruby+0x52d4>
    525f:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5269:      	movq	%rax, 0x56(%rsp)
    526e:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5278:      	movq	%rax, 0x50(%rsp)
    527d:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5287:      	movq	%rax, 0x48(%rsp)
    528c:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5296:      	movq	%rax, 0x40(%rsp)
    529b:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    52a5:      	movq	%rax, 0x38(%rsp)
    52aa:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    52b4:      	movq	%rax, 0x30(%rsp)
    52b9:      	leaq	0x30(%rsp), %rdi
    52be:      	movl	$0x2e, %eax
    52c3:      	movl	$0x6, %ecx
    52c8:      	movl	(%rsp), %edx
    52cb:      	movl	$0x2e, %esi
    52d0:      	xorl	%eax, %eax
    52d2:      	callq	*%rcx
    52d4:      	movq	0x8(%rsp), %rax
    52d9:      	cmpq	%rax, %r12
    52dc:      	jbe	0x2b2 <perf_unwind_ruby+0x2b2>
    52e2:      	movzbl	0x1e(%r15), %ecx
    52e7:      	addq	%rcx, %rax
    52ea:      	movq	%rax, 0x8(%rsp)
    52ef:      	movq	$0x0, 0x18(%rsp)
    52f8:      	movq	$0x0, 0x20(%rsp)
    5301:      	movzbl	0x1c(%r15), %ecx
    5306:      	addq	%rax, %rcx
    5309:      	leaq	0x20(%rsp), %rdi
    530e:      	movl	$0x8, %eax
    5313:      	movl	$0x70, %r8d
    5319:      	movzbl	0x1c(%r15), %edx
    531e:      	addq	0x8(%rsp), %rdx
    5323:      	movl	$0x8, %esi
    5328:      	callq	*%r8
    532b:      	movzbl	0x1b(%r15), %eax
    5330:      	addq	0x8(%rsp), %rax
    5335:      	leaq	0x18(%rsp), %rdi
    533a:      	movl	$0x8, %ecx
    533f:      	movl	$0x70, %r8d
    5345:      	movzbl	0x1b(%r15), %edx
    534a:      	addq	0x8(%rsp), %rdx
    534f:      	movl	$0x8, %esi
    5354:      	callq	*%r8
    5357:      	cmpq	$0x0, 0x18(%rsp)
    535d:      	je	0x54bf <perf_unwind_ruby+0x54bf>
    5363:      	movq	0x20(%rsp), %rax
    5368:      	testq	%rax, %rax
    536b:      	je	0x54bf <perf_unwind_ruby+0x54bf>
    5371:      	movzbl	0x1f(%r15), %ecx
    5376:      	addq	%rcx, %rax
    5379:      	leaq	0x10(%rsp), %rdi
    537e:      	movl	$0x8, %ecx
    5383:      	movl	$0x70, %r8d
    5389:      	movzbl	0x1f(%r15), %edx
    538e:      	addq	0x20(%rsp), %rdx
    5393:      	movl	$0x8, %esi
    5398:      	callq	*%r8
    539b:      	testq	%rax, %rax
    539e:      	jne	0x4c7 <perf_unwind_ruby+0x4c7>
    53a4:      	movzbl	0x21(%r15), %eax
    53a9:      	addq	0x10(%rsp), %rax
    53ae:      	leaq	0x68(%rsp), %rdi
    53b3:      	movl	$0x8, %ecx
    53b8:      	movl	$0x70, %r8d
    53be:      	movzbl	0x21(%r15), %edx
    53c3:      	addq	0x10(%rsp), %rdx
    53c8:      	movl	$0x8, %esi
    53cd:      	callq	*%r8
    53d0:      	testq	%rax, %rax
    53d3:      	jne	0x8a4 <perf_unwind_ruby+0x8a4>
    53d9:      	movzbl	0x22(%r15), %eax
    53de:      	addq	0x10(%rsp), %rax
    53e3:      	leaq	0x2c(%rsp), %rdi
    53e8:      	movl	$0x4, %ecx
    53ed:      	movl	$0x70, %r8d
    53f3:      	movzbl	0x22(%r15), %edx
    53f8:      	addq	0x10(%rsp), %rdx
    53fd:      	movl	$0x4, %esi
    5402:      	callq	*%r8
    5405:      	testq	%rax, %rax
    5408:      	jne	0xc08 <perf_unwind_ruby+0xc08>
    540e:      	movzbl	0x23(%r15), %ecx
    5413:      	testq	%rcx, %rcx
    5416:      	je	0x551c <perf_unwind_ruby+0x551c>
    541c:      	movq	0x18(%rsp), %rax
    5421:      	subq	0x68(%rsp), %rax
    5426:      	xorl	%edx, %edx
    5428:      	divq	%rcx
    542b:      	movl	0x2c(%rsp), %ecx
    542f:      	cmpq	%rcx, %rax
    5432:      	jbe	0x551c <perf_unwind_ruby+0x551c>
    5438:      	movq	(%rip), %rax            # 0x543f <perf_unwind_ruby+0x543f>
    543f:      	cmpl	$0x0, (%rax)
    5442:      	je	0x562d <perf_unwind_ruby+0x562d>
    5448:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    5452:      	movq	%rax, 0x55(%rsp)
    5457:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    5461:      	movq	%rax, 0x50(%rsp)
    5466:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    5470:      	movq	%rax, 0x48(%rsp)
    5475:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    547f:      	movq	%rax, 0x40(%rsp)
    5484:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    548e:      	movq	%rax, 0x38(%rsp)
    5493:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    549d:      	movq	%rax, 0x30(%rsp)
    54a2:      	leaq	0x30(%rsp), %rdi
    54a7:      	movl	$0x2d, %eax
    54ac:      	movl	$0x6, %ecx
    54b1:      	movl	$0x2d, %esi
    54b6:      	xorl	%eax, %eax
    54b8:      	callq	*%rcx
    54ba:      	jmp	0x562d <perf_unwind_ruby+0x562d>
    54bf:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    54c6:      	jb	0x562d <perf_unwind_ruby+0x562d>
    54cc:      	movq	$0x0, (%rsp)
    54d4:      	movzbl	0x1d(%r15), %eax
    54d9:      	addq	0x8(%rsp), %rax
    54de:      	movq	%rsp, %rdi
    54e1:      	movl	$0x8, %ecx
    54e6:      	movl	$0x70, %r8d
    54ec:      	movzbl	0x1d(%r15), %edx
    54f1:      	addq	0x8(%rsp), %rdx
    54f6:      	movl	$0x8, %esi
    54fb:      	callq	*%r8
    54fe:      	testq	%rax, %rax
    5501:      	jne	0x81b <perf_unwind_ruby+0x81b>
    5507:      	movl	(%rsp), %eax
    550a:      	notl	%eax
    550c:      	testl	$0x140, %eax            # imm = 0x140
    5511:      	jne	0x997 <perf_unwind_ruby+0x997>
    5517:      	jmp	0x562d <perf_unwind_ruby+0x562d>
    551c:      	movl	0x2c0(%r14), %eax
    5523:      	cmpq	$0x7e, %rax
    5527:      	ja	0xdd3 <perf_unwind_ruby+0xdd3>
    552d:      	movq	0x10(%rsp), %rcx
    5532:      	movq	0x18(%rsp), %rdx
    5537:      	leal	0x1(%rax), %esi
    553a:      	movl	%esi, 0x2c0(%r14)
    5541:      	leaq	(%rax,%rax,2), %rax
    5545:      	movw	$0x0, 0x4(%rsp)
    554c:      	movl	$0x0, (%rsp)
    5553:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    555b:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    5563:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    556e:      	movl	(%rsp), %ecx
    5571:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    5579:      	movzwl	0x4(%rsp), %ecx
    557e:      	movw	%cx, 0x2e6(%r14,%rax,8)
    5587:      	movl	$0x36, (%rsp)
    558e:      	movq	(%rip), %rdi            # 0x5595 <perf_unwind_ruby+0x5595>
    5595:      	movq	%rsp, %rsi
    5598:      	movl	$0x1, %eax
    559d:      	callq	*%rax
    559f:      	testq	%rax, %rax
    55a2:      	je	0x55ac <perf_unwind_ruby+0x55ac>
    55a4:      	incq	(%rax)
    55a7:      	jmp	0x562d <perf_unwind_ruby+0x562d>
    55ac:      	movq	(%rip), %rax            # 0x55b3 <perf_unwind_ruby+0x55b3>
    55b3:      	cmpl	$0x0, (%rax)
    55b6:      	je	0x562d <perf_unwind_ruby+0x562d>
    55b8:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    55c2:      	movq	%rax, 0x56(%rsp)
    55c7:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    55d1:      	movq	%rax, 0x50(%rsp)
    55d6:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    55e0:      	movq	%rax, 0x48(%rsp)
    55e5:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    55ef:      	movq	%rax, 0x40(%rsp)
    55f4:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    55fe:      	movq	%rax, 0x38(%rsp)
    5603:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    560d:      	movq	%rax, 0x30(%rsp)
    5612:      	leaq	0x30(%rsp), %rdi
    5617:      	movl	$0x2e, %eax
    561c:      	movl	$0x6, %ecx
    5621:      	movl	(%rsp), %edx
    5624:      	movl	$0x2e, %esi
    5629:      	xorl	%eax, %eax
    562b:      	callq	*%rcx
    562d:      	movq	0x8(%rsp), %rax
    5632:      	cmpq	%rax, %r12
    5635:      	jbe	0x2b2 <perf_unwind_ruby+0x2b2>
    563b:      	movzbl	0x1e(%r15), %ecx
    5640:      	addq	%rcx, %rax
    5643:      	movq	%rax, 0x8(%rsp)
    5648:      	movq	$0x0, 0x18(%rsp)
    5651:      	movq	$0x0, 0x20(%rsp)
    565a:      	movzbl	0x1c(%r15), %ecx
    565f:      	addq	%rax, %rcx
    5662:      	leaq	0x20(%rsp), %rdi
    5667:      	movl	$0x8, %eax
    566c:      	movl	$0x70, %r8d
    5672:      	movzbl	0x1c(%r15), %edx
    5677:      	addq	0x8(%rsp), %rdx
    567c:      	movl	$0x8, %esi
    5681:      	callq	*%r8
    5684:      	movzbl	0x1b(%r15), %eax
    5689:      	addq	0x8(%rsp), %rax
    568e:      	leaq	0x18(%rsp), %rdi
    5693:      	movl	$0x8, %ecx
    5698:      	movl	$0x70, %r8d
    569e:      	movzbl	0x1b(%r15), %edx
    56a3:      	addq	0x8(%rsp), %rdx
    56a8:      	movl	$0x8, %esi
    56ad:      	callq	*%r8
    56b0:      	cmpq	$0x0, 0x18(%rsp)
    56b6:      	je	0x5818 <perf_unwind_ruby+0x5818>
    56bc:      	movq	0x20(%rsp), %rax
    56c1:      	testq	%rax, %rax
    56c4:      	je	0x5818 <perf_unwind_ruby+0x5818>
    56ca:      	movzbl	0x1f(%r15), %ecx
    56cf:      	addq	%rcx, %rax
    56d2:      	leaq	0x10(%rsp), %rdi
    56d7:      	movl	$0x8, %ecx
    56dc:      	movl	$0x70, %r8d
    56e2:      	movzbl	0x1f(%r15), %edx
    56e7:      	addq	0x20(%rsp), %rdx
    56ec:      	movl	$0x8, %esi
    56f1:      	callq	*%r8
    56f4:      	testq	%rax, %rax
    56f7:      	jne	0x4c7 <perf_unwind_ruby+0x4c7>
    56fd:      	movzbl	0x21(%r15), %eax
    5702:      	addq	0x10(%rsp), %rax
    5707:      	leaq	0x68(%rsp), %rdi
    570c:      	movl	$0x8, %ecx
    5711:      	movl	$0x70, %r8d
    5717:      	movzbl	0x21(%r15), %edx
    571c:      	addq	0x10(%rsp), %rdx
    5721:      	movl	$0x8, %esi
    5726:      	callq	*%r8
    5729:      	testq	%rax, %rax
    572c:      	jne	0x8a4 <perf_unwind_ruby+0x8a4>
    5732:      	movzbl	0x22(%r15), %eax
    5737:      	addq	0x10(%rsp), %rax
    573c:      	leaq	0x2c(%rsp), %rdi
    5741:      	movl	$0x4, %ecx
    5746:      	movl	$0x70, %r8d
    574c:      	movzbl	0x22(%r15), %edx
    5751:      	addq	0x10(%rsp), %rdx
    5756:      	movl	$0x4, %esi
    575b:      	callq	*%r8
    575e:      	testq	%rax, %rax
    5761:      	jne	0xc08 <perf_unwind_ruby+0xc08>
    5767:      	movzbl	0x23(%r15), %ecx
    576c:      	testq	%rcx, %rcx
    576f:      	je	0x5875 <perf_unwind_ruby+0x5875>
    5775:      	movq	0x18(%rsp), %rax
    577a:      	subq	0x68(%rsp), %rax
    577f:      	xorl	%edx, %edx
    5781:      	divq	%rcx
    5784:      	movl	0x2c(%rsp), %ecx
    5788:      	cmpq	%rcx, %rax
    578b:      	jbe	0x5875 <perf_unwind_ruby+0x5875>
    5791:      	movq	(%rip), %rax            # 0x5798 <perf_unwind_ruby+0x5798>
    5798:      	cmpl	$0x0, (%rax)
    579b:      	je	0x5986 <perf_unwind_ruby+0x5986>
    57a1:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    57ab:      	movq	%rax, 0x55(%rsp)
    57b0:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    57ba:      	movq	%rax, 0x50(%rsp)
    57bf:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    57c9:      	movq	%rax, 0x48(%rsp)
    57ce:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    57d8:      	movq	%rax, 0x40(%rsp)
    57dd:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    57e7:      	movq	%rax, 0x38(%rsp)
    57ec:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    57f6:      	movq	%rax, 0x30(%rsp)
    57fb:      	leaq	0x30(%rsp), %rdi
    5800:      	movl	$0x2d, %eax
    5805:      	movl	$0x6, %ecx
    580a:      	movl	$0x2d, %esi
    580f:      	xorl	%eax, %eax
    5811:      	callq	*%rcx
    5813:      	jmp	0x5986 <perf_unwind_ruby+0x5986>
    5818:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    581f:      	jb	0x5986 <perf_unwind_ruby+0x5986>
    5825:      	movq	$0x0, (%rsp)
    582d:      	movzbl	0x1d(%r15), %eax
    5832:      	addq	0x8(%rsp), %rax
    5837:      	movq	%rsp, %rdi
    583a:      	movl	$0x8, %ecx
    583f:      	movl	$0x70, %r8d
    5845:      	movzbl	0x1d(%r15), %edx
    584a:      	addq	0x8(%rsp), %rdx
    584f:      	movl	$0x8, %esi
    5854:      	callq	*%r8
    5857:      	testq	%rax, %rax
    585a:      	jne	0x81b <perf_unwind_ruby+0x81b>
    5860:      	movl	(%rsp), %eax
    5863:      	notl	%eax
    5865:      	testl	$0x140, %eax            # imm = 0x140
    586a:      	jne	0x997 <perf_unwind_ruby+0x997>
    5870:      	jmp	0x5986 <perf_unwind_ruby+0x5986>
    5875:      	movl	0x2c0(%r14), %eax
    587c:      	cmpq	$0x7e, %rax
    5880:      	ja	0xdd3 <perf_unwind_ruby+0xdd3>
    5886:      	movq	0x10(%rsp), %rcx
    588b:      	movq	0x18(%rsp), %rdx
    5890:      	leal	0x1(%rax), %esi
    5893:      	movl	%esi, 0x2c0(%r14)
    589a:      	leaq	(%rax,%rax,2), %rax
    589e:      	movw	$0x0, 0x4(%rsp)
    58a5:      	movl	$0x0, (%rsp)
    58ac:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    58b4:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    58bc:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    58c7:      	movl	(%rsp), %ecx
    58ca:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    58d2:      	movzwl	0x4(%rsp), %ecx
    58d7:      	movw	%cx, 0x2e6(%r14,%rax,8)
    58e0:      	movl	$0x36, (%rsp)
    58e7:      	movq	(%rip), %rdi            # 0x58ee <perf_unwind_ruby+0x58ee>
    58ee:      	movq	%rsp, %rsi
    58f1:      	movl	$0x1, %eax
    58f6:      	callq	*%rax
    58f8:      	testq	%rax, %rax
    58fb:      	je	0x5905 <perf_unwind_ruby+0x5905>
    58fd:      	incq	(%rax)
    5900:      	jmp	0x5986 <perf_unwind_ruby+0x5986>
    5905:      	movq	(%rip), %rax            # 0x590c <perf_unwind_ruby+0x590c>
    590c:      	cmpl	$0x0, (%rax)
    590f:      	je	0x5986 <perf_unwind_ruby+0x5986>
    5911:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    591b:      	movq	%rax, 0x56(%rsp)
    5920:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    592a:      	movq	%rax, 0x50(%rsp)
    592f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5939:      	movq	%rax, 0x48(%rsp)
    593e:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5948:      	movq	%rax, 0x40(%rsp)
    594d:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5957:      	movq	%rax, 0x38(%rsp)
    595c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5966:      	movq	%rax, 0x30(%rsp)
    596b:      	leaq	0x30(%rsp), %rdi
    5970:      	movl	$0x2e, %eax
    5975:      	movl	$0x6, %ecx
    597a:      	movl	(%rsp), %edx
    597d:      	movl	$0x2e, %esi
    5982:      	xorl	%eax, %eax
    5984:      	callq	*%rcx
    5986:      	movq	0x8(%rsp), %rax
    598b:      	cmpq	%rax, %r12
    598e:      	jbe	0x2b2 <perf_unwind_ruby+0x2b2>
    5994:      	movzbl	0x1e(%r15), %ecx
    5999:      	addq	%rcx, %rax
    599c:      	movq	%rax, 0x8(%rsp)
    59a1:      	movq	$0x0, 0x18(%rsp)
    59aa:      	movq	$0x0, 0x20(%rsp)
    59b3:      	movzbl	0x1c(%r15), %ecx
    59b8:      	addq	%rax, %rcx
    59bb:      	leaq	0x20(%rsp), %rdi
    59c0:      	movl	$0x8, %eax
    59c5:      	movl	$0x70, %r8d
    59cb:      	movzbl	0x1c(%r15), %edx
    59d0:      	addq	0x8(%rsp), %rdx
    59d5:      	movl	$0x8, %esi
    59da:      	callq	*%r8
    59dd:      	movzbl	0x1b(%r15), %eax
    59e2:      	addq	0x8(%rsp), %rax
    59e7:      	leaq	0x18(%rsp), %rdi
    59ec:      	movl	$0x8, %ecx
    59f1:      	movl	$0x70, %r8d
    59f7:      	movzbl	0x1b(%r15), %edx
    59fc:      	addq	0x8(%rsp), %rdx
    5a01:      	movl	$0x8, %esi
    5a06:      	callq	*%r8
    5a09:      	cmpq	$0x0, 0x18(%rsp)
    5a0f:      	je	0x5b71 <perf_unwind_ruby+0x5b71>
    5a15:      	movq	0x20(%rsp), %rax
    5a1a:      	testq	%rax, %rax
    5a1d:      	je	0x5b71 <perf_unwind_ruby+0x5b71>
    5a23:      	movzbl	0x1f(%r15), %ecx
    5a28:      	addq	%rcx, %rax
    5a2b:      	leaq	0x10(%rsp), %rdi
    5a30:      	movl	$0x8, %ecx
    5a35:      	movl	$0x70, %r8d
    5a3b:      	movzbl	0x1f(%r15), %edx
    5a40:      	addq	0x20(%rsp), %rdx
    5a45:      	movl	$0x8, %esi
    5a4a:      	callq	*%r8
    5a4d:      	testq	%rax, %rax
    5a50:      	jne	0x4c7 <perf_unwind_ruby+0x4c7>
    5a56:      	movzbl	0x21(%r15), %eax
    5a5b:      	addq	0x10(%rsp), %rax
    5a60:      	leaq	0x68(%rsp), %rdi
    5a65:      	movl	$0x8, %ecx
    5a6a:      	movl	$0x70, %r8d
    5a70:      	movzbl	0x21(%r15), %edx
    5a75:      	addq	0x10(%rsp), %rdx
    5a7a:      	movl	$0x8, %esi
    5a7f:      	callq	*%r8
    5a82:      	testq	%rax, %rax
    5a85:      	jne	0x8a4 <perf_unwind_ruby+0x8a4>
    5a8b:      	movzbl	0x22(%r15), %eax
    5a90:      	addq	0x10(%rsp), %rax
    5a95:      	leaq	0x2c(%rsp), %rdi
    5a9a:      	movl	$0x4, %ecx
    5a9f:      	movl	$0x70, %r8d
    5aa5:      	movzbl	0x22(%r15), %edx
    5aaa:      	addq	0x10(%rsp), %rdx
    5aaf:      	movl	$0x4, %esi
    5ab4:      	callq	*%r8
    5ab7:      	testq	%rax, %rax
    5aba:      	jne	0xc08 <perf_unwind_ruby+0xc08>
    5ac0:      	movzbl	0x23(%r15), %ecx
    5ac5:      	testq	%rcx, %rcx
    5ac8:      	je	0x5bce <perf_unwind_ruby+0x5bce>
    5ace:      	movq	0x18(%rsp), %rax
    5ad3:      	subq	0x68(%rsp), %rax
    5ad8:      	xorl	%edx, %edx
    5ada:      	divq	%rcx
    5add:      	movl	0x2c(%rsp), %ecx
    5ae1:      	cmpq	%rcx, %rax
    5ae4:      	jbe	0x5bce <perf_unwind_ruby+0x5bce>
    5aea:      	movq	(%rip), %rax            # 0x5af1 <perf_unwind_ruby+0x5af1>
    5af1:      	cmpl	$0x0, (%rax)
    5af4:      	je	0x5cdf <perf_unwind_ruby+0x5cdf>
    5afa:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    5b04:      	movq	%rax, 0x55(%rsp)
    5b09:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    5b13:      	movq	%rax, 0x50(%rsp)
    5b18:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    5b22:      	movq	%rax, 0x48(%rsp)
    5b27:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    5b31:      	movq	%rax, 0x40(%rsp)
    5b36:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    5b40:      	movq	%rax, 0x38(%rsp)
    5b45:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    5b4f:      	movq	%rax, 0x30(%rsp)
    5b54:      	leaq	0x30(%rsp), %rdi
    5b59:      	movl	$0x2d, %eax
    5b5e:      	movl	$0x6, %ecx
    5b63:      	movl	$0x2d, %esi
    5b68:      	xorl	%eax, %eax
    5b6a:      	callq	*%rcx
    5b6c:      	jmp	0x5cdf <perf_unwind_ruby+0x5cdf>
    5b71:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    5b78:      	jb	0x5cdf <perf_unwind_ruby+0x5cdf>
    5b7e:      	movq	$0x0, (%rsp)
    5b86:      	movzbl	0x1d(%r15), %eax
    5b8b:      	addq	0x8(%rsp), %rax
    5b90:      	movq	%rsp, %rdi
    5b93:      	movl	$0x8, %ecx
    5b98:      	movl	$0x70, %r8d
    5b9e:      	movzbl	0x1d(%r15), %edx
    5ba3:      	addq	0x8(%rsp), %rdx
    5ba8:      	movl	$0x8, %esi
    5bad:      	callq	*%r8
    5bb0:      	testq	%rax, %rax
    5bb3:      	jne	0x81b <perf_unwind_ruby+0x81b>
    5bb9:      	movl	(%rsp), %eax
    5bbc:      	notl	%eax
    5bbe:      	testl	$0x140, %eax            # imm = 0x140
    5bc3:      	jne	0x997 <perf_unwind_ruby+0x997>
    5bc9:      	jmp	0x5cdf <perf_unwind_ruby+0x5cdf>
    5bce:      	movl	0x2c0(%r14), %eax
    5bd5:      	cmpq	$0x7e, %rax
    5bd9:      	ja	0xdd3 <perf_unwind_ruby+0xdd3>
    5bdf:      	movq	0x10(%rsp), %rcx
    5be4:      	movq	0x18(%rsp), %rdx
    5be9:      	leal	0x1(%rax), %esi
    5bec:      	movl	%esi, 0x2c0(%r14)
    5bf3:      	leaq	(%rax,%rax,2), %rax
    5bf7:      	movw	$0x0, 0x4(%rsp)
    5bfe:      	movl	$0x0, (%rsp)
    5c05:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    5c0d:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    5c15:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    5c20:      	movl	(%rsp), %ecx
    5c23:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    5c2b:      	movzwl	0x4(%rsp), %ecx
    5c30:      	movw	%cx, 0x2e6(%r14,%rax,8)
    5c39:      	movl	$0x36, (%rsp)
    5c40:      	movq	(%rip), %rdi            # 0x5c47 <perf_unwind_ruby+0x5c47>
    5c47:      	movq	%rsp, %rsi
    5c4a:      	movl	$0x1, %eax
    5c4f:      	callq	*%rax
    5c51:      	testq	%rax, %rax
    5c54:      	je	0x5c5e <perf_unwind_ruby+0x5c5e>
    5c56:      	incq	(%rax)
    5c59:      	jmp	0x5cdf <perf_unwind_ruby+0x5cdf>
    5c5e:      	movq	(%rip), %rax            # 0x5c65 <perf_unwind_ruby+0x5c65>
    5c65:      	cmpl	$0x0, (%rax)
    5c68:      	je	0x5cdf <perf_unwind_ruby+0x5cdf>
    5c6a:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5c74:      	movq	%rax, 0x56(%rsp)
    5c79:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5c83:      	movq	%rax, 0x50(%rsp)
    5c88:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5c92:      	movq	%rax, 0x48(%rsp)
    5c97:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5ca1:      	movq	%rax, 0x40(%rsp)
    5ca6:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5cb0:      	movq	%rax, 0x38(%rsp)
    5cb5:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5cbf:      	movq	%rax, 0x30(%rsp)
    5cc4:      	leaq	0x30(%rsp), %rdi
    5cc9:      	movl	$0x2e, %eax
    5cce:      	movl	$0x6, %ecx
    5cd3:      	movl	(%rsp), %edx
    5cd6:      	movl	$0x2e, %esi
    5cdb:      	xorl	%eax, %eax
    5cdd:      	callq	*%rcx
    5cdf:      	movq	0x8(%rsp), %rax
    5ce4:      	cmpq	%rax, %r12
    5ce7:      	jbe	0x2b2 <perf_unwind_ruby+0x2b2>
    5ced:      	movzbl	0x1e(%r15), %ecx
    5cf2:      	addq	%rcx, %rax
    5cf5:      	movq	%rax, 0x8(%rsp)
    5cfa:      	movq	$0x0, 0x18(%rsp)
    5d03:      	movq	$0x0, 0x20(%rsp)
    5d0c:      	movzbl	0x1c(%r15), %ecx
    5d11:      	addq	%rax, %rcx
    5d14:      	leaq	0x20(%rsp), %rdi
    5d19:      	movl	$0x8, %eax
    5d1e:      	movl	$0x70, %r8d
    5d24:      	movzbl	0x1c(%r15), %edx
    5d29:      	addq	0x8(%rsp), %rdx
    5d2e:      	movl	$0x8, %esi
    5d33:      	callq	*%r8
    5d36:      	movzbl	0x1b(%r15), %eax
    5d3b:      	addq	0x8(%rsp), %rax
    5d40:      	leaq	0x18(%rsp), %rdi
    5d45:      	movl	$0x8, %ecx
    5d4a:      	movl	$0x70, %r8d
    5d50:      	movzbl	0x1b(%r15), %edx
    5d55:      	addq	0x8(%rsp), %rdx
    5d5a:      	movl	$0x8, %esi
    5d5f:      	callq	*%r8
    5d62:      	cmpq	$0x0, 0x18(%rsp)
    5d68:      	je	0x5eca <perf_unwind_ruby+0x5eca>
    5d6e:      	movq	0x20(%rsp), %rax
    5d73:      	testq	%rax, %rax
    5d76:      	je	0x5eca <perf_unwind_ruby+0x5eca>
    5d7c:      	movzbl	0x1f(%r15), %ecx
    5d81:      	addq	%rcx, %rax
    5d84:      	leaq	0x10(%rsp), %rdi
    5d89:      	movl	$0x8, %ecx
    5d8e:      	movl	$0x70, %r8d
    5d94:      	movzbl	0x1f(%r15), %edx
    5d99:      	addq	0x20(%rsp), %rdx
    5d9e:      	movl	$0x8, %esi
    5da3:      	callq	*%r8
    5da6:      	testq	%rax, %rax
    5da9:      	jne	0x4c7 <perf_unwind_ruby+0x4c7>
    5daf:      	movzbl	0x21(%r15), %eax
    5db4:      	addq	0x10(%rsp), %rax
    5db9:      	leaq	0x68(%rsp), %rdi
    5dbe:      	movl	$0x8, %ecx
    5dc3:      	movl	$0x70, %r8d
    5dc9:      	movzbl	0x21(%r15), %edx
    5dce:      	addq	0x10(%rsp), %rdx
    5dd3:      	movl	$0x8, %esi
    5dd8:      	callq	*%r8
    5ddb:      	testq	%rax, %rax
    5dde:      	jne	0x8a4 <perf_unwind_ruby+0x8a4>
    5de4:      	movzbl	0x22(%r15), %eax
    5de9:      	addq	0x10(%rsp), %rax
    5dee:      	leaq	0x2c(%rsp), %rdi
    5df3:      	movl	$0x4, %ecx
    5df8:      	movl	$0x70, %r8d
    5dfe:      	movzbl	0x22(%r15), %edx
    5e03:      	addq	0x10(%rsp), %rdx
    5e08:      	movl	$0x4, %esi
    5e0d:      	callq	*%r8
    5e10:      	testq	%rax, %rax
    5e13:      	jne	0xc08 <perf_unwind_ruby+0xc08>
    5e19:      	movzbl	0x23(%r15), %ecx
    5e1e:      	testq	%rcx, %rcx
    5e21:      	je	0x5f27 <perf_unwind_ruby+0x5f27>
    5e27:      	movq	0x18(%rsp), %rax
    5e2c:      	subq	0x68(%rsp), %rax
    5e31:      	xorl	%edx, %edx
    5e33:      	divq	%rcx
    5e36:      	movl	0x2c(%rsp), %ecx
    5e3a:      	cmpq	%rcx, %rax
    5e3d:      	jbe	0x5f27 <perf_unwind_ruby+0x5f27>
    5e43:      	movq	(%rip), %rax            # 0x5e4a <perf_unwind_ruby+0x5e4a>
    5e4a:      	cmpl	$0x0, (%rax)
    5e4d:      	je	0x6038 <perf_unwind_ruby+0x6038>
    5e53:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    5e5d:      	movq	%rax, 0x55(%rsp)
    5e62:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    5e6c:      	movq	%rax, 0x50(%rsp)
    5e71:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    5e7b:      	movq	%rax, 0x48(%rsp)
    5e80:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    5e8a:      	movq	%rax, 0x40(%rsp)
    5e8f:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    5e99:      	movq	%rax, 0x38(%rsp)
    5e9e:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    5ea8:      	movq	%rax, 0x30(%rsp)
    5ead:      	leaq	0x30(%rsp), %rdi
    5eb2:      	movl	$0x2d, %eax
    5eb7:      	movl	$0x6, %ecx
    5ebc:      	movl	$0x2d, %esi
    5ec1:      	xorl	%eax, %eax
    5ec3:      	callq	*%rcx
    5ec5:      	jmp	0x6038 <perf_unwind_ruby+0x6038>
    5eca:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    5ed1:      	jb	0x6038 <perf_unwind_ruby+0x6038>
    5ed7:      	movq	$0x0, (%rsp)
    5edf:      	movzbl	0x1d(%r15), %eax
    5ee4:      	addq	0x8(%rsp), %rax
    5ee9:      	movq	%rsp, %rdi
    5eec:      	movl	$0x8, %ecx
    5ef1:      	movl	$0x70, %r8d
    5ef7:      	movzbl	0x1d(%r15), %edx
    5efc:      	addq	0x8(%rsp), %rdx
    5f01:      	movl	$0x8, %esi
    5f06:      	callq	*%r8
    5f09:      	testq	%rax, %rax
    5f0c:      	jne	0x81b <perf_unwind_ruby+0x81b>
    5f12:      	movl	(%rsp), %eax
    5f15:      	notl	%eax
    5f17:      	testl	$0x140, %eax            # imm = 0x140
    5f1c:      	jne	0x997 <perf_unwind_ruby+0x997>
    5f22:      	jmp	0x6038 <perf_unwind_ruby+0x6038>
    5f27:      	movl	0x2c0(%r14), %eax
    5f2e:      	cmpq	$0x7e, %rax
    5f32:      	ja	0xdd3 <perf_unwind_ruby+0xdd3>
    5f38:      	movq	0x10(%rsp), %rcx
    5f3d:      	movq	0x18(%rsp), %rdx
    5f42:      	leal	0x1(%rax), %esi
    5f45:      	movl	%esi, 0x2c0(%r14)
    5f4c:      	leaq	(%rax,%rax,2), %rax
    5f50:      	movw	$0x0, 0x4(%rsp)
    5f57:      	movl	$0x0, (%rsp)
    5f5e:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    5f66:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    5f6e:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    5f79:      	movl	(%rsp), %ecx
    5f7c:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    5f84:      	movzwl	0x4(%rsp), %ecx
    5f89:      	movw	%cx, 0x2e6(%r14,%rax,8)
    5f92:      	movl	$0x36, (%rsp)
    5f99:      	movq	(%rip), %rdi            # 0x5fa0 <perf_unwind_ruby+0x5fa0>
    5fa0:      	movq	%rsp, %rsi
    5fa3:      	movl	$0x1, %eax
    5fa8:      	callq	*%rax
    5faa:      	testq	%rax, %rax
    5fad:      	je	0x5fb7 <perf_unwind_ruby+0x5fb7>
    5faf:      	incq	(%rax)
    5fb2:      	jmp	0x6038 <perf_unwind_ruby+0x6038>
    5fb7:      	movq	(%rip), %rax            # 0x5fbe <perf_unwind_ruby+0x5fbe>
    5fbe:      	cmpl	$0x0, (%rax)
    5fc1:      	je	0x6038 <perf_unwind_ruby+0x6038>
    5fc3:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5fcd:      	movq	%rax, 0x56(%rsp)
    5fd2:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5fdc:      	movq	%rax, 0x50(%rsp)
    5fe1:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5feb:      	movq	%rax, 0x48(%rsp)
    5ff0:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5ffa:      	movq	%rax, 0x40(%rsp)
    5fff:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    6009:      	movq	%rax, 0x38(%rsp)
    600e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6018:      	movq	%rax, 0x30(%rsp)
    601d:      	leaq	0x30(%rsp), %rdi
    6022:      	movl	$0x2e, %eax
    6027:      	movl	$0x6, %ecx
    602c:      	movl	(%rsp), %edx
    602f:      	movl	$0x2e, %esi
    6034:      	xorl	%eax, %eax
    6036:      	callq	*%rcx
    6038:      	movq	0x8(%rsp), %rax
    603d:      	cmpq	%rax, %r12
    6040:      	jbe	0x2b2 <perf_unwind_ruby+0x2b2>
    6046:      	movzbl	0x1e(%r15), %ecx
    604b:      	addq	%rcx, %rax
    604e:      	movq	%rax, 0x8(%rsp)
    6053:      	movq	$0x0, 0x18(%rsp)
    605c:      	movq	$0x0, 0x20(%rsp)
    6065:      	movzbl	0x1c(%r15), %ecx
    606a:      	addq	%rax, %rcx
    606d:      	leaq	0x20(%rsp), %rdi
    6072:      	movl	$0x8, %eax
    6077:      	movl	$0x70, %r8d
    607d:      	movzbl	0x1c(%r15), %edx
    6082:      	addq	0x8(%rsp), %rdx
    6087:      	movl	$0x8, %esi
    608c:      	callq	*%r8
    608f:      	movzbl	0x1b(%r15), %eax
    6094:      	addq	0x8(%rsp), %rax
    6099:      	leaq	0x18(%rsp), %rdi
    609e:      	movl	$0x8, %ecx
    60a3:      	movl	$0x70, %r8d
    60a9:      	movzbl	0x1b(%r15), %edx
    60ae:      	addq	0x8(%rsp), %rdx
    60b3:      	movl	$0x8, %esi
    60b8:      	callq	*%r8
    60bb:      	cmpq	$0x0, 0x18(%rsp)
    60c1:      	je	0x6223 <perf_unwind_ruby+0x6223>
    60c7:      	movq	0x20(%rsp), %rax
    60cc:      	testq	%rax, %rax
    60cf:      	je	0x6223 <perf_unwind_ruby+0x6223>
    60d5:      	movzbl	0x1f(%r15), %ecx
    60da:      	addq	%rcx, %rax
    60dd:      	leaq	0x10(%rsp), %rdi
    60e2:      	movl	$0x8, %ecx
    60e7:      	movl	$0x70, %r8d
    60ed:      	movzbl	0x1f(%r15), %edx
    60f2:      	addq	0x20(%rsp), %rdx
    60f7:      	movl	$0x8, %esi
    60fc:      	callq	*%r8
    60ff:      	testq	%rax, %rax
    6102:      	jne	0x4c7 <perf_unwind_ruby+0x4c7>
    6108:      	movzbl	0x21(%r15), %eax
    610d:      	addq	0x10(%rsp), %rax
    6112:      	leaq	0x68(%rsp), %rdi
    6117:      	movl	$0x8, %ecx
    611c:      	movl	$0x70, %r8d
    6122:      	movzbl	0x21(%r15), %edx
    6127:      	addq	0x10(%rsp), %rdx
    612c:      	movl	$0x8, %esi
    6131:      	callq	*%r8
    6134:      	testq	%rax, %rax
    6137:      	jne	0x8a4 <perf_unwind_ruby+0x8a4>
    613d:      	movzbl	0x22(%r15), %eax
    6142:      	addq	0x10(%rsp), %rax
    6147:      	leaq	0x2c(%rsp), %rdi
    614c:      	movl	$0x4, %ecx
    6151:      	movl	$0x70, %r8d
    6157:      	movzbl	0x22(%r15), %edx
    615c:      	addq	0x10(%rsp), %rdx
    6161:      	movl	$0x4, %esi
    6166:      	callq	*%r8
    6169:      	testq	%rax, %rax
    616c:      	jne	0xc08 <perf_unwind_ruby+0xc08>
    6172:      	movzbl	0x23(%r15), %ecx
    6177:      	testq	%rcx, %rcx
    617a:      	je	0x6280 <perf_unwind_ruby+0x6280>
    6180:      	movq	0x18(%rsp), %rax
    6185:      	subq	0x68(%rsp), %rax
    618a:      	xorl	%edx, %edx
    618c:      	divq	%rcx
    618f:      	movl	0x2c(%rsp), %ecx
    6193:      	cmpq	%rcx, %rax
    6196:      	jbe	0x6280 <perf_unwind_ruby+0x6280>
    619c:      	movq	(%rip), %rax            # 0x61a3 <perf_unwind_ruby+0x61a3>
    61a3:      	cmpl	$0x0, (%rax)
    61a6:      	je	0x6391 <perf_unwind_ruby+0x6391>
    61ac:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    61b6:      	movq	%rax, 0x55(%rsp)
    61bb:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    61c5:      	movq	%rax, 0x50(%rsp)
    61ca:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    61d4:      	movq	%rax, 0x48(%rsp)
    61d9:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    61e3:      	movq	%rax, 0x40(%rsp)
    61e8:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    61f2:      	movq	%rax, 0x38(%rsp)
    61f7:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    6201:      	movq	%rax, 0x30(%rsp)
    6206:      	leaq	0x30(%rsp), %rdi
    620b:      	movl	$0x2d, %eax
    6210:      	movl	$0x6, %ecx
    6215:      	movl	$0x2d, %esi
    621a:      	xorl	%eax, %eax
    621c:      	callq	*%rcx
    621e:      	jmp	0x6391 <perf_unwind_ruby+0x6391>
    6223:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    622a:      	jb	0x6391 <perf_unwind_ruby+0x6391>
    6230:      	movq	$0x0, (%rsp)
    6238:      	movzbl	0x1d(%r15), %eax
    623d:      	addq	0x8(%rsp), %rax
    6242:      	movq	%rsp, %rdi
    6245:      	movl	$0x8, %ecx
    624a:      	movl	$0x70, %r8d
    6250:      	movzbl	0x1d(%r15), %edx
    6255:      	addq	0x8(%rsp), %rdx
    625a:      	movl	$0x8, %esi
    625f:      	callq	*%r8
    6262:      	testq	%rax, %rax
    6265:      	jne	0x81b <perf_unwind_ruby+0x81b>
    626b:      	movl	(%rsp), %eax
    626e:      	notl	%eax
    6270:      	testl	$0x140, %eax            # imm = 0x140
    6275:      	jne	0x997 <perf_unwind_ruby+0x997>
    627b:      	jmp	0x6391 <perf_unwind_ruby+0x6391>
    6280:      	movl	0x2c0(%r14), %eax
    6287:      	cmpq	$0x7e, %rax
    628b:      	ja	0xdd3 <perf_unwind_ruby+0xdd3>
    6291:      	movq	0x10(%rsp), %rcx
    6296:      	movq	0x18(%rsp), %rdx
    629b:      	leal	0x1(%rax), %esi
    629e:      	movl	%esi, 0x2c0(%r14)
    62a5:      	leaq	(%rax,%rax,2), %rax
    62a9:      	movw	$0x0, 0x4(%rsp)
    62b0:      	movl	$0x0, (%rsp)
    62b7:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    62bf:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    62c7:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    62d2:      	movl	(%rsp), %ecx
    62d5:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    62dd:      	movzwl	0x4(%rsp), %ecx
    62e2:      	movw	%cx, 0x2e6(%r14,%rax,8)
    62eb:      	movl	$0x36, (%rsp)
    62f2:      	movq	(%rip), %rdi            # 0x62f9 <perf_unwind_ruby+0x62f9>
    62f9:      	movq	%rsp, %rsi
    62fc:      	movl	$0x1, %eax
    6301:      	callq	*%rax
    6303:      	testq	%rax, %rax
    6306:      	je	0x6310 <perf_unwind_ruby+0x6310>
    6308:      	incq	(%rax)
    630b:      	jmp	0x6391 <perf_unwind_ruby+0x6391>
    6310:      	movq	(%rip), %rax            # 0x6317 <perf_unwind_ruby+0x6317>
    6317:      	cmpl	$0x0, (%rax)
    631a:      	je	0x6391 <perf_unwind_ruby+0x6391>
    631c:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    6326:      	movq	%rax, 0x56(%rsp)
    632b:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    6335:      	movq	%rax, 0x50(%rsp)
    633a:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    6344:      	movq	%rax, 0x48(%rsp)
    6349:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    6353:      	movq	%rax, 0x40(%rsp)
    6358:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    6362:      	movq	%rax, 0x38(%rsp)
    6367:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6371:      	movq	%rax, 0x30(%rsp)
    6376:      	leaq	0x30(%rsp), %rdi
    637b:      	movl	$0x2e, %eax
    6380:      	movl	$0x6, %ecx
    6385:      	movl	(%rsp), %edx
    6388:      	movl	$0x2e, %esi
    638d:      	xorl	%eax, %eax
    638f:      	callq	*%rcx
    6391:      	movq	0x8(%rsp), %rax
    6396:      	cmpq	%rax, %r12
    6399:      	jbe	0x2b2 <perf_unwind_ruby+0x2b2>
    639f:      	movzbl	0x1e(%r15), %ecx
    63a4:      	addq	%rcx, %rax
    63a7:      	movq	%rax, 0x8(%rsp)
    63ac:      	movq	$0x0, 0x18(%rsp)
    63b5:      	movq	$0x0, 0x20(%rsp)
    63be:      	movzbl	0x1c(%r15), %ecx
    63c3:      	addq	%rax, %rcx
    63c6:      	leaq	0x20(%rsp), %rdi
    63cb:      	movl	$0x8, %eax
    63d0:      	movl	$0x70, %r8d
    63d6:      	movzbl	0x1c(%r15), %edx
    63db:      	addq	0x8(%rsp), %rdx
    63e0:      	movl	$0x8, %esi
    63e5:      	callq	*%r8
    63e8:      	movzbl	0x1b(%r15), %eax
    63ed:      	addq	0x8(%rsp), %rax
    63f2:      	leaq	0x18(%rsp), %rdi
    63f7:      	movl	$0x8, %ecx
    63fc:      	movl	$0x70, %r8d
    6402:      	movzbl	0x1b(%r15), %edx
    6407:      	addq	0x8(%rsp), %rdx
    640c:      	movl	$0x8, %esi
    6411:      	callq	*%r8
    6414:      	cmpq	$0x0, 0x18(%rsp)
    641a:      	je	0x657c <perf_unwind_ruby+0x657c>
    6420:      	movq	0x20(%rsp), %rax
    6425:      	testq	%rax, %rax
    6428:      	je	0x657c <perf_unwind_ruby+0x657c>
    642e:      	movzbl	0x1f(%r15), %ecx
    6433:      	addq	%rcx, %rax
    6436:      	leaq	0x10(%rsp), %rdi
    643b:      	movl	$0x8, %ecx
    6440:      	movl	$0x70, %r8d
    6446:      	movzbl	0x1f(%r15), %edx
    644b:      	addq	0x20(%rsp), %rdx
    6450:      	movl	$0x8, %esi
    6455:      	callq	*%r8
    6458:      	testq	%rax, %rax
    645b:      	jne	0x4c7 <perf_unwind_ruby+0x4c7>
    6461:      	movzbl	0x21(%r15), %eax
    6466:      	addq	0x10(%rsp), %rax
    646b:      	leaq	0x68(%rsp), %rdi
    6470:      	movl	$0x8, %ecx
    6475:      	movl	$0x70, %r8d
    647b:      	movzbl	0x21(%r15), %edx
    6480:      	addq	0x10(%rsp), %rdx
    6485:      	movl	$0x8, %esi
    648a:      	callq	*%r8
    648d:      	testq	%rax, %rax
    6490:      	jne	0x8a4 <perf_unwind_ruby+0x8a4>
    6496:      	movzbl	0x22(%r15), %eax
    649b:      	addq	0x10(%rsp), %rax
    64a0:      	leaq	0x2c(%rsp), %rdi
    64a5:      	movl	$0x4, %ecx
    64aa:      	movl	$0x70, %r8d
    64b0:      	movzbl	0x22(%r15), %edx
    64b5:      	addq	0x10(%rsp), %rdx
    64ba:      	movl	$0x4, %esi
    64bf:      	callq	*%r8
    64c2:      	testq	%rax, %rax
    64c5:      	jne	0xc08 <perf_unwind_ruby+0xc08>
    64cb:      	movzbl	0x23(%r15), %ecx
    64d0:      	testq	%rcx, %rcx
    64d3:      	je	0x65d9 <perf_unwind_ruby+0x65d9>
    64d9:      	movq	0x18(%rsp), %rax
    64de:      	subq	0x68(%rsp), %rax
    64e3:      	xorl	%edx, %edx
    64e5:      	divq	%rcx
    64e8:      	movl	0x2c(%rsp), %ecx
    64ec:      	cmpq	%rcx, %rax
    64ef:      	jbe	0x65d9 <perf_unwind_ruby+0x65d9>
    64f5:      	movq	(%rip), %rax            # 0x64fc <perf_unwind_ruby+0x64fc>
    64fc:      	cmpl	$0x0, (%rax)
    64ff:      	je	0x66ea <perf_unwind_ruby+0x66ea>
    6505:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    650f:      	movq	%rax, 0x55(%rsp)
    6514:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    651e:      	movq	%rax, 0x50(%rsp)
    6523:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    652d:      	movq	%rax, 0x48(%rsp)
    6532:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    653c:      	movq	%rax, 0x40(%rsp)
    6541:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    654b:      	movq	%rax, 0x38(%rsp)
    6550:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    655a:      	movq	%rax, 0x30(%rsp)
    655f:      	leaq	0x30(%rsp), %rdi
    6564:      	movl	$0x2d, %eax
    6569:      	movl	$0x6, %ecx
    656e:      	movl	$0x2d, %esi
    6573:      	xorl	%eax, %eax
    6575:      	callq	*%rcx
    6577:      	jmp	0x66ea <perf_unwind_ruby+0x66ea>
    657c:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    6583:      	jb	0x66ea <perf_unwind_ruby+0x66ea>
    6589:      	movq	$0x0, (%rsp)
    6591:      	movzbl	0x1d(%r15), %eax
    6596:      	addq	0x8(%rsp), %rax
    659b:      	movq	%rsp, %rdi
    659e:      	movl	$0x8, %ecx
    65a3:      	movl	$0x70, %r8d
    65a9:      	movzbl	0x1d(%r15), %edx
    65ae:      	addq	0x8(%rsp), %rdx
    65b3:      	movl	$0x8, %esi
    65b8:      	callq	*%r8
    65bb:      	testq	%rax, %rax
    65be:      	jne	0x81b <perf_unwind_ruby+0x81b>
    65c4:      	movl	(%rsp), %eax
    65c7:      	notl	%eax
    65c9:      	testl	$0x140, %eax            # imm = 0x140
    65ce:      	jne	0x997 <perf_unwind_ruby+0x997>
    65d4:      	jmp	0x66ea <perf_unwind_ruby+0x66ea>
    65d9:      	movl	0x2c0(%r14), %eax
    65e0:      	cmpq	$0x7e, %rax
    65e4:      	ja	0xdd3 <perf_unwind_ruby+0xdd3>
    65ea:      	movq	0x10(%rsp), %rcx
    65ef:      	movq	0x18(%rsp), %rdx
    65f4:      	leal	0x1(%rax), %esi
    65f7:      	movl	%esi, 0x2c0(%r14)
    65fe:      	leaq	(%rax,%rax,2), %rax
    6602:      	movw	$0x0, 0x4(%rsp)
    6609:      	movl	$0x0, (%rsp)
    6610:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    6618:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    6620:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    662b:      	movl	(%rsp), %ecx
    662e:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    6636:      	movzwl	0x4(%rsp), %ecx
    663b:      	movw	%cx, 0x2e6(%r14,%rax,8)
    6644:      	movl	$0x36, (%rsp)
    664b:      	movq	(%rip), %rdi            # 0x6652 <perf_unwind_ruby+0x6652>
    6652:      	movq	%rsp, %rsi
    6655:      	movl	$0x1, %eax
    665a:      	callq	*%rax
    665c:      	testq	%rax, %rax
    665f:      	je	0x6669 <perf_unwind_ruby+0x6669>
    6661:      	incq	(%rax)
    6664:      	jmp	0x66ea <perf_unwind_ruby+0x66ea>
    6669:      	movq	(%rip), %rax            # 0x6670 <perf_unwind_ruby+0x6670>
    6670:      	cmpl	$0x0, (%rax)
    6673:      	je	0x66ea <perf_unwind_ruby+0x66ea>
    6675:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    667f:      	movq	%rax, 0x56(%rsp)
    6684:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    668e:      	movq	%rax, 0x50(%rsp)
    6693:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    669d:      	movq	%rax, 0x48(%rsp)
    66a2:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    66ac:      	movq	%rax, 0x40(%rsp)
    66b1:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    66bb:      	movq	%rax, 0x38(%rsp)
    66c0:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    66ca:      	movq	%rax, 0x30(%rsp)
    66cf:      	leaq	0x30(%rsp), %rdi
    66d4:      	movl	$0x2e, %eax
    66d9:      	movl	$0x6, %ecx
    66de:      	movl	(%rsp), %edx
    66e1:      	movl	$0x2e, %esi
    66e6:      	xorl	%eax, %eax
    66e8:      	callq	*%rcx
    66ea:      	movq	0x8(%rsp), %rax
    66ef:      	cmpq	%rax, %r12
    66f2:      	jbe	0x2b2 <perf_unwind_ruby+0x2b2>
    66f8:      	movzbl	0x1e(%r15), %ecx
    66fd:      	addq	%rcx, %rax
    6700:      	movq	%rax, 0x8(%rsp)
    6705:      	movq	$0x0, 0x18(%rsp)
    670e:      	movq	$0x0, 0x20(%rsp)
    6717:      	movzbl	0x1c(%r15), %ecx
    671c:      	addq	%rax, %rcx
    671f:      	leaq	0x20(%rsp), %rdi
    6724:      	movl	$0x8, %eax
    6729:      	movl	$0x70, %r8d
    672f:      	movzbl	0x1c(%r15), %edx
    6734:      	addq	0x8(%rsp), %rdx
    6739:      	movl	$0x8, %esi
    673e:      	callq	*%r8
    6741:      	movzbl	0x1b(%r15), %eax
    6746:      	addq	0x8(%rsp), %rax
    674b:      	leaq	0x18(%rsp), %rdi
    6750:      	movl	$0x8, %ecx
    6755:      	movl	$0x70, %r8d
    675b:      	movzbl	0x1b(%r15), %edx
    6760:      	addq	0x8(%rsp), %rdx
    6765:      	movl	$0x8, %esi
    676a:      	callq	*%r8
    676d:      	cmpq	$0x0, 0x18(%rsp)
    6773:      	je	0x68d5 <perf_unwind_ruby+0x68d5>
    6779:      	movq	0x20(%rsp), %rax
    677e:      	testq	%rax, %rax
    6781:      	je	0x68d5 <perf_unwind_ruby+0x68d5>
    6787:      	movzbl	0x1f(%r15), %ecx
    678c:      	addq	%rcx, %rax
    678f:      	leaq	0x10(%rsp), %rdi
    6794:      	movl	$0x8, %ecx
    6799:      	movl	$0x70, %r8d
    679f:      	movzbl	0x1f(%r15), %edx
    67a4:      	addq	0x20(%rsp), %rdx
    67a9:      	movl	$0x8, %esi
    67ae:      	callq	*%r8
    67b1:      	testq	%rax, %rax
    67b4:      	jne	0x4c7 <perf_unwind_ruby+0x4c7>
    67ba:      	movzbl	0x21(%r15), %eax
    67bf:      	addq	0x10(%rsp), %rax
    67c4:      	leaq	0x68(%rsp), %rdi
    67c9:      	movl	$0x8, %ecx
    67ce:      	movl	$0x70, %r8d
    67d4:      	movzbl	0x21(%r15), %edx
    67d9:      	addq	0x10(%rsp), %rdx
    67de:      	movl	$0x8, %esi
    67e3:      	callq	*%r8
    67e6:      	testq	%rax, %rax
    67e9:      	jne	0x8a4 <perf_unwind_ruby+0x8a4>
    67ef:      	movzbl	0x22(%r15), %eax
    67f4:      	addq	0x10(%rsp), %rax
    67f9:      	leaq	0x2c(%rsp), %rdi
    67fe:      	movl	$0x4, %ecx
    6803:      	movl	$0x70, %r8d
    6809:      	movzbl	0x22(%r15), %edx
    680e:      	addq	0x10(%rsp), %rdx
    6813:      	movl	$0x4, %esi
    6818:      	callq	*%r8
    681b:      	testq	%rax, %rax
    681e:      	jne	0xc08 <perf_unwind_ruby+0xc08>
    6824:      	movzbl	0x23(%r15), %ecx
    6829:      	testq	%rcx, %rcx
    682c:      	je	0x6932 <perf_unwind_ruby+0x6932>
    6832:      	movq	0x18(%rsp), %rax
    6837:      	subq	0x68(%rsp), %rax
    683c:      	xorl	%edx, %edx
    683e:      	divq	%rcx
    6841:      	movl	0x2c(%rsp), %ecx
    6845:      	cmpq	%rcx, %rax
    6848:      	jbe	0x6932 <perf_unwind_ruby+0x6932>
    684e:      	movq	(%rip), %rax            # 0x6855 <perf_unwind_ruby+0x6855>
    6855:      	cmpl	$0x0, (%rax)
    6858:      	je	0x6a43 <perf_unwind_ruby+0x6a43>
    685e:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    6868:      	movq	%rax, 0x55(%rsp)
    686d:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    6877:      	movq	%rax, 0x50(%rsp)
    687c:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    6886:      	movq	%rax, 0x48(%rsp)
    688b:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    6895:      	movq	%rax, 0x40(%rsp)
    689a:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    68a4:      	movq	%rax, 0x38(%rsp)
    68a9:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    68b3:      	movq	%rax, 0x30(%rsp)
    68b8:      	leaq	0x30(%rsp), %rdi
    68bd:      	movl	$0x2d, %eax
    68c2:      	movl	$0x6, %ecx
    68c7:      	movl	$0x2d, %esi
    68cc:      	xorl	%eax, %eax
    68ce:      	callq	*%rcx
    68d0:      	jmp	0x6a43 <perf_unwind_ruby+0x6a43>
    68d5:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    68dc:      	jb	0x6a43 <perf_unwind_ruby+0x6a43>
    68e2:      	movq	$0x0, (%rsp)
    68ea:      	movzbl	0x1d(%r15), %eax
    68ef:      	addq	0x8(%rsp), %rax
    68f4:      	movq	%rsp, %rdi
    68f7:      	movl	$0x8, %ecx
    68fc:      	movl	$0x70, %r8d
    6902:      	movzbl	0x1d(%r15), %edx
    6907:      	addq	0x8(%rsp), %rdx
    690c:      	movl	$0x8, %esi
    6911:      	callq	*%r8
    6914:      	testq	%rax, %rax
    6917:      	jne	0x81b <perf_unwind_ruby+0x81b>
    691d:      	movl	(%rsp), %eax
    6920:      	notl	%eax
    6922:      	testl	$0x140, %eax            # imm = 0x140
    6927:      	jne	0x997 <perf_unwind_ruby+0x997>
    692d:      	jmp	0x6a43 <perf_unwind_ruby+0x6a43>
    6932:      	movl	0x2c0(%r14), %eax
    6939:      	cmpq	$0x7e, %rax
    693d:      	ja	0xdd3 <perf_unwind_ruby+0xdd3>
    6943:      	movq	0x10(%rsp), %rcx
    6948:      	movq	0x18(%rsp), %rdx
    694d:      	leal	0x1(%rax), %esi
    6950:      	movl	%esi, 0x2c0(%r14)
    6957:      	leaq	(%rax,%rax,2), %rax
    695b:      	movw	$0x0, 0x4(%rsp)
    6962:      	movl	$0x0, (%rsp)
    6969:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    6971:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    6979:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    6984:      	movl	(%rsp), %ecx
    6987:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    698f:      	movzwl	0x4(%rsp), %ecx
    6994:      	movw	%cx, 0x2e6(%r14,%rax,8)
    699d:      	movl	$0x36, (%rsp)
    69a4:      	movq	(%rip), %rdi            # 0x69ab <perf_unwind_ruby+0x69ab>
    69ab:      	movq	%rsp, %rsi
    69ae:      	movl	$0x1, %eax
    69b3:      	callq	*%rax
    69b5:      	testq	%rax, %rax
    69b8:      	je	0x69c2 <perf_unwind_ruby+0x69c2>
    69ba:      	incq	(%rax)
    69bd:      	jmp	0x6a43 <perf_unwind_ruby+0x6a43>
    69c2:      	movq	(%rip), %rax            # 0x69c9 <perf_unwind_ruby+0x69c9>
    69c9:      	cmpl	$0x0, (%rax)
    69cc:      	je	0x6a43 <perf_unwind_ruby+0x6a43>
    69ce:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    69d8:      	movq	%rax, 0x56(%rsp)
    69dd:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    69e7:      	movq	%rax, 0x50(%rsp)
    69ec:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    69f6:      	movq	%rax, 0x48(%rsp)
    69fb:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    6a05:      	movq	%rax, 0x40(%rsp)
    6a0a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    6a14:      	movq	%rax, 0x38(%rsp)
    6a19:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6a23:      	movq	%rax, 0x30(%rsp)
    6a28:      	leaq	0x30(%rsp), %rdi
    6a2d:      	movl	$0x2e, %eax
    6a32:      	movl	$0x6, %ecx
    6a37:      	movl	(%rsp), %edx
    6a3a:      	movl	$0x2e, %esi
    6a3f:      	xorl	%eax, %eax
    6a41:      	callq	*%rcx
    6a43:      	movq	0x8(%rsp), %rax
    6a48:      	cmpq	%rax, %r12
    6a4b:      	jbe	0x2b2 <perf_unwind_ruby+0x2b2>
    6a51:      	movzbl	0x1e(%r15), %ecx
    6a56:      	addq	%rcx, %rax
    6a59:      	movq	%rax, 0x8(%rsp)
    6a5e:      	movq	$0x0, 0x18(%rsp)
    6a67:      	movq	$0x0, 0x20(%rsp)
    6a70:      	movzbl	0x1c(%r15), %ecx
    6a75:      	addq	%rax, %rcx
    6a78:      	leaq	0x20(%rsp), %rdi
    6a7d:      	movl	$0x8, %eax
    6a82:      	movl	$0x70, %r8d
    6a88:      	movzbl	0x1c(%r15), %edx
    6a8d:      	addq	0x8(%rsp), %rdx
    6a92:      	movl	$0x8, %esi
    6a97:      	callq	*%r8
    6a9a:      	movzbl	0x1b(%r15), %eax
    6a9f:      	addq	0x8(%rsp), %rax
    6aa4:      	leaq	0x18(%rsp), %rdi
    6aa9:      	movl	$0x8, %ecx
    6aae:      	movl	$0x70, %r8d
    6ab4:      	movzbl	0x1b(%r15), %edx
    6ab9:      	addq	0x8(%rsp), %rdx
    6abe:      	movl	$0x8, %esi
    6ac3:      	callq	*%r8
    6ac6:      	cmpq	$0x0, 0x18(%rsp)
    6acc:      	je	0x6c2e <perf_unwind_ruby+0x6c2e>
    6ad2:      	movq	0x20(%rsp), %rax
    6ad7:      	testq	%rax, %rax
    6ada:      	je	0x6c2e <perf_unwind_ruby+0x6c2e>
    6ae0:      	movzbl	0x1f(%r15), %ecx
    6ae5:      	addq	%rcx, %rax
    6ae8:      	leaq	0x10(%rsp), %rdi
    6aed:      	movl	$0x8, %ecx
    6af2:      	movl	$0x70, %r8d
    6af8:      	movzbl	0x1f(%r15), %edx
    6afd:      	addq	0x20(%rsp), %rdx
    6b02:      	movl	$0x8, %esi
    6b07:      	callq	*%r8
    6b0a:      	testq	%rax, %rax
    6b0d:      	jne	0x4c7 <perf_unwind_ruby+0x4c7>
    6b13:      	movzbl	0x21(%r15), %eax
    6b18:      	addq	0x10(%rsp), %rax
    6b1d:      	leaq	0x68(%rsp), %rdi
    6b22:      	movl	$0x8, %ecx
    6b27:      	movl	$0x70, %r8d
    6b2d:      	movzbl	0x21(%r15), %edx
    6b32:      	addq	0x10(%rsp), %rdx
    6b37:      	movl	$0x8, %esi
    6b3c:      	callq	*%r8
    6b3f:      	testq	%rax, %rax
    6b42:      	jne	0x8a4 <perf_unwind_ruby+0x8a4>
    6b48:      	movzbl	0x22(%r15), %eax
    6b4d:      	addq	0x10(%rsp), %rax
    6b52:      	leaq	0x2c(%rsp), %rdi
    6b57:      	movl	$0x4, %ecx
    6b5c:      	movl	$0x70, %r8d
    6b62:      	movzbl	0x22(%r15), %edx
    6b67:      	addq	0x10(%rsp), %rdx
    6b6c:      	movl	$0x4, %esi
    6b71:      	callq	*%r8
    6b74:      	testq	%rax, %rax
    6b77:      	jne	0xc08 <perf_unwind_ruby+0xc08>
    6b7d:      	movzbl	0x23(%r15), %ecx
    6b82:      	testq	%rcx, %rcx
    6b85:      	je	0x6c8b <perf_unwind_ruby+0x6c8b>
    6b8b:      	movq	0x18(%rsp), %rax
    6b90:      	subq	0x68(%rsp), %rax
    6b95:      	xorl	%edx, %edx
    6b97:      	divq	%rcx
    6b9a:      	movl	0x2c(%rsp), %ecx
    6b9e:      	cmpq	%rcx, %rax
    6ba1:      	jbe	0x6c8b <perf_unwind_ruby+0x6c8b>
    6ba7:      	movq	(%rip), %rax            # 0x6bae <perf_unwind_ruby+0x6bae>
    6bae:      	cmpl	$0x0, (%rax)
    6bb1:      	je	0x6d9c <perf_unwind_ruby+0x6d9c>
    6bb7:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    6bc1:      	movq	%rax, 0x55(%rsp)
    6bc6:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    6bd0:      	movq	%rax, 0x50(%rsp)
    6bd5:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    6bdf:      	movq	%rax, 0x48(%rsp)
    6be4:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    6bee:      	movq	%rax, 0x40(%rsp)
    6bf3:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    6bfd:      	movq	%rax, 0x38(%rsp)
    6c02:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    6c0c:      	movq	%rax, 0x30(%rsp)
    6c11:      	leaq	0x30(%rsp), %rdi
    6c16:      	movl	$0x2d, %eax
    6c1b:      	movl	$0x6, %ecx
    6c20:      	movl	$0x2d, %esi
    6c25:      	xorl	%eax, %eax
    6c27:      	callq	*%rcx
    6c29:      	jmp	0x6d9c <perf_unwind_ruby+0x6d9c>
    6c2e:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    6c35:      	jb	0x6d9c <perf_unwind_ruby+0x6d9c>
    6c3b:      	movq	$0x0, (%rsp)
    6c43:      	movzbl	0x1d(%r15), %eax
    6c48:      	addq	0x8(%rsp), %rax
    6c4d:      	movq	%rsp, %rdi
    6c50:      	movl	$0x8, %ecx
    6c55:      	movl	$0x70, %r8d
    6c5b:      	movzbl	0x1d(%r15), %edx
    6c60:      	addq	0x8(%rsp), %rdx
    6c65:      	movl	$0x8, %esi
    6c6a:      	callq	*%r8
    6c6d:      	testq	%rax, %rax
    6c70:      	jne	0x81b <perf_unwind_ruby+0x81b>
    6c76:      	movl	(%rsp), %eax
    6c79:      	notl	%eax
    6c7b:      	testl	$0x140, %eax            # imm = 0x140
    6c80:      	jne	0x997 <perf_unwind_ruby+0x997>
    6c86:      	jmp	0x6d9c <perf_unwind_ruby+0x6d9c>
    6c8b:      	movl	0x2c0(%r14), %eax
    6c92:      	cmpq	$0x7e, %rax
    6c96:      	ja	0xdd3 <perf_unwind_ruby+0xdd3>
    6c9c:      	movq	0x10(%rsp), %rcx
    6ca1:      	movq	0x18(%rsp), %rdx
    6ca6:      	leal	0x1(%rax), %esi
    6ca9:      	movl	%esi, 0x2c0(%r14)
    6cb0:      	leaq	(%rax,%rax,2), %rax
    6cb4:      	movw	$0x0, 0x4(%rsp)
    6cbb:      	movl	$0x0, (%rsp)
    6cc2:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    6cca:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    6cd2:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    6cdd:      	movl	(%rsp), %ecx
    6ce0:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    6ce8:      	movzwl	0x4(%rsp), %ecx
    6ced:      	movw	%cx, 0x2e6(%r14,%rax,8)
    6cf6:      	movl	$0x36, (%rsp)
    6cfd:      	movq	(%rip), %rdi            # 0x6d04 <perf_unwind_ruby+0x6d04>
    6d04:      	movq	%rsp, %rsi
    6d07:      	movl	$0x1, %eax
    6d0c:      	callq	*%rax
    6d0e:      	testq	%rax, %rax
    6d11:      	je	0x6d1b <perf_unwind_ruby+0x6d1b>
    6d13:      	incq	(%rax)
    6d16:      	jmp	0x6d9c <perf_unwind_ruby+0x6d9c>
    6d1b:      	movq	(%rip), %rax            # 0x6d22 <perf_unwind_ruby+0x6d22>
    6d22:      	cmpl	$0x0, (%rax)
    6d25:      	je	0x6d9c <perf_unwind_ruby+0x6d9c>
    6d27:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    6d31:      	movq	%rax, 0x56(%rsp)
    6d36:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    6d40:      	movq	%rax, 0x50(%rsp)
    6d45:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    6d4f:      	movq	%rax, 0x48(%rsp)
    6d54:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    6d5e:      	movq	%rax, 0x40(%rsp)
    6d63:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    6d6d:      	movq	%rax, 0x38(%rsp)
    6d72:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6d7c:      	movq	%rax, 0x30(%rsp)
    6d81:      	leaq	0x30(%rsp), %rdi
    6d86:      	movl	$0x2e, %eax
    6d8b:      	movl	$0x6, %ecx
    6d90:      	movl	(%rsp), %edx
    6d93:      	movl	$0x2e, %esi
    6d98:      	xorl	%eax, %eax
    6d9a:      	callq	*%rcx
    6d9c:      	movq	0x8(%rsp), %rax
    6da1:      	cmpq	%rax, %r12
    6da4:      	jbe	0x2b2 <perf_unwind_ruby+0x2b2>
    6daa:      	movzbl	0x1e(%r15), %ecx
    6daf:      	addq	%rcx, %rax
    6db2:      	movq	%rax, 0x8(%rsp)
    6db7:      	movl	$0x6, %ebp
    6dbc:      	jmp	0x9ab <perf_unwind_ruby+0x9ab>

Disassembly of section kprobe/unwind_ruby:

0000000000000000 <kprobe_unwind_ruby>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x98, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x30(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <kprobe_unwind_ruby+0x23>
      23:      	leaq	0x30(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x3ba <kprobe_unwind_ruby+0x3ba>
      38:      	movq	%rax, %r14
      3b:      	movl	(%rax), %eax
      3d:      	movl	%eax, 0x84(%rsp)
      44:      	movq	(%rip), %rdi            # 0x4b <kprobe_unwind_ruby+0x4b>
      4b:      	leaq	0x84(%rsp), %rsi
      53:      	movl	$0x1, %eax
      58:      	callq	*%rax
      5a:      	testq	%rax, %rax
      5d:      	je	0x109 <kprobe_unwind_ruby+0x109>
      63:      	movq	%rax, %r15
      66:      	movl	$0x35, 0x8(%rsp)
      6e:      	movq	(%rip), %rdi            # 0x75 <kprobe_unwind_ruby+0x75>
      75:      	leaq	0x8(%rsp), %rsi
      7a:      	movl	$0x1, %eax
      7f:      	callq	*%rax
      81:      	testq	%rax, %rax
      84:      	je	0x146 <kprobe_unwind_ruby+0x146>
      8a:      	incq	(%rax)
      8d:      	movq	$0x0, 0x78(%rsp)
      96:      	cmpq	$0x0, 0x8(%r15)
      9b:      	jne	0x16a <kprobe_unwind_ruby+0x16a>
      a1:      	cmpl	$0x30000, (%r15)        # imm = 0x30000
      a8:      	jb	0x333 <kprobe_unwind_ruby+0x333>
      ae:      	movq	$0x0, 0x30(%rsp)
      b7:      	movq	0x10(%r15), %rax
      bb:      	leaq	0x30(%rsp), %rdi
      c0:      	movl	$0x8, %ecx
      c5:      	movl	$0x70, %r8d
      cb:      	movq	0x10(%r15), %rdx
      cf:      	movl	$0x8, %esi
      d4:      	callq	*%r8
      d7:      	testq	%rax, %rax
      da:      	jne	0x298 <kprobe_unwind_ruby+0x298>
      e0:      	movzwl	0x24(%r15), %eax
      e5:      	addq	0x30(%rsp), %rax
      ea:      	leaq	0x78(%rsp), %rdi
      ef:      	movl	$0x8, %ecx
      f4:      	movl	$0x70, %r8d
      fa:      	movzwl	0x24(%r15), %edx
      ff:      	addq	0x30(%rsp), %rdx
     104:      	jmp	0x34b <kprobe_unwind_ruby+0x34b>
     109:      	movq	(%rip), %r15            # 0x110 <kprobe_unwind_ruby+0x110>
     110:      	cmpl	$0x0, (%r15)
     114:      	jne	0x11da <kprobe_unwind_ruby+0x11da>
     11a:      	movl	$0x49, 0x8(%rsp)
     122:      	movq	(%rip), %rdi            # 0x129 <kprobe_unwind_ruby+0x129>
     129:      	leaq	0x8(%rsp), %rsi
     12e:      	movl	$0x1, %eax
     133:      	callq	*%rax
     135:      	testq	%rax, %rax
     138:      	je	0x29d <kprobe_unwind_ruby+0x29d>
     13e:      	incq	(%rax)
     141:      	jmp	0x2a7 <kprobe_unwind_ruby+0x2a7>
     146:      	movq	(%rip), %rax            # 0x14d <kprobe_unwind_ruby+0x14d>
     14d:      	cmpl	$0x0, (%rax)
     150:      	jne	0x1511 <kprobe_unwind_ruby+0x1511>
     156:      	movq	$0x0, 0x78(%rsp)
     15f:      	cmpq	$0x0, 0x8(%r15)
     164:      	je	0xa1 <kprobe_unwind_ruby+0xa1>
     16a:      	movl	$0x23, %eax
     16f:      	callq	*%rax
     171:      	movq	(%rip), %rcx            # 0x178 <kprobe_unwind_ruby+0x178>
     178:      	addq	(%rcx), %rax
     17b:      	leaq	0x8(%rsp), %rdi
     180:      	movl	$0x8, %ecx
     185:      	movl	$0x71, %r8d
     18b:      	movl	$0x8, %esi
     190:      	movq	%rax, %rdx
     193:      	callq	*%r8
     196:      	testq	%rax, %rax
     199:      	je	0x25e <kprobe_unwind_ruby+0x25e>
     19f:      	movq	(%rip), %rbx            # 0x1a6 <kprobe_unwind_ruby+0x1a6>
     1a6:      	cmpl	$0x0, (%rbx)
     1a9:      	jne	0x12c0 <kprobe_unwind_ruby+0x12c0>
     1af:      	movl	$0x4, 0x20(%rsp)
     1b7:      	movq	(%rip), %rdi            # 0x1be <kprobe_unwind_ruby+0x1be>
     1be:      	leaq	0x20(%rsp), %rsi
     1c3:      	movl	$0x1, %eax
     1c8:      	callq	*%rax
     1ca:      	testq	%rax, %rax
     1cd:      	je	0x373 <kprobe_unwind_ruby+0x373>
     1d3:      	incq	(%rax)
     1d6:      	cmpl	$0x0, (%rbx)
     1d9:      	je	0x37c <kprobe_unwind_ruby+0x37c>
     1df:      	movabsq	$0x6b6f6f6c206c6f62, %rax # imm = 0x6B6F6F6C206C6F62
     1e9:      	movq	%rax, 0x58(%rsp)
     1ee:      	movabsq	$0x6d797320534c5420, %rax # imm = 0x6D797320534C5420
     1f8:      	movq	%rax, 0x50(%rsp)
     1fd:      	movabsq	$0x726f662065736162, %rax # imm = 0x726F662065736162
     207:      	movq	%rax, 0x48(%rsp)
     20c:      	movabsq	$0x2044535420746567, %rax # imm = 0x2044535420746567
     216:      	movq	%rax, 0x40(%rsp)
     21b:      	movabsq	$0x206f742064656c69, %rax # imm = 0x206F742064656C69
     225:      	movq	%rax, 0x38(%rsp)
     22a:      	movabsq	$0x6166203a79627572, %rax # imm = 0x6166203A79627572
     234:      	movq	%rax, 0x30(%rsp)
     239:      	movl	$0xa7075, 0x60(%rsp)    # imm = 0xA7075
     241:      	leaq	0x30(%rsp), %rdi
     246:      	movl	$0x34, %eax
     24b:      	movl	$0x6, %ecx
     250:      	movl	$0x34, %esi
     255:      	xorl	%eax, %eax
     257:      	callq	*%rcx
     259:      	jmp	0x37c <kprobe_unwind_ruby+0x37c>
     25e:      	movq	0x8(%r15), %rdx
     262:      	movq	(%rip), %r13            # 0x269 <kprobe_unwind_ruby+0x269>
     269:      	addq	0x8(%rsp), %rdx
     26e:      	cmpl	$0x0, (%r13)
     273:      	jne	0x15a0 <kprobe_unwind_ruby+0x15a0>
     279:      	leaq	0x78(%rsp), %rdi
     27e:      	movl	$0x8, %eax
     283:      	movl	$0x70, %ecx
     288:      	movl	$0x8, %esi
     28d:      	callq	*%rcx
     28f:      	testq	%rax, %rax
     292:      	je	0x3d1 <kprobe_unwind_ruby+0x3d1>
     298:      	xorl	%r13d, %r13d
     29b:      	jmp	0x2ad <kprobe_unwind_ruby+0x2ad>
     29d:      	cmpl	$0x0, (%r15)
     2a1:      	jne	0x1627 <kprobe_unwind_ruby+0x1627>
     2a7:      	movl	$0xbb8, %r13d           # imm = 0xBB8
     2ad:      	movl	$0x1, %ebp
     2b2:      	movl	%r13d, 0xf2c(%r14)
     2b9:      	movl	$0x0, 0x30(%rsp)
     2c1:      	movq	(%rip), %rdi            # 0x2c8 <kprobe_unwind_ruby+0x2c8>
     2c8:      	leaq	0x30(%rsp), %rsi
     2cd:      	movl	$0x1, %eax
     2d2:      	callq	*%rax
     2d4:      	testq	%rax, %rax
     2d7:      	je	0x31b <kprobe_unwind_ruby+0x31b>
     2d9:      	movzbl	0x1384(%rax), %ecx
     2e0:      	cmpb	$0x1d, %cl
     2e3:      	jb	0x39d <kprobe_unwind_ruby+0x39d>
     2e9:      	movq	%rax, %r14
     2ec:      	movl	$0x5, 0xf2c(%rax)
     2f6:      	movl	$0x44, 0x8(%rsp)
     2fe:      	movq	(%rip), %rdi            # 0x305 <kprobe_unwind_ruby+0x305>
     305:      	leaq	0x8(%rsp), %rsi
     30a:      	movl	$0x1, %eax
     30f:      	callq	*%rax
     311:      	testq	%rax, %rax
     314:      	je	0x380 <kprobe_unwind_ruby+0x380>
     316:      	incq	(%rax)
     319:      	jmp	0x390 <kprobe_unwind_ruby+0x390>
     31b:      	movq	(%rip), %rsi            # 0x322 <kprobe_unwind_ruby+0x322>
     322:      	xorl	%eax, %eax
     324:      	movl	$0xc, %ecx
     329:      	movq	%rbx, %rdi
     32c:      	xorl	%edx, %edx
     32e:      	jmp	0x3b8 <kprobe_unwind_ruby+0x3b8>
     333:      	movq	0x10(%r15), %rax
     337:      	leaq	0x78(%rsp), %rdi
     33c:      	movl	$0x8, %ecx
     341:      	movl	$0x70, %r8d
     347:      	movq	0x10(%r15), %rdx
     34b:      	movl	$0x8, %esi
     350:      	callq	*%r8
     353:      	xorl	%r13d, %r13d
     356:      	movl	$0x1, %ebp
     35b:      	testq	%rax, %rax
     35e:      	jne	0x2b2 <kprobe_unwind_ruby+0x2b2>
     364:      	movq	0x78(%rsp), %r12
     369:      	testq	%r12, %r12
     36c:      	jne	0x3ea <kprobe_unwind_ruby+0x3ea>
     36e:      	jmp	0x2b2 <kprobe_unwind_ruby+0x2b2>
     373:      	cmpl	$0x0, (%rbx)
     376:      	jne	0x16f2 <kprobe_unwind_ruby+0x16f2>
     37c:      	xorl	%eax, %eax
     37e:      	jmp	0x3bf <kprobe_unwind_ruby+0x3bf>
     380:      	movq	(%rip), %rax            # 0x387 <kprobe_unwind_ruby+0x387>
     387:      	cmpl	$0x0, (%rax)
     38a:      	jne	0x1776 <kprobe_unwind_ruby+0x1776>
     390:      	movq	%r14, %rax
     393:      	movzbl	0x1384(%r14), %ecx
     39b:      	xorl	%ebp, %ebp
     39d:      	incb	%cl
     39f:      	movb	%cl, 0x1384(%rax)
     3a5:      	movl	%ebp, %eax
     3a7:      	movq	(%rip), %rsi            # 0x3ae <kprobe_unwind_ruby+0x3ae>
     3ae:      	movl	$0xc, %ecx
     3b3:      	movq	%rbx, %rdi
     3b6:      	movl	%ebp, %edx
     3b8:      	callq	*%rcx
     3ba:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     3bf:      	addq	$0x98, %rsp
     3c6:      	popq	%rbx
     3c7:      	popq	%r12
     3c9:      	popq	%r13
     3cb:      	popq	%r14
     3cd:      	popq	%r15
     3cf:      	popq	%rbp
     3d0:      	retq
     3d1:      	cmpl	$0x0, (%r13)
     3d6:      	jne	0x187b <kprobe_unwind_ruby+0x187b>
     3dc:      	movq	0x78(%rsp), %r12
     3e1:      	testq	%r12, %r12
     3e4:      	je	0x298 <kprobe_unwind_ruby+0x298>
     3ea:      	movq	0xf68(%r14), %rax
     3f1:      	movq	%rax, 0x8(%rsp)
     3f6:      	testq	%rax, %rax
     3f9:      	je	0x501 <kprobe_unwind_ruby+0x501>
     3ff:      	movq	0xf70(%r14), %r13
     406:      	testq	%r13, %r13
     409:      	je	0x501 <kprobe_unwind_ruby+0x501>
     40f:      	movq	%r13, %r12
     412:      	movq	$0x0, 0x18(%rsp)
     41b:      	movq	$0x0, 0x20(%rsp)
     424:      	movzbl	0x1c(%r15), %ecx
     429:      	addq	%rax, %rcx
     42c:      	leaq	0x20(%rsp), %rdi
     431:      	movl	$0x8, %eax
     436:      	movl	$0x70, %r8d
     43c:      	movzbl	0x1c(%r15), %edx
     441:      	addq	0x8(%rsp), %rdx
     446:      	movl	$0x8, %esi
     44b:      	callq	*%r8
     44e:      	movzbl	0x1b(%r15), %eax
     453:      	addq	0x8(%rsp), %rax
     458:      	leaq	0x18(%rsp), %rdi
     45d:      	movl	$0x8, %ecx
     462:      	movl	$0x70, %r8d
     468:      	movzbl	0x1b(%r15), %edx
     46d:      	addq	0x8(%rsp), %rdx
     472:      	movl	$0x8, %esi
     477:      	callq	*%r8
     47a:      	cmpq	$0x0, 0x18(%rsp)
     480:      	je	0x56f <kprobe_unwind_ruby+0x56f>
     486:      	movq	0x20(%rsp), %rax
     48b:      	testq	%rax, %rax
     48e:      	je	0x56f <kprobe_unwind_ruby+0x56f>
     494:      	movzbl	0x1f(%r15), %ecx
     499:      	addq	%rcx, %rax
     49c:      	leaq	0x10(%rsp), %rdi
     4a1:      	movl	$0x8, %ecx
     4a6:      	movl	$0x70, %r8d
     4ac:      	movzbl	0x1f(%r15), %edx
     4b1:      	addq	0x20(%rsp), %rdx
     4b6:      	movl	$0x8, %esi
     4bb:      	callq	*%r8
     4be:      	testq	%rax, %rax
     4c1:      	je	0x86f <kprobe_unwind_ruby+0x86f>
     4c7:      	movq	(%rip), %r15            # 0x4ce <kprobe_unwind_ruby+0x4ce>
     4ce:      	cmpl	$0x0, (%r15)
     4d2:      	jne	0x1bdc <kprobe_unwind_ruby+0x1bdc>
     4d8:      	movl	$0x4e, (%rsp)
     4df:      	movq	(%rip), %rdi            # 0x4e6 <kprobe_unwind_ruby+0x4e6>
     4e6:      	movq	%rsp, %rsi
     4e9:      	movl	$0x1, %eax
     4ee:      	callq	*%rax
     4f0:      	testq	%rax, %rax
     4f3:      	je	0x8de <kprobe_unwind_ruby+0x8de>
     4f9:      	incq	(%rax)
     4fc:      	jmp	0x8e8 <kprobe_unwind_ruby+0x8e8>
     501:      	movzbl	0x18(%r15), %eax
     506:      	addq	%r12, %rax
     509:      	leaq	0x20(%rsp), %rdi
     50e:      	movl	$0x8, %ecx
     513:      	movl	$0x70, %r8d
     519:      	movzbl	0x18(%r15), %edx
     51e:      	addq	%r12, %rdx
     521:      	movl	$0x8, %esi
     526:      	callq	*%r8
     529:      	testq	%rax, %rax
     52c:      	je	0x772 <kprobe_unwind_ruby+0x772>
     532:      	movq	(%rip), %r15            # 0x539 <kprobe_unwind_ruby+0x539>
     539:      	cmpl	$0x0, (%r15)
     53d:      	jne	0x1b6c <kprobe_unwind_ruby+0x1b6c>
     543:      	movl	$0x4a, 0x18(%rsp)
     54b:      	movq	(%rip), %rdi            # 0x552 <kprobe_unwind_ruby+0x552>
     552:      	leaq	0x18(%rsp), %rsi
     557:      	movl	$0x1, %eax
     55c:      	callq	*%rax
     55e:      	testq	%rax, %rax
     561:      	je	0x858 <kprobe_unwind_ruby+0x858>
     567:      	incq	(%rax)
     56a:      	jmp	0x862 <kprobe_unwind_ruby+0x862>
     56f:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
     576:      	jae	0x7e0 <kprobe_unwind_ruby+0x7e0>
     57c:      	movq	0x8(%rsp), %rax
     581:      	xorl	%r13d, %r13d
     584:      	movl	$0x1, %ebp
     589:      	movq	%r12, %rcx
     58c:      	cmpq	%rax, %r12
     58f:      	jbe	0x2b2 <kprobe_unwind_ruby+0x2b2>
     595:      	movzbl	0x1e(%r15), %ecx
     59a:      	addq	%rcx, %rax
     59d:      	movq	%rax, 0x8(%rsp)
     5a2:      	movq	$0x0, 0x18(%rsp)
     5ab:      	movq	$0x0, 0x20(%rsp)
     5b4:      	movzbl	0x1c(%r15), %ecx
     5b9:      	addq	%rax, %rcx
     5bc:      	leaq	0x20(%rsp), %rdi
     5c1:      	movl	$0x8, %eax
     5c6:      	movl	$0x70, %r8d
     5cc:      	movzbl	0x1c(%r15), %edx
     5d1:      	addq	0x8(%rsp), %rdx
     5d6:      	movl	$0x8, %esi
     5db:      	callq	*%r8
     5de:      	movzbl	0x1b(%r15), %eax
     5e3:      	addq	0x8(%rsp), %rax
     5e8:      	leaq	0x18(%rsp), %rdi
     5ed:      	movl	$0x8, %ecx
     5f2:      	movl	$0x70, %r8d
     5f8:      	movzbl	0x1b(%r15), %edx
     5fd:      	addq	0x8(%rsp), %rdx
     602:      	movl	$0x8, %esi
     607:      	callq	*%r8
     60a:      	cmpq	$0x0, 0x18(%rsp)
     610:      	je	0x9d8 <kprobe_unwind_ruby+0x9d8>
     616:      	movq	0x20(%rsp), %rax
     61b:      	testq	%rax, %rax
     61e:      	je	0x9d8 <kprobe_unwind_ruby+0x9d8>
     624:      	movzbl	0x1f(%r15), %ecx
     629:      	addq	%rcx, %rax
     62c:      	leaq	0x10(%rsp), %rdi
     631:      	movl	$0x8, %ecx
     636:      	movl	$0x70, %r8d
     63c:      	movzbl	0x1f(%r15), %edx
     641:      	addq	0x20(%rsp), %rdx
     646:      	movl	$0x8, %esi
     64b:      	callq	*%r8
     64e:      	testq	%rax, %rax
     651:      	jne	0x4c7 <kprobe_unwind_ruby+0x4c7>
     657:      	movzbl	0x21(%r15), %eax
     65c:      	addq	0x10(%rsp), %rax
     661:      	leaq	0x68(%rsp), %rdi
     666:      	movl	$0x8, %ecx
     66b:      	movl	$0x70, %r8d
     671:      	movzbl	0x21(%r15), %edx
     676:      	addq	0x10(%rsp), %rdx
     67b:      	movl	$0x8, %esi
     680:      	callq	*%r8
     683:      	testq	%rax, %rax
     686:      	jne	0x8a4 <kprobe_unwind_ruby+0x8a4>
     68c:      	movzbl	0x22(%r15), %eax
     691:      	addq	0x10(%rsp), %rax
     696:      	leaq	0x2c(%rsp), %rdi
     69b:      	movl	$0x4, %ecx
     6a0:      	movl	$0x70, %r8d
     6a6:      	movzbl	0x22(%r15), %edx
     6ab:      	addq	0x10(%rsp), %rdx
     6b0:      	movl	$0x4, %esi
     6b5:      	callq	*%r8
     6b8:      	testq	%rax, %rax
     6bb:      	jne	0xc08 <kprobe_unwind_ruby+0xc08>
     6c1:      	movzbl	0x23(%r15), %ecx
     6c6:      	testq	%rcx, %rcx
     6c9:      	je	0x122c <kprobe_unwind_ruby+0x122c>
     6cf:      	movq	0x18(%rsp), %rax
     6d4:      	subq	0x68(%rsp), %rax
     6d9:      	xorl	%edx, %edx
     6db:      	divq	%rcx
     6de:      	movl	0x2c(%rsp), %ecx
     6e2:      	cmpq	%rcx, %rax
     6e5:      	jbe	0x122c <kprobe_unwind_ruby+0x122c>
     6eb:      	movq	(%rip), %rax            # 0x6f2 <kprobe_unwind_ruby+0x6f2>
     6f2:      	cmpl	$0x0, (%rax)
     6f5:      	je	0x9e5 <kprobe_unwind_ruby+0x9e5>
     6fb:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
     705:      	movq	%rax, 0x55(%rsp)
     70a:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
     714:      	movq	%rax, 0x50(%rsp)
     719:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
     723:      	movq	%rax, 0x48(%rsp)
     728:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
     732:      	movq	%rax, 0x40(%rsp)
     737:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
     741:      	movq	%rax, 0x38(%rsp)
     746:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
     750:      	movq	%rax, 0x30(%rsp)
     755:      	leaq	0x30(%rsp), %rdi
     75a:      	movl	$0x2d, %eax
     75f:      	movl	$0x6, %ecx
     764:      	movl	$0x2d, %esi
     769:      	xorl	%eax, %eax
     76b:      	callq	*%rcx
     76d:      	jmp	0x9e5 <kprobe_unwind_ruby+0x9e5>
     772:      	movzbl	0x19(%r15), %eax
     777:      	addq	%r12, %rax
     77a:      	leaq	0x10(%rsp), %rdi
     77f:      	movl	$0x8, %ecx
     784:      	movl	$0x70, %r8d
     78a:      	movzbl	0x19(%r15), %edx
     78f:      	addq	%r12, %rdx
     792:      	movl	$0x8, %esi
     797:      	callq	*%r8
     79a:      	testq	%rax, %rax
     79d:      	je	0x8f5 <kprobe_unwind_ruby+0x8f5>
     7a3:      	movq	(%rip), %r15            # 0x7aa <kprobe_unwind_ruby+0x7aa>
     7aa:      	cmpl	$0x0, (%r15)
     7ae:      	jne	0x1c85 <kprobe_unwind_ruby+0x1c85>
     7b4:      	movl	$0x4b, 0x18(%rsp)
     7bc:      	movq	(%rip), %rdi            # 0x7c3 <kprobe_unwind_ruby+0x7c3>
     7c3:      	leaq	0x18(%rsp), %rsi
     7c8:      	movl	$0x1, %eax
     7cd:      	callq	*%rax
     7cf:      	testq	%rax, %rax
     7d2:      	je	0x9c1 <kprobe_unwind_ruby+0x9c1>
     7d8:      	incq	(%rax)
     7db:      	jmp	0x9cb <kprobe_unwind_ruby+0x9cb>
     7e0:      	movq	$0x0, (%rsp)
     7e8:      	movzbl	0x1d(%r15), %eax
     7ed:      	addq	0x8(%rsp), %rax
     7f2:      	movq	%rsp, %rdi
     7f5:      	movl	$0x8, %ecx
     7fa:      	movl	$0x70, %r8d
     800:      	movzbl	0x1d(%r15), %edx
     805:      	addq	0x8(%rsp), %rdx
     80a:      	movl	$0x8, %esi
     80f:      	callq	*%r8
     812:      	testq	%rax, %rax
     815:      	je	0x987 <kprobe_unwind_ruby+0x987>
     81b:      	movq	(%rip), %r15            # 0x822 <kprobe_unwind_ruby+0x822>
     822:      	cmpl	$0x0, (%r15)
     826:      	jne	0x1d59 <kprobe_unwind_ruby+0x1d59>
     82c:      	movl	$0x4d, 0x74(%rsp)
     834:      	movq	(%rip), %rdi            # 0x83b <kprobe_unwind_ruby+0x83b>
     83b:      	leaq	0x74(%rsp), %rsi
     840:      	movl	$0x1, %eax
     845:      	callq	*%rax
     847:      	testq	%rax, %rax
     84a:      	je	0xc42 <kprobe_unwind_ruby+0xc42>
     850:      	incq	(%rax)
     853:      	jmp	0xc4c <kprobe_unwind_ruby+0xc4c>
     858:      	cmpl	$0x0, (%r15)
     85c:      	jne	0x1cde <kprobe_unwind_ruby+0x1cde>
     862:      	movl	$0xbb9, %r13d           # imm = 0xBB9
     868:      	xorl	%ebp, %ebp
     86a:      	jmp	0x2b2 <kprobe_unwind_ruby+0x2b2>
     86f:      	movzbl	0x21(%r15), %eax
     874:      	addq	0x10(%rsp), %rax
     879:      	leaq	0x68(%rsp), %rdi
     87e:      	movl	$0x8, %ecx
     883:      	movl	$0x70, %r8d
     889:      	movzbl	0x21(%r15), %edx
     88e:      	addq	0x10(%rsp), %rdx
     893:      	movl	$0x8, %esi
     898:      	callq	*%r8
     89b:      	testq	%rax, %rax
     89e:      	je	0xbd3 <kprobe_unwind_ruby+0xbd3>
     8a4:      	movq	(%rip), %r15            # 0x8ab <kprobe_unwind_ruby+0x8ab>
     8ab:      	cmpl	$0x0, (%r15)
     8af:      	jne	0x1ec1 <kprobe_unwind_ruby+0x1ec1>
     8b5:      	movl	$0x4f, (%rsp)
     8bc:      	movq	(%rip), %rdi            # 0x8c3 <kprobe_unwind_ruby+0x8c3>
     8c3:      	movq	%rsp, %rsi
     8c6:      	movl	$0x1, %eax
     8cb:      	callq	*%rax
     8cd:      	testq	%rax, %rax
     8d0:      	je	0xc59 <kprobe_unwind_ruby+0xc59>
     8d6:      	incq	(%rax)
     8d9:      	jmp	0xc63 <kprobe_unwind_ruby+0xc63>
     8de:      	cmpl	$0x0, (%r15)
     8e2:      	jne	0x1f21 <kprobe_unwind_ruby+0x1f21>
     8e8:      	movl	$0xbbd, %r13d           # imm = 0xBBD
     8ee:      	xorl	%ebp, %ebp
     8f0:      	jmp	0x2b2 <kprobe_unwind_ruby+0x2b2>
     8f5:      	movq	0x20(%rsp), %r13
     8fa:      	movzbl	0x23(%r15), %eax
     8ff:      	movq	%rax, 0x88(%rsp)
     907:      	movq	0x10(%rsp), %rbp
     90c:      	movzbl	0x1e(%r15), %eax
     911:      	movq	%rax, 0x90(%rsp)
     919:      	movzbl	0x1a(%r15), %eax
     91e:      	addq	%r12, %rax
     921:      	leaq	0x8(%rsp), %rdi
     926:      	movl	$0x8, %ecx
     92b:      	movl	$0x70, %r8d
     931:      	movzbl	0x1a(%r15), %edx
     936:      	addq	%r12, %rdx
     939:      	movl	$0x8, %esi
     93e:      	callq	*%r8
     941:      	testq	%rax, %rax
     944:      	je	0xc70 <kprobe_unwind_ruby+0xc70>
     94a:      	movq	(%rip), %r15            # 0x951 <kprobe_unwind_ruby+0x951>
     951:      	cmpl	$0x0, (%r15)
     955:      	jne	0x2193 <kprobe_unwind_ruby+0x2193>
     95b:      	movl	$0x4c, 0x18(%rsp)
     963:      	movq	(%rip), %rdi            # 0x96a <kprobe_unwind_ruby+0x96a>
     96a:      	leaq	0x18(%rsp), %rsi
     96f:      	movl	$0x1, %eax
     974:      	callq	*%rax
     976:      	testq	%rax, %rax
     979:      	je	0xce3 <kprobe_unwind_ruby+0xce3>
     97f:      	incq	(%rax)
     982:      	jmp	0xced <kprobe_unwind_ruby+0xced>
     987:      	movl	(%rsp), %eax
     98a:      	notl	%eax
     98c:      	testl	$0x140, %eax            # imm = 0x140
     991:      	je	0x57c <kprobe_unwind_ruby+0x57c>
     997:      	movzbl	0x1e(%r15), %eax
     99c:      	addq	0x8(%rsp), %rax
     9a1:      	movq	%rax, 0x8(%rsp)
     9a6:      	movl	$0x1, %ebp
     9ab:      	movq	%rax, 0xf68(%r14)
     9b2:      	movq	%r12, 0xf70(%r14)
     9b9:      	xorl	%r13d, %r13d
     9bc:      	jmp	0x2b2 <kprobe_unwind_ruby+0x2b2>
     9c1:      	cmpl	$0x0, (%r15)
     9c5:      	jne	0x21e2 <kprobe_unwind_ruby+0x21e2>
     9cb:      	movl	$0xbba, %r13d           # imm = 0xBBA
     9d1:      	xorl	%ebp, %ebp
     9d3:      	jmp	0x2b2 <kprobe_unwind_ruby+0x2b2>
     9d8:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
     9df:      	jae	0xc93 <kprobe_unwind_ruby+0xc93>
     9e5:      	movq	0x8(%rsp), %rax
     9ea:      	movq	%r12, %rcx
     9ed:      	cmpq	%rax, %r12
     9f0:      	jbe	0x2b2 <kprobe_unwind_ruby+0x2b2>
     9f6:      	movzbl	0x1e(%r15), %ecx
     9fb:      	addq	%rcx, %rax
     9fe:      	movq	%rax, 0x8(%rsp)
     a03:      	movq	$0x0, 0x18(%rsp)
     a0c:      	movq	$0x0, 0x20(%rsp)
     a15:      	movzbl	0x1c(%r15), %ecx
     a1a:      	addq	%rax, %rcx
     a1d:      	leaq	0x20(%rsp), %rdi
     a22:      	movl	$0x8, %eax
     a27:      	movl	$0x70, %r8d
     a2d:      	movzbl	0x1c(%r15), %edx
     a32:      	addq	0x8(%rsp), %rdx
     a37:      	movl	$0x8, %esi
     a3c:      	callq	*%r8
     a3f:      	movzbl	0x1b(%r15), %eax
     a44:      	addq	0x8(%rsp), %rax
     a49:      	leaq	0x18(%rsp), %rdi
     a4e:      	movl	$0x8, %ecx
     a53:      	movl	$0x70, %r8d
     a59:      	movzbl	0x1b(%r15), %edx
     a5e:      	addq	0x8(%rsp), %rdx
     a63:      	movl	$0x8, %esi
     a68:      	callq	*%r8
     a6b:      	cmpq	$0x0, 0x18(%rsp)
     a71:      	je	0xe6f <kprobe_unwind_ruby+0xe6f>
     a77:      	movq	0x20(%rsp), %rax
     a7c:      	testq	%rax, %rax
     a7f:      	je	0xe6f <kprobe_unwind_ruby+0xe6f>
     a85:      	movzbl	0x1f(%r15), %ecx
     a8a:      	addq	%rcx, %rax
     a8d:      	leaq	0x10(%rsp), %rdi
     a92:      	movl	$0x8, %ecx
     a97:      	movl	$0x70, %r8d
     a9d:      	movzbl	0x1f(%r15), %edx
     aa2:      	addq	0x20(%rsp), %rdx
     aa7:      	movl	$0x8, %esi
     aac:      	callq	*%r8
     aaf:      	testq	%rax, %rax
     ab2:      	jne	0x4c7 <kprobe_unwind_ruby+0x4c7>
     ab8:      	movzbl	0x21(%r15), %eax
     abd:      	addq	0x10(%rsp), %rax
     ac2:      	leaq	0x68(%rsp), %rdi
     ac7:      	movl	$0x8, %ecx
     acc:      	movl	$0x70, %r8d
     ad2:      	movzbl	0x21(%r15), %edx
     ad7:      	addq	0x10(%rsp), %rdx
     adc:      	movl	$0x8, %esi
     ae1:      	callq	*%r8
     ae4:      	testq	%rax, %rax
     ae7:      	jne	0x8a4 <kprobe_unwind_ruby+0x8a4>
     aed:      	movzbl	0x22(%r15), %eax
     af2:      	addq	0x10(%rsp), %rax
     af7:      	leaq	0x2c(%rsp), %rdi
     afc:      	movl	$0x4, %ecx
     b01:      	movl	$0x70, %r8d
     b07:      	movzbl	0x22(%r15), %edx
     b0c:      	addq	0x10(%rsp), %rdx
     b11:      	movl	$0x4, %esi
     b16:      	callq	*%r8
     b19:      	testq	%rax, %rax
     b1c:      	jne	0xc08 <kprobe_unwind_ruby+0xc08>
     b22:      	movzbl	0x23(%r15), %ecx
     b27:      	testq	%rcx, %rcx
     b2a:      	je	0x18e0 <kprobe_unwind_ruby+0x18e0>
     b30:      	movq	0x18(%rsp), %rax
     b35:      	subq	0x68(%rsp), %rax
     b3a:      	xorl	%edx, %edx
     b3c:      	divq	%rcx
     b3f:      	movl	0x2c(%rsp), %ecx
     b43:      	cmpq	%rcx, %rax
     b46:      	jbe	0x18e0 <kprobe_unwind_ruby+0x18e0>
     b4c:      	movq	(%rip), %rax            # 0xb53 <kprobe_unwind_ruby+0xb53>
     b53:      	cmpl	$0x0, (%rax)
     b56:      	je	0xe7c <kprobe_unwind_ruby+0xe7c>
     b5c:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
     b66:      	movq	%rax, 0x55(%rsp)
     b6b:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
     b75:      	movq	%rax, 0x50(%rsp)
     b7a:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
     b84:      	movq	%rax, 0x48(%rsp)
     b89:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
     b93:      	movq	%rax, 0x40(%rsp)
     b98:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
     ba2:      	movq	%rax, 0x38(%rsp)
     ba7:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
     bb1:      	movq	%rax, 0x30(%rsp)
     bb6:      	leaq	0x30(%rsp), %rdi
     bbb:      	movl	$0x2d, %eax
     bc0:      	movl	$0x6, %ecx
     bc5:      	movl	$0x2d, %esi
     bca:      	xorl	%eax, %eax
     bcc:      	callq	*%rcx
     bce:      	jmp	0xe7c <kprobe_unwind_ruby+0xe7c>
     bd3:      	movzbl	0x22(%r15), %eax
     bd8:      	addq	0x10(%rsp), %rax
     bdd:      	leaq	0x2c(%rsp), %rdi
     be2:      	movl	$0x4, %ecx
     be7:      	movl	$0x70, %r8d
     bed:      	movzbl	0x22(%r15), %edx
     bf2:      	addq	0x10(%rsp), %rdx
     bf7:      	movl	$0x4, %esi
     bfc:      	callq	*%r8
     bff:      	testq	%rax, %rax
     c02:      	je	0xcfa <kprobe_unwind_ruby+0xcfa>
     c08:      	movq	(%rip), %r15            # 0xc0f <kprobe_unwind_ruby+0xc0f>
     c0f:      	cmpl	$0x0, (%r15)
     c13:      	jne	0x22d8 <kprobe_unwind_ruby+0x22d8>
     c19:      	movl	$0x50, (%rsp)
     c20:      	movq	(%rip), %rdi            # 0xc27 <kprobe_unwind_ruby+0xc27>
     c27:      	movq	%rsp, %rsi
     c2a:      	movl	$0x1, %eax
     c2f:      	callq	*%rax
     c31:      	testq	%rax, %rax
     c34:      	je	0xdab <kprobe_unwind_ruby+0xdab>
     c3a:      	incq	(%rax)
     c3d:      	jmp	0xdb5 <kprobe_unwind_ruby+0xdb5>
     c42:      	cmpl	$0x0, (%r15)
     c46:      	jne	0x225d <kprobe_unwind_ruby+0x225d>
     c4c:      	movl	$0xbbc, %r13d           # imm = 0xBBC
     c52:      	xorl	%ebp, %ebp
     c54:      	jmp	0x2b2 <kprobe_unwind_ruby+0x2b2>
     c59:      	cmpl	$0x0, (%r15)
     c5d:      	jne	0x2331 <kprobe_unwind_ruby+0x2331>
     c63:      	movl	$0xbbe, %r13d           # imm = 0xBBE
     c69:      	xorl	%ebp, %ebp
     c6b:      	jmp	0x2b2 <kprobe_unwind_ruby+0x2b2>
     c70:      	imulq	0x88(%rsp), %rbp
     c79:      	addq	%rbp, %r13
     c7c:      	movq	0x90(%rsp), %rax
     c84:      	addl	%eax, %eax
     c86:      	subq	%rax, %r13
     c89:      	movq	0x8(%rsp), %rax
     c8e:      	jmp	0x40f <kprobe_unwind_ruby+0x40f>
     c93:      	movq	$0x0, (%rsp)
     c9b:      	movzbl	0x1d(%r15), %eax
     ca0:      	addq	0x8(%rsp), %rax
     ca5:      	movq	%rsp, %rdi
     ca8:      	movl	$0x8, %ecx
     cad:      	movl	$0x70, %r8d
     cb3:      	movzbl	0x1d(%r15), %edx
     cb8:      	addq	0x8(%rsp), %rdx
     cbd:      	movl	$0x8, %esi
     cc2:      	callq	*%r8
     cc5:      	testq	%rax, %rax
     cc8:      	jne	0x81b <kprobe_unwind_ruby+0x81b>
     cce:      	movl	(%rsp), %eax
     cd1:      	notl	%eax
     cd3:      	testl	$0x140, %eax            # imm = 0x140
     cd8:      	jne	0x997 <kprobe_unwind_ruby+0x997>
     cde:      	jmp	0x9e5 <kprobe_unwind_ruby+0x9e5>
     ce3:      	cmpl	$0x0, (%r15)
     ce7:      	jne	0x23fb <kprobe_unwind_ruby+0x23fb>
     ced:      	movl	$0xbbb, %r13d           # imm = 0xBBB
     cf3:      	xorl	%ebp, %ebp
     cf5:      	jmp	0x2b2 <kprobe_unwind_ruby+0x2b2>
     cfa:      	movzbl	0x23(%r15), %ecx
     cff:      	testq	%rcx, %rcx
     d02:      	je	0xdc2 <kprobe_unwind_ruby+0xdc2>
     d08:      	movq	0x18(%rsp), %rax
     d0d:      	subq	0x68(%rsp), %rax
     d12:      	xorl	%edx, %edx
     d14:      	divq	%rcx
     d17:      	movl	0x2c(%rsp), %ecx
     d1b:      	cmpq	%rcx, %rax
     d1e:      	jbe	0xdc2 <kprobe_unwind_ruby+0xdc2>
     d24:      	movq	(%rip), %rax            # 0xd2b <kprobe_unwind_ruby+0xd2b>
     d2b:      	cmpl	$0x0, (%rax)
     d2e:      	je	0x57c <kprobe_unwind_ruby+0x57c>
     d34:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
     d3e:      	movq	%rax, 0x55(%rsp)
     d43:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
     d4d:      	movq	%rax, 0x50(%rsp)
     d52:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
     d5c:      	movq	%rax, 0x48(%rsp)
     d61:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
     d6b:      	movq	%rax, 0x40(%rsp)
     d70:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
     d7a:      	movq	%rax, 0x38(%rsp)
     d7f:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
     d89:      	movq	%rax, 0x30(%rsp)
     d8e:      	leaq	0x30(%rsp), %rdi
     d93:      	movl	$0x2d, %eax
     d98:      	movl	$0x6, %ecx
     d9d:      	movl	$0x2d, %esi
     da2:      	xorl	%eax, %eax
     da4:      	callq	*%rcx
     da6:      	jmp	0x57c <kprobe_unwind_ruby+0x57c>
     dab:      	cmpl	$0x0, (%r15)
     daf:      	jne	0x2594 <kprobe_unwind_ruby+0x2594>
     db5:      	movl	$0xbbf, %r13d           # imm = 0xBBF
     dbb:      	xorl	%ebp, %ebp
     dbd:      	jmp	0x2b2 <kprobe_unwind_ruby+0x2b2>
     dc2:      	movl	0x2c0(%r14), %eax
     dc9:      	cmpq	$0x7f, %rax
     dcd:      	jb	0x106a <kprobe_unwind_ruby+0x106a>
     dd3:      	movq	(%rip), %r15            # 0xdda <kprobe_unwind_ruby+0xdda>
     dda:      	cmpl	$0x0, (%r15)
     dde:      	jne	0x2806 <kprobe_unwind_ruby+0x2806>
     de4:      	movl	$0x2, 0x74(%rsp)
     dec:      	movq	(%rip), %rdi            # 0xdf3 <kprobe_unwind_ruby+0xdf3>
     df3:      	leaq	0x74(%rsp), %rsi
     df8:      	movl	$0x1, %eax
     dfd:      	callq	*%rax
     dff:      	testq	%rax, %rax
     e02:      	je	0x1139 <kprobe_unwind_ruby+0x1139>
     e08:      	incq	(%rax)
     e0b:      	cmpl	$0x0, (%r15)
     e0f:      	movl	$0x2, %r13d
     e15:      	je	0x29ce <kprobe_unwind_ruby+0x29ce>
     e1b:      	movabsq	$0x6172662068737570, %rax # imm = 0x6172662068737570
     e25:      	movq	%rax, 0x40(%rsp)
     e2a:      	movabsq	$0x206f742064656c69, %rax # imm = 0x206F742064656C69
     e34:      	movq	%rax, 0x38(%rsp)
     e39:      	movabsq	$0x6166203a79627572, %rax # imm = 0x6166203A79627572
     e43:      	movq	%rax, 0x30(%rsp)
     e48:      	movl	$0xa656d, 0x48(%rsp)    # imm = 0xA656D
     e50:      	leaq	0x30(%rsp), %rdi
     e55:      	movl	$0x1c, %eax
     e5a:      	movl	$0x6, %ecx
     e5f:      	xorl	%ebp, %ebp
     e61:      	movl	$0x1c, %esi
     e66:      	xorl	%eax, %eax
     e68:      	callq	*%rcx
     e6a:      	jmp	0x2b2 <kprobe_unwind_ruby+0x2b2>
     e6f:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
     e76:      	jae	0x10e9 <kprobe_unwind_ruby+0x10e9>
     e7c:      	movq	0x8(%rsp), %rax
     e81:      	movq	%r12, %rcx
     e84:      	cmpq	%rax, %r12
     e87:      	jbe	0x2b2 <kprobe_unwind_ruby+0x2b2>
     e8d:      	movzbl	0x1e(%r15), %ecx
     e92:      	addq	%rcx, %rax
     e95:      	movq	%rax, 0x8(%rsp)
     e9a:      	movq	$0x0, 0x18(%rsp)
     ea3:      	movq	$0x0, 0x20(%rsp)
     eac:      	movzbl	0x1c(%r15), %ecx
     eb1:      	addq	%rax, %rcx
     eb4:      	leaq	0x20(%rsp), %rdi
     eb9:      	movl	$0x8, %eax
     ebe:      	movl	$0x70, %r8d
     ec4:      	movzbl	0x1c(%r15), %edx
     ec9:      	addq	0x8(%rsp), %rdx
     ece:      	movl	$0x8, %esi
     ed3:      	callq	*%r8
     ed6:      	movzbl	0x1b(%r15), %eax
     edb:      	addq	0x8(%rsp), %rax
     ee0:      	leaq	0x18(%rsp), %rdi
     ee5:      	movl	$0x8, %ecx
     eea:      	movl	$0x70, %r8d
     ef0:      	movzbl	0x1b(%r15), %edx
     ef5:      	addq	0x8(%rsp), %rdx
     efa:      	movl	$0x8, %esi
     eff:      	callq	*%r8
     f02:      	cmpq	$0x0, 0x18(%rsp)
     f08:      	je	0x1319 <kprobe_unwind_ruby+0x1319>
     f0e:      	movq	0x20(%rsp), %rax
     f13:      	testq	%rax, %rax
     f16:      	je	0x1319 <kprobe_unwind_ruby+0x1319>
     f1c:      	movzbl	0x1f(%r15), %ecx
     f21:      	addq	%rcx, %rax
     f24:      	leaq	0x10(%rsp), %rdi
     f29:      	movl	$0x8, %ecx
     f2e:      	movl	$0x70, %r8d
     f34:      	movzbl	0x1f(%r15), %edx
     f39:      	addq	0x20(%rsp), %rdx
     f3e:      	movl	$0x8, %esi
     f43:      	callq	*%r8
     f46:      	testq	%rax, %rax
     f49:      	jne	0x4c7 <kprobe_unwind_ruby+0x4c7>
     f4f:      	movzbl	0x21(%r15), %eax
     f54:      	addq	0x10(%rsp), %rax
     f59:      	leaq	0x68(%rsp), %rdi
     f5e:      	movl	$0x8, %ecx
     f63:      	movl	$0x70, %r8d
     f69:      	movzbl	0x21(%r15), %edx
     f6e:      	addq	0x10(%rsp), %rdx
     f73:      	movl	$0x8, %esi
     f78:      	callq	*%r8
     f7b:      	testq	%rax, %rax
     f7e:      	jne	0x8a4 <kprobe_unwind_ruby+0x8a4>
     f84:      	movzbl	0x22(%r15), %eax
     f89:      	addq	0x10(%rsp), %rax
     f8e:      	leaq	0x2c(%rsp), %rdi
     f93:      	movl	$0x4, %ecx
     f98:      	movl	$0x70, %r8d
     f9e:      	movzbl	0x22(%r15), %edx
     fa3:      	addq	0x10(%rsp), %rdx
     fa8:      	movl	$0x4, %esi
     fad:      	callq	*%r8
     fb0:      	testq	%rax, %rax
     fb3:      	jne	0xc08 <kprobe_unwind_ruby+0xc08>
     fb9:      	movzbl	0x23(%r15), %ecx
     fbe:      	testq	%rcx, %rcx
     fc1:      	je	0x1e2d <kprobe_unwind_ruby+0x1e2d>
     fc7:      	movq	0x18(%rsp), %rax
     fcc:      	subq	0x68(%rsp), %rax
     fd1:      	xorl	%edx, %edx
     fd3:      	divq	%rcx
     fd6:      	movl	0x2c(%rsp), %ecx
     fda:      	cmpq	%rcx, %rax
     fdd:      	jbe	0x1e2d <kprobe_unwind_ruby+0x1e2d>
     fe3:      	movq	(%rip), %rax            # 0xfea <kprobe_unwind_ruby+0xfea>
     fea:      	cmpl	$0x0, (%rax)
     fed:      	je	0x1326 <kprobe_unwind_ruby+0x1326>
     ff3:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
     ffd:      	movq	%rax, 0x55(%rsp)
    1002:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    100c:      	movq	%rax, 0x50(%rsp)
    1011:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    101b:      	movq	%rax, 0x48(%rsp)
    1020:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    102a:      	movq	%rax, 0x40(%rsp)
    102f:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    1039:      	movq	%rax, 0x38(%rsp)
    103e:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    1048:      	movq	%rax, 0x30(%rsp)
    104d:      	leaq	0x30(%rsp), %rdi
    1052:      	movl	$0x2d, %eax
    1057:      	movl	$0x6, %ecx
    105c:      	movl	$0x2d, %esi
    1061:      	xorl	%eax, %eax
    1063:      	callq	*%rcx
    1065:      	jmp	0x1326 <kprobe_unwind_ruby+0x1326>
    106a:      	movq	0x10(%rsp), %rcx
    106f:      	movq	0x18(%rsp), %rdx
    1074:      	leal	0x1(%rax), %esi
    1077:      	movl	%esi, 0x2c0(%r14)
    107e:      	leaq	(%rax,%rax,2), %rax
    1082:      	movw	$0x0, 0x4(%rsp)
    1089:      	movl	$0x0, (%rsp)
    1090:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    1098:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    10a0:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    10ab:      	movl	(%rsp), %ecx
    10ae:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    10b6:      	movzwl	0x4(%rsp), %ecx
    10bb:      	movw	%cx, 0x2e6(%r14,%rax,8)
    10c4:      	movl	$0x36, (%rsp)
    10cb:      	movq	(%rip), %rdi            # 0x10d2 <kprobe_unwind_ruby+0x10d2>
    10d2:      	movq	%rsp, %rsi
    10d5:      	movl	$0x1, %eax
    10da:      	callq	*%rax
    10dc:      	testq	%rax, %rax
    10df:      	je	0x1150 <kprobe_unwind_ruby+0x1150>
    10e1:      	incq	(%rax)
    10e4:      	jmp	0x57c <kprobe_unwind_ruby+0x57c>
    10e9:      	movq	$0x0, (%rsp)
    10f1:      	movzbl	0x1d(%r15), %eax
    10f6:      	addq	0x8(%rsp), %rax
    10fb:      	movq	%rsp, %rdi
    10fe:      	movl	$0x8, %ecx
    1103:      	movl	$0x70, %r8d
    1109:      	movzbl	0x1d(%r15), %edx
    110e:      	addq	0x8(%rsp), %rdx
    1113:      	movl	$0x8, %esi
    1118:      	callq	*%r8
    111b:      	testq	%rax, %rax
    111e:      	jne	0x81b <kprobe_unwind_ruby+0x81b>
    1124:      	movl	(%rsp), %eax
    1127:      	notl	%eax
    1129:      	testl	$0x140, %eax            # imm = 0x140
    112e:      	jne	0x997 <kprobe_unwind_ruby+0x997>
    1134:      	jmp	0xe7c <kprobe_unwind_ruby+0xe7c>
    1139:      	cmpl	$0x0, (%r15)
    113d:      	jne	0x2948 <kprobe_unwind_ruby+0x2948>
    1143:      	movl	$0x2, %r13d
    1149:      	xorl	%ebp, %ebp
    114b:      	jmp	0x2b2 <kprobe_unwind_ruby+0x2b2>
    1150:      	movq	(%rip), %rax            # 0x1157 <kprobe_unwind_ruby+0x1157>
    1157:      	cmpl	$0x0, (%rax)
    115a:      	je	0x57c <kprobe_unwind_ruby+0x57c>
    1160:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    116a:      	movq	%rax, 0x56(%rsp)
    116f:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1179:      	movq	%rax, 0x50(%rsp)
    117e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1188:      	movq	%rax, 0x48(%rsp)
    118d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1197:      	movq	%rax, 0x40(%rsp)
    119c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    11a6:      	movq	%rax, 0x38(%rsp)
    11ab:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    11b5:      	movq	%rax, 0x30(%rsp)
    11ba:      	leaq	0x30(%rsp), %rdi
    11bf:      	movl	$0x2e, %eax
    11c4:      	movl	$0x6, %ecx
    11c9:      	movl	(%rsp), %edx
    11cc:      	movl	$0x2e, %esi
    11d1:      	xorl	%eax, %eax
    11d3:      	callq	*%rcx
    11d5:      	jmp	0x57c <kprobe_unwind_ruby+0x57c>
    11da:      	movabsq	$0x6164206e6f697463, %rax # imm = 0x6164206E6F697463
    11e4:      	movq	%rax, 0x40(%rsp)
    11e9:      	movabsq	$0x6570736f72746e69, %rax # imm = 0x6570736F72746E69
    11f3:      	movq	%rax, 0x38(%rsp)
    11f8:      	movabsq	$0x2079627552206f4e, %rax # imm = 0x2079627552206F4E
    1202:      	movq	%rax, 0x30(%rsp)
    1207:      	movl	$0xa6174, 0x48(%rsp)    # imm = 0xA6174
    120f:      	leaq	0x30(%rsp), %rdi
    1214:      	movl	$0x1c, %eax
    1219:      	movl	$0x6, %ecx
    121e:      	movl	$0x1c, %esi
    1223:      	xorl	%eax, %eax
    1225:      	callq	*%rcx
    1227:      	jmp	0x11a <kprobe_unwind_ruby+0x11a>
    122c:      	movl	0x2c0(%r14), %eax
    1233:      	cmpq	$0x7e, %rax
    1237:      	ja	0xdd3 <kprobe_unwind_ruby+0xdd3>
    123d:      	movq	0x10(%rsp), %rcx
    1242:      	movq	0x18(%rsp), %rdx
    1247:      	leal	0x1(%rax), %esi
    124a:      	movl	%esi, 0x2c0(%r14)
    1251:      	leaq	(%rax,%rax,2), %rax
    1255:      	movw	$0x0, 0x4(%rsp)
    125c:      	movl	$0x0, (%rsp)
    1263:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    126b:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    1273:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    127e:      	movl	(%rsp), %ecx
    1281:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    1289:      	movzwl	0x4(%rsp), %ecx
    128e:      	movw	%cx, 0x2e6(%r14,%rax,8)
    1297:      	movl	$0x36, (%rsp)
    129e:      	movq	(%rip), %rdi            # 0x12a5 <kprobe_unwind_ruby+0x12a5>
    12a5:      	movq	%rsp, %rsi
    12a8:      	movl	$0x1, %eax
    12ad:      	callq	*%rax
    12af:      	testq	%rax, %rax
    12b2:      	je	0x17f1 <kprobe_unwind_ruby+0x17f1>
    12b8:      	incq	(%rax)
    12bb:      	jmp	0x9e5 <kprobe_unwind_ruby+0x9e5>
    12c0:      	movabsq	$0xa65756c617620, %rax  # imm = 0xA65756C617620
    12ca:      	movq	%rax, 0x45(%rsp)
    12cf:      	movabsq	$0x6176206573616270, %rax # imm = 0x6176206573616270
    12d9:      	movq	%rax, 0x40(%rsp)
    12de:      	movabsq	$0x742064616572206f, %rax # imm = 0x742064616572206F
    12e8:      	movq	%rax, 0x38(%rsp)
    12ed:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    12f7:      	movq	%rax, 0x30(%rsp)
    12fc:      	leaq	0x30(%rsp), %rdi
    1301:      	movl	$0x1d, %eax
    1306:      	movl	$0x6, %ecx
    130b:      	movl	$0x1d, %esi
    1310:      	xorl	%eax, %eax
    1312:      	callq	*%rcx
    1314:      	jmp	0x1af <kprobe_unwind_ruby+0x1af>
    1319:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    1320:      	jae	0x16a2 <kprobe_unwind_ruby+0x16a2>
    1326:      	movq	0x8(%rsp), %rax
    132b:      	cmpq	%rax, %r12
    132e:      	jbe	0x2b2 <kprobe_unwind_ruby+0x2b2>
    1334:      	movzbl	0x1e(%r15), %ecx
    1339:      	addq	%rcx, %rax
    133c:      	movq	%rax, 0x8(%rsp)
    1341:      	movq	$0x0, 0x18(%rsp)
    134a:      	movq	$0x0, 0x20(%rsp)
    1353:      	movzbl	0x1c(%r15), %ecx
    1358:      	addq	%rax, %rcx
    135b:      	leaq	0x20(%rsp), %rdi
    1360:      	movl	$0x8, %eax
    1365:      	movl	$0x70, %r8d
    136b:      	movzbl	0x1c(%r15), %edx
    1370:      	addq	0x8(%rsp), %rdx
    1375:      	movl	$0x8, %esi
    137a:      	callq	*%r8
    137d:      	movzbl	0x1b(%r15), %eax
    1382:      	addq	0x8(%rsp), %rax
    1387:      	leaq	0x18(%rsp), %rdi
    138c:      	movl	$0x8, %ecx
    1391:      	movl	$0x70, %r8d
    1397:      	movzbl	0x1b(%r15), %edx
    139c:      	addq	0x8(%rsp), %rdx
    13a1:      	movl	$0x8, %esi
    13a6:      	callq	*%r8
    13a9:      	cmpq	$0x0, 0x18(%rsp)
    13af:      	je	0x1974 <kprobe_unwind_ruby+0x1974>
    13b5:      	movq	0x20(%rsp), %rax
    13ba:      	testq	%rax, %rax
    13bd:      	je	0x1974 <kprobe_unwind_ruby+0x1974>
    13c3:      	movzbl	0x1f(%r15), %ecx
    13c8:      	addq	%rcx, %rax
    13cb:      	leaq	0x10(%rsp), %rdi
    13d0:      	movl	$0x8, %ecx
    13d5:      	movl	$0x70, %r8d
    13db:      	movzbl	0x1f(%r15), %edx
    13e0:      	addq	0x20(%rsp), %rdx
    13e5:      	movl	$0x8, %esi
    13ea:      	callq	*%r8
    13ed:      	testq	%rax, %rax
    13f0:      	jne	0x4c7 <kprobe_unwind_ruby+0x4c7>
    13f6:      	movzbl	0x21(%r15), %eax
    13fb:      	addq	0x10(%rsp), %rax
    1400:      	leaq	0x68(%rsp), %rdi
    1405:      	movl	$0x8, %ecx
    140a:      	movl	$0x70, %r8d
    1410:      	movzbl	0x21(%r15), %edx
    1415:      	addq	0x10(%rsp), %rdx
    141a:      	movl	$0x8, %esi
    141f:      	callq	*%r8
    1422:      	testq	%rax, %rax
    1425:      	jne	0x8a4 <kprobe_unwind_ruby+0x8a4>
    142b:      	movzbl	0x22(%r15), %eax
    1430:      	addq	0x10(%rsp), %rax
    1435:      	leaq	0x2c(%rsp), %rdi
    143a:      	movl	$0x4, %ecx
    143f:      	movl	$0x70, %r8d
    1445:      	movzbl	0x22(%r15), %edx
    144a:      	addq	0x10(%rsp), %rdx
    144f:      	movl	$0x4, %esi
    1454:      	callq	*%r8
    1457:      	testq	%rax, %rax
    145a:      	jne	0xc08 <kprobe_unwind_ruby+0xc08>
    1460:      	movzbl	0x23(%r15), %ecx
    1465:      	testq	%rcx, %rcx
    1468:      	je	0x2500 <kprobe_unwind_ruby+0x2500>
    146e:      	movq	0x18(%rsp), %rax
    1473:      	subq	0x68(%rsp), %rax
    1478:      	xorl	%edx, %edx
    147a:      	divq	%rcx
    147d:      	movl	0x2c(%rsp), %ecx
    1481:      	cmpq	%rcx, %rax
    1484:      	jbe	0x2500 <kprobe_unwind_ruby+0x2500>
    148a:      	movq	(%rip), %rax            # 0x1491 <kprobe_unwind_ruby+0x1491>
    1491:      	cmpl	$0x0, (%rax)
    1494:      	je	0x1981 <kprobe_unwind_ruby+0x1981>
    149a:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    14a4:      	movq	%rax, 0x55(%rsp)
    14a9:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    14b3:      	movq	%rax, 0x50(%rsp)
    14b8:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    14c2:      	movq	%rax, 0x48(%rsp)
    14c7:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    14d1:      	movq	%rax, 0x40(%rsp)
    14d6:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    14e0:      	movq	%rax, 0x38(%rsp)
    14e5:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    14ef:      	movq	%rax, 0x30(%rsp)
    14f4:      	leaq	0x30(%rsp), %rdi
    14f9:      	movl	$0x2d, %eax
    14fe:      	movl	$0x6, %ecx
    1503:      	movl	$0x2d, %esi
    1508:      	xorl	%eax, %eax
    150a:      	callq	*%rcx
    150c:      	jmp	0x1981 <kprobe_unwind_ruby+0x1981>
    1511:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    151b:      	movq	%rax, 0x56(%rsp)
    1520:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    152a:      	movq	%rax, 0x50(%rsp)
    152f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1539:      	movq	%rax, 0x48(%rsp)
    153e:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1548:      	movq	%rax, 0x40(%rsp)
    154d:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1557:      	movq	%rax, 0x38(%rsp)
    155c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1566:      	movq	%rax, 0x30(%rsp)
    156b:      	leaq	0x30(%rsp), %rdi
    1570:      	movl	$0x2e, %eax
    1575:      	movl	$0x6, %ecx
    157a:      	movl	0x8(%rsp), %edx
    157e:      	movl	$0x2e, %esi
    1583:      	xorl	%eax, %eax
    1585:      	callq	*%rcx
    1587:      	movq	$0x0, 0x78(%rsp)
    1590:      	cmpq	$0x0, 0x8(%r15)
    1595:      	jne	0x16a <kprobe_unwind_ruby+0x16a>
    159b:      	jmp	0xa1 <kprobe_unwind_ruby+0xa1>
    15a0:      	movabsq	$0xa786c6c25783020, %rax # imm = 0xA786C6C25783020
    15aa:      	movq	%rax, 0x58(%rsp)
    15af:      	movabsq	$0x6d6f726620786c6c, %rax # imm = 0x6D6F726620786C6C
    15b9:      	movq	%rax, 0x50(%rsp)
    15be:      	movabsq	$0x2578302072646461, %rax # imm = 0x2578302072646461
    15c8:      	movq	%rax, 0x48(%rsp)
    15cd:      	movabsq	$0x206c6f626d797320, %rax # imm = 0x206C6F626D797320
    15d7:      	movq	%rax, 0x40(%rsp)
    15dc:      	movabsq	$0x434520534c542074, %rax # imm = 0x434520534C542074
    15e6:      	movq	%rax, 0x38(%rsp)
    15eb:      	movabsq	$0x6f67203a79627572, %rax # imm = 0x6F67203A79627572
    15f5:      	movq	%rax, 0x30(%rsp)
    15fa:      	movb	$0x0, 0x60(%rsp)
    15ff:      	leaq	0x30(%rsp), %rdi
    1604:      	movl	$0x31, %eax
    1609:      	movl	$0x6, %r8d
    160f:      	movl	$0x31, %esi
    1614:      	movq	%rdx, %r12
    1617:      	movq	%rdx, %rcx
    161a:      	xorl	%eax, %eax
    161c:      	callq	*%r8
    161f:      	movq	%r12, %rdx
    1622:      	jmp	0x279 <kprobe_unwind_ruby+0x279>
    1627:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1631:      	movq	%rax, 0x56(%rsp)
    1636:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1640:      	movq	%rax, 0x50(%rsp)
    1645:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    164f:      	movq	%rax, 0x48(%rsp)
    1654:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    165e:      	movq	%rax, 0x40(%rsp)
    1663:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    166d:      	movq	%rax, 0x38(%rsp)
    1672:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    167c:      	movq	%rax, 0x30(%rsp)
    1681:      	leaq	0x30(%rsp), %rdi
    1686:      	movl	$0x2e, %eax
    168b:      	movl	$0x6, %ecx
    1690:      	movl	0x8(%rsp), %edx
    1694:      	movl	$0x2e, %esi
    1699:      	xorl	%eax, %eax
    169b:      	callq	*%rcx
    169d:      	jmp	0x2a7 <kprobe_unwind_ruby+0x2a7>
    16a2:      	movq	$0x0, (%rsp)
    16aa:      	movzbl	0x1d(%r15), %eax
    16af:      	addq	0x8(%rsp), %rax
    16b4:      	movq	%rsp, %rdi
    16b7:      	movl	$0x8, %ecx
    16bc:      	movl	$0x70, %r8d
    16c2:      	movzbl	0x1d(%r15), %edx
    16c7:      	addq	0x8(%rsp), %rdx
    16cc:      	movl	$0x8, %esi
    16d1:      	callq	*%r8
    16d4:      	testq	%rax, %rax
    16d7:      	jne	0x81b <kprobe_unwind_ruby+0x81b>
    16dd:      	movl	(%rsp), %eax
    16e0:      	notl	%eax
    16e2:      	testl	$0x140, %eax            # imm = 0x140
    16e7:      	jne	0x997 <kprobe_unwind_ruby+0x997>
    16ed:      	jmp	0x1326 <kprobe_unwind_ruby+0x1326>
    16f2:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    16fc:      	movq	%rax, 0x56(%rsp)
    1701:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    170b:      	movq	%rax, 0x50(%rsp)
    1710:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    171a:      	movq	%rax, 0x48(%rsp)
    171f:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1729:      	movq	%rax, 0x40(%rsp)
    172e:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1738:      	movq	%rax, 0x38(%rsp)
    173d:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1747:      	movq	%rax, 0x30(%rsp)
    174c:      	leaq	0x30(%rsp), %rdi
    1751:      	movl	$0x2e, %eax
    1756:      	movl	$0x6, %ecx
    175b:      	movl	0x20(%rsp), %edx
    175f:      	movl	$0x2e, %esi
    1764:      	xorl	%eax, %eax
    1766:      	callq	*%rcx
    1768:      	cmpl	$0x0, (%rbx)
    176b:      	je	0x37c <kprobe_unwind_ruby+0x37c>
    1771:      	jmp	0x1df <kprobe_unwind_ruby+0x1df>
    1776:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1780:      	movq	%rax, 0x56(%rsp)
    1785:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    178f:      	movq	%rax, 0x50(%rsp)
    1794:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    179e:      	movq	%rax, 0x48(%rsp)
    17a3:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    17ad:      	movq	%rax, 0x40(%rsp)
    17b2:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    17bc:      	movq	%rax, 0x38(%rsp)
    17c1:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    17cb:      	movq	%rax, 0x30(%rsp)
    17d0:      	leaq	0x30(%rsp), %rdi
    17d5:      	movl	$0x2e, %eax
    17da:      	movl	$0x6, %ecx
    17df:      	movl	0x8(%rsp), %edx
    17e3:      	movl	$0x2e, %esi
    17e8:      	xorl	%eax, %eax
    17ea:      	callq	*%rcx
    17ec:      	jmp	0x390 <kprobe_unwind_ruby+0x390>
    17f1:      	movq	(%rip), %rax            # 0x17f8 <kprobe_unwind_ruby+0x17f8>
    17f8:      	cmpl	$0x0, (%rax)
    17fb:      	je	0x9e5 <kprobe_unwind_ruby+0x9e5>
    1801:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    180b:      	movq	%rax, 0x56(%rsp)
    1810:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    181a:      	movq	%rax, 0x50(%rsp)
    181f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1829:      	movq	%rax, 0x48(%rsp)
    182e:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1838:      	movq	%rax, 0x40(%rsp)
    183d:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1847:      	movq	%rax, 0x38(%rsp)
    184c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1856:      	movq	%rax, 0x30(%rsp)
    185b:      	leaq	0x30(%rsp), %rdi
    1860:      	movl	$0x2e, %eax
    1865:      	movl	$0x6, %ecx
    186a:      	movl	(%rsp), %edx
    186d:      	movl	$0x2e, %esi
    1872:      	xorl	%eax, %eax
    1874:      	callq	*%rcx
    1876:      	jmp	0x9e5 <kprobe_unwind_ruby+0x9e5>
    187b:      	movabsq	$0x6c6c257830203a53, %rax # imm = 0x6C6C257830203A53
    1885:      	movq	%rax, 0x40(%rsp)
    188a:      	movabsq	$0x4c54206d6f726620, %rax # imm = 0x4C54206D6F726620
    1894:      	movq	%rax, 0x38(%rsp)
    1899:      	movabsq	$0x4345203a79627572, %rax # imm = 0x4345203A79627572
    18a3:      	movq	%rax, 0x30(%rsp)
    18a8:      	movl	$0xa786c, 0x47(%rsp)    # imm = 0xA786C
    18b0:      	leaq	0x30(%rsp), %rdi
    18b5:      	movl	$0x1b, %eax
    18ba:      	movl	$0x6, %ecx
    18bf:      	movq	0x78(%rsp), %rdx
    18c4:      	movl	$0x1b, %esi
    18c9:      	xorl	%eax, %eax
    18cb:      	callq	*%rcx
    18cd:      	movq	0x78(%rsp), %r12
    18d2:      	testq	%r12, %r12
    18d5:      	jne	0x3ea <kprobe_unwind_ruby+0x3ea>
    18db:      	jmp	0x298 <kprobe_unwind_ruby+0x298>
    18e0:      	movl	0x2c0(%r14), %eax
    18e7:      	cmpq	$0x7e, %rax
    18eb:      	ja	0xdd3 <kprobe_unwind_ruby+0xdd3>
    18f1:      	movq	0x10(%rsp), %rcx
    18f6:      	movq	0x18(%rsp), %rdx
    18fb:      	leal	0x1(%rax), %esi
    18fe:      	movl	%esi, 0x2c0(%r14)
    1905:      	leaq	(%rax,%rax,2), %rax
    1909:      	movw	$0x0, 0x4(%rsp)
    1910:      	movl	$0x0, (%rsp)
    1917:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    191f:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    1927:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    1932:      	movl	(%rsp), %ecx
    1935:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    193d:      	movzwl	0x4(%rsp), %ecx
    1942:      	movw	%cx, 0x2e6(%r14,%rax,8)
    194b:      	movl	$0x36, (%rsp)
    1952:      	movq	(%rip), %rdi            # 0x1959 <kprobe_unwind_ruby+0x1959>
    1959:      	movq	%rsp, %rsi
    195c:      	movl	$0x1, %eax
    1961:      	callq	*%rax
    1963:      	testq	%rax, %rax
    1966:      	je	0x1da3 <kprobe_unwind_ruby+0x1da3>
    196c:      	incq	(%rax)
    196f:      	jmp	0xe7c <kprobe_unwind_ruby+0xe7c>
    1974:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    197b:      	jae	0x1c35 <kprobe_unwind_ruby+0x1c35>
    1981:      	movq	0x8(%rsp), %rax
    1986:      	cmpq	%rax, %r12
    1989:      	jbe	0x2b2 <kprobe_unwind_ruby+0x2b2>
    198f:      	movzbl	0x1e(%r15), %ecx
    1994:      	addq	%rcx, %rax
    1997:      	movq	%rax, 0x8(%rsp)
    199c:      	movq	$0x0, 0x18(%rsp)
    19a5:      	movq	$0x0, 0x20(%rsp)
    19ae:      	movzbl	0x1c(%r15), %ecx
    19b3:      	addq	%rax, %rcx
    19b6:      	leaq	0x20(%rsp), %rdi
    19bb:      	movl	$0x8, %eax
    19c0:      	movl	$0x70, %r8d
    19c6:      	movzbl	0x1c(%r15), %edx
    19cb:      	addq	0x8(%rsp), %rdx
    19d0:      	movl	$0x8, %esi
    19d5:      	callq	*%r8
    19d8:      	movzbl	0x1b(%r15), %eax
    19dd:      	addq	0x8(%rsp), %rax
    19e2:      	leaq	0x18(%rsp), %rdi
    19e7:      	movl	$0x8, %ecx
    19ec:      	movl	$0x70, %r8d
    19f2:      	movzbl	0x1b(%r15), %edx
    19f7:      	addq	0x8(%rsp), %rdx
    19fc:      	movl	$0x8, %esi
    1a01:      	callq	*%r8
    1a04:      	cmpq	$0x0, 0x18(%rsp)
    1a0a:      	je	0x1f9b <kprobe_unwind_ruby+0x1f9b>
    1a10:      	movq	0x20(%rsp), %rax
    1a15:      	testq	%rax, %rax
    1a18:      	je	0x1f9b <kprobe_unwind_ruby+0x1f9b>
    1a1e:      	movzbl	0x1f(%r15), %ecx
    1a23:      	addq	%rcx, %rax
    1a26:      	leaq	0x10(%rsp), %rdi
    1a2b:      	movl	$0x8, %ecx
    1a30:      	movl	$0x70, %r8d
    1a36:      	movzbl	0x1f(%r15), %edx
    1a3b:      	addq	0x20(%rsp), %rdx
    1a40:      	movl	$0x8, %esi
    1a45:      	callq	*%r8
    1a48:      	testq	%rax, %rax
    1a4b:      	jne	0x4c7 <kprobe_unwind_ruby+0x4c7>
    1a51:      	movzbl	0x21(%r15), %eax
    1a56:      	addq	0x10(%rsp), %rax
    1a5b:      	leaq	0x68(%rsp), %rdi
    1a60:      	movl	$0x8, %ecx
    1a65:      	movl	$0x70, %r8d
    1a6b:      	movzbl	0x21(%r15), %edx
    1a70:      	addq	0x10(%rsp), %rdx
    1a75:      	movl	$0x8, %esi
    1a7a:      	callq	*%r8
    1a7d:      	testq	%rax, %rax
    1a80:      	jne	0x8a4 <kprobe_unwind_ruby+0x8a4>
    1a86:      	movzbl	0x22(%r15), %eax
    1a8b:      	addq	0x10(%rsp), %rax
    1a90:      	leaq	0x2c(%rsp), %rdi
    1a95:      	movl	$0x4, %ecx
    1a9a:      	movl	$0x70, %r8d
    1aa0:      	movzbl	0x22(%r15), %edx
    1aa5:      	addq	0x10(%rsp), %rdx
    1aaa:      	movl	$0x4, %esi
    1aaf:      	callq	*%r8
    1ab2:      	testq	%rax, %rax
    1ab5:      	jne	0xc08 <kprobe_unwind_ruby+0xc08>
    1abb:      	movzbl	0x23(%r15), %ecx
    1ac0:      	testq	%rcx, %rcx
    1ac3:      	je	0x29d5 <kprobe_unwind_ruby+0x29d5>
    1ac9:      	movq	0x18(%rsp), %rax
    1ace:      	subq	0x68(%rsp), %rax
    1ad3:      	xorl	%edx, %edx
    1ad5:      	divq	%rcx
    1ad8:      	movl	0x2c(%rsp), %ecx
    1adc:      	cmpq	%rcx, %rax
    1adf:      	jbe	0x29d5 <kprobe_unwind_ruby+0x29d5>
    1ae5:      	movq	(%rip), %rax            # 0x1aec <kprobe_unwind_ruby+0x1aec>
    1aec:      	cmpl	$0x0, (%rax)
    1aef:      	je	0x1fa8 <kprobe_unwind_ruby+0x1fa8>
    1af5:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    1aff:      	movq	%rax, 0x55(%rsp)
    1b04:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    1b0e:      	movq	%rax, 0x50(%rsp)
    1b13:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    1b1d:      	movq	%rax, 0x48(%rsp)
    1b22:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    1b2c:      	movq	%rax, 0x40(%rsp)
    1b31:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    1b3b:      	movq	%rax, 0x38(%rsp)
    1b40:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    1b4a:      	movq	%rax, 0x30(%rsp)
    1b4f:      	leaq	0x30(%rsp), %rdi
    1b54:      	movl	$0x2d, %eax
    1b59:      	movl	$0x6, %ecx
    1b5e:      	movl	$0x2d, %esi
    1b63:      	xorl	%eax, %eax
    1b65:      	callq	*%rcx
    1b67:      	jmp	0x1fa8 <kprobe_unwind_ruby+0x1fa8>
    1b6c:      	movabsq	$0x746e696f70206b63, %rax # imm = 0x746E696F70206B63
    1b76:      	movq	%rax, 0x50(%rsp)
    1b7b:      	movabsq	$0x61747320746e6572, %rax # imm = 0x61747320746E6572
    1b85:      	movq	%rax, 0x48(%rsp)
    1b8a:      	movabsq	$0x7275632064616572, %rax # imm = 0x7275632064616572
    1b94:      	movq	%rax, 0x40(%rsp)
    1b99:      	movabsq	$0x206f742064656c69, %rax # imm = 0x206F742064656C69
    1ba3:      	movq	%rax, 0x38(%rsp)
    1ba8:      	movabsq	$0x6166203a79627572, %rax # imm = 0x6166203A79627572
    1bb2:      	movq	%rax, 0x30(%rsp)
    1bb7:      	movl	$0xa7265, 0x58(%rsp)    # imm = 0xA7265
    1bbf:      	leaq	0x30(%rsp), %rdi
    1bc4:      	movl	$0x2c, %eax
    1bc9:      	movl	$0x6, %ecx
    1bce:      	movl	$0x2c, %esi
    1bd3:      	xorl	%eax, %eax
    1bd5:      	callq	*%rcx
    1bd7:      	jmp	0x543 <kprobe_unwind_ruby+0x543>
    1bdc:      	movabsq	$0xa79646f622071, %rax  # imm = 0xA79646F622071
    1be6:      	movq	%rax, 0x47(%rsp)
    1beb:      	movabsq	$0x7165736920746567, %rax # imm = 0x7165736920746567
    1bf5:      	movq	%rax, 0x40(%rsp)
    1bfa:      	movabsq	$0x206f742064656c69, %rax # imm = 0x206F742064656C69
    1c04:      	movq	%rax, 0x38(%rsp)
    1c09:      	movabsq	$0x6166203a79627572, %rax # imm = 0x6166203A79627572
    1c13:      	movq	%rax, 0x30(%rsp)
    1c18:      	leaq	0x30(%rsp), %rdi
    1c1d:      	movl	$0x1f, %eax
    1c22:      	movl	$0x6, %ecx
    1c27:      	movl	$0x1f, %esi
    1c2c:      	xorl	%eax, %eax
    1c2e:      	callq	*%rcx
    1c30:      	jmp	0x4d8 <kprobe_unwind_ruby+0x4d8>
    1c35:      	movq	$0x0, (%rsp)
    1c3d:      	movzbl	0x1d(%r15), %eax
    1c42:      	addq	0x8(%rsp), %rax
    1c47:      	movq	%rsp, %rdi
    1c4a:      	movl	$0x8, %ecx
    1c4f:      	movl	$0x70, %r8d
    1c55:      	movzbl	0x1d(%r15), %edx
    1c5a:      	addq	0x8(%rsp), %rdx
    1c5f:      	movl	$0x8, %esi
    1c64:      	callq	*%r8
    1c67:      	testq	%rax, %rax
    1c6a:      	jne	0x81b <kprobe_unwind_ruby+0x81b>
    1c70:      	movl	(%rsp), %eax
    1c73:      	notl	%eax
    1c75:      	testl	$0x140, %eax            # imm = 0x140
    1c7a:      	jne	0x997 <kprobe_unwind_ruby+0x997>
    1c80:      	jmp	0x1981 <kprobe_unwind_ruby+0x1981>
    1c85:      	movabsq	$0xa657a6973206b, %rax  # imm = 0xA657A6973206B
    1c8f:      	movq	%rax, 0x48(%rsp)
    1c94:      	movabsq	$0x6361747320746567, %rax # imm = 0x6361747320746567
    1c9e:      	movq	%rax, 0x40(%rsp)
    1ca3:      	movabsq	$0x206f742064656c69, %rax # imm = 0x206F742064656C69
    1cad:      	movq	%rax, 0x38(%rsp)
    1cb2:      	movabsq	$0x6166203a79627572, %rax # imm = 0x6166203A79627572
    1cbc:      	movq	%rax, 0x30(%rsp)
    1cc1:      	leaq	0x30(%rsp), %rdi
    1cc6:      	movl	$0x20, %eax
    1ccb:      	movl	$0x6, %ecx
    1cd0:      	movl	$0x20, %esi
    1cd5:      	xorl	%eax, %eax
    1cd7:      	callq	*%rcx
    1cd9:      	jmp	0x7b4 <kprobe_unwind_ruby+0x7b4>
    1cde:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1ce8:      	movq	%rax, 0x56(%rsp)
    1ced:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1cf7:      	movq	%rax, 0x50(%rsp)
    1cfc:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1d06:      	movq	%rax, 0x48(%rsp)
    1d0b:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1d15:      	movq	%rax, 0x40(%rsp)
    1d1a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1d24:      	movq	%rax, 0x38(%rsp)
    1d29:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1d33:      	movq	%rax, 0x30(%rsp)
    1d38:      	leaq	0x30(%rsp), %rdi
    1d3d:      	movl	$0x2e, %eax
    1d42:      	movl	$0x6, %ecx
    1d47:      	movl	0x18(%rsp), %edx
    1d4b:      	movl	$0x2e, %esi
    1d50:      	xorl	%eax, %eax
    1d52:      	callq	*%rcx
    1d54:      	jmp	0x862 <kprobe_unwind_ruby+0x862>
    1d59:      	movabsq	$0xa706520746567, %rax  # imm = 0xA706520746567
    1d63:      	movq	%rax, 0x40(%rsp)
    1d68:      	movabsq	$0x206f742064656c69, %rax # imm = 0x206F742064656C69
    1d72:      	movq	%rax, 0x38(%rsp)
    1d77:      	movabsq	$0x6166203a79627572, %rax # imm = 0x6166203A79627572
    1d81:      	movq	%rax, 0x30(%rsp)
    1d86:      	leaq	0x30(%rsp), %rdi
    1d8b:      	movl	$0x18, %eax
    1d90:      	movl	$0x6, %ecx
    1d95:      	movl	$0x18, %esi
    1d9a:      	xorl	%eax, %eax
    1d9c:      	callq	*%rcx
    1d9e:      	jmp	0x82c <kprobe_unwind_ruby+0x82c>
    1da3:      	movq	(%rip), %rax            # 0x1daa <kprobe_unwind_ruby+0x1daa>
    1daa:      	cmpl	$0x0, (%rax)
    1dad:      	je	0xe7c <kprobe_unwind_ruby+0xe7c>
    1db3:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1dbd:      	movq	%rax, 0x56(%rsp)
    1dc2:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1dcc:      	movq	%rax, 0x50(%rsp)
    1dd1:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1ddb:      	movq	%rax, 0x48(%rsp)
    1de0:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1dea:      	movq	%rax, 0x40(%rsp)
    1def:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1df9:      	movq	%rax, 0x38(%rsp)
    1dfe:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1e08:      	movq	%rax, 0x30(%rsp)
    1e0d:      	leaq	0x30(%rsp), %rdi
    1e12:      	movl	$0x2e, %eax
    1e17:      	movl	$0x6, %ecx
    1e1c:      	movl	(%rsp), %edx
    1e1f:      	movl	$0x2e, %esi
    1e24:      	xorl	%eax, %eax
    1e26:      	callq	*%rcx
    1e28:      	jmp	0xe7c <kprobe_unwind_ruby+0xe7c>
    1e2d:      	movl	0x2c0(%r14), %eax
    1e34:      	cmpq	$0x7e, %rax
    1e38:      	ja	0xdd3 <kprobe_unwind_ruby+0xdd3>
    1e3e:      	movq	0x10(%rsp), %rcx
    1e43:      	movq	0x18(%rsp), %rdx
    1e48:      	leal	0x1(%rax), %esi
    1e4b:      	movl	%esi, 0x2c0(%r14)
    1e52:      	leaq	(%rax,%rax,2), %rax
    1e56:      	movw	$0x0, 0x4(%rsp)
    1e5d:      	movl	$0x0, (%rsp)
    1e64:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    1e6c:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    1e74:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    1e7f:      	movl	(%rsp), %ecx
    1e82:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    1e8a:      	movzwl	0x4(%rsp), %ecx
    1e8f:      	movw	%cx, 0x2e6(%r14,%rax,8)
    1e98:      	movl	$0x36, (%rsp)
    1e9f:      	movq	(%rip), %rdi            # 0x1ea6 <kprobe_unwind_ruby+0x1ea6>
    1ea6:      	movq	%rsp, %rsi
    1ea9:      	movl	$0x1, %eax
    1eae:      	callq	*%rax
    1eb0:      	testq	%rax, %rax
    1eb3:      	je	0x2476 <kprobe_unwind_ruby+0x2476>
    1eb9:      	incq	(%rax)
    1ebc:      	jmp	0x1326 <kprobe_unwind_ruby+0x1326>
    1ec1:      	movabsq	$0x6465646f636e6520, %rax # imm = 0x6465646F636E6520
    1ecb:      	movq	%rax, 0x48(%rsp)
    1ed0:      	movabsq	$0x7165736920746567, %rax # imm = 0x7165736920746567
    1eda:      	movq	%rax, 0x40(%rsp)
    1edf:      	movabsq	$0x206f742064656c69, %rax # imm = 0x206F742064656C69
    1ee9:      	movq	%rax, 0x38(%rsp)
    1eee:      	movabsq	$0x6166203a79627572, %rax # imm = 0x6166203A79627572
    1ef8:      	movq	%rax, 0x30(%rsp)
    1efd:      	movw	$0xa, 0x50(%rsp)
    1f04:      	leaq	0x30(%rsp), %rdi
    1f09:      	movl	$0x22, %eax
    1f0e:      	movl	$0x6, %ecx
    1f13:      	movl	$0x22, %esi
    1f18:      	xorl	%eax, %eax
    1f1a:      	callq	*%rcx
    1f1c:      	jmp	0x8b5 <kprobe_unwind_ruby+0x8b5>
    1f21:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1f2b:      	movq	%rax, 0x56(%rsp)
    1f30:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1f3a:      	movq	%rax, 0x50(%rsp)
    1f3f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1f49:      	movq	%rax, 0x48(%rsp)
    1f4e:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1f58:      	movq	%rax, 0x40(%rsp)
    1f5d:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1f67:      	movq	%rax, 0x38(%rsp)
    1f6c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1f76:      	movq	%rax, 0x30(%rsp)
    1f7b:      	leaq	0x30(%rsp), %rdi
    1f80:      	movl	$0x2e, %eax
    1f85:      	movl	$0x6, %ecx
    1f8a:      	movl	(%rsp), %edx
    1f8d:      	movl	$0x2e, %esi
    1f92:      	xorl	%eax, %eax
    1f94:      	callq	*%rcx
    1f96:      	jmp	0x8e8 <kprobe_unwind_ruby+0x8e8>
    1f9b:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    1fa2:      	jae	0x23ab <kprobe_unwind_ruby+0x23ab>
    1fa8:      	movq	0x8(%rsp), %rax
    1fad:      	cmpq	%rax, %r12
    1fb0:      	jbe	0x2b2 <kprobe_unwind_ruby+0x2b2>
    1fb6:      	movzbl	0x1e(%r15), %ecx
    1fbb:      	addq	%rcx, %rax
    1fbe:      	movq	%rax, 0x8(%rsp)
    1fc3:      	movq	$0x0, 0x18(%rsp)
    1fcc:      	movq	$0x0, 0x20(%rsp)
    1fd5:      	movzbl	0x1c(%r15), %ecx
    1fda:      	addq	%rax, %rcx
    1fdd:      	leaq	0x20(%rsp), %rdi
    1fe2:      	movl	$0x8, %eax
    1fe7:      	movl	$0x70, %r8d
    1fed:      	movzbl	0x1c(%r15), %edx
    1ff2:      	addq	0x8(%rsp), %rdx
    1ff7:      	movl	$0x8, %esi
    1ffc:      	callq	*%r8
    1fff:      	movzbl	0x1b(%r15), %eax
    2004:      	addq	0x8(%rsp), %rax
    2009:      	leaq	0x18(%rsp), %rdi
    200e:      	movl	$0x8, %ecx
    2013:      	movl	$0x70, %r8d
    2019:      	movzbl	0x1b(%r15), %edx
    201e:      	addq	0x8(%rsp), %rdx
    2023:      	movl	$0x8, %esi
    2028:      	callq	*%r8
    202b:      	cmpq	$0x0, 0x18(%rsp)
    2031:      	je	0x260e <kprobe_unwind_ruby+0x260e>
    2037:      	movq	0x20(%rsp), %rax
    203c:      	testq	%rax, %rax
    203f:      	je	0x260e <kprobe_unwind_ruby+0x260e>
    2045:      	movzbl	0x1f(%r15), %ecx
    204a:      	addq	%rcx, %rax
    204d:      	leaq	0x10(%rsp), %rdi
    2052:      	movl	$0x8, %ecx
    2057:      	movl	$0x70, %r8d
    205d:      	movzbl	0x1f(%r15), %edx
    2062:      	addq	0x20(%rsp), %rdx
    2067:      	movl	$0x8, %esi
    206c:      	callq	*%r8
    206f:      	testq	%rax, %rax
    2072:      	jne	0x4c7 <kprobe_unwind_ruby+0x4c7>
    2078:      	movzbl	0x21(%r15), %eax
    207d:      	addq	0x10(%rsp), %rax
    2082:      	leaq	0x68(%rsp), %rdi
    2087:      	movl	$0x8, %ecx
    208c:      	movl	$0x70, %r8d
    2092:      	movzbl	0x21(%r15), %edx
    2097:      	addq	0x10(%rsp), %rdx
    209c:      	movl	$0x8, %esi
    20a1:      	callq	*%r8
    20a4:      	testq	%rax, %rax
    20a7:      	jne	0x8a4 <kprobe_unwind_ruby+0x8a4>
    20ad:      	movzbl	0x22(%r15), %eax
    20b2:      	addq	0x10(%rsp), %rax
    20b7:      	leaq	0x2c(%rsp), %rdi
    20bc:      	movl	$0x4, %ecx
    20c1:      	movl	$0x70, %r8d
    20c7:      	movzbl	0x22(%r15), %edx
    20cc:      	addq	0x10(%rsp), %rdx
    20d1:      	movl	$0x4, %esi
    20d6:      	callq	*%r8
    20d9:      	testq	%rax, %rax
    20dc:      	jne	0xc08 <kprobe_unwind_ruby+0xc08>
    20e2:      	movzbl	0x23(%r15), %ecx
    20e7:      	testq	%rcx, %rcx
    20ea:      	je	0x2d3b <kprobe_unwind_ruby+0x2d3b>
    20f0:      	movq	0x18(%rsp), %rax
    20f5:      	subq	0x68(%rsp), %rax
    20fa:      	xorl	%edx, %edx
    20fc:      	divq	%rcx
    20ff:      	movl	0x2c(%rsp), %ecx
    2103:      	cmpq	%rcx, %rax
    2106:      	jbe	0x2d3b <kprobe_unwind_ruby+0x2d3b>
    210c:      	movq	(%rip), %rax            # 0x2113 <kprobe_unwind_ruby+0x2113>
    2113:      	cmpl	$0x0, (%rax)
    2116:      	je	0x261b <kprobe_unwind_ruby+0x261b>
    211c:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    2126:      	movq	%rax, 0x55(%rsp)
    212b:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    2135:      	movq	%rax, 0x50(%rsp)
    213a:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    2144:      	movq	%rax, 0x48(%rsp)
    2149:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    2153:      	movq	%rax, 0x40(%rsp)
    2158:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    2162:      	movq	%rax, 0x38(%rsp)
    2167:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    2171:      	movq	%rax, 0x30(%rsp)
    2176:      	leaq	0x30(%rsp), %rdi
    217b:      	movl	$0x2d, %eax
    2180:      	movl	$0x6, %ecx
    2185:      	movl	$0x2d, %esi
    218a:      	xorl	%eax, %eax
    218c:      	callq	*%rcx
    218e:      	jmp	0x261b <kprobe_unwind_ruby+0x261b>
    2193:      	movabsq	$0xa70666320746567, %rax # imm = 0xA70666320746567
    219d:      	movq	%rax, 0x40(%rsp)
    21a2:      	movabsq	$0x206f742064656c69, %rax # imm = 0x206F742064656C69
    21ac:      	movq	%rax, 0x38(%rsp)
    21b1:      	movabsq	$0x6166203a79627572, %rax # imm = 0x6166203A79627572
    21bb:      	movq	%rax, 0x30(%rsp)
    21c0:      	movb	$0x0, 0x48(%rsp)
    21c5:      	leaq	0x30(%rsp), %rdi
    21ca:      	movl	$0x19, %eax
    21cf:      	movl	$0x6, %ecx
    21d4:      	movl	$0x19, %esi
    21d9:      	xorl	%eax, %eax
    21db:      	callq	*%rcx
    21dd:      	jmp	0x95b <kprobe_unwind_ruby+0x95b>
    21e2:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    21ec:      	movq	%rax, 0x56(%rsp)
    21f1:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    21fb:      	movq	%rax, 0x50(%rsp)
    2200:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    220a:      	movq	%rax, 0x48(%rsp)
    220f:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2219:      	movq	%rax, 0x40(%rsp)
    221e:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2228:      	movq	%rax, 0x38(%rsp)
    222d:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2237:      	movq	%rax, 0x30(%rsp)
    223c:      	leaq	0x30(%rsp), %rdi
    2241:      	movl	$0x2e, %eax
    2246:      	movl	$0x6, %ecx
    224b:      	movl	0x18(%rsp), %edx
    224f:      	movl	$0x2e, %esi
    2254:      	xorl	%eax, %eax
    2256:      	callq	*%rcx
    2258:      	jmp	0x9cb <kprobe_unwind_ruby+0x9cb>
    225d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2267:      	movq	%rax, 0x56(%rsp)
    226c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2276:      	movq	%rax, 0x50(%rsp)
    227b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2285:      	movq	%rax, 0x48(%rsp)
    228a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2294:      	movq	%rax, 0x40(%rsp)
    2299:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    22a3:      	movq	%rax, 0x38(%rsp)
    22a8:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    22b2:      	movq	%rax, 0x30(%rsp)
    22b7:      	leaq	0x30(%rsp), %rdi
    22bc:      	movl	$0x2e, %eax
    22c1:      	movl	$0x6, %ecx
    22c6:      	movl	0x74(%rsp), %edx
    22ca:      	movl	$0x2e, %esi
    22cf:      	xorl	%eax, %eax
    22d1:      	callq	*%rcx
    22d3:      	jmp	0xc4c <kprobe_unwind_ruby+0xc4c>
    22d8:      	movabsq	$0xa657a69732071, %rax  # imm = 0xA657A69732071
    22e2:      	movq	%rax, 0x47(%rsp)
    22e7:      	movabsq	$0x7165736920746567, %rax # imm = 0x7165736920746567
    22f1:      	movq	%rax, 0x40(%rsp)
    22f6:      	movabsq	$0x206f742064656c69, %rax # imm = 0x206F742064656C69
    2300:      	movq	%rax, 0x38(%rsp)
    2305:      	movabsq	$0x6166203a79627572, %rax # imm = 0x6166203A79627572
    230f:      	movq	%rax, 0x30(%rsp)
    2314:      	leaq	0x30(%rsp), %rdi
    2319:      	movl	$0x1f, %eax
    231e:      	movl	$0x6, %ecx
    2323:      	movl	$0x1f, %esi
    2328:      	xorl	%eax, %eax
    232a:      	callq	*%rcx
    232c:      	jmp	0xc19 <kprobe_unwind_ruby+0xc19>
    2331:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    233b:      	movq	%rax, 0x56(%rsp)
    2340:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    234a:      	movq	%rax, 0x50(%rsp)
    234f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2359:      	movq	%rax, 0x48(%rsp)
    235e:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2368:      	movq	%rax, 0x40(%rsp)
    236d:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2377:      	movq	%rax, 0x38(%rsp)
    237c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2386:      	movq	%rax, 0x30(%rsp)
    238b:      	leaq	0x30(%rsp), %rdi
    2390:      	movl	$0x2e, %eax
    2395:      	movl	$0x6, %ecx
    239a:      	movl	(%rsp), %edx
    239d:      	movl	$0x2e, %esi
    23a2:      	xorl	%eax, %eax
    23a4:      	callq	*%rcx
    23a6:      	jmp	0xc63 <kprobe_unwind_ruby+0xc63>
    23ab:      	movq	$0x0, (%rsp)
    23b3:      	movzbl	0x1d(%r15), %eax
    23b8:      	addq	0x8(%rsp), %rax
    23bd:      	movq	%rsp, %rdi
    23c0:      	movl	$0x8, %ecx
    23c5:      	movl	$0x70, %r8d
    23cb:      	movzbl	0x1d(%r15), %edx
    23d0:      	addq	0x8(%rsp), %rdx
    23d5:      	movl	$0x8, %esi
    23da:      	callq	*%r8
    23dd:      	testq	%rax, %rax
    23e0:      	jne	0x81b <kprobe_unwind_ruby+0x81b>
    23e6:      	movl	(%rsp), %eax
    23e9:      	notl	%eax
    23eb:      	testl	$0x140, %eax            # imm = 0x140
    23f0:      	jne	0x997 <kprobe_unwind_ruby+0x997>
    23f6:      	jmp	0x1fa8 <kprobe_unwind_ruby+0x1fa8>
    23fb:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2405:      	movq	%rax, 0x56(%rsp)
    240a:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2414:      	movq	%rax, 0x50(%rsp)
    2419:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2423:      	movq	%rax, 0x48(%rsp)
    2428:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2432:      	movq	%rax, 0x40(%rsp)
    2437:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2441:      	movq	%rax, 0x38(%rsp)
    2446:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2450:      	movq	%rax, 0x30(%rsp)
    2455:      	leaq	0x30(%rsp), %rdi
    245a:      	movl	$0x2e, %eax
    245f:      	movl	$0x6, %ecx
    2464:      	movl	0x18(%rsp), %edx
    2468:      	movl	$0x2e, %esi
    246d:      	xorl	%eax, %eax
    246f:      	callq	*%rcx
    2471:      	jmp	0xced <kprobe_unwind_ruby+0xced>
    2476:      	movq	(%rip), %rax            # 0x247d <kprobe_unwind_ruby+0x247d>
    247d:      	cmpl	$0x0, (%rax)
    2480:      	je	0x1326 <kprobe_unwind_ruby+0x1326>
    2486:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2490:      	movq	%rax, 0x56(%rsp)
    2495:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    249f:      	movq	%rax, 0x50(%rsp)
    24a4:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    24ae:      	movq	%rax, 0x48(%rsp)
    24b3:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    24bd:      	movq	%rax, 0x40(%rsp)
    24c2:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    24cc:      	movq	%rax, 0x38(%rsp)
    24d1:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    24db:      	movq	%rax, 0x30(%rsp)
    24e0:      	leaq	0x30(%rsp), %rdi
    24e5:      	movl	$0x2e, %eax
    24ea:      	movl	$0x6, %ecx
    24ef:      	movl	(%rsp), %edx
    24f2:      	movl	$0x2e, %esi
    24f7:      	xorl	%eax, %eax
    24f9:      	callq	*%rcx
    24fb:      	jmp	0x1326 <kprobe_unwind_ruby+0x1326>
    2500:      	movl	0x2c0(%r14), %eax
    2507:      	cmpq	$0x7e, %rax
    250b:      	ja	0xdd3 <kprobe_unwind_ruby+0xdd3>
    2511:      	movq	0x10(%rsp), %rcx
    2516:      	movq	0x18(%rsp), %rdx
    251b:      	leal	0x1(%rax), %esi
    251e:      	movl	%esi, 0x2c0(%r14)
    2525:      	leaq	(%rax,%rax,2), %rax
    2529:      	movw	$0x0, 0x4(%rsp)
    2530:      	movl	$0x0, (%rsp)
    2537:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    253f:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    2547:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    2552:      	movl	(%rsp), %ecx
    2555:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    255d:      	movzwl	0x4(%rsp), %ecx
    2562:      	movw	%cx, 0x2e6(%r14,%rax,8)
    256b:      	movl	$0x36, (%rsp)
    2572:      	movq	(%rip), %rdi            # 0x2579 <kprobe_unwind_ruby+0x2579>
    2579:      	movq	%rsp, %rsi
    257c:      	movl	$0x1, %eax
    2581:      	callq	*%rax
    2583:      	testq	%rax, %rax
    2586:      	je	0x28be <kprobe_unwind_ruby+0x28be>
    258c:      	incq	(%rax)
    258f:      	jmp	0x1981 <kprobe_unwind_ruby+0x1981>
    2594:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    259e:      	movq	%rax, 0x56(%rsp)
    25a3:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    25ad:      	movq	%rax, 0x50(%rsp)
    25b2:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    25bc:      	movq	%rax, 0x48(%rsp)
    25c1:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    25cb:      	movq	%rax, 0x40(%rsp)
    25d0:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    25da:      	movq	%rax, 0x38(%rsp)
    25df:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    25e9:      	movq	%rax, 0x30(%rsp)
    25ee:      	leaq	0x30(%rsp), %rdi
    25f3:      	movl	$0x2e, %eax
    25f8:      	movl	$0x6, %ecx
    25fd:      	movl	(%rsp), %edx
    2600:      	movl	$0x2e, %esi
    2605:      	xorl	%eax, %eax
    2607:      	callq	*%rcx
    2609:      	jmp	0xdb5 <kprobe_unwind_ruby+0xdb5>
    260e:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    2615:      	jae	0x286e <kprobe_unwind_ruby+0x286e>
    261b:      	movq	0x8(%rsp), %rax
    2620:      	cmpq	%rax, %r12
    2623:      	jbe	0x2b2 <kprobe_unwind_ruby+0x2b2>
    2629:      	movzbl	0x1e(%r15), %ecx
    262e:      	addq	%rcx, %rax
    2631:      	movq	%rax, 0x8(%rsp)
    2636:      	movq	$0x0, 0x18(%rsp)
    263f:      	movq	$0x0, 0x20(%rsp)
    2648:      	movzbl	0x1c(%r15), %ecx
    264d:      	addq	%rax, %rcx
    2650:      	leaq	0x20(%rsp), %rdi
    2655:      	movl	$0x8, %eax
    265a:      	movl	$0x70, %r8d
    2660:      	movzbl	0x1c(%r15), %edx
    2665:      	addq	0x8(%rsp), %rdx
    266a:      	movl	$0x8, %esi
    266f:      	callq	*%r8
    2672:      	movzbl	0x1b(%r15), %eax
    2677:      	addq	0x8(%rsp), %rax
    267c:      	leaq	0x18(%rsp), %rdi
    2681:      	movl	$0x8, %ecx
    2686:      	movl	$0x70, %r8d
    268c:      	movzbl	0x1b(%r15), %edx
    2691:      	addq	0x8(%rsp), %rdx
    2696:      	movl	$0x8, %esi
    269b:      	callq	*%r8
    269e:      	cmpq	$0x0, 0x18(%rsp)
    26a4:      	je	0x2a69 <kprobe_unwind_ruby+0x2a69>
    26aa:      	movq	0x20(%rsp), %rax
    26af:      	testq	%rax, %rax
    26b2:      	je	0x2a69 <kprobe_unwind_ruby+0x2a69>
    26b8:      	movzbl	0x1f(%r15), %ecx
    26bd:      	addq	%rcx, %rax
    26c0:      	leaq	0x10(%rsp), %rdi
    26c5:      	movl	$0x8, %ecx
    26ca:      	movl	$0x70, %r8d
    26d0:      	movzbl	0x1f(%r15), %edx
    26d5:      	addq	0x20(%rsp), %rdx
    26da:      	movl	$0x8, %esi
    26df:      	callq	*%r8
    26e2:      	testq	%rax, %rax
    26e5:      	jne	0x4c7 <kprobe_unwind_ruby+0x4c7>
    26eb:      	movzbl	0x21(%r15), %eax
    26f0:      	addq	0x10(%rsp), %rax
    26f5:      	leaq	0x68(%rsp), %rdi
    26fa:      	movl	$0x8, %ecx
    26ff:      	movl	$0x70, %r8d
    2705:      	movzbl	0x21(%r15), %edx
    270a:      	addq	0x10(%rsp), %rdx
    270f:      	movl	$0x8, %esi
    2714:      	callq	*%r8
    2717:      	testq	%rax, %rax
    271a:      	jne	0x8a4 <kprobe_unwind_ruby+0x8a4>
    2720:      	movzbl	0x22(%r15), %eax
    2725:      	addq	0x10(%rsp), %rax
    272a:      	leaq	0x2c(%rsp), %rdi
    272f:      	movl	$0x4, %ecx
    2734:      	movl	$0x70, %r8d
    273a:      	movzbl	0x22(%r15), %edx
    273f:      	addq	0x10(%rsp), %rdx
    2744:      	movl	$0x4, %esi
    2749:      	callq	*%r8
    274c:      	testq	%rax, %rax
    274f:      	jne	0xc08 <kprobe_unwind_ruby+0xc08>
    2755:      	movzbl	0x23(%r15), %ecx
    275a:      	testq	%rcx, %rcx
    275d:      	je	0x30a1 <kprobe_unwind_ruby+0x30a1>
    2763:      	movq	0x18(%rsp), %rax
    2768:      	subq	0x68(%rsp), %rax
    276d:      	xorl	%edx, %edx
    276f:      	divq	%rcx
    2772:      	movl	0x2c(%rsp), %ecx
    2776:      	cmpq	%rcx, %rax
    2779:      	jbe	0x30a1 <kprobe_unwind_ruby+0x30a1>
    277f:      	movq	(%rip), %rax            # 0x2786 <kprobe_unwind_ruby+0x2786>
    2786:      	cmpl	$0x0, (%rax)
    2789:      	je	0x2a76 <kprobe_unwind_ruby+0x2a76>
    278f:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    2799:      	movq	%rax, 0x55(%rsp)
    279e:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    27a8:      	movq	%rax, 0x50(%rsp)
    27ad:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    27b7:      	movq	%rax, 0x48(%rsp)
    27bc:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    27c6:      	movq	%rax, 0x40(%rsp)
    27cb:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    27d5:      	movq	%rax, 0x38(%rsp)
    27da:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    27e4:      	movq	%rax, 0x30(%rsp)
    27e9:      	leaq	0x30(%rsp), %rdi
    27ee:      	movl	$0x2d, %eax
    27f3:      	movl	$0x6, %ecx
    27f8:      	movl	$0x2d, %esi
    27fd:      	xorl	%eax, %eax
    27ff:      	callq	*%rcx
    2801:      	jmp	0x2a76 <kprobe_unwind_ruby+0x2a76>
    2806:      	movabsq	$0xa6c6c75662073, %rax  # imm = 0xA6C6C75662073
    2810:      	movq	%rax, 0x4d(%rsp)
    2815:      	movabsq	$0x66207369206b6361, %rax # imm = 0x66207369206B6361
    281f:      	movq	%rax, 0x48(%rsp)
    2824:      	movabsq	$0x7473203a656d6172, %rax # imm = 0x7473203A656D6172
    282e:      	movq	%rax, 0x40(%rsp)
    2833:      	movabsq	$0x662068737570206f, %rax # imm = 0x662068737570206F
    283d:      	movq	%rax, 0x38(%rsp)
    2842:      	movabsq	$0x7420656c62616e75, %rax # imm = 0x7420656C62616E75
    284c:      	movq	%rax, 0x30(%rsp)
    2851:      	leaq	0x30(%rsp), %rdi
    2856:      	movl	$0x25, %eax
    285b:      	movl	$0x6, %ecx
    2860:      	movl	$0x25, %esi
    2865:      	xorl	%eax, %eax
    2867:      	callq	*%rcx
    2869:      	jmp	0xde4 <kprobe_unwind_ruby+0xde4>
    286e:      	movq	$0x0, (%rsp)
    2876:      	movzbl	0x1d(%r15), %eax
    287b:      	addq	0x8(%rsp), %rax
    2880:      	movq	%rsp, %rdi
    2883:      	movl	$0x8, %ecx
    2888:      	movl	$0x70, %r8d
    288e:      	movzbl	0x1d(%r15), %edx
    2893:      	addq	0x8(%rsp), %rdx
    2898:      	movl	$0x8, %esi
    289d:      	callq	*%r8
    28a0:      	testq	%rax, %rax
    28a3:      	jne	0x81b <kprobe_unwind_ruby+0x81b>
    28a9:      	movl	(%rsp), %eax
    28ac:      	notl	%eax
    28ae:      	testl	$0x140, %eax            # imm = 0x140
    28b3:      	jne	0x997 <kprobe_unwind_ruby+0x997>
    28b9:      	jmp	0x261b <kprobe_unwind_ruby+0x261b>
    28be:      	movq	(%rip), %rax            # 0x28c5 <kprobe_unwind_ruby+0x28c5>
    28c5:      	cmpl	$0x0, (%rax)
    28c8:      	je	0x1981 <kprobe_unwind_ruby+0x1981>
    28ce:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    28d8:      	movq	%rax, 0x56(%rsp)
    28dd:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    28e7:      	movq	%rax, 0x50(%rsp)
    28ec:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    28f6:      	movq	%rax, 0x48(%rsp)
    28fb:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2905:      	movq	%rax, 0x40(%rsp)
    290a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2914:      	movq	%rax, 0x38(%rsp)
    2919:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2923:      	movq	%rax, 0x30(%rsp)
    2928:      	leaq	0x30(%rsp), %rdi
    292d:      	movl	$0x2e, %eax
    2932:      	movl	$0x6, %ecx
    2937:      	movl	(%rsp), %edx
    293a:      	movl	$0x2e, %esi
    293f:      	xorl	%eax, %eax
    2941:      	callq	*%rcx
    2943:      	jmp	0x1981 <kprobe_unwind_ruby+0x1981>
    2948:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2952:      	movq	%rax, 0x56(%rsp)
    2957:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2961:      	movq	%rax, 0x50(%rsp)
    2966:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2970:      	movq	%rax, 0x48(%rsp)
    2975:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    297f:      	movq	%rax, 0x40(%rsp)
    2984:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    298e:      	movq	%rax, 0x38(%rsp)
    2993:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    299d:      	movq	%rax, 0x30(%rsp)
    29a2:      	leaq	0x30(%rsp), %rdi
    29a7:      	movl	$0x2e, %eax
    29ac:      	movl	$0x6, %ecx
    29b1:      	movl	0x74(%rsp), %edx
    29b5:      	movl	$0x2e, %esi
    29ba:      	xorl	%eax, %eax
    29bc:      	callq	*%rcx
    29be:      	cmpl	$0x0, (%r15)
    29c2:      	movl	$0x2, %r13d
    29c8:      	jne	0xe1b <kprobe_unwind_ruby+0xe1b>
    29ce:      	xorl	%ebp, %ebp
    29d0:      	jmp	0x2b2 <kprobe_unwind_ruby+0x2b2>
    29d5:      	movl	0x2c0(%r14), %eax
    29dc:      	cmpq	$0x7e, %rax
    29e0:      	ja	0xdd3 <kprobe_unwind_ruby+0xdd3>
    29e6:      	movq	0x10(%rsp), %rcx
    29eb:      	movq	0x18(%rsp), %rdx
    29f0:      	leal	0x1(%rax), %esi
    29f3:      	movl	%esi, 0x2c0(%r14)
    29fa:      	leaq	(%rax,%rax,2), %rax
    29fe:      	movw	$0x0, 0x4(%rsp)
    2a05:      	movl	$0x0, (%rsp)
    2a0c:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    2a14:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    2a1c:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    2a27:      	movl	(%rsp), %ecx
    2a2a:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    2a32:      	movzwl	0x4(%rsp), %ecx
    2a37:      	movw	%cx, 0x2e6(%r14,%rax,8)
    2a40:      	movl	$0x36, (%rsp)
    2a47:      	movq	(%rip), %rdi            # 0x2a4e <kprobe_unwind_ruby+0x2a4e>
    2a4e:      	movq	%rsp, %rsi
    2a51:      	movl	$0x1, %eax
    2a56:      	callq	*%rax
    2a58:      	testq	%rax, %rax
    2a5b:      	je	0x2cb1 <kprobe_unwind_ruby+0x2cb1>
    2a61:      	incq	(%rax)
    2a64:      	jmp	0x1fa8 <kprobe_unwind_ruby+0x1fa8>
    2a69:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    2a70:      	jae	0x2c61 <kprobe_unwind_ruby+0x2c61>
    2a76:      	movq	0x8(%rsp), %rax
    2a7b:      	cmpq	%rax, %r12
    2a7e:      	jbe	0x2b2 <kprobe_unwind_ruby+0x2b2>
    2a84:      	movzbl	0x1e(%r15), %ecx
    2a89:      	addq	%rcx, %rax
    2a8c:      	movq	%rax, 0x8(%rsp)
    2a91:      	movq	$0x0, 0x18(%rsp)
    2a9a:      	movq	$0x0, 0x20(%rsp)
    2aa3:      	movzbl	0x1c(%r15), %ecx
    2aa8:      	addq	%rax, %rcx
    2aab:      	leaq	0x20(%rsp), %rdi
    2ab0:      	movl	$0x8, %eax
    2ab5:      	movl	$0x70, %r8d
    2abb:      	movzbl	0x1c(%r15), %edx
    2ac0:      	addq	0x8(%rsp), %rdx
    2ac5:      	movl	$0x8, %esi
    2aca:      	callq	*%r8
    2acd:      	movzbl	0x1b(%r15), %eax
    2ad2:      	addq	0x8(%rsp), %rax
    2ad7:      	leaq	0x18(%rsp), %rdi
    2adc:      	movl	$0x8, %ecx
    2ae1:      	movl	$0x70, %r8d
    2ae7:      	movzbl	0x1b(%r15), %edx
    2aec:      	addq	0x8(%rsp), %rdx
    2af1:      	movl	$0x8, %esi
    2af6:      	callq	*%r8
    2af9:      	cmpq	$0x0, 0x18(%rsp)
    2aff:      	je	0x2dcf <kprobe_unwind_ruby+0x2dcf>
    2b05:      	movq	0x20(%rsp), %rax
    2b0a:      	testq	%rax, %rax
    2b0d:      	je	0x2dcf <kprobe_unwind_ruby+0x2dcf>
    2b13:      	movzbl	0x1f(%r15), %ecx
    2b18:      	addq	%rcx, %rax
    2b1b:      	leaq	0x10(%rsp), %rdi
    2b20:      	movl	$0x8, %ecx
    2b25:      	movl	$0x70, %r8d
    2b2b:      	movzbl	0x1f(%r15), %edx
    2b30:      	addq	0x20(%rsp), %rdx
    2b35:      	movl	$0x8, %esi
    2b3a:      	callq	*%r8
    2b3d:      	testq	%rax, %rax
    2b40:      	jne	0x4c7 <kprobe_unwind_ruby+0x4c7>
    2b46:      	movzbl	0x21(%r15), %eax
    2b4b:      	addq	0x10(%rsp), %rax
    2b50:      	leaq	0x68(%rsp), %rdi
    2b55:      	movl	$0x8, %ecx
    2b5a:      	movl	$0x70, %r8d
    2b60:      	movzbl	0x21(%r15), %edx
    2b65:      	addq	0x10(%rsp), %rdx
    2b6a:      	movl	$0x8, %esi
    2b6f:      	callq	*%r8
    2b72:      	testq	%rax, %rax
    2b75:      	jne	0x8a4 <kprobe_unwind_ruby+0x8a4>
    2b7b:      	movzbl	0x22(%r15), %eax
    2b80:      	addq	0x10(%rsp), %rax
    2b85:      	leaq	0x2c(%rsp), %rdi
    2b8a:      	movl	$0x4, %ecx
    2b8f:      	movl	$0x70, %r8d
    2b95:      	movzbl	0x22(%r15), %edx
    2b9a:      	addq	0x10(%rsp), %rdx
    2b9f:      	movl	$0x4, %esi
    2ba4:      	callq	*%r8
    2ba7:      	testq	%rax, %rax
    2baa:      	jne	0xc08 <kprobe_unwind_ruby+0xc08>
    2bb0:      	movzbl	0x23(%r15), %ecx
    2bb5:      	testq	%rcx, %rcx
    2bb8:      	je	0x3407 <kprobe_unwind_ruby+0x3407>
    2bbe:      	movq	0x18(%rsp), %rax
    2bc3:      	subq	0x68(%rsp), %rax
    2bc8:      	xorl	%edx, %edx
    2bca:      	divq	%rcx
    2bcd:      	movl	0x2c(%rsp), %ecx
    2bd1:      	cmpq	%rcx, %rax
    2bd4:      	jbe	0x3407 <kprobe_unwind_ruby+0x3407>
    2bda:      	movq	(%rip), %rax            # 0x2be1 <kprobe_unwind_ruby+0x2be1>
    2be1:      	cmpl	$0x0, (%rax)
    2be4:      	je	0x2ddc <kprobe_unwind_ruby+0x2ddc>
    2bea:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    2bf4:      	movq	%rax, 0x55(%rsp)
    2bf9:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    2c03:      	movq	%rax, 0x50(%rsp)
    2c08:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    2c12:      	movq	%rax, 0x48(%rsp)
    2c17:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    2c21:      	movq	%rax, 0x40(%rsp)
    2c26:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    2c30:      	movq	%rax, 0x38(%rsp)
    2c35:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    2c3f:      	movq	%rax, 0x30(%rsp)
    2c44:      	leaq	0x30(%rsp), %rdi
    2c49:      	movl	$0x2d, %eax
    2c4e:      	movl	$0x6, %ecx
    2c53:      	movl	$0x2d, %esi
    2c58:      	xorl	%eax, %eax
    2c5a:      	callq	*%rcx
    2c5c:      	jmp	0x2ddc <kprobe_unwind_ruby+0x2ddc>
    2c61:      	movq	$0x0, (%rsp)
    2c69:      	movzbl	0x1d(%r15), %eax
    2c6e:      	addq	0x8(%rsp), %rax
    2c73:      	movq	%rsp, %rdi
    2c76:      	movl	$0x8, %ecx
    2c7b:      	movl	$0x70, %r8d
    2c81:      	movzbl	0x1d(%r15), %edx
    2c86:      	addq	0x8(%rsp), %rdx
    2c8b:      	movl	$0x8, %esi
    2c90:      	callq	*%r8
    2c93:      	testq	%rax, %rax
    2c96:      	jne	0x81b <kprobe_unwind_ruby+0x81b>
    2c9c:      	movl	(%rsp), %eax
    2c9f:      	notl	%eax
    2ca1:      	testl	$0x140, %eax            # imm = 0x140
    2ca6:      	jne	0x997 <kprobe_unwind_ruby+0x997>
    2cac:      	jmp	0x2a76 <kprobe_unwind_ruby+0x2a76>
    2cb1:      	movq	(%rip), %rax            # 0x2cb8 <kprobe_unwind_ruby+0x2cb8>
    2cb8:      	cmpl	$0x0, (%rax)
    2cbb:      	je	0x1fa8 <kprobe_unwind_ruby+0x1fa8>
    2cc1:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2ccb:      	movq	%rax, 0x56(%rsp)
    2cd0:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2cda:      	movq	%rax, 0x50(%rsp)
    2cdf:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2ce9:      	movq	%rax, 0x48(%rsp)
    2cee:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2cf8:      	movq	%rax, 0x40(%rsp)
    2cfd:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2d07:      	movq	%rax, 0x38(%rsp)
    2d0c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2d16:      	movq	%rax, 0x30(%rsp)
    2d1b:      	leaq	0x30(%rsp), %rdi
    2d20:      	movl	$0x2e, %eax
    2d25:      	movl	$0x6, %ecx
    2d2a:      	movl	(%rsp), %edx
    2d2d:      	movl	$0x2e, %esi
    2d32:      	xorl	%eax, %eax
    2d34:      	callq	*%rcx
    2d36:      	jmp	0x1fa8 <kprobe_unwind_ruby+0x1fa8>
    2d3b:      	movl	0x2c0(%r14), %eax
    2d42:      	cmpq	$0x7e, %rax
    2d46:      	ja	0xdd3 <kprobe_unwind_ruby+0xdd3>
    2d4c:      	movq	0x10(%rsp), %rcx
    2d51:      	movq	0x18(%rsp), %rdx
    2d56:      	leal	0x1(%rax), %esi
    2d59:      	movl	%esi, 0x2c0(%r14)
    2d60:      	leaq	(%rax,%rax,2), %rax
    2d64:      	movw	$0x0, 0x4(%rsp)
    2d6b:      	movl	$0x0, (%rsp)
    2d72:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    2d7a:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    2d82:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    2d8d:      	movl	(%rsp), %ecx
    2d90:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    2d98:      	movzwl	0x4(%rsp), %ecx
    2d9d:      	movw	%cx, 0x2e6(%r14,%rax,8)
    2da6:      	movl	$0x36, (%rsp)
    2dad:      	movq	(%rip), %rdi            # 0x2db4 <kprobe_unwind_ruby+0x2db4>
    2db4:      	movq	%rsp, %rsi
    2db7:      	movl	$0x1, %eax
    2dbc:      	callq	*%rax
    2dbe:      	testq	%rax, %rax
    2dc1:      	je	0x3017 <kprobe_unwind_ruby+0x3017>
    2dc7:      	incq	(%rax)
    2dca:      	jmp	0x261b <kprobe_unwind_ruby+0x261b>
    2dcf:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    2dd6:      	jae	0x2fc7 <kprobe_unwind_ruby+0x2fc7>
    2ddc:      	movq	0x8(%rsp), %rax
    2de1:      	cmpq	%rax, %r12
    2de4:      	jbe	0x2b2 <kprobe_unwind_ruby+0x2b2>
    2dea:      	movzbl	0x1e(%r15), %ecx
    2def:      	addq	%rcx, %rax
    2df2:      	movq	%rax, 0x8(%rsp)
    2df7:      	movq	$0x0, 0x18(%rsp)
    2e00:      	movq	$0x0, 0x20(%rsp)
    2e09:      	movzbl	0x1c(%r15), %ecx
    2e0e:      	addq	%rax, %rcx
    2e11:      	leaq	0x20(%rsp), %rdi
    2e16:      	movl	$0x8, %eax
    2e1b:      	movl	$0x70, %r8d
    2e21:      	movzbl	0x1c(%r15), %edx
    2e26:      	addq	0x8(%rsp), %rdx
    2e2b:      	movl	$0x8, %esi
    2e30:      	callq	*%r8
    2e33:      	movzbl	0x1b(%r15), %eax
    2e38:      	addq	0x8(%rsp), %rax
    2e3d:      	leaq	0x18(%rsp), %rdi
    2e42:      	movl	$0x8, %ecx
    2e47:      	movl	$0x70, %r8d
    2e4d:      	movzbl	0x1b(%r15), %edx
    2e52:      	addq	0x8(%rsp), %rdx
    2e57:      	movl	$0x8, %esi
    2e5c:      	callq	*%r8
    2e5f:      	cmpq	$0x0, 0x18(%rsp)
    2e65:      	je	0x3135 <kprobe_unwind_ruby+0x3135>
    2e6b:      	movq	0x20(%rsp), %rax
    2e70:      	testq	%rax, %rax
    2e73:      	je	0x3135 <kprobe_unwind_ruby+0x3135>
    2e79:      	movzbl	0x1f(%r15), %ecx
    2e7e:      	addq	%rcx, %rax
    2e81:      	leaq	0x10(%rsp), %rdi
    2e86:      	movl	$0x8, %ecx
    2e8b:      	movl	$0x70, %r8d
    2e91:      	movzbl	0x1f(%r15), %edx
    2e96:      	addq	0x20(%rsp), %rdx
    2e9b:      	movl	$0x8, %esi
    2ea0:      	callq	*%r8
    2ea3:      	testq	%rax, %rax
    2ea6:      	jne	0x4c7 <kprobe_unwind_ruby+0x4c7>
    2eac:      	movzbl	0x21(%r15), %eax
    2eb1:      	addq	0x10(%rsp), %rax
    2eb6:      	leaq	0x68(%rsp), %rdi
    2ebb:      	movl	$0x8, %ecx
    2ec0:      	movl	$0x70, %r8d
    2ec6:      	movzbl	0x21(%r15), %edx
    2ecb:      	addq	0x10(%rsp), %rdx
    2ed0:      	movl	$0x8, %esi
    2ed5:      	callq	*%r8
    2ed8:      	testq	%rax, %rax
    2edb:      	jne	0x8a4 <kprobe_unwind_ruby+0x8a4>
    2ee1:      	movzbl	0x22(%r15), %eax
    2ee6:      	addq	0x10(%rsp), %rax
    2eeb:      	leaq	0x2c(%rsp), %rdi
    2ef0:      	movl	$0x4, %ecx
    2ef5:      	movl	$0x70, %r8d
    2efb:      	movzbl	0x22(%r15), %edx
    2f00:      	addq	0x10(%rsp), %rdx
    2f05:      	movl	$0x4, %esi
    2f0a:      	callq	*%r8
    2f0d:      	testq	%rax, %rax
    2f10:      	jne	0xc08 <kprobe_unwind_ruby+0xc08>
    2f16:      	movzbl	0x23(%r15), %ecx
    2f1b:      	testq	%rcx, %rcx
    2f1e:      	je	0x376d <kprobe_unwind_ruby+0x376d>
    2f24:      	movq	0x18(%rsp), %rax
    2f29:      	subq	0x68(%rsp), %rax
    2f2e:      	xorl	%edx, %edx
    2f30:      	divq	%rcx
    2f33:      	movl	0x2c(%rsp), %ecx
    2f37:      	cmpq	%rcx, %rax
    2f3a:      	jbe	0x376d <kprobe_unwind_ruby+0x376d>
    2f40:      	movq	(%rip), %rax            # 0x2f47 <kprobe_unwind_ruby+0x2f47>
    2f47:      	cmpl	$0x0, (%rax)
    2f4a:      	je	0x3142 <kprobe_unwind_ruby+0x3142>
    2f50:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    2f5a:      	movq	%rax, 0x55(%rsp)
    2f5f:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    2f69:      	movq	%rax, 0x50(%rsp)
    2f6e:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    2f78:      	movq	%rax, 0x48(%rsp)
    2f7d:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    2f87:      	movq	%rax, 0x40(%rsp)
    2f8c:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    2f96:      	movq	%rax, 0x38(%rsp)
    2f9b:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    2fa5:      	movq	%rax, 0x30(%rsp)
    2faa:      	leaq	0x30(%rsp), %rdi
    2faf:      	movl	$0x2d, %eax
    2fb4:      	movl	$0x6, %ecx
    2fb9:      	movl	$0x2d, %esi
    2fbe:      	xorl	%eax, %eax
    2fc0:      	callq	*%rcx
    2fc2:      	jmp	0x3142 <kprobe_unwind_ruby+0x3142>
    2fc7:      	movq	$0x0, (%rsp)
    2fcf:      	movzbl	0x1d(%r15), %eax
    2fd4:      	addq	0x8(%rsp), %rax
    2fd9:      	movq	%rsp, %rdi
    2fdc:      	movl	$0x8, %ecx
    2fe1:      	movl	$0x70, %r8d
    2fe7:      	movzbl	0x1d(%r15), %edx
    2fec:      	addq	0x8(%rsp), %rdx
    2ff1:      	movl	$0x8, %esi
    2ff6:      	callq	*%r8
    2ff9:      	testq	%rax, %rax
    2ffc:      	jne	0x81b <kprobe_unwind_ruby+0x81b>
    3002:      	movl	(%rsp), %eax
    3005:      	notl	%eax
    3007:      	testl	$0x140, %eax            # imm = 0x140
    300c:      	jne	0x997 <kprobe_unwind_ruby+0x997>
    3012:      	jmp	0x2ddc <kprobe_unwind_ruby+0x2ddc>
    3017:      	movq	(%rip), %rax            # 0x301e <kprobe_unwind_ruby+0x301e>
    301e:      	cmpl	$0x0, (%rax)
    3021:      	je	0x261b <kprobe_unwind_ruby+0x261b>
    3027:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3031:      	movq	%rax, 0x56(%rsp)
    3036:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3040:      	movq	%rax, 0x50(%rsp)
    3045:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    304f:      	movq	%rax, 0x48(%rsp)
    3054:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    305e:      	movq	%rax, 0x40(%rsp)
    3063:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    306d:      	movq	%rax, 0x38(%rsp)
    3072:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    307c:      	movq	%rax, 0x30(%rsp)
    3081:      	leaq	0x30(%rsp), %rdi
    3086:      	movl	$0x2e, %eax
    308b:      	movl	$0x6, %ecx
    3090:      	movl	(%rsp), %edx
    3093:      	movl	$0x2e, %esi
    3098:      	xorl	%eax, %eax
    309a:      	callq	*%rcx
    309c:      	jmp	0x261b <kprobe_unwind_ruby+0x261b>
    30a1:      	movl	0x2c0(%r14), %eax
    30a8:      	cmpq	$0x7e, %rax
    30ac:      	ja	0xdd3 <kprobe_unwind_ruby+0xdd3>
    30b2:      	movq	0x10(%rsp), %rcx
    30b7:      	movq	0x18(%rsp), %rdx
    30bc:      	leal	0x1(%rax), %esi
    30bf:      	movl	%esi, 0x2c0(%r14)
    30c6:      	leaq	(%rax,%rax,2), %rax
    30ca:      	movw	$0x0, 0x4(%rsp)
    30d1:      	movl	$0x0, (%rsp)
    30d8:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    30e0:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    30e8:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    30f3:      	movl	(%rsp), %ecx
    30f6:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    30fe:      	movzwl	0x4(%rsp), %ecx
    3103:      	movw	%cx, 0x2e6(%r14,%rax,8)
    310c:      	movl	$0x36, (%rsp)
    3113:      	movq	(%rip), %rdi            # 0x311a <kprobe_unwind_ruby+0x311a>
    311a:      	movq	%rsp, %rsi
    311d:      	movl	$0x1, %eax
    3122:      	callq	*%rax
    3124:      	testq	%rax, %rax
    3127:      	je	0x337d <kprobe_unwind_ruby+0x337d>
    312d:      	incq	(%rax)
    3130:      	jmp	0x2a76 <kprobe_unwind_ruby+0x2a76>
    3135:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    313c:      	jae	0x332d <kprobe_unwind_ruby+0x332d>
    3142:      	movq	0x8(%rsp), %rax
    3147:      	cmpq	%rax, %r12
    314a:      	jbe	0x2b2 <kprobe_unwind_ruby+0x2b2>
    3150:      	movzbl	0x1e(%r15), %ecx
    3155:      	addq	%rcx, %rax
    3158:      	movq	%rax, 0x8(%rsp)
    315d:      	movq	$0x0, 0x18(%rsp)
    3166:      	movq	$0x0, 0x20(%rsp)
    316f:      	movzbl	0x1c(%r15), %ecx
    3174:      	addq	%rax, %rcx
    3177:      	leaq	0x20(%rsp), %rdi
    317c:      	movl	$0x8, %eax
    3181:      	movl	$0x70, %r8d
    3187:      	movzbl	0x1c(%r15), %edx
    318c:      	addq	0x8(%rsp), %rdx
    3191:      	movl	$0x8, %esi
    3196:      	callq	*%r8
    3199:      	movzbl	0x1b(%r15), %eax
    319e:      	addq	0x8(%rsp), %rax
    31a3:      	leaq	0x18(%rsp), %rdi
    31a8:      	movl	$0x8, %ecx
    31ad:      	movl	$0x70, %r8d
    31b3:      	movzbl	0x1b(%r15), %edx
    31b8:      	addq	0x8(%rsp), %rdx
    31bd:      	movl	$0x8, %esi
    31c2:      	callq	*%r8
    31c5:      	cmpq	$0x0, 0x18(%rsp)
    31cb:      	je	0x349b <kprobe_unwind_ruby+0x349b>
    31d1:      	movq	0x20(%rsp), %rax
    31d6:      	testq	%rax, %rax
    31d9:      	je	0x349b <kprobe_unwind_ruby+0x349b>
    31df:      	movzbl	0x1f(%r15), %ecx
    31e4:      	addq	%rcx, %rax
    31e7:      	leaq	0x10(%rsp), %rdi
    31ec:      	movl	$0x8, %ecx
    31f1:      	movl	$0x70, %r8d
    31f7:      	movzbl	0x1f(%r15), %edx
    31fc:      	addq	0x20(%rsp), %rdx
    3201:      	movl	$0x8, %esi
    3206:      	callq	*%r8
    3209:      	testq	%rax, %rax
    320c:      	jne	0x4c7 <kprobe_unwind_ruby+0x4c7>
    3212:      	movzbl	0x21(%r15), %eax
    3217:      	addq	0x10(%rsp), %rax
    321c:      	leaq	0x68(%rsp), %rdi
    3221:      	movl	$0x8, %ecx
    3226:      	movl	$0x70, %r8d
    322c:      	movzbl	0x21(%r15), %edx
    3231:      	addq	0x10(%rsp), %rdx
    3236:      	movl	$0x8, %esi
    323b:      	callq	*%r8
    323e:      	testq	%rax, %rax
    3241:      	jne	0x8a4 <kprobe_unwind_ruby+0x8a4>
    3247:      	movzbl	0x22(%r15), %eax
    324c:      	addq	0x10(%rsp), %rax
    3251:      	leaq	0x2c(%rsp), %rdi
    3256:      	movl	$0x4, %ecx
    325b:      	movl	$0x70, %r8d
    3261:      	movzbl	0x22(%r15), %edx
    3266:      	addq	0x10(%rsp), %rdx
    326b:      	movl	$0x4, %esi
    3270:      	callq	*%r8
    3273:      	testq	%rax, %rax
    3276:      	jne	0xc08 <kprobe_unwind_ruby+0xc08>
    327c:      	movzbl	0x23(%r15), %ecx
    3281:      	testq	%rcx, %rcx
    3284:      	je	0x3ad3 <kprobe_unwind_ruby+0x3ad3>
    328a:      	movq	0x18(%rsp), %rax
    328f:      	subq	0x68(%rsp), %rax
    3294:      	xorl	%edx, %edx
    3296:      	divq	%rcx
    3299:      	movl	0x2c(%rsp), %ecx
    329d:      	cmpq	%rcx, %rax
    32a0:      	jbe	0x3ad3 <kprobe_unwind_ruby+0x3ad3>
    32a6:      	movq	(%rip), %rax            # 0x32ad <kprobe_unwind_ruby+0x32ad>
    32ad:      	cmpl	$0x0, (%rax)
    32b0:      	je	0x34a8 <kprobe_unwind_ruby+0x34a8>
    32b6:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    32c0:      	movq	%rax, 0x55(%rsp)
    32c5:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    32cf:      	movq	%rax, 0x50(%rsp)
    32d4:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    32de:      	movq	%rax, 0x48(%rsp)
    32e3:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    32ed:      	movq	%rax, 0x40(%rsp)
    32f2:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    32fc:      	movq	%rax, 0x38(%rsp)
    3301:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    330b:      	movq	%rax, 0x30(%rsp)
    3310:      	leaq	0x30(%rsp), %rdi
    3315:      	movl	$0x2d, %eax
    331a:      	movl	$0x6, %ecx
    331f:      	movl	$0x2d, %esi
    3324:      	xorl	%eax, %eax
    3326:      	callq	*%rcx
    3328:      	jmp	0x34a8 <kprobe_unwind_ruby+0x34a8>
    332d:      	movq	$0x0, (%rsp)
    3335:      	movzbl	0x1d(%r15), %eax
    333a:      	addq	0x8(%rsp), %rax
    333f:      	movq	%rsp, %rdi
    3342:      	movl	$0x8, %ecx
    3347:      	movl	$0x70, %r8d
    334d:      	movzbl	0x1d(%r15), %edx
    3352:      	addq	0x8(%rsp), %rdx
    3357:      	movl	$0x8, %esi
    335c:      	callq	*%r8
    335f:      	testq	%rax, %rax
    3362:      	jne	0x81b <kprobe_unwind_ruby+0x81b>
    3368:      	movl	(%rsp), %eax
    336b:      	notl	%eax
    336d:      	testl	$0x140, %eax            # imm = 0x140
    3372:      	jne	0x997 <kprobe_unwind_ruby+0x997>
    3378:      	jmp	0x3142 <kprobe_unwind_ruby+0x3142>
    337d:      	movq	(%rip), %rax            # 0x3384 <kprobe_unwind_ruby+0x3384>
    3384:      	cmpl	$0x0, (%rax)
    3387:      	je	0x2a76 <kprobe_unwind_ruby+0x2a76>
    338d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3397:      	movq	%rax, 0x56(%rsp)
    339c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    33a6:      	movq	%rax, 0x50(%rsp)
    33ab:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    33b5:      	movq	%rax, 0x48(%rsp)
    33ba:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    33c4:      	movq	%rax, 0x40(%rsp)
    33c9:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    33d3:      	movq	%rax, 0x38(%rsp)
    33d8:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    33e2:      	movq	%rax, 0x30(%rsp)
    33e7:      	leaq	0x30(%rsp), %rdi
    33ec:      	movl	$0x2e, %eax
    33f1:      	movl	$0x6, %ecx
    33f6:      	movl	(%rsp), %edx
    33f9:      	movl	$0x2e, %esi
    33fe:      	xorl	%eax, %eax
    3400:      	callq	*%rcx
    3402:      	jmp	0x2a76 <kprobe_unwind_ruby+0x2a76>
    3407:      	movl	0x2c0(%r14), %eax
    340e:      	cmpq	$0x7e, %rax
    3412:      	ja	0xdd3 <kprobe_unwind_ruby+0xdd3>
    3418:      	movq	0x10(%rsp), %rcx
    341d:      	movq	0x18(%rsp), %rdx
    3422:      	leal	0x1(%rax), %esi
    3425:      	movl	%esi, 0x2c0(%r14)
    342c:      	leaq	(%rax,%rax,2), %rax
    3430:      	movw	$0x0, 0x4(%rsp)
    3437:      	movl	$0x0, (%rsp)
    343e:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    3446:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    344e:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    3459:      	movl	(%rsp), %ecx
    345c:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    3464:      	movzwl	0x4(%rsp), %ecx
    3469:      	movw	%cx, 0x2e6(%r14,%rax,8)
    3472:      	movl	$0x36, (%rsp)
    3479:      	movq	(%rip), %rdi            # 0x3480 <kprobe_unwind_ruby+0x3480>
    3480:      	movq	%rsp, %rsi
    3483:      	movl	$0x1, %eax
    3488:      	callq	*%rax
    348a:      	testq	%rax, %rax
    348d:      	je	0x36e3 <kprobe_unwind_ruby+0x36e3>
    3493:      	incq	(%rax)
    3496:      	jmp	0x2ddc <kprobe_unwind_ruby+0x2ddc>
    349b:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    34a2:      	jae	0x3693 <kprobe_unwind_ruby+0x3693>
    34a8:      	movq	0x8(%rsp), %rax
    34ad:      	cmpq	%rax, %r12
    34b0:      	jbe	0x2b2 <kprobe_unwind_ruby+0x2b2>
    34b6:      	movzbl	0x1e(%r15), %ecx
    34bb:      	addq	%rcx, %rax
    34be:      	movq	%rax, 0x8(%rsp)
    34c3:      	movq	$0x0, 0x18(%rsp)
    34cc:      	movq	$0x0, 0x20(%rsp)
    34d5:      	movzbl	0x1c(%r15), %ecx
    34da:      	addq	%rax, %rcx
    34dd:      	leaq	0x20(%rsp), %rdi
    34e2:      	movl	$0x8, %eax
    34e7:      	movl	$0x70, %r8d
    34ed:      	movzbl	0x1c(%r15), %edx
    34f2:      	addq	0x8(%rsp), %rdx
    34f7:      	movl	$0x8, %esi
    34fc:      	callq	*%r8
    34ff:      	movzbl	0x1b(%r15), %eax
    3504:      	addq	0x8(%rsp), %rax
    3509:      	leaq	0x18(%rsp), %rdi
    350e:      	movl	$0x8, %ecx
    3513:      	movl	$0x70, %r8d
    3519:      	movzbl	0x1b(%r15), %edx
    351e:      	addq	0x8(%rsp), %rdx
    3523:      	movl	$0x8, %esi
    3528:      	callq	*%r8
    352b:      	cmpq	$0x0, 0x18(%rsp)
    3531:      	je	0x3801 <kprobe_unwind_ruby+0x3801>
    3537:      	movq	0x20(%rsp), %rax
    353c:      	testq	%rax, %rax
    353f:      	je	0x3801 <kprobe_unwind_ruby+0x3801>
    3545:      	movzbl	0x1f(%r15), %ecx
    354a:      	addq	%rcx, %rax
    354d:      	leaq	0x10(%rsp), %rdi
    3552:      	movl	$0x8, %ecx
    3557:      	movl	$0x70, %r8d
    355d:      	movzbl	0x1f(%r15), %edx
    3562:      	addq	0x20(%rsp), %rdx
    3567:      	movl	$0x8, %esi
    356c:      	callq	*%r8
    356f:      	testq	%rax, %rax
    3572:      	jne	0x4c7 <kprobe_unwind_ruby+0x4c7>
    3578:      	movzbl	0x21(%r15), %eax
    357d:      	addq	0x10(%rsp), %rax
    3582:      	leaq	0x68(%rsp), %rdi
    3587:      	movl	$0x8, %ecx
    358c:      	movl	$0x70, %r8d
    3592:      	movzbl	0x21(%r15), %edx
    3597:      	addq	0x10(%rsp), %rdx
    359c:      	movl	$0x8, %esi
    35a1:      	callq	*%r8
    35a4:      	testq	%rax, %rax
    35a7:      	jne	0x8a4 <kprobe_unwind_ruby+0x8a4>
    35ad:      	movzbl	0x22(%r15), %eax
    35b2:      	addq	0x10(%rsp), %rax
    35b7:      	leaq	0x2c(%rsp), %rdi
    35bc:      	movl	$0x4, %ecx
    35c1:      	movl	$0x70, %r8d
    35c7:      	movzbl	0x22(%r15), %edx
    35cc:      	addq	0x10(%rsp), %rdx
    35d1:      	movl	$0x4, %esi
    35d6:      	callq	*%r8
    35d9:      	testq	%rax, %rax
    35dc:      	jne	0xc08 <kprobe_unwind_ruby+0xc08>
    35e2:      	movzbl	0x23(%r15), %ecx
    35e7:      	testq	%rcx, %rcx
    35ea:      	je	0x3e39 <kprobe_unwind_ruby+0x3e39>
    35f0:      	movq	0x18(%rsp), %rax
    35f5:      	subq	0x68(%rsp), %rax
    35fa:      	xorl	%edx, %edx
    35fc:      	divq	%rcx
    35ff:      	movl	0x2c(%rsp), %ecx
    3603:      	cmpq	%rcx, %rax
    3606:      	jbe	0x3e39 <kprobe_unwind_ruby+0x3e39>
    360c:      	movq	(%rip), %rax            # 0x3613 <kprobe_unwind_ruby+0x3613>
    3613:      	cmpl	$0x0, (%rax)
    3616:      	je	0x380e <kprobe_unwind_ruby+0x380e>
    361c:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    3626:      	movq	%rax, 0x55(%rsp)
    362b:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    3635:      	movq	%rax, 0x50(%rsp)
    363a:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    3644:      	movq	%rax, 0x48(%rsp)
    3649:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    3653:      	movq	%rax, 0x40(%rsp)
    3658:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    3662:      	movq	%rax, 0x38(%rsp)
    3667:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    3671:      	movq	%rax, 0x30(%rsp)
    3676:      	leaq	0x30(%rsp), %rdi
    367b:      	movl	$0x2d, %eax
    3680:      	movl	$0x6, %ecx
    3685:      	movl	$0x2d, %esi
    368a:      	xorl	%eax, %eax
    368c:      	callq	*%rcx
    368e:      	jmp	0x380e <kprobe_unwind_ruby+0x380e>
    3693:      	movq	$0x0, (%rsp)
    369b:      	movzbl	0x1d(%r15), %eax
    36a0:      	addq	0x8(%rsp), %rax
    36a5:      	movq	%rsp, %rdi
    36a8:      	movl	$0x8, %ecx
    36ad:      	movl	$0x70, %r8d
    36b3:      	movzbl	0x1d(%r15), %edx
    36b8:      	addq	0x8(%rsp), %rdx
    36bd:      	movl	$0x8, %esi
    36c2:      	callq	*%r8
    36c5:      	testq	%rax, %rax
    36c8:      	jne	0x81b <kprobe_unwind_ruby+0x81b>
    36ce:      	movl	(%rsp), %eax
    36d1:      	notl	%eax
    36d3:      	testl	$0x140, %eax            # imm = 0x140
    36d8:      	jne	0x997 <kprobe_unwind_ruby+0x997>
    36de:      	jmp	0x34a8 <kprobe_unwind_ruby+0x34a8>
    36e3:      	movq	(%rip), %rax            # 0x36ea <kprobe_unwind_ruby+0x36ea>
    36ea:      	cmpl	$0x0, (%rax)
    36ed:      	je	0x2ddc <kprobe_unwind_ruby+0x2ddc>
    36f3:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    36fd:      	movq	%rax, 0x56(%rsp)
    3702:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    370c:      	movq	%rax, 0x50(%rsp)
    3711:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    371b:      	movq	%rax, 0x48(%rsp)
    3720:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    372a:      	movq	%rax, 0x40(%rsp)
    372f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3739:      	movq	%rax, 0x38(%rsp)
    373e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3748:      	movq	%rax, 0x30(%rsp)
    374d:      	leaq	0x30(%rsp), %rdi
    3752:      	movl	$0x2e, %eax
    3757:      	movl	$0x6, %ecx
    375c:      	movl	(%rsp), %edx
    375f:      	movl	$0x2e, %esi
    3764:      	xorl	%eax, %eax
    3766:      	callq	*%rcx
    3768:      	jmp	0x2ddc <kprobe_unwind_ruby+0x2ddc>
    376d:      	movl	0x2c0(%r14), %eax
    3774:      	cmpq	$0x7e, %rax
    3778:      	ja	0xdd3 <kprobe_unwind_ruby+0xdd3>
    377e:      	movq	0x10(%rsp), %rcx
    3783:      	movq	0x18(%rsp), %rdx
    3788:      	leal	0x1(%rax), %esi
    378b:      	movl	%esi, 0x2c0(%r14)
    3792:      	leaq	(%rax,%rax,2), %rax
    3796:      	movw	$0x0, 0x4(%rsp)
    379d:      	movl	$0x0, (%rsp)
    37a4:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    37ac:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    37b4:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    37bf:      	movl	(%rsp), %ecx
    37c2:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    37ca:      	movzwl	0x4(%rsp), %ecx
    37cf:      	movw	%cx, 0x2e6(%r14,%rax,8)
    37d8:      	movl	$0x36, (%rsp)
    37df:      	movq	(%rip), %rdi            # 0x37e6 <kprobe_unwind_ruby+0x37e6>
    37e6:      	movq	%rsp, %rsi
    37e9:      	movl	$0x1, %eax
    37ee:      	callq	*%rax
    37f0:      	testq	%rax, %rax
    37f3:      	je	0x3a49 <kprobe_unwind_ruby+0x3a49>
    37f9:      	incq	(%rax)
    37fc:      	jmp	0x3142 <kprobe_unwind_ruby+0x3142>
    3801:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    3808:      	jae	0x39f9 <kprobe_unwind_ruby+0x39f9>
    380e:      	movq	0x8(%rsp), %rax
    3813:      	cmpq	%rax, %r12
    3816:      	jbe	0x2b2 <kprobe_unwind_ruby+0x2b2>
    381c:      	movzbl	0x1e(%r15), %ecx
    3821:      	addq	%rcx, %rax
    3824:      	movq	%rax, 0x8(%rsp)
    3829:      	movq	$0x0, 0x18(%rsp)
    3832:      	movq	$0x0, 0x20(%rsp)
    383b:      	movzbl	0x1c(%r15), %ecx
    3840:      	addq	%rax, %rcx
    3843:      	leaq	0x20(%rsp), %rdi
    3848:      	movl	$0x8, %eax
    384d:      	movl	$0x70, %r8d
    3853:      	movzbl	0x1c(%r15), %edx
    3858:      	addq	0x8(%rsp), %rdx
    385d:      	movl	$0x8, %esi
    3862:      	callq	*%r8
    3865:      	movzbl	0x1b(%r15), %eax
    386a:      	addq	0x8(%rsp), %rax
    386f:      	leaq	0x18(%rsp), %rdi
    3874:      	movl	$0x8, %ecx
    3879:      	movl	$0x70, %r8d
    387f:      	movzbl	0x1b(%r15), %edx
    3884:      	addq	0x8(%rsp), %rdx
    3889:      	movl	$0x8, %esi
    388e:      	callq	*%r8
    3891:      	cmpq	$0x0, 0x18(%rsp)
    3897:      	je	0x3b67 <kprobe_unwind_ruby+0x3b67>
    389d:      	movq	0x20(%rsp), %rax
    38a2:      	testq	%rax, %rax
    38a5:      	je	0x3b67 <kprobe_unwind_ruby+0x3b67>
    38ab:      	movzbl	0x1f(%r15), %ecx
    38b0:      	addq	%rcx, %rax
    38b3:      	leaq	0x10(%rsp), %rdi
    38b8:      	movl	$0x8, %ecx
    38bd:      	movl	$0x70, %r8d
    38c3:      	movzbl	0x1f(%r15), %edx
    38c8:      	addq	0x20(%rsp), %rdx
    38cd:      	movl	$0x8, %esi
    38d2:      	callq	*%r8
    38d5:      	testq	%rax, %rax
    38d8:      	jne	0x4c7 <kprobe_unwind_ruby+0x4c7>
    38de:      	movzbl	0x21(%r15), %eax
    38e3:      	addq	0x10(%rsp), %rax
    38e8:      	leaq	0x68(%rsp), %rdi
    38ed:      	movl	$0x8, %ecx
    38f2:      	movl	$0x70, %r8d
    38f8:      	movzbl	0x21(%r15), %edx
    38fd:      	addq	0x10(%rsp), %rdx
    3902:      	movl	$0x8, %esi
    3907:      	callq	*%r8
    390a:      	testq	%rax, %rax
    390d:      	jne	0x8a4 <kprobe_unwind_ruby+0x8a4>
    3913:      	movzbl	0x22(%r15), %eax
    3918:      	addq	0x10(%rsp), %rax
    391d:      	leaq	0x2c(%rsp), %rdi
    3922:      	movl	$0x4, %ecx
    3927:      	movl	$0x70, %r8d
    392d:      	movzbl	0x22(%r15), %edx
    3932:      	addq	0x10(%rsp), %rdx
    3937:      	movl	$0x4, %esi
    393c:      	callq	*%r8
    393f:      	testq	%rax, %rax
    3942:      	jne	0xc08 <kprobe_unwind_ruby+0xc08>
    3948:      	movzbl	0x23(%r15), %ecx
    394d:      	testq	%rcx, %rcx
    3950:      	je	0x419f <kprobe_unwind_ruby+0x419f>
    3956:      	movq	0x18(%rsp), %rax
    395b:      	subq	0x68(%rsp), %rax
    3960:      	xorl	%edx, %edx
    3962:      	divq	%rcx
    3965:      	movl	0x2c(%rsp), %ecx
    3969:      	cmpq	%rcx, %rax
    396c:      	jbe	0x419f <kprobe_unwind_ruby+0x419f>
    3972:      	movq	(%rip), %rax            # 0x3979 <kprobe_unwind_ruby+0x3979>
    3979:      	cmpl	$0x0, (%rax)
    397c:      	je	0x3b74 <kprobe_unwind_ruby+0x3b74>
    3982:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    398c:      	movq	%rax, 0x55(%rsp)
    3991:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    399b:      	movq	%rax, 0x50(%rsp)
    39a0:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    39aa:      	movq	%rax, 0x48(%rsp)
    39af:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    39b9:      	movq	%rax, 0x40(%rsp)
    39be:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    39c8:      	movq	%rax, 0x38(%rsp)
    39cd:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    39d7:      	movq	%rax, 0x30(%rsp)
    39dc:      	leaq	0x30(%rsp), %rdi
    39e1:      	movl	$0x2d, %eax
    39e6:      	movl	$0x6, %ecx
    39eb:      	movl	$0x2d, %esi
    39f0:      	xorl	%eax, %eax
    39f2:      	callq	*%rcx
    39f4:      	jmp	0x3b74 <kprobe_unwind_ruby+0x3b74>
    39f9:      	movq	$0x0, (%rsp)
    3a01:      	movzbl	0x1d(%r15), %eax
    3a06:      	addq	0x8(%rsp), %rax
    3a0b:      	movq	%rsp, %rdi
    3a0e:      	movl	$0x8, %ecx
    3a13:      	movl	$0x70, %r8d
    3a19:      	movzbl	0x1d(%r15), %edx
    3a1e:      	addq	0x8(%rsp), %rdx
    3a23:      	movl	$0x8, %esi
    3a28:      	callq	*%r8
    3a2b:      	testq	%rax, %rax
    3a2e:      	jne	0x81b <kprobe_unwind_ruby+0x81b>
    3a34:      	movl	(%rsp), %eax
    3a37:      	notl	%eax
    3a39:      	testl	$0x140, %eax            # imm = 0x140
    3a3e:      	jne	0x997 <kprobe_unwind_ruby+0x997>
    3a44:      	jmp	0x380e <kprobe_unwind_ruby+0x380e>
    3a49:      	movq	(%rip), %rax            # 0x3a50 <kprobe_unwind_ruby+0x3a50>
    3a50:      	cmpl	$0x0, (%rax)
    3a53:      	je	0x3142 <kprobe_unwind_ruby+0x3142>
    3a59:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3a63:      	movq	%rax, 0x56(%rsp)
    3a68:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3a72:      	movq	%rax, 0x50(%rsp)
    3a77:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3a81:      	movq	%rax, 0x48(%rsp)
    3a86:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3a90:      	movq	%rax, 0x40(%rsp)
    3a95:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3a9f:      	movq	%rax, 0x38(%rsp)
    3aa4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3aae:      	movq	%rax, 0x30(%rsp)
    3ab3:      	leaq	0x30(%rsp), %rdi
    3ab8:      	movl	$0x2e, %eax
    3abd:      	movl	$0x6, %ecx
    3ac2:      	movl	(%rsp), %edx
    3ac5:      	movl	$0x2e, %esi
    3aca:      	xorl	%eax, %eax
    3acc:      	callq	*%rcx
    3ace:      	jmp	0x3142 <kprobe_unwind_ruby+0x3142>
    3ad3:      	movl	0x2c0(%r14), %eax
    3ada:      	cmpq	$0x7e, %rax
    3ade:      	ja	0xdd3 <kprobe_unwind_ruby+0xdd3>
    3ae4:      	movq	0x10(%rsp), %rcx
    3ae9:      	movq	0x18(%rsp), %rdx
    3aee:      	leal	0x1(%rax), %esi
    3af1:      	movl	%esi, 0x2c0(%r14)
    3af8:      	leaq	(%rax,%rax,2), %rax
    3afc:      	movw	$0x0, 0x4(%rsp)
    3b03:      	movl	$0x0, (%rsp)
    3b0a:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    3b12:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    3b1a:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    3b25:      	movl	(%rsp), %ecx
    3b28:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    3b30:      	movzwl	0x4(%rsp), %ecx
    3b35:      	movw	%cx, 0x2e6(%r14,%rax,8)
    3b3e:      	movl	$0x36, (%rsp)
    3b45:      	movq	(%rip), %rdi            # 0x3b4c <kprobe_unwind_ruby+0x3b4c>
    3b4c:      	movq	%rsp, %rsi
    3b4f:      	movl	$0x1, %eax
    3b54:      	callq	*%rax
    3b56:      	testq	%rax, %rax
    3b59:      	je	0x3daf <kprobe_unwind_ruby+0x3daf>
    3b5f:      	incq	(%rax)
    3b62:      	jmp	0x34a8 <kprobe_unwind_ruby+0x34a8>
    3b67:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    3b6e:      	jae	0x3d5f <kprobe_unwind_ruby+0x3d5f>
    3b74:      	movq	0x8(%rsp), %rax
    3b79:      	cmpq	%rax, %r12
    3b7c:      	jbe	0x2b2 <kprobe_unwind_ruby+0x2b2>
    3b82:      	movzbl	0x1e(%r15), %ecx
    3b87:      	addq	%rcx, %rax
    3b8a:      	movq	%rax, 0x8(%rsp)
    3b8f:      	movq	$0x0, 0x18(%rsp)
    3b98:      	movq	$0x0, 0x20(%rsp)
    3ba1:      	movzbl	0x1c(%r15), %ecx
    3ba6:      	addq	%rax, %rcx
    3ba9:      	leaq	0x20(%rsp), %rdi
    3bae:      	movl	$0x8, %eax
    3bb3:      	movl	$0x70, %r8d
    3bb9:      	movzbl	0x1c(%r15), %edx
    3bbe:      	addq	0x8(%rsp), %rdx
    3bc3:      	movl	$0x8, %esi
    3bc8:      	callq	*%r8
    3bcb:      	movzbl	0x1b(%r15), %eax
    3bd0:      	addq	0x8(%rsp), %rax
    3bd5:      	leaq	0x18(%rsp), %rdi
    3bda:      	movl	$0x8, %ecx
    3bdf:      	movl	$0x70, %r8d
    3be5:      	movzbl	0x1b(%r15), %edx
    3bea:      	addq	0x8(%rsp), %rdx
    3bef:      	movl	$0x8, %esi
    3bf4:      	callq	*%r8
    3bf7:      	cmpq	$0x0, 0x18(%rsp)
    3bfd:      	je	0x3ecd <kprobe_unwind_ruby+0x3ecd>
    3c03:      	movq	0x20(%rsp), %rax
    3c08:      	testq	%rax, %rax
    3c0b:      	je	0x3ecd <kprobe_unwind_ruby+0x3ecd>
    3c11:      	movzbl	0x1f(%r15), %ecx
    3c16:      	addq	%rcx, %rax
    3c19:      	leaq	0x10(%rsp), %rdi
    3c1e:      	movl	$0x8, %ecx
    3c23:      	movl	$0x70, %r8d
    3c29:      	movzbl	0x1f(%r15), %edx
    3c2e:      	addq	0x20(%rsp), %rdx
    3c33:      	movl	$0x8, %esi
    3c38:      	callq	*%r8
    3c3b:      	testq	%rax, %rax
    3c3e:      	jne	0x4c7 <kprobe_unwind_ruby+0x4c7>
    3c44:      	movzbl	0x21(%r15), %eax
    3c49:      	addq	0x10(%rsp), %rax
    3c4e:      	leaq	0x68(%rsp), %rdi
    3c53:      	movl	$0x8, %ecx
    3c58:      	movl	$0x70, %r8d
    3c5e:      	movzbl	0x21(%r15), %edx
    3c63:      	addq	0x10(%rsp), %rdx
    3c68:      	movl	$0x8, %esi
    3c6d:      	callq	*%r8
    3c70:      	testq	%rax, %rax
    3c73:      	jne	0x8a4 <kprobe_unwind_ruby+0x8a4>
    3c79:      	movzbl	0x22(%r15), %eax
    3c7e:      	addq	0x10(%rsp), %rax
    3c83:      	leaq	0x2c(%rsp), %rdi
    3c88:      	movl	$0x4, %ecx
    3c8d:      	movl	$0x70, %r8d
    3c93:      	movzbl	0x22(%r15), %edx
    3c98:      	addq	0x10(%rsp), %rdx
    3c9d:      	movl	$0x4, %esi
    3ca2:      	callq	*%r8
    3ca5:      	testq	%rax, %rax
    3ca8:      	jne	0xc08 <kprobe_unwind_ruby+0xc08>
    3cae:      	movzbl	0x23(%r15), %ecx
    3cb3:      	testq	%rcx, %rcx
    3cb6:      	je	0x4505 <kprobe_unwind_ruby+0x4505>
    3cbc:      	movq	0x18(%rsp), %rax
    3cc1:      	subq	0x68(%rsp), %rax
    3cc6:      	xorl	%edx, %edx
    3cc8:      	divq	%rcx
    3ccb:      	movl	0x2c(%rsp), %ecx
    3ccf:      	cmpq	%rcx, %rax
    3cd2:      	jbe	0x4505 <kprobe_unwind_ruby+0x4505>
    3cd8:      	movq	(%rip), %rax            # 0x3cdf <kprobe_unwind_ruby+0x3cdf>
    3cdf:      	cmpl	$0x0, (%rax)
    3ce2:      	je	0x3eda <kprobe_unwind_ruby+0x3eda>
    3ce8:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    3cf2:      	movq	%rax, 0x55(%rsp)
    3cf7:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    3d01:      	movq	%rax, 0x50(%rsp)
    3d06:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    3d10:      	movq	%rax, 0x48(%rsp)
    3d15:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    3d1f:      	movq	%rax, 0x40(%rsp)
    3d24:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    3d2e:      	movq	%rax, 0x38(%rsp)
    3d33:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    3d3d:      	movq	%rax, 0x30(%rsp)
    3d42:      	leaq	0x30(%rsp), %rdi
    3d47:      	movl	$0x2d, %eax
    3d4c:      	movl	$0x6, %ecx
    3d51:      	movl	$0x2d, %esi
    3d56:      	xorl	%eax, %eax
    3d58:      	callq	*%rcx
    3d5a:      	jmp	0x3eda <kprobe_unwind_ruby+0x3eda>
    3d5f:      	movq	$0x0, (%rsp)
    3d67:      	movzbl	0x1d(%r15), %eax
    3d6c:      	addq	0x8(%rsp), %rax
    3d71:      	movq	%rsp, %rdi
    3d74:      	movl	$0x8, %ecx
    3d79:      	movl	$0x70, %r8d
    3d7f:      	movzbl	0x1d(%r15), %edx
    3d84:      	addq	0x8(%rsp), %rdx
    3d89:      	movl	$0x8, %esi
    3d8e:      	callq	*%r8
    3d91:      	testq	%rax, %rax
    3d94:      	jne	0x81b <kprobe_unwind_ruby+0x81b>
    3d9a:      	movl	(%rsp), %eax
    3d9d:      	notl	%eax
    3d9f:      	testl	$0x140, %eax            # imm = 0x140
    3da4:      	jne	0x997 <kprobe_unwind_ruby+0x997>
    3daa:      	jmp	0x3b74 <kprobe_unwind_ruby+0x3b74>
    3daf:      	movq	(%rip), %rax            # 0x3db6 <kprobe_unwind_ruby+0x3db6>
    3db6:      	cmpl	$0x0, (%rax)
    3db9:      	je	0x34a8 <kprobe_unwind_ruby+0x34a8>
    3dbf:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3dc9:      	movq	%rax, 0x56(%rsp)
    3dce:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3dd8:      	movq	%rax, 0x50(%rsp)
    3ddd:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3de7:      	movq	%rax, 0x48(%rsp)
    3dec:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3df6:      	movq	%rax, 0x40(%rsp)
    3dfb:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3e05:      	movq	%rax, 0x38(%rsp)
    3e0a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3e14:      	movq	%rax, 0x30(%rsp)
    3e19:      	leaq	0x30(%rsp), %rdi
    3e1e:      	movl	$0x2e, %eax
    3e23:      	movl	$0x6, %ecx
    3e28:      	movl	(%rsp), %edx
    3e2b:      	movl	$0x2e, %esi
    3e30:      	xorl	%eax, %eax
    3e32:      	callq	*%rcx
    3e34:      	jmp	0x34a8 <kprobe_unwind_ruby+0x34a8>
    3e39:      	movl	0x2c0(%r14), %eax
    3e40:      	cmpq	$0x7e, %rax
    3e44:      	ja	0xdd3 <kprobe_unwind_ruby+0xdd3>
    3e4a:      	movq	0x10(%rsp), %rcx
    3e4f:      	movq	0x18(%rsp), %rdx
    3e54:      	leal	0x1(%rax), %esi
    3e57:      	movl	%esi, 0x2c0(%r14)
    3e5e:      	leaq	(%rax,%rax,2), %rax
    3e62:      	movw	$0x0, 0x4(%rsp)
    3e69:      	movl	$0x0, (%rsp)
    3e70:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    3e78:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    3e80:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    3e8b:      	movl	(%rsp), %ecx
    3e8e:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    3e96:      	movzwl	0x4(%rsp), %ecx
    3e9b:      	movw	%cx, 0x2e6(%r14,%rax,8)
    3ea4:      	movl	$0x36, (%rsp)
    3eab:      	movq	(%rip), %rdi            # 0x3eb2 <kprobe_unwind_ruby+0x3eb2>
    3eb2:      	movq	%rsp, %rsi
    3eb5:      	movl	$0x1, %eax
    3eba:      	callq	*%rax
    3ebc:      	testq	%rax, %rax
    3ebf:      	je	0x4115 <kprobe_unwind_ruby+0x4115>
    3ec5:      	incq	(%rax)
    3ec8:      	jmp	0x380e <kprobe_unwind_ruby+0x380e>
    3ecd:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    3ed4:      	jae	0x40c5 <kprobe_unwind_ruby+0x40c5>
    3eda:      	movq	0x8(%rsp), %rax
    3edf:      	cmpq	%rax, %r12
    3ee2:      	jbe	0x2b2 <kprobe_unwind_ruby+0x2b2>
    3ee8:      	movzbl	0x1e(%r15), %ecx
    3eed:      	addq	%rcx, %rax
    3ef0:      	movq	%rax, 0x8(%rsp)
    3ef5:      	movq	$0x0, 0x18(%rsp)
    3efe:      	movq	$0x0, 0x20(%rsp)
    3f07:      	movzbl	0x1c(%r15), %ecx
    3f0c:      	addq	%rax, %rcx
    3f0f:      	leaq	0x20(%rsp), %rdi
    3f14:      	movl	$0x8, %eax
    3f19:      	movl	$0x70, %r8d
    3f1f:      	movzbl	0x1c(%r15), %edx
    3f24:      	addq	0x8(%rsp), %rdx
    3f29:      	movl	$0x8, %esi
    3f2e:      	callq	*%r8
    3f31:      	movzbl	0x1b(%r15), %eax
    3f36:      	addq	0x8(%rsp), %rax
    3f3b:      	leaq	0x18(%rsp), %rdi
    3f40:      	movl	$0x8, %ecx
    3f45:      	movl	$0x70, %r8d
    3f4b:      	movzbl	0x1b(%r15), %edx
    3f50:      	addq	0x8(%rsp), %rdx
    3f55:      	movl	$0x8, %esi
    3f5a:      	callq	*%r8
    3f5d:      	cmpq	$0x0, 0x18(%rsp)
    3f63:      	je	0x4233 <kprobe_unwind_ruby+0x4233>
    3f69:      	movq	0x20(%rsp), %rax
    3f6e:      	testq	%rax, %rax
    3f71:      	je	0x4233 <kprobe_unwind_ruby+0x4233>
    3f77:      	movzbl	0x1f(%r15), %ecx
    3f7c:      	addq	%rcx, %rax
    3f7f:      	leaq	0x10(%rsp), %rdi
    3f84:      	movl	$0x8, %ecx
    3f89:      	movl	$0x70, %r8d
    3f8f:      	movzbl	0x1f(%r15), %edx
    3f94:      	addq	0x20(%rsp), %rdx
    3f99:      	movl	$0x8, %esi
    3f9e:      	callq	*%r8
    3fa1:      	testq	%rax, %rax
    3fa4:      	jne	0x4c7 <kprobe_unwind_ruby+0x4c7>
    3faa:      	movzbl	0x21(%r15), %eax
    3faf:      	addq	0x10(%rsp), %rax
    3fb4:      	leaq	0x68(%rsp), %rdi
    3fb9:      	movl	$0x8, %ecx
    3fbe:      	movl	$0x70, %r8d
    3fc4:      	movzbl	0x21(%r15), %edx
    3fc9:      	addq	0x10(%rsp), %rdx
    3fce:      	movl	$0x8, %esi
    3fd3:      	callq	*%r8
    3fd6:      	testq	%rax, %rax
    3fd9:      	jne	0x8a4 <kprobe_unwind_ruby+0x8a4>
    3fdf:      	movzbl	0x22(%r15), %eax
    3fe4:      	addq	0x10(%rsp), %rax
    3fe9:      	leaq	0x2c(%rsp), %rdi
    3fee:      	movl	$0x4, %ecx
    3ff3:      	movl	$0x70, %r8d
    3ff9:      	movzbl	0x22(%r15), %edx
    3ffe:      	addq	0x10(%rsp), %rdx
    4003:      	movl	$0x4, %esi
    4008:      	callq	*%r8
    400b:      	testq	%rax, %rax
    400e:      	jne	0xc08 <kprobe_unwind_ruby+0xc08>
    4014:      	movzbl	0x23(%r15), %ecx
    4019:      	testq	%rcx, %rcx
    401c:      	je	0x486b <kprobe_unwind_ruby+0x486b>
    4022:      	movq	0x18(%rsp), %rax
    4027:      	subq	0x68(%rsp), %rax
    402c:      	xorl	%edx, %edx
    402e:      	divq	%rcx
    4031:      	movl	0x2c(%rsp), %ecx
    4035:      	cmpq	%rcx, %rax
    4038:      	jbe	0x486b <kprobe_unwind_ruby+0x486b>
    403e:      	movq	(%rip), %rax            # 0x4045 <kprobe_unwind_ruby+0x4045>
    4045:      	cmpl	$0x0, (%rax)
    4048:      	je	0x4240 <kprobe_unwind_ruby+0x4240>
    404e:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    4058:      	movq	%rax, 0x55(%rsp)
    405d:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    4067:      	movq	%rax, 0x50(%rsp)
    406c:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    4076:      	movq	%rax, 0x48(%rsp)
    407b:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    4085:      	movq	%rax, 0x40(%rsp)
    408a:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    4094:      	movq	%rax, 0x38(%rsp)
    4099:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    40a3:      	movq	%rax, 0x30(%rsp)
    40a8:      	leaq	0x30(%rsp), %rdi
    40ad:      	movl	$0x2d, %eax
    40b2:      	movl	$0x6, %ecx
    40b7:      	movl	$0x2d, %esi
    40bc:      	xorl	%eax, %eax
    40be:      	callq	*%rcx
    40c0:      	jmp	0x4240 <kprobe_unwind_ruby+0x4240>
    40c5:      	movq	$0x0, (%rsp)
    40cd:      	movzbl	0x1d(%r15), %eax
    40d2:      	addq	0x8(%rsp), %rax
    40d7:      	movq	%rsp, %rdi
    40da:      	movl	$0x8, %ecx
    40df:      	movl	$0x70, %r8d
    40e5:      	movzbl	0x1d(%r15), %edx
    40ea:      	addq	0x8(%rsp), %rdx
    40ef:      	movl	$0x8, %esi
    40f4:      	callq	*%r8
    40f7:      	testq	%rax, %rax
    40fa:      	jne	0x81b <kprobe_unwind_ruby+0x81b>
    4100:      	movl	(%rsp), %eax
    4103:      	notl	%eax
    4105:      	testl	$0x140, %eax            # imm = 0x140
    410a:      	jne	0x997 <kprobe_unwind_ruby+0x997>
    4110:      	jmp	0x3eda <kprobe_unwind_ruby+0x3eda>
    4115:      	movq	(%rip), %rax            # 0x411c <kprobe_unwind_ruby+0x411c>
    411c:      	cmpl	$0x0, (%rax)
    411f:      	je	0x380e <kprobe_unwind_ruby+0x380e>
    4125:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    412f:      	movq	%rax, 0x56(%rsp)
    4134:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    413e:      	movq	%rax, 0x50(%rsp)
    4143:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    414d:      	movq	%rax, 0x48(%rsp)
    4152:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    415c:      	movq	%rax, 0x40(%rsp)
    4161:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    416b:      	movq	%rax, 0x38(%rsp)
    4170:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    417a:      	movq	%rax, 0x30(%rsp)
    417f:      	leaq	0x30(%rsp), %rdi
    4184:      	movl	$0x2e, %eax
    4189:      	movl	$0x6, %ecx
    418e:      	movl	(%rsp), %edx
    4191:      	movl	$0x2e, %esi
    4196:      	xorl	%eax, %eax
    4198:      	callq	*%rcx
    419a:      	jmp	0x380e <kprobe_unwind_ruby+0x380e>
    419f:      	movl	0x2c0(%r14), %eax
    41a6:      	cmpq	$0x7e, %rax
    41aa:      	ja	0xdd3 <kprobe_unwind_ruby+0xdd3>
    41b0:      	movq	0x10(%rsp), %rcx
    41b5:      	movq	0x18(%rsp), %rdx
    41ba:      	leal	0x1(%rax), %esi
    41bd:      	movl	%esi, 0x2c0(%r14)
    41c4:      	leaq	(%rax,%rax,2), %rax
    41c8:      	movw	$0x0, 0x4(%rsp)
    41cf:      	movl	$0x0, (%rsp)
    41d6:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    41de:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    41e6:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    41f1:      	movl	(%rsp), %ecx
    41f4:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    41fc:      	movzwl	0x4(%rsp), %ecx
    4201:      	movw	%cx, 0x2e6(%r14,%rax,8)
    420a:      	movl	$0x36, (%rsp)
    4211:      	movq	(%rip), %rdi            # 0x4218 <kprobe_unwind_ruby+0x4218>
    4218:      	movq	%rsp, %rsi
    421b:      	movl	$0x1, %eax
    4220:      	callq	*%rax
    4222:      	testq	%rax, %rax
    4225:      	je	0x447b <kprobe_unwind_ruby+0x447b>
    422b:      	incq	(%rax)
    422e:      	jmp	0x3b74 <kprobe_unwind_ruby+0x3b74>
    4233:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    423a:      	jae	0x442b <kprobe_unwind_ruby+0x442b>
    4240:      	movq	0x8(%rsp), %rax
    4245:      	cmpq	%rax, %r12
    4248:      	jbe	0x2b2 <kprobe_unwind_ruby+0x2b2>
    424e:      	movzbl	0x1e(%r15), %ecx
    4253:      	addq	%rcx, %rax
    4256:      	movq	%rax, 0x8(%rsp)
    425b:      	movq	$0x0, 0x18(%rsp)
    4264:      	movq	$0x0, 0x20(%rsp)
    426d:      	movzbl	0x1c(%r15), %ecx
    4272:      	addq	%rax, %rcx
    4275:      	leaq	0x20(%rsp), %rdi
    427a:      	movl	$0x8, %eax
    427f:      	movl	$0x70, %r8d
    4285:      	movzbl	0x1c(%r15), %edx
    428a:      	addq	0x8(%rsp), %rdx
    428f:      	movl	$0x8, %esi
    4294:      	callq	*%r8
    4297:      	movzbl	0x1b(%r15), %eax
    429c:      	addq	0x8(%rsp), %rax
    42a1:      	leaq	0x18(%rsp), %rdi
    42a6:      	movl	$0x8, %ecx
    42ab:      	movl	$0x70, %r8d
    42b1:      	movzbl	0x1b(%r15), %edx
    42b6:      	addq	0x8(%rsp), %rdx
    42bb:      	movl	$0x8, %esi
    42c0:      	callq	*%r8
    42c3:      	cmpq	$0x0, 0x18(%rsp)
    42c9:      	je	0x4599 <kprobe_unwind_ruby+0x4599>
    42cf:      	movq	0x20(%rsp), %rax
    42d4:      	testq	%rax, %rax
    42d7:      	je	0x4599 <kprobe_unwind_ruby+0x4599>
    42dd:      	movzbl	0x1f(%r15), %ecx
    42e2:      	addq	%rcx, %rax
    42e5:      	leaq	0x10(%rsp), %rdi
    42ea:      	movl	$0x8, %ecx
    42ef:      	movl	$0x70, %r8d
    42f5:      	movzbl	0x1f(%r15), %edx
    42fa:      	addq	0x20(%rsp), %rdx
    42ff:      	movl	$0x8, %esi
    4304:      	callq	*%r8
    4307:      	testq	%rax, %rax
    430a:      	jne	0x4c7 <kprobe_unwind_ruby+0x4c7>
    4310:      	movzbl	0x21(%r15), %eax
    4315:      	addq	0x10(%rsp), %rax
    431a:      	leaq	0x68(%rsp), %rdi
    431f:      	movl	$0x8, %ecx
    4324:      	movl	$0x70, %r8d
    432a:      	movzbl	0x21(%r15), %edx
    432f:      	addq	0x10(%rsp), %rdx
    4334:      	movl	$0x8, %esi
    4339:      	callq	*%r8
    433c:      	testq	%rax, %rax
    433f:      	jne	0x8a4 <kprobe_unwind_ruby+0x8a4>
    4345:      	movzbl	0x22(%r15), %eax
    434a:      	addq	0x10(%rsp), %rax
    434f:      	leaq	0x2c(%rsp), %rdi
    4354:      	movl	$0x4, %ecx
    4359:      	movl	$0x70, %r8d
    435f:      	movzbl	0x22(%r15), %edx
    4364:      	addq	0x10(%rsp), %rdx
    4369:      	movl	$0x4, %esi
    436e:      	callq	*%r8
    4371:      	testq	%rax, %rax
    4374:      	jne	0xc08 <kprobe_unwind_ruby+0xc08>
    437a:      	movzbl	0x23(%r15), %ecx
    437f:      	testq	%rcx, %rcx
    4382:      	je	0x4bd1 <kprobe_unwind_ruby+0x4bd1>
    4388:      	movq	0x18(%rsp), %rax
    438d:      	subq	0x68(%rsp), %rax
    4392:      	xorl	%edx, %edx
    4394:      	divq	%rcx
    4397:      	movl	0x2c(%rsp), %ecx
    439b:      	cmpq	%rcx, %rax
    439e:      	jbe	0x4bd1 <kprobe_unwind_ruby+0x4bd1>
    43a4:      	movq	(%rip), %rax            # 0x43ab <kprobe_unwind_ruby+0x43ab>
    43ab:      	cmpl	$0x0, (%rax)
    43ae:      	je	0x45a6 <kprobe_unwind_ruby+0x45a6>
    43b4:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    43be:      	movq	%rax, 0x55(%rsp)
    43c3:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    43cd:      	movq	%rax, 0x50(%rsp)
    43d2:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    43dc:      	movq	%rax, 0x48(%rsp)
    43e1:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    43eb:      	movq	%rax, 0x40(%rsp)
    43f0:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    43fa:      	movq	%rax, 0x38(%rsp)
    43ff:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    4409:      	movq	%rax, 0x30(%rsp)
    440e:      	leaq	0x30(%rsp), %rdi
    4413:      	movl	$0x2d, %eax
    4418:      	movl	$0x6, %ecx
    441d:      	movl	$0x2d, %esi
    4422:      	xorl	%eax, %eax
    4424:      	callq	*%rcx
    4426:      	jmp	0x45a6 <kprobe_unwind_ruby+0x45a6>
    442b:      	movq	$0x0, (%rsp)
    4433:      	movzbl	0x1d(%r15), %eax
    4438:      	addq	0x8(%rsp), %rax
    443d:      	movq	%rsp, %rdi
    4440:      	movl	$0x8, %ecx
    4445:      	movl	$0x70, %r8d
    444b:      	movzbl	0x1d(%r15), %edx
    4450:      	addq	0x8(%rsp), %rdx
    4455:      	movl	$0x8, %esi
    445a:      	callq	*%r8
    445d:      	testq	%rax, %rax
    4460:      	jne	0x81b <kprobe_unwind_ruby+0x81b>
    4466:      	movl	(%rsp), %eax
    4469:      	notl	%eax
    446b:      	testl	$0x140, %eax            # imm = 0x140
    4470:      	jne	0x997 <kprobe_unwind_ruby+0x997>
    4476:      	jmp	0x4240 <kprobe_unwind_ruby+0x4240>
    447b:      	movq	(%rip), %rax            # 0x4482 <kprobe_unwind_ruby+0x4482>
    4482:      	cmpl	$0x0, (%rax)
    4485:      	je	0x3b74 <kprobe_unwind_ruby+0x3b74>
    448b:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4495:      	movq	%rax, 0x56(%rsp)
    449a:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    44a4:      	movq	%rax, 0x50(%rsp)
    44a9:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    44b3:      	movq	%rax, 0x48(%rsp)
    44b8:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    44c2:      	movq	%rax, 0x40(%rsp)
    44c7:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    44d1:      	movq	%rax, 0x38(%rsp)
    44d6:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    44e0:      	movq	%rax, 0x30(%rsp)
    44e5:      	leaq	0x30(%rsp), %rdi
    44ea:      	movl	$0x2e, %eax
    44ef:      	movl	$0x6, %ecx
    44f4:      	movl	(%rsp), %edx
    44f7:      	movl	$0x2e, %esi
    44fc:      	xorl	%eax, %eax
    44fe:      	callq	*%rcx
    4500:      	jmp	0x3b74 <kprobe_unwind_ruby+0x3b74>
    4505:      	movl	0x2c0(%r14), %eax
    450c:      	cmpq	$0x7e, %rax
    4510:      	ja	0xdd3 <kprobe_unwind_ruby+0xdd3>
    4516:      	movq	0x10(%rsp), %rcx
    451b:      	movq	0x18(%rsp), %rdx
    4520:      	leal	0x1(%rax), %esi
    4523:      	movl	%esi, 0x2c0(%r14)
    452a:      	leaq	(%rax,%rax,2), %rax
    452e:      	movw	$0x0, 0x4(%rsp)
    4535:      	movl	$0x0, (%rsp)
    453c:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    4544:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    454c:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    4557:      	movl	(%rsp), %ecx
    455a:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    4562:      	movzwl	0x4(%rsp), %ecx
    4567:      	movw	%cx, 0x2e6(%r14,%rax,8)
    4570:      	movl	$0x36, (%rsp)
    4577:      	movq	(%rip), %rdi            # 0x457e <kprobe_unwind_ruby+0x457e>
    457e:      	movq	%rsp, %rsi
    4581:      	movl	$0x1, %eax
    4586:      	callq	*%rax
    4588:      	testq	%rax, %rax
    458b:      	je	0x47e1 <kprobe_unwind_ruby+0x47e1>
    4591:      	incq	(%rax)
    4594:      	jmp	0x3eda <kprobe_unwind_ruby+0x3eda>
    4599:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    45a0:      	jae	0x4791 <kprobe_unwind_ruby+0x4791>
    45a6:      	movq	0x8(%rsp), %rax
    45ab:      	cmpq	%rax, %r12
    45ae:      	jbe	0x2b2 <kprobe_unwind_ruby+0x2b2>
    45b4:      	movzbl	0x1e(%r15), %ecx
    45b9:      	addq	%rcx, %rax
    45bc:      	movq	%rax, 0x8(%rsp)
    45c1:      	movq	$0x0, 0x18(%rsp)
    45ca:      	movq	$0x0, 0x20(%rsp)
    45d3:      	movzbl	0x1c(%r15), %ecx
    45d8:      	addq	%rax, %rcx
    45db:      	leaq	0x20(%rsp), %rdi
    45e0:      	movl	$0x8, %eax
    45e5:      	movl	$0x70, %r8d
    45eb:      	movzbl	0x1c(%r15), %edx
    45f0:      	addq	0x8(%rsp), %rdx
    45f5:      	movl	$0x8, %esi
    45fa:      	callq	*%r8
    45fd:      	movzbl	0x1b(%r15), %eax
    4602:      	addq	0x8(%rsp), %rax
    4607:      	leaq	0x18(%rsp), %rdi
    460c:      	movl	$0x8, %ecx
    4611:      	movl	$0x70, %r8d
    4617:      	movzbl	0x1b(%r15), %edx
    461c:      	addq	0x8(%rsp), %rdx
    4621:      	movl	$0x8, %esi
    4626:      	callq	*%r8
    4629:      	cmpq	$0x0, 0x18(%rsp)
    462f:      	je	0x48ff <kprobe_unwind_ruby+0x48ff>
    4635:      	movq	0x20(%rsp), %rax
    463a:      	testq	%rax, %rax
    463d:      	je	0x48ff <kprobe_unwind_ruby+0x48ff>
    4643:      	movzbl	0x1f(%r15), %ecx
    4648:      	addq	%rcx, %rax
    464b:      	leaq	0x10(%rsp), %rdi
    4650:      	movl	$0x8, %ecx
    4655:      	movl	$0x70, %r8d
    465b:      	movzbl	0x1f(%r15), %edx
    4660:      	addq	0x20(%rsp), %rdx
    4665:      	movl	$0x8, %esi
    466a:      	callq	*%r8
    466d:      	testq	%rax, %rax
    4670:      	jne	0x4c7 <kprobe_unwind_ruby+0x4c7>
    4676:      	movzbl	0x21(%r15), %eax
    467b:      	addq	0x10(%rsp), %rax
    4680:      	leaq	0x68(%rsp), %rdi
    4685:      	movl	$0x8, %ecx
    468a:      	movl	$0x70, %r8d
    4690:      	movzbl	0x21(%r15), %edx
    4695:      	addq	0x10(%rsp), %rdx
    469a:      	movl	$0x8, %esi
    469f:      	callq	*%r8
    46a2:      	testq	%rax, %rax
    46a5:      	jne	0x8a4 <kprobe_unwind_ruby+0x8a4>
    46ab:      	movzbl	0x22(%r15), %eax
    46b0:      	addq	0x10(%rsp), %rax
    46b5:      	leaq	0x2c(%rsp), %rdi
    46ba:      	movl	$0x4, %ecx
    46bf:      	movl	$0x70, %r8d
    46c5:      	movzbl	0x22(%r15), %edx
    46ca:      	addq	0x10(%rsp), %rdx
    46cf:      	movl	$0x4, %esi
    46d4:      	callq	*%r8
    46d7:      	testq	%rax, %rax
    46da:      	jne	0xc08 <kprobe_unwind_ruby+0xc08>
    46e0:      	movzbl	0x23(%r15), %ecx
    46e5:      	testq	%rcx, %rcx
    46e8:      	je	0x4d48 <kprobe_unwind_ruby+0x4d48>
    46ee:      	movq	0x18(%rsp), %rax
    46f3:      	subq	0x68(%rsp), %rax
    46f8:      	xorl	%edx, %edx
    46fa:      	divq	%rcx
    46fd:      	movl	0x2c(%rsp), %ecx
    4701:      	cmpq	%rcx, %rax
    4704:      	jbe	0x4d48 <kprobe_unwind_ruby+0x4d48>
    470a:      	movq	(%rip), %rax            # 0x4711 <kprobe_unwind_ruby+0x4711>
    4711:      	cmpl	$0x0, (%rax)
    4714:      	je	0x490c <kprobe_unwind_ruby+0x490c>
    471a:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    4724:      	movq	%rax, 0x55(%rsp)
    4729:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    4733:      	movq	%rax, 0x50(%rsp)
    4738:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    4742:      	movq	%rax, 0x48(%rsp)
    4747:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    4751:      	movq	%rax, 0x40(%rsp)
    4756:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    4760:      	movq	%rax, 0x38(%rsp)
    4765:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    476f:      	movq	%rax, 0x30(%rsp)
    4774:      	leaq	0x30(%rsp), %rdi
    4779:      	movl	$0x2d, %eax
    477e:      	movl	$0x6, %ecx
    4783:      	movl	$0x2d, %esi
    4788:      	xorl	%eax, %eax
    478a:      	callq	*%rcx
    478c:      	jmp	0x490c <kprobe_unwind_ruby+0x490c>
    4791:      	movq	$0x0, (%rsp)
    4799:      	movzbl	0x1d(%r15), %eax
    479e:      	addq	0x8(%rsp), %rax
    47a3:      	movq	%rsp, %rdi
    47a6:      	movl	$0x8, %ecx
    47ab:      	movl	$0x70, %r8d
    47b1:      	movzbl	0x1d(%r15), %edx
    47b6:      	addq	0x8(%rsp), %rdx
    47bb:      	movl	$0x8, %esi
    47c0:      	callq	*%r8
    47c3:      	testq	%rax, %rax
    47c6:      	jne	0x81b <kprobe_unwind_ruby+0x81b>
    47cc:      	movl	(%rsp), %eax
    47cf:      	notl	%eax
    47d1:      	testl	$0x140, %eax            # imm = 0x140
    47d6:      	jne	0x997 <kprobe_unwind_ruby+0x997>
    47dc:      	jmp	0x45a6 <kprobe_unwind_ruby+0x45a6>
    47e1:      	movq	(%rip), %rax            # 0x47e8 <kprobe_unwind_ruby+0x47e8>
    47e8:      	cmpl	$0x0, (%rax)
    47eb:      	je	0x3eda <kprobe_unwind_ruby+0x3eda>
    47f1:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    47fb:      	movq	%rax, 0x56(%rsp)
    4800:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    480a:      	movq	%rax, 0x50(%rsp)
    480f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4819:      	movq	%rax, 0x48(%rsp)
    481e:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4828:      	movq	%rax, 0x40(%rsp)
    482d:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4837:      	movq	%rax, 0x38(%rsp)
    483c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4846:      	movq	%rax, 0x30(%rsp)
    484b:      	leaq	0x30(%rsp), %rdi
    4850:      	movl	$0x2e, %eax
    4855:      	movl	$0x6, %ecx
    485a:      	movl	(%rsp), %edx
    485d:      	movl	$0x2e, %esi
    4862:      	xorl	%eax, %eax
    4864:      	callq	*%rcx
    4866:      	jmp	0x3eda <kprobe_unwind_ruby+0x3eda>
    486b:      	movl	0x2c0(%r14), %eax
    4872:      	cmpq	$0x7e, %rax
    4876:      	ja	0xdd3 <kprobe_unwind_ruby+0xdd3>
    487c:      	movq	0x10(%rsp), %rcx
    4881:      	movq	0x18(%rsp), %rdx
    4886:      	leal	0x1(%rax), %esi
    4889:      	movl	%esi, 0x2c0(%r14)
    4890:      	leaq	(%rax,%rax,2), %rax
    4894:      	movw	$0x0, 0x4(%rsp)
    489b:      	movl	$0x0, (%rsp)
    48a2:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    48aa:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    48b2:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    48bd:      	movl	(%rsp), %ecx
    48c0:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    48c8:      	movzwl	0x4(%rsp), %ecx
    48cd:      	movw	%cx, 0x2e6(%r14,%rax,8)
    48d6:      	movl	$0x36, (%rsp)
    48dd:      	movq	(%rip), %rdi            # 0x48e4 <kprobe_unwind_ruby+0x48e4>
    48e4:      	movq	%rsp, %rsi
    48e7:      	movl	$0x1, %eax
    48ec:      	callq	*%rax
    48ee:      	testq	%rax, %rax
    48f1:      	je	0x4b47 <kprobe_unwind_ruby+0x4b47>
    48f7:      	incq	(%rax)
    48fa:      	jmp	0x4240 <kprobe_unwind_ruby+0x4240>
    48ff:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    4906:      	jae	0x4af7 <kprobe_unwind_ruby+0x4af7>
    490c:      	movq	0x8(%rsp), %rax
    4911:      	cmpq	%rax, %r12
    4914:      	jbe	0x2b2 <kprobe_unwind_ruby+0x2b2>
    491a:      	movzbl	0x1e(%r15), %ecx
    491f:      	addq	%rcx, %rax
    4922:      	movq	%rax, 0x8(%rsp)
    4927:      	movq	$0x0, 0x18(%rsp)
    4930:      	movq	$0x0, 0x20(%rsp)
    4939:      	movzbl	0x1c(%r15), %ecx
    493e:      	addq	%rax, %rcx
    4941:      	leaq	0x20(%rsp), %rdi
    4946:      	movl	$0x8, %eax
    494b:      	movl	$0x70, %r8d
    4951:      	movzbl	0x1c(%r15), %edx
    4956:      	addq	0x8(%rsp), %rdx
    495b:      	movl	$0x8, %esi
    4960:      	callq	*%r8
    4963:      	movzbl	0x1b(%r15), %eax
    4968:      	addq	0x8(%rsp), %rax
    496d:      	leaq	0x18(%rsp), %rdi
    4972:      	movl	$0x8, %ecx
    4977:      	movl	$0x70, %r8d
    497d:      	movzbl	0x1b(%r15), %edx
    4982:      	addq	0x8(%rsp), %rdx
    4987:      	movl	$0x8, %esi
    498c:      	callq	*%r8
    498f:      	cmpq	$0x0, 0x18(%rsp)
    4995:      	je	0x4c61 <kprobe_unwind_ruby+0x4c61>
    499b:      	movq	0x20(%rsp), %rax
    49a0:      	testq	%rax, %rax
    49a3:      	je	0x4c61 <kprobe_unwind_ruby+0x4c61>
    49a9:      	movzbl	0x1f(%r15), %ecx
    49ae:      	addq	%rcx, %rax
    49b1:      	leaq	0x10(%rsp), %rdi
    49b6:      	movl	$0x8, %ecx
    49bb:      	movl	$0x70, %r8d
    49c1:      	movzbl	0x1f(%r15), %edx
    49c6:      	addq	0x20(%rsp), %rdx
    49cb:      	movl	$0x8, %esi
    49d0:      	callq	*%r8
    49d3:      	testq	%rax, %rax
    49d6:      	jne	0x4c7 <kprobe_unwind_ruby+0x4c7>
    49dc:      	movzbl	0x21(%r15), %eax
    49e1:      	addq	0x10(%rsp), %rax
    49e6:      	leaq	0x68(%rsp), %rdi
    49eb:      	movl	$0x8, %ecx
    49f0:      	movl	$0x70, %r8d
    49f6:      	movzbl	0x21(%r15), %edx
    49fb:      	addq	0x10(%rsp), %rdx
    4a00:      	movl	$0x8, %esi
    4a05:      	callq	*%r8
    4a08:      	testq	%rax, %rax
    4a0b:      	jne	0x8a4 <kprobe_unwind_ruby+0x8a4>
    4a11:      	movzbl	0x22(%r15), %eax
    4a16:      	addq	0x10(%rsp), %rax
    4a1b:      	leaq	0x2c(%rsp), %rdi
    4a20:      	movl	$0x4, %ecx
    4a25:      	movl	$0x70, %r8d
    4a2b:      	movzbl	0x22(%r15), %edx
    4a30:      	addq	0x10(%rsp), %rdx
    4a35:      	movl	$0x4, %esi
    4a3a:      	callq	*%r8
    4a3d:      	testq	%rax, %rax
    4a40:      	jne	0xc08 <kprobe_unwind_ruby+0xc08>
    4a46:      	movzbl	0x23(%r15), %ecx
    4a4b:      	testq	%rcx, %rcx
    4a4e:      	je	0x4ddc <kprobe_unwind_ruby+0x4ddc>
    4a54:      	movq	0x18(%rsp), %rax
    4a59:      	subq	0x68(%rsp), %rax
    4a5e:      	xorl	%edx, %edx
    4a60:      	divq	%rcx
    4a63:      	movl	0x2c(%rsp), %ecx
    4a67:      	cmpq	%rcx, %rax
    4a6a:      	jbe	0x4ddc <kprobe_unwind_ruby+0x4ddc>
    4a70:      	movq	(%rip), %rax            # 0x4a77 <kprobe_unwind_ruby+0x4a77>
    4a77:      	cmpl	$0x0, (%rax)
    4a7a:      	je	0x4f7b <kprobe_unwind_ruby+0x4f7b>
    4a80:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    4a8a:      	movq	%rax, 0x55(%rsp)
    4a8f:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    4a99:      	movq	%rax, 0x50(%rsp)
    4a9e:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    4aa8:      	movq	%rax, 0x48(%rsp)
    4aad:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    4ab7:      	movq	%rax, 0x40(%rsp)
    4abc:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    4ac6:      	movq	%rax, 0x38(%rsp)
    4acb:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    4ad5:      	movq	%rax, 0x30(%rsp)
    4ada:      	leaq	0x30(%rsp), %rdi
    4adf:      	movl	$0x2d, %eax
    4ae4:      	movl	$0x6, %ecx
    4ae9:      	movl	$0x2d, %esi
    4aee:      	xorl	%eax, %eax
    4af0:      	callq	*%rcx
    4af2:      	jmp	0x4f7b <kprobe_unwind_ruby+0x4f7b>
    4af7:      	movq	$0x0, (%rsp)
    4aff:      	movzbl	0x1d(%r15), %eax
    4b04:      	addq	0x8(%rsp), %rax
    4b09:      	movq	%rsp, %rdi
    4b0c:      	movl	$0x8, %ecx
    4b11:      	movl	$0x70, %r8d
    4b17:      	movzbl	0x1d(%r15), %edx
    4b1c:      	addq	0x8(%rsp), %rdx
    4b21:      	movl	$0x8, %esi
    4b26:      	callq	*%r8
    4b29:      	testq	%rax, %rax
    4b2c:      	jne	0x81b <kprobe_unwind_ruby+0x81b>
    4b32:      	movl	(%rsp), %eax
    4b35:      	notl	%eax
    4b37:      	testl	$0x140, %eax            # imm = 0x140
    4b3c:      	jne	0x997 <kprobe_unwind_ruby+0x997>
    4b42:      	jmp	0x490c <kprobe_unwind_ruby+0x490c>
    4b47:      	movq	(%rip), %rax            # 0x4b4e <kprobe_unwind_ruby+0x4b4e>
    4b4e:      	cmpl	$0x0, (%rax)
    4b51:      	je	0x4240 <kprobe_unwind_ruby+0x4240>
    4b57:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4b61:      	movq	%rax, 0x56(%rsp)
    4b66:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4b70:      	movq	%rax, 0x50(%rsp)
    4b75:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4b7f:      	movq	%rax, 0x48(%rsp)
    4b84:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4b8e:      	movq	%rax, 0x40(%rsp)
    4b93:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4b9d:      	movq	%rax, 0x38(%rsp)
    4ba2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4bac:      	movq	%rax, 0x30(%rsp)
    4bb1:      	leaq	0x30(%rsp), %rdi
    4bb6:      	movl	$0x2e, %eax
    4bbb:      	movl	$0x6, %ecx
    4bc0:      	movl	(%rsp), %edx
    4bc3:      	movl	$0x2e, %esi
    4bc8:      	xorl	%eax, %eax
    4bca:      	callq	*%rcx
    4bcc:      	jmp	0x4240 <kprobe_unwind_ruby+0x4240>
    4bd1:      	movl	0x2c0(%r14), %eax
    4bd8:      	cmpq	$0x7e, %rax
    4bdc:      	ja	0xdd3 <kprobe_unwind_ruby+0xdd3>
    4be2:      	movq	0x10(%rsp), %rcx
    4be7:      	movq	0x18(%rsp), %rdx
    4bec:      	leal	0x1(%rax), %esi
    4bef:      	movl	%esi, 0x2c0(%r14)
    4bf6:      	leaq	(%rax,%rax,2), %rax
    4bfa:      	movw	$0x0, 0x4(%rsp)
    4c01:      	movl	$0x0, (%rsp)
    4c08:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    4c10:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    4c18:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    4c23:      	movl	(%rsp), %ecx
    4c26:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    4c2e:      	movzwl	0x4(%rsp), %ecx
    4c33:      	movw	%cx, 0x2e6(%r14,%rax,8)
    4c3c:      	movl	$0x36, (%rsp)
    4c43:      	movq	(%rip), %rdi            # 0x4c4a <kprobe_unwind_ruby+0x4c4a>
    4c4a:      	movq	%rsp, %rsi
    4c4d:      	movl	$0x1, %eax
    4c52:      	callq	*%rax
    4c54:      	testq	%rax, %rax
    4c57:      	je	0x4cbe <kprobe_unwind_ruby+0x4cbe>
    4c59:      	incq	(%rax)
    4c5c:      	jmp	0x45a6 <kprobe_unwind_ruby+0x45a6>
    4c61:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    4c68:      	jb	0x4f7b <kprobe_unwind_ruby+0x4f7b>
    4c6e:      	movq	$0x0, (%rsp)
    4c76:      	movzbl	0x1d(%r15), %eax
    4c7b:      	addq	0x8(%rsp), %rax
    4c80:      	movq	%rsp, %rdi
    4c83:      	movl	$0x8, %ecx
    4c88:      	movl	$0x70, %r8d
    4c8e:      	movzbl	0x1d(%r15), %edx
    4c93:      	addq	0x8(%rsp), %rdx
    4c98:      	movl	$0x8, %esi
    4c9d:      	callq	*%r8
    4ca0:      	testq	%rax, %rax
    4ca3:      	jne	0x81b <kprobe_unwind_ruby+0x81b>
    4ca9:      	movl	(%rsp), %eax
    4cac:      	notl	%eax
    4cae:      	testl	$0x140, %eax            # imm = 0x140
    4cb3:      	jne	0x997 <kprobe_unwind_ruby+0x997>
    4cb9:      	jmp	0x4f7b <kprobe_unwind_ruby+0x4f7b>
    4cbe:      	movq	(%rip), %rax            # 0x4cc5 <kprobe_unwind_ruby+0x4cc5>
    4cc5:      	cmpl	$0x0, (%rax)
    4cc8:      	je	0x45a6 <kprobe_unwind_ruby+0x45a6>
    4cce:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4cd8:      	movq	%rax, 0x56(%rsp)
    4cdd:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4ce7:      	movq	%rax, 0x50(%rsp)
    4cec:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4cf6:      	movq	%rax, 0x48(%rsp)
    4cfb:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4d05:      	movq	%rax, 0x40(%rsp)
    4d0a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4d14:      	movq	%rax, 0x38(%rsp)
    4d19:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4d23:      	movq	%rax, 0x30(%rsp)
    4d28:      	leaq	0x30(%rsp), %rdi
    4d2d:      	movl	$0x2e, %eax
    4d32:      	movl	$0x6, %ecx
    4d37:      	movl	(%rsp), %edx
    4d3a:      	movl	$0x2e, %esi
    4d3f:      	xorl	%eax, %eax
    4d41:      	callq	*%rcx
    4d43:      	jmp	0x45a6 <kprobe_unwind_ruby+0x45a6>
    4d48:      	movl	0x2c0(%r14), %eax
    4d4f:      	cmpq	$0x7e, %rax
    4d53:      	ja	0xdd3 <kprobe_unwind_ruby+0xdd3>
    4d59:      	movq	0x10(%rsp), %rcx
    4d5e:      	movq	0x18(%rsp), %rdx
    4d63:      	leal	0x1(%rax), %esi
    4d66:      	movl	%esi, 0x2c0(%r14)
    4d6d:      	leaq	(%rax,%rax,2), %rax
    4d71:      	movw	$0x0, 0x4(%rsp)
    4d78:      	movl	$0x0, (%rsp)
    4d7f:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    4d87:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    4d8f:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    4d9a:      	movl	(%rsp), %ecx
    4d9d:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    4da5:      	movzwl	0x4(%rsp), %ecx
    4daa:      	movw	%cx, 0x2e6(%r14,%rax,8)
    4db3:      	movl	$0x36, (%rsp)
    4dba:      	movq	(%rip), %rdi            # 0x4dc1 <kprobe_unwind_ruby+0x4dc1>
    4dc1:      	movq	%rsp, %rsi
    4dc4:      	movl	$0x1, %eax
    4dc9:      	callq	*%rax
    4dcb:      	testq	%rax, %rax
    4dce:      	je	0x4e70 <kprobe_unwind_ruby+0x4e70>
    4dd4:      	incq	(%rax)
    4dd7:      	jmp	0x490c <kprobe_unwind_ruby+0x490c>
    4ddc:      	movl	0x2c0(%r14), %eax
    4de3:      	cmpq	$0x7e, %rax
    4de7:      	ja	0xdd3 <kprobe_unwind_ruby+0xdd3>
    4ded:      	movq	0x10(%rsp), %rcx
    4df2:      	movq	0x18(%rsp), %rdx
    4df7:      	leal	0x1(%rax), %esi
    4dfa:      	movl	%esi, 0x2c0(%r14)
    4e01:      	leaq	(%rax,%rax,2), %rax
    4e05:      	movw	$0x0, 0x4(%rsp)
    4e0c:      	movl	$0x0, (%rsp)
    4e13:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    4e1b:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    4e23:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    4e2e:      	movl	(%rsp), %ecx
    4e31:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    4e39:      	movzwl	0x4(%rsp), %ecx
    4e3e:      	movw	%cx, 0x2e6(%r14,%rax,8)
    4e47:      	movl	$0x36, (%rsp)
    4e4e:      	movq	(%rip), %rdi            # 0x4e55 <kprobe_unwind_ruby+0x4e55>
    4e55:      	movq	%rsp, %rsi
    4e58:      	movl	$0x1, %eax
    4e5d:      	callq	*%rax
    4e5f:      	testq	%rax, %rax
    4e62:      	je	0x4efa <kprobe_unwind_ruby+0x4efa>
    4e68:      	incq	(%rax)
    4e6b:      	jmp	0x4f7b <kprobe_unwind_ruby+0x4f7b>
    4e70:      	movq	(%rip), %rax            # 0x4e77 <kprobe_unwind_ruby+0x4e77>
    4e77:      	cmpl	$0x0, (%rax)
    4e7a:      	je	0x490c <kprobe_unwind_ruby+0x490c>
    4e80:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4e8a:      	movq	%rax, 0x56(%rsp)
    4e8f:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4e99:      	movq	%rax, 0x50(%rsp)
    4e9e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4ea8:      	movq	%rax, 0x48(%rsp)
    4ead:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4eb7:      	movq	%rax, 0x40(%rsp)
    4ebc:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4ec6:      	movq	%rax, 0x38(%rsp)
    4ecb:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4ed5:      	movq	%rax, 0x30(%rsp)
    4eda:      	leaq	0x30(%rsp), %rdi
    4edf:      	movl	$0x2e, %eax
    4ee4:      	movl	$0x6, %ecx
    4ee9:      	movl	(%rsp), %edx
    4eec:      	movl	$0x2e, %esi
    4ef1:      	xorl	%eax, %eax
    4ef3:      	callq	*%rcx
    4ef5:      	jmp	0x490c <kprobe_unwind_ruby+0x490c>
    4efa:      	movq	(%rip), %rax            # 0x4f01 <kprobe_unwind_ruby+0x4f01>
    4f01:      	cmpl	$0x0, (%rax)
    4f04:      	je	0x4f7b <kprobe_unwind_ruby+0x4f7b>
    4f06:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4f10:      	movq	%rax, 0x56(%rsp)
    4f15:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4f1f:      	movq	%rax, 0x50(%rsp)
    4f24:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4f2e:      	movq	%rax, 0x48(%rsp)
    4f33:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4f3d:      	movq	%rax, 0x40(%rsp)
    4f42:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4f4c:      	movq	%rax, 0x38(%rsp)
    4f51:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4f5b:      	movq	%rax, 0x30(%rsp)
    4f60:      	leaq	0x30(%rsp), %rdi
    4f65:      	movl	$0x2e, %eax
    4f6a:      	movl	$0x6, %ecx
    4f6f:      	movl	(%rsp), %edx
    4f72:      	movl	$0x2e, %esi
    4f77:      	xorl	%eax, %eax
    4f79:      	callq	*%rcx
    4f7b:      	movq	0x8(%rsp), %rax
    4f80:      	cmpq	%rax, %r12
    4f83:      	jbe	0x2b2 <kprobe_unwind_ruby+0x2b2>
    4f89:      	movzbl	0x1e(%r15), %ecx
    4f8e:      	addq	%rcx, %rax
    4f91:      	movq	%rax, 0x8(%rsp)
    4f96:      	movq	$0x0, 0x18(%rsp)
    4f9f:      	movq	$0x0, 0x20(%rsp)
    4fa8:      	movzbl	0x1c(%r15), %ecx
    4fad:      	addq	%rax, %rcx
    4fb0:      	leaq	0x20(%rsp), %rdi
    4fb5:      	movl	$0x8, %eax
    4fba:      	movl	$0x70, %r8d
    4fc0:      	movzbl	0x1c(%r15), %edx
    4fc5:      	addq	0x8(%rsp), %rdx
    4fca:      	movl	$0x8, %esi
    4fcf:      	callq	*%r8
    4fd2:      	movzbl	0x1b(%r15), %eax
    4fd7:      	addq	0x8(%rsp), %rax
    4fdc:      	leaq	0x18(%rsp), %rdi
    4fe1:      	movl	$0x8, %ecx
    4fe6:      	movl	$0x70, %r8d
    4fec:      	movzbl	0x1b(%r15), %edx
    4ff1:      	addq	0x8(%rsp), %rdx
    4ff6:      	movl	$0x8, %esi
    4ffb:      	callq	*%r8
    4ffe:      	cmpq	$0x0, 0x18(%rsp)
    5004:      	je	0x5166 <kprobe_unwind_ruby+0x5166>
    500a:      	movq	0x20(%rsp), %rax
    500f:      	testq	%rax, %rax
    5012:      	je	0x5166 <kprobe_unwind_ruby+0x5166>
    5018:      	movzbl	0x1f(%r15), %ecx
    501d:      	addq	%rcx, %rax
    5020:      	leaq	0x10(%rsp), %rdi
    5025:      	movl	$0x8, %ecx
    502a:      	movl	$0x70, %r8d
    5030:      	movzbl	0x1f(%r15), %edx
    5035:      	addq	0x20(%rsp), %rdx
    503a:      	movl	$0x8, %esi
    503f:      	callq	*%r8
    5042:      	testq	%rax, %rax
    5045:      	jne	0x4c7 <kprobe_unwind_ruby+0x4c7>
    504b:      	movzbl	0x21(%r15), %eax
    5050:      	addq	0x10(%rsp), %rax
    5055:      	leaq	0x68(%rsp), %rdi
    505a:      	movl	$0x8, %ecx
    505f:      	movl	$0x70, %r8d
    5065:      	movzbl	0x21(%r15), %edx
    506a:      	addq	0x10(%rsp), %rdx
    506f:      	movl	$0x8, %esi
    5074:      	callq	*%r8
    5077:      	testq	%rax, %rax
    507a:      	jne	0x8a4 <kprobe_unwind_ruby+0x8a4>
    5080:      	movzbl	0x22(%r15), %eax
    5085:      	addq	0x10(%rsp), %rax
    508a:      	leaq	0x2c(%rsp), %rdi
    508f:      	movl	$0x4, %ecx
    5094:      	movl	$0x70, %r8d
    509a:      	movzbl	0x22(%r15), %edx
    509f:      	addq	0x10(%rsp), %rdx
    50a4:      	movl	$0x4, %esi
    50a9:      	callq	*%r8
    50ac:      	testq	%rax, %rax
    50af:      	jne	0xc08 <kprobe_unwind_ruby+0xc08>
    50b5:      	movzbl	0x23(%r15), %ecx
    50ba:      	testq	%rcx, %rcx
    50bd:      	je	0x51c3 <kprobe_unwind_ruby+0x51c3>
    50c3:      	movq	0x18(%rsp), %rax
    50c8:      	subq	0x68(%rsp), %rax
    50cd:      	xorl	%edx, %edx
    50cf:      	divq	%rcx
    50d2:      	movl	0x2c(%rsp), %ecx
    50d6:      	cmpq	%rcx, %rax
    50d9:      	jbe	0x51c3 <kprobe_unwind_ruby+0x51c3>
    50df:      	movq	(%rip), %rax            # 0x50e6 <kprobe_unwind_ruby+0x50e6>
    50e6:      	cmpl	$0x0, (%rax)
    50e9:      	je	0x52d4 <kprobe_unwind_ruby+0x52d4>
    50ef:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    50f9:      	movq	%rax, 0x55(%rsp)
    50fe:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    5108:      	movq	%rax, 0x50(%rsp)
    510d:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    5117:      	movq	%rax, 0x48(%rsp)
    511c:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    5126:      	movq	%rax, 0x40(%rsp)
    512b:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    5135:      	movq	%rax, 0x38(%rsp)
    513a:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    5144:      	movq	%rax, 0x30(%rsp)
    5149:      	leaq	0x30(%rsp), %rdi
    514e:      	movl	$0x2d, %eax
    5153:      	movl	$0x6, %ecx
    5158:      	movl	$0x2d, %esi
    515d:      	xorl	%eax, %eax
    515f:      	callq	*%rcx
    5161:      	jmp	0x52d4 <kprobe_unwind_ruby+0x52d4>
    5166:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    516d:      	jb	0x52d4 <kprobe_unwind_ruby+0x52d4>
    5173:      	movq	$0x0, (%rsp)
    517b:      	movzbl	0x1d(%r15), %eax
    5180:      	addq	0x8(%rsp), %rax
    5185:      	movq	%rsp, %rdi
    5188:      	movl	$0x8, %ecx
    518d:      	movl	$0x70, %r8d
    5193:      	movzbl	0x1d(%r15), %edx
    5198:      	addq	0x8(%rsp), %rdx
    519d:      	movl	$0x8, %esi
    51a2:      	callq	*%r8
    51a5:      	testq	%rax, %rax
    51a8:      	jne	0x81b <kprobe_unwind_ruby+0x81b>
    51ae:      	movl	(%rsp), %eax
    51b1:      	notl	%eax
    51b3:      	testl	$0x140, %eax            # imm = 0x140
    51b8:      	jne	0x997 <kprobe_unwind_ruby+0x997>
    51be:      	jmp	0x52d4 <kprobe_unwind_ruby+0x52d4>
    51c3:      	movl	0x2c0(%r14), %eax
    51ca:      	cmpq	$0x7e, %rax
    51ce:      	ja	0xdd3 <kprobe_unwind_ruby+0xdd3>
    51d4:      	movq	0x10(%rsp), %rcx
    51d9:      	movq	0x18(%rsp), %rdx
    51de:      	leal	0x1(%rax), %esi
    51e1:      	movl	%esi, 0x2c0(%r14)
    51e8:      	leaq	(%rax,%rax,2), %rax
    51ec:      	movw	$0x0, 0x4(%rsp)
    51f3:      	movl	$0x0, (%rsp)
    51fa:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    5202:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    520a:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    5215:      	movl	(%rsp), %ecx
    5218:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    5220:      	movzwl	0x4(%rsp), %ecx
    5225:      	movw	%cx, 0x2e6(%r14,%rax,8)
    522e:      	movl	$0x36, (%rsp)
    5235:      	movq	(%rip), %rdi            # 0x523c <kprobe_unwind_ruby+0x523c>
    523c:      	movq	%rsp, %rsi
    523f:      	movl	$0x1, %eax
    5244:      	callq	*%rax
    5246:      	testq	%rax, %rax
    5249:      	je	0x5253 <kprobe_unwind_ruby+0x5253>
    524b:      	incq	(%rax)
    524e:      	jmp	0x52d4 <kprobe_unwind_ruby+0x52d4>
    5253:      	movq	(%rip), %rax            # 0x525a <kprobe_unwind_ruby+0x525a>
    525a:      	cmpl	$0x0, (%rax)
    525d:      	je	0x52d4 <kprobe_unwind_ruby+0x52d4>
    525f:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5269:      	movq	%rax, 0x56(%rsp)
    526e:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5278:      	movq	%rax, 0x50(%rsp)
    527d:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5287:      	movq	%rax, 0x48(%rsp)
    528c:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5296:      	movq	%rax, 0x40(%rsp)
    529b:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    52a5:      	movq	%rax, 0x38(%rsp)
    52aa:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    52b4:      	movq	%rax, 0x30(%rsp)
    52b9:      	leaq	0x30(%rsp), %rdi
    52be:      	movl	$0x2e, %eax
    52c3:      	movl	$0x6, %ecx
    52c8:      	movl	(%rsp), %edx
    52cb:      	movl	$0x2e, %esi
    52d0:      	xorl	%eax, %eax
    52d2:      	callq	*%rcx
    52d4:      	movq	0x8(%rsp), %rax
    52d9:      	cmpq	%rax, %r12
    52dc:      	jbe	0x2b2 <kprobe_unwind_ruby+0x2b2>
    52e2:      	movzbl	0x1e(%r15), %ecx
    52e7:      	addq	%rcx, %rax
    52ea:      	movq	%rax, 0x8(%rsp)
    52ef:      	movq	$0x0, 0x18(%rsp)
    52f8:      	movq	$0x0, 0x20(%rsp)
    5301:      	movzbl	0x1c(%r15), %ecx
    5306:      	addq	%rax, %rcx
    5309:      	leaq	0x20(%rsp), %rdi
    530e:      	movl	$0x8, %eax
    5313:      	movl	$0x70, %r8d
    5319:      	movzbl	0x1c(%r15), %edx
    531e:      	addq	0x8(%rsp), %rdx
    5323:      	movl	$0x8, %esi
    5328:      	callq	*%r8
    532b:      	movzbl	0x1b(%r15), %eax
    5330:      	addq	0x8(%rsp), %rax
    5335:      	leaq	0x18(%rsp), %rdi
    533a:      	movl	$0x8, %ecx
    533f:      	movl	$0x70, %r8d
    5345:      	movzbl	0x1b(%r15), %edx
    534a:      	addq	0x8(%rsp), %rdx
    534f:      	movl	$0x8, %esi
    5354:      	callq	*%r8
    5357:      	cmpq	$0x0, 0x18(%rsp)
    535d:      	je	0x54bf <kprobe_unwind_ruby+0x54bf>
    5363:      	movq	0x20(%rsp), %rax
    5368:      	testq	%rax, %rax
    536b:      	je	0x54bf <kprobe_unwind_ruby+0x54bf>
    5371:      	movzbl	0x1f(%r15), %ecx
    5376:      	addq	%rcx, %rax
    5379:      	leaq	0x10(%rsp), %rdi
    537e:      	movl	$0x8, %ecx
    5383:      	movl	$0x70, %r8d
    5389:      	movzbl	0x1f(%r15), %edx
    538e:      	addq	0x20(%rsp), %rdx
    5393:      	movl	$0x8, %esi
    5398:      	callq	*%r8
    539b:      	testq	%rax, %rax
    539e:      	jne	0x4c7 <kprobe_unwind_ruby+0x4c7>
    53a4:      	movzbl	0x21(%r15), %eax
    53a9:      	addq	0x10(%rsp), %rax
    53ae:      	leaq	0x68(%rsp), %rdi
    53b3:      	movl	$0x8, %ecx
    53b8:      	movl	$0x70, %r8d
    53be:      	movzbl	0x21(%r15), %edx
    53c3:      	addq	0x10(%rsp), %rdx
    53c8:      	movl	$0x8, %esi
    53cd:      	callq	*%r8
    53d0:      	testq	%rax, %rax
    53d3:      	jne	0x8a4 <kprobe_unwind_ruby+0x8a4>
    53d9:      	movzbl	0x22(%r15), %eax
    53de:      	addq	0x10(%rsp), %rax
    53e3:      	leaq	0x2c(%rsp), %rdi
    53e8:      	movl	$0x4, %ecx
    53ed:      	movl	$0x70, %r8d
    53f3:      	movzbl	0x22(%r15), %edx
    53f8:      	addq	0x10(%rsp), %rdx
    53fd:      	movl	$0x4, %esi
    5402:      	callq	*%r8
    5405:      	testq	%rax, %rax
    5408:      	jne	0xc08 <kprobe_unwind_ruby+0xc08>
    540e:      	movzbl	0x23(%r15), %ecx
    5413:      	testq	%rcx, %rcx
    5416:      	je	0x551c <kprobe_unwind_ruby+0x551c>
    541c:      	movq	0x18(%rsp), %rax
    5421:      	subq	0x68(%rsp), %rax
    5426:      	xorl	%edx, %edx
    5428:      	divq	%rcx
    542b:      	movl	0x2c(%rsp), %ecx
    542f:      	cmpq	%rcx, %rax
    5432:      	jbe	0x551c <kprobe_unwind_ruby+0x551c>
    5438:      	movq	(%rip), %rax            # 0x543f <kprobe_unwind_ruby+0x543f>
    543f:      	cmpl	$0x0, (%rax)
    5442:      	je	0x562d <kprobe_unwind_ruby+0x562d>
    5448:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    5452:      	movq	%rax, 0x55(%rsp)
    5457:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    5461:      	movq	%rax, 0x50(%rsp)
    5466:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    5470:      	movq	%rax, 0x48(%rsp)
    5475:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    547f:      	movq	%rax, 0x40(%rsp)
    5484:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    548e:      	movq	%rax, 0x38(%rsp)
    5493:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    549d:      	movq	%rax, 0x30(%rsp)
    54a2:      	leaq	0x30(%rsp), %rdi
    54a7:      	movl	$0x2d, %eax
    54ac:      	movl	$0x6, %ecx
    54b1:      	movl	$0x2d, %esi
    54b6:      	xorl	%eax, %eax
    54b8:      	callq	*%rcx
    54ba:      	jmp	0x562d <kprobe_unwind_ruby+0x562d>
    54bf:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    54c6:      	jb	0x562d <kprobe_unwind_ruby+0x562d>
    54cc:      	movq	$0x0, (%rsp)
    54d4:      	movzbl	0x1d(%r15), %eax
    54d9:      	addq	0x8(%rsp), %rax
    54de:      	movq	%rsp, %rdi
    54e1:      	movl	$0x8, %ecx
    54e6:      	movl	$0x70, %r8d
    54ec:      	movzbl	0x1d(%r15), %edx
    54f1:      	addq	0x8(%rsp), %rdx
    54f6:      	movl	$0x8, %esi
    54fb:      	callq	*%r8
    54fe:      	testq	%rax, %rax
    5501:      	jne	0x81b <kprobe_unwind_ruby+0x81b>
    5507:      	movl	(%rsp), %eax
    550a:      	notl	%eax
    550c:      	testl	$0x140, %eax            # imm = 0x140
    5511:      	jne	0x997 <kprobe_unwind_ruby+0x997>
    5517:      	jmp	0x562d <kprobe_unwind_ruby+0x562d>
    551c:      	movl	0x2c0(%r14), %eax
    5523:      	cmpq	$0x7e, %rax
    5527:      	ja	0xdd3 <kprobe_unwind_ruby+0xdd3>
    552d:      	movq	0x10(%rsp), %rcx
    5532:      	movq	0x18(%rsp), %rdx
    5537:      	leal	0x1(%rax), %esi
    553a:      	movl	%esi, 0x2c0(%r14)
    5541:      	leaq	(%rax,%rax,2), %rax
    5545:      	movw	$0x0, 0x4(%rsp)
    554c:      	movl	$0x0, (%rsp)
    5553:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    555b:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    5563:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    556e:      	movl	(%rsp), %ecx
    5571:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    5579:      	movzwl	0x4(%rsp), %ecx
    557e:      	movw	%cx, 0x2e6(%r14,%rax,8)
    5587:      	movl	$0x36, (%rsp)
    558e:      	movq	(%rip), %rdi            # 0x5595 <kprobe_unwind_ruby+0x5595>
    5595:      	movq	%rsp, %rsi
    5598:      	movl	$0x1, %eax
    559d:      	callq	*%rax
    559f:      	testq	%rax, %rax
    55a2:      	je	0x55ac <kprobe_unwind_ruby+0x55ac>
    55a4:      	incq	(%rax)
    55a7:      	jmp	0x562d <kprobe_unwind_ruby+0x562d>
    55ac:      	movq	(%rip), %rax            # 0x55b3 <kprobe_unwind_ruby+0x55b3>
    55b3:      	cmpl	$0x0, (%rax)
    55b6:      	je	0x562d <kprobe_unwind_ruby+0x562d>
    55b8:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    55c2:      	movq	%rax, 0x56(%rsp)
    55c7:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    55d1:      	movq	%rax, 0x50(%rsp)
    55d6:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    55e0:      	movq	%rax, 0x48(%rsp)
    55e5:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    55ef:      	movq	%rax, 0x40(%rsp)
    55f4:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    55fe:      	movq	%rax, 0x38(%rsp)
    5603:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    560d:      	movq	%rax, 0x30(%rsp)
    5612:      	leaq	0x30(%rsp), %rdi
    5617:      	movl	$0x2e, %eax
    561c:      	movl	$0x6, %ecx
    5621:      	movl	(%rsp), %edx
    5624:      	movl	$0x2e, %esi
    5629:      	xorl	%eax, %eax
    562b:      	callq	*%rcx
    562d:      	movq	0x8(%rsp), %rax
    5632:      	cmpq	%rax, %r12
    5635:      	jbe	0x2b2 <kprobe_unwind_ruby+0x2b2>
    563b:      	movzbl	0x1e(%r15), %ecx
    5640:      	addq	%rcx, %rax
    5643:      	movq	%rax, 0x8(%rsp)
    5648:      	movq	$0x0, 0x18(%rsp)
    5651:      	movq	$0x0, 0x20(%rsp)
    565a:      	movzbl	0x1c(%r15), %ecx
    565f:      	addq	%rax, %rcx
    5662:      	leaq	0x20(%rsp), %rdi
    5667:      	movl	$0x8, %eax
    566c:      	movl	$0x70, %r8d
    5672:      	movzbl	0x1c(%r15), %edx
    5677:      	addq	0x8(%rsp), %rdx
    567c:      	movl	$0x8, %esi
    5681:      	callq	*%r8
    5684:      	movzbl	0x1b(%r15), %eax
    5689:      	addq	0x8(%rsp), %rax
    568e:      	leaq	0x18(%rsp), %rdi
    5693:      	movl	$0x8, %ecx
    5698:      	movl	$0x70, %r8d
    569e:      	movzbl	0x1b(%r15), %edx
    56a3:      	addq	0x8(%rsp), %rdx
    56a8:      	movl	$0x8, %esi
    56ad:      	callq	*%r8
    56b0:      	cmpq	$0x0, 0x18(%rsp)
    56b6:      	je	0x5818 <kprobe_unwind_ruby+0x5818>
    56bc:      	movq	0x20(%rsp), %rax
    56c1:      	testq	%rax, %rax
    56c4:      	je	0x5818 <kprobe_unwind_ruby+0x5818>
    56ca:      	movzbl	0x1f(%r15), %ecx
    56cf:      	addq	%rcx, %rax
    56d2:      	leaq	0x10(%rsp), %rdi
    56d7:      	movl	$0x8, %ecx
    56dc:      	movl	$0x70, %r8d
    56e2:      	movzbl	0x1f(%r15), %edx
    56e7:      	addq	0x20(%rsp), %rdx
    56ec:      	movl	$0x8, %esi
    56f1:      	callq	*%r8
    56f4:      	testq	%rax, %rax
    56f7:      	jne	0x4c7 <kprobe_unwind_ruby+0x4c7>
    56fd:      	movzbl	0x21(%r15), %eax
    5702:      	addq	0x10(%rsp), %rax
    5707:      	leaq	0x68(%rsp), %rdi
    570c:      	movl	$0x8, %ecx
    5711:      	movl	$0x70, %r8d
    5717:      	movzbl	0x21(%r15), %edx
    571c:      	addq	0x10(%rsp), %rdx
    5721:      	movl	$0x8, %esi
    5726:      	callq	*%r8
    5729:      	testq	%rax, %rax
    572c:      	jne	0x8a4 <kprobe_unwind_ruby+0x8a4>
    5732:      	movzbl	0x22(%r15), %eax
    5737:      	addq	0x10(%rsp), %rax
    573c:      	leaq	0x2c(%rsp), %rdi
    5741:      	movl	$0x4, %ecx
    5746:      	movl	$0x70, %r8d
    574c:      	movzbl	0x22(%r15), %edx
    5751:      	addq	0x10(%rsp), %rdx
    5756:      	movl	$0x4, %esi
    575b:      	callq	*%r8
    575e:      	testq	%rax, %rax
    5761:      	jne	0xc08 <kprobe_unwind_ruby+0xc08>
    5767:      	movzbl	0x23(%r15), %ecx
    576c:      	testq	%rcx, %rcx
    576f:      	je	0x5875 <kprobe_unwind_ruby+0x5875>
    5775:      	movq	0x18(%rsp), %rax
    577a:      	subq	0x68(%rsp), %rax
    577f:      	xorl	%edx, %edx
    5781:      	divq	%rcx
    5784:      	movl	0x2c(%rsp), %ecx
    5788:      	cmpq	%rcx, %rax
    578b:      	jbe	0x5875 <kprobe_unwind_ruby+0x5875>
    5791:      	movq	(%rip), %rax            # 0x5798 <kprobe_unwind_ruby+0x5798>
    5798:      	cmpl	$0x0, (%rax)
    579b:      	je	0x5986 <kprobe_unwind_ruby+0x5986>
    57a1:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    57ab:      	movq	%rax, 0x55(%rsp)
    57b0:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    57ba:      	movq	%rax, 0x50(%rsp)
    57bf:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    57c9:      	movq	%rax, 0x48(%rsp)
    57ce:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    57d8:      	movq	%rax, 0x40(%rsp)
    57dd:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    57e7:      	movq	%rax, 0x38(%rsp)
    57ec:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    57f6:      	movq	%rax, 0x30(%rsp)
    57fb:      	leaq	0x30(%rsp), %rdi
    5800:      	movl	$0x2d, %eax
    5805:      	movl	$0x6, %ecx
    580a:      	movl	$0x2d, %esi
    580f:      	xorl	%eax, %eax
    5811:      	callq	*%rcx
    5813:      	jmp	0x5986 <kprobe_unwind_ruby+0x5986>
    5818:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    581f:      	jb	0x5986 <kprobe_unwind_ruby+0x5986>
    5825:      	movq	$0x0, (%rsp)
    582d:      	movzbl	0x1d(%r15), %eax
    5832:      	addq	0x8(%rsp), %rax
    5837:      	movq	%rsp, %rdi
    583a:      	movl	$0x8, %ecx
    583f:      	movl	$0x70, %r8d
    5845:      	movzbl	0x1d(%r15), %edx
    584a:      	addq	0x8(%rsp), %rdx
    584f:      	movl	$0x8, %esi
    5854:      	callq	*%r8
    5857:      	testq	%rax, %rax
    585a:      	jne	0x81b <kprobe_unwind_ruby+0x81b>
    5860:      	movl	(%rsp), %eax
    5863:      	notl	%eax
    5865:      	testl	$0x140, %eax            # imm = 0x140
    586a:      	jne	0x997 <kprobe_unwind_ruby+0x997>
    5870:      	jmp	0x5986 <kprobe_unwind_ruby+0x5986>
    5875:      	movl	0x2c0(%r14), %eax
    587c:      	cmpq	$0x7e, %rax
    5880:      	ja	0xdd3 <kprobe_unwind_ruby+0xdd3>
    5886:      	movq	0x10(%rsp), %rcx
    588b:      	movq	0x18(%rsp), %rdx
    5890:      	leal	0x1(%rax), %esi
    5893:      	movl	%esi, 0x2c0(%r14)
    589a:      	leaq	(%rax,%rax,2), %rax
    589e:      	movw	$0x0, 0x4(%rsp)
    58a5:      	movl	$0x0, (%rsp)
    58ac:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    58b4:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    58bc:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    58c7:      	movl	(%rsp), %ecx
    58ca:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    58d2:      	movzwl	0x4(%rsp), %ecx
    58d7:      	movw	%cx, 0x2e6(%r14,%rax,8)
    58e0:      	movl	$0x36, (%rsp)
    58e7:      	movq	(%rip), %rdi            # 0x58ee <kprobe_unwind_ruby+0x58ee>
    58ee:      	movq	%rsp, %rsi
    58f1:      	movl	$0x1, %eax
    58f6:      	callq	*%rax
    58f8:      	testq	%rax, %rax
    58fb:      	je	0x5905 <kprobe_unwind_ruby+0x5905>
    58fd:      	incq	(%rax)
    5900:      	jmp	0x5986 <kprobe_unwind_ruby+0x5986>
    5905:      	movq	(%rip), %rax            # 0x590c <kprobe_unwind_ruby+0x590c>
    590c:      	cmpl	$0x0, (%rax)
    590f:      	je	0x5986 <kprobe_unwind_ruby+0x5986>
    5911:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    591b:      	movq	%rax, 0x56(%rsp)
    5920:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    592a:      	movq	%rax, 0x50(%rsp)
    592f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5939:      	movq	%rax, 0x48(%rsp)
    593e:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5948:      	movq	%rax, 0x40(%rsp)
    594d:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5957:      	movq	%rax, 0x38(%rsp)
    595c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5966:      	movq	%rax, 0x30(%rsp)
    596b:      	leaq	0x30(%rsp), %rdi
    5970:      	movl	$0x2e, %eax
    5975:      	movl	$0x6, %ecx
    597a:      	movl	(%rsp), %edx
    597d:      	movl	$0x2e, %esi
    5982:      	xorl	%eax, %eax
    5984:      	callq	*%rcx
    5986:      	movq	0x8(%rsp), %rax
    598b:      	cmpq	%rax, %r12
    598e:      	jbe	0x2b2 <kprobe_unwind_ruby+0x2b2>
    5994:      	movzbl	0x1e(%r15), %ecx
    5999:      	addq	%rcx, %rax
    599c:      	movq	%rax, 0x8(%rsp)
    59a1:      	movq	$0x0, 0x18(%rsp)
    59aa:      	movq	$0x0, 0x20(%rsp)
    59b3:      	movzbl	0x1c(%r15), %ecx
    59b8:      	addq	%rax, %rcx
    59bb:      	leaq	0x20(%rsp), %rdi
    59c0:      	movl	$0x8, %eax
    59c5:      	movl	$0x70, %r8d
    59cb:      	movzbl	0x1c(%r15), %edx
    59d0:      	addq	0x8(%rsp), %rdx
    59d5:      	movl	$0x8, %esi
    59da:      	callq	*%r8
    59dd:      	movzbl	0x1b(%r15), %eax
    59e2:      	addq	0x8(%rsp), %rax
    59e7:      	leaq	0x18(%rsp), %rdi
    59ec:      	movl	$0x8, %ecx
    59f1:      	movl	$0x70, %r8d
    59f7:      	movzbl	0x1b(%r15), %edx
    59fc:      	addq	0x8(%rsp), %rdx
    5a01:      	movl	$0x8, %esi
    5a06:      	callq	*%r8
    5a09:      	cmpq	$0x0, 0x18(%rsp)
    5a0f:      	je	0x5b71 <kprobe_unwind_ruby+0x5b71>
    5a15:      	movq	0x20(%rsp), %rax
    5a1a:      	testq	%rax, %rax
    5a1d:      	je	0x5b71 <kprobe_unwind_ruby+0x5b71>
    5a23:      	movzbl	0x1f(%r15), %ecx
    5a28:      	addq	%rcx, %rax
    5a2b:      	leaq	0x10(%rsp), %rdi
    5a30:      	movl	$0x8, %ecx
    5a35:      	movl	$0x70, %r8d
    5a3b:      	movzbl	0x1f(%r15), %edx
    5a40:      	addq	0x20(%rsp), %rdx
    5a45:      	movl	$0x8, %esi
    5a4a:      	callq	*%r8
    5a4d:      	testq	%rax, %rax
    5a50:      	jne	0x4c7 <kprobe_unwind_ruby+0x4c7>
    5a56:      	movzbl	0x21(%r15), %eax
    5a5b:      	addq	0x10(%rsp), %rax
    5a60:      	leaq	0x68(%rsp), %rdi
    5a65:      	movl	$0x8, %ecx
    5a6a:      	movl	$0x70, %r8d
    5a70:      	movzbl	0x21(%r15), %edx
    5a75:      	addq	0x10(%rsp), %rdx
    5a7a:      	movl	$0x8, %esi
    5a7f:      	callq	*%r8
    5a82:      	testq	%rax, %rax
    5a85:      	jne	0x8a4 <kprobe_unwind_ruby+0x8a4>
    5a8b:      	movzbl	0x22(%r15), %eax
    5a90:      	addq	0x10(%rsp), %rax
    5a95:      	leaq	0x2c(%rsp), %rdi
    5a9a:      	movl	$0x4, %ecx
    5a9f:      	movl	$0x70, %r8d
    5aa5:      	movzbl	0x22(%r15), %edx
    5aaa:      	addq	0x10(%rsp), %rdx
    5aaf:      	movl	$0x4, %esi
    5ab4:      	callq	*%r8
    5ab7:      	testq	%rax, %rax
    5aba:      	jne	0xc08 <kprobe_unwind_ruby+0xc08>
    5ac0:      	movzbl	0x23(%r15), %ecx
    5ac5:      	testq	%rcx, %rcx
    5ac8:      	je	0x5bce <kprobe_unwind_ruby+0x5bce>
    5ace:      	movq	0x18(%rsp), %rax
    5ad3:      	subq	0x68(%rsp), %rax
    5ad8:      	xorl	%edx, %edx
    5ada:      	divq	%rcx
    5add:      	movl	0x2c(%rsp), %ecx
    5ae1:      	cmpq	%rcx, %rax
    5ae4:      	jbe	0x5bce <kprobe_unwind_ruby+0x5bce>
    5aea:      	movq	(%rip), %rax            # 0x5af1 <kprobe_unwind_ruby+0x5af1>
    5af1:      	cmpl	$0x0, (%rax)
    5af4:      	je	0x5cdf <kprobe_unwind_ruby+0x5cdf>
    5afa:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    5b04:      	movq	%rax, 0x55(%rsp)
    5b09:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    5b13:      	movq	%rax, 0x50(%rsp)
    5b18:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    5b22:      	movq	%rax, 0x48(%rsp)
    5b27:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    5b31:      	movq	%rax, 0x40(%rsp)
    5b36:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    5b40:      	movq	%rax, 0x38(%rsp)
    5b45:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    5b4f:      	movq	%rax, 0x30(%rsp)
    5b54:      	leaq	0x30(%rsp), %rdi
    5b59:      	movl	$0x2d, %eax
    5b5e:      	movl	$0x6, %ecx
    5b63:      	movl	$0x2d, %esi
    5b68:      	xorl	%eax, %eax
    5b6a:      	callq	*%rcx
    5b6c:      	jmp	0x5cdf <kprobe_unwind_ruby+0x5cdf>
    5b71:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    5b78:      	jb	0x5cdf <kprobe_unwind_ruby+0x5cdf>
    5b7e:      	movq	$0x0, (%rsp)
    5b86:      	movzbl	0x1d(%r15), %eax
    5b8b:      	addq	0x8(%rsp), %rax
    5b90:      	movq	%rsp, %rdi
    5b93:      	movl	$0x8, %ecx
    5b98:      	movl	$0x70, %r8d
    5b9e:      	movzbl	0x1d(%r15), %edx
    5ba3:      	addq	0x8(%rsp), %rdx
    5ba8:      	movl	$0x8, %esi
    5bad:      	callq	*%r8
    5bb0:      	testq	%rax, %rax
    5bb3:      	jne	0x81b <kprobe_unwind_ruby+0x81b>
    5bb9:      	movl	(%rsp), %eax
    5bbc:      	notl	%eax
    5bbe:      	testl	$0x140, %eax            # imm = 0x140
    5bc3:      	jne	0x997 <kprobe_unwind_ruby+0x997>
    5bc9:      	jmp	0x5cdf <kprobe_unwind_ruby+0x5cdf>
    5bce:      	movl	0x2c0(%r14), %eax
    5bd5:      	cmpq	$0x7e, %rax
    5bd9:      	ja	0xdd3 <kprobe_unwind_ruby+0xdd3>
    5bdf:      	movq	0x10(%rsp), %rcx
    5be4:      	movq	0x18(%rsp), %rdx
    5be9:      	leal	0x1(%rax), %esi
    5bec:      	movl	%esi, 0x2c0(%r14)
    5bf3:      	leaq	(%rax,%rax,2), %rax
    5bf7:      	movw	$0x0, 0x4(%rsp)
    5bfe:      	movl	$0x0, (%rsp)
    5c05:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    5c0d:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    5c15:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    5c20:      	movl	(%rsp), %ecx
    5c23:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    5c2b:      	movzwl	0x4(%rsp), %ecx
    5c30:      	movw	%cx, 0x2e6(%r14,%rax,8)
    5c39:      	movl	$0x36, (%rsp)
    5c40:      	movq	(%rip), %rdi            # 0x5c47 <kprobe_unwind_ruby+0x5c47>
    5c47:      	movq	%rsp, %rsi
    5c4a:      	movl	$0x1, %eax
    5c4f:      	callq	*%rax
    5c51:      	testq	%rax, %rax
    5c54:      	je	0x5c5e <kprobe_unwind_ruby+0x5c5e>
    5c56:      	incq	(%rax)
    5c59:      	jmp	0x5cdf <kprobe_unwind_ruby+0x5cdf>
    5c5e:      	movq	(%rip), %rax            # 0x5c65 <kprobe_unwind_ruby+0x5c65>
    5c65:      	cmpl	$0x0, (%rax)
    5c68:      	je	0x5cdf <kprobe_unwind_ruby+0x5cdf>
    5c6a:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5c74:      	movq	%rax, 0x56(%rsp)
    5c79:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5c83:      	movq	%rax, 0x50(%rsp)
    5c88:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5c92:      	movq	%rax, 0x48(%rsp)
    5c97:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5ca1:      	movq	%rax, 0x40(%rsp)
    5ca6:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5cb0:      	movq	%rax, 0x38(%rsp)
    5cb5:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5cbf:      	movq	%rax, 0x30(%rsp)
    5cc4:      	leaq	0x30(%rsp), %rdi
    5cc9:      	movl	$0x2e, %eax
    5cce:      	movl	$0x6, %ecx
    5cd3:      	movl	(%rsp), %edx
    5cd6:      	movl	$0x2e, %esi
    5cdb:      	xorl	%eax, %eax
    5cdd:      	callq	*%rcx
    5cdf:      	movq	0x8(%rsp), %rax
    5ce4:      	cmpq	%rax, %r12
    5ce7:      	jbe	0x2b2 <kprobe_unwind_ruby+0x2b2>
    5ced:      	movzbl	0x1e(%r15), %ecx
    5cf2:      	addq	%rcx, %rax
    5cf5:      	movq	%rax, 0x8(%rsp)
    5cfa:      	movq	$0x0, 0x18(%rsp)
    5d03:      	movq	$0x0, 0x20(%rsp)
    5d0c:      	movzbl	0x1c(%r15), %ecx
    5d11:      	addq	%rax, %rcx
    5d14:      	leaq	0x20(%rsp), %rdi
    5d19:      	movl	$0x8, %eax
    5d1e:      	movl	$0x70, %r8d
    5d24:      	movzbl	0x1c(%r15), %edx
    5d29:      	addq	0x8(%rsp), %rdx
    5d2e:      	movl	$0x8, %esi
    5d33:      	callq	*%r8
    5d36:      	movzbl	0x1b(%r15), %eax
    5d3b:      	addq	0x8(%rsp), %rax
    5d40:      	leaq	0x18(%rsp), %rdi
    5d45:      	movl	$0x8, %ecx
    5d4a:      	movl	$0x70, %r8d
    5d50:      	movzbl	0x1b(%r15), %edx
    5d55:      	addq	0x8(%rsp), %rdx
    5d5a:      	movl	$0x8, %esi
    5d5f:      	callq	*%r8
    5d62:      	cmpq	$0x0, 0x18(%rsp)
    5d68:      	je	0x5eca <kprobe_unwind_ruby+0x5eca>
    5d6e:      	movq	0x20(%rsp), %rax
    5d73:      	testq	%rax, %rax
    5d76:      	je	0x5eca <kprobe_unwind_ruby+0x5eca>
    5d7c:      	movzbl	0x1f(%r15), %ecx
    5d81:      	addq	%rcx, %rax
    5d84:      	leaq	0x10(%rsp), %rdi
    5d89:      	movl	$0x8, %ecx
    5d8e:      	movl	$0x70, %r8d
    5d94:      	movzbl	0x1f(%r15), %edx
    5d99:      	addq	0x20(%rsp), %rdx
    5d9e:      	movl	$0x8, %esi
    5da3:      	callq	*%r8
    5da6:      	testq	%rax, %rax
    5da9:      	jne	0x4c7 <kprobe_unwind_ruby+0x4c7>
    5daf:      	movzbl	0x21(%r15), %eax
    5db4:      	addq	0x10(%rsp), %rax
    5db9:      	leaq	0x68(%rsp), %rdi
    5dbe:      	movl	$0x8, %ecx
    5dc3:      	movl	$0x70, %r8d
    5dc9:      	movzbl	0x21(%r15), %edx
    5dce:      	addq	0x10(%rsp), %rdx
    5dd3:      	movl	$0x8, %esi
    5dd8:      	callq	*%r8
    5ddb:      	testq	%rax, %rax
    5dde:      	jne	0x8a4 <kprobe_unwind_ruby+0x8a4>
    5de4:      	movzbl	0x22(%r15), %eax
    5de9:      	addq	0x10(%rsp), %rax
    5dee:      	leaq	0x2c(%rsp), %rdi
    5df3:      	movl	$0x4, %ecx
    5df8:      	movl	$0x70, %r8d
    5dfe:      	movzbl	0x22(%r15), %edx
    5e03:      	addq	0x10(%rsp), %rdx
    5e08:      	movl	$0x4, %esi
    5e0d:      	callq	*%r8
    5e10:      	testq	%rax, %rax
    5e13:      	jne	0xc08 <kprobe_unwind_ruby+0xc08>
    5e19:      	movzbl	0x23(%r15), %ecx
    5e1e:      	testq	%rcx, %rcx
    5e21:      	je	0x5f27 <kprobe_unwind_ruby+0x5f27>
    5e27:      	movq	0x18(%rsp), %rax
    5e2c:      	subq	0x68(%rsp), %rax
    5e31:      	xorl	%edx, %edx
    5e33:      	divq	%rcx
    5e36:      	movl	0x2c(%rsp), %ecx
    5e3a:      	cmpq	%rcx, %rax
    5e3d:      	jbe	0x5f27 <kprobe_unwind_ruby+0x5f27>
    5e43:      	movq	(%rip), %rax            # 0x5e4a <kprobe_unwind_ruby+0x5e4a>
    5e4a:      	cmpl	$0x0, (%rax)
    5e4d:      	je	0x6038 <kprobe_unwind_ruby+0x6038>
    5e53:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    5e5d:      	movq	%rax, 0x55(%rsp)
    5e62:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    5e6c:      	movq	%rax, 0x50(%rsp)
    5e71:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    5e7b:      	movq	%rax, 0x48(%rsp)
    5e80:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    5e8a:      	movq	%rax, 0x40(%rsp)
    5e8f:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    5e99:      	movq	%rax, 0x38(%rsp)
    5e9e:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    5ea8:      	movq	%rax, 0x30(%rsp)
    5ead:      	leaq	0x30(%rsp), %rdi
    5eb2:      	movl	$0x2d, %eax
    5eb7:      	movl	$0x6, %ecx
    5ebc:      	movl	$0x2d, %esi
    5ec1:      	xorl	%eax, %eax
    5ec3:      	callq	*%rcx
    5ec5:      	jmp	0x6038 <kprobe_unwind_ruby+0x6038>
    5eca:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    5ed1:      	jb	0x6038 <kprobe_unwind_ruby+0x6038>
    5ed7:      	movq	$0x0, (%rsp)
    5edf:      	movzbl	0x1d(%r15), %eax
    5ee4:      	addq	0x8(%rsp), %rax
    5ee9:      	movq	%rsp, %rdi
    5eec:      	movl	$0x8, %ecx
    5ef1:      	movl	$0x70, %r8d
    5ef7:      	movzbl	0x1d(%r15), %edx
    5efc:      	addq	0x8(%rsp), %rdx
    5f01:      	movl	$0x8, %esi
    5f06:      	callq	*%r8
    5f09:      	testq	%rax, %rax
    5f0c:      	jne	0x81b <kprobe_unwind_ruby+0x81b>
    5f12:      	movl	(%rsp), %eax
    5f15:      	notl	%eax
    5f17:      	testl	$0x140, %eax            # imm = 0x140
    5f1c:      	jne	0x997 <kprobe_unwind_ruby+0x997>
    5f22:      	jmp	0x6038 <kprobe_unwind_ruby+0x6038>
    5f27:      	movl	0x2c0(%r14), %eax
    5f2e:      	cmpq	$0x7e, %rax
    5f32:      	ja	0xdd3 <kprobe_unwind_ruby+0xdd3>
    5f38:      	movq	0x10(%rsp), %rcx
    5f3d:      	movq	0x18(%rsp), %rdx
    5f42:      	leal	0x1(%rax), %esi
    5f45:      	movl	%esi, 0x2c0(%r14)
    5f4c:      	leaq	(%rax,%rax,2), %rax
    5f50:      	movw	$0x0, 0x4(%rsp)
    5f57:      	movl	$0x0, (%rsp)
    5f5e:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    5f66:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    5f6e:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    5f79:      	movl	(%rsp), %ecx
    5f7c:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    5f84:      	movzwl	0x4(%rsp), %ecx
    5f89:      	movw	%cx, 0x2e6(%r14,%rax,8)
    5f92:      	movl	$0x36, (%rsp)
    5f99:      	movq	(%rip), %rdi            # 0x5fa0 <kprobe_unwind_ruby+0x5fa0>
    5fa0:      	movq	%rsp, %rsi
    5fa3:      	movl	$0x1, %eax
    5fa8:      	callq	*%rax
    5faa:      	testq	%rax, %rax
    5fad:      	je	0x5fb7 <kprobe_unwind_ruby+0x5fb7>
    5faf:      	incq	(%rax)
    5fb2:      	jmp	0x6038 <kprobe_unwind_ruby+0x6038>
    5fb7:      	movq	(%rip), %rax            # 0x5fbe <kprobe_unwind_ruby+0x5fbe>
    5fbe:      	cmpl	$0x0, (%rax)
    5fc1:      	je	0x6038 <kprobe_unwind_ruby+0x6038>
    5fc3:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5fcd:      	movq	%rax, 0x56(%rsp)
    5fd2:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5fdc:      	movq	%rax, 0x50(%rsp)
    5fe1:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5feb:      	movq	%rax, 0x48(%rsp)
    5ff0:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5ffa:      	movq	%rax, 0x40(%rsp)
    5fff:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    6009:      	movq	%rax, 0x38(%rsp)
    600e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6018:      	movq	%rax, 0x30(%rsp)
    601d:      	leaq	0x30(%rsp), %rdi
    6022:      	movl	$0x2e, %eax
    6027:      	movl	$0x6, %ecx
    602c:      	movl	(%rsp), %edx
    602f:      	movl	$0x2e, %esi
    6034:      	xorl	%eax, %eax
    6036:      	callq	*%rcx
    6038:      	movq	0x8(%rsp), %rax
    603d:      	cmpq	%rax, %r12
    6040:      	jbe	0x2b2 <kprobe_unwind_ruby+0x2b2>
    6046:      	movzbl	0x1e(%r15), %ecx
    604b:      	addq	%rcx, %rax
    604e:      	movq	%rax, 0x8(%rsp)
    6053:      	movq	$0x0, 0x18(%rsp)
    605c:      	movq	$0x0, 0x20(%rsp)
    6065:      	movzbl	0x1c(%r15), %ecx
    606a:      	addq	%rax, %rcx
    606d:      	leaq	0x20(%rsp), %rdi
    6072:      	movl	$0x8, %eax
    6077:      	movl	$0x70, %r8d
    607d:      	movzbl	0x1c(%r15), %edx
    6082:      	addq	0x8(%rsp), %rdx
    6087:      	movl	$0x8, %esi
    608c:      	callq	*%r8
    608f:      	movzbl	0x1b(%r15), %eax
    6094:      	addq	0x8(%rsp), %rax
    6099:      	leaq	0x18(%rsp), %rdi
    609e:      	movl	$0x8, %ecx
    60a3:      	movl	$0x70, %r8d
    60a9:      	movzbl	0x1b(%r15), %edx
    60ae:      	addq	0x8(%rsp), %rdx
    60b3:      	movl	$0x8, %esi
    60b8:      	callq	*%r8
    60bb:      	cmpq	$0x0, 0x18(%rsp)
    60c1:      	je	0x6223 <kprobe_unwind_ruby+0x6223>
    60c7:      	movq	0x20(%rsp), %rax
    60cc:      	testq	%rax, %rax
    60cf:      	je	0x6223 <kprobe_unwind_ruby+0x6223>
    60d5:      	movzbl	0x1f(%r15), %ecx
    60da:      	addq	%rcx, %rax
    60dd:      	leaq	0x10(%rsp), %rdi
    60e2:      	movl	$0x8, %ecx
    60e7:      	movl	$0x70, %r8d
    60ed:      	movzbl	0x1f(%r15), %edx
    60f2:      	addq	0x20(%rsp), %rdx
    60f7:      	movl	$0x8, %esi
    60fc:      	callq	*%r8
    60ff:      	testq	%rax, %rax
    6102:      	jne	0x4c7 <kprobe_unwind_ruby+0x4c7>
    6108:      	movzbl	0x21(%r15), %eax
    610d:      	addq	0x10(%rsp), %rax
    6112:      	leaq	0x68(%rsp), %rdi
    6117:      	movl	$0x8, %ecx
    611c:      	movl	$0x70, %r8d
    6122:      	movzbl	0x21(%r15), %edx
    6127:      	addq	0x10(%rsp), %rdx
    612c:      	movl	$0x8, %esi
    6131:      	callq	*%r8
    6134:      	testq	%rax, %rax
    6137:      	jne	0x8a4 <kprobe_unwind_ruby+0x8a4>
    613d:      	movzbl	0x22(%r15), %eax
    6142:      	addq	0x10(%rsp), %rax
    6147:      	leaq	0x2c(%rsp), %rdi
    614c:      	movl	$0x4, %ecx
    6151:      	movl	$0x70, %r8d
    6157:      	movzbl	0x22(%r15), %edx
    615c:      	addq	0x10(%rsp), %rdx
    6161:      	movl	$0x4, %esi
    6166:      	callq	*%r8
    6169:      	testq	%rax, %rax
    616c:      	jne	0xc08 <kprobe_unwind_ruby+0xc08>
    6172:      	movzbl	0x23(%r15), %ecx
    6177:      	testq	%rcx, %rcx
    617a:      	je	0x6280 <kprobe_unwind_ruby+0x6280>
    6180:      	movq	0x18(%rsp), %rax
    6185:      	subq	0x68(%rsp), %rax
    618a:      	xorl	%edx, %edx
    618c:      	divq	%rcx
    618f:      	movl	0x2c(%rsp), %ecx
    6193:      	cmpq	%rcx, %rax
    6196:      	jbe	0x6280 <kprobe_unwind_ruby+0x6280>
    619c:      	movq	(%rip), %rax            # 0x61a3 <kprobe_unwind_ruby+0x61a3>
    61a3:      	cmpl	$0x0, (%rax)
    61a6:      	je	0x6391 <kprobe_unwind_ruby+0x6391>
    61ac:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    61b6:      	movq	%rax, 0x55(%rsp)
    61bb:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    61c5:      	movq	%rax, 0x50(%rsp)
    61ca:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    61d4:      	movq	%rax, 0x48(%rsp)
    61d9:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    61e3:      	movq	%rax, 0x40(%rsp)
    61e8:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    61f2:      	movq	%rax, 0x38(%rsp)
    61f7:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    6201:      	movq	%rax, 0x30(%rsp)
    6206:      	leaq	0x30(%rsp), %rdi
    620b:      	movl	$0x2d, %eax
    6210:      	movl	$0x6, %ecx
    6215:      	movl	$0x2d, %esi
    621a:      	xorl	%eax, %eax
    621c:      	callq	*%rcx
    621e:      	jmp	0x6391 <kprobe_unwind_ruby+0x6391>
    6223:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    622a:      	jb	0x6391 <kprobe_unwind_ruby+0x6391>
    6230:      	movq	$0x0, (%rsp)
    6238:      	movzbl	0x1d(%r15), %eax
    623d:      	addq	0x8(%rsp), %rax
    6242:      	movq	%rsp, %rdi
    6245:      	movl	$0x8, %ecx
    624a:      	movl	$0x70, %r8d
    6250:      	movzbl	0x1d(%r15), %edx
    6255:      	addq	0x8(%rsp), %rdx
    625a:      	movl	$0x8, %esi
    625f:      	callq	*%r8
    6262:      	testq	%rax, %rax
    6265:      	jne	0x81b <kprobe_unwind_ruby+0x81b>
    626b:      	movl	(%rsp), %eax
    626e:      	notl	%eax
    6270:      	testl	$0x140, %eax            # imm = 0x140
    6275:      	jne	0x997 <kprobe_unwind_ruby+0x997>
    627b:      	jmp	0x6391 <kprobe_unwind_ruby+0x6391>
    6280:      	movl	0x2c0(%r14), %eax
    6287:      	cmpq	$0x7e, %rax
    628b:      	ja	0xdd3 <kprobe_unwind_ruby+0xdd3>
    6291:      	movq	0x10(%rsp), %rcx
    6296:      	movq	0x18(%rsp), %rdx
    629b:      	leal	0x1(%rax), %esi
    629e:      	movl	%esi, 0x2c0(%r14)
    62a5:      	leaq	(%rax,%rax,2), %rax
    62a9:      	movw	$0x0, 0x4(%rsp)
    62b0:      	movl	$0x0, (%rsp)
    62b7:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    62bf:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    62c7:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    62d2:      	movl	(%rsp), %ecx
    62d5:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    62dd:      	movzwl	0x4(%rsp), %ecx
    62e2:      	movw	%cx, 0x2e6(%r14,%rax,8)
    62eb:      	movl	$0x36, (%rsp)
    62f2:      	movq	(%rip), %rdi            # 0x62f9 <kprobe_unwind_ruby+0x62f9>
    62f9:      	movq	%rsp, %rsi
    62fc:      	movl	$0x1, %eax
    6301:      	callq	*%rax
    6303:      	testq	%rax, %rax
    6306:      	je	0x6310 <kprobe_unwind_ruby+0x6310>
    6308:      	incq	(%rax)
    630b:      	jmp	0x6391 <kprobe_unwind_ruby+0x6391>
    6310:      	movq	(%rip), %rax            # 0x6317 <kprobe_unwind_ruby+0x6317>
    6317:      	cmpl	$0x0, (%rax)
    631a:      	je	0x6391 <kprobe_unwind_ruby+0x6391>
    631c:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    6326:      	movq	%rax, 0x56(%rsp)
    632b:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    6335:      	movq	%rax, 0x50(%rsp)
    633a:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    6344:      	movq	%rax, 0x48(%rsp)
    6349:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    6353:      	movq	%rax, 0x40(%rsp)
    6358:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    6362:      	movq	%rax, 0x38(%rsp)
    6367:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6371:      	movq	%rax, 0x30(%rsp)
    6376:      	leaq	0x30(%rsp), %rdi
    637b:      	movl	$0x2e, %eax
    6380:      	movl	$0x6, %ecx
    6385:      	movl	(%rsp), %edx
    6388:      	movl	$0x2e, %esi
    638d:      	xorl	%eax, %eax
    638f:      	callq	*%rcx
    6391:      	movq	0x8(%rsp), %rax
    6396:      	cmpq	%rax, %r12
    6399:      	jbe	0x2b2 <kprobe_unwind_ruby+0x2b2>
    639f:      	movzbl	0x1e(%r15), %ecx
    63a4:      	addq	%rcx, %rax
    63a7:      	movq	%rax, 0x8(%rsp)
    63ac:      	movq	$0x0, 0x18(%rsp)
    63b5:      	movq	$0x0, 0x20(%rsp)
    63be:      	movzbl	0x1c(%r15), %ecx
    63c3:      	addq	%rax, %rcx
    63c6:      	leaq	0x20(%rsp), %rdi
    63cb:      	movl	$0x8, %eax
    63d0:      	movl	$0x70, %r8d
    63d6:      	movzbl	0x1c(%r15), %edx
    63db:      	addq	0x8(%rsp), %rdx
    63e0:      	movl	$0x8, %esi
    63e5:      	callq	*%r8
    63e8:      	movzbl	0x1b(%r15), %eax
    63ed:      	addq	0x8(%rsp), %rax
    63f2:      	leaq	0x18(%rsp), %rdi
    63f7:      	movl	$0x8, %ecx
    63fc:      	movl	$0x70, %r8d
    6402:      	movzbl	0x1b(%r15), %edx
    6407:      	addq	0x8(%rsp), %rdx
    640c:      	movl	$0x8, %esi
    6411:      	callq	*%r8
    6414:      	cmpq	$0x0, 0x18(%rsp)
    641a:      	je	0x657c <kprobe_unwind_ruby+0x657c>
    6420:      	movq	0x20(%rsp), %rax
    6425:      	testq	%rax, %rax
    6428:      	je	0x657c <kprobe_unwind_ruby+0x657c>
    642e:      	movzbl	0x1f(%r15), %ecx
    6433:      	addq	%rcx, %rax
    6436:      	leaq	0x10(%rsp), %rdi
    643b:      	movl	$0x8, %ecx
    6440:      	movl	$0x70, %r8d
    6446:      	movzbl	0x1f(%r15), %edx
    644b:      	addq	0x20(%rsp), %rdx
    6450:      	movl	$0x8, %esi
    6455:      	callq	*%r8
    6458:      	testq	%rax, %rax
    645b:      	jne	0x4c7 <kprobe_unwind_ruby+0x4c7>
    6461:      	movzbl	0x21(%r15), %eax
    6466:      	addq	0x10(%rsp), %rax
    646b:      	leaq	0x68(%rsp), %rdi
    6470:      	movl	$0x8, %ecx
    6475:      	movl	$0x70, %r8d
    647b:      	movzbl	0x21(%r15), %edx
    6480:      	addq	0x10(%rsp), %rdx
    6485:      	movl	$0x8, %esi
    648a:      	callq	*%r8
    648d:      	testq	%rax, %rax
    6490:      	jne	0x8a4 <kprobe_unwind_ruby+0x8a4>
    6496:      	movzbl	0x22(%r15), %eax
    649b:      	addq	0x10(%rsp), %rax
    64a0:      	leaq	0x2c(%rsp), %rdi
    64a5:      	movl	$0x4, %ecx
    64aa:      	movl	$0x70, %r8d
    64b0:      	movzbl	0x22(%r15), %edx
    64b5:      	addq	0x10(%rsp), %rdx
    64ba:      	movl	$0x4, %esi
    64bf:      	callq	*%r8
    64c2:      	testq	%rax, %rax
    64c5:      	jne	0xc08 <kprobe_unwind_ruby+0xc08>
    64cb:      	movzbl	0x23(%r15), %ecx
    64d0:      	testq	%rcx, %rcx
    64d3:      	je	0x65d9 <kprobe_unwind_ruby+0x65d9>
    64d9:      	movq	0x18(%rsp), %rax
    64de:      	subq	0x68(%rsp), %rax
    64e3:      	xorl	%edx, %edx
    64e5:      	divq	%rcx
    64e8:      	movl	0x2c(%rsp), %ecx
    64ec:      	cmpq	%rcx, %rax
    64ef:      	jbe	0x65d9 <kprobe_unwind_ruby+0x65d9>
    64f5:      	movq	(%rip), %rax            # 0x64fc <kprobe_unwind_ruby+0x64fc>
    64fc:      	cmpl	$0x0, (%rax)
    64ff:      	je	0x66ea <kprobe_unwind_ruby+0x66ea>
    6505:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    650f:      	movq	%rax, 0x55(%rsp)
    6514:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    651e:      	movq	%rax, 0x50(%rsp)
    6523:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    652d:      	movq	%rax, 0x48(%rsp)
    6532:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    653c:      	movq	%rax, 0x40(%rsp)
    6541:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    654b:      	movq	%rax, 0x38(%rsp)
    6550:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    655a:      	movq	%rax, 0x30(%rsp)
    655f:      	leaq	0x30(%rsp), %rdi
    6564:      	movl	$0x2d, %eax
    6569:      	movl	$0x6, %ecx
    656e:      	movl	$0x2d, %esi
    6573:      	xorl	%eax, %eax
    6575:      	callq	*%rcx
    6577:      	jmp	0x66ea <kprobe_unwind_ruby+0x66ea>
    657c:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    6583:      	jb	0x66ea <kprobe_unwind_ruby+0x66ea>
    6589:      	movq	$0x0, (%rsp)
    6591:      	movzbl	0x1d(%r15), %eax
    6596:      	addq	0x8(%rsp), %rax
    659b:      	movq	%rsp, %rdi
    659e:      	movl	$0x8, %ecx
    65a3:      	movl	$0x70, %r8d
    65a9:      	movzbl	0x1d(%r15), %edx
    65ae:      	addq	0x8(%rsp), %rdx
    65b3:      	movl	$0x8, %esi
    65b8:      	callq	*%r8
    65bb:      	testq	%rax, %rax
    65be:      	jne	0x81b <kprobe_unwind_ruby+0x81b>
    65c4:      	movl	(%rsp), %eax
    65c7:      	notl	%eax
    65c9:      	testl	$0x140, %eax            # imm = 0x140
    65ce:      	jne	0x997 <kprobe_unwind_ruby+0x997>
    65d4:      	jmp	0x66ea <kprobe_unwind_ruby+0x66ea>
    65d9:      	movl	0x2c0(%r14), %eax
    65e0:      	cmpq	$0x7e, %rax
    65e4:      	ja	0xdd3 <kprobe_unwind_ruby+0xdd3>
    65ea:      	movq	0x10(%rsp), %rcx
    65ef:      	movq	0x18(%rsp), %rdx
    65f4:      	leal	0x1(%rax), %esi
    65f7:      	movl	%esi, 0x2c0(%r14)
    65fe:      	leaq	(%rax,%rax,2), %rax
    6602:      	movw	$0x0, 0x4(%rsp)
    6609:      	movl	$0x0, (%rsp)
    6610:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    6618:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    6620:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    662b:      	movl	(%rsp), %ecx
    662e:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    6636:      	movzwl	0x4(%rsp), %ecx
    663b:      	movw	%cx, 0x2e6(%r14,%rax,8)
    6644:      	movl	$0x36, (%rsp)
    664b:      	movq	(%rip), %rdi            # 0x6652 <kprobe_unwind_ruby+0x6652>
    6652:      	movq	%rsp, %rsi
    6655:      	movl	$0x1, %eax
    665a:      	callq	*%rax
    665c:      	testq	%rax, %rax
    665f:      	je	0x6669 <kprobe_unwind_ruby+0x6669>
    6661:      	incq	(%rax)
    6664:      	jmp	0x66ea <kprobe_unwind_ruby+0x66ea>
    6669:      	movq	(%rip), %rax            # 0x6670 <kprobe_unwind_ruby+0x6670>
    6670:      	cmpl	$0x0, (%rax)
    6673:      	je	0x66ea <kprobe_unwind_ruby+0x66ea>
    6675:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    667f:      	movq	%rax, 0x56(%rsp)
    6684:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    668e:      	movq	%rax, 0x50(%rsp)
    6693:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    669d:      	movq	%rax, 0x48(%rsp)
    66a2:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    66ac:      	movq	%rax, 0x40(%rsp)
    66b1:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    66bb:      	movq	%rax, 0x38(%rsp)
    66c0:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    66ca:      	movq	%rax, 0x30(%rsp)
    66cf:      	leaq	0x30(%rsp), %rdi
    66d4:      	movl	$0x2e, %eax
    66d9:      	movl	$0x6, %ecx
    66de:      	movl	(%rsp), %edx
    66e1:      	movl	$0x2e, %esi
    66e6:      	xorl	%eax, %eax
    66e8:      	callq	*%rcx
    66ea:      	movq	0x8(%rsp), %rax
    66ef:      	cmpq	%rax, %r12
    66f2:      	jbe	0x2b2 <kprobe_unwind_ruby+0x2b2>
    66f8:      	movzbl	0x1e(%r15), %ecx
    66fd:      	addq	%rcx, %rax
    6700:      	movq	%rax, 0x8(%rsp)
    6705:      	movq	$0x0, 0x18(%rsp)
    670e:      	movq	$0x0, 0x20(%rsp)
    6717:      	movzbl	0x1c(%r15), %ecx
    671c:      	addq	%rax, %rcx
    671f:      	leaq	0x20(%rsp), %rdi
    6724:      	movl	$0x8, %eax
    6729:      	movl	$0x70, %r8d
    672f:      	movzbl	0x1c(%r15), %edx
    6734:      	addq	0x8(%rsp), %rdx
    6739:      	movl	$0x8, %esi
    673e:      	callq	*%r8
    6741:      	movzbl	0x1b(%r15), %eax
    6746:      	addq	0x8(%rsp), %rax
    674b:      	leaq	0x18(%rsp), %rdi
    6750:      	movl	$0x8, %ecx
    6755:      	movl	$0x70, %r8d
    675b:      	movzbl	0x1b(%r15), %edx
    6760:      	addq	0x8(%rsp), %rdx
    6765:      	movl	$0x8, %esi
    676a:      	callq	*%r8
    676d:      	cmpq	$0x0, 0x18(%rsp)
    6773:      	je	0x68d5 <kprobe_unwind_ruby+0x68d5>
    6779:      	movq	0x20(%rsp), %rax
    677e:      	testq	%rax, %rax
    6781:      	je	0x68d5 <kprobe_unwind_ruby+0x68d5>
    6787:      	movzbl	0x1f(%r15), %ecx
    678c:      	addq	%rcx, %rax
    678f:      	leaq	0x10(%rsp), %rdi
    6794:      	movl	$0x8, %ecx
    6799:      	movl	$0x70, %r8d
    679f:      	movzbl	0x1f(%r15), %edx
    67a4:      	addq	0x20(%rsp), %rdx
    67a9:      	movl	$0x8, %esi
    67ae:      	callq	*%r8
    67b1:      	testq	%rax, %rax
    67b4:      	jne	0x4c7 <kprobe_unwind_ruby+0x4c7>
    67ba:      	movzbl	0x21(%r15), %eax
    67bf:      	addq	0x10(%rsp), %rax
    67c4:      	leaq	0x68(%rsp), %rdi
    67c9:      	movl	$0x8, %ecx
    67ce:      	movl	$0x70, %r8d
    67d4:      	movzbl	0x21(%r15), %edx
    67d9:      	addq	0x10(%rsp), %rdx
    67de:      	movl	$0x8, %esi
    67e3:      	callq	*%r8
    67e6:      	testq	%rax, %rax
    67e9:      	jne	0x8a4 <kprobe_unwind_ruby+0x8a4>
    67ef:      	movzbl	0x22(%r15), %eax
    67f4:      	addq	0x10(%rsp), %rax
    67f9:      	leaq	0x2c(%rsp), %rdi
    67fe:      	movl	$0x4, %ecx
    6803:      	movl	$0x70, %r8d
    6809:      	movzbl	0x22(%r15), %edx
    680e:      	addq	0x10(%rsp), %rdx
    6813:      	movl	$0x4, %esi
    6818:      	callq	*%r8
    681b:      	testq	%rax, %rax
    681e:      	jne	0xc08 <kprobe_unwind_ruby+0xc08>
    6824:      	movzbl	0x23(%r15), %ecx
    6829:      	testq	%rcx, %rcx
    682c:      	je	0x6932 <kprobe_unwind_ruby+0x6932>
    6832:      	movq	0x18(%rsp), %rax
    6837:      	subq	0x68(%rsp), %rax
    683c:      	xorl	%edx, %edx
    683e:      	divq	%rcx
    6841:      	movl	0x2c(%rsp), %ecx
    6845:      	cmpq	%rcx, %rax
    6848:      	jbe	0x6932 <kprobe_unwind_ruby+0x6932>
    684e:      	movq	(%rip), %rax            # 0x6855 <kprobe_unwind_ruby+0x6855>
    6855:      	cmpl	$0x0, (%rax)
    6858:      	je	0x6a43 <kprobe_unwind_ruby+0x6a43>
    685e:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    6868:      	movq	%rax, 0x55(%rsp)
    686d:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    6877:      	movq	%rax, 0x50(%rsp)
    687c:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    6886:      	movq	%rax, 0x48(%rsp)
    688b:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    6895:      	movq	%rax, 0x40(%rsp)
    689a:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    68a4:      	movq	%rax, 0x38(%rsp)
    68a9:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    68b3:      	movq	%rax, 0x30(%rsp)
    68b8:      	leaq	0x30(%rsp), %rdi
    68bd:      	movl	$0x2d, %eax
    68c2:      	movl	$0x6, %ecx
    68c7:      	movl	$0x2d, %esi
    68cc:      	xorl	%eax, %eax
    68ce:      	callq	*%rcx
    68d0:      	jmp	0x6a43 <kprobe_unwind_ruby+0x6a43>
    68d5:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    68dc:      	jb	0x6a43 <kprobe_unwind_ruby+0x6a43>
    68e2:      	movq	$0x0, (%rsp)
    68ea:      	movzbl	0x1d(%r15), %eax
    68ef:      	addq	0x8(%rsp), %rax
    68f4:      	movq	%rsp, %rdi
    68f7:      	movl	$0x8, %ecx
    68fc:      	movl	$0x70, %r8d
    6902:      	movzbl	0x1d(%r15), %edx
    6907:      	addq	0x8(%rsp), %rdx
    690c:      	movl	$0x8, %esi
    6911:      	callq	*%r8
    6914:      	testq	%rax, %rax
    6917:      	jne	0x81b <kprobe_unwind_ruby+0x81b>
    691d:      	movl	(%rsp), %eax
    6920:      	notl	%eax
    6922:      	testl	$0x140, %eax            # imm = 0x140
    6927:      	jne	0x997 <kprobe_unwind_ruby+0x997>
    692d:      	jmp	0x6a43 <kprobe_unwind_ruby+0x6a43>
    6932:      	movl	0x2c0(%r14), %eax
    6939:      	cmpq	$0x7e, %rax
    693d:      	ja	0xdd3 <kprobe_unwind_ruby+0xdd3>
    6943:      	movq	0x10(%rsp), %rcx
    6948:      	movq	0x18(%rsp), %rdx
    694d:      	leal	0x1(%rax), %esi
    6950:      	movl	%esi, 0x2c0(%r14)
    6957:      	leaq	(%rax,%rax,2), %rax
    695b:      	movw	$0x0, 0x4(%rsp)
    6962:      	movl	$0x0, (%rsp)
    6969:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    6971:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    6979:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    6984:      	movl	(%rsp), %ecx
    6987:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    698f:      	movzwl	0x4(%rsp), %ecx
    6994:      	movw	%cx, 0x2e6(%r14,%rax,8)
    699d:      	movl	$0x36, (%rsp)
    69a4:      	movq	(%rip), %rdi            # 0x69ab <kprobe_unwind_ruby+0x69ab>
    69ab:      	movq	%rsp, %rsi
    69ae:      	movl	$0x1, %eax
    69b3:      	callq	*%rax
    69b5:      	testq	%rax, %rax
    69b8:      	je	0x69c2 <kprobe_unwind_ruby+0x69c2>
    69ba:      	incq	(%rax)
    69bd:      	jmp	0x6a43 <kprobe_unwind_ruby+0x6a43>
    69c2:      	movq	(%rip), %rax            # 0x69c9 <kprobe_unwind_ruby+0x69c9>
    69c9:      	cmpl	$0x0, (%rax)
    69cc:      	je	0x6a43 <kprobe_unwind_ruby+0x6a43>
    69ce:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    69d8:      	movq	%rax, 0x56(%rsp)
    69dd:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    69e7:      	movq	%rax, 0x50(%rsp)
    69ec:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    69f6:      	movq	%rax, 0x48(%rsp)
    69fb:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    6a05:      	movq	%rax, 0x40(%rsp)
    6a0a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    6a14:      	movq	%rax, 0x38(%rsp)
    6a19:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6a23:      	movq	%rax, 0x30(%rsp)
    6a28:      	leaq	0x30(%rsp), %rdi
    6a2d:      	movl	$0x2e, %eax
    6a32:      	movl	$0x6, %ecx
    6a37:      	movl	(%rsp), %edx
    6a3a:      	movl	$0x2e, %esi
    6a3f:      	xorl	%eax, %eax
    6a41:      	callq	*%rcx
    6a43:      	movq	0x8(%rsp), %rax
    6a48:      	cmpq	%rax, %r12
    6a4b:      	jbe	0x2b2 <kprobe_unwind_ruby+0x2b2>
    6a51:      	movzbl	0x1e(%r15), %ecx
    6a56:      	addq	%rcx, %rax
    6a59:      	movq	%rax, 0x8(%rsp)
    6a5e:      	movq	$0x0, 0x18(%rsp)
    6a67:      	movq	$0x0, 0x20(%rsp)
    6a70:      	movzbl	0x1c(%r15), %ecx
    6a75:      	addq	%rax, %rcx
    6a78:      	leaq	0x20(%rsp), %rdi
    6a7d:      	movl	$0x8, %eax
    6a82:      	movl	$0x70, %r8d
    6a88:      	movzbl	0x1c(%r15), %edx
    6a8d:      	addq	0x8(%rsp), %rdx
    6a92:      	movl	$0x8, %esi
    6a97:      	callq	*%r8
    6a9a:      	movzbl	0x1b(%r15), %eax
    6a9f:      	addq	0x8(%rsp), %rax
    6aa4:      	leaq	0x18(%rsp), %rdi
    6aa9:      	movl	$0x8, %ecx
    6aae:      	movl	$0x70, %r8d
    6ab4:      	movzbl	0x1b(%r15), %edx
    6ab9:      	addq	0x8(%rsp), %rdx
    6abe:      	movl	$0x8, %esi
    6ac3:      	callq	*%r8
    6ac6:      	cmpq	$0x0, 0x18(%rsp)
    6acc:      	je	0x6c2e <kprobe_unwind_ruby+0x6c2e>
    6ad2:      	movq	0x20(%rsp), %rax
    6ad7:      	testq	%rax, %rax
    6ada:      	je	0x6c2e <kprobe_unwind_ruby+0x6c2e>
    6ae0:      	movzbl	0x1f(%r15), %ecx
    6ae5:      	addq	%rcx, %rax
    6ae8:      	leaq	0x10(%rsp), %rdi
    6aed:      	movl	$0x8, %ecx
    6af2:      	movl	$0x70, %r8d
    6af8:      	movzbl	0x1f(%r15), %edx
    6afd:      	addq	0x20(%rsp), %rdx
    6b02:      	movl	$0x8, %esi
    6b07:      	callq	*%r8
    6b0a:      	testq	%rax, %rax
    6b0d:      	jne	0x4c7 <kprobe_unwind_ruby+0x4c7>
    6b13:      	movzbl	0x21(%r15), %eax
    6b18:      	addq	0x10(%rsp), %rax
    6b1d:      	leaq	0x68(%rsp), %rdi
    6b22:      	movl	$0x8, %ecx
    6b27:      	movl	$0x70, %r8d
    6b2d:      	movzbl	0x21(%r15), %edx
    6b32:      	addq	0x10(%rsp), %rdx
    6b37:      	movl	$0x8, %esi
    6b3c:      	callq	*%r8
    6b3f:      	testq	%rax, %rax
    6b42:      	jne	0x8a4 <kprobe_unwind_ruby+0x8a4>
    6b48:      	movzbl	0x22(%r15), %eax
    6b4d:      	addq	0x10(%rsp), %rax
    6b52:      	leaq	0x2c(%rsp), %rdi
    6b57:      	movl	$0x4, %ecx
    6b5c:      	movl	$0x70, %r8d
    6b62:      	movzbl	0x22(%r15), %edx
    6b67:      	addq	0x10(%rsp), %rdx
    6b6c:      	movl	$0x4, %esi
    6b71:      	callq	*%r8
    6b74:      	testq	%rax, %rax
    6b77:      	jne	0xc08 <kprobe_unwind_ruby+0xc08>
    6b7d:      	movzbl	0x23(%r15), %ecx
    6b82:      	testq	%rcx, %rcx
    6b85:      	je	0x6c8b <kprobe_unwind_ruby+0x6c8b>
    6b8b:      	movq	0x18(%rsp), %rax
    6b90:      	subq	0x68(%rsp), %rax
    6b95:      	xorl	%edx, %edx
    6b97:      	divq	%rcx
    6b9a:      	movl	0x2c(%rsp), %ecx
    6b9e:      	cmpq	%rcx, %rax
    6ba1:      	jbe	0x6c8b <kprobe_unwind_ruby+0x6c8b>
    6ba7:      	movq	(%rip), %rax            # 0x6bae <kprobe_unwind_ruby+0x6bae>
    6bae:      	cmpl	$0x0, (%rax)
    6bb1:      	je	0x6d9c <kprobe_unwind_ruby+0x6d9c>
    6bb7:      	movabsq	$0xa65636e657571, %rax  # imm = 0xA65636E657571
    6bc1:      	movq	%rax, 0x55(%rsp)
    6bc6:      	movabsq	$0x6575716573206e6f, %rax # imm = 0x6575716573206E6F
    6bd0:      	movq	%rax, 0x50(%rsp)
    6bd5:      	movabsq	$0x697463757274736e, %rax # imm = 0x697463757274736E
    6bdf:      	movq	%rax, 0x48(%rsp)
    6be4:      	movabsq	$0x692064696c61766e, %rax # imm = 0x692064696C61766E
    6bee:      	movq	%rax, 0x40(%rsp)
    6bf3:      	movabsq	$0x6920676e69707069, %rax # imm = 0x6920676E69707069
    6bfd:      	movq	%rax, 0x38(%rsp)
    6c02:      	movabsq	$0x6b73203a79627572, %rax # imm = 0x6B73203A79627572
    6c0c:      	movq	%rax, 0x30(%rsp)
    6c11:      	leaq	0x30(%rsp), %rdi
    6c16:      	movl	$0x2d, %eax
    6c1b:      	movl	$0x6, %ecx
    6c20:      	movl	$0x2d, %esi
    6c25:      	xorl	%eax, %eax
    6c27:      	callq	*%rcx
    6c29:      	jmp	0x6d9c <kprobe_unwind_ruby+0x6d9c>
    6c2e:      	cmpl	$0x20600, (%r15)        # imm = 0x20600
    6c35:      	jb	0x6d9c <kprobe_unwind_ruby+0x6d9c>
    6c3b:      	movq	$0x0, (%rsp)
    6c43:      	movzbl	0x1d(%r15), %eax
    6c48:      	addq	0x8(%rsp), %rax
    6c4d:      	movq	%rsp, %rdi
    6c50:      	movl	$0x8, %ecx
    6c55:      	movl	$0x70, %r8d
    6c5b:      	movzbl	0x1d(%r15), %edx
    6c60:      	addq	0x8(%rsp), %rdx
    6c65:      	movl	$0x8, %esi
    6c6a:      	callq	*%r8
    6c6d:      	testq	%rax, %rax
    6c70:      	jne	0x81b <kprobe_unwind_ruby+0x81b>
    6c76:      	movl	(%rsp), %eax
    6c79:      	notl	%eax
    6c7b:      	testl	$0x140, %eax            # imm = 0x140
    6c80:      	jne	0x997 <kprobe_unwind_ruby+0x997>
    6c86:      	jmp	0x6d9c <kprobe_unwind_ruby+0x6d9c>
    6c8b:      	movl	0x2c0(%r14), %eax
    6c92:      	cmpq	$0x7e, %rax
    6c96:      	ja	0xdd3 <kprobe_unwind_ruby+0xdd3>
    6c9c:      	movq	0x10(%rsp), %rcx
    6ca1:      	movq	0x18(%rsp), %rdx
    6ca6:      	leal	0x1(%rax), %esi
    6ca9:      	movl	%esi, 0x2c0(%r14)
    6cb0:      	leaq	(%rax,%rax,2), %rax
    6cb4:      	movw	$0x0, 0x4(%rsp)
    6cbb:      	movl	$0x0, (%rsp)
    6cc2:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    6cca:      	movq	%rdx, 0x2d8(%r14,%rax,8)
    6cd2:      	movw	$0x6, 0x2e0(%r14,%rax,8)
    6cdd:      	movl	(%rsp), %ecx
    6ce0:      	movl	%ecx, 0x2e2(%r14,%rax,8)
    6ce8:      	movzwl	0x4(%rsp), %ecx
    6ced:      	movw	%cx, 0x2e6(%r14,%rax,8)
    6cf6:      	movl	$0x36, (%rsp)
    6cfd:      	movq	(%rip), %rdi            # 0x6d04 <kprobe_unwind_ruby+0x6d04>
    6d04:      	movq	%rsp, %rsi
    6d07:      	movl	$0x1, %eax
    6d0c:      	callq	*%rax
    6d0e:      	testq	%rax, %rax
    6d11:      	je	0x6d1b <kprobe_unwind_ruby+0x6d1b>
    6d13:      	incq	(%rax)
    6d16:      	jmp	0x6d9c <kprobe_unwind_ruby+0x6d9c>
    6d1b:      	movq	(%rip), %rax            # 0x6d22 <kprobe_unwind_ruby+0x6d22>
    6d22:      	cmpl	$0x0, (%rax)
    6d25:      	je	0x6d9c <kprobe_unwind_ruby+0x6d9c>
    6d27:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    6d31:      	movq	%rax, 0x56(%rsp)
    6d36:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    6d40:      	movq	%rax, 0x50(%rsp)
    6d45:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    6d4f:      	movq	%rax, 0x48(%rsp)
    6d54:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    6d5e:      	movq	%rax, 0x40(%rsp)
    6d63:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    6d6d:      	movq	%rax, 0x38(%rsp)
    6d72:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6d7c:      	movq	%rax, 0x30(%rsp)
    6d81:      	leaq	0x30(%rsp), %rdi
    6d86:      	movl	$0x2e, %eax
    6d8b:      	movl	$0x6, %ecx
    6d90:      	movl	(%rsp), %edx
    6d93:      	movl	$0x2e, %esi
    6d98:      	xorl	%eax, %eax
    6d9a:      	callq	*%rcx
    6d9c:      	movq	0x8(%rsp), %rax
    6da1:      	cmpq	%rax, %r12
    6da4:      	jbe	0x2b2 <kprobe_unwind_ruby+0x2b2>
    6daa:      	movzbl	0x1e(%r15), %ecx
    6daf:      	addq	%rcx, %rax
    6db2:      	movq	%rax, 0x8(%rsp)
    6db7:      	movl	$0x6, %ebp
    6dbc:      	jmp	0x9ab <kprobe_unwind_ruby+0x9ab>
