
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/bcc/syscount.native.o:	file format elf64-x86-64

Disassembly of section tracepoint/raw_syscalls/sys_enter:

0000000000000000 <sys_enter>:
       0:      	pushq	%rbx
       1:      	subq	$0x10, %rsp
       5:      	callq	0xa <sys_enter+0xa>
       a:      	movq	%rax, %rbx
       d:      	movl	%ebx, 0x4(%rsp)
      11:      	movq	(%rip), %rax            # 0x18 <sys_enter+0x18>
      18:      	cmpb	$0x0, (%rax)
      1b:      	je	0x30 <sys_enter+0x30>
      1d:      	movq	(%rip), %rdi            # 0x24 <sys_enter+0x24>
      24:      	xorl	%esi, %esi
      26:      	callq	0x2b <sys_enter+0x2b>
      2b:      	testq	%rax, %rax
      2e:      	je	0x68 <sys_enter+0x68>
      30:      	movq	(%rip), %rax            # 0x37 <sys_enter+0x37>
      37:      	cmpl	$0x0, (%rax)
      3a:      	je	0x46 <sys_enter+0x46>
      3c:      	shrq	$0x20, %rbx
      40:      	movl	(%rax), %eax
      42:      	cmpl	%ebx, %eax
      44:      	jne	0x68 <sys_enter+0x68>
      46:      	callq	0x4b <sys_enter+0x4b>
      4b:      	movq	%rax, 0x8(%rsp)
      50:      	movq	(%rip), %rdi            # 0x57 <sys_enter+0x57>
      57:      	leaq	0x4(%rsp), %rsi
      5c:      	leaq	0x8(%rsp), %rdx
      61:      	xorl	%ecx, %ecx
      63:      	callq	0x68 <sys_enter+0x68>
      68:      	xorl	%eax, %eax
      6a:      	addq	$0x10, %rsp
      6e:      	popq	%rbx
      6f:      	retq

Disassembly of section tracepoint/raw_syscalls/sys_exit:

0000000000000000 <sys_exit>:
       0:      	pushq	%r15
       2:      	pushq	%r14
       4:      	pushq	%r13
       6:      	pushq	%r12
       8:      	pushq	%rbx
       9:      	subq	$0x10, %rsp
       d:      	movq	%rdi, %r14
      10:      	movq	(%rip), %rax            # 0x17 <sys_exit+0x17>
      17:      	cmpb	$0x0, (%rax)
      1a:      	je	0x33 <sys_exit+0x33>
      1c:      	movq	(%rip), %rdi            # 0x23 <sys_exit+0x23>
      23:      	xorl	%esi, %esi
      25:      	callq	0x2a <sys_exit+0x2a>
      2a:      	testq	%rax, %rax
      2d:      	je	0x19c <sys_exit+0x19c>
      33:      	callq	0x38 <sys_exit+0x38>
      38:      	movl	%eax, 0x4(%rsp)
      3c:      	cmpq	$-0x1, 0x8(%r14)
      41:      	je	0x19c <sys_exit+0x19c>
      47:      	movq	(%rip), %rcx            # 0x4e <sys_exit+0x4e>
      4e:      	cmpl	$0x0, (%rcx)
      51:      	je	0x64 <sys_exit+0x64>
      53:      	movq	%rax, %rdx
      56:      	shrq	$0x20, %rdx
      5a:      	movl	(%rcx), %ecx
      5c:      	cmpl	%edx, %ecx
      5e:      	jne	0x19c <sys_exit+0x19c>
      64:      	movq	(%rip), %rcx            # 0x6b <sys_exit+0x6b>
      6b:      	cmpb	$0x0, (%rcx)
      6e:      	je	0x7b <sys_exit+0x7b>
      70:      	cmpq	$0x0, 0x10(%r14)
      75:      	jns	0x19c <sys_exit+0x19c>
      7b:      	movq	(%rip), %rcx            # 0x82 <sys_exit+0x82>
      82:      	cmpl	$0x0, (%rcx)
      85:      	je	0x94 <sys_exit+0x94>
      87:      	movslq	(%rcx), %rcx
      8a:      	addq	0x10(%r14), %rcx
      8e:      	jne	0x19c <sys_exit+0x19c>
      94:      	movq	(%rip), %r12            # 0x9b <sys_exit+0x9b>
      9b:      	cmpb	$0x0, (%r12)
      a0:      	je	0xe3 <sys_exit+0xe3>
      a2:      	movq	(%rip), %rdi            # 0xa9 <sys_exit+0xa9>
      a9:      	leaq	0x4(%rsp), %rsi
      ae:      	movq	%rax, %r13
      b1:      	callq	0xb6 <sys_exit+0xb6>
      b6:      	testq	%rax, %rax
      b9:      	je	0x19c <sys_exit+0x19c>
      bf:      	movq	%rax, %r15
      c2:      	callq	0xc7 <sys_exit+0xc7>
      c7:      	movq	%rax, %rbx
      ca:      	movq	%r13, %rax
      cd:      	subq	(%r15), %rbx
      d0:      	movq	(%rip), %r15            # 0xd7 <sys_exit+0xd7>
      d7:      	cmpb	$0x0, (%r15)
      db:      	je	0xf2 <sys_exit+0xf2>
      dd:      	sarq	$0x20, %rax
      e1:      	jmp	0xf6 <sys_exit+0xf6>
      e3:      	xorl	%ebx, %ebx
      e5:      	movq	(%rip), %r15            # 0xec <sys_exit+0xec>
      ec:      	cmpb	$0x0, (%r15)
      f0:      	jne	0xdd <sys_exit+0xdd>
      f2:      	movq	0x8(%r14), %rax
      f6:      	movl	%eax, (%rsp)
      f9:      	movq	(%rip), %rdi            # 0x100 <sys_exit+0x100>
     100:      	movq	%rsp, %rsi
     103:      	callq	0x108 <sys_exit+0x108>
     108:      	movq	%rax, %r14
     10b:      	testq	%rax, %rax
     10e:      	je	0x15b <sys_exit+0x15b>
     110:      	lock
     111:      	incq	(%r14)
     114:      	cmpb	$0x0, (%r15)
     118:      	je	0x14d <sys_exit+0x14d>
     11a:      	callq	0x11f <sys_exit+0x11f>
     11f:      	leaq	0xb30(%rax), %rdx
     126:      	leaq	0x8(%rsp), %rdi
     12b:      	movl	$0x8, %esi
     130:      	callq	0x135 <sys_exit+0x135>
     135:      	leaq	0x10(%r14), %rdi
     139:      	movl	$0xd10, %edx            # imm = 0xD10
     13e:      	addq	0x8(%rsp), %rdx
     143:      	movl	$0x10, %esi
     148:      	callq	0x14d <sys_exit+0x14d>
     14d:      	cmpb	$0x0, (%r12)
     152:      	je	0x19c <sys_exit+0x19c>
     154:      	lock
     155:      	addq	%rbx, 0x8(%r14)
     159:      	jmp	0x19c <sys_exit+0x19c>
     15b:      	movq	(%rip), %rdi            # 0x162 <sys_exit+0x162>
     162:      	leaq	(%rip), %rdx            # 0x169 <sys_exit+0x169>
     169:      	movq	%rsp, %rsi
     16c:      	movl	$0x1, %ecx
     171:      	callq	0x176 <sys_exit+0x176>
     176:      	testq	%rax, %rax
     179:      	je	0x181 <sys_exit+0x181>
     17b:      	cmpq	$-0x11, %rax
     17f:      	jne	0x19c <sys_exit+0x19c>
     181:      	movq	(%rip), %rdi            # 0x188 <sys_exit+0x188>
     188:      	movq	%rsp, %rsi
     18b:      	callq	0x190 <sys_exit+0x190>
     190:      	movq	%rax, %r14
     193:      	testq	%rax, %rax
     196:      	jne	0x110 <sys_exit+0x110>
     19c:      	xorl	%eax, %eax
     19e:      	addq	$0x10, %rsp
     1a2:      	popq	%rbx
     1a3:      	popq	%r12
     1a5:      	popq	%r13
     1a7:      	popq	%r14
     1a9:      	popq	%r15
     1ab:      	retq
