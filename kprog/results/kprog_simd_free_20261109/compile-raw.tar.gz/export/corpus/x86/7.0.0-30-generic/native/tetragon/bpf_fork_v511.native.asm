
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_fork_v511.native.o:	file format elf64-x86-64

Disassembly of section kprobe/wake_up_new_task:

0000000000000000 <event_wake_up_new_task>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x128, %rsp            # imm = 0x128
      11:      	movq	0x70(%rdi), %r14
      15:      	testq	%r14, %r14
      18:      	je	0xf45 <event_wake_up_new_task+0xf45>
      1e:      	movq	%rdi, %rbx
      21:      	leaq	0xaf4(%r14), %rdx
      28:      	leaq	0x88(%rsp), %rdi
      30:      	movl	$0x4, %ecx
      35:      	movl	$0x4, %eax
      3a:      	movl	$0x4, %esi
      3f:      	callq	*%rax
      41:      	movl	0x88(%rsp), %ebp
      48:      	movq	%r14, 0x88(%rsp)
      50:      	leaq	0xb00(%r14), %rcx
      57:      	leaq	0x88(%rsp), %rdi
      5f:      	movl	$0x8, %edx
      64:      	movl	$0x71, %eax
      69:      	movl	$0xb00, %edx            # imm = 0xB00
      6e:      	addq	0x88(%rsp), %rdx
      76:      	movl	$0x8, %esi
      7b:      	callq	*%rax
      7d:      	movq	0x88(%rsp), %rcx
      85:      	testq	%rcx, %rcx
      88:      	je	0xf45 <event_wake_up_new_task+0xf45>
      8e:      	addq	$0xaf4, %rcx            # imm = 0xAF4
      95:      	leaq	0x18(%rsp), %rdi
      9a:      	movl	$0x4, %edx
      9f:      	movl	$0x71, %eax
      a4:      	movl	$0xaf4, %edx            # imm = 0xAF4
      a9:      	addq	0x88(%rsp), %rdx
      b1:      	movl	$0x4, %esi
      b6:      	callq	*%rax
      b8:      	movl	0x18(%rsp), %eax
      bc:      	movl	%eax, 0x48(%rsp)
      c0:      	movq	(%rip), %rdi            # 0xc7 <event_wake_up_new_task+0xc7>
      c7:      	leaq	0x48(%rsp), %rsi
      cc:      	movl	$0x1, %eax
      d1:      	callq	*%rax
      d3:      	testq	%rax, %rax
      d6:      	je	0xe6 <event_wake_up_new_task+0xe6>
      d8:      	movq	%rax, %r15
      db:      	cmpq	$0x0, 0x8(%rax)
      e0:      	jne	0x2b8 <event_wake_up_new_task+0x2b8>
      e6:      	movl	$0xb00, %edx            # imm = 0xB00
      eb:      	movq	0x88(%rsp), %rcx
      f3:      	addq	%rdx, %rcx
      f6:      	leaq	0x88(%rsp), %rdi
      fe:      	movl	$0x8, %esi
     103:      	movl	$0x71, %eax
     108:      	addq	0x88(%rsp), %rdx
     110:      	movl	$0x8, %esi
     115:      	callq	*%rax
     117:      	movq	0x88(%rsp), %rcx
     11f:      	testq	%rcx, %rcx
     122:      	je	0xf45 <event_wake_up_new_task+0xf45>
     128:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     12f:      	leaq	0x18(%rsp), %rdi
     134:      	movl	$0x4, %edx
     139:      	movl	$0x71, %eax
     13e:      	movl	$0xaf4, %edx            # imm = 0xAF4
     143:      	addq	0x88(%rsp), %rdx
     14b:      	movl	$0x4, %esi
     150:      	callq	*%rax
     152:      	movl	0x18(%rsp), %eax
     156:      	movl	%eax, 0x48(%rsp)
     15a:      	movq	(%rip), %rdi            # 0x161 <event_wake_up_new_task+0x161>
     161:      	leaq	0x48(%rsp), %rsi
     166:      	movl	$0x1, %eax
     16b:      	callq	*%rax
     16d:      	testq	%rax, %rax
     170:      	je	0x180 <event_wake_up_new_task+0x180>
     172:      	movq	%rax, %r15
     175:      	cmpq	$0x0, 0x8(%rax)
     17a:      	jne	0x2b8 <event_wake_up_new_task+0x2b8>
     180:      	movl	$0xb00, %edx            # imm = 0xB00
     185:      	movq	0x88(%rsp), %rcx
     18d:      	addq	%rdx, %rcx
     190:      	leaq	0x88(%rsp), %rdi
     198:      	movl	$0x8, %esi
     19d:      	movl	$0x71, %eax
     1a2:      	addq	0x88(%rsp), %rdx
     1aa:      	movl	$0x8, %esi
     1af:      	callq	*%rax
     1b1:      	movq	0x88(%rsp), %rcx
     1b9:      	testq	%rcx, %rcx
     1bc:      	je	0xf45 <event_wake_up_new_task+0xf45>
     1c2:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     1c9:      	leaq	0x18(%rsp), %rdi
     1ce:      	movl	$0x4, %edx
     1d3:      	movl	$0x71, %eax
     1d8:      	movl	$0xaf4, %edx            # imm = 0xAF4
     1dd:      	addq	0x88(%rsp), %rdx
     1e5:      	movl	$0x4, %esi
     1ea:      	callq	*%rax
     1ec:      	movl	0x18(%rsp), %eax
     1f0:      	movl	%eax, 0x48(%rsp)
     1f4:      	movq	(%rip), %rdi            # 0x1fb <event_wake_up_new_task+0x1fb>
     1fb:      	leaq	0x48(%rsp), %rsi
     200:      	movl	$0x1, %eax
     205:      	callq	*%rax
     207:      	testq	%rax, %rax
     20a:      	je	0x21a <event_wake_up_new_task+0x21a>
     20c:      	movq	%rax, %r15
     20f:      	cmpq	$0x0, 0x8(%rax)
     214:      	jne	0x2b8 <event_wake_up_new_task+0x2b8>
     21a:      	movl	$0xb00, %edx            # imm = 0xB00
     21f:      	movq	0x88(%rsp), %rcx
     227:      	addq	%rdx, %rcx
     22a:      	leaq	0x88(%rsp), %rdi
     232:      	movl	$0x8, %esi
     237:      	movl	$0x71, %eax
     23c:      	addq	0x88(%rsp), %rdx
     244:      	movl	$0x8, %esi
     249:      	callq	*%rax
     24b:      	movq	0x88(%rsp), %rcx
     253:      	testq	%rcx, %rcx
     256:      	je	0xf45 <event_wake_up_new_task+0xf45>
     25c:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     263:      	leaq	0x18(%rsp), %rdi
     268:      	movl	$0x4, %edx
     26d:      	movl	$0x71, %eax
     272:      	movl	$0xaf4, %edx            # imm = 0xAF4
     277:      	addq	0x88(%rsp), %rdx
     27f:      	movl	$0x4, %esi
     284:      	callq	*%rax
     286:      	movl	0x18(%rsp), %eax
     28a:      	movl	%eax, 0x48(%rsp)
     28e:      	movq	(%rip), %rdi            # 0x295 <event_wake_up_new_task+0x295>
     295:      	leaq	0x48(%rsp), %rsi
     29a:      	movl	$0x1, %eax
     29f:      	callq	*%rax
     2a1:      	testq	%rax, %rax
     2a4:      	je	0xf45 <event_wake_up_new_task+0xf45>
     2aa:      	movq	%rax, %r15
     2ad:      	cmpq	$0x0, 0x8(%rax)
     2b2:      	je	0xf45 <event_wake_up_new_task+0xf45>
     2b8:      	movl	%ebp, 0x48(%rsp)
     2bc:      	movq	(%rip), %rdi            # 0x2c3 <event_wake_up_new_task+0x2c3>
     2c3:      	leaq	0x48(%rsp), %rsi
     2c8:      	movl	$0x1, %eax
     2cd:      	callq	*%rax
     2cf:      	testq	%rax, %rax
     2d2:      	je	0x5e1 <event_wake_up_new_task+0x5e1>
     2d8:      	movq	%rax, %r12
     2db:      	cmpq	$0x0, 0x8(%r12)
     2e1:      	jne	0xf45 <event_wake_up_new_task+0xf45>
     2e7:      	movl	$0x1, 0x20(%r12)
     2f0:      	movl	%ebp, (%r12)
     2f4:      	movl	$0x7d, %eax
     2f9:      	callq	*%rax
     2fb:      	movq	%rax, 0x8(%r12)
     300:      	leaq	0x60(%r14), %rdx
     304:      	leaq	0x48(%rsp), %rdi
     309:      	movl	$0x8, %ecx
     30e:      	movl	$0x71, %eax
     313:      	movl	$0x8, %esi
     318:      	callq	*%rax
     31a:      	movq	0x48(%rsp), %rcx
     31f:      	xorl	%ebp, %ebp
     321:      	testq	%rcx, %rcx
     324:      	je	0x399 <event_wake_up_new_task+0x399>
     326:      	addq	$0x4, %rcx
     32a:      	leaq	0x18(%rsp), %rdi
     32f:      	movl	$0x4, %edx
     334:      	movl	$0x71, %eax
     339:      	movq	0x48(%rsp), %rdx
     33e:      	addq	$0x4, %rdx
     342:      	movl	$0x4, %esi
     347:      	callq	*%rax
     349:      	movl	0x18(%rsp), %eax
     34d:      	testl	%eax, %eax
     34f:      	je	0x399 <event_wake_up_new_task+0x399>
     351:      	movq	0x48(%rsp), %rcx
     356:      	shll	$0x4, %eax
     359:      	addq	%rax, %rcx
     35c:      	addq	$0x80, %rcx
     363:      	leaq	0x88(%rsp), %rdi
     36b:      	movl	$0x10, %edx
     370:      	movl	$0x71, %eax
     375:      	movq	0x48(%rsp), %rcx
     37a:      	movl	0x18(%rsp), %edx
     37e:      	shll	$0x4, %edx
     381:      	addq	%rcx, %rdx
     384:      	addq	$0x80, %rdx
     38b:      	movl	$0x10, %esi
     390:      	callq	*%rax
     392:      	movl	0x88(%rsp), %ebp
     399:      	movl	%ebp, 0x24(%r12)
     39e:      	leaq	0x68(%r12), %rdi
     3a3:      	leaq	0x68(%r15), %rsi
     3a7:      	movl	$0x318, %edx            # imm = 0x318
     3ac:      	callq	0x3b1 <event_wake_up_new_task+0x3b1>
     3b1:      	movq	(%r15), %rax
     3b4:      	movq	0x8(%r15), %rcx
     3b8:      	movq	%rax, 0x10(%r12)
     3bd:      	movq	%rcx, 0x18(%r12)
     3c2:      	leaq	0xd00(%r14), %rdx
     3c9:      	leaq	0x88(%rsp), %rdi
     3d1:      	movl	$0x8, %ecx
     3d6:      	movl	$0x4, %eax
     3db:      	leaq	0x50(%r12), %rbp
     3e0:      	movl	$0x8, %esi
     3e5:      	movq	%rdx, 0x120(%rsp)
     3ed:      	callq	*%rax
     3ef:      	movq	0x88(%rsp), %r13
     3f7:      	leaq	0x58(%r12), %rdi
     3fc:      	leaq	0x40(%r13), %rdx
     400:      	movl	$0x8, %ecx
     405:      	movl	$0x4, %eax
     40a:      	movl	$0x8, %esi
     40f:      	callq	*%rax
     411:      	leaq	0x60(%r12), %rdi
     416:      	leaq	0x30(%r13), %rdx
     41a:      	movl	$0x8, %ecx
     41f:      	movl	$0x4, %eax
     424:      	movl	$0x8, %esi
     429:      	callq	*%rax
     42b:      	addq	$0x38, %r13
     42f:      	movl	$0x8, %ecx
     434:      	movl	$0x4, %eax
     439:      	movq	%rbp, %rdi
     43c:      	movl	$0x8, %esi
     441:      	movq	%r13, %rdx
     444:      	callq	*%rax
     446:      	leaq	0x28(%r12), %rbp
     44b:      	leaq	0xd70(%r14), %rdx
     452:      	leaq	0x18(%rsp), %rdi
     457:      	movl	$0x8, %ecx
     45c:      	movl	$0x4, %eax
     461:      	movl	$0x8, %esi
     466:      	callq	*%rax
     468:      	movq	0x18(%rsp), %rcx
     46d:      	leaq	0x88(%rsp), %rdi
     475:      	movl	$0x48, %edx
     47a:      	movl	$0x4, %eax
     47f:      	movq	0x18(%rsp), %rdx
     484:      	movl	$0x48, %esi
     489:      	callq	*%rax
     48b:      	movl	$0x218, %edx            # imm = 0x218
     490:      	movq	0x90(%rsp), %rcx
     498:      	addq	%rdx, %rcx
     49b:      	movl	$0x4, %esi
     4a0:      	movl	$0x4, %eax
     4a5:      	addq	0x90(%rsp), %rdx
     4ad:      	movq	%rbp, %rdi
     4b0:      	movl	$0x4, %esi
     4b5:      	callq	*%rax
     4b7:      	leaq	0x2c(%r12), %rdi
     4bc:      	movl	$0x4d8, %edx            # imm = 0x4D8
     4c1:      	movq	0x98(%rsp), %rcx
     4c9:      	addq	%rdx, %rcx
     4cc:      	movl	$0x4, %esi
     4d1:      	movl	$0x4, %eax
     4d6:      	addq	0x98(%rsp), %rdx
     4de:      	movl	$0x4, %esi
     4e3:      	callq	*%rax
     4e5:      	leaq	0x30(%r12), %rdi
     4ea:      	movq	0xa0(%rsp), %rcx
     4f2:      	addq	$0x58, %rcx
     4f6:      	movl	$0x4, %edx
     4fb:      	movl	$0x4, %eax
     500:      	movq	0xa0(%rsp), %rdx
     508:      	addq	$0x58, %rdx
     50c:      	movl	$0x4, %esi
     511:      	callq	*%rax
     513:      	movq	$0x0, 0x8(%rsp)
     51c:      	leaq	0xb58(%r14), %rdx
     523:      	leaq	0x8(%rsp), %rdi
     528:      	movl	$0x8, %ecx
     52d:      	movl	$0x4, %eax
     532:      	movl	$0x8, %esi
     537:      	callq	*%rax
     539:      	movq	0x8(%rsp), %rcx
     53e:      	testq	%rcx, %rcx
     541:      	je	0x687 <event_wake_up_new_task+0x687>
     547:      	movl	$0x0, 0x10(%rsp)
     54f:      	addq	$0x4, %rcx
     553:      	leaq	0x10(%rsp), %rdi
     558:      	movl	$0x4, %eax
     55d:      	movl	$0x4, %r13d
     563:      	movq	0x8(%rsp), %rdx
     568:      	addq	$0x4, %rdx
     56c:      	movl	$0x4, %esi
     571:      	callq	*%rax
     573:      	movq	0x8(%rsp), %rax
     578:      	movslq	0x10(%rsp), %rcx
     57d:      	shlq	$0x4, %rcx
     581:      	addq	%rax, %rcx
     584:      	addq	$0x80, %rcx
     58b:      	leaq	0x48(%rsp), %rdi
     590:      	movl	$0x10, %edx
     595:      	movl	$0x4, %eax
     59a:      	movq	0x8(%rsp), %rcx
     59f:      	movslq	0x10(%rsp), %rdx
     5a4:      	shlq	$0x4, %rdx
     5a8:      	addq	%rcx, %rdx
     5ab:      	addq	$0x80, %rdx
     5b2:      	movl	$0x10, %esi
     5b7:      	callq	*%rax
     5b9:      	leaq	0x34(%r12), %rdi
     5be:      	movl	$0x158, %edx            # imm = 0x158
     5c3:      	movq	0x50(%rsp), %rcx
     5c8:      	addq	%rdx, %rcx
     5cb:      	movl	$0x4, %eax
     5d0:      	addq	0x50(%rsp), %rdx
     5d5:      	movl	$0x4, %esi
     5da:      	callq	*%rax
     5dc:      	jmp	0x690 <event_wake_up_new_task+0x690>
     5e1:      	movl	$0x0, 0x18(%rsp)
     5e9:      	movq	(%rip), %rdi            # 0x5f0 <event_wake_up_new_task+0x5f0>
     5f0:      	leaq	0x18(%rsp), %rsi
     5f5:      	movl	$0x1, %eax
     5fa:      	callq	*%rax
     5fc:      	testq	%rax, %rax
     5ff:      	je	0xf45 <event_wake_up_new_task+0xf45>
     605:      	xorl	%r13d, %r13d
     608:      	movl	$0x380, %edx            # imm = 0x380
     60d:      	movq	%rax, %rdi
     610:      	xorl	%esi, %esi
     612:      	movq	%rax, %r12
     615:      	callq	0x61a <event_wake_up_new_task+0x61a>
     61a:      	movq	(%rip), %rdi            # 0x621 <event_wake_up_new_task+0x621>
     621:      	leaq	0x48(%rsp), %rsi
     626:      	movl	$0x2, %eax
     62b:      	movq	%r12, %rdx
     62e:      	xorl	%ecx, %ecx
     630:      	callq	*%rax
     632:      	testl	%eax, %eax
     634:      	je	0xa0a <event_wake_up_new_task+0xa0a>
     63a:      	movl	$0x1, 0x88(%rsp)
     645:      	movq	(%rip), %rdi            # 0x64c <event_wake_up_new_task+0x64c>
     64c:      	leaq	0x88(%rsp), %rsi
     654:      	movl	$0x1, %eax
     659:      	callq	*%rax
     65b:      	testq	%rax, %rax
     65e:      	je	0x663 <event_wake_up_new_task+0x663>
     660:      	incq	(%rax)
     663:      	movq	(%rip), %rdi            # 0x66a <event_wake_up_new_task+0x66a>
     66a:      	leaq	0x48(%rsp), %rsi
     66f:      	movl	$0x1, %eax
     674:      	callq	*%rax
     676:      	movq	%rax, %r12
     679:      	testq	%rax, %rax
     67c:      	jne	0x2db <event_wake_up_new_task+0x2db>
     682:      	jmp	0xf45 <event_wake_up_new_task+0xf45>
     687:      	movl	$0x0, 0x34(%r12)
     690:      	leaq	0x38(%r12), %rdi
     695:      	movl	$0x158, %ebp            # imm = 0x158
     69a:      	movq	0xa8(%rsp), %rcx
     6a2:      	addq	%rbp, %rcx
     6a5:      	movl	$0x4, %edx
     6aa:      	movl	$0x4, %eax
     6af:      	leaq	0x10(%r12), %rcx
     6b4:      	movq	%rcx, 0x118(%rsp)
     6bc:      	movq	0xa8(%rsp), %rdx
     6c4:      	addq	%rbp, %rdx
     6c7:      	movl	$0x4, %esi
     6cc:      	callq	*%rax
     6ce:      	leaq	0x3c(%r12), %rdi
     6d3:      	movl	$0x118, %edx            # imm = 0x118
     6d8:      	movq	0xb0(%rsp), %rcx
     6e0:      	addq	%rdx, %rcx
     6e3:      	movl	$0x4, %esi
     6e8:      	movl	$0x4, %eax
     6ed:      	addq	0xb0(%rsp), %rdx
     6f5:      	movl	$0x4, %esi
     6fa:      	callq	*%rax
     6fc:      	leaq	0x40(%r12), %rdi
     701:      	movl	$0x98, %r13d
     707:      	movq	0xb8(%rsp), %rcx
     70f:      	addq	%r13, %rcx
     712:      	movl	$0x4, %edx
     717:      	movl	$0x4, %eax
     71c:      	movq	0xb8(%rsp), %rdx
     724:      	addq	%r13, %rdx
     727:      	movl	$0x4, %esi
     72c:      	callq	*%rax
     72e:      	leaq	0x44(%r12), %rdi
     733:      	movq	0xc0(%rsp), %rcx
     73b:      	addq	%r13, %rcx
     73e:      	movl	$0x4, %edx
     743:      	movl	$0x4, %eax
     748:      	addq	0xc0(%rsp), %r13
     750:      	movl	$0x4, %esi
     755:      	movq	%r13, %rdx
     758:      	callq	*%rax
     75a:      	leaq	0x48(%r12), %rdi
     75f:      	movq	0xc8(%rsp), %rcx
     767:      	addq	$0x58, %rcx
     76b:      	movl	$0x4, %edx
     770:      	movl	$0x4, %eax
     775:      	movq	0xc8(%rsp), %rdx
     77d:      	addq	$0x58, %rdx
     781:      	movl	$0x4, %esi
     786:      	callq	*%rax
     788:      	movq	$0x0, 0x48(%rsp)
     791:      	movq	$0x0, 0x8(%rsp)
     79a:      	leaq	0x48(%rsp), %rdi
     79f:      	movl	$0x8, %ecx
     7a4:      	movl	$0x4, %eax
     7a9:      	movq	0x120(%rsp), %rdx
     7b1:      	movl	$0x8, %esi
     7b6:      	callq	*%rax
     7b8:      	movl	$0x90, %edx
     7bd:      	movq	0x48(%rsp), %rcx
     7c2:      	addq	%rdx, %rcx
     7c5:      	leaq	0x8(%rsp), %rdi
     7ca:      	movl	$0x8, %esi
     7cf:      	movl	$0x4, %eax
     7d4:      	addq	0x48(%rsp), %rdx
     7d9:      	movl	$0x8, %esi
     7de:      	callq	*%rax
     7e0:      	leaq	0x4c(%r12), %rdi
     7e5:      	movq	0x8(%rsp), %rcx
     7ea:      	addq	%rbp, %rcx
     7ed:      	movl	$0x4, %edx
     7f2:      	movl	$0x4, %eax
     7f7:      	addq	0x8(%rsp), %rbp
     7fc:      	movl	$0x4, %esi
     801:      	movq	%rbp, %rdx
     804:      	callq	*%rax
     806:      	testb	$0x2, 0x23(%r15)
     80b:      	jne	0x815 <event_wake_up_new_task+0x815>
     80d:      	cmpl	$0x1, 0x24(%r12)
     813:      	jne	0x81b <event_wake_up_new_task+0x81b>
     815:      	orb	$0x2, 0x23(%r12)
     81b:      	movb	$0x17, 0x48(%rsp)
     820:      	movl	$0x38, 0x4c(%rsp)
     828:      	movq	0x8(%r12), %rax
     82d:      	movq	%rax, 0x50(%rsp)
     832:      	movq	0x118(%rsp), %rcx
     83a:      	movq	(%rcx), %rax
     83d:      	movq	0x8(%rcx), %rcx
     841:      	movq	%rax, 0x58(%rsp)
     846:      	movq	%rcx, 0x60(%rsp)
     84b:      	movl	(%r12), %eax
     84f:      	movl	%eax, 0x68(%rsp)
     853:      	leaq	0xaf0(%r14), %rdx
     85a:      	leaq	0x88(%rsp), %rdi
     862:      	movl	$0x4, %ecx
     867:      	movl	$0x4, %eax
     86c:      	movl	$0x4, %esi
     871:      	callq	*%rax
     873:      	movl	0x88(%rsp), %eax
     87a:      	movl	%eax, 0x6c(%rsp)
     87e:      	movq	0x8(%r12), %rax
     883:      	movq	%rax, 0x78(%rsp)
     888:      	movl	0x24(%r12), %eax
     88d:      	movl	%eax, 0x70(%rsp)
     891:      	movl	0x20(%r12), %eax
     896:      	movl	%eax, 0x74(%rsp)
     89a:      	movl	$0x0, 0x44(%rsp)
     8a2:      	leaq	0x88(%rsp), %rdi
     8aa:      	xorl	%r12d, %r12d
     8ad:      	movl	$0x90, %edx
     8b2:      	xorl	%esi, %esi
     8b4:      	callq	0x8b9 <event_wake_up_new_task+0x8b9>
     8b9:      	movq	(%rip), %rdi            # 0x8c0 <event_wake_up_new_task+0x8c0>
     8c0:      	leaq	0x44(%rsp), %rsi
     8c5:      	movl	$0x1, %eax
     8ca:      	callq	*%rax
     8cc:      	testq	%rax, %rax
     8cf:      	je	0x8db <event_wake_up_new_task+0x8db>
     8d1:      	movq	0x20(%rax), %r15
     8d5:      	movl	0x10(%rax), %r12d
     8d9:      	jmp	0x8de <event_wake_up_new_task+0x8de>
     8db:      	xorl	%r15d, %r15d
     8de:      	movq	$0x0, 0x10(%rsp)
     8e7:      	addq	$0xf90, %r14            # imm = 0xF90
     8ee:      	leaq	0x8(%rsp), %rdi
     8f3:      	movl	$0x8, %ecx
     8f8:      	movl	$0x71, %eax
     8fd:      	movl	$0x8, %esi
     902:      	movq	%r14, %rdx
     905:      	callq	*%rax
     907:      	movq	0x8(%rsp), %rcx
     90c:      	testq	%rcx, %rcx
     90f:      	je	0x98d <event_wake_up_new_task+0x98d>
     911:      	cmpq	$0x63677270, %r15       # imm = 0x63677270
     918:      	jne	0x93c <event_wake_up_new_task+0x93c>
     91a:      	addq	$0x88, %rcx
     921:      	leaq	0x10(%rsp), %rdi
     926:      	movl	$0x8, %edx
     92b:      	movl	$0x71, %eax
     930:      	movl	$0x88, %edx
     935:      	addq	0x8(%rsp), %rdx
     93a:      	jmp	0x986 <event_wake_up_new_task+0x986>
     93c:      	cmpl	$0xb, %r12d
     940:      	ja	0x98d <event_wake_up_new_task+0x98d>
     942:      	movl	%r12d, %edx
     945:      	leaq	(%rcx,%rdx,8), %rcx
     949:      	leaq	0x18(%rsp), %rdi
     94e:      	movl	$0x8, %esi
     953:      	movl	$0x71, %eax
     958:      	shlq	$0x3, %rdx
     95c:      	addq	0x8(%rsp), %rdx
     961:      	movl	$0x8, %esi
     966:      	callq	*%rax
     968:      	movq	0x18(%rsp), %rcx
     96d:      	testq	%rcx, %rcx
     970:      	je	0x98d <event_wake_up_new_task+0x98d>
     972:      	leaq	0x10(%rsp), %rdi
     977:      	movl	$0x8, %edx
     97c:      	movl	$0x71, %eax
     981:      	movq	0x18(%rsp), %rdx
     986:      	movl	$0x8, %esi
     98b:      	callq	*%rax
     98d:      	movq	0x10(%rsp), %r14
     992:      	testq	%r14, %r14
     995:      	je	0xae4 <event_wake_up_new_task+0xae4>
     99b:      	cmpq	$0x63677270, %r15       # imm = 0x63677270
     9a2:      	jne	0x9b0 <event_wake_up_new_task+0x9b0>
     9a4:      	movl	$0x50, %eax
     9a9:      	callq	*%rax
     9ab:      	jmp	0xa3b <event_wake_up_new_task+0xa3b>
     9b0:      	movq	$0x0, 0x18(%rsp)
     9b9:      	leaq	0x100(%r14), %rdx
     9c0:      	leaq	0x18(%rsp), %rdi
     9c5:      	movl	$0x8, %ecx
     9ca:      	movl	$0x71, %eax
     9cf:      	movl	$0x8, %esi
     9d4:      	callq	*%rax
     9d6:      	movq	0x18(%rsp), %rdx
     9db:      	movq	$0x0, 0x18(%rsp)
     9e4:      	testq	%rdx, %rdx
     9e7:      	je	0xa39 <event_wake_up_new_task+0xa39>
     9e9:      	addq	$0x60, %rdx
     9ed:      	leaq	0x18(%rsp), %rdi
     9f2:      	movl	$0x8, %ecx
     9f7:      	movl	$0x71, %eax
     9fc:      	movl	$0x8, %esi
     a01:      	callq	*%rax
     a03:      	movq	0x18(%rsp), %rax
     a08:      	jmp	0xa3b <event_wake_up_new_task+0xa3b>
     a0a:      	movl	$0x0, 0x88(%rsp)
     a15:      	movq	(%rip), %rdi            # 0xa1c <event_wake_up_new_task+0xa1c>
     a1c:      	leaq	0x88(%rsp), %rsi
     a24:      	movl	$0x1, %eax
     a29:      	callq	*%rax
     a2b:      	testq	%rax, %rax
     a2e:      	jne	0x660 <event_wake_up_new_task+0x660>
     a34:      	jmp	0x663 <event_wake_up_new_task+0x663>
     a39:      	xorl	%eax, %eax
     a3b:      	movq	%rax, 0x88(%rsp)
     a43:      	testq	%rax, %rax
     a46:      	je	0xa74 <event_wake_up_new_task+0xa74>
     a48:      	movq	%rax, 0x18(%rsp)
     a4d:      	movq	(%rip), %rdi            # 0xa54 <event_wake_up_new_task+0xa54>
     a54:      	leaq	0x18(%rsp), %rsi
     a59:      	movl	$0x1, %eax
     a5e:      	callq	*%rax
     a60:      	testq	%rax, %rax
     a63:      	je	0xa6a <event_wake_up_new_task+0xa6a>
     a65:      	movq	(%rax), %rax
     a68:      	jmp	0xa6c <event_wake_up_new_task+0xa6c>
     a6a:      	xorl	%eax, %eax
     a6c:      	movq	%rax, 0x90(%rsp)
     a74:      	addq	$0x100, %r14            # imm = 0x100
     a7b:      	leaq	0x8(%rsp), %rdi
     a80:      	movl	$0x8, %ecx
     a85:      	movl	$0x4, %eax
     a8a:      	movl	$0x8, %esi
     a8f:      	movq	%r14, %rdx
     a92:      	callq	*%rax
     a94:      	movq	0x8(%rsp), %rcx
     a99:      	addq	$0x10, %rcx
     a9d:      	leaq	0x18(%rsp), %rdi
     aa2:      	movl	$0x8, %edx
     aa7:      	movl	$0x4, %eax
     aac:      	movq	0x8(%rsp), %rdx
     ab1:      	addq	$0x10, %rdx
     ab5:      	movl	$0x8, %esi
     aba:      	callq	*%rax
     abc:      	testq	%rax, %rax
     abf:      	jne	0xae4 <event_wake_up_new_task+0xae4>
     ac1:      	movq	0x18(%rsp), %rdx
     ac6:      	testq	%rdx, %rdx
     ac9:      	je	0xae4 <event_wake_up_new_task+0xae4>
     acb:      	leaq	0x98(%rsp), %rdi
     ad3:      	movl	$0x80, %ecx
     ad8:      	movl	$0x2d, %eax
     add:      	movl	$0x80, %esi
     ae2:      	callq	*%rax
     ae4:      	movq	0x78(%rsp), %r15
     ae9:      	movq	0x88(%rsp), %rax
     af1:      	movq	%rax, 0x8(%rsp)
     af6:      	movl	$0x0, 0x80(%rsp)
     b01:      	movq	(%rip), %rdi            # 0xb08 <event_wake_up_new_task+0xb08>
     b08:      	leaq	0x80(%rsp), %rsi
     b10:      	movl	$0x1, %eax
     b15:      	callq	*%rax
     b17:      	testq	%rax, %rax
     b1a:      	je	0xdea <event_wake_up_new_task+0xdea>
     b20:      	movq	0x8(%rax), %r12
     b24:      	testq	%r12, %r12
     b27:      	je	0xdea <event_wake_up_new_task+0xdea>
     b2d:      	movq	%rax, %r13
     b30:      	movq	(%rip), %rdi            # 0xb37 <event_wake_up_new_task+0xb37>
     b37:      	leaq	0x8(%rsp), %rsi
     b3c:      	movl	$0x1, %eax
     b41:      	callq	*%rax
     b43:      	testq	%rax, %rax
     b46:      	je	0xb79 <event_wake_up_new_task+0xb79>
     b48:      	movq	%rax, %r14
     b4b:      	movq	0x10(%rax), %rax
     b4f:      	movq	%r15, %rcx
     b52:      	subq	%rax, %rcx
     b55:      	cmpq	%r12, %rcx
     b58:      	jbe	0xbcf <event_wake_up_new_task+0xbcf>
     b5a:      	leaq	(%r12,%r12), %rdx
     b5e:      	cmpq	%rdx, %rcx
     b61:      	jbe	0xbd4 <event_wake_up_new_task+0xbd4>
     b63:      	movq	$0x0, 0x8(%r14)
     b6b:      	movq	%r15, %rax
     b6e:      	xorl	%edx, %edx
     b70:      	divq	%r12
     b73:      	imulq	%r12, %rax
     b77:      	jmp	0xbde <event_wake_up_new_task+0xbde>
     b79:      	movq	$0x1, 0x18(%rsp)
     b82:      	movq	$0x0, 0x20(%rsp)
     b8b:      	movq	%r15, %rax
     b8e:      	xorl	%edx, %edx
     b90:      	divq	%r12
     b93:      	imulq	%r12, %rax
     b97:      	movq	%rax, 0x28(%rsp)
     b9c:      	movq	$0x0, 0x30(%rsp)
     ba5:      	movq	$0x0, 0x38(%rsp)
     bae:      	movq	(%rip), %rdi            # 0xbb5 <event_wake_up_new_task+0xbb5>
     bb5:      	xorl	%ecx, %ecx
     bb7:      	leaq	0x8(%rsp), %rsi
     bbc:      	leaq	0x18(%rsp), %rdx
     bc1:      	movl	$0x2, %eax
     bc6:      	xorl	%ecx, %ecx
     bc8:      	callq	*%rax
     bca:      	jmp	0xdea <event_wake_up_new_task+0xdea>
     bcf:      	movq	(%r14), %rcx
     bd2:      	jmp	0xbe4 <event_wake_up_new_task+0xbe4>
     bd4:      	movq	(%r14), %rcx
     bd7:      	movq	%rcx, 0x8(%r14)
     bdb:      	addq	%r12, %rax
     bde:      	movq	%rax, 0x10(%r14)
     be2:      	xorl	%ecx, %ecx
     be4:      	incq	%rcx
     be7:      	movq	%rcx, (%r14)
     bea:      	movq	%r12, %rcx
     bed:      	subq	%r15, %rcx
     bf0:      	addq	%rax, %rcx
     bf3:      	imulq	0x8(%r14), %rcx
     bf8:      	movq	%rcx, %rax
     bfb:      	xorl	%edx, %edx
     bfd:      	divq	%r12
     c00:      	addq	(%r14), %rax
     c03:      	movq	%rax, 0x18(%r14)
     c07:      	cmpq	$0x0, 0x20(%r14)
     c0c:      	jne	0xf45 <event_wake_up_new_task+0xf45>
     c12:      	cmpq	(%r13), %rax
     c16:      	jb	0xdea <event_wake_up_new_task+0xdea>
     c1c:      	movq	%r15, 0x20(%r14)
     c20:      	movl	$0x0, 0x44(%rsp)
     c28:      	movq	(%rip), %rdi            # 0xc2f <event_wake_up_new_task+0xc2f>
     c2f:      	leaq	0x44(%rsp), %rcx
     c34:      	movl	$0x1, %eax
     c39:      	movl	$0x0, 0x84(%rsp)
     c44:      	leaq	0x84(%rsp), %rsi
     c4c:      	callq	*%rax
     c4e:      	testq	%rax, %rax
     c51:      	je	0xddf <event_wake_up_new_task+0xddf>
     c57:      	movq	%rax, %r12
     c5a:      	movl	$0xa0, 0x4(%rax)
     c61:      	movq	%r15, 0x8(%rax)
     c65:      	movw	$0x1b, (%rax)
     c6a:      	movq	%rax, %rdi
     c6d:      	addq	$0x10, %rdi
     c71:      	leaq	0x88(%rsp), %rsi
     c79:      	movl	$0x90, %edx
     c7e:      	callq	0xc83 <event_wake_up_new_task+0xc83>
     c83:      	movl	$0x0, 0x10(%rsp)
     c8b:      	movq	(%rip), %rdi            # 0xc92 <event_wake_up_new_task+0xc92>
     c92:      	leaq	0x10(%rsp), %rsi
     c97:      	movl	$0x1, %eax
     c9c:      	callq	*%rax
     c9e:      	testq	%rax, %rax
     ca1:      	je	0xd2b <event_wake_up_new_task+0xd2b>
     ca7:      	cmpb	$0x0, 0x28(%rax)
     cab:      	je	0xd2b <event_wake_up_new_task+0xd2b>
     cad:      	movq	(%rip), %rsi            # 0xcb4 <event_wake_up_new_task+0xcb4>
     cb4:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     cb9:      	movl	$0xa0, %edx
     cbe:      	movl	$0x19, %eax
     cc3:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     cc8:      	movl	$0xa0, %r8d
     cce:      	movq	%rbx, %rdi
     cd1:      	movq	%r12, %rcx
     cd4:      	callq	*%rax
     cd6:      	testq	%rax, %rax
     cd9:      	jns	0xddf <event_wake_up_new_task+0xddf>
     cdf:      	movq	%rax, %r15
     ce2:      	movl	$0x0, 0x18(%rsp)
     cea:      	movq	(%rip), %rdi            # 0xcf1 <event_wake_up_new_task+0xcf1>
     cf1:      	leaq	0x18(%rsp), %rsi
     cf6:      	movl	$0x1, %eax
     cfb:      	callq	*%rax
     cfd:      	testq	%rax, %rax
     d00:      	je	0xddf <event_wake_up_new_task+0xddf>
     d06:      	cmpq	$-0xc, %r15
     d0a:      	jg	0xdab <event_wake_up_new_task+0xdab>
     d10:      	cmpq	$-0x1c, %r15
     d14:      	je	0xdc5 <event_wake_up_new_task+0xdc5>
     d1a:      	cmpq	$-0x16, %r15
     d1e:      	jne	0xd83 <event_wake_up_new_task+0xd83>
     d20:      	addq	$0x608, %rax            # imm = 0x608
     d26:      	jmp	0xddb <event_wake_up_new_task+0xddb>
     d2b:      	movq	(%rip), %rdi            # 0xd32 <event_wake_up_new_task+0xd32>
     d32:      	xorl	%ecx, %ecx
     d34:      	movl	$0xa0, %edx
     d39:      	movl	$0x82, %eax
     d3e:      	movq	%r12, %rsi
     d41:      	xorl	%ecx, %ecx
     d43:      	callq	*%rax
     d45:      	testq	%rax, %rax
     d48:      	jns	0xddf <event_wake_up_new_task+0xddf>
     d4e:      	movq	%rax, %r15
     d51:      	movl	$0x0, 0x18(%rsp)
     d59:      	movq	(%rip), %rdi            # 0xd60 <event_wake_up_new_task+0xd60>
     d60:      	leaq	0x18(%rsp), %rsi
     d65:      	movl	$0x1, %eax
     d6a:      	callq	*%rax
     d6c:      	testq	%rax, %rax
     d6f:      	je	0xddf <event_wake_up_new_task+0xddf>
     d71:      	cmpq	$-0xc, %r15
     d75:      	jg	0xd91 <event_wake_up_new_task+0xd91>
     d77:      	cmpq	$-0x1c, %r15
     d7b:      	je	0xdc5 <event_wake_up_new_task+0xdc5>
     d7d:      	cmpq	$-0x16, %r15
     d81:      	je	0xd20 <event_wake_up_new_task+0xd20>
     d83:      	cmpq	$-0x10, %r15
     d87:      	jne	0xdbd <event_wake_up_new_task+0xdbd>
     d89:      	addq	$0x600, %rax            # imm = 0x600
     d8f:      	jmp	0xddb <event_wake_up_new_task+0xddb>
     d91:      	cmpq	$-0xb, %r15
     d95:      	je	0xdcd <event_wake_up_new_task+0xdcd>
     d97:      	cmpq	$-0x7, %r15
     d9b:      	je	0xdd5 <event_wake_up_new_task+0xdd5>
     d9d:      	cmpq	$-0x2, %r15
     da1:      	jne	0xdbd <event_wake_up_new_task+0xdbd>
     da3:      	addq	$0x5f0, %rax            # imm = 0x5F0
     da9:      	jmp	0xddb <event_wake_up_new_task+0xddb>
     dab:      	cmpq	$-0xb, %r15
     daf:      	je	0xdcd <event_wake_up_new_task+0xdcd>
     db1:      	cmpq	$-0x7, %r15
     db5:      	je	0xdd5 <event_wake_up_new_task+0xdd5>
     db7:      	cmpq	$-0x2, %r15
     dbb:      	je	0xda3 <event_wake_up_new_task+0xda3>
     dbd:      	addq	$0x5e8, %rax            # imm = 0x5E8
     dc3:      	jmp	0xddb <event_wake_up_new_task+0xddb>
     dc5:      	addq	$0x610, %rax            # imm = 0x610
     dcb:      	jmp	0xddb <event_wake_up_new_task+0xddb>
     dcd:      	addq	$0x618, %rax            # imm = 0x618
     dd3:      	jmp	0xddb <event_wake_up_new_task+0xddb>
     dd5:      	addq	$0x5f8, %rax            # imm = 0x5F8
     ddb:      	lock
     ddc:      	incq	(%rax)
     ddf:      	cmpq	$0x0, 0x20(%r14)
     de4:      	jne	0xf45 <event_wake_up_new_task+0xf45>
     dea:      	movl	$0x0, 0x8(%rsp)
     df2:      	movq	(%rip), %rdi            # 0xdf9 <event_wake_up_new_task+0xdf9>
     df9:      	leaq	0x8(%rsp), %rsi
     dfe:      	movl	$0x1, %eax
     e03:      	callq	*%rax
     e05:      	testq	%rax, %rax
     e08:      	je	0xe8f <event_wake_up_new_task+0xe8f>
     e0e:      	cmpb	$0x0, 0x28(%rax)
     e12:      	je	0xe8f <event_wake_up_new_task+0xe8f>
     e14:      	movq	(%rip), %rsi            # 0xe1b <event_wake_up_new_task+0xe1b>
     e1b:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     e20:      	leaq	0x48(%rsp), %rcx
     e25:      	movl	$0x38, %edi
     e2a:      	movl	$0x19, %eax
     e2f:      	movl	$0x38, %r8d
     e35:      	movq	%rbx, %rdi
     e38:      	callq	*%rax
     e3a:      	testq	%rax, %rax
     e3d:      	jns	0xf45 <event_wake_up_new_task+0xf45>
     e43:      	movq	%rax, %rbx
     e46:      	movl	$0x0, 0x18(%rsp)
     e4e:      	movq	(%rip), %rdi            # 0xe55 <event_wake_up_new_task+0xe55>
     e55:      	leaq	0x18(%rsp), %rsi
     e5a:      	movl	$0x1, %eax
     e5f:      	callq	*%rax
     e61:      	testq	%rax, %rax
     e64:      	je	0xf45 <event_wake_up_new_task+0xf45>
     e6a:      	cmpq	$-0xc, %rbx
     e6e:      	jg	0xf11 <event_wake_up_new_task+0xf11>
     e74:      	cmpq	$-0x1c, %rbx
     e78:      	je	0xf2b <event_wake_up_new_task+0xf2b>
     e7e:      	cmpq	$-0x16, %rbx
     e82:      	jne	0xee9 <event_wake_up_new_task+0xee9>
     e84:      	addq	$0x528, %rax            # imm = 0x528
     e8a:      	jmp	0xf41 <event_wake_up_new_task+0xf41>
     e8f:      	movq	(%rip), %rdi            # 0xe96 <event_wake_up_new_task+0xe96>
     e96:      	xorl	%ecx, %ecx
     e98:      	leaq	0x48(%rsp), %rsi
     e9d:      	movl	$0x38, %edx
     ea2:      	movl	$0x82, %eax
     ea7:      	xorl	%ecx, %ecx
     ea9:      	callq	*%rax
     eab:      	testq	%rax, %rax
     eae:      	jns	0xf45 <event_wake_up_new_task+0xf45>
     eb4:      	movq	%rax, %rbx
     eb7:      	movl	$0x0, 0x18(%rsp)
     ebf:      	movq	(%rip), %rdi            # 0xec6 <event_wake_up_new_task+0xec6>
     ec6:      	leaq	0x18(%rsp), %rsi
     ecb:      	movl	$0x1, %eax
     ed0:      	callq	*%rax
     ed2:      	testq	%rax, %rax
     ed5:      	je	0xf45 <event_wake_up_new_task+0xf45>
     ed7:      	cmpq	$-0xc, %rbx
     edb:      	jg	0xef7 <event_wake_up_new_task+0xef7>
     edd:      	cmpq	$-0x1c, %rbx
     ee1:      	je	0xf2b <event_wake_up_new_task+0xf2b>
     ee3:      	cmpq	$-0x16, %rbx
     ee7:      	je	0xe84 <event_wake_up_new_task+0xe84>
     ee9:      	cmpq	$-0x10, %rbx
     eed:      	jne	0xf23 <event_wake_up_new_task+0xf23>
     eef:      	addq	$0x520, %rax            # imm = 0x520
     ef5:      	jmp	0xf41 <event_wake_up_new_task+0xf41>
     ef7:      	cmpq	$-0xb, %rbx
     efb:      	je	0xf33 <event_wake_up_new_task+0xf33>
     efd:      	cmpq	$-0x7, %rbx
     f01:      	je	0xf3b <event_wake_up_new_task+0xf3b>
     f03:      	cmpq	$-0x2, %rbx
     f07:      	jne	0xf23 <event_wake_up_new_task+0xf23>
     f09:      	addq	$0x510, %rax            # imm = 0x510
     f0f:      	jmp	0xf41 <event_wake_up_new_task+0xf41>
     f11:      	cmpq	$-0xb, %rbx
     f15:      	je	0xf33 <event_wake_up_new_task+0xf33>
     f17:      	cmpq	$-0x7, %rbx
     f1b:      	je	0xf3b <event_wake_up_new_task+0xf3b>
     f1d:      	cmpq	$-0x2, %rbx
     f21:      	je	0xf09 <event_wake_up_new_task+0xf09>
     f23:      	addq	$0x508, %rax            # imm = 0x508
     f29:      	jmp	0xf41 <event_wake_up_new_task+0xf41>
     f2b:      	addq	$0x530, %rax            # imm = 0x530
     f31:      	jmp	0xf41 <event_wake_up_new_task+0xf41>
     f33:      	addq	$0x538, %rax            # imm = 0x538
     f39:      	jmp	0xf41 <event_wake_up_new_task+0xf41>
     f3b:      	addq	$0x518, %rax            # imm = 0x518
     f41:      	lock
     f42:      	incq	(%rax)
     f45:      	xorl	%eax, %eax
     f47:      	addq	$0x128, %rsp            # imm = 0x128
     f4e:      	popq	%rbx
     f4f:      	popq	%r12
     f51:      	popq	%r13
     f53:      	popq	%r14
     f55:      	popq	%r15
     f57:      	popq	%rbp
     f58:      	retq
