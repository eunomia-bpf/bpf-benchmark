
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_execve_event_v61.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <do_str>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x18, %rsp
       e:      	movq	%rdx, %r15
      11:      	movq	%rsi, %rbx
      14:      	movq	%rdi, %r14
      17:      	leaq	0x20(%rsi), %r12
      1b:      	movl	$0x7fdf, %ecx           # imm = 0x7FDF
      20:      	movl	$0x2d, %eax
      25:      	movq	%r12, %rdi
      28:      	movl	$0x7fdf, %esi           # imm = 0x7FDF
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	js	0x35b <do_str+0x35b>
      38:      	je	0x150 <do_str+0x150>
      3e:      	movq	%rax, %rbp
      41:      	leal	0x1f(%rax), %r13d
      45:      	andl	$0x7fff, %r13d          # imm = 0x7FFF
      4c:      	movl	%r13d, 0x4(%rbx)
      50:      	movl	$0x0, 0xc(%rsp)
      58:      	movq	(%rip), %rdi            # 0x5f <do_str+0x5f>
      5f:      	leaq	0xc(%rsp), %rsi
      64:      	movl	$0x1, %eax
      69:      	callq	*%rax
      6b:      	testq	%rax, %rax
      6e:      	je	0xec <do_str+0xec>
      70:      	cmpb	$0x0, 0x28(%rax)
      74:      	je	0xec <do_str+0xec>
      76:      	movq	(%rip), %rsi            # 0x7d <do_str+0x7d>
      7d:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
      82:      	movl	$0x19, %eax
      87:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
      8c:      	movq	%r14, %rdi
      8f:      	movq	%rbx, %rcx
      92:      	movq	%r13, %r8
      95:      	callq	*%rax
      97:      	testq	%rax, %rax
      9a:      	jns	0x1a5 <do_str+0x1a5>
      a0:      	movq	%rax, %r13
      a3:      	movl	$0x0, 0x14(%rsp)
      ab:      	movq	(%rip), %rdi            # 0xb2 <do_str+0xb2>
      b2:      	leaq	0x14(%rsp), %rsi
      b7:      	movl	$0x1, %eax
      bc:      	callq	*%rax
      be:      	testq	%rax, %rax
      c1:      	je	0x1a5 <do_str+0x1a5>
      c7:      	cmpq	$-0xc, %r13
      cb:      	jg	0x171 <do_str+0x171>
      d1:      	cmpq	$-0x1c, %r13
      d5:      	je	0x18b <do_str+0x18b>
      db:      	cmpq	$-0x16, %r13
      df:      	jne	0x142 <do_str+0x142>
      e1:      	addq	$0x560, %rax            # imm = 0x560
      e7:      	jmp	0x1a1 <do_str+0x1a1>
      ec:      	movq	(%rip), %rdi            # 0xf3 <do_str+0xf3>
      f3:      	xorl	%ecx, %ecx
      f5:      	movl	$0x82, %eax
      fa:      	movq	%rbx, %rsi
      fd:      	movq	%r13, %rdx
     100:      	xorl	%ecx, %ecx
     102:      	callq	*%rax
     104:      	testq	%rax, %rax
     107:      	jns	0x1a5 <do_str+0x1a5>
     10d:      	movq	%rax, %r13
     110:      	movl	$0x0, 0x10(%rsp)
     118:      	movq	(%rip), %rdi            # 0x11f <do_str+0x11f>
     11f:      	leaq	0x10(%rsp), %rsi
     124:      	movl	$0x1, %eax
     129:      	callq	*%rax
     12b:      	testq	%rax, %rax
     12e:      	je	0x1a5 <do_str+0x1a5>
     130:      	cmpq	$-0xc, %r13
     134:      	jg	0x157 <do_str+0x157>
     136:      	cmpq	$-0x1c, %r13
     13a:      	je	0x18b <do_str+0x18b>
     13c:      	cmpq	$-0x16, %r13
     140:      	je	0xe1 <do_str+0xe1>
     142:      	cmpq	$-0x10, %r13
     146:      	jne	0x183 <do_str+0x183>
     148:      	addq	$0x558, %rax            # imm = 0x558
     14e:      	jmp	0x1a1 <do_str+0x1a1>
     150:      	xorl	%eax, %eax
     152:      	jmp	0x35b <do_str+0x35b>
     157:      	cmpq	$-0xb, %r13
     15b:      	je	0x193 <do_str+0x193>
     15d:      	cmpq	$-0x7, %r13
     161:      	je	0x19b <do_str+0x19b>
     163:      	cmpq	$-0x2, %r13
     167:      	jne	0x183 <do_str+0x183>
     169:      	addq	$0x548, %rax            # imm = 0x548
     16f:      	jmp	0x1a1 <do_str+0x1a1>
     171:      	cmpq	$-0xb, %r13
     175:      	je	0x193 <do_str+0x193>
     177:      	cmpq	$-0x7, %r13
     17b:      	je	0x19b <do_str+0x19b>
     17d:      	cmpq	$-0x2, %r13
     181:      	je	0x169 <do_str+0x169>
     183:      	addq	$0x540, %rax            # imm = 0x540
     189:      	jmp	0x1a1 <do_str+0x1a1>
     18b:      	addq	$0x568, %rax            # imm = 0x568
     191:      	jmp	0x1a1 <do_str+0x1a1>
     193:      	addq	$0x570, %rax            # imm = 0x570
     199:      	jmp	0x1a1 <do_str+0x1a1>
     19b:      	addq	$0x550, %rax            # imm = 0x550
     1a1:      	lock
     1a2:      	incq	(%rax)
     1a5:      	leaq	-0x1(%rbp), %r13
     1a9:      	cmpq	$0x7fdf, %rbp           # imm = 0x7FDF
     1b0:      	jne	0x294 <do_str+0x294>
     1b6:      	addq	%r13, %r15
     1b9:      	movl	$0x7fdf, %ecx           # imm = 0x7FDF
     1be:      	movl	$0x2d, %eax
     1c3:      	movq	%r12, %rdi
     1c6:      	movl	$0x7fdf, %esi           # imm = 0x7FDF
     1cb:      	movq	%r15, %rdx
     1ce:      	callq	*%rax
     1d0:      	testq	%rax, %rax
     1d3:      	js	0x35b <do_str+0x35b>
     1d9:      	je	0x300 <do_str+0x300>
     1df:      	leal	0x1f(%rax), %r15d
     1e3:      	andl	$0x7fff, %r15d          # imm = 0x7FFF
     1ea:      	movl	%r15d, 0x4(%rbx)
     1ee:      	movl	$0x0, 0xc(%rsp)
     1f6:      	movq	(%rip), %rdi            # 0x1fd <do_str+0x1fd>
     1fd:      	leaq	0xc(%rsp), %rsi
     202:      	movq	%rax, %r12
     205:      	movl	$0x1, %eax
     20a:      	decq	%r12
     20d:      	callq	*%rax
     20f:      	testq	%rax, %rax
     212:      	je	0x29c <do_str+0x29c>
     218:      	cmpb	$0x0, 0x28(%rax)
     21c:      	je	0x29c <do_str+0x29c>
     21e:      	movq	(%rip), %rsi            # 0x225 <do_str+0x225>
     225:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     22a:      	movl	$0x19, %eax
     22f:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     234:      	movq	%r14, %rdi
     237:      	movq	%rbx, %rcx
     23a:      	movq	%r15, %r8
     23d:      	callq	*%rax
     23f:      	testq	%rax, %rax
     242:      	jns	0x355 <do_str+0x355>
     248:      	movq	%rax, %rbx
     24b:      	movl	$0x0, 0x14(%rsp)
     253:      	movq	(%rip), %rdi            # 0x25a <do_str+0x25a>
     25a:      	leaq	0x14(%rsp), %rsi
     25f:      	movl	$0x1, %eax
     264:      	callq	*%rax
     266:      	testq	%rax, %rax
     269:      	je	0x355 <do_str+0x355>
     26f:      	cmpq	$-0xc, %rbx
     273:      	jg	0x321 <do_str+0x321>
     279:      	cmpq	$-0x1c, %rbx
     27d:      	je	0x33b <do_str+0x33b>
     283:      	cmpq	$-0x16, %rbx
     287:      	jne	0x2f2 <do_str+0x2f2>
     289:      	addq	$0x560, %rax            # imm = 0x560
     28f:      	jmp	0x351 <do_str+0x351>
     294:      	movq	%r13, %rax
     297:      	jmp	0x35b <do_str+0x35b>
     29c:      	movq	(%rip), %rdi            # 0x2a3 <do_str+0x2a3>
     2a3:      	xorl	%ecx, %ecx
     2a5:      	movl	$0x82, %eax
     2aa:      	movq	%rbx, %rsi
     2ad:      	movq	%r15, %rdx
     2b0:      	xorl	%ecx, %ecx
     2b2:      	callq	*%rax
     2b4:      	testq	%rax, %rax
     2b7:      	jns	0x355 <do_str+0x355>
     2bd:      	movq	%rax, %rbx
     2c0:      	movl	$0x0, 0x10(%rsp)
     2c8:      	movq	(%rip), %rdi            # 0x2cf <do_str+0x2cf>
     2cf:      	leaq	0x10(%rsp), %rsi
     2d4:      	movl	$0x1, %eax
     2d9:      	callq	*%rax
     2db:      	testq	%rax, %rax
     2de:      	je	0x355 <do_str+0x355>
     2e0:      	cmpq	$-0xc, %rbx
     2e4:      	jg	0x307 <do_str+0x307>
     2e6:      	cmpq	$-0x1c, %rbx
     2ea:      	je	0x33b <do_str+0x33b>
     2ec:      	cmpq	$-0x16, %rbx
     2f0:      	je	0x289 <do_str+0x289>
     2f2:      	cmpq	$-0x10, %rbx
     2f6:      	jne	0x333 <do_str+0x333>
     2f8:      	addq	$0x558, %rax            # imm = 0x558
     2fe:      	jmp	0x351 <do_str+0x351>
     300:      	movl	$0x7fde, %eax           # imm = 0x7FDE
     305:      	jmp	0x35b <do_str+0x35b>
     307:      	cmpq	$-0xb, %rbx
     30b:      	je	0x343 <do_str+0x343>
     30d:      	cmpq	$-0x7, %rbx
     311:      	je	0x34b <do_str+0x34b>
     313:      	cmpq	$-0x2, %rbx
     317:      	jne	0x333 <do_str+0x333>
     319:      	addq	$0x548, %rax            # imm = 0x548
     31f:      	jmp	0x351 <do_str+0x351>
     321:      	cmpq	$-0xb, %rbx
     325:      	je	0x343 <do_str+0x343>
     327:      	cmpq	$-0x7, %rbx
     32b:      	je	0x34b <do_str+0x34b>
     32d:      	cmpq	$-0x2, %rbx
     331:      	je	0x319 <do_str+0x319>
     333:      	addq	$0x540, %rax            # imm = 0x540
     339:      	jmp	0x351 <do_str+0x351>
     33b:      	addq	$0x568, %rax            # imm = 0x568
     341:      	jmp	0x351 <do_str+0x351>
     343:      	addq	$0x570, %rax            # imm = 0x570
     349:      	jmp	0x351 <do_str+0x351>
     34b:      	addq	$0x550, %rax            # imm = 0x550
     351:      	lock
     352:      	incq	(%rax)
     355:      	addq	%r13, %r12
     358:      	movq	%r12, %rax
     35b:      	addq	$0x18, %rsp
     35f:      	popq	%rbx
     360:      	popq	%r12
     362:      	popq	%r13
     364:      	popq	%r14
     366:      	popq	%r15
     368:      	popq	%rbp
     369:      	retq
     36a:      	nopw	(%rax,%rax)

0000000000000370 <do_bytes>:
     370:      	pushq	%rbp
     371:      	pushq	%r15
     373:      	pushq	%r14
     375:      	pushq	%r13
     377:      	pushq	%r12
     379:      	pushq	%rbx
     37a:      	pushq	%rax
     37b:      	movq	%rcx, %rbx
     37e:      	movq	%rdx, %r14
     381:      	movq	%rsi, %r15
     384:      	movq	%rdi, %r12
     387:      	callq	0x5d0 <__do_bytes>
     38c:      	testl	%eax, %eax
     38e:      	js	0x537 <do_bytes+0x1c7>
     394:      	movl	%eax, %r13d
     397:      	andl	$0x7fffffff, %r13d      # imm = 0x7FFFFFFF
     39e:      	movq	%rbx, %rcx
     3a1:      	subq	%r13, %rcx
     3a4:      	je	0x5be <do_bytes+0x24e>
     3aa:      	leaq	(%r14,%r13), %rdx
     3ae:      	movq	%r12, %rdi
     3b1:      	movq	%r15, %rsi
     3b4:      	callq	0x5d0 <__do_bytes>
     3b9:      	testl	%eax, %eax
     3bb:      	js	0x537 <do_bytes+0x1c7>
     3c1:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     3c6:      	movq	%rax, %rbp
     3c9:      	addq	%r13, %rbp
     3cc:      	movq	%rbx, %rcx
     3cf:      	subq	%rbp, %rcx
     3d2:      	je	0x5be <do_bytes+0x24e>
     3d8:      	leaq	(%r14,%rbp), %rdx
     3dc:      	movq	%r12, %rdi
     3df:      	movq	%r15, %rsi
     3e2:      	callq	0x5d0 <__do_bytes>
     3e7:      	testl	%eax, %eax
     3e9:      	js	0x537 <do_bytes+0x1c7>
     3ef:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     3f4:      	movq	%rax, %r13
     3f7:      	addq	%rbp, %r13
     3fa:      	movq	%rbx, %rcx
     3fd:      	subq	%r13, %rcx
     400:      	je	0x5be <do_bytes+0x24e>
     406:      	leaq	(%r14,%r13), %rdx
     40a:      	movq	%r12, %rdi
     40d:      	movq	%r15, %rsi
     410:      	callq	0x5d0 <__do_bytes>
     415:      	testl	%eax, %eax
     417:      	js	0x537 <do_bytes+0x1c7>
     41d:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     422:      	movq	%rax, %rbp
     425:      	addq	%r13, %rbp
     428:      	movq	%rbx, %rcx
     42b:      	subq	%rbp, %rcx
     42e:      	je	0x5be <do_bytes+0x24e>
     434:      	leaq	(%r14,%rbp), %rdx
     438:      	movq	%r12, %rdi
     43b:      	movq	%r15, %rsi
     43e:      	callq	0x5d0 <__do_bytes>
     443:      	testl	%eax, %eax
     445:      	js	0x537 <do_bytes+0x1c7>
     44b:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     450:      	movq	%rax, %r13
     453:      	addq	%rbp, %r13
     456:      	movq	%rbx, %rcx
     459:      	subq	%r13, %rcx
     45c:      	je	0x5be <do_bytes+0x24e>
     462:      	leaq	(%r14,%r13), %rdx
     466:      	movq	%r12, %rdi
     469:      	movq	%r15, %rsi
     46c:      	callq	0x5d0 <__do_bytes>
     471:      	testl	%eax, %eax
     473:      	js	0x537 <do_bytes+0x1c7>
     479:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     47e:      	movq	%rax, %rbp
     481:      	addq	%r13, %rbp
     484:      	movq	%rbx, %rcx
     487:      	subq	%rbp, %rcx
     48a:      	je	0x5be <do_bytes+0x24e>
     490:      	leaq	(%r14,%rbp), %rdx
     494:      	movq	%r12, %rdi
     497:      	movq	%r15, %rsi
     49a:      	callq	0x5d0 <__do_bytes>
     49f:      	testl	%eax, %eax
     4a1:      	js	0x537 <do_bytes+0x1c7>
     4a7:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     4ac:      	movq	%rax, %r13
     4af:      	addq	%rbp, %r13
     4b2:      	movq	%rbx, %rcx
     4b5:      	subq	%r13, %rcx
     4b8:      	je	0x5be <do_bytes+0x24e>
     4be:      	leaq	(%r14,%r13), %rdx
     4c2:      	movq	%r12, %rdi
     4c5:      	movq	%r15, %rsi
     4c8:      	callq	0x5d0 <__do_bytes>
     4cd:      	testl	%eax, %eax
     4cf:      	js	0x537 <do_bytes+0x1c7>
     4d1:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     4d6:      	movq	%rax, %rbp
     4d9:      	addq	%r13, %rbp
     4dc:      	movq	%rbx, %rcx
     4df:      	subq	%rbp, %rcx
     4e2:      	je	0x5be <do_bytes+0x24e>
     4e8:      	leaq	(%r14,%rbp), %rdx
     4ec:      	movq	%r12, %rdi
     4ef:      	movq	%r15, %rsi
     4f2:      	callq	0x5d0 <__do_bytes>
     4f7:      	testl	%eax, %eax
     4f9:      	js	0x537 <do_bytes+0x1c7>
     4fb:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     500:      	movq	%rax, %r13
     503:      	addq	%rbp, %r13
     506:      	movq	%rbx, %rcx
     509:      	subq	%r13, %rcx
     50c:      	je	0x5be <do_bytes+0x24e>
     512:      	addq	%r13, %r14
     515:      	movq	%r12, %rdi
     518:      	movq	%r15, %rsi
     51b:      	movq	%r14, %rdx
     51e:      	callq	0x5d0 <__do_bytes>
     523:      	testl	%eax, %eax
     525:      	js	0x537 <do_bytes+0x1c7>
     527:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     52c:      	addq	%r13, %rax
     52f:      	movq	%rax, %rbx
     532:      	jmp	0x5be <do_bytes+0x24e>
     537:      	movslq	%eax, %rbx
     53a:      	movl	$0x0, 0x4(%rsp)
     542:      	movq	(%rip), %rdi            # 0x549 <do_bytes+0x1d9>
     549:      	leaq	0x4(%rsp), %rsi
     54e:      	movl	$0x1, %eax
     553:      	callq	*%rax
     555:      	testq	%rax, %rax
     558:      	je	0x5be <do_bytes+0x24e>
     55a:      	cmpq	$-0xc, %rbx
     55e:      	jg	0x57a <do_bytes+0x20a>
     560:      	cmpq	$-0x1c, %rbx
     564:      	je	0x594 <do_bytes+0x224>
     566:      	cmpq	$-0x16, %rbx
     56a:      	je	0x5ac <do_bytes+0x23c>
     56c:      	cmpq	$-0x10, %rbx
     570:      	jne	0x5a4 <do_bytes+0x234>
     572:      	addq	$0x558, %rax            # imm = 0x558
     578:      	jmp	0x5ba <do_bytes+0x24a>
     57a:      	cmpq	$-0xb, %rbx
     57e:      	je	0x59c <do_bytes+0x22c>
     580:      	cmpq	$-0x7, %rbx
     584:      	je	0x5b4 <do_bytes+0x244>
     586:      	cmpq	$-0x2, %rbx
     58a:      	jne	0x5a4 <do_bytes+0x234>
     58c:      	addq	$0x548, %rax            # imm = 0x548
     592:      	jmp	0x5ba <do_bytes+0x24a>
     594:      	addq	$0x568, %rax            # imm = 0x568
     59a:      	jmp	0x5ba <do_bytes+0x24a>
     59c:      	addq	$0x570, %rax            # imm = 0x570
     5a2:      	jmp	0x5ba <do_bytes+0x24a>
     5a4:      	addq	$0x540, %rax            # imm = 0x540
     5aa:      	jmp	0x5ba <do_bytes+0x24a>
     5ac:      	addq	$0x560, %rax            # imm = 0x560
     5b2:      	jmp	0x5ba <do_bytes+0x24a>
     5b4:      	addq	$0x550, %rax            # imm = 0x550
     5ba:      	lock
     5bb:      	incq	(%rax)
     5be:      	movq	%rbx, %rax
     5c1:      	addq	$0x8, %rsp
     5c5:      	popq	%rbx
     5c6:      	popq	%r12
     5c8:      	popq	%r13
     5ca:      	popq	%r14
     5cc:      	popq	%r15
     5ce:      	popq	%rbp
     5cf:      	retq

00000000000005d0 <__do_bytes>:
     5d0:      	pushq	%r15
     5d2:      	pushq	%r14
     5d4:      	pushq	%r12
     5d6:      	pushq	%rbx
     5d7:      	pushq	%rax
     5d8:      	testq	%rcx, %rcx
     5db:      	js	0x659 <__do_bytes+0x89>
     5dd:      	movq	%rsi, %r14
     5e0:      	movq	%rdi, %r12
     5e3:      	cmpq	$0x7fe0, %rcx           # imm = 0x7FE0
     5ea:      	movl	$0x7fe0, %ebx           # imm = 0x7FE0
     5ef:      	cmovbq	%rcx, %rbx
     5f3:      	leaq	0x20(%rsi), %rdi
     5f7:      	movl	$0x4, %eax
     5fc:      	movl	%ebx, %esi
     5fe:      	callq	*%rax
     600:      	testl	%eax, %eax
     602:      	js	0x67e <__do_bytes+0xae>
     604:      	leal	0x20(%rbx), %r15d
     608:      	movl	%r15d, 0x4(%r14)
     60c:      	movl	$0x0, 0x4(%rsp)
     614:      	movq	(%rip), %rdi            # 0x61b <__do_bytes+0x4b>
     61b:      	leaq	0x4(%rsp), %rsi
     620:      	movl	$0x1, %eax
     625:      	callq	*%rax
     627:      	testq	%rax, %rax
     62a:      	je	0x662 <__do_bytes+0x92>
     62c:      	cmpb	$0x0, 0x28(%rax)
     630:      	je	0x662 <__do_bytes+0x92>
     632:      	movq	(%rip), %rsi            # 0x639 <__do_bytes+0x69>
     639:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     63e:      	movl	$0x19, %eax
     643:      	movq	%r12, %rdi
     646:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     64b:      	movq	%r14, %rcx
     64e:      	movq	%r15, %r8
     651:      	callq	*%rax
     653:      	testl	%eax, %eax
     655:      	js	0x67e <__do_bytes+0xae>
     657:      	jmp	0x681 <__do_bytes+0xb1>
     659:      	movq	$-0x1, %rbx
     660:      	jmp	0x681 <__do_bytes+0xb1>
     662:      	movq	(%rip), %rdi            # 0x669 <__do_bytes+0x99>
     669:      	xorl	%ecx, %ecx
     66b:      	movl	$0x82, %eax
     670:      	movq	%r14, %rsi
     673:      	movq	%r15, %rdx
     676:      	xorl	%ecx, %ecx
     678:      	callq	*%rax
     67a:      	testl	%eax, %eax
     67c:      	jns	0x681 <__do_bytes+0xb1>
     67e:      	movslq	%eax, %rbx
     681:      	movq	%rbx, %rax
     684:      	addq	$0x8, %rsp
     688:      	popq	%rbx
     689:      	popq	%r12
     68b:      	popq	%r14
     68d:      	popq	%r15
     68f:      	retq

Disassembly of section tracepoint:

0000000000000000 <execve_rate>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x48, %rsp
       e:      	movq	%rdi, %rbx
      11:      	movl	$0x0, 0x4(%rsp)
      19:      	movq	(%rip), %rdi            # 0x20 <execve_rate+0x20>
      20:      	leaq	0x4(%rsp), %rsi
      25:      	movl	$0x1, %eax
      2a:      	callq	*%rax
      2c:      	testq	%rax, %rax
      2f:      	je	0x343 <execve_rate+0x343>
      35:      	movq	0x8(%rax), %r15
      39:      	movq	%rax, %r13
      3c:      	movq	0x10(%rax), %rax
      40:      	movq	%rax, 0x18(%rsp)
      45:      	movl	$0x0, 0x8(%rsp)
      4d:      	movq	(%rip), %rdi            # 0x54 <execve_rate+0x54>
      54:      	leaq	0x8(%rsp), %rsi
      59:      	movl	$0x1, %eax
      5e:      	callq	*%rax
      60:      	testq	%rax, %rax
      63:      	je	0x328 <execve_rate+0x328>
      69:      	movq	0x8(%rax), %r12
      6d:      	testq	%r12, %r12
      70:      	je	0x328 <execve_rate+0x328>
      76:      	movq	%rax, %rbp
      79:      	movq	(%rip), %rdi            # 0x80 <execve_rate+0x80>
      80:      	leaq	0x18(%rsp), %rsi
      85:      	movl	$0x1, %eax
      8a:      	callq	*%rax
      8c:      	testq	%rax, %rax
      8f:      	je	0xc2 <execve_rate+0xc2>
      91:      	movq	%rax, %r14
      94:      	movq	0x10(%rax), %rax
      98:      	movq	%r15, %rcx
      9b:      	subq	%rax, %rcx
      9e:      	cmpq	%r12, %rcx
      a1:      	jbe	0x118 <execve_rate+0x118>
      a3:      	leaq	(%r12,%r12), %rdx
      a7:      	cmpq	%rdx, %rcx
      aa:      	jbe	0x11d <execve_rate+0x11d>
      ac:      	movq	$0x0, 0x8(%r14)
      b4:      	movq	%r15, %rax
      b7:      	xorl	%edx, %edx
      b9:      	divq	%r12
      bc:      	imulq	%r12, %rax
      c0:      	jmp	0x127 <execve_rate+0x127>
      c2:      	movq	$0x1, 0x20(%rsp)
      cb:      	movq	$0x0, 0x28(%rsp)
      d4:      	movq	%r15, %rax
      d7:      	xorl	%edx, %edx
      d9:      	divq	%r12
      dc:      	imulq	%r12, %rax
      e0:      	movq	%rax, 0x30(%rsp)
      e5:      	movq	$0x0, 0x38(%rsp)
      ee:      	movq	$0x0, 0x40(%rsp)
      f7:      	movq	(%rip), %rdi            # 0xfe <execve_rate+0xfe>
      fe:      	xorl	%ecx, %ecx
     100:      	leaq	0x18(%rsp), %rsi
     105:      	leaq	0x20(%rsp), %rdx
     10a:      	movl	$0x2, %eax
     10f:      	xorl	%ecx, %ecx
     111:      	callq	*%rax
     113:      	jmp	0x328 <execve_rate+0x328>
     118:      	movq	(%r14), %rcx
     11b:      	jmp	0x12d <execve_rate+0x12d>
     11d:      	movq	(%r14), %rcx
     120:      	movq	%rcx, 0x8(%r14)
     124:      	addq	%r12, %rax
     127:      	movq	%rax, 0x10(%r14)
     12b:      	xorl	%ecx, %ecx
     12d:      	incq	%rcx
     130:      	movq	%rcx, (%r14)
     133:      	movq	%r12, %rcx
     136:      	subq	%r15, %rcx
     139:      	addq	%rax, %rcx
     13c:      	imulq	0x8(%r14), %rcx
     141:      	movq	%rcx, %rax
     144:      	xorl	%edx, %edx
     146:      	divq	%r12
     149:      	addq	(%r14), %rax
     14c:      	movq	%rax, 0x18(%r14)
     150:      	cmpq	$0x0, 0x20(%r14)
     155:      	jne	0x343 <execve_rate+0x343>
     15b:      	cmpq	(%rbp), %rax
     15f:      	jb	0x328 <execve_rate+0x328>
     165:      	movq	%r15, 0x20(%r14)
     169:      	movl	$0x0, 0x10(%rsp)
     171:      	movq	(%rip), %rdi            # 0x178 <execve_rate+0x178>
     178:      	leaq	0x10(%rsp), %rcx
     17d:      	movl	$0x1, %eax
     182:      	movl	$0x0, 0xc(%rsp)
     18a:      	leaq	0xc(%rsp), %rsi
     18f:      	callq	*%rax
     191:      	testq	%rax, %rax
     194:      	je	0x321 <execve_rate+0x321>
     19a:      	movq	%rax, %r12
     19d:      	movl	$0xa0, 0x4(%rax)
     1a4:      	movq	%r13, %rsi
     1a7:      	addq	$0x10, %rsi
     1ab:      	movq	%r15, 0x8(%rax)
     1af:      	movw	$0x1b, (%rax)
     1b4:      	movq	%rax, %rdi
     1b7:      	addq	$0x10, %rdi
     1bb:      	movl	$0x90, %edx
     1c0:      	callq	0x1c5 <execve_rate+0x1c5>
     1c5:      	movl	$0x0, 0x14(%rsp)
     1cd:      	movq	(%rip), %rdi            # 0x1d4 <execve_rate+0x1d4>
     1d4:      	leaq	0x14(%rsp), %rsi
     1d9:      	movl	$0x1, %eax
     1de:      	callq	*%rax
     1e0:      	testq	%rax, %rax
     1e3:      	je	0x26d <execve_rate+0x26d>
     1e9:      	cmpb	$0x0, 0x28(%rax)
     1ed:      	je	0x26d <execve_rate+0x26d>
     1ef:      	movq	(%rip), %rsi            # 0x1f6 <execve_rate+0x1f6>
     1f6:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     1fb:      	movl	$0xa0, %edx
     200:      	movl	$0x19, %eax
     205:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     20a:      	movl	$0xa0, %r8d
     210:      	movq	%rbx, %rdi
     213:      	movq	%r12, %rcx
     216:      	callq	*%rax
     218:      	testq	%rax, %rax
     21b:      	jns	0x321 <execve_rate+0x321>
     221:      	movq	%rax, %r15
     224:      	movl	$0x0, 0x20(%rsp)
     22c:      	movq	(%rip), %rdi            # 0x233 <execve_rate+0x233>
     233:      	leaq	0x20(%rsp), %rsi
     238:      	movl	$0x1, %eax
     23d:      	callq	*%rax
     23f:      	testq	%rax, %rax
     242:      	je	0x321 <execve_rate+0x321>
     248:      	cmpq	$-0xc, %r15
     24c:      	jg	0x2ed <execve_rate+0x2ed>
     252:      	cmpq	$-0x1c, %r15
     256:      	je	0x307 <execve_rate+0x307>
     25c:      	cmpq	$-0x16, %r15
     260:      	jne	0x2c5 <execve_rate+0x2c5>
     262:      	addq	$0x608, %rax            # imm = 0x608
     268:      	jmp	0x31d <execve_rate+0x31d>
     26d:      	movq	(%rip), %rdi            # 0x274 <execve_rate+0x274>
     274:      	xorl	%ecx, %ecx
     276:      	movl	$0xa0, %edx
     27b:      	movl	$0x82, %eax
     280:      	movq	%r12, %rsi
     283:      	xorl	%ecx, %ecx
     285:      	callq	*%rax
     287:      	testq	%rax, %rax
     28a:      	jns	0x321 <execve_rate+0x321>
     290:      	movq	%rax, %r15
     293:      	movl	$0x0, 0x20(%rsp)
     29b:      	movq	(%rip), %rdi            # 0x2a2 <execve_rate+0x2a2>
     2a2:      	leaq	0x20(%rsp), %rsi
     2a7:      	movl	$0x1, %eax
     2ac:      	callq	*%rax
     2ae:      	testq	%rax, %rax
     2b1:      	je	0x321 <execve_rate+0x321>
     2b3:      	cmpq	$-0xc, %r15
     2b7:      	jg	0x2d3 <execve_rate+0x2d3>
     2b9:      	cmpq	$-0x1c, %r15
     2bd:      	je	0x307 <execve_rate+0x307>
     2bf:      	cmpq	$-0x16, %r15
     2c3:      	je	0x262 <execve_rate+0x262>
     2c5:      	cmpq	$-0x10, %r15
     2c9:      	jne	0x2ff <execve_rate+0x2ff>
     2cb:      	addq	$0x600, %rax            # imm = 0x600
     2d1:      	jmp	0x31d <execve_rate+0x31d>
     2d3:      	cmpq	$-0xb, %r15
     2d7:      	je	0x30f <execve_rate+0x30f>
     2d9:      	cmpq	$-0x7, %r15
     2dd:      	je	0x317 <execve_rate+0x317>
     2df:      	cmpq	$-0x2, %r15
     2e3:      	jne	0x2ff <execve_rate+0x2ff>
     2e5:      	addq	$0x5f0, %rax            # imm = 0x5F0
     2eb:      	jmp	0x31d <execve_rate+0x31d>
     2ed:      	cmpq	$-0xb, %r15
     2f1:      	je	0x30f <execve_rate+0x30f>
     2f3:      	cmpq	$-0x7, %r15
     2f7:      	je	0x317 <execve_rate+0x317>
     2f9:      	cmpq	$-0x2, %r15
     2fd:      	je	0x2e5 <execve_rate+0x2e5>
     2ff:      	addq	$0x5e8, %rax            # imm = 0x5E8
     305:      	jmp	0x31d <execve_rate+0x31d>
     307:      	addq	$0x610, %rax            # imm = 0x610
     30d:      	jmp	0x31d <execve_rate+0x31d>
     30f:      	addq	$0x618, %rax            # imm = 0x618
     315:      	jmp	0x31d <execve_rate+0x31d>
     317:      	addq	$0x5f8, %rax            # imm = 0x5F8
     31d:      	lock
     31e:      	incq	(%rax)
     321:      	cmpq	$0x0, 0x20(%r14)
     326:      	jne	0x343 <execve_rate+0x343>
     328:      	movq	(%rip), %rsi            # 0x32f <execve_rate+0x32f>
     32f:      	movl	$0x1, %ecx
     334:      	movl	$0xc, %eax
     339:      	movq	%rbx, %rdi
     33c:      	movl	$0x1, %edx
     341:      	callq	*%rax
     343:      	xorl	%eax, %eax
     345:      	addq	$0x48, %rsp
     349:      	popq	%rbx
     34a:      	popq	%r12
     34c:      	popq	%r13
     34e:      	popq	%r14
     350:      	popq	%r15
     352:      	popq	%rbp
     353:      	retq
     354:      	nopw	%cs:(%rax,%rax)

0000000000000360 <execve_send>:
     360:      	pushq	%rbp
     361:      	pushq	%r15
     363:      	pushq	%r14
     365:      	pushq	%r13
     367:      	pushq	%r12
     369:      	pushq	%rbx
     36a:      	subq	$0xa8, %rsp
     371:      	movq	%rdi, %rbx
     374:      	movl	$0x0, 0x78(%rsp)
     37c:      	movq	(%rip), %rdi            # 0x383 <execve_send+0x23>
     383:      	leaq	0x78(%rsp), %rsi
     388:      	movl	$0x1, %eax
     38d:      	callq	*%rax
     38f:      	testq	%rax, %rax
     392:      	je	0x14cb <execve_send+0x116b>
     398:      	movq	%rax, %rbp
     39b:      	movq	%rbx, 0x90(%rsp)
     3a3:      	movl	$0x23, %eax
     3a8:      	callq	*%rax
     3aa:      	leaq	0xa78(%rax), %rdx
     3b1:      	leaq	0x10(%rsp), %rdi
     3b6:      	movl	$0x8, %ecx
     3bb:      	movl	$0x4, %eax
     3c0:      	leaq	0x16c0(%rbp), %rcx
     3c7:      	movq	%rcx, 0x88(%rsp)
     3cf:      	movl	$0x8, %esi
     3d4:      	callq	*%rax
     3d6:      	movl	$0x5f8, %edx            # imm = 0x5F8
     3db:      	movq	0x10(%rsp), %rcx
     3e0:      	addq	%rdx, %rcx
     3e3:      	leaq	0x20(%rsp), %rdi
     3e8:      	movl	$0x8, %esi
     3ed:      	movl	$0x4, %eax
     3f2:      	addq	0x10(%rsp), %rdx
     3f7:      	movl	$0x8, %esi
     3fc:      	callq	*%rax
     3fe:      	movq	0x20(%rsp), %r14
     403:      	movl	$0x0, 0x7c(%rsp)
     40b:      	movq	(%rip), %rdi            # 0x412 <execve_send+0xb2>
     412:      	leaq	0x7c(%rsp), %rsi
     417:      	movl	$0x1, %eax
     41c:      	callq	*%rax
     41e:      	testq	%rax, %rax
     421:      	je	0xaf1 <execve_send+0x791>
     427:      	movq	%rax, %r12
     42a:      	movl	$0x1000, 0x1840(%rbp)   # imm = 0x1000
     434:      	addq	$0x1000, %rax           # imm = 0x1000
     43a:      	movq	%rax, 0x60(%rsp)
     43f:      	movl	$0x23, %eax
     444:      	callq	*%rax
     446:      	leaq	0xd50(%rax), %rdx
     44d:      	leaq	0x98(%rsp), %rdi
     455:      	movl	$0x8, %ecx
     45a:      	movl	$0x4, %eax
     45f:      	movl	$0x8, %esi
     464:      	callq	*%rax
     466:      	movq	0x98(%rsp), %r13
     46e:      	leaq	0x48(%r14), %r15
     472:      	leaq	0xa0(%rsp), %rdi
     47a:      	movl	$0x8, %ecx
     47f:      	movl	$0x4, %eax
     484:      	movl	$0x8, %esi
     489:      	movq	%r15, %rdx
     48c:      	callq	*%rax
     48e:      	movq	0xa0(%rsp), %rbx
     496:      	leaq	0x10(%rbx), %rdx
     49a:      	leaq	0x20(%rsp), %rdi
     49f:      	movl	$0x8, %ecx
     4a4:      	movl	$0x4, %eax
     4a9:      	movl	$0x8, %esi
     4ae:      	callq	*%rax
     4b0:      	cmpq	$0x0, 0x20(%rsp)
     4b6:      	je	0x75b <execve_send+0x3fb>
     4bc:      	movq	0x60(%rsp), %rcx
     4c1:      	movq	$0x0, 0x28(%rsp)
     4ca:      	movq	$0x0, 0x20(%rsp)
     4d3:      	movq	%r12, 0x30(%rsp)
     4d8:      	movq	$0x0, 0x38(%rsp)
     4e1:      	movq	$0x0, 0x40(%rsp)
     4ea:      	movq	$0x0, 0x48(%rsp)
     4f3:      	movq	%rcx, 0x60(%rsp)
     4f8:      	movq	%rcx, 0x50(%rsp)
     4fd:      	movq	%rbp, 0x80(%rsp)
     505:      	movl	0x1840(%rbp), %eax
     50b:      	movl	%eax, 0x58(%rsp)
     50f:      	leaq	0x18(%r13), %r12
     513:      	movb	$0x0, 0x5c(%rsp)
     518:      	addq	$0x20, %r13
     51c:      	leaq	0x20(%rsp), %rdi
     521:      	movl	$0x8, %ecx
     526:      	movl	$0x4, %eax
     52b:      	addq	$0x40, %r14
     52f:      	leaq	0x28(%rsp), %rbx
     534:      	leaq	0x38(%rsp), %rbp
     539:      	movl	$0x8, %esi
     53e:      	movq	%r13, %rdx
     541:      	callq	*%rax
     543:      	movl	$0x8, %ecx
     548:      	movl	$0x4, %eax
     54d:      	movq	%rbx, %rdi
     550:      	movl	$0x8, %esi
     555:      	movq	%r12, %rdx
     558:      	callq	*%rax
     55a:      	movl	$0x8, %ecx
     55f:      	movl	$0x4, %eax
     564:      	movq	%rbp, %rdi
     567:      	movl	$0x8, %esi
     56c:      	movq	%r15, %rdx
     56f:      	callq	*%rax
     571:      	movl	$0x8, %ecx
     576:      	movl	$0x4, %eax
     57b:      	leaq	0x40(%rsp), %rdi
     580:      	movl	$0x8, %esi
     585:      	movq	%r14, %rdx
     588:      	callq	*%rax
     58a:      	movq	0x40(%rsp), %rax
     58f:      	addq	$-0x20, %rax
     593:      	movq	%rax, 0x48(%rsp)
     598:      	movq	(%rip), %rax            # 0x59f <execve_send+0x23f>
     59f:      	cmpb	$0x0, (%rax)
     5a2:      	je	0x7ac <execve_send+0x44c>
     5a8:      	movl	$0x800, %ebx            # imm = 0x800
     5ad:      	movl	$0x8, %r13d
     5b3:      	leaq	0x8(%rsp), %rbp
     5b8:      	nopl	(%rax,%rax)
     5c0:      	movq	0x38(%rsp), %r15
     5c5:      	movq	0x40(%rsp), %rdx
     5ca:      	movq	0x48(%rsp), %r14
     5cf:      	cmpq	0x20(%rsp), %r15
     5d4:      	jne	0x5e1 <execve_send+0x281>
     5d6:      	cmpq	0x28(%rsp), %rdx
     5db:      	je	0x94f <execve_send+0x5ef>
     5e1:      	movl	$0x4, %eax
     5e6:      	leaq	0x70(%rsp), %rdi
     5eb:      	movl	$0x8, %esi
     5f0:      	callq	*%rax
     5f2:      	cmpq	0x70(%rsp), %r15
     5f7:      	je	0x700 <execve_send+0x3a0>
     5fd:      	leaq	0x18(%r15), %r12
     601:      	movl	$0x4, %eax
     606:      	movq	%rbp, %rdi
     609:      	movl	$0x8, %esi
     60e:      	movq	%r12, %rdx
     611:      	callq	*%rax
     613:      	cmpq	%r15, 0x8(%rsp)
     618:      	je	0x700 <execve_send+0x3a0>
     61e:      	movl	$0x4, %eax
     623:      	leaq	0x68(%rsp), %rdi
     628:      	movl	$0x8, %esi
     62d:      	movq	%r12, %rdx
     630:      	callq	*%rax
     632:      	addq	$0x20, %r15
     636:      	movl	$0x4, %eax
     63b:      	leaq	0x10(%rsp), %rdi
     640:      	movl	$0x10, %ecx
     645:      	movl	$0x10, %esi
     64a:      	movq	%r15, %rdx
     64d:      	callq	*%rax
     64f:      	movq	0x30(%rsp), %r14
     654:      	movq	0x50(%rsp), %rax
     659:      	movl	0x14(%rsp), %r15d
     65e:      	subq	%r14, %rax
     661:      	movl	0x58(%rsp), %r12d
     666:      	movl	%r15d, %edx
     669:      	subl	%r12d, %edx
     66c:      	movl	$0x0, %ecx
     671:      	cmovbl	%ecx, %edx
     674:      	addq	0x18(%rsp), %rdx
     679:      	xorl	%esi, %esi
     67b:      	cmpl	%r15d, %r12d
     67e:      	seta	%sil
     682:      	movl	%r15d, %ecx
     685:      	cmovbl	%r12d, %ecx
     689:      	addl	%ecx, %esi
     68b:      	movl	%r12d, %edi
     68e:      	subl	%esi, %edi
     690:      	movl	%edi, 0x58(%rsp)
     694:      	subq	%rsi, %rax
     697:      	jb	0x98b <execve_send+0x62b>
     69d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     6a3:      	ja	0x98b <execve_send+0x62b>
     6a9:      	cmpl	%r15d, %r12d
     6ac:      	jbe	0x6b3 <execve_send+0x353>
     6ae:      	movb	$0x2f, (%r14,%rax)
     6b3:      	xorl	%edi, %edi
     6b5:      	cmpl	%r15d, %r12d
     6b8:      	seta	%dil
     6bc:      	movzbl	%cl, %esi
     6bf:      	addq	%rax, %r14
     6c2:      	addq	%r14, %rdi
     6c5:      	movl	$0x4, %eax
     6ca:      	callq	*%rax
     6cc:      	movq	%r14, 0x50(%rsp)
     6d1:      	cmpl	%r15d, %r12d
     6d4:      	jbe	0x98b <execve_send+0x62b>
     6da:      	movq	0x68(%rsp), %rax
     6df:      	movq	%rax, 0x38(%rsp)
     6e4:      	decl	%ebx
     6e6:      	jne	0x5c0 <execve_send+0x260>
     6ec:      	jmp	0x98b <execve_send+0x62b>
     6f1:      	nopw	%cs:(%rax,%rax)
     700:      	leaq	0x10(%r14), %rdx
     704:      	movl	$0x4, %eax
     709:      	movq	%rbp, %rdi
     70c:      	movl	$0x8, %esi
     711:      	callq	*%rax
     713:      	movq	0x48(%rsp), %rax
     718:      	cmpq	0x8(%rsp), %rax
     71d:      	je	0x986 <execve_send+0x626>
     723:      	addq	$0x18, %r14
     727:      	movl	$0x4, %eax
     72c:      	leaq	0x38(%rsp), %rdi
     731:      	movl	$0x8, %esi
     736:      	movq	%r14, %rdx
     739:      	callq	*%rax
     73b:      	movq	0x8(%rsp), %rax
     740:      	movq	%rax, 0x48(%rsp)
     745:      	addq	$0x20, %rax
     749:      	movq	%rax, 0x40(%rsp)
     74e:      	decl	%ebx
     750:      	jne	0x5c0 <execve_send+0x260>
     756:      	jmp	0x98b <execve_send+0x62b>
     75b:      	leaq	0x18(%rbx), %rdx
     75f:      	leaq	0x20(%rsp), %rdi
     764:      	movl	$0x8, %ecx
     769:      	movl	$0x4, %eax
     76e:      	movl	$0x8, %esi
     773:      	callq	*%rax
     775:      	cmpq	%rbx, 0x20(%rsp)
     77a:      	je	0x4bc <execve_send+0x15c>
     780:      	movl	0x1840(%rbp), %ecx
     786:      	leal	-0xa(%rcx), %eax
     789:      	movl	%eax, 0x1840(%rbp)
     78f:      	cmpl	$0x9, %ecx
     792:      	movq	0x60(%rsp), %rcx
     797:      	jg	0xf74 <execve_send+0xc14>
     79d:      	movl	$0xffffffdc, 0x1844(%rbp) # imm = 0xFFFFFFDC
     7a7:      	jmp	0x981 <execve_send+0x621>
     7ac:      	movl	$0x800, %ebx            # imm = 0x800
     7b1:      	movl	$0x8, %r13d
     7b7:      	leaq	0x8(%rsp), %rbp
     7bc:      	jmp	0x7c8 <execve_send+0x468>
     7be:      	nop
     7c0:      	decl	%ebx
     7c2:      	je	0x98b <execve_send+0x62b>
     7c8:      	movq	0x38(%rsp), %r15
     7cd:      	movq	0x40(%rsp), %rdx
     7d2:      	movq	0x48(%rsp), %r14
     7d7:      	cmpq	0x20(%rsp), %r15
     7dc:      	jne	0x7e9 <execve_send+0x489>
     7de:      	cmpq	0x28(%rsp), %rdx
     7e3:      	je	0x94f <execve_send+0x5ef>
     7e9:      	movl	$0x4, %eax
     7ee:      	leaq	0x70(%rsp), %rdi
     7f3:      	movl	$0x8, %esi
     7f8:      	callq	*%rax
     7fa:      	cmpq	0x70(%rsp), %r15
     7ff:      	je	0x900 <execve_send+0x5a0>
     805:      	leaq	0x18(%r15), %r12
     809:      	movl	$0x4, %eax
     80e:      	movq	%rbp, %rdi
     811:      	movl	$0x8, %esi
     816:      	movq	%r12, %rdx
     819:      	callq	*%rax
     81b:      	cmpq	%r15, 0x8(%rsp)
     820:      	je	0x900 <execve_send+0x5a0>
     826:      	movl	$0x4, %eax
     82b:      	leaq	0x68(%rsp), %rdi
     830:      	movl	$0x8, %esi
     835:      	movq	%r12, %rdx
     838:      	callq	*%rax
     83a:      	addq	$0x20, %r15
     83e:      	movl	$0x4, %eax
     843:      	leaq	0x10(%rsp), %rdi
     848:      	movl	$0x10, %ecx
     84d:      	movl	$0x10, %esi
     852:      	movq	%r15, %rdx
     855:      	callq	*%rax
     857:      	movq	0x30(%rsp), %r14
     85c:      	movq	0x50(%rsp), %rax
     861:      	movl	0x14(%rsp), %r15d
     866:      	subq	%r14, %rax
     869:      	movl	0x58(%rsp), %r12d
     86e:      	movl	%r15d, %edx
     871:      	subl	%r12d, %edx
     874:      	movl	$0x0, %ecx
     879:      	cmovbl	%ecx, %edx
     87c:      	addq	0x18(%rsp), %rdx
     881:      	xorl	%esi, %esi
     883:      	cmpl	%r15d, %r12d
     886:      	seta	%sil
     88a:      	movl	%r15d, %ecx
     88d:      	cmovbl	%r12d, %ecx
     891:      	addl	%ecx, %esi
     893:      	movl	%r12d, %edi
     896:      	subl	%esi, %edi
     898:      	movl	%edi, 0x58(%rsp)
     89c:      	subq	%rsi, %rax
     89f:      	jb	0x98b <execve_send+0x62b>
     8a5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     8ab:      	ja	0x98b <execve_send+0x62b>
     8b1:      	cmpl	%r15d, %r12d
     8b4:      	jbe	0x8bb <execve_send+0x55b>
     8b6:      	movb	$0x2f, (%r14,%rax)
     8bb:      	xorl	%edi, %edi
     8bd:      	cmpl	%r15d, %r12d
     8c0:      	seta	%dil
     8c4:      	movzbl	%cl, %esi
     8c7:      	addq	%rax, %r14
     8ca:      	addq	%r14, %rdi
     8cd:      	movl	$0x4, %eax
     8d2:      	callq	*%rax
     8d4:      	movq	%r14, 0x50(%rsp)
     8d9:      	cmpl	%r15d, %r12d
     8dc:      	jbe	0x98b <execve_send+0x62b>
     8e2:      	movq	0x68(%rsp), %rax
     8e7:      	movq	%rax, 0x38(%rsp)
     8ec:      	jmp	0x7c0 <execve_send+0x460>
     8f1:      	nopw	%cs:(%rax,%rax)
     900:      	leaq	0x10(%r14), %rdx
     904:      	movl	$0x4, %eax
     909:      	movq	%rbp, %rdi
     90c:      	movl	$0x8, %esi
     911:      	callq	*%rax
     913:      	movq	0x48(%rsp), %rax
     918:      	cmpq	0x8(%rsp), %rax
     91d:      	je	0x986 <execve_send+0x626>
     91f:      	addq	$0x18, %r14
     923:      	movl	$0x4, %eax
     928:      	leaq	0x38(%rsp), %rdi
     92d:      	movl	$0x8, %esi
     932:      	movq	%r14, %rdx
     935:      	callq	*%rax
     937:      	movq	0x8(%rsp), %rax
     93c:      	movq	%rax, 0x48(%rsp)
     941:      	addq	$0x20, %rax
     945:      	movq	%rax, 0x40(%rsp)
     94a:      	jmp	0x7c0 <execve_send+0x460>
     94f:      	movb	$0x1, 0x5c(%rsp)
     954:      	movq	0x50(%rsp), %r14
     959:      	movq	0x60(%rsp), %rcx
     95e:      	cmpq	%rcx, %r14
     961:      	jne	0x99a <execve_send+0x63a>
     963:      	movq	0x80(%rsp), %rbp
     96b:      	movl	$0x0, 0x1840(%rbp)
     975:      	movl	$0x0, 0x1844(%rbp)
     97f:      	xorl	%eax, %eax
     981:      	movq	%rcx, %r14
     984:      	jmp	0x9da <execve_send+0x67a>
     986:      	movb	$0x1, 0x5c(%rsp)
     98b:      	movq	0x50(%rsp), %r14
     990:      	movq	0x60(%rsp), %rcx
     995:      	cmpq	%rcx, %r14
     998:      	je	0x963 <execve_send+0x603>
     99a:      	xorl	%ecx, %ecx
     99c:      	cmpb	$0x0, 0x5c(%rsp)
     9a1:      	sete	%cl
     9a4:      	addl	%ecx, %ecx
     9a6:      	movl	0x58(%rsp), %eax
     9aa:      	movq	0x80(%rsp), %rbp
     9b2:      	movl	%eax, 0x1840(%rbp)
     9b8:      	movl	%ecx, 0x1844(%rbp)
     9be:      	testl	%eax, %eax
     9c0:      	jle	0x9d1 <execve_send+0x671>
     9c2:      	movl	$0x1000, %ecx           # imm = 0x1000
     9c7:      	subl	%eax, %ecx
     9c9:      	movl	%ecx, 0x1840(%rbp)
     9cf:      	movl	%ecx, %eax
     9d1:      	testq	%r14, %r14
     9d4:      	je	0xaf1 <execve_send+0x791>
     9da:      	xorl	%ecx, %ecx
     9dc:      	movl	%eax, %ebx
     9de:      	subl	$0x7f, %ebx
     9e1:      	movl	$0x7f, %r15d
     9e7:      	cmovbl	%eax, %r15d
     9eb:      	cmovbl	%ecx, %ebx
     9ee:      	cmpl	$0xff, %eax
     9f3:      	movl	$0xff, %ecx
     9f8:      	cmovbl	%eax, %ecx
     9fb:      	movzbl	%cl, %esi
     9fe:      	movl	%esi, 0x1840(%rbp)
     a04:      	movl	$0x4, %eax
     a09:      	movq	0x88(%rsp), %rdi
     a11:      	movq	%r14, %rdx
     a14:      	callq	*%rax
     a16:      	testq	%rax, %rax
     a19:      	je	0xa78 <execve_send+0x718>
     a1b:      	negl	%eax
     a1d:      	movw	%ax, 0x20(%rsp)
     a22:      	movw	$0x8, 0x22(%rsp)
     a29:      	movabsq	$0x4000002de, %rax      # imm = 0x4000002DE
     a33:      	movq	%rax, 0x24(%rsp)
     a38:      	movq	(%rip), %rdi            # 0xa3f <execve_send+0x6df>
     a3f:      	leaq	0x20(%rsp), %rsi
     a44:      	movl	$0x1, %eax
     a49:      	callq	*%rax
     a4b:      	testq	%rax, %rax
     a4e:      	je	0xa54 <execve_send+0x6f4>
     a50:      	incl	(%rax)
     a52:      	jmp	0xa78 <execve_send+0x718>
     a54:      	movl	$0x1, 0x10(%rsp)
     a5c:      	movq	(%rip), %rdi            # 0xa63 <execve_send+0x703>
     a63:      	xorl	%ecx, %ecx
     a65:      	leaq	0x20(%rsp), %rsi
     a6a:      	leaq	0x10(%rsp), %rdx
     a6f:      	movl	$0x2, %eax
     a74:      	xorl	%ecx, %ecx
     a76:      	callq	*%rax
     a78:      	leaq	0x17c0(%rbp), %rdi
     a7f:      	addq	%rbx, %r14
     a82:      	movl	$0x4, %eax
     a87:      	movl	%r15d, %esi
     a8a:      	movq	%r14, %rdx
     a8d:      	callq	*%rax
     a8f:      	testq	%rax, %rax
     a92:      	je	0xaf1 <execve_send+0x791>
     a94:      	negl	%eax
     a96:      	movw	%ax, 0x20(%rsp)
     a9b:      	movw	$0x8, 0x22(%rsp)
     aa2:      	movabsq	$0x4000002e0, %rax      # imm = 0x4000002E0
     aac:      	movq	%rax, 0x24(%rsp)
     ab1:      	movq	(%rip), %rdi            # 0xab8 <execve_send+0x758>
     ab8:      	leaq	0x20(%rsp), %rsi
     abd:      	movl	$0x1, %eax
     ac2:      	callq	*%rax
     ac4:      	testq	%rax, %rax
     ac7:      	je	0xacd <execve_send+0x76d>
     ac9:      	incl	(%rax)
     acb:      	jmp	0xaf1 <execve_send+0x791>
     acd:      	movl	$0x1, 0x10(%rsp)
     ad5:      	movq	(%rip), %rdi            # 0xadc <execve_send+0x77c>
     adc:      	xorl	%ecx, %ecx
     ade:      	leaq	0x20(%rsp), %rsi
     ae3:      	leaq	0x10(%rsp), %rdx
     ae8:      	movl	$0x2, %eax
     aed:      	xorl	%ecx, %ecx
     aef:      	callq	*%rax
     af1:      	movl	$0xe, %eax
     af6:      	callq	*%rax
     af8:      	shrq	$0x20, %rax
     afc:      	movl	%eax, 0x20(%rsp)
     b00:      	movq	(%rip), %rdi            # 0xb07 <execve_send+0x7a7>
     b07:      	leaq	0x20(%rsp), %rsi
     b0c:      	movl	$0x1, %eax
     b11:      	callq	*%rax
     b13:      	testq	%rax, %rax
     b16:      	je	0x1354 <execve_send+0xff4>
     b1c:      	movq	%rax, %r12
     b1f:      	movq	(%rax), %rax
     b22:      	movq	0x8(%r12), %rcx
     b27:      	movq	%rcx, 0x138(%rbp)
     b2e:      	movq	%rax, 0x130(%rbp)
     b35:      	movl	0x20(%r12), %eax
     b3a:      	movl	0x144(%rbp), %ecx
     b40:      	movl	%ecx, (%r12)
     b44:      	movq	0x170(%rbp), %rcx
     b4b:      	movq	%rcx, 0x8(%r12)
     b50:      	movl	0x14c(%rbp), %ecx
     b56:      	movl	%ecx, 0x24(%r12)
     b5b:      	movq	0xa0(%rbp), %rdx
     b62:      	movq	0xa8(%rbp), %rsi
     b69:      	movq	%rdx, 0x10(%r12)
     b6e:      	movq	%rsi, 0x18(%r12)
     b73:      	testb	$0x1, %al
     b75:      	je	0xb7e <execve_send+0x81e>
     b77:      	orb	$0x40, 0x15d(%rbp)
     b7e:      	movl	%eax, %edx
     b80:      	andl	$-0x2, %edx
     b83:      	movl	%edx, %esi
     b85:      	orl	$0x2000000, %esi        # imm = 0x2000000
     b8b:      	cmpl	$0x1, %ecx
     b8e:      	cmovnel	%edx, %esi
     b91:      	movl	%esi, 0x20(%r12)
     b96:      	testl	$0x2000000, %esi        # imm = 0x2000000
     b9c:      	jne	0xc14 <execve_send+0x8b4>
     b9e:      	cmpl	$0x1, %eax
     ba1:      	jne	0xc20 <execve_send+0x8c0>
     ba3:      	movq	0x128(%rbp), %rax
     baa:      	movq	%rax, 0x48(%r12)
     baf:      	movq	0x120(%rbp), %rax
     bb6:      	movq	%rax, 0x40(%r12)
     bbb:      	movq	0x118(%rbp), %rax
     bc2:      	movq	%rax, 0x38(%r12)
     bc7:      	movq	0x108(%rbp), %rax
     bce:      	movq	0x110(%rbp), %rcx
     bd5:      	movq	%rcx, 0x30(%r12)
     bda:      	movq	%rax, 0x28(%r12)
     bdf:      	movq	0xe0(%rbp), %rax
     be6:      	movq	%rax, 0x50(%r12)
     beb:      	movq	0xe8(%rbp), %rax
     bf2:      	movq	%rax, 0x58(%r12)
     bf7:      	movq	0xf0(%rbp), %rax
     bfe:      	movq	%rax, 0x60(%r12)
     c03:      	movq	(%rip), %rax            # 0xc0a <execve_send+0x8aa>
     c0a:      	cmpb	$0x0, (%rax)
     c0d:      	jne	0xc30 <execve_send+0x8d0>
     c0f:      	jmp	0xed6 <execve_send+0xb76>
     c14:      	orb	$0x2, 0x15f(%rbp)
     c1b:      	cmpl	$0x1, %eax
     c1e:      	je	0xba3 <execve_send+0x843>
     c20:      	movq	(%rip), %rax            # 0xc27 <execve_send+0x8c7>
     c27:      	cmpb	$0x0, (%rax)
     c2a:      	je	0xed6 <execve_send+0xb76>
     c30:      	movl	$0x0, 0x68(%rsp)
     c38:      	movq	(%rip), %rdi            # 0xc3f <execve_send+0x8df>
     c3f:      	leaq	0x68(%rsp), %rsi
     c44:      	movl	$0x1, %eax
     c49:      	callq	*%rax
     c4b:      	testq	%rax, %rax
     c4e:      	je	0xed6 <execve_send+0xb76>
     c54:      	testb	$0x40, 0x15d(%rbp)
     c5b:      	jne	0xc8b <execve_send+0x92b>
     c5d:      	leaq	0x68(%r12), %rsi
     c62:      	movl	$0x318, %edx            # imm = 0x318
     c67:      	movq	%rax, %rdi
     c6a:      	movq	%rax, %rbx
     c6d:      	callq	0xc72 <execve_send+0x912>
     c72:      	movq	(%rip), %rdi            # 0xc79 <execve_send+0x919>
     c79:      	xorl	%ecx, %ecx
     c7b:      	movl	$0x2, %eax
     c80:      	movq	%r12, %rsi
     c83:      	movq	%rbx, %rdx
     c86:      	jmp	0xed2 <execve_send+0xb72>
     c8b:      	movl	$0x23, %eax
     c90:      	callq	*%rax
     c92:      	movq	%rax, %rcx
     c95:      	movq	%rax, 0x20(%rsp)
     c9a:      	addq	$0xb00, %rcx            # imm = 0xB00
     ca1:      	leaq	0x20(%rsp), %rdi
     ca6:      	movl	$0x8, %edx
     cab:      	movl	$0x71, %eax
     cb0:      	movl	$0xb00, %edx            # imm = 0xB00
     cb5:      	addq	0x20(%rsp), %rdx
     cba:      	movl	$0x8, %esi
     cbf:      	callq	*%rax
     cc1:      	movq	0x20(%rsp), %rcx
     cc6:      	testq	%rcx, %rcx
     cc9:      	je	0xed6 <execve_send+0xb76>
     ccf:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     cd6:      	leaq	0x8(%rsp), %rdi
     cdb:      	movl	$0x4, %edx
     ce0:      	movl	$0x71, %eax
     ce5:      	movl	$0xaf4, %edx            # imm = 0xAF4
     cea:      	addq	0x20(%rsp), %rdx
     cef:      	movl	$0x4, %esi
     cf4:      	callq	*%rax
     cf6:      	movl	0x8(%rsp), %eax
     cfa:      	movl	%eax, 0x10(%rsp)
     cfe:      	movq	(%rip), %rdi            # 0xd05 <execve_send+0x9a5>
     d05:      	leaq	0x10(%rsp), %rsi
     d0a:      	movl	$0x1, %eax
     d0f:      	callq	*%rax
     d11:      	testq	%rax, %rax
     d14:      	je	0xd24 <execve_send+0x9c4>
     d16:      	movq	%rax, %rdx
     d19:      	cmpq	$0x0, 0x8(%rax)
     d1e:      	jne	0xebd <execve_send+0xb5d>
     d24:      	movl	$0xb00, %edx            # imm = 0xB00
     d29:      	movq	0x20(%rsp), %rcx
     d2e:      	addq	%rdx, %rcx
     d31:      	leaq	0x20(%rsp), %rdi
     d36:      	movl	$0x8, %esi
     d3b:      	movl	$0x71, %eax
     d40:      	addq	0x20(%rsp), %rdx
     d45:      	movl	$0x8, %esi
     d4a:      	callq	*%rax
     d4c:      	movq	0x20(%rsp), %rcx
     d51:      	testq	%rcx, %rcx
     d54:      	je	0xed6 <execve_send+0xb76>
     d5a:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     d61:      	leaq	0x8(%rsp), %rdi
     d66:      	movl	$0x4, %edx
     d6b:      	movl	$0x71, %eax
     d70:      	movl	$0xaf4, %edx            # imm = 0xAF4
     d75:      	addq	0x20(%rsp), %rdx
     d7a:      	movl	$0x4, %esi
     d7f:      	callq	*%rax
     d81:      	movl	0x8(%rsp), %eax
     d85:      	movl	%eax, 0x10(%rsp)
     d89:      	movq	(%rip), %rdi            # 0xd90 <execve_send+0xa30>
     d90:      	leaq	0x10(%rsp), %rsi
     d95:      	movl	$0x1, %eax
     d9a:      	callq	*%rax
     d9c:      	testq	%rax, %rax
     d9f:      	je	0xdaf <execve_send+0xa4f>
     da1:      	movq	%rax, %rdx
     da4:      	cmpq	$0x0, 0x8(%rax)
     da9:      	jne	0xebd <execve_send+0xb5d>
     daf:      	movl	$0xb00, %edx            # imm = 0xB00
     db4:      	movq	0x20(%rsp), %rcx
     db9:      	addq	%rdx, %rcx
     dbc:      	leaq	0x20(%rsp), %rdi
     dc1:      	movl	$0x8, %esi
     dc6:      	movl	$0x71, %eax
     dcb:      	addq	0x20(%rsp), %rdx
     dd0:      	movl	$0x8, %esi
     dd5:      	callq	*%rax
     dd7:      	movq	0x20(%rsp), %rcx
     ddc:      	testq	%rcx, %rcx
     ddf:      	je	0xed6 <execve_send+0xb76>
     de5:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     dec:      	leaq	0x8(%rsp), %rdi
     df1:      	movl	$0x4, %edx
     df6:      	movl	$0x71, %eax
     dfb:      	movl	$0xaf4, %edx            # imm = 0xAF4
     e00:      	addq	0x20(%rsp), %rdx
     e05:      	movl	$0x4, %esi
     e0a:      	callq	*%rax
     e0c:      	movl	0x8(%rsp), %eax
     e10:      	movl	%eax, 0x10(%rsp)
     e14:      	movq	(%rip), %rdi            # 0xe1b <execve_send+0xabb>
     e1b:      	leaq	0x10(%rsp), %rsi
     e20:      	movl	$0x1, %eax
     e25:      	callq	*%rax
     e27:      	testq	%rax, %rax
     e2a:      	je	0xe3a <execve_send+0xada>
     e2c:      	movq	%rax, %rdx
     e2f:      	cmpq	$0x0, 0x8(%rax)
     e34:      	jne	0xebd <execve_send+0xb5d>
     e3a:      	movl	$0xb00, %edx            # imm = 0xB00
     e3f:      	movq	0x20(%rsp), %rcx
     e44:      	addq	%rdx, %rcx
     e47:      	leaq	0x20(%rsp), %rdi
     e4c:      	movl	$0x8, %esi
     e51:      	movl	$0x71, %eax
     e56:      	addq	0x20(%rsp), %rdx
     e5b:      	movl	$0x8, %esi
     e60:      	callq	*%rax
     e62:      	movq	0x20(%rsp), %rcx
     e67:      	testq	%rcx, %rcx
     e6a:      	je	0xed6 <execve_send+0xb76>
     e6c:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     e73:      	leaq	0x8(%rsp), %rdi
     e78:      	movl	$0x4, %edx
     e7d:      	movl	$0x71, %eax
     e82:      	movl	$0xaf4, %edx            # imm = 0xAF4
     e87:      	addq	0x20(%rsp), %rdx
     e8c:      	movl	$0x4, %esi
     e91:      	callq	*%rax
     e93:      	movl	0x8(%rsp), %eax
     e97:      	movl	%eax, 0x10(%rsp)
     e9b:      	movq	(%rip), %rdi            # 0xea2 <execve_send+0xb42>
     ea2:      	leaq	0x10(%rsp), %rsi
     ea7:      	movl	$0x1, %eax
     eac:      	callq	*%rax
     eae:      	testq	%rax, %rax
     eb1:      	je	0xed6 <execve_send+0xb76>
     eb3:      	movq	%rax, %rdx
     eb6:      	cmpq	$0x0, 0x8(%rax)
     ebb:      	je	0xed6 <execve_send+0xb76>
     ebd:      	addq	$0x68, %rdx
     ec1:      	movq	(%rip), %rdi            # 0xec8 <execve_send+0xb68>
     ec8:      	xorl	%ecx, %ecx
     eca:      	movl	$0x2, %eax
     ecf:      	movq	%r12, %rsi
     ed2:      	xorl	%ecx, %ecx
     ed4:      	callq	*%rax
     ed6:      	leaq	0x140(%rbp), %r13
     edd:      	leaq	0x68(%r12), %r14
     ee2:      	movl	$0x308, %edx            # imm = 0x308
     ee7:      	movq	%r14, %rdi
     eea:      	xorl	%esi, %esi
     eec:      	callq	0xef1 <execve_send+0xb91>
     ef1:      	movl	0x1840(%rbp), %eax
     ef7:      	leal	-0x101(%rax), %ecx
     efd:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
     f03:      	ja	0xf11 <execve_send+0xbb1>
     f05:      	movl	$0xffffffff, (%r14)     # imm = 0xFFFFFFFF
     f0c:      	jmp	0x1058 <execve_send+0xcf8>
     f11:      	movzbl	%al, %r14d
     f15:      	leaq	0x70(%r12), %rdi
     f1a:      	movl	$0x4, %eax
     f1f:      	movq	0x88(%rsp), %rdx
     f27:      	movl	%r14d, %esi
     f2a:      	callq	*%rax
     f2c:      	movq	%rax, %r15
     f2f:      	testq	%rax, %rax
     f32:      	je	0xfc4 <execve_send+0xc64>
     f38:      	movl	%r15d, %eax
     f3b:      	negl	%eax
     f3d:      	movw	%ax, 0x20(%rsp)
     f42:      	movw	$0xf, 0x22(%rsp)
     f49:      	movabsq	$0x400000164, %rax      # imm = 0x400000164
     f53:      	movq	%rax, 0x24(%rsp)
     f58:      	movq	(%rip), %rdi            # 0xf5f <execve_send+0xbff>
     f5f:      	leaq	0x20(%rsp), %rsi
     f64:      	movl	$0x1, %eax
     f69:      	callq	*%rax
     f6b:      	testq	%rax, %rax
     f6e:      	je	0xfa0 <execve_send+0xc40>
     f70:      	incl	(%rax)
     f72:      	jmp	0xfc4 <execve_send+0xc64>
     f74:      	movq	%r12, %rcx
     f77:      	addq	$0xff6, %rcx            # imm = 0xFF6
     f7e:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
     f88:      	movq	%rax, 0xff6(%r12)
     f90:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
     f9b:      	jmp	0x4c1 <execve_send+0x161>
     fa0:      	movl	$0x1, 0x10(%rsp)
     fa8:      	movq	(%rip), %rdi            # 0xfaf <execve_send+0xc4f>
     faf:      	xorl	%ecx, %ecx
     fb1:      	leaq	0x20(%rsp), %rsi
     fb6:      	leaq	0x10(%rsp), %rdx
     fbb:      	movl	$0x2, %eax
     fc0:      	xorl	%ecx, %ecx
     fc2:      	callq	*%rax
     fc4:      	testl	%r15d, %r15d
     fc7:      	cmovel	%r14d, %r15d
     fcb:      	movl	%r15d, 0x68(%r12)
     fd0:      	cmpl	$0x7f, %r14d
     fd4:      	movl	$0x7f, %esi
     fd9:      	cmovbl	%r14d, %esi
     fdd:      	leaq	0x170(%r12), %rdi
     fe5:      	movq	%rbp, %rdx
     fe8:      	addq	$0x17c0, %rdx           # imm = 0x17C0
     fef:      	movl	$0x4, %eax
     ff4:      	callq	*%rax
     ff6:      	testq	%rax, %rax
     ff9:      	je	0x1058 <execve_send+0xcf8>
     ffb:      	negl	%eax
     ffd:      	movw	%ax, 0x20(%rsp)
    1002:      	movw	$0xf, 0x22(%rsp)
    1009:      	movabsq	$0x40000016a, %rax      # imm = 0x40000016A
    1013:      	movq	%rax, 0x24(%rsp)
    1018:      	movq	(%rip), %rdi            # 0x101f <execve_send+0xcbf>
    101f:      	leaq	0x20(%rsp), %rsi
    1024:      	movl	$0x1, %eax
    1029:      	callq	*%rax
    102b:      	testq	%rax, %rax
    102e:      	je	0x1034 <execve_send+0xcd4>
    1030:      	incl	(%rax)
    1032:      	jmp	0x1058 <execve_send+0xcf8>
    1034:      	movl	$0x1, 0x10(%rsp)
    103c:      	movq	(%rip), %rdi            # 0x1043 <execve_send+0xce3>
    1043:      	xorl	%ecx, %ecx
    1045:      	leaq	0x20(%rsp), %rsi
    104a:      	leaq	0x10(%rsp), %rdx
    104f:      	movl	$0x2, %eax
    1054:      	xorl	%ecx, %ecx
    1056:      	callq	*%rax
    1058:      	movl	0x1848(%rbp), %eax
    105e:      	movl	0x184c(%rbp), %ecx
    1064:      	cmpl	$0xfe, %eax
    1069:      	movl	$0xfe, %r14d
    106f:      	cmovbl	%eax, %r14d
    1073:      	leaq	0x270(%r12), %rdi
    107b:      	addq	%rcx, %r13
    107e:      	movl	$0x4, %eax
    1083:      	movl	%r14d, %esi
    1086:      	movq	%r13, %rdx
    1089:      	callq	*%rax
    108b:      	testq	%rax, %rax
    108e:      	je	0x10ed <execve_send+0xd8d>
    1090:      	negl	%eax
    1092:      	movw	%ax, 0x20(%rsp)
    1097:      	movw	$0x9, 0x22(%rsp)
    109e:      	movabsq	$0x4000001af, %rax      # imm = 0x4000001AF
    10a8:      	movq	%rax, 0x24(%rsp)
    10ad:      	movq	(%rip), %rdi            # 0x10b4 <execve_send+0xd54>
    10b4:      	leaq	0x20(%rsp), %rsi
    10b9:      	movl	$0x1, %eax
    10be:      	callq	*%rax
    10c0:      	testq	%rax, %rax
    10c3:      	je	0x10c9 <execve_send+0xd69>
    10c5:      	incl	(%rax)
    10c7:      	jmp	0x10ed <execve_send+0xd8d>
    10c9:      	movl	$0x1, 0x10(%rsp)
    10d1:      	movq	(%rip), %rdi            # 0x10d8 <execve_send+0xd78>
    10d8:      	xorl	%ecx, %ecx
    10da:      	leaq	0x20(%rsp), %rsi
    10df:      	leaq	0x10(%rsp), %rdx
    10e4:      	movl	$0x2, %eax
    10e9:      	xorl	%ecx, %ecx
    10eb:      	callq	*%rax
    10ed:      	movw	$0x0, 0x270(%r12,%r14)
    10f8:      	movl	$0x23, %eax
    10fd:      	callq	*%rax
    10ff:      	movq	%rax, %rcx
    1102:      	movq	%rax, 0x20(%rsp)
    1107:      	addq	$0xb00, %rcx            # imm = 0xB00
    110e:      	leaq	0x20(%rsp), %rdi
    1113:      	movl	$0x8, %edx
    1118:      	movl	$0x71, %eax
    111d:      	movl	$0xb00, %edx            # imm = 0xB00
    1122:      	addq	0x20(%rsp), %rdx
    1127:      	movl	$0x8, %esi
    112c:      	callq	*%rax
    112e:      	movq	0x20(%rsp), %rcx
    1133:      	testq	%rcx, %rcx
    1136:      	je	0x132e <execve_send+0xfce>
    113c:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    1143:      	leaq	0x8(%rsp), %rdi
    1148:      	movl	$0x4, %edx
    114d:      	movl	$0x71, %eax
    1152:      	movl	$0xaf4, %edx            # imm = 0xAF4
    1157:      	addq	0x20(%rsp), %rdx
    115c:      	movl	$0x4, %esi
    1161:      	callq	*%rax
    1163:      	movl	0x8(%rsp), %eax
    1167:      	movl	%eax, 0x10(%rsp)
    116b:      	movq	(%rip), %rdi            # 0x1172 <execve_send+0xe12>
    1172:      	leaq	0x10(%rsp), %rsi
    1177:      	movl	$0x1, %eax
    117c:      	callq	*%rax
    117e:      	testq	%rax, %rax
    1181:      	je	0x118e <execve_send+0xe2e>
    1183:      	cmpq	$0x0, 0x8(%rax)
    1188:      	jne	0x131e <execve_send+0xfbe>
    118e:      	movl	$0xb00, %edx            # imm = 0xB00
    1193:      	movq	0x20(%rsp), %rcx
    1198:      	addq	%rdx, %rcx
    119b:      	leaq	0x20(%rsp), %rdi
    11a0:      	movl	$0x8, %esi
    11a5:      	movl	$0x71, %eax
    11aa:      	addq	0x20(%rsp), %rdx
    11af:      	movl	$0x8, %esi
    11b4:      	callq	*%rax
    11b6:      	movq	0x20(%rsp), %rcx
    11bb:      	testq	%rcx, %rcx
    11be:      	je	0x132e <execve_send+0xfce>
    11c4:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    11cb:      	leaq	0x8(%rsp), %rdi
    11d0:      	movl	$0x4, %edx
    11d5:      	movl	$0x71, %eax
    11da:      	movl	$0xaf4, %edx            # imm = 0xAF4
    11df:      	addq	0x20(%rsp), %rdx
    11e4:      	movl	$0x4, %esi
    11e9:      	callq	*%rax
    11eb:      	movl	0x8(%rsp), %eax
    11ef:      	movl	%eax, 0x10(%rsp)
    11f3:      	movq	(%rip), %rdi            # 0x11fa <execve_send+0xe9a>
    11fa:      	leaq	0x10(%rsp), %rsi
    11ff:      	movl	$0x1, %eax
    1204:      	callq	*%rax
    1206:      	testq	%rax, %rax
    1209:      	je	0x1216 <execve_send+0xeb6>
    120b:      	cmpq	$0x0, 0x8(%rax)
    1210:      	jne	0x131e <execve_send+0xfbe>
    1216:      	movl	$0xb00, %edx            # imm = 0xB00
    121b:      	movq	0x20(%rsp), %rcx
    1220:      	addq	%rdx, %rcx
    1223:      	leaq	0x20(%rsp), %rdi
    1228:      	movl	$0x8, %esi
    122d:      	movl	$0x71, %eax
    1232:      	addq	0x20(%rsp), %rdx
    1237:      	movl	$0x8, %esi
    123c:      	callq	*%rax
    123e:      	movq	0x20(%rsp), %rcx
    1243:      	testq	%rcx, %rcx
    1246:      	je	0x132e <execve_send+0xfce>
    124c:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    1253:      	leaq	0x8(%rsp), %rdi
    1258:      	movl	$0x4, %edx
    125d:      	movl	$0x71, %eax
    1262:      	movl	$0xaf4, %edx            # imm = 0xAF4
    1267:      	addq	0x20(%rsp), %rdx
    126c:      	movl	$0x4, %esi
    1271:      	callq	*%rax
    1273:      	movl	0x8(%rsp), %eax
    1277:      	movl	%eax, 0x10(%rsp)
    127b:      	movq	(%rip), %rdi            # 0x1282 <execve_send+0xf22>
    1282:      	leaq	0x10(%rsp), %rsi
    1287:      	movl	$0x1, %eax
    128c:      	callq	*%rax
    128e:      	testq	%rax, %rax
    1291:      	je	0x129e <execve_send+0xf3e>
    1293:      	cmpq	$0x0, 0x8(%rax)
    1298:      	jne	0x131e <execve_send+0xfbe>
    129e:      	movl	$0xb00, %edx            # imm = 0xB00
    12a3:      	movq	0x20(%rsp), %rcx
    12a8:      	addq	%rdx, %rcx
    12ab:      	leaq	0x20(%rsp), %rdi
    12b0:      	movl	$0x8, %esi
    12b5:      	movl	$0x71, %eax
    12ba:      	addq	0x20(%rsp), %rdx
    12bf:      	movl	$0x8, %esi
    12c4:      	callq	*%rax
    12c6:      	movq	0x20(%rsp), %rcx
    12cb:      	testq	%rcx, %rcx
    12ce:      	je	0x132e <execve_send+0xfce>
    12d0:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    12d7:      	leaq	0x8(%rsp), %rdi
    12dc:      	movl	$0x4, %edx
    12e1:      	movl	$0x71, %eax
    12e6:      	movl	$0xaf4, %edx            # imm = 0xAF4
    12eb:      	addq	0x20(%rsp), %rdx
    12f0:      	movl	$0x4, %esi
    12f5:      	callq	*%rax
    12f7:      	movl	0x8(%rsp), %eax
    12fb:      	movl	%eax, 0x10(%rsp)
    12ff:      	movq	(%rip), %rdi            # 0x1306 <execve_send+0xfa6>
    1306:      	leaq	0x10(%rsp), %rsi
    130b:      	movl	$0x1, %eax
    1310:      	callq	*%rax
    1312:      	testq	%rax, %rax
    1315:      	je	0x132e <execve_send+0xfce>
    1317:      	cmpq	$0x0, 0x8(%rax)
    131c:      	je	0x132e <execve_send+0xfce>
    131e:      	movq	0x370(%rax), %rax
    1325:      	lock
    1326:      	orq	%rax, 0x370(%r12)
    132e:      	movq	%r12, %rsi
    1331:      	addq	$0x70, %rsi
    1335:      	movq	(%rip), %rdi            # 0x133c <execve_send+0xfdc>
    133c:      	movl	$0x1, %eax
    1341:      	callq	*%rax
    1343:      	testq	%rax, %rax
    1346:      	je	0x1354 <execve_send+0xff4>
    1348:      	movq	(%rax), %rax
    134b:      	lock
    134c:      	orq	%rax, 0x370(%r12)
    1354:      	movb	$0x0, 0x1(%rbp)
    1358:      	movl	0x140(%rbp), %eax
    135e:      	cmpl	$0x1710, %eax           # imm = 0x1710
    1363:      	movl	$0x1710, %r14d          # imm = 0x1710
    1369:      	cmovbl	%eax, %r14d
    136d:      	movl	$0x0, 0x10(%rsp)
    1375:      	movq	(%rip), %rdi            # 0x137c <execve_send+0x101c>
    137c:      	leaq	0x10(%rsp), %rsi
    1381:      	movl	$0x1, %eax
    1386:      	addl	$0x140, %r14d           # imm = 0x140
    138d:      	callq	*%rax
    138f:      	testq	%rax, %rax
    1392:      	je	0x1419 <execve_send+0x10b9>
    1398:      	cmpb	$0x0, 0x28(%rax)
    139c:      	je	0x1419 <execve_send+0x10b9>
    139e:      	movq	(%rip), %rsi            # 0x13a5 <execve_send+0x1045>
    13a5:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    13aa:      	movl	$0x19, %eax
    13af:      	movq	0x90(%rsp), %rdi
    13b7:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    13bc:      	movq	%rbp, %rcx
    13bf:      	movq	%r14, %r8
    13c2:      	callq	*%rax
    13c4:      	testq	%rax, %rax
    13c7:      	jns	0x14cb <execve_send+0x116b>
    13cd:      	movq	%rax, %rbx
    13d0:      	movl	$0x0, 0x20(%rsp)
    13d8:      	movq	(%rip), %rdi            # 0x13df <execve_send+0x107f>
    13df:      	leaq	0x20(%rsp), %rsi
    13e4:      	movl	$0x1, %eax
    13e9:      	callq	*%rax
    13eb:      	testq	%rax, %rax
    13ee:      	je	0x14cb <execve_send+0x116b>
    13f4:      	cmpq	$-0xc, %rbx
    13f8:      	jg	0x1497 <execve_send+0x1137>
    13fe:      	cmpq	$-0x1c, %rbx
    1402:      	je	0x14b1 <execve_send+0x1151>
    1408:      	cmpq	$-0x16, %rbx
    140c:      	jne	0x146f <execve_send+0x110f>
    140e:      	addq	$0x138, %rax            # imm = 0x138
    1414:      	jmp	0x14c7 <execve_send+0x1167>
    1419:      	movq	(%rip), %rdi            # 0x1420 <execve_send+0x10c0>
    1420:      	xorl	%ecx, %ecx
    1422:      	movl	$0x82, %eax
    1427:      	movq	%rbp, %rsi
    142a:      	movq	%r14, %rdx
    142d:      	xorl	%ecx, %ecx
    142f:      	callq	*%rax
    1431:      	testq	%rax, %rax
    1434:      	jns	0x14cb <execve_send+0x116b>
    143a:      	movq	%rax, %rbx
    143d:      	movl	$0x0, 0x20(%rsp)
    1445:      	movq	(%rip), %rdi            # 0x144c <execve_send+0x10ec>
    144c:      	leaq	0x20(%rsp), %rsi
    1451:      	movl	$0x1, %eax
    1456:      	callq	*%rax
    1458:      	testq	%rax, %rax
    145b:      	je	0x14cb <execve_send+0x116b>
    145d:      	cmpq	$-0xc, %rbx
    1461:      	jg	0x147d <execve_send+0x111d>
    1463:      	cmpq	$-0x1c, %rbx
    1467:      	je	0x14b1 <execve_send+0x1151>
    1469:      	cmpq	$-0x16, %rbx
    146d:      	je	0x140e <execve_send+0x10ae>
    146f:      	cmpq	$-0x10, %rbx
    1473:      	jne	0x14a9 <execve_send+0x1149>
    1475:      	addq	$0x130, %rax            # imm = 0x130
    147b:      	jmp	0x14c7 <execve_send+0x1167>
    147d:      	cmpq	$-0xb, %rbx
    1481:      	je	0x14b9 <execve_send+0x1159>
    1483:      	cmpq	$-0x7, %rbx
    1487:      	je	0x14c1 <execve_send+0x1161>
    1489:      	cmpq	$-0x2, %rbx
    148d:      	jne	0x14a9 <execve_send+0x1149>
    148f:      	addq	$0x120, %rax            # imm = 0x120
    1495:      	jmp	0x14c7 <execve_send+0x1167>
    1497:      	cmpq	$-0xb, %rbx
    149b:      	je	0x14b9 <execve_send+0x1159>
    149d:      	cmpq	$-0x7, %rbx
    14a1:      	je	0x14c1 <execve_send+0x1161>
    14a3:      	cmpq	$-0x2, %rbx
    14a7:      	je	0x148f <execve_send+0x112f>
    14a9:      	addq	$0x118, %rax            # imm = 0x118
    14af:      	jmp	0x14c7 <execve_send+0x1167>
    14b1:      	addq	$0x140, %rax            # imm = 0x140
    14b7:      	jmp	0x14c7 <execve_send+0x1167>
    14b9:      	addq	$0x148, %rax            # imm = 0x148
    14bf:      	jmp	0x14c7 <execve_send+0x1167>
    14c1:      	addq	$0x128, %rax            # imm = 0x128
    14c7:      	lock
    14c8:      	incq	(%rax)
    14cb:      	xorl	%eax, %eax
    14cd:      	addq	$0xa8, %rsp
    14d4:      	popq	%rbx
    14d5:      	popq	%r12
    14d7:      	popq	%r13
    14d9:      	popq	%r14
    14db:      	popq	%r15
    14dd:      	popq	%rbp
    14de:      	retq

Disassembly of section tracepoint/sys_execve:

0000000000000000 <event_execve>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xc8, %rsp
      11:      	movq	%rdi, %r14
      14:      	movl	$0x23, %eax
      19:      	callq	*%rax
      1b:      	movq	%rax, %r12
      1e:      	movzwl	0x8(%r14), %r13d
      23:      	movl	$0x0, 0xa8(%rsp)
      2e:      	movq	(%rip), %rdi            # 0x35 <event_execve+0x35>
      35:      	leaq	0xa8(%rsp), %rsi
      3d:      	movl	$0x1, %eax
      42:      	callq	*%rax
      44:      	testq	%rax, %rax
      47:      	je	0x2443 <event_execve+0x2443>
      4d:      	movq	%rax, %r15
      50:      	movl	$0xe, %eax
      55:      	callq	*%rax
      57:      	movq	%rax, 0x70(%rsp)
      5c:      	movl	$0x23, %eax
      61:      	callq	*%rax
      63:      	movq	%rax, %rcx
      66:      	movq	%rax, 0x20(%rsp)
      6b:      	addq	$0xb00, %rcx            # imm = 0xB00
      72:      	leaq	0x20(%rsp), %rdi
      77:      	movl	$0x8, %edx
      7c:      	movl	$0x71, %eax
      81:      	movl	$0xb00, %edx            # imm = 0xB00
      86:      	addq	0x20(%rsp), %rdx
      8b:      	movl	$0x8, %esi
      90:      	callq	*%rax
      92:      	movq	0x20(%rsp), %rcx
      97:      	testq	%rcx, %rcx
      9a:      	movq	%r14, 0x88(%rsp)
      a2:      	movq	%r15, 0x78(%rsp)
      a7:      	movq	%r12, 0x80(%rsp)
      af:      	je	0x383 <event_execve+0x383>
      b5:      	addq	$0xaf4, %rcx            # imm = 0xAF4
      bc:      	leaq	0x10(%rsp), %rdi
      c1:      	movl	$0x4, %edx
      c6:      	movl	$0x71, %eax
      cb:      	movl	$0xaf4, %edx            # imm = 0xAF4
      d0:      	addq	0x20(%rsp), %rdx
      d5:      	movl	$0x4, %esi
      da:      	callq	*%rax
      dc:      	movl	0x10(%rsp), %eax
      e0:      	movl	%eax, (%rsp)
      e3:      	movq	(%rip), %rdi            # 0xea <event_execve+0xea>
      ea:      	movq	%rsp, %rsi
      ed:      	movl	$0x1, %eax
      f2:      	callq	*%rax
      f4:      	testq	%rax, %rax
      f7:      	je	0x107 <event_execve+0x107>
      f9:      	movq	%rax, %rbp
      fc:      	cmpq	$0x0, 0x8(%rax)
     101:      	jne	0x2a3 <event_execve+0x2a3>
     107:      	movl	$0xb00, %edx            # imm = 0xB00
     10c:      	movq	0x20(%rsp), %rcx
     111:      	addq	%rdx, %rcx
     114:      	leaq	0x20(%rsp), %rdi
     119:      	movl	$0x8, %esi
     11e:      	movl	$0x71, %eax
     123:      	addq	0x20(%rsp), %rdx
     128:      	movl	$0x8, %esi
     12d:      	callq	*%rax
     12f:      	movq	0x20(%rsp), %rcx
     134:      	testq	%rcx, %rcx
     137:      	je	0x383 <event_execve+0x383>
     13d:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     144:      	leaq	0x10(%rsp), %rdi
     149:      	movl	$0x4, %edx
     14e:      	movl	$0x71, %eax
     153:      	movl	$0xaf4, %edx            # imm = 0xAF4
     158:      	addq	0x20(%rsp), %rdx
     15d:      	movl	$0x4, %esi
     162:      	callq	*%rax
     164:      	movl	0x10(%rsp), %eax
     168:      	movl	%eax, (%rsp)
     16b:      	movq	(%rip), %rdi            # 0x172 <event_execve+0x172>
     172:      	movq	%rsp, %rsi
     175:      	movl	$0x1, %eax
     17a:      	callq	*%rax
     17c:      	testq	%rax, %rax
     17f:      	je	0x18f <event_execve+0x18f>
     181:      	movq	%rax, %rbp
     184:      	cmpq	$0x0, 0x8(%rax)
     189:      	jne	0x2a3 <event_execve+0x2a3>
     18f:      	movl	$0xb00, %edx            # imm = 0xB00
     194:      	movq	0x20(%rsp), %rcx
     199:      	addq	%rdx, %rcx
     19c:      	leaq	0x20(%rsp), %rdi
     1a1:      	movl	$0x8, %esi
     1a6:      	movl	$0x71, %eax
     1ab:      	addq	0x20(%rsp), %rdx
     1b0:      	movl	$0x8, %esi
     1b5:      	callq	*%rax
     1b7:      	movq	0x20(%rsp), %rcx
     1bc:      	testq	%rcx, %rcx
     1bf:      	je	0x383 <event_execve+0x383>
     1c5:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     1cc:      	leaq	0x10(%rsp), %rdi
     1d1:      	movl	$0x4, %edx
     1d6:      	movl	$0x71, %eax
     1db:      	movl	$0xaf4, %edx            # imm = 0xAF4
     1e0:      	addq	0x20(%rsp), %rdx
     1e5:      	movl	$0x4, %esi
     1ea:      	callq	*%rax
     1ec:      	movl	0x10(%rsp), %eax
     1f0:      	movl	%eax, (%rsp)
     1f3:      	movq	(%rip), %rdi            # 0x1fa <event_execve+0x1fa>
     1fa:      	movq	%rsp, %rsi
     1fd:      	movl	$0x1, %eax
     202:      	callq	*%rax
     204:      	testq	%rax, %rax
     207:      	je	0x217 <event_execve+0x217>
     209:      	movq	%rax, %rbp
     20c:      	cmpq	$0x0, 0x8(%rax)
     211:      	jne	0x2a3 <event_execve+0x2a3>
     217:      	movl	$0xb00, %edx            # imm = 0xB00
     21c:      	movq	0x20(%rsp), %rcx
     221:      	addq	%rdx, %rcx
     224:      	leaq	0x20(%rsp), %rdi
     229:      	movl	$0x8, %esi
     22e:      	movl	$0x71, %eax
     233:      	addq	0x20(%rsp), %rdx
     238:      	movl	$0x8, %esi
     23d:      	callq	*%rax
     23f:      	movq	0x20(%rsp), %rcx
     244:      	testq	%rcx, %rcx
     247:      	je	0x383 <event_execve+0x383>
     24d:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     254:      	leaq	0x10(%rsp), %rdi
     259:      	movl	$0x4, %edx
     25e:      	movl	$0x71, %eax
     263:      	movl	$0xaf4, %edx            # imm = 0xAF4
     268:      	addq	0x20(%rsp), %rdx
     26d:      	movl	$0x4, %esi
     272:      	callq	*%rax
     274:      	movl	0x10(%rsp), %eax
     278:      	movl	%eax, (%rsp)
     27b:      	movq	(%rip), %rdi            # 0x282 <event_execve+0x282>
     282:      	movq	%rsp, %rsi
     285:      	movl	$0x1, %eax
     28a:      	callq	*%rax
     28c:      	testq	%rax, %rax
     28f:      	je	0x383 <event_execve+0x383>
     295:      	movq	%rax, %rbp
     298:      	cmpq	$0x0, 0x8(%rax)
     29d:      	je	0x383 <event_execve+0x383>
     2a3:      	movq	(%rbp), %rax
     2a7:      	movq	0x8(%rbp), %rcx
     2ab:      	movq	%rcx, 0xa8(%r15)
     2b2:      	movq	%rax, 0xa0(%r15)
     2b9:      	movl	$0x0, (%rsp)
     2c0:      	movq	(%rip), %rdi            # 0x2c7 <event_execve+0x2c7>
     2c7:      	movq	%rsp, %rsi
     2ca:      	movl	$0x1, %eax
     2cf:      	callq	*%rax
     2d1:      	testq	%rax, %rax
     2d4:      	je	0x485 <event_execve+0x485>
     2da:      	movq	(%rax), %rcx
     2dd:      	cmpq	0x378(%rbp), %rcx
     2e4:      	je	0x485 <event_execve+0x485>
     2ea:      	movq	%r13, 0x90(%rsp)
     2f2:      	movq	%rax, 0x98(%rsp)
     2fa:      	movq	(%rip), %rax            # 0x301 <event_execve+0x301>
     301:      	cmpb	$0x0, (%rax)
     304:      	je	0x3ec <event_execve+0x3ec>
     30a:      	movl	$0x1869f, %r14d         # imm = 0x1869F
     310:      	xorl	%ebx, %ebx
     312:      	leaq	0x20(%rsp), %r15
     317:      	movq	(%rip), %r12            # 0x31e <event_execve+0x31e>
     31e:      	nop
     320:      	movl	0x10(%rbp), %eax
     323:      	movl	%eax, 0x20(%rsp)
     327:      	movl	$0x1, %eax
     32c:      	movq	(%rip), %rdi            # 0x333 <event_execve+0x333>
     333:      	movq	%r15, %rsi
     336:      	callq	*%rax
     338:      	testq	%rax, %rax
     33b:      	je	0x456 <event_execve+0x456>
     341:      	movq	%rax, %r13
     344:      	leaq	0x70(%rax), %rsi
     348:      	movl	$0x1, %eax
     34d:      	movq	%r12, %rdi
     350:      	callq	*%rax
     352:      	testq	%rax, %rax
     355:      	je	0x367 <event_execve+0x367>
     357:      	movq	(%rax), %rax
     35a:      	testq	%rax, %rax
     35d:      	je	0x367 <event_execve+0x367>
     35f:      	lock
     360:      	orq	%rax, 0x370(%rbp)
     367:      	subl	$0x1, %r14d
     36b:      	setb	%al
     36e:      	cmpq	%rbx, %r13
     371:      	je	0x456 <event_execve+0x456>
     377:      	movq	%r13, %rbx
     37a:      	testb	%al, %al
     37c:      	je	0x320 <event_execve+0x320>
     37e:      	jmp	0x456 <event_execve+0x456>
     383:      	leaq	0xb00(%r12), %rdx
     38b:      	leaq	0x20(%rsp), %rdi
     390:      	movl	$0x8, %ecx
     395:      	movl	$0x71, %eax
     39a:      	movl	$0x8, %esi
     39f:      	callq	*%rax
     3a1:      	movq	0x20(%rsp), %rdx
     3a6:      	testq	%rdx, %rdx
     3a9:      	je	0x3ce <event_execve+0x3ce>
     3ab:      	addq	$0xaf4, %rdx            # imm = 0xAF4
     3b2:      	leaq	0x20(%rsp), %rdi
     3b7:      	movl	$0x4, %ecx
     3bc:      	movl	$0x71, %eax
     3c1:      	movl	$0x4, %esi
     3c6:      	callq	*%rax
     3c8:      	movl	0x20(%rsp), %eax
     3cc:      	jmp	0x3d0 <event_execve+0x3d0>
     3ce:      	xorl	%eax, %eax
     3d0:      	movl	%eax, 0xa0(%r15)
     3d7:      	movq	$0x0, 0xa8(%r15)
     3e2:      	movl	$0x40, %eax
     3e7:      	jmp	0x487 <event_execve+0x487>
     3ec:      	movl	$0x3ff, %r14d           # imm = 0x3FF
     3f2:      	xorl	%ebx, %ebx
     3f4:      	leaq	0x20(%rsp), %r15
     3f9:      	movq	(%rip), %r12            # 0x400 <event_execve+0x400>
     400:      	movl	0x10(%rbp), %eax
     403:      	movl	%eax, 0x20(%rsp)
     407:      	movl	$0x1, %eax
     40c:      	movq	(%rip), %rdi            # 0x413 <event_execve+0x413>
     413:      	movq	%r15, %rsi
     416:      	callq	*%rax
     418:      	testq	%rax, %rax
     41b:      	je	0x456 <event_execve+0x456>
     41d:      	movq	%rax, %r13
     420:      	leaq	0x70(%rax), %rsi
     424:      	movl	$0x1, %eax
     429:      	movq	%r12, %rdi
     42c:      	callq	*%rax
     42e:      	testq	%rax, %rax
     431:      	je	0x443 <event_execve+0x443>
     433:      	movq	(%rax), %rax
     436:      	testq	%rax, %rax
     439:      	je	0x443 <event_execve+0x443>
     43b:      	lock
     43c:      	orq	%rax, 0x370(%rbp)
     443:      	subl	$0x1, %r14d
     447:      	setb	%al
     44a:      	cmpq	%rbx, %r13
     44d:      	je	0x456 <event_execve+0x456>
     44f:      	movq	%r13, %rbx
     452:      	testb	%al, %al
     454:      	je	0x400 <event_execve+0x400>
     456:      	movq	0x98(%rsp), %rax
     45e:      	movq	(%rax), %rax
     461:      	movq	%rax, 0x378(%rbp)
     468:      	movq	0x88(%rsp), %r14
     470:      	movq	0x78(%rsp), %r15
     475:      	movq	0x80(%rsp), %r12
     47d:      	movq	0x90(%rsp), %r13
     485:      	xorl	%eax, %eax
     487:      	movq	0x70(%rsp), %rbp
     48c:      	movq	%rax, 0xb0(%r15)
     493:      	movl	$0x1, 0x15c(%r15)
     49e:      	movq	%rbp, %rax
     4a1:      	shrq	$0x20, %rax
     4a5:      	movq	$0x0, 0x178(%r15)
     4b0:      	movl	%eax, 0x144(%r15)
     4b7:      	movl	%ebp, 0x148(%r15)
     4be:      	movl	$0x23, %eax
     4c3:      	callq	*%rax
     4c5:      	leaq	0x60(%rax), %rdx
     4c9:      	movq	%rsp, %rdi
     4cc:      	movl	$0x8, %ecx
     4d1:      	movl	$0x71, %eax
     4d6:      	movl	$0x8, %esi
     4db:      	callq	*%rax
     4dd:      	movq	(%rsp), %rcx
     4e1:      	xorl	%ebx, %ebx
     4e3:      	testq	%rcx, %rcx
     4e6:      	je	0x552 <event_execve+0x552>
     4e8:      	addq	$0x4, %rcx
     4ec:      	leaq	0x10(%rsp), %rdi
     4f1:      	movl	$0x4, %edx
     4f6:      	movl	$0x71, %eax
     4fb:      	movq	(%rsp), %rdx
     4ff:      	addq	$0x4, %rdx
     503:      	movl	$0x4, %esi
     508:      	callq	*%rax
     50a:      	movl	0x10(%rsp), %eax
     50e:      	testl	%eax, %eax
     510:      	je	0x552 <event_execve+0x552>
     512:      	movq	(%rsp), %rcx
     516:      	shll	$0x4, %eax
     519:      	addq	%rax, %rcx
     51c:      	addq	$0x80, %rcx
     523:      	leaq	0x20(%rsp), %rdi
     528:      	movl	$0x10, %edx
     52d:      	movl	$0x71, %eax
     532:      	movq	(%rsp), %rcx
     536:      	movl	0x10(%rsp), %edx
     53a:      	shll	$0x4, %edx
     53d:      	addq	%rcx, %rdx
     540:      	addq	$0x80, %rdx
     547:      	movl	$0x10, %esi
     54c:      	callq	*%rax
     54e:      	movl	0x20(%rsp), %ebx
     552:      	movl	%ebx, 0x14c(%r15)
     559:      	movl	$0x7d, %eax
     55e:      	callq	*%rax
     560:      	movq	%rax, 0x170(%r15)
     567:      	movl	$0x40, 0x140(%r15)
     572:      	movl	$0x23, %eax
     577:      	callq	*%rax
     579:      	movq	$0x0, 0x20(%rsp)
     582:      	testq	%rax, %rax
     585:      	je	0x5ab <event_execve+0x5ab>
     587:      	movq	%rax, %rdx
     58a:      	addq	$0x70, %rdx
     58e:      	leaq	0x20(%rsp), %rdi
     593:      	movl	$0x8, %ecx
     598:      	movl	$0x4, %eax
     59d:      	movl	$0x8, %esi
     5a2:      	callq	*%rax
     5a4:      	movq	0x20(%rsp), %rax
     5a9:      	jmp	0x5ad <event_execve+0x5ad>
     5ab:      	xorl	%eax, %eax
     5ad:      	movl	%eax, 0x158(%r15)
     5b4:      	movq	%rbp, 0x20(%rsp)
     5b9:      	movq	(%rip), %rdi            # 0x5c0 <event_execve+0x5c0>
     5c0:      	leaq	0x20(%rsp), %rsi
     5c5:      	movl	$0x1, %eax
     5ca:      	addq	%r14, %r13
     5cd:      	callq	*%rax
     5cf:      	testq	%rax, %rax
     5d2:      	je	0x630 <event_execve+0x630>
     5d4:      	movl	(%rax), %ecx
     5d6:      	movl	%ecx, 0x150(%r15)
     5dd:      	movq	0x8(%rax), %rcx
     5e1:      	movq	%rcx, 0x168(%r15)
     5e8:      	movl	0x4(%rax), %eax
     5eb:      	movl	%eax, 0x160(%r15)
     5f2:      	movq	%rbp, 0x20(%rsp)
     5f7:      	movq	(%rip), %rdi            # 0x5fe <event_execve+0x5fe>
     5fe:      	leaq	0x20(%rsp), %rsi
     603:      	movl	$0x3, %eax
     608:      	callq	*%rax
     60a:      	testl	%eax, %eax
     60c:      	je	0x653 <event_execve+0x653>
     60e:      	movl	$0x2, (%rsp)
     615:      	movq	(%rip), %rdi            # 0x61c <event_execve+0x61c>
     61c:      	movq	%rsp, %rsi
     61f:      	movl	$0x1, %eax
     624:      	callq	*%rax
     626:      	testq	%rax, %rax
     629:      	je	0x673 <event_execve+0x673>
     62b:      	incq	(%rax)
     62e:      	jmp	0x673 <event_execve+0x673>
     630:      	movl	$0x0, 0x150(%r15)
     63b:      	movq	$0x0, 0x168(%r15)
     646:      	movl	$0x0, 0x160(%r15)
     651:      	jmp	0x673 <event_execve+0x673>
     653:      	movl	$0x0, (%rsp)
     65a:      	movq	(%rip), %rdi            # 0x661 <event_execve+0x661>
     661:      	movq	%rsp, %rsi
     664:      	movl	$0x1, %eax
     669:      	callq	*%rax
     66b:      	testq	%rax, %rax
     66e:      	je	0x673 <event_execve+0x673>
     670:      	decq	(%rax)
     673:      	leaq	0x180(%r15), %rdi
     67a:      	movl	$0xff, %ecx
     67f:      	movl	$0x2d, %eax
     684:      	movl	$0xff, %esi
     689:      	movq	%r13, %rdx
     68c:      	callq	*%rax
     68e:      	testl	%eax, %eax
     690:      	js	0x779 <event_execve+0x779>
     696:      	je	0x782 <event_execve+0x782>
     69c:      	cmpl	$0xff, %eax
     6a1:      	jne	0x786 <event_execve+0x786>
     6a7:      	movl	$0x0, (%rsp)
     6ae:      	movq	(%rip), %rdi            # 0x6b5 <event_execve+0x6b5>
     6b5:      	movq	%rsp, %rsi
     6b8:      	movl	$0x1, %eax
     6bd:      	callq	*%rax
     6bf:      	testq	%rax, %rax
     6c2:      	je	0x779 <event_execve+0x779>
     6c8:      	movq	%rax, %rbx
     6cb:      	movl	$0x18, (%rax)
     6d1:      	movl	$0xe, %eax
     6d6:      	callq	*%rax
     6d8:      	movq	%rbx, %r14
     6db:      	addq	$0x10, %r14
     6df:      	movq	%rax, 0x10(%rbx)
     6e3:      	cmpq	$-0x16, %rax
     6e7:      	jne	0x713 <event_execve+0x713>
     6e9:      	movq	0x88(%rsp), %rax
     6f1:      	leaq	0x20(%rax), %rdx
     6f5:      	leaq	0x20(%rsp), %rdi
     6fa:      	movl	$0x8, %ecx
     6ff:      	movl	$0x4, %eax
     704:      	movl	$0x8, %esi
     709:      	callq	*%rax
     70b:      	movq	0x20(%rsp), %rax
     710:      	movq	%rax, (%r14)
     713:      	movl	$0x7d, %eax
     718:      	callq	*%rax
     71a:      	movq	%rax, 0x18(%rbx)
     71e:      	movq	(%r14), %rax
     721:      	movq	0x8(%r14), %rcx
     725:      	movq	%rax, 0x190(%r15)
     72c:      	movq	%rcx, 0x198(%r15)
     733:      	movq	0x88(%rsp), %rdi
     73b:      	movq	%rbx, %rsi
     73e:      	movq	%r13, %rdx
     741:      	callq	0x746 <event_execve+0x746>
     746:      	movl	%eax, %ecx
     748:      	sarl	$0x1f, %ecx
     74b:      	andl	%eax, %ecx
     74d:      	xorl	%edx, %edx
     74f:      	testl	%eax, %eax
     751:      	cmovgl	%eax, %edx
     754:      	movl	%ecx, 0x180(%r15)
     75b:      	movq	$0x0, 0x184(%r15)
     766:      	movl	%edx, 0x18c(%r15)
     76d:      	movl	$0x20, %ecx
     772:      	movl	$0x800000, %eax         # imm = 0x800000
     777:      	jmp	0x78c <event_execve+0x78c>
     779:      	xorl	%ecx, %ecx
     77b:      	movl	$0x100, %eax            # imm = 0x100
     780:      	jmp	0x78c <event_execve+0x78c>
     782:      	movl	%eax, %ecx
     784:      	jmp	0x78c <event_execve+0x78c>
     786:      	movl	%eax, %ecx
     788:      	decl	%ecx
     78a:      	xorl	%eax, %eax
     78c:      	movw	%cx, 0x178(%r15)
     794:      	orl	%eax, 0x15c(%r15)
     79b:      	addl	%ecx, 0x140(%r15)
     7a2:      	movl	$0x23, %eax
     7a7:      	callq	*%rax
     7a9:      	movl	$0x0, 0xa0(%rsp)
     7b4:      	leaq	0xa78(%rax), %rdx
     7bb:      	leaq	0x18(%rsp), %rdi
     7c0:      	movl	$0x8, %ecx
     7c5:      	movl	$0x4, %eax
     7ca:      	movl	$0x8, %esi
     7cf:      	callq	*%rax
     7d1:      	testq	%rax, %rax
     7d4:      	je	0x830 <event_execve+0x830>
     7d6:      	negl	%eax
     7d8:      	movw	%ax, 0x20(%rsp)
     7dd:      	movw	$0x9, 0x22(%rsp)
     7e4:      	movabsq	$0x400000042, %rax      # imm = 0x400000042
     7ee:      	movq	%rax, 0x24(%rsp)
     7f3:      	movq	(%rip), %rdi            # 0x7fa <event_execve+0x7fa>
     7fa:      	leaq	0x20(%rsp), %rsi
     7ff:      	movl	$0x1, %eax
     804:      	callq	*%rax
     806:      	testq	%rax, %rax
     809:      	je	0x80f <event_execve+0x80f>
     80b:      	incl	(%rax)
     80d:      	jmp	0x830 <event_execve+0x830>
     80f:      	movl	$0x1, (%rsp)
     816:      	movq	(%rip), %rdi            # 0x81d <event_execve+0x81d>
     81d:      	xorl	%ecx, %ecx
     81f:      	leaq	0x20(%rsp), %rsi
     824:      	movq	%rsp, %rdx
     827:      	movl	$0x2, %eax
     82c:      	xorl	%ecx, %ecx
     82e:      	callq	*%rax
     830:      	leaq	0x140(%r15), %r13
     837:      	movq	0x18(%rsp), %rcx
     83c:      	xorl	%ebp, %ebp
     83e:      	movl	$0x0, %edx
     843:      	testq	%rcx, %rcx
     846:      	je	0xc44 <event_execve+0xc44>
     84c:      	addq	$0x2b8, %rcx            # imm = 0x2B8
     853:      	movq	%rsp, %rdi
     856:      	movl	$0x8, %edx
     85b:      	movl	$0x4, %eax
     860:      	movl	$0x2b8, %edx            # imm = 0x2B8
     865:      	addq	0x18(%rsp), %rdx
     86a:      	movl	$0x8, %esi
     86f:      	callq	*%rax
     871:      	testq	%rax, %rax
     874:      	je	0x8d3 <event_execve+0x8d3>
     876:      	negl	%eax
     878:      	movw	%ax, 0x20(%rsp)
     87d:      	movw	$0x9, 0x22(%rsp)
     884:      	movabsq	$0x400000047, %rax      # imm = 0x400000047
     88e:      	movq	%rax, 0x24(%rsp)
     893:      	movq	(%rip), %rdi            # 0x89a <event_execve+0x89a>
     89a:      	leaq	0x20(%rsp), %rsi
     89f:      	movl	$0x1, %eax
     8a4:      	callq	*%rax
     8a6:      	testq	%rax, %rax
     8a9:      	je	0x8af <event_execve+0x8af>
     8ab:      	incl	(%rax)
     8ad:      	jmp	0x8d3 <event_execve+0x8d3>
     8af:      	movl	$0x1, 0x10(%rsp)
     8b7:      	movq	(%rip), %rdi            # 0x8be <event_execve+0x8be>
     8be:      	xorl	%ecx, %ecx
     8c0:      	leaq	0x20(%rsp), %rsi
     8c5:      	leaq	0x10(%rsp), %rdx
     8ca:      	movl	$0x2, %eax
     8cf:      	xorl	%ecx, %ecx
     8d1:      	callq	*%rax
     8d3:      	movl	$0x2c0, %edx            # imm = 0x2C0
     8d8:      	movq	0x18(%rsp), %rcx
     8dd:      	addq	%rdx, %rcx
     8e0:      	leaq	0x10(%rsp), %rdi
     8e5:      	movl	$0x8, %esi
     8ea:      	movl	$0x4, %eax
     8ef:      	addq	0x18(%rsp), %rdx
     8f4:      	movl	$0x8, %esi
     8f9:      	callq	*%rax
     8fb:      	testq	%rax, %rax
     8fe:      	je	0x93b <event_execve+0x93b>
     900:      	negl	%eax
     902:      	movw	%ax, 0x20(%rsp)
     907:      	movw	$0x9, 0x22(%rsp)
     90e:      	movabsq	$0x400000048, %rax      # imm = 0x400000048
     918:      	movq	%rax, 0x24(%rsp)
     91d:      	movq	(%rip), %rdi            # 0x924 <event_execve+0x924>
     924:      	leaq	0x20(%rsp), %rsi
     929:      	movl	$0x1, %eax
     92e:      	callq	*%rax
     930:      	testq	%rax, %rax
     933:      	je	0xa8e <event_execve+0xa8e>
     939:      	incl	(%rax)
     93b:      	cmpq	$0x0, (%rsp)
     940:      	movl	$0x0, %edx
     945:      	je	0xc44 <event_execve+0xc44>
     94b:      	cmpq	$0x0, 0x10(%rsp)
     951:      	movl	$0x0, %edx
     956:      	je	0xc44 <event_execve+0xc44>
     95c:      	movq	(%rip), %rdi            # 0x963 <event_execve+0x963>
     963:      	leaq	0xa0(%rsp), %rsi
     96b:      	movl	$0x1, %eax
     970:      	callq	*%rax
     972:      	movl	$0x0, %edx
     977:      	testq	%rax, %rax
     97a:      	je	0xc44 <event_execve+0xc44>
     980:      	movq	%rax, %rdi
     983:      	movq	(%rsp), %rcx
     987:      	movl	$0x1000, %edx           # imm = 0x1000
     98c:      	movl	$0x2d, %eax
     991:      	movq	(%rsp), %rdx
     995:      	movl	$0x1000, %esi           # imm = 0x1000
     99a:      	callq	*%rax
     99c:      	movl	$0x0, %edx
     9a1:      	testq	%rax, %rax
     9a4:      	js	0xc44 <event_execve+0xc44>
     9aa:      	movq	%rax, %rbx
     9ad:      	movq	%r13, 0x70(%rsp)
     9b2:      	addq	(%rsp), %rbx
     9b6:      	movq	%rbx, (%rsp)
     9ba:      	movl	0x140(%r15), %r12d
     9c1:      	andl	$0x1ff, %r12d           # imm = 0x1FF
     9c8:      	movl	%r12d, 0x184c(%r15)
     9cf:      	movq	0x10(%rsp), %rax
     9d4:      	movq	%rax, %r13
     9d7:      	subq	%rbx, %r13
     9da:      	cmpq	$0x3ff, %r13            # imm = 0x3FF
     9e1:      	ja	0xac7 <event_execve+0xac7>
     9e7:      	leaq	(%r15,%r12), %rdi
     9eb:      	addq	$0x140, %rdi            # imm = 0x140
     9f2:      	movq	0x70(%rsp), %rcx
     9f7:      	subq	%rdi, %rcx
     9fa:      	addq	$0x400, %rcx            # imm = 0x400
     a01:      	cmpq	%rcx, %r13
     a04:      	jae	0xac7 <event_execve+0xac7>
     a0a:      	decl	%r13d
     a0d:      	andl	$0x3ff, %r13d           # imm = 0x3FF
     a14:      	xorl	%esi, %esi
     a16:      	cmpq	%rbx, %rax
     a19:      	cmovnel	%r13d, %esi
     a1d:      	movl	$0x4, %eax
     a22:      	movq	(%rsp), %rdx
     a26:      	movq	%rsi, 0x90(%rsp)
     a2e:      	callq	*%rax
     a30:      	testq	%rax, %rax
     a33:      	je	0xbdf <event_execve+0xbdf>
     a39:      	movq	%rax, %rbx
     a3c:      	negl	%eax
     a3e:      	movw	%ax, 0x20(%rsp)
     a43:      	movw	$0x9, 0x22(%rsp)
     a4a:      	movabsq	$0x40000006c, %rax      # imm = 0x40000006C
     a54:      	movq	%rax, 0x24(%rsp)
     a59:      	movq	(%rip), %rdi            # 0xa60 <event_execve+0xa60>
     a60:      	leaq	0x20(%rsp), %rsi
     a65:      	movl	$0x1, %eax
     a6a:      	callq	*%rax
     a6c:      	testq	%rax, %rax
     a6f:      	movq	0x78(%rsp), %r15
     a74:      	movq	0x80(%rsp), %r12
     a7c:      	movq	0x70(%rsp), %r13
     a81:      	je	0xbfb <event_execve+0xbfb>
     a87:      	incl	(%rax)
     a89:      	jmp	0xc1f <event_execve+0xc1f>
     a8e:      	movl	$0x1, 0x68(%rsp)
     a96:      	movq	(%rip), %rdi            # 0xa9d <event_execve+0xa9d>
     a9d:      	xorl	%ecx, %ecx
     a9f:      	leaq	0x20(%rsp), %rsi
     aa4:      	leaq	0x68(%rsp), %rdx
     aa9:      	movl	$0x2, %eax
     aae:      	xorl	%ecx, %ecx
     ab0:      	callq	*%rax
     ab2:      	cmpq	$0x0, (%rsp)
     ab7:      	movl	$0x0, %edx
     abc:      	jne	0x94b <event_execve+0x94b>
     ac2:      	jmp	0xc44 <event_execve+0xc44>
     ac7:      	movl	$0x0, 0x68(%rsp)
     acf:      	movq	(%rip), %rdi            # 0xad6 <event_execve+0xad6>
     ad6:      	leaq	0x68(%rsp), %rsi
     adb:      	movl	$0x1, %eax
     ae0:      	callq	*%rax
     ae2:      	testq	%rax, %rax
     ae5:      	je	0xbc9 <event_execve+0xbc9>
     aeb:      	movq	%rax, %r15
     aee:      	addq	0x78(%rsp), %r12
     af3:      	movl	$0x18, (%rax)
     af9:      	movl	$0xe, %eax
     afe:      	callq	*%rax
     b00:      	movq	%r15, %r14
     b03:      	addq	$0x10, %r14
     b07:      	movq	%rax, 0x10(%r15)
     b0b:      	cmpq	$-0x16, %rax
     b0f:      	jne	0xb3b <event_execve+0xb3b>
     b11:      	movq	0x88(%rsp), %rax
     b19:      	leaq	0x20(%rax), %rdx
     b1d:      	leaq	0x20(%rsp), %rdi
     b22:      	movl	$0x8, %ecx
     b27:      	movl	$0x4, %eax
     b2c:      	movl	$0x8, %esi
     b31:      	callq	*%rax
     b33:      	movq	0x20(%rsp), %rax
     b38:      	movq	%rax, (%r14)
     b3b:      	movl	$0x7d, %eax
     b40:      	callq	*%rax
     b42:      	movq	%rax, 0x18(%r15)
     b46:      	movq	(%r14), %rax
     b49:      	movq	0x8(%r14), %rcx
     b4d:      	movq	%rax, 0x150(%r12)
     b55:      	movq	%rcx, 0x158(%r12)
     b5d:      	movq	0x88(%rsp), %rdi
     b65:      	movq	%r15, %rsi
     b68:      	movq	%rbx, %rdx
     b6b:      	movq	%r13, %rcx
     b6e:      	callq	0xb73 <event_execve+0xb73>
     b73:      	movl	%r13d, %ecx
     b76:      	subl	%eax, %ecx
     b78:      	xorl	%edx, %edx
     b7a:      	cmpq	$-0x1, %r13
     b7e:      	cmovel	%edx, %ecx
     b81:      	testl	%eax, %eax
     b83:      	movl	$0x0, %esi
     b88:      	cmovsl	%eax, %esi
     b8b:      	cmovsl	%edx, %ecx
     b8e:      	cmovgl	%eax, %edx
     b91:      	movl	%esi, 0x140(%r12)
     b99:      	movl	$0x0, 0x144(%r12)
     ba5:      	movl	%ecx, 0x148(%r12)
     bad:      	movl	%edx, 0x14c(%r12)
     bb5:      	movq	0x78(%rsp), %r15
     bba:      	orb	$0x1, 0x15f(%r15)
     bc2:      	movl	$0x20, %edx
     bc7:      	jmp	0xbd0 <event_execve+0xbd0>
     bc9:      	xorl	%edx, %edx
     bcb:      	movq	0x78(%rsp), %r15
     bd0:      	movq	0x80(%rsp), %r12
     bd8:      	movq	0x70(%rsp), %r13
     bdd:      	jmp	0xc35 <event_execve+0xc35>
     bdf:      	movq	0x78(%rsp), %r15
     be4:      	movq	0x80(%rsp), %r12
     bec:      	movq	0x70(%rsp), %r13
     bf1:      	movq	0x90(%rsp), %rdx
     bf9:      	jmp	0xc35 <event_execve+0xc35>
     bfb:      	movl	$0x1, 0x68(%rsp)
     c03:      	movq	(%rip), %rdi            # 0xc0a <event_execve+0xc0a>
     c0a:      	xorl	%ecx, %ecx
     c0c:      	leaq	0x20(%rsp), %rsi
     c11:      	leaq	0x68(%rsp), %rdx
     c16:      	movl	$0x2, %eax
     c1b:      	xorl	%ecx, %ecx
     c1d:      	callq	*%rax
     c1f:      	testl	%ebx, %ebx
     c21:      	movq	0x90(%rsp), %rdx
     c29:      	jns	0xc35 <event_execve+0xc35>
     c2b:      	orb	$0x2, 0x15d(%r15)
     c33:      	xorl	%edx, %edx
     c35:      	movl	%edx, 0x1848(%r15)
     c3c:      	movw	%dx, 0x17a(%r15)
     c44:      	addl	0x140(%r15), %edx
     c4b:      	movl	%edx, 0x140(%r15)
     c52:      	testb	$0x20, 0x15d(%r15)
     c5a:      	jne	0x194a <event_execve+0x194a>
     c60:      	movq	%rdx, 0x90(%rsp)
     c68:      	movq	%r13, 0x70(%rsp)
     c6d:      	movl	0x144(%r15), %ebx
     c74:      	movl	$0x23, %eax
     c79:      	callq	*%rax
     c7b:      	movl	$0x0, (%rsp)
     c82:      	testq	%rax, %rax
     c85:      	je	0x12e3 <event_execve+0x12e3>
     c8b:      	movq	%rax, %r13
     c8e:      	leaq	0xaf4(%rax), %rdx
     c95:      	movq	%rsp, %rdi
     c98:      	movl	$0x4, %ecx
     c9d:      	movl	$0x71, %eax
     ca2:      	movl	$0x4, %esi
     ca7:      	callq	*%rax
     ca9:      	cmpl	%ebx, (%rsp)
     cac:      	je	0x12e6 <event_execve+0x12e6>
     cb2:      	addq	$0xb00, %r13            # imm = 0xB00
     cb9:      	leaq	0x20(%rsp), %rdi
     cbe:      	movl	$0x8, %ecx
     cc3:      	movl	$0x71, %eax
     cc8:      	movl	$0x8, %esi
     ccd:      	movq	%r13, %rdx
     cd0:      	callq	*%rax
     cd2:      	movq	0x20(%rsp), %r13
     cd7:      	testq	%r13, %r13
     cda:      	je	0x12e3 <event_execve+0x12e3>
     ce0:      	leaq	0xaf4(%r13), %rdx
     ce7:      	movq	%rsp, %rdi
     cea:      	movl	$0x4, %ecx
     cef:      	movl	$0x71, %eax
     cf4:      	movl	$0x4, %esi
     cf9:      	callq	*%rax
     cfb:      	cmpl	%ebx, (%rsp)
     cfe:      	je	0x12e6 <event_execve+0x12e6>
     d04:      	addq	$0xb00, %r13            # imm = 0xB00
     d0b:      	leaq	0x20(%rsp), %rdi
     d10:      	movl	$0x8, %ecx
     d15:      	movl	$0x71, %eax
     d1a:      	movl	$0x8, %esi
     d1f:      	movq	%r13, %rdx
     d22:      	callq	*%rax
     d24:      	movq	0x20(%rsp), %r13
     d29:      	testq	%r13, %r13
     d2c:      	je	0x12e3 <event_execve+0x12e3>
     d32:      	leaq	0xaf4(%r13), %rdx
     d39:      	movq	%rsp, %rdi
     d3c:      	movl	$0x4, %ecx
     d41:      	movl	$0x71, %eax
     d46:      	movl	$0x4, %esi
     d4b:      	callq	*%rax
     d4d:      	cmpl	%ebx, (%rsp)
     d50:      	je	0x12e6 <event_execve+0x12e6>
     d56:      	addq	$0xb00, %r13            # imm = 0xB00
     d5d:      	leaq	0x20(%rsp), %rdi
     d62:      	movl	$0x8, %ecx
     d67:      	movl	$0x71, %eax
     d6c:      	movl	$0x8, %esi
     d71:      	movq	%r13, %rdx
     d74:      	callq	*%rax
     d76:      	movq	0x20(%rsp), %r13
     d7b:      	testq	%r13, %r13
     d7e:      	je	0x12e3 <event_execve+0x12e3>
     d84:      	leaq	0xaf4(%r13), %rdx
     d8b:      	movq	%rsp, %rdi
     d8e:      	movl	$0x4, %ecx
     d93:      	movl	$0x71, %eax
     d98:      	movl	$0x4, %esi
     d9d:      	callq	*%rax
     d9f:      	cmpl	%ebx, (%rsp)
     da2:      	je	0x12e6 <event_execve+0x12e6>
     da8:      	addq	$0xb00, %r13            # imm = 0xB00
     daf:      	leaq	0x20(%rsp), %rdi
     db4:      	movl	$0x8, %ecx
     db9:      	movl	$0x71, %eax
     dbe:      	movl	$0x8, %esi
     dc3:      	movq	%r13, %rdx
     dc6:      	callq	*%rax
     dc8:      	movq	0x20(%rsp), %r13
     dcd:      	testq	%r13, %r13
     dd0:      	je	0x12e3 <event_execve+0x12e3>
     dd6:      	leaq	0xaf4(%r13), %rdx
     ddd:      	movq	%rsp, %rdi
     de0:      	movl	$0x4, %ecx
     de5:      	movl	$0x71, %eax
     dea:      	movl	$0x4, %esi
     def:      	callq	*%rax
     df1:      	cmpl	%ebx, (%rsp)
     df4:      	je	0x12e6 <event_execve+0x12e6>
     dfa:      	addq	$0xb00, %r13            # imm = 0xB00
     e01:      	leaq	0x20(%rsp), %rdi
     e06:      	movl	$0x8, %ecx
     e0b:      	movl	$0x71, %eax
     e10:      	movl	$0x8, %esi
     e15:      	movq	%r13, %rdx
     e18:      	callq	*%rax
     e1a:      	movq	0x20(%rsp), %r13
     e1f:      	testq	%r13, %r13
     e22:      	je	0x12e3 <event_execve+0x12e3>
     e28:      	leaq	0xaf4(%r13), %rdx
     e2f:      	movq	%rsp, %rdi
     e32:      	movl	$0x4, %ecx
     e37:      	movl	$0x71, %eax
     e3c:      	movl	$0x4, %esi
     e41:      	callq	*%rax
     e43:      	cmpl	%ebx, (%rsp)
     e46:      	je	0x12e6 <event_execve+0x12e6>
     e4c:      	addq	$0xb00, %r13            # imm = 0xB00
     e53:      	leaq	0x20(%rsp), %rdi
     e58:      	movl	$0x8, %ecx
     e5d:      	movl	$0x71, %eax
     e62:      	movl	$0x8, %esi
     e67:      	movq	%r13, %rdx
     e6a:      	callq	*%rax
     e6c:      	movq	0x20(%rsp), %r13
     e71:      	testq	%r13, %r13
     e74:      	je	0x12e3 <event_execve+0x12e3>
     e7a:      	leaq	0xaf4(%r13), %rdx
     e81:      	movq	%rsp, %rdi
     e84:      	movl	$0x4, %ecx
     e89:      	movl	$0x71, %eax
     e8e:      	movl	$0x4, %esi
     e93:      	callq	*%rax
     e95:      	cmpl	%ebx, (%rsp)
     e98:      	je	0x12e6 <event_execve+0x12e6>
     e9e:      	addq	$0xb00, %r13            # imm = 0xB00
     ea5:      	leaq	0x20(%rsp), %rdi
     eaa:      	movl	$0x8, %ecx
     eaf:      	movl	$0x71, %eax
     eb4:      	movl	$0x8, %esi
     eb9:      	movq	%r13, %rdx
     ebc:      	callq	*%rax
     ebe:      	movq	0x20(%rsp), %r13
     ec3:      	testq	%r13, %r13
     ec6:      	je	0x12e3 <event_execve+0x12e3>
     ecc:      	leaq	0xaf4(%r13), %rdx
     ed3:      	movq	%rsp, %rdi
     ed6:      	movl	$0x4, %ecx
     edb:      	movl	$0x71, %eax
     ee0:      	movl	$0x4, %esi
     ee5:      	callq	*%rax
     ee7:      	cmpl	%ebx, (%rsp)
     eea:      	je	0x12e6 <event_execve+0x12e6>
     ef0:      	addq	$0xb00, %r13            # imm = 0xB00
     ef7:      	leaq	0x20(%rsp), %rdi
     efc:      	movl	$0x8, %ecx
     f01:      	movl	$0x71, %eax
     f06:      	movl	$0x8, %esi
     f0b:      	movq	%r13, %rdx
     f0e:      	callq	*%rax
     f10:      	movq	0x20(%rsp), %r13
     f15:      	testq	%r13, %r13
     f18:      	je	0x12e3 <event_execve+0x12e3>
     f1e:      	leaq	0xaf4(%r13), %rdx
     f25:      	movq	%rsp, %rdi
     f28:      	movl	$0x4, %ecx
     f2d:      	movl	$0x71, %eax
     f32:      	movl	$0x4, %esi
     f37:      	callq	*%rax
     f39:      	cmpl	%ebx, (%rsp)
     f3c:      	je	0x12e6 <event_execve+0x12e6>
     f42:      	addq	$0xb00, %r13            # imm = 0xB00
     f49:      	leaq	0x20(%rsp), %rdi
     f4e:      	movl	$0x8, %ecx
     f53:      	movl	$0x71, %eax
     f58:      	movl	$0x8, %esi
     f5d:      	movq	%r13, %rdx
     f60:      	callq	*%rax
     f62:      	movq	0x20(%rsp), %r13
     f67:      	testq	%r13, %r13
     f6a:      	je	0x12e3 <event_execve+0x12e3>
     f70:      	leaq	0xaf4(%r13), %rdx
     f77:      	movq	%rsp, %rdi
     f7a:      	movl	$0x4, %ecx
     f7f:      	movl	$0x71, %eax
     f84:      	movl	$0x4, %esi
     f89:      	callq	*%rax
     f8b:      	cmpl	%ebx, (%rsp)
     f8e:      	je	0x12e6 <event_execve+0x12e6>
     f94:      	addq	$0xb00, %r13            # imm = 0xB00
     f9b:      	leaq	0x20(%rsp), %rdi
     fa0:      	movl	$0x8, %ecx
     fa5:      	movl	$0x71, %eax
     faa:      	movl	$0x8, %esi
     faf:      	movq	%r13, %rdx
     fb2:      	callq	*%rax
     fb4:      	movq	0x20(%rsp), %r13
     fb9:      	testq	%r13, %r13
     fbc:      	je	0x12e3 <event_execve+0x12e3>
     fc2:      	leaq	0xaf4(%r13), %rdx
     fc9:      	movq	%rsp, %rdi
     fcc:      	movl	$0x4, %ecx
     fd1:      	movl	$0x71, %eax
     fd6:      	movl	$0x4, %esi
     fdb:      	callq	*%rax
     fdd:      	cmpl	%ebx, (%rsp)
     fe0:      	je	0x12e6 <event_execve+0x12e6>
     fe6:      	addq	$0xb00, %r13            # imm = 0xB00
     fed:      	leaq	0x20(%rsp), %rdi
     ff2:      	movl	$0x8, %ecx
     ff7:      	movl	$0x71, %eax
     ffc:      	movl	$0x8, %esi
    1001:      	movq	%r13, %rdx
    1004:      	callq	*%rax
    1006:      	movq	0x20(%rsp), %r13
    100b:      	testq	%r13, %r13
    100e:      	je	0x12e3 <event_execve+0x12e3>
    1014:      	leaq	0xaf4(%r13), %rdx
    101b:      	movq	%rsp, %rdi
    101e:      	movl	$0x4, %ecx
    1023:      	movl	$0x71, %eax
    1028:      	movl	$0x4, %esi
    102d:      	callq	*%rax
    102f:      	cmpl	%ebx, (%rsp)
    1032:      	je	0x12e6 <event_execve+0x12e6>
    1038:      	addq	$0xb00, %r13            # imm = 0xB00
    103f:      	leaq	0x20(%rsp), %rdi
    1044:      	movl	$0x8, %ecx
    1049:      	movl	$0x71, %eax
    104e:      	movl	$0x8, %esi
    1053:      	movq	%r13, %rdx
    1056:      	callq	*%rax
    1058:      	movq	0x20(%rsp), %r13
    105d:      	testq	%r13, %r13
    1060:      	je	0x12e3 <event_execve+0x12e3>
    1066:      	leaq	0xaf4(%r13), %rdx
    106d:      	movq	%rsp, %rdi
    1070:      	movl	$0x4, %ecx
    1075:      	movl	$0x71, %eax
    107a:      	movl	$0x4, %esi
    107f:      	callq	*%rax
    1081:      	cmpl	%ebx, (%rsp)
    1084:      	je	0x12e6 <event_execve+0x12e6>
    108a:      	addq	$0xb00, %r13            # imm = 0xB00
    1091:      	leaq	0x20(%rsp), %rdi
    1096:      	movl	$0x8, %ecx
    109b:      	movl	$0x71, %eax
    10a0:      	movl	$0x8, %esi
    10a5:      	movq	%r13, %rdx
    10a8:      	callq	*%rax
    10aa:      	movq	0x20(%rsp), %r13
    10af:      	testq	%r13, %r13
    10b2:      	je	0x12e3 <event_execve+0x12e3>
    10b8:      	leaq	0xaf4(%r13), %rdx
    10bf:      	movq	%rsp, %rdi
    10c2:      	movl	$0x4, %ecx
    10c7:      	movl	$0x71, %eax
    10cc:      	movl	$0x4, %esi
    10d1:      	callq	*%rax
    10d3:      	cmpl	%ebx, (%rsp)
    10d6:      	je	0x12e6 <event_execve+0x12e6>
    10dc:      	addq	$0xb00, %r13            # imm = 0xB00
    10e3:      	leaq	0x20(%rsp), %rdi
    10e8:      	movl	$0x8, %ecx
    10ed:      	movl	$0x71, %eax
    10f2:      	movl	$0x8, %esi
    10f7:      	movq	%r13, %rdx
    10fa:      	callq	*%rax
    10fc:      	movq	0x20(%rsp), %r13
    1101:      	testq	%r13, %r13
    1104:      	je	0x12e3 <event_execve+0x12e3>
    110a:      	leaq	0xaf4(%r13), %rdx
    1111:      	movq	%rsp, %rdi
    1114:      	movl	$0x4, %ecx
    1119:      	movl	$0x71, %eax
    111e:      	movl	$0x4, %esi
    1123:      	callq	*%rax
    1125:      	cmpl	%ebx, (%rsp)
    1128:      	je	0x12e6 <event_execve+0x12e6>
    112e:      	addq	$0xb00, %r13            # imm = 0xB00
    1135:      	leaq	0x20(%rsp), %rdi
    113a:      	movl	$0x8, %ecx
    113f:      	movl	$0x71, %eax
    1144:      	movl	$0x8, %esi
    1149:      	movq	%r13, %rdx
    114c:      	callq	*%rax
    114e:      	movq	0x20(%rsp), %r13
    1153:      	testq	%r13, %r13
    1156:      	je	0x12e3 <event_execve+0x12e3>
    115c:      	leaq	0xaf4(%r13), %rdx
    1163:      	movq	%rsp, %rdi
    1166:      	movl	$0x4, %ecx
    116b:      	movl	$0x71, %eax
    1170:      	movl	$0x4, %esi
    1175:      	callq	*%rax
    1177:      	cmpl	%ebx, (%rsp)
    117a:      	je	0x12e6 <event_execve+0x12e6>
    1180:      	addq	$0xb00, %r13            # imm = 0xB00
    1187:      	leaq	0x20(%rsp), %rdi
    118c:      	movl	$0x8, %ecx
    1191:      	movl	$0x71, %eax
    1196:      	movl	$0x8, %esi
    119b:      	movq	%r13, %rdx
    119e:      	callq	*%rax
    11a0:      	movq	0x20(%rsp), %r13
    11a5:      	testq	%r13, %r13
    11a8:      	je	0x12e3 <event_execve+0x12e3>
    11ae:      	leaq	0xaf4(%r13), %rdx
    11b5:      	movq	%rsp, %rdi
    11b8:      	movl	$0x4, %ecx
    11bd:      	movl	$0x71, %eax
    11c2:      	movl	$0x4, %esi
    11c7:      	callq	*%rax
    11c9:      	cmpl	%ebx, (%rsp)
    11cc:      	je	0x12e6 <event_execve+0x12e6>
    11d2:      	addq	$0xb00, %r13            # imm = 0xB00
    11d9:      	leaq	0x20(%rsp), %rdi
    11de:      	movl	$0x8, %ecx
    11e3:      	movl	$0x71, %eax
    11e8:      	movl	$0x8, %esi
    11ed:      	movq	%r13, %rdx
    11f0:      	callq	*%rax
    11f2:      	movq	0x20(%rsp), %r13
    11f7:      	testq	%r13, %r13
    11fa:      	je	0x12e3 <event_execve+0x12e3>
    1200:      	leaq	0xaf4(%r13), %rdx
    1207:      	movq	%rsp, %rdi
    120a:      	movl	$0x4, %ecx
    120f:      	movl	$0x71, %eax
    1214:      	movl	$0x4, %esi
    1219:      	callq	*%rax
    121b:      	cmpl	%ebx, (%rsp)
    121e:      	je	0x12e6 <event_execve+0x12e6>
    1224:      	addq	$0xb00, %r13            # imm = 0xB00
    122b:      	leaq	0x20(%rsp), %rdi
    1230:      	movl	$0x8, %ecx
    1235:      	movl	$0x71, %eax
    123a:      	movl	$0x8, %esi
    123f:      	movq	%r13, %rdx
    1242:      	callq	*%rax
    1244:      	movq	0x20(%rsp), %r13
    1249:      	testq	%r13, %r13
    124c:      	je	0x12e3 <event_execve+0x12e3>
    1252:      	leaq	0xaf4(%r13), %rdx
    1259:      	movq	%rsp, %rdi
    125c:      	movl	$0x4, %ecx
    1261:      	movl	$0x71, %eax
    1266:      	movl	$0x4, %esi
    126b:      	callq	*%rax
    126d:      	cmpl	%ebx, (%rsp)
    1270:      	je	0x12e6 <event_execve+0x12e6>
    1272:      	addq	$0xb00, %r13            # imm = 0xB00
    1279:      	leaq	0x20(%rsp), %rdi
    127e:      	movl	$0x8, %ecx
    1283:      	movl	$0x71, %eax
    1288:      	movl	$0x8, %esi
    128d:      	movq	%r13, %rdx
    1290:      	callq	*%rax
    1292:      	movq	0x20(%rsp), %r13
    1297:      	testq	%r13, %r13
    129a:      	je	0x12e3 <event_execve+0x12e3>
    129c:      	leaq	0xaf4(%r13), %rdx
    12a3:      	movq	%rsp, %rdi
    12a6:      	movl	$0x4, %ecx
    12ab:      	movl	$0x71, %eax
    12b0:      	movl	$0x4, %esi
    12b5:      	callq	*%rax
    12b7:      	cmpl	%ebx, (%rsp)
    12ba:      	je	0x12e6 <event_execve+0x12e6>
    12bc:      	addq	$0xb00, %r13            # imm = 0xB00
    12c3:      	leaq	0x20(%rsp), %rdi
    12c8:      	movl	$0x8, %ecx
    12cd:      	movl	$0x71, %eax
    12d2:      	movl	$0x8, %esi
    12d7:      	movq	%r13, %rdx
    12da:      	callq	*%rax
    12dc:      	movq	0x20(%rsp), %r13
    12e1:      	jmp	0x12e6 <event_execve+0x12e6>
    12e3:      	xorl	%r13d, %r13d
    12e6:      	xorl	%ebp, %ebp
    12e8:      	cmpl	%ebx, (%rsp)
    12eb:      	cmovneq	%rbp, %r13
    12ef:      	addq	$0xd50, %r13            # imm = 0xD50
    12f6:      	leaq	0xb8(%rsp), %rdi
    12fe:      	movl	$0x8, %ecx
    1303:      	movl	$0x4, %eax
    1308:      	movl	$0x8, %esi
    130d:      	movq	%r13, %rdx
    1310:      	callq	*%rax
    1312:      	movq	0xb8(%rsp), %rbx
    131a:      	testq	%rbx, %rbx
    131d:      	je	0x13f9 <event_execve+0x13f9>
    1323:      	movl	$0x0, 0xac(%rsp)
    132e:      	movq	(%rip), %rdi            # 0x1335 <event_execve+0x1335>
    1335:      	leaq	0xac(%rsp), %rsi
    133d:      	movl	$0x1, %eax
    1342:      	callq	*%rax
    1344:      	testq	%rax, %rax
    1347:      	je	0x140f <event_execve+0x140f>
    134d:      	movq	%rax, %rbp
    1350:      	leaq	0x28(%rbx), %rax
    1354:      	movq	%rax, 0xb0(%rsp)
    135c:      	leaq	0x1000(%rbp), %rax
    1363:      	movq	%rax, 0x98(%rsp)
    136b:      	movl	$0x23, %eax
    1370:      	callq	*%rax
    1372:      	leaq	0xd50(%rax), %rdx
    1379:      	leaq	0xc0(%rsp), %rdi
    1381:      	movl	$0x8, %ecx
    1386:      	movl	$0x4, %eax
    138b:      	movl	$0x8, %esi
    1390:      	callq	*%rax
    1392:      	movq	0xc0(%rsp), %r13
    139a:      	addq	$0x30, %rbx
    139e:      	leaq	0xa0(%rsp), %rdi
    13a6:      	movl	$0x8, %ecx
    13ab:      	movl	$0x4, %eax
    13b0:      	leaq	0x18(%r13), %r15
    13b4:      	movl	$0x8, %esi
    13b9:      	movq	%rbx, %rdx
    13bc:      	callq	*%rax
    13be:      	movq	0xa0(%rsp), %r12
    13c6:      	leaq	0x10(%r12), %rdx
    13cb:      	leaq	0x20(%rsp), %rdi
    13d0:      	movl	$0x8, %ecx
    13d5:      	movl	$0x4, %eax
    13da:      	movl	$0x8, %esi
    13df:      	callq	*%rax
    13e1:      	cmpq	$0x0, 0x20(%rsp)
    13e7:      	movl	$0x1000, %r14d          # imm = 0x1000
    13ed:      	je	0x141b <event_execve+0x141b>
    13ef:      	movq	0x98(%rsp), %rcx
    13f7:      	jmp	0x146f <event_execve+0x146f>
    13f9:      	movq	0x78(%rsp), %rax
    13fe:      	orb	$0x20, 0x15d(%rax)
    1405:      	movq	0x70(%rsp), %r13
    140a:      	jmp	0x1946 <event_execve+0x1946>
    140f:      	xorl	%ebp, %ebp
    1411:      	movq	0x70(%rsp), %r13
    1416:      	jmp	0x1946 <event_execve+0x1946>
    141b:      	leaq	0x18(%r12), %rdx
    1420:      	leaq	0x20(%rsp), %rdi
    1425:      	movl	$0x8, %ecx
    142a:      	movl	$0x4, %eax
    142f:      	movl	$0x8, %esi
    1434:      	callq	*%rax
    1436:      	cmpq	%r12, 0x20(%rsp)
    143b:      	movq	0x98(%rsp), %rcx
    1443:      	je	0x146f <event_execve+0x146f>
    1445:      	movq	%rbp, %rcx
    1448:      	addq	$0xff6, %rcx            # imm = 0xFF6
    144f:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    1459:      	movq	%rax, 0xff6(%rbp)
    1460:      	movw	$0x2964, 0xffe(%rbp)    # imm = 0x2964
    1469:      	movl	$0xff6, %r14d           # imm = 0xFF6
    146f:      	movq	$0x0, 0x28(%rsp)
    1478:      	movq	$0x0, 0x20(%rsp)
    1481:      	movq	%rbp, 0x30(%rsp)
    1486:      	movq	$0x0, 0x38(%rsp)
    148f:      	movq	$0x0, 0x40(%rsp)
    1498:      	movq	$0x0, 0x48(%rsp)
    14a1:      	movq	%rcx, 0x98(%rsp)
    14a9:      	movq	%rcx, 0x50(%rsp)
    14ae:      	movl	%r14d, 0x58(%rsp)
    14b3:      	movb	$0x0, 0x5c(%rsp)
    14b8:      	addq	$0x20, %r13
    14bc:      	leaq	0x20(%rsp), %rdi
    14c1:      	movl	$0x8, %ecx
    14c6:      	movl	$0x4, %eax
    14cb:      	leaq	0x28(%rsp), %rbp
    14d0:      	leaq	0x38(%rsp), %r14
    14d5:      	leaq	0x40(%rsp), %r12
    14da:      	movl	$0x8, %esi
    14df:      	movq	%r13, %rdx
    14e2:      	callq	*%rax
    14e4:      	movl	$0x8, %ecx
    14e9:      	movl	$0x4, %eax
    14ee:      	movq	%rbp, %rdi
    14f1:      	movl	$0x8, %esi
    14f6:      	movq	%r15, %rdx
    14f9:      	callq	*%rax
    14fb:      	movl	$0x8, %ecx
    1500:      	movl	$0x4, %eax
    1505:      	movq	%r14, %rdi
    1508:      	movl	$0x8, %esi
    150d:      	movq	%rbx, %rdx
    1510:      	callq	*%rax
    1512:      	movl	$0x8, %ecx
    1517:      	movl	$0x4, %eax
    151c:      	movq	0xb0(%rsp), %rdx
    1524:      	movq	%r12, %rdi
    1527:      	movl	$0x8, %esi
    152c:      	callq	*%rax
    152e:      	movq	0x40(%rsp), %rax
    1533:      	addq	$-0x20, %rax
    1537:      	movq	%rax, 0x48(%rsp)
    153c:      	movq	(%rip), %rax            # 0x1543 <event_execve+0x1543>
    1543:      	cmpb	$0x0, (%rax)
    1546:      	je	0x16ee <event_execve+0x16ee>
    154c:      	movl	$0x800, %r12d           # imm = 0x800
    1552:      	movl	$0x8, %r13d
    1558:      	nopl	(%rax,%rax)
    1560:      	movq	0x38(%rsp), %rbp
    1565:      	movq	0x40(%rsp), %rdx
    156a:      	movq	0x48(%rsp), %r15
    156f:      	cmpq	0x20(%rsp), %rbp
    1574:      	jne	0x1581 <event_execve+0x1581>
    1576:      	cmpq	0x28(%rsp), %rdx
    157b:      	je	0x1887 <event_execve+0x1887>
    1581:      	movl	$0x4, %eax
    1586:      	leaq	0x68(%rsp), %rdi
    158b:      	movl	$0x8, %esi
    1590:      	callq	*%rax
    1592:      	cmpq	0x68(%rsp), %rbp
    1597:      	je	0x1690 <event_execve+0x1690>
    159d:      	leaq	0x18(%rbp), %rbx
    15a1:      	movl	$0x4, %eax
    15a6:      	leaq	0x10(%rsp), %rdi
    15ab:      	movl	$0x8, %esi
    15b0:      	movq	%rbx, %rdx
    15b3:      	callq	*%rax
    15b5:      	cmpq	%rbp, 0x10(%rsp)
    15ba:      	je	0x1690 <event_execve+0x1690>
    15c0:      	movl	$0x4, %eax
    15c5:      	leaq	0x18(%rsp), %rdi
    15ca:      	movl	$0x8, %esi
    15cf:      	movq	%rbx, %rdx
    15d2:      	callq	*%rax
    15d4:      	addq	$0x20, %rbp
    15d8:      	movl	$0x4, %eax
    15dd:      	movq	%rsp, %rdi
    15e0:      	movl	$0x10, %ecx
    15e5:      	movl	$0x10, %esi
    15ea:      	movq	%rbp, %rdx
    15ed:      	callq	*%rax
    15ef:      	movq	0x30(%rsp), %rbx
    15f4:      	movq	0x50(%rsp), %rax
    15f9:      	movl	0x4(%rsp), %ebp
    15fd:      	subq	%rbx, %rax
    1600:      	movl	0x58(%rsp), %r14d
    1605:      	movl	%ebp, %edx
    1607:      	subl	%r14d, %edx
    160a:      	movl	$0x0, %ecx
    160f:      	cmovbl	%ecx, %edx
    1612:      	addq	0x8(%rsp), %rdx
    1617:      	xorl	%esi, %esi
    1619:      	cmpl	%ebp, %r14d
    161c:      	seta	%sil
    1620:      	movl	%ebp, %ecx
    1622:      	cmovbl	%r14d, %ecx
    1626:      	addl	%ecx, %esi
    1628:      	movl	%r14d, %edi
    162b:      	subl	%esi, %edi
    162d:      	movl	%edi, 0x58(%rsp)
    1631:      	subq	%rsi, %rax
    1634:      	jb	0x188c <event_execve+0x188c>
    163a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    1640:      	ja	0x188c <event_execve+0x188c>
    1646:      	cmpl	%ebp, %r14d
    1649:      	jbe	0x164f <event_execve+0x164f>
    164b:      	movb	$0x2f, (%rbx,%rax)
    164f:      	xorl	%edi, %edi
    1651:      	cmpl	%ebp, %r14d
    1654:      	seta	%dil
    1658:      	movzbl	%cl, %esi
    165b:      	addq	%rax, %rbx
    165e:      	addq	%rbx, %rdi
    1661:      	movl	$0x4, %eax
    1666:      	callq	*%rax
    1668:      	movq	%rbx, 0x50(%rsp)
    166d:      	cmpl	%ebp, %r14d
    1670:      	jbe	0x188c <event_execve+0x188c>
    1676:      	movq	0x18(%rsp), %rax
    167b:      	movq	%rax, 0x38(%rsp)
    1680:      	decl	%r12d
    1683:      	jne	0x1560 <event_execve+0x1560>
    1689:      	jmp	0x188c <event_execve+0x188c>
    168e:      	nop
    1690:      	leaq	0x10(%r15), %rdx
    1694:      	movl	$0x4, %eax
    1699:      	leaq	0x10(%rsp), %rdi
    169e:      	movl	$0x8, %esi
    16a3:      	callq	*%rax
    16a5:      	movq	0x48(%rsp), %rax
    16aa:      	cmpq	0x10(%rsp), %rax
    16af:      	je	0x1887 <event_execve+0x1887>
    16b5:      	addq	$0x18, %r15
    16b9:      	movl	$0x4, %eax
    16be:      	leaq	0x38(%rsp), %rdi
    16c3:      	movl	$0x8, %esi
    16c8:      	movq	%r15, %rdx
    16cb:      	callq	*%rax
    16cd:      	movq	0x10(%rsp), %rax
    16d2:      	movq	%rax, 0x48(%rsp)
    16d7:      	addq	$0x20, %rax
    16db:      	movq	%rax, 0x40(%rsp)
    16e0:      	decl	%r12d
    16e3:      	jne	0x1560 <event_execve+0x1560>
    16e9:      	jmp	0x188c <event_execve+0x188c>
    16ee:      	movl	$0x800, %r12d           # imm = 0x800
    16f4:      	movl	$0x8, %r13d
    16fa:      	nopw	(%rax,%rax)
    1700:      	movq	0x38(%rsp), %rbp
    1705:      	movq	0x40(%rsp), %rdx
    170a:      	movq	0x48(%rsp), %r15
    170f:      	cmpq	0x20(%rsp), %rbp
    1714:      	jne	0x1721 <event_execve+0x1721>
    1716:      	cmpq	0x28(%rsp), %rdx
    171b:      	je	0x1887 <event_execve+0x1887>
    1721:      	movl	$0x4, %eax
    1726:      	leaq	0x68(%rsp), %rdi
    172b:      	movl	$0x8, %esi
    1730:      	callq	*%rax
    1732:      	cmpq	0x68(%rsp), %rbp
    1737:      	je	0x1830 <event_execve+0x1830>
    173d:      	leaq	0x18(%rbp), %rbx
    1741:      	movl	$0x4, %eax
    1746:      	leaq	0x10(%rsp), %rdi
    174b:      	movl	$0x8, %esi
    1750:      	movq	%rbx, %rdx
    1753:      	callq	*%rax
    1755:      	cmpq	%rbp, 0x10(%rsp)
    175a:      	je	0x1830 <event_execve+0x1830>
    1760:      	movl	$0x4, %eax
    1765:      	leaq	0x18(%rsp), %rdi
    176a:      	movl	$0x8, %esi
    176f:      	movq	%rbx, %rdx
    1772:      	callq	*%rax
    1774:      	addq	$0x20, %rbp
    1778:      	movl	$0x4, %eax
    177d:      	movq	%rsp, %rdi
    1780:      	movl	$0x10, %ecx
    1785:      	movl	$0x10, %esi
    178a:      	movq	%rbp, %rdx
    178d:      	callq	*%rax
    178f:      	movq	0x30(%rsp), %rbx
    1794:      	movq	0x50(%rsp), %rax
    1799:      	movl	0x4(%rsp), %ebp
    179d:      	subq	%rbx, %rax
    17a0:      	movl	0x58(%rsp), %r14d
    17a5:      	movl	%ebp, %edx
    17a7:      	subl	%r14d, %edx
    17aa:      	movl	$0x0, %ecx
    17af:      	cmovbl	%ecx, %edx
    17b2:      	addq	0x8(%rsp), %rdx
    17b7:      	xorl	%esi, %esi
    17b9:      	cmpl	%ebp, %r14d
    17bc:      	seta	%sil
    17c0:      	movl	%ebp, %ecx
    17c2:      	cmovbl	%r14d, %ecx
    17c6:      	addl	%ecx, %esi
    17c8:      	movl	%r14d, %edi
    17cb:      	subl	%esi, %edi
    17cd:      	movl	%edi, 0x58(%rsp)
    17d1:      	subq	%rsi, %rax
    17d4:      	jb	0x188c <event_execve+0x188c>
    17da:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    17e0:      	ja	0x188c <event_execve+0x188c>
    17e6:      	cmpl	%ebp, %r14d
    17e9:      	jbe	0x17ef <event_execve+0x17ef>
    17eb:      	movb	$0x2f, (%rbx,%rax)
    17ef:      	xorl	%edi, %edi
    17f1:      	cmpl	%ebp, %r14d
    17f4:      	seta	%dil
    17f8:      	movzbl	%cl, %esi
    17fb:      	addq	%rax, %rbx
    17fe:      	addq	%rbx, %rdi
    1801:      	movl	$0x4, %eax
    1806:      	callq	*%rax
    1808:      	movq	%rbx, 0x50(%rsp)
    180d:      	cmpl	%ebp, %r14d
    1810:      	jbe	0x188c <event_execve+0x188c>
    1812:      	movq	0x18(%rsp), %rax
    1817:      	movq	%rax, 0x38(%rsp)
    181c:      	decl	%r12d
    181f:      	jne	0x1700 <event_execve+0x1700>
    1825:      	jmp	0x188c <event_execve+0x188c>
    1827:      	nopw	(%rax,%rax)
    1830:      	leaq	0x10(%r15), %rdx
    1834:      	movl	$0x4, %eax
    1839:      	leaq	0x10(%rsp), %rdi
    183e:      	movl	$0x8, %esi
    1843:      	callq	*%rax
    1845:      	movq	0x48(%rsp), %rax
    184a:      	cmpq	0x10(%rsp), %rax
    184f:      	je	0x1887 <event_execve+0x1887>
    1851:      	addq	$0x18, %r15
    1855:      	movl	$0x4, %eax
    185a:      	leaq	0x38(%rsp), %rdi
    185f:      	movl	$0x8, %esi
    1864:      	movq	%r15, %rdx
    1867:      	callq	*%rax
    1869:      	movq	0x10(%rsp), %rax
    186e:      	movq	%rax, 0x48(%rsp)
    1873:      	addq	$0x20, %rax
    1877:      	movq	%rax, 0x40(%rsp)
    187c:      	decl	%r12d
    187f:      	jne	0x1700 <event_execve+0x1700>
    1885:      	jmp	0x188c <event_execve+0x188c>
    1887:      	movb	$0x1, 0x5c(%rsp)
    188c:      	movq	0x50(%rsp), %rax
    1891:      	movq	0x98(%rsp), %rdx
    1899:      	cmpq	%rdx, %rax
    189c:      	je	0x18d8 <event_execve+0x18d8>
    189e:      	xorl	%ebx, %ebx
    18a0:      	cmpb	$0x0, 0x5c(%rsp)
    18a5:      	sete	%cl
    18a8:      	movl	0x58(%rsp), %edx
    18ac:      	movl	$0x1000, %ebp           # imm = 0x1000
    18b1:      	subl	%edx, %ebp
    18b3:      	testl	%edx, %edx
    18b5:      	cmovlel	%edx, %ebp
    18b8:      	testq	%rax, %rax
    18bb:      	movq	0x78(%rsp), %r15
    18c0:      	movq	0x80(%rsp), %r12
    18c8:      	movq	0x70(%rsp), %r13
    18cd:      	je	0x1944 <event_execve+0x1944>
    18cf:      	movb	%cl, %bl
    18d1:      	addl	%ebx, %ebx
    18d3:      	movq	%rax, %rdx
    18d6:      	jmp	0x18ee <event_execve+0x18ee>
    18d8:      	xorl	%ebp, %ebp
    18da:      	xorl	%ebx, %ebx
    18dc:      	movq	0x78(%rsp), %r15
    18e1:      	movq	0x80(%rsp), %r12
    18e9:      	movq	0x70(%rsp), %r13
    18ee:      	movq	0x90(%rsp), %rdi
    18f6:      	andl	$0x3ff, %edi            # imm = 0x3FF
    18fc:      	andl	$0xfff, %ebp            # imm = 0xFFF
    1902:      	addq	%r13, %rdi
    1905:      	movl	$0x4, %eax
    190a:      	movl	%ebp, %esi
    190c:      	callq	*%rax
    190e:      	movl	0x15c(%r15), %eax
    1915:      	movl	%eax, %ecx
    1917:      	orl	$0x1000, %ecx           # imm = 0x1000
    191d:      	testl	%ebp, %ebp
    191f:      	cmovnel	%eax, %ecx
    1922:      	movl	%ecx, %eax
    1924:      	orl	$0x400000, %eax         # imm = 0x400000
    1929:      	testl	%ebx, %ebx
    192b:      	cmovel	%ecx, %eax
    192e:      	andl	$0xffffdbff, %eax       # imm = 0xFFFFDBFF
    1933:      	movl	%eax, 0x15c(%r15)
    193a:      	movw	%bp, 0x17c(%r15)
    1942:      	jmp	0x1946 <event_execve+0x1946>
    1944:      	xorl	%ebp, %ebp
    1946:      	movl	(%r13), %edx
    194a:      	addl	%ebp, %edx
    194c:      	movl	%edx, (%r13)
    1950:      	movq	$0x0, (%rsp)
    1958:      	movq	(%rip), %rax            # 0x195f <event_execve+0x195f>
    195f:      	xorl	%r13d, %r13d
    1962:      	cmpb	$0x0, (%rax)
    1965:      	je	0x1c71 <event_execve+0x1c71>
    196b:      	cmpl	$0x3ff, %edx            # imm = 0x3FF
    1971:      	ja	0x1c71 <event_execve+0x1c71>
    1977:      	movq	%rdx, %r15
    197a:      	movl	$0x23, %eax
    197f:      	callq	*%rax
    1981:      	leaq	0xa78(%rax), %rdx
    1988:      	movq	%rsp, %rdi
    198b:      	movl	$0x8, %ecx
    1990:      	movl	$0x4, %eax
    1995:      	movl	$0x8, %esi
    199a:      	callq	*%rax
    199c:      	movq	(%rsp), %rcx
    19a0:      	testq	%rcx, %rcx
    19a3:      	je	0x1c71 <event_execve+0x1c71>
    19a9:      	addq	$0x2c8, %rcx            # imm = 0x2C8
    19b0:      	leaq	0x10(%rsp), %rdi
    19b5:      	movl	$0x8, %edx
    19ba:      	movl	$0x4, %eax
    19bf:      	movl	$0x2c8, %edx            # imm = 0x2C8
    19c4:      	addq	(%rsp), %rdx
    19c8:      	movl	$0x8, %esi
    19cd:      	callq	*%rax
    19cf:      	testq	%rax, %rax
    19d2:      	je	0x1a31 <event_execve+0x1a31>
    19d4:      	negl	%eax
    19d6:      	movw	%ax, 0x20(%rsp)
    19db:      	movw	$0x9, 0x22(%rsp)
    19e2:      	movabsq	$0x40000009a, %rax      # imm = 0x40000009A
    19ec:      	movq	%rax, 0x24(%rsp)
    19f1:      	movq	(%rip), %rdi            # 0x19f8 <event_execve+0x19f8>
    19f8:      	leaq	0x20(%rsp), %rsi
    19fd:      	movl	$0x1, %eax
    1a02:      	callq	*%rax
    1a04:      	testq	%rax, %rax
    1a07:      	je	0x1a0d <event_execve+0x1a0d>
    1a09:      	incl	(%rax)
    1a0b:      	jmp	0x1a31 <event_execve+0x1a31>
    1a0d:      	movl	$0x1, 0x18(%rsp)
    1a15:      	movq	(%rip), %rdi            # 0x1a1c <event_execve+0x1a1c>
    1a1c:      	xorl	%ecx, %ecx
    1a1e:      	leaq	0x20(%rsp), %rsi
    1a23:      	leaq	0x18(%rsp), %rdx
    1a28:      	movl	$0x2, %eax
    1a2d:      	xorl	%ecx, %ecx
    1a2f:      	callq	*%rax
    1a31:      	movl	$0x2d0, %edx            # imm = 0x2D0
    1a36:      	movq	(%rsp), %rcx
    1a3a:      	addq	%rdx, %rcx
    1a3d:      	leaq	0x18(%rsp), %rdi
    1a42:      	movl	$0x8, %esi
    1a47:      	movl	$0x4, %eax
    1a4c:      	addq	(%rsp), %rdx
    1a50:      	movl	$0x8, %esi
    1a55:      	callq	*%rax
    1a57:      	testq	%rax, %rax
    1a5a:      	je	0x1a97 <event_execve+0x1a97>
    1a5c:      	negl	%eax
    1a5e:      	movw	%ax, 0x20(%rsp)
    1a63:      	movw	$0x9, 0x22(%rsp)
    1a6a:      	movabsq	$0x40000009b, %rax      # imm = 0x40000009B
    1a74:      	movq	%rax, 0x24(%rsp)
    1a79:      	movq	(%rip), %rdi            # 0x1a80 <event_execve+0x1a80>
    1a80:      	leaq	0x20(%rsp), %rsi
    1a85:      	movl	$0x1, %eax
    1a8a:      	callq	*%rax
    1a8c:      	testq	%rax, %rax
    1a8f:      	je	0x1be8 <event_execve+0x1be8>
    1a95:      	incl	(%rax)
    1a97:      	movq	0x10(%rsp), %rbx
    1a9c:      	testq	%rbx, %rbx
    1a9f:      	je	0x1c71 <event_execve+0x1c71>
    1aa5:      	movq	0x18(%rsp), %rax
    1aaa:      	testq	%rax, %rax
    1aad:      	je	0x1c71 <event_execve+0x1c71>
    1ab3:      	movl	%r15d, %r12d
    1ab6:      	movq	%rax, %r13
    1ab9:      	subq	%rbx, %r13
    1abc:      	cmpq	$0x3ff, %r13            # imm = 0x3FF
    1ac3:      	ja	0x1b1c <event_execve+0x1b1c>
    1ac5:      	movq	0x78(%rsp), %rcx
    1aca:      	leaq	(%rcx,%r12), %rdi
    1ace:      	addq	$0x140, %rdi            # imm = 0x140
    1ad5:      	addq	$0x540, %rcx            # imm = 0x540
    1adc:      	subq	%rdi, %rcx
    1adf:      	cmpq	%rcx, %r13
    1ae2:      	jae	0x1b1c <event_execve+0x1b1c>
    1ae4:      	decl	%r13d
    1ae7:      	andl	$0x3ff, %r13d           # imm = 0x3FF
    1aee:      	xorl	%ebp, %ebp
    1af0:      	cmpq	%rbx, %rax
    1af3:      	cmovel	%ebp, %r13d
    1af7:      	movl	$0x4, %eax
    1afc:      	movq	0x10(%rsp), %rdx
    1b01:      	movl	%r13d, %esi
    1b04:      	callq	*%rax
    1b06:      	andl	$0x80000000, %eax       # imm = 0x80000000
    1b0b:      	movl	%eax, %ecx
    1b0d:      	shrl	$0x1c, %ecx
    1b10:      	testq	%rax, %rax
    1b13:      	cmovnel	%ebp, %r13d
    1b17:      	jmp	0x1c56 <event_execve+0x1c56>
    1b1c:      	movl	$0x0, 0x68(%rsp)
    1b24:      	movq	(%rip), %rdi            # 0x1b2b <event_execve+0x1b2b>
    1b2b:      	leaq	0x68(%rsp), %rsi
    1b30:      	movl	$0x1, %eax
    1b35:      	callq	*%rax
    1b37:      	testq	%rax, %rax
    1b3a:      	je	0x1c1c <event_execve+0x1c1c>
    1b40:      	movq	%rax, %r15
    1b43:      	addq	0x78(%rsp), %r12
    1b48:      	movl	$0x18, (%rax)
    1b4e:      	movl	$0xe, %eax
    1b53:      	callq	*%rax
    1b55:      	movq	%r15, %r14
    1b58:      	addq	$0x10, %r14
    1b5c:      	movq	%rax, 0x10(%r15)
    1b60:      	cmpq	$-0x16, %rax
    1b64:      	jne	0x1b90 <event_execve+0x1b90>
    1b66:      	movq	0x88(%rsp), %rax
    1b6e:      	leaq	0x20(%rax), %rdx
    1b72:      	leaq	0x20(%rsp), %rdi
    1b77:      	movl	$0x8, %ecx
    1b7c:      	movl	$0x4, %eax
    1b81:      	movl	$0x8, %esi
    1b86:      	callq	*%rax
    1b88:      	movq	0x20(%rsp), %rax
    1b8d:      	movq	%rax, (%r14)
    1b90:      	movl	$0x7d, %eax
    1b95:      	callq	*%rax
    1b97:      	movq	%rax, 0x18(%r15)
    1b9b:      	movq	(%r14), %rax
    1b9e:      	movq	0x8(%r14), %rcx
    1ba2:      	movq	%rax, 0x150(%r12)
    1baa:      	movq	%rcx, 0x158(%r12)
    1bb2:      	movq	0x88(%rsp), %rdi
    1bba:      	movq	%r15, %rsi
    1bbd:      	movq	%rbx, %rdx
    1bc0:      	movq	%r13, %rcx
    1bc3:      	callq	0x1bc8 <event_execve+0x1bc8>
    1bc8:      	testl	%eax, %eax
    1bca:      	js	0x1c23 <event_execve+0x1c23>
    1bcc:      	movq	$0x0, 0x140(%r12)
    1bd8:      	movl	%r13d, %edx
    1bdb:      	subl	%eax, %edx
    1bdd:      	xorl	%ecx, %ecx
    1bdf:      	cmpq	$-0x1, %r13
    1be3:      	cmovnel	%edx, %ecx
    1be6:      	jmp	0x1c3b <event_execve+0x1c3b>
    1be8:      	movl	$0x1, 0x68(%rsp)
    1bf0:      	movq	(%rip), %rdi            # 0x1bf7 <event_execve+0x1bf7>
    1bf7:      	xorl	%ecx, %ecx
    1bf9:      	leaq	0x20(%rsp), %rsi
    1bfe:      	leaq	0x68(%rsp), %rdx
    1c03:      	movl	$0x2, %eax
    1c08:      	xorl	%ecx, %ecx
    1c0a:      	callq	*%rax
    1c0c:      	movq	0x10(%rsp), %rbx
    1c11:      	testq	%rbx, %rbx
    1c14:      	jne	0x1aa5 <event_execve+0x1aa5>
    1c1a:      	jmp	0x1c71 <event_execve+0x1c71>
    1c1c:      	xorl	%ecx, %ecx
    1c1e:      	xorl	%r13d, %r13d
    1c21:      	jmp	0x1c56 <event_execve+0x1c56>
    1c23:      	movl	%eax, 0x140(%r12)
    1c2b:      	movl	$0x0, 0x144(%r12)
    1c37:      	xorl	%ecx, %ecx
    1c39:      	xorl	%eax, %eax
    1c3b:      	movl	%ecx, 0x148(%r12)
    1c43:      	movl	%eax, 0x14c(%r12)
    1c4b:      	movl	$0x20, %r13d
    1c51:      	movl	$0x2, %ecx
    1c56:      	movq	0x80(%rsp), %r12
    1c5e:      	movq	0x78(%rsp), %rax
    1c63:      	movw	%r13w, 0x17e(%rax)
    1c6b:      	orl	%ecx, 0x15c(%rax)
    1c71:      	movq	0x78(%rsp), %rbp
    1c76:      	movl	0x140(%rbp), %eax
    1c7c:      	leal	(%rax,%r13), %ecx
    1c80:      	movl	%ecx, 0x140(%rbp)
    1c86:      	movw	$0x5, (%rbp)
    1c8c:      	movq	0x170(%rbp), %rcx
    1c93:      	movq	%rcx, 0x8(%rbp)
    1c97:      	leal	0x140(%rax,%r13), %eax
    1c9f:      	movl	%eax, 0x4(%rbp)
    1ca2:      	leaq	0xd00(%r12), %r14
    1caa:      	leaq	0x20(%rsp), %rdi
    1caf:      	movl	$0x8, %ecx
    1cb4:      	movl	$0x4, %eax
    1cb9:      	leaq	0xb8(%rbp), %rbx
    1cc0:      	movl	$0x4, %r13d
    1cc6:      	movl	$0x8, %esi
    1ccb:      	movq	%r14, %rdx
    1cce:      	callq	*%rax
    1cd0:      	movq	0x20(%rsp), %rcx
    1cd5:      	addq	$0x8, %rcx
    1cd9:      	movl	$0x4, %edx
    1cde:      	movl	$0x4, %eax
    1ce3:      	movq	0x20(%rsp), %rdx
    1ce8:      	addq	$0x8, %rdx
    1cec:      	movq	%rbx, %rdi
    1cef:      	movl	$0x4, %esi
    1cf4:      	callq	*%rax
    1cf6:      	leaq	0xbc(%rbp), %rdi
    1cfd:      	movq	0x20(%rsp), %rcx
    1d02:      	addq	$0xc, %rcx
    1d06:      	movl	$0x4, %edx
    1d0b:      	movl	$0x4, %eax
    1d10:      	movq	0x20(%rsp), %rdx
    1d15:      	addq	$0xc, %rdx
    1d19:      	movl	$0x4, %esi
    1d1e:      	callq	*%rax
    1d20:      	leaq	0xc8(%rbp), %rdi
    1d27:      	movq	0x20(%rsp), %rcx
    1d2c:      	addq	$0x18, %rcx
    1d30:      	movl	$0x4, %edx
    1d35:      	movl	$0x4, %eax
    1d3a:      	movq	0x20(%rsp), %rdx
    1d3f:      	addq	$0x18, %rdx
    1d43:      	movl	$0x4, %esi
    1d48:      	callq	*%rax
    1d4a:      	leaq	0xcc(%rbp), %rdi
    1d51:      	movq	0x20(%rsp), %rcx
    1d56:      	addq	$0x1c, %rcx
    1d5a:      	movl	$0x4, %edx
    1d5f:      	movl	$0x4, %eax
    1d64:      	movq	0x20(%rsp), %rdx
    1d69:      	addq	$0x1c, %rdx
    1d6d:      	movl	$0x4, %esi
    1d72:      	callq	*%rax
    1d74:      	leaq	0xc0(%rbp), %rdi
    1d7b:      	movq	0x20(%rsp), %rcx
    1d80:      	addq	$0x10, %rcx
    1d84:      	movl	$0x4, %edx
    1d89:      	movl	$0x4, %eax
    1d8e:      	movq	0x20(%rsp), %rdx
    1d93:      	addq	$0x10, %rdx
    1d97:      	movl	$0x4, %esi
    1d9c:      	callq	*%rax
    1d9e:      	leaq	0xc4(%rbp), %rdi
    1da5:      	movq	0x20(%rsp), %rcx
    1daa:      	addq	$0x14, %rcx
    1dae:      	movl	$0x4, %edx
    1db3:      	movl	$0x4, %eax
    1db8:      	movq	0x20(%rsp), %rdx
    1dbd:      	addq	$0x14, %rdx
    1dc1:      	movl	$0x4, %esi
    1dc6:      	callq	*%rax
    1dc8:      	leaq	0xd0(%rbp), %rdi
    1dcf:      	movq	0x20(%rsp), %rcx
    1dd4:      	addq	$0x20, %rcx
    1dd8:      	movl	$0x4, %edx
    1ddd:      	movl	$0x4, %eax
    1de2:      	movq	0x20(%rsp), %rdx
    1de7:      	addq	$0x20, %rdx
    1deb:      	movl	$0x4, %esi
    1df0:      	callq	*%rax
    1df2:      	leaq	0xd4(%rbp), %rdi
    1df9:      	movq	0x20(%rsp), %rcx
    1dfe:      	addq	$0x24, %rcx
    1e02:      	movl	$0x4, %edx
    1e07:      	movl	$0x4, %eax
    1e0c:      	movq	0x20(%rsp), %rdx
    1e11:      	addq	$0x24, %rdx
    1e15:      	movl	$0x4, %esi
    1e1a:      	callq	*%rax
    1e1c:      	leaq	0xd8(%rbp), %rdi
    1e23:      	movq	0x20(%rsp), %rcx
    1e28:      	addq	$0x28, %rcx
    1e2c:      	movl	$0x4, %edx
    1e31:      	movl	$0x4, %eax
    1e36:      	movq	0x20(%rsp), %rdx
    1e3b:      	addq	$0x28, %rdx
    1e3f:      	movl	$0x4, %esi
    1e44:      	callq	*%rax
    1e46:      	movq	0x20(%rsp), %rbx
    1e4b:      	leaq	0xe8(%rbp), %rdi
    1e52:      	leaq	0x40(%rbx), %rdx
    1e56:      	movl	$0x8, %ecx
    1e5b:      	movl	$0x4, %eax
    1e60:      	leaq	0xe0(%rbp), %r15
    1e67:      	movl	$0x8, %esi
    1e6c:      	callq	*%rax
    1e6e:      	leaq	0xf0(%rbp), %rdi
    1e75:      	leaq	0x30(%rbx), %rdx
    1e79:      	movl	$0x8, %ecx
    1e7e:      	movl	$0x4, %eax
    1e83:      	movl	$0x8, %esi
    1e88:      	callq	*%rax
    1e8a:      	addq	$0x38, %rbx
    1e8e:      	movl	$0x8, %ecx
    1e93:      	movl	$0x4, %eax
    1e98:      	movq	%r15, %rdi
    1e9b:      	movl	$0x8, %esi
    1ea0:      	movq	%rbx, %rdx
    1ea3:      	callq	*%rax
    1ea5:      	movl	0xc8(%rbp), %eax
    1eab:      	movl	%eax, 0x154(%rbp)
    1eb1:      	leaq	0xd70(%r12), %rdx
    1eb9:      	leaq	0x10(%rsp), %rdi
    1ebe:      	movl	$0x8, %ecx
    1ec3:      	movl	$0x4, %eax
    1ec8:      	leaq	0x108(%rbp), %rbx
    1ecf:      	movl	$0x8, %esi
    1ed4:      	callq	*%rax
    1ed6:      	movq	0x10(%rsp), %rcx
    1edb:      	leaq	0x20(%rsp), %rdi
    1ee0:      	movl	$0x48, %edx
    1ee5:      	movl	$0x4, %eax
    1eea:      	movq	0x10(%rsp), %rdx
    1eef:      	movl	$0x48, %esi
    1ef4:      	callq	*%rax
    1ef6:      	movl	$0x218, %edx            # imm = 0x218
    1efb:      	movq	0x28(%rsp), %rcx
    1f00:      	addq	%rdx, %rcx
    1f03:      	movl	$0x4, %esi
    1f08:      	movl	$0x4, %eax
    1f0d:      	addq	0x28(%rsp), %rdx
    1f12:      	movq	%rbx, %rdi
    1f15:      	movl	$0x4, %esi
    1f1a:      	callq	*%rax
    1f1c:      	leaq	0x10c(%rbp), %rdi
    1f23:      	movl	$0x4d8, %edx            # imm = 0x4D8
    1f28:      	movq	0x30(%rsp), %rcx
    1f2d:      	addq	%rdx, %rcx
    1f30:      	movl	$0x4, %esi
    1f35:      	movl	$0x4, %eax
    1f3a:      	addq	0x30(%rsp), %rdx
    1f3f:      	movl	$0x4, %esi
    1f44:      	callq	*%rax
    1f46:      	leaq	0x110(%rbp), %rdi
    1f4d:      	movq	0x38(%rsp), %rcx
    1f52:      	addq	$0x58, %rcx
    1f56:      	movl	$0x4, %edx
    1f5b:      	movl	$0x4, %eax
    1f60:      	movq	0x38(%rsp), %rdx
    1f65:      	addq	$0x58, %rdx
    1f69:      	movl	$0x4, %esi
    1f6e:      	callq	*%rax
    1f70:      	movq	$0x0, 0x18(%rsp)
    1f79:      	leaq	0xb58(%r12), %rdx
    1f81:      	leaq	0x18(%rsp), %rdi
    1f86:      	movl	$0x8, %ecx
    1f8b:      	movl	$0x4, %eax
    1f90:      	movl	$0x8, %esi
    1f95:      	callq	*%rax
    1f97:      	movq	0x18(%rsp), %rcx
    1f9c:      	testq	%rcx, %rcx
    1f9f:      	je	0x2036 <event_execve+0x2036>
    1fa5:      	movl	$0x0, 0x68(%rsp)
    1fad:      	addq	$0x4, %rcx
    1fb1:      	leaq	0x68(%rsp), %rdi
    1fb6:      	movl	$0x4, %eax
    1fbb:      	movq	0x18(%rsp), %rdx
    1fc0:      	addq	$0x4, %rdx
    1fc4:      	movl	$0x4, %esi
    1fc9:      	callq	*%rax
    1fcb:      	movq	0x18(%rsp), %rax
    1fd0:      	movslq	0x68(%rsp), %rcx
    1fd5:      	shlq	$0x4, %rcx
    1fd9:      	addq	%rax, %rcx
    1fdc:      	addq	$0x80, %rcx
    1fe3:      	movq	%rsp, %rdi
    1fe6:      	movl	$0x10, %edx
    1feb:      	movl	$0x4, %eax
    1ff0:      	movq	0x18(%rsp), %rcx
    1ff5:      	movslq	0x68(%rsp), %rdx
    1ffa:      	shlq	$0x4, %rdx
    1ffe:      	addq	%rcx, %rdx
    2001:      	addq	$0x80, %rdx
    2008:      	movl	$0x10, %esi
    200d:      	callq	*%rax
    200f:      	leaq	0x114(%rbp), %rdi
    2016:      	movl	$0x158, %edx            # imm = 0x158
    201b:      	movq	0x8(%rsp), %rcx
    2020:      	addq	%rdx, %rcx
    2023:      	movl	$0x4, %eax
    2028:      	addq	0x8(%rsp), %rdx
    202d:      	movl	$0x4, %esi
    2032:      	callq	*%rax
    2034:      	jmp	0x2040 <event_execve+0x2040>
    2036:      	movl	$0x0, 0x114(%rbp)
    2040:      	movq	%rbp, %r13
    2043:      	leaq	0x118(%rbp), %rdi
    204a:      	movl	$0x158, %ebx            # imm = 0x158
    204f:      	movq	0x40(%rsp), %rcx
    2054:      	addq	%rbx, %rcx
    2057:      	movl	$0x4, %edx
    205c:      	movl	$0x4, %eax
    2061:      	movq	0x40(%rsp), %rdx
    2066:      	addq	%rbx, %rdx
    2069:      	movl	$0x4, %esi
    206e:      	callq	*%rax
    2070:      	leaq	0x11c(%rbp), %rdi
    2077:      	movl	$0x118, %edx            # imm = 0x118
    207c:      	movq	0x48(%rsp), %rcx
    2081:      	addq	%rdx, %rcx
    2084:      	movl	$0x4, %esi
    2089:      	movl	$0x4, %eax
    208e:      	addq	0x48(%rsp), %rdx
    2093:      	movl	$0x4, %esi
    2098:      	callq	*%rax
    209a:      	leaq	0x120(%rbp), %rdi
    20a1:      	movl	$0x98, %r15d
    20a7:      	movq	0x50(%rsp), %rcx
    20ac:      	addq	%r15, %rcx
    20af:      	movl	$0x4, %edx
    20b4:      	movl	$0x4, %eax
    20b9:      	movq	0x50(%rsp), %rdx
    20be:      	addq	%r15, %rdx
    20c1:      	movl	$0x4, %esi
    20c6:      	callq	*%rax
    20c8:      	leaq	0x124(%rbp), %rdi
    20cf:      	movq	0x58(%rsp), %rcx
    20d4:      	addq	%r15, %rcx
    20d7:      	movl	$0x4, %edx
    20dc:      	movl	$0x4, %eax
    20e1:      	addq	0x58(%rsp), %r15
    20e6:      	movl	$0x4, %esi
    20eb:      	movq	%r15, %rdx
    20ee:      	callq	*%rax
    20f0:      	leaq	0x128(%rbp), %rdi
    20f7:      	movq	0x60(%rsp), %rcx
    20fc:      	addq	$0x58, %rcx
    2100:      	movl	$0x4, %edx
    2105:      	movl	$0x4, %eax
    210a:      	movq	0x60(%rsp), %rdx
    210f:      	addq	$0x58, %rdx
    2113:      	movl	$0x4, %esi
    2118:      	callq	*%rax
    211a:      	movq	$0x0, (%rsp)
    2122:      	movq	$0x0, 0x18(%rsp)
    212b:      	movq	%rsp, %rdi
    212e:      	movl	$0x8, %ecx
    2133:      	movl	$0x4, %eax
    2138:      	movl	$0x8, %esi
    213d:      	movq	%r14, %rdx
    2140:      	callq	*%rax
    2142:      	movl	$0x90, %edx
    2147:      	movq	(%rsp), %rcx
    214b:      	addq	%rdx, %rcx
    214e:      	leaq	0x18(%rsp), %rdi
    2153:      	movl	$0x8, %esi
    2158:      	movl	$0x4, %eax
    215d:      	addq	(%rsp), %rdx
    2161:      	movl	$0x8, %esi
    2166:      	callq	*%rax
    2168:      	leaq	0x12c(%rbp), %rdi
    216f:      	movq	0x18(%rsp), %rcx
    2174:      	addq	%rbx, %rcx
    2177:      	movl	$0x4, %edx
    217c:      	movl	$0x4, %eax
    2181:      	addq	0x18(%rsp), %rbx
    2186:      	movl	$0x4, %esi
    218b:      	movq	%rbx, %rdx
    218e:      	callq	*%rax
    2190:      	leaq	0x10(%rbp), %r12
    2194:      	movl	$0x0, 0x18(%rsp)
    219c:      	xorl	%ebx, %ebx
    219e:      	movl	$0x90, %edx
    21a3:      	movq	%r12, %rdi
    21a6:      	xorl	%esi, %esi
    21a8:      	callq	0x21ad <event_execve+0x21ad>
    21ad:      	movq	(%rip), %rdi            # 0x21b4 <event_execve+0x21b4>
    21b4:      	leaq	0x18(%rsp), %rsi
    21b9:      	movl	$0x1, %eax
    21be:      	callq	*%rax
    21c0:      	testq	%rax, %rax
    21c3:      	je	0x21d6 <event_execve+0x21d6>
    21c5:      	movl	0x10(%rax), %ebx
    21c8:      	cmpq	$0x63677270, 0x20(%rax) # imm = 0x63677270
    21d0:      	sete	%bpl
    21d4:      	jmp	0x21d8 <event_execve+0x21d8>
    21d6:      	xorl	%ebp, %ebp
    21d8:      	movq	0x88(%rsp), %r14
    21e0:      	movq	$0x0, 0x10(%rsp)
    21e9:      	movq	0x80(%rsp), %rdx
    21f1:      	addq	$0xf90, %rdx            # imm = 0xF90
    21f8:      	movq	%rsp, %rdi
    21fb:      	movl	$0x8, %ecx
    2200:      	movl	$0x71, %eax
    2205:      	movl	$0x8, %esi
    220a:      	callq	*%rax
    220c:      	movq	(%rsp), %rcx
    2210:      	testq	%rcx, %rcx
    2213:      	je	0x240f <event_execve+0x240f>
    2219:      	testb	%bpl, %bpl
    221c:      	je	0x2295 <event_execve+0x2295>
    221e:      	addq	$0x88, %rcx
    2225:      	leaq	0x10(%rsp), %rdi
    222a:      	movl	$0x8, %edx
    222f:      	movl	$0x71, %eax
    2234:      	movl	$0x88, %edx
    2239:      	addq	(%rsp), %rdx
    223d:      	movl	$0x8, %esi
    2242:      	callq	*%rax
    2244:      	movq	0x10(%rsp), %rbx
    2249:      	testq	%rbx, %rbx
    224c:      	je	0x240f <event_execve+0x240f>
    2252:      	movl	$0x50, %eax
    2257:      	callq	*%rax
    2259:      	xorl	%ebp, %ebp
    225b:      	movq	%rax, (%r12)
    225f:      	testq	%rax, %rax
    2262:      	je	0x2364 <event_execve+0x2364>
    2268:      	movq	%rax, 0x20(%rsp)
    226d:      	movq	(%rip), %rdi            # 0x2274 <event_execve+0x2274>
    2274:      	leaq	0x20(%rsp), %rsi
    2279:      	movl	$0x1, %eax
    227e:      	callq	*%rax
    2280:      	testq	%rax, %rax
    2283:      	je	0x236c <event_execve+0x236c>
    2289:      	movq	(%rax), %rax
    228c:      	movq	%rax, 0x18(%r13)
    2290:      	jmp	0x2372 <event_execve+0x2372>
    2295:      	cmpl	$0xb, %ebx
    2298:      	ja	0x240f <event_execve+0x240f>
    229e:      	movl	%ebx, %edx
    22a0:      	leaq	(%rcx,%rdx,8), %rcx
    22a4:      	leaq	0x20(%rsp), %rdi
    22a9:      	movl	$0x8, %esi
    22ae:      	movl	$0x71, %eax
    22b3:      	shlq	$0x3, %rdx
    22b7:      	addq	(%rsp), %rdx
    22bb:      	movl	$0x8, %esi
    22c0:      	callq	*%rax
    22c2:      	movq	0x20(%rsp), %rcx
    22c7:      	testq	%rcx, %rcx
    22ca:      	je	0x23fc <event_execve+0x23fc>
    22d0:      	leaq	0x10(%rsp), %rdi
    22d5:      	movl	$0x8, %edx
    22da:      	movl	$0x71, %eax
    22df:      	movq	0x20(%rsp), %rdx
    22e4:      	movl	$0x8, %esi
    22e9:      	callq	*%rax
    22eb:      	movq	0x10(%rsp), %rbx
    22f0:      	testq	%rbx, %rbx
    22f3:      	je	0x240f <event_execve+0x240f>
    22f9:      	xorl	%ebp, %ebp
    22fb:      	movq	$0x0, 0x20(%rsp)
    2304:      	leaq	0x100(%rbx), %rdx
    230b:      	leaq	0x20(%rsp), %rdi
    2310:      	movl	$0x8, %ecx
    2315:      	movl	$0x71, %eax
    231a:      	movl	$0x8, %esi
    231f:      	callq	*%rax
    2321:      	movq	0x20(%rsp), %rdx
    2326:      	movq	$0x0, 0x20(%rsp)
    232f:      	testq	%rdx, %rdx
    2332:      	je	0x23e8 <event_execve+0x23e8>
    2338:      	addq	$0x60, %rdx
    233c:      	leaq	0x20(%rsp), %rdi
    2341:      	movl	$0x8, %ecx
    2346:      	movl	$0x71, %eax
    234b:      	movl	$0x8, %esi
    2350:      	callq	*%rax
    2352:      	movq	0x20(%rsp), %rax
    2357:      	movq	%rax, (%r12)
    235b:      	testq	%rax, %rax
    235e:      	jne	0x2268 <event_execve+0x2268>
    2364:      	orl	$0x200000, %ebp         # imm = 0x200000
    236a:      	jmp	0x2372 <event_execve+0x2372>
    236c:      	xorl	%eax, %eax
    236e:      	movq	%rax, 0x18(%r13)
    2372:      	addq	$0x100, %rbx            # imm = 0x100
    2379:      	movq	%rsp, %rdi
    237c:      	movl	$0x8, %ecx
    2381:      	movl	$0x4, %eax
    2386:      	movl	$0x8, %esi
    238b:      	movq	%rbx, %rdx
    238e:      	callq	*%rax
    2390:      	movq	(%rsp), %rcx
    2394:      	addq	$0x10, %rcx
    2398:      	leaq	0x20(%rsp), %rdi
    239d:      	movl	$0x8, %edx
    23a2:      	movl	$0x4, %eax
    23a7:      	movq	(%rsp), %rdx
    23ab:      	addq	$0x10, %rdx
    23af:      	movl	$0x8, %esi
    23b4:      	callq	*%rax
    23b6:      	movl	$0x10000, %ecx          # imm = 0x10000
    23bb:      	testq	%rax, %rax
    23be:      	jne	0x23e4 <event_execve+0x23e4>
    23c0:      	movq	0x20(%rsp), %rdx
    23c5:      	testq	%rdx, %rdx
    23c8:      	je	0x23e4 <event_execve+0x23e4>
    23ca:      	movq	%r13, %rdi
    23cd:      	addq	$0x20, %rdi
    23d1:      	movl	$0x80, %ecx
    23d6:      	movl	$0x2d, %eax
    23db:      	movl	$0x80, %esi
    23e0:      	callq	*%rax
    23e2:      	xorl	%ecx, %ecx
    23e4:      	orl	%ebp, %ecx
    23e6:      	jmp	0x2411 <event_execve+0x2411>
    23e8:      	xorl	%eax, %eax
    23ea:      	movq	%rax, (%r12)
    23ee:      	testq	%rax, %rax
    23f1:      	jne	0x2268 <event_execve+0x2268>
    23f7:      	jmp	0x2364 <event_execve+0x2364>
    23fc:      	movq	0x10(%rsp), %rbx
    2401:      	movl	$0x80000, %ebp          # imm = 0x80000
    2406:      	testq	%rbx, %rbx
    2409:      	jne	0x22fb <event_execve+0x22fb>
    240f:      	xorl	%ecx, %ecx
    2411:      	orl	%ecx, 0x15c(%r13)
    2418:      	movq	$0x0, 0x130(%r13)
    2423:      	movq	$0x0, 0x138(%r13)
    242e:      	movq	(%rip), %rsi            # 0x2435 <event_execve+0x2435>
    2435:      	xorl	%ecx, %ecx
    2437:      	movl	$0xc, %eax
    243c:      	movq	%r14, %rdi
    243f:      	xorl	%edx, %edx
    2441:      	callq	*%rax
    2443:      	xorl	%eax, %eax
    2445:      	addq	$0xc8, %rsp
    244c:      	popq	%rbx
    244d:      	popq	%r12
    244f:      	popq	%r13
    2451:      	popq	%r14
    2453:      	popq	%r15
    2455:      	popq	%rbp
    2456:      	retq
