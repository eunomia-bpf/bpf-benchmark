
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_generic_uprobe_v61.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <read_reg>:
       0:      	rorxl	$0x3, %esi, %ecx
       6:      	xorl	%eax, %eax
       8:      	cmpl	$0x7, %ecx
       b:      	jle	0x42 <read_reg+0x42>
       d:      	cmpl	$0xb, %ecx
      10:      	jle	0x66 <read_reg+0x66>
      12:      	cmpl	$0xd, %ecx
      15:      	jle	0xcb <read_reg+0xcb>
      1b:      	cmpl	$0xe, %ecx
      1e:      	je	0xff <read_reg+0xff>
      24:      	cmpl	$0x10, %ecx
      27:      	je	0xe7 <read_reg+0xe7>
      2d:      	cmpl	$0x13, %ecx
      30:      	jne	0x115 <read_reg+0x115>
      36:      	addq	$0x98, %rdi
      3d:      	jmp	0x109 <read_reg+0x109>
      42:      	cmpl	$0x3, %ecx
      45:      	jg	0x82 <read_reg+0x82>
      47:      	cmpl	$0x1, %ecx
      4a:      	jg	0xab <read_reg+0xab>
      4c:      	testl	%ecx, %ecx
      4e:      	je	0x109 <read_reg+0x109>
      54:      	cmpl	$0x1, %ecx
      57:      	jne	0x115 <read_reg+0x115>
      5d:      	addq	$0x8, %rdi
      61:      	jmp	0x109 <read_reg+0x109>
      66:      	cmpl	$0x9, %ecx
      69:      	jg	0x9b <read_reg+0x9b>
      6b:      	cmpl	$0x8, %ecx
      6e:      	je	0xdb <read_reg+0xdb>
      70:      	cmpl	$0x9, %ecx
      73:      	jne	0x115 <read_reg+0x115>
      79:      	addq	$0x48, %rdi
      7d:      	jmp	0x109 <read_reg+0x109>
      82:      	cmpl	$0x5, %ecx
      85:      	jg	0xbb <read_reg+0xbb>
      87:      	cmpl	$0x4, %ecx
      8a:      	je	0xed <read_reg+0xed>
      8c:      	cmpl	$0x5, %ecx
      8f:      	jne	0x115 <read_reg+0x115>
      95:      	addq	$0x28, %rdi
      99:      	jmp	0x109 <read_reg+0x109>
      9b:      	cmpl	$0xa, %ecx
      9e:      	je	0xe1 <read_reg+0xe1>
      a0:      	cmpl	$0xb, %ecx
      a3:      	jne	0x115 <read_reg+0x115>
      a5:      	addq	$0x58, %rdi
      a9:      	jmp	0x109 <read_reg+0x109>
      ab:      	cmpl	$0x2, %ecx
      ae:      	je	0xf3 <read_reg+0xf3>
      b0:      	cmpl	$0x3, %ecx
      b3:      	jne	0x115 <read_reg+0x115>
      b5:      	addq	$0x18, %rdi
      b9:      	jmp	0x109 <read_reg+0x109>
      bb:      	cmpl	$0x6, %ecx
      be:      	je	0xf9 <read_reg+0xf9>
      c0:      	cmpl	$0x7, %ecx
      c3:      	jne	0x115 <read_reg+0x115>
      c5:      	addq	$0x38, %rdi
      c9:      	jmp	0x109 <read_reg+0x109>
      cb:      	cmpl	$0xc, %ecx
      ce:      	je	0x105 <read_reg+0x105>
      d0:      	cmpl	$0xd, %ecx
      d3:      	jne	0x115 <read_reg+0x115>
      d5:      	addq	$0x68, %rdi
      d9:      	jmp	0x109 <read_reg+0x109>
      db:      	addq	$0x40, %rdi
      df:      	jmp	0x109 <read_reg+0x109>
      e1:      	addq	$0x50, %rdi
      e5:      	jmp	0x109 <read_reg+0x109>
      e7:      	subq	$-0x80, %rdi
      eb:      	jmp	0x109 <read_reg+0x109>
      ed:      	addq	$0x20, %rdi
      f1:      	jmp	0x109 <read_reg+0x109>
      f3:      	addq	$0x10, %rdi
      f7:      	jmp	0x109 <read_reg+0x109>
      f9:      	addq	$0x30, %rdi
      fd:      	jmp	0x109 <read_reg+0x109>
      ff:      	addq	$0x70, %rdi
     103:      	jmp	0x109 <read_reg+0x109>
     105:      	addq	$0x60, %rdi
     109:      	movl	$0x40, %eax
     10e:      	subl	%edx, %eax
     110:      	bzhiq	%rax, (%rdi), %rax
     115:      	retq
     116:      	nopw	%cs:(%rax,%rax)

0000000000000120 <extract_arg_depth>:
     120:      	movl	$0x1, %eax
     125:      	cmpl	$0x9, %edi
     128:      	ja	0x1a2 <extract_arg_depth+0x82>
     12a:      	pushq	%r14
     12c:      	pushq	%rbx
     12d:      	pushq	%rax
     12e:      	movq	(%rsi), %r8
     131:      	movl	%edi, %r9d
     134:      	cmpw	$0x0, 0x6(%r8,%r9,8)
     13b:      	je	0x19b <extract_arg_depth+0x7b>
     13d:      	movq	0x8(%rsi), %rcx
     141:      	movl	(%r8,%r9,8), %edx
     145:      	addq	(%rcx), %rdx
     148:      	movq	%rdx, (%rcx)
     14b:      	xorl	%eax, %eax
     14d:      	cmpw	$0x0, 0x4(%r8,%r9,8)
     154:      	je	0x19b <extract_arg_depth+0x7b>
     156:      	movl	%edi, %ebx
     158:      	cmpb	$0x0, 0x10(%rsi)
     15c:      	je	0x16a <extract_arg_depth+0x4a>
     15e:      	movl	$0x8, %edi
     163:      	movl	$0x94, %eax
     168:      	jmp	0x174 <extract_arg_depth+0x54>
     16a:      	movl	$0x8, %edi
     16f:      	movl	$0x4, %eax
     174:      	movq	%rsi, %r14
     177:      	movq	0x8(%rsi), %rdi
     17b:      	movq	(%rdi), %rdx
     17e:      	movl	$0x8, %esi
     183:      	callq	*%rax
     185:      	testl	%eax, %eax
     187:      	movl	$0x0, %eax
     18c:      	jns	0x19b <extract_arg_depth+0x7b>
     18e:      	incl	%ebx
     190:      	movq	0x18(%r14), %rax
     194:      	movl	%ebx, (%rax)
     196:      	movl	$0x1, %eax
     19b:      	addq	$0x8, %rsp
     19f:      	popq	%rbx
     1a0:      	popq	%r14
     1a2:      	retq
     1a3:      	nopw	%cs:(%rax,%rax)

00000000000001b0 <filter_64ty>:
     1b0:      	pushq	%rax
     1b1:      	movl	0x4(%rdi), %ecx
     1b4:      	xorl	%eax, %eax
     1b6:      	cmpq	$0x20, %rcx
     1ba:      	ja	0x1f5 <filter_64ty+0x45>
     1bc:      	movl	$0x101e, %edx           # imm = 0x101E
     1c1:      	btq	%rcx, %rdx
     1c5:      	jae	0x1ce <filter_64ty+0x1e>
     1c7:      	callq	0x2f0 <filter_64ty_selector_val>
     1cc:      	popq	%rcx
     1cd:      	retq
     1ce:      	movl	$0xc00, %edx            # imm = 0xC00
     1d3:      	btq	%rcx, %rdx
     1d7:      	jb	0x1f0 <filter_64ty+0x40>
     1d9:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     1e3:      	btq	%rcx, %rdx
     1e7:      	jae	0x1f5 <filter_64ty+0x45>
     1e9:      	callq	0x5b0 <filter_64ty_range>
     1ee:      	popq	%rcx
     1ef:      	retq
     1f0:      	callq	0x530 <filter_64ty_map>
     1f5:      	popq	%rcx
     1f6:      	retq
     1f7:      	nopw	(%rax,%rax)

0000000000000200 <filter_32ty>:
     200:      	pushq	%rax
     201:      	movl	0x4(%rdi), %ecx
     204:      	xorl	%eax, %eax
     206:      	cmpq	$0x20, %rcx
     20a:      	ja	0x245 <filter_32ty+0x45>
     20c:      	movl	$0x101e, %edx           # imm = 0x101E
     211:      	btq	%rcx, %rdx
     215:      	jae	0x21e <filter_32ty+0x1e>
     217:      	callq	0x790 <filter_32ty_selector_val>
     21c:      	popq	%rcx
     21d:      	retq
     21e:      	movl	$0xc00, %edx            # imm = 0xC00
     223:      	btq	%rcx, %rdx
     227:      	jb	0x240 <filter_32ty+0x40>
     229:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     233:      	btq	%rcx, %rdx
     237:      	jae	0x245 <filter_32ty+0x45>
     239:      	callq	0xa40 <filter_32ty_range>
     23e:      	popq	%rcx
     23f:      	retq
     240:      	callq	0x9b0 <filter_32ty_map>
     245:      	popq	%rcx
     246:      	retq
     247:      	nopw	(%rax,%rax)

0000000000000250 <filter_16ty>:
     250:      	pushq	%rax
     251:      	movl	0x4(%rdi), %ecx
     254:      	xorl	%eax, %eax
     256:      	cmpq	$0x20, %rcx
     25a:      	ja	0x295 <filter_16ty+0x45>
     25c:      	movl	$0x101e, %edx           # imm = 0x101E
     261:      	btq	%rcx, %rdx
     265:      	jae	0x26e <filter_16ty+0x1e>
     267:      	callq	0xc00 <filter_16ty_selector_val>
     26c:      	popq	%rcx
     26d:      	retq
     26e:      	movl	$0xc00, %edx            # imm = 0xC00
     273:      	btq	%rcx, %rdx
     277:      	jb	0x290 <filter_16ty+0x40>
     279:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     283:      	btq	%rcx, %rdx
     287:      	jae	0x295 <filter_16ty+0x45>
     289:      	callq	0xeb0 <filter_16ty_range>
     28e:      	popq	%rcx
     28f:      	retq
     290:      	callq	0xe20 <filter_16ty_map>
     295:      	popq	%rcx
     296:      	retq
     297:      	nopw	(%rax,%rax)

00000000000002a0 <filter_8ty>:
     2a0:      	pushq	%rax
     2a1:      	movl	0x4(%rdi), %ecx
     2a4:      	xorl	%eax, %eax
     2a6:      	cmpq	$0x20, %rcx
     2aa:      	ja	0x2e5 <filter_8ty+0x45>
     2ac:      	movl	$0x101e, %edx           # imm = 0x101E
     2b1:      	btq	%rcx, %rdx
     2b5:      	jae	0x2be <filter_8ty+0x1e>
     2b7:      	callq	0x1070 <filter_8ty_selector_val>
     2bc:      	popq	%rcx
     2bd:      	retq
     2be:      	movl	$0xc00, %edx            # imm = 0xC00
     2c3:      	btq	%rcx, %rdx
     2c7:      	jb	0x2e0 <filter_8ty+0x40>
     2c9:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     2d3:      	btq	%rcx, %rdx
     2d7:      	jae	0x2e5 <filter_8ty+0x45>
     2d9:      	callq	0x1320 <filter_8ty_range>
     2de:      	popq	%rcx
     2df:      	retq
     2e0:      	callq	0x1290 <filter_8ty_map>
     2e5:      	popq	%rcx
     2e6:      	retq
     2e7:      	nopw	(%rax,%rax)

00000000000002f0 <filter_64ty_selector_val>:
     2f0:      	movl	0x4(%rdi), %ecx
     2f3:      	movl	$0x1, %eax
     2f8:      	cmpq	$0x25, %rcx
     2fc:      	ja	0x374 <filter_64ty_selector_val+0x84>
     2fe:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     308:      	btq	%rcx, %rdx
     30c:      	jae	0x30f <filter_64ty_selector_val+0x1f>
     30e:      	retq
     30f:      	movl	$0x18, %edx
     314:      	btq	%rcx, %rdx
     318:      	jae	0x330 <filter_64ty_selector_val+0x40>
     31a:      	movq	(%rsi), %rdx
     31d:      	cmpq	0x10(%rdi), %rdx
     321:      	jne	0x452 <filter_64ty_selector_val+0x162>
     327:      	xorl	%eax, %eax
     329:      	cmpl	$0x3, %ecx
     32c:      	sete	%al
     32f:      	retq
     330:      	cmpq	$0xc, %rcx
     334:      	jne	0x374 <filter_64ty_selector_val+0x84>
     336:      	movq	(%rsi), %rcx
     339:      	testq	%rcx, 0x10(%rdi)
     33d:      	jne	0x30e <filter_64ty_selector_val+0x1e>
     33f:      	movl	0x8(%rdi), %edx
     342:      	cmpl	$0x11, %edx
     345:      	jb	0x51f <filter_64ty_selector_val+0x22f>
     34b:      	testq	%rcx, 0x18(%rdi)
     34f:      	jne	0x30e <filter_64ty_selector_val+0x1e>
     351:      	cmpl	$0x19, %edx
     354:      	jb	0x51f <filter_64ty_selector_val+0x22f>
     35a:      	testq	%rcx, 0x20(%rdi)
     35e:      	jne	0x30e <filter_64ty_selector_val+0x1e>
     360:      	cmpl	$0x21, %edx
     363:      	jb	0x51f <filter_64ty_selector_val+0x22f>
     369:      	testq	%rcx, 0x28(%rdi)
     36d:      	jne	0x30e <filter_64ty_selector_val+0x1e>
     36f:      	jmp	0x51f <filter_64ty_selector_val+0x22f>
     374:      	cmpl	$0x1, %ecx
     377:      	je	0x3ea <filter_64ty_selector_val+0xfa>
     379:      	cmpl	$0x2, %ecx
     37c:      	jne	0x51f <filter_64ty_selector_val+0x22f>
     382:      	movl	0xc(%rdi), %ecx
     385:      	cmpl	$0xc, %ecx
     388:      	ja	0x4e2 <filter_64ty_selector_val+0x1f2>
     38e:      	movl	$0x1402, %edx           # imm = 0x1402
     393:      	btl	%ecx, %edx
     396:      	jae	0x4e2 <filter_64ty_selector_val+0x1f2>
     39c:      	movq	(%rsi), %rcx
     39f:      	cmpq	0x10(%rdi), %rcx
     3a3:      	jl	0x30e <filter_64ty_selector_val+0x1e>
     3a9:      	movl	0x8(%rdi), %edx
     3ac:      	cmpl	$0x11, %edx
     3af:      	jb	0x51f <filter_64ty_selector_val+0x22f>
     3b5:      	cmpq	0x18(%rdi), %rcx
     3b9:      	jl	0x30e <filter_64ty_selector_val+0x1e>
     3bf:      	cmpl	$0x19, %edx
     3c2:      	jb	0x51f <filter_64ty_selector_val+0x22f>
     3c8:      	cmpq	0x20(%rdi), %rcx
     3cc:      	jl	0x30e <filter_64ty_selector_val+0x1e>
     3d2:      	cmpl	$0x21, %edx
     3d5:      	jb	0x51f <filter_64ty_selector_val+0x22f>
     3db:      	cmpq	0x28(%rdi), %rcx
     3df:      	jl	0x30e <filter_64ty_selector_val+0x1e>
     3e5:      	jmp	0x51f <filter_64ty_selector_val+0x22f>
     3ea:      	movl	0xc(%rdi), %ecx
     3ed:      	cmpl	$0xc, %ecx
     3f0:      	ja	0x4a3 <filter_64ty_selector_val+0x1b3>
     3f6:      	movl	$0x1402, %edx           # imm = 0x1402
     3fb:      	btl	%ecx, %edx
     3fe:      	jae	0x4a3 <filter_64ty_selector_val+0x1b3>
     404:      	movq	(%rsi), %rcx
     407:      	cmpq	0x10(%rdi), %rcx
     40b:      	jg	0x30e <filter_64ty_selector_val+0x1e>
     411:      	movl	0x8(%rdi), %edx
     414:      	cmpl	$0x11, %edx
     417:      	jb	0x51f <filter_64ty_selector_val+0x22f>
     41d:      	cmpq	0x18(%rdi), %rcx
     421:      	jg	0x30e <filter_64ty_selector_val+0x1e>
     427:      	cmpl	$0x19, %edx
     42a:      	jb	0x51f <filter_64ty_selector_val+0x22f>
     430:      	cmpq	0x20(%rdi), %rcx
     434:      	jg	0x30e <filter_64ty_selector_val+0x1e>
     43a:      	cmpl	$0x21, %edx
     43d:      	jb	0x51f <filter_64ty_selector_val+0x22f>
     443:      	cmpq	0x28(%rdi), %rcx
     447:      	jg	0x30e <filter_64ty_selector_val+0x1e>
     44d:      	jmp	0x51f <filter_64ty_selector_val+0x22f>
     452:      	movl	0x8(%rdi), %esi
     455:      	cmpl	$0x11, %esi
     458:      	jb	0x482 <filter_64ty_selector_val+0x192>
     45a:      	cmpq	0x18(%rdi), %rdx
     45e:      	je	0x327 <filter_64ty_selector_val+0x37>
     464:      	cmpl	$0x19, %esi
     467:      	jb	0x482 <filter_64ty_selector_val+0x192>
     469:      	cmpq	0x20(%rdi), %rdx
     46d:      	je	0x327 <filter_64ty_selector_val+0x37>
     473:      	cmpl	$0x21, %esi
     476:      	jb	0x482 <filter_64ty_selector_val+0x192>
     478:      	cmpq	0x28(%rdi), %rdx
     47c:      	je	0x327 <filter_64ty_selector_val+0x37>
     482:      	cmpl	$0x25, %ecx
     485:      	ja	0x51f <filter_64ty_selector_val+0x22f>
     48b:      	movl	%ecx, %ecx
     48d:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     497:      	btq	%rcx, %rdx
     49b:      	jb	0x30e <filter_64ty_selector_val+0x1e>
     4a1:      	jmp	0x51f <filter_64ty_selector_val+0x22f>
     4a3:      	movq	(%rsi), %rcx
     4a6:      	cmpq	0x10(%rdi), %rcx
     4aa:      	ja	0x30e <filter_64ty_selector_val+0x1e>
     4b0:      	movl	0x8(%rdi), %edx
     4b3:      	cmpl	$0x11, %edx
     4b6:      	jb	0x51f <filter_64ty_selector_val+0x22f>
     4b8:      	cmpq	0x18(%rdi), %rcx
     4bc:      	ja	0x30e <filter_64ty_selector_val+0x1e>
     4c2:      	cmpl	$0x19, %edx
     4c5:      	jb	0x51f <filter_64ty_selector_val+0x22f>
     4c7:      	cmpq	0x20(%rdi), %rcx
     4cb:      	ja	0x30e <filter_64ty_selector_val+0x1e>
     4d1:      	cmpl	$0x21, %edx
     4d4:      	jb	0x51f <filter_64ty_selector_val+0x22f>
     4d6:      	cmpq	0x28(%rdi), %rcx
     4da:      	ja	0x30e <filter_64ty_selector_val+0x1e>
     4e0:      	jmp	0x51f <filter_64ty_selector_val+0x22f>
     4e2:      	movq	(%rsi), %rcx
     4e5:      	cmpq	0x10(%rdi), %rcx
     4e9:      	jb	0x30e <filter_64ty_selector_val+0x1e>
     4ef:      	movl	0x8(%rdi), %edx
     4f2:      	cmpl	$0x11, %edx
     4f5:      	jb	0x51f <filter_64ty_selector_val+0x22f>
     4f7:      	cmpq	0x18(%rdi), %rcx
     4fb:      	jb	0x30e <filter_64ty_selector_val+0x1e>
     501:      	cmpl	$0x19, %edx
     504:      	jb	0x51f <filter_64ty_selector_val+0x22f>
     506:      	cmpq	0x20(%rdi), %rcx
     50a:      	jb	0x30e <filter_64ty_selector_val+0x1e>
     510:      	cmpl	$0x21, %edx
     513:      	jb	0x51f <filter_64ty_selector_val+0x22f>
     515:      	cmpq	0x28(%rdi), %rcx
     519:      	jb	0x30e <filter_64ty_selector_val+0x1e>
     51f:      	xorl	%eax, %eax
     521:      	retq
     522:      	nopw	%cs:(%rax,%rax)

0000000000000530 <filter_64ty_map>:
     530:      	pushq	%r14
     532:      	pushq	%rbx
     533:      	subq	$0x18, %rsp
     537:      	movq	%rsi, %r14
     53a:      	movq	%rdi, %rbx
     53d:      	movzbl	0x10(%rdi), %eax
     541:      	movl	%eax, 0xc(%rsp)
     545:      	movq	(%rip), %rdi            # 0x54c <filter_64ty_map+0x1c>
     54c:      	leaq	0xc(%rsp), %rsi
     551:      	movl	$0x1, %eax
     556:      	callq	*%rax
     558:      	testq	%rax, %rax
     55b:      	je	0x589 <filter_64ty_map+0x59>
     55d:      	movq	%rax, %rdi
     560:      	movq	(%r14), %rax
     563:      	movq	%rax, 0x10(%rsp)
     568:      	leaq	0x10(%rsp), %rsi
     56d:      	movl	$0x1, %eax
     572:      	callq	*%rax
     574:      	movl	0x4(%rbx), %ecx
     577:      	cmpl	$0xb, %ecx
     57a:      	je	0x593 <filter_64ty_map+0x63>
     57c:      	cmpl	$0xa, %ecx
     57f:      	jne	0x59b <filter_64ty_map+0x6b>
     581:      	testq	%rax, %rax
     584:      	setne	%al
     587:      	jmp	0x59d <filter_64ty_map+0x6d>
     589:      	xorl	%eax, %eax
     58b:      	addq	$0x18, %rsp
     58f:      	popq	%rbx
     590:      	popq	%r14
     592:      	retq
     593:      	testq	%rax, %rax
     596:      	sete	%al
     599:      	jmp	0x59d <filter_64ty_map+0x6d>
     59b:      	xorl	%eax, %eax
     59d:      	movzbl	%al, %eax
     5a0:      	addq	$0x18, %rsp
     5a4:      	popq	%rbx
     5a5:      	popq	%r14
     5a7:      	retq
     5a8:      	nopl	(%rax,%rax)

00000000000005b0 <filter_64ty_range>:
     5b0:      	movl	0x4(%rdi), %ecx
     5b3:      	movl	0xc(%rdi), %eax
     5b6:      	cmpl	$0xc, %eax
     5b9:      	ja	0x6b0 <filter_64ty_range+0x100>
     5bf:      	movl	$0x1402, %edx           # imm = 0x1402
     5c4:      	btl	%eax, %edx
     5c7:      	jae	0x6b0 <filter_64ty_range+0x100>
     5cd:      	movq	(%rsi), %rsi
     5d0:      	cmpl	$0x1f, %ecx
     5d3:      	jne	0x643 <filter_64ty_range+0x93>
     5d5:      	movl	$0x1, %eax
     5da:      	cmpq	%rsi, 0x10(%rdi)
     5de:      	jg	0x5ea <filter_64ty_range+0x3a>
     5e0:      	cmpq	0x18(%rdi), %rsi
     5e4:      	jle	0x6c9 <filter_64ty_range+0x119>
     5ea:      	movl	0x8(%rdi), %edx
     5ed:      	cmpl	$0x19, %edx
     5f0:      	jb	0x777 <filter_64ty_range+0x1c7>
     5f6:      	cmpq	%rsi, 0x20(%rdi)
     5fa:      	jg	0x606 <filter_64ty_range+0x56>
     5fc:      	cmpq	0x28(%rdi), %rsi
     600:      	jle	0x6c9 <filter_64ty_range+0x119>
     606:      	cmpl	$0x29, %edx
     609:      	jb	0x777 <filter_64ty_range+0x1c7>
     60f:      	cmpq	%rsi, 0x30(%rdi)
     613:      	jg	0x61f <filter_64ty_range+0x6f>
     615:      	cmpq	0x38(%rdi), %rsi
     619:      	jle	0x6c9 <filter_64ty_range+0x119>
     61f:      	cmpl	$0x39, %edx
     622:      	jb	0x777 <filter_64ty_range+0x1c7>
     628:      	xorl	%edx, %edx
     62a:      	cmpq	%rsi, 0x40(%rdi)
     62e:      	jg	0x779 <filter_64ty_range+0x1c9>
     634:      	cmpq	0x48(%rdi), %rsi
     638:      	jle	0x6c9 <filter_64ty_range+0x119>
     63e:      	jmp	0x779 <filter_64ty_range+0x1c9>
     643:      	movl	0x8(%rdi), %eax
     646:      	cmpq	%rsi, 0x10(%rdi)
     64a:      	setle	%r8b
     64e:      	cmpq	0x18(%rdi), %rsi
     652:      	setle	%dl
     655:      	andb	%r8b, %dl
     658:      	cmpl	$0x19, %eax
     65b:      	jb	0x779 <filter_64ty_range+0x1c9>
     661:      	cmpq	%rsi, 0x20(%rdi)
     665:      	setle	%r8b
     669:      	cmpq	0x28(%rdi), %rsi
     66d:      	setle	%r9b
     671:      	andb	%r8b, %r9b
     674:      	orb	%r9b, %dl
     677:      	cmpl	$0x29, %eax
     67a:      	jb	0x779 <filter_64ty_range+0x1c9>
     680:      	cmpq	%rsi, 0x30(%rdi)
     684:      	setle	%r8b
     688:      	cmpq	0x38(%rdi), %rsi
     68c:      	setle	%r9b
     690:      	andb	%r8b, %r9b
     693:      	orb	%r9b, %dl
     696:      	cmpl	$0x39, %eax
     699:      	jb	0x779 <filter_64ty_range+0x1c9>
     69f:      	cmpq	%rsi, 0x40(%rdi)
     6a3:      	setle	%al
     6a6:      	cmpq	0x48(%rdi), %rsi
     6aa:      	setle	%sil
     6ae:      	jmp	0x72d <filter_64ty_range+0x17d>
     6b0:      	movq	(%rsi), %rsi
     6b3:      	cmpl	$0x1f, %ecx
     6b6:      	jne	0x6ca <filter_64ty_range+0x11a>
     6b8:      	movl	$0x1, %eax
     6bd:      	cmpq	%rsi, 0x10(%rdi)
     6c1:      	ja	0x735 <filter_64ty_range+0x185>
     6c3:      	cmpq	0x18(%rdi), %rsi
     6c7:      	ja	0x735 <filter_64ty_range+0x185>
     6c9:      	retq
     6ca:      	movl	0x8(%rdi), %eax
     6cd:      	cmpq	%rsi, 0x10(%rdi)
     6d1:      	setbe	%r8b
     6d5:      	cmpq	0x18(%rdi), %rsi
     6d9:      	setbe	%dl
     6dc:      	andb	%r8b, %dl
     6df:      	cmpl	$0x19, %eax
     6e2:      	jb	0x779 <filter_64ty_range+0x1c9>
     6e8:      	cmpq	%rsi, 0x20(%rdi)
     6ec:      	setbe	%r8b
     6f0:      	cmpq	0x28(%rdi), %rsi
     6f4:      	setbe	%r9b
     6f8:      	andb	%r8b, %r9b
     6fb:      	orb	%r9b, %dl
     6fe:      	cmpl	$0x29, %eax
     701:      	jb	0x779 <filter_64ty_range+0x1c9>
     703:      	cmpq	%rsi, 0x30(%rdi)
     707:      	setbe	%r8b
     70b:      	cmpq	0x38(%rdi), %rsi
     70f:      	setbe	%r9b
     713:      	andb	%r8b, %r9b
     716:      	orb	%r9b, %dl
     719:      	cmpl	$0x39, %eax
     71c:      	jb	0x779 <filter_64ty_range+0x1c9>
     71e:      	cmpq	%rsi, 0x40(%rdi)
     722:      	setbe	%al
     725:      	cmpq	0x48(%rdi), %rsi
     729:      	setbe	%sil
     72d:      	andb	%al, %sil
     730:      	orb	%sil, %dl
     733:      	jmp	0x779 <filter_64ty_range+0x1c9>
     735:      	movl	0x8(%rdi), %edx
     738:      	cmpl	$0x19, %edx
     73b:      	jb	0x777 <filter_64ty_range+0x1c7>
     73d:      	cmpq	%rsi, 0x20(%rdi)
     741:      	ja	0x749 <filter_64ty_range+0x199>
     743:      	cmpq	0x28(%rdi), %rsi
     747:      	jbe	0x6c9 <filter_64ty_range+0x119>
     749:      	cmpl	$0x29, %edx
     74c:      	jb	0x777 <filter_64ty_range+0x1c7>
     74e:      	cmpq	%rsi, 0x30(%rdi)
     752:      	ja	0x75e <filter_64ty_range+0x1ae>
     754:      	cmpq	0x38(%rdi), %rsi
     758:      	jbe	0x6c9 <filter_64ty_range+0x119>
     75e:      	cmpl	$0x39, %edx
     761:      	jb	0x777 <filter_64ty_range+0x1c7>
     763:      	xorl	%edx, %edx
     765:      	cmpq	%rsi, 0x40(%rdi)
     769:      	ja	0x779 <filter_64ty_range+0x1c9>
     76b:      	cmpq	0x48(%rdi), %rsi
     76f:      	jbe	0x6c9 <filter_64ty_range+0x119>
     775:      	jmp	0x779 <filter_64ty_range+0x1c9>
     777:      	xorl	%edx, %edx
     779:      	cmpl	$0x20, %ecx
     77c:      	sete	%al
     77f:      	xorb	$0x1, %dl
     782:      	andb	%al, %dl
     784:      	movzbl	%dl, %eax
     787:      	retq
     788:      	nopl	(%rax,%rax)

0000000000000790 <filter_32ty_selector_val>:
     790:      	movl	0x4(%rdi), %ecx
     793:      	movl	$0x1, %eax
     798:      	cmpq	$0x25, %rcx
     79c:      	ja	0x80d <filter_32ty_selector_val+0x7d>
     79e:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     7a8:      	btq	%rcx, %rdx
     7ac:      	jae	0x7af <filter_32ty_selector_val+0x1f>
     7ae:      	retq
     7af:      	movl	$0x18, %edx
     7b4:      	btq	%rcx, %rdx
     7b8:      	jae	0x7ce <filter_32ty_selector_val+0x3e>
     7ba:      	movl	(%rsi), %edx
     7bc:      	cmpl	0x10(%rdi), %edx
     7bf:      	jne	0x8e1 <filter_32ty_selector_val+0x151>
     7c5:      	xorl	%eax, %eax
     7c7:      	cmpl	$0x3, %ecx
     7ca:      	sete	%al
     7cd:      	retq
     7ce:      	cmpq	$0xc, %rcx
     7d2:      	jne	0x80d <filter_32ty_selector_val+0x7d>
     7d4:      	movl	(%rsi), %ecx
     7d6:      	testl	%ecx, 0x10(%rdi)
     7d9:      	jne	0x7ae <filter_32ty_selector_val+0x1e>
     7db:      	movl	0x8(%rdi), %edx
     7de:      	cmpl	$0xd, %edx
     7e1:      	jb	0x9a1 <filter_32ty_selector_val+0x211>
     7e7:      	testl	%ecx, 0x14(%rdi)
     7ea:      	jne	0x7ae <filter_32ty_selector_val+0x1e>
     7ec:      	cmpl	$0x11, %edx
     7ef:      	jb	0x9a1 <filter_32ty_selector_val+0x211>
     7f5:      	testl	%ecx, 0x18(%rdi)
     7f8:      	jne	0x7ae <filter_32ty_selector_val+0x1e>
     7fa:      	cmpl	$0x15, %edx
     7fd:      	jb	0x9a1 <filter_32ty_selector_val+0x211>
     803:      	testl	%ecx, 0x1c(%rdi)
     806:      	jne	0x7ae <filter_32ty_selector_val+0x1e>
     808:      	jmp	0x9a1 <filter_32ty_selector_val+0x211>
     80d:      	cmpl	$0x1, %ecx
     810:      	je	0x87e <filter_32ty_selector_val+0xee>
     812:      	cmpl	$0x2, %ecx
     815:      	jne	0x9a1 <filter_32ty_selector_val+0x211>
     81b:      	movl	0xc(%rdi), %ecx
     81e:      	cmpl	$0xc, %ecx
     821:      	ja	0x969 <filter_32ty_selector_val+0x1d9>
     827:      	movl	$0x1402, %edx           # imm = 0x1402
     82c:      	btl	%ecx, %edx
     82f:      	jae	0x969 <filter_32ty_selector_val+0x1d9>
     835:      	movl	(%rsi), %ecx
     837:      	cmpl	0x10(%rdi), %ecx
     83a:      	jl	0x7ae <filter_32ty_selector_val+0x1e>
     840:      	movl	0x8(%rdi), %edx
     843:      	cmpl	$0xd, %edx
     846:      	jb	0x9a1 <filter_32ty_selector_val+0x211>
     84c:      	cmpl	0x14(%rdi), %ecx
     84f:      	jl	0x7ae <filter_32ty_selector_val+0x1e>
     855:      	cmpl	$0x11, %edx
     858:      	jb	0x9a1 <filter_32ty_selector_val+0x211>
     85e:      	cmpl	0x18(%rdi), %ecx
     861:      	jl	0x7ae <filter_32ty_selector_val+0x1e>
     867:      	cmpl	$0x15, %edx
     86a:      	jb	0x9a1 <filter_32ty_selector_val+0x211>
     870:      	cmpl	0x1c(%rdi), %ecx
     873:      	jl	0x7ae <filter_32ty_selector_val+0x1e>
     879:      	jmp	0x9a1 <filter_32ty_selector_val+0x211>
     87e:      	movl	0xc(%rdi), %ecx
     881:      	cmpl	$0xc, %ecx
     884:      	ja	0x92f <filter_32ty_selector_val+0x19f>
     88a:      	movl	$0x1402, %edx           # imm = 0x1402
     88f:      	btl	%ecx, %edx
     892:      	jae	0x92f <filter_32ty_selector_val+0x19f>
     898:      	movl	(%rsi), %ecx
     89a:      	cmpl	0x10(%rdi), %ecx
     89d:      	jg	0x7ae <filter_32ty_selector_val+0x1e>
     8a3:      	movl	0x8(%rdi), %edx
     8a6:      	cmpl	$0xd, %edx
     8a9:      	jb	0x9a1 <filter_32ty_selector_val+0x211>
     8af:      	cmpl	0x14(%rdi), %ecx
     8b2:      	jg	0x7ae <filter_32ty_selector_val+0x1e>
     8b8:      	cmpl	$0x11, %edx
     8bb:      	jb	0x9a1 <filter_32ty_selector_val+0x211>
     8c1:      	cmpl	0x18(%rdi), %ecx
     8c4:      	jg	0x7ae <filter_32ty_selector_val+0x1e>
     8ca:      	cmpl	$0x15, %edx
     8cd:      	jb	0x9a1 <filter_32ty_selector_val+0x211>
     8d3:      	cmpl	0x1c(%rdi), %ecx
     8d6:      	jg	0x7ae <filter_32ty_selector_val+0x1e>
     8dc:      	jmp	0x9a1 <filter_32ty_selector_val+0x211>
     8e1:      	movl	0x8(%rdi), %esi
     8e4:      	cmpl	$0xd, %esi
     8e7:      	jb	0x90e <filter_32ty_selector_val+0x17e>
     8e9:      	cmpl	0x14(%rdi), %edx
     8ec:      	je	0x7c5 <filter_32ty_selector_val+0x35>
     8f2:      	cmpl	$0x11, %esi
     8f5:      	jb	0x90e <filter_32ty_selector_val+0x17e>
     8f7:      	cmpl	0x18(%rdi), %edx
     8fa:      	je	0x7c5 <filter_32ty_selector_val+0x35>
     900:      	cmpl	$0x15, %esi
     903:      	jb	0x90e <filter_32ty_selector_val+0x17e>
     905:      	cmpl	0x1c(%rdi), %edx
     908:      	je	0x7c5 <filter_32ty_selector_val+0x35>
     90e:      	cmpl	$0x25, %ecx
     911:      	ja	0x9a1 <filter_32ty_selector_val+0x211>
     917:      	movl	%ecx, %ecx
     919:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     923:      	btq	%rcx, %rdx
     927:      	jb	0x7ae <filter_32ty_selector_val+0x1e>
     92d:      	jmp	0x9a1 <filter_32ty_selector_val+0x211>
     92f:      	movl	(%rsi), %ecx
     931:      	cmpl	0x10(%rdi), %ecx
     934:      	ja	0x7ae <filter_32ty_selector_val+0x1e>
     93a:      	movl	0x8(%rdi), %edx
     93d:      	cmpl	$0xd, %edx
     940:      	jb	0x9a1 <filter_32ty_selector_val+0x211>
     942:      	cmpl	0x14(%rdi), %ecx
     945:      	ja	0x7ae <filter_32ty_selector_val+0x1e>
     94b:      	cmpl	$0x11, %edx
     94e:      	jb	0x9a1 <filter_32ty_selector_val+0x211>
     950:      	cmpl	0x18(%rdi), %ecx
     953:      	ja	0x7ae <filter_32ty_selector_val+0x1e>
     959:      	cmpl	$0x15, %edx
     95c:      	jb	0x9a1 <filter_32ty_selector_val+0x211>
     95e:      	cmpl	0x1c(%rdi), %ecx
     961:      	ja	0x7ae <filter_32ty_selector_val+0x1e>
     967:      	jmp	0x9a1 <filter_32ty_selector_val+0x211>
     969:      	movl	(%rsi), %ecx
     96b:      	cmpl	0x10(%rdi), %ecx
     96e:      	jb	0x7ae <filter_32ty_selector_val+0x1e>
     974:      	movl	0x8(%rdi), %edx
     977:      	cmpl	$0xd, %edx
     97a:      	jb	0x9a1 <filter_32ty_selector_val+0x211>
     97c:      	cmpl	0x14(%rdi), %ecx
     97f:      	jb	0x7ae <filter_32ty_selector_val+0x1e>
     985:      	cmpl	$0x11, %edx
     988:      	jb	0x9a1 <filter_32ty_selector_val+0x211>
     98a:      	cmpl	0x18(%rdi), %ecx
     98d:      	jb	0x7ae <filter_32ty_selector_val+0x1e>
     993:      	cmpl	$0x15, %edx
     996:      	jb	0x9a1 <filter_32ty_selector_val+0x211>
     998:      	cmpl	0x1c(%rdi), %ecx
     99b:      	jb	0x7ae <filter_32ty_selector_val+0x1e>
     9a1:      	xorl	%eax, %eax
     9a3:      	retq
     9a4:      	nopw	%cs:(%rax,%rax)

00000000000009b0 <filter_32ty_map>:
     9b0:      	pushq	%r14
     9b2:      	pushq	%rbx
     9b3:      	subq	$0x18, %rsp
     9b7:      	movq	%rsi, %r14
     9ba:      	movq	%rdi, %rbx
     9bd:      	movzbl	0x10(%rdi), %eax
     9c1:      	movl	%eax, 0xc(%rsp)
     9c5:      	movq	(%rip), %rdi            # 0x9cc <filter_32ty_map+0x1c>
     9cc:      	leaq	0xc(%rsp), %rsi
     9d1:      	movl	$0x1, %eax
     9d6:      	callq	*%rax
     9d8:      	testq	%rax, %rax
     9db:      	je	0xa10 <filter_32ty_map+0x60>
     9dd:      	movq	%rax, %rdi
     9e0:      	movl	(%r14), %eax
     9e3:      	movq	%rax, 0x10(%rsp)
     9e8:      	leaq	0x10(%rsp), %rsi
     9ed:      	movl	$0x1, %eax
     9f2:      	callq	*%rax
     9f4:      	movl	0x4(%rbx), %edx
     9f7:      	xorl	%ecx, %ecx
     9f9:      	cmpl	$0x1d, %edx
     9fc:      	ja	0xa2a <filter_32ty_map+0x7a>
     9fe:      	movl	$0x30038400, %esi       # imm = 0x30038400
     a03:      	btl	%edx, %esi
     a06:      	jae	0xa1a <filter_32ty_map+0x6a>
     a08:      	testq	%rax, %rax
     a0b:      	setne	%cl
     a0e:      	jmp	0xa2a <filter_32ty_map+0x7a>
     a10:      	xorl	%eax, %eax
     a12:      	addq	$0x18, %rsp
     a16:      	popq	%rbx
     a17:      	popq	%r14
     a19:      	retq
     a1a:      	movl	$0xc0800, %esi          # imm = 0xC0800
     a1f:      	btl	%edx, %esi
     a22:      	jae	0xa2a <filter_32ty_map+0x7a>
     a24:      	testq	%rax, %rax
     a27:      	sete	%cl
     a2a:      	movzbl	%cl, %eax
     a2d:      	addq	$0x18, %rsp
     a31:      	popq	%rbx
     a32:      	popq	%r14
     a34:      	retq
     a35:      	nopw	%cs:(%rax,%rax)

0000000000000a40 <filter_32ty_range>:
     a40:      	movl	0x4(%rdi), %ecx
     a43:      	movl	0xc(%rdi), %eax
     a46:      	cmpl	$0xc, %eax
     a49:      	ja	0xb2f <filter_32ty_range+0xef>
     a4f:      	movl	$0x1402, %edx           # imm = 0x1402
     a54:      	btl	%eax, %edx
     a57:      	jae	0xb2f <filter_32ty_range+0xef>
     a5d:      	movl	(%rsi), %esi
     a5f:      	cmpl	$0x1f, %ecx
     a62:      	jne	0xaca <filter_32ty_range+0x8a>
     a64:      	movl	$0x1, %eax
     a69:      	cmpl	%esi, 0x10(%rdi)
     a6c:      	jg	0xa77 <filter_32ty_range+0x37>
     a6e:      	cmpl	0x14(%rdi), %esi
     a71:      	jle	0xb45 <filter_32ty_range+0x105>
     a77:      	movl	0x8(%rdi), %edx
     a7a:      	cmpl	$0x11, %edx
     a7d:      	jb	0xbe5 <filter_32ty_range+0x1a5>
     a83:      	cmpl	%esi, 0x18(%rdi)
     a86:      	jg	0xa91 <filter_32ty_range+0x51>
     a88:      	cmpl	0x1c(%rdi), %esi
     a8b:      	jle	0xb45 <filter_32ty_range+0x105>
     a91:      	cmpl	$0x19, %edx
     a94:      	jb	0xbe5 <filter_32ty_range+0x1a5>
     a9a:      	cmpl	%esi, 0x20(%rdi)
     a9d:      	jg	0xaa8 <filter_32ty_range+0x68>
     a9f:      	cmpl	0x24(%rdi), %esi
     aa2:      	jle	0xb45 <filter_32ty_range+0x105>
     aa8:      	cmpl	$0x21, %edx
     aab:      	jb	0xbe5 <filter_32ty_range+0x1a5>
     ab1:      	xorl	%edx, %edx
     ab3:      	cmpl	%esi, 0x28(%rdi)
     ab6:      	jg	0xbe7 <filter_32ty_range+0x1a7>
     abc:      	cmpl	0x2c(%rdi), %esi
     abf:      	jle	0xb45 <filter_32ty_range+0x105>
     ac5:      	jmp	0xbe7 <filter_32ty_range+0x1a7>
     aca:      	movl	0x8(%rdi), %eax
     acd:      	cmpl	%esi, 0x10(%rdi)
     ad0:      	setle	%r8b
     ad4:      	cmpl	0x14(%rdi), %esi
     ad7:      	setle	%dl
     ada:      	andb	%r8b, %dl
     add:      	cmpl	$0x11, %eax
     ae0:      	jb	0xbe7 <filter_32ty_range+0x1a7>
     ae6:      	cmpl	%esi, 0x18(%rdi)
     ae9:      	setle	%r8b
     aed:      	cmpl	0x1c(%rdi), %esi
     af0:      	setle	%r9b
     af4:      	andb	%r8b, %r9b
     af7:      	orb	%r9b, %dl
     afa:      	cmpl	$0x19, %eax
     afd:      	jb	0xbe7 <filter_32ty_range+0x1a7>
     b03:      	cmpl	%esi, 0x20(%rdi)
     b06:      	setle	%r8b
     b0a:      	cmpl	0x24(%rdi), %esi
     b0d:      	setle	%r9b
     b11:      	andb	%r8b, %r9b
     b14:      	orb	%r9b, %dl
     b17:      	cmpl	$0x21, %eax
     b1a:      	jb	0xbe7 <filter_32ty_range+0x1a7>
     b20:      	cmpl	%esi, 0x28(%rdi)
     b23:      	setle	%al
     b26:      	cmpl	0x2c(%rdi), %esi
     b29:      	setle	%sil
     b2d:      	jmp	0xba1 <filter_32ty_range+0x161>
     b2f:      	movl	(%rsi), %esi
     b31:      	cmpl	$0x1f, %ecx
     b34:      	jne	0xb46 <filter_32ty_range+0x106>
     b36:      	movl	$0x1, %eax
     b3b:      	cmpl	%esi, 0x10(%rdi)
     b3e:      	ja	0xba9 <filter_32ty_range+0x169>
     b40:      	cmpl	0x14(%rdi), %esi
     b43:      	ja	0xba9 <filter_32ty_range+0x169>
     b45:      	retq
     b46:      	movl	0x8(%rdi), %eax
     b49:      	cmpl	%esi, 0x10(%rdi)
     b4c:      	setbe	%r8b
     b50:      	cmpl	0x14(%rdi), %esi
     b53:      	setbe	%dl
     b56:      	andb	%r8b, %dl
     b59:      	cmpl	$0x11, %eax
     b5c:      	jb	0xbe7 <filter_32ty_range+0x1a7>
     b62:      	cmpl	%esi, 0x18(%rdi)
     b65:      	setbe	%r8b
     b69:      	cmpl	0x1c(%rdi), %esi
     b6c:      	setbe	%r9b
     b70:      	andb	%r8b, %r9b
     b73:      	orb	%r9b, %dl
     b76:      	cmpl	$0x19, %eax
     b79:      	jb	0xbe7 <filter_32ty_range+0x1a7>
     b7b:      	cmpl	%esi, 0x20(%rdi)
     b7e:      	setbe	%r8b
     b82:      	cmpl	0x24(%rdi), %esi
     b85:      	setbe	%r9b
     b89:      	andb	%r8b, %r9b
     b8c:      	orb	%r9b, %dl
     b8f:      	cmpl	$0x21, %eax
     b92:      	jb	0xbe7 <filter_32ty_range+0x1a7>
     b94:      	cmpl	%esi, 0x28(%rdi)
     b97:      	setbe	%al
     b9a:      	cmpl	0x2c(%rdi), %esi
     b9d:      	setbe	%sil
     ba1:      	andb	%al, %sil
     ba4:      	orb	%sil, %dl
     ba7:      	jmp	0xbe7 <filter_32ty_range+0x1a7>
     ba9:      	movl	0x8(%rdi), %edx
     bac:      	cmpl	$0x11, %edx
     baf:      	jb	0xbe5 <filter_32ty_range+0x1a5>
     bb1:      	cmpl	%esi, 0x18(%rdi)
     bb4:      	ja	0xbbb <filter_32ty_range+0x17b>
     bb6:      	cmpl	0x1c(%rdi), %esi
     bb9:      	jbe	0xb45 <filter_32ty_range+0x105>
     bbb:      	cmpl	$0x19, %edx
     bbe:      	jb	0xbe5 <filter_32ty_range+0x1a5>
     bc0:      	cmpl	%esi, 0x20(%rdi)
     bc3:      	ja	0xbce <filter_32ty_range+0x18e>
     bc5:      	cmpl	0x24(%rdi), %esi
     bc8:      	jbe	0xb45 <filter_32ty_range+0x105>
     bce:      	cmpl	$0x21, %edx
     bd1:      	jb	0xbe5 <filter_32ty_range+0x1a5>
     bd3:      	xorl	%edx, %edx
     bd5:      	cmpl	%esi, 0x28(%rdi)
     bd8:      	ja	0xbe7 <filter_32ty_range+0x1a7>
     bda:      	cmpl	0x2c(%rdi), %esi
     bdd:      	jbe	0xb45 <filter_32ty_range+0x105>
     be3:      	jmp	0xbe7 <filter_32ty_range+0x1a7>
     be5:      	xorl	%edx, %edx
     be7:      	cmpl	$0x20, %ecx
     bea:      	sete	%al
     bed:      	xorb	$0x1, %dl
     bf0:      	andb	%al, %dl
     bf2:      	movzbl	%dl, %eax
     bf5:      	retq
     bf6:      	nopw	%cs:(%rax,%rax)

0000000000000c00 <filter_16ty_selector_val>:
     c00:      	movl	0x4(%rdi), %ecx
     c03:      	movl	$0x1, %eax
     c08:      	cmpq	$0x25, %rcx
     c0c:      	ja	0xc7f <filter_16ty_selector_val+0x7f>
     c0e:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     c18:      	btq	%rcx, %rdx
     c1c:      	jae	0xc1f <filter_16ty_selector_val+0x1f>
     c1e:      	retq
     c1f:      	movl	$0x18, %edx
     c24:      	btq	%rcx, %rdx
     c28:      	jae	0xc3f <filter_16ty_selector_val+0x3f>
     c2a:      	movzwl	(%rsi), %edx
     c2d:      	cmpl	%edx, 0x10(%rdi)
     c30:      	jne	0xd55 <filter_16ty_selector_val+0x155>
     c36:      	xorl	%eax, %eax
     c38:      	cmpl	$0x3, %ecx
     c3b:      	sete	%al
     c3e:      	retq
     c3f:      	cmpq	$0xc, %rcx
     c43:      	jne	0xc7f <filter_16ty_selector_val+0x7f>
     c45:      	movzwl	(%rsi), %ecx
     c48:      	testl	%ecx, 0x10(%rdi)
     c4b:      	jne	0xc1e <filter_16ty_selector_val+0x1e>
     c4d:      	movl	0x8(%rdi), %edx
     c50:      	cmpl	$0xd, %edx
     c53:      	jb	0xe17 <filter_16ty_selector_val+0x217>
     c59:      	testl	%ecx, 0x14(%rdi)
     c5c:      	jne	0xc1e <filter_16ty_selector_val+0x1e>
     c5e:      	cmpl	$0x11, %edx
     c61:      	jb	0xe17 <filter_16ty_selector_val+0x217>
     c67:      	testl	%ecx, 0x18(%rdi)
     c6a:      	jne	0xc1e <filter_16ty_selector_val+0x1e>
     c6c:      	cmpl	$0x15, %edx
     c6f:      	jb	0xe17 <filter_16ty_selector_val+0x217>
     c75:      	testl	%ecx, 0x1c(%rdi)
     c78:      	jne	0xc1e <filter_16ty_selector_val+0x1e>
     c7a:      	jmp	0xe17 <filter_16ty_selector_val+0x217>
     c7f:      	cmpl	$0x1, %ecx
     c82:      	je	0xcf1 <filter_16ty_selector_val+0xf1>
     c84:      	cmpl	$0x2, %ecx
     c87:      	jne	0xe17 <filter_16ty_selector_val+0x217>
     c8d:      	movl	0xc(%rdi), %ecx
     c90:      	cmpl	$0xc, %ecx
     c93:      	ja	0xdde <filter_16ty_selector_val+0x1de>
     c99:      	movl	$0x1402, %edx           # imm = 0x1402
     c9e:      	btl	%ecx, %edx
     ca1:      	jae	0xdde <filter_16ty_selector_val+0x1de>
     ca7:      	movswl	(%rsi), %ecx
     caa:      	cmpl	%ecx, 0x10(%rdi)
     cad:      	jg	0xc1e <filter_16ty_selector_val+0x1e>
     cb3:      	movl	0x8(%rdi), %edx
     cb6:      	cmpl	$0xd, %edx
     cb9:      	jb	0xe17 <filter_16ty_selector_val+0x217>
     cbf:      	cmpl	%ecx, 0x14(%rdi)
     cc2:      	jg	0xc1e <filter_16ty_selector_val+0x1e>
     cc8:      	cmpl	$0x11, %edx
     ccb:      	jb	0xe17 <filter_16ty_selector_val+0x217>
     cd1:      	cmpl	%ecx, 0x18(%rdi)
     cd4:      	jg	0xc1e <filter_16ty_selector_val+0x1e>
     cda:      	cmpl	$0x15, %edx
     cdd:      	jb	0xe17 <filter_16ty_selector_val+0x217>
     ce3:      	cmpl	%ecx, 0x1c(%rdi)
     ce6:      	jg	0xc1e <filter_16ty_selector_val+0x1e>
     cec:      	jmp	0xe17 <filter_16ty_selector_val+0x217>
     cf1:      	movl	0xc(%rdi), %ecx
     cf4:      	cmpl	$0xc, %ecx
     cf7:      	ja	0xda3 <filter_16ty_selector_val+0x1a3>
     cfd:      	movl	$0x1402, %edx           # imm = 0x1402
     d02:      	btl	%ecx, %edx
     d05:      	jae	0xda3 <filter_16ty_selector_val+0x1a3>
     d0b:      	movswl	(%rsi), %ecx
     d0e:      	cmpl	%ecx, 0x10(%rdi)
     d11:      	jl	0xc1e <filter_16ty_selector_val+0x1e>
     d17:      	movl	0x8(%rdi), %edx
     d1a:      	cmpl	$0xd, %edx
     d1d:      	jb	0xe17 <filter_16ty_selector_val+0x217>
     d23:      	cmpl	%ecx, 0x14(%rdi)
     d26:      	jl	0xc1e <filter_16ty_selector_val+0x1e>
     d2c:      	cmpl	$0x11, %edx
     d2f:      	jb	0xe17 <filter_16ty_selector_val+0x217>
     d35:      	cmpl	%ecx, 0x18(%rdi)
     d38:      	jl	0xc1e <filter_16ty_selector_val+0x1e>
     d3e:      	cmpl	$0x15, %edx
     d41:      	jb	0xe17 <filter_16ty_selector_val+0x217>
     d47:      	cmpl	%ecx, 0x1c(%rdi)
     d4a:      	jl	0xc1e <filter_16ty_selector_val+0x1e>
     d50:      	jmp	0xe17 <filter_16ty_selector_val+0x217>
     d55:      	movl	0x8(%rdi), %esi
     d58:      	cmpl	$0xd, %esi
     d5b:      	jb	0xd82 <filter_16ty_selector_val+0x182>
     d5d:      	cmpl	%edx, 0x14(%rdi)
     d60:      	je	0xc36 <filter_16ty_selector_val+0x36>
     d66:      	cmpl	$0x11, %esi
     d69:      	jb	0xd82 <filter_16ty_selector_val+0x182>
     d6b:      	cmpl	%edx, 0x18(%rdi)
     d6e:      	je	0xc36 <filter_16ty_selector_val+0x36>
     d74:      	cmpl	$0x15, %esi
     d77:      	jb	0xd82 <filter_16ty_selector_val+0x182>
     d79:      	cmpl	%edx, 0x1c(%rdi)
     d7c:      	je	0xc36 <filter_16ty_selector_val+0x36>
     d82:      	cmpl	$0x25, %ecx
     d85:      	ja	0xe17 <filter_16ty_selector_val+0x217>
     d8b:      	movl	%ecx, %ecx
     d8d:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     d97:      	btq	%rcx, %rdx
     d9b:      	jb	0xc1e <filter_16ty_selector_val+0x1e>
     da1:      	jmp	0xe17 <filter_16ty_selector_val+0x217>
     da3:      	movzwl	(%rsi), %ecx
     da6:      	cmpl	%ecx, 0x10(%rdi)
     da9:      	jb	0xc1e <filter_16ty_selector_val+0x1e>
     daf:      	movl	0x8(%rdi), %edx
     db2:      	cmpl	$0xd, %edx
     db5:      	jb	0xe17 <filter_16ty_selector_val+0x217>
     db7:      	cmpl	%ecx, 0x14(%rdi)
     dba:      	jb	0xc1e <filter_16ty_selector_val+0x1e>
     dc0:      	cmpl	$0x11, %edx
     dc3:      	jb	0xe17 <filter_16ty_selector_val+0x217>
     dc5:      	cmpl	%ecx, 0x18(%rdi)
     dc8:      	jb	0xc1e <filter_16ty_selector_val+0x1e>
     dce:      	cmpl	$0x15, %edx
     dd1:      	jb	0xe17 <filter_16ty_selector_val+0x217>
     dd3:      	cmpl	%ecx, 0x1c(%rdi)
     dd6:      	jb	0xc1e <filter_16ty_selector_val+0x1e>
     ddc:      	jmp	0xe17 <filter_16ty_selector_val+0x217>
     dde:      	movzwl	(%rsi), %ecx
     de1:      	cmpl	%ecx, 0x10(%rdi)
     de4:      	ja	0xc1e <filter_16ty_selector_val+0x1e>
     dea:      	movl	0x8(%rdi), %edx
     ded:      	cmpl	$0xd, %edx
     df0:      	jb	0xe17 <filter_16ty_selector_val+0x217>
     df2:      	cmpl	%ecx, 0x14(%rdi)
     df5:      	ja	0xc1e <filter_16ty_selector_val+0x1e>
     dfb:      	cmpl	$0x11, %edx
     dfe:      	jb	0xe17 <filter_16ty_selector_val+0x217>
     e00:      	cmpl	%ecx, 0x18(%rdi)
     e03:      	ja	0xc1e <filter_16ty_selector_val+0x1e>
     e09:      	cmpl	$0x15, %edx
     e0c:      	jb	0xe17 <filter_16ty_selector_val+0x217>
     e0e:      	cmpl	%ecx, 0x1c(%rdi)
     e11:      	ja	0xc1e <filter_16ty_selector_val+0x1e>
     e17:      	xorl	%eax, %eax
     e19:      	retq
     e1a:      	nopw	(%rax,%rax)

0000000000000e20 <filter_16ty_map>:
     e20:      	pushq	%r14
     e22:      	pushq	%rbx
     e23:      	subq	$0x18, %rsp
     e27:      	movq	%rsi, %r14
     e2a:      	movq	%rdi, %rbx
     e2d:      	movzbl	0x10(%rdi), %eax
     e31:      	movl	%eax, 0xc(%rsp)
     e35:      	movq	(%rip), %rdi            # 0xe3c <filter_16ty_map+0x1c>
     e3c:      	leaq	0xc(%rsp), %rsi
     e41:      	movl	$0x1, %eax
     e46:      	callq	*%rax
     e48:      	testq	%rax, %rax
     e4b:      	je	0xe81 <filter_16ty_map+0x61>
     e4d:      	movq	%rax, %rdi
     e50:      	movzwl	(%r14), %eax
     e54:      	movq	%rax, 0x10(%rsp)
     e59:      	leaq	0x10(%rsp), %rsi
     e5e:      	movl	$0x1, %eax
     e63:      	callq	*%rax
     e65:      	movl	0x4(%rbx), %edx
     e68:      	xorl	%ecx, %ecx
     e6a:      	cmpl	$0x1d, %edx
     e6d:      	ja	0xe9b <filter_16ty_map+0x7b>
     e6f:      	movl	$0x30038400, %esi       # imm = 0x30038400
     e74:      	btl	%edx, %esi
     e77:      	jae	0xe8b <filter_16ty_map+0x6b>
     e79:      	testq	%rax, %rax
     e7c:      	setne	%cl
     e7f:      	jmp	0xe9b <filter_16ty_map+0x7b>
     e81:      	xorl	%eax, %eax
     e83:      	addq	$0x18, %rsp
     e87:      	popq	%rbx
     e88:      	popq	%r14
     e8a:      	retq
     e8b:      	movl	$0xc0800, %esi          # imm = 0xC0800
     e90:      	btl	%edx, %esi
     e93:      	jae	0xe9b <filter_16ty_map+0x7b>
     e95:      	testq	%rax, %rax
     e98:      	sete	%cl
     e9b:      	movzbl	%cl, %eax
     e9e:      	addq	$0x18, %rsp
     ea2:      	popq	%rbx
     ea3:      	popq	%r14
     ea5:      	retq
     ea6:      	nopw	%cs:(%rax,%rax)

0000000000000eb0 <filter_16ty_range>:
     eb0:      	movl	0x4(%rdi), %ecx
     eb3:      	movl	0xc(%rdi), %eax
     eb6:      	cmpl	$0xc, %eax
     eb9:      	ja	0xfa0 <filter_16ty_range+0xf0>
     ebf:      	movl	$0x1402, %edx           # imm = 0x1402
     ec4:      	btl	%eax, %edx
     ec7:      	jae	0xfa0 <filter_16ty_range+0xf0>
     ecd:      	movswl	(%rsi), %esi
     ed0:      	cmpl	$0x1f, %ecx
     ed3:      	jne	0xf3b <filter_16ty_range+0x8b>
     ed5:      	movl	$0x1, %eax
     eda:      	cmpl	%esi, 0x10(%rdi)
     edd:      	jg	0xee8 <filter_16ty_range+0x38>
     edf:      	cmpl	%esi, 0x14(%rdi)
     ee2:      	jge	0xfb7 <filter_16ty_range+0x107>
     ee8:      	movl	0x8(%rdi), %edx
     eeb:      	cmpl	$0x11, %edx
     eee:      	jb	0x1057 <filter_16ty_range+0x1a7>
     ef4:      	cmpl	%esi, 0x18(%rdi)
     ef7:      	jg	0xf02 <filter_16ty_range+0x52>
     ef9:      	cmpl	%esi, 0x1c(%rdi)
     efc:      	jge	0xfb7 <filter_16ty_range+0x107>
     f02:      	cmpl	$0x19, %edx
     f05:      	jb	0x1057 <filter_16ty_range+0x1a7>
     f0b:      	cmpl	%esi, 0x20(%rdi)
     f0e:      	jg	0xf19 <filter_16ty_range+0x69>
     f10:      	cmpl	%esi, 0x24(%rdi)
     f13:      	jge	0xfb7 <filter_16ty_range+0x107>
     f19:      	cmpl	$0x21, %edx
     f1c:      	jb	0x1057 <filter_16ty_range+0x1a7>
     f22:      	xorl	%edx, %edx
     f24:      	cmpl	%esi, 0x28(%rdi)
     f27:      	jg	0x1059 <filter_16ty_range+0x1a9>
     f2d:      	cmpl	%esi, 0x2c(%rdi)
     f30:      	jge	0xfb7 <filter_16ty_range+0x107>
     f36:      	jmp	0x1059 <filter_16ty_range+0x1a9>
     f3b:      	movl	0x8(%rdi), %eax
     f3e:      	cmpl	%esi, 0x10(%rdi)
     f41:      	setle	%r8b
     f45:      	cmpl	%esi, 0x14(%rdi)
     f48:      	setge	%dl
     f4b:      	andb	%r8b, %dl
     f4e:      	cmpl	$0x11, %eax
     f51:      	jb	0x1059 <filter_16ty_range+0x1a9>
     f57:      	cmpl	%esi, 0x18(%rdi)
     f5a:      	setle	%r8b
     f5e:      	cmpl	%esi, 0x1c(%rdi)
     f61:      	setge	%r9b
     f65:      	andb	%r8b, %r9b
     f68:      	orb	%r9b, %dl
     f6b:      	cmpl	$0x19, %eax
     f6e:      	jb	0x1059 <filter_16ty_range+0x1a9>
     f74:      	cmpl	%esi, 0x20(%rdi)
     f77:      	setle	%r8b
     f7b:      	cmpl	%esi, 0x24(%rdi)
     f7e:      	setge	%r9b
     f82:      	andb	%r8b, %r9b
     f85:      	orb	%r9b, %dl
     f88:      	cmpl	$0x21, %eax
     f8b:      	jb	0x1059 <filter_16ty_range+0x1a9>
     f91:      	cmpl	%esi, 0x28(%rdi)
     f94:      	setle	%al
     f97:      	cmpl	%esi, 0x2c(%rdi)
     f9a:      	setge	%sil
     f9e:      	jmp	0x1013 <filter_16ty_range+0x163>
     fa0:      	movzwl	(%rsi), %esi
     fa3:      	cmpl	$0x1f, %ecx
     fa6:      	jne	0xfb8 <filter_16ty_range+0x108>
     fa8:      	movl	$0x1, %eax
     fad:      	cmpl	%esi, 0x10(%rdi)
     fb0:      	ja	0x101b <filter_16ty_range+0x16b>
     fb2:      	cmpl	%esi, 0x14(%rdi)
     fb5:      	jb	0x101b <filter_16ty_range+0x16b>
     fb7:      	retq
     fb8:      	movl	0x8(%rdi), %eax
     fbb:      	cmpl	%esi, 0x10(%rdi)
     fbe:      	setbe	%r8b
     fc2:      	cmpl	%esi, 0x14(%rdi)
     fc5:      	setae	%dl
     fc8:      	andb	%r8b, %dl
     fcb:      	cmpl	$0x11, %eax
     fce:      	jb	0x1059 <filter_16ty_range+0x1a9>
     fd4:      	cmpl	%esi, 0x18(%rdi)
     fd7:      	setbe	%r8b
     fdb:      	cmpl	%esi, 0x1c(%rdi)
     fde:      	setae	%r9b
     fe2:      	andb	%r8b, %r9b
     fe5:      	orb	%r9b, %dl
     fe8:      	cmpl	$0x19, %eax
     feb:      	jb	0x1059 <filter_16ty_range+0x1a9>
     fed:      	cmpl	%esi, 0x20(%rdi)
     ff0:      	setbe	%r8b
     ff4:      	cmpl	%esi, 0x24(%rdi)
     ff7:      	setae	%r9b
     ffb:      	andb	%r8b, %r9b
     ffe:      	orb	%r9b, %dl
    1001:      	cmpl	$0x21, %eax
    1004:      	jb	0x1059 <filter_16ty_range+0x1a9>
    1006:      	cmpl	%esi, 0x28(%rdi)
    1009:      	setbe	%al
    100c:      	cmpl	%esi, 0x2c(%rdi)
    100f:      	setae	%sil
    1013:      	andb	%al, %sil
    1016:      	orb	%sil, %dl
    1019:      	jmp	0x1059 <filter_16ty_range+0x1a9>
    101b:      	movl	0x8(%rdi), %edx
    101e:      	cmpl	$0x11, %edx
    1021:      	jb	0x1057 <filter_16ty_range+0x1a7>
    1023:      	cmpl	%esi, 0x18(%rdi)
    1026:      	ja	0x102d <filter_16ty_range+0x17d>
    1028:      	cmpl	%esi, 0x1c(%rdi)
    102b:      	jae	0xfb7 <filter_16ty_range+0x107>
    102d:      	cmpl	$0x19, %edx
    1030:      	jb	0x1057 <filter_16ty_range+0x1a7>
    1032:      	cmpl	%esi, 0x20(%rdi)
    1035:      	ja	0x1040 <filter_16ty_range+0x190>
    1037:      	cmpl	%esi, 0x24(%rdi)
    103a:      	jae	0xfb7 <filter_16ty_range+0x107>
    1040:      	cmpl	$0x21, %edx
    1043:      	jb	0x1057 <filter_16ty_range+0x1a7>
    1045:      	xorl	%edx, %edx
    1047:      	cmpl	%esi, 0x28(%rdi)
    104a:      	ja	0x1059 <filter_16ty_range+0x1a9>
    104c:      	cmpl	%esi, 0x2c(%rdi)
    104f:      	jae	0xfb7 <filter_16ty_range+0x107>
    1055:      	jmp	0x1059 <filter_16ty_range+0x1a9>
    1057:      	xorl	%edx, %edx
    1059:      	cmpl	$0x20, %ecx
    105c:      	sete	%al
    105f:      	xorb	$0x1, %dl
    1062:      	andb	%al, %dl
    1064:      	movzbl	%dl, %eax
    1067:      	retq
    1068:      	nopl	(%rax,%rax)

0000000000001070 <filter_8ty_selector_val>:
    1070:      	movl	0x4(%rdi), %ecx
    1073:      	movl	$0x1, %eax
    1078:      	cmpq	$0x25, %rcx
    107c:      	ja	0x10ef <filter_8ty_selector_val+0x7f>
    107e:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
    1088:      	btq	%rcx, %rdx
    108c:      	jae	0x108f <filter_8ty_selector_val+0x1f>
    108e:      	retq
    108f:      	movl	$0x18, %edx
    1094:      	btq	%rcx, %rdx
    1098:      	jae	0x10af <filter_8ty_selector_val+0x3f>
    109a:      	movzbl	(%rsi), %edx
    109d:      	cmpl	%edx, 0x10(%rdi)
    10a0:      	jne	0x11c5 <filter_8ty_selector_val+0x155>
    10a6:      	xorl	%eax, %eax
    10a8:      	cmpl	$0x3, %ecx
    10ab:      	sete	%al
    10ae:      	retq
    10af:      	cmpq	$0xc, %rcx
    10b3:      	jne	0x10ef <filter_8ty_selector_val+0x7f>
    10b5:      	movzbl	(%rsi), %ecx
    10b8:      	testl	%ecx, 0x10(%rdi)
    10bb:      	jne	0x108e <filter_8ty_selector_val+0x1e>
    10bd:      	movl	0x8(%rdi), %edx
    10c0:      	cmpl	$0xd, %edx
    10c3:      	jb	0x1287 <filter_8ty_selector_val+0x217>
    10c9:      	testl	%ecx, 0x14(%rdi)
    10cc:      	jne	0x108e <filter_8ty_selector_val+0x1e>
    10ce:      	cmpl	$0x11, %edx
    10d1:      	jb	0x1287 <filter_8ty_selector_val+0x217>
    10d7:      	testl	%ecx, 0x18(%rdi)
    10da:      	jne	0x108e <filter_8ty_selector_val+0x1e>
    10dc:      	cmpl	$0x15, %edx
    10df:      	jb	0x1287 <filter_8ty_selector_val+0x217>
    10e5:      	testl	%ecx, 0x1c(%rdi)
    10e8:      	jne	0x108e <filter_8ty_selector_val+0x1e>
    10ea:      	jmp	0x1287 <filter_8ty_selector_val+0x217>
    10ef:      	cmpl	$0x1, %ecx
    10f2:      	je	0x1161 <filter_8ty_selector_val+0xf1>
    10f4:      	cmpl	$0x2, %ecx
    10f7:      	jne	0x1287 <filter_8ty_selector_val+0x217>
    10fd:      	movl	0xc(%rdi), %ecx
    1100:      	cmpl	$0xc, %ecx
    1103:      	ja	0x124e <filter_8ty_selector_val+0x1de>
    1109:      	movl	$0x1402, %edx           # imm = 0x1402
    110e:      	btl	%ecx, %edx
    1111:      	jae	0x124e <filter_8ty_selector_val+0x1de>
    1117:      	movsbl	(%rsi), %ecx
    111a:      	cmpl	%ecx, 0x10(%rdi)
    111d:      	jg	0x108e <filter_8ty_selector_val+0x1e>
    1123:      	movl	0x8(%rdi), %edx
    1126:      	cmpl	$0xd, %edx
    1129:      	jb	0x1287 <filter_8ty_selector_val+0x217>
    112f:      	cmpl	%ecx, 0x14(%rdi)
    1132:      	jg	0x108e <filter_8ty_selector_val+0x1e>
    1138:      	cmpl	$0x11, %edx
    113b:      	jb	0x1287 <filter_8ty_selector_val+0x217>
    1141:      	cmpl	%ecx, 0x18(%rdi)
    1144:      	jg	0x108e <filter_8ty_selector_val+0x1e>
    114a:      	cmpl	$0x15, %edx
    114d:      	jb	0x1287 <filter_8ty_selector_val+0x217>
    1153:      	cmpl	%ecx, 0x1c(%rdi)
    1156:      	jg	0x108e <filter_8ty_selector_val+0x1e>
    115c:      	jmp	0x1287 <filter_8ty_selector_val+0x217>
    1161:      	movl	0xc(%rdi), %ecx
    1164:      	cmpl	$0xc, %ecx
    1167:      	ja	0x1213 <filter_8ty_selector_val+0x1a3>
    116d:      	movl	$0x1402, %edx           # imm = 0x1402
    1172:      	btl	%ecx, %edx
    1175:      	jae	0x1213 <filter_8ty_selector_val+0x1a3>
    117b:      	movsbl	(%rsi), %ecx
    117e:      	cmpl	%ecx, 0x10(%rdi)
    1181:      	jl	0x108e <filter_8ty_selector_val+0x1e>
    1187:      	movl	0x8(%rdi), %edx
    118a:      	cmpl	$0xd, %edx
    118d:      	jb	0x1287 <filter_8ty_selector_val+0x217>
    1193:      	cmpl	%ecx, 0x14(%rdi)
    1196:      	jl	0x108e <filter_8ty_selector_val+0x1e>
    119c:      	cmpl	$0x11, %edx
    119f:      	jb	0x1287 <filter_8ty_selector_val+0x217>
    11a5:      	cmpl	%ecx, 0x18(%rdi)
    11a8:      	jl	0x108e <filter_8ty_selector_val+0x1e>
    11ae:      	cmpl	$0x15, %edx
    11b1:      	jb	0x1287 <filter_8ty_selector_val+0x217>
    11b7:      	cmpl	%ecx, 0x1c(%rdi)
    11ba:      	jl	0x108e <filter_8ty_selector_val+0x1e>
    11c0:      	jmp	0x1287 <filter_8ty_selector_val+0x217>
    11c5:      	movl	0x8(%rdi), %esi
    11c8:      	cmpl	$0xd, %esi
    11cb:      	jb	0x11f2 <filter_8ty_selector_val+0x182>
    11cd:      	cmpl	%edx, 0x14(%rdi)
    11d0:      	je	0x10a6 <filter_8ty_selector_val+0x36>
    11d6:      	cmpl	$0x11, %esi
    11d9:      	jb	0x11f2 <filter_8ty_selector_val+0x182>
    11db:      	cmpl	%edx, 0x18(%rdi)
    11de:      	je	0x10a6 <filter_8ty_selector_val+0x36>
    11e4:      	cmpl	$0x15, %esi
    11e7:      	jb	0x11f2 <filter_8ty_selector_val+0x182>
    11e9:      	cmpl	%edx, 0x1c(%rdi)
    11ec:      	je	0x10a6 <filter_8ty_selector_val+0x36>
    11f2:      	cmpl	$0x25, %ecx
    11f5:      	ja	0x1287 <filter_8ty_selector_val+0x217>
    11fb:      	movl	%ecx, %ecx
    11fd:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1207:      	btq	%rcx, %rdx
    120b:      	jb	0x108e <filter_8ty_selector_val+0x1e>
    1211:      	jmp	0x1287 <filter_8ty_selector_val+0x217>
    1213:      	movzbl	(%rsi), %ecx
    1216:      	cmpl	%ecx, 0x10(%rdi)
    1219:      	jb	0x108e <filter_8ty_selector_val+0x1e>
    121f:      	movl	0x8(%rdi), %edx
    1222:      	cmpl	$0xd, %edx
    1225:      	jb	0x1287 <filter_8ty_selector_val+0x217>
    1227:      	cmpl	%ecx, 0x14(%rdi)
    122a:      	jb	0x108e <filter_8ty_selector_val+0x1e>
    1230:      	cmpl	$0x11, %edx
    1233:      	jb	0x1287 <filter_8ty_selector_val+0x217>
    1235:      	cmpl	%ecx, 0x18(%rdi)
    1238:      	jb	0x108e <filter_8ty_selector_val+0x1e>
    123e:      	cmpl	$0x15, %edx
    1241:      	jb	0x1287 <filter_8ty_selector_val+0x217>
    1243:      	cmpl	%ecx, 0x1c(%rdi)
    1246:      	jb	0x108e <filter_8ty_selector_val+0x1e>
    124c:      	jmp	0x1287 <filter_8ty_selector_val+0x217>
    124e:      	movzbl	(%rsi), %ecx
    1251:      	cmpl	%ecx, 0x10(%rdi)
    1254:      	ja	0x108e <filter_8ty_selector_val+0x1e>
    125a:      	movl	0x8(%rdi), %edx
    125d:      	cmpl	$0xd, %edx
    1260:      	jb	0x1287 <filter_8ty_selector_val+0x217>
    1262:      	cmpl	%ecx, 0x14(%rdi)
    1265:      	ja	0x108e <filter_8ty_selector_val+0x1e>
    126b:      	cmpl	$0x11, %edx
    126e:      	jb	0x1287 <filter_8ty_selector_val+0x217>
    1270:      	cmpl	%ecx, 0x18(%rdi)
    1273:      	ja	0x108e <filter_8ty_selector_val+0x1e>
    1279:      	cmpl	$0x15, %edx
    127c:      	jb	0x1287 <filter_8ty_selector_val+0x217>
    127e:      	cmpl	%ecx, 0x1c(%rdi)
    1281:      	ja	0x108e <filter_8ty_selector_val+0x1e>
    1287:      	xorl	%eax, %eax
    1289:      	retq
    128a:      	nopw	(%rax,%rax)

0000000000001290 <filter_8ty_map>:
    1290:      	pushq	%r14
    1292:      	pushq	%rbx
    1293:      	subq	$0x18, %rsp
    1297:      	movq	%rsi, %r14
    129a:      	movq	%rdi, %rbx
    129d:      	movzbl	0x10(%rdi), %eax
    12a1:      	movl	%eax, 0xc(%rsp)
    12a5:      	movq	(%rip), %rdi            # 0x12ac <filter_8ty_map+0x1c>
    12ac:      	leaq	0xc(%rsp), %rsi
    12b1:      	movl	$0x1, %eax
    12b6:      	callq	*%rax
    12b8:      	testq	%rax, %rax
    12bb:      	je	0x12f1 <filter_8ty_map+0x61>
    12bd:      	movq	%rax, %rdi
    12c0:      	movzbl	(%r14), %eax
    12c4:      	movq	%rax, 0x10(%rsp)
    12c9:      	leaq	0x10(%rsp), %rsi
    12ce:      	movl	$0x1, %eax
    12d3:      	callq	*%rax
    12d5:      	movl	0x4(%rbx), %edx
    12d8:      	xorl	%ecx, %ecx
    12da:      	cmpl	$0x1d, %edx
    12dd:      	ja	0x130b <filter_8ty_map+0x7b>
    12df:      	movl	$0x30038400, %esi       # imm = 0x30038400
    12e4:      	btl	%edx, %esi
    12e7:      	jae	0x12fb <filter_8ty_map+0x6b>
    12e9:      	testq	%rax, %rax
    12ec:      	setne	%cl
    12ef:      	jmp	0x130b <filter_8ty_map+0x7b>
    12f1:      	xorl	%eax, %eax
    12f3:      	addq	$0x18, %rsp
    12f7:      	popq	%rbx
    12f8:      	popq	%r14
    12fa:      	retq
    12fb:      	movl	$0xc0800, %esi          # imm = 0xC0800
    1300:      	btl	%edx, %esi
    1303:      	jae	0x130b <filter_8ty_map+0x7b>
    1305:      	testq	%rax, %rax
    1308:      	sete	%cl
    130b:      	movzbl	%cl, %eax
    130e:      	addq	$0x18, %rsp
    1312:      	popq	%rbx
    1313:      	popq	%r14
    1315:      	retq
    1316:      	nopw	%cs:(%rax,%rax)

0000000000001320 <filter_8ty_range>:
    1320:      	movl	0x4(%rdi), %ecx
    1323:      	movl	0xc(%rdi), %eax
    1326:      	cmpl	$0xc, %eax
    1329:      	ja	0x1410 <filter_8ty_range+0xf0>
    132f:      	movl	$0x1402, %edx           # imm = 0x1402
    1334:      	btl	%eax, %edx
    1337:      	jae	0x1410 <filter_8ty_range+0xf0>
    133d:      	movsbl	(%rsi), %esi
    1340:      	cmpl	$0x1f, %ecx
    1343:      	jne	0x13ab <filter_8ty_range+0x8b>
    1345:      	movl	$0x1, %eax
    134a:      	cmpl	%esi, 0x10(%rdi)
    134d:      	jg	0x1358 <filter_8ty_range+0x38>
    134f:      	cmpl	%esi, 0x14(%rdi)
    1352:      	jge	0x1427 <filter_8ty_range+0x107>
    1358:      	movl	0x8(%rdi), %edx
    135b:      	cmpl	$0x11, %edx
    135e:      	jb	0x14c7 <filter_8ty_range+0x1a7>
    1364:      	cmpl	%esi, 0x18(%rdi)
    1367:      	jg	0x1372 <filter_8ty_range+0x52>
    1369:      	cmpl	%esi, 0x1c(%rdi)
    136c:      	jge	0x1427 <filter_8ty_range+0x107>
    1372:      	cmpl	$0x19, %edx
    1375:      	jb	0x14c7 <filter_8ty_range+0x1a7>
    137b:      	cmpl	%esi, 0x20(%rdi)
    137e:      	jg	0x1389 <filter_8ty_range+0x69>
    1380:      	cmpl	%esi, 0x24(%rdi)
    1383:      	jge	0x1427 <filter_8ty_range+0x107>
    1389:      	cmpl	$0x21, %edx
    138c:      	jb	0x14c7 <filter_8ty_range+0x1a7>
    1392:      	xorl	%edx, %edx
    1394:      	cmpl	%esi, 0x28(%rdi)
    1397:      	jg	0x14c9 <filter_8ty_range+0x1a9>
    139d:      	cmpl	%esi, 0x2c(%rdi)
    13a0:      	jge	0x1427 <filter_8ty_range+0x107>
    13a6:      	jmp	0x14c9 <filter_8ty_range+0x1a9>
    13ab:      	movl	0x8(%rdi), %eax
    13ae:      	cmpl	%esi, 0x10(%rdi)
    13b1:      	setle	%r8b
    13b5:      	cmpl	%esi, 0x14(%rdi)
    13b8:      	setge	%dl
    13bb:      	andb	%r8b, %dl
    13be:      	cmpl	$0x11, %eax
    13c1:      	jb	0x14c9 <filter_8ty_range+0x1a9>
    13c7:      	cmpl	%esi, 0x18(%rdi)
    13ca:      	setle	%r8b
    13ce:      	cmpl	%esi, 0x1c(%rdi)
    13d1:      	setge	%r9b
    13d5:      	andb	%r8b, %r9b
    13d8:      	orb	%r9b, %dl
    13db:      	cmpl	$0x19, %eax
    13de:      	jb	0x14c9 <filter_8ty_range+0x1a9>
    13e4:      	cmpl	%esi, 0x20(%rdi)
    13e7:      	setle	%r8b
    13eb:      	cmpl	%esi, 0x24(%rdi)
    13ee:      	setge	%r9b
    13f2:      	andb	%r8b, %r9b
    13f5:      	orb	%r9b, %dl
    13f8:      	cmpl	$0x21, %eax
    13fb:      	jb	0x14c9 <filter_8ty_range+0x1a9>
    1401:      	cmpl	%esi, 0x28(%rdi)
    1404:      	setle	%al
    1407:      	cmpl	%esi, 0x2c(%rdi)
    140a:      	setge	%sil
    140e:      	jmp	0x1483 <filter_8ty_range+0x163>
    1410:      	movzbl	(%rsi), %esi
    1413:      	cmpl	$0x1f, %ecx
    1416:      	jne	0x1428 <filter_8ty_range+0x108>
    1418:      	movl	$0x1, %eax
    141d:      	cmpl	%esi, 0x10(%rdi)
    1420:      	ja	0x148b <filter_8ty_range+0x16b>
    1422:      	cmpl	%esi, 0x14(%rdi)
    1425:      	jb	0x148b <filter_8ty_range+0x16b>
    1427:      	retq
    1428:      	movl	0x8(%rdi), %eax
    142b:      	cmpl	%esi, 0x10(%rdi)
    142e:      	setbe	%r8b
    1432:      	cmpl	%esi, 0x14(%rdi)
    1435:      	setae	%dl
    1438:      	andb	%r8b, %dl
    143b:      	cmpl	$0x11, %eax
    143e:      	jb	0x14c9 <filter_8ty_range+0x1a9>
    1444:      	cmpl	%esi, 0x18(%rdi)
    1447:      	setbe	%r8b
    144b:      	cmpl	%esi, 0x1c(%rdi)
    144e:      	setae	%r9b
    1452:      	andb	%r8b, %r9b
    1455:      	orb	%r9b, %dl
    1458:      	cmpl	$0x19, %eax
    145b:      	jb	0x14c9 <filter_8ty_range+0x1a9>
    145d:      	cmpl	%esi, 0x20(%rdi)
    1460:      	setbe	%r8b
    1464:      	cmpl	%esi, 0x24(%rdi)
    1467:      	setae	%r9b
    146b:      	andb	%r8b, %r9b
    146e:      	orb	%r9b, %dl
    1471:      	cmpl	$0x21, %eax
    1474:      	jb	0x14c9 <filter_8ty_range+0x1a9>
    1476:      	cmpl	%esi, 0x28(%rdi)
    1479:      	setbe	%al
    147c:      	cmpl	%esi, 0x2c(%rdi)
    147f:      	setae	%sil
    1483:      	andb	%al, %sil
    1486:      	orb	%sil, %dl
    1489:      	jmp	0x14c9 <filter_8ty_range+0x1a9>
    148b:      	movl	0x8(%rdi), %edx
    148e:      	cmpl	$0x11, %edx
    1491:      	jb	0x14c7 <filter_8ty_range+0x1a7>
    1493:      	cmpl	%esi, 0x18(%rdi)
    1496:      	ja	0x149d <filter_8ty_range+0x17d>
    1498:      	cmpl	%esi, 0x1c(%rdi)
    149b:      	jae	0x1427 <filter_8ty_range+0x107>
    149d:      	cmpl	$0x19, %edx
    14a0:      	jb	0x14c7 <filter_8ty_range+0x1a7>
    14a2:      	cmpl	%esi, 0x20(%rdi)
    14a5:      	ja	0x14b0 <filter_8ty_range+0x190>
    14a7:      	cmpl	%esi, 0x24(%rdi)
    14aa:      	jae	0x1427 <filter_8ty_range+0x107>
    14b0:      	cmpl	$0x21, %edx
    14b3:      	jb	0x14c7 <filter_8ty_range+0x1a7>
    14b5:      	xorl	%edx, %edx
    14b7:      	cmpl	%esi, 0x28(%rdi)
    14ba:      	ja	0x14c9 <filter_8ty_range+0x1a9>
    14bc:      	cmpl	%esi, 0x2c(%rdi)
    14bf:      	jae	0x1427 <filter_8ty_range+0x107>
    14c5:      	jmp	0x14c9 <filter_8ty_range+0x1a9>
    14c7:      	xorl	%edx, %edx
    14c9:      	cmpl	$0x20, %ecx
    14cc:      	sete	%al
    14cf:      	xorb	$0x1, %dl
    14d2:      	andb	%al, %dl
    14d4:      	movzbl	%dl, %eax
    14d7:      	retq
    14d8:      	nopl	(%rax,%rax)

00000000000014e0 <filter_file_buf>:
    14e0:      	pushq	%rbx
    14e1:      	movq	%rdi, %rbx
    14e4:      	movl	(%rsi), %edx
    14e6:      	movl	0x4(%rdi), %ecx
    14e9:      	testl	%edx, %edx
    14eb:      	jne	0x14fb <filter_file_buf+0x1b>
    14ed:      	movl	%ecx, %eax
    14ef:      	andl	$-0x2, %eax
    14f2:      	cmpl	$0x24, %eax
    14f5:      	je	0x14fb <filter_file_buf+0x1b>
    14f7:      	xorl	%eax, %eax
    14f9:      	popq	%rbx
    14fa:      	retq
    14fb:      	cmpl	$0x25, %ecx
    14fe:      	ja	0x153a <filter_file_buf+0x5a>
    1500:      	movl	%ecx, %eax
    1502:      	movl	$0x4000100, %edi        # imm = 0x4000100
    1507:      	btq	%rax, %rdi
    150b:      	jb	0x156e <filter_file_buf+0x8e>
    150d:      	movl	$0x8000200, %edi        # imm = 0x8000200
    1512:      	btq	%rax, %rdi
    1516:      	jb	0x1558 <filter_file_buf+0x78>
    1518:      	movabsq	$0x3000000000, %rdi     # imm = 0x3000000000
    1522:      	btq	%rax, %rdi
    1526:      	jae	0x153a <filter_file_buf+0x5a>
    1528:      	movq	%rbx, %rdi
    152b:      	callq	0x1fd0 <filter_file_type>
    1530:      	movl	0x4(%rbx), %ecx
    1533:      	cmpl	$0x25, %ecx
    1536:      	jbe	0x158b <filter_file_buf+0xab>
    1538:      	jmp	0x15a1 <filter_file_buf+0xc1>
    153a:      	leal	-0x3(%rcx), %eax
    153d:      	cmpl	$0x2, %eax
    1540:      	jae	0x1584 <filter_file_buf+0xa4>
    1542:      	addq	$0x4, %rsi
    1546:      	movq	%rbx, %rdi
    1549:      	callq	0x1a60 <filter_char_buf_equal>
    154e:      	movl	0x4(%rbx), %ecx
    1551:      	cmpl	$0x25, %ecx
    1554:      	jbe	0x158b <filter_file_buf+0xab>
    1556:      	jmp	0x15a1 <filter_file_buf+0xc1>
    1558:      	addq	$0x4, %rsi
    155c:      	movl	0x10(%rbx), %edi
    155f:      	callq	0x1e80 <filter_char_buf_postfix>
    1564:      	movl	0x4(%rbx), %ecx
    1567:      	cmpl	$0x25, %ecx
    156a:      	jbe	0x158b <filter_file_buf+0xab>
    156c:      	jmp	0x15a1 <filter_file_buf+0xc1>
    156e:      	addq	$0x4, %rsi
    1572:      	movl	0x10(%rbx), %edi
    1575:      	callq	0x1de0 <filter_char_buf_prefix>
    157a:      	movl	0x4(%rbx), %ecx
    157d:      	cmpl	$0x25, %ecx
    1580:      	jbe	0x158b <filter_file_buf+0xab>
    1582:      	jmp	0x15a1 <filter_file_buf+0xc1>
    1584:      	xorl	%eax, %eax
    1586:      	cmpl	$0x25, %ecx
    1589:      	ja	0x15a1 <filter_file_buf+0xc1>
    158b:      	movl	%ecx, %ecx
    158d:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1597:      	btq	%rcx, %rdx
    159b:      	jae	0x15a1 <filter_file_buf+0xc1>
    159d:      	xorq	$0x1, %rax
    15a1:      	popq	%rbx
    15a2:      	retq
    15a3:      	nopw	%cs:(%rax,%rax)

00000000000015b0 <filter_char_buf>:
    15b0:      	pushq	%rbx
    15b1:      	movq	%rsi, %rax
    15b4:      	movq	%rdi, %rbx
    15b7:      	movslq	%edx, %rcx
    15ba:      	movl	-0x4(%rsi,%rcx), %edx
    15be:      	movl	%ecx, %esi
    15c0:      	addq	%rax, %rsi
    15c3:      	movl	0x4(%rdi), %ecx
    15c6:      	xorl	%eax, %eax
    15c8:      	cmpl	$0x19, %ecx
    15cb:      	jg	0x15e1 <filter_char_buf+0x31>
    15cd:      	leal	-0x3(%rcx), %edi
    15d0:      	cmpl	$0x2, %edi
    15d3:      	jb	0x1618 <filter_char_buf+0x68>
    15d5:      	cmpl	$0x8, %ecx
    15d8:      	je	0x160e <filter_char_buf+0x5e>
    15da:      	cmpl	$0x9, %ecx
    15dd:      	je	0x15f0 <filter_char_buf+0x40>
    15df:      	jmp	0x162f <filter_char_buf+0x7f>
    15e1:      	cmpl	$0x20, %ecx
    15e4:      	jg	0x15fa <filter_char_buf+0x4a>
    15e6:      	cmpl	$0x1a, %ecx
    15e9:      	je	0x160e <filter_char_buf+0x5e>
    15eb:      	cmpl	$0x1b, %ecx
    15ee:      	jne	0x162f <filter_char_buf+0x7f>
    15f0:      	movl	0x10(%rbx), %edi
    15f3:      	callq	0x1e80 <filter_char_buf_postfix>
    15f8:      	jmp	0x162c <filter_char_buf+0x7c>
    15fa:      	cmpl	$0x21, %ecx
    15fd:      	je	0x1622 <filter_char_buf+0x72>
    15ff:      	cmpl	$0x22, %ecx
    1602:      	jne	0x162f <filter_char_buf+0x7f>
    1604:      	movq	%rbx, %rdi
    1607:      	movl	$0x1, %ecx
    160c:      	jmp	0x1627 <filter_char_buf+0x77>
    160e:      	movl	0x10(%rbx), %edi
    1611:      	callq	0x1de0 <filter_char_buf_prefix>
    1616:      	jmp	0x162c <filter_char_buf+0x7c>
    1618:      	movq	%rbx, %rdi
    161b:      	callq	0x1a60 <filter_char_buf_equal>
    1620:      	jmp	0x162c <filter_char_buf+0x7c>
    1622:      	movq	%rbx, %rdi
    1625:      	xorl	%ecx, %ecx
    1627:      	callq	0x2080 <filter_char_substring>
    162c:      	movl	0x4(%rbx), %ecx
    162f:      	cmpl	$0x25, %ecx
    1632:      	ja	0x1651 <filter_char_buf+0xa1>
    1634:      	movl	%ecx, %ecx
    1636:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1640:      	btq	%rcx, %rdx
    1644:      	jae	0x1651 <filter_char_buf+0xa1>
    1646:      	xorl	%ecx, %ecx
    1648:      	testq	%rax, %rax
    164b:      	sete	%cl
    164e:      	movq	%rcx, %rax
    1651:      	popq	%rbx
    1652:      	retq
    1653:      	nopw	%cs:(%rax,%rax)

0000000000001660 <filter_inet>:
    1660:      	pushq	%r15
    1662:      	pushq	%r14
    1664:      	pushq	%r12
    1666:      	pushq	%rbx
    1667:      	subq	$0x48, %rsp
    166b:      	movq	$0x0, 0x40(%rsp)
    1674:      	movq	$0x0, 0x38(%rsp)
    167d:      	movq	$0x0, 0x30(%rsp)
    1686:      	movq	$0x0, 0x28(%rsp)
    168f:      	movq	$0x0, 0x20(%rsp)
    1698:      	movl	$0x0, (%rsp)
    169f:      	movl	$0x0, 0x4(%rsp)
    16a7:      	movl	0xc(%rdi), %edx
    16aa:      	xorl	%eax, %eax
    16ac:      	cmpl	$0x27, %edx
    16af:      	jg	0x16c7 <filter_inet+0x67>
    16b1:      	cmpl	$0x5, %edx
    16b4:      	je	0x174c <filter_inet+0xec>
    16ba:      	movq	%rsi, %r8
    16bd:      	cmpl	$0x7, %edx
    16c0:      	je	0x16d8 <filter_inet+0x78>
    16c2:      	jmp	0x195d <filter_inet+0x2fd>
    16c7:      	cmpl	$0x28, %edx
    16ca:      	je	0x1724 <filter_inet+0xc4>
    16cc:      	movq	%rsi, %r8
    16cf:      	cmpl	$0x29, %edx
    16d2:      	jne	0x195d <filter_inet+0x2fd>
    16d8:      	movl	0x4(%rdi), %ecx
    16db:      	xorl	%eax, %eax
    16dd:      	cmpl	$0x13, %ecx
    16e0:      	jle	0x1759 <filter_inet+0xf9>
    16e2:      	cmpl	$0x17, %ecx
    16e5:      	jg	0x1704 <filter_inet+0xa4>
    16e7:      	leal	-0x14(%rcx), %edx
    16ea:      	cmpl	$0x2, %edx
    16ed:      	jb	0x17aa <filter_inet+0x14a>
    16f3:      	leal	-0x16(%rcx), %edx
    16f6:      	cmpl	$0x2, %edx
    16f9:      	jb	0x17a4 <filter_inet+0x144>
    16ff:      	jmp	0x195d <filter_inet+0x2fd>
    1704:      	cmpl	$0x1b, %ecx
    1707:      	jg	0x17e7 <filter_inet+0x187>
    170d:      	cmpl	$0x18, %ecx
    1710:      	je	0x181a <filter_inet+0x1ba>
    1716:      	cmpl	$0x19, %ecx
    1719:      	je	0x1810 <filter_inet+0x1b0>
    171f:      	jmp	0x195d <filter_inet+0x2fd>
    1724:      	movzwl	(%rsi), %eax
    1727:      	movw	%ax, 0x46(%rsp)
    172c:      	movzwl	0x2(%rsi), %eax
    1730:      	movw	%ax, 0x40(%rsp)
    1735:      	movq	0x8(%rsi), %rax
    1739:      	movq	%rax, 0x20(%rsp)
    173e:      	movq	0x10(%rsi), %rax
    1742:      	movq	%rax, 0x28(%rsp)
    1747:      	leaq	0x20(%rsp), %rsi
    174c:      	xorl	%r8d, %r8d
    174f:      	movl	0x4(%rdi), %ecx
    1752:      	xorl	%eax, %eax
    1754:      	cmpl	$0x13, %ecx
    1757:      	jg	0x16e2 <filter_inet+0x82>
    1759:      	cmpl	$0xf, %ecx
    175c:      	jle	0x177a <filter_inet+0x11a>
    175e:      	cmpl	$0x11, %ecx
    1761:      	jg	0x1796 <filter_inet+0x136>
    1763:      	cmpl	$0x10, %ecx
    1766:      	je	0x17a4 <filter_inet+0x144>
    1768:      	cmpl	$0x11, %ecx
    176b:      	jne	0x195d <filter_inet+0x2fd>
    1771:      	movzwl	0x24(%rsi), %eax
    1775:      	jmp	0x1952 <filter_inet+0x2f2>
    177a:      	cmpl	$0xd, %ecx
    177d:      	je	0x181a <filter_inet+0x1ba>
    1783:      	cmpl	$0xe, %ecx
    1786:      	je	0x1810 <filter_inet+0x1b0>
    178c:      	cmpl	$0xf, %ecx
    178f:      	je	0x17aa <filter_inet+0x14a>
    1791:      	jmp	0x195d <filter_inet+0x2fd>
    1796:      	cmpl	$0x12, %ecx
    1799:      	je	0x17aa <filter_inet+0x14a>
    179b:      	cmpl	$0x13, %ecx
    179e:      	jne	0x195d <filter_inet+0x2fd>
    17a4:      	movzwl	0x22(%rsi), %edx
    17a8:      	jmp	0x17ae <filter_inet+0x14e>
    17aa:      	movzwl	0x20(%rsi), %edx
    17ae:      	movl	%edx, 0x4(%rsp)
    17b2:      	xorl	%ebx, %ebx
    17b4:      	xorl	%r15d, %r15d
    17b7:      	xorl	%r14d, %r14d
    17ba:      	xorl	%eax, %eax
    17bc:      	cmpl	$0x11, %ecx
    17bf:      	jg	0x1831 <filter_inet+0x1d1>
    17c1:      	leal	-0xd(%rcx), %edx
    17c4:      	cmpl	$0x2, %edx
    17c7:      	jb	0x1858 <filter_inet+0x1f8>
    17cd:      	leal	-0xf(%rcx), %edx
    17d0:      	cmpl	$0x2, %edx
    17d3:      	jb	0x18ad <filter_inet+0x24d>
    17d9:      	cmpl	$0x11, %ecx
    17dc:      	je	0x1955 <filter_inet+0x2f5>
    17e2:      	jmp	0x195d <filter_inet+0x2fd>
    17e7:      	cmpl	$0x1c, %ecx
    17ea:      	je	0x194e <filter_inet+0x2ee>
    17f0:      	cmpl	$0x1d, %ecx
    17f3:      	jne	0x195d <filter_inet+0x2fd>
    17f9:      	cmpl	$0x7, %edx
    17fc:      	jne	0x1981 <filter_inet+0x321>
    1802:      	testq	%r8, %r8
    1805:      	jne	0x198b <filter_inet+0x32b>
    180b:      	jmp	0x1955 <filter_inet+0x2f5>
    1810:      	movq	0x10(%rsi), %rbx
    1814:      	movq	0x18(%rsi), %r14
    1818:      	jmp	0x1821 <filter_inet+0x1c1>
    181a:      	movq	(%rsi), %rbx
    181d:      	movq	0x8(%rsi), %r14
    1821:      	movq	%rbx, %r15
    1824:      	shrq	$0x20, %r15
    1828:      	xorl	%edx, %edx
    182a:      	xorl	%eax, %eax
    182c:      	cmpl	$0x11, %ecx
    182f:      	jle	0x17c1 <filter_inet+0x161>
    1831:      	cmpl	$0x19, %ecx
    1834:      	ja	0x18a1 <filter_inet+0x241>
    1836:      	movl	$0x500000, %r8d         # imm = 0x500000
    183c:      	btl	%ecx, %r8d
    1840:      	jb	0x18b7 <filter_inet+0x257>
    1842:      	movl	$0xa00000, %r8d         # imm = 0xA00000
    1848:      	btl	%ecx, %r8d
    184c:      	jb	0x18c7 <filter_inet+0x267>
    184e:      	movl	$0x3000000, %edx        # imm = 0x3000000
    1853:      	btl	%ecx, %edx
    1856:      	jae	0x18a1 <filter_inet+0x241>
    1858:      	movzwl	0x26(%rsi), %eax
    185c:      	cmpl	$0xa, %eax
    185f:      	je	0x18d7 <filter_inet+0x277>
    1861:      	cmpl	$0x2, %eax
    1864:      	jne	0x1947 <filter_inet+0x2e7>
    186a:      	movq	%rdi, %r12
    186d:      	movl	0x10(%rdi), %eax
    1870:      	movl	%eax, 0x8(%rsp)
    1874:      	movq	(%rip), %rdi            # 0x187b <filter_inet+0x21b>
    187b:      	leaq	0x8(%rsp), %rsi
    1880:      	movl	$0x1, %eax
    1885:      	callq	*%rax
    1887:      	testq	%rax, %rax
    188a:      	je	0x1969 <filter_inet+0x309>
    1890:      	movq	%rax, %rdi
    1893:      	movl	$0x20, 0xc(%rsp)
    189b:      	movl	%ebx, 0x10(%rsp)
    189f:      	jmp	0x191b <filter_inet+0x2bb>
    18a1:      	addl	$-0x12, %ecx
    18a4:      	cmpl	$0x2, %ecx
    18a7:      	jae	0x195d <filter_inet+0x2fd>
    18ad:      	leaq	0x4(%rsp), %rsi
    18b2:      	jmp	0x1958 <filter_inet+0x2f8>
    18b7:      	xorl	%eax, %eax
    18b9:      	cmpl	$0x400, %edx            # imm = 0x400
    18bf:      	setb	%al
    18c2:      	jmp	0x195d <filter_inet+0x2fd>
    18c7:      	xorl	%eax, %eax
    18c9:      	cmpl	$0x400, %edx            # imm = 0x400
    18cf:      	setae	%al
    18d2:      	jmp	0x195d <filter_inet+0x2fd>
    18d7:      	movq	%rdi, %r12
    18da:      	movl	0x14(%rdi), %eax
    18dd:      	movl	%eax, 0x8(%rsp)
    18e1:      	movq	(%rip), %rdi            # 0x18e8 <filter_inet+0x288>
    18e8:      	leaq	0x8(%rsp), %rsi
    18ed:      	movl	$0x1, %eax
    18f2:      	callq	*%rax
    18f4:      	testq	%rax, %rax
    18f7:      	je	0x1969 <filter_inet+0x309>
    18f9:      	movq	%rax, %rdi
    18fc:      	movl	$0x80, 0xc(%rsp)
    1904:      	movl	%ebx, 0x10(%rsp)
    1908:      	movl	%r15d, 0x14(%rsp)
    190d:      	movl	%r14d, 0x18(%rsp)
    1912:      	shrq	$0x20, %r14
    1916:      	movl	%r14d, 0x1c(%rsp)
    191b:      	leaq	0xc(%rsp), %rsi
    1920:      	movl	$0x1, %eax
    1925:      	callq	*%rax
    1927:      	movl	0x4(%r12), %ecx
    192c:      	leal	-0x18(%rcx), %edx
    192f:      	cmpl	$0x2, %edx
    1932:      	jb	0x1976 <filter_inet+0x316>
    1934:      	addl	$-0xd, %ecx
    1937:      	cmpl	$0x1, %ecx
    193a:      	ja	0x1947 <filter_inet+0x2e7>
    193c:      	testq	%rax, %rax
    193f:      	setne	%al
    1942:      	movzbl	%al, %eax
    1945:      	jmp	0x195d <filter_inet+0x2fd>
    1947:      	xorl	%eax, %eax
    1949:      	movzbl	%al, %eax
    194c:      	jmp	0x195d <filter_inet+0x2fd>
    194e:      	movzwl	0x26(%rsi), %eax
    1952:      	movl	%eax, (%rsp)
    1955:      	movq	%rsp, %rsi
    1958:      	callq	0x9b0 <filter_32ty_map>
    195d:      	addq	$0x48, %rsp
    1961:      	popq	%rbx
    1962:      	popq	%r12
    1964:      	popq	%r14
    1966:      	popq	%r15
    1968:      	retq
    1969:      	movl	0x4(%r12), %eax
    196e:      	andl	$-0x2, %eax
    1971:      	cmpl	$0x18, %eax
    1974:      	jmp	0x1979 <filter_inet+0x319>
    1976:      	testq	%rax, %rax
    1979:      	sete	%al
    197c:      	movzbl	%al, %eax
    197f:      	jmp	0x195d <filter_inet+0x2fd>
    1981:      	cmpl	$0x29, %edx
    1984:      	jne	0x1993 <filter_inet+0x333>
    1986:      	testq	%r8, %r8
    1989:      	je	0x1993 <filter_inet+0x333>
    198b:      	movzbl	0x3a(%r8), %eax
    1990:      	movl	%eax, (%rsp)
    1993:      	cmpl	$0x29, %edx
    1996:      	je	0x1955 <filter_inet+0x2f5>
    1998:      	cmpl	$0x7, %edx
    199b:      	je	0x1955 <filter_inet+0x2f5>
    199d:      	xorl	%eax, %eax
    199f:      	jmp	0x195d <filter_inet+0x2fd>
    19a1:      	nopw	%cs:(%rax,%rax)

00000000000019b0 <filter_sockaddr_un>:
    19b0:      	pushq	%rbx
    19b1:      	subq	$0x10, %rsp
    19b5:      	movq	%rsi, %rcx
    19b8:      	addq	$0x4, %rsi
    19bc:      	movzbl	0x3(%rcx), %edx
    19c0:      	movl	0x4(%rdi), %r8d
    19c4:      	xorl	%eax, %eax
    19c6:      	cmpl	$0x19, %r8d
    19ca:      	jg	0x1a00 <filter_sockaddr_un+0x50>
    19cc:      	leal	-0x3(%r8), %ecx
    19d0:      	cmpl	$0x2, %ecx
    19d3:      	jae	0x1a0e <filter_sockaddr_un+0x5e>
    19d5:      	movq	%rdi, %rbx
    19d8:      	callq	0x1a60 <filter_char_buf_equal>
    19dd:      	movl	0x4(%rbx), %ecx
    19e0:      	cmpq	$0x25, %rcx
    19e4:      	ja	0x19fa <filter_sockaddr_un+0x4a>
    19e6:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    19f0:      	btq	%rcx, %rdx
    19f4:      	jae	0x19fa <filter_sockaddr_un+0x4a>
    19f6:      	xorq	$0x1, %rax
    19fa:      	addq	$0x10, %rsp
    19fe:      	popq	%rbx
    19ff:      	retq
    1a00:      	cmpl	$0x1c, %r8d
    1a04:      	je	0x1a44 <filter_sockaddr_un+0x94>
    1a06:      	cmpl	$0x1a, %r8d
    1a0a:      	je	0x1a14 <filter_sockaddr_un+0x64>
    1a0c:      	jmp	0x19fa <filter_sockaddr_un+0x4a>
    1a0e:      	cmpl	$0x8, %r8d
    1a12:      	jne	0x19fa <filter_sockaddr_un+0x4a>
    1a14:      	movl	0x10(%rdi), %eax
    1a17:      	movq	%rdi, %rbx
    1a1a:      	movl	%eax, %edi
    1a1c:      	callq	0x1de0 <filter_char_buf_prefix>
    1a21:      	movl	0x4(%rbx), %ecx
    1a24:      	cmpq	$0x25, %rcx
    1a28:      	ja	0x19fa <filter_sockaddr_un+0x4a>
    1a2a:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1a34:      	btq	%rcx, %rdx
    1a38:      	jae	0x19fa <filter_sockaddr_un+0x4a>
    1a3a:      	xorq	$0x1, %rax
    1a3e:      	addq	$0x10, %rsp
    1a42:      	popq	%rbx
    1a43:      	retq
    1a44:      	movzwl	(%rcx), %eax
    1a47:      	movl	%eax, 0xc(%rsp)
    1a4b:      	leaq	0xc(%rsp), %rsi
    1a50:      	callq	0x9b0 <filter_32ty_map>
    1a55:      	addq	$0x10, %rsp
    1a59:      	popq	%rbx
    1a5a:      	retq
    1a5b:      	nopl	(%rax,%rax)

0000000000001a60 <filter_char_buf_equal>:
    1a60:      	pushq	%rbp
    1a61:      	pushq	%r15
    1a63:      	pushq	%r14
    1a65:      	pushq	%r13
    1a67:      	pushq	%r12
    1a69:      	pushq	%rbx
    1a6a:      	subq	$0x28, %rsp
    1a6e:      	movl	$0x0, 0x14(%rsp)
    1a76:      	cmpl	$0x1000, %edx           # imm = 0x1000
    1a7c:      	ja	0x1dce <filter_char_buf_equal+0x36e>
    1a82:      	movl	%edx, %ebp
    1a84:      	movzwl	%bp, %eax
    1a87:      	cmpl	$0x90, %eax
    1a8c:      	ja	0x1ad5 <filter_char_buf_equal+0x75>
    1a8e:      	testw	%bp, %bp
    1a91:      	je	0x1aa4 <filter_char_buf_equal+0x44>
    1a93:      	movl	$0x18, %ecx
    1a98:      	movl	%ebp, %eax
    1a9a:      	cltd
    1a9b:      	idivl	%ecx
    1a9d:      	movl	%ebp, %r14d
    1aa0:      	testl	%edx, %edx
    1aa2:      	je	0x1ac4 <filter_char_buf_equal+0x64>
    1aa4:      	movl	$0x18, %ecx
    1aa9:      	movl	%ebp, %eax
    1aab:      	cltd
    1aac:      	idivl	%ecx
    1aae:      	shll	$0x3, %eax
    1ab1:      	leal	(%rax,%rax,2), %eax
    1ab4:      	addl	$0x18, %eax
    1ab7:      	movzwl	%ax, %r14d
    1abb:      	cmpl	$0x90, %r14d
    1ac2:      	ja	0x1b13 <filter_char_buf_equal+0xb3>
    1ac4:      	movl	%r14d, %eax
    1ac7:      	cltd
    1ac8:      	idivl	%ecx
    1aca:      	movl	%eax, %r15d
    1acd:      	decl	%r15d
    1ad0:      	jmp	0x1b5e <filter_char_buf_equal+0xfe>
    1ad5:      	movl	$0x100, %r14d           # imm = 0x100
    1adb:      	cmpl	$0x101, %eax            # imm = 0x101
    1ae0:      	jb	0x1b13 <filter_char_buf_equal+0xb3>
    1ae2:      	movl	$0x200, %r14d           # imm = 0x200
    1ae8:      	cmpl	$0x201, %eax            # imm = 0x201
    1aed:      	jb	0x1b13 <filter_char_buf_equal+0xb3>
    1aef:      	movl	$0x400, %r14d           # imm = 0x400
    1af5:      	cmpl	$0x401, %eax            # imm = 0x401
    1afa:      	jb	0x1b13 <filter_char_buf_equal+0xb3>
    1afc:      	xorl	%r14d, %r14d
    1aff:      	cmpl	$0x801, %eax            # imm = 0x801
    1b04:      	setae	%r14b
    1b08:      	shll	$0xb, %r14d
    1b0c:      	addl	$0x800, %r14d           # imm = 0x800
    1b13:      	leal	-0x100(%r14), %eax
    1b1a:      	rorxl	$0x8, %eax, %eax
    1b20:      	cmpl	$0x2, %eax
    1b23:      	jg	0x1b36 <filter_char_buf_equal+0xd6>
    1b25:      	testl	%eax, %eax
    1b27:      	je	0x1b50 <filter_char_buf_equal+0xf0>
    1b29:      	cmpl	$0x1, %eax
    1b2c:      	jne	0x1b48 <filter_char_buf_equal+0xe8>
    1b2e:      	movl	$0x7, %r15d
    1b34:      	jmp	0x1b5e <filter_char_buf_equal+0xfe>
    1b36:      	cmpl	$0x3, %eax
    1b39:      	je	0x1b58 <filter_char_buf_equal+0xf8>
    1b3b:      	cmpl	$0x7, %eax
    1b3e:      	jne	0x1b48 <filter_char_buf_equal+0xe8>
    1b40:      	movl	$0x9, %r15d
    1b46:      	jmp	0x1b5e <filter_char_buf_equal+0xfe>
    1b48:      	movl	$0xa, %r15d
    1b4e:      	jmp	0x1b5e <filter_char_buf_equal+0xfe>
    1b50:      	movl	$0x6, %r15d
    1b56:      	jmp	0x1b5e <filter_char_buf_equal+0xfe>
    1b58:      	movl	$0x8, %r15d
    1b5e:      	movl	%r15d, %eax
    1b61:      	andl	$0xf, %eax
    1b64:      	movl	0x10(%rdi,%rax,4), %r13d
    1b69:      	cmpl	$-0x1, %r13d
    1b6d:      	je	0x1dce <filter_char_buf_equal+0x36e>
    1b73:      	movq	%rsi, 0x20(%rsp)
    1b78:      	movq	(%rip), %rdi            # 0x1b7f <filter_char_buf_equal+0x11f>
    1b7f:      	leaq	0x14(%rsp), %r12
    1b84:      	movl	$0x1, %eax
    1b89:      	movq	%r12, %rsi
    1b8c:      	callq	*%rax
    1b8e:      	movq	%rax, %rbx
    1b91:      	movq	(%rip), %rdi            # 0x1b98 <filter_char_buf_equal+0x138>
    1b98:      	movl	$0x1, %eax
    1b9d:      	movq	%r12, %rsi
    1ba0:      	callq	*%rax
    1ba2:      	movq	%rax, %rcx
    1ba5:      	xorl	%eax, %eax
    1ba7:      	movq	%rbx, 0x8(%rsp)
    1bac:      	testq	%rbx, %rbx
    1baf:      	je	0x1dd0 <filter_char_buf_equal+0x370>
    1bb5:      	testq	%rcx, %rcx
    1bb8:      	je	0x1dd0 <filter_char_buf_equal+0x370>
    1bbe:      	movq	%rcx, 0x18(%rsp)
    1bc3:      	cmpl	$0x5, %r15d
    1bc7:      	jg	0x1c0a <filter_char_buf_equal+0x1aa>
    1bc9:      	movq	0x8(%rsp), %rax
    1bce:      	movb	%bpl, (%rax)
    1bd1:      	leaq	0x1(%rax), %rdi
    1bd5:      	movl	%ebp, %r12d
    1bd8:      	movl	$0x4, %eax
    1bdd:      	movq	0x20(%rsp), %rdx
    1be2:      	movl	%ebp, %esi
    1be4:      	callq	*%rax
    1be6:      	subl	%ebp, %r14d
    1be9:      	jbe	0x1c4f <filter_char_buf_equal+0x1ef>
    1beb:      	movq	0x8(%rsp), %rax
    1bf0:      	leaq	(%rax,%r12), %rdi
    1bf4:      	incq	%rdi
    1bf7:      	andl	$0xfff, %r14d           # imm = 0xFFF
    1bfe:      	movl	$0x4, %eax
    1c03:      	movq	0x18(%rsp), %rdx
    1c08:      	jmp	0x1c4a <filter_char_buf_equal+0x1ea>
    1c0a:      	movq	0x8(%rsp), %rax
    1c0f:      	movw	%bp, (%rax)
    1c12:      	leaq	0x2(%rax), %rdi
    1c16:      	movl	%ebp, %r12d
    1c19:      	movl	$0x4, %eax
    1c1e:      	movq	0x20(%rsp), %rdx
    1c23:      	movl	%ebp, %esi
    1c25:      	callq	*%rax
    1c27:      	subl	%ebp, %r14d
    1c2a:      	jbe	0x1c4f <filter_char_buf_equal+0x1ef>
    1c2c:      	movq	0x8(%rsp), %rax
    1c31:      	leaq	(%rax,%r12), %rdi
    1c35:      	addq	$0x2, %rdi
    1c39:      	andl	$0xfff, %r14d           # imm = 0xFFF
    1c40:      	movl	$0x4, %eax
    1c45:      	movq	0x18(%rsp), %rdx
    1c4a:      	movl	%r14d, %esi
    1c4d:      	callq	*%rax
    1c4f:      	movl	%r13d, 0x4(%rsp)
    1c54:      	cmpl	$0x4, %r15d
    1c58:      	jle	0x1c94 <filter_char_buf_equal+0x234>
    1c5a:      	cmpl	$0x7, %r15d
    1c5e:      	jg	0x1cce <filter_char_buf_equal+0x26e>
    1c60:      	cmpl	$0x5, %r15d
    1c64:      	je	0x1d82 <filter_char_buf_equal+0x322>
    1c6a:      	cmpl	$0x6, %r15d
    1c6e:      	je	0x1d49 <filter_char_buf_equal+0x2e9>
    1c74:      	cmpl	$0x7, %r15d
    1c78:      	jne	0x1dce <filter_char_buf_equal+0x36e>
    1c7e:      	movq	(%rip), %rdi            # 0x1c85 <filter_char_buf_equal+0x225>
    1c85:      	leaq	0x4(%rsp), %rcx
    1c8a:      	movl	$0x1, %eax
    1c8f:      	jmp	0x1da6 <filter_char_buf_equal+0x346>
    1c94:      	cmpl	$0x1, %r15d
    1c98:      	jle	0x1cfe <filter_char_buf_equal+0x29e>
    1c9a:      	cmpl	$0x2, %r15d
    1c9e:      	je	0x1d6f <filter_char_buf_equal+0x30f>
    1ca4:      	cmpl	$0x3, %r15d
    1ca8:      	je	0x1d36 <filter_char_buf_equal+0x2d6>
    1cae:      	cmpl	$0x4, %r15d
    1cb2:      	jne	0x1dce <filter_char_buf_equal+0x36e>
    1cb8:      	movq	(%rip), %rdi            # 0x1cbf <filter_char_buf_equal+0x25f>
    1cbf:      	leaq	0x4(%rsp), %rcx
    1cc4:      	movl	$0x1, %eax
    1cc9:      	jmp	0x1da6 <filter_char_buf_equal+0x346>
    1cce:      	cmpl	$0x8, %r15d
    1cd2:      	je	0x1d95 <filter_char_buf_equal+0x335>
    1cd8:      	cmpl	$0x9, %r15d
    1cdc:      	je	0x1d5c <filter_char_buf_equal+0x2fc>
    1cde:      	cmpl	$0xa, %r15d
    1ce2:      	jne	0x1dce <filter_char_buf_equal+0x36e>
    1ce8:      	movq	(%rip), %rdi            # 0x1cef <filter_char_buf_equal+0x28f>
    1cef:      	leaq	0x4(%rsp), %rcx
    1cf4:      	movl	$0x1, %eax
    1cf9:      	jmp	0x1da6 <filter_char_buf_equal+0x346>
    1cfe:      	testl	%r15d, %r15d
    1d01:      	je	0x1d23 <filter_char_buf_equal+0x2c3>
    1d03:      	cmpl	$0x1, %r15d
    1d07:      	jne	0x1dce <filter_char_buf_equal+0x36e>
    1d0d:      	movq	(%rip), %rdi            # 0x1d14 <filter_char_buf_equal+0x2b4>
    1d14:      	leaq	0x4(%rsp), %rcx
    1d19:      	movl	$0x1, %eax
    1d1e:      	jmp	0x1da6 <filter_char_buf_equal+0x346>
    1d23:      	movq	(%rip), %rdi            # 0x1d2a <filter_char_buf_equal+0x2ca>
    1d2a:      	leaq	0x4(%rsp), %rcx
    1d2f:      	movl	$0x1, %eax
    1d34:      	jmp	0x1da6 <filter_char_buf_equal+0x346>
    1d36:      	movq	(%rip), %rdi            # 0x1d3d <filter_char_buf_equal+0x2dd>
    1d3d:      	leaq	0x4(%rsp), %rcx
    1d42:      	movl	$0x1, %eax
    1d47:      	jmp	0x1da6 <filter_char_buf_equal+0x346>
    1d49:      	movq	(%rip), %rdi            # 0x1d50 <filter_char_buf_equal+0x2f0>
    1d50:      	leaq	0x4(%rsp), %rcx
    1d55:      	movl	$0x1, %eax
    1d5a:      	jmp	0x1da6 <filter_char_buf_equal+0x346>
    1d5c:      	movq	(%rip), %rdi            # 0x1d63 <filter_char_buf_equal+0x303>
    1d63:      	leaq	0x4(%rsp), %rcx
    1d68:      	movl	$0x1, %eax
    1d6d:      	jmp	0x1da6 <filter_char_buf_equal+0x346>
    1d6f:      	movq	(%rip), %rdi            # 0x1d76 <filter_char_buf_equal+0x316>
    1d76:      	leaq	0x4(%rsp), %rcx
    1d7b:      	movl	$0x1, %eax
    1d80:      	jmp	0x1da6 <filter_char_buf_equal+0x346>
    1d82:      	movq	(%rip), %rdi            # 0x1d89 <filter_char_buf_equal+0x329>
    1d89:      	leaq	0x4(%rsp), %rcx
    1d8e:      	movl	$0x1, %eax
    1d93:      	jmp	0x1da6 <filter_char_buf_equal+0x346>
    1d95:      	movq	(%rip), %rdi            # 0x1d9c <filter_char_buf_equal+0x33c>
    1d9c:      	leaq	0x4(%rsp), %rcx
    1da1:      	movl	$0x1, %eax
    1da6:      	leaq	0x4(%rsp), %rsi
    1dab:      	callq	*%rax
    1dad:      	testq	%rax, %rax
    1db0:      	je	0x1dce <filter_char_buf_equal+0x36e>
    1db2:      	movq	%rax, %rdi
    1db5:      	movl	$0x1, %eax
    1dba:      	movq	0x8(%rsp), %rsi
    1dbf:      	callq	*%rax
    1dc1:      	movq	%rax, %rcx
    1dc4:      	xorl	%eax, %eax
    1dc6:      	testq	%rcx, %rcx
    1dc9:      	setne	%al
    1dcc:      	jmp	0x1dd0 <filter_char_buf_equal+0x370>
    1dce:      	xorl	%eax, %eax
    1dd0:      	addq	$0x28, %rsp
    1dd4:      	popq	%rbx
    1dd5:      	popq	%r12
    1dd7:      	popq	%r13
    1dd9:      	popq	%r14
    1ddb:      	popq	%r15
    1ddd:      	popq	%rbp
    1dde:      	retq
    1ddf:      	nop

0000000000001de0 <filter_char_buf_prefix>:
    1de0:      	pushq	%rbp
    1de1:      	pushq	%r15
    1de3:      	pushq	%r14
    1de5:      	pushq	%rbx
    1de6:      	pushq	%rax
    1de7:      	movl	%edx, %ebp
    1de9:      	movq	%rsi, %rbx
    1dec:      	movl	%edi, 0x4(%rsp)
    1df0:      	movl	$0x0, (%rsp)
    1df7:      	movq	(%rip), %rdi            # 0x1dfe <filter_char_buf_prefix+0x1e>
    1dfe:      	leaq	0x4(%rsp), %rsi
    1e03:      	movl	$0x1, %eax
    1e08:      	callq	*%rax
    1e0a:      	movq	%rax, %r14
    1e0d:      	xorl	%eax, %eax
    1e0f:      	testl	%ebp, %ebp
    1e11:      	je	0x1e75 <filter_char_buf_prefix+0x95>
    1e13:      	testq	%r14, %r14
    1e16:      	je	0x1e75 <filter_char_buf_prefix+0x95>
    1e18:      	movq	(%rip), %rdi            # 0x1e1f <filter_char_buf_prefix+0x3f>
    1e1f:      	movq	%rsp, %rsi
    1e22:      	movl	$0x1, %eax
    1e27:      	callq	*%rax
    1e29:      	testq	%rax, %rax
    1e2c:      	je	0x1e73 <filter_char_buf_prefix+0x93>
    1e2e:      	cmpl	$0xff, %ebp
    1e34:      	movl	$0xff, %esi
    1e39:      	cmovbl	%ebp, %esi
    1e3c:      	leal	(,%rsi,8), %ecx
    1e43:      	movl	%ecx, (%rax)
    1e45:      	movq	%rax, %rdi
    1e48:      	addq	$0x4, %rdi
    1e4c:      	movq	%rax, %r15
    1e4f:      	movl	$0x4, %eax
    1e54:      	movq	%rbx, %rdx
    1e57:      	callq	*%rax
    1e59:      	movl	$0x1, %eax
    1e5e:      	movq	%r14, %rdi
    1e61:      	movq	%r15, %rsi
    1e64:      	callq	*%rax
    1e66:      	movq	%rax, %rcx
    1e69:      	xorl	%eax, %eax
    1e6b:      	testq	%rcx, %rcx
    1e6e:      	setne	%al
    1e71:      	jmp	0x1e75 <filter_char_buf_prefix+0x95>
    1e73:      	xorl	%eax, %eax
    1e75:      	addq	$0x8, %rsp
    1e79:      	popq	%rbx
    1e7a:      	popq	%r14
    1e7c:      	popq	%r15
    1e7e:      	popq	%rbp
    1e7f:      	retq

0000000000001e80 <filter_char_buf_postfix>:
    1e80:      	pushq	%r15
    1e82:      	pushq	%r14
    1e84:      	pushq	%rbx
    1e85:      	subq	$0x10, %rsp
    1e89:      	movl	%edx, %ebx
    1e8b:      	movq	%rsi, %r14
    1e8e:      	movl	%edi, 0xc(%rsp)
    1e92:      	movl	$0x0, 0x8(%rsp)
    1e9a:      	movq	(%rip), %rdi            # 0x1ea1 <filter_char_buf_postfix+0x21>
    1ea1:      	leaq	0xc(%rsp), %rsi
    1ea6:      	movl	$0x1, %eax
    1eab:      	callq	*%rax
    1ead:      	movq	%rax, %r15
    1eb0:      	xorl	%eax, %eax
    1eb2:      	testl	%ebx, %ebx
    1eb4:      	je	0x1fc0 <filter_char_buf_postfix+0x140>
    1eba:      	testq	%r15, %r15
    1ebd:      	je	0x1fc0 <filter_char_buf_postfix+0x140>
    1ec3:      	movq	(%rip), %rdi            # 0x1eca <filter_char_buf_postfix+0x4a>
    1eca:      	leaq	0x8(%rsp), %rsi
    1ecf:      	movl	$0x1, %eax
    1ed4:      	callq	*%rax
    1ed6:      	testq	%rax, %rax
    1ed9:      	je	0x1fbe <filter_char_buf_postfix+0x13e>
    1edf:      	movq	%rax, %rsi
    1ee2:      	cmpl	$0x7f, %ebx
    1ee5:      	movl	$0x7f, %eax
    1eea:      	cmovbl	%ebx, %eax
    1eed:      	shll	$0x3, %eax
    1ef0:      	movl	%eax, (%rsi)
    1ef2:      	movl	%ebx, %eax
    1ef4:      	leal	-0x4(%rbx), %ecx
    1ef7:      	movq	%rsi, %rdx
    1efa:      	addq	$0x7, %rdx
    1efe:      	leal	-0x3(%rbx), %edi
    1f01:      	leal	-0x2(%rbx), %r8d
    1f05:      	decl	%ebx
    1f07:      	movq	$-0x3, %r9
    1f0e:      	nop
    1f10:      	leal	(%rbx,%r9), %r10d
    1f14:      	addl	$0x3, %r10d
    1f18:      	andl	$0xfff, %r10d           # imm = 0xFFF
    1f1f:      	movzbl	(%r14,%r10), %r10d
    1f24:      	movb	%r10b, -0x3(%rdx)
    1f28:      	leaq	(%rax,%r9), %r10
    1f2c:      	cmpq	$-0x2, %r10
    1f30:      	je	0x1fa7 <filter_char_buf_postfix+0x127>
    1f32:      	leal	(%r8,%r9), %r11d
    1f36:      	addl	$0x3, %r11d
    1f3a:      	andl	$0xfff, %r11d           # imm = 0xFFF
    1f41:      	movzbl	(%r14,%r11), %r11d
    1f46:      	movb	%r11b, -0x2(%rdx)
    1f4a:      	cmpq	$-0x1, %r10
    1f4e:      	je	0x1fa7 <filter_char_buf_postfix+0x127>
    1f50:      	leal	(%rdi,%r9), %r10d
    1f54:      	addl	$0x3, %r10d
    1f58:      	andl	$0xfff, %r10d           # imm = 0xFFF
    1f5f:      	movzbl	(%r14,%r10), %r10d
    1f64:      	movb	%r10b, -0x1(%rdx)
    1f68:      	movq	%rax, %r10
    1f6b:      	addq	%r9, %r10
    1f6e:      	je	0x1fa7 <filter_char_buf_postfix+0x127>
    1f70:      	cmpq	$-0x7f, %r9
    1f74:      	je	0x1fa7 <filter_char_buf_postfix+0x127>
    1f76:      	leal	(%rcx,%r9), %r10d
    1f7a:      	addl	$0x3, %r10d
    1f7e:      	andl	$0xfff, %r10d           # imm = 0xFFF
    1f85:      	movzbl	(%r14,%r10), %r10d
    1f8a:      	movb	%r10b, (%rdx)
    1f8d:      	addq	$0x4, %rdx
    1f91:      	leaq	(%rax,%r9), %r10
    1f95:      	addq	$-0x4, %r10
    1f99:      	addq	$-0x4, %r9
    1f9d:      	cmpq	$-0x3, %r10
    1fa1:      	jne	0x1f10 <filter_char_buf_postfix+0x90>
    1fa7:      	movl	$0x1, %eax
    1fac:      	movq	%r15, %rdi
    1faf:      	callq	*%rax
    1fb1:      	movq	%rax, %rcx
    1fb4:      	xorl	%eax, %eax
    1fb6:      	testq	%rcx, %rcx
    1fb9:      	setne	%al
    1fbc:      	jmp	0x1fc0 <filter_char_buf_postfix+0x140>
    1fbe:      	xorl	%eax, %eax
    1fc0:      	addq	$0x10, %rsp
    1fc4:      	popq	%rbx
    1fc5:      	popq	%r14
    1fc7:      	popq	%r15
    1fc9:      	retq
    1fca:      	nopw	(%rax,%rax)

0000000000001fd0 <filter_file_type>:
    1fd0:      	pushq	%rbx
    1fd1:      	subq	$0x10, %rsp
    1fd5:      	movw	$0x0, 0xe(%rsp)
    1fdc:      	movl	(%rsi), %eax
    1fde:      	cmpq	$0x1000, %rax           # imm = 0x1000
    1fe4:      	ja	0x206c <filter_file_type+0x9c>
    1fea:      	movq	%rdi, %rbx
    1fed:      	leaq	(%rsi,%rax), %rcx
    1ff1:      	addq	$0x8, %rcx
    1ff5:      	leaq	0xe(%rsp), %rdi
    1ffa:      	movl	$0x2, %edx
    1fff:      	movl	$0x4, %eax
    2004:      	movl	(%rsi), %ecx
    2006:      	leaq	(%rsi,%rcx), %rdx
    200a:      	addq	$0x8, %rdx
    200e:      	movl	$0x2, %esi
    2013:      	callq	*%rax
    2015:      	movl	0x10(%rbx), %edx
    2018:      	testl	%edx, %edx
    201a:      	je	0x206c <filter_file_type+0x9c>
    201c:      	movzwl	0xe(%rsp), %ecx
    2021:      	andl	$0xf000, %ecx           # imm = 0xF000
    2027:      	movl	$0x1, %eax
    202c:      	cmpl	%ecx, %edx
    202e:      	je	0x206e <filter_file_type+0x9e>
    2030:      	movl	0x8(%rbx), %edx
    2033:      	cmpl	$0xc, %edx
    2036:      	jbe	0x206c <filter_file_type+0x9c>
    2038:      	movl	0x14(%rbx), %esi
    203b:      	testl	%esi, %esi
    203d:      	je	0x206c <filter_file_type+0x9c>
    203f:      	cmpl	%ecx, %esi
    2041:      	je	0x206e <filter_file_type+0x9e>
    2043:      	cmpl	$0x11, %edx
    2046:      	jb	0x206c <filter_file_type+0x9c>
    2048:      	movl	0x18(%rbx), %esi
    204b:      	testl	%esi, %esi
    204d:      	je	0x206c <filter_file_type+0x9c>
    204f:      	cmpl	%ecx, %esi
    2051:      	je	0x206e <filter_file_type+0x9e>
    2053:      	cmpl	$0x15, %edx
    2056:      	jb	0x206c <filter_file_type+0x9c>
    2058:      	movl	0x1c(%rbx), %edx
    205b:      	testl	%edx, %edx
    205d:      	je	0x206c <filter_file_type+0x9c>
    205f:      	xorl	%eax, %eax
    2061:      	cmpl	%ecx, %edx
    2063:      	sete	%al
    2066:      	addq	$0x10, %rsp
    206a:      	popq	%rbx
    206b:      	retq
    206c:      	xorl	%eax, %eax
    206e:      	addq	$0x10, %rsp
    2072:      	popq	%rbx
    2073:      	retq
    2074:      	nopw	%cs:(%rax,%rax)

0000000000002080 <filter_char_substring>:
    2080:      	pushq	%rbp
    2081:      	pushq	%r15
    2083:      	pushq	%r14
    2085:      	pushq	%r13
    2087:      	pushq	%r12
    2089:      	pushq	%rbx
    208a:      	pushq	%rax
    208b:      	movq	%rsi, %r15
    208e:      	movq	%rdi, %r14
    2091:      	movl	%edx, %ebp
    2093:      	testl	%ecx, %ecx
    2095:      	je	0x216d <filter_char_substring+0xed>
    209b:      	testl	%edx, %edx
    209d:      	je	0x221d <filter_char_substring+0x19d>
    20a3:      	leaq	0x4(%rsp), %r13
    20a8:      	xorl	%ebx, %ebx
    20aa:      	xorl	%r12d, %r12d
    20ad:      	nopl	(%rax)
    20b0:      	movl	0x10(%r14,%rbx,4), %eax
    20b5:      	movl	%eax, 0x4(%rsp)
    20b9:      	movl	$0x1, %eax
    20be:      	movq	(%rip), %rdi            # 0x20c5 <filter_char_substring+0x45>
    20c5:      	movq	%r13, %rsi
    20c8:      	callq	*%rax
    20ca:      	testq	%rax, %rax
    20cd:      	je	0x22b0 <filter_char_substring+0x230>
    20d3:      	movq	%r15, %rdx
    20d6:      	xorl	%ecx, %ecx
    20d8:      	jmp	0x20eb <filter_char_substring+0x6b>
    20da:      	nopw	(%rax,%rax)
    20e0:      	incq	%rcx
    20e3:      	incq	%rdx
    20e6:      	cmpq	%rbp, %rcx
    20e9:      	je	0x2148 <filter_char_substring+0xc8>
    20eb:      	xorl	%esi, %esi
    20ed:      	nopl	(%rax)
    20f0:      	leaq	(%rcx,%rsi), %rdi
    20f4:      	cmpq	%rbp, %rdi
    20f7:      	jae	0x20e0 <filter_char_substring+0x60>
    20f9:      	movsbl	(%rax,%rsi), %edi
    20fd:      	testl	%edi, %edi
    20ff:      	je	0x2140 <filter_char_substring+0xc0>
    2101:      	movsbl	(%rdx,%rsi), %r9d
    2106:      	leal	-0x41(%r9), %r10d
    210a:      	movl	%r9d, %r8d
    210d:      	orl	$0x20, %r8d
    2111:      	cmpl	$0x1a, %r10d
    2115:      	cmovael	%r9d, %r8d
    2119:      	leal	-0x41(%rdi), %r10d
    211d:      	movl	%edi, %r9d
    2120:      	orl	$0x20, %r9d
    2124:      	cmpl	$0x1a, %r10d
    2128:      	cmovael	%edi, %r9d
    212c:      	cmpq	$0x62, %rsi
    2130:      	ja	0x20e0 <filter_char_substring+0x60>
    2132:      	incq	%rsi
    2135:      	cmpl	%r9d, %r8d
    2138:      	je	0x20f0 <filter_char_substring+0x70>
    213a:      	jmp	0x20e0 <filter_char_substring+0x60>
    213c:      	nopl	(%rax)
    2140:      	testl	%ecx, %ecx
    2142:      	jns	0x22c1 <filter_char_substring+0x241>
    2148:      	leal	0xc(%r12), %eax
    214d:      	cmpl	0x8(%r14), %eax
    2151:      	jae	0x22b0 <filter_char_substring+0x230>
    2157:      	addl	$0x4, %r12d
    215b:      	incq	%rbx
    215e:      	cmpq	$0x64, %rbx
    2162:      	jne	0x20b0 <filter_char_substring+0x30>
    2168:      	jmp	0x22b0 <filter_char_substring+0x230>
    216d:      	testl	%edx, %edx
    216f:      	je	0x2262 <filter_char_substring+0x1e2>
    2175:      	leaq	0x4(%rsp), %r13
    217a:      	xorl	%ebx, %ebx
    217c:      	xorl	%r12d, %r12d
    217f:      	nop
    2180:      	movl	0x10(%r14,%rbx,4), %eax
    2185:      	movl	%eax, 0x4(%rsp)
    2189:      	movl	$0x1, %eax
    218e:      	movq	(%rip), %rdi            # 0x2195 <filter_char_substring+0x115>
    2195:      	movq	%r13, %rsi
    2198:      	callq	*%rax
    219a:      	testq	%rax, %rax
    219d:      	je	0x22b0 <filter_char_substring+0x230>
    21a3:      	movq	%r15, %rdx
    21a6:      	xorl	%ecx, %ecx
    21a8:      	jmp	0x21bb <filter_char_substring+0x13b>
    21aa:      	nopw	(%rax,%rax)
    21b0:      	incq	%rcx
    21b3:      	incq	%rdx
    21b6:      	cmpq	%rbp, %rcx
    21b9:      	je	0x21f8 <filter_char_substring+0x178>
    21bb:      	xorl	%esi, %esi
    21bd:      	nopl	(%rax)
    21c0:      	leaq	(%rcx,%rsi), %rdi
    21c4:      	cmpq	%rbp, %rdi
    21c7:      	jae	0x21b0 <filter_char_substring+0x130>
    21c9:      	movzbl	(%rax,%rsi), %edi
    21cd:      	testb	%dil, %dil
    21d0:      	je	0x21f0 <filter_char_substring+0x170>
    21d2:      	cmpq	$0x62, %rsi
    21d6:      	ja	0x21b0 <filter_char_substring+0x130>
    21d8:      	leaq	0x1(%rsi), %r8
    21dc:      	cmpb	%dil, (%rdx,%rsi)
    21e0:      	movq	%r8, %rsi
    21e3:      	je	0x21c0 <filter_char_substring+0x140>
    21e5:      	jmp	0x21b0 <filter_char_substring+0x130>
    21e7:      	nopw	(%rax,%rax)
    21f0:      	testl	%ecx, %ecx
    21f2:      	jns	0x22c1 <filter_char_substring+0x241>
    21f8:      	leal	0xc(%r12), %eax
    21fd:      	cmpl	0x8(%r14), %eax
    2201:      	jae	0x22b0 <filter_char_substring+0x230>
    2207:      	addl	$0x4, %r12d
    220b:      	incq	%rbx
    220e:      	cmpq	$0x64, %rbx
    2212:      	jne	0x2180 <filter_char_substring+0x100>
    2218:      	jmp	0x22b0 <filter_char_substring+0x230>
    221d:      	movl	$0x10, %ebx
    2222:      	movq	(%rip), %r15            # 0x2229 <filter_char_substring+0x1a9>
    2229:      	leaq	0x4(%rsp), %r12
    222e:      	nop
    2230:      	movl	(%r14,%rbx), %eax
    2234:      	movl	%eax, 0x4(%rsp)
    2238:      	movl	$0x1, %eax
    223d:      	movq	%r15, %rdi
    2240:      	movq	%r12, %rsi
    2243:      	callq	*%rax
    2245:      	testq	%rax, %rax
    2248:      	je	0x22b0 <filter_char_substring+0x230>
    224a:      	addq	$0x4, %rbx
    224e:      	leal	-0x8(%rbx), %eax
    2251:      	cmpl	0x8(%r14), %eax
    2255:      	jae	0x22b0 <filter_char_substring+0x230>
    2257:      	cmpq	$0x1a0, %rbx            # imm = 0x1A0
    225e:      	jne	0x2230 <filter_char_substring+0x1b0>
    2260:      	jmp	0x22b0 <filter_char_substring+0x230>
    2262:      	movl	$0x10, %ebx
    2267:      	movq	(%rip), %r15            # 0x226e <filter_char_substring+0x1ee>
    226e:      	leaq	0x4(%rsp), %r12
    2273:      	nopw	%cs:(%rax,%rax)
    2280:      	movl	(%r14,%rbx), %eax
    2284:      	movl	%eax, 0x4(%rsp)
    2288:      	movl	$0x1, %eax
    228d:      	movq	%r15, %rdi
    2290:      	movq	%r12, %rsi
    2293:      	callq	*%rax
    2295:      	testq	%rax, %rax
    2298:      	je	0x22b0 <filter_char_substring+0x230>
    229a:      	addq	$0x4, %rbx
    229e:      	leal	-0x8(%rbx), %eax
    22a1:      	cmpl	0x8(%r14), %eax
    22a5:      	jae	0x22b0 <filter_char_substring+0x230>
    22a7:      	cmpq	$0x1a0, %rbx            # imm = 0x1A0
    22ae:      	jne	0x2280 <filter_char_substring+0x200>
    22b0:      	xorl	%eax, %eax
    22b2:      	addq	$0x8, %rsp
    22b6:      	popq	%rbx
    22b7:      	popq	%r12
    22b9:      	popq	%r13
    22bb:      	popq	%r14
    22bd:      	popq	%r15
    22bf:      	popq	%rbp
    22c0:      	retq
    22c1:      	movl	$0x1, %eax
    22c6:      	jmp	0x22b2 <filter_char_substring+0x232>
    22c8:      	nopl	(%rax,%rax)

00000000000022d0 <do_action>:
    22d0:      	pushq	%rbp
    22d1:      	pushq	%r15
    22d3:      	pushq	%r14
    22d5:      	pushq	%r13
    22d7:      	pushq	%r12
    22d9:      	pushq	%rbx
    22da:      	subq	$0x78, %rsp
    22de:      	movl	%r8d, %ebp
    22e1:      	movq	%rcx, 0x38(%rsp)
    22e6:      	movq	%rdx, %r15
    22e9:      	movl	%esi, %ebx
    22eb:      	movq	%rdi, %r12
    22ee:      	movl	%esi, %eax
    22f0:      	movslq	0x4(%rdx,%rax,4), %r14
    22f5:      	movl	$0x0, 0x54(%rsp)
    22fd:      	movq	(%rip), %rdi            # 0x2304 <do_action+0x34>
    2304:      	leaq	0x54(%rsp), %rsi
    2309:      	movl	$0x1, %eax
    230e:      	callq	*%rax
    2310:      	movq	%rax, %r13
    2313:      	xorl	%eax, %eax
    2315:      	testq	%r13, %r13
    2318:      	je	0x2be8 <do_action+0x918>
    231e:      	cmpl	$0x7, %r14d
    2322:      	jg	0x234c <do_action+0x7c>
    2324:      	cmpl	$0x3, %r14d
    2328:      	jg	0x2383 <do_action+0xb3>
    232a:      	cmpl	$0x1, %r14d
    232e:      	jg	0x24b5 <do_action+0x1e5>
    2334:      	testl	%r14d, %r14d
    2337:      	je	0x27e6 <do_action+0x516>
    233d:      	cmpl	$0x1, %r14d
    2341:      	je	0x24ce <do_action+0x1fe>
    2347:      	jmp	0x2be0 <do_action+0x910>
    234c:      	cmpl	$0xb, %r14d
    2350:      	jg	0x2487 <do_action+0x1b7>
    2356:      	leal	-0xa(%r14), %ecx
    235a:      	cmpl	$0x2, %ecx
    235d:      	jb	0x25d9 <do_action+0x309>
    2363:      	cmpl	$0x8, %r14d
    2367:      	je	0x26c6 <do_action+0x3f6>
    236d:      	cmpl	$0x9, %r14d
    2371:      	jne	0x2be0 <do_action+0x910>
    2377:      	incl	%ebx
    2379:      	movl	0x4(%r15,%rbx,4), %eax
    237e:      	jmp	0x2692 <do_action+0x3c2>
    2383:      	leal	-0x6(%r14), %eax
    2387:      	cmpl	$0x2, %eax
    238a:      	jb	0x26b6 <do_action+0x3e6>
    2390:      	cmpl	$0x4, %r14d
    2394:      	je	0x26d3 <do_action+0x403>
    239a:      	cmpl	$0x5, %r14d
    239e:      	jne	0x2be0 <do_action+0x910>
    23a4:      	leal	0x1(%rbx), %eax
    23a7:      	movl	0x4(%r15,%rax,4), %eax
    23ac:      	addl	$0x2, %ebx
    23af:      	andl	$0x7, %eax
    23b2:      	cmpl	$0x4, %eax
    23b5:      	ja	0x2be0 <do_action+0x910>
    23bb:      	cmpl	$0x0, 0x5ea0(%r13,%rax,4)
    23c4:      	jne	0x2be0 <do_action+0x910>
    23ca:      	movl	0x4(%r15,%rbx,4), %r15d
    23cf:      	movq	0x5e78(%r13,%rax,8), %rax
    23d7:      	movl	$0x0, 0xc(%rsp)
    23df:      	andl	$0x7ff, %eax            # imm = 0x7FF
    23e4:      	movl	0x90(%r13,%rax), %eax
    23ec:      	movl	%eax, 0x8(%rsp)
    23f0:      	movl	$0xe, %eax
    23f5:      	callq	*%rax
    23f7:      	shrq	$0x20, %rax
    23fb:      	movq	%rax, (%rsp)
    23ff:      	movq	(%rip), %rdi            # 0x2406 <do_action+0x136>
    2406:      	movq	%rsp, %rsi
    2409:      	movl	$0x1, %eax
    240e:      	callq	*%rax
    2410:      	testq	%rax, %rax
    2413:      	je	0x2be0 <do_action+0x910>
    2419:      	andl	$0x7, %r15d
    241d:      	cmpl	$0x4, %r15d
    2421:      	ja	0x2be0 <do_action+0x910>
    2427:      	cmpl	$0x0, 0x5ea0(%r13,%r15,4)
    2430:      	jne	0x2be0 <do_action+0x910>
    2436:      	movq	0x5e78(%r13,%r15,8), %rcx
    243e:      	movl	$0x0, 0xc(%rsp)
    2446:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    244c:      	movl	0x90(%r13,%rcx), %ecx
    2454:      	movl	%ecx, 0x8(%rsp)
    2458:      	movq	%rax, %r15
    245b:      	movl	$0xe, %eax
    2460:      	callq	*%rax
    2462:      	shrq	$0x20, %rax
    2466:      	movq	%rax, (%rsp)
    246a:      	movq	(%rip), %rdi            # 0x2471 <do_action+0x1a1>
    2471:      	xorl	%ecx, %ecx
    2473:      	movq	%rsp, %rsi
    2476:      	movl	$0x2, %eax
    247b:      	movq	%r15, %rdx
    247e:      	xorl	%ecx, %ecx
    2480:      	callq	*%rax
    2482:      	jmp	0x2be0 <do_action+0x910>
    2487:      	cmpl	$0xc, %r14d
    248b:      	je	0x28a2 <do_action+0x5d2>
    2491:      	cmpl	$0xd, %r14d
    2495:      	je	0x276e <do_action+0x49e>
    249b:      	cmpl	$0xe, %r14d
    249f:      	jne	0x2be0 <do_action+0x910>
    24a5:      	addl	$0x2, %ebx
    24a8:      	movzbl	%bpl, %r12d
    24ac:      	xorq	$0x9, %r12
    24b0:      	jmp	0x2bbe <do_action+0x8ee>
    24b5:      	movl	$0x9, %eax
    24ba:      	cmpl	$0x2, %r14d
    24be:      	je	0x2692 <do_action+0x3c2>
    24c4:      	cmpl	$0x3, %r14d
    24c8:      	jne	0x2be0 <do_action+0x910>
    24ce:      	leal	0x1(%rbx), %eax
    24d1:      	movl	0x4(%r15,%rax,4), %ebp
    24d6:      	addl	$0x2, %ebx
    24d9:      	movl	0x4(%r15,%rbx,4), %r12d
    24de:      	movl	$0x0, 0x10(%rsp)
    24e6:      	movq	(%rip), %rdi            # 0x24ed <do_action+0x21d>
    24ed:      	leaq	0x10(%rsp), %rsi
    24f2:      	movl	$0x1, %eax
    24f7:      	callq	*%rax
    24f9:      	xorl	%r15d, %r15d
    24fc:      	testq	%rax, %rax
    24ff:      	je	0x293f <do_action+0x66f>
    2505:      	movq	%rax, 0x38(%rsp)
    250a:      	andl	$0x7, %ebp
    250d:      	cmpl	$0x4, %ebp
    2510:      	movl	$0x0, %eax
    2515:      	ja	0x2941 <do_action+0x671>
    251b:      	cmpl	$0x0, 0x5ea0(%r13,%rbp,4)
    2524:      	jne	0x2941 <do_action+0x671>
    252a:      	movq	0x5e78(%r13,%rbp,8), %rax
    2532:      	movl	$0x0, 0xc(%rsp)
    253a:      	andl	$0x7ff, %eax            # imm = 0x7FF
    253f:      	movl	0x90(%r13,%rax), %eax
    2547:      	movl	%eax, 0x8(%rsp)
    254b:      	movl	$0xe, %eax
    2550:      	callq	*%rax
    2552:      	shrq	$0x20, %rax
    2556:      	movq	%rax, (%rsp)
    255a:      	cmpl	$0x1, %r14d
    255e:      	jne	0x2918 <do_action+0x648>
    2564:      	andl	$0x7, %r12d
    2568:      	cmpl	$0x4, %r12d
    256c:      	ja	0x293f <do_action+0x66f>
    2572:      	cmpl	$0x0, 0x5ea0(%r13,%r12,4)
    257b:      	movl	$0x0, %eax
    2580:      	jne	0x2941 <do_action+0x671>
    2586:      	movq	0x5e78(%r13,%r12,8), %rax
    258e:      	andl	$0x7ff, %eax            # imm = 0x7FF
    2593:      	leaq	(%rax,%r13), %rdx
    2597:      	addq	$0x90, %rdx
    259e:      	movl	0x90(%r13,%rax), %esi
    25a6:      	andl	$0xfff, %esi            # imm = 0xFFF
    25ac:      	addq	$0x8, %rsi
    25b0:      	movl	$0x4, %eax
    25b5:      	movq	0x38(%rsp), %r12
    25ba:      	movq	%r12, %rdi
    25bd:      	callq	*%rax
    25bf:      	movq	(%rip), %rdi            # 0x25c6 <do_action+0x2f6>
    25c6:      	xorl	%r15d, %r15d
    25c9:      	movq	%rsp, %rsi
    25cc:      	movl	$0x2, %eax
    25d1:      	movq	%r12, %rdx
    25d4:      	jmp	0x2689 <do_action+0x3b9>
    25d9:      	incl	%ebx
    25db:      	movl	0x4(%r15,%rbx,4), %ecx
    25e0:      	andl	$0x7, %ecx
    25e3:      	xorl	%r15d, %r15d
    25e6:      	cmpl	$0x4, %ecx
    25e9:      	ja	0x2941 <do_action+0x671>
    25ef:      	cmpl	$0x0, 0x5ea0(%r13,%rcx,4)
    25f8:      	jne	0x2941 <do_action+0x671>
    25fe:      	movq	0x5e78(%r13,%rcx,8), %rcx
    2606:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    260c:      	movq	0xb8(%r13,%rcx), %rcx
    2614:      	movq	%rcx, 0x10(%rsp)
    2619:      	testq	%rcx, %rcx
    261c:      	je	0x2941 <do_action+0x671>
    2622:      	cmpl	$0xa, %r14d
    2626:      	jne	0x2929 <do_action+0x659>
    262c:      	movl	$0xe, %eax
    2631:      	callq	*%rax
    2633:      	movq	%rax, %r12
    2636:      	shrq	$0x20, %rax
    263a:      	movl	%eax, (%rsp)
    263d:      	movq	(%rip), %rdi            # 0x2644 <do_action+0x374>
    2644:      	movq	%rsp, %rsi
    2647:      	movl	$0x1, %eax
    264c:      	callq	*%rax
    264e:      	movq	%rax, %rcx
    2651:      	testq	%rax, %rax
    2654:      	movl	$0x0, %eax
    2659:      	je	0x2941 <do_action+0x671>
    265f:      	movl	(%rcx), %eax
    2661:      	movl	%eax, (%rsp)
    2664:      	movl	%r12d, 0x4(%rsp)
    2669:      	movq	0x8(%rcx), %rax
    266d:      	movq	%rax, 0x8(%rsp)
    2672:      	movq	(%rip), %rdi            # 0x2679 <do_action+0x3a9>
    2679:      	xorl	%r15d, %r15d
    267c:      	leaq	0x10(%rsp), %rsi
    2681:      	movq	%rsp, %rdx
    2684:      	movl	$0x2, %eax
    2689:      	xorl	%ecx, %ecx
    268b:      	callq	*%rax
    268d:      	jmp	0x293f <do_action+0x66f>
    2692:      	movl	$0x3, %r12d
    2698:      	testb	%bpl, %bpl
    269b:      	je	0x2bbe <do_action+0x8ee>
    26a1:      	movslq	%eax, %rdi
    26a4:      	movl	$0x6d, %eax
    26a9:      	callq	*%rax
    26ab:      	movl	$0x2, %r12d
    26b1:      	jmp	0x2bbe <do_action+0x8ee>
    26b6:      	incl	%ebx
    26b8:      	movl	0x4(%r15,%rbx,4), %eax
    26bd:      	movl	%eax, 0x78(%r13)
    26c1:      	jmp	0x2be0 <do_action+0x910>
    26c6:      	movq	0x38(%rsp), %rax
    26cb:      	movb	$0x0, (%rax)
    26ce:      	jmp	0x2be0 <do_action+0x910>
    26d3:      	incl	%ebx
    26d5:      	movl	$0x5, %r12d
    26db:      	testb	%bpl, %bpl
    26de:      	je	0x2bbe <do_action+0x8ee>
    26e4:      	movl	%ebx, %eax
    26e6:      	movl	0x4(%r15,%rax,4), %ebp
    26eb:      	movl	%ebp, 0x28(%rsp)
    26ef:      	movl	$0xe, %eax
    26f4:      	callq	*%rax
    26f6:      	movq	%rax, 0x10(%rsp)
    26fb:      	movq	(%rip), %rdi            # 0x2702 <do_action+0x432>
    2702:      	leaq	0x10(%rsp), %rsi
    2707:      	movl	$0x1, %eax
    270c:      	callq	*%rax
    270e:      	movq	%rax, %r15
    2711:      	testq	%rax, %rax
    2714:      	je	0x2723 <do_action+0x453>
    2716:      	cmpq	$-0xfff, %r15           # imm = 0xF001
    271d:      	jb	0x2bb5 <do_action+0x8e5>
    2723:      	movl	%r15d, %eax
    2726:      	negl	%eax
    2728:      	testq	%r15, %r15
    272b:      	movl	$0x2, %ecx
    2730:      	cmovnel	%eax, %ecx
    2733:      	movw	%cx, (%rsp)
    2737:      	movw	$0xa, 0x2(%rsp)
    273e:      	movabsq	$0x10000003a, %rax      # imm = 0x10000003A
    2748:      	movq	%rax, 0x4(%rsp)
    274d:      	movq	(%rip), %rdi            # 0x2754 <do_action+0x484>
    2754:      	movq	%rsp, %rsi
    2757:      	movl	$0x1, %eax
    275c:      	callq	*%rax
    275e:      	testq	%rax, %rax
    2761:      	je	0x2b8e <do_action+0x8be>
    2767:      	incl	(%rax)
    2769:      	jmp	0x2bb0 <do_action+0x8e0>
    276e:      	movl	$0xe, %eax
    2773:      	callq	*%rax
    2775:      	movq	%rax, 0x20(%rsp)
    277a:      	movq	(%rip), %rdi            # 0x2781 <do_action+0x4b1>
    2781:      	leaq	0x20(%rsp), %rsi
    2786:      	movl	$0x1, %eax
    278b:      	callq	*%rax
    278d:      	testq	%rax, %rax
    2790:      	je	0x2be0 <do_action+0x910>
    2796:      	movq	0x4(%rax), %rax
    279a:      	movq	%rax, 0x10(%rsp)
    279f:      	movl	$0x2, 0x18(%rsp)
    27a7:      	movq	(%rip), %rdi            # 0x27ae <do_action+0x4de>
    27ae:      	leaq	0x10(%rsp), %rsi
    27b3:      	movl	$0x1, %eax
    27b8:      	callq	*%rax
    27ba:      	movl	$0x1, 0x2c(%rsp)
    27c2:      	testq	%rax, %rax
    27c5:      	je	0x28b2 <do_action+0x5e2>
    27cb:      	lock
    27cc:      	incl	(%rax)
    27ce:      	movq	(%rip), %rdi            # 0x27d5 <do_action+0x505>
    27d5:      	leaq	0x20(%rsp), %rsi
    27da:      	movl	$0x3, %eax
    27df:      	callq	*%rax
    27e1:      	jmp	0x2be0 <do_action+0x910>
    27e6:      	leal	0x1(%rbx), %eax
    27e9:      	movl	0x4(%r15,%rax,4), %ebp
    27ee:      	leal	0x2(%rbx), %eax
    27f1:      	movl	0x4(%r15,%rax,4), %eax
    27f6:      	movl	%eax, 0x30(%rsp)
    27fa:      	movl	$0x7d, %eax
    27ff:      	callq	*%rax
    2801:      	movq	%rax, 0x68(%rsp)
    2806:      	movq	%rax, (%rsp)
    280a:      	movl	$0x0, 0x20(%rsp)
    2812:      	movq	%rbp, 0x70(%rsp)
    2817:      	testq	%rbp, %rbp
    281a:      	je	0x2b1e <do_action+0x84e>
    2820:      	movq	(%rip), %rdi            # 0x2827 <do_action+0x557>
    2827:      	leaq	0x20(%rsp), %rsi
    282c:      	movl	$0x1, %eax
    2831:      	callq	*%rax
    2833:      	testq	%rax, %rax
    2836:      	je	0x2b1e <do_action+0x84e>
    283c:      	movq	%rax, 0x48(%rsp)
    2841:      	movq	%rax, %rbp
    2844:      	movq	(%rip), %rdi            # 0x284b <do_action+0x57b>
    284b:      	leaq	0x20(%rsp), %rsi
    2850:      	movl	$0x1, %eax
    2855:      	callq	*%rax
    2857:      	movq	%rax, %rdx
    285a:      	movq	0x60(%r13), %rax
    285e:      	movq	%rax, (%rbp)
    2862:      	movq	0x70(%r13), %rax
    2866:      	movq	%rbp, 0x40(%rsp)
    286b:      	movq	%rax, 0x8(%rbp)
    286f:      	xorl	%eax, %eax
    2871:      	movq	%rax, 0x60(%rsp)
    2876:      	movl	$0x0, %eax
    287b:      	movl	0x30(%rsp), %ecx
    287f:      	cmpl	$0x2, %ecx
    2882:      	je	0x2953 <do_action+0x683>
    2888:      	cmpl	$0x1, %ecx
    288b:      	je	0x294f <do_action+0x67f>
    2891:      	testl	%ecx, %ecx
    2893:      	jne	0x2b1e <do_action+0x84e>
    2899:      	movl	0x7c(%r13), %eax
    289d:      	jmp	0x2953 <do_action+0x683>
    28a2:      	addl	$0x3, %ebx
    28a5:      	movzbl	%bpl, %r12d
    28a9:      	xorq	$0x7, %r12
    28ad:      	jmp	0x2bbe <do_action+0x8ee>
    28b2:      	movq	(%rip), %rdi            # 0x28b9 <do_action+0x5e9>
    28b9:      	leaq	0x10(%rsp), %rsi
    28be:      	leaq	0x2c(%rsp), %rdx
    28c3:      	movl	$0x1, %ecx
    28c8:      	movl	$0x2, %eax
    28cd:      	callq	*%rax
    28cf:      	testq	%rax, %rax
    28d2:      	je	0x27ce <do_action+0x4fe>
    28d8:      	movq	%rax, %r15
    28db:      	negl	%eax
    28dd:      	movw	%ax, (%rsp)
    28e1:      	movw	$0x3, 0x2(%rsp)
    28e8:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    28f2:      	movq	%rax, 0x4(%rsp)
    28f7:      	movq	(%rip), %rdi            # 0x28fe <do_action+0x62e>
    28fe:      	movq	%rsp, %rsi
    2901:      	movl	$0x1, %eax
    2906:      	callq	*%rax
    2908:      	testq	%rax, %rax
    290b:      	je	0x2c15 <do_action+0x945>
    2911:      	incl	(%rax)
    2913:      	jmp	0x2c37 <do_action+0x967>
    2918:      	movq	(%rip), %rdi            # 0x291f <do_action+0x64f>
    291f:      	movq	%rsp, %rsi
    2922:      	movl	$0x3, %eax
    2927:      	jmp	0x293a <do_action+0x66a>
    2929:      	movq	(%rip), %rdi            # 0x2930 <do_action+0x660>
    2930:      	leaq	0x10(%rsp), %rsi
    2935:      	movl	$0x3, %eax
    293a:      	callq	*%rax
    293c:      	movq	%rax, %r15
    293f:      	xorl	%eax, %eax
    2941:      	testl	%r15d, %r15d
    2944:      	jne	0x2be8 <do_action+0x918>
    294a:      	jmp	0x2be0 <do_action+0x910>
    294f:      	movl	0x10(%r13), %eax
    2953:      	movq	%r12, 0x30(%rsp)
    2958:      	movl	%eax, %eax
    295a:      	movq	0x40(%rsp), %rcx
    295f:      	movq	%rax, 0x10(%rcx)
    2963:      	movq	0x48(%rsp), %rdi
    2968:      	addq	$0x18, %rdi
    296c:      	movl	$0xc8, %ecx
    2971:      	movl	$0x4, %eax
    2976:      	movq	%rdi, 0x48(%rsp)
    297b:      	movl	$0xc8, %esi
    2980:      	callq	*%rax
    2982:      	xorl	%r12d, %r12d
    2985:      	movq	%r13, 0x58(%rsp)
    298a:      	jmp	0x299a <do_action+0x6ca>
    298c:      	addq	$0x4, %r12
    2990:      	cmpq	$0x14, %r12
    2994:      	je	0x2ac7 <do_action+0x7f7>
    299a:      	movl	$0x0, 0x10(%rsp)
    29a2:      	movl	$0x1, %eax
    29a7:      	movq	(%rip), %rdi            # 0x29ae <do_action+0x6de>
    29ae:      	leaq	0x10(%rsp), %rsi
    29b3:      	callq	*%rax
    29b5:      	testq	%rax, %rax
    29b8:      	je	0x2ac7 <do_action+0x7f7>
    29be:      	movq	%rax, %rsi
    29c1:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    29c8:      	movl	$0x1, %eax
    29cd:      	movq	(%rip), %rdi            # 0x29d4 <do_action+0x704>
    29d4:      	callq	*%rax
    29d6:      	testq	%rax, %rax
    29d9:      	je	0x2ac7 <do_action+0x7f7>
    29df:      	cmpl	$-0x1, 0x40(%rax,%r12)
    29e5:      	je	0x2ac7 <do_action+0x7f7>
    29eb:      	movq	0x5e78(%r13,%r12,2), %rax
    29f3:      	movl	0x4(%r13), %ecx
    29f7:      	cmpq	%rcx, %rax
    29fa:      	jge	0x2ac7 <do_action+0x7f7>
    2a00:      	cmpq	$0x10, %r12
    2a04:      	je	0x2a67 <do_action+0x797>
    2a06:      	movl	$0x0, 0x10(%rsp)
    2a0e:      	movl	$0x1, %eax
    2a13:      	movq	(%rip), %rdi            # 0x2a1a <do_action+0x74a>
    2a1a:      	leaq	0x10(%rsp), %rsi
    2a1f:      	callq	*%rax
    2a21:      	testq	%rax, %rax
    2a24:      	je	0x2a5f <do_action+0x78f>
    2a26:      	movq	%rax, %rsi
    2a29:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    2a30:      	movl	$0x1, %eax
    2a35:      	movq	(%rip), %rdi            # 0x2a3c <do_action+0x76c>
    2a3c:      	callq	*%rax
    2a3e:      	testq	%rax, %rax
    2a41:      	je	0x2a5f <do_action+0x78f>
    2a43:      	cmpl	$-0x1, 0x44(%rax,%r12)
    2a49:      	movq	0x5e78(%r13,%r12,2), %rax
    2a51:      	je	0x2a67 <do_action+0x797>
    2a53:      	movl	0x5e80(%r13,%r12,2), %ebp
    2a5b:      	subl	%eax, %ebp
    2a5d:      	jmp	0x2a70 <do_action+0x7a0>
    2a5f:      	movq	0x5e78(%r13,%r12,2), %rax
    2a67:      	movl	0x4(%r13), %ebp
    2a6b:      	subl	%eax, %ebp
    2a6d:      	addl	$0x4, %ebp
    2a70:      	testl	%ebp, %ebp
    2a72:      	jle	0x298c <do_action+0x6bc>
    2a78:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    2a7d:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    2a82:      	cmpl	$0x28, %ebp
    2a85:      	movl	$0x28, %ecx
    2a8a:      	cmovgel	%ecx, %ebp
    2a8d:      	movzbl	0x60(%rsp), %r13d
    2a93:      	movq	0x48(%rsp), %rcx
    2a98:      	leaq	(%rcx,%r13), %rdi
    2a9c:      	movq	0x58(%rsp), %rcx
    2aa1:      	leaq	(%rcx,%rax), %rdx
    2aa5:      	addq	$0x90, %rdx
    2aac:      	movl	$0x4, %eax
    2ab1:      	movl	%ebp, %esi
    2ab3:      	callq	*%rax
    2ab5:      	addl	%r13d, %ebp
    2ab8:      	movq	0x58(%rsp), %r13
    2abd:      	movq	%rbp, 0x60(%rsp)
    2ac2:      	jmp	0x298c <do_action+0x6bc>
    2ac7:      	movq	(%rip), %rdi            # 0x2ace <do_action+0x7fe>
    2ace:      	movl	$0x1, %eax
    2ad3:      	movq	0x40(%rsp), %rsi
    2ad8:      	callq	*%rax
    2ada:      	testq	%rax, %rax
    2add:      	je	0x2aff <do_action+0x82f>
    2adf:      	imulq	$-0xf4240, 0x70(%rsp), %rcx # imm = 0xFFF0BDC0
    2ae8:      	movq	0x68(%rsp), %rdx
    2aed:      	addq	%rcx, %rdx
    2af0:      	cmpq	%rdx, (%rax)
    2af3:      	jbe	0x2aff <do_action+0x82f>
    2af5:      	movq	0x38(%rsp), %rax
    2afa:      	movb	$0x0, (%rax)
    2afd:      	jmp	0x2b19 <do_action+0x849>
    2aff:      	movq	(%rip), %rdi            # 0x2b06 <do_action+0x836>
    2b06:      	xorl	%ecx, %ecx
    2b08:      	movq	%rsp, %rdx
    2b0b:      	movl	$0x2, %eax
    2b10:      	movq	0x40(%rsp), %rsi
    2b15:      	xorl	%ecx, %ecx
    2b17:      	callq	*%rax
    2b19:      	movq	0x30(%rsp), %r12
    2b1e:      	leal	0x3(%rbx), %eax
    2b21:      	cmpl	$0x0, 0x4(%r15,%rax,4)
    2b27:      	je	0x2b4a <do_action+0x87a>
    2b29:      	orb	$0x2, 0x1(%r13)
    2b2e:      	movq	(%rip), %rsi            # 0x2b35 <do_action+0x865>
    2b35:      	xorl	%ecx, %ecx
    2b37:      	movl	$0x1b, %eax
    2b3c:      	movq	%r12, %rdi
    2b3f:      	xorl	%edx, %edx
    2b41:      	callq	*%rax
    2b43:      	movq	%rax, 0x80(%r13)
    2b4a:      	leal	0x4(%rbx), %eax
    2b4d:      	cmpl	$0x0, 0x4(%r15,%rax,4)
    2b53:      	je	0x2b7c <do_action+0x8ac>
    2b55:      	orb	$0x4, 0x1(%r13)
    2b5a:      	movq	(%rip), %rsi            # 0x2b61 <do_action+0x891>
    2b61:      	movl	$0x100, %ecx            # imm = 0x100
    2b66:      	movl	$0x1b, %eax
    2b6b:      	movl	$0x100, %edx            # imm = 0x100
    2b70:      	movq	%r12, %rdi
    2b73:      	callq	*%rax
    2b75:      	movq	%rax, 0x88(%r13)
    2b7c:      	addl	$0x5, %ebx
    2b7f:      	cmpl	$0x0, 0x4(%r15,%rbx,4)
    2b85:      	je	0x2be0 <do_action+0x910>
    2b87:      	orb	$0x8, 0x1(%r13)
    2b8c:      	jmp	0x2be0 <do_action+0x910>
    2b8e:      	movl	$0x1, 0x20(%rsp)
    2b96:      	movq	(%rip), %rdi            # 0x2b9d <do_action+0x8cd>
    2b9d:      	xorl	%ecx, %ecx
    2b9f:      	movq	%rsp, %rsi
    2ba2:      	leaq	0x20(%rsp), %rdx
    2ba7:      	movl	$0x2, %eax
    2bac:      	xorl	%ecx, %ecx
    2bae:      	callq	*%rax
    2bb0:      	testq	%r15, %r15
    2bb3:      	je	0x2bf7 <do_action+0x927>
    2bb5:      	movl	%ebp, (%r15)
    2bb8:      	movl	$0x4, %r12d
    2bbe:      	movl	$0x0, (%rsp)
    2bc5:      	movq	(%rip), %rdi            # 0x2bcc <do_action+0x8fc>
    2bcc:      	movq	%rsp, %rsi
    2bcf:      	movl	$0x1, %eax
    2bd4:      	callq	*%rax
    2bd6:      	testq	%rax, %rax
    2bd9:      	je	0x2be0 <do_action+0x910>
    2bdb:      	lock
    2bdc:      	incq	(%rax,%r12,8)
    2be0:      	movq	%r14, 0x70(%r13)
    2be4:      	incl	%ebx
    2be6:      	movl	%ebx, %eax
    2be8:      	addq	$0x78, %rsp
    2bec:      	popq	%rbx
    2bed:      	popq	%r12
    2bef:      	popq	%r13
    2bf1:      	popq	%r14
    2bf3:      	popq	%r15
    2bf5:      	popq	%rbp
    2bf6:      	retq
    2bf7:      	movq	(%rip), %rdi            # 0x2bfe <do_action+0x92e>
    2bfe:      	xorl	%ecx, %ecx
    2c00:      	leaq	0x10(%rsp), %rsi
    2c05:      	leaq	0x28(%rsp), %rdx
    2c0a:      	movl	$0x2, %eax
    2c0f:      	xorl	%ecx, %ecx
    2c11:      	callq	*%rax
    2c13:      	jmp	0x2bb8 <do_action+0x8e8>
    2c15:      	movl	$0x1, 0x28(%rsp)
    2c1d:      	movq	(%rip), %rdi            # 0x2c24 <do_action+0x954>
    2c24:      	xorl	%ecx, %ecx
    2c26:      	movq	%rsp, %rsi
    2c29:      	leaq	0x28(%rsp), %rdx
    2c2e:      	movl	$0x2, %eax
    2c33:      	xorl	%ecx, %ecx
    2c35:      	callq	*%rax
    2c37:      	testl	%r15d, %r15d
    2c3a:      	je	0x27ce <do_action+0x4fe>
    2c40:      	movq	(%rip), %rdi            # 0x2c47 <do_action+0x977>
    2c47:      	leaq	0x10(%rsp), %rsi
    2c4c:      	movl	$0x1, %eax
    2c51:      	callq	*%rax
    2c53:      	testq	%rax, %rax
    2c56:      	je	0x27ce <do_action+0x4fe>
    2c5c:      	movl	0x2c(%rsp), %ecx
    2c60:      	lock
    2c61:      	addl	%ecx, (%rax)
    2c63:      	jmp	0x27ce <do_action+0x4fe>
    2c68:      	nopl	(%rax,%rax)

0000000000002c70 <try_preload_arg>:
    2c70:      	pushq	%rbp
    2c71:      	pushq	%r15
    2c73:      	pushq	%r14
    2c75:      	pushq	%rbx
    2c76:      	subq	$0x38, %rsp
    2c7a:      	movl	%edi, %ebx
    2c7c:      	andl	$0x7, %ebx
    2c7f:      	movq	(%rsi), %r14
    2c82:      	movl	0x18(%r14,%rbx,4), %eax
    2c87:      	testl	$0x100, %eax            # imm = 0x100
    2c8c:      	jne	0x2c9b <try_preload_arg+0x2b>
    2c8e:      	xorl	%eax, %eax
    2c90:      	addq	$0x38, %rsp
    2c94:      	popq	%rbx
    2c95:      	popq	%r14
    2c97:      	popq	%r15
    2c99:      	popq	%rbp
    2c9a:      	retq
    2c9b:      	movq	0x8(%rsi), %rcx
    2c9f:      	testb	%al, %al
    2ca1:      	js	0x2cec <try_preload_arg+0x7c>
    2ca3:      	movl	$0x0, 0x10(%rsp)
    2cab:      	movl	0x40(%r14,%rbx,4), %eax
    2cb0:      	cmpl	$0x1, %eax
    2cb3:      	jle	0x304e <try_preload_arg+0x3de>
    2cb9:      	cmpl	$0x2, %eax
    2cbc:      	je	0x306c <try_preload_arg+0x3fc>
    2cc2:      	cmpl	$0x3, %eax
    2cc5:      	je	0x3081 <try_preload_arg+0x411>
    2ccb:      	cmpl	$0x4, %eax
    2cce:      	jne	0x30bd <try_preload_arg+0x44d>
    2cd4:      	addq	$0x48, %rcx
    2cd8:      	leaq	0x18(%rsp), %rdi
    2cdd:      	movl	$0x8, %edx
    2ce2:      	movl	$0x4, %eax
    2ce7:      	jmp	0x30a9 <try_preload_arg+0x439>
    2cec:      	movl	$0x0, 0x10(%rsp)
    2cf4:      	movzbl	0x2c2(%r14,%rbx,4), %eax
    2cfd:      	shlb	$0x3, %al
    2d00:      	movb	$0x40, %dl
    2d02:      	subb	%al, %dl
    2d04:      	movzwl	0x2c0(%r14,%rbx,4), %esi
    2d0d:      	movzbl	%dl, %edx
    2d10:      	movq	%rcx, %rdi
    2d13:      	callq	0x0 <read_reg>
    2d18:      	movq	%rax, 0x8(%rsp)
    2d1d:      	movl	0x4(%r14,%rbx,4), %ebp
    2d22:      	cmpl	$0x4, %ebx
    2d25:      	ja	0x341d <try_preload_arg+0x7ad>
    2d2b:      	leaq	(%rbx,%rbx,4), %rax
    2d2f:      	shll	$0x4, %eax
    2d32:      	cmpw	$0x0, 0x76(%r14,%rax)
    2d39:      	je	0x341d <try_preload_arg+0x7ad>
    2d3f:      	leaq	(%r14,%rax), %rbx
    2d43:      	addq	$0x70, %rbx
    2d47:      	movq	%rbx, 0x18(%rsp)
    2d4c:      	leaq	0x8(%rsp), %rax
    2d51:      	movq	%rax, 0x20(%rsp)
    2d56:      	movb	$0x1, 0x28(%rsp)
    2d5b:      	leaq	0x10(%rsp), %rax
    2d60:      	movq	%rax, 0x30(%rsp)
    2d65:      	movq	(%rip), %rax            # 0x2d6c <try_preload_arg+0xfc>
    2d6c:      	cmpb	$0x0, (%rax)
    2d6f:      	je	0x33fc <try_preload_arg+0x78c>
    2d75:      	cmpw	$0x0, 0x6(%rbx)
    2d7a:      	je	0x341d <try_preload_arg+0x7ad>
    2d80:      	movl	(%rbx), %ecx
    2d82:      	addq	0x8(%rsp), %rcx
    2d87:      	movq	%rcx, 0x8(%rsp)
    2d8c:      	cmpw	$0x0, 0x4(%rbx)
    2d91:      	je	0x2dbc <try_preload_arg+0x14c>
    2d93:      	leaq	0x8(%rsp), %rdi
    2d98:      	movl	$0x8, %edx
    2d9d:      	movl	$0x94, %eax
    2da2:      	movq	0x8(%rsp), %rdx
    2da7:      	movl	$0x8, %esi
    2dac:      	callq	*%rax
    2dae:      	movl	$0x1, %r14d
    2db4:      	testl	%eax, %eax
    2db6:      	js	0x3044 <try_preload_arg+0x3d4>
    2dbc:      	cmpw	$0x0, 0xe(%rbx)
    2dc1:      	je	0x341d <try_preload_arg+0x7ad>
    2dc7:      	movl	0x8(%rbx), %ecx
    2dca:      	addq	0x8(%rsp), %rcx
    2dcf:      	movq	%rcx, 0x8(%rsp)
    2dd4:      	cmpw	$0x0, 0xc(%rbx)
    2dd9:      	je	0x2e04 <try_preload_arg+0x194>
    2ddb:      	leaq	0x8(%rsp), %rdi
    2de0:      	movl	$0x8, %edx
    2de5:      	movl	$0x94, %eax
    2dea:      	movq	0x8(%rsp), %rdx
    2def:      	movl	$0x8, %esi
    2df4:      	callq	*%rax
    2df6:      	movl	$0x2, %r14d
    2dfc:      	testl	%eax, %eax
    2dfe:      	js	0x3044 <try_preload_arg+0x3d4>
    2e04:      	cmpw	$0x0, 0x16(%rbx)
    2e09:      	je	0x341d <try_preload_arg+0x7ad>
    2e0f:      	movl	0x10(%rbx), %ecx
    2e12:      	addq	0x8(%rsp), %rcx
    2e17:      	movq	%rcx, 0x8(%rsp)
    2e1c:      	cmpw	$0x0, 0x14(%rbx)
    2e21:      	je	0x2e4c <try_preload_arg+0x1dc>
    2e23:      	leaq	0x8(%rsp), %rdi
    2e28:      	movl	$0x8, %edx
    2e2d:      	movl	$0x94, %eax
    2e32:      	movq	0x8(%rsp), %rdx
    2e37:      	movl	$0x8, %esi
    2e3c:      	callq	*%rax
    2e3e:      	movl	$0x3, %r14d
    2e44:      	testl	%eax, %eax
    2e46:      	js	0x3044 <try_preload_arg+0x3d4>
    2e4c:      	cmpw	$0x0, 0x1e(%rbx)
    2e51:      	je	0x341d <try_preload_arg+0x7ad>
    2e57:      	movl	0x18(%rbx), %ecx
    2e5a:      	addq	0x8(%rsp), %rcx
    2e5f:      	movq	%rcx, 0x8(%rsp)
    2e64:      	cmpw	$0x0, 0x1c(%rbx)
    2e69:      	je	0x2e94 <try_preload_arg+0x224>
    2e6b:      	leaq	0x8(%rsp), %rdi
    2e70:      	movl	$0x8, %edx
    2e75:      	movl	$0x94, %eax
    2e7a:      	movq	0x8(%rsp), %rdx
    2e7f:      	movl	$0x8, %esi
    2e84:      	callq	*%rax
    2e86:      	movl	$0x4, %r14d
    2e8c:      	testl	%eax, %eax
    2e8e:      	js	0x3044 <try_preload_arg+0x3d4>
    2e94:      	cmpw	$0x0, 0x26(%rbx)
    2e99:      	je	0x341d <try_preload_arg+0x7ad>
    2e9f:      	movl	0x20(%rbx), %ecx
    2ea2:      	addq	0x8(%rsp), %rcx
    2ea7:      	movq	%rcx, 0x8(%rsp)
    2eac:      	cmpw	$0x0, 0x24(%rbx)
    2eb1:      	je	0x2edc <try_preload_arg+0x26c>
    2eb3:      	leaq	0x8(%rsp), %rdi
    2eb8:      	movl	$0x8, %edx
    2ebd:      	movl	$0x94, %eax
    2ec2:      	movq	0x8(%rsp), %rdx
    2ec7:      	movl	$0x8, %esi
    2ecc:      	callq	*%rax
    2ece:      	movl	$0x5, %r14d
    2ed4:      	testl	%eax, %eax
    2ed6:      	js	0x3044 <try_preload_arg+0x3d4>
    2edc:      	cmpw	$0x0, 0x2e(%rbx)
    2ee1:      	je	0x341d <try_preload_arg+0x7ad>
    2ee7:      	movl	0x28(%rbx), %ecx
    2eea:      	addq	0x8(%rsp), %rcx
    2eef:      	movq	%rcx, 0x8(%rsp)
    2ef4:      	cmpw	$0x0, 0x2c(%rbx)
    2ef9:      	je	0x2f24 <try_preload_arg+0x2b4>
    2efb:      	leaq	0x8(%rsp), %rdi
    2f00:      	movl	$0x8, %edx
    2f05:      	movl	$0x94, %eax
    2f0a:      	movq	0x8(%rsp), %rdx
    2f0f:      	movl	$0x8, %esi
    2f14:      	callq	*%rax
    2f16:      	movl	$0x6, %r14d
    2f1c:      	testl	%eax, %eax
    2f1e:      	js	0x3044 <try_preload_arg+0x3d4>
    2f24:      	cmpw	$0x0, 0x36(%rbx)
    2f29:      	je	0x341d <try_preload_arg+0x7ad>
    2f2f:      	movl	0x30(%rbx), %ecx
    2f32:      	addq	0x8(%rsp), %rcx
    2f37:      	movq	%rcx, 0x8(%rsp)
    2f3c:      	cmpw	$0x0, 0x34(%rbx)
    2f41:      	je	0x2f6c <try_preload_arg+0x2fc>
    2f43:      	leaq	0x8(%rsp), %rdi
    2f48:      	movl	$0x8, %edx
    2f4d:      	movl	$0x94, %eax
    2f52:      	movq	0x8(%rsp), %rdx
    2f57:      	movl	$0x8, %esi
    2f5c:      	callq	*%rax
    2f5e:      	movl	$0x7, %r14d
    2f64:      	testl	%eax, %eax
    2f66:      	js	0x3044 <try_preload_arg+0x3d4>
    2f6c:      	cmpw	$0x0, 0x3e(%rbx)
    2f71:      	je	0x341d <try_preload_arg+0x7ad>
    2f77:      	movl	0x38(%rbx), %ecx
    2f7a:      	addq	0x8(%rsp), %rcx
    2f7f:      	movq	%rcx, 0x8(%rsp)
    2f84:      	cmpw	$0x0, 0x3c(%rbx)
    2f89:      	je	0x2fb4 <try_preload_arg+0x344>
    2f8b:      	leaq	0x8(%rsp), %rdi
    2f90:      	movl	$0x8, %edx
    2f95:      	movl	$0x94, %eax
    2f9a:      	movq	0x8(%rsp), %rdx
    2f9f:      	movl	$0x8, %r14d
    2fa5:      	movl	$0x8, %esi
    2faa:      	callq	*%rax
    2fac:      	testl	%eax, %eax
    2fae:      	js	0x3044 <try_preload_arg+0x3d4>
    2fb4:      	cmpw	$0x0, 0x46(%rbx)
    2fb9:      	je	0x341d <try_preload_arg+0x7ad>
    2fbf:      	movl	0x40(%rbx), %ecx
    2fc2:      	addq	0x8(%rsp), %rcx
    2fc7:      	movq	%rcx, 0x8(%rsp)
    2fcc:      	cmpw	$0x0, 0x44(%rbx)
    2fd1:      	je	0x2ff8 <try_preload_arg+0x388>
    2fd3:      	leaq	0x8(%rsp), %rdi
    2fd8:      	movl	$0x8, %edx
    2fdd:      	movl	$0x94, %eax
    2fe2:      	movq	0x8(%rsp), %rdx
    2fe7:      	movl	$0x8, %esi
    2fec:      	callq	*%rax
    2fee:      	movl	$0x9, %r14d
    2ff4:      	testl	%eax, %eax
    2ff6:      	js	0x3044 <try_preload_arg+0x3d4>
    2ff8:      	cmpw	$0x0, 0x4e(%rbx)
    2ffd:      	je	0x341d <try_preload_arg+0x7ad>
    3003:      	movl	0x48(%rbx), %ecx
    3006:      	addq	0x8(%rsp), %rcx
    300b:      	movq	%rcx, 0x8(%rsp)
    3010:      	cmpw	$0x0, 0x4c(%rbx)
    3015:      	je	0x341d <try_preload_arg+0x7ad>
    301b:      	leaq	0x8(%rsp), %rdi
    3020:      	movl	$0x8, %edx
    3025:      	movl	$0x94, %eax
    302a:      	movq	0x8(%rsp), %rdx
    302f:      	movl	$0x8, %esi
    3034:      	callq	*%rax
    3036:      	movl	$0xa, %r14d
    303c:      	testl	%eax, %eax
    303e:      	jns	0x341d <try_preload_arg+0x7ad>
    3044:      	movl	%r14d, 0x10(%rsp)
    3049:      	jmp	0x341d <try_preload_arg+0x7ad>
    304e:      	testl	%eax, %eax
    3050:      	je	0x3096 <try_preload_arg+0x426>
    3052:      	cmpl	$0x1, %eax
    3055:      	jne	0x30bd <try_preload_arg+0x44d>
    3057:      	addq	$0x68, %rcx
    305b:      	leaq	0x18(%rsp), %rdi
    3060:      	movl	$0x8, %edx
    3065:      	movl	$0x4, %eax
    306a:      	jmp	0x30a9 <try_preload_arg+0x439>
    306c:      	addq	$0x60, %rcx
    3070:      	leaq	0x18(%rsp), %rdi
    3075:      	movl	$0x8, %edx
    307a:      	movl	$0x4, %eax
    307f:      	jmp	0x30a9 <try_preload_arg+0x439>
    3081:      	addq	$0x58, %rcx
    3085:      	leaq	0x18(%rsp), %rdi
    308a:      	movl	$0x8, %edx
    308f:      	movl	$0x4, %eax
    3094:      	jmp	0x30a9 <try_preload_arg+0x439>
    3096:      	addq	$0x70, %rcx
    309a:      	leaq	0x18(%rsp), %rdi
    309f:      	movl	$0x8, %edx
    30a4:      	movl	$0x4, %eax
    30a9:      	movl	$0x8, %esi
    30ae:      	movq	%rcx, %rdx
    30b1:      	callq	*%rax
    30b3:      	movq	0x18(%rsp), %rax
    30b8:      	movq	%rax, 0x8(%rsp)
    30bd:      	cmpl	$0x4, %ebx
    30c0:      	ja	0x34d7 <try_preload_arg+0x867>
    30c6:      	leaq	(%rbx,%rbx,4), %rax
    30ca:      	shll	$0x4, %eax
    30cd:      	cmpw	$0x0, 0x76(%r14,%rax)
    30d4:      	je	0x34d7 <try_preload_arg+0x867>
    30da:      	leaq	(%r14,%rax), %r15
    30de:      	addq	$0x70, %r15
    30e2:      	movq	%r15, 0x18(%rsp)
    30e7:      	leaq	0x8(%rsp), %rax
    30ec:      	movq	%rax, 0x20(%rsp)
    30f1:      	movb	$0x1, 0x28(%rsp)
    30f6:      	leaq	0x10(%rsp), %rax
    30fb:      	movq	%rax, 0x30(%rsp)
    3100:      	movq	(%rip), %rax            # 0x3107 <try_preload_arg+0x497>
    3107:      	cmpb	$0x0, (%rax)
    310a:      	je	0x34b6 <try_preload_arg+0x846>
    3110:      	cmpw	$0x0, 0x6(%r15)
    3116:      	je	0x34d7 <try_preload_arg+0x867>
    311c:      	movl	(%r15), %ecx
    311f:      	addq	0x8(%rsp), %rcx
    3124:      	movq	%rcx, 0x8(%rsp)
    3129:      	cmpw	$0x0, 0x4(%r15)
    312f:      	je	0x3159 <try_preload_arg+0x4e9>
    3131:      	leaq	0x8(%rsp), %rdi
    3136:      	movl	$0x8, %edx
    313b:      	movl	$0x94, %eax
    3140:      	movq	0x8(%rsp), %rdx
    3145:      	movl	$0x8, %esi
    314a:      	callq	*%rax
    314c:      	movl	$0x1, %ebp
    3151:      	testl	%eax, %eax
    3153:      	js	0x33f3 <try_preload_arg+0x783>
    3159:      	cmpw	$0x0, 0xe(%r15)
    315f:      	je	0x34d7 <try_preload_arg+0x867>
    3165:      	movl	0x8(%r15), %ecx
    3169:      	addq	0x8(%rsp), %rcx
    316e:      	movq	%rcx, 0x8(%rsp)
    3173:      	cmpw	$0x0, 0xc(%r15)
    3179:      	je	0x31a3 <try_preload_arg+0x533>
    317b:      	leaq	0x8(%rsp), %rdi
    3180:      	movl	$0x8, %edx
    3185:      	movl	$0x94, %eax
    318a:      	movq	0x8(%rsp), %rdx
    318f:      	movl	$0x8, %esi
    3194:      	callq	*%rax
    3196:      	movl	$0x2, %ebp
    319b:      	testl	%eax, %eax
    319d:      	js	0x33f3 <try_preload_arg+0x783>
    31a3:      	cmpw	$0x0, 0x16(%r15)
    31a9:      	je	0x34d7 <try_preload_arg+0x867>
    31af:      	movl	0x10(%r15), %ecx
    31b3:      	addq	0x8(%rsp), %rcx
    31b8:      	movq	%rcx, 0x8(%rsp)
    31bd:      	cmpw	$0x0, 0x14(%r15)
    31c3:      	je	0x31ed <try_preload_arg+0x57d>
    31c5:      	leaq	0x8(%rsp), %rdi
    31ca:      	movl	$0x8, %edx
    31cf:      	movl	$0x94, %eax
    31d4:      	movq	0x8(%rsp), %rdx
    31d9:      	movl	$0x8, %esi
    31de:      	callq	*%rax
    31e0:      	movl	$0x3, %ebp
    31e5:      	testl	%eax, %eax
    31e7:      	js	0x33f3 <try_preload_arg+0x783>
    31ed:      	cmpw	$0x0, 0x1e(%r15)
    31f3:      	je	0x34d7 <try_preload_arg+0x867>
    31f9:      	movl	0x18(%r15), %ecx
    31fd:      	addq	0x8(%rsp), %rcx
    3202:      	movq	%rcx, 0x8(%rsp)
    3207:      	cmpw	$0x0, 0x1c(%r15)
    320d:      	je	0x3237 <try_preload_arg+0x5c7>
    320f:      	leaq	0x8(%rsp), %rdi
    3214:      	movl	$0x8, %edx
    3219:      	movl	$0x94, %eax
    321e:      	movq	0x8(%rsp), %rdx
    3223:      	movl	$0x8, %esi
    3228:      	callq	*%rax
    322a:      	movl	$0x4, %ebp
    322f:      	testl	%eax, %eax
    3231:      	js	0x33f3 <try_preload_arg+0x783>
    3237:      	cmpw	$0x0, 0x26(%r15)
    323d:      	je	0x34d7 <try_preload_arg+0x867>
    3243:      	movl	0x20(%r15), %ecx
    3247:      	addq	0x8(%rsp), %rcx
    324c:      	movq	%rcx, 0x8(%rsp)
    3251:      	cmpw	$0x0, 0x24(%r15)
    3257:      	je	0x3281 <try_preload_arg+0x611>
    3259:      	leaq	0x8(%rsp), %rdi
    325e:      	movl	$0x8, %edx
    3263:      	movl	$0x94, %eax
    3268:      	movq	0x8(%rsp), %rdx
    326d:      	movl	$0x8, %esi
    3272:      	callq	*%rax
    3274:      	movl	$0x5, %ebp
    3279:      	testl	%eax, %eax
    327b:      	js	0x33f3 <try_preload_arg+0x783>
    3281:      	cmpw	$0x0, 0x2e(%r15)
    3287:      	je	0x34d7 <try_preload_arg+0x867>
    328d:      	movl	0x28(%r15), %ecx
    3291:      	addq	0x8(%rsp), %rcx
    3296:      	movq	%rcx, 0x8(%rsp)
    329b:      	cmpw	$0x0, 0x2c(%r15)
    32a1:      	je	0x32cb <try_preload_arg+0x65b>
    32a3:      	leaq	0x8(%rsp), %rdi
    32a8:      	movl	$0x8, %edx
    32ad:      	movl	$0x94, %eax
    32b2:      	movq	0x8(%rsp), %rdx
    32b7:      	movl	$0x8, %esi
    32bc:      	callq	*%rax
    32be:      	movl	$0x6, %ebp
    32c3:      	testl	%eax, %eax
    32c5:      	js	0x33f3 <try_preload_arg+0x783>
    32cb:      	cmpw	$0x0, 0x36(%r15)
    32d1:      	je	0x34d7 <try_preload_arg+0x867>
    32d7:      	movl	0x30(%r15), %ecx
    32db:      	addq	0x8(%rsp), %rcx
    32e0:      	movq	%rcx, 0x8(%rsp)
    32e5:      	cmpw	$0x0, 0x34(%r15)
    32eb:      	je	0x3315 <try_preload_arg+0x6a5>
    32ed:      	leaq	0x8(%rsp), %rdi
    32f2:      	movl	$0x8, %edx
    32f7:      	movl	$0x94, %eax
    32fc:      	movq	0x8(%rsp), %rdx
    3301:      	movl	$0x8, %esi
    3306:      	callq	*%rax
    3308:      	movl	$0x7, %ebp
    330d:      	testl	%eax, %eax
    330f:      	js	0x33f3 <try_preload_arg+0x783>
    3315:      	cmpw	$0x0, 0x3e(%r15)
    331b:      	je	0x34d7 <try_preload_arg+0x867>
    3321:      	movl	0x38(%r15), %ecx
    3325:      	addq	0x8(%rsp), %rcx
    332a:      	movq	%rcx, 0x8(%rsp)
    332f:      	cmpw	$0x0, 0x3c(%r15)
    3335:      	je	0x335f <try_preload_arg+0x6ef>
    3337:      	leaq	0x8(%rsp), %rdi
    333c:      	movl	$0x8, %edx
    3341:      	movl	$0x94, %eax
    3346:      	movq	0x8(%rsp), %rdx
    334b:      	movl	$0x8, %ebp
    3350:      	movl	$0x8, %esi
    3355:      	callq	*%rax
    3357:      	testl	%eax, %eax
    3359:      	js	0x33f3 <try_preload_arg+0x783>
    335f:      	cmpw	$0x0, 0x46(%r15)
    3365:      	je	0x34d7 <try_preload_arg+0x867>
    336b:      	movl	0x40(%r15), %ecx
    336f:      	addq	0x8(%rsp), %rcx
    3374:      	movq	%rcx, 0x8(%rsp)
    3379:      	cmpw	$0x0, 0x44(%r15)
    337f:      	je	0x33a5 <try_preload_arg+0x735>
    3381:      	leaq	0x8(%rsp), %rdi
    3386:      	movl	$0x8, %edx
    338b:      	movl	$0x94, %eax
    3390:      	movq	0x8(%rsp), %rdx
    3395:      	movl	$0x8, %esi
    339a:      	callq	*%rax
    339c:      	movl	$0x9, %ebp
    33a1:      	testl	%eax, %eax
    33a3:      	js	0x33f3 <try_preload_arg+0x783>
    33a5:      	cmpw	$0x0, 0x4e(%r15)
    33ab:      	je	0x34d7 <try_preload_arg+0x867>
    33b1:      	movl	0x48(%r15), %ecx
    33b5:      	addq	0x8(%rsp), %rcx
    33ba:      	movq	%rcx, 0x8(%rsp)
    33bf:      	cmpw	$0x0, 0x4c(%r15)
    33c5:      	je	0x34d7 <try_preload_arg+0x867>
    33cb:      	leaq	0x8(%rsp), %rdi
    33d0:      	movl	$0x8, %edx
    33d5:      	movl	$0x94, %eax
    33da:      	movq	0x8(%rsp), %rdx
    33df:      	movl	$0x8, %esi
    33e4:      	callq	*%rax
    33e6:      	movl	$0xa, %ebp
    33eb:      	testl	%eax, %eax
    33ed:      	jns	0x34d7 <try_preload_arg+0x867>
    33f3:      	movl	%ebp, 0x10(%rsp)
    33f7:      	jmp	0x34d7 <try_preload_arg+0x867>
    33fc:      	leaq	-0x32e3(%rip), %rsi     # 0x120 <extract_arg_depth>
    3403:      	xorl	%ecx, %ecx
    3405:      	leaq	0x18(%rsp), %rdx
    340a:      	movl	$0xa, %edi
    340f:      	movl	$0xb5, %eax
    3414:      	movl	$0xa, %edi
    3419:      	xorl	%ecx, %ecx
    341b:      	callq	*%rax
    341d:      	cmpl	$0x6, %ebp
    3420:      	jne	0x2c8e <try_preload_arg+0x1e>
    3426:      	movq	0x8(%rsp), %rbx
    342b:      	movl	0x10(%rsp), %ebp
    342f:      	movl	$0xe, %eax
    3434:      	callq	*%rax
    3436:      	movq	%rax, 0x18(%rsp)
    343b:      	movl	$0x0, 0x14(%rsp)
    3443:      	movq	(%rip), %rdi            # 0x344a <try_preload_arg+0x7da>
    344a:      	leaq	0x14(%rsp), %rsi
    344f:      	movl	$0x1, %eax
    3454:      	callq	*%rax
    3456:      	testq	%rax, %rax
    3459:      	je	0x2c8e <try_preload_arg+0x1e>
    345f:      	movq	%rax, %rdx
    3462:      	movq	(%rip), %r14            # 0x3469 <try_preload_arg+0x7f9>
    3469:      	xorl	%ecx, %ecx
    346b:      	leaq	0x18(%rsp), %r15
    3470:      	movl	$0x2, %eax
    3475:      	movq	%r14, %rdi
    3478:      	movq	%r15, %rsi
    347b:      	xorl	%ecx, %ecx
    347d:      	callq	*%rax
    347f:      	movl	$0x1, %eax
    3484:      	movq	%r14, %rdi
    3487:      	movq	%r15, %rsi
    348a:      	callq	*%rax
    348c:      	testq	%rax, %rax
    348f:      	je	0x2c8e <try_preload_arg+0x1e>
    3495:      	testl	%ebp, %ebp
    3497:      	jne	0x359f <try_preload_arg+0x92f>
    349d:      	movq	%rax, %rdi
    34a0:      	addq	$0x4, %rdi
    34a4:      	movl	$0x1000, %ecx           # imm = 0x1000
    34a9:      	movq	%rax, %r14
    34ac:      	movl	$0x72, %eax
    34b1:      	jmp	0x3585 <try_preload_arg+0x915>
    34b6:      	leaq	-0x339d(%rip), %rsi     # 0x120 <extract_arg_depth>
    34bd:      	xorl	%ecx, %ecx
    34bf:      	leaq	0x18(%rsp), %rdx
    34c4:      	movl	$0xa, %edi
    34c9:      	movl	$0xb5, %eax
    34ce:      	movl	$0xa, %edi
    34d3:      	xorl	%ecx, %ecx
    34d5:      	callq	*%rax
    34d7:      	movl	0x4(%r14,%rbx,4), %ebx
    34dc:      	leaq	0x8(%rsp), %rdi
    34e1:      	movl	$0x8, %ecx
    34e6:      	movl	$0x4, %eax
    34eb:      	movl	$0x8, %esi
    34f0:      	movq	%rdi, %rdx
    34f3:      	callq	*%rax
    34f5:      	cmpl	$0x6, %ebx
    34f8:      	jne	0x2c8e <try_preload_arg+0x1e>
    34fe:      	movq	0x8(%rsp), %rbx
    3503:      	movl	0x10(%rsp), %ebp
    3507:      	movl	$0xe, %eax
    350c:      	callq	*%rax
    350e:      	movq	%rax, 0x18(%rsp)
    3513:      	movl	$0x0, 0x14(%rsp)
    351b:      	movq	(%rip), %rdi            # 0x3522 <try_preload_arg+0x8b2>
    3522:      	leaq	0x14(%rsp), %rsi
    3527:      	movl	$0x1, %eax
    352c:      	callq	*%rax
    352e:      	testq	%rax, %rax
    3531:      	je	0x2c8e <try_preload_arg+0x1e>
    3537:      	movq	%rax, %rdx
    353a:      	movq	(%rip), %r14            # 0x3541 <try_preload_arg+0x8d1>
    3541:      	xorl	%ecx, %ecx
    3543:      	leaq	0x18(%rsp), %r15
    3548:      	movl	$0x2, %eax
    354d:      	movq	%r14, %rdi
    3550:      	movq	%r15, %rsi
    3553:      	xorl	%ecx, %ecx
    3555:      	callq	*%rax
    3557:      	movl	$0x1, %eax
    355c:      	movq	%r14, %rdi
    355f:      	movq	%r15, %rsi
    3562:      	callq	*%rax
    3564:      	testq	%rax, %rax
    3567:      	je	0x2c8e <try_preload_arg+0x1e>
    356d:      	testl	%ebp, %ebp
    356f:      	jne	0x359f <try_preload_arg+0x92f>
    3571:      	movq	%rax, %rdi
    3574:      	addq	$0x4, %rdi
    3578:      	movl	$0x1000, %ecx           # imm = 0x1000
    357d:      	movq	%rax, %r14
    3580:      	movl	$0x72, %eax
    3585:      	movl	$0x1000, %esi           # imm = 0x1000
    358a:      	movq	%rbx, %rdx
    358d:      	callq	*%rax
    358f:      	movq	%rax, %rcx
    3592:      	movq	%r14, %rax
    3595:      	testq	%rcx, %rcx
    3598:      	jns	0x359f <try_preload_arg+0x92f>
    359a:      	movl	$0xffffffff, %ebp       # imm = 0xFFFFFFFF
    359f:      	movl	%ebp, (%rax)
    35a1:      	jmp	0x2c8e <try_preload_arg+0x1e>
    35a6:      	nopw	%cs:(%rax,%rax)

00000000000035b0 <write_reg>:
    35b0:      	rorxl	$0x3, %esi, %eax
    35b6:      	cmpl	$0x7, %eax
    35b9:      	jle	0x360e <write_reg+0x5e>
    35bb:      	cmpl	$0xb, %eax
    35be:      	jle	0x3650 <write_reg+0xa0>
    35c4:      	cmpl	$0xd, %eax
    35c7:      	jle	0x3767 <write_reg+0x1b7>
    35cd:      	cmpl	$0xe, %eax
    35d0:      	je	0x3893 <write_reg+0x2e3>
    35d6:      	cmpl	$0x10, %eax
    35d9:      	je	0x37e2 <write_reg+0x232>
    35df:      	cmpl	$0x13, %eax
    35e2:      	jne	0x3abf <write_reg+0x50f>
    35e8:      	movzbl	%dl, %eax
    35eb:      	cmpl	$0x3, %eax
    35ee:      	jg	0x39d8 <write_reg+0x428>
    35f4:      	cmpl	$0x1, %eax
    35f7:      	je	0x3ab9 <write_reg+0x509>
    35fd:      	cmpl	$0x2, %eax
    3600:      	jne	0x3abf <write_reg+0x50f>
    3606:      	movw	%cx, 0x98(%rdi)
    360d:      	retq
    360e:      	cmpl	$0x3, %eax
    3611:      	jg	0x368a <write_reg+0xda>
    3613:      	cmpl	$0x1, %eax
    3616:      	jg	0x36fd <write_reg+0x14d>
    361c:      	testl	%eax, %eax
    361e:      	je	0x3808 <write_reg+0x258>
    3624:      	cmpl	$0x1, %eax
    3627:      	jne	0x3abf <write_reg+0x50f>
    362d:      	movzbl	%dl, %eax
    3630:      	cmpl	$0x3, %eax
    3633:      	jg	0x39f2 <write_reg+0x442>
    3639:      	cmpl	$0x1, %eax
    363c:      	je	0x3ac7 <write_reg+0x517>
    3642:      	cmpl	$0x2, %eax
    3645:      	jne	0x3abf <write_reg+0x50f>
    364b:      	movw	%cx, 0x8(%rdi)
    364f:      	retq
    3650:      	cmpl	$0x9, %eax
    3653:      	jg	0x36c8 <write_reg+0x118>
    3655:      	cmpl	$0x8, %eax
    3658:      	je	0x379c <write_reg+0x1ec>
    365e:      	cmpl	$0x9, %eax
    3661:      	jne	0x3abf <write_reg+0x50f>
    3667:      	movzbl	%dl, %eax
    366a:      	cmpl	$0x3, %eax
    366d:      	jg	0x3907 <write_reg+0x357>
    3673:      	cmpl	$0x1, %eax
    3676:      	je	0x3a6d <write_reg+0x4bd>
    367c:      	cmpl	$0x2, %eax
    367f:      	jne	0x3abf <write_reg+0x50f>
    3685:      	movw	%cx, 0x48(%rdi)
    3689:      	retq
    368a:      	cmpl	$0x5, %eax
    368d:      	jg	0x3732 <write_reg+0x182>
    3693:      	cmpl	$0x4, %eax
    3696:      	je	0x382a <write_reg+0x27a>
    369c:      	cmpl	$0x5, %eax
    369f:      	jne	0x3abf <write_reg+0x50f>
    36a5:      	movzbl	%dl, %eax
    36a8:      	cmpl	$0x3, %eax
    36ab:      	jg	0x3a09 <write_reg+0x459>
    36b1:      	cmpl	$0x1, %eax
    36b4:      	je	0x3acb <write_reg+0x51b>
    36ba:      	cmpl	$0x2, %eax
    36bd:      	jne	0x3abf <write_reg+0x50f>
    36c3:      	movw	%cx, 0x28(%rdi)
    36c7:      	retq
    36c8:      	cmpl	$0xa, %eax
    36cb:      	je	0x37bf <write_reg+0x20f>
    36d1:      	cmpl	$0xb, %eax
    36d4:      	jne	0x3abf <write_reg+0x50f>
    36da:      	movzbl	%dl, %eax
    36dd:      	cmpl	$0x3, %eax
    36e0:      	jg	0x391e <write_reg+0x36e>
    36e6:      	cmpl	$0x1, %eax
    36e9:      	je	0x3a71 <write_reg+0x4c1>
    36ef:      	cmpl	$0x2, %eax
    36f2:      	jne	0x3abf <write_reg+0x50f>
    36f8:      	movw	%cx, 0x58(%rdi)
    36fc:      	retq
    36fd:      	cmpl	$0x2, %eax
    3700:      	je	0x384d <write_reg+0x29d>
    3706:      	cmpl	$0x3, %eax
    3709:      	jne	0x3abf <write_reg+0x50f>
    370f:      	movzbl	%dl, %eax
    3712:      	cmpl	$0x3, %eax
    3715:      	jg	0x3a20 <write_reg+0x470>
    371b:      	cmpl	$0x1, %eax
    371e:      	je	0x3acf <write_reg+0x51f>
    3724:      	cmpl	$0x2, %eax
    3727:      	jne	0x3abf <write_reg+0x50f>
    372d:      	movw	%cx, 0x18(%rdi)
    3731:      	retq
    3732:      	cmpl	$0x6, %eax
    3735:      	je	0x3870 <write_reg+0x2c0>
    373b:      	cmpl	$0x7, %eax
    373e:      	jne	0x3abf <write_reg+0x50f>
    3744:      	movzbl	%dl, %eax
    3747:      	cmpl	$0x3, %eax
    374a:      	jg	0x3a37 <write_reg+0x487>
    3750:      	cmpl	$0x1, %eax
    3753:      	je	0x3ad3 <write_reg+0x523>
    3759:      	cmpl	$0x2, %eax
    375c:      	jne	0x3abf <write_reg+0x50f>
    3762:      	movw	%cx, 0x38(%rdi)
    3766:      	retq
    3767:      	cmpl	$0xc, %eax
    376a:      	je	0x38b6 <write_reg+0x306>
    3770:      	cmpl	$0xd, %eax
    3773:      	jne	0x3abf <write_reg+0x50f>
    3779:      	movzbl	%dl, %eax
    377c:      	cmpl	$0x3, %eax
    377f:      	jg	0x3a4a <write_reg+0x49a>
    3785:      	cmpl	$0x1, %eax
    3788:      	je	0x3ae7 <write_reg+0x537>
    378e:      	cmpl	$0x2, %eax
    3791:      	jne	0x3abf <write_reg+0x50f>
    3797:      	movw	%cx, 0x68(%rdi)
    379b:      	retq
    379c:      	movzbl	%dl, %eax
    379f:      	cmpl	$0x3, %eax
    37a2:      	jg	0x38d9 <write_reg+0x329>
    37a8:      	cmpl	$0x1, %eax
    37ab:      	je	0x3a5d <write_reg+0x4ad>
    37b1:      	cmpl	$0x2, %eax
    37b4:      	jne	0x3abf <write_reg+0x50f>
    37ba:      	movw	%cx, 0x40(%rdi)
    37be:      	retq
    37bf:      	movzbl	%dl, %eax
    37c2:      	cmpl	$0x3, %eax
    37c5:      	jg	0x38f0 <write_reg+0x340>
    37cb:      	cmpl	$0x1, %eax
    37ce:      	je	0x3a61 <write_reg+0x4b1>
    37d4:      	cmpl	$0x2, %eax
    37d7:      	jne	0x3abf <write_reg+0x50f>
    37dd:      	movw	%cx, 0x50(%rdi)
    37e1:      	retq
    37e2:      	movzbl	%dl, %eax
    37e5:      	cmpl	$0x3, %eax
    37e8:      	jg	0x3935 <write_reg+0x385>
    37ee:      	cmpl	$0x1, %eax
    37f1:      	je	0x3a7d <write_reg+0x4cd>
    37f7:      	cmpl	$0x2, %eax
    37fa:      	jne	0x3abf <write_reg+0x50f>
    3800:      	movw	%cx, 0x80(%rdi)
    3807:      	retq
    3808:      	movzbl	%dl, %eax
    380b:      	cmpl	$0x3, %eax
    380e:      	jg	0x394f <write_reg+0x39f>
    3814:      	cmpl	$0x1, %eax
    3817:      	je	0x3a8b <write_reg+0x4db>
    381d:      	cmpl	$0x2, %eax
    3820:      	jne	0x3abf <write_reg+0x50f>
    3826:      	movw	%cx, (%rdi)
    3829:      	retq
    382a:      	movzbl	%dl, %eax
    382d:      	cmpl	$0x3, %eax
    3830:      	jg	0x3965 <write_reg+0x3b5>
    3836:      	cmpl	$0x1, %eax
    3839:      	je	0x3a8e <write_reg+0x4de>
    383f:      	cmpl	$0x2, %eax
    3842:      	jne	0x3abf <write_reg+0x50f>
    3848:      	movw	%cx, 0x20(%rdi)
    384c:      	retq
    384d:      	movzbl	%dl, %eax
    3850:      	cmpl	$0x3, %eax
    3853:      	jg	0x397c <write_reg+0x3cc>
    3859:      	cmpl	$0x1, %eax
    385c:      	je	0x3a92 <write_reg+0x4e2>
    3862:      	cmpl	$0x2, %eax
    3865:      	jne	0x3abf <write_reg+0x50f>
    386b:      	movw	%cx, 0x10(%rdi)
    386f:      	retq
    3870:      	movzbl	%dl, %eax
    3873:      	cmpl	$0x3, %eax
    3876:      	jg	0x3993 <write_reg+0x3e3>
    387c:      	cmpl	$0x1, %eax
    387f:      	je	0x3a96 <write_reg+0x4e6>
    3885:      	cmpl	$0x2, %eax
    3888:      	jne	0x3abf <write_reg+0x50f>
    388e:      	movw	%cx, 0x30(%rdi)
    3892:      	retq
    3893:      	movzbl	%dl, %eax
    3896:      	cmpl	$0x3, %eax
    3899:      	jg	0x39aa <write_reg+0x3fa>
    389f:      	cmpl	$0x1, %eax
    38a2:      	je	0x3aa9 <write_reg+0x4f9>
    38a8:      	cmpl	$0x2, %eax
    38ab:      	jne	0x3abf <write_reg+0x50f>
    38b1:      	movw	%cx, 0x70(%rdi)
    38b5:      	retq
    38b6:      	movzbl	%dl, %eax
    38b9:      	cmpl	$0x3, %eax
    38bc:      	jg	0x39c1 <write_reg+0x411>
    38c2:      	cmpl	$0x1, %eax
    38c5:      	je	0x3ab1 <write_reg+0x501>
    38cb:      	cmpl	$0x2, %eax
    38ce:      	jne	0x3abf <write_reg+0x50f>
    38d4:      	movw	%cx, 0x60(%rdi)
    38d8:      	retq
    38d9:      	cmpl	$0x4, %eax
    38dc:      	je	0x3a65 <write_reg+0x4b5>
    38e2:      	cmpl	$0x8, %eax
    38e5:      	jne	0x3abf <write_reg+0x50f>
    38eb:      	movq	%rcx, 0x40(%rdi)
    38ef:      	retq
    38f0:      	cmpl	$0x4, %eax
    38f3:      	je	0x3a69 <write_reg+0x4b9>
    38f9:      	cmpl	$0x8, %eax
    38fc:      	jne	0x3abf <write_reg+0x50f>
    3902:      	movq	%rcx, 0x50(%rdi)
    3906:      	retq
    3907:      	cmpl	$0x4, %eax
    390a:      	je	0x3a75 <write_reg+0x4c5>
    3910:      	cmpl	$0x8, %eax
    3913:      	jne	0x3abf <write_reg+0x50f>
    3919:      	movq	%rcx, 0x48(%rdi)
    391d:      	retq
    391e:      	cmpl	$0x4, %eax
    3921:      	je	0x3a79 <write_reg+0x4c9>
    3927:      	cmpl	$0x8, %eax
    392a:      	jne	0x3abf <write_reg+0x50f>
    3930:      	movq	%rcx, 0x58(%rdi)
    3934:      	retq
    3935:      	cmpl	$0x4, %eax
    3938:      	je	0x3a84 <write_reg+0x4d4>
    393e:      	cmpl	$0x8, %eax
    3941:      	jne	0x3abf <write_reg+0x50f>
    3947:      	movq	%rcx, 0x80(%rdi)
    394e:      	retq
    394f:      	cmpl	$0x4, %eax
    3952:      	je	0x3a9a <write_reg+0x4ea>
    3958:      	cmpl	$0x8, %eax
    395b:      	jne	0x3abf <write_reg+0x50f>
    3961:      	movq	%rcx, (%rdi)
    3964:      	retq
    3965:      	cmpl	$0x4, %eax
    3968:      	je	0x3a9d <write_reg+0x4ed>
    396e:      	cmpl	$0x8, %eax
    3971:      	jne	0x3abf <write_reg+0x50f>
    3977:      	movq	%rcx, 0x20(%rdi)
    397b:      	retq
    397c:      	cmpl	$0x4, %eax
    397f:      	je	0x3aa1 <write_reg+0x4f1>
    3985:      	cmpl	$0x8, %eax
    3988:      	jne	0x3abf <write_reg+0x50f>
    398e:      	movq	%rcx, 0x10(%rdi)
    3992:      	retq
    3993:      	cmpl	$0x4, %eax
    3996:      	je	0x3aa5 <write_reg+0x4f5>
    399c:      	cmpl	$0x8, %eax
    399f:      	jne	0x3abf <write_reg+0x50f>
    39a5:      	movq	%rcx, 0x30(%rdi)
    39a9:      	retq
    39aa:      	cmpl	$0x4, %eax
    39ad:      	je	0x3aad <write_reg+0x4fd>
    39b3:      	cmpl	$0x8, %eax
    39b6:      	jne	0x3abf <write_reg+0x50f>
    39bc:      	movq	%rcx, 0x70(%rdi)
    39c0:      	retq
    39c1:      	cmpl	$0x4, %eax
    39c4:      	je	0x3ab5 <write_reg+0x505>
    39ca:      	cmpl	$0x8, %eax
    39cd:      	jne	0x3abf <write_reg+0x50f>
    39d3:      	movq	%rcx, 0x60(%rdi)
    39d7:      	retq
    39d8:      	cmpl	$0x4, %eax
    39db:      	je	0x3ac0 <write_reg+0x510>
    39e1:      	cmpl	$0x8, %eax
    39e4:      	jne	0x3abf <write_reg+0x50f>
    39ea:      	movq	%rcx, 0x98(%rdi)
    39f1:      	retq
    39f2:      	cmpl	$0x4, %eax
    39f5:      	je	0x3ad7 <write_reg+0x527>
    39fb:      	cmpl	$0x8, %eax
    39fe:      	jne	0x3abf <write_reg+0x50f>
    3a04:      	movq	%rcx, 0x8(%rdi)
    3a08:      	retq
    3a09:      	cmpl	$0x4, %eax
    3a0c:      	je	0x3adb <write_reg+0x52b>
    3a12:      	cmpl	$0x8, %eax
    3a15:      	jne	0x3abf <write_reg+0x50f>
    3a1b:      	movq	%rcx, 0x28(%rdi)
    3a1f:      	retq
    3a20:      	cmpl	$0x4, %eax
    3a23:      	je	0x3adf <write_reg+0x52f>
    3a29:      	cmpl	$0x8, %eax
    3a2c:      	jne	0x3abf <write_reg+0x50f>
    3a32:      	movq	%rcx, 0x18(%rdi)
    3a36:      	retq
    3a37:      	cmpl	$0x4, %eax
    3a3a:      	je	0x3ae3 <write_reg+0x533>
    3a40:      	cmpl	$0x8, %eax
    3a43:      	jne	0x3abf <write_reg+0x50f>
    3a45:      	movq	%rcx, 0x38(%rdi)
    3a49:      	retq
    3a4a:      	cmpl	$0x4, %eax
    3a4d:      	je	0x3aeb <write_reg+0x53b>
    3a53:      	cmpl	$0x8, %eax
    3a56:      	jne	0x3abf <write_reg+0x50f>
    3a58:      	movq	%rcx, 0x68(%rdi)
    3a5c:      	retq
    3a5d:      	movb	%cl, 0x40(%rdi)
    3a60:      	retq
    3a61:      	movb	%cl, 0x50(%rdi)
    3a64:      	retq
    3a65:      	movl	%ecx, 0x40(%rdi)
    3a68:      	retq
    3a69:      	movl	%ecx, 0x50(%rdi)
    3a6c:      	retq
    3a6d:      	movb	%cl, 0x48(%rdi)
    3a70:      	retq
    3a71:      	movb	%cl, 0x58(%rdi)
    3a74:      	retq
    3a75:      	movl	%ecx, 0x48(%rdi)
    3a78:      	retq
    3a79:      	movl	%ecx, 0x58(%rdi)
    3a7c:      	retq
    3a7d:      	movb	%cl, 0x80(%rdi)
    3a83:      	retq
    3a84:      	movl	%ecx, 0x80(%rdi)
    3a8a:      	retq
    3a8b:      	movb	%cl, (%rdi)
    3a8d:      	retq
    3a8e:      	movb	%cl, 0x20(%rdi)
    3a91:      	retq
    3a92:      	movb	%cl, 0x10(%rdi)
    3a95:      	retq
    3a96:      	movb	%cl, 0x30(%rdi)
    3a99:      	retq
    3a9a:      	movl	%ecx, (%rdi)
    3a9c:      	retq
    3a9d:      	movl	%ecx, 0x20(%rdi)
    3aa0:      	retq
    3aa1:      	movl	%ecx, 0x10(%rdi)
    3aa4:      	retq
    3aa5:      	movl	%ecx, 0x30(%rdi)
    3aa8:      	retq
    3aa9:      	movb	%cl, 0x70(%rdi)
    3aac:      	retq
    3aad:      	movl	%ecx, 0x70(%rdi)
    3ab0:      	retq
    3ab1:      	movb	%cl, 0x60(%rdi)
    3ab4:      	retq
    3ab5:      	movl	%ecx, 0x60(%rdi)
    3ab8:      	retq
    3ab9:      	movb	%cl, 0x98(%rdi)
    3abf:      	retq
    3ac0:      	movl	%ecx, 0x98(%rdi)
    3ac6:      	retq
    3ac7:      	movb	%cl, 0x8(%rdi)
    3aca:      	retq
    3acb:      	movb	%cl, 0x28(%rdi)
    3ace:      	retq
    3acf:      	movb	%cl, 0x18(%rdi)
    3ad2:      	retq
    3ad3:      	movb	%cl, 0x38(%rdi)
    3ad6:      	retq
    3ad7:      	movl	%ecx, 0x8(%rdi)
    3ada:      	retq
    3adb:      	movl	%ecx, 0x28(%rdi)
    3ade:      	retq
    3adf:      	movl	%ecx, 0x18(%rdi)
    3ae2:      	retq
    3ae3:      	movl	%ecx, 0x38(%rdi)
    3ae6:      	retq
    3ae7:      	movb	%cl, 0x68(%rdi)
    3aea:      	retq
    3aeb:      	movl	%ecx, 0x68(%rdi)
    3aee:      	retq

Disassembly of section uprobe:

0000000000000000 <generic_uprobe_setup_event>:
       0:      	pushq	%r15
       2:      	pushq	%r14
       4:      	pushq	%rbx
       5:      	subq	$0x40, %rsp
       9:      	movq	%rdi, %rbx
       c:      	movl	$0x0, 0x1c(%rsp)
      14:      	movq	(%rip), %rdi            # 0x1b <generic_uprobe_setup_event+0x1b>
      1b:      	leaq	0x1c(%rsp), %rsi
      20:      	movl	$0x1, %eax
      25:      	callq	*%rax
      27:      	testq	%rax, %rax
      2a:      	je	0x28e <generic_uprobe_setup_event+0x28e>
      30:      	movq	%rax, %r14
      33:      	leaq	0x5ef8(%rax), %rsi
      3a:      	movq	(%rip), %rdi            # 0x41 <generic_uprobe_setup_event+0x41>
      41:      	movl	$0x1, %eax
      46:      	callq	*%rax
      48:      	testq	%rax, %rax
      4b:      	je	0x28e <generic_uprobe_setup_event+0x28e>
      51:      	movq	%rax, %r15
      54:      	leaq	0x70(%rbx), %rdx
      58:      	movq	%rsp, %rdi
      5b:      	movl	$0x8, %ecx
      60:      	movl	$0x4, %eax
      65:      	movl	$0x8, %esi
      6a:      	callq	*%rax
      6c:      	movq	(%rsp), %rax
      70:      	movq	%rax, 0x5e50(%r14)
      77:      	leaq	0x68(%rbx), %rdx
      7b:      	movq	%rsp, %rdi
      7e:      	movl	$0x8, %ecx
      83:      	movl	$0x4, %eax
      88:      	movl	$0x8, %esi
      8d:      	callq	*%rax
      8f:      	movq	(%rsp), %rax
      93:      	movq	%rax, 0x5e58(%r14)
      9a:      	leaq	0x60(%rbx), %rdx
      9e:      	movq	%rsp, %rdi
      a1:      	movl	$0x8, %ecx
      a6:      	movl	$0x4, %eax
      ab:      	movl	$0x8, %esi
      b0:      	callq	*%rax
      b2:      	movq	(%rsp), %rax
      b6:      	movq	%rax, 0x5e60(%r14)
      bd:      	leaq	0x58(%rbx), %rdx
      c1:      	movq	%rsp, %rdi
      c4:      	movl	$0x8, %ecx
      c9:      	movl	$0x4, %eax
      ce:      	movl	$0x8, %esi
      d3:      	callq	*%rax
      d5:      	movq	(%rsp), %rax
      d9:      	movq	%rax, 0x5e68(%r14)
      e0:      	leaq	0x48(%rbx), %rdx
      e4:      	movq	%rsp, %rdi
      e7:      	movl	$0x8, %ecx
      ec:      	movl	$0x4, %eax
      f1:      	movl	$0x8, %esi
      f6:      	callq	*%rax
      f8:      	movq	(%rsp), %rax
      fc:      	movq	%rax, 0x5e70(%r14)
     103:      	movb	$0xf, (%r14)
     107:      	movw	$0x0, 0x2(%r14)
     10e:      	movl	$0x0, 0x4(%r14)
     116:      	movl	$0x7d, %eax
     11b:      	callq	*%rax
     11d:      	movq	%rax, 0x8(%r14)
     121:      	movq	$0x0, 0x70(%r14)
     129:      	movl	$0x0, 0x14(%r14)
     131:      	movl	$0xe, %eax
     136:      	callq	*%rax
     138:      	movl	%eax, 0x7c(%r14)
     13c:      	movl	$0xe, %eax
     141:      	callq	*%rax
     143:      	cmpq	$-0x16, %rax
     147:      	jne	0x165 <generic_uprobe_setup_event+0x165>
     149:      	leaq	0x20(%rbx), %rdx
     14d:      	movq	%rsp, %rdi
     150:      	movl	$0x8, %ecx
     155:      	movl	$0x4, %eax
     15a:      	movl	$0x8, %esi
     15f:      	callq	*%rax
     161:      	movq	(%rsp), %rax
     165:      	movq	%rax, 0x68(%r14)
     169:      	cmpl	$0x0, 0x5c(%r15)
     16e:      	jle	0x218 <generic_uprobe_setup_event+0x218>
     174:      	movq	0x8(%r14), %rcx
     178:      	movq	0x60(%r14), %rdx
     17c:      	movq	%rcx, (%rsp)
     180:      	movq	$0x1, 0x8(%rsp)
     189:      	movq	$0x0, 0x10(%rsp)
     192:      	movq	%rdx, 0x30(%rsp)
     197:      	movq	%rax, 0x38(%rsp)
     19c:      	movq	(%rip), %rdi            # 0x1a3 <generic_uprobe_setup_event+0x1a3>
     1a3:      	xorl	%ecx, %ecx
     1a5:      	leaq	0x30(%rsp), %rsi
     1aa:      	movq	%rsp, %rdx
     1ad:      	movl	$0x2, %eax
     1b2:      	xorl	%ecx, %ecx
     1b4:      	callq	*%rax
     1b6:      	testq	%rax, %rax
     1b9:      	je	0x218 <generic_uprobe_setup_event+0x218>
     1bb:      	negl	%eax
     1bd:      	movw	%ax, 0x24(%rsp)
     1c2:      	movw	$0x5, 0x26(%rsp)
     1c9:      	movabsq	$0x200000046, %rax      # imm = 0x200000046
     1d3:      	movq	%rax, 0x28(%rsp)
     1d8:      	movq	(%rip), %rdi            # 0x1df <generic_uprobe_setup_event+0x1df>
     1df:      	leaq	0x24(%rsp), %rsi
     1e4:      	movl	$0x1, %eax
     1e9:      	callq	*%rax
     1eb:      	testq	%rax, %rax
     1ee:      	je	0x1f4 <generic_uprobe_setup_event+0x1f4>
     1f0:      	incl	(%rax)
     1f2:      	jmp	0x218 <generic_uprobe_setup_event+0x218>
     1f4:      	movl	$0x1, 0x20(%rsp)
     1fc:      	movq	(%rip), %rdi            # 0x203 <generic_uprobe_setup_event+0x203>
     203:      	xorl	%ecx, %ecx
     205:      	leaq	0x24(%rsp), %rsi
     20a:      	leaq	0x20(%rsp), %rdx
     20f:      	movl	$0x2, %eax
     214:      	xorl	%ecx, %ecx
     216:      	callq	*%rax
     218:      	movl	$0x0, (%rsp)
     21f:      	movq	(%rip), %rdi            # 0x226 <generic_uprobe_setup_event+0x226>
     226:      	movq	%rsp, %rsi
     229:      	movl	$0x1, %eax
     22e:      	callq	*%rax
     230:      	testq	%rax, %rax
     233:      	je	0x258 <generic_uprobe_setup_event+0x258>
     235:      	movq	%rax, %rsi
     238:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     23f:      	movq	(%rip), %rdi            # 0x246 <generic_uprobe_setup_event+0x246>
     246:      	movl	$0x1, %eax
     24b:      	callq	*%rax
     24d:      	testq	%rax, %rax
     250:      	je	0x258 <generic_uprobe_setup_event+0x258>
     252:      	cmpl	$-0x1, 0x40(%rax)
     256:      	jne	0x273 <generic_uprobe_setup_event+0x273>
     258:      	movq	(%rip), %rsi            # 0x25f <generic_uprobe_setup_event+0x25f>
     25f:      	movl	$0x3, %ecx
     264:      	movl	$0xc, %eax
     269:      	movq	%rbx, %rdi
     26c:      	movl	$0x3, %edx
     271:      	callq	*%rax
     273:      	movq	(%rip), %rsi            # 0x27a <generic_uprobe_setup_event+0x27a>
     27a:      	movl	$0x1, %ecx
     27f:      	movl	$0xc, %eax
     284:      	movq	%rbx, %rdi
     287:      	movl	$0x1, %edx
     28c:      	callq	*%rax
     28e:      	xorl	%eax, %eax
     290:      	addq	$0x40, %rsp
     294:      	popq	%rbx
     295:      	popq	%r14
     297:      	popq	%r15
     299:      	retq
     29a:      	nopw	(%rax,%rax)

00000000000002a0 <generic_uprobe_process_event>:
     2a0:      	pushq	%rbp
     2a1:      	pushq	%r15
     2a3:      	pushq	%r14
     2a5:      	pushq	%r13
     2a7:      	pushq	%r12
     2a9:      	pushq	%rbx
     2aa:      	subq	$0x118, %rsp            # imm = 0x118
     2b1:      	movq	%rdi, %r14
     2b4:      	movl	$0x0, 0xfc(%rsp)
     2bf:      	movq	(%rip), %rdi            # 0x2c6 <generic_uprobe_process_event+0x26>
     2c6:      	leaq	0xfc(%rsp), %rsi
     2ce:      	movl	$0x1, %eax
     2d3:      	callq	*%rax
     2d5:      	testq	%rax, %rax
     2d8:      	je	0x1711 <generic_uprobe_process_event+0x1471>
     2de:      	movq	%rax, %rbx
     2e1:      	movl	0x5efc(%rax), %r13d
     2e8:      	movl	0x4(%rax), %ebp
     2eb:      	cmpq	$0x2327, %rbp           # imm = 0x2327
     2f2:      	ja	0x1674 <generic_uprobe_process_event+0x13d4>
     2f8:      	movl	$0x0, 0x100(%rsp)
     303:      	movq	(%rip), %rdi            # 0x30a <generic_uprobe_process_event+0x6a>
     30a:      	leaq	0x100(%rsp), %rsi
     312:      	movl	$0x1, %eax
     317:      	callq	*%rax
     319:      	testq	%rax, %rax
     31c:      	je	0x1674 <generic_uprobe_process_event+0x13d4>
     322:      	movq	%rax, %r15
     325:      	leaq	0x5ef8(%rax), %rsi
     32c:      	movq	(%rip), %rdi            # 0x333 <generic_uprobe_process_event+0x93>
     333:      	movl	$0x1, %eax
     338:      	callq	*%rax
     33a:      	cmpl	$0x4, %r13d
     33e:      	jg	0x1674 <generic_uprobe_process_event+0x13d4>
     344:      	testq	%rax, %rax
     347:      	je	0x1674 <generic_uprobe_process_event+0x13d4>
     34d:      	movq	%rbp, 0x18(%rsp)
     352:      	movl	%r13d, %ecx
     355:      	andl	$0x7, %ecx
     358:      	movq	%rcx, %rdx
     35b:      	movq	%rcx, 0xd8(%rsp)
     363:      	movl	%ecx, %ecx
     365:      	movl	0x4(%rax,%rcx,4), %r12d
     36a:      	movslq	0x18(%rax,%rcx,4), %rdx
     36f:      	movl	%edx, %esi
     371:      	leaq	(%r15,%rcx,4), %rbp
     375:      	addq	$0x5ea0, %rbp           # imm = 0x5EA0
     37c:      	movl	$0x0, 0x5ea0(%r15,%rcx,4)
     388:      	movq	%rdx, 0x30(%rsp)
     38d:      	testl	$0x100, %edx            # imm = 0x100
     393:      	movq	%rsi, 0xb0(%rsp)
     39b:      	jne	0x3e3 <generic_uprobe_process_event+0x143>
     39d:      	testb	%sil, %sil
     3a0:      	movq	%r13, 0xc0(%rsp)
     3a8:      	js	0x455 <generic_uprobe_process_event+0x1b5>
     3ae:      	movq	%rbx, %r13
     3b1:      	movq	%r14, %rbx
     3b4:      	testb	$0x40, 0x30(%rsp)
     3b9:      	jne	0x4b4 <generic_uprobe_process_event+0x214>
     3bf:      	movq	0xd8(%rsp), %rdx
     3c7:      	movl	0x40(%rax,%rdx,4), %ecx
     3cb:      	andl	$0x7, %ecx
     3ce:      	movq	0x5e50(%r15,%rcx,8), %rsi
     3d6:      	movq	%rsi, 0xe8(%rsp)
     3de:      	jmp	0x4f3 <generic_uprobe_process_event+0x253>
     3e3:      	movq	$0x0, 0x58(%rsp)
     3ec:      	movl	$0xe, %eax
     3f1:      	callq	*%rax
     3f3:      	movq	%rax, 0x98(%rsp)
     3fb:      	movq	(%rip), %rdi            # 0x402 <generic_uprobe_process_event+0x162>
     402:      	leaq	0x98(%rsp), %rsi
     40a:      	movl	$0x1, %eax
     40f:      	callq	*%rax
     411:      	testq	%rax, %rax
     414:      	je	0x443 <generic_uprobe_process_event+0x1a3>
     416:      	movl	(%rax), %ecx
     418:      	movl	%ecx, (%rbp)
     41b:      	cmpl	$0x6, %r12d
     41f:      	jne	0x443 <generic_uprobe_process_event+0x1a3>
     421:      	addq	$0x4, %rax
     425:      	movq	%rax, 0x58(%rsp)
     42a:      	leaq	0x58(%rsp), %rdi
     42f:      	movl	$0x8, %ecx
     434:      	movl	$0x4, %eax
     439:      	movl	$0x8, %esi
     43e:      	movq	%rdi, %rdx
     441:      	callq	*%rax
     443:      	movq	0x58(%rsp), %rsi
     448:      	movq	%rsi, 0xe8(%rsp)
     450:      	jmp	0x5f0 <generic_uprobe_process_event+0x350>
     455:      	movq	0xd8(%rsp), %rdx
     45d:      	movzbl	0x2c2(%rax,%rdx,4), %ecx
     465:      	shlb	$0x3, %cl
     468:      	movb	$0x40, %r15b
     46b:      	subb	%cl, %r15b
     46e:      	cmpl	$0x0, 0x54(%rax)
     472:      	movzwl	0x2c0(%rax,%rdx,4), %edx
     47a:      	movq	%rbx, %r13
     47d:      	je	0x4c0 <generic_uprobe_process_event+0x220>
     47f:      	testq	%r14, %r14
     482:      	je	0x4de <generic_uprobe_process_event+0x23e>
     484:      	movq	%r14, %rbx
     487:      	addq	%r14, %rdx
     48a:      	leaq	0x58(%rsp), %rdi
     48f:      	movl	$0x8, %ecx
     494:      	movq	%rax, %r14
     497:      	movl	$0x4, %eax
     49c:      	movl	$0x8, %esi
     4a1:      	callq	*%rax
     4a3:      	movq	%r14, %rax
     4a6:      	shlxq	%r15, 0x58(%rsp), %rcx
     4ad:      	sarxq	%r15, %rcx, %rsi
     4b2:      	jmp	0x4e3 <generic_uprobe_process_event+0x243>
     4b4:      	movq	%rax, %r14
     4b7:      	movl	$0x23, %eax
     4bc:      	callq	*%rax
     4be:      	jmp	0x4d6 <generic_uprobe_process_event+0x236>
     4c0:      	movzbl	%r15b, %ecx
     4c4:      	movq	%r14, %rbx
     4c7:      	movq	%r14, %rdi
     4ca:      	movl	%edx, %esi
     4cc:      	movl	%ecx, %edx
     4ce:      	movq	%rax, %r14
     4d1:      	callq	0x4d6 <generic_uprobe_process_event+0x236>
     4d6:      	movq	%rax, %rsi
     4d9:      	movq	%r14, %rax
     4dc:      	jmp	0x4e3 <generic_uprobe_process_event+0x243>
     4de:      	movq	%r14, %rbx
     4e1:      	xorl	%esi, %esi
     4e3:      	movq	%rsi, 0xe8(%rsp)
     4eb:      	movq	0xd8(%rsp), %rdx
     4f3:      	cmpl	$0x4, %edx
     4f6:      	jbe	0x50b <generic_uprobe_process_event+0x26b>
     4f8:      	movq	%rbx, %r14
     4fb:      	movq	%r13, %rbx
     4fe:      	movq	0xc0(%rsp), %r13
     506:      	jmp	0x5f0 <generic_uprobe_process_event+0x350>
     50b:      	leaq	(%rdx,%rdx,4), %rcx
     50f:      	shll	$0x4, %ecx
     512:      	cmpw	$0x0, 0x76(%rax,%rcx)
     518:      	movq	%rbx, %r14
     51b:      	movq	%r13, %rbx
     51e:      	movq	0xc0(%rsp), %r13
     526:      	je	0x5f0 <generic_uprobe_process_event+0x350>
     52c:      	addq	%rcx, %rax
     52f:      	addq	$0x70, %rax
     533:      	movq	%rax, 0x58(%rsp)
     538:      	leaq	0xe8(%rsp), %rax
     540:      	movq	%rax, 0x60(%rsp)
     545:      	movb	$0x0, 0x68(%rsp)
     54a:      	movq	%rbp, 0x70(%rsp)
     54f:      	movq	(%rip), %rax            # 0x556 <generic_uprobe_process_event+0x2b6>
     556:      	cmpb	$0x0, (%rax)
     559:      	je	0x5ba <generic_uprobe_process_event+0x31a>
     55b:      	xorl	%r15d, %r15d
     55e:      	movl	$0x8, %ebp
     563:      	jmp	0x586 <generic_uprobe_process_event+0x2e6>
     565:      	movl	$0x4, %eax
     56a:      	movq	0x60(%rsp), %rdi
     56f:      	movq	(%rdi), %rdx
     572:      	movl	$0x8, %esi
     577:      	callq	*%rax
     579:      	testl	%eax, %eax
     57b:      	js	0x5dd <generic_uprobe_process_event+0x33d>
     57d:      	incq	%r15
     580:      	cmpq	$0xa, %r15
     584:      	je	0x5e8 <generic_uprobe_process_event+0x348>
     586:      	movq	0x58(%rsp), %rax
     58b:      	cmpw	$0x0, 0x6(%rax,%r15,8)
     592:      	je	0x5e8 <generic_uprobe_process_event+0x348>
     594:      	movq	0x60(%rsp), %rcx
     599:      	movl	(%rax,%r15,8), %edx
     59d:      	addq	(%rcx), %rdx
     5a0:      	movq	%rdx, (%rcx)
     5a3:      	cmpw	$0x0, 0x4(%rax,%r15,8)
     5aa:      	je	0x57d <generic_uprobe_process_event+0x2dd>
     5ac:      	cmpb	$0x0, 0x68(%rsp)
     5b1:      	je	0x565 <generic_uprobe_process_event+0x2c5>
     5b3:      	movl	$0x94, %eax
     5b8:      	jmp	0x56a <generic_uprobe_process_event+0x2ca>
     5ba:      	leaq	(%rip), %rsi            # 0x5c1 <generic_uprobe_process_event+0x321>
     5c1:      	xorl	%ecx, %ecx
     5c3:      	leaq	0x58(%rsp), %rdx
     5c8:      	movl	$0xa, %edi
     5cd:      	movl	$0xb5, %eax
     5d2:      	movl	$0xa, %edi
     5d7:      	xorl	%ecx, %ecx
     5d9:      	callq	*%rax
     5db:      	jmp	0x5e8 <generic_uprobe_process_event+0x348>
     5dd:      	incl	%r15d
     5e0:      	movq	0x70(%rsp), %rax
     5e5:      	movl	%r15d, (%rax)
     5e8:      	movq	0xe8(%rsp), %rsi
     5f0:      	movq	%rsi, 0x20(%rsp)
     5f5:      	movl	$0x1000, %r15d          # imm = 0x1000
     5fb:      	cmpl	$0x15, %r12d
     5ff:      	jg	0x63d <generic_uprobe_process_event+0x39d>
     601:      	cmpl	$0xb, %r12d
     605:      	movq	0x18(%rsp), %rbp
     60a:      	jg	0x675 <generic_uprobe_process_event+0x3d5>
     60c:      	cmpl	$0x5, %r12d
     610:      	jg	0x700 <generic_uprobe_process_event+0x460>
     616:      	cmpl	$0x3, %r12d
     61a:      	jg	0x78a <generic_uprobe_process_event+0x4ea>
     620:      	leal	-0x2(%r12), %eax
     625:      	cmpl	$0x2, %eax
     628:      	jb	0x750 <generic_uprobe_process_event+0x4b0>
     62e:      	cmpl	$0x1, %r12d
     632:      	je	0x750 <generic_uprobe_process_event+0x4b0>
     638:      	jmp	0x7bc <generic_uprobe_process_event+0x51c>
     63d:      	cmpl	$0x20, %r12d
     641:      	movq	0x18(%rsp), %rbp
     646:      	jle	0x6a0 <generic_uprobe_process_event+0x400>
     648:      	cmpl	$0x27, %r12d
     64c:      	jg	0x6cd <generic_uprobe_process_event+0x42d>
     64e:      	leal	-0x21(%r12), %eax
     653:      	cmpl	$0x4, %eax
     656:      	jb	0x79e <generic_uprobe_process_event+0x4fe>
     65c:      	cmpl	$0x25, %r12d
     660:      	je	0x7bf <generic_uprobe_process_event+0x51f>
     666:      	cmpl	$0x27, %r12d
     66a:      	je	0x758 <generic_uprobe_process_event+0x4b8>
     670:      	jmp	0x7bc <generic_uprobe_process_event+0x51c>
     675:      	cmpl	$0x11, %r12d
     679:      	jg	0x729 <generic_uprobe_process_event+0x489>
     67f:      	leal	-0xf(%r12), %eax
     684:      	cmpl	$0x3, %eax
     687:      	jb	0x7bf <generic_uprobe_process_event+0x51f>
     68d:      	leal	-0xc(%r12), %eax
     692:      	cmpl	$0x2, %eax
     695:      	jb	0x750 <generic_uprobe_process_event+0x4b0>
     69b:      	jmp	0x7bc <generic_uprobe_process_event+0x51c>
     6a0:      	cmpl	$0x1a, %r12d
     6a4:      	jg	0x746 <generic_uprobe_process_event+0x4a6>
     6aa:      	cmpl	$0x16, %r12d
     6ae:      	je	0x758 <generic_uprobe_process_event+0x4b8>
     6b4:      	cmpl	$0x17, %r12d
     6b8:      	je	0x79e <generic_uprobe_process_event+0x4fe>
     6be:      	cmpl	$0x1a, %r12d
     6c2:      	je	0x7b4 <generic_uprobe_process_event+0x514>
     6c8:      	jmp	0x7bc <generic_uprobe_process_event+0x51c>
     6cd:      	cmpl	$0x29, %r12d
     6d1:      	jle	0x774 <generic_uprobe_process_event+0x4d4>
     6d7:      	cmpl	$0x2a, %r12d
     6db:      	je	0x7bf <generic_uprobe_process_event+0x51f>
     6e1:      	cmpl	$0x2b, %r12d
     6e5:      	je	0x782 <generic_uprobe_process_event+0x4e2>
     6eb:      	cmpl	$0x2c, %r12d
     6ef:      	jne	0x7bc <generic_uprobe_process_event+0x51c>
     6f5:      	movl	$0x70, %r15d
     6fb:      	jmp	0x7bf <generic_uprobe_process_event+0x51f>
     700:      	cmpl	$0x9, %r12d
     704:      	jg	0x79e <generic_uprobe_process_event+0x4fe>
     70a:      	cmpl	$0x6, %r12d
     70e:      	je	0x7bf <generic_uprobe_process_event+0x51f>
     714:      	cmpl	$0x7, %r12d
     718:      	je	0x796 <generic_uprobe_process_event+0x4f6>
     71a:      	cmpl	$0x8, %r12d
     71e:      	je	0x7b4 <generic_uprobe_process_event+0x514>
     724:      	jmp	0x7bc <generic_uprobe_process_event+0x51c>
     729:      	cmpl	$0x13, %r12d
     72d:      	jg	0x760 <generic_uprobe_process_event+0x4c0>
     72f:      	movq	0x30(%rsp), %r15
     734:      	cmpl	$0x12, %r12d
     738:      	je	0x7bf <generic_uprobe_process_event+0x51f>
     73e:      	cmpl	$0x13, %r12d
     742:      	je	0x782 <generic_uprobe_process_event+0x4e2>
     744:      	jmp	0x7bc <generic_uprobe_process_event+0x51c>
     746:      	leal	-0x1d(%r12), %eax
     74b:      	cmpl	$0x4, %eax
     74e:      	jae	0x7ae <generic_uprobe_process_event+0x50e>
     750:      	movl	$0x4, %r15d
     756:      	jmp	0x7bf <generic_uprobe_process_event+0x51f>
     758:      	movl	$0x10, %r15d
     75e:      	jmp	0x7bf <generic_uprobe_process_event+0x51f>
     760:      	cmpl	$0x14, %r12d
     764:      	je	0x7a6 <generic_uprobe_process_event+0x506>
     766:      	cmpl	$0x15, %r12d
     76a:      	jne	0x7bc <generic_uprobe_process_event+0x51c>
     76c:      	movl	$0x20, %r15d
     772:      	jmp	0x7bf <generic_uprobe_process_event+0x51f>
     774:      	cmpl	$0x28, %r12d
     778:      	je	0x782 <generic_uprobe_process_event+0x4e2>
     77a:      	cmpl	$0x29, %r12d
     77e:      	je	0x796 <generic_uprobe_process_event+0x4f6>
     780:      	jmp	0x7bc <generic_uprobe_process_event+0x51c>
     782:      	movl	$0x18, %r15d
     788:      	jmp	0x7bf <generic_uprobe_process_event+0x51f>
     78a:      	cmpl	$0x4, %r12d
     78e:      	je	0x79e <generic_uprobe_process_event+0x4fe>
     790:      	cmpl	$0x5, %r12d
     794:      	jne	0x7bc <generic_uprobe_process_event+0x51c>
     796:      	movl	$0x40, %r15d
     79c:      	jmp	0x7bf <generic_uprobe_process_event+0x51f>
     79e:      	movl	$0x8, %r15d
     7a4:      	jmp	0x7bf <generic_uprobe_process_event+0x51f>
     7a6:      	movl	$0x98, %r15d
     7ac:      	jmp	0x7bf <generic_uprobe_process_event+0x51f>
     7ae:      	cmpl	$0x1b, %r12d
     7b2:      	jne	0x7bc <generic_uprobe_process_event+0x51c>
     7b4:      	movl	$0x50, %r15d
     7ba:      	jmp	0x7bf <generic_uprobe_process_event+0x51f>
     7bc:      	xorl	%r15d, %r15d
     7bf:      	movl	$0x0, 0x104(%rsp)
     7ca:      	movq	(%rip), %rdi            # 0x7d1 <generic_uprobe_process_event+0x531>
     7d1:      	leaq	0x104(%rsp), %rsi
     7d9:      	movl	$0x1, %eax
     7de:      	callq	*%rax
     7e0:      	testq	%rax, %rax
     7e3:      	je	0x1674 <generic_uprobe_process_event+0x13d4>
     7e9:      	movl	$0x3ffb, %ecx           # imm = 0x3FFB
     7ee:      	subq	%r15, %rcx
     7f1:      	cmpq	%rbp, %rcx
     7f4:      	jbe	0x1674 <generic_uprobe_process_event+0x13d4>
     7fa:      	movq	0xd8(%rsp), %rdx
     802:      	movl	0x5ea0(%rax,%rdx,4), %ecx
     809:      	movl	%ecx, 0x90(%rax,%rbp)
     810:      	leaq	0x4(%rbp), %r15
     814:      	movq	%r15, 0x5e78(%rax,%rdx,8)
     81c:      	movl	$0x4, %edx
     821:      	testl	%ecx, %ecx
     823:      	jne	0x1670 <generic_uprobe_process_event+0x13d0>
     829:      	movq	%rax, %rbp
     82c:      	addq	$0x90, %rbp
     833:      	andl	$0x3fff, %r15d          # imm = 0x3FFF
     83a:      	addq	%r15, %rbp
     83d:      	movq	0x20(%rsp), %rdx
     842:      	movq	%rdx, 0x58(%rsp)
     847:      	movq	$0x0, 0x98(%rsp)
     853:      	cmpl	$0x17, %r12d
     857:      	movq	%rax, 0x8(%rsp)
     85c:      	jle	0x899 <generic_uprobe_process_event+0x5f9>
     85e:      	cmpl	$0x18, %r12d
     862:      	je	0x8b4 <generic_uprobe_process_event+0x614>
     864:      	cmpl	$0x25, %r12d
     868:      	je	0x8f2 <generic_uprobe_process_event+0x652>
     86e:      	cmpl	$0x2a, %r12d
     872:      	jne	0xfd6 <generic_uprobe_process_event+0xd36>
     878:      	movq	$0x0, 0x108(%rsp)
     884:      	movq	%rdx, 0x110(%rsp)
     88c:      	leaq	0x108(%rsp), %rax
     894:      	jmp	0x91f <generic_uprobe_process_event+0x67f>
     899:      	cmpl	$0xf, %r12d
     89d:      	je	0xeff <generic_uprobe_process_event+0xc5f>
     8a3:      	cmpl	$0x10, %r12d
     8a7:      	jne	0xfd6 <generic_uprobe_process_event+0xd36>
     8ad:      	leaq	0x40(%rsp), %r15
     8b2:      	jmp	0x8dc <generic_uprobe_process_event+0x63c>
     8b4:      	leaq	0x40(%rsp), %r15
     8b9:      	movl	$0x8, %ecx
     8be:      	movl	$0x4, %eax
     8c3:      	movq	0x58(%rsp), %rdx
     8c8:      	movq	%r15, %rdi
     8cb:      	movl	$0x8, %esi
     8d0:      	callq	*%rax
     8d2:      	movq	0x40(%rsp), %rax
     8d7:      	movq	%rax, 0x58(%rsp)
     8dc:      	leaq	0x58(%rsp), %rdx
     8e1:      	movl	$0x8, %ecx
     8e6:      	movl	$0x4, %eax
     8eb:      	leaq	0x40(%rsp), %rdi
     8f0:      	jmp	0x90f <generic_uprobe_process_event+0x66f>
     8f2:      	addq	$0x40, %rdx
     8f6:      	movq	%rdx, 0x58(%rsp)
     8fb:      	leaq	0x40(%rsp), %rdi
     900:      	movl	$0x8, %ecx
     905:      	movl	$0x4, %eax
     90a:      	movq	0x58(%rsp), %rdx
     90f:      	movl	$0x8, %esi
     914:      	callq	*%rax
     916:      	movq	0x40(%rsp), %rax
     91b:      	addq	$0x40, %rax
     91f:      	movq	%rax, 0x50(%rsp)
     924:      	movl	$0x0, 0xbc(%rsp)
     92f:      	movq	(%rip), %rdi            # 0x936 <generic_uprobe_process_event+0x696>
     936:      	leaq	0xbc(%rsp), %rsi
     93e:      	movl	$0x1, %eax
     943:      	callq	*%rax
     945:      	testq	%rax, %rax
     948:      	je	0x1109 <generic_uprobe_process_event+0xe69>
     94e:      	movq	%rax, %r12
     951:      	movq	%rbp, 0x10(%rsp)
     956:      	movq	%r13, 0xc0(%rsp)
     95e:      	addq	$0x1000, %rax           # imm = 0x1000
     964:      	movq	%rax, 0x30(%rsp)
     969:      	movl	$0x23, %eax
     96e:      	callq	*%rax
     970:      	leaq	0xd50(%rax), %rdx
     977:      	leaq	0xe0(%rsp), %rdi
     97f:      	movl	$0x8, %ecx
     984:      	movl	$0x4, %eax
     989:      	movl	$0x8, %esi
     98e:      	callq	*%rax
     990:      	movq	0xe0(%rsp), %r13
     998:      	movq	0x50(%rsp), %rax
     99d:      	leaq	0x8(%rax), %rdx
     9a1:      	leaq	0xc8(%rsp), %rdi
     9a9:      	movl	$0x8, %ecx
     9ae:      	movl	$0x4, %eax
     9b3:      	leaq	0x18(%r13), %rcx
     9b7:      	movq	%rcx, 0xb0(%rsp)
     9bf:      	movl	$0x8, %esi
     9c4:      	movq	%rdx, 0x20(%rsp)
     9c9:      	callq	*%rax
     9cb:      	movq	0xc8(%rsp), %r15
     9d3:      	leaq	0x10(%r15), %rdx
     9d7:      	leaq	0x58(%rsp), %rdi
     9dc:      	movl	$0x8, %ecx
     9e1:      	movl	$0x4, %eax
     9e6:      	movl	$0x8, %esi
     9eb:      	callq	*%rax
     9ed:      	cmpq	$0x0, 0x58(%rsp)
     9f3:      	movl	$0x1000, %ebp           # imm = 0x1000
     9f8:      	je	0xa01 <generic_uprobe_process_event+0x761>
     9fa:      	movq	0x30(%rsp), %rcx
     9ff:      	jmp	0xa53 <generic_uprobe_process_event+0x7b3>
     a01:      	leaq	0x18(%r15), %rdx
     a05:      	leaq	0x58(%rsp), %rdi
     a0a:      	movl	$0x8, %ecx
     a0f:      	movl	$0x4, %eax
     a14:      	movl	$0x8, %esi
     a19:      	callq	*%rax
     a1b:      	cmpq	%r15, 0x58(%rsp)
     a20:      	movq	0x30(%rsp), %rcx
     a25:      	je	0xa53 <generic_uprobe_process_event+0x7b3>
     a27:      	movq	%r12, %rcx
     a2a:      	addq	$0xff6, %rcx            # imm = 0xFF6
     a31:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
     a3b:      	movq	%rax, 0xff6(%r12)
     a43:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
     a4e:      	movl	$0xff6, %ebp            # imm = 0xFF6
     a53:      	movq	$0x0, 0x60(%rsp)
     a5c:      	movq	$0x0, 0x58(%rsp)
     a65:      	movq	%r12, 0x68(%rsp)
     a6a:      	movq	$0x0, 0x70(%rsp)
     a73:      	movq	$0x0, 0x78(%rsp)
     a7c:      	movq	$0x0, 0x80(%rsp)
     a88:      	movq	%rcx, 0x30(%rsp)
     a8d:      	movq	%rcx, 0x88(%rsp)
     a95:      	movl	%ebp, 0x90(%rsp)
     a9c:      	movb	$0x0, 0x94(%rsp)
     aa4:      	addq	$0x20, %r13
     aa8:      	leaq	0x58(%rsp), %rdi
     aad:      	movl	$0x8, %ecx
     ab2:      	movl	$0x4, %eax
     ab7:      	leaq	0x60(%rsp), %r12
     abc:      	leaq	0x70(%rsp), %r15
     ac1:      	leaq	0x78(%rsp), %rbp
     ac6:      	movl	$0x8, %esi
     acb:      	movq	%r13, %rdx
     ace:      	callq	*%rax
     ad0:      	movl	$0x8, %ecx
     ad5:      	movl	$0x4, %eax
     ada:      	movq	0xb0(%rsp), %rdx
     ae2:      	movq	%r12, %rdi
     ae5:      	movl	$0x8, %esi
     aea:      	callq	*%rax
     aec:      	movl	$0x8, %ecx
     af1:      	movl	$0x4, %eax
     af6:      	movq	0x20(%rsp), %rdx
     afb:      	movq	%r15, %rdi
     afe:      	movl	$0x8, %esi
     b03:      	callq	*%rax
     b05:      	movl	$0x8, %ecx
     b0a:      	movl	$0x4, %eax
     b0f:      	movq	0x50(%rsp), %rdx
     b14:      	movq	%rbp, %rdi
     b17:      	movl	$0x8, %esi
     b1c:      	callq	*%rax
     b1e:      	movq	0x78(%rsp), %rax
     b23:      	addq	$-0x20, %rax
     b27:      	movq	%rax, 0x80(%rsp)
     b2f:      	movq	(%rip), %rax            # 0xb36 <generic_uprobe_process_event+0x896>
     b36:      	cmpb	$0x0, (%rax)
     b39:      	je	0xd29 <generic_uprobe_process_event+0xa89>
     b3f:      	movl	$0x800, %ebp            # imm = 0x800
     b44:      	movl	$0x8, %r15d
     b4a:      	movq	%r14, 0xf0(%rsp)
     b52:      	movq	0x70(%rsp), %r12
     b57:      	movq	0x78(%rsp), %rdx
     b5c:      	movq	0x80(%rsp), %r13
     b64:      	cmpq	0x58(%rsp), %r12
     b69:      	jne	0xb76 <generic_uprobe_process_event+0x8d6>
     b6b:      	cmpq	0x60(%rsp), %rdx
     b70:      	je	0x1091 <generic_uprobe_process_event+0xdf1>
     b76:      	movl	$0x4, %eax
     b7b:      	leaq	0xd0(%rsp), %rdi
     b83:      	movl	$0x8, %esi
     b88:      	callq	*%rax
     b8a:      	cmpq	0xd0(%rsp), %r12
     b92:      	movl	$0x8, %r14d
     b98:      	je	0xcb8 <generic_uprobe_process_event+0xa18>
     b9e:      	leaq	0x18(%r12), %r15
     ba3:      	movl	$0x4, %eax
     ba8:      	leaq	0x40(%rsp), %rdi
     bad:      	movl	$0x8, %esi
     bb2:      	movq	%r15, %rdx
     bb5:      	callq	*%rax
     bb7:      	cmpq	%r12, 0x40(%rsp)
     bbc:      	je	0xcb8 <generic_uprobe_process_event+0xa18>
     bc2:      	movl	$0x4, %eax
     bc7:      	leaq	0x38(%rsp), %rdi
     bcc:      	movl	$0x8, %esi
     bd1:      	movq	%r15, %rdx
     bd4:      	callq	*%rax
     bd6:      	addq	$0x20, %r12
     bda:      	movl	$0x4, %eax
     bdf:      	leaq	0x98(%rsp), %rdi
     be7:      	movl	$0x10, %ecx
     bec:      	movl	$0x10, %esi
     bf1:      	movq	%r12, %rdx
     bf4:      	callq	*%rax
     bf6:      	movq	0x68(%rsp), %r15
     bfb:      	movq	0x88(%rsp), %rax
     c03:      	movl	0x9c(%rsp), %r12d
     c0b:      	subq	%r15, %rax
     c0e:      	movl	0x90(%rsp), %r13d
     c16:      	movl	%r12d, %edx
     c19:      	subl	%r13d, %edx
     c1c:      	movl	$0x0, %ecx
     c21:      	cmovbl	%ecx, %edx
     c24:      	addq	0xa0(%rsp), %rdx
     c2c:      	xorl	%esi, %esi
     c2e:      	cmpl	%r12d, %r13d
     c31:      	seta	%sil
     c35:      	movl	%r12d, %ecx
     c38:      	cmovbl	%r13d, %ecx
     c3c:      	addl	%ecx, %esi
     c3e:      	movl	%r13d, %edi
     c41:      	subl	%esi, %edi
     c43:      	movl	%edi, 0x90(%rsp)
     c4a:      	subq	%rsi, %rax
     c4d:      	movq	0xf0(%rsp), %r14
     c55:      	jb	0x10bd <generic_uprobe_process_event+0xe1d>
     c5b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     c61:      	ja	0x10bd <generic_uprobe_process_event+0xe1d>
     c67:      	cmpl	%r12d, %r13d
     c6a:      	jbe	0xc71 <generic_uprobe_process_event+0x9d1>
     c6c:      	movb	$0x2f, (%r15,%rax)
     c71:      	xorl	%edi, %edi
     c73:      	cmpl	%r12d, %r13d
     c76:      	seta	%dil
     c7a:      	movzbl	%cl, %esi
     c7d:      	addq	%rax, %r15
     c80:      	addq	%r15, %rdi
     c83:      	movl	$0x4, %eax
     c88:      	callq	*%rax
     c8a:      	movq	%r15, 0x88(%rsp)
     c92:      	cmpl	%r12d, %r13d
     c95:      	jbe	0x10bd <generic_uprobe_process_event+0xe1d>
     c9b:      	movq	0x38(%rsp), %rax
     ca0:      	movq	%rax, 0x70(%rsp)
     ca5:      	movl	$0x8, %r15d
     cab:      	decl	%ebp
     cad:      	jne	0xb52 <generic_uprobe_process_event+0x8b2>
     cb3:      	jmp	0x10bd <generic_uprobe_process_event+0xe1d>
     cb8:      	leaq	0x10(%r13), %rdx
     cbc:      	movl	$0x4, %eax
     cc1:      	leaq	0x40(%rsp), %rdi
     cc6:      	movl	$0x8, %esi
     ccb:      	callq	*%rax
     ccd:      	movq	0x80(%rsp), %rax
     cd5:      	cmpq	0x40(%rsp), %rax
     cda:      	movl	$0x8, %r15d
     ce0:      	je	0x10ad <generic_uprobe_process_event+0xe0d>
     ce6:      	addq	$0x18, %r13
     cea:      	movl	$0x4, %eax
     cef:      	leaq	0x70(%rsp), %rdi
     cf4:      	movl	$0x8, %esi
     cf9:      	movq	%r13, %rdx
     cfc:      	callq	*%rax
     cfe:      	movq	0x40(%rsp), %rax
     d03:      	movq	%rax, 0x80(%rsp)
     d0b:      	addq	$0x20, %rax
     d0f:      	movq	%rax, 0x78(%rsp)
     d14:      	movq	0xf0(%rsp), %r14
     d1c:      	decl	%ebp
     d1e:      	jne	0xb52 <generic_uprobe_process_event+0x8b2>
     d24:      	jmp	0x10bd <generic_uprobe_process_event+0xe1d>
     d29:      	movl	$0x800, %ebp            # imm = 0x800
     d2e:      	movl	$0x8, %r15d
     d34:      	movq	0x70(%rsp), %r12
     d39:      	movq	0x78(%rsp), %rdx
     d3e:      	movq	0x80(%rsp), %r13
     d46:      	cmpq	0x58(%rsp), %r12
     d4b:      	jne	0xd58 <generic_uprobe_process_event+0xab8>
     d4d:      	cmpq	0x60(%rsp), %rdx
     d52:      	je	0x1091 <generic_uprobe_process_event+0xdf1>
     d58:      	movl	$0x4, %eax
     d5d:      	leaq	0xd0(%rsp), %rdi
     d65:      	movl	$0x8, %esi
     d6a:      	callq	*%rax
     d6c:      	cmpq	0xd0(%rsp), %r12
     d74:      	movl	$0x8, %ecx
     d79:      	je	0xe96 <generic_uprobe_process_event+0xbf6>
     d7f:      	leaq	0x18(%r12), %r15
     d84:      	movl	$0x4, %eax
     d89:      	leaq	0x40(%rsp), %rdi
     d8e:      	movl	$0x8, %esi
     d93:      	movq	%r15, %rdx
     d96:      	callq	*%rax
     d98:      	movl	$0x8, %ecx
     d9d:      	cmpq	%r12, 0x40(%rsp)
     da2:      	je	0xe96 <generic_uprobe_process_event+0xbf6>
     da8:      	movl	$0x4, %eax
     dad:      	leaq	0x38(%rsp), %rdi
     db2:      	movl	$0x8, %esi
     db7:      	movq	%r15, %rdx
     dba:      	callq	*%rax
     dbc:      	addq	$0x20, %r12
     dc0:      	movl	$0x4, %eax
     dc5:      	leaq	0x98(%rsp), %rdi
     dcd:      	movl	$0x10, %ecx
     dd2:      	movl	$0x10, %esi
     dd7:      	movq	%r12, %rdx
     dda:      	callq	*%rax
     ddc:      	movq	0x68(%rsp), %r15
     de1:      	movq	0x88(%rsp), %rax
     de9:      	movl	0x9c(%rsp), %r12d
     df1:      	subq	%r15, %rax
     df4:      	movl	0x90(%rsp), %r13d
     dfc:      	movl	%r12d, %edx
     dff:      	subl	%r13d, %edx
     e02:      	movl	$0x0, %ecx
     e07:      	cmovbl	%ecx, %edx
     e0a:      	addq	0xa0(%rsp), %rdx
     e12:      	xorl	%esi, %esi
     e14:      	cmpl	%r12d, %r13d
     e17:      	seta	%sil
     e1b:      	movl	%r12d, %ecx
     e1e:      	cmovbl	%r13d, %ecx
     e22:      	addl	%ecx, %esi
     e24:      	movl	%r13d, %edi
     e27:      	subl	%esi, %edi
     e29:      	movl	%edi, 0x90(%rsp)
     e30:      	subq	%rsi, %rax
     e33:      	jb	0x10bd <generic_uprobe_process_event+0xe1d>
     e39:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     e3f:      	ja	0x10bd <generic_uprobe_process_event+0xe1d>
     e45:      	cmpl	%r12d, %r13d
     e48:      	jbe	0xe4f <generic_uprobe_process_event+0xbaf>
     e4a:      	movb	$0x2f, (%r15,%rax)
     e4f:      	xorl	%edi, %edi
     e51:      	cmpl	%r12d, %r13d
     e54:      	seta	%dil
     e58:      	movzbl	%cl, %esi
     e5b:      	addq	%rax, %r15
     e5e:      	addq	%r15, %rdi
     e61:      	movl	$0x4, %eax
     e66:      	callq	*%rax
     e68:      	movq	%r15, 0x88(%rsp)
     e70:      	cmpl	%r12d, %r13d
     e73:      	jbe	0x10bd <generic_uprobe_process_event+0xe1d>
     e79:      	movq	0x38(%rsp), %rax
     e7e:      	movq	%rax, 0x70(%rsp)
     e83:      	movl	$0x8, %r15d
     e89:      	decl	%ebp
     e8b:      	jne	0xd34 <generic_uprobe_process_event+0xa94>
     e91:      	jmp	0x10bd <generic_uprobe_process_event+0xe1d>
     e96:      	leaq	0x10(%r13), %rdx
     e9a:      	movl	$0x4, %eax
     e9f:      	leaq	0x40(%rsp), %rdi
     ea4:      	movl	$0x8, %esi
     ea9:      	callq	*%rax
     eab:      	movq	0x80(%rsp), %rax
     eb3:      	cmpq	0x40(%rsp), %rax
     eb8:      	movl	$0x8, %r15d
     ebe:      	je	0x1091 <generic_uprobe_process_event+0xdf1>
     ec4:      	addq	$0x18, %r13
     ec8:      	movl	$0x4, %eax
     ecd:      	leaq	0x70(%rsp), %rdi
     ed2:      	movl	$0x8, %esi
     ed7:      	movq	%r13, %rdx
     eda:      	callq	*%rax
     edc:      	movq	0x40(%rsp), %rax
     ee1:      	movq	%rax, 0x80(%rsp)
     ee9:      	addq	$0x20, %rax
     eed:      	movq	%rax, 0x78(%rsp)
     ef2:      	decl	%ebp
     ef4:      	jne	0xd34 <generic_uprobe_process_event+0xa94>
     efa:      	jmp	0x10bd <generic_uprobe_process_event+0xe1d>
     eff:      	leaq	0x98(%rsp), %rdi
     f07:      	leaq	0x58(%rsp), %rdx
     f0c:      	movl	$0x8, %ecx
     f11:      	movl	$0x4, %eax
     f16:      	movl	$0x8, %esi
     f1b:      	callq	*%rax
     f1d:      	movq	0x98(%rsp), %rax
     f25:      	movq	%rax, 0x50(%rsp)
     f2a:      	testq	%rax, %rax
     f2d:      	jne	0x924 <generic_uprobe_process_event+0x684>
     f33:      	movl	$0x0, 0xe0(%rsp)
     f3e:      	movq	(%rip), %rdi            # 0xf45 <generic_uprobe_process_event+0xca5>
     f45:      	leaq	0xe0(%rsp), %rsi
     f4d:      	movl	$0x1, %eax
     f52:      	callq	*%rax
     f54:      	testq	%rax, %rax
     f57:      	movq	%r13, 0xc0(%rsp)
     f5f:      	je	0x109b <generic_uprobe_process_event+0xdfb>
     f65:      	movq	%r15, 0x50(%rsp)
     f6a:      	movq	%rbp, 0x10(%rsp)
     f6f:      	xorl	%r15d, %r15d
     f72:      	cmpl	$0x19, %r12d
     f76:      	movq	0x18(%rsp), %rbp
     f7b:      	jg	0x13e9 <generic_uprobe_process_event+0x1149>
     f81:      	cmpl	$0x12, %r12d
     f85:      	jle	0x1542 <generic_uprobe_process_event+0x12a2>
     f8b:      	cmpl	$0x14, %r12d
     f8f:      	jle	0x19a6 <generic_uprobe_process_event+0x1706>
     f95:      	cmpl	$0x15, %r12d
     f99:      	je	0x221d <generic_uprobe_process_event+0x1f7d>
     f9f:      	cmpl	$0x16, %r12d
     fa3:      	je	0x2190 <generic_uprobe_process_event+0x1ef0>
     fa9:      	cmpl	$0x17, %r12d
     fad:      	movq	0x8(%rsp), %rcx
     fb2:      	jne	0x1630 <generic_uprobe_process_event+0x1390>
     fb8:      	movq	0x10(%rsp), %rax
     fbd:      	movl	$0x0, 0x4(%rax)
     fc4:      	movq	0x20(%rsp), %rdx
     fc9:      	movl	%edx, (%rax)
     fcb:      	movl	$0x8, %r15d
     fd1:      	jmp	0x1630 <generic_uprobe_process_event+0x1390>
     fd6:      	cmpl	$0x2c, %r12d
     fda:      	ja	0xf33 <generic_uprobe_process_event+0xc93>
     fe0:      	movl	%r12d, %eax
     fe3:      	movabsq	$0x11c1f2027cf2, %rcx   # imm = 0x11C1F2027CF2
     fed:      	btq	%rax, %rcx
     ff1:      	jae	0xf33 <generic_uprobe_process_event+0xc93>
     ff7:      	movq	%rdx, 0x38(%rsp)
     ffc:      	movl	$0x0, 0xd0(%rsp)
    1007:      	movq	(%rip), %rdi            # 0x100e <generic_uprobe_process_event+0xd6e>
    100e:      	leaq	0xd0(%rsp), %rsi
    1016:      	movl	$0x1, %eax
    101b:      	callq	*%rax
    101d:      	testq	%rax, %rax
    1020:      	movq	%r13, 0xc0(%rsp)
    1028:      	je	0x109b <generic_uprobe_process_event+0xdfb>
    102a:      	movq	%r15, 0x50(%rsp)
    102f:      	movq	%rbp, 0x10(%rsp)
    1034:      	xorl	%r15d, %r15d
    1037:      	cmpl	$0x10, %r12d
    103b:      	movq	0x8(%rsp), %rcx
    1040:      	jle	0x11cf <generic_uprobe_process_event+0xf2f>
    1046:      	cmpl	$0x1e, %r12d
    104a:      	movq	0x18(%rsp), %rbp
    104f:      	jle	0x1332 <generic_uprobe_process_event+0x1092>
    1055:      	cmpl	$0x26, %r12d
    1059:      	jg	0x1423 <generic_uprobe_process_event+0x1183>
    105f:      	leal	-0x1f(%r12), %eax
    1064:      	cmpl	$0x2, %eax
    1067:      	jae	0x1a86 <generic_uprobe_process_event+0x17e6>
    106d:      	leaq	0x38(%rsp), %rdx
    1072:      	movl	$0x4, %r15d
    1078:      	movl	$0x1, %ecx
    107d:      	movl	$0x4, %eax
    1082:      	movq	0x10(%rsp), %rdi
    1087:      	movl	$0x1, %esi
    108c:      	jmp	0x1629 <generic_uprobe_process_event+0x1389>
    1091:      	movb	$0x1, 0x94(%rsp)
    1099:      	jmp	0x10bd <generic_uprobe_process_event+0xe1d>
    109b:      	xorl	%r15d, %r15d
    109e:      	movq	0x8(%rsp), %rcx
    10a3:      	movq	0x18(%rsp), %rbp
    10a8:      	jmp	0x1630 <generic_uprobe_process_event+0x1390>
    10ad:      	movb	$0x1, 0x94(%rsp)
    10b5:      	movq	0xf0(%rsp), %r14
    10bd:      	movq	0x88(%rsp), %rax
    10c5:      	movq	0x30(%rsp), %rdx
    10ca:      	xorl	%ebp, %ebp
    10cc:      	cmpq	%rdx, %rax
    10cf:      	je	0x1116 <generic_uprobe_process_event+0xe76>
    10d1:      	cmpb	$0x0, 0x94(%rsp)
    10d9:      	sete	%cl
    10dc:      	movl	0x90(%rsp), %edx
    10e3:      	movl	$0x1000, %r15d          # imm = 0x1000
    10e9:      	subl	%edx, %r15d
    10ec:      	testl	%edx, %edx
    10ee:      	cmovlel	%edx, %r15d
    10f2:      	testq	%rax, %rax
    10f5:      	movq	0xc0(%rsp), %r13
    10fd:      	je	0x1109 <generic_uprobe_process_event+0xe69>
    10ff:      	movb	%cl, %bpl
    1102:      	addl	%ebp, %ebp
    1104:      	movq	%rax, %rdx
    1107:      	jmp	0x1121 <generic_uprobe_process_event+0xe81>
    1109:      	xorl	%r15d, %r15d
    110c:      	movq	0x18(%rsp), %rbp
    1111:      	jmp	0x163d <generic_uprobe_process_event+0x139d>
    1116:      	xorl	%r15d, %r15d
    1119:      	movq	0xc0(%rsp), %r13
    1121:      	movq	0x10(%rsp), %r12
    1126:      	leaq	0x4(%r12), %rdi
    112b:      	andl	$0xfff, %r15d           # imm = 0xFFF
    1132:      	movl	$0x4, %eax
    1137:      	movl	%r15d, %esi
    113a:      	callq	*%rax
    113c:      	movl	%r15d, (%r12)
    1140:      	leaq	0x58(%rsp), %rdi
    1145:      	movl	$0x8, %ecx
    114a:      	movl	$0x4, %eax
    114f:      	movq	0x20(%rsp), %rdx
    1154:      	movl	$0x8, %esi
    1159:      	callq	*%rax
    115b:      	movq	0x58(%rsp), %rcx
    1160:      	addq	$0x30, %rcx
    1164:      	leaq	0x98(%rsp), %rdi
    116c:      	movl	$0x8, %edx
    1171:      	movl	$0x4, %eax
    1176:      	movq	0x58(%rsp), %rdx
    117b:      	addq	$0x30, %rdx
    117f:      	movl	$0x8, %esi
    1184:      	callq	*%rax
    1186:      	movq	0x98(%rsp), %rcx
    118e:      	leaq	0x40(%rsp), %rdi
    1193:      	movl	$0x2, %edx
    1198:      	movl	$0x4, %eax
    119d:      	movq	0x98(%rsp), %rdx
    11a5:      	movl	$0x2, %esi
    11aa:      	callq	*%rax
    11ac:      	movl	%ebp, 0x4(%r12,%r15)
    11b1:      	movzwl	0x40(%rsp), %eax
    11b6:      	movw	%ax, 0x8(%r12,%r15)
    11bc:      	addl	$0xa, %r15d
    11c0:      	movq	0x8(%rsp), %rcx
    11c5:      	movq	0x18(%rsp), %rbp
    11ca:      	jmp	0x1638 <generic_uprobe_process_event+0x1398>
    11cf:      	cmpl	$0x9, %r12d
    11d3:      	movq	0x18(%rsp), %rbp
    11d8:      	jg	0x1364 <generic_uprobe_process_event+0x10c4>
    11de:      	cmpl	$0x4, %r12d
    11e2:      	jle	0x15dd <generic_uprobe_process_event+0x133d>
    11e8:      	cmpl	$0x5, %r12d
    11ec:      	je	0x1c80 <generic_uprobe_process_event+0x19e0>
    11f2:      	cmpl	$0x6, %r12d
    11f6:      	je	0x13c6 <generic_uprobe_process_event+0x1126>
    11fc:      	cmpl	$0x7, %r12d
    1200:      	movq	0x8(%rsp), %rcx
    1205:      	jne	0x1630 <generic_uprobe_process_event+0x1390>
    120b:      	movq	%rax, %r13
    120e:      	movq	%rbx, %rbp
    1211:      	movq	%r14, %rbx
    1214:      	movq	0x38(%rsp), %r15
    1219:      	movq	0x10(%rsp), %r14
    121e:      	movq	%r15, 0x28(%r14)
    1222:      	leaq	0x26(%r14), %rdi
    1226:      	leaq	0x10(%r15), %rdx
    122a:      	movl	$0x2, %ecx
    122f:      	movl	$0x4, %eax
    1234:      	movl	$0x2, %esi
    1239:      	callq	*%rax
    123b:      	leaq	0x3a(%r14), %rdi
    123f:      	leaq	0x12(%r15), %rdx
    1243:      	movl	$0x1, %ecx
    1248:      	movl	$0x4, %eax
    124d:      	movl	$0x1, %esi
    1252:      	callq	*%rax
    1254:      	leaq	0x38(%r14), %rdi
    1258:      	leaq	0x226(%r15), %rdx
    125f:      	movl	$0x2, %ecx
    1264:      	movl	$0x4, %eax
    1269:      	movl	$0x2, %esi
    126e:      	callq	*%rax
    1270:      	leaq	0x24(%r14), %rdi
    1274:      	leaq	0x224(%r15), %rdx
    127b:      	movl	$0x2, %ecx
    1280:      	movl	$0x4, %eax
    1285:      	movl	$0x2, %esi
    128a:      	callq	*%rax
    128c:      	leaq	0x30(%r14), %rdi
    1290:      	leaq	0x21c(%r15), %rdx
    1297:      	movl	$0x4, %ecx
    129c:      	movl	$0x4, %eax
    12a1:      	movl	$0x4, %esi
    12a6:      	callq	*%rax
    12a8:      	leaq	0x34(%r14), %rdi
    12ac:      	leaq	0x218(%r15), %rdx
    12b3:      	movl	$0x4, %ecx
    12b8:      	movl	$0x4, %eax
    12bd:      	movl	$0x4, %esi
    12c2:      	callq	*%rax
    12c4:      	leaq	0x10(%r14), %r12
    12c8:      	movq	$0x0, (%r14)
    12cf:      	movq	$0x0, 0x8(%r14)
    12d7:      	movq	$0x0, 0x10(%r14)
    12df:      	movq	$0x0, 0x18(%r14)
    12e7:      	movzwl	0x26(%r14), %eax
    12ec:      	cmpl	$0xa, %eax
    12ef:      	je	0x258c <generic_uprobe_process_event+0x22ec>
    12f5:      	cmpl	$0x2, %eax
    12f8:      	jne	0x25be <generic_uprobe_process_event+0x231e>
    12fe:      	leaq	0x4(%r15), %rdx
    1302:      	movl	$0x4, %ecx
    1307:      	movl	$0x4, %eax
    130c:      	movq	0x10(%rsp), %rdi
    1311:      	movl	$0x4, %esi
    1316:      	callq	*%rax
    1318:      	movl	$0x4, %ecx
    131d:      	movl	$0x4, %eax
    1322:      	movq	%r12, %rdi
    1325:      	movl	$0x4, %esi
    132a:      	movq	%r15, %rdx
    132d:      	jmp	0x25bc <generic_uprobe_process_event+0x231c>
    1332:      	cmpl	$0x1c, %r12d
    1336:      	jg	0x15bc <generic_uprobe_process_event+0x131c>
    133c:      	cmpl	$0x11, %r12d
    1340:      	je	0x1aba <generic_uprobe_process_event+0x181a>
    1346:      	cmpl	$0x19, %r12d
    134a:      	je	0x1b84 <generic_uprobe_process_event+0x18e4>
    1350:      	cmpl	$0x1c, %r12d
    1354:      	movq	0x18(%rsp), %rbp
    1359:      	je	0x15e9 <generic_uprobe_process_event+0x1349>
    135f:      	jmp	0x1630 <generic_uprobe_process_event+0x1390>
    1364:      	leal	-0xa(%r12), %eax
    1369:      	cmpl	$0x2, %eax
    136c:      	jb	0x15e9 <generic_uprobe_process_event+0x1349>
    1372:      	leal	-0xc(%r12), %eax
    1377:      	cmpl	$0x2, %eax
    137a:      	jb	0x160a <generic_uprobe_process_event+0x136a>
    1380:      	cmpl	$0xe, %r12d
    1384:      	jne	0x1630 <generic_uprobe_process_event+0x1390>
    138a:      	leaq	0x58(%rsp), %rdi
    138f:      	leaq	0x38(%rsp), %r15
    1394:      	movl	$0x8, %ecx
    1399:      	movl	$0x4, %eax
    139e:      	movl	$0x8, %esi
    13a3:      	movq	%r15, %rdx
    13a6:      	callq	*%rax
    13a8:      	movq	0x58(%rsp), %rcx
    13ad:      	movl	$0x8, %edx
    13b2:      	movl	$0x4, %eax
    13b7:      	movq	0x58(%rsp), %rdx
    13bc:      	movq	%r15, %rdi
    13bf:      	movl	$0x8, %esi
    13c4:      	callq	*%rax
    13c6:      	movq	0x38(%rsp), %rdx
    13cb:      	movq	0x10(%rsp), %r12
    13d0:      	leaq	0x4(%r12), %rdi
    13d5:      	movl	$0x1001, %ecx           # imm = 0x1001
    13da:      	movl	$0x2d, %eax
    13df:      	movl	$0x1001, %esi           # imm = 0x1001
    13e4:      	jmp	0x1e6f <generic_uprobe_process_event+0x1bcf>
    13e9:      	cmpl	$0x20, %r12d
    13ed:      	jle	0x188e <generic_uprobe_process_event+0x15ee>
    13f3:      	movq	%rax, %rcx
    13f6:      	leal	-0x21(%r12), %eax
    13fb:      	cmpl	$0x4, %eax
    13fe:      	jae	0x1725 <generic_uprobe_process_event+0x1485>
    1404:      	movl	$0x8, %r15d
    140a:      	movl	$0x8, %ecx
    140f:      	movl	$0x4, %eax
    1414:      	movq	0x10(%rsp), %rdi
    1419:      	movq	0x20(%rsp), %rdx
    141e:      	jmp	0x1603 <generic_uprobe_process_event+0x1363>
    1423:      	cmpl	$0x27, %r12d
    1427:      	je	0x1e4c <generic_uprobe_process_event+0x1bac>
    142d:      	cmpl	$0x28, %r12d
    1431:      	je	0x1e8e <generic_uprobe_process_event+0x1bee>
    1437:      	cmpl	$0x2c, %r12d
    143b:      	jne	0x1630 <generic_uprobe_process_event+0x1390>
    1441:      	movq	0x38(%rsp), %r15
    1446:      	movb	$0x0, 0x58(%rsp)
    144b:      	movq	0x10(%rsp), %rdi
    1450:      	movq	$0x0, 0x68(%rdi)
    1458:      	movq	$0x0, 0x60(%rdi)
    1460:      	movq	$0x0, 0x58(%rdi)
    1468:      	movq	$0x0, 0x50(%rdi)
    1470:      	movq	$0x0, 0x48(%rdi)
    1478:      	movq	$0x0, 0x40(%rdi)
    1480:      	movq	$0x0, 0x38(%rdi)
    1488:      	movq	$0x0, 0x30(%rdi)
    1490:      	movq	$0x0, 0x28(%rdi)
    1498:      	movq	$0x0, 0x20(%rdi)
    14a0:      	movq	$0x0, 0x18(%rdi)
    14a8:      	movq	$0x0, 0x10(%rdi)
    14b0:      	movq	$0x0, 0x8(%rdi)
    14b8:      	movq	$0x0, (%rdi)
    14bf:      	movl	$0x2, %ecx
    14c4:      	movl	$0x4, %eax
    14c9:      	movl	$0x2, %esi
    14ce:      	movq	%r15, %rdx
    14d1:      	callq	*%rax
    14d3:      	testq	%rax, %rax
    14d6:      	js	0x28dd <generic_uprobe_process_event+0x263d>
    14dc:      	leaq	0x2(%r15), %r12
    14e0:      	leaq	0x58(%rsp), %rdi
    14e5:      	movl	$0x1, %ecx
    14ea:      	movl	$0x4, %eax
    14ef:      	movl	$0x1, %esi
    14f4:      	movq	%r12, %rdx
    14f7:      	callq	*%rax
    14f9:      	testq	%rax, %rax
    14fc:      	js	0x28dd <generic_uprobe_process_event+0x263d>
    1502:      	movq	0x10(%rsp), %rax
    1507:      	leaq	0x4(%rax), %rdi
    150b:      	cmpb	$0x0, 0x58(%rsp)
    1510:      	sete	0x2(%rax)
    1514:      	je	0x28af <generic_uprobe_process_event+0x260f>
    151a:      	movl	$0x6c, %ecx
    151f:      	movl	$0x2d, %eax
    1524:      	movl	$0x6c, %esi
    1529:      	movq	%r12, %rdx
    152c:      	callq	*%rax
    152e:      	testl	%eax, %eax
    1530:      	movq	0x18(%rsp), %rbp
    1535:      	js	0x28dd <generic_uprobe_process_event+0x263d>
    153b:      	decb	%al
    153d:      	jmp	0x28d5 <generic_uprobe_process_event+0x2635>
    1542:      	cmpl	$0x7, %r12d
    1546:      	jg	0x195c <generic_uprobe_process_event+0x16bc>
    154c:      	movq	%rax, %rcx
    154f:      	movq	%rbx, 0x28(%rsp)
    1554:      	cmpl	$0x2, %r12d
    1558:      	je	0x1f27 <generic_uprobe_process_event+0x1c87>
    155e:      	movq	%rcx, %r13
    1561:      	cmpl	$0x3, %r12d
    1565:      	movq	0x8(%rsp), %rcx
    156a:      	movq	0x28(%rsp), %rbx
    156f:      	jne	0x1630 <generic_uprobe_process_event+0x1390>
    1575:      	movq	%r14, %rbx
    1578:      	leaq	0x90(%r13), %r12
    157f:      	movq	0xb0(%rsp), %rax
    1587:      	andl	$0xf, %eax
    158a:      	cmpl	$0x2, %eax
    158d:      	jle	0x2739 <generic_uprobe_process_event+0x2499>
    1593:      	cmpl	$0x3, %eax
    1596:      	je	0x29ca <generic_uprobe_process_event+0x272a>
    159c:      	cmpl	$0x4, %eax
    159f:      	je	0x29d5 <generic_uprobe_process_event+0x2735>
    15a5:      	cmpl	$0x5, %eax
    15a8:      	jne	0x2e01 <generic_uprobe_process_event+0x2b61>
    15ae:      	movq	%r13, %rax
    15b1:      	addq	$0x5e70, %rax           # imm = 0x5E70
    15b7:      	jmp	0x29e9 <generic_uprobe_process_event+0x2749>
    15bc:      	leaq	0x38(%rsp), %rdx
    15c1:      	movl	$0x4, %r15d
    15c7:      	movl	$0x2, %ecx
    15cc:      	movl	$0x4, %eax
    15d1:      	movq	0x10(%rsp), %rdi
    15d6:      	movl	$0x2, %esi
    15db:      	jmp	0x1629 <generic_uprobe_process_event+0x1389>
    15dd:      	cmpl	$0x1, %r12d
    15e1:      	je	0x160a <generic_uprobe_process_event+0x136a>
    15e3:      	cmpl	$0x4, %r12d
    15e7:      	jne	0x1630 <generic_uprobe_process_event+0x1390>
    15e9:      	movl	$0x8, %r15d
    15ef:      	leaq	0x38(%rsp), %rdx
    15f4:      	movl	$0x8, %ecx
    15f9:      	movl	$0x4, %eax
    15fe:      	movq	0x10(%rsp), %rdi
    1603:      	movl	$0x8, %esi
    1608:      	jmp	0x1629 <generic_uprobe_process_event+0x1389>
    160a:      	leaq	0x38(%rsp), %rdx
    160f:      	movl	$0x4, %r15d
    1615:      	movl	$0x4, %ecx
    161a:      	movl	$0x4, %eax
    161f:      	movq	0x10(%rsp), %rdi
    1624:      	movl	$0x4, %esi
    1629:      	callq	*%rax
    162b:      	movq	0x8(%rsp), %rcx
    1630:      	movq	0xc0(%rsp), %r13
    1638:      	testl	%r15d, %r15d
    163b:      	js	0x164d <generic_uprobe_process_event+0x13ad>
    163d:      	andl	$0x7fffffff, %r15d      # imm = 0x7FFFFFFF
    1644:      	addl	$0x4, %r15d
    1648:      	movl	%r15d, %edx
    164b:      	jmp	0x1670 <generic_uprobe_process_event+0x13d0>
    164d:      	movq	0xd8(%rsp), %rax
    1655:      	movl	$0xffffffff, 0x5ea0(%rcx,%rax,4) # imm = 0xFFFFFFFF
    1660:      	movl	$0xffffffff, 0x90(%rcx,%rbp) # imm = 0xFFFFFFFF
    166b:      	movl	$0x4, %edx
    1670:      	addl	%ebp, %edx
    1672:      	movl	%edx, %ebp
    1674:      	movl	%ebp, 0x4(%rbx)
    1677:      	cmpl	$0x3, %r13d
    167b:      	jg	0x16ec <generic_uprobe_process_event+0x144c>
    167d:      	movl	$0x0, 0x58(%rsp)
    1685:      	movq	(%rip), %rdi            # 0x168c <generic_uprobe_process_event+0x13ec>
    168c:      	leaq	0x58(%rsp), %rsi
    1691:      	movl	$0x1, %eax
    1696:      	callq	*%rax
    1698:      	testq	%rax, %rax
    169b:      	je	0x16ec <generic_uprobe_process_event+0x144c>
    169d:      	movq	%rax, %rsi
    16a0:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    16a7:      	movq	(%rip), %rdi            # 0x16ae <generic_uprobe_process_event+0x140e>
    16ae:      	movl	$0x1, %eax
    16b3:      	callq	*%rax
    16b5:      	testq	%rax, %rax
    16b8:      	je	0x16ec <generic_uprobe_process_event+0x144c>
    16ba:      	incl	%r13d
    16bd:      	movl	%r13d, %ecx
    16c0:      	andl	$0x7, %ecx
    16c3:      	cmpl	$-0x1, 0x40(%rax,%rcx,4)
    16c8:      	je	0x16ec <generic_uprobe_process_event+0x144c>
    16ca:      	movl	%r13d, 0x5efc(%rbx)
    16d1:      	movq	(%rip), %rsi            # 0x16d8 <generic_uprobe_process_event+0x1438>
    16d8:      	movl	$0x1, %ecx
    16dd:      	movl	$0xc, %eax
    16e2:      	movq	%r14, %rdi
    16e5:      	movl	$0x1, %edx
    16ea:      	callq	*%rax
    16ec:      	movl	$0x0, 0x5efc(%rbx)
    16f6:      	movq	(%rip), %rsi            # 0x16fd <generic_uprobe_process_event+0x145d>
    16fd:      	movl	$0x3, %ecx
    1702:      	movl	$0xc, %eax
    1707:      	movq	%r14, %rdi
    170a:      	movl	$0x3, %edx
    170f:      	callq	*%rax
    1711:      	xorl	%eax, %eax
    1713:      	addq	$0x118, %rsp            # imm = 0x118
    171a:      	popq	%rbx
    171b:      	popq	%r12
    171d:      	popq	%r13
    171f:      	popq	%r14
    1721:      	popq	%r15
    1723:      	popq	%rbp
    1724:      	retq
    1725:      	cmpl	$0x2b, %r12d
    1729:      	je	0x2315 <generic_uprobe_process_event+0x2075>
    172f:      	movq	%rcx, %r13
    1732:      	cmpl	$0x29, %r12d
    1736:      	movq	0x8(%rsp), %rcx
    173b:      	jne	0x1630 <generic_uprobe_process_event+0x1390>
    1741:      	movq	%rbx, 0x28(%rsp)
    1746:      	movq	%r14, %rbx
    1749:      	movq	%rcx, %rbp
    174c:      	movq	0x20(%rsp), %rdx
    1751:      	addq	$0x18, %rdx
    1755:      	leaq	0x58(%rsp), %rdi
    175a:      	movl	$0x4, %r12d
    1760:      	movl	$0x8, %ecx
    1765:      	movl	$0x4, %eax
    176a:      	movl	$0x8, %esi
    176f:      	callq	*%rax
    1771:      	movq	0x58(%rsp), %r15
    1776:      	testq	%r15, %r15
    1779:      	je	0x2981 <generic_uprobe_process_event+0x26e1>
    177f:      	movq	0x10(%rsp), %r14
    1784:      	movq	%r15, 0x28(%r14)
    1788:      	leaq	0x26(%r14), %rdi
    178c:      	leaq	0x10(%r15), %rdx
    1790:      	movl	$0x2, %ecx
    1795:      	movl	$0x4, %eax
    179a:      	movl	$0x2, %esi
    179f:      	callq	*%rax
    17a1:      	leaq	0x3a(%r14), %rdi
    17a5:      	leaq	0x12(%r15), %rdx
    17a9:      	movl	$0x1, %ecx
    17ae:      	movl	$0x4, %eax
    17b3:      	movl	$0x1, %esi
    17b8:      	callq	*%rax
    17ba:      	leaq	0x38(%r14), %rdi
    17be:      	leaq	0x226(%r15), %rdx
    17c5:      	movl	$0x2, %ecx
    17ca:      	movl	$0x4, %eax
    17cf:      	movl	$0x2, %esi
    17d4:      	callq	*%rax
    17d6:      	leaq	0x24(%r14), %rdi
    17da:      	leaq	0x224(%r15), %rdx
    17e1:      	movl	$0x2, %ecx
    17e6:      	movl	$0x4, %eax
    17eb:      	movl	$0x2, %esi
    17f0:      	callq	*%rax
    17f2:      	leaq	0x30(%r14), %rdi
    17f6:      	leaq	0x21c(%r15), %rdx
    17fd:      	movl	$0x4, %eax
    1802:      	movl	$0x4, %esi
    1807:      	callq	*%rax
    1809:      	leaq	0x34(%r14), %rdi
    180d:      	leaq	0x218(%r15), %rdx
    1814:      	movl	$0x4, %eax
    1819:      	movl	$0x4, %esi
    181e:      	callq	*%rax
    1820:      	leaq	0x10(%r14), %r12
    1824:      	movq	$0x0, (%r14)
    182b:      	movq	$0x0, 0x8(%r14)
    1833:      	movq	$0x0, 0x10(%r14)
    183b:      	movq	$0x0, 0x18(%r14)
    1843:      	movzwl	0x26(%r14), %eax
    1848:      	cmpl	$0xa, %eax
    184b:      	je	0x2906 <generic_uprobe_process_event+0x2666>
    1851:      	cmpl	$0x2, %eax
    1854:      	jne	0x2938 <generic_uprobe_process_event+0x2698>
    185a:      	leaq	0x4(%r15), %rdx
    185e:      	movl	$0x4, %ecx
    1863:      	movl	$0x4, %eax
    1868:      	movq	0x10(%rsp), %rdi
    186d:      	movl	$0x4, %esi
    1872:      	callq	*%rax
    1874:      	movl	$0x4, %ecx
    1879:      	movl	$0x4, %eax
    187e:      	movq	%r12, %rdi
    1881:      	movl	$0x4, %esi
    1886:      	movq	%r15, %rdx
    1889:      	jmp	0x2936 <generic_uprobe_process_event+0x2696>
    188e:      	movq	%rbx, %r13
    1891:      	cmpl	$0x1a, %r12d
    1895:      	je	0x23b6 <generic_uprobe_process_event+0x2116>
    189b:      	cmpl	$0x1b, %r12d
    189f:      	movq	0x8(%rsp), %rcx
    18a4:      	movq	%r13, %rbx
    18a7:      	jne	0x1630 <generic_uprobe_process_event+0x1390>
    18ad:      	movq	%rcx, %r12
    18b0:      	movq	0x10(%rsp), %rax
    18b5:      	movq	$0x0, 0x48(%rax)
    18bd:      	movq	$0x0, 0x40(%rax)
    18c5:      	movq	$0x0, 0x38(%rax)
    18cd:      	movq	$0x0, 0x30(%rax)
    18d5:      	movq	$0x0, 0x28(%rax)
    18dd:      	movq	$0x0, 0x20(%rax)
    18e5:      	movq	$0x0, 0x18(%rax)
    18ed:      	movq	$0x0, 0x10(%rax)
    18f5:      	movq	$0x0, 0x8(%rax)
    18fd:      	movq	$0x0, (%rax)
    1904:      	leaq	0x10(%rax), %rdi
    1908:      	movq	0x20(%rsp), %rax
    190d:      	leaq	0x18(%rax), %rdx
    1911:      	movl	$0x3f, %ecx
    1916:      	movl	$0x2d, %eax
    191b:      	movl	$0x3f, %esi
    1920:      	callq	*%rax
    1922:      	testq	%rax, %rax
    1925:      	js	0x287d <generic_uprobe_process_event+0x25dd>
    192b:      	movq	0x10(%rsp), %rdi
    1930:      	addq	$0x8, %rdi
    1934:      	movq	0x20(%rsp), %rdx
    1939:      	addq	$0x348, %rdx            # imm = 0x348
    1940:      	movl	$0x8, %ecx
    1945:      	movl	$0x4, %eax
    194a:      	movl	$0x8, %esi
    194f:      	callq	*%rax
    1951:      	movl	$0x50, %r15d
    1957:      	jmp	0x2880 <generic_uprobe_process_event+0x25e0>
    195c:      	cmpl	$0x8, %r12d
    1960:      	je	0x1f91 <generic_uprobe_process_event+0x1cf1>
    1966:      	cmpl	$0x12, %r12d
    196a:      	movq	0x8(%rsp), %rcx
    196f:      	jne	0x1630 <generic_uprobe_process_event+0x1390>
    1975:      	movq	0xb0(%rsp), %r12
    197d:      	andl	$0x3ff, %r12d           # imm = 0x3FF
    1984:      	movq	%rcx, %r15
    1987:      	movl	$0x4, %eax
    198c:      	movq	0x10(%rsp), %rdi
    1991:      	movq	0x20(%rsp), %rdx
    1996:      	movl	%r12d, %esi
    1999:      	callq	*%rax
    199b:      	movq	%r15, %rcx
    199e:      	movq	%r12, %r15
    19a1:      	jmp	0x1630 <generic_uprobe_process_event+0x1390>
    19a6:      	cmpl	$0x13, %r12d
    19aa:      	je	0x22b8 <generic_uprobe_process_event+0x2018>
    19b0:      	cmpl	$0x14, %r12d
    19b4:      	movq	0x8(%rsp), %rcx
    19b9:      	jne	0x1630 <generic_uprobe_process_event+0x1390>
    19bf:      	movq	$0x0, 0x58(%rsp)
    19c8:      	movq	0x20(%rsp), %r12
    19cd:      	leaq	0x110(%r12), %rdx
    19d5:      	leaq	0x58(%rsp), %rdi
    19da:      	movl	$0x8, %esi
    19df:      	movl	$0x4, %eax
    19e4:      	leaq	0xd8(%r12), %r15
    19ec:      	movl	$0x8, %esi
    19f1:      	callq	*%rax
    19f3:      	movq	0x58(%rsp), %rcx
    19f8:      	movl	$0x80, %edx
    19fd:      	movl	$0x2d, %eax
    1a02:      	movq	0x10(%rsp), %r13
    1a07:      	movq	0x58(%rsp), %rdx
    1a0c:      	movq	%r13, %rdi
    1a0f:      	movl	$0x80, %esi
    1a14:      	callq	*%rax
    1a16:      	leaq	0x90(%r13), %rdi
    1a1d:      	movl	$0x4, %ecx
    1a22:      	movl	$0x4, %eax
    1a27:      	movl	$0x4, %esi
    1a2c:      	movq	%r15, %rdx
    1a2f:      	callq	*%rax
    1a31:      	leaq	0x80(%r13), %rdi
    1a38:      	leaq	0xe0(%r12), %rdx
    1a40:      	movl	$0x8, %ecx
    1a45:      	movl	$0x4, %eax
    1a4a:      	movl	$0x8, %esi
    1a4f:      	callq	*%rax
    1a51:      	addq	$0x88, %r13
    1a58:      	addq	$0x118, %r12            # imm = 0x118
    1a5f:      	movl	$0x8, %ecx
    1a64:      	movl	$0x4, %eax
    1a69:      	movq	%r13, %rdi
    1a6c:      	movl	$0x8, %esi
    1a71:      	movq	%r12, %rdx
    1a74:      	callq	*%rax
    1a76:      	movq	0x8(%rsp), %rcx
    1a7b:      	movl	$0x98, %r15d
    1a81:      	jmp	0x1630 <generic_uprobe_process_event+0x1390>
    1a86:      	cmpl	$0x26, %r12d
    1a8a:      	jne	0x1630 <generic_uprobe_process_event+0x1390>
    1a90:      	movq	0x38(%rsp), %rsi
    1a95:      	movzwl	%si, %edx
    1a98:      	addq	%r14, %rdx
    1a9b:      	shrl	$0x10, %esi
    1a9e:      	andl	$0xfff, %esi            # imm = 0xFFF
    1aa4:      	movq	0x10(%rsp), %r12
    1aa9:      	leaq	0x4(%r12), %rdi
    1aae:      	incl	%esi
    1ab0:      	movl	$0x2d, %eax
    1ab5:      	jmp	0x1e6f <generic_uprobe_process_event+0x1bcf>
    1aba:      	movq	%rbx, %rbp
    1abd:      	movq	%r14, %rbx
    1ac0:      	movq	$0x0, 0x60(%rsp)
    1ac9:      	movl	$0xe, %eax
    1ace:      	callq	*%rax
    1ad0:      	shrq	$0x20, %rax
    1ad4:      	movq	%rax, 0x58(%rsp)
    1ad9:      	leaq	0x98(%rsp), %rdi
    1ae1:      	leaq	0x38(%rsp), %rdx
    1ae6:      	movl	$0x4, %ecx
    1aeb:      	movl	$0x4, %eax
    1af0:      	movl	$0x4, %r13d
    1af6:      	movl	$0x4, %esi
    1afb:      	callq	*%rax
    1afd:      	movl	0x98(%rsp), %eax
    1b04:      	movl	%eax, 0x60(%rsp)
    1b08:      	movq	(%rip), %rdi            # 0x1b0f <generic_uprobe_process_event+0x186f>
    1b0f:      	leaq	0x58(%rsp), %rsi
    1b14:      	movl	$0x1, %eax
    1b19:      	callq	*%rax
    1b1b:      	testq	%rax, %rax
    1b1e:      	je	0x2441 <generic_uprobe_process_event+0x21a1>
    1b24:      	movl	(%rax), %r15d
    1b27:      	leaq	0x98(%rsp), %rdx
    1b2f:      	movq	%rax, %r12
    1b32:      	movl	$0x4, %eax
    1b37:      	movq	0x10(%rsp), %r14
    1b3c:      	movq	%r14, %rdi
    1b3f:      	movl	$0x4, %esi
    1b44:      	callq	*%rax
    1b46:      	andl	$0xfff, %r15d           # imm = 0xFFF
    1b4d:      	leaq	0x4(%r14), %rdi
    1b51:      	leaq	0x4(%r15), %rsi
    1b55:      	movl	$0x4, %eax
    1b5a:      	movq	%r12, %rdx
    1b5d:      	callq	*%rax
    1b5f:      	leaq	(%r14,%r15), %rdi
    1b63:      	addq	$0x8, %rdi
    1b67:      	leaq	(%r15,%r12), %rdx
    1b6b:      	addq	$0x4, %rdx
    1b6f:      	movl	$0x4, %eax
    1b74:      	movl	$0x4, %esi
    1b79:      	callq	*%rax
    1b7b:      	addq	$0xc, %r15
    1b7f:      	jmp	0x2644 <generic_uprobe_process_event+0x23a4>
    1b84:      	movq	%rax, %rbp
    1b87:      	movq	%rbx, 0x28(%rsp)
    1b8c:      	movq	%r14, %rbx
    1b8f:      	movq	0x38(%rsp), %r13
    1b94:      	leaq	0xc8(%rsp), %rdi
    1b9c:      	movl	$0x1, %ecx
    1ba1:      	movl	$0x4, %eax
    1ba6:      	movl	$0x1, %esi
    1bab:      	movq	%r13, %rdx
    1bae:      	callq	*%rax
    1bb0:      	movzbl	0xc8(%rsp), %eax
    1bb8:      	testl	%eax, %eax
    1bba:      	je	0x244d <generic_uprobe_process_event+0x21ad>
    1bc0:      	cmpl	$0x1, %eax
    1bc3:      	jne	0x2659 <generic_uprobe_process_event+0x23b9>
    1bc9:      	addq	$0x10, %r13
    1bcd:      	leaq	0x58(%rsp), %rdi
    1bd2:      	movl	$0x4, %r15d
    1bd8:      	movl	$0x8, %ecx
    1bdd:      	movl	$0x4, %eax
    1be2:      	movl	$0x8, %esi
    1be7:      	movq	%r13, %rdx
    1bea:      	callq	*%rax
    1bec:      	movq	0x58(%rsp), %rdx
    1bf1:      	leaq	0x98(%rsp), %rdi
    1bf9:      	movl	$0x8, %ecx
    1bfe:      	movl	$0x4, %eax
    1c03:      	movl	$0x8, %esi
    1c08:      	callq	*%rax
    1c0a:      	movq	0x58(%rsp), %rdx
    1c0f:      	addq	$0x8, %rdx
    1c13:      	leaq	0x40(%rsp), %rdi
    1c18:      	movl	$0x8, %ecx
    1c1d:      	movl	$0x4, %eax
    1c22:      	movl	$0x8, %esi
    1c27:      	callq	*%rax
    1c29:      	movq	0x98(%rsp), %rdx
    1c31:      	movq	0x40(%rsp), %r12
    1c36:      	cmpq	$0xfff, %r12            # imm = 0xFFF
    1c3d:      	movl	$0xfff, %r13d           # imm = 0xFFF
    1c43:      	cmovbq	%r12, %r13
    1c47:      	movq	0x50(%rsp), %rcx
    1c4c:      	leaq	(%rcx,%rbp), %rdi
    1c50:      	addq	$0x98, %rdi
    1c57:      	movl	$0x4, %eax
    1c5c:      	addq	%rcx, %rbp
    1c5f:      	addq	$0x90, %rbp
    1c66:      	movl	%r13d, %esi
    1c69:      	callq	*%rax
    1c6b:      	testl	%eax, %eax
    1c6d:      	js	0x2890 <generic_uprobe_process_event+0x25f0>
    1c73:      	movl	%r12d, (%rbp)
    1c77:      	movl	%r13d, 0x4(%rbp)
    1c7b:      	jmp	0x3029 <generic_uprobe_process_event+0x2d89>
    1c80:      	movq	%rbx, 0x28(%rsp)
    1c85:      	movq	%r14, 0xf0(%rsp)
    1c8d:      	movq	0x38(%rsp), %r12
    1c92:      	movq	0x10(%rsp), %rbx
    1c97:      	leaq	0x28(%rbx), %rdi
    1c9b:      	leaq	0x98(%r12), %rdx
    1ca3:      	movl	$0x4, %ecx
    1ca8:      	movl	$0x4, %eax
    1cad:      	movl	$0x4, %esi
    1cb2:      	callq	*%rax
    1cb4:      	leaq	0x2c(%rbx), %rdi
    1cb8:      	leaq	0x70(%r12), %rdx
    1cbd:      	movl	$0x4, %ecx
    1cc2:      	movl	$0x4, %eax
    1cc7:      	movl	$0x4, %esi
    1ccc:      	callq	*%rax
    1cce:      	leaq	0x30(%rbx), %rdi
    1cd2:      	leaq	0x90(%r12), %rdx
    1cda:      	movl	$0x4, %ecx
    1cdf:      	movl	$0x4, %eax
    1ce4:      	movl	$0x4, %esi
    1ce9:      	callq	*%rax
    1ceb:      	leaq	0x34(%rbx), %rdi
    1cef:      	leaq	0xa8(%r12), %rdx
    1cf7:      	movl	$0x4, %ecx
    1cfc:      	movl	$0x4, %eax
    1d01:      	movl	$0x4, %esi
    1d06:      	callq	*%rax
    1d08:      	movq	$0x0, 0x58(%rsp)
    1d11:      	leaq	0xc8(%r12), %rdx
    1d19:      	leaq	0x58(%rsp), %rdi
    1d1e:      	movl	$0x8, %ecx
    1d23:      	movl	$0x4, %eax
    1d28:      	movl	$0x8, %esi
    1d2d:      	callq	*%rax
    1d2f:      	leaq	0xb8(%r12), %rdx
    1d37:      	leaq	0xc8(%rsp), %rdi
    1d3f:      	movl	$0x2, %ecx
    1d44:      	movl	$0x4, %eax
    1d49:      	movl	$0x2, %esi
    1d4e:      	callq	*%rax
    1d50:      	movzwl	0xc8(%rsp), %r15d
    1d59:      	addq	0x58(%rsp), %r15
    1d5e:      	leaq	0xaf(%rsp), %rdi
    1d66:      	movl	$0x1, %ecx
    1d6b:      	movl	$0x4, %eax
    1d70:      	movl	$0x1, %esi
    1d75:      	movq	%r15, %rdx
    1d78:      	callq	*%rax
    1d7a:      	movzbl	0xaf(%rsp), %eax
    1d82:      	shrl	$0x4, %eax
    1d85:      	cmpl	$0x6, %eax
    1d88:      	je	0x24e3 <generic_uprobe_process_event+0x2243>
    1d8e:      	cmpl	$0x4, %eax
    1d91:      	jne	0x3715 <generic_uprobe_process_event+0x3475>
    1d97:      	leaq	0x9(%r15), %rdx
    1d9b:      	leaq	0xbc(%rsp), %rdi
    1da3:      	movl	$0x1, %ecx
    1da8:      	movl	$0x4, %eax
    1dad:      	movl	$0x1, %esi
    1db2:      	callq	*%rax
    1db4:      	movzbl	0xbc(%rsp), %eax
    1dbc:      	movq	0x10(%rsp), %rdi
    1dc1:      	movw	%ax, 0x24(%rdi)
    1dc5:      	movw	$0x2, 0x26(%rdi)
    1dcb:      	leaq	0xc(%r15), %rdx
    1dcf:      	movq	$0x0, (%rdi)
    1dd6:      	movq	$0x0, 0x8(%rdi)
    1dde:      	movq	$0x0, 0x10(%rdi)
    1de6:      	movq	$0x0, 0x18(%rdi)
    1dee:      	movl	$0x4, %ecx
    1df3:      	movl	$0x4, %eax
    1df8:      	leaq	0x10(%rdi), %r13
    1dfc:      	movl	$0x4, %esi
    1e01:      	callq	*%rax
    1e03:      	addq	$0x10, %r15
    1e07:      	movl	$0x4, %ecx
    1e0c:      	movl	$0x4, %eax
    1e11:      	movq	%r13, %rdi
    1e14:      	movl	$0x4, %esi
    1e19:      	movq	%r15, %rdx
    1e1c:      	callq	*%rax
    1e1e:      	leaq	0xb6(%r12), %rdx
    1e26:      	leaq	0xe0(%rsp), %rdi
    1e2e:      	movl	$0x2, %ecx
    1e33:      	movl	$0x4, %eax
    1e38:      	movl	$0x2, %esi
    1e3d:      	callq	*%rax
    1e3f:      	movzbl	0xbc(%rsp), %ebp
    1e47:      	jmp	0x35ad <generic_uprobe_process_event+0x330d>
    1e4c:      	movl	$0x120, %edx            # imm = 0x120
    1e51:      	addq	0x38(%rsp), %rdx
    1e56:      	movq	0x10(%rsp), %r12
    1e5b:      	leaq	0x4(%r12), %rdi
    1e60:      	movl	$0x11, %ecx
    1e65:      	movl	$0x2d, %eax
    1e6a:      	movl	$0x11, %esi
    1e6f:      	callq	*%rax
    1e71:      	movq	%rax, %r15
    1e74:      	testq	%rax, %rax
    1e77:      	js	0x162b <generic_uprobe_process_event+0x138b>
    1e7d:      	leal	-0x1(%r15), %eax
    1e81:      	movl	%eax, (%r12)
    1e85:      	addq	$0x3, %r15
    1e89:      	jmp	0x162b <generic_uprobe_process_event+0x138b>
    1e8e:      	movq	0x38(%rsp), %r15
    1e93:      	movq	0x10(%rsp), %r12
    1e98:      	movq	$0x0, 0x10(%r12)
    1ea1:      	movq	$0x0, 0x8(%r12)
    1eaa:      	movq	$0x0, (%r12)
    1eb2:      	movl	$0x2, %ecx
    1eb7:      	movl	$0x4, %eax
    1ebc:      	movq	%r12, %rdi
    1ebf:      	movl	$0x2, %esi
    1ec4:      	movq	%r15, %rdx
    1ec7:      	callq	*%rax
    1ec9:      	testq	%rax, %rax
    1ecc:      	js	0x27a9 <generic_uprobe_process_event+0x2509>
    1ed2:      	movzwl	(%r12), %eax
    1ed7:      	cmpl	$0xa, %eax
    1eda:      	je	0x2759 <generic_uprobe_process_event+0x24b9>
    1ee0:      	cmpl	$0x2, %eax
    1ee3:      	jne	0x2795 <generic_uprobe_process_event+0x24f5>
    1ee9:      	leaq	0x4(%r15), %rdx
    1eed:      	leaq	0x58(%rsp), %rdi
    1ef2:      	movl	$0x4, %ecx
    1ef7:      	movl	$0x4, %eax
    1efc:      	movl	$0x4, %esi
    1f01:      	callq	*%rax
    1f03:      	movl	0x58(%rsp), %eax
    1f07:      	movq	0x10(%rsp), %rcx
    1f0c:      	movq	%rax, 0x8(%rcx)
    1f10:      	leaq	0x2(%rcx), %rdi
    1f14:      	addq	$0x2, %r15
    1f18:      	movl	$0x2, %ecx
    1f1d:      	movl	$0x4, %eax
    1f22:      	jmp	0x278b <generic_uprobe_process_event+0x24eb>
    1f27:      	movq	%r14, %rbx
    1f2a:      	movq	0x50(%rsp), %rax
    1f2f:      	movq	%rcx, %r14
    1f32:      	leaq	(%rcx,%rax), %r12
    1f36:      	addq	$0x90, %r12
    1f3d:      	movq	$0x0, 0xd0(%rsp)
    1f49:      	testb	$0x10, 0x30(%rsp)
    1f4e:      	jne	0x2675 <generic_uprobe_process_event+0x23d5>
    1f54:      	movq	0x30(%rsp), %rdx
    1f59:      	andl	$0xf, %edx
    1f5c:      	xorl	%eax, %eax
    1f5e:      	movq	%rdx, %rcx
    1f61:      	cmpl	$0x2, %edx
    1f64:      	jle	0x28e8 <generic_uprobe_process_event+0x2648>
    1f6a:      	cmpl	$0x3, %ecx
    1f6d:      	je	0x2faa <generic_uprobe_process_event+0x2d0a>
    1f73:      	cmpl	$0x4, %ecx
    1f76:      	je	0x2fb3 <generic_uprobe_process_event+0x2d13>
    1f7c:      	cmpl	$0x5, %ecx
    1f7f:      	jne	0x2fc6 <generic_uprobe_process_event+0x2d26>
    1f85:      	addq	$0x5e70, %r14           # imm = 0x5E70
    1f8c:      	jmp	0x2fc3 <generic_uprobe_process_event+0x2d23>
    1f91:      	movq	0x10(%rsp), %r15
    1f96:      	leaq	0x28(%r15), %r13
    1f9a:      	leaq	0x40(%r15), %rax
    1f9e:      	movq	%rax, 0x30(%rsp)
    1fa3:      	movq	0x20(%rsp), %r12
    1fa8:      	leaq	0x8(%r12), %rdx
    1fad:      	movl	$0x4, %ecx
    1fb2:      	movl	$0x4, %eax
    1fb7:      	movq	%r15, %rdi
    1fba:      	movl	$0x4, %esi
    1fbf:      	callq	*%rax
    1fc1:      	leaq	0x4(%r15), %rdi
    1fc5:      	leaq	0xc(%r12), %rdx
    1fca:      	movl	$0x4, %ecx
    1fcf:      	movl	$0x4, %eax
    1fd4:      	movl	$0x4, %esi
    1fd9:      	callq	*%rax
    1fdb:      	leaq	0x10(%r15), %rdi
    1fdf:      	leaq	0x18(%r12), %rdx
    1fe4:      	movl	$0x4, %ecx
    1fe9:      	movl	$0x4, %eax
    1fee:      	movl	$0x4, %esi
    1ff3:      	callq	*%rax
    1ff5:      	leaq	0x14(%r15), %rdi
    1ff9:      	leaq	0x1c(%r12), %rdx
    1ffe:      	movl	$0x4, %ecx
    2003:      	movl	$0x4, %eax
    2008:      	movl	$0x4, %esi
    200d:      	callq	*%rax
    200f:      	leaq	0x8(%r15), %rdi
    2013:      	leaq	0x10(%r12), %rdx
    2018:      	movl	$0x4, %ecx
    201d:      	movl	$0x4, %eax
    2022:      	movl	$0x4, %esi
    2027:      	callq	*%rax
    2029:      	leaq	0xc(%r15), %rdi
    202d:      	leaq	0x14(%r12), %rdx
    2032:      	movl	$0x4, %ecx
    2037:      	movl	$0x4, %eax
    203c:      	movl	$0x4, %esi
    2041:      	callq	*%rax
    2043:      	leaq	0x18(%r15), %rdi
    2047:      	leaq	0x20(%r12), %rdx
    204c:      	movl	$0x4, %ecx
    2051:      	movl	$0x4, %eax
    2056:      	movl	$0x4, %esi
    205b:      	callq	*%rax
    205d:      	leaq	0x1c(%r15), %rdi
    2061:      	leaq	0x24(%r12), %rdx
    2066:      	movl	$0x4, %ecx
    206b:      	movl	$0x4, %eax
    2070:      	movl	$0x4, %esi
    2075:      	callq	*%rax
    2077:      	movl	$0x0, 0x24(%r15)
    207f:      	leaq	0x20(%r15), %rdi
    2083:      	leaq	0x28(%r12), %rdx
    2088:      	movl	$0x4, %ecx
    208d:      	movl	$0x4, %eax
    2092:      	movl	$0x4, %esi
    2097:      	callq	*%rax
    2099:      	leaq	0x30(%r15), %rdi
    209d:      	leaq	0x40(%r12), %rdx
    20a2:      	movl	$0x8, %ecx
    20a7:      	movl	$0x4, %eax
    20ac:      	movl	$0x8, %esi
    20b1:      	callq	*%rax
    20b3:      	leaq	0x38(%r15), %rdi
    20b7:      	leaq	0x30(%r12), %rdx
    20bc:      	movl	$0x8, %ecx
    20c1:      	movl	$0x4, %eax
    20c6:      	movl	$0x8, %esi
    20cb:      	callq	*%rax
    20cd:      	leaq	0x38(%r12), %rdx
    20d2:      	movl	$0x8, %ecx
    20d7:      	movl	$0x4, %eax
    20dc:      	movq	%r13, %rdi
    20df:      	movl	$0x8, %esi
    20e4:      	callq	*%rax
    20e6:      	addq	$0x90, %r12
    20ed:      	leaq	0x58(%rsp), %rdi
    20f2:      	movl	$0x8, %ecx
    20f7:      	movl	$0x4, %eax
    20fc:      	movl	$0x8, %esi
    2101:      	movq	%r12, %rdx
    2104:      	callq	*%rax
    2106:      	movq	0x58(%rsp), %r12
    210b:      	leaq	0xc8(%r12), %rdx
    2113:      	movl	$0x4, %ecx
    2118:      	movl	$0x4, %eax
    211d:      	movq	0x30(%rsp), %rdi
    2122:      	movl	$0x4, %esi
    2127:      	callq	*%rax
    2129:      	leaq	0x44(%r15), %rdi
    212d:      	leaq	0xcc(%r12), %rdx
    2135:      	movl	$0x4, %ecx
    213a:      	movl	$0x4, %eax
    213f:      	movl	$0x4, %esi
    2144:      	callq	*%rax
    2146:      	leaq	0x48(%r15), %rdi
    214a:      	leaq	0xd0(%r12), %rdx
    2152:      	movl	$0x4, %ecx
    2157:      	movl	$0x4, %eax
    215c:      	movl	$0x4, %esi
    2161:      	callq	*%rax
    2163:      	addq	$0x4c, %r15
    2167:      	addq	$0x158, %r12            # imm = 0x158
    216e:      	movl	$0x4, %ecx
    2173:      	movl	$0x4, %eax
    2178:      	movq	%r15, %rdi
    217b:      	movl	$0x4, %esi
    2180:      	movq	%r12, %rdx
    2183:      	callq	*%rax
    2185:      	movl	$0x50, %r15d
    218b:      	jmp	0x162b <generic_uprobe_process_event+0x138b>
    2190:      	movq	0x20(%rsp), %r12
    2195:      	leaq	0xc8(%r12), %rdx
    219d:      	movl	$0x4, %ecx
    21a2:      	movl	$0x4, %eax
    21a7:      	movq	0x10(%rsp), %r15
    21ac:      	movq	%r15, %rdi
    21af:      	movl	$0x4, %esi
    21b4:      	callq	*%rax
    21b6:      	leaq	0x4(%r15), %rdi
    21ba:      	leaq	0xcc(%r12), %rdx
    21c2:      	movl	$0x4, %ecx
    21c7:      	movl	$0x4, %eax
    21cc:      	movl	$0x4, %esi
    21d1:      	callq	*%rax
    21d3:      	leaq	0x8(%r15), %rdi
    21d7:      	leaq	0xd0(%r12), %rdx
    21df:      	movl	$0x4, %ecx
    21e4:      	movl	$0x4, %eax
    21e9:      	movl	$0x4, %esi
    21ee:      	callq	*%rax
    21f0:      	addq	$0xc, %r15
    21f4:      	addq	$0x158, %r12            # imm = 0x158
    21fb:      	movl	$0x4, %ecx
    2200:      	movl	$0x4, %eax
    2205:      	movq	%r15, %rdi
    2208:      	movl	$0x4, %esi
    220d:      	movq	%r12, %rdx
    2210:      	callq	*%rax
    2212:      	movl	$0x10, %r15d
    2218:      	jmp	0x162b <generic_uprobe_process_event+0x138b>
    221d:      	movq	0x20(%rsp), %r12
    2222:      	leaq	0x38(%r12), %rdx
    2227:      	movl	$0x4, %ecx
    222c:      	movl	$0x4, %eax
    2231:      	movq	0x10(%rsp), %r15
    2236:      	movq	%r15, %rdi
    2239:      	movl	$0x4, %esi
    223e:      	callq	*%rax
    2240:      	leaq	0x4(%r15), %rdi
    2244:      	leaq	0x3c(%r12), %rdx
    2249:      	movl	$0x4, %ecx
    224e:      	movl	$0x4, %eax
    2253:      	movl	$0x4, %esi
    2258:      	callq	*%rax
    225a:      	leaq	0x8(%r15), %rdi
    225e:      	leaq	0x40(%r12), %rdx
    2263:      	movl	$0x4, %ecx
    2268:      	movl	$0x4, %eax
    226d:      	movl	$0x4, %esi
    2272:      	callq	*%rax
    2274:      	leaq	0xc(%r15), %rdi
    2278:      	leaq	0x44(%r12), %rdx
    227d:      	movl	$0x4, %ecx
    2282:      	movl	$0x4, %eax
    2287:      	movl	$0x4, %esi
    228c:      	callq	*%rax
    228e:      	addq	$0x10, %r15
    2292:      	subq	$-0x80, %r12
    2296:      	movl	$0x10, %ecx
    229b:      	movl	$0x4, %eax
    22a0:      	movq	%r15, %rdi
    22a3:      	movl	$0x10, %esi
    22a8:      	movq	%r12, %rdx
    22ab:      	callq	*%rax
    22ad:      	movl	$0x20, %r15d
    22b3:      	jmp	0x162b <generic_uprobe_process_event+0x138b>
    22b8:      	movl	$0x4, %ecx
    22bd:      	movl	$0x4, %eax
    22c2:      	movq	0x10(%rsp), %r15
    22c7:      	movq	0x20(%rsp), %r12
    22cc:      	movq	%r15, %rdi
    22cf:      	movl	$0x4, %esi
    22d4:      	movq	%r12, %rdx
    22d7:      	callq	*%rax
    22d9:      	leaq	0x4(%r15), %rdi
    22dd:      	leaq	0x4(%r12), %rdx
    22e2:      	movl	$0x4, %ecx
    22e7:      	movl	$0x4, %eax
    22ec:      	movl	$0x4, %esi
    22f1:      	callq	*%rax
    22f3:      	addq	$0x8, %r15
    22f7:      	addq	$0x30, %r12
    22fb:      	movl	$0x10, %ecx
    2300:      	movl	$0x4, %eax
    2305:      	movq	%r15, %rdi
    2308:      	movl	$0x10, %esi
    230d:      	movq	%r12, %rdx
    2310:      	jmp	0x23a9 <generic_uprobe_process_event+0x2109>
    2315:      	movq	0x20(%rsp), %r12
    231a:      	leaq	0x4(%r12), %rdx
    231f:      	leaq	0x58(%rsp), %rdi
    2324:      	movl	$0x4, %ecx
    2329:      	movl	$0x4, %eax
    232e:      	movl	$0x4, %esi
    2333:      	callq	*%rax
    2335:      	movl	0x58(%rsp), %eax
    2339:      	movq	0x10(%rsp), %r15
    233e:      	movl	%eax, (%r15)
    2341:      	leaq	0xc(%r12), %rdx
    2346:      	leaq	0x58(%rsp), %rdi
    234b:      	movl	$0x4, %ecx
    2350:      	movl	$0x4, %eax
    2355:      	movl	$0x4, %esi
    235a:      	callq	*%rax
    235c:      	movl	0x58(%rsp), %eax
    2360:      	movl	%eax, 0x4(%r15)
    2364:      	addq	$0x50, %r12
    2368:      	leaq	0x58(%rsp), %rdi
    236d:      	movl	$0x8, %ecx
    2372:      	movl	$0x2d, %eax
    2377:      	movl	$0x8, %esi
    237c:      	movq	%r12, %rdx
    237f:      	callq	*%rax
    2381:      	addq	$0x8, %r15
    2385:      	movl	$0x3f8, %edx            # imm = 0x3F8
    238a:      	movq	0x58(%rsp), %rcx
    238f:      	addq	%rdx, %rcx
    2392:      	movl	$0x10, %esi
    2397:      	movl	$0x2d, %eax
    239c:      	addq	0x58(%rsp), %rdx
    23a1:      	movq	%r15, %rdi
    23a4:      	movl	$0x10, %esi
    23a9:      	callq	*%rax
    23ab:      	movl	$0x18, %r15d
    23b1:      	jmp	0x162b <generic_uprobe_process_event+0x138b>
    23b6:      	movq	%r14, %rbx
    23b9:      	movq	0x10(%rsp), %rax
    23be:      	movq	$0x0, 0x48(%rax)
    23c6:      	movq	$0x0, 0x40(%rax)
    23ce:      	movq	$0x0, 0x38(%rax)
    23d6:      	movq	$0x0, 0x30(%rax)
    23de:      	movq	$0x0, 0x28(%rax)
    23e6:      	movq	$0x0, 0x20(%rax)
    23ee:      	movq	$0x0, 0x18(%rax)
    23f6:      	movq	$0x0, 0x10(%rax)
    23fe:      	movq	$0x0, 0x8(%rax)
    2406:      	movq	$0x0, (%rax)
    240d:      	leaq	0x58(%rsp), %rdi
    2412:      	movl	$0x8, %ecx
    2417:      	movl	$0x4, %eax
    241c:      	movq	0x20(%rsp), %rdx
    2421:      	movl	$0x8, %esi
    2426:      	callq	*%rax
    2428:      	testq	%rax, %rax
    242b:      	je	0x27b4 <generic_uprobe_process_event+0x2514>
    2431:      	xorl	%r15d, %r15d
    2434:      	movq	0x8(%rsp), %rcx
    2439:      	movq	%rbx, %r14
    243c:      	jmp	0x2883 <generic_uprobe_process_event+0x25e3>
    2441:      	movq	$-0x1, %r15
    2448:      	jmp	0x2644 <generic_uprobe_process_event+0x23a4>
    244d:      	leaq	0x10(%r13), %rdx
    2451:      	leaq	0x98(%rsp), %rdi
    2459:      	movl	$0x8, %ecx
    245e:      	movl	$0x4, %eax
    2463:      	movl	$0x8, %esi
    2468:      	callq	*%rax
    246a:      	addq	$0x18, %r13
    246e:      	leaq	0x40(%rsp), %rdi
    2473:      	movl	$0x8, %ecx
    2478:      	movl	$0x4, %eax
    247d:      	movl	$0x8, %esi
    2482:      	movq	%r13, %rdx
    2485:      	callq	*%rax
    2487:      	movq	0x98(%rsp), %rdx
    248f:      	movq	0x40(%rsp), %r12
    2494:      	cmpq	$0xfff, %r12            # imm = 0xFFF
    249b:      	movl	$0xfff, %r15d           # imm = 0xFFF
    24a1:      	cmovbq	%r12, %r15
    24a5:      	movq	0x50(%rsp), %rcx
    24aa:      	leaq	(%rcx,%rbp), %rdi
    24ae:      	addq	$0x98, %rdi
    24b5:      	movl	$0x4, %eax
    24ba:      	leaq	(%rcx,%rbp), %r13
    24be:      	addq	$0x90, %r13
    24c5:      	movl	%r15d, %esi
    24c8:      	callq	*%rax
    24ca:      	testl	%eax, %eax
    24cc:      	js	0x289c <generic_uprobe_process_event+0x25fc>
    24d2:      	movl	%r12d, (%r13)
    24d6:      	movl	%r15d, 0x4(%r13)
    24da:      	addq	$0x8, %r15
    24de:      	jmp	0x303a <generic_uprobe_process_event+0x2d9a>
    24e3:      	movq	0x58(%rsp), %rbx
    24e8:      	movl	$0x0, 0x98(%rsp)
    24f3:      	movzwl	0xc8(%rsp), %ebp
    24fb:      	movq	(%rip), %rdi            # 0x2502 <generic_uprobe_process_event+0x2262>
    2502:      	leaq	0x98(%rsp), %rsi
    250a:      	movl	$0x1, %eax
    250f:      	leaq	(%rbx,%rbp), %r13
    2513:      	callq	*%rax
    2515:      	testq	%rax, %rax
    2518:      	je	0x355c <generic_uprobe_process_event+0x32bc>
    251e:      	movq	%rax, %r15
    2521:      	movw	%bp, (%rax)
    2524:      	movb	$-0x1, 0x5(%rax)
    2528:      	movb	$0x0, 0x7(%rax)
    252c:      	movq	%rax, %r14
    252f:      	addq	$0x6, %r14
    2533:      	leaq	0x6(%r13), %rdx
    2537:      	movl	$0x1, %ecx
    253c:      	movl	$0x4, %eax
    2541:      	movq	%r14, %rdi
    2544:      	movl	$0x1, %esi
    2549:      	callq	*%rax
    254b:      	testq	%rax, %rax
    254e:      	js	0x355c <generic_uprobe_process_event+0x32bc>
    2554:      	movzbl	0x5(%r15), %eax
    2559:      	cmpl	$0x32, %eax
    255c:      	jg	0x2ef3 <generic_uprobe_process_event+0x2c53>
    2562:      	testl	%eax, %eax
    2564:      	je	0x2f99 <generic_uprobe_process_event+0x2cf9>
    256a:      	cmpl	$0x2b, %eax
    256d:      	je	0x2f99 <generic_uprobe_process_event+0x2cf9>
    2573:      	cmpl	$0x2c, %eax
    2576:      	jne	0x3107 <generic_uprobe_process_event+0x2e67>
    257c:      	movw	$0x8, 0x2(%r15)
    2583:      	movw	$0x8, %ax
    2587:      	jmp	0x3058 <generic_uprobe_process_event+0x2db8>
    258c:      	leaq	0x48(%r15), %rdx
    2590:      	movl	$0x10, %ecx
    2595:      	movl	$0x4, %eax
    259a:      	movq	0x10(%rsp), %rdi
    259f:      	movl	$0x10, %esi
    25a4:      	callq	*%rax
    25a6:      	leaq	0x38(%r15), %rdx
    25aa:      	movl	$0x10, %ecx
    25af:      	movl	$0x4, %eax
    25b4:      	movq	%r12, %rdi
    25b7:      	movl	$0x10, %esi
    25bc:      	callq	*%rax
    25be:      	movq	0x10(%rsp), %r14
    25c3:      	leaq	0x20(%r14), %rdi
    25c7:      	leaq	0xc(%r15), %r12
    25cb:      	addq	$0xe, %r15
    25cf:      	movl	$0x2, %ecx
    25d4:      	movl	$0x4, %eax
    25d9:      	movl	$0x2, %esi
    25de:      	movq	%r15, %rdx
    25e1:      	callq	*%rax
    25e3:      	leaq	0x22(%r14), %rdi
    25e7:      	movl	$0x2, %ecx
    25ec:      	movl	$0x4, %eax
    25f1:      	movl	$0x2, %esi
    25f6:      	movq	%r12, %rdx
    25f9:      	callq	*%rax
    25fb:      	movzwl	0x22(%r14), %eax
    2600:      	movbew	%ax, 0x22(%r14)
    2607:      	movq	0x38(%rsp), %rax
    260c:      	movq	%rax, 0x58(%rsp)
    2611:      	movq	(%rip), %rdi            # 0x2618 <generic_uprobe_process_event+0x2378>
    2618:      	leaq	0x58(%rsp), %rsi
    261d:      	movl	$0x1, %eax
    2622:      	callq	*%rax
    2624:      	testq	%rax, %rax
    2627:      	je	0x263e <generic_uprobe_process_event+0x239e>
    2629:      	movl	(%rax), %ecx
    262b:      	movl	%ecx, 0x10(%r13)
    262f:      	movq	0x8(%rax), %rcx
    2633:      	movq	%rcx, 0x18(%r13)
    2637:      	movl	0x4(%rax), %eax
    263a:      	movl	%eax, 0x7c(%r13)
    263e:      	movl	$0x40, %r15d
    2644:      	movq	0x8(%rsp), %rcx
    2649:      	movq	%rbx, %r14
    264c:      	movq	%rbp, %rbx
    264f:      	movq	0x18(%rsp), %rbp
    2654:      	jmp	0x1630 <generic_uprobe_process_event+0x1390>
    2659:      	movq	0x50(%rsp), %rax
    265e:      	movq	$0x0, 0x90(%rbp,%rax)
    266a:      	movl	$0x8, %r15d
    2670:      	jmp	0x303a <generic_uprobe_process_event+0x2d9a>
    2675:      	movl	$0xe, %eax
    267a:      	callq	*%rax
    267c:      	cmpq	$-0x16, %rax
    2680:      	jne	0x26a1 <generic_uprobe_process_event+0x2401>
    2682:      	leaq	0x20(%rbx), %rdx
    2686:      	leaq	0x58(%rsp), %rdi
    268b:      	movl	$0x8, %ecx
    2690:      	movl	$0x4, %eax
    2695:      	movl	$0x8, %esi
    269a:      	callq	*%rax
    269c:      	movq	0x58(%rsp), %rax
    26a1:      	movq	0x8(%r14), %rcx
    26a5:      	movq	0x60(%r14), %rdx
    26a9:      	movq	%rcx, 0x58(%rsp)
    26ae:      	movq	0x20(%rsp), %rcx
    26b3:      	movq	%rcx, 0x60(%rsp)
    26b8:      	movq	$0x0, 0x68(%rsp)
    26c1:      	movq	%rdx, 0x98(%rsp)
    26c9:      	movq	%rax, 0xa0(%rsp)
    26d1:      	movq	(%rip), %rdi            # 0x26d8 <generic_uprobe_process_event+0x2438>
    26d8:      	xorl	%ecx, %ecx
    26da:      	leaq	0x98(%rsp), %rsi
    26e2:      	leaq	0x58(%rsp), %rdx
    26e7:      	movl	$0x2, %eax
    26ec:      	xorl	%ecx, %ecx
    26ee:      	callq	*%rax
    26f0:      	testq	%rax, %rax
    26f3:      	je	0x2f4a <generic_uprobe_process_event+0x2caa>
    26f9:      	negl	%eax
    26fb:      	movw	%ax, 0x40(%rsp)
    2700:      	movw	$0x5, 0x42(%rsp)
    2707:      	movabsq	$0x200000046, %rax      # imm = 0x200000046
    2711:      	movq	%rax, 0x44(%rsp)
    2716:      	movq	(%rip), %rdi            # 0x271d <generic_uprobe_process_event+0x247d>
    271d:      	leaq	0x40(%rsp), %rsi
    2722:      	movl	$0x1, %eax
    2727:      	callq	*%rax
    2729:      	testq	%rax, %rax
    272c:      	je	0x2f20 <generic_uprobe_process_event+0x2c80>
    2732:      	incl	(%rax)
    2734:      	jmp	0x2f4a <generic_uprobe_process_event+0x2caa>
    2739:      	cmpl	$0x1, %eax
    273c:      	je	0x29e0 <generic_uprobe_process_event+0x2740>
    2742:      	cmpl	$0x2, %eax
    2745:      	jne	0x2e01 <generic_uprobe_process_event+0x2b61>
    274b:      	movq	%r13, %rax
    274e:      	addq	$0x5e58, %rax           # imm = 0x5E58
    2754:      	jmp	0x29e9 <generic_uprobe_process_event+0x2749>
    2759:      	movq	0x10(%rsp), %r12
    275e:      	leaq	0x8(%r12), %rdi
    2763:      	leaq	0x8(%r15), %rdx
    2767:      	movl	$0x10, %ecx
    276c:      	movl	$0x4, %eax
    2771:      	movl	$0x10, %esi
    2776:      	callq	*%rax
    2778:      	leaq	0x2(%r12), %rdi
    277d:      	addq	$0x2, %r15
    2781:      	movl	$0x2, %ecx
    2786:      	movl	$0x4, %eax
    278b:      	movl	$0x2, %esi
    2790:      	movq	%r15, %rdx
    2793:      	callq	*%rax
    2795:      	movq	0x10(%rsp), %rcx
    279a:      	movzwl	0x2(%rcx), %eax
    279e:      	movbew	%ax, 0x2(%rcx)
    27a4:      	movq	0x18(%rsp), %rbp
    27a9:      	movl	$0x18, %r15d
    27af:      	jmp	0x162b <generic_uprobe_process_event+0x138b>
    27b4:      	movq	0x10(%rsp), %rax
    27b9:      	leaq	0x10(%rax), %rdi
    27bd:      	movq	0x58(%rsp), %rcx
    27c2:      	movl	$0x3f, %edx
    27c7:      	movl	$0x2d, %eax
    27cc:      	movq	0x58(%rsp), %rdx
    27d1:      	movl	$0x3f, %esi
    27d6:      	callq	*%rax
    27d8:      	testq	%rax, %rax
    27db:      	js	0x2431 <generic_uprobe_process_event+0x2191>
    27e1:      	movq	0x20(%rsp), %r14
    27e6:      	leaq	0x8(%r14), %rdx
    27ea:      	leaq	0x98(%rsp), %rdi
    27f2:      	movl	$0x8, %ecx
    27f7:      	movl	$0x4, %eax
    27fc:      	movl	$0x8, %esi
    2801:      	callq	*%rax
    2803:      	movq	0x10(%rsp), %rax
    2808:      	leaq	0x8(%rax), %rdi
    280c:      	movl	$0x348, %edx            # imm = 0x348
    2811:      	movq	0x98(%rsp), %rcx
    2819:      	addq	%rdx, %rcx
    281c:      	movl	$0x8, %esi
    2821:      	movl	$0x4, %eax
    2826:      	addq	0x98(%rsp), %rdx
    282e:      	movl	$0x8, %esi
    2833:      	callq	*%rax
    2835:      	addq	$0x58, %r14
    2839:      	leaq	0x98(%rsp), %rdi
    2841:      	movl	$0x4, %ecx
    2846:      	movl	$0x4, %eax
    284b:      	movl	$0x4, %esi
    2850:      	movq	%r14, %rdx
    2853:      	callq	*%rax
    2855:      	movl	$0x50, %r15d
    285b:      	testq	%rax, %rax
    285e:      	jne	0x2434 <generic_uprobe_process_event+0x2194>
    2864:      	xorl	%eax, %eax
    2866:      	cmpl	$0x0, 0x98(%rsp)
    286e:      	setne	%al
    2871:      	movq	0x10(%rsp), %rcx
    2876:      	movl	%eax, (%rcx)
    2878:      	jmp	0x2434 <generic_uprobe_process_event+0x2194>
    287d:      	xorl	%r15d, %r15d
    2880:      	movq	%r12, %rcx
    2883:      	movq	%r13, %rbx
    2886:      	movq	0x18(%rsp), %rbp
    288b:      	jmp	0x1630 <generic_uprobe_process_event+0x1390>
    2890:      	movl	$0xfffffffe, (%rbp)     # imm = 0xFFFFFFFE
    2897:      	jmp	0x303a <generic_uprobe_process_event+0x2d9a>
    289c:      	movl	$0xfffffffe, (%r13)     # imm = 0xFFFFFFFE
    28a4:      	movl	$0x4, %r15d
    28aa:      	jmp	0x303a <generic_uprobe_process_event+0x2d9a>
    28af:      	addq	$0x3, %r15
    28b3:      	movl	$0x6b, %ecx
    28b8:      	movl	$0x71, %eax
    28bd:      	movl	$0x6b, %esi
    28c2:      	movq	%r15, %rdx
    28c5:      	callq	*%rax
    28c7:      	movq	%rax, %rcx
    28ca:      	movb	$0x6b, %al
    28cc:      	testl	%ecx, %ecx
    28ce:      	movq	0x18(%rsp), %rbp
    28d3:      	js	0x28dd <generic_uprobe_process_event+0x263d>
    28d5:      	movq	0x10(%rsp), %rcx
    28da:      	movb	%al, 0x3(%rcx)
    28dd:      	movl	$0x70, %r15d
    28e3:      	jmp	0x162b <generic_uprobe_process_event+0x138b>
    28e8:      	cmpl	$0x1, %ecx
    28eb:      	je	0x2fbc <generic_uprobe_process_event+0x2d1c>
    28f1:      	cmpl	$0x2, %ecx
    28f4:      	jne	0x2fc6 <generic_uprobe_process_event+0x2d26>
    28fa:      	addq	$0x5e58, %r14           # imm = 0x5E58
    2901:      	jmp	0x2fc3 <generic_uprobe_process_event+0x2d23>
    2906:      	leaq	0x48(%r15), %rdx
    290a:      	movl	$0x10, %ecx
    290f:      	movl	$0x4, %eax
    2914:      	movq	0x10(%rsp), %rdi
    2919:      	movl	$0x10, %esi
    291e:      	callq	*%rax
    2920:      	leaq	0x38(%r15), %rdx
    2924:      	movl	$0x10, %ecx
    2929:      	movl	$0x4, %eax
    292e:      	movq	%r12, %rdi
    2931:      	movl	$0x10, %esi
    2936:      	callq	*%rax
    2938:      	movq	0x10(%rsp), %r14
    293d:      	leaq	0x20(%r14), %rdi
    2941:      	leaq	0xc(%r15), %r12
    2945:      	addq	$0xe, %r15
    2949:      	movl	$0x2, %ecx
    294e:      	movl	$0x4, %eax
    2953:      	movl	$0x2, %esi
    2958:      	movq	%r15, %rdx
    295b:      	callq	*%rax
    295d:      	leaq	0x22(%r14), %rdi
    2961:      	movl	$0x2, %ecx
    2966:      	movl	$0x4, %eax
    296b:      	movl	$0x2, %esi
    2970:      	movq	%r12, %rdx
    2973:      	callq	*%rax
    2975:      	movzwl	0x22(%r14), %eax
    297a:      	movbew	%ax, 0x22(%r14)
    2981:      	movq	0x10(%rsp), %rax
    2986:      	movq	0x28(%rax), %rax
    298a:      	movq	%rax, 0x58(%rsp)
    298f:      	movq	(%rip), %rdi            # 0x2996 <generic_uprobe_process_event+0x26f6>
    2996:      	leaq	0x58(%rsp), %rsi
    299b:      	movl	$0x1, %eax
    29a0:      	callq	*%rax
    29a2:      	testq	%rax, %rax
    29a5:      	je	0x29bc <generic_uprobe_process_event+0x271c>
    29a7:      	movl	(%rax), %ecx
    29a9:      	movl	%ecx, 0x10(%r13)
    29ad:      	movq	0x8(%rax), %rcx
    29b1:      	movq	%rcx, 0x18(%r13)
    29b5:      	movl	0x4(%rax), %eax
    29b8:      	movl	%eax, 0x7c(%r13)
    29bc:      	movl	$0x40, %r15d
    29c2:      	movq	%rbp, %rcx
    29c5:      	jmp	0x303f <generic_uprobe_process_event+0x2d9f>
    29ca:      	movq	%r13, %rax
    29cd:      	addq	$0x5e60, %rax           # imm = 0x5E60
    29d3:      	jmp	0x29e9 <generic_uprobe_process_event+0x2749>
    29d5:      	movq	%r13, %rax
    29d8:      	addq	$0x5e68, %rax           # imm = 0x5E68
    29de:      	jmp	0x29e9 <generic_uprobe_process_event+0x2749>
    29e0:      	movq	%r13, %rax
    29e3:      	addq	$0x5e50, %rax           # imm = 0x5E50
    29e9:      	movq	(%rax), %r14
    29ec:      	testb	$0x10, 0xb0(%rsp)
    29f4:      	jne	0x2e17 <generic_uprobe_process_event+0x2b77>
    29fa:      	testq	%r14, %r14
    29fd:      	je	0x2ed7 <generic_uprobe_process_event+0x2c37>
    2a03:      	leaq	0x58(%rsp), %rdi
    2a08:      	movl	$0x4, %r15d
    2a0e:      	movl	$0x10, %ecx
    2a13:      	movl	$0x4, %eax
    2a18:      	movq	0x20(%rsp), %rdx
    2a1d:      	movl	$0x10, %esi
    2a22:      	callq	*%rax
    2a24:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2a29:      	testl	%eax, %eax
    2a2b:      	js	0x2df3 <generic_uprobe_process_event+0x2b53>
    2a31:      	movq	0x60(%rsp), %rax
    2a36:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2a3b:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2a41:      	ja	0x2df3 <generic_uprobe_process_event+0x2b53>
    2a47:      	movq	%rax, %rbp
    2a4a:      	movq	0x18(%rsp), %rax
    2a4f:      	leaq	0xc(%rax), %r13
    2a53:      	movl	%r13d, %edi
    2a56:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2a5c:      	addq	%r12, %rdi
    2a5f:      	movq	0x58(%rsp), %rcx
    2a64:      	movl	$0x4, %eax
    2a69:      	movq	%rbp, %rsi
    2a6c:      	movq	0x58(%rsp), %rdx
    2a71:      	callq	*%rax
    2a73:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2a78:      	testl	%eax, %eax
    2a7a:      	js	0x2df3 <generic_uprobe_process_event+0x2b53>
    2a80:      	cmpq	$0x1, %r14
    2a84:      	je	0x2ed9 <generic_uprobe_process_event+0x2c39>
    2a8a:      	movq	0x20(%rsp), %rax
    2a8f:      	leaq	0x10(%rax), %rdx
    2a93:      	leaq	0x58(%rsp), %rdi
    2a98:      	movl	$0x4, %r15d
    2a9e:      	movl	$0x10, %ecx
    2aa3:      	movl	$0x4, %eax
    2aa8:      	movl	$0x10, %esi
    2aad:      	callq	*%rax
    2aaf:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2ab4:      	testl	%eax, %eax
    2ab6:      	js	0x2df3 <generic_uprobe_process_event+0x2b53>
    2abc:      	movq	0x60(%rsp), %rax
    2ac1:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2ac6:      	movq	%rax, 0x30(%rsp)
    2acb:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2ad1:      	ja	0x2df3 <generic_uprobe_process_event+0x2b53>
    2ad7:      	addq	%rbp, %r13
    2ada:      	movl	%r13d, %edi
    2add:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2ae3:      	addq	%r12, %rdi
    2ae6:      	movq	0x58(%rsp), %rcx
    2aeb:      	movl	$0x4, %eax
    2af0:      	movq	0x30(%rsp), %rsi
    2af5:      	movq	0x58(%rsp), %rdx
    2afa:      	callq	*%rax
    2afc:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2b01:      	testl	%eax, %eax
    2b03:      	js	0x2df3 <generic_uprobe_process_event+0x2b53>
    2b09:      	addq	0x30(%rsp), %rbp
    2b0e:      	cmpq	$0x3, %r14
    2b12:      	jb	0x2ed9 <generic_uprobe_process_event+0x2c39>
    2b18:      	movq	0x20(%rsp), %rax
    2b1d:      	leaq	0x20(%rax), %rdx
    2b21:      	leaq	0x58(%rsp), %rdi
    2b26:      	movl	$0x4, %r15d
    2b2c:      	movl	$0x10, %ecx
    2b31:      	movl	$0x4, %eax
    2b36:      	movl	$0x10, %esi
    2b3b:      	callq	*%rax
    2b3d:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2b42:      	testl	%eax, %eax
    2b44:      	js	0x2df3 <generic_uprobe_process_event+0x2b53>
    2b4a:      	movq	0x60(%rsp), %rax
    2b4f:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2b54:      	movq	%rax, 0xb0(%rsp)
    2b5c:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2b62:      	ja	0x2df3 <generic_uprobe_process_event+0x2b53>
    2b68:      	movq	0x30(%rsp), %rdi
    2b6d:      	addq	%r13, %rdi
    2b70:      	movq	%rdi, %r13
    2b73:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2b79:      	addq	%r12, %rdi
    2b7c:      	movq	0x58(%rsp), %rcx
    2b81:      	movl	$0x4, %eax
    2b86:      	movq	0xb0(%rsp), %rsi
    2b8e:      	movq	0x58(%rsp), %rdx
    2b93:      	callq	*%rax
    2b95:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2b9a:      	testl	%eax, %eax
    2b9c:      	js	0x2df3 <generic_uprobe_process_event+0x2b53>
    2ba2:      	addq	0xb0(%rsp), %rbp
    2baa:      	cmpq	$0x3, %r14
    2bae:      	je	0x2ed9 <generic_uprobe_process_event+0x2c39>
    2bb4:      	movq	0x20(%rsp), %rax
    2bb9:      	leaq	0x30(%rax), %rdx
    2bbd:      	leaq	0x58(%rsp), %rdi
    2bc2:      	movl	$0x4, %r15d
    2bc8:      	movl	$0x10, %ecx
    2bcd:      	movl	$0x4, %eax
    2bd2:      	movl	$0x10, %esi
    2bd7:      	callq	*%rax
    2bd9:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2bde:      	testl	%eax, %eax
    2be0:      	js	0x2df3 <generic_uprobe_process_event+0x2b53>
    2be6:      	movq	0x60(%rsp), %rax
    2beb:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2bf0:      	movq	%rax, 0x30(%rsp)
    2bf5:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2bfb:      	ja	0x2df3 <generic_uprobe_process_event+0x2b53>
    2c01:      	movq	0xb0(%rsp), %rdi
    2c09:      	addq	%r13, %rdi
    2c0c:      	movq	%rdi, %r13
    2c0f:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2c15:      	addq	%r12, %rdi
    2c18:      	movq	0x58(%rsp), %rcx
    2c1d:      	movl	$0x4, %eax
    2c22:      	movq	0x30(%rsp), %rsi
    2c27:      	movq	0x58(%rsp), %rdx
    2c2c:      	callq	*%rax
    2c2e:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2c33:      	testl	%eax, %eax
    2c35:      	js	0x2df3 <generic_uprobe_process_event+0x2b53>
    2c3b:      	addq	0x30(%rsp), %rbp
    2c40:      	cmpq	$0x5, %r14
    2c44:      	jb	0x2ed9 <generic_uprobe_process_event+0x2c39>
    2c4a:      	movq	0x20(%rsp), %rax
    2c4f:      	leaq	0x40(%rax), %rdx
    2c53:      	leaq	0x58(%rsp), %rdi
    2c58:      	movl	$0x4, %r15d
    2c5e:      	movl	$0x10, %ecx
    2c63:      	movl	$0x4, %eax
    2c68:      	movl	$0x10, %esi
    2c6d:      	callq	*%rax
    2c6f:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2c74:      	testl	%eax, %eax
    2c76:      	js	0x2df3 <generic_uprobe_process_event+0x2b53>
    2c7c:      	movq	0x60(%rsp), %rax
    2c81:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2c86:      	movq	%rax, 0xb0(%rsp)
    2c8e:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2c94:      	ja	0x2df3 <generic_uprobe_process_event+0x2b53>
    2c9a:      	movq	0x30(%rsp), %rdi
    2c9f:      	addq	%r13, %rdi
    2ca2:      	movq	%rdi, %r13
    2ca5:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2cab:      	addq	%r12, %rdi
    2cae:      	movq	0x58(%rsp), %rcx
    2cb3:      	movl	$0x4, %eax
    2cb8:      	movq	0xb0(%rsp), %rsi
    2cc0:      	movq	0x58(%rsp), %rdx
    2cc5:      	callq	*%rax
    2cc7:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2ccc:      	testl	%eax, %eax
    2cce:      	js	0x2df3 <generic_uprobe_process_event+0x2b53>
    2cd4:      	addq	0xb0(%rsp), %rbp
    2cdc:      	cmpq	$0x5, %r14
    2ce0:      	je	0x2ed9 <generic_uprobe_process_event+0x2c39>
    2ce6:      	movq	0x20(%rsp), %rax
    2ceb:      	leaq	0x50(%rax), %rdx
    2cef:      	leaq	0x58(%rsp), %rdi
    2cf4:      	movl	$0x4, %r15d
    2cfa:      	movl	$0x10, %ecx
    2cff:      	movl	$0x4, %eax
    2d04:      	movl	$0x10, %esi
    2d09:      	callq	*%rax
    2d0b:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2d10:      	testl	%eax, %eax
    2d12:      	js	0x2df3 <generic_uprobe_process_event+0x2b53>
    2d18:      	movq	0x60(%rsp), %rax
    2d1d:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2d22:      	movq	%rax, 0x30(%rsp)
    2d27:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2d2d:      	ja	0x2df3 <generic_uprobe_process_event+0x2b53>
    2d33:      	movq	0xb0(%rsp), %rdi
    2d3b:      	addq	%r13, %rdi
    2d3e:      	movq	%rdi, %r13
    2d41:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2d47:      	addq	%r12, %rdi
    2d4a:      	movq	0x58(%rsp), %rcx
    2d4f:      	movl	$0x4, %eax
    2d54:      	movq	0x30(%rsp), %rsi
    2d59:      	movq	0x58(%rsp), %rdx
    2d5e:      	callq	*%rax
    2d60:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2d65:      	testl	%eax, %eax
    2d67:      	js	0x2df3 <generic_uprobe_process_event+0x2b53>
    2d6d:      	addq	0x30(%rsp), %rbp
    2d72:      	cmpq	$0x7, %r14
    2d76:      	jb	0x2ed9 <generic_uprobe_process_event+0x2c39>
    2d7c:      	movq	0x20(%rsp), %rdx
    2d81:      	addq	$0x60, %rdx
    2d85:      	leaq	0x58(%rsp), %rdi
    2d8a:      	movl	$0x4, %r15d
    2d90:      	movl	$0x10, %ecx
    2d95:      	movl	$0x4, %eax
    2d9a:      	movl	$0x10, %esi
    2d9f:      	callq	*%rax
    2da1:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2da6:      	testl	%eax, %eax
    2da8:      	js	0x2df3 <generic_uprobe_process_event+0x2b53>
    2daa:      	movq	0x60(%rsp), %r14
    2daf:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2db4:      	cmpq	$0xffe, %r14            # imm = 0xFFE
    2dbb:      	ja	0x2df3 <generic_uprobe_process_event+0x2b53>
    2dbd:      	movq	0x30(%rsp), %rdi
    2dc2:      	addq	%r13, %rdi
    2dc5:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2dcb:      	addq	%r12, %rdi
    2dce:      	movq	0x58(%rsp), %rcx
    2dd3:      	movl	$0x4, %eax
    2dd8:      	movq	0x58(%rsp), %rdx
    2ddd:      	movl	%r14d, %esi
    2de0:      	callq	*%rax
    2de2:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2de7:      	testl	%eax, %eax
    2de9:      	js	0x2df3 <generic_uprobe_process_event+0x2b53>
    2deb:      	addq	%r14, %rbp
    2dee:      	jmp	0x2ed9 <generic_uprobe_process_event+0x2c39>
    2df3:      	movq	0x50(%rsp), %rax
    2df8:      	movl	%ecx, (%r12,%rax)
    2dfc:      	jmp	0x303a <generic_uprobe_process_event+0x2d9a>
    2e01:      	xorl	%r14d, %r14d
    2e04:      	movl	$0x0, %ebp
    2e09:      	testb	$0x10, 0xb0(%rsp)
    2e11:      	je	0x2ed9 <generic_uprobe_process_event+0x2c39>
    2e17:      	movl	$0xe, %eax
    2e1c:      	callq	*%rax
    2e1e:      	cmpq	$-0x16, %rax
    2e22:      	jne	0x2e43 <generic_uprobe_process_event+0x2ba3>
    2e24:      	leaq	0x20(%rbx), %rdx
    2e28:      	leaq	0x58(%rsp), %rdi
    2e2d:      	movl	$0x8, %ecx
    2e32:      	movl	$0x4, %eax
    2e37:      	movl	$0x8, %esi
    2e3c:      	callq	*%rax
    2e3e:      	movq	0x58(%rsp), %rax
    2e43:      	movq	0x8(%r13), %rcx
    2e47:      	movq	0x60(%r13), %rdx
    2e4b:      	movq	%rcx, 0x58(%rsp)
    2e50:      	movq	0x20(%rsp), %rcx
    2e55:      	movq	%rcx, 0x60(%rsp)
    2e5a:      	movq	%r14, 0x68(%rsp)
    2e5f:      	movq	%rdx, 0x98(%rsp)
    2e67:      	movq	%rax, 0xa0(%rsp)
    2e6f:      	movq	(%rip), %rdi            # 0x2e76 <generic_uprobe_process_event+0x2bd6>
    2e76:      	xorl	%ecx, %ecx
    2e78:      	leaq	0x98(%rsp), %rsi
    2e80:      	leaq	0x58(%rsp), %rdx
    2e85:      	movl	$0x2, %eax
    2e8a:      	xorl	%ecx, %ecx
    2e8c:      	callq	*%rax
    2e8e:      	testq	%rax, %rax
    2e91:      	je	0x2f81 <generic_uprobe_process_event+0x2ce1>
    2e97:      	negl	%eax
    2e99:      	movw	%ax, 0x40(%rsp)
    2e9e:      	movw	$0x5, 0x42(%rsp)
    2ea5:      	movabsq	$0x200000057, %rax      # imm = 0x200000057
    2eaf:      	movq	%rax, 0x44(%rsp)
    2eb4:      	movq	(%rip), %rdi            # 0x2ebb <generic_uprobe_process_event+0x2c1b>
    2ebb:      	leaq	0x40(%rsp), %rsi
    2ec0:      	movl	$0x1, %eax
    2ec5:      	callq	*%rax
    2ec7:      	testq	%rax, %rax
    2eca:      	je	0x2f5d <generic_uprobe_process_event+0x2cbd>
    2ed0:      	incl	(%rax)
    2ed2:      	jmp	0x2f81 <generic_uprobe_process_event+0x2ce1>
    2ed7:      	xorl	%ebp, %ebp
    2ed9:      	movq	0x50(%rsp), %rax
    2ede:      	movl	%ebp, (%r12,%rax)
    2ee2:      	movl	%ebp, 0x4(%r12,%rax)
    2ee7:      	addq	$0x8, %rbp
    2eeb:      	movq	%rbp, %r15
    2eee:      	jmp	0x303a <generic_uprobe_process_event+0x2d9a>
    2ef3:      	cmpl	$0x33, %eax
    2ef6:      	je	0x3047 <generic_uprobe_process_event+0x2da7>
    2efc:      	cmpl	$0x3c, %eax
    2eff:      	je	0x2f99 <generic_uprobe_process_event+0x2cf9>
    2f05:      	cmpl	$0xff, %eax
    2f0a:      	jne	0x3107 <generic_uprobe_process_event+0x2e67>
    2f10:      	movw	$0x28, 0x2(%r15)
    2f17:      	movw	$0x28, %ax
    2f1b:      	jmp	0x3058 <generic_uprobe_process_event+0x2db8>
    2f20:      	movl	$0x1, 0xc8(%rsp)
    2f2b:      	movq	(%rip), %rdi            # 0x2f32 <generic_uprobe_process_event+0x2c92>
    2f32:      	xorl	%ecx, %ecx
    2f34:      	leaq	0x40(%rsp), %rsi
    2f39:      	leaq	0xc8(%rsp), %rdx
    2f41:      	movl	$0x2, %eax
    2f46:      	xorl	%ecx, %ecx
    2f48:      	callq	*%rax
    2f4a:      	movl	$0xfffffffc, (%r12)     # imm = 0xFFFFFFFC
    2f52:      	movl	$0x4, %r15d
    2f58:      	jmp	0x303a <generic_uprobe_process_event+0x2d9a>
    2f5d:      	movl	$0x1, 0x38(%rsp)
    2f65:      	movq	(%rip), %rdi            # 0x2f6c <generic_uprobe_process_event+0x2ccc>
    2f6c:      	xorl	%ecx, %ecx
    2f6e:      	leaq	0x40(%rsp), %rsi
    2f73:      	leaq	0x38(%rsp), %rdx
    2f78:      	movl	$0x2, %eax
    2f7d:      	xorl	%ecx, %ecx
    2f7f:      	callq	*%rax
    2f81:      	movq	0x50(%rsp), %rax
    2f86:      	movl	$0xfffffffc, (%r12,%rax) # imm = 0xFFFFFFFC
    2f8e:      	movl	$0x4, %r15d
    2f94:      	jmp	0x303a <generic_uprobe_process_event+0x2d9a>
    2f99:      	movzbl	0x7(%r15), %eax
    2f9e:      	leal	0x8(,%rax,8), %eax
    2fa5:      	jmp	0x3053 <generic_uprobe_process_event+0x2db3>
    2faa:      	addq	$0x5e60, %r14           # imm = 0x5E60
    2fb1:      	jmp	0x2fc3 <generic_uprobe_process_event+0x2d23>
    2fb3:      	addq	$0x5e68, %r14           # imm = 0x5E68
    2fba:      	jmp	0x2fc3 <generic_uprobe_process_event+0x2d23>
    2fbc:      	addq	$0x5e50, %r14           # imm = 0x5E50
    2fc3:      	movq	(%r14), %rax
    2fc6:      	movq	%rax, 0x38(%rsp)
    2fcb:      	leaq	0xd0(%rsp), %rdi
    2fd3:      	leaq	0x38(%rsp), %rdx
    2fd8:      	movl	$0x8, %ecx
    2fdd:      	movl	$0x4, %eax
    2fe2:      	movl	$0x4, %r15d
    2fe8:      	movl	$0x8, %esi
    2fed:      	callq	*%rax
    2fef:      	movq	0xd0(%rsp), %rbp
    2ff7:      	cmpq	$0xfff, %rbp            # imm = 0xFFF
    2ffe:      	movl	$0xfff, %r13d           # imm = 0xFFF
    3004:      	cmovbq	%rbp, %r13
    3008:      	leaq	0x8(%r12), %rdi
    300d:      	movl	$0x4, %eax
    3012:      	movq	0x20(%rsp), %rdx
    3017:      	movl	%r13d, %esi
    301a:      	callq	*%rax
    301c:      	testl	%eax, %eax
    301e:      	js	0x3032 <generic_uprobe_process_event+0x2d92>
    3020:      	movl	%ebp, (%r12)
    3024:      	movl	%r13d, 0x4(%r12)
    3029:      	addq	$0x8, %r13
    302d:      	movq	%r13, %r15
    3030:      	jmp	0x303a <generic_uprobe_process_event+0x2d9a>
    3032:      	movl	$0xfffffffe, (%r12)     # imm = 0xFFFFFFFE
    303a:      	movq	0x8(%rsp), %rcx
    303f:      	movq	%rbx, %r14
    3042:      	jmp	0x3728 <generic_uprobe_process_event+0x3488>
    3047:      	movzbl	0x7(%r15), %eax
    304c:      	leal	0x8(,%rax,4), %eax
    3053:      	movw	%ax, 0x2(%r15)
    3058:      	addw	(%r15), %ax
    305c:      	movw	%ax, (%r15)
    3060:      	movzbl	0x6(%r15), %ebp
    3065:      	cmpq	$0x3c, %rbp
    3069:      	ja	0x3737 <generic_uprobe_process_event+0x3497>
    306f:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3079:      	btq	%rbp, %rcx
    307d:      	jae	0x3737 <generic_uprobe_process_event+0x3497>
    3083:      	movb	%bpl, 0x5(%r15)
    3087:      	movzwl	%ax, %ecx
    308a:      	addq	%rbx, %rcx
    308d:      	movl	$0x2, %edx
    3092:      	movl	$0x4, %eax
    3097:      	movzwl	(%r15), %edx
    309b:      	addq	%rbx, %rdx
    309e:      	movq	%r14, %rdi
    30a1:      	movl	$0x2, %esi
    30a6:      	callq	*%rax
    30a8:      	testq	%rax, %rax
    30ab:      	js	0x355c <generic_uprobe_process_event+0x32bc>
    30b1:      	movzbl	0x5(%r15), %eax
    30b6:      	cmpl	$0x32, %eax
    30b9:      	jg	0x30d6 <generic_uprobe_process_event+0x2e36>
    30bb:      	testl	%eax, %eax
    30bd:      	je	0x30f4 <generic_uprobe_process_event+0x2e54>
    30bf:      	cmpl	$0x2b, %eax
    30c2:      	je	0x30f4 <generic_uprobe_process_event+0x2e54>
    30c4:      	cmpl	$0x2c, %eax
    30c7:      	jne	0x3124 <generic_uprobe_process_event+0x2e84>
    30c9:      	movw	$0x8, 0x2(%r15)
    30d0:      	movw	$0x8, %ax
    30d4:      	jmp	0x3129 <generic_uprobe_process_event+0x2e89>
    30d6:      	cmpl	$0x33, %eax
    30d9:      	je	0x3111 <generic_uprobe_process_event+0x2e71>
    30db:      	cmpl	$0x3c, %eax
    30de:      	je	0x30f4 <generic_uprobe_process_event+0x2e54>
    30e0:      	cmpl	$0xff, %eax
    30e5:      	jne	0x3124 <generic_uprobe_process_event+0x2e84>
    30e7:      	movw	$0x28, 0x2(%r15)
    30ee:      	movw	$0x28, %ax
    30f2:      	jmp	0x3129 <generic_uprobe_process_event+0x2e89>
    30f4:      	movzbl	0x7(%r15), %eax
    30f9:      	leal	0x8(,%rax,8), %eax
    3100:      	movw	%ax, 0x2(%r15)
    3105:      	jmp	0x3129 <generic_uprobe_process_event+0x2e89>
    3107:      	movzwl	0x2(%r15), %eax
    310c:      	jmp	0x3058 <generic_uprobe_process_event+0x2db8>
    3111:      	movzbl	0x7(%r15), %eax
    3116:      	leal	0x8(,%rax,4), %eax
    311d:      	movw	%ax, 0x2(%r15)
    3122:      	jmp	0x3129 <generic_uprobe_process_event+0x2e89>
    3124:      	movzwl	0x2(%r15), %eax
    3129:      	addw	(%r15), %ax
    312d:      	movw	%ax, (%r15)
    3131:      	movzbl	0x6(%r15), %ebp
    3136:      	cmpq	$0x3c, %rbp
    313a:      	ja	0x3737 <generic_uprobe_process_event+0x3497>
    3140:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    314a:      	btq	%rbp, %rcx
    314e:      	jae	0x3737 <generic_uprobe_process_event+0x3497>
    3154:      	movb	%bpl, 0x5(%r15)
    3158:      	movzwl	%ax, %ecx
    315b:      	addq	%rbx, %rcx
    315e:      	movl	$0x2, %edx
    3163:      	movl	$0x4, %eax
    3168:      	movzwl	(%r15), %edx
    316c:      	addq	%rbx, %rdx
    316f:      	movq	%r14, %rdi
    3172:      	movl	$0x2, %esi
    3177:      	callq	*%rax
    3179:      	testq	%rax, %rax
    317c:      	js	0x355c <generic_uprobe_process_event+0x32bc>
    3182:      	movzbl	0x5(%r15), %eax
    3187:      	cmpl	$0x32, %eax
    318a:      	jg	0x31a7 <generic_uprobe_process_event+0x2f07>
    318c:      	testl	%eax, %eax
    318e:      	je	0x31c5 <generic_uprobe_process_event+0x2f25>
    3190:      	cmpl	$0x2b, %eax
    3193:      	je	0x31c5 <generic_uprobe_process_event+0x2f25>
    3195:      	cmpl	$0x2c, %eax
    3198:      	jne	0x31eb <generic_uprobe_process_event+0x2f4b>
    319a:      	movw	$0x8, 0x2(%r15)
    31a1:      	movw	$0x8, %ax
    31a5:      	jmp	0x31f0 <generic_uprobe_process_event+0x2f50>
    31a7:      	cmpl	$0x33, %eax
    31aa:      	je	0x31d8 <generic_uprobe_process_event+0x2f38>
    31ac:      	cmpl	$0x3c, %eax
    31af:      	je	0x31c5 <generic_uprobe_process_event+0x2f25>
    31b1:      	cmpl	$0xff, %eax
    31b6:      	jne	0x31eb <generic_uprobe_process_event+0x2f4b>
    31b8:      	movw	$0x28, 0x2(%r15)
    31bf:      	movw	$0x28, %ax
    31c3:      	jmp	0x31f0 <generic_uprobe_process_event+0x2f50>
    31c5:      	movzbl	0x7(%r15), %eax
    31ca:      	leal	0x8(,%rax,8), %eax
    31d1:      	movw	%ax, 0x2(%r15)
    31d6:      	jmp	0x31f0 <generic_uprobe_process_event+0x2f50>
    31d8:      	movzbl	0x7(%r15), %eax
    31dd:      	leal	0x8(,%rax,4), %eax
    31e4:      	movw	%ax, 0x2(%r15)
    31e9:      	jmp	0x31f0 <generic_uprobe_process_event+0x2f50>
    31eb:      	movzwl	0x2(%r15), %eax
    31f0:      	addw	(%r15), %ax
    31f4:      	movw	%ax, (%r15)
    31f8:      	movzbl	0x6(%r15), %ebp
    31fd:      	cmpq	$0x3c, %rbp
    3201:      	ja	0x3737 <generic_uprobe_process_event+0x3497>
    3207:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3211:      	btq	%rbp, %rcx
    3215:      	jae	0x3737 <generic_uprobe_process_event+0x3497>
    321b:      	movb	%bpl, 0x5(%r15)
    321f:      	movzwl	%ax, %ecx
    3222:      	addq	%rbx, %rcx
    3225:      	movl	$0x2, %edx
    322a:      	movl	$0x4, %eax
    322f:      	movzwl	(%r15), %edx
    3233:      	addq	%rbx, %rdx
    3236:      	movq	%r14, %rdi
    3239:      	movl	$0x2, %esi
    323e:      	callq	*%rax
    3240:      	testq	%rax, %rax
    3243:      	js	0x355c <generic_uprobe_process_event+0x32bc>
    3249:      	movzbl	0x5(%r15), %eax
    324e:      	cmpl	$0x32, %eax
    3251:      	jg	0x326e <generic_uprobe_process_event+0x2fce>
    3253:      	testl	%eax, %eax
    3255:      	je	0x328c <generic_uprobe_process_event+0x2fec>
    3257:      	cmpl	$0x2b, %eax
    325a:      	je	0x328c <generic_uprobe_process_event+0x2fec>
    325c:      	cmpl	$0x2c, %eax
    325f:      	jne	0x32b2 <generic_uprobe_process_event+0x3012>
    3261:      	movw	$0x8, 0x2(%r15)
    3268:      	movw	$0x8, %ax
    326c:      	jmp	0x32b7 <generic_uprobe_process_event+0x3017>
    326e:      	cmpl	$0x33, %eax
    3271:      	je	0x329f <generic_uprobe_process_event+0x2fff>
    3273:      	cmpl	$0x3c, %eax
    3276:      	je	0x328c <generic_uprobe_process_event+0x2fec>
    3278:      	cmpl	$0xff, %eax
    327d:      	jne	0x32b2 <generic_uprobe_process_event+0x3012>
    327f:      	movw	$0x28, 0x2(%r15)
    3286:      	movw	$0x28, %ax
    328a:      	jmp	0x32b7 <generic_uprobe_process_event+0x3017>
    328c:      	movzbl	0x7(%r15), %eax
    3291:      	leal	0x8(,%rax,8), %eax
    3298:      	movw	%ax, 0x2(%r15)
    329d:      	jmp	0x32b7 <generic_uprobe_process_event+0x3017>
    329f:      	movzbl	0x7(%r15), %eax
    32a4:      	leal	0x8(,%rax,4), %eax
    32ab:      	movw	%ax, 0x2(%r15)
    32b0:      	jmp	0x32b7 <generic_uprobe_process_event+0x3017>
    32b2:      	movzwl	0x2(%r15), %eax
    32b7:      	addw	(%r15), %ax
    32bb:      	movw	%ax, (%r15)
    32bf:      	movzbl	0x6(%r15), %ebp
    32c4:      	cmpq	$0x3c, %rbp
    32c8:      	ja	0x3737 <generic_uprobe_process_event+0x3497>
    32ce:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    32d8:      	btq	%rbp, %rcx
    32dc:      	jae	0x3737 <generic_uprobe_process_event+0x3497>
    32e2:      	movb	%bpl, 0x5(%r15)
    32e6:      	movzwl	%ax, %ecx
    32e9:      	addq	%rbx, %rcx
    32ec:      	movl	$0x2, %edx
    32f1:      	movl	$0x4, %eax
    32f6:      	movzwl	(%r15), %edx
    32fa:      	addq	%rbx, %rdx
    32fd:      	movq	%r14, %rdi
    3300:      	movl	$0x2, %esi
    3305:      	callq	*%rax
    3307:      	testq	%rax, %rax
    330a:      	js	0x355c <generic_uprobe_process_event+0x32bc>
    3310:      	movzbl	0x5(%r15), %eax
    3315:      	cmpl	$0x32, %eax
    3318:      	jg	0x3335 <generic_uprobe_process_event+0x3095>
    331a:      	testl	%eax, %eax
    331c:      	je	0x3353 <generic_uprobe_process_event+0x30b3>
    331e:      	cmpl	$0x2b, %eax
    3321:      	je	0x3353 <generic_uprobe_process_event+0x30b3>
    3323:      	cmpl	$0x2c, %eax
    3326:      	jne	0x3379 <generic_uprobe_process_event+0x30d9>
    3328:      	movw	$0x8, 0x2(%r15)
    332f:      	movw	$0x8, %ax
    3333:      	jmp	0x337e <generic_uprobe_process_event+0x30de>
    3335:      	cmpl	$0x33, %eax
    3338:      	je	0x3366 <generic_uprobe_process_event+0x30c6>
    333a:      	cmpl	$0x3c, %eax
    333d:      	je	0x3353 <generic_uprobe_process_event+0x30b3>
    333f:      	cmpl	$0xff, %eax
    3344:      	jne	0x3379 <generic_uprobe_process_event+0x30d9>
    3346:      	movw	$0x28, 0x2(%r15)
    334d:      	movw	$0x28, %ax
    3351:      	jmp	0x337e <generic_uprobe_process_event+0x30de>
    3353:      	movzbl	0x7(%r15), %eax
    3358:      	leal	0x8(,%rax,8), %eax
    335f:      	movw	%ax, 0x2(%r15)
    3364:      	jmp	0x337e <generic_uprobe_process_event+0x30de>
    3366:      	movzbl	0x7(%r15), %eax
    336b:      	leal	0x8(,%rax,4), %eax
    3372:      	movw	%ax, 0x2(%r15)
    3377:      	jmp	0x337e <generic_uprobe_process_event+0x30de>
    3379:      	movzwl	0x2(%r15), %eax
    337e:      	addw	(%r15), %ax
    3382:      	movw	%ax, (%r15)
    3386:      	movzbl	0x6(%r15), %ebp
    338b:      	cmpq	$0x3c, %rbp
    338f:      	ja	0x3737 <generic_uprobe_process_event+0x3497>
    3395:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    339f:      	btq	%rbp, %rcx
    33a3:      	jae	0x3737 <generic_uprobe_process_event+0x3497>
    33a9:      	movb	%bpl, 0x5(%r15)
    33ad:      	movzwl	%ax, %ecx
    33b0:      	addq	%rbx, %rcx
    33b3:      	movl	$0x2, %edx
    33b8:      	movl	$0x4, %eax
    33bd:      	movzwl	(%r15), %edx
    33c1:      	addq	%rbx, %rdx
    33c4:      	movq	%r14, %rdi
    33c7:      	movl	$0x2, %esi
    33cc:      	callq	*%rax
    33ce:      	testq	%rax, %rax
    33d1:      	js	0x355c <generic_uprobe_process_event+0x32bc>
    33d7:      	movzbl	0x5(%r15), %eax
    33dc:      	cmpl	$0x32, %eax
    33df:      	jg	0x33fc <generic_uprobe_process_event+0x315c>
    33e1:      	testl	%eax, %eax
    33e3:      	je	0x341a <generic_uprobe_process_event+0x317a>
    33e5:      	cmpl	$0x2b, %eax
    33e8:      	je	0x341a <generic_uprobe_process_event+0x317a>
    33ea:      	cmpl	$0x2c, %eax
    33ed:      	jne	0x3440 <generic_uprobe_process_event+0x31a0>
    33ef:      	movw	$0x8, 0x2(%r15)
    33f6:      	movw	$0x8, %ax
    33fa:      	jmp	0x3445 <generic_uprobe_process_event+0x31a5>
    33fc:      	cmpl	$0x33, %eax
    33ff:      	je	0x342d <generic_uprobe_process_event+0x318d>
    3401:      	cmpl	$0x3c, %eax
    3404:      	je	0x341a <generic_uprobe_process_event+0x317a>
    3406:      	cmpl	$0xff, %eax
    340b:      	jne	0x3440 <generic_uprobe_process_event+0x31a0>
    340d:      	movw	$0x28, 0x2(%r15)
    3414:      	movw	$0x28, %ax
    3418:      	jmp	0x3445 <generic_uprobe_process_event+0x31a5>
    341a:      	movzbl	0x7(%r15), %eax
    341f:      	leal	0x8(,%rax,8), %eax
    3426:      	movw	%ax, 0x2(%r15)
    342b:      	jmp	0x3445 <generic_uprobe_process_event+0x31a5>
    342d:      	movzbl	0x7(%r15), %eax
    3432:      	leal	0x8(,%rax,4), %eax
    3439:      	movw	%ax, 0x2(%r15)
    343e:      	jmp	0x3445 <generic_uprobe_process_event+0x31a5>
    3440:      	movzwl	0x2(%r15), %eax
    3445:      	addw	(%r15), %ax
    3449:      	movw	%ax, (%r15)
    344d:      	movzbl	0x6(%r15), %ebp
    3452:      	cmpq	$0x3c, %rbp
    3456:      	ja	0x3737 <generic_uprobe_process_event+0x3497>
    345c:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3466:      	btq	%rbp, %rcx
    346a:      	jae	0x3737 <generic_uprobe_process_event+0x3497>
    3470:      	movb	%bpl, 0x5(%r15)
    3474:      	movzwl	%ax, %ecx
    3477:      	addq	%rbx, %rcx
    347a:      	movl	$0x2, %edx
    347f:      	movl	$0x4, %eax
    3484:      	movzwl	(%r15), %edx
    3488:      	addq	%rbx, %rdx
    348b:      	movq	%r14, %rdi
    348e:      	movl	$0x2, %esi
    3493:      	callq	*%rax
    3495:      	testq	%rax, %rax
    3498:      	js	0x355c <generic_uprobe_process_event+0x32bc>
    349e:      	movzbl	0x5(%r15), %eax
    34a3:      	cmpl	$0x32, %eax
    34a6:      	jg	0x34c3 <generic_uprobe_process_event+0x3223>
    34a8:      	testl	%eax, %eax
    34aa:      	je	0x34e1 <generic_uprobe_process_event+0x3241>
    34ac:      	cmpl	$0x2b, %eax
    34af:      	je	0x34e1 <generic_uprobe_process_event+0x3241>
    34b1:      	cmpl	$0x2c, %eax
    34b4:      	jne	0x3507 <generic_uprobe_process_event+0x3267>
    34b6:      	movw	$0x8, 0x2(%r15)
    34bd:      	movw	$0x8, %ax
    34c1:      	jmp	0x350c <generic_uprobe_process_event+0x326c>
    34c3:      	cmpl	$0x33, %eax
    34c6:      	je	0x34f4 <generic_uprobe_process_event+0x3254>
    34c8:      	cmpl	$0x3c, %eax
    34cb:      	je	0x34e1 <generic_uprobe_process_event+0x3241>
    34cd:      	cmpl	$0xff, %eax
    34d2:      	jne	0x3507 <generic_uprobe_process_event+0x3267>
    34d4:      	movw	$0x28, 0x2(%r15)
    34db:      	movw	$0x28, %ax
    34df:      	jmp	0x350c <generic_uprobe_process_event+0x326c>
    34e1:      	movzbl	0x7(%r15), %eax
    34e6:      	leal	0x8(,%rax,8), %eax
    34ed:      	movw	%ax, 0x2(%r15)
    34f2:      	jmp	0x350c <generic_uprobe_process_event+0x326c>
    34f4:      	movzbl	0x7(%r15), %eax
    34f9:      	leal	0x8(,%rax,4), %eax
    3500:      	movw	%ax, 0x2(%r15)
    3505:      	jmp	0x350c <generic_uprobe_process_event+0x326c>
    3507:      	movzwl	0x2(%r15), %eax
    350c:      	addw	(%r15), %ax
    3510:      	movw	%ax, (%r15)
    3514:      	movzbl	0x6(%r15), %ebp
    3519:      	cmpq	$0x3c, %rbp
    351d:      	ja	0x3737 <generic_uprobe_process_event+0x3497>
    3523:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    352d:      	btq	%rbp, %rcx
    3531:      	jae	0x3737 <generic_uprobe_process_event+0x3497>
    3537:      	movb	%bpl, 0x5(%r15)
    353b:      	movzwl	%ax, %ecx
    353e:      	addq	%rbx, %rcx
    3541:      	movl	$0x2, %edx
    3546:      	movl	$0x4, %eax
    354b:      	movzwl	(%r15), %edx
    354f:      	addq	%rbx, %rdx
    3552:      	movq	%r14, %rdi
    3555:      	movl	$0x2, %esi
    355a:      	callq	*%rax
    355c:      	xorl	%ebp, %ebp
    355e:      	movb	%bpl, 0xbc(%rsp)
    3566:      	movzbl	%bpl, %eax
    356a:      	movq	0x10(%rsp), %rbx
    356f:      	movw	%ax, 0x24(%rbx)
    3573:      	movw	$0xa, 0x26(%rbx)
    3579:      	leaq	0x8(%r13), %rdx
    357d:      	movl	$0x10, %ecx
    3582:      	movl	$0x4, %eax
    3587:      	movq	%rbx, %rdi
    358a:      	movl	$0x10, %esi
    358f:      	callq	*%rax
    3591:      	leaq	0x10(%rbx), %rdi
    3595:      	addq	$0x18, %r13
    3599:      	movl	$0x10, %ecx
    359e:      	movl	$0x4, %eax
    35a3:      	movl	$0x10, %esi
    35a8:      	movq	%r13, %rdx
    35ab:      	callq	*%rax
    35ad:      	cmpb	$0x11, %bpl
    35b1:      	je	0x3604 <generic_uprobe_process_event+0x3364>
    35b3:      	movzbl	%bpl, %eax
    35b7:      	cmpl	$0x6, %eax
    35ba:      	jne	0x364f <generic_uprobe_process_event+0x33af>
    35c0:      	movq	0x58(%rsp), %rbx
    35c5:      	movzwl	0xe0(%rsp), %r15d
    35ce:      	leaq	(%rbx,%r15), %rdx
    35d2:      	movq	0x10(%rsp), %r14
    35d7:      	leaq	0x20(%r14), %rdi
    35db:      	movl	$0x2, %ecx
    35e0:      	movl	$0x4, %eax
    35e5:      	movl	$0x2, %esi
    35ea:      	callq	*%rax
    35ec:      	leaq	0x22(%r14), %rdi
    35f0:      	leaq	(%rbx,%r15), %rdx
    35f4:      	addq	$0x2, %rdx
    35f8:      	movl	$0x2, %ecx
    35fd:      	movl	$0x4, %eax
    3602:      	jmp	0x3646 <generic_uprobe_process_event+0x33a6>
    3604:      	movq	0x58(%rsp), %rbx
    3609:      	movzwl	0xe0(%rsp), %r15d
    3612:      	leaq	(%rbx,%r15), %rdx
    3616:      	movq	0x10(%rsp), %r14
    361b:      	leaq	0x20(%r14), %rdi
    361f:      	movl	$0x2, %ecx
    3624:      	movl	$0x4, %eax
    3629:      	movl	$0x2, %esi
    362e:      	callq	*%rax
    3630:      	leaq	0x22(%r14), %rdi
    3634:      	leaq	(%rbx,%r15), %rdx
    3638:      	addq	$0x2, %rdx
    363c:      	movl	$0x2, %ecx
    3641:      	movl	$0x4, %eax
    3646:      	movl	$0x2, %esi
    364b:      	callq	*%rax
    364d:      	jmp	0x365b <generic_uprobe_process_event+0x33bb>
    364f:      	movq	0x10(%rsp), %rax
    3654:      	movl	$0x0, 0x20(%rax)
    365b:      	movq	0x10(%rsp), %rdx
    3660:      	movzwl	0x20(%rdx), %eax
    3664:      	movzwl	0x22(%rdx), %ecx
    3668:      	movbew	%ax, 0x20(%rdx)
    366e:      	movbew	%cx, 0x22(%rdx)
    3674:      	addq	$0xe0, %r12
    367b:      	leaq	0x98(%rsp), %rdi
    3683:      	movl	$0x8, %ecx
    3688:      	movl	$0x4, %eax
    368d:      	movl	$0x4, %r15d
    3693:      	movl	$0x8, %esi
    3698:      	movq	%r12, %rdx
    369b:      	callq	*%rax
    369d:      	movq	0x98(%rsp), %rcx
    36a5:      	testq	%rcx, %rcx
    36a8:      	je	0x3715 <generic_uprobe_process_event+0x3475>
    36aa:      	addq	$0x5, %rcx
    36ae:      	leaq	0x40(%rsp), %rdi
    36b3:      	movl	$0x8, %edx
    36b8:      	movl	$0x4, %eax
    36bd:      	movq	0x98(%rsp), %rdx
    36c5:      	addq	$0x5, %rdx
    36c9:      	movl	$0x8, %esi
    36ce:      	callq	*%rax
    36d0:      	movq	0x98(%rsp), %rbx
    36d8:      	movq	0x40(%rsp), %r12
    36dd:      	movq	0x10(%rsp), %r14
    36e2:      	leaq	0x38(%r14), %rdi
    36e6:      	leaq	(%rbx,%r12,8), %rdx
    36ea:      	addq	$0x44, %rdx
    36ee:      	movl	$0x4, %eax
    36f3:      	movl	$0x4, %esi
    36f8:      	callq	*%rax
    36fa:      	addq	$0x3c, %r14
    36fe:      	leaq	(%rbx,%r12,8), %rdx
    3702:      	addq	$0x45, %rdx
    3706:      	movl	$0x4, %eax
    370b:      	movq	%r14, %rdi
    370e:      	movl	$0x4, %esi
    3713:      	callq	*%rax
    3715:      	movl	$0x40, %r15d
    371b:      	movq	0x8(%rsp), %rcx
    3720:      	movq	0xf0(%rsp), %r14
    3728:      	movq	0x28(%rsp), %rbx
    372d:      	movq	0x18(%rsp), %rbp
    3732:      	jmp	0x1630 <generic_uprobe_process_event+0x1390>
    3737:      	movw	%ax, 0xe0(%rsp)
    373f:      	jmp	0x355e <generic_uprobe_process_event+0x32be>
    3744:      	nopw	%cs:(%rax,%rax)

0000000000003750 <generic_uprobe_process_filter>:
    3750:      	pushq	%rbp
    3751:      	pushq	%r15
    3753:      	pushq	%r14
    3755:      	pushq	%r13
    3757:      	pushq	%r12
    3759:      	pushq	%rbx
    375a:      	subq	$0xe8, %rsp
    3761:      	movq	%rdi, %rbx
    3764:      	movl	$0x0, 0xc8(%rsp)
    376f:      	movq	(%rip), %rdi            # 0x3776 <generic_uprobe_process_filter+0x26>
    3776:      	leaq	0xc8(%rsp), %rsi
    377e:      	movl	$0x1, %eax
    3783:      	callq	*%rax
    3785:      	testq	%rax, %rax
    3788:      	je	0x5d73 <generic_uprobe_process_filter+0x2623>
    378e:      	movq	%rax, %r14
    3791:      	movl	$0x23, %eax
    3796:      	callq	*%rax
    3798:      	movq	%rax, %rcx
    379b:      	movq	%rax, 0x60(%rsp)
    37a0:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    37a7:      	leaq	0x10(%rsp), %rdi
    37ac:      	movl	$0x4, %edx
    37b1:      	movl	$0x71, %eax
    37b6:      	movl	$0xaf4, %edx            # imm = 0xAF4
    37bb:      	addq	0x60(%rsp), %rdx
    37c0:      	movl	$0x4, %esi
    37c5:      	callq	*%rax
    37c7:      	movl	0x10(%rsp), %eax
    37cb:      	movl	%eax, 0x40(%rsp)
    37cf:      	movq	(%rip), %rdi            # 0x37d6 <generic_uprobe_process_filter+0x86>
    37d6:      	leaq	0x40(%rsp), %rsi
    37db:      	movl	$0x1, %eax
    37e0:      	callq	*%rax
    37e2:      	testq	%rax, %rax
    37e5:      	movq	%r14, 0x50(%rsp)
    37ea:      	je	0x37fa <generic_uprobe_process_filter+0xaa>
    37ec:      	movq	%rax, %r15
    37ef:      	cmpq	$0x0, 0x8(%rax)
    37f4:      	jne	0x477f <generic_uprobe_process_filter+0x102f>
    37fa:      	movl	$0xb00, %edx            # imm = 0xB00
    37ff:      	movq	0x60(%rsp), %rcx
    3804:      	addq	%rdx, %rcx
    3807:      	leaq	0x60(%rsp), %rdi
    380c:      	movl	$0x8, %esi
    3811:      	movl	$0x71, %eax
    3816:      	addq	0x60(%rsp), %rdx
    381b:      	movl	$0x8, %esi
    3820:      	callq	*%rax
    3822:      	movq	0x60(%rsp), %rcx
    3827:      	testq	%rcx, %rcx
    382a:      	je	0x39bf <generic_uprobe_process_filter+0x26f>
    3830:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3837:      	leaq	0x10(%rsp), %rdi
    383c:      	movl	$0x4, %edx
    3841:      	movl	$0x71, %eax
    3846:      	movl	$0xaf4, %edx            # imm = 0xAF4
    384b:      	addq	0x60(%rsp), %rdx
    3850:      	movl	$0x4, %esi
    3855:      	callq	*%rax
    3857:      	movl	0x10(%rsp), %eax
    385b:      	movl	%eax, 0x40(%rsp)
    385f:      	movq	(%rip), %rdi            # 0x3866 <generic_uprobe_process_filter+0x116>
    3866:      	leaq	0x40(%rsp), %rsi
    386b:      	movl	$0x1, %eax
    3870:      	callq	*%rax
    3872:      	testq	%rax, %rax
    3875:      	je	0x3885 <generic_uprobe_process_filter+0x135>
    3877:      	movq	%rax, %r15
    387a:      	cmpq	$0x0, 0x8(%rax)
    387f:      	jne	0x477f <generic_uprobe_process_filter+0x102f>
    3885:      	movl	$0xb00, %edx            # imm = 0xB00
    388a:      	movq	0x60(%rsp), %rcx
    388f:      	addq	%rdx, %rcx
    3892:      	leaq	0x60(%rsp), %rdi
    3897:      	movl	$0x8, %esi
    389c:      	movl	$0x71, %eax
    38a1:      	addq	0x60(%rsp), %rdx
    38a6:      	movl	$0x8, %esi
    38ab:      	callq	*%rax
    38ad:      	movq	0x60(%rsp), %rcx
    38b2:      	testq	%rcx, %rcx
    38b5:      	je	0x39bf <generic_uprobe_process_filter+0x26f>
    38bb:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    38c2:      	leaq	0x10(%rsp), %rdi
    38c7:      	movl	$0x4, %edx
    38cc:      	movl	$0x71, %eax
    38d1:      	movl	$0xaf4, %edx            # imm = 0xAF4
    38d6:      	addq	0x60(%rsp), %rdx
    38db:      	movl	$0x4, %esi
    38e0:      	callq	*%rax
    38e2:      	movl	0x10(%rsp), %eax
    38e6:      	movl	%eax, 0x40(%rsp)
    38ea:      	movq	(%rip), %rdi            # 0x38f1 <generic_uprobe_process_filter+0x1a1>
    38f1:      	leaq	0x40(%rsp), %rsi
    38f6:      	movl	$0x1, %eax
    38fb:      	callq	*%rax
    38fd:      	testq	%rax, %rax
    3900:      	je	0x3910 <generic_uprobe_process_filter+0x1c0>
    3902:      	movq	%rax, %r15
    3905:      	cmpq	$0x0, 0x8(%rax)
    390a:      	jne	0x477f <generic_uprobe_process_filter+0x102f>
    3910:      	movl	$0xb00, %edx            # imm = 0xB00
    3915:      	movq	0x60(%rsp), %rcx
    391a:      	addq	%rdx, %rcx
    391d:      	leaq	0x60(%rsp), %rdi
    3922:      	movl	$0x8, %esi
    3927:      	movl	$0x71, %eax
    392c:      	addq	0x60(%rsp), %rdx
    3931:      	movl	$0x8, %esi
    3936:      	callq	*%rax
    3938:      	movq	0x60(%rsp), %rcx
    393d:      	testq	%rcx, %rcx
    3940:      	je	0x39bf <generic_uprobe_process_filter+0x26f>
    3942:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3949:      	leaq	0x10(%rsp), %rdi
    394e:      	movl	$0x4, %edx
    3953:      	movl	$0x71, %eax
    3958:      	movl	$0xaf4, %edx            # imm = 0xAF4
    395d:      	addq	0x60(%rsp), %rdx
    3962:      	movl	$0x4, %esi
    3967:      	callq	*%rax
    3969:      	movl	0x10(%rsp), %eax
    396d:      	movl	%eax, 0x40(%rsp)
    3971:      	movq	(%rip), %rdi            # 0x3978 <generic_uprobe_process_filter+0x228>
    3978:      	leaq	0x40(%rsp), %rsi
    397d:      	movl	$0x1, %eax
    3982:      	callq	*%rax
    3984:      	testq	%rax, %rax
    3987:      	je	0x3997 <generic_uprobe_process_filter+0x247>
    3989:      	movq	%rax, %r15
    398c:      	cmpq	$0x0, 0x8(%rax)
    3991:      	jne	0x477f <generic_uprobe_process_filter+0x102f>
    3997:      	movl	$0xb00, %edx            # imm = 0xB00
    399c:      	movq	0x60(%rsp), %rcx
    39a1:      	addq	%rdx, %rcx
    39a4:      	leaq	0x60(%rsp), %rdi
    39a9:      	movl	$0x8, %esi
    39ae:      	movl	$0x71, %eax
    39b3:      	addq	0x60(%rsp), %rdx
    39b8:      	movl	$0x8, %esi
    39bd:      	callq	*%rax
    39bf:      	movq	%rbx, 0xb8(%rsp)
    39c7:      	movl	$0x23, %eax
    39cc:      	callq	*%rax
    39ce:      	movq	%rax, %r13
    39d1:      	leaq	0xaf4(%rax), %rdx
    39d8:      	leaq	0x60(%rsp), %rdi
    39dd:      	movl	$0x4, %ecx
    39e2:      	movl	$0x4, %eax
    39e7:      	movl	$0x4, %ebp
    39ec:      	movl	$0x4, %esi
    39f1:      	callq	*%rax
    39f3:      	movl	0x60(%rsp), %eax
    39f7:      	movl	%eax, 0x5f10(%r14)
    39fe:      	movl	$0x7d, %eax
    3a03:      	callq	*%rax
    3a05:      	movq	%rax, 0x5f18(%r14)
    3a0c:      	movl	$0x0, 0x5f20(%r14)
    3a17:      	movq	$0x0, 0x5f28(%r14)
    3a22:      	movl	$0x0, 0x5f30(%r14)
    3a2d:      	leaq	0x60(%r13), %rdx
    3a31:      	leaq	0x40(%rsp), %rdi
    3a36:      	movl	$0x8, %ecx
    3a3b:      	movl	$0x71, %eax
    3a40:      	movl	$0x8, %esi
    3a45:      	callq	*%rax
    3a47:      	movq	0x40(%rsp), %rcx
    3a4c:      	xorl	%ebx, %ebx
    3a4e:      	testq	%rcx, %rcx
    3a51:      	je	0x3ac0 <generic_uprobe_process_filter+0x370>
    3a53:      	addq	$0x4, %rcx
    3a57:      	leaq	0x10(%rsp), %rdi
    3a5c:      	movl	$0x4, %edx
    3a61:      	movl	$0x71, %eax
    3a66:      	movq	0x40(%rsp), %rdx
    3a6b:      	addq	$0x4, %rdx
    3a6f:      	movl	$0x4, %esi
    3a74:      	callq	*%rax
    3a76:      	movl	0x10(%rsp), %eax
    3a7a:      	testl	%eax, %eax
    3a7c:      	je	0x3ac0 <generic_uprobe_process_filter+0x370>
    3a7e:      	movq	0x40(%rsp), %rcx
    3a83:      	shll	$0x4, %eax
    3a86:      	addq	%rax, %rcx
    3a89:      	addq	$0x80, %rcx
    3a90:      	leaq	0x60(%rsp), %rdi
    3a95:      	movl	$0x10, %edx
    3a9a:      	movl	$0x71, %eax
    3a9f:      	movq	0x40(%rsp), %rcx
    3aa4:      	movl	0x10(%rsp), %edx
    3aa8:      	shll	$0x4, %edx
    3aab:      	addq	%rcx, %rdx
    3aae:      	addq	$0x80, %rdx
    3ab5:      	movl	$0x10, %esi
    3aba:      	callq	*%rax
    3abc:      	movl	0x60(%rsp), %ebx
    3ac0:      	movl	%ebx, 0x5f34(%r14)
    3ac7:      	leaq	0xd00(%r13), %r15
    3ace:      	leaq	0x60(%rsp), %rdi
    3ad3:      	movl	$0x8, %ecx
    3ad8:      	movl	$0x4, %eax
    3add:      	leaq	0x5f60(%r14), %rbx
    3ae4:      	movl	$0x8, %esi
    3ae9:      	movq	%r15, %rdx
    3aec:      	callq	*%rax
    3aee:      	movq	0x60(%rsp), %r12
    3af3:      	leaq	0x5f68(%r14), %rdi
    3afa:      	leaq	0x40(%r12), %rdx
    3aff:      	movl	$0x8, %ecx
    3b04:      	movl	$0x4, %eax
    3b09:      	movl	$0x8, %esi
    3b0e:      	callq	*%rax
    3b10:      	leaq	0x5f70(%r14), %rdi
    3b17:      	leaq	0x30(%r12), %rdx
    3b1c:      	movl	$0x8, %ecx
    3b21:      	movl	$0x4, %eax
    3b26:      	movl	$0x8, %esi
    3b2b:      	callq	*%rax
    3b2d:      	addq	$0x38, %r12
    3b31:      	movl	$0x8, %ecx
    3b36:      	movl	$0x4, %eax
    3b3b:      	movq	%rbx, %rdi
    3b3e:      	movl	$0x8, %esi
    3b43:      	movq	%r12, %rdx
    3b46:      	callq	*%rax
    3b48:      	leaq	0x5f38(%r14), %rbx
    3b4f:      	leaq	0xd70(%r13), %rdx
    3b56:      	leaq	0x10(%rsp), %rdi
    3b5b:      	movl	$0x8, %ecx
    3b60:      	movl	$0x4, %eax
    3b65:      	movl	$0x8, %esi
    3b6a:      	callq	*%rax
    3b6c:      	movq	0x10(%rsp), %rcx
    3b71:      	leaq	0x60(%rsp), %rdi
    3b76:      	movl	$0x48, %edx
    3b7b:      	movl	$0x4, %eax
    3b80:      	movq	0x10(%rsp), %rdx
    3b85:      	movl	$0x48, %esi
    3b8a:      	callq	*%rax
    3b8c:      	movl	$0x218, %edx            # imm = 0x218
    3b91:      	movq	0x68(%rsp), %rcx
    3b96:      	addq	%rdx, %rcx
    3b99:      	movl	$0x4, %eax
    3b9e:      	addq	0x68(%rsp), %rdx
    3ba3:      	movq	%rbx, %rdi
    3ba6:      	movl	$0x4, %esi
    3bab:      	callq	*%rax
    3bad:      	leaq	0x5f3c(%r14), %rdi
    3bb4:      	movl	$0x4d8, %edx            # imm = 0x4D8
    3bb9:      	movq	0x70(%rsp), %rcx
    3bbe:      	addq	%rdx, %rcx
    3bc1:      	movl	$0x4, %eax
    3bc6:      	addq	0x70(%rsp), %rdx
    3bcb:      	movl	$0x4, %esi
    3bd0:      	callq	*%rax
    3bd2:      	leaq	0x5f40(%r14), %rdi
    3bd9:      	movq	0x78(%rsp), %rcx
    3bde:      	addq	$0x58, %rcx
    3be2:      	movl	$0x4, %eax
    3be7:      	movq	0x78(%rsp), %rdx
    3bec:      	addq	$0x58, %rdx
    3bf0:      	movl	$0x4, %esi
    3bf5:      	callq	*%rax
    3bf7:      	movq	$0x0, 0x58(%rsp)
    3c00:      	leaq	0xb58(%r13), %rdx
    3c07:      	leaq	0x58(%rsp), %rdi
    3c0c:      	movl	$0x8, %ecx
    3c11:      	movl	$0x4, %eax
    3c16:      	movl	$0x8, %esi
    3c1b:      	callq	*%rax
    3c1d:      	movq	0x58(%rsp), %rcx
    3c22:      	testq	%rcx, %rcx
    3c25:      	je	0x3cd4 <generic_uprobe_process_filter+0x584>
    3c2b:      	movl	$0x0, 0xa8(%rsp)
    3c36:      	addq	$0x4, %rcx
    3c3a:      	leaq	0xa8(%rsp), %rdi
    3c42:      	movl	$0x4, %edx
    3c47:      	movl	$0x4, %eax
    3c4c:      	movq	0x58(%rsp), %rdx
    3c51:      	addq	$0x4, %rdx
    3c55:      	movl	$0x4, %esi
    3c5a:      	callq	*%rax
    3c5c:      	movq	0x58(%rsp), %rax
    3c61:      	movslq	0xa8(%rsp), %rcx
    3c69:      	shlq	$0x4, %rcx
    3c6d:      	addq	%rax, %rcx
    3c70:      	addq	$0x80, %rcx
    3c77:      	leaq	0x40(%rsp), %rdi
    3c7c:      	movl	$0x10, %edx
    3c81:      	movl	$0x4, %eax
    3c86:      	movq	0x58(%rsp), %rcx
    3c8b:      	movslq	0xa8(%rsp), %rdx
    3c93:      	shlq	$0x4, %rdx
    3c97:      	addq	%rcx, %rdx
    3c9a:      	addq	$0x80, %rdx
    3ca1:      	movl	$0x10, %esi
    3ca6:      	callq	*%rax
    3ca8:      	leaq	0x5f44(%r14), %rdi
    3caf:      	movl	$0x158, %edx            # imm = 0x158
    3cb4:      	movq	0x48(%rsp), %rcx
    3cb9:      	addq	%rdx, %rcx
    3cbc:      	movl	$0x4, %esi
    3cc1:      	movl	$0x4, %eax
    3cc6:      	addq	0x48(%rsp), %rdx
    3ccb:      	movl	$0x4, %esi
    3cd0:      	callq	*%rax
    3cd2:      	jmp	0x3cdf <generic_uprobe_process_filter+0x58f>
    3cd4:      	movl	$0x0, 0x5f44(%r14)
    3cdf:      	leaq	0x5f48(%r14), %rdi
    3ce6:      	movl	$0x158, %ebx            # imm = 0x158
    3ceb:      	movq	0x80(%rsp), %rcx
    3cf3:      	addq	%rbx, %rcx
    3cf6:      	movl	$0x4, %edx
    3cfb:      	movl	$0x4, %eax
    3d00:      	movq	0x80(%rsp), %rdx
    3d08:      	addq	%rbx, %rdx
    3d0b:      	movl	$0x4, %esi
    3d10:      	callq	*%rax
    3d12:      	leaq	0x5f4c(%r14), %rdi
    3d19:      	movl	$0x118, %edx            # imm = 0x118
    3d1e:      	movq	0x88(%rsp), %rcx
    3d26:      	addq	%rdx, %rcx
    3d29:      	movl	$0x4, %esi
    3d2e:      	movl	$0x4, %eax
    3d33:      	addq	0x88(%rsp), %rdx
    3d3b:      	movl	$0x4, %esi
    3d40:      	callq	*%rax
    3d42:      	leaq	0x5f50(%r14), %rdi
    3d49:      	movl	$0x98, %r12d
    3d4f:      	movq	0x90(%rsp), %rcx
    3d57:      	addq	%r12, %rcx
    3d5a:      	movl	$0x4, %edx
    3d5f:      	movl	$0x4, %eax
    3d64:      	movq	0x90(%rsp), %rdx
    3d6c:      	addq	%r12, %rdx
    3d6f:      	movl	$0x4, %esi
    3d74:      	callq	*%rax
    3d76:      	leaq	0x5f54(%r14), %rdi
    3d7d:      	movq	0x98(%rsp), %rcx
    3d85:      	addq	%r12, %rcx
    3d88:      	movl	$0x4, %edx
    3d8d:      	movl	$0x4, %eax
    3d92:      	addq	0x98(%rsp), %r12
    3d9a:      	movl	$0x4, %esi
    3d9f:      	movq	%r12, %rdx
    3da2:      	callq	*%rax
    3da4:      	leaq	0x5f58(%r14), %rdi
    3dab:      	movq	0xa0(%rsp), %rcx
    3db3:      	addq	$0x58, %rcx
    3db7:      	movl	$0x4, %edx
    3dbc:      	movl	$0x4, %eax
    3dc1:      	movq	0xa0(%rsp), %rdx
    3dc9:      	addq	$0x58, %rdx
    3dcd:      	movl	$0x4, %esi
    3dd2:      	callq	*%rax
    3dd4:      	movq	$0x0, 0x40(%rsp)
    3ddd:      	movq	$0x0, 0x58(%rsp)
    3de6:      	leaq	0x40(%rsp), %rdi
    3deb:      	movl	$0x8, %ecx
    3df0:      	movl	$0x4, %eax
    3df5:      	movl	$0x8, %esi
    3dfa:      	movq	%r15, %rdx
    3dfd:      	callq	*%rax
    3dff:      	movl	$0x90, %edx
    3e04:      	movq	0x40(%rsp), %rcx
    3e09:      	addq	%rdx, %rcx
    3e0c:      	leaq	0x58(%rsp), %rdi
    3e11:      	movl	$0x8, %esi
    3e16:      	movl	$0x4, %eax
    3e1b:      	addq	0x40(%rsp), %rdx
    3e20:      	movl	$0x8, %esi
    3e25:      	callq	*%rax
    3e27:      	leaq	0x5f5c(%r14), %rdi
    3e2e:      	movq	0x58(%rsp), %rcx
    3e33:      	addq	%rbx, %rcx
    3e36:      	movl	$0x4, %edx
    3e3b:      	movl	$0x4, %eax
    3e40:      	addq	0x58(%rsp), %rbx
    3e45:      	movl	$0x4, %esi
    3e4a:      	movq	%rbx, %rdx
    3e4d:      	callq	*%rax
    3e4f:      	cmpl	$0x1, 0x5f34(%r14)
    3e57:      	jne	0x3e61 <generic_uprobe_process_filter+0x711>
    3e59:      	orb	$0x2, 0x5f33(%r14)
    3e61:      	leaq	0x5f78(%r14), %rdi
    3e68:      	movl	$0x308, %edx            # imm = 0x308
    3e6d:      	movq	%rdi, 0x8(%rsp)
    3e72:      	xorl	%esi, %esi
    3e74:      	callq	0x3e79 <generic_uprobe_process_filter+0x729>
    3e79:      	leaq	0x6290(%r14), %rbp
    3e80:      	addq	$0xa78, %r13            # imm = 0xA78
    3e87:      	leaq	0x40(%rsp), %rdi
    3e8c:      	movl	$0x8, %ecx
    3e91:      	movl	$0x4, %eax
    3e96:      	movl	$0x8, %esi
    3e9b:      	movq	%r13, %rdx
    3e9e:      	callq	*%rax
    3ea0:      	movl	$0x5f8, %edx            # imm = 0x5F8
    3ea5:      	movq	0x40(%rsp), %rcx
    3eaa:      	addq	%rdx, %rcx
    3ead:      	leaq	0x60(%rsp), %rdi
    3eb2:      	movl	$0x8, %esi
    3eb7:      	movl	$0x4, %eax
    3ebc:      	addq	0x40(%rsp), %rdx
    3ec1:      	movl	$0x8, %esi
    3ec6:      	callq	*%rax
    3ec8:      	movq	0x60(%rsp), %rbx
    3ecd:      	movl	$0x0, 0xcc(%rsp)
    3ed8:      	movq	(%rip), %rdi            # 0x3edf <generic_uprobe_process_filter+0x78f>
    3edf:      	leaq	0xcc(%rsp), %rsi
    3ee7:      	movl	$0x1, %eax
    3eec:      	callq	*%rax
    3eee:      	testq	%rax, %rax
    3ef1:      	je	0x45f7 <generic_uprobe_process_filter+0xea7>
    3ef7:      	movq	%rax, %r12
    3efa:      	movq	%rbp, 0x38(%rsp)
    3eff:      	movl	$0x1000, 0x6410(%r14)   # imm = 0x1000
    3f0a:      	leaq	0x1000(%rax), %r13
    3f11:      	movl	$0x23, %eax
    3f16:      	callq	*%rax
    3f18:      	leaq	0xd50(%rax), %rdx
    3f1f:      	leaq	0xd8(%rsp), %rdi
    3f27:      	movl	$0x8, %ecx
    3f2c:      	movl	$0x4, %eax
    3f31:      	movl	$0x8, %esi
    3f36:      	callq	*%rax
    3f38:      	movq	0xd8(%rsp), %rbp
    3f40:      	leaq	0x48(%rbx), %r15
    3f44:      	leaq	0xe0(%rsp), %rdi
    3f4c:      	movl	$0x8, %ecx
    3f51:      	movl	$0x4, %eax
    3f56:      	movl	$0x8, %esi
    3f5b:      	movq	%r15, %rdx
    3f5e:      	callq	*%rax
    3f60:      	movq	0xe0(%rsp), %r14
    3f68:      	leaq	0x10(%r14), %rdx
    3f6c:      	leaq	0x60(%rsp), %rdi
    3f71:      	movl	$0x8, %ecx
    3f76:      	movl	$0x4, %eax
    3f7b:      	movl	$0x8, %esi
    3f80:      	callq	*%rax
    3f82:      	cmpq	$0x0, 0x60(%rsp)
    3f88:      	je	0x4256 <generic_uprobe_process_filter+0xb06>
    3f8e:      	movq	0x50(%rsp), %r14
    3f93:      	movq	$0x0, 0x68(%rsp)
    3f9c:      	movq	$0x0, 0x60(%rsp)
    3fa5:      	movq	%r12, 0x70(%rsp)
    3faa:      	movq	$0x0, 0x78(%rsp)
    3fb3:      	movq	$0x0, 0x80(%rsp)
    3fbf:      	movq	$0x0, 0x88(%rsp)
    3fcb:      	movq	%r13, 0xc0(%rsp)
    3fd3:      	movq	%r13, 0x90(%rsp)
    3fdb:      	movl	0x6410(%r14), %eax
    3fe2:      	movl	%eax, 0x98(%rsp)
    3fe9:      	leaq	0x18(%rbp), %r13
    3fed:      	movb	$0x0, 0x9c(%rsp)
    3ff5:      	addq	$0x20, %rbp
    3ff9:      	leaq	0x60(%rsp), %rdi
    3ffe:      	movl	$0x8, %ecx
    4003:      	movl	$0x4, %eax
    4008:      	addq	$0x40, %rbx
    400c:      	leaq	0x68(%rsp), %r12
    4011:      	leaq	0x78(%rsp), %r14
    4016:      	movl	$0x8, %esi
    401b:      	movq	%rbp, %rdx
    401e:      	callq	*%rax
    4020:      	movl	$0x8, %ecx
    4025:      	movl	$0x4, %eax
    402a:      	movq	%r12, %rdi
    402d:      	movl	$0x8, %esi
    4032:      	movq	%r13, %rdx
    4035:      	callq	*%rax
    4037:      	movl	$0x8, %ecx
    403c:      	movl	$0x4, %eax
    4041:      	movq	%r14, %rdi
    4044:      	movl	$0x8, %esi
    4049:      	movq	%r15, %rdx
    404c:      	callq	*%rax
    404e:      	movl	$0x8, %ecx
    4053:      	movl	$0x4, %eax
    4058:      	leaq	0x80(%rsp), %rdi
    4060:      	movl	$0x8, %esi
    4065:      	movq	%rbx, %rdx
    4068:      	callq	*%rax
    406a:      	movq	0x80(%rsp), %rax
    4072:      	addq	$-0x20, %rax
    4076:      	movq	%rax, 0x88(%rsp)
    407e:      	movq	(%rip), %rax            # 0x4085 <generic_uprobe_process_filter+0x935>
    4085:      	cmpb	$0x0, (%rax)
    4088:      	je	0x42ad <generic_uprobe_process_filter+0xb5d>
    408e:      	movl	$0x800, %r14d           # imm = 0x800
    4094:      	movl	$0x8, %ebp
    4099:      	leaq	0x10(%rsp), %rbx
    409e:      	nop
    40a0:      	movq	0x78(%rsp), %r15
    40a5:      	movq	0x80(%rsp), %rdx
    40ad:      	movq	0x88(%rsp), %r12
    40b5:      	cmpq	0x60(%rsp), %r15
    40ba:      	jne	0x40c7 <generic_uprobe_process_filter+0x977>
    40bc:      	cmpq	0x68(%rsp), %rdx
    40c1:      	je	0x446f <generic_uprobe_process_filter+0xd1f>
    40c7:      	movl	$0x4, %eax
    40cc:      	leaq	0xa8(%rsp), %rdi
    40d4:      	movl	$0x8, %esi
    40d9:      	callq	*%rax
    40db:      	cmpq	0xa8(%rsp), %r15
    40e3:      	je	0x41f0 <generic_uprobe_process_filter+0xaa0>
    40e9:      	leaq	0x18(%r15), %r13
    40ed:      	movl	$0x4, %eax
    40f2:      	movq	%rbx, %rdi
    40f5:      	movl	$0x8, %esi
    40fa:      	movq	%r13, %rdx
    40fd:      	callq	*%rax
    40ff:      	cmpq	%r15, 0x10(%rsp)
    4104:      	je	0x41f0 <generic_uprobe_process_filter+0xaa0>
    410a:      	movl	$0x4, %eax
    410f:      	leaq	0x58(%rsp), %rdi
    4114:      	movl	$0x8, %esi
    4119:      	movq	%r13, %rdx
    411c:      	callq	*%rax
    411e:      	addq	$0x20, %r15
    4122:      	movl	$0x4, %eax
    4127:      	leaq	0x40(%rsp), %rdi
    412c:      	movl	$0x10, %ecx
    4131:      	movl	$0x10, %esi
    4136:      	movq	%r15, %rdx
    4139:      	callq	*%rax
    413b:      	movq	0x70(%rsp), %r15
    4140:      	movq	0x90(%rsp), %rax
    4148:      	movl	0x44(%rsp), %r12d
    414d:      	subq	%r15, %rax
    4150:      	movl	0x98(%rsp), %r13d
    4158:      	movl	%r12d, %edx
    415b:      	subl	%r13d, %edx
    415e:      	movl	$0x0, %ecx
    4163:      	cmovbl	%ecx, %edx
    4166:      	addq	0x48(%rsp), %rdx
    416b:      	xorl	%esi, %esi
    416d:      	cmpl	%r12d, %r13d
    4170:      	seta	%sil
    4174:      	movl	%r12d, %ecx
    4177:      	cmovbl	%r13d, %ecx
    417b:      	addl	%ecx, %esi
    417d:      	movl	%r13d, %edi
    4180:      	subl	%esi, %edi
    4182:      	movl	%edi, 0x98(%rsp)
    4189:      	subq	%rsi, %rax
    418c:      	jb	0x4477 <generic_uprobe_process_filter+0xd27>
    4192:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    4198:      	ja	0x4477 <generic_uprobe_process_filter+0xd27>
    419e:      	cmpl	%r12d, %r13d
    41a1:      	jbe	0x41a8 <generic_uprobe_process_filter+0xa58>
    41a3:      	movb	$0x2f, (%r15,%rax)
    41a8:      	xorl	%edi, %edi
    41aa:      	cmpl	%r12d, %r13d
    41ad:      	seta	%dil
    41b1:      	movzbl	%cl, %esi
    41b4:      	addq	%rax, %r15
    41b7:      	addq	%r15, %rdi
    41ba:      	movl	$0x4, %eax
    41bf:      	callq	*%rax
    41c1:      	movq	%r15, 0x90(%rsp)
    41c9:      	cmpl	%r12d, %r13d
    41cc:      	jbe	0x4477 <generic_uprobe_process_filter+0xd27>
    41d2:      	movq	0x58(%rsp), %rax
    41d7:      	movq	%rax, 0x78(%rsp)
    41dc:      	decl	%r14d
    41df:      	jne	0x40a0 <generic_uprobe_process_filter+0x950>
    41e5:      	jmp	0x4477 <generic_uprobe_process_filter+0xd27>
    41ea:      	nopw	(%rax,%rax)
    41f0:      	leaq	0x10(%r12), %rdx
    41f5:      	movl	$0x4, %eax
    41fa:      	movq	%rbx, %rdi
    41fd:      	movl	$0x8, %esi
    4202:      	callq	*%rax
    4204:      	movq	0x88(%rsp), %rax
    420c:      	cmpq	0x10(%rsp), %rax
    4211:      	je	0x446f <generic_uprobe_process_filter+0xd1f>
    4217:      	addq	$0x18, %r12
    421b:      	movl	$0x4, %eax
    4220:      	leaq	0x78(%rsp), %rdi
    4225:      	movl	$0x8, %esi
    422a:      	movq	%r12, %rdx
    422d:      	callq	*%rax
    422f:      	movq	0x10(%rsp), %rax
    4234:      	movq	%rax, 0x88(%rsp)
    423c:      	addq	$0x20, %rax
    4240:      	movq	%rax, 0x80(%rsp)
    4248:      	decl	%r14d
    424b:      	jne	0x40a0 <generic_uprobe_process_filter+0x950>
    4251:      	jmp	0x4477 <generic_uprobe_process_filter+0xd27>
    4256:      	leaq	0x18(%r14), %rdx
    425a:      	leaq	0x60(%rsp), %rdi
    425f:      	movl	$0x8, %ecx
    4264:      	movl	$0x4, %eax
    4269:      	movl	$0x8, %esi
    426e:      	callq	*%rax
    4270:      	cmpq	%r14, 0x60(%rsp)
    4275:      	je	0x3f8e <generic_uprobe_process_filter+0x83e>
    427b:      	movq	0x50(%rsp), %r14
    4280:      	movl	0x6410(%r14), %ecx
    4287:      	leal	-0xa(%rcx), %eax
    428a:      	movl	%eax, 0x6410(%r14)
    4291:      	cmpl	$0x9, %ecx
    4294:      	jg	0x4c34 <generic_uprobe_process_filter+0x14e4>
    429a:      	movl	$0xffffffdc, 0x6414(%r14) # imm = 0xFFFFFFDC
    42a5:      	movq	%r13, %rbx
    42a8:      	jmp	0x44f8 <generic_uprobe_process_filter+0xda8>
    42ad:      	movl	$0x800, %r14d           # imm = 0x800
    42b3:      	movl	$0x8, %ebp
    42b8:      	leaq	0x10(%rsp), %rbx
    42bd:      	nopl	(%rax)
    42c0:      	movq	0x78(%rsp), %r15
    42c5:      	movq	0x80(%rsp), %rdx
    42cd:      	movq	0x88(%rsp), %r12
    42d5:      	cmpq	0x60(%rsp), %r15
    42da:      	jne	0x42e7 <generic_uprobe_process_filter+0xb97>
    42dc:      	cmpq	0x68(%rsp), %rdx
    42e1:      	je	0x446f <generic_uprobe_process_filter+0xd1f>
    42e7:      	movl	$0x4, %eax
    42ec:      	leaq	0xa8(%rsp), %rdi
    42f4:      	movl	$0x8, %esi
    42f9:      	callq	*%rax
    42fb:      	cmpq	0xa8(%rsp), %r15
    4303:      	je	0x4410 <generic_uprobe_process_filter+0xcc0>
    4309:      	leaq	0x18(%r15), %r13
    430d:      	movl	$0x4, %eax
    4312:      	movq	%rbx, %rdi
    4315:      	movl	$0x8, %esi
    431a:      	movq	%r13, %rdx
    431d:      	callq	*%rax
    431f:      	cmpq	%r15, 0x10(%rsp)
    4324:      	je	0x4410 <generic_uprobe_process_filter+0xcc0>
    432a:      	movl	$0x4, %eax
    432f:      	leaq	0x58(%rsp), %rdi
    4334:      	movl	$0x8, %esi
    4339:      	movq	%r13, %rdx
    433c:      	callq	*%rax
    433e:      	addq	$0x20, %r15
    4342:      	movl	$0x4, %eax
    4347:      	leaq	0x40(%rsp), %rdi
    434c:      	movl	$0x10, %ecx
    4351:      	movl	$0x10, %esi
    4356:      	movq	%r15, %rdx
    4359:      	callq	*%rax
    435b:      	movq	0x70(%rsp), %r15
    4360:      	movq	0x90(%rsp), %rax
    4368:      	movl	0x44(%rsp), %r12d
    436d:      	subq	%r15, %rax
    4370:      	movl	0x98(%rsp), %r13d
    4378:      	movl	%r12d, %edx
    437b:      	subl	%r13d, %edx
    437e:      	movl	$0x0, %ecx
    4383:      	cmovbl	%ecx, %edx
    4386:      	addq	0x48(%rsp), %rdx
    438b:      	xorl	%esi, %esi
    438d:      	cmpl	%r12d, %r13d
    4390:      	seta	%sil
    4394:      	movl	%r12d, %ecx
    4397:      	cmovbl	%r13d, %ecx
    439b:      	addl	%ecx, %esi
    439d:      	movl	%r13d, %edi
    43a0:      	subl	%esi, %edi
    43a2:      	movl	%edi, 0x98(%rsp)
    43a9:      	subq	%rsi, %rax
    43ac:      	jb	0x4477 <generic_uprobe_process_filter+0xd27>
    43b2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    43b8:      	ja	0x4477 <generic_uprobe_process_filter+0xd27>
    43be:      	cmpl	%r12d, %r13d
    43c1:      	jbe	0x43c8 <generic_uprobe_process_filter+0xc78>
    43c3:      	movb	$0x2f, (%r15,%rax)
    43c8:      	xorl	%edi, %edi
    43ca:      	cmpl	%r12d, %r13d
    43cd:      	seta	%dil
    43d1:      	movzbl	%cl, %esi
    43d4:      	addq	%rax, %r15
    43d7:      	addq	%r15, %rdi
    43da:      	movl	$0x4, %eax
    43df:      	callq	*%rax
    43e1:      	movq	%r15, 0x90(%rsp)
    43e9:      	cmpl	%r12d, %r13d
    43ec:      	jbe	0x4477 <generic_uprobe_process_filter+0xd27>
    43f2:      	movq	0x58(%rsp), %rax
    43f7:      	movq	%rax, 0x78(%rsp)
    43fc:      	decl	%r14d
    43ff:      	jne	0x42c0 <generic_uprobe_process_filter+0xb70>
    4405:      	jmp	0x4477 <generic_uprobe_process_filter+0xd27>
    4407:      	nopw	(%rax,%rax)
    4410:      	leaq	0x10(%r12), %rdx
    4415:      	movl	$0x4, %eax
    441a:      	movq	%rbx, %rdi
    441d:      	movl	$0x8, %esi
    4422:      	callq	*%rax
    4424:      	movq	0x88(%rsp), %rax
    442c:      	cmpq	0x10(%rsp), %rax
    4431:      	je	0x446f <generic_uprobe_process_filter+0xd1f>
    4433:      	addq	$0x18, %r12
    4437:      	movl	$0x4, %eax
    443c:      	leaq	0x78(%rsp), %rdi
    4441:      	movl	$0x8, %esi
    4446:      	movq	%r12, %rdx
    4449:      	callq	*%rax
    444b:      	movq	0x10(%rsp), %rax
    4450:      	movq	%rax, 0x88(%rsp)
    4458:      	addq	$0x20, %rax
    445c:      	movq	%rax, 0x80(%rsp)
    4464:      	decl	%r14d
    4467:      	jne	0x42c0 <generic_uprobe_process_filter+0xb70>
    446d:      	jmp	0x4477 <generic_uprobe_process_filter+0xd27>
    446f:      	movb	$0x1, 0x9c(%rsp)
    4477:      	movq	0x90(%rsp), %rbx
    447f:      	movq	0xc0(%rsp), %rcx
    4487:      	cmpq	%rcx, %rbx
    448a:      	je	0x44d8 <generic_uprobe_process_filter+0xd88>
    448c:      	xorl	%ecx, %ecx
    448e:      	cmpb	$0x0, 0x9c(%rsp)
    4496:      	sete	%cl
    4499:      	addl	%ecx, %ecx
    449b:      	movl	0x98(%rsp), %eax
    44a2:      	movq	0x50(%rsp), %r14
    44a7:      	movl	%eax, 0x6410(%r14)
    44ae:      	movl	%ecx, 0x6414(%r14)
    44b5:      	testl	%eax, %eax
    44b7:      	movq	0x38(%rsp), %rbp
    44bc:      	jle	0x44ce <generic_uprobe_process_filter+0xd7e>
    44be:      	movl	$0x1000, %ecx           # imm = 0x1000
    44c3:      	subl	%eax, %ecx
    44c5:      	movl	%ecx, 0x6410(%r14)
    44cc:      	movl	%ecx, %eax
    44ce:      	testq	%rbx, %rbx
    44d1:      	jne	0x44fd <generic_uprobe_process_filter+0xdad>
    44d3:      	jmp	0x45f7 <generic_uprobe_process_filter+0xea7>
    44d8:      	movq	0x50(%rsp), %r14
    44dd:      	movl	$0x0, 0x6410(%r14)
    44e8:      	movl	$0x0, 0x6414(%r14)
    44f3:      	xorl	%eax, %eax
    44f5:      	movq	%rcx, %rbx
    44f8:      	movq	0x38(%rsp), %rbp
    44fd:      	xorl	%ecx, %ecx
    44ff:      	movq	%r14, %rdx
    4502:      	movl	%eax, %r14d
    4505:      	subl	$0x7f, %r14d
    4509:      	movl	$0x7f, %r15d
    450f:      	cmovbl	%eax, %r15d
    4513:      	cmovbl	%ecx, %r14d
    4517:      	cmpl	$0xff, %eax
    451c:      	movl	$0xff, %ecx
    4521:      	cmovbl	%eax, %ecx
    4524:      	movzbl	%cl, %esi
    4527:      	movl	%esi, 0x6410(%rdx)
    452d:      	movl	$0x4, %eax
    4532:      	movq	%rbp, %rdi
    4535:      	movq	%rbx, %rdx
    4538:      	callq	*%rax
    453a:      	testq	%rax, %rax
    453d:      	je	0x459c <generic_uprobe_process_filter+0xe4c>
    453f:      	negl	%eax
    4541:      	movw	%ax, 0x60(%rsp)
    4546:      	movw	$0x8, 0x62(%rsp)
    454d:      	movabsq	$0x4000002de, %rax      # imm = 0x4000002DE
    4557:      	movq	%rax, 0x64(%rsp)
    455c:      	movq	(%rip), %rdi            # 0x4563 <generic_uprobe_process_filter+0xe13>
    4563:      	leaq	0x60(%rsp), %rsi
    4568:      	movl	$0x1, %eax
    456d:      	callq	*%rax
    456f:      	testq	%rax, %rax
    4572:      	je	0x4578 <generic_uprobe_process_filter+0xe28>
    4574:      	incl	(%rax)
    4576:      	jmp	0x459c <generic_uprobe_process_filter+0xe4c>
    4578:      	movl	$0x1, 0x40(%rsp)
    4580:      	movq	(%rip), %rdi            # 0x4587 <generic_uprobe_process_filter+0xe37>
    4587:      	xorl	%ecx, %ecx
    4589:      	leaq	0x60(%rsp), %rsi
    458e:      	leaq	0x40(%rsp), %rdx
    4593:      	movl	$0x2, %eax
    4598:      	xorl	%ecx, %ecx
    459a:      	callq	*%rax
    459c:      	movq	0x50(%rsp), %rax
    45a1:      	leaq	0x6390(%rax), %rdi
    45a8:      	addq	%r14, %rbx
    45ab:      	movq	%rax, %r14
    45ae:      	movl	$0x4, %eax
    45b3:      	movl	%r15d, %esi
    45b6:      	movq	%rbx, %rdx
    45b9:      	callq	*%rax
    45bb:      	testq	%rax, %rax
    45be:      	je	0x45f7 <generic_uprobe_process_filter+0xea7>
    45c0:      	negl	%eax
    45c2:      	movw	%ax, 0x60(%rsp)
    45c7:      	movw	$0x8, 0x62(%rsp)
    45ce:      	movabsq	$0x4000002e0, %rax      # imm = 0x4000002E0
    45d8:      	movq	%rax, 0x64(%rsp)
    45dd:      	movq	(%rip), %rdi            # 0x45e4 <generic_uprobe_process_filter+0xe94>
    45e4:      	leaq	0x60(%rsp), %rsi
    45e9:      	movl	$0x1, %eax
    45ee:      	callq	*%rax
    45f0:      	testq	%rax, %rax
    45f3:      	je	0x4624 <generic_uprobe_process_filter+0xed4>
    45f5:      	incl	(%rax)
    45f7:      	movl	0x6410(%r14), %eax
    45fe:      	leal	-0x101(%rax), %ecx
    4604:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    460a:      	ja	0x465d <generic_uprobe_process_filter+0xf0d>
    460c:      	movq	0x8(%rsp), %rax
    4611:      	movl	$0xffffffff, (%rax)     # imm = 0xFFFFFFFF
    4617:      	movq	0xb8(%rsp), %rbx
    461f:      	jmp	0x4773 <generic_uprobe_process_filter+0x1023>
    4624:      	movl	$0x1, 0x40(%rsp)
    462c:      	movq	(%rip), %rdi            # 0x4633 <generic_uprobe_process_filter+0xee3>
    4633:      	xorl	%ecx, %ecx
    4635:      	leaq	0x60(%rsp), %rsi
    463a:      	leaq	0x40(%rsp), %rdx
    463f:      	movl	$0x2, %eax
    4644:      	xorl	%ecx, %ecx
    4646:      	callq	*%rax
    4648:      	movl	0x6410(%r14), %eax
    464f:      	leal	-0x101(%rax), %ecx
    4655:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    465b:      	jbe	0x460c <generic_uprobe_process_filter+0xebc>
    465d:      	movzbl	%al, %ebx
    4660:      	leaq	0x5f80(%r14), %rdi
    4667:      	movl	$0x4, %eax
    466c:      	movl	%ebx, %esi
    466e:      	movq	%rbp, %rdx
    4671:      	callq	*%rax
    4673:      	movq	%rax, %r15
    4676:      	testq	%rax, %rax
    4679:      	je	0x46db <generic_uprobe_process_filter+0xf8b>
    467b:      	movl	%r15d, %eax
    467e:      	negl	%eax
    4680:      	movw	%ax, 0x60(%rsp)
    4685:      	movw	$0xf, 0x62(%rsp)
    468c:      	movabsq	$0x400000164, %rax      # imm = 0x400000164
    4696:      	movq	%rax, 0x64(%rsp)
    469b:      	movq	(%rip), %rdi            # 0x46a2 <generic_uprobe_process_filter+0xf52>
    46a2:      	leaq	0x60(%rsp), %rsi
    46a7:      	movl	$0x1, %eax
    46ac:      	callq	*%rax
    46ae:      	testq	%rax, %rax
    46b1:      	je	0x46b7 <generic_uprobe_process_filter+0xf67>
    46b3:      	incl	(%rax)
    46b5:      	jmp	0x46db <generic_uprobe_process_filter+0xf8b>
    46b7:      	movl	$0x1, 0x40(%rsp)
    46bf:      	movq	(%rip), %rdi            # 0x46c6 <generic_uprobe_process_filter+0xf76>
    46c6:      	xorl	%ecx, %ecx
    46c8:      	leaq	0x60(%rsp), %rsi
    46cd:      	leaq	0x40(%rsp), %rdx
    46d2:      	movl	$0x2, %eax
    46d7:      	xorl	%ecx, %ecx
    46d9:      	callq	*%rax
    46db:      	testl	%r15d, %r15d
    46de:      	cmovel	%ebx, %r15d
    46e2:      	movl	%r15d, 0x5f78(%r14)
    46e9:      	cmpl	$0x7f, %ebx
    46ec:      	movl	$0x7f, %esi
    46f1:      	cmovbl	%ebx, %esi
    46f4:      	leaq	0x6080(%r14), %rdi
    46fb:      	leaq	0x6390(%r14), %rdx
    4702:      	movl	$0x4, %eax
    4707:      	callq	*%rax
    4709:      	testq	%rax, %rax
    470c:      	movq	0xb8(%rsp), %rbx
    4714:      	je	0x4773 <generic_uprobe_process_filter+0x1023>
    4716:      	negl	%eax
    4718:      	movw	%ax, 0x60(%rsp)
    471d:      	movw	$0xf, 0x62(%rsp)
    4724:      	movabsq	$0x40000016a, %rax      # imm = 0x40000016A
    472e:      	movq	%rax, 0x64(%rsp)
    4733:      	movq	(%rip), %rdi            # 0x473a <generic_uprobe_process_filter+0xfea>
    473a:      	leaq	0x60(%rsp), %rsi
    473f:      	movl	$0x1, %eax
    4744:      	callq	*%rax
    4746:      	testq	%rax, %rax
    4749:      	je	0x474f <generic_uprobe_process_filter+0xfff>
    474b:      	incl	(%rax)
    474d:      	jmp	0x4773 <generic_uprobe_process_filter+0x1023>
    474f:      	movl	$0x1, 0x40(%rsp)
    4757:      	movq	(%rip), %rdi            # 0x475e <generic_uprobe_process_filter+0x100e>
    475e:      	xorl	%ecx, %ecx
    4760:      	leaq	0x60(%rsp), %rsi
    4765:      	leaq	0x40(%rsp), %rdx
    476a:      	movl	$0x2, %eax
    476f:      	xorl	%ecx, %ecx
    4771:      	callq	*%rax
    4773:      	leaq	0x5f10(%r14), %r15
    477a:      	orb	$0x10, 0x1(%r14)
    477f:      	leaq	0x5ef8(%r14), %rsi
    4786:      	movq	(%rip), %rdi            # 0x478d <generic_uprobe_process_filter+0x103d>
    478d:      	movl	$0x1, %eax
    4792:      	callq	*%rax
    4794:      	testq	%rax, %rax
    4797:      	je	0x5d73 <generic_uprobe_process_filter+0x2623>
    479d:      	movq	0x5eb8(%r14), %r13
    47a4:      	cmpq	$0x6, %r13
    47a8:      	jae	0x49d6 <generic_uprobe_process_filter+0x1286>
    47ae:      	movslq	(%rax), %rcx
    47b1:      	testq	%rcx, %rcx
    47b4:      	je	0x49f8 <generic_uprobe_process_filter+0x12a8>
    47ba:      	cmpq	%rcx, %r13
    47bd:      	jae	0x49d6 <generic_uprobe_process_filter+0x1286>
    47c3:      	movq	%rax, 0x8(%rsp)
    47c8:      	movq	%rcx, 0xc0(%rsp)
    47d0:      	movq	%rbx, 0xb8(%rsp)
    47d8:      	movl	%r13d, 0x10(%rsp)
    47dd:      	movl	$0x0, 0x58(%rsp)
    47e5:      	movq	(%rip), %rdi            # 0x47ec <generic_uprobe_process_filter+0x109c>
    47ec:      	leaq	0x10(%rsp), %rsi
    47f1:      	movl	$0x1, %eax
    47f6:      	callq	*%rax
    47f8:      	testq	%rax, %rax
    47fb:      	movq	%r15, 0x38(%rsp)
    4800:      	je	0x4a14 <generic_uprobe_process_filter+0x12c4>
    4806:      	movq	%rax, %rbx
    4809:      	movl	(%rax), %eax
    480b:      	testl	%eax, %eax
    480d:      	je	0x4a14 <generic_uprobe_process_filter+0x12c4>
    4813:      	cmpl	$0x0, 0x68(%r15)
    4818:      	js	0x5d1b <generic_uprobe_process_filter+0x25cb>
    481e:      	cmpl	$0x1b, %eax
    4821:      	ja	0x5d1b <generic_uprobe_process_filter+0x25cb>
    4827:      	movl	$0x60, %ecx
    482c:      	btl	%eax, %ecx
    482f:      	jb	0x54ac <generic_uprobe_process_filter+0x1d5c>
    4835:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    483a:      	btl	%eax, %ecx
    483d:      	jb	0x5419 <generic_uprobe_process_filter+0x1cc9>
    4843:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    4848:      	btl	%eax, %ecx
    484b:      	jae	0x5d1b <generic_uprobe_process_filter+0x25cb>
    4851:      	movq	%rbx, %rsi
    4854:      	addq	$0x4, %rsi
    4858:      	movq	(%rip), %rdi            # 0x485f <generic_uprobe_process_filter+0x110f>
    485f:      	movl	$0x1, %eax
    4864:      	callq	*%rax
    4866:      	testq	%rax, %rax
    4869:      	je	0x5d1b <generic_uprobe_process_filter+0x25cb>
    486f:      	movq	%rax, %r12
    4872:      	movq	0x38(%rsp), %rax
    4877:      	movl	0x68(%rax), %eax
    487a:      	cmpl	$0x7f, %eax
    487d:      	movl	$0x7f, %r14d
    4883:      	cmovll	%eax, %r14d
    4887:      	movq	(%rip), %rdi            # 0x488e <generic_uprobe_process_filter+0x113e>
    488e:      	leaq	0x58(%rsp), %rsi
    4893:      	movl	$0x1, %eax
    4898:      	callq	*%rax
    489a:      	testq	%rax, %rax
    489d:      	je	0x5d1b <generic_uprobe_process_filter+0x25cb>
    48a3:      	movq	%rax, %rbp
    48a6:      	leal	(,%r14,8), %eax
    48ae:      	movl	%eax, (%rbp)
    48b1:      	movq	0x38(%rsp), %rax
    48b6:      	cmpl	$0x0, 0x6c(%rax)
    48ba:      	jne	0x499d <generic_uprobe_process_filter+0x124d>
    48c0:      	movq	0x38(%rsp), %r15
    48c5:      	movl	0x68(%r15), %ecx
    48c9:      	movl	%ecx, %eax
    48cb:      	subl	%r14d, %eax
    48ce:      	movl	%r14d, %edx
    48d1:      	andl	$0x7f, %edx
    48d4:      	addl	%edx, %eax
    48d6:      	addl	%ecx, %edx
    48d8:      	movl	%r14d, %ecx
    48db:      	notl	%ecx
    48dd:      	addl	%edx, %ecx
    48df:      	subl	%r14d, %edx
    48e2:      	leal	-0x4(%rdx), %esi
    48e5:      	leaq	0x1f3(%r15), %rdi
    48ec:      	leal	-0x3(%rdx), %r8d
    48f0:      	addl	$-0x2, %edx
    48f3:      	movq	$-0x3, %r9
    48fa:      	leal	(%rcx,%r9), %r10d
    48fe:      	addl	$0x3, %r10d
    4902:      	andl	$0x7f, %r10d
    4906:      	movzbl	0x170(%r15,%r10), %r10d
    490f:      	movb	%r10b, -0x3(%rdi)
    4913:      	leaq	(%rax,%r9), %r10
    4917:      	cmpq	$-0x2, %r10
    491b:      	je	0x4995 <generic_uprobe_process_filter+0x1245>
    491d:      	leal	(%rdx,%r9), %r11d
    4921:      	addl	$0x3, %r11d
    4925:      	andl	$0x7f, %r11d
    4929:      	movzbl	0x170(%r15,%r11), %r11d
    4932:      	movb	%r11b, -0x2(%rdi)
    4936:      	cmpq	$-0x1, %r10
    493a:      	je	0x4995 <generic_uprobe_process_filter+0x1245>
    493c:      	leal	(%r8,%r9), %r10d
    4940:      	addl	$0x3, %r10d
    4944:      	andl	$0x7f, %r10d
    4948:      	movzbl	0x170(%r15,%r10), %r10d
    4951:      	movb	%r10b, -0x1(%rdi)
    4955:      	movq	%rax, %r10
    4958:      	addq	%r9, %r10
    495b:      	je	0x4995 <generic_uprobe_process_filter+0x1245>
    495d:      	cmpq	$-0x7f, %r9
    4961:      	je	0x4995 <generic_uprobe_process_filter+0x1245>
    4963:      	leal	(%rsi,%r9), %r10d
    4967:      	addl	$0x3, %r10d
    496b:      	andl	$0x7f, %r10d
    496f:      	movzbl	0x170(%r15,%r10), %r10d
    4978:      	movb	%r10b, (%rdi)
    497b:      	addq	$0x4, %rdi
    497f:      	leaq	(%rax,%r9), %r10
    4983:      	addq	$-0x4, %r10
    4987:      	addq	$-0x4, %r9
    498b:      	cmpq	$-0x3, %r10
    498f:      	jne	0x48fa <generic_uprobe_process_filter+0x11aa>
    4995:      	movl	$0x1, 0x6c(%r15)
    499d:      	cmpl	$0x7f, %r14d
    49a1:      	ja	0x49c9 <generic_uprobe_process_filter+0x1279>
    49a3:      	movslq	%r14d, %rsi
    49a6:      	movq	%rbp, %rdi
    49a9:      	addq	$0x4, %rdi
    49ad:      	movq	0x38(%rsp), %rax
    49b2:      	leaq	0x1f0(%rax), %rdx
    49b9:      	movl	$0x4, %eax
    49be:      	callq	*%rax
    49c0:      	testq	%rax, %rax
    49c3:      	js	0x5d1b <generic_uprobe_process_filter+0x25cb>
    49c9:      	movl	$0x1, %eax
    49ce:      	movq	%r12, %rdi
    49d1:      	jmp	0x54a4 <generic_uprobe_process_filter+0x1d54>
    49d6:      	movl	(%r15), %eax
    49d9:      	movl	%eax, 0x10(%r14)
    49dd:      	movq	0x8(%r15), %rax
    49e1:      	movq	%rax, 0x18(%r14)
    49e5:      	cmpb	$0x0, 0x5ec0(%r14)
    49ed:      	jne	0x5d5e <generic_uprobe_process_filter+0x260e>
    49f3:      	jmp	0x5d73 <generic_uprobe_process_filter+0x2623>
    49f8:      	movb	$0x1, 0x5ec0(%r14)
    4a00:      	movl	(%r15), %eax
    4a03:      	movl	%eax, 0x10(%r14)
    4a07:      	movq	0x8(%r15), %rax
    4a0b:      	movq	%rax, 0x18(%r14)
    4a0f:      	jmp	0x5d5e <generic_uprobe_process_filter+0x260e>
    4a14:      	movq	0x8(%rsp), %r10
    4a19:      	movq	(%rip), %rax            # 0x4a20 <generic_uprobe_process_filter+0x12d0>
    4a20:      	cmpb	$0x0, (%rax)
    4a23:      	je	0x4c65 <generic_uprobe_process_filter+0x1515>
    4a29:      	movq	(%rip), %rdi            # 0x4a30 <generic_uprobe_process_filter+0x12e0>
    4a30:      	movl	$0x1, %eax
    4a35:      	movq	0x38(%rsp), %rsi
    4a3a:      	callq	*%rax
    4a3c:      	movq	0x8(%rsp), %r10
    4a41:      	testq	%rax, %rax
    4a44:      	je	0x4c65 <generic_uprobe_process_filter+0x1515>
    4a4a:      	movq	%rax, %rbp
    4a4d:      	leal	0x5(%r13), %eax
    4a51:      	movl	%eax, 0x10(%rsp)
    4a55:      	movl	$0x0, 0x58(%rsp)
    4a5d:      	movq	(%rip), %rdi            # 0x4a64 <generic_uprobe_process_filter+0x1314>
    4a64:      	leaq	0x10(%rsp), %rsi
    4a69:      	movl	$0x1, %eax
    4a6e:      	callq	*%rax
    4a70:      	testq	%rax, %rax
    4a73:      	je	0x4c60 <generic_uprobe_process_filter+0x1510>
    4a79:      	movq	%rax, %r12
    4a7c:      	movl	(%rax), %eax
    4a7e:      	testl	%eax, %eax
    4a80:      	je	0x4c60 <generic_uprobe_process_filter+0x1510>
    4a86:      	cmpl	$0x0, (%rbp)
    4a8a:      	js	0x5d1b <generic_uprobe_process_filter+0x25cb>
    4a90:      	cmpl	$0x1b, %eax
    4a93:      	ja	0x5d1b <generic_uprobe_process_filter+0x25cb>
    4a99:      	movl	$0x60, %ecx
    4a9e:      	btl	%eax, %ecx
    4aa1:      	jb	0x5708 <generic_uprobe_process_filter+0x1fb8>
    4aa7:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    4aac:      	btl	%eax, %ecx
    4aaf:      	jb	0x5678 <generic_uprobe_process_filter+0x1f28>
    4ab5:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    4aba:      	btl	%eax, %ecx
    4abd:      	jae	0x5d1b <generic_uprobe_process_filter+0x25cb>
    4ac3:      	movq	%r12, %rsi
    4ac6:      	addq	$0x4, %rsi
    4aca:      	movq	(%rip), %rdi            # 0x4ad1 <generic_uprobe_process_filter+0x1381>
    4ad1:      	movl	$0x1, %eax
    4ad6:      	callq	*%rax
    4ad8:      	testq	%rax, %rax
    4adb:      	je	0x5d1b <generic_uprobe_process_filter+0x25cb>
    4ae1:      	movq	%rax, %r15
    4ae4:      	movl	(%rbp), %eax
    4ae7:      	cmpl	$0x7f, %eax
    4aea:      	movl	$0x7f, %r14d
    4af0:      	cmovll	%eax, %r14d
    4af4:      	movq	(%rip), %rdi            # 0x4afb <generic_uprobe_process_filter+0x13ab>
    4afb:      	leaq	0x58(%rsp), %rsi
    4b00:      	movl	$0x1, %eax
    4b05:      	callq	*%rax
    4b07:      	testq	%rax, %rax
    4b0a:      	je	0x5d1b <generic_uprobe_process_filter+0x25cb>
    4b10:      	movq	%rax, %rbx
    4b13:      	leal	(,%r14,8), %eax
    4b1b:      	movl	%eax, (%rbx)
    4b1d:      	cmpl	$0x0, 0x4(%rbp)
    4b21:      	jne	0x4bfd <generic_uprobe_process_filter+0x14ad>
    4b27:      	movl	(%rbp), %ecx
    4b2a:      	movl	%ecx, %eax
    4b2c:      	subl	%r14d, %eax
    4b2f:      	movl	%r14d, %edx
    4b32:      	andl	$0x7f, %edx
    4b35:      	addl	%edx, %eax
    4b37:      	addl	%ecx, %edx
    4b39:      	movl	%r14d, %ecx
    4b3c:      	notl	%ecx
    4b3e:      	addl	%edx, %ecx
    4b40:      	subl	%r14d, %edx
    4b43:      	leal	-0x4(%rdx), %esi
    4b46:      	leaq	0x18b(%rbp), %rdi
    4b4d:      	leal	-0x3(%rdx), %r8d
    4b51:      	addl	$-0x2, %edx
    4b54:      	movq	$-0x3, %r9
    4b5b:      	leal	(%rcx,%r9), %r10d
    4b5f:      	addl	$0x3, %r10d
    4b63:      	andl	$0x7f, %r10d
    4b67:      	movzbl	0x108(%rbp,%r10), %r10d
    4b70:      	movb	%r10b, -0x3(%rdi)
    4b74:      	leaq	(%rax,%r9), %r10
    4b78:      	cmpq	$-0x2, %r10
    4b7c:      	je	0x4bf6 <generic_uprobe_process_filter+0x14a6>
    4b7e:      	leal	(%rdx,%r9), %r11d
    4b82:      	addl	$0x3, %r11d
    4b86:      	andl	$0x7f, %r11d
    4b8a:      	movzbl	0x108(%rbp,%r11), %r11d
    4b93:      	movb	%r11b, -0x2(%rdi)
    4b97:      	cmpq	$-0x1, %r10
    4b9b:      	je	0x4bf6 <generic_uprobe_process_filter+0x14a6>
    4b9d:      	leal	(%r8,%r9), %r10d
    4ba1:      	addl	$0x3, %r10d
    4ba5:      	andl	$0x7f, %r10d
    4ba9:      	movzbl	0x108(%rbp,%r10), %r10d
    4bb2:      	movb	%r10b, -0x1(%rdi)
    4bb6:      	movq	%rax, %r10
    4bb9:      	addq	%r9, %r10
    4bbc:      	je	0x4bf6 <generic_uprobe_process_filter+0x14a6>
    4bbe:      	cmpq	$-0x7f, %r9
    4bc2:      	je	0x4bf6 <generic_uprobe_process_filter+0x14a6>
    4bc4:      	leal	(%rsi,%r9), %r10d
    4bc8:      	addl	$0x3, %r10d
    4bcc:      	andl	$0x7f, %r10d
    4bd0:      	movzbl	0x108(%rbp,%r10), %r10d
    4bd9:      	movb	%r10b, (%rdi)
    4bdc:      	addq	$0x4, %rdi
    4be0:      	leaq	(%rax,%r9), %r10
    4be4:      	addq	$-0x4, %r10
    4be8:      	addq	$-0x4, %r9
    4bec:      	cmpq	$-0x3, %r10
    4bf0:      	jne	0x4b5b <generic_uprobe_process_filter+0x140b>
    4bf6:      	movl	$0x1, 0x4(%rbp)
    4bfd:      	cmpl	$0x7f, %r14d
    4c01:      	ja	0x4c27 <generic_uprobe_process_filter+0x14d7>
    4c03:      	movslq	%r14d, %rsi
    4c06:      	movq	%rbx, %rdi
    4c09:      	addq	$0x4, %rdi
    4c0d:      	addq	$0x188, %rbp            # imm = 0x188
    4c14:      	movl	$0x4, %eax
    4c19:      	movq	%rbp, %rdx
    4c1c:      	callq	*%rax
    4c1e:      	testq	%rax, %rax
    4c21:      	js	0x5d1b <generic_uprobe_process_filter+0x25cb>
    4c27:      	movl	$0x1, %eax
    4c2c:      	movq	%r15, %rdi
    4c2f:      	jmp	0x5700 <generic_uprobe_process_filter+0x1fb0>
    4c34:      	movq	%r12, %r13
    4c37:      	addq	$0xff6, %r13            # imm = 0xFF6
    4c3e:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    4c48:      	movq	%rax, 0xff6(%r12)
    4c50:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
    4c5b:      	jmp	0x3f93 <generic_uprobe_process_filter+0x843>
    4c60:      	movq	0x8(%rsp), %r10
    4c65:      	movl	%r13d, %eax
    4c68:      	leaq	0x4(,%rax,4), %rcx
    4c70:      	movl	0x4(%r10,%rax,4), %eax
    4c75:      	leal	(%rax,%rcx), %r14d
    4c79:      	andl	$0x3ff, %r14d           # imm = 0x3FF
    4c80:      	addl	%eax, %ecx
    4c82:      	addl	$0x4, %ecx
    4c85:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    4c8b:      	leaq	0x8(%r14), %rbp
    4c8f:      	cmpl	$0x5, (%rcx,%r10)
    4c94:      	jb	0x51be <generic_uprobe_process_filter+0x1a6e>
    4c9a:      	movl	(%rbp,%r10), %r12d
    4c9f:      	movl	0x4(%rbp,%r10), %edi
    4ca4:      	movl	0x8(%rbp,%r10), %edx
    4ca9:      	movq	$0x0, 0x68(%rsp)
    4cb2:      	movq	$0x0, 0x60(%rsp)
    4cbb:      	cmpl	$0x4, %edx
    4cbe:      	movl	$0x4, %ecx
    4cc3:      	cmovbl	%edx, %ecx
    4cc6:      	cmpl	$0x6, %r12d
    4cca:      	jne	0x4ce0 <generic_uprobe_process_filter+0x1590>
    4ccc:      	movabsq	$0x100000001, %rsi      # imm = 0x100000001
    4cd6:      	movq	%rsi, 0x60(%rsp)
    4cdb:      	movq	%rsi, 0x68(%rsp)
    4ce0:      	testl	%edx, %edx
    4ce2:      	je	0x51c5 <generic_uprobe_process_filter+0x1a75>
    4ce8:      	movq	0x38(%rsp), %rdx
    4ced:      	leaq	0x24(%rdx), %rsi
    4cf1:      	testb	$0x1, %dil
    4cf5:      	movq	%rsi, 0xb0(%rsp)
    4cfd:      	movq	%rsi, %r8
    4d00:      	cmoveq	%rdx, %r8
    4d04:      	addq	$0x10, %rdx
    4d08:      	movq	%rdx, 0xd0(%rsp)
    4d10:      	leal	(%rax,%r13,4), %r9d
    4d14:      	addl	$0x4, %r9d
    4d18:      	andl	$0x3ff, %r9d            # imm = 0x3FF
    4d1f:      	addq	$0x14, %r9
    4d23:      	decq	%rcx
    4d26:      	cmpq	$0x3, %rcx
    4d2a:      	movl	$0x3, %eax
    4d2f:      	cmovbq	%rcx, %rax
    4d33:      	movl	%eax, %eax
    4d35:      	leaq	0x4(,%rax,4), %r11
    4d3d:      	xorl	%r13d, %r13d
    4d40:      	movq	%rdi, 0x30(%rsp)
    4d45:      	movq	%r8, 0x28(%rsp)
    4d4a:      	movq	%r9, 0x20(%rsp)
    4d4f:      	movq	%r11, 0x18(%rsp)
    4d54:      	jmp	0x4d90 <generic_uprobe_process_filter+0x1640>
    4d56:      	movq	0x8(%rsp), %r10
    4d5b:      	movq	0x30(%rsp), %rdi
    4d60:      	movq	0x28(%rsp), %r8
    4d65:      	movq	0x20(%rsp), %r9
    4d6a:      	movq	0x18(%rsp), %r11
    4d6f:      	cmpl	$0x6, %r12d
    4d73:      	setne	%al
    4d76:      	xorb	$0x1, %bl
    4d79:      	orb	%al, %bl
    4d7b:      	movzbl	%bl, %eax
    4d7e:      	movl	%eax, 0x60(%rsp,%r13)
    4d83:      	addq	$0x4, %r13
    4d87:      	cmpq	%r13, %r11
    4d8a:      	je	0x51c5 <generic_uprobe_process_filter+0x1a75>
    4d90:      	leaq	(%r9,%r13), %rax
    4d94:      	movl	(%r8), %ecx
    4d97:      	cmpq	$0x3e8, %rax            # imm = 0x3E8
    4d9d:      	jbe	0x4faa <generic_uprobe_process_filter+0x185a>
    4da3:      	xorl	%r15d, %r15d
    4da6:      	testb	$0x2, %dil
    4daa:      	je	0x4fc7 <generic_uprobe_process_filter+0x1877>
    4db0:      	testb	$0x1, %dil
    4db4:      	jne	0x4fe8 <generic_uprobe_process_filter+0x1898>
    4dba:      	movq	0x38(%rsp), %rcx
    4dbf:      	movl	(%rcx), %eax
    4dc1:      	movb	$0x1, %bl
    4dc3:      	cmpq	%rax, %r15
    4dc6:      	je	0x4d6f <generic_uprobe_process_filter+0x161f>
    4dc8:      	movl	0x10(%rcx), %eax
    4dcb:      	cmpq	%rax, %r15
    4dce:      	je	0x4d6f <generic_uprobe_process_filter+0x161f>
    4dd0:      	movl	$0x1, %eax
    4dd5:      	movq	0xd0(%rsp), %rsi
    4ddd:      	movq	(%rip), %rdi            # 0x4de4 <generic_uprobe_process_filter+0x1694>
    4de4:      	callq	*%rax
    4de6:      	testq	%rax, %rax
    4de9:      	je	0x518d <generic_uprobe_process_filter+0x1a3d>
    4def:      	movq	%rax, %rsi
    4df2:      	movl	(%rax), %eax
    4df4:      	cmpq	%rax, %r15
    4df7:      	je	0x4d56 <generic_uprobe_process_filter+0x1606>
    4dfd:      	movl	0x10(%rsi), %eax
    4e00:      	cmpq	%rax, %r15
    4e03:      	je	0x4d56 <generic_uprobe_process_filter+0x1606>
    4e09:      	addq	$0x10, %rsi
    4e0d:      	movl	$0x1, %eax
    4e12:      	movq	(%rip), %rdi            # 0x4e19 <generic_uprobe_process_filter+0x16c9>
    4e19:      	callq	*%rax
    4e1b:      	testq	%rax, %rax
    4e1e:      	je	0x518d <generic_uprobe_process_filter+0x1a3d>
    4e24:      	movq	%rax, %rsi
    4e27:      	movl	(%rax), %eax
    4e29:      	cmpq	%rax, %r15
    4e2c:      	je	0x4d56 <generic_uprobe_process_filter+0x1606>
    4e32:      	movl	0x10(%rsi), %eax
    4e35:      	cmpq	%rax, %r15
    4e38:      	je	0x4d56 <generic_uprobe_process_filter+0x1606>
    4e3e:      	addq	$0x10, %rsi
    4e42:      	movl	$0x1, %eax
    4e47:      	movq	(%rip), %rdi            # 0x4e4e <generic_uprobe_process_filter+0x16fe>
    4e4e:      	callq	*%rax
    4e50:      	testq	%rax, %rax
    4e53:      	je	0x518d <generic_uprobe_process_filter+0x1a3d>
    4e59:      	movq	%rax, %rsi
    4e5c:      	movl	(%rax), %eax
    4e5e:      	cmpq	%rax, %r15
    4e61:      	je	0x4d56 <generic_uprobe_process_filter+0x1606>
    4e67:      	movl	0x10(%rsi), %eax
    4e6a:      	cmpq	%rax, %r15
    4e6d:      	je	0x4d56 <generic_uprobe_process_filter+0x1606>
    4e73:      	addq	$0x10, %rsi
    4e77:      	movl	$0x1, %eax
    4e7c:      	movq	(%rip), %rdi            # 0x4e83 <generic_uprobe_process_filter+0x1733>
    4e83:      	callq	*%rax
    4e85:      	testq	%rax, %rax
    4e88:      	je	0x518d <generic_uprobe_process_filter+0x1a3d>
    4e8e:      	movq	%rax, %rsi
    4e91:      	movl	(%rax), %eax
    4e93:      	cmpq	%rax, %r15
    4e96:      	je	0x4d56 <generic_uprobe_process_filter+0x1606>
    4e9c:      	movl	0x10(%rsi), %eax
    4e9f:      	cmpq	%rax, %r15
    4ea2:      	je	0x4d56 <generic_uprobe_process_filter+0x1606>
    4ea8:      	addq	$0x10, %rsi
    4eac:      	movl	$0x1, %eax
    4eb1:      	movq	(%rip), %rdi            # 0x4eb8 <generic_uprobe_process_filter+0x1768>
    4eb8:      	callq	*%rax
    4eba:      	testq	%rax, %rax
    4ebd:      	je	0x518d <generic_uprobe_process_filter+0x1a3d>
    4ec3:      	movq	%rax, %rsi
    4ec6:      	movl	(%rax), %eax
    4ec8:      	cmpq	%rax, %r15
    4ecb:      	je	0x4d56 <generic_uprobe_process_filter+0x1606>
    4ed1:      	movl	0x10(%rsi), %eax
    4ed4:      	cmpq	%rax, %r15
    4ed7:      	je	0x4d56 <generic_uprobe_process_filter+0x1606>
    4edd:      	addq	$0x10, %rsi
    4ee1:      	movl	$0x1, %eax
    4ee6:      	movq	(%rip), %rdi            # 0x4eed <generic_uprobe_process_filter+0x179d>
    4eed:      	callq	*%rax
    4eef:      	testq	%rax, %rax
    4ef2:      	je	0x518d <generic_uprobe_process_filter+0x1a3d>
    4ef8:      	movq	%rax, %rsi
    4efb:      	movl	(%rax), %eax
    4efd:      	cmpq	%rax, %r15
    4f00:      	je	0x4d56 <generic_uprobe_process_filter+0x1606>
    4f06:      	movl	0x10(%rsi), %eax
    4f09:      	cmpq	%rax, %r15
    4f0c:      	je	0x4d56 <generic_uprobe_process_filter+0x1606>
    4f12:      	addq	$0x10, %rsi
    4f16:      	movl	$0x1, %eax
    4f1b:      	movq	(%rip), %rdi            # 0x4f22 <generic_uprobe_process_filter+0x17d2>
    4f22:      	callq	*%rax
    4f24:      	testq	%rax, %rax
    4f27:      	je	0x518d <generic_uprobe_process_filter+0x1a3d>
    4f2d:      	movq	%rax, %rsi
    4f30:      	movl	(%rax), %eax
    4f32:      	cmpq	%rax, %r15
    4f35:      	je	0x4d56 <generic_uprobe_process_filter+0x1606>
    4f3b:      	movl	0x10(%rsi), %eax
    4f3e:      	cmpq	%rax, %r15
    4f41:      	je	0x4d56 <generic_uprobe_process_filter+0x1606>
    4f47:      	addq	$0x10, %rsi
    4f4b:      	movl	$0x1, %eax
    4f50:      	movq	(%rip), %rdi            # 0x4f57 <generic_uprobe_process_filter+0x1807>
    4f57:      	callq	*%rax
    4f59:      	testq	%rax, %rax
    4f5c:      	je	0x518d <generic_uprobe_process_filter+0x1a3d>
    4f62:      	movq	%rax, %rsi
    4f65:      	movl	(%rax), %eax
    4f67:      	cmpq	%rax, %r15
    4f6a:      	je	0x4d56 <generic_uprobe_process_filter+0x1606>
    4f70:      	movl	0x10(%rsi), %eax
    4f73:      	cmpq	%rax, %r15
    4f76:      	movq	0x8(%rsp), %r10
    4f7b:      	movq	0x30(%rsp), %rdi
    4f80:      	movq	0x28(%rsp), %r8
    4f85:      	movq	0x20(%rsp), %r9
    4f8a:      	movq	0x18(%rsp), %r11
    4f8f:      	je	0x4d6f <generic_uprobe_process_filter+0x161f>
    4f95:      	addq	$0x10, %rsi
    4f99:      	movl	$0x1, %eax
    4f9e:      	movq	(%rip), %rcx            # 0x4fa5 <generic_uprobe_process_filter+0x1855>
    4fa5:      	jmp	0x5184 <generic_uprobe_process_filter+0x1a34>
    4faa:      	movl	$0x4, %esi
    4faf:      	xorl	%edx, %edx
    4fb1:      	divq	%rsi
    4fb4:      	andl	$0x3ff, %eax            # imm = 0x3FF
    4fb9:      	movl	(%r10,%rax,4), %r15d
    4fbd:      	testb	$0x2, %dil
    4fc1:      	jne	0x4db0 <generic_uprobe_process_filter+0x1660>
    4fc7:      	cmpl	$0x5, %r12d
    4fcb:      	jne	0x4fd6 <generic_uprobe_process_filter+0x1886>
    4fcd:      	cmpq	%rcx, %r15
    4fd0:      	jne	0x51b7 <generic_uprobe_process_filter+0x1a67>
    4fd6:      	cmpq	%rcx, %r15
    4fd9:      	setne	%al
    4fdc:      	cmpl	$0x6, %r12d
    4fe0:      	setne	%bl
    4fe3:      	jmp	0x4d79 <generic_uprobe_process_filter+0x1629>
    4fe8:      	movq	0xb0(%rsp), %rax
    4ff0:      	movl	(%rax), %eax
    4ff2:      	testq	%rax, %rax
    4ff5:      	je	0x51b7 <generic_uprobe_process_filter+0x1a67>
    4ffb:      	movb	$0x1, %bl
    4ffd:      	testq	%r15, %r15
    5000:      	je	0x4d6f <generic_uprobe_process_filter+0x161f>
    5006:      	cmpq	%rax, %r15
    5009:      	je	0x4d6f <generic_uprobe_process_filter+0x161f>
    500f:      	movl	$0x1, %eax
    5014:      	movq	0xd0(%rsp), %rsi
    501c:      	movq	(%rip), %rdi            # 0x5023 <generic_uprobe_process_filter+0x18d3>
    5023:      	callq	*%rax
    5025:      	testq	%rax, %rax
    5028:      	je	0x518d <generic_uprobe_process_filter+0x1a3d>
    502e:      	movq	%rax, %rsi
    5031:      	movl	0x24(%rax), %eax
    5034:      	cmpq	%rax, %r15
    5037:      	je	0x4d56 <generic_uprobe_process_filter+0x1606>
    503d:      	addq	$0x10, %rsi
    5041:      	movl	$0x1, %eax
    5046:      	movq	(%rip), %rdi            # 0x504d <generic_uprobe_process_filter+0x18fd>
    504d:      	callq	*%rax
    504f:      	testq	%rax, %rax
    5052:      	je	0x518d <generic_uprobe_process_filter+0x1a3d>
    5058:      	movq	%rax, %rsi
    505b:      	movl	0x24(%rax), %eax
    505e:      	cmpq	%rax, %r15
    5061:      	je	0x4d56 <generic_uprobe_process_filter+0x1606>
    5067:      	addq	$0x10, %rsi
    506b:      	movl	$0x1, %eax
    5070:      	movq	(%rip), %rdi            # 0x5077 <generic_uprobe_process_filter+0x1927>
    5077:      	callq	*%rax
    5079:      	testq	%rax, %rax
    507c:      	je	0x518d <generic_uprobe_process_filter+0x1a3d>
    5082:      	movq	%rax, %rsi
    5085:      	movl	0x24(%rax), %eax
    5088:      	cmpq	%rax, %r15
    508b:      	je	0x4d56 <generic_uprobe_process_filter+0x1606>
    5091:      	addq	$0x10, %rsi
    5095:      	movl	$0x1, %eax
    509a:      	movq	(%rip), %rdi            # 0x50a1 <generic_uprobe_process_filter+0x1951>
    50a1:      	callq	*%rax
    50a3:      	testq	%rax, %rax
    50a6:      	je	0x518d <generic_uprobe_process_filter+0x1a3d>
    50ac:      	movq	%rax, %rsi
    50af:      	movl	0x24(%rax), %eax
    50b2:      	cmpq	%rax, %r15
    50b5:      	je	0x4d56 <generic_uprobe_process_filter+0x1606>
    50bb:      	addq	$0x10, %rsi
    50bf:      	movl	$0x1, %eax
    50c4:      	movq	(%rip), %rdi            # 0x50cb <generic_uprobe_process_filter+0x197b>
    50cb:      	callq	*%rax
    50cd:      	testq	%rax, %rax
    50d0:      	je	0x518d <generic_uprobe_process_filter+0x1a3d>
    50d6:      	movq	%rax, %rsi
    50d9:      	movl	0x24(%rax), %eax
    50dc:      	cmpq	%rax, %r15
    50df:      	je	0x4d56 <generic_uprobe_process_filter+0x1606>
    50e5:      	addq	$0x10, %rsi
    50e9:      	movl	$0x1, %eax
    50ee:      	movq	(%rip), %rdi            # 0x50f5 <generic_uprobe_process_filter+0x19a5>
    50f5:      	callq	*%rax
    50f7:      	testq	%rax, %rax
    50fa:      	je	0x518d <generic_uprobe_process_filter+0x1a3d>
    5100:      	movq	%rax, %rsi
    5103:      	movl	0x24(%rax), %eax
    5106:      	cmpq	%rax, %r15
    5109:      	je	0x4d56 <generic_uprobe_process_filter+0x1606>
    510f:      	addq	$0x10, %rsi
    5113:      	movl	$0x1, %eax
    5118:      	movq	(%rip), %rdi            # 0x511f <generic_uprobe_process_filter+0x19cf>
    511f:      	callq	*%rax
    5121:      	testq	%rax, %rax
    5124:      	je	0x518d <generic_uprobe_process_filter+0x1a3d>
    5126:      	movq	%rax, %rsi
    5129:      	movl	0x24(%rax), %eax
    512c:      	cmpq	%rax, %r15
    512f:      	je	0x4d56 <generic_uprobe_process_filter+0x1606>
    5135:      	addq	$0x10, %rsi
    5139:      	movl	$0x1, %eax
    513e:      	movq	(%rip), %rdi            # 0x5145 <generic_uprobe_process_filter+0x19f5>
    5145:      	callq	*%rax
    5147:      	testq	%rax, %rax
    514a:      	je	0x518d <generic_uprobe_process_filter+0x1a3d>
    514c:      	movq	%rax, %rsi
    514f:      	movl	0x24(%rax), %eax
    5152:      	cmpq	%rax, %r15
    5155:      	movq	0x8(%rsp), %r10
    515a:      	movq	0x30(%rsp), %rdi
    515f:      	movq	0x28(%rsp), %r8
    5164:      	movq	0x20(%rsp), %r9
    5169:      	movq	0x18(%rsp), %r11
    516e:      	je	0x4d6f <generic_uprobe_process_filter+0x161f>
    5174:      	addq	$0x10, %rsi
    5178:      	movl	$0x1, %eax
    517d:      	movq	(%rip), %rcx            # 0x5184 <generic_uprobe_process_filter+0x1a34>
    5184:      	movq	(%rip), %rdi            # 0x518b <generic_uprobe_process_filter+0x1a3b>
    518b:      	callq	*%rax
    518d:      	xorl	%ebx, %ebx
    518f:      	cmpl	$0x5, %r12d
    5193:      	movq	0x8(%rsp), %r10
    5198:      	movq	0x30(%rsp), %rdi
    519d:      	movq	0x28(%rsp), %r8
    51a2:      	movq	0x20(%rsp), %r9
    51a7:      	movq	0x18(%rsp), %r11
    51ac:      	jne	0x4d6f <generic_uprobe_process_filter+0x161f>
    51b2:      	jmp	0x4d7b <generic_uprobe_process_filter+0x162b>
    51b7:      	xorl	%ebx, %ebx
    51b9:      	jmp	0x4d7b <generic_uprobe_process_filter+0x162b>
    51be:      	movl	$0x1, %eax
    51c3:      	jmp	0x5201 <generic_uprobe_process_filter+0x1ab1>
    51c5:      	movl	0x60(%rsp), %esi
    51c9:      	movl	0x64(%rsp), %ecx
    51cd:      	movl	0x68(%rsp), %eax
    51d1:      	movl	0x6c(%rsp), %edx
    51d5:      	cmpl	$0x6, %r12d
    51d9:      	jne	0x51e3 <generic_uprobe_process_filter+0x1a93>
    51db:      	andl	%esi, %ecx
    51dd:      	andl	%edx, %eax
    51df:      	andl	%ecx, %eax
    51e1:      	jmp	0x51e9 <generic_uprobe_process_filter+0x1a99>
    51e3:      	orl	%esi, %ecx
    51e5:      	orl	%edx, %eax
    51e7:      	orl	%ecx, %eax
    51e9:      	testl	%eax, %eax
    51eb:      	je	0x5d1b <generic_uprobe_process_filter+0x25cb>
    51f1:      	addl	$0x14, %r14d
    51f5:      	movl	0x8(%r10,%rbp), %ecx
    51fa:      	andl	$0x7, %ecx
    51fd:      	leal	(%r14,%rcx,4), %ebp
    5201:      	movq	0x50(%rsp), %r9
    5206:      	movl	%ebp, %ecx
    5208:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    520e:      	movl	(%rcx,%r10), %ecx
    5212:      	addl	$0x4, %ebp
    5215:      	addl	$-0x4, %ecx
    5218:      	xorl	%esi, %esi
    521a:      	movl	$0x4, %r8d
    5220:      	jmp	0x523f <generic_uprobe_process_filter+0x1aef>
    5222:      	nopw	%cs:(%rax,%rax)
    5230:      	xorl	%ecx, %ecx
    5232:      	incq	%rsi
    5235:      	cmpq	$0xa, %rsi
    5239:      	je	0x53c8 <generic_uprobe_process_filter+0x1c78>
    523f:      	testl	%ecx, %ecx
    5241:      	je	0x5230 <generic_uprobe_process_filter+0x1ae0>
    5243:      	movl	%ebp, %r9d
    5246:      	andl	$0x3ff, %r9d            # imm = 0x3FF
    524d:      	movl	(%r9,%r10), %r11d
    5251:      	movq	%r10, %rax
    5254:      	movl	0x4(%r9,%r10), %r10d
    5259:      	movl	0x8(%r9,%rax), %edx
    525e:      	movq	$0x0, 0x68(%rsp)
    5267:      	movq	$0x0, 0x60(%rsp)
    5270:      	cmpl	$0x4, %edx
    5273:      	movl	$0x4, %eax
    5278:      	cmovbl	%edx, %eax
    527b:      	cmpl	$0x6, %r10d
    527f:      	jne	0x5295 <generic_uprobe_process_filter+0x1b45>
    5281:      	movabsq	$0x100000001, %rdi      # imm = 0x100000001
    528b:      	movq	%rdi, 0x60(%rsp)
    5290:      	movq	%rdi, 0x68(%rsp)
    5295:      	addl	$0xc, %ebp
    5298:      	testl	%edx, %edx
    529a:      	je	0x5370 <generic_uprobe_process_filter+0x1c20>
    52a0:      	andl	$0xf, %r11d
    52a4:      	decq	%rax
    52a7:      	cmpq	$0x3, %rax
    52ab:      	movl	$0x3, %edx
    52b0:      	cmovaeq	%rdx, %rax
    52b4:      	leaq	0x4(,%rax,4), %rbx
    52bc:      	movl	%ebp, %r14d
    52bf:      	cmpl	$0x9, %r11d
    52c3:      	jbe	0x52fa <generic_uprobe_process_filter+0x1baa>
    52c5:      	xorl	%r11d, %r11d
    52c8:      	jmp	0x52e6 <generic_uprobe_process_filter+0x1b96>
    52ca:      	nopw	(%rax,%rax)
    52d0:      	movl	$0x0, 0x60(%rsp,%r11)
    52d9:      	addq	$0x4, %r11
    52dd:      	cmpq	%r11, %rbx
    52e0:      	je	0x5370 <generic_uprobe_process_filter+0x1c20>
    52e6:      	leaq	(%r14,%r11), %rax
    52ea:      	cmpl	$0x3e8, %eax            # imm = 0x3E8
    52ef:      	ja	0x52d0 <generic_uprobe_process_filter+0x1b80>
    52f1:      	movl	%eax, %eax
    52f3:      	xorl	%edx, %edx
    52f5:      	divq	%r8
    52f8:      	jmp	0x52d0 <generic_uprobe_process_filter+0x1b80>
    52fa:      	xorl	%r15d, %r15d
    52fd:      	jmp	0x5341 <generic_uprobe_process_filter+0x1bf1>
    52ff:      	nop
    5300:      	cmpl	$0x5, %r10d
    5304:      	setne	%dl
    5307:      	movl	%r10d, %r13d
    530a:      	xorl	$0x6, %r13d
    530e:      	movq	0x50(%rsp), %rax
    5313:      	movl	0x20(%rax,%r11,4), %edi
    5318:      	movl	%r12d, %eax
    531b:      	xorl	%edi, %eax
    531d:      	cmpl	%edi, %r12d
    5320:      	sete	%dil
    5324:      	orb	%dl, %dil
    5327:      	orl	%r13d, %eax
    532a:      	setne	%al
    532d:      	andb	%dil, %al
    5330:      	movzbl	%al, %eax
    5333:      	movl	%eax, 0x60(%rsp,%r15)
    5338:      	addq	$0x4, %r15
    533c:      	cmpq	%r15, %rbx
    533f:      	je	0x5370 <generic_uprobe_process_filter+0x1c20>
    5341:      	leaq	(%r14,%r15), %rdx
    5345:      	xorl	%r12d, %r12d
    5348:      	cmpl	$0x3e8, %edx            # imm = 0x3E8
    534e:      	ja	0x5300 <generic_uprobe_process_filter+0x1bb0>
    5350:      	movl	%edx, %eax
    5352:      	xorl	%edx, %edx
    5354:      	divq	%r8
    5357:      	andl	$0x3ff, %eax            # imm = 0x3FF
    535c:      	movq	0x8(%rsp), %rdx
    5361:      	movl	(%rdx,%rax,4), %r12d
    5365:      	jmp	0x5300 <generic_uprobe_process_filter+0x1bb0>
    5367:      	nopw	(%rax,%rax)
    5370:      	movl	0x60(%rsp), %ebx
    5374:      	movl	0x64(%rsp), %edx
    5378:      	movl	0x68(%rsp), %eax
    537c:      	movl	0x6c(%rsp), %r11d
    5381:      	cmpl	$0x6, %r10d
    5385:      	jne	0x5390 <generic_uprobe_process_filter+0x1c40>
    5387:      	andl	%ebx, %edx
    5389:      	andl	%r11d, %eax
    538c:      	andl	%edx, %eax
    538e:      	jmp	0x5397 <generic_uprobe_process_filter+0x1c47>
    5390:      	orl	%ebx, %edx
    5392:      	orl	%r11d, %eax
    5395:      	orl	%edx, %eax
    5397:      	movq	0x8(%rsp), %r10
    539c:      	testl	%eax, %eax
    539e:      	je	0x5d1b <generic_uprobe_process_filter+0x25cb>
    53a4:      	movl	0x8(%r10,%r9), %edx
    53a9:      	shll	$0x2, %edx
    53ac:      	subl	%edx, %ecx
    53ae:      	andl	$0x1c, %edx
    53b1:      	addl	%edx, %ebp
    53b3:      	addl	$-0xc, %ecx
    53b6:      	movq	0x50(%rsp), %r9
    53bb:      	incq	%rsi
    53be:      	cmpq	$0xa, %rsi
    53c2:      	jne	0x523f <generic_uprobe_process_filter+0x1aef>
    53c8:      	movl	%ebp, %ecx
    53ca:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    53d0:      	leal	0x4(%rbp), %ebx
    53d3:      	cmpl	$0x4, (%rcx,%r10)
    53d8:      	je	0x55a8 <generic_uprobe_process_filter+0x1e58>
    53de:      	andl	$0x3ff, %ebx            # imm = 0x3FF
    53e4:      	movl	(%rbx,%r10), %ecx
    53e8:      	movl	0x4(%rbx,%r10), %edx
    53ed:      	movl	0x8(%rbx,%r10), %edi
    53f2:      	movq	0xc(%rbx,%r10), %rax
    53f7:      	testl	%edi, %edi
    53f9:      	je	0x557c <generic_uprobe_process_filter+0x1e2c>
    53ff:      	xorl	%esi, %esi
    5401:      	cmpl	$0x2, %ecx
    5404:      	ja	0x559f <generic_uprobe_process_filter+0x1e4f>
    540a:      	cmpl	%edi, 0x44(%r9)
    540e:      	jne	0x5585 <generic_uprobe_process_filter+0x1e35>
    5414:      	jmp	0x559f <generic_uprobe_process_filter+0x1e4f>
    5419:      	movq	%rbx, %rsi
    541c:      	addq	$0x4, %rsi
    5420:      	movq	(%rip), %rdi            # 0x5427 <generic_uprobe_process_filter+0x1cd7>
    5427:      	movl	$0x1, %eax
    542c:      	callq	*%rax
    542e:      	testq	%rax, %rax
    5431:      	je	0x5d1b <generic_uprobe_process_filter+0x25cb>
    5437:      	movq	%rax, %r14
    543a:      	movq	(%rip), %rdi            # 0x5441 <generic_uprobe_process_filter+0x1cf1>
    5441:      	leaq	0x58(%rsp), %rsi
    5446:      	movl	$0x1, %eax
    544b:      	callq	*%rax
    544d:      	testq	%rax, %rax
    5450:      	je	0x5d1b <generic_uprobe_process_filter+0x25cb>
    5456:      	movq	%rax, %rbp
    5459:      	movl	$0x104, %edx            # imm = 0x104
    545e:      	movq	%rax, %rdi
    5461:      	xorl	%esi, %esi
    5463:      	callq	0x5468 <generic_uprobe_process_filter+0x1d18>
    5468:      	movq	0x38(%rsp), %rsi
    546d:      	movl	0x68(%rsi), %eax
    5470:      	leal	(,%rax,8), %ecx
    5477:      	movl	%ecx, (%rbp)
    547a:      	movq	%rbp, %rdi
    547d:      	addq	$0x4, %rdi
    5481:      	movzbl	%al, %ecx
    5484:      	leaq	0x70(%rsi), %rdx
    5488:      	movl	$0x4, %eax
    548d:      	movzbl	0x68(%rsi), %esi
    5491:      	callq	*%rax
    5493:      	testq	%rax, %rax
    5496:      	js	0x5d1b <generic_uprobe_process_filter+0x25cb>
    549c:      	movl	$0x1, %eax
    54a1:      	movq	%r14, %rdi
    54a4:      	movq	%rbp, %rsi
    54a7:      	jmp	0x58a7 <generic_uprobe_process_filter+0x2157>
    54ac:      	movl	$0x0, 0x40(%rsp)
    54b4:      	movq	(%rip), %rdi            # 0x54bb <generic_uprobe_process_filter+0x1d6b>
    54bb:      	leaq	0x40(%rsp), %rsi
    54c0:      	movl	$0x1, %eax
    54c5:      	callq	*%rax
    54c7:      	testq	%rax, %rax
    54ca:      	movq	0x38(%rsp), %rdx
    54cf:      	je	0x5854 <generic_uprobe_process_filter+0x2104>
    54d5:      	movq	(%rax), %rcx
    54d8:      	cmpq	0x378(%rdx), %rcx
    54df:      	je	0x5854 <generic_uprobe_process_filter+0x2104>
    54e5:      	movq	%rax, 0xb0(%rsp)
    54ed:      	movq	(%rip), %rax            # 0x54f4 <generic_uprobe_process_filter+0x1da4>
    54f4:      	cmpb	$0x0, (%rax)
    54f7:      	je	0x57cb <generic_uprobe_process_filter+0x207b>
    54fd:      	movl	$0x1869f, %r15d         # imm = 0x1869F
    5503:      	xorl	%r14d, %r14d
    5506:      	movq	(%rip), %r12            # 0x550d <generic_uprobe_process_filter+0x1dbd>
    550d:      	movq	0x38(%rsp), %rax
    5512:      	movl	0x10(%rax), %eax
    5515:      	movl	%eax, 0x60(%rsp)
    5519:      	movl	$0x1, %eax
    551e:      	leaq	0x60(%rsp), %rsi
    5523:      	movq	%r12, %rdi
    5526:      	callq	*%rax
    5528:      	testq	%rax, %rax
    552b:      	je	0x583d <generic_uprobe_process_filter+0x20ed>
    5531:      	movq	%rax, %rbp
    5534:      	leaq	0x70(%rax), %rsi
    5538:      	movl	$0x1, %eax
    553d:      	movq	(%rip), %rdi            # 0x5544 <generic_uprobe_process_filter+0x1df4>
    5544:      	callq	*%rax
    5546:      	testq	%rax, %rax
    5549:      	je	0x5560 <generic_uprobe_process_filter+0x1e10>
    554b:      	movq	(%rax), %rax
    554e:      	testq	%rax, %rax
    5551:      	je	0x5560 <generic_uprobe_process_filter+0x1e10>
    5553:      	movq	0x38(%rsp), %rcx
    5558:      	lock
    5559:      	orq	%rax, 0x370(%rcx)
    5560:      	subl	$0x1, %r15d
    5564:      	setb	%al
    5567:      	cmpq	%r14, %rbp
    556a:      	je	0x583d <generic_uprobe_process_filter+0x20ed>
    5570:      	movq	%rbp, %r14
    5573:      	testb	%al, %al
    5575:      	je	0x550d <generic_uprobe_process_filter+0x1dbd>
    5577:      	jmp	0x583d <generic_uprobe_process_filter+0x20ed>
    557c:      	cmpl	$0x2, %ecx
    557f:      	jbe	0x5585 <generic_uprobe_process_filter+0x1e35>
    5581:      	xorl	%esi, %esi
    5583:      	jmp	0x559f <generic_uprobe_process_filter+0x1e4f>
    5585:      	andq	0x48(%r9,%rcx,8), %rax
    558a:      	cmpl	$0x5, %edx
    558d:      	jne	0x5598 <generic_uprobe_process_filter+0x1e48>
    558f:      	testq	%rax, %rax
    5592:      	setne	%sil
    5596:      	jmp	0x559f <generic_uprobe_process_filter+0x1e4f>
    5598:      	testq	%rax, %rax
    559b:      	sete	%sil
    559f:      	addl	$0x18, %ebp
    55a2:      	movzbl	%sil, %eax
    55a6:      	movl	%ebp, %ebx
    55a8:      	testl	%eax, %eax
    55aa:      	je	0x5d1b <generic_uprobe_process_filter+0x25cb>
    55b0:      	movl	%ebx, %ecx
    55b2:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    55b8:      	leal	0x4(%rbx), %eax
    55bb:      	cmpl	$0x4, (%rcx,%r10)
    55c0:      	je	0x5c23 <generic_uprobe_process_filter+0x24d3>
    55c6:      	andl	$0x3ff, %eax            # imm = 0x3FF
    55cb:      	movl	(%rax,%r10), %r14d
    55cf:      	movl	0x4(%rax,%r10), %ebp
    55d4:      	movl	$0xe, %eax
    55d9:      	callq	*%rax
    55db:      	shrq	$0x20, %rax
    55df:      	movl	%eax, 0x60(%rsp)
    55e3:      	movq	(%rip), %rdi            # 0x55ea <generic_uprobe_process_filter+0x1e9a>
    55ea:      	leaq	0x60(%rsp), %rsi
    55ef:      	movl	$0x1, %eax
    55f4:      	callq	*%rax
    55f6:      	movq	0x8(%rsp), %r10
    55fb:      	testq	%rax, %rax
    55fe:      	je	0x5d1b <generic_uprobe_process_filter+0x25cb>
    5604:      	cmpl	$0x5, %r14d
    5608:      	je	0x5646 <generic_uprobe_process_filter+0x1ef6>
    560a:      	cmpl	$0x6, %r14d
    560e:      	jne	0x5d1b <generic_uprobe_process_filter+0x25cb>
    5614:      	movq	0x50(%rsp), %rsi
    5619:      	movq	%rsi, %rcx
    561c:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    5623:      	testb	$0x1, %bpl
    5627:      	jne	0x58e9 <generic_uprobe_process_filter+0x2199>
    562d:      	movl	0x28(%rax), %edx
    5630:      	testl	%edx, %edx
    5632:      	je	0x58e2 <generic_uprobe_process_filter+0x2192>
    5638:      	cmpl	0x20(%rsi), %edx
    563b:      	je	0x58e9 <generic_uprobe_process_filter+0x2199>
    5641:      	jmp	0x5c17 <generic_uprobe_process_filter+0x24c7>
    5646:      	movq	0x50(%rsp), %rsi
    564b:      	movq	%rsi, %rcx
    564e:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    5655:      	testb	$0x1, %bpl
    5659:      	je	0x5907 <generic_uprobe_process_filter+0x21b7>
    565f:      	movl	0x28(%rax), %edx
    5662:      	testl	%edx, %edx
    5664:      	je	0x5900 <generic_uprobe_process_filter+0x21b0>
    566a:      	cmpl	0x20(%rsi), %edx
    566d:      	je	0x5907 <generic_uprobe_process_filter+0x21b7>
    5673:      	jmp	0x5c17 <generic_uprobe_process_filter+0x24c7>
    5678:      	movq	%r12, %rsi
    567b:      	addq	$0x4, %rsi
    567f:      	movq	(%rip), %rdi            # 0x5686 <generic_uprobe_process_filter+0x1f36>
    5686:      	movl	$0x1, %eax
    568b:      	callq	*%rax
    568d:      	testq	%rax, %rax
    5690:      	je	0x5d1b <generic_uprobe_process_filter+0x25cb>
    5696:      	movq	%rax, %r14
    5699:      	movq	(%rip), %rdi            # 0x56a0 <generic_uprobe_process_filter+0x1f50>
    56a0:      	leaq	0x58(%rsp), %rsi
    56a5:      	movl	$0x1, %eax
    56aa:      	callq	*%rax
    56ac:      	testq	%rax, %rax
    56af:      	je	0x5d1b <generic_uprobe_process_filter+0x25cb>
    56b5:      	movq	%rax, %rbx
    56b8:      	movl	$0x104, %edx            # imm = 0x104
    56bd:      	movq	%rax, %rdi
    56c0:      	xorl	%esi, %esi
    56c2:      	callq	0x56c7 <generic_uprobe_process_filter+0x1f77>
    56c7:      	movl	(%rbp), %eax
    56ca:      	leal	(,%rax,8), %ecx
    56d1:      	movl	%ecx, (%rbx)
    56d3:      	movq	%rbx, %rdi
    56d6:      	addq	$0x4, %rdi
    56da:      	movzbl	%al, %ecx
    56dd:      	movq	%rbp, %rdx
    56e0:      	addq	$0x8, %rdx
    56e4:      	movl	$0x4, %eax
    56e9:      	movzbl	(%rbp), %esi
    56ed:      	callq	*%rax
    56ef:      	testq	%rax, %rax
    56f2:      	js	0x5d1b <generic_uprobe_process_filter+0x25cb>
    56f8:      	movl	$0x1, %eax
    56fd:      	movq	%r14, %rdi
    5700:      	movq	%rbx, %rsi
    5703:      	jmp	0x5a7d <generic_uprobe_process_filter+0x232d>
    5708:      	movl	$0x0, 0x40(%rsp)
    5710:      	movq	(%rip), %rdi            # 0x5717 <generic_uprobe_process_filter+0x1fc7>
    5717:      	leaq	0x40(%rsp), %rsi
    571c:      	movl	$0x1, %eax
    5721:      	callq	*%rax
    5723:      	testq	%rax, %rax
    5726:      	je	0x5a2a <generic_uprobe_process_filter+0x22da>
    572c:      	movq	(%rax), %rcx
    572f:      	cmpq	0x310(%rbp), %rcx
    5736:      	je	0x5a2a <generic_uprobe_process_filter+0x22da>
    573c:      	movq	%rax, 0xb0(%rsp)
    5744:      	movq	(%rip), %rax            # 0x574b <generic_uprobe_process_filter+0x1ffb>
    574b:      	cmpb	$0x0, (%rax)
    574e:      	je	0x59ae <generic_uprobe_process_filter+0x225e>
    5754:      	movl	$0x1869f, %r15d         # imm = 0x1869F
    575a:      	xorl	%r14d, %r14d
    575d:      	movq	0x38(%rsp), %rax
    5762:      	movl	0x10(%rax), %eax
    5765:      	movl	%eax, 0x60(%rsp)
    5769:      	movl	$0x1, %eax
    576e:      	movq	(%rip), %rdi            # 0x5775 <generic_uprobe_process_filter+0x2025>
    5775:      	leaq	0x60(%rsp), %rsi
    577a:      	callq	*%rax
    577c:      	testq	%rax, %rax
    577f:      	je	0x5a18 <generic_uprobe_process_filter+0x22c8>
    5785:      	movq	%rax, %rbx
    5788:      	leaq	0x70(%rax), %rsi
    578c:      	movl	$0x1, %eax
    5791:      	movq	(%rip), %rdi            # 0x5798 <generic_uprobe_process_filter+0x2048>
    5798:      	callq	*%rax
    579a:      	testq	%rax, %rax
    579d:      	je	0x57af <generic_uprobe_process_filter+0x205f>
    579f:      	movq	(%rax), %rax
    57a2:      	testq	%rax, %rax
    57a5:      	je	0x57af <generic_uprobe_process_filter+0x205f>
    57a7:      	lock
    57a8:      	orq	%rax, 0x308(%rbp)
    57af:      	subl	$0x1, %r15d
    57b3:      	setb	%al
    57b6:      	cmpq	%r14, %rbx
    57b9:      	je	0x5a18 <generic_uprobe_process_filter+0x22c8>
    57bf:      	movq	%rbx, %r14
    57c2:      	testb	%al, %al
    57c4:      	je	0x575d <generic_uprobe_process_filter+0x200d>
    57c6:      	jmp	0x5a18 <generic_uprobe_process_filter+0x22c8>
    57cb:      	movl	$0x3ff, %r15d           # imm = 0x3FF
    57d1:      	xorl	%r14d, %r14d
    57d4:      	movq	(%rip), %r12            # 0x57db <generic_uprobe_process_filter+0x208b>
    57db:      	movq	0x38(%rsp), %rax
    57e0:      	movl	0x10(%rax), %eax
    57e3:      	movl	%eax, 0x60(%rsp)
    57e7:      	movl	$0x1, %eax
    57ec:      	leaq	0x60(%rsp), %rsi
    57f1:      	movq	%r12, %rdi
    57f4:      	callq	*%rax
    57f6:      	testq	%rax, %rax
    57f9:      	je	0x583d <generic_uprobe_process_filter+0x20ed>
    57fb:      	movq	%rax, %rbp
    57fe:      	leaq	0x70(%rax), %rsi
    5802:      	movl	$0x1, %eax
    5807:      	movq	(%rip), %rdi            # 0x580e <generic_uprobe_process_filter+0x20be>
    580e:      	callq	*%rax
    5810:      	testq	%rax, %rax
    5813:      	je	0x582a <generic_uprobe_process_filter+0x20da>
    5815:      	movq	(%rax), %rax
    5818:      	testq	%rax, %rax
    581b:      	je	0x582a <generic_uprobe_process_filter+0x20da>
    581d:      	movq	0x38(%rsp), %rcx
    5822:      	lock
    5823:      	orq	%rax, 0x370(%rcx)
    582a:      	subl	$0x1, %r15d
    582e:      	setb	%al
    5831:      	cmpq	%r14, %rbp
    5834:      	je	0x583d <generic_uprobe_process_filter+0x20ed>
    5836:      	movq	%rbp, %r14
    5839:      	testb	%al, %al
    583b:      	je	0x57db <generic_uprobe_process_filter+0x208b>
    583d:      	movq	0xb0(%rsp), %rax
    5845:      	movq	(%rax), %rax
    5848:      	movq	0x38(%rsp), %rdx
    584d:      	movq	%rax, 0x378(%rdx)
    5854:      	movl	0x8(%rbx), %eax
    5857:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    585c:      	cmpq	%rcx, %rax
    585f:      	je	0x587a <generic_uprobe_process_filter+0x212a>
    5861:      	movq	0x370(%rdx), %rcx
    5868:      	btq	%rax, %rcx
    586c:      	jae	0x587a <generic_uprobe_process_filter+0x212a>
    586e:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    5878:      	jmp	0x58a9 <generic_uprobe_process_filter+0x2159>
    587a:      	movq	(%rip), %rdi            # 0x5881 <generic_uprobe_process_filter+0x2131>
    5881:      	leaq	0x10(%rsp), %rsi
    5886:      	movl	$0x1, %eax
    588b:      	callq	*%rax
    588d:      	testq	%rax, %rax
    5890:      	je	0x5d1b <generic_uprobe_process_filter+0x25cb>
    5896:      	movq	%rax, %rdi
    5899:      	movq	0x38(%rsp), %rax
    589e:      	leaq	0x70(%rax), %rsi
    58a2:      	movl	$0x1, %eax
    58a7:      	callq	*%rax
    58a9:      	movl	(%rbx), %ecx
    58ab:      	cmpq	$0x25, %rcx
    58af:      	movq	0x8(%rsp), %r10
    58b4:      	ja	0x58d4 <generic_uprobe_process_filter+0x2184>
    58b6:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    58c0:      	btq	%rcx, %rdx
    58c4:      	jae	0x58d4 <generic_uprobe_process_filter+0x2184>
    58c6:      	testq	%rax, %rax
    58c9:      	jne	0x5d1b <generic_uprobe_process_filter+0x25cb>
    58cf:      	jmp	0x4a19 <generic_uprobe_process_filter+0x12c9>
    58d4:      	testq	%rax, %rax
    58d7:      	jne	0x4a19 <generic_uprobe_process_filter+0x12c9>
    58dd:      	jmp	0x5d1b <generic_uprobe_process_filter+0x25cb>
    58e2:      	movq	$0x1, (%rcx)
    58e9:      	testb	$0x2, %bpl
    58ed:      	jne	0x5925 <generic_uprobe_process_filter+0x21d5>
    58ef:      	movl	0x2c(%rax), %edx
    58f2:      	testl	%edx, %edx
    58f4:      	je	0x591e <generic_uprobe_process_filter+0x21ce>
    58f6:      	cmpl	0x24(%rsi), %edx
    58f9:      	je	0x5925 <generic_uprobe_process_filter+0x21d5>
    58fb:      	jmp	0x5c17 <generic_uprobe_process_filter+0x24c7>
    5900:      	movq	$0x1, (%rcx)
    5907:      	testb	$0x2, %bpl
    590b:      	je	0x5943 <generic_uprobe_process_filter+0x21f3>
    590d:      	movl	0x2c(%rax), %edx
    5910:      	testl	%edx, %edx
    5912:      	je	0x593c <generic_uprobe_process_filter+0x21ec>
    5914:      	cmpl	0x24(%rsi), %edx
    5917:      	je	0x5943 <generic_uprobe_process_filter+0x21f3>
    5919:      	jmp	0x5c17 <generic_uprobe_process_filter+0x24c7>
    591e:      	movq	$0x1, (%rcx)
    5925:      	testb	$0x4, %bpl
    5929:      	jne	0x5961 <generic_uprobe_process_filter+0x2211>
    592b:      	movl	0x30(%rax), %edx
    592e:      	testl	%edx, %edx
    5930:      	je	0x595a <generic_uprobe_process_filter+0x220a>
    5932:      	cmpl	0x28(%rsi), %edx
    5935:      	je	0x5961 <generic_uprobe_process_filter+0x2211>
    5937:      	jmp	0x5c17 <generic_uprobe_process_filter+0x24c7>
    593c:      	movq	$0x1, (%rcx)
    5943:      	testb	$0x4, %bpl
    5947:      	je	0x598b <generic_uprobe_process_filter+0x223b>
    5949:      	movl	0x30(%rax), %edx
    594c:      	testl	%edx, %edx
    594e:      	je	0x5984 <generic_uprobe_process_filter+0x2234>
    5950:      	cmpl	0x28(%rsi), %edx
    5953:      	je	0x598b <generic_uprobe_process_filter+0x223b>
    5955:      	jmp	0x5c17 <generic_uprobe_process_filter+0x24c7>
    595a:      	movq	$0x1, (%rcx)
    5961:      	testb	$0x8, %bpl
    5965:      	jne	0x5ac1 <generic_uprobe_process_filter+0x2371>
    596b:      	movl	0x34(%rax), %edx
    596e:      	testl	%edx, %edx
    5970:      	je	0x5aba <generic_uprobe_process_filter+0x236a>
    5976:      	cmpl	0x2c(%rsi), %edx
    5979:      	je	0x5ac1 <generic_uprobe_process_filter+0x2371>
    597f:      	jmp	0x5c17 <generic_uprobe_process_filter+0x24c7>
    5984:      	movq	$0x1, (%rcx)
    598b:      	testb	$0x8, %bpl
    598f:      	je	0x5adf <generic_uprobe_process_filter+0x238f>
    5995:      	movl	0x34(%rax), %edx
    5998:      	testl	%edx, %edx
    599a:      	je	0x5ad8 <generic_uprobe_process_filter+0x2388>
    59a0:      	cmpl	0x2c(%rsi), %edx
    59a3:      	je	0x5adf <generic_uprobe_process_filter+0x238f>
    59a9:      	jmp	0x5c17 <generic_uprobe_process_filter+0x24c7>
    59ae:      	movl	$0x3ff, %r15d           # imm = 0x3FF
    59b4:      	xorl	%r14d, %r14d
    59b7:      	movq	0x38(%rsp), %rax
    59bc:      	movl	0x10(%rax), %eax
    59bf:      	movl	%eax, 0x60(%rsp)
    59c3:      	movl	$0x1, %eax
    59c8:      	movq	(%rip), %rdi            # 0x59cf <generic_uprobe_process_filter+0x227f>
    59cf:      	leaq	0x60(%rsp), %rsi
    59d4:      	callq	*%rax
    59d6:      	testq	%rax, %rax
    59d9:      	je	0x5a18 <generic_uprobe_process_filter+0x22c8>
    59db:      	movq	%rax, %rbx
    59de:      	leaq	0x70(%rax), %rsi
    59e2:      	movl	$0x1, %eax
    59e7:      	movq	(%rip), %rdi            # 0x59ee <generic_uprobe_process_filter+0x229e>
    59ee:      	callq	*%rax
    59f0:      	testq	%rax, %rax
    59f3:      	je	0x5a05 <generic_uprobe_process_filter+0x22b5>
    59f5:      	movq	(%rax), %rax
    59f8:      	testq	%rax, %rax
    59fb:      	je	0x5a05 <generic_uprobe_process_filter+0x22b5>
    59fd:      	lock
    59fe:      	orq	%rax, 0x308(%rbp)
    5a05:      	subl	$0x1, %r15d
    5a09:      	setb	%al
    5a0c:      	cmpq	%r14, %rbx
    5a0f:      	je	0x5a18 <generic_uprobe_process_filter+0x22c8>
    5a11:      	movq	%rbx, %r14
    5a14:      	testb	%al, %al
    5a16:      	je	0x59b7 <generic_uprobe_process_filter+0x2267>
    5a18:      	movq	0xb0(%rsp), %rax
    5a20:      	movq	(%rax), %rax
    5a23:      	movq	%rax, 0x310(%rbp)
    5a2a:      	movl	0x8(%r12), %eax
    5a2f:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    5a34:      	cmpq	%rcx, %rax
    5a37:      	je	0x5a52 <generic_uprobe_process_filter+0x2302>
    5a39:      	movq	0x308(%rbp), %rcx
    5a40:      	btq	%rax, %rcx
    5a44:      	jae	0x5a52 <generic_uprobe_process_filter+0x2302>
    5a46:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    5a50:      	jmp	0x5a7f <generic_uprobe_process_filter+0x232f>
    5a52:      	movq	(%rip), %rdi            # 0x5a59 <generic_uprobe_process_filter+0x2309>
    5a59:      	leaq	0x10(%rsp), %rsi
    5a5e:      	movl	$0x1, %eax
    5a63:      	callq	*%rax
    5a65:      	testq	%rax, %rax
    5a68:      	je	0x5d1b <generic_uprobe_process_filter+0x25cb>
    5a6e:      	movq	%rax, %rdi
    5a71:      	addq	$0x8, %rbp
    5a75:      	movl	$0x1, %eax
    5a7a:      	movq	%rbp, %rsi
    5a7d:      	callq	*%rax
    5a7f:      	movl	(%r12), %ecx
    5a83:      	cmpq	$0x25, %rcx
    5a87:      	movq	0x8(%rsp), %r10
    5a8c:      	ja	0x5aac <generic_uprobe_process_filter+0x235c>
    5a8e:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    5a98:      	btq	%rcx, %rdx
    5a9c:      	jae	0x5aac <generic_uprobe_process_filter+0x235c>
    5a9e:      	testq	%rax, %rax
    5aa1:      	jne	0x5d1b <generic_uprobe_process_filter+0x25cb>
    5aa7:      	jmp	0x4c65 <generic_uprobe_process_filter+0x1515>
    5aac:      	testq	%rax, %rax
    5aaf:      	jne	0x4c65 <generic_uprobe_process_filter+0x1515>
    5ab5:      	jmp	0x5d1b <generic_uprobe_process_filter+0x25cb>
    5aba:      	movq	$0x1, (%rcx)
    5ac1:      	testb	$0x10, %bpl
    5ac5:      	jne	0x5afd <generic_uprobe_process_filter+0x23ad>
    5ac7:      	movl	0x38(%rax), %edx
    5aca:      	testl	%edx, %edx
    5acc:      	je	0x5af6 <generic_uprobe_process_filter+0x23a6>
    5ace:      	cmpl	0x30(%rsi), %edx
    5ad1:      	je	0x5afd <generic_uprobe_process_filter+0x23ad>
    5ad3:      	jmp	0x5c17 <generic_uprobe_process_filter+0x24c7>
    5ad8:      	movq	$0x1, (%rcx)
    5adf:      	testb	$0x10, %bpl
    5ae3:      	je	0x5b1b <generic_uprobe_process_filter+0x23cb>
    5ae5:      	movl	0x38(%rax), %edx
    5ae8:      	testl	%edx, %edx
    5aea:      	je	0x5b14 <generic_uprobe_process_filter+0x23c4>
    5aec:      	cmpl	0x30(%rsi), %edx
    5aef:      	je	0x5b1b <generic_uprobe_process_filter+0x23cb>
    5af1:      	jmp	0x5c17 <generic_uprobe_process_filter+0x24c7>
    5af6:      	movq	$0x1, (%rcx)
    5afd:      	testb	$0x20, %bpl
    5b01:      	jne	0x5b39 <generic_uprobe_process_filter+0x23e9>
    5b03:      	movl	0x3c(%rax), %edx
    5b06:      	testl	%edx, %edx
    5b08:      	je	0x5b32 <generic_uprobe_process_filter+0x23e2>
    5b0a:      	cmpl	0x34(%rsi), %edx
    5b0d:      	je	0x5b39 <generic_uprobe_process_filter+0x23e9>
    5b0f:      	jmp	0x5c17 <generic_uprobe_process_filter+0x24c7>
    5b14:      	movq	$0x1, (%rcx)
    5b1b:      	testb	$0x20, %bpl
    5b1f:      	je	0x5b57 <generic_uprobe_process_filter+0x2407>
    5b21:      	movl	0x3c(%rax), %edx
    5b24:      	testl	%edx, %edx
    5b26:      	je	0x5b50 <generic_uprobe_process_filter+0x2400>
    5b28:      	cmpl	0x34(%rsi), %edx
    5b2b:      	je	0x5b57 <generic_uprobe_process_filter+0x2407>
    5b2d:      	jmp	0x5c17 <generic_uprobe_process_filter+0x24c7>
    5b32:      	movq	$0x1, (%rcx)
    5b39:      	testb	$0x40, %bpl
    5b3d:      	jne	0x5b75 <generic_uprobe_process_filter+0x2425>
    5b3f:      	movl	0x40(%rax), %edx
    5b42:      	testl	%edx, %edx
    5b44:      	je	0x5b6e <generic_uprobe_process_filter+0x241e>
    5b46:      	cmpl	0x38(%rsi), %edx
    5b49:      	je	0x5b75 <generic_uprobe_process_filter+0x2425>
    5b4b:      	jmp	0x5c17 <generic_uprobe_process_filter+0x24c7>
    5b50:      	movq	$0x1, (%rcx)
    5b57:      	testb	$0x40, %bpl
    5b5b:      	je	0x5b92 <generic_uprobe_process_filter+0x2442>
    5b5d:      	movl	0x40(%rax), %edx
    5b60:      	testl	%edx, %edx
    5b62:      	je	0x5b8b <generic_uprobe_process_filter+0x243b>
    5b64:      	cmpl	0x38(%rsi), %edx
    5b67:      	je	0x5b92 <generic_uprobe_process_filter+0x2442>
    5b69:      	jmp	0x5c17 <generic_uprobe_process_filter+0x24c7>
    5b6e:      	movq	$0x1, (%rcx)
    5b75:      	testb	%bpl, %bpl
    5b78:      	js	0x5bac <generic_uprobe_process_filter+0x245c>
    5b7a:      	movl	0x44(%rax), %edx
    5b7d:      	testl	%edx, %edx
    5b7f:      	je	0x5ba5 <generic_uprobe_process_filter+0x2455>
    5b81:      	cmpl	0x3c(%rsi), %edx
    5b84:      	je	0x5bac <generic_uprobe_process_filter+0x245c>
    5b86:      	jmp	0x5c17 <generic_uprobe_process_filter+0x24c7>
    5b8b:      	movq	$0x1, (%rcx)
    5b92:      	testb	%bpl, %bpl
    5b95:      	jns	0x5bc9 <generic_uprobe_process_filter+0x2479>
    5b97:      	movl	0x44(%rax), %edx
    5b9a:      	testl	%edx, %edx
    5b9c:      	je	0x5bc2 <generic_uprobe_process_filter+0x2472>
    5b9e:      	cmpl	0x3c(%rsi), %edx
    5ba1:      	je	0x5bc9 <generic_uprobe_process_filter+0x2479>
    5ba3:      	jmp	0x5c17 <generic_uprobe_process_filter+0x24c7>
    5ba5:      	movq	$0x1, (%rcx)
    5bac:      	testl	$0x100, %ebp            # imm = 0x100
    5bb2:      	jne	0x5bf2 <generic_uprobe_process_filter+0x24a2>
    5bb4:      	movl	0x48(%rax), %edx
    5bb7:      	testl	%edx, %edx
    5bb9:      	je	0x5beb <generic_uprobe_process_filter+0x249b>
    5bbb:      	cmpl	0x40(%rsi), %edx
    5bbe:      	je	0x5bf2 <generic_uprobe_process_filter+0x24a2>
    5bc0:      	jmp	0x5c17 <generic_uprobe_process_filter+0x24c7>
    5bc2:      	movq	$0x1, (%rcx)
    5bc9:      	testl	$0x100, %ebp            # imm = 0x100
    5bcf:      	je	0x5d01 <generic_uprobe_process_filter+0x25b1>
    5bd5:      	movl	0x48(%rax), %edx
    5bd8:      	testl	%edx, %edx
    5bda:      	je	0x5cfa <generic_uprobe_process_filter+0x25aa>
    5be0:      	cmpl	0x40(%rsi), %edx
    5be3:      	je	0x5d01 <generic_uprobe_process_filter+0x25b1>
    5be9:      	jmp	0x5c17 <generic_uprobe_process_filter+0x24c7>
    5beb:      	movq	$0x1, (%rcx)
    5bf2:      	testl	$0x200, %ebp            # imm = 0x200
    5bf8:      	jne	0x5d1b <generic_uprobe_process_filter+0x25cb>
    5bfe:      	movl	0x4c(%rax), %eax
    5c01:      	testl	%eax, %eax
    5c03:      	je	0x5d14 <generic_uprobe_process_filter+0x25c4>
    5c09:      	movq	0x50(%rsp), %rdx
    5c0e:      	cmpl	0x44(%rdx), %eax
    5c11:      	je	0x5d1b <generic_uprobe_process_filter+0x25cb>
    5c17:      	addl	$0xc, %ebx
    5c1a:      	movq	$0x1, (%rcx)
    5c21:      	movl	%ebx, %eax
    5c23:      	movl	%eax, %ecx
    5c25:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5c2b:      	cmpl	$0x4, (%rcx,%r10)
    5c30:      	movq	0x50(%rsp), %rcx
    5c35:      	jne	0x5c5c <generic_uprobe_process_filter+0x250c>
    5c37:      	movq	0x5eb8(%rcx), %rax
    5c3e:      	andl	$0x1f, %eax
    5c41:      	movb	$0x1, 0x5ec1(%rcx,%rax)
    5c49:      	movb	$0x1, 0x5ee0(%rcx)
    5c50:      	movb	$0x1, 0x5ec0(%rcx)
    5c57:      	jmp	0x5d1b <generic_uprobe_process_filter+0x25cb>
    5c5c:      	addl	$0x4, %eax
    5c5f:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5c64:      	movl	(%rax,%r10), %r14d
    5c68:      	movl	0x4(%rax,%r10), %ebx
    5c6d:      	movl	0x8(%rax,%r10), %ebp
    5c72:      	movq	0xc(%rax,%r10), %r15
    5c77:      	movl	$0xe, %eax
    5c7c:      	callq	*%rax
    5c7e:      	shrq	$0x20, %rax
    5c82:      	movl	%eax, 0x60(%rsp)
    5c86:      	movq	(%rip), %rdi            # 0x5c8d <generic_uprobe_process_filter+0x253d>
    5c8d:      	leaq	0x60(%rsp), %rsi
    5c92:      	movl	$0x1, %eax
    5c97:      	callq	*%rax
    5c99:      	testq	%rax, %rax
    5c9c:      	je	0x5d1b <generic_uprobe_process_filter+0x25cb>
    5c9e:      	testl	%ebp, %ebp
    5ca0:      	je	0x5cb4 <generic_uprobe_process_filter+0x2564>
    5ca2:      	cmpl	$0x2, %r14d
    5ca6:      	ja	0x5d1b <generic_uprobe_process_filter+0x25cb>
    5ca8:      	movq	0x50(%rsp), %rcx
    5cad:      	cmpl	%ebp, 0x44(%rcx)
    5cb0:      	jne	0x5cba <generic_uprobe_process_filter+0x256a>
    5cb2:      	jmp	0x5d1b <generic_uprobe_process_filter+0x25cb>
    5cb4:      	cmpl	$0x2, %r14d
    5cb8:      	ja	0x5d1b <generic_uprobe_process_filter+0x25cb>
    5cba:      	movq	0x50(%rax,%r14,8), %rax
    5cbf:      	movq	0x50(%rsp), %rcx
    5cc4:      	movq	0x48(%rcx,%r14,8), %rcx
    5cc9:      	movq	%rcx, %rdx
    5ccc:      	xorq	%rax, %rdx
    5ccf:      	testq	%r15, %rdx
    5cd2:      	je	0x5cdb <generic_uprobe_process_filter+0x258b>
    5cd4:      	cmpl	$0x5, %ebx
    5cd7:      	jne	0x5d1b <generic_uprobe_process_filter+0x25cb>
    5cd9:      	jmp	0x5ce5 <generic_uprobe_process_filter+0x2595>
    5cdb:      	cmpq	%rcx, %rax
    5cde:      	je	0x5d1b <generic_uprobe_process_filter+0x25cb>
    5ce0:      	cmpl	$0x6, %ebx
    5ce3:      	jne	0x5d1b <generic_uprobe_process_filter+0x25cb>
    5ce5:      	movq	0x50(%rsp), %rcx
    5cea:      	movq	$0x1, 0x5ef0(%rcx)
    5cf5:      	jmp	0x5c37 <generic_uprobe_process_filter+0x24e7>
    5cfa:      	movq	$0x1, (%rcx)
    5d01:      	testl	$0x200, %ebp            # imm = 0x200
    5d07:      	je	0x5d1b <generic_uprobe_process_filter+0x25cb>
    5d09:      	movl	0x4c(%rax), %eax
    5d0c:      	testl	%eax, %eax
    5d0e:      	jne	0x5c09 <generic_uprobe_process_filter+0x24b9>
    5d14:      	movq	$0x1, (%rcx)
    5d1b:      	movq	0x50(%rsp), %rcx
    5d20:      	movq	0x5eb8(%rcx), %rax
    5d27:      	incq	%rax
    5d2a:      	movq	%rax, 0x5eb8(%rcx)
    5d31:      	cmpq	0xc0(%rsp), %rax
    5d39:      	jbe	0x5d87 <generic_uprobe_process_filter+0x2637>
    5d3b:      	movq	0x38(%rsp), %rdx
    5d40:      	movl	(%rdx), %eax
    5d42:      	movl	%eax, 0x10(%rcx)
    5d45:      	movq	0x8(%rdx), %rax
    5d49:      	movq	%rax, 0x18(%rcx)
    5d4d:      	cmpb	$0x0, 0x5ec0(%rcx)
    5d54:      	movq	0xb8(%rsp), %rbx
    5d5c:      	je	0x5d73 <generic_uprobe_process_filter+0x2623>
    5d5e:      	movq	(%rip), %rsi            # 0x5d65 <generic_uprobe_process_filter+0x2615>
    5d65:      	xorl	%ecx, %ecx
    5d67:      	movl	$0xc, %eax
    5d6c:      	movq	%rbx, %rdi
    5d6f:      	xorl	%edx, %edx
    5d71:      	callq	*%rax
    5d73:      	xorl	%eax, %eax
    5d75:      	addq	$0xe8, %rsp
    5d7c:      	popq	%rbx
    5d7d:      	popq	%r12
    5d7f:      	popq	%r13
    5d81:      	popq	%r14
    5d83:      	popq	%r15
    5d85:      	popq	%rbp
    5d86:      	retq
    5d87:      	movq	(%rip), %rsi            # 0x5d8e <generic_uprobe_process_filter+0x263e>
    5d8e:      	movl	$0x2, %ecx
    5d93:      	movl	$0xc, %eax
    5d98:      	movq	0xb8(%rsp), %rdi
    5da0:      	movl	$0x2, %edx
    5da5:      	jmp	0x5d71 <generic_uprobe_process_filter+0x2621>
    5da7:      	nopw	(%rax,%rax)

0000000000005db0 <generic_uprobe_filter_arg>:
    5db0:      	pushq	%rbp
    5db1:      	pushq	%r15
    5db3:      	pushq	%r14
    5db5:      	pushq	%r13
    5db7:      	pushq	%r12
    5db9:      	pushq	%rbx
    5dba:      	subq	$0x28, %rsp
    5dbe:      	movq	%rdi, %rbx
    5dc1:      	movl	$0x0, 0xc(%rsp)
    5dc9:      	movq	(%rip), %rdi            # 0x5dd0 <generic_uprobe_filter_arg+0x20>
    5dd0:      	leaq	0xc(%rsp), %rsi
    5dd5:      	movl	$0x1, %eax
    5dda:      	callq	*%rax
    5ddc:      	testq	%rax, %rax
    5ddf:      	je	0x61ac <generic_uprobe_filter_arg+0x3fc>
    5de5:      	movq	%rax, %r14
    5de8:      	movl	0x5f00(%rax), %r12d
    5def:      	leaq	0x5ef8(%rax), %rsi
    5df6:      	movq	(%rip), %rdi            # 0x5dfd <generic_uprobe_filter_arg+0x4d>
    5dfd:      	movl	$0x1, %eax
    5e02:      	callq	*%rax
    5e04:      	testq	%rax, %rax
    5e07:      	je	0x6191 <generic_uprobe_filter_arg+0x3e1>
    5e0d:      	cmpb	$0x0, 0x5ee0(%r14)
    5e15:      	je	0x6191 <generic_uprobe_filter_arg+0x3e1>
    5e1b:      	movq	%rax, %r15
    5e1e:      	movl	%r12d, %eax
    5e21:      	andl	$0x7, %eax
    5e24:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
    5e2d:      	je	0x5ebc <generic_uprobe_filter_arg+0x10c>
    5e33:      	movl	%eax, %eax
    5e35:      	movl	0x4(%r15,%rax,4), %ecx
    5e3a:      	leaq	(%rcx,%rax,4), %rdx
    5e3e:      	addq	$0x4, %rdx
    5e42:      	leaq	(%rcx,%rax,4), %rax
    5e46:      	addq	$0x8, %rax
    5e4a:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5e4f:      	movl	(%rax,%r15), %eax
    5e53:      	addq	%rdx, %rax
    5e56:      	addq	$0x4, %rax
    5e5a:      	movl	%eax, %ecx
    5e5c:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5e62:      	movl	(%rcx,%r15), %ecx
    5e66:      	addq	%rax, %rcx
    5e69:      	movl	%ecx, %eax
    5e6b:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5e70:      	movl	(%rax,%r15), %eax
    5e74:      	addq	%rcx, %rax
    5e77:      	movl	%eax, %ecx
    5e79:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5e7f:      	movl	(%rcx,%r15), %ecx
    5e83:      	addq	%rax, %rcx
    5e86:      	movl	%ecx, %eax
    5e88:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5e8d:      	movl	(%rax,%r15), %ebp
    5e91:      	addq	%rcx, %rbp
    5e94:      	movl	%ebp, %eax
    5e96:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5e9b:      	movq	%rax, (%rsp)
    5e9f:      	cmpl	$0x19, (%r15,%rax)
    5ea4:      	jae	0x5f11 <generic_uprobe_filter_arg+0x161>
    5ea6:      	movq	(%rsp), %rax
    5eaa:      	cmpq	$0x1, %rax
    5eae:      	je	0x6191 <generic_uprobe_filter_arg+0x3e1>
    5eb4:      	testl	%eax, %eax
    5eb6:      	jne	0x616b <generic_uprobe_filter_arg+0x3bb>
    5ebc:      	cmpl	$0x1, %r12d
    5ec0:      	jg	0x5ee1 <generic_uprobe_filter_arg+0x131>
    5ec2:      	cmpl	$-0x1, %r12d
    5ec6:      	je	0x61bd <generic_uprobe_filter_arg+0x40d>
    5ecc:      	testl	%r12d, %r12d
    5ecf:      	je	0x61ca <generic_uprobe_filter_arg+0x41a>
    5ed5:      	cmpl	$0x1, %r12d
    5ed9:      	je	0x61da <generic_uprobe_filter_arg+0x42a>
    5edf:      	jmp	0x5eff <generic_uprobe_filter_arg+0x14f>
    5ee1:      	cmpl	$0x2, %r12d
    5ee5:      	je	0x61ea <generic_uprobe_filter_arg+0x43a>
    5eeb:      	cmpl	$0x3, %r12d
    5eef:      	je	0x61fa <generic_uprobe_filter_arg+0x44a>
    5ef5:      	cmpl	$0x4, %r12d
    5ef9:      	je	0x620a <generic_uprobe_filter_arg+0x45a>
    5eff:      	cmpl	$0x4, %r12d
    5f03:      	jg	0x623c <generic_uprobe_filter_arg+0x48c>
    5f09:      	incl	%r12d
    5f0c:      	jmp	0x621a <generic_uprobe_filter_arg+0x46a>
    5f11:      	movq	(%rsp), %rax
    5f15:      	addq	%r15, %rax
    5f18:      	movq	%rax, 0x10(%rsp)
    5f1d:      	movl	$0x1, %r13d
    5f23:      	nopw	%cs:(%rax,%rax)
    5f30:      	movq	0x10(%rsp), %rax
    5f35:      	movl	(%rax,%r13,4), %edi
    5f39:      	testl	$0x3ff, %edi            # imm = 0x3FF
    5f3f:      	je	0x5ea6 <generic_uprobe_filter_arg+0xf6>
    5f45:      	addl	%ebp, %edi
    5f47:      	andl	$0x3ff, %edi            # imm = 0x3FF
    5f4d:      	movl	0x4(%r15,%rdi), %ecx
    5f52:      	cmpl	$0x23, %ecx
    5f55:      	je	0x5ebc <generic_uprobe_filter_arg+0x10c>
    5f5b:      	addq	%r15, %rdi
    5f5e:      	movl	(%rdi), %eax
    5f60:      	cmpq	$0x4, %rax
    5f64:      	ja	0x5ebc <generic_uprobe_filter_arg+0x10c>
    5f6a:      	cmpl	$0x0, 0x5ea0(%r14,%rax,4)
    5f73:      	jne	0x5ebc <generic_uprobe_filter_arg+0x10c>
    5f79:      	movq	0x5e78(%r14,%rax,8), %rax
    5f81:      	andl	$0x7ff, %eax            # imm = 0x7FF
    5f86:      	leaq	(%r14,%rax), %rsi
    5f8a:      	addq	$0x90, %rsi
    5f91:      	movl	0xc(%rdi), %eax
    5f94:      	cmpl	$0x1b, %eax
    5f97:      	jle	0x5fb8 <generic_uprobe_filter_arg+0x208>
    5f99:      	cmpl	$0x25, %eax
    5f9c:      	jg	0x5fe8 <generic_uprobe_filter_arg+0x238>
    5f9e:      	leal	-0x1c(%rax), %edx
    5fa1:      	cmpl	$0x9, %edx
    5fa4:      	jb	0x602e <generic_uprobe_filter_arg+0x27e>
    5faa:      	cmpl	$0x25, %eax
    5fad:      	je	0x6111 <generic_uprobe_filter_arg+0x361>
    5fb3:      	jmp	0x6159 <generic_uprobe_filter_arg+0x3a9>
    5fb8:      	cmpl	$0x9, %eax
    5fbb:      	jle	0x600e <generic_uprobe_filter_arg+0x25e>
    5fbd:      	leal	-0xa(%rax), %edx
    5fc0:      	cmpl	$0x4, %edx
    5fc3:      	jb	0x602e <generic_uprobe_filter_arg+0x27e>
    5fc5:      	leal	-0xf(%rax), %ecx
    5fc8:      	cmpl	$0x2, %ecx
    5fcb:      	jb	0x6111 <generic_uprobe_filter_arg+0x361>
    5fd1:      	cmpl	$0x11, %eax
    5fd4:      	jne	0x6159 <generic_uprobe_filter_arg+0x3a9>
    5fda:      	addq	$0x4, %rsi
    5fde:      	callq	0x5fe3 <generic_uprobe_filter_arg+0x233>
    5fe3:      	jmp	0x6150 <generic_uprobe_filter_arg+0x3a0>
    5fe8:      	cmpl	$0x29, %eax
    5feb:      	jg	0x6100 <generic_uprobe_filter_arg+0x350>
    5ff1:      	leal	-0x26(%rax), %ecx
    5ff4:      	cmpl	$0x2, %ecx
    5ff7:      	jb	0x60bb <generic_uprobe_filter_arg+0x30b>
    5ffd:      	addl	$-0x28, %eax
    6000:      	cmpl	$0x2, %eax
    6003:      	jb	0x60b1 <generic_uprobe_filter_arg+0x301>
    6009:      	jmp	0x6159 <generic_uprobe_filter_arg+0x3a9>
    600e:      	cmpl	$0x4, %eax
    6011:      	jg	0x609e <generic_uprobe_filter_arg+0x2ee>
    6017:      	cmpl	$0x1, %eax
    601a:      	je	0x602e <generic_uprobe_filter_arg+0x27e>
    601c:      	cmpl	$0x2, %eax
    601f:      	je	0x612e <generic_uprobe_filter_arg+0x37e>
    6025:      	cmpl	$0x4, %eax
    6028:      	jne	0x6159 <generic_uprobe_filter_arg+0x3a9>
    602e:      	cmpl	$0xb, %eax
    6031:      	jle	0x607b <generic_uprobe_filter_arg+0x2cb>
    6033:      	cmpl	$0x24, %eax
    6036:      	ja	0x6118 <generic_uprobe_filter_arg+0x368>
    603c:      	movl	%eax, %edx
    603e:      	movabsq	$0x1e00000000, %r8      # imm = 0x1E00000000
    6048:      	btq	%rdx, %r8
    604c:      	jb	0x60c2 <generic_uprobe_filter_arg+0x312>
    604e:      	movl	$0x60000000, %ecx       # imm = 0x60000000
    6053:      	btq	%rdx, %rcx
    6057:      	jb	0x6127 <generic_uprobe_filter_arg+0x377>
    605d:      	movabsq	$0x180000000, %rcx      # imm = 0x180000000
    6067:      	btq	%rdx, %rcx
    606b:      	jae	0x6118 <generic_uprobe_filter_arg+0x368>
    6071:      	callq	0x6076 <generic_uprobe_filter_arg+0x2c6>
    6076:      	jmp	0x6150 <generic_uprobe_filter_arg+0x3a0>
    607b:      	leal	-0xa(%rax), %ecx
    607e:      	cmpl	$0x2, %ecx
    6081:      	jb	0x613f <generic_uprobe_filter_arg+0x38f>
    6087:      	cmpl	$0x1, %eax
    608a:      	je	0x6120 <generic_uprobe_filter_arg+0x370>
    6090:      	cmpl	$0x4, %eax
    6093:      	je	0x6120 <generic_uprobe_filter_arg+0x370>
    6099:      	jmp	0x6159 <generic_uprobe_filter_arg+0x3a9>
    609e:      	cmpl	$0x5, %eax
    60a1:      	je	0x60b1 <generic_uprobe_filter_arg+0x301>
    60a3:      	cmpl	$0x6, %eax
    60a6:      	je	0x60bb <generic_uprobe_filter_arg+0x30b>
    60a8:      	cmpl	$0x7, %eax
    60ab:      	jne	0x6159 <generic_uprobe_filter_arg+0x3a9>
    60b1:      	callq	0x60b6 <generic_uprobe_filter_arg+0x306>
    60b6:      	jmp	0x6150 <generic_uprobe_filter_arg+0x3a0>
    60bb:      	movl	$0x4, %edx
    60c0:      	jmp	0x6133 <generic_uprobe_filter_arg+0x383>
    60c2:      	cmpl	$0x1e, %ecx
    60c5:      	jne	0x613f <generic_uprobe_filter_arg+0x38f>
    60c7:      	movl	0x10(%rdi), %eax
    60ca:      	andl	$0x7, %eax
    60cd:      	movl	%eax, %ecx
    60cf:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    60d8:      	jne	0x5ebc <generic_uprobe_filter_arg+0x10c>
    60de:      	movq	(%rsi), %rcx
    60e1:      	movq	0x5e78(%r14,%rax,8), %rdx
    60e9:      	andl	$0x7ff, %edx            # imm = 0x7FF
    60ef:      	xorl	%eax, %eax
    60f1:      	andnq	0x90(%r14,%rdx), %rcx, %rcx
    60fb:      	setne	%al
    60fe:      	jmp	0x6150 <generic_uprobe_filter_arg+0x3a0>
    6100:      	cmpl	$0x2a, %eax
    6103:      	je	0x6111 <generic_uprobe_filter_arg+0x361>
    6105:      	cmpl	$0x2c, %eax
    6108:      	jne	0x6159 <generic_uprobe_filter_arg+0x3a9>
    610a:      	callq	0x610f <generic_uprobe_filter_arg+0x35f>
    610f:      	jmp	0x6150 <generic_uprobe_filter_arg+0x3a0>
    6111:      	callq	0x6116 <generic_uprobe_filter_arg+0x366>
    6116:      	jmp	0x6150 <generic_uprobe_filter_arg+0x3a0>
    6118:      	leal	-0xc(%rax), %ecx
    611b:      	cmpl	$0x2, %ecx
    611e:      	jae	0x613a <generic_uprobe_filter_arg+0x38a>
    6120:      	callq	0x6125 <generic_uprobe_filter_arg+0x375>
    6125:      	jmp	0x6150 <generic_uprobe_filter_arg+0x3a0>
    6127:      	callq	0x612c <generic_uprobe_filter_arg+0x37c>
    612c:      	jmp	0x6150 <generic_uprobe_filter_arg+0x3a0>
    612e:      	movl	$0x8, %edx
    6133:      	callq	0x6138 <generic_uprobe_filter_arg+0x388>
    6138:      	jmp	0x6150 <generic_uprobe_filter_arg+0x3a0>
    613a:      	cmpl	$0x1c, %eax
    613d:      	jne	0x6159 <generic_uprobe_filter_arg+0x3a9>
    613f:      	callq	0x6144 <generic_uprobe_filter_arg+0x394>
    6144:      	nopw	%cs:(%rax,%rax)
    6150:      	testq	%rax, %rax
    6153:      	je	0x5ebc <generic_uprobe_filter_arg+0x10c>
    6159:      	incq	%r13
    615c:      	cmpq	$0x6, %r13
    6160:      	jne	0x5f30 <generic_uprobe_filter_arg+0x180>
    6166:      	jmp	0x5ea6 <generic_uprobe_filter_arg+0xf6>
    616b:      	movq	(%rsp), %rax
    616f:      	movl	%eax, 0x5f04(%r14)
    6176:      	movq	(%rip), %rsi            # 0x617d <generic_uprobe_filter_arg+0x3cd>
    617d:      	movl	$0x4, %ecx
    6182:      	movl	$0xc, %eax
    6187:      	movq	%rbx, %rdi
    618a:      	movl	$0x4, %edx
    618f:      	callq	*%rax
    6191:      	movq	(%rip), %rsi            # 0x6198 <generic_uprobe_filter_arg+0x3e8>
    6198:      	movl	$0x5, %ecx
    619d:      	movl	$0xc, %eax
    61a2:      	movq	%rbx, %rdi
    61a5:      	movl	$0x5, %edx
    61aa:      	callq	*%rax
    61ac:      	xorl	%eax, %eax
    61ae:      	addq	$0x28, %rsp
    61b2:      	popq	%rbx
    61b3:      	popq	%r12
    61b5:      	popq	%r13
    61b7:      	popq	%r14
    61b9:      	popq	%r15
    61bb:      	popq	%rbp
    61bc:      	retq
    61bd:      	xorl	%r12d, %r12d
    61c0:      	cmpb	$0x0, 0x5ec1(%r14)
    61c8:      	jne	0x621a <generic_uprobe_filter_arg+0x46a>
    61ca:      	movl	$0x1, %r12d
    61d0:      	cmpb	$0x0, 0x5ec2(%r14)
    61d8:      	jne	0x621a <generic_uprobe_filter_arg+0x46a>
    61da:      	movl	$0x2, %r12d
    61e0:      	cmpb	$0x0, 0x5ec3(%r14)
    61e8:      	jne	0x621a <generic_uprobe_filter_arg+0x46a>
    61ea:      	movl	$0x3, %r12d
    61f0:      	cmpb	$0x0, 0x5ec4(%r14)
    61f8:      	jne	0x621a <generic_uprobe_filter_arg+0x46a>
    61fa:      	movl	$0x4, %r12d
    6200:      	cmpb	$0x0, 0x5ec5(%r14)
    6208:      	jne	0x621a <generic_uprobe_filter_arg+0x46a>
    620a:      	movl	$0x5, %r12d
    6210:      	cmpb	$0x0, 0x5ec6(%r14)
    6218:      	je	0x623c <generic_uprobe_filter_arg+0x48c>
    621a:      	movl	%r12d, 0x5f00(%r14)
    6221:      	movq	(%rip), %rsi            # 0x6228 <generic_uprobe_filter_arg+0x478>
    6228:      	movl	$0x3, %ecx
    622d:      	movl	$0xc, %eax
    6232:      	movq	%rbx, %rdi
    6235:      	movl	$0x3, %edx
    623a:      	callq	*%rax
    623c:      	movq	0x60(%r14), %rbx
    6240:      	movl	$0xe, %eax
    6245:      	callq	*%rax
    6247:      	movq	%rbx, 0x18(%rsp)
    624c:      	movq	%rax, 0x20(%rsp)
    6251:      	movq	(%rip), %rdi            # 0x6258 <generic_uprobe_filter_arg+0x4a8>
    6258:      	leaq	0x18(%rsp), %rsi
    625d:      	movl	$0x1, %eax
    6262:      	callq	*%rax
    6264:      	testq	%rax, %rax
    6267:      	je	0x61ac <generic_uprobe_filter_arg+0x3fc>
    626d:      	movq	(%rip), %rdi            # 0x6274 <generic_uprobe_filter_arg+0x4c4>
    6274:      	leaq	0x18(%rsp), %rsi
    6279:      	movl	$0x3, %eax
    627e:      	callq	*%rax
    6280:      	jmp	0x61ac <generic_uprobe_filter_arg+0x3fc>
    6285:      	nopw	%cs:(%rax,%rax)

0000000000006290 <generic_uprobe_actions>:
    6290:      	pushq	%rbp
    6291:      	pushq	%r14
    6293:      	pushq	%rbx
    6294:      	subq	$0x10, %rsp
    6298:      	movq	%rdi, %rbx
    629b:      	movl	$0x0, 0x8(%rsp)
    62a3:      	movq	(%rip), %rdi            # 0x62aa <generic_uprobe_actions+0x1a>
    62aa:      	leaq	0x8(%rsp), %rsi
    62af:      	movl	$0x1, %eax
    62b4:      	callq	*%rax
    62b6:      	testq	%rax, %rax
    62b9:      	je	0x63c2 <generic_uprobe_actions+0x132>
    62bf:      	movq	%rax, %rsi
    62c2:      	movl	0x5f04(%rax), %r14d
    62c9:      	cmpl	$0x2, %r14d
    62cd:      	jl	0x63c2 <generic_uprobe_actions+0x132>
    62d3:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    62da:      	movq	(%rip), %rdi            # 0x62e1 <generic_uprobe_actions+0x51>
    62e1:      	movl	$0x1, %eax
    62e6:      	callq	*%rax
    62e8:      	testq	%rax, %rax
    62eb:      	je	0x63c2 <generic_uprobe_actions+0x132>
    62f1:      	movl	%r14d, %ecx
    62f4:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    62fa:      	addl	(%rax,%rcx), %r14d
    62fe:      	movb	$0x1, 0x7(%rsp)
    6303:      	movl	$0x0, 0xc(%rsp)
    630b:      	movq	(%rip), %rdi            # 0x6312 <generic_uprobe_actions+0x82>
    6312:      	leaq	0xc(%rsp), %rsi
    6317:      	movq	%rax, %rcx
    631a:      	movl	$0x1, %eax
    631f:      	andl	$0x7ff, %r14d           # imm = 0x7FF
    6326:      	addq	%rcx, %r14
    6329:      	callq	*%rax
    632b:      	testq	%rax, %rax
    632e:      	je	0x633e <generic_uprobe_actions+0xae>
    6330:      	cmpb	$0x0, (%rax)
    6333:      	sete	%al
    6336:      	cmpl	$0x5, (%r14)
    633a:      	jae	0x6346 <generic_uprobe_actions+0xb6>
    633c:      	jmp	0x63a0 <generic_uprobe_actions+0x110>
    633e:      	movb	$0x1, %al
    6340:      	cmpl	$0x5, (%r14)
    6344:      	jb	0x63a0 <generic_uprobe_actions+0x110>
    6346:      	movzbl	%al, %ebp
    6349:      	leaq	0x7(%rsp), %rcx
    634e:      	movq	%rbx, %rdi
    6351:      	xorl	%esi, %esi
    6353:      	movq	%r14, %rdx
    6356:      	movl	%ebp, %r8d
    6359:      	callq	0x635e <generic_uprobe_actions+0xce>
    635e:      	leal	0x4(,%rax,4), %ecx
    6365:      	cmpl	(%r14), %ecx
    6368:      	jae	0x63a0 <generic_uprobe_actions+0x110>
    636a:      	leaq	0x7(%rsp), %rcx
    636f:      	movq	%rbx, %rdi
    6372:      	movl	%eax, %esi
    6374:      	movq	%r14, %rdx
    6377:      	movl	%ebp, %r8d
    637a:      	callq	0x637f <generic_uprobe_actions+0xef>
    637f:      	leal	0x4(,%rax,4), %ecx
    6386:      	cmpl	(%r14), %ecx
    6389:      	jae	0x63a0 <generic_uprobe_actions+0x110>
    638b:      	leaq	0x7(%rsp), %rcx
    6390:      	movq	%rbx, %rdi
    6393:      	movl	%eax, %esi
    6395:      	movq	%r14, %rdx
    6398:      	movl	%ebp, %r8d
    639b:      	callq	0x63a0 <generic_uprobe_actions+0x110>
    63a0:      	cmpb	$0x0, 0x7(%rsp)
    63a5:      	je	0x63c2 <generic_uprobe_actions+0x132>
    63a7:      	movq	(%rip), %rsi            # 0x63ae <generic_uprobe_actions+0x11e>
    63ae:      	movl	$0x5, %ecx
    63b3:      	movl	$0xc, %eax
    63b8:      	movq	%rbx, %rdi
    63bb:      	movl	$0x5, %edx
    63c0:      	callq	*%rax
    63c2:      	xorl	%eax, %eax
    63c4:      	addq	$0x10, %rsp
    63c8:      	popq	%rbx
    63c9:      	popq	%r14
    63cb:      	popq	%rbp
    63cc:      	retq
    63cd:      	nopl	(%rax)

00000000000063d0 <generic_uprobe_output>:
    63d0:      	pushq	%rbp
    63d1:      	pushq	%r15
    63d3:      	pushq	%r14
    63d5:      	pushq	%r13
    63d7:      	pushq	%r12
    63d9:      	pushq	%rbx
    63da:      	subq	$0x78, %rsp
    63de:      	movq	%rdi, %r14
    63e1:      	movl	$0x0, 0x24(%rsp)
    63e9:      	movq	(%rip), %rdi            # 0x63f0 <generic_uprobe_output+0x20>
    63f0:      	leaq	0x24(%rsp), %rsi
    63f5:      	movl	$0x1, %eax
    63fa:      	callq	*%rax
    63fc:      	testq	%rax, %rax
    63ff:      	je	0x68a9 <generic_uprobe_output+0x4d9>
    6405:      	movq	%rax, %rbx
    6408:      	cmpq	$0x0, 0x5ee8(%rax)
    6410:      	je	0x6718 <generic_uprobe_output+0x348>
    6416:      	movl	$0xe, %eax
    641b:      	callq	*%rax
    641d:      	movq	%rax, %r15
    6420:      	shrq	$0x20, %r15
    6424:      	movl	$0x23, %eax
    6429:      	callq	*%rax
    642b:      	movq	%rax, %r12
    642e:      	movl	%r15d, 0x28(%rsp)
    6433:      	movq	(%rip), %rdi            # 0x643a <generic_uprobe_output+0x6a>
    643a:      	leaq	0x28(%rsp), %rsi
    643f:      	movl	$0x1, %eax
    6444:      	callq	*%rax
    6446:      	testq	%rax, %rax
    6449:      	je	0x6718 <generic_uprobe_output+0x348>
    644f:      	movq	%rax, %r15
    6452:      	leaq	0xd70(%r12), %rdx
    645a:      	leaq	0x70(%rsp), %rdi
    645f:      	movl	$0x8, %ecx
    6464:      	movl	$0x4, %eax
    6469:      	leaq	0x28(%r15), %r13
    646d:      	movl	$0x4, %ebp
    6472:      	movl	$0x8, %esi
    6477:      	callq	*%rax
    6479:      	movq	0x70(%rsp), %rcx
    647e:      	leaq	0x28(%rsp), %rdi
    6483:      	movl	$0x48, %edx
    6488:      	movl	$0x4, %eax
    648d:      	movq	0x70(%rsp), %rdx
    6492:      	movl	$0x48, %esi
    6497:      	callq	*%rax
    6499:      	movl	$0x218, %edx            # imm = 0x218
    649e:      	movq	0x30(%rsp), %rcx
    64a3:      	addq	%rdx, %rcx
    64a6:      	movl	$0x4, %esi
    64ab:      	movl	$0x4, %eax
    64b0:      	addq	0x30(%rsp), %rdx
    64b5:      	movq	%r13, %rdi
    64b8:      	movl	$0x4, %esi
    64bd:      	callq	*%rax
    64bf:      	leaq	0x2c(%r15), %rdi
    64c3:      	movl	$0x4d8, %edx            # imm = 0x4D8
    64c8:      	movq	0x38(%rsp), %rcx
    64cd:      	addq	%rdx, %rcx
    64d0:      	movl	$0x4, %esi
    64d5:      	movl	$0x4, %eax
    64da:      	addq	0x38(%rsp), %rdx
    64df:      	movl	$0x4, %esi
    64e4:      	callq	*%rax
    64e6:      	leaq	0x30(%r15), %rdi
    64ea:      	movq	0x40(%rsp), %rcx
    64ef:      	addq	$0x58, %rcx
    64f3:      	movl	$0x4, %edx
    64f8:      	movl	$0x4, %eax
    64fd:      	movq	0x40(%rsp), %rdx
    6502:      	addq	$0x58, %rdx
    6506:      	movl	$0x4, %esi
    650b:      	callq	*%rax
    650d:      	movq	$0x0, (%rsp)
    6515:      	leaq	0xb58(%r12), %rdx
    651d:      	movq	%rsp, %rdi
    6520:      	movl	$0x8, %ecx
    6525:      	movl	$0x4, %eax
    652a:      	movl	$0x8, %esi
    652f:      	callq	*%rax
    6531:      	movq	(%rsp), %rcx
    6535:      	testq	%rcx, %rcx
    6538:      	je	0x65cb <generic_uprobe_output+0x1fb>
    653e:      	movl	$0x0, 0xc(%rsp)
    6546:      	addq	$0x4, %rcx
    654a:      	leaq	0xc(%rsp), %rdi
    654f:      	movl	$0x4, %eax
    6554:      	movq	(%rsp), %rdx
    6558:      	addq	$0x4, %rdx
    655c:      	movl	$0x4, %esi
    6561:      	callq	*%rax
    6563:      	movq	(%rsp), %rax
    6567:      	movslq	0xc(%rsp), %rcx
    656c:      	shlq	$0x4, %rcx
    6570:      	addq	%rax, %rcx
    6573:      	addq	$0x80, %rcx
    657a:      	leaq	0x10(%rsp), %rdi
    657f:      	movl	$0x10, %edx
    6584:      	movl	$0x4, %eax
    6589:      	movq	(%rsp), %rcx
    658d:      	movslq	0xc(%rsp), %rdx
    6592:      	shlq	$0x4, %rdx
    6596:      	addq	%rcx, %rdx
    6599:      	addq	$0x80, %rdx
    65a0:      	movl	$0x10, %esi
    65a5:      	callq	*%rax
    65a7:      	leaq	0x34(%r15), %rdi
    65ab:      	movl	$0x158, %edx            # imm = 0x158
    65b0:      	movq	0x18(%rsp), %rcx
    65b5:      	addq	%rdx, %rcx
    65b8:      	movl	$0x4, %eax
    65bd:      	addq	0x18(%rsp), %rdx
    65c2:      	movl	$0x4, %esi
    65c7:      	callq	*%rax
    65c9:      	jmp	0x65d3 <generic_uprobe_output+0x203>
    65cb:      	movl	$0x0, 0x34(%r15)
    65d3:      	leaq	0x38(%r15), %rdi
    65d7:      	movl	$0x158, %r13d           # imm = 0x158
    65dd:      	movq	0x48(%rsp), %rcx
    65e2:      	addq	%r13, %rcx
    65e5:      	movl	$0x4, %edx
    65ea:      	movl	$0x4, %eax
    65ef:      	movq	0x48(%rsp), %rdx
    65f4:      	addq	%r13, %rdx
    65f7:      	movl	$0x4, %esi
    65fc:      	callq	*%rax
    65fe:      	leaq	0x3c(%r15), %rdi
    6602:      	movl	$0x118, %edx            # imm = 0x118
    6607:      	movq	0x50(%rsp), %rcx
    660c:      	addq	%rdx, %rcx
    660f:      	movl	$0x4, %esi
    6614:      	movl	$0x4, %eax
    6619:      	addq	0x50(%rsp), %rdx
    661e:      	movl	$0x4, %esi
    6623:      	callq	*%rax
    6625:      	leaq	0x40(%r15), %rdi
    6629:      	movl	$0x98, %ebp
    662e:      	movq	0x58(%rsp), %rcx
    6633:      	addq	%rbp, %rcx
    6636:      	movl	$0x4, %edx
    663b:      	movl	$0x4, %eax
    6640:      	movq	0x58(%rsp), %rdx
    6645:      	addq	%rbp, %rdx
    6648:      	movl	$0x4, %esi
    664d:      	callq	*%rax
    664f:      	leaq	0x44(%r15), %rdi
    6653:      	movq	0x60(%rsp), %rcx
    6658:      	addq	%rbp, %rcx
    665b:      	movl	$0x4, %edx
    6660:      	movl	$0x4, %eax
    6665:      	addq	0x60(%rsp), %rbp
    666a:      	movl	$0x4, %esi
    666f:      	movq	%rbp, %rdx
    6672:      	callq	*%rax
    6674:      	leaq	0x48(%r15), %rdi
    6678:      	movq	0x68(%rsp), %rcx
    667d:      	addq	$0x58, %rcx
    6681:      	movl	$0x4, %edx
    6686:      	movl	$0x4, %eax
    668b:      	movq	0x68(%rsp), %rdx
    6690:      	addq	$0x58, %rdx
    6694:      	movl	$0x4, %esi
    6699:      	callq	*%rax
    669b:      	movq	$0x0, 0x10(%rsp)
    66a4:      	movq	$0x0, (%rsp)
    66ac:      	addq	$0xd00, %r12            # imm = 0xD00
    66b3:      	leaq	0x10(%rsp), %rdi
    66b8:      	movl	$0x8, %ecx
    66bd:      	movl	$0x4, %eax
    66c2:      	movl	$0x8, %esi
    66c7:      	movq	%r12, %rdx
    66ca:      	callq	*%rax
    66cc:      	movl	$0x90, %edx
    66d1:      	movq	0x10(%rsp), %rcx
    66d6:      	addq	%rdx, %rcx
    66d9:      	movq	%rsp, %rdi
    66dc:      	movl	$0x8, %esi
    66e1:      	movl	$0x4, %eax
    66e6:      	addq	0x10(%rsp), %rdx
    66eb:      	movl	$0x8, %esi
    66f0:      	callq	*%rax
    66f2:      	addq	$0x4c, %r15
    66f6:      	movq	(%rsp), %rcx
    66fa:      	addq	%r13, %rcx
    66fd:      	movl	$0x4, %edx
    6702:      	movl	$0x4, %eax
    6707:      	addq	(%rsp), %r13
    670b:      	movq	%r15, %rdi
    670e:      	movl	$0x4, %esi
    6713:      	movq	%r13, %rdx
    6716:      	callq	*%rax
    6718:      	cmpq	$0x0, 0x5ef0(%rbx)
    6720:      	je	0x67d9 <generic_uprobe_output+0x409>
    6726:      	movl	$0xe, %eax
    672b:      	callq	*%rax
    672d:      	movq	%rax, %r15
    6730:      	shrq	$0x20, %r15
    6734:      	movl	$0x23, %eax
    6739:      	callq	*%rax
    673b:      	movq	%rax, %r12
    673e:      	movl	%r15d, 0x28(%rsp)
    6743:      	movq	(%rip), %rdi            # 0x674a <generic_uprobe_output+0x37a>
    674a:      	leaq	0x28(%rsp), %rsi
    674f:      	movl	$0x1, %eax
    6754:      	callq	*%rax
    6756:      	testq	%rax, %rax
    6759:      	je	0x67d9 <generic_uprobe_output+0x409>
    675b:      	leaq	0x50(%rax), %r15
    675f:      	addq	$0xd00, %r12            # imm = 0xD00
    6766:      	leaq	0x28(%rsp), %rdi
    676b:      	movl	$0x8, %ecx
    6770:      	movq	%rax, %r13
    6773:      	movl	$0x4, %eax
    6778:      	movl	$0x8, %esi
    677d:      	movq	%r12, %rdx
    6780:      	callq	*%rax
    6782:      	movq	0x28(%rsp), %r12
    6787:      	leaq	0x58(%r13), %rdi
    678b:      	leaq	0x40(%r12), %rdx
    6790:      	movl	$0x8, %ecx
    6795:      	movl	$0x4, %eax
    679a:      	movl	$0x8, %esi
    679f:      	callq	*%rax
    67a1:      	addq	$0x60, %r13
    67a5:      	leaq	0x30(%r12), %rdx
    67aa:      	movl	$0x8, %ecx
    67af:      	movl	$0x4, %eax
    67b4:      	movq	%r13, %rdi
    67b7:      	movl	$0x8, %esi
    67bc:      	callq	*%rax
    67be:      	addq	$0x38, %r12
    67c2:      	movl	$0x8, %ecx
    67c7:      	movl	$0x4, %eax
    67cc:      	movq	%r15, %rdi
    67cf:      	movl	$0x8, %esi
    67d4:      	movq	%r12, %rdx
    67d7:      	callq	*%rax
    67d9:      	movl	$0x90, %eax
    67de:      	addl	0x4(%rbx), %eax
    67e1:      	andl	$0x7fff, %eax           # imm = 0x7FFF
    67e6:      	cmpl	$0x2328, %eax           # imm = 0x2328
    67eb:      	movl	$0x2328, %r15d          # imm = 0x2328
    67f1:      	cmovbl	%eax, %r15d
    67f5:      	movl	$0x0, 0x10(%rsp)
    67fd:      	movq	(%rip), %rdi            # 0x6804 <generic_uprobe_output+0x434>
    6804:      	leaq	0x10(%rsp), %rsi
    6809:      	movl	$0x1, %eax
    680e:      	callq	*%rax
    6810:      	testq	%rax, %rax
    6813:      	je	0x6867 <generic_uprobe_output+0x497>
    6815:      	cmpb	$0x0, 0x28(%rax)
    6819:      	je	0x6867 <generic_uprobe_output+0x497>
    681b:      	movq	(%rip), %rsi            # 0x6822 <generic_uprobe_output+0x452>
    6822:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    6827:      	movl	$0x19, %eax
    682c:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    6831:      	movq	%r14, %rdi
    6834:      	movq	%rbx, %rcx
    6837:      	movq	%r15, %r8
    683a:      	callq	*%rax
    683c:      	testq	%rax, %rax
    683f:      	js	0x6909 <generic_uprobe_output+0x539>
    6845:      	movl	$0x0, 0x28(%rsp)
    684d:      	movq	(%rip), %rdi            # 0x6854 <generic_uprobe_output+0x484>
    6854:      	leaq	0x28(%rsp), %rsi
    6859:      	movl	$0x1, %eax
    685e:      	callq	*%rax
    6860:      	testq	%rax, %rax
    6863:      	jne	0x68a4 <generic_uprobe_output+0x4d4>
    6865:      	jmp	0x68a9 <generic_uprobe_output+0x4d9>
    6867:      	movq	(%rip), %rdi            # 0x686e <generic_uprobe_output+0x49e>
    686e:      	xorl	%ecx, %ecx
    6870:      	movl	$0x82, %eax
    6875:      	movq	%rbx, %rsi
    6878:      	movq	%r15, %rdx
    687b:      	xorl	%ecx, %ecx
    687d:      	callq	*%rax
    687f:      	testq	%rax, %rax
    6882:      	js	0x68ba <generic_uprobe_output+0x4ea>
    6884:      	movl	$0x0, 0x28(%rsp)
    688c:      	movq	(%rip), %rdi            # 0x6893 <generic_uprobe_output+0x4c3>
    6893:      	leaq	0x28(%rsp), %rsi
    6898:      	movl	$0x1, %eax
    689d:      	callq	*%rax
    689f:      	testq	%rax, %rax
    68a2:      	je	0x68a9 <generic_uprobe_output+0x4d9>
    68a4:      	lock
    68a5:      	incq	0x8(%rax)
    68a9:      	xorl	%eax, %eax
    68ab:      	addq	$0x78, %rsp
    68af:      	popq	%rbx
    68b0:      	popq	%r12
    68b2:      	popq	%r13
    68b4:      	popq	%r14
    68b6:      	popq	%r15
    68b8:      	popq	%rbp
    68b9:      	retq
    68ba:      	movq	%rax, %rbx
    68bd:      	movl	$0x0, 0x28(%rsp)
    68c5:      	movq	(%rip), %rdi            # 0x68cc <generic_uprobe_output+0x4fc>
    68cc:      	leaq	0x28(%rsp), %rsi
    68d1:      	movl	$0x1, %eax
    68d6:      	callq	*%rax
    68d8:      	testq	%rax, %rax
    68db:      	je	0x68a9 <generic_uprobe_output+0x4d9>
    68dd:      	cmpq	$-0xc, %rbx
    68e1:      	jg	0x6951 <generic_uprobe_output+0x581>
    68e3:      	cmpq	$-0x1c, %rbx
    68e7:      	je	0x6993 <generic_uprobe_output+0x5c3>
    68ed:      	cmpq	$-0x16, %rbx
    68f1:      	je	0x6942 <generic_uprobe_output+0x572>
    68f3:      	cmpq	$-0x10, %rbx
    68f7:      	jne	0x6984 <generic_uprobe_output+0x5b4>
    68fd:      	addq	$0x360, %rax            # imm = 0x360
    6903:      	lock
    6904:      	incq	(%rax)
    6907:      	jmp	0x68a9 <generic_uprobe_output+0x4d9>
    6909:      	movq	%rax, %rbx
    690c:      	movl	$0x0, 0x28(%rsp)
    6914:      	movq	(%rip), %rdi            # 0x691b <generic_uprobe_output+0x54b>
    691b:      	leaq	0x28(%rsp), %rsi
    6920:      	movl	$0x1, %eax
    6925:      	callq	*%rax
    6927:      	testq	%rax, %rax
    692a:      	je	0x68a9 <generic_uprobe_output+0x4d9>
    6930:      	cmpq	$-0xc, %rbx
    6934:      	jg	0x6972 <generic_uprobe_output+0x5a2>
    6936:      	cmpq	$-0x1c, %rbx
    693a:      	je	0x6993 <generic_uprobe_output+0x5c3>
    693c:      	cmpq	$-0x16, %rbx
    6940:      	jne	0x68f3 <generic_uprobe_output+0x523>
    6942:      	addq	$0x368, %rax            # imm = 0x368
    6948:      	lock
    6949:      	incq	(%rax)
    694c:      	jmp	0x68a9 <generic_uprobe_output+0x4d9>
    6951:      	cmpq	$-0xb, %rbx
    6955:      	je	0x69a2 <generic_uprobe_output+0x5d2>
    6957:      	cmpq	$-0x7, %rbx
    695b:      	je	0x69b1 <generic_uprobe_output+0x5e1>
    695d:      	cmpq	$-0x2, %rbx
    6961:      	jne	0x6984 <generic_uprobe_output+0x5b4>
    6963:      	addq	$0x350, %rax            # imm = 0x350
    6969:      	lock
    696a:      	incq	(%rax)
    696d:      	jmp	0x68a9 <generic_uprobe_output+0x4d9>
    6972:      	cmpq	$-0xb, %rbx
    6976:      	je	0x69a2 <generic_uprobe_output+0x5d2>
    6978:      	cmpq	$-0x7, %rbx
    697c:      	je	0x69b1 <generic_uprobe_output+0x5e1>
    697e:      	cmpq	$-0x2, %rbx
    6982:      	je	0x6963 <generic_uprobe_output+0x593>
    6984:      	addq	$0x348, %rax            # imm = 0x348
    698a:      	lock
    698b:      	incq	(%rax)
    698e:      	jmp	0x68a9 <generic_uprobe_output+0x4d9>
    6993:      	addq	$0x370, %rax            # imm = 0x370
    6999:      	lock
    699a:      	incq	(%rax)
    699d:      	jmp	0x68a9 <generic_uprobe_output+0x4d9>
    69a2:      	addq	$0x378, %rax            # imm = 0x378
    69a8:      	lock
    69a9:      	incq	(%rax)
    69ac:      	jmp	0x68a9 <generic_uprobe_output+0x4d9>
    69b1:      	addq	$0x358, %rax            # imm = 0x358
    69b7:      	lock
    69b8:      	incq	(%rax)
    69bb:      	jmp	0x68a9 <generic_uprobe_output+0x4d9>

Disassembly of section uprobe/generic_uprobe:

0000000000000000 <generic_uprobe_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x88, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x38(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <generic_uprobe_event+0x23>
      23:      	leaq	0x38(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x622 <generic_uprobe_event+0x622>
      38:      	movq	%rax, %r14
      3b:      	leaq	0x5ef8(%rax), %rsi
      42:      	movl	$0x0, 0x5ef8(%rax)
      4c:      	movq	(%rip), %rdi            # 0x53 <generic_uprobe_event+0x53>
      53:      	movl	$0x1, %eax
      58:      	callq	*%rax
      5a:      	testq	%rax, %rax
      5d:      	je	0x622 <generic_uprobe_event+0x622>
      63:      	movl	0x64(%rax), %ecx
      66:      	movl	%ecx, 0x14(%rsp)
      6a:      	testl	%ecx, %ecx
      6c:      	je	0x23b <generic_uprobe_event+0x23b>
      72:      	movq	%rax, %r12
      75:      	movq	(%rip), %rdi            # 0x7c <generic_uprobe_event+0x7c>
      7c:      	leaq	0x14(%rsp), %rsi
      81:      	movl	$0x1, %eax
      86:      	callq	*%rax
      88:      	testq	%rax, %rax
      8b:      	je	0x622 <generic_uprobe_event+0x622>
      91:      	movq	%rax, %r15
      94:      	movl	$0x0, 0x3c(%rsp)
      9c:      	movq	(%rip), %rdi            # 0xa3 <generic_uprobe_event+0xa3>
      a3:      	leaq	0x3c(%rsp), %rsi
      a8:      	movl	$0x1, %eax
      ad:      	callq	*%rax
      af:      	testq	%rax, %rax
      b2:      	je	0xd8 <generic_uprobe_event+0xd8>
      b4:      	cmpq	$0x63677270, 0x20(%rax) # imm = 0x63677270
      bc:      	jne	0xdc <generic_uprobe_event+0xdc>
      be:      	movl	$0x50, %eax
      c3:      	callq	*%rax
      c5:      	movq	%rax, 0x8(%rsp)
      ca:      	testq	%rax, %rax
      cd:      	jne	0x1f6 <generic_uprobe_event+0x1f6>
      d3:      	jmp	0x622 <generic_uprobe_event+0x622>
      d8:      	xorl	%ebp, %ebp
      da:      	jmp	0xdf <generic_uprobe_event+0xdf>
      dc:      	movl	0x10(%rax), %ebp
      df:      	movl	$0x23, %eax
      e4:      	callq	*%rax
      e6:      	movq	$0x0, 0x20(%rsp)
      ef:      	leaq	0xf90(%rax), %rdx
      f6:      	leaq	0x28(%rsp), %rdi
      fb:      	movl	$0x8, %ecx
     100:      	movl	$0x71, %eax
     105:      	movl	$0x8, %esi
     10a:      	callq	*%rax
     10c:      	movq	0x28(%rsp), %rax
     111:      	testq	%rax, %rax
     114:      	je	0x622 <generic_uprobe_event+0x622>
     11a:      	cmpl	$0xb, %ebp
     11d:      	ja	0x622 <generic_uprobe_event+0x622>
     123:      	movl	%ebp, %edx
     125:      	leaq	(%rax,%rdx,8), %rcx
     129:      	leaq	0x40(%rsp), %rdi
     12e:      	movl	$0x8, %esi
     133:      	movl	$0x71, %eax
     138:      	shlq	$0x3, %rdx
     13c:      	addq	0x28(%rsp), %rdx
     141:      	movl	$0x8, %esi
     146:      	callq	*%rax
     148:      	movq	0x40(%rsp), %rcx
     14d:      	testq	%rcx, %rcx
     150:      	je	0x622 <generic_uprobe_event+0x622>
     156:      	leaq	0x20(%rsp), %rdi
     15b:      	movl	$0x8, %edx
     160:      	movl	$0x71, %eax
     165:      	movq	0x40(%rsp), %rdx
     16a:      	movl	$0x8, %esi
     16f:      	callq	*%rax
     171:      	movq	0x20(%rsp), %rdx
     176:      	testq	%rdx, %rdx
     179:      	je	0x622 <generic_uprobe_event+0x622>
     17f:      	movq	$0x0, 0x40(%rsp)
     188:      	addq	$0x100, %rdx            # imm = 0x100
     18f:      	leaq	0x40(%rsp), %rdi
     194:      	movl	$0x8, %ecx
     199:      	movl	$0x71, %eax
     19e:      	movl	$0x8, %esi
     1a3:      	callq	*%rax
     1a5:      	movq	0x40(%rsp), %rdx
     1aa:      	movq	$0x0, 0x40(%rsp)
     1b3:      	testq	%rdx, %rdx
     1b6:      	je	0x1e6 <generic_uprobe_event+0x1e6>
     1b8:      	addq	$0x60, %rdx
     1bc:      	leaq	0x40(%rsp), %rdi
     1c1:      	movl	$0x8, %ecx
     1c6:      	movl	$0x71, %eax
     1cb:      	movl	$0x8, %esi
     1d0:      	callq	*%rax
     1d2:      	movq	0x40(%rsp), %rax
     1d7:      	movq	%rax, 0x8(%rsp)
     1dc:      	testq	%rax, %rax
     1df:      	jne	0x1f6 <generic_uprobe_event+0x1f6>
     1e1:      	jmp	0x622 <generic_uprobe_event+0x622>
     1e6:      	xorl	%eax, %eax
     1e8:      	movq	%rax, 0x8(%rsp)
     1ed:      	testq	%rax, %rax
     1f0:      	je	0x622 <generic_uprobe_event+0x622>
     1f6:      	movq	%rax, 0x40(%rsp)
     1fb:      	movq	(%rip), %rdi            # 0x202 <generic_uprobe_event+0x202>
     202:      	leaq	0x40(%rsp), %rsi
     207:      	movl	$0x1, %eax
     20c:      	callq	*%rax
     20e:      	testq	%rax, %rax
     211:      	je	0x220 <generic_uprobe_event+0x220>
     213:      	movq	(%rax), %rax
     216:      	testq	%rax, %rax
     219:      	je	0x220 <generic_uprobe_event+0x220>
     21b:      	movq	%rax, 0x8(%rsp)
     220:      	leaq	0x8(%rsp), %rsi
     225:      	movl	$0x1, %eax
     22a:      	movq	%r15, %rdi
     22d:      	callq	*%rax
     22f:      	testq	%rax, %rax
     232:      	movq	%r12, %rax
     235:      	je	0x636 <generic_uprobe_event+0x636>
     23b:      	movl	(%rax), %eax
     23d:      	movq	%rax, 0x60(%r14)
     241:      	movq	$0x0, 0x68(%r14)
     249:      	movq	$0x0, 0x5efc(%r14)
     254:      	movq	$0x0, 0x5eb8(%r14)
     25f:      	movq	$0x0, 0x5ec0(%r14)
     26a:      	movq	$0x0, 0x5ec8(%r14)
     275:      	movq	$0x0, 0x5ed0(%r14)
     280:      	movq	$0x0, 0x5ed8(%r14)
     28b:      	movb	$0x0, 0x5ee0(%r14)
     293:      	movl	$0x23, %eax
     298:      	callq	*%rax
     29a:      	movq	%rax, %r15
     29d:      	leaq	0xd70(%rax), %rdx
     2a4:      	leaq	0x20(%rsp), %rdi
     2a9:      	movl	$0x8, %ecx
     2ae:      	movl	$0x4, %eax
     2b3:      	leaq	0x20(%r14), %r12
     2b7:      	movl	$0x4, %r13d
     2bd:      	movl	$0x8, %esi
     2c2:      	callq	*%rax
     2c4:      	movq	0x20(%rsp), %rcx
     2c9:      	leaq	0x40(%rsp), %rdi
     2ce:      	movl	$0x48, %edx
     2d3:      	movl	$0x4, %eax
     2d8:      	movq	0x20(%rsp), %rdx
     2dd:      	movl	$0x48, %esi
     2e2:      	callq	*%rax
     2e4:      	movl	$0x218, %edx            # imm = 0x218
     2e9:      	movq	0x48(%rsp), %rcx
     2ee:      	addq	%rdx, %rcx
     2f1:      	movl	$0x4, %esi
     2f6:      	movl	$0x4, %eax
     2fb:      	addq	0x48(%rsp), %rdx
     300:      	movq	%r12, %rdi
     303:      	movl	$0x4, %esi
     308:      	callq	*%rax
     30a:      	leaq	0x24(%r14), %rdi
     30e:      	movl	$0x4d8, %edx            # imm = 0x4D8
     313:      	movq	0x50(%rsp), %rcx
     318:      	addq	%rdx, %rcx
     31b:      	movl	$0x4, %esi
     320:      	movl	$0x4, %eax
     325:      	addq	0x50(%rsp), %rdx
     32a:      	movl	$0x4, %esi
     32f:      	callq	*%rax
     331:      	leaq	0x28(%r14), %rdi
     335:      	movq	0x58(%rsp), %rcx
     33a:      	addq	$0x58, %rcx
     33e:      	movl	$0x4, %edx
     343:      	movl	$0x4, %eax
     348:      	movq	0x58(%rsp), %rdx
     34d:      	addq	$0x58, %rdx
     351:      	movl	$0x4, %esi
     356:      	callq	*%rax
     358:      	movq	$0x0, 0x8(%rsp)
     361:      	leaq	0xb58(%r15), %rdx
     368:      	leaq	0x8(%rsp), %rdi
     36d:      	movl	$0x8, %ecx
     372:      	movl	$0x4, %eax
     377:      	movl	$0x8, %esi
     37c:      	callq	*%rax
     37e:      	movq	0x8(%rsp), %rcx
     383:      	testq	%rcx, %rcx
     386:      	je	0x41c <generic_uprobe_event+0x41c>
     38c:      	movl	$0x0, 0x18(%rsp)
     394:      	addq	$0x4, %rcx
     398:      	leaq	0x18(%rsp), %rdi
     39d:      	movl	$0x4, %eax
     3a2:      	movq	0x8(%rsp), %rdx
     3a7:      	addq	$0x4, %rdx
     3ab:      	movl	$0x4, %esi
     3b0:      	callq	*%rax
     3b2:      	movq	0x8(%rsp), %rax
     3b7:      	movslq	0x18(%rsp), %rcx
     3bc:      	shlq	$0x4, %rcx
     3c0:      	addq	%rax, %rcx
     3c3:      	addq	$0x80, %rcx
     3ca:      	leaq	0x28(%rsp), %rdi
     3cf:      	movl	$0x10, %edx
     3d4:      	movl	$0x4, %eax
     3d9:      	movq	0x8(%rsp), %rcx
     3de:      	movslq	0x18(%rsp), %rdx
     3e3:      	shlq	$0x4, %rdx
     3e7:      	addq	%rcx, %rdx
     3ea:      	addq	$0x80, %rdx
     3f1:      	movl	$0x10, %esi
     3f6:      	callq	*%rax
     3f8:      	leaq	0x2c(%r14), %rdi
     3fc:      	movl	$0x158, %edx            # imm = 0x158
     401:      	movq	0x30(%rsp), %rcx
     406:      	addq	%rdx, %rcx
     409:      	movl	$0x4, %eax
     40e:      	addq	0x30(%rsp), %rdx
     413:      	movl	$0x4, %esi
     418:      	callq	*%rax
     41a:      	jmp	0x424 <generic_uprobe_event+0x424>
     41c:      	movl	$0x0, 0x2c(%r14)
     424:      	leaq	0x30(%r14), %rdi
     428:      	movl	$0x158, %r12d           # imm = 0x158
     42e:      	movq	0x60(%rsp), %rcx
     433:      	addq	%r12, %rcx
     436:      	movl	$0x4, %edx
     43b:      	movl	$0x4, %eax
     440:      	movq	0x60(%rsp), %rdx
     445:      	addq	%r12, %rdx
     448:      	movl	$0x4, %esi
     44d:      	callq	*%rax
     44f:      	leaq	0x34(%r14), %rdi
     453:      	movl	$0x118, %edx            # imm = 0x118
     458:      	movq	0x68(%rsp), %rcx
     45d:      	addq	%rdx, %rcx
     460:      	movl	$0x4, %esi
     465:      	movl	$0x4, %eax
     46a:      	addq	0x68(%rsp), %rdx
     46f:      	movl	$0x4, %esi
     474:      	callq	*%rax
     476:      	leaq	0x38(%r14), %rdi
     47a:      	movl	$0x98, %r13d
     480:      	movq	0x70(%rsp), %rcx
     485:      	addq	%r13, %rcx
     488:      	movl	$0x4, %edx
     48d:      	movl	$0x4, %eax
     492:      	movq	0x70(%rsp), %rdx
     497:      	addq	%r13, %rdx
     49a:      	movl	$0x4, %esi
     49f:      	callq	*%rax
     4a1:      	leaq	0x3c(%r14), %rdi
     4a5:      	movq	0x78(%rsp), %rcx
     4aa:      	addq	%r13, %rcx
     4ad:      	movl	$0x4, %edx
     4b2:      	movl	$0x4, %eax
     4b7:      	addq	0x78(%rsp), %r13
     4bc:      	movl	$0x4, %esi
     4c1:      	movq	%r13, %rdx
     4c4:      	callq	*%rax
     4c6:      	leaq	0x40(%r14), %rdi
     4ca:      	movq	0x80(%rsp), %rcx
     4d2:      	addq	$0x58, %rcx
     4d6:      	movl	$0x4, %edx
     4db:      	movl	$0x4, %eax
     4e0:      	movq	0x80(%rsp), %rdx
     4e8:      	addq	$0x58, %rdx
     4ec:      	movl	$0x4, %esi
     4f1:      	callq	*%rax
     4f3:      	movq	$0x0, 0x28(%rsp)
     4fc:      	movq	$0x0, 0x8(%rsp)
     505:      	addq	$0xd00, %r15            # imm = 0xD00
     50c:      	leaq	0x28(%rsp), %rdi
     511:      	movl	$0x8, %ecx
     516:      	movl	$0x4, %eax
     51b:      	movl	$0x8, %esi
     520:      	movq	%r15, %rdx
     523:      	callq	*%rax
     525:      	movl	$0x90, %edx
     52a:      	movq	0x28(%rsp), %rcx
     52f:      	addq	%rdx, %rcx
     532:      	leaq	0x8(%rsp), %rdi
     537:      	movl	$0x8, %esi
     53c:      	movl	$0x4, %eax
     541:      	addq	0x28(%rsp), %rdx
     546:      	movl	$0x8, %esi
     54b:      	callq	*%rax
     54d:      	leaq	0x44(%r14), %rdi
     551:      	movq	0x8(%rsp), %rcx
     556:      	addq	%r12, %rcx
     559:      	movl	$0x4, %edx
     55e:      	movl	$0x4, %eax
     563:      	addq	0x8(%rsp), %r12
     568:      	movl	$0x4, %esi
     56d:      	movq	%r12, %rdx
     570:      	callq	*%rax
     572:      	leaq	0x48(%r14), %r12
     576:      	leaq	0x40(%rsp), %rdi
     57b:      	movl	$0x8, %ecx
     580:      	movl	$0x4, %eax
     585:      	movl	$0x8, %esi
     58a:      	movq	%r15, %rdx
     58d:      	callq	*%rax
     58f:      	movq	0x40(%rsp), %r15
     594:      	leaq	0x50(%r14), %rdi
     598:      	leaq	0x40(%r15), %rdx
     59c:      	movl	$0x8, %ecx
     5a1:      	movl	$0x4, %eax
     5a6:      	movl	$0x8, %esi
     5ab:      	callq	*%rax
     5ad:      	movq	%r14, %rdi
     5b0:      	addq	$0x58, %rdi
     5b4:      	leaq	0x30(%r15), %rdx
     5b8:      	movl	$0x8, %ecx
     5bd:      	movl	$0x4, %eax
     5c2:      	movl	$0x8, %esi
     5c7:      	callq	*%rax
     5c9:      	addq	$0x38, %r15
     5cd:      	movl	$0x8, %ecx
     5d2:      	movl	$0x4, %eax
     5d7:      	movq	%r12, %rdi
     5da:      	movl	$0x8, %esi
     5df:      	movq	%r15, %rdx
     5e2:      	callq	*%rax
     5e4:      	movb	$0x0, 0x5f08(%r14)
     5ec:      	movb	$0x0, 0x1(%r14)
     5f1:      	movq	$0x0, 0x5ee8(%r14)
     5fc:      	movq	$0x0, 0x5ef0(%r14)
     607:      	movq	(%rip), %rsi            # 0x60e <generic_uprobe_event+0x60e>
     60e:      	movl	$0x2, %ecx
     613:      	movl	$0xc, %eax
     618:      	movq	%rbx, %rdi
     61b:      	movl	$0x2, %edx
     620:      	callq	*%rax
     622:      	xorl	%eax, %eax
     624:      	addq	$0x88, %rsp
     62b:      	popq	%rbx
     62c:      	popq	%r12
     62e:      	popq	%r13
     630:      	popq	%r14
     632:      	popq	%r15
     634:      	popq	%rbp
     635:      	retq
     636:      	movq	$-0x1, 0x18(%rsp)
     63f:      	leaq	0x18(%rsp), %rsi
     644:      	movl	$0x1, %eax
     649:      	movq	%r15, %rdi
     64c:      	callq	*%rax
     64e:      	testq	%rax, %rax
     651:      	je	0x622 <generic_uprobe_event+0x622>
     653:      	movl	$0x1, 0x14(%rsp)
     65b:      	movq	(%rip), %rdi            # 0x662 <generic_uprobe_event+0x662>
     662:      	leaq	0x14(%rsp), %rsi
     667:      	movl	$0x1, %eax
     66c:      	callq	*%rax
     66e:      	testq	%rax, %rax
     671:      	je	0x622 <generic_uprobe_event+0x622>
     673:      	movq	%rax, %rdi
     676:      	leaq	0x8(%rsp), %rsi
     67b:      	movl	$0x1, %eax
     680:      	callq	*%rax
     682:      	testq	%rax, %rax
     685:      	movq	%r12, %rax
     688:      	jne	0x622 <generic_uprobe_event+0x622>
     68a:      	jmp	0x23b <generic_uprobe_event+0x23b>

Disassembly of section uprobe.s/generic_uprobe:

0000000000000000 <generic_sleepable_preload>:
       0:      	pushq	%rbx
       1:      	subq	$0x20, %rsp
       5:      	movq	%rdi, %rbx
       8:      	movl	$0x0, 0xc(%rsp)
      10:      	movq	(%rip), %rdi            # 0x17 <generic_sleepable_preload+0x17>
      17:      	leaq	0xc(%rsp), %rsi
      1c:      	movl	$0x1, %eax
      21:      	callq	*%rax
      23:      	testq	%rax, %rax
      26:      	je	0x81 <generic_sleepable_preload+0x81>
      28:      	movq	%rax, 0x10(%rsp)
      2d:      	movq	%rbx, 0x18(%rsp)
      32:      	movq	(%rip), %rax            # 0x39 <generic_sleepable_preload+0x39>
      39:      	cmpb	$0x0, (%rax)
      3c:      	je	0x89 <generic_sleepable_preload+0x89>
      3e:      	leaq	0x10(%rsp), %rbx
      43:      	xorl	%edi, %edi
      45:      	movq	%rbx, %rsi
      48:      	callq	0x4d <generic_sleepable_preload+0x4d>
      4d:      	movl	$0x1, %edi
      52:      	movq	%rbx, %rsi
      55:      	callq	0x5a <generic_sleepable_preload+0x5a>
      5a:      	movl	$0x2, %edi
      5f:      	movq	%rbx, %rsi
      62:      	callq	0x67 <generic_sleepable_preload+0x67>
      67:      	movl	$0x3, %edi
      6c:      	movq	%rbx, %rsi
      6f:      	callq	0x74 <generic_sleepable_preload+0x74>
      74:      	movl	$0x4, %edi
      79:      	movq	%rbx, %rsi
      7c:      	callq	0x81 <generic_sleepable_preload+0x81>
      81:      	xorl	%eax, %eax
      83:      	addq	$0x20, %rsp
      87:      	popq	%rbx
      88:      	retq
      89:      	leaq	(%rip), %rsi            # 0x90 <generic_sleepable_preload+0x90>
      90:      	xorl	%ecx, %ecx
      92:      	leaq	0x10(%rsp), %rdx
      97:      	movl	$0x5, %edi
      9c:      	movl	$0xb5, %eax
      a1:      	movl	$0x5, %edi
      a6:      	xorl	%ecx, %ecx
      a8:      	callq	*%rax
      aa:      	xorl	%eax, %eax
      ac:      	addq	$0x20, %rsp
      b0:      	popq	%rbx
      b1:      	retq
      b2:      	nopw	%cs:(%rax,%rax)

00000000000000c0 <generic_sleepable_preload_cleanup>:
      c0:      	pushq	%rax
      c1:      	movl	$0xe, %eax
      c6:      	callq	*%rax
      c8:      	movq	%rax, (%rsp)
      cc:      	movq	(%rip), %rdi            # 0xd3 <generic_sleepable_preload_cleanup+0x13>
      d3:      	movq	%rsp, %rsi
      d6:      	movl	$0x3, %eax
      db:      	callq	*%rax
      dd:      	xorl	%eax, %eax
      df:      	popq	%rcx
      e0:      	retq
      e1:      	nopw	%cs:(%rax,%rax)

00000000000000f0 <generic_sleepable_offload>:
      f0:      	pushq	%rbp
      f1:      	pushq	%r15
      f3:      	pushq	%r14
      f5:      	pushq	%r13
      f7:      	pushq	%r12
      f9:      	pushq	%rbx
      fa:      	subq	$0x18, %rsp
      fe:      	movq	%rdi, %rbx
     101:      	movq	$0x0, 0x8(%rsp)
     10a:      	movl	$0xe, %eax
     10f:      	callq	*%rax
     111:      	movq	%rax, 0x10(%rsp)
     116:      	movq	(%rip), %rdi            # 0x11d <generic_sleepable_offload+0x2d>
     11d:      	leaq	0x10(%rsp), %rsi
     122:      	movl	$0x1, %eax
     127:      	callq	*%rax
     129:      	testq	%rax, %rax
     12c:      	je	0x2a3 <generic_sleepable_offload+0x1b3>
     132:      	movq	%rax, %r14
     135:      	movq	(%rip), %rdi            # 0x13c <generic_sleepable_offload+0x4c>
     13c:      	leaq	0x10(%rsp), %rsi
     141:      	movl	$0x3, %eax
     146:      	callq	*%rax
     148:      	movq	(%rip), %rdi            # 0x14f <generic_sleepable_offload+0x5f>
     14f:      	movl	$0x1, %eax
     154:      	movq	%r14, %rsi
     157:      	callq	*%rax
     159:      	testq	%rax, %rax
     15c:      	je	0x2a3 <generic_sleepable_offload+0x1b3>
     162:      	movq	%rax, %r14
     165:      	movq	%rax, %r12
     168:      	addq	$0x8, %r12
     16c:      	xorl	%r13d, %r13d
     16f:      	leaq	0x8(%rsp), %r15
     174:      	movl	$0x8, %ebp
     179:      	jmp	0x1ca <generic_sleepable_offload+0xda>
     17b:      	movzwl	-0x6(%r12), %esi
     181:      	movzbl	-0x2(%r12), %eax
     187:      	shlb	$0x3, %al
     18a:      	movb	$0x40, %cl
     18c:      	subb	%al, %cl
     18e:      	movzbl	%cl, %edx
     191:      	movq	%rbx, %rdi
     194:      	callq	0x199 <generic_sleepable_offload+0xa9>
     199:      	addq	(%r12), %rax
     19d:      	movq	%rax, 0x8(%rsp)
     1a2:      	movzwl	-0x4(%r12), %esi
     1a8:      	movzbl	-0x1(%r12), %edx
     1ae:      	movq	%rbx, %rdi
     1b1:      	movq	%rax, %rcx
     1b4:      	callq	0x1b9 <generic_sleepable_offload+0xc9>
     1b9:      	incq	%r13
     1bc:      	addq	$0x10, %r12
     1c0:      	cmpq	$0x12, %r13
     1c4:      	je	0x2a3 <generic_sleepable_offload+0x1b3>
     1ca:      	movl	0x120(%r14), %eax
     1d1:      	cmpq	%rax, %r13
     1d4:      	jae	0x2a3 <generic_sleepable_offload+0x1b3>
     1da:      	movzbl	-0x8(%r12), %eax
     1e0:      	cmpl	$0x2, %eax
     1e3:      	jg	0x220 <generic_sleepable_offload+0x130>
     1e5:      	cmpl	$0x1, %eax
     1e8:      	je	0x28b <generic_sleepable_offload+0x19b>
     1ee:      	cmpl	$0x2, %eax
     1f1:      	jne	0x1b9 <generic_sleepable_offload+0xc9>
     1f3:      	movzwl	-0x6(%r12), %esi
     1f9:      	movzbl	-0x2(%r12), %eax
     1ff:      	shlb	$0x3, %al
     202:      	movb	$0x40, %cl
     204:      	subb	%al, %cl
     206:      	movzbl	%cl, %edx
     209:      	movq	%rbx, %rdi
     20c:      	callq	0x211 <generic_sleepable_offload+0x121>
     211:      	jmp	0x19d <generic_sleepable_offload+0xad>
     213:      	nopw	%cs:(%rax,%rax)
     220:      	cmpl	$0x3, %eax
     223:      	je	0x17b <generic_sleepable_offload+0x8b>
     229:      	cmpl	$0x4, %eax
     22c:      	jne	0x1b9 <generic_sleepable_offload+0xc9>
     22e:      	movzwl	-0x6(%r12), %esi
     234:      	movzbl	-0x2(%r12), %eax
     23a:      	shlb	$0x3, %al
     23d:      	movb	$0x40, %cl
     23f:      	subb	%al, %cl
     241:      	movzbl	%cl, %edx
     244:      	movq	%rbx, %rdi
     247:      	callq	0x24c <generic_sleepable_offload+0x15c>
     24c:      	movq	%rax, %rcx
     24f:      	movq	%rax, 0x8(%rsp)
     254:      	addq	(%r12), %rcx
     258:      	movl	$0x70, %eax
     25d:      	movq	0x8(%rsp), %rdx
     262:      	addq	(%r12), %rdx
     266:      	movq	%r15, %rdi
     269:      	movl	$0x8, %esi
     26e:      	callq	*%rax
     270:      	testl	%eax, %eax
     272:      	jne	0x1b9 <generic_sleepable_offload+0xc9>
     278:      	movzwl	-0x4(%r12), %esi
     27e:      	movzbl	-0x1(%r12), %edx
     284:      	movq	0x8(%rsp), %rcx
     289:      	jmp	0x29b <generic_sleepable_offload+0x1ab>
     28b:      	movzwl	-0x4(%r12), %esi
     291:      	movzbl	-0x1(%r12), %edx
     297:      	movq	(%r12), %rcx
     29b:      	movq	%rbx, %rdi
     29e:      	jmp	0x1b4 <generic_sleepable_offload+0xc4>
     2a3:      	xorl	%eax, %eax
     2a5:      	addq	$0x18, %rsp
     2a9:      	popq	%rbx
     2aa:      	popq	%r12
     2ac:      	popq	%r13
     2ae:      	popq	%r14
     2b0:      	popq	%r15
     2b2:      	popq	%rbp
     2b3:      	retq
