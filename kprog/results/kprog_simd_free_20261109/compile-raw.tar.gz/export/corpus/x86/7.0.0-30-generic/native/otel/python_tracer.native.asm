
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/otel/python_tracer.native.o:	file format elf64-x86-64

Disassembly of section perf_event/unwind_python:

0000000000000000 <perf_unwind_python>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x98, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x30(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <perf_unwind_python+0x23>
      23:      	leaq	0x30(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x892 <perf_unwind_python+0x892>
      38:      	movq	%rax, %r15
      3b:      	movq	%rax, %rbp
      3e:      	movl	(%r15), %eax
      41:      	movl	%eax, 0x88(%rsp)
      48:      	movq	(%rip), %r14            # 0x4f <perf_unwind_python+0x4f>
      4f:      	cmpl	$0x0, (%r14)
      53:      	jne	0x407 <perf_unwind_python+0x407>
      59:      	movq	(%rip), %rdi            # 0x60 <perf_unwind_python+0x60>
      60:      	leaq	0x88(%rsp), %rsi
      68:      	movl	$0x1, %eax
      6d:      	callq	*%rax
      6f:      	movl	(%r14), %ecx
      72:      	testq	%rax, %rax
      75:      	je	0x134 <perf_unwind_python+0x134>
      7b:      	testl	%ecx, %ecx
      7d:      	jne	0x466 <perf_unwind_python+0x466>
      83:      	leaq	0xf58(%r15), %rsi
      8a:      	movq	0xf58(%rbp), %r13
      91:      	testq	%r13, %r13
      94:      	je	0x4e9 <perf_unwind_python+0x4e9>
      9a:      	xorl	%ecx, %ecx
      9c:      	cmpb	$0x78, 0x19(%rax)
      a0:      	ja	0x169 <perf_unwind_python+0x169>
      a6:      	cmpb	$0x78, 0x18(%rax)
      aa:      	ja	0x169 <perf_unwind_python+0x169>
      b0:      	cmpb	$0x78, 0x1a(%rax)
      b4:      	ja	0x169 <perf_unwind_python+0x169>
      ba:      	cmpb	$0x0, 0x1b(%rax)
      be:      	js	0x169 <perf_unwind_python+0x169>
      c4:      	movq	%rsi, 0x10(%rsp)
      c9:      	movq	%rax, (%rsp)
      cd:      	leaq	0xf80(%r15), %r12
      d4:      	movl	$0x80, %eax
      d9:      	movl	$0x70, %ecx
      de:      	movq	%r12, %rdi
      e1:      	movl	$0x80, %esi
      e6:      	movq	%r13, %rdx
      e9:      	callq	*%rcx
      eb:      	testq	%rax, %rax
      ee:      	je	0x198 <perf_unwind_python+0x198>
      f4:      	cmpl	$0x0, (%r14)
      f8:      	jne	0x11b2 <perf_unwind_python+0x11b2>
      fe:      	movl	$0x1b, 0x18(%rsp)
     106:      	movq	(%rip), %rdi            # 0x10d <perf_unwind_python+0x10d>
     10d:      	leaq	0x18(%rsp), %rsi
     112:      	movl	$0x1, %eax
     117:      	callq	*%rax
     119:      	testq	%rax, %rax
     11c:      	je	0x1d8 <perf_unwind_python+0x1d8>
     122:      	incq	(%rax)
     125:      	movq	0x10(%rsp), %rsi
     12a:      	xorl	%ecx, %ecx
     12c:      	movl	$0x7d2, %r12d           # imm = 0x7D2
     132:      	jmp	0x16f <perf_unwind_python+0x16f>
     134:      	testl	%ecx, %ecx
     136:      	jne	0xa51 <perf_unwind_python+0xa51>
     13c:      	movl	$0x45, 0x18(%rsp)
     144:      	movq	(%rip), %rdi            # 0x14b <perf_unwind_python+0x14b>
     14b:      	leaq	0x18(%rsp), %rsi
     150:      	movl	$0x1, %eax
     155:      	callq	*%rax
     157:      	testq	%rax, %rax
     15a:      	je	0x184 <perf_unwind_python+0x184>
     15c:      	incq	(%rax)
     15f:      	movl	$0x7d1, %eax            # imm = 0x7D1
     164:      	jmp	0x897 <perf_unwind_python+0x897>
     169:      	movl	$0x1, %r12d
     16f:      	orb	$0x10, 0x1380(%rbp)
     176:      	movl	%ecx, %r15d
     179:      	movq	%r13, %rdi
     17c:      	movq	%rdi, (%rsi)
     17f:      	jmp	0x7e1 <perf_unwind_python+0x7e1>
     184:      	cmpl	$0x0, (%r14)
     188:      	jne	0xca4 <perf_unwind_python+0xca4>
     18e:      	movl	$0x7d1, %eax            # imm = 0x7D1
     193:      	jmp	0x897 <perf_unwind_python+0x897>
     198:      	movq	(%rsp), %rax
     19c:      	movzbl	0x19(%rax), %ecx
     1a0:      	movq	(%r12,%rcx), %rdx
     1a4:      	movzbl	0x18(%rax), %ecx
     1a8:      	movq	(%r12,%rcx), %rdi
     1ac:      	movq	0x8(%rax), %rcx
     1b0:      	testq	%rcx, %rcx
     1b3:      	je	0x1f7 <perf_unwind_python+0x1f7>
     1b5:      	cmpq	%rcx, %rdx
     1b8:      	jne	0x1f7 <perf_unwind_python+0x1f7>
     1ba:      	movq	0x10(%rsp), %rsi
     1bf:      	xorl	%r12d, %r12d
     1c2:      	movl	$0x1, %ecx
     1c7:      	testq	%rdi, %rdi
     1ca:      	je	0xc43 <perf_unwind_python+0xc43>
     1d0:      	movl	$0x1, %r15d
     1d6:      	jmp	0x17c <perf_unwind_python+0x17c>
     1d8:      	cmpl	$0x0, (%r14)
     1dc:      	movq	0x10(%rsp), %rsi
     1e1:      	movl	$0x0, %ecx
     1e6:      	jne	0x13a7 <perf_unwind_python+0x13a7>
     1ec:      	movl	$0x7d2, %r12d           # imm = 0x7D2
     1f2:      	jmp	0x16f <perf_unwind_python+0x16f>
     1f7:      	cmpb	$0x0, 0x22(%rax)
     1fb:      	movzbl	0x1a(%rax), %ecx
     1ff:      	movq	0x10(%rsp), %rsi
     204:      	movq	%r12, 0x70(%rsp)
     209:      	je	0x249 <perf_unwind_python+0x249>
     20b:      	movq	(%r12,%rcx), %rcx
     20f:      	movzbl	0x21(%rax), %r8d
     214:      	addq	%rdx, %r8
     217:      	subq	%r8, %rcx
     21a:      	leaq	-0x10000001(%rcx), %r8
     221:      	sarl	%ecx
     223:      	cmpq	$-0x10000003, %r8       # imm = 0xEFFFFFFD
     22a:      	movq	%r12, %r8
     22d:      	movl	$0xffffffff, %r12d      # imm = 0xFFFFFFFF
     233:      	cmovael	%ecx, %r12d
     237:      	movzbl	0x1b(%rax), %ecx
     23b:      	movzbl	(%r8,%rcx), %ecx
     240:      	cmpb	0x1c(%rax), %cl
     243:      	sete	%r8b
     247:      	jmp	0x250 <perf_unwind_python+0x250>
     249:      	movl	(%r12,%rcx), %r12d
     24d:      	xorl	%r8d, %r8d
     250:      	addq	$0x1000, %r15           # imm = 0x1000
     257:      	testq	%rdx, %rdx
     25a:      	movl	$0x0, %ecx
     25f:      	je	0x2f5 <perf_unwind_python+0x2f5>
     265:      	cmpb	$-0x44, 0x1d(%rax)
     269:      	ja	0xc33 <perf_unwind_python+0xc33>
     26f:      	cmpb	$-0x44, 0x1e(%rax)
     273:      	ja	0xc33 <perf_unwind_python+0xc33>
     279:      	cmpb	$-0x44, 0x1f(%rax)
     27d:      	ja	0xc33 <perf_unwind_python+0xc33>
     283:      	cmpb	$-0x44, 0x20(%rax)
     287:      	ja	0xc33 <perf_unwind_python+0xc33>
     28d:      	movl	%r8d, 0x8(%rsp)
     292:      	movq	%rdi, %r13
     295:      	movl	$0xc0, %eax
     29a:      	movl	$0x70, %ecx
     29f:      	movq	%r15, %rdi
     2a2:      	movl	$0xc0, %esi
     2a7:      	movq	%rdx, 0x28(%rsp)
     2ac:      	callq	*%rcx
     2ae:      	testq	%rax, %rax
     2b1:      	je	0xac1 <perf_unwind_python+0xac1>
     2b7:      	movq	%rbx, 0x8(%rsp)
     2bc:      	movq	%r14, %rbx
     2bf:      	cmpl	$0x0, (%r14)
     2c3:      	jne	0x1aff <perf_unwind_python+0x1aff>
     2c9:      	movl	$0x1e, 0x18(%rsp)
     2d1:      	movq	(%rip), %rdi            # 0x2d8 <perf_unwind_python+0x2d8>
     2d8:      	leaq	0x18(%rsp), %rsi
     2dd:      	movl	$0x1, %eax
     2e2:      	callq	*%rax
     2e4:      	testq	%rax, %rax
     2e7:      	je	0xd6f <perf_unwind_python+0xd6f>
     2ed:      	incq	(%rax)
     2f0:      	jmp	0xd78 <perf_unwind_python+0xd78>
     2f5:      	movl	%r8d, 0x8(%rsp)
     2fa:      	movq	%rdi, %r12
     2fd:      	cmpl	$0x0, (%r14)
     301:      	jne	0x15db <perf_unwind_python+0x15db>
     307:      	movl	$0x1c, 0x18(%rsp)
     30f:      	movq	(%rip), %rdi            # 0x316 <perf_unwind_python+0x316>
     316:      	leaq	0x18(%rsp), %rsi
     31b:      	movl	$0x1, %eax
     320:      	callq	*%rax
     322:      	testq	%rax, %rax
     325:      	je	0x32f <perf_unwind_python+0x32f>
     327:      	incq	(%rax)
     32a:      	movq	%r12, %r13
     32d:      	jmp	0x33c <perf_unwind_python+0x33c>
     32f:      	cmpl	$0x0, (%r14)
     333:      	movq	%r12, %r13
     336:      	jne	0x17fc <perf_unwind_python+0x17fc>
     33c:      	movq	$-0x2, %r12
     343:      	xorl	%edx, %edx
     345:      	cmpl	$0x0, (%r14)
     349:      	jne	0xb08 <perf_unwind_python+0xb08>
     34f:      	movl	0x2c0(%rbp), %eax
     355:      	cmpq	$0x7f, %rax
     359:      	jb	0xb72 <perf_unwind_python+0xb72>
     35f:      	cmpl	$0x0, (%r14)
     363:      	jne	0x1662 <perf_unwind_python+0x1662>
     369:      	movl	$0x2, 0x18(%rsp)
     371:      	movq	(%rip), %rdi            # 0x378 <perf_unwind_python+0x378>
     378:      	leaq	0x18(%rsp), %rsi
     37d:      	movl	$0x1, %eax
     382:      	callq	*%rax
     384:      	testq	%rax, %rax
     387:      	je	0x447 <perf_unwind_python+0x447>
     38d:      	incq	(%rax)
     390:      	movq	0x10(%rsp), %rsi
     395:      	xorl	%ecx, %ecx
     397:      	cmpl	$0x0, (%r14)
     39b:      	movl	$0x2, %r12d
     3a1:      	je	0x16f <perf_unwind_python+0x16f>
     3a7:      	movabsq	$0xa656d61726620, %rax  # imm = 0xA656D61726620
     3b1:      	movq	%rax, 0x45(%rsp)
     3b6:      	movabsq	$0x7266206e6f687479, %rax # imm = 0x7266206E6F687479
     3c0:      	movq	%rax, 0x40(%rsp)
     3c5:      	movabsq	$0x702068737570206f, %rax # imm = 0x702068737570206F
     3cf:      	movq	%rax, 0x38(%rsp)
     3d4:      	movabsq	$0x742064656c696166, %rax # imm = 0x742064656C696166
     3de:      	movq	%rax, 0x30(%rsp)
     3e3:      	leaq	0x30(%rsp), %rdi
     3e8:      	movl	$0x1d, %eax
     3ed:      	movl	$0x6, %ecx
     3f2:      	movl	$0x1d, %esi
     3f7:      	xorl	%eax, %eax
     3f9:      	callq	*%rcx
     3fb:      	xorl	%ecx, %ecx
     3fd:      	movq	0x10(%rsp), %rsi
     402:      	jmp	0x16f <perf_unwind_python+0x16f>
     407:      	movabsq	$0xa29286e6f687479, %rax # imm = 0xA29286E6F687479
     411:      	movq	%rax, 0x38(%rsp)
     416:      	movabsq	$0x705f646e69776e75, %rax # imm = 0x705F646E69776E75
     420:      	movq	%rax, 0x30(%rsp)
     425:      	movb	$0x0, 0x40(%rsp)
     42a:      	leaq	0x30(%rsp), %rdi
     42f:      	movl	$0x11, %eax
     434:      	movl	$0x6, %ecx
     439:      	movl	$0x11, %esi
     43e:      	xorl	%eax, %eax
     440:      	callq	*%rcx
     442:      	jmp	0x59 <perf_unwind_python+0x59>
     447:      	cmpl	$0x0, (%r14)
     44b:      	movq	0x10(%rsp), %rsi
     450:      	movl	$0x0, %ecx
     455:      	jne	0x1901 <perf_unwind_python+0x1901>
     45b:      	movl	$0x2, %r12d
     461:      	jmp	0x16f <perf_unwind_python+0x16f>
     466:      	movabsq	$0xa782578302072, %rcx  # imm = 0xA782578302072
     470:      	movq	%rcx, 0x48(%rsp)
     475:      	movabsq	$0x6f66206b63617473, %rcx # imm = 0x6F66206B63617473
     47f:      	movq	%rcx, 0x40(%rsp)
     484:      	movabsq	$0x206e6f6874795020, %rcx # imm = 0x206E6F6874795020
     48e:      	movq	%rcx, 0x38(%rsp)
     493:      	movabsq	$0x676e69646c697542, %rcx # imm = 0x676E69646C697542
     49d:      	movq	%rcx, 0x30(%rsp)
     4a2:      	leaq	0x30(%rsp), %rdi
     4a7:      	movl	$0x20, %ecx
     4ac:      	movl	$0x6, %r8d
     4b2:      	movzwl	0x10(%rax), %edx
     4b6:      	movl	$0x20, %esi
     4bb:      	movq	%rbx, %r12
     4be:      	movq	%r14, %rbx
     4c1:      	movq	%rax, %r14
     4c4:      	xorl	%eax, %eax
     4c6:      	callq	*%r8
     4c9:      	movq	%r14, %rax
     4cc:      	movq	%rbx, %r14
     4cf:      	movq	%r12, %rbx
     4d2:      	leaq	0xf58(%r15), %rsi
     4d9:      	movq	0xf58(%rbp), %r13
     4e0:      	testq	%r13, %r13
     4e3:      	jne	0x9a <perf_unwind_python+0x9a>
     4e9:      	movq	%rsi, 0x10(%rsp)
     4ee:      	movq	%rax, %r13
     4f1:      	movl	$0x15, 0x18(%rsp)
     4f9:      	movq	(%rip), %rdi            # 0x500 <perf_unwind_python+0x500>
     500:      	leaq	0x18(%rsp), %rsi
     505:      	movl	$0x1, %eax
     50a:      	callq	*%rax
     50c:      	testq	%rax, %rax
     50f:      	je	0x516 <perf_unwind_python+0x516>
     511:      	incq	(%rax)
     514:      	jmp	0x520 <perf_unwind_python+0x520>
     516:      	cmpl	$0x0, (%r14)
     51a:      	jne	0xd92 <perf_unwind_python+0xd92>
     520:      	movl	$0x23, %eax
     525:      	callq	*%rax
     527:      	movq	(%rip), %rcx            # 0x52e <perf_unwind_python+0x52e>
     52e:      	addq	(%rcx), %rax
     531:      	leaq	0x90(%rsp), %rdi
     539:      	movl	$0x8, %ecx
     53e:      	movl	$0x71, %r8d
     544:      	movl	$0x8, %esi
     549:      	movq	%rax, %rdx
     54c:      	callq	*%r8
     54f:      	movl	(%r14), %ecx
     552:      	testq	%rax, %rax
     555:      	je	0x5ed <perf_unwind_python+0x5ed>
     55b:      	testl	%ecx, %ecx
     55d:      	jne	0xc4b <perf_unwind_python+0xc4b>
     563:      	movl	$0x4, 0x18(%rsp)
     56b:      	movq	(%rip), %rdi            # 0x572 <perf_unwind_python+0x572>
     572:      	leaq	0x18(%rsp), %rsi
     577:      	movl	$0x1, %eax
     57c:      	callq	*%rax
     57e:      	testq	%rax, %rax
     581:      	je	0x66f <perf_unwind_python+0x66f>
     587:      	incq	(%rax)
     58a:      	cmpl	$0x0, (%r14)
     58e:      	je	0x679 <perf_unwind_python+0x679>
     594:      	movabsq	$0xa737365726464, %rax  # imm = 0xA737365726464
     59e:      	movq	%rax, 0x48(%rsp)
     5a3:      	movabsq	$0x6120657361622044, %rax # imm = 0x6120657361622044
     5ad:      	movq	%rax, 0x40(%rsp)
     5b2:      	movabsq	$0x535420746567206f, %rax # imm = 0x535420746567206F
     5bc:      	movq	%rax, 0x38(%rsp)
     5c1:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     5cb:      	movq	%rax, 0x30(%rsp)
     5d0:      	leaq	0x30(%rsp), %rdi
     5d5:      	movl	$0x20, %eax
     5da:      	movl	$0x6, %ecx
     5df:      	movl	$0x20, %esi
     5e4:      	xorl	%eax, %eax
     5e6:      	callq	*%rcx
     5e8:      	jmp	0x679 <perf_unwind_python+0x679>
     5ed:      	movq	%rbp, (%rsp)
     5f1:      	movq	%rbx, %rbp
     5f4:      	movq	%r14, %rbx
     5f7:      	testl	%ecx, %ecx
     5f9:      	jne	0xe0d <perf_unwind_python+0xe0d>
     5ff:      	movq	0x90(%rsp), %r14
     607:      	movq	(%r13), %r12
     60b:      	leaq	0x8c(%rsp), %rdi
     613:      	movl	$0x4, %eax
     618:      	movl	$0x70, %ecx
     61d:      	movl	$0x4, %esi
     622:      	movq	%r12, %rdx
     625:      	callq	*%rcx
     627:      	testq	%rax, %rax
     62a:      	je	0x6b9 <perf_unwind_python+0x6b9>
     630:      	movq	%rbx, %r14
     633:      	cmpl	$0x0, (%rbx)
     636:      	jne	0xefe <perf_unwind_python+0xefe>
     63c:      	movl	$0x46, 0x18(%rsp)
     644:      	movq	(%rip), %rdi            # 0x64b <perf_unwind_python+0x64b>
     64b:      	leaq	0x18(%rsp), %rsi
     650:      	movl	$0x1, %eax
     655:      	callq	*%rax
     657:      	testq	%rax, %rax
     65a:      	movq	%rbp, %rbx
     65d:      	je	0x77c <perf_unwind_python+0x77c>
     663:      	incq	(%rax)
     666:      	movq	(%rsp), %rbp
     66a:      	jmp	0x78a <perf_unwind_python+0x78a>
     66f:      	cmpl	$0x0, (%r14)
     673:      	jne	0xf69 <perf_unwind_python+0xf69>
     679:      	movl	$0x48, 0x18(%rsp)
     681:      	movq	(%rip), %rdi            # 0x688 <perf_unwind_python+0x688>
     688:      	leaq	0x18(%rsp), %rsi
     68d:      	movl	$0x1, %eax
     692:      	callq	*%rax
     694:      	testq	%rax, %rax
     697:      	je	0x69e <perf_unwind_python+0x69e>
     699:      	incq	(%rax)
     69c:      	jmp	0x6a8 <perf_unwind_python+0x6a8>
     69e:      	cmpl	$0x0, (%r14)
     6a2:      	jne	0xfee <perf_unwind_python+0xfee>
     6a8:      	movl	$0x7d8, %r12d           # imm = 0x7D8
     6ae:      	movl	$0x1, %r15d
     6b4:      	jmp	0x7e1 <perf_unwind_python+0x7e1>
     6b9:      	movslq	0x8c(%rsp), %r12
     6c1:      	movswq	0x12(%r13), %rcx
     6c6:      	addq	%rcx, %r14
     6c9:      	movq	%r14, 0x18(%rsp)
     6ce:      	cmpb	$0x0, 0x15(%r13)
     6d3:      	je	0x6fd <perf_unwind_python+0x6fd>
     6d5:      	leaq	0x18(%rsp), %rdi
     6da:      	movl	$0x8, %eax
     6df:      	movl	$0x70, %ecx
     6e4:      	movq	0x18(%rsp), %rdx
     6e9:      	movl	$0x8, %esi
     6ee:      	callq	*%rcx
     6f0:      	testq	%rax, %rax
     6f3:      	movq	%rbx, %r14
     6f6:      	jne	0x746 <perf_unwind_python+0x746>
     6f8:      	movq	0x18(%rsp), %r14
     6fd:      	movq	%r13, %rax
     700:      	movzbl	0x14(%r13), %eax
     705:      	imulq	%r12, %rax
     709:      	addq	%r14, %rax
     70c:      	movq	%rax, 0x18(%rsp)
     711:      	movq	%rbx, %r14
     714:      	cmpl	$0x0, (%rbx)
     717:      	jne	0x1142 <perf_unwind_python+0x1142>
     71d:      	leaq	0x80(%rsp), %rdi
     725:      	movl	$0x8, %ecx
     72a:      	movl	$0x70, %r8d
     730:      	movq	0x18(%rsp), %rdx
     735:      	movl	$0x8, %esi
     73a:      	callq	*%r8
     73d:      	testq	%rax, %rax
     740:      	je	0x8a9 <perf_unwind_python+0x8a9>
     746:      	cmpl	$0x0, (%r14)
     74a:      	jne	0x1069 <perf_unwind_python+0x1069>
     750:      	movl	$0x3, 0x7c(%rsp)
     758:      	movq	(%rip), %rdi            # 0x75f <perf_unwind_python+0x75f>
     75f:      	leaq	0x7c(%rsp), %rsi
     764:      	movl	$0x1, %eax
     769:      	callq	*%rax
     76b:      	testq	%rax, %rax
     76e:      	movq	%rbp, %rbx
     771:      	je	0x798 <perf_unwind_python+0x798>
     773:      	incq	(%rax)
     776:      	movq	(%rsp), %rbp
     77a:      	jmp	0x7a6 <perf_unwind_python+0x7a6>
     77c:      	cmpl	$0x0, (%r14)
     780:      	movq	(%rsp), %rbp
     784:      	jne	0x10c7 <perf_unwind_python+0x10c7>
     78a:      	movl	$0x7d7, %r12d           # imm = 0x7D7
     790:      	movl	$0x1, %r15d
     796:      	jmp	0x7e1 <perf_unwind_python+0x7e1>
     798:      	cmpl	$0x0, (%r14)
     79c:      	movq	(%rsp), %rbp
     7a0:      	jne	0x1259 <perf_unwind_python+0x1259>
     7a6:      	movl	$0x47, 0x18(%rsp)
     7ae:      	movq	(%rip), %rdi            # 0x7b5 <perf_unwind_python+0x7b5>
     7b5:      	leaq	0x18(%rsp), %rsi
     7ba:      	movl	$0x1, %eax
     7bf:      	callq	*%rax
     7c1:      	testq	%rax, %rax
     7c4:      	je	0x7cb <perf_unwind_python+0x7cb>
     7c6:      	incq	(%rax)
     7c9:      	jmp	0x7d5 <perf_unwind_python+0x7d5>
     7cb:      	cmpl	$0x0, (%r14)
     7cf:      	jne	0x12d4 <perf_unwind_python+0x12d4>
     7d5:      	movl	$0x7d4, %r12d           # imm = 0x7D4
     7db:      	movl	$0x1, %r15d
     7e1:      	movl	%r12d, 0xf2c(%rbp)
     7e8:      	movl	$0x0, 0x30(%rsp)
     7f0:      	movq	(%rip), %rdi            # 0x7f7 <perf_unwind_python+0x7f7>
     7f7:      	leaq	0x30(%rsp), %rsi
     7fc:      	movl	$0x1, %eax
     801:      	callq	*%rax
     803:      	testq	%rax, %rax
     806:      	je	0x846 <perf_unwind_python+0x846>
     808:      	movzbl	0x1384(%rax), %ecx
     80f:      	cmpb	$0x1d, %cl
     812:      	jb	0x873 <perf_unwind_python+0x873>
     814:      	movq	%rax, %r15
     817:      	movl	$0x5, 0xf2c(%rax)
     821:      	movl	$0x44, 0x18(%rsp)
     829:      	movq	(%rip), %rdi            # 0x830 <perf_unwind_python+0x830>
     830:      	leaq	0x18(%rsp), %rsi
     835:      	movl	$0x1, %eax
     83a:      	callq	*%rax
     83c:      	testq	%rax, %rax
     83f:      	je	0x85b <perf_unwind_python+0x85b>
     841:      	incq	(%rax)
     844:      	jmp	0x865 <perf_unwind_python+0x865>
     846:      	movq	(%rip), %rsi            # 0x84d <perf_unwind_python+0x84d>
     84d:      	xorl	%eax, %eax
     84f:      	movl	$0xc, %ecx
     854:      	movq	%rbx, %rdi
     857:      	xorl	%edx, %edx
     859:      	jmp	0x890 <perf_unwind_python+0x890>
     85b:      	cmpl	$0x0, (%r14)
     85f:      	jne	0xe83 <perf_unwind_python+0xe83>
     865:      	movq	%r15, %rax
     868:      	movzbl	0x1384(%r15), %ecx
     870:      	xorl	%r15d, %r15d
     873:      	incb	%cl
     875:      	movb	%cl, 0x1384(%rax)
     87b:      	movl	%r15d, %eax
     87e:      	movq	(%rip), %rsi            # 0x885 <perf_unwind_python+0x885>
     885:      	movl	$0xc, %ecx
     88a:      	movq	%rbx, %rdi
     88d:      	movl	%r15d, %edx
     890:      	callq	*%rcx
     892:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     897:      	addq	$0x98, %rsp
     89e:      	popq	%rbx
     89f:      	popq	%r12
     8a1:      	popq	%r13
     8a3:      	popq	%r14
     8a5:      	popq	%r15
     8a7:      	popq	%rbp
     8a8:      	retq
     8a9:      	movq	0x80(%rsp), %rax
     8b1:      	testq	%rax, %rax
     8b4:      	je	0x925 <perf_unwind_python+0x925>
     8b6:      	movzbl	0x16(%r13), %edx
     8bb:      	addq	%rdx, %rax
     8be:      	movl	$0x8, %edx
     8c3:      	movl	$0x70, %r8d
     8c9:      	movq	0x10(%rsp), %rdi
     8ce:      	movzbl	0x16(%r13), %edx
     8d3:      	addq	0x80(%rsp), %rdx
     8db:      	movl	$0x8, %esi
     8e0:      	callq	*%r8
     8e3:      	testq	%rax, %rax
     8e6:      	movq	%rbp, %rbx
     8e9:      	je	0x962 <perf_unwind_python+0x962>
     8eb:      	cmpl	$0x0, (%r14)
     8ef:      	movq	(%rsp), %rbp
     8f3:      	jne	0x1429 <perf_unwind_python+0x1429>
     8f9:      	movl	$0x19, 0x18(%rsp)
     901:      	movq	(%rip), %rdi            # 0x908 <perf_unwind_python+0x908>
     908:      	leaq	0x18(%rsp), %rsi
     90d:      	movl	$0x1, %eax
     912:      	callq	*%rax
     914:      	testq	%rax, %rax
     917:      	je	0x9d0 <perf_unwind_python+0x9d0>
     91d:      	incq	(%rax)
     920:      	jmp	0x9da <perf_unwind_python+0x9da>
     925:      	cmpl	$0x0, (%r14)
     929:      	movq	%rbp, %rbx
     92c:      	jne	0x1591 <perf_unwind_python+0x1591>
     932:      	movl	$0x18, 0x18(%rsp)
     93a:      	movq	(%rip), %rdi            # 0x941 <perf_unwind_python+0x941>
     941:      	leaq	0x18(%rsp), %rsi
     946:      	movl	$0x1, %eax
     94b:      	callq	*%rax
     94d:      	testq	%rax, %rax
     950:      	movq	(%rsp), %rbp
     954:      	je	0xa1b <perf_unwind_python+0xa1b>
     95a:      	incq	(%rax)
     95d:      	jmp	0xa25 <perf_unwind_python+0xa25>
     962:      	movq	%r13, %rax
     965:      	cmpb	$0x0, 0x23(%r13)
     96a:      	movq	(%rsp), %rbp
     96e:      	je	0x9eb <perf_unwind_python+0x9eb>
     970:      	movzbl	0x17(%rax), %ecx
     974:      	movq	0x10(%rsp), %rdi
     979:      	addq	(%rdi), %rcx
     97c:      	movl	$0x8, %edx
     981:      	movl	$0x70, %r8d
     987:      	movzbl	0x17(%rax), %edx
     98b:      	addq	(%rdi), %rdx
     98e:      	movl	$0x8, %esi
     993:      	callq	*%r8
     996:      	movq	%rax, %rcx
     999:      	movq	%r13, %rax
     99c:      	testq	%rcx, %rcx
     99f:      	je	0x9eb <perf_unwind_python+0x9eb>
     9a1:      	cmpl	$0x0, (%r14)
     9a5:      	jne	0x1877 <perf_unwind_python+0x1877>
     9ab:      	movl	$0x43, 0x18(%rsp)
     9b3:      	movq	(%rip), %rdi            # 0x9ba <perf_unwind_python+0x9ba>
     9ba:      	leaq	0x18(%rsp), %rsi
     9bf:      	movl	$0x1, %eax
     9c4:      	callq	*%rax
     9c6:      	testq	%rax, %rax
     9c9:      	je	0xa36 <perf_unwind_python+0xa36>
     9cb:      	incq	(%rax)
     9ce:      	jmp	0xa40 <perf_unwind_python+0xa40>
     9d0:      	cmpl	$0x0, (%r14)
     9d4:      	jne	0x16ca <perf_unwind_python+0x16ca>
     9da:      	movl	$0x7d6, %r12d           # imm = 0x7D6
     9e0:      	movl	$0x1, %r15d
     9e6:      	jmp	0x7e1 <perf_unwind_python+0x7e1>
     9eb:      	movq	0x10(%rsp), %rsi
     9f0:      	movq	(%rsi), %r13
     9f3:      	testq	%r13, %r13
     9f6:      	jne	0x9a <perf_unwind_python+0x9a>
     9fc:      	cmpl	$0x0, (%r14)
     a00:      	jne	0x1a2b <perf_unwind_python+0x1a2b>
     a06:      	orb	$0x10, 0x1380(%rbp)
     a0d:      	xorl	%r12d, %r12d
     a10:      	movl	$0x1, %r15d
     a16:      	jmp	0x7e1 <perf_unwind_python+0x7e1>
     a1b:      	cmpl	$0x0, (%r14)
     a1f:      	jne	0x1781 <perf_unwind_python+0x1781>
     a25:      	movl	$0x7d5, %r12d           # imm = 0x7D5
     a2b:      	movl	$0x1, %r15d
     a31:      	jmp	0x7e1 <perf_unwind_python+0x7e1>
     a36:      	cmpl	$0x0, (%r14)
     a3a:      	jne	0x1a84 <perf_unwind_python+0x1a84>
     a40:      	movl	$0x7d3, %r12d           # imm = 0x7D3
     a46:      	movl	$0x1, %r15d
     a4c:      	jmp	0x7e1 <perf_unwind_python+0x7e1>
     a51:      	movabsq	$0x666e692073736572, %rax # imm = 0x666E692073736572
     a5b:      	movq	%rax, 0x50(%rsp)
     a60:      	movabsq	$0x646461206f6e202c, %rax # imm = 0x646461206F6E202C
     a6a:      	movq	%rax, 0x48(%rsp)
     a6f:      	movabsq	$0x6b63617473206e6f, %rax # imm = 0x6B63617473206E6F
     a79:      	movq	%rax, 0x40(%rsp)
     a7e:      	movabsq	$0x6874795020646c69, %rax # imm = 0x6874795020646C69
     a88:      	movq	%rax, 0x38(%rsp)
     a8d:      	movabsq	$0x75622074276e6143, %rax # imm = 0x75622074276E6143
     a97:      	movq	%rax, 0x30(%rsp)
     a9c:      	movl	$0xa6f66, 0x57(%rsp)    # imm = 0xA6F66
     aa4:      	leaq	0x30(%rsp), %rdi
     aa9:      	movl	$0x2b, %eax
     aae:      	movl	$0x6, %ecx
     ab3:      	movl	$0x2b, %esi
     ab8:      	xorl	%eax, %eax
     aba:      	callq	*%rcx
     abc:      	jmp	0x13c <perf_unwind_python+0x13c>
     ac1:      	movq	(%rsp), %rax
     ac5:      	movzbl	0x1d(%rax), %ecx
     ac9:      	movl	(%r15,%rcx), %ecx
     acd:      	movzbl	0x1e(%rax), %edx
     ad1:      	movl	(%r15,%rdx), %edx
     ad5:      	movzbl	0x1f(%rax), %esi
     ad9:      	movl	(%r15,%rsi), %esi
     add:      	movzbl	0x20(%rax), %eax
     ae1:      	shll	$0x19, %ecx
     ae4:      	shll	$0x12, %edx
     ae7:      	addl	%ecx, %edx
     ae9:      	shll	$0xa, %esi
     aec:      	addl	%edx, %esi
     aee:      	addl	(%r15,%rax), %esi
     af2:      	shlq	$0x20, %r12
     af6:      	orq	%rsi, %r12
     af9:      	movq	0x28(%rsp), %rdx
     afe:      	cmpl	$0x0, (%r14)
     b02:      	je	0x34f <perf_unwind_python+0x34f>
     b08:      	movabsq	$0xa756c2520786c, %rax  # imm = 0xA756C2520786C
     b12:      	movq	%rax, 0x40(%rsp)
     b17:      	movabsq	$0x25206e6f68747950, %rax # imm = 0x25206E6F68747950
     b21:      	movq	%rax, 0x38(%rsp)
     b26:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
     b30:      	movq	%rax, 0x30(%rsp)
     b35:      	movq	%r13, 0x20(%rsp)
     b3a:      	leaq	0x30(%rsp), %rdi
     b3f:      	movl	$0x18, %eax
     b44:      	movl	$0x6, %r8d
     b4a:      	movl	$0x18, %esi
     b4f:      	movq	%r12, %rcx
     b52:      	xorl	%eax, %eax
     b54:      	movq	%rdx, %r13
     b57:      	callq	*%r8
     b5a:      	movq	%r13, %rdx
     b5d:      	movq	0x20(%rsp), %r13
     b62:      	movl	0x2c0(%rbp), %eax
     b68:      	cmpq	$0x7f, %rax
     b6c:      	jae	0x35f <perf_unwind_python+0x35f>
     b72:      	movq	%r13, 0x20(%rsp)
     b77:      	leal	0x1(%rax), %ecx
     b7a:      	movl	%ecx, 0x2c0(%rbp)
     b80:      	leaq	(%rax,%rax,2), %rax
     b84:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
     b8c:      	movq	%r12, 0x2d8(%rbp,%rax,8)
     b94:      	movb	$0x1, 0x2e0(%rbp,%rax,8)
     b9c:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
     ba7:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
     bb2:      	movl	$0x16, 0x18(%rsp)
     bba:      	movq	(%rip), %rdi            # 0xbc1 <perf_unwind_python+0xbc1>
     bc1:      	leaq	0x18(%rsp), %rsi
     bc6:      	movl	$0x1, %eax
     bcb:      	callq	*%rax
     bcd:      	testq	%rax, %rax
     bd0:      	je	0xbf3 <perf_unwind_python+0xbf3>
     bd2:      	incq	(%rax)
     bd5:      	movq	(%rsp), %rax
     bd9:      	movq	0x10(%rsp), %rsi
     bde:      	movl	0x8(%rsp), %r8d
     be3:      	testb	%r8b, %r8b
     be6:      	movq	0x20(%rsp), %rdi
     beb:      	jne	0x1bf <perf_unwind_python+0x1bf>
     bf1:      	jmp	0xc19 <perf_unwind_python+0xc19>
     bf3:      	cmpl	$0x0, (%r14)
     bf7:      	movq	(%rsp), %rax
     bfb:      	movq	0x10(%rsp), %rsi
     c00:      	movl	0x8(%rsp), %r8d
     c05:      	jne	0x1993 <perf_unwind_python+0x1993>
     c0b:      	testb	%r8b, %r8b
     c0e:      	movq	0x20(%rsp), %rdi
     c13:      	jne	0x1bf <perf_unwind_python+0x1bf>
     c19:      	xorl	%r12d, %r12d
     c1c:      	testq	%rdi, %rdi
     c1f:      	je	0xc41 <perf_unwind_python+0xc41>
     c21:      	cmpb	$0x78, 0x19(%rax)
     c25:      	ja	0xc31 <perf_unwind_python+0xc31>
     c27:      	cmpb	$0x78, 0x18(%rax)
     c2b:      	jbe	0xd1f <perf_unwind_python+0xd1f>
     c31:      	xorl	%ecx, %ecx
     c33:      	movq	%rdi, %r13
     c36:      	movl	$0x1, %r12d
     c3c:      	jmp	0x16f <perf_unwind_python+0x16f>
     c41:      	xorl	%ecx, %ecx
     c43:      	xorl	%r13d, %r13d
     c46:      	jmp	0x16f <perf_unwind_python+0x16f>
     c4b:      	movabsq	$0xa65756c617620, %rax  # imm = 0xA65756C617620
     c55:      	movq	%rax, 0x45(%rsp)
     c5a:      	movabsq	$0x6176206573616270, %rax # imm = 0x6176206573616270
     c64:      	movq	%rax, 0x40(%rsp)
     c69:      	movabsq	$0x742064616572206f, %rax # imm = 0x742064616572206F
     c73:      	movq	%rax, 0x38(%rsp)
     c78:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     c82:      	movq	%rax, 0x30(%rsp)
     c87:      	leaq	0x30(%rsp), %rdi
     c8c:      	movl	$0x1d, %eax
     c91:      	movl	$0x6, %ecx
     c96:      	movl	$0x1d, %esi
     c9b:      	xorl	%eax, %eax
     c9d:      	callq	*%rcx
     c9f:      	jmp	0x563 <perf_unwind_python+0x563>
     ca4:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     cae:      	movq	%rax, 0x56(%rsp)
     cb3:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     cbd:      	movq	%rax, 0x50(%rsp)
     cc2:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     ccc:      	movq	%rax, 0x48(%rsp)
     cd1:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     cdb:      	movq	%rax, 0x40(%rsp)
     ce0:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     cea:      	movq	%rax, 0x38(%rsp)
     cef:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     cf9:      	movq	%rax, 0x30(%rsp)
     cfe:      	leaq	0x30(%rsp), %rdi
     d03:      	movl	$0x2e, %eax
     d08:      	movl	$0x6, %ecx
     d0d:      	movl	0x18(%rsp), %edx
     d11:      	movl	$0x2e, %esi
     d16:      	xorl	%eax, %eax
     d18:      	callq	*%rcx
     d1a:      	jmp	0x18e <perf_unwind_python+0x18e>
     d1f:      	movq	%rbx, 0x8(%rsp)
     d24:      	cmpb	$0x78, 0x1a(%rax)
     d28:      	ja	0x45a2 <perf_unwind_python+0x45a2>
     d2e:      	movq	(%rsp), %rax
     d32:      	cmpb	$0x0, 0x1b(%rax)
     d36:      	js	0x45a2 <perf_unwind_python+0x45a2>
     d3c:      	movl	$0x80, %eax
     d41:      	movl	$0x70, %ecx
     d46:      	movq	0x70(%rsp), %rdi
     d4b:      	movq	0x20(%rsp), %rdx
     d50:      	movl	$0x80, %esi
     d55:      	callq	*%rcx
     d57:      	testq	%rax, %rax
     d5a:      	je	0x1216 <perf_unwind_python+0x1216>
     d60:      	movq	0x20(%rsp), %r13
     d65:      	movq	0x8(%rsp), %rbx
     d6a:      	jmp	0xf4 <perf_unwind_python+0xf4>
     d6f:      	cmpl	$0x0, (%rbx)
     d72:      	jne	0x1b6c <perf_unwind_python+0x1b6c>
     d78:      	movl	$0x7d0, %r12d           # imm = 0x7D0
     d7e:      	movq	%rbx, %r14
     d81:      	movq	0x8(%rsp), %rbx
     d86:      	movq	0x10(%rsp), %rsi
     d8b:      	xorl	%ecx, %ecx
     d8d:      	jmp	0x16f <perf_unwind_python+0x16f>
     d92:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     d9c:      	movq	%rax, 0x56(%rsp)
     da1:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     dab:      	movq	%rax, 0x50(%rsp)
     db0:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     dba:      	movq	%rax, 0x48(%rsp)
     dbf:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     dc9:      	movq	%rax, 0x40(%rsp)
     dce:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     dd8:      	movq	%rax, 0x38(%rsp)
     ddd:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     de7:      	movq	%rax, 0x30(%rsp)
     dec:      	leaq	0x30(%rsp), %rdi
     df1:      	movl	$0x2e, %eax
     df6:      	movl	$0x6, %ecx
     dfb:      	movl	0x18(%rsp), %edx
     dff:      	movl	$0x2e, %esi
     e04:      	xorl	%eax, %eax
     e06:      	callq	*%rcx
     e08:      	jmp	0x520 <perf_unwind_python+0x520>
     e0d:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
     e17:      	movq	%rax, 0x4e(%rsp)
     e1c:      	movabsq	$0x3020726464417965, %rax # imm = 0x3020726464417965
     e26:      	movq	%rax, 0x48(%rsp)
     e2b:      	movabsq	$0x4b534c546f747561, %rax # imm = 0x4B534C546F747561
     e35:      	movq	%rax, 0x40(%rsp)
     e3a:      	movabsq	$0x202c786c25783020, %rax # imm = 0x202C786C25783020
     e44:      	movq	%rax, 0x38(%rsp)
     e49:      	movabsq	$0x6573614220445354, %rax # imm = 0x6573614220445354
     e53:      	movq	%rax, 0x30(%rsp)
     e58:      	leaq	0x30(%rsp), %rdi
     e5d:      	movl	$0x26, %eax
     e62:      	movl	$0x6, %r8d
     e68:      	movq	0x90(%rsp), %rdx
     e70:      	movq	(%r13), %rcx
     e74:      	movl	$0x26, %esi
     e79:      	xorl	%eax, %eax
     e7b:      	callq	*%r8
     e7e:      	jmp	0x5ff <perf_unwind_python+0x5ff>
     e83:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     e8d:      	movq	%rax, 0x56(%rsp)
     e92:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     e9c:      	movq	%rax, 0x50(%rsp)
     ea1:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     eab:      	movq	%rax, 0x48(%rsp)
     eb0:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     eba:      	movq	%rax, 0x40(%rsp)
     ebf:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     ec9:      	movq	%rax, 0x38(%rsp)
     ece:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     ed8:      	movq	%rax, 0x30(%rsp)
     edd:      	leaq	0x30(%rsp), %rdi
     ee2:      	movl	$0x2e, %eax
     ee7:      	movl	$0x6, %ecx
     eec:      	movl	0x18(%rsp), %edx
     ef0:      	movl	$0x2e, %esi
     ef5:      	xorl	%eax, %eax
     ef7:      	callq	*%rcx
     ef9:      	jmp	0x865 <perf_unwind_python+0x865>
     efe:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
     f08:      	movq	%rax, 0x4e(%rsp)
     f0d:      	movabsq	$0x30206d6f72662079, %rax # imm = 0x30206D6F72662079
     f17:      	movq	%rax, 0x48(%rsp)
     f1c:      	movabsq	$0x656b534c546f7475, %rax # imm = 0x656B534C546F7475
     f26:      	movq	%rax, 0x40(%rsp)
     f2b:      	movabsq	$0x612064616572206f, %rax # imm = 0x612064616572206F
     f35:      	movq	%rax, 0x38(%rsp)
     f3a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     f44:      	movq	%rax, 0x30(%rsp)
     f49:      	leaq	0x30(%rsp), %rdi
     f4e:      	movl	$0x26, %eax
     f53:      	movl	$0x6, %ecx
     f58:      	movl	$0x26, %esi
     f5d:      	movq	%r12, %rdx
     f60:      	xorl	%eax, %eax
     f62:      	callq	*%rcx
     f64:      	jmp	0x63c <perf_unwind_python+0x63c>
     f69:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     f73:      	movq	%rax, 0x56(%rsp)
     f78:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     f82:      	movq	%rax, 0x50(%rsp)
     f87:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     f91:      	movq	%rax, 0x48(%rsp)
     f96:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     fa0:      	movq	%rax, 0x40(%rsp)
     fa5:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     faf:      	movq	%rax, 0x38(%rsp)
     fb4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     fbe:      	movq	%rax, 0x30(%rsp)
     fc3:      	leaq	0x30(%rsp), %rdi
     fc8:      	movl	$0x2e, %eax
     fcd:      	movl	$0x6, %ecx
     fd2:      	movl	0x18(%rsp), %edx
     fd6:      	movl	$0x2e, %esi
     fdb:      	xorl	%eax, %eax
     fdd:      	callq	*%rcx
     fdf:      	cmpl	$0x0, (%r14)
     fe3:      	je	0x679 <perf_unwind_python+0x679>
     fe9:      	jmp	0x594 <perf_unwind_python+0x594>
     fee:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     ff8:      	movq	%rax, 0x56(%rsp)
     ffd:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1007:      	movq	%rax, 0x50(%rsp)
    100c:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1016:      	movq	%rax, 0x48(%rsp)
    101b:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1025:      	movq	%rax, 0x40(%rsp)
    102a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1034:      	movq	%rax, 0x38(%rsp)
    1039:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1043:      	movq	%rax, 0x30(%rsp)
    1048:      	leaq	0x30(%rsp), %rdi
    104d:      	movl	$0x2e, %eax
    1052:      	movl	$0x6, %ecx
    1057:      	movl	0x18(%rsp), %edx
    105b:      	movl	$0x2e, %esi
    1060:      	xorl	%eax, %eax
    1062:      	callq	*%rcx
    1064:      	jmp	0x6a8 <perf_unwind_python+0x6a8>
    1069:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    1073:      	movq	%rax, 0x47(%rsp)
    1078:      	movabsq	$0x206d6f7266204453, %rax # imm = 0x206D6F7266204453
    1082:      	movq	%rax, 0x40(%rsp)
    1087:      	movabsq	$0x542064616572206f, %rax # imm = 0x542064616572206F
    1091:      	movq	%rax, 0x38(%rsp)
    1096:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    10a0:      	movq	%rax, 0x30(%rsp)
    10a5:      	leaq	0x30(%rsp), %rdi
    10aa:      	movl	$0x1f, %eax
    10af:      	movl	$0x6, %ecx
    10b4:      	movq	0x18(%rsp), %rdx
    10b9:      	movl	$0x1f, %esi
    10be:      	xorl	%eax, %eax
    10c0:      	callq	*%rcx
    10c2:      	jmp	0x750 <perf_unwind_python+0x750>
    10c7:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    10d1:      	movq	%rax, 0x56(%rsp)
    10d6:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    10e0:      	movq	%rax, 0x50(%rsp)
    10e5:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    10ef:      	movq	%rax, 0x48(%rsp)
    10f4:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    10fe:      	movq	%rax, 0x40(%rsp)
    1103:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    110d:      	movq	%rax, 0x38(%rsp)
    1112:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    111c:      	movq	%rax, 0x30(%rsp)
    1121:      	leaq	0x30(%rsp), %rdi
    1126:      	movl	$0x2e, %eax
    112b:      	movl	$0x6, %ecx
    1130:      	movl	0x18(%rsp), %edx
    1134:      	movl	$0x2e, %esi
    1139:      	xorl	%eax, %eax
    113b:      	callq	*%rcx
    113d:      	jmp	0x78a <perf_unwind_python+0x78a>
    1142:      	movabsq	$0x6c25783020737365, %rax # imm = 0x6C25783020737365
    114c:      	movq	%rax, 0x48(%rsp)
    1151:      	movabsq	$0x72646461206d6f72, %rax # imm = 0x72646461206D6F72
    115b:      	movq	%rax, 0x40(%rsp)
    1160:      	movabsq	$0x662064252079656b, %rax # imm = 0x662064252079656B
    116a:      	movq	%rax, 0x38(%rsp)
    116f:      	movabsq	$0x2044535464616572, %rax # imm = 0x2044535464616572
    1179:      	movq	%rax, 0x30(%rsp)
    117e:      	movl	$0xa786c, 0x4f(%rsp)    # imm = 0xA786C
    1186:      	leaq	0x30(%rsp), %rdi
    118b:      	movl	$0x23, %eax
    1190:      	movl	$0x6, %r8d
    1196:      	movq	0x18(%rsp), %rcx
    119b:      	movl	$0x23, %esi
    11a0:      	movl	%r12d, %edx
    11a3:      	xorl	%eax, %eax
    11a5:      	callq	*%r8
    11a8:      	movq	0x18(%rsp), %rax
    11ad:      	jmp	0x71d <perf_unwind_python+0x71d>
    11b2:      	movabsq	$0x257830207463656a, %rax # imm = 0x257830207463656A
    11bc:      	movq	%rax, 0x48(%rsp)
    11c1:      	movabsq	$0x624f656d61724679, %rax # imm = 0x624F656D61724679
    11cb:      	movq	%rax, 0x40(%rsp)
    11d0:      	movabsq	$0x502064616572206f, %rax # imm = 0x502064616572206F
    11da:      	movq	%rax, 0x38(%rsp)
    11df:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    11e9:      	movq	%rax, 0x30(%rsp)
    11ee:      	movl	$0xa786c, 0x50(%rsp)    # imm = 0xA786C
    11f6:      	leaq	0x30(%rsp), %rdi
    11fb:      	movl	$0x24, %eax
    1200:      	movl	$0x6, %ecx
    1205:      	movl	$0x24, %esi
    120a:      	movq	%r13, %rdx
    120d:      	xorl	%eax, %eax
    120f:      	callq	*%rcx
    1211:      	jmp	0xfe <perf_unwind_python+0xfe>
    1216:      	movq	(%rsp), %rax
    121a:      	movzbl	0x19(%rax), %ecx
    121e:      	movq	0x70(%rsp), %rdx
    1223:      	movq	(%rdx,%rcx), %rcx
    1227:      	movq	%rcx, 0x28(%rsp)
    122c:      	movzbl	0x18(%rax), %ecx
    1230:      	movq	(%rdx,%rcx), %r13
    1234:      	movq	0x8(%rax), %rax
    1238:      	testq	%rax, %rax
    123b:      	je	0x134f <perf_unwind_python+0x134f>
    1241:      	cmpq	%rax, 0x28(%rsp)
    1246:      	jne	0x134f <perf_unwind_python+0x134f>
    124c:      	movq	%r13, %rdi
    124f:      	movq	0x8(%rsp), %rbx
    1254:      	jmp	0x1ba <perf_unwind_python+0x1ba>
    1259:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1263:      	movq	%rax, 0x56(%rsp)
    1268:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1272:      	movq	%rax, 0x50(%rsp)
    1277:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1281:      	movq	%rax, 0x48(%rsp)
    1286:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1290:      	movq	%rax, 0x40(%rsp)
    1295:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    129f:      	movq	%rax, 0x38(%rsp)
    12a4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    12ae:      	movq	%rax, 0x30(%rsp)
    12b3:      	leaq	0x30(%rsp), %rdi
    12b8:      	movl	$0x2e, %eax
    12bd:      	movl	$0x6, %ecx
    12c2:      	movl	0x7c(%rsp), %edx
    12c6:      	movl	$0x2e, %esi
    12cb:      	xorl	%eax, %eax
    12cd:      	callq	*%rcx
    12cf:      	jmp	0x7a6 <perf_unwind_python+0x7a6>
    12d4:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    12de:      	movq	%rax, 0x56(%rsp)
    12e3:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    12ed:      	movq	%rax, 0x50(%rsp)
    12f2:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    12fc:      	movq	%rax, 0x48(%rsp)
    1301:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    130b:      	movq	%rax, 0x40(%rsp)
    1310:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    131a:      	movq	%rax, 0x38(%rsp)
    131f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1329:      	movq	%rax, 0x30(%rsp)
    132e:      	leaq	0x30(%rsp), %rdi
    1333:      	movl	$0x2e, %eax
    1338:      	movl	$0x6, %ecx
    133d:      	movl	0x18(%rsp), %edx
    1341:      	movl	$0x2e, %esi
    1346:      	xorl	%eax, %eax
    1348:      	callq	*%rcx
    134a:      	jmp	0x7d5 <perf_unwind_python+0x7d5>
    134f:      	movq	(%rsp), %rax
    1353:      	cmpb	$0x0, 0x22(%rax)
    1357:      	movzbl	0x1a(%rax), %eax
    135b:      	je	0x14ad <perf_unwind_python+0x14ad>
    1361:      	movq	0x70(%rsp), %rsi
    1366:      	movq	(%rsi,%rax), %rax
    136a:      	movq	(%rsp), %rcx
    136e:      	movzbl	0x21(%rcx), %edx
    1372:      	addq	0x28(%rsp), %rdx
    1377:      	subq	%rdx, %rax
    137a:      	leaq	-0x10000001(%rax), %rdx
    1381:      	sarl	%eax
    1383:      	cmpq	$-0x10000003, %rdx      # imm = 0xEFFFFFFD
    138a:      	movl	$0xffffffff, %r12d      # imm = 0xFFFFFFFF
    1390:      	cmovael	%eax, %r12d
    1394:      	movzbl	0x1b(%rcx), %eax
    1398:      	movzbl	(%rsi,%rax), %eax
    139c:      	cmpb	0x1c(%rcx), %al
    139f:      	sete	%bl
    13a2:      	jmp	0x14b8 <perf_unwind_python+0x14b8>
    13a7:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    13b1:      	movq	%rax, 0x56(%rsp)
    13b6:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    13c0:      	movq	%rax, 0x50(%rsp)
    13c5:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    13cf:      	movq	%rax, 0x48(%rsp)
    13d4:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    13de:      	movq	%rax, 0x40(%rsp)
    13e3:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    13ed:      	movq	%rax, 0x38(%rsp)
    13f2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    13fc:      	movq	%rax, 0x30(%rsp)
    1401:      	leaq	0x30(%rsp), %rdi
    1406:      	movl	$0x2e, %eax
    140b:      	movl	$0x6, %ecx
    1410:      	movl	0x18(%rsp), %edx
    1414:      	movl	$0x2e, %esi
    1419:      	xorl	%eax, %eax
    141b:      	callq	*%rcx
    141d:      	xorl	%ecx, %ecx
    141f:      	movq	0x10(%rsp), %rsi
    1424:      	jmp	0x1ec <perf_unwind_python+0x1ec>
    1429:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    1433:      	movq	%rax, 0x55(%rsp)
    1438:      	movabsq	$0x783020746120656d, %rax # imm = 0x783020746120656D
    1442:      	movq	%rax, 0x50(%rsp)
    1447:      	movabsq	$0x6172662e65746174, %rax # imm = 0x6172662E65746174
    1451:      	movq	%rax, 0x48(%rsp)
    1456:      	movabsq	$0x5364616572685479, %rax # imm = 0x5364616572685479
    1460:      	movq	%rax, 0x40(%rsp)
    1465:      	movabsq	$0x502064616572206f, %rax # imm = 0x502064616572206F
    146f:      	movq	%rax, 0x38(%rsp)
    1474:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    147e:      	movq	%rax, 0x30(%rsp)
    1483:      	leaq	0x30(%rsp), %rdi
    1488:      	movl	$0x2d, %eax
    148d:      	movl	$0x6, %ecx
    1492:      	movzbl	0x16(%r13), %edx
    1497:      	addq	0x80(%rsp), %rdx
    149f:      	movl	$0x2d, %esi
    14a4:      	xorl	%eax, %eax
    14a6:      	callq	*%rcx
    14a8:      	jmp	0x8f9 <perf_unwind_python+0x8f9>
    14ad:      	movq	0x70(%rsp), %rcx
    14b2:      	movl	(%rcx,%rax), %r12d
    14b6:      	xorl	%ebx, %ebx
    14b8:      	cmpq	$0x0, 0x28(%rsp)
    14be:      	je	0x155b <perf_unwind_python+0x155b>
    14c4:      	movq	(%rsp), %rax
    14c8:      	cmpb	$-0x44, 0x1d(%rax)
    14cc:      	ja	0x460a <perf_unwind_python+0x460a>
    14d2:      	movq	(%rsp), %rax
    14d6:      	cmpb	$-0x44, 0x1e(%rax)
    14da:      	ja	0x460a <perf_unwind_python+0x460a>
    14e0:      	movq	(%rsp), %rax
    14e4:      	cmpb	$-0x44, 0x1f(%rax)
    14e8:      	ja	0x460a <perf_unwind_python+0x460a>
    14ee:      	movq	(%rsp), %rax
    14f2:      	cmpb	$-0x44, 0x20(%rax)
    14f6:      	ja	0x460a <perf_unwind_python+0x460a>
    14fc:      	movl	$0xc0, %eax
    1501:      	movl	$0x70, %ecx
    1506:      	movq	0x28(%rsp), %rdx
    150b:      	movq	%r15, %rdi
    150e:      	movl	$0xc0, %esi
    1513:      	callq	*%rcx
    1515:      	testq	%rax, %rax
    1518:      	jne	0x2bc <perf_unwind_python+0x2bc>
    151e:      	movq	(%rsp), %rax
    1522:      	movzbl	0x1d(%rax), %ecx
    1526:      	movl	(%r15,%rcx), %ecx
    152a:      	movzbl	0x1e(%rax), %edx
    152e:      	movl	(%r15,%rdx), %edx
    1532:      	movzbl	0x1f(%rax), %esi
    1536:      	movl	(%r15,%rsi), %esi
    153a:      	movzbl	0x20(%rax), %eax
    153e:      	shll	$0x19, %ecx
    1541:      	shll	$0x12, %edx
    1544:      	addl	%ecx, %edx
    1546:      	shll	$0xa, %esi
    1549:      	addl	%edx, %esi
    154b:      	addl	(%r15,%rax), %esi
    154f:      	shlq	$0x20, %r12
    1553:      	orq	%rsi, %r12
    1556:      	jmp	0x175d <perf_unwind_python+0x175d>
    155b:      	cmpl	$0x0, (%r14)
    155f:      	jne	0x1e76 <perf_unwind_python+0x1e76>
    1565:      	movl	$0x1c, 0x18(%rsp)
    156d:      	movq	(%rip), %rdi            # 0x1574 <perf_unwind_python+0x1574>
    1574:      	leaq	0x18(%rsp), %rsi
    1579:      	movl	$0x1, %eax
    157e:      	callq	*%rax
    1580:      	testq	%rax, %rax
    1583:      	je	0x1745 <perf_unwind_python+0x1745>
    1589:      	incq	(%rax)
    158c:      	jmp	0x174f <perf_unwind_python+0x174f>
    1591:      	movabsq	$0xa307830207369, %rax  # imm = 0xA307830207369
    159b:      	movq	%rax, 0x3e(%rsp)
    15a0:      	movabsq	$0x7369206574617453, %rax # imm = 0x7369206574617453
    15aa:      	movq	%rax, 0x38(%rsp)
    15af:      	movabsq	$0x6461657268547950, %rax # imm = 0x6461657268547950
    15b9:      	movq	%rax, 0x30(%rsp)
    15be:      	leaq	0x30(%rsp), %rdi
    15c3:      	movl	$0x16, %eax
    15c8:      	movl	$0x6, %ecx
    15cd:      	movl	$0x16, %esi
    15d2:      	xorl	%eax, %eax
    15d4:      	callq	*%rcx
    15d6:      	jmp	0x932 <perf_unwind_python+0x932>
    15db:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    15e5:      	movq	%rax, 0x57(%rsp)
    15ea:      	movabsq	$0x20786c2578302074, %rax # imm = 0x20786C2578302074
    15f4:      	movq	%rax, 0x50(%rsp)
    15f9:      	movabsq	$0x63656a624f656d61, %rax # imm = 0x63656A624F656D61
    1603:      	movq	%rax, 0x48(%rsp)
    1608:      	movabsq	$0x7246795020726f66, %rax # imm = 0x7246795020726F66
    1612:      	movq	%rax, 0x40(%rsp)
    1617:      	movabsq	$0x207463656a626f65, %rax # imm = 0x207463656A626F65
    1621:      	movq	%rax, 0x38(%rsp)
    1626:      	movabsq	$0x646f63206c6c754e, %rax # imm = 0x646F63206C6C754E
    1630:      	movq	%rax, 0x30(%rsp)
    1635:      	leaq	0x30(%rsp), %rdi
    163a:      	movl	$0x2f, %eax
    163f:      	movl	$0x6, %r8d
    1645:      	movq	(%rsp), %rax
    1649:      	movzbl	0x19(%rax), %ecx
    164d:      	addq	%r13, %rcx
    1650:      	movl	$0x2f, %esi
    1655:      	movq	%r13, %rdx
    1658:      	xorl	%eax, %eax
    165a:      	callq	*%r8
    165d:      	jmp	0x307 <perf_unwind_python+0x307>
    1662:      	movabsq	$0xa6c6c75662073, %rax  # imm = 0xA6C6C75662073
    166c:      	movq	%rax, 0x4d(%rsp)
    1671:      	movabsq	$0x66207369206b6361, %rax # imm = 0x66207369206B6361
    167b:      	movq	%rax, 0x48(%rsp)
    1680:      	movabsq	$0x7473203a656d6172, %rax # imm = 0x7473203A656D6172
    168a:      	movq	%rax, 0x40(%rsp)
    168f:      	movabsq	$0x662068737570206f, %rax # imm = 0x662068737570206F
    1699:      	movq	%rax, 0x38(%rsp)
    169e:      	movabsq	$0x7420656c62616e75, %rax # imm = 0x7420656C62616E75
    16a8:      	movq	%rax, 0x30(%rsp)
    16ad:      	leaq	0x30(%rsp), %rdi
    16b2:      	movl	$0x25, %eax
    16b7:      	movl	$0x6, %ecx
    16bc:      	movl	$0x25, %esi
    16c1:      	xorl	%eax, %eax
    16c3:      	callq	*%rcx
    16c5:      	jmp	0x369 <perf_unwind_python+0x369>
    16ca:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    16d4:      	movq	%rax, 0x56(%rsp)
    16d9:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    16e3:      	movq	%rax, 0x50(%rsp)
    16e8:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    16f2:      	movq	%rax, 0x48(%rsp)
    16f7:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1701:      	movq	%rax, 0x40(%rsp)
    1706:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1710:      	movq	%rax, 0x38(%rsp)
    1715:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    171f:      	movq	%rax, 0x30(%rsp)
    1724:      	leaq	0x30(%rsp), %rdi
    1729:      	movl	$0x2e, %eax
    172e:      	movl	$0x6, %ecx
    1733:      	movl	0x18(%rsp), %edx
    1737:      	movl	$0x2e, %esi
    173c:      	xorl	%eax, %eax
    173e:      	callq	*%rcx
    1740:      	jmp	0x9da <perf_unwind_python+0x9da>
    1745:      	cmpl	$0x0, (%r14)
    1749:      	jne	0x1f40 <perf_unwind_python+0x1f40>
    174f:      	movq	$-0x2, %r12
    1756:      	xorl	%eax, %eax
    1758:      	movq	%rax, 0x28(%rsp)
    175d:      	cmpl	$0x0, (%r14)
    1761:      	jne	0x1be7 <perf_unwind_python+0x1be7>
    1767:      	movl	0x2c0(%rbp), %eax
    176d:      	cmpq	$0x7e, %rax
    1771:      	jbe	0x1c46 <perf_unwind_python+0x1c46>
    1777:      	movq	0x8(%rsp), %rbx
    177c:      	jmp	0x35f <perf_unwind_python+0x35f>
    1781:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    178b:      	movq	%rax, 0x56(%rsp)
    1790:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    179a:      	movq	%rax, 0x50(%rsp)
    179f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    17a9:      	movq	%rax, 0x48(%rsp)
    17ae:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    17b8:      	movq	%rax, 0x40(%rsp)
    17bd:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    17c7:      	movq	%rax, 0x38(%rsp)
    17cc:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    17d6:      	movq	%rax, 0x30(%rsp)
    17db:      	leaq	0x30(%rsp), %rdi
    17e0:      	movl	$0x2e, %eax
    17e5:      	movl	$0x6, %ecx
    17ea:      	movl	0x18(%rsp), %edx
    17ee:      	movl	$0x2e, %esi
    17f3:      	xorl	%eax, %eax
    17f5:      	callq	*%rcx
    17f7:      	jmp	0xa25 <perf_unwind_python+0xa25>
    17fc:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1806:      	movq	%rax, 0x56(%rsp)
    180b:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1815:      	movq	%rax, 0x50(%rsp)
    181a:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1824:      	movq	%rax, 0x48(%rsp)
    1829:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1833:      	movq	%rax, 0x40(%rsp)
    1838:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1842:      	movq	%rax, 0x38(%rsp)
    1847:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1851:      	movq	%rax, 0x30(%rsp)
    1856:      	leaq	0x30(%rsp), %rdi
    185b:      	movl	$0x2e, %eax
    1860:      	movl	$0x6, %ecx
    1865:      	movl	0x18(%rsp), %edx
    1869:      	movl	$0x2e, %esi
    186e:      	xorl	%eax, %eax
    1870:      	callq	*%rcx
    1872:      	jmp	0x32a <perf_unwind_python+0x32a>
    1877:      	movabsq	$0xa786c2578302074, %rcx # imm = 0xA786C2578302074
    1881:      	movq	%rcx, 0x58(%rsp)
    1886:      	movabsq	$0x6120656d6172665f, %rcx # imm = 0x6120656D6172665F
    1890:      	movq	%rcx, 0x50(%rsp)
    1895:      	movabsq	$0x746e65727275632e, %rcx # imm = 0x746E65727275632E
    189f:      	movq	%rcx, 0x48(%rsp)
    18a4:      	movabsq	$0x656d617246437950, %rcx # imm = 0x656D617246437950
    18ae:      	movq	%rcx, 0x40(%rsp)
    18b3:      	movabsq	$0x5f2064616572206f, %rcx # imm = 0x5F2064616572206F
    18bd:      	movq	%rcx, 0x38(%rsp)
    18c2:      	movabsq	$0x742064656c696146, %rcx # imm = 0x742064656C696146
    18cc:      	movq	%rcx, 0x30(%rsp)
    18d1:      	movb	$0x0, 0x60(%rsp)
    18d6:      	leaq	0x30(%rsp), %rdi
    18db:      	movl	$0x31, %ecx
    18e0:      	movl	$0x6, %r8d
    18e6:      	movzbl	0x17(%rax), %edx
    18ea:      	movq	0x10(%rsp), %rax
    18ef:      	addq	(%rax), %rdx
    18f2:      	movl	$0x31, %esi
    18f7:      	xorl	%eax, %eax
    18f9:      	callq	*%r8
    18fc:      	jmp	0x9ab <perf_unwind_python+0x9ab>
    1901:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    190b:      	movq	%rax, 0x56(%rsp)
    1910:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    191a:      	movq	%rax, 0x50(%rsp)
    191f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1929:      	movq	%rax, 0x48(%rsp)
    192e:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1938:      	movq	%rax, 0x40(%rsp)
    193d:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1947:      	movq	%rax, 0x38(%rsp)
    194c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1956:      	movq	%rax, 0x30(%rsp)
    195b:      	leaq	0x30(%rsp), %rdi
    1960:      	movl	$0x2e, %eax
    1965:      	movl	$0x6, %ecx
    196a:      	movl	0x18(%rsp), %edx
    196e:      	movl	$0x2e, %esi
    1973:      	xorl	%eax, %eax
    1975:      	callq	*%rcx
    1977:      	xorl	%ecx, %ecx
    1979:      	movq	0x10(%rsp), %rsi
    197e:      	cmpl	$0x0, (%r14)
    1982:      	movl	$0x2, %r12d
    1988:      	je	0x16f <perf_unwind_python+0x16f>
    198e:      	jmp	0x3a7 <perf_unwind_python+0x3a7>
    1993:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    199d:      	movq	%rax, 0x56(%rsp)
    19a2:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    19ac:      	movq	%rax, 0x50(%rsp)
    19b1:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    19bb:      	movq	%rax, 0x48(%rsp)
    19c0:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    19ca:      	movq	%rax, 0x40(%rsp)
    19cf:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    19d9:      	movq	%rax, 0x38(%rsp)
    19de:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    19e8:      	movq	%rax, 0x30(%rsp)
    19ed:      	leaq	0x30(%rsp), %rdi
    19f2:      	movl	$0x2e, %eax
    19f7:      	movl	$0x6, %ecx
    19fc:      	movl	0x18(%rsp), %edx
    1a00:      	movl	$0x2e, %esi
    1a05:      	xorl	%eax, %eax
    1a07:      	movl	%r8d, %r12d
    1a0a:      	callq	*%rcx
    1a0c:      	movl	%r12d, %r8d
    1a0f:      	movq	0x10(%rsp), %rsi
    1a14:      	movq	(%rsp), %rax
    1a18:      	testb	%r8b, %r8b
    1a1b:      	movq	0x20(%rsp), %rdi
    1a20:      	jne	0x1bf <perf_unwind_python+0x1bf>
    1a26:      	jmp	0xc19 <perf_unwind_python+0xc19>
    1a2b:      	movabsq	$0xa64656c646e61, %rax  # imm = 0xA64656C646E61
    1a35:      	movq	%rax, 0x48(%rsp)
    1a3a:      	movabsq	$0x6820657261207365, %rax # imm = 0x6820657261207365
    1a44:      	movq	%rax, 0x40(%rsp)
    1a49:      	movabsq	$0x6d617266206e6f68, %rax # imm = 0x6D617266206E6F68
    1a53:      	movq	%rax, 0x38(%rsp)
    1a58:      	movabsq	$0x747950203e2d2020, %rax # imm = 0x747950203E2D2020
    1a62:      	movq	%rax, 0x30(%rsp)
    1a67:      	leaq	0x30(%rsp), %rdi
    1a6c:      	movl	$0x20, %eax
    1a71:      	movl	$0x6, %ecx
    1a76:      	movl	$0x20, %esi
    1a7b:      	xorl	%eax, %eax
    1a7d:      	callq	*%rcx
    1a7f:      	jmp	0xa06 <perf_unwind_python+0xa06>
    1a84:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1a8e:      	movq	%rax, 0x56(%rsp)
    1a93:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1a9d:      	movq	%rax, 0x50(%rsp)
    1aa2:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1aac:      	movq	%rax, 0x48(%rsp)
    1ab1:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1abb:      	movq	%rax, 0x40(%rsp)
    1ac0:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1aca:      	movq	%rax, 0x38(%rsp)
    1acf:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1ad9:      	movq	%rax, 0x30(%rsp)
    1ade:      	leaq	0x30(%rsp), %rdi
    1ae3:      	movl	$0x2e, %eax
    1ae8:      	movl	$0x6, %ecx
    1aed:      	movl	0x18(%rsp), %edx
    1af1:      	movl	$0x2e, %esi
    1af6:      	xorl	%eax, %eax
    1af8:      	callq	*%rcx
    1afa:      	jmp	0xa40 <perf_unwind_python+0xa40>
    1aff:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    1b09:      	movq	%rax, 0x4e(%rsp)
    1b0e:      	movabsq	$0x3020746120746365, %rax # imm = 0x3020746120746365
    1b18:      	movq	%rax, 0x48(%rsp)
    1b1d:      	movabsq	$0x6a624f65646f4379, %rax # imm = 0x6A624F65646F4379
    1b27:      	movq	%rax, 0x40(%rsp)
    1b2c:      	movabsq	$0x502064616572206f, %rax # imm = 0x502064616572206F
    1b36:      	movq	%rax, 0x38(%rsp)
    1b3b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1b45:      	movq	%rax, 0x30(%rsp)
    1b4a:      	leaq	0x30(%rsp), %rdi
    1b4f:      	movl	$0x26, %eax
    1b54:      	movl	$0x6, %ecx
    1b59:      	movl	$0x26, %esi
    1b5e:      	movq	0x28(%rsp), %rdx
    1b63:      	xorl	%eax, %eax
    1b65:      	callq	*%rcx
    1b67:      	jmp	0x2c9 <perf_unwind_python+0x2c9>
    1b6c:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1b76:      	movq	%rax, 0x56(%rsp)
    1b7b:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1b85:      	movq	%rax, 0x50(%rsp)
    1b8a:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1b94:      	movq	%rax, 0x48(%rsp)
    1b99:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1ba3:      	movq	%rax, 0x40(%rsp)
    1ba8:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1bb2:      	movq	%rax, 0x38(%rsp)
    1bb7:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1bc1:      	movq	%rax, 0x30(%rsp)
    1bc6:      	leaq	0x30(%rsp), %rdi
    1bcb:      	movl	$0x2e, %eax
    1bd0:      	movl	$0x6, %ecx
    1bd5:      	movl	0x18(%rsp), %edx
    1bd9:      	movl	$0x2e, %esi
    1bde:      	xorl	%eax, %eax
    1be0:      	callq	*%rcx
    1be2:      	jmp	0xd78 <perf_unwind_python+0xd78>
    1be7:      	movabsq	$0xa756c2520786c, %rax  # imm = 0xA756C2520786C
    1bf1:      	movq	%rax, 0x40(%rsp)
    1bf6:      	movabsq	$0x25206e6f68747950, %rax # imm = 0x25206E6F68747950
    1c00:      	movq	%rax, 0x38(%rsp)
    1c05:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    1c0f:      	movq	%rax, 0x30(%rsp)
    1c14:      	leaq	0x30(%rsp), %rdi
    1c19:      	movl	$0x18, %eax
    1c1e:      	movl	$0x6, %r8d
    1c24:      	movl	$0x18, %esi
    1c29:      	movq	0x28(%rsp), %rdx
    1c2e:      	movq	%r12, %rcx
    1c31:      	xorl	%eax, %eax
    1c33:      	callq	*%r8
    1c36:      	movl	0x2c0(%rbp), %eax
    1c3c:      	cmpq	$0x7e, %rax
    1c40:      	ja	0x1777 <perf_unwind_python+0x1777>
    1c46:      	leal	0x1(%rax), %ecx
    1c49:      	movl	%ecx, 0x2c0(%rbp)
    1c4f:      	leaq	(%rax,%rax,2), %rax
    1c53:      	movq	0x28(%rsp), %rcx
    1c58:      	movq	%rcx, 0x2d0(%rbp,%rax,8)
    1c60:      	movq	%r12, 0x2d8(%rbp,%rax,8)
    1c68:      	movb	$0x1, 0x2e0(%rbp,%rax,8)
    1c70:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    1c7b:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    1c86:      	movl	$0x16, 0x18(%rsp)
    1c8e:      	movq	(%rip), %rdi            # 0x1c95 <perf_unwind_python+0x1c95>
    1c95:      	leaq	0x18(%rsp), %rsi
    1c9a:      	movl	$0x1, %eax
    1c9f:      	callq	*%rax
    1ca1:      	testq	%rax, %rax
    1ca4:      	je	0x1cb3 <perf_unwind_python+0x1cb3>
    1ca6:      	incq	(%rax)
    1ca9:      	testb	%bl, %bl
    1cab:      	jne	0x124c <perf_unwind_python+0x124c>
    1cb1:      	jmp	0x1cc5 <perf_unwind_python+0x1cc5>
    1cb3:      	cmpl	$0x0, (%r14)
    1cb7:      	jne	0x1fbb <perf_unwind_python+0x1fbb>
    1cbd:      	testb	%bl, %bl
    1cbf:      	jne	0x124c <perf_unwind_python+0x124c>
    1cc5:      	xorl	%r12d, %r12d
    1cc8:      	testq	%r13, %r13
    1ccb:      	je	0x45be <perf_unwind_python+0x45be>
    1cd1:      	movq	(%rsp), %rax
    1cd5:      	cmpb	$0x78, 0x19(%rax)
    1cd9:      	ja	0x460a <perf_unwind_python+0x460a>
    1cdf:      	movq	(%rsp), %rax
    1ce3:      	cmpb	$0x78, 0x18(%rax)
    1ce7:      	ja	0x460a <perf_unwind_python+0x460a>
    1ced:      	movq	(%rsp), %rax
    1cf1:      	cmpb	$0x78, 0x1a(%rax)
    1cf5:      	ja	0x460a <perf_unwind_python+0x460a>
    1cfb:      	movq	(%rsp), %rax
    1cff:      	cmpb	$0x0, 0x1b(%rax)
    1d03:      	js	0x460a <perf_unwind_python+0x460a>
    1d09:      	movl	$0x80, %eax
    1d0e:      	movl	$0x70, %ecx
    1d13:      	movq	0x70(%rsp), %rdi
    1d18:      	movl	$0x80, %esi
    1d1d:      	movq	%r13, %rdx
    1d20:      	callq	*%rcx
    1d22:      	testq	%rax, %rax
    1d25:      	je	0x1d31 <perf_unwind_python+0x1d31>
    1d27:      	movq	0x8(%rsp), %rbx
    1d2c:      	jmp	0xf4 <perf_unwind_python+0xf4>
    1d31:      	movq	(%rsp), %rax
    1d35:      	movzbl	0x19(%rax), %ecx
    1d39:      	movq	0x70(%rsp), %rdx
    1d3e:      	movq	(%rdx,%rcx), %rcx
    1d42:      	movq	%rcx, 0x28(%rsp)
    1d47:      	movzbl	0x18(%rax), %ecx
    1d4b:      	movq	(%rdx,%rcx), %rcx
    1d4f:      	movq	%rcx, 0x20(%rsp)
    1d54:      	movq	0x8(%rax), %rax
    1d58:      	testq	%rax, %rax
    1d5b:      	je	0x1d78 <perf_unwind_python+0x1d78>
    1d5d:      	cmpq	%rax, 0x28(%rsp)
    1d62:      	jne	0x1d78 <perf_unwind_python+0x1d78>
    1d64:      	movq	0x8(%rsp), %rbx
    1d69:      	movq	0x10(%rsp), %rsi
    1d6e:      	movq	0x20(%rsp), %rdi
    1d73:      	jmp	0x1bf <perf_unwind_python+0x1bf>
    1d78:      	movq	(%rsp), %rax
    1d7c:      	cmpb	$0x0, 0x22(%rax)
    1d80:      	movzbl	0x1a(%rax), %eax
    1d84:      	je	0x1dc9 <perf_unwind_python+0x1dc9>
    1d86:      	movq	0x70(%rsp), %rsi
    1d8b:      	movq	(%rsi,%rax), %rax
    1d8f:      	movq	(%rsp), %rcx
    1d93:      	movzbl	0x21(%rcx), %edx
    1d97:      	addq	0x28(%rsp), %rdx
    1d9c:      	subq	%rdx, %rax
    1d9f:      	leaq	-0x10000001(%rax), %rdx
    1da6:      	sarl	%eax
    1da8:      	cmpq	$-0x10000003, %rdx      # imm = 0xEFFFFFFD
    1daf:      	movl	$0xffffffff, %r12d      # imm = 0xFFFFFFFF
    1db5:      	cmovael	%eax, %r12d
    1db9:      	movzbl	0x1b(%rcx), %eax
    1dbd:      	movzbl	(%rsi,%rax), %eax
    1dc1:      	cmpb	0x1c(%rcx), %al
    1dc4:      	sete	%bl
    1dc7:      	jmp	0x1dd4 <perf_unwind_python+0x1dd4>
    1dc9:      	movq	0x70(%rsp), %rcx
    1dce:      	movl	(%rcx,%rax), %r12d
    1dd2:      	xorl	%ebx, %ebx
    1dd4:      	cmpq	$0x0, 0x28(%rsp)
    1dda:      	je	0x1e40 <perf_unwind_python+0x1e40>
    1ddc:      	movq	(%rsp), %rax
    1de0:      	cmpb	$-0x44, 0x1d(%rax)
    1de4:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    1dea:      	movq	(%rsp), %rax
    1dee:      	cmpb	$-0x44, 0x1e(%rax)
    1df2:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    1df8:      	movq	(%rsp), %rax
    1dfc:      	cmpb	$-0x44, 0x1f(%rax)
    1e00:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    1e06:      	movq	(%rsp), %rax
    1e0a:      	cmpb	$-0x44, 0x20(%rax)
    1e0e:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    1e14:      	movl	$0xc0, %eax
    1e19:      	movl	$0x70, %ecx
    1e1e:      	movq	0x28(%rsp), %rdx
    1e23:      	movq	%r15, %rdi
    1e26:      	movl	$0xc0, %esi
    1e2b:      	callq	*%rcx
    1e2d:      	testq	%rax, %rax
    1e30:      	je	0x203e <perf_unwind_python+0x203e>
    1e36:      	movq	0x20(%rsp), %r13
    1e3b:      	jmp	0x2bc <perf_unwind_python+0x2bc>
    1e40:      	cmpl	$0x0, (%r14)
    1e44:      	jne	0x2330 <perf_unwind_python+0x2330>
    1e4a:      	movl	$0x1c, 0x18(%rsp)
    1e52:      	movq	(%rip), %rdi            # 0x1e59 <perf_unwind_python+0x1e59>
    1e59:      	leaq	0x18(%rsp), %rsi
    1e5e:      	movl	$0x1, %eax
    1e63:      	callq	*%rax
    1e65:      	testq	%rax, %rax
    1e68:      	je	0x1eff <perf_unwind_python+0x1eff>
    1e6e:      	incq	(%rax)
    1e71:      	jmp	0x1f09 <perf_unwind_python+0x1f09>
    1e76:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    1e80:      	movq	%rax, 0x57(%rsp)
    1e85:      	movabsq	$0x20786c2578302074, %rax # imm = 0x20786C2578302074
    1e8f:      	movq	%rax, 0x50(%rsp)
    1e94:      	movabsq	$0x63656a624f656d61, %rax # imm = 0x63656A624F656D61
    1e9e:      	movq	%rax, 0x48(%rsp)
    1ea3:      	movabsq	$0x7246795020726f66, %rax # imm = 0x7246795020726F66
    1ead:      	movq	%rax, 0x40(%rsp)
    1eb2:      	movabsq	$0x207463656a626f65, %rax # imm = 0x207463656A626F65
    1ebc:      	movq	%rax, 0x38(%rsp)
    1ec1:      	movabsq	$0x646f63206c6c754e, %rax # imm = 0x646F63206C6C754E
    1ecb:      	movq	%rax, 0x30(%rsp)
    1ed0:      	leaq	0x30(%rsp), %rdi
    1ed5:      	movl	$0x2f, %eax
    1eda:      	movl	$0x6, %r8d
    1ee0:      	movq	(%rsp), %rax
    1ee4:      	movzbl	0x19(%rax), %ecx
    1ee8:      	movq	0x20(%rsp), %rdx
    1eed:      	addq	%rdx, %rcx
    1ef0:      	movl	$0x2f, %esi
    1ef5:      	xorl	%eax, %eax
    1ef7:      	callq	*%r8
    1efa:      	jmp	0x1565 <perf_unwind_python+0x1565>
    1eff:      	cmpl	$0x0, (%r14)
    1f03:      	jne	0x245d <perf_unwind_python+0x245d>
    1f09:      	movq	$-0x2, %r12
    1f10:      	xorl	%eax, %eax
    1f12:      	movq	%rax, 0x28(%rsp)
    1f17:      	cmpl	$0x0, (%r14)
    1f1b:      	jne	0x2080 <perf_unwind_python+0x2080>
    1f21:      	movl	0x2c0(%rbp), %eax
    1f27:      	cmpq	$0x7e, %rax
    1f2b:      	jbe	0x20df <perf_unwind_python+0x20df>
    1f31:      	movq	0x20(%rsp), %r13
    1f36:      	movq	0x8(%rsp), %rbx
    1f3b:      	jmp	0x35f <perf_unwind_python+0x35f>
    1f40:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1f4a:      	movq	%rax, 0x56(%rsp)
    1f4f:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1f59:      	movq	%rax, 0x50(%rsp)
    1f5e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1f68:      	movq	%rax, 0x48(%rsp)
    1f6d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1f77:      	movq	%rax, 0x40(%rsp)
    1f7c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1f86:      	movq	%rax, 0x38(%rsp)
    1f8b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1f95:      	movq	%rax, 0x30(%rsp)
    1f9a:      	leaq	0x30(%rsp), %rdi
    1f9f:      	movl	$0x2e, %eax
    1fa4:      	movl	$0x6, %ecx
    1fa9:      	movl	0x18(%rsp), %edx
    1fad:      	movl	$0x2e, %esi
    1fb2:      	xorl	%eax, %eax
    1fb4:      	callq	*%rcx
    1fb6:      	jmp	0x174f <perf_unwind_python+0x174f>
    1fbb:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1fc5:      	movq	%rax, 0x56(%rsp)
    1fca:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1fd4:      	movq	%rax, 0x50(%rsp)
    1fd9:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1fe3:      	movq	%rax, 0x48(%rsp)
    1fe8:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1ff2:      	movq	%rax, 0x40(%rsp)
    1ff7:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2001:      	movq	%rax, 0x38(%rsp)
    2006:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2010:      	movq	%rax, 0x30(%rsp)
    2015:      	leaq	0x30(%rsp), %rdi
    201a:      	movl	$0x2e, %eax
    201f:      	movl	$0x6, %ecx
    2024:      	movl	0x18(%rsp), %edx
    2028:      	movl	$0x2e, %esi
    202d:      	xorl	%eax, %eax
    202f:      	callq	*%rcx
    2031:      	testb	%bl, %bl
    2033:      	jne	0x124c <perf_unwind_python+0x124c>
    2039:      	jmp	0x1cc5 <perf_unwind_python+0x1cc5>
    203e:      	movq	(%rsp), %rax
    2042:      	movzbl	0x1d(%rax), %ecx
    2046:      	movl	(%r15,%rcx), %ecx
    204a:      	movzbl	0x1e(%rax), %edx
    204e:      	movl	(%r15,%rdx), %edx
    2052:      	movzbl	0x1f(%rax), %esi
    2056:      	movl	(%r15,%rsi), %esi
    205a:      	movzbl	0x20(%rax), %eax
    205e:      	shll	$0x19, %ecx
    2061:      	shll	$0x12, %edx
    2064:      	addl	%ecx, %edx
    2066:      	shll	$0xa, %esi
    2069:      	addl	%edx, %esi
    206b:      	addl	(%r15,%rax), %esi
    206f:      	shlq	$0x20, %r12
    2073:      	orq	%rsi, %r12
    2076:      	cmpl	$0x0, (%r14)
    207a:      	je	0x1f21 <perf_unwind_python+0x1f21>
    2080:      	movabsq	$0xa756c2520786c, %rax  # imm = 0xA756C2520786C
    208a:      	movq	%rax, 0x40(%rsp)
    208f:      	movabsq	$0x25206e6f68747950, %rax # imm = 0x25206E6F68747950
    2099:      	movq	%rax, 0x38(%rsp)
    209e:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    20a8:      	movq	%rax, 0x30(%rsp)
    20ad:      	leaq	0x30(%rsp), %rdi
    20b2:      	movl	$0x18, %eax
    20b7:      	movl	$0x6, %r8d
    20bd:      	movl	$0x18, %esi
    20c2:      	movq	0x28(%rsp), %rdx
    20c7:      	movq	%r12, %rcx
    20ca:      	xorl	%eax, %eax
    20cc:      	callq	*%r8
    20cf:      	movl	0x2c0(%rbp), %eax
    20d5:      	cmpq	$0x7e, %rax
    20d9:      	ja	0x1f31 <perf_unwind_python+0x1f31>
    20df:      	leal	0x1(%rax), %ecx
    20e2:      	movl	%ecx, 0x2c0(%rbp)
    20e8:      	leaq	(%rax,%rax,2), %rax
    20ec:      	movq	0x28(%rsp), %rcx
    20f1:      	movq	%rcx, 0x2d0(%rbp,%rax,8)
    20f9:      	movq	%r12, 0x2d8(%rbp,%rax,8)
    2101:      	movb	$0x1, 0x2e0(%rbp,%rax,8)
    2109:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    2114:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    211f:      	movl	$0x16, 0x18(%rsp)
    2127:      	movq	(%rip), %rdi            # 0x212e <perf_unwind_python+0x212e>
    212e:      	leaq	0x18(%rsp), %rsi
    2133:      	movl	$0x1, %eax
    2138:      	callq	*%rax
    213a:      	testq	%rax, %rax
    213d:      	je	0x214c <perf_unwind_python+0x214c>
    213f:      	incq	(%rax)
    2142:      	testb	%bl, %bl
    2144:      	jne	0x1d64 <perf_unwind_python+0x1d64>
    214a:      	jmp	0x215e <perf_unwind_python+0x215e>
    214c:      	cmpl	$0x0, (%r14)
    2150:      	jne	0x25df <perf_unwind_python+0x25df>
    2156:      	testb	%bl, %bl
    2158:      	jne	0x1d64 <perf_unwind_python+0x1d64>
    215e:      	xorl	%r12d, %r12d
    2161:      	cmpq	$0x0, 0x20(%rsp)
    2167:      	je	0x45be <perf_unwind_python+0x45be>
    216d:      	movq	(%rsp), %rax
    2171:      	cmpb	$0x78, 0x19(%rax)
    2175:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    217b:      	movq	(%rsp), %rax
    217f:      	cmpb	$0x78, 0x18(%rax)
    2183:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    2189:      	movq	(%rsp), %rax
    218d:      	cmpb	$0x78, 0x1a(%rax)
    2191:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    2197:      	movq	(%rsp), %rax
    219b:      	cmpb	$0x0, 0x1b(%rax)
    219f:      	js	0x45a2 <perf_unwind_python+0x45a2>
    21a5:      	movl	$0x80, %eax
    21aa:      	movl	$0x70, %ecx
    21af:      	movq	0x70(%rsp), %rdi
    21b4:      	movq	0x20(%rsp), %rdx
    21b9:      	movl	$0x80, %esi
    21be:      	callq	*%rcx
    21c0:      	testq	%rax, %rax
    21c3:      	jne	0xd60 <perf_unwind_python+0xd60>
    21c9:      	movq	(%rsp), %rax
    21cd:      	movzbl	0x19(%rax), %ecx
    21d1:      	movq	0x70(%rsp), %rdx
    21d6:      	movq	(%rdx,%rcx), %rcx
    21da:      	movq	%rcx, 0x28(%rsp)
    21df:      	movzbl	0x18(%rax), %ecx
    21e3:      	movq	(%rdx,%rcx), %r13
    21e7:      	movq	0x8(%rax), %rax
    21eb:      	testq	%rax, %rax
    21ee:      	je	0x21fb <perf_unwind_python+0x21fb>
    21f0:      	cmpq	%rax, 0x28(%rsp)
    21f5:      	je	0x124c <perf_unwind_python+0x124c>
    21fb:      	movq	(%rsp), %rax
    21ff:      	cmpb	$0x0, 0x22(%rax)
    2203:      	movzbl	0x1a(%rax), %eax
    2207:      	je	0x224c <perf_unwind_python+0x224c>
    2209:      	movq	0x70(%rsp), %rsi
    220e:      	movq	(%rsi,%rax), %rax
    2212:      	movq	(%rsp), %rcx
    2216:      	movzbl	0x21(%rcx), %edx
    221a:      	addq	0x28(%rsp), %rdx
    221f:      	subq	%rdx, %rax
    2222:      	leaq	-0x10000001(%rax), %rdx
    2229:      	sarl	%eax
    222b:      	cmpq	$-0x10000003, %rdx      # imm = 0xEFFFFFFD
    2232:      	movl	$0xffffffff, %r12d      # imm = 0xFFFFFFFF
    2238:      	cmovael	%eax, %r12d
    223c:      	movzbl	0x1b(%rcx), %eax
    2240:      	movzbl	(%rsi,%rax), %eax
    2244:      	cmpb	0x1c(%rcx), %al
    2247:      	sete	%bl
    224a:      	jmp	0x2257 <perf_unwind_python+0x2257>
    224c:      	movq	0x70(%rsp), %rcx
    2251:      	movl	(%rcx,%rax), %r12d
    2255:      	xorl	%ebx, %ebx
    2257:      	cmpq	$0x0, 0x28(%rsp)
    225d:      	je	0x22fa <perf_unwind_python+0x22fa>
    2263:      	movq	(%rsp), %rax
    2267:      	cmpb	$-0x44, 0x1d(%rax)
    226b:      	ja	0x460a <perf_unwind_python+0x460a>
    2271:      	movq	(%rsp), %rax
    2275:      	cmpb	$-0x44, 0x1e(%rax)
    2279:      	ja	0x460a <perf_unwind_python+0x460a>
    227f:      	movq	(%rsp), %rax
    2283:      	cmpb	$-0x44, 0x1f(%rax)
    2287:      	ja	0x460a <perf_unwind_python+0x460a>
    228d:      	movq	(%rsp), %rax
    2291:      	cmpb	$-0x44, 0x20(%rax)
    2295:      	ja	0x460a <perf_unwind_python+0x460a>
    229b:      	movl	$0xc0, %eax
    22a0:      	movl	$0x70, %ecx
    22a5:      	movq	0x28(%rsp), %rdx
    22aa:      	movq	%r15, %rdi
    22ad:      	movl	$0xc0, %esi
    22b2:      	callq	*%rcx
    22b4:      	testq	%rax, %rax
    22b7:      	jne	0x2bc <perf_unwind_python+0x2bc>
    22bd:      	movq	(%rsp), %rax
    22c1:      	movzbl	0x1d(%rax), %ecx
    22c5:      	movl	(%r15,%rcx), %ecx
    22c9:      	movzbl	0x1e(%rax), %edx
    22cd:      	movl	(%r15,%rdx), %edx
    22d1:      	movzbl	0x1f(%rax), %esi
    22d5:      	movl	(%r15,%rsi), %esi
    22d9:      	movzbl	0x20(%rax), %eax
    22dd:      	shll	$0x19, %ecx
    22e0:      	shll	$0x12, %edx
    22e3:      	addl	%ecx, %edx
    22e5:      	shll	$0xa, %esi
    22e8:      	addl	%edx, %esi
    22ea:      	addl	(%r15,%rax), %esi
    22ee:      	shlq	$0x20, %r12
    22f2:      	orq	%rsi, %r12
    22f5:      	jmp	0x23cf <perf_unwind_python+0x23cf>
    22fa:      	cmpl	$0x0, (%r14)
    22fe:      	jne	0x27c8 <perf_unwind_python+0x27c8>
    2304:      	movl	$0x1c, 0x18(%rsp)
    230c:      	movq	(%rip), %rdi            # 0x2313 <perf_unwind_python+0x2313>
    2313:      	leaq	0x18(%rsp), %rsi
    2318:      	movl	$0x1, %eax
    231d:      	callq	*%rax
    231f:      	testq	%rax, %rax
    2322:      	je	0x23b7 <perf_unwind_python+0x23b7>
    2328:      	incq	(%rax)
    232b:      	jmp	0x23c1 <perf_unwind_python+0x23c1>
    2330:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    233a:      	movq	%rax, 0x57(%rsp)
    233f:      	movabsq	$0x20786c2578302074, %rax # imm = 0x20786C2578302074
    2349:      	movq	%rax, 0x50(%rsp)
    234e:      	movabsq	$0x63656a624f656d61, %rax # imm = 0x63656A624F656D61
    2358:      	movq	%rax, 0x48(%rsp)
    235d:      	movabsq	$0x7246795020726f66, %rax # imm = 0x7246795020726F66
    2367:      	movq	%rax, 0x40(%rsp)
    236c:      	movabsq	$0x207463656a626f65, %rax # imm = 0x207463656A626F65
    2376:      	movq	%rax, 0x38(%rsp)
    237b:      	movabsq	$0x646f63206c6c754e, %rax # imm = 0x646F63206C6C754E
    2385:      	movq	%rax, 0x30(%rsp)
    238a:      	leaq	0x30(%rsp), %rdi
    238f:      	movl	$0x2f, %eax
    2394:      	movl	$0x6, %r8d
    239a:      	movq	(%rsp), %rax
    239e:      	movzbl	0x19(%rax), %ecx
    23a2:      	addq	%r13, %rcx
    23a5:      	movl	$0x2f, %esi
    23aa:      	movq	%r13, %rdx
    23ad:      	xorl	%eax, %eax
    23af:      	callq	*%r8
    23b2:      	jmp	0x1e4a <perf_unwind_python+0x1e4a>
    23b7:      	cmpl	$0x0, (%r14)
    23bb:      	jne	0x28b5 <perf_unwind_python+0x28b5>
    23c1:      	movq	$-0x2, %r12
    23c8:      	xorl	%eax, %eax
    23ca:      	movq	%rax, 0x28(%rsp)
    23cf:      	cmpl	$0x0, (%r14)
    23d3:      	jne	0x2851 <perf_unwind_python+0x2851>
    23d9:      	movl	0x2c0(%rbp), %eax
    23df:      	cmpq	$0x7e, %rax
    23e3:      	ja	0x1777 <perf_unwind_python+0x1777>
    23e9:      	leal	0x1(%rax), %ecx
    23ec:      	movl	%ecx, 0x2c0(%rbp)
    23f2:      	leaq	(%rax,%rax,2), %rax
    23f6:      	movq	0x28(%rsp), %rcx
    23fb:      	movq	%rcx, 0x2d0(%rbp,%rax,8)
    2403:      	movq	%r12, 0x2d8(%rbp,%rax,8)
    240b:      	movb	$0x1, 0x2e0(%rbp,%rax,8)
    2413:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    241e:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    2429:      	movl	$0x16, 0x18(%rsp)
    2431:      	movq	(%rip), %rdi            # 0x2438 <perf_unwind_python+0x2438>
    2438:      	leaq	0x18(%rsp), %rsi
    243d:      	movl	$0x1, %eax
    2442:      	callq	*%rax
    2444:      	testq	%rax, %rax
    2447:      	je	0x24d8 <perf_unwind_python+0x24d8>
    244d:      	incq	(%rax)
    2450:      	testb	%bl, %bl
    2452:      	jne	0x124c <perf_unwind_python+0x124c>
    2458:      	jmp	0x24ea <perf_unwind_python+0x24ea>
    245d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2467:      	movq	%rax, 0x56(%rsp)
    246c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2476:      	movq	%rax, 0x50(%rsp)
    247b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2485:      	movq	%rax, 0x48(%rsp)
    248a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2494:      	movq	%rax, 0x40(%rsp)
    2499:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    24a3:      	movq	%rax, 0x38(%rsp)
    24a8:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    24b2:      	movq	%rax, 0x30(%rsp)
    24b7:      	leaq	0x30(%rsp), %rdi
    24bc:      	movl	$0x2e, %eax
    24c1:      	movl	$0x6, %ecx
    24c6:      	movl	0x18(%rsp), %edx
    24ca:      	movl	$0x2e, %esi
    24cf:      	xorl	%eax, %eax
    24d1:      	callq	*%rcx
    24d3:      	jmp	0x1f09 <perf_unwind_python+0x1f09>
    24d8:      	cmpl	$0x0, (%r14)
    24dc:      	jne	0x2930 <perf_unwind_python+0x2930>
    24e2:      	testb	%bl, %bl
    24e4:      	jne	0x124c <perf_unwind_python+0x124c>
    24ea:      	xorl	%r12d, %r12d
    24ed:      	testq	%r13, %r13
    24f0:      	je	0x45be <perf_unwind_python+0x45be>
    24f6:      	movq	(%rsp), %rax
    24fa:      	cmpb	$0x78, 0x19(%rax)
    24fe:      	ja	0x460a <perf_unwind_python+0x460a>
    2504:      	movq	(%rsp), %rax
    2508:      	cmpb	$0x78, 0x18(%rax)
    250c:      	ja	0x460a <perf_unwind_python+0x460a>
    2512:      	movq	(%rsp), %rax
    2516:      	cmpb	$0x78, 0x1a(%rax)
    251a:      	ja	0x460a <perf_unwind_python+0x460a>
    2520:      	movq	(%rsp), %rax
    2524:      	cmpb	$0x0, 0x1b(%rax)
    2528:      	js	0x460a <perf_unwind_python+0x460a>
    252e:      	movl	$0x80, %eax
    2533:      	movl	$0x70, %ecx
    2538:      	movq	0x70(%rsp), %rdi
    253d:      	movl	$0x80, %esi
    2542:      	movq	%r13, %rdx
    2545:      	callq	*%rcx
    2547:      	testq	%rax, %rax
    254a:      	jne	0x1d27 <perf_unwind_python+0x1d27>
    2550:      	movq	(%rsp), %rax
    2554:      	movzbl	0x19(%rax), %ecx
    2558:      	movq	0x70(%rsp), %rdx
    255d:      	movq	(%rdx,%rcx), %rcx
    2561:      	movq	%rcx, 0x28(%rsp)
    2566:      	movzbl	0x18(%rax), %ecx
    256a:      	movq	(%rdx,%rcx), %rcx
    256e:      	movq	%rcx, 0x20(%rsp)
    2573:      	movq	0x8(%rax), %rax
    2577:      	testq	%rax, %rax
    257a:      	je	0x2587 <perf_unwind_python+0x2587>
    257c:      	cmpq	%rax, 0x28(%rsp)
    2581:      	je	0x1d64 <perf_unwind_python+0x1d64>
    2587:      	movq	(%rsp), %rax
    258b:      	cmpb	$0x0, 0x22(%rax)
    258f:      	movzbl	0x1a(%rax), %eax
    2593:      	je	0x2662 <perf_unwind_python+0x2662>
    2599:      	movq	0x70(%rsp), %rsi
    259e:      	movq	(%rsi,%rax), %rax
    25a2:      	movq	(%rsp), %rcx
    25a6:      	movzbl	0x21(%rcx), %edx
    25aa:      	addq	0x28(%rsp), %rdx
    25af:      	subq	%rdx, %rax
    25b2:      	leaq	-0x10000001(%rax), %rdx
    25b9:      	sarl	%eax
    25bb:      	cmpq	$-0x10000003, %rdx      # imm = 0xEFFFFFFD
    25c2:      	movl	$0xffffffff, %r12d      # imm = 0xFFFFFFFF
    25c8:      	cmovael	%eax, %r12d
    25cc:      	movzbl	0x1b(%rcx), %eax
    25d0:      	movzbl	(%rsi,%rax), %eax
    25d4:      	cmpb	0x1c(%rcx), %al
    25d7:      	sete	%bl
    25da:      	jmp	0x266d <perf_unwind_python+0x266d>
    25df:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    25e9:      	movq	%rax, 0x56(%rsp)
    25ee:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    25f8:      	movq	%rax, 0x50(%rsp)
    25fd:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2607:      	movq	%rax, 0x48(%rsp)
    260c:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2616:      	movq	%rax, 0x40(%rsp)
    261b:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2625:      	movq	%rax, 0x38(%rsp)
    262a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2634:      	movq	%rax, 0x30(%rsp)
    2639:      	leaq	0x30(%rsp), %rdi
    263e:      	movl	$0x2e, %eax
    2643:      	movl	$0x6, %ecx
    2648:      	movl	0x18(%rsp), %edx
    264c:      	movl	$0x2e, %esi
    2651:      	xorl	%eax, %eax
    2653:      	callq	*%rcx
    2655:      	testb	%bl, %bl
    2657:      	jne	0x1d64 <perf_unwind_python+0x1d64>
    265d:      	jmp	0x215e <perf_unwind_python+0x215e>
    2662:      	movq	0x70(%rsp), %rcx
    2667:      	movl	(%rcx,%rax), %r12d
    266b:      	xorl	%ebx, %ebx
    266d:      	cmpq	$0x0, 0x28(%rsp)
    2673:      	je	0x2710 <perf_unwind_python+0x2710>
    2679:      	movq	(%rsp), %rax
    267d:      	cmpb	$-0x44, 0x1d(%rax)
    2681:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    2687:      	movq	(%rsp), %rax
    268b:      	cmpb	$-0x44, 0x1e(%rax)
    268f:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    2695:      	movq	(%rsp), %rax
    2699:      	cmpb	$-0x44, 0x1f(%rax)
    269d:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    26a3:      	movq	(%rsp), %rax
    26a7:      	cmpb	$-0x44, 0x20(%rax)
    26ab:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    26b1:      	movl	$0xc0, %eax
    26b6:      	movl	$0x70, %ecx
    26bb:      	movq	0x28(%rsp), %rdx
    26c0:      	movq	%r15, %rdi
    26c3:      	movl	$0xc0, %esi
    26c8:      	callq	*%rcx
    26ca:      	testq	%rax, %rax
    26cd:      	jne	0x1e36 <perf_unwind_python+0x1e36>
    26d3:      	movq	(%rsp), %rax
    26d7:      	movzbl	0x1d(%rax), %ecx
    26db:      	movl	(%r15,%rcx), %ecx
    26df:      	movzbl	0x1e(%rax), %edx
    26e3:      	movl	(%r15,%rdx), %edx
    26e7:      	movzbl	0x1f(%rax), %esi
    26eb:      	movl	(%r15,%rsi), %esi
    26ef:      	movzbl	0x20(%rax), %eax
    26f3:      	shll	$0x19, %ecx
    26f6:      	shll	$0x12, %edx
    26f9:      	addl	%ecx, %edx
    26fb:      	shll	$0xa, %esi
    26fe:      	addl	%edx, %esi
    2700:      	addl	(%r15,%rax), %esi
    2704:      	shlq	$0x20, %r12
    2708:      	orq	%rsi, %r12
    270b:      	jmp	0x2a3d <perf_unwind_python+0x2a3d>
    2710:      	cmpl	$0x0, (%r14)
    2714:      	je	0x279c <perf_unwind_python+0x279c>
    271a:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    2724:      	movq	%rax, 0x57(%rsp)
    2729:      	movabsq	$0x20786c2578302074, %rax # imm = 0x20786C2578302074
    2733:      	movq	%rax, 0x50(%rsp)
    2738:      	movabsq	$0x63656a624f656d61, %rax # imm = 0x63656A624F656D61
    2742:      	movq	%rax, 0x48(%rsp)
    2747:      	movabsq	$0x7246795020726f66, %rax # imm = 0x7246795020726F66
    2751:      	movq	%rax, 0x40(%rsp)
    2756:      	movabsq	$0x207463656a626f65, %rax # imm = 0x207463656A626F65
    2760:      	movq	%rax, 0x38(%rsp)
    2765:      	movabsq	$0x646f63206c6c754e, %rax # imm = 0x646F63206C6C754E
    276f:      	movq	%rax, 0x30(%rsp)
    2774:      	leaq	0x30(%rsp), %rdi
    2779:      	movl	$0x2f, %eax
    277e:      	movl	$0x6, %r8d
    2784:      	movq	(%rsp), %rax
    2788:      	movzbl	0x19(%rax), %ecx
    278c:      	addq	%r13, %rcx
    278f:      	movl	$0x2f, %esi
    2794:      	movq	%r13, %rdx
    2797:      	xorl	%eax, %eax
    2799:      	callq	*%r8
    279c:      	movl	$0x1c, 0x18(%rsp)
    27a4:      	movq	(%rip), %rdi            # 0x27ab <perf_unwind_python+0x27ab>
    27ab:      	leaq	0x18(%rsp), %rsi
    27b0:      	movl	$0x1, %eax
    27b5:      	callq	*%rax
    27b7:      	testq	%rax, %rax
    27ba:      	je	0x29b3 <perf_unwind_python+0x29b3>
    27c0:      	incq	(%rax)
    27c3:      	jmp	0x2a2f <perf_unwind_python+0x2a2f>
    27c8:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    27d2:      	movq	%rax, 0x57(%rsp)
    27d7:      	movabsq	$0x20786c2578302074, %rax # imm = 0x20786C2578302074
    27e1:      	movq	%rax, 0x50(%rsp)
    27e6:      	movabsq	$0x63656a624f656d61, %rax # imm = 0x63656A624F656D61
    27f0:      	movq	%rax, 0x48(%rsp)
    27f5:      	movabsq	$0x7246795020726f66, %rax # imm = 0x7246795020726F66
    27ff:      	movq	%rax, 0x40(%rsp)
    2804:      	movabsq	$0x207463656a626f65, %rax # imm = 0x207463656A626F65
    280e:      	movq	%rax, 0x38(%rsp)
    2813:      	movabsq	$0x646f63206c6c754e, %rax # imm = 0x646F63206C6C754E
    281d:      	movq	%rax, 0x30(%rsp)
    2822:      	leaq	0x30(%rsp), %rdi
    2827:      	movl	$0x2f, %eax
    282c:      	movl	$0x6, %r8d
    2832:      	movq	(%rsp), %rax
    2836:      	movzbl	0x19(%rax), %ecx
    283a:      	movq	0x20(%rsp), %rdx
    283f:      	addq	%rdx, %rcx
    2842:      	movl	$0x2f, %esi
    2847:      	xorl	%eax, %eax
    2849:      	callq	*%r8
    284c:      	jmp	0x2304 <perf_unwind_python+0x2304>
    2851:      	movabsq	$0xa756c2520786c, %rax  # imm = 0xA756C2520786C
    285b:      	movq	%rax, 0x40(%rsp)
    2860:      	movabsq	$0x25206e6f68747950, %rax # imm = 0x25206E6F68747950
    286a:      	movq	%rax, 0x38(%rsp)
    286f:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    2879:      	movq	%rax, 0x30(%rsp)
    287e:      	leaq	0x30(%rsp), %rdi
    2883:      	movl	$0x18, %eax
    2888:      	movl	$0x6, %r8d
    288e:      	movl	$0x18, %esi
    2893:      	movq	0x28(%rsp), %rdx
    2898:      	movq	%r12, %rcx
    289b:      	xorl	%eax, %eax
    289d:      	callq	*%r8
    28a0:      	movl	0x2c0(%rbp), %eax
    28a6:      	cmpq	$0x7e, %rax
    28aa:      	ja	0x1777 <perf_unwind_python+0x1777>
    28b0:      	jmp	0x23e9 <perf_unwind_python+0x23e9>
    28b5:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    28bf:      	movq	%rax, 0x56(%rsp)
    28c4:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    28ce:      	movq	%rax, 0x50(%rsp)
    28d3:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    28dd:      	movq	%rax, 0x48(%rsp)
    28e2:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    28ec:      	movq	%rax, 0x40(%rsp)
    28f1:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    28fb:      	movq	%rax, 0x38(%rsp)
    2900:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    290a:      	movq	%rax, 0x30(%rsp)
    290f:      	leaq	0x30(%rsp), %rdi
    2914:      	movl	$0x2e, %eax
    2919:      	movl	$0x6, %ecx
    291e:      	movl	0x18(%rsp), %edx
    2922:      	movl	$0x2e, %esi
    2927:      	xorl	%eax, %eax
    2929:      	callq	*%rcx
    292b:      	jmp	0x23c1 <perf_unwind_python+0x23c1>
    2930:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    293a:      	movq	%rax, 0x56(%rsp)
    293f:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2949:      	movq	%rax, 0x50(%rsp)
    294e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2958:      	movq	%rax, 0x48(%rsp)
    295d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2967:      	movq	%rax, 0x40(%rsp)
    296c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2976:      	movq	%rax, 0x38(%rsp)
    297b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2985:      	movq	%rax, 0x30(%rsp)
    298a:      	leaq	0x30(%rsp), %rdi
    298f:      	movl	$0x2e, %eax
    2994:      	movl	$0x6, %ecx
    2999:      	movl	0x18(%rsp), %edx
    299d:      	movl	$0x2e, %esi
    29a2:      	xorl	%eax, %eax
    29a4:      	callq	*%rcx
    29a6:      	testb	%bl, %bl
    29a8:      	jne	0x124c <perf_unwind_python+0x124c>
    29ae:      	jmp	0x24ea <perf_unwind_python+0x24ea>
    29b3:      	cmpl	$0x0, (%r14)
    29b7:      	je	0x2a2f <perf_unwind_python+0x2a2f>
    29b9:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    29c3:      	movq	%rax, 0x56(%rsp)
    29c8:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    29d2:      	movq	%rax, 0x50(%rsp)
    29d7:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    29e1:      	movq	%rax, 0x48(%rsp)
    29e6:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    29f0:      	movq	%rax, 0x40(%rsp)
    29f5:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    29ff:      	movq	%rax, 0x38(%rsp)
    2a04:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2a0e:      	movq	%rax, 0x30(%rsp)
    2a13:      	leaq	0x30(%rsp), %rdi
    2a18:      	movl	$0x2e, %eax
    2a1d:      	movl	$0x6, %ecx
    2a22:      	movl	0x18(%rsp), %edx
    2a26:      	movl	$0x2e, %esi
    2a2b:      	xorl	%eax, %eax
    2a2d:      	callq	*%rcx
    2a2f:      	movq	$-0x2, %r12
    2a36:      	xorl	%eax, %eax
    2a38:      	movq	%rax, 0x28(%rsp)
    2a3d:      	cmpl	$0x0, (%r14)
    2a41:      	je	0x2a92 <perf_unwind_python+0x2a92>
    2a43:      	movabsq	$0xa756c2520786c, %rax  # imm = 0xA756C2520786C
    2a4d:      	movq	%rax, 0x40(%rsp)
    2a52:      	movabsq	$0x25206e6f68747950, %rax # imm = 0x25206E6F68747950
    2a5c:      	movq	%rax, 0x38(%rsp)
    2a61:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    2a6b:      	movq	%rax, 0x30(%rsp)
    2a70:      	leaq	0x30(%rsp), %rdi
    2a75:      	movl	$0x18, %eax
    2a7a:      	movl	$0x6, %r8d
    2a80:      	movl	$0x18, %esi
    2a85:      	movq	0x28(%rsp), %rdx
    2a8a:      	movq	%r12, %rcx
    2a8d:      	xorl	%eax, %eax
    2a8f:      	callq	*%r8
    2a92:      	movl	0x2c0(%rbp), %eax
    2a98:      	cmpq	$0x7e, %rax
    2a9c:      	ja	0x1f31 <perf_unwind_python+0x1f31>
    2aa2:      	leal	0x1(%rax), %ecx
    2aa5:      	movl	%ecx, 0x2c0(%rbp)
    2aab:      	leaq	(%rax,%rax,2), %rax
    2aaf:      	movq	0x28(%rsp), %rcx
    2ab4:      	movq	%rcx, 0x2d0(%rbp,%rax,8)
    2abc:      	movq	%r12, 0x2d8(%rbp,%rax,8)
    2ac4:      	movb	$0x1, 0x2e0(%rbp,%rax,8)
    2acc:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    2ad7:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    2ae2:      	movl	$0x16, 0x18(%rsp)
    2aea:      	movq	(%rip), %rdi            # 0x2af1 <perf_unwind_python+0x2af1>
    2af1:      	leaq	0x18(%rsp), %rsi
    2af6:      	movl	$0x1, %eax
    2afb:      	callq	*%rax
    2afd:      	testq	%rax, %rax
    2b00:      	je	0x2b07 <perf_unwind_python+0x2b07>
    2b02:      	incq	(%rax)
    2b05:      	jmp	0x2b83 <perf_unwind_python+0x2b83>
    2b07:      	cmpl	$0x0, (%r14)
    2b0b:      	je	0x2b83 <perf_unwind_python+0x2b83>
    2b0d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2b17:      	movq	%rax, 0x56(%rsp)
    2b1c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2b26:      	movq	%rax, 0x50(%rsp)
    2b2b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2b35:      	movq	%rax, 0x48(%rsp)
    2b3a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2b44:      	movq	%rax, 0x40(%rsp)
    2b49:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2b53:      	movq	%rax, 0x38(%rsp)
    2b58:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2b62:      	movq	%rax, 0x30(%rsp)
    2b67:      	leaq	0x30(%rsp), %rdi
    2b6c:      	movl	$0x2e, %eax
    2b71:      	movl	$0x6, %ecx
    2b76:      	movl	0x18(%rsp), %edx
    2b7a:      	movl	$0x2e, %esi
    2b7f:      	xorl	%eax, %eax
    2b81:      	callq	*%rcx
    2b83:      	testb	%bl, %bl
    2b85:      	jne	0x1d64 <perf_unwind_python+0x1d64>
    2b8b:      	xorl	%r12d, %r12d
    2b8e:      	cmpq	$0x0, 0x20(%rsp)
    2b94:      	je	0x45be <perf_unwind_python+0x45be>
    2b9a:      	movq	(%rsp), %rax
    2b9e:      	cmpb	$0x78, 0x19(%rax)
    2ba2:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    2ba8:      	movq	(%rsp), %rax
    2bac:      	cmpb	$0x78, 0x18(%rax)
    2bb0:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    2bb6:      	movq	(%rsp), %rax
    2bba:      	cmpb	$0x78, 0x1a(%rax)
    2bbe:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    2bc4:      	movq	(%rsp), %rax
    2bc8:      	cmpb	$0x0, 0x1b(%rax)
    2bcc:      	js	0x45a2 <perf_unwind_python+0x45a2>
    2bd2:      	movl	$0x80, %eax
    2bd7:      	movl	$0x70, %ecx
    2bdc:      	movq	0x70(%rsp), %rdi
    2be1:      	movq	0x20(%rsp), %rdx
    2be6:      	movl	$0x80, %esi
    2beb:      	callq	*%rcx
    2bed:      	testq	%rax, %rax
    2bf0:      	jne	0xd60 <perf_unwind_python+0xd60>
    2bf6:      	movq	(%rsp), %rax
    2bfa:      	movzbl	0x19(%rax), %ecx
    2bfe:      	movq	0x70(%rsp), %rdx
    2c03:      	movq	(%rdx,%rcx), %rcx
    2c07:      	movq	%rcx, 0x28(%rsp)
    2c0c:      	movzbl	0x18(%rax), %ecx
    2c10:      	movq	(%rdx,%rcx), %r13
    2c14:      	movq	0x8(%rax), %rax
    2c18:      	testq	%rax, %rax
    2c1b:      	je	0x2c28 <perf_unwind_python+0x2c28>
    2c1d:      	cmpq	%rax, 0x28(%rsp)
    2c22:      	je	0x124c <perf_unwind_python+0x124c>
    2c28:      	movq	(%rsp), %rax
    2c2c:      	cmpb	$0x0, 0x22(%rax)
    2c30:      	movzbl	0x1a(%rax), %eax
    2c34:      	je	0x2c78 <perf_unwind_python+0x2c78>
    2c36:      	movq	0x70(%rsp), %rsi
    2c3b:      	movq	(%rsi,%rax), %rax
    2c3f:      	movq	(%rsp), %rcx
    2c43:      	movzbl	0x21(%rcx), %edx
    2c47:      	addq	0x28(%rsp), %rdx
    2c4c:      	subq	%rdx, %rax
    2c4f:      	leaq	-0x10000001(%rax), %rdx
    2c56:      	sarl	%eax
    2c58:      	cmpq	$-0x10000003, %rdx      # imm = 0xEFFFFFFD
    2c5f:      	movl	$0xffffffff, %ebx       # imm = 0xFFFFFFFF
    2c64:      	cmovael	%eax, %ebx
    2c67:      	movzbl	0x1b(%rcx), %eax
    2c6b:      	movzbl	(%rsi,%rax), %eax
    2c6f:      	cmpb	0x1c(%rcx), %al
    2c72:      	sete	%r12b
    2c76:      	jmp	0x2c83 <perf_unwind_python+0x2c83>
    2c78:      	movq	0x70(%rsp), %rcx
    2c7d:      	movl	(%rcx,%rax), %ebx
    2c80:      	xorl	%r12d, %r12d
    2c83:      	cmpq	$0x0, 0x28(%rsp)
    2c89:      	je	0x2d26 <perf_unwind_python+0x2d26>
    2c8f:      	movq	(%rsp), %rax
    2c93:      	cmpb	$-0x44, 0x1d(%rax)
    2c97:      	ja	0x460a <perf_unwind_python+0x460a>
    2c9d:      	movq	(%rsp), %rax
    2ca1:      	cmpb	$-0x44, 0x1e(%rax)
    2ca5:      	ja	0x460a <perf_unwind_python+0x460a>
    2cab:      	movq	(%rsp), %rax
    2caf:      	cmpb	$-0x44, 0x1f(%rax)
    2cb3:      	ja	0x460a <perf_unwind_python+0x460a>
    2cb9:      	movq	(%rsp), %rax
    2cbd:      	cmpb	$-0x44, 0x20(%rax)
    2cc1:      	ja	0x460a <perf_unwind_python+0x460a>
    2cc7:      	movl	$0xc0, %eax
    2ccc:      	movl	$0x70, %ecx
    2cd1:      	movq	0x28(%rsp), %rdx
    2cd6:      	movq	%r15, %rdi
    2cd9:      	movl	$0xc0, %esi
    2cde:      	callq	*%rcx
    2ce0:      	testq	%rax, %rax
    2ce3:      	jne	0x2bc <perf_unwind_python+0x2bc>
    2ce9:      	movq	(%rsp), %rax
    2ced:      	movzbl	0x1d(%rax), %ecx
    2cf1:      	movl	(%r15,%rcx), %ecx
    2cf5:      	movzbl	0x1e(%rax), %edx
    2cf9:      	movl	(%r15,%rdx), %edx
    2cfd:      	movzbl	0x1f(%rax), %esi
    2d01:      	movl	(%r15,%rsi), %esi
    2d05:      	movzbl	0x20(%rax), %eax
    2d09:      	shll	$0x19, %ecx
    2d0c:      	shll	$0x12, %edx
    2d0f:      	addl	%ecx, %edx
    2d11:      	shll	$0xa, %esi
    2d14:      	addl	%edx, %esi
    2d16:      	addl	(%r15,%rax), %esi
    2d1a:      	shlq	$0x20, %rbx
    2d1e:      	orq	%rsi, %rbx
    2d21:      	jmp	0x2e63 <perf_unwind_python+0x2e63>
    2d26:      	cmpl	$0x0, (%r14)
    2d2a:      	je	0x2db4 <perf_unwind_python+0x2db4>
    2d30:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    2d3a:      	movq	%rax, 0x57(%rsp)
    2d3f:      	movabsq	$0x20786c2578302074, %rax # imm = 0x20786C2578302074
    2d49:      	movq	%rax, 0x50(%rsp)
    2d4e:      	movabsq	$0x63656a624f656d61, %rax # imm = 0x63656A624F656D61
    2d58:      	movq	%rax, 0x48(%rsp)
    2d5d:      	movabsq	$0x7246795020726f66, %rax # imm = 0x7246795020726F66
    2d67:      	movq	%rax, 0x40(%rsp)
    2d6c:      	movabsq	$0x207463656a626f65, %rax # imm = 0x207463656A626F65
    2d76:      	movq	%rax, 0x38(%rsp)
    2d7b:      	movabsq	$0x646f63206c6c754e, %rax # imm = 0x646F63206C6C754E
    2d85:      	movq	%rax, 0x30(%rsp)
    2d8a:      	leaq	0x30(%rsp), %rdi
    2d8f:      	movl	$0x2f, %eax
    2d94:      	movl	$0x6, %r8d
    2d9a:      	movq	(%rsp), %rax
    2d9e:      	movzbl	0x19(%rax), %ecx
    2da2:      	movq	0x20(%rsp), %rdx
    2da7:      	addq	%rdx, %rcx
    2daa:      	movl	$0x2f, %esi
    2daf:      	xorl	%eax, %eax
    2db1:      	callq	*%r8
    2db4:      	movl	$0x1c, 0x18(%rsp)
    2dbc:      	movq	(%rip), %rdi            # 0x2dc3 <perf_unwind_python+0x2dc3>
    2dc3:      	leaq	0x18(%rsp), %rsi
    2dc8:      	movl	$0x1, %eax
    2dcd:      	callq	*%rax
    2dcf:      	testq	%rax, %rax
    2dd2:      	je	0x2dd9 <perf_unwind_python+0x2dd9>
    2dd4:      	incq	(%rax)
    2dd7:      	jmp	0x2e55 <perf_unwind_python+0x2e55>
    2dd9:      	cmpl	$0x0, (%r14)
    2ddd:      	je	0x2e55 <perf_unwind_python+0x2e55>
    2ddf:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2de9:      	movq	%rax, 0x56(%rsp)
    2dee:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2df8:      	movq	%rax, 0x50(%rsp)
    2dfd:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2e07:      	movq	%rax, 0x48(%rsp)
    2e0c:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2e16:      	movq	%rax, 0x40(%rsp)
    2e1b:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2e25:      	movq	%rax, 0x38(%rsp)
    2e2a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2e34:      	movq	%rax, 0x30(%rsp)
    2e39:      	leaq	0x30(%rsp), %rdi
    2e3e:      	movl	$0x2e, %eax
    2e43:      	movl	$0x6, %ecx
    2e48:      	movl	0x18(%rsp), %edx
    2e4c:      	movl	$0x2e, %esi
    2e51:      	xorl	%eax, %eax
    2e53:      	callq	*%rcx
    2e55:      	movq	$-0x2, %rbx
    2e5c:      	xorl	%eax, %eax
    2e5e:      	movq	%rax, 0x28(%rsp)
    2e63:      	cmpl	$0x0, (%r14)
    2e67:      	je	0x2eb8 <perf_unwind_python+0x2eb8>
    2e69:      	movabsq	$0xa756c2520786c, %rax  # imm = 0xA756C2520786C
    2e73:      	movq	%rax, 0x40(%rsp)
    2e78:      	movabsq	$0x25206e6f68747950, %rax # imm = 0x25206E6F68747950
    2e82:      	movq	%rax, 0x38(%rsp)
    2e87:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    2e91:      	movq	%rax, 0x30(%rsp)
    2e96:      	leaq	0x30(%rsp), %rdi
    2e9b:      	movl	$0x18, %eax
    2ea0:      	movl	$0x6, %r8d
    2ea6:      	movl	$0x18, %esi
    2eab:      	movq	0x28(%rsp), %rdx
    2eb0:      	movq	%rbx, %rcx
    2eb3:      	xorl	%eax, %eax
    2eb5:      	callq	*%r8
    2eb8:      	movl	0x2c0(%rbp), %eax
    2ebe:      	cmpq	$0x7e, %rax
    2ec2:      	ja	0x1777 <perf_unwind_python+0x1777>
    2ec8:      	leal	0x1(%rax), %ecx
    2ecb:      	movl	%ecx, 0x2c0(%rbp)
    2ed1:      	leaq	(%rax,%rax,2), %rax
    2ed5:      	movq	0x28(%rsp), %rcx
    2eda:      	movq	%rcx, 0x2d0(%rbp,%rax,8)
    2ee2:      	movq	%rbx, 0x2d8(%rbp,%rax,8)
    2eea:      	movb	$0x1, 0x2e0(%rbp,%rax,8)
    2ef2:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    2efd:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    2f08:      	movl	$0x16, 0x18(%rsp)
    2f10:      	movq	(%rip), %rdi            # 0x2f17 <perf_unwind_python+0x2f17>
    2f17:      	leaq	0x18(%rsp), %rsi
    2f1c:      	movl	$0x1, %eax
    2f21:      	callq	*%rax
    2f23:      	testq	%rax, %rax
    2f26:      	je	0x2f2d <perf_unwind_python+0x2f2d>
    2f28:      	incq	(%rax)
    2f2b:      	jmp	0x2fa9 <perf_unwind_python+0x2fa9>
    2f2d:      	cmpl	$0x0, (%r14)
    2f31:      	je	0x2fa9 <perf_unwind_python+0x2fa9>
    2f33:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2f3d:      	movq	%rax, 0x56(%rsp)
    2f42:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2f4c:      	movq	%rax, 0x50(%rsp)
    2f51:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2f5b:      	movq	%rax, 0x48(%rsp)
    2f60:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2f6a:      	movq	%rax, 0x40(%rsp)
    2f6f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2f79:      	movq	%rax, 0x38(%rsp)
    2f7e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2f88:      	movq	%rax, 0x30(%rsp)
    2f8d:      	leaq	0x30(%rsp), %rdi
    2f92:      	movl	$0x2e, %eax
    2f97:      	movl	$0x6, %ecx
    2f9c:      	movl	0x18(%rsp), %edx
    2fa0:      	movl	$0x2e, %esi
    2fa5:      	xorl	%eax, %eax
    2fa7:      	callq	*%rcx
    2fa9:      	testb	%r12b, %r12b
    2fac:      	jne	0x124c <perf_unwind_python+0x124c>
    2fb2:      	xorl	%r12d, %r12d
    2fb5:      	testq	%r13, %r13
    2fb8:      	je	0x45be <perf_unwind_python+0x45be>
    2fbe:      	movq	(%rsp), %rax
    2fc2:      	cmpb	$0x78, 0x19(%rax)
    2fc6:      	ja	0x460a <perf_unwind_python+0x460a>
    2fcc:      	movq	(%rsp), %rax
    2fd0:      	cmpb	$0x78, 0x18(%rax)
    2fd4:      	ja	0x460a <perf_unwind_python+0x460a>
    2fda:      	movq	(%rsp), %rax
    2fde:      	cmpb	$0x78, 0x1a(%rax)
    2fe2:      	ja	0x460a <perf_unwind_python+0x460a>
    2fe8:      	movq	(%rsp), %rax
    2fec:      	cmpb	$0x0, 0x1b(%rax)
    2ff0:      	js	0x460a <perf_unwind_python+0x460a>
    2ff6:      	movl	$0x80, %eax
    2ffb:      	movl	$0x70, %ecx
    3000:      	movq	0x70(%rsp), %rdi
    3005:      	movl	$0x80, %esi
    300a:      	movq	%r13, %rdx
    300d:      	callq	*%rcx
    300f:      	testq	%rax, %rax
    3012:      	jne	0x1d27 <perf_unwind_python+0x1d27>
    3018:      	movq	(%rsp), %rax
    301c:      	movzbl	0x19(%rax), %ecx
    3020:      	movq	0x70(%rsp), %rdx
    3025:      	movq	(%rdx,%rcx), %rcx
    3029:      	movq	%rcx, 0x28(%rsp)
    302e:      	movzbl	0x18(%rax), %ecx
    3032:      	movq	(%rdx,%rcx), %rcx
    3036:      	movq	%rcx, 0x20(%rsp)
    303b:      	movq	0x8(%rax), %rax
    303f:      	testq	%rax, %rax
    3042:      	je	0x304f <perf_unwind_python+0x304f>
    3044:      	cmpq	%rax, 0x28(%rsp)
    3049:      	je	0x1d64 <perf_unwind_python+0x1d64>
    304f:      	movq	(%rsp), %rax
    3053:      	cmpb	$0x0, 0x22(%rax)
    3057:      	movzbl	0x1a(%rax), %eax
    305b:      	je	0x30a4 <perf_unwind_python+0x30a4>
    305d:      	movq	0x70(%rsp), %rsi
    3062:      	movq	(%rsi,%rax), %rax
    3066:      	movq	(%rsp), %rcx
    306a:      	movzbl	0x21(%rcx), %edx
    306e:      	addq	0x28(%rsp), %rdx
    3073:      	subq	%rdx, %rax
    3076:      	leaq	-0x10000001(%rax), %rdx
    307d:      	sarl	%eax
    307f:      	cmpq	$-0x10000003, %rdx      # imm = 0xEFFFFFFD
    3086:      	movl	$0xffffffff, %r12d      # imm = 0xFFFFFFFF
    308c:      	cmovael	%eax, %r12d
    3090:      	movzbl	0x1b(%rcx), %eax
    3094:      	movzbl	(%rsi,%rax), %eax
    3098:      	cmpb	0x1c(%rcx), %al
    309b:      	sete	%al
    309e:      	movl	%eax, 0x78(%rsp)
    30a2:      	jmp	0x30b5 <perf_unwind_python+0x30b5>
    30a4:      	movq	0x70(%rsp), %rcx
    30a9:      	movl	(%rcx,%rax), %r12d
    30ad:      	movl	$0x0, 0x78(%rsp)
    30b5:      	cmpq	$0x0, 0x28(%rsp)
    30bb:      	je	0x3158 <perf_unwind_python+0x3158>
    30c1:      	movq	(%rsp), %rax
    30c5:      	cmpb	$-0x44, 0x1d(%rax)
    30c9:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    30cf:      	movq	(%rsp), %rax
    30d3:      	cmpb	$-0x44, 0x1e(%rax)
    30d7:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    30dd:      	movq	(%rsp), %rax
    30e1:      	cmpb	$-0x44, 0x1f(%rax)
    30e5:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    30eb:      	movq	(%rsp), %rax
    30ef:      	cmpb	$-0x44, 0x20(%rax)
    30f3:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    30f9:      	movl	$0xc0, %eax
    30fe:      	movl	$0x70, %ecx
    3103:      	movq	0x28(%rsp), %rdx
    3108:      	movq	%r15, %rdi
    310b:      	movl	$0xc0, %esi
    3110:      	callq	*%rcx
    3112:      	testq	%rax, %rax
    3115:      	jne	0x1e36 <perf_unwind_python+0x1e36>
    311b:      	movq	(%rsp), %rax
    311f:      	movzbl	0x1d(%rax), %ecx
    3123:      	movl	(%r15,%rcx), %ecx
    3127:      	movzbl	0x1e(%rax), %edx
    312b:      	movl	(%r15,%rdx), %edx
    312f:      	movzbl	0x1f(%rax), %esi
    3133:      	movl	(%r15,%rsi), %esi
    3137:      	movzbl	0x20(%rax), %eax
    313b:      	shll	$0x19, %ecx
    313e:      	shll	$0x12, %edx
    3141:      	addl	%ecx, %edx
    3143:      	shll	$0xa, %esi
    3146:      	addl	%edx, %esi
    3148:      	addl	(%r15,%rax), %esi
    314c:      	shlq	$0x20, %r12
    3150:      	orq	%rsi, %r12
    3153:      	jmp	0x3293 <perf_unwind_python+0x3293>
    3158:      	cmpl	$0x0, (%r14)
    315c:      	je	0x31e4 <perf_unwind_python+0x31e4>
    3162:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    316c:      	movq	%rax, 0x57(%rsp)
    3171:      	movabsq	$0x20786c2578302074, %rax # imm = 0x20786C2578302074
    317b:      	movq	%rax, 0x50(%rsp)
    3180:      	movabsq	$0x63656a624f656d61, %rax # imm = 0x63656A624F656D61
    318a:      	movq	%rax, 0x48(%rsp)
    318f:      	movabsq	$0x7246795020726f66, %rax # imm = 0x7246795020726F66
    3199:      	movq	%rax, 0x40(%rsp)
    319e:      	movabsq	$0x207463656a626f65, %rax # imm = 0x207463656A626F65
    31a8:      	movq	%rax, 0x38(%rsp)
    31ad:      	movabsq	$0x646f63206c6c754e, %rax # imm = 0x646F63206C6C754E
    31b7:      	movq	%rax, 0x30(%rsp)
    31bc:      	leaq	0x30(%rsp), %rdi
    31c1:      	movl	$0x2f, %eax
    31c6:      	movl	$0x6, %r8d
    31cc:      	movq	(%rsp), %rax
    31d0:      	movzbl	0x19(%rax), %ecx
    31d4:      	addq	%r13, %rcx
    31d7:      	movl	$0x2f, %esi
    31dc:      	movq	%r13, %rdx
    31df:      	xorl	%eax, %eax
    31e1:      	callq	*%r8
    31e4:      	movl	$0x1c, 0x18(%rsp)
    31ec:      	movq	(%rip), %rdi            # 0x31f3 <perf_unwind_python+0x31f3>
    31f3:      	leaq	0x18(%rsp), %rsi
    31f8:      	movl	$0x1, %eax
    31fd:      	callq	*%rax
    31ff:      	testq	%rax, %rax
    3202:      	je	0x3209 <perf_unwind_python+0x3209>
    3204:      	incq	(%rax)
    3207:      	jmp	0x3285 <perf_unwind_python+0x3285>
    3209:      	cmpl	$0x0, (%r14)
    320d:      	je	0x3285 <perf_unwind_python+0x3285>
    320f:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3219:      	movq	%rax, 0x56(%rsp)
    321e:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3228:      	movq	%rax, 0x50(%rsp)
    322d:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3237:      	movq	%rax, 0x48(%rsp)
    323c:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3246:      	movq	%rax, 0x40(%rsp)
    324b:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3255:      	movq	%rax, 0x38(%rsp)
    325a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3264:      	movq	%rax, 0x30(%rsp)
    3269:      	leaq	0x30(%rsp), %rdi
    326e:      	movl	$0x2e, %eax
    3273:      	movl	$0x6, %ecx
    3278:      	movl	0x18(%rsp), %edx
    327c:      	movl	$0x2e, %esi
    3281:      	xorl	%eax, %eax
    3283:      	callq	*%rcx
    3285:      	movq	$-0x2, %r12
    328c:      	xorl	%eax, %eax
    328e:      	movq	%rax, 0x28(%rsp)
    3293:      	cmpl	$0x0, (%r14)
    3297:      	je	0x32e8 <perf_unwind_python+0x32e8>
    3299:      	movabsq	$0xa756c2520786c, %rax  # imm = 0xA756C2520786C
    32a3:      	movq	%rax, 0x40(%rsp)
    32a8:      	movabsq	$0x25206e6f68747950, %rax # imm = 0x25206E6F68747950
    32b2:      	movq	%rax, 0x38(%rsp)
    32b7:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    32c1:      	movq	%rax, 0x30(%rsp)
    32c6:      	leaq	0x30(%rsp), %rdi
    32cb:      	movl	$0x18, %eax
    32d0:      	movl	$0x6, %r8d
    32d6:      	movl	$0x18, %esi
    32db:      	movq	0x28(%rsp), %rdx
    32e0:      	movq	%r12, %rcx
    32e3:      	xorl	%eax, %eax
    32e5:      	callq	*%r8
    32e8:      	movl	0x2c0(%rbp), %eax
    32ee:      	cmpq	$0x7e, %rax
    32f2:      	ja	0x1f31 <perf_unwind_python+0x1f31>
    32f8:      	leal	0x1(%rax), %ecx
    32fb:      	movl	%ecx, 0x2c0(%rbp)
    3301:      	leaq	(%rax,%rax,2), %rax
    3305:      	movq	0x28(%rsp), %rcx
    330a:      	movq	%rcx, 0x2d0(%rbp,%rax,8)
    3312:      	movq	%r12, 0x2d8(%rbp,%rax,8)
    331a:      	movb	$0x1, 0x2e0(%rbp,%rax,8)
    3322:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    332d:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    3338:      	movl	$0x16, 0x18(%rsp)
    3340:      	movq	(%rip), %rdi            # 0x3347 <perf_unwind_python+0x3347>
    3347:      	leaq	0x18(%rsp), %rsi
    334c:      	movl	$0x1, %eax
    3351:      	callq	*%rax
    3353:      	testq	%rax, %rax
    3356:      	je	0x335d <perf_unwind_python+0x335d>
    3358:      	incq	(%rax)
    335b:      	jmp	0x33d9 <perf_unwind_python+0x33d9>
    335d:      	cmpl	$0x0, (%r14)
    3361:      	je	0x33d9 <perf_unwind_python+0x33d9>
    3363:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    336d:      	movq	%rax, 0x56(%rsp)
    3372:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    337c:      	movq	%rax, 0x50(%rsp)
    3381:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    338b:      	movq	%rax, 0x48(%rsp)
    3390:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    339a:      	movq	%rax, 0x40(%rsp)
    339f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    33a9:      	movq	%rax, 0x38(%rsp)
    33ae:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    33b8:      	movq	%rax, 0x30(%rsp)
    33bd:      	leaq	0x30(%rsp), %rdi
    33c2:      	movl	$0x2e, %eax
    33c7:      	movl	$0x6, %ecx
    33cc:      	movl	0x18(%rsp), %edx
    33d0:      	movl	$0x2e, %esi
    33d5:      	xorl	%eax, %eax
    33d7:      	callq	*%rcx
    33d9:      	cmpb	$0x0, 0x78(%rsp)
    33de:      	jne	0x1d64 <perf_unwind_python+0x1d64>
    33e4:      	xorl	%r12d, %r12d
    33e7:      	cmpq	$0x0, 0x20(%rsp)
    33ed:      	je	0x45be <perf_unwind_python+0x45be>
    33f3:      	movq	(%rsp), %rax
    33f7:      	cmpb	$0x78, 0x19(%rax)
    33fb:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    3401:      	movq	(%rsp), %rax
    3405:      	cmpb	$0x78, 0x18(%rax)
    3409:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    340f:      	movq	(%rsp), %rax
    3413:      	cmpb	$0x78, 0x1a(%rax)
    3417:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    341d:      	movq	(%rsp), %rax
    3421:      	cmpb	$0x0, 0x1b(%rax)
    3425:      	js	0x45a2 <perf_unwind_python+0x45a2>
    342b:      	movl	$0x80, %eax
    3430:      	movl	$0x70, %ecx
    3435:      	movq	0x70(%rsp), %rdi
    343a:      	movq	0x20(%rsp), %rdx
    343f:      	movl	$0x80, %esi
    3444:      	callq	*%rcx
    3446:      	testq	%rax, %rax
    3449:      	jne	0xd60 <perf_unwind_python+0xd60>
    344f:      	movq	(%rsp), %rax
    3453:      	movzbl	0x19(%rax), %ecx
    3457:      	movq	0x70(%rsp), %rdx
    345c:      	movq	(%rdx,%rcx), %rcx
    3460:      	movq	%rcx, 0x28(%rsp)
    3465:      	movzbl	0x18(%rax), %ecx
    3469:      	movq	(%rdx,%rcx), %r13
    346d:      	movq	0x8(%rax), %rax
    3471:      	testq	%rax, %rax
    3474:      	je	0x3481 <perf_unwind_python+0x3481>
    3476:      	cmpq	%rax, 0x28(%rsp)
    347b:      	je	0x124c <perf_unwind_python+0x124c>
    3481:      	movq	(%rsp), %rax
    3485:      	cmpb	$0x0, 0x22(%rax)
    3489:      	movzbl	0x1a(%rax), %eax
    348d:      	je	0x34d6 <perf_unwind_python+0x34d6>
    348f:      	movq	0x70(%rsp), %rsi
    3494:      	movq	(%rsi,%rax), %rax
    3498:      	movq	(%rsp), %rcx
    349c:      	movzbl	0x21(%rcx), %edx
    34a0:      	addq	0x28(%rsp), %rdx
    34a5:      	subq	%rdx, %rax
    34a8:      	leaq	-0x10000001(%rax), %rdx
    34af:      	sarl	%eax
    34b1:      	cmpq	$-0x10000003, %rdx      # imm = 0xEFFFFFFD
    34b8:      	movl	$0xffffffff, %r12d      # imm = 0xFFFFFFFF
    34be:      	cmovael	%eax, %r12d
    34c2:      	movzbl	0x1b(%rcx), %eax
    34c6:      	movzbl	(%rsi,%rax), %eax
    34ca:      	cmpb	0x1c(%rcx), %al
    34cd:      	sete	%al
    34d0:      	movl	%eax, 0x78(%rsp)
    34d4:      	jmp	0x34e7 <perf_unwind_python+0x34e7>
    34d6:      	movq	0x70(%rsp), %rcx
    34db:      	movl	(%rcx,%rax), %r12d
    34df:      	movl	$0x0, 0x78(%rsp)
    34e7:      	cmpq	$0x0, 0x28(%rsp)
    34ed:      	je	0x358a <perf_unwind_python+0x358a>
    34f3:      	movq	(%rsp), %rax
    34f7:      	cmpb	$-0x44, 0x1d(%rax)
    34fb:      	ja	0x460a <perf_unwind_python+0x460a>
    3501:      	movq	(%rsp), %rax
    3505:      	cmpb	$-0x44, 0x1e(%rax)
    3509:      	ja	0x460a <perf_unwind_python+0x460a>
    350f:      	movq	(%rsp), %rax
    3513:      	cmpb	$-0x44, 0x1f(%rax)
    3517:      	ja	0x460a <perf_unwind_python+0x460a>
    351d:      	movq	(%rsp), %rax
    3521:      	cmpb	$-0x44, 0x20(%rax)
    3525:      	ja	0x460a <perf_unwind_python+0x460a>
    352b:      	movl	$0xc0, %eax
    3530:      	movl	$0x70, %ecx
    3535:      	movq	0x28(%rsp), %rdx
    353a:      	movq	%r15, %rdi
    353d:      	movl	$0xc0, %esi
    3542:      	callq	*%rcx
    3544:      	testq	%rax, %rax
    3547:      	jne	0x2bc <perf_unwind_python+0x2bc>
    354d:      	movq	(%rsp), %rax
    3551:      	movzbl	0x1d(%rax), %ecx
    3555:      	movl	(%r15,%rcx), %ecx
    3559:      	movzbl	0x1e(%rax), %edx
    355d:      	movl	(%r15,%rdx), %edx
    3561:      	movzbl	0x1f(%rax), %esi
    3565:      	movl	(%r15,%rsi), %esi
    3569:      	movzbl	0x20(%rax), %eax
    356d:      	shll	$0x19, %ecx
    3570:      	shll	$0x12, %edx
    3573:      	addl	%ecx, %edx
    3575:      	shll	$0xa, %esi
    3578:      	addl	%edx, %esi
    357a:      	addl	(%r15,%rax), %esi
    357e:      	shlq	$0x20, %r12
    3582:      	orq	%rsi, %r12
    3585:      	jmp	0x36c7 <perf_unwind_python+0x36c7>
    358a:      	cmpl	$0x0, (%r14)
    358e:      	je	0x3618 <perf_unwind_python+0x3618>
    3594:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    359e:      	movq	%rax, 0x57(%rsp)
    35a3:      	movabsq	$0x20786c2578302074, %rax # imm = 0x20786C2578302074
    35ad:      	movq	%rax, 0x50(%rsp)
    35b2:      	movabsq	$0x63656a624f656d61, %rax # imm = 0x63656A624F656D61
    35bc:      	movq	%rax, 0x48(%rsp)
    35c1:      	movabsq	$0x7246795020726f66, %rax # imm = 0x7246795020726F66
    35cb:      	movq	%rax, 0x40(%rsp)
    35d0:      	movabsq	$0x207463656a626f65, %rax # imm = 0x207463656A626F65
    35da:      	movq	%rax, 0x38(%rsp)
    35df:      	movabsq	$0x646f63206c6c754e, %rax # imm = 0x646F63206C6C754E
    35e9:      	movq	%rax, 0x30(%rsp)
    35ee:      	leaq	0x30(%rsp), %rdi
    35f3:      	movl	$0x2f, %eax
    35f8:      	movl	$0x6, %r8d
    35fe:      	movq	(%rsp), %rax
    3602:      	movzbl	0x19(%rax), %ecx
    3606:      	movq	0x20(%rsp), %rdx
    360b:      	addq	%rdx, %rcx
    360e:      	movl	$0x2f, %esi
    3613:      	xorl	%eax, %eax
    3615:      	callq	*%r8
    3618:      	movl	$0x1c, 0x18(%rsp)
    3620:      	movq	(%rip), %rdi            # 0x3627 <perf_unwind_python+0x3627>
    3627:      	leaq	0x18(%rsp), %rsi
    362c:      	movl	$0x1, %eax
    3631:      	callq	*%rax
    3633:      	testq	%rax, %rax
    3636:      	je	0x363d <perf_unwind_python+0x363d>
    3638:      	incq	(%rax)
    363b:      	jmp	0x36b9 <perf_unwind_python+0x36b9>
    363d:      	cmpl	$0x0, (%r14)
    3641:      	je	0x36b9 <perf_unwind_python+0x36b9>
    3643:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    364d:      	movq	%rax, 0x56(%rsp)
    3652:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    365c:      	movq	%rax, 0x50(%rsp)
    3661:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    366b:      	movq	%rax, 0x48(%rsp)
    3670:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    367a:      	movq	%rax, 0x40(%rsp)
    367f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3689:      	movq	%rax, 0x38(%rsp)
    368e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3698:      	movq	%rax, 0x30(%rsp)
    369d:      	leaq	0x30(%rsp), %rdi
    36a2:      	movl	$0x2e, %eax
    36a7:      	movl	$0x6, %ecx
    36ac:      	movl	0x18(%rsp), %edx
    36b0:      	movl	$0x2e, %esi
    36b5:      	xorl	%eax, %eax
    36b7:      	callq	*%rcx
    36b9:      	movq	$-0x2, %r12
    36c0:      	xorl	%eax, %eax
    36c2:      	movq	%rax, 0x28(%rsp)
    36c7:      	cmpl	$0x0, (%r14)
    36cb:      	je	0x371c <perf_unwind_python+0x371c>
    36cd:      	movabsq	$0xa756c2520786c, %rax  # imm = 0xA756C2520786C
    36d7:      	movq	%rax, 0x40(%rsp)
    36dc:      	movabsq	$0x25206e6f68747950, %rax # imm = 0x25206E6F68747950
    36e6:      	movq	%rax, 0x38(%rsp)
    36eb:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    36f5:      	movq	%rax, 0x30(%rsp)
    36fa:      	leaq	0x30(%rsp), %rdi
    36ff:      	movl	$0x18, %eax
    3704:      	movl	$0x6, %r8d
    370a:      	movl	$0x18, %esi
    370f:      	movq	0x28(%rsp), %rdx
    3714:      	movq	%r12, %rcx
    3717:      	xorl	%eax, %eax
    3719:      	callq	*%r8
    371c:      	movl	0x2c0(%rbp), %eax
    3722:      	cmpq	$0x7e, %rax
    3726:      	ja	0x1777 <perf_unwind_python+0x1777>
    372c:      	leal	0x1(%rax), %ecx
    372f:      	movl	%ecx, 0x2c0(%rbp)
    3735:      	leaq	(%rax,%rax,2), %rax
    3739:      	movq	0x28(%rsp), %rcx
    373e:      	movq	%rcx, 0x2d0(%rbp,%rax,8)
    3746:      	movq	%r12, 0x2d8(%rbp,%rax,8)
    374e:      	movb	$0x1, 0x2e0(%rbp,%rax,8)
    3756:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    3761:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    376c:      	movl	$0x16, 0x18(%rsp)
    3774:      	movq	(%rip), %rdi            # 0x377b <perf_unwind_python+0x377b>
    377b:      	leaq	0x18(%rsp), %rsi
    3780:      	movl	$0x1, %eax
    3785:      	callq	*%rax
    3787:      	testq	%rax, %rax
    378a:      	je	0x3791 <perf_unwind_python+0x3791>
    378c:      	incq	(%rax)
    378f:      	jmp	0x380d <perf_unwind_python+0x380d>
    3791:      	cmpl	$0x0, (%r14)
    3795:      	je	0x380d <perf_unwind_python+0x380d>
    3797:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    37a1:      	movq	%rax, 0x56(%rsp)
    37a6:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    37b0:      	movq	%rax, 0x50(%rsp)
    37b5:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    37bf:      	movq	%rax, 0x48(%rsp)
    37c4:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    37ce:      	movq	%rax, 0x40(%rsp)
    37d3:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    37dd:      	movq	%rax, 0x38(%rsp)
    37e2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    37ec:      	movq	%rax, 0x30(%rsp)
    37f1:      	leaq	0x30(%rsp), %rdi
    37f6:      	movl	$0x2e, %eax
    37fb:      	movl	$0x6, %ecx
    3800:      	movl	0x18(%rsp), %edx
    3804:      	movl	$0x2e, %esi
    3809:      	xorl	%eax, %eax
    380b:      	callq	*%rcx
    380d:      	cmpb	$0x0, 0x78(%rsp)
    3812:      	jne	0x124c <perf_unwind_python+0x124c>
    3818:      	xorl	%r12d, %r12d
    381b:      	testq	%r13, %r13
    381e:      	je	0x45be <perf_unwind_python+0x45be>
    3824:      	movq	(%rsp), %rax
    3828:      	cmpb	$0x78, 0x19(%rax)
    382c:      	ja	0x460a <perf_unwind_python+0x460a>
    3832:      	movq	(%rsp), %rax
    3836:      	cmpb	$0x78, 0x18(%rax)
    383a:      	ja	0x460a <perf_unwind_python+0x460a>
    3840:      	movq	(%rsp), %rax
    3844:      	cmpb	$0x78, 0x1a(%rax)
    3848:      	ja	0x460a <perf_unwind_python+0x460a>
    384e:      	movq	(%rsp), %rax
    3852:      	cmpb	$0x0, 0x1b(%rax)
    3856:      	js	0x460a <perf_unwind_python+0x460a>
    385c:      	movl	$0x80, %eax
    3861:      	movl	$0x70, %ecx
    3866:      	movq	0x70(%rsp), %rdi
    386b:      	movl	$0x80, %esi
    3870:      	movq	%r13, %rdx
    3873:      	callq	*%rcx
    3875:      	testq	%rax, %rax
    3878:      	jne	0x1d27 <perf_unwind_python+0x1d27>
    387e:      	movq	(%rsp), %rax
    3882:      	movzbl	0x19(%rax), %ecx
    3886:      	movq	0x70(%rsp), %rdx
    388b:      	movq	(%rdx,%rcx), %rcx
    388f:      	movq	%rcx, 0x28(%rsp)
    3894:      	movzbl	0x18(%rax), %ecx
    3898:      	movq	(%rdx,%rcx), %rcx
    389c:      	movq	%rcx, 0x20(%rsp)
    38a1:      	movq	0x8(%rax), %rax
    38a5:      	testq	%rax, %rax
    38a8:      	je	0x38b5 <perf_unwind_python+0x38b5>
    38aa:      	cmpq	%rax, 0x28(%rsp)
    38af:      	je	0x1d64 <perf_unwind_python+0x1d64>
    38b5:      	movq	(%rsp), %rax
    38b9:      	cmpb	$0x0, 0x22(%rax)
    38bd:      	movzbl	0x1a(%rax), %eax
    38c1:      	je	0x390a <perf_unwind_python+0x390a>
    38c3:      	movq	0x70(%rsp), %rsi
    38c8:      	movq	(%rsi,%rax), %rax
    38cc:      	movq	(%rsp), %rcx
    38d0:      	movzbl	0x21(%rcx), %edx
    38d4:      	addq	0x28(%rsp), %rdx
    38d9:      	subq	%rdx, %rax
    38dc:      	leaq	-0x10000001(%rax), %rdx
    38e3:      	sarl	%eax
    38e5:      	cmpq	$-0x10000003, %rdx      # imm = 0xEFFFFFFD
    38ec:      	movl	$0xffffffff, %r12d      # imm = 0xFFFFFFFF
    38f2:      	cmovael	%eax, %r12d
    38f6:      	movzbl	0x1b(%rcx), %eax
    38fa:      	movzbl	(%rsi,%rax), %eax
    38fe:      	cmpb	0x1c(%rcx), %al
    3901:      	sete	%al
    3904:      	movl	%eax, 0x78(%rsp)
    3908:      	jmp	0x391b <perf_unwind_python+0x391b>
    390a:      	movq	0x70(%rsp), %rcx
    390f:      	movl	(%rcx,%rax), %r12d
    3913:      	movl	$0x0, 0x78(%rsp)
    391b:      	cmpq	$0x0, 0x28(%rsp)
    3921:      	je	0x39be <perf_unwind_python+0x39be>
    3927:      	movq	(%rsp), %rax
    392b:      	cmpb	$-0x44, 0x1d(%rax)
    392f:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    3935:      	movq	(%rsp), %rax
    3939:      	cmpb	$-0x44, 0x1e(%rax)
    393d:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    3943:      	movq	(%rsp), %rax
    3947:      	cmpb	$-0x44, 0x1f(%rax)
    394b:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    3951:      	movq	(%rsp), %rax
    3955:      	cmpb	$-0x44, 0x20(%rax)
    3959:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    395f:      	movl	$0xc0, %eax
    3964:      	movl	$0x70, %ecx
    3969:      	movq	0x28(%rsp), %rdx
    396e:      	movq	%r15, %rdi
    3971:      	movl	$0xc0, %esi
    3976:      	callq	*%rcx
    3978:      	testq	%rax, %rax
    397b:      	jne	0x1e36 <perf_unwind_python+0x1e36>
    3981:      	movq	(%rsp), %rax
    3985:      	movzbl	0x1d(%rax), %ecx
    3989:      	movl	(%r15,%rcx), %ecx
    398d:      	movzbl	0x1e(%rax), %edx
    3991:      	movl	(%r15,%rdx), %edx
    3995:      	movzbl	0x1f(%rax), %esi
    3999:      	movl	(%r15,%rsi), %esi
    399d:      	movzbl	0x20(%rax), %eax
    39a1:      	shll	$0x19, %ecx
    39a4:      	shll	$0x12, %edx
    39a7:      	addl	%ecx, %edx
    39a9:      	shll	$0xa, %esi
    39ac:      	addl	%edx, %esi
    39ae:      	addl	(%r15,%rax), %esi
    39b2:      	shlq	$0x20, %r12
    39b6:      	orq	%rsi, %r12
    39b9:      	jmp	0x3af9 <perf_unwind_python+0x3af9>
    39be:      	cmpl	$0x0, (%r14)
    39c2:      	je	0x3a4a <perf_unwind_python+0x3a4a>
    39c8:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    39d2:      	movq	%rax, 0x57(%rsp)
    39d7:      	movabsq	$0x20786c2578302074, %rax # imm = 0x20786C2578302074
    39e1:      	movq	%rax, 0x50(%rsp)
    39e6:      	movabsq	$0x63656a624f656d61, %rax # imm = 0x63656A624F656D61
    39f0:      	movq	%rax, 0x48(%rsp)
    39f5:      	movabsq	$0x7246795020726f66, %rax # imm = 0x7246795020726F66
    39ff:      	movq	%rax, 0x40(%rsp)
    3a04:      	movabsq	$0x207463656a626f65, %rax # imm = 0x207463656A626F65
    3a0e:      	movq	%rax, 0x38(%rsp)
    3a13:      	movabsq	$0x646f63206c6c754e, %rax # imm = 0x646F63206C6C754E
    3a1d:      	movq	%rax, 0x30(%rsp)
    3a22:      	leaq	0x30(%rsp), %rdi
    3a27:      	movl	$0x2f, %eax
    3a2c:      	movl	$0x6, %r8d
    3a32:      	movq	(%rsp), %rax
    3a36:      	movzbl	0x19(%rax), %ecx
    3a3a:      	addq	%r13, %rcx
    3a3d:      	movl	$0x2f, %esi
    3a42:      	movq	%r13, %rdx
    3a45:      	xorl	%eax, %eax
    3a47:      	callq	*%r8
    3a4a:      	movl	$0x1c, 0x18(%rsp)
    3a52:      	movq	(%rip), %rdi            # 0x3a59 <perf_unwind_python+0x3a59>
    3a59:      	leaq	0x18(%rsp), %rsi
    3a5e:      	movl	$0x1, %eax
    3a63:      	callq	*%rax
    3a65:      	testq	%rax, %rax
    3a68:      	je	0x3a6f <perf_unwind_python+0x3a6f>
    3a6a:      	incq	(%rax)
    3a6d:      	jmp	0x3aeb <perf_unwind_python+0x3aeb>
    3a6f:      	cmpl	$0x0, (%r14)
    3a73:      	je	0x3aeb <perf_unwind_python+0x3aeb>
    3a75:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3a7f:      	movq	%rax, 0x56(%rsp)
    3a84:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3a8e:      	movq	%rax, 0x50(%rsp)
    3a93:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3a9d:      	movq	%rax, 0x48(%rsp)
    3aa2:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3aac:      	movq	%rax, 0x40(%rsp)
    3ab1:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3abb:      	movq	%rax, 0x38(%rsp)
    3ac0:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3aca:      	movq	%rax, 0x30(%rsp)
    3acf:      	leaq	0x30(%rsp), %rdi
    3ad4:      	movl	$0x2e, %eax
    3ad9:      	movl	$0x6, %ecx
    3ade:      	movl	0x18(%rsp), %edx
    3ae2:      	movl	$0x2e, %esi
    3ae7:      	xorl	%eax, %eax
    3ae9:      	callq	*%rcx
    3aeb:      	movq	$-0x2, %r12
    3af2:      	xorl	%eax, %eax
    3af4:      	movq	%rax, 0x28(%rsp)
    3af9:      	cmpl	$0x0, (%r14)
    3afd:      	je	0x3b4e <perf_unwind_python+0x3b4e>
    3aff:      	movabsq	$0xa756c2520786c, %rax  # imm = 0xA756C2520786C
    3b09:      	movq	%rax, 0x40(%rsp)
    3b0e:      	movabsq	$0x25206e6f68747950, %rax # imm = 0x25206E6F68747950
    3b18:      	movq	%rax, 0x38(%rsp)
    3b1d:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    3b27:      	movq	%rax, 0x30(%rsp)
    3b2c:      	leaq	0x30(%rsp), %rdi
    3b31:      	movl	$0x18, %eax
    3b36:      	movl	$0x6, %r8d
    3b3c:      	movl	$0x18, %esi
    3b41:      	movq	0x28(%rsp), %rdx
    3b46:      	movq	%r12, %rcx
    3b49:      	xorl	%eax, %eax
    3b4b:      	callq	*%r8
    3b4e:      	movl	0x2c0(%rbp), %eax
    3b54:      	cmpq	$0x7e, %rax
    3b58:      	ja	0x1f31 <perf_unwind_python+0x1f31>
    3b5e:      	leal	0x1(%rax), %ecx
    3b61:      	movl	%ecx, 0x2c0(%rbp)
    3b67:      	leaq	(%rax,%rax,2), %rax
    3b6b:      	movq	0x28(%rsp), %rcx
    3b70:      	movq	%rcx, 0x2d0(%rbp,%rax,8)
    3b78:      	movq	%r12, 0x2d8(%rbp,%rax,8)
    3b80:      	movb	$0x1, 0x2e0(%rbp,%rax,8)
    3b88:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    3b93:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    3b9e:      	movl	$0x16, 0x18(%rsp)
    3ba6:      	movq	(%rip), %rdi            # 0x3bad <perf_unwind_python+0x3bad>
    3bad:      	leaq	0x18(%rsp), %rsi
    3bb2:      	movl	$0x1, %eax
    3bb7:      	callq	*%rax
    3bb9:      	testq	%rax, %rax
    3bbc:      	je	0x3bc3 <perf_unwind_python+0x3bc3>
    3bbe:      	incq	(%rax)
    3bc1:      	jmp	0x3c3f <perf_unwind_python+0x3c3f>
    3bc3:      	cmpl	$0x0, (%r14)
    3bc7:      	je	0x3c3f <perf_unwind_python+0x3c3f>
    3bc9:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3bd3:      	movq	%rax, 0x56(%rsp)
    3bd8:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3be2:      	movq	%rax, 0x50(%rsp)
    3be7:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3bf1:      	movq	%rax, 0x48(%rsp)
    3bf6:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3c00:      	movq	%rax, 0x40(%rsp)
    3c05:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3c0f:      	movq	%rax, 0x38(%rsp)
    3c14:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3c1e:      	movq	%rax, 0x30(%rsp)
    3c23:      	leaq	0x30(%rsp), %rdi
    3c28:      	movl	$0x2e, %eax
    3c2d:      	movl	$0x6, %ecx
    3c32:      	movl	0x18(%rsp), %edx
    3c36:      	movl	$0x2e, %esi
    3c3b:      	xorl	%eax, %eax
    3c3d:      	callq	*%rcx
    3c3f:      	cmpb	$0x0, 0x78(%rsp)
    3c44:      	jne	0x1d64 <perf_unwind_python+0x1d64>
    3c4a:      	xorl	%r12d, %r12d
    3c4d:      	cmpq	$0x0, 0x20(%rsp)
    3c53:      	je	0x45be <perf_unwind_python+0x45be>
    3c59:      	movq	(%rsp), %rax
    3c5d:      	cmpb	$0x78, 0x19(%rax)
    3c61:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    3c67:      	movq	(%rsp), %rax
    3c6b:      	cmpb	$0x78, 0x18(%rax)
    3c6f:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    3c75:      	movq	(%rsp), %rax
    3c79:      	cmpb	$0x78, 0x1a(%rax)
    3c7d:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    3c83:      	movq	(%rsp), %rax
    3c87:      	cmpb	$0x0, 0x1b(%rax)
    3c8b:      	js	0x45a2 <perf_unwind_python+0x45a2>
    3c91:      	movl	$0x80, %eax
    3c96:      	movl	$0x70, %ecx
    3c9b:      	movq	0x70(%rsp), %rdi
    3ca0:      	movq	0x20(%rsp), %rdx
    3ca5:      	movl	$0x80, %esi
    3caa:      	callq	*%rcx
    3cac:      	testq	%rax, %rax
    3caf:      	jne	0xd60 <perf_unwind_python+0xd60>
    3cb5:      	movq	(%rsp), %rax
    3cb9:      	movzbl	0x19(%rax), %ecx
    3cbd:      	movq	0x70(%rsp), %rdx
    3cc2:      	movq	(%rdx,%rcx), %rcx
    3cc6:      	movq	%rcx, 0x28(%rsp)
    3ccb:      	movzbl	0x18(%rax), %ecx
    3ccf:      	movq	(%rdx,%rcx), %r13
    3cd3:      	movq	0x8(%rax), %rax
    3cd7:      	testq	%rax, %rax
    3cda:      	je	0x3ce7 <perf_unwind_python+0x3ce7>
    3cdc:      	cmpq	%rax, 0x28(%rsp)
    3ce1:      	je	0x124c <perf_unwind_python+0x124c>
    3ce7:      	movq	(%rsp), %rax
    3ceb:      	cmpb	$0x0, 0x22(%rax)
    3cef:      	movzbl	0x1a(%rax), %eax
    3cf3:      	je	0x3d3c <perf_unwind_python+0x3d3c>
    3cf5:      	movq	0x70(%rsp), %rsi
    3cfa:      	movq	(%rsi,%rax), %rax
    3cfe:      	movq	(%rsp), %rcx
    3d02:      	movzbl	0x21(%rcx), %edx
    3d06:      	addq	0x28(%rsp), %rdx
    3d0b:      	subq	%rdx, %rax
    3d0e:      	leaq	-0x10000001(%rax), %rdx
    3d15:      	sarl	%eax
    3d17:      	cmpq	$-0x10000003, %rdx      # imm = 0xEFFFFFFD
    3d1e:      	movl	$0xffffffff, %r12d      # imm = 0xFFFFFFFF
    3d24:      	cmovael	%eax, %r12d
    3d28:      	movzbl	0x1b(%rcx), %eax
    3d2c:      	movzbl	(%rsi,%rax), %eax
    3d30:      	cmpb	0x1c(%rcx), %al
    3d33:      	sete	%al
    3d36:      	movl	%eax, 0x78(%rsp)
    3d3a:      	jmp	0x3d4d <perf_unwind_python+0x3d4d>
    3d3c:      	movq	0x70(%rsp), %rcx
    3d41:      	movl	(%rcx,%rax), %r12d
    3d45:      	movl	$0x0, 0x78(%rsp)
    3d4d:      	cmpq	$0x0, 0x28(%rsp)
    3d53:      	je	0x3df0 <perf_unwind_python+0x3df0>
    3d59:      	movq	(%rsp), %rax
    3d5d:      	cmpb	$-0x44, 0x1d(%rax)
    3d61:      	ja	0x460a <perf_unwind_python+0x460a>
    3d67:      	movq	(%rsp), %rax
    3d6b:      	cmpb	$-0x44, 0x1e(%rax)
    3d6f:      	ja	0x460a <perf_unwind_python+0x460a>
    3d75:      	movq	(%rsp), %rax
    3d79:      	cmpb	$-0x44, 0x1f(%rax)
    3d7d:      	ja	0x460a <perf_unwind_python+0x460a>
    3d83:      	movq	(%rsp), %rax
    3d87:      	cmpb	$-0x44, 0x20(%rax)
    3d8b:      	ja	0x460a <perf_unwind_python+0x460a>
    3d91:      	movl	$0xc0, %eax
    3d96:      	movl	$0x70, %ecx
    3d9b:      	movq	0x28(%rsp), %rdx
    3da0:      	movq	%r15, %rdi
    3da3:      	movl	$0xc0, %esi
    3da8:      	callq	*%rcx
    3daa:      	testq	%rax, %rax
    3dad:      	jne	0x2bc <perf_unwind_python+0x2bc>
    3db3:      	movq	(%rsp), %rax
    3db7:      	movzbl	0x1d(%rax), %ecx
    3dbb:      	movl	(%r15,%rcx), %ecx
    3dbf:      	movzbl	0x1e(%rax), %edx
    3dc3:      	movl	(%r15,%rdx), %edx
    3dc7:      	movzbl	0x1f(%rax), %esi
    3dcb:      	movl	(%r15,%rsi), %esi
    3dcf:      	movzbl	0x20(%rax), %eax
    3dd3:      	shll	$0x19, %ecx
    3dd6:      	shll	$0x12, %edx
    3dd9:      	addl	%ecx, %edx
    3ddb:      	shll	$0xa, %esi
    3dde:      	addl	%edx, %esi
    3de0:      	addl	(%r15,%rax), %esi
    3de4:      	shlq	$0x20, %r12
    3de8:      	orq	%rsi, %r12
    3deb:      	jmp	0x3f2d <perf_unwind_python+0x3f2d>
    3df0:      	cmpl	$0x0, (%r14)
    3df4:      	je	0x3e7e <perf_unwind_python+0x3e7e>
    3dfa:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    3e04:      	movq	%rax, 0x57(%rsp)
    3e09:      	movabsq	$0x20786c2578302074, %rax # imm = 0x20786C2578302074
    3e13:      	movq	%rax, 0x50(%rsp)
    3e18:      	movabsq	$0x63656a624f656d61, %rax # imm = 0x63656A624F656D61
    3e22:      	movq	%rax, 0x48(%rsp)
    3e27:      	movabsq	$0x7246795020726f66, %rax # imm = 0x7246795020726F66
    3e31:      	movq	%rax, 0x40(%rsp)
    3e36:      	movabsq	$0x207463656a626f65, %rax # imm = 0x207463656A626F65
    3e40:      	movq	%rax, 0x38(%rsp)
    3e45:      	movabsq	$0x646f63206c6c754e, %rax # imm = 0x646F63206C6C754E
    3e4f:      	movq	%rax, 0x30(%rsp)
    3e54:      	leaq	0x30(%rsp), %rdi
    3e59:      	movl	$0x2f, %eax
    3e5e:      	movl	$0x6, %r8d
    3e64:      	movq	(%rsp), %rax
    3e68:      	movzbl	0x19(%rax), %ecx
    3e6c:      	movq	0x20(%rsp), %rdx
    3e71:      	addq	%rdx, %rcx
    3e74:      	movl	$0x2f, %esi
    3e79:      	xorl	%eax, %eax
    3e7b:      	callq	*%r8
    3e7e:      	movl	$0x1c, 0x18(%rsp)
    3e86:      	movq	(%rip), %rdi            # 0x3e8d <perf_unwind_python+0x3e8d>
    3e8d:      	leaq	0x18(%rsp), %rsi
    3e92:      	movl	$0x1, %eax
    3e97:      	callq	*%rax
    3e99:      	testq	%rax, %rax
    3e9c:      	je	0x3ea3 <perf_unwind_python+0x3ea3>
    3e9e:      	incq	(%rax)
    3ea1:      	jmp	0x3f1f <perf_unwind_python+0x3f1f>
    3ea3:      	cmpl	$0x0, (%r14)
    3ea7:      	je	0x3f1f <perf_unwind_python+0x3f1f>
    3ea9:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3eb3:      	movq	%rax, 0x56(%rsp)
    3eb8:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3ec2:      	movq	%rax, 0x50(%rsp)
    3ec7:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3ed1:      	movq	%rax, 0x48(%rsp)
    3ed6:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3ee0:      	movq	%rax, 0x40(%rsp)
    3ee5:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3eef:      	movq	%rax, 0x38(%rsp)
    3ef4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3efe:      	movq	%rax, 0x30(%rsp)
    3f03:      	leaq	0x30(%rsp), %rdi
    3f08:      	movl	$0x2e, %eax
    3f0d:      	movl	$0x6, %ecx
    3f12:      	movl	0x18(%rsp), %edx
    3f16:      	movl	$0x2e, %esi
    3f1b:      	xorl	%eax, %eax
    3f1d:      	callq	*%rcx
    3f1f:      	movq	$-0x2, %r12
    3f26:      	xorl	%eax, %eax
    3f28:      	movq	%rax, 0x28(%rsp)
    3f2d:      	cmpl	$0x0, (%r14)
    3f31:      	je	0x3f82 <perf_unwind_python+0x3f82>
    3f33:      	movabsq	$0xa756c2520786c, %rax  # imm = 0xA756C2520786C
    3f3d:      	movq	%rax, 0x40(%rsp)
    3f42:      	movabsq	$0x25206e6f68747950, %rax # imm = 0x25206E6F68747950
    3f4c:      	movq	%rax, 0x38(%rsp)
    3f51:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    3f5b:      	movq	%rax, 0x30(%rsp)
    3f60:      	leaq	0x30(%rsp), %rdi
    3f65:      	movl	$0x18, %eax
    3f6a:      	movl	$0x6, %r8d
    3f70:      	movl	$0x18, %esi
    3f75:      	movq	0x28(%rsp), %rdx
    3f7a:      	movq	%r12, %rcx
    3f7d:      	xorl	%eax, %eax
    3f7f:      	callq	*%r8
    3f82:      	movl	0x2c0(%rbp), %eax
    3f88:      	cmpq	$0x7e, %rax
    3f8c:      	ja	0x1777 <perf_unwind_python+0x1777>
    3f92:      	leal	0x1(%rax), %ecx
    3f95:      	movl	%ecx, 0x2c0(%rbp)
    3f9b:      	leaq	(%rax,%rax,2), %rax
    3f9f:      	movq	0x28(%rsp), %rcx
    3fa4:      	movq	%rcx, 0x2d0(%rbp,%rax,8)
    3fac:      	movq	%r12, 0x2d8(%rbp,%rax,8)
    3fb4:      	movb	$0x1, 0x2e0(%rbp,%rax,8)
    3fbc:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    3fc7:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    3fd2:      	movl	$0x16, 0x18(%rsp)
    3fda:      	movq	(%rip), %rdi            # 0x3fe1 <perf_unwind_python+0x3fe1>
    3fe1:      	leaq	0x18(%rsp), %rsi
    3fe6:      	movl	$0x1, %eax
    3feb:      	callq	*%rax
    3fed:      	testq	%rax, %rax
    3ff0:      	je	0x3ff7 <perf_unwind_python+0x3ff7>
    3ff2:      	incq	(%rax)
    3ff5:      	jmp	0x4073 <perf_unwind_python+0x4073>
    3ff7:      	cmpl	$0x0, (%r14)
    3ffb:      	je	0x4073 <perf_unwind_python+0x4073>
    3ffd:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4007:      	movq	%rax, 0x56(%rsp)
    400c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4016:      	movq	%rax, 0x50(%rsp)
    401b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4025:      	movq	%rax, 0x48(%rsp)
    402a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4034:      	movq	%rax, 0x40(%rsp)
    4039:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4043:      	movq	%rax, 0x38(%rsp)
    4048:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4052:      	movq	%rax, 0x30(%rsp)
    4057:      	leaq	0x30(%rsp), %rdi
    405c:      	movl	$0x2e, %eax
    4061:      	movl	$0x6, %ecx
    4066:      	movl	0x18(%rsp), %edx
    406a:      	movl	$0x2e, %esi
    406f:      	xorl	%eax, %eax
    4071:      	callq	*%rcx
    4073:      	cmpb	$0x0, 0x78(%rsp)
    4078:      	jne	0x124c <perf_unwind_python+0x124c>
    407e:      	xorl	%r12d, %r12d
    4081:      	testq	%r13, %r13
    4084:      	je	0x45be <perf_unwind_python+0x45be>
    408a:      	movq	(%rsp), %rax
    408e:      	cmpb	$0x78, 0x19(%rax)
    4092:      	ja	0x460a <perf_unwind_python+0x460a>
    4098:      	movq	(%rsp), %rax
    409c:      	cmpb	$0x78, 0x18(%rax)
    40a0:      	ja	0x460a <perf_unwind_python+0x460a>
    40a6:      	movq	(%rsp), %rax
    40aa:      	cmpb	$0x78, 0x1a(%rax)
    40ae:      	ja	0x460a <perf_unwind_python+0x460a>
    40b4:      	movq	(%rsp), %rax
    40b8:      	cmpb	$0x0, 0x1b(%rax)
    40bc:      	js	0x460a <perf_unwind_python+0x460a>
    40c2:      	movl	$0x80, %eax
    40c7:      	movl	$0x70, %ecx
    40cc:      	movq	0x70(%rsp), %rdi
    40d1:      	movl	$0x80, %esi
    40d6:      	movq	%r13, %rdx
    40d9:      	callq	*%rcx
    40db:      	testq	%rax, %rax
    40de:      	jne	0x1d27 <perf_unwind_python+0x1d27>
    40e4:      	movq	(%rsp), %rax
    40e8:      	movzbl	0x19(%rax), %ecx
    40ec:      	movq	0x70(%rsp), %rdx
    40f1:      	movq	(%rdx,%rcx), %rcx
    40f5:      	movq	%rcx, 0x28(%rsp)
    40fa:      	movzbl	0x18(%rax), %ecx
    40fe:      	movq	(%rdx,%rcx), %rcx
    4102:      	movq	%rcx, 0x20(%rsp)
    4107:      	movq	0x8(%rax), %rax
    410b:      	testq	%rax, %rax
    410e:      	je	0x411b <perf_unwind_python+0x411b>
    4110:      	cmpq	%rax, 0x28(%rsp)
    4115:      	je	0x1d64 <perf_unwind_python+0x1d64>
    411b:      	movq	(%rsp), %rax
    411f:      	cmpb	$0x0, 0x22(%rax)
    4123:      	movzbl	0x1a(%rax), %eax
    4127:      	je	0x4170 <perf_unwind_python+0x4170>
    4129:      	movq	0x70(%rsp), %rsi
    412e:      	movq	(%rsi,%rax), %rax
    4132:      	movq	(%rsp), %rcx
    4136:      	movzbl	0x21(%rcx), %edx
    413a:      	addq	0x28(%rsp), %rdx
    413f:      	subq	%rdx, %rax
    4142:      	leaq	-0x10000001(%rax), %rdx
    4149:      	sarl	%eax
    414b:      	cmpq	$-0x10000003, %rdx      # imm = 0xEFFFFFFD
    4152:      	movl	$0xffffffff, %r12d      # imm = 0xFFFFFFFF
    4158:      	cmovael	%eax, %r12d
    415c:      	movzbl	0x1b(%rcx), %eax
    4160:      	movzbl	(%rsi,%rax), %eax
    4164:      	cmpb	0x1c(%rcx), %al
    4167:      	sete	%al
    416a:      	movl	%eax, 0x78(%rsp)
    416e:      	jmp	0x4181 <perf_unwind_python+0x4181>
    4170:      	movq	0x70(%rsp), %rcx
    4175:      	movl	(%rcx,%rax), %r12d
    4179:      	movl	$0x0, 0x78(%rsp)
    4181:      	cmpq	$0x0, 0x28(%rsp)
    4187:      	je	0x4224 <perf_unwind_python+0x4224>
    418d:      	movq	(%rsp), %rax
    4191:      	cmpb	$-0x44, 0x1d(%rax)
    4195:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    419b:      	movq	(%rsp), %rax
    419f:      	cmpb	$-0x44, 0x1e(%rax)
    41a3:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    41a9:      	movq	(%rsp), %rax
    41ad:      	cmpb	$-0x44, 0x1f(%rax)
    41b1:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    41b7:      	movq	(%rsp), %rax
    41bb:      	cmpb	$-0x44, 0x20(%rax)
    41bf:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    41c5:      	movl	$0xc0, %eax
    41ca:      	movl	$0x70, %ecx
    41cf:      	movq	0x28(%rsp), %rdx
    41d4:      	movq	%r15, %rdi
    41d7:      	movl	$0xc0, %esi
    41dc:      	callq	*%rcx
    41de:      	testq	%rax, %rax
    41e1:      	jne	0x1e36 <perf_unwind_python+0x1e36>
    41e7:      	movq	(%rsp), %rax
    41eb:      	movzbl	0x1d(%rax), %ecx
    41ef:      	movl	(%r15,%rcx), %ecx
    41f3:      	movzbl	0x1e(%rax), %edx
    41f7:      	movl	(%r15,%rdx), %edx
    41fb:      	movzbl	0x1f(%rax), %esi
    41ff:      	movl	(%r15,%rsi), %esi
    4203:      	movzbl	0x20(%rax), %eax
    4207:      	shll	$0x19, %ecx
    420a:      	shll	$0x12, %edx
    420d:      	addl	%ecx, %edx
    420f:      	shll	$0xa, %esi
    4212:      	addl	%edx, %esi
    4214:      	addl	(%r15,%rax), %esi
    4218:      	shlq	$0x20, %r12
    421c:      	orq	%rsi, %r12
    421f:      	jmp	0x435f <perf_unwind_python+0x435f>
    4224:      	cmpl	$0x0, (%r14)
    4228:      	je	0x42b0 <perf_unwind_python+0x42b0>
    422e:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    4238:      	movq	%rax, 0x57(%rsp)
    423d:      	movabsq	$0x20786c2578302074, %rax # imm = 0x20786C2578302074
    4247:      	movq	%rax, 0x50(%rsp)
    424c:      	movabsq	$0x63656a624f656d61, %rax # imm = 0x63656A624F656D61
    4256:      	movq	%rax, 0x48(%rsp)
    425b:      	movabsq	$0x7246795020726f66, %rax # imm = 0x7246795020726F66
    4265:      	movq	%rax, 0x40(%rsp)
    426a:      	movabsq	$0x207463656a626f65, %rax # imm = 0x207463656A626F65
    4274:      	movq	%rax, 0x38(%rsp)
    4279:      	movabsq	$0x646f63206c6c754e, %rax # imm = 0x646F63206C6C754E
    4283:      	movq	%rax, 0x30(%rsp)
    4288:      	leaq	0x30(%rsp), %rdi
    428d:      	movl	$0x2f, %eax
    4292:      	movl	$0x6, %r8d
    4298:      	movq	(%rsp), %rax
    429c:      	movzbl	0x19(%rax), %ecx
    42a0:      	addq	%r13, %rcx
    42a3:      	movl	$0x2f, %esi
    42a8:      	movq	%r13, %rdx
    42ab:      	xorl	%eax, %eax
    42ad:      	callq	*%r8
    42b0:      	movl	$0x1c, 0x18(%rsp)
    42b8:      	movq	(%rip), %rdi            # 0x42bf <perf_unwind_python+0x42bf>
    42bf:      	leaq	0x18(%rsp), %rsi
    42c4:      	movl	$0x1, %eax
    42c9:      	callq	*%rax
    42cb:      	testq	%rax, %rax
    42ce:      	je	0x42d5 <perf_unwind_python+0x42d5>
    42d0:      	incq	(%rax)
    42d3:      	jmp	0x4351 <perf_unwind_python+0x4351>
    42d5:      	cmpl	$0x0, (%r14)
    42d9:      	je	0x4351 <perf_unwind_python+0x4351>
    42db:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    42e5:      	movq	%rax, 0x56(%rsp)
    42ea:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    42f4:      	movq	%rax, 0x50(%rsp)
    42f9:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4303:      	movq	%rax, 0x48(%rsp)
    4308:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4312:      	movq	%rax, 0x40(%rsp)
    4317:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4321:      	movq	%rax, 0x38(%rsp)
    4326:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4330:      	movq	%rax, 0x30(%rsp)
    4335:      	leaq	0x30(%rsp), %rdi
    433a:      	movl	$0x2e, %eax
    433f:      	movl	$0x6, %ecx
    4344:      	movl	0x18(%rsp), %edx
    4348:      	movl	$0x2e, %esi
    434d:      	xorl	%eax, %eax
    434f:      	callq	*%rcx
    4351:      	movq	$-0x2, %r12
    4358:      	xorl	%eax, %eax
    435a:      	movq	%rax, 0x28(%rsp)
    435f:      	cmpl	$0x0, (%r14)
    4363:      	je	0x43b4 <perf_unwind_python+0x43b4>
    4365:      	movabsq	$0xa756c2520786c, %rax  # imm = 0xA756C2520786C
    436f:      	movq	%rax, 0x40(%rsp)
    4374:      	movabsq	$0x25206e6f68747950, %rax # imm = 0x25206E6F68747950
    437e:      	movq	%rax, 0x38(%rsp)
    4383:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    438d:      	movq	%rax, 0x30(%rsp)
    4392:      	leaq	0x30(%rsp), %rdi
    4397:      	movl	$0x18, %eax
    439c:      	movl	$0x6, %r8d
    43a2:      	movl	$0x18, %esi
    43a7:      	movq	0x28(%rsp), %rdx
    43ac:      	movq	%r12, %rcx
    43af:      	xorl	%eax, %eax
    43b1:      	callq	*%r8
    43b4:      	movl	0x2c0(%rbp), %eax
    43ba:      	cmpq	$0x7e, %rax
    43be:      	ja	0x1f31 <perf_unwind_python+0x1f31>
    43c4:      	leal	0x1(%rax), %ecx
    43c7:      	movl	%ecx, 0x2c0(%rbp)
    43cd:      	leaq	(%rax,%rax,2), %rax
    43d1:      	movq	0x28(%rsp), %rcx
    43d6:      	movq	%rcx, 0x2d0(%rbp,%rax,8)
    43de:      	movq	%r12, 0x2d8(%rbp,%rax,8)
    43e6:      	movb	$0x1, 0x2e0(%rbp,%rax,8)
    43ee:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    43f9:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    4404:      	movl	$0x16, 0x18(%rsp)
    440c:      	movq	(%rip), %rdi            # 0x4413 <perf_unwind_python+0x4413>
    4413:      	leaq	0x18(%rsp), %rsi
    4418:      	movl	$0x1, %eax
    441d:      	callq	*%rax
    441f:      	testq	%rax, %rax
    4422:      	je	0x4429 <perf_unwind_python+0x4429>
    4424:      	incq	(%rax)
    4427:      	jmp	0x44a5 <perf_unwind_python+0x44a5>
    4429:      	cmpl	$0x0, (%r14)
    442d:      	je	0x44a5 <perf_unwind_python+0x44a5>
    442f:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4439:      	movq	%rax, 0x56(%rsp)
    443e:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4448:      	movq	%rax, 0x50(%rsp)
    444d:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4457:      	movq	%rax, 0x48(%rsp)
    445c:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4466:      	movq	%rax, 0x40(%rsp)
    446b:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4475:      	movq	%rax, 0x38(%rsp)
    447a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4484:      	movq	%rax, 0x30(%rsp)
    4489:      	leaq	0x30(%rsp), %rdi
    448e:      	movl	$0x2e, %eax
    4493:      	movl	$0x6, %ecx
    4498:      	movl	0x18(%rsp), %edx
    449c:      	movl	$0x2e, %esi
    44a1:      	xorl	%eax, %eax
    44a3:      	callq	*%rcx
    44a5:      	cmpb	$0x0, 0x78(%rsp)
    44aa:      	jne	0x1d64 <perf_unwind_python+0x1d64>
    44b0:      	xorl	%r12d, %r12d
    44b3:      	cmpq	$0x0, 0x20(%rsp)
    44b9:      	je	0x45be <perf_unwind_python+0x45be>
    44bf:      	movq	(%rsp), %rax
    44c3:      	cmpb	$0x78, 0x19(%rax)
    44c7:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    44cd:      	movq	(%rsp), %rax
    44d1:      	cmpb	$0x78, 0x18(%rax)
    44d5:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    44db:      	movq	(%rsp), %rax
    44df:      	cmpb	$0x78, 0x1a(%rax)
    44e3:      	ja	0x45a2 <perf_unwind_python+0x45a2>
    44e9:      	movq	(%rsp), %rax
    44ed:      	cmpb	$0x0, 0x1b(%rax)
    44f1:      	js	0x45a2 <perf_unwind_python+0x45a2>
    44f7:      	movl	$0x80, %eax
    44fc:      	movl	$0x70, %ecx
    4501:      	movq	0x70(%rsp), %rdi
    4506:      	movq	0x20(%rsp), %rdx
    450b:      	movl	$0x80, %esi
    4510:      	callq	*%rcx
    4512:      	testq	%rax, %rax
    4515:      	jne	0xd60 <perf_unwind_python+0xd60>
    451b:      	movq	(%rsp), %rax
    451f:      	movzbl	0x19(%rax), %ecx
    4523:      	movq	0x70(%rsp), %rdx
    4528:      	movq	(%rdx,%rcx), %rcx
    452c:      	movq	%rcx, 0x28(%rsp)
    4531:      	movzbl	0x18(%rax), %ecx
    4535:      	movq	(%rdx,%rcx), %r13
    4539:      	movq	0x8(%rax), %rax
    453d:      	testq	%rax, %rax
    4540:      	je	0x454d <perf_unwind_python+0x454d>
    4542:      	cmpq	%rax, 0x28(%rsp)
    4547:      	je	0x124c <perf_unwind_python+0x124c>
    454d:      	movq	(%rsp), %rax
    4551:      	cmpb	$0x0, 0x22(%rax)
    4555:      	movzbl	0x1a(%rax), %eax
    4559:      	je	0x45c5 <perf_unwind_python+0x45c5>
    455b:      	movq	0x70(%rsp), %rsi
    4560:      	movq	(%rsi,%rax), %rax
    4564:      	movq	(%rsp), %rcx
    4568:      	movzbl	0x21(%rcx), %edx
    456c:      	addq	0x28(%rsp), %rdx
    4571:      	subq	%rdx, %rax
    4574:      	leaq	-0x10000001(%rax), %rdx
    457b:      	sarl	%eax
    457d:      	cmpq	$-0x10000003, %rdx      # imm = 0xEFFFFFFD
    4584:      	movl	$0xffffffff, %r12d      # imm = 0xFFFFFFFF
    458a:      	cmovael	%eax, %r12d
    458e:      	movzbl	0x1b(%rcx), %eax
    4592:      	movzbl	(%rsi,%rax), %eax
    4596:      	cmpb	0x1c(%rcx), %al
    4599:      	sete	%al
    459c:      	movl	%eax, 0x70(%rsp)
    45a0:      	jmp	0x45d6 <perf_unwind_python+0x45d6>
    45a2:      	xorl	%ecx, %ecx
    45a4:      	movq	0x20(%rsp), %r13
    45a9:      	movl	$0x1, %r12d
    45af:      	movq	0x8(%rsp), %rbx
    45b4:      	movq	0x10(%rsp), %rsi
    45b9:      	jmp	0x16f <perf_unwind_python+0x16f>
    45be:      	xorl	%ecx, %ecx
    45c0:      	xorl	%r13d, %r13d
    45c3:      	jmp	0x45af <perf_unwind_python+0x45af>
    45c5:      	movq	0x70(%rsp), %rcx
    45ca:      	movl	(%rcx,%rax), %r12d
    45ce:      	movl	$0x0, 0x70(%rsp)
    45d6:      	cmpq	$0x0, 0x28(%rsp)
    45dc:      	je	0x460e <perf_unwind_python+0x460e>
    45de:      	movq	(%rsp), %rax
    45e2:      	cmpb	$-0x44, 0x1d(%rax)
    45e6:      	ja	0x460a <perf_unwind_python+0x460a>
    45e8:      	movq	(%rsp), %rax
    45ec:      	cmpb	$-0x44, 0x1e(%rax)
    45f0:      	ja	0x460a <perf_unwind_python+0x460a>
    45f2:      	movq	(%rsp), %rax
    45f6:      	cmpb	$-0x44, 0x1f(%rax)
    45fa:      	ja	0x460a <perf_unwind_python+0x460a>
    45fc:      	movq	(%rsp), %rax
    4600:      	cmpb	$-0x44, 0x20(%rax)
    4604:      	jbe	0x46c4 <perf_unwind_python+0x46c4>
    460a:      	xorl	%ecx, %ecx
    460c:      	jmp	0x45a9 <perf_unwind_python+0x45a9>
    460e:      	cmpl	$0x0, (%r14)
    4612:      	je	0x469c <perf_unwind_python+0x469c>
    4618:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    4622:      	movq	%rax, 0x57(%rsp)
    4627:      	movabsq	$0x20786c2578302074, %rax # imm = 0x20786C2578302074
    4631:      	movq	%rax, 0x50(%rsp)
    4636:      	movabsq	$0x63656a624f656d61, %rax # imm = 0x63656A624F656D61
    4640:      	movq	%rax, 0x48(%rsp)
    4645:      	movabsq	$0x7246795020726f66, %rax # imm = 0x7246795020726F66
    464f:      	movq	%rax, 0x40(%rsp)
    4654:      	movabsq	$0x207463656a626f65, %rax # imm = 0x207463656A626F65
    465e:      	movq	%rax, 0x38(%rsp)
    4663:      	movabsq	$0x646f63206c6c754e, %rax # imm = 0x646F63206C6C754E
    466d:      	movq	%rax, 0x30(%rsp)
    4672:      	leaq	0x30(%rsp), %rdi
    4677:      	movl	$0x2f, %eax
    467c:      	movl	$0x6, %r8d
    4682:      	movq	(%rsp), %rax
    4686:      	movzbl	0x19(%rax), %ecx
    468a:      	movq	0x20(%rsp), %rdx
    468f:      	addq	%rdx, %rcx
    4692:      	movl	$0x2f, %esi
    4697:      	xorl	%eax, %eax
    4699:      	callq	*%r8
    469c:      	movl	$0x1c, 0x18(%rsp)
    46a4:      	movq	(%rip), %rdi            # 0x46ab <perf_unwind_python+0x46ab>
    46ab:      	leaq	0x18(%rsp), %rsi
    46b0:      	movl	$0x1, %eax
    46b5:      	callq	*%rax
    46b7:      	testq	%rax, %rax
    46ba:      	je	0x4723 <perf_unwind_python+0x4723>
    46bc:      	incq	(%rax)
    46bf:      	jmp	0x479f <perf_unwind_python+0x479f>
    46c4:      	movl	$0xc0, %eax
    46c9:      	movl	$0x70, %ecx
    46ce:      	movq	0x28(%rsp), %rdx
    46d3:      	movq	%r15, %rdi
    46d6:      	movl	$0xc0, %esi
    46db:      	callq	*%rcx
    46dd:      	testq	%rax, %rax
    46e0:      	jne	0x2bc <perf_unwind_python+0x2bc>
    46e6:      	movq	(%rsp), %rax
    46ea:      	movzbl	0x1d(%rax), %ecx
    46ee:      	movl	(%r15,%rcx), %ecx
    46f2:      	movzbl	0x1e(%rax), %edx
    46f6:      	movl	(%r15,%rdx), %edx
    46fa:      	movzbl	0x1f(%rax), %esi
    46fe:      	movl	(%r15,%rsi), %esi
    4702:      	movzbl	0x20(%rax), %eax
    4706:      	shll	$0x19, %ecx
    4709:      	shll	$0x12, %edx
    470c:      	addl	%ecx, %edx
    470e:      	shll	$0xa, %esi
    4711:      	addl	%edx, %esi
    4713:      	addl	(%r15,%rax), %esi
    4717:      	shlq	$0x20, %r12
    471b:      	orq	%rsi, %r12
    471e:      	jmp	0x47ad <perf_unwind_python+0x47ad>
    4723:      	cmpl	$0x0, (%r14)
    4727:      	je	0x479f <perf_unwind_python+0x479f>
    4729:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4733:      	movq	%rax, 0x56(%rsp)
    4738:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4742:      	movq	%rax, 0x50(%rsp)
    4747:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4751:      	movq	%rax, 0x48(%rsp)
    4756:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4760:      	movq	%rax, 0x40(%rsp)
    4765:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    476f:      	movq	%rax, 0x38(%rsp)
    4774:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    477e:      	movq	%rax, 0x30(%rsp)
    4783:      	leaq	0x30(%rsp), %rdi
    4788:      	movl	$0x2e, %eax
    478d:      	movl	$0x6, %ecx
    4792:      	movl	0x18(%rsp), %edx
    4796:      	movl	$0x2e, %esi
    479b:      	xorl	%eax, %eax
    479d:      	callq	*%rcx
    479f:      	movq	$-0x2, %r12
    47a6:      	xorl	%eax, %eax
    47a8:      	movq	%rax, 0x28(%rsp)
    47ad:      	cmpl	$0x0, (%r14)
    47b1:      	je	0x4802 <perf_unwind_python+0x4802>
    47b3:      	movabsq	$0xa756c2520786c, %rax  # imm = 0xA756C2520786C
    47bd:      	movq	%rax, 0x40(%rsp)
    47c2:      	movabsq	$0x25206e6f68747950, %rax # imm = 0x25206E6F68747950
    47cc:      	movq	%rax, 0x38(%rsp)
    47d1:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    47db:      	movq	%rax, 0x30(%rsp)
    47e0:      	leaq	0x30(%rsp), %rdi
    47e5:      	movl	$0x18, %eax
    47ea:      	movl	$0x6, %r8d
    47f0:      	movl	$0x18, %esi
    47f5:      	movq	0x28(%rsp), %rdx
    47fa:      	movq	%r12, %rcx
    47fd:      	xorl	%eax, %eax
    47ff:      	callq	*%r8
    4802:      	movl	0x2c0(%rbp), %eax
    4808:      	cmpq	$0x7e, %rax
    480c:      	ja	0x1777 <perf_unwind_python+0x1777>
    4812:      	leal	0x1(%rax), %ecx
    4815:      	movl	%ecx, 0x2c0(%rbp)
    481b:      	leaq	(%rax,%rax,2), %rax
    481f:      	movq	0x28(%rsp), %rcx
    4824:      	movq	%rcx, 0x2d0(%rbp,%rax,8)
    482c:      	movq	%r12, 0x2d8(%rbp,%rax,8)
    4834:      	movb	$0x1, 0x2e0(%rbp,%rax,8)
    483c:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    4847:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    4852:      	movl	$0x16, 0x18(%rsp)
    485a:      	movq	(%rip), %rdi            # 0x4861 <perf_unwind_python+0x4861>
    4861:      	leaq	0x18(%rsp), %rsi
    4866:      	movl	$0x1, %eax
    486b:      	callq	*%rax
    486d:      	testq	%rax, %rax
    4870:      	je	0x4877 <perf_unwind_python+0x4877>
    4872:      	incq	(%rax)
    4875:      	jmp	0x48f3 <perf_unwind_python+0x48f3>
    4877:      	cmpl	$0x0, (%r14)
    487b:      	je	0x48f3 <perf_unwind_python+0x48f3>
    487d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4887:      	movq	%rax, 0x56(%rsp)
    488c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4896:      	movq	%rax, 0x50(%rsp)
    489b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    48a5:      	movq	%rax, 0x48(%rsp)
    48aa:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    48b4:      	movq	%rax, 0x40(%rsp)
    48b9:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    48c3:      	movq	%rax, 0x38(%rsp)
    48c8:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    48d2:      	movq	%rax, 0x30(%rsp)
    48d7:      	leaq	0x30(%rsp), %rdi
    48dc:      	movl	$0x2e, %eax
    48e1:      	movl	$0x6, %ecx
    48e6:      	movl	0x18(%rsp), %edx
    48ea:      	movl	$0x2e, %esi
    48ef:      	xorl	%eax, %eax
    48f1:      	callq	*%rcx
    48f3:      	cmpb	$0x0, 0x70(%rsp)
    48f8:      	jne	0x124c <perf_unwind_python+0x124c>
    48fe:      	movl	$0x4, %r15d
    4904:      	testq	%r13, %r13
    4907:      	je	0x491e <perf_unwind_python+0x491e>
    4909:      	movq	%r13, %rdi
    490c:      	xorl	%r12d, %r12d
    490f:      	movq	0x8(%rsp), %rbx
    4914:      	movq	0x10(%rsp), %rsi
    4919:      	jmp	0x17c <perf_unwind_python+0x17c>
    491e:      	xorl	%r13d, %r13d
    4921:      	xorl	%r12d, %r12d
    4924:      	jmp	0xd81 <perf_unwind_python+0xd81>

Disassembly of section kprobe/unwind_python:

0000000000000000 <kprobe_unwind_python>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x98, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x30(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <kprobe_unwind_python+0x23>
      23:      	leaq	0x30(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x892 <kprobe_unwind_python+0x892>
      38:      	movq	%rax, %r15
      3b:      	movq	%rax, %rbp
      3e:      	movl	(%r15), %eax
      41:      	movl	%eax, 0x88(%rsp)
      48:      	movq	(%rip), %r14            # 0x4f <kprobe_unwind_python+0x4f>
      4f:      	cmpl	$0x0, (%r14)
      53:      	jne	0x407 <kprobe_unwind_python+0x407>
      59:      	movq	(%rip), %rdi            # 0x60 <kprobe_unwind_python+0x60>
      60:      	leaq	0x88(%rsp), %rsi
      68:      	movl	$0x1, %eax
      6d:      	callq	*%rax
      6f:      	movl	(%r14), %ecx
      72:      	testq	%rax, %rax
      75:      	je	0x134 <kprobe_unwind_python+0x134>
      7b:      	testl	%ecx, %ecx
      7d:      	jne	0x466 <kprobe_unwind_python+0x466>
      83:      	leaq	0xf58(%r15), %rsi
      8a:      	movq	0xf58(%rbp), %r13
      91:      	testq	%r13, %r13
      94:      	je	0x4e9 <kprobe_unwind_python+0x4e9>
      9a:      	xorl	%ecx, %ecx
      9c:      	cmpb	$0x78, 0x19(%rax)
      a0:      	ja	0x169 <kprobe_unwind_python+0x169>
      a6:      	cmpb	$0x78, 0x18(%rax)
      aa:      	ja	0x169 <kprobe_unwind_python+0x169>
      b0:      	cmpb	$0x78, 0x1a(%rax)
      b4:      	ja	0x169 <kprobe_unwind_python+0x169>
      ba:      	cmpb	$0x0, 0x1b(%rax)
      be:      	js	0x169 <kprobe_unwind_python+0x169>
      c4:      	movq	%rsi, 0x10(%rsp)
      c9:      	movq	%rax, (%rsp)
      cd:      	leaq	0xf80(%r15), %r12
      d4:      	movl	$0x80, %eax
      d9:      	movl	$0x70, %ecx
      de:      	movq	%r12, %rdi
      e1:      	movl	$0x80, %esi
      e6:      	movq	%r13, %rdx
      e9:      	callq	*%rcx
      eb:      	testq	%rax, %rax
      ee:      	je	0x198 <kprobe_unwind_python+0x198>
      f4:      	cmpl	$0x0, (%r14)
      f8:      	jne	0x11b2 <kprobe_unwind_python+0x11b2>
      fe:      	movl	$0x1b, 0x18(%rsp)
     106:      	movq	(%rip), %rdi            # 0x10d <kprobe_unwind_python+0x10d>
     10d:      	leaq	0x18(%rsp), %rsi
     112:      	movl	$0x1, %eax
     117:      	callq	*%rax
     119:      	testq	%rax, %rax
     11c:      	je	0x1d8 <kprobe_unwind_python+0x1d8>
     122:      	incq	(%rax)
     125:      	movq	0x10(%rsp), %rsi
     12a:      	xorl	%ecx, %ecx
     12c:      	movl	$0x7d2, %r12d           # imm = 0x7D2
     132:      	jmp	0x16f <kprobe_unwind_python+0x16f>
     134:      	testl	%ecx, %ecx
     136:      	jne	0xa51 <kprobe_unwind_python+0xa51>
     13c:      	movl	$0x45, 0x18(%rsp)
     144:      	movq	(%rip), %rdi            # 0x14b <kprobe_unwind_python+0x14b>
     14b:      	leaq	0x18(%rsp), %rsi
     150:      	movl	$0x1, %eax
     155:      	callq	*%rax
     157:      	testq	%rax, %rax
     15a:      	je	0x184 <kprobe_unwind_python+0x184>
     15c:      	incq	(%rax)
     15f:      	movl	$0x7d1, %eax            # imm = 0x7D1
     164:      	jmp	0x897 <kprobe_unwind_python+0x897>
     169:      	movl	$0x1, %r12d
     16f:      	orb	$0x10, 0x1380(%rbp)
     176:      	movl	%ecx, %r15d
     179:      	movq	%r13, %rdi
     17c:      	movq	%rdi, (%rsi)
     17f:      	jmp	0x7e1 <kprobe_unwind_python+0x7e1>
     184:      	cmpl	$0x0, (%r14)
     188:      	jne	0xca4 <kprobe_unwind_python+0xca4>
     18e:      	movl	$0x7d1, %eax            # imm = 0x7D1
     193:      	jmp	0x897 <kprobe_unwind_python+0x897>
     198:      	movq	(%rsp), %rax
     19c:      	movzbl	0x19(%rax), %ecx
     1a0:      	movq	(%r12,%rcx), %rdx
     1a4:      	movzbl	0x18(%rax), %ecx
     1a8:      	movq	(%r12,%rcx), %rdi
     1ac:      	movq	0x8(%rax), %rcx
     1b0:      	testq	%rcx, %rcx
     1b3:      	je	0x1f7 <kprobe_unwind_python+0x1f7>
     1b5:      	cmpq	%rcx, %rdx
     1b8:      	jne	0x1f7 <kprobe_unwind_python+0x1f7>
     1ba:      	movq	0x10(%rsp), %rsi
     1bf:      	xorl	%r12d, %r12d
     1c2:      	movl	$0x1, %ecx
     1c7:      	testq	%rdi, %rdi
     1ca:      	je	0xc43 <kprobe_unwind_python+0xc43>
     1d0:      	movl	$0x1, %r15d
     1d6:      	jmp	0x17c <kprobe_unwind_python+0x17c>
     1d8:      	cmpl	$0x0, (%r14)
     1dc:      	movq	0x10(%rsp), %rsi
     1e1:      	movl	$0x0, %ecx
     1e6:      	jne	0x13a7 <kprobe_unwind_python+0x13a7>
     1ec:      	movl	$0x7d2, %r12d           # imm = 0x7D2
     1f2:      	jmp	0x16f <kprobe_unwind_python+0x16f>
     1f7:      	cmpb	$0x0, 0x22(%rax)
     1fb:      	movzbl	0x1a(%rax), %ecx
     1ff:      	movq	0x10(%rsp), %rsi
     204:      	movq	%r12, 0x70(%rsp)
     209:      	je	0x249 <kprobe_unwind_python+0x249>
     20b:      	movq	(%r12,%rcx), %rcx
     20f:      	movzbl	0x21(%rax), %r8d
     214:      	addq	%rdx, %r8
     217:      	subq	%r8, %rcx
     21a:      	leaq	-0x10000001(%rcx), %r8
     221:      	sarl	%ecx
     223:      	cmpq	$-0x10000003, %r8       # imm = 0xEFFFFFFD
     22a:      	movq	%r12, %r8
     22d:      	movl	$0xffffffff, %r12d      # imm = 0xFFFFFFFF
     233:      	cmovael	%ecx, %r12d
     237:      	movzbl	0x1b(%rax), %ecx
     23b:      	movzbl	(%r8,%rcx), %ecx
     240:      	cmpb	0x1c(%rax), %cl
     243:      	sete	%r8b
     247:      	jmp	0x250 <kprobe_unwind_python+0x250>
     249:      	movl	(%r12,%rcx), %r12d
     24d:      	xorl	%r8d, %r8d
     250:      	addq	$0x1000, %r15           # imm = 0x1000
     257:      	testq	%rdx, %rdx
     25a:      	movl	$0x0, %ecx
     25f:      	je	0x2f5 <kprobe_unwind_python+0x2f5>
     265:      	cmpb	$-0x44, 0x1d(%rax)
     269:      	ja	0xc33 <kprobe_unwind_python+0xc33>
     26f:      	cmpb	$-0x44, 0x1e(%rax)
     273:      	ja	0xc33 <kprobe_unwind_python+0xc33>
     279:      	cmpb	$-0x44, 0x1f(%rax)
     27d:      	ja	0xc33 <kprobe_unwind_python+0xc33>
     283:      	cmpb	$-0x44, 0x20(%rax)
     287:      	ja	0xc33 <kprobe_unwind_python+0xc33>
     28d:      	movl	%r8d, 0x8(%rsp)
     292:      	movq	%rdi, %r13
     295:      	movl	$0xc0, %eax
     29a:      	movl	$0x70, %ecx
     29f:      	movq	%r15, %rdi
     2a2:      	movl	$0xc0, %esi
     2a7:      	movq	%rdx, 0x28(%rsp)
     2ac:      	callq	*%rcx
     2ae:      	testq	%rax, %rax
     2b1:      	je	0xac1 <kprobe_unwind_python+0xac1>
     2b7:      	movq	%rbx, 0x8(%rsp)
     2bc:      	movq	%r14, %rbx
     2bf:      	cmpl	$0x0, (%r14)
     2c3:      	jne	0x1aff <kprobe_unwind_python+0x1aff>
     2c9:      	movl	$0x1e, 0x18(%rsp)
     2d1:      	movq	(%rip), %rdi            # 0x2d8 <kprobe_unwind_python+0x2d8>
     2d8:      	leaq	0x18(%rsp), %rsi
     2dd:      	movl	$0x1, %eax
     2e2:      	callq	*%rax
     2e4:      	testq	%rax, %rax
     2e7:      	je	0xd6f <kprobe_unwind_python+0xd6f>
     2ed:      	incq	(%rax)
     2f0:      	jmp	0xd78 <kprobe_unwind_python+0xd78>
     2f5:      	movl	%r8d, 0x8(%rsp)
     2fa:      	movq	%rdi, %r12
     2fd:      	cmpl	$0x0, (%r14)
     301:      	jne	0x15db <kprobe_unwind_python+0x15db>
     307:      	movl	$0x1c, 0x18(%rsp)
     30f:      	movq	(%rip), %rdi            # 0x316 <kprobe_unwind_python+0x316>
     316:      	leaq	0x18(%rsp), %rsi
     31b:      	movl	$0x1, %eax
     320:      	callq	*%rax
     322:      	testq	%rax, %rax
     325:      	je	0x32f <kprobe_unwind_python+0x32f>
     327:      	incq	(%rax)
     32a:      	movq	%r12, %r13
     32d:      	jmp	0x33c <kprobe_unwind_python+0x33c>
     32f:      	cmpl	$0x0, (%r14)
     333:      	movq	%r12, %r13
     336:      	jne	0x17fc <kprobe_unwind_python+0x17fc>
     33c:      	movq	$-0x2, %r12
     343:      	xorl	%edx, %edx
     345:      	cmpl	$0x0, (%r14)
     349:      	jne	0xb08 <kprobe_unwind_python+0xb08>
     34f:      	movl	0x2c0(%rbp), %eax
     355:      	cmpq	$0x7f, %rax
     359:      	jb	0xb72 <kprobe_unwind_python+0xb72>
     35f:      	cmpl	$0x0, (%r14)
     363:      	jne	0x1662 <kprobe_unwind_python+0x1662>
     369:      	movl	$0x2, 0x18(%rsp)
     371:      	movq	(%rip), %rdi            # 0x378 <kprobe_unwind_python+0x378>
     378:      	leaq	0x18(%rsp), %rsi
     37d:      	movl	$0x1, %eax
     382:      	callq	*%rax
     384:      	testq	%rax, %rax
     387:      	je	0x447 <kprobe_unwind_python+0x447>
     38d:      	incq	(%rax)
     390:      	movq	0x10(%rsp), %rsi
     395:      	xorl	%ecx, %ecx
     397:      	cmpl	$0x0, (%r14)
     39b:      	movl	$0x2, %r12d
     3a1:      	je	0x16f <kprobe_unwind_python+0x16f>
     3a7:      	movabsq	$0xa656d61726620, %rax  # imm = 0xA656D61726620
     3b1:      	movq	%rax, 0x45(%rsp)
     3b6:      	movabsq	$0x7266206e6f687479, %rax # imm = 0x7266206E6F687479
     3c0:      	movq	%rax, 0x40(%rsp)
     3c5:      	movabsq	$0x702068737570206f, %rax # imm = 0x702068737570206F
     3cf:      	movq	%rax, 0x38(%rsp)
     3d4:      	movabsq	$0x742064656c696166, %rax # imm = 0x742064656C696166
     3de:      	movq	%rax, 0x30(%rsp)
     3e3:      	leaq	0x30(%rsp), %rdi
     3e8:      	movl	$0x1d, %eax
     3ed:      	movl	$0x6, %ecx
     3f2:      	movl	$0x1d, %esi
     3f7:      	xorl	%eax, %eax
     3f9:      	callq	*%rcx
     3fb:      	xorl	%ecx, %ecx
     3fd:      	movq	0x10(%rsp), %rsi
     402:      	jmp	0x16f <kprobe_unwind_python+0x16f>
     407:      	movabsq	$0xa29286e6f687479, %rax # imm = 0xA29286E6F687479
     411:      	movq	%rax, 0x38(%rsp)
     416:      	movabsq	$0x705f646e69776e75, %rax # imm = 0x705F646E69776E75
     420:      	movq	%rax, 0x30(%rsp)
     425:      	movb	$0x0, 0x40(%rsp)
     42a:      	leaq	0x30(%rsp), %rdi
     42f:      	movl	$0x11, %eax
     434:      	movl	$0x6, %ecx
     439:      	movl	$0x11, %esi
     43e:      	xorl	%eax, %eax
     440:      	callq	*%rcx
     442:      	jmp	0x59 <kprobe_unwind_python+0x59>
     447:      	cmpl	$0x0, (%r14)
     44b:      	movq	0x10(%rsp), %rsi
     450:      	movl	$0x0, %ecx
     455:      	jne	0x1901 <kprobe_unwind_python+0x1901>
     45b:      	movl	$0x2, %r12d
     461:      	jmp	0x16f <kprobe_unwind_python+0x16f>
     466:      	movabsq	$0xa782578302072, %rcx  # imm = 0xA782578302072
     470:      	movq	%rcx, 0x48(%rsp)
     475:      	movabsq	$0x6f66206b63617473, %rcx # imm = 0x6F66206B63617473
     47f:      	movq	%rcx, 0x40(%rsp)
     484:      	movabsq	$0x206e6f6874795020, %rcx # imm = 0x206E6F6874795020
     48e:      	movq	%rcx, 0x38(%rsp)
     493:      	movabsq	$0x676e69646c697542, %rcx # imm = 0x676E69646C697542
     49d:      	movq	%rcx, 0x30(%rsp)
     4a2:      	leaq	0x30(%rsp), %rdi
     4a7:      	movl	$0x20, %ecx
     4ac:      	movl	$0x6, %r8d
     4b2:      	movzwl	0x10(%rax), %edx
     4b6:      	movl	$0x20, %esi
     4bb:      	movq	%rbx, %r12
     4be:      	movq	%r14, %rbx
     4c1:      	movq	%rax, %r14
     4c4:      	xorl	%eax, %eax
     4c6:      	callq	*%r8
     4c9:      	movq	%r14, %rax
     4cc:      	movq	%rbx, %r14
     4cf:      	movq	%r12, %rbx
     4d2:      	leaq	0xf58(%r15), %rsi
     4d9:      	movq	0xf58(%rbp), %r13
     4e0:      	testq	%r13, %r13
     4e3:      	jne	0x9a <kprobe_unwind_python+0x9a>
     4e9:      	movq	%rsi, 0x10(%rsp)
     4ee:      	movq	%rax, %r13
     4f1:      	movl	$0x15, 0x18(%rsp)
     4f9:      	movq	(%rip), %rdi            # 0x500 <kprobe_unwind_python+0x500>
     500:      	leaq	0x18(%rsp), %rsi
     505:      	movl	$0x1, %eax
     50a:      	callq	*%rax
     50c:      	testq	%rax, %rax
     50f:      	je	0x516 <kprobe_unwind_python+0x516>
     511:      	incq	(%rax)
     514:      	jmp	0x520 <kprobe_unwind_python+0x520>
     516:      	cmpl	$0x0, (%r14)
     51a:      	jne	0xd92 <kprobe_unwind_python+0xd92>
     520:      	movl	$0x23, %eax
     525:      	callq	*%rax
     527:      	movq	(%rip), %rcx            # 0x52e <kprobe_unwind_python+0x52e>
     52e:      	addq	(%rcx), %rax
     531:      	leaq	0x90(%rsp), %rdi
     539:      	movl	$0x8, %ecx
     53e:      	movl	$0x71, %r8d
     544:      	movl	$0x8, %esi
     549:      	movq	%rax, %rdx
     54c:      	callq	*%r8
     54f:      	movl	(%r14), %ecx
     552:      	testq	%rax, %rax
     555:      	je	0x5ed <kprobe_unwind_python+0x5ed>
     55b:      	testl	%ecx, %ecx
     55d:      	jne	0xc4b <kprobe_unwind_python+0xc4b>
     563:      	movl	$0x4, 0x18(%rsp)
     56b:      	movq	(%rip), %rdi            # 0x572 <kprobe_unwind_python+0x572>
     572:      	leaq	0x18(%rsp), %rsi
     577:      	movl	$0x1, %eax
     57c:      	callq	*%rax
     57e:      	testq	%rax, %rax
     581:      	je	0x66f <kprobe_unwind_python+0x66f>
     587:      	incq	(%rax)
     58a:      	cmpl	$0x0, (%r14)
     58e:      	je	0x679 <kprobe_unwind_python+0x679>
     594:      	movabsq	$0xa737365726464, %rax  # imm = 0xA737365726464
     59e:      	movq	%rax, 0x48(%rsp)
     5a3:      	movabsq	$0x6120657361622044, %rax # imm = 0x6120657361622044
     5ad:      	movq	%rax, 0x40(%rsp)
     5b2:      	movabsq	$0x535420746567206f, %rax # imm = 0x535420746567206F
     5bc:      	movq	%rax, 0x38(%rsp)
     5c1:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     5cb:      	movq	%rax, 0x30(%rsp)
     5d0:      	leaq	0x30(%rsp), %rdi
     5d5:      	movl	$0x20, %eax
     5da:      	movl	$0x6, %ecx
     5df:      	movl	$0x20, %esi
     5e4:      	xorl	%eax, %eax
     5e6:      	callq	*%rcx
     5e8:      	jmp	0x679 <kprobe_unwind_python+0x679>
     5ed:      	movq	%rbp, (%rsp)
     5f1:      	movq	%rbx, %rbp
     5f4:      	movq	%r14, %rbx
     5f7:      	testl	%ecx, %ecx
     5f9:      	jne	0xe0d <kprobe_unwind_python+0xe0d>
     5ff:      	movq	0x90(%rsp), %r14
     607:      	movq	(%r13), %r12
     60b:      	leaq	0x8c(%rsp), %rdi
     613:      	movl	$0x4, %eax
     618:      	movl	$0x70, %ecx
     61d:      	movl	$0x4, %esi
     622:      	movq	%r12, %rdx
     625:      	callq	*%rcx
     627:      	testq	%rax, %rax
     62a:      	je	0x6b9 <kprobe_unwind_python+0x6b9>
     630:      	movq	%rbx, %r14
     633:      	cmpl	$0x0, (%rbx)
     636:      	jne	0xefe <kprobe_unwind_python+0xefe>
     63c:      	movl	$0x46, 0x18(%rsp)
     644:      	movq	(%rip), %rdi            # 0x64b <kprobe_unwind_python+0x64b>
     64b:      	leaq	0x18(%rsp), %rsi
     650:      	movl	$0x1, %eax
     655:      	callq	*%rax
     657:      	testq	%rax, %rax
     65a:      	movq	%rbp, %rbx
     65d:      	je	0x77c <kprobe_unwind_python+0x77c>
     663:      	incq	(%rax)
     666:      	movq	(%rsp), %rbp
     66a:      	jmp	0x78a <kprobe_unwind_python+0x78a>
     66f:      	cmpl	$0x0, (%r14)
     673:      	jne	0xf69 <kprobe_unwind_python+0xf69>
     679:      	movl	$0x48, 0x18(%rsp)
     681:      	movq	(%rip), %rdi            # 0x688 <kprobe_unwind_python+0x688>
     688:      	leaq	0x18(%rsp), %rsi
     68d:      	movl	$0x1, %eax
     692:      	callq	*%rax
     694:      	testq	%rax, %rax
     697:      	je	0x69e <kprobe_unwind_python+0x69e>
     699:      	incq	(%rax)
     69c:      	jmp	0x6a8 <kprobe_unwind_python+0x6a8>
     69e:      	cmpl	$0x0, (%r14)
     6a2:      	jne	0xfee <kprobe_unwind_python+0xfee>
     6a8:      	movl	$0x7d8, %r12d           # imm = 0x7D8
     6ae:      	movl	$0x1, %r15d
     6b4:      	jmp	0x7e1 <kprobe_unwind_python+0x7e1>
     6b9:      	movslq	0x8c(%rsp), %r12
     6c1:      	movswq	0x12(%r13), %rcx
     6c6:      	addq	%rcx, %r14
     6c9:      	movq	%r14, 0x18(%rsp)
     6ce:      	cmpb	$0x0, 0x15(%r13)
     6d3:      	je	0x6fd <kprobe_unwind_python+0x6fd>
     6d5:      	leaq	0x18(%rsp), %rdi
     6da:      	movl	$0x8, %eax
     6df:      	movl	$0x70, %ecx
     6e4:      	movq	0x18(%rsp), %rdx
     6e9:      	movl	$0x8, %esi
     6ee:      	callq	*%rcx
     6f0:      	testq	%rax, %rax
     6f3:      	movq	%rbx, %r14
     6f6:      	jne	0x746 <kprobe_unwind_python+0x746>
     6f8:      	movq	0x18(%rsp), %r14
     6fd:      	movq	%r13, %rax
     700:      	movzbl	0x14(%r13), %eax
     705:      	imulq	%r12, %rax
     709:      	addq	%r14, %rax
     70c:      	movq	%rax, 0x18(%rsp)
     711:      	movq	%rbx, %r14
     714:      	cmpl	$0x0, (%rbx)
     717:      	jne	0x1142 <kprobe_unwind_python+0x1142>
     71d:      	leaq	0x80(%rsp), %rdi
     725:      	movl	$0x8, %ecx
     72a:      	movl	$0x70, %r8d
     730:      	movq	0x18(%rsp), %rdx
     735:      	movl	$0x8, %esi
     73a:      	callq	*%r8
     73d:      	testq	%rax, %rax
     740:      	je	0x8a9 <kprobe_unwind_python+0x8a9>
     746:      	cmpl	$0x0, (%r14)
     74a:      	jne	0x1069 <kprobe_unwind_python+0x1069>
     750:      	movl	$0x3, 0x7c(%rsp)
     758:      	movq	(%rip), %rdi            # 0x75f <kprobe_unwind_python+0x75f>
     75f:      	leaq	0x7c(%rsp), %rsi
     764:      	movl	$0x1, %eax
     769:      	callq	*%rax
     76b:      	testq	%rax, %rax
     76e:      	movq	%rbp, %rbx
     771:      	je	0x798 <kprobe_unwind_python+0x798>
     773:      	incq	(%rax)
     776:      	movq	(%rsp), %rbp
     77a:      	jmp	0x7a6 <kprobe_unwind_python+0x7a6>
     77c:      	cmpl	$0x0, (%r14)
     780:      	movq	(%rsp), %rbp
     784:      	jne	0x10c7 <kprobe_unwind_python+0x10c7>
     78a:      	movl	$0x7d7, %r12d           # imm = 0x7D7
     790:      	movl	$0x1, %r15d
     796:      	jmp	0x7e1 <kprobe_unwind_python+0x7e1>
     798:      	cmpl	$0x0, (%r14)
     79c:      	movq	(%rsp), %rbp
     7a0:      	jne	0x1259 <kprobe_unwind_python+0x1259>
     7a6:      	movl	$0x47, 0x18(%rsp)
     7ae:      	movq	(%rip), %rdi            # 0x7b5 <kprobe_unwind_python+0x7b5>
     7b5:      	leaq	0x18(%rsp), %rsi
     7ba:      	movl	$0x1, %eax
     7bf:      	callq	*%rax
     7c1:      	testq	%rax, %rax
     7c4:      	je	0x7cb <kprobe_unwind_python+0x7cb>
     7c6:      	incq	(%rax)
     7c9:      	jmp	0x7d5 <kprobe_unwind_python+0x7d5>
     7cb:      	cmpl	$0x0, (%r14)
     7cf:      	jne	0x12d4 <kprobe_unwind_python+0x12d4>
     7d5:      	movl	$0x7d4, %r12d           # imm = 0x7D4
     7db:      	movl	$0x1, %r15d
     7e1:      	movl	%r12d, 0xf2c(%rbp)
     7e8:      	movl	$0x0, 0x30(%rsp)
     7f0:      	movq	(%rip), %rdi            # 0x7f7 <kprobe_unwind_python+0x7f7>
     7f7:      	leaq	0x30(%rsp), %rsi
     7fc:      	movl	$0x1, %eax
     801:      	callq	*%rax
     803:      	testq	%rax, %rax
     806:      	je	0x846 <kprobe_unwind_python+0x846>
     808:      	movzbl	0x1384(%rax), %ecx
     80f:      	cmpb	$0x1d, %cl
     812:      	jb	0x873 <kprobe_unwind_python+0x873>
     814:      	movq	%rax, %r15
     817:      	movl	$0x5, 0xf2c(%rax)
     821:      	movl	$0x44, 0x18(%rsp)
     829:      	movq	(%rip), %rdi            # 0x830 <kprobe_unwind_python+0x830>
     830:      	leaq	0x18(%rsp), %rsi
     835:      	movl	$0x1, %eax
     83a:      	callq	*%rax
     83c:      	testq	%rax, %rax
     83f:      	je	0x85b <kprobe_unwind_python+0x85b>
     841:      	incq	(%rax)
     844:      	jmp	0x865 <kprobe_unwind_python+0x865>
     846:      	movq	(%rip), %rsi            # 0x84d <kprobe_unwind_python+0x84d>
     84d:      	xorl	%eax, %eax
     84f:      	movl	$0xc, %ecx
     854:      	movq	%rbx, %rdi
     857:      	xorl	%edx, %edx
     859:      	jmp	0x890 <kprobe_unwind_python+0x890>
     85b:      	cmpl	$0x0, (%r14)
     85f:      	jne	0xe83 <kprobe_unwind_python+0xe83>
     865:      	movq	%r15, %rax
     868:      	movzbl	0x1384(%r15), %ecx
     870:      	xorl	%r15d, %r15d
     873:      	incb	%cl
     875:      	movb	%cl, 0x1384(%rax)
     87b:      	movl	%r15d, %eax
     87e:      	movq	(%rip), %rsi            # 0x885 <kprobe_unwind_python+0x885>
     885:      	movl	$0xc, %ecx
     88a:      	movq	%rbx, %rdi
     88d:      	movl	%r15d, %edx
     890:      	callq	*%rcx
     892:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     897:      	addq	$0x98, %rsp
     89e:      	popq	%rbx
     89f:      	popq	%r12
     8a1:      	popq	%r13
     8a3:      	popq	%r14
     8a5:      	popq	%r15
     8a7:      	popq	%rbp
     8a8:      	retq
     8a9:      	movq	0x80(%rsp), %rax
     8b1:      	testq	%rax, %rax
     8b4:      	je	0x925 <kprobe_unwind_python+0x925>
     8b6:      	movzbl	0x16(%r13), %edx
     8bb:      	addq	%rdx, %rax
     8be:      	movl	$0x8, %edx
     8c3:      	movl	$0x70, %r8d
     8c9:      	movq	0x10(%rsp), %rdi
     8ce:      	movzbl	0x16(%r13), %edx
     8d3:      	addq	0x80(%rsp), %rdx
     8db:      	movl	$0x8, %esi
     8e0:      	callq	*%r8
     8e3:      	testq	%rax, %rax
     8e6:      	movq	%rbp, %rbx
     8e9:      	je	0x962 <kprobe_unwind_python+0x962>
     8eb:      	cmpl	$0x0, (%r14)
     8ef:      	movq	(%rsp), %rbp
     8f3:      	jne	0x1429 <kprobe_unwind_python+0x1429>
     8f9:      	movl	$0x19, 0x18(%rsp)
     901:      	movq	(%rip), %rdi            # 0x908 <kprobe_unwind_python+0x908>
     908:      	leaq	0x18(%rsp), %rsi
     90d:      	movl	$0x1, %eax
     912:      	callq	*%rax
     914:      	testq	%rax, %rax
     917:      	je	0x9d0 <kprobe_unwind_python+0x9d0>
     91d:      	incq	(%rax)
     920:      	jmp	0x9da <kprobe_unwind_python+0x9da>
     925:      	cmpl	$0x0, (%r14)
     929:      	movq	%rbp, %rbx
     92c:      	jne	0x1591 <kprobe_unwind_python+0x1591>
     932:      	movl	$0x18, 0x18(%rsp)
     93a:      	movq	(%rip), %rdi            # 0x941 <kprobe_unwind_python+0x941>
     941:      	leaq	0x18(%rsp), %rsi
     946:      	movl	$0x1, %eax
     94b:      	callq	*%rax
     94d:      	testq	%rax, %rax
     950:      	movq	(%rsp), %rbp
     954:      	je	0xa1b <kprobe_unwind_python+0xa1b>
     95a:      	incq	(%rax)
     95d:      	jmp	0xa25 <kprobe_unwind_python+0xa25>
     962:      	movq	%r13, %rax
     965:      	cmpb	$0x0, 0x23(%r13)
     96a:      	movq	(%rsp), %rbp
     96e:      	je	0x9eb <kprobe_unwind_python+0x9eb>
     970:      	movzbl	0x17(%rax), %ecx
     974:      	movq	0x10(%rsp), %rdi
     979:      	addq	(%rdi), %rcx
     97c:      	movl	$0x8, %edx
     981:      	movl	$0x70, %r8d
     987:      	movzbl	0x17(%rax), %edx
     98b:      	addq	(%rdi), %rdx
     98e:      	movl	$0x8, %esi
     993:      	callq	*%r8
     996:      	movq	%rax, %rcx
     999:      	movq	%r13, %rax
     99c:      	testq	%rcx, %rcx
     99f:      	je	0x9eb <kprobe_unwind_python+0x9eb>
     9a1:      	cmpl	$0x0, (%r14)
     9a5:      	jne	0x1877 <kprobe_unwind_python+0x1877>
     9ab:      	movl	$0x43, 0x18(%rsp)
     9b3:      	movq	(%rip), %rdi            # 0x9ba <kprobe_unwind_python+0x9ba>
     9ba:      	leaq	0x18(%rsp), %rsi
     9bf:      	movl	$0x1, %eax
     9c4:      	callq	*%rax
     9c6:      	testq	%rax, %rax
     9c9:      	je	0xa36 <kprobe_unwind_python+0xa36>
     9cb:      	incq	(%rax)
     9ce:      	jmp	0xa40 <kprobe_unwind_python+0xa40>
     9d0:      	cmpl	$0x0, (%r14)
     9d4:      	jne	0x16ca <kprobe_unwind_python+0x16ca>
     9da:      	movl	$0x7d6, %r12d           # imm = 0x7D6
     9e0:      	movl	$0x1, %r15d
     9e6:      	jmp	0x7e1 <kprobe_unwind_python+0x7e1>
     9eb:      	movq	0x10(%rsp), %rsi
     9f0:      	movq	(%rsi), %r13
     9f3:      	testq	%r13, %r13
     9f6:      	jne	0x9a <kprobe_unwind_python+0x9a>
     9fc:      	cmpl	$0x0, (%r14)
     a00:      	jne	0x1a2b <kprobe_unwind_python+0x1a2b>
     a06:      	orb	$0x10, 0x1380(%rbp)
     a0d:      	xorl	%r12d, %r12d
     a10:      	movl	$0x1, %r15d
     a16:      	jmp	0x7e1 <kprobe_unwind_python+0x7e1>
     a1b:      	cmpl	$0x0, (%r14)
     a1f:      	jne	0x1781 <kprobe_unwind_python+0x1781>
     a25:      	movl	$0x7d5, %r12d           # imm = 0x7D5
     a2b:      	movl	$0x1, %r15d
     a31:      	jmp	0x7e1 <kprobe_unwind_python+0x7e1>
     a36:      	cmpl	$0x0, (%r14)
     a3a:      	jne	0x1a84 <kprobe_unwind_python+0x1a84>
     a40:      	movl	$0x7d3, %r12d           # imm = 0x7D3
     a46:      	movl	$0x1, %r15d
     a4c:      	jmp	0x7e1 <kprobe_unwind_python+0x7e1>
     a51:      	movabsq	$0x666e692073736572, %rax # imm = 0x666E692073736572
     a5b:      	movq	%rax, 0x50(%rsp)
     a60:      	movabsq	$0x646461206f6e202c, %rax # imm = 0x646461206F6E202C
     a6a:      	movq	%rax, 0x48(%rsp)
     a6f:      	movabsq	$0x6b63617473206e6f, %rax # imm = 0x6B63617473206E6F
     a79:      	movq	%rax, 0x40(%rsp)
     a7e:      	movabsq	$0x6874795020646c69, %rax # imm = 0x6874795020646C69
     a88:      	movq	%rax, 0x38(%rsp)
     a8d:      	movabsq	$0x75622074276e6143, %rax # imm = 0x75622074276E6143
     a97:      	movq	%rax, 0x30(%rsp)
     a9c:      	movl	$0xa6f66, 0x57(%rsp)    # imm = 0xA6F66
     aa4:      	leaq	0x30(%rsp), %rdi
     aa9:      	movl	$0x2b, %eax
     aae:      	movl	$0x6, %ecx
     ab3:      	movl	$0x2b, %esi
     ab8:      	xorl	%eax, %eax
     aba:      	callq	*%rcx
     abc:      	jmp	0x13c <kprobe_unwind_python+0x13c>
     ac1:      	movq	(%rsp), %rax
     ac5:      	movzbl	0x1d(%rax), %ecx
     ac9:      	movl	(%r15,%rcx), %ecx
     acd:      	movzbl	0x1e(%rax), %edx
     ad1:      	movl	(%r15,%rdx), %edx
     ad5:      	movzbl	0x1f(%rax), %esi
     ad9:      	movl	(%r15,%rsi), %esi
     add:      	movzbl	0x20(%rax), %eax
     ae1:      	shll	$0x19, %ecx
     ae4:      	shll	$0x12, %edx
     ae7:      	addl	%ecx, %edx
     ae9:      	shll	$0xa, %esi
     aec:      	addl	%edx, %esi
     aee:      	addl	(%r15,%rax), %esi
     af2:      	shlq	$0x20, %r12
     af6:      	orq	%rsi, %r12
     af9:      	movq	0x28(%rsp), %rdx
     afe:      	cmpl	$0x0, (%r14)
     b02:      	je	0x34f <kprobe_unwind_python+0x34f>
     b08:      	movabsq	$0xa756c2520786c, %rax  # imm = 0xA756C2520786C
     b12:      	movq	%rax, 0x40(%rsp)
     b17:      	movabsq	$0x25206e6f68747950, %rax # imm = 0x25206E6F68747950
     b21:      	movq	%rax, 0x38(%rsp)
     b26:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
     b30:      	movq	%rax, 0x30(%rsp)
     b35:      	movq	%r13, 0x20(%rsp)
     b3a:      	leaq	0x30(%rsp), %rdi
     b3f:      	movl	$0x18, %eax
     b44:      	movl	$0x6, %r8d
     b4a:      	movl	$0x18, %esi
     b4f:      	movq	%r12, %rcx
     b52:      	xorl	%eax, %eax
     b54:      	movq	%rdx, %r13
     b57:      	callq	*%r8
     b5a:      	movq	%r13, %rdx
     b5d:      	movq	0x20(%rsp), %r13
     b62:      	movl	0x2c0(%rbp), %eax
     b68:      	cmpq	$0x7f, %rax
     b6c:      	jae	0x35f <kprobe_unwind_python+0x35f>
     b72:      	movq	%r13, 0x20(%rsp)
     b77:      	leal	0x1(%rax), %ecx
     b7a:      	movl	%ecx, 0x2c0(%rbp)
     b80:      	leaq	(%rax,%rax,2), %rax
     b84:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
     b8c:      	movq	%r12, 0x2d8(%rbp,%rax,8)
     b94:      	movb	$0x1, 0x2e0(%rbp,%rax,8)
     b9c:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
     ba7:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
     bb2:      	movl	$0x16, 0x18(%rsp)
     bba:      	movq	(%rip), %rdi            # 0xbc1 <kprobe_unwind_python+0xbc1>
     bc1:      	leaq	0x18(%rsp), %rsi
     bc6:      	movl	$0x1, %eax
     bcb:      	callq	*%rax
     bcd:      	testq	%rax, %rax
     bd0:      	je	0xbf3 <kprobe_unwind_python+0xbf3>
     bd2:      	incq	(%rax)
     bd5:      	movq	(%rsp), %rax
     bd9:      	movq	0x10(%rsp), %rsi
     bde:      	movl	0x8(%rsp), %r8d
     be3:      	testb	%r8b, %r8b
     be6:      	movq	0x20(%rsp), %rdi
     beb:      	jne	0x1bf <kprobe_unwind_python+0x1bf>
     bf1:      	jmp	0xc19 <kprobe_unwind_python+0xc19>
     bf3:      	cmpl	$0x0, (%r14)
     bf7:      	movq	(%rsp), %rax
     bfb:      	movq	0x10(%rsp), %rsi
     c00:      	movl	0x8(%rsp), %r8d
     c05:      	jne	0x1993 <kprobe_unwind_python+0x1993>
     c0b:      	testb	%r8b, %r8b
     c0e:      	movq	0x20(%rsp), %rdi
     c13:      	jne	0x1bf <kprobe_unwind_python+0x1bf>
     c19:      	xorl	%r12d, %r12d
     c1c:      	testq	%rdi, %rdi
     c1f:      	je	0xc41 <kprobe_unwind_python+0xc41>
     c21:      	cmpb	$0x78, 0x19(%rax)
     c25:      	ja	0xc31 <kprobe_unwind_python+0xc31>
     c27:      	cmpb	$0x78, 0x18(%rax)
     c2b:      	jbe	0xd1f <kprobe_unwind_python+0xd1f>
     c31:      	xorl	%ecx, %ecx
     c33:      	movq	%rdi, %r13
     c36:      	movl	$0x1, %r12d
     c3c:      	jmp	0x16f <kprobe_unwind_python+0x16f>
     c41:      	xorl	%ecx, %ecx
     c43:      	xorl	%r13d, %r13d
     c46:      	jmp	0x16f <kprobe_unwind_python+0x16f>
     c4b:      	movabsq	$0xa65756c617620, %rax  # imm = 0xA65756C617620
     c55:      	movq	%rax, 0x45(%rsp)
     c5a:      	movabsq	$0x6176206573616270, %rax # imm = 0x6176206573616270
     c64:      	movq	%rax, 0x40(%rsp)
     c69:      	movabsq	$0x742064616572206f, %rax # imm = 0x742064616572206F
     c73:      	movq	%rax, 0x38(%rsp)
     c78:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     c82:      	movq	%rax, 0x30(%rsp)
     c87:      	leaq	0x30(%rsp), %rdi
     c8c:      	movl	$0x1d, %eax
     c91:      	movl	$0x6, %ecx
     c96:      	movl	$0x1d, %esi
     c9b:      	xorl	%eax, %eax
     c9d:      	callq	*%rcx
     c9f:      	jmp	0x563 <kprobe_unwind_python+0x563>
     ca4:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     cae:      	movq	%rax, 0x56(%rsp)
     cb3:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     cbd:      	movq	%rax, 0x50(%rsp)
     cc2:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     ccc:      	movq	%rax, 0x48(%rsp)
     cd1:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     cdb:      	movq	%rax, 0x40(%rsp)
     ce0:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     cea:      	movq	%rax, 0x38(%rsp)
     cef:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     cf9:      	movq	%rax, 0x30(%rsp)
     cfe:      	leaq	0x30(%rsp), %rdi
     d03:      	movl	$0x2e, %eax
     d08:      	movl	$0x6, %ecx
     d0d:      	movl	0x18(%rsp), %edx
     d11:      	movl	$0x2e, %esi
     d16:      	xorl	%eax, %eax
     d18:      	callq	*%rcx
     d1a:      	jmp	0x18e <kprobe_unwind_python+0x18e>
     d1f:      	movq	%rbx, 0x8(%rsp)
     d24:      	cmpb	$0x78, 0x1a(%rax)
     d28:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
     d2e:      	movq	(%rsp), %rax
     d32:      	cmpb	$0x0, 0x1b(%rax)
     d36:      	js	0x45a2 <kprobe_unwind_python+0x45a2>
     d3c:      	movl	$0x80, %eax
     d41:      	movl	$0x70, %ecx
     d46:      	movq	0x70(%rsp), %rdi
     d4b:      	movq	0x20(%rsp), %rdx
     d50:      	movl	$0x80, %esi
     d55:      	callq	*%rcx
     d57:      	testq	%rax, %rax
     d5a:      	je	0x1216 <kprobe_unwind_python+0x1216>
     d60:      	movq	0x20(%rsp), %r13
     d65:      	movq	0x8(%rsp), %rbx
     d6a:      	jmp	0xf4 <kprobe_unwind_python+0xf4>
     d6f:      	cmpl	$0x0, (%rbx)
     d72:      	jne	0x1b6c <kprobe_unwind_python+0x1b6c>
     d78:      	movl	$0x7d0, %r12d           # imm = 0x7D0
     d7e:      	movq	%rbx, %r14
     d81:      	movq	0x8(%rsp), %rbx
     d86:      	movq	0x10(%rsp), %rsi
     d8b:      	xorl	%ecx, %ecx
     d8d:      	jmp	0x16f <kprobe_unwind_python+0x16f>
     d92:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     d9c:      	movq	%rax, 0x56(%rsp)
     da1:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     dab:      	movq	%rax, 0x50(%rsp)
     db0:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     dba:      	movq	%rax, 0x48(%rsp)
     dbf:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     dc9:      	movq	%rax, 0x40(%rsp)
     dce:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     dd8:      	movq	%rax, 0x38(%rsp)
     ddd:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     de7:      	movq	%rax, 0x30(%rsp)
     dec:      	leaq	0x30(%rsp), %rdi
     df1:      	movl	$0x2e, %eax
     df6:      	movl	$0x6, %ecx
     dfb:      	movl	0x18(%rsp), %edx
     dff:      	movl	$0x2e, %esi
     e04:      	xorl	%eax, %eax
     e06:      	callq	*%rcx
     e08:      	jmp	0x520 <kprobe_unwind_python+0x520>
     e0d:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
     e17:      	movq	%rax, 0x4e(%rsp)
     e1c:      	movabsq	$0x3020726464417965, %rax # imm = 0x3020726464417965
     e26:      	movq	%rax, 0x48(%rsp)
     e2b:      	movabsq	$0x4b534c546f747561, %rax # imm = 0x4B534C546F747561
     e35:      	movq	%rax, 0x40(%rsp)
     e3a:      	movabsq	$0x202c786c25783020, %rax # imm = 0x202C786C25783020
     e44:      	movq	%rax, 0x38(%rsp)
     e49:      	movabsq	$0x6573614220445354, %rax # imm = 0x6573614220445354
     e53:      	movq	%rax, 0x30(%rsp)
     e58:      	leaq	0x30(%rsp), %rdi
     e5d:      	movl	$0x26, %eax
     e62:      	movl	$0x6, %r8d
     e68:      	movq	0x90(%rsp), %rdx
     e70:      	movq	(%r13), %rcx
     e74:      	movl	$0x26, %esi
     e79:      	xorl	%eax, %eax
     e7b:      	callq	*%r8
     e7e:      	jmp	0x5ff <kprobe_unwind_python+0x5ff>
     e83:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     e8d:      	movq	%rax, 0x56(%rsp)
     e92:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     e9c:      	movq	%rax, 0x50(%rsp)
     ea1:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     eab:      	movq	%rax, 0x48(%rsp)
     eb0:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     eba:      	movq	%rax, 0x40(%rsp)
     ebf:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     ec9:      	movq	%rax, 0x38(%rsp)
     ece:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     ed8:      	movq	%rax, 0x30(%rsp)
     edd:      	leaq	0x30(%rsp), %rdi
     ee2:      	movl	$0x2e, %eax
     ee7:      	movl	$0x6, %ecx
     eec:      	movl	0x18(%rsp), %edx
     ef0:      	movl	$0x2e, %esi
     ef5:      	xorl	%eax, %eax
     ef7:      	callq	*%rcx
     ef9:      	jmp	0x865 <kprobe_unwind_python+0x865>
     efe:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
     f08:      	movq	%rax, 0x4e(%rsp)
     f0d:      	movabsq	$0x30206d6f72662079, %rax # imm = 0x30206D6F72662079
     f17:      	movq	%rax, 0x48(%rsp)
     f1c:      	movabsq	$0x656b534c546f7475, %rax # imm = 0x656B534C546F7475
     f26:      	movq	%rax, 0x40(%rsp)
     f2b:      	movabsq	$0x612064616572206f, %rax # imm = 0x612064616572206F
     f35:      	movq	%rax, 0x38(%rsp)
     f3a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     f44:      	movq	%rax, 0x30(%rsp)
     f49:      	leaq	0x30(%rsp), %rdi
     f4e:      	movl	$0x26, %eax
     f53:      	movl	$0x6, %ecx
     f58:      	movl	$0x26, %esi
     f5d:      	movq	%r12, %rdx
     f60:      	xorl	%eax, %eax
     f62:      	callq	*%rcx
     f64:      	jmp	0x63c <kprobe_unwind_python+0x63c>
     f69:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     f73:      	movq	%rax, 0x56(%rsp)
     f78:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     f82:      	movq	%rax, 0x50(%rsp)
     f87:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     f91:      	movq	%rax, 0x48(%rsp)
     f96:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     fa0:      	movq	%rax, 0x40(%rsp)
     fa5:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     faf:      	movq	%rax, 0x38(%rsp)
     fb4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     fbe:      	movq	%rax, 0x30(%rsp)
     fc3:      	leaq	0x30(%rsp), %rdi
     fc8:      	movl	$0x2e, %eax
     fcd:      	movl	$0x6, %ecx
     fd2:      	movl	0x18(%rsp), %edx
     fd6:      	movl	$0x2e, %esi
     fdb:      	xorl	%eax, %eax
     fdd:      	callq	*%rcx
     fdf:      	cmpl	$0x0, (%r14)
     fe3:      	je	0x679 <kprobe_unwind_python+0x679>
     fe9:      	jmp	0x594 <kprobe_unwind_python+0x594>
     fee:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     ff8:      	movq	%rax, 0x56(%rsp)
     ffd:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1007:      	movq	%rax, 0x50(%rsp)
    100c:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1016:      	movq	%rax, 0x48(%rsp)
    101b:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1025:      	movq	%rax, 0x40(%rsp)
    102a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1034:      	movq	%rax, 0x38(%rsp)
    1039:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1043:      	movq	%rax, 0x30(%rsp)
    1048:      	leaq	0x30(%rsp), %rdi
    104d:      	movl	$0x2e, %eax
    1052:      	movl	$0x6, %ecx
    1057:      	movl	0x18(%rsp), %edx
    105b:      	movl	$0x2e, %esi
    1060:      	xorl	%eax, %eax
    1062:      	callq	*%rcx
    1064:      	jmp	0x6a8 <kprobe_unwind_python+0x6a8>
    1069:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    1073:      	movq	%rax, 0x47(%rsp)
    1078:      	movabsq	$0x206d6f7266204453, %rax # imm = 0x206D6F7266204453
    1082:      	movq	%rax, 0x40(%rsp)
    1087:      	movabsq	$0x542064616572206f, %rax # imm = 0x542064616572206F
    1091:      	movq	%rax, 0x38(%rsp)
    1096:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    10a0:      	movq	%rax, 0x30(%rsp)
    10a5:      	leaq	0x30(%rsp), %rdi
    10aa:      	movl	$0x1f, %eax
    10af:      	movl	$0x6, %ecx
    10b4:      	movq	0x18(%rsp), %rdx
    10b9:      	movl	$0x1f, %esi
    10be:      	xorl	%eax, %eax
    10c0:      	callq	*%rcx
    10c2:      	jmp	0x750 <kprobe_unwind_python+0x750>
    10c7:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    10d1:      	movq	%rax, 0x56(%rsp)
    10d6:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    10e0:      	movq	%rax, 0x50(%rsp)
    10e5:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    10ef:      	movq	%rax, 0x48(%rsp)
    10f4:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    10fe:      	movq	%rax, 0x40(%rsp)
    1103:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    110d:      	movq	%rax, 0x38(%rsp)
    1112:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    111c:      	movq	%rax, 0x30(%rsp)
    1121:      	leaq	0x30(%rsp), %rdi
    1126:      	movl	$0x2e, %eax
    112b:      	movl	$0x6, %ecx
    1130:      	movl	0x18(%rsp), %edx
    1134:      	movl	$0x2e, %esi
    1139:      	xorl	%eax, %eax
    113b:      	callq	*%rcx
    113d:      	jmp	0x78a <kprobe_unwind_python+0x78a>
    1142:      	movabsq	$0x6c25783020737365, %rax # imm = 0x6C25783020737365
    114c:      	movq	%rax, 0x48(%rsp)
    1151:      	movabsq	$0x72646461206d6f72, %rax # imm = 0x72646461206D6F72
    115b:      	movq	%rax, 0x40(%rsp)
    1160:      	movabsq	$0x662064252079656b, %rax # imm = 0x662064252079656B
    116a:      	movq	%rax, 0x38(%rsp)
    116f:      	movabsq	$0x2044535464616572, %rax # imm = 0x2044535464616572
    1179:      	movq	%rax, 0x30(%rsp)
    117e:      	movl	$0xa786c, 0x4f(%rsp)    # imm = 0xA786C
    1186:      	leaq	0x30(%rsp), %rdi
    118b:      	movl	$0x23, %eax
    1190:      	movl	$0x6, %r8d
    1196:      	movq	0x18(%rsp), %rcx
    119b:      	movl	$0x23, %esi
    11a0:      	movl	%r12d, %edx
    11a3:      	xorl	%eax, %eax
    11a5:      	callq	*%r8
    11a8:      	movq	0x18(%rsp), %rax
    11ad:      	jmp	0x71d <kprobe_unwind_python+0x71d>
    11b2:      	movabsq	$0x257830207463656a, %rax # imm = 0x257830207463656A
    11bc:      	movq	%rax, 0x48(%rsp)
    11c1:      	movabsq	$0x624f656d61724679, %rax # imm = 0x624F656D61724679
    11cb:      	movq	%rax, 0x40(%rsp)
    11d0:      	movabsq	$0x502064616572206f, %rax # imm = 0x502064616572206F
    11da:      	movq	%rax, 0x38(%rsp)
    11df:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    11e9:      	movq	%rax, 0x30(%rsp)
    11ee:      	movl	$0xa786c, 0x50(%rsp)    # imm = 0xA786C
    11f6:      	leaq	0x30(%rsp), %rdi
    11fb:      	movl	$0x24, %eax
    1200:      	movl	$0x6, %ecx
    1205:      	movl	$0x24, %esi
    120a:      	movq	%r13, %rdx
    120d:      	xorl	%eax, %eax
    120f:      	callq	*%rcx
    1211:      	jmp	0xfe <kprobe_unwind_python+0xfe>
    1216:      	movq	(%rsp), %rax
    121a:      	movzbl	0x19(%rax), %ecx
    121e:      	movq	0x70(%rsp), %rdx
    1223:      	movq	(%rdx,%rcx), %rcx
    1227:      	movq	%rcx, 0x28(%rsp)
    122c:      	movzbl	0x18(%rax), %ecx
    1230:      	movq	(%rdx,%rcx), %r13
    1234:      	movq	0x8(%rax), %rax
    1238:      	testq	%rax, %rax
    123b:      	je	0x134f <kprobe_unwind_python+0x134f>
    1241:      	cmpq	%rax, 0x28(%rsp)
    1246:      	jne	0x134f <kprobe_unwind_python+0x134f>
    124c:      	movq	%r13, %rdi
    124f:      	movq	0x8(%rsp), %rbx
    1254:      	jmp	0x1ba <kprobe_unwind_python+0x1ba>
    1259:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1263:      	movq	%rax, 0x56(%rsp)
    1268:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1272:      	movq	%rax, 0x50(%rsp)
    1277:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1281:      	movq	%rax, 0x48(%rsp)
    1286:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1290:      	movq	%rax, 0x40(%rsp)
    1295:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    129f:      	movq	%rax, 0x38(%rsp)
    12a4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    12ae:      	movq	%rax, 0x30(%rsp)
    12b3:      	leaq	0x30(%rsp), %rdi
    12b8:      	movl	$0x2e, %eax
    12bd:      	movl	$0x6, %ecx
    12c2:      	movl	0x7c(%rsp), %edx
    12c6:      	movl	$0x2e, %esi
    12cb:      	xorl	%eax, %eax
    12cd:      	callq	*%rcx
    12cf:      	jmp	0x7a6 <kprobe_unwind_python+0x7a6>
    12d4:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    12de:      	movq	%rax, 0x56(%rsp)
    12e3:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    12ed:      	movq	%rax, 0x50(%rsp)
    12f2:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    12fc:      	movq	%rax, 0x48(%rsp)
    1301:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    130b:      	movq	%rax, 0x40(%rsp)
    1310:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    131a:      	movq	%rax, 0x38(%rsp)
    131f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1329:      	movq	%rax, 0x30(%rsp)
    132e:      	leaq	0x30(%rsp), %rdi
    1333:      	movl	$0x2e, %eax
    1338:      	movl	$0x6, %ecx
    133d:      	movl	0x18(%rsp), %edx
    1341:      	movl	$0x2e, %esi
    1346:      	xorl	%eax, %eax
    1348:      	callq	*%rcx
    134a:      	jmp	0x7d5 <kprobe_unwind_python+0x7d5>
    134f:      	movq	(%rsp), %rax
    1353:      	cmpb	$0x0, 0x22(%rax)
    1357:      	movzbl	0x1a(%rax), %eax
    135b:      	je	0x14ad <kprobe_unwind_python+0x14ad>
    1361:      	movq	0x70(%rsp), %rsi
    1366:      	movq	(%rsi,%rax), %rax
    136a:      	movq	(%rsp), %rcx
    136e:      	movzbl	0x21(%rcx), %edx
    1372:      	addq	0x28(%rsp), %rdx
    1377:      	subq	%rdx, %rax
    137a:      	leaq	-0x10000001(%rax), %rdx
    1381:      	sarl	%eax
    1383:      	cmpq	$-0x10000003, %rdx      # imm = 0xEFFFFFFD
    138a:      	movl	$0xffffffff, %r12d      # imm = 0xFFFFFFFF
    1390:      	cmovael	%eax, %r12d
    1394:      	movzbl	0x1b(%rcx), %eax
    1398:      	movzbl	(%rsi,%rax), %eax
    139c:      	cmpb	0x1c(%rcx), %al
    139f:      	sete	%bl
    13a2:      	jmp	0x14b8 <kprobe_unwind_python+0x14b8>
    13a7:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    13b1:      	movq	%rax, 0x56(%rsp)
    13b6:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    13c0:      	movq	%rax, 0x50(%rsp)
    13c5:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    13cf:      	movq	%rax, 0x48(%rsp)
    13d4:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    13de:      	movq	%rax, 0x40(%rsp)
    13e3:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    13ed:      	movq	%rax, 0x38(%rsp)
    13f2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    13fc:      	movq	%rax, 0x30(%rsp)
    1401:      	leaq	0x30(%rsp), %rdi
    1406:      	movl	$0x2e, %eax
    140b:      	movl	$0x6, %ecx
    1410:      	movl	0x18(%rsp), %edx
    1414:      	movl	$0x2e, %esi
    1419:      	xorl	%eax, %eax
    141b:      	callq	*%rcx
    141d:      	xorl	%ecx, %ecx
    141f:      	movq	0x10(%rsp), %rsi
    1424:      	jmp	0x1ec <kprobe_unwind_python+0x1ec>
    1429:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    1433:      	movq	%rax, 0x55(%rsp)
    1438:      	movabsq	$0x783020746120656d, %rax # imm = 0x783020746120656D
    1442:      	movq	%rax, 0x50(%rsp)
    1447:      	movabsq	$0x6172662e65746174, %rax # imm = 0x6172662E65746174
    1451:      	movq	%rax, 0x48(%rsp)
    1456:      	movabsq	$0x5364616572685479, %rax # imm = 0x5364616572685479
    1460:      	movq	%rax, 0x40(%rsp)
    1465:      	movabsq	$0x502064616572206f, %rax # imm = 0x502064616572206F
    146f:      	movq	%rax, 0x38(%rsp)
    1474:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    147e:      	movq	%rax, 0x30(%rsp)
    1483:      	leaq	0x30(%rsp), %rdi
    1488:      	movl	$0x2d, %eax
    148d:      	movl	$0x6, %ecx
    1492:      	movzbl	0x16(%r13), %edx
    1497:      	addq	0x80(%rsp), %rdx
    149f:      	movl	$0x2d, %esi
    14a4:      	xorl	%eax, %eax
    14a6:      	callq	*%rcx
    14a8:      	jmp	0x8f9 <kprobe_unwind_python+0x8f9>
    14ad:      	movq	0x70(%rsp), %rcx
    14b2:      	movl	(%rcx,%rax), %r12d
    14b6:      	xorl	%ebx, %ebx
    14b8:      	cmpq	$0x0, 0x28(%rsp)
    14be:      	je	0x155b <kprobe_unwind_python+0x155b>
    14c4:      	movq	(%rsp), %rax
    14c8:      	cmpb	$-0x44, 0x1d(%rax)
    14cc:      	ja	0x460a <kprobe_unwind_python+0x460a>
    14d2:      	movq	(%rsp), %rax
    14d6:      	cmpb	$-0x44, 0x1e(%rax)
    14da:      	ja	0x460a <kprobe_unwind_python+0x460a>
    14e0:      	movq	(%rsp), %rax
    14e4:      	cmpb	$-0x44, 0x1f(%rax)
    14e8:      	ja	0x460a <kprobe_unwind_python+0x460a>
    14ee:      	movq	(%rsp), %rax
    14f2:      	cmpb	$-0x44, 0x20(%rax)
    14f6:      	ja	0x460a <kprobe_unwind_python+0x460a>
    14fc:      	movl	$0xc0, %eax
    1501:      	movl	$0x70, %ecx
    1506:      	movq	0x28(%rsp), %rdx
    150b:      	movq	%r15, %rdi
    150e:      	movl	$0xc0, %esi
    1513:      	callq	*%rcx
    1515:      	testq	%rax, %rax
    1518:      	jne	0x2bc <kprobe_unwind_python+0x2bc>
    151e:      	movq	(%rsp), %rax
    1522:      	movzbl	0x1d(%rax), %ecx
    1526:      	movl	(%r15,%rcx), %ecx
    152a:      	movzbl	0x1e(%rax), %edx
    152e:      	movl	(%r15,%rdx), %edx
    1532:      	movzbl	0x1f(%rax), %esi
    1536:      	movl	(%r15,%rsi), %esi
    153a:      	movzbl	0x20(%rax), %eax
    153e:      	shll	$0x19, %ecx
    1541:      	shll	$0x12, %edx
    1544:      	addl	%ecx, %edx
    1546:      	shll	$0xa, %esi
    1549:      	addl	%edx, %esi
    154b:      	addl	(%r15,%rax), %esi
    154f:      	shlq	$0x20, %r12
    1553:      	orq	%rsi, %r12
    1556:      	jmp	0x175d <kprobe_unwind_python+0x175d>
    155b:      	cmpl	$0x0, (%r14)
    155f:      	jne	0x1e76 <kprobe_unwind_python+0x1e76>
    1565:      	movl	$0x1c, 0x18(%rsp)
    156d:      	movq	(%rip), %rdi            # 0x1574 <kprobe_unwind_python+0x1574>
    1574:      	leaq	0x18(%rsp), %rsi
    1579:      	movl	$0x1, %eax
    157e:      	callq	*%rax
    1580:      	testq	%rax, %rax
    1583:      	je	0x1745 <kprobe_unwind_python+0x1745>
    1589:      	incq	(%rax)
    158c:      	jmp	0x174f <kprobe_unwind_python+0x174f>
    1591:      	movabsq	$0xa307830207369, %rax  # imm = 0xA307830207369
    159b:      	movq	%rax, 0x3e(%rsp)
    15a0:      	movabsq	$0x7369206574617453, %rax # imm = 0x7369206574617453
    15aa:      	movq	%rax, 0x38(%rsp)
    15af:      	movabsq	$0x6461657268547950, %rax # imm = 0x6461657268547950
    15b9:      	movq	%rax, 0x30(%rsp)
    15be:      	leaq	0x30(%rsp), %rdi
    15c3:      	movl	$0x16, %eax
    15c8:      	movl	$0x6, %ecx
    15cd:      	movl	$0x16, %esi
    15d2:      	xorl	%eax, %eax
    15d4:      	callq	*%rcx
    15d6:      	jmp	0x932 <kprobe_unwind_python+0x932>
    15db:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    15e5:      	movq	%rax, 0x57(%rsp)
    15ea:      	movabsq	$0x20786c2578302074, %rax # imm = 0x20786C2578302074
    15f4:      	movq	%rax, 0x50(%rsp)
    15f9:      	movabsq	$0x63656a624f656d61, %rax # imm = 0x63656A624F656D61
    1603:      	movq	%rax, 0x48(%rsp)
    1608:      	movabsq	$0x7246795020726f66, %rax # imm = 0x7246795020726F66
    1612:      	movq	%rax, 0x40(%rsp)
    1617:      	movabsq	$0x207463656a626f65, %rax # imm = 0x207463656A626F65
    1621:      	movq	%rax, 0x38(%rsp)
    1626:      	movabsq	$0x646f63206c6c754e, %rax # imm = 0x646F63206C6C754E
    1630:      	movq	%rax, 0x30(%rsp)
    1635:      	leaq	0x30(%rsp), %rdi
    163a:      	movl	$0x2f, %eax
    163f:      	movl	$0x6, %r8d
    1645:      	movq	(%rsp), %rax
    1649:      	movzbl	0x19(%rax), %ecx
    164d:      	addq	%r13, %rcx
    1650:      	movl	$0x2f, %esi
    1655:      	movq	%r13, %rdx
    1658:      	xorl	%eax, %eax
    165a:      	callq	*%r8
    165d:      	jmp	0x307 <kprobe_unwind_python+0x307>
    1662:      	movabsq	$0xa6c6c75662073, %rax  # imm = 0xA6C6C75662073
    166c:      	movq	%rax, 0x4d(%rsp)
    1671:      	movabsq	$0x66207369206b6361, %rax # imm = 0x66207369206B6361
    167b:      	movq	%rax, 0x48(%rsp)
    1680:      	movabsq	$0x7473203a656d6172, %rax # imm = 0x7473203A656D6172
    168a:      	movq	%rax, 0x40(%rsp)
    168f:      	movabsq	$0x662068737570206f, %rax # imm = 0x662068737570206F
    1699:      	movq	%rax, 0x38(%rsp)
    169e:      	movabsq	$0x7420656c62616e75, %rax # imm = 0x7420656C62616E75
    16a8:      	movq	%rax, 0x30(%rsp)
    16ad:      	leaq	0x30(%rsp), %rdi
    16b2:      	movl	$0x25, %eax
    16b7:      	movl	$0x6, %ecx
    16bc:      	movl	$0x25, %esi
    16c1:      	xorl	%eax, %eax
    16c3:      	callq	*%rcx
    16c5:      	jmp	0x369 <kprobe_unwind_python+0x369>
    16ca:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    16d4:      	movq	%rax, 0x56(%rsp)
    16d9:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    16e3:      	movq	%rax, 0x50(%rsp)
    16e8:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    16f2:      	movq	%rax, 0x48(%rsp)
    16f7:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1701:      	movq	%rax, 0x40(%rsp)
    1706:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1710:      	movq	%rax, 0x38(%rsp)
    1715:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    171f:      	movq	%rax, 0x30(%rsp)
    1724:      	leaq	0x30(%rsp), %rdi
    1729:      	movl	$0x2e, %eax
    172e:      	movl	$0x6, %ecx
    1733:      	movl	0x18(%rsp), %edx
    1737:      	movl	$0x2e, %esi
    173c:      	xorl	%eax, %eax
    173e:      	callq	*%rcx
    1740:      	jmp	0x9da <kprobe_unwind_python+0x9da>
    1745:      	cmpl	$0x0, (%r14)
    1749:      	jne	0x1f40 <kprobe_unwind_python+0x1f40>
    174f:      	movq	$-0x2, %r12
    1756:      	xorl	%eax, %eax
    1758:      	movq	%rax, 0x28(%rsp)
    175d:      	cmpl	$0x0, (%r14)
    1761:      	jne	0x1be7 <kprobe_unwind_python+0x1be7>
    1767:      	movl	0x2c0(%rbp), %eax
    176d:      	cmpq	$0x7e, %rax
    1771:      	jbe	0x1c46 <kprobe_unwind_python+0x1c46>
    1777:      	movq	0x8(%rsp), %rbx
    177c:      	jmp	0x35f <kprobe_unwind_python+0x35f>
    1781:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    178b:      	movq	%rax, 0x56(%rsp)
    1790:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    179a:      	movq	%rax, 0x50(%rsp)
    179f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    17a9:      	movq	%rax, 0x48(%rsp)
    17ae:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    17b8:      	movq	%rax, 0x40(%rsp)
    17bd:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    17c7:      	movq	%rax, 0x38(%rsp)
    17cc:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    17d6:      	movq	%rax, 0x30(%rsp)
    17db:      	leaq	0x30(%rsp), %rdi
    17e0:      	movl	$0x2e, %eax
    17e5:      	movl	$0x6, %ecx
    17ea:      	movl	0x18(%rsp), %edx
    17ee:      	movl	$0x2e, %esi
    17f3:      	xorl	%eax, %eax
    17f5:      	callq	*%rcx
    17f7:      	jmp	0xa25 <kprobe_unwind_python+0xa25>
    17fc:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1806:      	movq	%rax, 0x56(%rsp)
    180b:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1815:      	movq	%rax, 0x50(%rsp)
    181a:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1824:      	movq	%rax, 0x48(%rsp)
    1829:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1833:      	movq	%rax, 0x40(%rsp)
    1838:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1842:      	movq	%rax, 0x38(%rsp)
    1847:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1851:      	movq	%rax, 0x30(%rsp)
    1856:      	leaq	0x30(%rsp), %rdi
    185b:      	movl	$0x2e, %eax
    1860:      	movl	$0x6, %ecx
    1865:      	movl	0x18(%rsp), %edx
    1869:      	movl	$0x2e, %esi
    186e:      	xorl	%eax, %eax
    1870:      	callq	*%rcx
    1872:      	jmp	0x32a <kprobe_unwind_python+0x32a>
    1877:      	movabsq	$0xa786c2578302074, %rcx # imm = 0xA786C2578302074
    1881:      	movq	%rcx, 0x58(%rsp)
    1886:      	movabsq	$0x6120656d6172665f, %rcx # imm = 0x6120656D6172665F
    1890:      	movq	%rcx, 0x50(%rsp)
    1895:      	movabsq	$0x746e65727275632e, %rcx # imm = 0x746E65727275632E
    189f:      	movq	%rcx, 0x48(%rsp)
    18a4:      	movabsq	$0x656d617246437950, %rcx # imm = 0x656D617246437950
    18ae:      	movq	%rcx, 0x40(%rsp)
    18b3:      	movabsq	$0x5f2064616572206f, %rcx # imm = 0x5F2064616572206F
    18bd:      	movq	%rcx, 0x38(%rsp)
    18c2:      	movabsq	$0x742064656c696146, %rcx # imm = 0x742064656C696146
    18cc:      	movq	%rcx, 0x30(%rsp)
    18d1:      	movb	$0x0, 0x60(%rsp)
    18d6:      	leaq	0x30(%rsp), %rdi
    18db:      	movl	$0x31, %ecx
    18e0:      	movl	$0x6, %r8d
    18e6:      	movzbl	0x17(%rax), %edx
    18ea:      	movq	0x10(%rsp), %rax
    18ef:      	addq	(%rax), %rdx
    18f2:      	movl	$0x31, %esi
    18f7:      	xorl	%eax, %eax
    18f9:      	callq	*%r8
    18fc:      	jmp	0x9ab <kprobe_unwind_python+0x9ab>
    1901:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    190b:      	movq	%rax, 0x56(%rsp)
    1910:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    191a:      	movq	%rax, 0x50(%rsp)
    191f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1929:      	movq	%rax, 0x48(%rsp)
    192e:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1938:      	movq	%rax, 0x40(%rsp)
    193d:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1947:      	movq	%rax, 0x38(%rsp)
    194c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1956:      	movq	%rax, 0x30(%rsp)
    195b:      	leaq	0x30(%rsp), %rdi
    1960:      	movl	$0x2e, %eax
    1965:      	movl	$0x6, %ecx
    196a:      	movl	0x18(%rsp), %edx
    196e:      	movl	$0x2e, %esi
    1973:      	xorl	%eax, %eax
    1975:      	callq	*%rcx
    1977:      	xorl	%ecx, %ecx
    1979:      	movq	0x10(%rsp), %rsi
    197e:      	cmpl	$0x0, (%r14)
    1982:      	movl	$0x2, %r12d
    1988:      	je	0x16f <kprobe_unwind_python+0x16f>
    198e:      	jmp	0x3a7 <kprobe_unwind_python+0x3a7>
    1993:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    199d:      	movq	%rax, 0x56(%rsp)
    19a2:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    19ac:      	movq	%rax, 0x50(%rsp)
    19b1:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    19bb:      	movq	%rax, 0x48(%rsp)
    19c0:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    19ca:      	movq	%rax, 0x40(%rsp)
    19cf:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    19d9:      	movq	%rax, 0x38(%rsp)
    19de:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    19e8:      	movq	%rax, 0x30(%rsp)
    19ed:      	leaq	0x30(%rsp), %rdi
    19f2:      	movl	$0x2e, %eax
    19f7:      	movl	$0x6, %ecx
    19fc:      	movl	0x18(%rsp), %edx
    1a00:      	movl	$0x2e, %esi
    1a05:      	xorl	%eax, %eax
    1a07:      	movl	%r8d, %r12d
    1a0a:      	callq	*%rcx
    1a0c:      	movl	%r12d, %r8d
    1a0f:      	movq	0x10(%rsp), %rsi
    1a14:      	movq	(%rsp), %rax
    1a18:      	testb	%r8b, %r8b
    1a1b:      	movq	0x20(%rsp), %rdi
    1a20:      	jne	0x1bf <kprobe_unwind_python+0x1bf>
    1a26:      	jmp	0xc19 <kprobe_unwind_python+0xc19>
    1a2b:      	movabsq	$0xa64656c646e61, %rax  # imm = 0xA64656C646E61
    1a35:      	movq	%rax, 0x48(%rsp)
    1a3a:      	movabsq	$0x6820657261207365, %rax # imm = 0x6820657261207365
    1a44:      	movq	%rax, 0x40(%rsp)
    1a49:      	movabsq	$0x6d617266206e6f68, %rax # imm = 0x6D617266206E6F68
    1a53:      	movq	%rax, 0x38(%rsp)
    1a58:      	movabsq	$0x747950203e2d2020, %rax # imm = 0x747950203E2D2020
    1a62:      	movq	%rax, 0x30(%rsp)
    1a67:      	leaq	0x30(%rsp), %rdi
    1a6c:      	movl	$0x20, %eax
    1a71:      	movl	$0x6, %ecx
    1a76:      	movl	$0x20, %esi
    1a7b:      	xorl	%eax, %eax
    1a7d:      	callq	*%rcx
    1a7f:      	jmp	0xa06 <kprobe_unwind_python+0xa06>
    1a84:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1a8e:      	movq	%rax, 0x56(%rsp)
    1a93:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1a9d:      	movq	%rax, 0x50(%rsp)
    1aa2:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1aac:      	movq	%rax, 0x48(%rsp)
    1ab1:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1abb:      	movq	%rax, 0x40(%rsp)
    1ac0:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1aca:      	movq	%rax, 0x38(%rsp)
    1acf:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1ad9:      	movq	%rax, 0x30(%rsp)
    1ade:      	leaq	0x30(%rsp), %rdi
    1ae3:      	movl	$0x2e, %eax
    1ae8:      	movl	$0x6, %ecx
    1aed:      	movl	0x18(%rsp), %edx
    1af1:      	movl	$0x2e, %esi
    1af6:      	xorl	%eax, %eax
    1af8:      	callq	*%rcx
    1afa:      	jmp	0xa40 <kprobe_unwind_python+0xa40>
    1aff:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    1b09:      	movq	%rax, 0x4e(%rsp)
    1b0e:      	movabsq	$0x3020746120746365, %rax # imm = 0x3020746120746365
    1b18:      	movq	%rax, 0x48(%rsp)
    1b1d:      	movabsq	$0x6a624f65646f4379, %rax # imm = 0x6A624F65646F4379
    1b27:      	movq	%rax, 0x40(%rsp)
    1b2c:      	movabsq	$0x502064616572206f, %rax # imm = 0x502064616572206F
    1b36:      	movq	%rax, 0x38(%rsp)
    1b3b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1b45:      	movq	%rax, 0x30(%rsp)
    1b4a:      	leaq	0x30(%rsp), %rdi
    1b4f:      	movl	$0x26, %eax
    1b54:      	movl	$0x6, %ecx
    1b59:      	movl	$0x26, %esi
    1b5e:      	movq	0x28(%rsp), %rdx
    1b63:      	xorl	%eax, %eax
    1b65:      	callq	*%rcx
    1b67:      	jmp	0x2c9 <kprobe_unwind_python+0x2c9>
    1b6c:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1b76:      	movq	%rax, 0x56(%rsp)
    1b7b:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1b85:      	movq	%rax, 0x50(%rsp)
    1b8a:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1b94:      	movq	%rax, 0x48(%rsp)
    1b99:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1ba3:      	movq	%rax, 0x40(%rsp)
    1ba8:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1bb2:      	movq	%rax, 0x38(%rsp)
    1bb7:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1bc1:      	movq	%rax, 0x30(%rsp)
    1bc6:      	leaq	0x30(%rsp), %rdi
    1bcb:      	movl	$0x2e, %eax
    1bd0:      	movl	$0x6, %ecx
    1bd5:      	movl	0x18(%rsp), %edx
    1bd9:      	movl	$0x2e, %esi
    1bde:      	xorl	%eax, %eax
    1be0:      	callq	*%rcx
    1be2:      	jmp	0xd78 <kprobe_unwind_python+0xd78>
    1be7:      	movabsq	$0xa756c2520786c, %rax  # imm = 0xA756C2520786C
    1bf1:      	movq	%rax, 0x40(%rsp)
    1bf6:      	movabsq	$0x25206e6f68747950, %rax # imm = 0x25206E6F68747950
    1c00:      	movq	%rax, 0x38(%rsp)
    1c05:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    1c0f:      	movq	%rax, 0x30(%rsp)
    1c14:      	leaq	0x30(%rsp), %rdi
    1c19:      	movl	$0x18, %eax
    1c1e:      	movl	$0x6, %r8d
    1c24:      	movl	$0x18, %esi
    1c29:      	movq	0x28(%rsp), %rdx
    1c2e:      	movq	%r12, %rcx
    1c31:      	xorl	%eax, %eax
    1c33:      	callq	*%r8
    1c36:      	movl	0x2c0(%rbp), %eax
    1c3c:      	cmpq	$0x7e, %rax
    1c40:      	ja	0x1777 <kprobe_unwind_python+0x1777>
    1c46:      	leal	0x1(%rax), %ecx
    1c49:      	movl	%ecx, 0x2c0(%rbp)
    1c4f:      	leaq	(%rax,%rax,2), %rax
    1c53:      	movq	0x28(%rsp), %rcx
    1c58:      	movq	%rcx, 0x2d0(%rbp,%rax,8)
    1c60:      	movq	%r12, 0x2d8(%rbp,%rax,8)
    1c68:      	movb	$0x1, 0x2e0(%rbp,%rax,8)
    1c70:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    1c7b:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    1c86:      	movl	$0x16, 0x18(%rsp)
    1c8e:      	movq	(%rip), %rdi            # 0x1c95 <kprobe_unwind_python+0x1c95>
    1c95:      	leaq	0x18(%rsp), %rsi
    1c9a:      	movl	$0x1, %eax
    1c9f:      	callq	*%rax
    1ca1:      	testq	%rax, %rax
    1ca4:      	je	0x1cb3 <kprobe_unwind_python+0x1cb3>
    1ca6:      	incq	(%rax)
    1ca9:      	testb	%bl, %bl
    1cab:      	jne	0x124c <kprobe_unwind_python+0x124c>
    1cb1:      	jmp	0x1cc5 <kprobe_unwind_python+0x1cc5>
    1cb3:      	cmpl	$0x0, (%r14)
    1cb7:      	jne	0x1fbb <kprobe_unwind_python+0x1fbb>
    1cbd:      	testb	%bl, %bl
    1cbf:      	jne	0x124c <kprobe_unwind_python+0x124c>
    1cc5:      	xorl	%r12d, %r12d
    1cc8:      	testq	%r13, %r13
    1ccb:      	je	0x45be <kprobe_unwind_python+0x45be>
    1cd1:      	movq	(%rsp), %rax
    1cd5:      	cmpb	$0x78, 0x19(%rax)
    1cd9:      	ja	0x460a <kprobe_unwind_python+0x460a>
    1cdf:      	movq	(%rsp), %rax
    1ce3:      	cmpb	$0x78, 0x18(%rax)
    1ce7:      	ja	0x460a <kprobe_unwind_python+0x460a>
    1ced:      	movq	(%rsp), %rax
    1cf1:      	cmpb	$0x78, 0x1a(%rax)
    1cf5:      	ja	0x460a <kprobe_unwind_python+0x460a>
    1cfb:      	movq	(%rsp), %rax
    1cff:      	cmpb	$0x0, 0x1b(%rax)
    1d03:      	js	0x460a <kprobe_unwind_python+0x460a>
    1d09:      	movl	$0x80, %eax
    1d0e:      	movl	$0x70, %ecx
    1d13:      	movq	0x70(%rsp), %rdi
    1d18:      	movl	$0x80, %esi
    1d1d:      	movq	%r13, %rdx
    1d20:      	callq	*%rcx
    1d22:      	testq	%rax, %rax
    1d25:      	je	0x1d31 <kprobe_unwind_python+0x1d31>
    1d27:      	movq	0x8(%rsp), %rbx
    1d2c:      	jmp	0xf4 <kprobe_unwind_python+0xf4>
    1d31:      	movq	(%rsp), %rax
    1d35:      	movzbl	0x19(%rax), %ecx
    1d39:      	movq	0x70(%rsp), %rdx
    1d3e:      	movq	(%rdx,%rcx), %rcx
    1d42:      	movq	%rcx, 0x28(%rsp)
    1d47:      	movzbl	0x18(%rax), %ecx
    1d4b:      	movq	(%rdx,%rcx), %rcx
    1d4f:      	movq	%rcx, 0x20(%rsp)
    1d54:      	movq	0x8(%rax), %rax
    1d58:      	testq	%rax, %rax
    1d5b:      	je	0x1d78 <kprobe_unwind_python+0x1d78>
    1d5d:      	cmpq	%rax, 0x28(%rsp)
    1d62:      	jne	0x1d78 <kprobe_unwind_python+0x1d78>
    1d64:      	movq	0x8(%rsp), %rbx
    1d69:      	movq	0x10(%rsp), %rsi
    1d6e:      	movq	0x20(%rsp), %rdi
    1d73:      	jmp	0x1bf <kprobe_unwind_python+0x1bf>
    1d78:      	movq	(%rsp), %rax
    1d7c:      	cmpb	$0x0, 0x22(%rax)
    1d80:      	movzbl	0x1a(%rax), %eax
    1d84:      	je	0x1dc9 <kprobe_unwind_python+0x1dc9>
    1d86:      	movq	0x70(%rsp), %rsi
    1d8b:      	movq	(%rsi,%rax), %rax
    1d8f:      	movq	(%rsp), %rcx
    1d93:      	movzbl	0x21(%rcx), %edx
    1d97:      	addq	0x28(%rsp), %rdx
    1d9c:      	subq	%rdx, %rax
    1d9f:      	leaq	-0x10000001(%rax), %rdx
    1da6:      	sarl	%eax
    1da8:      	cmpq	$-0x10000003, %rdx      # imm = 0xEFFFFFFD
    1daf:      	movl	$0xffffffff, %r12d      # imm = 0xFFFFFFFF
    1db5:      	cmovael	%eax, %r12d
    1db9:      	movzbl	0x1b(%rcx), %eax
    1dbd:      	movzbl	(%rsi,%rax), %eax
    1dc1:      	cmpb	0x1c(%rcx), %al
    1dc4:      	sete	%bl
    1dc7:      	jmp	0x1dd4 <kprobe_unwind_python+0x1dd4>
    1dc9:      	movq	0x70(%rsp), %rcx
    1dce:      	movl	(%rcx,%rax), %r12d
    1dd2:      	xorl	%ebx, %ebx
    1dd4:      	cmpq	$0x0, 0x28(%rsp)
    1dda:      	je	0x1e40 <kprobe_unwind_python+0x1e40>
    1ddc:      	movq	(%rsp), %rax
    1de0:      	cmpb	$-0x44, 0x1d(%rax)
    1de4:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    1dea:      	movq	(%rsp), %rax
    1dee:      	cmpb	$-0x44, 0x1e(%rax)
    1df2:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    1df8:      	movq	(%rsp), %rax
    1dfc:      	cmpb	$-0x44, 0x1f(%rax)
    1e00:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    1e06:      	movq	(%rsp), %rax
    1e0a:      	cmpb	$-0x44, 0x20(%rax)
    1e0e:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    1e14:      	movl	$0xc0, %eax
    1e19:      	movl	$0x70, %ecx
    1e1e:      	movq	0x28(%rsp), %rdx
    1e23:      	movq	%r15, %rdi
    1e26:      	movl	$0xc0, %esi
    1e2b:      	callq	*%rcx
    1e2d:      	testq	%rax, %rax
    1e30:      	je	0x203e <kprobe_unwind_python+0x203e>
    1e36:      	movq	0x20(%rsp), %r13
    1e3b:      	jmp	0x2bc <kprobe_unwind_python+0x2bc>
    1e40:      	cmpl	$0x0, (%r14)
    1e44:      	jne	0x2330 <kprobe_unwind_python+0x2330>
    1e4a:      	movl	$0x1c, 0x18(%rsp)
    1e52:      	movq	(%rip), %rdi            # 0x1e59 <kprobe_unwind_python+0x1e59>
    1e59:      	leaq	0x18(%rsp), %rsi
    1e5e:      	movl	$0x1, %eax
    1e63:      	callq	*%rax
    1e65:      	testq	%rax, %rax
    1e68:      	je	0x1eff <kprobe_unwind_python+0x1eff>
    1e6e:      	incq	(%rax)
    1e71:      	jmp	0x1f09 <kprobe_unwind_python+0x1f09>
    1e76:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    1e80:      	movq	%rax, 0x57(%rsp)
    1e85:      	movabsq	$0x20786c2578302074, %rax # imm = 0x20786C2578302074
    1e8f:      	movq	%rax, 0x50(%rsp)
    1e94:      	movabsq	$0x63656a624f656d61, %rax # imm = 0x63656A624F656D61
    1e9e:      	movq	%rax, 0x48(%rsp)
    1ea3:      	movabsq	$0x7246795020726f66, %rax # imm = 0x7246795020726F66
    1ead:      	movq	%rax, 0x40(%rsp)
    1eb2:      	movabsq	$0x207463656a626f65, %rax # imm = 0x207463656A626F65
    1ebc:      	movq	%rax, 0x38(%rsp)
    1ec1:      	movabsq	$0x646f63206c6c754e, %rax # imm = 0x646F63206C6C754E
    1ecb:      	movq	%rax, 0x30(%rsp)
    1ed0:      	leaq	0x30(%rsp), %rdi
    1ed5:      	movl	$0x2f, %eax
    1eda:      	movl	$0x6, %r8d
    1ee0:      	movq	(%rsp), %rax
    1ee4:      	movzbl	0x19(%rax), %ecx
    1ee8:      	movq	0x20(%rsp), %rdx
    1eed:      	addq	%rdx, %rcx
    1ef0:      	movl	$0x2f, %esi
    1ef5:      	xorl	%eax, %eax
    1ef7:      	callq	*%r8
    1efa:      	jmp	0x1565 <kprobe_unwind_python+0x1565>
    1eff:      	cmpl	$0x0, (%r14)
    1f03:      	jne	0x245d <kprobe_unwind_python+0x245d>
    1f09:      	movq	$-0x2, %r12
    1f10:      	xorl	%eax, %eax
    1f12:      	movq	%rax, 0x28(%rsp)
    1f17:      	cmpl	$0x0, (%r14)
    1f1b:      	jne	0x2080 <kprobe_unwind_python+0x2080>
    1f21:      	movl	0x2c0(%rbp), %eax
    1f27:      	cmpq	$0x7e, %rax
    1f2b:      	jbe	0x20df <kprobe_unwind_python+0x20df>
    1f31:      	movq	0x20(%rsp), %r13
    1f36:      	movq	0x8(%rsp), %rbx
    1f3b:      	jmp	0x35f <kprobe_unwind_python+0x35f>
    1f40:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1f4a:      	movq	%rax, 0x56(%rsp)
    1f4f:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1f59:      	movq	%rax, 0x50(%rsp)
    1f5e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1f68:      	movq	%rax, 0x48(%rsp)
    1f6d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1f77:      	movq	%rax, 0x40(%rsp)
    1f7c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1f86:      	movq	%rax, 0x38(%rsp)
    1f8b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1f95:      	movq	%rax, 0x30(%rsp)
    1f9a:      	leaq	0x30(%rsp), %rdi
    1f9f:      	movl	$0x2e, %eax
    1fa4:      	movl	$0x6, %ecx
    1fa9:      	movl	0x18(%rsp), %edx
    1fad:      	movl	$0x2e, %esi
    1fb2:      	xorl	%eax, %eax
    1fb4:      	callq	*%rcx
    1fb6:      	jmp	0x174f <kprobe_unwind_python+0x174f>
    1fbb:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1fc5:      	movq	%rax, 0x56(%rsp)
    1fca:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1fd4:      	movq	%rax, 0x50(%rsp)
    1fd9:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1fe3:      	movq	%rax, 0x48(%rsp)
    1fe8:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1ff2:      	movq	%rax, 0x40(%rsp)
    1ff7:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2001:      	movq	%rax, 0x38(%rsp)
    2006:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2010:      	movq	%rax, 0x30(%rsp)
    2015:      	leaq	0x30(%rsp), %rdi
    201a:      	movl	$0x2e, %eax
    201f:      	movl	$0x6, %ecx
    2024:      	movl	0x18(%rsp), %edx
    2028:      	movl	$0x2e, %esi
    202d:      	xorl	%eax, %eax
    202f:      	callq	*%rcx
    2031:      	testb	%bl, %bl
    2033:      	jne	0x124c <kprobe_unwind_python+0x124c>
    2039:      	jmp	0x1cc5 <kprobe_unwind_python+0x1cc5>
    203e:      	movq	(%rsp), %rax
    2042:      	movzbl	0x1d(%rax), %ecx
    2046:      	movl	(%r15,%rcx), %ecx
    204a:      	movzbl	0x1e(%rax), %edx
    204e:      	movl	(%r15,%rdx), %edx
    2052:      	movzbl	0x1f(%rax), %esi
    2056:      	movl	(%r15,%rsi), %esi
    205a:      	movzbl	0x20(%rax), %eax
    205e:      	shll	$0x19, %ecx
    2061:      	shll	$0x12, %edx
    2064:      	addl	%ecx, %edx
    2066:      	shll	$0xa, %esi
    2069:      	addl	%edx, %esi
    206b:      	addl	(%r15,%rax), %esi
    206f:      	shlq	$0x20, %r12
    2073:      	orq	%rsi, %r12
    2076:      	cmpl	$0x0, (%r14)
    207a:      	je	0x1f21 <kprobe_unwind_python+0x1f21>
    2080:      	movabsq	$0xa756c2520786c, %rax  # imm = 0xA756C2520786C
    208a:      	movq	%rax, 0x40(%rsp)
    208f:      	movabsq	$0x25206e6f68747950, %rax # imm = 0x25206E6F68747950
    2099:      	movq	%rax, 0x38(%rsp)
    209e:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    20a8:      	movq	%rax, 0x30(%rsp)
    20ad:      	leaq	0x30(%rsp), %rdi
    20b2:      	movl	$0x18, %eax
    20b7:      	movl	$0x6, %r8d
    20bd:      	movl	$0x18, %esi
    20c2:      	movq	0x28(%rsp), %rdx
    20c7:      	movq	%r12, %rcx
    20ca:      	xorl	%eax, %eax
    20cc:      	callq	*%r8
    20cf:      	movl	0x2c0(%rbp), %eax
    20d5:      	cmpq	$0x7e, %rax
    20d9:      	ja	0x1f31 <kprobe_unwind_python+0x1f31>
    20df:      	leal	0x1(%rax), %ecx
    20e2:      	movl	%ecx, 0x2c0(%rbp)
    20e8:      	leaq	(%rax,%rax,2), %rax
    20ec:      	movq	0x28(%rsp), %rcx
    20f1:      	movq	%rcx, 0x2d0(%rbp,%rax,8)
    20f9:      	movq	%r12, 0x2d8(%rbp,%rax,8)
    2101:      	movb	$0x1, 0x2e0(%rbp,%rax,8)
    2109:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    2114:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    211f:      	movl	$0x16, 0x18(%rsp)
    2127:      	movq	(%rip), %rdi            # 0x212e <kprobe_unwind_python+0x212e>
    212e:      	leaq	0x18(%rsp), %rsi
    2133:      	movl	$0x1, %eax
    2138:      	callq	*%rax
    213a:      	testq	%rax, %rax
    213d:      	je	0x214c <kprobe_unwind_python+0x214c>
    213f:      	incq	(%rax)
    2142:      	testb	%bl, %bl
    2144:      	jne	0x1d64 <kprobe_unwind_python+0x1d64>
    214a:      	jmp	0x215e <kprobe_unwind_python+0x215e>
    214c:      	cmpl	$0x0, (%r14)
    2150:      	jne	0x25df <kprobe_unwind_python+0x25df>
    2156:      	testb	%bl, %bl
    2158:      	jne	0x1d64 <kprobe_unwind_python+0x1d64>
    215e:      	xorl	%r12d, %r12d
    2161:      	cmpq	$0x0, 0x20(%rsp)
    2167:      	je	0x45be <kprobe_unwind_python+0x45be>
    216d:      	movq	(%rsp), %rax
    2171:      	cmpb	$0x78, 0x19(%rax)
    2175:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    217b:      	movq	(%rsp), %rax
    217f:      	cmpb	$0x78, 0x18(%rax)
    2183:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    2189:      	movq	(%rsp), %rax
    218d:      	cmpb	$0x78, 0x1a(%rax)
    2191:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    2197:      	movq	(%rsp), %rax
    219b:      	cmpb	$0x0, 0x1b(%rax)
    219f:      	js	0x45a2 <kprobe_unwind_python+0x45a2>
    21a5:      	movl	$0x80, %eax
    21aa:      	movl	$0x70, %ecx
    21af:      	movq	0x70(%rsp), %rdi
    21b4:      	movq	0x20(%rsp), %rdx
    21b9:      	movl	$0x80, %esi
    21be:      	callq	*%rcx
    21c0:      	testq	%rax, %rax
    21c3:      	jne	0xd60 <kprobe_unwind_python+0xd60>
    21c9:      	movq	(%rsp), %rax
    21cd:      	movzbl	0x19(%rax), %ecx
    21d1:      	movq	0x70(%rsp), %rdx
    21d6:      	movq	(%rdx,%rcx), %rcx
    21da:      	movq	%rcx, 0x28(%rsp)
    21df:      	movzbl	0x18(%rax), %ecx
    21e3:      	movq	(%rdx,%rcx), %r13
    21e7:      	movq	0x8(%rax), %rax
    21eb:      	testq	%rax, %rax
    21ee:      	je	0x21fb <kprobe_unwind_python+0x21fb>
    21f0:      	cmpq	%rax, 0x28(%rsp)
    21f5:      	je	0x124c <kprobe_unwind_python+0x124c>
    21fb:      	movq	(%rsp), %rax
    21ff:      	cmpb	$0x0, 0x22(%rax)
    2203:      	movzbl	0x1a(%rax), %eax
    2207:      	je	0x224c <kprobe_unwind_python+0x224c>
    2209:      	movq	0x70(%rsp), %rsi
    220e:      	movq	(%rsi,%rax), %rax
    2212:      	movq	(%rsp), %rcx
    2216:      	movzbl	0x21(%rcx), %edx
    221a:      	addq	0x28(%rsp), %rdx
    221f:      	subq	%rdx, %rax
    2222:      	leaq	-0x10000001(%rax), %rdx
    2229:      	sarl	%eax
    222b:      	cmpq	$-0x10000003, %rdx      # imm = 0xEFFFFFFD
    2232:      	movl	$0xffffffff, %r12d      # imm = 0xFFFFFFFF
    2238:      	cmovael	%eax, %r12d
    223c:      	movzbl	0x1b(%rcx), %eax
    2240:      	movzbl	(%rsi,%rax), %eax
    2244:      	cmpb	0x1c(%rcx), %al
    2247:      	sete	%bl
    224a:      	jmp	0x2257 <kprobe_unwind_python+0x2257>
    224c:      	movq	0x70(%rsp), %rcx
    2251:      	movl	(%rcx,%rax), %r12d
    2255:      	xorl	%ebx, %ebx
    2257:      	cmpq	$0x0, 0x28(%rsp)
    225d:      	je	0x22fa <kprobe_unwind_python+0x22fa>
    2263:      	movq	(%rsp), %rax
    2267:      	cmpb	$-0x44, 0x1d(%rax)
    226b:      	ja	0x460a <kprobe_unwind_python+0x460a>
    2271:      	movq	(%rsp), %rax
    2275:      	cmpb	$-0x44, 0x1e(%rax)
    2279:      	ja	0x460a <kprobe_unwind_python+0x460a>
    227f:      	movq	(%rsp), %rax
    2283:      	cmpb	$-0x44, 0x1f(%rax)
    2287:      	ja	0x460a <kprobe_unwind_python+0x460a>
    228d:      	movq	(%rsp), %rax
    2291:      	cmpb	$-0x44, 0x20(%rax)
    2295:      	ja	0x460a <kprobe_unwind_python+0x460a>
    229b:      	movl	$0xc0, %eax
    22a0:      	movl	$0x70, %ecx
    22a5:      	movq	0x28(%rsp), %rdx
    22aa:      	movq	%r15, %rdi
    22ad:      	movl	$0xc0, %esi
    22b2:      	callq	*%rcx
    22b4:      	testq	%rax, %rax
    22b7:      	jne	0x2bc <kprobe_unwind_python+0x2bc>
    22bd:      	movq	(%rsp), %rax
    22c1:      	movzbl	0x1d(%rax), %ecx
    22c5:      	movl	(%r15,%rcx), %ecx
    22c9:      	movzbl	0x1e(%rax), %edx
    22cd:      	movl	(%r15,%rdx), %edx
    22d1:      	movzbl	0x1f(%rax), %esi
    22d5:      	movl	(%r15,%rsi), %esi
    22d9:      	movzbl	0x20(%rax), %eax
    22dd:      	shll	$0x19, %ecx
    22e0:      	shll	$0x12, %edx
    22e3:      	addl	%ecx, %edx
    22e5:      	shll	$0xa, %esi
    22e8:      	addl	%edx, %esi
    22ea:      	addl	(%r15,%rax), %esi
    22ee:      	shlq	$0x20, %r12
    22f2:      	orq	%rsi, %r12
    22f5:      	jmp	0x23cf <kprobe_unwind_python+0x23cf>
    22fa:      	cmpl	$0x0, (%r14)
    22fe:      	jne	0x27c8 <kprobe_unwind_python+0x27c8>
    2304:      	movl	$0x1c, 0x18(%rsp)
    230c:      	movq	(%rip), %rdi            # 0x2313 <kprobe_unwind_python+0x2313>
    2313:      	leaq	0x18(%rsp), %rsi
    2318:      	movl	$0x1, %eax
    231d:      	callq	*%rax
    231f:      	testq	%rax, %rax
    2322:      	je	0x23b7 <kprobe_unwind_python+0x23b7>
    2328:      	incq	(%rax)
    232b:      	jmp	0x23c1 <kprobe_unwind_python+0x23c1>
    2330:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    233a:      	movq	%rax, 0x57(%rsp)
    233f:      	movabsq	$0x20786c2578302074, %rax # imm = 0x20786C2578302074
    2349:      	movq	%rax, 0x50(%rsp)
    234e:      	movabsq	$0x63656a624f656d61, %rax # imm = 0x63656A624F656D61
    2358:      	movq	%rax, 0x48(%rsp)
    235d:      	movabsq	$0x7246795020726f66, %rax # imm = 0x7246795020726F66
    2367:      	movq	%rax, 0x40(%rsp)
    236c:      	movabsq	$0x207463656a626f65, %rax # imm = 0x207463656A626F65
    2376:      	movq	%rax, 0x38(%rsp)
    237b:      	movabsq	$0x646f63206c6c754e, %rax # imm = 0x646F63206C6C754E
    2385:      	movq	%rax, 0x30(%rsp)
    238a:      	leaq	0x30(%rsp), %rdi
    238f:      	movl	$0x2f, %eax
    2394:      	movl	$0x6, %r8d
    239a:      	movq	(%rsp), %rax
    239e:      	movzbl	0x19(%rax), %ecx
    23a2:      	addq	%r13, %rcx
    23a5:      	movl	$0x2f, %esi
    23aa:      	movq	%r13, %rdx
    23ad:      	xorl	%eax, %eax
    23af:      	callq	*%r8
    23b2:      	jmp	0x1e4a <kprobe_unwind_python+0x1e4a>
    23b7:      	cmpl	$0x0, (%r14)
    23bb:      	jne	0x28b5 <kprobe_unwind_python+0x28b5>
    23c1:      	movq	$-0x2, %r12
    23c8:      	xorl	%eax, %eax
    23ca:      	movq	%rax, 0x28(%rsp)
    23cf:      	cmpl	$0x0, (%r14)
    23d3:      	jne	0x2851 <kprobe_unwind_python+0x2851>
    23d9:      	movl	0x2c0(%rbp), %eax
    23df:      	cmpq	$0x7e, %rax
    23e3:      	ja	0x1777 <kprobe_unwind_python+0x1777>
    23e9:      	leal	0x1(%rax), %ecx
    23ec:      	movl	%ecx, 0x2c0(%rbp)
    23f2:      	leaq	(%rax,%rax,2), %rax
    23f6:      	movq	0x28(%rsp), %rcx
    23fb:      	movq	%rcx, 0x2d0(%rbp,%rax,8)
    2403:      	movq	%r12, 0x2d8(%rbp,%rax,8)
    240b:      	movb	$0x1, 0x2e0(%rbp,%rax,8)
    2413:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    241e:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    2429:      	movl	$0x16, 0x18(%rsp)
    2431:      	movq	(%rip), %rdi            # 0x2438 <kprobe_unwind_python+0x2438>
    2438:      	leaq	0x18(%rsp), %rsi
    243d:      	movl	$0x1, %eax
    2442:      	callq	*%rax
    2444:      	testq	%rax, %rax
    2447:      	je	0x24d8 <kprobe_unwind_python+0x24d8>
    244d:      	incq	(%rax)
    2450:      	testb	%bl, %bl
    2452:      	jne	0x124c <kprobe_unwind_python+0x124c>
    2458:      	jmp	0x24ea <kprobe_unwind_python+0x24ea>
    245d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2467:      	movq	%rax, 0x56(%rsp)
    246c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2476:      	movq	%rax, 0x50(%rsp)
    247b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2485:      	movq	%rax, 0x48(%rsp)
    248a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2494:      	movq	%rax, 0x40(%rsp)
    2499:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    24a3:      	movq	%rax, 0x38(%rsp)
    24a8:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    24b2:      	movq	%rax, 0x30(%rsp)
    24b7:      	leaq	0x30(%rsp), %rdi
    24bc:      	movl	$0x2e, %eax
    24c1:      	movl	$0x6, %ecx
    24c6:      	movl	0x18(%rsp), %edx
    24ca:      	movl	$0x2e, %esi
    24cf:      	xorl	%eax, %eax
    24d1:      	callq	*%rcx
    24d3:      	jmp	0x1f09 <kprobe_unwind_python+0x1f09>
    24d8:      	cmpl	$0x0, (%r14)
    24dc:      	jne	0x2930 <kprobe_unwind_python+0x2930>
    24e2:      	testb	%bl, %bl
    24e4:      	jne	0x124c <kprobe_unwind_python+0x124c>
    24ea:      	xorl	%r12d, %r12d
    24ed:      	testq	%r13, %r13
    24f0:      	je	0x45be <kprobe_unwind_python+0x45be>
    24f6:      	movq	(%rsp), %rax
    24fa:      	cmpb	$0x78, 0x19(%rax)
    24fe:      	ja	0x460a <kprobe_unwind_python+0x460a>
    2504:      	movq	(%rsp), %rax
    2508:      	cmpb	$0x78, 0x18(%rax)
    250c:      	ja	0x460a <kprobe_unwind_python+0x460a>
    2512:      	movq	(%rsp), %rax
    2516:      	cmpb	$0x78, 0x1a(%rax)
    251a:      	ja	0x460a <kprobe_unwind_python+0x460a>
    2520:      	movq	(%rsp), %rax
    2524:      	cmpb	$0x0, 0x1b(%rax)
    2528:      	js	0x460a <kprobe_unwind_python+0x460a>
    252e:      	movl	$0x80, %eax
    2533:      	movl	$0x70, %ecx
    2538:      	movq	0x70(%rsp), %rdi
    253d:      	movl	$0x80, %esi
    2542:      	movq	%r13, %rdx
    2545:      	callq	*%rcx
    2547:      	testq	%rax, %rax
    254a:      	jne	0x1d27 <kprobe_unwind_python+0x1d27>
    2550:      	movq	(%rsp), %rax
    2554:      	movzbl	0x19(%rax), %ecx
    2558:      	movq	0x70(%rsp), %rdx
    255d:      	movq	(%rdx,%rcx), %rcx
    2561:      	movq	%rcx, 0x28(%rsp)
    2566:      	movzbl	0x18(%rax), %ecx
    256a:      	movq	(%rdx,%rcx), %rcx
    256e:      	movq	%rcx, 0x20(%rsp)
    2573:      	movq	0x8(%rax), %rax
    2577:      	testq	%rax, %rax
    257a:      	je	0x2587 <kprobe_unwind_python+0x2587>
    257c:      	cmpq	%rax, 0x28(%rsp)
    2581:      	je	0x1d64 <kprobe_unwind_python+0x1d64>
    2587:      	movq	(%rsp), %rax
    258b:      	cmpb	$0x0, 0x22(%rax)
    258f:      	movzbl	0x1a(%rax), %eax
    2593:      	je	0x2662 <kprobe_unwind_python+0x2662>
    2599:      	movq	0x70(%rsp), %rsi
    259e:      	movq	(%rsi,%rax), %rax
    25a2:      	movq	(%rsp), %rcx
    25a6:      	movzbl	0x21(%rcx), %edx
    25aa:      	addq	0x28(%rsp), %rdx
    25af:      	subq	%rdx, %rax
    25b2:      	leaq	-0x10000001(%rax), %rdx
    25b9:      	sarl	%eax
    25bb:      	cmpq	$-0x10000003, %rdx      # imm = 0xEFFFFFFD
    25c2:      	movl	$0xffffffff, %r12d      # imm = 0xFFFFFFFF
    25c8:      	cmovael	%eax, %r12d
    25cc:      	movzbl	0x1b(%rcx), %eax
    25d0:      	movzbl	(%rsi,%rax), %eax
    25d4:      	cmpb	0x1c(%rcx), %al
    25d7:      	sete	%bl
    25da:      	jmp	0x266d <kprobe_unwind_python+0x266d>
    25df:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    25e9:      	movq	%rax, 0x56(%rsp)
    25ee:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    25f8:      	movq	%rax, 0x50(%rsp)
    25fd:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2607:      	movq	%rax, 0x48(%rsp)
    260c:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2616:      	movq	%rax, 0x40(%rsp)
    261b:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2625:      	movq	%rax, 0x38(%rsp)
    262a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2634:      	movq	%rax, 0x30(%rsp)
    2639:      	leaq	0x30(%rsp), %rdi
    263e:      	movl	$0x2e, %eax
    2643:      	movl	$0x6, %ecx
    2648:      	movl	0x18(%rsp), %edx
    264c:      	movl	$0x2e, %esi
    2651:      	xorl	%eax, %eax
    2653:      	callq	*%rcx
    2655:      	testb	%bl, %bl
    2657:      	jne	0x1d64 <kprobe_unwind_python+0x1d64>
    265d:      	jmp	0x215e <kprobe_unwind_python+0x215e>
    2662:      	movq	0x70(%rsp), %rcx
    2667:      	movl	(%rcx,%rax), %r12d
    266b:      	xorl	%ebx, %ebx
    266d:      	cmpq	$0x0, 0x28(%rsp)
    2673:      	je	0x2710 <kprobe_unwind_python+0x2710>
    2679:      	movq	(%rsp), %rax
    267d:      	cmpb	$-0x44, 0x1d(%rax)
    2681:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    2687:      	movq	(%rsp), %rax
    268b:      	cmpb	$-0x44, 0x1e(%rax)
    268f:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    2695:      	movq	(%rsp), %rax
    2699:      	cmpb	$-0x44, 0x1f(%rax)
    269d:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    26a3:      	movq	(%rsp), %rax
    26a7:      	cmpb	$-0x44, 0x20(%rax)
    26ab:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    26b1:      	movl	$0xc0, %eax
    26b6:      	movl	$0x70, %ecx
    26bb:      	movq	0x28(%rsp), %rdx
    26c0:      	movq	%r15, %rdi
    26c3:      	movl	$0xc0, %esi
    26c8:      	callq	*%rcx
    26ca:      	testq	%rax, %rax
    26cd:      	jne	0x1e36 <kprobe_unwind_python+0x1e36>
    26d3:      	movq	(%rsp), %rax
    26d7:      	movzbl	0x1d(%rax), %ecx
    26db:      	movl	(%r15,%rcx), %ecx
    26df:      	movzbl	0x1e(%rax), %edx
    26e3:      	movl	(%r15,%rdx), %edx
    26e7:      	movzbl	0x1f(%rax), %esi
    26eb:      	movl	(%r15,%rsi), %esi
    26ef:      	movzbl	0x20(%rax), %eax
    26f3:      	shll	$0x19, %ecx
    26f6:      	shll	$0x12, %edx
    26f9:      	addl	%ecx, %edx
    26fb:      	shll	$0xa, %esi
    26fe:      	addl	%edx, %esi
    2700:      	addl	(%r15,%rax), %esi
    2704:      	shlq	$0x20, %r12
    2708:      	orq	%rsi, %r12
    270b:      	jmp	0x2a3d <kprobe_unwind_python+0x2a3d>
    2710:      	cmpl	$0x0, (%r14)
    2714:      	je	0x279c <kprobe_unwind_python+0x279c>
    271a:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    2724:      	movq	%rax, 0x57(%rsp)
    2729:      	movabsq	$0x20786c2578302074, %rax # imm = 0x20786C2578302074
    2733:      	movq	%rax, 0x50(%rsp)
    2738:      	movabsq	$0x63656a624f656d61, %rax # imm = 0x63656A624F656D61
    2742:      	movq	%rax, 0x48(%rsp)
    2747:      	movabsq	$0x7246795020726f66, %rax # imm = 0x7246795020726F66
    2751:      	movq	%rax, 0x40(%rsp)
    2756:      	movabsq	$0x207463656a626f65, %rax # imm = 0x207463656A626F65
    2760:      	movq	%rax, 0x38(%rsp)
    2765:      	movabsq	$0x646f63206c6c754e, %rax # imm = 0x646F63206C6C754E
    276f:      	movq	%rax, 0x30(%rsp)
    2774:      	leaq	0x30(%rsp), %rdi
    2779:      	movl	$0x2f, %eax
    277e:      	movl	$0x6, %r8d
    2784:      	movq	(%rsp), %rax
    2788:      	movzbl	0x19(%rax), %ecx
    278c:      	addq	%r13, %rcx
    278f:      	movl	$0x2f, %esi
    2794:      	movq	%r13, %rdx
    2797:      	xorl	%eax, %eax
    2799:      	callq	*%r8
    279c:      	movl	$0x1c, 0x18(%rsp)
    27a4:      	movq	(%rip), %rdi            # 0x27ab <kprobe_unwind_python+0x27ab>
    27ab:      	leaq	0x18(%rsp), %rsi
    27b0:      	movl	$0x1, %eax
    27b5:      	callq	*%rax
    27b7:      	testq	%rax, %rax
    27ba:      	je	0x29b3 <kprobe_unwind_python+0x29b3>
    27c0:      	incq	(%rax)
    27c3:      	jmp	0x2a2f <kprobe_unwind_python+0x2a2f>
    27c8:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    27d2:      	movq	%rax, 0x57(%rsp)
    27d7:      	movabsq	$0x20786c2578302074, %rax # imm = 0x20786C2578302074
    27e1:      	movq	%rax, 0x50(%rsp)
    27e6:      	movabsq	$0x63656a624f656d61, %rax # imm = 0x63656A624F656D61
    27f0:      	movq	%rax, 0x48(%rsp)
    27f5:      	movabsq	$0x7246795020726f66, %rax # imm = 0x7246795020726F66
    27ff:      	movq	%rax, 0x40(%rsp)
    2804:      	movabsq	$0x207463656a626f65, %rax # imm = 0x207463656A626F65
    280e:      	movq	%rax, 0x38(%rsp)
    2813:      	movabsq	$0x646f63206c6c754e, %rax # imm = 0x646F63206C6C754E
    281d:      	movq	%rax, 0x30(%rsp)
    2822:      	leaq	0x30(%rsp), %rdi
    2827:      	movl	$0x2f, %eax
    282c:      	movl	$0x6, %r8d
    2832:      	movq	(%rsp), %rax
    2836:      	movzbl	0x19(%rax), %ecx
    283a:      	movq	0x20(%rsp), %rdx
    283f:      	addq	%rdx, %rcx
    2842:      	movl	$0x2f, %esi
    2847:      	xorl	%eax, %eax
    2849:      	callq	*%r8
    284c:      	jmp	0x2304 <kprobe_unwind_python+0x2304>
    2851:      	movabsq	$0xa756c2520786c, %rax  # imm = 0xA756C2520786C
    285b:      	movq	%rax, 0x40(%rsp)
    2860:      	movabsq	$0x25206e6f68747950, %rax # imm = 0x25206E6F68747950
    286a:      	movq	%rax, 0x38(%rsp)
    286f:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    2879:      	movq	%rax, 0x30(%rsp)
    287e:      	leaq	0x30(%rsp), %rdi
    2883:      	movl	$0x18, %eax
    2888:      	movl	$0x6, %r8d
    288e:      	movl	$0x18, %esi
    2893:      	movq	0x28(%rsp), %rdx
    2898:      	movq	%r12, %rcx
    289b:      	xorl	%eax, %eax
    289d:      	callq	*%r8
    28a0:      	movl	0x2c0(%rbp), %eax
    28a6:      	cmpq	$0x7e, %rax
    28aa:      	ja	0x1777 <kprobe_unwind_python+0x1777>
    28b0:      	jmp	0x23e9 <kprobe_unwind_python+0x23e9>
    28b5:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    28bf:      	movq	%rax, 0x56(%rsp)
    28c4:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    28ce:      	movq	%rax, 0x50(%rsp)
    28d3:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    28dd:      	movq	%rax, 0x48(%rsp)
    28e2:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    28ec:      	movq	%rax, 0x40(%rsp)
    28f1:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    28fb:      	movq	%rax, 0x38(%rsp)
    2900:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    290a:      	movq	%rax, 0x30(%rsp)
    290f:      	leaq	0x30(%rsp), %rdi
    2914:      	movl	$0x2e, %eax
    2919:      	movl	$0x6, %ecx
    291e:      	movl	0x18(%rsp), %edx
    2922:      	movl	$0x2e, %esi
    2927:      	xorl	%eax, %eax
    2929:      	callq	*%rcx
    292b:      	jmp	0x23c1 <kprobe_unwind_python+0x23c1>
    2930:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    293a:      	movq	%rax, 0x56(%rsp)
    293f:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2949:      	movq	%rax, 0x50(%rsp)
    294e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2958:      	movq	%rax, 0x48(%rsp)
    295d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2967:      	movq	%rax, 0x40(%rsp)
    296c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2976:      	movq	%rax, 0x38(%rsp)
    297b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2985:      	movq	%rax, 0x30(%rsp)
    298a:      	leaq	0x30(%rsp), %rdi
    298f:      	movl	$0x2e, %eax
    2994:      	movl	$0x6, %ecx
    2999:      	movl	0x18(%rsp), %edx
    299d:      	movl	$0x2e, %esi
    29a2:      	xorl	%eax, %eax
    29a4:      	callq	*%rcx
    29a6:      	testb	%bl, %bl
    29a8:      	jne	0x124c <kprobe_unwind_python+0x124c>
    29ae:      	jmp	0x24ea <kprobe_unwind_python+0x24ea>
    29b3:      	cmpl	$0x0, (%r14)
    29b7:      	je	0x2a2f <kprobe_unwind_python+0x2a2f>
    29b9:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    29c3:      	movq	%rax, 0x56(%rsp)
    29c8:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    29d2:      	movq	%rax, 0x50(%rsp)
    29d7:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    29e1:      	movq	%rax, 0x48(%rsp)
    29e6:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    29f0:      	movq	%rax, 0x40(%rsp)
    29f5:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    29ff:      	movq	%rax, 0x38(%rsp)
    2a04:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2a0e:      	movq	%rax, 0x30(%rsp)
    2a13:      	leaq	0x30(%rsp), %rdi
    2a18:      	movl	$0x2e, %eax
    2a1d:      	movl	$0x6, %ecx
    2a22:      	movl	0x18(%rsp), %edx
    2a26:      	movl	$0x2e, %esi
    2a2b:      	xorl	%eax, %eax
    2a2d:      	callq	*%rcx
    2a2f:      	movq	$-0x2, %r12
    2a36:      	xorl	%eax, %eax
    2a38:      	movq	%rax, 0x28(%rsp)
    2a3d:      	cmpl	$0x0, (%r14)
    2a41:      	je	0x2a92 <kprobe_unwind_python+0x2a92>
    2a43:      	movabsq	$0xa756c2520786c, %rax  # imm = 0xA756C2520786C
    2a4d:      	movq	%rax, 0x40(%rsp)
    2a52:      	movabsq	$0x25206e6f68747950, %rax # imm = 0x25206E6F68747950
    2a5c:      	movq	%rax, 0x38(%rsp)
    2a61:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    2a6b:      	movq	%rax, 0x30(%rsp)
    2a70:      	leaq	0x30(%rsp), %rdi
    2a75:      	movl	$0x18, %eax
    2a7a:      	movl	$0x6, %r8d
    2a80:      	movl	$0x18, %esi
    2a85:      	movq	0x28(%rsp), %rdx
    2a8a:      	movq	%r12, %rcx
    2a8d:      	xorl	%eax, %eax
    2a8f:      	callq	*%r8
    2a92:      	movl	0x2c0(%rbp), %eax
    2a98:      	cmpq	$0x7e, %rax
    2a9c:      	ja	0x1f31 <kprobe_unwind_python+0x1f31>
    2aa2:      	leal	0x1(%rax), %ecx
    2aa5:      	movl	%ecx, 0x2c0(%rbp)
    2aab:      	leaq	(%rax,%rax,2), %rax
    2aaf:      	movq	0x28(%rsp), %rcx
    2ab4:      	movq	%rcx, 0x2d0(%rbp,%rax,8)
    2abc:      	movq	%r12, 0x2d8(%rbp,%rax,8)
    2ac4:      	movb	$0x1, 0x2e0(%rbp,%rax,8)
    2acc:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    2ad7:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    2ae2:      	movl	$0x16, 0x18(%rsp)
    2aea:      	movq	(%rip), %rdi            # 0x2af1 <kprobe_unwind_python+0x2af1>
    2af1:      	leaq	0x18(%rsp), %rsi
    2af6:      	movl	$0x1, %eax
    2afb:      	callq	*%rax
    2afd:      	testq	%rax, %rax
    2b00:      	je	0x2b07 <kprobe_unwind_python+0x2b07>
    2b02:      	incq	(%rax)
    2b05:      	jmp	0x2b83 <kprobe_unwind_python+0x2b83>
    2b07:      	cmpl	$0x0, (%r14)
    2b0b:      	je	0x2b83 <kprobe_unwind_python+0x2b83>
    2b0d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2b17:      	movq	%rax, 0x56(%rsp)
    2b1c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2b26:      	movq	%rax, 0x50(%rsp)
    2b2b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2b35:      	movq	%rax, 0x48(%rsp)
    2b3a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2b44:      	movq	%rax, 0x40(%rsp)
    2b49:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2b53:      	movq	%rax, 0x38(%rsp)
    2b58:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2b62:      	movq	%rax, 0x30(%rsp)
    2b67:      	leaq	0x30(%rsp), %rdi
    2b6c:      	movl	$0x2e, %eax
    2b71:      	movl	$0x6, %ecx
    2b76:      	movl	0x18(%rsp), %edx
    2b7a:      	movl	$0x2e, %esi
    2b7f:      	xorl	%eax, %eax
    2b81:      	callq	*%rcx
    2b83:      	testb	%bl, %bl
    2b85:      	jne	0x1d64 <kprobe_unwind_python+0x1d64>
    2b8b:      	xorl	%r12d, %r12d
    2b8e:      	cmpq	$0x0, 0x20(%rsp)
    2b94:      	je	0x45be <kprobe_unwind_python+0x45be>
    2b9a:      	movq	(%rsp), %rax
    2b9e:      	cmpb	$0x78, 0x19(%rax)
    2ba2:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    2ba8:      	movq	(%rsp), %rax
    2bac:      	cmpb	$0x78, 0x18(%rax)
    2bb0:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    2bb6:      	movq	(%rsp), %rax
    2bba:      	cmpb	$0x78, 0x1a(%rax)
    2bbe:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    2bc4:      	movq	(%rsp), %rax
    2bc8:      	cmpb	$0x0, 0x1b(%rax)
    2bcc:      	js	0x45a2 <kprobe_unwind_python+0x45a2>
    2bd2:      	movl	$0x80, %eax
    2bd7:      	movl	$0x70, %ecx
    2bdc:      	movq	0x70(%rsp), %rdi
    2be1:      	movq	0x20(%rsp), %rdx
    2be6:      	movl	$0x80, %esi
    2beb:      	callq	*%rcx
    2bed:      	testq	%rax, %rax
    2bf0:      	jne	0xd60 <kprobe_unwind_python+0xd60>
    2bf6:      	movq	(%rsp), %rax
    2bfa:      	movzbl	0x19(%rax), %ecx
    2bfe:      	movq	0x70(%rsp), %rdx
    2c03:      	movq	(%rdx,%rcx), %rcx
    2c07:      	movq	%rcx, 0x28(%rsp)
    2c0c:      	movzbl	0x18(%rax), %ecx
    2c10:      	movq	(%rdx,%rcx), %r13
    2c14:      	movq	0x8(%rax), %rax
    2c18:      	testq	%rax, %rax
    2c1b:      	je	0x2c28 <kprobe_unwind_python+0x2c28>
    2c1d:      	cmpq	%rax, 0x28(%rsp)
    2c22:      	je	0x124c <kprobe_unwind_python+0x124c>
    2c28:      	movq	(%rsp), %rax
    2c2c:      	cmpb	$0x0, 0x22(%rax)
    2c30:      	movzbl	0x1a(%rax), %eax
    2c34:      	je	0x2c78 <kprobe_unwind_python+0x2c78>
    2c36:      	movq	0x70(%rsp), %rsi
    2c3b:      	movq	(%rsi,%rax), %rax
    2c3f:      	movq	(%rsp), %rcx
    2c43:      	movzbl	0x21(%rcx), %edx
    2c47:      	addq	0x28(%rsp), %rdx
    2c4c:      	subq	%rdx, %rax
    2c4f:      	leaq	-0x10000001(%rax), %rdx
    2c56:      	sarl	%eax
    2c58:      	cmpq	$-0x10000003, %rdx      # imm = 0xEFFFFFFD
    2c5f:      	movl	$0xffffffff, %ebx       # imm = 0xFFFFFFFF
    2c64:      	cmovael	%eax, %ebx
    2c67:      	movzbl	0x1b(%rcx), %eax
    2c6b:      	movzbl	(%rsi,%rax), %eax
    2c6f:      	cmpb	0x1c(%rcx), %al
    2c72:      	sete	%r12b
    2c76:      	jmp	0x2c83 <kprobe_unwind_python+0x2c83>
    2c78:      	movq	0x70(%rsp), %rcx
    2c7d:      	movl	(%rcx,%rax), %ebx
    2c80:      	xorl	%r12d, %r12d
    2c83:      	cmpq	$0x0, 0x28(%rsp)
    2c89:      	je	0x2d26 <kprobe_unwind_python+0x2d26>
    2c8f:      	movq	(%rsp), %rax
    2c93:      	cmpb	$-0x44, 0x1d(%rax)
    2c97:      	ja	0x460a <kprobe_unwind_python+0x460a>
    2c9d:      	movq	(%rsp), %rax
    2ca1:      	cmpb	$-0x44, 0x1e(%rax)
    2ca5:      	ja	0x460a <kprobe_unwind_python+0x460a>
    2cab:      	movq	(%rsp), %rax
    2caf:      	cmpb	$-0x44, 0x1f(%rax)
    2cb3:      	ja	0x460a <kprobe_unwind_python+0x460a>
    2cb9:      	movq	(%rsp), %rax
    2cbd:      	cmpb	$-0x44, 0x20(%rax)
    2cc1:      	ja	0x460a <kprobe_unwind_python+0x460a>
    2cc7:      	movl	$0xc0, %eax
    2ccc:      	movl	$0x70, %ecx
    2cd1:      	movq	0x28(%rsp), %rdx
    2cd6:      	movq	%r15, %rdi
    2cd9:      	movl	$0xc0, %esi
    2cde:      	callq	*%rcx
    2ce0:      	testq	%rax, %rax
    2ce3:      	jne	0x2bc <kprobe_unwind_python+0x2bc>
    2ce9:      	movq	(%rsp), %rax
    2ced:      	movzbl	0x1d(%rax), %ecx
    2cf1:      	movl	(%r15,%rcx), %ecx
    2cf5:      	movzbl	0x1e(%rax), %edx
    2cf9:      	movl	(%r15,%rdx), %edx
    2cfd:      	movzbl	0x1f(%rax), %esi
    2d01:      	movl	(%r15,%rsi), %esi
    2d05:      	movzbl	0x20(%rax), %eax
    2d09:      	shll	$0x19, %ecx
    2d0c:      	shll	$0x12, %edx
    2d0f:      	addl	%ecx, %edx
    2d11:      	shll	$0xa, %esi
    2d14:      	addl	%edx, %esi
    2d16:      	addl	(%r15,%rax), %esi
    2d1a:      	shlq	$0x20, %rbx
    2d1e:      	orq	%rsi, %rbx
    2d21:      	jmp	0x2e63 <kprobe_unwind_python+0x2e63>
    2d26:      	cmpl	$0x0, (%r14)
    2d2a:      	je	0x2db4 <kprobe_unwind_python+0x2db4>
    2d30:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    2d3a:      	movq	%rax, 0x57(%rsp)
    2d3f:      	movabsq	$0x20786c2578302074, %rax # imm = 0x20786C2578302074
    2d49:      	movq	%rax, 0x50(%rsp)
    2d4e:      	movabsq	$0x63656a624f656d61, %rax # imm = 0x63656A624F656D61
    2d58:      	movq	%rax, 0x48(%rsp)
    2d5d:      	movabsq	$0x7246795020726f66, %rax # imm = 0x7246795020726F66
    2d67:      	movq	%rax, 0x40(%rsp)
    2d6c:      	movabsq	$0x207463656a626f65, %rax # imm = 0x207463656A626F65
    2d76:      	movq	%rax, 0x38(%rsp)
    2d7b:      	movabsq	$0x646f63206c6c754e, %rax # imm = 0x646F63206C6C754E
    2d85:      	movq	%rax, 0x30(%rsp)
    2d8a:      	leaq	0x30(%rsp), %rdi
    2d8f:      	movl	$0x2f, %eax
    2d94:      	movl	$0x6, %r8d
    2d9a:      	movq	(%rsp), %rax
    2d9e:      	movzbl	0x19(%rax), %ecx
    2da2:      	movq	0x20(%rsp), %rdx
    2da7:      	addq	%rdx, %rcx
    2daa:      	movl	$0x2f, %esi
    2daf:      	xorl	%eax, %eax
    2db1:      	callq	*%r8
    2db4:      	movl	$0x1c, 0x18(%rsp)
    2dbc:      	movq	(%rip), %rdi            # 0x2dc3 <kprobe_unwind_python+0x2dc3>
    2dc3:      	leaq	0x18(%rsp), %rsi
    2dc8:      	movl	$0x1, %eax
    2dcd:      	callq	*%rax
    2dcf:      	testq	%rax, %rax
    2dd2:      	je	0x2dd9 <kprobe_unwind_python+0x2dd9>
    2dd4:      	incq	(%rax)
    2dd7:      	jmp	0x2e55 <kprobe_unwind_python+0x2e55>
    2dd9:      	cmpl	$0x0, (%r14)
    2ddd:      	je	0x2e55 <kprobe_unwind_python+0x2e55>
    2ddf:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2de9:      	movq	%rax, 0x56(%rsp)
    2dee:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2df8:      	movq	%rax, 0x50(%rsp)
    2dfd:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2e07:      	movq	%rax, 0x48(%rsp)
    2e0c:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2e16:      	movq	%rax, 0x40(%rsp)
    2e1b:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2e25:      	movq	%rax, 0x38(%rsp)
    2e2a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2e34:      	movq	%rax, 0x30(%rsp)
    2e39:      	leaq	0x30(%rsp), %rdi
    2e3e:      	movl	$0x2e, %eax
    2e43:      	movl	$0x6, %ecx
    2e48:      	movl	0x18(%rsp), %edx
    2e4c:      	movl	$0x2e, %esi
    2e51:      	xorl	%eax, %eax
    2e53:      	callq	*%rcx
    2e55:      	movq	$-0x2, %rbx
    2e5c:      	xorl	%eax, %eax
    2e5e:      	movq	%rax, 0x28(%rsp)
    2e63:      	cmpl	$0x0, (%r14)
    2e67:      	je	0x2eb8 <kprobe_unwind_python+0x2eb8>
    2e69:      	movabsq	$0xa756c2520786c, %rax  # imm = 0xA756C2520786C
    2e73:      	movq	%rax, 0x40(%rsp)
    2e78:      	movabsq	$0x25206e6f68747950, %rax # imm = 0x25206E6F68747950
    2e82:      	movq	%rax, 0x38(%rsp)
    2e87:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    2e91:      	movq	%rax, 0x30(%rsp)
    2e96:      	leaq	0x30(%rsp), %rdi
    2e9b:      	movl	$0x18, %eax
    2ea0:      	movl	$0x6, %r8d
    2ea6:      	movl	$0x18, %esi
    2eab:      	movq	0x28(%rsp), %rdx
    2eb0:      	movq	%rbx, %rcx
    2eb3:      	xorl	%eax, %eax
    2eb5:      	callq	*%r8
    2eb8:      	movl	0x2c0(%rbp), %eax
    2ebe:      	cmpq	$0x7e, %rax
    2ec2:      	ja	0x1777 <kprobe_unwind_python+0x1777>
    2ec8:      	leal	0x1(%rax), %ecx
    2ecb:      	movl	%ecx, 0x2c0(%rbp)
    2ed1:      	leaq	(%rax,%rax,2), %rax
    2ed5:      	movq	0x28(%rsp), %rcx
    2eda:      	movq	%rcx, 0x2d0(%rbp,%rax,8)
    2ee2:      	movq	%rbx, 0x2d8(%rbp,%rax,8)
    2eea:      	movb	$0x1, 0x2e0(%rbp,%rax,8)
    2ef2:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    2efd:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    2f08:      	movl	$0x16, 0x18(%rsp)
    2f10:      	movq	(%rip), %rdi            # 0x2f17 <kprobe_unwind_python+0x2f17>
    2f17:      	leaq	0x18(%rsp), %rsi
    2f1c:      	movl	$0x1, %eax
    2f21:      	callq	*%rax
    2f23:      	testq	%rax, %rax
    2f26:      	je	0x2f2d <kprobe_unwind_python+0x2f2d>
    2f28:      	incq	(%rax)
    2f2b:      	jmp	0x2fa9 <kprobe_unwind_python+0x2fa9>
    2f2d:      	cmpl	$0x0, (%r14)
    2f31:      	je	0x2fa9 <kprobe_unwind_python+0x2fa9>
    2f33:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2f3d:      	movq	%rax, 0x56(%rsp)
    2f42:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2f4c:      	movq	%rax, 0x50(%rsp)
    2f51:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2f5b:      	movq	%rax, 0x48(%rsp)
    2f60:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2f6a:      	movq	%rax, 0x40(%rsp)
    2f6f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2f79:      	movq	%rax, 0x38(%rsp)
    2f7e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2f88:      	movq	%rax, 0x30(%rsp)
    2f8d:      	leaq	0x30(%rsp), %rdi
    2f92:      	movl	$0x2e, %eax
    2f97:      	movl	$0x6, %ecx
    2f9c:      	movl	0x18(%rsp), %edx
    2fa0:      	movl	$0x2e, %esi
    2fa5:      	xorl	%eax, %eax
    2fa7:      	callq	*%rcx
    2fa9:      	testb	%r12b, %r12b
    2fac:      	jne	0x124c <kprobe_unwind_python+0x124c>
    2fb2:      	xorl	%r12d, %r12d
    2fb5:      	testq	%r13, %r13
    2fb8:      	je	0x45be <kprobe_unwind_python+0x45be>
    2fbe:      	movq	(%rsp), %rax
    2fc2:      	cmpb	$0x78, 0x19(%rax)
    2fc6:      	ja	0x460a <kprobe_unwind_python+0x460a>
    2fcc:      	movq	(%rsp), %rax
    2fd0:      	cmpb	$0x78, 0x18(%rax)
    2fd4:      	ja	0x460a <kprobe_unwind_python+0x460a>
    2fda:      	movq	(%rsp), %rax
    2fde:      	cmpb	$0x78, 0x1a(%rax)
    2fe2:      	ja	0x460a <kprobe_unwind_python+0x460a>
    2fe8:      	movq	(%rsp), %rax
    2fec:      	cmpb	$0x0, 0x1b(%rax)
    2ff0:      	js	0x460a <kprobe_unwind_python+0x460a>
    2ff6:      	movl	$0x80, %eax
    2ffb:      	movl	$0x70, %ecx
    3000:      	movq	0x70(%rsp), %rdi
    3005:      	movl	$0x80, %esi
    300a:      	movq	%r13, %rdx
    300d:      	callq	*%rcx
    300f:      	testq	%rax, %rax
    3012:      	jne	0x1d27 <kprobe_unwind_python+0x1d27>
    3018:      	movq	(%rsp), %rax
    301c:      	movzbl	0x19(%rax), %ecx
    3020:      	movq	0x70(%rsp), %rdx
    3025:      	movq	(%rdx,%rcx), %rcx
    3029:      	movq	%rcx, 0x28(%rsp)
    302e:      	movzbl	0x18(%rax), %ecx
    3032:      	movq	(%rdx,%rcx), %rcx
    3036:      	movq	%rcx, 0x20(%rsp)
    303b:      	movq	0x8(%rax), %rax
    303f:      	testq	%rax, %rax
    3042:      	je	0x304f <kprobe_unwind_python+0x304f>
    3044:      	cmpq	%rax, 0x28(%rsp)
    3049:      	je	0x1d64 <kprobe_unwind_python+0x1d64>
    304f:      	movq	(%rsp), %rax
    3053:      	cmpb	$0x0, 0x22(%rax)
    3057:      	movzbl	0x1a(%rax), %eax
    305b:      	je	0x30a4 <kprobe_unwind_python+0x30a4>
    305d:      	movq	0x70(%rsp), %rsi
    3062:      	movq	(%rsi,%rax), %rax
    3066:      	movq	(%rsp), %rcx
    306a:      	movzbl	0x21(%rcx), %edx
    306e:      	addq	0x28(%rsp), %rdx
    3073:      	subq	%rdx, %rax
    3076:      	leaq	-0x10000001(%rax), %rdx
    307d:      	sarl	%eax
    307f:      	cmpq	$-0x10000003, %rdx      # imm = 0xEFFFFFFD
    3086:      	movl	$0xffffffff, %r12d      # imm = 0xFFFFFFFF
    308c:      	cmovael	%eax, %r12d
    3090:      	movzbl	0x1b(%rcx), %eax
    3094:      	movzbl	(%rsi,%rax), %eax
    3098:      	cmpb	0x1c(%rcx), %al
    309b:      	sete	%al
    309e:      	movl	%eax, 0x78(%rsp)
    30a2:      	jmp	0x30b5 <kprobe_unwind_python+0x30b5>
    30a4:      	movq	0x70(%rsp), %rcx
    30a9:      	movl	(%rcx,%rax), %r12d
    30ad:      	movl	$0x0, 0x78(%rsp)
    30b5:      	cmpq	$0x0, 0x28(%rsp)
    30bb:      	je	0x3158 <kprobe_unwind_python+0x3158>
    30c1:      	movq	(%rsp), %rax
    30c5:      	cmpb	$-0x44, 0x1d(%rax)
    30c9:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    30cf:      	movq	(%rsp), %rax
    30d3:      	cmpb	$-0x44, 0x1e(%rax)
    30d7:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    30dd:      	movq	(%rsp), %rax
    30e1:      	cmpb	$-0x44, 0x1f(%rax)
    30e5:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    30eb:      	movq	(%rsp), %rax
    30ef:      	cmpb	$-0x44, 0x20(%rax)
    30f3:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    30f9:      	movl	$0xc0, %eax
    30fe:      	movl	$0x70, %ecx
    3103:      	movq	0x28(%rsp), %rdx
    3108:      	movq	%r15, %rdi
    310b:      	movl	$0xc0, %esi
    3110:      	callq	*%rcx
    3112:      	testq	%rax, %rax
    3115:      	jne	0x1e36 <kprobe_unwind_python+0x1e36>
    311b:      	movq	(%rsp), %rax
    311f:      	movzbl	0x1d(%rax), %ecx
    3123:      	movl	(%r15,%rcx), %ecx
    3127:      	movzbl	0x1e(%rax), %edx
    312b:      	movl	(%r15,%rdx), %edx
    312f:      	movzbl	0x1f(%rax), %esi
    3133:      	movl	(%r15,%rsi), %esi
    3137:      	movzbl	0x20(%rax), %eax
    313b:      	shll	$0x19, %ecx
    313e:      	shll	$0x12, %edx
    3141:      	addl	%ecx, %edx
    3143:      	shll	$0xa, %esi
    3146:      	addl	%edx, %esi
    3148:      	addl	(%r15,%rax), %esi
    314c:      	shlq	$0x20, %r12
    3150:      	orq	%rsi, %r12
    3153:      	jmp	0x3293 <kprobe_unwind_python+0x3293>
    3158:      	cmpl	$0x0, (%r14)
    315c:      	je	0x31e4 <kprobe_unwind_python+0x31e4>
    3162:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    316c:      	movq	%rax, 0x57(%rsp)
    3171:      	movabsq	$0x20786c2578302074, %rax # imm = 0x20786C2578302074
    317b:      	movq	%rax, 0x50(%rsp)
    3180:      	movabsq	$0x63656a624f656d61, %rax # imm = 0x63656A624F656D61
    318a:      	movq	%rax, 0x48(%rsp)
    318f:      	movabsq	$0x7246795020726f66, %rax # imm = 0x7246795020726F66
    3199:      	movq	%rax, 0x40(%rsp)
    319e:      	movabsq	$0x207463656a626f65, %rax # imm = 0x207463656A626F65
    31a8:      	movq	%rax, 0x38(%rsp)
    31ad:      	movabsq	$0x646f63206c6c754e, %rax # imm = 0x646F63206C6C754E
    31b7:      	movq	%rax, 0x30(%rsp)
    31bc:      	leaq	0x30(%rsp), %rdi
    31c1:      	movl	$0x2f, %eax
    31c6:      	movl	$0x6, %r8d
    31cc:      	movq	(%rsp), %rax
    31d0:      	movzbl	0x19(%rax), %ecx
    31d4:      	addq	%r13, %rcx
    31d7:      	movl	$0x2f, %esi
    31dc:      	movq	%r13, %rdx
    31df:      	xorl	%eax, %eax
    31e1:      	callq	*%r8
    31e4:      	movl	$0x1c, 0x18(%rsp)
    31ec:      	movq	(%rip), %rdi            # 0x31f3 <kprobe_unwind_python+0x31f3>
    31f3:      	leaq	0x18(%rsp), %rsi
    31f8:      	movl	$0x1, %eax
    31fd:      	callq	*%rax
    31ff:      	testq	%rax, %rax
    3202:      	je	0x3209 <kprobe_unwind_python+0x3209>
    3204:      	incq	(%rax)
    3207:      	jmp	0x3285 <kprobe_unwind_python+0x3285>
    3209:      	cmpl	$0x0, (%r14)
    320d:      	je	0x3285 <kprobe_unwind_python+0x3285>
    320f:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3219:      	movq	%rax, 0x56(%rsp)
    321e:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3228:      	movq	%rax, 0x50(%rsp)
    322d:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3237:      	movq	%rax, 0x48(%rsp)
    323c:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3246:      	movq	%rax, 0x40(%rsp)
    324b:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3255:      	movq	%rax, 0x38(%rsp)
    325a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3264:      	movq	%rax, 0x30(%rsp)
    3269:      	leaq	0x30(%rsp), %rdi
    326e:      	movl	$0x2e, %eax
    3273:      	movl	$0x6, %ecx
    3278:      	movl	0x18(%rsp), %edx
    327c:      	movl	$0x2e, %esi
    3281:      	xorl	%eax, %eax
    3283:      	callq	*%rcx
    3285:      	movq	$-0x2, %r12
    328c:      	xorl	%eax, %eax
    328e:      	movq	%rax, 0x28(%rsp)
    3293:      	cmpl	$0x0, (%r14)
    3297:      	je	0x32e8 <kprobe_unwind_python+0x32e8>
    3299:      	movabsq	$0xa756c2520786c, %rax  # imm = 0xA756C2520786C
    32a3:      	movq	%rax, 0x40(%rsp)
    32a8:      	movabsq	$0x25206e6f68747950, %rax # imm = 0x25206E6F68747950
    32b2:      	movq	%rax, 0x38(%rsp)
    32b7:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    32c1:      	movq	%rax, 0x30(%rsp)
    32c6:      	leaq	0x30(%rsp), %rdi
    32cb:      	movl	$0x18, %eax
    32d0:      	movl	$0x6, %r8d
    32d6:      	movl	$0x18, %esi
    32db:      	movq	0x28(%rsp), %rdx
    32e0:      	movq	%r12, %rcx
    32e3:      	xorl	%eax, %eax
    32e5:      	callq	*%r8
    32e8:      	movl	0x2c0(%rbp), %eax
    32ee:      	cmpq	$0x7e, %rax
    32f2:      	ja	0x1f31 <kprobe_unwind_python+0x1f31>
    32f8:      	leal	0x1(%rax), %ecx
    32fb:      	movl	%ecx, 0x2c0(%rbp)
    3301:      	leaq	(%rax,%rax,2), %rax
    3305:      	movq	0x28(%rsp), %rcx
    330a:      	movq	%rcx, 0x2d0(%rbp,%rax,8)
    3312:      	movq	%r12, 0x2d8(%rbp,%rax,8)
    331a:      	movb	$0x1, 0x2e0(%rbp,%rax,8)
    3322:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    332d:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    3338:      	movl	$0x16, 0x18(%rsp)
    3340:      	movq	(%rip), %rdi            # 0x3347 <kprobe_unwind_python+0x3347>
    3347:      	leaq	0x18(%rsp), %rsi
    334c:      	movl	$0x1, %eax
    3351:      	callq	*%rax
    3353:      	testq	%rax, %rax
    3356:      	je	0x335d <kprobe_unwind_python+0x335d>
    3358:      	incq	(%rax)
    335b:      	jmp	0x33d9 <kprobe_unwind_python+0x33d9>
    335d:      	cmpl	$0x0, (%r14)
    3361:      	je	0x33d9 <kprobe_unwind_python+0x33d9>
    3363:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    336d:      	movq	%rax, 0x56(%rsp)
    3372:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    337c:      	movq	%rax, 0x50(%rsp)
    3381:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    338b:      	movq	%rax, 0x48(%rsp)
    3390:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    339a:      	movq	%rax, 0x40(%rsp)
    339f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    33a9:      	movq	%rax, 0x38(%rsp)
    33ae:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    33b8:      	movq	%rax, 0x30(%rsp)
    33bd:      	leaq	0x30(%rsp), %rdi
    33c2:      	movl	$0x2e, %eax
    33c7:      	movl	$0x6, %ecx
    33cc:      	movl	0x18(%rsp), %edx
    33d0:      	movl	$0x2e, %esi
    33d5:      	xorl	%eax, %eax
    33d7:      	callq	*%rcx
    33d9:      	cmpb	$0x0, 0x78(%rsp)
    33de:      	jne	0x1d64 <kprobe_unwind_python+0x1d64>
    33e4:      	xorl	%r12d, %r12d
    33e7:      	cmpq	$0x0, 0x20(%rsp)
    33ed:      	je	0x45be <kprobe_unwind_python+0x45be>
    33f3:      	movq	(%rsp), %rax
    33f7:      	cmpb	$0x78, 0x19(%rax)
    33fb:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    3401:      	movq	(%rsp), %rax
    3405:      	cmpb	$0x78, 0x18(%rax)
    3409:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    340f:      	movq	(%rsp), %rax
    3413:      	cmpb	$0x78, 0x1a(%rax)
    3417:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    341d:      	movq	(%rsp), %rax
    3421:      	cmpb	$0x0, 0x1b(%rax)
    3425:      	js	0x45a2 <kprobe_unwind_python+0x45a2>
    342b:      	movl	$0x80, %eax
    3430:      	movl	$0x70, %ecx
    3435:      	movq	0x70(%rsp), %rdi
    343a:      	movq	0x20(%rsp), %rdx
    343f:      	movl	$0x80, %esi
    3444:      	callq	*%rcx
    3446:      	testq	%rax, %rax
    3449:      	jne	0xd60 <kprobe_unwind_python+0xd60>
    344f:      	movq	(%rsp), %rax
    3453:      	movzbl	0x19(%rax), %ecx
    3457:      	movq	0x70(%rsp), %rdx
    345c:      	movq	(%rdx,%rcx), %rcx
    3460:      	movq	%rcx, 0x28(%rsp)
    3465:      	movzbl	0x18(%rax), %ecx
    3469:      	movq	(%rdx,%rcx), %r13
    346d:      	movq	0x8(%rax), %rax
    3471:      	testq	%rax, %rax
    3474:      	je	0x3481 <kprobe_unwind_python+0x3481>
    3476:      	cmpq	%rax, 0x28(%rsp)
    347b:      	je	0x124c <kprobe_unwind_python+0x124c>
    3481:      	movq	(%rsp), %rax
    3485:      	cmpb	$0x0, 0x22(%rax)
    3489:      	movzbl	0x1a(%rax), %eax
    348d:      	je	0x34d6 <kprobe_unwind_python+0x34d6>
    348f:      	movq	0x70(%rsp), %rsi
    3494:      	movq	(%rsi,%rax), %rax
    3498:      	movq	(%rsp), %rcx
    349c:      	movzbl	0x21(%rcx), %edx
    34a0:      	addq	0x28(%rsp), %rdx
    34a5:      	subq	%rdx, %rax
    34a8:      	leaq	-0x10000001(%rax), %rdx
    34af:      	sarl	%eax
    34b1:      	cmpq	$-0x10000003, %rdx      # imm = 0xEFFFFFFD
    34b8:      	movl	$0xffffffff, %r12d      # imm = 0xFFFFFFFF
    34be:      	cmovael	%eax, %r12d
    34c2:      	movzbl	0x1b(%rcx), %eax
    34c6:      	movzbl	(%rsi,%rax), %eax
    34ca:      	cmpb	0x1c(%rcx), %al
    34cd:      	sete	%al
    34d0:      	movl	%eax, 0x78(%rsp)
    34d4:      	jmp	0x34e7 <kprobe_unwind_python+0x34e7>
    34d6:      	movq	0x70(%rsp), %rcx
    34db:      	movl	(%rcx,%rax), %r12d
    34df:      	movl	$0x0, 0x78(%rsp)
    34e7:      	cmpq	$0x0, 0x28(%rsp)
    34ed:      	je	0x358a <kprobe_unwind_python+0x358a>
    34f3:      	movq	(%rsp), %rax
    34f7:      	cmpb	$-0x44, 0x1d(%rax)
    34fb:      	ja	0x460a <kprobe_unwind_python+0x460a>
    3501:      	movq	(%rsp), %rax
    3505:      	cmpb	$-0x44, 0x1e(%rax)
    3509:      	ja	0x460a <kprobe_unwind_python+0x460a>
    350f:      	movq	(%rsp), %rax
    3513:      	cmpb	$-0x44, 0x1f(%rax)
    3517:      	ja	0x460a <kprobe_unwind_python+0x460a>
    351d:      	movq	(%rsp), %rax
    3521:      	cmpb	$-0x44, 0x20(%rax)
    3525:      	ja	0x460a <kprobe_unwind_python+0x460a>
    352b:      	movl	$0xc0, %eax
    3530:      	movl	$0x70, %ecx
    3535:      	movq	0x28(%rsp), %rdx
    353a:      	movq	%r15, %rdi
    353d:      	movl	$0xc0, %esi
    3542:      	callq	*%rcx
    3544:      	testq	%rax, %rax
    3547:      	jne	0x2bc <kprobe_unwind_python+0x2bc>
    354d:      	movq	(%rsp), %rax
    3551:      	movzbl	0x1d(%rax), %ecx
    3555:      	movl	(%r15,%rcx), %ecx
    3559:      	movzbl	0x1e(%rax), %edx
    355d:      	movl	(%r15,%rdx), %edx
    3561:      	movzbl	0x1f(%rax), %esi
    3565:      	movl	(%r15,%rsi), %esi
    3569:      	movzbl	0x20(%rax), %eax
    356d:      	shll	$0x19, %ecx
    3570:      	shll	$0x12, %edx
    3573:      	addl	%ecx, %edx
    3575:      	shll	$0xa, %esi
    3578:      	addl	%edx, %esi
    357a:      	addl	(%r15,%rax), %esi
    357e:      	shlq	$0x20, %r12
    3582:      	orq	%rsi, %r12
    3585:      	jmp	0x36c7 <kprobe_unwind_python+0x36c7>
    358a:      	cmpl	$0x0, (%r14)
    358e:      	je	0x3618 <kprobe_unwind_python+0x3618>
    3594:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    359e:      	movq	%rax, 0x57(%rsp)
    35a3:      	movabsq	$0x20786c2578302074, %rax # imm = 0x20786C2578302074
    35ad:      	movq	%rax, 0x50(%rsp)
    35b2:      	movabsq	$0x63656a624f656d61, %rax # imm = 0x63656A624F656D61
    35bc:      	movq	%rax, 0x48(%rsp)
    35c1:      	movabsq	$0x7246795020726f66, %rax # imm = 0x7246795020726F66
    35cb:      	movq	%rax, 0x40(%rsp)
    35d0:      	movabsq	$0x207463656a626f65, %rax # imm = 0x207463656A626F65
    35da:      	movq	%rax, 0x38(%rsp)
    35df:      	movabsq	$0x646f63206c6c754e, %rax # imm = 0x646F63206C6C754E
    35e9:      	movq	%rax, 0x30(%rsp)
    35ee:      	leaq	0x30(%rsp), %rdi
    35f3:      	movl	$0x2f, %eax
    35f8:      	movl	$0x6, %r8d
    35fe:      	movq	(%rsp), %rax
    3602:      	movzbl	0x19(%rax), %ecx
    3606:      	movq	0x20(%rsp), %rdx
    360b:      	addq	%rdx, %rcx
    360e:      	movl	$0x2f, %esi
    3613:      	xorl	%eax, %eax
    3615:      	callq	*%r8
    3618:      	movl	$0x1c, 0x18(%rsp)
    3620:      	movq	(%rip), %rdi            # 0x3627 <kprobe_unwind_python+0x3627>
    3627:      	leaq	0x18(%rsp), %rsi
    362c:      	movl	$0x1, %eax
    3631:      	callq	*%rax
    3633:      	testq	%rax, %rax
    3636:      	je	0x363d <kprobe_unwind_python+0x363d>
    3638:      	incq	(%rax)
    363b:      	jmp	0x36b9 <kprobe_unwind_python+0x36b9>
    363d:      	cmpl	$0x0, (%r14)
    3641:      	je	0x36b9 <kprobe_unwind_python+0x36b9>
    3643:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    364d:      	movq	%rax, 0x56(%rsp)
    3652:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    365c:      	movq	%rax, 0x50(%rsp)
    3661:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    366b:      	movq	%rax, 0x48(%rsp)
    3670:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    367a:      	movq	%rax, 0x40(%rsp)
    367f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3689:      	movq	%rax, 0x38(%rsp)
    368e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3698:      	movq	%rax, 0x30(%rsp)
    369d:      	leaq	0x30(%rsp), %rdi
    36a2:      	movl	$0x2e, %eax
    36a7:      	movl	$0x6, %ecx
    36ac:      	movl	0x18(%rsp), %edx
    36b0:      	movl	$0x2e, %esi
    36b5:      	xorl	%eax, %eax
    36b7:      	callq	*%rcx
    36b9:      	movq	$-0x2, %r12
    36c0:      	xorl	%eax, %eax
    36c2:      	movq	%rax, 0x28(%rsp)
    36c7:      	cmpl	$0x0, (%r14)
    36cb:      	je	0x371c <kprobe_unwind_python+0x371c>
    36cd:      	movabsq	$0xa756c2520786c, %rax  # imm = 0xA756C2520786C
    36d7:      	movq	%rax, 0x40(%rsp)
    36dc:      	movabsq	$0x25206e6f68747950, %rax # imm = 0x25206E6F68747950
    36e6:      	movq	%rax, 0x38(%rsp)
    36eb:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    36f5:      	movq	%rax, 0x30(%rsp)
    36fa:      	leaq	0x30(%rsp), %rdi
    36ff:      	movl	$0x18, %eax
    3704:      	movl	$0x6, %r8d
    370a:      	movl	$0x18, %esi
    370f:      	movq	0x28(%rsp), %rdx
    3714:      	movq	%r12, %rcx
    3717:      	xorl	%eax, %eax
    3719:      	callq	*%r8
    371c:      	movl	0x2c0(%rbp), %eax
    3722:      	cmpq	$0x7e, %rax
    3726:      	ja	0x1777 <kprobe_unwind_python+0x1777>
    372c:      	leal	0x1(%rax), %ecx
    372f:      	movl	%ecx, 0x2c0(%rbp)
    3735:      	leaq	(%rax,%rax,2), %rax
    3739:      	movq	0x28(%rsp), %rcx
    373e:      	movq	%rcx, 0x2d0(%rbp,%rax,8)
    3746:      	movq	%r12, 0x2d8(%rbp,%rax,8)
    374e:      	movb	$0x1, 0x2e0(%rbp,%rax,8)
    3756:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    3761:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    376c:      	movl	$0x16, 0x18(%rsp)
    3774:      	movq	(%rip), %rdi            # 0x377b <kprobe_unwind_python+0x377b>
    377b:      	leaq	0x18(%rsp), %rsi
    3780:      	movl	$0x1, %eax
    3785:      	callq	*%rax
    3787:      	testq	%rax, %rax
    378a:      	je	0x3791 <kprobe_unwind_python+0x3791>
    378c:      	incq	(%rax)
    378f:      	jmp	0x380d <kprobe_unwind_python+0x380d>
    3791:      	cmpl	$0x0, (%r14)
    3795:      	je	0x380d <kprobe_unwind_python+0x380d>
    3797:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    37a1:      	movq	%rax, 0x56(%rsp)
    37a6:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    37b0:      	movq	%rax, 0x50(%rsp)
    37b5:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    37bf:      	movq	%rax, 0x48(%rsp)
    37c4:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    37ce:      	movq	%rax, 0x40(%rsp)
    37d3:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    37dd:      	movq	%rax, 0x38(%rsp)
    37e2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    37ec:      	movq	%rax, 0x30(%rsp)
    37f1:      	leaq	0x30(%rsp), %rdi
    37f6:      	movl	$0x2e, %eax
    37fb:      	movl	$0x6, %ecx
    3800:      	movl	0x18(%rsp), %edx
    3804:      	movl	$0x2e, %esi
    3809:      	xorl	%eax, %eax
    380b:      	callq	*%rcx
    380d:      	cmpb	$0x0, 0x78(%rsp)
    3812:      	jne	0x124c <kprobe_unwind_python+0x124c>
    3818:      	xorl	%r12d, %r12d
    381b:      	testq	%r13, %r13
    381e:      	je	0x45be <kprobe_unwind_python+0x45be>
    3824:      	movq	(%rsp), %rax
    3828:      	cmpb	$0x78, 0x19(%rax)
    382c:      	ja	0x460a <kprobe_unwind_python+0x460a>
    3832:      	movq	(%rsp), %rax
    3836:      	cmpb	$0x78, 0x18(%rax)
    383a:      	ja	0x460a <kprobe_unwind_python+0x460a>
    3840:      	movq	(%rsp), %rax
    3844:      	cmpb	$0x78, 0x1a(%rax)
    3848:      	ja	0x460a <kprobe_unwind_python+0x460a>
    384e:      	movq	(%rsp), %rax
    3852:      	cmpb	$0x0, 0x1b(%rax)
    3856:      	js	0x460a <kprobe_unwind_python+0x460a>
    385c:      	movl	$0x80, %eax
    3861:      	movl	$0x70, %ecx
    3866:      	movq	0x70(%rsp), %rdi
    386b:      	movl	$0x80, %esi
    3870:      	movq	%r13, %rdx
    3873:      	callq	*%rcx
    3875:      	testq	%rax, %rax
    3878:      	jne	0x1d27 <kprobe_unwind_python+0x1d27>
    387e:      	movq	(%rsp), %rax
    3882:      	movzbl	0x19(%rax), %ecx
    3886:      	movq	0x70(%rsp), %rdx
    388b:      	movq	(%rdx,%rcx), %rcx
    388f:      	movq	%rcx, 0x28(%rsp)
    3894:      	movzbl	0x18(%rax), %ecx
    3898:      	movq	(%rdx,%rcx), %rcx
    389c:      	movq	%rcx, 0x20(%rsp)
    38a1:      	movq	0x8(%rax), %rax
    38a5:      	testq	%rax, %rax
    38a8:      	je	0x38b5 <kprobe_unwind_python+0x38b5>
    38aa:      	cmpq	%rax, 0x28(%rsp)
    38af:      	je	0x1d64 <kprobe_unwind_python+0x1d64>
    38b5:      	movq	(%rsp), %rax
    38b9:      	cmpb	$0x0, 0x22(%rax)
    38bd:      	movzbl	0x1a(%rax), %eax
    38c1:      	je	0x390a <kprobe_unwind_python+0x390a>
    38c3:      	movq	0x70(%rsp), %rsi
    38c8:      	movq	(%rsi,%rax), %rax
    38cc:      	movq	(%rsp), %rcx
    38d0:      	movzbl	0x21(%rcx), %edx
    38d4:      	addq	0x28(%rsp), %rdx
    38d9:      	subq	%rdx, %rax
    38dc:      	leaq	-0x10000001(%rax), %rdx
    38e3:      	sarl	%eax
    38e5:      	cmpq	$-0x10000003, %rdx      # imm = 0xEFFFFFFD
    38ec:      	movl	$0xffffffff, %r12d      # imm = 0xFFFFFFFF
    38f2:      	cmovael	%eax, %r12d
    38f6:      	movzbl	0x1b(%rcx), %eax
    38fa:      	movzbl	(%rsi,%rax), %eax
    38fe:      	cmpb	0x1c(%rcx), %al
    3901:      	sete	%al
    3904:      	movl	%eax, 0x78(%rsp)
    3908:      	jmp	0x391b <kprobe_unwind_python+0x391b>
    390a:      	movq	0x70(%rsp), %rcx
    390f:      	movl	(%rcx,%rax), %r12d
    3913:      	movl	$0x0, 0x78(%rsp)
    391b:      	cmpq	$0x0, 0x28(%rsp)
    3921:      	je	0x39be <kprobe_unwind_python+0x39be>
    3927:      	movq	(%rsp), %rax
    392b:      	cmpb	$-0x44, 0x1d(%rax)
    392f:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    3935:      	movq	(%rsp), %rax
    3939:      	cmpb	$-0x44, 0x1e(%rax)
    393d:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    3943:      	movq	(%rsp), %rax
    3947:      	cmpb	$-0x44, 0x1f(%rax)
    394b:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    3951:      	movq	(%rsp), %rax
    3955:      	cmpb	$-0x44, 0x20(%rax)
    3959:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    395f:      	movl	$0xc0, %eax
    3964:      	movl	$0x70, %ecx
    3969:      	movq	0x28(%rsp), %rdx
    396e:      	movq	%r15, %rdi
    3971:      	movl	$0xc0, %esi
    3976:      	callq	*%rcx
    3978:      	testq	%rax, %rax
    397b:      	jne	0x1e36 <kprobe_unwind_python+0x1e36>
    3981:      	movq	(%rsp), %rax
    3985:      	movzbl	0x1d(%rax), %ecx
    3989:      	movl	(%r15,%rcx), %ecx
    398d:      	movzbl	0x1e(%rax), %edx
    3991:      	movl	(%r15,%rdx), %edx
    3995:      	movzbl	0x1f(%rax), %esi
    3999:      	movl	(%r15,%rsi), %esi
    399d:      	movzbl	0x20(%rax), %eax
    39a1:      	shll	$0x19, %ecx
    39a4:      	shll	$0x12, %edx
    39a7:      	addl	%ecx, %edx
    39a9:      	shll	$0xa, %esi
    39ac:      	addl	%edx, %esi
    39ae:      	addl	(%r15,%rax), %esi
    39b2:      	shlq	$0x20, %r12
    39b6:      	orq	%rsi, %r12
    39b9:      	jmp	0x3af9 <kprobe_unwind_python+0x3af9>
    39be:      	cmpl	$0x0, (%r14)
    39c2:      	je	0x3a4a <kprobe_unwind_python+0x3a4a>
    39c8:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    39d2:      	movq	%rax, 0x57(%rsp)
    39d7:      	movabsq	$0x20786c2578302074, %rax # imm = 0x20786C2578302074
    39e1:      	movq	%rax, 0x50(%rsp)
    39e6:      	movabsq	$0x63656a624f656d61, %rax # imm = 0x63656A624F656D61
    39f0:      	movq	%rax, 0x48(%rsp)
    39f5:      	movabsq	$0x7246795020726f66, %rax # imm = 0x7246795020726F66
    39ff:      	movq	%rax, 0x40(%rsp)
    3a04:      	movabsq	$0x207463656a626f65, %rax # imm = 0x207463656A626F65
    3a0e:      	movq	%rax, 0x38(%rsp)
    3a13:      	movabsq	$0x646f63206c6c754e, %rax # imm = 0x646F63206C6C754E
    3a1d:      	movq	%rax, 0x30(%rsp)
    3a22:      	leaq	0x30(%rsp), %rdi
    3a27:      	movl	$0x2f, %eax
    3a2c:      	movl	$0x6, %r8d
    3a32:      	movq	(%rsp), %rax
    3a36:      	movzbl	0x19(%rax), %ecx
    3a3a:      	addq	%r13, %rcx
    3a3d:      	movl	$0x2f, %esi
    3a42:      	movq	%r13, %rdx
    3a45:      	xorl	%eax, %eax
    3a47:      	callq	*%r8
    3a4a:      	movl	$0x1c, 0x18(%rsp)
    3a52:      	movq	(%rip), %rdi            # 0x3a59 <kprobe_unwind_python+0x3a59>
    3a59:      	leaq	0x18(%rsp), %rsi
    3a5e:      	movl	$0x1, %eax
    3a63:      	callq	*%rax
    3a65:      	testq	%rax, %rax
    3a68:      	je	0x3a6f <kprobe_unwind_python+0x3a6f>
    3a6a:      	incq	(%rax)
    3a6d:      	jmp	0x3aeb <kprobe_unwind_python+0x3aeb>
    3a6f:      	cmpl	$0x0, (%r14)
    3a73:      	je	0x3aeb <kprobe_unwind_python+0x3aeb>
    3a75:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3a7f:      	movq	%rax, 0x56(%rsp)
    3a84:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3a8e:      	movq	%rax, 0x50(%rsp)
    3a93:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3a9d:      	movq	%rax, 0x48(%rsp)
    3aa2:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3aac:      	movq	%rax, 0x40(%rsp)
    3ab1:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3abb:      	movq	%rax, 0x38(%rsp)
    3ac0:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3aca:      	movq	%rax, 0x30(%rsp)
    3acf:      	leaq	0x30(%rsp), %rdi
    3ad4:      	movl	$0x2e, %eax
    3ad9:      	movl	$0x6, %ecx
    3ade:      	movl	0x18(%rsp), %edx
    3ae2:      	movl	$0x2e, %esi
    3ae7:      	xorl	%eax, %eax
    3ae9:      	callq	*%rcx
    3aeb:      	movq	$-0x2, %r12
    3af2:      	xorl	%eax, %eax
    3af4:      	movq	%rax, 0x28(%rsp)
    3af9:      	cmpl	$0x0, (%r14)
    3afd:      	je	0x3b4e <kprobe_unwind_python+0x3b4e>
    3aff:      	movabsq	$0xa756c2520786c, %rax  # imm = 0xA756C2520786C
    3b09:      	movq	%rax, 0x40(%rsp)
    3b0e:      	movabsq	$0x25206e6f68747950, %rax # imm = 0x25206E6F68747950
    3b18:      	movq	%rax, 0x38(%rsp)
    3b1d:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    3b27:      	movq	%rax, 0x30(%rsp)
    3b2c:      	leaq	0x30(%rsp), %rdi
    3b31:      	movl	$0x18, %eax
    3b36:      	movl	$0x6, %r8d
    3b3c:      	movl	$0x18, %esi
    3b41:      	movq	0x28(%rsp), %rdx
    3b46:      	movq	%r12, %rcx
    3b49:      	xorl	%eax, %eax
    3b4b:      	callq	*%r8
    3b4e:      	movl	0x2c0(%rbp), %eax
    3b54:      	cmpq	$0x7e, %rax
    3b58:      	ja	0x1f31 <kprobe_unwind_python+0x1f31>
    3b5e:      	leal	0x1(%rax), %ecx
    3b61:      	movl	%ecx, 0x2c0(%rbp)
    3b67:      	leaq	(%rax,%rax,2), %rax
    3b6b:      	movq	0x28(%rsp), %rcx
    3b70:      	movq	%rcx, 0x2d0(%rbp,%rax,8)
    3b78:      	movq	%r12, 0x2d8(%rbp,%rax,8)
    3b80:      	movb	$0x1, 0x2e0(%rbp,%rax,8)
    3b88:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    3b93:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    3b9e:      	movl	$0x16, 0x18(%rsp)
    3ba6:      	movq	(%rip), %rdi            # 0x3bad <kprobe_unwind_python+0x3bad>
    3bad:      	leaq	0x18(%rsp), %rsi
    3bb2:      	movl	$0x1, %eax
    3bb7:      	callq	*%rax
    3bb9:      	testq	%rax, %rax
    3bbc:      	je	0x3bc3 <kprobe_unwind_python+0x3bc3>
    3bbe:      	incq	(%rax)
    3bc1:      	jmp	0x3c3f <kprobe_unwind_python+0x3c3f>
    3bc3:      	cmpl	$0x0, (%r14)
    3bc7:      	je	0x3c3f <kprobe_unwind_python+0x3c3f>
    3bc9:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3bd3:      	movq	%rax, 0x56(%rsp)
    3bd8:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3be2:      	movq	%rax, 0x50(%rsp)
    3be7:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3bf1:      	movq	%rax, 0x48(%rsp)
    3bf6:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3c00:      	movq	%rax, 0x40(%rsp)
    3c05:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3c0f:      	movq	%rax, 0x38(%rsp)
    3c14:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3c1e:      	movq	%rax, 0x30(%rsp)
    3c23:      	leaq	0x30(%rsp), %rdi
    3c28:      	movl	$0x2e, %eax
    3c2d:      	movl	$0x6, %ecx
    3c32:      	movl	0x18(%rsp), %edx
    3c36:      	movl	$0x2e, %esi
    3c3b:      	xorl	%eax, %eax
    3c3d:      	callq	*%rcx
    3c3f:      	cmpb	$0x0, 0x78(%rsp)
    3c44:      	jne	0x1d64 <kprobe_unwind_python+0x1d64>
    3c4a:      	xorl	%r12d, %r12d
    3c4d:      	cmpq	$0x0, 0x20(%rsp)
    3c53:      	je	0x45be <kprobe_unwind_python+0x45be>
    3c59:      	movq	(%rsp), %rax
    3c5d:      	cmpb	$0x78, 0x19(%rax)
    3c61:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    3c67:      	movq	(%rsp), %rax
    3c6b:      	cmpb	$0x78, 0x18(%rax)
    3c6f:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    3c75:      	movq	(%rsp), %rax
    3c79:      	cmpb	$0x78, 0x1a(%rax)
    3c7d:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    3c83:      	movq	(%rsp), %rax
    3c87:      	cmpb	$0x0, 0x1b(%rax)
    3c8b:      	js	0x45a2 <kprobe_unwind_python+0x45a2>
    3c91:      	movl	$0x80, %eax
    3c96:      	movl	$0x70, %ecx
    3c9b:      	movq	0x70(%rsp), %rdi
    3ca0:      	movq	0x20(%rsp), %rdx
    3ca5:      	movl	$0x80, %esi
    3caa:      	callq	*%rcx
    3cac:      	testq	%rax, %rax
    3caf:      	jne	0xd60 <kprobe_unwind_python+0xd60>
    3cb5:      	movq	(%rsp), %rax
    3cb9:      	movzbl	0x19(%rax), %ecx
    3cbd:      	movq	0x70(%rsp), %rdx
    3cc2:      	movq	(%rdx,%rcx), %rcx
    3cc6:      	movq	%rcx, 0x28(%rsp)
    3ccb:      	movzbl	0x18(%rax), %ecx
    3ccf:      	movq	(%rdx,%rcx), %r13
    3cd3:      	movq	0x8(%rax), %rax
    3cd7:      	testq	%rax, %rax
    3cda:      	je	0x3ce7 <kprobe_unwind_python+0x3ce7>
    3cdc:      	cmpq	%rax, 0x28(%rsp)
    3ce1:      	je	0x124c <kprobe_unwind_python+0x124c>
    3ce7:      	movq	(%rsp), %rax
    3ceb:      	cmpb	$0x0, 0x22(%rax)
    3cef:      	movzbl	0x1a(%rax), %eax
    3cf3:      	je	0x3d3c <kprobe_unwind_python+0x3d3c>
    3cf5:      	movq	0x70(%rsp), %rsi
    3cfa:      	movq	(%rsi,%rax), %rax
    3cfe:      	movq	(%rsp), %rcx
    3d02:      	movzbl	0x21(%rcx), %edx
    3d06:      	addq	0x28(%rsp), %rdx
    3d0b:      	subq	%rdx, %rax
    3d0e:      	leaq	-0x10000001(%rax), %rdx
    3d15:      	sarl	%eax
    3d17:      	cmpq	$-0x10000003, %rdx      # imm = 0xEFFFFFFD
    3d1e:      	movl	$0xffffffff, %r12d      # imm = 0xFFFFFFFF
    3d24:      	cmovael	%eax, %r12d
    3d28:      	movzbl	0x1b(%rcx), %eax
    3d2c:      	movzbl	(%rsi,%rax), %eax
    3d30:      	cmpb	0x1c(%rcx), %al
    3d33:      	sete	%al
    3d36:      	movl	%eax, 0x78(%rsp)
    3d3a:      	jmp	0x3d4d <kprobe_unwind_python+0x3d4d>
    3d3c:      	movq	0x70(%rsp), %rcx
    3d41:      	movl	(%rcx,%rax), %r12d
    3d45:      	movl	$0x0, 0x78(%rsp)
    3d4d:      	cmpq	$0x0, 0x28(%rsp)
    3d53:      	je	0x3df0 <kprobe_unwind_python+0x3df0>
    3d59:      	movq	(%rsp), %rax
    3d5d:      	cmpb	$-0x44, 0x1d(%rax)
    3d61:      	ja	0x460a <kprobe_unwind_python+0x460a>
    3d67:      	movq	(%rsp), %rax
    3d6b:      	cmpb	$-0x44, 0x1e(%rax)
    3d6f:      	ja	0x460a <kprobe_unwind_python+0x460a>
    3d75:      	movq	(%rsp), %rax
    3d79:      	cmpb	$-0x44, 0x1f(%rax)
    3d7d:      	ja	0x460a <kprobe_unwind_python+0x460a>
    3d83:      	movq	(%rsp), %rax
    3d87:      	cmpb	$-0x44, 0x20(%rax)
    3d8b:      	ja	0x460a <kprobe_unwind_python+0x460a>
    3d91:      	movl	$0xc0, %eax
    3d96:      	movl	$0x70, %ecx
    3d9b:      	movq	0x28(%rsp), %rdx
    3da0:      	movq	%r15, %rdi
    3da3:      	movl	$0xc0, %esi
    3da8:      	callq	*%rcx
    3daa:      	testq	%rax, %rax
    3dad:      	jne	0x2bc <kprobe_unwind_python+0x2bc>
    3db3:      	movq	(%rsp), %rax
    3db7:      	movzbl	0x1d(%rax), %ecx
    3dbb:      	movl	(%r15,%rcx), %ecx
    3dbf:      	movzbl	0x1e(%rax), %edx
    3dc3:      	movl	(%r15,%rdx), %edx
    3dc7:      	movzbl	0x1f(%rax), %esi
    3dcb:      	movl	(%r15,%rsi), %esi
    3dcf:      	movzbl	0x20(%rax), %eax
    3dd3:      	shll	$0x19, %ecx
    3dd6:      	shll	$0x12, %edx
    3dd9:      	addl	%ecx, %edx
    3ddb:      	shll	$0xa, %esi
    3dde:      	addl	%edx, %esi
    3de0:      	addl	(%r15,%rax), %esi
    3de4:      	shlq	$0x20, %r12
    3de8:      	orq	%rsi, %r12
    3deb:      	jmp	0x3f2d <kprobe_unwind_python+0x3f2d>
    3df0:      	cmpl	$0x0, (%r14)
    3df4:      	je	0x3e7e <kprobe_unwind_python+0x3e7e>
    3dfa:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    3e04:      	movq	%rax, 0x57(%rsp)
    3e09:      	movabsq	$0x20786c2578302074, %rax # imm = 0x20786C2578302074
    3e13:      	movq	%rax, 0x50(%rsp)
    3e18:      	movabsq	$0x63656a624f656d61, %rax # imm = 0x63656A624F656D61
    3e22:      	movq	%rax, 0x48(%rsp)
    3e27:      	movabsq	$0x7246795020726f66, %rax # imm = 0x7246795020726F66
    3e31:      	movq	%rax, 0x40(%rsp)
    3e36:      	movabsq	$0x207463656a626f65, %rax # imm = 0x207463656A626F65
    3e40:      	movq	%rax, 0x38(%rsp)
    3e45:      	movabsq	$0x646f63206c6c754e, %rax # imm = 0x646F63206C6C754E
    3e4f:      	movq	%rax, 0x30(%rsp)
    3e54:      	leaq	0x30(%rsp), %rdi
    3e59:      	movl	$0x2f, %eax
    3e5e:      	movl	$0x6, %r8d
    3e64:      	movq	(%rsp), %rax
    3e68:      	movzbl	0x19(%rax), %ecx
    3e6c:      	movq	0x20(%rsp), %rdx
    3e71:      	addq	%rdx, %rcx
    3e74:      	movl	$0x2f, %esi
    3e79:      	xorl	%eax, %eax
    3e7b:      	callq	*%r8
    3e7e:      	movl	$0x1c, 0x18(%rsp)
    3e86:      	movq	(%rip), %rdi            # 0x3e8d <kprobe_unwind_python+0x3e8d>
    3e8d:      	leaq	0x18(%rsp), %rsi
    3e92:      	movl	$0x1, %eax
    3e97:      	callq	*%rax
    3e99:      	testq	%rax, %rax
    3e9c:      	je	0x3ea3 <kprobe_unwind_python+0x3ea3>
    3e9e:      	incq	(%rax)
    3ea1:      	jmp	0x3f1f <kprobe_unwind_python+0x3f1f>
    3ea3:      	cmpl	$0x0, (%r14)
    3ea7:      	je	0x3f1f <kprobe_unwind_python+0x3f1f>
    3ea9:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3eb3:      	movq	%rax, 0x56(%rsp)
    3eb8:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3ec2:      	movq	%rax, 0x50(%rsp)
    3ec7:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3ed1:      	movq	%rax, 0x48(%rsp)
    3ed6:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3ee0:      	movq	%rax, 0x40(%rsp)
    3ee5:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3eef:      	movq	%rax, 0x38(%rsp)
    3ef4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3efe:      	movq	%rax, 0x30(%rsp)
    3f03:      	leaq	0x30(%rsp), %rdi
    3f08:      	movl	$0x2e, %eax
    3f0d:      	movl	$0x6, %ecx
    3f12:      	movl	0x18(%rsp), %edx
    3f16:      	movl	$0x2e, %esi
    3f1b:      	xorl	%eax, %eax
    3f1d:      	callq	*%rcx
    3f1f:      	movq	$-0x2, %r12
    3f26:      	xorl	%eax, %eax
    3f28:      	movq	%rax, 0x28(%rsp)
    3f2d:      	cmpl	$0x0, (%r14)
    3f31:      	je	0x3f82 <kprobe_unwind_python+0x3f82>
    3f33:      	movabsq	$0xa756c2520786c, %rax  # imm = 0xA756C2520786C
    3f3d:      	movq	%rax, 0x40(%rsp)
    3f42:      	movabsq	$0x25206e6f68747950, %rax # imm = 0x25206E6F68747950
    3f4c:      	movq	%rax, 0x38(%rsp)
    3f51:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    3f5b:      	movq	%rax, 0x30(%rsp)
    3f60:      	leaq	0x30(%rsp), %rdi
    3f65:      	movl	$0x18, %eax
    3f6a:      	movl	$0x6, %r8d
    3f70:      	movl	$0x18, %esi
    3f75:      	movq	0x28(%rsp), %rdx
    3f7a:      	movq	%r12, %rcx
    3f7d:      	xorl	%eax, %eax
    3f7f:      	callq	*%r8
    3f82:      	movl	0x2c0(%rbp), %eax
    3f88:      	cmpq	$0x7e, %rax
    3f8c:      	ja	0x1777 <kprobe_unwind_python+0x1777>
    3f92:      	leal	0x1(%rax), %ecx
    3f95:      	movl	%ecx, 0x2c0(%rbp)
    3f9b:      	leaq	(%rax,%rax,2), %rax
    3f9f:      	movq	0x28(%rsp), %rcx
    3fa4:      	movq	%rcx, 0x2d0(%rbp,%rax,8)
    3fac:      	movq	%r12, 0x2d8(%rbp,%rax,8)
    3fb4:      	movb	$0x1, 0x2e0(%rbp,%rax,8)
    3fbc:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    3fc7:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    3fd2:      	movl	$0x16, 0x18(%rsp)
    3fda:      	movq	(%rip), %rdi            # 0x3fe1 <kprobe_unwind_python+0x3fe1>
    3fe1:      	leaq	0x18(%rsp), %rsi
    3fe6:      	movl	$0x1, %eax
    3feb:      	callq	*%rax
    3fed:      	testq	%rax, %rax
    3ff0:      	je	0x3ff7 <kprobe_unwind_python+0x3ff7>
    3ff2:      	incq	(%rax)
    3ff5:      	jmp	0x4073 <kprobe_unwind_python+0x4073>
    3ff7:      	cmpl	$0x0, (%r14)
    3ffb:      	je	0x4073 <kprobe_unwind_python+0x4073>
    3ffd:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4007:      	movq	%rax, 0x56(%rsp)
    400c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4016:      	movq	%rax, 0x50(%rsp)
    401b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4025:      	movq	%rax, 0x48(%rsp)
    402a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4034:      	movq	%rax, 0x40(%rsp)
    4039:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4043:      	movq	%rax, 0x38(%rsp)
    4048:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4052:      	movq	%rax, 0x30(%rsp)
    4057:      	leaq	0x30(%rsp), %rdi
    405c:      	movl	$0x2e, %eax
    4061:      	movl	$0x6, %ecx
    4066:      	movl	0x18(%rsp), %edx
    406a:      	movl	$0x2e, %esi
    406f:      	xorl	%eax, %eax
    4071:      	callq	*%rcx
    4073:      	cmpb	$0x0, 0x78(%rsp)
    4078:      	jne	0x124c <kprobe_unwind_python+0x124c>
    407e:      	xorl	%r12d, %r12d
    4081:      	testq	%r13, %r13
    4084:      	je	0x45be <kprobe_unwind_python+0x45be>
    408a:      	movq	(%rsp), %rax
    408e:      	cmpb	$0x78, 0x19(%rax)
    4092:      	ja	0x460a <kprobe_unwind_python+0x460a>
    4098:      	movq	(%rsp), %rax
    409c:      	cmpb	$0x78, 0x18(%rax)
    40a0:      	ja	0x460a <kprobe_unwind_python+0x460a>
    40a6:      	movq	(%rsp), %rax
    40aa:      	cmpb	$0x78, 0x1a(%rax)
    40ae:      	ja	0x460a <kprobe_unwind_python+0x460a>
    40b4:      	movq	(%rsp), %rax
    40b8:      	cmpb	$0x0, 0x1b(%rax)
    40bc:      	js	0x460a <kprobe_unwind_python+0x460a>
    40c2:      	movl	$0x80, %eax
    40c7:      	movl	$0x70, %ecx
    40cc:      	movq	0x70(%rsp), %rdi
    40d1:      	movl	$0x80, %esi
    40d6:      	movq	%r13, %rdx
    40d9:      	callq	*%rcx
    40db:      	testq	%rax, %rax
    40de:      	jne	0x1d27 <kprobe_unwind_python+0x1d27>
    40e4:      	movq	(%rsp), %rax
    40e8:      	movzbl	0x19(%rax), %ecx
    40ec:      	movq	0x70(%rsp), %rdx
    40f1:      	movq	(%rdx,%rcx), %rcx
    40f5:      	movq	%rcx, 0x28(%rsp)
    40fa:      	movzbl	0x18(%rax), %ecx
    40fe:      	movq	(%rdx,%rcx), %rcx
    4102:      	movq	%rcx, 0x20(%rsp)
    4107:      	movq	0x8(%rax), %rax
    410b:      	testq	%rax, %rax
    410e:      	je	0x411b <kprobe_unwind_python+0x411b>
    4110:      	cmpq	%rax, 0x28(%rsp)
    4115:      	je	0x1d64 <kprobe_unwind_python+0x1d64>
    411b:      	movq	(%rsp), %rax
    411f:      	cmpb	$0x0, 0x22(%rax)
    4123:      	movzbl	0x1a(%rax), %eax
    4127:      	je	0x4170 <kprobe_unwind_python+0x4170>
    4129:      	movq	0x70(%rsp), %rsi
    412e:      	movq	(%rsi,%rax), %rax
    4132:      	movq	(%rsp), %rcx
    4136:      	movzbl	0x21(%rcx), %edx
    413a:      	addq	0x28(%rsp), %rdx
    413f:      	subq	%rdx, %rax
    4142:      	leaq	-0x10000001(%rax), %rdx
    4149:      	sarl	%eax
    414b:      	cmpq	$-0x10000003, %rdx      # imm = 0xEFFFFFFD
    4152:      	movl	$0xffffffff, %r12d      # imm = 0xFFFFFFFF
    4158:      	cmovael	%eax, %r12d
    415c:      	movzbl	0x1b(%rcx), %eax
    4160:      	movzbl	(%rsi,%rax), %eax
    4164:      	cmpb	0x1c(%rcx), %al
    4167:      	sete	%al
    416a:      	movl	%eax, 0x78(%rsp)
    416e:      	jmp	0x4181 <kprobe_unwind_python+0x4181>
    4170:      	movq	0x70(%rsp), %rcx
    4175:      	movl	(%rcx,%rax), %r12d
    4179:      	movl	$0x0, 0x78(%rsp)
    4181:      	cmpq	$0x0, 0x28(%rsp)
    4187:      	je	0x4224 <kprobe_unwind_python+0x4224>
    418d:      	movq	(%rsp), %rax
    4191:      	cmpb	$-0x44, 0x1d(%rax)
    4195:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    419b:      	movq	(%rsp), %rax
    419f:      	cmpb	$-0x44, 0x1e(%rax)
    41a3:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    41a9:      	movq	(%rsp), %rax
    41ad:      	cmpb	$-0x44, 0x1f(%rax)
    41b1:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    41b7:      	movq	(%rsp), %rax
    41bb:      	cmpb	$-0x44, 0x20(%rax)
    41bf:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    41c5:      	movl	$0xc0, %eax
    41ca:      	movl	$0x70, %ecx
    41cf:      	movq	0x28(%rsp), %rdx
    41d4:      	movq	%r15, %rdi
    41d7:      	movl	$0xc0, %esi
    41dc:      	callq	*%rcx
    41de:      	testq	%rax, %rax
    41e1:      	jne	0x1e36 <kprobe_unwind_python+0x1e36>
    41e7:      	movq	(%rsp), %rax
    41eb:      	movzbl	0x1d(%rax), %ecx
    41ef:      	movl	(%r15,%rcx), %ecx
    41f3:      	movzbl	0x1e(%rax), %edx
    41f7:      	movl	(%r15,%rdx), %edx
    41fb:      	movzbl	0x1f(%rax), %esi
    41ff:      	movl	(%r15,%rsi), %esi
    4203:      	movzbl	0x20(%rax), %eax
    4207:      	shll	$0x19, %ecx
    420a:      	shll	$0x12, %edx
    420d:      	addl	%ecx, %edx
    420f:      	shll	$0xa, %esi
    4212:      	addl	%edx, %esi
    4214:      	addl	(%r15,%rax), %esi
    4218:      	shlq	$0x20, %r12
    421c:      	orq	%rsi, %r12
    421f:      	jmp	0x435f <kprobe_unwind_python+0x435f>
    4224:      	cmpl	$0x0, (%r14)
    4228:      	je	0x42b0 <kprobe_unwind_python+0x42b0>
    422e:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    4238:      	movq	%rax, 0x57(%rsp)
    423d:      	movabsq	$0x20786c2578302074, %rax # imm = 0x20786C2578302074
    4247:      	movq	%rax, 0x50(%rsp)
    424c:      	movabsq	$0x63656a624f656d61, %rax # imm = 0x63656A624F656D61
    4256:      	movq	%rax, 0x48(%rsp)
    425b:      	movabsq	$0x7246795020726f66, %rax # imm = 0x7246795020726F66
    4265:      	movq	%rax, 0x40(%rsp)
    426a:      	movabsq	$0x207463656a626f65, %rax # imm = 0x207463656A626F65
    4274:      	movq	%rax, 0x38(%rsp)
    4279:      	movabsq	$0x646f63206c6c754e, %rax # imm = 0x646F63206C6C754E
    4283:      	movq	%rax, 0x30(%rsp)
    4288:      	leaq	0x30(%rsp), %rdi
    428d:      	movl	$0x2f, %eax
    4292:      	movl	$0x6, %r8d
    4298:      	movq	(%rsp), %rax
    429c:      	movzbl	0x19(%rax), %ecx
    42a0:      	addq	%r13, %rcx
    42a3:      	movl	$0x2f, %esi
    42a8:      	movq	%r13, %rdx
    42ab:      	xorl	%eax, %eax
    42ad:      	callq	*%r8
    42b0:      	movl	$0x1c, 0x18(%rsp)
    42b8:      	movq	(%rip), %rdi            # 0x42bf <kprobe_unwind_python+0x42bf>
    42bf:      	leaq	0x18(%rsp), %rsi
    42c4:      	movl	$0x1, %eax
    42c9:      	callq	*%rax
    42cb:      	testq	%rax, %rax
    42ce:      	je	0x42d5 <kprobe_unwind_python+0x42d5>
    42d0:      	incq	(%rax)
    42d3:      	jmp	0x4351 <kprobe_unwind_python+0x4351>
    42d5:      	cmpl	$0x0, (%r14)
    42d9:      	je	0x4351 <kprobe_unwind_python+0x4351>
    42db:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    42e5:      	movq	%rax, 0x56(%rsp)
    42ea:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    42f4:      	movq	%rax, 0x50(%rsp)
    42f9:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4303:      	movq	%rax, 0x48(%rsp)
    4308:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4312:      	movq	%rax, 0x40(%rsp)
    4317:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4321:      	movq	%rax, 0x38(%rsp)
    4326:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4330:      	movq	%rax, 0x30(%rsp)
    4335:      	leaq	0x30(%rsp), %rdi
    433a:      	movl	$0x2e, %eax
    433f:      	movl	$0x6, %ecx
    4344:      	movl	0x18(%rsp), %edx
    4348:      	movl	$0x2e, %esi
    434d:      	xorl	%eax, %eax
    434f:      	callq	*%rcx
    4351:      	movq	$-0x2, %r12
    4358:      	xorl	%eax, %eax
    435a:      	movq	%rax, 0x28(%rsp)
    435f:      	cmpl	$0x0, (%r14)
    4363:      	je	0x43b4 <kprobe_unwind_python+0x43b4>
    4365:      	movabsq	$0xa756c2520786c, %rax  # imm = 0xA756C2520786C
    436f:      	movq	%rax, 0x40(%rsp)
    4374:      	movabsq	$0x25206e6f68747950, %rax # imm = 0x25206E6F68747950
    437e:      	movq	%rax, 0x38(%rsp)
    4383:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    438d:      	movq	%rax, 0x30(%rsp)
    4392:      	leaq	0x30(%rsp), %rdi
    4397:      	movl	$0x18, %eax
    439c:      	movl	$0x6, %r8d
    43a2:      	movl	$0x18, %esi
    43a7:      	movq	0x28(%rsp), %rdx
    43ac:      	movq	%r12, %rcx
    43af:      	xorl	%eax, %eax
    43b1:      	callq	*%r8
    43b4:      	movl	0x2c0(%rbp), %eax
    43ba:      	cmpq	$0x7e, %rax
    43be:      	ja	0x1f31 <kprobe_unwind_python+0x1f31>
    43c4:      	leal	0x1(%rax), %ecx
    43c7:      	movl	%ecx, 0x2c0(%rbp)
    43cd:      	leaq	(%rax,%rax,2), %rax
    43d1:      	movq	0x28(%rsp), %rcx
    43d6:      	movq	%rcx, 0x2d0(%rbp,%rax,8)
    43de:      	movq	%r12, 0x2d8(%rbp,%rax,8)
    43e6:      	movb	$0x1, 0x2e0(%rbp,%rax,8)
    43ee:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    43f9:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    4404:      	movl	$0x16, 0x18(%rsp)
    440c:      	movq	(%rip), %rdi            # 0x4413 <kprobe_unwind_python+0x4413>
    4413:      	leaq	0x18(%rsp), %rsi
    4418:      	movl	$0x1, %eax
    441d:      	callq	*%rax
    441f:      	testq	%rax, %rax
    4422:      	je	0x4429 <kprobe_unwind_python+0x4429>
    4424:      	incq	(%rax)
    4427:      	jmp	0x44a5 <kprobe_unwind_python+0x44a5>
    4429:      	cmpl	$0x0, (%r14)
    442d:      	je	0x44a5 <kprobe_unwind_python+0x44a5>
    442f:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4439:      	movq	%rax, 0x56(%rsp)
    443e:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4448:      	movq	%rax, 0x50(%rsp)
    444d:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4457:      	movq	%rax, 0x48(%rsp)
    445c:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4466:      	movq	%rax, 0x40(%rsp)
    446b:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4475:      	movq	%rax, 0x38(%rsp)
    447a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4484:      	movq	%rax, 0x30(%rsp)
    4489:      	leaq	0x30(%rsp), %rdi
    448e:      	movl	$0x2e, %eax
    4493:      	movl	$0x6, %ecx
    4498:      	movl	0x18(%rsp), %edx
    449c:      	movl	$0x2e, %esi
    44a1:      	xorl	%eax, %eax
    44a3:      	callq	*%rcx
    44a5:      	cmpb	$0x0, 0x78(%rsp)
    44aa:      	jne	0x1d64 <kprobe_unwind_python+0x1d64>
    44b0:      	xorl	%r12d, %r12d
    44b3:      	cmpq	$0x0, 0x20(%rsp)
    44b9:      	je	0x45be <kprobe_unwind_python+0x45be>
    44bf:      	movq	(%rsp), %rax
    44c3:      	cmpb	$0x78, 0x19(%rax)
    44c7:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    44cd:      	movq	(%rsp), %rax
    44d1:      	cmpb	$0x78, 0x18(%rax)
    44d5:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    44db:      	movq	(%rsp), %rax
    44df:      	cmpb	$0x78, 0x1a(%rax)
    44e3:      	ja	0x45a2 <kprobe_unwind_python+0x45a2>
    44e9:      	movq	(%rsp), %rax
    44ed:      	cmpb	$0x0, 0x1b(%rax)
    44f1:      	js	0x45a2 <kprobe_unwind_python+0x45a2>
    44f7:      	movl	$0x80, %eax
    44fc:      	movl	$0x70, %ecx
    4501:      	movq	0x70(%rsp), %rdi
    4506:      	movq	0x20(%rsp), %rdx
    450b:      	movl	$0x80, %esi
    4510:      	callq	*%rcx
    4512:      	testq	%rax, %rax
    4515:      	jne	0xd60 <kprobe_unwind_python+0xd60>
    451b:      	movq	(%rsp), %rax
    451f:      	movzbl	0x19(%rax), %ecx
    4523:      	movq	0x70(%rsp), %rdx
    4528:      	movq	(%rdx,%rcx), %rcx
    452c:      	movq	%rcx, 0x28(%rsp)
    4531:      	movzbl	0x18(%rax), %ecx
    4535:      	movq	(%rdx,%rcx), %r13
    4539:      	movq	0x8(%rax), %rax
    453d:      	testq	%rax, %rax
    4540:      	je	0x454d <kprobe_unwind_python+0x454d>
    4542:      	cmpq	%rax, 0x28(%rsp)
    4547:      	je	0x124c <kprobe_unwind_python+0x124c>
    454d:      	movq	(%rsp), %rax
    4551:      	cmpb	$0x0, 0x22(%rax)
    4555:      	movzbl	0x1a(%rax), %eax
    4559:      	je	0x45c5 <kprobe_unwind_python+0x45c5>
    455b:      	movq	0x70(%rsp), %rsi
    4560:      	movq	(%rsi,%rax), %rax
    4564:      	movq	(%rsp), %rcx
    4568:      	movzbl	0x21(%rcx), %edx
    456c:      	addq	0x28(%rsp), %rdx
    4571:      	subq	%rdx, %rax
    4574:      	leaq	-0x10000001(%rax), %rdx
    457b:      	sarl	%eax
    457d:      	cmpq	$-0x10000003, %rdx      # imm = 0xEFFFFFFD
    4584:      	movl	$0xffffffff, %r12d      # imm = 0xFFFFFFFF
    458a:      	cmovael	%eax, %r12d
    458e:      	movzbl	0x1b(%rcx), %eax
    4592:      	movzbl	(%rsi,%rax), %eax
    4596:      	cmpb	0x1c(%rcx), %al
    4599:      	sete	%al
    459c:      	movl	%eax, 0x70(%rsp)
    45a0:      	jmp	0x45d6 <kprobe_unwind_python+0x45d6>
    45a2:      	xorl	%ecx, %ecx
    45a4:      	movq	0x20(%rsp), %r13
    45a9:      	movl	$0x1, %r12d
    45af:      	movq	0x8(%rsp), %rbx
    45b4:      	movq	0x10(%rsp), %rsi
    45b9:      	jmp	0x16f <kprobe_unwind_python+0x16f>
    45be:      	xorl	%ecx, %ecx
    45c0:      	xorl	%r13d, %r13d
    45c3:      	jmp	0x45af <kprobe_unwind_python+0x45af>
    45c5:      	movq	0x70(%rsp), %rcx
    45ca:      	movl	(%rcx,%rax), %r12d
    45ce:      	movl	$0x0, 0x70(%rsp)
    45d6:      	cmpq	$0x0, 0x28(%rsp)
    45dc:      	je	0x460e <kprobe_unwind_python+0x460e>
    45de:      	movq	(%rsp), %rax
    45e2:      	cmpb	$-0x44, 0x1d(%rax)
    45e6:      	ja	0x460a <kprobe_unwind_python+0x460a>
    45e8:      	movq	(%rsp), %rax
    45ec:      	cmpb	$-0x44, 0x1e(%rax)
    45f0:      	ja	0x460a <kprobe_unwind_python+0x460a>
    45f2:      	movq	(%rsp), %rax
    45f6:      	cmpb	$-0x44, 0x1f(%rax)
    45fa:      	ja	0x460a <kprobe_unwind_python+0x460a>
    45fc:      	movq	(%rsp), %rax
    4600:      	cmpb	$-0x44, 0x20(%rax)
    4604:      	jbe	0x46c4 <kprobe_unwind_python+0x46c4>
    460a:      	xorl	%ecx, %ecx
    460c:      	jmp	0x45a9 <kprobe_unwind_python+0x45a9>
    460e:      	cmpl	$0x0, (%r14)
    4612:      	je	0x469c <kprobe_unwind_python+0x469c>
    4618:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
    4622:      	movq	%rax, 0x57(%rsp)
    4627:      	movabsq	$0x20786c2578302074, %rax # imm = 0x20786C2578302074
    4631:      	movq	%rax, 0x50(%rsp)
    4636:      	movabsq	$0x63656a624f656d61, %rax # imm = 0x63656A624F656D61
    4640:      	movq	%rax, 0x48(%rsp)
    4645:      	movabsq	$0x7246795020726f66, %rax # imm = 0x7246795020726F66
    464f:      	movq	%rax, 0x40(%rsp)
    4654:      	movabsq	$0x207463656a626f65, %rax # imm = 0x207463656A626F65
    465e:      	movq	%rax, 0x38(%rsp)
    4663:      	movabsq	$0x646f63206c6c754e, %rax # imm = 0x646F63206C6C754E
    466d:      	movq	%rax, 0x30(%rsp)
    4672:      	leaq	0x30(%rsp), %rdi
    4677:      	movl	$0x2f, %eax
    467c:      	movl	$0x6, %r8d
    4682:      	movq	(%rsp), %rax
    4686:      	movzbl	0x19(%rax), %ecx
    468a:      	movq	0x20(%rsp), %rdx
    468f:      	addq	%rdx, %rcx
    4692:      	movl	$0x2f, %esi
    4697:      	xorl	%eax, %eax
    4699:      	callq	*%r8
    469c:      	movl	$0x1c, 0x18(%rsp)
    46a4:      	movq	(%rip), %rdi            # 0x46ab <kprobe_unwind_python+0x46ab>
    46ab:      	leaq	0x18(%rsp), %rsi
    46b0:      	movl	$0x1, %eax
    46b5:      	callq	*%rax
    46b7:      	testq	%rax, %rax
    46ba:      	je	0x4723 <kprobe_unwind_python+0x4723>
    46bc:      	incq	(%rax)
    46bf:      	jmp	0x479f <kprobe_unwind_python+0x479f>
    46c4:      	movl	$0xc0, %eax
    46c9:      	movl	$0x70, %ecx
    46ce:      	movq	0x28(%rsp), %rdx
    46d3:      	movq	%r15, %rdi
    46d6:      	movl	$0xc0, %esi
    46db:      	callq	*%rcx
    46dd:      	testq	%rax, %rax
    46e0:      	jne	0x2bc <kprobe_unwind_python+0x2bc>
    46e6:      	movq	(%rsp), %rax
    46ea:      	movzbl	0x1d(%rax), %ecx
    46ee:      	movl	(%r15,%rcx), %ecx
    46f2:      	movzbl	0x1e(%rax), %edx
    46f6:      	movl	(%r15,%rdx), %edx
    46fa:      	movzbl	0x1f(%rax), %esi
    46fe:      	movl	(%r15,%rsi), %esi
    4702:      	movzbl	0x20(%rax), %eax
    4706:      	shll	$0x19, %ecx
    4709:      	shll	$0x12, %edx
    470c:      	addl	%ecx, %edx
    470e:      	shll	$0xa, %esi
    4711:      	addl	%edx, %esi
    4713:      	addl	(%r15,%rax), %esi
    4717:      	shlq	$0x20, %r12
    471b:      	orq	%rsi, %r12
    471e:      	jmp	0x47ad <kprobe_unwind_python+0x47ad>
    4723:      	cmpl	$0x0, (%r14)
    4727:      	je	0x479f <kprobe_unwind_python+0x479f>
    4729:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4733:      	movq	%rax, 0x56(%rsp)
    4738:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4742:      	movq	%rax, 0x50(%rsp)
    4747:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4751:      	movq	%rax, 0x48(%rsp)
    4756:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4760:      	movq	%rax, 0x40(%rsp)
    4765:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    476f:      	movq	%rax, 0x38(%rsp)
    4774:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    477e:      	movq	%rax, 0x30(%rsp)
    4783:      	leaq	0x30(%rsp), %rdi
    4788:      	movl	$0x2e, %eax
    478d:      	movl	$0x6, %ecx
    4792:      	movl	0x18(%rsp), %edx
    4796:      	movl	$0x2e, %esi
    479b:      	xorl	%eax, %eax
    479d:      	callq	*%rcx
    479f:      	movq	$-0x2, %r12
    47a6:      	xorl	%eax, %eax
    47a8:      	movq	%rax, 0x28(%rsp)
    47ad:      	cmpl	$0x0, (%r14)
    47b1:      	je	0x4802 <kprobe_unwind_python+0x4802>
    47b3:      	movabsq	$0xa756c2520786c, %rax  # imm = 0xA756C2520786C
    47bd:      	movq	%rax, 0x40(%rsp)
    47c2:      	movabsq	$0x25206e6f68747950, %rax # imm = 0x25206E6F68747950
    47cc:      	movq	%rax, 0x38(%rsp)
    47d1:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    47db:      	movq	%rax, 0x30(%rsp)
    47e0:      	leaq	0x30(%rsp), %rdi
    47e5:      	movl	$0x18, %eax
    47ea:      	movl	$0x6, %r8d
    47f0:      	movl	$0x18, %esi
    47f5:      	movq	0x28(%rsp), %rdx
    47fa:      	movq	%r12, %rcx
    47fd:      	xorl	%eax, %eax
    47ff:      	callq	*%r8
    4802:      	movl	0x2c0(%rbp), %eax
    4808:      	cmpq	$0x7e, %rax
    480c:      	ja	0x1777 <kprobe_unwind_python+0x1777>
    4812:      	leal	0x1(%rax), %ecx
    4815:      	movl	%ecx, 0x2c0(%rbp)
    481b:      	leaq	(%rax,%rax,2), %rax
    481f:      	movq	0x28(%rsp), %rcx
    4824:      	movq	%rcx, 0x2d0(%rbp,%rax,8)
    482c:      	movq	%r12, 0x2d8(%rbp,%rax,8)
    4834:      	movb	$0x1, 0x2e0(%rbp,%rax,8)
    483c:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    4847:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    4852:      	movl	$0x16, 0x18(%rsp)
    485a:      	movq	(%rip), %rdi            # 0x4861 <kprobe_unwind_python+0x4861>
    4861:      	leaq	0x18(%rsp), %rsi
    4866:      	movl	$0x1, %eax
    486b:      	callq	*%rax
    486d:      	testq	%rax, %rax
    4870:      	je	0x4877 <kprobe_unwind_python+0x4877>
    4872:      	incq	(%rax)
    4875:      	jmp	0x48f3 <kprobe_unwind_python+0x48f3>
    4877:      	cmpl	$0x0, (%r14)
    487b:      	je	0x48f3 <kprobe_unwind_python+0x48f3>
    487d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4887:      	movq	%rax, 0x56(%rsp)
    488c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4896:      	movq	%rax, 0x50(%rsp)
    489b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    48a5:      	movq	%rax, 0x48(%rsp)
    48aa:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    48b4:      	movq	%rax, 0x40(%rsp)
    48b9:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    48c3:      	movq	%rax, 0x38(%rsp)
    48c8:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    48d2:      	movq	%rax, 0x30(%rsp)
    48d7:      	leaq	0x30(%rsp), %rdi
    48dc:      	movl	$0x2e, %eax
    48e1:      	movl	$0x6, %ecx
    48e6:      	movl	0x18(%rsp), %edx
    48ea:      	movl	$0x2e, %esi
    48ef:      	xorl	%eax, %eax
    48f1:      	callq	*%rcx
    48f3:      	cmpb	$0x0, 0x70(%rsp)
    48f8:      	jne	0x124c <kprobe_unwind_python+0x124c>
    48fe:      	movl	$0x4, %r15d
    4904:      	testq	%r13, %r13
    4907:      	je	0x491e <kprobe_unwind_python+0x491e>
    4909:      	movq	%r13, %rdi
    490c:      	xorl	%r12d, %r12d
    490f:      	movq	0x8(%rsp), %rbx
    4914:      	movq	0x10(%rsp), %rsi
    4919:      	jmp	0x17c <kprobe_unwind_python+0x17c>
    491e:      	xorl	%r13d, %r13d
    4921:      	xorl	%r12d, %r12d
    4924:      	jmp	0xd81 <kprobe_unwind_python+0xd81>
