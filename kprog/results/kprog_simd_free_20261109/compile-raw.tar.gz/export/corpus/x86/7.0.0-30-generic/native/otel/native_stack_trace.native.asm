
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/otel/native_stack_trace.native.o:	file format elf64-x86-64

Disassembly of section perf_event/native_tracer_entry:

0000000000000000 <native_tracer_entry>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x108, %rsp            # imm = 0x108
      11:      	movq	%rdi, %rbx
      14:      	movl	$0xe, %eax
      19:      	callq	*%rax
      1b:      	movq	%rax, %r13
      1e:      	movq	%rax, %r12
      21:      	shrq	$0x20, %r12
      25:      	je	0x19a <native_tracer_entry+0x19a>
      2b:      	movl	$0x5, %eax
      30:      	callq	*%rax
      32:      	movq	%rax, %rbp
      35:      	movq	(%rip), %rax            # 0x3c <native_tracer_entry+0x3c>
      3c:      	cmpl	$0x0, (%rax)
      3f:      	jne	0xa38 <native_tracer_entry+0xa38>
      45:      	movl	$0x0, 0x10(%rsp)
      4d:      	movq	(%rip), %rdi            # 0x54 <native_tracer_entry+0x54>
      54:      	leaq	0x10(%rsp), %rsi
      59:      	movl	$0x1, %eax
      5e:      	callq	*%rax
      60:      	movl	$0xffffffff, %r14d      # imm = 0xFFFFFFFF
      66:      	testq	%rax, %rax
      69:      	je	0xc49 <native_tracer_entry+0xc49>
      6f:      	movq	%rax, %r15
      72:      	movq	$0x0, 0xf00(%rax)
      7d:      	movb	$0x0, 0xf30(%rax)
      84:      	movq	$0x0, 0xed0(%rax)
      8f:      	movq	$0x0, 0xed8(%rax)
      9a:      	movq	$0x0, 0xee0(%rax)
      a5:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
      aa:      	movq	%rax, 0xf28(%r15)
      b1:      	movl	$0x0, 0x1380(%r15)
      bc:      	movw	$0x100, 0x1384(%r15)    # imm = 0x100
      c6:      	movq	$0x0, 0xf38(%r15)
      d1:      	movq	$0x0, 0xf40(%r15)
      dc:      	movq	$0x0, 0xf58(%r15)
      e7:      	movq	$0x0, 0xf60(%r15)
      f2:      	movq	$0x0, 0xf68(%r15)
      fd:      	movq	$0x0, 0xf70(%r15)
     108:      	movq	$0x0, 0xf78(%r15)
     113:      	movq	%rax, 0x2bc(%r15)
     11a:      	leaq	0x20(%r15), %rdi
     11e:      	movl	$0x29c, %edx            # imm = 0x29C
     123:      	xorl	%esi, %esi
     125:      	callq	0x12a <native_tracer_entry+0x12a>
     12a:      	movl	$0x1, 0x2c4(%r15)
     135:      	movl	%r12d, (%r15)
     138:      	movl	%r13d, 0x4(%r15)
     13c:      	movq	%rbp, 0x8(%r15)
     140:      	movq	$0x0, 0x2c8(%r15)
     14b:      	leaq	0x10(%r15), %rdi
     14f:      	movl	$0x10, %eax
     154:      	movl	$0x10, %ecx
     159:      	movl	$0x10, %esi
     15e:      	callq	*%rcx
     160:      	testl	%eax, %eax
     162:      	jns	0x32f <native_tracer_entry+0x32f>
     168:      	movl	$0x34, 0xd0(%rsp)
     173:      	movq	(%rip), %rdi            # 0x17a <native_tracer_entry+0x17a>
     17a:      	leaq	0xd0(%rsp), %rsi
     182:      	movl	$0x1, %eax
     187:      	callq	*%rax
     189:      	testq	%rax, %rax
     18c:      	je	0x31f <native_tracer_entry+0x31f>
     192:      	incq	(%rax)
     195:      	jmp	0x32f <native_tracer_entry+0x32f>
     19a:      	movq	(%rip), %rax            # 0x1a1 <native_tracer_entry+0x1a1>
     1a1:      	xorl	%r14d, %r14d
     1a4:      	cmpb	$0x0, (%rax)
     1a7:      	jne	0xc49 <native_tracer_entry+0xc49>
     1ad:      	movl	$0x5, %eax
     1b2:      	callq	*%rax
     1b4:      	movq	%rax, %r15
     1b7:      	movq	(%rip), %r12            # 0x1be <native_tracer_entry+0x1be>
     1be:      	cmpl	$0x0, (%r12)
     1c3:      	jne	0xe0e <native_tracer_entry+0xe0e>
     1c9:      	movl	$0x0, 0x10(%rsp)
     1d1:      	movq	(%rip), %rdi            # 0x1d8 <native_tracer_entry+0x1d8>
     1d8:      	leaq	0x10(%rsp), %rsi
     1dd:      	movl	$0x1, %eax
     1e2:      	callq	*%rax
     1e4:      	testq	%rax, %rax
     1e7:      	je	0x480 <native_tracer_entry+0x480>
     1ed:      	movq	%rax, %r14
     1f0:      	movq	$0x0, 0xf00(%rax)
     1fb:      	movb	$0x0, 0xf30(%rax)
     202:      	movq	$0x0, 0xed0(%rax)
     20d:      	movq	$0x0, 0xed8(%rax)
     218:      	movq	$0x0, 0xee0(%rax)
     223:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     228:      	movq	%rax, 0xf28(%r14)
     22f:      	movl	$0x0, 0x1380(%r14)
     23a:      	movw	$0x100, 0x1384(%r14)    # imm = 0x100
     244:      	movq	$0x0, 0xf38(%r14)
     24f:      	movq	$0x0, 0xf40(%r14)
     25a:      	movq	$0x0, 0xf58(%r14)
     265:      	movq	$0x0, 0xf60(%r14)
     270:      	movq	$0x0, 0xf68(%r14)
     27b:      	movq	$0x0, 0xf70(%r14)
     286:      	movq	$0x0, 0xf78(%r14)
     291:      	movq	%rax, 0x2bc(%r14)
     298:      	leaq	0x20(%r14), %rdi
     29c:      	movl	$0x29c, %edx            # imm = 0x29C
     2a1:      	xorl	%esi, %esi
     2a3:      	callq	0x2a8 <native_tracer_entry+0x2a8>
     2a8:      	movl	$0x1, 0x2c4(%r14)
     2b3:      	movl	$0x0, (%r14)
     2ba:      	movl	%r13d, 0x4(%r14)
     2be:      	movq	%r15, 0x8(%r14)
     2c2:      	movq	$0x0, 0x2c8(%r14)
     2cd:      	movq	%r14, %rdi
     2d0:      	addq	$0x10, %rdi
     2d4:      	movl	$0x10, %eax
     2d9:      	movl	$0x10, %ecx
     2de:      	movl	$0x10, %esi
     2e3:      	callq	*%rcx
     2e5:      	testl	%eax, %eax
     2e7:      	jns	0x64d <native_tracer_entry+0x64d>
     2ed:      	movl	$0x34, 0xd0(%rsp)
     2f8:      	movq	(%rip), %rdi            # 0x2ff <native_tracer_entry+0x2ff>
     2ff:      	leaq	0xd0(%rsp), %rsi
     307:      	movl	$0x1, %eax
     30c:      	callq	*%rax
     30e:      	testq	%rax, %rax
     311:      	je	0x642 <native_tracer_entry+0x642>
     317:      	incq	(%rax)
     31a:      	jmp	0x64d <native_tracer_entry+0x64d>
     31f:      	movq	(%rip), %rax            # 0x326 <native_tracer_entry+0x326>
     326:      	cmpl	$0x0, (%rax)
     329:      	jne	0xf3c <native_tracer_entry+0xf3c>
     32f:      	movq	(%rip), %rsi            # 0x336 <native_tracer_entry+0x336>
     336:      	movl	$0x400, %eax            # imm = 0x400
     33b:      	movl	$0x1b, %ecx
     340:      	movl	$0x400, %edx            # imm = 0x400
     345:      	movq	%rbx, %rdi
     348:      	callq	*%rcx
     34a:      	movl	%eax, 0x2bc(%r15)
     351:      	movq	(%rip), %rax            # 0x358 <native_tracer_entry+0x358>
     358:      	cmpl	$0x0, (%rax)
     35b:      	jne	0xa82 <native_tracer_entry+0xa82>
     361:      	cmpq	$0x2b, 0xa0(%rbx)
     369:      	jne	0xadc <native_tracer_entry+0xadc>
     36f:      	cmpq	$0x23, 0x88(%rbx)
     377:      	jne	0x383 <native_tracer_entry+0x383>
     379:      	movl	$0xfb1, %ebp            # imm = 0xFB1
     37e:      	jmp	0xb79 <native_tracer_entry+0xb79>
     383:      	movq	0x80(%rbx), %rax
     38a:      	movq	%rax, 0xed0(%r15)
     391:      	movq	0x98(%rbx), %rax
     398:      	movq	%rax, 0xed8(%r15)
     39f:      	movq	0x20(%rbx), %rax
     3a3:      	movq	%rax, 0xee0(%r15)
     3aa:      	movq	0x50(%rbx), %rax
     3ae:      	movq	%rax, 0xee8(%r15)
     3b5:      	movq	0x40(%rbx), %rax
     3b9:      	movq	%rax, 0xef0(%r15)
     3c0:      	movq	0x30(%rbx), %rax
     3c4:      	movq	%rax, 0xef8(%r15)
     3cb:      	movq	0x10(%rbx), %rax
     3cf:      	movq	%rax, 0xf00(%r15)
     3d6:      	movq	(%rbx), %rax
     3d9:      	movq	%rax, 0xf08(%r15)
     3e0:      	movb	$0x0, 0xf30(%r15)
     3e8:      	movq	(%rip), %rax            # 0x3ef <native_tracer_entry+0x3ef>
     3ef:      	cmpl	$0x0, (%rax)
     3f2:      	jne	0xd03 <native_tracer_entry+0xd03>
     3f8:      	movl	$0x60, 0x10(%rsp)
     400:      	movbel	%r12d, 0x14(%rsp)
     407:      	movq	$0x0, 0x18(%rsp)
     410:      	movq	(%rip), %rdi            # 0x417 <native_tracer_entry+0x417>
     417:      	leaq	0x10(%rsp), %rsi
     41c:      	movl	$0x1, %eax
     421:      	callq	*%rax
     423:      	testq	%rax, %rax
     426:      	je	0x48b <native_tracer_entry+0x48b>
     428:      	movq	%r15, %rax
     42b:      	addq	$0xed0, %rax            # imm = 0xED0
     431:      	movq	(%rax), %r13
     434:      	movq	(%rip), %rax            # 0x43b <native_tracer_entry+0x43b>
     43b:      	movl	(%rax), %eax
     43d:      	testq	%r13, %r13
     440:      	je	0x554 <native_tracer_entry+0x554>
     446:      	testl	%eax, %eax
     448:      	jne	0xfba <native_tracer_entry+0xfba>
     44e:      	movq	%r13, %rax
     451:      	shrq	$0x38, %rax
     455:      	je	0x104c <native_tracer_entry+0x104c>
     45b:      	movq	(%rip), %rax            # 0x462 <native_tracer_entry+0x462>
     462:      	cmpl	$0x0, (%rax)
     465:      	jne	0x136f <native_tracer_entry+0x136f>
     46b:      	movl	$0xb, 0xf28(%r15)
     476:      	movl	$0xfab, %ebp            # imm = 0xFAB
     47b:      	jmp	0xb79 <native_tracer_entry+0xb79>
     480:      	movl	$0xffffffff, %r14d      # imm = 0xFFFFFFFF
     486:      	jmp	0xc49 <native_tracer_entry+0xc49>
     48b:      	movq	%r13, 0xc8(%rsp)
     493:      	movl	%r12d, 0x8(%rsp)
     498:      	movq	(%rip), %rdi            # 0x49f <native_tracer_entry+0x49f>
     49f:      	leaq	0x8(%rsp), %rsi
     4a4:      	movl	$0x1, %eax
     4a9:      	callq	*%rax
     4ab:      	movq	%rax, %r14
     4ae:      	movl	$0x5, %eax
     4b3:      	callq	*%rax
     4b5:      	testq	%r14, %r14
     4b8:      	je	0x571 <native_tracer_entry+0x571>
     4be:      	movq	(%r14), %rcx
     4c1:      	movq	%rcx, %rsi
     4c4:      	andq	$-0x20, %rsi
     4c8:      	movq	%rax, %rdx
     4cb:      	subq	%rsi, %rdx
     4ce:      	movl	%ecx, %esi
     4d0:      	andb	$0xf, %sil
     4d4:      	movl	$0x5f5e100, %edi        # imm = 0x5F5E100
     4d9:      	shlxq	%rsi, %rdi, %rsi
     4de:      	cmpq	%rsi, %rdx
     4e1:      	jae	0x575 <native_tracer_entry+0x575>
     4e7:      	movq	(%rip), %rax            # 0x4ee <native_tracer_entry+0x4ee>
     4ee:      	cmpl	$0x0, (%rax)
     4f1:      	je	0xa30 <native_tracer_entry+0xa30>
     4f7:      	movabsq	$0xa74736166206f, %rax  # imm = 0xA74736166206F
     501:      	movq	%rax, 0x28(%rsp)
     506:      	movabsq	$0x6f74203a64657469, %rax # imm = 0x6F74203A64657469
     510:      	movq	%rax, 0x20(%rsp)
     515:      	movabsq	$0x6d696c20746e6576, %rax # imm = 0x6D696C20746E6576
     51f:      	movq	%rax, 0x18(%rsp)
     524:      	movabsq	$0x6520642520444950, %rax # imm = 0x6520642520444950
     52e:      	movq	%rax, 0x10(%rsp)
     533:      	leaq	0x10(%rsp), %rdi
     538:      	movl	$0x20, %eax
     53d:      	movl	$0x6, %ecx
     542:      	movl	0x8(%rsp), %edx
     546:      	movl	$0x20, %esi
     54b:      	xorl	%eax, %eax
     54d:      	callq	*%rcx
     54f:      	jmp	0xa30 <native_tracer_entry+0xa30>
     554:      	testl	%eax, %eax
     556:      	jne	0x12f3 <native_tracer_entry+0x12f3>
     55c:      	movl	$0x1, 0xf28(%r15)
     567:      	movl	$0xfad, %ebp            # imm = 0xFAD
     56c:      	jmp	0xb79 <native_tracer_entry+0xb79>
     571:      	xorl	%ebp, %ebp
     573:      	jmp	0x5a8 <native_tracer_entry+0x5a8>
     575:      	movl	%ecx, %ebp
     577:      	andb	$0x10, %bpl
     57b:      	movl	$0xffffffff, %edi       # imm = 0xFFFFFFFF
     580:      	addq	%rdi, %rsi
     583:      	addq	$0x2a05f201, %rsi       # imm = 0x2A05F201
     58a:      	cmpq	%rsi, %rdx
     58d:      	jae	0x5a8 <native_tracer_entry+0x5a8>
     58f:      	andl	$0xf, %ecx
     592:      	xorl	%edx, %edx
     594:      	testb	%bpl, %bpl
     597:      	sete	%dl
     59a:      	leal	0x4(,%rdx,4), %edx
     5a1:      	cmpl	%edx, %ecx
     5a3:      	adcb	$0x0, %cl
     5a6:      	jmp	0x5aa <native_tracer_entry+0x5aa>
     5a8:      	xorl	%ecx, %ecx
     5aa:      	movq	(%rip), %rdx            # 0x5b1 <native_tracer_entry+0x5b1>
     5b1:      	cmpl	$0x0, (%rdx)
     5b4:      	movzbl	%cl, %r14d
     5b8:      	jne	0x128b <native_tracer_entry+0x128b>
     5be:      	andq	$-0x20, %rax
     5c2:      	movzbl	%bpl, %ecx
     5c6:      	orq	%rax, %rcx
     5c9:      	orq	%rcx, %r14
     5cc:      	movq	%r14, 0xd0(%rsp)
     5d4:      	movq	(%rip), %rdi            # 0x5db <native_tracer_entry+0x5db>
     5db:      	xorl	%eax, %eax
     5dd:      	leaq	0x8(%rsp), %rsi
     5e2:      	leaq	0xd0(%rsp), %rdx
     5ea:      	movl	$0x2, %r8d
     5f0:      	xorl	%ecx, %ecx
     5f2:      	callq	*%r8
     5f5:      	testl	%eax, %eax
     5f7:      	je	0x6fd <native_tracer_entry+0x6fd>
     5fd:      	movq	(%rip), %rcx            # 0x604 <native_tracer_entry+0x604>
     604:      	cmpl	$0x0, (%rcx)
     607:      	jne	0x13d2 <native_tracer_entry+0x13d2>
     60d:      	movl	$0x3d, 0xc4(%rsp)
     618:      	movq	(%rip), %rdi            # 0x61f <native_tracer_entry+0x61f>
     61f:      	leaq	0xc4(%rsp), %rsi
     627:      	movl	$0x1, %eax
     62c:      	callq	*%rax
     62e:      	testq	%rax, %rax
     631:      	je	0x7a6 <native_tracer_entry+0x7a6>
     637:      	incq	(%rax)
     63a:      	xorl	%r14d, %r14d
     63d:      	jmp	0xc49 <native_tracer_entry+0xc49>
     642:      	cmpl	$0x0, (%r12)
     647:      	jne	0x1433 <native_tracer_entry+0x1433>
     64d:      	movq	(%rip), %rsi            # 0x654 <native_tracer_entry+0x654>
     654:      	movl	$0x400, %eax            # imm = 0x400
     659:      	movl	$0x1b, %ecx
     65e:      	movl	$0x400, %edx            # imm = 0x400
     663:      	movq	%rbx, %rdi
     666:      	callq	*%rcx
     668:      	movl	%eax, 0x2bc(%r14)
     66f:      	cmpl	$0x0, (%r12)
     674:      	jne	0xe58 <native_tracer_entry+0xe58>
     67a:      	movl	$0x0, 0x10(%rsp)
     682:      	movq	(%rip), %rdi            # 0x689 <native_tracer_entry+0x689>
     689:      	leaq	0x10(%rsp), %rsi
     68e:      	movl	$0x1, %eax
     693:      	callq	*%rax
     695:      	testq	%rax, %rax
     698:      	je	0x6e9 <native_tracer_entry+0x6e9>
     69a:      	movzbl	0x1384(%rax), %ecx
     6a1:      	cmpb	$0x1d, %cl
     6a4:      	jb	0x783 <native_tracer_entry+0x783>
     6aa:      	movq	%rax, %r14
     6ad:      	movl	$0x5, 0xf2c(%rax)
     6b7:      	movl	$0x44, 0xd0(%rsp)
     6c2:      	movq	(%rip), %rdi            # 0x6c9 <native_tracer_entry+0x6c9>
     6c9:      	leaq	0xd0(%rsp), %rsi
     6d1:      	movl	$0x1, %eax
     6d6:      	callq	*%rax
     6d8:      	testq	%rax, %rax
     6db:      	je	0x76d <native_tracer_entry+0x76d>
     6e1:      	incq	(%rax)
     6e4:      	jmp	0x778 <native_tracer_entry+0x778>
     6e9:      	movq	(%rip), %rsi            # 0x6f0 <native_tracer_entry+0x6f0>
     6f0:      	xorl	%r14d, %r14d
     6f3:      	movl	$0xc, %eax
     6f8:      	jmp	0x79a <native_tracer_entry+0x79a>
     6fd:      	movb	$0x1, 0xf(%rsp)
     702:      	movq	(%rip), %rdi            # 0x709 <native_tracer_entry+0x709>
     709:      	xorl	%eax, %eax
     70b:      	leaq	0xc8(%rsp), %rsi
     713:      	leaq	0xf(%rsp), %rdx
     718:      	movl	$0x2, %r8d
     71e:      	xorl	%ecx, %ecx
     720:      	callq	*%r8
     723:      	testl	%eax, %eax
     725:      	je	0x834 <native_tracer_entry+0x834>
     72b:      	movq	(%rip), %rcx            # 0x732 <native_tracer_entry+0x732>
     732:      	cmpl	$0x0, (%rcx)
     735:      	jne	0x16a0 <native_tracer_entry+0x16a0>
     73b:      	movl	$0x3e, 0xd0(%rsp)
     746:      	movq	(%rip), %rdi            # 0x74d <native_tracer_entry+0x74d>
     74d:      	leaq	0xd0(%rsp), %rsi
     755:      	movl	$0x1, %eax
     75a:      	callq	*%rax
     75c:      	testq	%rax, %rax
     75f:      	je	0x8a5 <native_tracer_entry+0x8a5>
     765:      	incq	(%rax)
     768:      	jmp	0xa30 <native_tracer_entry+0xa30>
     76d:      	cmpl	$0x0, (%r12)
     772:      	jne	0x150d <native_tracer_entry+0x150d>
     778:      	movq	%r14, %rax
     77b:      	movzbl	0x1384(%r14), %ecx
     783:      	incb	%cl
     785:      	movb	%cl, 0x1384(%rax)
     78b:      	movq	(%rip), %rsi            # 0x792 <native_tracer_entry+0x792>
     792:      	xorl	%r14d, %r14d
     795:      	movl	$0xc, %eax
     79a:      	movq	%rbx, %rdi
     79d:      	xorl	%edx, %edx
     79f:      	callq	*%rax
     7a1:      	jmp	0xc49 <native_tracer_entry+0xc49>
     7a6:      	movq	(%rip), %rax            # 0x7ad <native_tracer_entry+0x7ad>
     7ad:      	cmpl	$0x0, (%rax)
     7b0:      	je	0xa30 <native_tracer_entry+0xa30>
     7b6:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     7c0:      	movq	%rax, 0x36(%rsp)
     7c5:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     7cf:      	movq	%rax, 0x30(%rsp)
     7d4:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     7de:      	movq	%rax, 0x28(%rsp)
     7e3:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     7ed:      	movq	%rax, 0x20(%rsp)
     7f2:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     7fc:      	movq	%rax, 0x18(%rsp)
     801:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     80b:      	movq	%rax, 0x10(%rsp)
     810:      	leaq	0x10(%rsp), %rdi
     815:      	movl	$0x2e, %eax
     81a:      	movl	$0x6, %ecx
     81f:      	movl	0xc4(%rsp), %edx
     826:      	movl	$0x2e, %esi
     82b:      	xorl	%eax, %eax
     82d:      	callq	*%rcx
     82f:      	jmp	0xa30 <native_tracer_entry+0xa30>
     834:      	movl	$0x1, 0xc4(%rsp)
     83f:      	movb	$0x1, 0x8(%rsp)
     844:      	movq	(%rip), %rdi            # 0x84b <native_tracer_entry+0x84b>
     84b:      	leaq	0xc4(%rsp), %rsi
     853:      	leaq	0x8(%rsp), %rdx
     858:      	movl	$0x1, %eax
     85d:      	movl	$0x2, %r8d
     863:      	movl	$0x1, %ecx
     868:      	callq	*%r8
     86b:      	testl	%eax, %eax
     86d:      	js	0x936 <native_tracer_entry+0x936>
     873:      	movl	$0x42, 0xd0(%rsp)
     87e:      	movq	(%rip), %rdi            # 0x885 <native_tracer_entry+0x885>
     885:      	leaq	0xd0(%rsp), %rsi
     88d:      	movl	$0x1, %eax
     892:      	callq	*%rax
     894:      	testq	%rax, %rax
     897:      	je	0x997 <native_tracer_entry+0x997>
     89d:      	incq	(%rax)
     8a0:      	jmp	0x9a7 <native_tracer_entry+0x9a7>
     8a5:      	movq	(%rip), %rax            # 0x8ac <native_tracer_entry+0x8ac>
     8ac:      	cmpl	$0x0, (%rax)
     8af:      	je	0xa30 <native_tracer_entry+0xa30>
     8b5:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     8bf:      	movq	%rax, 0x36(%rsp)
     8c4:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     8ce:      	movq	%rax, 0x30(%rsp)
     8d3:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     8dd:      	movq	%rax, 0x28(%rsp)
     8e2:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     8ec:      	movq	%rax, 0x20(%rsp)
     8f1:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     8fb:      	movq	%rax, 0x18(%rsp)
     900:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     90a:      	movq	%rax, 0x10(%rsp)
     90f:      	leaq	0x10(%rsp), %rdi
     914:      	movl	$0x2e, %eax
     919:      	movl	$0x6, %ecx
     91e:      	movl	0xd0(%rsp), %edx
     925:      	movl	$0x2e, %esi
     92a:      	xorl	%eax, %eax
     92c:      	callq	*%rcx
     92e:      	xorl	%r14d, %r14d
     931:      	jmp	0xc49 <native_tracer_entry+0xc49>
     936:      	movq	(%rip), %rax            # 0x93d <native_tracer_entry+0x93d>
     93d:      	cmpl	$0x0, (%rax)
     940:      	je	0x9f6 <native_tracer_entry+0x9f6>
     946:      	movabsq	$0xa64657469626968, %rax # imm = 0xA64657469626968
     950:      	movq	%rax, 0x20(%rsp)
     955:      	movabsq	$0x6e69206425206570, %rax # imm = 0x6E69206425206570
     95f:      	movq	%rax, 0x18(%rsp)
     964:      	movabsq	$0x797420746e657645, %rax # imm = 0x797420746E657645
     96e:      	movq	%rax, 0x10(%rsp)
     973:      	movb	$0x0, 0x28(%rsp)
     978:      	leaq	0x10(%rsp), %rdi
     97d:      	movl	$0x19, %eax
     982:      	movl	$0x6, %ecx
     987:      	movl	$0x19, %esi
     98c:      	movl	$0x1, %edx
     991:      	xorl	%eax, %eax
     993:      	callq	*%rcx
     995:      	jmp	0x9f6 <native_tracer_entry+0x9f6>
     997:      	movq	(%rip), %rax            # 0x99e <native_tracer_entry+0x99e>
     99e:      	cmpl	$0x0, (%rax)
     9a1:      	jne	0x18d0 <native_tracer_entry+0x18d0>
     9a7:      	movl	$0x1, 0xd0(%rsp)
     9b2:      	movq	(%rip), %rsi            # 0x9b9 <native_tracer_entry+0x9b9>
     9b9:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     9be:      	leaq	0xd0(%rsp), %rcx
     9c6:      	movl	$0x4, %edx
     9cb:      	movl	$0x19, %r9d
     9d1:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     9d6:      	movq	%rbx, %rdi
     9d9:      	movl	$0x4, %r8d
     9df:      	callq	*%r9
     9e2:      	testl	%eax, %eax
     9e4:      	jns	0x9f6 <native_tracer_entry+0x9f6>
     9e6:      	movq	(%rip), %rcx            # 0x9ed <native_tracer_entry+0x9ed>
     9ed:      	cmpl	$0x0, (%rcx)
     9f0:      	jne	0x1841 <native_tracer_entry+0x1841>
     9f6:      	movl	$0x3f, 0xd0(%rsp)
     a01:      	movq	(%rip), %rdi            # 0xa08 <native_tracer_entry+0xa08>
     a08:      	leaq	0xd0(%rsp), %rsi
     a10:      	movl	$0x1, %eax
     a15:      	callq	*%rax
     a17:      	testq	%rax, %rax
     a1a:      	jne	0x637 <native_tracer_entry+0x637>
     a20:      	movq	(%rip), %rax            # 0xa27 <native_tracer_entry+0xa27>
     a27:      	cmpl	$0x0, (%rax)
     a2a:      	jne	0x17c3 <native_tracer_entry+0x17c3>
     a30:      	xorl	%r14d, %r14d
     a33:      	jmp	0xc49 <native_tracer_entry+0xc49>
     a38:      	movabsq	$0xa64726f636572, %rax  # imm = 0xA64726F636572
     a42:      	movq	%rax, 0x1e(%rsp)
     a47:      	movabsq	$0x6572205550432067, %rax # imm = 0x6572205550432067
     a51:      	movq	%rax, 0x18(%rsp)
     a56:      	movabsq	$0x6e69747465736552, %rax # imm = 0x6E69747465736552
     a60:      	movq	%rax, 0x10(%rsp)
     a65:      	leaq	0x10(%rsp), %rdi
     a6a:      	movl	$0x16, %eax
     a6f:      	movl	$0x6, %ecx
     a74:      	movl	$0x16, %esi
     a79:      	xorl	%eax, %eax
     a7b:      	callq	*%rcx
     a7d:      	jmp	0x45 <native_tracer_entry+0x45>
     a82:      	movabsq	$0xa6425203d2064, %rax  # imm = 0xA6425203D2064
     a8c:      	movq	%rax, 0x1e(%rsp)
     a91:      	movabsq	$0x206469206b636174, %rax # imm = 0x206469206B636174
     a9b:      	movq	%rax, 0x18(%rsp)
     aa0:      	movabsq	$0x73206c656e72656b, %rax # imm = 0x73206C656E72656B
     aaa:      	movq	%rax, 0x10(%rsp)
     aaf:      	leaq	0x10(%rsp), %rdi
     ab4:      	movl	$0x16, %eax
     ab9:      	movl	$0x6, %ecx
     abe:      	movl	0x2bc(%r15), %edx
     ac5:      	movl	$0x16, %esi
     aca:      	xorl	%eax, %eax
     acc:      	callq	*%rcx
     ace:      	cmpq	$0x2b, 0xa0(%rbx)
     ad6:      	je	0x36f <native_tracer_entry+0x36f>
     adc:      	movl	$0x23, %eax
     ae1:      	callq	*%rax
     ae3:      	movq	(%rip), %rcx            # 0xaea <native_tracer_entry+0xaea>
     aea:      	movl	(%rcx), %edx
     aec:      	addq	%rax, %rdx
     aef:      	leaq	0x10(%rsp), %rdi
     af4:      	movl	$0x8, %eax
     af9:      	movl	$0x71, %ecx
     afe:      	movl	$0x8, %esi
     b03:      	callq	*%rcx
     b05:      	testq	%rax, %rax
     b08:      	jne	0xb39 <native_tracer_entry+0xb39>
     b0a:      	movq	(%rip), %rax            # 0xb11 <native_tracer_entry+0xb11>
     b11:      	movl	(%rax), %edx
     b13:      	addq	0x10(%rsp), %rdx
     b18:      	je	0xb39 <native_tracer_entry+0xb39>
     b1a:      	leaq	0x10(%rsp), %rdi
     b1f:      	movl	$0xa8, %eax
     b24:      	movl	$0x71, %ecx
     b29:      	movl	$0xa8, %esi
     b2e:      	callq	*%rcx
     b30:      	testq	%rax, %rax
     b33:      	je	0xc5e <native_tracer_entry+0xc5e>
     b39:      	movl	$0x52, 0xc8(%rsp)
     b44:      	movq	(%rip), %rdi            # 0xb4b <native_tracer_entry+0xb4b>
     b4b:      	leaq	0xc8(%rsp), %rsi
     b53:      	movl	$0x1, %eax
     b58:      	callq	*%rax
     b5a:      	testq	%rax, %rax
     b5d:      	je	0xb64 <native_tracer_entry+0xb64>
     b5f:      	incq	(%rax)
     b62:      	jmp	0xb74 <native_tracer_entry+0xb74>
     b64:      	movq	(%rip), %rax            # 0xb6b <native_tracer_entry+0xb6b>
     b6b:      	cmpl	$0x0, (%rax)
     b6e:      	jne	0xea9 <native_tracer_entry+0xea9>
     b74:      	movl	$0xfa9, %ebp            # imm = 0xFA9
     b79:      	xorl	%r12d, %r12d
     b7c:      	movl	%ebp, 0xf2c(%r15)
     b83:      	movl	$0x0, 0x10(%rsp)
     b8b:      	movq	(%rip), %rdi            # 0xb92 <native_tracer_entry+0xb92>
     b92:      	leaq	0x10(%rsp), %rsi
     b97:      	movl	$0x1, %eax
     b9c:      	callq	*%rax
     b9e:      	testq	%rax, %rax
     ba1:      	je	0xbea <native_tracer_entry+0xbea>
     ba3:      	movzbl	0x1384(%rax), %ecx
     baa:      	movl	%r12d, %edx
     bad:      	cmpb	$0x1d, %cl
     bb0:      	jb	0xc17 <native_tracer_entry+0xc17>
     bb2:      	movq	%rax, %r15
     bb5:      	movl	$0x5, 0xf2c(%rax)
     bbf:      	movl	$0x44, 0xd0(%rsp)
     bca:      	movq	(%rip), %rdi            # 0xbd1 <native_tracer_entry+0xbd1>
     bd1:      	leaq	0xd0(%rsp), %rsi
     bd9:      	movl	$0x1, %eax
     bde:      	callq	*%rax
     be0:      	testq	%rax, %rax
     be3:      	je	0xbfa <native_tracer_entry+0xbfa>
     be5:      	incq	(%rax)
     be8:      	jmp	0xc0a <native_tracer_entry+0xc0a>
     bea:      	movq	(%rip), %rcx            # 0xbf1 <native_tracer_entry+0xbf1>
     bf1:      	xorl	%edx, %edx
     bf3:      	movl	$0xc, %eax
     bf8:      	jmp	0xc2d <native_tracer_entry+0xc2d>
     bfa:      	movq	(%rip), %rax            # 0xc01 <native_tracer_entry+0xc01>
     c01:      	cmpl	$0x0, (%rax)
     c04:      	jne	0x120d <native_tracer_entry+0x120d>
     c0a:      	movq	%r15, %rax
     c0d:      	movzbl	0x1384(%r15), %ecx
     c15:      	xorl	%edx, %edx
     c17:      	incb	%cl
     c19:      	movb	%cl, 0x1384(%rax)
     c1f:      	movl	%edx, %ecx
     c21:      	movq	(%rip), %rsi            # 0xc28 <native_tracer_entry+0xc28>
     c28:      	movl	$0xc, %eax
     c2d:      	movq	(%rip), %rsi            # 0xc34 <native_tracer_entry+0xc34>
     c34:      	movq	%rbx, %rdi
     c37:      	callq	*%rax
     c39:      	movq	(%rip), %rax            # 0xc40 <native_tracer_entry+0xc40>
     c40:      	cmpl	$0x0, (%rax)
     c43:      	jne	0xd8c <native_tracer_entry+0xd8c>
     c49:      	movl	%r14d, %eax
     c4c:      	addq	$0x108, %rsp            # imm = 0x108
     c53:      	popq	%rbx
     c54:      	popq	%r12
     c56:      	popq	%r13
     c58:      	popq	%r14
     c5a:      	popq	%r15
     c5c:      	popq	%rbp
     c5d:      	retq
     c5e:      	cmpq	$0x2b, 0xb0(%rsp)
     c67:      	jne	0xd82 <native_tracer_entry+0xd82>
     c6d:      	cmpq	$0x23, 0x98(%rsp)
     c76:      	je	0x379 <native_tracer_entry+0x379>
     c7c:      	movq	0x90(%rsp), %rax
     c84:      	movq	%rax, 0xed0(%r15)
     c8b:      	movq	0xa8(%rsp), %rax
     c93:      	movq	%rax, 0xed8(%r15)
     c9a:      	movq	0x30(%rsp), %rax
     c9f:      	movq	%rax, 0xee0(%r15)
     ca6:      	movq	0x60(%rsp), %rax
     cab:      	movq	%rax, 0xee8(%r15)
     cb2:      	movq	0x50(%rsp), %rax
     cb7:      	movq	%rax, 0xef0(%r15)
     cbe:      	movq	0x40(%rsp), %rax
     cc3:      	movq	%rax, 0xef8(%r15)
     cca:      	movq	0x20(%rsp), %rax
     ccf:      	movq	%rax, 0xf00(%r15)
     cd6:      	movq	0x10(%rsp), %rax
     cdb:      	movq	%rax, 0xf08(%r15)
     ce2:      	cmpq	$-0x1, 0x88(%rsp)
     ceb:      	setne	0xf30(%r15)
     cf3:      	movq	(%rip), %rax            # 0xcfa <native_tracer_entry+0xcfa>
     cfa:      	cmpl	$0x0, (%rax)
     cfd:      	je	0x3f8 <native_tracer_entry+0x3f8>
     d03:      	movabsq	$0xa786c6c25203a, %rax  # imm = 0xA786C6C25203A
     d0d:      	movq	%rax, 0x2f(%rsp)
     d12:      	movabsq	$0x3a706620786c6c25, %rax # imm = 0x3A706620786C6C25
     d1c:      	movq	%rax, 0x28(%rsp)
     d21:      	movabsq	$0x203a707320786c6c, %rax # imm = 0x203A707320786C6C
     d2b:      	movq	%rax, 0x20(%rsp)
     d30:      	movabsq	$0x25203a6370203a73, %rax # imm = 0x25203A6370203A73
     d3a:      	movq	%rax, 0x18(%rsp)
     d3f:      	movabsq	$0x6765722064616552, %rax # imm = 0x6765722064616552
     d49:      	movq	%rax, 0x10(%rsp)
     d4e:      	leaq	0x10(%rsp), %rdi
     d53:      	movl	$0x27, %eax
     d58:      	movl	$0x6, %r9d
     d5e:      	movq	0xed0(%r15), %rdx
     d65:      	movq	0xed8(%r15), %rcx
     d6c:      	movq	0xee0(%r15), %r8
     d73:      	movl	$0x27, %esi
     d78:      	xorl	%eax, %eax
     d7a:      	callq	*%r9
     d7d:      	jmp	0x3f8 <native_tracer_entry+0x3f8>
     d82:      	xorl	%r12d, %r12d
     d85:      	xorl	%ebp, %ebp
     d87:      	jmp	0xb7c <native_tracer_entry+0xb7c>
     d8c:      	movabsq	$0x746e655f72656361, %rax # imm = 0x746E655F72656361
     d96:      	movq	%rax, 0x38(%rsp)
     d9b:      	movabsq	$0x72745f6576697461, %rax # imm = 0x72745F6576697461
     da5:      	movq	%rax, 0x30(%rsp)
     daa:      	movabsq	$0x6e206e6920642520, %rax # imm = 0x6E206E6920642520
     db4:      	movq	%rax, 0x28(%rsp)
     db9:      	movabsq	$0x726f662064656c69, %rax # imm = 0x726F662064656C69
     dc3:      	movq	%rax, 0x20(%rsp)
     dc8:      	movabsq	$0x6166206c6c616320, %rax # imm = 0x6166206C6C616320
     dd2:      	movq	%rax, 0x18(%rsp)
     dd7:      	movabsq	$0x6c6961745f667062, %rax # imm = 0x6C6961745F667062
     de1:      	movq	%rax, 0x10(%rsp)
     de6:      	movl	$0xa7972, 0x40(%rsp)    # imm = 0xA7972
     dee:      	leaq	0x10(%rsp), %rdi
     df3:      	movl	$0x34, %eax
     df8:      	movl	$0x6, %ecx
     dfd:      	movl	$0x34, %esi
     e02:      	movl	%r12d, %edx
     e05:      	xorl	%eax, %eax
     e07:      	callq	*%rcx
     e09:      	jmp	0xc49 <native_tracer_entry+0xc49>
     e0e:      	movabsq	$0xa64726f636572, %rax  # imm = 0xA64726F636572
     e18:      	movq	%rax, 0x1e(%rsp)
     e1d:      	movabsq	$0x6572205550432067, %rax # imm = 0x6572205550432067
     e27:      	movq	%rax, 0x18(%rsp)
     e2c:      	movabsq	$0x6e69747465736552, %rax # imm = 0x6E69747465736552
     e36:      	movq	%rax, 0x10(%rsp)
     e3b:      	leaq	0x10(%rsp), %rdi
     e40:      	movl	$0x16, %eax
     e45:      	movl	$0x6, %ecx
     e4a:      	movl	$0x16, %esi
     e4f:      	xorl	%eax, %eax
     e51:      	callq	*%rcx
     e53:      	jmp	0x1c9 <native_tracer_entry+0x1c9>
     e58:      	movabsq	$0xa6425203d2064, %rax  # imm = 0xA6425203D2064
     e62:      	movq	%rax, 0x1e(%rsp)
     e67:      	movabsq	$0x206469206b636174, %rax # imm = 0x206469206B636174
     e71:      	movq	%rax, 0x18(%rsp)
     e76:      	movabsq	$0x73206c656e72656b, %rax # imm = 0x73206C656E72656B
     e80:      	movq	%rax, 0x10(%rsp)
     e85:      	leaq	0x10(%rsp), %rdi
     e8a:      	movl	$0x16, %eax
     e8f:      	movl	$0x6, %ecx
     e94:      	movl	0x2bc(%r14), %edx
     e9b:      	movl	$0x16, %esi
     ea0:      	xorl	%eax, %eax
     ea2:      	callq	*%rcx
     ea4:      	jmp	0x67a <native_tracer_entry+0x67a>
     ea9:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     eb3:      	movq	%rax, 0xf6(%rsp)
     ebb:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     ec5:      	movq	%rax, 0xf0(%rsp)
     ecd:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     ed7:      	movq	%rax, 0xe8(%rsp)
     edf:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     ee9:      	movq	%rax, 0xe0(%rsp)
     ef1:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     efb:      	movq	%rax, 0xd8(%rsp)
     f03:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     f0d:      	movq	%rax, 0xd0(%rsp)
     f15:      	leaq	0xd0(%rsp), %rdi
     f1d:      	movl	$0x2e, %eax
     f22:      	movl	$0x6, %ecx
     f27:      	movl	0xc8(%rsp), %edx
     f2e:      	movl	$0x2e, %esi
     f33:      	xorl	%eax, %eax
     f35:      	callq	*%rcx
     f37:      	jmp	0xb74 <native_tracer_entry+0xb74>
     f3c:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     f46:      	movq	%rax, 0x36(%rsp)
     f4b:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     f55:      	movq	%rax, 0x30(%rsp)
     f5a:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     f64:      	movq	%rax, 0x28(%rsp)
     f69:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     f73:      	movq	%rax, 0x20(%rsp)
     f78:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     f82:      	movq	%rax, 0x18(%rsp)
     f87:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     f91:      	movq	%rax, 0x10(%rsp)
     f96:      	leaq	0x10(%rsp), %rdi
     f9b:      	movl	$0x2e, %eax
     fa0:      	movl	$0x6, %ecx
     fa5:      	movl	0xd0(%rsp), %edx
     fac:      	movl	$0x2e, %esi
     fb1:      	xorl	%eax, %eax
     fb3:      	callq	*%rcx
     fb5:      	jmp	0x32f <native_tracer_entry+0x32f>
     fba:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
     fc4:      	movq	%rax, 0x38(%rsp)
     fc9:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
     fd3:      	movq	%rax, 0x30(%rsp)
     fd8:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
     fe2:      	movq	%rax, 0x28(%rsp)
     fe7:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
     ff1:      	movq	%rax, 0x20(%rsp)
     ff6:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    1000:      	movq	%rax, 0x18(%rsp)
    1005:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    100f:      	movq	%rax, 0x10(%rsp)
    1014:      	movb	$0x0, 0x40(%rsp)
    1019:      	leaq	0x10(%rsp), %rdi
    101e:      	movl	$0x31, %eax
    1023:      	movl	$0x6, %ecx
    1028:      	movl	0x2c0(%r15), %edx
    102f:      	movl	$0x31, %esi
    1034:      	xorl	%eax, %eax
    1036:      	callq	*%rcx
    1038:      	movq	0xed0(%r15), %r13
    103f:      	movq	%r13, %rax
    1042:      	shrq	$0x38, %rax
    1046:      	jne	0x45b <native_tracer_entry+0x45b>
    104c:      	cmpq	$0xfff, %r13            # imm = 0xFFF
    1053:      	ja	0x107a <native_tracer_entry+0x107a>
    1055:      	movq	(%rip), %rax            # 0x105c <native_tracer_entry+0x105c>
    105c:      	cmpl	$0x0, (%rax)
    105f:      	jne	0x14b1 <native_tracer_entry+0x14b1>
    1065:      	movl	$0x31, 0xf28(%r15)
    1070:      	movl	$0xfae, %ebp            # imm = 0xFAE
    1075:      	jmp	0xb79 <native_tracer_entry+0xb79>
    107a:      	movl	(%r15), %eax
    107d:      	movl	$0x60, 0xd0(%rsp)
    1088:      	movbel	%eax, 0xd4(%rsp)
    1091:      	movbeq	%r13, 0xd8(%rsp)
    109b:      	movq	(%rip), %rdi            # 0x10a2 <native_tracer_entry+0x10a2>
    10a2:      	leaq	0xd0(%rsp), %rsi
    10aa:      	movl	$0x1, %eax
    10af:      	callq	*%rax
    10b1:      	testq	%rax, %rax
    10b4:      	je	0x11e8 <native_tracer_entry+0x11e8>
    10ba:      	movabsq	$0xffffffffffffff, %rcx # imm = 0xFFFFFFFFFFFFFF
    10c4:      	movq	0x8(%rax), %r12
    10c8:      	andq	%r12, %rcx
    10cb:      	movq	%rcx, 0xf20(%r15)
    10d2:      	movq	(%rax), %rax
    10d5:      	movq	%rax, 0xf10(%r15)
    10dc:      	shrq	$0x38, %r12
    10e0:      	movq	%r13, %rax
    10e3:      	subq	%rcx, %rax
    10e6:      	movq	%rax, 0xf18(%r15)
    10ed:      	movq	(%rip), %rax            # 0x10f4 <native_tracer_entry+0x10f4>
    10f4:      	cmpl	$0x0, (%rax)
    10f7:      	jne	0x158b <native_tracer_entry+0x158b>
    10fd:      	xorl	%ebp, %ebp
    10ff:      	cmpl	$0x1, %r12d
    1103:      	jne	0xb7c <native_tracer_entry+0xb7c>
    1109:      	movq	0xf10(%r15), %rax
    1110:      	movq	%rax, 0xd0(%rsp)
    1118:      	movq	0xf18(%r15), %r13
    111f:      	movq	(%rip), %rdi            # 0x1126 <native_tracer_entry+0x1126>
    1126:      	leaq	0xd0(%rsp), %rsi
    112e:      	movl	$0x1, %eax
    1133:      	callq	*%rax
    1135:      	movl	$0x1, %r12d
    113b:      	testq	%rax, %rax
    113e:      	je	0xb7c <native_tracer_entry+0xb7c>
    1144:      	cmpq	%r13, (%rax)
    1147:      	ja	0x114f <native_tracer_entry+0x114f>
    1149:      	cmpq	%r13, 0x8(%rax)
    114d:      	jae	0x1163 <native_tracer_entry+0x1163>
    114f:      	cmpq	%r13, 0x10(%rax)
    1153:      	ja	0xb7c <native_tracer_entry+0xb7c>
    1159:      	cmpq	%r13, 0x18(%rax)
    115d:      	jb	0xb7c <native_tracer_entry+0xb7c>
    1163:      	movq	(%rip), %rcx            # 0x116a <native_tracer_entry+0x116a>
    116a:      	cmpl	$0x0, (%rcx)
    116d:      	jne	0x194e <native_tracer_entry+0x194e>
    1173:      	movl	0x1380(%r15), %ecx
    117a:      	movl	0x20(%rax), %edx
    117d:      	btl	%edx, %ecx
    1180:      	jae	0x19c1 <native_tracer_entry+0x19c1>
    1186:      	movq	(%rip), %rax            # 0x118d <native_tracer_entry+0x118d>
    118d:      	cmpl	$0x0, (%rax)
    1190:      	je	0xb7c <native_tracer_entry+0xb7c>
    1196:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    11a0:      	movq	%rax, 0x20(%rsp)
    11a5:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    11af:      	movq	%rax, 0x18(%rsp)
    11b4:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    11be:      	movq	%rax, 0x10(%rsp)
    11c3:      	movl	$0xa656e, 0x27(%rsp)    # imm = 0xA656E
    11cb:      	leaq	0x10(%rsp), %rdi
    11d0:      	movl	$0x1b, %eax
    11d5:      	movl	$0x6, %ecx
    11da:      	movl	$0x1b, %esi
    11df:      	xorl	%eax, %eax
    11e1:      	callq	*%rcx
    11e3:      	jmp	0xb7c <native_tracer_entry+0xb7c>
    11e8:      	movq	(%rip), %rax            # 0x11ef <native_tracer_entry+0x11ef>
    11ef:      	cmpl	$0x0, (%rax)
    11f2:      	jne	0x1735 <native_tracer_entry+0x1735>
    11f8:      	movl	$0xc, 0xf28(%r15)
    1203:      	movl	$0xfac, %ebp            # imm = 0xFAC
    1208:      	jmp	0xb79 <native_tracer_entry+0xb79>
    120d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1217:      	movq	%rax, 0x36(%rsp)
    121c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1226:      	movq	%rax, 0x30(%rsp)
    122b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1235:      	movq	%rax, 0x28(%rsp)
    123a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1244:      	movq	%rax, 0x20(%rsp)
    1249:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1253:      	movq	%rax, 0x18(%rsp)
    1258:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1262:      	movq	%rax, 0x10(%rsp)
    1267:      	leaq	0x10(%rsp), %rdi
    126c:      	movl	$0x2e, %eax
    1271:      	movl	$0x6, %ecx
    1276:      	movl	0xd0(%rsp), %edx
    127d:      	movl	$0x2e, %esi
    1282:      	xorl	%eax, %eax
    1284:      	callq	*%rcx
    1286:      	jmp	0xc0a <native_tracer_entry+0xc0a>
    128b:      	movabsq	$0xa64253d74706d, %rcx  # imm = 0xA64253D74706D
    1295:      	movq	%rcx, 0x27(%rsp)
    129a:      	movabsq	$0x6d65747461202c64, %rcx # imm = 0x6D65747461202C64
    12a4:      	movq	%rcx, 0x20(%rsp)
    12a9:      	movabsq	$0x6e657320746e6576, %rcx # imm = 0x6E657320746E6576
    12b3:      	movq	%rcx, 0x18(%rsp)
    12b8:      	movabsq	$0x6520642520444950, %rcx # imm = 0x6520642520444950
    12c2:      	movq	%rcx, 0x10(%rsp)
    12c7:      	leaq	0x10(%rsp), %rdi
    12cc:      	movl	$0x1f, %ecx
    12d1:      	movl	$0x6, %r8d
    12d7:      	movl	0x8(%rsp), %edx
    12db:      	movl	$0x1f, %esi
    12e0:      	movl	%r14d, %ecx
    12e3:      	movq	%rax, %r15
    12e6:      	xorl	%eax, %eax
    12e8:      	callq	*%r8
    12eb:      	movq	%r15, %rax
    12ee:      	jmp	0x5be <native_tracer_entry+0x5be>
    12f3:      	movabsq	$0xa2930203d3d2043, %rax # imm = 0xA2930203D3D2043
    12fd:      	movq	%rax, 0x38(%rsp)
    1302:      	movabsq	$0x5028206572756c69, %rax # imm = 0x5028206572756C69
    130c:      	movq	%rax, 0x30(%rsp)
    1311:      	movabsq	$0x616620646e69776e, %rax # imm = 0x616620646E69776E
    131b:      	movq	%rax, 0x28(%rsp)
    1320:      	movabsq	$0x75206f7420657564, %rax # imm = 0x75206F7420657564
    132a:      	movq	%rax, 0x20(%rsp)
    132f:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    1339:      	movq	%rax, 0x18(%rsp)
    133e:      	movabsq	$0x676e6970706f7453, %rax # imm = 0x676E6970706F7453
    1348:      	movq	%rax, 0x10(%rsp)
    134d:      	movb	$0x0, 0x40(%rsp)
    1352:      	leaq	0x10(%rsp), %rdi
    1357:      	movl	$0x31, %eax
    135c:      	movl	$0x6, %ecx
    1361:      	movl	$0x31, %esi
    1366:      	xorl	%eax, %eax
    1368:      	callq	*%rcx
    136a:      	jmp	0x55c <native_tracer_entry+0x55c>
    136f:      	movabsq	$0x7373657264646120, %rax # imm = 0x7373657264646120
    1379:      	movq	%rax, 0x28(%rsp)
    137e:      	movabsq	$0x6c656e72656b2061, %rax # imm = 0x6C656E72656B2061
    1388:      	movq	%rax, 0x20(%rsp)
    138d:      	movabsq	$0x20736920786c2520, %rax # imm = 0x20736920786C2520
    1397:      	movq	%rax, 0x18(%rsp)
    139c:      	movabsq	$0x65756c6176204350, %rax # imm = 0x65756C6176204350
    13a6:      	movq	%rax, 0x10(%rsp)
    13ab:      	movw	$0xa, 0x30(%rsp)
    13b2:      	leaq	0x10(%rsp), %rdi
    13b7:      	movl	$0x22, %eax
    13bc:      	movl	$0x6, %ecx
    13c1:      	movl	$0x22, %esi
    13c6:      	movq	%r13, %rdx
    13c9:      	xorl	%eax, %eax
    13cb:      	callq	*%rcx
    13cd:      	jmp	0x46b <native_tracer_entry+0x46b>
    13d2:      	movabsq	$0xa6425203a6425, %rcx  # imm = 0xA6425203A6425
    13dc:      	movq	%rcx, 0x25(%rsp)
    13e1:      	movabsq	$0x3a64252044495020, %rcx # imm = 0x3A64252044495020
    13eb:      	movq	%rcx, 0x20(%rsp)
    13f0:      	movabsq	$0x74726f706572206f, %rcx # imm = 0x74726F706572206F
    13fa:      	movq	%rcx, 0x18(%rsp)
    13ff:      	movabsq	$0x742064656c696146, %rcx # imm = 0x742064656C696146
    1409:      	movq	%rcx, 0x10(%rsp)
    140e:      	leaq	0x10(%rsp), %rdi
    1413:      	movl	$0x1d, %ecx
    1418:      	movl	$0x6, %r8d
    141e:      	movl	0x8(%rsp), %edx
    1422:      	movl	$0x1d, %esi
    1427:      	movl	%eax, %ecx
    1429:      	xorl	%eax, %eax
    142b:      	callq	*%r8
    142e:      	jmp	0x60d <native_tracer_entry+0x60d>
    1433:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    143d:      	movq	%rax, 0x36(%rsp)
    1442:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    144c:      	movq	%rax, 0x30(%rsp)
    1451:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    145b:      	movq	%rax, 0x28(%rsp)
    1460:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    146a:      	movq	%rax, 0x20(%rsp)
    146f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1479:      	movq	%rax, 0x18(%rsp)
    147e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1488:      	movq	%rax, 0x10(%rsp)
    148d:      	leaq	0x10(%rsp), %rdi
    1492:      	movl	$0x2e, %eax
    1497:      	movl	$0x6, %ecx
    149c:      	movl	0xd0(%rsp), %edx
    14a3:      	movl	$0x2e, %esi
    14a8:      	xorl	%eax, %eax
    14aa:      	callq	*%rcx
    14ac:      	jmp	0x64d <native_tracer_entry+0x64d>
    14b1:      	movabsq	$0xa676e69726f6e, %rax  # imm = 0xA676E69726F6E
    14bb:      	movq	%rax, 0x26(%rsp)
    14c0:      	movabsq	$0x6f6e6769202c786c, %rax # imm = 0x6F6E6769202C786C
    14ca:      	movq	%rax, 0x20(%rsp)
    14cf:      	movabsq	$0x252065756c617620, %rax # imm = 0x252065756C617620
    14d9:      	movq	%rax, 0x18(%rsp)
    14de:      	movabsq	$0x6370206c6c616d73, %rax # imm = 0x6370206C6C616D73
    14e8:      	movq	%rax, 0x10(%rsp)
    14ed:      	leaq	0x10(%rsp), %rdi
    14f2:      	movl	$0x1e, %eax
    14f7:      	movl	$0x6, %ecx
    14fc:      	movl	$0x1e, %esi
    1501:      	movq	%r13, %rdx
    1504:      	xorl	%eax, %eax
    1506:      	callq	*%rcx
    1508:      	jmp	0x1065 <native_tracer_entry+0x1065>
    150d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1517:      	movq	%rax, 0x36(%rsp)
    151c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1526:      	movq	%rax, 0x30(%rsp)
    152b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1535:      	movq	%rax, 0x28(%rsp)
    153a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1544:      	movq	%rax, 0x20(%rsp)
    1549:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1553:      	movq	%rax, 0x18(%rsp)
    1558:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1562:      	movq	%rax, 0x10(%rsp)
    1567:      	leaq	0x10(%rsp), %rdi
    156c:      	movl	$0x2e, %eax
    1571:      	movl	$0x6, %ecx
    1576:      	movl	0xd0(%rsp), %edx
    157d:      	movl	$0x2e, %esi
    1582:      	xorl	%eax, %eax
    1584:      	callq	*%rcx
    1586:      	jmp	0x778 <native_tracer_entry+0x778>
    158b:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    1595:      	movq	%rax, 0x38(%rsp)
    159a:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    15a4:      	movq	%rax, 0x30(%rsp)
    15a9:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    15b3:      	movq	%rax, 0x28(%rsp)
    15b8:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    15c2:      	movq	%rax, 0x20(%rsp)
    15c7:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    15d1:      	movq	%rax, 0x18(%rsp)
    15d6:      	movabsq	$0x6365732074786554, %rbp # imm = 0x6365732074786554
    15e0:      	movq	%rbp, 0x10(%rsp)
    15e5:      	movw	$0xa, 0x40(%rsp)
    15ec:      	leaq	0x10(%rsp), %rdi
    15f1:      	movl	$0x32, %eax
    15f6:      	movl	$0x6, %r9d
    15fc:      	movq	0xf10(%r15), %rcx
    1603:      	movl	$0x32, %esi
    1608:      	movq	%r13, %rdx
    160b:      	movl	%r12d, %r8d
    160e:      	xorl	%eax, %eax
    1610:      	callq	*%r9
    1613:      	movq	(%rip), %rax            # 0x161a <native_tracer_entry+0x161a>
    161a:      	cmpl	$0x0, (%rax)
    161d:      	je	0x10fd <native_tracer_entry+0x10fd>
    1623:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    162d:      	movq	%rax, 0x37(%rsp)
    1632:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    163c:      	movq	%rax, 0x30(%rsp)
    1641:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    164b:      	movq	%rax, 0x28(%rsp)
    1650:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    165a:      	movq	%rax, 0x20(%rsp)
    165f:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    1669:      	movq	%rax, 0x18(%rsp)
    166e:      	movq	%rbp, 0x10(%rsp)
    1673:      	leaq	0x10(%rsp), %rdi
    1678:      	movl	$0x2f, %eax
    167d:      	movl	$0x6, %r8d
    1683:      	movq	0xf18(%r15), %rcx
    168a:      	movq	0xf20(%r15), %rdx
    1691:      	movl	$0x2f, %esi
    1696:      	xorl	%eax, %eax
    1698:      	callq	*%r8
    169b:      	jmp	0x10fd <native_tracer_entry+0x10fd>
    16a0:      	movl	0xc8(%rsp), %ecx
    16a7:      	movabsq	$0xa6425203a6425, %rdx  # imm = 0xA6425203A6425
    16b1:      	movq	%rdx, 0x3d(%rsp)
    16b6:      	movabsq	$0x3a6425203a444954, %rdx # imm = 0x3A6425203A444954
    16c0:      	movq	%rdx, 0x38(%rsp)
    16c5:      	movabsq	$0x2064252044495020, %rdx # imm = 0x2064252044495020
    16cf:      	movq	%rdx, 0x30(%rsp)
    16d4:      	movabsq	$0x687469772073746e, %rdx # imm = 0x687469772073746E
    16de:      	movq	%rdx, 0x28(%rsp)
    16e3:      	movabsq	$0x6576655f64697020, %rdx # imm = 0x6576655F64697020
    16ed:      	movq	%rdx, 0x20(%rsp)
    16f2:      	movabsq	$0x657461647075206f, %rdx # imm = 0x657461647075206F
    16fc:      	movq	%rdx, 0x18(%rsp)
    1701:      	movabsq	$0x742064656c696146, %rdx # imm = 0x742064656C696146
    170b:      	movq	%rdx, 0x10(%rsp)
    1710:      	leaq	0x10(%rsp), %rdi
    1715:      	movl	$0x35, %edx
    171a:      	movl	$0x6, %r9d
    1720:      	movl	$0x35, %esi
    1725:      	movl	%r12d, %edx
    1728:      	movl	%eax, %r8d
    172b:      	xorl	%eax, %eax
    172d:      	callq	*%r9
    1730:      	jmp	0x73b <native_tracer_entry+0x73b>
    1735:      	movabsq	$0xa786c2578302043, %rax # imm = 0xA786C2578302043
    173f:      	movq	%rax, 0x40(%rsp)
    1744:      	movabsq	$0x5020726f6620676e, %rax # imm = 0x5020726F6620676E
    174e:      	movq	%rax, 0x38(%rsp)
    1753:      	movabsq	$0x697070616d207972, %rax # imm = 0x697070616D207972
    175d:      	movq	%rax, 0x30(%rsp)
    1762:      	movabsq	$0x6f6d656d206c6176, %rax # imm = 0x6F6D656D206C6176
    176c:      	movq	%rax, 0x28(%rsp)
    1771:      	movabsq	$0x7265746e69207075, %rax # imm = 0x7265746E69207075
    177b:      	movq	%rax, 0x20(%rsp)
    1780:      	movabsq	$0x206b6f6f6c206f74, %rax # imm = 0x206B6F6F6C206F74
    178a:      	movq	%rax, 0x18(%rsp)
    178f:      	movabsq	$0x206572756c696146, %rax # imm = 0x206572756C696146
    1799:      	movq	%rax, 0x10(%rsp)
    179e:      	movb	$0x0, 0x48(%rsp)
    17a3:      	leaq	0x10(%rsp), %rdi
    17a8:      	movl	$0x39, %eax
    17ad:      	movl	$0x6, %ecx
    17b2:      	movl	$0x39, %esi
    17b7:      	movq	%r13, %rdx
    17ba:      	xorl	%eax, %eax
    17bc:      	callq	*%rcx
    17be:      	jmp	0x11f8 <native_tracer_entry+0x11f8>
    17c3:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    17cd:      	movq	%rax, 0x36(%rsp)
    17d2:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    17dc:      	movq	%rax, 0x30(%rsp)
    17e1:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    17eb:      	movq	%rax, 0x28(%rsp)
    17f0:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    17fa:      	movq	%rax, 0x20(%rsp)
    17ff:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1809:      	movq	%rax, 0x18(%rsp)
    180e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1818:      	movq	%rax, 0x10(%rsp)
    181d:      	leaq	0x10(%rsp), %rdi
    1822:      	movl	$0x2e, %eax
    1827:      	movl	$0x6, %ecx
    182c:      	movl	0xd0(%rsp), %edx
    1833:      	movl	$0x2e, %esi
    1838:      	xorl	%eax, %eax
    183a:      	callq	*%rcx
    183c:      	jmp	0xa30 <native_tracer_entry+0xa30>
    1841:      	movabsq	$0xa642520726f72, %rcx  # imm = 0xA642520726F72
    184b:      	movq	%rcx, 0x3e(%rsp)
    1850:      	movabsq	$0x6f727265203a6425, %rcx # imm = 0x6F727265203A6425
    185a:      	movq	%rcx, 0x38(%rsp)
    185f:      	movabsq	$0x20746e6576652064, %rcx # imm = 0x20746E6576652064
    1869:      	movq	%rcx, 0x30(%rsp)
    186e:      	movabsq	$0x6e6573206f742064, %rcx # imm = 0x6E6573206F742064
    1878:      	movq	%rcx, 0x28(%rsp)
    187d:      	movabsq	$0x656c696166207265, %rcx # imm = 0x656C696166207265
    1887:      	movq	%rcx, 0x20(%rsp)
    188c:      	movabsq	$0x67676972745f646e, %rcx # imm = 0x67676972745F646E
    1896:      	movq	%rcx, 0x18(%rsp)
    189b:      	movabsq	$0x65735f746e657665, %rcx # imm = 0x65735F746E657665
    18a5:      	movq	%rcx, 0x10(%rsp)
    18aa:      	leaq	0x10(%rsp), %rdi
    18af:      	movl	$0x36, %ecx
    18b4:      	movl	$0x6, %r8d
    18ba:      	movl	$0x36, %esi
    18bf:      	movl	$0x1, %edx
    18c4:      	movl	%eax, %ecx
    18c6:      	xorl	%eax, %eax
    18c8:      	callq	*%r8
    18cb:      	jmp	0x9f6 <native_tracer_entry+0x9f6>
    18d0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    18da:      	movq	%rax, 0x36(%rsp)
    18df:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    18e9:      	movq	%rax, 0x30(%rsp)
    18ee:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    18f8:      	movq	%rax, 0x28(%rsp)
    18fd:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1907:      	movq	%rax, 0x20(%rsp)
    190c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1916:      	movq	%rax, 0x18(%rsp)
    191b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1925:      	movq	%rax, 0x10(%rsp)
    192a:      	leaq	0x10(%rsp), %rdi
    192f:      	movl	$0x2e, %eax
    1934:      	movl	$0x6, %ecx
    1939:      	movl	0xd0(%rsp), %edx
    1940:      	movl	$0x2e, %esi
    1945:      	xorl	%eax, %eax
    1947:      	callq	*%rcx
    1949:      	jmp	0x9a7 <native_tracer_entry+0x9a7>
    194e:      	movabsq	$0xa642520686374, %rcx  # imm = 0xA642520686374
    1958:      	movq	%rcx, 0x26(%rsp)
    195d:      	movabsq	$0x6374616d20737465, %rcx # imm = 0x6374616D20737465
    1967:      	movq	%rcx, 0x20(%rsp)
    196c:      	movabsq	$0x7366666f5f726574, %rcx # imm = 0x7366666F5F726574
    1976:      	movq	%rcx, 0x18(%rsp)
    197b:      	movabsq	$0x6572707265746e69, %rcx # imm = 0x6572707265746E69
    1985:      	movq	%rcx, 0x10(%rsp)
    198a:      	leaq	0x10(%rsp), %rdi
    198f:      	movl	$0x1e, %ecx
    1994:      	movl	$0x6, %r8d
    199a:      	movzwl	0x20(%rax), %edx
    199e:      	movl	$0x1e, %esi
    19a3:      	movq	%rax, %r13
    19a6:      	xorl	%eax, %eax
    19a8:      	callq	*%r8
    19ab:      	movq	%r13, %rax
    19ae:      	movl	0x1380(%r15), %ecx
    19b5:      	movl	0x20(%rax), %edx
    19b8:      	btl	%edx, %ecx
    19bb:      	jb	0x1186 <native_tracer_entry+0x1186>
    19c1:      	movq	%rax, %r12
    19c4:      	movl	$0x0, 0xc8(%rsp)
    19cf:      	movq	(%rip), %rdi            # 0x19d6 <native_tracer_entry+0x19d6>
    19d6:      	leaq	0xc8(%rsp), %rsi
    19de:      	movl	$0x1, %eax
    19e3:      	callq	*%rax
    19e5:      	testq	%rax, %rax
    19e8:      	je	0x19f2 <native_tracer_entry+0x19f2>
    19ea:      	incq	(%rax)
    19ed:      	movq	%r12, %rax
    19f0:      	jmp	0x1a01 <native_tracer_entry+0x1a01>
    19f2:      	movq	(%rip), %rax            # 0x19f9 <native_tracer_entry+0x19f9>
    19f9:      	cmpl	$0x0, (%rax)
    19fc:      	movq	%r12, %rax
    19ff:      	jne	0x1a0b <native_tracer_entry+0x1a0b>
    1a01:      	movzwl	0x20(%rax), %r12d
    1a06:      	jmp	0xb7c <native_tracer_entry+0xb7c>
    1a0b:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1a15:      	movq	%rax, 0x36(%rsp)
    1a1a:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1a24:      	movq	%rax, 0x30(%rsp)
    1a29:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1a33:      	movq	%rax, 0x28(%rsp)
    1a38:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1a42:      	movq	%rax, 0x20(%rsp)
    1a47:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1a51:      	movq	%rax, 0x18(%rsp)
    1a56:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1a60:      	movq	%rax, 0x10(%rsp)
    1a65:      	leaq	0x10(%rsp), %rdi
    1a6a:      	movl	$0x2e, %eax
    1a6f:      	movl	$0x6, %ecx
    1a74:      	movl	0xc8(%rsp), %edx
    1a7b:      	movl	$0x2e, %esi
    1a80:      	xorl	%eax, %eax
    1a82:      	callq	*%rcx
    1a84:      	jmp	0x19ed <native_tracer_entry+0x19ed>

Disassembly of section perf_event/unwind_native:

0000000000000000 <perf_unwind_native>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x148, %rsp            # imm = 0x148
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x60(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <perf_unwind_native+0x23>
      23:      	leaq	0x60(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x1d78 <perf_unwind_native+0x1d78>
      38:      	movq	%rax, %r14
      3b:      	movq	%rbx, 0x140(%rsp)
      43:      	addq	$0xed0, %rax            # imm = 0xED0
      49:      	movq	%rax, 0x108(%rsp)
      51:      	leaq	0xee0(%r14), %rax
      58:      	movq	%rax, 0xf0(%rsp)
      60:      	leaq	0xed8(%r14), %rax
      67:      	movq	%rax, 0xf8(%rsp)
      6f:      	leaq	0xee8(%r14), %rax
      76:      	movq	%rax, 0x138(%rsp)
      7e:      	leaq	0xef0(%r14), %rax
      85:      	movq	%rax, 0x128(%rsp)
      8d:      	leaq	0xef8(%r14), %rax
      94:      	movq	%rax, 0x130(%rsp)
      9c:      	movq	%r14, %rax
      9f:      	addq	$0xf08, %rax            # imm = 0xF08
      a5:      	movq	%rax, 0x120(%rsp)
      ad:      	movl	$0x4, %r15d
      b3:      	movq	(%rip), %r13            # 0xba <perf_unwind_native+0xba>
      ba:      	cmpl	$0x0, (%r13)
      bf:      	jne	0xc40 <perf_unwind_native+0xc40>
      c5:      	movl	$0x5, (%rsp)
      cc:      	movl	$0x1, %eax
      d1:      	movq	(%rip), %rdi            # 0xd8 <perf_unwind_native+0xd8>
      d8:      	movq	%rsp, %rsi
      db:      	callq	*%rax
      dd:      	testq	%rax, %rax
      e0:      	je	0x180 <perf_unwind_native+0x180>
      e6:      	incq	(%rax)
      e9:      	cmpl	$0x0, (%r13)
      ee:      	je	0x18b <perf_unwind_native+0x18b>
      f4:      	movabsq	$0x63617473206e6f20, %rax # imm = 0x63617473206E6F20
      fe:      	movq	%rax, 0x80(%rsp)
     106:      	movabsq	$0x7525206e6f697469, %rax # imm = 0x7525206E6F697469
     110:      	movq	%rax, 0x78(%rsp)
     115:      	movabsq	$0x736f70206f742078, %rax # imm = 0x736F70206F742078
     11f:      	movq	%rax, 0x70(%rsp)
     124:      	movabsq	$0x6c6c2520786c6c25, %rax # imm = 0x6C6C2520786C6C25
     12e:      	movq	%rax, 0x68(%rsp)
     133:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
     13d:      	movq	%rax, 0x60(%rsp)
     142:      	movl	$0xa6b63, 0x87(%rsp)    # imm = 0xA6B63
     14d:      	movl	$0x6, %r9d
     153:      	leaq	0x60(%rsp), %rdi
     158:      	movl	$0x2b, %eax
     15d:      	movq	0xf10(%r14), %rdx
     164:      	movq	0xf18(%r14), %rcx
     16b:      	movl	0x2c0(%r14), %r8d
     172:      	movl	$0x2b, %esi
     177:      	xorl	%eax, %eax
     179:      	callq	*%r9
     17c:      	jmp	0x18b <perf_unwind_native+0x18b>
     17e:      	nop
     180:      	cmpl	$0x0, (%r13)
     185:      	jne	0xe0d <perf_unwind_native+0xe0d>
     18b:      	movl	0x2c0(%r14), %eax
     192:      	cmpq	$0x7f, %rax
     196:      	jae	0x1a1a <perf_unwind_native+0x1a1a>
     19c:      	movzbl	0xf30(%r14), %ecx
     1a4:      	movq	0xf10(%r14), %rdx
     1ab:      	movq	0xf18(%r14), %rsi
     1b2:      	leal	0x1(%rax), %edi
     1b5:      	movl	%edi, 0x2c0(%r14)
     1bc:      	leaq	(%rax,%rax,2), %rax
     1c0:      	movq	%rdx, 0x2d0(%r14,%rax,8)
     1c8:      	movq	%rsi, 0x2d8(%r14,%rax,8)
     1d0:      	movb	$0x3, 0x2e0(%r14,%rax,8)
     1d9:      	movb	%cl, 0x2e1(%r14,%rax,8)
     1e1:      	movl	$0x0, 0x2e2(%r14,%rax,8)
     1ed:      	movw	$0x0, 0x2e6(%r14,%rax,8)
     1f8:      	movl	$0x0, 0x58(%rsp)
     200:      	movq	0xf10(%r14), %rax
     207:      	movq	%rax, 0x110(%rsp)
     20f:      	movq	%rax, 0x48(%rsp)
     214:      	movq	0xf18(%r14), %rax
     21b:      	movq	$-0x10000, %rcx         # imm = 0xFFFF0000
     222:      	andq	%rcx, %rax
     225:      	movq	%rax, 0x50(%rsp)
     22a:      	cmpl	$0x0, (%r13)
     22f:      	jne	0xc99 <perf_unwind_native+0xc99>
     235:      	movl	$0x1, %eax
     23a:      	movq	(%rip), %rdi            # 0x241 <perf_unwind_native+0x241>
     241:      	leaq	0x48(%rsp), %rsi
     246:      	callq	*%rax
     248:      	testq	%rax, %rax
     24b:      	je	0x1ab6 <perf_unwind_native+0x1ab6>
     251:      	movq	%rax, %r12
     254:      	movzwl	0x6(%rax), %eax
     258:      	cmpl	$0xf, %eax
     25b:      	jg	0x290 <perf_unwind_native+0x290>
     25d:      	cmpl	$0xb, %eax
     260:      	jg	0x2c0 <perf_unwind_native+0x2c0>
     262:      	cmpl	$0x9, %eax
     265:      	jg	0x313 <perf_unwind_native+0x313>
     26b:      	movq	(%rip), %rdi            # 0x272 <perf_unwind_native+0x272>
     272:      	cmpl	$0x8, %eax
     275:      	je	0x3b0 <perf_unwind_native+0x3b0>
     27b:      	cmpl	$0x9, %eax
     27e:      	jne	0x1df4 <perf_unwind_native+0x1df4>
     284:      	movq	(%rip), %rdi            # 0x28b <perf_unwind_native+0x28b>
     28b:      	jmp	0x3b0 <perf_unwind_native+0x3b0>
     290:      	cmpl	$0x13, %eax
     293:      	jg	0x2f0 <perf_unwind_native+0x2f0>
     295:      	cmpl	$0x11, %eax
     298:      	jg	0x32d <perf_unwind_native+0x32d>
     29e:      	cmpl	$0x10, %eax
     2a1:      	je	0x372 <perf_unwind_native+0x372>
     2a7:      	cmpl	$0x11, %eax
     2aa:      	jne	0x1df4 <perf_unwind_native+0x1df4>
     2b0:      	movq	(%rip), %rdi            # 0x2b7 <perf_unwind_native+0x2b7>
     2b7:      	jmp	0x3b0 <perf_unwind_native+0x3b0>
     2bc:      	nopl	(%rax)
     2c0:      	cmpl	$0xd, %eax
     2c3:      	jg	0x344 <perf_unwind_native+0x344>
     2c5:      	cmpl	$0xc, %eax
     2c8:      	je	0x37b <perf_unwind_native+0x37b>
     2ce:      	cmpl	$0xd, %eax
     2d1:      	jne	0x1df4 <perf_unwind_native+0x1df4>
     2d7:      	movq	(%rip), %rdi            # 0x2de <perf_unwind_native+0x2de>
     2de:      	jmp	0x3b0 <perf_unwind_native+0x3b0>
     2e3:      	nopw	%cs:(%rax,%rax)
     2f0:      	cmpl	$0x15, %eax
     2f3:      	jg	0x35b <perf_unwind_native+0x35b>
     2f5:      	cmpl	$0x14, %eax
     2f8:      	je	0x384 <perf_unwind_native+0x384>
     2fe:      	cmpl	$0x15, %eax
     301:      	jne	0x1df4 <perf_unwind_native+0x1df4>
     307:      	movq	(%rip), %rdi            # 0x30e <perf_unwind_native+0x30e>
     30e:      	jmp	0x3b0 <perf_unwind_native+0x3b0>
     313:      	cmpl	$0xa, %eax
     316:      	je	0x38d <perf_unwind_native+0x38d>
     318:      	cmpl	$0xb, %eax
     31b:      	jne	0x1df4 <perf_unwind_native+0x1df4>
     321:      	movq	(%rip), %rdi            # 0x328 <perf_unwind_native+0x328>
     328:      	jmp	0x3b0 <perf_unwind_native+0x3b0>
     32d:      	cmpl	$0x12, %eax
     330:      	je	0x396 <perf_unwind_native+0x396>
     332:      	cmpl	$0x13, %eax
     335:      	jne	0x1df4 <perf_unwind_native+0x1df4>
     33b:      	movq	(%rip), %rdi            # 0x342 <perf_unwind_native+0x342>
     342:      	jmp	0x3b0 <perf_unwind_native+0x3b0>
     344:      	cmpl	$0xe, %eax
     347:      	je	0x39f <perf_unwind_native+0x39f>
     349:      	cmpl	$0xf, %eax
     34c:      	jne	0x1df4 <perf_unwind_native+0x1df4>
     352:      	movq	(%rip), %rdi            # 0x359 <perf_unwind_native+0x359>
     359:      	jmp	0x3b0 <perf_unwind_native+0x3b0>
     35b:      	cmpl	$0x16, %eax
     35e:      	je	0x3a8 <perf_unwind_native+0x3a8>
     360:      	cmpl	$0x17, %eax
     363:      	jne	0x1df4 <perf_unwind_native+0x1df4>
     369:      	movq	(%rip), %rdi            # 0x370 <perf_unwind_native+0x370>
     370:      	jmp	0x3b0 <perf_unwind_native+0x3b0>
     372:      	movq	(%rip), %rdi            # 0x379 <perf_unwind_native+0x379>
     379:      	jmp	0x3b0 <perf_unwind_native+0x3b0>
     37b:      	movq	(%rip), %rdi            # 0x382 <perf_unwind_native+0x382>
     382:      	jmp	0x3b0 <perf_unwind_native+0x3b0>
     384:      	movq	(%rip), %rdi            # 0x38b <perf_unwind_native+0x38b>
     38b:      	jmp	0x3b0 <perf_unwind_native+0x3b0>
     38d:      	movq	(%rip), %rdi            # 0x394 <perf_unwind_native+0x394>
     394:      	jmp	0x3b0 <perf_unwind_native+0x3b0>
     396:      	movq	(%rip), %rdi            # 0x39d <perf_unwind_native+0x39d>
     39d:      	jmp	0x3b0 <perf_unwind_native+0x3b0>
     39f:      	movq	(%rip), %rdi            # 0x3a6 <perf_unwind_native+0x3a6>
     3a6:      	jmp	0x3b0 <perf_unwind_native+0x3b0>
     3a8:      	movq	(%rip), %rdi            # 0x3af <perf_unwind_native+0x3af>
     3af:      	nop
     3b0:      	movl	$0x1, %eax
     3b5:      	leaq	0x110(%rsp), %rsi
     3bd:      	callq	*%rax
     3bf:      	testq	%rax, %rax
     3c2:      	je	0x1b61 <perf_unwind_native+0x1b61>
     3c8:      	movq	%rax, %rbx
     3cb:      	movl	%r15d, 0x11c(%rsp)
     3d3:      	movl	(%r12), %r15d
     3d7:      	movl	%r15d, 0x5c(%rsp)
     3dc:      	movq	0xf18(%r14), %rax
     3e3:      	movq	%rax, 0x40(%rsp)
     3e8:      	movzwl	0x4(%r12), %ebp
     3ee:      	testl	%ebp, %ebp
     3f0:      	je	0x822 <perf_unwind_native+0x822>
     3f6:      	addl	%r15d, %ebp
     3f9:      	cmpl	$0x0, (%r13)
     3fe:      	jne	0xd8c <perf_unwind_native+0xd8c>
     404:      	leal	(%r15,%rbp), %eax
     408:      	shrl	%eax
     40a:      	movl	%eax, (%rsp)
     40d:      	movl	$0x1, %eax
     412:      	movq	%rsp, %rsi
     415:      	movq	%rbx, %rdi
     418:      	callq	*%rax
     41a:      	testq	%rax, %rax
     41d:      	je	0x1991 <perf_unwind_native+0x1991>
     423:      	movl	(%rsp), %ecx
     426:      	movq	0x40(%rsp), %rdx
     42b:      	cmpw	%dx, (%rax)
     42e:      	ja	0x440 <perf_unwind_native+0x440>
     430:      	incl	%ecx
     432:      	movl	%ecx, %r15d
     435:      	cmpl	%ebp, %r15d
     438:      	jb	0x44b <perf_unwind_native+0x44b>
     43a:      	jmp	0x810 <perf_unwind_native+0x810>
     43f:      	nop
     440:      	movl	%ecx, %ebp
     442:      	cmpl	%ebp, %r15d
     445:      	jae	0x810 <perf_unwind_native+0x810>
     44b:      	leal	(%r15,%rbp), %eax
     44f:      	shrl	%eax
     451:      	movl	%eax, (%rsp)
     454:      	movl	$0x1, %eax
     459:      	movq	%rsp, %rsi
     45c:      	movq	%rbx, %rdi
     45f:      	callq	*%rax
     461:      	testq	%rax, %rax
     464:      	je	0x1991 <perf_unwind_native+0x1991>
     46a:      	movl	(%rsp), %ecx
     46d:      	movq	0x40(%rsp), %rdx
     472:      	cmpw	%dx, (%rax)
     475:      	ja	0x487 <perf_unwind_native+0x487>
     477:      	incl	%ecx
     479:      	movl	%ecx, %r15d
     47c:      	cmpl	%ebp, %r15d
     47f:      	jae	0x810 <perf_unwind_native+0x810>
     485:      	jmp	0x492 <perf_unwind_native+0x492>
     487:      	movl	%ecx, %ebp
     489:      	cmpl	%ebp, %r15d
     48c:      	jae	0x810 <perf_unwind_native+0x810>
     492:      	leal	(%r15,%rbp), %eax
     496:      	shrl	%eax
     498:      	movl	%eax, (%rsp)
     49b:      	movl	$0x1, %eax
     4a0:      	movq	%rsp, %rsi
     4a3:      	movq	%rbx, %rdi
     4a6:      	callq	*%rax
     4a8:      	testq	%rax, %rax
     4ab:      	je	0x1991 <perf_unwind_native+0x1991>
     4b1:      	movl	(%rsp), %ecx
     4b4:      	movq	0x40(%rsp), %rdx
     4b9:      	cmpw	%dx, (%rax)
     4bc:      	ja	0x4ce <perf_unwind_native+0x4ce>
     4be:      	incl	%ecx
     4c0:      	movl	%ecx, %r15d
     4c3:      	cmpl	%ebp, %r15d
     4c6:      	jae	0x810 <perf_unwind_native+0x810>
     4cc:      	jmp	0x4d9 <perf_unwind_native+0x4d9>
     4ce:      	movl	%ecx, %ebp
     4d0:      	cmpl	%ebp, %r15d
     4d3:      	jae	0x810 <perf_unwind_native+0x810>
     4d9:      	leal	(%r15,%rbp), %eax
     4dd:      	shrl	%eax
     4df:      	movl	%eax, (%rsp)
     4e2:      	movl	$0x1, %eax
     4e7:      	movq	%rsp, %rsi
     4ea:      	movq	%rbx, %rdi
     4ed:      	callq	*%rax
     4ef:      	testq	%rax, %rax
     4f2:      	je	0x1991 <perf_unwind_native+0x1991>
     4f8:      	movl	(%rsp), %ecx
     4fb:      	leal	0x1(%rcx), %r13d
     4ff:      	movq	0x40(%rsp), %rdx
     504:      	cmpw	%dx, (%rax)
     507:      	cmoval	%r15d, %r13d
     50b:      	cmoval	%ecx, %ebp
     50e:      	cmpl	%ebp, %r13d
     511:      	jae	0x810 <perf_unwind_native+0x810>
     517:      	leal	(%rbp,%r13), %eax
     51c:      	shrl	%eax
     51e:      	movl	%eax, (%rsp)
     521:      	movl	$0x1, %eax
     526:      	movq	%rsp, %rsi
     529:      	movq	%rbx, %rdi
     52c:      	callq	*%rax
     52e:      	testq	%rax, %rax
     531:      	je	0x1991 <perf_unwind_native+0x1991>
     537:      	movl	(%rsp), %ecx
     53a:      	leal	0x1(%rcx), %r15d
     53e:      	movq	0x40(%rsp), %rdx
     543:      	cmpw	%dx, (%rax)
     546:      	cmoval	%r13d, %r15d
     54a:      	cmoval	%ecx, %ebp
     54d:      	cmpl	%ebp, %r15d
     550:      	jae	0x810 <perf_unwind_native+0x810>
     556:      	leal	(%r15,%rbp), %eax
     55a:      	shrl	%eax
     55c:      	movl	%eax, (%rsp)
     55f:      	movl	$0x1, %eax
     564:      	movq	%rsp, %rsi
     567:      	movq	%rbx, %rdi
     56a:      	callq	*%rax
     56c:      	testq	%rax, %rax
     56f:      	je	0x1991 <perf_unwind_native+0x1991>
     575:      	movl	(%rsp), %ecx
     578:      	leal	0x1(%rcx), %r13d
     57c:      	movq	0x40(%rsp), %rdx
     581:      	cmpw	%dx, (%rax)
     584:      	cmoval	%r15d, %r13d
     588:      	cmoval	%ecx, %ebp
     58b:      	cmpl	%ebp, %r13d
     58e:      	jae	0x810 <perf_unwind_native+0x810>
     594:      	leal	(%rbp,%r13), %eax
     599:      	shrl	%eax
     59b:      	movl	%eax, (%rsp)
     59e:      	movl	$0x1, %eax
     5a3:      	movq	%rsp, %rsi
     5a6:      	movq	%rbx, %rdi
     5a9:      	callq	*%rax
     5ab:      	testq	%rax, %rax
     5ae:      	je	0x1991 <perf_unwind_native+0x1991>
     5b4:      	movl	(%rsp), %ecx
     5b7:      	leal	0x1(%rcx), %r15d
     5bb:      	movq	0x40(%rsp), %rdx
     5c0:      	cmpw	%dx, (%rax)
     5c3:      	cmoval	%r13d, %r15d
     5c7:      	cmoval	%ecx, %ebp
     5ca:      	cmpl	%ebp, %r15d
     5cd:      	jae	0x810 <perf_unwind_native+0x810>
     5d3:      	leal	(%r15,%rbp), %eax
     5d7:      	shrl	%eax
     5d9:      	movl	%eax, (%rsp)
     5dc:      	movl	$0x1, %eax
     5e1:      	movq	%rsp, %rsi
     5e4:      	movq	%rbx, %rdi
     5e7:      	callq	*%rax
     5e9:      	testq	%rax, %rax
     5ec:      	je	0x1991 <perf_unwind_native+0x1991>
     5f2:      	movl	(%rsp), %ecx
     5f5:      	leal	0x1(%rcx), %r13d
     5f9:      	movq	0x40(%rsp), %rdx
     5fe:      	cmpw	%dx, (%rax)
     601:      	cmoval	%r15d, %r13d
     605:      	cmoval	%ecx, %ebp
     608:      	cmpl	%ebp, %r13d
     60b:      	jae	0x810 <perf_unwind_native+0x810>
     611:      	leal	(%rbp,%r13), %eax
     616:      	shrl	%eax
     618:      	movl	%eax, (%rsp)
     61b:      	movl	$0x1, %eax
     620:      	movq	%rsp, %rsi
     623:      	movq	%rbx, %rdi
     626:      	callq	*%rax
     628:      	testq	%rax, %rax
     62b:      	je	0x1991 <perf_unwind_native+0x1991>
     631:      	movl	(%rsp), %ecx
     634:      	leal	0x1(%rcx), %r15d
     638:      	movq	0x40(%rsp), %rdx
     63d:      	cmpw	%dx, (%rax)
     640:      	cmoval	%r13d, %r15d
     644:      	cmoval	%ecx, %ebp
     647:      	cmpl	%ebp, %r15d
     64a:      	jae	0x810 <perf_unwind_native+0x810>
     650:      	leal	(%r15,%rbp), %eax
     654:      	shrl	%eax
     656:      	movl	%eax, (%rsp)
     659:      	movl	$0x1, %eax
     65e:      	movq	%rsp, %rsi
     661:      	movq	%rbx, %rdi
     664:      	callq	*%rax
     666:      	testq	%rax, %rax
     669:      	je	0x1991 <perf_unwind_native+0x1991>
     66f:      	movl	(%rsp), %ecx
     672:      	leal	0x1(%rcx), %r13d
     676:      	movq	0x40(%rsp), %rdx
     67b:      	cmpw	%dx, (%rax)
     67e:      	cmoval	%r15d, %r13d
     682:      	cmoval	%ecx, %ebp
     685:      	cmpl	%ebp, %r13d
     688:      	jae	0x810 <perf_unwind_native+0x810>
     68e:      	leal	(%rbp,%r13), %eax
     693:      	shrl	%eax
     695:      	movl	%eax, (%rsp)
     698:      	movl	$0x1, %eax
     69d:      	movq	%rsp, %rsi
     6a0:      	movq	%rbx, %rdi
     6a3:      	callq	*%rax
     6a5:      	testq	%rax, %rax
     6a8:      	je	0x1991 <perf_unwind_native+0x1991>
     6ae:      	movl	(%rsp), %ecx
     6b1:      	leal	0x1(%rcx), %r15d
     6b5:      	movq	0x40(%rsp), %rdx
     6ba:      	cmpw	%dx, (%rax)
     6bd:      	cmoval	%r13d, %r15d
     6c1:      	cmoval	%ecx, %ebp
     6c4:      	cmpl	%ebp, %r15d
     6c7:      	jae	0x810 <perf_unwind_native+0x810>
     6cd:      	leal	(%r15,%rbp), %eax
     6d1:      	shrl	%eax
     6d3:      	movl	%eax, (%rsp)
     6d6:      	movl	$0x1, %eax
     6db:      	movq	%rsp, %rsi
     6de:      	movq	%rbx, %rdi
     6e1:      	callq	*%rax
     6e3:      	testq	%rax, %rax
     6e6:      	je	0x1991 <perf_unwind_native+0x1991>
     6ec:      	movl	(%rsp), %ecx
     6ef:      	leal	0x1(%rcx), %r13d
     6f3:      	movq	0x40(%rsp), %rdx
     6f8:      	cmpw	%dx, (%rax)
     6fb:      	cmoval	%r15d, %r13d
     6ff:      	cmoval	%ecx, %ebp
     702:      	cmpl	%ebp, %r13d
     705:      	jae	0x810 <perf_unwind_native+0x810>
     70b:      	leal	(%rbp,%r13), %eax
     710:      	shrl	%eax
     712:      	movl	%eax, (%rsp)
     715:      	movl	$0x1, %eax
     71a:      	movq	%rsp, %rsi
     71d:      	movq	%rbx, %rdi
     720:      	callq	*%rax
     722:      	testq	%rax, %rax
     725:      	je	0x1991 <perf_unwind_native+0x1991>
     72b:      	movl	(%rsp), %ecx
     72e:      	leal	0x1(%rcx), %r15d
     732:      	movq	0x40(%rsp), %rdx
     737:      	cmpw	%dx, (%rax)
     73a:      	cmoval	%r13d, %r15d
     73e:      	cmoval	%ecx, %ebp
     741:      	cmpl	%ebp, %r15d
     744:      	jae	0x810 <perf_unwind_native+0x810>
     74a:      	leal	(%r15,%rbp), %eax
     74e:      	shrl	%eax
     750:      	movl	%eax, (%rsp)
     753:      	movl	$0x1, %eax
     758:      	movq	%rsp, %rsi
     75b:      	movq	%rbx, %rdi
     75e:      	callq	*%rax
     760:      	testq	%rax, %rax
     763:      	je	0x1991 <perf_unwind_native+0x1991>
     769:      	movl	(%rsp), %ecx
     76c:      	leal	0x1(%rcx), %r13d
     770:      	movq	0x40(%rsp), %rdx
     775:      	cmpw	%dx, (%rax)
     778:      	cmoval	%r15d, %r13d
     77c:      	cmoval	%ecx, %ebp
     77f:      	cmpl	%ebp, %r13d
     782:      	jae	0x810 <perf_unwind_native+0x810>
     788:      	leal	(%rbp,%r13), %eax
     78d:      	shrl	%eax
     78f:      	movl	%eax, (%rsp)
     792:      	movl	$0x1, %eax
     797:      	movq	%rsp, %rsi
     79a:      	movq	%rbx, %rdi
     79d:      	callq	*%rax
     79f:      	testq	%rax, %rax
     7a2:      	je	0x1991 <perf_unwind_native+0x1991>
     7a8:      	movl	(%rsp), %ecx
     7ab:      	leal	0x1(%rcx), %r15d
     7af:      	movq	0x40(%rsp), %rdx
     7b4:      	cmpw	%dx, (%rax)
     7b7:      	cmoval	%r13d, %r15d
     7bb:      	cmoval	%ecx, %ebp
     7be:      	cmpl	%ebp, %r15d
     7c1:      	jae	0x810 <perf_unwind_native+0x810>
     7c3:      	leal	(%r15,%rbp), %eax
     7c7:      	shrl	%eax
     7c9:      	movl	%eax, (%rsp)
     7cc:      	movl	$0x1, %eax
     7d1:      	movq	%rsp, %rsi
     7d4:      	movq	%rbx, %rdi
     7d7:      	callq	*%rax
     7d9:      	testq	%rax, %rax
     7dc:      	je	0x1991 <perf_unwind_native+0x1991>
     7e2:      	movl	(%rsp), %ecx
     7e5:      	leal	0x1(%rcx), %edx
     7e8:      	movq	0x40(%rsp), %rsi
     7ed:      	cmpw	%si, (%rax)
     7f0:      	cmoval	%r15d, %edx
     7f4:      	cmoval	%ecx, %ebp
     7f7:      	cmpl	%ebp, %edx
     7f9:      	movq	(%rip), %r13            # 0x800 <perf_unwind_native+0x800>
     800:      	jae	0x817 <perf_unwind_native+0x817>
     802:      	jmp	0x1998 <perf_unwind_native+0x1998>
     807:      	nopw	(%rax,%rax)
     810:      	movq	(%rip), %r13            # 0x817 <perf_unwind_native+0x817>
     817:      	movl	%ebp, %r15d
     81a:      	testl	%ebp, %ebp
     81c:      	je	0x1998 <perf_unwind_native+0x1998>
     822:      	decl	%r15d
     825:      	movl	%r15d, 0x5c(%rsp)
     82a:      	movl	$0x1, %eax
     82f:      	leaq	0x5c(%rsp), %rsi
     834:      	movq	%rbx, %rdi
     837:      	callq	*%rax
     839:      	testq	%rax, %rax
     83c:      	je	0x1bfa <perf_unwind_native+0x1bfa>
     842:      	cmpl	$0x0, (%r13)
     847:      	jne	0xd04 <perf_unwind_native+0xd04>
     84d:      	movzwl	0x40(%rsp), %ecx
     852:      	movzwl	(%rax), %edx
     855:      	subl	%edx, %ecx
     857:      	movl	0x5c(%rsp), %edx
     85b:      	cmpl	(%r12), %edx
     85f:      	leal	0x10000(%rcx), %r12d
     866:      	cmovael	%ecx, %r12d
     86a:      	movzwl	0x2(%rax), %eax
     86e:      	movl	%eax, 0x58(%rsp)
     872:      	cmpl	$0x8001, %eax           # imm = 0x8001
     877:      	je	0x930 <perf_unwind_native+0x930>
     87d:      	cmpl	$0x8000, %eax           # imm = 0x8000
     882:      	je	0x1c96 <perf_unwind_native+0x1c96>
     888:      	testw	%ax, %ax
     88b:      	js	0xa0f <perf_unwind_native+0xa0f>
     891:      	movl	$0x1, %eax
     896:      	movq	(%rip), %rdi            # 0x89d <perf_unwind_native+0x89d>
     89d:      	leaq	0x58(%rsp), %rsi
     8a2:      	callq	*%rax
     8a4:      	testq	%rax, %rax
     8a7:      	je	0x1d8f <perf_unwind_native+0x1d8f>
     8ad:      	movq	%rax, %rbx
     8b0:      	movl	0x4(%rax), %r15d
     8b4:      	movzbl	0x2(%rax), %eax
     8b8:      	testb	%al, %al
     8ba:      	je	0x8f0 <perf_unwind_native+0x8f0>
     8bc:      	cmpl	$0x0, (%r13)
     8c1:      	jne	0xe98 <perf_unwind_native+0xe98>
     8c7:      	movl	%eax, %ecx
     8c9:      	andb	$0x7f, %cl
     8cc:      	movzbl	%cl, %ecx
     8cf:      	cmpl	%ecx, %r12d
     8d2:      	jl	0x8f0 <perf_unwind_native+0x8f0>
     8d4:      	xorl	%ecx, %ecx
     8d6:      	testb	%al, %al
     8d8:      	setns	%cl
     8db:      	shll	$0x4, %ecx
     8de:      	addl	%ecx, %r15d
     8e1:      	addl	$-0x8, %r15d
     8e5:      	cmpl	$0x0, (%r13)
     8ea:      	jne	0xf88 <perf_unwind_native+0xf88>
     8f0:      	movzbl	(%rbx), %eax
     8f3:      	movl	%r15d, %ecx
     8f6:      	andl	$-0x8, %ecx
     8f9:      	testb	%al, %al
     8fb:      	cmovnsl	%r15d, %ecx
     8ff:      	movl	%eax, %edx
     901:      	andl	$0x7f, %edx
     904:      	cmpl	$0x2, %edx
     907:      	jg	0x96f <perf_unwind_native+0x96f>
     909:      	cmpl	$0x1, %edx
     90c:      	je	0xbea <perf_unwind_native+0xbea>
     912:      	movq	0xf8(%rsp), %rsi
     91a:      	movl	$0x0, %r12d
     920:      	cmpl	$0x2, %edx
     923:      	je	0x9e1 <perf_unwind_native+0x9e1>
     929:      	jmp	0x1070 <perf_unwind_native+0x1070>
     92e:      	nop
     930:      	movl	$0x7, 0x104(%rsp)
     93b:      	movl	$0x1, %eax
     940:      	movq	(%rip), %rdi            # 0x947 <perf_unwind_native+0x947>
     947:      	leaq	0x104(%rsp), %rsi
     94f:      	callq	*%rax
     951:      	testq	%rax, %rax
     954:      	je	0x9f7 <perf_unwind_native+0x9f7>
     95a:      	incq	(%rax)
     95d:      	movl	0x58(%rsp), %eax
     961:      	testw	%ax, %ax
     964:      	jns	0x891 <perf_unwind_native+0x891>
     96a:      	jmp	0xa0f <perf_unwind_native+0xa0f>
     96f:      	movq	0xf0(%rsp), %rsi
     977:      	cmpl	$0x3, %edx
     97a:      	je	0x9e1 <perf_unwind_native+0x9e1>
     97c:      	movl	$0x0, %r12d
     982:      	cmpl	$0x5, %edx
     985:      	jne	0x1070 <perf_unwind_native+0x1070>
     98b:      	movl	%r15d, %eax
     98e:      	sarl	%eax
     990:      	andl	$-0x8, %eax
     993:      	cltq
     995:      	movq	%rax, 0x48(%rsp)
     99a:      	cmpl	$0x0, (%r13)
     99f:      	jne	0xfe7 <perf_unwind_native+0xfe7>
     9a5:      	andl	$0xf, %r15d
     9a9:      	cmpl	$0xa, %r15d
     9ad:      	jg	0x1037 <perf_unwind_native+0x1037>
     9b3:      	movq	0x138(%rsp), %rax
     9bb:      	testl	%r15d, %r15d
     9be:      	je	0x1059 <perf_unwind_native+0x1059>
     9c4:      	movq	0x128(%rsp), %rax
     9cc:      	movl	$0x0, %r12d
     9d2:      	cmpl	$0x9, %r15d
     9d6:      	je	0x1059 <perf_unwind_native+0x1059>
     9dc:      	jmp	0x1070 <perf_unwind_native+0x1070>
     9e1:      	movq	(%rsi), %rdx
     9e4:      	movslq	%ecx, %r12
     9e7:      	addq	%rdx, %r12
     9ea:      	testb	%al, %al
     9ec:      	jns	0x1070 <perf_unwind_native+0x1070>
     9f2:      	jmp	0xbfa <perf_unwind_native+0xbfa>
     9f7:      	cmpl	$0x0, (%r13)
     9fc:      	jne	0xf00 <perf_unwind_native+0xf00>
     a02:      	movl	0x58(%rsp), %eax
     a06:      	testw	%ax, %ax
     a09:      	jns	0x891 <perf_unwind_native+0x891>
     a0f:      	andl	$0xffff7fff, %eax       # imm = 0xFFFF7FFF
     a14:      	cmpl	$0x2, %eax
     a17:      	jle	0xa84 <perf_unwind_native+0xa84>
     a19:      	cmpl	$0x3, %eax
     a1c:      	je	0xaf8 <perf_unwind_native+0xaf8>
     a22:      	cmpl	$0x4, %eax
     a25:      	jne	0x1dea <perf_unwind_native+0x1dea>
     a2b:      	movq	0xf0(%rsp), %rdx
     a33:      	movq	(%rdx), %rax
     a36:      	movl	$0x70, %ecx
     a3b:      	movq	%rsp, %rdi
     a3e:      	movl	$0x10, %esi
     a43:      	movq	(%rdx), %rdx
     a46:      	movl	$0x10, %esi
     a4b:      	callq	*%rcx
     a4d:      	testq	%rax, %rax
     a50:      	jne	0x1965 <perf_unwind_native+0x1965>
     a56:      	movq	0xee0(%r14), %rax
     a5d:      	addq	$0x10, %rax
     a61:      	movq	%rax, 0xed8(%r14)
     a68:      	movq	(%rsp), %rax
     a6c:      	movq	%rax, 0xee0(%r14)
     a73:      	movq	0x8(%rsp), %rax
     a78:      	movq	%rax, 0xed0(%r14)
     a7f:      	jmp	0x1287 <perf_unwind_native+0x1287>
     a84:      	jne	0x1dc9 <perf_unwind_native+0x1dc9>
     a8a:      	movq	0xf8(%rsp), %rax
     a92:      	movq	(%rax), %rax
     a95:      	movq	0x108(%rsp), %rcx
     a9d:      	movl	(%rcx), %ecx
     a9f:      	andl	$0xf, %ecx
     aa2:      	xorl	%edx, %edx
     aa4:      	cmpl	$0xb, %ecx
     aa7:      	setae	%dl
     aaa:      	leaq	(%rax,%rdx,8), %r12
     aae:      	addq	$0x8, %r12
     ab2:      	cmpl	$0x0, (%r13)
     ab7:      	je	0x1250 <perf_unwind_native+0x1250>
     abd:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
     ac7:      	movq	%rax, 0x8(%rsp)
     acc:      	movabsq	$0x616663202c544c50, %rax # imm = 0x616663202C544C50
     ad6:      	movq	%rax, (%rsp)
     ada:      	movl	$0x6, %ecx
     adf:      	movq	%rsp, %rdi
     ae2:      	movl	$0x10, %eax
     ae7:      	movl	$0x10, %esi
     aec:      	movq	%r12, %rdx
     aef:      	xorl	%eax, %eax
     af1:      	callq	*%rcx
     af3:      	jmp	0x1250 <perf_unwind_native+0x1250>
     af8:      	movq	0xf8(%rsp), %rdx
     b00:      	movq	(%rdx), %rax
     b03:      	addq	$0x28, %rax
     b07:      	movl	$0x70, %ecx
     b0c:      	leaq	0x60(%rsp), %rdi
     b11:      	movl	$0x90, %esi
     b16:      	movq	(%rdx), %rdx
     b19:      	addq	$0x28, %rdx
     b1d:      	movl	$0x90, %esi
     b22:      	callq	*%rcx
     b24:      	testq	%rax, %rax
     b27:      	jne	0x1965 <perf_unwind_native+0x1965>
     b2d:      	movq	0xc8(%rsp), %rax
     b35:      	movq	%rax, 0xee8(%r14)
     b3c:      	movq	0x68(%rsp), %rax
     b41:      	movq	%rax, 0xef0(%r14)
     b48:      	movq	0x78(%rsp), %rax
     b4d:      	movq	%rax, 0xef8(%r14)
     b54:      	movq	0x88(%rsp), %rax
     b5c:      	movq	%rax, 0xf00(%r14)
     b63:      	movq	0x98(%rsp), %rax
     b6b:      	movq	%rax, 0xf08(%r14)
     b72:      	movq	0xb0(%rsp), %rax
     b7a:      	movq	%rax, 0xee0(%r14)
     b81:      	movq	0xd8(%rsp), %rax
     b89:      	movq	%rax, 0xed8(%r14)
     b90:      	movq	0xe0(%rsp), %rax
     b98:      	movq	%rax, 0xed0(%r14)
     b9f:      	movb	$0x0, 0xf30(%r14)
     ba7:      	cmpl	$0x0, (%r13)
     bac:      	je	0x128f <perf_unwind_native+0x128f>
     bb2:      	movabsq	$0xa656d61726620, %rax  # imm = 0xA656D61726620
     bbc:      	movq	%rax, 0x6(%rsp)
     bc1:      	movabsq	$0x66206c616e676973, %rax # imm = 0x66206C616E676973
     bcb:      	movq	%rax, (%rsp)
     bcf:      	movl	$0x6, %ecx
     bd4:      	movq	%rsp, %rdi
     bd7:      	movl	$0xe, %eax
     bdc:      	movl	$0xe, %esi
     be1:      	xorl	%eax, %eax
     be3:      	callq	*%rcx
     be5:      	jmp	0x128f <perf_unwind_native+0x128f>
     bea:      	xorl	%edx, %edx
     bec:      	movslq	%ecx, %r12
     bef:      	addq	%rdx, %r12
     bf2:      	testb	%al, %al
     bf4:      	jns	0x1070 <perf_unwind_native+0x1070>
     bfa:      	movl	$0x70, %eax
     bff:      	leaq	0x48(%rsp), %rdi
     c04:      	movl	$0x8, %ecx
     c09:      	movl	$0x8, %esi
     c0e:      	movq	%r12, %rdx
     c11:      	callq	*%rax
     c13:      	testq	%rax, %rax
     c16:      	je	0xc2b <perf_unwind_native+0xc2b>
     c18:      	cmpl	$0x0, (%r13)
     c1d:      	jne	0x1801 <perf_unwind_native+0x1801>
     c23:      	xorl	%r12d, %r12d
     c26:      	jmp	0x1070 <perf_unwind_native+0x1070>
     c2b:      	shll	$0x3, %r15d
     c2f:      	andl	$0x38, %r15d
     c33:      	addq	0x48(%rsp), %r15
     c38:      	movq	%r15, %r12
     c3b:      	jmp	0x1070 <perf_unwind_native+0x1070>
     c40:      	movl	0x2c0(%r14), %edx
     c47:      	movabsq	$0x3d3d206425206576, %rax # imm = 0x3D3D206425206576
     c51:      	movq	%rax, 0x70(%rsp)
     c56:      	movabsq	$0x6974616e5f646e69, %rax # imm = 0x6974616E5F646E69
     c60:      	movq	%rax, 0x68(%rsp)
     c65:      	movabsq	$0x776e75203d3d3d3d, %rax # imm = 0x776E75203D3D3D3D
     c6f:      	movq	%rax, 0x60(%rsp)
     c74:      	movl	$0xa3d3d, 0x78(%rsp)    # imm = 0xA3D3D
     c7c:      	movl	$0x6, %ecx
     c81:      	leaq	0x60(%rsp), %rdi
     c86:      	movl	$0x1c, %eax
     c8b:      	movl	$0x1c, %esi
     c90:      	xorl	%eax, %eax
     c92:      	callq	*%rcx
     c94:      	jmp	0xc5 <perf_unwind_native+0xc5>
     c99:      	movabsq	$0xa786c253a786c25, %rax # imm = 0xA786C253A786C25
     ca3:      	movq	%rax, 0x18(%rsp)
     ca8:      	movabsq	$0x20726f662061746c, %rax # imm = 0x20726F662061746C
     cb2:      	movq	%rax, 0x10(%rsp)
     cb7:      	movabsq	$0x6564206b63617473, %rax # imm = 0x6564206B63617473
     cc1:      	movq	%rax, 0x8(%rsp)
     cc6:      	movabsq	$0x207075206b6f6f4c, %rax # imm = 0x207075206B6F6F4C
     cd0:      	movq	%rax, (%rsp)
     cd4:      	movb	$0x0, 0x20(%rsp)
     cd9:      	movl	$0x6, %r8d
     cdf:      	movq	%rsp, %rdi
     ce2:      	movl	$0x21, %eax
     ce7:      	movq	0xf10(%r14), %rdx
     cee:      	movq	0xf18(%r14), %rcx
     cf5:      	movl	$0x21, %esi
     cfa:      	xorl	%eax, %eax
     cfc:      	callq	*%r8
     cff:      	jmp	0x235 <perf_unwind_native+0x235>
     d04:      	movabsq	$0xa6425206f666e, %rcx  # imm = 0xA6425206F666E
     d0e:      	movq	%rcx, 0x25(%rsp)
     d13:      	movabsq	$0x6f666e49646e6977, %rcx # imm = 0x6F666E49646E6977
     d1d:      	movq	%rcx, 0x20(%rsp)
     d22:      	movabsq	$0x6e75202c78257830, %rcx # imm = 0x6E75202C78257830
     d2c:      	movq	%rcx, 0x18(%rsp)
     d31:      	movabsq	$0x20776f4c72646461, %rcx # imm = 0x20776F4C72646461
     d3b:      	movq	%rcx, 0x10(%rsp)
     d40:      	movabsq	$0x202c642520786564, %rcx # imm = 0x202C642520786564
     d4a:      	movq	%rcx, 0x8(%rsp)
     d4f:      	movabsq	$0x6e692061746c6564, %rcx # imm = 0x6E692061746C6564
     d59:      	movq	%rcx, (%rsp)
     d5d:      	movl	$0x6, %r9d
     d63:      	movq	%rsp, %rdi
     d66:      	movl	$0x2d, %ecx
     d6b:      	movl	0x5c(%rsp), %edx
     d6f:      	movzwl	(%rax), %ecx
     d72:      	movzwl	0x2(%rax), %r8d
     d77:      	movl	$0x2d, %esi
     d7c:      	movq	%rax, %rbx
     d7f:      	xorl	%eax, %eax
     d81:      	callq	*%r9
     d84:      	movq	%rbx, %rax
     d87:      	jmp	0x84d <perf_unwind_native+0x84d>
     d8c:      	movabsq	$0xa296425204449, %rax  # imm = 0xA296425204449
     d96:      	movq	%rax, 0x28(%rsp)
     d9b:      	movabsq	$0x70616d2820756c25, %rax # imm = 0x70616D2820756C25
     da5:      	movq	%rax, 0x20(%rsp)
     daa:      	movabsq	$0x206f7420756c2520, %rax # imm = 0x206F7420756C2520
     db4:      	movq	%rax, 0x18(%rsp)
     db9:      	movabsq	$0x6d6f726620656220, %rax # imm = 0x6D6F726620656220
     dc3:      	movq	%rax, 0x10(%rsp)
     dc8:      	movabsq	$0x646c756f68732073, %rax # imm = 0x646C756F68732073
     dd2:      	movq	%rax, 0x8(%rsp)
     dd7:      	movabsq	$0x6c61767265746e49, %rax # imm = 0x6C61767265746E49
     de1:      	movq	%rax, (%rsp)
     de5:      	movl	$0x6, %r9d
     deb:      	movq	%rsp, %rdi
     dee:      	movl	$0x30, %eax
     df3:      	movl	%ebp, %ecx
     df5:      	movzwl	0x6(%r12), %r8d
     dfb:      	movl	$0x30, %esi
     e00:      	movq	%r15, %rdx
     e03:      	xorl	%eax, %eax
     e05:      	callq	*%r9
     e08:      	jmp	0x404 <perf_unwind_native+0x404>
     e0d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     e17:      	movq	%rax, 0x86(%rsp)
     e1f:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     e29:      	movq	%rax, 0x80(%rsp)
     e31:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     e3b:      	movq	%rax, 0x78(%rsp)
     e40:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     e4a:      	movq	%rax, 0x70(%rsp)
     e4f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     e59:      	movq	%rax, 0x68(%rsp)
     e5e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     e68:      	movq	%rax, 0x60(%rsp)
     e6d:      	movl	$0x6, %ecx
     e72:      	leaq	0x60(%rsp), %rdi
     e77:      	movl	$0x2e, %eax
     e7c:      	movl	(%rsp), %edx
     e7f:      	movl	$0x2e, %esi
     e84:      	xorl	%eax, %eax
     e86:      	callq	*%rcx
     e88:      	cmpl	$0x0, (%r13)
     e8d:      	je	0x18b <perf_unwind_native+0x18b>
     e93:      	jmp	0xf4 <perf_unwind_native+0xf4>
     e98:      	movabsq	$0xa78323023252061, %rax # imm = 0xA78323023252061
     ea2:      	movq	%rax, 0x18(%rsp)
     ea7:      	movabsq	$0x746c656420646567, %rax # imm = 0x746C656420646567
     eb1:      	movq	%rax, 0x10(%rsp)
     eb6:      	movabsq	$0x72656d202c642520, %rax # imm = 0x72656D202C642520
     ec0:      	movq	%rax, 0x8(%rsp)
     ec5:      	movabsq	$0x6666694472646441, %rax # imm = 0x6666694472646441
     ecf:      	movq	%rax, (%rsp)
     ed3:      	movb	$0x0, 0x20(%rsp)
     ed8:      	movl	$0x6, %r8d
     ede:      	movq	%rsp, %rdi
     ee1:      	movl	$0x21, %eax
     ee6:      	movzbl	0x2(%rbx), %ecx
     eea:      	movl	$0x21, %esi
     eef:      	movl	%r12d, %edx
     ef2:      	xorl	%eax, %eax
     ef4:      	callq	*%r8
     ef7:      	movzbl	0x2(%rbx), %eax
     efb:      	jmp	0x8c7 <perf_unwind_native+0x8c7>
     f00:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     f0a:      	movq	%rax, 0x26(%rsp)
     f0f:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     f19:      	movq	%rax, 0x20(%rsp)
     f1e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     f28:      	movq	%rax, 0x18(%rsp)
     f2d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     f37:      	movq	%rax, 0x10(%rsp)
     f3c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     f46:      	movq	%rax, 0x8(%rsp)
     f4b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     f55:      	movq	%rax, (%rsp)
     f59:      	movl	$0x6, %ecx
     f5e:      	movq	%rsp, %rdi
     f61:      	movl	$0x2e, %eax
     f66:      	movl	0x104(%rsp), %edx
     f6d:      	movl	$0x2e, %esi
     f72:      	xorl	%eax, %eax
     f74:      	callq	*%rcx
     f76:      	movl	0x58(%rsp), %eax
     f7a:      	testw	%ax, %ax
     f7d:      	jns	0x891 <perf_unwind_native+0x891>
     f83:      	jmp	0xa0f <perf_unwind_native+0xa0f>
     f88:      	movabsq	$0xa64253d61746c65, %rax # imm = 0xA64253D61746C65
     f92:      	movq	%rax, 0x18(%rsp)
     f97:      	movabsq	$0x44616663203a6863, %rax # imm = 0x44616663203A6863
     fa1:      	movq	%rax, 0x10(%rsp)
     fa6:      	movabsq	$0x74616d2061746c65, %rax # imm = 0x74616D2061746C65
     fb0:      	movq	%rax, 0x8(%rsp)
     fb5:      	movabsq	$0x642064656772654d, %rax # imm = 0x642064656772654D
     fbf:      	movq	%rax, (%rsp)
     fc3:      	movb	$0x0, 0x20(%rsp)
     fc8:      	movl	$0x6, %ecx
     fcd:      	movq	%rsp, %rdi
     fd0:      	movl	$0x21, %eax
     fd5:      	movl	0x58(%rsp), %edx
     fd9:      	movl	$0x21, %esi
     fde:      	xorl	%eax, %eax
     fe0:      	callq	*%rcx
     fe2:      	jmp	0x8f0 <perf_unwind_native+0x8f0>
     fe7:      	movabsq	$0xa756c252b642572, %rax # imm = 0xA756C252B642572
     ff1:      	movq	%rax, 0x8(%rsp)
     ff6:      	movabsq	$0x203a646e69776e75, %rax # imm = 0x203A646E69776E75
    1000:      	movq	%rax, (%rsp)
    1004:      	movb	$0x0, 0x10(%rsp)
    1009:      	movl	$0x6, %r8d
    100f:      	movq	%rsp, %rdi
    1012:      	movl	$0x11, %eax
    1017:      	andl	$0xf, %r15d
    101b:      	movq	0x48(%rsp), %rcx
    1020:      	movl	$0x11, %esi
    1025:      	movl	%r15d, %edx
    1028:      	xorl	%eax, %eax
    102a:      	callq	*%r8
    102d:      	cmpl	$0xa, %r15d
    1031:      	jle	0x9b3 <perf_unwind_native+0x9b3>
    1037:      	movq	0x130(%rsp), %rax
    103f:      	cmpl	$0xb, %r15d
    1043:      	je	0x1059 <perf_unwind_native+0x1059>
    1045:      	movl	$0x0, %r12d
    104b:      	cmpl	$0xf, %r15d
    104f:      	jne	0x1070 <perf_unwind_native+0x1070>
    1051:      	movq	0x120(%rsp), %rax
    1059:      	movq	0x48(%rsp), %r12
    105e:      	addq	(%rax), %r12
    1061:      	nopw	%cs:(%rax,%rax)
    1070:      	movzbl	0x1(%rbx), %eax
    1074:      	movl	0x8(%rbx), %r13d
    1078:      	movl	%r13d, %ecx
    107b:      	andl	$-0x8, %ecx
    107e:      	testb	%al, %al
    1080:      	cmovnsl	%r13d, %ecx
    1084:      	movl	%eax, %edx
    1086:      	andl	$0x7f, %edx
    1089:      	cmpl	$0x2, %edx
    108c:      	jg	0x10a8 <perf_unwind_native+0x10a8>
    108e:      	movq	%r12, %rsi
    1091:      	cmpl	$0x1, %edx
    1094:      	je	0x1113 <perf_unwind_native+0x1113>
    1096:      	movq	0xf8(%rsp), %rsi
    109e:      	cmpl	$0x2, %edx
    10a1:      	je	0x1110 <perf_unwind_native+0x1110>
    10a3:      	jmp	0x1166 <perf_unwind_native+0x1166>
    10a8:      	movq	0xf0(%rsp), %rsi
    10b0:      	cmpl	$0x3, %edx
    10b3:      	je	0x1110 <perf_unwind_native+0x1110>
    10b5:      	cmpl	$0x5, %edx
    10b8:      	jne	0x1166 <perf_unwind_native+0x1166>
    10be:      	movl	%r13d, %eax
    10c1:      	sarl	%eax
    10c3:      	andl	$-0x8, %eax
    10c6:      	cltq
    10c8:      	movq	%rax, 0x48(%rsp)
    10cd:      	movq	(%rip), %rax            # 0x10d4 <perf_unwind_native+0x10d4>
    10d4:      	cmpl	$0x0, (%rax)
    10d7:      	jne	0x11ac <perf_unwind_native+0x11ac>
    10dd:      	andl	$0xf, %r13d
    10e1:      	cmpl	$0xa, %r13d
    10e5:      	jg	0x11fc <perf_unwind_native+0x11fc>
    10eb:      	movq	0x138(%rsp), %rax
    10f3:      	testl	%r13d, %r13d
    10f6:      	je	0x121c <perf_unwind_native+0x121c>
    10fc:      	movq	0x128(%rsp), %rax
    1104:      	cmpl	$0x9, %r13d
    1108:      	je	0x121c <perf_unwind_native+0x121c>
    110e:      	jmp	0x1166 <perf_unwind_native+0x1166>
    1110:      	movq	(%rsi), %rsi
    1113:      	movslq	%ecx, %r15
    1116:      	addq	%rsi, %r15
    1119:      	testb	%al, %al
    111b:      	js	0x1138 <perf_unwind_native+0x1138>
    111d:      	testq	%r15, %r15
    1120:      	movq	(%rip), %r13            # 0x1127 <perf_unwind_native+0x1127>
    1127:      	jne	0x1234 <perf_unwind_native+0x1234>
    112d:      	cmpb	$0x3, (%rbx)
    1130:      	jne	0x1250 <perf_unwind_native+0x1250>
    1136:      	jmp	0x1176 <perf_unwind_native+0x1176>
    1138:      	movl	$0x70, %eax
    113d:      	leaq	0x48(%rsp), %rdi
    1142:      	movl	$0x8, %ecx
    1147:      	movl	$0x8, %esi
    114c:      	movq	%r15, %rdx
    114f:      	callq	*%rax
    1151:      	testq	%rax, %rax
    1154:      	je	0x118a <perf_unwind_native+0x118a>
    1156:      	movq	(%rip), %rax            # 0x115d <perf_unwind_native+0x115d>
    115d:      	cmpl	$0x0, (%rax)
    1160:      	jne	0x1874 <perf_unwind_native+0x1874>
    1166:      	movq	(%rip), %r13            # 0x116d <perf_unwind_native+0x116d>
    116d:      	cmpb	$0x3, (%rbx)
    1170:      	jne	0x1250 <perf_unwind_native+0x1250>
    1176:      	movq	0xf0(%rsp), %rax
    117e:      	movq	$0x0, (%rax)
    1185:      	jmp	0x1250 <perf_unwind_native+0x1250>
    118a:      	shll	$0x3, %r13d
    118e:      	andl	$0x38, %r13d
    1192:      	addq	0x48(%rsp), %r13
    1197:      	movq	%r13, %r15
    119a:      	testq	%r15, %r15
    119d:      	movq	(%rip), %r13            # 0x11a4 <perf_unwind_native+0x11a4>
    11a4:      	jne	0x1234 <perf_unwind_native+0x1234>
    11aa:      	jmp	0x112d <perf_unwind_native+0x112d>
    11ac:      	movabsq	$0xa756c252b642572, %rax # imm = 0xA756C252B642572
    11b6:      	movq	%rax, 0x8(%rsp)
    11bb:      	movabsq	$0x203a646e69776e75, %rax # imm = 0x203A646E69776E75
    11c5:      	movq	%rax, (%rsp)
    11c9:      	movb	$0x0, 0x10(%rsp)
    11ce:      	movl	$0x6, %r8d
    11d4:      	movq	%rsp, %rdi
    11d7:      	movl	$0x11, %eax
    11dc:      	andl	$0xf, %r13d
    11e0:      	movq	0x48(%rsp), %rcx
    11e5:      	movl	$0x11, %esi
    11ea:      	movl	%r13d, %edx
    11ed:      	xorl	%eax, %eax
    11ef:      	callq	*%r8
    11f2:      	cmpl	$0xa, %r13d
    11f6:      	jle	0x10eb <perf_unwind_native+0x10eb>
    11fc:      	movq	0x130(%rsp), %rax
    1204:      	cmpl	$0xb, %r13d
    1208:      	je	0x121c <perf_unwind_native+0x121c>
    120a:      	cmpl	$0xf, %r13d
    120e:      	jne	0x1166 <perf_unwind_native+0x1166>
    1214:      	movq	0x120(%rsp), %rax
    121c:      	movq	0x48(%rsp), %r15
    1221:      	addq	(%rax), %r15
    1224:      	testq	%r15, %r15
    1227:      	movq	(%rip), %r13            # 0x122e <perf_unwind_native+0x122e>
    122e:      	je	0x112d <perf_unwind_native+0x112d>
    1234:      	movl	$0x70, %eax
    1239:      	movq	0xf0(%rsp), %rdi
    1241:      	movl	$0x8, %ecx
    1246:      	movl	$0x8, %esi
    124b:      	movq	%r15, %rdx
    124e:      	callq	*%rax
    1250:      	testq	%r12, %r12
    1253:      	je	0x1965 <perf_unwind_native+0x1965>
    1259:      	leaq	-0x8(%r12), %rdx
    125e:      	movl	$0x70, %eax
    1263:      	movq	0x108(%rsp), %rdi
    126b:      	movl	$0x8, %ecx
    1270:      	movl	$0x8, %esi
    1275:      	callq	*%rax
    1277:      	testq	%rax, %rax
    127a:      	jne	0x1965 <perf_unwind_native+0x1965>
    1280:      	movq	%r12, 0xed8(%r14)
    1287:      	movb	$0x1, 0xf30(%r14)
    128f:      	movl	$0x6, 0x48(%rsp)
    1297:      	movl	$0x1, %eax
    129c:      	movq	(%rip), %rdi            # 0x12a3 <perf_unwind_native+0x12a3>
    12a3:      	leaq	0x48(%rsp), %rsi
    12a8:      	callq	*%rax
    12aa:      	testq	%rax, %rax
    12ad:      	je	0x1340 <perf_unwind_native+0x1340>
    12b3:      	incq	(%rax)
    12b6:      	cmpl	$0x0, (%r13)
    12bb:      	je	0x134b <perf_unwind_native+0x134b>
    12c1:      	movabsq	$0xa786c6c25203a, %rax  # imm = 0xA786C6C25203A
    12cb:      	movq	%rax, 0x75(%rsp)
    12d0:      	movabsq	$0x25203a706620786c, %rax # imm = 0x25203A706620786C
    12da:      	movq	%rax, 0x70(%rsp)
    12df:      	movabsq	$0x6c25203a70732078, %rax # imm = 0x6C25203A70732078
    12e9:      	movq	%rax, 0x68(%rsp)
    12ee:      	movabsq	$0x6c6c25203a637020, %rax # imm = 0x6C6C25203A637020
    12f8:      	movq	%rax, 0x60(%rsp)
    12fd:      	movl	$0x6, %r9d
    1303:      	leaq	0x60(%rsp), %rdi
    1308:      	movl	$0x1d, %eax
    130d:      	movq	0x108(%rsp), %rax
    1315:      	movq	(%rax), %rdx
    1318:      	movq	0xf8(%rsp), %rax
    1320:      	movq	(%rax), %rcx
    1323:      	movq	0xf0(%rsp), %rax
    132b:      	movq	(%rax), %r8
    132e:      	movl	$0x1d, %esi
    1333:      	xorl	%eax, %eax
    1335:      	callq	*%r9
    1338:      	jmp	0x134b <perf_unwind_native+0x134b>
    133a:      	nopw	(%rax,%rax)
    1340:      	cmpl	$0x0, (%r13)
    1345:      	jne	0x16a0 <perf_unwind_native+0x16a0>
    134b:      	movq	0x108(%rsp), %rax
    1353:      	movq	(%rax), %r15
    1356:      	movl	(%r13), %eax
    135a:      	testq	%r15, %r15
    135d:      	je	0x1c09 <perf_unwind_native+0x1c09>
    1363:      	testl	%eax, %eax
    1365:      	jne	0x14d1 <perf_unwind_native+0x14d1>
    136b:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    1375:      	cmpq	%rax, %r15
    1378:      	ja	0x1c26 <perf_unwind_native+0x1c26>
    137e:      	cmpq	$0xfff, %r15            # imm = 0xFFF
    1385:      	jbe	0x1c43 <perf_unwind_native+0x1c43>
    138b:      	movl	(%r14), %eax
    138e:      	movl	$0x60, (%rsp)
    1395:      	movbel	%eax, 0x4(%rsp)
    139b:      	movbeq	%r15, 0x8(%rsp)
    13a2:      	movl	$0x1, %eax
    13a7:      	movq	%rsp, %rsi
    13aa:      	movq	(%rip), %rdi            # 0x13b1 <perf_unwind_native+0x13b1>
    13b1:      	callq	*%rax
    13b3:      	testq	%rax, %rax
    13b6:      	je	0x1c60 <perf_unwind_native+0x1c60>
    13bc:      	movq	0x8(%rax), %rbx
    13c0:      	movq	%rbx, %rcx
    13c3:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    13cd:      	andq	%rdx, %rcx
    13d0:      	movq	%rcx, 0xf20(%r14)
    13d7:      	movq	(%rax), %rax
    13da:      	movq	%rax, 0xf10(%r14)
    13e1:      	shrq	$0x38, %rbx
    13e5:      	movq	%r15, %rax
    13e8:      	subq	%rcx, %rax
    13eb:      	movq	%rax, 0xf18(%r14)
    13f2:      	cmpl	$0x0, (%r13)
    13f7:      	jne	0x1577 <perf_unwind_native+0x1577>
    13fd:      	cmpl	$0x1, %ebx
    1400:      	jne	0x17e0 <perf_unwind_native+0x17e0>
    1406:      	movq	0xf10(%r14), %rax
    140d:      	movq	%rax, (%rsp)
    1411:      	movq	0xf18(%r14), %r15
    1418:      	movl	$0x1, %eax
    141d:      	movq	%rsp, %rsi
    1420:      	movq	(%rip), %rdi            # 0x1427 <perf_unwind_native+0x1427>
    1427:      	callq	*%rax
    1429:      	movl	$0x1, %ebx
    142e:      	testq	%rax, %rax
    1431:      	je	0x17e0 <perf_unwind_native+0x17e0>
    1437:      	cmpq	%r15, (%rax)
    143a:      	ja	0x1442 <perf_unwind_native+0x1442>
    143c:      	cmpq	%r15, 0x8(%rax)
    1440:      	jae	0x1456 <perf_unwind_native+0x1456>
    1442:      	cmpq	%r15, 0x10(%rax)
    1446:      	ja	0x17e0 <perf_unwind_native+0x17e0>
    144c:      	cmpq	%r15, 0x18(%rax)
    1450:      	jb	0x17e0 <perf_unwind_native+0x17e0>
    1456:      	cmpl	$0x0, (%r13)
    145b:      	jne	0x1723 <perf_unwind_native+0x1723>
    1461:      	movl	0x1380(%r14), %ecx
    1468:      	movl	0x20(%rax), %edx
    146b:      	btl	%edx, %ecx
    146e:      	jae	0x1794 <perf_unwind_native+0x1794>
    1474:      	cmpl	$0x0, (%r13)
    1479:      	je	0x17e0 <perf_unwind_native+0x17e0>
    147f:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    1489:      	movq	%rax, 0x70(%rsp)
    148e:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    1498:      	movq	%rax, 0x68(%rsp)
    149d:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    14a7:      	movq	%rax, 0x60(%rsp)
    14ac:      	movl	$0xa656e, 0x77(%rsp)    # imm = 0xA656E
    14b4:      	movl	$0x6, %ecx
    14b9:      	leaq	0x60(%rsp), %rdi
    14be:      	movl	$0x1b, %eax
    14c3:      	movl	$0x1b, %esi
    14c8:      	xorl	%eax, %eax
    14ca:      	callq	*%rcx
    14cc:      	jmp	0x17e0 <perf_unwind_native+0x17e0>
    14d1:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    14db:      	movq	%rax, 0x88(%rsp)
    14e3:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    14ed:      	movq	%rax, 0x80(%rsp)
    14f5:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    14ff:      	movq	%rax, 0x78(%rsp)
    1504:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    150e:      	movq	%rax, 0x70(%rsp)
    1513:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    151d:      	movq	%rax, 0x68(%rsp)
    1522:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    152c:      	movq	%rax, 0x60(%rsp)
    1531:      	movb	$0x0, 0x90(%rsp)
    1539:      	movl	$0x6, %ecx
    153e:      	leaq	0x60(%rsp), %rdi
    1543:      	movl	$0x31, %eax
    1548:      	movl	0x2c0(%r14), %edx
    154f:      	movl	$0x31, %esi
    1554:      	xorl	%eax, %eax
    1556:      	callq	*%rcx
    1558:      	movq	0xed0(%r14), %r15
    155f:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    1569:      	cmpq	%rax, %r15
    156c:      	jbe	0x137e <perf_unwind_native+0x137e>
    1572:      	jmp	0x1c26 <perf_unwind_native+0x1c26>
    1577:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    1581:      	movq	%rax, 0x88(%rsp)
    1589:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    1593:      	movq	%rax, 0x80(%rsp)
    159b:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    15a5:      	movq	%rax, 0x78(%rsp)
    15aa:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    15b4:      	movq	%rax, 0x70(%rsp)
    15b9:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    15c3:      	movq	%rax, 0x68(%rsp)
    15c8:      	movabsq	$0x6365732074786554, %rax # imm = 0x6365732074786554
    15d2:      	movq	%rax, 0x60(%rsp)
    15d7:      	movw	$0xa, 0x90(%rsp)
    15e1:      	movl	$0x6, %r9d
    15e7:      	leaq	0x60(%rsp), %rdi
    15ec:      	movl	$0x32, %eax
    15f1:      	movq	0xf10(%r14), %rcx
    15f8:      	movl	$0x32, %esi
    15fd:      	movq	%r15, %rdx
    1600:      	movl	%ebx, %r8d
    1603:      	xorl	%eax, %eax
    1605:      	callq	*%r9
    1608:      	cmpl	$0x0, (%r13)
    160d:      	je	0x13fd <perf_unwind_native+0x13fd>
    1613:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    161d:      	movq	%rax, 0x87(%rsp)
    1625:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    162f:      	movq	%rax, 0x80(%rsp)
    1637:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    1641:      	movq	%rax, 0x78(%rsp)
    1646:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    1650:      	movq	%rax, 0x70(%rsp)
    1655:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    165f:      	movq	%rax, 0x68(%rsp)
    1664:      	movabsq	$0x6365732074786554, %rax # imm = 0x6365732074786554
    166e:      	movq	%rax, 0x60(%rsp)
    1673:      	movl	$0x6, %r8d
    1679:      	leaq	0x60(%rsp), %rdi
    167e:      	movl	$0x2f, %eax
    1683:      	movq	0xf18(%r14), %rcx
    168a:      	movq	0xf20(%r14), %rdx
    1691:      	movl	$0x2f, %esi
    1696:      	xorl	%eax, %eax
    1698:      	callq	*%r8
    169b:      	jmp	0x13fd <perf_unwind_native+0x13fd>
    16a0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    16aa:      	movq	%rax, 0x26(%rsp)
    16af:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    16b9:      	movq	%rax, 0x20(%rsp)
    16be:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    16c8:      	movq	%rax, 0x18(%rsp)
    16cd:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    16d7:      	movq	%rax, 0x10(%rsp)
    16dc:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    16e6:      	movq	%rax, 0x8(%rsp)
    16eb:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    16f5:      	movq	%rax, (%rsp)
    16f9:      	movl	$0x6, %ecx
    16fe:      	movq	%rsp, %rdi
    1701:      	movl	$0x2e, %eax
    1706:      	movl	0x48(%rsp), %edx
    170a:      	movl	$0x2e, %esi
    170f:      	xorl	%eax, %eax
    1711:      	callq	*%rcx
    1713:      	cmpl	$0x0, (%r13)
    1718:      	je	0x134b <perf_unwind_native+0x134b>
    171e:      	jmp	0x12c1 <perf_unwind_native+0x12c1>
    1723:      	movabsq	$0xa642520686374, %rcx  # imm = 0xA642520686374
    172d:      	movq	%rcx, 0x76(%rsp)
    1732:      	movabsq	$0x6374616d20737465, %rcx # imm = 0x6374616D20737465
    173c:      	movq	%rcx, 0x70(%rsp)
    1741:      	movabsq	$0x7366666f5f726574, %rcx # imm = 0x7366666F5F726574
    174b:      	movq	%rcx, 0x68(%rsp)
    1750:      	movabsq	$0x6572707265746e69, %rcx # imm = 0x6572707265746E69
    175a:      	movq	%rcx, 0x60(%rsp)
    175f:      	movl	$0x6, %ecx
    1764:      	leaq	0x60(%rsp), %rdi
    1769:      	movl	$0x1e, %edx
    176e:      	movzwl	0x20(%rax), %edx
    1772:      	movl	$0x1e, %esi
    1777:      	movq	%rax, %r15
    177a:      	xorl	%eax, %eax
    177c:      	callq	*%rcx
    177e:      	movq	%r15, %rax
    1781:      	movl	0x1380(%r14), %ecx
    1788:      	movl	0x20(%rax), %edx
    178b:      	btl	%edx, %ecx
    178e:      	jb	0x1474 <perf_unwind_native+0x1474>
    1794:      	movq	%rax, %rbx
    1797:      	movl	$0x0, 0x48(%rsp)
    179f:      	movl	$0x1, %eax
    17a4:      	movq	(%rip), %rdi            # 0x17ab <perf_unwind_native+0x17ab>
    17ab:      	leaq	0x48(%rsp), %rsi
    17b0:      	callq	*%rax
    17b2:      	testq	%rax, %rax
    17b5:      	je	0x17bf <perf_unwind_native+0x17bf>
    17b7:      	incq	(%rax)
    17ba:      	movq	%rbx, %rax
    17bd:      	jmp	0x17cd <perf_unwind_native+0x17cd>
    17bf:      	cmpl	$0x0, (%r13)
    17c4:      	movq	%rbx, %rax
    17c7:      	jne	0x18e4 <perf_unwind_native+0x18e4>
    17cd:      	movzwl	0x20(%rax), %ebx
    17d1:      	nopw	%cs:(%rax,%rax)
    17e0:      	xorl	%ebp, %ebp
    17e2:      	cmpl	$0x1, %ebx
    17e5:      	movl	0x11c(%rsp), %r15d
    17ed:      	jne	0x1ca9 <perf_unwind_native+0x1ca9>
    17f3:      	decl	%r15d
    17f6:      	jne	0xba <perf_unwind_native+0xba>
    17fc:      	jmp	0x1c7d <perf_unwind_native+0x1c7d>
    1801:      	movabsq	$0x2578302073736572, %rax # imm = 0x2578302073736572
    180b:      	movq	%rax, 0x20(%rsp)
    1810:      	movabsq	$0x6464612065636e65, %rax # imm = 0x6464612065636E65
    181a:      	movq	%rax, 0x18(%rsp)
    181f:      	movabsq	$0x7265666572656420, %rax # imm = 0x7265666572656420
    1829:      	movq	%rax, 0x10(%rsp)
    182e:      	movabsq	$0x6f742064656c6961, %rax # imm = 0x6F742064656C6961
    1838:      	movq	%rax, 0x8(%rsp)
    183d:      	movabsq	$0x6620646e69776e75, %rax # imm = 0x6620646E69776E75
    1847:      	movq	%rax, (%rsp)
    184b:      	movl	$0xa786c, 0x28(%rsp)    # imm = 0xA786C
    1853:      	movl	$0x6, %ecx
    1858:      	movq	%rsp, %rdi
    185b:      	movl	$0x2c, %eax
    1860:      	movl	$0x2c, %esi
    1865:      	movq	%r12, %rdx
    1868:      	xorl	%eax, %eax
    186a:      	callq	*%rcx
    186c:      	xorl	%r12d, %r12d
    186f:      	jmp	0x1070 <perf_unwind_native+0x1070>
    1874:      	movabsq	$0x2578302073736572, %rax # imm = 0x2578302073736572
    187e:      	movq	%rax, 0x20(%rsp)
    1883:      	movabsq	$0x6464612065636e65, %rax # imm = 0x6464612065636E65
    188d:      	movq	%rax, 0x18(%rsp)
    1892:      	movabsq	$0x7265666572656420, %rax # imm = 0x7265666572656420
    189c:      	movq	%rax, 0x10(%rsp)
    18a1:      	movabsq	$0x6f742064656c6961, %rax # imm = 0x6F742064656C6961
    18ab:      	movq	%rax, 0x8(%rsp)
    18b0:      	movabsq	$0x6620646e69776e75, %rax # imm = 0x6620646E69776E75
    18ba:      	movq	%rax, (%rsp)
    18be:      	movl	$0xa786c, 0x28(%rsp)    # imm = 0xA786C
    18c6:      	movl	$0x6, %ecx
    18cb:      	movq	%rsp, %rdi
    18ce:      	movl	$0x2c, %eax
    18d3:      	movl	$0x2c, %esi
    18d8:      	movq	%r15, %rdx
    18db:      	xorl	%eax, %eax
    18dd:      	callq	*%rcx
    18df:      	jmp	0x1166 <perf_unwind_native+0x1166>
    18e4:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    18ee:      	movq	%rax, 0x86(%rsp)
    18f6:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1900:      	movq	%rax, 0x80(%rsp)
    1908:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1912:      	movq	%rax, 0x78(%rsp)
    1917:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1921:      	movq	%rax, 0x70(%rsp)
    1926:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1930:      	movq	%rax, 0x68(%rsp)
    1935:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    193f:      	movq	%rax, 0x60(%rsp)
    1944:      	movl	$0x6, %ecx
    1949:      	leaq	0x60(%rsp), %rdi
    194e:      	movl	$0x2e, %eax
    1953:      	movl	0x48(%rsp), %edx
    1957:      	movl	$0x2e, %esi
    195c:      	xorl	%eax, %eax
    195e:      	callq	*%rcx
    1960:      	jmp	0x17ba <perf_unwind_native+0x17ba>
    1965:      	movl	$0xe, 0x48(%rsp)
    196d:      	movq	(%rip), %rdi            # 0x1974 <perf_unwind_native+0x1974>
    1974:      	leaq	0x48(%rsp), %rsi
    1979:      	movl	$0x1, %eax
    197e:      	callq	*%rax
    1980:      	testq	%rax, %rax
    1983:      	je	0x1c84 <perf_unwind_native+0x1c84>
    1989:      	incq	(%rax)
    198c:      	jmp	0x1c8f <perf_unwind_native+0x1c8f>
    1991:      	movq	(%rip), %r13            # 0x1998 <perf_unwind_native+0x1998>
    1998:      	movl	$0xfa3, %ebp            # imm = 0xFA3
    199d:      	movl	$0x9, %ebx
    19a2:      	cmpl	$0x0, (%r13)
    19a7:      	je	0x1ca0 <perf_unwind_native+0x1ca0>
    19ad:      	movabsq	$0x6174616420747075, %rax # imm = 0x6174616420747075
    19b7:      	movq	%rax, 0x20(%rsp)
    19bc:      	movabsq	$0x72726f43202e7370, %rax # imm = 0x72726F43202E7370
    19c6:      	movq	%rax, 0x18(%rsp)
    19cb:      	movabsq	$0x657473203631206e, %rax # imm = 0x657473203631206E
    19d5:      	movq	%rax, 0x10(%rsp)
    19da:      	movabsq	$0x6920686372616573, %rax # imm = 0x6920686372616573
    19e4:      	movq	%rax, 0x8(%rsp)
    19e9:      	movabsq	$0x622064656c696146, %rax # imm = 0x622064656C696146
    19f3:      	movq	%rax, (%rsp)
    19f7:      	movl	$0xa3f61, 0x27(%rsp)    # imm = 0xA3F61
    19ff:      	movq	%rsp, %rdi
    1a02:      	movl	$0x2b, %eax
    1a07:      	movl	$0x6, %ecx
    1a0c:      	movl	$0x2b, %esi
    1a11:      	xorl	%eax, %eax
    1a13:      	callq	*%rcx
    1a15:      	jmp	0x1ca0 <perf_unwind_native+0x1ca0>
    1a1a:      	cmpl	$0x0, (%r13)
    1a1f:      	jne	0x1faa <perf_unwind_native+0x1faa>
    1a25:      	movl	$0x2, (%rsp)
    1a2c:      	movq	(%rip), %rdi            # 0x1a33 <perf_unwind_native+0x1a33>
    1a33:      	movq	%rsp, %rsi
    1a36:      	movl	$0x1, %eax
    1a3b:      	callq	*%rax
    1a3d:      	testq	%rax, %rax
    1a40:      	je	0x1db4 <perf_unwind_native+0x1db4>
    1a46:      	incq	(%rax)
    1a49:      	xorl	%ebx, %ebx
    1a4b:      	cmpl	$0x0, (%r13)
    1a50:      	movl	$0x2, %ebp
    1a55:      	je	0x1ca9 <perf_unwind_native+0x1ca9>
    1a5b:      	movabsq	$0xa656d61726620, %rax  # imm = 0xA656D61726620
    1a65:      	movq	%rax, 0x75(%rsp)
    1a6a:      	movabsq	$0x7266206576697461, %rax # imm = 0x7266206576697461
    1a74:      	movq	%rax, 0x70(%rsp)
    1a79:      	movabsq	$0x6e2068737570206f, %rax # imm = 0x6E2068737570206F
    1a83:      	movq	%rax, 0x68(%rsp)
    1a88:      	movabsq	$0x742064656c696166, %rax # imm = 0x742064656C696166
    1a92:      	movq	%rax, 0x60(%rsp)
    1a97:      	leaq	0x60(%rsp), %rdi
    1a9c:      	movl	$0x1d, %eax
    1aa1:      	movl	$0x6, %ecx
    1aa6:      	xorl	%ebx, %ebx
    1aa8:      	movl	$0x1d, %esi
    1aad:      	xorl	%eax, %eax
    1aaf:      	callq	*%rcx
    1ab1:      	jmp	0x1ca9 <perf_unwind_native+0x1ca9>
    1ab6:      	movl	$0xfa0, %ebp            # imm = 0xFA0
    1abb:      	movl	$0x8, %ebx
    1ac0:      	cmpl	$0x0, (%r13)
    1ac5:      	je	0x1ca0 <perf_unwind_native+0x1ca0>
    1acb:      	movabsq	$0x786c252065676170, %rax # imm = 0x786C252065676170
    1ad5:      	movq	%rax, 0x30(%rsp)
    1ada:      	movabsq	$0x202c786c25204449, %rax # imm = 0x202C786C25204449
    1ae4:      	movq	%rax, 0x28(%rsp)
    1ae9:      	movabsq	$0x656c696620656761, %rax # imm = 0x656C696620656761
    1af3:      	movq	%rax, 0x20(%rsp)
    1af8:      	movabsq	$0x702061746c656420, %rax # imm = 0x702061746C656420
    1b02:      	movq	%rax, 0x18(%rsp)
    1b07:      	movabsq	$0x6b63617473207075, %rax # imm = 0x6B63617473207075
    1b11:      	movq	%rax, 0x10(%rsp)
    1b16:      	movabsq	$0x206b6f6f6c206f74, %rax # imm = 0x206B6F6F6C206F74
    1b20:      	movq	%rax, 0x8(%rsp)
    1b25:      	movabsq	$0x206572756c696146, %rax # imm = 0x206572756C696146
    1b2f:      	movq	%rax, (%rsp)
    1b33:      	movw	$0xa, 0x38(%rsp)
    1b3a:      	movq	%rsp, %rdi
    1b3d:      	movl	$0x3a, %eax
    1b42:      	movl	$0x6, %r8d
    1b48:      	movq	0x48(%rsp), %rdx
    1b4d:      	movq	0x50(%rsp), %rcx
    1b52:      	movl	$0x3a, %esi
    1b57:      	xorl	%eax, %eax
    1b59:      	callq	*%r8
    1b5c:      	jmp	0x1ca0 <perf_unwind_native+0x1ca0>
    1b61:      	movl	$0xfa2, %ebp            # imm = 0xFA2
    1b66:      	movl	$0x32, %ebx
    1b6b:      	cmpl	$0x0, (%r13)
    1b70:      	je	0x1ca0 <perf_unwind_native+0x1ca0>
    1b76:      	movabsq	$0x6c25206e6f697463, %rax # imm = 0x6C25206E6F697463
    1b80:      	movq	%rax, 0x28(%rsp)
    1b85:      	movabsq	$0x6573207478657420, %rax # imm = 0x6573207478657420
    1b8f:      	movq	%rax, 0x20(%rsp)
    1b94:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1b9e:      	movq	%rax, 0x18(%rsp)
    1ba3:      	movabsq	$0x72656e6e69207075, %rax # imm = 0x72656E6E69207075
    1bad:      	movq	%rax, 0x10(%rsp)
    1bb2:      	movabsq	$0x206b6f6f6c206f74, %rax # imm = 0x206B6F6F6C206F74
    1bbc:      	movq	%rax, 0x8(%rsp)
    1bc1:      	movabsq	$0x206572756c696146, %rax # imm = 0x206572756C696146
    1bcb:      	movq	%rax, (%rsp)
    1bcf:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    1bd7:      	movq	%rsp, %rdi
    1bda:      	movl	$0x33, %eax
    1bdf:      	movl	$0x6, %ecx
    1be4:      	movq	0x110(%rsp), %rdx
    1bec:      	movl	$0x33, %esi
    1bf1:      	xorl	%eax, %eax
    1bf3:      	callq	*%rcx
    1bf5:      	jmp	0x1ca0 <perf_unwind_native+0x1ca0>
    1bfa:      	movl	$0xfa4, %ebp            # imm = 0xFA4
    1bff:      	movl	$0xa, %ebx
    1c04:      	jmp	0x1ca0 <perf_unwind_native+0x1ca0>
    1c09:      	testl	%eax, %eax
    1c0b:      	jne	0x2012 <perf_unwind_native+0x2012>
    1c11:      	movl	$0x1, 0xf28(%r14)
    1c1c:      	movl	$0xfad, %ebp            # imm = 0xFAD
    1c21:      	jmp	0x1ca7 <perf_unwind_native+0x1ca7>
    1c26:      	cmpl	$0x0, (%r13)
    1c2b:      	jne	0x2097 <perf_unwind_native+0x2097>
    1c31:      	movl	$0xb, 0xf28(%r14)
    1c3c:      	movl	$0xfab, %ebp            # imm = 0xFAB
    1c41:      	jmp	0x1ca7 <perf_unwind_native+0x1ca7>
    1c43:      	cmpl	$0x0, (%r13)
    1c48:      	jne	0x20fd <perf_unwind_native+0x20fd>
    1c4e:      	movl	$0x31, 0xf28(%r14)
    1c59:      	movl	$0xfae, %ebp            # imm = 0xFAE
    1c5e:      	jmp	0x1ca7 <perf_unwind_native+0x1ca7>
    1c60:      	cmpl	$0x0, (%r13)
    1c65:      	jne	0x2159 <perf_unwind_native+0x2159>
    1c6b:      	movl	$0xc, 0xf28(%r14)
    1c76:      	movl	$0xfac, %ebp            # imm = 0xFAC
    1c7b:      	jmp	0x1ca7 <perf_unwind_native+0x1ca7>
    1c7d:      	movl	$0x1, %ebx
    1c82:      	jmp	0x1ca9 <perf_unwind_native+0x1ca9>
    1c84:      	cmpl	$0x0, (%r13)
    1c89:      	jne	0x21f3 <perf_unwind_native+0x21f3>
    1c8f:      	movl	$0xfa7, %ebp            # imm = 0xFA7
    1c94:      	jmp	0x1ca7 <perf_unwind_native+0x1ca7>
    1c96:      	movl	$0xfa5, %ebp            # imm = 0xFA5
    1c9b:      	movl	$0xd, %ebx
    1ca0:      	movl	%ebx, 0xf28(%r14)
    1ca7:      	xorl	%ebx, %ebx
    1ca9:      	movl	%ebp, 0xf2c(%r14)
    1cb0:      	movl	$0x0, 0x60(%rsp)
    1cb8:      	movq	(%rip), %rdi            # 0x1cbf <perf_unwind_native+0x1cbf>
    1cbf:      	leaq	0x60(%rsp), %rsi
    1cc4:      	movl	$0x1, %eax
    1cc9:      	callq	*%rax
    1ccb:      	testq	%rax, %rax
    1cce:      	je	0x1d1b <perf_unwind_native+0x1d1b>
    1cd0:      	movzbl	0x1384(%rax), %ecx
    1cd7:      	movl	%ebx, %edx
    1cd9:      	cmpb	$0x1d, %cl
    1cdc:      	movq	0x140(%rsp), %rdi
    1ce4:      	jb	0x1d4e <perf_unwind_native+0x1d4e>
    1ce6:      	movq	%rdi, %r15
    1ce9:      	movq	%rax, %r14
    1cec:      	movl	$0x5, 0xf2c(%rax)
    1cf6:      	movl	$0x44, (%rsp)
    1cfd:      	movq	(%rip), %rdi            # 0x1d04 <perf_unwind_native+0x1d04>
    1d04:      	movq	%rsp, %rsi
    1d07:      	movl	$0x1, %eax
    1d0c:      	callq	*%rax
    1d0e:      	testq	%rax, %rax
    1d11:      	je	0x1d33 <perf_unwind_native+0x1d33>
    1d13:      	incq	(%rax)
    1d16:      	movq	%r15, %rdi
    1d19:      	jmp	0x1d41 <perf_unwind_native+0x1d41>
    1d1b:      	movq	(%rip), %rcx            # 0x1d22 <perf_unwind_native+0x1d22>
    1d22:      	xorl	%edx, %edx
    1d24:      	movl	$0xc, %eax
    1d29:      	movq	0x140(%rsp), %rdi
    1d31:      	jmp	0x1d64 <perf_unwind_native+0x1d64>
    1d33:      	cmpl	$0x0, (%r13)
    1d38:      	movq	%r15, %rdi
    1d3b:      	jne	0x1f2a <perf_unwind_native+0x1f2a>
    1d41:      	movq	%r14, %rax
    1d44:      	movzbl	0x1384(%r14), %ecx
    1d4c:      	xorl	%edx, %edx
    1d4e:      	incb	%cl
    1d50:      	movb	%cl, 0x1384(%rax)
    1d56:      	movl	%edx, %ecx
    1d58:      	movq	(%rip), %rsi            # 0x1d5f <perf_unwind_native+0x1d5f>
    1d5f:      	movl	$0xc, %eax
    1d64:      	movq	(%rip), %rsi            # 0x1d6b <perf_unwind_native+0x1d6b>
    1d6b:      	callq	*%rax
    1d6d:      	cmpl	$0x0, (%r13)
    1d72:      	jne	0x1eab <perf_unwind_native+0x1eab>
    1d78:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
    1d7d:      	addq	$0x148, %rsp            # imm = 0x148
    1d84:      	popq	%rbx
    1d85:      	popq	%r12
    1d87:      	popq	%r13
    1d89:      	popq	%r14
    1d8b:      	popq	%r15
    1d8d:      	popq	%rbp
    1d8e:      	retq
    1d8f:      	movl	$0x55, 0x48(%rsp)
    1d97:      	movq	(%rip), %rdi            # 0x1d9e <perf_unwind_native+0x1d9e>
    1d9e:      	leaq	0x48(%rsp), %rsi
    1da3:      	movl	$0x1, %eax
    1da8:      	callq	*%rax
    1daa:      	testq	%rax, %rax
    1dad:      	je	0x1dd5 <perf_unwind_native+0x1dd5>
    1daf:      	incq	(%rax)
    1db2:      	jmp	0x1de0 <perf_unwind_native+0x1de0>
    1db4:      	cmpl	$0x0, (%r13)
    1db9:      	jne	0x226b <perf_unwind_native+0x226b>
    1dbf:      	movl	$0x2, %ebp
    1dc4:      	jmp	0x1ca7 <perf_unwind_native+0x1ca7>
    1dc9:      	cmpl	$0x1, %eax
    1dcc:      	jne	0x1dea <perf_unwind_native+0x1dea>
    1dce:      	xorl	%ebp, %ebp
    1dd0:      	jmp	0x1ca7 <perf_unwind_native+0x1ca7>
    1dd5:      	cmpl	$0x0, (%r13)
    1dda:      	jne	0x22fd <perf_unwind_native+0x22fd>
    1de0:      	movl	$0xfaf, %ebp            # imm = 0xFAF
    1de5:      	jmp	0x1ca7 <perf_unwind_native+0x1ca7>
    1dea:      	movl	$0x1, %ebp
    1def:      	jmp	0x1ca7 <perf_unwind_native+0x1ca7>
    1df4:      	movl	$0xfa1, %ebp            # imm = 0xFA1
    1df9:      	movl	$0x33, %ebx
    1dfe:      	cmpl	$0x0, (%r13)
    1e03:      	je	0x1ca0 <perf_unwind_native+0x1ca0>
    1e09:      	movabsq	$0xa642520444970, %rax  # imm = 0xA642520444970
    1e13:      	movq	%rax, 0x37(%rsp)
    1e18:      	movabsq	$0x70616d206e692078, %rax # imm = 0x70616D206E692078
    1e22:      	movq	%rax, 0x30(%rsp)
    1e27:      	movabsq	$0x6c25206e6f697463, %rax # imm = 0x6C25206E6F697463
    1e31:      	movq	%rax, 0x28(%rsp)
    1e36:      	movabsq	$0x6573207478657420, %rax # imm = 0x6573207478657420
    1e40:      	movq	%rax, 0x20(%rsp)
    1e45:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1e4f:      	movq	%rax, 0x18(%rsp)
    1e54:      	movabsq	$0x726574756f207075, %rax # imm = 0x726574756F207075
    1e5e:      	movq	%rax, 0x10(%rsp)
    1e63:      	movabsq	$0x206b6f6f6c206f74, %rax # imm = 0x206B6F6F6C206F74
    1e6d:      	movq	%rax, 0x8(%rsp)
    1e72:      	movabsq	$0x206572756c696146, %rax # imm = 0x206572756C696146
    1e7c:      	movq	%rax, (%rsp)
    1e80:      	movq	%rsp, %rdi
    1e83:      	movl	$0x3f, %eax
    1e88:      	movl	$0x6, %r8d
    1e8e:      	movq	0x110(%rsp), %rdx
    1e96:      	movzwl	0x6(%r12), %ecx
    1e9c:      	movl	$0x3f, %esi
    1ea1:      	xorl	%eax, %eax
    1ea3:      	callq	*%r8
    1ea6:      	jmp	0x1ca0 <perf_unwind_native+0x1ca0>
    1eab:      	movabsq	$0xa65766974616e, %rax  # imm = 0xA65766974616E
    1eb5:      	movq	%rax, 0x86(%rsp)
    1ebd:      	movabsq	$0x616e5f646e69776e, %rax # imm = 0x616E5F646E69776E
    1ec7:      	movq	%rax, 0x80(%rsp)
    1ecf:      	movabsq	$0x75206e6920642520, %rax # imm = 0x75206E6920642520
    1ed9:      	movq	%rax, 0x78(%rsp)
    1ede:      	movabsq	$0x726f662064656c69, %rax # imm = 0x726F662064656C69
    1ee8:      	movq	%rax, 0x70(%rsp)
    1eed:      	movabsq	$0x6166206c6c616320, %rax # imm = 0x6166206C6C616320
    1ef7:      	movq	%rax, 0x68(%rsp)
    1efc:      	movabsq	$0x6c6961745f667062, %rax # imm = 0x6C6961745F667062
    1f06:      	movq	%rax, 0x60(%rsp)
    1f0b:      	leaq	0x60(%rsp), %rdi
    1f10:      	movl	$0x2e, %eax
    1f15:      	movl	$0x6, %ecx
    1f1a:      	movl	$0x2e, %esi
    1f1f:      	movl	%ebx, %edx
    1f21:      	xorl	%eax, %eax
    1f23:      	callq	*%rcx
    1f25:      	jmp	0x1d78 <perf_unwind_native+0x1d78>
    1f2a:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1f34:      	movq	%rax, 0x86(%rsp)
    1f3c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1f46:      	movq	%rax, 0x80(%rsp)
    1f4e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1f58:      	movq	%rax, 0x78(%rsp)
    1f5d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1f67:      	movq	%rax, 0x70(%rsp)
    1f6c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1f76:      	movq	%rax, 0x68(%rsp)
    1f7b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1f85:      	movq	%rax, 0x60(%rsp)
    1f8a:      	leaq	0x60(%rsp), %rdi
    1f8f:      	movl	$0x2e, %eax
    1f94:      	movl	$0x6, %ecx
    1f99:      	movl	(%rsp), %edx
    1f9c:      	movl	$0x2e, %esi
    1fa1:      	xorl	%eax, %eax
    1fa3:      	callq	*%rcx
    1fa5:      	jmp	0x1d16 <perf_unwind_native+0x1d16>
    1faa:      	movabsq	$0xa6c6c75662073, %rax  # imm = 0xA6C6C75662073
    1fb4:      	movq	%rax, 0x7d(%rsp)
    1fb9:      	movabsq	$0x66207369206b6361, %rax # imm = 0x66207369206B6361
    1fc3:      	movq	%rax, 0x78(%rsp)
    1fc8:      	movabsq	$0x7473203a656d6172, %rax # imm = 0x7473203A656D6172
    1fd2:      	movq	%rax, 0x70(%rsp)
    1fd7:      	movabsq	$0x662068737570206f, %rax # imm = 0x662068737570206F
    1fe1:      	movq	%rax, 0x68(%rsp)
    1fe6:      	movabsq	$0x7420656c62616e75, %rax # imm = 0x7420656C62616E75
    1ff0:      	movq	%rax, 0x60(%rsp)
    1ff5:      	leaq	0x60(%rsp), %rdi
    1ffa:      	movl	$0x25, %eax
    1fff:      	movl	$0x6, %ecx
    2004:      	movl	$0x25, %esi
    2009:      	xorl	%eax, %eax
    200b:      	callq	*%rcx
    200d:      	jmp	0x1a25 <perf_unwind_native+0x1a25>
    2012:      	movabsq	$0xa2930203d3d2043, %rax # imm = 0xA2930203D3D2043
    201c:      	movq	%rax, 0x88(%rsp)
    2024:      	movabsq	$0x5028206572756c69, %rax # imm = 0x5028206572756C69
    202e:      	movq	%rax, 0x80(%rsp)
    2036:      	movabsq	$0x616620646e69776e, %rax # imm = 0x616620646E69776E
    2040:      	movq	%rax, 0x78(%rsp)
    2045:      	movabsq	$0x75206f7420657564, %rax # imm = 0x75206F7420657564
    204f:      	movq	%rax, 0x70(%rsp)
    2054:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    205e:      	movq	%rax, 0x68(%rsp)
    2063:      	movabsq	$0x676e6970706f7453, %rax # imm = 0x676E6970706F7453
    206d:      	movq	%rax, 0x60(%rsp)
    2072:      	movb	$0x0, 0x90(%rsp)
    207a:      	leaq	0x60(%rsp), %rdi
    207f:      	movl	$0x31, %eax
    2084:      	movl	$0x6, %ecx
    2089:      	movl	$0x31, %esi
    208e:      	xorl	%eax, %eax
    2090:      	callq	*%rcx
    2092:      	jmp	0x1c11 <perf_unwind_native+0x1c11>
    2097:      	movabsq	$0x7373657264646120, %rax # imm = 0x7373657264646120
    20a1:      	movq	%rax, 0x78(%rsp)
    20a6:      	movabsq	$0x6c656e72656b2061, %rax # imm = 0x6C656E72656B2061
    20b0:      	movq	%rax, 0x70(%rsp)
    20b5:      	movabsq	$0x20736920786c2520, %rax # imm = 0x20736920786C2520
    20bf:      	movq	%rax, 0x68(%rsp)
    20c4:      	movabsq	$0x65756c6176204350, %rax # imm = 0x65756C6176204350
    20ce:      	movq	%rax, 0x60(%rsp)
    20d3:      	movw	$0xa, 0x80(%rsp)
    20dd:      	leaq	0x60(%rsp), %rdi
    20e2:      	movl	$0x22, %eax
    20e7:      	movl	$0x6, %ecx
    20ec:      	movl	$0x22, %esi
    20f1:      	movq	%r15, %rdx
    20f4:      	xorl	%eax, %eax
    20f6:      	callq	*%rcx
    20f8:      	jmp	0x1c31 <perf_unwind_native+0x1c31>
    20fd:      	movabsq	$0xa676e69726f6e, %rax  # imm = 0xA676E69726F6E
    2107:      	movq	%rax, 0x76(%rsp)
    210c:      	movabsq	$0x6f6e6769202c786c, %rax # imm = 0x6F6E6769202C786C
    2116:      	movq	%rax, 0x70(%rsp)
    211b:      	movabsq	$0x252065756c617620, %rax # imm = 0x252065756C617620
    2125:      	movq	%rax, 0x68(%rsp)
    212a:      	movabsq	$0x6370206c6c616d73, %rax # imm = 0x6370206C6C616D73
    2134:      	movq	%rax, 0x60(%rsp)
    2139:      	leaq	0x60(%rsp), %rdi
    213e:      	movl	$0x1e, %eax
    2143:      	movl	$0x6, %ecx
    2148:      	movl	$0x1e, %esi
    214d:      	movq	%r15, %rdx
    2150:      	xorl	%eax, %eax
    2152:      	callq	*%rcx
    2154:      	jmp	0x1c4e <perf_unwind_native+0x1c4e>
    2159:      	movabsq	$0xa786c2578302043, %rax # imm = 0xA786C2578302043
    2163:      	movq	%rax, 0x90(%rsp)
    216b:      	movabsq	$0x5020726f6620676e, %rax # imm = 0x5020726F6620676E
    2175:      	movq	%rax, 0x88(%rsp)
    217d:      	movabsq	$0x697070616d207972, %rax # imm = 0x697070616D207972
    2187:      	movq	%rax, 0x80(%rsp)
    218f:      	movabsq	$0x6f6d656d206c6176, %rax # imm = 0x6F6D656D206C6176
    2199:      	movq	%rax, 0x78(%rsp)
    219e:      	movabsq	$0x7265746e69207075, %rax # imm = 0x7265746E69207075
    21a8:      	movq	%rax, 0x70(%rsp)
    21ad:      	movabsq	$0x206b6f6f6c206f74, %rax # imm = 0x206B6F6F6C206F74
    21b7:      	movq	%rax, 0x68(%rsp)
    21bc:      	movabsq	$0x206572756c696146, %rax # imm = 0x206572756C696146
    21c6:      	movq	%rax, 0x60(%rsp)
    21cb:      	movb	$0x0, 0x98(%rsp)
    21d3:      	leaq	0x60(%rsp), %rdi
    21d8:      	movl	$0x39, %eax
    21dd:      	movl	$0x6, %ecx
    21e2:      	movl	$0x39, %esi
    21e7:      	movq	%r15, %rdx
    21ea:      	xorl	%eax, %eax
    21ec:      	callq	*%rcx
    21ee:      	jmp	0x1c6b <perf_unwind_native+0x1c6b>
    21f3:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    21fd:      	movq	%rax, 0x26(%rsp)
    2202:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    220c:      	movq	%rax, 0x20(%rsp)
    2211:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    221b:      	movq	%rax, 0x18(%rsp)
    2220:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    222a:      	movq	%rax, 0x10(%rsp)
    222f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2239:      	movq	%rax, 0x8(%rsp)
    223e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2248:      	movq	%rax, (%rsp)
    224c:      	movq	%rsp, %rdi
    224f:      	movl	$0x2e, %eax
    2254:      	movl	$0x6, %ecx
    2259:      	movl	0x48(%rsp), %edx
    225d:      	movl	$0x2e, %esi
    2262:      	xorl	%eax, %eax
    2264:      	callq	*%rcx
    2266:      	jmp	0x1c8f <perf_unwind_native+0x1c8f>
    226b:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2275:      	movq	%rax, 0x86(%rsp)
    227d:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2287:      	movq	%rax, 0x80(%rsp)
    228f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2299:      	movq	%rax, 0x78(%rsp)
    229e:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    22a8:      	movq	%rax, 0x70(%rsp)
    22ad:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    22b7:      	movq	%rax, 0x68(%rsp)
    22bc:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    22c6:      	movq	%rax, 0x60(%rsp)
    22cb:      	leaq	0x60(%rsp), %rdi
    22d0:      	movl	$0x2e, %eax
    22d5:      	movl	$0x6, %ecx
    22da:      	movl	(%rsp), %edx
    22dd:      	movl	$0x2e, %esi
    22e2:      	xorl	%eax, %eax
    22e4:      	callq	*%rcx
    22e6:      	xorl	%ebx, %ebx
    22e8:      	cmpl	$0x0, (%r13)
    22ed:      	movl	$0x2, %ebp
    22f2:      	je	0x1ca9 <perf_unwind_native+0x1ca9>
    22f8:      	jmp	0x1a5b <perf_unwind_native+0x1a5b>
    22fd:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2307:      	movq	%rax, 0x26(%rsp)
    230c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2316:      	movq	%rax, 0x20(%rsp)
    231b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2325:      	movq	%rax, 0x18(%rsp)
    232a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2334:      	movq	%rax, 0x10(%rsp)
    2339:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2343:      	movq	%rax, 0x8(%rsp)
    2348:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2352:      	movq	%rax, (%rsp)
    2356:      	movq	%rsp, %rdi
    2359:      	movl	$0x2e, %eax
    235e:      	movl	$0x6, %ecx
    2363:      	movl	0x48(%rsp), %edx
    2367:      	movl	$0x2e, %esi
    236c:      	xorl	%eax, %eax
    236e:      	callq	*%rcx
    2370:      	jmp	0x1de0 <perf_unwind_native+0x1de0>

Disassembly of section kprobe/unwind_native:

0000000000000000 <kprobe_unwind_native>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x148, %rsp            # imm = 0x148
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x60(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <kprobe_unwind_native+0x23>
      23:      	leaq	0x60(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x1d78 <kprobe_unwind_native+0x1d78>
      38:      	movq	%rax, %r14
      3b:      	movq	%rbx, 0x140(%rsp)
      43:      	addq	$0xed0, %rax            # imm = 0xED0
      49:      	movq	%rax, 0x108(%rsp)
      51:      	leaq	0xee0(%r14), %rax
      58:      	movq	%rax, 0xf0(%rsp)
      60:      	leaq	0xed8(%r14), %rax
      67:      	movq	%rax, 0xf8(%rsp)
      6f:      	leaq	0xee8(%r14), %rax
      76:      	movq	%rax, 0x138(%rsp)
      7e:      	leaq	0xef0(%r14), %rax
      85:      	movq	%rax, 0x128(%rsp)
      8d:      	leaq	0xef8(%r14), %rax
      94:      	movq	%rax, 0x130(%rsp)
      9c:      	movq	%r14, %rax
      9f:      	addq	$0xf08, %rax            # imm = 0xF08
      a5:      	movq	%rax, 0x120(%rsp)
      ad:      	movl	$0x4, %r15d
      b3:      	movq	(%rip), %r13            # 0xba <kprobe_unwind_native+0xba>
      ba:      	cmpl	$0x0, (%r13)
      bf:      	jne	0xc40 <kprobe_unwind_native+0xc40>
      c5:      	movl	$0x5, (%rsp)
      cc:      	movl	$0x1, %eax
      d1:      	movq	(%rip), %rdi            # 0xd8 <kprobe_unwind_native+0xd8>
      d8:      	movq	%rsp, %rsi
      db:      	callq	*%rax
      dd:      	testq	%rax, %rax
      e0:      	je	0x180 <kprobe_unwind_native+0x180>
      e6:      	incq	(%rax)
      e9:      	cmpl	$0x0, (%r13)
      ee:      	je	0x18b <kprobe_unwind_native+0x18b>
      f4:      	movabsq	$0x63617473206e6f20, %rax # imm = 0x63617473206E6F20
      fe:      	movq	%rax, 0x80(%rsp)
     106:      	movabsq	$0x7525206e6f697469, %rax # imm = 0x7525206E6F697469
     110:      	movq	%rax, 0x78(%rsp)
     115:      	movabsq	$0x736f70206f742078, %rax # imm = 0x736F70206F742078
     11f:      	movq	%rax, 0x70(%rsp)
     124:      	movabsq	$0x6c6c2520786c6c25, %rax # imm = 0x6C6C2520786C6C25
     12e:      	movq	%rax, 0x68(%rsp)
     133:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
     13d:      	movq	%rax, 0x60(%rsp)
     142:      	movl	$0xa6b63, 0x87(%rsp)    # imm = 0xA6B63
     14d:      	movl	$0x6, %r9d
     153:      	leaq	0x60(%rsp), %rdi
     158:      	movl	$0x2b, %eax
     15d:      	movq	0xf10(%r14), %rdx
     164:      	movq	0xf18(%r14), %rcx
     16b:      	movl	0x2c0(%r14), %r8d
     172:      	movl	$0x2b, %esi
     177:      	xorl	%eax, %eax
     179:      	callq	*%r9
     17c:      	jmp	0x18b <kprobe_unwind_native+0x18b>
     17e:      	nop
     180:      	cmpl	$0x0, (%r13)
     185:      	jne	0xe0d <kprobe_unwind_native+0xe0d>
     18b:      	movl	0x2c0(%r14), %eax
     192:      	cmpq	$0x7f, %rax
     196:      	jae	0x1a1a <kprobe_unwind_native+0x1a1a>
     19c:      	movzbl	0xf30(%r14), %ecx
     1a4:      	movq	0xf10(%r14), %rdx
     1ab:      	movq	0xf18(%r14), %rsi
     1b2:      	leal	0x1(%rax), %edi
     1b5:      	movl	%edi, 0x2c0(%r14)
     1bc:      	leaq	(%rax,%rax,2), %rax
     1c0:      	movq	%rdx, 0x2d0(%r14,%rax,8)
     1c8:      	movq	%rsi, 0x2d8(%r14,%rax,8)
     1d0:      	movb	$0x3, 0x2e0(%r14,%rax,8)
     1d9:      	movb	%cl, 0x2e1(%r14,%rax,8)
     1e1:      	movl	$0x0, 0x2e2(%r14,%rax,8)
     1ed:      	movw	$0x0, 0x2e6(%r14,%rax,8)
     1f8:      	movl	$0x0, 0x58(%rsp)
     200:      	movq	0xf10(%r14), %rax
     207:      	movq	%rax, 0x110(%rsp)
     20f:      	movq	%rax, 0x48(%rsp)
     214:      	movq	0xf18(%r14), %rax
     21b:      	movq	$-0x10000, %rcx         # imm = 0xFFFF0000
     222:      	andq	%rcx, %rax
     225:      	movq	%rax, 0x50(%rsp)
     22a:      	cmpl	$0x0, (%r13)
     22f:      	jne	0xc99 <kprobe_unwind_native+0xc99>
     235:      	movl	$0x1, %eax
     23a:      	movq	(%rip), %rdi            # 0x241 <kprobe_unwind_native+0x241>
     241:      	leaq	0x48(%rsp), %rsi
     246:      	callq	*%rax
     248:      	testq	%rax, %rax
     24b:      	je	0x1ab6 <kprobe_unwind_native+0x1ab6>
     251:      	movq	%rax, %r12
     254:      	movzwl	0x6(%rax), %eax
     258:      	cmpl	$0xf, %eax
     25b:      	jg	0x290 <kprobe_unwind_native+0x290>
     25d:      	cmpl	$0xb, %eax
     260:      	jg	0x2c0 <kprobe_unwind_native+0x2c0>
     262:      	cmpl	$0x9, %eax
     265:      	jg	0x313 <kprobe_unwind_native+0x313>
     26b:      	movq	(%rip), %rdi            # 0x272 <kprobe_unwind_native+0x272>
     272:      	cmpl	$0x8, %eax
     275:      	je	0x3b0 <kprobe_unwind_native+0x3b0>
     27b:      	cmpl	$0x9, %eax
     27e:      	jne	0x1df4 <kprobe_unwind_native+0x1df4>
     284:      	movq	(%rip), %rdi            # 0x28b <kprobe_unwind_native+0x28b>
     28b:      	jmp	0x3b0 <kprobe_unwind_native+0x3b0>
     290:      	cmpl	$0x13, %eax
     293:      	jg	0x2f0 <kprobe_unwind_native+0x2f0>
     295:      	cmpl	$0x11, %eax
     298:      	jg	0x32d <kprobe_unwind_native+0x32d>
     29e:      	cmpl	$0x10, %eax
     2a1:      	je	0x372 <kprobe_unwind_native+0x372>
     2a7:      	cmpl	$0x11, %eax
     2aa:      	jne	0x1df4 <kprobe_unwind_native+0x1df4>
     2b0:      	movq	(%rip), %rdi            # 0x2b7 <kprobe_unwind_native+0x2b7>
     2b7:      	jmp	0x3b0 <kprobe_unwind_native+0x3b0>
     2bc:      	nopl	(%rax)
     2c0:      	cmpl	$0xd, %eax
     2c3:      	jg	0x344 <kprobe_unwind_native+0x344>
     2c5:      	cmpl	$0xc, %eax
     2c8:      	je	0x37b <kprobe_unwind_native+0x37b>
     2ce:      	cmpl	$0xd, %eax
     2d1:      	jne	0x1df4 <kprobe_unwind_native+0x1df4>
     2d7:      	movq	(%rip), %rdi            # 0x2de <kprobe_unwind_native+0x2de>
     2de:      	jmp	0x3b0 <kprobe_unwind_native+0x3b0>
     2e3:      	nopw	%cs:(%rax,%rax)
     2f0:      	cmpl	$0x15, %eax
     2f3:      	jg	0x35b <kprobe_unwind_native+0x35b>
     2f5:      	cmpl	$0x14, %eax
     2f8:      	je	0x384 <kprobe_unwind_native+0x384>
     2fe:      	cmpl	$0x15, %eax
     301:      	jne	0x1df4 <kprobe_unwind_native+0x1df4>
     307:      	movq	(%rip), %rdi            # 0x30e <kprobe_unwind_native+0x30e>
     30e:      	jmp	0x3b0 <kprobe_unwind_native+0x3b0>
     313:      	cmpl	$0xa, %eax
     316:      	je	0x38d <kprobe_unwind_native+0x38d>
     318:      	cmpl	$0xb, %eax
     31b:      	jne	0x1df4 <kprobe_unwind_native+0x1df4>
     321:      	movq	(%rip), %rdi            # 0x328 <kprobe_unwind_native+0x328>
     328:      	jmp	0x3b0 <kprobe_unwind_native+0x3b0>
     32d:      	cmpl	$0x12, %eax
     330:      	je	0x396 <kprobe_unwind_native+0x396>
     332:      	cmpl	$0x13, %eax
     335:      	jne	0x1df4 <kprobe_unwind_native+0x1df4>
     33b:      	movq	(%rip), %rdi            # 0x342 <kprobe_unwind_native+0x342>
     342:      	jmp	0x3b0 <kprobe_unwind_native+0x3b0>
     344:      	cmpl	$0xe, %eax
     347:      	je	0x39f <kprobe_unwind_native+0x39f>
     349:      	cmpl	$0xf, %eax
     34c:      	jne	0x1df4 <kprobe_unwind_native+0x1df4>
     352:      	movq	(%rip), %rdi            # 0x359 <kprobe_unwind_native+0x359>
     359:      	jmp	0x3b0 <kprobe_unwind_native+0x3b0>
     35b:      	cmpl	$0x16, %eax
     35e:      	je	0x3a8 <kprobe_unwind_native+0x3a8>
     360:      	cmpl	$0x17, %eax
     363:      	jne	0x1df4 <kprobe_unwind_native+0x1df4>
     369:      	movq	(%rip), %rdi            # 0x370 <kprobe_unwind_native+0x370>
     370:      	jmp	0x3b0 <kprobe_unwind_native+0x3b0>
     372:      	movq	(%rip), %rdi            # 0x379 <kprobe_unwind_native+0x379>
     379:      	jmp	0x3b0 <kprobe_unwind_native+0x3b0>
     37b:      	movq	(%rip), %rdi            # 0x382 <kprobe_unwind_native+0x382>
     382:      	jmp	0x3b0 <kprobe_unwind_native+0x3b0>
     384:      	movq	(%rip), %rdi            # 0x38b <kprobe_unwind_native+0x38b>
     38b:      	jmp	0x3b0 <kprobe_unwind_native+0x3b0>
     38d:      	movq	(%rip), %rdi            # 0x394 <kprobe_unwind_native+0x394>
     394:      	jmp	0x3b0 <kprobe_unwind_native+0x3b0>
     396:      	movq	(%rip), %rdi            # 0x39d <kprobe_unwind_native+0x39d>
     39d:      	jmp	0x3b0 <kprobe_unwind_native+0x3b0>
     39f:      	movq	(%rip), %rdi            # 0x3a6 <kprobe_unwind_native+0x3a6>
     3a6:      	jmp	0x3b0 <kprobe_unwind_native+0x3b0>
     3a8:      	movq	(%rip), %rdi            # 0x3af <kprobe_unwind_native+0x3af>
     3af:      	nop
     3b0:      	movl	$0x1, %eax
     3b5:      	leaq	0x110(%rsp), %rsi
     3bd:      	callq	*%rax
     3bf:      	testq	%rax, %rax
     3c2:      	je	0x1b61 <kprobe_unwind_native+0x1b61>
     3c8:      	movq	%rax, %rbx
     3cb:      	movl	%r15d, 0x11c(%rsp)
     3d3:      	movl	(%r12), %r15d
     3d7:      	movl	%r15d, 0x5c(%rsp)
     3dc:      	movq	0xf18(%r14), %rax
     3e3:      	movq	%rax, 0x40(%rsp)
     3e8:      	movzwl	0x4(%r12), %ebp
     3ee:      	testl	%ebp, %ebp
     3f0:      	je	0x822 <kprobe_unwind_native+0x822>
     3f6:      	addl	%r15d, %ebp
     3f9:      	cmpl	$0x0, (%r13)
     3fe:      	jne	0xd8c <kprobe_unwind_native+0xd8c>
     404:      	leal	(%r15,%rbp), %eax
     408:      	shrl	%eax
     40a:      	movl	%eax, (%rsp)
     40d:      	movl	$0x1, %eax
     412:      	movq	%rsp, %rsi
     415:      	movq	%rbx, %rdi
     418:      	callq	*%rax
     41a:      	testq	%rax, %rax
     41d:      	je	0x1991 <kprobe_unwind_native+0x1991>
     423:      	movl	(%rsp), %ecx
     426:      	movq	0x40(%rsp), %rdx
     42b:      	cmpw	%dx, (%rax)
     42e:      	ja	0x440 <kprobe_unwind_native+0x440>
     430:      	incl	%ecx
     432:      	movl	%ecx, %r15d
     435:      	cmpl	%ebp, %r15d
     438:      	jb	0x44b <kprobe_unwind_native+0x44b>
     43a:      	jmp	0x810 <kprobe_unwind_native+0x810>
     43f:      	nop
     440:      	movl	%ecx, %ebp
     442:      	cmpl	%ebp, %r15d
     445:      	jae	0x810 <kprobe_unwind_native+0x810>
     44b:      	leal	(%r15,%rbp), %eax
     44f:      	shrl	%eax
     451:      	movl	%eax, (%rsp)
     454:      	movl	$0x1, %eax
     459:      	movq	%rsp, %rsi
     45c:      	movq	%rbx, %rdi
     45f:      	callq	*%rax
     461:      	testq	%rax, %rax
     464:      	je	0x1991 <kprobe_unwind_native+0x1991>
     46a:      	movl	(%rsp), %ecx
     46d:      	movq	0x40(%rsp), %rdx
     472:      	cmpw	%dx, (%rax)
     475:      	ja	0x487 <kprobe_unwind_native+0x487>
     477:      	incl	%ecx
     479:      	movl	%ecx, %r15d
     47c:      	cmpl	%ebp, %r15d
     47f:      	jae	0x810 <kprobe_unwind_native+0x810>
     485:      	jmp	0x492 <kprobe_unwind_native+0x492>
     487:      	movl	%ecx, %ebp
     489:      	cmpl	%ebp, %r15d
     48c:      	jae	0x810 <kprobe_unwind_native+0x810>
     492:      	leal	(%r15,%rbp), %eax
     496:      	shrl	%eax
     498:      	movl	%eax, (%rsp)
     49b:      	movl	$0x1, %eax
     4a0:      	movq	%rsp, %rsi
     4a3:      	movq	%rbx, %rdi
     4a6:      	callq	*%rax
     4a8:      	testq	%rax, %rax
     4ab:      	je	0x1991 <kprobe_unwind_native+0x1991>
     4b1:      	movl	(%rsp), %ecx
     4b4:      	movq	0x40(%rsp), %rdx
     4b9:      	cmpw	%dx, (%rax)
     4bc:      	ja	0x4ce <kprobe_unwind_native+0x4ce>
     4be:      	incl	%ecx
     4c0:      	movl	%ecx, %r15d
     4c3:      	cmpl	%ebp, %r15d
     4c6:      	jae	0x810 <kprobe_unwind_native+0x810>
     4cc:      	jmp	0x4d9 <kprobe_unwind_native+0x4d9>
     4ce:      	movl	%ecx, %ebp
     4d0:      	cmpl	%ebp, %r15d
     4d3:      	jae	0x810 <kprobe_unwind_native+0x810>
     4d9:      	leal	(%r15,%rbp), %eax
     4dd:      	shrl	%eax
     4df:      	movl	%eax, (%rsp)
     4e2:      	movl	$0x1, %eax
     4e7:      	movq	%rsp, %rsi
     4ea:      	movq	%rbx, %rdi
     4ed:      	callq	*%rax
     4ef:      	testq	%rax, %rax
     4f2:      	je	0x1991 <kprobe_unwind_native+0x1991>
     4f8:      	movl	(%rsp), %ecx
     4fb:      	leal	0x1(%rcx), %r13d
     4ff:      	movq	0x40(%rsp), %rdx
     504:      	cmpw	%dx, (%rax)
     507:      	cmoval	%r15d, %r13d
     50b:      	cmoval	%ecx, %ebp
     50e:      	cmpl	%ebp, %r13d
     511:      	jae	0x810 <kprobe_unwind_native+0x810>
     517:      	leal	(%rbp,%r13), %eax
     51c:      	shrl	%eax
     51e:      	movl	%eax, (%rsp)
     521:      	movl	$0x1, %eax
     526:      	movq	%rsp, %rsi
     529:      	movq	%rbx, %rdi
     52c:      	callq	*%rax
     52e:      	testq	%rax, %rax
     531:      	je	0x1991 <kprobe_unwind_native+0x1991>
     537:      	movl	(%rsp), %ecx
     53a:      	leal	0x1(%rcx), %r15d
     53e:      	movq	0x40(%rsp), %rdx
     543:      	cmpw	%dx, (%rax)
     546:      	cmoval	%r13d, %r15d
     54a:      	cmoval	%ecx, %ebp
     54d:      	cmpl	%ebp, %r15d
     550:      	jae	0x810 <kprobe_unwind_native+0x810>
     556:      	leal	(%r15,%rbp), %eax
     55a:      	shrl	%eax
     55c:      	movl	%eax, (%rsp)
     55f:      	movl	$0x1, %eax
     564:      	movq	%rsp, %rsi
     567:      	movq	%rbx, %rdi
     56a:      	callq	*%rax
     56c:      	testq	%rax, %rax
     56f:      	je	0x1991 <kprobe_unwind_native+0x1991>
     575:      	movl	(%rsp), %ecx
     578:      	leal	0x1(%rcx), %r13d
     57c:      	movq	0x40(%rsp), %rdx
     581:      	cmpw	%dx, (%rax)
     584:      	cmoval	%r15d, %r13d
     588:      	cmoval	%ecx, %ebp
     58b:      	cmpl	%ebp, %r13d
     58e:      	jae	0x810 <kprobe_unwind_native+0x810>
     594:      	leal	(%rbp,%r13), %eax
     599:      	shrl	%eax
     59b:      	movl	%eax, (%rsp)
     59e:      	movl	$0x1, %eax
     5a3:      	movq	%rsp, %rsi
     5a6:      	movq	%rbx, %rdi
     5a9:      	callq	*%rax
     5ab:      	testq	%rax, %rax
     5ae:      	je	0x1991 <kprobe_unwind_native+0x1991>
     5b4:      	movl	(%rsp), %ecx
     5b7:      	leal	0x1(%rcx), %r15d
     5bb:      	movq	0x40(%rsp), %rdx
     5c0:      	cmpw	%dx, (%rax)
     5c3:      	cmoval	%r13d, %r15d
     5c7:      	cmoval	%ecx, %ebp
     5ca:      	cmpl	%ebp, %r15d
     5cd:      	jae	0x810 <kprobe_unwind_native+0x810>
     5d3:      	leal	(%r15,%rbp), %eax
     5d7:      	shrl	%eax
     5d9:      	movl	%eax, (%rsp)
     5dc:      	movl	$0x1, %eax
     5e1:      	movq	%rsp, %rsi
     5e4:      	movq	%rbx, %rdi
     5e7:      	callq	*%rax
     5e9:      	testq	%rax, %rax
     5ec:      	je	0x1991 <kprobe_unwind_native+0x1991>
     5f2:      	movl	(%rsp), %ecx
     5f5:      	leal	0x1(%rcx), %r13d
     5f9:      	movq	0x40(%rsp), %rdx
     5fe:      	cmpw	%dx, (%rax)
     601:      	cmoval	%r15d, %r13d
     605:      	cmoval	%ecx, %ebp
     608:      	cmpl	%ebp, %r13d
     60b:      	jae	0x810 <kprobe_unwind_native+0x810>
     611:      	leal	(%rbp,%r13), %eax
     616:      	shrl	%eax
     618:      	movl	%eax, (%rsp)
     61b:      	movl	$0x1, %eax
     620:      	movq	%rsp, %rsi
     623:      	movq	%rbx, %rdi
     626:      	callq	*%rax
     628:      	testq	%rax, %rax
     62b:      	je	0x1991 <kprobe_unwind_native+0x1991>
     631:      	movl	(%rsp), %ecx
     634:      	leal	0x1(%rcx), %r15d
     638:      	movq	0x40(%rsp), %rdx
     63d:      	cmpw	%dx, (%rax)
     640:      	cmoval	%r13d, %r15d
     644:      	cmoval	%ecx, %ebp
     647:      	cmpl	%ebp, %r15d
     64a:      	jae	0x810 <kprobe_unwind_native+0x810>
     650:      	leal	(%r15,%rbp), %eax
     654:      	shrl	%eax
     656:      	movl	%eax, (%rsp)
     659:      	movl	$0x1, %eax
     65e:      	movq	%rsp, %rsi
     661:      	movq	%rbx, %rdi
     664:      	callq	*%rax
     666:      	testq	%rax, %rax
     669:      	je	0x1991 <kprobe_unwind_native+0x1991>
     66f:      	movl	(%rsp), %ecx
     672:      	leal	0x1(%rcx), %r13d
     676:      	movq	0x40(%rsp), %rdx
     67b:      	cmpw	%dx, (%rax)
     67e:      	cmoval	%r15d, %r13d
     682:      	cmoval	%ecx, %ebp
     685:      	cmpl	%ebp, %r13d
     688:      	jae	0x810 <kprobe_unwind_native+0x810>
     68e:      	leal	(%rbp,%r13), %eax
     693:      	shrl	%eax
     695:      	movl	%eax, (%rsp)
     698:      	movl	$0x1, %eax
     69d:      	movq	%rsp, %rsi
     6a0:      	movq	%rbx, %rdi
     6a3:      	callq	*%rax
     6a5:      	testq	%rax, %rax
     6a8:      	je	0x1991 <kprobe_unwind_native+0x1991>
     6ae:      	movl	(%rsp), %ecx
     6b1:      	leal	0x1(%rcx), %r15d
     6b5:      	movq	0x40(%rsp), %rdx
     6ba:      	cmpw	%dx, (%rax)
     6bd:      	cmoval	%r13d, %r15d
     6c1:      	cmoval	%ecx, %ebp
     6c4:      	cmpl	%ebp, %r15d
     6c7:      	jae	0x810 <kprobe_unwind_native+0x810>
     6cd:      	leal	(%r15,%rbp), %eax
     6d1:      	shrl	%eax
     6d3:      	movl	%eax, (%rsp)
     6d6:      	movl	$0x1, %eax
     6db:      	movq	%rsp, %rsi
     6de:      	movq	%rbx, %rdi
     6e1:      	callq	*%rax
     6e3:      	testq	%rax, %rax
     6e6:      	je	0x1991 <kprobe_unwind_native+0x1991>
     6ec:      	movl	(%rsp), %ecx
     6ef:      	leal	0x1(%rcx), %r13d
     6f3:      	movq	0x40(%rsp), %rdx
     6f8:      	cmpw	%dx, (%rax)
     6fb:      	cmoval	%r15d, %r13d
     6ff:      	cmoval	%ecx, %ebp
     702:      	cmpl	%ebp, %r13d
     705:      	jae	0x810 <kprobe_unwind_native+0x810>
     70b:      	leal	(%rbp,%r13), %eax
     710:      	shrl	%eax
     712:      	movl	%eax, (%rsp)
     715:      	movl	$0x1, %eax
     71a:      	movq	%rsp, %rsi
     71d:      	movq	%rbx, %rdi
     720:      	callq	*%rax
     722:      	testq	%rax, %rax
     725:      	je	0x1991 <kprobe_unwind_native+0x1991>
     72b:      	movl	(%rsp), %ecx
     72e:      	leal	0x1(%rcx), %r15d
     732:      	movq	0x40(%rsp), %rdx
     737:      	cmpw	%dx, (%rax)
     73a:      	cmoval	%r13d, %r15d
     73e:      	cmoval	%ecx, %ebp
     741:      	cmpl	%ebp, %r15d
     744:      	jae	0x810 <kprobe_unwind_native+0x810>
     74a:      	leal	(%r15,%rbp), %eax
     74e:      	shrl	%eax
     750:      	movl	%eax, (%rsp)
     753:      	movl	$0x1, %eax
     758:      	movq	%rsp, %rsi
     75b:      	movq	%rbx, %rdi
     75e:      	callq	*%rax
     760:      	testq	%rax, %rax
     763:      	je	0x1991 <kprobe_unwind_native+0x1991>
     769:      	movl	(%rsp), %ecx
     76c:      	leal	0x1(%rcx), %r13d
     770:      	movq	0x40(%rsp), %rdx
     775:      	cmpw	%dx, (%rax)
     778:      	cmoval	%r15d, %r13d
     77c:      	cmoval	%ecx, %ebp
     77f:      	cmpl	%ebp, %r13d
     782:      	jae	0x810 <kprobe_unwind_native+0x810>
     788:      	leal	(%rbp,%r13), %eax
     78d:      	shrl	%eax
     78f:      	movl	%eax, (%rsp)
     792:      	movl	$0x1, %eax
     797:      	movq	%rsp, %rsi
     79a:      	movq	%rbx, %rdi
     79d:      	callq	*%rax
     79f:      	testq	%rax, %rax
     7a2:      	je	0x1991 <kprobe_unwind_native+0x1991>
     7a8:      	movl	(%rsp), %ecx
     7ab:      	leal	0x1(%rcx), %r15d
     7af:      	movq	0x40(%rsp), %rdx
     7b4:      	cmpw	%dx, (%rax)
     7b7:      	cmoval	%r13d, %r15d
     7bb:      	cmoval	%ecx, %ebp
     7be:      	cmpl	%ebp, %r15d
     7c1:      	jae	0x810 <kprobe_unwind_native+0x810>
     7c3:      	leal	(%r15,%rbp), %eax
     7c7:      	shrl	%eax
     7c9:      	movl	%eax, (%rsp)
     7cc:      	movl	$0x1, %eax
     7d1:      	movq	%rsp, %rsi
     7d4:      	movq	%rbx, %rdi
     7d7:      	callq	*%rax
     7d9:      	testq	%rax, %rax
     7dc:      	je	0x1991 <kprobe_unwind_native+0x1991>
     7e2:      	movl	(%rsp), %ecx
     7e5:      	leal	0x1(%rcx), %edx
     7e8:      	movq	0x40(%rsp), %rsi
     7ed:      	cmpw	%si, (%rax)
     7f0:      	cmoval	%r15d, %edx
     7f4:      	cmoval	%ecx, %ebp
     7f7:      	cmpl	%ebp, %edx
     7f9:      	movq	(%rip), %r13            # 0x800 <kprobe_unwind_native+0x800>
     800:      	jae	0x817 <kprobe_unwind_native+0x817>
     802:      	jmp	0x1998 <kprobe_unwind_native+0x1998>
     807:      	nopw	(%rax,%rax)
     810:      	movq	(%rip), %r13            # 0x817 <kprobe_unwind_native+0x817>
     817:      	movl	%ebp, %r15d
     81a:      	testl	%ebp, %ebp
     81c:      	je	0x1998 <kprobe_unwind_native+0x1998>
     822:      	decl	%r15d
     825:      	movl	%r15d, 0x5c(%rsp)
     82a:      	movl	$0x1, %eax
     82f:      	leaq	0x5c(%rsp), %rsi
     834:      	movq	%rbx, %rdi
     837:      	callq	*%rax
     839:      	testq	%rax, %rax
     83c:      	je	0x1bfa <kprobe_unwind_native+0x1bfa>
     842:      	cmpl	$0x0, (%r13)
     847:      	jne	0xd04 <kprobe_unwind_native+0xd04>
     84d:      	movzwl	0x40(%rsp), %ecx
     852:      	movzwl	(%rax), %edx
     855:      	subl	%edx, %ecx
     857:      	movl	0x5c(%rsp), %edx
     85b:      	cmpl	(%r12), %edx
     85f:      	leal	0x10000(%rcx), %r12d
     866:      	cmovael	%ecx, %r12d
     86a:      	movzwl	0x2(%rax), %eax
     86e:      	movl	%eax, 0x58(%rsp)
     872:      	cmpl	$0x8001, %eax           # imm = 0x8001
     877:      	je	0x930 <kprobe_unwind_native+0x930>
     87d:      	cmpl	$0x8000, %eax           # imm = 0x8000
     882:      	je	0x1c96 <kprobe_unwind_native+0x1c96>
     888:      	testw	%ax, %ax
     88b:      	js	0xa0f <kprobe_unwind_native+0xa0f>
     891:      	movl	$0x1, %eax
     896:      	movq	(%rip), %rdi            # 0x89d <kprobe_unwind_native+0x89d>
     89d:      	leaq	0x58(%rsp), %rsi
     8a2:      	callq	*%rax
     8a4:      	testq	%rax, %rax
     8a7:      	je	0x1d8f <kprobe_unwind_native+0x1d8f>
     8ad:      	movq	%rax, %rbx
     8b0:      	movl	0x4(%rax), %r15d
     8b4:      	movzbl	0x2(%rax), %eax
     8b8:      	testb	%al, %al
     8ba:      	je	0x8f0 <kprobe_unwind_native+0x8f0>
     8bc:      	cmpl	$0x0, (%r13)
     8c1:      	jne	0xe98 <kprobe_unwind_native+0xe98>
     8c7:      	movl	%eax, %ecx
     8c9:      	andb	$0x7f, %cl
     8cc:      	movzbl	%cl, %ecx
     8cf:      	cmpl	%ecx, %r12d
     8d2:      	jl	0x8f0 <kprobe_unwind_native+0x8f0>
     8d4:      	xorl	%ecx, %ecx
     8d6:      	testb	%al, %al
     8d8:      	setns	%cl
     8db:      	shll	$0x4, %ecx
     8de:      	addl	%ecx, %r15d
     8e1:      	addl	$-0x8, %r15d
     8e5:      	cmpl	$0x0, (%r13)
     8ea:      	jne	0xf88 <kprobe_unwind_native+0xf88>
     8f0:      	movzbl	(%rbx), %eax
     8f3:      	movl	%r15d, %ecx
     8f6:      	andl	$-0x8, %ecx
     8f9:      	testb	%al, %al
     8fb:      	cmovnsl	%r15d, %ecx
     8ff:      	movl	%eax, %edx
     901:      	andl	$0x7f, %edx
     904:      	cmpl	$0x2, %edx
     907:      	jg	0x96f <kprobe_unwind_native+0x96f>
     909:      	cmpl	$0x1, %edx
     90c:      	je	0xbea <kprobe_unwind_native+0xbea>
     912:      	movq	0xf8(%rsp), %rsi
     91a:      	movl	$0x0, %r12d
     920:      	cmpl	$0x2, %edx
     923:      	je	0x9e1 <kprobe_unwind_native+0x9e1>
     929:      	jmp	0x1070 <kprobe_unwind_native+0x1070>
     92e:      	nop
     930:      	movl	$0x7, 0x104(%rsp)
     93b:      	movl	$0x1, %eax
     940:      	movq	(%rip), %rdi            # 0x947 <kprobe_unwind_native+0x947>
     947:      	leaq	0x104(%rsp), %rsi
     94f:      	callq	*%rax
     951:      	testq	%rax, %rax
     954:      	je	0x9f7 <kprobe_unwind_native+0x9f7>
     95a:      	incq	(%rax)
     95d:      	movl	0x58(%rsp), %eax
     961:      	testw	%ax, %ax
     964:      	jns	0x891 <kprobe_unwind_native+0x891>
     96a:      	jmp	0xa0f <kprobe_unwind_native+0xa0f>
     96f:      	movq	0xf0(%rsp), %rsi
     977:      	cmpl	$0x3, %edx
     97a:      	je	0x9e1 <kprobe_unwind_native+0x9e1>
     97c:      	movl	$0x0, %r12d
     982:      	cmpl	$0x5, %edx
     985:      	jne	0x1070 <kprobe_unwind_native+0x1070>
     98b:      	movl	%r15d, %eax
     98e:      	sarl	%eax
     990:      	andl	$-0x8, %eax
     993:      	cltq
     995:      	movq	%rax, 0x48(%rsp)
     99a:      	cmpl	$0x0, (%r13)
     99f:      	jne	0xfe7 <kprobe_unwind_native+0xfe7>
     9a5:      	andl	$0xf, %r15d
     9a9:      	cmpl	$0xa, %r15d
     9ad:      	jg	0x1037 <kprobe_unwind_native+0x1037>
     9b3:      	movq	0x138(%rsp), %rax
     9bb:      	testl	%r15d, %r15d
     9be:      	je	0x1059 <kprobe_unwind_native+0x1059>
     9c4:      	movq	0x128(%rsp), %rax
     9cc:      	movl	$0x0, %r12d
     9d2:      	cmpl	$0x9, %r15d
     9d6:      	je	0x1059 <kprobe_unwind_native+0x1059>
     9dc:      	jmp	0x1070 <kprobe_unwind_native+0x1070>
     9e1:      	movq	(%rsi), %rdx
     9e4:      	movslq	%ecx, %r12
     9e7:      	addq	%rdx, %r12
     9ea:      	testb	%al, %al
     9ec:      	jns	0x1070 <kprobe_unwind_native+0x1070>
     9f2:      	jmp	0xbfa <kprobe_unwind_native+0xbfa>
     9f7:      	cmpl	$0x0, (%r13)
     9fc:      	jne	0xf00 <kprobe_unwind_native+0xf00>
     a02:      	movl	0x58(%rsp), %eax
     a06:      	testw	%ax, %ax
     a09:      	jns	0x891 <kprobe_unwind_native+0x891>
     a0f:      	andl	$0xffff7fff, %eax       # imm = 0xFFFF7FFF
     a14:      	cmpl	$0x2, %eax
     a17:      	jle	0xa84 <kprobe_unwind_native+0xa84>
     a19:      	cmpl	$0x3, %eax
     a1c:      	je	0xaf8 <kprobe_unwind_native+0xaf8>
     a22:      	cmpl	$0x4, %eax
     a25:      	jne	0x1dea <kprobe_unwind_native+0x1dea>
     a2b:      	movq	0xf0(%rsp), %rdx
     a33:      	movq	(%rdx), %rax
     a36:      	movl	$0x70, %ecx
     a3b:      	movq	%rsp, %rdi
     a3e:      	movl	$0x10, %esi
     a43:      	movq	(%rdx), %rdx
     a46:      	movl	$0x10, %esi
     a4b:      	callq	*%rcx
     a4d:      	testq	%rax, %rax
     a50:      	jne	0x1965 <kprobe_unwind_native+0x1965>
     a56:      	movq	0xee0(%r14), %rax
     a5d:      	addq	$0x10, %rax
     a61:      	movq	%rax, 0xed8(%r14)
     a68:      	movq	(%rsp), %rax
     a6c:      	movq	%rax, 0xee0(%r14)
     a73:      	movq	0x8(%rsp), %rax
     a78:      	movq	%rax, 0xed0(%r14)
     a7f:      	jmp	0x1287 <kprobe_unwind_native+0x1287>
     a84:      	jne	0x1dc9 <kprobe_unwind_native+0x1dc9>
     a8a:      	movq	0xf8(%rsp), %rax
     a92:      	movq	(%rax), %rax
     a95:      	movq	0x108(%rsp), %rcx
     a9d:      	movl	(%rcx), %ecx
     a9f:      	andl	$0xf, %ecx
     aa2:      	xorl	%edx, %edx
     aa4:      	cmpl	$0xb, %ecx
     aa7:      	setae	%dl
     aaa:      	leaq	(%rax,%rdx,8), %r12
     aae:      	addq	$0x8, %r12
     ab2:      	cmpl	$0x0, (%r13)
     ab7:      	je	0x1250 <kprobe_unwind_native+0x1250>
     abd:      	movabsq	$0xa786c2578303d, %rax  # imm = 0xA786C2578303D
     ac7:      	movq	%rax, 0x8(%rsp)
     acc:      	movabsq	$0x616663202c544c50, %rax # imm = 0x616663202C544C50
     ad6:      	movq	%rax, (%rsp)
     ada:      	movl	$0x6, %ecx
     adf:      	movq	%rsp, %rdi
     ae2:      	movl	$0x10, %eax
     ae7:      	movl	$0x10, %esi
     aec:      	movq	%r12, %rdx
     aef:      	xorl	%eax, %eax
     af1:      	callq	*%rcx
     af3:      	jmp	0x1250 <kprobe_unwind_native+0x1250>
     af8:      	movq	0xf8(%rsp), %rdx
     b00:      	movq	(%rdx), %rax
     b03:      	addq	$0x28, %rax
     b07:      	movl	$0x70, %ecx
     b0c:      	leaq	0x60(%rsp), %rdi
     b11:      	movl	$0x90, %esi
     b16:      	movq	(%rdx), %rdx
     b19:      	addq	$0x28, %rdx
     b1d:      	movl	$0x90, %esi
     b22:      	callq	*%rcx
     b24:      	testq	%rax, %rax
     b27:      	jne	0x1965 <kprobe_unwind_native+0x1965>
     b2d:      	movq	0xc8(%rsp), %rax
     b35:      	movq	%rax, 0xee8(%r14)
     b3c:      	movq	0x68(%rsp), %rax
     b41:      	movq	%rax, 0xef0(%r14)
     b48:      	movq	0x78(%rsp), %rax
     b4d:      	movq	%rax, 0xef8(%r14)
     b54:      	movq	0x88(%rsp), %rax
     b5c:      	movq	%rax, 0xf00(%r14)
     b63:      	movq	0x98(%rsp), %rax
     b6b:      	movq	%rax, 0xf08(%r14)
     b72:      	movq	0xb0(%rsp), %rax
     b7a:      	movq	%rax, 0xee0(%r14)
     b81:      	movq	0xd8(%rsp), %rax
     b89:      	movq	%rax, 0xed8(%r14)
     b90:      	movq	0xe0(%rsp), %rax
     b98:      	movq	%rax, 0xed0(%r14)
     b9f:      	movb	$0x0, 0xf30(%r14)
     ba7:      	cmpl	$0x0, (%r13)
     bac:      	je	0x128f <kprobe_unwind_native+0x128f>
     bb2:      	movabsq	$0xa656d61726620, %rax  # imm = 0xA656D61726620
     bbc:      	movq	%rax, 0x6(%rsp)
     bc1:      	movabsq	$0x66206c616e676973, %rax # imm = 0x66206C616E676973
     bcb:      	movq	%rax, (%rsp)
     bcf:      	movl	$0x6, %ecx
     bd4:      	movq	%rsp, %rdi
     bd7:      	movl	$0xe, %eax
     bdc:      	movl	$0xe, %esi
     be1:      	xorl	%eax, %eax
     be3:      	callq	*%rcx
     be5:      	jmp	0x128f <kprobe_unwind_native+0x128f>
     bea:      	xorl	%edx, %edx
     bec:      	movslq	%ecx, %r12
     bef:      	addq	%rdx, %r12
     bf2:      	testb	%al, %al
     bf4:      	jns	0x1070 <kprobe_unwind_native+0x1070>
     bfa:      	movl	$0x70, %eax
     bff:      	leaq	0x48(%rsp), %rdi
     c04:      	movl	$0x8, %ecx
     c09:      	movl	$0x8, %esi
     c0e:      	movq	%r12, %rdx
     c11:      	callq	*%rax
     c13:      	testq	%rax, %rax
     c16:      	je	0xc2b <kprobe_unwind_native+0xc2b>
     c18:      	cmpl	$0x0, (%r13)
     c1d:      	jne	0x1801 <kprobe_unwind_native+0x1801>
     c23:      	xorl	%r12d, %r12d
     c26:      	jmp	0x1070 <kprobe_unwind_native+0x1070>
     c2b:      	shll	$0x3, %r15d
     c2f:      	andl	$0x38, %r15d
     c33:      	addq	0x48(%rsp), %r15
     c38:      	movq	%r15, %r12
     c3b:      	jmp	0x1070 <kprobe_unwind_native+0x1070>
     c40:      	movl	0x2c0(%r14), %edx
     c47:      	movabsq	$0x3d3d206425206576, %rax # imm = 0x3D3D206425206576
     c51:      	movq	%rax, 0x70(%rsp)
     c56:      	movabsq	$0x6974616e5f646e69, %rax # imm = 0x6974616E5F646E69
     c60:      	movq	%rax, 0x68(%rsp)
     c65:      	movabsq	$0x776e75203d3d3d3d, %rax # imm = 0x776E75203D3D3D3D
     c6f:      	movq	%rax, 0x60(%rsp)
     c74:      	movl	$0xa3d3d, 0x78(%rsp)    # imm = 0xA3D3D
     c7c:      	movl	$0x6, %ecx
     c81:      	leaq	0x60(%rsp), %rdi
     c86:      	movl	$0x1c, %eax
     c8b:      	movl	$0x1c, %esi
     c90:      	xorl	%eax, %eax
     c92:      	callq	*%rcx
     c94:      	jmp	0xc5 <kprobe_unwind_native+0xc5>
     c99:      	movabsq	$0xa786c253a786c25, %rax # imm = 0xA786C253A786C25
     ca3:      	movq	%rax, 0x18(%rsp)
     ca8:      	movabsq	$0x20726f662061746c, %rax # imm = 0x20726F662061746C
     cb2:      	movq	%rax, 0x10(%rsp)
     cb7:      	movabsq	$0x6564206b63617473, %rax # imm = 0x6564206B63617473
     cc1:      	movq	%rax, 0x8(%rsp)
     cc6:      	movabsq	$0x207075206b6f6f4c, %rax # imm = 0x207075206B6F6F4C
     cd0:      	movq	%rax, (%rsp)
     cd4:      	movb	$0x0, 0x20(%rsp)
     cd9:      	movl	$0x6, %r8d
     cdf:      	movq	%rsp, %rdi
     ce2:      	movl	$0x21, %eax
     ce7:      	movq	0xf10(%r14), %rdx
     cee:      	movq	0xf18(%r14), %rcx
     cf5:      	movl	$0x21, %esi
     cfa:      	xorl	%eax, %eax
     cfc:      	callq	*%r8
     cff:      	jmp	0x235 <kprobe_unwind_native+0x235>
     d04:      	movabsq	$0xa6425206f666e, %rcx  # imm = 0xA6425206F666E
     d0e:      	movq	%rcx, 0x25(%rsp)
     d13:      	movabsq	$0x6f666e49646e6977, %rcx # imm = 0x6F666E49646E6977
     d1d:      	movq	%rcx, 0x20(%rsp)
     d22:      	movabsq	$0x6e75202c78257830, %rcx # imm = 0x6E75202C78257830
     d2c:      	movq	%rcx, 0x18(%rsp)
     d31:      	movabsq	$0x20776f4c72646461, %rcx # imm = 0x20776F4C72646461
     d3b:      	movq	%rcx, 0x10(%rsp)
     d40:      	movabsq	$0x202c642520786564, %rcx # imm = 0x202C642520786564
     d4a:      	movq	%rcx, 0x8(%rsp)
     d4f:      	movabsq	$0x6e692061746c6564, %rcx # imm = 0x6E692061746C6564
     d59:      	movq	%rcx, (%rsp)
     d5d:      	movl	$0x6, %r9d
     d63:      	movq	%rsp, %rdi
     d66:      	movl	$0x2d, %ecx
     d6b:      	movl	0x5c(%rsp), %edx
     d6f:      	movzwl	(%rax), %ecx
     d72:      	movzwl	0x2(%rax), %r8d
     d77:      	movl	$0x2d, %esi
     d7c:      	movq	%rax, %rbx
     d7f:      	xorl	%eax, %eax
     d81:      	callq	*%r9
     d84:      	movq	%rbx, %rax
     d87:      	jmp	0x84d <kprobe_unwind_native+0x84d>
     d8c:      	movabsq	$0xa296425204449, %rax  # imm = 0xA296425204449
     d96:      	movq	%rax, 0x28(%rsp)
     d9b:      	movabsq	$0x70616d2820756c25, %rax # imm = 0x70616D2820756C25
     da5:      	movq	%rax, 0x20(%rsp)
     daa:      	movabsq	$0x206f7420756c2520, %rax # imm = 0x206F7420756C2520
     db4:      	movq	%rax, 0x18(%rsp)
     db9:      	movabsq	$0x6d6f726620656220, %rax # imm = 0x6D6F726620656220
     dc3:      	movq	%rax, 0x10(%rsp)
     dc8:      	movabsq	$0x646c756f68732073, %rax # imm = 0x646C756F68732073
     dd2:      	movq	%rax, 0x8(%rsp)
     dd7:      	movabsq	$0x6c61767265746e49, %rax # imm = 0x6C61767265746E49
     de1:      	movq	%rax, (%rsp)
     de5:      	movl	$0x6, %r9d
     deb:      	movq	%rsp, %rdi
     dee:      	movl	$0x30, %eax
     df3:      	movl	%ebp, %ecx
     df5:      	movzwl	0x6(%r12), %r8d
     dfb:      	movl	$0x30, %esi
     e00:      	movq	%r15, %rdx
     e03:      	xorl	%eax, %eax
     e05:      	callq	*%r9
     e08:      	jmp	0x404 <kprobe_unwind_native+0x404>
     e0d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     e17:      	movq	%rax, 0x86(%rsp)
     e1f:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     e29:      	movq	%rax, 0x80(%rsp)
     e31:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     e3b:      	movq	%rax, 0x78(%rsp)
     e40:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     e4a:      	movq	%rax, 0x70(%rsp)
     e4f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     e59:      	movq	%rax, 0x68(%rsp)
     e5e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     e68:      	movq	%rax, 0x60(%rsp)
     e6d:      	movl	$0x6, %ecx
     e72:      	leaq	0x60(%rsp), %rdi
     e77:      	movl	$0x2e, %eax
     e7c:      	movl	(%rsp), %edx
     e7f:      	movl	$0x2e, %esi
     e84:      	xorl	%eax, %eax
     e86:      	callq	*%rcx
     e88:      	cmpl	$0x0, (%r13)
     e8d:      	je	0x18b <kprobe_unwind_native+0x18b>
     e93:      	jmp	0xf4 <kprobe_unwind_native+0xf4>
     e98:      	movabsq	$0xa78323023252061, %rax # imm = 0xA78323023252061
     ea2:      	movq	%rax, 0x18(%rsp)
     ea7:      	movabsq	$0x746c656420646567, %rax # imm = 0x746C656420646567
     eb1:      	movq	%rax, 0x10(%rsp)
     eb6:      	movabsq	$0x72656d202c642520, %rax # imm = 0x72656D202C642520
     ec0:      	movq	%rax, 0x8(%rsp)
     ec5:      	movabsq	$0x6666694472646441, %rax # imm = 0x6666694472646441
     ecf:      	movq	%rax, (%rsp)
     ed3:      	movb	$0x0, 0x20(%rsp)
     ed8:      	movl	$0x6, %r8d
     ede:      	movq	%rsp, %rdi
     ee1:      	movl	$0x21, %eax
     ee6:      	movzbl	0x2(%rbx), %ecx
     eea:      	movl	$0x21, %esi
     eef:      	movl	%r12d, %edx
     ef2:      	xorl	%eax, %eax
     ef4:      	callq	*%r8
     ef7:      	movzbl	0x2(%rbx), %eax
     efb:      	jmp	0x8c7 <kprobe_unwind_native+0x8c7>
     f00:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     f0a:      	movq	%rax, 0x26(%rsp)
     f0f:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     f19:      	movq	%rax, 0x20(%rsp)
     f1e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     f28:      	movq	%rax, 0x18(%rsp)
     f2d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     f37:      	movq	%rax, 0x10(%rsp)
     f3c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     f46:      	movq	%rax, 0x8(%rsp)
     f4b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     f55:      	movq	%rax, (%rsp)
     f59:      	movl	$0x6, %ecx
     f5e:      	movq	%rsp, %rdi
     f61:      	movl	$0x2e, %eax
     f66:      	movl	0x104(%rsp), %edx
     f6d:      	movl	$0x2e, %esi
     f72:      	xorl	%eax, %eax
     f74:      	callq	*%rcx
     f76:      	movl	0x58(%rsp), %eax
     f7a:      	testw	%ax, %ax
     f7d:      	jns	0x891 <kprobe_unwind_native+0x891>
     f83:      	jmp	0xa0f <kprobe_unwind_native+0xa0f>
     f88:      	movabsq	$0xa64253d61746c65, %rax # imm = 0xA64253D61746C65
     f92:      	movq	%rax, 0x18(%rsp)
     f97:      	movabsq	$0x44616663203a6863, %rax # imm = 0x44616663203A6863
     fa1:      	movq	%rax, 0x10(%rsp)
     fa6:      	movabsq	$0x74616d2061746c65, %rax # imm = 0x74616D2061746C65
     fb0:      	movq	%rax, 0x8(%rsp)
     fb5:      	movabsq	$0x642064656772654d, %rax # imm = 0x642064656772654D
     fbf:      	movq	%rax, (%rsp)
     fc3:      	movb	$0x0, 0x20(%rsp)
     fc8:      	movl	$0x6, %ecx
     fcd:      	movq	%rsp, %rdi
     fd0:      	movl	$0x21, %eax
     fd5:      	movl	0x58(%rsp), %edx
     fd9:      	movl	$0x21, %esi
     fde:      	xorl	%eax, %eax
     fe0:      	callq	*%rcx
     fe2:      	jmp	0x8f0 <kprobe_unwind_native+0x8f0>
     fe7:      	movabsq	$0xa756c252b642572, %rax # imm = 0xA756C252B642572
     ff1:      	movq	%rax, 0x8(%rsp)
     ff6:      	movabsq	$0x203a646e69776e75, %rax # imm = 0x203A646E69776E75
    1000:      	movq	%rax, (%rsp)
    1004:      	movb	$0x0, 0x10(%rsp)
    1009:      	movl	$0x6, %r8d
    100f:      	movq	%rsp, %rdi
    1012:      	movl	$0x11, %eax
    1017:      	andl	$0xf, %r15d
    101b:      	movq	0x48(%rsp), %rcx
    1020:      	movl	$0x11, %esi
    1025:      	movl	%r15d, %edx
    1028:      	xorl	%eax, %eax
    102a:      	callq	*%r8
    102d:      	cmpl	$0xa, %r15d
    1031:      	jle	0x9b3 <kprobe_unwind_native+0x9b3>
    1037:      	movq	0x130(%rsp), %rax
    103f:      	cmpl	$0xb, %r15d
    1043:      	je	0x1059 <kprobe_unwind_native+0x1059>
    1045:      	movl	$0x0, %r12d
    104b:      	cmpl	$0xf, %r15d
    104f:      	jne	0x1070 <kprobe_unwind_native+0x1070>
    1051:      	movq	0x120(%rsp), %rax
    1059:      	movq	0x48(%rsp), %r12
    105e:      	addq	(%rax), %r12
    1061:      	nopw	%cs:(%rax,%rax)
    1070:      	movzbl	0x1(%rbx), %eax
    1074:      	movl	0x8(%rbx), %r13d
    1078:      	movl	%r13d, %ecx
    107b:      	andl	$-0x8, %ecx
    107e:      	testb	%al, %al
    1080:      	cmovnsl	%r13d, %ecx
    1084:      	movl	%eax, %edx
    1086:      	andl	$0x7f, %edx
    1089:      	cmpl	$0x2, %edx
    108c:      	jg	0x10a8 <kprobe_unwind_native+0x10a8>
    108e:      	movq	%r12, %rsi
    1091:      	cmpl	$0x1, %edx
    1094:      	je	0x1113 <kprobe_unwind_native+0x1113>
    1096:      	movq	0xf8(%rsp), %rsi
    109e:      	cmpl	$0x2, %edx
    10a1:      	je	0x1110 <kprobe_unwind_native+0x1110>
    10a3:      	jmp	0x1166 <kprobe_unwind_native+0x1166>
    10a8:      	movq	0xf0(%rsp), %rsi
    10b0:      	cmpl	$0x3, %edx
    10b3:      	je	0x1110 <kprobe_unwind_native+0x1110>
    10b5:      	cmpl	$0x5, %edx
    10b8:      	jne	0x1166 <kprobe_unwind_native+0x1166>
    10be:      	movl	%r13d, %eax
    10c1:      	sarl	%eax
    10c3:      	andl	$-0x8, %eax
    10c6:      	cltq
    10c8:      	movq	%rax, 0x48(%rsp)
    10cd:      	movq	(%rip), %rax            # 0x10d4 <kprobe_unwind_native+0x10d4>
    10d4:      	cmpl	$0x0, (%rax)
    10d7:      	jne	0x11ac <kprobe_unwind_native+0x11ac>
    10dd:      	andl	$0xf, %r13d
    10e1:      	cmpl	$0xa, %r13d
    10e5:      	jg	0x11fc <kprobe_unwind_native+0x11fc>
    10eb:      	movq	0x138(%rsp), %rax
    10f3:      	testl	%r13d, %r13d
    10f6:      	je	0x121c <kprobe_unwind_native+0x121c>
    10fc:      	movq	0x128(%rsp), %rax
    1104:      	cmpl	$0x9, %r13d
    1108:      	je	0x121c <kprobe_unwind_native+0x121c>
    110e:      	jmp	0x1166 <kprobe_unwind_native+0x1166>
    1110:      	movq	(%rsi), %rsi
    1113:      	movslq	%ecx, %r15
    1116:      	addq	%rsi, %r15
    1119:      	testb	%al, %al
    111b:      	js	0x1138 <kprobe_unwind_native+0x1138>
    111d:      	testq	%r15, %r15
    1120:      	movq	(%rip), %r13            # 0x1127 <kprobe_unwind_native+0x1127>
    1127:      	jne	0x1234 <kprobe_unwind_native+0x1234>
    112d:      	cmpb	$0x3, (%rbx)
    1130:      	jne	0x1250 <kprobe_unwind_native+0x1250>
    1136:      	jmp	0x1176 <kprobe_unwind_native+0x1176>
    1138:      	movl	$0x70, %eax
    113d:      	leaq	0x48(%rsp), %rdi
    1142:      	movl	$0x8, %ecx
    1147:      	movl	$0x8, %esi
    114c:      	movq	%r15, %rdx
    114f:      	callq	*%rax
    1151:      	testq	%rax, %rax
    1154:      	je	0x118a <kprobe_unwind_native+0x118a>
    1156:      	movq	(%rip), %rax            # 0x115d <kprobe_unwind_native+0x115d>
    115d:      	cmpl	$0x0, (%rax)
    1160:      	jne	0x1874 <kprobe_unwind_native+0x1874>
    1166:      	movq	(%rip), %r13            # 0x116d <kprobe_unwind_native+0x116d>
    116d:      	cmpb	$0x3, (%rbx)
    1170:      	jne	0x1250 <kprobe_unwind_native+0x1250>
    1176:      	movq	0xf0(%rsp), %rax
    117e:      	movq	$0x0, (%rax)
    1185:      	jmp	0x1250 <kprobe_unwind_native+0x1250>
    118a:      	shll	$0x3, %r13d
    118e:      	andl	$0x38, %r13d
    1192:      	addq	0x48(%rsp), %r13
    1197:      	movq	%r13, %r15
    119a:      	testq	%r15, %r15
    119d:      	movq	(%rip), %r13            # 0x11a4 <kprobe_unwind_native+0x11a4>
    11a4:      	jne	0x1234 <kprobe_unwind_native+0x1234>
    11aa:      	jmp	0x112d <kprobe_unwind_native+0x112d>
    11ac:      	movabsq	$0xa756c252b642572, %rax # imm = 0xA756C252B642572
    11b6:      	movq	%rax, 0x8(%rsp)
    11bb:      	movabsq	$0x203a646e69776e75, %rax # imm = 0x203A646E69776E75
    11c5:      	movq	%rax, (%rsp)
    11c9:      	movb	$0x0, 0x10(%rsp)
    11ce:      	movl	$0x6, %r8d
    11d4:      	movq	%rsp, %rdi
    11d7:      	movl	$0x11, %eax
    11dc:      	andl	$0xf, %r13d
    11e0:      	movq	0x48(%rsp), %rcx
    11e5:      	movl	$0x11, %esi
    11ea:      	movl	%r13d, %edx
    11ed:      	xorl	%eax, %eax
    11ef:      	callq	*%r8
    11f2:      	cmpl	$0xa, %r13d
    11f6:      	jle	0x10eb <kprobe_unwind_native+0x10eb>
    11fc:      	movq	0x130(%rsp), %rax
    1204:      	cmpl	$0xb, %r13d
    1208:      	je	0x121c <kprobe_unwind_native+0x121c>
    120a:      	cmpl	$0xf, %r13d
    120e:      	jne	0x1166 <kprobe_unwind_native+0x1166>
    1214:      	movq	0x120(%rsp), %rax
    121c:      	movq	0x48(%rsp), %r15
    1221:      	addq	(%rax), %r15
    1224:      	testq	%r15, %r15
    1227:      	movq	(%rip), %r13            # 0x122e <kprobe_unwind_native+0x122e>
    122e:      	je	0x112d <kprobe_unwind_native+0x112d>
    1234:      	movl	$0x70, %eax
    1239:      	movq	0xf0(%rsp), %rdi
    1241:      	movl	$0x8, %ecx
    1246:      	movl	$0x8, %esi
    124b:      	movq	%r15, %rdx
    124e:      	callq	*%rax
    1250:      	testq	%r12, %r12
    1253:      	je	0x1965 <kprobe_unwind_native+0x1965>
    1259:      	leaq	-0x8(%r12), %rdx
    125e:      	movl	$0x70, %eax
    1263:      	movq	0x108(%rsp), %rdi
    126b:      	movl	$0x8, %ecx
    1270:      	movl	$0x8, %esi
    1275:      	callq	*%rax
    1277:      	testq	%rax, %rax
    127a:      	jne	0x1965 <kprobe_unwind_native+0x1965>
    1280:      	movq	%r12, 0xed8(%r14)
    1287:      	movb	$0x1, 0xf30(%r14)
    128f:      	movl	$0x6, 0x48(%rsp)
    1297:      	movl	$0x1, %eax
    129c:      	movq	(%rip), %rdi            # 0x12a3 <kprobe_unwind_native+0x12a3>
    12a3:      	leaq	0x48(%rsp), %rsi
    12a8:      	callq	*%rax
    12aa:      	testq	%rax, %rax
    12ad:      	je	0x1340 <kprobe_unwind_native+0x1340>
    12b3:      	incq	(%rax)
    12b6:      	cmpl	$0x0, (%r13)
    12bb:      	je	0x134b <kprobe_unwind_native+0x134b>
    12c1:      	movabsq	$0xa786c6c25203a, %rax  # imm = 0xA786C6C25203A
    12cb:      	movq	%rax, 0x75(%rsp)
    12d0:      	movabsq	$0x25203a706620786c, %rax # imm = 0x25203A706620786C
    12da:      	movq	%rax, 0x70(%rsp)
    12df:      	movabsq	$0x6c25203a70732078, %rax # imm = 0x6C25203A70732078
    12e9:      	movq	%rax, 0x68(%rsp)
    12ee:      	movabsq	$0x6c6c25203a637020, %rax # imm = 0x6C6C25203A637020
    12f8:      	movq	%rax, 0x60(%rsp)
    12fd:      	movl	$0x6, %r9d
    1303:      	leaq	0x60(%rsp), %rdi
    1308:      	movl	$0x1d, %eax
    130d:      	movq	0x108(%rsp), %rax
    1315:      	movq	(%rax), %rdx
    1318:      	movq	0xf8(%rsp), %rax
    1320:      	movq	(%rax), %rcx
    1323:      	movq	0xf0(%rsp), %rax
    132b:      	movq	(%rax), %r8
    132e:      	movl	$0x1d, %esi
    1333:      	xorl	%eax, %eax
    1335:      	callq	*%r9
    1338:      	jmp	0x134b <kprobe_unwind_native+0x134b>
    133a:      	nopw	(%rax,%rax)
    1340:      	cmpl	$0x0, (%r13)
    1345:      	jne	0x16a0 <kprobe_unwind_native+0x16a0>
    134b:      	movq	0x108(%rsp), %rax
    1353:      	movq	(%rax), %r15
    1356:      	movl	(%r13), %eax
    135a:      	testq	%r15, %r15
    135d:      	je	0x1c09 <kprobe_unwind_native+0x1c09>
    1363:      	testl	%eax, %eax
    1365:      	jne	0x14d1 <kprobe_unwind_native+0x14d1>
    136b:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    1375:      	cmpq	%rax, %r15
    1378:      	ja	0x1c26 <kprobe_unwind_native+0x1c26>
    137e:      	cmpq	$0xfff, %r15            # imm = 0xFFF
    1385:      	jbe	0x1c43 <kprobe_unwind_native+0x1c43>
    138b:      	movl	(%r14), %eax
    138e:      	movl	$0x60, (%rsp)
    1395:      	movbel	%eax, 0x4(%rsp)
    139b:      	movbeq	%r15, 0x8(%rsp)
    13a2:      	movl	$0x1, %eax
    13a7:      	movq	%rsp, %rsi
    13aa:      	movq	(%rip), %rdi            # 0x13b1 <kprobe_unwind_native+0x13b1>
    13b1:      	callq	*%rax
    13b3:      	testq	%rax, %rax
    13b6:      	je	0x1c60 <kprobe_unwind_native+0x1c60>
    13bc:      	movq	0x8(%rax), %rbx
    13c0:      	movq	%rbx, %rcx
    13c3:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    13cd:      	andq	%rdx, %rcx
    13d0:      	movq	%rcx, 0xf20(%r14)
    13d7:      	movq	(%rax), %rax
    13da:      	movq	%rax, 0xf10(%r14)
    13e1:      	shrq	$0x38, %rbx
    13e5:      	movq	%r15, %rax
    13e8:      	subq	%rcx, %rax
    13eb:      	movq	%rax, 0xf18(%r14)
    13f2:      	cmpl	$0x0, (%r13)
    13f7:      	jne	0x1577 <kprobe_unwind_native+0x1577>
    13fd:      	cmpl	$0x1, %ebx
    1400:      	jne	0x17e0 <kprobe_unwind_native+0x17e0>
    1406:      	movq	0xf10(%r14), %rax
    140d:      	movq	%rax, (%rsp)
    1411:      	movq	0xf18(%r14), %r15
    1418:      	movl	$0x1, %eax
    141d:      	movq	%rsp, %rsi
    1420:      	movq	(%rip), %rdi            # 0x1427 <kprobe_unwind_native+0x1427>
    1427:      	callq	*%rax
    1429:      	movl	$0x1, %ebx
    142e:      	testq	%rax, %rax
    1431:      	je	0x17e0 <kprobe_unwind_native+0x17e0>
    1437:      	cmpq	%r15, (%rax)
    143a:      	ja	0x1442 <kprobe_unwind_native+0x1442>
    143c:      	cmpq	%r15, 0x8(%rax)
    1440:      	jae	0x1456 <kprobe_unwind_native+0x1456>
    1442:      	cmpq	%r15, 0x10(%rax)
    1446:      	ja	0x17e0 <kprobe_unwind_native+0x17e0>
    144c:      	cmpq	%r15, 0x18(%rax)
    1450:      	jb	0x17e0 <kprobe_unwind_native+0x17e0>
    1456:      	cmpl	$0x0, (%r13)
    145b:      	jne	0x1723 <kprobe_unwind_native+0x1723>
    1461:      	movl	0x1380(%r14), %ecx
    1468:      	movl	0x20(%rax), %edx
    146b:      	btl	%edx, %ecx
    146e:      	jae	0x1794 <kprobe_unwind_native+0x1794>
    1474:      	cmpl	$0x0, (%r13)
    1479:      	je	0x17e0 <kprobe_unwind_native+0x17e0>
    147f:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    1489:      	movq	%rax, 0x70(%rsp)
    148e:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    1498:      	movq	%rax, 0x68(%rsp)
    149d:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    14a7:      	movq	%rax, 0x60(%rsp)
    14ac:      	movl	$0xa656e, 0x77(%rsp)    # imm = 0xA656E
    14b4:      	movl	$0x6, %ecx
    14b9:      	leaq	0x60(%rsp), %rdi
    14be:      	movl	$0x1b, %eax
    14c3:      	movl	$0x1b, %esi
    14c8:      	xorl	%eax, %eax
    14ca:      	callq	*%rcx
    14cc:      	jmp	0x17e0 <kprobe_unwind_native+0x17e0>
    14d1:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    14db:      	movq	%rax, 0x88(%rsp)
    14e3:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    14ed:      	movq	%rax, 0x80(%rsp)
    14f5:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    14ff:      	movq	%rax, 0x78(%rsp)
    1504:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    150e:      	movq	%rax, 0x70(%rsp)
    1513:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    151d:      	movq	%rax, 0x68(%rsp)
    1522:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    152c:      	movq	%rax, 0x60(%rsp)
    1531:      	movb	$0x0, 0x90(%rsp)
    1539:      	movl	$0x6, %ecx
    153e:      	leaq	0x60(%rsp), %rdi
    1543:      	movl	$0x31, %eax
    1548:      	movl	0x2c0(%r14), %edx
    154f:      	movl	$0x31, %esi
    1554:      	xorl	%eax, %eax
    1556:      	callq	*%rcx
    1558:      	movq	0xed0(%r14), %r15
    155f:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    1569:      	cmpq	%rax, %r15
    156c:      	jbe	0x137e <kprobe_unwind_native+0x137e>
    1572:      	jmp	0x1c26 <kprobe_unwind_native+0x1c26>
    1577:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    1581:      	movq	%rax, 0x88(%rsp)
    1589:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    1593:      	movq	%rax, 0x80(%rsp)
    159b:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    15a5:      	movq	%rax, 0x78(%rsp)
    15aa:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    15b4:      	movq	%rax, 0x70(%rsp)
    15b9:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    15c3:      	movq	%rax, 0x68(%rsp)
    15c8:      	movabsq	$0x6365732074786554, %rax # imm = 0x6365732074786554
    15d2:      	movq	%rax, 0x60(%rsp)
    15d7:      	movw	$0xa, 0x90(%rsp)
    15e1:      	movl	$0x6, %r9d
    15e7:      	leaq	0x60(%rsp), %rdi
    15ec:      	movl	$0x32, %eax
    15f1:      	movq	0xf10(%r14), %rcx
    15f8:      	movl	$0x32, %esi
    15fd:      	movq	%r15, %rdx
    1600:      	movl	%ebx, %r8d
    1603:      	xorl	%eax, %eax
    1605:      	callq	*%r9
    1608:      	cmpl	$0x0, (%r13)
    160d:      	je	0x13fd <kprobe_unwind_native+0x13fd>
    1613:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    161d:      	movq	%rax, 0x87(%rsp)
    1625:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    162f:      	movq	%rax, 0x80(%rsp)
    1637:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    1641:      	movq	%rax, 0x78(%rsp)
    1646:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    1650:      	movq	%rax, 0x70(%rsp)
    1655:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    165f:      	movq	%rax, 0x68(%rsp)
    1664:      	movabsq	$0x6365732074786554, %rax # imm = 0x6365732074786554
    166e:      	movq	%rax, 0x60(%rsp)
    1673:      	movl	$0x6, %r8d
    1679:      	leaq	0x60(%rsp), %rdi
    167e:      	movl	$0x2f, %eax
    1683:      	movq	0xf18(%r14), %rcx
    168a:      	movq	0xf20(%r14), %rdx
    1691:      	movl	$0x2f, %esi
    1696:      	xorl	%eax, %eax
    1698:      	callq	*%r8
    169b:      	jmp	0x13fd <kprobe_unwind_native+0x13fd>
    16a0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    16aa:      	movq	%rax, 0x26(%rsp)
    16af:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    16b9:      	movq	%rax, 0x20(%rsp)
    16be:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    16c8:      	movq	%rax, 0x18(%rsp)
    16cd:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    16d7:      	movq	%rax, 0x10(%rsp)
    16dc:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    16e6:      	movq	%rax, 0x8(%rsp)
    16eb:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    16f5:      	movq	%rax, (%rsp)
    16f9:      	movl	$0x6, %ecx
    16fe:      	movq	%rsp, %rdi
    1701:      	movl	$0x2e, %eax
    1706:      	movl	0x48(%rsp), %edx
    170a:      	movl	$0x2e, %esi
    170f:      	xorl	%eax, %eax
    1711:      	callq	*%rcx
    1713:      	cmpl	$0x0, (%r13)
    1718:      	je	0x134b <kprobe_unwind_native+0x134b>
    171e:      	jmp	0x12c1 <kprobe_unwind_native+0x12c1>
    1723:      	movabsq	$0xa642520686374, %rcx  # imm = 0xA642520686374
    172d:      	movq	%rcx, 0x76(%rsp)
    1732:      	movabsq	$0x6374616d20737465, %rcx # imm = 0x6374616D20737465
    173c:      	movq	%rcx, 0x70(%rsp)
    1741:      	movabsq	$0x7366666f5f726574, %rcx # imm = 0x7366666F5F726574
    174b:      	movq	%rcx, 0x68(%rsp)
    1750:      	movabsq	$0x6572707265746e69, %rcx # imm = 0x6572707265746E69
    175a:      	movq	%rcx, 0x60(%rsp)
    175f:      	movl	$0x6, %ecx
    1764:      	leaq	0x60(%rsp), %rdi
    1769:      	movl	$0x1e, %edx
    176e:      	movzwl	0x20(%rax), %edx
    1772:      	movl	$0x1e, %esi
    1777:      	movq	%rax, %r15
    177a:      	xorl	%eax, %eax
    177c:      	callq	*%rcx
    177e:      	movq	%r15, %rax
    1781:      	movl	0x1380(%r14), %ecx
    1788:      	movl	0x20(%rax), %edx
    178b:      	btl	%edx, %ecx
    178e:      	jb	0x1474 <kprobe_unwind_native+0x1474>
    1794:      	movq	%rax, %rbx
    1797:      	movl	$0x0, 0x48(%rsp)
    179f:      	movl	$0x1, %eax
    17a4:      	movq	(%rip), %rdi            # 0x17ab <kprobe_unwind_native+0x17ab>
    17ab:      	leaq	0x48(%rsp), %rsi
    17b0:      	callq	*%rax
    17b2:      	testq	%rax, %rax
    17b5:      	je	0x17bf <kprobe_unwind_native+0x17bf>
    17b7:      	incq	(%rax)
    17ba:      	movq	%rbx, %rax
    17bd:      	jmp	0x17cd <kprobe_unwind_native+0x17cd>
    17bf:      	cmpl	$0x0, (%r13)
    17c4:      	movq	%rbx, %rax
    17c7:      	jne	0x18e4 <kprobe_unwind_native+0x18e4>
    17cd:      	movzwl	0x20(%rax), %ebx
    17d1:      	nopw	%cs:(%rax,%rax)
    17e0:      	xorl	%ebp, %ebp
    17e2:      	cmpl	$0x1, %ebx
    17e5:      	movl	0x11c(%rsp), %r15d
    17ed:      	jne	0x1ca9 <kprobe_unwind_native+0x1ca9>
    17f3:      	decl	%r15d
    17f6:      	jne	0xba <kprobe_unwind_native+0xba>
    17fc:      	jmp	0x1c7d <kprobe_unwind_native+0x1c7d>
    1801:      	movabsq	$0x2578302073736572, %rax # imm = 0x2578302073736572
    180b:      	movq	%rax, 0x20(%rsp)
    1810:      	movabsq	$0x6464612065636e65, %rax # imm = 0x6464612065636E65
    181a:      	movq	%rax, 0x18(%rsp)
    181f:      	movabsq	$0x7265666572656420, %rax # imm = 0x7265666572656420
    1829:      	movq	%rax, 0x10(%rsp)
    182e:      	movabsq	$0x6f742064656c6961, %rax # imm = 0x6F742064656C6961
    1838:      	movq	%rax, 0x8(%rsp)
    183d:      	movabsq	$0x6620646e69776e75, %rax # imm = 0x6620646E69776E75
    1847:      	movq	%rax, (%rsp)
    184b:      	movl	$0xa786c, 0x28(%rsp)    # imm = 0xA786C
    1853:      	movl	$0x6, %ecx
    1858:      	movq	%rsp, %rdi
    185b:      	movl	$0x2c, %eax
    1860:      	movl	$0x2c, %esi
    1865:      	movq	%r12, %rdx
    1868:      	xorl	%eax, %eax
    186a:      	callq	*%rcx
    186c:      	xorl	%r12d, %r12d
    186f:      	jmp	0x1070 <kprobe_unwind_native+0x1070>
    1874:      	movabsq	$0x2578302073736572, %rax # imm = 0x2578302073736572
    187e:      	movq	%rax, 0x20(%rsp)
    1883:      	movabsq	$0x6464612065636e65, %rax # imm = 0x6464612065636E65
    188d:      	movq	%rax, 0x18(%rsp)
    1892:      	movabsq	$0x7265666572656420, %rax # imm = 0x7265666572656420
    189c:      	movq	%rax, 0x10(%rsp)
    18a1:      	movabsq	$0x6f742064656c6961, %rax # imm = 0x6F742064656C6961
    18ab:      	movq	%rax, 0x8(%rsp)
    18b0:      	movabsq	$0x6620646e69776e75, %rax # imm = 0x6620646E69776E75
    18ba:      	movq	%rax, (%rsp)
    18be:      	movl	$0xa786c, 0x28(%rsp)    # imm = 0xA786C
    18c6:      	movl	$0x6, %ecx
    18cb:      	movq	%rsp, %rdi
    18ce:      	movl	$0x2c, %eax
    18d3:      	movl	$0x2c, %esi
    18d8:      	movq	%r15, %rdx
    18db:      	xorl	%eax, %eax
    18dd:      	callq	*%rcx
    18df:      	jmp	0x1166 <kprobe_unwind_native+0x1166>
    18e4:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    18ee:      	movq	%rax, 0x86(%rsp)
    18f6:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1900:      	movq	%rax, 0x80(%rsp)
    1908:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1912:      	movq	%rax, 0x78(%rsp)
    1917:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1921:      	movq	%rax, 0x70(%rsp)
    1926:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1930:      	movq	%rax, 0x68(%rsp)
    1935:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    193f:      	movq	%rax, 0x60(%rsp)
    1944:      	movl	$0x6, %ecx
    1949:      	leaq	0x60(%rsp), %rdi
    194e:      	movl	$0x2e, %eax
    1953:      	movl	0x48(%rsp), %edx
    1957:      	movl	$0x2e, %esi
    195c:      	xorl	%eax, %eax
    195e:      	callq	*%rcx
    1960:      	jmp	0x17ba <kprobe_unwind_native+0x17ba>
    1965:      	movl	$0xe, 0x48(%rsp)
    196d:      	movq	(%rip), %rdi            # 0x1974 <kprobe_unwind_native+0x1974>
    1974:      	leaq	0x48(%rsp), %rsi
    1979:      	movl	$0x1, %eax
    197e:      	callq	*%rax
    1980:      	testq	%rax, %rax
    1983:      	je	0x1c84 <kprobe_unwind_native+0x1c84>
    1989:      	incq	(%rax)
    198c:      	jmp	0x1c8f <kprobe_unwind_native+0x1c8f>
    1991:      	movq	(%rip), %r13            # 0x1998 <kprobe_unwind_native+0x1998>
    1998:      	movl	$0xfa3, %ebp            # imm = 0xFA3
    199d:      	movl	$0x9, %ebx
    19a2:      	cmpl	$0x0, (%r13)
    19a7:      	je	0x1ca0 <kprobe_unwind_native+0x1ca0>
    19ad:      	movabsq	$0x6174616420747075, %rax # imm = 0x6174616420747075
    19b7:      	movq	%rax, 0x20(%rsp)
    19bc:      	movabsq	$0x72726f43202e7370, %rax # imm = 0x72726F43202E7370
    19c6:      	movq	%rax, 0x18(%rsp)
    19cb:      	movabsq	$0x657473203631206e, %rax # imm = 0x657473203631206E
    19d5:      	movq	%rax, 0x10(%rsp)
    19da:      	movabsq	$0x6920686372616573, %rax # imm = 0x6920686372616573
    19e4:      	movq	%rax, 0x8(%rsp)
    19e9:      	movabsq	$0x622064656c696146, %rax # imm = 0x622064656C696146
    19f3:      	movq	%rax, (%rsp)
    19f7:      	movl	$0xa3f61, 0x27(%rsp)    # imm = 0xA3F61
    19ff:      	movq	%rsp, %rdi
    1a02:      	movl	$0x2b, %eax
    1a07:      	movl	$0x6, %ecx
    1a0c:      	movl	$0x2b, %esi
    1a11:      	xorl	%eax, %eax
    1a13:      	callq	*%rcx
    1a15:      	jmp	0x1ca0 <kprobe_unwind_native+0x1ca0>
    1a1a:      	cmpl	$0x0, (%r13)
    1a1f:      	jne	0x1faa <kprobe_unwind_native+0x1faa>
    1a25:      	movl	$0x2, (%rsp)
    1a2c:      	movq	(%rip), %rdi            # 0x1a33 <kprobe_unwind_native+0x1a33>
    1a33:      	movq	%rsp, %rsi
    1a36:      	movl	$0x1, %eax
    1a3b:      	callq	*%rax
    1a3d:      	testq	%rax, %rax
    1a40:      	je	0x1db4 <kprobe_unwind_native+0x1db4>
    1a46:      	incq	(%rax)
    1a49:      	xorl	%ebx, %ebx
    1a4b:      	cmpl	$0x0, (%r13)
    1a50:      	movl	$0x2, %ebp
    1a55:      	je	0x1ca9 <kprobe_unwind_native+0x1ca9>
    1a5b:      	movabsq	$0xa656d61726620, %rax  # imm = 0xA656D61726620
    1a65:      	movq	%rax, 0x75(%rsp)
    1a6a:      	movabsq	$0x7266206576697461, %rax # imm = 0x7266206576697461
    1a74:      	movq	%rax, 0x70(%rsp)
    1a79:      	movabsq	$0x6e2068737570206f, %rax # imm = 0x6E2068737570206F
    1a83:      	movq	%rax, 0x68(%rsp)
    1a88:      	movabsq	$0x742064656c696166, %rax # imm = 0x742064656C696166
    1a92:      	movq	%rax, 0x60(%rsp)
    1a97:      	leaq	0x60(%rsp), %rdi
    1a9c:      	movl	$0x1d, %eax
    1aa1:      	movl	$0x6, %ecx
    1aa6:      	xorl	%ebx, %ebx
    1aa8:      	movl	$0x1d, %esi
    1aad:      	xorl	%eax, %eax
    1aaf:      	callq	*%rcx
    1ab1:      	jmp	0x1ca9 <kprobe_unwind_native+0x1ca9>
    1ab6:      	movl	$0xfa0, %ebp            # imm = 0xFA0
    1abb:      	movl	$0x8, %ebx
    1ac0:      	cmpl	$0x0, (%r13)
    1ac5:      	je	0x1ca0 <kprobe_unwind_native+0x1ca0>
    1acb:      	movabsq	$0x786c252065676170, %rax # imm = 0x786C252065676170
    1ad5:      	movq	%rax, 0x30(%rsp)
    1ada:      	movabsq	$0x202c786c25204449, %rax # imm = 0x202C786C25204449
    1ae4:      	movq	%rax, 0x28(%rsp)
    1ae9:      	movabsq	$0x656c696620656761, %rax # imm = 0x656C696620656761
    1af3:      	movq	%rax, 0x20(%rsp)
    1af8:      	movabsq	$0x702061746c656420, %rax # imm = 0x702061746C656420
    1b02:      	movq	%rax, 0x18(%rsp)
    1b07:      	movabsq	$0x6b63617473207075, %rax # imm = 0x6B63617473207075
    1b11:      	movq	%rax, 0x10(%rsp)
    1b16:      	movabsq	$0x206b6f6f6c206f74, %rax # imm = 0x206B6F6F6C206F74
    1b20:      	movq	%rax, 0x8(%rsp)
    1b25:      	movabsq	$0x206572756c696146, %rax # imm = 0x206572756C696146
    1b2f:      	movq	%rax, (%rsp)
    1b33:      	movw	$0xa, 0x38(%rsp)
    1b3a:      	movq	%rsp, %rdi
    1b3d:      	movl	$0x3a, %eax
    1b42:      	movl	$0x6, %r8d
    1b48:      	movq	0x48(%rsp), %rdx
    1b4d:      	movq	0x50(%rsp), %rcx
    1b52:      	movl	$0x3a, %esi
    1b57:      	xorl	%eax, %eax
    1b59:      	callq	*%r8
    1b5c:      	jmp	0x1ca0 <kprobe_unwind_native+0x1ca0>
    1b61:      	movl	$0xfa2, %ebp            # imm = 0xFA2
    1b66:      	movl	$0x32, %ebx
    1b6b:      	cmpl	$0x0, (%r13)
    1b70:      	je	0x1ca0 <kprobe_unwind_native+0x1ca0>
    1b76:      	movabsq	$0x6c25206e6f697463, %rax # imm = 0x6C25206E6F697463
    1b80:      	movq	%rax, 0x28(%rsp)
    1b85:      	movabsq	$0x6573207478657420, %rax # imm = 0x6573207478657420
    1b8f:      	movq	%rax, 0x20(%rsp)
    1b94:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1b9e:      	movq	%rax, 0x18(%rsp)
    1ba3:      	movabsq	$0x72656e6e69207075, %rax # imm = 0x72656E6E69207075
    1bad:      	movq	%rax, 0x10(%rsp)
    1bb2:      	movabsq	$0x206b6f6f6c206f74, %rax # imm = 0x206B6F6F6C206F74
    1bbc:      	movq	%rax, 0x8(%rsp)
    1bc1:      	movabsq	$0x206572756c696146, %rax # imm = 0x206572756C696146
    1bcb:      	movq	%rax, (%rsp)
    1bcf:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    1bd7:      	movq	%rsp, %rdi
    1bda:      	movl	$0x33, %eax
    1bdf:      	movl	$0x6, %ecx
    1be4:      	movq	0x110(%rsp), %rdx
    1bec:      	movl	$0x33, %esi
    1bf1:      	xorl	%eax, %eax
    1bf3:      	callq	*%rcx
    1bf5:      	jmp	0x1ca0 <kprobe_unwind_native+0x1ca0>
    1bfa:      	movl	$0xfa4, %ebp            # imm = 0xFA4
    1bff:      	movl	$0xa, %ebx
    1c04:      	jmp	0x1ca0 <kprobe_unwind_native+0x1ca0>
    1c09:      	testl	%eax, %eax
    1c0b:      	jne	0x2012 <kprobe_unwind_native+0x2012>
    1c11:      	movl	$0x1, 0xf28(%r14)
    1c1c:      	movl	$0xfad, %ebp            # imm = 0xFAD
    1c21:      	jmp	0x1ca7 <kprobe_unwind_native+0x1ca7>
    1c26:      	cmpl	$0x0, (%r13)
    1c2b:      	jne	0x2097 <kprobe_unwind_native+0x2097>
    1c31:      	movl	$0xb, 0xf28(%r14)
    1c3c:      	movl	$0xfab, %ebp            # imm = 0xFAB
    1c41:      	jmp	0x1ca7 <kprobe_unwind_native+0x1ca7>
    1c43:      	cmpl	$0x0, (%r13)
    1c48:      	jne	0x20fd <kprobe_unwind_native+0x20fd>
    1c4e:      	movl	$0x31, 0xf28(%r14)
    1c59:      	movl	$0xfae, %ebp            # imm = 0xFAE
    1c5e:      	jmp	0x1ca7 <kprobe_unwind_native+0x1ca7>
    1c60:      	cmpl	$0x0, (%r13)
    1c65:      	jne	0x2159 <kprobe_unwind_native+0x2159>
    1c6b:      	movl	$0xc, 0xf28(%r14)
    1c76:      	movl	$0xfac, %ebp            # imm = 0xFAC
    1c7b:      	jmp	0x1ca7 <kprobe_unwind_native+0x1ca7>
    1c7d:      	movl	$0x1, %ebx
    1c82:      	jmp	0x1ca9 <kprobe_unwind_native+0x1ca9>
    1c84:      	cmpl	$0x0, (%r13)
    1c89:      	jne	0x21f3 <kprobe_unwind_native+0x21f3>
    1c8f:      	movl	$0xfa7, %ebp            # imm = 0xFA7
    1c94:      	jmp	0x1ca7 <kprobe_unwind_native+0x1ca7>
    1c96:      	movl	$0xfa5, %ebp            # imm = 0xFA5
    1c9b:      	movl	$0xd, %ebx
    1ca0:      	movl	%ebx, 0xf28(%r14)
    1ca7:      	xorl	%ebx, %ebx
    1ca9:      	movl	%ebp, 0xf2c(%r14)
    1cb0:      	movl	$0x0, 0x60(%rsp)
    1cb8:      	movq	(%rip), %rdi            # 0x1cbf <kprobe_unwind_native+0x1cbf>
    1cbf:      	leaq	0x60(%rsp), %rsi
    1cc4:      	movl	$0x1, %eax
    1cc9:      	callq	*%rax
    1ccb:      	testq	%rax, %rax
    1cce:      	je	0x1d1b <kprobe_unwind_native+0x1d1b>
    1cd0:      	movzbl	0x1384(%rax), %ecx
    1cd7:      	movl	%ebx, %edx
    1cd9:      	cmpb	$0x1d, %cl
    1cdc:      	movq	0x140(%rsp), %rdi
    1ce4:      	jb	0x1d4e <kprobe_unwind_native+0x1d4e>
    1ce6:      	movq	%rdi, %r15
    1ce9:      	movq	%rax, %r14
    1cec:      	movl	$0x5, 0xf2c(%rax)
    1cf6:      	movl	$0x44, (%rsp)
    1cfd:      	movq	(%rip), %rdi            # 0x1d04 <kprobe_unwind_native+0x1d04>
    1d04:      	movq	%rsp, %rsi
    1d07:      	movl	$0x1, %eax
    1d0c:      	callq	*%rax
    1d0e:      	testq	%rax, %rax
    1d11:      	je	0x1d33 <kprobe_unwind_native+0x1d33>
    1d13:      	incq	(%rax)
    1d16:      	movq	%r15, %rdi
    1d19:      	jmp	0x1d41 <kprobe_unwind_native+0x1d41>
    1d1b:      	movq	(%rip), %rcx            # 0x1d22 <kprobe_unwind_native+0x1d22>
    1d22:      	xorl	%edx, %edx
    1d24:      	movl	$0xc, %eax
    1d29:      	movq	0x140(%rsp), %rdi
    1d31:      	jmp	0x1d64 <kprobe_unwind_native+0x1d64>
    1d33:      	cmpl	$0x0, (%r13)
    1d38:      	movq	%r15, %rdi
    1d3b:      	jne	0x1f2a <kprobe_unwind_native+0x1f2a>
    1d41:      	movq	%r14, %rax
    1d44:      	movzbl	0x1384(%r14), %ecx
    1d4c:      	xorl	%edx, %edx
    1d4e:      	incb	%cl
    1d50:      	movb	%cl, 0x1384(%rax)
    1d56:      	movl	%edx, %ecx
    1d58:      	movq	(%rip), %rsi            # 0x1d5f <kprobe_unwind_native+0x1d5f>
    1d5f:      	movl	$0xc, %eax
    1d64:      	movq	(%rip), %rsi            # 0x1d6b <kprobe_unwind_native+0x1d6b>
    1d6b:      	callq	*%rax
    1d6d:      	cmpl	$0x0, (%r13)
    1d72:      	jne	0x1eab <kprobe_unwind_native+0x1eab>
    1d78:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
    1d7d:      	addq	$0x148, %rsp            # imm = 0x148
    1d84:      	popq	%rbx
    1d85:      	popq	%r12
    1d87:      	popq	%r13
    1d89:      	popq	%r14
    1d8b:      	popq	%r15
    1d8d:      	popq	%rbp
    1d8e:      	retq
    1d8f:      	movl	$0x55, 0x48(%rsp)
    1d97:      	movq	(%rip), %rdi            # 0x1d9e <kprobe_unwind_native+0x1d9e>
    1d9e:      	leaq	0x48(%rsp), %rsi
    1da3:      	movl	$0x1, %eax
    1da8:      	callq	*%rax
    1daa:      	testq	%rax, %rax
    1dad:      	je	0x1dd5 <kprobe_unwind_native+0x1dd5>
    1daf:      	incq	(%rax)
    1db2:      	jmp	0x1de0 <kprobe_unwind_native+0x1de0>
    1db4:      	cmpl	$0x0, (%r13)
    1db9:      	jne	0x226b <kprobe_unwind_native+0x226b>
    1dbf:      	movl	$0x2, %ebp
    1dc4:      	jmp	0x1ca7 <kprobe_unwind_native+0x1ca7>
    1dc9:      	cmpl	$0x1, %eax
    1dcc:      	jne	0x1dea <kprobe_unwind_native+0x1dea>
    1dce:      	xorl	%ebp, %ebp
    1dd0:      	jmp	0x1ca7 <kprobe_unwind_native+0x1ca7>
    1dd5:      	cmpl	$0x0, (%r13)
    1dda:      	jne	0x22fd <kprobe_unwind_native+0x22fd>
    1de0:      	movl	$0xfaf, %ebp            # imm = 0xFAF
    1de5:      	jmp	0x1ca7 <kprobe_unwind_native+0x1ca7>
    1dea:      	movl	$0x1, %ebp
    1def:      	jmp	0x1ca7 <kprobe_unwind_native+0x1ca7>
    1df4:      	movl	$0xfa1, %ebp            # imm = 0xFA1
    1df9:      	movl	$0x33, %ebx
    1dfe:      	cmpl	$0x0, (%r13)
    1e03:      	je	0x1ca0 <kprobe_unwind_native+0x1ca0>
    1e09:      	movabsq	$0xa642520444970, %rax  # imm = 0xA642520444970
    1e13:      	movq	%rax, 0x37(%rsp)
    1e18:      	movabsq	$0x70616d206e692078, %rax # imm = 0x70616D206E692078
    1e22:      	movq	%rax, 0x30(%rsp)
    1e27:      	movabsq	$0x6c25206e6f697463, %rax # imm = 0x6C25206E6F697463
    1e31:      	movq	%rax, 0x28(%rsp)
    1e36:      	movabsq	$0x6573207478657420, %rax # imm = 0x6573207478657420
    1e40:      	movq	%rax, 0x20(%rsp)
    1e45:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1e4f:      	movq	%rax, 0x18(%rsp)
    1e54:      	movabsq	$0x726574756f207075, %rax # imm = 0x726574756F207075
    1e5e:      	movq	%rax, 0x10(%rsp)
    1e63:      	movabsq	$0x206b6f6f6c206f74, %rax # imm = 0x206B6F6F6C206F74
    1e6d:      	movq	%rax, 0x8(%rsp)
    1e72:      	movabsq	$0x206572756c696146, %rax # imm = 0x206572756C696146
    1e7c:      	movq	%rax, (%rsp)
    1e80:      	movq	%rsp, %rdi
    1e83:      	movl	$0x3f, %eax
    1e88:      	movl	$0x6, %r8d
    1e8e:      	movq	0x110(%rsp), %rdx
    1e96:      	movzwl	0x6(%r12), %ecx
    1e9c:      	movl	$0x3f, %esi
    1ea1:      	xorl	%eax, %eax
    1ea3:      	callq	*%r8
    1ea6:      	jmp	0x1ca0 <kprobe_unwind_native+0x1ca0>
    1eab:      	movabsq	$0xa65766974616e, %rax  # imm = 0xA65766974616E
    1eb5:      	movq	%rax, 0x86(%rsp)
    1ebd:      	movabsq	$0x616e5f646e69776e, %rax # imm = 0x616E5F646E69776E
    1ec7:      	movq	%rax, 0x80(%rsp)
    1ecf:      	movabsq	$0x75206e6920642520, %rax # imm = 0x75206E6920642520
    1ed9:      	movq	%rax, 0x78(%rsp)
    1ede:      	movabsq	$0x726f662064656c69, %rax # imm = 0x726F662064656C69
    1ee8:      	movq	%rax, 0x70(%rsp)
    1eed:      	movabsq	$0x6166206c6c616320, %rax # imm = 0x6166206C6C616320
    1ef7:      	movq	%rax, 0x68(%rsp)
    1efc:      	movabsq	$0x6c6961745f667062, %rax # imm = 0x6C6961745F667062
    1f06:      	movq	%rax, 0x60(%rsp)
    1f0b:      	leaq	0x60(%rsp), %rdi
    1f10:      	movl	$0x2e, %eax
    1f15:      	movl	$0x6, %ecx
    1f1a:      	movl	$0x2e, %esi
    1f1f:      	movl	%ebx, %edx
    1f21:      	xorl	%eax, %eax
    1f23:      	callq	*%rcx
    1f25:      	jmp	0x1d78 <kprobe_unwind_native+0x1d78>
    1f2a:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1f34:      	movq	%rax, 0x86(%rsp)
    1f3c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1f46:      	movq	%rax, 0x80(%rsp)
    1f4e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1f58:      	movq	%rax, 0x78(%rsp)
    1f5d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1f67:      	movq	%rax, 0x70(%rsp)
    1f6c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1f76:      	movq	%rax, 0x68(%rsp)
    1f7b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1f85:      	movq	%rax, 0x60(%rsp)
    1f8a:      	leaq	0x60(%rsp), %rdi
    1f8f:      	movl	$0x2e, %eax
    1f94:      	movl	$0x6, %ecx
    1f99:      	movl	(%rsp), %edx
    1f9c:      	movl	$0x2e, %esi
    1fa1:      	xorl	%eax, %eax
    1fa3:      	callq	*%rcx
    1fa5:      	jmp	0x1d16 <kprobe_unwind_native+0x1d16>
    1faa:      	movabsq	$0xa6c6c75662073, %rax  # imm = 0xA6C6C75662073
    1fb4:      	movq	%rax, 0x7d(%rsp)
    1fb9:      	movabsq	$0x66207369206b6361, %rax # imm = 0x66207369206B6361
    1fc3:      	movq	%rax, 0x78(%rsp)
    1fc8:      	movabsq	$0x7473203a656d6172, %rax # imm = 0x7473203A656D6172
    1fd2:      	movq	%rax, 0x70(%rsp)
    1fd7:      	movabsq	$0x662068737570206f, %rax # imm = 0x662068737570206F
    1fe1:      	movq	%rax, 0x68(%rsp)
    1fe6:      	movabsq	$0x7420656c62616e75, %rax # imm = 0x7420656C62616E75
    1ff0:      	movq	%rax, 0x60(%rsp)
    1ff5:      	leaq	0x60(%rsp), %rdi
    1ffa:      	movl	$0x25, %eax
    1fff:      	movl	$0x6, %ecx
    2004:      	movl	$0x25, %esi
    2009:      	xorl	%eax, %eax
    200b:      	callq	*%rcx
    200d:      	jmp	0x1a25 <kprobe_unwind_native+0x1a25>
    2012:      	movabsq	$0xa2930203d3d2043, %rax # imm = 0xA2930203D3D2043
    201c:      	movq	%rax, 0x88(%rsp)
    2024:      	movabsq	$0x5028206572756c69, %rax # imm = 0x5028206572756C69
    202e:      	movq	%rax, 0x80(%rsp)
    2036:      	movabsq	$0x616620646e69776e, %rax # imm = 0x616620646E69776E
    2040:      	movq	%rax, 0x78(%rsp)
    2045:      	movabsq	$0x75206f7420657564, %rax # imm = 0x75206F7420657564
    204f:      	movq	%rax, 0x70(%rsp)
    2054:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    205e:      	movq	%rax, 0x68(%rsp)
    2063:      	movabsq	$0x676e6970706f7453, %rax # imm = 0x676E6970706F7453
    206d:      	movq	%rax, 0x60(%rsp)
    2072:      	movb	$0x0, 0x90(%rsp)
    207a:      	leaq	0x60(%rsp), %rdi
    207f:      	movl	$0x31, %eax
    2084:      	movl	$0x6, %ecx
    2089:      	movl	$0x31, %esi
    208e:      	xorl	%eax, %eax
    2090:      	callq	*%rcx
    2092:      	jmp	0x1c11 <kprobe_unwind_native+0x1c11>
    2097:      	movabsq	$0x7373657264646120, %rax # imm = 0x7373657264646120
    20a1:      	movq	%rax, 0x78(%rsp)
    20a6:      	movabsq	$0x6c656e72656b2061, %rax # imm = 0x6C656E72656B2061
    20b0:      	movq	%rax, 0x70(%rsp)
    20b5:      	movabsq	$0x20736920786c2520, %rax # imm = 0x20736920786C2520
    20bf:      	movq	%rax, 0x68(%rsp)
    20c4:      	movabsq	$0x65756c6176204350, %rax # imm = 0x65756C6176204350
    20ce:      	movq	%rax, 0x60(%rsp)
    20d3:      	movw	$0xa, 0x80(%rsp)
    20dd:      	leaq	0x60(%rsp), %rdi
    20e2:      	movl	$0x22, %eax
    20e7:      	movl	$0x6, %ecx
    20ec:      	movl	$0x22, %esi
    20f1:      	movq	%r15, %rdx
    20f4:      	xorl	%eax, %eax
    20f6:      	callq	*%rcx
    20f8:      	jmp	0x1c31 <kprobe_unwind_native+0x1c31>
    20fd:      	movabsq	$0xa676e69726f6e, %rax  # imm = 0xA676E69726F6E
    2107:      	movq	%rax, 0x76(%rsp)
    210c:      	movabsq	$0x6f6e6769202c786c, %rax # imm = 0x6F6E6769202C786C
    2116:      	movq	%rax, 0x70(%rsp)
    211b:      	movabsq	$0x252065756c617620, %rax # imm = 0x252065756C617620
    2125:      	movq	%rax, 0x68(%rsp)
    212a:      	movabsq	$0x6370206c6c616d73, %rax # imm = 0x6370206C6C616D73
    2134:      	movq	%rax, 0x60(%rsp)
    2139:      	leaq	0x60(%rsp), %rdi
    213e:      	movl	$0x1e, %eax
    2143:      	movl	$0x6, %ecx
    2148:      	movl	$0x1e, %esi
    214d:      	movq	%r15, %rdx
    2150:      	xorl	%eax, %eax
    2152:      	callq	*%rcx
    2154:      	jmp	0x1c4e <kprobe_unwind_native+0x1c4e>
    2159:      	movabsq	$0xa786c2578302043, %rax # imm = 0xA786C2578302043
    2163:      	movq	%rax, 0x90(%rsp)
    216b:      	movabsq	$0x5020726f6620676e, %rax # imm = 0x5020726F6620676E
    2175:      	movq	%rax, 0x88(%rsp)
    217d:      	movabsq	$0x697070616d207972, %rax # imm = 0x697070616D207972
    2187:      	movq	%rax, 0x80(%rsp)
    218f:      	movabsq	$0x6f6d656d206c6176, %rax # imm = 0x6F6D656D206C6176
    2199:      	movq	%rax, 0x78(%rsp)
    219e:      	movabsq	$0x7265746e69207075, %rax # imm = 0x7265746E69207075
    21a8:      	movq	%rax, 0x70(%rsp)
    21ad:      	movabsq	$0x206b6f6f6c206f74, %rax # imm = 0x206B6F6F6C206F74
    21b7:      	movq	%rax, 0x68(%rsp)
    21bc:      	movabsq	$0x206572756c696146, %rax # imm = 0x206572756C696146
    21c6:      	movq	%rax, 0x60(%rsp)
    21cb:      	movb	$0x0, 0x98(%rsp)
    21d3:      	leaq	0x60(%rsp), %rdi
    21d8:      	movl	$0x39, %eax
    21dd:      	movl	$0x6, %ecx
    21e2:      	movl	$0x39, %esi
    21e7:      	movq	%r15, %rdx
    21ea:      	xorl	%eax, %eax
    21ec:      	callq	*%rcx
    21ee:      	jmp	0x1c6b <kprobe_unwind_native+0x1c6b>
    21f3:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    21fd:      	movq	%rax, 0x26(%rsp)
    2202:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    220c:      	movq	%rax, 0x20(%rsp)
    2211:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    221b:      	movq	%rax, 0x18(%rsp)
    2220:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    222a:      	movq	%rax, 0x10(%rsp)
    222f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2239:      	movq	%rax, 0x8(%rsp)
    223e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2248:      	movq	%rax, (%rsp)
    224c:      	movq	%rsp, %rdi
    224f:      	movl	$0x2e, %eax
    2254:      	movl	$0x6, %ecx
    2259:      	movl	0x48(%rsp), %edx
    225d:      	movl	$0x2e, %esi
    2262:      	xorl	%eax, %eax
    2264:      	callq	*%rcx
    2266:      	jmp	0x1c8f <kprobe_unwind_native+0x1c8f>
    226b:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2275:      	movq	%rax, 0x86(%rsp)
    227d:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2287:      	movq	%rax, 0x80(%rsp)
    228f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2299:      	movq	%rax, 0x78(%rsp)
    229e:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    22a8:      	movq	%rax, 0x70(%rsp)
    22ad:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    22b7:      	movq	%rax, 0x68(%rsp)
    22bc:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    22c6:      	movq	%rax, 0x60(%rsp)
    22cb:      	leaq	0x60(%rsp), %rdi
    22d0:      	movl	$0x2e, %eax
    22d5:      	movl	$0x6, %ecx
    22da:      	movl	(%rsp), %edx
    22dd:      	movl	$0x2e, %esi
    22e2:      	xorl	%eax, %eax
    22e4:      	callq	*%rcx
    22e6:      	xorl	%ebx, %ebx
    22e8:      	cmpl	$0x0, (%r13)
    22ed:      	movl	$0x2, %ebp
    22f2:      	je	0x1ca9 <kprobe_unwind_native+0x1ca9>
    22f8:      	jmp	0x1a5b <kprobe_unwind_native+0x1a5b>
    22fd:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2307:      	movq	%rax, 0x26(%rsp)
    230c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2316:      	movq	%rax, 0x20(%rsp)
    231b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2325:      	movq	%rax, 0x18(%rsp)
    232a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2334:      	movq	%rax, 0x10(%rsp)
    2339:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2343:      	movq	%rax, 0x8(%rsp)
    2348:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2352:      	movq	%rax, (%rsp)
    2356:      	movq	%rsp, %rdi
    2359:      	movl	$0x2e, %eax
    235e:      	movl	$0x6, %ecx
    2363:      	movl	0x48(%rsp), %edx
    2367:      	movl	$0x2e, %esi
    236c:      	xorl	%eax, %eax
    236e:      	callq	*%rcx
    2370:      	jmp	0x1de0 <kprobe_unwind_native+0x1de0>
