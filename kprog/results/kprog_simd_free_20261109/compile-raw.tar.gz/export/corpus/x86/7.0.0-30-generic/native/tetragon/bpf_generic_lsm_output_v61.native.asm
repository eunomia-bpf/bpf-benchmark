
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_generic_lsm_output_v61.native.o:	file format elf64-x86-64

Disassembly of section lsm/generic_lsm_output:

0000000000000000 <generic_lsm_output>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x78, %rsp
       e:      	movq	%rdi, %rbx
      11:      	movl	$0x0, 0x68(%rsp)
      19:      	movq	(%rip), %rdi            # 0x20 <generic_lsm_output+0x20>
      20:      	leaq	0x68(%rsp), %rsi
      25:      	movl	$0x1, %eax
      2a:      	callq	*%rax
      2c:      	testq	%rax, %rax
      2f:      	je	0x5ec <generic_lsm_output+0x5ec>
      35:      	movq	%rax, %r14
      38:      	testb	$0x8, 0x1(%rax)
      3c:      	je	0xc3 <generic_lsm_output+0xc3>
      42:      	movl	$0xe, %eax
      47:      	callq	*%rax
      49:      	movq	%rax, 0x20(%rsp)
      4e:      	movq	(%rip), %rdi            # 0x55 <generic_lsm_output+0x55>
      55:      	leaq	0x20(%rsp), %rsi
      5a:      	movl	$0x1, %eax
      5f:      	callq	*%rax
      61:      	testq	%rax, %rax
      64:      	je	0xc3 <generic_lsm_output+0xc3>
      66:      	movq	%rax, %rdx
      69:      	cmpb	$0x2, (%rax)
      6c:      	jne	0xc3 <generic_lsm_output+0xc3>
      6e:      	movl	0x4(%r14), %eax
      72:      	cmpq	$0x3fbd, %rax           # imm = 0x3FBD
      78:      	ja	0xb0 <generic_lsm_output+0xb0>
      7a:      	leaq	(%r14,%rax), %rcx
      7e:      	addq	$0x90, %rcx
      85:      	movl	$0x42, %esi
      8a:      	movl	$0x4, %eax
      8f:      	movl	0x4(%r14), %ecx
      93:      	andl	$0x3fff, %ecx           # imm = 0x3FFF
      99:      	leaq	(%r14,%rcx), %rdi
      9d:      	addq	$0x90, %rdi
      a4:      	movl	$0x42, %esi
      a9:      	callq	*%rax
      ab:      	addl	$0x42, 0x4(%r14)
      b0:      	movq	(%rip), %rdi            # 0xb7 <generic_lsm_output+0xb7>
      b7:      	leaq	0x20(%rsp), %rsi
      bc:      	movl	$0x3, %eax
      c1:      	callq	*%rax
      c3:      	cmpb	$0x0, 0x5f08(%r14)
      cb:      	je	0x59e <generic_lsm_output+0x59e>
      d1:      	movl	$0x0, 0x6c(%rsp)
      d9:      	movq	(%rip), %rdi            # 0xe0 <generic_lsm_output+0xe0>
      e0:      	leaq	0x6c(%rsp), %rsi
      e5:      	movl	$0x1, %eax
      ea:      	callq	*%rax
      ec:      	testq	%rax, %rax
      ef:      	je	0x59e <generic_lsm_output+0x59e>
      f5:      	movq	%rax, %r14
      f8:      	cmpq	$0x0, 0x5ee8(%rax)
     100:      	je	0x408 <generic_lsm_output+0x408>
     106:      	movl	$0xe, %eax
     10b:      	callq	*%rax
     10d:      	movq	%rax, %r15
     110:      	shrq	$0x20, %r15
     114:      	movl	$0x23, %eax
     119:      	callq	*%rax
     11b:      	movq	%rax, %r12
     11e:      	movl	%r15d, 0x20(%rsp)
     123:      	movq	(%rip), %rdi            # 0x12a <generic_lsm_output+0x12a>
     12a:      	leaq	0x20(%rsp), %rsi
     12f:      	movl	$0x1, %eax
     134:      	callq	*%rax
     136:      	testq	%rax, %rax
     139:      	je	0x408 <generic_lsm_output+0x408>
     13f:      	movq	%rax, %r15
     142:      	leaq	0xd70(%r12), %rdx
     14a:      	leaq	0x70(%rsp), %rdi
     14f:      	movl	$0x8, %ecx
     154:      	movl	$0x4, %eax
     159:      	leaq	0x28(%r15), %r13
     15d:      	movl	$0x4, %ebp
     162:      	movl	$0x8, %esi
     167:      	callq	*%rax
     169:      	movq	0x70(%rsp), %rcx
     16e:      	leaq	0x20(%rsp), %rdi
     173:      	movl	$0x48, %edx
     178:      	movl	$0x4, %eax
     17d:      	movq	0x70(%rsp), %rdx
     182:      	movl	$0x48, %esi
     187:      	callq	*%rax
     189:      	movl	$0x218, %edx            # imm = 0x218
     18e:      	movq	0x28(%rsp), %rcx
     193:      	addq	%rdx, %rcx
     196:      	movl	$0x4, %esi
     19b:      	movl	$0x4, %eax
     1a0:      	addq	0x28(%rsp), %rdx
     1a5:      	movq	%r13, %rdi
     1a8:      	movl	$0x4, %esi
     1ad:      	callq	*%rax
     1af:      	leaq	0x2c(%r15), %rdi
     1b3:      	movl	$0x4d8, %edx            # imm = 0x4D8
     1b8:      	movq	0x30(%rsp), %rcx
     1bd:      	addq	%rdx, %rcx
     1c0:      	movl	$0x4, %esi
     1c5:      	movl	$0x4, %eax
     1ca:      	addq	0x30(%rsp), %rdx
     1cf:      	movl	$0x4, %esi
     1d4:      	callq	*%rax
     1d6:      	leaq	0x30(%r15), %rdi
     1da:      	movq	0x38(%rsp), %rcx
     1df:      	addq	$0x58, %rcx
     1e3:      	movl	$0x4, %edx
     1e8:      	movl	$0x4, %eax
     1ed:      	movq	0x38(%rsp), %rdx
     1f2:      	addq	$0x58, %rdx
     1f6:      	movl	$0x4, %esi
     1fb:      	callq	*%rax
     1fd:      	movq	$0x0, (%rsp)
     205:      	leaq	0xb58(%r12), %rdx
     20d:      	movq	%rsp, %rdi
     210:      	movl	$0x8, %ecx
     215:      	movl	$0x4, %eax
     21a:      	movl	$0x8, %esi
     21f:      	callq	*%rax
     221:      	movq	(%rsp), %rcx
     225:      	testq	%rcx, %rcx
     228:      	je	0x2bb <generic_lsm_output+0x2bb>
     22e:      	movl	$0x0, 0xc(%rsp)
     236:      	addq	$0x4, %rcx
     23a:      	leaq	0xc(%rsp), %rdi
     23f:      	movl	$0x4, %eax
     244:      	movq	(%rsp), %rdx
     248:      	addq	$0x4, %rdx
     24c:      	movl	$0x4, %esi
     251:      	callq	*%rax
     253:      	movq	(%rsp), %rax
     257:      	movslq	0xc(%rsp), %rcx
     25c:      	shlq	$0x4, %rcx
     260:      	addq	%rax, %rcx
     263:      	addq	$0x80, %rcx
     26a:      	leaq	0x10(%rsp), %rdi
     26f:      	movl	$0x10, %edx
     274:      	movl	$0x4, %eax
     279:      	movq	(%rsp), %rcx
     27d:      	movslq	0xc(%rsp), %rdx
     282:      	shlq	$0x4, %rdx
     286:      	addq	%rcx, %rdx
     289:      	addq	$0x80, %rdx
     290:      	movl	$0x10, %esi
     295:      	callq	*%rax
     297:      	leaq	0x34(%r15), %rdi
     29b:      	movl	$0x158, %edx            # imm = 0x158
     2a0:      	movq	0x18(%rsp), %rcx
     2a5:      	addq	%rdx, %rcx
     2a8:      	movl	$0x4, %eax
     2ad:      	addq	0x18(%rsp), %rdx
     2b2:      	movl	$0x4, %esi
     2b7:      	callq	*%rax
     2b9:      	jmp	0x2c3 <generic_lsm_output+0x2c3>
     2bb:      	movl	$0x0, 0x34(%r15)
     2c3:      	leaq	0x38(%r15), %rdi
     2c7:      	movl	$0x158, %r13d           # imm = 0x158
     2cd:      	movq	0x40(%rsp), %rcx
     2d2:      	addq	%r13, %rcx
     2d5:      	movl	$0x4, %edx
     2da:      	movl	$0x4, %eax
     2df:      	movq	0x40(%rsp), %rdx
     2e4:      	addq	%r13, %rdx
     2e7:      	movl	$0x4, %esi
     2ec:      	callq	*%rax
     2ee:      	leaq	0x3c(%r15), %rdi
     2f2:      	movl	$0x118, %edx            # imm = 0x118
     2f7:      	movq	0x48(%rsp), %rcx
     2fc:      	addq	%rdx, %rcx
     2ff:      	movl	$0x4, %esi
     304:      	movl	$0x4, %eax
     309:      	addq	0x48(%rsp), %rdx
     30e:      	movl	$0x4, %esi
     313:      	callq	*%rax
     315:      	leaq	0x40(%r15), %rdi
     319:      	movl	$0x98, %ebp
     31e:      	movq	0x50(%rsp), %rcx
     323:      	addq	%rbp, %rcx
     326:      	movl	$0x4, %edx
     32b:      	movl	$0x4, %eax
     330:      	movq	0x50(%rsp), %rdx
     335:      	addq	%rbp, %rdx
     338:      	movl	$0x4, %esi
     33d:      	callq	*%rax
     33f:      	leaq	0x44(%r15), %rdi
     343:      	movq	0x58(%rsp), %rcx
     348:      	addq	%rbp, %rcx
     34b:      	movl	$0x4, %edx
     350:      	movl	$0x4, %eax
     355:      	addq	0x58(%rsp), %rbp
     35a:      	movl	$0x4, %esi
     35f:      	movq	%rbp, %rdx
     362:      	callq	*%rax
     364:      	leaq	0x48(%r15), %rdi
     368:      	movq	0x60(%rsp), %rcx
     36d:      	addq	$0x58, %rcx
     371:      	movl	$0x4, %edx
     376:      	movl	$0x4, %eax
     37b:      	movq	0x60(%rsp), %rdx
     380:      	addq	$0x58, %rdx
     384:      	movl	$0x4, %esi
     389:      	callq	*%rax
     38b:      	movq	$0x0, 0x10(%rsp)
     394:      	movq	$0x0, (%rsp)
     39c:      	addq	$0xd00, %r12            # imm = 0xD00
     3a3:      	leaq	0x10(%rsp), %rdi
     3a8:      	movl	$0x8, %ecx
     3ad:      	movl	$0x4, %eax
     3b2:      	movl	$0x8, %esi
     3b7:      	movq	%r12, %rdx
     3ba:      	callq	*%rax
     3bc:      	movl	$0x90, %edx
     3c1:      	movq	0x10(%rsp), %rcx
     3c6:      	addq	%rdx, %rcx
     3c9:      	movq	%rsp, %rdi
     3cc:      	movl	$0x8, %esi
     3d1:      	movl	$0x4, %eax
     3d6:      	addq	0x10(%rsp), %rdx
     3db:      	movl	$0x8, %esi
     3e0:      	callq	*%rax
     3e2:      	addq	$0x4c, %r15
     3e6:      	movq	(%rsp), %rcx
     3ea:      	addq	%r13, %rcx
     3ed:      	movl	$0x4, %edx
     3f2:      	movl	$0x4, %eax
     3f7:      	addq	(%rsp), %r13
     3fb:      	movq	%r15, %rdi
     3fe:      	movl	$0x4, %esi
     403:      	movq	%r13, %rdx
     406:      	callq	*%rax
     408:      	cmpq	$0x0, 0x5ef0(%r14)
     410:      	je	0x4c9 <generic_lsm_output+0x4c9>
     416:      	movl	$0xe, %eax
     41b:      	callq	*%rax
     41d:      	movq	%rax, %r15
     420:      	shrq	$0x20, %r15
     424:      	movl	$0x23, %eax
     429:      	callq	*%rax
     42b:      	movq	%rax, %r12
     42e:      	movl	%r15d, 0x20(%rsp)
     433:      	movq	(%rip), %rdi            # 0x43a <generic_lsm_output+0x43a>
     43a:      	leaq	0x20(%rsp), %rsi
     43f:      	movl	$0x1, %eax
     444:      	callq	*%rax
     446:      	testq	%rax, %rax
     449:      	je	0x4c9 <generic_lsm_output+0x4c9>
     44b:      	leaq	0x50(%rax), %r15
     44f:      	addq	$0xd00, %r12            # imm = 0xD00
     456:      	leaq	0x20(%rsp), %rdi
     45b:      	movl	$0x8, %ecx
     460:      	movq	%rax, %r13
     463:      	movl	$0x4, %eax
     468:      	movl	$0x8, %esi
     46d:      	movq	%r12, %rdx
     470:      	callq	*%rax
     472:      	movq	0x20(%rsp), %r12
     477:      	leaq	0x58(%r13), %rdi
     47b:      	leaq	0x40(%r12), %rdx
     480:      	movl	$0x8, %ecx
     485:      	movl	$0x4, %eax
     48a:      	movl	$0x8, %esi
     48f:      	callq	*%rax
     491:      	addq	$0x60, %r13
     495:      	leaq	0x30(%r12), %rdx
     49a:      	movl	$0x8, %ecx
     49f:      	movl	$0x4, %eax
     4a4:      	movq	%r13, %rdi
     4a7:      	movl	$0x8, %esi
     4ac:      	callq	*%rax
     4ae:      	addq	$0x38, %r12
     4b2:      	movl	$0x8, %ecx
     4b7:      	movl	$0x4, %eax
     4bc:      	movq	%r15, %rdi
     4bf:      	movl	$0x8, %esi
     4c4:      	movq	%r12, %rdx
     4c7:      	callq	*%rax
     4c9:      	movl	$0x90, %eax
     4ce:      	addl	0x4(%r14), %eax
     4d2:      	andl	$0x7fff, %eax           # imm = 0x7FFF
     4d7:      	cmpl	$0x2328, %eax           # imm = 0x2328
     4dc:      	movl	$0x2328, %r15d          # imm = 0x2328
     4e2:      	cmovbl	%eax, %r15d
     4e6:      	movl	$0x0, 0x10(%rsp)
     4ee:      	movq	(%rip), %rdi            # 0x4f5 <generic_lsm_output+0x4f5>
     4f5:      	leaq	0x10(%rsp), %rsi
     4fa:      	movl	$0x1, %eax
     4ff:      	callq	*%rax
     501:      	testq	%rax, %rax
     504:      	je	0x558 <generic_lsm_output+0x558>
     506:      	cmpb	$0x0, 0x28(%rax)
     50a:      	je	0x558 <generic_lsm_output+0x558>
     50c:      	movq	(%rip), %rsi            # 0x513 <generic_lsm_output+0x513>
     513:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     518:      	movl	$0x19, %eax
     51d:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     522:      	movq	%rbx, %rdi
     525:      	movq	%r14, %rcx
     528:      	movq	%r15, %r8
     52b:      	callq	*%rax
     52d:      	testq	%rax, %rax
     530:      	js	0x653 <generic_lsm_output+0x653>
     536:      	movl	$0x0, 0x20(%rsp)
     53e:      	movq	(%rip), %rdi            # 0x545 <generic_lsm_output+0x545>
     545:      	leaq	0x20(%rsp), %rsi
     54a:      	movl	$0x1, %eax
     54f:      	callq	*%rax
     551:      	testq	%rax, %rax
     554:      	jne	0x599 <generic_lsm_output+0x599>
     556:      	jmp	0x59e <generic_lsm_output+0x59e>
     558:      	movq	(%rip), %rdi            # 0x55f <generic_lsm_output+0x55f>
     55f:      	xorl	%ecx, %ecx
     561:      	movl	$0x82, %eax
     566:      	movq	%r14, %rsi
     569:      	movq	%r15, %rdx
     56c:      	xorl	%ecx, %ecx
     56e:      	callq	*%rax
     570:      	testq	%rax, %rax
     573:      	js	0x5fd <generic_lsm_output+0x5fd>
     579:      	movl	$0x0, 0x20(%rsp)
     581:      	movq	(%rip), %rdi            # 0x588 <generic_lsm_output+0x588>
     588:      	leaq	0x20(%rsp), %rsi
     58d:      	movl	$0x1, %eax
     592:      	callq	*%rax
     594:      	testq	%rax, %rax
     597:      	je	0x59e <generic_lsm_output+0x59e>
     599:      	lock
     59a:      	incq	0x8(%rax)
     59e:      	movl	$0xe, %eax
     5a3:      	callq	*%rax
     5a5:      	movq	%rax, 0x20(%rsp)
     5aa:      	movq	(%rip), %rdi            # 0x5b1 <generic_lsm_output+0x5b1>
     5b1:      	leaq	0x20(%rsp), %rsi
     5b6:      	movl	$0x1, %eax
     5bb:      	callq	*%rax
     5bd:      	testq	%rax, %rax
     5c0:      	je	0x5ec <generic_lsm_output+0x5ec>
     5c2:      	movq	%rax, %rbx
     5c5:      	movq	(%rip), %rdi            # 0x5cc <generic_lsm_output+0x5cc>
     5cc:      	leaq	0x20(%rsp), %rsi
     5d1:      	movl	$0x3, %eax
     5d6:      	callq	*%rax
     5d8:      	movl	(%rbx), %ecx
     5da:      	leal	-0x1(%rcx), %eax
     5dd:      	cmpl	$0xfffff000, %eax       # imm = 0xFFFFF000
     5e2:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     5e7:      	cmovael	%ecx, %eax
     5ea:      	jmp	0x5ee <generic_lsm_output+0x5ee>
     5ec:      	xorl	%eax, %eax
     5ee:      	addq	$0x78, %rsp
     5f2:      	popq	%rbx
     5f3:      	popq	%r12
     5f5:      	popq	%r13
     5f7:      	popq	%r14
     5f9:      	popq	%r15
     5fb:      	popq	%rbp
     5fc:      	retq
     5fd:      	movq	%rax, %rbx
     600:      	movl	$0x0, 0x20(%rsp)
     608:      	movq	(%rip), %rdi            # 0x60f <generic_lsm_output+0x60f>
     60f:      	leaq	0x20(%rsp), %rsi
     614:      	movl	$0x1, %eax
     619:      	callq	*%rax
     61b:      	testq	%rax, %rax
     61e:      	je	0x59e <generic_lsm_output+0x59e>
     624:      	cmpq	$-0xc, %rbx
     628:      	jg	0x69b <generic_lsm_output+0x69b>
     62a:      	cmpq	$-0x1c, %rbx
     62e:      	je	0x6dd <generic_lsm_output+0x6dd>
     634:      	cmpq	$-0x16, %rbx
     638:      	je	0x68c <generic_lsm_output+0x68c>
     63a:      	cmpq	$-0x10, %rbx
     63e:      	jne	0x6ce <generic_lsm_output+0x6ce>
     644:      	addq	$0x398, %rax            # imm = 0x398
     64a:      	lock
     64b:      	incq	(%rax)
     64e:      	jmp	0x59e <generic_lsm_output+0x59e>
     653:      	movq	%rax, %rbx
     656:      	movl	$0x0, 0x20(%rsp)
     65e:      	movq	(%rip), %rdi            # 0x665 <generic_lsm_output+0x665>
     665:      	leaq	0x20(%rsp), %rsi
     66a:      	movl	$0x1, %eax
     66f:      	callq	*%rax
     671:      	testq	%rax, %rax
     674:      	je	0x59e <generic_lsm_output+0x59e>
     67a:      	cmpq	$-0xc, %rbx
     67e:      	jg	0x6bc <generic_lsm_output+0x6bc>
     680:      	cmpq	$-0x1c, %rbx
     684:      	je	0x6dd <generic_lsm_output+0x6dd>
     686:      	cmpq	$-0x16, %rbx
     68a:      	jne	0x63a <generic_lsm_output+0x63a>
     68c:      	addq	$0x3a0, %rax            # imm = 0x3A0
     692:      	lock
     693:      	incq	(%rax)
     696:      	jmp	0x59e <generic_lsm_output+0x59e>
     69b:      	cmpq	$-0xb, %rbx
     69f:      	je	0x6ec <generic_lsm_output+0x6ec>
     6a1:      	cmpq	$-0x7, %rbx
     6a5:      	je	0x6fb <generic_lsm_output+0x6fb>
     6a7:      	cmpq	$-0x2, %rbx
     6ab:      	jne	0x6ce <generic_lsm_output+0x6ce>
     6ad:      	addq	$0x388, %rax            # imm = 0x388
     6b3:      	lock
     6b4:      	incq	(%rax)
     6b7:      	jmp	0x59e <generic_lsm_output+0x59e>
     6bc:      	cmpq	$-0xb, %rbx
     6c0:      	je	0x6ec <generic_lsm_output+0x6ec>
     6c2:      	cmpq	$-0x7, %rbx
     6c6:      	je	0x6fb <generic_lsm_output+0x6fb>
     6c8:      	cmpq	$-0x2, %rbx
     6cc:      	je	0x6ad <generic_lsm_output+0x6ad>
     6ce:      	addq	$0x380, %rax            # imm = 0x380
     6d4:      	lock
     6d5:      	incq	(%rax)
     6d8:      	jmp	0x59e <generic_lsm_output+0x59e>
     6dd:      	addq	$0x3a8, %rax            # imm = 0x3A8
     6e3:      	lock
     6e4:      	incq	(%rax)
     6e7:      	jmp	0x59e <generic_lsm_output+0x59e>
     6ec:      	addq	$0x3b0, %rax            # imm = 0x3B0
     6f2:      	lock
     6f3:      	incq	(%rax)
     6f6:      	jmp	0x59e <generic_lsm_output+0x59e>
     6fb:      	addq	$0x390, %rax            # imm = 0x390
     701:      	lock
     702:      	incq	(%rax)
     705:      	jmp	0x59e <generic_lsm_output+0x59e>
