
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/otel/custom_trace.native.o:	file format elf64-x86-64

Disassembly of section uprobe/custom__generic:

0000000000000000 <custom__generic>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xf8, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0xe, %eax
      19:      	callq	*%rax
      1b:      	movq	%rax, %r12
      1e:      	xorl	%eax, %eax
      20:      	testl	%r12d, %r12d
      23:      	je	0x9b3 <custom__generic+0x9b3>
      29:      	movq	%r12, %r15
      2c:      	shrq	$0x20, %r15
      30:      	testl	%r15d, %r15d
      33:      	je	0x9b3 <custom__generic+0x9b3>
      39:      	movl	$0x5, %eax
      3e:      	callq	*%rax
      40:      	movq	%rax, %r13
      43:      	movl	$0x0, 0xf4(%rsp)
      4e:      	movq	(%rip), %rdi            # 0x55 <custom__generic+0x55>
      55:      	leaq	0xf4(%rsp), %rsi
      5d:      	movl	$0x1, %eax
      62:      	callq	*%rax
      64:      	testq	%rax, %rax
      67:      	je	0x6e <custom__generic+0x6e>
      69:      	movq	(%rax), %rbp
      6c:      	jmp	0x70 <custom__generic+0x70>
      6e:      	xorl	%ebp, %ebp
      70:      	movl	$0x0, 0x10(%rsp)
      78:      	movq	(%rip), %rdi            # 0x7f <custom__generic+0x7f>
      7f:      	leaq	0x10(%rsp), %rsi
      84:      	movl	$0x1, %eax
      89:      	callq	*%rax
      8b:      	testq	%rax, %rax
      8e:      	je	0x96 <custom__generic+0x96>
      90:      	incb	0x1384(%rax)
      96:      	movq	(%rip), %rax            # 0x9d <custom__generic+0x9d>
      9d:      	cmpl	$0x0, (%rax)
      a0:      	jne	0x7ab <custom__generic+0x7ab>
      a6:      	movl	$0x0, 0x10(%rsp)
      ae:      	movq	(%rip), %rdi            # 0xb5 <custom__generic+0xb5>
      b5:      	leaq	0x10(%rsp), %rsi
      ba:      	movl	$0x1, %eax
      bf:      	callq	*%rax
      c1:      	movq	%rax, %r14
      c4:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
      c9:      	testq	%r14, %r14
      cc:      	je	0x9b3 <custom__generic+0x9b3>
      d2:      	movq	$0x0, 0xf00(%r14)
      dd:      	movb	$0x0, 0xf30(%r14)
      e5:      	movq	$0x0, 0xed0(%r14)
      f0:      	movq	$0x0, 0xed8(%r14)
      fb:      	movq	$0x0, 0xee0(%r14)
     106:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     10b:      	movq	%rax, 0xf28(%r14)
     112:      	movl	$0x0, 0x1380(%r14)
     11d:      	movw	$0x100, 0x1384(%r14)    # imm = 0x100
     127:      	movq	$0x0, 0xf38(%r14)
     132:      	movq	$0x0, 0xf40(%r14)
     13d:      	movq	$0x0, 0xf58(%r14)
     148:      	movq	$0x0, 0xf60(%r14)
     153:      	movq	$0x0, 0xf68(%r14)
     15e:      	movq	$0x0, 0xf70(%r14)
     169:      	movq	$0x0, 0xf78(%r14)
     174:      	movq	%rax, 0x2bc(%r14)
     17b:      	leaq	0x20(%r14), %rdi
     17f:      	movl	$0x29c, %edx            # imm = 0x29C
     184:      	xorl	%esi, %esi
     186:      	callq	0x18b <custom__generic+0x18b>
     18b:      	movl	$0x4, 0x2c4(%r14)
     196:      	movl	%r15d, (%r14)
     199:      	movl	%r12d, 0x4(%r14)
     19d:      	movq	%r13, 0x8(%r14)
     1a1:      	movq	%rbp, 0x2c8(%r14)
     1a8:      	leaq	0x10(%r14), %rdi
     1ac:      	movl	$0x10, %eax
     1b1:      	movl	$0x10, %ecx
     1b6:      	movl	$0x10, %esi
     1bb:      	callq	*%rcx
     1bd:      	testl	%eax, %eax
     1bf:      	movq	(%rip), %r13            # 0x1c6 <custom__generic+0x1c6>
     1c6:      	jns	0x1fe <custom__generic+0x1fe>
     1c8:      	movl	$0x34, 0xc0(%rsp)
     1d3:      	movq	(%rip), %rdi            # 0x1da <custom__generic+0x1da>
     1da:      	leaq	0xc0(%rsp), %rsi
     1e2:      	movl	$0x1, %eax
     1e7:      	callq	*%rax
     1e9:      	testq	%rax, %rax
     1ec:      	je	0x1f3 <custom__generic+0x1f3>
     1ee:      	incq	(%rax)
     1f1:      	jmp	0x1fe <custom__generic+0x1fe>
     1f3:      	cmpl	$0x0, (%r13)
     1f8:      	jne	0xc04 <custom__generic+0xc04>
     1fe:      	movq	(%rip), %rsi            # 0x205 <custom__generic+0x205>
     205:      	movl	$0x400, %eax            # imm = 0x400
     20a:      	movl	$0x1b, %ecx
     20f:      	movl	$0x400, %edx            # imm = 0x400
     214:      	movq	%rbx, %rdi
     217:      	callq	*%rcx
     219:      	movl	%eax, 0x2bc(%r14)
     220:      	cmpl	$0x0, (%r13)
     225:      	jne	0x7f5 <custom__generic+0x7f5>
     22b:      	cmpq	$0x2b, 0xa0(%rbx)
     233:      	jne	0x84f <custom__generic+0x84f>
     239:      	cmpq	$0x23, 0x88(%rbx)
     241:      	jne	0x24e <custom__generic+0x24e>
     243:      	movl	$0xfb1, %r12d           # imm = 0xFB1
     249:      	jmp	0x8e8 <custom__generic+0x8e8>
     24e:      	movq	0x80(%rbx), %rax
     255:      	movq	%rax, 0xed0(%r14)
     25c:      	movq	0x98(%rbx), %rax
     263:      	movq	%rax, 0xed8(%r14)
     26a:      	movq	0x20(%rbx), %rax
     26e:      	movq	%rax, 0xee0(%r14)
     275:      	movq	0x50(%rbx), %rax
     279:      	movq	%rax, 0xee8(%r14)
     280:      	movq	0x40(%rbx), %rax
     284:      	movq	%rax, 0xef0(%r14)
     28b:      	movq	0x30(%rbx), %rax
     28f:      	movq	%rax, 0xef8(%r14)
     296:      	movq	0x10(%rbx), %rax
     29a:      	movq	%rax, 0xf00(%r14)
     2a1:      	movq	(%rbx), %rax
     2a4:      	movq	%rax, 0xf08(%r14)
     2ab:      	movb	$0x0, 0xf30(%r14)
     2b3:      	cmpl	$0x0, (%r13)
     2b8:      	jne	0xa65 <custom__generic+0xa65>
     2be:      	movl	$0x60, 0x10(%rsp)
     2c6:      	movbel	%r15d, 0x14(%rsp)
     2cd:      	movq	$0x0, 0x18(%rsp)
     2d6:      	movq	(%rip), %rdi            # 0x2dd <custom__generic+0x2dd>
     2dd:      	leaq	0x10(%rsp), %rsi
     2e2:      	movl	$0x1, %eax
     2e7:      	callq	*%rax
     2e9:      	testq	%rax, %rax
     2ec:      	je	0x33d <custom__generic+0x33d>
     2ee:      	movq	%r14, %rax
     2f1:      	addq	$0xed0, %rax            # imm = 0xED0
     2f7:      	movq	(%rax), %r12
     2fa:      	movl	(%r13), %eax
     2fe:      	testq	%r12, %r12
     301:      	je	0x401 <custom__generic+0x401>
     307:      	testl	%eax, %eax
     309:      	jne	0xc82 <custom__generic+0xc82>
     30f:      	movq	%r12, %rax
     312:      	shrq	$0x38, %rax
     316:      	je	0xd14 <custom__generic+0xd14>
     31c:      	cmpl	$0x0, (%r13)
     321:      	jne	0x1024 <custom__generic+0x1024>
     327:      	movl	$0xb, 0xf28(%r14)
     332:      	movl	$0xfab, %r12d           # imm = 0xFAB
     338:      	jmp	0x8e8 <custom__generic+0x8e8>
     33d:      	movq	%r12, 0xb8(%rsp)
     345:      	movl	%r15d, 0x4(%rsp)
     34a:      	movq	(%rip), %rdi            # 0x351 <custom__generic+0x351>
     351:      	leaq	0x4(%rsp), %rsi
     356:      	movl	$0x1, %eax
     35b:      	callq	*%rax
     35d:      	movq	%rax, %r14
     360:      	movl	$0x5, %eax
     365:      	callq	*%rax
     367:      	testq	%r14, %r14
     36a:      	je	0x41f <custom__generic+0x41f>
     370:      	movq	(%r14), %rcx
     373:      	movq	%rcx, %rsi
     376:      	andq	$-0x20, %rsi
     37a:      	movq	%rax, %rdx
     37d:      	subq	%rsi, %rdx
     380:      	movl	%ecx, %esi
     382:      	andb	$0xf, %sil
     386:      	movl	$0x5f5e100, %edi        # imm = 0x5F5E100
     38b:      	shlxq	%rsi, %rdi, %rsi
     390:      	cmpq	%rsi, %rdx
     393:      	jae	0x423 <custom__generic+0x423>
     399:      	cmpl	$0x0, (%r13)
     39e:      	je	0x7a4 <custom__generic+0x7a4>
     3a4:      	movabsq	$0xa74736166206f, %rax  # imm = 0xA74736166206F
     3ae:      	movq	%rax, 0x28(%rsp)
     3b3:      	movabsq	$0x6f74203a64657469, %rax # imm = 0x6F74203A64657469
     3bd:      	movq	%rax, 0x20(%rsp)
     3c2:      	movabsq	$0x6d696c20746e6576, %rax # imm = 0x6D696C20746E6576
     3cc:      	movq	%rax, 0x18(%rsp)
     3d1:      	movabsq	$0x6520642520444950, %rax # imm = 0x6520642520444950
     3db:      	movq	%rax, 0x10(%rsp)
     3e0:      	leaq	0x10(%rsp), %rdi
     3e5:      	movl	$0x20, %eax
     3ea:      	movl	$0x6, %ecx
     3ef:      	movl	0x4(%rsp), %edx
     3f3:      	movl	$0x20, %esi
     3f8:      	xorl	%eax, %eax
     3fa:      	callq	*%rcx
     3fc:      	jmp	0x7a4 <custom__generic+0x7a4>
     401:      	testl	%eax, %eax
     403:      	jne	0xfa8 <custom__generic+0xfa8>
     409:      	movl	$0x1, 0xf28(%r14)
     414:      	movl	$0xfad, %r12d           # imm = 0xFAD
     41a:      	jmp	0x8e8 <custom__generic+0x8e8>
     41f:      	xorl	%ebp, %ebp
     421:      	jmp	0x456 <custom__generic+0x456>
     423:      	movl	%ecx, %ebp
     425:      	andb	$0x10, %bpl
     429:      	movl	$0xffffffff, %edi       # imm = 0xFFFFFFFF
     42e:      	addq	%rdi, %rsi
     431:      	addq	$0x2a05f201, %rsi       # imm = 0x2A05F201
     438:      	cmpq	%rsi, %rdx
     43b:      	jae	0x456 <custom__generic+0x456>
     43d:      	andl	$0xf, %ecx
     440:      	xorl	%edx, %edx
     442:      	testb	%bpl, %bpl
     445:      	sete	%dl
     448:      	leal	0x4(,%rdx,4), %edx
     44f:      	cmpl	%edx, %ecx
     451:      	adcb	$0x0, %cl
     454:      	jmp	0x458 <custom__generic+0x458>
     456:      	xorl	%ecx, %ecx
     458:      	cmpl	$0x0, (%r13)
     45d:      	movzbl	%cl, %r14d
     461:      	jne	0xf40 <custom__generic+0xf40>
     467:      	andq	$-0x20, %rax
     46b:      	movzbl	%bpl, %ecx
     46f:      	orq	%rax, %rcx
     472:      	orq	%rcx, %r14
     475:      	movq	%r14, 0xc0(%rsp)
     47d:      	movq	(%rip), %rdi            # 0x484 <custom__generic+0x484>
     484:      	xorl	%eax, %eax
     486:      	leaq	0x4(%rsp), %rsi
     48b:      	leaq	0xc0(%rsp), %rdx
     493:      	movl	$0x2, %r8d
     499:      	xorl	%ecx, %ecx
     49b:      	callq	*%r8
     49e:      	testl	%eax, %eax
     4a0:      	je	0x4d7 <custom__generic+0x4d7>
     4a2:      	cmpl	$0x0, (%r13)
     4a7:      	jne	0x1087 <custom__generic+0x1087>
     4ad:      	movl	$0x3d, 0xc(%rsp)
     4b5:      	movq	(%rip), %rdi            # 0x4bc <custom__generic+0x4bc>
     4bc:      	leaq	0xc(%rsp), %rsi
     4c1:      	movl	$0x1, %eax
     4c6:      	callq	*%rax
     4c8:      	testq	%rax, %rax
     4cb:      	je	0x542 <custom__generic+0x542>
     4cd:      	incq	(%rax)
     4d0:      	xorl	%eax, %eax
     4d2:      	jmp	0x9b3 <custom__generic+0x9b3>
     4d7:      	movb	$0x1, 0xb(%rsp)
     4dc:      	movq	(%rip), %rdi            # 0x4e3 <custom__generic+0x4e3>
     4e3:      	xorl	%eax, %eax
     4e5:      	leaq	0xb8(%rsp), %rsi
     4ed:      	leaq	0xb(%rsp), %rdx
     4f2:      	movl	$0x2, %r8d
     4f8:      	xorl	%ecx, %ecx
     4fa:      	callq	*%r8
     4fd:      	testl	%eax, %eax
     4ff:      	je	0x5c8 <custom__generic+0x5c8>
     505:      	cmpl	$0x0, (%r13)
     50a:      	jne	0x1259 <custom__generic+0x1259>
     510:      	movl	$0x3e, 0xc0(%rsp)
     51b:      	movq	(%rip), %rdi            # 0x522 <custom__generic+0x522>
     522:      	leaq	0xc0(%rsp), %rsi
     52a:      	movl	$0x1, %eax
     52f:      	callq	*%rax
     531:      	testq	%rax, %rax
     534:      	je	0x633 <custom__generic+0x633>
     53a:      	incq	(%rax)
     53d:      	jmp	0x7a4 <custom__generic+0x7a4>
     542:      	cmpl	$0x0, (%r13)
     547:      	je	0x7a4 <custom__generic+0x7a4>
     54d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     557:      	movq	%rax, 0x36(%rsp)
     55c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     566:      	movq	%rax, 0x30(%rsp)
     56b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     575:      	movq	%rax, 0x28(%rsp)
     57a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     584:      	movq	%rax, 0x20(%rsp)
     589:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     593:      	movq	%rax, 0x18(%rsp)
     598:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     5a2:      	movq	%rax, 0x10(%rsp)
     5a7:      	leaq	0x10(%rsp), %rdi
     5ac:      	movl	$0x2e, %eax
     5b1:      	movl	$0x6, %ecx
     5b6:      	movl	0xc(%rsp), %edx
     5ba:      	movl	$0x2e, %esi
     5bf:      	xorl	%eax, %eax
     5c1:      	callq	*%rcx
     5c3:      	jmp	0x7a4 <custom__generic+0x7a4>
     5c8:      	movl	$0x1, 0xc(%rsp)
     5d0:      	movb	$0x1, 0x4(%rsp)
     5d5:      	movq	(%rip), %rdi            # 0x5dc <custom__generic+0x5dc>
     5dc:      	leaq	0xc(%rsp), %rsi
     5e1:      	leaq	0x4(%rsp), %rdx
     5e6:      	movl	$0x1, %eax
     5eb:      	movl	$0x2, %r8d
     5f1:      	movl	$0x1, %ecx
     5f6:      	callq	*%r8
     5f9:      	testl	%eax, %eax
     5fb:      	js	0x6be <custom__generic+0x6be>
     601:      	movl	$0x42, 0xc0(%rsp)
     60c:      	movq	(%rip), %rdi            # 0x613 <custom__generic+0x613>
     613:      	leaq	0xc0(%rsp), %rsi
     61b:      	movl	$0x1, %eax
     620:      	callq	*%rax
     622:      	testq	%rax, %rax
     625:      	je	0x71a <custom__generic+0x71a>
     62b:      	incq	(%rax)
     62e:      	jmp	0x725 <custom__generic+0x725>
     633:      	cmpl	$0x0, (%r13)
     638:      	je	0x7a4 <custom__generic+0x7a4>
     63e:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     648:      	movq	%rax, 0x36(%rsp)
     64d:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     657:      	movq	%rax, 0x30(%rsp)
     65c:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     666:      	movq	%rax, 0x28(%rsp)
     66b:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     675:      	movq	%rax, 0x20(%rsp)
     67a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     684:      	movq	%rax, 0x18(%rsp)
     689:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     693:      	movq	%rax, 0x10(%rsp)
     698:      	leaq	0x10(%rsp), %rdi
     69d:      	movl	$0x2e, %eax
     6a2:      	movl	$0x6, %ecx
     6a7:      	movl	0xc0(%rsp), %edx
     6ae:      	movl	$0x2e, %esi
     6b3:      	xorl	%eax, %eax
     6b5:      	callq	*%rcx
     6b7:      	xorl	%eax, %eax
     6b9:      	jmp	0x9b3 <custom__generic+0x9b3>
     6be:      	cmpl	$0x0, (%r13)
     6c3:      	je	0x76f <custom__generic+0x76f>
     6c9:      	movabsq	$0xa64657469626968, %rax # imm = 0xA64657469626968
     6d3:      	movq	%rax, 0x20(%rsp)
     6d8:      	movabsq	$0x6e69206425206570, %rax # imm = 0x6E69206425206570
     6e2:      	movq	%rax, 0x18(%rsp)
     6e7:      	movabsq	$0x797420746e657645, %rax # imm = 0x797420746E657645
     6f1:      	movq	%rax, 0x10(%rsp)
     6f6:      	movb	$0x0, 0x28(%rsp)
     6fb:      	leaq	0x10(%rsp), %rdi
     700:      	movl	$0x19, %eax
     705:      	movl	$0x6, %ecx
     70a:      	movl	$0x19, %esi
     70f:      	movl	$0x1, %edx
     714:      	xorl	%eax, %eax
     716:      	callq	*%rcx
     718:      	jmp	0x76f <custom__generic+0x76f>
     71a:      	cmpl	$0x0, (%r13)
     71f:      	jne	0x1489 <custom__generic+0x1489>
     725:      	movl	$0x1, 0xc0(%rsp)
     730:      	movq	(%rip), %rsi            # 0x737 <custom__generic+0x737>
     737:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     73c:      	leaq	0xc0(%rsp), %rcx
     744:      	movl	$0x4, %edx
     749:      	movl	$0x19, %r9d
     74f:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     754:      	movq	%rbx, %rdi
     757:      	movl	$0x4, %r8d
     75d:      	callq	*%r9
     760:      	testl	%eax, %eax
     762:      	jns	0x76f <custom__generic+0x76f>
     764:      	cmpl	$0x0, (%r13)
     769:      	jne	0x13fa <custom__generic+0x13fa>
     76f:      	movl	$0x3f, 0xc0(%rsp)
     77a:      	movq	(%rip), %rdi            # 0x781 <custom__generic+0x781>
     781:      	leaq	0xc0(%rsp), %rsi
     789:      	movl	$0x1, %eax
     78e:      	callq	*%rax
     790:      	testq	%rax, %rax
     793:      	jne	0x4cd <custom__generic+0x4cd>
     799:      	cmpl	$0x0, (%r13)
     79e:      	jne	0x137c <custom__generic+0x137c>
     7a4:      	xorl	%eax, %eax
     7a6:      	jmp	0x9b3 <custom__generic+0x9b3>
     7ab:      	movabsq	$0xa64726f636572, %rax  # imm = 0xA64726F636572
     7b5:      	movq	%rax, 0x1e(%rsp)
     7ba:      	movabsq	$0x6572205550432067, %rax # imm = 0x6572205550432067
     7c4:      	movq	%rax, 0x18(%rsp)
     7c9:      	movabsq	$0x6e69747465736552, %rax # imm = 0x6E69747465736552
     7d3:      	movq	%rax, 0x10(%rsp)
     7d8:      	leaq	0x10(%rsp), %rdi
     7dd:      	movl	$0x16, %eax
     7e2:      	movl	$0x6, %ecx
     7e7:      	movl	$0x16, %esi
     7ec:      	xorl	%eax, %eax
     7ee:      	callq	*%rcx
     7f0:      	jmp	0xa6 <custom__generic+0xa6>
     7f5:      	movabsq	$0xa6425203d2064, %rax  # imm = 0xA6425203D2064
     7ff:      	movq	%rax, 0x1e(%rsp)
     804:      	movabsq	$0x206469206b636174, %rax # imm = 0x206469206B636174
     80e:      	movq	%rax, 0x18(%rsp)
     813:      	movabsq	$0x73206c656e72656b, %rax # imm = 0x73206C656E72656B
     81d:      	movq	%rax, 0x10(%rsp)
     822:      	leaq	0x10(%rsp), %rdi
     827:      	movl	$0x16, %eax
     82c:      	movl	$0x6, %ecx
     831:      	movl	0x2bc(%r14), %edx
     838:      	movl	$0x16, %esi
     83d:      	xorl	%eax, %eax
     83f:      	callq	*%rcx
     841:      	cmpq	$0x2b, 0xa0(%rbx)
     849:      	je	0x239 <custom__generic+0x239>
     84f:      	movl	$0x23, %eax
     854:      	callq	*%rax
     856:      	movq	(%rip), %rcx            # 0x85d <custom__generic+0x85d>
     85d:      	movl	(%rcx), %edx
     85f:      	addq	%rax, %rdx
     862:      	leaq	0x10(%rsp), %rdi
     867:      	movl	$0x8, %eax
     86c:      	movl	$0x71, %ecx
     871:      	movl	$0x8, %esi
     876:      	callq	*%rcx
     878:      	testq	%rax, %rax
     87b:      	jne	0x8ac <custom__generic+0x8ac>
     87d:      	movq	(%rip), %rax            # 0x884 <custom__generic+0x884>
     884:      	movl	(%rax), %edx
     886:      	addq	0x10(%rsp), %rdx
     88b:      	je	0x8ac <custom__generic+0x8ac>
     88d:      	leaq	0x10(%rsp), %rdi
     892:      	movl	$0xa8, %eax
     897:      	movl	$0x71, %ecx
     89c:      	movl	$0xa8, %esi
     8a1:      	callq	*%rcx
     8a3:      	testq	%rax, %rax
     8a6:      	je	0x9c5 <custom__generic+0x9c5>
     8ac:      	movl	$0x52, 0xb8(%rsp)
     8b7:      	movq	(%rip), %rdi            # 0x8be <custom__generic+0x8be>
     8be:      	leaq	0xb8(%rsp), %rsi
     8c6:      	movl	$0x1, %eax
     8cb:      	callq	*%rax
     8cd:      	testq	%rax, %rax
     8d0:      	je	0x8d7 <custom__generic+0x8d7>
     8d2:      	incq	(%rax)
     8d5:      	jmp	0x8e2 <custom__generic+0x8e2>
     8d7:      	cmpl	$0x0, (%r13)
     8dc:      	jne	0xb71 <custom__generic+0xb71>
     8e2:      	movl	$0xfa9, %r12d           # imm = 0xFA9
     8e8:      	xorl	%r15d, %r15d
     8eb:      	movl	%r12d, 0xf2c(%r14)
     8f2:      	movl	$0x0, 0x10(%rsp)
     8fa:      	movq	(%rip), %rdi            # 0x901 <custom__generic+0x901>
     901:      	leaq	0x10(%rsp), %rsi
     906:      	movl	$0x1, %eax
     90b:      	callq	*%rax
     90d:      	testq	%rax, %rax
     910:      	je	0x959 <custom__generic+0x959>
     912:      	movzbl	0x1384(%rax), %ecx
     919:      	movl	%r15d, %edx
     91c:      	cmpb	$0x1d, %cl
     91f:      	jb	0x981 <custom__generic+0x981>
     921:      	movq	%rax, %r14
     924:      	movl	$0x5, 0xf2c(%rax)
     92e:      	movl	$0x44, 0xc0(%rsp)
     939:      	movq	(%rip), %rdi            # 0x940 <custom__generic+0x940>
     940:      	leaq	0xc0(%rsp), %rsi
     948:      	movl	$0x1, %eax
     94d:      	callq	*%rax
     94f:      	testq	%rax, %rax
     952:      	je	0x969 <custom__generic+0x969>
     954:      	incq	(%rax)
     957:      	jmp	0x974 <custom__generic+0x974>
     959:      	movq	(%rip), %rcx            # 0x960 <custom__generic+0x960>
     960:      	xorl	%edx, %edx
     962:      	movl	$0xc, %eax
     967:      	jmp	0x997 <custom__generic+0x997>
     969:      	cmpl	$0x0, (%r13)
     96e:      	jne	0xec2 <custom__generic+0xec2>
     974:      	movq	%r14, %rax
     977:      	movzbl	0x1384(%r14), %ecx
     97f:      	xorl	%edx, %edx
     981:      	incb	%cl
     983:      	movb	%cl, 0x1384(%rax)
     989:      	movl	%edx, %ecx
     98b:      	movq	(%rip), %rsi            # 0x992 <custom__generic+0x992>
     992:      	movl	$0xc, %eax
     997:      	movq	(%rip), %rsi            # 0x99e <custom__generic+0x99e>
     99e:      	movq	%rbx, %rdi
     9a1:      	callq	*%rax
     9a3:      	cmpl	$0x0, (%r13)
     9a8:      	jne	0xaef <custom__generic+0xaef>
     9ae:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     9b3:      	addq	$0xf8, %rsp
     9ba:      	popq	%rbx
     9bb:      	popq	%r12
     9bd:      	popq	%r13
     9bf:      	popq	%r14
     9c1:      	popq	%r15
     9c3:      	popq	%rbp
     9c4:      	retq
     9c5:      	cmpq	$0x2b, 0xb0(%rsp)
     9ce:      	jne	0xae4 <custom__generic+0xae4>
     9d4:      	cmpq	$0x23, 0x98(%rsp)
     9dd:      	je	0x243 <custom__generic+0x243>
     9e3:      	movq	0x90(%rsp), %rax
     9eb:      	movq	%rax, 0xed0(%r14)
     9f2:      	movq	0xa8(%rsp), %rax
     9fa:      	movq	%rax, 0xed8(%r14)
     a01:      	movq	0x30(%rsp), %rax
     a06:      	movq	%rax, 0xee0(%r14)
     a0d:      	movq	0x60(%rsp), %rax
     a12:      	movq	%rax, 0xee8(%r14)
     a19:      	movq	0x50(%rsp), %rax
     a1e:      	movq	%rax, 0xef0(%r14)
     a25:      	movq	0x40(%rsp), %rax
     a2a:      	movq	%rax, 0xef8(%r14)
     a31:      	movq	0x20(%rsp), %rax
     a36:      	movq	%rax, 0xf00(%r14)
     a3d:      	movq	0x10(%rsp), %rax
     a42:      	movq	%rax, 0xf08(%r14)
     a49:      	cmpq	$-0x1, 0x88(%rsp)
     a52:      	setne	0xf30(%r14)
     a5a:      	cmpl	$0x0, (%r13)
     a5f:      	je	0x2be <custom__generic+0x2be>
     a65:      	movabsq	$0xa786c6c25203a, %rax  # imm = 0xA786C6C25203A
     a6f:      	movq	%rax, 0x2f(%rsp)
     a74:      	movabsq	$0x3a706620786c6c25, %rax # imm = 0x3A706620786C6C25
     a7e:      	movq	%rax, 0x28(%rsp)
     a83:      	movabsq	$0x203a707320786c6c, %rax # imm = 0x203A707320786C6C
     a8d:      	movq	%rax, 0x20(%rsp)
     a92:      	movabsq	$0x25203a6370203a73, %rax # imm = 0x25203A6370203A73
     a9c:      	movq	%rax, 0x18(%rsp)
     aa1:      	movabsq	$0x6765722064616552, %rax # imm = 0x6765722064616552
     aab:      	movq	%rax, 0x10(%rsp)
     ab0:      	leaq	0x10(%rsp), %rdi
     ab5:      	movl	$0x27, %eax
     aba:      	movl	$0x6, %r9d
     ac0:      	movq	0xed0(%r14), %rdx
     ac7:      	movq	0xed8(%r14), %rcx
     ace:      	movq	0xee0(%r14), %r8
     ad5:      	movl	$0x27, %esi
     ada:      	xorl	%eax, %eax
     adc:      	callq	*%r9
     adf:      	jmp	0x2be <custom__generic+0x2be>
     ae4:      	xorl	%r15d, %r15d
     ae7:      	xorl	%r12d, %r12d
     aea:      	jmp	0x8eb <custom__generic+0x8eb>
     aef:      	movabsq	$0x746e655f72656361, %rax # imm = 0x746E655F72656361
     af9:      	movq	%rax, 0x38(%rsp)
     afe:      	movabsq	$0x72745f6576697461, %rax # imm = 0x72745F6576697461
     b08:      	movq	%rax, 0x30(%rsp)
     b0d:      	movabsq	$0x6e206e6920642520, %rax # imm = 0x6E206E6920642520
     b17:      	movq	%rax, 0x28(%rsp)
     b1c:      	movabsq	$0x726f662064656c69, %rax # imm = 0x726F662064656C69
     b26:      	movq	%rax, 0x20(%rsp)
     b2b:      	movabsq	$0x6166206c6c616320, %rax # imm = 0x6166206C6C616320
     b35:      	movq	%rax, 0x18(%rsp)
     b3a:      	movabsq	$0x6c6961745f667062, %rax # imm = 0x6C6961745F667062
     b44:      	movq	%rax, 0x10(%rsp)
     b49:      	movl	$0xa7972, 0x40(%rsp)    # imm = 0xA7972
     b51:      	leaq	0x10(%rsp), %rdi
     b56:      	movl	$0x34, %eax
     b5b:      	movl	$0x6, %ecx
     b60:      	movl	$0x34, %esi
     b65:      	movl	%r15d, %edx
     b68:      	xorl	%eax, %eax
     b6a:      	callq	*%rcx
     b6c:      	jmp	0x9ae <custom__generic+0x9ae>
     b71:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     b7b:      	movq	%rax, 0xe6(%rsp)
     b83:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     b8d:      	movq	%rax, 0xe0(%rsp)
     b95:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     b9f:      	movq	%rax, 0xd8(%rsp)
     ba7:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     bb1:      	movq	%rax, 0xd0(%rsp)
     bb9:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     bc3:      	movq	%rax, 0xc8(%rsp)
     bcb:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     bd5:      	movq	%rax, 0xc0(%rsp)
     bdd:      	leaq	0xc0(%rsp), %rdi
     be5:      	movl	$0x2e, %eax
     bea:      	movl	$0x6, %ecx
     bef:      	movl	0xb8(%rsp), %edx
     bf6:      	movl	$0x2e, %esi
     bfb:      	xorl	%eax, %eax
     bfd:      	callq	*%rcx
     bff:      	jmp	0x8e2 <custom__generic+0x8e2>
     c04:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     c0e:      	movq	%rax, 0x36(%rsp)
     c13:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     c1d:      	movq	%rax, 0x30(%rsp)
     c22:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     c2c:      	movq	%rax, 0x28(%rsp)
     c31:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     c3b:      	movq	%rax, 0x20(%rsp)
     c40:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     c4a:      	movq	%rax, 0x18(%rsp)
     c4f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     c59:      	movq	%rax, 0x10(%rsp)
     c5e:      	leaq	0x10(%rsp), %rdi
     c63:      	movl	$0x2e, %eax
     c68:      	movl	$0x6, %ecx
     c6d:      	movl	0xc0(%rsp), %edx
     c74:      	movl	$0x2e, %esi
     c79:      	xorl	%eax, %eax
     c7b:      	callq	*%rcx
     c7d:      	jmp	0x1fe <custom__generic+0x1fe>
     c82:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
     c8c:      	movq	%rax, 0x38(%rsp)
     c91:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
     c9b:      	movq	%rax, 0x30(%rsp)
     ca0:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
     caa:      	movq	%rax, 0x28(%rsp)
     caf:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
     cb9:      	movq	%rax, 0x20(%rsp)
     cbe:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
     cc8:      	movq	%rax, 0x18(%rsp)
     ccd:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
     cd7:      	movq	%rax, 0x10(%rsp)
     cdc:      	movb	$0x0, 0x40(%rsp)
     ce1:      	leaq	0x10(%rsp), %rdi
     ce6:      	movl	$0x31, %eax
     ceb:      	movl	$0x6, %ecx
     cf0:      	movl	0x2c0(%r14), %edx
     cf7:      	movl	$0x31, %esi
     cfc:      	xorl	%eax, %eax
     cfe:      	callq	*%rcx
     d00:      	movq	0xed0(%r14), %r12
     d07:      	movq	%r12, %rax
     d0a:      	shrq	$0x38, %rax
     d0e:      	jne	0x31c <custom__generic+0x31c>
     d14:      	cmpq	$0xfff, %r12            # imm = 0xFFF
     d1b:      	ja	0xd3e <custom__generic+0xd3e>
     d1d:      	cmpl	$0x0, (%r13)
     d22:      	jne	0x10e8 <custom__generic+0x10e8>
     d28:      	movl	$0x31, 0xf28(%r14)
     d33:      	movl	$0xfae, %r12d           # imm = 0xFAE
     d39:      	jmp	0x8e8 <custom__generic+0x8e8>
     d3e:      	movl	(%r14), %eax
     d41:      	movl	$0x60, 0xc0(%rsp)
     d4c:      	movbel	%eax, 0xc4(%rsp)
     d55:      	movbeq	%r12, 0xc8(%rsp)
     d5f:      	movq	(%rip), %rdi            # 0xd66 <custom__generic+0xd66>
     d66:      	leaq	0xc0(%rsp), %rsi
     d6e:      	movl	$0x1, %eax
     d73:      	callq	*%rax
     d75:      	testq	%rax, %rax
     d78:      	je	0xe1f <custom__generic+0xe1f>
     d7e:      	movabsq	$0xffffffffffffff, %rcx # imm = 0xFFFFFFFFFFFFFF
     d88:      	movq	0x8(%rax), %r15
     d8c:      	andq	%r15, %rcx
     d8f:      	movq	%rcx, 0xf20(%r14)
     d96:      	movq	(%rax), %rax
     d99:      	movq	%rax, 0xf10(%r14)
     da0:      	shrq	$0x38, %r15
     da4:      	movq	%r12, %rax
     da7:      	subq	%rcx, %rax
     daa:      	movq	%rax, 0xf18(%r14)
     db1:      	cmpl	$0x0, (%r13)
     db6:      	jne	0x1144 <custom__generic+0x1144>
     dbc:      	xorl	%r12d, %r12d
     dbf:      	cmpl	$0x1, %r15d
     dc3:      	jne	0xe13 <custom__generic+0xe13>
     dc5:      	movq	0xf10(%r14), %rax
     dcc:      	movq	%rax, 0xc0(%rsp)
     dd4:      	movq	0xf18(%r14), %r13
     ddb:      	movq	(%rip), %rdi            # 0xde2 <custom__generic+0xde2>
     de2:      	leaq	0xc0(%rsp), %rsi
     dea:      	movl	$0x1, %eax
     def:      	callq	*%rax
     df1:      	movl	$0x1, %r15d
     df7:      	testq	%rax, %rax
     dfa:      	je	0xe13 <custom__generic+0xe13>
     dfc:      	cmpq	%r13, (%rax)
     dff:      	ja	0xe07 <custom__generic+0xe07>
     e01:      	cmpq	%r13, 0x8(%rax)
     e05:      	jae	0xe40 <custom__generic+0xe40>
     e07:      	cmpq	%r13, 0x10(%rax)
     e0b:      	ja	0xe13 <custom__generic+0xe13>
     e0d:      	cmpq	%r13, 0x18(%rax)
     e11:      	jae	0xe40 <custom__generic+0xe40>
     e13:      	movq	(%rip), %r13            # 0xe1a <custom__generic+0xe1a>
     e1a:      	jmp	0x8eb <custom__generic+0x8eb>
     e1f:      	cmpl	$0x0, (%r13)
     e24:      	jne	0x12ee <custom__generic+0x12ee>
     e2a:      	movl	$0xc, 0xf28(%r14)
     e35:      	movl	$0xfac, %r12d           # imm = 0xFAC
     e3b:      	jmp	0x8e8 <custom__generic+0x8e8>
     e40:      	movq	(%rip), %r13            # 0xe47 <custom__generic+0xe47>
     e47:      	cmpl	$0x0, (%r13)
     e4c:      	jne	0x1507 <custom__generic+0x1507>
     e52:      	movl	0x1380(%r14), %ecx
     e59:      	movl	0x20(%rax), %edx
     e5c:      	btl	%edx, %ecx
     e5f:      	jae	0x1581 <custom__generic+0x1581>
     e65:      	cmpl	$0x0, (%r13)
     e6a:      	je	0x8eb <custom__generic+0x8eb>
     e70:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
     e7a:      	movq	%rax, 0x20(%rsp)
     e7f:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
     e89:      	movq	%rax, 0x18(%rsp)
     e8e:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
     e98:      	movq	%rax, 0x10(%rsp)
     e9d:      	movl	$0xa656e, 0x27(%rsp)    # imm = 0xA656E
     ea5:      	leaq	0x10(%rsp), %rdi
     eaa:      	movl	$0x1b, %eax
     eaf:      	movl	$0x6, %ecx
     eb4:      	movl	$0x1b, %esi
     eb9:      	xorl	%eax, %eax
     ebb:      	callq	*%rcx
     ebd:      	jmp	0x8eb <custom__generic+0x8eb>
     ec2:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     ecc:      	movq	%rax, 0x36(%rsp)
     ed1:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     edb:      	movq	%rax, 0x30(%rsp)
     ee0:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     eea:      	movq	%rax, 0x28(%rsp)
     eef:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     ef9:      	movq	%rax, 0x20(%rsp)
     efe:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     f08:      	movq	%rax, 0x18(%rsp)
     f0d:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     f17:      	movq	%rax, 0x10(%rsp)
     f1c:      	leaq	0x10(%rsp), %rdi
     f21:      	movl	$0x2e, %eax
     f26:      	movl	$0x6, %ecx
     f2b:      	movl	0xc0(%rsp), %edx
     f32:      	movl	$0x2e, %esi
     f37:      	xorl	%eax, %eax
     f39:      	callq	*%rcx
     f3b:      	jmp	0x974 <custom__generic+0x974>
     f40:      	movabsq	$0xa64253d74706d, %rcx  # imm = 0xA64253D74706D
     f4a:      	movq	%rcx, 0x27(%rsp)
     f4f:      	movabsq	$0x6d65747461202c64, %rcx # imm = 0x6D65747461202C64
     f59:      	movq	%rcx, 0x20(%rsp)
     f5e:      	movabsq	$0x6e657320746e6576, %rcx # imm = 0x6E657320746E6576
     f68:      	movq	%rcx, 0x18(%rsp)
     f6d:      	movabsq	$0x6520642520444950, %rcx # imm = 0x6520642520444950
     f77:      	movq	%rcx, 0x10(%rsp)
     f7c:      	leaq	0x10(%rsp), %rdi
     f81:      	movl	$0x1f, %ecx
     f86:      	movl	$0x6, %r8d
     f8c:      	movl	0x4(%rsp), %edx
     f90:      	movl	$0x1f, %esi
     f95:      	movl	%r14d, %ecx
     f98:      	movq	%rax, %r12
     f9b:      	xorl	%eax, %eax
     f9d:      	callq	*%r8
     fa0:      	movq	%r12, %rax
     fa3:      	jmp	0x467 <custom__generic+0x467>
     fa8:      	movabsq	$0xa2930203d3d2043, %rax # imm = 0xA2930203D3D2043
     fb2:      	movq	%rax, 0x38(%rsp)
     fb7:      	movabsq	$0x5028206572756c69, %rax # imm = 0x5028206572756C69
     fc1:      	movq	%rax, 0x30(%rsp)
     fc6:      	movabsq	$0x616620646e69776e, %rax # imm = 0x616620646E69776E
     fd0:      	movq	%rax, 0x28(%rsp)
     fd5:      	movabsq	$0x75206f7420657564, %rax # imm = 0x75206F7420657564
     fdf:      	movq	%rax, 0x20(%rsp)
     fe4:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
     fee:      	movq	%rax, 0x18(%rsp)
     ff3:      	movabsq	$0x676e6970706f7453, %rax # imm = 0x676E6970706F7453
     ffd:      	movq	%rax, 0x10(%rsp)
    1002:      	movb	$0x0, 0x40(%rsp)
    1007:      	leaq	0x10(%rsp), %rdi
    100c:      	movl	$0x31, %eax
    1011:      	movl	$0x6, %ecx
    1016:      	movl	$0x31, %esi
    101b:      	xorl	%eax, %eax
    101d:      	callq	*%rcx
    101f:      	jmp	0x409 <custom__generic+0x409>
    1024:      	movabsq	$0x7373657264646120, %rax # imm = 0x7373657264646120
    102e:      	movq	%rax, 0x28(%rsp)
    1033:      	movabsq	$0x6c656e72656b2061, %rax # imm = 0x6C656E72656B2061
    103d:      	movq	%rax, 0x20(%rsp)
    1042:      	movabsq	$0x20736920786c2520, %rax # imm = 0x20736920786C2520
    104c:      	movq	%rax, 0x18(%rsp)
    1051:      	movabsq	$0x65756c6176204350, %rax # imm = 0x65756C6176204350
    105b:      	movq	%rax, 0x10(%rsp)
    1060:      	movw	$0xa, 0x30(%rsp)
    1067:      	leaq	0x10(%rsp), %rdi
    106c:      	movl	$0x22, %eax
    1071:      	movl	$0x6, %ecx
    1076:      	movl	$0x22, %esi
    107b:      	movq	%r12, %rdx
    107e:      	xorl	%eax, %eax
    1080:      	callq	*%rcx
    1082:      	jmp	0x327 <custom__generic+0x327>
    1087:      	movabsq	$0xa6425203a6425, %rcx  # imm = 0xA6425203A6425
    1091:      	movq	%rcx, 0x25(%rsp)
    1096:      	movabsq	$0x3a64252044495020, %rcx # imm = 0x3A64252044495020
    10a0:      	movq	%rcx, 0x20(%rsp)
    10a5:      	movabsq	$0x74726f706572206f, %rcx # imm = 0x74726F706572206F
    10af:      	movq	%rcx, 0x18(%rsp)
    10b4:      	movabsq	$0x742064656c696146, %rcx # imm = 0x742064656C696146
    10be:      	movq	%rcx, 0x10(%rsp)
    10c3:      	leaq	0x10(%rsp), %rdi
    10c8:      	movl	$0x1d, %ecx
    10cd:      	movl	$0x6, %r8d
    10d3:      	movl	0x4(%rsp), %edx
    10d7:      	movl	$0x1d, %esi
    10dc:      	movl	%eax, %ecx
    10de:      	xorl	%eax, %eax
    10e0:      	callq	*%r8
    10e3:      	jmp	0x4ad <custom__generic+0x4ad>
    10e8:      	movabsq	$0xa676e69726f6e, %rax  # imm = 0xA676E69726F6E
    10f2:      	movq	%rax, 0x26(%rsp)
    10f7:      	movabsq	$0x6f6e6769202c786c, %rax # imm = 0x6F6E6769202C786C
    1101:      	movq	%rax, 0x20(%rsp)
    1106:      	movabsq	$0x252065756c617620, %rax # imm = 0x252065756C617620
    1110:      	movq	%rax, 0x18(%rsp)
    1115:      	movabsq	$0x6370206c6c616d73, %rax # imm = 0x6370206C6C616D73
    111f:      	movq	%rax, 0x10(%rsp)
    1124:      	leaq	0x10(%rsp), %rdi
    1129:      	movl	$0x1e, %eax
    112e:      	movl	$0x6, %ecx
    1133:      	movl	$0x1e, %esi
    1138:      	movq	%r12, %rdx
    113b:      	xorl	%eax, %eax
    113d:      	callq	*%rcx
    113f:      	jmp	0xd28 <custom__generic+0xd28>
    1144:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    114e:      	movq	%rax, 0x38(%rsp)
    1153:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    115d:      	movq	%rax, 0x30(%rsp)
    1162:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    116c:      	movq	%rax, 0x28(%rsp)
    1171:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    117b:      	movq	%rax, 0x20(%rsp)
    1180:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    118a:      	movq	%rax, 0x18(%rsp)
    118f:      	movabsq	$0x6365732074786554, %r13 # imm = 0x6365732074786554
    1199:      	movq	%r13, 0x10(%rsp)
    119e:      	movw	$0xa, 0x40(%rsp)
    11a5:      	leaq	0x10(%rsp), %rdi
    11aa:      	movl	$0x32, %eax
    11af:      	movl	$0x6, %r9d
    11b5:      	movq	0xf10(%r14), %rcx
    11bc:      	movl	$0x32, %esi
    11c1:      	movq	%r12, %rdx
    11c4:      	movl	%r15d, %r8d
    11c7:      	xorl	%eax, %eax
    11c9:      	callq	*%r9
    11cc:      	movq	(%rip), %rax            # 0x11d3 <custom__generic+0x11d3>
    11d3:      	cmpl	$0x0, (%rax)
    11d6:      	je	0xdbc <custom__generic+0xdbc>
    11dc:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    11e6:      	movq	%rax, 0x37(%rsp)
    11eb:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    11f5:      	movq	%rax, 0x30(%rsp)
    11fa:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    1204:      	movq	%rax, 0x28(%rsp)
    1209:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    1213:      	movq	%rax, 0x20(%rsp)
    1218:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    1222:      	movq	%rax, 0x18(%rsp)
    1227:      	movq	%r13, 0x10(%rsp)
    122c:      	leaq	0x10(%rsp), %rdi
    1231:      	movl	$0x2f, %eax
    1236:      	movl	$0x6, %r8d
    123c:      	movq	0xf18(%r14), %rcx
    1243:      	movq	0xf20(%r14), %rdx
    124a:      	movl	$0x2f, %esi
    124f:      	xorl	%eax, %eax
    1251:      	callq	*%r8
    1254:      	jmp	0xdbc <custom__generic+0xdbc>
    1259:      	movl	0xb8(%rsp), %ecx
    1260:      	movabsq	$0xa6425203a6425, %rdx  # imm = 0xA6425203A6425
    126a:      	movq	%rdx, 0x3d(%rsp)
    126f:      	movabsq	$0x3a6425203a444954, %rdx # imm = 0x3A6425203A444954
    1279:      	movq	%rdx, 0x38(%rsp)
    127e:      	movabsq	$0x2064252044495020, %rdx # imm = 0x2064252044495020
    1288:      	movq	%rdx, 0x30(%rsp)
    128d:      	movabsq	$0x687469772073746e, %rdx # imm = 0x687469772073746E
    1297:      	movq	%rdx, 0x28(%rsp)
    129c:      	movabsq	$0x6576655f64697020, %rdx # imm = 0x6576655F64697020
    12a6:      	movq	%rdx, 0x20(%rsp)
    12ab:      	movabsq	$0x657461647075206f, %rdx # imm = 0x657461647075206F
    12b5:      	movq	%rdx, 0x18(%rsp)
    12ba:      	movabsq	$0x742064656c696146, %rdx # imm = 0x742064656C696146
    12c4:      	movq	%rdx, 0x10(%rsp)
    12c9:      	leaq	0x10(%rsp), %rdi
    12ce:      	movl	$0x35, %edx
    12d3:      	movl	$0x6, %r9d
    12d9:      	movl	$0x35, %esi
    12de:      	movl	%r15d, %edx
    12e1:      	movl	%eax, %r8d
    12e4:      	xorl	%eax, %eax
    12e6:      	callq	*%r9
    12e9:      	jmp	0x510 <custom__generic+0x510>
    12ee:      	movabsq	$0xa786c2578302043, %rax # imm = 0xA786C2578302043
    12f8:      	movq	%rax, 0x40(%rsp)
    12fd:      	movabsq	$0x5020726f6620676e, %rax # imm = 0x5020726F6620676E
    1307:      	movq	%rax, 0x38(%rsp)
    130c:      	movabsq	$0x697070616d207972, %rax # imm = 0x697070616D207972
    1316:      	movq	%rax, 0x30(%rsp)
    131b:      	movabsq	$0x6f6d656d206c6176, %rax # imm = 0x6F6D656D206C6176
    1325:      	movq	%rax, 0x28(%rsp)
    132a:      	movabsq	$0x7265746e69207075, %rax # imm = 0x7265746E69207075
    1334:      	movq	%rax, 0x20(%rsp)
    1339:      	movabsq	$0x206b6f6f6c206f74, %rax # imm = 0x206B6F6F6C206F74
    1343:      	movq	%rax, 0x18(%rsp)
    1348:      	movabsq	$0x206572756c696146, %rax # imm = 0x206572756C696146
    1352:      	movq	%rax, 0x10(%rsp)
    1357:      	movb	$0x0, 0x48(%rsp)
    135c:      	leaq	0x10(%rsp), %rdi
    1361:      	movl	$0x39, %eax
    1366:      	movl	$0x6, %ecx
    136b:      	movl	$0x39, %esi
    1370:      	movq	%r12, %rdx
    1373:      	xorl	%eax, %eax
    1375:      	callq	*%rcx
    1377:      	jmp	0xe2a <custom__generic+0xe2a>
    137c:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1386:      	movq	%rax, 0x36(%rsp)
    138b:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1395:      	movq	%rax, 0x30(%rsp)
    139a:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    13a4:      	movq	%rax, 0x28(%rsp)
    13a9:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    13b3:      	movq	%rax, 0x20(%rsp)
    13b8:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    13c2:      	movq	%rax, 0x18(%rsp)
    13c7:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    13d1:      	movq	%rax, 0x10(%rsp)
    13d6:      	leaq	0x10(%rsp), %rdi
    13db:      	movl	$0x2e, %eax
    13e0:      	movl	$0x6, %ecx
    13e5:      	movl	0xc0(%rsp), %edx
    13ec:      	movl	$0x2e, %esi
    13f1:      	xorl	%eax, %eax
    13f3:      	callq	*%rcx
    13f5:      	jmp	0x7a4 <custom__generic+0x7a4>
    13fa:      	movabsq	$0xa642520726f72, %rcx  # imm = 0xA642520726F72
    1404:      	movq	%rcx, 0x3e(%rsp)
    1409:      	movabsq	$0x6f727265203a6425, %rcx # imm = 0x6F727265203A6425
    1413:      	movq	%rcx, 0x38(%rsp)
    1418:      	movabsq	$0x20746e6576652064, %rcx # imm = 0x20746E6576652064
    1422:      	movq	%rcx, 0x30(%rsp)
    1427:      	movabsq	$0x6e6573206f742064, %rcx # imm = 0x6E6573206F742064
    1431:      	movq	%rcx, 0x28(%rsp)
    1436:      	movabsq	$0x656c696166207265, %rcx # imm = 0x656C696166207265
    1440:      	movq	%rcx, 0x20(%rsp)
    1445:      	movabsq	$0x67676972745f646e, %rcx # imm = 0x67676972745F646E
    144f:      	movq	%rcx, 0x18(%rsp)
    1454:      	movabsq	$0x65735f746e657665, %rcx # imm = 0x65735F746E657665
    145e:      	movq	%rcx, 0x10(%rsp)
    1463:      	leaq	0x10(%rsp), %rdi
    1468:      	movl	$0x36, %ecx
    146d:      	movl	$0x6, %r8d
    1473:      	movl	$0x36, %esi
    1478:      	movl	$0x1, %edx
    147d:      	movl	%eax, %ecx
    147f:      	xorl	%eax, %eax
    1481:      	callq	*%r8
    1484:      	jmp	0x76f <custom__generic+0x76f>
    1489:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1493:      	movq	%rax, 0x36(%rsp)
    1498:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    14a2:      	movq	%rax, 0x30(%rsp)
    14a7:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    14b1:      	movq	%rax, 0x28(%rsp)
    14b6:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    14c0:      	movq	%rax, 0x20(%rsp)
    14c5:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    14cf:      	movq	%rax, 0x18(%rsp)
    14d4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    14de:      	movq	%rax, 0x10(%rsp)
    14e3:      	leaq	0x10(%rsp), %rdi
    14e8:      	movl	$0x2e, %eax
    14ed:      	movl	$0x6, %ecx
    14f2:      	movl	0xc0(%rsp), %edx
    14f9:      	movl	$0x2e, %esi
    14fe:      	xorl	%eax, %eax
    1500:      	callq	*%rcx
    1502:      	jmp	0x725 <custom__generic+0x725>
    1507:      	movabsq	$0xa642520686374, %rcx  # imm = 0xA642520686374
    1511:      	movq	%rcx, 0x26(%rsp)
    1516:      	movabsq	$0x6374616d20737465, %rcx # imm = 0x6374616D20737465
    1520:      	movq	%rcx, 0x20(%rsp)
    1525:      	movabsq	$0x7366666f5f726574, %rcx # imm = 0x7366666F5F726574
    152f:      	movq	%rcx, 0x18(%rsp)
    1534:      	movabsq	$0x6572707265746e69, %rcx # imm = 0x6572707265746E69
    153e:      	movq	%rcx, 0x10(%rsp)
    1543:      	leaq	0x10(%rsp), %rdi
    1548:      	movl	$0x1e, %ecx
    154d:      	movl	$0x6, %r8d
    1553:      	movzwl	0x20(%rax), %edx
    1557:      	movl	$0x1e, %esi
    155c:      	movq	%rax, %r13
    155f:      	xorl	%eax, %eax
    1561:      	callq	*%r8
    1564:      	movq	%r13, %rax
    1567:      	movq	(%rip), %r13            # 0x156e <custom__generic+0x156e>
    156e:      	movl	0x1380(%r14), %ecx
    1575:      	movl	0x20(%rax), %edx
    1578:      	btl	%edx, %ecx
    157b:      	jb	0xe65 <custom__generic+0xe65>
    1581:      	movq	%rax, %r15
    1584:      	movl	$0x0, 0xb8(%rsp)
    158f:      	movq	(%rip), %rdi            # 0x1596 <custom__generic+0x1596>
    1596:      	leaq	0xb8(%rsp), %rsi
    159e:      	movl	$0x1, %eax
    15a3:      	callq	*%rax
    15a5:      	testq	%rax, %rax
    15a8:      	je	0x15b2 <custom__generic+0x15b2>
    15aa:      	incq	(%rax)
    15ad:      	movq	%r15, %rax
    15b0:      	jmp	0x15bc <custom__generic+0x15bc>
    15b2:      	cmpl	$0x0, (%r13)
    15b7:      	movq	%r15, %rax
    15ba:      	jne	0x15c6 <custom__generic+0x15c6>
    15bc:      	movzwl	0x20(%rax), %r15d
    15c1:      	jmp	0x8eb <custom__generic+0x8eb>
    15c6:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    15d0:      	movq	%rax, 0x36(%rsp)
    15d5:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    15df:      	movq	%rax, 0x30(%rsp)
    15e4:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    15ee:      	movq	%rax, 0x28(%rsp)
    15f3:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    15fd:      	movq	%rax, 0x20(%rsp)
    1602:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    160c:      	movq	%rax, 0x18(%rsp)
    1611:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    161b:      	movq	%rax, 0x10(%rsp)
    1620:      	leaq	0x10(%rsp), %rdi
    1625:      	movl	$0x2e, %eax
    162a:      	movl	$0x6, %ecx
    162f:      	movl	0xb8(%rsp), %edx
    1636:      	movl	$0x2e, %esi
    163b:      	xorl	%eax, %eax
    163d:      	callq	*%rcx
    163f:      	jmp	0x15ad <custom__generic+0x15ad>
