
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/katran/healthchecking.native.o:	file format elf64-x86-64

Disassembly of section tc:

0000000000000000 <healthcheck_encap>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x68, %rsp
       e:      	movl	$0x0, 0x24(%rsp)
      16:      	movq	%rdi, %rbx
      19:      	movl	$0x3, 0x10(%rsp)
      21:      	movl	0xa8(%rdi), %ebp
      27:      	movl	%ebp, 0x20(%rsp)
      2b:      	movq	(%rip), %rdi            # 0x32 <healthcheck_encap+0x32>
      32:      	leaq	0x24(%rsp), %rsi
      37:      	movl	$0x1, %eax
      3c:      	callq	*%rax
      3e:      	movq	%rax, %rcx
      41:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
      46:      	testq	%rcx, %rcx
      49:      	je	0x3e9 <healthcheck_encap+0x3e9>
      4f:      	movq	0xd0(%rbx), %rdx
      56:      	leaq	0xe(%rdx), %rsi
      5a:      	movl	0xbc(%rbx), %edi
      60:      	addq	0xc8(%rbx), %rdi
      67:      	cmpq	%rdi, %rsi
      6a:      	jbe	0x75 <healthcheck_encap+0x75>
      6c:      	incq	0x8(%rcx)
      70:      	jmp	0x3e4 <healthcheck_encap+0x3e4>
      75:      	movq	%rcx, %r13
      78:      	testl	%ebp, %ebp
      7a:      	je	0x16d <healthcheck_encap+0x16d>
      80:      	movzwl	0xc(%rdx), %ebp
      84:      	movq	(%rip), %rdi            # 0x8b <healthcheck_encap+0x8b>
      8b:      	leaq	0x20(%rsp), %rsi
      90:      	movl	$0x1, %r15d
      96:      	callq	*%r15
      99:      	movq	%rax, %r14
      9c:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
      a1:      	testq	%r14, %r14
      a4:      	je	0x16d <healthcheck_encap+0x16d>
      aa:      	movq	(%rip), %rdi            # 0xb1 <healthcheck_encap+0xb1>
      b1:      	leaq	0x10(%rsp), %rsi
      b6:      	callq	*%r15
      b9:      	testq	%rax, %rax
      bc:      	je	0x3e0 <healthcheck_encap+0x3e0>
      c2:      	movq	%rax, 0x18(%rsp)
      c7:      	movl	$0x0, 0x10(%rsp)
      cf:      	movq	(%rip), %rdi            # 0xd6 <healthcheck_encap+0xd6>
      d6:      	leaq	0x10(%rsp), %rsi
      db:      	movl	$0x1, %r15d
      e1:      	callq	*%r15
      e4:      	testq	%rax, %rax
      e7:      	je	0x3e0 <healthcheck_encap+0x3e0>
      ed:      	movq	%rax, 0x60(%rsp)
      f2:      	movl	$0x1, 0x10(%rsp)
      fa:      	movq	(%rip), %rdi            # 0x101 <healthcheck_encap+0x101>
     101:      	leaq	0x10(%rsp), %rsi
     106:      	callq	*%r15
     109:      	testq	%rax, %rax
     10c:      	je	0x3e0 <healthcheck_encap+0x3e0>
     112:      	movl	$0x0, 0x38(%rsp)
     11a:      	movq	$0x0, 0x30(%rsp)
     123:      	movq	$0x0, 0x28(%rsp)
     12c:      	movzwl	%bp, %ebp
     12f:      	movl	0xbc(%rbx), %ecx
     135:      	addq	0xc8(%rbx), %rcx
     13c:      	movq	0xd0(%rbx), %rsi
     143:      	cmpl	$0xdd86, %ebp           # imm = 0xDD86
     149:      	jne	0x176 <healthcheck_encap+0x176>
     14b:      	leaq	0x36(%rsi), %rdx
     14f:      	cmpq	%rcx, %rdx
     152:      	ja	0x1af <healthcheck_encap+0x1af>
     154:      	movq	0x26(%rsi), %rdi
     158:      	movq	0x2e(%rsi), %r8
     15c:      	movq	%r8, 0x30(%rsp)
     161:      	movq	%rdi, 0x28(%rsp)
     166:      	movl	$0x14, %edi
     16b:      	jmp	0x18b <healthcheck_encap+0x18b>
     16d:      	incq	0x10(%r13)
     171:      	jmp	0x3e9 <healthcheck_encap+0x3e9>
     176:      	leaq	0x22(%rsi), %rdx
     17a:      	cmpq	%rcx, %rdx
     17d:      	ja	0x1af <healthcheck_encap+0x1af>
     17f:      	movl	0x1e(%rsi), %edi
     182:      	movl	%edi, 0x28(%rsp)
     186:      	movl	$0x17, %edi
     18b:      	movzbl	(%rsi,%rdi), %esi
     18f:      	movb	%sil, 0x3a(%rsp)
     194:      	cmpl	$0x11, %esi
     197:      	je	0x3f8 <healthcheck_encap+0x3f8>
     19d:      	cmpl	$0x6, %esi
     1a0:      	jne	0x1af <healthcheck_encap+0x1af>
     1a2:      	leaq	0x14(%rdx), %rsi
     1a6:      	cmpq	%rcx, %rsi
     1a9:      	jbe	0x405 <healthcheck_encap+0x405>
     1af:      	movl	$0x0, 0xc(%rsp)
     1b7:      	movq	%rax, 0x58(%rsp)
     1bc:      	movl	$0x0, 0xa8(%rbx)
     1c6:      	movl	0x70(%rbx), %r12d
     1ca:      	cmpb	$0x1, 0x10(%r14)
     1cf:      	jne	0x2a7 <healthcheck_encap+0x2a7>
     1d5:      	movl	$0x1, 0x14(%rsp)
     1dd:      	movq	(%rip), %rdi            # 0x1e4 <healthcheck_encap+0x1e4>
     1e4:      	leaq	0x14(%rsp), %rsi
     1e9:      	movl	$0x1, %eax
     1ee:      	callq	*%rax
     1f0:      	testq	%rax, %rax
     1f3:      	je	0x3e0 <healthcheck_encap+0x3e0>
     1f9:      	movq	%rax, %r15
     1fc:      	movl	$0x32, %eax
     201:      	movl	$0x5, %ecx
     206:      	movq	%rbx, %rdi
     209:      	movl	$0x28, %esi
     20e:      	movl	$0x1, %edx
     213:      	callq	*%rax
     215:      	testl	%eax, %eax
     217:      	jne	0x3e0 <healthcheck_encap+0x3e0>
     21d:      	movq	0xd0(%rbx), %rax
     224:      	leaq	0x36(%rax), %rcx
     228:      	movl	0xbc(%rbx), %edx
     22e:      	addq	0xc8(%rbx), %rdx
     235:      	cmpq	%rdx, %rcx
     238:      	ja	0x3e0 <healthcheck_encap+0x3e0>
     23e:      	addl	$-0xe, %r12d
     242:      	cmpl	$0xdd86, %ebp           # imm = 0xDD86
     248:      	movw	$0xdd86, 0xc(%rax)      # imm = 0xDD86
     24e:      	movl	$0x29, %ecx
     253:      	movl	$0x4, %edx
     258:      	cmovel	%ecx, %edx
     25b:      	movq	(%r15), %rcx
     25e:      	movq	0x8(%r15), %rsi
     262:      	movq	%rsi, 0x48(%rsp)
     267:      	movq	%rcx, 0x40(%rsp)
     26c:      	movl	$0x60, 0xe(%rax)
     273:      	movb	%dl, 0x14(%rax)
     276:      	movbew	%r12w, 0x12(%rax)
     27d:      	movb	$0x40, 0x15(%rax)
     281:      	movq	0x40(%rsp), %rcx
     286:      	movq	0x48(%rsp), %rdx
     28b:      	movq	%rcx, 0x16(%rax)
     28f:      	movq	%rdx, 0x1e(%rax)
     293:      	movq	(%r14), %rcx
     296:      	movq	0x8(%r14), %rdx
     29a:      	movq	%rcx, 0x26(%rax)
     29e:      	movq	%rdx, 0x2e(%rax)
     2a2:      	jmp	0x3b4 <healthcheck_encap+0x3b4>
     2a7:      	movl	$0x0, 0x14(%rsp)
     2af:      	movq	(%rip), %rdi            # 0x2b6 <healthcheck_encap+0x2b6>
     2b6:      	leaq	0x14(%rsp), %rsi
     2bb:      	movl	$0x1, %eax
     2c0:      	callq	*%rax
     2c2:      	testq	%rax, %rax
     2c5:      	je	0x3e0 <healthcheck_encap+0x3e0>
     2cb:      	movq	%rax, %r15
     2ce:      	movl	$0x32, %eax
     2d3:      	movl	$0x3, %ecx
     2d8:      	movq	%rbx, %rdi
     2db:      	movl	$0x14, %esi
     2e0:      	movl	$0x1, %edx
     2e5:      	callq	*%rax
     2e7:      	testl	%eax, %eax
     2e9:      	jne	0x3e0 <healthcheck_encap+0x3e0>
     2ef:      	movq	0xd0(%rbx), %rax
     2f6:      	leaq	0x22(%rax), %rcx
     2fa:      	movl	0xbc(%rbx), %edx
     300:      	addq	0xc8(%rbx), %rdx
     307:      	cmpq	%rdx, %rcx
     30a:      	ja	0x3e0 <healthcheck_encap+0x3e0>
     310:      	movl	(%r15), %ecx
     313:      	movl	(%r14), %edx
     316:      	movw	$0x45, 0xe(%rax)
     31c:      	addl	$0x6, %r12d
     320:      	movbew	%r12w, 0x10(%rax)
     327:      	rolw	$0x8, %r12w
     32c:      	movl	$0x0, 0x12(%rax)
     333:      	movl	%edx, 0x1e(%rax)
     336:      	movl	%ecx, 0x1a(%rax)
     339:      	movw	$0x440, 0x16(%rax)      # imm = 0x440
     33f:      	movzwl	%r12w, %esi
     343:      	movzwl	%cx, %edi
     346:      	addq	%rsi, %rdi
     349:      	shrl	$0x10, %ecx
     34c:      	movzwl	%dx, %edx
     34f:      	addq	%rcx, %rdx
     352:      	addq	%rdi, %rdx
     355:      	movzwl	0x20(%rax), %ecx
     359:      	addq	%rdx, %rcx
     35c:      	addq	$0x485, %rcx            # imm = 0x485
     363:      	movl	%ecx, %edx
     365:      	shrl	$0x10, %edx
     368:      	movzwl	%cx, %esi
     36b:      	addq	%rdx, %rsi
     36e:      	cmpq	$0x10000, %rcx          # imm = 0x10000
     375:      	cmovbq	%rcx, %rsi
     379:      	movq	%rsi, %rcx
     37c:      	shrq	$0x10, %rcx
     380:      	movzwl	%si, %edx
     383:      	addq	%rcx, %rdx
     386:      	cmpq	$0x10000, %rsi          # imm = 0x10000
     38d:      	cmovbq	%rsi, %rdx
     391:      	movq	%rdx, %rcx
     394:      	shrq	$0x10, %rcx
     398:      	movzwl	%dx, %esi
     39b:      	addl	%esi, %ecx
     39d:      	cmpq	$0x10000, %rdx          # imm = 0x10000
     3a4:      	cmovbl	%edx, %ecx
     3a7:      	movl	%ecx, %edx
     3a9:      	shrl	$0x10, %edx
     3ac:      	addl	%ecx, %edx
     3ae:      	notl	%edx
     3b0:      	movw	%dx, 0x18(%rax)
     3b4:      	movq	0xd0(%rbx), %rax
     3bb:      	leaq	0xe(%rax), %rcx
     3bf:      	movl	0xbc(%rbx), %edx
     3c5:      	addq	0xc8(%rbx), %rdx
     3cc:      	cmpq	%rdx, %rcx
     3cf:      	movq	0x18(%rsp), %rcx
     3d4:      	movq	0x60(%rsp), %rsi
     3d9:      	movq	0x58(%rsp), %rdx
     3de:      	jbe	0x419 <healthcheck_encap+0x419>
     3e0:      	incq	0x8(%r13)
     3e4:      	movl	$0x2, %eax
     3e9:      	addq	$0x68, %rsp
     3ed:      	popq	%rbx
     3ee:      	popq	%r12
     3f0:      	popq	%r13
     3f2:      	popq	%r14
     3f4:      	popq	%r15
     3f6:      	popq	%rbp
     3f7:      	retq
     3f8:      	leaq	0x8(%rdx), %rsi
     3fc:      	cmpq	%rcx, %rsi
     3ff:      	ja	0x1af <healthcheck_encap+0x1af>
     405:      	movzwl	0x2(%rdx), %ecx
     409:      	movw	%cx, 0x38(%rsp)
     40e:      	movb	$0x1, %cl
     410:      	movl	%ecx, 0xc(%rsp)
     414:      	jmp	0x1b7 <healthcheck_encap+0x1b7>
     419:      	movzwl	0x4(%rsi), %edi
     41d:      	movw	%di, 0xa(%rax)
     421:      	movl	(%rsi), %esi
     423:      	movl	%esi, 0x6(%rax)
     426:      	movl	(%rdx), %esi
     428:      	movl	%esi, (%rax)
     42a:      	movzwl	0x4(%rdx), %edx
     42e:      	movw	%dx, 0x4(%rax)
     432:      	incq	(%r13)
     436:      	cmpb	$0x0, 0xc(%rsp)
     43b:      	je	0x472 <healthcheck_encap+0x472>
     43d:      	movq	(%rip), %rdi            # 0x444 <healthcheck_encap+0x444>
     444:      	leaq	0x28(%rsp), %rsi
     449:      	movl	$0x1, %ebx
     44e:      	callq	*%rbx
     450:      	movq	0x18(%rsp), %rcx
     455:      	testq	%rax, %rax
     458:      	je	0x472 <healthcheck_encap+0x472>
     45a:      	movq	(%rip), %rdi            # 0x461 <healthcheck_encap+0x461>
     461:      	movq	%rax, %rsi
     464:      	callq	*%rbx
     466:      	movq	0x18(%rsp), %rcx
     46b:      	testq	%rax, %rax
     46e:      	je	0x472 <healthcheck_encap+0x472>
     470:      	incl	(%rax)
     472:      	movl	(%rcx), %edi
     474:      	movl	$0x17, %eax
     479:      	xorl	%esi, %esi
     47b:      	callq	*%rax
     47d:      	jmp	0x3e9 <healthcheck_encap+0x3e9>
