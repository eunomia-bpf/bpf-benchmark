
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_execve_event_v511.native.o:	file format elf64-x86-64

Disassembly of section tracepoint:

0000000000000000 <execve_rate>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x48, %rsp
       e:      	movq	%rdi, %rbx
      11:      	movl	$0x0, 0x4(%rsp)
      19:      	movq	(%rip), %rdi            # 0x20 <execve_rate+0x20>
      20:      	leaq	0x4(%rsp), %rsi
      25:      	movl	$0x1, %eax
      2a:      	callq	*%rax
      2c:      	testq	%rax, %rax
      2f:      	je	0x343 <execve_rate+0x343>
      35:      	movq	0x8(%rax), %r15
      39:      	movq	%rax, %r13
      3c:      	movq	0x10(%rax), %rax
      40:      	movq	%rax, 0x18(%rsp)
      45:      	movl	$0x0, 0x8(%rsp)
      4d:      	movq	(%rip), %rdi            # 0x54 <execve_rate+0x54>
      54:      	leaq	0x8(%rsp), %rsi
      59:      	movl	$0x1, %eax
      5e:      	callq	*%rax
      60:      	testq	%rax, %rax
      63:      	je	0x328 <execve_rate+0x328>
      69:      	movq	0x8(%rax), %r12
      6d:      	testq	%r12, %r12
      70:      	je	0x328 <execve_rate+0x328>
      76:      	movq	%rax, %rbp
      79:      	movq	(%rip), %rdi            # 0x80 <execve_rate+0x80>
      80:      	leaq	0x18(%rsp), %rsi
      85:      	movl	$0x1, %eax
      8a:      	callq	*%rax
      8c:      	testq	%rax, %rax
      8f:      	je	0xc2 <execve_rate+0xc2>
      91:      	movq	%rax, %r14
      94:      	movq	0x10(%rax), %rax
      98:      	movq	%r15, %rcx
      9b:      	subq	%rax, %rcx
      9e:      	cmpq	%r12, %rcx
      a1:      	jbe	0x118 <execve_rate+0x118>
      a3:      	leaq	(%r12,%r12), %rdx
      a7:      	cmpq	%rdx, %rcx
      aa:      	jbe	0x11d <execve_rate+0x11d>
      ac:      	movq	$0x0, 0x8(%r14)
      b4:      	movq	%r15, %rax
      b7:      	xorl	%edx, %edx
      b9:      	divq	%r12
      bc:      	imulq	%r12, %rax
      c0:      	jmp	0x127 <execve_rate+0x127>
      c2:      	movq	$0x1, 0x20(%rsp)
      cb:      	movq	$0x0, 0x28(%rsp)
      d4:      	movq	%r15, %rax
      d7:      	xorl	%edx, %edx
      d9:      	divq	%r12
      dc:      	imulq	%r12, %rax
      e0:      	movq	%rax, 0x30(%rsp)
      e5:      	movq	$0x0, 0x38(%rsp)
      ee:      	movq	$0x0, 0x40(%rsp)
      f7:      	movq	(%rip), %rdi            # 0xfe <execve_rate+0xfe>
      fe:      	xorl	%ecx, %ecx
     100:      	leaq	0x18(%rsp), %rsi
     105:      	leaq	0x20(%rsp), %rdx
     10a:      	movl	$0x2, %eax
     10f:      	xorl	%ecx, %ecx
     111:      	callq	*%rax
     113:      	jmp	0x328 <execve_rate+0x328>
     118:      	movq	(%r14), %rcx
     11b:      	jmp	0x12d <execve_rate+0x12d>
     11d:      	movq	(%r14), %rcx
     120:      	movq	%rcx, 0x8(%r14)
     124:      	addq	%r12, %rax
     127:      	movq	%rax, 0x10(%r14)
     12b:      	xorl	%ecx, %ecx
     12d:      	incq	%rcx
     130:      	movq	%rcx, (%r14)
     133:      	movq	%r12, %rcx
     136:      	subq	%r15, %rcx
     139:      	addq	%rax, %rcx
     13c:      	imulq	0x8(%r14), %rcx
     141:      	movq	%rcx, %rax
     144:      	xorl	%edx, %edx
     146:      	divq	%r12
     149:      	addq	(%r14), %rax
     14c:      	movq	%rax, 0x18(%r14)
     150:      	cmpq	$0x0, 0x20(%r14)
     155:      	jne	0x343 <execve_rate+0x343>
     15b:      	cmpq	(%rbp), %rax
     15f:      	jb	0x328 <execve_rate+0x328>
     165:      	movq	%r15, 0x20(%r14)
     169:      	movl	$0x0, 0x10(%rsp)
     171:      	movq	(%rip), %rdi            # 0x178 <execve_rate+0x178>
     178:      	leaq	0x10(%rsp), %rcx
     17d:      	movl	$0x1, %eax
     182:      	movl	$0x0, 0xc(%rsp)
     18a:      	leaq	0xc(%rsp), %rsi
     18f:      	callq	*%rax
     191:      	testq	%rax, %rax
     194:      	je	0x321 <execve_rate+0x321>
     19a:      	movq	%rax, %r12
     19d:      	movl	$0xa0, 0x4(%rax)
     1a4:      	movq	%r13, %rsi
     1a7:      	addq	$0x10, %rsi
     1ab:      	movq	%r15, 0x8(%rax)
     1af:      	movw	$0x1b, (%rax)
     1b4:      	movq	%rax, %rdi
     1b7:      	addq	$0x10, %rdi
     1bb:      	movl	$0x90, %edx
     1c0:      	callq	0x1c5 <execve_rate+0x1c5>
     1c5:      	movl	$0x0, 0x14(%rsp)
     1cd:      	movq	(%rip), %rdi            # 0x1d4 <execve_rate+0x1d4>
     1d4:      	leaq	0x14(%rsp), %rsi
     1d9:      	movl	$0x1, %eax
     1de:      	callq	*%rax
     1e0:      	testq	%rax, %rax
     1e3:      	je	0x26d <execve_rate+0x26d>
     1e9:      	cmpb	$0x0, 0x28(%rax)
     1ed:      	je	0x26d <execve_rate+0x26d>
     1ef:      	movq	(%rip), %rsi            # 0x1f6 <execve_rate+0x1f6>
     1f6:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     1fb:      	movl	$0xa0, %edx
     200:      	movl	$0x19, %eax
     205:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     20a:      	movl	$0xa0, %r8d
     210:      	movq	%rbx, %rdi
     213:      	movq	%r12, %rcx
     216:      	callq	*%rax
     218:      	testq	%rax, %rax
     21b:      	jns	0x321 <execve_rate+0x321>
     221:      	movq	%rax, %r15
     224:      	movl	$0x0, 0x20(%rsp)
     22c:      	movq	(%rip), %rdi            # 0x233 <execve_rate+0x233>
     233:      	leaq	0x20(%rsp), %rsi
     238:      	movl	$0x1, %eax
     23d:      	callq	*%rax
     23f:      	testq	%rax, %rax
     242:      	je	0x321 <execve_rate+0x321>
     248:      	cmpq	$-0xc, %r15
     24c:      	jg	0x2ed <execve_rate+0x2ed>
     252:      	cmpq	$-0x1c, %r15
     256:      	je	0x307 <execve_rate+0x307>
     25c:      	cmpq	$-0x16, %r15
     260:      	jne	0x2c5 <execve_rate+0x2c5>
     262:      	addq	$0x608, %rax            # imm = 0x608
     268:      	jmp	0x31d <execve_rate+0x31d>
     26d:      	movq	(%rip), %rdi            # 0x274 <execve_rate+0x274>
     274:      	xorl	%ecx, %ecx
     276:      	movl	$0xa0, %edx
     27b:      	movl	$0x82, %eax
     280:      	movq	%r12, %rsi
     283:      	xorl	%ecx, %ecx
     285:      	callq	*%rax
     287:      	testq	%rax, %rax
     28a:      	jns	0x321 <execve_rate+0x321>
     290:      	movq	%rax, %r15
     293:      	movl	$0x0, 0x20(%rsp)
     29b:      	movq	(%rip), %rdi            # 0x2a2 <execve_rate+0x2a2>
     2a2:      	leaq	0x20(%rsp), %rsi
     2a7:      	movl	$0x1, %eax
     2ac:      	callq	*%rax
     2ae:      	testq	%rax, %rax
     2b1:      	je	0x321 <execve_rate+0x321>
     2b3:      	cmpq	$-0xc, %r15
     2b7:      	jg	0x2d3 <execve_rate+0x2d3>
     2b9:      	cmpq	$-0x1c, %r15
     2bd:      	je	0x307 <execve_rate+0x307>
     2bf:      	cmpq	$-0x16, %r15
     2c3:      	je	0x262 <execve_rate+0x262>
     2c5:      	cmpq	$-0x10, %r15
     2c9:      	jne	0x2ff <execve_rate+0x2ff>
     2cb:      	addq	$0x600, %rax            # imm = 0x600
     2d1:      	jmp	0x31d <execve_rate+0x31d>
     2d3:      	cmpq	$-0xb, %r15
     2d7:      	je	0x30f <execve_rate+0x30f>
     2d9:      	cmpq	$-0x7, %r15
     2dd:      	je	0x317 <execve_rate+0x317>
     2df:      	cmpq	$-0x2, %r15
     2e3:      	jne	0x2ff <execve_rate+0x2ff>
     2e5:      	addq	$0x5f0, %rax            # imm = 0x5F0
     2eb:      	jmp	0x31d <execve_rate+0x31d>
     2ed:      	cmpq	$-0xb, %r15
     2f1:      	je	0x30f <execve_rate+0x30f>
     2f3:      	cmpq	$-0x7, %r15
     2f7:      	je	0x317 <execve_rate+0x317>
     2f9:      	cmpq	$-0x2, %r15
     2fd:      	je	0x2e5 <execve_rate+0x2e5>
     2ff:      	addq	$0x5e8, %rax            # imm = 0x5E8
     305:      	jmp	0x31d <execve_rate+0x31d>
     307:      	addq	$0x610, %rax            # imm = 0x610
     30d:      	jmp	0x31d <execve_rate+0x31d>
     30f:      	addq	$0x618, %rax            # imm = 0x618
     315:      	jmp	0x31d <execve_rate+0x31d>
     317:      	addq	$0x5f8, %rax            # imm = 0x5F8
     31d:      	lock
     31e:      	incq	(%rax)
     321:      	cmpq	$0x0, 0x20(%r14)
     326:      	jne	0x343 <execve_rate+0x343>
     328:      	movq	(%rip), %rsi            # 0x32f <execve_rate+0x32f>
     32f:      	movl	$0x1, %ecx
     334:      	movl	$0xc, %eax
     339:      	movq	%rbx, %rdi
     33c:      	movl	$0x1, %edx
     341:      	callq	*%rax
     343:      	xorl	%eax, %eax
     345:      	addq	$0x48, %rsp
     349:      	popq	%rbx
     34a:      	popq	%r12
     34c:      	popq	%r13
     34e:      	popq	%r14
     350:      	popq	%r15
     352:      	popq	%rbp
     353:      	retq
     354:      	nopw	%cs:(%rax,%rax)

0000000000000360 <execve_send>:
     360:      	pushq	%rbp
     361:      	pushq	%r15
     363:      	pushq	%r14
     365:      	pushq	%r13
     367:      	pushq	%r12
     369:      	pushq	%rbx
     36a:      	subq	$0xa8, %rsp
     371:      	movq	%rdi, %rbx
     374:      	movl	$0x0, 0x78(%rsp)
     37c:      	movq	(%rip), %rdi            # 0x383 <execve_send+0x23>
     383:      	leaq	0x78(%rsp), %rsi
     388:      	movl	$0x1, %eax
     38d:      	callq	*%rax
     38f:      	testq	%rax, %rax
     392:      	je	0x14cb <execve_send+0x116b>
     398:      	movq	%rax, %rbp
     39b:      	movq	%rbx, 0x90(%rsp)
     3a3:      	movl	$0x23, %eax
     3a8:      	callq	*%rax
     3aa:      	leaq	0xa78(%rax), %rdx
     3b1:      	leaq	0x10(%rsp), %rdi
     3b6:      	movl	$0x8, %ecx
     3bb:      	movl	$0x4, %eax
     3c0:      	leaq	0x16c0(%rbp), %rcx
     3c7:      	movq	%rcx, 0x88(%rsp)
     3cf:      	movl	$0x8, %esi
     3d4:      	callq	*%rax
     3d6:      	movl	$0x5f8, %edx            # imm = 0x5F8
     3db:      	movq	0x10(%rsp), %rcx
     3e0:      	addq	%rdx, %rcx
     3e3:      	leaq	0x20(%rsp), %rdi
     3e8:      	movl	$0x8, %esi
     3ed:      	movl	$0x4, %eax
     3f2:      	addq	0x10(%rsp), %rdx
     3f7:      	movl	$0x8, %esi
     3fc:      	callq	*%rax
     3fe:      	movq	0x20(%rsp), %r14
     403:      	movl	$0x0, 0x7c(%rsp)
     40b:      	movq	(%rip), %rdi            # 0x412 <execve_send+0xb2>
     412:      	leaq	0x7c(%rsp), %rsi
     417:      	movl	$0x1, %eax
     41c:      	callq	*%rax
     41e:      	testq	%rax, %rax
     421:      	je	0xaf1 <execve_send+0x791>
     427:      	movq	%rax, %r12
     42a:      	movl	$0x1000, 0x1840(%rbp)   # imm = 0x1000
     434:      	addq	$0x1000, %rax           # imm = 0x1000
     43a:      	movq	%rax, 0x60(%rsp)
     43f:      	movl	$0x23, %eax
     444:      	callq	*%rax
     446:      	leaq	0xd50(%rax), %rdx
     44d:      	leaq	0x98(%rsp), %rdi
     455:      	movl	$0x8, %ecx
     45a:      	movl	$0x4, %eax
     45f:      	movl	$0x8, %esi
     464:      	callq	*%rax
     466:      	movq	0x98(%rsp), %r13
     46e:      	leaq	0x48(%r14), %r15
     472:      	leaq	0xa0(%rsp), %rdi
     47a:      	movl	$0x8, %ecx
     47f:      	movl	$0x4, %eax
     484:      	movl	$0x8, %esi
     489:      	movq	%r15, %rdx
     48c:      	callq	*%rax
     48e:      	movq	0xa0(%rsp), %rbx
     496:      	leaq	0x10(%rbx), %rdx
     49a:      	leaq	0x20(%rsp), %rdi
     49f:      	movl	$0x8, %ecx
     4a4:      	movl	$0x4, %eax
     4a9:      	movl	$0x8, %esi
     4ae:      	callq	*%rax
     4b0:      	cmpq	$0x0, 0x20(%rsp)
     4b6:      	je	0x75b <execve_send+0x3fb>
     4bc:      	movq	0x60(%rsp), %rcx
     4c1:      	movq	$0x0, 0x28(%rsp)
     4ca:      	movq	$0x0, 0x20(%rsp)
     4d3:      	movq	%r12, 0x30(%rsp)
     4d8:      	movq	$0x0, 0x38(%rsp)
     4e1:      	movq	$0x0, 0x40(%rsp)
     4ea:      	movq	$0x0, 0x48(%rsp)
     4f3:      	movq	%rcx, 0x60(%rsp)
     4f8:      	movq	%rcx, 0x50(%rsp)
     4fd:      	movq	%rbp, 0x80(%rsp)
     505:      	movl	0x1840(%rbp), %eax
     50b:      	movl	%eax, 0x58(%rsp)
     50f:      	leaq	0x18(%r13), %r12
     513:      	movb	$0x0, 0x5c(%rsp)
     518:      	addq	$0x20, %r13
     51c:      	leaq	0x20(%rsp), %rdi
     521:      	movl	$0x8, %ecx
     526:      	movl	$0x4, %eax
     52b:      	addq	$0x40, %r14
     52f:      	leaq	0x28(%rsp), %rbx
     534:      	leaq	0x38(%rsp), %rbp
     539:      	movl	$0x8, %esi
     53e:      	movq	%r13, %rdx
     541:      	callq	*%rax
     543:      	movl	$0x8, %ecx
     548:      	movl	$0x4, %eax
     54d:      	movq	%rbx, %rdi
     550:      	movl	$0x8, %esi
     555:      	movq	%r12, %rdx
     558:      	callq	*%rax
     55a:      	movl	$0x8, %ecx
     55f:      	movl	$0x4, %eax
     564:      	movq	%rbp, %rdi
     567:      	movl	$0x8, %esi
     56c:      	movq	%r15, %rdx
     56f:      	callq	*%rax
     571:      	movl	$0x8, %ecx
     576:      	movl	$0x4, %eax
     57b:      	leaq	0x40(%rsp), %rdi
     580:      	movl	$0x8, %esi
     585:      	movq	%r14, %rdx
     588:      	callq	*%rax
     58a:      	movq	0x40(%rsp), %rax
     58f:      	addq	$-0x20, %rax
     593:      	movq	%rax, 0x48(%rsp)
     598:      	movq	(%rip), %rax            # 0x59f <execve_send+0x23f>
     59f:      	cmpb	$0x0, (%rax)
     5a2:      	je	0x7ac <execve_send+0x44c>
     5a8:      	movl	$0x80, %ebx
     5ad:      	movl	$0x8, %r13d
     5b3:      	leaq	0x8(%rsp), %rbp
     5b8:      	nopl	(%rax,%rax)
     5c0:      	movq	0x38(%rsp), %r15
     5c5:      	movq	0x40(%rsp), %rdx
     5ca:      	movq	0x48(%rsp), %r14
     5cf:      	cmpq	0x20(%rsp), %r15
     5d4:      	jne	0x5e1 <execve_send+0x281>
     5d6:      	cmpq	0x28(%rsp), %rdx
     5db:      	je	0x94f <execve_send+0x5ef>
     5e1:      	movl	$0x4, %eax
     5e6:      	leaq	0x70(%rsp), %rdi
     5eb:      	movl	$0x8, %esi
     5f0:      	callq	*%rax
     5f2:      	cmpq	0x70(%rsp), %r15
     5f7:      	je	0x700 <execve_send+0x3a0>
     5fd:      	leaq	0x18(%r15), %r12
     601:      	movl	$0x4, %eax
     606:      	movq	%rbp, %rdi
     609:      	movl	$0x8, %esi
     60e:      	movq	%r12, %rdx
     611:      	callq	*%rax
     613:      	cmpq	%r15, 0x8(%rsp)
     618:      	je	0x700 <execve_send+0x3a0>
     61e:      	movl	$0x4, %eax
     623:      	leaq	0x68(%rsp), %rdi
     628:      	movl	$0x8, %esi
     62d:      	movq	%r12, %rdx
     630:      	callq	*%rax
     632:      	addq	$0x20, %r15
     636:      	movl	$0x4, %eax
     63b:      	leaq	0x10(%rsp), %rdi
     640:      	movl	$0x10, %ecx
     645:      	movl	$0x10, %esi
     64a:      	movq	%r15, %rdx
     64d:      	callq	*%rax
     64f:      	movq	0x30(%rsp), %r14
     654:      	movq	0x50(%rsp), %rax
     659:      	movl	0x14(%rsp), %r15d
     65e:      	subq	%r14, %rax
     661:      	movl	0x58(%rsp), %r12d
     666:      	movl	%r15d, %edx
     669:      	subl	%r12d, %edx
     66c:      	movl	$0x0, %ecx
     671:      	cmovbl	%ecx, %edx
     674:      	addq	0x18(%rsp), %rdx
     679:      	xorl	%esi, %esi
     67b:      	cmpl	%r15d, %r12d
     67e:      	seta	%sil
     682:      	movl	%r15d, %ecx
     685:      	cmovbl	%r12d, %ecx
     689:      	addl	%ecx, %esi
     68b:      	movl	%r12d, %edi
     68e:      	subl	%esi, %edi
     690:      	movl	%edi, 0x58(%rsp)
     694:      	subq	%rsi, %rax
     697:      	jb	0x98b <execve_send+0x62b>
     69d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     6a3:      	ja	0x98b <execve_send+0x62b>
     6a9:      	cmpl	%r15d, %r12d
     6ac:      	jbe	0x6b3 <execve_send+0x353>
     6ae:      	movb	$0x2f, (%r14,%rax)
     6b3:      	xorl	%edi, %edi
     6b5:      	cmpl	%r15d, %r12d
     6b8:      	seta	%dil
     6bc:      	movzbl	%cl, %esi
     6bf:      	addq	%rax, %r14
     6c2:      	addq	%r14, %rdi
     6c5:      	movl	$0x4, %eax
     6ca:      	callq	*%rax
     6cc:      	movq	%r14, 0x50(%rsp)
     6d1:      	cmpl	%r15d, %r12d
     6d4:      	jbe	0x98b <execve_send+0x62b>
     6da:      	movq	0x68(%rsp), %rax
     6df:      	movq	%rax, 0x38(%rsp)
     6e4:      	decl	%ebx
     6e6:      	jne	0x5c0 <execve_send+0x260>
     6ec:      	jmp	0x98b <execve_send+0x62b>
     6f1:      	nopw	%cs:(%rax,%rax)
     700:      	leaq	0x10(%r14), %rdx
     704:      	movl	$0x4, %eax
     709:      	movq	%rbp, %rdi
     70c:      	movl	$0x8, %esi
     711:      	callq	*%rax
     713:      	movq	0x48(%rsp), %rax
     718:      	cmpq	0x8(%rsp), %rax
     71d:      	je	0x986 <execve_send+0x626>
     723:      	addq	$0x18, %r14
     727:      	movl	$0x4, %eax
     72c:      	leaq	0x38(%rsp), %rdi
     731:      	movl	$0x8, %esi
     736:      	movq	%r14, %rdx
     739:      	callq	*%rax
     73b:      	movq	0x8(%rsp), %rax
     740:      	movq	%rax, 0x48(%rsp)
     745:      	addq	$0x20, %rax
     749:      	movq	%rax, 0x40(%rsp)
     74e:      	decl	%ebx
     750:      	jne	0x5c0 <execve_send+0x260>
     756:      	jmp	0x98b <execve_send+0x62b>
     75b:      	leaq	0x18(%rbx), %rdx
     75f:      	leaq	0x20(%rsp), %rdi
     764:      	movl	$0x8, %ecx
     769:      	movl	$0x4, %eax
     76e:      	movl	$0x8, %esi
     773:      	callq	*%rax
     775:      	cmpq	%rbx, 0x20(%rsp)
     77a:      	je	0x4bc <execve_send+0x15c>
     780:      	movl	0x1840(%rbp), %ecx
     786:      	leal	-0xa(%rcx), %eax
     789:      	movl	%eax, 0x1840(%rbp)
     78f:      	cmpl	$0x9, %ecx
     792:      	movq	0x60(%rsp), %rcx
     797:      	jg	0xf74 <execve_send+0xc14>
     79d:      	movl	$0xffffffdc, 0x1844(%rbp) # imm = 0xFFFFFFDC
     7a7:      	jmp	0x981 <execve_send+0x621>
     7ac:      	movl	$0x80, %ebx
     7b1:      	movl	$0x8, %r13d
     7b7:      	leaq	0x8(%rsp), %rbp
     7bc:      	jmp	0x7c8 <execve_send+0x468>
     7be:      	nop
     7c0:      	decl	%ebx
     7c2:      	je	0x98b <execve_send+0x62b>
     7c8:      	movq	0x38(%rsp), %r15
     7cd:      	movq	0x40(%rsp), %rdx
     7d2:      	movq	0x48(%rsp), %r14
     7d7:      	cmpq	0x20(%rsp), %r15
     7dc:      	jne	0x7e9 <execve_send+0x489>
     7de:      	cmpq	0x28(%rsp), %rdx
     7e3:      	je	0x94f <execve_send+0x5ef>
     7e9:      	movl	$0x4, %eax
     7ee:      	leaq	0x70(%rsp), %rdi
     7f3:      	movl	$0x8, %esi
     7f8:      	callq	*%rax
     7fa:      	cmpq	0x70(%rsp), %r15
     7ff:      	je	0x900 <execve_send+0x5a0>
     805:      	leaq	0x18(%r15), %r12
     809:      	movl	$0x4, %eax
     80e:      	movq	%rbp, %rdi
     811:      	movl	$0x8, %esi
     816:      	movq	%r12, %rdx
     819:      	callq	*%rax
     81b:      	cmpq	%r15, 0x8(%rsp)
     820:      	je	0x900 <execve_send+0x5a0>
     826:      	movl	$0x4, %eax
     82b:      	leaq	0x68(%rsp), %rdi
     830:      	movl	$0x8, %esi
     835:      	movq	%r12, %rdx
     838:      	callq	*%rax
     83a:      	addq	$0x20, %r15
     83e:      	movl	$0x4, %eax
     843:      	leaq	0x10(%rsp), %rdi
     848:      	movl	$0x10, %ecx
     84d:      	movl	$0x10, %esi
     852:      	movq	%r15, %rdx
     855:      	callq	*%rax
     857:      	movq	0x30(%rsp), %r14
     85c:      	movq	0x50(%rsp), %rax
     861:      	movl	0x14(%rsp), %r15d
     866:      	subq	%r14, %rax
     869:      	movl	0x58(%rsp), %r12d
     86e:      	movl	%r15d, %edx
     871:      	subl	%r12d, %edx
     874:      	movl	$0x0, %ecx
     879:      	cmovbl	%ecx, %edx
     87c:      	addq	0x18(%rsp), %rdx
     881:      	xorl	%esi, %esi
     883:      	cmpl	%r15d, %r12d
     886:      	seta	%sil
     88a:      	movl	%r15d, %ecx
     88d:      	cmovbl	%r12d, %ecx
     891:      	addl	%ecx, %esi
     893:      	movl	%r12d, %edi
     896:      	subl	%esi, %edi
     898:      	movl	%edi, 0x58(%rsp)
     89c:      	subq	%rsi, %rax
     89f:      	jb	0x98b <execve_send+0x62b>
     8a5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     8ab:      	ja	0x98b <execve_send+0x62b>
     8b1:      	cmpl	%r15d, %r12d
     8b4:      	jbe	0x8bb <execve_send+0x55b>
     8b6:      	movb	$0x2f, (%r14,%rax)
     8bb:      	xorl	%edi, %edi
     8bd:      	cmpl	%r15d, %r12d
     8c0:      	seta	%dil
     8c4:      	movzbl	%cl, %esi
     8c7:      	addq	%rax, %r14
     8ca:      	addq	%r14, %rdi
     8cd:      	movl	$0x4, %eax
     8d2:      	callq	*%rax
     8d4:      	movq	%r14, 0x50(%rsp)
     8d9:      	cmpl	%r15d, %r12d
     8dc:      	jbe	0x98b <execve_send+0x62b>
     8e2:      	movq	0x68(%rsp), %rax
     8e7:      	movq	%rax, 0x38(%rsp)
     8ec:      	jmp	0x7c0 <execve_send+0x460>
     8f1:      	nopw	%cs:(%rax,%rax)
     900:      	leaq	0x10(%r14), %rdx
     904:      	movl	$0x4, %eax
     909:      	movq	%rbp, %rdi
     90c:      	movl	$0x8, %esi
     911:      	callq	*%rax
     913:      	movq	0x48(%rsp), %rax
     918:      	cmpq	0x8(%rsp), %rax
     91d:      	je	0x986 <execve_send+0x626>
     91f:      	addq	$0x18, %r14
     923:      	movl	$0x4, %eax
     928:      	leaq	0x38(%rsp), %rdi
     92d:      	movl	$0x8, %esi
     932:      	movq	%r14, %rdx
     935:      	callq	*%rax
     937:      	movq	0x8(%rsp), %rax
     93c:      	movq	%rax, 0x48(%rsp)
     941:      	addq	$0x20, %rax
     945:      	movq	%rax, 0x40(%rsp)
     94a:      	jmp	0x7c0 <execve_send+0x460>
     94f:      	movb	$0x1, 0x5c(%rsp)
     954:      	movq	0x50(%rsp), %r14
     959:      	movq	0x60(%rsp), %rcx
     95e:      	cmpq	%rcx, %r14
     961:      	jne	0x99a <execve_send+0x63a>
     963:      	movq	0x80(%rsp), %rbp
     96b:      	movl	$0x0, 0x1840(%rbp)
     975:      	movl	$0x0, 0x1844(%rbp)
     97f:      	xorl	%eax, %eax
     981:      	movq	%rcx, %r14
     984:      	jmp	0x9da <execve_send+0x67a>
     986:      	movb	$0x1, 0x5c(%rsp)
     98b:      	movq	0x50(%rsp), %r14
     990:      	movq	0x60(%rsp), %rcx
     995:      	cmpq	%rcx, %r14
     998:      	je	0x963 <execve_send+0x603>
     99a:      	xorl	%ecx, %ecx
     99c:      	cmpb	$0x0, 0x5c(%rsp)
     9a1:      	sete	%cl
     9a4:      	addl	%ecx, %ecx
     9a6:      	movl	0x58(%rsp), %eax
     9aa:      	movq	0x80(%rsp), %rbp
     9b2:      	movl	%eax, 0x1840(%rbp)
     9b8:      	movl	%ecx, 0x1844(%rbp)
     9be:      	testl	%eax, %eax
     9c0:      	jle	0x9d1 <execve_send+0x671>
     9c2:      	movl	$0x1000, %ecx           # imm = 0x1000
     9c7:      	subl	%eax, %ecx
     9c9:      	movl	%ecx, 0x1840(%rbp)
     9cf:      	movl	%ecx, %eax
     9d1:      	testq	%r14, %r14
     9d4:      	je	0xaf1 <execve_send+0x791>
     9da:      	xorl	%ecx, %ecx
     9dc:      	movl	%eax, %ebx
     9de:      	subl	$0x7f, %ebx
     9e1:      	movl	$0x7f, %r15d
     9e7:      	cmovbl	%eax, %r15d
     9eb:      	cmovbl	%ecx, %ebx
     9ee:      	cmpl	$0xff, %eax
     9f3:      	movl	$0xff, %ecx
     9f8:      	cmovbl	%eax, %ecx
     9fb:      	movzbl	%cl, %esi
     9fe:      	movl	%esi, 0x1840(%rbp)
     a04:      	movl	$0x4, %eax
     a09:      	movq	0x88(%rsp), %rdi
     a11:      	movq	%r14, %rdx
     a14:      	callq	*%rax
     a16:      	testq	%rax, %rax
     a19:      	je	0xa78 <execve_send+0x718>
     a1b:      	negl	%eax
     a1d:      	movw	%ax, 0x20(%rsp)
     a22:      	movw	$0x8, 0x22(%rsp)
     a29:      	movabsq	$0x4000002de, %rax      # imm = 0x4000002DE
     a33:      	movq	%rax, 0x24(%rsp)
     a38:      	movq	(%rip), %rdi            # 0xa3f <execve_send+0x6df>
     a3f:      	leaq	0x20(%rsp), %rsi
     a44:      	movl	$0x1, %eax
     a49:      	callq	*%rax
     a4b:      	testq	%rax, %rax
     a4e:      	je	0xa54 <execve_send+0x6f4>
     a50:      	incl	(%rax)
     a52:      	jmp	0xa78 <execve_send+0x718>
     a54:      	movl	$0x1, 0x10(%rsp)
     a5c:      	movq	(%rip), %rdi            # 0xa63 <execve_send+0x703>
     a63:      	xorl	%ecx, %ecx
     a65:      	leaq	0x20(%rsp), %rsi
     a6a:      	leaq	0x10(%rsp), %rdx
     a6f:      	movl	$0x2, %eax
     a74:      	xorl	%ecx, %ecx
     a76:      	callq	*%rax
     a78:      	leaq	0x17c0(%rbp), %rdi
     a7f:      	addq	%rbx, %r14
     a82:      	movl	$0x4, %eax
     a87:      	movl	%r15d, %esi
     a8a:      	movq	%r14, %rdx
     a8d:      	callq	*%rax
     a8f:      	testq	%rax, %rax
     a92:      	je	0xaf1 <execve_send+0x791>
     a94:      	negl	%eax
     a96:      	movw	%ax, 0x20(%rsp)
     a9b:      	movw	$0x8, 0x22(%rsp)
     aa2:      	movabsq	$0x4000002e0, %rax      # imm = 0x4000002E0
     aac:      	movq	%rax, 0x24(%rsp)
     ab1:      	movq	(%rip), %rdi            # 0xab8 <execve_send+0x758>
     ab8:      	leaq	0x20(%rsp), %rsi
     abd:      	movl	$0x1, %eax
     ac2:      	callq	*%rax
     ac4:      	testq	%rax, %rax
     ac7:      	je	0xacd <execve_send+0x76d>
     ac9:      	incl	(%rax)
     acb:      	jmp	0xaf1 <execve_send+0x791>
     acd:      	movl	$0x1, 0x10(%rsp)
     ad5:      	movq	(%rip), %rdi            # 0xadc <execve_send+0x77c>
     adc:      	xorl	%ecx, %ecx
     ade:      	leaq	0x20(%rsp), %rsi
     ae3:      	leaq	0x10(%rsp), %rdx
     ae8:      	movl	$0x2, %eax
     aed:      	xorl	%ecx, %ecx
     aef:      	callq	*%rax
     af1:      	movl	$0xe, %eax
     af6:      	callq	*%rax
     af8:      	shrq	$0x20, %rax
     afc:      	movl	%eax, 0x20(%rsp)
     b00:      	movq	(%rip), %rdi            # 0xb07 <execve_send+0x7a7>
     b07:      	leaq	0x20(%rsp), %rsi
     b0c:      	movl	$0x1, %eax
     b11:      	callq	*%rax
     b13:      	testq	%rax, %rax
     b16:      	je	0x1354 <execve_send+0xff4>
     b1c:      	movq	%rax, %r12
     b1f:      	movq	(%rax), %rax
     b22:      	movq	0x8(%r12), %rcx
     b27:      	movq	%rcx, 0x138(%rbp)
     b2e:      	movq	%rax, 0x130(%rbp)
     b35:      	movl	0x20(%r12), %eax
     b3a:      	movl	0x144(%rbp), %ecx
     b40:      	movl	%ecx, (%r12)
     b44:      	movq	0x170(%rbp), %rcx
     b4b:      	movq	%rcx, 0x8(%r12)
     b50:      	movl	0x14c(%rbp), %ecx
     b56:      	movl	%ecx, 0x24(%r12)
     b5b:      	movq	0xa0(%rbp), %rdx
     b62:      	movq	0xa8(%rbp), %rsi
     b69:      	movq	%rdx, 0x10(%r12)
     b6e:      	movq	%rsi, 0x18(%r12)
     b73:      	testb	$0x1, %al
     b75:      	je	0xb7e <execve_send+0x81e>
     b77:      	orb	$0x40, 0x15d(%rbp)
     b7e:      	movl	%eax, %edx
     b80:      	andl	$-0x2, %edx
     b83:      	movl	%edx, %esi
     b85:      	orl	$0x2000000, %esi        # imm = 0x2000000
     b8b:      	cmpl	$0x1, %ecx
     b8e:      	cmovnel	%edx, %esi
     b91:      	movl	%esi, 0x20(%r12)
     b96:      	testl	$0x2000000, %esi        # imm = 0x2000000
     b9c:      	jne	0xc14 <execve_send+0x8b4>
     b9e:      	cmpl	$0x1, %eax
     ba1:      	jne	0xc20 <execve_send+0x8c0>
     ba3:      	movq	0x128(%rbp), %rax
     baa:      	movq	%rax, 0x48(%r12)
     baf:      	movq	0x120(%rbp), %rax
     bb6:      	movq	%rax, 0x40(%r12)
     bbb:      	movq	0x118(%rbp), %rax
     bc2:      	movq	%rax, 0x38(%r12)
     bc7:      	movq	0x108(%rbp), %rax
     bce:      	movq	0x110(%rbp), %rcx
     bd5:      	movq	%rcx, 0x30(%r12)
     bda:      	movq	%rax, 0x28(%r12)
     bdf:      	movq	0xe0(%rbp), %rax
     be6:      	movq	%rax, 0x50(%r12)
     beb:      	movq	0xe8(%rbp), %rax
     bf2:      	movq	%rax, 0x58(%r12)
     bf7:      	movq	0xf0(%rbp), %rax
     bfe:      	movq	%rax, 0x60(%r12)
     c03:      	movq	(%rip), %rax            # 0xc0a <execve_send+0x8aa>
     c0a:      	cmpb	$0x0, (%rax)
     c0d:      	jne	0xc30 <execve_send+0x8d0>
     c0f:      	jmp	0xed6 <execve_send+0xb76>
     c14:      	orb	$0x2, 0x15f(%rbp)
     c1b:      	cmpl	$0x1, %eax
     c1e:      	je	0xba3 <execve_send+0x843>
     c20:      	movq	(%rip), %rax            # 0xc27 <execve_send+0x8c7>
     c27:      	cmpb	$0x0, (%rax)
     c2a:      	je	0xed6 <execve_send+0xb76>
     c30:      	movl	$0x0, 0x68(%rsp)
     c38:      	movq	(%rip), %rdi            # 0xc3f <execve_send+0x8df>
     c3f:      	leaq	0x68(%rsp), %rsi
     c44:      	movl	$0x1, %eax
     c49:      	callq	*%rax
     c4b:      	testq	%rax, %rax
     c4e:      	je	0xed6 <execve_send+0xb76>
     c54:      	testb	$0x40, 0x15d(%rbp)
     c5b:      	jne	0xc8b <execve_send+0x92b>
     c5d:      	leaq	0x68(%r12), %rsi
     c62:      	movl	$0x318, %edx            # imm = 0x318
     c67:      	movq	%rax, %rdi
     c6a:      	movq	%rax, %rbx
     c6d:      	callq	0xc72 <execve_send+0x912>
     c72:      	movq	(%rip), %rdi            # 0xc79 <execve_send+0x919>
     c79:      	xorl	%ecx, %ecx
     c7b:      	movl	$0x2, %eax
     c80:      	movq	%r12, %rsi
     c83:      	movq	%rbx, %rdx
     c86:      	jmp	0xed2 <execve_send+0xb72>
     c8b:      	movl	$0x23, %eax
     c90:      	callq	*%rax
     c92:      	movq	%rax, %rcx
     c95:      	movq	%rax, 0x20(%rsp)
     c9a:      	addq	$0xb00, %rcx            # imm = 0xB00
     ca1:      	leaq	0x20(%rsp), %rdi
     ca6:      	movl	$0x8, %edx
     cab:      	movl	$0x71, %eax
     cb0:      	movl	$0xb00, %edx            # imm = 0xB00
     cb5:      	addq	0x20(%rsp), %rdx
     cba:      	movl	$0x8, %esi
     cbf:      	callq	*%rax
     cc1:      	movq	0x20(%rsp), %rcx
     cc6:      	testq	%rcx, %rcx
     cc9:      	je	0xed6 <execve_send+0xb76>
     ccf:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     cd6:      	leaq	0x8(%rsp), %rdi
     cdb:      	movl	$0x4, %edx
     ce0:      	movl	$0x71, %eax
     ce5:      	movl	$0xaf4, %edx            # imm = 0xAF4
     cea:      	addq	0x20(%rsp), %rdx
     cef:      	movl	$0x4, %esi
     cf4:      	callq	*%rax
     cf6:      	movl	0x8(%rsp), %eax
     cfa:      	movl	%eax, 0x10(%rsp)
     cfe:      	movq	(%rip), %rdi            # 0xd05 <execve_send+0x9a5>
     d05:      	leaq	0x10(%rsp), %rsi
     d0a:      	movl	$0x1, %eax
     d0f:      	callq	*%rax
     d11:      	testq	%rax, %rax
     d14:      	je	0xd24 <execve_send+0x9c4>
     d16:      	movq	%rax, %rdx
     d19:      	cmpq	$0x0, 0x8(%rax)
     d1e:      	jne	0xebd <execve_send+0xb5d>
     d24:      	movl	$0xb00, %edx            # imm = 0xB00
     d29:      	movq	0x20(%rsp), %rcx
     d2e:      	addq	%rdx, %rcx
     d31:      	leaq	0x20(%rsp), %rdi
     d36:      	movl	$0x8, %esi
     d3b:      	movl	$0x71, %eax
     d40:      	addq	0x20(%rsp), %rdx
     d45:      	movl	$0x8, %esi
     d4a:      	callq	*%rax
     d4c:      	movq	0x20(%rsp), %rcx
     d51:      	testq	%rcx, %rcx
     d54:      	je	0xed6 <execve_send+0xb76>
     d5a:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     d61:      	leaq	0x8(%rsp), %rdi
     d66:      	movl	$0x4, %edx
     d6b:      	movl	$0x71, %eax
     d70:      	movl	$0xaf4, %edx            # imm = 0xAF4
     d75:      	addq	0x20(%rsp), %rdx
     d7a:      	movl	$0x4, %esi
     d7f:      	callq	*%rax
     d81:      	movl	0x8(%rsp), %eax
     d85:      	movl	%eax, 0x10(%rsp)
     d89:      	movq	(%rip), %rdi            # 0xd90 <execve_send+0xa30>
     d90:      	leaq	0x10(%rsp), %rsi
     d95:      	movl	$0x1, %eax
     d9a:      	callq	*%rax
     d9c:      	testq	%rax, %rax
     d9f:      	je	0xdaf <execve_send+0xa4f>
     da1:      	movq	%rax, %rdx
     da4:      	cmpq	$0x0, 0x8(%rax)
     da9:      	jne	0xebd <execve_send+0xb5d>
     daf:      	movl	$0xb00, %edx            # imm = 0xB00
     db4:      	movq	0x20(%rsp), %rcx
     db9:      	addq	%rdx, %rcx
     dbc:      	leaq	0x20(%rsp), %rdi
     dc1:      	movl	$0x8, %esi
     dc6:      	movl	$0x71, %eax
     dcb:      	addq	0x20(%rsp), %rdx
     dd0:      	movl	$0x8, %esi
     dd5:      	callq	*%rax
     dd7:      	movq	0x20(%rsp), %rcx
     ddc:      	testq	%rcx, %rcx
     ddf:      	je	0xed6 <execve_send+0xb76>
     de5:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     dec:      	leaq	0x8(%rsp), %rdi
     df1:      	movl	$0x4, %edx
     df6:      	movl	$0x71, %eax
     dfb:      	movl	$0xaf4, %edx            # imm = 0xAF4
     e00:      	addq	0x20(%rsp), %rdx
     e05:      	movl	$0x4, %esi
     e0a:      	callq	*%rax
     e0c:      	movl	0x8(%rsp), %eax
     e10:      	movl	%eax, 0x10(%rsp)
     e14:      	movq	(%rip), %rdi            # 0xe1b <execve_send+0xabb>
     e1b:      	leaq	0x10(%rsp), %rsi
     e20:      	movl	$0x1, %eax
     e25:      	callq	*%rax
     e27:      	testq	%rax, %rax
     e2a:      	je	0xe3a <execve_send+0xada>
     e2c:      	movq	%rax, %rdx
     e2f:      	cmpq	$0x0, 0x8(%rax)
     e34:      	jne	0xebd <execve_send+0xb5d>
     e3a:      	movl	$0xb00, %edx            # imm = 0xB00
     e3f:      	movq	0x20(%rsp), %rcx
     e44:      	addq	%rdx, %rcx
     e47:      	leaq	0x20(%rsp), %rdi
     e4c:      	movl	$0x8, %esi
     e51:      	movl	$0x71, %eax
     e56:      	addq	0x20(%rsp), %rdx
     e5b:      	movl	$0x8, %esi
     e60:      	callq	*%rax
     e62:      	movq	0x20(%rsp), %rcx
     e67:      	testq	%rcx, %rcx
     e6a:      	je	0xed6 <execve_send+0xb76>
     e6c:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     e73:      	leaq	0x8(%rsp), %rdi
     e78:      	movl	$0x4, %edx
     e7d:      	movl	$0x71, %eax
     e82:      	movl	$0xaf4, %edx            # imm = 0xAF4
     e87:      	addq	0x20(%rsp), %rdx
     e8c:      	movl	$0x4, %esi
     e91:      	callq	*%rax
     e93:      	movl	0x8(%rsp), %eax
     e97:      	movl	%eax, 0x10(%rsp)
     e9b:      	movq	(%rip), %rdi            # 0xea2 <execve_send+0xb42>
     ea2:      	leaq	0x10(%rsp), %rsi
     ea7:      	movl	$0x1, %eax
     eac:      	callq	*%rax
     eae:      	testq	%rax, %rax
     eb1:      	je	0xed6 <execve_send+0xb76>
     eb3:      	movq	%rax, %rdx
     eb6:      	cmpq	$0x0, 0x8(%rax)
     ebb:      	je	0xed6 <execve_send+0xb76>
     ebd:      	addq	$0x68, %rdx
     ec1:      	movq	(%rip), %rdi            # 0xec8 <execve_send+0xb68>
     ec8:      	xorl	%ecx, %ecx
     eca:      	movl	$0x2, %eax
     ecf:      	movq	%r12, %rsi
     ed2:      	xorl	%ecx, %ecx
     ed4:      	callq	*%rax
     ed6:      	leaq	0x140(%rbp), %r13
     edd:      	leaq	0x68(%r12), %r14
     ee2:      	movl	$0x308, %edx            # imm = 0x308
     ee7:      	movq	%r14, %rdi
     eea:      	xorl	%esi, %esi
     eec:      	callq	0xef1 <execve_send+0xb91>
     ef1:      	movl	0x1840(%rbp), %eax
     ef7:      	leal	-0x101(%rax), %ecx
     efd:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
     f03:      	ja	0xf11 <execve_send+0xbb1>
     f05:      	movl	$0xffffffff, (%r14)     # imm = 0xFFFFFFFF
     f0c:      	jmp	0x1058 <execve_send+0xcf8>
     f11:      	movzbl	%al, %r14d
     f15:      	leaq	0x70(%r12), %rdi
     f1a:      	movl	$0x4, %eax
     f1f:      	movq	0x88(%rsp), %rdx
     f27:      	movl	%r14d, %esi
     f2a:      	callq	*%rax
     f2c:      	movq	%rax, %r15
     f2f:      	testq	%rax, %rax
     f32:      	je	0xfc4 <execve_send+0xc64>
     f38:      	movl	%r15d, %eax
     f3b:      	negl	%eax
     f3d:      	movw	%ax, 0x20(%rsp)
     f42:      	movw	$0xf, 0x22(%rsp)
     f49:      	movabsq	$0x400000164, %rax      # imm = 0x400000164
     f53:      	movq	%rax, 0x24(%rsp)
     f58:      	movq	(%rip), %rdi            # 0xf5f <execve_send+0xbff>
     f5f:      	leaq	0x20(%rsp), %rsi
     f64:      	movl	$0x1, %eax
     f69:      	callq	*%rax
     f6b:      	testq	%rax, %rax
     f6e:      	je	0xfa0 <execve_send+0xc40>
     f70:      	incl	(%rax)
     f72:      	jmp	0xfc4 <execve_send+0xc64>
     f74:      	movq	%r12, %rcx
     f77:      	addq	$0xff6, %rcx            # imm = 0xFF6
     f7e:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
     f88:      	movq	%rax, 0xff6(%r12)
     f90:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
     f9b:      	jmp	0x4c1 <execve_send+0x161>
     fa0:      	movl	$0x1, 0x10(%rsp)
     fa8:      	movq	(%rip), %rdi            # 0xfaf <execve_send+0xc4f>
     faf:      	xorl	%ecx, %ecx
     fb1:      	leaq	0x20(%rsp), %rsi
     fb6:      	leaq	0x10(%rsp), %rdx
     fbb:      	movl	$0x2, %eax
     fc0:      	xorl	%ecx, %ecx
     fc2:      	callq	*%rax
     fc4:      	testl	%r15d, %r15d
     fc7:      	cmovel	%r14d, %r15d
     fcb:      	movl	%r15d, 0x68(%r12)
     fd0:      	cmpl	$0x7f, %r14d
     fd4:      	movl	$0x7f, %esi
     fd9:      	cmovbl	%r14d, %esi
     fdd:      	leaq	0x170(%r12), %rdi
     fe5:      	movq	%rbp, %rdx
     fe8:      	addq	$0x17c0, %rdx           # imm = 0x17C0
     fef:      	movl	$0x4, %eax
     ff4:      	callq	*%rax
     ff6:      	testq	%rax, %rax
     ff9:      	je	0x1058 <execve_send+0xcf8>
     ffb:      	negl	%eax
     ffd:      	movw	%ax, 0x20(%rsp)
    1002:      	movw	$0xf, 0x22(%rsp)
    1009:      	movabsq	$0x40000016a, %rax      # imm = 0x40000016A
    1013:      	movq	%rax, 0x24(%rsp)
    1018:      	movq	(%rip), %rdi            # 0x101f <execve_send+0xcbf>
    101f:      	leaq	0x20(%rsp), %rsi
    1024:      	movl	$0x1, %eax
    1029:      	callq	*%rax
    102b:      	testq	%rax, %rax
    102e:      	je	0x1034 <execve_send+0xcd4>
    1030:      	incl	(%rax)
    1032:      	jmp	0x1058 <execve_send+0xcf8>
    1034:      	movl	$0x1, 0x10(%rsp)
    103c:      	movq	(%rip), %rdi            # 0x1043 <execve_send+0xce3>
    1043:      	xorl	%ecx, %ecx
    1045:      	leaq	0x20(%rsp), %rsi
    104a:      	leaq	0x10(%rsp), %rdx
    104f:      	movl	$0x2, %eax
    1054:      	xorl	%ecx, %ecx
    1056:      	callq	*%rax
    1058:      	movl	0x1848(%rbp), %eax
    105e:      	movl	0x184c(%rbp), %ecx
    1064:      	cmpl	$0xfe, %eax
    1069:      	movl	$0xfe, %r14d
    106f:      	cmovbl	%eax, %r14d
    1073:      	leaq	0x270(%r12), %rdi
    107b:      	addq	%rcx, %r13
    107e:      	movl	$0x4, %eax
    1083:      	movl	%r14d, %esi
    1086:      	movq	%r13, %rdx
    1089:      	callq	*%rax
    108b:      	testq	%rax, %rax
    108e:      	je	0x10ed <execve_send+0xd8d>
    1090:      	negl	%eax
    1092:      	movw	%ax, 0x20(%rsp)
    1097:      	movw	$0x9, 0x22(%rsp)
    109e:      	movabsq	$0x4000001af, %rax      # imm = 0x4000001AF
    10a8:      	movq	%rax, 0x24(%rsp)
    10ad:      	movq	(%rip), %rdi            # 0x10b4 <execve_send+0xd54>
    10b4:      	leaq	0x20(%rsp), %rsi
    10b9:      	movl	$0x1, %eax
    10be:      	callq	*%rax
    10c0:      	testq	%rax, %rax
    10c3:      	je	0x10c9 <execve_send+0xd69>
    10c5:      	incl	(%rax)
    10c7:      	jmp	0x10ed <execve_send+0xd8d>
    10c9:      	movl	$0x1, 0x10(%rsp)
    10d1:      	movq	(%rip), %rdi            # 0x10d8 <execve_send+0xd78>
    10d8:      	xorl	%ecx, %ecx
    10da:      	leaq	0x20(%rsp), %rsi
    10df:      	leaq	0x10(%rsp), %rdx
    10e4:      	movl	$0x2, %eax
    10e9:      	xorl	%ecx, %ecx
    10eb:      	callq	*%rax
    10ed:      	movw	$0x0, 0x270(%r12,%r14)
    10f8:      	movl	$0x23, %eax
    10fd:      	callq	*%rax
    10ff:      	movq	%rax, %rcx
    1102:      	movq	%rax, 0x20(%rsp)
    1107:      	addq	$0xb00, %rcx            # imm = 0xB00
    110e:      	leaq	0x20(%rsp), %rdi
    1113:      	movl	$0x8, %edx
    1118:      	movl	$0x71, %eax
    111d:      	movl	$0xb00, %edx            # imm = 0xB00
    1122:      	addq	0x20(%rsp), %rdx
    1127:      	movl	$0x8, %esi
    112c:      	callq	*%rax
    112e:      	movq	0x20(%rsp), %rcx
    1133:      	testq	%rcx, %rcx
    1136:      	je	0x132e <execve_send+0xfce>
    113c:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    1143:      	leaq	0x8(%rsp), %rdi
    1148:      	movl	$0x4, %edx
    114d:      	movl	$0x71, %eax
    1152:      	movl	$0xaf4, %edx            # imm = 0xAF4
    1157:      	addq	0x20(%rsp), %rdx
    115c:      	movl	$0x4, %esi
    1161:      	callq	*%rax
    1163:      	movl	0x8(%rsp), %eax
    1167:      	movl	%eax, 0x10(%rsp)
    116b:      	movq	(%rip), %rdi            # 0x1172 <execve_send+0xe12>
    1172:      	leaq	0x10(%rsp), %rsi
    1177:      	movl	$0x1, %eax
    117c:      	callq	*%rax
    117e:      	testq	%rax, %rax
    1181:      	je	0x118e <execve_send+0xe2e>
    1183:      	cmpq	$0x0, 0x8(%rax)
    1188:      	jne	0x131e <execve_send+0xfbe>
    118e:      	movl	$0xb00, %edx            # imm = 0xB00
    1193:      	movq	0x20(%rsp), %rcx
    1198:      	addq	%rdx, %rcx
    119b:      	leaq	0x20(%rsp), %rdi
    11a0:      	movl	$0x8, %esi
    11a5:      	movl	$0x71, %eax
    11aa:      	addq	0x20(%rsp), %rdx
    11af:      	movl	$0x8, %esi
    11b4:      	callq	*%rax
    11b6:      	movq	0x20(%rsp), %rcx
    11bb:      	testq	%rcx, %rcx
    11be:      	je	0x132e <execve_send+0xfce>
    11c4:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    11cb:      	leaq	0x8(%rsp), %rdi
    11d0:      	movl	$0x4, %edx
    11d5:      	movl	$0x71, %eax
    11da:      	movl	$0xaf4, %edx            # imm = 0xAF4
    11df:      	addq	0x20(%rsp), %rdx
    11e4:      	movl	$0x4, %esi
    11e9:      	callq	*%rax
    11eb:      	movl	0x8(%rsp), %eax
    11ef:      	movl	%eax, 0x10(%rsp)
    11f3:      	movq	(%rip), %rdi            # 0x11fa <execve_send+0xe9a>
    11fa:      	leaq	0x10(%rsp), %rsi
    11ff:      	movl	$0x1, %eax
    1204:      	callq	*%rax
    1206:      	testq	%rax, %rax
    1209:      	je	0x1216 <execve_send+0xeb6>
    120b:      	cmpq	$0x0, 0x8(%rax)
    1210:      	jne	0x131e <execve_send+0xfbe>
    1216:      	movl	$0xb00, %edx            # imm = 0xB00
    121b:      	movq	0x20(%rsp), %rcx
    1220:      	addq	%rdx, %rcx
    1223:      	leaq	0x20(%rsp), %rdi
    1228:      	movl	$0x8, %esi
    122d:      	movl	$0x71, %eax
    1232:      	addq	0x20(%rsp), %rdx
    1237:      	movl	$0x8, %esi
    123c:      	callq	*%rax
    123e:      	movq	0x20(%rsp), %rcx
    1243:      	testq	%rcx, %rcx
    1246:      	je	0x132e <execve_send+0xfce>
    124c:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    1253:      	leaq	0x8(%rsp), %rdi
    1258:      	movl	$0x4, %edx
    125d:      	movl	$0x71, %eax
    1262:      	movl	$0xaf4, %edx            # imm = 0xAF4
    1267:      	addq	0x20(%rsp), %rdx
    126c:      	movl	$0x4, %esi
    1271:      	callq	*%rax
    1273:      	movl	0x8(%rsp), %eax
    1277:      	movl	%eax, 0x10(%rsp)
    127b:      	movq	(%rip), %rdi            # 0x1282 <execve_send+0xf22>
    1282:      	leaq	0x10(%rsp), %rsi
    1287:      	movl	$0x1, %eax
    128c:      	callq	*%rax
    128e:      	testq	%rax, %rax
    1291:      	je	0x129e <execve_send+0xf3e>
    1293:      	cmpq	$0x0, 0x8(%rax)
    1298:      	jne	0x131e <execve_send+0xfbe>
    129e:      	movl	$0xb00, %edx            # imm = 0xB00
    12a3:      	movq	0x20(%rsp), %rcx
    12a8:      	addq	%rdx, %rcx
    12ab:      	leaq	0x20(%rsp), %rdi
    12b0:      	movl	$0x8, %esi
    12b5:      	movl	$0x71, %eax
    12ba:      	addq	0x20(%rsp), %rdx
    12bf:      	movl	$0x8, %esi
    12c4:      	callq	*%rax
    12c6:      	movq	0x20(%rsp), %rcx
    12cb:      	testq	%rcx, %rcx
    12ce:      	je	0x132e <execve_send+0xfce>
    12d0:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    12d7:      	leaq	0x8(%rsp), %rdi
    12dc:      	movl	$0x4, %edx
    12e1:      	movl	$0x71, %eax
    12e6:      	movl	$0xaf4, %edx            # imm = 0xAF4
    12eb:      	addq	0x20(%rsp), %rdx
    12f0:      	movl	$0x4, %esi
    12f5:      	callq	*%rax
    12f7:      	movl	0x8(%rsp), %eax
    12fb:      	movl	%eax, 0x10(%rsp)
    12ff:      	movq	(%rip), %rdi            # 0x1306 <execve_send+0xfa6>
    1306:      	leaq	0x10(%rsp), %rsi
    130b:      	movl	$0x1, %eax
    1310:      	callq	*%rax
    1312:      	testq	%rax, %rax
    1315:      	je	0x132e <execve_send+0xfce>
    1317:      	cmpq	$0x0, 0x8(%rax)
    131c:      	je	0x132e <execve_send+0xfce>
    131e:      	movq	0x370(%rax), %rax
    1325:      	lock
    1326:      	orq	%rax, 0x370(%r12)
    132e:      	movq	%r12, %rsi
    1331:      	addq	$0x70, %rsi
    1335:      	movq	(%rip), %rdi            # 0x133c <execve_send+0xfdc>
    133c:      	movl	$0x1, %eax
    1341:      	callq	*%rax
    1343:      	testq	%rax, %rax
    1346:      	je	0x1354 <execve_send+0xff4>
    1348:      	movq	(%rax), %rax
    134b:      	lock
    134c:      	orq	%rax, 0x370(%r12)
    1354:      	movb	$0x0, 0x1(%rbp)
    1358:      	movl	0x140(%rbp), %eax
    135e:      	cmpl	$0x1710, %eax           # imm = 0x1710
    1363:      	movl	$0x1710, %r14d          # imm = 0x1710
    1369:      	cmovbl	%eax, %r14d
    136d:      	movl	$0x0, 0x10(%rsp)
    1375:      	movq	(%rip), %rdi            # 0x137c <execve_send+0x101c>
    137c:      	leaq	0x10(%rsp), %rsi
    1381:      	movl	$0x1, %eax
    1386:      	addl	$0x140, %r14d           # imm = 0x140
    138d:      	callq	*%rax
    138f:      	testq	%rax, %rax
    1392:      	je	0x1419 <execve_send+0x10b9>
    1398:      	cmpb	$0x0, 0x28(%rax)
    139c:      	je	0x1419 <execve_send+0x10b9>
    139e:      	movq	(%rip), %rsi            # 0x13a5 <execve_send+0x1045>
    13a5:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    13aa:      	movl	$0x19, %eax
    13af:      	movq	0x90(%rsp), %rdi
    13b7:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    13bc:      	movq	%rbp, %rcx
    13bf:      	movq	%r14, %r8
    13c2:      	callq	*%rax
    13c4:      	testq	%rax, %rax
    13c7:      	jns	0x14cb <execve_send+0x116b>
    13cd:      	movq	%rax, %rbx
    13d0:      	movl	$0x0, 0x20(%rsp)
    13d8:      	movq	(%rip), %rdi            # 0x13df <execve_send+0x107f>
    13df:      	leaq	0x20(%rsp), %rsi
    13e4:      	movl	$0x1, %eax
    13e9:      	callq	*%rax
    13eb:      	testq	%rax, %rax
    13ee:      	je	0x14cb <execve_send+0x116b>
    13f4:      	cmpq	$-0xc, %rbx
    13f8:      	jg	0x1497 <execve_send+0x1137>
    13fe:      	cmpq	$-0x1c, %rbx
    1402:      	je	0x14b1 <execve_send+0x1151>
    1408:      	cmpq	$-0x16, %rbx
    140c:      	jne	0x146f <execve_send+0x110f>
    140e:      	addq	$0x138, %rax            # imm = 0x138
    1414:      	jmp	0x14c7 <execve_send+0x1167>
    1419:      	movq	(%rip), %rdi            # 0x1420 <execve_send+0x10c0>
    1420:      	xorl	%ecx, %ecx
    1422:      	movl	$0x82, %eax
    1427:      	movq	%rbp, %rsi
    142a:      	movq	%r14, %rdx
    142d:      	xorl	%ecx, %ecx
    142f:      	callq	*%rax
    1431:      	testq	%rax, %rax
    1434:      	jns	0x14cb <execve_send+0x116b>
    143a:      	movq	%rax, %rbx
    143d:      	movl	$0x0, 0x20(%rsp)
    1445:      	movq	(%rip), %rdi            # 0x144c <execve_send+0x10ec>
    144c:      	leaq	0x20(%rsp), %rsi
    1451:      	movl	$0x1, %eax
    1456:      	callq	*%rax
    1458:      	testq	%rax, %rax
    145b:      	je	0x14cb <execve_send+0x116b>
    145d:      	cmpq	$-0xc, %rbx
    1461:      	jg	0x147d <execve_send+0x111d>
    1463:      	cmpq	$-0x1c, %rbx
    1467:      	je	0x14b1 <execve_send+0x1151>
    1469:      	cmpq	$-0x16, %rbx
    146d:      	je	0x140e <execve_send+0x10ae>
    146f:      	cmpq	$-0x10, %rbx
    1473:      	jne	0x14a9 <execve_send+0x1149>
    1475:      	addq	$0x130, %rax            # imm = 0x130
    147b:      	jmp	0x14c7 <execve_send+0x1167>
    147d:      	cmpq	$-0xb, %rbx
    1481:      	je	0x14b9 <execve_send+0x1159>
    1483:      	cmpq	$-0x7, %rbx
    1487:      	je	0x14c1 <execve_send+0x1161>
    1489:      	cmpq	$-0x2, %rbx
    148d:      	jne	0x14a9 <execve_send+0x1149>
    148f:      	addq	$0x120, %rax            # imm = 0x120
    1495:      	jmp	0x14c7 <execve_send+0x1167>
    1497:      	cmpq	$-0xb, %rbx
    149b:      	je	0x14b9 <execve_send+0x1159>
    149d:      	cmpq	$-0x7, %rbx
    14a1:      	je	0x14c1 <execve_send+0x1161>
    14a3:      	cmpq	$-0x2, %rbx
    14a7:      	je	0x148f <execve_send+0x112f>
    14a9:      	addq	$0x118, %rax            # imm = 0x118
    14af:      	jmp	0x14c7 <execve_send+0x1167>
    14b1:      	addq	$0x140, %rax            # imm = 0x140
    14b7:      	jmp	0x14c7 <execve_send+0x1167>
    14b9:      	addq	$0x148, %rax            # imm = 0x148
    14bf:      	jmp	0x14c7 <execve_send+0x1167>
    14c1:      	addq	$0x128, %rax            # imm = 0x128
    14c7:      	lock
    14c8:      	incq	(%rax)
    14cb:      	xorl	%eax, %eax
    14cd:      	addq	$0xa8, %rsp
    14d4:      	popq	%rbx
    14d5:      	popq	%r12
    14d7:      	popq	%r13
    14d9:      	popq	%r14
    14db:      	popq	%r15
    14dd:      	popq	%rbp
    14de:      	retq

Disassembly of section tracepoint/sys_execve:

0000000000000000 <event_execve>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xd8, %rsp
      11:      	movq	%rdi, %r12
      14:      	movl	$0x23, %eax
      19:      	callq	*%rax
      1b:      	movq	%rax, 0xa0(%rsp)
      23:      	movzwl	0x8(%r12), %r15d
      29:      	movl	$0x0, 0xb0(%rsp)
      34:      	movq	(%rip), %rdi            # 0x3b <event_execve+0x3b>
      3b:      	leaq	0xb0(%rsp), %rsi
      43:      	movl	$0x1, %eax
      48:      	callq	*%rax
      4a:      	testq	%rax, %rax
      4d:      	je	0x2b35 <event_execve+0x2b35>
      53:      	movq	%rax, %r14
      56:      	movl	$0xe, %eax
      5b:      	callq	*%rax
      5d:      	movq	%rax, %r13
      60:      	movl	$0x23, %eax
      65:      	callq	*%rax
      67:      	movq	%rax, %rcx
      6a:      	movq	%rax, 0x28(%rsp)
      6f:      	addq	$0xb00, %rcx            # imm = 0xB00
      76:      	leaq	0x28(%rsp), %rdi
      7b:      	movl	$0x8, %edx
      80:      	movl	$0x71, %eax
      85:      	movl	$0xb00, %edx            # imm = 0xB00
      8a:      	addq	0x28(%rsp), %rdx
      8f:      	movl	$0x8, %esi
      94:      	callq	*%rax
      96:      	movq	0x28(%rsp), %rcx
      9b:      	testq	%rcx, %rcx
      9e:      	movq	%r12, 0x10(%rsp)
      a3:      	movq	%r14, 0x20(%rsp)
      a8:      	je	0x383 <event_execve+0x383>
      ae:      	addq	$0xaf4, %rcx            # imm = 0xAF4
      b5:      	leaq	0x18(%rsp), %rdi
      ba:      	movl	$0x4, %edx
      bf:      	movl	$0x71, %eax
      c4:      	movl	$0xaf4, %edx            # imm = 0xAF4
      c9:      	addq	0x28(%rsp), %rdx
      ce:      	movl	$0x4, %esi
      d3:      	callq	*%rax
      d5:      	movl	0x18(%rsp), %eax
      d9:      	movl	%eax, (%rsp)
      dc:      	movq	(%rip), %rdi            # 0xe3 <event_execve+0xe3>
      e3:      	movq	%rsp, %rsi
      e6:      	movl	$0x1, %eax
      eb:      	callq	*%rax
      ed:      	testq	%rax, %rax
      f0:      	je	0x100 <event_execve+0x100>
      f2:      	movq	%rax, %rbx
      f5:      	cmpq	$0x0, 0x8(%rax)
      fa:      	jne	0x29c <event_execve+0x29c>
     100:      	movl	$0xb00, %edx            # imm = 0xB00
     105:      	movq	0x28(%rsp), %rcx
     10a:      	addq	%rdx, %rcx
     10d:      	leaq	0x28(%rsp), %rdi
     112:      	movl	$0x8, %esi
     117:      	movl	$0x71, %eax
     11c:      	addq	0x28(%rsp), %rdx
     121:      	movl	$0x8, %esi
     126:      	callq	*%rax
     128:      	movq	0x28(%rsp), %rcx
     12d:      	testq	%rcx, %rcx
     130:      	je	0x383 <event_execve+0x383>
     136:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     13d:      	leaq	0x18(%rsp), %rdi
     142:      	movl	$0x4, %edx
     147:      	movl	$0x71, %eax
     14c:      	movl	$0xaf4, %edx            # imm = 0xAF4
     151:      	addq	0x28(%rsp), %rdx
     156:      	movl	$0x4, %esi
     15b:      	callq	*%rax
     15d:      	movl	0x18(%rsp), %eax
     161:      	movl	%eax, (%rsp)
     164:      	movq	(%rip), %rdi            # 0x16b <event_execve+0x16b>
     16b:      	movq	%rsp, %rsi
     16e:      	movl	$0x1, %eax
     173:      	callq	*%rax
     175:      	testq	%rax, %rax
     178:      	je	0x188 <event_execve+0x188>
     17a:      	movq	%rax, %rbx
     17d:      	cmpq	$0x0, 0x8(%rax)
     182:      	jne	0x29c <event_execve+0x29c>
     188:      	movl	$0xb00, %edx            # imm = 0xB00
     18d:      	movq	0x28(%rsp), %rcx
     192:      	addq	%rdx, %rcx
     195:      	leaq	0x28(%rsp), %rdi
     19a:      	movl	$0x8, %esi
     19f:      	movl	$0x71, %eax
     1a4:      	addq	0x28(%rsp), %rdx
     1a9:      	movl	$0x8, %esi
     1ae:      	callq	*%rax
     1b0:      	movq	0x28(%rsp), %rcx
     1b5:      	testq	%rcx, %rcx
     1b8:      	je	0x383 <event_execve+0x383>
     1be:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     1c5:      	leaq	0x18(%rsp), %rdi
     1ca:      	movl	$0x4, %edx
     1cf:      	movl	$0x71, %eax
     1d4:      	movl	$0xaf4, %edx            # imm = 0xAF4
     1d9:      	addq	0x28(%rsp), %rdx
     1de:      	movl	$0x4, %esi
     1e3:      	callq	*%rax
     1e5:      	movl	0x18(%rsp), %eax
     1e9:      	movl	%eax, (%rsp)
     1ec:      	movq	(%rip), %rdi            # 0x1f3 <event_execve+0x1f3>
     1f3:      	movq	%rsp, %rsi
     1f6:      	movl	$0x1, %eax
     1fb:      	callq	*%rax
     1fd:      	testq	%rax, %rax
     200:      	je	0x210 <event_execve+0x210>
     202:      	movq	%rax, %rbx
     205:      	cmpq	$0x0, 0x8(%rax)
     20a:      	jne	0x29c <event_execve+0x29c>
     210:      	movl	$0xb00, %edx            # imm = 0xB00
     215:      	movq	0x28(%rsp), %rcx
     21a:      	addq	%rdx, %rcx
     21d:      	leaq	0x28(%rsp), %rdi
     222:      	movl	$0x8, %esi
     227:      	movl	$0x71, %eax
     22c:      	addq	0x28(%rsp), %rdx
     231:      	movl	$0x8, %esi
     236:      	callq	*%rax
     238:      	movq	0x28(%rsp), %rcx
     23d:      	testq	%rcx, %rcx
     240:      	je	0x383 <event_execve+0x383>
     246:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     24d:      	leaq	0x18(%rsp), %rdi
     252:      	movl	$0x4, %edx
     257:      	movl	$0x71, %eax
     25c:      	movl	$0xaf4, %edx            # imm = 0xAF4
     261:      	addq	0x28(%rsp), %rdx
     266:      	movl	$0x4, %esi
     26b:      	callq	*%rax
     26d:      	movl	0x18(%rsp), %eax
     271:      	movl	%eax, (%rsp)
     274:      	movq	(%rip), %rdi            # 0x27b <event_execve+0x27b>
     27b:      	movq	%rsp, %rsi
     27e:      	movl	$0x1, %eax
     283:      	callq	*%rax
     285:      	testq	%rax, %rax
     288:      	je	0x383 <event_execve+0x383>
     28e:      	movq	%rax, %rbx
     291:      	cmpq	$0x0, 0x8(%rax)
     296:      	je	0x383 <event_execve+0x383>
     29c:      	movq	(%rbx), %rax
     29f:      	movq	0x8(%rbx), %rcx
     2a3:      	movq	%rcx, 0xa8(%r14)
     2aa:      	movq	%rax, 0xa0(%r14)
     2b1:      	movl	$0x0, (%rsp)
     2b8:      	movq	(%rip), %rdi            # 0x2bf <event_execve+0x2bf>
     2bf:      	movq	%rsp, %rsi
     2c2:      	movl	$0x1, %eax
     2c7:      	callq	*%rax
     2c9:      	testq	%rax, %rax
     2cc:      	je	0x492 <event_execve+0x492>
     2d2:      	movq	(%rax), %rcx
     2d5:      	cmpq	0x378(%rbx), %rcx
     2dc:      	je	0x492 <event_execve+0x492>
     2e2:      	movq	%r13, 0x98(%rsp)
     2ea:      	movq	%r15, 0x88(%rsp)
     2f2:      	movq	%rax, 0x80(%rsp)
     2fa:      	movq	(%rip), %rax            # 0x301 <event_execve+0x301>
     301:      	cmpb	$0x0, (%rax)
     304:      	je	0x3f3 <event_execve+0x3f3>
     30a:      	movl	$0x1869f, %r14d         # imm = 0x1869F
     310:      	xorl	%r15d, %r15d
     313:      	leaq	0x28(%rsp), %rbp
     318:      	movq	(%rip), %r12            # 0x31f <event_execve+0x31f>
     31f:      	nop
     320:      	movl	0x10(%rbx), %eax
     323:      	movl	%eax, 0x28(%rsp)
     327:      	movl	$0x1, %eax
     32c:      	movq	(%rip), %rdi            # 0x333 <event_execve+0x333>
     333:      	movq	%rbp, %rsi
     336:      	callq	*%rax
     338:      	testq	%rax, %rax
     33b:      	je	0x466 <event_execve+0x466>
     341:      	movq	%rax, %r13
     344:      	leaq	0x70(%rax), %rsi
     348:      	movl	$0x1, %eax
     34d:      	movq	%r12, %rdi
     350:      	callq	*%rax
     352:      	testq	%rax, %rax
     355:      	je	0x367 <event_execve+0x367>
     357:      	movq	(%rax), %rax
     35a:      	testq	%rax, %rax
     35d:      	je	0x367 <event_execve+0x367>
     35f:      	lock
     360:      	orq	%rax, 0x370(%rbx)
     367:      	subl	$0x1, %r14d
     36b:      	setb	%al
     36e:      	cmpq	%r15, %r13
     371:      	je	0x466 <event_execve+0x466>
     377:      	movq	%r13, %r15
     37a:      	testb	%al, %al
     37c:      	je	0x320 <event_execve+0x320>
     37e:      	jmp	0x466 <event_execve+0x466>
     383:      	movq	0xa0(%rsp), %rax
     38b:      	leaq	0xb00(%rax), %rdx
     392:      	leaq	0x28(%rsp), %rdi
     397:      	movl	$0x8, %ecx
     39c:      	movl	$0x71, %eax
     3a1:      	movl	$0x8, %esi
     3a6:      	callq	*%rax
     3a8:      	movq	0x28(%rsp), %rdx
     3ad:      	testq	%rdx, %rdx
     3b0:      	je	0x3d5 <event_execve+0x3d5>
     3b2:      	addq	$0xaf4, %rdx            # imm = 0xAF4
     3b9:      	leaq	0x28(%rsp), %rdi
     3be:      	movl	$0x4, %ecx
     3c3:      	movl	$0x71, %eax
     3c8:      	movl	$0x4, %esi
     3cd:      	callq	*%rax
     3cf:      	movl	0x28(%rsp), %eax
     3d3:      	jmp	0x3d7 <event_execve+0x3d7>
     3d5:      	xorl	%eax, %eax
     3d7:      	movl	%eax, 0xa0(%r14)
     3de:      	movq	$0x0, 0xa8(%r14)
     3e9:      	movl	$0x40, %eax
     3ee:      	jmp	0x494 <event_execve+0x494>
     3f3:      	movl	$0x3ff, %r14d           # imm = 0x3FF
     3f9:      	xorl	%r15d, %r15d
     3fc:      	leaq	0x28(%rsp), %rbp
     401:      	movq	(%rip), %r12            # 0x408 <event_execve+0x408>
     408:      	nopl	(%rax,%rax)
     410:      	movl	0x10(%rbx), %eax
     413:      	movl	%eax, 0x28(%rsp)
     417:      	movl	$0x1, %eax
     41c:      	movq	(%rip), %rdi            # 0x423 <event_execve+0x423>
     423:      	movq	%rbp, %rsi
     426:      	callq	*%rax
     428:      	testq	%rax, %rax
     42b:      	je	0x466 <event_execve+0x466>
     42d:      	movq	%rax, %r13
     430:      	leaq	0x70(%rax), %rsi
     434:      	movl	$0x1, %eax
     439:      	movq	%r12, %rdi
     43c:      	callq	*%rax
     43e:      	testq	%rax, %rax
     441:      	je	0x453 <event_execve+0x453>
     443:      	movq	(%rax), %rax
     446:      	testq	%rax, %rax
     449:      	je	0x453 <event_execve+0x453>
     44b:      	lock
     44c:      	orq	%rax, 0x370(%rbx)
     453:      	subl	$0x1, %r14d
     457:      	setb	%al
     45a:      	cmpq	%r15, %r13
     45d:      	je	0x466 <event_execve+0x466>
     45f:      	movq	%r13, %r15
     462:      	testb	%al, %al
     464:      	je	0x410 <event_execve+0x410>
     466:      	movq	0x80(%rsp), %rax
     46e:      	movq	(%rax), %rax
     471:      	movq	%rax, 0x378(%rbx)
     478:      	movq	0x10(%rsp), %r12
     47d:      	movq	0x20(%rsp), %r14
     482:      	movq	0x88(%rsp), %r15
     48a:      	movq	0x98(%rsp), %r13
     492:      	xorl	%eax, %eax
     494:      	movq	%rax, 0xb0(%r14)
     49b:      	movl	$0x1, 0x15c(%r14)
     4a6:      	movq	%r13, %rax
     4a9:      	shrq	$0x20, %rax
     4ad:      	movq	$0x0, 0x178(%r14)
     4b8:      	movl	%eax, 0x144(%r14)
     4bf:      	movl	%r13d, 0x148(%r14)
     4c6:      	movl	$0x23, %eax
     4cb:      	callq	*%rax
     4cd:      	leaq	0x60(%rax), %rdx
     4d1:      	movq	%rsp, %rdi
     4d4:      	movl	$0x8, %ecx
     4d9:      	movl	$0x71, %eax
     4de:      	movl	$0x8, %esi
     4e3:      	callq	*%rax
     4e5:      	movq	(%rsp), %rcx
     4e9:      	xorl	%ebx, %ebx
     4eb:      	testq	%rcx, %rcx
     4ee:      	je	0x55a <event_execve+0x55a>
     4f0:      	addq	$0x4, %rcx
     4f4:      	leaq	0x18(%rsp), %rdi
     4f9:      	movl	$0x4, %edx
     4fe:      	movl	$0x71, %eax
     503:      	movq	(%rsp), %rdx
     507:      	addq	$0x4, %rdx
     50b:      	movl	$0x4, %esi
     510:      	callq	*%rax
     512:      	movl	0x18(%rsp), %eax
     516:      	testl	%eax, %eax
     518:      	je	0x55a <event_execve+0x55a>
     51a:      	movq	(%rsp), %rcx
     51e:      	shll	$0x4, %eax
     521:      	addq	%rax, %rcx
     524:      	addq	$0x80, %rcx
     52b:      	leaq	0x28(%rsp), %rdi
     530:      	movl	$0x10, %edx
     535:      	movl	$0x71, %eax
     53a:      	movq	(%rsp), %rcx
     53e:      	movl	0x18(%rsp), %edx
     542:      	shll	$0x4, %edx
     545:      	addq	%rcx, %rdx
     548:      	addq	$0x80, %rdx
     54f:      	movl	$0x10, %esi
     554:      	callq	*%rax
     556:      	movl	0x28(%rsp), %ebx
     55a:      	movl	%ebx, 0x14c(%r14)
     561:      	movl	$0x7d, %eax
     566:      	callq	*%rax
     568:      	movq	%rax, 0x170(%r14)
     56f:      	movl	$0x40, 0x140(%r14)
     57a:      	movl	$0x23, %eax
     57f:      	callq	*%rax
     581:      	movq	$0x0, 0x28(%rsp)
     58a:      	testq	%rax, %rax
     58d:      	je	0x5b3 <event_execve+0x5b3>
     58f:      	movq	%rax, %rdx
     592:      	addq	$0x70, %rdx
     596:      	leaq	0x28(%rsp), %rdi
     59b:      	movl	$0x8, %ecx
     5a0:      	movl	$0x4, %eax
     5a5:      	movl	$0x8, %esi
     5aa:      	callq	*%rax
     5ac:      	movq	0x28(%rsp), %rax
     5b1:      	jmp	0x5b5 <event_execve+0x5b5>
     5b3:      	xorl	%eax, %eax
     5b5:      	movl	%eax, 0x158(%r14)
     5bc:      	movq	%r13, 0x28(%rsp)
     5c1:      	movq	(%rip), %rdi            # 0x5c8 <event_execve+0x5c8>
     5c8:      	leaq	0x28(%rsp), %rsi
     5cd:      	movl	$0x1, %eax
     5d2:      	addq	%r12, %r15
     5d5:      	callq	*%rax
     5d7:      	testq	%rax, %rax
     5da:      	je	0x638 <event_execve+0x638>
     5dc:      	movl	(%rax), %ecx
     5de:      	movl	%ecx, 0x150(%r14)
     5e5:      	movq	0x8(%rax), %rcx
     5e9:      	movq	%rcx, 0x168(%r14)
     5f0:      	movl	0x4(%rax), %eax
     5f3:      	movl	%eax, 0x160(%r14)
     5fa:      	movq	%r13, 0x28(%rsp)
     5ff:      	movq	(%rip), %rdi            # 0x606 <event_execve+0x606>
     606:      	leaq	0x28(%rsp), %rsi
     60b:      	movl	$0x3, %eax
     610:      	callq	*%rax
     612:      	testl	%eax, %eax
     614:      	je	0x65b <event_execve+0x65b>
     616:      	movl	$0x2, (%rsp)
     61d:      	movq	(%rip), %rdi            # 0x624 <event_execve+0x624>
     624:      	movq	%rsp, %rsi
     627:      	movl	$0x1, %eax
     62c:      	callq	*%rax
     62e:      	testq	%rax, %rax
     631:      	je	0x67b <event_execve+0x67b>
     633:      	incq	(%rax)
     636:      	jmp	0x67b <event_execve+0x67b>
     638:      	movl	$0x0, 0x150(%r14)
     643:      	movq	$0x0, 0x168(%r14)
     64e:      	movl	$0x0, 0x160(%r14)
     659:      	jmp	0x67b <event_execve+0x67b>
     65b:      	movl	$0x0, (%rsp)
     662:      	movq	(%rip), %rdi            # 0x669 <event_execve+0x669>
     669:      	movq	%rsp, %rsi
     66c:      	movl	$0x1, %eax
     671:      	callq	*%rax
     673:      	testq	%rax, %rax
     676:      	je	0x67b <event_execve+0x67b>
     678:      	decq	(%rax)
     67b:      	leaq	0x180(%r14), %rdi
     682:      	movl	$0xff, %ecx
     687:      	movl	$0x2d, %eax
     68c:      	movl	$0xff, %esi
     691:      	movq	%r15, %rdx
     694:      	callq	*%rax
     696:      	testl	%eax, %eax
     698:      	js	0x825 <event_execve+0x825>
     69e:      	je	0x831 <event_execve+0x831>
     6a4:      	cmpl	$0xff, %eax
     6a9:      	jne	0x838 <event_execve+0x838>
     6af:      	movl	$0x0, 0x18(%rsp)
     6b7:      	movq	(%rip), %rdi            # 0x6be <event_execve+0x6be>
     6be:      	leaq	0x18(%rsp), %rsi
     6c3:      	movl	$0x1, %eax
     6c8:      	callq	*%rax
     6ca:      	testq	%rax, %rax
     6cd:      	je	0x825 <event_execve+0x825>
     6d3:      	movq	%rax, %rbp
     6d6:      	movq	%rax, %r13
     6d9:      	movl	$0x18, (%rbp)
     6e0:      	movl	$0xe, %eax
     6e5:      	callq	*%rax
     6e7:      	leaq	0x10(%rbp), %rbx
     6eb:      	movq	%rax, 0x10(%rbp)
     6ef:      	cmpq	$-0x16, %rax
     6f3:      	jne	0x718 <event_execve+0x718>
     6f5:      	leaq	0x20(%r12), %rdx
     6fa:      	leaq	0x28(%rsp), %rdi
     6ff:      	movl	$0x8, %ecx
     704:      	movl	$0x4, %eax
     709:      	movl	$0x8, %esi
     70e:      	callq	*%rax
     710:      	movq	0x28(%rsp), %rax
     715:      	movq	%rax, (%rbx)
     718:      	movl	$0x7d, %eax
     71d:      	callq	*%rax
     71f:      	movq	%rax, 0x18(%r13)
     723:      	movq	(%rbx), %rax
     726:      	movq	0x8(%rbx), %rcx
     72a:      	movq	%rax, 0x190(%r14)
     731:      	movq	%rcx, 0x198(%r14)
     738:      	addq	$0x20, %rbp
     73c:      	movl	$0x7fdf, %ecx           # imm = 0x7FDF
     741:      	movl	$0x2d, %eax
     746:      	movq	%rbp, %rdi
     749:      	movl	$0x7fdf, %esi           # imm = 0x7FDF
     74e:      	movq	%r15, %rdx
     751:      	callq	*%rax
     753:      	movq	%rax, %rbx
     756:      	testq	%rax, %rax
     759:      	js	0xac6 <event_execve+0xac6>
     75f:      	xorl	%r12d, %r12d
     762:      	testq	%rbx, %rbx
     765:      	je	0x8a7 <event_execve+0x8a7>
     76b:      	movq	%r15, 0x88(%rsp)
     773:      	leal	0x1f(%rbx), %r15d
     777:      	andl	$0x7fff, %r15d          # imm = 0x7FFF
     77e:      	movl	%r15d, 0x4(%r13)
     782:      	movl	$0x0, (%rsp)
     789:      	movq	(%rip), %rdi            # 0x790 <event_execve+0x790>
     790:      	movq	%rsp, %rsi
     793:      	movl	$0x1, %eax
     798:      	callq	*%rax
     79a:      	testq	%rax, %rax
     79d:      	je	0x843 <event_execve+0x843>
     7a3:      	cmpb	$0x0, 0x28(%rax)
     7a7:      	je	0x843 <event_execve+0x843>
     7ad:      	movq	(%rip), %rsi            # 0x7b4 <event_execve+0x7b4>
     7b4:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     7b9:      	movl	$0x19, %eax
     7be:      	movq	0x10(%rsp), %rdi
     7c3:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     7c8:      	movq	%r13, %rcx
     7cb:      	movq	%r15, %r8
     7ce:      	callq	*%rax
     7d0:      	testq	%rax, %rax
     7d3:      	jns	0x8fc <event_execve+0x8fc>
     7d9:      	movq	%rax, %r15
     7dc:      	movl	$0x0, 0x28(%rsp)
     7e4:      	movq	(%rip), %rdi            # 0x7eb <event_execve+0x7eb>
     7eb:      	leaq	0x28(%rsp), %rsi
     7f0:      	movl	$0x1, %eax
     7f5:      	callq	*%rax
     7f7:      	testq	%rax, %rax
     7fa:      	je	0x8fc <event_execve+0x8fc>
     800:      	cmpq	$-0xc, %r15
     804:      	jg	0x8c8 <event_execve+0x8c8>
     80a:      	cmpq	$-0x1c, %r15
     80e:      	je	0x8e2 <event_execve+0x8e2>
     814:      	cmpq	$-0x16, %r15
     818:      	jne	0x899 <event_execve+0x899>
     81a:      	addq	$0x560, %rax            # imm = 0x560
     820:      	jmp	0x8f8 <event_execve+0x8f8>
     825:      	xorl	%ecx, %ecx
     827:      	movl	$0x100, %eax            # imm = 0x100
     82c:      	jmp	0xaff <event_execve+0xaff>
     831:      	movl	%eax, %ecx
     833:      	jmp	0xaff <event_execve+0xaff>
     838:      	movl	%eax, %ecx
     83a:      	decl	%ecx
     83c:      	xorl	%eax, %eax
     83e:      	jmp	0xaff <event_execve+0xaff>
     843:      	movq	(%rip), %rdi            # 0x84a <event_execve+0x84a>
     84a:      	xorl	%ecx, %ecx
     84c:      	movl	$0x82, %eax
     851:      	movq	%r13, %rsi
     854:      	movq	%r15, %rdx
     857:      	xorl	%ecx, %ecx
     859:      	callq	*%rax
     85b:      	testq	%rax, %rax
     85e:      	jns	0x8fc <event_execve+0x8fc>
     864:      	movq	%rax, %r15
     867:      	movl	$0x0, 0x28(%rsp)
     86f:      	movq	(%rip), %rdi            # 0x876 <event_execve+0x876>
     876:      	leaq	0x28(%rsp), %rsi
     87b:      	movl	$0x1, %eax
     880:      	callq	*%rax
     882:      	testq	%rax, %rax
     885:      	je	0x8fc <event_execve+0x8fc>
     887:      	cmpq	$-0xc, %r15
     88b:      	jg	0x8ae <event_execve+0x8ae>
     88d:      	cmpq	$-0x1c, %r15
     891:      	je	0x8e2 <event_execve+0x8e2>
     893:      	cmpq	$-0x16, %r15
     897:      	je	0x81a <event_execve+0x81a>
     899:      	cmpq	$-0x10, %r15
     89d:      	jne	0x8da <event_execve+0x8da>
     89f:      	addq	$0x558, %rax            # imm = 0x558
     8a5:      	jmp	0x8f8 <event_execve+0x8f8>
     8a7:      	xorl	%eax, %eax
     8a9:      	jmp	0xad7 <event_execve+0xad7>
     8ae:      	cmpq	$-0xb, %r15
     8b2:      	je	0x8ea <event_execve+0x8ea>
     8b4:      	cmpq	$-0x7, %r15
     8b8:      	je	0x8f2 <event_execve+0x8f2>
     8ba:      	cmpq	$-0x2, %r15
     8be:      	jne	0x8da <event_execve+0x8da>
     8c0:      	addq	$0x548, %rax            # imm = 0x548
     8c6:      	jmp	0x8f8 <event_execve+0x8f8>
     8c8:      	cmpq	$-0xb, %r15
     8cc:      	je	0x8ea <event_execve+0x8ea>
     8ce:      	cmpq	$-0x7, %r15
     8d2:      	je	0x8f2 <event_execve+0x8f2>
     8d4:      	cmpq	$-0x2, %r15
     8d8:      	je	0x8c0 <event_execve+0x8c0>
     8da:      	addq	$0x540, %rax            # imm = 0x540
     8e0:      	jmp	0x8f8 <event_execve+0x8f8>
     8e2:      	addq	$0x568, %rax            # imm = 0x568
     8e8:      	jmp	0x8f8 <event_execve+0x8f8>
     8ea:      	addq	$0x570, %rax            # imm = 0x570
     8f0:      	jmp	0x8f8 <event_execve+0x8f8>
     8f2:      	addq	$0x550, %rax            # imm = 0x550
     8f8:      	lock
     8f9:      	incq	(%rax)
     8fc:      	leaq	-0x1(%rbx), %r15
     900:      	cmpq	$0x7fdf, %rbx           # imm = 0x7FDF
     907:      	jne	0x9fc <event_execve+0x9fc>
     90d:      	movq	0x88(%rsp), %rdx
     915:      	addq	%r15, %rdx
     918:      	movl	$0x7fdf, %ecx           # imm = 0x7FDF
     91d:      	movl	$0x2d, %eax
     922:      	movq	%rbp, %rdi
     925:      	movl	$0x7fdf, %esi           # imm = 0x7FDF
     92a:      	callq	*%rax
     92c:      	movq	%rax, %rbx
     92f:      	testq	%rax, %rax
     932:      	js	0xac6 <event_execve+0xac6>
     938:      	je	0xa6b <event_execve+0xa6b>
     93e:      	movq	%r15, %rbp
     941:      	leal	0x1f(%rbx), %r15d
     945:      	andl	$0x7fff, %r15d          # imm = 0x7FFF
     94c:      	movl	%r15d, 0x4(%r13)
     950:      	movl	$0x0, (%rsp)
     957:      	movq	(%rip), %rdi            # 0x95e <event_execve+0x95e>
     95e:      	movq	%rsp, %rsi
     961:      	movl	$0x1, %eax
     966:      	movq	%rbx, %r12
     969:      	decq	%r12
     96c:      	callq	*%rax
     96e:      	testq	%rax, %rax
     971:      	je	0xa04 <event_execve+0xa04>
     977:      	cmpb	$0x0, 0x28(%rax)
     97b:      	je	0xa04 <event_execve+0xa04>
     981:      	movq	(%rip), %rsi            # 0x988 <event_execve+0x988>
     988:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     98d:      	movl	$0x19, %eax
     992:      	movq	0x10(%rsp), %rdi
     997:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     99c:      	movq	%r13, %rcx
     99f:      	movq	%r15, %r8
     9a2:      	callq	*%rax
     9a4:      	testq	%rax, %rax
     9a7:      	movq	%rbp, %r15
     9aa:      	jns	0xac0 <event_execve+0xac0>
     9b0:      	movq	%rax, %rbx
     9b3:      	movl	$0x0, 0x28(%rsp)
     9bb:      	movq	(%rip), %rdi            # 0x9c2 <event_execve+0x9c2>
     9c2:      	leaq	0x28(%rsp), %rsi
     9c7:      	movl	$0x1, %eax
     9cc:      	callq	*%rax
     9ce:      	testq	%rax, %rax
     9d1:      	je	0xac0 <event_execve+0xac0>
     9d7:      	cmpq	$-0xc, %rbx
     9db:      	jg	0xa8c <event_execve+0xa8c>
     9e1:      	cmpq	$-0x1c, %rbx
     9e5:      	je	0xaa6 <event_execve+0xaa6>
     9eb:      	cmpq	$-0x16, %rbx
     9ef:      	jne	0xa5d <event_execve+0xa5d>
     9f1:      	addq	$0x560, %rax            # imm = 0x560
     9f7:      	jmp	0xabc <event_execve+0xabc>
     9fc:      	movq	%r15, %rbx
     9ff:      	jmp	0xac6 <event_execve+0xac6>
     a04:      	movq	(%rip), %rdi            # 0xa0b <event_execve+0xa0b>
     a0b:      	xorl	%ecx, %ecx
     a0d:      	movl	$0x82, %eax
     a12:      	movq	%r13, %rsi
     a15:      	movq	%r15, %rdx
     a18:      	xorl	%ecx, %ecx
     a1a:      	callq	*%rax
     a1c:      	testq	%rax, %rax
     a1f:      	movq	%rbp, %r15
     a22:      	jns	0xac0 <event_execve+0xac0>
     a28:      	movq	%rax, %rbx
     a2b:      	movl	$0x0, 0x28(%rsp)
     a33:      	movq	(%rip), %rdi            # 0xa3a <event_execve+0xa3a>
     a3a:      	leaq	0x28(%rsp), %rsi
     a3f:      	movl	$0x1, %eax
     a44:      	callq	*%rax
     a46:      	testq	%rax, %rax
     a49:      	je	0xac0 <event_execve+0xac0>
     a4b:      	cmpq	$-0xc, %rbx
     a4f:      	jg	0xa72 <event_execve+0xa72>
     a51:      	cmpq	$-0x1c, %rbx
     a55:      	je	0xaa6 <event_execve+0xaa6>
     a57:      	cmpq	$-0x16, %rbx
     a5b:      	je	0x9f1 <event_execve+0x9f1>
     a5d:      	cmpq	$-0x10, %rbx
     a61:      	jne	0xa9e <event_execve+0xa9e>
     a63:      	addq	$0x558, %rax            # imm = 0x558
     a69:      	jmp	0xabc <event_execve+0xabc>
     a6b:      	movl	$0x7fde, %eax           # imm = 0x7FDE
     a70:      	jmp	0xad7 <event_execve+0xad7>
     a72:      	cmpq	$-0xb, %rbx
     a76:      	je	0xaae <event_execve+0xaae>
     a78:      	cmpq	$-0x7, %rbx
     a7c:      	je	0xab6 <event_execve+0xab6>
     a7e:      	cmpq	$-0x2, %rbx
     a82:      	jne	0xa9e <event_execve+0xa9e>
     a84:      	addq	$0x548, %rax            # imm = 0x548
     a8a:      	jmp	0xabc <event_execve+0xabc>
     a8c:      	cmpq	$-0xb, %rbx
     a90:      	je	0xaae <event_execve+0xaae>
     a92:      	cmpq	$-0x7, %rbx
     a96:      	je	0xab6 <event_execve+0xab6>
     a98:      	cmpq	$-0x2, %rbx
     a9c:      	je	0xa84 <event_execve+0xa84>
     a9e:      	addq	$0x540, %rax            # imm = 0x540
     aa4:      	jmp	0xabc <event_execve+0xabc>
     aa6:      	addq	$0x568, %rax            # imm = 0x568
     aac:      	jmp	0xabc <event_execve+0xabc>
     aae:      	addq	$0x570, %rax            # imm = 0x570
     ab4:      	jmp	0xabc <event_execve+0xabc>
     ab6:      	addq	$0x550, %rax            # imm = 0x550
     abc:      	lock
     abd:      	incq	(%rax)
     ac0:      	addq	%r15, %r12
     ac3:      	movq	%r12, %rbx
     ac6:      	movl	%ebx, %r12d
     ac9:      	sarl	$0x1f, %r12d
     acd:      	andl	%ebx, %r12d
     ad0:      	xorl	%eax, %eax
     ad2:      	testl	%ebx, %ebx
     ad4:      	cmovgl	%ebx, %eax
     ad7:      	movl	%r12d, 0x180(%r14)
     ade:      	movq	$0x0, 0x184(%r14)
     ae9:      	movl	%eax, 0x18c(%r14)
     af0:      	movl	$0x20, %ecx
     af5:      	movl	$0x800000, %eax         # imm = 0x800000
     afa:      	movq	0x10(%rsp), %r12
     aff:      	movw	%cx, 0x178(%r14)
     b07:      	orl	%eax, 0x15c(%r14)
     b0e:      	addl	%ecx, 0x140(%r14)
     b15:      	movl	$0x23, %eax
     b1a:      	callq	*%rax
     b1c:      	movl	$0x0, 0xa8(%rsp)
     b27:      	leaq	0xa78(%rax), %rdx
     b2e:      	leaq	0x70(%rsp), %rdi
     b33:      	movl	$0x8, %ecx
     b38:      	movl	$0x4, %eax
     b3d:      	movl	$0x8, %esi
     b42:      	callq	*%rax
     b44:      	testq	%rax, %rax
     b47:      	je	0xba3 <event_execve+0xba3>
     b49:      	negl	%eax
     b4b:      	movw	%ax, 0x28(%rsp)
     b50:      	movw	$0x9, 0x2a(%rsp)
     b57:      	movabsq	$0x400000042, %rax      # imm = 0x400000042
     b61:      	movq	%rax, 0x2c(%rsp)
     b66:      	movq	(%rip), %rdi            # 0xb6d <event_execve+0xb6d>
     b6d:      	leaq	0x28(%rsp), %rsi
     b72:      	movl	$0x1, %eax
     b77:      	callq	*%rax
     b79:      	testq	%rax, %rax
     b7c:      	je	0xb82 <event_execve+0xb82>
     b7e:      	incl	(%rax)
     b80:      	jmp	0xba3 <event_execve+0xba3>
     b82:      	movl	$0x1, (%rsp)
     b89:      	movq	(%rip), %rdi            # 0xb90 <event_execve+0xb90>
     b90:      	xorl	%ecx, %ecx
     b92:      	leaq	0x28(%rsp), %rsi
     b97:      	movq	%rsp, %rdx
     b9a:      	movl	$0x2, %eax
     b9f:      	xorl	%ecx, %ecx
     ba1:      	callq	*%rax
     ba3:      	leaq	0x140(%r14), %r15
     baa:      	movq	0x70(%rsp), %rcx
     baf:      	xorl	%ebp, %ebp
     bb1:      	movl	$0x0, %r13d
     bb7:      	testq	%rcx, %rcx
     bba:      	je	0x1145 <event_execve+0x1145>
     bc0:      	addq	$0x2b8, %rcx            # imm = 0x2B8
     bc7:      	movq	%rsp, %rdi
     bca:      	movl	$0x8, %edx
     bcf:      	movl	$0x4, %eax
     bd4:      	movl	$0x2b8, %edx            # imm = 0x2B8
     bd9:      	addq	0x70(%rsp), %rdx
     bde:      	movl	$0x8, %esi
     be3:      	callq	*%rax
     be5:      	testq	%rax, %rax
     be8:      	je	0xc47 <event_execve+0xc47>
     bea:      	negl	%eax
     bec:      	movw	%ax, 0x28(%rsp)
     bf1:      	movw	$0x9, 0x2a(%rsp)
     bf8:      	movabsq	$0x400000047, %rax      # imm = 0x400000047
     c02:      	movq	%rax, 0x2c(%rsp)
     c07:      	movq	(%rip), %rdi            # 0xc0e <event_execve+0xc0e>
     c0e:      	leaq	0x28(%rsp), %rsi
     c13:      	movl	$0x1, %eax
     c18:      	callq	*%rax
     c1a:      	testq	%rax, %rax
     c1d:      	je	0xc23 <event_execve+0xc23>
     c1f:      	incl	(%rax)
     c21:      	jmp	0xc47 <event_execve+0xc47>
     c23:      	movl	$0x1, 0x18(%rsp)
     c2b:      	movq	(%rip), %rdi            # 0xc32 <event_execve+0xc32>
     c32:      	xorl	%ecx, %ecx
     c34:      	leaq	0x28(%rsp), %rsi
     c39:      	leaq	0x18(%rsp), %rdx
     c3e:      	movl	$0x2, %eax
     c43:      	xorl	%ecx, %ecx
     c45:      	callq	*%rax
     c47:      	movl	$0x2c0, %edx            # imm = 0x2C0
     c4c:      	movq	0x70(%rsp), %rcx
     c51:      	addq	%rdx, %rcx
     c54:      	leaq	0x18(%rsp), %rdi
     c59:      	movl	$0x8, %esi
     c5e:      	movl	$0x4, %eax
     c63:      	addq	0x70(%rsp), %rdx
     c68:      	movl	$0x8, %esi
     c6d:      	callq	*%rax
     c6f:      	testq	%rax, %rax
     c72:      	je	0xcaf <event_execve+0xcaf>
     c74:      	negl	%eax
     c76:      	movw	%ax, 0x28(%rsp)
     c7b:      	movw	$0x9, 0x2a(%rsp)
     c82:      	movabsq	$0x400000048, %rax      # imm = 0x400000048
     c8c:      	movq	%rax, 0x2c(%rsp)
     c91:      	movq	(%rip), %rdi            # 0xc98 <event_execve+0xc98>
     c98:      	leaq	0x28(%rsp), %rsi
     c9d:      	movl	$0x1, %eax
     ca2:      	callq	*%rax
     ca4:      	testq	%rax, %rax
     ca7:      	je	0xde7 <event_execve+0xde7>
     cad:      	incl	(%rax)
     caf:      	cmpq	$0x0, (%rsp)
     cb4:      	movl	$0x0, %r13d
     cba:      	je	0x1145 <event_execve+0x1145>
     cc0:      	cmpq	$0x0, 0x18(%rsp)
     cc6:      	movl	$0x0, %r13d
     ccc:      	je	0x1145 <event_execve+0x1145>
     cd2:      	movq	(%rip), %rdi            # 0xcd9 <event_execve+0xcd9>
     cd9:      	leaq	0xa8(%rsp), %rsi
     ce1:      	movl	$0x1, %eax
     ce6:      	callq	*%rax
     ce8:      	movl	$0x0, %r13d
     cee:      	testq	%rax, %rax
     cf1:      	je	0x1145 <event_execve+0x1145>
     cf7:      	movq	%rax, %rdi
     cfa:      	movq	(%rsp), %rcx
     cfe:      	movl	$0x1000, %edx           # imm = 0x1000
     d03:      	movl	$0x2d, %eax
     d08:      	movq	(%rsp), %rdx
     d0c:      	movl	$0x1000, %esi           # imm = 0x1000
     d11:      	callq	*%rax
     d13:      	movl	$0x0, %r13d
     d19:      	testq	%rax, %rax
     d1c:      	js	0x1145 <event_execve+0x1145>
     d22:      	movq	%rax, %rbx
     d25:      	addq	(%rsp), %rbx
     d29:      	movq	%rbx, (%rsp)
     d2d:      	movl	0x140(%r14), %r13d
     d34:      	andl	$0x1ff, %r13d           # imm = 0x1FF
     d3b:      	movl	%r13d, 0x184c(%r14)
     d42:      	movq	0x18(%rsp), %rax
     d47:      	movq	%rax, %rdx
     d4a:      	subq	%rbx, %rdx
     d4d:      	cmpq	$0x3ff, %rdx            # imm = 0x3FF
     d54:      	ja	0xe21 <event_execve+0xe21>
     d5a:      	leaq	(%r14,%r13), %rdi
     d5e:      	addq	$0x140, %rdi            # imm = 0x140
     d65:      	movq	%r15, %rcx
     d68:      	subq	%rdi, %rcx
     d6b:      	addq	$0x400, %rcx            # imm = 0x400
     d72:      	cmpq	%rcx, %rdx
     d75:      	jae	0xe21 <event_execve+0xe21>
     d7b:      	decl	%edx
     d7d:      	andl	$0x3ff, %edx            # imm = 0x3FF
     d83:      	xorl	%r13d, %r13d
     d86:      	cmpq	%rbx, %rax
     d89:      	cmovnel	%edx, %r13d
     d8d:      	movl	$0x4, %eax
     d92:      	movq	(%rsp), %rdx
     d96:      	movl	%r13d, %esi
     d99:      	callq	*%rax
     d9b:      	testq	%rax, %rax
     d9e:      	je	0x1136 <event_execve+0x1136>
     da4:      	movq	%rax, %rbx
     da7:      	negl	%eax
     da9:      	movw	%ax, 0x28(%rsp)
     dae:      	movw	$0x9, 0x2a(%rsp)
     db5:      	movabsq	$0x40000006c, %rax      # imm = 0x40000006C
     dbf:      	movq	%rax, 0x2c(%rsp)
     dc4:      	movq	(%rip), %rdi            # 0xdcb <event_execve+0xdcb>
     dcb:      	leaq	0x28(%rsp), %rsi
     dd0:      	movl	$0x1, %eax
     dd5:      	callq	*%rax
     dd7:      	testq	%rax, %rax
     dda:      	je	0x1002 <event_execve+0x1002>
     de0:      	incl	(%rax)
     de2:      	jmp	0x1026 <event_execve+0x1026>
     de7:      	movl	$0x1, 0x78(%rsp)
     def:      	movq	(%rip), %rdi            # 0xdf6 <event_execve+0xdf6>
     df6:      	xorl	%ecx, %ecx
     df8:      	leaq	0x28(%rsp), %rsi
     dfd:      	leaq	0x78(%rsp), %rdx
     e02:      	movl	$0x2, %eax
     e07:      	xorl	%ecx, %ecx
     e09:      	callq	*%rax
     e0b:      	cmpq	$0x0, (%rsp)
     e10:      	movl	$0x0, %r13d
     e16:      	jne	0xcc0 <event_execve+0xcc0>
     e1c:      	jmp	0x1145 <event_execve+0x1145>
     e21:      	movq	%rdx, 0x80(%rsp)
     e29:      	movl	$0x0, 0x78(%rsp)
     e31:      	movq	(%rip), %rdi            # 0xe38 <event_execve+0xe38>
     e38:      	leaq	0x78(%rsp), %rsi
     e3d:      	movl	$0x1, %eax
     e42:      	callq	*%rax
     e44:      	testq	%rax, %rax
     e47:      	je	0xff5 <event_execve+0xff5>
     e4d:      	movq	%rax, %r12
     e50:      	movq	%rbx, 0x98(%rsp)
     e58:      	movq	%r15, 0x88(%rsp)
     e60:      	addq	%r14, %r13
     e63:      	movl	$0x18, (%rax)
     e69:      	movl	$0xe, %eax
     e6e:      	callq	*%rax
     e70:      	leaq	0x10(%r12), %rbx
     e75:      	movq	%rax, 0x10(%r12)
     e7a:      	cmpq	$-0x16, %rax
     e7e:      	jne	0xea7 <event_execve+0xea7>
     e80:      	movq	0x10(%rsp), %rax
     e85:      	leaq	0x20(%rax), %rdx
     e89:      	leaq	0x28(%rsp), %rdi
     e8e:      	movl	$0x8, %ecx
     e93:      	movl	$0x4, %eax
     e98:      	movl	$0x8, %esi
     e9d:      	callq	*%rax
     e9f:      	movq	0x28(%rsp), %rax
     ea4:      	movq	%rax, (%rbx)
     ea7:      	movl	$0x7d, %eax
     eac:      	callq	*%rax
     eae:      	movq	%rax, 0x18(%r12)
     eb3:      	movq	(%rbx), %rax
     eb6:      	movq	0x8(%rbx), %rcx
     eba:      	movq	%rax, 0x150(%r13)
     ec1:      	movq	%r13, 0xb8(%rsp)
     ec9:      	movq	%rcx, 0x158(%r13)
     ed0:      	movq	%r12, 0x90(%rsp)
     ed8:      	addq	$0x20, %r12
     edc:      	movq	%r12, 0xc0(%rsp)
     ee4:      	movl	$0xa, %ebx
     ee9:      	xorl	%r15d, %r15d
     eec:      	movq	0x80(%rsp), %rdx
     ef4:      	movq	0x10(%rsp), %r12
     ef9:      	movq	%rdx, %r13
     efc:      	subq	%r15, %r13
     eff:      	js	0x103e <event_execve+0x103e>
     f05:      	movq	0x98(%rsp), %rax
     f0d:      	leaq	(%r15,%rax), %rdx
     f11:      	cmpq	$0x7fe0, %r13           # imm = 0x7FE0
     f18:      	movl	$0x7fe0, %eax           # imm = 0x7FE0
     f1d:      	cmovaeq	%rax, %r13
     f21:      	movl	$0x4, %eax
     f26:      	movq	0xc0(%rsp), %rdi
     f2e:      	movl	%r13d, %esi
     f31:      	callq	*%rax
     f33:      	testl	%eax, %eax
     f35:      	js	0xf92 <event_execve+0xf92>
     f37:      	leal	0x20(%r13), %r12d
     f3b:      	movq	0x90(%rsp), %rax
     f43:      	movl	%r12d, 0x4(%rax)
     f47:      	movl	$0x0, 0x28(%rsp)
     f4f:      	movl	$0x1, %eax
     f54:      	movq	(%rip), %rdi            # 0xf5b <event_execve+0xf5b>
     f5b:      	leaq	0x28(%rsp), %rsi
     f60:      	callq	*%rax
     f62:      	testq	%rax, %rax
     f65:      	je	0xf9f <event_execve+0xf9f>
     f67:      	cmpb	$0x0, 0x28(%rax)
     f6b:      	je	0xf9f <event_execve+0xf9f>
     f6d:      	movl	$0x19, %eax
     f72:      	movq	0x10(%rsp), %rdi
     f77:      	movq	0x90(%rsp), %rcx
     f7f:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     f84:      	movq	(%rip), %rsi            # 0xf8b <event_execve+0xf8b>
     f8b:      	movq	%r12, %r8
     f8e:      	callq	*%rax
     f90:      	jmp	0xfbc <event_execve+0xfbc>
     f92:      	movslq	%eax, %r13
     f95:      	movq	0x80(%rsp), %rdx
     f9d:      	jmp	0xfd0 <event_execve+0xfd0>
     f9f:      	movl	$0x82, %eax
     fa4:      	movq	0x90(%rsp), %rsi
     fac:      	xorl	%ecx, %ecx
     fae:      	movq	(%rip), %rdi            # 0xfb5 <event_execve+0xfb5>
     fb5:      	movq	%r12, %rdx
     fb8:      	xorl	%ecx, %ecx
     fba:      	callq	*%rax
     fbc:      	testl	%eax, %eax
     fbe:      	movq	0x10(%rsp), %r12
     fc3:      	movq	0x80(%rsp), %rdx
     fcb:      	jns	0xfd0 <event_execve+0xfd0>
     fcd:      	movslq	%eax, %r13
     fd0:      	testl	%r13d, %r13d
     fd3:      	js	0x1047 <event_execve+0x1047>
     fd5:      	andl	$0x7fffffff, %r13d      # imm = 0x7FFFFFFF
     fdc:      	addq	%r13, %r15
     fdf:      	cmpq	%rdx, %r15
     fe2:      	je	0x1092 <event_execve+0x1092>
     fe8:      	decl	%ebx
     fea:      	jne	0xef9 <event_execve+0xef9>
     ff0:      	jmp	0x10db <event_execve+0x10db>
     ff5:      	xorl	%r13d, %r13d
     ff8:      	movq	0x10(%rsp), %r12
     ffd:      	jmp	0x1136 <event_execve+0x1136>
    1002:      	movl	$0x1, 0x78(%rsp)
    100a:      	movq	(%rip), %rdi            # 0x1011 <event_execve+0x1011>
    1011:      	xorl	%ecx, %ecx
    1013:      	leaq	0x28(%rsp), %rsi
    1018:      	leaq	0x78(%rsp), %rdx
    101d:      	movl	$0x2, %eax
    1022:      	xorl	%ecx, %ecx
    1024:      	callq	*%rax
    1026:      	testl	%ebx, %ebx
    1028:      	jns	0x1136 <event_execve+0x1136>
    102e:      	orb	$0x2, 0x15d(%r14)
    1036:      	xorl	%r13d, %r13d
    1039:      	jmp	0x1136 <event_execve+0x1136>
    103e:      	movq	$-0x1, %r15
    1045:      	jmp	0x104a <event_execve+0x104a>
    1047:      	movq	%r13, %r15
    104a:      	movl	$0x0, 0x28(%rsp)
    1052:      	movq	(%rip), %rdi            # 0x1059 <event_execve+0x1059>
    1059:      	leaq	0x28(%rsp), %rsi
    105e:      	movl	$0x1, %eax
    1063:      	callq	*%rax
    1065:      	testq	%rax, %rax
    1068:      	movq	0x80(%rsp), %rdx
    1070:      	je	0x10db <event_execve+0x10db>
    1072:      	cmpq	$-0xc, %r15
    1076:      	jg	0x1097 <event_execve+0x1097>
    1078:      	cmpq	$-0x1c, %r15
    107c:      	je	0x10b1 <event_execve+0x10b1>
    107e:      	cmpq	$-0x16, %r15
    1082:      	je	0x10c9 <event_execve+0x10c9>
    1084:      	cmpq	$-0x10, %r15
    1088:      	jne	0x10c1 <event_execve+0x10c1>
    108a:      	addq	$0x558, %rax            # imm = 0x558
    1090:      	jmp	0x10d7 <event_execve+0x10d7>
    1092:      	movq	%rdx, %r15
    1095:      	jmp	0x10db <event_execve+0x10db>
    1097:      	cmpq	$-0xb, %r15
    109b:      	je	0x10b9 <event_execve+0x10b9>
    109d:      	cmpq	$-0x7, %r15
    10a1:      	je	0x10d1 <event_execve+0x10d1>
    10a3:      	cmpq	$-0x2, %r15
    10a7:      	jne	0x10c1 <event_execve+0x10c1>
    10a9:      	addq	$0x548, %rax            # imm = 0x548
    10af:      	jmp	0x10d7 <event_execve+0x10d7>
    10b1:      	addq	$0x568, %rax            # imm = 0x568
    10b7:      	jmp	0x10d7 <event_execve+0x10d7>
    10b9:      	addq	$0x570, %rax            # imm = 0x570
    10bf:      	jmp	0x10d7 <event_execve+0x10d7>
    10c1:      	addq	$0x540, %rax            # imm = 0x540
    10c7:      	jmp	0x10d7 <event_execve+0x10d7>
    10c9:      	addq	$0x560, %rax            # imm = 0x560
    10cf:      	jmp	0x10d7 <event_execve+0x10d7>
    10d1:      	addq	$0x550, %rax            # imm = 0x550
    10d7:      	lock
    10d8:      	incq	(%rax)
    10db:      	movl	%edx, %eax
    10dd:      	subl	%r15d, %eax
    10e0:      	xorl	%ecx, %ecx
    10e2:      	cmpq	$-0x1, %rdx
    10e6:      	cmovel	%ecx, %eax
    10e9:      	testl	%r15d, %r15d
    10ec:      	movl	$0x0, %edx
    10f1:      	cmovsl	%r15d, %edx
    10f5:      	cmovsl	%ecx, %eax
    10f8:      	cmovgl	%r15d, %ecx
    10fc:      	movq	0xb8(%rsp), %rsi
    1104:      	movl	%edx, 0x140(%rsi)
    110a:      	movl	$0x0, 0x144(%rsi)
    1114:      	movl	%eax, 0x148(%rsi)
    111a:      	movl	%ecx, 0x14c(%rsi)
    1120:      	orb	$0x1, 0x15f(%r14)
    1128:      	movl	$0x20, %r13d
    112e:      	movq	0x88(%rsp), %r15
    1136:      	movl	%r13d, 0x1848(%r14)
    113d:      	movw	%r13w, 0x17a(%r14)
    1145:      	addl	0x140(%r14), %r13d
    114c:      	movl	%r13d, 0x140(%r14)
    1153:      	testb	$0x20, 0x15d(%r14)
    115b:      	jne	0x1e97 <event_execve+0x1e97>
    1161:      	movq	%r13, 0x98(%rsp)
    1169:      	movq	%r15, 0x88(%rsp)
    1171:      	movl	0x144(%r14), %ebx
    1178:      	movl	$0x23, %eax
    117d:      	callq	*%rax
    117f:      	movl	$0x0, (%rsp)
    1186:      	testq	%rax, %rax
    1189:      	je	0x17f6 <event_execve+0x17f6>
    118f:      	movq	%rax, %r13
    1192:      	leaq	0xaf4(%rax), %rdx
    1199:      	movq	%rsp, %rdi
    119c:      	movl	$0x4, %ecx
    11a1:      	movl	$0x71, %eax
    11a6:      	movl	$0x4, %esi
    11ab:      	callq	*%rax
    11ad:      	cmpl	%ebx, (%rsp)
    11b0:      	je	0x17f9 <event_execve+0x17f9>
    11b6:      	addq	$0xb00, %r13            # imm = 0xB00
    11bd:      	leaq	0x28(%rsp), %rdi
    11c2:      	movl	$0x8, %ecx
    11c7:      	movl	$0x71, %eax
    11cc:      	movl	$0x8, %esi
    11d1:      	movq	%r13, %rdx
    11d4:      	callq	*%rax
    11d6:      	movq	0x28(%rsp), %r13
    11db:      	testq	%r13, %r13
    11de:      	je	0x17f6 <event_execve+0x17f6>
    11e4:      	leaq	0xaf4(%r13), %rdx
    11eb:      	movq	%rsp, %rdi
    11ee:      	movl	$0x4, %ecx
    11f3:      	movl	$0x71, %eax
    11f8:      	movl	$0x4, %esi
    11fd:      	callq	*%rax
    11ff:      	cmpl	%ebx, (%rsp)
    1202:      	je	0x17f9 <event_execve+0x17f9>
    1208:      	addq	$0xb00, %r13            # imm = 0xB00
    120f:      	leaq	0x28(%rsp), %rdi
    1214:      	movl	$0x8, %ecx
    1219:      	movl	$0x71, %eax
    121e:      	movl	$0x8, %esi
    1223:      	movq	%r13, %rdx
    1226:      	callq	*%rax
    1228:      	movq	0x28(%rsp), %r13
    122d:      	testq	%r13, %r13
    1230:      	je	0x17f6 <event_execve+0x17f6>
    1236:      	leaq	0xaf4(%r13), %rdx
    123d:      	movq	%rsp, %rdi
    1240:      	movl	$0x4, %ecx
    1245:      	movl	$0x71, %eax
    124a:      	movl	$0x4, %esi
    124f:      	callq	*%rax
    1251:      	cmpl	%ebx, (%rsp)
    1254:      	je	0x17f9 <event_execve+0x17f9>
    125a:      	addq	$0xb00, %r13            # imm = 0xB00
    1261:      	leaq	0x28(%rsp), %rdi
    1266:      	movl	$0x8, %ecx
    126b:      	movl	$0x71, %eax
    1270:      	movl	$0x8, %esi
    1275:      	movq	%r13, %rdx
    1278:      	callq	*%rax
    127a:      	movq	0x28(%rsp), %r13
    127f:      	testq	%r13, %r13
    1282:      	je	0x17f6 <event_execve+0x17f6>
    1288:      	leaq	0xaf4(%r13), %rdx
    128f:      	movq	%rsp, %rdi
    1292:      	movl	$0x4, %ecx
    1297:      	movl	$0x71, %eax
    129c:      	movl	$0x4, %esi
    12a1:      	callq	*%rax
    12a3:      	cmpl	%ebx, (%rsp)
    12a6:      	je	0x17f9 <event_execve+0x17f9>
    12ac:      	addq	$0xb00, %r13            # imm = 0xB00
    12b3:      	leaq	0x28(%rsp), %rdi
    12b8:      	movl	$0x8, %ecx
    12bd:      	movl	$0x71, %eax
    12c2:      	movl	$0x8, %esi
    12c7:      	movq	%r13, %rdx
    12ca:      	callq	*%rax
    12cc:      	movq	0x28(%rsp), %r13
    12d1:      	testq	%r13, %r13
    12d4:      	je	0x17f6 <event_execve+0x17f6>
    12da:      	leaq	0xaf4(%r13), %rdx
    12e1:      	movq	%rsp, %rdi
    12e4:      	movl	$0x4, %ecx
    12e9:      	movl	$0x71, %eax
    12ee:      	movl	$0x4, %esi
    12f3:      	callq	*%rax
    12f5:      	cmpl	%ebx, (%rsp)
    12f8:      	je	0x17f9 <event_execve+0x17f9>
    12fe:      	addq	$0xb00, %r13            # imm = 0xB00
    1305:      	leaq	0x28(%rsp), %rdi
    130a:      	movl	$0x8, %ecx
    130f:      	movl	$0x71, %eax
    1314:      	movl	$0x8, %esi
    1319:      	movq	%r13, %rdx
    131c:      	callq	*%rax
    131e:      	movq	0x28(%rsp), %r13
    1323:      	testq	%r13, %r13
    1326:      	je	0x17f6 <event_execve+0x17f6>
    132c:      	leaq	0xaf4(%r13), %rdx
    1333:      	movq	%rsp, %rdi
    1336:      	movl	$0x4, %ecx
    133b:      	movl	$0x71, %eax
    1340:      	movl	$0x4, %esi
    1345:      	callq	*%rax
    1347:      	cmpl	%ebx, (%rsp)
    134a:      	je	0x17f9 <event_execve+0x17f9>
    1350:      	addq	$0xb00, %r13            # imm = 0xB00
    1357:      	leaq	0x28(%rsp), %rdi
    135c:      	movl	$0x8, %ecx
    1361:      	movl	$0x71, %eax
    1366:      	movl	$0x8, %esi
    136b:      	movq	%r13, %rdx
    136e:      	callq	*%rax
    1370:      	movq	0x28(%rsp), %r13
    1375:      	testq	%r13, %r13
    1378:      	je	0x17f6 <event_execve+0x17f6>
    137e:      	leaq	0xaf4(%r13), %rdx
    1385:      	movq	%rsp, %rdi
    1388:      	movl	$0x4, %ecx
    138d:      	movl	$0x71, %eax
    1392:      	movl	$0x4, %esi
    1397:      	callq	*%rax
    1399:      	cmpl	%ebx, (%rsp)
    139c:      	je	0x17f9 <event_execve+0x17f9>
    13a2:      	addq	$0xb00, %r13            # imm = 0xB00
    13a9:      	leaq	0x28(%rsp), %rdi
    13ae:      	movl	$0x8, %ecx
    13b3:      	movl	$0x71, %eax
    13b8:      	movl	$0x8, %esi
    13bd:      	movq	%r13, %rdx
    13c0:      	callq	*%rax
    13c2:      	movq	0x28(%rsp), %r13
    13c7:      	testq	%r13, %r13
    13ca:      	je	0x17f6 <event_execve+0x17f6>
    13d0:      	leaq	0xaf4(%r13), %rdx
    13d7:      	movq	%rsp, %rdi
    13da:      	movl	$0x4, %ecx
    13df:      	movl	$0x71, %eax
    13e4:      	movl	$0x4, %esi
    13e9:      	callq	*%rax
    13eb:      	cmpl	%ebx, (%rsp)
    13ee:      	je	0x2b4c <event_execve+0x2b4c>
    13f4:      	addq	$0xb00, %r13            # imm = 0xB00
    13fb:      	leaq	0x28(%rsp), %rdi
    1400:      	movl	$0x8, %ecx
    1405:      	movl	$0x71, %eax
    140a:      	movl	$0x8, %esi
    140f:      	movq	%r13, %rdx
    1412:      	callq	*%rax
    1414:      	movq	0x28(%rsp), %r13
    1419:      	testq	%r13, %r13
    141c:      	je	0x2b49 <event_execve+0x2b49>
    1422:      	leaq	0xaf4(%r13), %rdx
    1429:      	movq	%rsp, %rdi
    142c:      	movl	$0x4, %ecx
    1431:      	movl	$0x71, %eax
    1436:      	movl	$0x4, %esi
    143b:      	callq	*%rax
    143d:      	cmpl	%ebx, (%rsp)
    1440:      	je	0x2b4c <event_execve+0x2b4c>
    1446:      	addq	$0xb00, %r13            # imm = 0xB00
    144d:      	leaq	0x28(%rsp), %rdi
    1452:      	movl	$0x8, %ecx
    1457:      	movl	$0x71, %eax
    145c:      	movl	$0x8, %esi
    1461:      	movq	%r13, %rdx
    1464:      	callq	*%rax
    1466:      	movq	0x28(%rsp), %r13
    146b:      	testq	%r13, %r13
    146e:      	je	0x2b49 <event_execve+0x2b49>
    1474:      	leaq	0xaf4(%r13), %rdx
    147b:      	movq	%rsp, %rdi
    147e:      	movl	$0x4, %ecx
    1483:      	movl	$0x71, %eax
    1488:      	movl	$0x4, %esi
    148d:      	callq	*%rax
    148f:      	cmpl	%ebx, (%rsp)
    1492:      	je	0x2b4c <event_execve+0x2b4c>
    1498:      	addq	$0xb00, %r13            # imm = 0xB00
    149f:      	leaq	0x28(%rsp), %rdi
    14a4:      	movl	$0x8, %ecx
    14a9:      	movl	$0x71, %eax
    14ae:      	movl	$0x8, %esi
    14b3:      	movq	%r13, %rdx
    14b6:      	callq	*%rax
    14b8:      	movq	0x28(%rsp), %r13
    14bd:      	testq	%r13, %r13
    14c0:      	je	0x2b49 <event_execve+0x2b49>
    14c6:      	leaq	0xaf4(%r13), %rdx
    14cd:      	movq	%rsp, %rdi
    14d0:      	movl	$0x4, %ecx
    14d5:      	movl	$0x71, %eax
    14da:      	movl	$0x4, %esi
    14df:      	callq	*%rax
    14e1:      	cmpl	%ebx, (%rsp)
    14e4:      	je	0x2b4c <event_execve+0x2b4c>
    14ea:      	addq	$0xb00, %r13            # imm = 0xB00
    14f1:      	leaq	0x28(%rsp), %rdi
    14f6:      	movl	$0x8, %ecx
    14fb:      	movl	$0x71, %eax
    1500:      	movl	$0x8, %esi
    1505:      	movq	%r13, %rdx
    1508:      	callq	*%rax
    150a:      	movq	0x28(%rsp), %r13
    150f:      	testq	%r13, %r13
    1512:      	je	0x2b49 <event_execve+0x2b49>
    1518:      	leaq	0xaf4(%r13), %rdx
    151f:      	movq	%rsp, %rdi
    1522:      	movl	$0x4, %ecx
    1527:      	movl	$0x71, %eax
    152c:      	movl	$0x4, %esi
    1531:      	callq	*%rax
    1533:      	cmpl	%ebx, (%rsp)
    1536:      	je	0x2b4c <event_execve+0x2b4c>
    153c:      	addq	$0xb00, %r13            # imm = 0xB00
    1543:      	leaq	0x28(%rsp), %rdi
    1548:      	movl	$0x8, %ecx
    154d:      	movl	$0x71, %eax
    1552:      	movl	$0x8, %esi
    1557:      	movq	%r13, %rdx
    155a:      	callq	*%rax
    155c:      	movq	0x28(%rsp), %r13
    1561:      	testq	%r13, %r13
    1564:      	je	0x2b49 <event_execve+0x2b49>
    156a:      	leaq	0xaf4(%r13), %rdx
    1571:      	movq	%rsp, %rdi
    1574:      	movl	$0x4, %ecx
    1579:      	movl	$0x71, %eax
    157e:      	movl	$0x4, %esi
    1583:      	callq	*%rax
    1585:      	cmpl	%ebx, (%rsp)
    1588:      	je	0x2b4c <event_execve+0x2b4c>
    158e:      	addq	$0xb00, %r13            # imm = 0xB00
    1595:      	leaq	0x28(%rsp), %rdi
    159a:      	movl	$0x8, %ecx
    159f:      	movl	$0x71, %eax
    15a4:      	movl	$0x8, %esi
    15a9:      	movq	%r13, %rdx
    15ac:      	callq	*%rax
    15ae:      	movq	0x28(%rsp), %r13
    15b3:      	testq	%r13, %r13
    15b6:      	je	0x2b49 <event_execve+0x2b49>
    15bc:      	leaq	0xaf4(%r13), %rdx
    15c3:      	movq	%rsp, %rdi
    15c6:      	movl	$0x4, %ecx
    15cb:      	movl	$0x71, %eax
    15d0:      	movl	$0x4, %esi
    15d5:      	callq	*%rax
    15d7:      	cmpl	%ebx, (%rsp)
    15da:      	je	0x2b4c <event_execve+0x2b4c>
    15e0:      	addq	$0xb00, %r13            # imm = 0xB00
    15e7:      	leaq	0x28(%rsp), %rdi
    15ec:      	movl	$0x8, %ecx
    15f1:      	movl	$0x71, %eax
    15f6:      	movl	$0x8, %esi
    15fb:      	movq	%r13, %rdx
    15fe:      	callq	*%rax
    1600:      	movq	0x28(%rsp), %r13
    1605:      	testq	%r13, %r13
    1608:      	je	0x2b49 <event_execve+0x2b49>
    160e:      	leaq	0xaf4(%r13), %rdx
    1615:      	movq	%rsp, %rdi
    1618:      	movl	$0x4, %ecx
    161d:      	movl	$0x71, %eax
    1622:      	movl	$0x4, %esi
    1627:      	callq	*%rax
    1629:      	cmpl	%ebx, (%rsp)
    162c:      	je	0x2b4c <event_execve+0x2b4c>
    1632:      	addq	$0xb00, %r13            # imm = 0xB00
    1639:      	leaq	0x28(%rsp), %rdi
    163e:      	movl	$0x8, %ecx
    1643:      	movl	$0x71, %eax
    1648:      	movl	$0x8, %esi
    164d:      	movq	%r13, %rdx
    1650:      	callq	*%rax
    1652:      	movq	0x28(%rsp), %r13
    1657:      	testq	%r13, %r13
    165a:      	je	0x2b49 <event_execve+0x2b49>
    1660:      	leaq	0xaf4(%r13), %rdx
    1667:      	movq	%rsp, %rdi
    166a:      	movl	$0x4, %ecx
    166f:      	movl	$0x71, %eax
    1674:      	movl	$0x4, %esi
    1679:      	callq	*%rax
    167b:      	cmpl	%ebx, (%rsp)
    167e:      	je	0x2b4c <event_execve+0x2b4c>
    1684:      	addq	$0xb00, %r13            # imm = 0xB00
    168b:      	leaq	0x28(%rsp), %rdi
    1690:      	movl	$0x8, %ecx
    1695:      	movl	$0x71, %eax
    169a:      	movl	$0x8, %esi
    169f:      	movq	%r13, %rdx
    16a2:      	callq	*%rax
    16a4:      	movq	0x28(%rsp), %r13
    16a9:      	testq	%r13, %r13
    16ac:      	je	0x2b49 <event_execve+0x2b49>
    16b2:      	leaq	0xaf4(%r13), %rdx
    16b9:      	movq	%rsp, %rdi
    16bc:      	movl	$0x4, %ecx
    16c1:      	movl	$0x71, %eax
    16c6:      	movl	$0x4, %esi
    16cb:      	callq	*%rax
    16cd:      	cmpl	%ebx, (%rsp)
    16d0:      	je	0x2b4c <event_execve+0x2b4c>
    16d6:      	addq	$0xb00, %r13            # imm = 0xB00
    16dd:      	leaq	0x28(%rsp), %rdi
    16e2:      	movl	$0x8, %ecx
    16e7:      	movl	$0x71, %eax
    16ec:      	movl	$0x8, %esi
    16f1:      	movq	%r13, %rdx
    16f4:      	callq	*%rax
    16f6:      	movq	0x28(%rsp), %r13
    16fb:      	testq	%r13, %r13
    16fe:      	je	0x2b49 <event_execve+0x2b49>
    1704:      	leaq	0xaf4(%r13), %rdx
    170b:      	movq	%rsp, %rdi
    170e:      	movl	$0x4, %ecx
    1713:      	movl	$0x71, %eax
    1718:      	movl	$0x4, %esi
    171d:      	callq	*%rax
    171f:      	cmpl	%ebx, (%rsp)
    1722:      	je	0x2b4c <event_execve+0x2b4c>
    1728:      	addq	$0xb00, %r13            # imm = 0xB00
    172f:      	leaq	0x28(%rsp), %rdi
    1734:      	movl	$0x8, %ecx
    1739:      	movl	$0x71, %eax
    173e:      	movl	$0x8, %esi
    1743:      	movq	%r13, %rdx
    1746:      	callq	*%rax
    1748:      	movq	0x28(%rsp), %r13
    174d:      	testq	%r13, %r13
    1750:      	je	0x2b49 <event_execve+0x2b49>
    1756:      	leaq	0xaf4(%r13), %rdx
    175d:      	movq	%rsp, %rdi
    1760:      	movl	$0x4, %ecx
    1765:      	movl	$0x71, %eax
    176a:      	movl	$0x4, %esi
    176f:      	callq	*%rax
    1771:      	cmpl	%ebx, (%rsp)
    1774:      	je	0x2b4c <event_execve+0x2b4c>
    177a:      	addq	$0xb00, %r13            # imm = 0xB00
    1781:      	leaq	0x28(%rsp), %rdi
    1786:      	movl	$0x8, %ecx
    178b:      	movl	$0x71, %eax
    1790:      	movl	$0x8, %esi
    1795:      	movq	%r13, %rdx
    1798:      	callq	*%rax
    179a:      	movq	0x28(%rsp), %r13
    179f:      	testq	%r13, %r13
    17a2:      	je	0x2b49 <event_execve+0x2b49>
    17a8:      	leaq	0xaf4(%r13), %rdx
    17af:      	movq	%rsp, %rdi
    17b2:      	movl	$0x4, %ecx
    17b7:      	movl	$0x71, %eax
    17bc:      	movl	$0x4, %esi
    17c1:      	callq	*%rax
    17c3:      	cmpl	%ebx, (%rsp)
    17c6:      	je	0x2b4c <event_execve+0x2b4c>
    17cc:      	addq	$0xb00, %r13            # imm = 0xB00
    17d3:      	leaq	0x28(%rsp), %rdi
    17d8:      	movl	$0x8, %ecx
    17dd:      	movl	$0x71, %eax
    17e2:      	movl	$0x8, %esi
    17e7:      	movq	%r13, %rdx
    17ea:      	callq	*%rax
    17ec:      	movq	0x28(%rsp), %r13
    17f1:      	jmp	0x2b4c <event_execve+0x2b4c>
    17f6:      	xorl	%r13d, %r13d
    17f9:      	xorl	%ebp, %ebp
    17fb:      	cmpl	%ebx, (%rsp)
    17fe:      	cmovneq	%rbp, %r13
    1802:      	addq	$0xd50, %r13            # imm = 0xD50
    1809:      	leaq	0xc8(%rsp), %rdi
    1811:      	movl	$0x8, %ecx
    1816:      	movl	$0x4, %eax
    181b:      	movl	$0x8, %esi
    1820:      	movq	%r13, %rdx
    1823:      	callq	*%rax
    1825:      	movq	0xc8(%rsp), %rbx
    182d:      	testq	%rbx, %rbx
    1830:      	je	0x190c <event_execve+0x190c>
    1836:      	movl	$0x0, 0xb4(%rsp)
    1841:      	movq	(%rip), %rdi            # 0x1848 <event_execve+0x1848>
    1848:      	leaq	0xb4(%rsp), %rsi
    1850:      	movl	$0x1, %eax
    1855:      	callq	*%rax
    1857:      	testq	%rax, %rax
    185a:      	je	0x1921 <event_execve+0x1921>
    1860:      	movq	%rax, %r13
    1863:      	leaq	0x28(%rbx), %rax
    1867:      	movq	%rax, 0x90(%rsp)
    186f:      	leaq	0x1000(%r13), %rax
    1876:      	movq	%rax, 0x80(%rsp)
    187e:      	movl	$0x23, %eax
    1883:      	callq	*%rax
    1885:      	leaq	0xd50(%rax), %rdx
    188c:      	leaq	0xd0(%rsp), %rdi
    1894:      	movl	$0x8, %ecx
    1899:      	movl	$0x4, %eax
    189e:      	movl	$0x8, %esi
    18a3:      	callq	*%rax
    18a5:      	movq	0xd0(%rsp), %r15
    18ad:      	addq	$0x30, %rbx
    18b1:      	leaq	0xa8(%rsp), %rdi
    18b9:      	movl	$0x8, %ecx
    18be:      	movl	$0x4, %eax
    18c3:      	leaq	0x18(%r15), %rbp
    18c7:      	movl	$0x8, %esi
    18cc:      	movq	%rbx, %rdx
    18cf:      	callq	*%rax
    18d1:      	movq	0xa8(%rsp), %r12
    18d9:      	leaq	0x10(%r12), %rdx
    18de:      	leaq	0x28(%rsp), %rdi
    18e3:      	movl	$0x8, %ecx
    18e8:      	movl	$0x4, %eax
    18ed:      	movl	$0x8, %esi
    18f2:      	callq	*%rax
    18f4:      	cmpq	$0x0, 0x28(%rsp)
    18fa:      	movl	$0x1000, %r14d          # imm = 0x1000
    1900:      	je	0x1930 <event_execve+0x1930>
    1902:      	movq	0x80(%rsp), %rcx
    190a:      	jmp	0x1985 <event_execve+0x1985>
    190c:      	orb	$0x20, 0x15d(%r14)
    1914:      	movq	0x88(%rsp), %r15
    191c:      	jmp	0x1e94 <event_execve+0x1e94>
    1921:      	xorl	%ebp, %ebp
    1923:      	movq	0x88(%rsp), %r15
    192b:      	jmp	0x1e94 <event_execve+0x1e94>
    1930:      	leaq	0x18(%r12), %rdx
    1935:      	leaq	0x28(%rsp), %rdi
    193a:      	movl	$0x8, %ecx
    193f:      	movl	$0x4, %eax
    1944:      	movl	$0x8, %esi
    1949:      	callq	*%rax
    194b:      	cmpq	%r12, 0x28(%rsp)
    1950:      	movq	0x80(%rsp), %rcx
    1958:      	je	0x1985 <event_execve+0x1985>
    195a:      	movq	%r13, %rcx
    195d:      	addq	$0xff6, %rcx            # imm = 0xFF6
    1964:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    196e:      	movq	%rax, 0xff6(%r13)
    1975:      	movw	$0x2964, 0xffe(%r13)    # imm = 0x2964
    197f:      	movl	$0xff6, %r14d           # imm = 0xFF6
    1985:      	movq	$0x0, 0x30(%rsp)
    198e:      	movq	$0x0, 0x28(%rsp)
    1997:      	movq	%r13, 0x38(%rsp)
    199c:      	movq	$0x0, 0x40(%rsp)
    19a5:      	movq	$0x0, 0x48(%rsp)
    19ae:      	movq	$0x0, 0x50(%rsp)
    19b7:      	movq	%rcx, 0x80(%rsp)
    19bf:      	movq	%rcx, 0x58(%rsp)
    19c4:      	movl	%r14d, 0x60(%rsp)
    19c9:      	movb	$0x0, 0x64(%rsp)
    19ce:      	addq	$0x20, %r15
    19d2:      	leaq	0x28(%rsp), %rdi
    19d7:      	movl	$0x8, %ecx
    19dc:      	movl	$0x4, %eax
    19e1:      	leaq	0x30(%rsp), %r13
    19e6:      	leaq	0x40(%rsp), %r14
    19eb:      	leaq	0x48(%rsp), %r12
    19f0:      	movl	$0x8, %esi
    19f5:      	movq	%r15, %rdx
    19f8:      	callq	*%rax
    19fa:      	movl	$0x8, %ecx
    19ff:      	movl	$0x4, %eax
    1a04:      	movq	%r13, %rdi
    1a07:      	movl	$0x8, %esi
    1a0c:      	movq	%rbp, %rdx
    1a0f:      	callq	*%rax
    1a11:      	movl	$0x8, %ecx
    1a16:      	movl	$0x4, %eax
    1a1b:      	movq	%r14, %rdi
    1a1e:      	movl	$0x8, %esi
    1a23:      	movq	%rbx, %rdx
    1a26:      	callq	*%rax
    1a28:      	movl	$0x8, %ecx
    1a2d:      	movl	$0x4, %eax
    1a32:      	movq	0x90(%rsp), %rdx
    1a3a:      	movq	%r12, %rdi
    1a3d:      	movl	$0x8, %esi
    1a42:      	callq	*%rax
    1a44:      	movq	0x48(%rsp), %rax
    1a49:      	addq	$-0x20, %rax
    1a4d:      	movq	%rax, 0x50(%rsp)
    1a52:      	movq	(%rip), %rax            # 0x1a59 <event_execve+0x1a59>
    1a59:      	cmpb	$0x0, (%rax)
    1a5c:      	je	0x1c1e <event_execve+0x1c1e>
    1a62:      	movl	$0x80, %r12d
    1a68:      	movl	$0x8, %r13d
    1a6e:      	movq	0x20(%rsp), %r14
    1a73:      	nopw	%cs:(%rax,%rax)
    1a80:      	movq	0x40(%rsp), %r15
    1a85:      	movq	0x48(%rsp), %rdx
    1a8a:      	movq	0x50(%rsp), %rbp
    1a8f:      	cmpq	0x28(%rsp), %r15
    1a94:      	jne	0x1aa1 <event_execve+0x1aa1>
    1a96:      	cmpq	0x30(%rsp), %rdx
    1a9b:      	je	0x1dbb <event_execve+0x1dbb>
    1aa1:      	movl	$0x4, %eax
    1aa6:      	leaq	0x78(%rsp), %rdi
    1aab:      	movl	$0x8, %esi
    1ab0:      	callq	*%rax
    1ab2:      	cmpq	0x78(%rsp), %r15
    1ab7:      	je	0x1bc0 <event_execve+0x1bc0>
    1abd:      	leaq	0x18(%r15), %rbx
    1ac1:      	movl	$0x4, %eax
    1ac6:      	leaq	0x18(%rsp), %rdi
    1acb:      	movl	$0x8, %esi
    1ad0:      	movq	%rbx, %rdx
    1ad3:      	callq	*%rax
    1ad5:      	cmpq	%r15, 0x18(%rsp)
    1ada:      	je	0x1bc0 <event_execve+0x1bc0>
    1ae0:      	movl	$0x4, %eax
    1ae5:      	leaq	0x70(%rsp), %rdi
    1aea:      	movl	$0x8, %esi
    1aef:      	movq	%rbx, %rdx
    1af2:      	callq	*%rax
    1af4:      	addq	$0x20, %r15
    1af8:      	movl	$0x4, %eax
    1afd:      	movq	%rsp, %rdi
    1b00:      	movl	$0x10, %ecx
    1b05:      	movl	$0x10, %esi
    1b0a:      	movq	%r15, %rdx
    1b0d:      	callq	*%rax
    1b0f:      	movq	0x38(%rsp), %rbx
    1b14:      	movq	0x58(%rsp), %rax
    1b19:      	movl	0x4(%rsp), %ebp
    1b1d:      	subq	%rbx, %rax
    1b20:      	movl	0x60(%rsp), %r14d
    1b25:      	movl	%ebp, %edx
    1b27:      	subl	%r14d, %edx
    1b2a:      	movl	$0x0, %ecx
    1b2f:      	cmovbl	%ecx, %edx
    1b32:      	addq	0x8(%rsp), %rdx
    1b37:      	xorl	%esi, %esi
    1b39:      	cmpl	%ebp, %r14d
    1b3c:      	seta	%sil
    1b40:      	movl	%ebp, %ecx
    1b42:      	cmovbl	%r14d, %ecx
    1b46:      	addl	%ecx, %esi
    1b48:      	movl	%r14d, %edi
    1b4b:      	subl	%esi, %edi
    1b4d:      	movl	%edi, 0x60(%rsp)
    1b51:      	subq	%rsi, %rax
    1b54:      	jb	0x1dc0 <event_execve+0x1dc0>
    1b5a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    1b60:      	ja	0x1dc0 <event_execve+0x1dc0>
    1b66:      	cmpl	%ebp, %r14d
    1b69:      	jbe	0x1b6f <event_execve+0x1b6f>
    1b6b:      	movb	$0x2f, (%rbx,%rax)
    1b6f:      	xorl	%edi, %edi
    1b71:      	cmpl	%ebp, %r14d
    1b74:      	seta	%dil
    1b78:      	movzbl	%cl, %esi
    1b7b:      	addq	%rax, %rbx
    1b7e:      	addq	%rbx, %rdi
    1b81:      	movl	$0x4, %eax
    1b86:      	callq	*%rax
    1b88:      	movq	%rbx, 0x58(%rsp)
    1b8d:      	cmpl	%ebp, %r14d
    1b90:      	jbe	0x1dc0 <event_execve+0x1dc0>
    1b96:      	movq	0x70(%rsp), %rax
    1b9b:      	movq	%rax, 0x40(%rsp)
    1ba0:      	movq	0x20(%rsp), %r14
    1ba5:      	decl	%r12d
    1ba8:      	jne	0x1a80 <event_execve+0x1a80>
    1bae:      	jmp	0x1dc5 <event_execve+0x1dc5>
    1bb3:      	nopw	%cs:(%rax,%rax)
    1bc0:      	leaq	0x10(%rbp), %rdx
    1bc4:      	movl	$0x4, %eax
    1bc9:      	leaq	0x18(%rsp), %rdi
    1bce:      	movl	$0x8, %esi
    1bd3:      	callq	*%rax
    1bd5:      	movq	0x50(%rsp), %rax
    1bda:      	cmpq	0x18(%rsp), %rax
    1bdf:      	je	0x1e18 <event_execve+0x1e18>
    1be5:      	addq	$0x18, %rbp
    1be9:      	movl	$0x4, %eax
    1bee:      	leaq	0x40(%rsp), %rdi
    1bf3:      	movl	$0x8, %esi
    1bf8:      	movq	%rbp, %rdx
    1bfb:      	callq	*%rax
    1bfd:      	movq	0x18(%rsp), %rax
    1c02:      	movq	%rax, 0x50(%rsp)
    1c07:      	addq	$0x20, %rax
    1c0b:      	movq	%rax, 0x48(%rsp)
    1c10:      	decl	%r12d
    1c13:      	jne	0x1a80 <event_execve+0x1a80>
    1c19:      	jmp	0x1dc5 <event_execve+0x1dc5>
    1c1e:      	movl	$0x80, %r12d
    1c24:      	movl	$0x8, %r13d
    1c2a:      	movq	0x20(%rsp), %r14
    1c2f:      	nop
    1c30:      	movq	0x40(%rsp), %r15
    1c35:      	movq	0x48(%rsp), %rdx
    1c3a:      	movq	0x50(%rsp), %rbp
    1c3f:      	cmpq	0x28(%rsp), %r15
    1c44:      	jne	0x1c51 <event_execve+0x1c51>
    1c46:      	cmpq	0x30(%rsp), %rdx
    1c4b:      	je	0x1dbb <event_execve+0x1dbb>
    1c51:      	movl	$0x4, %eax
    1c56:      	leaq	0x78(%rsp), %rdi
    1c5b:      	movl	$0x8, %esi
    1c60:      	callq	*%rax
    1c62:      	cmpq	0x78(%rsp), %r15
    1c67:      	je	0x1d60 <event_execve+0x1d60>
    1c6d:      	leaq	0x18(%r15), %rbx
    1c71:      	movl	$0x4, %eax
    1c76:      	leaq	0x18(%rsp), %rdi
    1c7b:      	movl	$0x8, %esi
    1c80:      	movq	%rbx, %rdx
    1c83:      	callq	*%rax
    1c85:      	cmpq	%r15, 0x18(%rsp)
    1c8a:      	je	0x1d60 <event_execve+0x1d60>
    1c90:      	movl	$0x4, %eax
    1c95:      	leaq	0x70(%rsp), %rdi
    1c9a:      	movl	$0x8, %esi
    1c9f:      	movq	%rbx, %rdx
    1ca2:      	callq	*%rax
    1ca4:      	addq	$0x20, %r15
    1ca8:      	movl	$0x4, %eax
    1cad:      	movq	%rsp, %rdi
    1cb0:      	movl	$0x10, %ecx
    1cb5:      	movl	$0x10, %esi
    1cba:      	movq	%r15, %rdx
    1cbd:      	callq	*%rax
    1cbf:      	movq	0x38(%rsp), %rbx
    1cc4:      	movq	0x58(%rsp), %rax
    1cc9:      	movl	0x4(%rsp), %ebp
    1ccd:      	subq	%rbx, %rax
    1cd0:      	movl	0x60(%rsp), %r14d
    1cd5:      	movl	%ebp, %edx
    1cd7:      	subl	%r14d, %edx
    1cda:      	movl	$0x0, %ecx
    1cdf:      	cmovbl	%ecx, %edx
    1ce2:      	addq	0x8(%rsp), %rdx
    1ce7:      	xorl	%esi, %esi
    1ce9:      	cmpl	%ebp, %r14d
    1cec:      	seta	%sil
    1cf0:      	movl	%ebp, %ecx
    1cf2:      	cmovbl	%r14d, %ecx
    1cf6:      	addl	%ecx, %esi
    1cf8:      	movl	%r14d, %edi
    1cfb:      	subl	%esi, %edi
    1cfd:      	movl	%edi, 0x60(%rsp)
    1d01:      	subq	%rsi, %rax
    1d04:      	jb	0x1dc0 <event_execve+0x1dc0>
    1d0a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    1d10:      	ja	0x1dc0 <event_execve+0x1dc0>
    1d16:      	cmpl	%ebp, %r14d
    1d19:      	jbe	0x1d1f <event_execve+0x1d1f>
    1d1b:      	movb	$0x2f, (%rbx,%rax)
    1d1f:      	xorl	%edi, %edi
    1d21:      	cmpl	%ebp, %r14d
    1d24:      	seta	%dil
    1d28:      	movzbl	%cl, %esi
    1d2b:      	addq	%rax, %rbx
    1d2e:      	addq	%rbx, %rdi
    1d31:      	movl	$0x4, %eax
    1d36:      	callq	*%rax
    1d38:      	movq	%rbx, 0x58(%rsp)
    1d3d:      	cmpl	%ebp, %r14d
    1d40:      	jbe	0x1dc0 <event_execve+0x1dc0>
    1d42:      	movq	0x70(%rsp), %rax
    1d47:      	movq	%rax, 0x40(%rsp)
    1d4c:      	movq	0x20(%rsp), %r14
    1d51:      	decl	%r12d
    1d54:      	jne	0x1c30 <event_execve+0x1c30>
    1d5a:      	jmp	0x1dc5 <event_execve+0x1dc5>
    1d5c:      	nopl	(%rax)
    1d60:      	leaq	0x10(%rbp), %rdx
    1d64:      	movl	$0x4, %eax
    1d69:      	leaq	0x18(%rsp), %rdi
    1d6e:      	movl	$0x8, %esi
    1d73:      	callq	*%rax
    1d75:      	movq	0x50(%rsp), %rax
    1d7a:      	cmpq	0x18(%rsp), %rax
    1d7f:      	je	0x1e18 <event_execve+0x1e18>
    1d85:      	addq	$0x18, %rbp
    1d89:      	movl	$0x4, %eax
    1d8e:      	leaq	0x40(%rsp), %rdi
    1d93:      	movl	$0x8, %esi
    1d98:      	movq	%rbp, %rdx
    1d9b:      	callq	*%rax
    1d9d:      	movq	0x18(%rsp), %rax
    1da2:      	movq	%rax, 0x50(%rsp)
    1da7:      	addq	$0x20, %rax
    1dab:      	movq	%rax, 0x48(%rsp)
    1db0:      	decl	%r12d
    1db3:      	jne	0x1c30 <event_execve+0x1c30>
    1db9:      	jmp	0x1dc5 <event_execve+0x1dc5>
    1dbb:      	movb	$0x1, 0x64(%rsp)
    1dc0:      	movq	0x20(%rsp), %r14
    1dc5:      	movq	0x58(%rsp), %rax
    1dca:      	movq	0x80(%rsp), %rdx
    1dd2:      	cmpq	%rdx, %rax
    1dd5:      	je	0x1e2f <event_execve+0x1e2f>
    1dd7:      	xorl	%ebx, %ebx
    1dd9:      	cmpb	$0x0, 0x64(%rsp)
    1dde:      	sete	%cl
    1de1:      	movl	0x60(%rsp), %edx
    1de5:      	movl	$0x1000, %ebp           # imm = 0x1000
    1dea:      	subl	%edx, %ebp
    1dec:      	testl	%edx, %edx
    1dee:      	cmovlel	%edx, %ebp
    1df1:      	testq	%rax, %rax
    1df4:      	movq	0x10(%rsp), %r12
    1df9:      	movq	0x88(%rsp), %r15
    1e01:      	movq	0x98(%rsp), %rdi
    1e09:      	je	0x1e14 <event_execve+0x1e14>
    1e0b:      	movb	%cl, %bl
    1e0d:      	addl	%ebx, %ebx
    1e0f:      	movq	%rax, %rdx
    1e12:      	jmp	0x1e48 <event_execve+0x1e48>
    1e14:      	xorl	%ebp, %ebp
    1e16:      	jmp	0x1e94 <event_execve+0x1e94>
    1e18:      	movb	$0x1, 0x64(%rsp)
    1e1d:      	movq	0x58(%rsp), %rax
    1e22:      	movq	0x80(%rsp), %rdx
    1e2a:      	cmpq	%rdx, %rax
    1e2d:      	jne	0x1dd7 <event_execve+0x1dd7>
    1e2f:      	xorl	%ebp, %ebp
    1e31:      	xorl	%ebx, %ebx
    1e33:      	movq	0x10(%rsp), %r12
    1e38:      	movq	0x88(%rsp), %r15
    1e40:      	movq	0x98(%rsp), %rdi
    1e48:      	andl	$0x3ff, %edi            # imm = 0x3FF
    1e4e:      	andl	$0xfff, %ebp            # imm = 0xFFF
    1e54:      	addq	%r15, %rdi
    1e57:      	movl	$0x4, %eax
    1e5c:      	movl	%ebp, %esi
    1e5e:      	callq	*%rax
    1e60:      	movl	0x15c(%r14), %eax
    1e67:      	movl	%eax, %ecx
    1e69:      	orl	$0x1000, %ecx           # imm = 0x1000
    1e6f:      	testl	%ebp, %ebp
    1e71:      	cmovnel	%eax, %ecx
    1e74:      	movl	%ecx, %eax
    1e76:      	orl	$0x400000, %eax         # imm = 0x400000
    1e7b:      	testl	%ebx, %ebx
    1e7d:      	cmovel	%ecx, %eax
    1e80:      	andl	$0xffffdbff, %eax       # imm = 0xFFFFDBFF
    1e85:      	movl	%eax, 0x15c(%r14)
    1e8c:      	movw	%bp, 0x17c(%r14)
    1e94:      	movl	(%r15), %r13d
    1e97:      	addl	%ebp, %r13d
    1e9a:      	movl	%r13d, (%r15)
    1e9d:      	movq	$0x0, (%rsp)
    1ea5:      	movq	(%rip), %rax            # 0x1eac <event_execve+0x1eac>
    1eac:      	xorl	%ebx, %ebx
    1eae:      	cmpb	$0x0, (%rax)
    1eb1:      	je	0x234f <event_execve+0x234f>
    1eb7:      	cmpl	$0x3ff, %r13d           # imm = 0x3FF
    1ebe:      	ja	0x234f <event_execve+0x234f>
    1ec4:      	movl	$0x23, %eax
    1ec9:      	callq	*%rax
    1ecb:      	leaq	0xa78(%rax), %rdx
    1ed2:      	movq	%rsp, %rdi
    1ed5:      	movl	$0x8, %ecx
    1eda:      	movl	$0x4, %eax
    1edf:      	movl	$0x8, %esi
    1ee4:      	callq	*%rax
    1ee6:      	movq	(%rsp), %rcx
    1eea:      	testq	%rcx, %rcx
    1eed:      	je	0x234f <event_execve+0x234f>
    1ef3:      	addq	$0x2c8, %rcx            # imm = 0x2C8
    1efa:      	leaq	0x18(%rsp), %rdi
    1eff:      	movl	$0x8, %edx
    1f04:      	movl	$0x4, %eax
    1f09:      	movl	$0x2c8, %edx            # imm = 0x2C8
    1f0e:      	addq	(%rsp), %rdx
    1f12:      	movl	$0x8, %esi
    1f17:      	callq	*%rax
    1f19:      	testq	%rax, %rax
    1f1c:      	je	0x1f7b <event_execve+0x1f7b>
    1f1e:      	negl	%eax
    1f20:      	movw	%ax, 0x28(%rsp)
    1f25:      	movw	$0x9, 0x2a(%rsp)
    1f2c:      	movabsq	$0x40000009a, %rax      # imm = 0x40000009A
    1f36:      	movq	%rax, 0x2c(%rsp)
    1f3b:      	movq	(%rip), %rdi            # 0x1f42 <event_execve+0x1f42>
    1f42:      	leaq	0x28(%rsp), %rsi
    1f47:      	movl	$0x1, %eax
    1f4c:      	callq	*%rax
    1f4e:      	testq	%rax, %rax
    1f51:      	je	0x1f57 <event_execve+0x1f57>
    1f53:      	incl	(%rax)
    1f55:      	jmp	0x1f7b <event_execve+0x1f7b>
    1f57:      	movl	$0x1, 0x70(%rsp)
    1f5f:      	movq	(%rip), %rdi            # 0x1f66 <event_execve+0x1f66>
    1f66:      	xorl	%ecx, %ecx
    1f68:      	leaq	0x28(%rsp), %rsi
    1f6d:      	leaq	0x70(%rsp), %rdx
    1f72:      	movl	$0x2, %eax
    1f77:      	xorl	%ecx, %ecx
    1f79:      	callq	*%rax
    1f7b:      	movl	$0x2d0, %edx            # imm = 0x2D0
    1f80:      	movq	(%rsp), %rcx
    1f84:      	addq	%rdx, %rcx
    1f87:      	leaq	0x70(%rsp), %rdi
    1f8c:      	movl	$0x8, %esi
    1f91:      	movl	$0x4, %eax
    1f96:      	addq	(%rsp), %rdx
    1f9a:      	movl	$0x8, %esi
    1f9f:      	callq	*%rax
    1fa1:      	testq	%rax, %rax
    1fa4:      	je	0x1fe1 <event_execve+0x1fe1>
    1fa6:      	negl	%eax
    1fa8:      	movw	%ax, 0x28(%rsp)
    1fad:      	movw	$0x9, 0x2a(%rsp)
    1fb4:      	movabsq	$0x40000009b, %rax      # imm = 0x40000009B
    1fbe:      	movq	%rax, 0x2c(%rsp)
    1fc3:      	movq	(%rip), %rdi            # 0x1fca <event_execve+0x1fca>
    1fca:      	leaq	0x28(%rsp), %rsi
    1fcf:      	movl	$0x1, %eax
    1fd4:      	callq	*%rax
    1fd6:      	testq	%rax, %rax
    1fd9:      	je	0x2213 <event_execve+0x2213>
    1fdf:      	incl	(%rax)
    1fe1:      	movq	0x18(%rsp), %rdx
    1fe6:      	testq	%rdx, %rdx
    1fe9:      	je	0x234f <event_execve+0x234f>
    1fef:      	movq	0x70(%rsp), %rax
    1ff4:      	testq	%rax, %rax
    1ff7:      	je	0x234f <event_execve+0x234f>
    1ffd:      	movl	%r13d, %r15d
    2000:      	movq	%rax, %rbx
    2003:      	subq	%rdx, %rbx
    2006:      	cmpq	$0x3ff, %rbx            # imm = 0x3FF
    200d:      	ja	0x205c <event_execve+0x205c>
    200f:      	leaq	(%r14,%r15), %rdi
    2013:      	addq	$0x140, %rdi            # imm = 0x140
    201a:      	leaq	0x540(%r14), %rcx
    2021:      	subq	%rdi, %rcx
    2024:      	cmpq	%rcx, %rbx
    2027:      	jae	0x205c <event_execve+0x205c>
    2029:      	decl	%ebx
    202b:      	andl	$0x3ff, %ebx            # imm = 0x3FF
    2031:      	xorl	%ebp, %ebp
    2033:      	cmpq	%rdx, %rax
    2036:      	cmovel	%ebp, %ebx
    2039:      	movl	$0x4, %eax
    203e:      	movq	0x18(%rsp), %rdx
    2043:      	movl	%ebx, %esi
    2045:      	callq	*%rax
    2047:      	andl	$0x80000000, %eax       # imm = 0x80000000
    204c:      	movl	%eax, %ecx
    204e:      	shrl	$0x1c, %ecx
    2051:      	testq	%rax, %rax
    2054:      	cmovnel	%ebp, %ebx
    2057:      	jmp	0x2340 <event_execve+0x2340>
    205c:      	movq	%rdx, 0x88(%rsp)
    2064:      	movl	$0x0, 0x78(%rsp)
    206c:      	movq	(%rip), %rdi            # 0x2073 <event_execve+0x2073>
    2073:      	leaq	0x78(%rsp), %rsi
    2078:      	movl	$0x1, %eax
    207d:      	callq	*%rax
    207f:      	testq	%rax, %rax
    2082:      	je	0x224a <event_execve+0x224a>
    2088:      	movq	%rax, %r13
    208b:      	addq	%r14, %r15
    208e:      	movl	$0x18, (%rax)
    2094:      	movl	$0xe, %eax
    2099:      	callq	*%rax
    209b:      	leaq	0x10(%r13), %r14
    209f:      	movq	%rax, 0x10(%r13)
    20a3:      	cmpq	$-0x16, %rax
    20a7:      	jne	0x20cc <event_execve+0x20cc>
    20a9:      	leaq	0x20(%r12), %rdx
    20ae:      	leaq	0x28(%rsp), %rdi
    20b3:      	movl	$0x8, %ecx
    20b8:      	movl	$0x4, %eax
    20bd:      	movl	$0x8, %esi
    20c2:      	callq	*%rax
    20c4:      	movq	0x28(%rsp), %rax
    20c9:      	movq	%rax, (%r14)
    20cc:      	movl	$0x7d, %eax
    20d1:      	callq	*%rax
    20d3:      	movq	%rax, 0x18(%r13)
    20d7:      	movq	(%r14), %rax
    20da:      	movq	0x8(%r14), %rcx
    20de:      	movq	%rax, 0x150(%r15)
    20e5:      	movq	%r15, 0x90(%rsp)
    20ed:      	movq	%rcx, 0x158(%r15)
    20f4:      	movq	%r13, 0x80(%rsp)
    20fc:      	movq	%r13, %r12
    20ff:      	addq	$0x20, %r12
    2103:      	movl	$0xa, %r15d
    2109:      	xorl	%ebp, %ebp
    210b:      	movq	0x20(%rsp), %r14
    2110:      	movq	0x88(%rsp), %rcx
    2118:      	movq	%r12, 0x98(%rsp)
    2120:      	movq	%rbx, %r13
    2123:      	subq	%rbp, %r13
    2126:      	js	0x2253 <event_execve+0x2253>
    212c:      	leaq	(%rcx,%rbp), %rdx
    2130:      	cmpq	$0x7fe0, %r13           # imm = 0x7FE0
    2137:      	movl	$0x7fe0, %eax           # imm = 0x7FE0
    213c:      	cmovaeq	%rax, %r13
    2140:      	movl	$0x4, %eax
    2145:      	movq	%r12, %rdi
    2148:      	movl	%r13d, %esi
    214b:      	callq	*%rax
    214d:      	testl	%eax, %eax
    214f:      	js	0x21ac <event_execve+0x21ac>
    2151:      	leal	0x20(%r13), %r12d
    2155:      	movq	0x80(%rsp), %rax
    215d:      	movl	%r12d, 0x4(%rax)
    2161:      	movl	$0x0, 0x28(%rsp)
    2169:      	movl	$0x1, %eax
    216e:      	movq	(%rip), %rdi            # 0x2175 <event_execve+0x2175>
    2175:      	leaq	0x28(%rsp), %rsi
    217a:      	callq	*%rax
    217c:      	testq	%rax, %rax
    217f:      	je	0x21b9 <event_execve+0x21b9>
    2181:      	cmpb	$0x0, 0x28(%rax)
    2185:      	je	0x21b9 <event_execve+0x21b9>
    2187:      	movl	$0x19, %eax
    218c:      	movq	0x10(%rsp), %rdi
    2191:      	movq	0x80(%rsp), %rcx
    2199:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    219e:      	movq	(%rip), %rsi            # 0x21a5 <event_execve+0x21a5>
    21a5:      	movq	%r12, %r8
    21a8:      	callq	*%rax
    21aa:      	jmp	0x21d6 <event_execve+0x21d6>
    21ac:      	movslq	%eax, %r13
    21af:      	movq	0x88(%rsp), %rcx
    21b7:      	jmp	0x21ed <event_execve+0x21ed>
    21b9:      	movl	$0x82, %eax
    21be:      	movq	0x80(%rsp), %rsi
    21c6:      	xorl	%ecx, %ecx
    21c8:      	movq	(%rip), %rdi            # 0x21cf <event_execve+0x21cf>
    21cf:      	movq	%r12, %rdx
    21d2:      	xorl	%ecx, %ecx
    21d4:      	callq	*%rax
    21d6:      	testl	%eax, %eax
    21d8:      	movq	0x88(%rsp), %rcx
    21e0:      	movq	0x98(%rsp), %r12
    21e8:      	jns	0x21ed <event_execve+0x21ed>
    21ea:      	movslq	%eax, %r13
    21ed:      	testl	%r13d, %r13d
    21f0:      	js	0x225c <event_execve+0x225c>
    21f2:      	andl	$0x7fffffff, %r13d      # imm = 0x7FFFFFFF
    21f9:      	addq	%r13, %rbp
    21fc:      	cmpq	%rbx, %rbp
    21ff:      	je	0x229f <event_execve+0x229f>
    2205:      	decl	%r15d
    2208:      	jne	0x2120 <event_execve+0x2120>
    220e:      	jmp	0x22e8 <event_execve+0x22e8>
    2213:      	movl	$0x1, 0x78(%rsp)
    221b:      	movq	(%rip), %rdi            # 0x2222 <event_execve+0x2222>
    2222:      	xorl	%ecx, %ecx
    2224:      	leaq	0x28(%rsp), %rsi
    2229:      	leaq	0x78(%rsp), %rdx
    222e:      	movl	$0x2, %eax
    2233:      	xorl	%ecx, %ecx
    2235:      	callq	*%rax
    2237:      	movq	0x18(%rsp), %rdx
    223c:      	testq	%rdx, %rdx
    223f:      	jne	0x1fef <event_execve+0x1fef>
    2245:      	jmp	0x234f <event_execve+0x234f>
    224a:      	xorl	%ecx, %ecx
    224c:      	xorl	%ebx, %ebx
    224e:      	jmp	0x2340 <event_execve+0x2340>
    2253:      	movq	$-0x1, %rbp
    225a:      	jmp	0x225f <event_execve+0x225f>
    225c:      	movq	%r13, %rbp
    225f:      	movl	$0x0, 0x28(%rsp)
    2267:      	movq	(%rip), %rdi            # 0x226e <event_execve+0x226e>
    226e:      	leaq	0x28(%rsp), %rsi
    2273:      	movl	$0x1, %eax
    2278:      	callq	*%rax
    227a:      	testq	%rax, %rax
    227d:      	je	0x22e8 <event_execve+0x22e8>
    227f:      	cmpq	$-0xc, %rbp
    2283:      	jg	0x22a4 <event_execve+0x22a4>
    2285:      	cmpq	$-0x1c, %rbp
    2289:      	je	0x22be <event_execve+0x22be>
    228b:      	cmpq	$-0x16, %rbp
    228f:      	je	0x22d6 <event_execve+0x22d6>
    2291:      	cmpq	$-0x10, %rbp
    2295:      	jne	0x22ce <event_execve+0x22ce>
    2297:      	addq	$0x558, %rax            # imm = 0x558
    229d:      	jmp	0x22e4 <event_execve+0x22e4>
    229f:      	movq	%rbx, %rbp
    22a2:      	jmp	0x22e8 <event_execve+0x22e8>
    22a4:      	cmpq	$-0xb, %rbp
    22a8:      	je	0x22c6 <event_execve+0x22c6>
    22aa:      	cmpq	$-0x7, %rbp
    22ae:      	je	0x22de <event_execve+0x22de>
    22b0:      	cmpq	$-0x2, %rbp
    22b4:      	jne	0x22ce <event_execve+0x22ce>
    22b6:      	addq	$0x548, %rax            # imm = 0x548
    22bc:      	jmp	0x22e4 <event_execve+0x22e4>
    22be:      	addq	$0x568, %rax            # imm = 0x568
    22c4:      	jmp	0x22e4 <event_execve+0x22e4>
    22c6:      	addq	$0x570, %rax            # imm = 0x570
    22cc:      	jmp	0x22e4 <event_execve+0x22e4>
    22ce:      	addq	$0x540, %rax            # imm = 0x540
    22d4:      	jmp	0x22e4 <event_execve+0x22e4>
    22d6:      	addq	$0x560, %rax            # imm = 0x560
    22dc:      	jmp	0x22e4 <event_execve+0x22e4>
    22de:      	addq	$0x550, %rax            # imm = 0x550
    22e4:      	lock
    22e5:      	incq	(%rax)
    22e8:      	testl	%ebp, %ebp
    22ea:      	js	0x230e <event_execve+0x230e>
    22ec:      	movq	0x90(%rsp), %rdx
    22f4:      	movq	$0x0, 0x140(%rdx)
    22ff:      	movl	%ebx, %ecx
    2301:      	subl	%ebp, %ecx
    2303:      	xorl	%eax, %eax
    2305:      	cmpq	$-0x1, %rbx
    2309:      	cmovnel	%ecx, %eax
    230c:      	jmp	0x232a <event_execve+0x232a>
    230e:      	movq	0x90(%rsp), %rdx
    2316:      	movl	%ebp, 0x140(%rdx)
    231c:      	movl	$0x0, 0x144(%rdx)
    2326:      	xorl	%eax, %eax
    2328:      	xorl	%ebp, %ebp
    232a:      	movl	%eax, 0x148(%rdx)
    2330:      	movl	%ebp, 0x14c(%rdx)
    2336:      	movl	$0x20, %ebx
    233b:      	movl	$0x2, %ecx
    2340:      	movw	%bx, 0x17e(%r14)
    2348:      	orl	%ecx, 0x15c(%r14)
    234f:      	movl	0x140(%r14), %eax
    2356:      	leal	(%rax,%rbx), %ecx
    2359:      	movl	%ecx, 0x140(%r14)
    2360:      	movw	$0x5, (%r14)
    2366:      	movq	0x170(%r14), %rcx
    236d:      	movq	%rcx, 0x8(%r14)
    2371:      	leal	0x140(%rax,%rbx), %eax
    2378:      	movl	%eax, 0x4(%r14)
    237c:      	movq	0xa0(%rsp), %rbp
    2384:      	leaq	0xd00(%rbp), %r12
    238b:      	leaq	0x28(%rsp), %rdi
    2390:      	movl	$0x8, %ecx
    2395:      	movl	$0x4, %eax
    239a:      	leaq	0xb8(%r14), %rbx
    23a1:      	movl	$0x4, %r13d
    23a7:      	movl	$0x8, %esi
    23ac:      	movq	%r12, %rdx
    23af:      	callq	*%rax
    23b1:      	movq	0x28(%rsp), %rcx
    23b6:      	addq	$0x8, %rcx
    23ba:      	movl	$0x4, %edx
    23bf:      	movl	$0x4, %eax
    23c4:      	movq	0x28(%rsp), %rdx
    23c9:      	addq	$0x8, %rdx
    23cd:      	movq	%rbx, %rdi
    23d0:      	movl	$0x4, %esi
    23d5:      	callq	*%rax
    23d7:      	leaq	0xbc(%r14), %rdi
    23de:      	movq	0x28(%rsp), %rcx
    23e3:      	addq	$0xc, %rcx
    23e7:      	movl	$0x4, %edx
    23ec:      	movl	$0x4, %eax
    23f1:      	movq	0x28(%rsp), %rdx
    23f6:      	addq	$0xc, %rdx
    23fa:      	movl	$0x4, %esi
    23ff:      	callq	*%rax
    2401:      	leaq	0xc8(%r14), %rdi
    2408:      	movq	0x28(%rsp), %rcx
    240d:      	addq	$0x18, %rcx
    2411:      	movl	$0x4, %edx
    2416:      	movl	$0x4, %eax
    241b:      	movq	0x28(%rsp), %rdx
    2420:      	addq	$0x18, %rdx
    2424:      	movl	$0x4, %esi
    2429:      	callq	*%rax
    242b:      	leaq	0xcc(%r14), %rdi
    2432:      	movq	0x28(%rsp), %rcx
    2437:      	addq	$0x1c, %rcx
    243b:      	movl	$0x4, %edx
    2440:      	movl	$0x4, %eax
    2445:      	movq	0x28(%rsp), %rdx
    244a:      	addq	$0x1c, %rdx
    244e:      	movl	$0x4, %esi
    2453:      	callq	*%rax
    2455:      	leaq	0xc0(%r14), %rdi
    245c:      	movq	0x28(%rsp), %rcx
    2461:      	addq	$0x10, %rcx
    2465:      	movl	$0x4, %edx
    246a:      	movl	$0x4, %eax
    246f:      	movq	0x28(%rsp), %rdx
    2474:      	addq	$0x10, %rdx
    2478:      	movl	$0x4, %esi
    247d:      	callq	*%rax
    247f:      	leaq	0xc4(%r14), %rdi
    2486:      	movq	0x28(%rsp), %rcx
    248b:      	addq	$0x14, %rcx
    248f:      	movl	$0x4, %edx
    2494:      	movl	$0x4, %eax
    2499:      	movq	0x28(%rsp), %rdx
    249e:      	addq	$0x14, %rdx
    24a2:      	movl	$0x4, %esi
    24a7:      	callq	*%rax
    24a9:      	leaq	0xd0(%r14), %rdi
    24b0:      	movq	0x28(%rsp), %rcx
    24b5:      	addq	$0x20, %rcx
    24b9:      	movl	$0x4, %edx
    24be:      	movl	$0x4, %eax
    24c3:      	movq	0x28(%rsp), %rdx
    24c8:      	addq	$0x20, %rdx
    24cc:      	movl	$0x4, %esi
    24d1:      	callq	*%rax
    24d3:      	leaq	0xd4(%r14), %rdi
    24da:      	movq	0x28(%rsp), %rcx
    24df:      	addq	$0x24, %rcx
    24e3:      	movl	$0x4, %edx
    24e8:      	movl	$0x4, %eax
    24ed:      	movq	0x28(%rsp), %rdx
    24f2:      	addq	$0x24, %rdx
    24f6:      	movl	$0x4, %esi
    24fb:      	callq	*%rax
    24fd:      	leaq	0xd8(%r14), %rdi
    2504:      	movq	0x28(%rsp), %rcx
    2509:      	addq	$0x28, %rcx
    250d:      	movl	$0x4, %edx
    2512:      	movl	$0x4, %eax
    2517:      	movq	0x28(%rsp), %rdx
    251c:      	addq	$0x28, %rdx
    2520:      	movl	$0x4, %esi
    2525:      	callq	*%rax
    2527:      	movq	0x28(%rsp), %rbx
    252c:      	leaq	0xe8(%r14), %rdi
    2533:      	leaq	0x40(%rbx), %rdx
    2537:      	movl	$0x8, %ecx
    253c:      	movl	$0x4, %eax
    2541:      	leaq	0xe0(%r14), %r15
    2548:      	movl	$0x8, %esi
    254d:      	callq	*%rax
    254f:      	leaq	0xf0(%r14), %rdi
    2556:      	leaq	0x30(%rbx), %rdx
    255a:      	movl	$0x8, %ecx
    255f:      	movl	$0x4, %eax
    2564:      	movl	$0x8, %esi
    2569:      	callq	*%rax
    256b:      	addq	$0x38, %rbx
    256f:      	movl	$0x8, %ecx
    2574:      	movl	$0x4, %eax
    2579:      	movq	%r15, %rdi
    257c:      	movl	$0x8, %esi
    2581:      	movq	%rbx, %rdx
    2584:      	callq	*%rax
    2586:      	movl	0xc8(%r14), %eax
    258d:      	movl	%eax, 0x154(%r14)
    2594:      	leaq	0xd70(%rbp), %rdx
    259b:      	leaq	0x18(%rsp), %rdi
    25a0:      	movl	$0x8, %ecx
    25a5:      	movl	$0x4, %eax
    25aa:      	leaq	0x108(%r14), %rbx
    25b1:      	movl	$0x8, %esi
    25b6:      	callq	*%rax
    25b8:      	movq	0x18(%rsp), %rcx
    25bd:      	leaq	0x28(%rsp), %rdi
    25c2:      	movl	$0x48, %edx
    25c7:      	movl	$0x4, %eax
    25cc:      	movq	0x18(%rsp), %rdx
    25d1:      	movl	$0x48, %esi
    25d6:      	callq	*%rax
    25d8:      	movl	$0x218, %edx            # imm = 0x218
    25dd:      	movq	0x30(%rsp), %rcx
    25e2:      	addq	%rdx, %rcx
    25e5:      	movl	$0x4, %esi
    25ea:      	movl	$0x4, %eax
    25ef:      	addq	0x30(%rsp), %rdx
    25f4:      	movq	%rbx, %rdi
    25f7:      	movl	$0x4, %esi
    25fc:      	callq	*%rax
    25fe:      	leaq	0x10c(%r14), %rdi
    2605:      	movl	$0x4d8, %edx            # imm = 0x4D8
    260a:      	movq	0x38(%rsp), %rcx
    260f:      	addq	%rdx, %rcx
    2612:      	movl	$0x4, %esi
    2617:      	movl	$0x4, %eax
    261c:      	addq	0x38(%rsp), %rdx
    2621:      	movl	$0x4, %esi
    2626:      	callq	*%rax
    2628:      	leaq	0x110(%r14), %rdi
    262f:      	movq	0x40(%rsp), %rcx
    2634:      	addq	$0x58, %rcx
    2638:      	movl	$0x4, %edx
    263d:      	movl	$0x4, %eax
    2642:      	movq	0x40(%rsp), %rdx
    2647:      	addq	$0x58, %rdx
    264b:      	movl	$0x4, %esi
    2650:      	callq	*%rax
    2652:      	movq	$0x0, 0x70(%rsp)
    265b:      	leaq	0xb58(%rbp), %rdx
    2662:      	leaq	0x70(%rsp), %rdi
    2667:      	movl	$0x8, %ecx
    266c:      	movl	$0x4, %eax
    2671:      	movl	$0x8, %esi
    2676:      	callq	*%rax
    2678:      	movq	0x70(%rsp), %rcx
    267d:      	testq	%rcx, %rcx
    2680:      	je	0x2717 <event_execve+0x2717>
    2686:      	movl	$0x0, 0x78(%rsp)
    268e:      	addq	$0x4, %rcx
    2692:      	leaq	0x78(%rsp), %rdi
    2697:      	movl	$0x4, %eax
    269c:      	movq	0x70(%rsp), %rdx
    26a1:      	addq	$0x4, %rdx
    26a5:      	movl	$0x4, %esi
    26aa:      	callq	*%rax
    26ac:      	movq	0x70(%rsp), %rax
    26b1:      	movslq	0x78(%rsp), %rcx
    26b6:      	shlq	$0x4, %rcx
    26ba:      	addq	%rax, %rcx
    26bd:      	addq	$0x80, %rcx
    26c4:      	movq	%rsp, %rdi
    26c7:      	movl	$0x10, %edx
    26cc:      	movl	$0x4, %eax
    26d1:      	movq	0x70(%rsp), %rcx
    26d6:      	movslq	0x78(%rsp), %rdx
    26db:      	shlq	$0x4, %rdx
    26df:      	addq	%rcx, %rdx
    26e2:      	addq	$0x80, %rdx
    26e9:      	movl	$0x10, %esi
    26ee:      	callq	*%rax
    26f0:      	leaq	0x114(%r14), %rdi
    26f7:      	movl	$0x158, %edx            # imm = 0x158
    26fc:      	movq	0x8(%rsp), %rcx
    2701:      	addq	%rdx, %rcx
    2704:      	movl	$0x4, %eax
    2709:      	addq	0x8(%rsp), %rdx
    270e:      	movl	$0x4, %esi
    2713:      	callq	*%rax
    2715:      	jmp	0x2722 <event_execve+0x2722>
    2717:      	movl	$0x0, 0x114(%r14)
    2722:      	leaq	0x118(%r14), %rdi
    2729:      	movl	$0x158, %ebx            # imm = 0x158
    272e:      	movq	0x48(%rsp), %rcx
    2733:      	addq	%rbx, %rcx
    2736:      	movl	$0x4, %edx
    273b:      	movl	$0x4, %eax
    2740:      	movq	0x48(%rsp), %rdx
    2745:      	addq	%rbx, %rdx
    2748:      	movl	$0x4, %esi
    274d:      	callq	*%rax
    274f:      	leaq	0x11c(%r14), %rdi
    2756:      	movl	$0x118, %edx            # imm = 0x118
    275b:      	movq	0x50(%rsp), %rcx
    2760:      	addq	%rdx, %rcx
    2763:      	movl	$0x4, %esi
    2768:      	movl	$0x4, %eax
    276d:      	addq	0x50(%rsp), %rdx
    2772:      	movl	$0x4, %esi
    2777:      	callq	*%rax
    2779:      	leaq	0x120(%r14), %rdi
    2780:      	movl	$0x98, %r15d
    2786:      	movq	0x58(%rsp), %rcx
    278b:      	addq	%r15, %rcx
    278e:      	movl	$0x4, %edx
    2793:      	movl	$0x4, %eax
    2798:      	movq	0x58(%rsp), %rdx
    279d:      	addq	%r15, %rdx
    27a0:      	movl	$0x4, %esi
    27a5:      	callq	*%rax
    27a7:      	leaq	0x124(%r14), %rdi
    27ae:      	movq	0x60(%rsp), %rcx
    27b3:      	addq	%r15, %rcx
    27b6:      	movl	$0x4, %edx
    27bb:      	movl	$0x4, %eax
    27c0:      	addq	0x60(%rsp), %r15
    27c5:      	movl	$0x4, %esi
    27ca:      	movq	%r15, %rdx
    27cd:      	callq	*%rax
    27cf:      	leaq	0x128(%r14), %rdi
    27d6:      	movq	0x68(%rsp), %rcx
    27db:      	addq	$0x58, %rcx
    27df:      	movl	$0x4, %edx
    27e4:      	movl	$0x4, %eax
    27e9:      	movq	0x68(%rsp), %rdx
    27ee:      	addq	$0x58, %rdx
    27f2:      	movl	$0x4, %esi
    27f7:      	callq	*%rax
    27f9:      	movq	$0x0, (%rsp)
    2801:      	movq	$0x0, 0x70(%rsp)
    280a:      	movq	%rsp, %rdi
    280d:      	movl	$0x8, %ecx
    2812:      	movl	$0x4, %eax
    2817:      	movl	$0x8, %esi
    281c:      	movq	%r12, %rdx
    281f:      	callq	*%rax
    2821:      	movl	$0x90, %edx
    2826:      	movq	(%rsp), %rcx
    282a:      	addq	%rdx, %rcx
    282d:      	leaq	0x70(%rsp), %rdi
    2832:      	movl	$0x8, %esi
    2837:      	movl	$0x4, %eax
    283c:      	addq	(%rsp), %rdx
    2840:      	movl	$0x8, %esi
    2845:      	callq	*%rax
    2847:      	leaq	0x12c(%r14), %rdi
    284e:      	movq	0x70(%rsp), %rcx
    2853:      	addq	%rbx, %rcx
    2856:      	movl	$0x4, %edx
    285b:      	movl	$0x4, %eax
    2860:      	addq	0x70(%rsp), %rbx
    2865:      	movl	$0x4, %esi
    286a:      	movq	%rbx, %rdx
    286d:      	callq	*%rax
    286f:      	leaq	0x10(%r14), %rbx
    2873:      	movl	$0x0, 0x70(%rsp)
    287b:      	xorl	%ebp, %ebp
    287d:      	movl	$0x90, %edx
    2882:      	movq	%rbx, %rdi
    2885:      	xorl	%esi, %esi
    2887:      	callq	0x288c <event_execve+0x288c>
    288c:      	movq	(%rip), %rdi            # 0x2893 <event_execve+0x2893>
    2893:      	leaq	0x70(%rsp), %rsi
    2898:      	movl	$0x1, %eax
    289d:      	callq	*%rax
    289f:      	testq	%rax, %rax
    28a2:      	je	0x28b5 <event_execve+0x28b5>
    28a4:      	movl	0x10(%rax), %ebp
    28a7:      	cmpq	$0x63677270, 0x20(%rax) # imm = 0x63677270
    28af:      	sete	%r14b
    28b3:      	jmp	0x28b8 <event_execve+0x28b8>
    28b5:      	xorl	%r14d, %r14d
    28b8:      	movq	0x10(%rsp), %r12
    28bd:      	movq	$0x0, 0x18(%rsp)
    28c6:      	movq	0xa0(%rsp), %rdx
    28ce:      	addq	$0xf90, %rdx            # imm = 0xF90
    28d5:      	movq	%rsp, %rdi
    28d8:      	movl	$0x8, %ecx
    28dd:      	movl	$0x71, %eax
    28e2:      	movl	$0x8, %esi
    28e7:      	callq	*%rax
    28e9:      	movq	(%rsp), %rcx
    28ed:      	testq	%rcx, %rcx
    28f0:      	je	0x2ae0 <event_execve+0x2ae0>
    28f6:      	testb	%r14b, %r14b
    28f9:      	je	0x2976 <event_execve+0x2976>
    28fb:      	addq	$0x88, %rcx
    2902:      	leaq	0x18(%rsp), %rdi
    2907:      	movl	$0x8, %edx
    290c:      	movl	$0x71, %eax
    2911:      	movl	$0x88, %edx
    2916:      	addq	(%rsp), %rdx
    291a:      	movl	$0x8, %esi
    291f:      	callq	*%rax
    2921:      	movq	0x18(%rsp), %r15
    2926:      	testq	%r15, %r15
    2929:      	movq	0x20(%rsp), %r14
    292e:      	je	0x2b01 <event_execve+0x2b01>
    2934:      	movl	$0x50, %eax
    2939:      	callq	*%rax
    293b:      	xorl	%ebp, %ebp
    293d:      	movq	%rax, (%rbx)
    2940:      	testq	%rax, %rax
    2943:      	je	0x2a49 <event_execve+0x2a49>
    2949:      	movq	%rax, 0x28(%rsp)
    294e:      	movq	(%rip), %rdi            # 0x2955 <event_execve+0x2955>
    2955:      	leaq	0x28(%rsp), %rsi
    295a:      	movl	$0x1, %eax
    295f:      	callq	*%rax
    2961:      	testq	%rax, %rax
    2964:      	je	0x2a51 <event_execve+0x2a51>
    296a:      	movq	(%rax), %rax
    296d:      	movq	%rax, 0x18(%r14)
    2971:      	jmp	0x2a57 <event_execve+0x2a57>
    2976:      	cmpl	$0xb, %ebp
    2979:      	ja	0x2ae0 <event_execve+0x2ae0>
    297f:      	movl	%ebp, %edx
    2981:      	leaq	(%rcx,%rdx,8), %rcx
    2985:      	leaq	0x28(%rsp), %rdi
    298a:      	movl	$0x8, %esi
    298f:      	movl	$0x71, %eax
    2994:      	shlq	$0x3, %rdx
    2998:      	addq	(%rsp), %rdx
    299c:      	movl	$0x8, %esi
    29a1:      	callq	*%rax
    29a3:      	movq	0x28(%rsp), %rcx
    29a8:      	testq	%rcx, %rcx
    29ab:      	je	0x2ae9 <event_execve+0x2ae9>
    29b1:      	leaq	0x18(%rsp), %rdi
    29b6:      	movl	$0x8, %edx
    29bb:      	movl	$0x71, %eax
    29c0:      	movq	0x28(%rsp), %rdx
    29c5:      	movl	$0x8, %esi
    29ca:      	callq	*%rax
    29cc:      	movq	0x18(%rsp), %r15
    29d1:      	testq	%r15, %r15
    29d4:      	movq	0x20(%rsp), %r14
    29d9:      	je	0x2b01 <event_execve+0x2b01>
    29df:      	xorl	%ebp, %ebp
    29e1:      	movq	$0x0, 0x28(%rsp)
    29ea:      	leaq	0x100(%r15), %rdx
    29f1:      	leaq	0x28(%rsp), %rdi
    29f6:      	movl	$0x8, %ecx
    29fb:      	movl	$0x71, %eax
    2a00:      	movl	$0x8, %esi
    2a05:      	callq	*%rax
    2a07:      	movq	0x28(%rsp), %rdx
    2a0c:      	movq	$0x0, 0x28(%rsp)
    2a15:      	testq	%rdx, %rdx
    2a18:      	je	0x2acd <event_execve+0x2acd>
    2a1e:      	addq	$0x60, %rdx
    2a22:      	leaq	0x28(%rsp), %rdi
    2a27:      	movl	$0x8, %ecx
    2a2c:      	movl	$0x71, %eax
    2a31:      	movl	$0x8, %esi
    2a36:      	callq	*%rax
    2a38:      	movq	0x28(%rsp), %rax
    2a3d:      	movq	%rax, (%rbx)
    2a40:      	testq	%rax, %rax
    2a43:      	jne	0x2949 <event_execve+0x2949>
    2a49:      	orl	$0x200000, %ebp         # imm = 0x200000
    2a4f:      	jmp	0x2a57 <event_execve+0x2a57>
    2a51:      	xorl	%eax, %eax
    2a53:      	movq	%rax, 0x18(%r14)
    2a57:      	addq	$0x100, %r15            # imm = 0x100
    2a5e:      	movq	%rsp, %rdi
    2a61:      	movl	$0x8, %ecx
    2a66:      	movl	$0x4, %eax
    2a6b:      	movl	$0x8, %esi
    2a70:      	movq	%r15, %rdx
    2a73:      	callq	*%rax
    2a75:      	movq	(%rsp), %rcx
    2a79:      	addq	$0x10, %rcx
    2a7d:      	leaq	0x28(%rsp), %rdi
    2a82:      	movl	$0x8, %edx
    2a87:      	movl	$0x4, %eax
    2a8c:      	movq	(%rsp), %rdx
    2a90:      	addq	$0x10, %rdx
    2a94:      	movl	$0x8, %esi
    2a99:      	callq	*%rax
    2a9b:      	movl	$0x10000, %ecx          # imm = 0x10000
    2aa0:      	testq	%rax, %rax
    2aa3:      	jne	0x2ac9 <event_execve+0x2ac9>
    2aa5:      	movq	0x28(%rsp), %rdx
    2aaa:      	testq	%rdx, %rdx
    2aad:      	je	0x2ac9 <event_execve+0x2ac9>
    2aaf:      	movq	%r14, %rdi
    2ab2:      	addq	$0x20, %rdi
    2ab6:      	movl	$0x80, %ecx
    2abb:      	movl	$0x2d, %eax
    2ac0:      	movl	$0x80, %esi
    2ac5:      	callq	*%rax
    2ac7:      	xorl	%ecx, %ecx
    2ac9:      	orl	%ebp, %ecx
    2acb:      	jmp	0x2b03 <event_execve+0x2b03>
    2acd:      	xorl	%eax, %eax
    2acf:      	movq	%rax, (%rbx)
    2ad2:      	testq	%rax, %rax
    2ad5:      	jne	0x2949 <event_execve+0x2949>
    2adb:      	jmp	0x2a49 <event_execve+0x2a49>
    2ae0:      	xorl	%ecx, %ecx
    2ae2:      	movq	0x20(%rsp), %r14
    2ae7:      	jmp	0x2b03 <event_execve+0x2b03>
    2ae9:      	movq	0x18(%rsp), %r15
    2aee:      	movl	$0x80000, %ebp          # imm = 0x80000
    2af3:      	testq	%r15, %r15
    2af6:      	movq	0x20(%rsp), %r14
    2afb:      	jne	0x29e1 <event_execve+0x29e1>
    2b01:      	xorl	%ecx, %ecx
    2b03:      	orl	%ecx, 0x15c(%r14)
    2b0a:      	movq	$0x0, 0x130(%r14)
    2b15:      	movq	$0x0, 0x138(%r14)
    2b20:      	movq	(%rip), %rsi            # 0x2b27 <event_execve+0x2b27>
    2b27:      	xorl	%ecx, %ecx
    2b29:      	movl	$0xc, %eax
    2b2e:      	movq	%r12, %rdi
    2b31:      	xorl	%edx, %edx
    2b33:      	callq	*%rax
    2b35:      	xorl	%eax, %eax
    2b37:      	addq	$0xd8, %rsp
    2b3e:      	popq	%rbx
    2b3f:      	popq	%r12
    2b41:      	popq	%r13
    2b43:      	popq	%r14
    2b45:      	popq	%r15
    2b47:      	popq	%rbp
    2b48:      	retq
    2b49:      	xorl	%r13d, %r13d
    2b4c:      	movq	0x10(%rsp), %r12
    2b51:      	movq	0x20(%rsp), %r14
    2b56:      	jmp	0x17f9 <event_execve+0x17f9>
