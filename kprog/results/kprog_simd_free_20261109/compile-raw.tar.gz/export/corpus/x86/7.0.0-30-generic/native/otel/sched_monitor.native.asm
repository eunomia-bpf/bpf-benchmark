
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/otel/sched_monitor.native.o:	file format elf64-x86-64

Disassembly of section tracepoint/sched/sched_process_free/v2:

0000000000000000 <tracepoint__sched_process_free>:
       0:      	pushq	%r14
       2:      	pushq	%rbx
       3:      	subq	$0x58, %rsp
       7:      	movq	%rdi, %rbx
       a:      	movl	0xc(%rdi), %eax
       d:      	movl	%eax, 0xc(%rsp)
      11:      	movq	(%rip), %rdi            # 0x18 <tracepoint__sched_process_free+0x18>
      18:      	leaq	0xc(%rsp), %rsi
      1d:      	movl	$0x1, %eax
      22:      	callq	*%rax
      24:      	testq	%rax, %rax
      27:      	jne	0x60 <tracepoint__sched_process_free+0x60>
      29:      	movl	0xc(%rsp), %eax
      2d:      	movl	$0x60, 0x10(%rsp)
      35:      	movbel	%eax, 0x14(%rsp)
      3b:      	movq	$0x0, 0x18(%rsp)
      44:      	movq	(%rip), %rdi            # 0x4b <tracepoint__sched_process_free+0x4b>
      4b:      	leaq	0x10(%rsp), %rsi
      50:      	movl	$0x1, %eax
      55:      	callq	*%rax
      57:      	testq	%rax, %rax
      5a:      	je	0x2bc <tracepoint__sched_process_free+0x2bc>
      60:      	movl	0xc(%rsp), %r14d
      65:      	movq	%r14, %rax
      68:      	shlq	$0x20, %rax
      6c:      	orq	%r14, %rax
      6f:      	movq	%rax, 0x48(%rsp)
      74:      	movl	%r14d, 0x50(%rsp)
      79:      	movl	%r14d, 0x10(%rsp)
      7e:      	movq	(%rip), %rdi            # 0x85 <tracepoint__sched_process_free+0x85>
      85:      	leaq	0x10(%rsp), %rsi
      8a:      	movl	$0x1, %eax
      8f:      	callq	*%rax
      91:      	movl	$0x5, %eax
      96:      	callq	*%rax
      98:      	movb	$0x1, 0xa(%rsp)
      9d:      	movq	(%rip), %rdi            # 0xa4 <tracepoint__sched_process_free+0xa4>
      a4:      	xorl	%eax, %eax
      a6:      	leaq	0x48(%rsp), %rsi
      ab:      	leaq	0xa(%rsp), %rdx
      b0:      	movl	$0x2, %r8d
      b6:      	xorl	%ecx, %ecx
      b8:      	callq	*%r8
      bb:      	testl	%eax, %eax
      bd:      	je	0x172 <tracepoint__sched_process_free+0x172>
      c3:      	movq	(%rip), %rbx            # 0xca <tracepoint__sched_process_free+0xca>
      ca:      	cmpl	$0x0, (%rbx)
      cd:      	jne	0x34d <tracepoint__sched_process_free+0x34d>
      d3:      	movl	$0x3e, 0x4(%rsp)
      db:      	movq	(%rip), %rdi            # 0xe2 <tracepoint__sched_process_free+0xe2>
      e2:      	leaq	0x4(%rsp), %rsi
      e7:      	movl	$0x1, %eax
      ec:      	callq	*%rax
      ee:      	testq	%rax, %rax
      f1:      	jne	0x2b9 <tracepoint__sched_process_free+0x2b9>
      f7:      	cmpl	$0x0, (%rbx)
      fa:      	je	0x2bc <tracepoint__sched_process_free+0x2bc>
     100:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     10a:      	movq	%rax, 0x36(%rsp)
     10f:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     119:      	movq	%rax, 0x30(%rsp)
     11e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     128:      	movq	%rax, 0x28(%rsp)
     12d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     137:      	movq	%rax, 0x20(%rsp)
     13c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     146:      	movq	%rax, 0x18(%rsp)
     14b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     155:      	movq	%rax, 0x10(%rsp)
     15a:      	leaq	0x10(%rsp), %rdi
     15f:      	movl	$0x2e, %eax
     164:      	movl	$0x6, %ecx
     169:      	movl	0x4(%rsp), %edx
     16d:      	jmp	0x33f <tracepoint__sched_process_free+0x33f>
     172:      	movq	(%rip), %rdi            # 0x179 <tracepoint__sched_process_free+0x179>
     179:      	leaq	0x50(%rsp), %rsi
     17e:      	movl	$0x3, %eax
     183:      	callq	*%rax
     185:      	movl	$0x1, 0x54(%rsp)
     18d:      	movb	$0x1, 0xb(%rsp)
     192:      	movq	(%rip), %rdi            # 0x199 <tracepoint__sched_process_free+0x199>
     199:      	leaq	0x54(%rsp), %rsi
     19e:      	leaq	0xb(%rsp), %rdx
     1a3:      	movl	$0x1, %eax
     1a8:      	movl	$0x2, %r8d
     1ae:      	movl	$0x1, %ecx
     1b3:      	callq	*%r8
     1b6:      	testl	%eax, %eax
     1b8:      	js	0x1df <tracepoint__sched_process_free+0x1df>
     1ba:      	movl	$0x42, 0x4(%rsp)
     1c2:      	movq	(%rip), %rdi            # 0x1c9 <tracepoint__sched_process_free+0x1c9>
     1c9:      	leaq	0x4(%rsp), %rsi
     1ce:      	movl	$0x1, %eax
     1d3:      	callq	*%rax
     1d5:      	testq	%rax, %rax
     1d8:      	je	0x240 <tracepoint__sched_process_free+0x240>
     1da:      	incq	(%rax)
     1dd:      	jmp	0x250 <tracepoint__sched_process_free+0x250>
     1df:      	movq	(%rip), %rax            # 0x1e6 <tracepoint__sched_process_free+0x1e6>
     1e6:      	cmpl	$0x0, (%rax)
     1e9:      	je	0x299 <tracepoint__sched_process_free+0x299>
     1ef:      	movabsq	$0xa64657469626968, %rax # imm = 0xA64657469626968
     1f9:      	movq	%rax, 0x20(%rsp)
     1fe:      	movabsq	$0x6e69206425206570, %rax # imm = 0x6E69206425206570
     208:      	movq	%rax, 0x18(%rsp)
     20d:      	movabsq	$0x797420746e657645, %rax # imm = 0x797420746E657645
     217:      	movq	%rax, 0x10(%rsp)
     21c:      	movb	$0x0, 0x28(%rsp)
     221:      	leaq	0x10(%rsp), %rdi
     226:      	movl	$0x19, %eax
     22b:      	movl	$0x6, %ecx
     230:      	movl	$0x19, %esi
     235:      	movl	$0x1, %edx
     23a:      	xorl	%eax, %eax
     23c:      	callq	*%rcx
     23e:      	jmp	0x299 <tracepoint__sched_process_free+0x299>
     240:      	movq	(%rip), %rax            # 0x247 <tracepoint__sched_process_free+0x247>
     247:      	cmpl	$0x0, (%rax)
     24a:      	jne	0x46e <tracepoint__sched_process_free+0x46e>
     250:      	movl	$0x1, 0x4(%rsp)
     258:      	movq	(%rip), %rsi            # 0x25f <tracepoint__sched_process_free+0x25f>
     25f:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     264:      	leaq	0x4(%rsp), %rcx
     269:      	movl	$0x4, %edx
     26e:      	movl	$0x19, %r9d
     274:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     279:      	movq	%rbx, %rdi
     27c:      	movl	$0x4, %r8d
     282:      	callq	*%r9
     285:      	testl	%eax, %eax
     287:      	jns	0x299 <tracepoint__sched_process_free+0x299>
     289:      	movq	(%rip), %rcx            # 0x290 <tracepoint__sched_process_free+0x290>
     290:      	cmpl	$0x0, (%rcx)
     293:      	jne	0x3df <tracepoint__sched_process_free+0x3df>
     299:      	movl	$0x40, 0x48(%rsp)
     2a1:      	movq	(%rip), %rdi            # 0x2a8 <tracepoint__sched_process_free+0x2a8>
     2a8:      	leaq	0x48(%rsp), %rsi
     2ad:      	movl	$0x1, %eax
     2b2:      	callq	*%rax
     2b4:      	testq	%rax, %rax
     2b7:      	je	0x2c6 <tracepoint__sched_process_free+0x2c6>
     2b9:      	incq	(%rax)
     2bc:      	xorl	%eax, %eax
     2be:      	addq	$0x58, %rsp
     2c2:      	popq	%rbx
     2c3:      	popq	%r14
     2c5:      	retq
     2c6:      	movq	(%rip), %rax            # 0x2cd <tracepoint__sched_process_free+0x2cd>
     2cd:      	cmpl	$0x0, (%rax)
     2d0:      	je	0x2bc <tracepoint__sched_process_free+0x2bc>
     2d2:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     2dc:      	movq	%rax, 0x36(%rsp)
     2e1:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     2eb:      	movq	%rax, 0x30(%rsp)
     2f0:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     2fa:      	movq	%rax, 0x28(%rsp)
     2ff:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     309:      	movq	%rax, 0x20(%rsp)
     30e:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     318:      	movq	%rax, 0x18(%rsp)
     31d:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     327:      	movq	%rax, 0x10(%rsp)
     32c:      	leaq	0x10(%rsp), %rdi
     331:      	movl	$0x2e, %eax
     336:      	movl	$0x6, %ecx
     33b:      	movl	0x48(%rsp), %edx
     33f:      	movl	$0x2e, %esi
     344:      	xorl	%eax, %eax
     346:      	callq	*%rcx
     348:      	jmp	0x2bc <tracepoint__sched_process_free+0x2bc>
     34d:      	movl	0x48(%rsp), %ecx
     351:      	movabsq	$0xa6425203a6425, %rdx  # imm = 0xA6425203A6425
     35b:      	movq	%rdx, 0x3d(%rsp)
     360:      	movabsq	$0x3a6425203a444954, %rdx # imm = 0x3A6425203A444954
     36a:      	movq	%rdx, 0x38(%rsp)
     36f:      	movabsq	$0x2064252044495020, %rdx # imm = 0x2064252044495020
     379:      	movq	%rdx, 0x30(%rsp)
     37e:      	movabsq	$0x687469772073746e, %rdx # imm = 0x687469772073746E
     388:      	movq	%rdx, 0x28(%rsp)
     38d:      	movabsq	$0x6576655f64697020, %rdx # imm = 0x6576655F64697020
     397:      	movq	%rdx, 0x20(%rsp)
     39c:      	movabsq	$0x657461647075206f, %rdx # imm = 0x657461647075206F
     3a6:      	movq	%rdx, 0x18(%rsp)
     3ab:      	movabsq	$0x742064656c696146, %rdx # imm = 0x742064656C696146
     3b5:      	movq	%rdx, 0x10(%rsp)
     3ba:      	leaq	0x10(%rsp), %rdi
     3bf:      	movl	$0x35, %edx
     3c4:      	movl	$0x6, %r9d
     3ca:      	movl	$0x35, %esi
     3cf:      	movl	%r14d, %edx
     3d2:      	movl	%eax, %r8d
     3d5:      	xorl	%eax, %eax
     3d7:      	callq	*%r9
     3da:      	jmp	0xd3 <tracepoint__sched_process_free+0xd3>
     3df:      	movabsq	$0xa642520726f72, %rcx  # imm = 0xA642520726F72
     3e9:      	movq	%rcx, 0x3e(%rsp)
     3ee:      	movabsq	$0x6f727265203a6425, %rcx # imm = 0x6F727265203A6425
     3f8:      	movq	%rcx, 0x38(%rsp)
     3fd:      	movabsq	$0x20746e6576652064, %rcx # imm = 0x20746E6576652064
     407:      	movq	%rcx, 0x30(%rsp)
     40c:      	movabsq	$0x6e6573206f742064, %rcx # imm = 0x6E6573206F742064
     416:      	movq	%rcx, 0x28(%rsp)
     41b:      	movabsq	$0x656c696166207265, %rcx # imm = 0x656C696166207265
     425:      	movq	%rcx, 0x20(%rsp)
     42a:      	movabsq	$0x67676972745f646e, %rcx # imm = 0x67676972745F646E
     434:      	movq	%rcx, 0x18(%rsp)
     439:      	movabsq	$0x65735f746e657665, %rcx # imm = 0x65735F746E657665
     443:      	movq	%rcx, 0x10(%rsp)
     448:      	leaq	0x10(%rsp), %rdi
     44d:      	movl	$0x36, %ecx
     452:      	movl	$0x6, %r8d
     458:      	movl	$0x36, %esi
     45d:      	movl	$0x1, %edx
     462:      	movl	%eax, %ecx
     464:      	xorl	%eax, %eax
     466:      	callq	*%r8
     469:      	jmp	0x299 <tracepoint__sched_process_free+0x299>
     46e:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     478:      	movq	%rax, 0x36(%rsp)
     47d:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     487:      	movq	%rax, 0x30(%rsp)
     48c:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     496:      	movq	%rax, 0x28(%rsp)
     49b:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     4a5:      	movq	%rax, 0x20(%rsp)
     4aa:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     4b4:      	movq	%rax, 0x18(%rsp)
     4b9:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     4c3:      	movq	%rax, 0x10(%rsp)
     4c8:      	leaq	0x10(%rsp), %rdi
     4cd:      	movl	$0x2e, %eax
     4d2:      	movl	$0x6, %ecx
     4d7:      	movl	0x4(%rsp), %edx
     4db:      	movl	$0x2e, %esi
     4e0:      	xorl	%eax, %eax
     4e2:      	callq	*%rcx
     4e4:      	jmp	0x250 <tracepoint__sched_process_free+0x250>

Disassembly of section tracepoint/sched/sched_process_free/v1:

0000000000000000 <tracepoint__sched_process_free_pre616>:
       0:      	pushq	%r14
       2:      	pushq	%rbx
       3:      	subq	$0x58, %rsp
       7:      	movq	%rdi, %rbx
       a:      	movl	0x18(%rdi), %eax
       d:      	movl	%eax, 0xc(%rsp)
      11:      	movq	(%rip), %rdi            # 0x18 <tracepoint__sched_process_free_pre616+0x18>
      18:      	leaq	0xc(%rsp), %rsi
      1d:      	movl	$0x1, %eax
      22:      	callq	*%rax
      24:      	testq	%rax, %rax
      27:      	jne	0x60 <tracepoint__sched_process_free_pre616+0x60>
      29:      	movl	0xc(%rsp), %eax
      2d:      	movl	$0x60, 0x10(%rsp)
      35:      	movbel	%eax, 0x14(%rsp)
      3b:      	movq	$0x0, 0x18(%rsp)
      44:      	movq	(%rip), %rdi            # 0x4b <tracepoint__sched_process_free_pre616+0x4b>
      4b:      	leaq	0x10(%rsp), %rsi
      50:      	movl	$0x1, %eax
      55:      	callq	*%rax
      57:      	testq	%rax, %rax
      5a:      	je	0x2bc <tracepoint__sched_process_free_pre616+0x2bc>
      60:      	movl	0xc(%rsp), %r14d
      65:      	movq	%r14, %rax
      68:      	shlq	$0x20, %rax
      6c:      	orq	%r14, %rax
      6f:      	movq	%rax, 0x48(%rsp)
      74:      	movl	%r14d, 0x50(%rsp)
      79:      	movl	%r14d, 0x10(%rsp)
      7e:      	movq	(%rip), %rdi            # 0x85 <tracepoint__sched_process_free_pre616+0x85>
      85:      	leaq	0x10(%rsp), %rsi
      8a:      	movl	$0x1, %eax
      8f:      	callq	*%rax
      91:      	movl	$0x5, %eax
      96:      	callq	*%rax
      98:      	movb	$0x1, 0xa(%rsp)
      9d:      	movq	(%rip), %rdi            # 0xa4 <tracepoint__sched_process_free_pre616+0xa4>
      a4:      	xorl	%eax, %eax
      a6:      	leaq	0x48(%rsp), %rsi
      ab:      	leaq	0xa(%rsp), %rdx
      b0:      	movl	$0x2, %r8d
      b6:      	xorl	%ecx, %ecx
      b8:      	callq	*%r8
      bb:      	testl	%eax, %eax
      bd:      	je	0x172 <tracepoint__sched_process_free_pre616+0x172>
      c3:      	movq	(%rip), %rbx            # 0xca <tracepoint__sched_process_free_pre616+0xca>
      ca:      	cmpl	$0x0, (%rbx)
      cd:      	jne	0x34d <tracepoint__sched_process_free_pre616+0x34d>
      d3:      	movl	$0x3e, 0x4(%rsp)
      db:      	movq	(%rip), %rdi            # 0xe2 <tracepoint__sched_process_free_pre616+0xe2>
      e2:      	leaq	0x4(%rsp), %rsi
      e7:      	movl	$0x1, %eax
      ec:      	callq	*%rax
      ee:      	testq	%rax, %rax
      f1:      	jne	0x2b9 <tracepoint__sched_process_free_pre616+0x2b9>
      f7:      	cmpl	$0x0, (%rbx)
      fa:      	je	0x2bc <tracepoint__sched_process_free_pre616+0x2bc>
     100:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     10a:      	movq	%rax, 0x36(%rsp)
     10f:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     119:      	movq	%rax, 0x30(%rsp)
     11e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     128:      	movq	%rax, 0x28(%rsp)
     12d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     137:      	movq	%rax, 0x20(%rsp)
     13c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     146:      	movq	%rax, 0x18(%rsp)
     14b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     155:      	movq	%rax, 0x10(%rsp)
     15a:      	leaq	0x10(%rsp), %rdi
     15f:      	movl	$0x2e, %eax
     164:      	movl	$0x6, %ecx
     169:      	movl	0x4(%rsp), %edx
     16d:      	jmp	0x33f <tracepoint__sched_process_free_pre616+0x33f>
     172:      	movq	(%rip), %rdi            # 0x179 <tracepoint__sched_process_free_pre616+0x179>
     179:      	leaq	0x50(%rsp), %rsi
     17e:      	movl	$0x3, %eax
     183:      	callq	*%rax
     185:      	movl	$0x1, 0x54(%rsp)
     18d:      	movb	$0x1, 0xb(%rsp)
     192:      	movq	(%rip), %rdi            # 0x199 <tracepoint__sched_process_free_pre616+0x199>
     199:      	leaq	0x54(%rsp), %rsi
     19e:      	leaq	0xb(%rsp), %rdx
     1a3:      	movl	$0x1, %eax
     1a8:      	movl	$0x2, %r8d
     1ae:      	movl	$0x1, %ecx
     1b3:      	callq	*%r8
     1b6:      	testl	%eax, %eax
     1b8:      	js	0x1df <tracepoint__sched_process_free_pre616+0x1df>
     1ba:      	movl	$0x42, 0x4(%rsp)
     1c2:      	movq	(%rip), %rdi            # 0x1c9 <tracepoint__sched_process_free_pre616+0x1c9>
     1c9:      	leaq	0x4(%rsp), %rsi
     1ce:      	movl	$0x1, %eax
     1d3:      	callq	*%rax
     1d5:      	testq	%rax, %rax
     1d8:      	je	0x240 <tracepoint__sched_process_free_pre616+0x240>
     1da:      	incq	(%rax)
     1dd:      	jmp	0x250 <tracepoint__sched_process_free_pre616+0x250>
     1df:      	movq	(%rip), %rax            # 0x1e6 <tracepoint__sched_process_free_pre616+0x1e6>
     1e6:      	cmpl	$0x0, (%rax)
     1e9:      	je	0x299 <tracepoint__sched_process_free_pre616+0x299>
     1ef:      	movabsq	$0xa64657469626968, %rax # imm = 0xA64657469626968
     1f9:      	movq	%rax, 0x20(%rsp)
     1fe:      	movabsq	$0x6e69206425206570, %rax # imm = 0x6E69206425206570
     208:      	movq	%rax, 0x18(%rsp)
     20d:      	movabsq	$0x797420746e657645, %rax # imm = 0x797420746E657645
     217:      	movq	%rax, 0x10(%rsp)
     21c:      	movb	$0x0, 0x28(%rsp)
     221:      	leaq	0x10(%rsp), %rdi
     226:      	movl	$0x19, %eax
     22b:      	movl	$0x6, %ecx
     230:      	movl	$0x19, %esi
     235:      	movl	$0x1, %edx
     23a:      	xorl	%eax, %eax
     23c:      	callq	*%rcx
     23e:      	jmp	0x299 <tracepoint__sched_process_free_pre616+0x299>
     240:      	movq	(%rip), %rax            # 0x247 <tracepoint__sched_process_free_pre616+0x247>
     247:      	cmpl	$0x0, (%rax)
     24a:      	jne	0x46e <tracepoint__sched_process_free_pre616+0x46e>
     250:      	movl	$0x1, 0x4(%rsp)
     258:      	movq	(%rip), %rsi            # 0x25f <tracepoint__sched_process_free_pre616+0x25f>
     25f:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     264:      	leaq	0x4(%rsp), %rcx
     269:      	movl	$0x4, %edx
     26e:      	movl	$0x19, %r9d
     274:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     279:      	movq	%rbx, %rdi
     27c:      	movl	$0x4, %r8d
     282:      	callq	*%r9
     285:      	testl	%eax, %eax
     287:      	jns	0x299 <tracepoint__sched_process_free_pre616+0x299>
     289:      	movq	(%rip), %rcx            # 0x290 <tracepoint__sched_process_free_pre616+0x290>
     290:      	cmpl	$0x0, (%rcx)
     293:      	jne	0x3df <tracepoint__sched_process_free_pre616+0x3df>
     299:      	movl	$0x40, 0x48(%rsp)
     2a1:      	movq	(%rip), %rdi            # 0x2a8 <tracepoint__sched_process_free_pre616+0x2a8>
     2a8:      	leaq	0x48(%rsp), %rsi
     2ad:      	movl	$0x1, %eax
     2b2:      	callq	*%rax
     2b4:      	testq	%rax, %rax
     2b7:      	je	0x2c6 <tracepoint__sched_process_free_pre616+0x2c6>
     2b9:      	incq	(%rax)
     2bc:      	xorl	%eax, %eax
     2be:      	addq	$0x58, %rsp
     2c2:      	popq	%rbx
     2c3:      	popq	%r14
     2c5:      	retq
     2c6:      	movq	(%rip), %rax            # 0x2cd <tracepoint__sched_process_free_pre616+0x2cd>
     2cd:      	cmpl	$0x0, (%rax)
     2d0:      	je	0x2bc <tracepoint__sched_process_free_pre616+0x2bc>
     2d2:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     2dc:      	movq	%rax, 0x36(%rsp)
     2e1:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     2eb:      	movq	%rax, 0x30(%rsp)
     2f0:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     2fa:      	movq	%rax, 0x28(%rsp)
     2ff:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     309:      	movq	%rax, 0x20(%rsp)
     30e:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     318:      	movq	%rax, 0x18(%rsp)
     31d:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     327:      	movq	%rax, 0x10(%rsp)
     32c:      	leaq	0x10(%rsp), %rdi
     331:      	movl	$0x2e, %eax
     336:      	movl	$0x6, %ecx
     33b:      	movl	0x48(%rsp), %edx
     33f:      	movl	$0x2e, %esi
     344:      	xorl	%eax, %eax
     346:      	callq	*%rcx
     348:      	jmp	0x2bc <tracepoint__sched_process_free_pre616+0x2bc>
     34d:      	movl	0x48(%rsp), %ecx
     351:      	movabsq	$0xa6425203a6425, %rdx  # imm = 0xA6425203A6425
     35b:      	movq	%rdx, 0x3d(%rsp)
     360:      	movabsq	$0x3a6425203a444954, %rdx # imm = 0x3A6425203A444954
     36a:      	movq	%rdx, 0x38(%rsp)
     36f:      	movabsq	$0x2064252044495020, %rdx # imm = 0x2064252044495020
     379:      	movq	%rdx, 0x30(%rsp)
     37e:      	movabsq	$0x687469772073746e, %rdx # imm = 0x687469772073746E
     388:      	movq	%rdx, 0x28(%rsp)
     38d:      	movabsq	$0x6576655f64697020, %rdx # imm = 0x6576655F64697020
     397:      	movq	%rdx, 0x20(%rsp)
     39c:      	movabsq	$0x657461647075206f, %rdx # imm = 0x657461647075206F
     3a6:      	movq	%rdx, 0x18(%rsp)
     3ab:      	movabsq	$0x742064656c696146, %rdx # imm = 0x742064656C696146
     3b5:      	movq	%rdx, 0x10(%rsp)
     3ba:      	leaq	0x10(%rsp), %rdi
     3bf:      	movl	$0x35, %edx
     3c4:      	movl	$0x6, %r9d
     3ca:      	movl	$0x35, %esi
     3cf:      	movl	%r14d, %edx
     3d2:      	movl	%eax, %r8d
     3d5:      	xorl	%eax, %eax
     3d7:      	callq	*%r9
     3da:      	jmp	0xd3 <tracepoint__sched_process_free_pre616+0xd3>
     3df:      	movabsq	$0xa642520726f72, %rcx  # imm = 0xA642520726F72
     3e9:      	movq	%rcx, 0x3e(%rsp)
     3ee:      	movabsq	$0x6f727265203a6425, %rcx # imm = 0x6F727265203A6425
     3f8:      	movq	%rcx, 0x38(%rsp)
     3fd:      	movabsq	$0x20746e6576652064, %rcx # imm = 0x20746E6576652064
     407:      	movq	%rcx, 0x30(%rsp)
     40c:      	movabsq	$0x6e6573206f742064, %rcx # imm = 0x6E6573206F742064
     416:      	movq	%rcx, 0x28(%rsp)
     41b:      	movabsq	$0x656c696166207265, %rcx # imm = 0x656C696166207265
     425:      	movq	%rcx, 0x20(%rsp)
     42a:      	movabsq	$0x67676972745f646e, %rcx # imm = 0x67676972745F646E
     434:      	movq	%rcx, 0x18(%rsp)
     439:      	movabsq	$0x65735f746e657665, %rcx # imm = 0x65735F746E657665
     443:      	movq	%rcx, 0x10(%rsp)
     448:      	leaq	0x10(%rsp), %rdi
     44d:      	movl	$0x36, %ecx
     452:      	movl	$0x6, %r8d
     458:      	movl	$0x36, %esi
     45d:      	movl	$0x1, %edx
     462:      	movl	%eax, %ecx
     464:      	xorl	%eax, %eax
     466:      	callq	*%r8
     469:      	jmp	0x299 <tracepoint__sched_process_free_pre616+0x299>
     46e:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     478:      	movq	%rax, 0x36(%rsp)
     47d:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     487:      	movq	%rax, 0x30(%rsp)
     48c:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     496:      	movq	%rax, 0x28(%rsp)
     49b:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     4a5:      	movq	%rax, 0x20(%rsp)
     4aa:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     4b4:      	movq	%rax, 0x18(%rsp)
     4b9:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     4c3:      	movq	%rax, 0x10(%rsp)
     4c8:      	leaq	0x10(%rsp), %rdi
     4cd:      	movl	$0x2e, %eax
     4d2:      	movl	$0x6, %ecx
     4d7:      	movl	0x4(%rsp), %edx
     4db:      	movl	$0x2e, %esi
     4e0:      	xorl	%eax, %eax
     4e2:      	callq	*%rcx
     4e4:      	jmp	0x250 <tracepoint__sched_process_free_pre616+0x250>
