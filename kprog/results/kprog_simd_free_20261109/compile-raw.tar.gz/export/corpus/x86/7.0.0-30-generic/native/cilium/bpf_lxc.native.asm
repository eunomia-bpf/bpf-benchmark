
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/cilium/bpf_lxc.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <__check_cluster_id_bits>:
       0:      	movq	(%rip), %rax            # 0x7 <__check_cluster_id_bits+0x7>
       7:      	movl	(%rax), %eax
       9:      	retq
       a:      	nopw	(%rax,%rax)

0000000000000010 <__check_device_mtu>:
      10:      	movq	(%rip), %rax            # 0x17 <__check_device_mtu+0x7>
      17:      	movzwl	(%rax), %eax
      1a:      	retq

Disassembly of section tc/tail:

0000000000000000 <tail_drop_notify>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x58, %rsp
       e:      	movq	%rdi, %rbx
      11:      	movl	0x38(%rdi), %r12d
      15:      	movq	(%rip), %rax            # 0x1c <tail_drop_notify+0x1c>
      1c:      	cmpb	$0x0, (%rax)
      1f:      	je	0x46 <tail_drop_notify+0x46>
      21:      	movl	$0x0, 0x10(%rsp)
      29:      	movl	$0x1, %eax
      2e:      	movq	(%rip), %rdi            # 0x35 <tail_drop_notify+0x35>
      35:      	leaq	0x10(%rsp), %rsi
      3a:      	callq	*%rax
      3c:      	testq	%rax, %rax
      3f:      	je	0x46 <tail_drop_notify+0x46>
      41:      	movq	(%rax), %rax
      44:      	jmp	0x48 <tail_drop_notify+0x48>
      46:      	xorl	%eax, %eax
      48:      	movq	%rax, 0x8(%rsp)
      4d:      	movl	0x40(%rbx), %ebp
      50:      	movl	0x70(%rbx), %r13d
      54:      	movq	$0x2, 0x40(%rsp)
      5d:      	movq	(%rip), %rax            # 0x64 <tail_drop_notify+0x64>
      64:      	cmpl	$0x0, (%rax)
      67:      	movl	%r13d, %edi
      6a:      	je	0x1b4 <tail_drop_notify+0x1b4>
      70:      	movl	%r12d, (%rsp)
      74:      	movq	(%rip), %rcx            # 0x7b <tail_drop_notify+0x7b>
      7b:      	movl	(%rcx), %ecx
      7d:      	movq	%rcx, 0x48(%rsp)
      82:      	movl	(%rax), %r12d
      85:      	movl	$0x5, %ecx
      8a:      	xorl	%eax, %eax
      8c:      	callq	*%rcx
      8e:      	movq	%rax, %r15
      91:      	movl	$0x2, 0x4(%rsp)
      99:      	movl	$0x1, %eax
      9e:      	movq	(%rip), %rdi            # 0xa5 <tail_drop_notify+0xa5>
      a5:      	leaq	0x4(%rsp), %rsi
      aa:      	callq	*%rax
      ac:      	movq	%rax, %r14
      af:      	testq	%rax, %rax
      b2:      	jne	0xe2 <tail_drop_notify+0xe2>
      b4:      	movq	$0x0, 0x50(%rsp)
      bd:      	movl	$0x2, %eax
      c2:      	movq	(%rip), %rdi            # 0xc9 <tail_drop_notify+0xc9>
      c9:      	leaq	0x4(%rsp), %rsi
      ce:      	leaq	0x50(%rsp), %r14
      d3:      	movq	%r14, %rdx
      d6:      	xorl	%ecx, %ecx
      d8:      	callq	*%rax
      da:      	testl	%eax, %eax
      dc:      	js	0x2a2 <tail_drop_notify+0x2a2>
      e2:      	movl	$0x1, %eax
      e7:      	movq	(%rip), %rdi            # 0xee <tail_drop_notify+0xee>
      ee:      	leaq	0x40(%rsp), %rsi
      f3:      	callq	*%rax
      f5:      	testq	%rax, %rax
      f8:      	je	0x165 <tail_drop_notify+0x165>
      fa:      	movq	(%rax), %rcx
      fd:      	movq	%r15, %rsi
     100:      	subq	%rcx, %rsi
     103:      	cmpq	$0x3b9aca00, %rsi       # imm = 0x3B9ACA00
     10a:      	jbe	0x199 <tail_drop_notify+0x199>
     110:      	movl	$0x3b9aca00, %ecx       # imm = 0x3B9ACA00
     115:      	movq	%rax, %rdi
     118:      	movq	%rsi, %rax
     11b:      	xorl	%edx, %edx
     11d:      	divq	%rcx
     120:      	movq	%rax, %rcx
     123:      	movl	$0x3b9aca00, %r8d       # imm = 0x3B9ACA00
     129:      	movq	%rsi, %rax
     12c:      	xorl	%edx, %edx
     12e:      	divq	%r8
     131:      	movq	%rdi, %rax
     134:      	imulq	%r12, %rcx
     138:      	addq	0x8(%rdi), %rcx
     13c:      	movq	%rcx, 0x8(%rdi)
     140:      	subq	%rdx, %r15
     143:      	movq	%r15, (%rdi)
     146:      	movq	0x48(%rsp), %rdx
     14b:      	cmpq	%rdx, %rcx
     14e:      	movl	(%rsp), %r12d
     152:      	jbe	0x15b <tail_drop_notify+0x15b>
     154:      	movq	%rdx, 0x8(%rax)
     158:      	movq	%rdx, %rcx
     15b:      	testq	%rcx, %rcx
     15e:      	jne	0x1aa <tail_drop_notify+0x1aa>
     160:      	jmp	0x2b5 <tail_drop_notify+0x2b5>
     165:      	movq	%r15, 0x10(%rsp)
     16a:      	decq	%r12
     16d:      	movq	%r12, 0x18(%rsp)
     172:      	movl	$0x2, %eax
     177:      	movq	(%rip), %rdi            # 0x17e <tail_drop_notify+0x17e>
     17e:      	leaq	0x40(%rsp), %rsi
     183:      	leaq	0x10(%rsp), %rdx
     188:      	xorl	%ecx, %ecx
     18a:      	callq	*%rax
     18c:      	testl	%eax, %eax
     18e:      	movl	(%rsp), %r12d
     192:      	jns	0x1b1 <tail_drop_notify+0x1b1>
     194:      	jmp	0x2b5 <tail_drop_notify+0x2b5>
     199:      	movq	0x8(%rax), %rcx
     19d:      	movl	(%rsp), %r12d
     1a1:      	testq	%rcx, %rcx
     1a4:      	je	0x2b5 <tail_drop_notify+0x2b5>
     1aa:      	decq	%rcx
     1ad:      	movq	%rcx, 0x8(%rax)
     1b1:      	movl	0x70(%rbx), %edi
     1b4:      	movl	%ebp, %ecx
     1b6:      	shrl	$0x10, %ecx
     1b9:      	movl	%ebp, %edx
     1bb:      	shrl	$0x8, %edx
     1be:      	movzwl	0xb4(%rbx), %eax
     1c5:      	cmpl	$0xdd86, %eax           # imm = 0xDD86
     1ca:      	sete	%sil
     1ce:      	movq	(%rip), %rax            # 0x1d5 <tail_drop_notify+0x1d5>
     1d5:      	movl	(%rax), %eax
     1d7:      	cmpl	%eax, %edi
     1d9:      	cmovbl	%edi, %eax
     1dc:      	movq	(%rip), %rdi            # 0x1e3 <tail_drop_notify+0x1e3>
     1e3:      	movzwl	(%rdi), %r11d
     1e7:      	movl	0x98(%rbx), %r14d
     1ee:      	movl	0x30(%rbx), %r8d
     1f2:      	movl	0x34(%rbx), %r9d
     1f6:      	movl	0x3c(%rbx), %r10d
     1fa:      	movl	%r12d, %edi
     1fd:      	shrl	$0x8, %edi
     200:      	movq	0x10(%rbx), %r15
     204:      	testq	%r15, %r15
     207:      	je	0x212 <tail_drop_notify+0x212>
     209:      	movl	0xe0(%r15), %r15d
     210:      	jmp	0x215 <tail_drop_notify+0x215>
     212:      	xorl	%r15d, %r15d
     215:      	movb	$0x0, 0x37(%rsp)
     21a:      	movw	$0x0, 0x35(%rsp)
     221:      	movb	$0x1, 0x10(%rsp)
     226:      	movb	%r12b, 0x11(%rsp)
     22b:      	movw	%r11w, 0x12(%rsp)
     231:      	movl	%r14d, 0x14(%rsp)
     236:      	movl	%r13d, 0x18(%rsp)
     23b:      	movw	%ax, 0x1c(%rsp)
     240:      	movw	$0x3, 0x1e(%rsp)
     247:      	movl	%r8d, 0x20(%rsp)
     24c:      	movl	%r9d, 0x24(%rsp)
     251:      	movl	%r10d, 0x28(%rsp)
     256:      	movw	%cx, 0x2c(%rsp)
     25b:      	movb	%dl, 0x2e(%rsp)
     25f:      	movb	%dil, 0x2f(%rsp)
     264:      	movl	%r15d, 0x30(%rsp)
     269:      	movb	%sil, 0x34(%rsp)
     26e:      	movq	0x8(%rsp), %rcx
     273:      	movq	%rcx, 0x38(%rsp)
     278:      	movl	$0x19, %r9d
     27e:      	shlq	$0x20, %rax
     282:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     287:      	orq	%rax, %rdx
     28a:      	movq	(%rip), %rsi            # 0x291 <tail_drop_notify+0x291>
     291:      	leaq	0x10(%rsp), %rcx
     296:      	movq	%rbx, %rdi
     299:      	movl	$0x30, %r8d
     29f:      	callq	*%r9
     2a2:      	movzbl	%bpl, %eax
     2a6:      	addq	$0x58, %rsp
     2aa:      	popq	%rbx
     2ab:      	popq	%r12
     2ad:      	popq	%r13
     2af:      	popq	%r14
     2b1:      	popq	%r15
     2b3:      	popq	%rbp
     2b4:      	retq
     2b5:      	incq	(%r14)
     2b8:      	jmp	0x2a2 <tail_drop_notify+0x2a2>
     2ba:      	nopw	(%rax,%rax)

00000000000002c0 <tail_icmp6_send_time_exceeded>:
     2c0:      	pushq	%rbp
     2c1:      	pushq	%r15
     2c3:      	pushq	%r14
     2c5:      	pushq	%r13
     2c7:      	pushq	%r12
     2c9:      	pushq	%rbx
     2ca:      	subq	$0xd8, %rsp
     2d1:      	movq	%rdi, %rbx
     2d4:      	movl	0x30(%rdi), %r14d
     2d8:      	movl	0x34(%rdi), %r13d
     2dc:      	movl	$0x0, 0x30(%rdi)
     2e3:      	movq	$0x0, 0x88(%rsp)
     2ef:      	movq	$0x0, 0x80(%rsp)
     2fb:      	movq	$0x0, 0x78(%rsp)
     304:      	movq	$0x0, 0x70(%rsp)
     30d:      	movq	$0x0, 0x68(%rsp)
     316:      	movq	$0x0, 0x60(%rsp)
     31f:      	movq	$0x0, 0x58(%rsp)
     328:      	movq	$0x0, 0x50(%rsp)
     331:      	movq	$0x0, 0x48(%rsp)
     33a:      	movq	$0x0, 0x40(%rsp)
     343:      	movw	$0x0, 0xc(%rsp)
     34a:      	movb	$0x3a, 0xf(%rsp)
     34f:      	movq	(%rip), %rax            # 0x356 <tail_icmp6_send_time_exceeded+0x96>
     356:      	movq	(%rax), %rcx
     359:      	movq	%rcx, 0xa0(%rsp)
     361:      	movq	0x8(%rax), %rax
     365:      	movq	%rax, 0x98(%rsp)
     36d:      	movq	$0x3, 0x40(%rsp)
     376:      	movw	$0xe02, 0x10(%rsp)      # imm = 0xE02
     37d:      	movq	(%rip), %r12            # 0x384 <tail_icmp6_send_time_exceeded+0xc4>
     384:      	movzwl	(%r12), %eax
     389:      	leaq	0x48(%rsp), %r15
     38e:      	movw	%ax, 0x12(%rsp)
     393:      	movl	0x98(%rdi), %eax
     399:      	movl	%eax, 0x14(%rsp)
     39d:      	movq	$0x0, 0x18(%rsp)
     3a6:      	movl	$0x0, 0x20(%rsp)
     3ae:      	movl	$0x19, %eax
     3b3:      	movq	(%rip), %rsi            # 0x3ba <tail_icmp6_send_time_exceeded+0xfa>
     3ba:      	leaq	0x10(%rsp), %rcx
     3bf:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     3c4:      	movl	$0x14, %r8d
     3ca:      	callq	*%rax
     3cc:      	movl	$0x1a, %eax
     3d1:      	movq	%rbx, %rdi
     3d4:      	movl	%r14d, %esi
     3d7:      	movq	%r15, %rdx
     3da:      	movl	$0x28, %ecx
     3df:      	callq	*%rax
     3e1:      	movl	$0xffffff7a, %ebp       # imm = 0xFFFFFF7A
     3e6:      	testl	%eax, %eax
     3e8:      	js	0x908 <tail_icmp6_send_time_exceeded+0x648>
     3ee:      	movl	$0x9, %eax
     3f3:      	leal	0x6(%r14), %esi
     3f7:      	leaq	0xf(%rsp), %rdx
     3fc:      	movq	%rbx, %rdi
     3ff:      	movl	$0x1, %ecx
     404:      	xorl	%r8d, %r8d
     407:      	callq	*%rax
     409:      	testl	%eax, %eax
     40b:      	js	0x903 <tail_icmp6_send_time_exceeded+0x643>
     411:      	leaq	0x70(%rsp), %rdx
     416:      	movzbl	0x4e(%rsp), %eax
     41b:      	cmpl	$0x6, %eax
     41e:      	je	0x54b <tail_icmp6_send_time_exceeded+0x28b>
     424:      	cmpl	$0x3a, %eax
     427:      	je	0x437 <tail_icmp6_send_time_exceeded+0x177>
     429:      	movl	$0xffffff72, %ebp       # imm = 0xFFFFFF72
     42e:      	cmpl	$0x11, %eax
     431:      	jne	0x908 <tail_icmp6_send_time_exceeded+0x648>
     437:      	movl	$0x1a, %eax
     43c:      	leal	0x28(%r14), %r15d
     440:      	movq	%rbx, %rdi
     443:      	movl	%r15d, %esi
     446:      	movl	$0x8, %ecx
     44b:      	callq	*%rax
     44d:      	movl	$0xffffff7a, %ebp       # imm = 0xFFFFFF7A
     452:      	testl	%eax, %eax
     454:      	js	0x908 <tail_icmp6_send_time_exceeded+0x648>
     45a:      	movl	$0x1c, %eax
     45f:      	leaq	0x40(%rsp), %rdx
     464:      	xorl	%edi, %edi
     466:      	xorl	%esi, %esi
     468:      	movl	$0x38, %ecx
     46d:      	xorl	%r8d, %r8d
     470:      	callq	*%rax
     472:      	movl	$0x38000000, 0x10(%rsp) # imm = 0x38000000
     47a:      	movl	$0x3a000000, 0x28(%rsp) # imm = 0x3A000000
     482:      	leaq	0x50(%rsp), %rdx
     487:      	movl	$0x1c, %r9d
     48d:      	xorl	%edi, %edi
     48f:      	xorl	%esi, %esi
     491:      	movl	$0x10, %ecx
     496:      	movl	%eax, %r8d
     499:      	callq	*%r9
     49c:      	leaq	0x60(%rsp), %rdx
     4a1:      	movl	$0x1c, %r9d
     4a7:      	xorl	%edi, %edi
     4a9:      	xorl	%esi, %esi
     4ab:      	movl	$0x10, %ecx
     4b0:      	movl	%eax, %r8d
     4b3:      	callq	*%r9
     4b6:      	movl	$0x1c, %r9d
     4bc:      	leaq	0x10(%rsp), %rdx
     4c1:      	xorl	%edi, %edi
     4c3:      	xorl	%esi, %esi
     4c5:      	movl	$0x4, %ecx
     4ca:      	movl	%eax, %r8d
     4cd:      	callq	*%r9
     4d0:      	movl	$0x1c, %r9d
     4d6:      	leaq	0x28(%rsp), %rdx
     4db:      	xorl	%edi, %edi
     4dd:      	xorl	%esi, %esi
     4df:      	movl	$0x4, %ecx
     4e4:      	movl	%eax, %r8d
     4e7:      	callq	*%r9
     4ea:      	movl	%eax, %ebp
     4ec:      	movw	$0x3800, 0xc(%rsp)      # imm = 0x3800
     4f3:      	movbew	0x4c(%rsp), %ax
     4fa:      	movzwl	%ax, %eax
     4fd:      	movl	$0x26, %ecx
     502:      	movl	0x70(%rbx), %edx
     505:      	negl	%eax
     507:      	leal	(%rdx,%rax), %esi
     50a:      	addl	$0x38, %esi
     50d:      	movq	%rbx, %rdi
     510:      	xorl	%edx, %edx
     512:      	callq	*%rcx
     514:      	testl	%eax, %eax
     516:      	js	0x903 <tail_icmp6_send_time_exceeded+0x643>
     51c:      	movl	$0x9, %eax
     521:      	leaq	0x40(%rsp), %rdx
     526:      	movq	%rbx, %rdi
     529:      	movl	%r15d, %esi
     52c:      	movl	$0x38, %ecx
     531:      	xorl	%r8d, %r8d
     534:      	callq	*%rax
     536:      	testl	%eax, %eax
     538:      	js	0x903 <tail_icmp6_send_time_exceeded+0x643>
     53e:      	movl	%ebp, %r15d
     541:      	movl	$0x9, %eax
     546:      	jmp	0x655 <tail_icmp6_send_time_exceeded+0x395>
     54b:      	movl	$0x1a, %eax
     550:      	leal	0x28(%r14), %r15d
     554:      	movq	%rbx, %rdi
     557:      	movl	%r15d, %esi
     55a:      	movl	$0x14, %ecx
     55f:      	callq	*%rax
     561:      	testl	%eax, %eax
     563:      	js	0x908 <tail_icmp6_send_time_exceeded+0x648>
     569:      	movl	$0x1c, %eax
     56e:      	leaq	0x40(%rsp), %rdx
     573:      	xorl	%edi, %edi
     575:      	xorl	%esi, %esi
     577:      	movl	$0x44, %ecx
     57c:      	xorl	%r8d, %r8d
     57f:      	callq	*%rax
     581:      	movl	$0x44000000, 0x10(%rsp) # imm = 0x44000000
     589:      	movl	$0x3a000000, 0x28(%rsp) # imm = 0x3A000000
     591:      	leaq	0x50(%rsp), %rdx
     596:      	movl	$0x1c, %r9d
     59c:      	xorl	%edi, %edi
     59e:      	xorl	%esi, %esi
     5a0:      	movl	$0x10, %ecx
     5a5:      	movl	%eax, %r8d
     5a8:      	callq	*%r9
     5ab:      	leaq	0x60(%rsp), %rdx
     5b0:      	movl	$0x1c, %r9d
     5b6:      	xorl	%edi, %edi
     5b8:      	xorl	%esi, %esi
     5ba:      	movl	$0x10, %ecx
     5bf:      	movl	%eax, %r8d
     5c2:      	callq	*%r9
     5c5:      	movl	$0x1c, %r9d
     5cb:      	leaq	0x10(%rsp), %rdx
     5d0:      	xorl	%edi, %edi
     5d2:      	xorl	%esi, %esi
     5d4:      	movl	$0x4, %ecx
     5d9:      	movl	%eax, %r8d
     5dc:      	callq	*%r9
     5df:      	movl	$0x1c, %r9d
     5e5:      	leaq	0x28(%rsp), %rdx
     5ea:      	xorl	%edi, %edi
     5ec:      	xorl	%esi, %esi
     5ee:      	movl	$0x4, %ecx
     5f3:      	movl	%eax, %r8d
     5f6:      	callq	*%r9
     5f9:      	movl	%eax, %ebp
     5fb:      	movw	$0x4400, 0xc(%rsp)      # imm = 0x4400
     602:      	movbew	0x4c(%rsp), %ax
     609:      	movzwl	%ax, %eax
     60c:      	movl	$0x26, %ecx
     611:      	movl	0x70(%rbx), %edx
     614:      	negl	%eax
     616:      	leal	(%rdx,%rax), %esi
     619:      	addl	$0x44, %esi
     61c:      	movq	%rbx, %rdi
     61f:      	xorl	%edx, %edx
     621:      	callq	*%rcx
     623:      	testl	%eax, %eax
     625:      	js	0x903 <tail_icmp6_send_time_exceeded+0x643>
     62b:      	movl	$0x9, %eax
     630:      	leaq	0x40(%rsp), %rdx
     635:      	movq	%rbx, %rdi
     638:      	movl	%r15d, %esi
     63b:      	movl	$0x44, %ecx
     640:      	xorl	%r8d, %r8d
     643:      	callq	*%rax
     645:      	testl	%eax, %eax
     647:      	js	0x903 <tail_icmp6_send_time_exceeded+0x643>
     64d:      	movl	%ebp, %r15d
     650:      	movl	$0x9, %eax
     655:      	leal	0x4(%r14), %esi
     659:      	leaq	0xc(%rsp), %rdx
     65e:      	movq	%rbx, %rdi
     661:      	movl	$0x2, %ecx
     666:      	xorl	%r8d, %r8d
     669:      	callq	*%rax
     66b:      	movl	$0xffffff73, %ebp       # imm = 0xFFFFFF73
     670:      	testl	%eax, %eax
     672:      	js	0x908 <tail_icmp6_send_time_exceeded+0x648>
     678:      	leal	0x2a(%r14), %ebp
     67c:      	movl	$0xb, %eax
     681:      	movq	%rbx, %rdi
     684:      	movl	%ebp, %esi
     686:      	xorl	%edx, %edx
     688:      	movl	%r15d, %ecx
     68b:      	movl	$0x10, %r8d
     691:      	callq	*%rax
     693:      	testl	%eax, %eax
     695:      	js	0x9c3 <tail_icmp6_send_time_exceeded+0x703>
     69b:      	movl	%ebp, 0x3c(%rsp)
     69f:      	movq	0xa0(%rsp), %rax
     6a7:      	movq	0x98(%rsp), %rcx
     6af:      	movq	%rax, 0x28(%rsp)
     6b4:      	movq	%rcx, 0x30(%rsp)
     6b9:      	movq	(%rip), %rax            # 0x6c0 <tail_icmp6_send_time_exceeded+0x400>
     6c0:      	movq	(%rax), %rax
     6c3:      	movq	%rax, 0xa8(%rsp)
     6cb:      	movl	$0x1a, %eax
     6d0:      	leal	0x8(%r14), %r15d
     6d4:      	leaq	0xb8(%rsp), %rdx
     6dc:      	movq	%rbx, %rdi
     6df:      	movl	%r15d, %esi
     6e2:      	movl	$0x10, %ecx
     6e7:      	callq	*%rax
     6e9:      	movl	$0xffffff7a, %ebp       # imm = 0xFFFFFF7A
     6ee:      	testl	%eax, %eax
     6f0:      	js	0x908 <tail_icmp6_send_time_exceeded+0x648>
     6f6:      	movl	$0x1a, %eax
     6fb:      	addl	$0x18, %r14d
     6ff:      	leaq	0xc8(%rsp), %rdx
     707:      	movq	%rbx, %rdi
     70a:      	movl	%r14d, %esi
     70d:      	movl	$0x10, %ecx
     712:      	callq	*%rax
     714:      	testl	%eax, %eax
     716:      	js	0x908 <tail_icmp6_send_time_exceeded+0x648>
     71c:      	movl	$0x9, %eax
     721:      	leaq	0x28(%rsp), %rdx
     726:      	movq	%rbx, %rdi
     729:      	movl	%r15d, %esi
     72c:      	movl	$0x10, %ecx
     731:      	xorl	%r8d, %r8d
     734:      	callq	*%rax
     736:      	testl	%eax, %eax
     738:      	js	0x903 <tail_icmp6_send_time_exceeded+0x643>
     73e:      	movl	$0x9, %eax
     743:      	leaq	0xb8(%rsp), %rdx
     74b:      	movq	%rbx, %rdi
     74e:      	movl	%r14d, %esi
     751:      	movl	$0x10, %ecx
     756:      	xorl	%r8d, %r8d
     759:      	callq	*%rax
     75b:      	testl	%eax, %eax
     75d:      	js	0x903 <tail_icmp6_send_time_exceeded+0x643>
     763:      	movl	$0x1c, %eax
     768:      	leaq	0xb8(%rsp), %rdi
     770:      	leaq	0x28(%rsp), %rdx
     775:      	movl	$0x10, %esi
     77a:      	movl	$0x10, %ecx
     77f:      	xorl	%r8d, %r8d
     782:      	callq	*%rax
     784:      	movl	$0xb, %r14d
     78a:      	movq	%rbx, %rdi
     78d:      	movl	0x3c(%rsp), %r15d
     792:      	movl	%r15d, %esi
     795:      	xorl	%edx, %edx
     797:      	movl	%eax, %ecx
     799:      	movl	$0x10, %r8d
     79f:      	callq	*%r14
     7a2:      	movl	$0xffffff66, %ebp       # imm = 0xFFFFFF66
     7a7:      	testl	%eax, %eax
     7a9:      	js	0x908 <tail_icmp6_send_time_exceeded+0x648>
     7af:      	movl	$0x1c, %eax
     7b4:      	leaq	0xc8(%rsp), %rdi
     7bc:      	leaq	0xb8(%rsp), %rdx
     7c4:      	movl	$0x10, %esi
     7c9:      	movl	$0x10, %ecx
     7ce:      	xorl	%r8d, %r8d
     7d1:      	callq	*%rax
     7d3:      	movq	%rbx, %rdi
     7d6:      	movl	%r15d, %esi
     7d9:      	xorl	%edx, %edx
     7db:      	movl	%eax, %ecx
     7dd:      	movl	$0x10, %r8d
     7e3:      	callq	*%r14
     7e6:      	testl	%eax, %eax
     7e8:      	js	0x908 <tail_icmp6_send_time_exceeded+0x648>
     7ee:      	movl	$0x1a, %eax
     7f3:      	leaq	0xb0(%rsp), %rdx
     7fb:      	movq	%rbx, %rdi
     7fe:      	movl	$0x6, %esi
     803:      	movl	$0x6, %ecx
     808:      	callq	*%rax
     80a:      	movl	$0xffffff7a, %ebp       # imm = 0xFFFFFF7A
     80f:      	testl	%eax, %eax
     811:      	js	0x908 <tail_icmp6_send_time_exceeded+0x648>
     817:      	movl	$0x9, %eax
     81c:      	leaq	0xb0(%rsp), %rdx
     824:      	movq	%rbx, %rdi
     827:      	xorl	%esi, %esi
     829:      	movl	$0x6, %ecx
     82e:      	xorl	%r8d, %r8d
     831:      	callq	*%rax
     833:      	testl	%eax, %eax
     835:      	js	0x903 <tail_icmp6_send_time_exceeded+0x643>
     83b:      	movl	$0x9, %eax
     840:      	leaq	0xa8(%rsp), %rdx
     848:      	xorl	%r14d, %r14d
     84b:      	movq	%rbx, %rdi
     84e:      	movl	$0x6, %esi
     853:      	movl	$0x6, %ecx
     858:      	xorl	%r8d, %r8d
     85b:      	callq	*%rax
     85d:      	movl	$0xffffff73, %ebp       # imm = 0xFFFFFF73
     862:      	testl	%eax, %eax
     864:      	js	0x908 <tail_icmp6_send_time_exceeded+0x648>
     86a:      	movq	0x10(%rbx), %rax
     86e:      	testq	%rax, %rax
     871:      	je	0x87a <tail_icmp6_send_time_exceeded+0x5ba>
     873:      	movl	0xe0(%rax), %r14d
     87a:      	movl	0x70(%rbx), %eax
     87d:      	movq	(%rip), %rcx            # 0x884 <tail_icmp6_send_time_exceeded+0x5c4>
     884:      	movl	(%rcx), %edx
     886:      	cmpl	%edx, %eax
     888:      	movw	$0x403, 0x10(%rsp)      # imm = 0x403
     88f:      	movzwl	(%r12), %ecx
     894:      	movw	%cx, 0x12(%rsp)
     899:      	cmovbl	%eax, %edx
     89c:      	movl	0x98(%rbx), %ecx
     8a2:      	movl	%ecx, 0x14(%rsp)
     8a6:      	movl	%eax, 0x18(%rsp)
     8aa:      	movw	%dx, 0x1c(%rsp)
     8af:      	movw	$0x1, 0x1e(%rsp)
     8b6:      	movl	%r14d, 0x20(%rsp)
     8bb:      	movl	$0x0, 0x24(%rsp)
     8c3:      	movl	$0x19, %eax
     8c8:      	shlq	$0x20, %rdx
     8cc:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     8d1:      	orq	%rcx, %rdx
     8d4:      	movq	(%rip), %rsi            # 0x8db <tail_icmp6_send_time_exceeded+0x61b>
     8db:      	leaq	0x10(%rsp), %rcx
     8e0:      	movq	%rbx, %rdi
     8e3:      	movl	$0x18, %r8d
     8e9:      	callq	*%rax
     8eb:      	movq	0x10(%rbx), %rax
     8ef:      	testq	%rax, %rax
     8f2:      	je	0x9cd <tail_icmp6_send_time_exceeded+0x70d>
     8f8:      	movl	0xe0(%rax), %edi
     8fe:      	jmp	0x9cf <tail_icmp6_send_time_exceeded+0x70f>
     903:      	movl	$0xffffff73, %ebp       # imm = 0xFFFFFF73
     908:      	movl	%ebp, %eax
     90a:      	negl	%eax
     90c:      	cmovsl	%ebp, %eax
     90f:      	movq	$0x0, 0x30(%rbx)
     917:      	movzbl	%al, %eax
     91a:      	movl	%eax, 0x38(%rbx)
     91d:      	movabsq	$0x142670200000000, %rcx # imm = 0x142670200000000
     927:      	movq	%rcx, 0x3c(%rbx)
     92b:      	movl	0x70(%rbx), %r14d
     92f:      	movabsq	$0x6701420000, %rcx     # imm = 0x6701420000
     939:      	movq	%rcx, 0x10(%rsp)
     93e:      	movb	%al, 0x10(%rsp)
     942:      	andb	$0x3, %r13b
     946:      	movb	%r13b, 0x11(%rsp)
     94b:      	movl	$0x1, %eax
     950:      	movq	(%rip), %rdi            # 0x957 <tail_icmp6_send_time_exceeded+0x697>
     957:      	leaq	0x10(%rsp), %rsi
     95c:      	callq	*%rax
     95e:      	testq	%rax, %rax
     961:      	je	0x96c <tail_icmp6_send_time_exceeded+0x6ac>
     963:      	incq	(%rax)
     966:      	addq	%r14, 0x8(%rax)
     96a:      	jmp	0x994 <tail_icmp6_send_time_exceeded+0x6d4>
     96c:      	movq	$0x1, 0x40(%rsp)
     975:      	movq	%r14, 0x48(%rsp)
     97a:      	movl	$0x2, %eax
     97f:      	movq	(%rip), %rdi            # 0x986 <tail_icmp6_send_time_exceeded+0x6c6>
     986:      	leaq	0x10(%rsp), %rsi
     98b:      	leaq	0x40(%rsp), %rdx
     990:      	xorl	%ecx, %ecx
     992:      	callq	*%rax
     994:      	movl	$0xc, %eax
     999:      	movq	(%rip), %rsi            # 0x9a0 <tail_icmp6_send_time_exceeded+0x6e0>
     9a0:      	movq	%rbx, %rdi
     9a3:      	movl	$0x1, %edx
     9a8:      	callq	*%rax
     9aa:      	movl	$0x2, %ebp
     9af:      	movl	%ebp, %eax
     9b1:      	addq	$0xd8, %rsp
     9b8:      	popq	%rbx
     9b9:      	popq	%r12
     9bb:      	popq	%r13
     9bd:      	popq	%r14
     9bf:      	popq	%r15
     9c1:      	popq	%rbp
     9c2:      	retq
     9c3:      	movl	$0xffffff66, %ebp       # imm = 0xFFFFFF66
     9c8:      	jmp	0x908 <tail_icmp6_send_time_exceeded+0x648>
     9cd:      	xorl	%edi, %edi
     9cf:      	movl	$0x17, %eax
     9d4:      	xorl	%esi, %esi
     9d6:      	callq	*%rax
     9d8:      	movl	%eax, %ebp
     9da:      	testl	%eax, %eax
     9dc:      	js	0x908 <tail_icmp6_send_time_exceeded+0x648>
     9e2:      	cmpl	$0x2, %ebp
     9e5:      	jne	0x9af <tail_icmp6_send_time_exceeded+0x6ef>
     9e7:      	jmp	0x908 <tail_icmp6_send_time_exceeded+0x648>
     9ec:      	nopl	(%rax)

00000000000009f0 <tail_icmp6_handle_ns>:
     9f0:      	pushq	%rbp
     9f1:      	pushq	%r15
     9f3:      	pushq	%r14
     9f5:      	pushq	%r13
     9f7:      	pushq	%r12
     9f9:      	pushq	%rbx
     9fa:      	subq	$0xe8, %rsp
     a01:      	movq	%rdi, %rbx
     a04:      	movl	0x30(%rdi), %r13d
     a08:      	movl	0x34(%rdi), %r12d
     a0c:      	movl	$0x0, 0x30(%rdi)
     a13:      	movq	(%rip), %rax            # 0xa1a <tail_icmp6_handle_ns+0x2a>
     a1a:      	movq	(%rax), %rcx
     a1d:      	movq	%rcx, 0xd0(%rsp)
     a25:      	movq	0x8(%rax), %rax
     a29:      	movq	%rax, 0xc8(%rsp)
     a31:      	movq	(%rip), %r14            # 0xa38 <tail_icmp6_handle_ns+0x48>
     a38:      	movzbl	(%r14), %eax
     a3c:      	movb	%al, (%rsp)
     a3f:      	movzbl	0x1(%r14), %eax
     a44:      	movb	%al, 0xf(%rsp)
     a48:      	movzbl	0x2(%r14), %eax
     a4d:      	movb	%al, 0xc(%rsp)
     a51:      	movzbl	0x3(%r14), %eax
     a56:      	movb	%al, 0xe(%rsp)
     a5a:      	movzbl	0x4(%r14), %eax
     a5f:      	movb	%al, 0x8(%rsp)
     a63:      	movzbl	0x5(%r14), %eax
     a68:      	movb	%al, 0xd(%rsp)
     a6c:      	movzwl	0x6(%r14), %eax
     a71:      	movw	%ax, 0x9e(%rsp)
     a79:      	movl	$0x1a, %eax
     a7e:      	leal	0x30(%r13), %ebp
     a82:      	leaq	0xa8(%rsp), %rdx
     a8a:      	movl	%ebp, %esi
     a8c:      	movl	$0x10, %ecx
     a91:      	callq	*%rax
     a93:      	testl	%eax, %eax
     a95:      	js	0xf19 <tail_icmp6_handle_ns+0x529>
     a9b:      	movq	0xb0(%rsp), %rax
     aa3:      	movw	$0xd02, 0x18(%rsp)      # imm = 0xD02
     aaa:      	movq	(%rip), %rcx            # 0xab1 <tail_icmp6_handle_ns+0xc1>
     ab1:      	movzwl	(%rcx), %ecx
     ab4:      	movw	%cx, 0x1a(%rsp)
     ab9:      	movl	0x98(%rbx), %ecx
     abf:      	movl	%ecx, 0x1c(%rsp)
     ac3:      	movq	%rax, 0x20(%rsp)
     ac8:      	movl	$0x0, 0x28(%rsp)
     ad0:      	movl	$0x19, %eax
     ad5:      	movq	(%rip), %rsi            # 0xadc <tail_icmp6_handle_ns+0xec>
     adc:      	leaq	0x18(%rsp), %rcx
     ae1:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     ae6:      	movq	%rbx, %rdi
     ae9:      	movl	$0x14, %r8d
     aef:      	callq	*%rax
     af1:      	movq	0xa8(%rsp), %rcx
     af9:      	movq	0xb0(%rsp), %rax
     b01:      	cmpq	0xd0(%rsp), %rcx
     b09:      	jne	0xf89 <tail_icmp6_handle_ns+0x599>
     b0f:      	cmpq	0xc8(%rsp), %rax
     b17:      	jne	0xf89 <tail_icmp6_handle_ns+0x599>
     b1d:      	movl	%r12d, 0x3c(%rsp)
     b22:      	movabsq	$0xc000000088, %rax     # imm = 0xC000000088
     b2c:      	movq	%rax, 0x30(%rsp)
     b31:      	movl	$0x1a, %eax
     b36:      	leal	0x40(%r13), %r15d
     b3a:      	leaq	0x48(%rsp), %rdx
     b3f:      	movq	%rbx, %rdi
     b42:      	movl	%r15d, %esi
     b45:      	movl	$0x8, %ecx
     b4a:      	callq	*%rax
     b4c:      	xorl	%r12d, %r12d
     b4f:      	testl	%eax, %eax
     b51:      	js	0x185c <tail_icmp6_handle_ns+0xe6c>
     b57:      	movl	$0x1a, %eax
     b5c:      	movq	%r13, 0x60(%rsp)
     b61:      	addl	$0x28, %r13d
     b65:      	leaq	0x40(%rsp), %rdx
     b6a:      	movq	%rbx, %rdi
     b6d:      	movl	%r13d, %esi
     b70:      	movl	$0x8, %ecx
     b75:      	callq	*%rax
     b77:      	movl	%eax, %ecx
     b79:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
     b7e:      	testl	%ecx, %ecx
     b80:      	js	0x19a4 <tail_icmp6_handle_ns+0xfb4>
     b86:      	movzwl	0x42(%rsp), %eax
     b8b:      	movw	%ax, 0x32(%rsp)
     b90:      	movl	$0x1a, %eax
     b95:      	leaq	0x88(%rsp), %rdx
     b9d:      	movq	%rbx, %rdi
     ba0:      	movl	%ebp, %esi
     ba2:      	movl	$0x10, %ecx
     ba7:      	callq	*%rax
     ba9:      	testl	%eax, %eax
     bab:      	js	0x1852 <tail_icmp6_handle_ns+0xe62>
     bb1:      	movl	$0x9, %eax
     bb6:      	leaq	0x30(%rsp), %rdx
     bbb:      	movq	%rbx, %rdi
     bbe:      	movl	%r13d, %esi
     bc1:      	movl	$0x8, %ecx
     bc6:      	xorl	%r8d, %r8d
     bc9:      	callq	*%rax
     bcb:      	testl	%eax, %eax
     bcd:      	js	0x1852 <tail_icmp6_handle_ns+0xe62>
     bd3:      	movl	$0x1c, %eax
     bd8:      	leaq	0x40(%rsp), %rdi
     bdd:      	leaq	0x30(%rsp), %rdx
     be2:      	movl	$0x8, %esi
     be7:      	movl	$0x8, %ecx
     bec:      	movl	%r12d, %r8d
     bef:      	callq	*%rax
     bf1:      	movl	%eax, %r12d
     bf4:      	movl	$0x1a, %eax
     bf9:      	leaq	0x48(%rsp), %rdx
     bfe:      	movq	%rbx, %rdi
     c01:      	movl	%r15d, %esi
     c04:      	movl	$0x8, %ecx
     c09:      	callq	*%rax
     c0b:      	testl	%eax, %eax
     c0d:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
     c12:      	js	0x19a4 <tail_icmp6_handle_ns+0xfb4>
     c18:      	movw	$0x102, 0x10(%rsp)      # imm = 0x102
     c1f:      	movzbl	(%rsp), %eax
     c23:      	movb	%al, 0x12(%rsp)
     c27:      	movzbl	0xf(%rsp), %eax
     c2c:      	movb	%al, 0x13(%rsp)
     c30:      	movzbl	0xc(%rsp), %eax
     c35:      	movb	%al, 0x14(%rsp)
     c39:      	movzbl	0xe(%rsp), %eax
     c3e:      	movb	%al, 0x15(%rsp)
     c42:      	movzbl	0x8(%rsp), %eax
     c47:      	movb	%al, 0x16(%rsp)
     c4b:      	movzbl	0xd(%rsp), %eax
     c50:      	movb	%al, 0x17(%rsp)
     c54:      	movl	$0x9, %eax
     c59:      	leaq	0x10(%rsp), %rdx
     c5e:      	movq	%rbx, %rdi
     c61:      	movl	%r15d, %esi
     c64:      	movl	$0x8, %ecx
     c69:      	xorl	%r8d, %r8d
     c6c:      	callq	*%rax
     c6e:      	movl	%eax, %ecx
     c70:      	movl	$0xffffff73, %eax       # imm = 0xFFFFFF73
     c75:      	testl	%ecx, %ecx
     c77:      	js	0x19a4 <tail_icmp6_handle_ns+0xfb4>
     c7d:      	movq	0x60(%rsp), %r15
     c82:      	leal	0x2a(%r15), %ebp
     c86:      	movl	$0x1c, %eax
     c8b:      	leaq	0x48(%rsp), %rdi
     c90:      	leaq	0x10(%rsp), %rdx
     c95:      	movl	$0x8, %esi
     c9a:      	movl	$0x8, %ecx
     c9f:      	movl	%r12d, %r8d
     ca2:      	callq	*%rax
     ca4:      	movl	$0xb, %r9d
     caa:      	movq	%rbx, %rdi
     cad:      	movl	%ebp, %esi
     caf:      	xorl	%edx, %edx
     cb1:      	movl	%eax, %ecx
     cb3:      	movl	$0x10, %r8d
     cb9:      	callq	*%r9
     cbc:      	testl	%eax, %eax
     cbe:      	js	0x1998 <tail_icmp6_handle_ns+0xfa8>
     cc4:      	movq	0x88(%rsp), %rax
     ccc:      	movq	0x90(%rsp), %rcx
     cd4:      	movq	%rax, 0x50(%rsp)
     cd9:      	movq	%rcx, 0x58(%rsp)
     cde:      	movq	(%r14), %rax
     ce1:      	movq	%rax, 0x68(%rsp)
     ce6:      	movl	$0x1a, %eax
     ceb:      	movq	%r15, %r12
     cee:      	addl	$0x8, %r15d
     cf2:      	leaq	0x78(%rsp), %rdx
     cf7:      	movq	%rbx, %rdi
     cfa:      	movl	%r15d, %esi
     cfd:      	movl	$0x10, %ecx
     d02:      	callq	*%rax
     d04:      	movl	%eax, %ecx
     d06:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
     d0b:      	testl	%ecx, %ecx
     d0d:      	js	0x19a4 <tail_icmp6_handle_ns+0xfb4>
     d13:      	movl	$0x1a, %eax
     d18:      	addl	$0x18, %r12d
     d1c:      	leaq	0xb8(%rsp), %rdx
     d24:      	movq	%rbx, %rdi
     d27:      	movq	%r12, %r14
     d2a:      	movl	%r12d, %esi
     d2d:      	movl	$0x10, %ecx
     d32:      	callq	*%rax
     d34:      	testl	%eax, %eax
     d36:      	js	0x199f <tail_icmp6_handle_ns+0xfaf>
     d3c:      	movl	$0x9, %eax
     d41:      	leaq	0x50(%rsp), %rdx
     d46:      	movq	%rbx, %rdi
     d49:      	movl	%r15d, %esi
     d4c:      	movl	$0x10, %ecx
     d51:      	xorl	%r8d, %r8d
     d54:      	callq	*%rax
     d56:      	testl	%eax, %eax
     d58:      	js	0x1852 <tail_icmp6_handle_ns+0xe62>
     d5e:      	movl	$0x9, %eax
     d63:      	leaq	0x78(%rsp), %rdx
     d68:      	movq	%rbx, %rdi
     d6b:      	movl	%r14d, %esi
     d6e:      	movl	$0x10, %ecx
     d73:      	xorl	%r8d, %r8d
     d76:      	callq	*%rax
     d78:      	testl	%eax, %eax
     d7a:      	js	0x1852 <tail_icmp6_handle_ns+0xe62>
     d80:      	movl	$0x1c, %eax
     d85:      	leaq	0x78(%rsp), %rdi
     d8a:      	leaq	0x50(%rsp), %rdx
     d8f:      	movl	$0x10, %esi
     d94:      	movl	$0x10, %ecx
     d99:      	xorl	%r8d, %r8d
     d9c:      	callq	*%rax
     d9e:      	movl	$0xb, %r14d
     da4:      	movq	%rbx, %rdi
     da7:      	movl	%ebp, %esi
     da9:      	xorl	%edx, %edx
     dab:      	movl	%eax, %ecx
     dad:      	movl	$0x10, %r8d
     db3:      	callq	*%r14
     db6:      	movl	%eax, %ecx
     db8:      	movl	$0xffffff66, %eax       # imm = 0xFFFFFF66
     dbd:      	testl	%ecx, %ecx
     dbf:      	js	0x19a4 <tail_icmp6_handle_ns+0xfb4>
     dc5:      	movl	$0x1c, %eax
     dca:      	leaq	0xb8(%rsp), %rdi
     dd2:      	leaq	0x78(%rsp), %rdx
     dd7:      	movl	$0x10, %esi
     ddc:      	movl	$0x10, %ecx
     de1:      	xorl	%r8d, %r8d
     de4:      	callq	*%rax
     de6:      	movq	%rbx, %rdi
     de9:      	movl	%ebp, %esi
     deb:      	xorl	%edx, %edx
     ded:      	movl	%eax, %ecx
     def:      	movl	$0x10, %r8d
     df5:      	callq	*%r14
     df8:      	movl	%eax, %ecx
     dfa:      	movl	$0xffffff66, %eax       # imm = 0xFFFFFF66
     dff:      	testl	%ecx, %ecx
     e01:      	js	0x19a4 <tail_icmp6_handle_ns+0xfb4>
     e07:      	movl	$0x1a, %eax
     e0c:      	leaq	0x70(%rsp), %rdx
     e11:      	movq	%rbx, %rdi
     e14:      	movl	$0x6, %esi
     e19:      	movl	$0x6, %ecx
     e1e:      	callq	*%rax
     e20:      	movl	%eax, %ecx
     e22:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
     e27:      	testl	%ecx, %ecx
     e29:      	js	0x19a4 <tail_icmp6_handle_ns+0xfb4>
     e2f:      	movl	$0x9, %eax
     e34:      	leaq	0x70(%rsp), %rdx
     e39:      	movq	%rbx, %rdi
     e3c:      	xorl	%esi, %esi
     e3e:      	movl	$0x6, %ecx
     e43:      	xorl	%r8d, %r8d
     e46:      	callq	*%rax
     e48:      	testl	%eax, %eax
     e4a:      	js	0x1852 <tail_icmp6_handle_ns+0xe62>
     e50:      	movl	$0x9, %eax
     e55:      	leaq	0x68(%rsp), %rdx
     e5a:      	xorl	%ebp, %ebp
     e5c:      	movq	%rbx, %rdi
     e5f:      	movl	$0x6, %esi
     e64:      	movl	$0x6, %ecx
     e69:      	xorl	%r8d, %r8d
     e6c:      	callq	*%rax
     e6e:      	movl	%eax, %ecx
     e70:      	movl	$0xffffff73, %eax       # imm = 0xFFFFFF73
     e75:      	testl	%ecx, %ecx
     e77:      	js	0x19a4 <tail_icmp6_handle_ns+0xfb4>
     e7d:      	movq	0x10(%rbx), %rax
     e81:      	testq	%rax, %rax
     e84:      	je	0xe8c <tail_icmp6_handle_ns+0x49c>
     e86:      	movl	0xe0(%rax), %ebp
     e8c:      	movl	0x70(%rbx), %eax
     e8f:      	movq	(%rip), %rcx            # 0xe96 <tail_icmp6_handle_ns+0x4a6>
     e96:      	movl	(%rcx), %edx
     e98:      	cmpl	%edx, %eax
     e9a:      	movw	$0x403, 0x18(%rsp)      # imm = 0x403
     ea1:      	movq	(%rip), %rcx            # 0xea8 <tail_icmp6_handle_ns+0x4b8>
     ea8:      	movzwl	(%rcx), %ecx
     eab:      	movw	%cx, 0x1a(%rsp)
     eb0:      	cmovbl	%eax, %edx
     eb3:      	movl	0x98(%rbx), %ecx
     eb9:      	movl	%ecx, 0x1c(%rsp)
     ebd:      	movl	%eax, 0x20(%rsp)
     ec1:      	movw	%dx, 0x24(%rsp)
     ec6:      	movw	$0x1, 0x26(%rsp)
     ecd:      	movl	%ebp, 0x28(%rsp)
     ed1:      	movl	$0x0, 0x2c(%rsp)
     ed9:      	movl	$0x19, %eax
     ede:      	shlq	$0x20, %rdx
     ee2:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     ee7:      	orq	%rcx, %rdx
     eea:      	movq	(%rip), %rsi            # 0xef1 <tail_icmp6_handle_ns+0x501>
     ef1:      	leaq	0x18(%rsp), %rcx
     ef6:      	movq	%rbx, %rdi
     ef9:      	movl	$0x18, %r8d
     eff:      	callq	*%rax
     f01:      	movq	0x10(%rbx), %rax
     f05:      	testq	%rax, %rax
     f08:      	je	0x19cc <tail_icmp6_handle_ns+0xfdc>
     f0e:      	movl	0xe0(%rax), %edi
     f14:      	jmp	0x19ce <tail_icmp6_handle_ns+0xfde>
     f19:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
     f1e:      	movl	%eax, %ecx
     f20:      	negl	%ecx
     f22:      	cmovsl	%eax, %ecx
     f25:      	movq	$0x0, 0x30(%rbx)
     f2d:      	movzbl	%cl, %eax
     f30:      	movl	%eax, 0x38(%rbx)
     f33:      	movabsq	$0x196670200000000, %rcx # imm = 0x196670200000000
     f3d:      	movq	%rcx, 0x3c(%rbx)
     f41:      	movl	0x70(%rbx), %r14d
     f45:      	movabsq	$0x6701960000, %rcx     # imm = 0x6701960000
     f4f:      	movq	%rcx, 0x50(%rsp)
     f54:      	movb	%al, 0x50(%rsp)
     f58:      	andb	$0x3, %r12b
     f5c:      	movb	%r12b, 0x51(%rsp)
     f61:      	movl	$0x1, %eax
     f66:      	movq	(%rip), %rdi            # 0xf6d <tail_icmp6_handle_ns+0x57d>
     f6d:      	leaq	0x50(%rsp), %rsi
     f72:      	callq	*%rax
     f74:      	testq	%rax, %rax
     f77:      	je	0x180a <tail_icmp6_handle_ns+0xe1a>
     f7d:      	incq	(%rax)
     f80:      	addq	%r14, 0x8(%rax)
     f84:      	jmp	0x1832 <tail_icmp6_handle_ns+0xe42>
     f89:      	movq	(%rip), %rdx            # 0xf90 <tail_icmp6_handle_ns+0x5a0>
     f90:      	movq	(%rdx), %rsi
     f93:      	movq	%rsi, 0xe0(%rsp)
     f9b:      	movq	0x8(%rdx), %rdx
     f9f:      	movq	%rdx, 0xd8(%rsp)
     fa7:      	cmpq	%rsi, %rcx
     faa:      	jne	0x13bc <tail_icmp6_handle_ns+0x9cc>
     fb0:      	cmpq	%rdx, %rax
     fb3:      	jne	0x13bc <tail_icmp6_handle_ns+0x9cc>
     fb9:      	movl	$0x1a, %eax
     fbe:      	leaq	0xa0(%rsp), %rdx
     fc6:      	movq	%rbx, %rdi
     fc9:      	movl	$0x6, %esi
     fce:      	movl	$0x6, %ecx
     fd3:      	callq	*%rax
     fd5:      	testl	%eax, %eax
     fd7:      	js	0x18ce <tail_icmp6_handle_ns+0xede>
     fdd:      	movl	%r12d, 0x3c(%rsp)
     fe2:      	movabsq	$0x6000000088, %rax     # imm = 0x6000000088
     fec:      	movq	%rax, 0x30(%rsp)
     ff1:      	movl	$0x1a, %eax
     ff6:      	leal	0x40(%r13), %r15d
     ffa:      	leaq	0x48(%rsp), %rdx
     fff:      	movq	%rbx, %rdi
    1002:      	movl	%r15d, %esi
    1005:      	movl	$0x8, %ecx
    100a:      	callq	*%rax
    100c:      	xorl	%r12d, %r12d
    100f:      	testl	%eax, %eax
    1011:      	js	0x18d8 <tail_icmp6_handle_ns+0xee8>
    1017:      	movl	$0x1a, %eax
    101c:      	movq	%r13, 0x60(%rsp)
    1021:      	addl	$0x28, %r13d
    1025:      	leaq	0x40(%rsp), %rdx
    102a:      	movq	%rbx, %rdi
    102d:      	movl	%r13d, %esi
    1030:      	movl	$0x8, %ecx
    1035:      	callq	*%rax
    1037:      	movl	%eax, %ecx
    1039:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
    103e:      	testl	%ecx, %ecx
    1040:      	js	0x19a4 <tail_icmp6_handle_ns+0xfb4>
    1046:      	movzwl	0x42(%rsp), %eax
    104b:      	movw	%ax, 0x32(%rsp)
    1050:      	movl	$0x1a, %eax
    1055:      	leaq	0x88(%rsp), %rdx
    105d:      	movq	%rbx, %rdi
    1060:      	movl	%ebp, %esi
    1062:      	movl	$0x10, %ecx
    1067:      	callq	*%rax
    1069:      	testl	%eax, %eax
    106b:      	js	0x1852 <tail_icmp6_handle_ns+0xe62>
    1071:      	movl	$0x9, %eax
    1076:      	leaq	0x30(%rsp), %rdx
    107b:      	movq	%rbx, %rdi
    107e:      	movl	%r13d, %esi
    1081:      	movl	$0x8, %ecx
    1086:      	xorl	%r8d, %r8d
    1089:      	callq	*%rax
    108b:      	testl	%eax, %eax
    108d:      	js	0x1852 <tail_icmp6_handle_ns+0xe62>
    1093:      	movl	$0x1c, %eax
    1098:      	leaq	0x40(%rsp), %rdi
    109d:      	leaq	0x30(%rsp), %rdx
    10a2:      	movl	$0x8, %esi
    10a7:      	movl	$0x8, %ecx
    10ac:      	movl	%r12d, %r8d
    10af:      	callq	*%rax
    10b1:      	movl	%eax, %r12d
    10b4:      	movl	$0x1a, %eax
    10b9:      	leaq	0x48(%rsp), %rdx
    10be:      	movq	%rbx, %rdi
    10c1:      	movl	%r15d, %esi
    10c4:      	movl	$0x8, %ecx
    10c9:      	callq	*%rax
    10cb:      	testl	%eax, %eax
    10cd:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
    10d2:      	js	0x19a4 <tail_icmp6_handle_ns+0xfb4>
    10d8:      	movw	$0x102, 0x10(%rsp)      # imm = 0x102
    10df:      	movzwl	0xa0(%rsp), %eax
    10e7:      	movw	%ax, 0x12(%rsp)
    10ec:      	movl	0xa2(%rsp), %eax
    10f3:      	movl	%eax, 0x14(%rsp)
    10f7:      	movl	$0x9, %eax
    10fc:      	leaq	0x10(%rsp), %rdx
    1101:      	movq	%rbx, %rdi
    1104:      	movl	%r15d, %esi
    1107:      	movl	$0x8, %ecx
    110c:      	xorl	%r8d, %r8d
    110f:      	callq	*%rax
    1111:      	movl	%eax, %ecx
    1113:      	movl	$0xffffff73, %eax       # imm = 0xFFFFFF73
    1118:      	testl	%ecx, %ecx
    111a:      	js	0x19a4 <tail_icmp6_handle_ns+0xfb4>
    1120:      	movq	0x60(%rsp), %r15
    1125:      	leal	0x2a(%r15), %ebp
    1129:      	movl	$0x1c, %eax
    112e:      	leaq	0x48(%rsp), %rdi
    1133:      	leaq	0x10(%rsp), %rdx
    1138:      	movl	$0x8, %esi
    113d:      	movl	$0x8, %ecx
    1142:      	movl	%r12d, %r8d
    1145:      	callq	*%rax
    1147:      	movl	$0xb, %r9d
    114d:      	movq	%rbx, %rdi
    1150:      	movl	%ebp, %esi
    1152:      	xorl	%edx, %edx
    1154:      	movl	%eax, %ecx
    1156:      	movl	$0x10, %r8d
    115c:      	callq	*%r9
    115f:      	testl	%eax, %eax
    1161:      	js	0x1998 <tail_icmp6_handle_ns+0xfa8>
    1167:      	movq	0x88(%rsp), %rax
    116f:      	movq	0x90(%rsp), %rcx
    1177:      	movq	%rax, 0x50(%rsp)
    117c:      	movq	%rcx, 0x58(%rsp)
    1181:      	movq	(%r14), %rax
    1184:      	movq	%rax, 0x68(%rsp)
    1189:      	movl	$0x1a, %eax
    118e:      	movq	%r15, %r12
    1191:      	addl	$0x8, %r15d
    1195:      	leaq	0x78(%rsp), %rdx
    119a:      	movq	%rbx, %rdi
    119d:      	movl	%r15d, %esi
    11a0:      	movl	$0x10, %ecx
    11a5:      	callq	*%rax
    11a7:      	movl	%eax, %ecx
    11a9:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
    11ae:      	testl	%ecx, %ecx
    11b0:      	js	0x19a4 <tail_icmp6_handle_ns+0xfb4>
    11b6:      	movl	$0x1a, %eax
    11bb:      	addl	$0x18, %r12d
    11bf:      	leaq	0xb8(%rsp), %rdx
    11c7:      	movq	%rbx, %rdi
    11ca:      	movq	%r12, %r14
    11cd:      	movl	%r12d, %esi
    11d0:      	movl	$0x10, %ecx
    11d5:      	callq	*%rax
    11d7:      	testl	%eax, %eax
    11d9:      	js	0x199f <tail_icmp6_handle_ns+0xfaf>
    11df:      	movl	$0x9, %eax
    11e4:      	leaq	0x50(%rsp), %rdx
    11e9:      	movq	%rbx, %rdi
    11ec:      	movl	%r15d, %esi
    11ef:      	movl	$0x10, %ecx
    11f4:      	xorl	%r8d, %r8d
    11f7:      	callq	*%rax
    11f9:      	testl	%eax, %eax
    11fb:      	js	0x1852 <tail_icmp6_handle_ns+0xe62>
    1201:      	movl	$0x9, %eax
    1206:      	leaq	0x78(%rsp), %rdx
    120b:      	movq	%rbx, %rdi
    120e:      	movl	%r14d, %esi
    1211:      	movl	$0x10, %ecx
    1216:      	xorl	%r8d, %r8d
    1219:      	callq	*%rax
    121b:      	testl	%eax, %eax
    121d:      	js	0x1852 <tail_icmp6_handle_ns+0xe62>
    1223:      	movl	$0x1c, %eax
    1228:      	leaq	0x78(%rsp), %rdi
    122d:      	leaq	0x50(%rsp), %rdx
    1232:      	movl	$0x10, %esi
    1237:      	movl	$0x10, %ecx
    123c:      	xorl	%r8d, %r8d
    123f:      	callq	*%rax
    1241:      	movl	$0xb, %r14d
    1247:      	movq	%rbx, %rdi
    124a:      	movl	%ebp, %esi
    124c:      	xorl	%edx, %edx
    124e:      	movl	%eax, %ecx
    1250:      	movl	$0x10, %r8d
    1256:      	callq	*%r14
    1259:      	movl	%eax, %ecx
    125b:      	movl	$0xffffff66, %eax       # imm = 0xFFFFFF66
    1260:      	testl	%ecx, %ecx
    1262:      	js	0x19a4 <tail_icmp6_handle_ns+0xfb4>
    1268:      	movl	$0x1c, %eax
    126d:      	leaq	0xb8(%rsp), %rdi
    1275:      	leaq	0x78(%rsp), %rdx
    127a:      	movl	$0x10, %esi
    127f:      	movl	$0x10, %ecx
    1284:      	xorl	%r8d, %r8d
    1287:      	callq	*%rax
    1289:      	movq	%rbx, %rdi
    128c:      	movl	%ebp, %esi
    128e:      	xorl	%edx, %edx
    1290:      	movl	%eax, %ecx
    1292:      	movl	$0x10, %r8d
    1298:      	callq	*%r14
    129b:      	movl	%eax, %ecx
    129d:      	movl	$0xffffff66, %eax       # imm = 0xFFFFFF66
    12a2:      	testl	%ecx, %ecx
    12a4:      	js	0x19a4 <tail_icmp6_handle_ns+0xfb4>
    12aa:      	movl	$0x1a, %eax
    12af:      	leaq	0x70(%rsp), %rdx
    12b4:      	movq	%rbx, %rdi
    12b7:      	movl	$0x6, %esi
    12bc:      	movl	$0x6, %ecx
    12c1:      	callq	*%rax
    12c3:      	movl	%eax, %ecx
    12c5:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
    12ca:      	testl	%ecx, %ecx
    12cc:      	js	0x19a4 <tail_icmp6_handle_ns+0xfb4>
    12d2:      	movl	$0x9, %eax
    12d7:      	leaq	0x70(%rsp), %rdx
    12dc:      	movq	%rbx, %rdi
    12df:      	xorl	%esi, %esi
    12e1:      	movl	$0x6, %ecx
    12e6:      	xorl	%r8d, %r8d
    12e9:      	callq	*%rax
    12eb:      	testl	%eax, %eax
    12ed:      	js	0x1852 <tail_icmp6_handle_ns+0xe62>
    12f3:      	movl	$0x9, %eax
    12f8:      	leaq	0x68(%rsp), %rdx
    12fd:      	xorl	%ebp, %ebp
    12ff:      	movq	%rbx, %rdi
    1302:      	movl	$0x6, %esi
    1307:      	movl	$0x6, %ecx
    130c:      	xorl	%r8d, %r8d
    130f:      	callq	*%rax
    1311:      	movl	%eax, %ecx
    1313:      	movl	$0xffffff73, %eax       # imm = 0xFFFFFF73
    1318:      	testl	%ecx, %ecx
    131a:      	js	0x19a4 <tail_icmp6_handle_ns+0xfb4>
    1320:      	movq	0x10(%rbx), %rax
    1324:      	testq	%rax, %rax
    1327:      	je	0x132f <tail_icmp6_handle_ns+0x93f>
    1329:      	movl	0xe0(%rax), %ebp
    132f:      	movl	0x70(%rbx), %eax
    1332:      	movq	(%rip), %rcx            # 0x1339 <tail_icmp6_handle_ns+0x949>
    1339:      	movl	(%rcx), %edx
    133b:      	cmpl	%edx, %eax
    133d:      	movw	$0x403, 0x18(%rsp)      # imm = 0x403
    1344:      	movq	(%rip), %rcx            # 0x134b <tail_icmp6_handle_ns+0x95b>
    134b:      	movzwl	(%rcx), %ecx
    134e:      	movw	%cx, 0x1a(%rsp)
    1353:      	cmovbl	%eax, %edx
    1356:      	movl	0x98(%rbx), %ecx
    135c:      	movl	%ecx, 0x1c(%rsp)
    1360:      	movl	%eax, 0x20(%rsp)
    1364:      	movw	%dx, 0x24(%rsp)
    1369:      	movw	$0x1, 0x26(%rsp)
    1370:      	movl	%ebp, 0x28(%rsp)
    1374:      	movl	$0x0, 0x2c(%rsp)
    137c:      	movl	$0x19, %eax
    1381:      	shlq	$0x20, %rdx
    1385:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    138a:      	orq	%rcx, %rdx
    138d:      	movq	(%rip), %rsi            # 0x1394 <tail_icmp6_handle_ns+0x9a4>
    1394:      	leaq	0x18(%rsp), %rcx
    1399:      	movq	%rbx, %rdi
    139c:      	movl	$0x18, %r8d
    13a2:      	callq	*%rax
    13a4:      	movq	0x10(%rbx), %rax
    13a8:      	testq	%rax, %rax
    13ab:      	je	0x19d5 <tail_icmp6_handle_ns+0xfe5>
    13b1:      	movl	0xe0(%rax), %edi
    13b7:      	jmp	0x19d7 <tail_icmp6_handle_ns+0xfe7>
    13bc:      	movl	$0x0, 0x28(%rsp)
    13c4:      	movq	0xa8(%rsp), %rax
    13cc:      	movq	0xb0(%rsp), %rcx
    13d4:      	movq	%rax, 0x18(%rsp)
    13d9:      	movq	%rcx, 0x20(%rsp)
    13de:      	movb	$0x2, 0x28(%rsp)
    13e3:      	movl	$0x1, %eax
    13e8:      	movq	(%rip), %rdi            # 0x13ef <tail_icmp6_handle_ns+0x9ff>
    13ef:      	leaq	0x18(%rsp), %rsi
    13f4:      	callq	*%rax
    13f6:      	testq	%rax, %rax
    13f9:      	je	0x18c4 <tail_icmp6_handle_ns+0xed4>
    13ff:      	movq	%rax, %rcx
    1402:      	xorl	%eax, %eax
    1404:      	testb	$0x1, 0x8(%rcx)
    1408:      	jne	0x19a9 <tail_icmp6_handle_ns+0xfb9>
    140e:      	movl	%r12d, 0x3c(%rsp)
    1413:      	movabsq	$0x6000000088, %rax     # imm = 0x6000000088
    141d:      	movq	%rax, 0x30(%rsp)
    1422:      	movl	$0x1a, %eax
    1427:      	leal	0x40(%r13), %r15d
    142b:      	leaq	0x48(%rsp), %rdx
    1430:      	movq	%rbx, %rdi
    1433:      	movl	%r15d, %esi
    1436:      	movl	$0x8, %ecx
    143b:      	callq	*%rax
    143d:      	xorl	%r12d, %r12d
    1440:      	testl	%eax, %eax
    1442:      	js	0x193c <tail_icmp6_handle_ns+0xf4c>
    1448:      	movl	$0x1a, %eax
    144d:      	movq	%r13, 0x60(%rsp)
    1452:      	addl	$0x28, %r13d
    1456:      	leaq	0x40(%rsp), %rdx
    145b:      	movq	%rbx, %rdi
    145e:      	movl	%r13d, %esi
    1461:      	movl	$0x8, %ecx
    1466:      	callq	*%rax
    1468:      	movl	%eax, %ecx
    146a:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
    146f:      	testl	%ecx, %ecx
    1471:      	js	0x19a4 <tail_icmp6_handle_ns+0xfb4>
    1477:      	movzwl	0x42(%rsp), %eax
    147c:      	movw	%ax, 0x32(%rsp)
    1481:      	movl	$0x1a, %eax
    1486:      	leaq	0x88(%rsp), %rdx
    148e:      	movq	%rbx, %rdi
    1491:      	movl	%ebp, %esi
    1493:      	movl	$0x10, %ecx
    1498:      	callq	*%rax
    149a:      	testl	%eax, %eax
    149c:      	js	0x1852 <tail_icmp6_handle_ns+0xe62>
    14a2:      	movl	$0x9, %eax
    14a7:      	leaq	0x30(%rsp), %rdx
    14ac:      	movq	%rbx, %rdi
    14af:      	movl	%r13d, %esi
    14b2:      	movl	$0x8, %ecx
    14b7:      	xorl	%r8d, %r8d
    14ba:      	callq	*%rax
    14bc:      	testl	%eax, %eax
    14be:      	js	0x1852 <tail_icmp6_handle_ns+0xe62>
    14c4:      	movl	$0x1c, %eax
    14c9:      	leaq	0x40(%rsp), %rdi
    14ce:      	leaq	0x30(%rsp), %rdx
    14d3:      	movl	$0x8, %esi
    14d8:      	movl	$0x8, %ecx
    14dd:      	movl	%r12d, %r8d
    14e0:      	callq	*%rax
    14e2:      	movl	%eax, %r12d
    14e5:      	movl	$0x1a, %eax
    14ea:      	leaq	0x48(%rsp), %rdx
    14ef:      	movq	%rbx, %rdi
    14f2:      	movl	%r15d, %esi
    14f5:      	movl	$0x8, %ecx
    14fa:      	callq	*%rax
    14fc:      	testl	%eax, %eax
    14fe:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
    1503:      	js	0x19a4 <tail_icmp6_handle_ns+0xfb4>
    1509:      	movw	$0x102, 0x10(%rsp)      # imm = 0x102
    1510:      	movzbl	(%rsp), %eax
    1514:      	movb	%al, 0x12(%rsp)
    1518:      	movzbl	0xf(%rsp), %eax
    151d:      	movb	%al, 0x13(%rsp)
    1521:      	movzbl	0xc(%rsp), %eax
    1526:      	movb	%al, 0x14(%rsp)
    152a:      	movzbl	0xe(%rsp), %eax
    152f:      	movb	%al, 0x15(%rsp)
    1533:      	movzbl	0x8(%rsp), %eax
    1538:      	movb	%al, 0x16(%rsp)
    153c:      	movzbl	0xd(%rsp), %eax
    1541:      	movb	%al, 0x17(%rsp)
    1545:      	movl	$0x9, %eax
    154a:      	leaq	0x10(%rsp), %rdx
    154f:      	movq	%rbx, %rdi
    1552:      	movl	%r15d, %esi
    1555:      	movl	$0x8, %ecx
    155a:      	xorl	%r8d, %r8d
    155d:      	callq	*%rax
    155f:      	movl	%eax, %ecx
    1561:      	movl	$0xffffff73, %eax       # imm = 0xFFFFFF73
    1566:      	testl	%ecx, %ecx
    1568:      	js	0x19a4 <tail_icmp6_handle_ns+0xfb4>
    156e:      	movq	0x60(%rsp), %r15
    1573:      	leal	0x2a(%r15), %ebp
    1577:      	movl	$0x1c, %eax
    157c:      	leaq	0x48(%rsp), %rdi
    1581:      	leaq	0x10(%rsp), %rdx
    1586:      	movl	$0x8, %esi
    158b:      	movl	$0x8, %ecx
    1590:      	movl	%r12d, %r8d
    1593:      	callq	*%rax
    1595:      	movl	$0xb, %r9d
    159b:      	movq	%rbx, %rdi
    159e:      	movl	%ebp, %esi
    15a0:      	xorl	%edx, %edx
    15a2:      	movl	%eax, %ecx
    15a4:      	movl	$0x10, %r8d
    15aa:      	callq	*%r9
    15ad:      	testl	%eax, %eax
    15af:      	js	0x1998 <tail_icmp6_handle_ns+0xfa8>
    15b5:      	movq	0x88(%rsp), %rax
    15bd:      	movq	0x90(%rsp), %rcx
    15c5:      	movq	%rax, 0x50(%rsp)
    15ca:      	movq	%rcx, 0x58(%rsp)
    15cf:      	movq	(%r14), %rax
    15d2:      	movq	%rax, 0x68(%rsp)
    15d7:      	movl	$0x1a, %eax
    15dc:      	movq	%r15, %r12
    15df:      	addl	$0x8, %r15d
    15e3:      	leaq	0x78(%rsp), %rdx
    15e8:      	movq	%rbx, %rdi
    15eb:      	movl	%r15d, %esi
    15ee:      	movl	$0x10, %ecx
    15f3:      	callq	*%rax
    15f5:      	movl	%eax, %ecx
    15f7:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
    15fc:      	testl	%ecx, %ecx
    15fe:      	js	0x19a4 <tail_icmp6_handle_ns+0xfb4>
    1604:      	movl	$0x1a, %eax
    1609:      	addl	$0x18, %r12d
    160d:      	leaq	0xb8(%rsp), %rdx
    1615:      	movq	%rbx, %rdi
    1618:      	movq	%r12, %r14
    161b:      	movl	%r12d, %esi
    161e:      	movl	$0x10, %ecx
    1623:      	callq	*%rax
    1625:      	testl	%eax, %eax
    1627:      	js	0x199f <tail_icmp6_handle_ns+0xfaf>
    162d:      	movl	$0x9, %eax
    1632:      	leaq	0x50(%rsp), %rdx
    1637:      	movq	%rbx, %rdi
    163a:      	movl	%r15d, %esi
    163d:      	movl	$0x10, %ecx
    1642:      	xorl	%r8d, %r8d
    1645:      	callq	*%rax
    1647:      	testl	%eax, %eax
    1649:      	js	0x1852 <tail_icmp6_handle_ns+0xe62>
    164f:      	movl	$0x9, %eax
    1654:      	leaq	0x78(%rsp), %rdx
    1659:      	movq	%rbx, %rdi
    165c:      	movl	%r14d, %esi
    165f:      	movl	$0x10, %ecx
    1664:      	xorl	%r8d, %r8d
    1667:      	callq	*%rax
    1669:      	testl	%eax, %eax
    166b:      	js	0x1852 <tail_icmp6_handle_ns+0xe62>
    1671:      	movl	$0x1c, %eax
    1676:      	leaq	0x78(%rsp), %rdi
    167b:      	leaq	0x50(%rsp), %rdx
    1680:      	movl	$0x10, %esi
    1685:      	movl	$0x10, %ecx
    168a:      	xorl	%r8d, %r8d
    168d:      	callq	*%rax
    168f:      	movl	$0xb, %r14d
    1695:      	movq	%rbx, %rdi
    1698:      	movl	%ebp, %esi
    169a:      	xorl	%edx, %edx
    169c:      	movl	%eax, %ecx
    169e:      	movl	$0x10, %r8d
    16a4:      	callq	*%r14
    16a7:      	movl	%eax, %ecx
    16a9:      	movl	$0xffffff66, %eax       # imm = 0xFFFFFF66
    16ae:      	testl	%ecx, %ecx
    16b0:      	js	0x19a4 <tail_icmp6_handle_ns+0xfb4>
    16b6:      	movl	$0x1c, %eax
    16bb:      	leaq	0xb8(%rsp), %rdi
    16c3:      	leaq	0x78(%rsp), %rdx
    16c8:      	movl	$0x10, %esi
    16cd:      	movl	$0x10, %ecx
    16d2:      	xorl	%r8d, %r8d
    16d5:      	callq	*%rax
    16d7:      	movq	%rbx, %rdi
    16da:      	movl	%ebp, %esi
    16dc:      	xorl	%edx, %edx
    16de:      	movl	%eax, %ecx
    16e0:      	movl	$0x10, %r8d
    16e6:      	callq	*%r14
    16e9:      	movl	%eax, %ecx
    16eb:      	movl	$0xffffff66, %eax       # imm = 0xFFFFFF66
    16f0:      	testl	%ecx, %ecx
    16f2:      	js	0x19a4 <tail_icmp6_handle_ns+0xfb4>
    16f8:      	movl	$0x1a, %eax
    16fd:      	leaq	0x70(%rsp), %rdx
    1702:      	movq	%rbx, %rdi
    1705:      	movl	$0x6, %esi
    170a:      	movl	$0x6, %ecx
    170f:      	callq	*%rax
    1711:      	movl	%eax, %ecx
    1713:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
    1718:      	testl	%ecx, %ecx
    171a:      	js	0x19a4 <tail_icmp6_handle_ns+0xfb4>
    1720:      	movl	$0x9, %eax
    1725:      	leaq	0x70(%rsp), %rdx
    172a:      	movq	%rbx, %rdi
    172d:      	xorl	%esi, %esi
    172f:      	movl	$0x6, %ecx
    1734:      	xorl	%r8d, %r8d
    1737:      	callq	*%rax
    1739:      	testl	%eax, %eax
    173b:      	js	0x1852 <tail_icmp6_handle_ns+0xe62>
    1741:      	movl	$0x9, %eax
    1746:      	leaq	0x68(%rsp), %rdx
    174b:      	xorl	%ebp, %ebp
    174d:      	movq	%rbx, %rdi
    1750:      	movl	$0x6, %esi
    1755:      	movl	$0x6, %ecx
    175a:      	xorl	%r8d, %r8d
    175d:      	callq	*%rax
    175f:      	movl	%eax, %ecx
    1761:      	movl	$0xffffff73, %eax       # imm = 0xFFFFFF73
    1766:      	testl	%ecx, %ecx
    1768:      	js	0x19a4 <tail_icmp6_handle_ns+0xfb4>
    176e:      	movq	0x10(%rbx), %rax
    1772:      	testq	%rax, %rax
    1775:      	je	0x177d <tail_icmp6_handle_ns+0xd8d>
    1777:      	movl	0xe0(%rax), %ebp
    177d:      	movl	0x70(%rbx), %eax
    1780:      	movq	(%rip), %rcx            # 0x1787 <tail_icmp6_handle_ns+0xd97>
    1787:      	movl	(%rcx), %edx
    1789:      	cmpl	%edx, %eax
    178b:      	movw	$0x403, 0x18(%rsp)      # imm = 0x403
    1792:      	movq	(%rip), %rcx            # 0x1799 <tail_icmp6_handle_ns+0xda9>
    1799:      	movzwl	(%rcx), %ecx
    179c:      	movw	%cx, 0x1a(%rsp)
    17a1:      	cmovbl	%eax, %edx
    17a4:      	movl	0x98(%rbx), %ecx
    17aa:      	movl	%ecx, 0x1c(%rsp)
    17ae:      	movl	%eax, 0x20(%rsp)
    17b2:      	movw	%dx, 0x24(%rsp)
    17b7:      	movw	$0x1, 0x26(%rsp)
    17be:      	movl	%ebp, 0x28(%rsp)
    17c2:      	movl	$0x0, 0x2c(%rsp)
    17ca:      	movl	$0x19, %eax
    17cf:      	shlq	$0x20, %rdx
    17d3:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    17d8:      	orq	%rcx, %rdx
    17db:      	movq	(%rip), %rsi            # 0x17e2 <tail_icmp6_handle_ns+0xdf2>
    17e2:      	leaq	0x18(%rsp), %rcx
    17e7:      	movq	%rbx, %rdi
    17ea:      	movl	$0x18, %r8d
    17f0:      	callq	*%rax
    17f2:      	movq	0x10(%rbx), %rax
    17f6:      	testq	%rax, %rax
    17f9:      	je	0x19de <tail_icmp6_handle_ns+0xfee>
    17ff:      	movl	0xe0(%rax), %edi
    1805:      	jmp	0x19e0 <tail_icmp6_handle_ns+0xff0>
    180a:      	movq	$0x1, 0x18(%rsp)
    1813:      	movq	%r14, 0x20(%rsp)
    1818:      	movl	$0x2, %eax
    181d:      	movq	(%rip), %rdi            # 0x1824 <tail_icmp6_handle_ns+0xe34>
    1824:      	leaq	0x50(%rsp), %rsi
    1829:      	leaq	0x18(%rsp), %rdx
    182e:      	xorl	%ecx, %ecx
    1830:      	callq	*%rax
    1832:      	movl	$0xc, %eax
    1837:      	movq	(%rip), %rsi            # 0x183e <tail_icmp6_handle_ns+0xe4e>
    183e:      	movq	%rbx, %rdi
    1841:      	movl	$0x1, %edx
    1846:      	callq	*%rax
    1848:      	movl	$0x2, %eax
    184d:      	jmp	0x19ba <tail_icmp6_handle_ns+0xfca>
    1852:      	movl	$0xffffff73, %eax       # imm = 0xFFFFFF73
    1857:      	jmp	0x19a4 <tail_icmp6_handle_ns+0xfb4>
    185c:      	movl	$0x26, %eax
    1861:      	movl	0x70(%rbx), %esi
    1864:      	addl	$0x8, %esi
    1867:      	movq	%rbx, %rdi
    186a:      	xorl	%edx, %edx
    186c:      	callq	*%rax
    186e:      	movl	%eax, %ecx
    1870:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
    1875:      	testl	%ecx, %ecx
    1877:      	js	0x19a4 <tail_icmp6_handle_ns+0xfb4>
    187d:      	movq	0x50(%rbx), %rdx
    1881:      	movq	0xd0(%rbx), %rcx
    1888:      	leaq	0x36(%rcx), %rsi
    188c:      	cmpq	%rdx, %rsi
    188f:      	ja	0x19a4 <tail_icmp6_handle_ns+0xfb4>
    1895:      	movbew	0x12(%rcx), %si
    189b:      	addl	$0x8, %esi
    189e:      	movbew	%si, 0x12(%rcx)
    18a4:      	leaq	0x56(%rcx), %rsi
    18a8:      	cmpq	%rdx, %rsi
    18ab:      	ja	0x19a4 <tail_icmp6_handle_ns+0xfb4>
    18b1:      	movq	$0x0, 0x4e(%rcx)
    18b9:      	movl	$0x8000000, %r12d       # imm = 0x8000000
    18bf:      	jmp	0xb57 <tail_icmp6_handle_ns+0x167>
    18c4:      	movl	$0xffffff6a, %eax       # imm = 0xFFFFFF6A
    18c9:      	jmp	0x19a9 <tail_icmp6_handle_ns+0xfb9>
    18ce:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
    18d3:      	jmp	0x19a9 <tail_icmp6_handle_ns+0xfb9>
    18d8:      	movl	$0x26, %eax
    18dd:      	movl	0x70(%rbx), %esi
    18e0:      	addl	$0x8, %esi
    18e3:      	movq	%rbx, %rdi
    18e6:      	xorl	%edx, %edx
    18e8:      	callq	*%rax
    18ea:      	movl	%eax, %ecx
    18ec:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
    18f1:      	testl	%ecx, %ecx
    18f3:      	js	0x19a4 <tail_icmp6_handle_ns+0xfb4>
    18f9:      	movq	0x50(%rbx), %rdx
    18fd:      	movq	0xd0(%rbx), %rcx
    1904:      	leaq	0x36(%rcx), %rsi
    1908:      	cmpq	%rdx, %rsi
    190b:      	ja	0x19a4 <tail_icmp6_handle_ns+0xfb4>
    1911:      	movbew	0x12(%rcx), %si
    1917:      	addl	$0x8, %esi
    191a:      	movbew	%si, 0x12(%rcx)
    1920:      	leaq	0x56(%rcx), %rsi
    1924:      	cmpq	%rdx, %rsi
    1927:      	ja	0x19a4 <tail_icmp6_handle_ns+0xfb4>
    1929:      	movq	$0x0, 0x4e(%rcx)
    1931:      	movl	$0x8000000, %r12d       # imm = 0x8000000
    1937:      	jmp	0x1017 <tail_icmp6_handle_ns+0x627>
    193c:      	movl	$0x26, %eax
    1941:      	movl	0x70(%rbx), %esi
    1944:      	addl	$0x8, %esi
    1947:      	movq	%rbx, %rdi
    194a:      	xorl	%edx, %edx
    194c:      	callq	*%rax
    194e:      	movl	%eax, %ecx
    1950:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
    1955:      	testl	%ecx, %ecx
    1957:      	js	0x19a4 <tail_icmp6_handle_ns+0xfb4>
    1959:      	movq	0x50(%rbx), %rdx
    195d:      	movq	0xd0(%rbx), %rcx
    1964:      	leaq	0x36(%rcx), %rsi
    1968:      	cmpq	%rdx, %rsi
    196b:      	ja	0x19a4 <tail_icmp6_handle_ns+0xfb4>
    196d:      	movbew	0x12(%rcx), %si
    1973:      	addl	$0x8, %esi
    1976:      	movbew	%si, 0x12(%rcx)
    197c:      	leaq	0x56(%rcx), %rsi
    1980:      	cmpq	%rdx, %rsi
    1983:      	ja	0x19a4 <tail_icmp6_handle_ns+0xfb4>
    1985:      	movq	$0x0, 0x4e(%rcx)
    198d:      	movl	$0x8000000, %r12d       # imm = 0x8000000
    1993:      	jmp	0x1448 <tail_icmp6_handle_ns+0xa58>
    1998:      	movl	$0xffffff66, %eax       # imm = 0xFFFFFF66
    199d:      	jmp	0x19a4 <tail_icmp6_handle_ns+0xfb4>
    199f:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
    19a4:      	movl	0x3c(%rsp), %r12d
    19a9:      	testl	%eax, %eax
    19ab:      	js	0xf1e <tail_icmp6_handle_ns+0x52e>
    19b1:      	cmpl	$0x2, %eax
    19b4:      	je	0xf1e <tail_icmp6_handle_ns+0x52e>
    19ba:      	addq	$0xe8, %rsp
    19c1:      	popq	%rbx
    19c2:      	popq	%r12
    19c4:      	popq	%r13
    19c6:      	popq	%r14
    19c8:      	popq	%r15
    19ca:      	popq	%rbp
    19cb:      	retq
    19cc:      	xorl	%edi, %edi
    19ce:      	movl	$0x17, %eax
    19d3:      	jmp	0x19e5 <tail_icmp6_handle_ns+0xff5>
    19d5:      	xorl	%edi, %edi
    19d7:      	movl	$0x17, %eax
    19dc:      	jmp	0x19e5 <tail_icmp6_handle_ns+0xff5>
    19de:      	xorl	%edi, %edi
    19e0:      	movl	$0x17, %eax
    19e5:      	xorl	%esi, %esi
    19e7:      	callq	*%rax
    19e9:      	jmp	0x19a4 <tail_icmp6_handle_ns+0xfb4>

Disassembly of section tc/entry:

0000000000000000 <cil_from_container>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x28, %rsp
       e:      	movq	%rdi, %rbx
      11:      	movq	(%rip), %rax            # 0x18 <cil_from_container+0x18>
      18:      	movl	(%rax), %r15d
      1b:      	movq	0xd0(%rdi), %rax
      22:      	leaq	0xe(%rax), %rcx
      26:      	movl	$0xa6, %ebp
      2b:      	cmpq	0x50(%rdi), %rcx
      2f:      	ja	0x3e <cil_from_container+0x3e>
      31:      	cmpw	$0x6, 0xc(%rax)
      36:      	movl	$0x8b, %eax
      3b:      	cmovael	%eax, %ebp
      3e:      	movl	$0x0, 0x30(%rbx)
      45:      	movl	$0x0, 0x34(%rbx)
      4c:      	movl	$0x0, 0x38(%rbx)
      53:      	movl	$0x0, 0x3c(%rbx)
      5a:      	movl	$0x0, 0x40(%rbx)
      61:      	movq	(%rip), %r12            # 0x68 <cil_from_container+0x68>
      68:      	cmpb	$0x0, (%r12)
      6d:      	je	0xb3 <cil_from_container+0xb3>
      6f:      	movzbl	(%r12), %r13d
      74:      	movq	0x50(%rbx), %rdx
      78:      	movq	0xd0(%rbx), %rcx
      7f:      	leaq	0xe(%rcx), %rax
      83:      	cmpq	%rdx, %rax
      86:      	jbe	0x195 <cil_from_container+0x195>
      8c:      	movl	$0x0, 0x10(%rsp)
      94:      	movl	$0x1, %eax
      99:      	movq	(%rip), %rdi            # 0xa0 <cil_from_container+0xa0>
      a0:      	leaq	0x10(%rsp), %rsi
      a5:      	callq	*%rax
      a7:      	testq	%rax, %rax
      aa:      	je	0xb3 <cil_from_container+0xb3>
      ac:      	movq	$0x0, (%rax)
      b3:      	movw	$0x0, 0x7c(%rbx)
      b9:      	movq	(%rip), %rax            # 0xc0 <cil_from_container+0xc0>
      c0:      	movzwl	(%rax), %eax
      c3:      	movq	(%rip), %rax            # 0xca <cil_from_container+0xca>
      ca:      	movl	(%rax), %eax
      cc:      	cmpb	$0x0, (%r12)
      d1:      	je	0xee <cil_from_container+0xee>
      d3:      	movl	$0x0, 0x10(%rsp)
      db:      	movl	$0x1, %eax
      e0:      	movq	(%rip), %rdi            # 0xe7 <cil_from_container+0xe7>
      e7:      	leaq	0x10(%rsp), %rsi
      ec:      	callq	*%rax
      ee:      	movl	0x70(%rbx), %r14d
      f2:      	movl	%r15d, 0x30(%rbx)
      f6:      	movl	$0x0, 0x34(%rbx)
      fd:      	movl	%ebp, 0x38(%rbx)
     100:      	movabsq	$0x73c020200000000, %rax # imm = 0x73C020200000000
     10a:      	movq	%rax, 0x3c(%rbx)
     10e:      	movabsq	$0x2073c0200, %rax      # imm = 0x2073C0200
     118:      	movq	%rax, 0x8(%rsp)
     11d:      	movb	%bpl, 0x8(%rsp)
     122:      	movl	$0x1, %eax
     127:      	movq	(%rip), %rdi            # 0x12e <cil_from_container+0x12e>
     12e:      	leaq	0x8(%rsp), %rsi
     133:      	callq	*%rax
     135:      	testq	%rax, %rax
     138:      	je	0x143 <cil_from_container+0x143>
     13a:      	incq	(%rax)
     13d:      	addq	%r14, 0x8(%rax)
     141:      	jmp	0x16b <cil_from_container+0x16b>
     143:      	movq	$0x1, 0x10(%rsp)
     14c:      	movq	%r14, 0x18(%rsp)
     151:      	movl	$0x2, %eax
     156:      	movq	(%rip), %rdi            # 0x15d <cil_from_container+0x15d>
     15d:      	leaq	0x8(%rsp), %rsi
     162:      	leaq	0x10(%rsp), %rdx
     167:      	xorl	%ecx, %ecx
     169:      	callq	*%rax
     16b:      	movl	$0xc, %eax
     170:      	movq	(%rip), %rsi            # 0x177 <cil_from_container+0x177>
     177:      	movq	%rbx, %rdi
     17a:      	movl	$0x1, %edx
     17f:      	callq	*%rax
     181:      	movl	$0x2, %eax
     186:      	addq	$0x28, %rsp
     18a:      	popq	%rbx
     18b:      	popq	%r12
     18d:      	popq	%r13
     18f:      	popq	%r14
     191:      	popq	%r15
     193:      	popq	%rbp
     194:      	retq
     195:      	leaq	0x22(%rcx), %rsi
     199:      	cmpq	%rdx, %rsi
     19c:      	ja	0x8c <cil_from_container+0x8c>
     1a2:      	cmpw	$0x8, 0xc(%rcx)
     1a7:      	jne	0x8c <cil_from_container+0x8c>
     1ad:      	movzbl	(%rax), %r14d
     1b1:      	andl	$0xf, %r14d
     1b5:      	cmpb	$0x6, %r14b
     1b9:      	jae	0x1ea <cil_from_container+0x1ea>
     1bb:      	xorl	%r14d, %r14d
     1be:      	movl	$0x0, 0x10(%rsp)
     1c6:      	movl	$0x1, %eax
     1cb:      	movq	(%rip), %rdi            # 0x1d2 <cil_from_container+0x1d2>
     1d2:      	leaq	0x10(%rsp), %rsi
     1d7:      	callq	*%rax
     1d9:      	testq	%rax, %rax
     1dc:      	je	0xb3 <cil_from_container+0xb3>
     1e2:      	movq	%r14, (%rax)
     1e5:      	jmp	0xb3 <cil_from_container+0xb3>
     1ea:      	movl	$0x1a, %eax
     1ef:      	leaq	0x8(%rsp), %rdx
     1f4:      	movq	%rbx, %rdi
     1f7:      	movl	$0x22, %esi
     1fc:      	movl	$0x1, %ecx
     201:      	callq	*%rax
     203:      	testl	%eax, %eax
     205:      	js	0x8c <cil_from_container+0x8c>
     20b:      	movzbl	0x8(%rsp), %eax
     210:      	testl	%eax, %eax
     212:      	je	0x1bb <cil_from_container+0x1bb>
     214:      	movl	$0x23, %esi
     219:      	cmpl	$0x1, %eax
     21c:      	je	0x2a2 <cil_from_container+0x2a2>
     222:      	movl	$0x1a, %eax
     227:      	leaq	0x7(%rsp), %rdx
     22c:      	movq	%rbx, %rdi
     22f:      	movl	$0x23, %esi
     234:      	movl	$0x1, %ecx
     239:      	callq	*%rax
     23b:      	testl	%eax, %eax
     23d:      	js	0x8c <cil_from_container+0x8c>
     243:      	movl	$0x22, %esi
     248:      	cmpb	%r13b, 0x8(%rsp)
     24d:      	jne	0x29a <cil_from_container+0x29a>
     24f:      	movzbl	0x7(%rsp), %eax
     254:      	cmpl	$0xa, %eax
     257:      	je	0x346 <cil_from_container+0x346>
     25d:      	cmpl	$0x6, %eax
     260:      	je	0x31e <cil_from_container+0x31e>
     266:      	cmpl	$0x4, %eax
     269:      	jne	0x8c <cil_from_container+0x8c>
     26f:      	movl	$0x1a, %eax
     274:      	addl	$0x2, %esi
     277:      	leaq	0x10(%rsp), %rdx
     27c:      	movq	%rbx, %rdi
     27f:      	movl	$0x2, %ecx
     284:      	callq	*%rax
     286:      	xorl	%r14d, %r14d
     289:      	testl	%eax, %eax
     28b:      	movbew	0x10(%rsp), %cx
     292:      	movzwl	%cx, %ecx
     295:      	jmp	0x369 <cil_from_container+0x369>
     29a:      	movzbl	0x7(%rsp), %esi
     29f:      	addl	$0x22, %esi
     2a2:      	leal	0x22(,%r14,4), %r14d
     2aa:      	cmpl	%r14d, %esi
     2ad:      	jae	0x1bb <cil_from_container+0x1bb>
     2b3:      	movl	$0x1a, %eax
     2b8:      	leaq	0x8(%rsp), %rdx
     2bd:      	movq	%rbx, %rdi
     2c0:      	movq	%rsi, 0x20(%rsp)
     2c5:      	movl	$0x1, %ecx
     2ca:      	callq	*%rax
     2cc:      	testl	%eax, %eax
     2ce:      	js	0x8c <cil_from_container+0x8c>
     2d4:      	movzbl	0x8(%rsp), %eax
     2d9:      	testl	%eax, %eax
     2db:      	movq	0x20(%rsp), %rsi
     2e0:      	je	0x1bb <cil_from_container+0x1bb>
     2e6:      	cmpl	$0x1, %eax
     2e9:      	je	0x384 <cil_from_container+0x384>
     2ef:      	movl	$0x1a, %eax
     2f4:      	incl	%esi
     2f6:      	leaq	0x7(%rsp), %rdx
     2fb:      	movq	%rbx, %rdi
     2fe:      	movl	$0x1, %ecx
     303:      	callq	*%rax
     305:      	testl	%eax, %eax
     307:      	js	0x8c <cil_from_container+0x8c>
     30d:      	cmpb	%r13b, 0x8(%rsp)
     312:      	jne	0x37a <cil_from_container+0x37a>
     314:      	movq	0x20(%rsp), %rsi
     319:      	jmp	0x24f <cil_from_container+0x24f>
     31e:      	movl	$0x1a, %eax
     323:      	addl	$0x2, %esi
     326:      	leaq	0x10(%rsp), %rdx
     32b:      	movq	%rbx, %rdi
     32e:      	movl	$0x4, %ecx
     333:      	callq	*%rax
     335:      	xorl	%ecx, %ecx
     337:      	testl	%eax, %eax
     339:      	movbel	0x10(%rsp), %r14d
     340:      	cmovsl	%ecx, %r14d
     344:      	jmp	0x36d <cil_from_container+0x36d>
     346:      	movl	$0x1a, %eax
     34b:      	addl	$0x2, %esi
     34e:      	leaq	0x10(%rsp), %rdx
     353:      	movq	%rbx, %rdi
     356:      	movl	$0x8, %ecx
     35b:      	callq	*%rax
     35d:      	xorl	%r14d, %r14d
     360:      	testl	%eax, %eax
     362:      	movbeq	0x10(%rsp), %rcx
     369:      	cmovnsq	%rcx, %r14
     36d:      	testl	%eax, %eax
     36f:      	jns	0x1be <cil_from_container+0x1be>
     375:      	jmp	0x8c <cil_from_container+0x8c>
     37a:      	movzbl	0x7(%rsp), %eax
     37f:      	movq	0x20(%rsp), %rsi
     384:      	addl	%eax, %esi
     386:      	cmpl	%r14d, %esi
     389:      	jae	0x1bb <cil_from_container+0x1bb>
     38f:      	movl	$0x1a, %eax
     394:      	leaq	0x8(%rsp), %rdx
     399:      	movq	%rbx, %rdi
     39c:      	movq	%rsi, %r14
     39f:      	movl	$0x1, %ecx
     3a4:      	callq	*%rax
     3a6:      	testl	%eax, %eax
     3a8:      	js	0x8c <cil_from_container+0x8c>
     3ae:      	cmpb	$0x2, 0x8(%rsp)
     3b3:      	jb	0x1bb <cil_from_container+0x1bb>
     3b9:      	movl	$0x1a, %eax
     3be:      	leal	0x1(%r14), %esi
     3c2:      	leaq	0x7(%rsp), %rdx
     3c7:      	movq	%rbx, %rdi
     3ca:      	movl	$0x1, %ecx
     3cf:      	callq	*%rax
     3d1:      	testl	%eax, %eax
     3d3:      	js	0x8c <cil_from_container+0x8c>
     3d9:      	cmpb	%r13b, 0x8(%rsp)
     3de:      	movq	%r14, %rsi
     3e1:      	jne	0x1bb <cil_from_container+0x1bb>
     3e7:      	jmp	0x24f <cil_from_container+0x24f>
     3ec:      	nopl	(%rax)

00000000000003f0 <cil_lxc_policy>:
     3f0:      	pushq	%r14
     3f2:      	pushq	%rbx
     3f3:      	subq	$0x18, %rsp
     3f7:      	movq	%rdi, %rbx
     3fa:      	movq	(%rip), %rax            # 0x401 <cil_lxc_policy+0x11>
     401:      	movl	(%rax), %ecx
     403:      	movq	0xd0(%rdi), %rdx
     40a:      	leaq	0xe(%rdx), %rsi
     40e:      	movl	$0xa6, %eax
     413:      	cmpq	0x50(%rdi), %rsi
     417:      	ja	0x426 <cil_lxc_policy+0x36>
     419:      	cmpw	$0x6, 0xc(%rdx)
     41e:      	movl	$0x8b, %edx
     423:      	cmovael	%edx, %eax
     426:      	movq	(%rip), %rdx            # 0x42d <cil_lxc_policy+0x3d>
     42d:      	movzwl	(%rdx), %edx
     430:      	movl	%ecx, 0x34(%rbx)
     433:      	movl	%eax, 0x38(%rbx)
     436:      	movl	%edx, 0x3c(%rbx)
     439:      	movl	$0x9e80202, 0x40(%rbx)  # imm = 0x9E80202
     440:      	movl	0x70(%rbx), %r14d
     444:      	movabsq	$0x209e80100, %rcx      # imm = 0x209E80100
     44e:      	movq	%rcx, (%rsp)
     452:      	movb	%al, (%rsp)
     455:      	movl	$0x1, %eax
     45a:      	movq	(%rip), %rdi            # 0x461 <cil_lxc_policy+0x71>
     461:      	movq	%rsp, %rsi
     464:      	callq	*%rax
     466:      	testq	%rax, %rax
     469:      	je	0x474 <cil_lxc_policy+0x84>
     46b:      	incq	(%rax)
     46e:      	addq	%r14, 0x8(%rax)
     472:      	jmp	0x49a <cil_lxc_policy+0xaa>
     474:      	movq	$0x1, 0x8(%rsp)
     47d:      	movq	%r14, 0x10(%rsp)
     482:      	movl	$0x2, %eax
     487:      	movq	(%rip), %rdi            # 0x48e <cil_lxc_policy+0x9e>
     48e:      	movq	%rsp, %rsi
     491:      	leaq	0x8(%rsp), %rdx
     496:      	xorl	%ecx, %ecx
     498:      	callq	*%rax
     49a:      	movl	$0xc, %eax
     49f:      	movq	(%rip), %rsi            # 0x4a6 <cil_lxc_policy+0xb6>
     4a6:      	movq	%rbx, %rdi
     4a9:      	movl	$0x1, %edx
     4ae:      	callq	*%rax
     4b0:      	movl	$0x2, %eax
     4b5:      	addq	$0x18, %rsp
     4b9:      	popq	%rbx
     4ba:      	popq	%r14
     4bc:      	retq
     4bd:      	nopl	(%rax)

00000000000004c0 <cil_lxc_policy_egress>:
     4c0:      	xorl	%eax, %eax
     4c2:      	retq
     4c3:      	nopw	%cs:(%rax,%rax)

00000000000004d0 <cil_to_container>:
     4d0:      	pushq	%rbp
     4d1:      	pushq	%r15
     4d3:      	pushq	%r14
     4d5:      	pushq	%r13
     4d7:      	pushq	%r12
     4d9:      	pushq	%rbx
     4da:      	subq	$0x28, %rsp
     4de:      	movq	%rdi, %rbx
     4e1:      	movabsq	$0x20a510103, %r15      # imm = 0x20A510103
     4eb:      	movq	(%rip), %rax            # 0x4f2 <cil_to_container+0x22>
     4f2:      	movl	(%rax), %ebp
     4f4:      	movq	0xd0(%rdi), %rax
     4fb:      	leaq	0xe(%rax), %rcx
     4ff:      	movl	$0xa6, %r12d
     505:      	xorl	%r13d, %r13d
     508:      	cmpq	0x50(%rdi), %rcx
     50c:      	ja	0x840 <cil_to_container+0x370>
     512:      	cmpw	$0x6, 0xc(%rax)
     517:      	jb	0x840 <cil_to_container+0x370>
     51d:      	movl	$0x0, 0x30(%rbx)
     524:      	movl	$0x0, 0x34(%rbx)
     52b:      	movl	$0x0, 0x38(%rbx)
     532:      	movl	$0x0, 0x3c(%rbx)
     539:      	movl	$0x0, 0x40(%rbx)
     540:      	movq	(%rip), %rax            # 0x547 <cil_to_container+0x77>
     547:      	cmpb	$0x0, (%rax)
     54a:      	je	0x58f <cil_to_container+0xbf>
     54c:      	movzbl	(%rax), %r13d
     550:      	movq	0x50(%rbx), %rdx
     554:      	movq	0xd0(%rbx), %rcx
     55b:      	leaq	0xe(%rcx), %rax
     55f:      	cmpq	%rdx, %rax
     562:      	jbe	0x685 <cil_to_container+0x1b5>
     568:      	movl	$0x0, 0x10(%rsp)
     570:      	movl	$0x1, %eax
     575:      	movq	(%rip), %rdi            # 0x57c <cil_to_container+0xac>
     57c:      	leaq	0x10(%rsp), %rsi
     581:      	callq	*%rax
     583:      	testq	%rax, %rax
     586:      	je	0x58f <cil_to_container+0xbf>
     588:      	movq	$0x0, (%rax)
     58f:      	movl	0xa8(%rbx), %r14d
     596:      	movl	%r14d, %eax
     599:      	andl	$0xf00, %eax            # imm = 0xF00
     59e:      	addl	$0xfffff600, %eax       # imm = 0xFFFFF600
     5a3:      	shrl	$0x8, %eax
     5a6:      	cmpl	$0x1, %eax
     5a9:      	jg	0x61b <cil_to_container+0x14b>
     5ab:      	testl	%eax, %eax
     5ad:      	je	0x6e6 <cil_to_container+0x216>
     5b3:      	cmpl	$0x1, %eax
     5b6:      	jne	0x6de <cil_to_container+0x20e>
     5bc:      	movzbl	%r14b, %ecx
     5c0:      	movq	(%rip), %rax            # 0x5c7 <cil_to_container+0xf7>
     5c7:      	movl	(%rax), %edx
     5c9:      	movl	$0x7fffff00, %esi       # imm = 0x7FFFFF00
     5ce:      	bzhil	%edx, %esi, %edx
     5d3:      	movl	(%rax), %esi
     5d5:      	negb	%sil
     5d8:      	shlxl	%esi, %edx, %edx
     5dd:      	andl	%r14d, %edx
     5e0:      	movl	(%rax), %esi
     5e2:      	negb	%sil
     5e5:      	shrxl	%esi, %edx, %edx
     5ea:      	orl	%ecx, %edx
     5ec:      	movl	%r14d, %ecx
     5ef:      	shrl	$0x10, %ecx
     5f2:      	movl	(%rax), %esi
     5f4:      	movb	$0x18, %dil
     5f7:      	movb	$0x18, %r8b
     5fa:      	subb	%sil, %r8b
     5fd:      	bzhil	%r8d, %ecx, %ecx
     602:      	movl	(%rax), %eax
     604:      	subb	%al, %dil
     607:      	shlxl	%edi, %edx, %r13d
     60c:      	orl	%ecx, %r13d
     60f:      	orb	$0x2, 0x86(%rbx)
     616:      	jmp	0x748 <cil_to_container+0x278>
     61b:      	cmpl	$0x2, %eax
     61e:      	je	0x742 <cil_to_container+0x272>
     624:      	cmpl	$0x5, %eax
     627:      	jne	0x6de <cil_to_container+0x20e>
     62d:      	movzbl	%r14b, %ecx
     631:      	movq	(%rip), %rax            # 0x638 <cil_to_container+0x168>
     638:      	movl	(%rax), %edx
     63a:      	movl	$0x7fffff00, %esi       # imm = 0x7FFFFF00
     63f:      	bzhil	%edx, %esi, %edx
     644:      	movl	(%rax), %esi
     646:      	negb	%sil
     649:      	shlxl	%esi, %edx, %edx
     64e:      	andl	%r14d, %edx
     651:      	movl	(%rax), %esi
     653:      	negb	%sil
     656:      	shrxl	%esi, %edx, %edx
     65b:      	orl	%ecx, %edx
     65d:      	movl	%r14d, %ecx
     660:      	shrl	$0x10, %ecx
     663:      	movl	(%rax), %esi
     665:      	movb	$0x18, %dil
     668:      	movb	$0x18, %r8b
     66b:      	subb	%sil, %r8b
     66e:      	bzhil	%r8d, %ecx, %ecx
     673:      	movl	(%rax), %eax
     675:      	subb	%al, %dil
     678:      	shlxl	%edi, %edx, %r13d
     67d:      	orl	%ecx, %r13d
     680:      	jmp	0x748 <cil_to_container+0x278>
     685:      	leaq	0x22(%rcx), %rsi
     689:      	cmpq	%rdx, %rsi
     68c:      	ja	0x568 <cil_to_container+0x98>
     692:      	cmpw	$0x8, 0xc(%rcx)
     697:      	jne	0x568 <cil_to_container+0x98>
     69d:      	movzbl	(%rax), %r14d
     6a1:      	andl	$0xf, %r14d
     6a5:      	cmpb	$0x6, %r14b
     6a9:      	jae	0x8e7 <cil_to_container+0x417>
     6af:      	xorl	%r14d, %r14d
     6b2:      	movl	$0x0, 0x10(%rsp)
     6ba:      	movl	$0x1, %eax
     6bf:      	movq	(%rip), %rdi            # 0x6c6 <cil_to_container+0x1f6>
     6c6:      	leaq	0x10(%rsp), %rsi
     6cb:      	callq	*%rax
     6cd:      	testq	%rax, %rax
     6d0:      	je	0x58f <cil_to_container+0xbf>
     6d6:      	movq	%r14, (%rax)
     6d9:      	jmp	0x58f <cil_to_container+0xbf>
     6de:      	movl	$0x2, %r13d
     6e4:      	jmp	0x748 <cil_to_container+0x278>
     6e6:      	movzbl	%r14b, %ecx
     6ea:      	movq	(%rip), %rax            # 0x6f1 <cil_to_container+0x221>
     6f1:      	movl	(%rax), %edx
     6f3:      	movl	$0x7fffff00, %esi       # imm = 0x7FFFFF00
     6f8:      	bzhil	%edx, %esi, %edx
     6fd:      	movl	(%rax), %esi
     6ff:      	negb	%sil
     702:      	shlxl	%esi, %edx, %edx
     707:      	andl	%r14d, %edx
     70a:      	movl	(%rax), %esi
     70c:      	negb	%sil
     70f:      	shrxl	%esi, %edx, %edx
     714:      	orl	%ecx, %edx
     716:      	movl	%r14d, %ecx
     719:      	shrl	$0x10, %ecx
     71c:      	movl	(%rax), %esi
     71e:      	movb	$0x18, %dil
     721:      	movb	$0x18, %r8b
     724:      	subb	%sil, %r8b
     727:      	bzhil	%r8d, %ecx, %ecx
     72c:      	movl	(%rax), %eax
     72e:      	subb	%al, %dil
     731:      	shlxl	%edi, %edx, %r13d
     736:      	orl	%ecx, %r13d
     739:      	orb	$0x1, 0x86(%rbx)
     740:      	jmp	0x748 <cil_to_container+0x278>
     742:      	movl	$0x1, %r13d
     748:      	movl	$0x0, 0xa8(%rbx)
     752:      	movw	$0x3d02, 0x10(%rsp)     # imm = 0x3D02
     759:      	movq	(%rip), %r12            # 0x760 <cil_to_container+0x290>
     760:      	movzwl	(%r12), %eax
     765:      	movw	%ax, 0x12(%rsp)
     76a:      	movl	0x98(%rbx), %eax
     770:      	movl	%eax, 0x14(%rsp)
     774:      	movl	%r13d, 0x18(%rsp)
     779:      	movq	$0x0, 0x1c(%rsp)
     782:      	movl	$0x19, %eax
     787:      	movq	(%rip), %rsi            # 0x78e <cil_to_container+0x2be>
     78e:      	leaq	0x10(%rsp), %rcx
     793:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     798:      	movq	%rbx, %rdi
     79b:      	movl	$0x14, %r8d
     7a1:      	callq	*%rax
     7a3:      	movzwl	(%r12), %eax
     7a8:      	movq	(%rip), %rax            # 0x7af <cil_to_container+0x2df>
     7af:      	movl	(%rax), %eax
     7b1:      	andl	$0xe00, %r14d           # imm = 0xE00
     7b8:      	movq	(%rip), %rax            # 0x7bf <cil_to_container+0x2ef>
     7bf:      	cmpb	$0x0, (%rax)
     7c2:      	je	0x7df <cil_to_container+0x30f>
     7c4:      	movl	$0x0, 0x10(%rsp)
     7cc:      	movl	$0x1, %eax
     7d1:      	movq	(%rip), %rdi            # 0x7d8 <cil_to_container+0x308>
     7d8:      	leaq	0x10(%rsp), %rsi
     7dd:      	callq	*%rax
     7df:      	movl	$0x8b, %r12d
     7e5:      	cmpl	$0xa00, %r14d           # imm = 0xA00
     7ec:      	je	0x840 <cil_to_container+0x370>
     7ee:      	movl	0x70(%rbx), %r14d
     7f2:      	movq	%r15, 0x8(%rsp)
     7f7:      	movl	$0x1, %eax
     7fc:      	movq	(%rip), %rdi            # 0x803 <cil_to_container+0x333>
     803:      	leaq	0x8(%rsp), %rsi
     808:      	callq	*%rax
     80a:      	testq	%rax, %rax
     80d:      	je	0x818 <cil_to_container+0x348>
     80f:      	incq	(%rax)
     812:      	addq	%r14, 0x8(%rax)
     816:      	jmp	0x840 <cil_to_container+0x370>
     818:      	movq	$0x1, 0x10(%rsp)
     821:      	movq	%r14, 0x18(%rsp)
     826:      	movl	$0x2, %eax
     82b:      	movq	(%rip), %rdi            # 0x832 <cil_to_container+0x362>
     832:      	leaq	0x8(%rsp), %rsi
     837:      	leaq	0x10(%rsp), %rdx
     83c:      	xorl	%ecx, %ecx
     83e:      	callq	*%rax
     840:      	movq	(%rip), %rax            # 0x847 <cil_to_container+0x377>
     847:      	movzwl	(%rax), %eax
     84a:      	movl	%r13d, 0x30(%rbx)
     84e:      	movl	%ebp, 0x34(%rbx)
     851:      	movl	%r12d, 0x38(%rbx)
     855:      	movl	%eax, 0x3c(%rbx)
     858:      	movl	$0xa850202, 0x40(%rbx)  # imm = 0xA850202
     85f:      	movl	0x70(%rbx), %r14d
     863:      	addq	$0x33fffd, %r15         # imm = 0x33FFFD
     86a:      	movq	%r15, 0x8(%rsp)
     86f:      	movb	%r12b, 0x8(%rsp)
     874:      	movl	$0x1, %eax
     879:      	movq	(%rip), %rdi            # 0x880 <cil_to_container+0x3b0>
     880:      	leaq	0x8(%rsp), %rsi
     885:      	callq	*%rax
     887:      	testq	%rax, %rax
     88a:      	je	0x895 <cil_to_container+0x3c5>
     88c:      	incq	(%rax)
     88f:      	addq	%r14, 0x8(%rax)
     893:      	jmp	0x8bd <cil_to_container+0x3ed>
     895:      	movq	$0x1, 0x10(%rsp)
     89e:      	movq	%r14, 0x18(%rsp)
     8a3:      	movl	$0x2, %eax
     8a8:      	movq	(%rip), %rdi            # 0x8af <cil_to_container+0x3df>
     8af:      	leaq	0x8(%rsp), %rsi
     8b4:      	leaq	0x10(%rsp), %rdx
     8b9:      	xorl	%ecx, %ecx
     8bb:      	callq	*%rax
     8bd:      	movl	$0xc, %eax
     8c2:      	movq	(%rip), %rsi            # 0x8c9 <cil_to_container+0x3f9>
     8c9:      	movq	%rbx, %rdi
     8cc:      	movl	$0x1, %edx
     8d1:      	callq	*%rax
     8d3:      	movl	$0x2, %eax
     8d8:      	addq	$0x28, %rsp
     8dc:      	popq	%rbx
     8dd:      	popq	%r12
     8df:      	popq	%r13
     8e1:      	popq	%r14
     8e3:      	popq	%r15
     8e5:      	popq	%rbp
     8e6:      	retq
     8e7:      	movl	$0x1a, %eax
     8ec:      	leaq	0x8(%rsp), %rdx
     8f1:      	movq	%rbx, %rdi
     8f4:      	movl	$0x22, %esi
     8f9:      	movl	$0x1, %ecx
     8fe:      	callq	*%rax
     900:      	testl	%eax, %eax
     902:      	js	0x568 <cil_to_container+0x98>
     908:      	movzbl	0x8(%rsp), %eax
     90d:      	testl	%eax, %eax
     90f:      	je	0x6af <cil_to_container+0x1df>
     915:      	movl	$0x23, %r12d
     91b:      	cmpl	$0x1, %eax
     91e:      	je	0x9ab <cil_to_container+0x4db>
     924:      	movl	$0x1a, %eax
     929:      	leaq	0x7(%rsp), %rdx
     92e:      	movq	%rbx, %rdi
     931:      	movl	$0x23, %esi
     936:      	movl	$0x1, %ecx
     93b:      	callq	*%rax
     93d:      	testl	%eax, %eax
     93f:      	js	0x568 <cil_to_container+0x98>
     945:      	movl	$0x22, %r12d
     94b:      	cmpb	%r13b, 0x8(%rsp)
     950:      	jne	0x9a1 <cil_to_container+0x4d1>
     952:      	movzbl	0x7(%rsp), %eax
     957:      	cmpl	$0xa, %eax
     95a:      	je	0xab1 <cil_to_container+0x5e1>
     960:      	cmpl	$0x6, %eax
     963:      	je	0xa85 <cil_to_container+0x5b5>
     969:      	cmpl	$0x4, %eax
     96c:      	jne	0x568 <cil_to_container+0x98>
     972:      	movl	$0x1a, %eax
     977:      	addl	$0x2, %r12d
     97b:      	leaq	0x10(%rsp), %rdx
     980:      	movq	%rbx, %rdi
     983:      	movl	%r12d, %esi
     986:      	movl	$0x2, %ecx
     98b:      	callq	*%rax
     98d:      	xorl	%r14d, %r14d
     990:      	testl	%eax, %eax
     992:      	movbew	0x10(%rsp), %cx
     999:      	movzwl	%cx, %ecx
     99c:      	jmp	0xad8 <cil_to_container+0x608>
     9a1:      	movzbl	0x7(%rsp), %r12d
     9a7:      	addl	$0x22, %r12d
     9ab:      	leal	0x22(,%r14,4), %r14d
     9b3:      	cmpl	%r14d, %r12d
     9b6:      	jae	0x6af <cil_to_container+0x1df>
     9bc:      	movl	$0x1a, %eax
     9c1:      	leaq	0x8(%rsp), %rdx
     9c6:      	movq	%rbx, %rdi
     9c9:      	movl	%r12d, %esi
     9cc:      	movl	$0x1, %ecx
     9d1:      	callq	*%rax
     9d3:      	testl	%eax, %eax
     9d5:      	js	0x568 <cil_to_container+0x98>
     9db:      	movzbl	0x8(%rsp), %eax
     9e0:      	testl	%eax, %eax
     9e2:      	je	0x6af <cil_to_container+0x1df>
     9e8:      	cmpl	$0x1, %eax
     9eb:      	je	0xa1e <cil_to_container+0x54e>
     9ed:      	movl	$0x1a, %eax
     9f2:      	leal	0x1(%r12), %esi
     9f7:      	leaq	0x7(%rsp), %rdx
     9fc:      	movq	%rbx, %rdi
     9ff:      	movl	$0x1, %ecx
     a04:      	callq	*%rax
     a06:      	testl	%eax, %eax
     a08:      	js	0x568 <cil_to_container+0x98>
     a0e:      	cmpb	%r13b, 0x8(%rsp)
     a13:      	je	0x952 <cil_to_container+0x482>
     a19:      	movzbl	0x7(%rsp), %eax
     a1e:      	addl	%eax, %r12d
     a21:      	cmpl	%r14d, %r12d
     a24:      	jae	0x6af <cil_to_container+0x1df>
     a2a:      	movl	$0x1a, %eax
     a2f:      	leaq	0x8(%rsp), %rdx
     a34:      	movq	%rbx, %rdi
     a37:      	movl	%r12d, %esi
     a3a:      	movl	$0x1, %ecx
     a3f:      	callq	*%rax
     a41:      	testl	%eax, %eax
     a43:      	js	0x568 <cil_to_container+0x98>
     a49:      	cmpb	$0x2, 0x8(%rsp)
     a4e:      	jb	0x6af <cil_to_container+0x1df>
     a54:      	movl	$0x1a, %eax
     a59:      	leal	0x1(%r12), %esi
     a5e:      	leaq	0x7(%rsp), %rdx
     a63:      	movq	%rbx, %rdi
     a66:      	movl	$0x1, %ecx
     a6b:      	callq	*%rax
     a6d:      	testl	%eax, %eax
     a6f:      	js	0x568 <cil_to_container+0x98>
     a75:      	cmpb	%r13b, 0x8(%rsp)
     a7a:      	jne	0x6af <cil_to_container+0x1df>
     a80:      	jmp	0x952 <cil_to_container+0x482>
     a85:      	movl	$0x1a, %eax
     a8a:      	addl	$0x2, %r12d
     a8e:      	leaq	0x10(%rsp), %rdx
     a93:      	movq	%rbx, %rdi
     a96:      	movl	%r12d, %esi
     a99:      	movl	$0x4, %ecx
     a9e:      	callq	*%rax
     aa0:      	xorl	%ecx, %ecx
     aa2:      	testl	%eax, %eax
     aa4:      	movbel	0x10(%rsp), %r14d
     aab:      	cmovsl	%ecx, %r14d
     aaf:      	jmp	0xadc <cil_to_container+0x60c>
     ab1:      	movl	$0x1a, %eax
     ab6:      	addl	$0x2, %r12d
     aba:      	leaq	0x10(%rsp), %rdx
     abf:      	movq	%rbx, %rdi
     ac2:      	movl	%r12d, %esi
     ac5:      	movl	$0x8, %ecx
     aca:      	callq	*%rax
     acc:      	xorl	%r14d, %r14d
     acf:      	testl	%eax, %eax
     ad1:      	movbeq	0x10(%rsp), %rcx
     ad8:      	cmovnsq	%rcx, %r14
     adc:      	testl	%eax, %eax
     ade:      	jns	0x6b2 <cil_to_container+0x1e2>
     ae4:      	jmp	0x568 <cil_to_container+0x98>
