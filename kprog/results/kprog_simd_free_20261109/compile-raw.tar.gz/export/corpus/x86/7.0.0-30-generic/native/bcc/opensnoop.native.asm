
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/bcc/opensnoop.native.o:	file format elf64-x86-64

Disassembly of section tracepoint/syscalls/sys_enter_open:

0000000000000000 <tracepoint__syscalls__sys_enter_open>:
       0:      	pushq	%r14
       2:      	pushq	%rbx
       3:      	subq	$0x18, %rsp
       7:      	movq	%rdi, %rbx
       a:      	callq	0xf <tracepoint__syscalls__sys_enter_open+0xf>
       f:      	movl	%eax, 0x4(%rsp)
      13:      	movq	(%rip), %rcx            # 0x1a <tracepoint__syscalls__sys_enter_open+0x1a>
      1a:      	cmpl	$0x0, (%rcx)
      1d:      	je	0x2c <tracepoint__syscalls__sys_enter_open+0x2c>
      1f:      	movq	%rax, %rdx
      22:      	shrq	$0x20, %rdx
      26:      	movl	(%rcx), %ecx
      28:      	cmpl	%edx, %ecx
      2a:      	jne	0x8a <tracepoint__syscalls__sys_enter_open+0x8a>
      2c:      	movq	(%rip), %rcx            # 0x33 <tracepoint__syscalls__sys_enter_open+0x33>
      33:      	cmpl	$0x0, (%rcx)
      36:      	je	0x3e <tracepoint__syscalls__sys_enter_open+0x3e>
      38:      	movl	(%rcx), %ecx
      3a:      	cmpl	%eax, %ecx
      3c:      	jne	0x8a <tracepoint__syscalls__sys_enter_open+0x8a>
      3e:      	movq	(%rip), %r14            # 0x45 <tracepoint__syscalls__sys_enter_open+0x45>
      45:      	movl	(%r14), %eax
      48:      	cmpl	$-0x1, %eax
      4b:      	je	0x59 <tracepoint__syscalls__sys_enter_open+0x59>
      4d:      	callq	0x52 <tracepoint__syscalls__sys_enter_open+0x52>
      52:      	movl	(%r14), %ecx
      55:      	cmpl	%eax, %ecx
      57:      	jne	0x8a <tracepoint__syscalls__sys_enter_open+0x8a>
      59:      	movq	$0x0, 0x10(%rsp)
      62:      	movq	0x10(%rbx), %rax
      66:      	movq	%rax, 0x8(%rsp)
      6b:      	movl	0x18(%rbx), %eax
      6e:      	movl	%eax, 0x10(%rsp)
      72:      	movq	(%rip), %rdi            # 0x79 <tracepoint__syscalls__sys_enter_open+0x79>
      79:      	leaq	0x4(%rsp), %rsi
      7e:      	leaq	0x8(%rsp), %rdx
      83:      	xorl	%ecx, %ecx
      85:      	callq	0x8a <tracepoint__syscalls__sys_enter_open+0x8a>
      8a:      	xorl	%eax, %eax
      8c:      	addq	$0x18, %rsp
      90:      	popq	%rbx
      91:      	popq	%r14
      93:      	retq

Disassembly of section tracepoint/syscalls/sys_enter_openat:

0000000000000000 <tracepoint__syscalls__sys_enter_openat>:
       0:      	pushq	%r14
       2:      	pushq	%rbx
       3:      	subq	$0x18, %rsp
       7:      	movq	%rdi, %rbx
       a:      	callq	0xf <tracepoint__syscalls__sys_enter_openat+0xf>
       f:      	movl	%eax, 0x4(%rsp)
      13:      	movq	(%rip), %rcx            # 0x1a <tracepoint__syscalls__sys_enter_openat+0x1a>
      1a:      	cmpl	$0x0, (%rcx)
      1d:      	je	0x2c <tracepoint__syscalls__sys_enter_openat+0x2c>
      1f:      	movq	%rax, %rdx
      22:      	shrq	$0x20, %rdx
      26:      	movl	(%rcx), %ecx
      28:      	cmpl	%edx, %ecx
      2a:      	jne	0x8a <tracepoint__syscalls__sys_enter_openat+0x8a>
      2c:      	movq	(%rip), %rcx            # 0x33 <tracepoint__syscalls__sys_enter_openat+0x33>
      33:      	cmpl	$0x0, (%rcx)
      36:      	je	0x3e <tracepoint__syscalls__sys_enter_openat+0x3e>
      38:      	movl	(%rcx), %ecx
      3a:      	cmpl	%eax, %ecx
      3c:      	jne	0x8a <tracepoint__syscalls__sys_enter_openat+0x8a>
      3e:      	movq	(%rip), %r14            # 0x45 <tracepoint__syscalls__sys_enter_openat+0x45>
      45:      	movl	(%r14), %eax
      48:      	cmpl	$-0x1, %eax
      4b:      	je	0x59 <tracepoint__syscalls__sys_enter_openat+0x59>
      4d:      	callq	0x52 <tracepoint__syscalls__sys_enter_openat+0x52>
      52:      	movl	(%r14), %ecx
      55:      	cmpl	%eax, %ecx
      57:      	jne	0x8a <tracepoint__syscalls__sys_enter_openat+0x8a>
      59:      	movq	$0x0, 0x10(%rsp)
      62:      	movq	0x18(%rbx), %rax
      66:      	movq	%rax, 0x8(%rsp)
      6b:      	movl	0x20(%rbx), %eax
      6e:      	movl	%eax, 0x10(%rsp)
      72:      	movq	(%rip), %rdi            # 0x79 <tracepoint__syscalls__sys_enter_openat+0x79>
      79:      	leaq	0x4(%rsp), %rsi
      7e:      	leaq	0x8(%rsp), %rdx
      83:      	xorl	%ecx, %ecx
      85:      	callq	0x8a <tracepoint__syscalls__sys_enter_openat+0x8a>
      8a:      	xorl	%eax, %eax
      8c:      	addq	$0x18, %rsp
      90:      	popq	%rbx
      91:      	popq	%r14
      93:      	retq

Disassembly of section tracepoint/syscalls/sys_exit_open:

0000000000000000 <tracepoint__syscalls__sys_exit_open>:
       0:      	pushq	%rbp
       1:      	pushq	%r14
       3:      	pushq	%rbx
       4:      	subq	$0x160, %rsp            # imm = 0x160
       b:      	movq	%rdi, %rbx
       e:      	leaq	0x28(%rsp), %rdi
      13:      	movl	$0x138, %edx            # imm = 0x138
      18:      	xorl	%esi, %esi
      1a:      	callq	0x1f <tracepoint__syscalls__sys_exit_open+0x1f>
      1f:      	callq	0x24 <tracepoint__syscalls__sys_exit_open+0x24>
      24:      	movl	%eax, 0xc(%rsp)
      28:      	movq	(%rip), %rdi            # 0x2f <tracepoint__syscalls__sys_exit_open+0x2f>
      2f:      	leaq	0xc(%rsp), %rsi
      34:      	callq	0x39 <tracepoint__syscalls__sys_exit_open+0x39>
      39:      	testq	%rax, %rax
      3c:      	je	0xfa <tracepoint__syscalls__sys_exit_open+0xfa>
      42:      	movl	0x10(%rbx), %ebp
      45:      	movq	(%rip), %rcx            # 0x4c <tracepoint__syscalls__sys_exit_open+0x4c>
      4c:      	cmpb	$0x0, (%rcx)
      4f:      	je	0x59 <tracepoint__syscalls__sys_exit_open+0x59>
      51:      	testl	%ebp, %ebp
      53:      	jns	0xe9 <tracepoint__syscalls__sys_exit_open+0xe9>
      59:      	movq	%rax, %r14
      5c:      	callq	0x61 <tracepoint__syscalls__sys_exit_open+0x61>
      61:      	shrq	$0x20, %rax
      65:      	movl	%eax, 0x30(%rsp)
      69:      	callq	0x6e <tracepoint__syscalls__sys_exit_open+0x6e>
      6e:      	movl	%eax, 0x34(%rsp)
      72:      	leaq	0x50(%rsp), %rdi
      77:      	movl	$0x10, %esi
      7c:      	callq	0x81 <tracepoint__syscalls__sys_exit_open+0x81>
      81:      	leaq	0x60(%rsp), %rdi
      86:      	movq	(%r14), %rdx
      89:      	movl	$0xff, %esi
      8e:      	callq	0x93 <tracepoint__syscalls__sys_exit_open+0x93>
      93:      	movl	0x8(%r14), %eax
      97:      	movl	%eax, 0x3c(%rsp)
      9b:      	movl	%ebp, 0x38(%rsp)
      9f:      	leaq	0x10(%rsp), %rsi
      a4:      	movl	$0x100, %ecx            # imm = 0x100
      a9:      	movq	%rbx, %rdi
      ac:      	movl	$0x18, %edx
      b1:      	callq	0xb6 <tracepoint__syscalls__sys_exit_open+0xb6>
      b6:      	movq	0x18(%rsp), %rax
      bb:      	movq	0x20(%rsp), %rcx
      c0:      	movq	%rax, 0x40(%rsp)
      c5:      	movq	%rcx, 0x48(%rsp)
      ca:      	movq	(%rip), %rsi            # 0xd1 <tracepoint__syscalls__sys_exit_open+0xd1>
      d1:      	leaq	0x28(%rsp), %rcx
      d6:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
      db:      	movl	$0x138, %r8d            # imm = 0x138
      e1:      	movq	%rbx, %rdi
      e4:      	callq	0xe9 <tracepoint__syscalls__sys_exit_open+0xe9>
      e9:      	movq	(%rip), %rdi            # 0xf0 <tracepoint__syscalls__sys_exit_open+0xf0>
      f0:      	leaq	0xc(%rsp), %rsi
      f5:      	callq	0xfa <tracepoint__syscalls__sys_exit_open+0xfa>
      fa:      	xorl	%eax, %eax
      fc:      	addq	$0x160, %rsp            # imm = 0x160
     103:      	popq	%rbx
     104:      	popq	%r14
     106:      	popq	%rbp
     107:      	retq

Disassembly of section tracepoint/syscalls/sys_exit_openat:

0000000000000000 <tracepoint__syscalls__sys_exit_openat>:
       0:      	pushq	%rbp
       1:      	pushq	%r14
       3:      	pushq	%rbx
       4:      	subq	$0x160, %rsp            # imm = 0x160
       b:      	movq	%rdi, %rbx
       e:      	leaq	0x28(%rsp), %rdi
      13:      	movl	$0x138, %edx            # imm = 0x138
      18:      	xorl	%esi, %esi
      1a:      	callq	0x1f <tracepoint__syscalls__sys_exit_openat+0x1f>
      1f:      	callq	0x24 <tracepoint__syscalls__sys_exit_openat+0x24>
      24:      	movl	%eax, 0xc(%rsp)
      28:      	movq	(%rip), %rdi            # 0x2f <tracepoint__syscalls__sys_exit_openat+0x2f>
      2f:      	leaq	0xc(%rsp), %rsi
      34:      	callq	0x39 <tracepoint__syscalls__sys_exit_openat+0x39>
      39:      	testq	%rax, %rax
      3c:      	je	0xfa <tracepoint__syscalls__sys_exit_openat+0xfa>
      42:      	movl	0x10(%rbx), %ebp
      45:      	movq	(%rip), %rcx            # 0x4c <tracepoint__syscalls__sys_exit_openat+0x4c>
      4c:      	cmpb	$0x0, (%rcx)
      4f:      	je	0x59 <tracepoint__syscalls__sys_exit_openat+0x59>
      51:      	testl	%ebp, %ebp
      53:      	jns	0xe9 <tracepoint__syscalls__sys_exit_openat+0xe9>
      59:      	movq	%rax, %r14
      5c:      	callq	0x61 <tracepoint__syscalls__sys_exit_openat+0x61>
      61:      	shrq	$0x20, %rax
      65:      	movl	%eax, 0x30(%rsp)
      69:      	callq	0x6e <tracepoint__syscalls__sys_exit_openat+0x6e>
      6e:      	movl	%eax, 0x34(%rsp)
      72:      	leaq	0x50(%rsp), %rdi
      77:      	movl	$0x10, %esi
      7c:      	callq	0x81 <tracepoint__syscalls__sys_exit_openat+0x81>
      81:      	leaq	0x60(%rsp), %rdi
      86:      	movq	(%r14), %rdx
      89:      	movl	$0xff, %esi
      8e:      	callq	0x93 <tracepoint__syscalls__sys_exit_openat+0x93>
      93:      	movl	0x8(%r14), %eax
      97:      	movl	%eax, 0x3c(%rsp)
      9b:      	movl	%ebp, 0x38(%rsp)
      9f:      	leaq	0x10(%rsp), %rsi
      a4:      	movl	$0x100, %ecx            # imm = 0x100
      a9:      	movq	%rbx, %rdi
      ac:      	movl	$0x18, %edx
      b1:      	callq	0xb6 <tracepoint__syscalls__sys_exit_openat+0xb6>
      b6:      	movq	0x18(%rsp), %rax
      bb:      	movq	0x20(%rsp), %rcx
      c0:      	movq	%rax, 0x40(%rsp)
      c5:      	movq	%rcx, 0x48(%rsp)
      ca:      	movq	(%rip), %rsi            # 0xd1 <tracepoint__syscalls__sys_exit_openat+0xd1>
      d1:      	leaq	0x28(%rsp), %rcx
      d6:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
      db:      	movl	$0x138, %r8d            # imm = 0x138
      e1:      	movq	%rbx, %rdi
      e4:      	callq	0xe9 <tracepoint__syscalls__sys_exit_openat+0xe9>
      e9:      	movq	(%rip), %rdi            # 0xf0 <tracepoint__syscalls__sys_exit_openat+0xf0>
      f0:      	leaq	0xc(%rsp), %rsi
      f5:      	callq	0xfa <tracepoint__syscalls__sys_exit_openat+0xfa>
      fa:      	xorl	%eax, %eax
      fc:      	addq	$0x160, %rsp            # imm = 0x160
     103:      	popq	%rbx
     104:      	popq	%r14
     106:      	popq	%rbp
     107:      	retq
