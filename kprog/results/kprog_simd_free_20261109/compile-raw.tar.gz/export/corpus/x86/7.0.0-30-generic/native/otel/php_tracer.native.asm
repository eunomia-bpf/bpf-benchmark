
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/otel/php_tracer.native.o:	file format elf64-x86-64

Disassembly of section perf_event/unwind_php:

0000000000000000 <perf_unwind_php>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x88, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x10(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <perf_unwind_php+0x23>
      23:      	leaq	0x10(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x86a1 <perf_unwind_php+0x86a1>
      38:      	movq	%rax, %r14
      3b:      	movq	%rax, %rbp
      3e:      	movl	(%r14), %eax
      41:      	movl	%eax, 0x84(%rsp)
      48:      	movq	(%rip), %rdi            # 0x4f <perf_unwind_php+0x4f>
      4f:      	leaq	0x84(%rsp), %rsi
      57:      	movl	$0x1, %eax
      5c:      	callq	*%rax
      5e:      	testq	%rax, %rax
      61:      	je	0x75 <perf_unwind_php+0x75>
      63:      	movq	%rax, %r15
      66:      	cmpq	$0x0, 0xf10(%rbp)
      6e:      	je	0xdd <perf_unwind_php+0xdd>
      70:      	xorl	%r13d, %r13d
      73:      	jmp	0xe9 <perf_unwind_php+0xe9>
      75:      	movq	(%rip), %rax            # 0x7c <perf_unwind_php+0x7c>
      7c:      	movl	$0x1, %r12d
      82:      	cmpl	$0x0, (%rax)
      85:      	je	0x85f2 <perf_unwind_php+0x85f2>
      8b:      	movabsq	$0x746164206e6f6974, %rax # imm = 0x746164206E6F6974
      95:      	movq	%rax, 0x20(%rsp)
      9a:      	movabsq	$0x636570736f72746e, %rax # imm = 0x636570736F72746E
      a4:      	movq	%rax, 0x18(%rsp)
      a9:      	movabsq	$0x6920504850206f4e, %rax # imm = 0x6920504850206F4E
      b3:      	movq	%rax, 0x10(%rsp)
      b8:      	movl	$0xa6174, 0x27(%rsp)    # imm = 0xA6174
      c0:      	leaq	0x10(%rsp), %rdi
      c5:      	movl	$0x1b, %eax
      ca:      	movl	$0x6, %ecx
      cf:      	movl	$0x1b, %esi
      d4:      	xorl	%eax, %eax
      d6:      	callq	*%rcx
      d8:      	jmp	0x85f2 <perf_unwind_php+0x85f2>
      dd:      	cmpq	$0x0, 0xf20(%rbp)
      e5:      	sete	%r13b
      e9:      	movl	$0x22, 0x58(%rsp)
      f1:      	movq	(%rip), %rdi            # 0xf8 <perf_unwind_php+0xf8>
      f8:      	leaq	0x58(%rsp), %rsi
      fd:      	movl	$0x1, %eax
     102:      	callq	*%rax
     104:      	testq	%rax, %rax
     107:      	je	0x187 <perf_unwind_php+0x187>
     109:      	incq	(%rax)
     10c:      	addq	$0xf60, %r14            # imm = 0xF60
     113:      	cmpq	$0x0, 0xf60(%rbp)
     11b:      	jne	0x1ac <perf_unwind_php+0x1ac>
     121:      	movq	(%r15), %rax
     124:      	movl	$0x8, %ecx
     129:      	movl	$0x70, %r8d
     12f:      	movq	(%r15), %rdx
     132:      	movq	%r14, %rdi
     135:      	movl	$0x8, %esi
     13a:      	callq	*%r8
     13d:      	movq	(%rip), %r12            # 0x144 <perf_unwind_php+0x144>
     144:      	movl	(%r12), %ecx
     148:      	testq	%rax, %rax
     14b:      	je	0x1b5 <perf_unwind_php+0x1b5>
     14d:      	testl	%ecx, %ecx
     14f:      	jne	0x113c <perf_unwind_php+0x113c>
     155:      	movl	$0x24, 0x58(%rsp)
     15d:      	movq	(%rip), %rdi            # 0x164 <perf_unwind_php+0x164>
     164:      	leaq	0x58(%rsp), %rsi
     169:      	movl	$0x1, %eax
     16e:      	callq	*%rax
     170:      	testq	%rax, %rax
     173:      	je	0x354 <perf_unwind_php+0x354>
     179:      	incq	(%rax)
     17c:      	movl	$0x1, %r12d
     182:      	jmp	0x85f2 <perf_unwind_php+0x85f2>
     187:      	movq	(%rip), %rax            # 0x18e <perf_unwind_php+0x18e>
     18e:      	cmpl	$0x0, (%rax)
     191:      	jne	0xf3b <perf_unwind_php+0xf3b>
     197:      	addq	$0xf60, %r14            # imm = 0xF60
     19e:      	cmpq	$0x0, 0xf60(%rbp)
     1a6:      	je	0x121 <perf_unwind_php+0x121>
     1ac:      	movq	(%rip), %rax            # 0x1b3 <perf_unwind_php+0x1b3>
     1b3:      	movl	(%rax), %ecx
     1b5:      	testl	%ecx, %ecx
     1b7:      	jne	0xe0c <perf_unwind_php+0xe0c>
     1bd:      	movq	(%r14), %r12
     1c0:      	movq	%r12, 0x70(%rsp)
     1c5:      	testq	%r12, %r12
     1c8:      	je	0x35f <perf_unwind_php+0x35f>
     1ce:      	movl	$0x0, 0x54(%rsp)
     1d6:      	testb	%r13b, %r13b
     1d9:      	movl	$0x9, %eax
     1de:      	movl	$0x2, %ecx
     1e3:      	cmovnel	%eax, %ecx
     1e6:      	movl	%ecx, 0x7c(%rsp)
     1ea:      	movzbl	0x10(%r15), %eax
     1ef:      	addq	%r12, %rax
     1f2:      	leaq	0x58(%rsp), %rdi
     1f7:      	movl	$0x8, %ecx
     1fc:      	movl	$0x70, %r8d
     202:      	movzbl	0x10(%r15), %edx
     207:      	addq	%r12, %rdx
     20a:      	movl	$0x8, %esi
     20f:      	callq	*%r8
     212:      	testq	%rax, %rax
     215:      	movl	%r13d, 0x80(%rsp)
     21d:      	je	0x26a <perf_unwind_php+0x26a>
     21f:      	movq	(%rip), %rax            # 0x226 <perf_unwind_php+0x226>
     226:      	movl	$0x25, %r13d
     22c:      	cmpl	$0x0, (%rax)
     22f:      	jne	0xfcb <perf_unwind_php+0xfcb>
     235:      	movl	%r13d, 0x58(%rsp)
     23a:      	movq	(%rip), %rdi            # 0x241 <perf_unwind_php+0x241>
     241:      	leaq	0x58(%rsp), %rsi
     246:      	movl	$0x1, %eax
     24b:      	callq	*%rax
     24d:      	testq	%rax, %rax
     250:      	je	0x2c6 <perf_unwind_php+0x2c6>
     252:      	incq	(%rax)
     255:      	movl	$0x5, %r12d
     25b:      	cmpl	$0x23, %r13d
     25f:      	je	0x2e6 <perf_unwind_php+0x2e6>
     265:      	jmp	0x85e3 <perf_unwind_php+0x85e3>
     26a:      	movq	0x58(%rsp), %rax
     26f:      	testq	%rax, %rax
     272:      	je	0x3fe <perf_unwind_php+0x3fe>
     278:      	movzbl	0x14(%r15), %ecx
     27d:      	addq	%rcx, %rax
     280:      	leaq	0xb(%rsp), %rdi
     285:      	movl	$0x1, %ecx
     28a:      	movl	$0x70, %r8d
     290:      	movzbl	0x14(%r15), %edx
     295:      	addq	0x58(%rsp), %rdx
     29a:      	movl	$0x1, %esi
     29f:      	callq	*%r8
     2a2:      	testq	%rax, %rax
     2a5:      	je	0x535 <perf_unwind_php+0x535>
     2ab:      	movq	(%rip), %rax            # 0x2b2 <perf_unwind_php+0x2b2>
     2b2:      	cmpl	$0x0, (%rax)
     2b5:      	jne	0x13d8 <perf_unwind_php+0x13d8>
     2bb:      	movl	$0x26, %r13d
     2c1:      	jmp	0x235 <perf_unwind_php+0x235>
     2c6:      	movq	(%rip), %rax            # 0x2cd <perf_unwind_php+0x2cd>
     2cd:      	cmpl	$0x0, (%rax)
     2d0:      	jne	0x11d4 <perf_unwind_php+0x11d4>
     2d6:      	movl	$0x5, %r12d
     2dc:      	cmpl	$0x23, %r13d
     2e0:      	jne	0x85e3 <perf_unwind_php+0x85e3>
     2e6:      	movzbl	0x12(%r15), %eax
     2eb:      	addq	0x70(%rsp), %rax
     2f0:      	leaq	0x70(%rsp), %rdi
     2f5:      	movl	$0x8, %ecx
     2fa:      	movl	$0x70, %r8d
     300:      	movzbl	0x12(%r15), %edx
     305:      	addq	0x70(%rsp), %rdx
     30a:      	movl	$0x8, %esi
     30f:      	callq	*%r8
     312:      	testq	%rax, %rax
     315:      	je	0x36a <perf_unwind_php+0x36a>
     317:      	movq	(%rip), %r15            # 0x31e <perf_unwind_php+0x31e>
     31e:      	cmpl	$0x0, (%r15)
     322:      	jne	0x12c3 <perf_unwind_php+0x12c3>
     328:      	movl	$0x25, 0x58(%rsp)
     330:      	movq	(%rip), %rdi            # 0x337 <perf_unwind_php+0x337>
     337:      	leaq	0x58(%rsp), %rsi
     33c:      	movl	$0x1, %eax
     341:      	callq	*%rax
     343:      	testq	%rax, %rax
     346:      	je	0x4b0 <perf_unwind_php+0x4b0>
     34c:      	incq	(%rax)
     34f:      	jmp	0x85e3 <perf_unwind_php+0x85e3>
     354:      	cmpl	$0x0, (%r12)
     359:      	jne	0x135d <perf_unwind_php+0x135d>
     35f:      	movl	$0x1, %r12d
     365:      	jmp	0x85f2 <perf_unwind_php+0x85f2>
     36a:      	movq	0x70(%rsp), %r13
     36f:      	testq	%r13, %r13
     372:      	je	0x83ba <perf_unwind_php+0x83ba>
     378:      	testb	$0x2, 0x56(%rsp)
     37d:      	jne	0x83ba <perf_unwind_php+0x83ba>
     383:      	movzbl	0x10(%r15), %eax
     388:      	addq	%r13, %rax
     38b:      	leaq	0x58(%rsp), %rdi
     390:      	movl	$0x8, %ecx
     395:      	movl	$0x70, %r8d
     39b:      	movzbl	0x10(%r15), %edx
     3a0:      	addq	%r13, %rdx
     3a3:      	movl	$0x8, %esi
     3a8:      	callq	*%r8
     3ab:      	testq	%rax, %rax
     3ae:      	je	0x7ce <perf_unwind_php+0x7ce>
     3b4:      	movq	(%rip), %rax            # 0x3bb <perf_unwind_php+0x3bb>
     3bb:      	movl	$0x25, %ecx
     3c0:      	cmpl	$0x0, (%rax)
     3c3:      	jne	0x1811 <perf_unwind_php+0x1811>
     3c9:      	movl	%ecx, %r13d
     3cc:      	movl	%ecx, 0x58(%rsp)
     3d0:      	movq	(%rip), %rdi            # 0x3d7 <perf_unwind_php+0x3d7>
     3d7:      	leaq	0x58(%rsp), %rsi
     3dc:      	movl	$0x1, %eax
     3e1:      	callq	*%rax
     3e3:      	testq	%rax, %rax
     3e6:      	je	0x829 <perf_unwind_php+0x829>
     3ec:      	incq	(%rax)
     3ef:      	cmpl	$0x23, %r13d
     3f3:      	je	0x843 <perf_unwind_php+0x843>
     3f9:      	jmp	0x85e3 <perf_unwind_php+0x85e3>
     3fe:      	movl	0x2c0(%rbp), %eax
     404:      	cmpq	$0x7f, %rax
     408:      	jb	0x615 <perf_unwind_php+0x615>
     40e:      	movq	(%rip), %r15            # 0x415 <perf_unwind_php+0x415>
     415:      	cmpl	$0x0, (%r15)
     419:      	jne	0x167e <perf_unwind_php+0x167e>
     41f:      	movl	$0x2, 0x68(%rsp)
     427:      	movq	(%rip), %rdi            # 0x42e <perf_unwind_php+0x42e>
     42e:      	leaq	0x68(%rsp), %rsi
     433:      	movl	$0x1, %eax
     438:      	callq	*%rax
     43a:      	testq	%rax, %rax
     43d:      	je	0x663 <perf_unwind_php+0x663>
     443:      	incq	(%rax)
     446:      	cmpl	$0x0, (%r15)
     44a:      	je	0xbd9 <perf_unwind_php+0xbd9>
     450:      	movabsq	$0x656d617266207068, %rax # imm = 0x656D617266207068
     45a:      	movq	%rax, 0x28(%rsp)
     45f:      	movabsq	$0x70206e776f6e6b6e, %rax # imm = 0x70206E776F6E6B6E
     469:      	movq	%rax, 0x20(%rsp)
     46e:      	movabsq	$0x752068737570206f, %rax # imm = 0x752068737570206F
     478:      	movq	%rax, 0x18(%rsp)
     47d:      	movabsq	$0x742064656c696166, %rax # imm = 0x742064656C696166
     487:      	movq	%rax, 0x10(%rsp)
     48c:      	movw	$0xa, 0x30(%rsp)
     493:      	leaq	0x10(%rsp), %rdi
     498:      	movl	$0x22, %eax
     49d:      	movl	$0x6, %ecx
     4a2:      	movl	$0x22, %esi
     4a7:      	xorl	%eax, %eax
     4a9:      	callq	*%rcx
     4ab:      	jmp	0xbd9 <perf_unwind_php+0xbd9>
     4b0:      	cmpl	$0x0, (%r15)
     4b4:      	je	0x85e3 <perf_unwind_php+0x85e3>
     4ba:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     4c4:      	movq	%rax, 0x36(%rsp)
     4c9:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     4d3:      	movq	%rax, 0x30(%rsp)
     4d8:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     4e2:      	movq	%rax, 0x28(%rsp)
     4e7:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     4f1:      	movq	%rax, 0x20(%rsp)
     4f6:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     500:      	movq	%rax, 0x18(%rsp)
     505:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     50f:      	movq	%rax, 0x10(%rsp)
     514:      	leaq	0x10(%rsp), %rdi
     519:      	movl	$0x2e, %eax
     51e:      	movl	$0x6, %ecx
     523:      	movl	0x58(%rsp), %edx
     527:      	movl	$0x2e, %esi
     52c:      	xorl	%eax, %eax
     52e:      	callq	*%rcx
     530:      	jmp	0x85e3 <perf_unwind_php+0x85e3>
     535:      	movl	$0x0, 0xc(%rsp)
     53d:      	movzbl	0xb(%rsp), %eax
     542:      	cmpl	$0x4, %eax
     545:      	je	0x553 <perf_unwind_php+0x553>
     547:      	xorl	%r13d, %r13d
     54a:      	cmpl	$0x2, %eax
     54d:      	jne	0xb22 <perf_unwind_php+0xb22>
     553:      	movzbl	0x11(%r15), %eax
     558:      	addq	%r12, %rax
     55b:      	leaq	0x68(%rsp), %rdi
     560:      	movl	$0x8, %ecx
     565:      	movl	$0x70, %r8d
     56b:      	movzbl	0x11(%r15), %edx
     570:      	addq	%r12, %rdx
     573:      	movl	$0x8, %esi
     578:      	callq	*%r8
     57b:      	testq	%rax, %rax
     57e:      	je	0x6f2 <perf_unwind_php+0x6f2>
     584:      	movq	(%rip), %rax            # 0x58b <perf_unwind_php+0x58b>
     58b:      	movl	$0x25, %r13d
     591:      	cmpl	$0x0, (%rax)
     594:      	je	0x235 <perf_unwind_php+0x235>
     59a:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
     5a4:      	movq	%rax, 0x35(%rsp)
     5a9:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
     5b3:      	movq	%rax, 0x30(%rsp)
     5b8:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
     5c2:      	movq	%rax, 0x28(%rsp)
     5c7:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
     5d1:      	movq	%rax, 0x20(%rsp)
     5d6:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
     5e0:      	movq	%rax, 0x18(%rsp)
     5e5:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     5ef:      	movq	%rax, 0x10(%rsp)
     5f4:      	leaq	0x10(%rsp), %rdi
     5f9:      	movl	$0x2d, %eax
     5fe:      	movl	$0x6, %ecx
     603:      	movzbl	0x11(%r15), %eax
     608:      	addq	%rax, %r12
     60b:      	movl	$0x2d, %esi
     610:      	jmp	0x1049 <perf_unwind_php+0x1049>
     615:      	leal	0x1(%rax), %ecx
     618:      	movl	%ecx, 0x2c0(%rbp)
     61e:      	leaq	(%rax,%rax,2), %rax
     622:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
     62e:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
     63a:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
     642:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
     64d:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
     658:      	movl	$0x23, %r13d
     65e:      	jmp	0x235 <perf_unwind_php+0x235>
     663:      	cmpl	$0x0, (%r15)
     667:      	je	0xbd9 <perf_unwind_php+0xbd9>
     66d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     677:      	movq	%rax, 0x36(%rsp)
     67c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     686:      	movq	%rax, 0x30(%rsp)
     68b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     695:      	movq	%rax, 0x28(%rsp)
     69a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     6a4:      	movq	%rax, 0x20(%rsp)
     6a9:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     6b3:      	movq	%rax, 0x18(%rsp)
     6b8:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     6c2:      	movq	%rax, 0x10(%rsp)
     6c7:      	leaq	0x10(%rsp), %rdi
     6cc:      	movl	$0x2e, %eax
     6d1:      	movl	$0x6, %ecx
     6d6:      	movl	0x68(%rsp), %edx
     6da:      	movl	$0x2e, %esi
     6df:      	xorl	%eax, %eax
     6e1:      	callq	*%rcx
     6e3:      	cmpl	$0x0, (%r15)
     6e7:      	je	0xbd9 <perf_unwind_php+0xbd9>
     6ed:      	jmp	0x450 <perf_unwind_php+0x450>
     6f2:      	movzbl	0x15(%r15), %eax
     6f7:      	addq	0x68(%rsp), %rax
     6fc:      	leaq	0xc(%rsp), %rdi
     701:      	movl	$0x4, %ecx
     706:      	movl	$0x70, %r8d
     70c:      	movzbl	0x15(%r15), %edx
     711:      	addq	0x68(%rsp), %rdx
     716:      	movl	$0x4, %esi
     71b:      	callq	*%r8
     71e:      	testq	%rax, %rax
     721:      	je	0x912 <perf_unwind_php+0x912>
     727:      	movq	(%rip), %rax            # 0x72e <perf_unwind_php+0x72e>
     72e:      	movl	$0x27, %r13d
     734:      	cmpl	$0x0, (%rax)
     737:      	je	0x235 <perf_unwind_php+0x235>
     73d:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
     747:      	movq	%rax, 0x40(%rsp)
     74c:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
     756:      	movq	%rax, 0x38(%rsp)
     75b:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
     765:      	movq	%rax, 0x30(%rsp)
     76a:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
     774:      	movq	%rax, 0x28(%rsp)
     779:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
     783:      	movq	%rax, 0x20(%rsp)
     788:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
     792:      	movq	%rax, 0x18(%rsp)
     797:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     7a1:      	movq	%rax, 0x10(%rsp)
     7a6:      	movb	$0x0, 0x48(%rsp)
     7ab:      	leaq	0x10(%rsp), %rdi
     7b0:      	movl	$0x39, %eax
     7b5:      	movl	$0x6, %ecx
     7ba:      	movzbl	0x15(%r15), %edx
     7bf:      	addq	0x68(%rsp), %rdx
     7c4:      	movl	$0x39, %esi
     7c9:      	jmp	0x104c <perf_unwind_php+0x104c>
     7ce:      	movq	0x58(%rsp), %rax
     7d3:      	testq	%rax, %rax
     7d6:      	je	0x9db <perf_unwind_php+0x9db>
     7dc:      	movzbl	0x14(%r15), %ecx
     7e1:      	addq	%rcx, %rax
     7e4:      	leaq	0xb(%rsp), %rdi
     7e9:      	movl	$0x1, %ecx
     7ee:      	movl	$0x70, %r8d
     7f4:      	movzbl	0x14(%r15), %edx
     7f9:      	addq	0x58(%rsp), %rdx
     7fe:      	movl	$0x1, %esi
     803:      	callq	*%r8
     806:      	testq	%rax, %rax
     809:      	je	0xa38 <perf_unwind_php+0xa38>
     80f:      	movq	(%rip), %rax            # 0x816 <perf_unwind_php+0x816>
     816:      	cmpl	$0x0, (%rax)
     819:      	jne	0x1b96 <perf_unwind_php+0x1b96>
     81f:      	movl	$0x26, %ecx
     824:      	jmp	0x3c9 <perf_unwind_php+0x3c9>
     829:      	movq	(%rip), %rax            # 0x830 <perf_unwind_php+0x830>
     830:      	cmpl	$0x0, (%rax)
     833:      	jne	0x1a23 <perf_unwind_php+0x1a23>
     839:      	cmpl	$0x23, %r13d
     83d:      	jne	0x85e3 <perf_unwind_php+0x85e3>
     843:      	movzbl	0x12(%r15), %eax
     848:      	addq	0x70(%rsp), %rax
     84d:      	leaq	0x70(%rsp), %rdi
     852:      	movl	$0x8, %ecx
     857:      	movl	$0x70, %r8d
     85d:      	movzbl	0x12(%r15), %edx
     862:      	addq	0x70(%rsp), %rdx
     867:      	movl	$0x8, %esi
     86c:      	callq	*%r8
     86f:      	testq	%rax, %rax
     872:      	jne	0x317 <perf_unwind_php+0x317>
     878:      	movq	0x70(%rsp), %r13
     87d:      	testq	%r13, %r13
     880:      	je	0x83ba <perf_unwind_php+0x83ba>
     886:      	testb	$0x2, 0x56(%rsp)
     88b:      	jne	0x83ba <perf_unwind_php+0x83ba>
     891:      	movzbl	0x10(%r15), %eax
     896:      	addq	%r13, %rax
     899:      	leaq	0x58(%rsp), %rdi
     89e:      	movl	$0x8, %ecx
     8a3:      	movl	$0x70, %r8d
     8a9:      	movzbl	0x10(%r15), %edx
     8ae:      	addq	%r13, %rdx
     8b1:      	movl	$0x8, %esi
     8b6:      	callq	*%r8
     8b9:      	testq	%rax, %rax
     8bc:      	je	0xcc8 <perf_unwind_php+0xcc8>
     8c2:      	movq	(%rip), %rax            # 0x8c9 <perf_unwind_php+0x8c9>
     8c9:      	movl	$0x25, 0x4(%rsp)
     8d1:      	cmpl	$0x0, (%rax)
     8d4:      	jne	0x1fec <perf_unwind_php+0x1fec>
     8da:      	movl	0x4(%rsp), %r13d
     8df:      	movl	%r13d, 0x58(%rsp)
     8e4:      	movq	(%rip), %rdi            # 0x8eb <perf_unwind_php+0x8eb>
     8eb:      	leaq	0x58(%rsp), %rsi
     8f0:      	movl	$0x1, %eax
     8f5:      	callq	*%rax
     8f7:      	testq	%rax, %rax
     8fa:      	je	0xd24 <perf_unwind_php+0xd24>
     900:      	incq	(%rax)
     903:      	cmpl	$0x23, %r13d
     907:      	je	0xd3e <perf_unwind_php+0xd3e>
     90d:      	jmp	0x85e3 <perf_unwind_php+0x85e3>
     912:      	movzbl	0x13(%r15), %eax
     917:      	addq	%r12, %rax
     91a:      	leaq	0x54(%rsp), %rdi
     91f:      	movl	$0x4, %ecx
     924:      	movl	$0x70, %r8d
     92a:      	movzbl	0x13(%r15), %edx
     92f:      	addq	%r12, %rdx
     932:      	movl	$0x4, %esi
     937:      	callq	*%r8
     93a:      	testq	%rax, %rax
     93d:      	je	0xb1d <perf_unwind_php+0xb1d>
     943:      	movq	(%rip), %rax            # 0x94a <perf_unwind_php+0x94a>
     94a:      	movl	$0x25, %r13d
     950:      	cmpl	$0x0, (%rax)
     953:      	je	0x235 <perf_unwind_php+0x235>
     959:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
     963:      	movq	%rax, 0x3d(%rsp)
     968:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
     972:      	movq	%rax, 0x38(%rsp)
     977:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
     981:      	movq	%rax, 0x30(%rsp)
     986:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
     990:      	movq	%rax, 0x28(%rsp)
     995:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
     99f:      	movq	%rax, 0x20(%rsp)
     9a4:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
     9ae:      	movq	%rax, 0x18(%rsp)
     9b3:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     9bd:      	movq	%rax, 0x10(%rsp)
     9c2:      	leaq	0x10(%rsp), %rdi
     9c7:      	movl	$0x35, %eax
     9cc:      	movl	$0x6, %ecx
     9d1:      	movl	$0x35, %esi
     9d6:      	jmp	0x1049 <perf_unwind_php+0x1049>
     9db:      	movl	0x2c0(%rbp), %eax
     9e1:      	cmpq	$0x7e, %rax
     9e5:      	ja	0x40e <perf_unwind_php+0x40e>
     9eb:      	leal	0x1(%rax), %ecx
     9ee:      	movl	%ecx, 0x2c0(%rbp)
     9f4:      	leaq	(%rax,%rax,2), %rax
     9f8:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
     a04:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
     a10:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
     a18:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
     a23:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
     a2e:      	movl	$0x23, %ecx
     a33:      	jmp	0x3c9 <perf_unwind_php+0x3c9>
     a38:      	movl	$0x0, 0xc(%rsp)
     a40:      	movzbl	0xb(%rsp), %eax
     a45:      	cmpl	$0x4, %eax
     a48:      	je	0xa55 <perf_unwind_php+0xa55>
     a4a:      	xorl	%ecx, %ecx
     a4c:      	cmpl	$0x2, %eax
     a4f:      	jne	0x1263 <perf_unwind_php+0x1263>
     a55:      	movzbl	0x11(%r15), %eax
     a5a:      	addq	%r13, %rax
     a5d:      	leaq	0x68(%rsp), %rdi
     a62:      	movl	$0x8, %ecx
     a67:      	movl	$0x70, %r8d
     a6d:      	movzbl	0x11(%r15), %edx
     a72:      	addq	%r13, %rdx
     a75:      	movl	$0x8, %esi
     a7a:      	callq	*%r8
     a7d:      	testq	%rax, %rax
     a80:      	je	0xbe4 <perf_unwind_php+0xbe4>
     a86:      	movq	(%rip), %rax            # 0xa8d <perf_unwind_php+0xa8d>
     a8d:      	movl	$0x25, %ecx
     a92:      	cmpl	$0x0, (%rax)
     a95:      	je	0x3c9 <perf_unwind_php+0x3c9>
     a9b:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
     aa5:      	movq	%rax, 0x35(%rsp)
     aaa:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
     ab4:      	movq	%rax, 0x30(%rsp)
     ab9:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
     ac3:      	movq	%rax, 0x28(%rsp)
     ac8:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
     ad2:      	movq	%rax, 0x20(%rsp)
     ad7:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
     ae1:      	movq	%rax, 0x18(%rsp)
     ae6:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     af0:      	movq	%rax, 0x10(%rsp)
     af5:      	leaq	0x10(%rsp), %rdi
     afa:      	movl	$0x2d, %eax
     aff:      	movl	$0x6, %ecx
     b04:      	movzbl	0x11(%r15), %eax
     b09:      	addq	%rax, %r13
     b0c:      	movl	$0x2d, %esi
     b11:      	movq	%r13, %rdx
     b14:      	xorl	%eax, %eax
     b16:      	callq	*%rcx
     b18:      	jmp	0xed1 <perf_unwind_php+0xed1>
     b1d:      	movl	0xc(%rsp), %r13d
     b22:      	movl	0x54(%rsp), %r12d
     b27:      	movq	(%rip), %rax            # 0xb2e <perf_unwind_php+0xb2e>
     b2e:      	cmpl	$0x0, (%rax)
     b31:      	jne	0x18a0 <perf_unwind_php+0x18a0>
     b37:      	movl	0x2c0(%rbp), %eax
     b3d:      	cmpq	$0x7f, %rax
     b41:      	jb	0x1900 <perf_unwind_php+0x1900>
     b47:      	movq	(%rip), %r15            # 0xb4e <perf_unwind_php+0xb4e>
     b4e:      	cmpl	$0x0, (%r15)
     b52:      	jne	0x1b2e <perf_unwind_php+0x1b2e>
     b58:      	movl	$0x2, 0x68(%rsp)
     b60:      	movq	(%rip), %rdi            # 0xb67 <perf_unwind_php+0xb67>
     b67:      	leaq	0x68(%rsp), %rsi
     b6c:      	movl	$0x1, %eax
     b71:      	callq	*%rax
     b73:      	testq	%rax, %rax
     b76:      	je	0xbcf <perf_unwind_php+0xbcf>
     b78:      	incq	(%rax)
     b7b:      	cmpl	$0x0, (%r15)
     b7f:      	je	0xbd9 <perf_unwind_php+0xbd9>
     b81:      	movabsq	$0x656d617266207068, %rax # imm = 0x656D617266207068
     b8b:      	movq	%rax, 0x20(%rsp)
     b90:      	movabsq	$0x702068737570206f, %rax # imm = 0x702068737570206F
     b9a:      	movq	%rax, 0x18(%rsp)
     b9f:      	movabsq	$0x742064656c696166, %rax # imm = 0x742064656C696166
     ba9:      	movq	%rax, 0x10(%rsp)
     bae:      	movw	$0xa, 0x28(%rsp)
     bb5:      	leaq	0x10(%rsp), %rdi
     bba:      	movl	$0x1a, %eax
     bbf:      	movl	$0x6, %ecx
     bc4:      	movl	$0x1a, %esi
     bc9:      	xorl	%eax, %eax
     bcb:      	callq	*%rcx
     bcd:      	jmp	0xbd9 <perf_unwind_php+0xbd9>
     bcf:      	cmpl	$0x0, (%r15)
     bd3:      	jne	0x1cf5 <perf_unwind_php+0x1cf5>
     bd9:      	movl	$0x5, %r12d
     bdf:      	jmp	0x85e3 <perf_unwind_php+0x85e3>
     be4:      	movzbl	0x15(%r15), %eax
     be9:      	addq	0x68(%rsp), %rax
     bee:      	leaq	0xc(%rsp), %rdi
     bf3:      	movl	$0x4, %ecx
     bf8:      	movl	$0x70, %r8d
     bfe:      	movzbl	0x15(%r15), %edx
     c03:      	addq	0x68(%rsp), %rdx
     c08:      	movl	$0x4, %esi
     c0d:      	callq	*%r8
     c10:      	testq	%rax, %rax
     c13:      	je	0xe90 <perf_unwind_php+0xe90>
     c19:      	movq	(%rip), %rax            # 0xc20 <perf_unwind_php+0xc20>
     c20:      	movl	$0x27, %ecx
     c25:      	cmpl	$0x0, (%rax)
     c28:      	je	0x3c9 <perf_unwind_php+0x3c9>
     c2e:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
     c38:      	movq	%rax, 0x40(%rsp)
     c3d:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
     c47:      	movq	%rax, 0x38(%rsp)
     c4c:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
     c56:      	movq	%rax, 0x30(%rsp)
     c5b:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
     c65:      	movq	%rax, 0x28(%rsp)
     c6a:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
     c74:      	movq	%rax, 0x20(%rsp)
     c79:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
     c83:      	movq	%rax, 0x18(%rsp)
     c88:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     c92:      	movq	%rax, 0x10(%rsp)
     c97:      	movb	$0x0, 0x48(%rsp)
     c9c:      	leaq	0x10(%rsp), %rdi
     ca1:      	movl	$0x39, %eax
     ca6:      	movl	$0x6, %ecx
     cab:      	movzbl	0x15(%r15), %edx
     cb0:      	addq	0x68(%rsp), %rdx
     cb5:      	movl	$0x39, %esi
     cba:      	xorl	%eax, %eax
     cbc:      	callq	*%rcx
     cbe:      	movl	$0x27, %ecx
     cc3:      	jmp	0x3c9 <perf_unwind_php+0x3c9>
     cc8:      	movq	0x58(%rsp), %rax
     ccd:      	testq	%rax, %rax
     cd0:      	je	0xedb <perf_unwind_php+0xedb>
     cd6:      	movzbl	0x14(%r15), %ecx
     cdb:      	addq	%rcx, %rax
     cde:      	leaq	0xb(%rsp), %rdi
     ce3:      	movl	$0x1, %ecx
     ce8:      	movl	$0x70, %r8d
     cee:      	movzbl	0x14(%r15), %edx
     cf3:      	addq	0x58(%rsp), %rdx
     cf8:      	movl	$0x1, %esi
     cfd:      	callq	*%r8
     d00:      	testq	%rax, %rax
     d03:      	je	0x1055 <perf_unwind_php+0x1055>
     d09:      	movq	(%rip), %rax            # 0xd10 <perf_unwind_php+0xd10>
     d10:      	cmpl	$0x0, (%rax)
     d13:      	jne	0x22b9 <perf_unwind_php+0x22b9>
     d19:      	movl	$0x26, %r13d
     d1f:      	jmp	0x8df <perf_unwind_php+0x8df>
     d24:      	movq	(%rip), %rax            # 0xd2b <perf_unwind_php+0xd2b>
     d2b:      	cmpl	$0x0, (%rax)
     d2e:      	jne	0x21ca <perf_unwind_php+0x21ca>
     d34:      	cmpl	$0x23, %r13d
     d38:      	jne	0x85e3 <perf_unwind_php+0x85e3>
     d3e:      	movzbl	0x12(%r15), %eax
     d43:      	addq	0x70(%rsp), %rax
     d48:      	leaq	0x70(%rsp), %rdi
     d4d:      	movl	$0x8, %ecx
     d52:      	movl	$0x70, %r8d
     d58:      	movzbl	0x12(%r15), %edx
     d5d:      	addq	0x70(%rsp), %rdx
     d62:      	movl	$0x8, %esi
     d67:      	callq	*%r8
     d6a:      	testq	%rax, %rax
     d6d:      	jne	0x317 <perf_unwind_php+0x317>
     d73:      	movq	0x70(%rsp), %r13
     d78:      	testq	%r13, %r13
     d7b:      	je	0x83ba <perf_unwind_php+0x83ba>
     d81:      	testb	$0x2, 0x56(%rsp)
     d86:      	jne	0x83ba <perf_unwind_php+0x83ba>
     d8c:      	movzbl	0x10(%r15), %eax
     d91:      	addq	%r13, %rax
     d94:      	leaq	0x58(%rsp), %rdi
     d99:      	movl	$0x8, %ecx
     d9e:      	movl	$0x70, %r8d
     da4:      	movzbl	0x10(%r15), %edx
     da9:      	addq	%r13, %rdx
     dac:      	movl	$0x8, %esi
     db1:      	callq	*%r8
     db4:      	testq	%rax, %rax
     db7:      	je	0x1537 <perf_unwind_php+0x1537>
     dbd:      	movq	(%rip), %rax            # 0xdc4 <perf_unwind_php+0xdc4>
     dc4:      	movl	$0x25, 0x4(%rsp)
     dcc:      	cmpl	$0x0, (%rax)
     dcf:      	jne	0x270c <perf_unwind_php+0x270c>
     dd5:      	movl	0x4(%rsp), %eax
     dd9:      	movl	%eax, 0x58(%rsp)
     ddd:      	movq	(%rip), %rdi            # 0xde4 <perf_unwind_php+0xde4>
     de4:      	leaq	0x58(%rsp), %rsi
     de9:      	movl	$0x1, %eax
     dee:      	callq	*%rax
     df0:      	testq	%rax, %rax
     df3:      	je	0x1595 <perf_unwind_php+0x1595>
     df9:      	incq	(%rax)
     dfc:      	cmpl	$0x23, 0x4(%rsp)
     e01:      	je	0x15b0 <perf_unwind_php+0x15b0>
     e07:      	jmp	0x85e3 <perf_unwind_php+0x85e3>
     e0c:      	movabsq	$0x786c257830203d20, %rax # imm = 0x786C257830203D20
     e16:      	movq	%rax, 0x30(%rsp)
     e1b:      	movabsq	$0x617461645f657475, %rax # imm = 0x617461645F657475
     e25:      	movq	%rax, 0x28(%rsp)
     e2a:      	movabsq	$0x6365786528206b63, %rax # imm = 0x6365786528206B63
     e34:      	movq	%rax, 0x20(%rsp)
     e39:      	movabsq	$0x6174732050485020, %rax # imm = 0x6174732050485020
     e43:      	movq	%rax, 0x18(%rsp)
     e48:      	movabsq	$0x676e69646c697542, %rax # imm = 0x676E69646C697542
     e52:      	movq	%rax, 0x10(%rsp)
     e57:      	movl	$0xa2978, 0x37(%rsp)    # imm = 0xA2978
     e5f:      	leaq	0x10(%rsp), %rdi
     e64:      	movl	$0x2b, %eax
     e69:      	movl	$0x6, %ecx
     e6e:      	movq	(%r14), %rdx
     e71:      	movl	$0x2b, %esi
     e76:      	xorl	%eax, %eax
     e78:      	callq	*%rcx
     e7a:      	movq	(%r14), %r12
     e7d:      	movq	%r12, 0x70(%rsp)
     e82:      	testq	%r12, %r12
     e85:      	jne	0x1ce <perf_unwind_php+0x1ce>
     e8b:      	jmp	0x35f <perf_unwind_php+0x35f>
     e90:      	movzbl	0x13(%r15), %eax
     e95:      	addq	%r13, %rax
     e98:      	leaq	0x54(%rsp), %rdi
     e9d:      	movl	$0x4, %ecx
     ea2:      	movl	$0x70, %r8d
     ea8:      	movzbl	0x13(%r15), %edx
     ead:      	addq	%r13, %rdx
     eb0:      	movl	$0x4, %esi
     eb5:      	callq	*%r8
     eb8:      	testq	%rax, %rax
     ebb:      	je	0x125f <perf_unwind_php+0x125f>
     ec1:      	movq	(%rip), %rax            # 0xec8 <perf_unwind_php+0xec8>
     ec8:      	cmpl	$0x0, (%rax)
     ecb:      	jne	0x255f <perf_unwind_php+0x255f>
     ed1:      	movl	$0x25, %ecx
     ed6:      	jmp	0x3c9 <perf_unwind_php+0x3c9>
     edb:      	movl	0x2c0(%rbp), %eax
     ee1:      	cmpq	$0x7e, %rax
     ee5:      	ja	0x40e <perf_unwind_php+0x40e>
     eeb:      	leal	0x1(%rax), %ecx
     eee:      	movl	%ecx, 0x2c0(%rbp)
     ef4:      	leaq	(%rax,%rax,2), %rax
     ef8:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
     f04:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
     f10:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
     f18:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
     f23:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
     f2e:      	movl	$0x23, 0x4(%rsp)
     f36:      	jmp	0x8da <perf_unwind_php+0x8da>
     f3b:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     f45:      	movq	%rax, 0x36(%rsp)
     f4a:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     f54:      	movq	%rax, 0x30(%rsp)
     f59:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     f63:      	movq	%rax, 0x28(%rsp)
     f68:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     f72:      	movq	%rax, 0x20(%rsp)
     f77:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     f81:      	movq	%rax, 0x18(%rsp)
     f86:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     f90:      	movq	%rax, 0x10(%rsp)
     f95:      	leaq	0x10(%rsp), %rdi
     f9a:      	movl	$0x2e, %eax
     f9f:      	movl	$0x6, %ecx
     fa4:      	movl	0x58(%rsp), %edx
     fa8:      	movl	$0x2e, %esi
     fad:      	xorl	%eax, %eax
     faf:      	callq	*%rcx
     fb1:      	addq	$0xf60, %r14            # imm = 0xF60
     fb8:      	cmpq	$0x0, 0xf60(%rbp)
     fc0:      	jne	0x1ac <perf_unwind_php+0x1ac>
     fc6:      	jmp	0x121 <perf_unwind_php+0x121>
     fcb:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
     fd5:      	movq	%rax, 0x38(%rsp)
     fda:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
     fe4:      	movq	%rax, 0x30(%rsp)
     fe9:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
     ff3:      	movq	%rax, 0x28(%rsp)
     ff8:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    1002:      	movq	%rax, 0x20(%rsp)
    1007:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    1011:      	movq	%rax, 0x18(%rsp)
    1016:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1020:      	movq	%rax, 0x10(%rsp)
    1025:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    102d:      	leaq	0x10(%rsp), %rdi
    1032:      	movl	$0x33, %eax
    1037:      	movl	$0x6, %ecx
    103c:      	movzbl	0x10(%r15), %eax
    1041:      	addq	%rax, %r12
    1044:      	movl	$0x33, %esi
    1049:      	movq	%r12, %rdx
    104c:      	xorl	%eax, %eax
    104e:      	callq	*%rcx
    1050:      	jmp	0x235 <perf_unwind_php+0x235>
    1055:      	movl	$0x0, 0xc(%rsp)
    105d:      	movzbl	0xb(%rsp), %eax
    1062:      	cmpl	$0x4, %eax
    1065:      	je	0x1078 <perf_unwind_php+0x1078>
    1067:      	movl	$0x0, 0x4(%rsp)
    106f:      	cmpl	$0x2, %eax
    1072:      	jne	0x1ab0 <perf_unwind_php+0x1ab0>
    1078:      	movzbl	0x11(%r15), %eax
    107d:      	addq	%r13, %rax
    1080:      	leaq	0x68(%rsp), %rdi
    1085:      	movl	$0x8, %ecx
    108a:      	movl	$0x70, %r8d
    1090:      	movzbl	0x11(%r15), %edx
    1095:      	addq	%r13, %rdx
    1098:      	movl	$0x8, %esi
    109d:      	callq	*%r8
    10a0:      	testq	%rax, %rax
    10a3:      	je	0x1459 <perf_unwind_php+0x1459>
    10a9:      	movq	(%rip), %rax            # 0x10b0 <perf_unwind_php+0x10b0>
    10b0:      	movl	$0x25, 0x4(%rsp)
    10b8:      	cmpl	$0x0, (%rax)
    10bb:      	je	0x8da <perf_unwind_php+0x8da>
    10c1:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    10cb:      	movq	%rax, 0x35(%rsp)
    10d0:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    10da:      	movq	%rax, 0x30(%rsp)
    10df:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    10e9:      	movq	%rax, 0x28(%rsp)
    10ee:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    10f8:      	movq	%rax, 0x20(%rsp)
    10fd:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    1107:      	movq	%rax, 0x18(%rsp)
    110c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1116:      	movq	%rax, 0x10(%rsp)
    111b:      	leaq	0x10(%rsp), %rdi
    1120:      	movl	$0x2d, %eax
    1125:      	movl	$0x6, %ecx
    112a:      	movzbl	0x11(%r15), %eax
    112f:      	addq	%rax, %r13
    1132:      	movl	$0x2d, %esi
    1137:      	jmp	0x206a <perf_unwind_php+0x206a>
    113c:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    1146:      	movq	%rax, 0x46(%rsp)
    114b:      	movabsq	$0x7830282061746164, %rax # imm = 0x7830282061746164
    1155:      	movq	%rax, 0x40(%rsp)
    115a:      	movabsq	$0x2065747563657865, %rax # imm = 0x2065747563657865
    1164:      	movq	%rax, 0x38(%rsp)
    1169:      	movabsq	$0x5f746e6572727563, %rax # imm = 0x5F746E6572727563
    1173:      	movq	%rax, 0x30(%rsp)
    1178:      	movabsq	$0x2e736c61626f6c67, %rax # imm = 0x2E736C61626F6C67
    1182:      	movq	%rax, 0x28(%rsp)
    1187:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    1191:      	movq	%rax, 0x20(%rsp)
    1196:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    11a0:      	movq	%rax, 0x18(%rsp)
    11a5:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    11af:      	movq	%rax, 0x10(%rsp)
    11b4:      	leaq	0x10(%rsp), %rdi
    11b9:      	movl	$0x3e, %eax
    11be:      	movl	$0x6, %ecx
    11c3:      	movq	(%r15), %rdx
    11c6:      	movl	$0x3e, %esi
    11cb:      	xorl	%eax, %eax
    11cd:      	callq	*%rcx
    11cf:      	jmp	0x155 <perf_unwind_php+0x155>
    11d4:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    11de:      	movq	%rax, 0x36(%rsp)
    11e3:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    11ed:      	movq	%rax, 0x30(%rsp)
    11f2:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    11fc:      	movq	%rax, 0x28(%rsp)
    1201:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    120b:      	movq	%rax, 0x20(%rsp)
    1210:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    121a:      	movq	%rax, 0x18(%rsp)
    121f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1229:      	movq	%rax, 0x10(%rsp)
    122e:      	leaq	0x10(%rsp), %rdi
    1233:      	movl	$0x2e, %eax
    1238:      	movl	$0x6, %ecx
    123d:      	movl	0x58(%rsp), %edx
    1241:      	movl	$0x2e, %esi
    1246:      	xorl	%eax, %eax
    1248:      	callq	*%rcx
    124a:      	movl	$0x5, %r12d
    1250:      	cmpl	$0x23, %r13d
    1254:      	je	0x2e6 <perf_unwind_php+0x2e6>
    125a:      	jmp	0x85e3 <perf_unwind_php+0x85e3>
    125f:      	movl	0xc(%rsp), %ecx
    1263:      	movl	0x54(%rsp), %r13d
    1268:      	movq	(%rip), %rax            # 0x126f <perf_unwind_php+0x126f>
    126f:      	cmpl	$0x0, (%rax)
    1272:      	jne	0x2076 <perf_unwind_php+0x2076>
    1278:      	movl	0x2c0(%rbp), %eax
    127e:      	cmpq	$0x7e, %rax
    1282:      	ja	0xb47 <perf_unwind_php+0xb47>
    1288:      	movl	%ecx, %ecx
    128a:      	shlq	$0x20, %r13
    128e:      	orq	%r13, %rcx
    1291:      	movq	0x58(%rsp), %rdx
    1296:      	leal	0x1(%rax), %esi
    1299:      	movl	%esi, 0x2c0(%rbp)
    129f:      	leaq	(%rax,%rax,2), %rax
    12a3:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    12ab:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    12b3:      	movl	0x7c(%rsp), %ecx
    12b7:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    12be:      	jmp	0xa18 <perf_unwind_php+0xa18>
    12c3:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    12cd:      	movq	%rax, 0x48(%rsp)
    12d2:      	movabsq	$0x2820617461645f65, %rax # imm = 0x2820617461645F65
    12dc:      	movq	%rax, 0x40(%rsp)
    12e1:      	movabsq	$0x7475636578655f76, %rax # imm = 0x7475636578655F76
    12eb:      	movq	%rax, 0x38(%rsp)
    12f0:      	movabsq	$0x6572703e2d617461, %rax # imm = 0x6572703E2D617461
    12fa:      	movq	%rax, 0x30(%rsp)
    12ff:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    1309:      	movq	%rax, 0x28(%rsp)
    130e:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    1318:      	movq	%rax, 0x20(%rsp)
    131d:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    1327:      	movq	%rax, 0x18(%rsp)
    132c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1336:      	movq	%rax, 0x10(%rsp)
    133b:      	leaq	0x10(%rsp), %rdi
    1340:      	movl	$0x40, %eax
    1345:      	movl	$0x6, %ecx
    134a:      	movq	0x70(%rsp), %rdx
    134f:      	movl	$0x40, %esi
    1354:      	xorl	%eax, %eax
    1356:      	callq	*%rcx
    1358:      	jmp	0x328 <perf_unwind_php+0x328>
    135d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1367:      	movq	%rax, 0x36(%rsp)
    136c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1376:      	movq	%rax, 0x30(%rsp)
    137b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1385:      	movq	%rax, 0x28(%rsp)
    138a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1394:      	movq	%rax, 0x20(%rsp)
    1399:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    13a3:      	movq	%rax, 0x18(%rsp)
    13a8:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    13b2:      	movq	%rax, 0x10(%rsp)
    13b7:      	leaq	0x10(%rsp), %rdi
    13bc:      	movl	$0x2e, %eax
    13c1:      	movl	$0x6, %ecx
    13c6:      	movl	0x58(%rsp), %edx
    13ca:      	movl	$0x2e, %esi
    13cf:      	xorl	%eax, %eax
    13d1:      	callq	*%rcx
    13d3:      	jmp	0x35f <perf_unwind_php+0x35f>
    13d8:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    13e2:      	movq	%rax, 0x38(%rsp)
    13e7:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    13f1:      	movq	%rax, 0x30(%rsp)
    13f6:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    1400:      	movq	%rax, 0x28(%rsp)
    1405:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    140f:      	movq	%rax, 0x20(%rsp)
    1414:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    141e:      	movq	%rax, 0x18(%rsp)
    1423:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    142d:      	movq	%rax, 0x10(%rsp)
    1432:      	movb	$0x0, 0x40(%rsp)
    1437:      	leaq	0x10(%rsp), %rdi
    143c:      	movl	$0x31, %eax
    1441:      	movl	$0x6, %ecx
    1446:      	movq	0x58(%rsp), %rdx
    144b:      	movl	$0x31, %esi
    1450:      	xorl	%eax, %eax
    1452:      	callq	*%rcx
    1454:      	jmp	0x2bb <perf_unwind_php+0x2bb>
    1459:      	movzbl	0x15(%r15), %eax
    145e:      	addq	0x68(%rsp), %rax
    1463:      	leaq	0xc(%rsp), %rdi
    1468:      	movl	$0x4, %ecx
    146d:      	movl	$0x70, %r8d
    1473:      	movzbl	0x15(%r15), %edx
    1478:      	addq	0x68(%rsp), %rdx
    147d:      	movl	$0x4, %esi
    1482:      	callq	*%r8
    1485:      	testq	%rax, %rax
    1488:      	je	0x16e6 <perf_unwind_php+0x16e6>
    148e:      	movq	(%rip), %rax            # 0x1495 <perf_unwind_php+0x1495>
    1495:      	movl	$0x27, 0x4(%rsp)
    149d:      	cmpl	$0x0, (%rax)
    14a0:      	je	0x8da <perf_unwind_php+0x8da>
    14a6:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    14b0:      	movq	%rax, 0x40(%rsp)
    14b5:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    14bf:      	movq	%rax, 0x38(%rsp)
    14c4:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    14ce:      	movq	%rax, 0x30(%rsp)
    14d3:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    14dd:      	movq	%rax, 0x28(%rsp)
    14e2:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    14ec:      	movq	%rax, 0x20(%rsp)
    14f1:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    14fb:      	movq	%rax, 0x18(%rsp)
    1500:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    150a:      	movq	%rax, 0x10(%rsp)
    150f:      	movb	$0x0, 0x48(%rsp)
    1514:      	leaq	0x10(%rsp), %rdi
    1519:      	movl	$0x39, %eax
    151e:      	movl	$0x6, %ecx
    1523:      	movzbl	0x15(%r15), %edx
    1528:      	addq	0x68(%rsp), %rdx
    152d:      	movl	$0x39, %esi
    1532:      	jmp	0x206d <perf_unwind_php+0x206d>
    1537:      	movq	0x58(%rsp), %rax
    153c:      	testq	%rax, %rax
    153f:      	je	0x17b1 <perf_unwind_php+0x17b1>
    1545:      	movzbl	0x14(%r15), %ecx
    154a:      	addq	%rcx, %rax
    154d:      	leaq	0xb(%rsp), %rdi
    1552:      	movl	$0x1, %ecx
    1557:      	movl	$0x70, %r8d
    155d:      	movzbl	0x14(%r15), %edx
    1562:      	addq	0x58(%rsp), %rdx
    1567:      	movl	$0x1, %esi
    156c:      	callq	*%r8
    156f:      	testq	%rax, %rax
    1572:      	je	0x193c <perf_unwind_php+0x193c>
    1578:      	movq	(%rip), %rax            # 0x157f <perf_unwind_php+0x157f>
    157f:      	cmpl	$0x0, (%rax)
    1582:      	jne	0x29d2 <perf_unwind_php+0x29d2>
    1588:      	movl	$0x26, 0x4(%rsp)
    1590:      	jmp	0xdd5 <perf_unwind_php+0xdd5>
    1595:      	movq	(%rip), %rax            # 0x159c <perf_unwind_php+0x159c>
    159c:      	cmpl	$0x0, (%rax)
    159f:      	jne	0x28e2 <perf_unwind_php+0x28e2>
    15a5:      	cmpl	$0x23, 0x4(%rsp)
    15aa:      	jne	0x85e3 <perf_unwind_php+0x85e3>
    15b0:      	movzbl	0x12(%r15), %eax
    15b5:      	addq	0x70(%rsp), %rax
    15ba:      	leaq	0x70(%rsp), %rdi
    15bf:      	movl	$0x8, %ecx
    15c4:      	movl	$0x70, %r8d
    15ca:      	movzbl	0x12(%r15), %edx
    15cf:      	addq	0x70(%rsp), %rdx
    15d4:      	movl	$0x8, %esi
    15d9:      	callq	*%r8
    15dc:      	testq	%rax, %rax
    15df:      	jne	0x317 <perf_unwind_php+0x317>
    15e5:      	movq	0x70(%rsp), %r13
    15ea:      	testq	%r13, %r13
    15ed:      	je	0x83ba <perf_unwind_php+0x83ba>
    15f3:      	testb	$0x2, 0x56(%rsp)
    15f8:      	jne	0x83ba <perf_unwind_php+0x83ba>
    15fe:      	movzbl	0x10(%r15), %eax
    1603:      	addq	%r13, %rax
    1606:      	leaq	0x58(%rsp), %rdi
    160b:      	movl	$0x8, %ecx
    1610:      	movl	$0x70, %r8d
    1616:      	movzbl	0x10(%r15), %edx
    161b:      	addq	%r13, %rdx
    161e:      	movl	$0x8, %esi
    1623:      	callq	*%r8
    1626:      	testq	%rax, %rax
    1629:      	je	0x1d7a <perf_unwind_php+0x1d7a>
    162f:      	movq	(%rip), %rax            # 0x1636 <perf_unwind_php+0x1636>
    1636:      	movl	$0x25, 0x4(%rsp)
    163e:      	cmpl	$0x0, (%rax)
    1641:      	jne	0x2da3 <perf_unwind_php+0x2da3>
    1647:      	movl	0x4(%rsp), %eax
    164b:      	movl	%eax, 0x58(%rsp)
    164f:      	movq	(%rip), %rdi            # 0x1656 <perf_unwind_php+0x1656>
    1656:      	leaq	0x58(%rsp), %rsi
    165b:      	movl	$0x1, %eax
    1660:      	callq	*%rax
    1662:      	testq	%rax, %rax
    1665:      	je	0x1dd8 <perf_unwind_php+0x1dd8>
    166b:      	incq	(%rax)
    166e:      	cmpl	$0x23, 0x4(%rsp)
    1673:      	je	0x1df3 <perf_unwind_php+0x1df3>
    1679:      	jmp	0x85e3 <perf_unwind_php+0x85e3>
    167e:      	movabsq	$0xa6c6c75662073, %rax  # imm = 0xA6C6C75662073
    1688:      	movq	%rax, 0x2d(%rsp)
    168d:      	movabsq	$0x66207369206b6361, %rax # imm = 0x66207369206B6361
    1697:      	movq	%rax, 0x28(%rsp)
    169c:      	movabsq	$0x7473203a656d6172, %rax # imm = 0x7473203A656D6172
    16a6:      	movq	%rax, 0x20(%rsp)
    16ab:      	movabsq	$0x662068737570206f, %rax # imm = 0x662068737570206F
    16b5:      	movq	%rax, 0x18(%rsp)
    16ba:      	movabsq	$0x7420656c62616e75, %rax # imm = 0x7420656C62616E75
    16c4:      	movq	%rax, 0x10(%rsp)
    16c9:      	leaq	0x10(%rsp), %rdi
    16ce:      	movl	$0x25, %eax
    16d3:      	movl	$0x6, %ecx
    16d8:      	movl	$0x25, %esi
    16dd:      	xorl	%eax, %eax
    16df:      	callq	*%rcx
    16e1:      	jmp	0x41f <perf_unwind_php+0x41f>
    16e6:      	movzbl	0x13(%r15), %eax
    16eb:      	addq	%r13, %rax
    16ee:      	leaq	0x54(%rsp), %rdi
    16f3:      	movl	$0x4, %ecx
    16f8:      	movl	$0x70, %r8d
    16fe:      	movzbl	0x13(%r15), %edx
    1703:      	addq	%r13, %rdx
    1706:      	movl	$0x4, %esi
    170b:      	callq	*%r8
    170e:      	testq	%rax, %rax
    1711:      	je	0x1aa8 <perf_unwind_php+0x1aa8>
    1717:      	movq	(%rip), %rax            # 0x171e <perf_unwind_php+0x171e>
    171e:      	movl	$0x25, 0x4(%rsp)
    1726:      	cmpl	$0x0, (%rax)
    1729:      	je	0x8da <perf_unwind_php+0x8da>
    172f:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    1739:      	movq	%rax, 0x3d(%rsp)
    173e:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    1748:      	movq	%rax, 0x38(%rsp)
    174d:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    1757:      	movq	%rax, 0x30(%rsp)
    175c:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    1766:      	movq	%rax, 0x28(%rsp)
    176b:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    1775:      	movq	%rax, 0x20(%rsp)
    177a:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    1784:      	movq	%rax, 0x18(%rsp)
    1789:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1793:      	movq	%rax, 0x10(%rsp)
    1798:      	leaq	0x10(%rsp), %rdi
    179d:      	movl	$0x35, %eax
    17a2:      	movl	$0x6, %ecx
    17a7:      	movl	$0x35, %esi
    17ac:      	jmp	0x206a <perf_unwind_php+0x206a>
    17b1:      	movl	0x2c0(%rbp), %eax
    17b7:      	cmpq	$0x7e, %rax
    17bb:      	ja	0x40e <perf_unwind_php+0x40e>
    17c1:      	leal	0x1(%rax), %ecx
    17c4:      	movl	%ecx, 0x2c0(%rbp)
    17ca:      	leaq	(%rax,%rax,2), %rax
    17ce:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    17da:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    17e6:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    17ee:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    17f9:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    1804:      	movl	$0x23, 0x4(%rsp)
    180c:      	jmp	0xdd5 <perf_unwind_php+0xdd5>
    1811:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    181b:      	movq	%rax, 0x38(%rsp)
    1820:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    182a:      	movq	%rax, 0x30(%rsp)
    182f:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    1839:      	movq	%rax, 0x28(%rsp)
    183e:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    1848:      	movq	%rax, 0x20(%rsp)
    184d:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    1857:      	movq	%rax, 0x18(%rsp)
    185c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1866:      	movq	%rax, 0x10(%rsp)
    186b:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    1873:      	leaq	0x10(%rsp), %rdi
    1878:      	movl	$0x33, %eax
    187d:      	movl	$0x6, %ecx
    1882:      	movzbl	0x10(%r15), %eax
    1887:      	addq	%rax, %r13
    188a:      	movl	$0x33, %esi
    188f:      	movq	%r13, %rdx
    1892:      	xorl	%eax, %eax
    1894:      	callq	*%rcx
    1896:      	movl	$0x25, %ecx
    189b:      	jmp	0x3c9 <perf_unwind_php+0x3c9>
    18a0:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    18aa:      	movq	%rax, 0x1e(%rsp)
    18af:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    18b9:      	movq	%rax, 0x18(%rsp)
    18be:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    18c8:      	movq	%rax, 0x10(%rsp)
    18cd:      	leaq	0x10(%rsp), %rdi
    18d2:      	movl	$0x16, %eax
    18d7:      	movl	$0x6, %r8d
    18dd:      	movq	0x58(%rsp), %rdx
    18e2:      	movl	0xc(%rsp), %ecx
    18e6:      	movl	$0x16, %esi
    18eb:      	xorl	%eax, %eax
    18ed:      	callq	*%r8
    18f0:      	movl	0x2c0(%rbp), %eax
    18f6:      	cmpq	$0x7f, %rax
    18fa:      	jae	0xb47 <perf_unwind_php+0xb47>
    1900:      	movl	%r13d, %ecx
    1903:      	shlq	$0x20, %r12
    1907:      	orq	%r12, %rcx
    190a:      	movq	0x58(%rsp), %rdx
    190f:      	leal	0x1(%rax), %esi
    1912:      	movl	%esi, 0x2c0(%rbp)
    1918:      	leaq	(%rax,%rax,2), %rax
    191c:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    1924:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    192c:      	movl	0x7c(%rsp), %ecx
    1930:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    1937:      	jmp	0x642 <perf_unwind_php+0x642>
    193c:      	movl	$0x0, 0xc(%rsp)
    1944:      	movzbl	0xb(%rsp), %eax
    1949:      	cmpl	$0x4, %eax
    194c:      	je	0x195f <perf_unwind_php+0x195f>
    194e:      	movl	$0x0, 0x4(%rsp)
    1956:      	cmpl	$0x2, %eax
    1959:      	jne	0x2257 <perf_unwind_php+0x2257>
    195f:      	movzbl	0x11(%r15), %eax
    1964:      	addq	%r13, %rax
    1967:      	leaq	0x68(%rsp), %rdi
    196c:      	movl	$0x8, %ecx
    1971:      	movl	$0x70, %r8d
    1977:      	movzbl	0x11(%r15), %edx
    197c:      	addq	%r13, %rdx
    197f:      	movl	$0x8, %esi
    1984:      	callq	*%r8
    1987:      	testq	%rax, %rax
    198a:      	je	0x1c17 <perf_unwind_php+0x1c17>
    1990:      	movq	(%rip), %rax            # 0x1997 <perf_unwind_php+0x1997>
    1997:      	movl	$0x25, 0x4(%rsp)
    199f:      	cmpl	$0x0, (%rax)
    19a2:      	je	0xdd5 <perf_unwind_php+0xdd5>
    19a8:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    19b2:      	movq	%rax, 0x35(%rsp)
    19b7:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    19c1:      	movq	%rax, 0x30(%rsp)
    19c6:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    19d0:      	movq	%rax, 0x28(%rsp)
    19d5:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    19df:      	movq	%rax, 0x20(%rsp)
    19e4:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    19ee:      	movq	%rax, 0x18(%rsp)
    19f3:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    19fd:      	movq	%rax, 0x10(%rsp)
    1a02:      	leaq	0x10(%rsp), %rdi
    1a07:      	movl	$0x2d, %eax
    1a0c:      	movl	$0x6, %ecx
    1a11:      	movzbl	0x11(%r15), %eax
    1a16:      	addq	%rax, %r13
    1a19:      	movl	$0x2d, %esi
    1a1e:      	jmp	0x278a <perf_unwind_php+0x278a>
    1a23:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1a2d:      	movq	%rax, 0x36(%rsp)
    1a32:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1a3c:      	movq	%rax, 0x30(%rsp)
    1a41:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1a4b:      	movq	%rax, 0x28(%rsp)
    1a50:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1a5a:      	movq	%rax, 0x20(%rsp)
    1a5f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1a69:      	movq	%rax, 0x18(%rsp)
    1a6e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1a78:      	movq	%rax, 0x10(%rsp)
    1a7d:      	leaq	0x10(%rsp), %rdi
    1a82:      	movl	$0x2e, %eax
    1a87:      	movl	$0x6, %ecx
    1a8c:      	movl	0x58(%rsp), %edx
    1a90:      	movl	$0x2e, %esi
    1a95:      	xorl	%eax, %eax
    1a97:      	callq	*%rcx
    1a99:      	cmpl	$0x23, %r13d
    1a9d:      	je	0x843 <perf_unwind_php+0x843>
    1aa3:      	jmp	0x85e3 <perf_unwind_php+0x85e3>
    1aa8:      	movl	0xc(%rsp), %eax
    1aac:      	movl	%eax, 0x4(%rsp)
    1ab0:      	movl	0x54(%rsp), %r13d
    1ab5:      	movq	(%rip), %rax            # 0x1abc <perf_unwind_php+0x1abc>
    1abc:      	cmpl	$0x0, (%rax)
    1abf:      	jne	0x2796 <perf_unwind_php+0x2796>
    1ac5:      	movl	0x2c0(%rbp), %eax
    1acb:      	cmpq	$0x7e, %rax
    1acf:      	ja	0xb47 <perf_unwind_php+0xb47>
    1ad5:      	movl	0x4(%rsp), %ecx
    1ad9:      	shlq	$0x20, %r13
    1add:      	orq	%r13, %rcx
    1ae0:      	movq	0x58(%rsp), %rdx
    1ae5:      	leal	0x1(%rax), %esi
    1ae8:      	movl	%esi, 0x2c0(%rbp)
    1aee:      	leaq	(%rax,%rax,2), %rax
    1af2:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    1afa:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    1b02:      	movl	0x7c(%rsp), %ecx
    1b06:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    1b0d:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    1b18:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    1b23:      	movl	$0x23, %r13d
    1b29:      	jmp	0x8df <perf_unwind_php+0x8df>
    1b2e:      	movabsq	$0xa6c6c75662073, %rax  # imm = 0xA6C6C75662073
    1b38:      	movq	%rax, 0x2d(%rsp)
    1b3d:      	movabsq	$0x66207369206b6361, %rax # imm = 0x66207369206B6361
    1b47:      	movq	%rax, 0x28(%rsp)
    1b4c:      	movabsq	$0x7473203a656d6172, %rax # imm = 0x7473203A656D6172
    1b56:      	movq	%rax, 0x20(%rsp)
    1b5b:      	movabsq	$0x662068737570206f, %rax # imm = 0x662068737570206F
    1b65:      	movq	%rax, 0x18(%rsp)
    1b6a:      	movabsq	$0x7420656c62616e75, %rax # imm = 0x7420656C62616E75
    1b74:      	movq	%rax, 0x10(%rsp)
    1b79:      	leaq	0x10(%rsp), %rdi
    1b7e:      	movl	$0x25, %eax
    1b83:      	movl	$0x6, %ecx
    1b88:      	movl	$0x25, %esi
    1b8d:      	xorl	%eax, %eax
    1b8f:      	callq	*%rcx
    1b91:      	jmp	0xb58 <perf_unwind_php+0xb58>
    1b96:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    1ba0:      	movq	%rax, 0x38(%rsp)
    1ba5:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    1baf:      	movq	%rax, 0x30(%rsp)
    1bb4:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    1bbe:      	movq	%rax, 0x28(%rsp)
    1bc3:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    1bcd:      	movq	%rax, 0x20(%rsp)
    1bd2:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    1bdc:      	movq	%rax, 0x18(%rsp)
    1be1:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1beb:      	movq	%rax, 0x10(%rsp)
    1bf0:      	movb	$0x0, 0x40(%rsp)
    1bf5:      	leaq	0x10(%rsp), %rdi
    1bfa:      	movl	$0x31, %eax
    1bff:      	movl	$0x6, %ecx
    1c04:      	movq	0x58(%rsp), %rdx
    1c09:      	movl	$0x31, %esi
    1c0e:      	xorl	%eax, %eax
    1c10:      	callq	*%rcx
    1c12:      	jmp	0x81f <perf_unwind_php+0x81f>
    1c17:      	movzbl	0x15(%r15), %eax
    1c1c:      	addq	0x68(%rsp), %rax
    1c21:      	leaq	0xc(%rsp), %rdi
    1c26:      	movl	$0x4, %ecx
    1c2b:      	movl	$0x70, %r8d
    1c31:      	movzbl	0x15(%r15), %edx
    1c36:      	addq	0x68(%rsp), %rdx
    1c3b:      	movl	$0x4, %esi
    1c40:      	callq	*%r8
    1c43:      	testq	%rax, %rax
    1c46:      	je	0x1ec1 <perf_unwind_php+0x1ec1>
    1c4c:      	movq	(%rip), %rax            # 0x1c53 <perf_unwind_php+0x1c53>
    1c53:      	movl	$0x27, 0x4(%rsp)
    1c5b:      	cmpl	$0x0, (%rax)
    1c5e:      	je	0xdd5 <perf_unwind_php+0xdd5>
    1c64:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    1c6e:      	movq	%rax, 0x40(%rsp)
    1c73:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    1c7d:      	movq	%rax, 0x38(%rsp)
    1c82:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    1c8c:      	movq	%rax, 0x30(%rsp)
    1c91:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    1c9b:      	movq	%rax, 0x28(%rsp)
    1ca0:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    1caa:      	movq	%rax, 0x20(%rsp)
    1caf:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    1cb9:      	movq	%rax, 0x18(%rsp)
    1cbe:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1cc8:      	movq	%rax, 0x10(%rsp)
    1ccd:      	movb	$0x0, 0x48(%rsp)
    1cd2:      	leaq	0x10(%rsp), %rdi
    1cd7:      	movl	$0x39, %eax
    1cdc:      	movl	$0x6, %ecx
    1ce1:      	movzbl	0x15(%r15), %edx
    1ce6:      	addq	0x68(%rsp), %rdx
    1ceb:      	movl	$0x39, %esi
    1cf0:      	jmp	0x278d <perf_unwind_php+0x278d>
    1cf5:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1cff:      	movq	%rax, 0x36(%rsp)
    1d04:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1d0e:      	movq	%rax, 0x30(%rsp)
    1d13:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1d1d:      	movq	%rax, 0x28(%rsp)
    1d22:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1d2c:      	movq	%rax, 0x20(%rsp)
    1d31:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1d3b:      	movq	%rax, 0x18(%rsp)
    1d40:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1d4a:      	movq	%rax, 0x10(%rsp)
    1d4f:      	leaq	0x10(%rsp), %rdi
    1d54:      	movl	$0x2e, %eax
    1d59:      	movl	$0x6, %ecx
    1d5e:      	movl	0x68(%rsp), %edx
    1d62:      	movl	$0x2e, %esi
    1d67:      	xorl	%eax, %eax
    1d69:      	callq	*%rcx
    1d6b:      	cmpl	$0x0, (%r15)
    1d6f:      	je	0xbd9 <perf_unwind_php+0xbd9>
    1d75:      	jmp	0xb81 <perf_unwind_php+0xb81>
    1d7a:      	movq	0x58(%rsp), %rax
    1d7f:      	testq	%rax, %rax
    1d82:      	je	0x1f8c <perf_unwind_php+0x1f8c>
    1d88:      	movzbl	0x14(%r15), %ecx
    1d8d:      	addq	%rcx, %rax
    1d90:      	leaq	0xb(%rsp), %rdi
    1d95:      	movl	$0x1, %ecx
    1d9a:      	movl	$0x70, %r8d
    1da0:      	movzbl	0x14(%r15), %edx
    1da5:      	addq	0x58(%rsp), %rdx
    1daa:      	movl	$0x1, %esi
    1daf:      	callq	*%r8
    1db2:      	testq	%rax, %rax
    1db5:      	je	0x20e3 <perf_unwind_php+0x20e3>
    1dbb:      	movq	(%rip), %rax            # 0x1dc2 <perf_unwind_php+0x1dc2>
    1dc2:      	cmpl	$0x0, (%rax)
    1dc5:      	jne	0x3069 <perf_unwind_php+0x3069>
    1dcb:      	movl	$0x26, 0x4(%rsp)
    1dd3:      	jmp	0x1647 <perf_unwind_php+0x1647>
    1dd8:      	movq	(%rip), %rax            # 0x1ddf <perf_unwind_php+0x1ddf>
    1ddf:      	cmpl	$0x0, (%rax)
    1de2:      	jne	0x2f79 <perf_unwind_php+0x2f79>
    1de8:      	cmpl	$0x23, 0x4(%rsp)
    1ded:      	jne	0x85e3 <perf_unwind_php+0x85e3>
    1df3:      	movzbl	0x12(%r15), %eax
    1df8:      	addq	0x70(%rsp), %rax
    1dfd:      	leaq	0x70(%rsp), %rdi
    1e02:      	movl	$0x8, %ecx
    1e07:      	movl	$0x70, %r8d
    1e0d:      	movzbl	0x12(%r15), %edx
    1e12:      	addq	0x70(%rsp), %rdx
    1e17:      	movl	$0x8, %esi
    1e1c:      	callq	*%r8
    1e1f:      	testq	%rax, %rax
    1e22:      	jne	0x317 <perf_unwind_php+0x317>
    1e28:      	movq	0x70(%rsp), %r13
    1e2d:      	testq	%r13, %r13
    1e30:      	je	0x83ba <perf_unwind_php+0x83ba>
    1e36:      	testb	$0x2, 0x56(%rsp)
    1e3b:      	jne	0x83ba <perf_unwind_php+0x83ba>
    1e41:      	movzbl	0x10(%r15), %eax
    1e46:      	addq	%r13, %rax
    1e49:      	leaq	0x58(%rsp), %rdi
    1e4e:      	movl	$0x8, %ecx
    1e53:      	movl	$0x70, %r8d
    1e59:      	movzbl	0x10(%r15), %edx
    1e5e:      	addq	%r13, %rdx
    1e61:      	movl	$0x8, %esi
    1e66:      	callq	*%r8
    1e69:      	testq	%rax, %rax
    1e6c:      	je	0x2418 <perf_unwind_php+0x2418>
    1e72:      	movq	(%rip), %rax            # 0x1e79 <perf_unwind_php+0x1e79>
    1e79:      	movl	$0x25, 0x4(%rsp)
    1e81:      	cmpl	$0x0, (%rax)
    1e84:      	jne	0x343a <perf_unwind_php+0x343a>
    1e8a:      	movl	0x4(%rsp), %eax
    1e8e:      	movl	%eax, 0x58(%rsp)
    1e92:      	movq	(%rip), %rdi            # 0x1e99 <perf_unwind_php+0x1e99>
    1e99:      	leaq	0x58(%rsp), %rsi
    1e9e:      	movl	$0x1, %eax
    1ea3:      	callq	*%rax
    1ea5:      	testq	%rax, %rax
    1ea8:      	je	0x2476 <perf_unwind_php+0x2476>
    1eae:      	incq	(%rax)
    1eb1:      	cmpl	$0x23, 0x4(%rsp)
    1eb6:      	je	0x2491 <perf_unwind_php+0x2491>
    1ebc:      	jmp	0x85e3 <perf_unwind_php+0x85e3>
    1ec1:      	movzbl	0x13(%r15), %eax
    1ec6:      	addq	%r13, %rax
    1ec9:      	leaq	0x54(%rsp), %rdi
    1ece:      	movl	$0x4, %ecx
    1ed3:      	movl	$0x70, %r8d
    1ed9:      	movzbl	0x13(%r15), %edx
    1ede:      	addq	%r13, %rdx
    1ee1:      	movl	$0x4, %esi
    1ee6:      	callq	*%r8
    1ee9:      	testq	%rax, %rax
    1eec:      	je	0x224f <perf_unwind_php+0x224f>
    1ef2:      	movq	(%rip), %rax            # 0x1ef9 <perf_unwind_php+0x1ef9>
    1ef9:      	movl	$0x25, 0x4(%rsp)
    1f01:      	cmpl	$0x0, (%rax)
    1f04:      	je	0xdd5 <perf_unwind_php+0xdd5>
    1f0a:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    1f14:      	movq	%rax, 0x3d(%rsp)
    1f19:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    1f23:      	movq	%rax, 0x38(%rsp)
    1f28:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    1f32:      	movq	%rax, 0x30(%rsp)
    1f37:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    1f41:      	movq	%rax, 0x28(%rsp)
    1f46:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    1f50:      	movq	%rax, 0x20(%rsp)
    1f55:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    1f5f:      	movq	%rax, 0x18(%rsp)
    1f64:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1f6e:      	movq	%rax, 0x10(%rsp)
    1f73:      	leaq	0x10(%rsp), %rdi
    1f78:      	movl	$0x35, %eax
    1f7d:      	movl	$0x6, %ecx
    1f82:      	movl	$0x35, %esi
    1f87:      	jmp	0x278a <perf_unwind_php+0x278a>
    1f8c:      	movl	0x2c0(%rbp), %eax
    1f92:      	cmpq	$0x7e, %rax
    1f96:      	ja	0x40e <perf_unwind_php+0x40e>
    1f9c:      	leal	0x1(%rax), %ecx
    1f9f:      	movl	%ecx, 0x2c0(%rbp)
    1fa5:      	leaq	(%rax,%rax,2), %rax
    1fa9:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    1fb5:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    1fc1:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    1fc9:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    1fd4:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    1fdf:      	movl	$0x23, 0x4(%rsp)
    1fe7:      	jmp	0x1647 <perf_unwind_php+0x1647>
    1fec:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    1ff6:      	movq	%rax, 0x38(%rsp)
    1ffb:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    2005:      	movq	%rax, 0x30(%rsp)
    200a:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    2014:      	movq	%rax, 0x28(%rsp)
    2019:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    2023:      	movq	%rax, 0x20(%rsp)
    2028:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    2032:      	movq	%rax, 0x18(%rsp)
    2037:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2041:      	movq	%rax, 0x10(%rsp)
    2046:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    204e:      	leaq	0x10(%rsp), %rdi
    2053:      	movl	$0x33, %eax
    2058:      	movl	$0x6, %ecx
    205d:      	movzbl	0x10(%r15), %eax
    2062:      	addq	%rax, %r13
    2065:      	movl	$0x33, %esi
    206a:      	movq	%r13, %rdx
    206d:      	xorl	%eax, %eax
    206f:      	callq	*%rcx
    2071:      	jmp	0x8da <perf_unwind_php+0x8da>
    2076:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    2080:      	movq	%rax, 0x1e(%rsp)
    2085:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    208f:      	movq	%rax, 0x18(%rsp)
    2094:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    209e:      	movq	%rax, 0x10(%rsp)
    20a3:      	leaq	0x10(%rsp), %rdi
    20a8:      	movl	$0x16, %eax
    20ad:      	movl	$0x6, %r8d
    20b3:      	movq	0x58(%rsp), %rdx
    20b8:      	movl	%ecx, 0x4(%rsp)
    20bc:      	movl	0xc(%rsp), %ecx
    20c0:      	movl	$0x16, %esi
    20c5:      	xorl	%eax, %eax
    20c7:      	callq	*%r8
    20ca:      	movl	0x4(%rsp), %ecx
    20ce:      	movl	0x2c0(%rbp), %eax
    20d4:      	cmpq	$0x7e, %rax
    20d8:      	ja	0xb47 <perf_unwind_php+0xb47>
    20de:      	jmp	0x1288 <perf_unwind_php+0x1288>
    20e3:      	movl	$0x0, 0xc(%rsp)
    20eb:      	movzbl	0xb(%rsp), %eax
    20f0:      	cmpl	$0x4, %eax
    20f3:      	je	0x2106 <perf_unwind_php+0x2106>
    20f5:      	movl	$0x0, 0x4(%rsp)
    20fd:      	cmpl	$0x2, %eax
    2100:      	jne	0x2970 <perf_unwind_php+0x2970>
    2106:      	movzbl	0x11(%r15), %eax
    210b:      	addq	%r13, %rax
    210e:      	leaq	0x68(%rsp), %rdi
    2113:      	movl	$0x8, %ecx
    2118:      	movl	$0x70, %r8d
    211e:      	movzbl	0x11(%r15), %edx
    2123:      	addq	%r13, %rdx
    2126:      	movl	$0x8, %esi
    212b:      	callq	*%r8
    212e:      	testq	%rax, %rax
    2131:      	je	0x233a <perf_unwind_php+0x233a>
    2137:      	movq	(%rip), %rax            # 0x213e <perf_unwind_php+0x213e>
    213e:      	movl	$0x25, 0x4(%rsp)
    2146:      	cmpl	$0x0, (%rax)
    2149:      	je	0x1647 <perf_unwind_php+0x1647>
    214f:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    2159:      	movq	%rax, 0x35(%rsp)
    215e:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    2168:      	movq	%rax, 0x30(%rsp)
    216d:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    2177:      	movq	%rax, 0x28(%rsp)
    217c:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    2186:      	movq	%rax, 0x20(%rsp)
    218b:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    2195:      	movq	%rax, 0x18(%rsp)
    219a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    21a4:      	movq	%rax, 0x10(%rsp)
    21a9:      	leaq	0x10(%rsp), %rdi
    21ae:      	movl	$0x2d, %eax
    21b3:      	movl	$0x6, %ecx
    21b8:      	movzbl	0x11(%r15), %eax
    21bd:      	addq	%rax, %r13
    21c0:      	movl	$0x2d, %esi
    21c5:      	jmp	0x2e21 <perf_unwind_php+0x2e21>
    21ca:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    21d4:      	movq	%rax, 0x36(%rsp)
    21d9:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    21e3:      	movq	%rax, 0x30(%rsp)
    21e8:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    21f2:      	movq	%rax, 0x28(%rsp)
    21f7:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2201:      	movq	%rax, 0x20(%rsp)
    2206:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2210:      	movq	%rax, 0x18(%rsp)
    2215:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    221f:      	movq	%rax, 0x10(%rsp)
    2224:      	leaq	0x10(%rsp), %rdi
    2229:      	movl	$0x2e, %eax
    222e:      	movl	$0x6, %ecx
    2233:      	movl	0x58(%rsp), %edx
    2237:      	movl	$0x2e, %esi
    223c:      	xorl	%eax, %eax
    223e:      	callq	*%rcx
    2240:      	cmpl	$0x23, %r13d
    2244:      	je	0xd3e <perf_unwind_php+0xd3e>
    224a:      	jmp	0x85e3 <perf_unwind_php+0x85e3>
    224f:      	movl	0xc(%rsp), %eax
    2253:      	movl	%eax, 0x4(%rsp)
    2257:      	movl	0x54(%rsp), %r13d
    225c:      	movq	(%rip), %rax            # 0x2263 <perf_unwind_php+0x2263>
    2263:      	cmpl	$0x0, (%rax)
    2266:      	jne	0x2e2d <perf_unwind_php+0x2e2d>
    226c:      	movl	0x2c0(%rbp), %eax
    2272:      	cmpq	$0x7e, %rax
    2276:      	ja	0xb47 <perf_unwind_php+0xb47>
    227c:      	movl	0x4(%rsp), %ecx
    2280:      	shlq	$0x20, %r13
    2284:      	orq	%r13, %rcx
    2287:      	movq	0x58(%rsp), %rdx
    228c:      	leal	0x1(%rax), %esi
    228f:      	movl	%esi, 0x2c0(%rbp)
    2295:      	leaq	(%rax,%rax,2), %rax
    2299:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    22a1:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    22a9:      	movl	0x7c(%rsp), %ecx
    22ad:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    22b4:      	jmp	0x17ee <perf_unwind_php+0x17ee>
    22b9:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    22c3:      	movq	%rax, 0x38(%rsp)
    22c8:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    22d2:      	movq	%rax, 0x30(%rsp)
    22d7:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    22e1:      	movq	%rax, 0x28(%rsp)
    22e6:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    22f0:      	movq	%rax, 0x20(%rsp)
    22f5:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    22ff:      	movq	%rax, 0x18(%rsp)
    2304:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    230e:      	movq	%rax, 0x10(%rsp)
    2313:      	movb	$0x0, 0x40(%rsp)
    2318:      	leaq	0x10(%rsp), %rdi
    231d:      	movl	$0x31, %eax
    2322:      	movl	$0x6, %ecx
    2327:      	movq	0x58(%rsp), %rdx
    232c:      	movl	$0x31, %esi
    2331:      	xorl	%eax, %eax
    2333:      	callq	*%rcx
    2335:      	jmp	0xd19 <perf_unwind_php+0xd19>
    233a:      	movzbl	0x15(%r15), %eax
    233f:      	addq	0x68(%rsp), %rax
    2344:      	leaq	0xc(%rsp), %rdi
    2349:      	movl	$0x4, %ecx
    234e:      	movl	$0x70, %r8d
    2354:      	movzbl	0x15(%r15), %edx
    2359:      	addq	0x68(%rsp), %rdx
    235e:      	movl	$0x4, %esi
    2363:      	callq	*%r8
    2366:      	testq	%rax, %rax
    2369:      	je	0x25e1 <perf_unwind_php+0x25e1>
    236f:      	movq	(%rip), %rax            # 0x2376 <perf_unwind_php+0x2376>
    2376:      	movl	$0x27, 0x4(%rsp)
    237e:      	cmpl	$0x0, (%rax)
    2381:      	je	0x1647 <perf_unwind_php+0x1647>
    2387:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    2391:      	movq	%rax, 0x40(%rsp)
    2396:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    23a0:      	movq	%rax, 0x38(%rsp)
    23a5:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    23af:      	movq	%rax, 0x30(%rsp)
    23b4:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    23be:      	movq	%rax, 0x28(%rsp)
    23c3:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    23cd:      	movq	%rax, 0x20(%rsp)
    23d2:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    23dc:      	movq	%rax, 0x18(%rsp)
    23e1:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    23eb:      	movq	%rax, 0x10(%rsp)
    23f0:      	movb	$0x0, 0x48(%rsp)
    23f5:      	leaq	0x10(%rsp), %rdi
    23fa:      	movl	$0x39, %eax
    23ff:      	movl	$0x6, %ecx
    2404:      	movzbl	0x15(%r15), %edx
    2409:      	addq	0x68(%rsp), %rdx
    240e:      	movl	$0x39, %esi
    2413:      	jmp	0x2e24 <perf_unwind_php+0x2e24>
    2418:      	movq	0x58(%rsp), %rax
    241d:      	testq	%rax, %rax
    2420:      	je	0x26ac <perf_unwind_php+0x26ac>
    2426:      	movzbl	0x14(%r15), %ecx
    242b:      	addq	%rcx, %rax
    242e:      	leaq	0xb(%rsp), %rdi
    2433:      	movl	$0x1, %ecx
    2438:      	movl	$0x70, %r8d
    243e:      	movzbl	0x14(%r15), %edx
    2443:      	addq	0x58(%rsp), %rdx
    2448:      	movl	$0x1, %esi
    244d:      	callq	*%r8
    2450:      	testq	%rax, %rax
    2453:      	je	0x27fb <perf_unwind_php+0x27fb>
    2459:      	movq	(%rip), %rax            # 0x2460 <perf_unwind_php+0x2460>
    2460:      	cmpl	$0x0, (%rax)
    2463:      	jne	0x3700 <perf_unwind_php+0x3700>
    2469:      	movl	$0x26, 0x4(%rsp)
    2471:      	jmp	0x1e8a <perf_unwind_php+0x1e8a>
    2476:      	movq	(%rip), %rax            # 0x247d <perf_unwind_php+0x247d>
    247d:      	cmpl	$0x0, (%rax)
    2480:      	jne	0x3610 <perf_unwind_php+0x3610>
    2486:      	cmpl	$0x23, 0x4(%rsp)
    248b:      	jne	0x85e3 <perf_unwind_php+0x85e3>
    2491:      	movzbl	0x12(%r15), %eax
    2496:      	addq	0x70(%rsp), %rax
    249b:      	leaq	0x70(%rsp), %rdi
    24a0:      	movl	$0x8, %ecx
    24a5:      	movl	$0x70, %r8d
    24ab:      	movzbl	0x12(%r15), %edx
    24b0:      	addq	0x70(%rsp), %rdx
    24b5:      	movl	$0x8, %esi
    24ba:      	callq	*%r8
    24bd:      	testq	%rax, %rax
    24c0:      	jne	0x317 <perf_unwind_php+0x317>
    24c6:      	movq	0x70(%rsp), %r13
    24cb:      	testq	%r13, %r13
    24ce:      	je	0x83ba <perf_unwind_php+0x83ba>
    24d4:      	testb	$0x2, 0x56(%rsp)
    24d9:      	jne	0x83ba <perf_unwind_php+0x83ba>
    24df:      	movzbl	0x10(%r15), %eax
    24e4:      	addq	%r13, %rax
    24e7:      	leaq	0x58(%rsp), %rdi
    24ec:      	movl	$0x8, %ecx
    24f1:      	movl	$0x70, %r8d
    24f7:      	movzbl	0x10(%r15), %edx
    24fc:      	addq	%r13, %rdx
    24ff:      	movl	$0x8, %esi
    2504:      	callq	*%r8
    2507:      	testq	%rax, %rax
    250a:      	je	0x2b31 <perf_unwind_php+0x2b31>
    2510:      	movq	(%rip), %rax            # 0x2517 <perf_unwind_php+0x2517>
    2517:      	movl	$0x25, 0x4(%rsp)
    251f:      	cmpl	$0x0, (%rax)
    2522:      	jne	0x3ad1 <perf_unwind_php+0x3ad1>
    2528:      	movl	0x4(%rsp), %eax
    252c:      	movl	%eax, 0x58(%rsp)
    2530:      	movq	(%rip), %rdi            # 0x2537 <perf_unwind_php+0x2537>
    2537:      	leaq	0x58(%rsp), %rsi
    253c:      	movl	$0x1, %eax
    2541:      	callq	*%rax
    2543:      	testq	%rax, %rax
    2546:      	je	0x2b8f <perf_unwind_php+0x2b8f>
    254c:      	incq	(%rax)
    254f:      	cmpl	$0x23, 0x4(%rsp)
    2554:      	je	0x2baa <perf_unwind_php+0x2baa>
    255a:      	jmp	0x85e3 <perf_unwind_php+0x85e3>
    255f:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    2569:      	movq	%rax, 0x3d(%rsp)
    256e:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    2578:      	movq	%rax, 0x38(%rsp)
    257d:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    2587:      	movq	%rax, 0x30(%rsp)
    258c:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    2596:      	movq	%rax, 0x28(%rsp)
    259b:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    25a5:      	movq	%rax, 0x20(%rsp)
    25aa:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    25b4:      	movq	%rax, 0x18(%rsp)
    25b9:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    25c3:      	movq	%rax, 0x10(%rsp)
    25c8:      	leaq	0x10(%rsp), %rdi
    25cd:      	movl	$0x35, %eax
    25d2:      	movl	$0x6, %ecx
    25d7:      	movl	$0x35, %esi
    25dc:      	jmp	0xb11 <perf_unwind_php+0xb11>
    25e1:      	movzbl	0x13(%r15), %eax
    25e6:      	addq	%r13, %rax
    25e9:      	leaq	0x54(%rsp), %rdi
    25ee:      	movl	$0x4, %ecx
    25f3:      	movl	$0x70, %r8d
    25f9:      	movzbl	0x13(%r15), %edx
    25fe:      	addq	%r13, %rdx
    2601:      	movl	$0x4, %esi
    2606:      	callq	*%r8
    2609:      	testq	%rax, %rax
    260c:      	je	0x2968 <perf_unwind_php+0x2968>
    2612:      	movq	(%rip), %rax            # 0x2619 <perf_unwind_php+0x2619>
    2619:      	movl	$0x25, 0x4(%rsp)
    2621:      	cmpl	$0x0, (%rax)
    2624:      	je	0x1647 <perf_unwind_php+0x1647>
    262a:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    2634:      	movq	%rax, 0x3d(%rsp)
    2639:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    2643:      	movq	%rax, 0x38(%rsp)
    2648:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    2652:      	movq	%rax, 0x30(%rsp)
    2657:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    2661:      	movq	%rax, 0x28(%rsp)
    2666:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    2670:      	movq	%rax, 0x20(%rsp)
    2675:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    267f:      	movq	%rax, 0x18(%rsp)
    2684:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    268e:      	movq	%rax, 0x10(%rsp)
    2693:      	leaq	0x10(%rsp), %rdi
    2698:      	movl	$0x35, %eax
    269d:      	movl	$0x6, %ecx
    26a2:      	movl	$0x35, %esi
    26a7:      	jmp	0x2e21 <perf_unwind_php+0x2e21>
    26ac:      	movl	0x2c0(%rbp), %eax
    26b2:      	cmpq	$0x7e, %rax
    26b6:      	ja	0x40e <perf_unwind_php+0x40e>
    26bc:      	leal	0x1(%rax), %ecx
    26bf:      	movl	%ecx, 0x2c0(%rbp)
    26c5:      	leaq	(%rax,%rax,2), %rax
    26c9:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    26d5:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    26e1:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    26e9:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    26f4:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    26ff:      	movl	$0x23, 0x4(%rsp)
    2707:      	jmp	0x1e8a <perf_unwind_php+0x1e8a>
    270c:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    2716:      	movq	%rax, 0x38(%rsp)
    271b:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    2725:      	movq	%rax, 0x30(%rsp)
    272a:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    2734:      	movq	%rax, 0x28(%rsp)
    2739:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    2743:      	movq	%rax, 0x20(%rsp)
    2748:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    2752:      	movq	%rax, 0x18(%rsp)
    2757:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2761:      	movq	%rax, 0x10(%rsp)
    2766:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    276e:      	leaq	0x10(%rsp), %rdi
    2773:      	movl	$0x33, %eax
    2778:      	movl	$0x6, %ecx
    277d:      	movzbl	0x10(%r15), %eax
    2782:      	addq	%rax, %r13
    2785:      	movl	$0x33, %esi
    278a:      	movq	%r13, %rdx
    278d:      	xorl	%eax, %eax
    278f:      	callq	*%rcx
    2791:      	jmp	0xdd5 <perf_unwind_php+0xdd5>
    2796:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    27a0:      	movq	%rax, 0x1e(%rsp)
    27a5:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    27af:      	movq	%rax, 0x18(%rsp)
    27b4:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    27be:      	movq	%rax, 0x10(%rsp)
    27c3:      	leaq	0x10(%rsp), %rdi
    27c8:      	movl	$0x16, %eax
    27cd:      	movl	$0x6, %r8d
    27d3:      	movq	0x58(%rsp), %rdx
    27d8:      	movl	0xc(%rsp), %ecx
    27dc:      	movl	$0x16, %esi
    27e1:      	xorl	%eax, %eax
    27e3:      	callq	*%r8
    27e6:      	movl	0x2c0(%rbp), %eax
    27ec:      	cmpq	$0x7e, %rax
    27f0:      	ja	0xb47 <perf_unwind_php+0xb47>
    27f6:      	jmp	0x1ad5 <perf_unwind_php+0x1ad5>
    27fb:      	movl	$0x0, 0xc(%rsp)
    2803:      	movzbl	0xb(%rsp), %eax
    2808:      	cmpl	$0x4, %eax
    280b:      	je	0x281e <perf_unwind_php+0x281e>
    280d:      	movl	$0x0, 0x4(%rsp)
    2815:      	cmpl	$0x2, %eax
    2818:      	jne	0x3007 <perf_unwind_php+0x3007>
    281e:      	movzbl	0x11(%r15), %eax
    2823:      	addq	%r13, %rax
    2826:      	leaq	0x68(%rsp), %rdi
    282b:      	movl	$0x8, %ecx
    2830:      	movl	$0x70, %r8d
    2836:      	movzbl	0x11(%r15), %edx
    283b:      	addq	%r13, %rdx
    283e:      	movl	$0x8, %esi
    2843:      	callq	*%r8
    2846:      	testq	%rax, %rax
    2849:      	je	0x2a53 <perf_unwind_php+0x2a53>
    284f:      	movq	(%rip), %rax            # 0x2856 <perf_unwind_php+0x2856>
    2856:      	movl	$0x25, 0x4(%rsp)
    285e:      	cmpl	$0x0, (%rax)
    2861:      	je	0x1e8a <perf_unwind_php+0x1e8a>
    2867:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    2871:      	movq	%rax, 0x35(%rsp)
    2876:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    2880:      	movq	%rax, 0x30(%rsp)
    2885:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    288f:      	movq	%rax, 0x28(%rsp)
    2894:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    289e:      	movq	%rax, 0x20(%rsp)
    28a3:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    28ad:      	movq	%rax, 0x18(%rsp)
    28b2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    28bc:      	movq	%rax, 0x10(%rsp)
    28c1:      	leaq	0x10(%rsp), %rdi
    28c6:      	movl	$0x2d, %eax
    28cb:      	movl	$0x6, %ecx
    28d0:      	movzbl	0x11(%r15), %eax
    28d5:      	addq	%rax, %r13
    28d8:      	movl	$0x2d, %esi
    28dd:      	jmp	0x34b8 <perf_unwind_php+0x34b8>
    28e2:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    28ec:      	movq	%rax, 0x36(%rsp)
    28f1:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    28fb:      	movq	%rax, 0x30(%rsp)
    2900:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    290a:      	movq	%rax, 0x28(%rsp)
    290f:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2919:      	movq	%rax, 0x20(%rsp)
    291e:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2928:      	movq	%rax, 0x18(%rsp)
    292d:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2937:      	movq	%rax, 0x10(%rsp)
    293c:      	leaq	0x10(%rsp), %rdi
    2941:      	movl	$0x2e, %eax
    2946:      	movl	$0x6, %ecx
    294b:      	movl	0x58(%rsp), %edx
    294f:      	movl	$0x2e, %esi
    2954:      	xorl	%eax, %eax
    2956:      	callq	*%rcx
    2958:      	cmpl	$0x23, 0x4(%rsp)
    295d:      	je	0x15b0 <perf_unwind_php+0x15b0>
    2963:      	jmp	0x85e3 <perf_unwind_php+0x85e3>
    2968:      	movl	0xc(%rsp), %eax
    296c:      	movl	%eax, 0x4(%rsp)
    2970:      	movl	0x54(%rsp), %r13d
    2975:      	movq	(%rip), %rax            # 0x297c <perf_unwind_php+0x297c>
    297c:      	cmpl	$0x0, (%rax)
    297f:      	jne	0x34c4 <perf_unwind_php+0x34c4>
    2985:      	movl	0x2c0(%rbp), %eax
    298b:      	cmpq	$0x7e, %rax
    298f:      	ja	0xb47 <perf_unwind_php+0xb47>
    2995:      	movl	0x4(%rsp), %ecx
    2999:      	shlq	$0x20, %r13
    299d:      	orq	%r13, %rcx
    29a0:      	movq	0x58(%rsp), %rdx
    29a5:      	leal	0x1(%rax), %esi
    29a8:      	movl	%esi, 0x2c0(%rbp)
    29ae:      	leaq	(%rax,%rax,2), %rax
    29b2:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    29ba:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    29c2:      	movl	0x7c(%rsp), %ecx
    29c6:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    29cd:      	jmp	0x1fc9 <perf_unwind_php+0x1fc9>
    29d2:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    29dc:      	movq	%rax, 0x38(%rsp)
    29e1:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    29eb:      	movq	%rax, 0x30(%rsp)
    29f0:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    29fa:      	movq	%rax, 0x28(%rsp)
    29ff:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    2a09:      	movq	%rax, 0x20(%rsp)
    2a0e:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    2a18:      	movq	%rax, 0x18(%rsp)
    2a1d:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2a27:      	movq	%rax, 0x10(%rsp)
    2a2c:      	movb	$0x0, 0x40(%rsp)
    2a31:      	leaq	0x10(%rsp), %rdi
    2a36:      	movl	$0x31, %eax
    2a3b:      	movl	$0x6, %ecx
    2a40:      	movq	0x58(%rsp), %rdx
    2a45:      	movl	$0x31, %esi
    2a4a:      	xorl	%eax, %eax
    2a4c:      	callq	*%rcx
    2a4e:      	jmp	0x1588 <perf_unwind_php+0x1588>
    2a53:      	movzbl	0x15(%r15), %eax
    2a58:      	addq	0x68(%rsp), %rax
    2a5d:      	leaq	0xc(%rsp), %rdi
    2a62:      	movl	$0x4, %ecx
    2a67:      	movl	$0x70, %r8d
    2a6d:      	movzbl	0x15(%r15), %edx
    2a72:      	addq	0x68(%rsp), %rdx
    2a77:      	movl	$0x4, %esi
    2a7c:      	callq	*%r8
    2a7f:      	testq	%rax, %rax
    2a82:      	je	0x2c78 <perf_unwind_php+0x2c78>
    2a88:      	movq	(%rip), %rax            # 0x2a8f <perf_unwind_php+0x2a8f>
    2a8f:      	movl	$0x27, 0x4(%rsp)
    2a97:      	cmpl	$0x0, (%rax)
    2a9a:      	je	0x1e8a <perf_unwind_php+0x1e8a>
    2aa0:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    2aaa:      	movq	%rax, 0x40(%rsp)
    2aaf:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    2ab9:      	movq	%rax, 0x38(%rsp)
    2abe:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    2ac8:      	movq	%rax, 0x30(%rsp)
    2acd:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    2ad7:      	movq	%rax, 0x28(%rsp)
    2adc:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    2ae6:      	movq	%rax, 0x20(%rsp)
    2aeb:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    2af5:      	movq	%rax, 0x18(%rsp)
    2afa:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2b04:      	movq	%rax, 0x10(%rsp)
    2b09:      	movb	$0x0, 0x48(%rsp)
    2b0e:      	leaq	0x10(%rsp), %rdi
    2b13:      	movl	$0x39, %eax
    2b18:      	movl	$0x6, %ecx
    2b1d:      	movzbl	0x15(%r15), %edx
    2b22:      	addq	0x68(%rsp), %rdx
    2b27:      	movl	$0x39, %esi
    2b2c:      	jmp	0x34bb <perf_unwind_php+0x34bb>
    2b31:      	movq	0x58(%rsp), %rax
    2b36:      	testq	%rax, %rax
    2b39:      	je	0x2d43 <perf_unwind_php+0x2d43>
    2b3f:      	movzbl	0x14(%r15), %ecx
    2b44:      	addq	%rcx, %rax
    2b47:      	leaq	0xb(%rsp), %rdi
    2b4c:      	movl	$0x1, %ecx
    2b51:      	movl	$0x70, %r8d
    2b57:      	movzbl	0x14(%r15), %edx
    2b5c:      	addq	0x58(%rsp), %rdx
    2b61:      	movl	$0x1, %esi
    2b66:      	callq	*%r8
    2b69:      	testq	%rax, %rax
    2b6c:      	je	0x2e92 <perf_unwind_php+0x2e92>
    2b72:      	movq	(%rip), %rax            # 0x2b79 <perf_unwind_php+0x2b79>
    2b79:      	cmpl	$0x0, (%rax)
    2b7c:      	jne	0x3d97 <perf_unwind_php+0x3d97>
    2b82:      	movl	$0x26, 0x4(%rsp)
    2b8a:      	jmp	0x2528 <perf_unwind_php+0x2528>
    2b8f:      	movq	(%rip), %rax            # 0x2b96 <perf_unwind_php+0x2b96>
    2b96:      	cmpl	$0x0, (%rax)
    2b99:      	jne	0x3ca7 <perf_unwind_php+0x3ca7>
    2b9f:      	cmpl	$0x23, 0x4(%rsp)
    2ba4:      	jne	0x85e3 <perf_unwind_php+0x85e3>
    2baa:      	movzbl	0x12(%r15), %eax
    2baf:      	addq	0x70(%rsp), %rax
    2bb4:      	leaq	0x70(%rsp), %rdi
    2bb9:      	movl	$0x8, %ecx
    2bbe:      	movl	$0x70, %r8d
    2bc4:      	movzbl	0x12(%r15), %edx
    2bc9:      	addq	0x70(%rsp), %rdx
    2bce:      	movl	$0x8, %esi
    2bd3:      	callq	*%r8
    2bd6:      	testq	%rax, %rax
    2bd9:      	jne	0x317 <perf_unwind_php+0x317>
    2bdf:      	movq	0x70(%rsp), %r13
    2be4:      	testq	%r13, %r13
    2be7:      	je	0x83ba <perf_unwind_php+0x83ba>
    2bed:      	testb	$0x2, 0x56(%rsp)
    2bf2:      	jne	0x83ba <perf_unwind_php+0x83ba>
    2bf8:      	movzbl	0x10(%r15), %eax
    2bfd:      	addq	%r13, %rax
    2c00:      	leaq	0x58(%rsp), %rdi
    2c05:      	movl	$0x8, %ecx
    2c0a:      	movl	$0x70, %r8d
    2c10:      	movzbl	0x10(%r15), %edx
    2c15:      	addq	%r13, %rdx
    2c18:      	movl	$0x8, %esi
    2c1d:      	callq	*%r8
    2c20:      	testq	%rax, %rax
    2c23:      	je	0x31c8 <perf_unwind_php+0x31c8>
    2c29:      	movq	(%rip), %rax            # 0x2c30 <perf_unwind_php+0x2c30>
    2c30:      	movl	$0x25, 0x4(%rsp)
    2c38:      	cmpl	$0x0, (%rax)
    2c3b:      	jne	0x4168 <perf_unwind_php+0x4168>
    2c41:      	movl	0x4(%rsp), %eax
    2c45:      	movl	%eax, 0x58(%rsp)
    2c49:      	movq	(%rip), %rdi            # 0x2c50 <perf_unwind_php+0x2c50>
    2c50:      	leaq	0x58(%rsp), %rsi
    2c55:      	movl	$0x1, %eax
    2c5a:      	callq	*%rax
    2c5c:      	testq	%rax, %rax
    2c5f:      	je	0x3226 <perf_unwind_php+0x3226>
    2c65:      	incq	(%rax)
    2c68:      	cmpl	$0x23, 0x4(%rsp)
    2c6d:      	je	0x3241 <perf_unwind_php+0x3241>
    2c73:      	jmp	0x85e3 <perf_unwind_php+0x85e3>
    2c78:      	movzbl	0x13(%r15), %eax
    2c7d:      	addq	%r13, %rax
    2c80:      	leaq	0x54(%rsp), %rdi
    2c85:      	movl	$0x4, %ecx
    2c8a:      	movl	$0x70, %r8d
    2c90:      	movzbl	0x13(%r15), %edx
    2c95:      	addq	%r13, %rdx
    2c98:      	movl	$0x4, %esi
    2c9d:      	callq	*%r8
    2ca0:      	testq	%rax, %rax
    2ca3:      	je	0x2fff <perf_unwind_php+0x2fff>
    2ca9:      	movq	(%rip), %rax            # 0x2cb0 <perf_unwind_php+0x2cb0>
    2cb0:      	movl	$0x25, 0x4(%rsp)
    2cb8:      	cmpl	$0x0, (%rax)
    2cbb:      	je	0x1e8a <perf_unwind_php+0x1e8a>
    2cc1:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    2ccb:      	movq	%rax, 0x3d(%rsp)
    2cd0:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    2cda:      	movq	%rax, 0x38(%rsp)
    2cdf:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    2ce9:      	movq	%rax, 0x30(%rsp)
    2cee:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    2cf8:      	movq	%rax, 0x28(%rsp)
    2cfd:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    2d07:      	movq	%rax, 0x20(%rsp)
    2d0c:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    2d16:      	movq	%rax, 0x18(%rsp)
    2d1b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2d25:      	movq	%rax, 0x10(%rsp)
    2d2a:      	leaq	0x10(%rsp), %rdi
    2d2f:      	movl	$0x35, %eax
    2d34:      	movl	$0x6, %ecx
    2d39:      	movl	$0x35, %esi
    2d3e:      	jmp	0x34b8 <perf_unwind_php+0x34b8>
    2d43:      	movl	0x2c0(%rbp), %eax
    2d49:      	cmpq	$0x7e, %rax
    2d4d:      	ja	0x40e <perf_unwind_php+0x40e>
    2d53:      	leal	0x1(%rax), %ecx
    2d56:      	movl	%ecx, 0x2c0(%rbp)
    2d5c:      	leaq	(%rax,%rax,2), %rax
    2d60:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    2d6c:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    2d78:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    2d80:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    2d8b:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    2d96:      	movl	$0x23, 0x4(%rsp)
    2d9e:      	jmp	0x2528 <perf_unwind_php+0x2528>
    2da3:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    2dad:      	movq	%rax, 0x38(%rsp)
    2db2:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    2dbc:      	movq	%rax, 0x30(%rsp)
    2dc1:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    2dcb:      	movq	%rax, 0x28(%rsp)
    2dd0:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    2dda:      	movq	%rax, 0x20(%rsp)
    2ddf:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    2de9:      	movq	%rax, 0x18(%rsp)
    2dee:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2df8:      	movq	%rax, 0x10(%rsp)
    2dfd:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    2e05:      	leaq	0x10(%rsp), %rdi
    2e0a:      	movl	$0x33, %eax
    2e0f:      	movl	$0x6, %ecx
    2e14:      	movzbl	0x10(%r15), %eax
    2e19:      	addq	%rax, %r13
    2e1c:      	movl	$0x33, %esi
    2e21:      	movq	%r13, %rdx
    2e24:      	xorl	%eax, %eax
    2e26:      	callq	*%rcx
    2e28:      	jmp	0x1647 <perf_unwind_php+0x1647>
    2e2d:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    2e37:      	movq	%rax, 0x1e(%rsp)
    2e3c:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    2e46:      	movq	%rax, 0x18(%rsp)
    2e4b:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    2e55:      	movq	%rax, 0x10(%rsp)
    2e5a:      	leaq	0x10(%rsp), %rdi
    2e5f:      	movl	$0x16, %eax
    2e64:      	movl	$0x6, %r8d
    2e6a:      	movq	0x58(%rsp), %rdx
    2e6f:      	movl	0xc(%rsp), %ecx
    2e73:      	movl	$0x16, %esi
    2e78:      	xorl	%eax, %eax
    2e7a:      	callq	*%r8
    2e7d:      	movl	0x2c0(%rbp), %eax
    2e83:      	cmpq	$0x7e, %rax
    2e87:      	ja	0xb47 <perf_unwind_php+0xb47>
    2e8d:      	jmp	0x227c <perf_unwind_php+0x227c>
    2e92:      	movl	$0x0, 0xc(%rsp)
    2e9a:      	movzbl	0xb(%rsp), %eax
    2e9f:      	cmpl	$0x4, %eax
    2ea2:      	je	0x2eb5 <perf_unwind_php+0x2eb5>
    2ea4:      	movl	$0x0, 0x4(%rsp)
    2eac:      	cmpl	$0x2, %eax
    2eaf:      	jne	0x369e <perf_unwind_php+0x369e>
    2eb5:      	movzbl	0x11(%r15), %eax
    2eba:      	addq	%r13, %rax
    2ebd:      	leaq	0x68(%rsp), %rdi
    2ec2:      	movl	$0x8, %ecx
    2ec7:      	movl	$0x70, %r8d
    2ecd:      	movzbl	0x11(%r15), %edx
    2ed2:      	addq	%r13, %rdx
    2ed5:      	movl	$0x8, %esi
    2eda:      	callq	*%r8
    2edd:      	testq	%rax, %rax
    2ee0:      	je	0x30ea <perf_unwind_php+0x30ea>
    2ee6:      	movq	(%rip), %rax            # 0x2eed <perf_unwind_php+0x2eed>
    2eed:      	movl	$0x25, 0x4(%rsp)
    2ef5:      	cmpl	$0x0, (%rax)
    2ef8:      	je	0x2528 <perf_unwind_php+0x2528>
    2efe:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    2f08:      	movq	%rax, 0x35(%rsp)
    2f0d:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    2f17:      	movq	%rax, 0x30(%rsp)
    2f1c:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    2f26:      	movq	%rax, 0x28(%rsp)
    2f2b:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    2f35:      	movq	%rax, 0x20(%rsp)
    2f3a:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    2f44:      	movq	%rax, 0x18(%rsp)
    2f49:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2f53:      	movq	%rax, 0x10(%rsp)
    2f58:      	leaq	0x10(%rsp), %rdi
    2f5d:      	movl	$0x2d, %eax
    2f62:      	movl	$0x6, %ecx
    2f67:      	movzbl	0x11(%r15), %eax
    2f6c:      	addq	%rax, %r13
    2f6f:      	movl	$0x2d, %esi
    2f74:      	jmp	0x3b4f <perf_unwind_php+0x3b4f>
    2f79:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2f83:      	movq	%rax, 0x36(%rsp)
    2f88:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2f92:      	movq	%rax, 0x30(%rsp)
    2f97:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2fa1:      	movq	%rax, 0x28(%rsp)
    2fa6:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2fb0:      	movq	%rax, 0x20(%rsp)
    2fb5:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2fbf:      	movq	%rax, 0x18(%rsp)
    2fc4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2fce:      	movq	%rax, 0x10(%rsp)
    2fd3:      	leaq	0x10(%rsp), %rdi
    2fd8:      	movl	$0x2e, %eax
    2fdd:      	movl	$0x6, %ecx
    2fe2:      	movl	0x58(%rsp), %edx
    2fe6:      	movl	$0x2e, %esi
    2feb:      	xorl	%eax, %eax
    2fed:      	callq	*%rcx
    2fef:      	cmpl	$0x23, 0x4(%rsp)
    2ff4:      	je	0x1df3 <perf_unwind_php+0x1df3>
    2ffa:      	jmp	0x85e3 <perf_unwind_php+0x85e3>
    2fff:      	movl	0xc(%rsp), %eax
    3003:      	movl	%eax, 0x4(%rsp)
    3007:      	movl	0x54(%rsp), %r13d
    300c:      	movq	(%rip), %rax            # 0x3013 <perf_unwind_php+0x3013>
    3013:      	cmpl	$0x0, (%rax)
    3016:      	jne	0x3b5b <perf_unwind_php+0x3b5b>
    301c:      	movl	0x2c0(%rbp), %eax
    3022:      	cmpq	$0x7e, %rax
    3026:      	ja	0xb47 <perf_unwind_php+0xb47>
    302c:      	movl	0x4(%rsp), %ecx
    3030:      	shlq	$0x20, %r13
    3034:      	orq	%r13, %rcx
    3037:      	movq	0x58(%rsp), %rdx
    303c:      	leal	0x1(%rax), %esi
    303f:      	movl	%esi, 0x2c0(%rbp)
    3045:      	leaq	(%rax,%rax,2), %rax
    3049:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    3051:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    3059:      	movl	0x7c(%rsp), %ecx
    305d:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    3064:      	jmp	0x26e9 <perf_unwind_php+0x26e9>
    3069:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    3073:      	movq	%rax, 0x38(%rsp)
    3078:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    3082:      	movq	%rax, 0x30(%rsp)
    3087:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    3091:      	movq	%rax, 0x28(%rsp)
    3096:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    30a0:      	movq	%rax, 0x20(%rsp)
    30a5:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    30af:      	movq	%rax, 0x18(%rsp)
    30b4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    30be:      	movq	%rax, 0x10(%rsp)
    30c3:      	movb	$0x0, 0x40(%rsp)
    30c8:      	leaq	0x10(%rsp), %rdi
    30cd:      	movl	$0x31, %eax
    30d2:      	movl	$0x6, %ecx
    30d7:      	movq	0x58(%rsp), %rdx
    30dc:      	movl	$0x31, %esi
    30e1:      	xorl	%eax, %eax
    30e3:      	callq	*%rcx
    30e5:      	jmp	0x1dcb <perf_unwind_php+0x1dcb>
    30ea:      	movzbl	0x15(%r15), %eax
    30ef:      	addq	0x68(%rsp), %rax
    30f4:      	leaq	0xc(%rsp), %rdi
    30f9:      	movl	$0x4, %ecx
    30fe:      	movl	$0x70, %r8d
    3104:      	movzbl	0x15(%r15), %edx
    3109:      	addq	0x68(%rsp), %rdx
    310e:      	movl	$0x4, %esi
    3113:      	callq	*%r8
    3116:      	testq	%rax, %rax
    3119:      	je	0x330f <perf_unwind_php+0x330f>
    311f:      	movq	(%rip), %rax            # 0x3126 <perf_unwind_php+0x3126>
    3126:      	movl	$0x27, 0x4(%rsp)
    312e:      	cmpl	$0x0, (%rax)
    3131:      	je	0x2528 <perf_unwind_php+0x2528>
    3137:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    3141:      	movq	%rax, 0x40(%rsp)
    3146:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    3150:      	movq	%rax, 0x38(%rsp)
    3155:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    315f:      	movq	%rax, 0x30(%rsp)
    3164:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    316e:      	movq	%rax, 0x28(%rsp)
    3173:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    317d:      	movq	%rax, 0x20(%rsp)
    3182:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    318c:      	movq	%rax, 0x18(%rsp)
    3191:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    319b:      	movq	%rax, 0x10(%rsp)
    31a0:      	movb	$0x0, 0x48(%rsp)
    31a5:      	leaq	0x10(%rsp), %rdi
    31aa:      	movl	$0x39, %eax
    31af:      	movl	$0x6, %ecx
    31b4:      	movzbl	0x15(%r15), %edx
    31b9:      	addq	0x68(%rsp), %rdx
    31be:      	movl	$0x39, %esi
    31c3:      	jmp	0x3b52 <perf_unwind_php+0x3b52>
    31c8:      	movq	0x58(%rsp), %rax
    31cd:      	testq	%rax, %rax
    31d0:      	je	0x33da <perf_unwind_php+0x33da>
    31d6:      	movzbl	0x14(%r15), %ecx
    31db:      	addq	%rcx, %rax
    31de:      	leaq	0xb(%rsp), %rdi
    31e3:      	movl	$0x1, %ecx
    31e8:      	movl	$0x70, %r8d
    31ee:      	movzbl	0x14(%r15), %edx
    31f3:      	addq	0x58(%rsp), %rdx
    31f8:      	movl	$0x1, %esi
    31fd:      	callq	*%r8
    3200:      	testq	%rax, %rax
    3203:      	je	0x3529 <perf_unwind_php+0x3529>
    3209:      	movq	(%rip), %rax            # 0x3210 <perf_unwind_php+0x3210>
    3210:      	cmpl	$0x0, (%rax)
    3213:      	jne	0x442e <perf_unwind_php+0x442e>
    3219:      	movl	$0x26, 0x4(%rsp)
    3221:      	jmp	0x2c41 <perf_unwind_php+0x2c41>
    3226:      	movq	(%rip), %rax            # 0x322d <perf_unwind_php+0x322d>
    322d:      	cmpl	$0x0, (%rax)
    3230:      	jne	0x433e <perf_unwind_php+0x433e>
    3236:      	cmpl	$0x23, 0x4(%rsp)
    323b:      	jne	0x85e3 <perf_unwind_php+0x85e3>
    3241:      	movzbl	0x12(%r15), %eax
    3246:      	addq	0x70(%rsp), %rax
    324b:      	leaq	0x70(%rsp), %rdi
    3250:      	movl	$0x8, %ecx
    3255:      	movl	$0x70, %r8d
    325b:      	movzbl	0x12(%r15), %edx
    3260:      	addq	0x70(%rsp), %rdx
    3265:      	movl	$0x8, %esi
    326a:      	callq	*%r8
    326d:      	testq	%rax, %rax
    3270:      	jne	0x317 <perf_unwind_php+0x317>
    3276:      	movq	0x70(%rsp), %r13
    327b:      	testq	%r13, %r13
    327e:      	je	0x83ba <perf_unwind_php+0x83ba>
    3284:      	testb	$0x2, 0x56(%rsp)
    3289:      	jne	0x83ba <perf_unwind_php+0x83ba>
    328f:      	movzbl	0x10(%r15), %eax
    3294:      	addq	%r13, %rax
    3297:      	leaq	0x58(%rsp), %rdi
    329c:      	movl	$0x8, %ecx
    32a1:      	movl	$0x70, %r8d
    32a7:      	movzbl	0x10(%r15), %edx
    32ac:      	addq	%r13, %rdx
    32af:      	movl	$0x8, %esi
    32b4:      	callq	*%r8
    32b7:      	testq	%rax, %rax
    32ba:      	je	0x385f <perf_unwind_php+0x385f>
    32c0:      	movq	(%rip), %rax            # 0x32c7 <perf_unwind_php+0x32c7>
    32c7:      	movl	$0x25, 0x4(%rsp)
    32cf:      	cmpl	$0x0, (%rax)
    32d2:      	jne	0x47ff <perf_unwind_php+0x47ff>
    32d8:      	movl	0x4(%rsp), %eax
    32dc:      	movl	%eax, 0x58(%rsp)
    32e0:      	movq	(%rip), %rdi            # 0x32e7 <perf_unwind_php+0x32e7>
    32e7:      	leaq	0x58(%rsp), %rsi
    32ec:      	movl	$0x1, %eax
    32f1:      	callq	*%rax
    32f3:      	testq	%rax, %rax
    32f6:      	je	0x38bd <perf_unwind_php+0x38bd>
    32fc:      	incq	(%rax)
    32ff:      	cmpl	$0x23, 0x4(%rsp)
    3304:      	je	0x38d8 <perf_unwind_php+0x38d8>
    330a:      	jmp	0x85e3 <perf_unwind_php+0x85e3>
    330f:      	movzbl	0x13(%r15), %eax
    3314:      	addq	%r13, %rax
    3317:      	leaq	0x54(%rsp), %rdi
    331c:      	movl	$0x4, %ecx
    3321:      	movl	$0x70, %r8d
    3327:      	movzbl	0x13(%r15), %edx
    332c:      	addq	%r13, %rdx
    332f:      	movl	$0x4, %esi
    3334:      	callq	*%r8
    3337:      	testq	%rax, %rax
    333a:      	je	0x3696 <perf_unwind_php+0x3696>
    3340:      	movq	(%rip), %rax            # 0x3347 <perf_unwind_php+0x3347>
    3347:      	movl	$0x25, 0x4(%rsp)
    334f:      	cmpl	$0x0, (%rax)
    3352:      	je	0x2528 <perf_unwind_php+0x2528>
    3358:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    3362:      	movq	%rax, 0x3d(%rsp)
    3367:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    3371:      	movq	%rax, 0x38(%rsp)
    3376:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    3380:      	movq	%rax, 0x30(%rsp)
    3385:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    338f:      	movq	%rax, 0x28(%rsp)
    3394:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    339e:      	movq	%rax, 0x20(%rsp)
    33a3:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    33ad:      	movq	%rax, 0x18(%rsp)
    33b2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    33bc:      	movq	%rax, 0x10(%rsp)
    33c1:      	leaq	0x10(%rsp), %rdi
    33c6:      	movl	$0x35, %eax
    33cb:      	movl	$0x6, %ecx
    33d0:      	movl	$0x35, %esi
    33d5:      	jmp	0x3b4f <perf_unwind_php+0x3b4f>
    33da:      	movl	0x2c0(%rbp), %eax
    33e0:      	cmpq	$0x7e, %rax
    33e4:      	ja	0x40e <perf_unwind_php+0x40e>
    33ea:      	leal	0x1(%rax), %ecx
    33ed:      	movl	%ecx, 0x2c0(%rbp)
    33f3:      	leaq	(%rax,%rax,2), %rax
    33f7:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    3403:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    340f:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    3417:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    3422:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    342d:      	movl	$0x23, 0x4(%rsp)
    3435:      	jmp	0x2c41 <perf_unwind_php+0x2c41>
    343a:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    3444:      	movq	%rax, 0x38(%rsp)
    3449:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    3453:      	movq	%rax, 0x30(%rsp)
    3458:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    3462:      	movq	%rax, 0x28(%rsp)
    3467:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    3471:      	movq	%rax, 0x20(%rsp)
    3476:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    3480:      	movq	%rax, 0x18(%rsp)
    3485:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    348f:      	movq	%rax, 0x10(%rsp)
    3494:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    349c:      	leaq	0x10(%rsp), %rdi
    34a1:      	movl	$0x33, %eax
    34a6:      	movl	$0x6, %ecx
    34ab:      	movzbl	0x10(%r15), %eax
    34b0:      	addq	%rax, %r13
    34b3:      	movl	$0x33, %esi
    34b8:      	movq	%r13, %rdx
    34bb:      	xorl	%eax, %eax
    34bd:      	callq	*%rcx
    34bf:      	jmp	0x1e8a <perf_unwind_php+0x1e8a>
    34c4:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    34ce:      	movq	%rax, 0x1e(%rsp)
    34d3:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    34dd:      	movq	%rax, 0x18(%rsp)
    34e2:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    34ec:      	movq	%rax, 0x10(%rsp)
    34f1:      	leaq	0x10(%rsp), %rdi
    34f6:      	movl	$0x16, %eax
    34fb:      	movl	$0x6, %r8d
    3501:      	movq	0x58(%rsp), %rdx
    3506:      	movl	0xc(%rsp), %ecx
    350a:      	movl	$0x16, %esi
    350f:      	xorl	%eax, %eax
    3511:      	callq	*%r8
    3514:      	movl	0x2c0(%rbp), %eax
    351a:      	cmpq	$0x7e, %rax
    351e:      	ja	0xb47 <perf_unwind_php+0xb47>
    3524:      	jmp	0x2995 <perf_unwind_php+0x2995>
    3529:      	movl	$0x0, 0xc(%rsp)
    3531:      	movzbl	0xb(%rsp), %eax
    3536:      	cmpl	$0x4, %eax
    3539:      	je	0x354c <perf_unwind_php+0x354c>
    353b:      	movl	$0x0, 0x4(%rsp)
    3543:      	cmpl	$0x2, %eax
    3546:      	jne	0x3d35 <perf_unwind_php+0x3d35>
    354c:      	movzbl	0x11(%r15), %eax
    3551:      	addq	%r13, %rax
    3554:      	leaq	0x68(%rsp), %rdi
    3559:      	movl	$0x8, %ecx
    355e:      	movl	$0x70, %r8d
    3564:      	movzbl	0x11(%r15), %edx
    3569:      	addq	%r13, %rdx
    356c:      	movl	$0x8, %esi
    3571:      	callq	*%r8
    3574:      	testq	%rax, %rax
    3577:      	je	0x3781 <perf_unwind_php+0x3781>
    357d:      	movq	(%rip), %rax            # 0x3584 <perf_unwind_php+0x3584>
    3584:      	movl	$0x25, 0x4(%rsp)
    358c:      	cmpl	$0x0, (%rax)
    358f:      	je	0x2c41 <perf_unwind_php+0x2c41>
    3595:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    359f:      	movq	%rax, 0x35(%rsp)
    35a4:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    35ae:      	movq	%rax, 0x30(%rsp)
    35b3:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    35bd:      	movq	%rax, 0x28(%rsp)
    35c2:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    35cc:      	movq	%rax, 0x20(%rsp)
    35d1:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    35db:      	movq	%rax, 0x18(%rsp)
    35e0:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    35ea:      	movq	%rax, 0x10(%rsp)
    35ef:      	leaq	0x10(%rsp), %rdi
    35f4:      	movl	$0x2d, %eax
    35f9:      	movl	$0x6, %ecx
    35fe:      	movzbl	0x11(%r15), %eax
    3603:      	addq	%rax, %r13
    3606:      	movl	$0x2d, %esi
    360b:      	jmp	0x41e6 <perf_unwind_php+0x41e6>
    3610:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    361a:      	movq	%rax, 0x36(%rsp)
    361f:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3629:      	movq	%rax, 0x30(%rsp)
    362e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3638:      	movq	%rax, 0x28(%rsp)
    363d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3647:      	movq	%rax, 0x20(%rsp)
    364c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3656:      	movq	%rax, 0x18(%rsp)
    365b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3665:      	movq	%rax, 0x10(%rsp)
    366a:      	leaq	0x10(%rsp), %rdi
    366f:      	movl	$0x2e, %eax
    3674:      	movl	$0x6, %ecx
    3679:      	movl	0x58(%rsp), %edx
    367d:      	movl	$0x2e, %esi
    3682:      	xorl	%eax, %eax
    3684:      	callq	*%rcx
    3686:      	cmpl	$0x23, 0x4(%rsp)
    368b:      	je	0x2491 <perf_unwind_php+0x2491>
    3691:      	jmp	0x85e3 <perf_unwind_php+0x85e3>
    3696:      	movl	0xc(%rsp), %eax
    369a:      	movl	%eax, 0x4(%rsp)
    369e:      	movl	0x54(%rsp), %r13d
    36a3:      	movq	(%rip), %rax            # 0x36aa <perf_unwind_php+0x36aa>
    36aa:      	cmpl	$0x0, (%rax)
    36ad:      	jne	0x41f2 <perf_unwind_php+0x41f2>
    36b3:      	movl	0x2c0(%rbp), %eax
    36b9:      	cmpq	$0x7e, %rax
    36bd:      	ja	0xb47 <perf_unwind_php+0xb47>
    36c3:      	movl	0x4(%rsp), %ecx
    36c7:      	shlq	$0x20, %r13
    36cb:      	orq	%r13, %rcx
    36ce:      	movq	0x58(%rsp), %rdx
    36d3:      	leal	0x1(%rax), %esi
    36d6:      	movl	%esi, 0x2c0(%rbp)
    36dc:      	leaq	(%rax,%rax,2), %rax
    36e0:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    36e8:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    36f0:      	movl	0x7c(%rsp), %ecx
    36f4:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    36fb:      	jmp	0x2d80 <perf_unwind_php+0x2d80>
    3700:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    370a:      	movq	%rax, 0x38(%rsp)
    370f:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    3719:      	movq	%rax, 0x30(%rsp)
    371e:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    3728:      	movq	%rax, 0x28(%rsp)
    372d:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    3737:      	movq	%rax, 0x20(%rsp)
    373c:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    3746:      	movq	%rax, 0x18(%rsp)
    374b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3755:      	movq	%rax, 0x10(%rsp)
    375a:      	movb	$0x0, 0x40(%rsp)
    375f:      	leaq	0x10(%rsp), %rdi
    3764:      	movl	$0x31, %eax
    3769:      	movl	$0x6, %ecx
    376e:      	movq	0x58(%rsp), %rdx
    3773:      	movl	$0x31, %esi
    3778:      	xorl	%eax, %eax
    377a:      	callq	*%rcx
    377c:      	jmp	0x2469 <perf_unwind_php+0x2469>
    3781:      	movzbl	0x15(%r15), %eax
    3786:      	addq	0x68(%rsp), %rax
    378b:      	leaq	0xc(%rsp), %rdi
    3790:      	movl	$0x4, %ecx
    3795:      	movl	$0x70, %r8d
    379b:      	movzbl	0x15(%r15), %edx
    37a0:      	addq	0x68(%rsp), %rdx
    37a5:      	movl	$0x4, %esi
    37aa:      	callq	*%r8
    37ad:      	testq	%rax, %rax
    37b0:      	je	0x39a6 <perf_unwind_php+0x39a6>
    37b6:      	movq	(%rip), %rax            # 0x37bd <perf_unwind_php+0x37bd>
    37bd:      	movl	$0x27, 0x4(%rsp)
    37c5:      	cmpl	$0x0, (%rax)
    37c8:      	je	0x2c41 <perf_unwind_php+0x2c41>
    37ce:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    37d8:      	movq	%rax, 0x40(%rsp)
    37dd:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    37e7:      	movq	%rax, 0x38(%rsp)
    37ec:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    37f6:      	movq	%rax, 0x30(%rsp)
    37fb:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    3805:      	movq	%rax, 0x28(%rsp)
    380a:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    3814:      	movq	%rax, 0x20(%rsp)
    3819:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    3823:      	movq	%rax, 0x18(%rsp)
    3828:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3832:      	movq	%rax, 0x10(%rsp)
    3837:      	movb	$0x0, 0x48(%rsp)
    383c:      	leaq	0x10(%rsp), %rdi
    3841:      	movl	$0x39, %eax
    3846:      	movl	$0x6, %ecx
    384b:      	movzbl	0x15(%r15), %edx
    3850:      	addq	0x68(%rsp), %rdx
    3855:      	movl	$0x39, %esi
    385a:      	jmp	0x41e9 <perf_unwind_php+0x41e9>
    385f:      	movq	0x58(%rsp), %rax
    3864:      	testq	%rax, %rax
    3867:      	je	0x3a71 <perf_unwind_php+0x3a71>
    386d:      	movzbl	0x14(%r15), %ecx
    3872:      	addq	%rcx, %rax
    3875:      	leaq	0xb(%rsp), %rdi
    387a:      	movl	$0x1, %ecx
    387f:      	movl	$0x70, %r8d
    3885:      	movzbl	0x14(%r15), %edx
    388a:      	addq	0x58(%rsp), %rdx
    388f:      	movl	$0x1, %esi
    3894:      	callq	*%r8
    3897:      	testq	%rax, %rax
    389a:      	je	0x3bc0 <perf_unwind_php+0x3bc0>
    38a0:      	movq	(%rip), %rax            # 0x38a7 <perf_unwind_php+0x38a7>
    38a7:      	cmpl	$0x0, (%rax)
    38aa:      	jne	0x4ac5 <perf_unwind_php+0x4ac5>
    38b0:      	movl	$0x26, 0x4(%rsp)
    38b8:      	jmp	0x32d8 <perf_unwind_php+0x32d8>
    38bd:      	movq	(%rip), %rax            # 0x38c4 <perf_unwind_php+0x38c4>
    38c4:      	cmpl	$0x0, (%rax)
    38c7:      	jne	0x49d5 <perf_unwind_php+0x49d5>
    38cd:      	cmpl	$0x23, 0x4(%rsp)
    38d2:      	jne	0x85e3 <perf_unwind_php+0x85e3>
    38d8:      	movzbl	0x12(%r15), %eax
    38dd:      	addq	0x70(%rsp), %rax
    38e2:      	leaq	0x70(%rsp), %rdi
    38e7:      	movl	$0x8, %ecx
    38ec:      	movl	$0x70, %r8d
    38f2:      	movzbl	0x12(%r15), %edx
    38f7:      	addq	0x70(%rsp), %rdx
    38fc:      	movl	$0x8, %esi
    3901:      	callq	*%r8
    3904:      	testq	%rax, %rax
    3907:      	jne	0x317 <perf_unwind_php+0x317>
    390d:      	movq	0x70(%rsp), %r13
    3912:      	testq	%r13, %r13
    3915:      	je	0x83ba <perf_unwind_php+0x83ba>
    391b:      	testb	$0x2, 0x56(%rsp)
    3920:      	jne	0x83ba <perf_unwind_php+0x83ba>
    3926:      	movzbl	0x10(%r15), %eax
    392b:      	addq	%r13, %rax
    392e:      	leaq	0x58(%rsp), %rdi
    3933:      	movl	$0x8, %ecx
    3938:      	movl	$0x70, %r8d
    393e:      	movzbl	0x10(%r15), %edx
    3943:      	addq	%r13, %rdx
    3946:      	movl	$0x8, %esi
    394b:      	callq	*%r8
    394e:      	testq	%rax, %rax
    3951:      	je	0x3ef6 <perf_unwind_php+0x3ef6>
    3957:      	movq	(%rip), %rax            # 0x395e <perf_unwind_php+0x395e>
    395e:      	movl	$0x25, 0x4(%rsp)
    3966:      	cmpl	$0x0, (%rax)
    3969:      	jne	0x4f3c <perf_unwind_php+0x4f3c>
    396f:      	movl	0x4(%rsp), %eax
    3973:      	movl	%eax, 0x58(%rsp)
    3977:      	movq	(%rip), %rdi            # 0x397e <perf_unwind_php+0x397e>
    397e:      	leaq	0x58(%rsp), %rsi
    3983:      	movl	$0x1, %eax
    3988:      	callq	*%rax
    398a:      	testq	%rax, %rax
    398d:      	je	0x3f54 <perf_unwind_php+0x3f54>
    3993:      	incq	(%rax)
    3996:      	cmpl	$0x23, 0x4(%rsp)
    399b:      	je	0x3f6f <perf_unwind_php+0x3f6f>
    39a1:      	jmp	0x85e3 <perf_unwind_php+0x85e3>
    39a6:      	movzbl	0x13(%r15), %eax
    39ab:      	addq	%r13, %rax
    39ae:      	leaq	0x54(%rsp), %rdi
    39b3:      	movl	$0x4, %ecx
    39b8:      	movl	$0x70, %r8d
    39be:      	movzbl	0x13(%r15), %edx
    39c3:      	addq	%r13, %rdx
    39c6:      	movl	$0x4, %esi
    39cb:      	callq	*%r8
    39ce:      	testq	%rax, %rax
    39d1:      	je	0x3d2d <perf_unwind_php+0x3d2d>
    39d7:      	movq	(%rip), %rax            # 0x39de <perf_unwind_php+0x39de>
    39de:      	movl	$0x25, 0x4(%rsp)
    39e6:      	cmpl	$0x0, (%rax)
    39e9:      	je	0x2c41 <perf_unwind_php+0x2c41>
    39ef:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    39f9:      	movq	%rax, 0x3d(%rsp)
    39fe:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    3a08:      	movq	%rax, 0x38(%rsp)
    3a0d:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    3a17:      	movq	%rax, 0x30(%rsp)
    3a1c:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    3a26:      	movq	%rax, 0x28(%rsp)
    3a2b:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    3a35:      	movq	%rax, 0x20(%rsp)
    3a3a:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    3a44:      	movq	%rax, 0x18(%rsp)
    3a49:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3a53:      	movq	%rax, 0x10(%rsp)
    3a58:      	leaq	0x10(%rsp), %rdi
    3a5d:      	movl	$0x35, %eax
    3a62:      	movl	$0x6, %ecx
    3a67:      	movl	$0x35, %esi
    3a6c:      	jmp	0x41e6 <perf_unwind_php+0x41e6>
    3a71:      	movl	0x2c0(%rbp), %eax
    3a77:      	cmpq	$0x7e, %rax
    3a7b:      	ja	0x40e <perf_unwind_php+0x40e>
    3a81:      	leal	0x1(%rax), %ecx
    3a84:      	movl	%ecx, 0x2c0(%rbp)
    3a8a:      	leaq	(%rax,%rax,2), %rax
    3a8e:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    3a9a:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    3aa6:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    3aae:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    3ab9:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    3ac4:      	movl	$0x23, 0x4(%rsp)
    3acc:      	jmp	0x32d8 <perf_unwind_php+0x32d8>
    3ad1:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    3adb:      	movq	%rax, 0x38(%rsp)
    3ae0:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    3aea:      	movq	%rax, 0x30(%rsp)
    3aef:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    3af9:      	movq	%rax, 0x28(%rsp)
    3afe:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    3b08:      	movq	%rax, 0x20(%rsp)
    3b0d:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    3b17:      	movq	%rax, 0x18(%rsp)
    3b1c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3b26:      	movq	%rax, 0x10(%rsp)
    3b2b:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    3b33:      	leaq	0x10(%rsp), %rdi
    3b38:      	movl	$0x33, %eax
    3b3d:      	movl	$0x6, %ecx
    3b42:      	movzbl	0x10(%r15), %eax
    3b47:      	addq	%rax, %r13
    3b4a:      	movl	$0x33, %esi
    3b4f:      	movq	%r13, %rdx
    3b52:      	xorl	%eax, %eax
    3b54:      	callq	*%rcx
    3b56:      	jmp	0x2528 <perf_unwind_php+0x2528>
    3b5b:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    3b65:      	movq	%rax, 0x1e(%rsp)
    3b6a:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    3b74:      	movq	%rax, 0x18(%rsp)
    3b79:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    3b83:      	movq	%rax, 0x10(%rsp)
    3b88:      	leaq	0x10(%rsp), %rdi
    3b8d:      	movl	$0x16, %eax
    3b92:      	movl	$0x6, %r8d
    3b98:      	movq	0x58(%rsp), %rdx
    3b9d:      	movl	0xc(%rsp), %ecx
    3ba1:      	movl	$0x16, %esi
    3ba6:      	xorl	%eax, %eax
    3ba8:      	callq	*%r8
    3bab:      	movl	0x2c0(%rbp), %eax
    3bb1:      	cmpq	$0x7e, %rax
    3bb5:      	ja	0xb47 <perf_unwind_php+0xb47>
    3bbb:      	jmp	0x302c <perf_unwind_php+0x302c>
    3bc0:      	movl	$0x0, 0xc(%rsp)
    3bc8:      	movzbl	0xb(%rsp), %eax
    3bcd:      	cmpl	$0x4, %eax
    3bd0:      	je	0x3be3 <perf_unwind_php+0x3be3>
    3bd2:      	movl	$0x0, 0x4(%rsp)
    3bda:      	cmpl	$0x2, %eax
    3bdd:      	jne	0x43cc <perf_unwind_php+0x43cc>
    3be3:      	movzbl	0x11(%r15), %eax
    3be8:      	addq	%r13, %rax
    3beb:      	leaq	0x68(%rsp), %rdi
    3bf0:      	movl	$0x8, %ecx
    3bf5:      	movl	$0x70, %r8d
    3bfb:      	movzbl	0x11(%r15), %edx
    3c00:      	addq	%r13, %rdx
    3c03:      	movl	$0x8, %esi
    3c08:      	callq	*%r8
    3c0b:      	testq	%rax, %rax
    3c0e:      	je	0x3e18 <perf_unwind_php+0x3e18>
    3c14:      	movq	(%rip), %rax            # 0x3c1b <perf_unwind_php+0x3c1b>
    3c1b:      	movl	$0x25, 0x4(%rsp)
    3c23:      	cmpl	$0x0, (%rax)
    3c26:      	je	0x32d8 <perf_unwind_php+0x32d8>
    3c2c:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    3c36:      	movq	%rax, 0x35(%rsp)
    3c3b:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    3c45:      	movq	%rax, 0x30(%rsp)
    3c4a:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    3c54:      	movq	%rax, 0x28(%rsp)
    3c59:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    3c63:      	movq	%rax, 0x20(%rsp)
    3c68:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    3c72:      	movq	%rax, 0x18(%rsp)
    3c77:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3c81:      	movq	%rax, 0x10(%rsp)
    3c86:      	leaq	0x10(%rsp), %rdi
    3c8b:      	movl	$0x2d, %eax
    3c90:      	movl	$0x6, %ecx
    3c95:      	movzbl	0x11(%r15), %eax
    3c9a:      	addq	%rax, %r13
    3c9d:      	movl	$0x2d, %esi
    3ca2:      	jmp	0x487d <perf_unwind_php+0x487d>
    3ca7:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3cb1:      	movq	%rax, 0x36(%rsp)
    3cb6:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3cc0:      	movq	%rax, 0x30(%rsp)
    3cc5:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3ccf:      	movq	%rax, 0x28(%rsp)
    3cd4:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3cde:      	movq	%rax, 0x20(%rsp)
    3ce3:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3ced:      	movq	%rax, 0x18(%rsp)
    3cf2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3cfc:      	movq	%rax, 0x10(%rsp)
    3d01:      	leaq	0x10(%rsp), %rdi
    3d06:      	movl	$0x2e, %eax
    3d0b:      	movl	$0x6, %ecx
    3d10:      	movl	0x58(%rsp), %edx
    3d14:      	movl	$0x2e, %esi
    3d19:      	xorl	%eax, %eax
    3d1b:      	callq	*%rcx
    3d1d:      	cmpl	$0x23, 0x4(%rsp)
    3d22:      	je	0x2baa <perf_unwind_php+0x2baa>
    3d28:      	jmp	0x85e3 <perf_unwind_php+0x85e3>
    3d2d:      	movl	0xc(%rsp), %eax
    3d31:      	movl	%eax, 0x4(%rsp)
    3d35:      	movl	0x54(%rsp), %r13d
    3d3a:      	movq	(%rip), %rax            # 0x3d41 <perf_unwind_php+0x3d41>
    3d41:      	cmpl	$0x0, (%rax)
    3d44:      	jne	0x4889 <perf_unwind_php+0x4889>
    3d4a:      	movl	0x2c0(%rbp), %eax
    3d50:      	cmpq	$0x7e, %rax
    3d54:      	ja	0xb47 <perf_unwind_php+0xb47>
    3d5a:      	movl	0x4(%rsp), %ecx
    3d5e:      	shlq	$0x20, %r13
    3d62:      	orq	%r13, %rcx
    3d65:      	movq	0x58(%rsp), %rdx
    3d6a:      	leal	0x1(%rax), %esi
    3d6d:      	movl	%esi, 0x2c0(%rbp)
    3d73:      	leaq	(%rax,%rax,2), %rax
    3d77:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    3d7f:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    3d87:      	movl	0x7c(%rsp), %ecx
    3d8b:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    3d92:      	jmp	0x3417 <perf_unwind_php+0x3417>
    3d97:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    3da1:      	movq	%rax, 0x38(%rsp)
    3da6:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    3db0:      	movq	%rax, 0x30(%rsp)
    3db5:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    3dbf:      	movq	%rax, 0x28(%rsp)
    3dc4:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    3dce:      	movq	%rax, 0x20(%rsp)
    3dd3:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    3ddd:      	movq	%rax, 0x18(%rsp)
    3de2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3dec:      	movq	%rax, 0x10(%rsp)
    3df1:      	movb	$0x0, 0x40(%rsp)
    3df6:      	leaq	0x10(%rsp), %rdi
    3dfb:      	movl	$0x31, %eax
    3e00:      	movl	$0x6, %ecx
    3e05:      	movq	0x58(%rsp), %rdx
    3e0a:      	movl	$0x31, %esi
    3e0f:      	xorl	%eax, %eax
    3e11:      	callq	*%rcx
    3e13:      	jmp	0x2b82 <perf_unwind_php+0x2b82>
    3e18:      	movzbl	0x15(%r15), %eax
    3e1d:      	addq	0x68(%rsp), %rax
    3e22:      	leaq	0xc(%rsp), %rdi
    3e27:      	movl	$0x4, %ecx
    3e2c:      	movl	$0x70, %r8d
    3e32:      	movzbl	0x15(%r15), %edx
    3e37:      	addq	0x68(%rsp), %rdx
    3e3c:      	movl	$0x4, %esi
    3e41:      	callq	*%r8
    3e44:      	testq	%rax, %rax
    3e47:      	je	0x403d <perf_unwind_php+0x403d>
    3e4d:      	movq	(%rip), %rax            # 0x3e54 <perf_unwind_php+0x3e54>
    3e54:      	movl	$0x27, 0x4(%rsp)
    3e5c:      	cmpl	$0x0, (%rax)
    3e5f:      	je	0x32d8 <perf_unwind_php+0x32d8>
    3e65:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    3e6f:      	movq	%rax, 0x40(%rsp)
    3e74:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    3e7e:      	movq	%rax, 0x38(%rsp)
    3e83:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    3e8d:      	movq	%rax, 0x30(%rsp)
    3e92:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    3e9c:      	movq	%rax, 0x28(%rsp)
    3ea1:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    3eab:      	movq	%rax, 0x20(%rsp)
    3eb0:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    3eba:      	movq	%rax, 0x18(%rsp)
    3ebf:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3ec9:      	movq	%rax, 0x10(%rsp)
    3ece:      	movb	$0x0, 0x48(%rsp)
    3ed3:      	leaq	0x10(%rsp), %rdi
    3ed8:      	movl	$0x39, %eax
    3edd:      	movl	$0x6, %ecx
    3ee2:      	movzbl	0x15(%r15), %edx
    3ee7:      	addq	0x68(%rsp), %rdx
    3eec:      	movl	$0x39, %esi
    3ef1:      	jmp	0x4880 <perf_unwind_php+0x4880>
    3ef6:      	movq	0x58(%rsp), %rax
    3efb:      	testq	%rax, %rax
    3efe:      	je	0x4108 <perf_unwind_php+0x4108>
    3f04:      	movzbl	0x14(%r15), %ecx
    3f09:      	addq	%rcx, %rax
    3f0c:      	leaq	0xb(%rsp), %rdi
    3f11:      	movl	$0x1, %ecx
    3f16:      	movl	$0x70, %r8d
    3f1c:      	movzbl	0x14(%r15), %edx
    3f21:      	addq	0x58(%rsp), %rdx
    3f26:      	movl	$0x1, %esi
    3f2b:      	callq	*%r8
    3f2e:      	testq	%rax, %rax
    3f31:      	je	0x4257 <perf_unwind_php+0x4257>
    3f37:      	movq	(%rip), %rax            # 0x3f3e <perf_unwind_php+0x3f3e>
    3f3e:      	cmpl	$0x0, (%rax)
    3f41:      	jne	0x5202 <perf_unwind_php+0x5202>
    3f47:      	movl	$0x26, 0x4(%rsp)
    3f4f:      	jmp	0x396f <perf_unwind_php+0x396f>
    3f54:      	movq	(%rip), %rax            # 0x3f5b <perf_unwind_php+0x3f5b>
    3f5b:      	cmpl	$0x0, (%rax)
    3f5e:      	jne	0x5112 <perf_unwind_php+0x5112>
    3f64:      	cmpl	$0x23, 0x4(%rsp)
    3f69:      	jne	0x85e3 <perf_unwind_php+0x85e3>
    3f6f:      	movzbl	0x12(%r15), %eax
    3f74:      	addq	0x70(%rsp), %rax
    3f79:      	leaq	0x70(%rsp), %rdi
    3f7e:      	movl	$0x8, %ecx
    3f83:      	movl	$0x70, %r8d
    3f89:      	movzbl	0x12(%r15), %edx
    3f8e:      	addq	0x70(%rsp), %rdx
    3f93:      	movl	$0x8, %esi
    3f98:      	callq	*%r8
    3f9b:      	testq	%rax, %rax
    3f9e:      	jne	0x317 <perf_unwind_php+0x317>
    3fa4:      	movq	0x70(%rsp), %r13
    3fa9:      	testq	%r13, %r13
    3fac:      	je	0x83ba <perf_unwind_php+0x83ba>
    3fb2:      	testb	$0x2, 0x56(%rsp)
    3fb7:      	jne	0x83ba <perf_unwind_php+0x83ba>
    3fbd:      	movzbl	0x10(%r15), %eax
    3fc2:      	addq	%r13, %rax
    3fc5:      	leaq	0x58(%rsp), %rdi
    3fca:      	movl	$0x8, %ecx
    3fcf:      	movl	$0x70, %r8d
    3fd5:      	movzbl	0x10(%r15), %edx
    3fda:      	addq	%r13, %rdx
    3fdd:      	movl	$0x8, %esi
    3fe2:      	callq	*%r8
    3fe5:      	testq	%rax, %rax
    3fe8:      	je	0x458d <perf_unwind_php+0x458d>
    3fee:      	movq	(%rip), %rax            # 0x3ff5 <perf_unwind_php+0x3ff5>
    3ff5:      	movl	$0x25, 0x4(%rsp)
    3ffd:      	cmpl	$0x0, (%rax)
    4000:      	jne	0x5283 <perf_unwind_php+0x5283>
    4006:      	movl	0x4(%rsp), %eax
    400a:      	movl	%eax, 0x58(%rsp)
    400e:      	movq	(%rip), %rdi            # 0x4015 <perf_unwind_php+0x4015>
    4015:      	leaq	0x58(%rsp), %rsi
    401a:      	movl	$0x1, %eax
    401f:      	callq	*%rax
    4021:      	testq	%rax, %rax
    4024:      	je	0x45eb <perf_unwind_php+0x45eb>
    402a:      	incq	(%rax)
    402d:      	cmpl	$0x23, 0x4(%rsp)
    4032:      	je	0x4606 <perf_unwind_php+0x4606>
    4038:      	jmp	0x85e3 <perf_unwind_php+0x85e3>
    403d:      	movzbl	0x13(%r15), %eax
    4042:      	addq	%r13, %rax
    4045:      	leaq	0x54(%rsp), %rdi
    404a:      	movl	$0x4, %ecx
    404f:      	movl	$0x70, %r8d
    4055:      	movzbl	0x13(%r15), %edx
    405a:      	addq	%r13, %rdx
    405d:      	movl	$0x4, %esi
    4062:      	callq	*%r8
    4065:      	testq	%rax, %rax
    4068:      	je	0x43c4 <perf_unwind_php+0x43c4>
    406e:      	movq	(%rip), %rax            # 0x4075 <perf_unwind_php+0x4075>
    4075:      	movl	$0x25, 0x4(%rsp)
    407d:      	cmpl	$0x0, (%rax)
    4080:      	je	0x32d8 <perf_unwind_php+0x32d8>
    4086:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    4090:      	movq	%rax, 0x3d(%rsp)
    4095:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    409f:      	movq	%rax, 0x38(%rsp)
    40a4:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    40ae:      	movq	%rax, 0x30(%rsp)
    40b3:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    40bd:      	movq	%rax, 0x28(%rsp)
    40c2:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    40cc:      	movq	%rax, 0x20(%rsp)
    40d1:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    40db:      	movq	%rax, 0x18(%rsp)
    40e0:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    40ea:      	movq	%rax, 0x10(%rsp)
    40ef:      	leaq	0x10(%rsp), %rdi
    40f4:      	movl	$0x35, %eax
    40f9:      	movl	$0x6, %ecx
    40fe:      	movl	$0x35, %esi
    4103:      	jmp	0x487d <perf_unwind_php+0x487d>
    4108:      	movl	0x2c0(%rbp), %eax
    410e:      	cmpq	$0x7e, %rax
    4112:      	ja	0x40e <perf_unwind_php+0x40e>
    4118:      	leal	0x1(%rax), %ecx
    411b:      	movl	%ecx, 0x2c0(%rbp)
    4121:      	leaq	(%rax,%rax,2), %rax
    4125:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    4131:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    413d:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    4145:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    4150:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    415b:      	movl	$0x23, 0x4(%rsp)
    4163:      	jmp	0x396f <perf_unwind_php+0x396f>
    4168:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    4172:      	movq	%rax, 0x38(%rsp)
    4177:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    4181:      	movq	%rax, 0x30(%rsp)
    4186:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    4190:      	movq	%rax, 0x28(%rsp)
    4195:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    419f:      	movq	%rax, 0x20(%rsp)
    41a4:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    41ae:      	movq	%rax, 0x18(%rsp)
    41b3:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    41bd:      	movq	%rax, 0x10(%rsp)
    41c2:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    41ca:      	leaq	0x10(%rsp), %rdi
    41cf:      	movl	$0x33, %eax
    41d4:      	movl	$0x6, %ecx
    41d9:      	movzbl	0x10(%r15), %eax
    41de:      	addq	%rax, %r13
    41e1:      	movl	$0x33, %esi
    41e6:      	movq	%r13, %rdx
    41e9:      	xorl	%eax, %eax
    41eb:      	callq	*%rcx
    41ed:      	jmp	0x2c41 <perf_unwind_php+0x2c41>
    41f2:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    41fc:      	movq	%rax, 0x1e(%rsp)
    4201:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    420b:      	movq	%rax, 0x18(%rsp)
    4210:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    421a:      	movq	%rax, 0x10(%rsp)
    421f:      	leaq	0x10(%rsp), %rdi
    4224:      	movl	$0x16, %eax
    4229:      	movl	$0x6, %r8d
    422f:      	movq	0x58(%rsp), %rdx
    4234:      	movl	0xc(%rsp), %ecx
    4238:      	movl	$0x16, %esi
    423d:      	xorl	%eax, %eax
    423f:      	callq	*%r8
    4242:      	movl	0x2c0(%rbp), %eax
    4248:      	cmpq	$0x7e, %rax
    424c:      	ja	0xb47 <perf_unwind_php+0xb47>
    4252:      	jmp	0x36c3 <perf_unwind_php+0x36c3>
    4257:      	movl	$0x0, 0xc(%rsp)
    425f:      	movzbl	0xb(%rsp), %eax
    4264:      	cmpl	$0x4, %eax
    4267:      	je	0x427a <perf_unwind_php+0x427a>
    4269:      	movl	$0x0, 0x4(%rsp)
    4271:      	cmpl	$0x2, %eax
    4274:      	jne	0x4a63 <perf_unwind_php+0x4a63>
    427a:      	movzbl	0x11(%r15), %eax
    427f:      	addq	%r13, %rax
    4282:      	leaq	0x68(%rsp), %rdi
    4287:      	movl	$0x8, %ecx
    428c:      	movl	$0x70, %r8d
    4292:      	movzbl	0x11(%r15), %edx
    4297:      	addq	%r13, %rdx
    429a:      	movl	$0x8, %esi
    429f:      	callq	*%r8
    42a2:      	testq	%rax, %rax
    42a5:      	je	0x44af <perf_unwind_php+0x44af>
    42ab:      	movq	(%rip), %rax            # 0x42b2 <perf_unwind_php+0x42b2>
    42b2:      	movl	$0x25, 0x4(%rsp)
    42ba:      	cmpl	$0x0, (%rax)
    42bd:      	je	0x396f <perf_unwind_php+0x396f>
    42c3:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    42cd:      	movq	%rax, 0x35(%rsp)
    42d2:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    42dc:      	movq	%rax, 0x30(%rsp)
    42e1:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    42eb:      	movq	%rax, 0x28(%rsp)
    42f0:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    42fa:      	movq	%rax, 0x20(%rsp)
    42ff:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    4309:      	movq	%rax, 0x18(%rsp)
    430e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4318:      	movq	%rax, 0x10(%rsp)
    431d:      	leaq	0x10(%rsp), %rdi
    4322:      	movl	$0x2d, %eax
    4327:      	movl	$0x6, %ecx
    432c:      	movzbl	0x11(%r15), %eax
    4331:      	addq	%rax, %r13
    4334:      	movl	$0x2d, %esi
    4339:      	jmp	0x4fba <perf_unwind_php+0x4fba>
    433e:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4348:      	movq	%rax, 0x36(%rsp)
    434d:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4357:      	movq	%rax, 0x30(%rsp)
    435c:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4366:      	movq	%rax, 0x28(%rsp)
    436b:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4375:      	movq	%rax, 0x20(%rsp)
    437a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4384:      	movq	%rax, 0x18(%rsp)
    4389:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4393:      	movq	%rax, 0x10(%rsp)
    4398:      	leaq	0x10(%rsp), %rdi
    439d:      	movl	$0x2e, %eax
    43a2:      	movl	$0x6, %ecx
    43a7:      	movl	0x58(%rsp), %edx
    43ab:      	movl	$0x2e, %esi
    43b0:      	xorl	%eax, %eax
    43b2:      	callq	*%rcx
    43b4:      	cmpl	$0x23, 0x4(%rsp)
    43b9:      	je	0x3241 <perf_unwind_php+0x3241>
    43bf:      	jmp	0x85e3 <perf_unwind_php+0x85e3>
    43c4:      	movl	0xc(%rsp), %eax
    43c8:      	movl	%eax, 0x4(%rsp)
    43cc:      	movl	0x54(%rsp), %r13d
    43d1:      	movq	(%rip), %rax            # 0x43d8 <perf_unwind_php+0x43d8>
    43d8:      	cmpl	$0x0, (%rax)
    43db:      	jne	0x4fc6 <perf_unwind_php+0x4fc6>
    43e1:      	movl	0x2c0(%rbp), %eax
    43e7:      	cmpq	$0x7e, %rax
    43eb:      	ja	0xb47 <perf_unwind_php+0xb47>
    43f1:      	movl	0x4(%rsp), %ecx
    43f5:      	shlq	$0x20, %r13
    43f9:      	orq	%r13, %rcx
    43fc:      	movq	0x58(%rsp), %rdx
    4401:      	leal	0x1(%rax), %esi
    4404:      	movl	%esi, 0x2c0(%rbp)
    440a:      	leaq	(%rax,%rax,2), %rax
    440e:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    4416:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    441e:      	movl	0x7c(%rsp), %ecx
    4422:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    4429:      	jmp	0x3aae <perf_unwind_php+0x3aae>
    442e:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    4438:      	movq	%rax, 0x38(%rsp)
    443d:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    4447:      	movq	%rax, 0x30(%rsp)
    444c:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    4456:      	movq	%rax, 0x28(%rsp)
    445b:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    4465:      	movq	%rax, 0x20(%rsp)
    446a:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    4474:      	movq	%rax, 0x18(%rsp)
    4479:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4483:      	movq	%rax, 0x10(%rsp)
    4488:      	movb	$0x0, 0x40(%rsp)
    448d:      	leaq	0x10(%rsp), %rdi
    4492:      	movl	$0x31, %eax
    4497:      	movl	$0x6, %ecx
    449c:      	movq	0x58(%rsp), %rdx
    44a1:      	movl	$0x31, %esi
    44a6:      	xorl	%eax, %eax
    44a8:      	callq	*%rcx
    44aa:      	jmp	0x3219 <perf_unwind_php+0x3219>
    44af:      	movzbl	0x15(%r15), %eax
    44b4:      	addq	0x68(%rsp), %rax
    44b9:      	leaq	0xc(%rsp), %rdi
    44be:      	movl	$0x4, %ecx
    44c3:      	movl	$0x70, %r8d
    44c9:      	movzbl	0x15(%r15), %edx
    44ce:      	addq	0x68(%rsp), %rdx
    44d3:      	movl	$0x4, %esi
    44d8:      	callq	*%r8
    44db:      	testq	%rax, %rax
    44de:      	je	0x46d4 <perf_unwind_php+0x46d4>
    44e4:      	movq	(%rip), %rax            # 0x44eb <perf_unwind_php+0x44eb>
    44eb:      	movl	$0x27, 0x4(%rsp)
    44f3:      	cmpl	$0x0, (%rax)
    44f6:      	je	0x396f <perf_unwind_php+0x396f>
    44fc:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    4506:      	movq	%rax, 0x40(%rsp)
    450b:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    4515:      	movq	%rax, 0x38(%rsp)
    451a:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    4524:      	movq	%rax, 0x30(%rsp)
    4529:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    4533:      	movq	%rax, 0x28(%rsp)
    4538:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    4542:      	movq	%rax, 0x20(%rsp)
    4547:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    4551:      	movq	%rax, 0x18(%rsp)
    4556:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4560:      	movq	%rax, 0x10(%rsp)
    4565:      	movb	$0x0, 0x48(%rsp)
    456a:      	leaq	0x10(%rsp), %rdi
    456f:      	movl	$0x39, %eax
    4574:      	movl	$0x6, %ecx
    4579:      	movzbl	0x15(%r15), %edx
    457e:      	addq	0x68(%rsp), %rdx
    4583:      	movl	$0x39, %esi
    4588:      	jmp	0x4fbd <perf_unwind_php+0x4fbd>
    458d:      	movq	0x58(%rsp), %rax
    4592:      	testq	%rax, %rax
    4595:      	je	0x479f <perf_unwind_php+0x479f>
    459b:      	movzbl	0x14(%r15), %ecx
    45a0:      	addq	%rcx, %rax
    45a3:      	leaq	0xb(%rsp), %rdi
    45a8:      	movl	$0x1, %ecx
    45ad:      	movl	$0x70, %r8d
    45b3:      	movzbl	0x14(%r15), %edx
    45b8:      	addq	0x58(%rsp), %rdx
    45bd:      	movl	$0x1, %esi
    45c2:      	callq	*%r8
    45c5:      	testq	%rax, %rax
    45c8:      	je	0x48ee <perf_unwind_php+0x48ee>
    45ce:      	movq	(%rip), %rax            # 0x45d5 <perf_unwind_php+0x45d5>
    45d5:      	cmpl	$0x0, (%rax)
    45d8:      	jne	0x530d <perf_unwind_php+0x530d>
    45de:      	movl	$0x26, 0x4(%rsp)
    45e6:      	jmp	0x4006 <perf_unwind_php+0x4006>
    45eb:      	movq	(%rip), %rax            # 0x45f2 <perf_unwind_php+0x45f2>
    45f2:      	cmpl	$0x0, (%rax)
    45f5:      	jne	0x538e <perf_unwind_php+0x538e>
    45fb:      	cmpl	$0x23, 0x4(%rsp)
    4600:      	jne	0x85e3 <perf_unwind_php+0x85e3>
    4606:      	movzbl	0x12(%r15), %eax
    460b:      	addq	0x70(%rsp), %rax
    4610:      	leaq	0x70(%rsp), %rdi
    4615:      	movl	$0x8, %ecx
    461a:      	movl	$0x70, %r8d
    4620:      	movzbl	0x12(%r15), %edx
    4625:      	addq	0x70(%rsp), %rdx
    462a:      	movl	$0x8, %esi
    462f:      	callq	*%r8
    4632:      	testq	%rax, %rax
    4635:      	jne	0x317 <perf_unwind_php+0x317>
    463b:      	movq	0x70(%rsp), %r13
    4640:      	testq	%r13, %r13
    4643:      	je	0x83ba <perf_unwind_php+0x83ba>
    4649:      	testb	$0x2, 0x56(%rsp)
    464e:      	jne	0x83ba <perf_unwind_php+0x83ba>
    4654:      	movzbl	0x10(%r15), %eax
    4659:      	addq	%r13, %rax
    465c:      	leaq	0x58(%rsp), %rdi
    4661:      	movl	$0x8, %ecx
    4666:      	movl	$0x70, %r8d
    466c:      	movzbl	0x10(%r15), %edx
    4671:      	addq	%r13, %rdx
    4674:      	movl	$0x8, %esi
    4679:      	callq	*%r8
    467c:      	testq	%rax, %rax
    467f:      	je	0x4c24 <perf_unwind_php+0x4c24>
    4685:      	movq	(%rip), %rax            # 0x468c <perf_unwind_php+0x468c>
    468c:      	movl	$0x25, 0x4(%rsp)
    4694:      	cmpl	$0x0, (%rax)
    4697:      	jne	0x5414 <perf_unwind_php+0x5414>
    469d:      	movl	0x4(%rsp), %eax
    46a1:      	movl	%eax, 0x58(%rsp)
    46a5:      	movq	(%rip), %rdi            # 0x46ac <perf_unwind_php+0x46ac>
    46ac:      	leaq	0x58(%rsp), %rsi
    46b1:      	movl	$0x1, %eax
    46b6:      	callq	*%rax
    46b8:      	testq	%rax, %rax
    46bb:      	je	0x4cfa <perf_unwind_php+0x4cfa>
    46c1:      	incq	(%rax)
    46c4:      	cmpl	$0x23, 0x4(%rsp)
    46c9:      	je	0x4d15 <perf_unwind_php+0x4d15>
    46cf:      	jmp	0x85e3 <perf_unwind_php+0x85e3>
    46d4:      	movzbl	0x13(%r15), %eax
    46d9:      	addq	%r13, %rax
    46dc:      	leaq	0x54(%rsp), %rdi
    46e1:      	movl	$0x4, %ecx
    46e6:      	movl	$0x70, %r8d
    46ec:      	movzbl	0x13(%r15), %edx
    46f1:      	addq	%r13, %rdx
    46f4:      	movl	$0x4, %esi
    46f9:      	callq	*%r8
    46fc:      	testq	%rax, %rax
    46ff:      	je	0x4a5b <perf_unwind_php+0x4a5b>
    4705:      	movq	(%rip), %rax            # 0x470c <perf_unwind_php+0x470c>
    470c:      	movl	$0x25, 0x4(%rsp)
    4714:      	cmpl	$0x0, (%rax)
    4717:      	je	0x396f <perf_unwind_php+0x396f>
    471d:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    4727:      	movq	%rax, 0x3d(%rsp)
    472c:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    4736:      	movq	%rax, 0x38(%rsp)
    473b:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    4745:      	movq	%rax, 0x30(%rsp)
    474a:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    4754:      	movq	%rax, 0x28(%rsp)
    4759:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    4763:      	movq	%rax, 0x20(%rsp)
    4768:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    4772:      	movq	%rax, 0x18(%rsp)
    4777:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4781:      	movq	%rax, 0x10(%rsp)
    4786:      	leaq	0x10(%rsp), %rdi
    478b:      	movl	$0x35, %eax
    4790:      	movl	$0x6, %ecx
    4795:      	movl	$0x35, %esi
    479a:      	jmp	0x4fba <perf_unwind_php+0x4fba>
    479f:      	movl	0x2c0(%rbp), %eax
    47a5:      	cmpq	$0x7e, %rax
    47a9:      	ja	0x40e <perf_unwind_php+0x40e>
    47af:      	leal	0x1(%rax), %ecx
    47b2:      	movl	%ecx, 0x2c0(%rbp)
    47b8:      	leaq	(%rax,%rax,2), %rax
    47bc:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    47c8:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    47d4:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    47dc:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    47e7:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    47f2:      	movl	$0x23, 0x4(%rsp)
    47fa:      	jmp	0x4006 <perf_unwind_php+0x4006>
    47ff:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    4809:      	movq	%rax, 0x38(%rsp)
    480e:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    4818:      	movq	%rax, 0x30(%rsp)
    481d:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    4827:      	movq	%rax, 0x28(%rsp)
    482c:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    4836:      	movq	%rax, 0x20(%rsp)
    483b:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    4845:      	movq	%rax, 0x18(%rsp)
    484a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4854:      	movq	%rax, 0x10(%rsp)
    4859:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    4861:      	leaq	0x10(%rsp), %rdi
    4866:      	movl	$0x33, %eax
    486b:      	movl	$0x6, %ecx
    4870:      	movzbl	0x10(%r15), %eax
    4875:      	addq	%rax, %r13
    4878:      	movl	$0x33, %esi
    487d:      	movq	%r13, %rdx
    4880:      	xorl	%eax, %eax
    4882:      	callq	*%rcx
    4884:      	jmp	0x32d8 <perf_unwind_php+0x32d8>
    4889:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    4893:      	movq	%rax, 0x1e(%rsp)
    4898:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    48a2:      	movq	%rax, 0x18(%rsp)
    48a7:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    48b1:      	movq	%rax, 0x10(%rsp)
    48b6:      	leaq	0x10(%rsp), %rdi
    48bb:      	movl	$0x16, %eax
    48c0:      	movl	$0x6, %r8d
    48c6:      	movq	0x58(%rsp), %rdx
    48cb:      	movl	0xc(%rsp), %ecx
    48cf:      	movl	$0x16, %esi
    48d4:      	xorl	%eax, %eax
    48d6:      	callq	*%r8
    48d9:      	movl	0x2c0(%rbp), %eax
    48df:      	cmpq	$0x7e, %rax
    48e3:      	ja	0xb47 <perf_unwind_php+0xb47>
    48e9:      	jmp	0x3d5a <perf_unwind_php+0x3d5a>
    48ee:      	movl	$0x0, 0xc(%rsp)
    48f6:      	movzbl	0xb(%rsp), %eax
    48fb:      	cmpl	$0x4, %eax
    48fe:      	je	0x4911 <perf_unwind_php+0x4911>
    4900:      	movl	$0x0, 0x4(%rsp)
    4908:      	cmpl	$0x2, %eax
    490b:      	jne	0x51a0 <perf_unwind_php+0x51a0>
    4911:      	movzbl	0x11(%r15), %eax
    4916:      	addq	%r13, %rax
    4919:      	leaq	0x68(%rsp), %rdi
    491e:      	movl	$0x8, %ecx
    4923:      	movl	$0x70, %r8d
    4929:      	movzbl	0x11(%r15), %edx
    492e:      	addq	%r13, %rdx
    4931:      	movl	$0x8, %esi
    4936:      	callq	*%r8
    4939:      	testq	%rax, %rax
    493c:      	je	0x4b46 <perf_unwind_php+0x4b46>
    4942:      	movq	(%rip), %rax            # 0x4949 <perf_unwind_php+0x4949>
    4949:      	movl	$0x25, 0x4(%rsp)
    4951:      	cmpl	$0x0, (%rax)
    4954:      	je	0x4006 <perf_unwind_php+0x4006>
    495a:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    4964:      	movq	%rax, 0x35(%rsp)
    4969:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    4973:      	movq	%rax, 0x30(%rsp)
    4978:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    4982:      	movq	%rax, 0x28(%rsp)
    4987:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    4991:      	movq	%rax, 0x20(%rsp)
    4996:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    49a0:      	movq	%rax, 0x18(%rsp)
    49a5:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    49af:      	movq	%rax, 0x10(%rsp)
    49b4:      	leaq	0x10(%rsp), %rdi
    49b9:      	movl	$0x2d, %eax
    49be:      	movl	$0x6, %ecx
    49c3:      	movzbl	0x11(%r15), %eax
    49c8:      	addq	%rax, %r13
    49cb:      	movl	$0x2d, %esi
    49d0:      	jmp	0x5301 <perf_unwind_php+0x5301>
    49d5:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    49df:      	movq	%rax, 0x36(%rsp)
    49e4:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    49ee:      	movq	%rax, 0x30(%rsp)
    49f3:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    49fd:      	movq	%rax, 0x28(%rsp)
    4a02:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4a0c:      	movq	%rax, 0x20(%rsp)
    4a11:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4a1b:      	movq	%rax, 0x18(%rsp)
    4a20:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4a2a:      	movq	%rax, 0x10(%rsp)
    4a2f:      	leaq	0x10(%rsp), %rdi
    4a34:      	movl	$0x2e, %eax
    4a39:      	movl	$0x6, %ecx
    4a3e:      	movl	0x58(%rsp), %edx
    4a42:      	movl	$0x2e, %esi
    4a47:      	xorl	%eax, %eax
    4a49:      	callq	*%rcx
    4a4b:      	cmpl	$0x23, 0x4(%rsp)
    4a50:      	je	0x38d8 <perf_unwind_php+0x38d8>
    4a56:      	jmp	0x85e3 <perf_unwind_php+0x85e3>
    4a5b:      	movl	0xc(%rsp), %eax
    4a5f:      	movl	%eax, 0x4(%rsp)
    4a63:      	movl	0x54(%rsp), %r13d
    4a68:      	movq	(%rip), %rax            # 0x4a6f <perf_unwind_php+0x4a6f>
    4a6f:      	cmpl	$0x0, (%rax)
    4a72:      	jne	0x5497 <perf_unwind_php+0x5497>
    4a78:      	movl	0x2c0(%rbp), %eax
    4a7e:      	cmpq	$0x7e, %rax
    4a82:      	ja	0xb47 <perf_unwind_php+0xb47>
    4a88:      	movl	0x4(%rsp), %ecx
    4a8c:      	shlq	$0x20, %r13
    4a90:      	orq	%r13, %rcx
    4a93:      	movq	0x58(%rsp), %rdx
    4a98:      	leal	0x1(%rax), %esi
    4a9b:      	movl	%esi, 0x2c0(%rbp)
    4aa1:      	leaq	(%rax,%rax,2), %rax
    4aa5:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    4aad:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    4ab5:      	movl	0x7c(%rsp), %ecx
    4ab9:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    4ac0:      	jmp	0x4145 <perf_unwind_php+0x4145>
    4ac5:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    4acf:      	movq	%rax, 0x38(%rsp)
    4ad4:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    4ade:      	movq	%rax, 0x30(%rsp)
    4ae3:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    4aed:      	movq	%rax, 0x28(%rsp)
    4af2:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    4afc:      	movq	%rax, 0x20(%rsp)
    4b01:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    4b0b:      	movq	%rax, 0x18(%rsp)
    4b10:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4b1a:      	movq	%rax, 0x10(%rsp)
    4b1f:      	movb	$0x0, 0x40(%rsp)
    4b24:      	leaq	0x10(%rsp), %rdi
    4b29:      	movl	$0x31, %eax
    4b2e:      	movl	$0x6, %ecx
    4b33:      	movq	0x58(%rsp), %rdx
    4b38:      	movl	$0x31, %esi
    4b3d:      	xorl	%eax, %eax
    4b3f:      	callq	*%rcx
    4b41:      	jmp	0x38b0 <perf_unwind_php+0x38b0>
    4b46:      	movzbl	0x15(%r15), %eax
    4b4b:      	addq	0x68(%rsp), %rax
    4b50:      	leaq	0xc(%rsp), %rdi
    4b55:      	movl	$0x4, %ecx
    4b5a:      	movl	$0x70, %r8d
    4b60:      	movzbl	0x15(%r15), %edx
    4b65:      	addq	0x68(%rsp), %rdx
    4b6a:      	movl	$0x4, %esi
    4b6f:      	callq	*%r8
    4b72:      	testq	%rax, %rax
    4b75:      	je	0x4e2f <perf_unwind_php+0x4e2f>
    4b7b:      	movq	(%rip), %rax            # 0x4b82 <perf_unwind_php+0x4b82>
    4b82:      	movl	$0x27, 0x4(%rsp)
    4b8a:      	cmpl	$0x0, (%rax)
    4b8d:      	je	0x4006 <perf_unwind_php+0x4006>
    4b93:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    4b9d:      	movq	%rax, 0x40(%rsp)
    4ba2:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    4bac:      	movq	%rax, 0x38(%rsp)
    4bb1:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    4bbb:      	movq	%rax, 0x30(%rsp)
    4bc0:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    4bca:      	movq	%rax, 0x28(%rsp)
    4bcf:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    4bd9:      	movq	%rax, 0x20(%rsp)
    4bde:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    4be8:      	movq	%rax, 0x18(%rsp)
    4bed:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4bf7:      	movq	%rax, 0x10(%rsp)
    4bfc:      	movb	$0x0, 0x48(%rsp)
    4c01:      	leaq	0x10(%rsp), %rdi
    4c06:      	movl	$0x39, %eax
    4c0b:      	movl	$0x6, %ecx
    4c10:      	movzbl	0x15(%r15), %edx
    4c15:      	addq	0x68(%rsp), %rdx
    4c1a:      	movl	$0x39, %esi
    4c1f:      	jmp	0x5304 <perf_unwind_php+0x5304>
    4c24:      	movq	0x58(%rsp), %rax
    4c29:      	testq	%rax, %rax
    4c2c:      	je	0x4efa <perf_unwind_php+0x4efa>
    4c32:      	movzbl	0x14(%r15), %ecx
    4c37:      	addq	%rcx, %rax
    4c3a:      	leaq	0xb(%rsp), %rdi
    4c3f:      	movl	$0x1, %ecx
    4c44:      	movl	$0x70, %r8d
    4c4a:      	movzbl	0x14(%r15), %edx
    4c4f:      	addq	0x58(%rsp), %rdx
    4c54:      	movl	$0x1, %esi
    4c59:      	callq	*%r8
    4c5c:      	testq	%rax, %rax
    4c5f:      	je	0x502b <perf_unwind_php+0x502b>
    4c65:      	movq	(%rip), %rax            # 0x4c6c <perf_unwind_php+0x4c6c>
    4c6c:      	cmpl	$0x0, (%rax)
    4c6f:      	je	0x4ced <perf_unwind_php+0x4ced>
    4c71:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    4c7b:      	movq	%rax, 0x38(%rsp)
    4c80:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    4c8a:      	movq	%rax, 0x30(%rsp)
    4c8f:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    4c99:      	movq	%rax, 0x28(%rsp)
    4c9e:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    4ca8:      	movq	%rax, 0x20(%rsp)
    4cad:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    4cb7:      	movq	%rax, 0x18(%rsp)
    4cbc:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4cc6:      	movq	%rax, 0x10(%rsp)
    4ccb:      	movb	$0x0, 0x40(%rsp)
    4cd0:      	leaq	0x10(%rsp), %rdi
    4cd5:      	movl	$0x31, %eax
    4cda:      	movl	$0x6, %ecx
    4cdf:      	movq	0x58(%rsp), %rdx
    4ce4:      	movl	$0x31, %esi
    4ce9:      	xorl	%eax, %eax
    4ceb:      	callq	*%rcx
    4ced:      	movl	$0x26, 0x4(%rsp)
    4cf5:      	jmp	0x469d <perf_unwind_php+0x469d>
    4cfa:      	movq	(%rip), %rax            # 0x4d01 <perf_unwind_php+0x4d01>
    4d01:      	cmpl	$0x0, (%rax)
    4d04:      	jne	0x54fc <perf_unwind_php+0x54fc>
    4d0a:      	cmpl	$0x23, 0x4(%rsp)
    4d0f:      	jne	0x85e3 <perf_unwind_php+0x85e3>
    4d15:      	movzbl	0x12(%r15), %eax
    4d1a:      	addq	0x70(%rsp), %rax
    4d1f:      	leaq	0x70(%rsp), %rdi
    4d24:      	movl	$0x8, %ecx
    4d29:      	movl	$0x70, %r8d
    4d2f:      	movzbl	0x12(%r15), %edx
    4d34:      	addq	0x70(%rsp), %rdx
    4d39:      	movl	$0x8, %esi
    4d3e:      	callq	*%r8
    4d41:      	testq	%rax, %rax
    4d44:      	jne	0x317 <perf_unwind_php+0x317>
    4d4a:      	movq	0x70(%rsp), %r13
    4d4f:      	testq	%r13, %r13
    4d52:      	je	0x83ba <perf_unwind_php+0x83ba>
    4d58:      	testb	$0x2, 0x56(%rsp)
    4d5d:      	jne	0x83ba <perf_unwind_php+0x83ba>
    4d63:      	movzbl	0x10(%r15), %eax
    4d68:      	addq	%r13, %rax
    4d6b:      	leaq	0x58(%rsp), %rdi
    4d70:      	movl	$0x8, %ecx
    4d75:      	movl	$0x70, %r8d
    4d7b:      	movzbl	0x10(%r15), %edx
    4d80:      	addq	%r13, %rdx
    4d83:      	movl	$0x8, %esi
    4d88:      	callq	*%r8
    4d8b:      	testq	%rax, %rax
    4d8e:      	je	0x5582 <perf_unwind_php+0x5582>
    4d94:      	movq	(%rip), %rax            # 0x4d9b <perf_unwind_php+0x4d9b>
    4d9b:      	movl	$0x25, 0x4(%rsp)
    4da3:      	cmpl	$0x0, (%rax)
    4da6:      	je	0x5ce9 <perf_unwind_php+0x5ce9>
    4dac:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    4db6:      	movq	%rax, 0x38(%rsp)
    4dbb:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    4dc5:      	movq	%rax, 0x30(%rsp)
    4dca:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    4dd4:      	movq	%rax, 0x28(%rsp)
    4dd9:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    4de3:      	movq	%rax, 0x20(%rsp)
    4de8:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    4df2:      	movq	%rax, 0x18(%rsp)
    4df7:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4e01:      	movq	%rax, 0x10(%rsp)
    4e06:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    4e0e:      	leaq	0x10(%rsp), %rdi
    4e13:      	movl	$0x33, %eax
    4e18:      	movl	$0x6, %ecx
    4e1d:      	movzbl	0x10(%r15), %eax
    4e22:      	addq	%rax, %r13
    4e25:      	movl	$0x33, %esi
    4e2a:      	jmp	0x5c0e <perf_unwind_php+0x5c0e>
    4e2f:      	movzbl	0x13(%r15), %eax
    4e34:      	addq	%r13, %rax
    4e37:      	leaq	0x54(%rsp), %rdi
    4e3c:      	movl	$0x4, %ecx
    4e41:      	movl	$0x70, %r8d
    4e47:      	movzbl	0x13(%r15), %edx
    4e4c:      	addq	%r13, %rdx
    4e4f:      	movl	$0x4, %esi
    4e54:      	callq	*%r8
    4e57:      	testq	%rax, %rax
    4e5a:      	je	0x5198 <perf_unwind_php+0x5198>
    4e60:      	movq	(%rip), %rax            # 0x4e67 <perf_unwind_php+0x4e67>
    4e67:      	movl	$0x25, 0x4(%rsp)
    4e6f:      	cmpl	$0x0, (%rax)
    4e72:      	je	0x4006 <perf_unwind_php+0x4006>
    4e78:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    4e82:      	movq	%rax, 0x3d(%rsp)
    4e87:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    4e91:      	movq	%rax, 0x38(%rsp)
    4e96:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    4ea0:      	movq	%rax, 0x30(%rsp)
    4ea5:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    4eaf:      	movq	%rax, 0x28(%rsp)
    4eb4:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    4ebe:      	movq	%rax, 0x20(%rsp)
    4ec3:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    4ecd:      	movq	%rax, 0x18(%rsp)
    4ed2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4edc:      	movq	%rax, 0x10(%rsp)
    4ee1:      	leaq	0x10(%rsp), %rdi
    4ee6:      	movl	$0x35, %eax
    4eeb:      	movl	$0x6, %ecx
    4ef0:      	movl	$0x35, %esi
    4ef5:      	jmp	0x5301 <perf_unwind_php+0x5301>
    4efa:      	movl	0x2c0(%rbp), %eax
    4f00:      	cmpq	$0x7e, %rax
    4f04:      	ja	0x40e <perf_unwind_php+0x40e>
    4f0a:      	leal	0x1(%rax), %ecx
    4f0d:      	movl	%ecx, 0x2c0(%rbp)
    4f13:      	leaq	(%rax,%rax,2), %rax
    4f17:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    4f23:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    4f2f:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    4f37:      	jmp	0x5b25 <perf_unwind_php+0x5b25>
    4f3c:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    4f46:      	movq	%rax, 0x38(%rsp)
    4f4b:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    4f55:      	movq	%rax, 0x30(%rsp)
    4f5a:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    4f64:      	movq	%rax, 0x28(%rsp)
    4f69:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    4f73:      	movq	%rax, 0x20(%rsp)
    4f78:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    4f82:      	movq	%rax, 0x18(%rsp)
    4f87:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4f91:      	movq	%rax, 0x10(%rsp)
    4f96:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    4f9e:      	leaq	0x10(%rsp), %rdi
    4fa3:      	movl	$0x33, %eax
    4fa8:      	movl	$0x6, %ecx
    4fad:      	movzbl	0x10(%r15), %eax
    4fb2:      	addq	%rax, %r13
    4fb5:      	movl	$0x33, %esi
    4fba:      	movq	%r13, %rdx
    4fbd:      	xorl	%eax, %eax
    4fbf:      	callq	*%rcx
    4fc1:      	jmp	0x396f <perf_unwind_php+0x396f>
    4fc6:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    4fd0:      	movq	%rax, 0x1e(%rsp)
    4fd5:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    4fdf:      	movq	%rax, 0x18(%rsp)
    4fe4:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    4fee:      	movq	%rax, 0x10(%rsp)
    4ff3:      	leaq	0x10(%rsp), %rdi
    4ff8:      	movl	$0x16, %eax
    4ffd:      	movl	$0x6, %r8d
    5003:      	movq	0x58(%rsp), %rdx
    5008:      	movl	0xc(%rsp), %ecx
    500c:      	movl	$0x16, %esi
    5011:      	xorl	%eax, %eax
    5013:      	callq	*%r8
    5016:      	movl	0x2c0(%rbp), %eax
    501c:      	cmpq	$0x7e, %rax
    5020:      	ja	0xb47 <perf_unwind_php+0xb47>
    5026:      	jmp	0x43f1 <perf_unwind_php+0x43f1>
    502b:      	movl	$0x0, 0xc(%rsp)
    5033:      	movzbl	0xb(%rsp), %eax
    5038:      	cmpl	$0x4, %eax
    503b:      	je	0x504e <perf_unwind_php+0x504e>
    503d:      	movl	$0x0, 0x4(%rsp)
    5045:      	cmpl	$0x2, %eax
    5048:      	jne	0x5a7c <perf_unwind_php+0x5a7c>
    504e:      	movzbl	0x11(%r15), %eax
    5053:      	addq	%r13, %rax
    5056:      	leaq	0x68(%rsp), %rdi
    505b:      	movl	$0x8, %ecx
    5060:      	movl	$0x70, %r8d
    5066:      	movzbl	0x11(%r15), %edx
    506b:      	addq	%r13, %rdx
    506e:      	movl	$0x8, %esi
    5073:      	callq	*%r8
    5076:      	testq	%rax, %rax
    5079:      	je	0x5658 <perf_unwind_php+0x5658>
    507f:      	movq	(%rip), %rax            # 0x5086 <perf_unwind_php+0x5086>
    5086:      	movl	$0x25, 0x4(%rsp)
    508e:      	cmpl	$0x0, (%rax)
    5091:      	je	0x469d <perf_unwind_php+0x469d>
    5097:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    50a1:      	movq	%rax, 0x35(%rsp)
    50a6:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    50b0:      	movq	%rax, 0x30(%rsp)
    50b5:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    50bf:      	movq	%rax, 0x28(%rsp)
    50c4:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    50ce:      	movq	%rax, 0x20(%rsp)
    50d3:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    50dd:      	movq	%rax, 0x18(%rsp)
    50e2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    50ec:      	movq	%rax, 0x10(%rsp)
    50f1:      	leaq	0x10(%rsp), %rdi
    50f6:      	movl	$0x2d, %eax
    50fb:      	movl	$0x6, %ecx
    5100:      	movzbl	0x11(%r15), %eax
    5105:      	addq	%rax, %r13
    5108:      	movl	$0x2d, %esi
    510d:      	jmp	0x598a <perf_unwind_php+0x598a>
    5112:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    511c:      	movq	%rax, 0x36(%rsp)
    5121:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    512b:      	movq	%rax, 0x30(%rsp)
    5130:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    513a:      	movq	%rax, 0x28(%rsp)
    513f:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5149:      	movq	%rax, 0x20(%rsp)
    514e:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5158:      	movq	%rax, 0x18(%rsp)
    515d:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5167:      	movq	%rax, 0x10(%rsp)
    516c:      	leaq	0x10(%rsp), %rdi
    5171:      	movl	$0x2e, %eax
    5176:      	movl	$0x6, %ecx
    517b:      	movl	0x58(%rsp), %edx
    517f:      	movl	$0x2e, %esi
    5184:      	xorl	%eax, %eax
    5186:      	callq	*%rcx
    5188:      	cmpl	$0x23, 0x4(%rsp)
    518d:      	je	0x3f6f <perf_unwind_php+0x3f6f>
    5193:      	jmp	0x85e3 <perf_unwind_php+0x85e3>
    5198:      	movl	0xc(%rsp), %eax
    519c:      	movl	%eax, 0x4(%rsp)
    51a0:      	movl	0x54(%rsp), %r13d
    51a5:      	movq	(%rip), %rax            # 0x51ac <perf_unwind_php+0x51ac>
    51ac:      	cmpl	$0x0, (%rax)
    51af:      	jne	0x5736 <perf_unwind_php+0x5736>
    51b5:      	movl	0x2c0(%rbp), %eax
    51bb:      	cmpq	$0x7e, %rax
    51bf:      	ja	0xb47 <perf_unwind_php+0xb47>
    51c5:      	movl	0x4(%rsp), %ecx
    51c9:      	shlq	$0x20, %r13
    51cd:      	orq	%r13, %rcx
    51d0:      	movq	0x58(%rsp), %rdx
    51d5:      	leal	0x1(%rax), %esi
    51d8:      	movl	%esi, 0x2c0(%rbp)
    51de:      	leaq	(%rax,%rax,2), %rax
    51e2:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    51ea:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    51f2:      	movl	0x7c(%rsp), %ecx
    51f6:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    51fd:      	jmp	0x47dc <perf_unwind_php+0x47dc>
    5202:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    520c:      	movq	%rax, 0x38(%rsp)
    5211:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    521b:      	movq	%rax, 0x30(%rsp)
    5220:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    522a:      	movq	%rax, 0x28(%rsp)
    522f:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    5239:      	movq	%rax, 0x20(%rsp)
    523e:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    5248:      	movq	%rax, 0x18(%rsp)
    524d:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5257:      	movq	%rax, 0x10(%rsp)
    525c:      	movb	$0x0, 0x40(%rsp)
    5261:      	leaq	0x10(%rsp), %rdi
    5266:      	movl	$0x31, %eax
    526b:      	movl	$0x6, %ecx
    5270:      	movq	0x58(%rsp), %rdx
    5275:      	movl	$0x31, %esi
    527a:      	xorl	%eax, %eax
    527c:      	callq	*%rcx
    527e:      	jmp	0x3f47 <perf_unwind_php+0x3f47>
    5283:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    528d:      	movq	%rax, 0x38(%rsp)
    5292:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    529c:      	movq	%rax, 0x30(%rsp)
    52a1:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    52ab:      	movq	%rax, 0x28(%rsp)
    52b0:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    52ba:      	movq	%rax, 0x20(%rsp)
    52bf:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    52c9:      	movq	%rax, 0x18(%rsp)
    52ce:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    52d8:      	movq	%rax, 0x10(%rsp)
    52dd:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    52e5:      	leaq	0x10(%rsp), %rdi
    52ea:      	movl	$0x33, %eax
    52ef:      	movl	$0x6, %ecx
    52f4:      	movzbl	0x10(%r15), %eax
    52f9:      	addq	%rax, %r13
    52fc:      	movl	$0x33, %esi
    5301:      	movq	%r13, %rdx
    5304:      	xorl	%eax, %eax
    5306:      	callq	*%rcx
    5308:      	jmp	0x4006 <perf_unwind_php+0x4006>
    530d:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    5317:      	movq	%rax, 0x38(%rsp)
    531c:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    5326:      	movq	%rax, 0x30(%rsp)
    532b:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    5335:      	movq	%rax, 0x28(%rsp)
    533a:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    5344:      	movq	%rax, 0x20(%rsp)
    5349:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    5353:      	movq	%rax, 0x18(%rsp)
    5358:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5362:      	movq	%rax, 0x10(%rsp)
    5367:      	movb	$0x0, 0x40(%rsp)
    536c:      	leaq	0x10(%rsp), %rdi
    5371:      	movl	$0x31, %eax
    5376:      	movl	$0x6, %ecx
    537b:      	movq	0x58(%rsp), %rdx
    5380:      	movl	$0x31, %esi
    5385:      	xorl	%eax, %eax
    5387:      	callq	*%rcx
    5389:      	jmp	0x45de <perf_unwind_php+0x45de>
    538e:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5398:      	movq	%rax, 0x36(%rsp)
    539d:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    53a7:      	movq	%rax, 0x30(%rsp)
    53ac:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    53b6:      	movq	%rax, 0x28(%rsp)
    53bb:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    53c5:      	movq	%rax, 0x20(%rsp)
    53ca:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    53d4:      	movq	%rax, 0x18(%rsp)
    53d9:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    53e3:      	movq	%rax, 0x10(%rsp)
    53e8:      	leaq	0x10(%rsp), %rdi
    53ed:      	movl	$0x2e, %eax
    53f2:      	movl	$0x6, %ecx
    53f7:      	movl	0x58(%rsp), %edx
    53fb:      	movl	$0x2e, %esi
    5400:      	xorl	%eax, %eax
    5402:      	callq	*%rcx
    5404:      	cmpl	$0x23, 0x4(%rsp)
    5409:      	je	0x4606 <perf_unwind_php+0x4606>
    540f:      	jmp	0x85e3 <perf_unwind_php+0x85e3>
    5414:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    541e:      	movq	%rax, 0x38(%rsp)
    5423:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    542d:      	movq	%rax, 0x30(%rsp)
    5432:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    543c:      	movq	%rax, 0x28(%rsp)
    5441:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    544b:      	movq	%rax, 0x20(%rsp)
    5450:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    545a:      	movq	%rax, 0x18(%rsp)
    545f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5469:      	movq	%rax, 0x10(%rsp)
    546e:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    5476:      	leaq	0x10(%rsp), %rdi
    547b:      	movl	$0x33, %eax
    5480:      	movl	$0x6, %ecx
    5485:      	movzbl	0x10(%r15), %eax
    548a:      	addq	%rax, %r13
    548d:      	movl	$0x33, %esi
    5492:      	jmp	0x598a <perf_unwind_php+0x598a>
    5497:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    54a1:      	movq	%rax, 0x1e(%rsp)
    54a6:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    54b0:      	movq	%rax, 0x18(%rsp)
    54b5:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    54bf:      	movq	%rax, 0x10(%rsp)
    54c4:      	leaq	0x10(%rsp), %rdi
    54c9:      	movl	$0x16, %eax
    54ce:      	movl	$0x6, %r8d
    54d4:      	movq	0x58(%rsp), %rdx
    54d9:      	movl	0xc(%rsp), %ecx
    54dd:      	movl	$0x16, %esi
    54e2:      	xorl	%eax, %eax
    54e4:      	callq	*%r8
    54e7:      	movl	0x2c0(%rbp), %eax
    54ed:      	cmpq	$0x7e, %rax
    54f1:      	ja	0xb47 <perf_unwind_php+0xb47>
    54f7:      	jmp	0x4a88 <perf_unwind_php+0x4a88>
    54fc:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5506:      	movq	%rax, 0x36(%rsp)
    550b:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5515:      	movq	%rax, 0x30(%rsp)
    551a:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5524:      	movq	%rax, 0x28(%rsp)
    5529:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5533:      	movq	%rax, 0x20(%rsp)
    5538:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5542:      	movq	%rax, 0x18(%rsp)
    5547:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5551:      	movq	%rax, 0x10(%rsp)
    5556:      	leaq	0x10(%rsp), %rdi
    555b:      	movl	$0x2e, %eax
    5560:      	movl	$0x6, %ecx
    5565:      	movl	0x58(%rsp), %edx
    5569:      	movl	$0x2e, %esi
    556e:      	xorl	%eax, %eax
    5570:      	callq	*%rcx
    5572:      	cmpl	$0x23, 0x4(%rsp)
    5577:      	je	0x4d15 <perf_unwind_php+0x4d15>
    557d:      	jmp	0x85e3 <perf_unwind_php+0x85e3>
    5582:      	movq	0x58(%rsp), %rax
    5587:      	testq	%rax, %rax
    558a:      	je	0x579b <perf_unwind_php+0x579b>
    5590:      	movzbl	0x14(%r15), %ecx
    5595:      	addq	%rcx, %rax
    5598:      	leaq	0xb(%rsp), %rdi
    559d:      	movl	$0x1, %ecx
    55a2:      	movl	$0x70, %r8d
    55a8:      	movzbl	0x14(%r15), %edx
    55ad:      	addq	0x58(%rsp), %rdx
    55b2:      	movl	$0x1, %esi
    55b7:      	callq	*%r8
    55ba:      	testq	%rax, %rax
    55bd:      	je	0x57dd <perf_unwind_php+0x57dd>
    55c3:      	movq	(%rip), %rax            # 0x55ca <perf_unwind_php+0x55ca>
    55ca:      	cmpl	$0x0, (%rax)
    55cd:      	je	0x564b <perf_unwind_php+0x564b>
    55cf:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    55d9:      	movq	%rax, 0x38(%rsp)
    55de:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    55e8:      	movq	%rax, 0x30(%rsp)
    55ed:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    55f7:      	movq	%rax, 0x28(%rsp)
    55fc:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    5606:      	movq	%rax, 0x20(%rsp)
    560b:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    5615:      	movq	%rax, 0x18(%rsp)
    561a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5624:      	movq	%rax, 0x10(%rsp)
    5629:      	movb	$0x0, 0x40(%rsp)
    562e:      	leaq	0x10(%rsp), %rdi
    5633:      	movl	$0x31, %eax
    5638:      	movl	$0x6, %ecx
    563d:      	movq	0x58(%rsp), %rdx
    5642:      	movl	$0x31, %esi
    5647:      	xorl	%eax, %eax
    5649:      	callq	*%rcx
    564b:      	movl	$0x26, 0x4(%rsp)
    5653:      	jmp	0x5ce9 <perf_unwind_php+0x5ce9>
    5658:      	movzbl	0x15(%r15), %eax
    565d:      	addq	0x68(%rsp), %rax
    5662:      	leaq	0xc(%rsp), %rdi
    5667:      	movl	$0x4, %ecx
    566c:      	movl	$0x70, %r8d
    5672:      	movzbl	0x15(%r15), %edx
    5677:      	addq	0x68(%rsp), %rdx
    567c:      	movl	$0x4, %esi
    5681:      	callq	*%r8
    5684:      	testq	%rax, %rax
    5687:      	je	0x58c4 <perf_unwind_php+0x58c4>
    568d:      	movq	(%rip), %rax            # 0x5694 <perf_unwind_php+0x5694>
    5694:      	movl	$0x27, 0x4(%rsp)
    569c:      	cmpl	$0x0, (%rax)
    569f:      	je	0x469d <perf_unwind_php+0x469d>
    56a5:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    56af:      	movq	%rax, 0x40(%rsp)
    56b4:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    56be:      	movq	%rax, 0x38(%rsp)
    56c3:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    56cd:      	movq	%rax, 0x30(%rsp)
    56d2:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    56dc:      	movq	%rax, 0x28(%rsp)
    56e1:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    56eb:      	movq	%rax, 0x20(%rsp)
    56f0:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    56fa:      	movq	%rax, 0x18(%rsp)
    56ff:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5709:      	movq	%rax, 0x10(%rsp)
    570e:      	movb	$0x0, 0x48(%rsp)
    5713:      	leaq	0x10(%rsp), %rdi
    5718:      	movl	$0x39, %eax
    571d:      	movl	$0x6, %ecx
    5722:      	movzbl	0x15(%r15), %edx
    5727:      	addq	0x68(%rsp), %rdx
    572c:      	movl	$0x39, %esi
    5731:      	jmp	0x598d <perf_unwind_php+0x598d>
    5736:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    5740:      	movq	%rax, 0x1e(%rsp)
    5745:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    574f:      	movq	%rax, 0x18(%rsp)
    5754:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    575e:      	movq	%rax, 0x10(%rsp)
    5763:      	leaq	0x10(%rsp), %rdi
    5768:      	movl	$0x16, %eax
    576d:      	movl	$0x6, %r8d
    5773:      	movq	0x58(%rsp), %rdx
    5778:      	movl	0xc(%rsp), %ecx
    577c:      	movl	$0x16, %esi
    5781:      	xorl	%eax, %eax
    5783:      	callq	*%r8
    5786:      	movl	0x2c0(%rbp), %eax
    578c:      	cmpq	$0x7e, %rax
    5790:      	ja	0xb47 <perf_unwind_php+0xb47>
    5796:      	jmp	0x51c5 <perf_unwind_php+0x51c5>
    579b:      	movl	0x2c0(%rbp), %eax
    57a1:      	cmpq	$0x7e, %rax
    57a5:      	ja	0x40e <perf_unwind_php+0x40e>
    57ab:      	leal	0x1(%rax), %ecx
    57ae:      	movl	%ecx, 0x2c0(%rbp)
    57b4:      	leaq	(%rax,%rax,2), %rax
    57b8:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    57c4:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    57d0:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    57d8:      	jmp	0x5ccb <perf_unwind_php+0x5ccb>
    57dd:      	movl	$0x0, 0xc(%rsp)
    57e5:      	movzbl	0xb(%rsp), %eax
    57ea:      	cmpl	$0x4, %eax
    57ed:      	je	0x5800 <perf_unwind_php+0x5800>
    57ef:      	movl	$0x0, 0x4(%rsp)
    57f7:      	cmpl	$0x2, %eax
    57fa:      	jne	0x5c22 <perf_unwind_php+0x5c22>
    5800:      	movzbl	0x11(%r15), %eax
    5805:      	addq	%r13, %rax
    5808:      	leaq	0x68(%rsp), %rdi
    580d:      	movl	$0x8, %ecx
    5812:      	movl	$0x70, %r8d
    5818:      	movzbl	0x11(%r15), %edx
    581d:      	addq	%r13, %rdx
    5820:      	movl	$0x8, %esi
    5825:      	callq	*%r8
    5828:      	testq	%rax, %rax
    582b:      	je	0x5996 <perf_unwind_php+0x5996>
    5831:      	movq	(%rip), %rax            # 0x5838 <perf_unwind_php+0x5838>
    5838:      	movl	$0x25, 0x4(%rsp)
    5840:      	cmpl	$0x0, (%rax)
    5843:      	je	0x5ce9 <perf_unwind_php+0x5ce9>
    5849:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    5853:      	movq	%rax, 0x35(%rsp)
    5858:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    5862:      	movq	%rax, 0x30(%rsp)
    5867:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    5871:      	movq	%rax, 0x28(%rsp)
    5876:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    5880:      	movq	%rax, 0x20(%rsp)
    5885:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    588f:      	movq	%rax, 0x18(%rsp)
    5894:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    589e:      	movq	%rax, 0x10(%rsp)
    58a3:      	leaq	0x10(%rsp), %rdi
    58a8:      	movl	$0x2d, %eax
    58ad:      	movl	$0x6, %ecx
    58b2:      	movzbl	0x11(%r15), %eax
    58b7:      	addq	%rax, %r13
    58ba:      	movl	$0x2d, %esi
    58bf:      	jmp	0x5c0e <perf_unwind_php+0x5c0e>
    58c4:      	movzbl	0x13(%r15), %eax
    58c9:      	addq	%r13, %rax
    58cc:      	leaq	0x54(%rsp), %rdi
    58d1:      	movl	$0x4, %ecx
    58d6:      	movl	$0x70, %r8d
    58dc:      	movzbl	0x13(%r15), %edx
    58e1:      	addq	%r13, %rdx
    58e4:      	movl	$0x4, %esi
    58e9:      	callq	*%r8
    58ec:      	testq	%rax, %rax
    58ef:      	je	0x5a74 <perf_unwind_php+0x5a74>
    58f5:      	movq	(%rip), %rax            # 0x58fc <perf_unwind_php+0x58fc>
    58fc:      	movl	$0x25, 0x4(%rsp)
    5904:      	cmpl	$0x0, (%rax)
    5907:      	je	0x469d <perf_unwind_php+0x469d>
    590d:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    5917:      	movq	%rax, 0x3d(%rsp)
    591c:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    5926:      	movq	%rax, 0x38(%rsp)
    592b:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    5935:      	movq	%rax, 0x30(%rsp)
    593a:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    5944:      	movq	%rax, 0x28(%rsp)
    5949:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    5953:      	movq	%rax, 0x20(%rsp)
    5958:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    5962:      	movq	%rax, 0x18(%rsp)
    5967:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5971:      	movq	%rax, 0x10(%rsp)
    5976:      	leaq	0x10(%rsp), %rdi
    597b:      	movl	$0x35, %eax
    5980:      	movl	$0x6, %ecx
    5985:      	movl	$0x35, %esi
    598a:      	movq	%r13, %rdx
    598d:      	xorl	%eax, %eax
    598f:      	callq	*%rcx
    5991:      	jmp	0x469d <perf_unwind_php+0x469d>
    5996:      	movzbl	0x15(%r15), %eax
    599b:      	addq	0x68(%rsp), %rax
    59a0:      	leaq	0xc(%rsp), %rdi
    59a5:      	movl	$0x4, %ecx
    59aa:      	movl	$0x70, %r8d
    59b0:      	movzbl	0x15(%r15), %edx
    59b5:      	addq	0x68(%rsp), %rdx
    59ba:      	movl	$0x4, %esi
    59bf:      	callq	*%r8
    59c2:      	testq	%rax, %rax
    59c5:      	je	0x5b48 <perf_unwind_php+0x5b48>
    59cb:      	movq	(%rip), %rax            # 0x59d2 <perf_unwind_php+0x59d2>
    59d2:      	movl	$0x27, 0x4(%rsp)
    59da:      	cmpl	$0x0, (%rax)
    59dd:      	je	0x5ce9 <perf_unwind_php+0x5ce9>
    59e3:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    59ed:      	movq	%rax, 0x40(%rsp)
    59f2:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    59fc:      	movq	%rax, 0x38(%rsp)
    5a01:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    5a0b:      	movq	%rax, 0x30(%rsp)
    5a10:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    5a1a:      	movq	%rax, 0x28(%rsp)
    5a1f:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    5a29:      	movq	%rax, 0x20(%rsp)
    5a2e:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    5a38:      	movq	%rax, 0x18(%rsp)
    5a3d:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5a47:      	movq	%rax, 0x10(%rsp)
    5a4c:      	movb	$0x0, 0x48(%rsp)
    5a51:      	leaq	0x10(%rsp), %rdi
    5a56:      	movl	$0x39, %eax
    5a5b:      	movl	$0x6, %ecx
    5a60:      	movzbl	0x15(%r15), %edx
    5a65:      	addq	0x68(%rsp), %rdx
    5a6a:      	movl	$0x39, %esi
    5a6f:      	jmp	0x5c11 <perf_unwind_php+0x5c11>
    5a74:      	movl	0xc(%rsp), %eax
    5a78:      	movl	%eax, 0x4(%rsp)
    5a7c:      	movl	0x54(%rsp), %r13d
    5a81:      	movq	(%rip), %rax            # 0x5a88 <perf_unwind_php+0x5a88>
    5a88:      	cmpl	$0x0, (%rax)
    5a8b:      	je	0x5add <perf_unwind_php+0x5add>
    5a8d:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    5a97:      	movq	%rax, 0x1e(%rsp)
    5a9c:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    5aa6:      	movq	%rax, 0x18(%rsp)
    5aab:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    5ab5:      	movq	%rax, 0x10(%rsp)
    5aba:      	leaq	0x10(%rsp), %rdi
    5abf:      	movl	$0x16, %eax
    5ac4:      	movl	$0x6, %r8d
    5aca:      	movq	0x58(%rsp), %rdx
    5acf:      	movl	0xc(%rsp), %ecx
    5ad3:      	movl	$0x16, %esi
    5ad8:      	xorl	%eax, %eax
    5ada:      	callq	*%r8
    5add:      	movl	0x2c0(%rbp), %eax
    5ae3:      	cmpq	$0x7e, %rax
    5ae7:      	ja	0xb47 <perf_unwind_php+0xb47>
    5aed:      	movl	0x4(%rsp), %ecx
    5af1:      	shlq	$0x20, %r13
    5af5:      	orq	%r13, %rcx
    5af8:      	movq	0x58(%rsp), %rdx
    5afd:      	leal	0x1(%rax), %esi
    5b00:      	movl	%esi, 0x2c0(%rbp)
    5b06:      	leaq	(%rax,%rax,2), %rax
    5b0a:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    5b12:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    5b1a:      	movl	0x7c(%rsp), %ecx
    5b1e:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    5b25:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    5b30:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    5b3b:      	movl	$0x23, 0x4(%rsp)
    5b43:      	jmp	0x469d <perf_unwind_php+0x469d>
    5b48:      	movzbl	0x13(%r15), %eax
    5b4d:      	addq	%r13, %rax
    5b50:      	leaq	0x54(%rsp), %rdi
    5b55:      	movl	$0x4, %ecx
    5b5a:      	movl	$0x70, %r8d
    5b60:      	movzbl	0x13(%r15), %edx
    5b65:      	addq	%r13, %rdx
    5b68:      	movl	$0x4, %esi
    5b6d:      	callq	*%r8
    5b70:      	testq	%rax, %rax
    5b73:      	je	0x5c1a <perf_unwind_php+0x5c1a>
    5b79:      	movq	(%rip), %rax            # 0x5b80 <perf_unwind_php+0x5b80>
    5b80:      	movl	$0x25, 0x4(%rsp)
    5b88:      	cmpl	$0x0, (%rax)
    5b8b:      	je	0x5ce9 <perf_unwind_php+0x5ce9>
    5b91:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    5b9b:      	movq	%rax, 0x3d(%rsp)
    5ba0:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    5baa:      	movq	%rax, 0x38(%rsp)
    5baf:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    5bb9:      	movq	%rax, 0x30(%rsp)
    5bbe:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    5bc8:      	movq	%rax, 0x28(%rsp)
    5bcd:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    5bd7:      	movq	%rax, 0x20(%rsp)
    5bdc:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    5be6:      	movq	%rax, 0x18(%rsp)
    5beb:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5bf5:      	movq	%rax, 0x10(%rsp)
    5bfa:      	leaq	0x10(%rsp), %rdi
    5bff:      	movl	$0x35, %eax
    5c04:      	movl	$0x6, %ecx
    5c09:      	movl	$0x35, %esi
    5c0e:      	movq	%r13, %rdx
    5c11:      	xorl	%eax, %eax
    5c13:      	callq	*%rcx
    5c15:      	jmp	0x5ce9 <perf_unwind_php+0x5ce9>
    5c1a:      	movl	0xc(%rsp), %eax
    5c1e:      	movl	%eax, 0x4(%rsp)
    5c22:      	movl	0x54(%rsp), %r13d
    5c27:      	movq	(%rip), %rax            # 0x5c2e <perf_unwind_php+0x5c2e>
    5c2e:      	cmpl	$0x0, (%rax)
    5c31:      	je	0x5c83 <perf_unwind_php+0x5c83>
    5c33:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    5c3d:      	movq	%rax, 0x1e(%rsp)
    5c42:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    5c4c:      	movq	%rax, 0x18(%rsp)
    5c51:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    5c5b:      	movq	%rax, 0x10(%rsp)
    5c60:      	leaq	0x10(%rsp), %rdi
    5c65:      	movl	$0x16, %eax
    5c6a:      	movl	$0x6, %r8d
    5c70:      	movq	0x58(%rsp), %rdx
    5c75:      	movl	0xc(%rsp), %ecx
    5c79:      	movl	$0x16, %esi
    5c7e:      	xorl	%eax, %eax
    5c80:      	callq	*%r8
    5c83:      	movl	0x2c0(%rbp), %eax
    5c89:      	cmpq	$0x7e, %rax
    5c8d:      	ja	0xb47 <perf_unwind_php+0xb47>
    5c93:      	movl	0x4(%rsp), %ecx
    5c97:      	shlq	$0x20, %r13
    5c9b:      	orq	%r13, %rcx
    5c9e:      	movq	0x58(%rsp), %rdx
    5ca3:      	leal	0x1(%rax), %esi
    5ca6:      	movl	%esi, 0x2c0(%rbp)
    5cac:      	leaq	(%rax,%rax,2), %rax
    5cb0:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    5cb8:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    5cc0:      	movl	0x7c(%rsp), %ecx
    5cc4:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    5ccb:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    5cd6:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    5ce1:      	movl	$0x23, 0x4(%rsp)
    5ce9:      	movl	0x4(%rsp), %eax
    5ced:      	movl	%eax, 0x58(%rsp)
    5cf1:      	movq	(%rip), %rdi            # 0x5cf8 <perf_unwind_php+0x5cf8>
    5cf8:      	leaq	0x58(%rsp), %rsi
    5cfd:      	movl	$0x1, %eax
    5d02:      	callq	*%rax
    5d04:      	testq	%rax, %rax
    5d07:      	je	0x5d11 <perf_unwind_php+0x5d11>
    5d09:      	incq	(%rax)
    5d0c:      	jmp	0x5d93 <perf_unwind_php+0x5d93>
    5d11:      	movq	(%rip), %rax            # 0x5d18 <perf_unwind_php+0x5d18>
    5d18:      	cmpl	$0x0, (%rax)
    5d1b:      	je	0x5d93 <perf_unwind_php+0x5d93>
    5d1d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5d27:      	movq	%rax, 0x36(%rsp)
    5d2c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5d36:      	movq	%rax, 0x30(%rsp)
    5d3b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5d45:      	movq	%rax, 0x28(%rsp)
    5d4a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5d54:      	movq	%rax, 0x20(%rsp)
    5d59:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5d63:      	movq	%rax, 0x18(%rsp)
    5d68:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5d72:      	movq	%rax, 0x10(%rsp)
    5d77:      	leaq	0x10(%rsp), %rdi
    5d7c:      	movl	$0x2e, %eax
    5d81:      	movl	$0x6, %ecx
    5d86:      	movl	0x58(%rsp), %edx
    5d8a:      	movl	$0x2e, %esi
    5d8f:      	xorl	%eax, %eax
    5d91:      	callq	*%rcx
    5d93:      	cmpl	$0x23, 0x4(%rsp)
    5d98:      	jne	0x85e3 <perf_unwind_php+0x85e3>
    5d9e:      	movzbl	0x12(%r15), %eax
    5da3:      	addq	0x70(%rsp), %rax
    5da8:      	leaq	0x70(%rsp), %rdi
    5dad:      	movl	$0x8, %ecx
    5db2:      	movl	$0x70, %r8d
    5db8:      	movzbl	0x12(%r15), %edx
    5dbd:      	addq	0x70(%rsp), %rdx
    5dc2:      	movl	$0x8, %esi
    5dc7:      	callq	*%r8
    5dca:      	testq	%rax, %rax
    5dcd:      	jne	0x317 <perf_unwind_php+0x317>
    5dd3:      	movq	0x70(%rsp), %r13
    5dd8:      	testq	%r13, %r13
    5ddb:      	je	0x83ba <perf_unwind_php+0x83ba>
    5de1:      	testb	$0x2, 0x56(%rsp)
    5de6:      	jne	0x83ba <perf_unwind_php+0x83ba>
    5dec:      	movzbl	0x10(%r15), %eax
    5df1:      	addq	%r13, %rax
    5df4:      	leaq	0x58(%rsp), %rdi
    5df9:      	movl	$0x8, %ecx
    5dfe:      	movl	$0x70, %r8d
    5e04:      	movzbl	0x10(%r15), %edx
    5e09:      	addq	%r13, %rdx
    5e0c:      	movl	$0x8, %esi
    5e11:      	callq	*%r8
    5e14:      	testq	%rax, %rax
    5e17:      	je	0x5eb8 <perf_unwind_php+0x5eb8>
    5e1d:      	movq	(%rip), %rax            # 0x5e24 <perf_unwind_php+0x5e24>
    5e24:      	movl	$0x25, 0x4(%rsp)
    5e2c:      	cmpl	$0x0, (%rax)
    5e2f:      	je	0x6336 <perf_unwind_php+0x6336>
    5e35:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    5e3f:      	movq	%rax, 0x38(%rsp)
    5e44:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    5e4e:      	movq	%rax, 0x30(%rsp)
    5e53:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    5e5d:      	movq	%rax, 0x28(%rsp)
    5e62:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    5e6c:      	movq	%rax, 0x20(%rsp)
    5e71:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    5e7b:      	movq	%rax, 0x18(%rsp)
    5e80:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5e8a:      	movq	%rax, 0x10(%rsp)
    5e8f:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    5e97:      	leaq	0x10(%rsp), %rdi
    5e9c:      	movl	$0x33, %eax
    5ea1:      	movl	$0x6, %ecx
    5ea6:      	movzbl	0x10(%r15), %eax
    5eab:      	addq	%rax, %r13
    5eae:      	movl	$0x33, %esi
    5eb3:      	jmp	0x625b <perf_unwind_php+0x625b>
    5eb8:      	movq	0x58(%rsp), %rax
    5ebd:      	testq	%rax, %rax
    5ec0:      	je	0x5f8e <perf_unwind_php+0x5f8e>
    5ec6:      	movzbl	0x14(%r15), %ecx
    5ecb:      	addq	%rcx, %rax
    5ece:      	leaq	0xb(%rsp), %rdi
    5ed3:      	movl	$0x1, %ecx
    5ed8:      	movl	$0x70, %r8d
    5ede:      	movzbl	0x14(%r15), %edx
    5ee3:      	addq	0x58(%rsp), %rdx
    5ee8:      	movl	$0x1, %esi
    5eed:      	callq	*%r8
    5ef0:      	testq	%rax, %rax
    5ef3:      	je	0x5fd0 <perf_unwind_php+0x5fd0>
    5ef9:      	movq	(%rip), %rax            # 0x5f00 <perf_unwind_php+0x5f00>
    5f00:      	cmpl	$0x0, (%rax)
    5f03:      	je	0x5f81 <perf_unwind_php+0x5f81>
    5f05:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    5f0f:      	movq	%rax, 0x38(%rsp)
    5f14:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    5f1e:      	movq	%rax, 0x30(%rsp)
    5f23:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    5f2d:      	movq	%rax, 0x28(%rsp)
    5f32:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    5f3c:      	movq	%rax, 0x20(%rsp)
    5f41:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    5f4b:      	movq	%rax, 0x18(%rsp)
    5f50:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5f5a:      	movq	%rax, 0x10(%rsp)
    5f5f:      	movb	$0x0, 0x40(%rsp)
    5f64:      	leaq	0x10(%rsp), %rdi
    5f69:      	movl	$0x31, %eax
    5f6e:      	movl	$0x6, %ecx
    5f73:      	movq	0x58(%rsp), %rdx
    5f78:      	movl	$0x31, %esi
    5f7d:      	xorl	%eax, %eax
    5f7f:      	callq	*%rcx
    5f81:      	movl	$0x26, 0x4(%rsp)
    5f89:      	jmp	0x6336 <perf_unwind_php+0x6336>
    5f8e:      	movl	0x2c0(%rbp), %eax
    5f94:      	cmpq	$0x7e, %rax
    5f98:      	ja	0x40e <perf_unwind_php+0x40e>
    5f9e:      	leal	0x1(%rax), %ecx
    5fa1:      	movl	%ecx, 0x2c0(%rbp)
    5fa7:      	leaq	(%rax,%rax,2), %rax
    5fab:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    5fb7:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    5fc3:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    5fcb:      	jmp	0x6318 <perf_unwind_php+0x6318>
    5fd0:      	movl	$0x0, 0xc(%rsp)
    5fd8:      	movzbl	0xb(%rsp), %eax
    5fdd:      	cmpl	$0x4, %eax
    5fe0:      	je	0x5ff3 <perf_unwind_php+0x5ff3>
    5fe2:      	movl	$0x0, 0x4(%rsp)
    5fea:      	cmpl	$0x2, %eax
    5fed:      	jne	0x626f <perf_unwind_php+0x626f>
    5ff3:      	movzbl	0x11(%r15), %eax
    5ff8:      	addq	%r13, %rax
    5ffb:      	leaq	0x68(%rsp), %rdi
    6000:      	movl	$0x8, %ecx
    6005:      	movl	$0x70, %r8d
    600b:      	movzbl	0x11(%r15), %edx
    6010:      	addq	%r13, %rdx
    6013:      	movl	$0x8, %esi
    6018:      	callq	*%r8
    601b:      	testq	%rax, %rax
    601e:      	je	0x60b7 <perf_unwind_php+0x60b7>
    6024:      	movq	(%rip), %rax            # 0x602b <perf_unwind_php+0x602b>
    602b:      	movl	$0x25, 0x4(%rsp)
    6033:      	cmpl	$0x0, (%rax)
    6036:      	je	0x6336 <perf_unwind_php+0x6336>
    603c:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    6046:      	movq	%rax, 0x35(%rsp)
    604b:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    6055:      	movq	%rax, 0x30(%rsp)
    605a:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    6064:      	movq	%rax, 0x28(%rsp)
    6069:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    6073:      	movq	%rax, 0x20(%rsp)
    6078:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    6082:      	movq	%rax, 0x18(%rsp)
    6087:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6091:      	movq	%rax, 0x10(%rsp)
    6096:      	leaq	0x10(%rsp), %rdi
    609b:      	movl	$0x2d, %eax
    60a0:      	movl	$0x6, %ecx
    60a5:      	movzbl	0x11(%r15), %eax
    60aa:      	addq	%rax, %r13
    60ad:      	movl	$0x2d, %esi
    60b2:      	jmp	0x625b <perf_unwind_php+0x625b>
    60b7:      	movzbl	0x15(%r15), %eax
    60bc:      	addq	0x68(%rsp), %rax
    60c1:      	leaq	0xc(%rsp), %rdi
    60c6:      	movl	$0x4, %ecx
    60cb:      	movl	$0x70, %r8d
    60d1:      	movzbl	0x15(%r15), %edx
    60d6:      	addq	0x68(%rsp), %rdx
    60db:      	movl	$0x4, %esi
    60e0:      	callq	*%r8
    60e3:      	testq	%rax, %rax
    60e6:      	je	0x6195 <perf_unwind_php+0x6195>
    60ec:      	movq	(%rip), %rax            # 0x60f3 <perf_unwind_php+0x60f3>
    60f3:      	movl	$0x27, 0x4(%rsp)
    60fb:      	cmpl	$0x0, (%rax)
    60fe:      	je	0x6336 <perf_unwind_php+0x6336>
    6104:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    610e:      	movq	%rax, 0x40(%rsp)
    6113:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    611d:      	movq	%rax, 0x38(%rsp)
    6122:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    612c:      	movq	%rax, 0x30(%rsp)
    6131:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    613b:      	movq	%rax, 0x28(%rsp)
    6140:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    614a:      	movq	%rax, 0x20(%rsp)
    614f:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    6159:      	movq	%rax, 0x18(%rsp)
    615e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6168:      	movq	%rax, 0x10(%rsp)
    616d:      	movb	$0x0, 0x48(%rsp)
    6172:      	leaq	0x10(%rsp), %rdi
    6177:      	movl	$0x39, %eax
    617c:      	movl	$0x6, %ecx
    6181:      	movzbl	0x15(%r15), %edx
    6186:      	addq	0x68(%rsp), %rdx
    618b:      	movl	$0x39, %esi
    6190:      	jmp	0x625e <perf_unwind_php+0x625e>
    6195:      	movzbl	0x13(%r15), %eax
    619a:      	addq	%r13, %rax
    619d:      	leaq	0x54(%rsp), %rdi
    61a2:      	movl	$0x4, %ecx
    61a7:      	movl	$0x70, %r8d
    61ad:      	movzbl	0x13(%r15), %edx
    61b2:      	addq	%r13, %rdx
    61b5:      	movl	$0x4, %esi
    61ba:      	callq	*%r8
    61bd:      	testq	%rax, %rax
    61c0:      	je	0x6267 <perf_unwind_php+0x6267>
    61c6:      	movq	(%rip), %rax            # 0x61cd <perf_unwind_php+0x61cd>
    61cd:      	movl	$0x25, 0x4(%rsp)
    61d5:      	cmpl	$0x0, (%rax)
    61d8:      	je	0x6336 <perf_unwind_php+0x6336>
    61de:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    61e8:      	movq	%rax, 0x3d(%rsp)
    61ed:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    61f7:      	movq	%rax, 0x38(%rsp)
    61fc:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    6206:      	movq	%rax, 0x30(%rsp)
    620b:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    6215:      	movq	%rax, 0x28(%rsp)
    621a:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    6224:      	movq	%rax, 0x20(%rsp)
    6229:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    6233:      	movq	%rax, 0x18(%rsp)
    6238:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6242:      	movq	%rax, 0x10(%rsp)
    6247:      	leaq	0x10(%rsp), %rdi
    624c:      	movl	$0x35, %eax
    6251:      	movl	$0x6, %ecx
    6256:      	movl	$0x35, %esi
    625b:      	movq	%r13, %rdx
    625e:      	xorl	%eax, %eax
    6260:      	callq	*%rcx
    6262:      	jmp	0x6336 <perf_unwind_php+0x6336>
    6267:      	movl	0xc(%rsp), %eax
    626b:      	movl	%eax, 0x4(%rsp)
    626f:      	movl	0x54(%rsp), %r13d
    6274:      	movq	(%rip), %rax            # 0x627b <perf_unwind_php+0x627b>
    627b:      	cmpl	$0x0, (%rax)
    627e:      	je	0x62d0 <perf_unwind_php+0x62d0>
    6280:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    628a:      	movq	%rax, 0x1e(%rsp)
    628f:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    6299:      	movq	%rax, 0x18(%rsp)
    629e:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    62a8:      	movq	%rax, 0x10(%rsp)
    62ad:      	leaq	0x10(%rsp), %rdi
    62b2:      	movl	$0x16, %eax
    62b7:      	movl	$0x6, %r8d
    62bd:      	movq	0x58(%rsp), %rdx
    62c2:      	movl	0xc(%rsp), %ecx
    62c6:      	movl	$0x16, %esi
    62cb:      	xorl	%eax, %eax
    62cd:      	callq	*%r8
    62d0:      	movl	0x2c0(%rbp), %eax
    62d6:      	cmpq	$0x7e, %rax
    62da:      	ja	0xb47 <perf_unwind_php+0xb47>
    62e0:      	movl	0x4(%rsp), %ecx
    62e4:      	shlq	$0x20, %r13
    62e8:      	orq	%r13, %rcx
    62eb:      	movq	0x58(%rsp), %rdx
    62f0:      	leal	0x1(%rax), %esi
    62f3:      	movl	%esi, 0x2c0(%rbp)
    62f9:      	leaq	(%rax,%rax,2), %rax
    62fd:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    6305:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    630d:      	movl	0x7c(%rsp), %ecx
    6311:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    6318:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    6323:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    632e:      	movl	$0x23, 0x4(%rsp)
    6336:      	movl	0x4(%rsp), %eax
    633a:      	movl	%eax, 0x58(%rsp)
    633e:      	movq	(%rip), %rdi            # 0x6345 <perf_unwind_php+0x6345>
    6345:      	leaq	0x58(%rsp), %rsi
    634a:      	movl	$0x1, %eax
    634f:      	callq	*%rax
    6351:      	testq	%rax, %rax
    6354:      	je	0x635e <perf_unwind_php+0x635e>
    6356:      	incq	(%rax)
    6359:      	jmp	0x63e0 <perf_unwind_php+0x63e0>
    635e:      	movq	(%rip), %rax            # 0x6365 <perf_unwind_php+0x6365>
    6365:      	cmpl	$0x0, (%rax)
    6368:      	je	0x63e0 <perf_unwind_php+0x63e0>
    636a:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    6374:      	movq	%rax, 0x36(%rsp)
    6379:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    6383:      	movq	%rax, 0x30(%rsp)
    6388:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    6392:      	movq	%rax, 0x28(%rsp)
    6397:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    63a1:      	movq	%rax, 0x20(%rsp)
    63a6:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    63b0:      	movq	%rax, 0x18(%rsp)
    63b5:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    63bf:      	movq	%rax, 0x10(%rsp)
    63c4:      	leaq	0x10(%rsp), %rdi
    63c9:      	movl	$0x2e, %eax
    63ce:      	movl	$0x6, %ecx
    63d3:      	movl	0x58(%rsp), %edx
    63d7:      	movl	$0x2e, %esi
    63dc:      	xorl	%eax, %eax
    63de:      	callq	*%rcx
    63e0:      	cmpl	$0x23, 0x4(%rsp)
    63e5:      	jne	0x85e3 <perf_unwind_php+0x85e3>
    63eb:      	movzbl	0x12(%r15), %eax
    63f0:      	addq	0x70(%rsp), %rax
    63f5:      	leaq	0x70(%rsp), %rdi
    63fa:      	movl	$0x8, %ecx
    63ff:      	movl	$0x70, %r8d
    6405:      	movzbl	0x12(%r15), %edx
    640a:      	addq	0x70(%rsp), %rdx
    640f:      	movl	$0x8, %esi
    6414:      	callq	*%r8
    6417:      	testq	%rax, %rax
    641a:      	jne	0x317 <perf_unwind_php+0x317>
    6420:      	movq	0x70(%rsp), %r13
    6425:      	testq	%r13, %r13
    6428:      	je	0x83ba <perf_unwind_php+0x83ba>
    642e:      	testb	$0x2, 0x56(%rsp)
    6433:      	jne	0x83ba <perf_unwind_php+0x83ba>
    6439:      	movzbl	0x10(%r15), %eax
    643e:      	addq	%r13, %rax
    6441:      	leaq	0x58(%rsp), %rdi
    6446:      	movl	$0x8, %ecx
    644b:      	movl	$0x70, %r8d
    6451:      	movzbl	0x10(%r15), %edx
    6456:      	addq	%r13, %rdx
    6459:      	movl	$0x8, %esi
    645e:      	callq	*%r8
    6461:      	testq	%rax, %rax
    6464:      	je	0x6505 <perf_unwind_php+0x6505>
    646a:      	movq	(%rip), %rax            # 0x6471 <perf_unwind_php+0x6471>
    6471:      	movl	$0x25, 0x4(%rsp)
    6479:      	cmpl	$0x0, (%rax)
    647c:      	je	0x6983 <perf_unwind_php+0x6983>
    6482:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    648c:      	movq	%rax, 0x38(%rsp)
    6491:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    649b:      	movq	%rax, 0x30(%rsp)
    64a0:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    64aa:      	movq	%rax, 0x28(%rsp)
    64af:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    64b9:      	movq	%rax, 0x20(%rsp)
    64be:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    64c8:      	movq	%rax, 0x18(%rsp)
    64cd:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    64d7:      	movq	%rax, 0x10(%rsp)
    64dc:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    64e4:      	leaq	0x10(%rsp), %rdi
    64e9:      	movl	$0x33, %eax
    64ee:      	movl	$0x6, %ecx
    64f3:      	movzbl	0x10(%r15), %eax
    64f8:      	addq	%rax, %r13
    64fb:      	movl	$0x33, %esi
    6500:      	jmp	0x68a8 <perf_unwind_php+0x68a8>
    6505:      	movq	0x58(%rsp), %rax
    650a:      	testq	%rax, %rax
    650d:      	je	0x65db <perf_unwind_php+0x65db>
    6513:      	movzbl	0x14(%r15), %ecx
    6518:      	addq	%rcx, %rax
    651b:      	leaq	0xb(%rsp), %rdi
    6520:      	movl	$0x1, %ecx
    6525:      	movl	$0x70, %r8d
    652b:      	movzbl	0x14(%r15), %edx
    6530:      	addq	0x58(%rsp), %rdx
    6535:      	movl	$0x1, %esi
    653a:      	callq	*%r8
    653d:      	testq	%rax, %rax
    6540:      	je	0x661d <perf_unwind_php+0x661d>
    6546:      	movq	(%rip), %rax            # 0x654d <perf_unwind_php+0x654d>
    654d:      	cmpl	$0x0, (%rax)
    6550:      	je	0x65ce <perf_unwind_php+0x65ce>
    6552:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    655c:      	movq	%rax, 0x38(%rsp)
    6561:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    656b:      	movq	%rax, 0x30(%rsp)
    6570:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    657a:      	movq	%rax, 0x28(%rsp)
    657f:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    6589:      	movq	%rax, 0x20(%rsp)
    658e:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    6598:      	movq	%rax, 0x18(%rsp)
    659d:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    65a7:      	movq	%rax, 0x10(%rsp)
    65ac:      	movb	$0x0, 0x40(%rsp)
    65b1:      	leaq	0x10(%rsp), %rdi
    65b6:      	movl	$0x31, %eax
    65bb:      	movl	$0x6, %ecx
    65c0:      	movq	0x58(%rsp), %rdx
    65c5:      	movl	$0x31, %esi
    65ca:      	xorl	%eax, %eax
    65cc:      	callq	*%rcx
    65ce:      	movl	$0x26, 0x4(%rsp)
    65d6:      	jmp	0x6983 <perf_unwind_php+0x6983>
    65db:      	movl	0x2c0(%rbp), %eax
    65e1:      	cmpq	$0x7e, %rax
    65e5:      	ja	0x40e <perf_unwind_php+0x40e>
    65eb:      	leal	0x1(%rax), %ecx
    65ee:      	movl	%ecx, 0x2c0(%rbp)
    65f4:      	leaq	(%rax,%rax,2), %rax
    65f8:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    6604:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    6610:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    6618:      	jmp	0x6965 <perf_unwind_php+0x6965>
    661d:      	movl	$0x0, 0xc(%rsp)
    6625:      	movzbl	0xb(%rsp), %eax
    662a:      	cmpl	$0x4, %eax
    662d:      	je	0x6640 <perf_unwind_php+0x6640>
    662f:      	movl	$0x0, 0x4(%rsp)
    6637:      	cmpl	$0x2, %eax
    663a:      	jne	0x68bc <perf_unwind_php+0x68bc>
    6640:      	movzbl	0x11(%r15), %eax
    6645:      	addq	%r13, %rax
    6648:      	leaq	0x68(%rsp), %rdi
    664d:      	movl	$0x8, %ecx
    6652:      	movl	$0x70, %r8d
    6658:      	movzbl	0x11(%r15), %edx
    665d:      	addq	%r13, %rdx
    6660:      	movl	$0x8, %esi
    6665:      	callq	*%r8
    6668:      	testq	%rax, %rax
    666b:      	je	0x6704 <perf_unwind_php+0x6704>
    6671:      	movq	(%rip), %rax            # 0x6678 <perf_unwind_php+0x6678>
    6678:      	movl	$0x25, 0x4(%rsp)
    6680:      	cmpl	$0x0, (%rax)
    6683:      	je	0x6983 <perf_unwind_php+0x6983>
    6689:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    6693:      	movq	%rax, 0x35(%rsp)
    6698:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    66a2:      	movq	%rax, 0x30(%rsp)
    66a7:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    66b1:      	movq	%rax, 0x28(%rsp)
    66b6:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    66c0:      	movq	%rax, 0x20(%rsp)
    66c5:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    66cf:      	movq	%rax, 0x18(%rsp)
    66d4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    66de:      	movq	%rax, 0x10(%rsp)
    66e3:      	leaq	0x10(%rsp), %rdi
    66e8:      	movl	$0x2d, %eax
    66ed:      	movl	$0x6, %ecx
    66f2:      	movzbl	0x11(%r15), %eax
    66f7:      	addq	%rax, %r13
    66fa:      	movl	$0x2d, %esi
    66ff:      	jmp	0x68a8 <perf_unwind_php+0x68a8>
    6704:      	movzbl	0x15(%r15), %eax
    6709:      	addq	0x68(%rsp), %rax
    670e:      	leaq	0xc(%rsp), %rdi
    6713:      	movl	$0x4, %ecx
    6718:      	movl	$0x70, %r8d
    671e:      	movzbl	0x15(%r15), %edx
    6723:      	addq	0x68(%rsp), %rdx
    6728:      	movl	$0x4, %esi
    672d:      	callq	*%r8
    6730:      	testq	%rax, %rax
    6733:      	je	0x67e2 <perf_unwind_php+0x67e2>
    6739:      	movq	(%rip), %rax            # 0x6740 <perf_unwind_php+0x6740>
    6740:      	movl	$0x27, 0x4(%rsp)
    6748:      	cmpl	$0x0, (%rax)
    674b:      	je	0x6983 <perf_unwind_php+0x6983>
    6751:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    675b:      	movq	%rax, 0x40(%rsp)
    6760:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    676a:      	movq	%rax, 0x38(%rsp)
    676f:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    6779:      	movq	%rax, 0x30(%rsp)
    677e:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    6788:      	movq	%rax, 0x28(%rsp)
    678d:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    6797:      	movq	%rax, 0x20(%rsp)
    679c:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    67a6:      	movq	%rax, 0x18(%rsp)
    67ab:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    67b5:      	movq	%rax, 0x10(%rsp)
    67ba:      	movb	$0x0, 0x48(%rsp)
    67bf:      	leaq	0x10(%rsp), %rdi
    67c4:      	movl	$0x39, %eax
    67c9:      	movl	$0x6, %ecx
    67ce:      	movzbl	0x15(%r15), %edx
    67d3:      	addq	0x68(%rsp), %rdx
    67d8:      	movl	$0x39, %esi
    67dd:      	jmp	0x68ab <perf_unwind_php+0x68ab>
    67e2:      	movzbl	0x13(%r15), %eax
    67e7:      	addq	%r13, %rax
    67ea:      	leaq	0x54(%rsp), %rdi
    67ef:      	movl	$0x4, %ecx
    67f4:      	movl	$0x70, %r8d
    67fa:      	movzbl	0x13(%r15), %edx
    67ff:      	addq	%r13, %rdx
    6802:      	movl	$0x4, %esi
    6807:      	callq	*%r8
    680a:      	testq	%rax, %rax
    680d:      	je	0x68b4 <perf_unwind_php+0x68b4>
    6813:      	movq	(%rip), %rax            # 0x681a <perf_unwind_php+0x681a>
    681a:      	movl	$0x25, 0x4(%rsp)
    6822:      	cmpl	$0x0, (%rax)
    6825:      	je	0x6983 <perf_unwind_php+0x6983>
    682b:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    6835:      	movq	%rax, 0x3d(%rsp)
    683a:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    6844:      	movq	%rax, 0x38(%rsp)
    6849:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    6853:      	movq	%rax, 0x30(%rsp)
    6858:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    6862:      	movq	%rax, 0x28(%rsp)
    6867:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    6871:      	movq	%rax, 0x20(%rsp)
    6876:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    6880:      	movq	%rax, 0x18(%rsp)
    6885:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    688f:      	movq	%rax, 0x10(%rsp)
    6894:      	leaq	0x10(%rsp), %rdi
    6899:      	movl	$0x35, %eax
    689e:      	movl	$0x6, %ecx
    68a3:      	movl	$0x35, %esi
    68a8:      	movq	%r13, %rdx
    68ab:      	xorl	%eax, %eax
    68ad:      	callq	*%rcx
    68af:      	jmp	0x6983 <perf_unwind_php+0x6983>
    68b4:      	movl	0xc(%rsp), %eax
    68b8:      	movl	%eax, 0x4(%rsp)
    68bc:      	movl	0x54(%rsp), %r13d
    68c1:      	movq	(%rip), %rax            # 0x68c8 <perf_unwind_php+0x68c8>
    68c8:      	cmpl	$0x0, (%rax)
    68cb:      	je	0x691d <perf_unwind_php+0x691d>
    68cd:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    68d7:      	movq	%rax, 0x1e(%rsp)
    68dc:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    68e6:      	movq	%rax, 0x18(%rsp)
    68eb:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    68f5:      	movq	%rax, 0x10(%rsp)
    68fa:      	leaq	0x10(%rsp), %rdi
    68ff:      	movl	$0x16, %eax
    6904:      	movl	$0x6, %r8d
    690a:      	movq	0x58(%rsp), %rdx
    690f:      	movl	0xc(%rsp), %ecx
    6913:      	movl	$0x16, %esi
    6918:      	xorl	%eax, %eax
    691a:      	callq	*%r8
    691d:      	movl	0x2c0(%rbp), %eax
    6923:      	cmpq	$0x7e, %rax
    6927:      	ja	0xb47 <perf_unwind_php+0xb47>
    692d:      	movl	0x4(%rsp), %ecx
    6931:      	shlq	$0x20, %r13
    6935:      	orq	%r13, %rcx
    6938:      	movq	0x58(%rsp), %rdx
    693d:      	leal	0x1(%rax), %esi
    6940:      	movl	%esi, 0x2c0(%rbp)
    6946:      	leaq	(%rax,%rax,2), %rax
    694a:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    6952:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    695a:      	movl	0x7c(%rsp), %ecx
    695e:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    6965:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    6970:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    697b:      	movl	$0x23, 0x4(%rsp)
    6983:      	movl	0x4(%rsp), %eax
    6987:      	movl	%eax, 0x58(%rsp)
    698b:      	movq	(%rip), %rdi            # 0x6992 <perf_unwind_php+0x6992>
    6992:      	leaq	0x58(%rsp), %rsi
    6997:      	movl	$0x1, %eax
    699c:      	callq	*%rax
    699e:      	testq	%rax, %rax
    69a1:      	je	0x69ab <perf_unwind_php+0x69ab>
    69a3:      	incq	(%rax)
    69a6:      	jmp	0x6a2d <perf_unwind_php+0x6a2d>
    69ab:      	movq	(%rip), %rax            # 0x69b2 <perf_unwind_php+0x69b2>
    69b2:      	cmpl	$0x0, (%rax)
    69b5:      	je	0x6a2d <perf_unwind_php+0x6a2d>
    69b7:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    69c1:      	movq	%rax, 0x36(%rsp)
    69c6:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    69d0:      	movq	%rax, 0x30(%rsp)
    69d5:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    69df:      	movq	%rax, 0x28(%rsp)
    69e4:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    69ee:      	movq	%rax, 0x20(%rsp)
    69f3:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    69fd:      	movq	%rax, 0x18(%rsp)
    6a02:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6a0c:      	movq	%rax, 0x10(%rsp)
    6a11:      	leaq	0x10(%rsp), %rdi
    6a16:      	movl	$0x2e, %eax
    6a1b:      	movl	$0x6, %ecx
    6a20:      	movl	0x58(%rsp), %edx
    6a24:      	movl	$0x2e, %esi
    6a29:      	xorl	%eax, %eax
    6a2b:      	callq	*%rcx
    6a2d:      	cmpl	$0x23, 0x4(%rsp)
    6a32:      	jne	0x85e3 <perf_unwind_php+0x85e3>
    6a38:      	movzbl	0x12(%r15), %eax
    6a3d:      	addq	0x70(%rsp), %rax
    6a42:      	leaq	0x70(%rsp), %rdi
    6a47:      	movl	$0x8, %ecx
    6a4c:      	movl	$0x70, %r8d
    6a52:      	movzbl	0x12(%r15), %edx
    6a57:      	addq	0x70(%rsp), %rdx
    6a5c:      	movl	$0x8, %esi
    6a61:      	callq	*%r8
    6a64:      	testq	%rax, %rax
    6a67:      	jne	0x317 <perf_unwind_php+0x317>
    6a6d:      	movq	0x70(%rsp), %r13
    6a72:      	testq	%r13, %r13
    6a75:      	je	0x83ba <perf_unwind_php+0x83ba>
    6a7b:      	testb	$0x2, 0x56(%rsp)
    6a80:      	jne	0x83ba <perf_unwind_php+0x83ba>
    6a86:      	movzbl	0x10(%r15), %eax
    6a8b:      	addq	%r13, %rax
    6a8e:      	leaq	0x58(%rsp), %rdi
    6a93:      	movl	$0x8, %ecx
    6a98:      	movl	$0x70, %r8d
    6a9e:      	movzbl	0x10(%r15), %edx
    6aa3:      	addq	%r13, %rdx
    6aa6:      	movl	$0x8, %esi
    6aab:      	callq	*%r8
    6aae:      	testq	%rax, %rax
    6ab1:      	je	0x6b52 <perf_unwind_php+0x6b52>
    6ab7:      	movq	(%rip), %rax            # 0x6abe <perf_unwind_php+0x6abe>
    6abe:      	movl	$0x25, 0x4(%rsp)
    6ac6:      	cmpl	$0x0, (%rax)
    6ac9:      	je	0x6fd0 <perf_unwind_php+0x6fd0>
    6acf:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    6ad9:      	movq	%rax, 0x38(%rsp)
    6ade:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    6ae8:      	movq	%rax, 0x30(%rsp)
    6aed:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    6af7:      	movq	%rax, 0x28(%rsp)
    6afc:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    6b06:      	movq	%rax, 0x20(%rsp)
    6b0b:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    6b15:      	movq	%rax, 0x18(%rsp)
    6b1a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6b24:      	movq	%rax, 0x10(%rsp)
    6b29:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    6b31:      	leaq	0x10(%rsp), %rdi
    6b36:      	movl	$0x33, %eax
    6b3b:      	movl	$0x6, %ecx
    6b40:      	movzbl	0x10(%r15), %eax
    6b45:      	addq	%rax, %r13
    6b48:      	movl	$0x33, %esi
    6b4d:      	jmp	0x6ef5 <perf_unwind_php+0x6ef5>
    6b52:      	movq	0x58(%rsp), %rax
    6b57:      	testq	%rax, %rax
    6b5a:      	je	0x6c28 <perf_unwind_php+0x6c28>
    6b60:      	movzbl	0x14(%r15), %ecx
    6b65:      	addq	%rcx, %rax
    6b68:      	leaq	0xb(%rsp), %rdi
    6b6d:      	movl	$0x1, %ecx
    6b72:      	movl	$0x70, %r8d
    6b78:      	movzbl	0x14(%r15), %edx
    6b7d:      	addq	0x58(%rsp), %rdx
    6b82:      	movl	$0x1, %esi
    6b87:      	callq	*%r8
    6b8a:      	testq	%rax, %rax
    6b8d:      	je	0x6c6a <perf_unwind_php+0x6c6a>
    6b93:      	movq	(%rip), %rax            # 0x6b9a <perf_unwind_php+0x6b9a>
    6b9a:      	cmpl	$0x0, (%rax)
    6b9d:      	je	0x6c1b <perf_unwind_php+0x6c1b>
    6b9f:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    6ba9:      	movq	%rax, 0x38(%rsp)
    6bae:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    6bb8:      	movq	%rax, 0x30(%rsp)
    6bbd:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    6bc7:      	movq	%rax, 0x28(%rsp)
    6bcc:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    6bd6:      	movq	%rax, 0x20(%rsp)
    6bdb:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    6be5:      	movq	%rax, 0x18(%rsp)
    6bea:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6bf4:      	movq	%rax, 0x10(%rsp)
    6bf9:      	movb	$0x0, 0x40(%rsp)
    6bfe:      	leaq	0x10(%rsp), %rdi
    6c03:      	movl	$0x31, %eax
    6c08:      	movl	$0x6, %ecx
    6c0d:      	movq	0x58(%rsp), %rdx
    6c12:      	movl	$0x31, %esi
    6c17:      	xorl	%eax, %eax
    6c19:      	callq	*%rcx
    6c1b:      	movl	$0x26, 0x4(%rsp)
    6c23:      	jmp	0x6fd0 <perf_unwind_php+0x6fd0>
    6c28:      	movl	0x2c0(%rbp), %eax
    6c2e:      	cmpq	$0x7e, %rax
    6c32:      	ja	0x40e <perf_unwind_php+0x40e>
    6c38:      	leal	0x1(%rax), %ecx
    6c3b:      	movl	%ecx, 0x2c0(%rbp)
    6c41:      	leaq	(%rax,%rax,2), %rax
    6c45:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    6c51:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    6c5d:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    6c65:      	jmp	0x6fb2 <perf_unwind_php+0x6fb2>
    6c6a:      	movl	$0x0, 0xc(%rsp)
    6c72:      	movzbl	0xb(%rsp), %eax
    6c77:      	cmpl	$0x4, %eax
    6c7a:      	je	0x6c8d <perf_unwind_php+0x6c8d>
    6c7c:      	movl	$0x0, 0x4(%rsp)
    6c84:      	cmpl	$0x2, %eax
    6c87:      	jne	0x6f09 <perf_unwind_php+0x6f09>
    6c8d:      	movzbl	0x11(%r15), %eax
    6c92:      	addq	%r13, %rax
    6c95:      	leaq	0x68(%rsp), %rdi
    6c9a:      	movl	$0x8, %ecx
    6c9f:      	movl	$0x70, %r8d
    6ca5:      	movzbl	0x11(%r15), %edx
    6caa:      	addq	%r13, %rdx
    6cad:      	movl	$0x8, %esi
    6cb2:      	callq	*%r8
    6cb5:      	testq	%rax, %rax
    6cb8:      	je	0x6d51 <perf_unwind_php+0x6d51>
    6cbe:      	movq	(%rip), %rax            # 0x6cc5 <perf_unwind_php+0x6cc5>
    6cc5:      	movl	$0x25, 0x4(%rsp)
    6ccd:      	cmpl	$0x0, (%rax)
    6cd0:      	je	0x6fd0 <perf_unwind_php+0x6fd0>
    6cd6:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    6ce0:      	movq	%rax, 0x35(%rsp)
    6ce5:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    6cef:      	movq	%rax, 0x30(%rsp)
    6cf4:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    6cfe:      	movq	%rax, 0x28(%rsp)
    6d03:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    6d0d:      	movq	%rax, 0x20(%rsp)
    6d12:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    6d1c:      	movq	%rax, 0x18(%rsp)
    6d21:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6d2b:      	movq	%rax, 0x10(%rsp)
    6d30:      	leaq	0x10(%rsp), %rdi
    6d35:      	movl	$0x2d, %eax
    6d3a:      	movl	$0x6, %ecx
    6d3f:      	movzbl	0x11(%r15), %eax
    6d44:      	addq	%rax, %r13
    6d47:      	movl	$0x2d, %esi
    6d4c:      	jmp	0x6ef5 <perf_unwind_php+0x6ef5>
    6d51:      	movzbl	0x15(%r15), %eax
    6d56:      	addq	0x68(%rsp), %rax
    6d5b:      	leaq	0xc(%rsp), %rdi
    6d60:      	movl	$0x4, %ecx
    6d65:      	movl	$0x70, %r8d
    6d6b:      	movzbl	0x15(%r15), %edx
    6d70:      	addq	0x68(%rsp), %rdx
    6d75:      	movl	$0x4, %esi
    6d7a:      	callq	*%r8
    6d7d:      	testq	%rax, %rax
    6d80:      	je	0x6e2f <perf_unwind_php+0x6e2f>
    6d86:      	movq	(%rip), %rax            # 0x6d8d <perf_unwind_php+0x6d8d>
    6d8d:      	movl	$0x27, 0x4(%rsp)
    6d95:      	cmpl	$0x0, (%rax)
    6d98:      	je	0x6fd0 <perf_unwind_php+0x6fd0>
    6d9e:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    6da8:      	movq	%rax, 0x40(%rsp)
    6dad:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    6db7:      	movq	%rax, 0x38(%rsp)
    6dbc:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    6dc6:      	movq	%rax, 0x30(%rsp)
    6dcb:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    6dd5:      	movq	%rax, 0x28(%rsp)
    6dda:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    6de4:      	movq	%rax, 0x20(%rsp)
    6de9:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    6df3:      	movq	%rax, 0x18(%rsp)
    6df8:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6e02:      	movq	%rax, 0x10(%rsp)
    6e07:      	movb	$0x0, 0x48(%rsp)
    6e0c:      	leaq	0x10(%rsp), %rdi
    6e11:      	movl	$0x39, %eax
    6e16:      	movl	$0x6, %ecx
    6e1b:      	movzbl	0x15(%r15), %edx
    6e20:      	addq	0x68(%rsp), %rdx
    6e25:      	movl	$0x39, %esi
    6e2a:      	jmp	0x6ef8 <perf_unwind_php+0x6ef8>
    6e2f:      	movzbl	0x13(%r15), %eax
    6e34:      	addq	%r13, %rax
    6e37:      	leaq	0x54(%rsp), %rdi
    6e3c:      	movl	$0x4, %ecx
    6e41:      	movl	$0x70, %r8d
    6e47:      	movzbl	0x13(%r15), %edx
    6e4c:      	addq	%r13, %rdx
    6e4f:      	movl	$0x4, %esi
    6e54:      	callq	*%r8
    6e57:      	testq	%rax, %rax
    6e5a:      	je	0x6f01 <perf_unwind_php+0x6f01>
    6e60:      	movq	(%rip), %rax            # 0x6e67 <perf_unwind_php+0x6e67>
    6e67:      	movl	$0x25, 0x4(%rsp)
    6e6f:      	cmpl	$0x0, (%rax)
    6e72:      	je	0x6fd0 <perf_unwind_php+0x6fd0>
    6e78:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    6e82:      	movq	%rax, 0x3d(%rsp)
    6e87:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    6e91:      	movq	%rax, 0x38(%rsp)
    6e96:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    6ea0:      	movq	%rax, 0x30(%rsp)
    6ea5:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    6eaf:      	movq	%rax, 0x28(%rsp)
    6eb4:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    6ebe:      	movq	%rax, 0x20(%rsp)
    6ec3:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    6ecd:      	movq	%rax, 0x18(%rsp)
    6ed2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6edc:      	movq	%rax, 0x10(%rsp)
    6ee1:      	leaq	0x10(%rsp), %rdi
    6ee6:      	movl	$0x35, %eax
    6eeb:      	movl	$0x6, %ecx
    6ef0:      	movl	$0x35, %esi
    6ef5:      	movq	%r13, %rdx
    6ef8:      	xorl	%eax, %eax
    6efa:      	callq	*%rcx
    6efc:      	jmp	0x6fd0 <perf_unwind_php+0x6fd0>
    6f01:      	movl	0xc(%rsp), %eax
    6f05:      	movl	%eax, 0x4(%rsp)
    6f09:      	movl	0x54(%rsp), %r13d
    6f0e:      	movq	(%rip), %rax            # 0x6f15 <perf_unwind_php+0x6f15>
    6f15:      	cmpl	$0x0, (%rax)
    6f18:      	je	0x6f6a <perf_unwind_php+0x6f6a>
    6f1a:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    6f24:      	movq	%rax, 0x1e(%rsp)
    6f29:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    6f33:      	movq	%rax, 0x18(%rsp)
    6f38:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    6f42:      	movq	%rax, 0x10(%rsp)
    6f47:      	leaq	0x10(%rsp), %rdi
    6f4c:      	movl	$0x16, %eax
    6f51:      	movl	$0x6, %r8d
    6f57:      	movq	0x58(%rsp), %rdx
    6f5c:      	movl	0xc(%rsp), %ecx
    6f60:      	movl	$0x16, %esi
    6f65:      	xorl	%eax, %eax
    6f67:      	callq	*%r8
    6f6a:      	movl	0x2c0(%rbp), %eax
    6f70:      	cmpq	$0x7e, %rax
    6f74:      	ja	0xb47 <perf_unwind_php+0xb47>
    6f7a:      	movl	0x4(%rsp), %ecx
    6f7e:      	shlq	$0x20, %r13
    6f82:      	orq	%r13, %rcx
    6f85:      	movq	0x58(%rsp), %rdx
    6f8a:      	leal	0x1(%rax), %esi
    6f8d:      	movl	%esi, 0x2c0(%rbp)
    6f93:      	leaq	(%rax,%rax,2), %rax
    6f97:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    6f9f:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    6fa7:      	movl	0x7c(%rsp), %ecx
    6fab:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    6fb2:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    6fbd:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    6fc8:      	movl	$0x23, 0x4(%rsp)
    6fd0:      	movl	0x4(%rsp), %eax
    6fd4:      	movl	%eax, 0x58(%rsp)
    6fd8:      	movq	(%rip), %rdi            # 0x6fdf <perf_unwind_php+0x6fdf>
    6fdf:      	leaq	0x58(%rsp), %rsi
    6fe4:      	movl	$0x1, %eax
    6fe9:      	callq	*%rax
    6feb:      	testq	%rax, %rax
    6fee:      	je	0x6ff8 <perf_unwind_php+0x6ff8>
    6ff0:      	incq	(%rax)
    6ff3:      	jmp	0x707a <perf_unwind_php+0x707a>
    6ff8:      	movq	(%rip), %rax            # 0x6fff <perf_unwind_php+0x6fff>
    6fff:      	cmpl	$0x0, (%rax)
    7002:      	je	0x707a <perf_unwind_php+0x707a>
    7004:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    700e:      	movq	%rax, 0x36(%rsp)
    7013:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    701d:      	movq	%rax, 0x30(%rsp)
    7022:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    702c:      	movq	%rax, 0x28(%rsp)
    7031:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    703b:      	movq	%rax, 0x20(%rsp)
    7040:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    704a:      	movq	%rax, 0x18(%rsp)
    704f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7059:      	movq	%rax, 0x10(%rsp)
    705e:      	leaq	0x10(%rsp), %rdi
    7063:      	movl	$0x2e, %eax
    7068:      	movl	$0x6, %ecx
    706d:      	movl	0x58(%rsp), %edx
    7071:      	movl	$0x2e, %esi
    7076:      	xorl	%eax, %eax
    7078:      	callq	*%rcx
    707a:      	cmpl	$0x23, 0x4(%rsp)
    707f:      	jne	0x85e3 <perf_unwind_php+0x85e3>
    7085:      	movzbl	0x12(%r15), %eax
    708a:      	addq	0x70(%rsp), %rax
    708f:      	leaq	0x70(%rsp), %rdi
    7094:      	movl	$0x8, %ecx
    7099:      	movl	$0x70, %r8d
    709f:      	movzbl	0x12(%r15), %edx
    70a4:      	addq	0x70(%rsp), %rdx
    70a9:      	movl	$0x8, %esi
    70ae:      	callq	*%r8
    70b1:      	testq	%rax, %rax
    70b4:      	jne	0x317 <perf_unwind_php+0x317>
    70ba:      	movq	0x70(%rsp), %r13
    70bf:      	testq	%r13, %r13
    70c2:      	je	0x83ba <perf_unwind_php+0x83ba>
    70c8:      	testb	$0x2, 0x56(%rsp)
    70cd:      	jne	0x83ba <perf_unwind_php+0x83ba>
    70d3:      	movzbl	0x10(%r15), %eax
    70d8:      	addq	%r13, %rax
    70db:      	leaq	0x58(%rsp), %rdi
    70e0:      	movl	$0x8, %ecx
    70e5:      	movl	$0x70, %r8d
    70eb:      	movzbl	0x10(%r15), %edx
    70f0:      	addq	%r13, %rdx
    70f3:      	movl	$0x8, %esi
    70f8:      	callq	*%r8
    70fb:      	testq	%rax, %rax
    70fe:      	je	0x719f <perf_unwind_php+0x719f>
    7104:      	movq	(%rip), %rax            # 0x710b <perf_unwind_php+0x710b>
    710b:      	movl	$0x25, 0x4(%rsp)
    7113:      	cmpl	$0x0, (%rax)
    7116:      	je	0x761d <perf_unwind_php+0x761d>
    711c:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    7126:      	movq	%rax, 0x38(%rsp)
    712b:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    7135:      	movq	%rax, 0x30(%rsp)
    713a:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    7144:      	movq	%rax, 0x28(%rsp)
    7149:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    7153:      	movq	%rax, 0x20(%rsp)
    7158:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    7162:      	movq	%rax, 0x18(%rsp)
    7167:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7171:      	movq	%rax, 0x10(%rsp)
    7176:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    717e:      	leaq	0x10(%rsp), %rdi
    7183:      	movl	$0x33, %eax
    7188:      	movl	$0x6, %ecx
    718d:      	movzbl	0x10(%r15), %eax
    7192:      	addq	%rax, %r13
    7195:      	movl	$0x33, %esi
    719a:      	jmp	0x7542 <perf_unwind_php+0x7542>
    719f:      	movq	0x58(%rsp), %rax
    71a4:      	testq	%rax, %rax
    71a7:      	je	0x7275 <perf_unwind_php+0x7275>
    71ad:      	movzbl	0x14(%r15), %ecx
    71b2:      	addq	%rcx, %rax
    71b5:      	leaq	0xb(%rsp), %rdi
    71ba:      	movl	$0x1, %ecx
    71bf:      	movl	$0x70, %r8d
    71c5:      	movzbl	0x14(%r15), %edx
    71ca:      	addq	0x58(%rsp), %rdx
    71cf:      	movl	$0x1, %esi
    71d4:      	callq	*%r8
    71d7:      	testq	%rax, %rax
    71da:      	je	0x72b7 <perf_unwind_php+0x72b7>
    71e0:      	movq	(%rip), %rax            # 0x71e7 <perf_unwind_php+0x71e7>
    71e7:      	cmpl	$0x0, (%rax)
    71ea:      	je	0x7268 <perf_unwind_php+0x7268>
    71ec:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    71f6:      	movq	%rax, 0x38(%rsp)
    71fb:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    7205:      	movq	%rax, 0x30(%rsp)
    720a:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    7214:      	movq	%rax, 0x28(%rsp)
    7219:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    7223:      	movq	%rax, 0x20(%rsp)
    7228:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    7232:      	movq	%rax, 0x18(%rsp)
    7237:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7241:      	movq	%rax, 0x10(%rsp)
    7246:      	movb	$0x0, 0x40(%rsp)
    724b:      	leaq	0x10(%rsp), %rdi
    7250:      	movl	$0x31, %eax
    7255:      	movl	$0x6, %ecx
    725a:      	movq	0x58(%rsp), %rdx
    725f:      	movl	$0x31, %esi
    7264:      	xorl	%eax, %eax
    7266:      	callq	*%rcx
    7268:      	movl	$0x26, 0x4(%rsp)
    7270:      	jmp	0x761d <perf_unwind_php+0x761d>
    7275:      	movl	0x2c0(%rbp), %eax
    727b:      	cmpq	$0x7e, %rax
    727f:      	ja	0x40e <perf_unwind_php+0x40e>
    7285:      	leal	0x1(%rax), %ecx
    7288:      	movl	%ecx, 0x2c0(%rbp)
    728e:      	leaq	(%rax,%rax,2), %rax
    7292:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    729e:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    72aa:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    72b2:      	jmp	0x75ff <perf_unwind_php+0x75ff>
    72b7:      	movl	$0x0, 0xc(%rsp)
    72bf:      	movzbl	0xb(%rsp), %eax
    72c4:      	cmpl	$0x4, %eax
    72c7:      	je	0x72da <perf_unwind_php+0x72da>
    72c9:      	movl	$0x0, 0x4(%rsp)
    72d1:      	cmpl	$0x2, %eax
    72d4:      	jne	0x7556 <perf_unwind_php+0x7556>
    72da:      	movzbl	0x11(%r15), %eax
    72df:      	addq	%r13, %rax
    72e2:      	leaq	0x68(%rsp), %rdi
    72e7:      	movl	$0x8, %ecx
    72ec:      	movl	$0x70, %r8d
    72f2:      	movzbl	0x11(%r15), %edx
    72f7:      	addq	%r13, %rdx
    72fa:      	movl	$0x8, %esi
    72ff:      	callq	*%r8
    7302:      	testq	%rax, %rax
    7305:      	je	0x739e <perf_unwind_php+0x739e>
    730b:      	movq	(%rip), %rax            # 0x7312 <perf_unwind_php+0x7312>
    7312:      	movl	$0x25, 0x4(%rsp)
    731a:      	cmpl	$0x0, (%rax)
    731d:      	je	0x761d <perf_unwind_php+0x761d>
    7323:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    732d:      	movq	%rax, 0x35(%rsp)
    7332:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    733c:      	movq	%rax, 0x30(%rsp)
    7341:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    734b:      	movq	%rax, 0x28(%rsp)
    7350:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    735a:      	movq	%rax, 0x20(%rsp)
    735f:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    7369:      	movq	%rax, 0x18(%rsp)
    736e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7378:      	movq	%rax, 0x10(%rsp)
    737d:      	leaq	0x10(%rsp), %rdi
    7382:      	movl	$0x2d, %eax
    7387:      	movl	$0x6, %ecx
    738c:      	movzbl	0x11(%r15), %eax
    7391:      	addq	%rax, %r13
    7394:      	movl	$0x2d, %esi
    7399:      	jmp	0x7542 <perf_unwind_php+0x7542>
    739e:      	movzbl	0x15(%r15), %eax
    73a3:      	addq	0x68(%rsp), %rax
    73a8:      	leaq	0xc(%rsp), %rdi
    73ad:      	movl	$0x4, %ecx
    73b2:      	movl	$0x70, %r8d
    73b8:      	movzbl	0x15(%r15), %edx
    73bd:      	addq	0x68(%rsp), %rdx
    73c2:      	movl	$0x4, %esi
    73c7:      	callq	*%r8
    73ca:      	testq	%rax, %rax
    73cd:      	je	0x747c <perf_unwind_php+0x747c>
    73d3:      	movq	(%rip), %rax            # 0x73da <perf_unwind_php+0x73da>
    73da:      	movl	$0x27, 0x4(%rsp)
    73e2:      	cmpl	$0x0, (%rax)
    73e5:      	je	0x761d <perf_unwind_php+0x761d>
    73eb:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    73f5:      	movq	%rax, 0x40(%rsp)
    73fa:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    7404:      	movq	%rax, 0x38(%rsp)
    7409:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    7413:      	movq	%rax, 0x30(%rsp)
    7418:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    7422:      	movq	%rax, 0x28(%rsp)
    7427:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    7431:      	movq	%rax, 0x20(%rsp)
    7436:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    7440:      	movq	%rax, 0x18(%rsp)
    7445:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    744f:      	movq	%rax, 0x10(%rsp)
    7454:      	movb	$0x0, 0x48(%rsp)
    7459:      	leaq	0x10(%rsp), %rdi
    745e:      	movl	$0x39, %eax
    7463:      	movl	$0x6, %ecx
    7468:      	movzbl	0x15(%r15), %edx
    746d:      	addq	0x68(%rsp), %rdx
    7472:      	movl	$0x39, %esi
    7477:      	jmp	0x7545 <perf_unwind_php+0x7545>
    747c:      	movzbl	0x13(%r15), %eax
    7481:      	addq	%r13, %rax
    7484:      	leaq	0x54(%rsp), %rdi
    7489:      	movl	$0x4, %ecx
    748e:      	movl	$0x70, %r8d
    7494:      	movzbl	0x13(%r15), %edx
    7499:      	addq	%r13, %rdx
    749c:      	movl	$0x4, %esi
    74a1:      	callq	*%r8
    74a4:      	testq	%rax, %rax
    74a7:      	je	0x754e <perf_unwind_php+0x754e>
    74ad:      	movq	(%rip), %rax            # 0x74b4 <perf_unwind_php+0x74b4>
    74b4:      	movl	$0x25, 0x4(%rsp)
    74bc:      	cmpl	$0x0, (%rax)
    74bf:      	je	0x761d <perf_unwind_php+0x761d>
    74c5:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    74cf:      	movq	%rax, 0x3d(%rsp)
    74d4:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    74de:      	movq	%rax, 0x38(%rsp)
    74e3:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    74ed:      	movq	%rax, 0x30(%rsp)
    74f2:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    74fc:      	movq	%rax, 0x28(%rsp)
    7501:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    750b:      	movq	%rax, 0x20(%rsp)
    7510:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    751a:      	movq	%rax, 0x18(%rsp)
    751f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7529:      	movq	%rax, 0x10(%rsp)
    752e:      	leaq	0x10(%rsp), %rdi
    7533:      	movl	$0x35, %eax
    7538:      	movl	$0x6, %ecx
    753d:      	movl	$0x35, %esi
    7542:      	movq	%r13, %rdx
    7545:      	xorl	%eax, %eax
    7547:      	callq	*%rcx
    7549:      	jmp	0x761d <perf_unwind_php+0x761d>
    754e:      	movl	0xc(%rsp), %eax
    7552:      	movl	%eax, 0x4(%rsp)
    7556:      	movl	0x54(%rsp), %r13d
    755b:      	movq	(%rip), %rax            # 0x7562 <perf_unwind_php+0x7562>
    7562:      	cmpl	$0x0, (%rax)
    7565:      	je	0x75b7 <perf_unwind_php+0x75b7>
    7567:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    7571:      	movq	%rax, 0x1e(%rsp)
    7576:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    7580:      	movq	%rax, 0x18(%rsp)
    7585:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    758f:      	movq	%rax, 0x10(%rsp)
    7594:      	leaq	0x10(%rsp), %rdi
    7599:      	movl	$0x16, %eax
    759e:      	movl	$0x6, %r8d
    75a4:      	movq	0x58(%rsp), %rdx
    75a9:      	movl	0xc(%rsp), %ecx
    75ad:      	movl	$0x16, %esi
    75b2:      	xorl	%eax, %eax
    75b4:      	callq	*%r8
    75b7:      	movl	0x2c0(%rbp), %eax
    75bd:      	cmpq	$0x7e, %rax
    75c1:      	ja	0xb47 <perf_unwind_php+0xb47>
    75c7:      	movl	0x4(%rsp), %ecx
    75cb:      	shlq	$0x20, %r13
    75cf:      	orq	%r13, %rcx
    75d2:      	movq	0x58(%rsp), %rdx
    75d7:      	leal	0x1(%rax), %esi
    75da:      	movl	%esi, 0x2c0(%rbp)
    75e0:      	leaq	(%rax,%rax,2), %rax
    75e4:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    75ec:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    75f4:      	movl	0x7c(%rsp), %ecx
    75f8:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    75ff:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    760a:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    7615:      	movl	$0x23, 0x4(%rsp)
    761d:      	movl	0x4(%rsp), %eax
    7621:      	movl	%eax, 0x58(%rsp)
    7625:      	movq	(%rip), %rdi            # 0x762c <perf_unwind_php+0x762c>
    762c:      	leaq	0x58(%rsp), %rsi
    7631:      	movl	$0x1, %eax
    7636:      	callq	*%rax
    7638:      	testq	%rax, %rax
    763b:      	je	0x7645 <perf_unwind_php+0x7645>
    763d:      	incq	(%rax)
    7640:      	jmp	0x76c7 <perf_unwind_php+0x76c7>
    7645:      	movq	(%rip), %rax            # 0x764c <perf_unwind_php+0x764c>
    764c:      	cmpl	$0x0, (%rax)
    764f:      	je	0x76c7 <perf_unwind_php+0x76c7>
    7651:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    765b:      	movq	%rax, 0x36(%rsp)
    7660:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    766a:      	movq	%rax, 0x30(%rsp)
    766f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7679:      	movq	%rax, 0x28(%rsp)
    767e:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7688:      	movq	%rax, 0x20(%rsp)
    768d:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    7697:      	movq	%rax, 0x18(%rsp)
    769c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    76a6:      	movq	%rax, 0x10(%rsp)
    76ab:      	leaq	0x10(%rsp), %rdi
    76b0:      	movl	$0x2e, %eax
    76b5:      	movl	$0x6, %ecx
    76ba:      	movl	0x58(%rsp), %edx
    76be:      	movl	$0x2e, %esi
    76c3:      	xorl	%eax, %eax
    76c5:      	callq	*%rcx
    76c7:      	cmpl	$0x23, 0x4(%rsp)
    76cc:      	jne	0x85e3 <perf_unwind_php+0x85e3>
    76d2:      	movzbl	0x12(%r15), %eax
    76d7:      	addq	0x70(%rsp), %rax
    76dc:      	leaq	0x70(%rsp), %rdi
    76e1:      	movl	$0x8, %ecx
    76e6:      	movl	$0x70, %r8d
    76ec:      	movzbl	0x12(%r15), %edx
    76f1:      	addq	0x70(%rsp), %rdx
    76f6:      	movl	$0x8, %esi
    76fb:      	callq	*%r8
    76fe:      	testq	%rax, %rax
    7701:      	jne	0x317 <perf_unwind_php+0x317>
    7707:      	movq	0x70(%rsp), %r13
    770c:      	testq	%r13, %r13
    770f:      	je	0x83ba <perf_unwind_php+0x83ba>
    7715:      	testb	$0x2, 0x56(%rsp)
    771a:      	jne	0x83ba <perf_unwind_php+0x83ba>
    7720:      	movzbl	0x10(%r15), %eax
    7725:      	addq	%r13, %rax
    7728:      	leaq	0x58(%rsp), %rdi
    772d:      	movl	$0x8, %ecx
    7732:      	movl	$0x70, %r8d
    7738:      	movzbl	0x10(%r15), %edx
    773d:      	addq	%r13, %rdx
    7740:      	movl	$0x8, %esi
    7745:      	callq	*%r8
    7748:      	testq	%rax, %rax
    774b:      	je	0x77ec <perf_unwind_php+0x77ec>
    7751:      	movq	(%rip), %rax            # 0x7758 <perf_unwind_php+0x7758>
    7758:      	movl	$0x25, 0x4(%rsp)
    7760:      	cmpl	$0x0, (%rax)
    7763:      	je	0x7c6a <perf_unwind_php+0x7c6a>
    7769:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    7773:      	movq	%rax, 0x38(%rsp)
    7778:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    7782:      	movq	%rax, 0x30(%rsp)
    7787:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    7791:      	movq	%rax, 0x28(%rsp)
    7796:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    77a0:      	movq	%rax, 0x20(%rsp)
    77a5:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    77af:      	movq	%rax, 0x18(%rsp)
    77b4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    77be:      	movq	%rax, 0x10(%rsp)
    77c3:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    77cb:      	leaq	0x10(%rsp), %rdi
    77d0:      	movl	$0x33, %eax
    77d5:      	movl	$0x6, %ecx
    77da:      	movzbl	0x10(%r15), %eax
    77df:      	addq	%rax, %r13
    77e2:      	movl	$0x33, %esi
    77e7:      	jmp	0x7b8f <perf_unwind_php+0x7b8f>
    77ec:      	movq	0x58(%rsp), %rax
    77f1:      	testq	%rax, %rax
    77f4:      	je	0x78c2 <perf_unwind_php+0x78c2>
    77fa:      	movzbl	0x14(%r15), %ecx
    77ff:      	addq	%rcx, %rax
    7802:      	leaq	0xb(%rsp), %rdi
    7807:      	movl	$0x1, %ecx
    780c:      	movl	$0x70, %r8d
    7812:      	movzbl	0x14(%r15), %edx
    7817:      	addq	0x58(%rsp), %rdx
    781c:      	movl	$0x1, %esi
    7821:      	callq	*%r8
    7824:      	testq	%rax, %rax
    7827:      	je	0x7904 <perf_unwind_php+0x7904>
    782d:      	movq	(%rip), %rax            # 0x7834 <perf_unwind_php+0x7834>
    7834:      	cmpl	$0x0, (%rax)
    7837:      	je	0x78b5 <perf_unwind_php+0x78b5>
    7839:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    7843:      	movq	%rax, 0x38(%rsp)
    7848:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    7852:      	movq	%rax, 0x30(%rsp)
    7857:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    7861:      	movq	%rax, 0x28(%rsp)
    7866:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    7870:      	movq	%rax, 0x20(%rsp)
    7875:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    787f:      	movq	%rax, 0x18(%rsp)
    7884:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    788e:      	movq	%rax, 0x10(%rsp)
    7893:      	movb	$0x0, 0x40(%rsp)
    7898:      	leaq	0x10(%rsp), %rdi
    789d:      	movl	$0x31, %eax
    78a2:      	movl	$0x6, %ecx
    78a7:      	movq	0x58(%rsp), %rdx
    78ac:      	movl	$0x31, %esi
    78b1:      	xorl	%eax, %eax
    78b3:      	callq	*%rcx
    78b5:      	movl	$0x26, 0x4(%rsp)
    78bd:      	jmp	0x7c6a <perf_unwind_php+0x7c6a>
    78c2:      	movl	0x2c0(%rbp), %eax
    78c8:      	cmpq	$0x7e, %rax
    78cc:      	ja	0x40e <perf_unwind_php+0x40e>
    78d2:      	leal	0x1(%rax), %ecx
    78d5:      	movl	%ecx, 0x2c0(%rbp)
    78db:      	leaq	(%rax,%rax,2), %rax
    78df:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    78eb:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    78f7:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    78ff:      	jmp	0x7c4c <perf_unwind_php+0x7c4c>
    7904:      	movl	$0x0, 0xc(%rsp)
    790c:      	movzbl	0xb(%rsp), %eax
    7911:      	cmpl	$0x4, %eax
    7914:      	je	0x7927 <perf_unwind_php+0x7927>
    7916:      	movl	$0x0, 0x4(%rsp)
    791e:      	cmpl	$0x2, %eax
    7921:      	jne	0x7ba3 <perf_unwind_php+0x7ba3>
    7927:      	movzbl	0x11(%r15), %eax
    792c:      	addq	%r13, %rax
    792f:      	leaq	0x68(%rsp), %rdi
    7934:      	movl	$0x8, %ecx
    7939:      	movl	$0x70, %r8d
    793f:      	movzbl	0x11(%r15), %edx
    7944:      	addq	%r13, %rdx
    7947:      	movl	$0x8, %esi
    794c:      	callq	*%r8
    794f:      	testq	%rax, %rax
    7952:      	je	0x79eb <perf_unwind_php+0x79eb>
    7958:      	movq	(%rip), %rax            # 0x795f <perf_unwind_php+0x795f>
    795f:      	movl	$0x25, 0x4(%rsp)
    7967:      	cmpl	$0x0, (%rax)
    796a:      	je	0x7c6a <perf_unwind_php+0x7c6a>
    7970:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    797a:      	movq	%rax, 0x35(%rsp)
    797f:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    7989:      	movq	%rax, 0x30(%rsp)
    798e:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    7998:      	movq	%rax, 0x28(%rsp)
    799d:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    79a7:      	movq	%rax, 0x20(%rsp)
    79ac:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    79b6:      	movq	%rax, 0x18(%rsp)
    79bb:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    79c5:      	movq	%rax, 0x10(%rsp)
    79ca:      	leaq	0x10(%rsp), %rdi
    79cf:      	movl	$0x2d, %eax
    79d4:      	movl	$0x6, %ecx
    79d9:      	movzbl	0x11(%r15), %eax
    79de:      	addq	%rax, %r13
    79e1:      	movl	$0x2d, %esi
    79e6:      	jmp	0x7b8f <perf_unwind_php+0x7b8f>
    79eb:      	movzbl	0x15(%r15), %eax
    79f0:      	addq	0x68(%rsp), %rax
    79f5:      	leaq	0xc(%rsp), %rdi
    79fa:      	movl	$0x4, %ecx
    79ff:      	movl	$0x70, %r8d
    7a05:      	movzbl	0x15(%r15), %edx
    7a0a:      	addq	0x68(%rsp), %rdx
    7a0f:      	movl	$0x4, %esi
    7a14:      	callq	*%r8
    7a17:      	testq	%rax, %rax
    7a1a:      	je	0x7ac9 <perf_unwind_php+0x7ac9>
    7a20:      	movq	(%rip), %rax            # 0x7a27 <perf_unwind_php+0x7a27>
    7a27:      	movl	$0x27, 0x4(%rsp)
    7a2f:      	cmpl	$0x0, (%rax)
    7a32:      	je	0x7c6a <perf_unwind_php+0x7c6a>
    7a38:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    7a42:      	movq	%rax, 0x40(%rsp)
    7a47:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    7a51:      	movq	%rax, 0x38(%rsp)
    7a56:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    7a60:      	movq	%rax, 0x30(%rsp)
    7a65:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    7a6f:      	movq	%rax, 0x28(%rsp)
    7a74:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    7a7e:      	movq	%rax, 0x20(%rsp)
    7a83:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    7a8d:      	movq	%rax, 0x18(%rsp)
    7a92:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7a9c:      	movq	%rax, 0x10(%rsp)
    7aa1:      	movb	$0x0, 0x48(%rsp)
    7aa6:      	leaq	0x10(%rsp), %rdi
    7aab:      	movl	$0x39, %eax
    7ab0:      	movl	$0x6, %ecx
    7ab5:      	movzbl	0x15(%r15), %edx
    7aba:      	addq	0x68(%rsp), %rdx
    7abf:      	movl	$0x39, %esi
    7ac4:      	jmp	0x7b92 <perf_unwind_php+0x7b92>
    7ac9:      	movzbl	0x13(%r15), %eax
    7ace:      	addq	%r13, %rax
    7ad1:      	leaq	0x54(%rsp), %rdi
    7ad6:      	movl	$0x4, %ecx
    7adb:      	movl	$0x70, %r8d
    7ae1:      	movzbl	0x13(%r15), %edx
    7ae6:      	addq	%r13, %rdx
    7ae9:      	movl	$0x4, %esi
    7aee:      	callq	*%r8
    7af1:      	testq	%rax, %rax
    7af4:      	je	0x7b9b <perf_unwind_php+0x7b9b>
    7afa:      	movq	(%rip), %rax            # 0x7b01 <perf_unwind_php+0x7b01>
    7b01:      	movl	$0x25, 0x4(%rsp)
    7b09:      	cmpl	$0x0, (%rax)
    7b0c:      	je	0x7c6a <perf_unwind_php+0x7c6a>
    7b12:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    7b1c:      	movq	%rax, 0x3d(%rsp)
    7b21:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    7b2b:      	movq	%rax, 0x38(%rsp)
    7b30:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    7b3a:      	movq	%rax, 0x30(%rsp)
    7b3f:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    7b49:      	movq	%rax, 0x28(%rsp)
    7b4e:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    7b58:      	movq	%rax, 0x20(%rsp)
    7b5d:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    7b67:      	movq	%rax, 0x18(%rsp)
    7b6c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7b76:      	movq	%rax, 0x10(%rsp)
    7b7b:      	leaq	0x10(%rsp), %rdi
    7b80:      	movl	$0x35, %eax
    7b85:      	movl	$0x6, %ecx
    7b8a:      	movl	$0x35, %esi
    7b8f:      	movq	%r13, %rdx
    7b92:      	xorl	%eax, %eax
    7b94:      	callq	*%rcx
    7b96:      	jmp	0x7c6a <perf_unwind_php+0x7c6a>
    7b9b:      	movl	0xc(%rsp), %eax
    7b9f:      	movl	%eax, 0x4(%rsp)
    7ba3:      	movl	0x54(%rsp), %r13d
    7ba8:      	movq	(%rip), %rax            # 0x7baf <perf_unwind_php+0x7baf>
    7baf:      	cmpl	$0x0, (%rax)
    7bb2:      	je	0x7c04 <perf_unwind_php+0x7c04>
    7bb4:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    7bbe:      	movq	%rax, 0x1e(%rsp)
    7bc3:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    7bcd:      	movq	%rax, 0x18(%rsp)
    7bd2:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    7bdc:      	movq	%rax, 0x10(%rsp)
    7be1:      	leaq	0x10(%rsp), %rdi
    7be6:      	movl	$0x16, %eax
    7beb:      	movl	$0x6, %r8d
    7bf1:      	movq	0x58(%rsp), %rdx
    7bf6:      	movl	0xc(%rsp), %ecx
    7bfa:      	movl	$0x16, %esi
    7bff:      	xorl	%eax, %eax
    7c01:      	callq	*%r8
    7c04:      	movl	0x2c0(%rbp), %eax
    7c0a:      	cmpq	$0x7e, %rax
    7c0e:      	ja	0xb47 <perf_unwind_php+0xb47>
    7c14:      	movl	0x4(%rsp), %ecx
    7c18:      	shlq	$0x20, %r13
    7c1c:      	orq	%r13, %rcx
    7c1f:      	movq	0x58(%rsp), %rdx
    7c24:      	leal	0x1(%rax), %esi
    7c27:      	movl	%esi, 0x2c0(%rbp)
    7c2d:      	leaq	(%rax,%rax,2), %rax
    7c31:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    7c39:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    7c41:      	movl	0x7c(%rsp), %ecx
    7c45:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    7c4c:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    7c57:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    7c62:      	movl	$0x23, 0x4(%rsp)
    7c6a:      	movl	0x4(%rsp), %eax
    7c6e:      	movl	%eax, 0x58(%rsp)
    7c72:      	movq	(%rip), %rdi            # 0x7c79 <perf_unwind_php+0x7c79>
    7c79:      	leaq	0x58(%rsp), %rsi
    7c7e:      	movl	$0x1, %eax
    7c83:      	callq	*%rax
    7c85:      	testq	%rax, %rax
    7c88:      	je	0x7c92 <perf_unwind_php+0x7c92>
    7c8a:      	incq	(%rax)
    7c8d:      	jmp	0x7d14 <perf_unwind_php+0x7d14>
    7c92:      	movq	(%rip), %rax            # 0x7c99 <perf_unwind_php+0x7c99>
    7c99:      	cmpl	$0x0, (%rax)
    7c9c:      	je	0x7d14 <perf_unwind_php+0x7d14>
    7c9e:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    7ca8:      	movq	%rax, 0x36(%rsp)
    7cad:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7cb7:      	movq	%rax, 0x30(%rsp)
    7cbc:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7cc6:      	movq	%rax, 0x28(%rsp)
    7ccb:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7cd5:      	movq	%rax, 0x20(%rsp)
    7cda:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    7ce4:      	movq	%rax, 0x18(%rsp)
    7ce9:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7cf3:      	movq	%rax, 0x10(%rsp)
    7cf8:      	leaq	0x10(%rsp), %rdi
    7cfd:      	movl	$0x2e, %eax
    7d02:      	movl	$0x6, %ecx
    7d07:      	movl	0x58(%rsp), %edx
    7d0b:      	movl	$0x2e, %esi
    7d10:      	xorl	%eax, %eax
    7d12:      	callq	*%rcx
    7d14:      	cmpl	$0x23, 0x4(%rsp)
    7d19:      	jne	0x85e3 <perf_unwind_php+0x85e3>
    7d1f:      	movzbl	0x12(%r15), %eax
    7d24:      	addq	0x70(%rsp), %rax
    7d29:      	leaq	0x70(%rsp), %rdi
    7d2e:      	movl	$0x8, %ecx
    7d33:      	movl	$0x70, %r8d
    7d39:      	movzbl	0x12(%r15), %edx
    7d3e:      	addq	0x70(%rsp), %rdx
    7d43:      	movl	$0x8, %esi
    7d48:      	callq	*%r8
    7d4b:      	testq	%rax, %rax
    7d4e:      	jne	0x317 <perf_unwind_php+0x317>
    7d54:      	movq	0x70(%rsp), %r13
    7d59:      	testq	%r13, %r13
    7d5c:      	je	0x83ba <perf_unwind_php+0x83ba>
    7d62:      	testb	$0x2, 0x56(%rsp)
    7d67:      	jne	0x83ba <perf_unwind_php+0x83ba>
    7d6d:      	movzbl	0x10(%r15), %eax
    7d72:      	addq	%r13, %rax
    7d75:      	leaq	0x58(%rsp), %rdi
    7d7a:      	movl	$0x8, %ecx
    7d7f:      	movl	$0x70, %r8d
    7d85:      	movzbl	0x10(%r15), %edx
    7d8a:      	addq	%r13, %rdx
    7d8d:      	movl	$0x8, %esi
    7d92:      	callq	*%r8
    7d95:      	testq	%rax, %rax
    7d98:      	je	0x7e39 <perf_unwind_php+0x7e39>
    7d9e:      	movq	(%rip), %rax            # 0x7da5 <perf_unwind_php+0x7da5>
    7da5:      	movl	$0x25, 0x7c(%rsp)
    7dad:      	cmpl	$0x0, (%rax)
    7db0:      	je	0x82b7 <perf_unwind_php+0x82b7>
    7db6:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    7dc0:      	movq	%rax, 0x38(%rsp)
    7dc5:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    7dcf:      	movq	%rax, 0x30(%rsp)
    7dd4:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    7dde:      	movq	%rax, 0x28(%rsp)
    7de3:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    7ded:      	movq	%rax, 0x20(%rsp)
    7df2:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    7dfc:      	movq	%rax, 0x18(%rsp)
    7e01:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7e0b:      	movq	%rax, 0x10(%rsp)
    7e10:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    7e18:      	leaq	0x10(%rsp), %rdi
    7e1d:      	movl	$0x33, %eax
    7e22:      	movl	$0x6, %ecx
    7e27:      	movzbl	0x10(%r15), %eax
    7e2c:      	addq	%rax, %r13
    7e2f:      	movl	$0x33, %esi
    7e34:      	jmp	0x81dc <perf_unwind_php+0x81dc>
    7e39:      	movq	0x58(%rsp), %rax
    7e3e:      	testq	%rax, %rax
    7e41:      	je	0x7f0f <perf_unwind_php+0x7f0f>
    7e47:      	movzbl	0x14(%r15), %ecx
    7e4c:      	addq	%rcx, %rax
    7e4f:      	leaq	0xb(%rsp), %rdi
    7e54:      	movl	$0x1, %ecx
    7e59:      	movl	$0x70, %r8d
    7e5f:      	movzbl	0x14(%r15), %edx
    7e64:      	addq	0x58(%rsp), %rdx
    7e69:      	movl	$0x1, %esi
    7e6e:      	callq	*%r8
    7e71:      	testq	%rax, %rax
    7e74:      	je	0x7f51 <perf_unwind_php+0x7f51>
    7e7a:      	movq	(%rip), %rax            # 0x7e81 <perf_unwind_php+0x7e81>
    7e81:      	cmpl	$0x0, (%rax)
    7e84:      	je	0x7f02 <perf_unwind_php+0x7f02>
    7e86:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    7e90:      	movq	%rax, 0x38(%rsp)
    7e95:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    7e9f:      	movq	%rax, 0x30(%rsp)
    7ea4:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    7eae:      	movq	%rax, 0x28(%rsp)
    7eb3:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    7ebd:      	movq	%rax, 0x20(%rsp)
    7ec2:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    7ecc:      	movq	%rax, 0x18(%rsp)
    7ed1:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7edb:      	movq	%rax, 0x10(%rsp)
    7ee0:      	movb	$0x0, 0x40(%rsp)
    7ee5:      	leaq	0x10(%rsp), %rdi
    7eea:      	movl	$0x31, %eax
    7eef:      	movl	$0x6, %ecx
    7ef4:      	movq	0x58(%rsp), %rdx
    7ef9:      	movl	$0x31, %esi
    7efe:      	xorl	%eax, %eax
    7f00:      	callq	*%rcx
    7f02:      	movl	$0x26, 0x7c(%rsp)
    7f0a:      	jmp	0x82b7 <perf_unwind_php+0x82b7>
    7f0f:      	movl	0x2c0(%rbp), %eax
    7f15:      	cmpq	$0x7e, %rax
    7f19:      	ja	0x40e <perf_unwind_php+0x40e>
    7f1f:      	leal	0x1(%rax), %ecx
    7f22:      	movl	%ecx, 0x2c0(%rbp)
    7f28:      	leaq	(%rax,%rax,2), %rax
    7f2c:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    7f38:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    7f44:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    7f4c:      	jmp	0x8299 <perf_unwind_php+0x8299>
    7f51:      	movl	$0x0, 0xc(%rsp)
    7f59:      	movzbl	0xb(%rsp), %eax
    7f5e:      	cmpl	$0x4, %eax
    7f61:      	je	0x7f74 <perf_unwind_php+0x7f74>
    7f63:      	movl	$0x0, 0x4(%rsp)
    7f6b:      	cmpl	$0x2, %eax
    7f6e:      	jne	0x81f0 <perf_unwind_php+0x81f0>
    7f74:      	movzbl	0x11(%r15), %eax
    7f79:      	addq	%r13, %rax
    7f7c:      	leaq	0x68(%rsp), %rdi
    7f81:      	movl	$0x8, %ecx
    7f86:      	movl	$0x70, %r8d
    7f8c:      	movzbl	0x11(%r15), %edx
    7f91:      	addq	%r13, %rdx
    7f94:      	movl	$0x8, %esi
    7f99:      	callq	*%r8
    7f9c:      	testq	%rax, %rax
    7f9f:      	je	0x8038 <perf_unwind_php+0x8038>
    7fa5:      	movq	(%rip), %rax            # 0x7fac <perf_unwind_php+0x7fac>
    7fac:      	movl	$0x25, 0x7c(%rsp)
    7fb4:      	cmpl	$0x0, (%rax)
    7fb7:      	je	0x82b7 <perf_unwind_php+0x82b7>
    7fbd:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    7fc7:      	movq	%rax, 0x35(%rsp)
    7fcc:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    7fd6:      	movq	%rax, 0x30(%rsp)
    7fdb:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    7fe5:      	movq	%rax, 0x28(%rsp)
    7fea:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    7ff4:      	movq	%rax, 0x20(%rsp)
    7ff9:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    8003:      	movq	%rax, 0x18(%rsp)
    8008:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    8012:      	movq	%rax, 0x10(%rsp)
    8017:      	leaq	0x10(%rsp), %rdi
    801c:      	movl	$0x2d, %eax
    8021:      	movl	$0x6, %ecx
    8026:      	movzbl	0x11(%r15), %eax
    802b:      	addq	%rax, %r13
    802e:      	movl	$0x2d, %esi
    8033:      	jmp	0x81dc <perf_unwind_php+0x81dc>
    8038:      	movzbl	0x15(%r15), %eax
    803d:      	addq	0x68(%rsp), %rax
    8042:      	leaq	0xc(%rsp), %rdi
    8047:      	movl	$0x4, %ecx
    804c:      	movl	$0x70, %r8d
    8052:      	movzbl	0x15(%r15), %edx
    8057:      	addq	0x68(%rsp), %rdx
    805c:      	movl	$0x4, %esi
    8061:      	callq	*%r8
    8064:      	testq	%rax, %rax
    8067:      	je	0x8116 <perf_unwind_php+0x8116>
    806d:      	movq	(%rip), %rax            # 0x8074 <perf_unwind_php+0x8074>
    8074:      	movl	$0x27, 0x7c(%rsp)
    807c:      	cmpl	$0x0, (%rax)
    807f:      	je	0x82b7 <perf_unwind_php+0x82b7>
    8085:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    808f:      	movq	%rax, 0x40(%rsp)
    8094:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    809e:      	movq	%rax, 0x38(%rsp)
    80a3:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    80ad:      	movq	%rax, 0x30(%rsp)
    80b2:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    80bc:      	movq	%rax, 0x28(%rsp)
    80c1:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    80cb:      	movq	%rax, 0x20(%rsp)
    80d0:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    80da:      	movq	%rax, 0x18(%rsp)
    80df:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    80e9:      	movq	%rax, 0x10(%rsp)
    80ee:      	movb	$0x0, 0x48(%rsp)
    80f3:      	leaq	0x10(%rsp), %rdi
    80f8:      	movl	$0x39, %eax
    80fd:      	movl	$0x6, %ecx
    8102:      	movzbl	0x15(%r15), %edx
    8107:      	addq	0x68(%rsp), %rdx
    810c:      	movl	$0x39, %esi
    8111:      	jmp	0x81df <perf_unwind_php+0x81df>
    8116:      	movzbl	0x13(%r15), %eax
    811b:      	addq	%r13, %rax
    811e:      	leaq	0x54(%rsp), %rdi
    8123:      	movl	$0x4, %ecx
    8128:      	movl	$0x70, %r8d
    812e:      	movzbl	0x13(%r15), %edx
    8133:      	addq	%r13, %rdx
    8136:      	movl	$0x4, %esi
    813b:      	callq	*%r8
    813e:      	testq	%rax, %rax
    8141:      	je	0x81e8 <perf_unwind_php+0x81e8>
    8147:      	movq	(%rip), %rax            # 0x814e <perf_unwind_php+0x814e>
    814e:      	movl	$0x25, 0x7c(%rsp)
    8156:      	cmpl	$0x0, (%rax)
    8159:      	je	0x82b7 <perf_unwind_php+0x82b7>
    815f:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    8169:      	movq	%rax, 0x3d(%rsp)
    816e:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    8178:      	movq	%rax, 0x38(%rsp)
    817d:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    8187:      	movq	%rax, 0x30(%rsp)
    818c:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    8196:      	movq	%rax, 0x28(%rsp)
    819b:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    81a5:      	movq	%rax, 0x20(%rsp)
    81aa:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    81b4:      	movq	%rax, 0x18(%rsp)
    81b9:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    81c3:      	movq	%rax, 0x10(%rsp)
    81c8:      	leaq	0x10(%rsp), %rdi
    81cd:      	movl	$0x35, %eax
    81d2:      	movl	$0x6, %ecx
    81d7:      	movl	$0x35, %esi
    81dc:      	movq	%r13, %rdx
    81df:      	xorl	%eax, %eax
    81e1:      	callq	*%rcx
    81e3:      	jmp	0x82b7 <perf_unwind_php+0x82b7>
    81e8:      	movl	0xc(%rsp), %eax
    81ec:      	movl	%eax, 0x4(%rsp)
    81f0:      	movl	0x54(%rsp), %r13d
    81f5:      	movq	(%rip), %rax            # 0x81fc <perf_unwind_php+0x81fc>
    81fc:      	cmpl	$0x0, (%rax)
    81ff:      	je	0x8251 <perf_unwind_php+0x8251>
    8201:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    820b:      	movq	%rax, 0x1e(%rsp)
    8210:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    821a:      	movq	%rax, 0x18(%rsp)
    821f:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    8229:      	movq	%rax, 0x10(%rsp)
    822e:      	leaq	0x10(%rsp), %rdi
    8233:      	movl	$0x16, %eax
    8238:      	movl	$0x6, %r8d
    823e:      	movq	0x58(%rsp), %rdx
    8243:      	movl	0xc(%rsp), %ecx
    8247:      	movl	$0x16, %esi
    824c:      	xorl	%eax, %eax
    824e:      	callq	*%r8
    8251:      	movl	0x2c0(%rbp), %eax
    8257:      	cmpq	$0x7e, %rax
    825b:      	ja	0xb47 <perf_unwind_php+0xb47>
    8261:      	movl	0x4(%rsp), %ecx
    8265:      	shlq	$0x20, %r13
    8269:      	orq	%r13, %rcx
    826c:      	movq	0x58(%rsp), %rdx
    8271:      	leal	0x1(%rax), %esi
    8274:      	movl	%esi, 0x2c0(%rbp)
    827a:      	leaq	(%rax,%rax,2), %rax
    827e:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    8286:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    828e:      	movl	0x7c(%rsp), %ecx
    8292:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    8299:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    82a4:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    82af:      	movl	$0x23, 0x7c(%rsp)
    82b7:      	movl	0x7c(%rsp), %eax
    82bb:      	movl	%eax, 0x58(%rsp)
    82bf:      	movq	(%rip), %rdi            # 0x82c6 <perf_unwind_php+0x82c6>
    82c6:      	leaq	0x58(%rsp), %rsi
    82cb:      	movl	$0x1, %eax
    82d0:      	callq	*%rax
    82d2:      	testq	%rax, %rax
    82d5:      	je	0x82df <perf_unwind_php+0x82df>
    82d7:      	incq	(%rax)
    82da:      	jmp	0x8361 <perf_unwind_php+0x8361>
    82df:      	movq	(%rip), %rax            # 0x82e6 <perf_unwind_php+0x82e6>
    82e6:      	cmpl	$0x0, (%rax)
    82e9:      	je	0x8361 <perf_unwind_php+0x8361>
    82eb:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    82f5:      	movq	%rax, 0x36(%rsp)
    82fa:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    8304:      	movq	%rax, 0x30(%rsp)
    8309:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    8313:      	movq	%rax, 0x28(%rsp)
    8318:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    8322:      	movq	%rax, 0x20(%rsp)
    8327:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    8331:      	movq	%rax, 0x18(%rsp)
    8336:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    8340:      	movq	%rax, 0x10(%rsp)
    8345:      	leaq	0x10(%rsp), %rdi
    834a:      	movl	$0x2e, %eax
    834f:      	movl	$0x6, %ecx
    8354:      	movl	0x58(%rsp), %edx
    8358:      	movl	$0x2e, %esi
    835d:      	xorl	%eax, %eax
    835f:      	callq	*%rcx
    8361:      	cmpl	$0x23, 0x7c(%rsp)
    8366:      	jne	0x85e3 <perf_unwind_php+0x85e3>
    836c:      	movzbl	0x12(%r15), %eax
    8371:      	addq	0x70(%rsp), %rax
    8376:      	leaq	0x70(%rsp), %rdi
    837b:      	movl	$0x8, %ecx
    8380:      	movl	$0x70, %r8d
    8386:      	movzbl	0x12(%r15), %edx
    838b:      	addq	0x70(%rsp), %rdx
    8390:      	movl	$0x8, %esi
    8395:      	callq	*%r8
    8398:      	testq	%rax, %rax
    839b:      	jne	0x317 <perf_unwind_php+0x317>
    83a1:      	cmpq	$0x0, 0x70(%rsp)
    83a7:      	je	0x83ba <perf_unwind_php+0x83ba>
    83a9:      	movl	$0x5, %r12d
    83af:      	testb	$0x2, 0x56(%rsp)
    83b4:      	je	0x85d9 <perf_unwind_php+0x85d9>
    83ba:      	movq	(%rip), %r13            # 0x83c1 <perf_unwind_php+0x83c1>
    83c1:      	cmpl	$0x0, (%r13)
    83c6:      	jne	0x8733 <perf_unwind_php+0x8733>
    83cc:      	movl	$0x1, %r12d
    83d2:      	cmpb	$0x0, 0x80(%rsp)
    83da:      	je	0x85d9 <perf_unwind_php+0x85d9>
    83e0:      	movq	0x8(%r15), %r15
    83e4:      	movq	%r15, 0xed0(%rbp)
    83eb:      	movb	$0x0, 0xf30(%rbp)
    83f2:      	movq	%r15, %rax
    83f5:      	shrq	$0x38, %rax
    83f9:      	je	0x8415 <perf_unwind_php+0x8415>
    83fb:      	cmpl	$0x0, (%r13)
    8400:      	jne	0x87bc <perf_unwind_php+0x87bc>
    8406:      	movl	$0xb, 0xf28(%rbp)
    8410:      	jmp	0x85d6 <perf_unwind_php+0x85d6>
    8415:      	cmpq	$0xfff, %r15            # imm = 0xFFF
    841c:      	ja	0x8438 <perf_unwind_php+0x8438>
    841e:      	cmpl	$0x0, (%r13)
    8423:      	jne	0x881f <perf_unwind_php+0x881f>
    8429:      	movl	$0x31, 0xf28(%rbp)
    8433:      	jmp	0x85d6 <perf_unwind_php+0x85d6>
    8438:      	movl	(%rbp), %eax
    843b:      	movl	$0x60, 0x58(%rsp)
    8443:      	movbel	%eax, 0x5c(%rsp)
    8449:      	movbeq	%r15, 0x60(%rsp)
    8450:      	movq	(%rip), %rdi            # 0x8457 <perf_unwind_php+0x8457>
    8457:      	leaq	0x58(%rsp), %rsi
    845c:      	movl	$0x1, %eax
    8461:      	callq	*%rax
    8463:      	testq	%rax, %rax
    8466:      	je	0x85c1 <perf_unwind_php+0x85c1>
    846c:      	movabsq	$0xffffffffffffff, %rcx # imm = 0xFFFFFFFFFFFFFF
    8476:      	movq	0x8(%rax), %r12
    847a:      	andq	%r12, %rcx
    847d:      	movq	%rcx, 0xf20(%rbp)
    8484:      	movq	(%rax), %rax
    8487:      	movq	%rax, 0xf10(%rbp)
    848e:      	shrq	$0x38, %r12
    8492:      	movq	%r15, %rax
    8495:      	subq	%rcx, %rax
    8498:      	movq	%rax, 0xf18(%rbp)
    849f:      	cmpl	$0x0, (%r13)
    84a4:      	je	0x85d9 <perf_unwind_php+0x85d9>
    84aa:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    84b4:      	movq	%rax, 0x38(%rsp)
    84b9:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    84c3:      	movq	%rax, 0x30(%rsp)
    84c8:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    84d2:      	movq	%rax, 0x28(%rsp)
    84d7:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    84e1:      	movq	%rax, 0x20(%rsp)
    84e6:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    84f0:      	movq	%rax, 0x18(%rsp)
    84f5:      	movabsq	$0x6365732074786554, %rax # imm = 0x6365732074786554
    84ff:      	movq	%rax, 0x10(%rsp)
    8504:      	movw	$0xa, 0x40(%rsp)
    850b:      	leaq	0x10(%rsp), %rdi
    8510:      	movl	$0x32, %eax
    8515:      	movl	$0x6, %r9d
    851b:      	movq	0xf10(%rbp), %rcx
    8522:      	movl	$0x32, %esi
    8527:      	movq	%r15, %rdx
    852a:      	movl	%r12d, %r8d
    852d:      	xorl	%eax, %eax
    852f:      	callq	*%r9
    8532:      	cmpl	$0x0, (%r13)
    8537:      	je	0x85d9 <perf_unwind_php+0x85d9>
    853d:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    8547:      	movq	%rax, 0x37(%rsp)
    854c:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    8556:      	movq	%rax, 0x30(%rsp)
    855b:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    8565:      	movq	%rax, 0x28(%rsp)
    856a:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    8574:      	movq	%rax, 0x20(%rsp)
    8579:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    8583:      	movq	%rax, 0x18(%rsp)
    8588:      	movabsq	$0x6365732074786554, %rax # imm = 0x6365732074786554
    8592:      	movq	%rax, 0x10(%rsp)
    8597:      	leaq	0x10(%rsp), %rdi
    859c:      	movl	$0x2f, %eax
    85a1:      	movl	$0x6, %r8d
    85a7:      	movq	0xf18(%rbp), %rcx
    85ae:      	movq	0xf20(%rbp), %rdx
    85b5:      	movl	$0x2f, %esi
    85ba:      	xorl	%eax, %eax
    85bc:      	callq	*%r8
    85bf:      	jmp	0x85d9 <perf_unwind_php+0x85d9>
    85c1:      	cmpl	$0x0, (%r13)
    85c6:      	jne	0x887b <perf_unwind_php+0x887b>
    85cc:      	movl	$0xc, 0xf28(%rbp)
    85d6:      	xorl	%r12d, %r12d
    85d9:      	movq	0x70(%rsp), %rax
    85de:      	testq	%rax, %rax
    85e1:      	jne	0x85ef <perf_unwind_php+0x85ef>
    85e3:      	orb	$0x20, 0x1380(%rbp)
    85ea:      	movq	0x70(%rsp), %rax
    85ef:      	movq	%rax, (%r14)
    85f2:      	movl	$0x0, 0x10(%rsp)
    85fa:      	movq	(%rip), %rdi            # 0x8601 <perf_unwind_php+0x8601>
    8601:      	leaq	0x10(%rsp), %rsi
    8606:      	movl	$0x1, %eax
    860b:      	callq	*%rax
    860d:      	testq	%rax, %rax
    8610:      	je	0x8650 <perf_unwind_php+0x8650>
    8612:      	movzbl	0x1384(%rax), %ecx
    8619:      	cmpb	$0x1d, %cl
    861c:      	jb	0x867b <perf_unwind_php+0x867b>
    861e:      	movq	%rax, %r14
    8621:      	movl	$0x5, 0xf2c(%rax)
    862b:      	movl	$0x44, 0x58(%rsp)
    8633:      	movq	(%rip), %rdi            # 0x863a <perf_unwind_php+0x863a>
    863a:      	leaq	0x58(%rsp), %rsi
    863f:      	movl	$0x1, %eax
    8644:      	callq	*%rax
    8646:      	testq	%rax, %rax
    8649:      	je	0x8661 <perf_unwind_php+0x8661>
    864b:      	incq	(%rax)
    864e:      	jmp	0x866d <perf_unwind_php+0x866d>
    8650:      	movq	(%rip), %rcx            # 0x8657 <perf_unwind_php+0x8657>
    8657:      	xorl	%r12d, %r12d
    865a:      	movl	$0xc, %eax
    865f:      	jmp	0x8692 <perf_unwind_php+0x8692>
    8661:      	movq	(%rip), %rax            # 0x8668 <perf_unwind_php+0x8668>
    8668:      	cmpl	$0x0, (%rax)
    866b:      	jne	0x86b8 <perf_unwind_php+0x86b8>
    866d:      	movq	%r14, %rax
    8670:      	movzbl	0x1384(%r14), %ecx
    8678:      	xorl	%r12d, %r12d
    867b:      	incb	%cl
    867d:      	movb	%cl, 0x1384(%rax)
    8683:      	movl	%r12d, %ecx
    8686:      	movq	(%rip), %rdx            # 0x868d <perf_unwind_php+0x868d>
    868d:      	movl	$0xc, %eax
    8692:      	movq	(%rip), %rsi            # 0x8699 <perf_unwind_php+0x8699>
    8699:      	movq	%rbx, %rdi
    869c:      	movl	%r12d, %edx
    869f:      	callq	*%rax
    86a1:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
    86a6:      	addq	$0x88, %rsp
    86ad:      	popq	%rbx
    86ae:      	popq	%r12
    86b0:      	popq	%r13
    86b2:      	popq	%r14
    86b4:      	popq	%r15
    86b6:      	popq	%rbp
    86b7:      	retq
    86b8:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    86c2:      	movq	%rax, 0x36(%rsp)
    86c7:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    86d1:      	movq	%rax, 0x30(%rsp)
    86d6:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    86e0:      	movq	%rax, 0x28(%rsp)
    86e5:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    86ef:      	movq	%rax, 0x20(%rsp)
    86f4:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    86fe:      	movq	%rax, 0x18(%rsp)
    8703:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    870d:      	movq	%rax, 0x10(%rsp)
    8712:      	leaq	0x10(%rsp), %rdi
    8717:      	movl	$0x2e, %eax
    871c:      	movl	$0x6, %ecx
    8721:      	movl	0x58(%rsp), %edx
    8725:      	movl	$0x2e, %esi
    872a:      	xorl	%eax, %eax
    872c:      	callq	*%rcx
    872e:      	jmp	0x866d <perf_unwind_php+0x866d>
    8733:      	movabsq	$0x2578303d61746164, %rax # imm = 0x2578303D61746164
    873d:      	movq	%rax, 0x30(%rsp)
    8742:      	movabsq	$0x5f65747563657865, %rax # imm = 0x5F65747563657865
    874c:      	movq	%rax, 0x28(%rsp)
    8751:      	movabsq	$0x207478656e206874, %rax # imm = 0x207478656E206874
    875b:      	movq	%rax, 0x20(%rsp)
    8760:      	movabsq	$0x6977202c6b636174, %rax # imm = 0x6977202C6B636174
    876a:      	movq	%rax, 0x18(%rsp)
    876f:      	movabsq	$0x732d666f2d706f54, %rax # imm = 0x732D666F2D706F54
    8779:      	movq	%rax, 0x10(%rsp)
    877e:      	movl	$0xa786c, 0x38(%rsp)    # imm = 0xA786C
    8786:      	leaq	0x10(%rsp), %rdi
    878b:      	movl	$0x2c, %eax
    8790:      	movl	$0x6, %ecx
    8795:      	movq	0x70(%rsp), %rdx
    879a:      	movl	$0x2c, %esi
    879f:      	xorl	%eax, %eax
    87a1:      	callq	*%rcx
    87a3:      	movl	$0x1, %r12d
    87a9:      	cmpb	$0x0, 0x80(%rsp)
    87b1:      	jne	0x83e0 <perf_unwind_php+0x83e0>
    87b7:      	jmp	0x85d9 <perf_unwind_php+0x85d9>
    87bc:      	movabsq	$0x7373657264646120, %rax # imm = 0x7373657264646120
    87c6:      	movq	%rax, 0x28(%rsp)
    87cb:      	movabsq	$0x6c656e72656b2061, %rax # imm = 0x6C656E72656B2061
    87d5:      	movq	%rax, 0x20(%rsp)
    87da:      	movabsq	$0x20736920786c2520, %rax # imm = 0x20736920786C2520
    87e4:      	movq	%rax, 0x18(%rsp)
    87e9:      	movabsq	$0x65756c6176204350, %rax # imm = 0x65756C6176204350
    87f3:      	movq	%rax, 0x10(%rsp)
    87f8:      	movw	$0xa, 0x30(%rsp)
    87ff:      	leaq	0x10(%rsp), %rdi
    8804:      	movl	$0x22, %eax
    8809:      	movl	$0x6, %ecx
    880e:      	movl	$0x22, %esi
    8813:      	movq	%r15, %rdx
    8816:      	xorl	%eax, %eax
    8818:      	callq	*%rcx
    881a:      	jmp	0x8406 <perf_unwind_php+0x8406>
    881f:      	movabsq	$0xa676e69726f6e, %rax  # imm = 0xA676E69726F6E
    8829:      	movq	%rax, 0x26(%rsp)
    882e:      	movabsq	$0x6f6e6769202c786c, %rax # imm = 0x6F6E6769202C786C
    8838:      	movq	%rax, 0x20(%rsp)
    883d:      	movabsq	$0x252065756c617620, %rax # imm = 0x252065756C617620
    8847:      	movq	%rax, 0x18(%rsp)
    884c:      	movabsq	$0x6370206c6c616d73, %rax # imm = 0x6370206C6C616D73
    8856:      	movq	%rax, 0x10(%rsp)
    885b:      	leaq	0x10(%rsp), %rdi
    8860:      	movl	$0x1e, %eax
    8865:      	movl	$0x6, %ecx
    886a:      	movl	$0x1e, %esi
    886f:      	movq	%r15, %rdx
    8872:      	xorl	%eax, %eax
    8874:      	callq	*%rcx
    8876:      	jmp	0x8429 <perf_unwind_php+0x8429>
    887b:      	movabsq	$0xa786c2578302043, %rax # imm = 0xA786C2578302043
    8885:      	movq	%rax, 0x40(%rsp)
    888a:      	movabsq	$0x5020726f6620676e, %rax # imm = 0x5020726F6620676E
    8894:      	movq	%rax, 0x38(%rsp)
    8899:      	movabsq	$0x697070616d207972, %rax # imm = 0x697070616D207972
    88a3:      	movq	%rax, 0x30(%rsp)
    88a8:      	movabsq	$0x6f6d656d206c6176, %rax # imm = 0x6F6D656D206C6176
    88b2:      	movq	%rax, 0x28(%rsp)
    88b7:      	movabsq	$0x7265746e69207075, %rax # imm = 0x7265746E69207075
    88c1:      	movq	%rax, 0x20(%rsp)
    88c6:      	movabsq	$0x206b6f6f6c206f74, %rax # imm = 0x206B6F6F6C206F74
    88d0:      	movq	%rax, 0x18(%rsp)
    88d5:      	movabsq	$0x206572756c696146, %rax # imm = 0x206572756C696146
    88df:      	movq	%rax, 0x10(%rsp)
    88e4:      	movb	$0x0, 0x48(%rsp)
    88e9:      	leaq	0x10(%rsp), %rdi
    88ee:      	movl	$0x39, %eax
    88f3:      	movl	$0x6, %ecx
    88f8:      	movl	$0x39, %esi
    88fd:      	movq	%r15, %rdx
    8900:      	xorl	%eax, %eax
    8902:      	callq	*%rcx
    8904:      	jmp	0x85cc <perf_unwind_php+0x85cc>

Disassembly of section kprobe/unwind_php:

0000000000000000 <kprobe_unwind_php>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x88, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x10(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <kprobe_unwind_php+0x23>
      23:      	leaq	0x10(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x86a1 <kprobe_unwind_php+0x86a1>
      38:      	movq	%rax, %r14
      3b:      	movq	%rax, %rbp
      3e:      	movl	(%r14), %eax
      41:      	movl	%eax, 0x84(%rsp)
      48:      	movq	(%rip), %rdi            # 0x4f <kprobe_unwind_php+0x4f>
      4f:      	leaq	0x84(%rsp), %rsi
      57:      	movl	$0x1, %eax
      5c:      	callq	*%rax
      5e:      	testq	%rax, %rax
      61:      	je	0x75 <kprobe_unwind_php+0x75>
      63:      	movq	%rax, %r15
      66:      	cmpq	$0x0, 0xf10(%rbp)
      6e:      	je	0xdd <kprobe_unwind_php+0xdd>
      70:      	xorl	%r13d, %r13d
      73:      	jmp	0xe9 <kprobe_unwind_php+0xe9>
      75:      	movq	(%rip), %rax            # 0x7c <kprobe_unwind_php+0x7c>
      7c:      	movl	$0x1, %r12d
      82:      	cmpl	$0x0, (%rax)
      85:      	je	0x85f2 <kprobe_unwind_php+0x85f2>
      8b:      	movabsq	$0x746164206e6f6974, %rax # imm = 0x746164206E6F6974
      95:      	movq	%rax, 0x20(%rsp)
      9a:      	movabsq	$0x636570736f72746e, %rax # imm = 0x636570736F72746E
      a4:      	movq	%rax, 0x18(%rsp)
      a9:      	movabsq	$0x6920504850206f4e, %rax # imm = 0x6920504850206F4E
      b3:      	movq	%rax, 0x10(%rsp)
      b8:      	movl	$0xa6174, 0x27(%rsp)    # imm = 0xA6174
      c0:      	leaq	0x10(%rsp), %rdi
      c5:      	movl	$0x1b, %eax
      ca:      	movl	$0x6, %ecx
      cf:      	movl	$0x1b, %esi
      d4:      	xorl	%eax, %eax
      d6:      	callq	*%rcx
      d8:      	jmp	0x85f2 <kprobe_unwind_php+0x85f2>
      dd:      	cmpq	$0x0, 0xf20(%rbp)
      e5:      	sete	%r13b
      e9:      	movl	$0x22, 0x58(%rsp)
      f1:      	movq	(%rip), %rdi            # 0xf8 <kprobe_unwind_php+0xf8>
      f8:      	leaq	0x58(%rsp), %rsi
      fd:      	movl	$0x1, %eax
     102:      	callq	*%rax
     104:      	testq	%rax, %rax
     107:      	je	0x187 <kprobe_unwind_php+0x187>
     109:      	incq	(%rax)
     10c:      	addq	$0xf60, %r14            # imm = 0xF60
     113:      	cmpq	$0x0, 0xf60(%rbp)
     11b:      	jne	0x1ac <kprobe_unwind_php+0x1ac>
     121:      	movq	(%r15), %rax
     124:      	movl	$0x8, %ecx
     129:      	movl	$0x70, %r8d
     12f:      	movq	(%r15), %rdx
     132:      	movq	%r14, %rdi
     135:      	movl	$0x8, %esi
     13a:      	callq	*%r8
     13d:      	movq	(%rip), %r12            # 0x144 <kprobe_unwind_php+0x144>
     144:      	movl	(%r12), %ecx
     148:      	testq	%rax, %rax
     14b:      	je	0x1b5 <kprobe_unwind_php+0x1b5>
     14d:      	testl	%ecx, %ecx
     14f:      	jne	0x113c <kprobe_unwind_php+0x113c>
     155:      	movl	$0x24, 0x58(%rsp)
     15d:      	movq	(%rip), %rdi            # 0x164 <kprobe_unwind_php+0x164>
     164:      	leaq	0x58(%rsp), %rsi
     169:      	movl	$0x1, %eax
     16e:      	callq	*%rax
     170:      	testq	%rax, %rax
     173:      	je	0x354 <kprobe_unwind_php+0x354>
     179:      	incq	(%rax)
     17c:      	movl	$0x1, %r12d
     182:      	jmp	0x85f2 <kprobe_unwind_php+0x85f2>
     187:      	movq	(%rip), %rax            # 0x18e <kprobe_unwind_php+0x18e>
     18e:      	cmpl	$0x0, (%rax)
     191:      	jne	0xf3b <kprobe_unwind_php+0xf3b>
     197:      	addq	$0xf60, %r14            # imm = 0xF60
     19e:      	cmpq	$0x0, 0xf60(%rbp)
     1a6:      	je	0x121 <kprobe_unwind_php+0x121>
     1ac:      	movq	(%rip), %rax            # 0x1b3 <kprobe_unwind_php+0x1b3>
     1b3:      	movl	(%rax), %ecx
     1b5:      	testl	%ecx, %ecx
     1b7:      	jne	0xe0c <kprobe_unwind_php+0xe0c>
     1bd:      	movq	(%r14), %r12
     1c0:      	movq	%r12, 0x70(%rsp)
     1c5:      	testq	%r12, %r12
     1c8:      	je	0x35f <kprobe_unwind_php+0x35f>
     1ce:      	movl	$0x0, 0x54(%rsp)
     1d6:      	testb	%r13b, %r13b
     1d9:      	movl	$0x9, %eax
     1de:      	movl	$0x2, %ecx
     1e3:      	cmovnel	%eax, %ecx
     1e6:      	movl	%ecx, 0x7c(%rsp)
     1ea:      	movzbl	0x10(%r15), %eax
     1ef:      	addq	%r12, %rax
     1f2:      	leaq	0x58(%rsp), %rdi
     1f7:      	movl	$0x8, %ecx
     1fc:      	movl	$0x70, %r8d
     202:      	movzbl	0x10(%r15), %edx
     207:      	addq	%r12, %rdx
     20a:      	movl	$0x8, %esi
     20f:      	callq	*%r8
     212:      	testq	%rax, %rax
     215:      	movl	%r13d, 0x80(%rsp)
     21d:      	je	0x26a <kprobe_unwind_php+0x26a>
     21f:      	movq	(%rip), %rax            # 0x226 <kprobe_unwind_php+0x226>
     226:      	movl	$0x25, %r13d
     22c:      	cmpl	$0x0, (%rax)
     22f:      	jne	0xfcb <kprobe_unwind_php+0xfcb>
     235:      	movl	%r13d, 0x58(%rsp)
     23a:      	movq	(%rip), %rdi            # 0x241 <kprobe_unwind_php+0x241>
     241:      	leaq	0x58(%rsp), %rsi
     246:      	movl	$0x1, %eax
     24b:      	callq	*%rax
     24d:      	testq	%rax, %rax
     250:      	je	0x2c6 <kprobe_unwind_php+0x2c6>
     252:      	incq	(%rax)
     255:      	movl	$0x5, %r12d
     25b:      	cmpl	$0x23, %r13d
     25f:      	je	0x2e6 <kprobe_unwind_php+0x2e6>
     265:      	jmp	0x85e3 <kprobe_unwind_php+0x85e3>
     26a:      	movq	0x58(%rsp), %rax
     26f:      	testq	%rax, %rax
     272:      	je	0x3fe <kprobe_unwind_php+0x3fe>
     278:      	movzbl	0x14(%r15), %ecx
     27d:      	addq	%rcx, %rax
     280:      	leaq	0xb(%rsp), %rdi
     285:      	movl	$0x1, %ecx
     28a:      	movl	$0x70, %r8d
     290:      	movzbl	0x14(%r15), %edx
     295:      	addq	0x58(%rsp), %rdx
     29a:      	movl	$0x1, %esi
     29f:      	callq	*%r8
     2a2:      	testq	%rax, %rax
     2a5:      	je	0x535 <kprobe_unwind_php+0x535>
     2ab:      	movq	(%rip), %rax            # 0x2b2 <kprobe_unwind_php+0x2b2>
     2b2:      	cmpl	$0x0, (%rax)
     2b5:      	jne	0x13d8 <kprobe_unwind_php+0x13d8>
     2bb:      	movl	$0x26, %r13d
     2c1:      	jmp	0x235 <kprobe_unwind_php+0x235>
     2c6:      	movq	(%rip), %rax            # 0x2cd <kprobe_unwind_php+0x2cd>
     2cd:      	cmpl	$0x0, (%rax)
     2d0:      	jne	0x11d4 <kprobe_unwind_php+0x11d4>
     2d6:      	movl	$0x5, %r12d
     2dc:      	cmpl	$0x23, %r13d
     2e0:      	jne	0x85e3 <kprobe_unwind_php+0x85e3>
     2e6:      	movzbl	0x12(%r15), %eax
     2eb:      	addq	0x70(%rsp), %rax
     2f0:      	leaq	0x70(%rsp), %rdi
     2f5:      	movl	$0x8, %ecx
     2fa:      	movl	$0x70, %r8d
     300:      	movzbl	0x12(%r15), %edx
     305:      	addq	0x70(%rsp), %rdx
     30a:      	movl	$0x8, %esi
     30f:      	callq	*%r8
     312:      	testq	%rax, %rax
     315:      	je	0x36a <kprobe_unwind_php+0x36a>
     317:      	movq	(%rip), %r15            # 0x31e <kprobe_unwind_php+0x31e>
     31e:      	cmpl	$0x0, (%r15)
     322:      	jne	0x12c3 <kprobe_unwind_php+0x12c3>
     328:      	movl	$0x25, 0x58(%rsp)
     330:      	movq	(%rip), %rdi            # 0x337 <kprobe_unwind_php+0x337>
     337:      	leaq	0x58(%rsp), %rsi
     33c:      	movl	$0x1, %eax
     341:      	callq	*%rax
     343:      	testq	%rax, %rax
     346:      	je	0x4b0 <kprobe_unwind_php+0x4b0>
     34c:      	incq	(%rax)
     34f:      	jmp	0x85e3 <kprobe_unwind_php+0x85e3>
     354:      	cmpl	$0x0, (%r12)
     359:      	jne	0x135d <kprobe_unwind_php+0x135d>
     35f:      	movl	$0x1, %r12d
     365:      	jmp	0x85f2 <kprobe_unwind_php+0x85f2>
     36a:      	movq	0x70(%rsp), %r13
     36f:      	testq	%r13, %r13
     372:      	je	0x83ba <kprobe_unwind_php+0x83ba>
     378:      	testb	$0x2, 0x56(%rsp)
     37d:      	jne	0x83ba <kprobe_unwind_php+0x83ba>
     383:      	movzbl	0x10(%r15), %eax
     388:      	addq	%r13, %rax
     38b:      	leaq	0x58(%rsp), %rdi
     390:      	movl	$0x8, %ecx
     395:      	movl	$0x70, %r8d
     39b:      	movzbl	0x10(%r15), %edx
     3a0:      	addq	%r13, %rdx
     3a3:      	movl	$0x8, %esi
     3a8:      	callq	*%r8
     3ab:      	testq	%rax, %rax
     3ae:      	je	0x7ce <kprobe_unwind_php+0x7ce>
     3b4:      	movq	(%rip), %rax            # 0x3bb <kprobe_unwind_php+0x3bb>
     3bb:      	movl	$0x25, %ecx
     3c0:      	cmpl	$0x0, (%rax)
     3c3:      	jne	0x1811 <kprobe_unwind_php+0x1811>
     3c9:      	movl	%ecx, %r13d
     3cc:      	movl	%ecx, 0x58(%rsp)
     3d0:      	movq	(%rip), %rdi            # 0x3d7 <kprobe_unwind_php+0x3d7>
     3d7:      	leaq	0x58(%rsp), %rsi
     3dc:      	movl	$0x1, %eax
     3e1:      	callq	*%rax
     3e3:      	testq	%rax, %rax
     3e6:      	je	0x829 <kprobe_unwind_php+0x829>
     3ec:      	incq	(%rax)
     3ef:      	cmpl	$0x23, %r13d
     3f3:      	je	0x843 <kprobe_unwind_php+0x843>
     3f9:      	jmp	0x85e3 <kprobe_unwind_php+0x85e3>
     3fe:      	movl	0x2c0(%rbp), %eax
     404:      	cmpq	$0x7f, %rax
     408:      	jb	0x615 <kprobe_unwind_php+0x615>
     40e:      	movq	(%rip), %r15            # 0x415 <kprobe_unwind_php+0x415>
     415:      	cmpl	$0x0, (%r15)
     419:      	jne	0x167e <kprobe_unwind_php+0x167e>
     41f:      	movl	$0x2, 0x68(%rsp)
     427:      	movq	(%rip), %rdi            # 0x42e <kprobe_unwind_php+0x42e>
     42e:      	leaq	0x68(%rsp), %rsi
     433:      	movl	$0x1, %eax
     438:      	callq	*%rax
     43a:      	testq	%rax, %rax
     43d:      	je	0x663 <kprobe_unwind_php+0x663>
     443:      	incq	(%rax)
     446:      	cmpl	$0x0, (%r15)
     44a:      	je	0xbd9 <kprobe_unwind_php+0xbd9>
     450:      	movabsq	$0x656d617266207068, %rax # imm = 0x656D617266207068
     45a:      	movq	%rax, 0x28(%rsp)
     45f:      	movabsq	$0x70206e776f6e6b6e, %rax # imm = 0x70206E776F6E6B6E
     469:      	movq	%rax, 0x20(%rsp)
     46e:      	movabsq	$0x752068737570206f, %rax # imm = 0x752068737570206F
     478:      	movq	%rax, 0x18(%rsp)
     47d:      	movabsq	$0x742064656c696166, %rax # imm = 0x742064656C696166
     487:      	movq	%rax, 0x10(%rsp)
     48c:      	movw	$0xa, 0x30(%rsp)
     493:      	leaq	0x10(%rsp), %rdi
     498:      	movl	$0x22, %eax
     49d:      	movl	$0x6, %ecx
     4a2:      	movl	$0x22, %esi
     4a7:      	xorl	%eax, %eax
     4a9:      	callq	*%rcx
     4ab:      	jmp	0xbd9 <kprobe_unwind_php+0xbd9>
     4b0:      	cmpl	$0x0, (%r15)
     4b4:      	je	0x85e3 <kprobe_unwind_php+0x85e3>
     4ba:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     4c4:      	movq	%rax, 0x36(%rsp)
     4c9:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     4d3:      	movq	%rax, 0x30(%rsp)
     4d8:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     4e2:      	movq	%rax, 0x28(%rsp)
     4e7:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     4f1:      	movq	%rax, 0x20(%rsp)
     4f6:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     500:      	movq	%rax, 0x18(%rsp)
     505:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     50f:      	movq	%rax, 0x10(%rsp)
     514:      	leaq	0x10(%rsp), %rdi
     519:      	movl	$0x2e, %eax
     51e:      	movl	$0x6, %ecx
     523:      	movl	0x58(%rsp), %edx
     527:      	movl	$0x2e, %esi
     52c:      	xorl	%eax, %eax
     52e:      	callq	*%rcx
     530:      	jmp	0x85e3 <kprobe_unwind_php+0x85e3>
     535:      	movl	$0x0, 0xc(%rsp)
     53d:      	movzbl	0xb(%rsp), %eax
     542:      	cmpl	$0x4, %eax
     545:      	je	0x553 <kprobe_unwind_php+0x553>
     547:      	xorl	%r13d, %r13d
     54a:      	cmpl	$0x2, %eax
     54d:      	jne	0xb22 <kprobe_unwind_php+0xb22>
     553:      	movzbl	0x11(%r15), %eax
     558:      	addq	%r12, %rax
     55b:      	leaq	0x68(%rsp), %rdi
     560:      	movl	$0x8, %ecx
     565:      	movl	$0x70, %r8d
     56b:      	movzbl	0x11(%r15), %edx
     570:      	addq	%r12, %rdx
     573:      	movl	$0x8, %esi
     578:      	callq	*%r8
     57b:      	testq	%rax, %rax
     57e:      	je	0x6f2 <kprobe_unwind_php+0x6f2>
     584:      	movq	(%rip), %rax            # 0x58b <kprobe_unwind_php+0x58b>
     58b:      	movl	$0x25, %r13d
     591:      	cmpl	$0x0, (%rax)
     594:      	je	0x235 <kprobe_unwind_php+0x235>
     59a:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
     5a4:      	movq	%rax, 0x35(%rsp)
     5a9:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
     5b3:      	movq	%rax, 0x30(%rsp)
     5b8:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
     5c2:      	movq	%rax, 0x28(%rsp)
     5c7:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
     5d1:      	movq	%rax, 0x20(%rsp)
     5d6:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
     5e0:      	movq	%rax, 0x18(%rsp)
     5e5:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     5ef:      	movq	%rax, 0x10(%rsp)
     5f4:      	leaq	0x10(%rsp), %rdi
     5f9:      	movl	$0x2d, %eax
     5fe:      	movl	$0x6, %ecx
     603:      	movzbl	0x11(%r15), %eax
     608:      	addq	%rax, %r12
     60b:      	movl	$0x2d, %esi
     610:      	jmp	0x1049 <kprobe_unwind_php+0x1049>
     615:      	leal	0x1(%rax), %ecx
     618:      	movl	%ecx, 0x2c0(%rbp)
     61e:      	leaq	(%rax,%rax,2), %rax
     622:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
     62e:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
     63a:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
     642:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
     64d:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
     658:      	movl	$0x23, %r13d
     65e:      	jmp	0x235 <kprobe_unwind_php+0x235>
     663:      	cmpl	$0x0, (%r15)
     667:      	je	0xbd9 <kprobe_unwind_php+0xbd9>
     66d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     677:      	movq	%rax, 0x36(%rsp)
     67c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     686:      	movq	%rax, 0x30(%rsp)
     68b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     695:      	movq	%rax, 0x28(%rsp)
     69a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     6a4:      	movq	%rax, 0x20(%rsp)
     6a9:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     6b3:      	movq	%rax, 0x18(%rsp)
     6b8:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     6c2:      	movq	%rax, 0x10(%rsp)
     6c7:      	leaq	0x10(%rsp), %rdi
     6cc:      	movl	$0x2e, %eax
     6d1:      	movl	$0x6, %ecx
     6d6:      	movl	0x68(%rsp), %edx
     6da:      	movl	$0x2e, %esi
     6df:      	xorl	%eax, %eax
     6e1:      	callq	*%rcx
     6e3:      	cmpl	$0x0, (%r15)
     6e7:      	je	0xbd9 <kprobe_unwind_php+0xbd9>
     6ed:      	jmp	0x450 <kprobe_unwind_php+0x450>
     6f2:      	movzbl	0x15(%r15), %eax
     6f7:      	addq	0x68(%rsp), %rax
     6fc:      	leaq	0xc(%rsp), %rdi
     701:      	movl	$0x4, %ecx
     706:      	movl	$0x70, %r8d
     70c:      	movzbl	0x15(%r15), %edx
     711:      	addq	0x68(%rsp), %rdx
     716:      	movl	$0x4, %esi
     71b:      	callq	*%r8
     71e:      	testq	%rax, %rax
     721:      	je	0x912 <kprobe_unwind_php+0x912>
     727:      	movq	(%rip), %rax            # 0x72e <kprobe_unwind_php+0x72e>
     72e:      	movl	$0x27, %r13d
     734:      	cmpl	$0x0, (%rax)
     737:      	je	0x235 <kprobe_unwind_php+0x235>
     73d:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
     747:      	movq	%rax, 0x40(%rsp)
     74c:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
     756:      	movq	%rax, 0x38(%rsp)
     75b:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
     765:      	movq	%rax, 0x30(%rsp)
     76a:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
     774:      	movq	%rax, 0x28(%rsp)
     779:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
     783:      	movq	%rax, 0x20(%rsp)
     788:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
     792:      	movq	%rax, 0x18(%rsp)
     797:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     7a1:      	movq	%rax, 0x10(%rsp)
     7a6:      	movb	$0x0, 0x48(%rsp)
     7ab:      	leaq	0x10(%rsp), %rdi
     7b0:      	movl	$0x39, %eax
     7b5:      	movl	$0x6, %ecx
     7ba:      	movzbl	0x15(%r15), %edx
     7bf:      	addq	0x68(%rsp), %rdx
     7c4:      	movl	$0x39, %esi
     7c9:      	jmp	0x104c <kprobe_unwind_php+0x104c>
     7ce:      	movq	0x58(%rsp), %rax
     7d3:      	testq	%rax, %rax
     7d6:      	je	0x9db <kprobe_unwind_php+0x9db>
     7dc:      	movzbl	0x14(%r15), %ecx
     7e1:      	addq	%rcx, %rax
     7e4:      	leaq	0xb(%rsp), %rdi
     7e9:      	movl	$0x1, %ecx
     7ee:      	movl	$0x70, %r8d
     7f4:      	movzbl	0x14(%r15), %edx
     7f9:      	addq	0x58(%rsp), %rdx
     7fe:      	movl	$0x1, %esi
     803:      	callq	*%r8
     806:      	testq	%rax, %rax
     809:      	je	0xa38 <kprobe_unwind_php+0xa38>
     80f:      	movq	(%rip), %rax            # 0x816 <kprobe_unwind_php+0x816>
     816:      	cmpl	$0x0, (%rax)
     819:      	jne	0x1b96 <kprobe_unwind_php+0x1b96>
     81f:      	movl	$0x26, %ecx
     824:      	jmp	0x3c9 <kprobe_unwind_php+0x3c9>
     829:      	movq	(%rip), %rax            # 0x830 <kprobe_unwind_php+0x830>
     830:      	cmpl	$0x0, (%rax)
     833:      	jne	0x1a23 <kprobe_unwind_php+0x1a23>
     839:      	cmpl	$0x23, %r13d
     83d:      	jne	0x85e3 <kprobe_unwind_php+0x85e3>
     843:      	movzbl	0x12(%r15), %eax
     848:      	addq	0x70(%rsp), %rax
     84d:      	leaq	0x70(%rsp), %rdi
     852:      	movl	$0x8, %ecx
     857:      	movl	$0x70, %r8d
     85d:      	movzbl	0x12(%r15), %edx
     862:      	addq	0x70(%rsp), %rdx
     867:      	movl	$0x8, %esi
     86c:      	callq	*%r8
     86f:      	testq	%rax, %rax
     872:      	jne	0x317 <kprobe_unwind_php+0x317>
     878:      	movq	0x70(%rsp), %r13
     87d:      	testq	%r13, %r13
     880:      	je	0x83ba <kprobe_unwind_php+0x83ba>
     886:      	testb	$0x2, 0x56(%rsp)
     88b:      	jne	0x83ba <kprobe_unwind_php+0x83ba>
     891:      	movzbl	0x10(%r15), %eax
     896:      	addq	%r13, %rax
     899:      	leaq	0x58(%rsp), %rdi
     89e:      	movl	$0x8, %ecx
     8a3:      	movl	$0x70, %r8d
     8a9:      	movzbl	0x10(%r15), %edx
     8ae:      	addq	%r13, %rdx
     8b1:      	movl	$0x8, %esi
     8b6:      	callq	*%r8
     8b9:      	testq	%rax, %rax
     8bc:      	je	0xcc8 <kprobe_unwind_php+0xcc8>
     8c2:      	movq	(%rip), %rax            # 0x8c9 <kprobe_unwind_php+0x8c9>
     8c9:      	movl	$0x25, 0x4(%rsp)
     8d1:      	cmpl	$0x0, (%rax)
     8d4:      	jne	0x1fec <kprobe_unwind_php+0x1fec>
     8da:      	movl	0x4(%rsp), %r13d
     8df:      	movl	%r13d, 0x58(%rsp)
     8e4:      	movq	(%rip), %rdi            # 0x8eb <kprobe_unwind_php+0x8eb>
     8eb:      	leaq	0x58(%rsp), %rsi
     8f0:      	movl	$0x1, %eax
     8f5:      	callq	*%rax
     8f7:      	testq	%rax, %rax
     8fa:      	je	0xd24 <kprobe_unwind_php+0xd24>
     900:      	incq	(%rax)
     903:      	cmpl	$0x23, %r13d
     907:      	je	0xd3e <kprobe_unwind_php+0xd3e>
     90d:      	jmp	0x85e3 <kprobe_unwind_php+0x85e3>
     912:      	movzbl	0x13(%r15), %eax
     917:      	addq	%r12, %rax
     91a:      	leaq	0x54(%rsp), %rdi
     91f:      	movl	$0x4, %ecx
     924:      	movl	$0x70, %r8d
     92a:      	movzbl	0x13(%r15), %edx
     92f:      	addq	%r12, %rdx
     932:      	movl	$0x4, %esi
     937:      	callq	*%r8
     93a:      	testq	%rax, %rax
     93d:      	je	0xb1d <kprobe_unwind_php+0xb1d>
     943:      	movq	(%rip), %rax            # 0x94a <kprobe_unwind_php+0x94a>
     94a:      	movl	$0x25, %r13d
     950:      	cmpl	$0x0, (%rax)
     953:      	je	0x235 <kprobe_unwind_php+0x235>
     959:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
     963:      	movq	%rax, 0x3d(%rsp)
     968:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
     972:      	movq	%rax, 0x38(%rsp)
     977:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
     981:      	movq	%rax, 0x30(%rsp)
     986:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
     990:      	movq	%rax, 0x28(%rsp)
     995:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
     99f:      	movq	%rax, 0x20(%rsp)
     9a4:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
     9ae:      	movq	%rax, 0x18(%rsp)
     9b3:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     9bd:      	movq	%rax, 0x10(%rsp)
     9c2:      	leaq	0x10(%rsp), %rdi
     9c7:      	movl	$0x35, %eax
     9cc:      	movl	$0x6, %ecx
     9d1:      	movl	$0x35, %esi
     9d6:      	jmp	0x1049 <kprobe_unwind_php+0x1049>
     9db:      	movl	0x2c0(%rbp), %eax
     9e1:      	cmpq	$0x7e, %rax
     9e5:      	ja	0x40e <kprobe_unwind_php+0x40e>
     9eb:      	leal	0x1(%rax), %ecx
     9ee:      	movl	%ecx, 0x2c0(%rbp)
     9f4:      	leaq	(%rax,%rax,2), %rax
     9f8:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
     a04:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
     a10:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
     a18:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
     a23:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
     a2e:      	movl	$0x23, %ecx
     a33:      	jmp	0x3c9 <kprobe_unwind_php+0x3c9>
     a38:      	movl	$0x0, 0xc(%rsp)
     a40:      	movzbl	0xb(%rsp), %eax
     a45:      	cmpl	$0x4, %eax
     a48:      	je	0xa55 <kprobe_unwind_php+0xa55>
     a4a:      	xorl	%ecx, %ecx
     a4c:      	cmpl	$0x2, %eax
     a4f:      	jne	0x1263 <kprobe_unwind_php+0x1263>
     a55:      	movzbl	0x11(%r15), %eax
     a5a:      	addq	%r13, %rax
     a5d:      	leaq	0x68(%rsp), %rdi
     a62:      	movl	$0x8, %ecx
     a67:      	movl	$0x70, %r8d
     a6d:      	movzbl	0x11(%r15), %edx
     a72:      	addq	%r13, %rdx
     a75:      	movl	$0x8, %esi
     a7a:      	callq	*%r8
     a7d:      	testq	%rax, %rax
     a80:      	je	0xbe4 <kprobe_unwind_php+0xbe4>
     a86:      	movq	(%rip), %rax            # 0xa8d <kprobe_unwind_php+0xa8d>
     a8d:      	movl	$0x25, %ecx
     a92:      	cmpl	$0x0, (%rax)
     a95:      	je	0x3c9 <kprobe_unwind_php+0x3c9>
     a9b:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
     aa5:      	movq	%rax, 0x35(%rsp)
     aaa:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
     ab4:      	movq	%rax, 0x30(%rsp)
     ab9:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
     ac3:      	movq	%rax, 0x28(%rsp)
     ac8:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
     ad2:      	movq	%rax, 0x20(%rsp)
     ad7:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
     ae1:      	movq	%rax, 0x18(%rsp)
     ae6:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     af0:      	movq	%rax, 0x10(%rsp)
     af5:      	leaq	0x10(%rsp), %rdi
     afa:      	movl	$0x2d, %eax
     aff:      	movl	$0x6, %ecx
     b04:      	movzbl	0x11(%r15), %eax
     b09:      	addq	%rax, %r13
     b0c:      	movl	$0x2d, %esi
     b11:      	movq	%r13, %rdx
     b14:      	xorl	%eax, %eax
     b16:      	callq	*%rcx
     b18:      	jmp	0xed1 <kprobe_unwind_php+0xed1>
     b1d:      	movl	0xc(%rsp), %r13d
     b22:      	movl	0x54(%rsp), %r12d
     b27:      	movq	(%rip), %rax            # 0xb2e <kprobe_unwind_php+0xb2e>
     b2e:      	cmpl	$0x0, (%rax)
     b31:      	jne	0x18a0 <kprobe_unwind_php+0x18a0>
     b37:      	movl	0x2c0(%rbp), %eax
     b3d:      	cmpq	$0x7f, %rax
     b41:      	jb	0x1900 <kprobe_unwind_php+0x1900>
     b47:      	movq	(%rip), %r15            # 0xb4e <kprobe_unwind_php+0xb4e>
     b4e:      	cmpl	$0x0, (%r15)
     b52:      	jne	0x1b2e <kprobe_unwind_php+0x1b2e>
     b58:      	movl	$0x2, 0x68(%rsp)
     b60:      	movq	(%rip), %rdi            # 0xb67 <kprobe_unwind_php+0xb67>
     b67:      	leaq	0x68(%rsp), %rsi
     b6c:      	movl	$0x1, %eax
     b71:      	callq	*%rax
     b73:      	testq	%rax, %rax
     b76:      	je	0xbcf <kprobe_unwind_php+0xbcf>
     b78:      	incq	(%rax)
     b7b:      	cmpl	$0x0, (%r15)
     b7f:      	je	0xbd9 <kprobe_unwind_php+0xbd9>
     b81:      	movabsq	$0x656d617266207068, %rax # imm = 0x656D617266207068
     b8b:      	movq	%rax, 0x20(%rsp)
     b90:      	movabsq	$0x702068737570206f, %rax # imm = 0x702068737570206F
     b9a:      	movq	%rax, 0x18(%rsp)
     b9f:      	movabsq	$0x742064656c696166, %rax # imm = 0x742064656C696166
     ba9:      	movq	%rax, 0x10(%rsp)
     bae:      	movw	$0xa, 0x28(%rsp)
     bb5:      	leaq	0x10(%rsp), %rdi
     bba:      	movl	$0x1a, %eax
     bbf:      	movl	$0x6, %ecx
     bc4:      	movl	$0x1a, %esi
     bc9:      	xorl	%eax, %eax
     bcb:      	callq	*%rcx
     bcd:      	jmp	0xbd9 <kprobe_unwind_php+0xbd9>
     bcf:      	cmpl	$0x0, (%r15)
     bd3:      	jne	0x1cf5 <kprobe_unwind_php+0x1cf5>
     bd9:      	movl	$0x5, %r12d
     bdf:      	jmp	0x85e3 <kprobe_unwind_php+0x85e3>
     be4:      	movzbl	0x15(%r15), %eax
     be9:      	addq	0x68(%rsp), %rax
     bee:      	leaq	0xc(%rsp), %rdi
     bf3:      	movl	$0x4, %ecx
     bf8:      	movl	$0x70, %r8d
     bfe:      	movzbl	0x15(%r15), %edx
     c03:      	addq	0x68(%rsp), %rdx
     c08:      	movl	$0x4, %esi
     c0d:      	callq	*%r8
     c10:      	testq	%rax, %rax
     c13:      	je	0xe90 <kprobe_unwind_php+0xe90>
     c19:      	movq	(%rip), %rax            # 0xc20 <kprobe_unwind_php+0xc20>
     c20:      	movl	$0x27, %ecx
     c25:      	cmpl	$0x0, (%rax)
     c28:      	je	0x3c9 <kprobe_unwind_php+0x3c9>
     c2e:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
     c38:      	movq	%rax, 0x40(%rsp)
     c3d:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
     c47:      	movq	%rax, 0x38(%rsp)
     c4c:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
     c56:      	movq	%rax, 0x30(%rsp)
     c5b:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
     c65:      	movq	%rax, 0x28(%rsp)
     c6a:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
     c74:      	movq	%rax, 0x20(%rsp)
     c79:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
     c83:      	movq	%rax, 0x18(%rsp)
     c88:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     c92:      	movq	%rax, 0x10(%rsp)
     c97:      	movb	$0x0, 0x48(%rsp)
     c9c:      	leaq	0x10(%rsp), %rdi
     ca1:      	movl	$0x39, %eax
     ca6:      	movl	$0x6, %ecx
     cab:      	movzbl	0x15(%r15), %edx
     cb0:      	addq	0x68(%rsp), %rdx
     cb5:      	movl	$0x39, %esi
     cba:      	xorl	%eax, %eax
     cbc:      	callq	*%rcx
     cbe:      	movl	$0x27, %ecx
     cc3:      	jmp	0x3c9 <kprobe_unwind_php+0x3c9>
     cc8:      	movq	0x58(%rsp), %rax
     ccd:      	testq	%rax, %rax
     cd0:      	je	0xedb <kprobe_unwind_php+0xedb>
     cd6:      	movzbl	0x14(%r15), %ecx
     cdb:      	addq	%rcx, %rax
     cde:      	leaq	0xb(%rsp), %rdi
     ce3:      	movl	$0x1, %ecx
     ce8:      	movl	$0x70, %r8d
     cee:      	movzbl	0x14(%r15), %edx
     cf3:      	addq	0x58(%rsp), %rdx
     cf8:      	movl	$0x1, %esi
     cfd:      	callq	*%r8
     d00:      	testq	%rax, %rax
     d03:      	je	0x1055 <kprobe_unwind_php+0x1055>
     d09:      	movq	(%rip), %rax            # 0xd10 <kprobe_unwind_php+0xd10>
     d10:      	cmpl	$0x0, (%rax)
     d13:      	jne	0x22b9 <kprobe_unwind_php+0x22b9>
     d19:      	movl	$0x26, %r13d
     d1f:      	jmp	0x8df <kprobe_unwind_php+0x8df>
     d24:      	movq	(%rip), %rax            # 0xd2b <kprobe_unwind_php+0xd2b>
     d2b:      	cmpl	$0x0, (%rax)
     d2e:      	jne	0x21ca <kprobe_unwind_php+0x21ca>
     d34:      	cmpl	$0x23, %r13d
     d38:      	jne	0x85e3 <kprobe_unwind_php+0x85e3>
     d3e:      	movzbl	0x12(%r15), %eax
     d43:      	addq	0x70(%rsp), %rax
     d48:      	leaq	0x70(%rsp), %rdi
     d4d:      	movl	$0x8, %ecx
     d52:      	movl	$0x70, %r8d
     d58:      	movzbl	0x12(%r15), %edx
     d5d:      	addq	0x70(%rsp), %rdx
     d62:      	movl	$0x8, %esi
     d67:      	callq	*%r8
     d6a:      	testq	%rax, %rax
     d6d:      	jne	0x317 <kprobe_unwind_php+0x317>
     d73:      	movq	0x70(%rsp), %r13
     d78:      	testq	%r13, %r13
     d7b:      	je	0x83ba <kprobe_unwind_php+0x83ba>
     d81:      	testb	$0x2, 0x56(%rsp)
     d86:      	jne	0x83ba <kprobe_unwind_php+0x83ba>
     d8c:      	movzbl	0x10(%r15), %eax
     d91:      	addq	%r13, %rax
     d94:      	leaq	0x58(%rsp), %rdi
     d99:      	movl	$0x8, %ecx
     d9e:      	movl	$0x70, %r8d
     da4:      	movzbl	0x10(%r15), %edx
     da9:      	addq	%r13, %rdx
     dac:      	movl	$0x8, %esi
     db1:      	callq	*%r8
     db4:      	testq	%rax, %rax
     db7:      	je	0x1537 <kprobe_unwind_php+0x1537>
     dbd:      	movq	(%rip), %rax            # 0xdc4 <kprobe_unwind_php+0xdc4>
     dc4:      	movl	$0x25, 0x4(%rsp)
     dcc:      	cmpl	$0x0, (%rax)
     dcf:      	jne	0x270c <kprobe_unwind_php+0x270c>
     dd5:      	movl	0x4(%rsp), %eax
     dd9:      	movl	%eax, 0x58(%rsp)
     ddd:      	movq	(%rip), %rdi            # 0xde4 <kprobe_unwind_php+0xde4>
     de4:      	leaq	0x58(%rsp), %rsi
     de9:      	movl	$0x1, %eax
     dee:      	callq	*%rax
     df0:      	testq	%rax, %rax
     df3:      	je	0x1595 <kprobe_unwind_php+0x1595>
     df9:      	incq	(%rax)
     dfc:      	cmpl	$0x23, 0x4(%rsp)
     e01:      	je	0x15b0 <kprobe_unwind_php+0x15b0>
     e07:      	jmp	0x85e3 <kprobe_unwind_php+0x85e3>
     e0c:      	movabsq	$0x786c257830203d20, %rax # imm = 0x786C257830203D20
     e16:      	movq	%rax, 0x30(%rsp)
     e1b:      	movabsq	$0x617461645f657475, %rax # imm = 0x617461645F657475
     e25:      	movq	%rax, 0x28(%rsp)
     e2a:      	movabsq	$0x6365786528206b63, %rax # imm = 0x6365786528206B63
     e34:      	movq	%rax, 0x20(%rsp)
     e39:      	movabsq	$0x6174732050485020, %rax # imm = 0x6174732050485020
     e43:      	movq	%rax, 0x18(%rsp)
     e48:      	movabsq	$0x676e69646c697542, %rax # imm = 0x676E69646C697542
     e52:      	movq	%rax, 0x10(%rsp)
     e57:      	movl	$0xa2978, 0x37(%rsp)    # imm = 0xA2978
     e5f:      	leaq	0x10(%rsp), %rdi
     e64:      	movl	$0x2b, %eax
     e69:      	movl	$0x6, %ecx
     e6e:      	movq	(%r14), %rdx
     e71:      	movl	$0x2b, %esi
     e76:      	xorl	%eax, %eax
     e78:      	callq	*%rcx
     e7a:      	movq	(%r14), %r12
     e7d:      	movq	%r12, 0x70(%rsp)
     e82:      	testq	%r12, %r12
     e85:      	jne	0x1ce <kprobe_unwind_php+0x1ce>
     e8b:      	jmp	0x35f <kprobe_unwind_php+0x35f>
     e90:      	movzbl	0x13(%r15), %eax
     e95:      	addq	%r13, %rax
     e98:      	leaq	0x54(%rsp), %rdi
     e9d:      	movl	$0x4, %ecx
     ea2:      	movl	$0x70, %r8d
     ea8:      	movzbl	0x13(%r15), %edx
     ead:      	addq	%r13, %rdx
     eb0:      	movl	$0x4, %esi
     eb5:      	callq	*%r8
     eb8:      	testq	%rax, %rax
     ebb:      	je	0x125f <kprobe_unwind_php+0x125f>
     ec1:      	movq	(%rip), %rax            # 0xec8 <kprobe_unwind_php+0xec8>
     ec8:      	cmpl	$0x0, (%rax)
     ecb:      	jne	0x255f <kprobe_unwind_php+0x255f>
     ed1:      	movl	$0x25, %ecx
     ed6:      	jmp	0x3c9 <kprobe_unwind_php+0x3c9>
     edb:      	movl	0x2c0(%rbp), %eax
     ee1:      	cmpq	$0x7e, %rax
     ee5:      	ja	0x40e <kprobe_unwind_php+0x40e>
     eeb:      	leal	0x1(%rax), %ecx
     eee:      	movl	%ecx, 0x2c0(%rbp)
     ef4:      	leaq	(%rax,%rax,2), %rax
     ef8:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
     f04:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
     f10:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
     f18:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
     f23:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
     f2e:      	movl	$0x23, 0x4(%rsp)
     f36:      	jmp	0x8da <kprobe_unwind_php+0x8da>
     f3b:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     f45:      	movq	%rax, 0x36(%rsp)
     f4a:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     f54:      	movq	%rax, 0x30(%rsp)
     f59:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     f63:      	movq	%rax, 0x28(%rsp)
     f68:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     f72:      	movq	%rax, 0x20(%rsp)
     f77:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     f81:      	movq	%rax, 0x18(%rsp)
     f86:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     f90:      	movq	%rax, 0x10(%rsp)
     f95:      	leaq	0x10(%rsp), %rdi
     f9a:      	movl	$0x2e, %eax
     f9f:      	movl	$0x6, %ecx
     fa4:      	movl	0x58(%rsp), %edx
     fa8:      	movl	$0x2e, %esi
     fad:      	xorl	%eax, %eax
     faf:      	callq	*%rcx
     fb1:      	addq	$0xf60, %r14            # imm = 0xF60
     fb8:      	cmpq	$0x0, 0xf60(%rbp)
     fc0:      	jne	0x1ac <kprobe_unwind_php+0x1ac>
     fc6:      	jmp	0x121 <kprobe_unwind_php+0x121>
     fcb:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
     fd5:      	movq	%rax, 0x38(%rsp)
     fda:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
     fe4:      	movq	%rax, 0x30(%rsp)
     fe9:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
     ff3:      	movq	%rax, 0x28(%rsp)
     ff8:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    1002:      	movq	%rax, 0x20(%rsp)
    1007:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    1011:      	movq	%rax, 0x18(%rsp)
    1016:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1020:      	movq	%rax, 0x10(%rsp)
    1025:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    102d:      	leaq	0x10(%rsp), %rdi
    1032:      	movl	$0x33, %eax
    1037:      	movl	$0x6, %ecx
    103c:      	movzbl	0x10(%r15), %eax
    1041:      	addq	%rax, %r12
    1044:      	movl	$0x33, %esi
    1049:      	movq	%r12, %rdx
    104c:      	xorl	%eax, %eax
    104e:      	callq	*%rcx
    1050:      	jmp	0x235 <kprobe_unwind_php+0x235>
    1055:      	movl	$0x0, 0xc(%rsp)
    105d:      	movzbl	0xb(%rsp), %eax
    1062:      	cmpl	$0x4, %eax
    1065:      	je	0x1078 <kprobe_unwind_php+0x1078>
    1067:      	movl	$0x0, 0x4(%rsp)
    106f:      	cmpl	$0x2, %eax
    1072:      	jne	0x1ab0 <kprobe_unwind_php+0x1ab0>
    1078:      	movzbl	0x11(%r15), %eax
    107d:      	addq	%r13, %rax
    1080:      	leaq	0x68(%rsp), %rdi
    1085:      	movl	$0x8, %ecx
    108a:      	movl	$0x70, %r8d
    1090:      	movzbl	0x11(%r15), %edx
    1095:      	addq	%r13, %rdx
    1098:      	movl	$0x8, %esi
    109d:      	callq	*%r8
    10a0:      	testq	%rax, %rax
    10a3:      	je	0x1459 <kprobe_unwind_php+0x1459>
    10a9:      	movq	(%rip), %rax            # 0x10b0 <kprobe_unwind_php+0x10b0>
    10b0:      	movl	$0x25, 0x4(%rsp)
    10b8:      	cmpl	$0x0, (%rax)
    10bb:      	je	0x8da <kprobe_unwind_php+0x8da>
    10c1:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    10cb:      	movq	%rax, 0x35(%rsp)
    10d0:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    10da:      	movq	%rax, 0x30(%rsp)
    10df:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    10e9:      	movq	%rax, 0x28(%rsp)
    10ee:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    10f8:      	movq	%rax, 0x20(%rsp)
    10fd:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    1107:      	movq	%rax, 0x18(%rsp)
    110c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1116:      	movq	%rax, 0x10(%rsp)
    111b:      	leaq	0x10(%rsp), %rdi
    1120:      	movl	$0x2d, %eax
    1125:      	movl	$0x6, %ecx
    112a:      	movzbl	0x11(%r15), %eax
    112f:      	addq	%rax, %r13
    1132:      	movl	$0x2d, %esi
    1137:      	jmp	0x206a <kprobe_unwind_php+0x206a>
    113c:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    1146:      	movq	%rax, 0x46(%rsp)
    114b:      	movabsq	$0x7830282061746164, %rax # imm = 0x7830282061746164
    1155:      	movq	%rax, 0x40(%rsp)
    115a:      	movabsq	$0x2065747563657865, %rax # imm = 0x2065747563657865
    1164:      	movq	%rax, 0x38(%rsp)
    1169:      	movabsq	$0x5f746e6572727563, %rax # imm = 0x5F746E6572727563
    1173:      	movq	%rax, 0x30(%rsp)
    1178:      	movabsq	$0x2e736c61626f6c67, %rax # imm = 0x2E736C61626F6C67
    1182:      	movq	%rax, 0x28(%rsp)
    1187:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    1191:      	movq	%rax, 0x20(%rsp)
    1196:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    11a0:      	movq	%rax, 0x18(%rsp)
    11a5:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    11af:      	movq	%rax, 0x10(%rsp)
    11b4:      	leaq	0x10(%rsp), %rdi
    11b9:      	movl	$0x3e, %eax
    11be:      	movl	$0x6, %ecx
    11c3:      	movq	(%r15), %rdx
    11c6:      	movl	$0x3e, %esi
    11cb:      	xorl	%eax, %eax
    11cd:      	callq	*%rcx
    11cf:      	jmp	0x155 <kprobe_unwind_php+0x155>
    11d4:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    11de:      	movq	%rax, 0x36(%rsp)
    11e3:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    11ed:      	movq	%rax, 0x30(%rsp)
    11f2:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    11fc:      	movq	%rax, 0x28(%rsp)
    1201:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    120b:      	movq	%rax, 0x20(%rsp)
    1210:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    121a:      	movq	%rax, 0x18(%rsp)
    121f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1229:      	movq	%rax, 0x10(%rsp)
    122e:      	leaq	0x10(%rsp), %rdi
    1233:      	movl	$0x2e, %eax
    1238:      	movl	$0x6, %ecx
    123d:      	movl	0x58(%rsp), %edx
    1241:      	movl	$0x2e, %esi
    1246:      	xorl	%eax, %eax
    1248:      	callq	*%rcx
    124a:      	movl	$0x5, %r12d
    1250:      	cmpl	$0x23, %r13d
    1254:      	je	0x2e6 <kprobe_unwind_php+0x2e6>
    125a:      	jmp	0x85e3 <kprobe_unwind_php+0x85e3>
    125f:      	movl	0xc(%rsp), %ecx
    1263:      	movl	0x54(%rsp), %r13d
    1268:      	movq	(%rip), %rax            # 0x126f <kprobe_unwind_php+0x126f>
    126f:      	cmpl	$0x0, (%rax)
    1272:      	jne	0x2076 <kprobe_unwind_php+0x2076>
    1278:      	movl	0x2c0(%rbp), %eax
    127e:      	cmpq	$0x7e, %rax
    1282:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    1288:      	movl	%ecx, %ecx
    128a:      	shlq	$0x20, %r13
    128e:      	orq	%r13, %rcx
    1291:      	movq	0x58(%rsp), %rdx
    1296:      	leal	0x1(%rax), %esi
    1299:      	movl	%esi, 0x2c0(%rbp)
    129f:      	leaq	(%rax,%rax,2), %rax
    12a3:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    12ab:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    12b3:      	movl	0x7c(%rsp), %ecx
    12b7:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    12be:      	jmp	0xa18 <kprobe_unwind_php+0xa18>
    12c3:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    12cd:      	movq	%rax, 0x48(%rsp)
    12d2:      	movabsq	$0x2820617461645f65, %rax # imm = 0x2820617461645F65
    12dc:      	movq	%rax, 0x40(%rsp)
    12e1:      	movabsq	$0x7475636578655f76, %rax # imm = 0x7475636578655F76
    12eb:      	movq	%rax, 0x38(%rsp)
    12f0:      	movabsq	$0x6572703e2d617461, %rax # imm = 0x6572703E2D617461
    12fa:      	movq	%rax, 0x30(%rsp)
    12ff:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    1309:      	movq	%rax, 0x28(%rsp)
    130e:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    1318:      	movq	%rax, 0x20(%rsp)
    131d:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    1327:      	movq	%rax, 0x18(%rsp)
    132c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1336:      	movq	%rax, 0x10(%rsp)
    133b:      	leaq	0x10(%rsp), %rdi
    1340:      	movl	$0x40, %eax
    1345:      	movl	$0x6, %ecx
    134a:      	movq	0x70(%rsp), %rdx
    134f:      	movl	$0x40, %esi
    1354:      	xorl	%eax, %eax
    1356:      	callq	*%rcx
    1358:      	jmp	0x328 <kprobe_unwind_php+0x328>
    135d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1367:      	movq	%rax, 0x36(%rsp)
    136c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1376:      	movq	%rax, 0x30(%rsp)
    137b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1385:      	movq	%rax, 0x28(%rsp)
    138a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1394:      	movq	%rax, 0x20(%rsp)
    1399:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    13a3:      	movq	%rax, 0x18(%rsp)
    13a8:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    13b2:      	movq	%rax, 0x10(%rsp)
    13b7:      	leaq	0x10(%rsp), %rdi
    13bc:      	movl	$0x2e, %eax
    13c1:      	movl	$0x6, %ecx
    13c6:      	movl	0x58(%rsp), %edx
    13ca:      	movl	$0x2e, %esi
    13cf:      	xorl	%eax, %eax
    13d1:      	callq	*%rcx
    13d3:      	jmp	0x35f <kprobe_unwind_php+0x35f>
    13d8:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    13e2:      	movq	%rax, 0x38(%rsp)
    13e7:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    13f1:      	movq	%rax, 0x30(%rsp)
    13f6:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    1400:      	movq	%rax, 0x28(%rsp)
    1405:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    140f:      	movq	%rax, 0x20(%rsp)
    1414:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    141e:      	movq	%rax, 0x18(%rsp)
    1423:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    142d:      	movq	%rax, 0x10(%rsp)
    1432:      	movb	$0x0, 0x40(%rsp)
    1437:      	leaq	0x10(%rsp), %rdi
    143c:      	movl	$0x31, %eax
    1441:      	movl	$0x6, %ecx
    1446:      	movq	0x58(%rsp), %rdx
    144b:      	movl	$0x31, %esi
    1450:      	xorl	%eax, %eax
    1452:      	callq	*%rcx
    1454:      	jmp	0x2bb <kprobe_unwind_php+0x2bb>
    1459:      	movzbl	0x15(%r15), %eax
    145e:      	addq	0x68(%rsp), %rax
    1463:      	leaq	0xc(%rsp), %rdi
    1468:      	movl	$0x4, %ecx
    146d:      	movl	$0x70, %r8d
    1473:      	movzbl	0x15(%r15), %edx
    1478:      	addq	0x68(%rsp), %rdx
    147d:      	movl	$0x4, %esi
    1482:      	callq	*%r8
    1485:      	testq	%rax, %rax
    1488:      	je	0x16e6 <kprobe_unwind_php+0x16e6>
    148e:      	movq	(%rip), %rax            # 0x1495 <kprobe_unwind_php+0x1495>
    1495:      	movl	$0x27, 0x4(%rsp)
    149d:      	cmpl	$0x0, (%rax)
    14a0:      	je	0x8da <kprobe_unwind_php+0x8da>
    14a6:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    14b0:      	movq	%rax, 0x40(%rsp)
    14b5:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    14bf:      	movq	%rax, 0x38(%rsp)
    14c4:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    14ce:      	movq	%rax, 0x30(%rsp)
    14d3:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    14dd:      	movq	%rax, 0x28(%rsp)
    14e2:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    14ec:      	movq	%rax, 0x20(%rsp)
    14f1:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    14fb:      	movq	%rax, 0x18(%rsp)
    1500:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    150a:      	movq	%rax, 0x10(%rsp)
    150f:      	movb	$0x0, 0x48(%rsp)
    1514:      	leaq	0x10(%rsp), %rdi
    1519:      	movl	$0x39, %eax
    151e:      	movl	$0x6, %ecx
    1523:      	movzbl	0x15(%r15), %edx
    1528:      	addq	0x68(%rsp), %rdx
    152d:      	movl	$0x39, %esi
    1532:      	jmp	0x206d <kprobe_unwind_php+0x206d>
    1537:      	movq	0x58(%rsp), %rax
    153c:      	testq	%rax, %rax
    153f:      	je	0x17b1 <kprobe_unwind_php+0x17b1>
    1545:      	movzbl	0x14(%r15), %ecx
    154a:      	addq	%rcx, %rax
    154d:      	leaq	0xb(%rsp), %rdi
    1552:      	movl	$0x1, %ecx
    1557:      	movl	$0x70, %r8d
    155d:      	movzbl	0x14(%r15), %edx
    1562:      	addq	0x58(%rsp), %rdx
    1567:      	movl	$0x1, %esi
    156c:      	callq	*%r8
    156f:      	testq	%rax, %rax
    1572:      	je	0x193c <kprobe_unwind_php+0x193c>
    1578:      	movq	(%rip), %rax            # 0x157f <kprobe_unwind_php+0x157f>
    157f:      	cmpl	$0x0, (%rax)
    1582:      	jne	0x29d2 <kprobe_unwind_php+0x29d2>
    1588:      	movl	$0x26, 0x4(%rsp)
    1590:      	jmp	0xdd5 <kprobe_unwind_php+0xdd5>
    1595:      	movq	(%rip), %rax            # 0x159c <kprobe_unwind_php+0x159c>
    159c:      	cmpl	$0x0, (%rax)
    159f:      	jne	0x28e2 <kprobe_unwind_php+0x28e2>
    15a5:      	cmpl	$0x23, 0x4(%rsp)
    15aa:      	jne	0x85e3 <kprobe_unwind_php+0x85e3>
    15b0:      	movzbl	0x12(%r15), %eax
    15b5:      	addq	0x70(%rsp), %rax
    15ba:      	leaq	0x70(%rsp), %rdi
    15bf:      	movl	$0x8, %ecx
    15c4:      	movl	$0x70, %r8d
    15ca:      	movzbl	0x12(%r15), %edx
    15cf:      	addq	0x70(%rsp), %rdx
    15d4:      	movl	$0x8, %esi
    15d9:      	callq	*%r8
    15dc:      	testq	%rax, %rax
    15df:      	jne	0x317 <kprobe_unwind_php+0x317>
    15e5:      	movq	0x70(%rsp), %r13
    15ea:      	testq	%r13, %r13
    15ed:      	je	0x83ba <kprobe_unwind_php+0x83ba>
    15f3:      	testb	$0x2, 0x56(%rsp)
    15f8:      	jne	0x83ba <kprobe_unwind_php+0x83ba>
    15fe:      	movzbl	0x10(%r15), %eax
    1603:      	addq	%r13, %rax
    1606:      	leaq	0x58(%rsp), %rdi
    160b:      	movl	$0x8, %ecx
    1610:      	movl	$0x70, %r8d
    1616:      	movzbl	0x10(%r15), %edx
    161b:      	addq	%r13, %rdx
    161e:      	movl	$0x8, %esi
    1623:      	callq	*%r8
    1626:      	testq	%rax, %rax
    1629:      	je	0x1d7a <kprobe_unwind_php+0x1d7a>
    162f:      	movq	(%rip), %rax            # 0x1636 <kprobe_unwind_php+0x1636>
    1636:      	movl	$0x25, 0x4(%rsp)
    163e:      	cmpl	$0x0, (%rax)
    1641:      	jne	0x2da3 <kprobe_unwind_php+0x2da3>
    1647:      	movl	0x4(%rsp), %eax
    164b:      	movl	%eax, 0x58(%rsp)
    164f:      	movq	(%rip), %rdi            # 0x1656 <kprobe_unwind_php+0x1656>
    1656:      	leaq	0x58(%rsp), %rsi
    165b:      	movl	$0x1, %eax
    1660:      	callq	*%rax
    1662:      	testq	%rax, %rax
    1665:      	je	0x1dd8 <kprobe_unwind_php+0x1dd8>
    166b:      	incq	(%rax)
    166e:      	cmpl	$0x23, 0x4(%rsp)
    1673:      	je	0x1df3 <kprobe_unwind_php+0x1df3>
    1679:      	jmp	0x85e3 <kprobe_unwind_php+0x85e3>
    167e:      	movabsq	$0xa6c6c75662073, %rax  # imm = 0xA6C6C75662073
    1688:      	movq	%rax, 0x2d(%rsp)
    168d:      	movabsq	$0x66207369206b6361, %rax # imm = 0x66207369206B6361
    1697:      	movq	%rax, 0x28(%rsp)
    169c:      	movabsq	$0x7473203a656d6172, %rax # imm = 0x7473203A656D6172
    16a6:      	movq	%rax, 0x20(%rsp)
    16ab:      	movabsq	$0x662068737570206f, %rax # imm = 0x662068737570206F
    16b5:      	movq	%rax, 0x18(%rsp)
    16ba:      	movabsq	$0x7420656c62616e75, %rax # imm = 0x7420656C62616E75
    16c4:      	movq	%rax, 0x10(%rsp)
    16c9:      	leaq	0x10(%rsp), %rdi
    16ce:      	movl	$0x25, %eax
    16d3:      	movl	$0x6, %ecx
    16d8:      	movl	$0x25, %esi
    16dd:      	xorl	%eax, %eax
    16df:      	callq	*%rcx
    16e1:      	jmp	0x41f <kprobe_unwind_php+0x41f>
    16e6:      	movzbl	0x13(%r15), %eax
    16eb:      	addq	%r13, %rax
    16ee:      	leaq	0x54(%rsp), %rdi
    16f3:      	movl	$0x4, %ecx
    16f8:      	movl	$0x70, %r8d
    16fe:      	movzbl	0x13(%r15), %edx
    1703:      	addq	%r13, %rdx
    1706:      	movl	$0x4, %esi
    170b:      	callq	*%r8
    170e:      	testq	%rax, %rax
    1711:      	je	0x1aa8 <kprobe_unwind_php+0x1aa8>
    1717:      	movq	(%rip), %rax            # 0x171e <kprobe_unwind_php+0x171e>
    171e:      	movl	$0x25, 0x4(%rsp)
    1726:      	cmpl	$0x0, (%rax)
    1729:      	je	0x8da <kprobe_unwind_php+0x8da>
    172f:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    1739:      	movq	%rax, 0x3d(%rsp)
    173e:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    1748:      	movq	%rax, 0x38(%rsp)
    174d:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    1757:      	movq	%rax, 0x30(%rsp)
    175c:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    1766:      	movq	%rax, 0x28(%rsp)
    176b:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    1775:      	movq	%rax, 0x20(%rsp)
    177a:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    1784:      	movq	%rax, 0x18(%rsp)
    1789:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1793:      	movq	%rax, 0x10(%rsp)
    1798:      	leaq	0x10(%rsp), %rdi
    179d:      	movl	$0x35, %eax
    17a2:      	movl	$0x6, %ecx
    17a7:      	movl	$0x35, %esi
    17ac:      	jmp	0x206a <kprobe_unwind_php+0x206a>
    17b1:      	movl	0x2c0(%rbp), %eax
    17b7:      	cmpq	$0x7e, %rax
    17bb:      	ja	0x40e <kprobe_unwind_php+0x40e>
    17c1:      	leal	0x1(%rax), %ecx
    17c4:      	movl	%ecx, 0x2c0(%rbp)
    17ca:      	leaq	(%rax,%rax,2), %rax
    17ce:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    17da:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    17e6:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    17ee:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    17f9:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    1804:      	movl	$0x23, 0x4(%rsp)
    180c:      	jmp	0xdd5 <kprobe_unwind_php+0xdd5>
    1811:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    181b:      	movq	%rax, 0x38(%rsp)
    1820:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    182a:      	movq	%rax, 0x30(%rsp)
    182f:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    1839:      	movq	%rax, 0x28(%rsp)
    183e:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    1848:      	movq	%rax, 0x20(%rsp)
    184d:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    1857:      	movq	%rax, 0x18(%rsp)
    185c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1866:      	movq	%rax, 0x10(%rsp)
    186b:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    1873:      	leaq	0x10(%rsp), %rdi
    1878:      	movl	$0x33, %eax
    187d:      	movl	$0x6, %ecx
    1882:      	movzbl	0x10(%r15), %eax
    1887:      	addq	%rax, %r13
    188a:      	movl	$0x33, %esi
    188f:      	movq	%r13, %rdx
    1892:      	xorl	%eax, %eax
    1894:      	callq	*%rcx
    1896:      	movl	$0x25, %ecx
    189b:      	jmp	0x3c9 <kprobe_unwind_php+0x3c9>
    18a0:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    18aa:      	movq	%rax, 0x1e(%rsp)
    18af:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    18b9:      	movq	%rax, 0x18(%rsp)
    18be:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    18c8:      	movq	%rax, 0x10(%rsp)
    18cd:      	leaq	0x10(%rsp), %rdi
    18d2:      	movl	$0x16, %eax
    18d7:      	movl	$0x6, %r8d
    18dd:      	movq	0x58(%rsp), %rdx
    18e2:      	movl	0xc(%rsp), %ecx
    18e6:      	movl	$0x16, %esi
    18eb:      	xorl	%eax, %eax
    18ed:      	callq	*%r8
    18f0:      	movl	0x2c0(%rbp), %eax
    18f6:      	cmpq	$0x7f, %rax
    18fa:      	jae	0xb47 <kprobe_unwind_php+0xb47>
    1900:      	movl	%r13d, %ecx
    1903:      	shlq	$0x20, %r12
    1907:      	orq	%r12, %rcx
    190a:      	movq	0x58(%rsp), %rdx
    190f:      	leal	0x1(%rax), %esi
    1912:      	movl	%esi, 0x2c0(%rbp)
    1918:      	leaq	(%rax,%rax,2), %rax
    191c:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    1924:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    192c:      	movl	0x7c(%rsp), %ecx
    1930:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    1937:      	jmp	0x642 <kprobe_unwind_php+0x642>
    193c:      	movl	$0x0, 0xc(%rsp)
    1944:      	movzbl	0xb(%rsp), %eax
    1949:      	cmpl	$0x4, %eax
    194c:      	je	0x195f <kprobe_unwind_php+0x195f>
    194e:      	movl	$0x0, 0x4(%rsp)
    1956:      	cmpl	$0x2, %eax
    1959:      	jne	0x2257 <kprobe_unwind_php+0x2257>
    195f:      	movzbl	0x11(%r15), %eax
    1964:      	addq	%r13, %rax
    1967:      	leaq	0x68(%rsp), %rdi
    196c:      	movl	$0x8, %ecx
    1971:      	movl	$0x70, %r8d
    1977:      	movzbl	0x11(%r15), %edx
    197c:      	addq	%r13, %rdx
    197f:      	movl	$0x8, %esi
    1984:      	callq	*%r8
    1987:      	testq	%rax, %rax
    198a:      	je	0x1c17 <kprobe_unwind_php+0x1c17>
    1990:      	movq	(%rip), %rax            # 0x1997 <kprobe_unwind_php+0x1997>
    1997:      	movl	$0x25, 0x4(%rsp)
    199f:      	cmpl	$0x0, (%rax)
    19a2:      	je	0xdd5 <kprobe_unwind_php+0xdd5>
    19a8:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    19b2:      	movq	%rax, 0x35(%rsp)
    19b7:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    19c1:      	movq	%rax, 0x30(%rsp)
    19c6:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    19d0:      	movq	%rax, 0x28(%rsp)
    19d5:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    19df:      	movq	%rax, 0x20(%rsp)
    19e4:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    19ee:      	movq	%rax, 0x18(%rsp)
    19f3:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    19fd:      	movq	%rax, 0x10(%rsp)
    1a02:      	leaq	0x10(%rsp), %rdi
    1a07:      	movl	$0x2d, %eax
    1a0c:      	movl	$0x6, %ecx
    1a11:      	movzbl	0x11(%r15), %eax
    1a16:      	addq	%rax, %r13
    1a19:      	movl	$0x2d, %esi
    1a1e:      	jmp	0x278a <kprobe_unwind_php+0x278a>
    1a23:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1a2d:      	movq	%rax, 0x36(%rsp)
    1a32:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1a3c:      	movq	%rax, 0x30(%rsp)
    1a41:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1a4b:      	movq	%rax, 0x28(%rsp)
    1a50:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1a5a:      	movq	%rax, 0x20(%rsp)
    1a5f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1a69:      	movq	%rax, 0x18(%rsp)
    1a6e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1a78:      	movq	%rax, 0x10(%rsp)
    1a7d:      	leaq	0x10(%rsp), %rdi
    1a82:      	movl	$0x2e, %eax
    1a87:      	movl	$0x6, %ecx
    1a8c:      	movl	0x58(%rsp), %edx
    1a90:      	movl	$0x2e, %esi
    1a95:      	xorl	%eax, %eax
    1a97:      	callq	*%rcx
    1a99:      	cmpl	$0x23, %r13d
    1a9d:      	je	0x843 <kprobe_unwind_php+0x843>
    1aa3:      	jmp	0x85e3 <kprobe_unwind_php+0x85e3>
    1aa8:      	movl	0xc(%rsp), %eax
    1aac:      	movl	%eax, 0x4(%rsp)
    1ab0:      	movl	0x54(%rsp), %r13d
    1ab5:      	movq	(%rip), %rax            # 0x1abc <kprobe_unwind_php+0x1abc>
    1abc:      	cmpl	$0x0, (%rax)
    1abf:      	jne	0x2796 <kprobe_unwind_php+0x2796>
    1ac5:      	movl	0x2c0(%rbp), %eax
    1acb:      	cmpq	$0x7e, %rax
    1acf:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    1ad5:      	movl	0x4(%rsp), %ecx
    1ad9:      	shlq	$0x20, %r13
    1add:      	orq	%r13, %rcx
    1ae0:      	movq	0x58(%rsp), %rdx
    1ae5:      	leal	0x1(%rax), %esi
    1ae8:      	movl	%esi, 0x2c0(%rbp)
    1aee:      	leaq	(%rax,%rax,2), %rax
    1af2:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    1afa:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    1b02:      	movl	0x7c(%rsp), %ecx
    1b06:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    1b0d:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    1b18:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    1b23:      	movl	$0x23, %r13d
    1b29:      	jmp	0x8df <kprobe_unwind_php+0x8df>
    1b2e:      	movabsq	$0xa6c6c75662073, %rax  # imm = 0xA6C6C75662073
    1b38:      	movq	%rax, 0x2d(%rsp)
    1b3d:      	movabsq	$0x66207369206b6361, %rax # imm = 0x66207369206B6361
    1b47:      	movq	%rax, 0x28(%rsp)
    1b4c:      	movabsq	$0x7473203a656d6172, %rax # imm = 0x7473203A656D6172
    1b56:      	movq	%rax, 0x20(%rsp)
    1b5b:      	movabsq	$0x662068737570206f, %rax # imm = 0x662068737570206F
    1b65:      	movq	%rax, 0x18(%rsp)
    1b6a:      	movabsq	$0x7420656c62616e75, %rax # imm = 0x7420656C62616E75
    1b74:      	movq	%rax, 0x10(%rsp)
    1b79:      	leaq	0x10(%rsp), %rdi
    1b7e:      	movl	$0x25, %eax
    1b83:      	movl	$0x6, %ecx
    1b88:      	movl	$0x25, %esi
    1b8d:      	xorl	%eax, %eax
    1b8f:      	callq	*%rcx
    1b91:      	jmp	0xb58 <kprobe_unwind_php+0xb58>
    1b96:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    1ba0:      	movq	%rax, 0x38(%rsp)
    1ba5:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    1baf:      	movq	%rax, 0x30(%rsp)
    1bb4:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    1bbe:      	movq	%rax, 0x28(%rsp)
    1bc3:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    1bcd:      	movq	%rax, 0x20(%rsp)
    1bd2:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    1bdc:      	movq	%rax, 0x18(%rsp)
    1be1:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1beb:      	movq	%rax, 0x10(%rsp)
    1bf0:      	movb	$0x0, 0x40(%rsp)
    1bf5:      	leaq	0x10(%rsp), %rdi
    1bfa:      	movl	$0x31, %eax
    1bff:      	movl	$0x6, %ecx
    1c04:      	movq	0x58(%rsp), %rdx
    1c09:      	movl	$0x31, %esi
    1c0e:      	xorl	%eax, %eax
    1c10:      	callq	*%rcx
    1c12:      	jmp	0x81f <kprobe_unwind_php+0x81f>
    1c17:      	movzbl	0x15(%r15), %eax
    1c1c:      	addq	0x68(%rsp), %rax
    1c21:      	leaq	0xc(%rsp), %rdi
    1c26:      	movl	$0x4, %ecx
    1c2b:      	movl	$0x70, %r8d
    1c31:      	movzbl	0x15(%r15), %edx
    1c36:      	addq	0x68(%rsp), %rdx
    1c3b:      	movl	$0x4, %esi
    1c40:      	callq	*%r8
    1c43:      	testq	%rax, %rax
    1c46:      	je	0x1ec1 <kprobe_unwind_php+0x1ec1>
    1c4c:      	movq	(%rip), %rax            # 0x1c53 <kprobe_unwind_php+0x1c53>
    1c53:      	movl	$0x27, 0x4(%rsp)
    1c5b:      	cmpl	$0x0, (%rax)
    1c5e:      	je	0xdd5 <kprobe_unwind_php+0xdd5>
    1c64:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    1c6e:      	movq	%rax, 0x40(%rsp)
    1c73:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    1c7d:      	movq	%rax, 0x38(%rsp)
    1c82:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    1c8c:      	movq	%rax, 0x30(%rsp)
    1c91:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    1c9b:      	movq	%rax, 0x28(%rsp)
    1ca0:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    1caa:      	movq	%rax, 0x20(%rsp)
    1caf:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    1cb9:      	movq	%rax, 0x18(%rsp)
    1cbe:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1cc8:      	movq	%rax, 0x10(%rsp)
    1ccd:      	movb	$0x0, 0x48(%rsp)
    1cd2:      	leaq	0x10(%rsp), %rdi
    1cd7:      	movl	$0x39, %eax
    1cdc:      	movl	$0x6, %ecx
    1ce1:      	movzbl	0x15(%r15), %edx
    1ce6:      	addq	0x68(%rsp), %rdx
    1ceb:      	movl	$0x39, %esi
    1cf0:      	jmp	0x278d <kprobe_unwind_php+0x278d>
    1cf5:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1cff:      	movq	%rax, 0x36(%rsp)
    1d04:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1d0e:      	movq	%rax, 0x30(%rsp)
    1d13:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1d1d:      	movq	%rax, 0x28(%rsp)
    1d22:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1d2c:      	movq	%rax, 0x20(%rsp)
    1d31:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1d3b:      	movq	%rax, 0x18(%rsp)
    1d40:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1d4a:      	movq	%rax, 0x10(%rsp)
    1d4f:      	leaq	0x10(%rsp), %rdi
    1d54:      	movl	$0x2e, %eax
    1d59:      	movl	$0x6, %ecx
    1d5e:      	movl	0x68(%rsp), %edx
    1d62:      	movl	$0x2e, %esi
    1d67:      	xorl	%eax, %eax
    1d69:      	callq	*%rcx
    1d6b:      	cmpl	$0x0, (%r15)
    1d6f:      	je	0xbd9 <kprobe_unwind_php+0xbd9>
    1d75:      	jmp	0xb81 <kprobe_unwind_php+0xb81>
    1d7a:      	movq	0x58(%rsp), %rax
    1d7f:      	testq	%rax, %rax
    1d82:      	je	0x1f8c <kprobe_unwind_php+0x1f8c>
    1d88:      	movzbl	0x14(%r15), %ecx
    1d8d:      	addq	%rcx, %rax
    1d90:      	leaq	0xb(%rsp), %rdi
    1d95:      	movl	$0x1, %ecx
    1d9a:      	movl	$0x70, %r8d
    1da0:      	movzbl	0x14(%r15), %edx
    1da5:      	addq	0x58(%rsp), %rdx
    1daa:      	movl	$0x1, %esi
    1daf:      	callq	*%r8
    1db2:      	testq	%rax, %rax
    1db5:      	je	0x20e3 <kprobe_unwind_php+0x20e3>
    1dbb:      	movq	(%rip), %rax            # 0x1dc2 <kprobe_unwind_php+0x1dc2>
    1dc2:      	cmpl	$0x0, (%rax)
    1dc5:      	jne	0x3069 <kprobe_unwind_php+0x3069>
    1dcb:      	movl	$0x26, 0x4(%rsp)
    1dd3:      	jmp	0x1647 <kprobe_unwind_php+0x1647>
    1dd8:      	movq	(%rip), %rax            # 0x1ddf <kprobe_unwind_php+0x1ddf>
    1ddf:      	cmpl	$0x0, (%rax)
    1de2:      	jne	0x2f79 <kprobe_unwind_php+0x2f79>
    1de8:      	cmpl	$0x23, 0x4(%rsp)
    1ded:      	jne	0x85e3 <kprobe_unwind_php+0x85e3>
    1df3:      	movzbl	0x12(%r15), %eax
    1df8:      	addq	0x70(%rsp), %rax
    1dfd:      	leaq	0x70(%rsp), %rdi
    1e02:      	movl	$0x8, %ecx
    1e07:      	movl	$0x70, %r8d
    1e0d:      	movzbl	0x12(%r15), %edx
    1e12:      	addq	0x70(%rsp), %rdx
    1e17:      	movl	$0x8, %esi
    1e1c:      	callq	*%r8
    1e1f:      	testq	%rax, %rax
    1e22:      	jne	0x317 <kprobe_unwind_php+0x317>
    1e28:      	movq	0x70(%rsp), %r13
    1e2d:      	testq	%r13, %r13
    1e30:      	je	0x83ba <kprobe_unwind_php+0x83ba>
    1e36:      	testb	$0x2, 0x56(%rsp)
    1e3b:      	jne	0x83ba <kprobe_unwind_php+0x83ba>
    1e41:      	movzbl	0x10(%r15), %eax
    1e46:      	addq	%r13, %rax
    1e49:      	leaq	0x58(%rsp), %rdi
    1e4e:      	movl	$0x8, %ecx
    1e53:      	movl	$0x70, %r8d
    1e59:      	movzbl	0x10(%r15), %edx
    1e5e:      	addq	%r13, %rdx
    1e61:      	movl	$0x8, %esi
    1e66:      	callq	*%r8
    1e69:      	testq	%rax, %rax
    1e6c:      	je	0x2418 <kprobe_unwind_php+0x2418>
    1e72:      	movq	(%rip), %rax            # 0x1e79 <kprobe_unwind_php+0x1e79>
    1e79:      	movl	$0x25, 0x4(%rsp)
    1e81:      	cmpl	$0x0, (%rax)
    1e84:      	jne	0x343a <kprobe_unwind_php+0x343a>
    1e8a:      	movl	0x4(%rsp), %eax
    1e8e:      	movl	%eax, 0x58(%rsp)
    1e92:      	movq	(%rip), %rdi            # 0x1e99 <kprobe_unwind_php+0x1e99>
    1e99:      	leaq	0x58(%rsp), %rsi
    1e9e:      	movl	$0x1, %eax
    1ea3:      	callq	*%rax
    1ea5:      	testq	%rax, %rax
    1ea8:      	je	0x2476 <kprobe_unwind_php+0x2476>
    1eae:      	incq	(%rax)
    1eb1:      	cmpl	$0x23, 0x4(%rsp)
    1eb6:      	je	0x2491 <kprobe_unwind_php+0x2491>
    1ebc:      	jmp	0x85e3 <kprobe_unwind_php+0x85e3>
    1ec1:      	movzbl	0x13(%r15), %eax
    1ec6:      	addq	%r13, %rax
    1ec9:      	leaq	0x54(%rsp), %rdi
    1ece:      	movl	$0x4, %ecx
    1ed3:      	movl	$0x70, %r8d
    1ed9:      	movzbl	0x13(%r15), %edx
    1ede:      	addq	%r13, %rdx
    1ee1:      	movl	$0x4, %esi
    1ee6:      	callq	*%r8
    1ee9:      	testq	%rax, %rax
    1eec:      	je	0x224f <kprobe_unwind_php+0x224f>
    1ef2:      	movq	(%rip), %rax            # 0x1ef9 <kprobe_unwind_php+0x1ef9>
    1ef9:      	movl	$0x25, 0x4(%rsp)
    1f01:      	cmpl	$0x0, (%rax)
    1f04:      	je	0xdd5 <kprobe_unwind_php+0xdd5>
    1f0a:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    1f14:      	movq	%rax, 0x3d(%rsp)
    1f19:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    1f23:      	movq	%rax, 0x38(%rsp)
    1f28:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    1f32:      	movq	%rax, 0x30(%rsp)
    1f37:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    1f41:      	movq	%rax, 0x28(%rsp)
    1f46:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    1f50:      	movq	%rax, 0x20(%rsp)
    1f55:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    1f5f:      	movq	%rax, 0x18(%rsp)
    1f64:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1f6e:      	movq	%rax, 0x10(%rsp)
    1f73:      	leaq	0x10(%rsp), %rdi
    1f78:      	movl	$0x35, %eax
    1f7d:      	movl	$0x6, %ecx
    1f82:      	movl	$0x35, %esi
    1f87:      	jmp	0x278a <kprobe_unwind_php+0x278a>
    1f8c:      	movl	0x2c0(%rbp), %eax
    1f92:      	cmpq	$0x7e, %rax
    1f96:      	ja	0x40e <kprobe_unwind_php+0x40e>
    1f9c:      	leal	0x1(%rax), %ecx
    1f9f:      	movl	%ecx, 0x2c0(%rbp)
    1fa5:      	leaq	(%rax,%rax,2), %rax
    1fa9:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    1fb5:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    1fc1:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    1fc9:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    1fd4:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    1fdf:      	movl	$0x23, 0x4(%rsp)
    1fe7:      	jmp	0x1647 <kprobe_unwind_php+0x1647>
    1fec:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    1ff6:      	movq	%rax, 0x38(%rsp)
    1ffb:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    2005:      	movq	%rax, 0x30(%rsp)
    200a:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    2014:      	movq	%rax, 0x28(%rsp)
    2019:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    2023:      	movq	%rax, 0x20(%rsp)
    2028:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    2032:      	movq	%rax, 0x18(%rsp)
    2037:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2041:      	movq	%rax, 0x10(%rsp)
    2046:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    204e:      	leaq	0x10(%rsp), %rdi
    2053:      	movl	$0x33, %eax
    2058:      	movl	$0x6, %ecx
    205d:      	movzbl	0x10(%r15), %eax
    2062:      	addq	%rax, %r13
    2065:      	movl	$0x33, %esi
    206a:      	movq	%r13, %rdx
    206d:      	xorl	%eax, %eax
    206f:      	callq	*%rcx
    2071:      	jmp	0x8da <kprobe_unwind_php+0x8da>
    2076:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    2080:      	movq	%rax, 0x1e(%rsp)
    2085:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    208f:      	movq	%rax, 0x18(%rsp)
    2094:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    209e:      	movq	%rax, 0x10(%rsp)
    20a3:      	leaq	0x10(%rsp), %rdi
    20a8:      	movl	$0x16, %eax
    20ad:      	movl	$0x6, %r8d
    20b3:      	movq	0x58(%rsp), %rdx
    20b8:      	movl	%ecx, 0x4(%rsp)
    20bc:      	movl	0xc(%rsp), %ecx
    20c0:      	movl	$0x16, %esi
    20c5:      	xorl	%eax, %eax
    20c7:      	callq	*%r8
    20ca:      	movl	0x4(%rsp), %ecx
    20ce:      	movl	0x2c0(%rbp), %eax
    20d4:      	cmpq	$0x7e, %rax
    20d8:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    20de:      	jmp	0x1288 <kprobe_unwind_php+0x1288>
    20e3:      	movl	$0x0, 0xc(%rsp)
    20eb:      	movzbl	0xb(%rsp), %eax
    20f0:      	cmpl	$0x4, %eax
    20f3:      	je	0x2106 <kprobe_unwind_php+0x2106>
    20f5:      	movl	$0x0, 0x4(%rsp)
    20fd:      	cmpl	$0x2, %eax
    2100:      	jne	0x2970 <kprobe_unwind_php+0x2970>
    2106:      	movzbl	0x11(%r15), %eax
    210b:      	addq	%r13, %rax
    210e:      	leaq	0x68(%rsp), %rdi
    2113:      	movl	$0x8, %ecx
    2118:      	movl	$0x70, %r8d
    211e:      	movzbl	0x11(%r15), %edx
    2123:      	addq	%r13, %rdx
    2126:      	movl	$0x8, %esi
    212b:      	callq	*%r8
    212e:      	testq	%rax, %rax
    2131:      	je	0x233a <kprobe_unwind_php+0x233a>
    2137:      	movq	(%rip), %rax            # 0x213e <kprobe_unwind_php+0x213e>
    213e:      	movl	$0x25, 0x4(%rsp)
    2146:      	cmpl	$0x0, (%rax)
    2149:      	je	0x1647 <kprobe_unwind_php+0x1647>
    214f:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    2159:      	movq	%rax, 0x35(%rsp)
    215e:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    2168:      	movq	%rax, 0x30(%rsp)
    216d:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    2177:      	movq	%rax, 0x28(%rsp)
    217c:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    2186:      	movq	%rax, 0x20(%rsp)
    218b:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    2195:      	movq	%rax, 0x18(%rsp)
    219a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    21a4:      	movq	%rax, 0x10(%rsp)
    21a9:      	leaq	0x10(%rsp), %rdi
    21ae:      	movl	$0x2d, %eax
    21b3:      	movl	$0x6, %ecx
    21b8:      	movzbl	0x11(%r15), %eax
    21bd:      	addq	%rax, %r13
    21c0:      	movl	$0x2d, %esi
    21c5:      	jmp	0x2e21 <kprobe_unwind_php+0x2e21>
    21ca:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    21d4:      	movq	%rax, 0x36(%rsp)
    21d9:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    21e3:      	movq	%rax, 0x30(%rsp)
    21e8:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    21f2:      	movq	%rax, 0x28(%rsp)
    21f7:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2201:      	movq	%rax, 0x20(%rsp)
    2206:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2210:      	movq	%rax, 0x18(%rsp)
    2215:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    221f:      	movq	%rax, 0x10(%rsp)
    2224:      	leaq	0x10(%rsp), %rdi
    2229:      	movl	$0x2e, %eax
    222e:      	movl	$0x6, %ecx
    2233:      	movl	0x58(%rsp), %edx
    2237:      	movl	$0x2e, %esi
    223c:      	xorl	%eax, %eax
    223e:      	callq	*%rcx
    2240:      	cmpl	$0x23, %r13d
    2244:      	je	0xd3e <kprobe_unwind_php+0xd3e>
    224a:      	jmp	0x85e3 <kprobe_unwind_php+0x85e3>
    224f:      	movl	0xc(%rsp), %eax
    2253:      	movl	%eax, 0x4(%rsp)
    2257:      	movl	0x54(%rsp), %r13d
    225c:      	movq	(%rip), %rax            # 0x2263 <kprobe_unwind_php+0x2263>
    2263:      	cmpl	$0x0, (%rax)
    2266:      	jne	0x2e2d <kprobe_unwind_php+0x2e2d>
    226c:      	movl	0x2c0(%rbp), %eax
    2272:      	cmpq	$0x7e, %rax
    2276:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    227c:      	movl	0x4(%rsp), %ecx
    2280:      	shlq	$0x20, %r13
    2284:      	orq	%r13, %rcx
    2287:      	movq	0x58(%rsp), %rdx
    228c:      	leal	0x1(%rax), %esi
    228f:      	movl	%esi, 0x2c0(%rbp)
    2295:      	leaq	(%rax,%rax,2), %rax
    2299:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    22a1:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    22a9:      	movl	0x7c(%rsp), %ecx
    22ad:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    22b4:      	jmp	0x17ee <kprobe_unwind_php+0x17ee>
    22b9:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    22c3:      	movq	%rax, 0x38(%rsp)
    22c8:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    22d2:      	movq	%rax, 0x30(%rsp)
    22d7:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    22e1:      	movq	%rax, 0x28(%rsp)
    22e6:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    22f0:      	movq	%rax, 0x20(%rsp)
    22f5:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    22ff:      	movq	%rax, 0x18(%rsp)
    2304:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    230e:      	movq	%rax, 0x10(%rsp)
    2313:      	movb	$0x0, 0x40(%rsp)
    2318:      	leaq	0x10(%rsp), %rdi
    231d:      	movl	$0x31, %eax
    2322:      	movl	$0x6, %ecx
    2327:      	movq	0x58(%rsp), %rdx
    232c:      	movl	$0x31, %esi
    2331:      	xorl	%eax, %eax
    2333:      	callq	*%rcx
    2335:      	jmp	0xd19 <kprobe_unwind_php+0xd19>
    233a:      	movzbl	0x15(%r15), %eax
    233f:      	addq	0x68(%rsp), %rax
    2344:      	leaq	0xc(%rsp), %rdi
    2349:      	movl	$0x4, %ecx
    234e:      	movl	$0x70, %r8d
    2354:      	movzbl	0x15(%r15), %edx
    2359:      	addq	0x68(%rsp), %rdx
    235e:      	movl	$0x4, %esi
    2363:      	callq	*%r8
    2366:      	testq	%rax, %rax
    2369:      	je	0x25e1 <kprobe_unwind_php+0x25e1>
    236f:      	movq	(%rip), %rax            # 0x2376 <kprobe_unwind_php+0x2376>
    2376:      	movl	$0x27, 0x4(%rsp)
    237e:      	cmpl	$0x0, (%rax)
    2381:      	je	0x1647 <kprobe_unwind_php+0x1647>
    2387:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    2391:      	movq	%rax, 0x40(%rsp)
    2396:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    23a0:      	movq	%rax, 0x38(%rsp)
    23a5:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    23af:      	movq	%rax, 0x30(%rsp)
    23b4:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    23be:      	movq	%rax, 0x28(%rsp)
    23c3:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    23cd:      	movq	%rax, 0x20(%rsp)
    23d2:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    23dc:      	movq	%rax, 0x18(%rsp)
    23e1:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    23eb:      	movq	%rax, 0x10(%rsp)
    23f0:      	movb	$0x0, 0x48(%rsp)
    23f5:      	leaq	0x10(%rsp), %rdi
    23fa:      	movl	$0x39, %eax
    23ff:      	movl	$0x6, %ecx
    2404:      	movzbl	0x15(%r15), %edx
    2409:      	addq	0x68(%rsp), %rdx
    240e:      	movl	$0x39, %esi
    2413:      	jmp	0x2e24 <kprobe_unwind_php+0x2e24>
    2418:      	movq	0x58(%rsp), %rax
    241d:      	testq	%rax, %rax
    2420:      	je	0x26ac <kprobe_unwind_php+0x26ac>
    2426:      	movzbl	0x14(%r15), %ecx
    242b:      	addq	%rcx, %rax
    242e:      	leaq	0xb(%rsp), %rdi
    2433:      	movl	$0x1, %ecx
    2438:      	movl	$0x70, %r8d
    243e:      	movzbl	0x14(%r15), %edx
    2443:      	addq	0x58(%rsp), %rdx
    2448:      	movl	$0x1, %esi
    244d:      	callq	*%r8
    2450:      	testq	%rax, %rax
    2453:      	je	0x27fb <kprobe_unwind_php+0x27fb>
    2459:      	movq	(%rip), %rax            # 0x2460 <kprobe_unwind_php+0x2460>
    2460:      	cmpl	$0x0, (%rax)
    2463:      	jne	0x3700 <kprobe_unwind_php+0x3700>
    2469:      	movl	$0x26, 0x4(%rsp)
    2471:      	jmp	0x1e8a <kprobe_unwind_php+0x1e8a>
    2476:      	movq	(%rip), %rax            # 0x247d <kprobe_unwind_php+0x247d>
    247d:      	cmpl	$0x0, (%rax)
    2480:      	jne	0x3610 <kprobe_unwind_php+0x3610>
    2486:      	cmpl	$0x23, 0x4(%rsp)
    248b:      	jne	0x85e3 <kprobe_unwind_php+0x85e3>
    2491:      	movzbl	0x12(%r15), %eax
    2496:      	addq	0x70(%rsp), %rax
    249b:      	leaq	0x70(%rsp), %rdi
    24a0:      	movl	$0x8, %ecx
    24a5:      	movl	$0x70, %r8d
    24ab:      	movzbl	0x12(%r15), %edx
    24b0:      	addq	0x70(%rsp), %rdx
    24b5:      	movl	$0x8, %esi
    24ba:      	callq	*%r8
    24bd:      	testq	%rax, %rax
    24c0:      	jne	0x317 <kprobe_unwind_php+0x317>
    24c6:      	movq	0x70(%rsp), %r13
    24cb:      	testq	%r13, %r13
    24ce:      	je	0x83ba <kprobe_unwind_php+0x83ba>
    24d4:      	testb	$0x2, 0x56(%rsp)
    24d9:      	jne	0x83ba <kprobe_unwind_php+0x83ba>
    24df:      	movzbl	0x10(%r15), %eax
    24e4:      	addq	%r13, %rax
    24e7:      	leaq	0x58(%rsp), %rdi
    24ec:      	movl	$0x8, %ecx
    24f1:      	movl	$0x70, %r8d
    24f7:      	movzbl	0x10(%r15), %edx
    24fc:      	addq	%r13, %rdx
    24ff:      	movl	$0x8, %esi
    2504:      	callq	*%r8
    2507:      	testq	%rax, %rax
    250a:      	je	0x2b31 <kprobe_unwind_php+0x2b31>
    2510:      	movq	(%rip), %rax            # 0x2517 <kprobe_unwind_php+0x2517>
    2517:      	movl	$0x25, 0x4(%rsp)
    251f:      	cmpl	$0x0, (%rax)
    2522:      	jne	0x3ad1 <kprobe_unwind_php+0x3ad1>
    2528:      	movl	0x4(%rsp), %eax
    252c:      	movl	%eax, 0x58(%rsp)
    2530:      	movq	(%rip), %rdi            # 0x2537 <kprobe_unwind_php+0x2537>
    2537:      	leaq	0x58(%rsp), %rsi
    253c:      	movl	$0x1, %eax
    2541:      	callq	*%rax
    2543:      	testq	%rax, %rax
    2546:      	je	0x2b8f <kprobe_unwind_php+0x2b8f>
    254c:      	incq	(%rax)
    254f:      	cmpl	$0x23, 0x4(%rsp)
    2554:      	je	0x2baa <kprobe_unwind_php+0x2baa>
    255a:      	jmp	0x85e3 <kprobe_unwind_php+0x85e3>
    255f:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    2569:      	movq	%rax, 0x3d(%rsp)
    256e:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    2578:      	movq	%rax, 0x38(%rsp)
    257d:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    2587:      	movq	%rax, 0x30(%rsp)
    258c:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    2596:      	movq	%rax, 0x28(%rsp)
    259b:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    25a5:      	movq	%rax, 0x20(%rsp)
    25aa:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    25b4:      	movq	%rax, 0x18(%rsp)
    25b9:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    25c3:      	movq	%rax, 0x10(%rsp)
    25c8:      	leaq	0x10(%rsp), %rdi
    25cd:      	movl	$0x35, %eax
    25d2:      	movl	$0x6, %ecx
    25d7:      	movl	$0x35, %esi
    25dc:      	jmp	0xb11 <kprobe_unwind_php+0xb11>
    25e1:      	movzbl	0x13(%r15), %eax
    25e6:      	addq	%r13, %rax
    25e9:      	leaq	0x54(%rsp), %rdi
    25ee:      	movl	$0x4, %ecx
    25f3:      	movl	$0x70, %r8d
    25f9:      	movzbl	0x13(%r15), %edx
    25fe:      	addq	%r13, %rdx
    2601:      	movl	$0x4, %esi
    2606:      	callq	*%r8
    2609:      	testq	%rax, %rax
    260c:      	je	0x2968 <kprobe_unwind_php+0x2968>
    2612:      	movq	(%rip), %rax            # 0x2619 <kprobe_unwind_php+0x2619>
    2619:      	movl	$0x25, 0x4(%rsp)
    2621:      	cmpl	$0x0, (%rax)
    2624:      	je	0x1647 <kprobe_unwind_php+0x1647>
    262a:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    2634:      	movq	%rax, 0x3d(%rsp)
    2639:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    2643:      	movq	%rax, 0x38(%rsp)
    2648:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    2652:      	movq	%rax, 0x30(%rsp)
    2657:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    2661:      	movq	%rax, 0x28(%rsp)
    2666:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    2670:      	movq	%rax, 0x20(%rsp)
    2675:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    267f:      	movq	%rax, 0x18(%rsp)
    2684:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    268e:      	movq	%rax, 0x10(%rsp)
    2693:      	leaq	0x10(%rsp), %rdi
    2698:      	movl	$0x35, %eax
    269d:      	movl	$0x6, %ecx
    26a2:      	movl	$0x35, %esi
    26a7:      	jmp	0x2e21 <kprobe_unwind_php+0x2e21>
    26ac:      	movl	0x2c0(%rbp), %eax
    26b2:      	cmpq	$0x7e, %rax
    26b6:      	ja	0x40e <kprobe_unwind_php+0x40e>
    26bc:      	leal	0x1(%rax), %ecx
    26bf:      	movl	%ecx, 0x2c0(%rbp)
    26c5:      	leaq	(%rax,%rax,2), %rax
    26c9:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    26d5:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    26e1:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    26e9:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    26f4:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    26ff:      	movl	$0x23, 0x4(%rsp)
    2707:      	jmp	0x1e8a <kprobe_unwind_php+0x1e8a>
    270c:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    2716:      	movq	%rax, 0x38(%rsp)
    271b:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    2725:      	movq	%rax, 0x30(%rsp)
    272a:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    2734:      	movq	%rax, 0x28(%rsp)
    2739:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    2743:      	movq	%rax, 0x20(%rsp)
    2748:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    2752:      	movq	%rax, 0x18(%rsp)
    2757:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2761:      	movq	%rax, 0x10(%rsp)
    2766:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    276e:      	leaq	0x10(%rsp), %rdi
    2773:      	movl	$0x33, %eax
    2778:      	movl	$0x6, %ecx
    277d:      	movzbl	0x10(%r15), %eax
    2782:      	addq	%rax, %r13
    2785:      	movl	$0x33, %esi
    278a:      	movq	%r13, %rdx
    278d:      	xorl	%eax, %eax
    278f:      	callq	*%rcx
    2791:      	jmp	0xdd5 <kprobe_unwind_php+0xdd5>
    2796:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    27a0:      	movq	%rax, 0x1e(%rsp)
    27a5:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    27af:      	movq	%rax, 0x18(%rsp)
    27b4:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    27be:      	movq	%rax, 0x10(%rsp)
    27c3:      	leaq	0x10(%rsp), %rdi
    27c8:      	movl	$0x16, %eax
    27cd:      	movl	$0x6, %r8d
    27d3:      	movq	0x58(%rsp), %rdx
    27d8:      	movl	0xc(%rsp), %ecx
    27dc:      	movl	$0x16, %esi
    27e1:      	xorl	%eax, %eax
    27e3:      	callq	*%r8
    27e6:      	movl	0x2c0(%rbp), %eax
    27ec:      	cmpq	$0x7e, %rax
    27f0:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    27f6:      	jmp	0x1ad5 <kprobe_unwind_php+0x1ad5>
    27fb:      	movl	$0x0, 0xc(%rsp)
    2803:      	movzbl	0xb(%rsp), %eax
    2808:      	cmpl	$0x4, %eax
    280b:      	je	0x281e <kprobe_unwind_php+0x281e>
    280d:      	movl	$0x0, 0x4(%rsp)
    2815:      	cmpl	$0x2, %eax
    2818:      	jne	0x3007 <kprobe_unwind_php+0x3007>
    281e:      	movzbl	0x11(%r15), %eax
    2823:      	addq	%r13, %rax
    2826:      	leaq	0x68(%rsp), %rdi
    282b:      	movl	$0x8, %ecx
    2830:      	movl	$0x70, %r8d
    2836:      	movzbl	0x11(%r15), %edx
    283b:      	addq	%r13, %rdx
    283e:      	movl	$0x8, %esi
    2843:      	callq	*%r8
    2846:      	testq	%rax, %rax
    2849:      	je	0x2a53 <kprobe_unwind_php+0x2a53>
    284f:      	movq	(%rip), %rax            # 0x2856 <kprobe_unwind_php+0x2856>
    2856:      	movl	$0x25, 0x4(%rsp)
    285e:      	cmpl	$0x0, (%rax)
    2861:      	je	0x1e8a <kprobe_unwind_php+0x1e8a>
    2867:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    2871:      	movq	%rax, 0x35(%rsp)
    2876:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    2880:      	movq	%rax, 0x30(%rsp)
    2885:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    288f:      	movq	%rax, 0x28(%rsp)
    2894:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    289e:      	movq	%rax, 0x20(%rsp)
    28a3:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    28ad:      	movq	%rax, 0x18(%rsp)
    28b2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    28bc:      	movq	%rax, 0x10(%rsp)
    28c1:      	leaq	0x10(%rsp), %rdi
    28c6:      	movl	$0x2d, %eax
    28cb:      	movl	$0x6, %ecx
    28d0:      	movzbl	0x11(%r15), %eax
    28d5:      	addq	%rax, %r13
    28d8:      	movl	$0x2d, %esi
    28dd:      	jmp	0x34b8 <kprobe_unwind_php+0x34b8>
    28e2:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    28ec:      	movq	%rax, 0x36(%rsp)
    28f1:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    28fb:      	movq	%rax, 0x30(%rsp)
    2900:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    290a:      	movq	%rax, 0x28(%rsp)
    290f:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2919:      	movq	%rax, 0x20(%rsp)
    291e:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2928:      	movq	%rax, 0x18(%rsp)
    292d:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2937:      	movq	%rax, 0x10(%rsp)
    293c:      	leaq	0x10(%rsp), %rdi
    2941:      	movl	$0x2e, %eax
    2946:      	movl	$0x6, %ecx
    294b:      	movl	0x58(%rsp), %edx
    294f:      	movl	$0x2e, %esi
    2954:      	xorl	%eax, %eax
    2956:      	callq	*%rcx
    2958:      	cmpl	$0x23, 0x4(%rsp)
    295d:      	je	0x15b0 <kprobe_unwind_php+0x15b0>
    2963:      	jmp	0x85e3 <kprobe_unwind_php+0x85e3>
    2968:      	movl	0xc(%rsp), %eax
    296c:      	movl	%eax, 0x4(%rsp)
    2970:      	movl	0x54(%rsp), %r13d
    2975:      	movq	(%rip), %rax            # 0x297c <kprobe_unwind_php+0x297c>
    297c:      	cmpl	$0x0, (%rax)
    297f:      	jne	0x34c4 <kprobe_unwind_php+0x34c4>
    2985:      	movl	0x2c0(%rbp), %eax
    298b:      	cmpq	$0x7e, %rax
    298f:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    2995:      	movl	0x4(%rsp), %ecx
    2999:      	shlq	$0x20, %r13
    299d:      	orq	%r13, %rcx
    29a0:      	movq	0x58(%rsp), %rdx
    29a5:      	leal	0x1(%rax), %esi
    29a8:      	movl	%esi, 0x2c0(%rbp)
    29ae:      	leaq	(%rax,%rax,2), %rax
    29b2:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    29ba:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    29c2:      	movl	0x7c(%rsp), %ecx
    29c6:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    29cd:      	jmp	0x1fc9 <kprobe_unwind_php+0x1fc9>
    29d2:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    29dc:      	movq	%rax, 0x38(%rsp)
    29e1:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    29eb:      	movq	%rax, 0x30(%rsp)
    29f0:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    29fa:      	movq	%rax, 0x28(%rsp)
    29ff:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    2a09:      	movq	%rax, 0x20(%rsp)
    2a0e:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    2a18:      	movq	%rax, 0x18(%rsp)
    2a1d:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2a27:      	movq	%rax, 0x10(%rsp)
    2a2c:      	movb	$0x0, 0x40(%rsp)
    2a31:      	leaq	0x10(%rsp), %rdi
    2a36:      	movl	$0x31, %eax
    2a3b:      	movl	$0x6, %ecx
    2a40:      	movq	0x58(%rsp), %rdx
    2a45:      	movl	$0x31, %esi
    2a4a:      	xorl	%eax, %eax
    2a4c:      	callq	*%rcx
    2a4e:      	jmp	0x1588 <kprobe_unwind_php+0x1588>
    2a53:      	movzbl	0x15(%r15), %eax
    2a58:      	addq	0x68(%rsp), %rax
    2a5d:      	leaq	0xc(%rsp), %rdi
    2a62:      	movl	$0x4, %ecx
    2a67:      	movl	$0x70, %r8d
    2a6d:      	movzbl	0x15(%r15), %edx
    2a72:      	addq	0x68(%rsp), %rdx
    2a77:      	movl	$0x4, %esi
    2a7c:      	callq	*%r8
    2a7f:      	testq	%rax, %rax
    2a82:      	je	0x2c78 <kprobe_unwind_php+0x2c78>
    2a88:      	movq	(%rip), %rax            # 0x2a8f <kprobe_unwind_php+0x2a8f>
    2a8f:      	movl	$0x27, 0x4(%rsp)
    2a97:      	cmpl	$0x0, (%rax)
    2a9a:      	je	0x1e8a <kprobe_unwind_php+0x1e8a>
    2aa0:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    2aaa:      	movq	%rax, 0x40(%rsp)
    2aaf:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    2ab9:      	movq	%rax, 0x38(%rsp)
    2abe:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    2ac8:      	movq	%rax, 0x30(%rsp)
    2acd:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    2ad7:      	movq	%rax, 0x28(%rsp)
    2adc:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    2ae6:      	movq	%rax, 0x20(%rsp)
    2aeb:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    2af5:      	movq	%rax, 0x18(%rsp)
    2afa:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2b04:      	movq	%rax, 0x10(%rsp)
    2b09:      	movb	$0x0, 0x48(%rsp)
    2b0e:      	leaq	0x10(%rsp), %rdi
    2b13:      	movl	$0x39, %eax
    2b18:      	movl	$0x6, %ecx
    2b1d:      	movzbl	0x15(%r15), %edx
    2b22:      	addq	0x68(%rsp), %rdx
    2b27:      	movl	$0x39, %esi
    2b2c:      	jmp	0x34bb <kprobe_unwind_php+0x34bb>
    2b31:      	movq	0x58(%rsp), %rax
    2b36:      	testq	%rax, %rax
    2b39:      	je	0x2d43 <kprobe_unwind_php+0x2d43>
    2b3f:      	movzbl	0x14(%r15), %ecx
    2b44:      	addq	%rcx, %rax
    2b47:      	leaq	0xb(%rsp), %rdi
    2b4c:      	movl	$0x1, %ecx
    2b51:      	movl	$0x70, %r8d
    2b57:      	movzbl	0x14(%r15), %edx
    2b5c:      	addq	0x58(%rsp), %rdx
    2b61:      	movl	$0x1, %esi
    2b66:      	callq	*%r8
    2b69:      	testq	%rax, %rax
    2b6c:      	je	0x2e92 <kprobe_unwind_php+0x2e92>
    2b72:      	movq	(%rip), %rax            # 0x2b79 <kprobe_unwind_php+0x2b79>
    2b79:      	cmpl	$0x0, (%rax)
    2b7c:      	jne	0x3d97 <kprobe_unwind_php+0x3d97>
    2b82:      	movl	$0x26, 0x4(%rsp)
    2b8a:      	jmp	0x2528 <kprobe_unwind_php+0x2528>
    2b8f:      	movq	(%rip), %rax            # 0x2b96 <kprobe_unwind_php+0x2b96>
    2b96:      	cmpl	$0x0, (%rax)
    2b99:      	jne	0x3ca7 <kprobe_unwind_php+0x3ca7>
    2b9f:      	cmpl	$0x23, 0x4(%rsp)
    2ba4:      	jne	0x85e3 <kprobe_unwind_php+0x85e3>
    2baa:      	movzbl	0x12(%r15), %eax
    2baf:      	addq	0x70(%rsp), %rax
    2bb4:      	leaq	0x70(%rsp), %rdi
    2bb9:      	movl	$0x8, %ecx
    2bbe:      	movl	$0x70, %r8d
    2bc4:      	movzbl	0x12(%r15), %edx
    2bc9:      	addq	0x70(%rsp), %rdx
    2bce:      	movl	$0x8, %esi
    2bd3:      	callq	*%r8
    2bd6:      	testq	%rax, %rax
    2bd9:      	jne	0x317 <kprobe_unwind_php+0x317>
    2bdf:      	movq	0x70(%rsp), %r13
    2be4:      	testq	%r13, %r13
    2be7:      	je	0x83ba <kprobe_unwind_php+0x83ba>
    2bed:      	testb	$0x2, 0x56(%rsp)
    2bf2:      	jne	0x83ba <kprobe_unwind_php+0x83ba>
    2bf8:      	movzbl	0x10(%r15), %eax
    2bfd:      	addq	%r13, %rax
    2c00:      	leaq	0x58(%rsp), %rdi
    2c05:      	movl	$0x8, %ecx
    2c0a:      	movl	$0x70, %r8d
    2c10:      	movzbl	0x10(%r15), %edx
    2c15:      	addq	%r13, %rdx
    2c18:      	movl	$0x8, %esi
    2c1d:      	callq	*%r8
    2c20:      	testq	%rax, %rax
    2c23:      	je	0x31c8 <kprobe_unwind_php+0x31c8>
    2c29:      	movq	(%rip), %rax            # 0x2c30 <kprobe_unwind_php+0x2c30>
    2c30:      	movl	$0x25, 0x4(%rsp)
    2c38:      	cmpl	$0x0, (%rax)
    2c3b:      	jne	0x4168 <kprobe_unwind_php+0x4168>
    2c41:      	movl	0x4(%rsp), %eax
    2c45:      	movl	%eax, 0x58(%rsp)
    2c49:      	movq	(%rip), %rdi            # 0x2c50 <kprobe_unwind_php+0x2c50>
    2c50:      	leaq	0x58(%rsp), %rsi
    2c55:      	movl	$0x1, %eax
    2c5a:      	callq	*%rax
    2c5c:      	testq	%rax, %rax
    2c5f:      	je	0x3226 <kprobe_unwind_php+0x3226>
    2c65:      	incq	(%rax)
    2c68:      	cmpl	$0x23, 0x4(%rsp)
    2c6d:      	je	0x3241 <kprobe_unwind_php+0x3241>
    2c73:      	jmp	0x85e3 <kprobe_unwind_php+0x85e3>
    2c78:      	movzbl	0x13(%r15), %eax
    2c7d:      	addq	%r13, %rax
    2c80:      	leaq	0x54(%rsp), %rdi
    2c85:      	movl	$0x4, %ecx
    2c8a:      	movl	$0x70, %r8d
    2c90:      	movzbl	0x13(%r15), %edx
    2c95:      	addq	%r13, %rdx
    2c98:      	movl	$0x4, %esi
    2c9d:      	callq	*%r8
    2ca0:      	testq	%rax, %rax
    2ca3:      	je	0x2fff <kprobe_unwind_php+0x2fff>
    2ca9:      	movq	(%rip), %rax            # 0x2cb0 <kprobe_unwind_php+0x2cb0>
    2cb0:      	movl	$0x25, 0x4(%rsp)
    2cb8:      	cmpl	$0x0, (%rax)
    2cbb:      	je	0x1e8a <kprobe_unwind_php+0x1e8a>
    2cc1:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    2ccb:      	movq	%rax, 0x3d(%rsp)
    2cd0:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    2cda:      	movq	%rax, 0x38(%rsp)
    2cdf:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    2ce9:      	movq	%rax, 0x30(%rsp)
    2cee:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    2cf8:      	movq	%rax, 0x28(%rsp)
    2cfd:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    2d07:      	movq	%rax, 0x20(%rsp)
    2d0c:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    2d16:      	movq	%rax, 0x18(%rsp)
    2d1b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2d25:      	movq	%rax, 0x10(%rsp)
    2d2a:      	leaq	0x10(%rsp), %rdi
    2d2f:      	movl	$0x35, %eax
    2d34:      	movl	$0x6, %ecx
    2d39:      	movl	$0x35, %esi
    2d3e:      	jmp	0x34b8 <kprobe_unwind_php+0x34b8>
    2d43:      	movl	0x2c0(%rbp), %eax
    2d49:      	cmpq	$0x7e, %rax
    2d4d:      	ja	0x40e <kprobe_unwind_php+0x40e>
    2d53:      	leal	0x1(%rax), %ecx
    2d56:      	movl	%ecx, 0x2c0(%rbp)
    2d5c:      	leaq	(%rax,%rax,2), %rax
    2d60:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    2d6c:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    2d78:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    2d80:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    2d8b:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    2d96:      	movl	$0x23, 0x4(%rsp)
    2d9e:      	jmp	0x2528 <kprobe_unwind_php+0x2528>
    2da3:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    2dad:      	movq	%rax, 0x38(%rsp)
    2db2:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    2dbc:      	movq	%rax, 0x30(%rsp)
    2dc1:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    2dcb:      	movq	%rax, 0x28(%rsp)
    2dd0:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    2dda:      	movq	%rax, 0x20(%rsp)
    2ddf:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    2de9:      	movq	%rax, 0x18(%rsp)
    2dee:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2df8:      	movq	%rax, 0x10(%rsp)
    2dfd:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    2e05:      	leaq	0x10(%rsp), %rdi
    2e0a:      	movl	$0x33, %eax
    2e0f:      	movl	$0x6, %ecx
    2e14:      	movzbl	0x10(%r15), %eax
    2e19:      	addq	%rax, %r13
    2e1c:      	movl	$0x33, %esi
    2e21:      	movq	%r13, %rdx
    2e24:      	xorl	%eax, %eax
    2e26:      	callq	*%rcx
    2e28:      	jmp	0x1647 <kprobe_unwind_php+0x1647>
    2e2d:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    2e37:      	movq	%rax, 0x1e(%rsp)
    2e3c:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    2e46:      	movq	%rax, 0x18(%rsp)
    2e4b:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    2e55:      	movq	%rax, 0x10(%rsp)
    2e5a:      	leaq	0x10(%rsp), %rdi
    2e5f:      	movl	$0x16, %eax
    2e64:      	movl	$0x6, %r8d
    2e6a:      	movq	0x58(%rsp), %rdx
    2e6f:      	movl	0xc(%rsp), %ecx
    2e73:      	movl	$0x16, %esi
    2e78:      	xorl	%eax, %eax
    2e7a:      	callq	*%r8
    2e7d:      	movl	0x2c0(%rbp), %eax
    2e83:      	cmpq	$0x7e, %rax
    2e87:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    2e8d:      	jmp	0x227c <kprobe_unwind_php+0x227c>
    2e92:      	movl	$0x0, 0xc(%rsp)
    2e9a:      	movzbl	0xb(%rsp), %eax
    2e9f:      	cmpl	$0x4, %eax
    2ea2:      	je	0x2eb5 <kprobe_unwind_php+0x2eb5>
    2ea4:      	movl	$0x0, 0x4(%rsp)
    2eac:      	cmpl	$0x2, %eax
    2eaf:      	jne	0x369e <kprobe_unwind_php+0x369e>
    2eb5:      	movzbl	0x11(%r15), %eax
    2eba:      	addq	%r13, %rax
    2ebd:      	leaq	0x68(%rsp), %rdi
    2ec2:      	movl	$0x8, %ecx
    2ec7:      	movl	$0x70, %r8d
    2ecd:      	movzbl	0x11(%r15), %edx
    2ed2:      	addq	%r13, %rdx
    2ed5:      	movl	$0x8, %esi
    2eda:      	callq	*%r8
    2edd:      	testq	%rax, %rax
    2ee0:      	je	0x30ea <kprobe_unwind_php+0x30ea>
    2ee6:      	movq	(%rip), %rax            # 0x2eed <kprobe_unwind_php+0x2eed>
    2eed:      	movl	$0x25, 0x4(%rsp)
    2ef5:      	cmpl	$0x0, (%rax)
    2ef8:      	je	0x2528 <kprobe_unwind_php+0x2528>
    2efe:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    2f08:      	movq	%rax, 0x35(%rsp)
    2f0d:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    2f17:      	movq	%rax, 0x30(%rsp)
    2f1c:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    2f26:      	movq	%rax, 0x28(%rsp)
    2f2b:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    2f35:      	movq	%rax, 0x20(%rsp)
    2f3a:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    2f44:      	movq	%rax, 0x18(%rsp)
    2f49:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2f53:      	movq	%rax, 0x10(%rsp)
    2f58:      	leaq	0x10(%rsp), %rdi
    2f5d:      	movl	$0x2d, %eax
    2f62:      	movl	$0x6, %ecx
    2f67:      	movzbl	0x11(%r15), %eax
    2f6c:      	addq	%rax, %r13
    2f6f:      	movl	$0x2d, %esi
    2f74:      	jmp	0x3b4f <kprobe_unwind_php+0x3b4f>
    2f79:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2f83:      	movq	%rax, 0x36(%rsp)
    2f88:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2f92:      	movq	%rax, 0x30(%rsp)
    2f97:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2fa1:      	movq	%rax, 0x28(%rsp)
    2fa6:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2fb0:      	movq	%rax, 0x20(%rsp)
    2fb5:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2fbf:      	movq	%rax, 0x18(%rsp)
    2fc4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2fce:      	movq	%rax, 0x10(%rsp)
    2fd3:      	leaq	0x10(%rsp), %rdi
    2fd8:      	movl	$0x2e, %eax
    2fdd:      	movl	$0x6, %ecx
    2fe2:      	movl	0x58(%rsp), %edx
    2fe6:      	movl	$0x2e, %esi
    2feb:      	xorl	%eax, %eax
    2fed:      	callq	*%rcx
    2fef:      	cmpl	$0x23, 0x4(%rsp)
    2ff4:      	je	0x1df3 <kprobe_unwind_php+0x1df3>
    2ffa:      	jmp	0x85e3 <kprobe_unwind_php+0x85e3>
    2fff:      	movl	0xc(%rsp), %eax
    3003:      	movl	%eax, 0x4(%rsp)
    3007:      	movl	0x54(%rsp), %r13d
    300c:      	movq	(%rip), %rax            # 0x3013 <kprobe_unwind_php+0x3013>
    3013:      	cmpl	$0x0, (%rax)
    3016:      	jne	0x3b5b <kprobe_unwind_php+0x3b5b>
    301c:      	movl	0x2c0(%rbp), %eax
    3022:      	cmpq	$0x7e, %rax
    3026:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    302c:      	movl	0x4(%rsp), %ecx
    3030:      	shlq	$0x20, %r13
    3034:      	orq	%r13, %rcx
    3037:      	movq	0x58(%rsp), %rdx
    303c:      	leal	0x1(%rax), %esi
    303f:      	movl	%esi, 0x2c0(%rbp)
    3045:      	leaq	(%rax,%rax,2), %rax
    3049:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    3051:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    3059:      	movl	0x7c(%rsp), %ecx
    305d:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    3064:      	jmp	0x26e9 <kprobe_unwind_php+0x26e9>
    3069:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    3073:      	movq	%rax, 0x38(%rsp)
    3078:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    3082:      	movq	%rax, 0x30(%rsp)
    3087:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    3091:      	movq	%rax, 0x28(%rsp)
    3096:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    30a0:      	movq	%rax, 0x20(%rsp)
    30a5:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    30af:      	movq	%rax, 0x18(%rsp)
    30b4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    30be:      	movq	%rax, 0x10(%rsp)
    30c3:      	movb	$0x0, 0x40(%rsp)
    30c8:      	leaq	0x10(%rsp), %rdi
    30cd:      	movl	$0x31, %eax
    30d2:      	movl	$0x6, %ecx
    30d7:      	movq	0x58(%rsp), %rdx
    30dc:      	movl	$0x31, %esi
    30e1:      	xorl	%eax, %eax
    30e3:      	callq	*%rcx
    30e5:      	jmp	0x1dcb <kprobe_unwind_php+0x1dcb>
    30ea:      	movzbl	0x15(%r15), %eax
    30ef:      	addq	0x68(%rsp), %rax
    30f4:      	leaq	0xc(%rsp), %rdi
    30f9:      	movl	$0x4, %ecx
    30fe:      	movl	$0x70, %r8d
    3104:      	movzbl	0x15(%r15), %edx
    3109:      	addq	0x68(%rsp), %rdx
    310e:      	movl	$0x4, %esi
    3113:      	callq	*%r8
    3116:      	testq	%rax, %rax
    3119:      	je	0x330f <kprobe_unwind_php+0x330f>
    311f:      	movq	(%rip), %rax            # 0x3126 <kprobe_unwind_php+0x3126>
    3126:      	movl	$0x27, 0x4(%rsp)
    312e:      	cmpl	$0x0, (%rax)
    3131:      	je	0x2528 <kprobe_unwind_php+0x2528>
    3137:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    3141:      	movq	%rax, 0x40(%rsp)
    3146:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    3150:      	movq	%rax, 0x38(%rsp)
    3155:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    315f:      	movq	%rax, 0x30(%rsp)
    3164:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    316e:      	movq	%rax, 0x28(%rsp)
    3173:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    317d:      	movq	%rax, 0x20(%rsp)
    3182:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    318c:      	movq	%rax, 0x18(%rsp)
    3191:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    319b:      	movq	%rax, 0x10(%rsp)
    31a0:      	movb	$0x0, 0x48(%rsp)
    31a5:      	leaq	0x10(%rsp), %rdi
    31aa:      	movl	$0x39, %eax
    31af:      	movl	$0x6, %ecx
    31b4:      	movzbl	0x15(%r15), %edx
    31b9:      	addq	0x68(%rsp), %rdx
    31be:      	movl	$0x39, %esi
    31c3:      	jmp	0x3b52 <kprobe_unwind_php+0x3b52>
    31c8:      	movq	0x58(%rsp), %rax
    31cd:      	testq	%rax, %rax
    31d0:      	je	0x33da <kprobe_unwind_php+0x33da>
    31d6:      	movzbl	0x14(%r15), %ecx
    31db:      	addq	%rcx, %rax
    31de:      	leaq	0xb(%rsp), %rdi
    31e3:      	movl	$0x1, %ecx
    31e8:      	movl	$0x70, %r8d
    31ee:      	movzbl	0x14(%r15), %edx
    31f3:      	addq	0x58(%rsp), %rdx
    31f8:      	movl	$0x1, %esi
    31fd:      	callq	*%r8
    3200:      	testq	%rax, %rax
    3203:      	je	0x3529 <kprobe_unwind_php+0x3529>
    3209:      	movq	(%rip), %rax            # 0x3210 <kprobe_unwind_php+0x3210>
    3210:      	cmpl	$0x0, (%rax)
    3213:      	jne	0x442e <kprobe_unwind_php+0x442e>
    3219:      	movl	$0x26, 0x4(%rsp)
    3221:      	jmp	0x2c41 <kprobe_unwind_php+0x2c41>
    3226:      	movq	(%rip), %rax            # 0x322d <kprobe_unwind_php+0x322d>
    322d:      	cmpl	$0x0, (%rax)
    3230:      	jne	0x433e <kprobe_unwind_php+0x433e>
    3236:      	cmpl	$0x23, 0x4(%rsp)
    323b:      	jne	0x85e3 <kprobe_unwind_php+0x85e3>
    3241:      	movzbl	0x12(%r15), %eax
    3246:      	addq	0x70(%rsp), %rax
    324b:      	leaq	0x70(%rsp), %rdi
    3250:      	movl	$0x8, %ecx
    3255:      	movl	$0x70, %r8d
    325b:      	movzbl	0x12(%r15), %edx
    3260:      	addq	0x70(%rsp), %rdx
    3265:      	movl	$0x8, %esi
    326a:      	callq	*%r8
    326d:      	testq	%rax, %rax
    3270:      	jne	0x317 <kprobe_unwind_php+0x317>
    3276:      	movq	0x70(%rsp), %r13
    327b:      	testq	%r13, %r13
    327e:      	je	0x83ba <kprobe_unwind_php+0x83ba>
    3284:      	testb	$0x2, 0x56(%rsp)
    3289:      	jne	0x83ba <kprobe_unwind_php+0x83ba>
    328f:      	movzbl	0x10(%r15), %eax
    3294:      	addq	%r13, %rax
    3297:      	leaq	0x58(%rsp), %rdi
    329c:      	movl	$0x8, %ecx
    32a1:      	movl	$0x70, %r8d
    32a7:      	movzbl	0x10(%r15), %edx
    32ac:      	addq	%r13, %rdx
    32af:      	movl	$0x8, %esi
    32b4:      	callq	*%r8
    32b7:      	testq	%rax, %rax
    32ba:      	je	0x385f <kprobe_unwind_php+0x385f>
    32c0:      	movq	(%rip), %rax            # 0x32c7 <kprobe_unwind_php+0x32c7>
    32c7:      	movl	$0x25, 0x4(%rsp)
    32cf:      	cmpl	$0x0, (%rax)
    32d2:      	jne	0x47ff <kprobe_unwind_php+0x47ff>
    32d8:      	movl	0x4(%rsp), %eax
    32dc:      	movl	%eax, 0x58(%rsp)
    32e0:      	movq	(%rip), %rdi            # 0x32e7 <kprobe_unwind_php+0x32e7>
    32e7:      	leaq	0x58(%rsp), %rsi
    32ec:      	movl	$0x1, %eax
    32f1:      	callq	*%rax
    32f3:      	testq	%rax, %rax
    32f6:      	je	0x38bd <kprobe_unwind_php+0x38bd>
    32fc:      	incq	(%rax)
    32ff:      	cmpl	$0x23, 0x4(%rsp)
    3304:      	je	0x38d8 <kprobe_unwind_php+0x38d8>
    330a:      	jmp	0x85e3 <kprobe_unwind_php+0x85e3>
    330f:      	movzbl	0x13(%r15), %eax
    3314:      	addq	%r13, %rax
    3317:      	leaq	0x54(%rsp), %rdi
    331c:      	movl	$0x4, %ecx
    3321:      	movl	$0x70, %r8d
    3327:      	movzbl	0x13(%r15), %edx
    332c:      	addq	%r13, %rdx
    332f:      	movl	$0x4, %esi
    3334:      	callq	*%r8
    3337:      	testq	%rax, %rax
    333a:      	je	0x3696 <kprobe_unwind_php+0x3696>
    3340:      	movq	(%rip), %rax            # 0x3347 <kprobe_unwind_php+0x3347>
    3347:      	movl	$0x25, 0x4(%rsp)
    334f:      	cmpl	$0x0, (%rax)
    3352:      	je	0x2528 <kprobe_unwind_php+0x2528>
    3358:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    3362:      	movq	%rax, 0x3d(%rsp)
    3367:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    3371:      	movq	%rax, 0x38(%rsp)
    3376:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    3380:      	movq	%rax, 0x30(%rsp)
    3385:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    338f:      	movq	%rax, 0x28(%rsp)
    3394:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    339e:      	movq	%rax, 0x20(%rsp)
    33a3:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    33ad:      	movq	%rax, 0x18(%rsp)
    33b2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    33bc:      	movq	%rax, 0x10(%rsp)
    33c1:      	leaq	0x10(%rsp), %rdi
    33c6:      	movl	$0x35, %eax
    33cb:      	movl	$0x6, %ecx
    33d0:      	movl	$0x35, %esi
    33d5:      	jmp	0x3b4f <kprobe_unwind_php+0x3b4f>
    33da:      	movl	0x2c0(%rbp), %eax
    33e0:      	cmpq	$0x7e, %rax
    33e4:      	ja	0x40e <kprobe_unwind_php+0x40e>
    33ea:      	leal	0x1(%rax), %ecx
    33ed:      	movl	%ecx, 0x2c0(%rbp)
    33f3:      	leaq	(%rax,%rax,2), %rax
    33f7:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    3403:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    340f:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    3417:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    3422:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    342d:      	movl	$0x23, 0x4(%rsp)
    3435:      	jmp	0x2c41 <kprobe_unwind_php+0x2c41>
    343a:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    3444:      	movq	%rax, 0x38(%rsp)
    3449:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    3453:      	movq	%rax, 0x30(%rsp)
    3458:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    3462:      	movq	%rax, 0x28(%rsp)
    3467:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    3471:      	movq	%rax, 0x20(%rsp)
    3476:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    3480:      	movq	%rax, 0x18(%rsp)
    3485:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    348f:      	movq	%rax, 0x10(%rsp)
    3494:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    349c:      	leaq	0x10(%rsp), %rdi
    34a1:      	movl	$0x33, %eax
    34a6:      	movl	$0x6, %ecx
    34ab:      	movzbl	0x10(%r15), %eax
    34b0:      	addq	%rax, %r13
    34b3:      	movl	$0x33, %esi
    34b8:      	movq	%r13, %rdx
    34bb:      	xorl	%eax, %eax
    34bd:      	callq	*%rcx
    34bf:      	jmp	0x1e8a <kprobe_unwind_php+0x1e8a>
    34c4:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    34ce:      	movq	%rax, 0x1e(%rsp)
    34d3:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    34dd:      	movq	%rax, 0x18(%rsp)
    34e2:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    34ec:      	movq	%rax, 0x10(%rsp)
    34f1:      	leaq	0x10(%rsp), %rdi
    34f6:      	movl	$0x16, %eax
    34fb:      	movl	$0x6, %r8d
    3501:      	movq	0x58(%rsp), %rdx
    3506:      	movl	0xc(%rsp), %ecx
    350a:      	movl	$0x16, %esi
    350f:      	xorl	%eax, %eax
    3511:      	callq	*%r8
    3514:      	movl	0x2c0(%rbp), %eax
    351a:      	cmpq	$0x7e, %rax
    351e:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    3524:      	jmp	0x2995 <kprobe_unwind_php+0x2995>
    3529:      	movl	$0x0, 0xc(%rsp)
    3531:      	movzbl	0xb(%rsp), %eax
    3536:      	cmpl	$0x4, %eax
    3539:      	je	0x354c <kprobe_unwind_php+0x354c>
    353b:      	movl	$0x0, 0x4(%rsp)
    3543:      	cmpl	$0x2, %eax
    3546:      	jne	0x3d35 <kprobe_unwind_php+0x3d35>
    354c:      	movzbl	0x11(%r15), %eax
    3551:      	addq	%r13, %rax
    3554:      	leaq	0x68(%rsp), %rdi
    3559:      	movl	$0x8, %ecx
    355e:      	movl	$0x70, %r8d
    3564:      	movzbl	0x11(%r15), %edx
    3569:      	addq	%r13, %rdx
    356c:      	movl	$0x8, %esi
    3571:      	callq	*%r8
    3574:      	testq	%rax, %rax
    3577:      	je	0x3781 <kprobe_unwind_php+0x3781>
    357d:      	movq	(%rip), %rax            # 0x3584 <kprobe_unwind_php+0x3584>
    3584:      	movl	$0x25, 0x4(%rsp)
    358c:      	cmpl	$0x0, (%rax)
    358f:      	je	0x2c41 <kprobe_unwind_php+0x2c41>
    3595:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    359f:      	movq	%rax, 0x35(%rsp)
    35a4:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    35ae:      	movq	%rax, 0x30(%rsp)
    35b3:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    35bd:      	movq	%rax, 0x28(%rsp)
    35c2:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    35cc:      	movq	%rax, 0x20(%rsp)
    35d1:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    35db:      	movq	%rax, 0x18(%rsp)
    35e0:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    35ea:      	movq	%rax, 0x10(%rsp)
    35ef:      	leaq	0x10(%rsp), %rdi
    35f4:      	movl	$0x2d, %eax
    35f9:      	movl	$0x6, %ecx
    35fe:      	movzbl	0x11(%r15), %eax
    3603:      	addq	%rax, %r13
    3606:      	movl	$0x2d, %esi
    360b:      	jmp	0x41e6 <kprobe_unwind_php+0x41e6>
    3610:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    361a:      	movq	%rax, 0x36(%rsp)
    361f:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3629:      	movq	%rax, 0x30(%rsp)
    362e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3638:      	movq	%rax, 0x28(%rsp)
    363d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3647:      	movq	%rax, 0x20(%rsp)
    364c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3656:      	movq	%rax, 0x18(%rsp)
    365b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3665:      	movq	%rax, 0x10(%rsp)
    366a:      	leaq	0x10(%rsp), %rdi
    366f:      	movl	$0x2e, %eax
    3674:      	movl	$0x6, %ecx
    3679:      	movl	0x58(%rsp), %edx
    367d:      	movl	$0x2e, %esi
    3682:      	xorl	%eax, %eax
    3684:      	callq	*%rcx
    3686:      	cmpl	$0x23, 0x4(%rsp)
    368b:      	je	0x2491 <kprobe_unwind_php+0x2491>
    3691:      	jmp	0x85e3 <kprobe_unwind_php+0x85e3>
    3696:      	movl	0xc(%rsp), %eax
    369a:      	movl	%eax, 0x4(%rsp)
    369e:      	movl	0x54(%rsp), %r13d
    36a3:      	movq	(%rip), %rax            # 0x36aa <kprobe_unwind_php+0x36aa>
    36aa:      	cmpl	$0x0, (%rax)
    36ad:      	jne	0x41f2 <kprobe_unwind_php+0x41f2>
    36b3:      	movl	0x2c0(%rbp), %eax
    36b9:      	cmpq	$0x7e, %rax
    36bd:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    36c3:      	movl	0x4(%rsp), %ecx
    36c7:      	shlq	$0x20, %r13
    36cb:      	orq	%r13, %rcx
    36ce:      	movq	0x58(%rsp), %rdx
    36d3:      	leal	0x1(%rax), %esi
    36d6:      	movl	%esi, 0x2c0(%rbp)
    36dc:      	leaq	(%rax,%rax,2), %rax
    36e0:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    36e8:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    36f0:      	movl	0x7c(%rsp), %ecx
    36f4:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    36fb:      	jmp	0x2d80 <kprobe_unwind_php+0x2d80>
    3700:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    370a:      	movq	%rax, 0x38(%rsp)
    370f:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    3719:      	movq	%rax, 0x30(%rsp)
    371e:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    3728:      	movq	%rax, 0x28(%rsp)
    372d:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    3737:      	movq	%rax, 0x20(%rsp)
    373c:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    3746:      	movq	%rax, 0x18(%rsp)
    374b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3755:      	movq	%rax, 0x10(%rsp)
    375a:      	movb	$0x0, 0x40(%rsp)
    375f:      	leaq	0x10(%rsp), %rdi
    3764:      	movl	$0x31, %eax
    3769:      	movl	$0x6, %ecx
    376e:      	movq	0x58(%rsp), %rdx
    3773:      	movl	$0x31, %esi
    3778:      	xorl	%eax, %eax
    377a:      	callq	*%rcx
    377c:      	jmp	0x2469 <kprobe_unwind_php+0x2469>
    3781:      	movzbl	0x15(%r15), %eax
    3786:      	addq	0x68(%rsp), %rax
    378b:      	leaq	0xc(%rsp), %rdi
    3790:      	movl	$0x4, %ecx
    3795:      	movl	$0x70, %r8d
    379b:      	movzbl	0x15(%r15), %edx
    37a0:      	addq	0x68(%rsp), %rdx
    37a5:      	movl	$0x4, %esi
    37aa:      	callq	*%r8
    37ad:      	testq	%rax, %rax
    37b0:      	je	0x39a6 <kprobe_unwind_php+0x39a6>
    37b6:      	movq	(%rip), %rax            # 0x37bd <kprobe_unwind_php+0x37bd>
    37bd:      	movl	$0x27, 0x4(%rsp)
    37c5:      	cmpl	$0x0, (%rax)
    37c8:      	je	0x2c41 <kprobe_unwind_php+0x2c41>
    37ce:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    37d8:      	movq	%rax, 0x40(%rsp)
    37dd:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    37e7:      	movq	%rax, 0x38(%rsp)
    37ec:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    37f6:      	movq	%rax, 0x30(%rsp)
    37fb:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    3805:      	movq	%rax, 0x28(%rsp)
    380a:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    3814:      	movq	%rax, 0x20(%rsp)
    3819:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    3823:      	movq	%rax, 0x18(%rsp)
    3828:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3832:      	movq	%rax, 0x10(%rsp)
    3837:      	movb	$0x0, 0x48(%rsp)
    383c:      	leaq	0x10(%rsp), %rdi
    3841:      	movl	$0x39, %eax
    3846:      	movl	$0x6, %ecx
    384b:      	movzbl	0x15(%r15), %edx
    3850:      	addq	0x68(%rsp), %rdx
    3855:      	movl	$0x39, %esi
    385a:      	jmp	0x41e9 <kprobe_unwind_php+0x41e9>
    385f:      	movq	0x58(%rsp), %rax
    3864:      	testq	%rax, %rax
    3867:      	je	0x3a71 <kprobe_unwind_php+0x3a71>
    386d:      	movzbl	0x14(%r15), %ecx
    3872:      	addq	%rcx, %rax
    3875:      	leaq	0xb(%rsp), %rdi
    387a:      	movl	$0x1, %ecx
    387f:      	movl	$0x70, %r8d
    3885:      	movzbl	0x14(%r15), %edx
    388a:      	addq	0x58(%rsp), %rdx
    388f:      	movl	$0x1, %esi
    3894:      	callq	*%r8
    3897:      	testq	%rax, %rax
    389a:      	je	0x3bc0 <kprobe_unwind_php+0x3bc0>
    38a0:      	movq	(%rip), %rax            # 0x38a7 <kprobe_unwind_php+0x38a7>
    38a7:      	cmpl	$0x0, (%rax)
    38aa:      	jne	0x4ac5 <kprobe_unwind_php+0x4ac5>
    38b0:      	movl	$0x26, 0x4(%rsp)
    38b8:      	jmp	0x32d8 <kprobe_unwind_php+0x32d8>
    38bd:      	movq	(%rip), %rax            # 0x38c4 <kprobe_unwind_php+0x38c4>
    38c4:      	cmpl	$0x0, (%rax)
    38c7:      	jne	0x49d5 <kprobe_unwind_php+0x49d5>
    38cd:      	cmpl	$0x23, 0x4(%rsp)
    38d2:      	jne	0x85e3 <kprobe_unwind_php+0x85e3>
    38d8:      	movzbl	0x12(%r15), %eax
    38dd:      	addq	0x70(%rsp), %rax
    38e2:      	leaq	0x70(%rsp), %rdi
    38e7:      	movl	$0x8, %ecx
    38ec:      	movl	$0x70, %r8d
    38f2:      	movzbl	0x12(%r15), %edx
    38f7:      	addq	0x70(%rsp), %rdx
    38fc:      	movl	$0x8, %esi
    3901:      	callq	*%r8
    3904:      	testq	%rax, %rax
    3907:      	jne	0x317 <kprobe_unwind_php+0x317>
    390d:      	movq	0x70(%rsp), %r13
    3912:      	testq	%r13, %r13
    3915:      	je	0x83ba <kprobe_unwind_php+0x83ba>
    391b:      	testb	$0x2, 0x56(%rsp)
    3920:      	jne	0x83ba <kprobe_unwind_php+0x83ba>
    3926:      	movzbl	0x10(%r15), %eax
    392b:      	addq	%r13, %rax
    392e:      	leaq	0x58(%rsp), %rdi
    3933:      	movl	$0x8, %ecx
    3938:      	movl	$0x70, %r8d
    393e:      	movzbl	0x10(%r15), %edx
    3943:      	addq	%r13, %rdx
    3946:      	movl	$0x8, %esi
    394b:      	callq	*%r8
    394e:      	testq	%rax, %rax
    3951:      	je	0x3ef6 <kprobe_unwind_php+0x3ef6>
    3957:      	movq	(%rip), %rax            # 0x395e <kprobe_unwind_php+0x395e>
    395e:      	movl	$0x25, 0x4(%rsp)
    3966:      	cmpl	$0x0, (%rax)
    3969:      	jne	0x4f3c <kprobe_unwind_php+0x4f3c>
    396f:      	movl	0x4(%rsp), %eax
    3973:      	movl	%eax, 0x58(%rsp)
    3977:      	movq	(%rip), %rdi            # 0x397e <kprobe_unwind_php+0x397e>
    397e:      	leaq	0x58(%rsp), %rsi
    3983:      	movl	$0x1, %eax
    3988:      	callq	*%rax
    398a:      	testq	%rax, %rax
    398d:      	je	0x3f54 <kprobe_unwind_php+0x3f54>
    3993:      	incq	(%rax)
    3996:      	cmpl	$0x23, 0x4(%rsp)
    399b:      	je	0x3f6f <kprobe_unwind_php+0x3f6f>
    39a1:      	jmp	0x85e3 <kprobe_unwind_php+0x85e3>
    39a6:      	movzbl	0x13(%r15), %eax
    39ab:      	addq	%r13, %rax
    39ae:      	leaq	0x54(%rsp), %rdi
    39b3:      	movl	$0x4, %ecx
    39b8:      	movl	$0x70, %r8d
    39be:      	movzbl	0x13(%r15), %edx
    39c3:      	addq	%r13, %rdx
    39c6:      	movl	$0x4, %esi
    39cb:      	callq	*%r8
    39ce:      	testq	%rax, %rax
    39d1:      	je	0x3d2d <kprobe_unwind_php+0x3d2d>
    39d7:      	movq	(%rip), %rax            # 0x39de <kprobe_unwind_php+0x39de>
    39de:      	movl	$0x25, 0x4(%rsp)
    39e6:      	cmpl	$0x0, (%rax)
    39e9:      	je	0x2c41 <kprobe_unwind_php+0x2c41>
    39ef:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    39f9:      	movq	%rax, 0x3d(%rsp)
    39fe:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    3a08:      	movq	%rax, 0x38(%rsp)
    3a0d:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    3a17:      	movq	%rax, 0x30(%rsp)
    3a1c:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    3a26:      	movq	%rax, 0x28(%rsp)
    3a2b:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    3a35:      	movq	%rax, 0x20(%rsp)
    3a3a:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    3a44:      	movq	%rax, 0x18(%rsp)
    3a49:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3a53:      	movq	%rax, 0x10(%rsp)
    3a58:      	leaq	0x10(%rsp), %rdi
    3a5d:      	movl	$0x35, %eax
    3a62:      	movl	$0x6, %ecx
    3a67:      	movl	$0x35, %esi
    3a6c:      	jmp	0x41e6 <kprobe_unwind_php+0x41e6>
    3a71:      	movl	0x2c0(%rbp), %eax
    3a77:      	cmpq	$0x7e, %rax
    3a7b:      	ja	0x40e <kprobe_unwind_php+0x40e>
    3a81:      	leal	0x1(%rax), %ecx
    3a84:      	movl	%ecx, 0x2c0(%rbp)
    3a8a:      	leaq	(%rax,%rax,2), %rax
    3a8e:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    3a9a:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    3aa6:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    3aae:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    3ab9:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    3ac4:      	movl	$0x23, 0x4(%rsp)
    3acc:      	jmp	0x32d8 <kprobe_unwind_php+0x32d8>
    3ad1:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    3adb:      	movq	%rax, 0x38(%rsp)
    3ae0:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    3aea:      	movq	%rax, 0x30(%rsp)
    3aef:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    3af9:      	movq	%rax, 0x28(%rsp)
    3afe:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    3b08:      	movq	%rax, 0x20(%rsp)
    3b0d:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    3b17:      	movq	%rax, 0x18(%rsp)
    3b1c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3b26:      	movq	%rax, 0x10(%rsp)
    3b2b:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    3b33:      	leaq	0x10(%rsp), %rdi
    3b38:      	movl	$0x33, %eax
    3b3d:      	movl	$0x6, %ecx
    3b42:      	movzbl	0x10(%r15), %eax
    3b47:      	addq	%rax, %r13
    3b4a:      	movl	$0x33, %esi
    3b4f:      	movq	%r13, %rdx
    3b52:      	xorl	%eax, %eax
    3b54:      	callq	*%rcx
    3b56:      	jmp	0x2528 <kprobe_unwind_php+0x2528>
    3b5b:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    3b65:      	movq	%rax, 0x1e(%rsp)
    3b6a:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    3b74:      	movq	%rax, 0x18(%rsp)
    3b79:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    3b83:      	movq	%rax, 0x10(%rsp)
    3b88:      	leaq	0x10(%rsp), %rdi
    3b8d:      	movl	$0x16, %eax
    3b92:      	movl	$0x6, %r8d
    3b98:      	movq	0x58(%rsp), %rdx
    3b9d:      	movl	0xc(%rsp), %ecx
    3ba1:      	movl	$0x16, %esi
    3ba6:      	xorl	%eax, %eax
    3ba8:      	callq	*%r8
    3bab:      	movl	0x2c0(%rbp), %eax
    3bb1:      	cmpq	$0x7e, %rax
    3bb5:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    3bbb:      	jmp	0x302c <kprobe_unwind_php+0x302c>
    3bc0:      	movl	$0x0, 0xc(%rsp)
    3bc8:      	movzbl	0xb(%rsp), %eax
    3bcd:      	cmpl	$0x4, %eax
    3bd0:      	je	0x3be3 <kprobe_unwind_php+0x3be3>
    3bd2:      	movl	$0x0, 0x4(%rsp)
    3bda:      	cmpl	$0x2, %eax
    3bdd:      	jne	0x43cc <kprobe_unwind_php+0x43cc>
    3be3:      	movzbl	0x11(%r15), %eax
    3be8:      	addq	%r13, %rax
    3beb:      	leaq	0x68(%rsp), %rdi
    3bf0:      	movl	$0x8, %ecx
    3bf5:      	movl	$0x70, %r8d
    3bfb:      	movzbl	0x11(%r15), %edx
    3c00:      	addq	%r13, %rdx
    3c03:      	movl	$0x8, %esi
    3c08:      	callq	*%r8
    3c0b:      	testq	%rax, %rax
    3c0e:      	je	0x3e18 <kprobe_unwind_php+0x3e18>
    3c14:      	movq	(%rip), %rax            # 0x3c1b <kprobe_unwind_php+0x3c1b>
    3c1b:      	movl	$0x25, 0x4(%rsp)
    3c23:      	cmpl	$0x0, (%rax)
    3c26:      	je	0x32d8 <kprobe_unwind_php+0x32d8>
    3c2c:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    3c36:      	movq	%rax, 0x35(%rsp)
    3c3b:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    3c45:      	movq	%rax, 0x30(%rsp)
    3c4a:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    3c54:      	movq	%rax, 0x28(%rsp)
    3c59:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    3c63:      	movq	%rax, 0x20(%rsp)
    3c68:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    3c72:      	movq	%rax, 0x18(%rsp)
    3c77:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3c81:      	movq	%rax, 0x10(%rsp)
    3c86:      	leaq	0x10(%rsp), %rdi
    3c8b:      	movl	$0x2d, %eax
    3c90:      	movl	$0x6, %ecx
    3c95:      	movzbl	0x11(%r15), %eax
    3c9a:      	addq	%rax, %r13
    3c9d:      	movl	$0x2d, %esi
    3ca2:      	jmp	0x487d <kprobe_unwind_php+0x487d>
    3ca7:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3cb1:      	movq	%rax, 0x36(%rsp)
    3cb6:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3cc0:      	movq	%rax, 0x30(%rsp)
    3cc5:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3ccf:      	movq	%rax, 0x28(%rsp)
    3cd4:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3cde:      	movq	%rax, 0x20(%rsp)
    3ce3:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3ced:      	movq	%rax, 0x18(%rsp)
    3cf2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3cfc:      	movq	%rax, 0x10(%rsp)
    3d01:      	leaq	0x10(%rsp), %rdi
    3d06:      	movl	$0x2e, %eax
    3d0b:      	movl	$0x6, %ecx
    3d10:      	movl	0x58(%rsp), %edx
    3d14:      	movl	$0x2e, %esi
    3d19:      	xorl	%eax, %eax
    3d1b:      	callq	*%rcx
    3d1d:      	cmpl	$0x23, 0x4(%rsp)
    3d22:      	je	0x2baa <kprobe_unwind_php+0x2baa>
    3d28:      	jmp	0x85e3 <kprobe_unwind_php+0x85e3>
    3d2d:      	movl	0xc(%rsp), %eax
    3d31:      	movl	%eax, 0x4(%rsp)
    3d35:      	movl	0x54(%rsp), %r13d
    3d3a:      	movq	(%rip), %rax            # 0x3d41 <kprobe_unwind_php+0x3d41>
    3d41:      	cmpl	$0x0, (%rax)
    3d44:      	jne	0x4889 <kprobe_unwind_php+0x4889>
    3d4a:      	movl	0x2c0(%rbp), %eax
    3d50:      	cmpq	$0x7e, %rax
    3d54:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    3d5a:      	movl	0x4(%rsp), %ecx
    3d5e:      	shlq	$0x20, %r13
    3d62:      	orq	%r13, %rcx
    3d65:      	movq	0x58(%rsp), %rdx
    3d6a:      	leal	0x1(%rax), %esi
    3d6d:      	movl	%esi, 0x2c0(%rbp)
    3d73:      	leaq	(%rax,%rax,2), %rax
    3d77:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    3d7f:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    3d87:      	movl	0x7c(%rsp), %ecx
    3d8b:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    3d92:      	jmp	0x3417 <kprobe_unwind_php+0x3417>
    3d97:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    3da1:      	movq	%rax, 0x38(%rsp)
    3da6:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    3db0:      	movq	%rax, 0x30(%rsp)
    3db5:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    3dbf:      	movq	%rax, 0x28(%rsp)
    3dc4:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    3dce:      	movq	%rax, 0x20(%rsp)
    3dd3:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    3ddd:      	movq	%rax, 0x18(%rsp)
    3de2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3dec:      	movq	%rax, 0x10(%rsp)
    3df1:      	movb	$0x0, 0x40(%rsp)
    3df6:      	leaq	0x10(%rsp), %rdi
    3dfb:      	movl	$0x31, %eax
    3e00:      	movl	$0x6, %ecx
    3e05:      	movq	0x58(%rsp), %rdx
    3e0a:      	movl	$0x31, %esi
    3e0f:      	xorl	%eax, %eax
    3e11:      	callq	*%rcx
    3e13:      	jmp	0x2b82 <kprobe_unwind_php+0x2b82>
    3e18:      	movzbl	0x15(%r15), %eax
    3e1d:      	addq	0x68(%rsp), %rax
    3e22:      	leaq	0xc(%rsp), %rdi
    3e27:      	movl	$0x4, %ecx
    3e2c:      	movl	$0x70, %r8d
    3e32:      	movzbl	0x15(%r15), %edx
    3e37:      	addq	0x68(%rsp), %rdx
    3e3c:      	movl	$0x4, %esi
    3e41:      	callq	*%r8
    3e44:      	testq	%rax, %rax
    3e47:      	je	0x403d <kprobe_unwind_php+0x403d>
    3e4d:      	movq	(%rip), %rax            # 0x3e54 <kprobe_unwind_php+0x3e54>
    3e54:      	movl	$0x27, 0x4(%rsp)
    3e5c:      	cmpl	$0x0, (%rax)
    3e5f:      	je	0x32d8 <kprobe_unwind_php+0x32d8>
    3e65:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    3e6f:      	movq	%rax, 0x40(%rsp)
    3e74:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    3e7e:      	movq	%rax, 0x38(%rsp)
    3e83:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    3e8d:      	movq	%rax, 0x30(%rsp)
    3e92:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    3e9c:      	movq	%rax, 0x28(%rsp)
    3ea1:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    3eab:      	movq	%rax, 0x20(%rsp)
    3eb0:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    3eba:      	movq	%rax, 0x18(%rsp)
    3ebf:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3ec9:      	movq	%rax, 0x10(%rsp)
    3ece:      	movb	$0x0, 0x48(%rsp)
    3ed3:      	leaq	0x10(%rsp), %rdi
    3ed8:      	movl	$0x39, %eax
    3edd:      	movl	$0x6, %ecx
    3ee2:      	movzbl	0x15(%r15), %edx
    3ee7:      	addq	0x68(%rsp), %rdx
    3eec:      	movl	$0x39, %esi
    3ef1:      	jmp	0x4880 <kprobe_unwind_php+0x4880>
    3ef6:      	movq	0x58(%rsp), %rax
    3efb:      	testq	%rax, %rax
    3efe:      	je	0x4108 <kprobe_unwind_php+0x4108>
    3f04:      	movzbl	0x14(%r15), %ecx
    3f09:      	addq	%rcx, %rax
    3f0c:      	leaq	0xb(%rsp), %rdi
    3f11:      	movl	$0x1, %ecx
    3f16:      	movl	$0x70, %r8d
    3f1c:      	movzbl	0x14(%r15), %edx
    3f21:      	addq	0x58(%rsp), %rdx
    3f26:      	movl	$0x1, %esi
    3f2b:      	callq	*%r8
    3f2e:      	testq	%rax, %rax
    3f31:      	je	0x4257 <kprobe_unwind_php+0x4257>
    3f37:      	movq	(%rip), %rax            # 0x3f3e <kprobe_unwind_php+0x3f3e>
    3f3e:      	cmpl	$0x0, (%rax)
    3f41:      	jne	0x5202 <kprobe_unwind_php+0x5202>
    3f47:      	movl	$0x26, 0x4(%rsp)
    3f4f:      	jmp	0x396f <kprobe_unwind_php+0x396f>
    3f54:      	movq	(%rip), %rax            # 0x3f5b <kprobe_unwind_php+0x3f5b>
    3f5b:      	cmpl	$0x0, (%rax)
    3f5e:      	jne	0x5112 <kprobe_unwind_php+0x5112>
    3f64:      	cmpl	$0x23, 0x4(%rsp)
    3f69:      	jne	0x85e3 <kprobe_unwind_php+0x85e3>
    3f6f:      	movzbl	0x12(%r15), %eax
    3f74:      	addq	0x70(%rsp), %rax
    3f79:      	leaq	0x70(%rsp), %rdi
    3f7e:      	movl	$0x8, %ecx
    3f83:      	movl	$0x70, %r8d
    3f89:      	movzbl	0x12(%r15), %edx
    3f8e:      	addq	0x70(%rsp), %rdx
    3f93:      	movl	$0x8, %esi
    3f98:      	callq	*%r8
    3f9b:      	testq	%rax, %rax
    3f9e:      	jne	0x317 <kprobe_unwind_php+0x317>
    3fa4:      	movq	0x70(%rsp), %r13
    3fa9:      	testq	%r13, %r13
    3fac:      	je	0x83ba <kprobe_unwind_php+0x83ba>
    3fb2:      	testb	$0x2, 0x56(%rsp)
    3fb7:      	jne	0x83ba <kprobe_unwind_php+0x83ba>
    3fbd:      	movzbl	0x10(%r15), %eax
    3fc2:      	addq	%r13, %rax
    3fc5:      	leaq	0x58(%rsp), %rdi
    3fca:      	movl	$0x8, %ecx
    3fcf:      	movl	$0x70, %r8d
    3fd5:      	movzbl	0x10(%r15), %edx
    3fda:      	addq	%r13, %rdx
    3fdd:      	movl	$0x8, %esi
    3fe2:      	callq	*%r8
    3fe5:      	testq	%rax, %rax
    3fe8:      	je	0x458d <kprobe_unwind_php+0x458d>
    3fee:      	movq	(%rip), %rax            # 0x3ff5 <kprobe_unwind_php+0x3ff5>
    3ff5:      	movl	$0x25, 0x4(%rsp)
    3ffd:      	cmpl	$0x0, (%rax)
    4000:      	jne	0x5283 <kprobe_unwind_php+0x5283>
    4006:      	movl	0x4(%rsp), %eax
    400a:      	movl	%eax, 0x58(%rsp)
    400e:      	movq	(%rip), %rdi            # 0x4015 <kprobe_unwind_php+0x4015>
    4015:      	leaq	0x58(%rsp), %rsi
    401a:      	movl	$0x1, %eax
    401f:      	callq	*%rax
    4021:      	testq	%rax, %rax
    4024:      	je	0x45eb <kprobe_unwind_php+0x45eb>
    402a:      	incq	(%rax)
    402d:      	cmpl	$0x23, 0x4(%rsp)
    4032:      	je	0x4606 <kprobe_unwind_php+0x4606>
    4038:      	jmp	0x85e3 <kprobe_unwind_php+0x85e3>
    403d:      	movzbl	0x13(%r15), %eax
    4042:      	addq	%r13, %rax
    4045:      	leaq	0x54(%rsp), %rdi
    404a:      	movl	$0x4, %ecx
    404f:      	movl	$0x70, %r8d
    4055:      	movzbl	0x13(%r15), %edx
    405a:      	addq	%r13, %rdx
    405d:      	movl	$0x4, %esi
    4062:      	callq	*%r8
    4065:      	testq	%rax, %rax
    4068:      	je	0x43c4 <kprobe_unwind_php+0x43c4>
    406e:      	movq	(%rip), %rax            # 0x4075 <kprobe_unwind_php+0x4075>
    4075:      	movl	$0x25, 0x4(%rsp)
    407d:      	cmpl	$0x0, (%rax)
    4080:      	je	0x32d8 <kprobe_unwind_php+0x32d8>
    4086:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    4090:      	movq	%rax, 0x3d(%rsp)
    4095:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    409f:      	movq	%rax, 0x38(%rsp)
    40a4:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    40ae:      	movq	%rax, 0x30(%rsp)
    40b3:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    40bd:      	movq	%rax, 0x28(%rsp)
    40c2:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    40cc:      	movq	%rax, 0x20(%rsp)
    40d1:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    40db:      	movq	%rax, 0x18(%rsp)
    40e0:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    40ea:      	movq	%rax, 0x10(%rsp)
    40ef:      	leaq	0x10(%rsp), %rdi
    40f4:      	movl	$0x35, %eax
    40f9:      	movl	$0x6, %ecx
    40fe:      	movl	$0x35, %esi
    4103:      	jmp	0x487d <kprobe_unwind_php+0x487d>
    4108:      	movl	0x2c0(%rbp), %eax
    410e:      	cmpq	$0x7e, %rax
    4112:      	ja	0x40e <kprobe_unwind_php+0x40e>
    4118:      	leal	0x1(%rax), %ecx
    411b:      	movl	%ecx, 0x2c0(%rbp)
    4121:      	leaq	(%rax,%rax,2), %rax
    4125:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    4131:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    413d:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    4145:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    4150:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    415b:      	movl	$0x23, 0x4(%rsp)
    4163:      	jmp	0x396f <kprobe_unwind_php+0x396f>
    4168:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    4172:      	movq	%rax, 0x38(%rsp)
    4177:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    4181:      	movq	%rax, 0x30(%rsp)
    4186:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    4190:      	movq	%rax, 0x28(%rsp)
    4195:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    419f:      	movq	%rax, 0x20(%rsp)
    41a4:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    41ae:      	movq	%rax, 0x18(%rsp)
    41b3:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    41bd:      	movq	%rax, 0x10(%rsp)
    41c2:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    41ca:      	leaq	0x10(%rsp), %rdi
    41cf:      	movl	$0x33, %eax
    41d4:      	movl	$0x6, %ecx
    41d9:      	movzbl	0x10(%r15), %eax
    41de:      	addq	%rax, %r13
    41e1:      	movl	$0x33, %esi
    41e6:      	movq	%r13, %rdx
    41e9:      	xorl	%eax, %eax
    41eb:      	callq	*%rcx
    41ed:      	jmp	0x2c41 <kprobe_unwind_php+0x2c41>
    41f2:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    41fc:      	movq	%rax, 0x1e(%rsp)
    4201:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    420b:      	movq	%rax, 0x18(%rsp)
    4210:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    421a:      	movq	%rax, 0x10(%rsp)
    421f:      	leaq	0x10(%rsp), %rdi
    4224:      	movl	$0x16, %eax
    4229:      	movl	$0x6, %r8d
    422f:      	movq	0x58(%rsp), %rdx
    4234:      	movl	0xc(%rsp), %ecx
    4238:      	movl	$0x16, %esi
    423d:      	xorl	%eax, %eax
    423f:      	callq	*%r8
    4242:      	movl	0x2c0(%rbp), %eax
    4248:      	cmpq	$0x7e, %rax
    424c:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    4252:      	jmp	0x36c3 <kprobe_unwind_php+0x36c3>
    4257:      	movl	$0x0, 0xc(%rsp)
    425f:      	movzbl	0xb(%rsp), %eax
    4264:      	cmpl	$0x4, %eax
    4267:      	je	0x427a <kprobe_unwind_php+0x427a>
    4269:      	movl	$0x0, 0x4(%rsp)
    4271:      	cmpl	$0x2, %eax
    4274:      	jne	0x4a63 <kprobe_unwind_php+0x4a63>
    427a:      	movzbl	0x11(%r15), %eax
    427f:      	addq	%r13, %rax
    4282:      	leaq	0x68(%rsp), %rdi
    4287:      	movl	$0x8, %ecx
    428c:      	movl	$0x70, %r8d
    4292:      	movzbl	0x11(%r15), %edx
    4297:      	addq	%r13, %rdx
    429a:      	movl	$0x8, %esi
    429f:      	callq	*%r8
    42a2:      	testq	%rax, %rax
    42a5:      	je	0x44af <kprobe_unwind_php+0x44af>
    42ab:      	movq	(%rip), %rax            # 0x42b2 <kprobe_unwind_php+0x42b2>
    42b2:      	movl	$0x25, 0x4(%rsp)
    42ba:      	cmpl	$0x0, (%rax)
    42bd:      	je	0x396f <kprobe_unwind_php+0x396f>
    42c3:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    42cd:      	movq	%rax, 0x35(%rsp)
    42d2:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    42dc:      	movq	%rax, 0x30(%rsp)
    42e1:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    42eb:      	movq	%rax, 0x28(%rsp)
    42f0:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    42fa:      	movq	%rax, 0x20(%rsp)
    42ff:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    4309:      	movq	%rax, 0x18(%rsp)
    430e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4318:      	movq	%rax, 0x10(%rsp)
    431d:      	leaq	0x10(%rsp), %rdi
    4322:      	movl	$0x2d, %eax
    4327:      	movl	$0x6, %ecx
    432c:      	movzbl	0x11(%r15), %eax
    4331:      	addq	%rax, %r13
    4334:      	movl	$0x2d, %esi
    4339:      	jmp	0x4fba <kprobe_unwind_php+0x4fba>
    433e:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4348:      	movq	%rax, 0x36(%rsp)
    434d:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4357:      	movq	%rax, 0x30(%rsp)
    435c:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4366:      	movq	%rax, 0x28(%rsp)
    436b:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4375:      	movq	%rax, 0x20(%rsp)
    437a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4384:      	movq	%rax, 0x18(%rsp)
    4389:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4393:      	movq	%rax, 0x10(%rsp)
    4398:      	leaq	0x10(%rsp), %rdi
    439d:      	movl	$0x2e, %eax
    43a2:      	movl	$0x6, %ecx
    43a7:      	movl	0x58(%rsp), %edx
    43ab:      	movl	$0x2e, %esi
    43b0:      	xorl	%eax, %eax
    43b2:      	callq	*%rcx
    43b4:      	cmpl	$0x23, 0x4(%rsp)
    43b9:      	je	0x3241 <kprobe_unwind_php+0x3241>
    43bf:      	jmp	0x85e3 <kprobe_unwind_php+0x85e3>
    43c4:      	movl	0xc(%rsp), %eax
    43c8:      	movl	%eax, 0x4(%rsp)
    43cc:      	movl	0x54(%rsp), %r13d
    43d1:      	movq	(%rip), %rax            # 0x43d8 <kprobe_unwind_php+0x43d8>
    43d8:      	cmpl	$0x0, (%rax)
    43db:      	jne	0x4fc6 <kprobe_unwind_php+0x4fc6>
    43e1:      	movl	0x2c0(%rbp), %eax
    43e7:      	cmpq	$0x7e, %rax
    43eb:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    43f1:      	movl	0x4(%rsp), %ecx
    43f5:      	shlq	$0x20, %r13
    43f9:      	orq	%r13, %rcx
    43fc:      	movq	0x58(%rsp), %rdx
    4401:      	leal	0x1(%rax), %esi
    4404:      	movl	%esi, 0x2c0(%rbp)
    440a:      	leaq	(%rax,%rax,2), %rax
    440e:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    4416:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    441e:      	movl	0x7c(%rsp), %ecx
    4422:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    4429:      	jmp	0x3aae <kprobe_unwind_php+0x3aae>
    442e:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    4438:      	movq	%rax, 0x38(%rsp)
    443d:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    4447:      	movq	%rax, 0x30(%rsp)
    444c:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    4456:      	movq	%rax, 0x28(%rsp)
    445b:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    4465:      	movq	%rax, 0x20(%rsp)
    446a:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    4474:      	movq	%rax, 0x18(%rsp)
    4479:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4483:      	movq	%rax, 0x10(%rsp)
    4488:      	movb	$0x0, 0x40(%rsp)
    448d:      	leaq	0x10(%rsp), %rdi
    4492:      	movl	$0x31, %eax
    4497:      	movl	$0x6, %ecx
    449c:      	movq	0x58(%rsp), %rdx
    44a1:      	movl	$0x31, %esi
    44a6:      	xorl	%eax, %eax
    44a8:      	callq	*%rcx
    44aa:      	jmp	0x3219 <kprobe_unwind_php+0x3219>
    44af:      	movzbl	0x15(%r15), %eax
    44b4:      	addq	0x68(%rsp), %rax
    44b9:      	leaq	0xc(%rsp), %rdi
    44be:      	movl	$0x4, %ecx
    44c3:      	movl	$0x70, %r8d
    44c9:      	movzbl	0x15(%r15), %edx
    44ce:      	addq	0x68(%rsp), %rdx
    44d3:      	movl	$0x4, %esi
    44d8:      	callq	*%r8
    44db:      	testq	%rax, %rax
    44de:      	je	0x46d4 <kprobe_unwind_php+0x46d4>
    44e4:      	movq	(%rip), %rax            # 0x44eb <kprobe_unwind_php+0x44eb>
    44eb:      	movl	$0x27, 0x4(%rsp)
    44f3:      	cmpl	$0x0, (%rax)
    44f6:      	je	0x396f <kprobe_unwind_php+0x396f>
    44fc:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    4506:      	movq	%rax, 0x40(%rsp)
    450b:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    4515:      	movq	%rax, 0x38(%rsp)
    451a:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    4524:      	movq	%rax, 0x30(%rsp)
    4529:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    4533:      	movq	%rax, 0x28(%rsp)
    4538:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    4542:      	movq	%rax, 0x20(%rsp)
    4547:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    4551:      	movq	%rax, 0x18(%rsp)
    4556:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4560:      	movq	%rax, 0x10(%rsp)
    4565:      	movb	$0x0, 0x48(%rsp)
    456a:      	leaq	0x10(%rsp), %rdi
    456f:      	movl	$0x39, %eax
    4574:      	movl	$0x6, %ecx
    4579:      	movzbl	0x15(%r15), %edx
    457e:      	addq	0x68(%rsp), %rdx
    4583:      	movl	$0x39, %esi
    4588:      	jmp	0x4fbd <kprobe_unwind_php+0x4fbd>
    458d:      	movq	0x58(%rsp), %rax
    4592:      	testq	%rax, %rax
    4595:      	je	0x479f <kprobe_unwind_php+0x479f>
    459b:      	movzbl	0x14(%r15), %ecx
    45a0:      	addq	%rcx, %rax
    45a3:      	leaq	0xb(%rsp), %rdi
    45a8:      	movl	$0x1, %ecx
    45ad:      	movl	$0x70, %r8d
    45b3:      	movzbl	0x14(%r15), %edx
    45b8:      	addq	0x58(%rsp), %rdx
    45bd:      	movl	$0x1, %esi
    45c2:      	callq	*%r8
    45c5:      	testq	%rax, %rax
    45c8:      	je	0x48ee <kprobe_unwind_php+0x48ee>
    45ce:      	movq	(%rip), %rax            # 0x45d5 <kprobe_unwind_php+0x45d5>
    45d5:      	cmpl	$0x0, (%rax)
    45d8:      	jne	0x530d <kprobe_unwind_php+0x530d>
    45de:      	movl	$0x26, 0x4(%rsp)
    45e6:      	jmp	0x4006 <kprobe_unwind_php+0x4006>
    45eb:      	movq	(%rip), %rax            # 0x45f2 <kprobe_unwind_php+0x45f2>
    45f2:      	cmpl	$0x0, (%rax)
    45f5:      	jne	0x538e <kprobe_unwind_php+0x538e>
    45fb:      	cmpl	$0x23, 0x4(%rsp)
    4600:      	jne	0x85e3 <kprobe_unwind_php+0x85e3>
    4606:      	movzbl	0x12(%r15), %eax
    460b:      	addq	0x70(%rsp), %rax
    4610:      	leaq	0x70(%rsp), %rdi
    4615:      	movl	$0x8, %ecx
    461a:      	movl	$0x70, %r8d
    4620:      	movzbl	0x12(%r15), %edx
    4625:      	addq	0x70(%rsp), %rdx
    462a:      	movl	$0x8, %esi
    462f:      	callq	*%r8
    4632:      	testq	%rax, %rax
    4635:      	jne	0x317 <kprobe_unwind_php+0x317>
    463b:      	movq	0x70(%rsp), %r13
    4640:      	testq	%r13, %r13
    4643:      	je	0x83ba <kprobe_unwind_php+0x83ba>
    4649:      	testb	$0x2, 0x56(%rsp)
    464e:      	jne	0x83ba <kprobe_unwind_php+0x83ba>
    4654:      	movzbl	0x10(%r15), %eax
    4659:      	addq	%r13, %rax
    465c:      	leaq	0x58(%rsp), %rdi
    4661:      	movl	$0x8, %ecx
    4666:      	movl	$0x70, %r8d
    466c:      	movzbl	0x10(%r15), %edx
    4671:      	addq	%r13, %rdx
    4674:      	movl	$0x8, %esi
    4679:      	callq	*%r8
    467c:      	testq	%rax, %rax
    467f:      	je	0x4c24 <kprobe_unwind_php+0x4c24>
    4685:      	movq	(%rip), %rax            # 0x468c <kprobe_unwind_php+0x468c>
    468c:      	movl	$0x25, 0x4(%rsp)
    4694:      	cmpl	$0x0, (%rax)
    4697:      	jne	0x5414 <kprobe_unwind_php+0x5414>
    469d:      	movl	0x4(%rsp), %eax
    46a1:      	movl	%eax, 0x58(%rsp)
    46a5:      	movq	(%rip), %rdi            # 0x46ac <kprobe_unwind_php+0x46ac>
    46ac:      	leaq	0x58(%rsp), %rsi
    46b1:      	movl	$0x1, %eax
    46b6:      	callq	*%rax
    46b8:      	testq	%rax, %rax
    46bb:      	je	0x4cfa <kprobe_unwind_php+0x4cfa>
    46c1:      	incq	(%rax)
    46c4:      	cmpl	$0x23, 0x4(%rsp)
    46c9:      	je	0x4d15 <kprobe_unwind_php+0x4d15>
    46cf:      	jmp	0x85e3 <kprobe_unwind_php+0x85e3>
    46d4:      	movzbl	0x13(%r15), %eax
    46d9:      	addq	%r13, %rax
    46dc:      	leaq	0x54(%rsp), %rdi
    46e1:      	movl	$0x4, %ecx
    46e6:      	movl	$0x70, %r8d
    46ec:      	movzbl	0x13(%r15), %edx
    46f1:      	addq	%r13, %rdx
    46f4:      	movl	$0x4, %esi
    46f9:      	callq	*%r8
    46fc:      	testq	%rax, %rax
    46ff:      	je	0x4a5b <kprobe_unwind_php+0x4a5b>
    4705:      	movq	(%rip), %rax            # 0x470c <kprobe_unwind_php+0x470c>
    470c:      	movl	$0x25, 0x4(%rsp)
    4714:      	cmpl	$0x0, (%rax)
    4717:      	je	0x396f <kprobe_unwind_php+0x396f>
    471d:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    4727:      	movq	%rax, 0x3d(%rsp)
    472c:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    4736:      	movq	%rax, 0x38(%rsp)
    473b:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    4745:      	movq	%rax, 0x30(%rsp)
    474a:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    4754:      	movq	%rax, 0x28(%rsp)
    4759:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    4763:      	movq	%rax, 0x20(%rsp)
    4768:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    4772:      	movq	%rax, 0x18(%rsp)
    4777:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4781:      	movq	%rax, 0x10(%rsp)
    4786:      	leaq	0x10(%rsp), %rdi
    478b:      	movl	$0x35, %eax
    4790:      	movl	$0x6, %ecx
    4795:      	movl	$0x35, %esi
    479a:      	jmp	0x4fba <kprobe_unwind_php+0x4fba>
    479f:      	movl	0x2c0(%rbp), %eax
    47a5:      	cmpq	$0x7e, %rax
    47a9:      	ja	0x40e <kprobe_unwind_php+0x40e>
    47af:      	leal	0x1(%rax), %ecx
    47b2:      	movl	%ecx, 0x2c0(%rbp)
    47b8:      	leaq	(%rax,%rax,2), %rax
    47bc:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    47c8:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    47d4:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    47dc:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    47e7:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    47f2:      	movl	$0x23, 0x4(%rsp)
    47fa:      	jmp	0x4006 <kprobe_unwind_php+0x4006>
    47ff:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    4809:      	movq	%rax, 0x38(%rsp)
    480e:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    4818:      	movq	%rax, 0x30(%rsp)
    481d:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    4827:      	movq	%rax, 0x28(%rsp)
    482c:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    4836:      	movq	%rax, 0x20(%rsp)
    483b:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    4845:      	movq	%rax, 0x18(%rsp)
    484a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4854:      	movq	%rax, 0x10(%rsp)
    4859:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    4861:      	leaq	0x10(%rsp), %rdi
    4866:      	movl	$0x33, %eax
    486b:      	movl	$0x6, %ecx
    4870:      	movzbl	0x10(%r15), %eax
    4875:      	addq	%rax, %r13
    4878:      	movl	$0x33, %esi
    487d:      	movq	%r13, %rdx
    4880:      	xorl	%eax, %eax
    4882:      	callq	*%rcx
    4884:      	jmp	0x32d8 <kprobe_unwind_php+0x32d8>
    4889:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    4893:      	movq	%rax, 0x1e(%rsp)
    4898:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    48a2:      	movq	%rax, 0x18(%rsp)
    48a7:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    48b1:      	movq	%rax, 0x10(%rsp)
    48b6:      	leaq	0x10(%rsp), %rdi
    48bb:      	movl	$0x16, %eax
    48c0:      	movl	$0x6, %r8d
    48c6:      	movq	0x58(%rsp), %rdx
    48cb:      	movl	0xc(%rsp), %ecx
    48cf:      	movl	$0x16, %esi
    48d4:      	xorl	%eax, %eax
    48d6:      	callq	*%r8
    48d9:      	movl	0x2c0(%rbp), %eax
    48df:      	cmpq	$0x7e, %rax
    48e3:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    48e9:      	jmp	0x3d5a <kprobe_unwind_php+0x3d5a>
    48ee:      	movl	$0x0, 0xc(%rsp)
    48f6:      	movzbl	0xb(%rsp), %eax
    48fb:      	cmpl	$0x4, %eax
    48fe:      	je	0x4911 <kprobe_unwind_php+0x4911>
    4900:      	movl	$0x0, 0x4(%rsp)
    4908:      	cmpl	$0x2, %eax
    490b:      	jne	0x51a0 <kprobe_unwind_php+0x51a0>
    4911:      	movzbl	0x11(%r15), %eax
    4916:      	addq	%r13, %rax
    4919:      	leaq	0x68(%rsp), %rdi
    491e:      	movl	$0x8, %ecx
    4923:      	movl	$0x70, %r8d
    4929:      	movzbl	0x11(%r15), %edx
    492e:      	addq	%r13, %rdx
    4931:      	movl	$0x8, %esi
    4936:      	callq	*%r8
    4939:      	testq	%rax, %rax
    493c:      	je	0x4b46 <kprobe_unwind_php+0x4b46>
    4942:      	movq	(%rip), %rax            # 0x4949 <kprobe_unwind_php+0x4949>
    4949:      	movl	$0x25, 0x4(%rsp)
    4951:      	cmpl	$0x0, (%rax)
    4954:      	je	0x4006 <kprobe_unwind_php+0x4006>
    495a:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    4964:      	movq	%rax, 0x35(%rsp)
    4969:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    4973:      	movq	%rax, 0x30(%rsp)
    4978:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    4982:      	movq	%rax, 0x28(%rsp)
    4987:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    4991:      	movq	%rax, 0x20(%rsp)
    4996:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    49a0:      	movq	%rax, 0x18(%rsp)
    49a5:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    49af:      	movq	%rax, 0x10(%rsp)
    49b4:      	leaq	0x10(%rsp), %rdi
    49b9:      	movl	$0x2d, %eax
    49be:      	movl	$0x6, %ecx
    49c3:      	movzbl	0x11(%r15), %eax
    49c8:      	addq	%rax, %r13
    49cb:      	movl	$0x2d, %esi
    49d0:      	jmp	0x5301 <kprobe_unwind_php+0x5301>
    49d5:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    49df:      	movq	%rax, 0x36(%rsp)
    49e4:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    49ee:      	movq	%rax, 0x30(%rsp)
    49f3:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    49fd:      	movq	%rax, 0x28(%rsp)
    4a02:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4a0c:      	movq	%rax, 0x20(%rsp)
    4a11:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4a1b:      	movq	%rax, 0x18(%rsp)
    4a20:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4a2a:      	movq	%rax, 0x10(%rsp)
    4a2f:      	leaq	0x10(%rsp), %rdi
    4a34:      	movl	$0x2e, %eax
    4a39:      	movl	$0x6, %ecx
    4a3e:      	movl	0x58(%rsp), %edx
    4a42:      	movl	$0x2e, %esi
    4a47:      	xorl	%eax, %eax
    4a49:      	callq	*%rcx
    4a4b:      	cmpl	$0x23, 0x4(%rsp)
    4a50:      	je	0x38d8 <kprobe_unwind_php+0x38d8>
    4a56:      	jmp	0x85e3 <kprobe_unwind_php+0x85e3>
    4a5b:      	movl	0xc(%rsp), %eax
    4a5f:      	movl	%eax, 0x4(%rsp)
    4a63:      	movl	0x54(%rsp), %r13d
    4a68:      	movq	(%rip), %rax            # 0x4a6f <kprobe_unwind_php+0x4a6f>
    4a6f:      	cmpl	$0x0, (%rax)
    4a72:      	jne	0x5497 <kprobe_unwind_php+0x5497>
    4a78:      	movl	0x2c0(%rbp), %eax
    4a7e:      	cmpq	$0x7e, %rax
    4a82:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    4a88:      	movl	0x4(%rsp), %ecx
    4a8c:      	shlq	$0x20, %r13
    4a90:      	orq	%r13, %rcx
    4a93:      	movq	0x58(%rsp), %rdx
    4a98:      	leal	0x1(%rax), %esi
    4a9b:      	movl	%esi, 0x2c0(%rbp)
    4aa1:      	leaq	(%rax,%rax,2), %rax
    4aa5:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    4aad:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    4ab5:      	movl	0x7c(%rsp), %ecx
    4ab9:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    4ac0:      	jmp	0x4145 <kprobe_unwind_php+0x4145>
    4ac5:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    4acf:      	movq	%rax, 0x38(%rsp)
    4ad4:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    4ade:      	movq	%rax, 0x30(%rsp)
    4ae3:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    4aed:      	movq	%rax, 0x28(%rsp)
    4af2:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    4afc:      	movq	%rax, 0x20(%rsp)
    4b01:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    4b0b:      	movq	%rax, 0x18(%rsp)
    4b10:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4b1a:      	movq	%rax, 0x10(%rsp)
    4b1f:      	movb	$0x0, 0x40(%rsp)
    4b24:      	leaq	0x10(%rsp), %rdi
    4b29:      	movl	$0x31, %eax
    4b2e:      	movl	$0x6, %ecx
    4b33:      	movq	0x58(%rsp), %rdx
    4b38:      	movl	$0x31, %esi
    4b3d:      	xorl	%eax, %eax
    4b3f:      	callq	*%rcx
    4b41:      	jmp	0x38b0 <kprobe_unwind_php+0x38b0>
    4b46:      	movzbl	0x15(%r15), %eax
    4b4b:      	addq	0x68(%rsp), %rax
    4b50:      	leaq	0xc(%rsp), %rdi
    4b55:      	movl	$0x4, %ecx
    4b5a:      	movl	$0x70, %r8d
    4b60:      	movzbl	0x15(%r15), %edx
    4b65:      	addq	0x68(%rsp), %rdx
    4b6a:      	movl	$0x4, %esi
    4b6f:      	callq	*%r8
    4b72:      	testq	%rax, %rax
    4b75:      	je	0x4e2f <kprobe_unwind_php+0x4e2f>
    4b7b:      	movq	(%rip), %rax            # 0x4b82 <kprobe_unwind_php+0x4b82>
    4b82:      	movl	$0x27, 0x4(%rsp)
    4b8a:      	cmpl	$0x0, (%rax)
    4b8d:      	je	0x4006 <kprobe_unwind_php+0x4006>
    4b93:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    4b9d:      	movq	%rax, 0x40(%rsp)
    4ba2:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    4bac:      	movq	%rax, 0x38(%rsp)
    4bb1:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    4bbb:      	movq	%rax, 0x30(%rsp)
    4bc0:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    4bca:      	movq	%rax, 0x28(%rsp)
    4bcf:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    4bd9:      	movq	%rax, 0x20(%rsp)
    4bde:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    4be8:      	movq	%rax, 0x18(%rsp)
    4bed:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4bf7:      	movq	%rax, 0x10(%rsp)
    4bfc:      	movb	$0x0, 0x48(%rsp)
    4c01:      	leaq	0x10(%rsp), %rdi
    4c06:      	movl	$0x39, %eax
    4c0b:      	movl	$0x6, %ecx
    4c10:      	movzbl	0x15(%r15), %edx
    4c15:      	addq	0x68(%rsp), %rdx
    4c1a:      	movl	$0x39, %esi
    4c1f:      	jmp	0x5304 <kprobe_unwind_php+0x5304>
    4c24:      	movq	0x58(%rsp), %rax
    4c29:      	testq	%rax, %rax
    4c2c:      	je	0x4efa <kprobe_unwind_php+0x4efa>
    4c32:      	movzbl	0x14(%r15), %ecx
    4c37:      	addq	%rcx, %rax
    4c3a:      	leaq	0xb(%rsp), %rdi
    4c3f:      	movl	$0x1, %ecx
    4c44:      	movl	$0x70, %r8d
    4c4a:      	movzbl	0x14(%r15), %edx
    4c4f:      	addq	0x58(%rsp), %rdx
    4c54:      	movl	$0x1, %esi
    4c59:      	callq	*%r8
    4c5c:      	testq	%rax, %rax
    4c5f:      	je	0x502b <kprobe_unwind_php+0x502b>
    4c65:      	movq	(%rip), %rax            # 0x4c6c <kprobe_unwind_php+0x4c6c>
    4c6c:      	cmpl	$0x0, (%rax)
    4c6f:      	je	0x4ced <kprobe_unwind_php+0x4ced>
    4c71:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    4c7b:      	movq	%rax, 0x38(%rsp)
    4c80:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    4c8a:      	movq	%rax, 0x30(%rsp)
    4c8f:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    4c99:      	movq	%rax, 0x28(%rsp)
    4c9e:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    4ca8:      	movq	%rax, 0x20(%rsp)
    4cad:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    4cb7:      	movq	%rax, 0x18(%rsp)
    4cbc:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4cc6:      	movq	%rax, 0x10(%rsp)
    4ccb:      	movb	$0x0, 0x40(%rsp)
    4cd0:      	leaq	0x10(%rsp), %rdi
    4cd5:      	movl	$0x31, %eax
    4cda:      	movl	$0x6, %ecx
    4cdf:      	movq	0x58(%rsp), %rdx
    4ce4:      	movl	$0x31, %esi
    4ce9:      	xorl	%eax, %eax
    4ceb:      	callq	*%rcx
    4ced:      	movl	$0x26, 0x4(%rsp)
    4cf5:      	jmp	0x469d <kprobe_unwind_php+0x469d>
    4cfa:      	movq	(%rip), %rax            # 0x4d01 <kprobe_unwind_php+0x4d01>
    4d01:      	cmpl	$0x0, (%rax)
    4d04:      	jne	0x54fc <kprobe_unwind_php+0x54fc>
    4d0a:      	cmpl	$0x23, 0x4(%rsp)
    4d0f:      	jne	0x85e3 <kprobe_unwind_php+0x85e3>
    4d15:      	movzbl	0x12(%r15), %eax
    4d1a:      	addq	0x70(%rsp), %rax
    4d1f:      	leaq	0x70(%rsp), %rdi
    4d24:      	movl	$0x8, %ecx
    4d29:      	movl	$0x70, %r8d
    4d2f:      	movzbl	0x12(%r15), %edx
    4d34:      	addq	0x70(%rsp), %rdx
    4d39:      	movl	$0x8, %esi
    4d3e:      	callq	*%r8
    4d41:      	testq	%rax, %rax
    4d44:      	jne	0x317 <kprobe_unwind_php+0x317>
    4d4a:      	movq	0x70(%rsp), %r13
    4d4f:      	testq	%r13, %r13
    4d52:      	je	0x83ba <kprobe_unwind_php+0x83ba>
    4d58:      	testb	$0x2, 0x56(%rsp)
    4d5d:      	jne	0x83ba <kprobe_unwind_php+0x83ba>
    4d63:      	movzbl	0x10(%r15), %eax
    4d68:      	addq	%r13, %rax
    4d6b:      	leaq	0x58(%rsp), %rdi
    4d70:      	movl	$0x8, %ecx
    4d75:      	movl	$0x70, %r8d
    4d7b:      	movzbl	0x10(%r15), %edx
    4d80:      	addq	%r13, %rdx
    4d83:      	movl	$0x8, %esi
    4d88:      	callq	*%r8
    4d8b:      	testq	%rax, %rax
    4d8e:      	je	0x5582 <kprobe_unwind_php+0x5582>
    4d94:      	movq	(%rip), %rax            # 0x4d9b <kprobe_unwind_php+0x4d9b>
    4d9b:      	movl	$0x25, 0x4(%rsp)
    4da3:      	cmpl	$0x0, (%rax)
    4da6:      	je	0x5ce9 <kprobe_unwind_php+0x5ce9>
    4dac:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    4db6:      	movq	%rax, 0x38(%rsp)
    4dbb:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    4dc5:      	movq	%rax, 0x30(%rsp)
    4dca:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    4dd4:      	movq	%rax, 0x28(%rsp)
    4dd9:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    4de3:      	movq	%rax, 0x20(%rsp)
    4de8:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    4df2:      	movq	%rax, 0x18(%rsp)
    4df7:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4e01:      	movq	%rax, 0x10(%rsp)
    4e06:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    4e0e:      	leaq	0x10(%rsp), %rdi
    4e13:      	movl	$0x33, %eax
    4e18:      	movl	$0x6, %ecx
    4e1d:      	movzbl	0x10(%r15), %eax
    4e22:      	addq	%rax, %r13
    4e25:      	movl	$0x33, %esi
    4e2a:      	jmp	0x5c0e <kprobe_unwind_php+0x5c0e>
    4e2f:      	movzbl	0x13(%r15), %eax
    4e34:      	addq	%r13, %rax
    4e37:      	leaq	0x54(%rsp), %rdi
    4e3c:      	movl	$0x4, %ecx
    4e41:      	movl	$0x70, %r8d
    4e47:      	movzbl	0x13(%r15), %edx
    4e4c:      	addq	%r13, %rdx
    4e4f:      	movl	$0x4, %esi
    4e54:      	callq	*%r8
    4e57:      	testq	%rax, %rax
    4e5a:      	je	0x5198 <kprobe_unwind_php+0x5198>
    4e60:      	movq	(%rip), %rax            # 0x4e67 <kprobe_unwind_php+0x4e67>
    4e67:      	movl	$0x25, 0x4(%rsp)
    4e6f:      	cmpl	$0x0, (%rax)
    4e72:      	je	0x4006 <kprobe_unwind_php+0x4006>
    4e78:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    4e82:      	movq	%rax, 0x3d(%rsp)
    4e87:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    4e91:      	movq	%rax, 0x38(%rsp)
    4e96:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    4ea0:      	movq	%rax, 0x30(%rsp)
    4ea5:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    4eaf:      	movq	%rax, 0x28(%rsp)
    4eb4:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    4ebe:      	movq	%rax, 0x20(%rsp)
    4ec3:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    4ecd:      	movq	%rax, 0x18(%rsp)
    4ed2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4edc:      	movq	%rax, 0x10(%rsp)
    4ee1:      	leaq	0x10(%rsp), %rdi
    4ee6:      	movl	$0x35, %eax
    4eeb:      	movl	$0x6, %ecx
    4ef0:      	movl	$0x35, %esi
    4ef5:      	jmp	0x5301 <kprobe_unwind_php+0x5301>
    4efa:      	movl	0x2c0(%rbp), %eax
    4f00:      	cmpq	$0x7e, %rax
    4f04:      	ja	0x40e <kprobe_unwind_php+0x40e>
    4f0a:      	leal	0x1(%rax), %ecx
    4f0d:      	movl	%ecx, 0x2c0(%rbp)
    4f13:      	leaq	(%rax,%rax,2), %rax
    4f17:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    4f23:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    4f2f:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    4f37:      	jmp	0x5b25 <kprobe_unwind_php+0x5b25>
    4f3c:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    4f46:      	movq	%rax, 0x38(%rsp)
    4f4b:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    4f55:      	movq	%rax, 0x30(%rsp)
    4f5a:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    4f64:      	movq	%rax, 0x28(%rsp)
    4f69:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    4f73:      	movq	%rax, 0x20(%rsp)
    4f78:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    4f82:      	movq	%rax, 0x18(%rsp)
    4f87:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4f91:      	movq	%rax, 0x10(%rsp)
    4f96:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    4f9e:      	leaq	0x10(%rsp), %rdi
    4fa3:      	movl	$0x33, %eax
    4fa8:      	movl	$0x6, %ecx
    4fad:      	movzbl	0x10(%r15), %eax
    4fb2:      	addq	%rax, %r13
    4fb5:      	movl	$0x33, %esi
    4fba:      	movq	%r13, %rdx
    4fbd:      	xorl	%eax, %eax
    4fbf:      	callq	*%rcx
    4fc1:      	jmp	0x396f <kprobe_unwind_php+0x396f>
    4fc6:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    4fd0:      	movq	%rax, 0x1e(%rsp)
    4fd5:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    4fdf:      	movq	%rax, 0x18(%rsp)
    4fe4:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    4fee:      	movq	%rax, 0x10(%rsp)
    4ff3:      	leaq	0x10(%rsp), %rdi
    4ff8:      	movl	$0x16, %eax
    4ffd:      	movl	$0x6, %r8d
    5003:      	movq	0x58(%rsp), %rdx
    5008:      	movl	0xc(%rsp), %ecx
    500c:      	movl	$0x16, %esi
    5011:      	xorl	%eax, %eax
    5013:      	callq	*%r8
    5016:      	movl	0x2c0(%rbp), %eax
    501c:      	cmpq	$0x7e, %rax
    5020:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    5026:      	jmp	0x43f1 <kprobe_unwind_php+0x43f1>
    502b:      	movl	$0x0, 0xc(%rsp)
    5033:      	movzbl	0xb(%rsp), %eax
    5038:      	cmpl	$0x4, %eax
    503b:      	je	0x504e <kprobe_unwind_php+0x504e>
    503d:      	movl	$0x0, 0x4(%rsp)
    5045:      	cmpl	$0x2, %eax
    5048:      	jne	0x5a7c <kprobe_unwind_php+0x5a7c>
    504e:      	movzbl	0x11(%r15), %eax
    5053:      	addq	%r13, %rax
    5056:      	leaq	0x68(%rsp), %rdi
    505b:      	movl	$0x8, %ecx
    5060:      	movl	$0x70, %r8d
    5066:      	movzbl	0x11(%r15), %edx
    506b:      	addq	%r13, %rdx
    506e:      	movl	$0x8, %esi
    5073:      	callq	*%r8
    5076:      	testq	%rax, %rax
    5079:      	je	0x5658 <kprobe_unwind_php+0x5658>
    507f:      	movq	(%rip), %rax            # 0x5086 <kprobe_unwind_php+0x5086>
    5086:      	movl	$0x25, 0x4(%rsp)
    508e:      	cmpl	$0x0, (%rax)
    5091:      	je	0x469d <kprobe_unwind_php+0x469d>
    5097:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    50a1:      	movq	%rax, 0x35(%rsp)
    50a6:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    50b0:      	movq	%rax, 0x30(%rsp)
    50b5:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    50bf:      	movq	%rax, 0x28(%rsp)
    50c4:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    50ce:      	movq	%rax, 0x20(%rsp)
    50d3:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    50dd:      	movq	%rax, 0x18(%rsp)
    50e2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    50ec:      	movq	%rax, 0x10(%rsp)
    50f1:      	leaq	0x10(%rsp), %rdi
    50f6:      	movl	$0x2d, %eax
    50fb:      	movl	$0x6, %ecx
    5100:      	movzbl	0x11(%r15), %eax
    5105:      	addq	%rax, %r13
    5108:      	movl	$0x2d, %esi
    510d:      	jmp	0x598a <kprobe_unwind_php+0x598a>
    5112:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    511c:      	movq	%rax, 0x36(%rsp)
    5121:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    512b:      	movq	%rax, 0x30(%rsp)
    5130:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    513a:      	movq	%rax, 0x28(%rsp)
    513f:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5149:      	movq	%rax, 0x20(%rsp)
    514e:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5158:      	movq	%rax, 0x18(%rsp)
    515d:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5167:      	movq	%rax, 0x10(%rsp)
    516c:      	leaq	0x10(%rsp), %rdi
    5171:      	movl	$0x2e, %eax
    5176:      	movl	$0x6, %ecx
    517b:      	movl	0x58(%rsp), %edx
    517f:      	movl	$0x2e, %esi
    5184:      	xorl	%eax, %eax
    5186:      	callq	*%rcx
    5188:      	cmpl	$0x23, 0x4(%rsp)
    518d:      	je	0x3f6f <kprobe_unwind_php+0x3f6f>
    5193:      	jmp	0x85e3 <kprobe_unwind_php+0x85e3>
    5198:      	movl	0xc(%rsp), %eax
    519c:      	movl	%eax, 0x4(%rsp)
    51a0:      	movl	0x54(%rsp), %r13d
    51a5:      	movq	(%rip), %rax            # 0x51ac <kprobe_unwind_php+0x51ac>
    51ac:      	cmpl	$0x0, (%rax)
    51af:      	jne	0x5736 <kprobe_unwind_php+0x5736>
    51b5:      	movl	0x2c0(%rbp), %eax
    51bb:      	cmpq	$0x7e, %rax
    51bf:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    51c5:      	movl	0x4(%rsp), %ecx
    51c9:      	shlq	$0x20, %r13
    51cd:      	orq	%r13, %rcx
    51d0:      	movq	0x58(%rsp), %rdx
    51d5:      	leal	0x1(%rax), %esi
    51d8:      	movl	%esi, 0x2c0(%rbp)
    51de:      	leaq	(%rax,%rax,2), %rax
    51e2:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    51ea:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    51f2:      	movl	0x7c(%rsp), %ecx
    51f6:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    51fd:      	jmp	0x47dc <kprobe_unwind_php+0x47dc>
    5202:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    520c:      	movq	%rax, 0x38(%rsp)
    5211:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    521b:      	movq	%rax, 0x30(%rsp)
    5220:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    522a:      	movq	%rax, 0x28(%rsp)
    522f:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    5239:      	movq	%rax, 0x20(%rsp)
    523e:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    5248:      	movq	%rax, 0x18(%rsp)
    524d:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5257:      	movq	%rax, 0x10(%rsp)
    525c:      	movb	$0x0, 0x40(%rsp)
    5261:      	leaq	0x10(%rsp), %rdi
    5266:      	movl	$0x31, %eax
    526b:      	movl	$0x6, %ecx
    5270:      	movq	0x58(%rsp), %rdx
    5275:      	movl	$0x31, %esi
    527a:      	xorl	%eax, %eax
    527c:      	callq	*%rcx
    527e:      	jmp	0x3f47 <kprobe_unwind_php+0x3f47>
    5283:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    528d:      	movq	%rax, 0x38(%rsp)
    5292:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    529c:      	movq	%rax, 0x30(%rsp)
    52a1:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    52ab:      	movq	%rax, 0x28(%rsp)
    52b0:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    52ba:      	movq	%rax, 0x20(%rsp)
    52bf:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    52c9:      	movq	%rax, 0x18(%rsp)
    52ce:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    52d8:      	movq	%rax, 0x10(%rsp)
    52dd:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    52e5:      	leaq	0x10(%rsp), %rdi
    52ea:      	movl	$0x33, %eax
    52ef:      	movl	$0x6, %ecx
    52f4:      	movzbl	0x10(%r15), %eax
    52f9:      	addq	%rax, %r13
    52fc:      	movl	$0x33, %esi
    5301:      	movq	%r13, %rdx
    5304:      	xorl	%eax, %eax
    5306:      	callq	*%rcx
    5308:      	jmp	0x4006 <kprobe_unwind_php+0x4006>
    530d:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    5317:      	movq	%rax, 0x38(%rsp)
    531c:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    5326:      	movq	%rax, 0x30(%rsp)
    532b:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    5335:      	movq	%rax, 0x28(%rsp)
    533a:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    5344:      	movq	%rax, 0x20(%rsp)
    5349:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    5353:      	movq	%rax, 0x18(%rsp)
    5358:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5362:      	movq	%rax, 0x10(%rsp)
    5367:      	movb	$0x0, 0x40(%rsp)
    536c:      	leaq	0x10(%rsp), %rdi
    5371:      	movl	$0x31, %eax
    5376:      	movl	$0x6, %ecx
    537b:      	movq	0x58(%rsp), %rdx
    5380:      	movl	$0x31, %esi
    5385:      	xorl	%eax, %eax
    5387:      	callq	*%rcx
    5389:      	jmp	0x45de <kprobe_unwind_php+0x45de>
    538e:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5398:      	movq	%rax, 0x36(%rsp)
    539d:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    53a7:      	movq	%rax, 0x30(%rsp)
    53ac:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    53b6:      	movq	%rax, 0x28(%rsp)
    53bb:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    53c5:      	movq	%rax, 0x20(%rsp)
    53ca:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    53d4:      	movq	%rax, 0x18(%rsp)
    53d9:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    53e3:      	movq	%rax, 0x10(%rsp)
    53e8:      	leaq	0x10(%rsp), %rdi
    53ed:      	movl	$0x2e, %eax
    53f2:      	movl	$0x6, %ecx
    53f7:      	movl	0x58(%rsp), %edx
    53fb:      	movl	$0x2e, %esi
    5400:      	xorl	%eax, %eax
    5402:      	callq	*%rcx
    5404:      	cmpl	$0x23, 0x4(%rsp)
    5409:      	je	0x4606 <kprobe_unwind_php+0x4606>
    540f:      	jmp	0x85e3 <kprobe_unwind_php+0x85e3>
    5414:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    541e:      	movq	%rax, 0x38(%rsp)
    5423:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    542d:      	movq	%rax, 0x30(%rsp)
    5432:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    543c:      	movq	%rax, 0x28(%rsp)
    5441:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    544b:      	movq	%rax, 0x20(%rsp)
    5450:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    545a:      	movq	%rax, 0x18(%rsp)
    545f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5469:      	movq	%rax, 0x10(%rsp)
    546e:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    5476:      	leaq	0x10(%rsp), %rdi
    547b:      	movl	$0x33, %eax
    5480:      	movl	$0x6, %ecx
    5485:      	movzbl	0x10(%r15), %eax
    548a:      	addq	%rax, %r13
    548d:      	movl	$0x33, %esi
    5492:      	jmp	0x598a <kprobe_unwind_php+0x598a>
    5497:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    54a1:      	movq	%rax, 0x1e(%rsp)
    54a6:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    54b0:      	movq	%rax, 0x18(%rsp)
    54b5:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    54bf:      	movq	%rax, 0x10(%rsp)
    54c4:      	leaq	0x10(%rsp), %rdi
    54c9:      	movl	$0x16, %eax
    54ce:      	movl	$0x6, %r8d
    54d4:      	movq	0x58(%rsp), %rdx
    54d9:      	movl	0xc(%rsp), %ecx
    54dd:      	movl	$0x16, %esi
    54e2:      	xorl	%eax, %eax
    54e4:      	callq	*%r8
    54e7:      	movl	0x2c0(%rbp), %eax
    54ed:      	cmpq	$0x7e, %rax
    54f1:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    54f7:      	jmp	0x4a88 <kprobe_unwind_php+0x4a88>
    54fc:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5506:      	movq	%rax, 0x36(%rsp)
    550b:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5515:      	movq	%rax, 0x30(%rsp)
    551a:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5524:      	movq	%rax, 0x28(%rsp)
    5529:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5533:      	movq	%rax, 0x20(%rsp)
    5538:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5542:      	movq	%rax, 0x18(%rsp)
    5547:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5551:      	movq	%rax, 0x10(%rsp)
    5556:      	leaq	0x10(%rsp), %rdi
    555b:      	movl	$0x2e, %eax
    5560:      	movl	$0x6, %ecx
    5565:      	movl	0x58(%rsp), %edx
    5569:      	movl	$0x2e, %esi
    556e:      	xorl	%eax, %eax
    5570:      	callq	*%rcx
    5572:      	cmpl	$0x23, 0x4(%rsp)
    5577:      	je	0x4d15 <kprobe_unwind_php+0x4d15>
    557d:      	jmp	0x85e3 <kprobe_unwind_php+0x85e3>
    5582:      	movq	0x58(%rsp), %rax
    5587:      	testq	%rax, %rax
    558a:      	je	0x579b <kprobe_unwind_php+0x579b>
    5590:      	movzbl	0x14(%r15), %ecx
    5595:      	addq	%rcx, %rax
    5598:      	leaq	0xb(%rsp), %rdi
    559d:      	movl	$0x1, %ecx
    55a2:      	movl	$0x70, %r8d
    55a8:      	movzbl	0x14(%r15), %edx
    55ad:      	addq	0x58(%rsp), %rdx
    55b2:      	movl	$0x1, %esi
    55b7:      	callq	*%r8
    55ba:      	testq	%rax, %rax
    55bd:      	je	0x57dd <kprobe_unwind_php+0x57dd>
    55c3:      	movq	(%rip), %rax            # 0x55ca <kprobe_unwind_php+0x55ca>
    55ca:      	cmpl	$0x0, (%rax)
    55cd:      	je	0x564b <kprobe_unwind_php+0x564b>
    55cf:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    55d9:      	movq	%rax, 0x38(%rsp)
    55de:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    55e8:      	movq	%rax, 0x30(%rsp)
    55ed:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    55f7:      	movq	%rax, 0x28(%rsp)
    55fc:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    5606:      	movq	%rax, 0x20(%rsp)
    560b:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    5615:      	movq	%rax, 0x18(%rsp)
    561a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5624:      	movq	%rax, 0x10(%rsp)
    5629:      	movb	$0x0, 0x40(%rsp)
    562e:      	leaq	0x10(%rsp), %rdi
    5633:      	movl	$0x31, %eax
    5638:      	movl	$0x6, %ecx
    563d:      	movq	0x58(%rsp), %rdx
    5642:      	movl	$0x31, %esi
    5647:      	xorl	%eax, %eax
    5649:      	callq	*%rcx
    564b:      	movl	$0x26, 0x4(%rsp)
    5653:      	jmp	0x5ce9 <kprobe_unwind_php+0x5ce9>
    5658:      	movzbl	0x15(%r15), %eax
    565d:      	addq	0x68(%rsp), %rax
    5662:      	leaq	0xc(%rsp), %rdi
    5667:      	movl	$0x4, %ecx
    566c:      	movl	$0x70, %r8d
    5672:      	movzbl	0x15(%r15), %edx
    5677:      	addq	0x68(%rsp), %rdx
    567c:      	movl	$0x4, %esi
    5681:      	callq	*%r8
    5684:      	testq	%rax, %rax
    5687:      	je	0x58c4 <kprobe_unwind_php+0x58c4>
    568d:      	movq	(%rip), %rax            # 0x5694 <kprobe_unwind_php+0x5694>
    5694:      	movl	$0x27, 0x4(%rsp)
    569c:      	cmpl	$0x0, (%rax)
    569f:      	je	0x469d <kprobe_unwind_php+0x469d>
    56a5:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    56af:      	movq	%rax, 0x40(%rsp)
    56b4:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    56be:      	movq	%rax, 0x38(%rsp)
    56c3:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    56cd:      	movq	%rax, 0x30(%rsp)
    56d2:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    56dc:      	movq	%rax, 0x28(%rsp)
    56e1:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    56eb:      	movq	%rax, 0x20(%rsp)
    56f0:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    56fa:      	movq	%rax, 0x18(%rsp)
    56ff:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5709:      	movq	%rax, 0x10(%rsp)
    570e:      	movb	$0x0, 0x48(%rsp)
    5713:      	leaq	0x10(%rsp), %rdi
    5718:      	movl	$0x39, %eax
    571d:      	movl	$0x6, %ecx
    5722:      	movzbl	0x15(%r15), %edx
    5727:      	addq	0x68(%rsp), %rdx
    572c:      	movl	$0x39, %esi
    5731:      	jmp	0x598d <kprobe_unwind_php+0x598d>
    5736:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    5740:      	movq	%rax, 0x1e(%rsp)
    5745:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    574f:      	movq	%rax, 0x18(%rsp)
    5754:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    575e:      	movq	%rax, 0x10(%rsp)
    5763:      	leaq	0x10(%rsp), %rdi
    5768:      	movl	$0x16, %eax
    576d:      	movl	$0x6, %r8d
    5773:      	movq	0x58(%rsp), %rdx
    5778:      	movl	0xc(%rsp), %ecx
    577c:      	movl	$0x16, %esi
    5781:      	xorl	%eax, %eax
    5783:      	callq	*%r8
    5786:      	movl	0x2c0(%rbp), %eax
    578c:      	cmpq	$0x7e, %rax
    5790:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    5796:      	jmp	0x51c5 <kprobe_unwind_php+0x51c5>
    579b:      	movl	0x2c0(%rbp), %eax
    57a1:      	cmpq	$0x7e, %rax
    57a5:      	ja	0x40e <kprobe_unwind_php+0x40e>
    57ab:      	leal	0x1(%rax), %ecx
    57ae:      	movl	%ecx, 0x2c0(%rbp)
    57b4:      	leaq	(%rax,%rax,2), %rax
    57b8:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    57c4:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    57d0:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    57d8:      	jmp	0x5ccb <kprobe_unwind_php+0x5ccb>
    57dd:      	movl	$0x0, 0xc(%rsp)
    57e5:      	movzbl	0xb(%rsp), %eax
    57ea:      	cmpl	$0x4, %eax
    57ed:      	je	0x5800 <kprobe_unwind_php+0x5800>
    57ef:      	movl	$0x0, 0x4(%rsp)
    57f7:      	cmpl	$0x2, %eax
    57fa:      	jne	0x5c22 <kprobe_unwind_php+0x5c22>
    5800:      	movzbl	0x11(%r15), %eax
    5805:      	addq	%r13, %rax
    5808:      	leaq	0x68(%rsp), %rdi
    580d:      	movl	$0x8, %ecx
    5812:      	movl	$0x70, %r8d
    5818:      	movzbl	0x11(%r15), %edx
    581d:      	addq	%r13, %rdx
    5820:      	movl	$0x8, %esi
    5825:      	callq	*%r8
    5828:      	testq	%rax, %rax
    582b:      	je	0x5996 <kprobe_unwind_php+0x5996>
    5831:      	movq	(%rip), %rax            # 0x5838 <kprobe_unwind_php+0x5838>
    5838:      	movl	$0x25, 0x4(%rsp)
    5840:      	cmpl	$0x0, (%rax)
    5843:      	je	0x5ce9 <kprobe_unwind_php+0x5ce9>
    5849:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    5853:      	movq	%rax, 0x35(%rsp)
    5858:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    5862:      	movq	%rax, 0x30(%rsp)
    5867:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    5871:      	movq	%rax, 0x28(%rsp)
    5876:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    5880:      	movq	%rax, 0x20(%rsp)
    5885:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    588f:      	movq	%rax, 0x18(%rsp)
    5894:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    589e:      	movq	%rax, 0x10(%rsp)
    58a3:      	leaq	0x10(%rsp), %rdi
    58a8:      	movl	$0x2d, %eax
    58ad:      	movl	$0x6, %ecx
    58b2:      	movzbl	0x11(%r15), %eax
    58b7:      	addq	%rax, %r13
    58ba:      	movl	$0x2d, %esi
    58bf:      	jmp	0x5c0e <kprobe_unwind_php+0x5c0e>
    58c4:      	movzbl	0x13(%r15), %eax
    58c9:      	addq	%r13, %rax
    58cc:      	leaq	0x54(%rsp), %rdi
    58d1:      	movl	$0x4, %ecx
    58d6:      	movl	$0x70, %r8d
    58dc:      	movzbl	0x13(%r15), %edx
    58e1:      	addq	%r13, %rdx
    58e4:      	movl	$0x4, %esi
    58e9:      	callq	*%r8
    58ec:      	testq	%rax, %rax
    58ef:      	je	0x5a74 <kprobe_unwind_php+0x5a74>
    58f5:      	movq	(%rip), %rax            # 0x58fc <kprobe_unwind_php+0x58fc>
    58fc:      	movl	$0x25, 0x4(%rsp)
    5904:      	cmpl	$0x0, (%rax)
    5907:      	je	0x469d <kprobe_unwind_php+0x469d>
    590d:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    5917:      	movq	%rax, 0x3d(%rsp)
    591c:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    5926:      	movq	%rax, 0x38(%rsp)
    592b:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    5935:      	movq	%rax, 0x30(%rsp)
    593a:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    5944:      	movq	%rax, 0x28(%rsp)
    5949:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    5953:      	movq	%rax, 0x20(%rsp)
    5958:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    5962:      	movq	%rax, 0x18(%rsp)
    5967:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5971:      	movq	%rax, 0x10(%rsp)
    5976:      	leaq	0x10(%rsp), %rdi
    597b:      	movl	$0x35, %eax
    5980:      	movl	$0x6, %ecx
    5985:      	movl	$0x35, %esi
    598a:      	movq	%r13, %rdx
    598d:      	xorl	%eax, %eax
    598f:      	callq	*%rcx
    5991:      	jmp	0x469d <kprobe_unwind_php+0x469d>
    5996:      	movzbl	0x15(%r15), %eax
    599b:      	addq	0x68(%rsp), %rax
    59a0:      	leaq	0xc(%rsp), %rdi
    59a5:      	movl	$0x4, %ecx
    59aa:      	movl	$0x70, %r8d
    59b0:      	movzbl	0x15(%r15), %edx
    59b5:      	addq	0x68(%rsp), %rdx
    59ba:      	movl	$0x4, %esi
    59bf:      	callq	*%r8
    59c2:      	testq	%rax, %rax
    59c5:      	je	0x5b48 <kprobe_unwind_php+0x5b48>
    59cb:      	movq	(%rip), %rax            # 0x59d2 <kprobe_unwind_php+0x59d2>
    59d2:      	movl	$0x27, 0x4(%rsp)
    59da:      	cmpl	$0x0, (%rax)
    59dd:      	je	0x5ce9 <kprobe_unwind_php+0x5ce9>
    59e3:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    59ed:      	movq	%rax, 0x40(%rsp)
    59f2:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    59fc:      	movq	%rax, 0x38(%rsp)
    5a01:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    5a0b:      	movq	%rax, 0x30(%rsp)
    5a10:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    5a1a:      	movq	%rax, 0x28(%rsp)
    5a1f:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    5a29:      	movq	%rax, 0x20(%rsp)
    5a2e:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    5a38:      	movq	%rax, 0x18(%rsp)
    5a3d:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5a47:      	movq	%rax, 0x10(%rsp)
    5a4c:      	movb	$0x0, 0x48(%rsp)
    5a51:      	leaq	0x10(%rsp), %rdi
    5a56:      	movl	$0x39, %eax
    5a5b:      	movl	$0x6, %ecx
    5a60:      	movzbl	0x15(%r15), %edx
    5a65:      	addq	0x68(%rsp), %rdx
    5a6a:      	movl	$0x39, %esi
    5a6f:      	jmp	0x5c11 <kprobe_unwind_php+0x5c11>
    5a74:      	movl	0xc(%rsp), %eax
    5a78:      	movl	%eax, 0x4(%rsp)
    5a7c:      	movl	0x54(%rsp), %r13d
    5a81:      	movq	(%rip), %rax            # 0x5a88 <kprobe_unwind_php+0x5a88>
    5a88:      	cmpl	$0x0, (%rax)
    5a8b:      	je	0x5add <kprobe_unwind_php+0x5add>
    5a8d:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    5a97:      	movq	%rax, 0x1e(%rsp)
    5a9c:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    5aa6:      	movq	%rax, 0x18(%rsp)
    5aab:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    5ab5:      	movq	%rax, 0x10(%rsp)
    5aba:      	leaq	0x10(%rsp), %rdi
    5abf:      	movl	$0x16, %eax
    5ac4:      	movl	$0x6, %r8d
    5aca:      	movq	0x58(%rsp), %rdx
    5acf:      	movl	0xc(%rsp), %ecx
    5ad3:      	movl	$0x16, %esi
    5ad8:      	xorl	%eax, %eax
    5ada:      	callq	*%r8
    5add:      	movl	0x2c0(%rbp), %eax
    5ae3:      	cmpq	$0x7e, %rax
    5ae7:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    5aed:      	movl	0x4(%rsp), %ecx
    5af1:      	shlq	$0x20, %r13
    5af5:      	orq	%r13, %rcx
    5af8:      	movq	0x58(%rsp), %rdx
    5afd:      	leal	0x1(%rax), %esi
    5b00:      	movl	%esi, 0x2c0(%rbp)
    5b06:      	leaq	(%rax,%rax,2), %rax
    5b0a:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    5b12:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    5b1a:      	movl	0x7c(%rsp), %ecx
    5b1e:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    5b25:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    5b30:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    5b3b:      	movl	$0x23, 0x4(%rsp)
    5b43:      	jmp	0x469d <kprobe_unwind_php+0x469d>
    5b48:      	movzbl	0x13(%r15), %eax
    5b4d:      	addq	%r13, %rax
    5b50:      	leaq	0x54(%rsp), %rdi
    5b55:      	movl	$0x4, %ecx
    5b5a:      	movl	$0x70, %r8d
    5b60:      	movzbl	0x13(%r15), %edx
    5b65:      	addq	%r13, %rdx
    5b68:      	movl	$0x4, %esi
    5b6d:      	callq	*%r8
    5b70:      	testq	%rax, %rax
    5b73:      	je	0x5c1a <kprobe_unwind_php+0x5c1a>
    5b79:      	movq	(%rip), %rax            # 0x5b80 <kprobe_unwind_php+0x5b80>
    5b80:      	movl	$0x25, 0x4(%rsp)
    5b88:      	cmpl	$0x0, (%rax)
    5b8b:      	je	0x5ce9 <kprobe_unwind_php+0x5ce9>
    5b91:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    5b9b:      	movq	%rax, 0x3d(%rsp)
    5ba0:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    5baa:      	movq	%rax, 0x38(%rsp)
    5baf:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    5bb9:      	movq	%rax, 0x30(%rsp)
    5bbe:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    5bc8:      	movq	%rax, 0x28(%rsp)
    5bcd:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    5bd7:      	movq	%rax, 0x20(%rsp)
    5bdc:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    5be6:      	movq	%rax, 0x18(%rsp)
    5beb:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5bf5:      	movq	%rax, 0x10(%rsp)
    5bfa:      	leaq	0x10(%rsp), %rdi
    5bff:      	movl	$0x35, %eax
    5c04:      	movl	$0x6, %ecx
    5c09:      	movl	$0x35, %esi
    5c0e:      	movq	%r13, %rdx
    5c11:      	xorl	%eax, %eax
    5c13:      	callq	*%rcx
    5c15:      	jmp	0x5ce9 <kprobe_unwind_php+0x5ce9>
    5c1a:      	movl	0xc(%rsp), %eax
    5c1e:      	movl	%eax, 0x4(%rsp)
    5c22:      	movl	0x54(%rsp), %r13d
    5c27:      	movq	(%rip), %rax            # 0x5c2e <kprobe_unwind_php+0x5c2e>
    5c2e:      	cmpl	$0x0, (%rax)
    5c31:      	je	0x5c83 <kprobe_unwind_php+0x5c83>
    5c33:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    5c3d:      	movq	%rax, 0x1e(%rsp)
    5c42:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    5c4c:      	movq	%rax, 0x18(%rsp)
    5c51:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    5c5b:      	movq	%rax, 0x10(%rsp)
    5c60:      	leaq	0x10(%rsp), %rdi
    5c65:      	movl	$0x16, %eax
    5c6a:      	movl	$0x6, %r8d
    5c70:      	movq	0x58(%rsp), %rdx
    5c75:      	movl	0xc(%rsp), %ecx
    5c79:      	movl	$0x16, %esi
    5c7e:      	xorl	%eax, %eax
    5c80:      	callq	*%r8
    5c83:      	movl	0x2c0(%rbp), %eax
    5c89:      	cmpq	$0x7e, %rax
    5c8d:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    5c93:      	movl	0x4(%rsp), %ecx
    5c97:      	shlq	$0x20, %r13
    5c9b:      	orq	%r13, %rcx
    5c9e:      	movq	0x58(%rsp), %rdx
    5ca3:      	leal	0x1(%rax), %esi
    5ca6:      	movl	%esi, 0x2c0(%rbp)
    5cac:      	leaq	(%rax,%rax,2), %rax
    5cb0:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    5cb8:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    5cc0:      	movl	0x7c(%rsp), %ecx
    5cc4:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    5ccb:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    5cd6:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    5ce1:      	movl	$0x23, 0x4(%rsp)
    5ce9:      	movl	0x4(%rsp), %eax
    5ced:      	movl	%eax, 0x58(%rsp)
    5cf1:      	movq	(%rip), %rdi            # 0x5cf8 <kprobe_unwind_php+0x5cf8>
    5cf8:      	leaq	0x58(%rsp), %rsi
    5cfd:      	movl	$0x1, %eax
    5d02:      	callq	*%rax
    5d04:      	testq	%rax, %rax
    5d07:      	je	0x5d11 <kprobe_unwind_php+0x5d11>
    5d09:      	incq	(%rax)
    5d0c:      	jmp	0x5d93 <kprobe_unwind_php+0x5d93>
    5d11:      	movq	(%rip), %rax            # 0x5d18 <kprobe_unwind_php+0x5d18>
    5d18:      	cmpl	$0x0, (%rax)
    5d1b:      	je	0x5d93 <kprobe_unwind_php+0x5d93>
    5d1d:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5d27:      	movq	%rax, 0x36(%rsp)
    5d2c:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5d36:      	movq	%rax, 0x30(%rsp)
    5d3b:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5d45:      	movq	%rax, 0x28(%rsp)
    5d4a:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5d54:      	movq	%rax, 0x20(%rsp)
    5d59:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5d63:      	movq	%rax, 0x18(%rsp)
    5d68:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5d72:      	movq	%rax, 0x10(%rsp)
    5d77:      	leaq	0x10(%rsp), %rdi
    5d7c:      	movl	$0x2e, %eax
    5d81:      	movl	$0x6, %ecx
    5d86:      	movl	0x58(%rsp), %edx
    5d8a:      	movl	$0x2e, %esi
    5d8f:      	xorl	%eax, %eax
    5d91:      	callq	*%rcx
    5d93:      	cmpl	$0x23, 0x4(%rsp)
    5d98:      	jne	0x85e3 <kprobe_unwind_php+0x85e3>
    5d9e:      	movzbl	0x12(%r15), %eax
    5da3:      	addq	0x70(%rsp), %rax
    5da8:      	leaq	0x70(%rsp), %rdi
    5dad:      	movl	$0x8, %ecx
    5db2:      	movl	$0x70, %r8d
    5db8:      	movzbl	0x12(%r15), %edx
    5dbd:      	addq	0x70(%rsp), %rdx
    5dc2:      	movl	$0x8, %esi
    5dc7:      	callq	*%r8
    5dca:      	testq	%rax, %rax
    5dcd:      	jne	0x317 <kprobe_unwind_php+0x317>
    5dd3:      	movq	0x70(%rsp), %r13
    5dd8:      	testq	%r13, %r13
    5ddb:      	je	0x83ba <kprobe_unwind_php+0x83ba>
    5de1:      	testb	$0x2, 0x56(%rsp)
    5de6:      	jne	0x83ba <kprobe_unwind_php+0x83ba>
    5dec:      	movzbl	0x10(%r15), %eax
    5df1:      	addq	%r13, %rax
    5df4:      	leaq	0x58(%rsp), %rdi
    5df9:      	movl	$0x8, %ecx
    5dfe:      	movl	$0x70, %r8d
    5e04:      	movzbl	0x10(%r15), %edx
    5e09:      	addq	%r13, %rdx
    5e0c:      	movl	$0x8, %esi
    5e11:      	callq	*%r8
    5e14:      	testq	%rax, %rax
    5e17:      	je	0x5eb8 <kprobe_unwind_php+0x5eb8>
    5e1d:      	movq	(%rip), %rax            # 0x5e24 <kprobe_unwind_php+0x5e24>
    5e24:      	movl	$0x25, 0x4(%rsp)
    5e2c:      	cmpl	$0x0, (%rax)
    5e2f:      	je	0x6336 <kprobe_unwind_php+0x6336>
    5e35:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    5e3f:      	movq	%rax, 0x38(%rsp)
    5e44:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    5e4e:      	movq	%rax, 0x30(%rsp)
    5e53:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    5e5d:      	movq	%rax, 0x28(%rsp)
    5e62:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    5e6c:      	movq	%rax, 0x20(%rsp)
    5e71:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    5e7b:      	movq	%rax, 0x18(%rsp)
    5e80:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5e8a:      	movq	%rax, 0x10(%rsp)
    5e8f:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    5e97:      	leaq	0x10(%rsp), %rdi
    5e9c:      	movl	$0x33, %eax
    5ea1:      	movl	$0x6, %ecx
    5ea6:      	movzbl	0x10(%r15), %eax
    5eab:      	addq	%rax, %r13
    5eae:      	movl	$0x33, %esi
    5eb3:      	jmp	0x625b <kprobe_unwind_php+0x625b>
    5eb8:      	movq	0x58(%rsp), %rax
    5ebd:      	testq	%rax, %rax
    5ec0:      	je	0x5f8e <kprobe_unwind_php+0x5f8e>
    5ec6:      	movzbl	0x14(%r15), %ecx
    5ecb:      	addq	%rcx, %rax
    5ece:      	leaq	0xb(%rsp), %rdi
    5ed3:      	movl	$0x1, %ecx
    5ed8:      	movl	$0x70, %r8d
    5ede:      	movzbl	0x14(%r15), %edx
    5ee3:      	addq	0x58(%rsp), %rdx
    5ee8:      	movl	$0x1, %esi
    5eed:      	callq	*%r8
    5ef0:      	testq	%rax, %rax
    5ef3:      	je	0x5fd0 <kprobe_unwind_php+0x5fd0>
    5ef9:      	movq	(%rip), %rax            # 0x5f00 <kprobe_unwind_php+0x5f00>
    5f00:      	cmpl	$0x0, (%rax)
    5f03:      	je	0x5f81 <kprobe_unwind_php+0x5f81>
    5f05:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    5f0f:      	movq	%rax, 0x38(%rsp)
    5f14:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    5f1e:      	movq	%rax, 0x30(%rsp)
    5f23:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    5f2d:      	movq	%rax, 0x28(%rsp)
    5f32:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    5f3c:      	movq	%rax, 0x20(%rsp)
    5f41:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    5f4b:      	movq	%rax, 0x18(%rsp)
    5f50:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5f5a:      	movq	%rax, 0x10(%rsp)
    5f5f:      	movb	$0x0, 0x40(%rsp)
    5f64:      	leaq	0x10(%rsp), %rdi
    5f69:      	movl	$0x31, %eax
    5f6e:      	movl	$0x6, %ecx
    5f73:      	movq	0x58(%rsp), %rdx
    5f78:      	movl	$0x31, %esi
    5f7d:      	xorl	%eax, %eax
    5f7f:      	callq	*%rcx
    5f81:      	movl	$0x26, 0x4(%rsp)
    5f89:      	jmp	0x6336 <kprobe_unwind_php+0x6336>
    5f8e:      	movl	0x2c0(%rbp), %eax
    5f94:      	cmpq	$0x7e, %rax
    5f98:      	ja	0x40e <kprobe_unwind_php+0x40e>
    5f9e:      	leal	0x1(%rax), %ecx
    5fa1:      	movl	%ecx, 0x2c0(%rbp)
    5fa7:      	leaq	(%rax,%rax,2), %rax
    5fab:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    5fb7:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    5fc3:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    5fcb:      	jmp	0x6318 <kprobe_unwind_php+0x6318>
    5fd0:      	movl	$0x0, 0xc(%rsp)
    5fd8:      	movzbl	0xb(%rsp), %eax
    5fdd:      	cmpl	$0x4, %eax
    5fe0:      	je	0x5ff3 <kprobe_unwind_php+0x5ff3>
    5fe2:      	movl	$0x0, 0x4(%rsp)
    5fea:      	cmpl	$0x2, %eax
    5fed:      	jne	0x626f <kprobe_unwind_php+0x626f>
    5ff3:      	movzbl	0x11(%r15), %eax
    5ff8:      	addq	%r13, %rax
    5ffb:      	leaq	0x68(%rsp), %rdi
    6000:      	movl	$0x8, %ecx
    6005:      	movl	$0x70, %r8d
    600b:      	movzbl	0x11(%r15), %edx
    6010:      	addq	%r13, %rdx
    6013:      	movl	$0x8, %esi
    6018:      	callq	*%r8
    601b:      	testq	%rax, %rax
    601e:      	je	0x60b7 <kprobe_unwind_php+0x60b7>
    6024:      	movq	(%rip), %rax            # 0x602b <kprobe_unwind_php+0x602b>
    602b:      	movl	$0x25, 0x4(%rsp)
    6033:      	cmpl	$0x0, (%rax)
    6036:      	je	0x6336 <kprobe_unwind_php+0x6336>
    603c:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    6046:      	movq	%rax, 0x35(%rsp)
    604b:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    6055:      	movq	%rax, 0x30(%rsp)
    605a:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    6064:      	movq	%rax, 0x28(%rsp)
    6069:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    6073:      	movq	%rax, 0x20(%rsp)
    6078:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    6082:      	movq	%rax, 0x18(%rsp)
    6087:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6091:      	movq	%rax, 0x10(%rsp)
    6096:      	leaq	0x10(%rsp), %rdi
    609b:      	movl	$0x2d, %eax
    60a0:      	movl	$0x6, %ecx
    60a5:      	movzbl	0x11(%r15), %eax
    60aa:      	addq	%rax, %r13
    60ad:      	movl	$0x2d, %esi
    60b2:      	jmp	0x625b <kprobe_unwind_php+0x625b>
    60b7:      	movzbl	0x15(%r15), %eax
    60bc:      	addq	0x68(%rsp), %rax
    60c1:      	leaq	0xc(%rsp), %rdi
    60c6:      	movl	$0x4, %ecx
    60cb:      	movl	$0x70, %r8d
    60d1:      	movzbl	0x15(%r15), %edx
    60d6:      	addq	0x68(%rsp), %rdx
    60db:      	movl	$0x4, %esi
    60e0:      	callq	*%r8
    60e3:      	testq	%rax, %rax
    60e6:      	je	0x6195 <kprobe_unwind_php+0x6195>
    60ec:      	movq	(%rip), %rax            # 0x60f3 <kprobe_unwind_php+0x60f3>
    60f3:      	movl	$0x27, 0x4(%rsp)
    60fb:      	cmpl	$0x0, (%rax)
    60fe:      	je	0x6336 <kprobe_unwind_php+0x6336>
    6104:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    610e:      	movq	%rax, 0x40(%rsp)
    6113:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    611d:      	movq	%rax, 0x38(%rsp)
    6122:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    612c:      	movq	%rax, 0x30(%rsp)
    6131:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    613b:      	movq	%rax, 0x28(%rsp)
    6140:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    614a:      	movq	%rax, 0x20(%rsp)
    614f:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    6159:      	movq	%rax, 0x18(%rsp)
    615e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6168:      	movq	%rax, 0x10(%rsp)
    616d:      	movb	$0x0, 0x48(%rsp)
    6172:      	leaq	0x10(%rsp), %rdi
    6177:      	movl	$0x39, %eax
    617c:      	movl	$0x6, %ecx
    6181:      	movzbl	0x15(%r15), %edx
    6186:      	addq	0x68(%rsp), %rdx
    618b:      	movl	$0x39, %esi
    6190:      	jmp	0x625e <kprobe_unwind_php+0x625e>
    6195:      	movzbl	0x13(%r15), %eax
    619a:      	addq	%r13, %rax
    619d:      	leaq	0x54(%rsp), %rdi
    61a2:      	movl	$0x4, %ecx
    61a7:      	movl	$0x70, %r8d
    61ad:      	movzbl	0x13(%r15), %edx
    61b2:      	addq	%r13, %rdx
    61b5:      	movl	$0x4, %esi
    61ba:      	callq	*%r8
    61bd:      	testq	%rax, %rax
    61c0:      	je	0x6267 <kprobe_unwind_php+0x6267>
    61c6:      	movq	(%rip), %rax            # 0x61cd <kprobe_unwind_php+0x61cd>
    61cd:      	movl	$0x25, 0x4(%rsp)
    61d5:      	cmpl	$0x0, (%rax)
    61d8:      	je	0x6336 <kprobe_unwind_php+0x6336>
    61de:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    61e8:      	movq	%rax, 0x3d(%rsp)
    61ed:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    61f7:      	movq	%rax, 0x38(%rsp)
    61fc:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    6206:      	movq	%rax, 0x30(%rsp)
    620b:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    6215:      	movq	%rax, 0x28(%rsp)
    621a:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    6224:      	movq	%rax, 0x20(%rsp)
    6229:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    6233:      	movq	%rax, 0x18(%rsp)
    6238:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6242:      	movq	%rax, 0x10(%rsp)
    6247:      	leaq	0x10(%rsp), %rdi
    624c:      	movl	$0x35, %eax
    6251:      	movl	$0x6, %ecx
    6256:      	movl	$0x35, %esi
    625b:      	movq	%r13, %rdx
    625e:      	xorl	%eax, %eax
    6260:      	callq	*%rcx
    6262:      	jmp	0x6336 <kprobe_unwind_php+0x6336>
    6267:      	movl	0xc(%rsp), %eax
    626b:      	movl	%eax, 0x4(%rsp)
    626f:      	movl	0x54(%rsp), %r13d
    6274:      	movq	(%rip), %rax            # 0x627b <kprobe_unwind_php+0x627b>
    627b:      	cmpl	$0x0, (%rax)
    627e:      	je	0x62d0 <kprobe_unwind_php+0x62d0>
    6280:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    628a:      	movq	%rax, 0x1e(%rsp)
    628f:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    6299:      	movq	%rax, 0x18(%rsp)
    629e:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    62a8:      	movq	%rax, 0x10(%rsp)
    62ad:      	leaq	0x10(%rsp), %rdi
    62b2:      	movl	$0x16, %eax
    62b7:      	movl	$0x6, %r8d
    62bd:      	movq	0x58(%rsp), %rdx
    62c2:      	movl	0xc(%rsp), %ecx
    62c6:      	movl	$0x16, %esi
    62cb:      	xorl	%eax, %eax
    62cd:      	callq	*%r8
    62d0:      	movl	0x2c0(%rbp), %eax
    62d6:      	cmpq	$0x7e, %rax
    62da:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    62e0:      	movl	0x4(%rsp), %ecx
    62e4:      	shlq	$0x20, %r13
    62e8:      	orq	%r13, %rcx
    62eb:      	movq	0x58(%rsp), %rdx
    62f0:      	leal	0x1(%rax), %esi
    62f3:      	movl	%esi, 0x2c0(%rbp)
    62f9:      	leaq	(%rax,%rax,2), %rax
    62fd:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    6305:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    630d:      	movl	0x7c(%rsp), %ecx
    6311:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    6318:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    6323:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    632e:      	movl	$0x23, 0x4(%rsp)
    6336:      	movl	0x4(%rsp), %eax
    633a:      	movl	%eax, 0x58(%rsp)
    633e:      	movq	(%rip), %rdi            # 0x6345 <kprobe_unwind_php+0x6345>
    6345:      	leaq	0x58(%rsp), %rsi
    634a:      	movl	$0x1, %eax
    634f:      	callq	*%rax
    6351:      	testq	%rax, %rax
    6354:      	je	0x635e <kprobe_unwind_php+0x635e>
    6356:      	incq	(%rax)
    6359:      	jmp	0x63e0 <kprobe_unwind_php+0x63e0>
    635e:      	movq	(%rip), %rax            # 0x6365 <kprobe_unwind_php+0x6365>
    6365:      	cmpl	$0x0, (%rax)
    6368:      	je	0x63e0 <kprobe_unwind_php+0x63e0>
    636a:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    6374:      	movq	%rax, 0x36(%rsp)
    6379:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    6383:      	movq	%rax, 0x30(%rsp)
    6388:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    6392:      	movq	%rax, 0x28(%rsp)
    6397:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    63a1:      	movq	%rax, 0x20(%rsp)
    63a6:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    63b0:      	movq	%rax, 0x18(%rsp)
    63b5:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    63bf:      	movq	%rax, 0x10(%rsp)
    63c4:      	leaq	0x10(%rsp), %rdi
    63c9:      	movl	$0x2e, %eax
    63ce:      	movl	$0x6, %ecx
    63d3:      	movl	0x58(%rsp), %edx
    63d7:      	movl	$0x2e, %esi
    63dc:      	xorl	%eax, %eax
    63de:      	callq	*%rcx
    63e0:      	cmpl	$0x23, 0x4(%rsp)
    63e5:      	jne	0x85e3 <kprobe_unwind_php+0x85e3>
    63eb:      	movzbl	0x12(%r15), %eax
    63f0:      	addq	0x70(%rsp), %rax
    63f5:      	leaq	0x70(%rsp), %rdi
    63fa:      	movl	$0x8, %ecx
    63ff:      	movl	$0x70, %r8d
    6405:      	movzbl	0x12(%r15), %edx
    640a:      	addq	0x70(%rsp), %rdx
    640f:      	movl	$0x8, %esi
    6414:      	callq	*%r8
    6417:      	testq	%rax, %rax
    641a:      	jne	0x317 <kprobe_unwind_php+0x317>
    6420:      	movq	0x70(%rsp), %r13
    6425:      	testq	%r13, %r13
    6428:      	je	0x83ba <kprobe_unwind_php+0x83ba>
    642e:      	testb	$0x2, 0x56(%rsp)
    6433:      	jne	0x83ba <kprobe_unwind_php+0x83ba>
    6439:      	movzbl	0x10(%r15), %eax
    643e:      	addq	%r13, %rax
    6441:      	leaq	0x58(%rsp), %rdi
    6446:      	movl	$0x8, %ecx
    644b:      	movl	$0x70, %r8d
    6451:      	movzbl	0x10(%r15), %edx
    6456:      	addq	%r13, %rdx
    6459:      	movl	$0x8, %esi
    645e:      	callq	*%r8
    6461:      	testq	%rax, %rax
    6464:      	je	0x6505 <kprobe_unwind_php+0x6505>
    646a:      	movq	(%rip), %rax            # 0x6471 <kprobe_unwind_php+0x6471>
    6471:      	movl	$0x25, 0x4(%rsp)
    6479:      	cmpl	$0x0, (%rax)
    647c:      	je	0x6983 <kprobe_unwind_php+0x6983>
    6482:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    648c:      	movq	%rax, 0x38(%rsp)
    6491:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    649b:      	movq	%rax, 0x30(%rsp)
    64a0:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    64aa:      	movq	%rax, 0x28(%rsp)
    64af:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    64b9:      	movq	%rax, 0x20(%rsp)
    64be:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    64c8:      	movq	%rax, 0x18(%rsp)
    64cd:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    64d7:      	movq	%rax, 0x10(%rsp)
    64dc:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    64e4:      	leaq	0x10(%rsp), %rdi
    64e9:      	movl	$0x33, %eax
    64ee:      	movl	$0x6, %ecx
    64f3:      	movzbl	0x10(%r15), %eax
    64f8:      	addq	%rax, %r13
    64fb:      	movl	$0x33, %esi
    6500:      	jmp	0x68a8 <kprobe_unwind_php+0x68a8>
    6505:      	movq	0x58(%rsp), %rax
    650a:      	testq	%rax, %rax
    650d:      	je	0x65db <kprobe_unwind_php+0x65db>
    6513:      	movzbl	0x14(%r15), %ecx
    6518:      	addq	%rcx, %rax
    651b:      	leaq	0xb(%rsp), %rdi
    6520:      	movl	$0x1, %ecx
    6525:      	movl	$0x70, %r8d
    652b:      	movzbl	0x14(%r15), %edx
    6530:      	addq	0x58(%rsp), %rdx
    6535:      	movl	$0x1, %esi
    653a:      	callq	*%r8
    653d:      	testq	%rax, %rax
    6540:      	je	0x661d <kprobe_unwind_php+0x661d>
    6546:      	movq	(%rip), %rax            # 0x654d <kprobe_unwind_php+0x654d>
    654d:      	cmpl	$0x0, (%rax)
    6550:      	je	0x65ce <kprobe_unwind_php+0x65ce>
    6552:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    655c:      	movq	%rax, 0x38(%rsp)
    6561:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    656b:      	movq	%rax, 0x30(%rsp)
    6570:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    657a:      	movq	%rax, 0x28(%rsp)
    657f:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    6589:      	movq	%rax, 0x20(%rsp)
    658e:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    6598:      	movq	%rax, 0x18(%rsp)
    659d:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    65a7:      	movq	%rax, 0x10(%rsp)
    65ac:      	movb	$0x0, 0x40(%rsp)
    65b1:      	leaq	0x10(%rsp), %rdi
    65b6:      	movl	$0x31, %eax
    65bb:      	movl	$0x6, %ecx
    65c0:      	movq	0x58(%rsp), %rdx
    65c5:      	movl	$0x31, %esi
    65ca:      	xorl	%eax, %eax
    65cc:      	callq	*%rcx
    65ce:      	movl	$0x26, 0x4(%rsp)
    65d6:      	jmp	0x6983 <kprobe_unwind_php+0x6983>
    65db:      	movl	0x2c0(%rbp), %eax
    65e1:      	cmpq	$0x7e, %rax
    65e5:      	ja	0x40e <kprobe_unwind_php+0x40e>
    65eb:      	leal	0x1(%rax), %ecx
    65ee:      	movl	%ecx, 0x2c0(%rbp)
    65f4:      	leaq	(%rax,%rax,2), %rax
    65f8:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    6604:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    6610:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    6618:      	jmp	0x6965 <kprobe_unwind_php+0x6965>
    661d:      	movl	$0x0, 0xc(%rsp)
    6625:      	movzbl	0xb(%rsp), %eax
    662a:      	cmpl	$0x4, %eax
    662d:      	je	0x6640 <kprobe_unwind_php+0x6640>
    662f:      	movl	$0x0, 0x4(%rsp)
    6637:      	cmpl	$0x2, %eax
    663a:      	jne	0x68bc <kprobe_unwind_php+0x68bc>
    6640:      	movzbl	0x11(%r15), %eax
    6645:      	addq	%r13, %rax
    6648:      	leaq	0x68(%rsp), %rdi
    664d:      	movl	$0x8, %ecx
    6652:      	movl	$0x70, %r8d
    6658:      	movzbl	0x11(%r15), %edx
    665d:      	addq	%r13, %rdx
    6660:      	movl	$0x8, %esi
    6665:      	callq	*%r8
    6668:      	testq	%rax, %rax
    666b:      	je	0x6704 <kprobe_unwind_php+0x6704>
    6671:      	movq	(%rip), %rax            # 0x6678 <kprobe_unwind_php+0x6678>
    6678:      	movl	$0x25, 0x4(%rsp)
    6680:      	cmpl	$0x0, (%rax)
    6683:      	je	0x6983 <kprobe_unwind_php+0x6983>
    6689:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    6693:      	movq	%rax, 0x35(%rsp)
    6698:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    66a2:      	movq	%rax, 0x30(%rsp)
    66a7:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    66b1:      	movq	%rax, 0x28(%rsp)
    66b6:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    66c0:      	movq	%rax, 0x20(%rsp)
    66c5:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    66cf:      	movq	%rax, 0x18(%rsp)
    66d4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    66de:      	movq	%rax, 0x10(%rsp)
    66e3:      	leaq	0x10(%rsp), %rdi
    66e8:      	movl	$0x2d, %eax
    66ed:      	movl	$0x6, %ecx
    66f2:      	movzbl	0x11(%r15), %eax
    66f7:      	addq	%rax, %r13
    66fa:      	movl	$0x2d, %esi
    66ff:      	jmp	0x68a8 <kprobe_unwind_php+0x68a8>
    6704:      	movzbl	0x15(%r15), %eax
    6709:      	addq	0x68(%rsp), %rax
    670e:      	leaq	0xc(%rsp), %rdi
    6713:      	movl	$0x4, %ecx
    6718:      	movl	$0x70, %r8d
    671e:      	movzbl	0x15(%r15), %edx
    6723:      	addq	0x68(%rsp), %rdx
    6728:      	movl	$0x4, %esi
    672d:      	callq	*%r8
    6730:      	testq	%rax, %rax
    6733:      	je	0x67e2 <kprobe_unwind_php+0x67e2>
    6739:      	movq	(%rip), %rax            # 0x6740 <kprobe_unwind_php+0x6740>
    6740:      	movl	$0x27, 0x4(%rsp)
    6748:      	cmpl	$0x0, (%rax)
    674b:      	je	0x6983 <kprobe_unwind_php+0x6983>
    6751:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    675b:      	movq	%rax, 0x40(%rsp)
    6760:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    676a:      	movq	%rax, 0x38(%rsp)
    676f:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    6779:      	movq	%rax, 0x30(%rsp)
    677e:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    6788:      	movq	%rax, 0x28(%rsp)
    678d:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    6797:      	movq	%rax, 0x20(%rsp)
    679c:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    67a6:      	movq	%rax, 0x18(%rsp)
    67ab:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    67b5:      	movq	%rax, 0x10(%rsp)
    67ba:      	movb	$0x0, 0x48(%rsp)
    67bf:      	leaq	0x10(%rsp), %rdi
    67c4:      	movl	$0x39, %eax
    67c9:      	movl	$0x6, %ecx
    67ce:      	movzbl	0x15(%r15), %edx
    67d3:      	addq	0x68(%rsp), %rdx
    67d8:      	movl	$0x39, %esi
    67dd:      	jmp	0x68ab <kprobe_unwind_php+0x68ab>
    67e2:      	movzbl	0x13(%r15), %eax
    67e7:      	addq	%r13, %rax
    67ea:      	leaq	0x54(%rsp), %rdi
    67ef:      	movl	$0x4, %ecx
    67f4:      	movl	$0x70, %r8d
    67fa:      	movzbl	0x13(%r15), %edx
    67ff:      	addq	%r13, %rdx
    6802:      	movl	$0x4, %esi
    6807:      	callq	*%r8
    680a:      	testq	%rax, %rax
    680d:      	je	0x68b4 <kprobe_unwind_php+0x68b4>
    6813:      	movq	(%rip), %rax            # 0x681a <kprobe_unwind_php+0x681a>
    681a:      	movl	$0x25, 0x4(%rsp)
    6822:      	cmpl	$0x0, (%rax)
    6825:      	je	0x6983 <kprobe_unwind_php+0x6983>
    682b:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    6835:      	movq	%rax, 0x3d(%rsp)
    683a:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    6844:      	movq	%rax, 0x38(%rsp)
    6849:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    6853:      	movq	%rax, 0x30(%rsp)
    6858:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    6862:      	movq	%rax, 0x28(%rsp)
    6867:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    6871:      	movq	%rax, 0x20(%rsp)
    6876:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    6880:      	movq	%rax, 0x18(%rsp)
    6885:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    688f:      	movq	%rax, 0x10(%rsp)
    6894:      	leaq	0x10(%rsp), %rdi
    6899:      	movl	$0x35, %eax
    689e:      	movl	$0x6, %ecx
    68a3:      	movl	$0x35, %esi
    68a8:      	movq	%r13, %rdx
    68ab:      	xorl	%eax, %eax
    68ad:      	callq	*%rcx
    68af:      	jmp	0x6983 <kprobe_unwind_php+0x6983>
    68b4:      	movl	0xc(%rsp), %eax
    68b8:      	movl	%eax, 0x4(%rsp)
    68bc:      	movl	0x54(%rsp), %r13d
    68c1:      	movq	(%rip), %rax            # 0x68c8 <kprobe_unwind_php+0x68c8>
    68c8:      	cmpl	$0x0, (%rax)
    68cb:      	je	0x691d <kprobe_unwind_php+0x691d>
    68cd:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    68d7:      	movq	%rax, 0x1e(%rsp)
    68dc:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    68e6:      	movq	%rax, 0x18(%rsp)
    68eb:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    68f5:      	movq	%rax, 0x10(%rsp)
    68fa:      	leaq	0x10(%rsp), %rdi
    68ff:      	movl	$0x16, %eax
    6904:      	movl	$0x6, %r8d
    690a:      	movq	0x58(%rsp), %rdx
    690f:      	movl	0xc(%rsp), %ecx
    6913:      	movl	$0x16, %esi
    6918:      	xorl	%eax, %eax
    691a:      	callq	*%r8
    691d:      	movl	0x2c0(%rbp), %eax
    6923:      	cmpq	$0x7e, %rax
    6927:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    692d:      	movl	0x4(%rsp), %ecx
    6931:      	shlq	$0x20, %r13
    6935:      	orq	%r13, %rcx
    6938:      	movq	0x58(%rsp), %rdx
    693d:      	leal	0x1(%rax), %esi
    6940:      	movl	%esi, 0x2c0(%rbp)
    6946:      	leaq	(%rax,%rax,2), %rax
    694a:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    6952:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    695a:      	movl	0x7c(%rsp), %ecx
    695e:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    6965:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    6970:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    697b:      	movl	$0x23, 0x4(%rsp)
    6983:      	movl	0x4(%rsp), %eax
    6987:      	movl	%eax, 0x58(%rsp)
    698b:      	movq	(%rip), %rdi            # 0x6992 <kprobe_unwind_php+0x6992>
    6992:      	leaq	0x58(%rsp), %rsi
    6997:      	movl	$0x1, %eax
    699c:      	callq	*%rax
    699e:      	testq	%rax, %rax
    69a1:      	je	0x69ab <kprobe_unwind_php+0x69ab>
    69a3:      	incq	(%rax)
    69a6:      	jmp	0x6a2d <kprobe_unwind_php+0x6a2d>
    69ab:      	movq	(%rip), %rax            # 0x69b2 <kprobe_unwind_php+0x69b2>
    69b2:      	cmpl	$0x0, (%rax)
    69b5:      	je	0x6a2d <kprobe_unwind_php+0x6a2d>
    69b7:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    69c1:      	movq	%rax, 0x36(%rsp)
    69c6:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    69d0:      	movq	%rax, 0x30(%rsp)
    69d5:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    69df:      	movq	%rax, 0x28(%rsp)
    69e4:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    69ee:      	movq	%rax, 0x20(%rsp)
    69f3:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    69fd:      	movq	%rax, 0x18(%rsp)
    6a02:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6a0c:      	movq	%rax, 0x10(%rsp)
    6a11:      	leaq	0x10(%rsp), %rdi
    6a16:      	movl	$0x2e, %eax
    6a1b:      	movl	$0x6, %ecx
    6a20:      	movl	0x58(%rsp), %edx
    6a24:      	movl	$0x2e, %esi
    6a29:      	xorl	%eax, %eax
    6a2b:      	callq	*%rcx
    6a2d:      	cmpl	$0x23, 0x4(%rsp)
    6a32:      	jne	0x85e3 <kprobe_unwind_php+0x85e3>
    6a38:      	movzbl	0x12(%r15), %eax
    6a3d:      	addq	0x70(%rsp), %rax
    6a42:      	leaq	0x70(%rsp), %rdi
    6a47:      	movl	$0x8, %ecx
    6a4c:      	movl	$0x70, %r8d
    6a52:      	movzbl	0x12(%r15), %edx
    6a57:      	addq	0x70(%rsp), %rdx
    6a5c:      	movl	$0x8, %esi
    6a61:      	callq	*%r8
    6a64:      	testq	%rax, %rax
    6a67:      	jne	0x317 <kprobe_unwind_php+0x317>
    6a6d:      	movq	0x70(%rsp), %r13
    6a72:      	testq	%r13, %r13
    6a75:      	je	0x83ba <kprobe_unwind_php+0x83ba>
    6a7b:      	testb	$0x2, 0x56(%rsp)
    6a80:      	jne	0x83ba <kprobe_unwind_php+0x83ba>
    6a86:      	movzbl	0x10(%r15), %eax
    6a8b:      	addq	%r13, %rax
    6a8e:      	leaq	0x58(%rsp), %rdi
    6a93:      	movl	$0x8, %ecx
    6a98:      	movl	$0x70, %r8d
    6a9e:      	movzbl	0x10(%r15), %edx
    6aa3:      	addq	%r13, %rdx
    6aa6:      	movl	$0x8, %esi
    6aab:      	callq	*%r8
    6aae:      	testq	%rax, %rax
    6ab1:      	je	0x6b52 <kprobe_unwind_php+0x6b52>
    6ab7:      	movq	(%rip), %rax            # 0x6abe <kprobe_unwind_php+0x6abe>
    6abe:      	movl	$0x25, 0x4(%rsp)
    6ac6:      	cmpl	$0x0, (%rax)
    6ac9:      	je	0x6fd0 <kprobe_unwind_php+0x6fd0>
    6acf:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    6ad9:      	movq	%rax, 0x38(%rsp)
    6ade:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    6ae8:      	movq	%rax, 0x30(%rsp)
    6aed:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    6af7:      	movq	%rax, 0x28(%rsp)
    6afc:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    6b06:      	movq	%rax, 0x20(%rsp)
    6b0b:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    6b15:      	movq	%rax, 0x18(%rsp)
    6b1a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6b24:      	movq	%rax, 0x10(%rsp)
    6b29:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    6b31:      	leaq	0x10(%rsp), %rdi
    6b36:      	movl	$0x33, %eax
    6b3b:      	movl	$0x6, %ecx
    6b40:      	movzbl	0x10(%r15), %eax
    6b45:      	addq	%rax, %r13
    6b48:      	movl	$0x33, %esi
    6b4d:      	jmp	0x6ef5 <kprobe_unwind_php+0x6ef5>
    6b52:      	movq	0x58(%rsp), %rax
    6b57:      	testq	%rax, %rax
    6b5a:      	je	0x6c28 <kprobe_unwind_php+0x6c28>
    6b60:      	movzbl	0x14(%r15), %ecx
    6b65:      	addq	%rcx, %rax
    6b68:      	leaq	0xb(%rsp), %rdi
    6b6d:      	movl	$0x1, %ecx
    6b72:      	movl	$0x70, %r8d
    6b78:      	movzbl	0x14(%r15), %edx
    6b7d:      	addq	0x58(%rsp), %rdx
    6b82:      	movl	$0x1, %esi
    6b87:      	callq	*%r8
    6b8a:      	testq	%rax, %rax
    6b8d:      	je	0x6c6a <kprobe_unwind_php+0x6c6a>
    6b93:      	movq	(%rip), %rax            # 0x6b9a <kprobe_unwind_php+0x6b9a>
    6b9a:      	cmpl	$0x0, (%rax)
    6b9d:      	je	0x6c1b <kprobe_unwind_php+0x6c1b>
    6b9f:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    6ba9:      	movq	%rax, 0x38(%rsp)
    6bae:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    6bb8:      	movq	%rax, 0x30(%rsp)
    6bbd:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    6bc7:      	movq	%rax, 0x28(%rsp)
    6bcc:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    6bd6:      	movq	%rax, 0x20(%rsp)
    6bdb:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    6be5:      	movq	%rax, 0x18(%rsp)
    6bea:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6bf4:      	movq	%rax, 0x10(%rsp)
    6bf9:      	movb	$0x0, 0x40(%rsp)
    6bfe:      	leaq	0x10(%rsp), %rdi
    6c03:      	movl	$0x31, %eax
    6c08:      	movl	$0x6, %ecx
    6c0d:      	movq	0x58(%rsp), %rdx
    6c12:      	movl	$0x31, %esi
    6c17:      	xorl	%eax, %eax
    6c19:      	callq	*%rcx
    6c1b:      	movl	$0x26, 0x4(%rsp)
    6c23:      	jmp	0x6fd0 <kprobe_unwind_php+0x6fd0>
    6c28:      	movl	0x2c0(%rbp), %eax
    6c2e:      	cmpq	$0x7e, %rax
    6c32:      	ja	0x40e <kprobe_unwind_php+0x40e>
    6c38:      	leal	0x1(%rax), %ecx
    6c3b:      	movl	%ecx, 0x2c0(%rbp)
    6c41:      	leaq	(%rax,%rax,2), %rax
    6c45:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    6c51:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    6c5d:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    6c65:      	jmp	0x6fb2 <kprobe_unwind_php+0x6fb2>
    6c6a:      	movl	$0x0, 0xc(%rsp)
    6c72:      	movzbl	0xb(%rsp), %eax
    6c77:      	cmpl	$0x4, %eax
    6c7a:      	je	0x6c8d <kprobe_unwind_php+0x6c8d>
    6c7c:      	movl	$0x0, 0x4(%rsp)
    6c84:      	cmpl	$0x2, %eax
    6c87:      	jne	0x6f09 <kprobe_unwind_php+0x6f09>
    6c8d:      	movzbl	0x11(%r15), %eax
    6c92:      	addq	%r13, %rax
    6c95:      	leaq	0x68(%rsp), %rdi
    6c9a:      	movl	$0x8, %ecx
    6c9f:      	movl	$0x70, %r8d
    6ca5:      	movzbl	0x11(%r15), %edx
    6caa:      	addq	%r13, %rdx
    6cad:      	movl	$0x8, %esi
    6cb2:      	callq	*%r8
    6cb5:      	testq	%rax, %rax
    6cb8:      	je	0x6d51 <kprobe_unwind_php+0x6d51>
    6cbe:      	movq	(%rip), %rax            # 0x6cc5 <kprobe_unwind_php+0x6cc5>
    6cc5:      	movl	$0x25, 0x4(%rsp)
    6ccd:      	cmpl	$0x0, (%rax)
    6cd0:      	je	0x6fd0 <kprobe_unwind_php+0x6fd0>
    6cd6:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    6ce0:      	movq	%rax, 0x35(%rsp)
    6ce5:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    6cef:      	movq	%rax, 0x30(%rsp)
    6cf4:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    6cfe:      	movq	%rax, 0x28(%rsp)
    6d03:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    6d0d:      	movq	%rax, 0x20(%rsp)
    6d12:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    6d1c:      	movq	%rax, 0x18(%rsp)
    6d21:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6d2b:      	movq	%rax, 0x10(%rsp)
    6d30:      	leaq	0x10(%rsp), %rdi
    6d35:      	movl	$0x2d, %eax
    6d3a:      	movl	$0x6, %ecx
    6d3f:      	movzbl	0x11(%r15), %eax
    6d44:      	addq	%rax, %r13
    6d47:      	movl	$0x2d, %esi
    6d4c:      	jmp	0x6ef5 <kprobe_unwind_php+0x6ef5>
    6d51:      	movzbl	0x15(%r15), %eax
    6d56:      	addq	0x68(%rsp), %rax
    6d5b:      	leaq	0xc(%rsp), %rdi
    6d60:      	movl	$0x4, %ecx
    6d65:      	movl	$0x70, %r8d
    6d6b:      	movzbl	0x15(%r15), %edx
    6d70:      	addq	0x68(%rsp), %rdx
    6d75:      	movl	$0x4, %esi
    6d7a:      	callq	*%r8
    6d7d:      	testq	%rax, %rax
    6d80:      	je	0x6e2f <kprobe_unwind_php+0x6e2f>
    6d86:      	movq	(%rip), %rax            # 0x6d8d <kprobe_unwind_php+0x6d8d>
    6d8d:      	movl	$0x27, 0x4(%rsp)
    6d95:      	cmpl	$0x0, (%rax)
    6d98:      	je	0x6fd0 <kprobe_unwind_php+0x6fd0>
    6d9e:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    6da8:      	movq	%rax, 0x40(%rsp)
    6dad:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    6db7:      	movq	%rax, 0x38(%rsp)
    6dbc:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    6dc6:      	movq	%rax, 0x30(%rsp)
    6dcb:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    6dd5:      	movq	%rax, 0x28(%rsp)
    6dda:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    6de4:      	movq	%rax, 0x20(%rsp)
    6de9:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    6df3:      	movq	%rax, 0x18(%rsp)
    6df8:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6e02:      	movq	%rax, 0x10(%rsp)
    6e07:      	movb	$0x0, 0x48(%rsp)
    6e0c:      	leaq	0x10(%rsp), %rdi
    6e11:      	movl	$0x39, %eax
    6e16:      	movl	$0x6, %ecx
    6e1b:      	movzbl	0x15(%r15), %edx
    6e20:      	addq	0x68(%rsp), %rdx
    6e25:      	movl	$0x39, %esi
    6e2a:      	jmp	0x6ef8 <kprobe_unwind_php+0x6ef8>
    6e2f:      	movzbl	0x13(%r15), %eax
    6e34:      	addq	%r13, %rax
    6e37:      	leaq	0x54(%rsp), %rdi
    6e3c:      	movl	$0x4, %ecx
    6e41:      	movl	$0x70, %r8d
    6e47:      	movzbl	0x13(%r15), %edx
    6e4c:      	addq	%r13, %rdx
    6e4f:      	movl	$0x4, %esi
    6e54:      	callq	*%r8
    6e57:      	testq	%rax, %rax
    6e5a:      	je	0x6f01 <kprobe_unwind_php+0x6f01>
    6e60:      	movq	(%rip), %rax            # 0x6e67 <kprobe_unwind_php+0x6e67>
    6e67:      	movl	$0x25, 0x4(%rsp)
    6e6f:      	cmpl	$0x0, (%rax)
    6e72:      	je	0x6fd0 <kprobe_unwind_php+0x6fd0>
    6e78:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    6e82:      	movq	%rax, 0x3d(%rsp)
    6e87:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    6e91:      	movq	%rax, 0x38(%rsp)
    6e96:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    6ea0:      	movq	%rax, 0x30(%rsp)
    6ea5:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    6eaf:      	movq	%rax, 0x28(%rsp)
    6eb4:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    6ebe:      	movq	%rax, 0x20(%rsp)
    6ec3:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    6ecd:      	movq	%rax, 0x18(%rsp)
    6ed2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6edc:      	movq	%rax, 0x10(%rsp)
    6ee1:      	leaq	0x10(%rsp), %rdi
    6ee6:      	movl	$0x35, %eax
    6eeb:      	movl	$0x6, %ecx
    6ef0:      	movl	$0x35, %esi
    6ef5:      	movq	%r13, %rdx
    6ef8:      	xorl	%eax, %eax
    6efa:      	callq	*%rcx
    6efc:      	jmp	0x6fd0 <kprobe_unwind_php+0x6fd0>
    6f01:      	movl	0xc(%rsp), %eax
    6f05:      	movl	%eax, 0x4(%rsp)
    6f09:      	movl	0x54(%rsp), %r13d
    6f0e:      	movq	(%rip), %rax            # 0x6f15 <kprobe_unwind_php+0x6f15>
    6f15:      	cmpl	$0x0, (%rax)
    6f18:      	je	0x6f6a <kprobe_unwind_php+0x6f6a>
    6f1a:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    6f24:      	movq	%rax, 0x1e(%rsp)
    6f29:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    6f33:      	movq	%rax, 0x18(%rsp)
    6f38:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    6f42:      	movq	%rax, 0x10(%rsp)
    6f47:      	leaq	0x10(%rsp), %rdi
    6f4c:      	movl	$0x16, %eax
    6f51:      	movl	$0x6, %r8d
    6f57:      	movq	0x58(%rsp), %rdx
    6f5c:      	movl	0xc(%rsp), %ecx
    6f60:      	movl	$0x16, %esi
    6f65:      	xorl	%eax, %eax
    6f67:      	callq	*%r8
    6f6a:      	movl	0x2c0(%rbp), %eax
    6f70:      	cmpq	$0x7e, %rax
    6f74:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    6f7a:      	movl	0x4(%rsp), %ecx
    6f7e:      	shlq	$0x20, %r13
    6f82:      	orq	%r13, %rcx
    6f85:      	movq	0x58(%rsp), %rdx
    6f8a:      	leal	0x1(%rax), %esi
    6f8d:      	movl	%esi, 0x2c0(%rbp)
    6f93:      	leaq	(%rax,%rax,2), %rax
    6f97:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    6f9f:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    6fa7:      	movl	0x7c(%rsp), %ecx
    6fab:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    6fb2:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    6fbd:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    6fc8:      	movl	$0x23, 0x4(%rsp)
    6fd0:      	movl	0x4(%rsp), %eax
    6fd4:      	movl	%eax, 0x58(%rsp)
    6fd8:      	movq	(%rip), %rdi            # 0x6fdf <kprobe_unwind_php+0x6fdf>
    6fdf:      	leaq	0x58(%rsp), %rsi
    6fe4:      	movl	$0x1, %eax
    6fe9:      	callq	*%rax
    6feb:      	testq	%rax, %rax
    6fee:      	je	0x6ff8 <kprobe_unwind_php+0x6ff8>
    6ff0:      	incq	(%rax)
    6ff3:      	jmp	0x707a <kprobe_unwind_php+0x707a>
    6ff8:      	movq	(%rip), %rax            # 0x6fff <kprobe_unwind_php+0x6fff>
    6fff:      	cmpl	$0x0, (%rax)
    7002:      	je	0x707a <kprobe_unwind_php+0x707a>
    7004:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    700e:      	movq	%rax, 0x36(%rsp)
    7013:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    701d:      	movq	%rax, 0x30(%rsp)
    7022:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    702c:      	movq	%rax, 0x28(%rsp)
    7031:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    703b:      	movq	%rax, 0x20(%rsp)
    7040:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    704a:      	movq	%rax, 0x18(%rsp)
    704f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7059:      	movq	%rax, 0x10(%rsp)
    705e:      	leaq	0x10(%rsp), %rdi
    7063:      	movl	$0x2e, %eax
    7068:      	movl	$0x6, %ecx
    706d:      	movl	0x58(%rsp), %edx
    7071:      	movl	$0x2e, %esi
    7076:      	xorl	%eax, %eax
    7078:      	callq	*%rcx
    707a:      	cmpl	$0x23, 0x4(%rsp)
    707f:      	jne	0x85e3 <kprobe_unwind_php+0x85e3>
    7085:      	movzbl	0x12(%r15), %eax
    708a:      	addq	0x70(%rsp), %rax
    708f:      	leaq	0x70(%rsp), %rdi
    7094:      	movl	$0x8, %ecx
    7099:      	movl	$0x70, %r8d
    709f:      	movzbl	0x12(%r15), %edx
    70a4:      	addq	0x70(%rsp), %rdx
    70a9:      	movl	$0x8, %esi
    70ae:      	callq	*%r8
    70b1:      	testq	%rax, %rax
    70b4:      	jne	0x317 <kprobe_unwind_php+0x317>
    70ba:      	movq	0x70(%rsp), %r13
    70bf:      	testq	%r13, %r13
    70c2:      	je	0x83ba <kprobe_unwind_php+0x83ba>
    70c8:      	testb	$0x2, 0x56(%rsp)
    70cd:      	jne	0x83ba <kprobe_unwind_php+0x83ba>
    70d3:      	movzbl	0x10(%r15), %eax
    70d8:      	addq	%r13, %rax
    70db:      	leaq	0x58(%rsp), %rdi
    70e0:      	movl	$0x8, %ecx
    70e5:      	movl	$0x70, %r8d
    70eb:      	movzbl	0x10(%r15), %edx
    70f0:      	addq	%r13, %rdx
    70f3:      	movl	$0x8, %esi
    70f8:      	callq	*%r8
    70fb:      	testq	%rax, %rax
    70fe:      	je	0x719f <kprobe_unwind_php+0x719f>
    7104:      	movq	(%rip), %rax            # 0x710b <kprobe_unwind_php+0x710b>
    710b:      	movl	$0x25, 0x4(%rsp)
    7113:      	cmpl	$0x0, (%rax)
    7116:      	je	0x761d <kprobe_unwind_php+0x761d>
    711c:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    7126:      	movq	%rax, 0x38(%rsp)
    712b:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    7135:      	movq	%rax, 0x30(%rsp)
    713a:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    7144:      	movq	%rax, 0x28(%rsp)
    7149:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    7153:      	movq	%rax, 0x20(%rsp)
    7158:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    7162:      	movq	%rax, 0x18(%rsp)
    7167:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7171:      	movq	%rax, 0x10(%rsp)
    7176:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    717e:      	leaq	0x10(%rsp), %rdi
    7183:      	movl	$0x33, %eax
    7188:      	movl	$0x6, %ecx
    718d:      	movzbl	0x10(%r15), %eax
    7192:      	addq	%rax, %r13
    7195:      	movl	$0x33, %esi
    719a:      	jmp	0x7542 <kprobe_unwind_php+0x7542>
    719f:      	movq	0x58(%rsp), %rax
    71a4:      	testq	%rax, %rax
    71a7:      	je	0x7275 <kprobe_unwind_php+0x7275>
    71ad:      	movzbl	0x14(%r15), %ecx
    71b2:      	addq	%rcx, %rax
    71b5:      	leaq	0xb(%rsp), %rdi
    71ba:      	movl	$0x1, %ecx
    71bf:      	movl	$0x70, %r8d
    71c5:      	movzbl	0x14(%r15), %edx
    71ca:      	addq	0x58(%rsp), %rdx
    71cf:      	movl	$0x1, %esi
    71d4:      	callq	*%r8
    71d7:      	testq	%rax, %rax
    71da:      	je	0x72b7 <kprobe_unwind_php+0x72b7>
    71e0:      	movq	(%rip), %rax            # 0x71e7 <kprobe_unwind_php+0x71e7>
    71e7:      	cmpl	$0x0, (%rax)
    71ea:      	je	0x7268 <kprobe_unwind_php+0x7268>
    71ec:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    71f6:      	movq	%rax, 0x38(%rsp)
    71fb:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    7205:      	movq	%rax, 0x30(%rsp)
    720a:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    7214:      	movq	%rax, 0x28(%rsp)
    7219:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    7223:      	movq	%rax, 0x20(%rsp)
    7228:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    7232:      	movq	%rax, 0x18(%rsp)
    7237:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7241:      	movq	%rax, 0x10(%rsp)
    7246:      	movb	$0x0, 0x40(%rsp)
    724b:      	leaq	0x10(%rsp), %rdi
    7250:      	movl	$0x31, %eax
    7255:      	movl	$0x6, %ecx
    725a:      	movq	0x58(%rsp), %rdx
    725f:      	movl	$0x31, %esi
    7264:      	xorl	%eax, %eax
    7266:      	callq	*%rcx
    7268:      	movl	$0x26, 0x4(%rsp)
    7270:      	jmp	0x761d <kprobe_unwind_php+0x761d>
    7275:      	movl	0x2c0(%rbp), %eax
    727b:      	cmpq	$0x7e, %rax
    727f:      	ja	0x40e <kprobe_unwind_php+0x40e>
    7285:      	leal	0x1(%rax), %ecx
    7288:      	movl	%ecx, 0x2c0(%rbp)
    728e:      	leaq	(%rax,%rax,2), %rax
    7292:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    729e:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    72aa:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    72b2:      	jmp	0x75ff <kprobe_unwind_php+0x75ff>
    72b7:      	movl	$0x0, 0xc(%rsp)
    72bf:      	movzbl	0xb(%rsp), %eax
    72c4:      	cmpl	$0x4, %eax
    72c7:      	je	0x72da <kprobe_unwind_php+0x72da>
    72c9:      	movl	$0x0, 0x4(%rsp)
    72d1:      	cmpl	$0x2, %eax
    72d4:      	jne	0x7556 <kprobe_unwind_php+0x7556>
    72da:      	movzbl	0x11(%r15), %eax
    72df:      	addq	%r13, %rax
    72e2:      	leaq	0x68(%rsp), %rdi
    72e7:      	movl	$0x8, %ecx
    72ec:      	movl	$0x70, %r8d
    72f2:      	movzbl	0x11(%r15), %edx
    72f7:      	addq	%r13, %rdx
    72fa:      	movl	$0x8, %esi
    72ff:      	callq	*%r8
    7302:      	testq	%rax, %rax
    7305:      	je	0x739e <kprobe_unwind_php+0x739e>
    730b:      	movq	(%rip), %rax            # 0x7312 <kprobe_unwind_php+0x7312>
    7312:      	movl	$0x25, 0x4(%rsp)
    731a:      	cmpl	$0x0, (%rax)
    731d:      	je	0x761d <kprobe_unwind_php+0x761d>
    7323:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    732d:      	movq	%rax, 0x35(%rsp)
    7332:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    733c:      	movq	%rax, 0x30(%rsp)
    7341:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    734b:      	movq	%rax, 0x28(%rsp)
    7350:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    735a:      	movq	%rax, 0x20(%rsp)
    735f:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    7369:      	movq	%rax, 0x18(%rsp)
    736e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7378:      	movq	%rax, 0x10(%rsp)
    737d:      	leaq	0x10(%rsp), %rdi
    7382:      	movl	$0x2d, %eax
    7387:      	movl	$0x6, %ecx
    738c:      	movzbl	0x11(%r15), %eax
    7391:      	addq	%rax, %r13
    7394:      	movl	$0x2d, %esi
    7399:      	jmp	0x7542 <kprobe_unwind_php+0x7542>
    739e:      	movzbl	0x15(%r15), %eax
    73a3:      	addq	0x68(%rsp), %rax
    73a8:      	leaq	0xc(%rsp), %rdi
    73ad:      	movl	$0x4, %ecx
    73b2:      	movl	$0x70, %r8d
    73b8:      	movzbl	0x15(%r15), %edx
    73bd:      	addq	0x68(%rsp), %rdx
    73c2:      	movl	$0x4, %esi
    73c7:      	callq	*%r8
    73ca:      	testq	%rax, %rax
    73cd:      	je	0x747c <kprobe_unwind_php+0x747c>
    73d3:      	movq	(%rip), %rax            # 0x73da <kprobe_unwind_php+0x73da>
    73da:      	movl	$0x27, 0x4(%rsp)
    73e2:      	cmpl	$0x0, (%rax)
    73e5:      	je	0x761d <kprobe_unwind_php+0x761d>
    73eb:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    73f5:      	movq	%rax, 0x40(%rsp)
    73fa:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    7404:      	movq	%rax, 0x38(%rsp)
    7409:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    7413:      	movq	%rax, 0x30(%rsp)
    7418:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    7422:      	movq	%rax, 0x28(%rsp)
    7427:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    7431:      	movq	%rax, 0x20(%rsp)
    7436:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    7440:      	movq	%rax, 0x18(%rsp)
    7445:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    744f:      	movq	%rax, 0x10(%rsp)
    7454:      	movb	$0x0, 0x48(%rsp)
    7459:      	leaq	0x10(%rsp), %rdi
    745e:      	movl	$0x39, %eax
    7463:      	movl	$0x6, %ecx
    7468:      	movzbl	0x15(%r15), %edx
    746d:      	addq	0x68(%rsp), %rdx
    7472:      	movl	$0x39, %esi
    7477:      	jmp	0x7545 <kprobe_unwind_php+0x7545>
    747c:      	movzbl	0x13(%r15), %eax
    7481:      	addq	%r13, %rax
    7484:      	leaq	0x54(%rsp), %rdi
    7489:      	movl	$0x4, %ecx
    748e:      	movl	$0x70, %r8d
    7494:      	movzbl	0x13(%r15), %edx
    7499:      	addq	%r13, %rdx
    749c:      	movl	$0x4, %esi
    74a1:      	callq	*%r8
    74a4:      	testq	%rax, %rax
    74a7:      	je	0x754e <kprobe_unwind_php+0x754e>
    74ad:      	movq	(%rip), %rax            # 0x74b4 <kprobe_unwind_php+0x74b4>
    74b4:      	movl	$0x25, 0x4(%rsp)
    74bc:      	cmpl	$0x0, (%rax)
    74bf:      	je	0x761d <kprobe_unwind_php+0x761d>
    74c5:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    74cf:      	movq	%rax, 0x3d(%rsp)
    74d4:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    74de:      	movq	%rax, 0x38(%rsp)
    74e3:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    74ed:      	movq	%rax, 0x30(%rsp)
    74f2:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    74fc:      	movq	%rax, 0x28(%rsp)
    7501:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    750b:      	movq	%rax, 0x20(%rsp)
    7510:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    751a:      	movq	%rax, 0x18(%rsp)
    751f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7529:      	movq	%rax, 0x10(%rsp)
    752e:      	leaq	0x10(%rsp), %rdi
    7533:      	movl	$0x35, %eax
    7538:      	movl	$0x6, %ecx
    753d:      	movl	$0x35, %esi
    7542:      	movq	%r13, %rdx
    7545:      	xorl	%eax, %eax
    7547:      	callq	*%rcx
    7549:      	jmp	0x761d <kprobe_unwind_php+0x761d>
    754e:      	movl	0xc(%rsp), %eax
    7552:      	movl	%eax, 0x4(%rsp)
    7556:      	movl	0x54(%rsp), %r13d
    755b:      	movq	(%rip), %rax            # 0x7562 <kprobe_unwind_php+0x7562>
    7562:      	cmpl	$0x0, (%rax)
    7565:      	je	0x75b7 <kprobe_unwind_php+0x75b7>
    7567:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    7571:      	movq	%rax, 0x1e(%rsp)
    7576:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    7580:      	movq	%rax, 0x18(%rsp)
    7585:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    758f:      	movq	%rax, 0x10(%rsp)
    7594:      	leaq	0x10(%rsp), %rdi
    7599:      	movl	$0x16, %eax
    759e:      	movl	$0x6, %r8d
    75a4:      	movq	0x58(%rsp), %rdx
    75a9:      	movl	0xc(%rsp), %ecx
    75ad:      	movl	$0x16, %esi
    75b2:      	xorl	%eax, %eax
    75b4:      	callq	*%r8
    75b7:      	movl	0x2c0(%rbp), %eax
    75bd:      	cmpq	$0x7e, %rax
    75c1:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    75c7:      	movl	0x4(%rsp), %ecx
    75cb:      	shlq	$0x20, %r13
    75cf:      	orq	%r13, %rcx
    75d2:      	movq	0x58(%rsp), %rdx
    75d7:      	leal	0x1(%rax), %esi
    75da:      	movl	%esi, 0x2c0(%rbp)
    75e0:      	leaq	(%rax,%rax,2), %rax
    75e4:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    75ec:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    75f4:      	movl	0x7c(%rsp), %ecx
    75f8:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    75ff:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    760a:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    7615:      	movl	$0x23, 0x4(%rsp)
    761d:      	movl	0x4(%rsp), %eax
    7621:      	movl	%eax, 0x58(%rsp)
    7625:      	movq	(%rip), %rdi            # 0x762c <kprobe_unwind_php+0x762c>
    762c:      	leaq	0x58(%rsp), %rsi
    7631:      	movl	$0x1, %eax
    7636:      	callq	*%rax
    7638:      	testq	%rax, %rax
    763b:      	je	0x7645 <kprobe_unwind_php+0x7645>
    763d:      	incq	(%rax)
    7640:      	jmp	0x76c7 <kprobe_unwind_php+0x76c7>
    7645:      	movq	(%rip), %rax            # 0x764c <kprobe_unwind_php+0x764c>
    764c:      	cmpl	$0x0, (%rax)
    764f:      	je	0x76c7 <kprobe_unwind_php+0x76c7>
    7651:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    765b:      	movq	%rax, 0x36(%rsp)
    7660:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    766a:      	movq	%rax, 0x30(%rsp)
    766f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7679:      	movq	%rax, 0x28(%rsp)
    767e:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7688:      	movq	%rax, 0x20(%rsp)
    768d:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    7697:      	movq	%rax, 0x18(%rsp)
    769c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    76a6:      	movq	%rax, 0x10(%rsp)
    76ab:      	leaq	0x10(%rsp), %rdi
    76b0:      	movl	$0x2e, %eax
    76b5:      	movl	$0x6, %ecx
    76ba:      	movl	0x58(%rsp), %edx
    76be:      	movl	$0x2e, %esi
    76c3:      	xorl	%eax, %eax
    76c5:      	callq	*%rcx
    76c7:      	cmpl	$0x23, 0x4(%rsp)
    76cc:      	jne	0x85e3 <kprobe_unwind_php+0x85e3>
    76d2:      	movzbl	0x12(%r15), %eax
    76d7:      	addq	0x70(%rsp), %rax
    76dc:      	leaq	0x70(%rsp), %rdi
    76e1:      	movl	$0x8, %ecx
    76e6:      	movl	$0x70, %r8d
    76ec:      	movzbl	0x12(%r15), %edx
    76f1:      	addq	0x70(%rsp), %rdx
    76f6:      	movl	$0x8, %esi
    76fb:      	callq	*%r8
    76fe:      	testq	%rax, %rax
    7701:      	jne	0x317 <kprobe_unwind_php+0x317>
    7707:      	movq	0x70(%rsp), %r13
    770c:      	testq	%r13, %r13
    770f:      	je	0x83ba <kprobe_unwind_php+0x83ba>
    7715:      	testb	$0x2, 0x56(%rsp)
    771a:      	jne	0x83ba <kprobe_unwind_php+0x83ba>
    7720:      	movzbl	0x10(%r15), %eax
    7725:      	addq	%r13, %rax
    7728:      	leaq	0x58(%rsp), %rdi
    772d:      	movl	$0x8, %ecx
    7732:      	movl	$0x70, %r8d
    7738:      	movzbl	0x10(%r15), %edx
    773d:      	addq	%r13, %rdx
    7740:      	movl	$0x8, %esi
    7745:      	callq	*%r8
    7748:      	testq	%rax, %rax
    774b:      	je	0x77ec <kprobe_unwind_php+0x77ec>
    7751:      	movq	(%rip), %rax            # 0x7758 <kprobe_unwind_php+0x7758>
    7758:      	movl	$0x25, 0x4(%rsp)
    7760:      	cmpl	$0x0, (%rax)
    7763:      	je	0x7c6a <kprobe_unwind_php+0x7c6a>
    7769:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    7773:      	movq	%rax, 0x38(%rsp)
    7778:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    7782:      	movq	%rax, 0x30(%rsp)
    7787:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    7791:      	movq	%rax, 0x28(%rsp)
    7796:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    77a0:      	movq	%rax, 0x20(%rsp)
    77a5:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    77af:      	movq	%rax, 0x18(%rsp)
    77b4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    77be:      	movq	%rax, 0x10(%rsp)
    77c3:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    77cb:      	leaq	0x10(%rsp), %rdi
    77d0:      	movl	$0x33, %eax
    77d5:      	movl	$0x6, %ecx
    77da:      	movzbl	0x10(%r15), %eax
    77df:      	addq	%rax, %r13
    77e2:      	movl	$0x33, %esi
    77e7:      	jmp	0x7b8f <kprobe_unwind_php+0x7b8f>
    77ec:      	movq	0x58(%rsp), %rax
    77f1:      	testq	%rax, %rax
    77f4:      	je	0x78c2 <kprobe_unwind_php+0x78c2>
    77fa:      	movzbl	0x14(%r15), %ecx
    77ff:      	addq	%rcx, %rax
    7802:      	leaq	0xb(%rsp), %rdi
    7807:      	movl	$0x1, %ecx
    780c:      	movl	$0x70, %r8d
    7812:      	movzbl	0x14(%r15), %edx
    7817:      	addq	0x58(%rsp), %rdx
    781c:      	movl	$0x1, %esi
    7821:      	callq	*%r8
    7824:      	testq	%rax, %rax
    7827:      	je	0x7904 <kprobe_unwind_php+0x7904>
    782d:      	movq	(%rip), %rax            # 0x7834 <kprobe_unwind_php+0x7834>
    7834:      	cmpl	$0x0, (%rax)
    7837:      	je	0x78b5 <kprobe_unwind_php+0x78b5>
    7839:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    7843:      	movq	%rax, 0x38(%rsp)
    7848:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    7852:      	movq	%rax, 0x30(%rsp)
    7857:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    7861:      	movq	%rax, 0x28(%rsp)
    7866:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    7870:      	movq	%rax, 0x20(%rsp)
    7875:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    787f:      	movq	%rax, 0x18(%rsp)
    7884:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    788e:      	movq	%rax, 0x10(%rsp)
    7893:      	movb	$0x0, 0x40(%rsp)
    7898:      	leaq	0x10(%rsp), %rdi
    789d:      	movl	$0x31, %eax
    78a2:      	movl	$0x6, %ecx
    78a7:      	movq	0x58(%rsp), %rdx
    78ac:      	movl	$0x31, %esi
    78b1:      	xorl	%eax, %eax
    78b3:      	callq	*%rcx
    78b5:      	movl	$0x26, 0x4(%rsp)
    78bd:      	jmp	0x7c6a <kprobe_unwind_php+0x7c6a>
    78c2:      	movl	0x2c0(%rbp), %eax
    78c8:      	cmpq	$0x7e, %rax
    78cc:      	ja	0x40e <kprobe_unwind_php+0x40e>
    78d2:      	leal	0x1(%rax), %ecx
    78d5:      	movl	%ecx, 0x2c0(%rbp)
    78db:      	leaq	(%rax,%rax,2), %rax
    78df:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    78eb:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    78f7:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    78ff:      	jmp	0x7c4c <kprobe_unwind_php+0x7c4c>
    7904:      	movl	$0x0, 0xc(%rsp)
    790c:      	movzbl	0xb(%rsp), %eax
    7911:      	cmpl	$0x4, %eax
    7914:      	je	0x7927 <kprobe_unwind_php+0x7927>
    7916:      	movl	$0x0, 0x4(%rsp)
    791e:      	cmpl	$0x2, %eax
    7921:      	jne	0x7ba3 <kprobe_unwind_php+0x7ba3>
    7927:      	movzbl	0x11(%r15), %eax
    792c:      	addq	%r13, %rax
    792f:      	leaq	0x68(%rsp), %rdi
    7934:      	movl	$0x8, %ecx
    7939:      	movl	$0x70, %r8d
    793f:      	movzbl	0x11(%r15), %edx
    7944:      	addq	%r13, %rdx
    7947:      	movl	$0x8, %esi
    794c:      	callq	*%r8
    794f:      	testq	%rax, %rax
    7952:      	je	0x79eb <kprobe_unwind_php+0x79eb>
    7958:      	movq	(%rip), %rax            # 0x795f <kprobe_unwind_php+0x795f>
    795f:      	movl	$0x25, 0x4(%rsp)
    7967:      	cmpl	$0x0, (%rax)
    796a:      	je	0x7c6a <kprobe_unwind_php+0x7c6a>
    7970:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    797a:      	movq	%rax, 0x35(%rsp)
    797f:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    7989:      	movq	%rax, 0x30(%rsp)
    798e:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    7998:      	movq	%rax, 0x28(%rsp)
    799d:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    79a7:      	movq	%rax, 0x20(%rsp)
    79ac:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    79b6:      	movq	%rax, 0x18(%rsp)
    79bb:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    79c5:      	movq	%rax, 0x10(%rsp)
    79ca:      	leaq	0x10(%rsp), %rdi
    79cf:      	movl	$0x2d, %eax
    79d4:      	movl	$0x6, %ecx
    79d9:      	movzbl	0x11(%r15), %eax
    79de:      	addq	%rax, %r13
    79e1:      	movl	$0x2d, %esi
    79e6:      	jmp	0x7b8f <kprobe_unwind_php+0x7b8f>
    79eb:      	movzbl	0x15(%r15), %eax
    79f0:      	addq	0x68(%rsp), %rax
    79f5:      	leaq	0xc(%rsp), %rdi
    79fa:      	movl	$0x4, %ecx
    79ff:      	movl	$0x70, %r8d
    7a05:      	movzbl	0x15(%r15), %edx
    7a0a:      	addq	0x68(%rsp), %rdx
    7a0f:      	movl	$0x4, %esi
    7a14:      	callq	*%r8
    7a17:      	testq	%rax, %rax
    7a1a:      	je	0x7ac9 <kprobe_unwind_php+0x7ac9>
    7a20:      	movq	(%rip), %rax            # 0x7a27 <kprobe_unwind_php+0x7a27>
    7a27:      	movl	$0x27, 0x4(%rsp)
    7a2f:      	cmpl	$0x0, (%rax)
    7a32:      	je	0x7c6a <kprobe_unwind_php+0x7c6a>
    7a38:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    7a42:      	movq	%rax, 0x40(%rsp)
    7a47:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    7a51:      	movq	%rax, 0x38(%rsp)
    7a56:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    7a60:      	movq	%rax, 0x30(%rsp)
    7a65:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    7a6f:      	movq	%rax, 0x28(%rsp)
    7a74:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    7a7e:      	movq	%rax, 0x20(%rsp)
    7a83:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    7a8d:      	movq	%rax, 0x18(%rsp)
    7a92:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7a9c:      	movq	%rax, 0x10(%rsp)
    7aa1:      	movb	$0x0, 0x48(%rsp)
    7aa6:      	leaq	0x10(%rsp), %rdi
    7aab:      	movl	$0x39, %eax
    7ab0:      	movl	$0x6, %ecx
    7ab5:      	movzbl	0x15(%r15), %edx
    7aba:      	addq	0x68(%rsp), %rdx
    7abf:      	movl	$0x39, %esi
    7ac4:      	jmp	0x7b92 <kprobe_unwind_php+0x7b92>
    7ac9:      	movzbl	0x13(%r15), %eax
    7ace:      	addq	%r13, %rax
    7ad1:      	leaq	0x54(%rsp), %rdi
    7ad6:      	movl	$0x4, %ecx
    7adb:      	movl	$0x70, %r8d
    7ae1:      	movzbl	0x13(%r15), %edx
    7ae6:      	addq	%r13, %rdx
    7ae9:      	movl	$0x4, %esi
    7aee:      	callq	*%r8
    7af1:      	testq	%rax, %rax
    7af4:      	je	0x7b9b <kprobe_unwind_php+0x7b9b>
    7afa:      	movq	(%rip), %rax            # 0x7b01 <kprobe_unwind_php+0x7b01>
    7b01:      	movl	$0x25, 0x4(%rsp)
    7b09:      	cmpl	$0x0, (%rax)
    7b0c:      	je	0x7c6a <kprobe_unwind_php+0x7c6a>
    7b12:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    7b1c:      	movq	%rax, 0x3d(%rsp)
    7b21:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    7b2b:      	movq	%rax, 0x38(%rsp)
    7b30:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    7b3a:      	movq	%rax, 0x30(%rsp)
    7b3f:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    7b49:      	movq	%rax, 0x28(%rsp)
    7b4e:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    7b58:      	movq	%rax, 0x20(%rsp)
    7b5d:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    7b67:      	movq	%rax, 0x18(%rsp)
    7b6c:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7b76:      	movq	%rax, 0x10(%rsp)
    7b7b:      	leaq	0x10(%rsp), %rdi
    7b80:      	movl	$0x35, %eax
    7b85:      	movl	$0x6, %ecx
    7b8a:      	movl	$0x35, %esi
    7b8f:      	movq	%r13, %rdx
    7b92:      	xorl	%eax, %eax
    7b94:      	callq	*%rcx
    7b96:      	jmp	0x7c6a <kprobe_unwind_php+0x7c6a>
    7b9b:      	movl	0xc(%rsp), %eax
    7b9f:      	movl	%eax, 0x4(%rsp)
    7ba3:      	movl	0x54(%rsp), %r13d
    7ba8:      	movq	(%rip), %rax            # 0x7baf <kprobe_unwind_php+0x7baf>
    7baf:      	cmpl	$0x0, (%rax)
    7bb2:      	je	0x7c04 <kprobe_unwind_php+0x7c04>
    7bb4:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    7bbe:      	movq	%rax, 0x1e(%rsp)
    7bc3:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    7bcd:      	movq	%rax, 0x18(%rsp)
    7bd2:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    7bdc:      	movq	%rax, 0x10(%rsp)
    7be1:      	leaq	0x10(%rsp), %rdi
    7be6:      	movl	$0x16, %eax
    7beb:      	movl	$0x6, %r8d
    7bf1:      	movq	0x58(%rsp), %rdx
    7bf6:      	movl	0xc(%rsp), %ecx
    7bfa:      	movl	$0x16, %esi
    7bff:      	xorl	%eax, %eax
    7c01:      	callq	*%r8
    7c04:      	movl	0x2c0(%rbp), %eax
    7c0a:      	cmpq	$0x7e, %rax
    7c0e:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    7c14:      	movl	0x4(%rsp), %ecx
    7c18:      	shlq	$0x20, %r13
    7c1c:      	orq	%r13, %rcx
    7c1f:      	movq	0x58(%rsp), %rdx
    7c24:      	leal	0x1(%rax), %esi
    7c27:      	movl	%esi, 0x2c0(%rbp)
    7c2d:      	leaq	(%rax,%rax,2), %rax
    7c31:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    7c39:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    7c41:      	movl	0x7c(%rsp), %ecx
    7c45:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    7c4c:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    7c57:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    7c62:      	movl	$0x23, 0x4(%rsp)
    7c6a:      	movl	0x4(%rsp), %eax
    7c6e:      	movl	%eax, 0x58(%rsp)
    7c72:      	movq	(%rip), %rdi            # 0x7c79 <kprobe_unwind_php+0x7c79>
    7c79:      	leaq	0x58(%rsp), %rsi
    7c7e:      	movl	$0x1, %eax
    7c83:      	callq	*%rax
    7c85:      	testq	%rax, %rax
    7c88:      	je	0x7c92 <kprobe_unwind_php+0x7c92>
    7c8a:      	incq	(%rax)
    7c8d:      	jmp	0x7d14 <kprobe_unwind_php+0x7d14>
    7c92:      	movq	(%rip), %rax            # 0x7c99 <kprobe_unwind_php+0x7c99>
    7c99:      	cmpl	$0x0, (%rax)
    7c9c:      	je	0x7d14 <kprobe_unwind_php+0x7d14>
    7c9e:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    7ca8:      	movq	%rax, 0x36(%rsp)
    7cad:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7cb7:      	movq	%rax, 0x30(%rsp)
    7cbc:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7cc6:      	movq	%rax, 0x28(%rsp)
    7ccb:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7cd5:      	movq	%rax, 0x20(%rsp)
    7cda:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    7ce4:      	movq	%rax, 0x18(%rsp)
    7ce9:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7cf3:      	movq	%rax, 0x10(%rsp)
    7cf8:      	leaq	0x10(%rsp), %rdi
    7cfd:      	movl	$0x2e, %eax
    7d02:      	movl	$0x6, %ecx
    7d07:      	movl	0x58(%rsp), %edx
    7d0b:      	movl	$0x2e, %esi
    7d10:      	xorl	%eax, %eax
    7d12:      	callq	*%rcx
    7d14:      	cmpl	$0x23, 0x4(%rsp)
    7d19:      	jne	0x85e3 <kprobe_unwind_php+0x85e3>
    7d1f:      	movzbl	0x12(%r15), %eax
    7d24:      	addq	0x70(%rsp), %rax
    7d29:      	leaq	0x70(%rsp), %rdi
    7d2e:      	movl	$0x8, %ecx
    7d33:      	movl	$0x70, %r8d
    7d39:      	movzbl	0x12(%r15), %edx
    7d3e:      	addq	0x70(%rsp), %rdx
    7d43:      	movl	$0x8, %esi
    7d48:      	callq	*%r8
    7d4b:      	testq	%rax, %rax
    7d4e:      	jne	0x317 <kprobe_unwind_php+0x317>
    7d54:      	movq	0x70(%rsp), %r13
    7d59:      	testq	%r13, %r13
    7d5c:      	je	0x83ba <kprobe_unwind_php+0x83ba>
    7d62:      	testb	$0x2, 0x56(%rsp)
    7d67:      	jne	0x83ba <kprobe_unwind_php+0x83ba>
    7d6d:      	movzbl	0x10(%r15), %eax
    7d72:      	addq	%r13, %rax
    7d75:      	leaq	0x58(%rsp), %rdi
    7d7a:      	movl	$0x8, %ecx
    7d7f:      	movl	$0x70, %r8d
    7d85:      	movzbl	0x10(%r15), %edx
    7d8a:      	addq	%r13, %rdx
    7d8d:      	movl	$0x8, %esi
    7d92:      	callq	*%r8
    7d95:      	testq	%rax, %rax
    7d98:      	je	0x7e39 <kprobe_unwind_php+0x7e39>
    7d9e:      	movq	(%rip), %rax            # 0x7da5 <kprobe_unwind_php+0x7da5>
    7da5:      	movl	$0x25, 0x7c(%rsp)
    7dad:      	cmpl	$0x0, (%rax)
    7db0:      	je	0x82b7 <kprobe_unwind_php+0x82b7>
    7db6:      	movabsq	$0x786c257830282063, %rax # imm = 0x786C257830282063
    7dc0:      	movq	%rax, 0x38(%rsp)
    7dc5:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    7dcf:      	movq	%rax, 0x30(%rsp)
    7dd4:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    7dde:      	movq	%rax, 0x28(%rsp)
    7de3:      	movabsq	$0x655f746e65727275, %rax # imm = 0x655F746E65727275
    7ded:      	movq	%rax, 0x20(%rsp)
    7df2:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
    7dfc:      	movq	%rax, 0x18(%rsp)
    7e01:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7e0b:      	movq	%rax, 0x10(%rsp)
    7e10:      	movl	$0xa2978, 0x3f(%rsp)    # imm = 0xA2978
    7e18:      	leaq	0x10(%rsp), %rdi
    7e1d:      	movl	$0x33, %eax
    7e22:      	movl	$0x6, %ecx
    7e27:      	movzbl	0x10(%r15), %eax
    7e2c:      	addq	%rax, %r13
    7e2f:      	movl	$0x33, %esi
    7e34:      	jmp	0x81dc <kprobe_unwind_php+0x81dc>
    7e39:      	movq	0x58(%rsp), %rax
    7e3e:      	testq	%rax, %rax
    7e41:      	je	0x7f0f <kprobe_unwind_php+0x7f0f>
    7e47:      	movzbl	0x14(%r15), %ecx
    7e4c:      	addq	%rcx, %rax
    7e4f:      	leaq	0xb(%rsp), %rdi
    7e54:      	movl	$0x1, %ecx
    7e59:      	movl	$0x70, %r8d
    7e5f:      	movzbl	0x14(%r15), %edx
    7e64:      	addq	0x58(%rsp), %rdx
    7e69:      	movl	$0x1, %esi
    7e6e:      	callq	*%r8
    7e71:      	testq	%rax, %rax
    7e74:      	je	0x7f51 <kprobe_unwind_php+0x7f51>
    7e7a:      	movq	(%rip), %rax            # 0x7e81 <kprobe_unwind_php+0x7e81>
    7e81:      	cmpl	$0x0, (%rax)
    7e84:      	je	0x7f02 <kprobe_unwind_php+0x7f02>
    7e86:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    7e90:      	movq	%rax, 0x38(%rsp)
    7e95:      	movabsq	$0x20657079743e2d63, %rax # imm = 0x20657079743E2D63
    7e9f:      	movq	%rax, 0x30(%rsp)
    7ea4:      	movabsq	$0x6e75663e2d617461, %rax # imm = 0x6E75663E2D617461
    7eae:      	movq	%rax, 0x28(%rsp)
    7eb3:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    7ebd:      	movq	%rax, 0x20(%rsp)
    7ec2:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    7ecc:      	movq	%rax, 0x18(%rsp)
    7ed1:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7edb:      	movq	%rax, 0x10(%rsp)
    7ee0:      	movb	$0x0, 0x40(%rsp)
    7ee5:      	leaq	0x10(%rsp), %rdi
    7eea:      	movl	$0x31, %eax
    7eef:      	movl	$0x6, %ecx
    7ef4:      	movq	0x58(%rsp), %rdx
    7ef9:      	movl	$0x31, %esi
    7efe:      	xorl	%eax, %eax
    7f00:      	callq	*%rcx
    7f02:      	movl	$0x26, 0x7c(%rsp)
    7f0a:      	jmp	0x82b7 <kprobe_unwind_php+0x82b7>
    7f0f:      	movl	0x2c0(%rbp), %eax
    7f15:      	cmpq	$0x7e, %rax
    7f19:      	ja	0x40e <kprobe_unwind_php+0x40e>
    7f1f:      	leal	0x1(%rax), %ecx
    7f22:      	movl	%ecx, 0x2c0(%rbp)
    7f28:      	leaq	(%rax,%rax,2), %rax
    7f2c:      	movq	$0x0, 0x2d0(%rbp,%rax,8)
    7f38:      	movq	$-0x2, 0x2d8(%rbp,%rax,8)
    7f44:      	movb	$0x2, 0x2e0(%rbp,%rax,8)
    7f4c:      	jmp	0x8299 <kprobe_unwind_php+0x8299>
    7f51:      	movl	$0x0, 0xc(%rsp)
    7f59:      	movzbl	0xb(%rsp), %eax
    7f5e:      	cmpl	$0x4, %eax
    7f61:      	je	0x7f74 <kprobe_unwind_php+0x7f74>
    7f63:      	movl	$0x0, 0x4(%rsp)
    7f6b:      	cmpl	$0x2, %eax
    7f6e:      	jne	0x81f0 <kprobe_unwind_php+0x81f0>
    7f74:      	movzbl	0x11(%r15), %eax
    7f79:      	addq	%r13, %rax
    7f7c:      	leaq	0x68(%rsp), %rdi
    7f81:      	movl	$0x8, %ecx
    7f86:      	movl	$0x70, %r8d
    7f8c:      	movzbl	0x11(%r15), %edx
    7f91:      	addq	%r13, %rdx
    7f94:      	movl	$0x8, %esi
    7f99:      	callq	*%r8
    7f9c:      	testq	%rax, %rax
    7f9f:      	je	0x8038 <kprobe_unwind_php+0x8038>
    7fa5:      	movq	(%rip), %rax            # 0x7fac <kprobe_unwind_php+0x7fac>
    7fac:      	movl	$0x25, 0x7c(%rsp)
    7fb4:      	cmpl	$0x0, (%rax)
    7fb7:      	je	0x82b7 <kprobe_unwind_php+0x82b7>
    7fbd:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    7fc7:      	movq	%rax, 0x35(%rsp)
    7fcc:      	movabsq	$0x2578302820656e69, %rax # imm = 0x2578302820656E69
    7fd6:      	movq	%rax, 0x30(%rsp)
    7fdb:      	movabsq	$0x6c706f3e2d617461, %rax # imm = 0x6C706F3E2D617461
    7fe5:      	movq	%rax, 0x28(%rsp)
    7fea:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    7ff4:      	movq	%rax, 0x20(%rsp)
    7ff9:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    8003:      	movq	%rax, 0x18(%rsp)
    8008:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    8012:      	movq	%rax, 0x10(%rsp)
    8017:      	leaq	0x10(%rsp), %rdi
    801c:      	movl	$0x2d, %eax
    8021:      	movl	$0x6, %ecx
    8026:      	movzbl	0x11(%r15), %eax
    802b:      	addq	%rax, %r13
    802e:      	movl	$0x2d, %esi
    8033:      	jmp	0x81dc <kprobe_unwind_php+0x81dc>
    8038:      	movzbl	0x15(%r15), %eax
    803d:      	addq	0x68(%rsp), %rax
    8042:      	leaq	0xc(%rsp), %rdi
    8047:      	movl	$0x4, %ecx
    804c:      	movl	$0x70, %r8d
    8052:      	movzbl	0x15(%r15), %edx
    8057:      	addq	0x68(%rsp), %rdx
    805c:      	movl	$0x4, %esi
    8061:      	callq	*%r8
    8064:      	testq	%rax, %rax
    8067:      	je	0x8116 <kprobe_unwind_php+0x8116>
    806d:      	movq	(%rip), %rax            # 0x8074 <kprobe_unwind_php+0x8074>
    8074:      	movl	$0x27, 0x7c(%rsp)
    807c:      	cmpl	$0x0, (%rax)
    807f:      	je	0x82b7 <kprobe_unwind_php+0x82b7>
    8085:      	movabsq	$0xa29786c25783028, %rax # imm = 0xA29786C25783028
    808f:      	movq	%rax, 0x40(%rsp)
    8094:      	movabsq	$0x206f6e656e696c3e, %rax # imm = 0x206F6E656E696C3E
    809e:      	movq	%rax, 0x38(%rsp)
    80a3:      	movabsq	$0x2d656e696c706f3e, %rax # imm = 0x2D656E696C706F3E
    80ad:      	movq	%rax, 0x30(%rsp)
    80b2:      	movabsq	$0x2d736c61626f6c67, %rax # imm = 0x2D736C61626F6C67
    80bc:      	movq	%rax, 0x28(%rsp)
    80c1:      	movabsq	$0x5f726f7475636578, %rax # imm = 0x5F726F7475636578
    80cb:      	movq	%rax, 0x20(%rsp)
    80d0:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    80da:      	movq	%rax, 0x18(%rsp)
    80df:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    80e9:      	movq	%rax, 0x10(%rsp)
    80ee:      	movb	$0x0, 0x48(%rsp)
    80f3:      	leaq	0x10(%rsp), %rdi
    80f8:      	movl	$0x39, %eax
    80fd:      	movl	$0x6, %ecx
    8102:      	movzbl	0x15(%r15), %edx
    8107:      	addq	0x68(%rsp), %rdx
    810c:      	movl	$0x39, %esi
    8111:      	jmp	0x81df <kprobe_unwind_php+0x81df>
    8116:      	movzbl	0x13(%r15), %eax
    811b:      	addq	%r13, %rax
    811e:      	leaq	0x54(%rsp), %rdi
    8123:      	movl	$0x4, %ecx
    8128:      	movl	$0x70, %r8d
    812e:      	movzbl	0x13(%r15), %edx
    8133:      	addq	%r13, %rdx
    8136:      	movl	$0x4, %esi
    813b:      	callq	*%r8
    813e:      	testq	%rax, %rax
    8141:      	je	0x81e8 <kprobe_unwind_php+0x81e8>
    8147:      	movq	(%rip), %rax            # 0x814e <kprobe_unwind_php+0x814e>
    814e:      	movl	$0x25, 0x7c(%rsp)
    8156:      	cmpl	$0x0, (%rax)
    8159:      	je	0x82b7 <kprobe_unwind_php+0x82b7>
    815f:      	movabsq	$0xa29786c257830, %rax  # imm = 0xA29786C257830
    8169:      	movq	%rax, 0x3d(%rsp)
    816e:      	movabsq	$0x25783028206f666e, %rax # imm = 0x25783028206F666E
    8178:      	movq	%rax, 0x38(%rsp)
    817d:      	movabsq	$0x695f657079742e73, %rax # imm = 0x695F657079742E73
    8187:      	movq	%rax, 0x30(%rsp)
    818c:      	movabsq	$0x6968543e2d617461, %rax # imm = 0x6968543E2D617461
    8196:      	movq	%rax, 0x28(%rsp)
    819b:      	movabsq	$0x645f657475636578, %rax # imm = 0x645F657475636578
    81a5:      	movq	%rax, 0x20(%rsp)
    81aa:      	movabsq	$0x652064616572206f, %rax # imm = 0x652064616572206F
    81b4:      	movq	%rax, 0x18(%rsp)
    81b9:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    81c3:      	movq	%rax, 0x10(%rsp)
    81c8:      	leaq	0x10(%rsp), %rdi
    81cd:      	movl	$0x35, %eax
    81d2:      	movl	$0x6, %ecx
    81d7:      	movl	$0x35, %esi
    81dc:      	movq	%r13, %rdx
    81df:      	xorl	%eax, %eax
    81e1:      	callq	*%rcx
    81e3:      	jmp	0x82b7 <kprobe_unwind_php+0x82b7>
    81e8:      	movl	0xc(%rsp), %eax
    81ec:      	movl	%eax, 0x4(%rsp)
    81f0:      	movl	0x54(%rsp), %r13d
    81f5:      	movq	(%rip), %rax            # 0x81fc <kprobe_unwind_php+0x81fc>
    81fc:      	cmpl	$0x0, (%rax)
    81ff:      	je	0x8251 <kprobe_unwind_php+0x8251>
    8201:      	movabsq	$0xa752520786c25, %rax  # imm = 0xA752520786C25
    820b:      	movq	%rax, 0x1e(%rsp)
    8210:      	movabsq	$0x6c25783020504850, %rax # imm = 0x6C25783020504850
    821a:      	movq	%rax, 0x18(%rsp)
    821f:      	movabsq	$0x20676e6968737550, %rax # imm = 0x20676E6968737550
    8229:      	movq	%rax, 0x10(%rsp)
    822e:      	leaq	0x10(%rsp), %rdi
    8233:      	movl	$0x16, %eax
    8238:      	movl	$0x6, %r8d
    823e:      	movq	0x58(%rsp), %rdx
    8243:      	movl	0xc(%rsp), %ecx
    8247:      	movl	$0x16, %esi
    824c:      	xorl	%eax, %eax
    824e:      	callq	*%r8
    8251:      	movl	0x2c0(%rbp), %eax
    8257:      	cmpq	$0x7e, %rax
    825b:      	ja	0xb47 <kprobe_unwind_php+0xb47>
    8261:      	movl	0x4(%rsp), %ecx
    8265:      	shlq	$0x20, %r13
    8269:      	orq	%r13, %rcx
    826c:      	movq	0x58(%rsp), %rdx
    8271:      	leal	0x1(%rax), %esi
    8274:      	movl	%esi, 0x2c0(%rbp)
    827a:      	leaq	(%rax,%rax,2), %rax
    827e:      	movq	%rdx, 0x2d0(%rbp,%rax,8)
    8286:      	movq	%rcx, 0x2d8(%rbp,%rax,8)
    828e:      	movl	0x7c(%rsp), %ecx
    8292:      	movb	%cl, 0x2e0(%rbp,%rax,8)
    8299:      	movl	$0x0, 0x2e1(%rbp,%rax,8)
    82a4:      	movl	$0x0, 0x2e4(%rbp,%rax,8)
    82af:      	movl	$0x23, 0x7c(%rsp)
    82b7:      	movl	0x7c(%rsp), %eax
    82bb:      	movl	%eax, 0x58(%rsp)
    82bf:      	movq	(%rip), %rdi            # 0x82c6 <kprobe_unwind_php+0x82c6>
    82c6:      	leaq	0x58(%rsp), %rsi
    82cb:      	movl	$0x1, %eax
    82d0:      	callq	*%rax
    82d2:      	testq	%rax, %rax
    82d5:      	je	0x82df <kprobe_unwind_php+0x82df>
    82d7:      	incq	(%rax)
    82da:      	jmp	0x8361 <kprobe_unwind_php+0x8361>
    82df:      	movq	(%rip), %rax            # 0x82e6 <kprobe_unwind_php+0x82e6>
    82e6:      	cmpl	$0x0, (%rax)
    82e9:      	je	0x8361 <kprobe_unwind_php+0x8361>
    82eb:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    82f5:      	movq	%rax, 0x36(%rsp)
    82fa:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    8304:      	movq	%rax, 0x30(%rsp)
    8309:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    8313:      	movq	%rax, 0x28(%rsp)
    8318:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    8322:      	movq	%rax, 0x20(%rsp)
    8327:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    8331:      	movq	%rax, 0x18(%rsp)
    8336:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    8340:      	movq	%rax, 0x10(%rsp)
    8345:      	leaq	0x10(%rsp), %rdi
    834a:      	movl	$0x2e, %eax
    834f:      	movl	$0x6, %ecx
    8354:      	movl	0x58(%rsp), %edx
    8358:      	movl	$0x2e, %esi
    835d:      	xorl	%eax, %eax
    835f:      	callq	*%rcx
    8361:      	cmpl	$0x23, 0x7c(%rsp)
    8366:      	jne	0x85e3 <kprobe_unwind_php+0x85e3>
    836c:      	movzbl	0x12(%r15), %eax
    8371:      	addq	0x70(%rsp), %rax
    8376:      	leaq	0x70(%rsp), %rdi
    837b:      	movl	$0x8, %ecx
    8380:      	movl	$0x70, %r8d
    8386:      	movzbl	0x12(%r15), %edx
    838b:      	addq	0x70(%rsp), %rdx
    8390:      	movl	$0x8, %esi
    8395:      	callq	*%r8
    8398:      	testq	%rax, %rax
    839b:      	jne	0x317 <kprobe_unwind_php+0x317>
    83a1:      	cmpq	$0x0, 0x70(%rsp)
    83a7:      	je	0x83ba <kprobe_unwind_php+0x83ba>
    83a9:      	movl	$0x5, %r12d
    83af:      	testb	$0x2, 0x56(%rsp)
    83b4:      	je	0x85d9 <kprobe_unwind_php+0x85d9>
    83ba:      	movq	(%rip), %r13            # 0x83c1 <kprobe_unwind_php+0x83c1>
    83c1:      	cmpl	$0x0, (%r13)
    83c6:      	jne	0x8733 <kprobe_unwind_php+0x8733>
    83cc:      	movl	$0x1, %r12d
    83d2:      	cmpb	$0x0, 0x80(%rsp)
    83da:      	je	0x85d9 <kprobe_unwind_php+0x85d9>
    83e0:      	movq	0x8(%r15), %r15
    83e4:      	movq	%r15, 0xed0(%rbp)
    83eb:      	movb	$0x0, 0xf30(%rbp)
    83f2:      	movq	%r15, %rax
    83f5:      	shrq	$0x38, %rax
    83f9:      	je	0x8415 <kprobe_unwind_php+0x8415>
    83fb:      	cmpl	$0x0, (%r13)
    8400:      	jne	0x87bc <kprobe_unwind_php+0x87bc>
    8406:      	movl	$0xb, 0xf28(%rbp)
    8410:      	jmp	0x85d6 <kprobe_unwind_php+0x85d6>
    8415:      	cmpq	$0xfff, %r15            # imm = 0xFFF
    841c:      	ja	0x8438 <kprobe_unwind_php+0x8438>
    841e:      	cmpl	$0x0, (%r13)
    8423:      	jne	0x881f <kprobe_unwind_php+0x881f>
    8429:      	movl	$0x31, 0xf28(%rbp)
    8433:      	jmp	0x85d6 <kprobe_unwind_php+0x85d6>
    8438:      	movl	(%rbp), %eax
    843b:      	movl	$0x60, 0x58(%rsp)
    8443:      	movbel	%eax, 0x5c(%rsp)
    8449:      	movbeq	%r15, 0x60(%rsp)
    8450:      	movq	(%rip), %rdi            # 0x8457 <kprobe_unwind_php+0x8457>
    8457:      	leaq	0x58(%rsp), %rsi
    845c:      	movl	$0x1, %eax
    8461:      	callq	*%rax
    8463:      	testq	%rax, %rax
    8466:      	je	0x85c1 <kprobe_unwind_php+0x85c1>
    846c:      	movabsq	$0xffffffffffffff, %rcx # imm = 0xFFFFFFFFFFFFFF
    8476:      	movq	0x8(%rax), %r12
    847a:      	andq	%r12, %rcx
    847d:      	movq	%rcx, 0xf20(%rbp)
    8484:      	movq	(%rax), %rax
    8487:      	movq	%rax, 0xf10(%rbp)
    848e:      	shrq	$0x38, %r12
    8492:      	movq	%r15, %rax
    8495:      	subq	%rcx, %rax
    8498:      	movq	%rax, 0xf18(%rbp)
    849f:      	cmpl	$0x0, (%r13)
    84a4:      	je	0x85d9 <kprobe_unwind_php+0x85d9>
    84aa:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    84b4:      	movq	%rax, 0x38(%rsp)
    84b9:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    84c3:      	movq	%rax, 0x30(%rsp)
    84c8:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    84d2:      	movq	%rax, 0x28(%rsp)
    84d7:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    84e1:      	movq	%rax, 0x20(%rsp)
    84e6:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    84f0:      	movq	%rax, 0x18(%rsp)
    84f5:      	movabsq	$0x6365732074786554, %rax # imm = 0x6365732074786554
    84ff:      	movq	%rax, 0x10(%rsp)
    8504:      	movw	$0xa, 0x40(%rsp)
    850b:      	leaq	0x10(%rsp), %rdi
    8510:      	movl	$0x32, %eax
    8515:      	movl	$0x6, %r9d
    851b:      	movq	0xf10(%rbp), %rcx
    8522:      	movl	$0x32, %esi
    8527:      	movq	%r15, %rdx
    852a:      	movl	%r12d, %r8d
    852d:      	xorl	%eax, %eax
    852f:      	callq	*%r9
    8532:      	cmpl	$0x0, (%r13)
    8537:      	je	0x85d9 <kprobe_unwind_php+0x85d9>
    853d:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    8547:      	movq	%rax, 0x37(%rsp)
    854c:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    8556:      	movq	%rax, 0x30(%rsp)
    855b:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    8565:      	movq	%rax, 0x28(%rsp)
    856a:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    8574:      	movq	%rax, 0x20(%rsp)
    8579:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    8583:      	movq	%rax, 0x18(%rsp)
    8588:      	movabsq	$0x6365732074786554, %rax # imm = 0x6365732074786554
    8592:      	movq	%rax, 0x10(%rsp)
    8597:      	leaq	0x10(%rsp), %rdi
    859c:      	movl	$0x2f, %eax
    85a1:      	movl	$0x6, %r8d
    85a7:      	movq	0xf18(%rbp), %rcx
    85ae:      	movq	0xf20(%rbp), %rdx
    85b5:      	movl	$0x2f, %esi
    85ba:      	xorl	%eax, %eax
    85bc:      	callq	*%r8
    85bf:      	jmp	0x85d9 <kprobe_unwind_php+0x85d9>
    85c1:      	cmpl	$0x0, (%r13)
    85c6:      	jne	0x887b <kprobe_unwind_php+0x887b>
    85cc:      	movl	$0xc, 0xf28(%rbp)
    85d6:      	xorl	%r12d, %r12d
    85d9:      	movq	0x70(%rsp), %rax
    85de:      	testq	%rax, %rax
    85e1:      	jne	0x85ef <kprobe_unwind_php+0x85ef>
    85e3:      	orb	$0x20, 0x1380(%rbp)
    85ea:      	movq	0x70(%rsp), %rax
    85ef:      	movq	%rax, (%r14)
    85f2:      	movl	$0x0, 0x10(%rsp)
    85fa:      	movq	(%rip), %rdi            # 0x8601 <kprobe_unwind_php+0x8601>
    8601:      	leaq	0x10(%rsp), %rsi
    8606:      	movl	$0x1, %eax
    860b:      	callq	*%rax
    860d:      	testq	%rax, %rax
    8610:      	je	0x8650 <kprobe_unwind_php+0x8650>
    8612:      	movzbl	0x1384(%rax), %ecx
    8619:      	cmpb	$0x1d, %cl
    861c:      	jb	0x867b <kprobe_unwind_php+0x867b>
    861e:      	movq	%rax, %r14
    8621:      	movl	$0x5, 0xf2c(%rax)
    862b:      	movl	$0x44, 0x58(%rsp)
    8633:      	movq	(%rip), %rdi            # 0x863a <kprobe_unwind_php+0x863a>
    863a:      	leaq	0x58(%rsp), %rsi
    863f:      	movl	$0x1, %eax
    8644:      	callq	*%rax
    8646:      	testq	%rax, %rax
    8649:      	je	0x8661 <kprobe_unwind_php+0x8661>
    864b:      	incq	(%rax)
    864e:      	jmp	0x866d <kprobe_unwind_php+0x866d>
    8650:      	movq	(%rip), %rcx            # 0x8657 <kprobe_unwind_php+0x8657>
    8657:      	xorl	%r12d, %r12d
    865a:      	movl	$0xc, %eax
    865f:      	jmp	0x8692 <kprobe_unwind_php+0x8692>
    8661:      	movq	(%rip), %rax            # 0x8668 <kprobe_unwind_php+0x8668>
    8668:      	cmpl	$0x0, (%rax)
    866b:      	jne	0x86b8 <kprobe_unwind_php+0x86b8>
    866d:      	movq	%r14, %rax
    8670:      	movzbl	0x1384(%r14), %ecx
    8678:      	xorl	%r12d, %r12d
    867b:      	incb	%cl
    867d:      	movb	%cl, 0x1384(%rax)
    8683:      	movl	%r12d, %ecx
    8686:      	movq	(%rip), %rdx            # 0x868d <kprobe_unwind_php+0x868d>
    868d:      	movl	$0xc, %eax
    8692:      	movq	(%rip), %rsi            # 0x8699 <kprobe_unwind_php+0x8699>
    8699:      	movq	%rbx, %rdi
    869c:      	movl	%r12d, %edx
    869f:      	callq	*%rax
    86a1:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
    86a6:      	addq	$0x88, %rsp
    86ad:      	popq	%rbx
    86ae:      	popq	%r12
    86b0:      	popq	%r13
    86b2:      	popq	%r14
    86b4:      	popq	%r15
    86b6:      	popq	%rbp
    86b7:      	retq
    86b8:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    86c2:      	movq	%rax, 0x36(%rsp)
    86c7:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    86d1:      	movq	%rax, 0x30(%rsp)
    86d6:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    86e0:      	movq	%rax, 0x28(%rsp)
    86e5:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    86ef:      	movq	%rax, 0x20(%rsp)
    86f4:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    86fe:      	movq	%rax, 0x18(%rsp)
    8703:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    870d:      	movq	%rax, 0x10(%rsp)
    8712:      	leaq	0x10(%rsp), %rdi
    8717:      	movl	$0x2e, %eax
    871c:      	movl	$0x6, %ecx
    8721:      	movl	0x58(%rsp), %edx
    8725:      	movl	$0x2e, %esi
    872a:      	xorl	%eax, %eax
    872c:      	callq	*%rcx
    872e:      	jmp	0x866d <kprobe_unwind_php+0x866d>
    8733:      	movabsq	$0x2578303d61746164, %rax # imm = 0x2578303D61746164
    873d:      	movq	%rax, 0x30(%rsp)
    8742:      	movabsq	$0x5f65747563657865, %rax # imm = 0x5F65747563657865
    874c:      	movq	%rax, 0x28(%rsp)
    8751:      	movabsq	$0x207478656e206874, %rax # imm = 0x207478656E206874
    875b:      	movq	%rax, 0x20(%rsp)
    8760:      	movabsq	$0x6977202c6b636174, %rax # imm = 0x6977202C6B636174
    876a:      	movq	%rax, 0x18(%rsp)
    876f:      	movabsq	$0x732d666f2d706f54, %rax # imm = 0x732D666F2D706F54
    8779:      	movq	%rax, 0x10(%rsp)
    877e:      	movl	$0xa786c, 0x38(%rsp)    # imm = 0xA786C
    8786:      	leaq	0x10(%rsp), %rdi
    878b:      	movl	$0x2c, %eax
    8790:      	movl	$0x6, %ecx
    8795:      	movq	0x70(%rsp), %rdx
    879a:      	movl	$0x2c, %esi
    879f:      	xorl	%eax, %eax
    87a1:      	callq	*%rcx
    87a3:      	movl	$0x1, %r12d
    87a9:      	cmpb	$0x0, 0x80(%rsp)
    87b1:      	jne	0x83e0 <kprobe_unwind_php+0x83e0>
    87b7:      	jmp	0x85d9 <kprobe_unwind_php+0x85d9>
    87bc:      	movabsq	$0x7373657264646120, %rax # imm = 0x7373657264646120
    87c6:      	movq	%rax, 0x28(%rsp)
    87cb:      	movabsq	$0x6c656e72656b2061, %rax # imm = 0x6C656E72656B2061
    87d5:      	movq	%rax, 0x20(%rsp)
    87da:      	movabsq	$0x20736920786c2520, %rax # imm = 0x20736920786C2520
    87e4:      	movq	%rax, 0x18(%rsp)
    87e9:      	movabsq	$0x65756c6176204350, %rax # imm = 0x65756C6176204350
    87f3:      	movq	%rax, 0x10(%rsp)
    87f8:      	movw	$0xa, 0x30(%rsp)
    87ff:      	leaq	0x10(%rsp), %rdi
    8804:      	movl	$0x22, %eax
    8809:      	movl	$0x6, %ecx
    880e:      	movl	$0x22, %esi
    8813:      	movq	%r15, %rdx
    8816:      	xorl	%eax, %eax
    8818:      	callq	*%rcx
    881a:      	jmp	0x8406 <kprobe_unwind_php+0x8406>
    881f:      	movabsq	$0xa676e69726f6e, %rax  # imm = 0xA676E69726F6E
    8829:      	movq	%rax, 0x26(%rsp)
    882e:      	movabsq	$0x6f6e6769202c786c, %rax # imm = 0x6F6E6769202C786C
    8838:      	movq	%rax, 0x20(%rsp)
    883d:      	movabsq	$0x252065756c617620, %rax # imm = 0x252065756C617620
    8847:      	movq	%rax, 0x18(%rsp)
    884c:      	movabsq	$0x6370206c6c616d73, %rax # imm = 0x6370206C6C616D73
    8856:      	movq	%rax, 0x10(%rsp)
    885b:      	leaq	0x10(%rsp), %rdi
    8860:      	movl	$0x1e, %eax
    8865:      	movl	$0x6, %ecx
    886a:      	movl	$0x1e, %esi
    886f:      	movq	%r15, %rdx
    8872:      	xorl	%eax, %eax
    8874:      	callq	*%rcx
    8876:      	jmp	0x8429 <kprobe_unwind_php+0x8429>
    887b:      	movabsq	$0xa786c2578302043, %rax # imm = 0xA786C2578302043
    8885:      	movq	%rax, 0x40(%rsp)
    888a:      	movabsq	$0x5020726f6620676e, %rax # imm = 0x5020726F6620676E
    8894:      	movq	%rax, 0x38(%rsp)
    8899:      	movabsq	$0x697070616d207972, %rax # imm = 0x697070616D207972
    88a3:      	movq	%rax, 0x30(%rsp)
    88a8:      	movabsq	$0x6f6d656d206c6176, %rax # imm = 0x6F6D656D206C6176
    88b2:      	movq	%rax, 0x28(%rsp)
    88b7:      	movabsq	$0x7265746e69207075, %rax # imm = 0x7265746E69207075
    88c1:      	movq	%rax, 0x20(%rsp)
    88c6:      	movabsq	$0x206b6f6f6c206f74, %rax # imm = 0x206B6F6F6C206F74
    88d0:      	movq	%rax, 0x18(%rsp)
    88d5:      	movabsq	$0x206572756c696146, %rax # imm = 0x206572756C696146
    88df:      	movq	%rax, 0x10(%rsp)
    88e4:      	movb	$0x0, 0x48(%rsp)
    88e9:      	leaq	0x10(%rsp), %rdi
    88ee:      	movl	$0x39, %eax
    88f3:      	movl	$0x6, %ecx
    88f8:      	movl	$0x39, %esi
    88fd:      	movq	%r15, %rdx
    8900:      	xorl	%eax, %eax
    8902:      	callq	*%rcx
    8904:      	jmp	0x85cc <kprobe_unwind_php+0x85cc>
