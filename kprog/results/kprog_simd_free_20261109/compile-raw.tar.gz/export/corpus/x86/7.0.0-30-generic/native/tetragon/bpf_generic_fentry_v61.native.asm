
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_generic_fentry_v61.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <extract_arg_depth>:
       0:      	movl	$0x1, %eax
       5:      	cmpl	$0x9, %edi
       8:      	ja	0x82 <extract_arg_depth+0x82>
       a:      	pushq	%r14
       c:      	pushq	%rbx
       d:      	pushq	%rax
       e:      	movq	(%rsi), %r8
      11:      	movl	%edi, %r9d
      14:      	cmpw	$0x0, 0x6(%r8,%r9,8)
      1b:      	je	0x7b <extract_arg_depth+0x7b>
      1d:      	movq	0x8(%rsi), %rcx
      21:      	movl	(%r8,%r9,8), %edx
      25:      	addq	(%rcx), %rdx
      28:      	movq	%rdx, (%rcx)
      2b:      	xorl	%eax, %eax
      2d:      	cmpw	$0x0, 0x4(%r8,%r9,8)
      34:      	je	0x7b <extract_arg_depth+0x7b>
      36:      	movl	%edi, %ebx
      38:      	cmpb	$0x0, 0x10(%rsi)
      3c:      	je	0x4a <extract_arg_depth+0x4a>
      3e:      	movl	$0x8, %edi
      43:      	movl	$0x94, %eax
      48:      	jmp	0x54 <extract_arg_depth+0x54>
      4a:      	movl	$0x8, %edi
      4f:      	movl	$0x4, %eax
      54:      	movq	%rsi, %r14
      57:      	movq	0x8(%rsi), %rdi
      5b:      	movq	(%rdi), %rdx
      5e:      	movl	$0x8, %esi
      63:      	callq	*%rax
      65:      	testl	%eax, %eax
      67:      	movl	$0x0, %eax
      6c:      	jns	0x7b <extract_arg_depth+0x7b>
      6e:      	incl	%ebx
      70:      	movq	0x18(%r14), %rax
      74:      	movl	%ebx, (%rax)
      76:      	movl	$0x1, %eax
      7b:      	addq	$0x8, %rsp
      7f:      	popq	%rbx
      80:      	popq	%r14
      82:      	retq
      83:      	nopw	%cs:(%rax,%rax)

0000000000000090 <do_bytes>:
      90:      	pushq	%rbp
      91:      	pushq	%r15
      93:      	pushq	%r14
      95:      	pushq	%r13
      97:      	pushq	%r12
      99:      	pushq	%rbx
      9a:      	pushq	%rax
      9b:      	movq	%rcx, %rbx
      9e:      	movq	%rdx, %r14
      a1:      	movq	%rsi, %r15
      a4:      	movq	%rdi, %r12
      a7:      	callq	0x2f0 <__do_bytes>
      ac:      	testl	%eax, %eax
      ae:      	js	0x257 <do_bytes+0x1c7>
      b4:      	movl	%eax, %r13d
      b7:      	andl	$0x7fffffff, %r13d      # imm = 0x7FFFFFFF
      be:      	movq	%rbx, %rcx
      c1:      	subq	%r13, %rcx
      c4:      	je	0x2de <do_bytes+0x24e>
      ca:      	leaq	(%r14,%r13), %rdx
      ce:      	movq	%r12, %rdi
      d1:      	movq	%r15, %rsi
      d4:      	callq	0x2f0 <__do_bytes>
      d9:      	testl	%eax, %eax
      db:      	js	0x257 <do_bytes+0x1c7>
      e1:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
      e6:      	movq	%rax, %rbp
      e9:      	addq	%r13, %rbp
      ec:      	movq	%rbx, %rcx
      ef:      	subq	%rbp, %rcx
      f2:      	je	0x2de <do_bytes+0x24e>
      f8:      	leaq	(%r14,%rbp), %rdx
      fc:      	movq	%r12, %rdi
      ff:      	movq	%r15, %rsi
     102:      	callq	0x2f0 <__do_bytes>
     107:      	testl	%eax, %eax
     109:      	js	0x257 <do_bytes+0x1c7>
     10f:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     114:      	movq	%rax, %r13
     117:      	addq	%rbp, %r13
     11a:      	movq	%rbx, %rcx
     11d:      	subq	%r13, %rcx
     120:      	je	0x2de <do_bytes+0x24e>
     126:      	leaq	(%r14,%r13), %rdx
     12a:      	movq	%r12, %rdi
     12d:      	movq	%r15, %rsi
     130:      	callq	0x2f0 <__do_bytes>
     135:      	testl	%eax, %eax
     137:      	js	0x257 <do_bytes+0x1c7>
     13d:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     142:      	movq	%rax, %rbp
     145:      	addq	%r13, %rbp
     148:      	movq	%rbx, %rcx
     14b:      	subq	%rbp, %rcx
     14e:      	je	0x2de <do_bytes+0x24e>
     154:      	leaq	(%r14,%rbp), %rdx
     158:      	movq	%r12, %rdi
     15b:      	movq	%r15, %rsi
     15e:      	callq	0x2f0 <__do_bytes>
     163:      	testl	%eax, %eax
     165:      	js	0x257 <do_bytes+0x1c7>
     16b:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     170:      	movq	%rax, %r13
     173:      	addq	%rbp, %r13
     176:      	movq	%rbx, %rcx
     179:      	subq	%r13, %rcx
     17c:      	je	0x2de <do_bytes+0x24e>
     182:      	leaq	(%r14,%r13), %rdx
     186:      	movq	%r12, %rdi
     189:      	movq	%r15, %rsi
     18c:      	callq	0x2f0 <__do_bytes>
     191:      	testl	%eax, %eax
     193:      	js	0x257 <do_bytes+0x1c7>
     199:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     19e:      	movq	%rax, %rbp
     1a1:      	addq	%r13, %rbp
     1a4:      	movq	%rbx, %rcx
     1a7:      	subq	%rbp, %rcx
     1aa:      	je	0x2de <do_bytes+0x24e>
     1b0:      	leaq	(%r14,%rbp), %rdx
     1b4:      	movq	%r12, %rdi
     1b7:      	movq	%r15, %rsi
     1ba:      	callq	0x2f0 <__do_bytes>
     1bf:      	testl	%eax, %eax
     1c1:      	js	0x257 <do_bytes+0x1c7>
     1c7:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     1cc:      	movq	%rax, %r13
     1cf:      	addq	%rbp, %r13
     1d2:      	movq	%rbx, %rcx
     1d5:      	subq	%r13, %rcx
     1d8:      	je	0x2de <do_bytes+0x24e>
     1de:      	leaq	(%r14,%r13), %rdx
     1e2:      	movq	%r12, %rdi
     1e5:      	movq	%r15, %rsi
     1e8:      	callq	0x2f0 <__do_bytes>
     1ed:      	testl	%eax, %eax
     1ef:      	js	0x257 <do_bytes+0x1c7>
     1f1:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     1f6:      	movq	%rax, %rbp
     1f9:      	addq	%r13, %rbp
     1fc:      	movq	%rbx, %rcx
     1ff:      	subq	%rbp, %rcx
     202:      	je	0x2de <do_bytes+0x24e>
     208:      	leaq	(%r14,%rbp), %rdx
     20c:      	movq	%r12, %rdi
     20f:      	movq	%r15, %rsi
     212:      	callq	0x2f0 <__do_bytes>
     217:      	testl	%eax, %eax
     219:      	js	0x257 <do_bytes+0x1c7>
     21b:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     220:      	movq	%rax, %r13
     223:      	addq	%rbp, %r13
     226:      	movq	%rbx, %rcx
     229:      	subq	%r13, %rcx
     22c:      	je	0x2de <do_bytes+0x24e>
     232:      	addq	%r13, %r14
     235:      	movq	%r12, %rdi
     238:      	movq	%r15, %rsi
     23b:      	movq	%r14, %rdx
     23e:      	callq	0x2f0 <__do_bytes>
     243:      	testl	%eax, %eax
     245:      	js	0x257 <do_bytes+0x1c7>
     247:      	andl	$0x7fffffff, %eax       # imm = 0x7FFFFFFF
     24c:      	addq	%r13, %rax
     24f:      	movq	%rax, %rbx
     252:      	jmp	0x2de <do_bytes+0x24e>
     257:      	movslq	%eax, %rbx
     25a:      	movl	$0x0, 0x4(%rsp)
     262:      	movq	(%rip), %rdi            # 0x269 <do_bytes+0x1d9>
     269:      	leaq	0x4(%rsp), %rsi
     26e:      	movl	$0x1, %eax
     273:      	callq	*%rax
     275:      	testq	%rax, %rax
     278:      	je	0x2de <do_bytes+0x24e>
     27a:      	cmpq	$-0xc, %rbx
     27e:      	jg	0x29a <do_bytes+0x20a>
     280:      	cmpq	$-0x1c, %rbx
     284:      	je	0x2b4 <do_bytes+0x224>
     286:      	cmpq	$-0x16, %rbx
     28a:      	je	0x2cc <do_bytes+0x23c>
     28c:      	cmpq	$-0x10, %rbx
     290:      	jne	0x2c4 <do_bytes+0x234>
     292:      	addq	$0x558, %rax            # imm = 0x558
     298:      	jmp	0x2da <do_bytes+0x24a>
     29a:      	cmpq	$-0xb, %rbx
     29e:      	je	0x2bc <do_bytes+0x22c>
     2a0:      	cmpq	$-0x7, %rbx
     2a4:      	je	0x2d4 <do_bytes+0x244>
     2a6:      	cmpq	$-0x2, %rbx
     2aa:      	jne	0x2c4 <do_bytes+0x234>
     2ac:      	addq	$0x548, %rax            # imm = 0x548
     2b2:      	jmp	0x2da <do_bytes+0x24a>
     2b4:      	addq	$0x568, %rax            # imm = 0x568
     2ba:      	jmp	0x2da <do_bytes+0x24a>
     2bc:      	addq	$0x570, %rax            # imm = 0x570
     2c2:      	jmp	0x2da <do_bytes+0x24a>
     2c4:      	addq	$0x540, %rax            # imm = 0x540
     2ca:      	jmp	0x2da <do_bytes+0x24a>
     2cc:      	addq	$0x560, %rax            # imm = 0x560
     2d2:      	jmp	0x2da <do_bytes+0x24a>
     2d4:      	addq	$0x550, %rax            # imm = 0x550
     2da:      	lock
     2db:      	incq	(%rax)
     2de:      	movq	%rbx, %rax
     2e1:      	addq	$0x8, %rsp
     2e5:      	popq	%rbx
     2e6:      	popq	%r12
     2e8:      	popq	%r13
     2ea:      	popq	%r14
     2ec:      	popq	%r15
     2ee:      	popq	%rbp
     2ef:      	retq

00000000000002f0 <__do_bytes>:
     2f0:      	pushq	%r15
     2f2:      	pushq	%r14
     2f4:      	pushq	%r12
     2f6:      	pushq	%rbx
     2f7:      	pushq	%rax
     2f8:      	testq	%rcx, %rcx
     2fb:      	js	0x379 <__do_bytes+0x89>
     2fd:      	movq	%rsi, %r14
     300:      	movq	%rdi, %r12
     303:      	cmpq	$0x7fe0, %rcx           # imm = 0x7FE0
     30a:      	movl	$0x7fe0, %ebx           # imm = 0x7FE0
     30f:      	cmovbq	%rcx, %rbx
     313:      	leaq	0x20(%rsi), %rdi
     317:      	movl	$0x4, %eax
     31c:      	movl	%ebx, %esi
     31e:      	callq	*%rax
     320:      	testl	%eax, %eax
     322:      	js	0x39e <__do_bytes+0xae>
     324:      	leal	0x20(%rbx), %r15d
     328:      	movl	%r15d, 0x4(%r14)
     32c:      	movl	$0x0, 0x4(%rsp)
     334:      	movq	(%rip), %rdi            # 0x33b <__do_bytes+0x4b>
     33b:      	leaq	0x4(%rsp), %rsi
     340:      	movl	$0x1, %eax
     345:      	callq	*%rax
     347:      	testq	%rax, %rax
     34a:      	je	0x382 <__do_bytes+0x92>
     34c:      	cmpb	$0x0, 0x28(%rax)
     350:      	je	0x382 <__do_bytes+0x92>
     352:      	movq	(%rip), %rsi            # 0x359 <__do_bytes+0x69>
     359:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     35e:      	movl	$0x19, %eax
     363:      	movq	%r12, %rdi
     366:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     36b:      	movq	%r14, %rcx
     36e:      	movq	%r15, %r8
     371:      	callq	*%rax
     373:      	testl	%eax, %eax
     375:      	js	0x39e <__do_bytes+0xae>
     377:      	jmp	0x3a1 <__do_bytes+0xb1>
     379:      	movq	$-0x1, %rbx
     380:      	jmp	0x3a1 <__do_bytes+0xb1>
     382:      	movq	(%rip), %rdi            # 0x389 <__do_bytes+0x99>
     389:      	xorl	%ecx, %ecx
     38b:      	movl	$0x82, %eax
     390:      	movq	%r14, %rsi
     393:      	movq	%r15, %rdx
     396:      	xorl	%ecx, %ecx
     398:      	callq	*%rax
     39a:      	testl	%eax, %eax
     39c:      	jns	0x3a1 <__do_bytes+0xb1>
     39e:      	movslq	%eax, %rbx
     3a1:      	movq	%rbx, %rax
     3a4:      	addq	$0x8, %rsp
     3a8:      	popq	%rbx
     3a9:      	popq	%r12
     3ab:      	popq	%r14
     3ad:      	popq	%r15
     3af:      	retq

00000000000003b0 <filter_64ty>:
     3b0:      	pushq	%rax
     3b1:      	movl	0x4(%rdi), %ecx
     3b4:      	xorl	%eax, %eax
     3b6:      	cmpq	$0x20, %rcx
     3ba:      	ja	0x3f5 <filter_64ty+0x45>
     3bc:      	movl	$0x101e, %edx           # imm = 0x101E
     3c1:      	btq	%rcx, %rdx
     3c5:      	jae	0x3ce <filter_64ty+0x1e>
     3c7:      	callq	0x4f0 <filter_64ty_selector_val>
     3cc:      	popq	%rcx
     3cd:      	retq
     3ce:      	movl	$0xc00, %edx            # imm = 0xC00
     3d3:      	btq	%rcx, %rdx
     3d7:      	jb	0x3f0 <filter_64ty+0x40>
     3d9:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     3e3:      	btq	%rcx, %rdx
     3e7:      	jae	0x3f5 <filter_64ty+0x45>
     3e9:      	callq	0x7b0 <filter_64ty_range>
     3ee:      	popq	%rcx
     3ef:      	retq
     3f0:      	callq	0x730 <filter_64ty_map>
     3f5:      	popq	%rcx
     3f6:      	retq
     3f7:      	nopw	(%rax,%rax)

0000000000000400 <filter_32ty>:
     400:      	pushq	%rax
     401:      	movl	0x4(%rdi), %ecx
     404:      	xorl	%eax, %eax
     406:      	cmpq	$0x20, %rcx
     40a:      	ja	0x445 <filter_32ty+0x45>
     40c:      	movl	$0x101e, %edx           # imm = 0x101E
     411:      	btq	%rcx, %rdx
     415:      	jae	0x41e <filter_32ty+0x1e>
     417:      	callq	0x990 <filter_32ty_selector_val>
     41c:      	popq	%rcx
     41d:      	retq
     41e:      	movl	$0xc00, %edx            # imm = 0xC00
     423:      	btq	%rcx, %rdx
     427:      	jb	0x440 <filter_32ty+0x40>
     429:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     433:      	btq	%rcx, %rdx
     437:      	jae	0x445 <filter_32ty+0x45>
     439:      	callq	0xc40 <filter_32ty_range>
     43e:      	popq	%rcx
     43f:      	retq
     440:      	callq	0xbb0 <filter_32ty_map>
     445:      	popq	%rcx
     446:      	retq
     447:      	nopw	(%rax,%rax)

0000000000000450 <filter_16ty>:
     450:      	pushq	%rax
     451:      	movl	0x4(%rdi), %ecx
     454:      	xorl	%eax, %eax
     456:      	cmpq	$0x20, %rcx
     45a:      	ja	0x495 <filter_16ty+0x45>
     45c:      	movl	$0x101e, %edx           # imm = 0x101E
     461:      	btq	%rcx, %rdx
     465:      	jae	0x46e <filter_16ty+0x1e>
     467:      	callq	0xe00 <filter_16ty_selector_val>
     46c:      	popq	%rcx
     46d:      	retq
     46e:      	movl	$0xc00, %edx            # imm = 0xC00
     473:      	btq	%rcx, %rdx
     477:      	jb	0x490 <filter_16ty+0x40>
     479:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     483:      	btq	%rcx, %rdx
     487:      	jae	0x495 <filter_16ty+0x45>
     489:      	callq	0x10b0 <filter_16ty_range>
     48e:      	popq	%rcx
     48f:      	retq
     490:      	callq	0x1020 <filter_16ty_map>
     495:      	popq	%rcx
     496:      	retq
     497:      	nopw	(%rax,%rax)

00000000000004a0 <filter_8ty>:
     4a0:      	pushq	%rax
     4a1:      	movl	0x4(%rdi), %ecx
     4a4:      	xorl	%eax, %eax
     4a6:      	cmpq	$0x20, %rcx
     4aa:      	ja	0x4e5 <filter_8ty+0x45>
     4ac:      	movl	$0x101e, %edx           # imm = 0x101E
     4b1:      	btq	%rcx, %rdx
     4b5:      	jae	0x4be <filter_8ty+0x1e>
     4b7:      	callq	0x1270 <filter_8ty_selector_val>
     4bc:      	popq	%rcx
     4bd:      	retq
     4be:      	movl	$0xc00, %edx            # imm = 0xC00
     4c3:      	btq	%rcx, %rdx
     4c7:      	jb	0x4e0 <filter_8ty+0x40>
     4c9:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     4d3:      	btq	%rcx, %rdx
     4d7:      	jae	0x4e5 <filter_8ty+0x45>
     4d9:      	callq	0x1520 <filter_8ty_range>
     4de:      	popq	%rcx
     4df:      	retq
     4e0:      	callq	0x1490 <filter_8ty_map>
     4e5:      	popq	%rcx
     4e6:      	retq
     4e7:      	nopw	(%rax,%rax)

00000000000004f0 <filter_64ty_selector_val>:
     4f0:      	movl	0x4(%rdi), %ecx
     4f3:      	movl	$0x1, %eax
     4f8:      	cmpq	$0x25, %rcx
     4fc:      	ja	0x574 <filter_64ty_selector_val+0x84>
     4fe:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     508:      	btq	%rcx, %rdx
     50c:      	jae	0x50f <filter_64ty_selector_val+0x1f>
     50e:      	retq
     50f:      	movl	$0x18, %edx
     514:      	btq	%rcx, %rdx
     518:      	jae	0x530 <filter_64ty_selector_val+0x40>
     51a:      	movq	(%rsi), %rdx
     51d:      	cmpq	0x10(%rdi), %rdx
     521:      	jne	0x652 <filter_64ty_selector_val+0x162>
     527:      	xorl	%eax, %eax
     529:      	cmpl	$0x3, %ecx
     52c:      	sete	%al
     52f:      	retq
     530:      	cmpq	$0xc, %rcx
     534:      	jne	0x574 <filter_64ty_selector_val+0x84>
     536:      	movq	(%rsi), %rcx
     539:      	testq	%rcx, 0x10(%rdi)
     53d:      	jne	0x50e <filter_64ty_selector_val+0x1e>
     53f:      	movl	0x8(%rdi), %edx
     542:      	cmpl	$0x11, %edx
     545:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     54b:      	testq	%rcx, 0x18(%rdi)
     54f:      	jne	0x50e <filter_64ty_selector_val+0x1e>
     551:      	cmpl	$0x19, %edx
     554:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     55a:      	testq	%rcx, 0x20(%rdi)
     55e:      	jne	0x50e <filter_64ty_selector_val+0x1e>
     560:      	cmpl	$0x21, %edx
     563:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     569:      	testq	%rcx, 0x28(%rdi)
     56d:      	jne	0x50e <filter_64ty_selector_val+0x1e>
     56f:      	jmp	0x71f <filter_64ty_selector_val+0x22f>
     574:      	cmpl	$0x1, %ecx
     577:      	je	0x5ea <filter_64ty_selector_val+0xfa>
     579:      	cmpl	$0x2, %ecx
     57c:      	jne	0x71f <filter_64ty_selector_val+0x22f>
     582:      	movl	0xc(%rdi), %ecx
     585:      	cmpl	$0xc, %ecx
     588:      	ja	0x6e2 <filter_64ty_selector_val+0x1f2>
     58e:      	movl	$0x1402, %edx           # imm = 0x1402
     593:      	btl	%ecx, %edx
     596:      	jae	0x6e2 <filter_64ty_selector_val+0x1f2>
     59c:      	movq	(%rsi), %rcx
     59f:      	cmpq	0x10(%rdi), %rcx
     5a3:      	jl	0x50e <filter_64ty_selector_val+0x1e>
     5a9:      	movl	0x8(%rdi), %edx
     5ac:      	cmpl	$0x11, %edx
     5af:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     5b5:      	cmpq	0x18(%rdi), %rcx
     5b9:      	jl	0x50e <filter_64ty_selector_val+0x1e>
     5bf:      	cmpl	$0x19, %edx
     5c2:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     5c8:      	cmpq	0x20(%rdi), %rcx
     5cc:      	jl	0x50e <filter_64ty_selector_val+0x1e>
     5d2:      	cmpl	$0x21, %edx
     5d5:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     5db:      	cmpq	0x28(%rdi), %rcx
     5df:      	jl	0x50e <filter_64ty_selector_val+0x1e>
     5e5:      	jmp	0x71f <filter_64ty_selector_val+0x22f>
     5ea:      	movl	0xc(%rdi), %ecx
     5ed:      	cmpl	$0xc, %ecx
     5f0:      	ja	0x6a3 <filter_64ty_selector_val+0x1b3>
     5f6:      	movl	$0x1402, %edx           # imm = 0x1402
     5fb:      	btl	%ecx, %edx
     5fe:      	jae	0x6a3 <filter_64ty_selector_val+0x1b3>
     604:      	movq	(%rsi), %rcx
     607:      	cmpq	0x10(%rdi), %rcx
     60b:      	jg	0x50e <filter_64ty_selector_val+0x1e>
     611:      	movl	0x8(%rdi), %edx
     614:      	cmpl	$0x11, %edx
     617:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     61d:      	cmpq	0x18(%rdi), %rcx
     621:      	jg	0x50e <filter_64ty_selector_val+0x1e>
     627:      	cmpl	$0x19, %edx
     62a:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     630:      	cmpq	0x20(%rdi), %rcx
     634:      	jg	0x50e <filter_64ty_selector_val+0x1e>
     63a:      	cmpl	$0x21, %edx
     63d:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     643:      	cmpq	0x28(%rdi), %rcx
     647:      	jg	0x50e <filter_64ty_selector_val+0x1e>
     64d:      	jmp	0x71f <filter_64ty_selector_val+0x22f>
     652:      	movl	0x8(%rdi), %esi
     655:      	cmpl	$0x11, %esi
     658:      	jb	0x682 <filter_64ty_selector_val+0x192>
     65a:      	cmpq	0x18(%rdi), %rdx
     65e:      	je	0x527 <filter_64ty_selector_val+0x37>
     664:      	cmpl	$0x19, %esi
     667:      	jb	0x682 <filter_64ty_selector_val+0x192>
     669:      	cmpq	0x20(%rdi), %rdx
     66d:      	je	0x527 <filter_64ty_selector_val+0x37>
     673:      	cmpl	$0x21, %esi
     676:      	jb	0x682 <filter_64ty_selector_val+0x192>
     678:      	cmpq	0x28(%rdi), %rdx
     67c:      	je	0x527 <filter_64ty_selector_val+0x37>
     682:      	cmpl	$0x25, %ecx
     685:      	ja	0x71f <filter_64ty_selector_val+0x22f>
     68b:      	movl	%ecx, %ecx
     68d:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     697:      	btq	%rcx, %rdx
     69b:      	jb	0x50e <filter_64ty_selector_val+0x1e>
     6a1:      	jmp	0x71f <filter_64ty_selector_val+0x22f>
     6a3:      	movq	(%rsi), %rcx
     6a6:      	cmpq	0x10(%rdi), %rcx
     6aa:      	ja	0x50e <filter_64ty_selector_val+0x1e>
     6b0:      	movl	0x8(%rdi), %edx
     6b3:      	cmpl	$0x11, %edx
     6b6:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     6b8:      	cmpq	0x18(%rdi), %rcx
     6bc:      	ja	0x50e <filter_64ty_selector_val+0x1e>
     6c2:      	cmpl	$0x19, %edx
     6c5:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     6c7:      	cmpq	0x20(%rdi), %rcx
     6cb:      	ja	0x50e <filter_64ty_selector_val+0x1e>
     6d1:      	cmpl	$0x21, %edx
     6d4:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     6d6:      	cmpq	0x28(%rdi), %rcx
     6da:      	ja	0x50e <filter_64ty_selector_val+0x1e>
     6e0:      	jmp	0x71f <filter_64ty_selector_val+0x22f>
     6e2:      	movq	(%rsi), %rcx
     6e5:      	cmpq	0x10(%rdi), %rcx
     6e9:      	jb	0x50e <filter_64ty_selector_val+0x1e>
     6ef:      	movl	0x8(%rdi), %edx
     6f2:      	cmpl	$0x11, %edx
     6f5:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     6f7:      	cmpq	0x18(%rdi), %rcx
     6fb:      	jb	0x50e <filter_64ty_selector_val+0x1e>
     701:      	cmpl	$0x19, %edx
     704:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     706:      	cmpq	0x20(%rdi), %rcx
     70a:      	jb	0x50e <filter_64ty_selector_val+0x1e>
     710:      	cmpl	$0x21, %edx
     713:      	jb	0x71f <filter_64ty_selector_val+0x22f>
     715:      	cmpq	0x28(%rdi), %rcx
     719:      	jb	0x50e <filter_64ty_selector_val+0x1e>
     71f:      	xorl	%eax, %eax
     721:      	retq
     722:      	nopw	%cs:(%rax,%rax)

0000000000000730 <filter_64ty_map>:
     730:      	pushq	%r14
     732:      	pushq	%rbx
     733:      	subq	$0x18, %rsp
     737:      	movq	%rsi, %r14
     73a:      	movq	%rdi, %rbx
     73d:      	movzbl	0x10(%rdi), %eax
     741:      	movl	%eax, 0xc(%rsp)
     745:      	movq	(%rip), %rdi            # 0x74c <filter_64ty_map+0x1c>
     74c:      	leaq	0xc(%rsp), %rsi
     751:      	movl	$0x1, %eax
     756:      	callq	*%rax
     758:      	testq	%rax, %rax
     75b:      	je	0x789 <filter_64ty_map+0x59>
     75d:      	movq	%rax, %rdi
     760:      	movq	(%r14), %rax
     763:      	movq	%rax, 0x10(%rsp)
     768:      	leaq	0x10(%rsp), %rsi
     76d:      	movl	$0x1, %eax
     772:      	callq	*%rax
     774:      	movl	0x4(%rbx), %ecx
     777:      	cmpl	$0xb, %ecx
     77a:      	je	0x793 <filter_64ty_map+0x63>
     77c:      	cmpl	$0xa, %ecx
     77f:      	jne	0x79b <filter_64ty_map+0x6b>
     781:      	testq	%rax, %rax
     784:      	setne	%al
     787:      	jmp	0x79d <filter_64ty_map+0x6d>
     789:      	xorl	%eax, %eax
     78b:      	addq	$0x18, %rsp
     78f:      	popq	%rbx
     790:      	popq	%r14
     792:      	retq
     793:      	testq	%rax, %rax
     796:      	sete	%al
     799:      	jmp	0x79d <filter_64ty_map+0x6d>
     79b:      	xorl	%eax, %eax
     79d:      	movzbl	%al, %eax
     7a0:      	addq	$0x18, %rsp
     7a4:      	popq	%rbx
     7a5:      	popq	%r14
     7a7:      	retq
     7a8:      	nopl	(%rax,%rax)

00000000000007b0 <filter_64ty_range>:
     7b0:      	movl	0x4(%rdi), %ecx
     7b3:      	movl	0xc(%rdi), %eax
     7b6:      	cmpl	$0xc, %eax
     7b9:      	ja	0x8b0 <filter_64ty_range+0x100>
     7bf:      	movl	$0x1402, %edx           # imm = 0x1402
     7c4:      	btl	%eax, %edx
     7c7:      	jae	0x8b0 <filter_64ty_range+0x100>
     7cd:      	movq	(%rsi), %rsi
     7d0:      	cmpl	$0x1f, %ecx
     7d3:      	jne	0x843 <filter_64ty_range+0x93>
     7d5:      	movl	$0x1, %eax
     7da:      	cmpq	%rsi, 0x10(%rdi)
     7de:      	jg	0x7ea <filter_64ty_range+0x3a>
     7e0:      	cmpq	0x18(%rdi), %rsi
     7e4:      	jle	0x8c9 <filter_64ty_range+0x119>
     7ea:      	movl	0x8(%rdi), %edx
     7ed:      	cmpl	$0x19, %edx
     7f0:      	jb	0x977 <filter_64ty_range+0x1c7>
     7f6:      	cmpq	%rsi, 0x20(%rdi)
     7fa:      	jg	0x806 <filter_64ty_range+0x56>
     7fc:      	cmpq	0x28(%rdi), %rsi
     800:      	jle	0x8c9 <filter_64ty_range+0x119>
     806:      	cmpl	$0x29, %edx
     809:      	jb	0x977 <filter_64ty_range+0x1c7>
     80f:      	cmpq	%rsi, 0x30(%rdi)
     813:      	jg	0x81f <filter_64ty_range+0x6f>
     815:      	cmpq	0x38(%rdi), %rsi
     819:      	jle	0x8c9 <filter_64ty_range+0x119>
     81f:      	cmpl	$0x39, %edx
     822:      	jb	0x977 <filter_64ty_range+0x1c7>
     828:      	xorl	%edx, %edx
     82a:      	cmpq	%rsi, 0x40(%rdi)
     82e:      	jg	0x979 <filter_64ty_range+0x1c9>
     834:      	cmpq	0x48(%rdi), %rsi
     838:      	jle	0x8c9 <filter_64ty_range+0x119>
     83e:      	jmp	0x979 <filter_64ty_range+0x1c9>
     843:      	movl	0x8(%rdi), %eax
     846:      	cmpq	%rsi, 0x10(%rdi)
     84a:      	setle	%r8b
     84e:      	cmpq	0x18(%rdi), %rsi
     852:      	setle	%dl
     855:      	andb	%r8b, %dl
     858:      	cmpl	$0x19, %eax
     85b:      	jb	0x979 <filter_64ty_range+0x1c9>
     861:      	cmpq	%rsi, 0x20(%rdi)
     865:      	setle	%r8b
     869:      	cmpq	0x28(%rdi), %rsi
     86d:      	setle	%r9b
     871:      	andb	%r8b, %r9b
     874:      	orb	%r9b, %dl
     877:      	cmpl	$0x29, %eax
     87a:      	jb	0x979 <filter_64ty_range+0x1c9>
     880:      	cmpq	%rsi, 0x30(%rdi)
     884:      	setle	%r8b
     888:      	cmpq	0x38(%rdi), %rsi
     88c:      	setle	%r9b
     890:      	andb	%r8b, %r9b
     893:      	orb	%r9b, %dl
     896:      	cmpl	$0x39, %eax
     899:      	jb	0x979 <filter_64ty_range+0x1c9>
     89f:      	cmpq	%rsi, 0x40(%rdi)
     8a3:      	setle	%al
     8a6:      	cmpq	0x48(%rdi), %rsi
     8aa:      	setle	%sil
     8ae:      	jmp	0x92d <filter_64ty_range+0x17d>
     8b0:      	movq	(%rsi), %rsi
     8b3:      	cmpl	$0x1f, %ecx
     8b6:      	jne	0x8ca <filter_64ty_range+0x11a>
     8b8:      	movl	$0x1, %eax
     8bd:      	cmpq	%rsi, 0x10(%rdi)
     8c1:      	ja	0x935 <filter_64ty_range+0x185>
     8c3:      	cmpq	0x18(%rdi), %rsi
     8c7:      	ja	0x935 <filter_64ty_range+0x185>
     8c9:      	retq
     8ca:      	movl	0x8(%rdi), %eax
     8cd:      	cmpq	%rsi, 0x10(%rdi)
     8d1:      	setbe	%r8b
     8d5:      	cmpq	0x18(%rdi), %rsi
     8d9:      	setbe	%dl
     8dc:      	andb	%r8b, %dl
     8df:      	cmpl	$0x19, %eax
     8e2:      	jb	0x979 <filter_64ty_range+0x1c9>
     8e8:      	cmpq	%rsi, 0x20(%rdi)
     8ec:      	setbe	%r8b
     8f0:      	cmpq	0x28(%rdi), %rsi
     8f4:      	setbe	%r9b
     8f8:      	andb	%r8b, %r9b
     8fb:      	orb	%r9b, %dl
     8fe:      	cmpl	$0x29, %eax
     901:      	jb	0x979 <filter_64ty_range+0x1c9>
     903:      	cmpq	%rsi, 0x30(%rdi)
     907:      	setbe	%r8b
     90b:      	cmpq	0x38(%rdi), %rsi
     90f:      	setbe	%r9b
     913:      	andb	%r8b, %r9b
     916:      	orb	%r9b, %dl
     919:      	cmpl	$0x39, %eax
     91c:      	jb	0x979 <filter_64ty_range+0x1c9>
     91e:      	cmpq	%rsi, 0x40(%rdi)
     922:      	setbe	%al
     925:      	cmpq	0x48(%rdi), %rsi
     929:      	setbe	%sil
     92d:      	andb	%al, %sil
     930:      	orb	%sil, %dl
     933:      	jmp	0x979 <filter_64ty_range+0x1c9>
     935:      	movl	0x8(%rdi), %edx
     938:      	cmpl	$0x19, %edx
     93b:      	jb	0x977 <filter_64ty_range+0x1c7>
     93d:      	cmpq	%rsi, 0x20(%rdi)
     941:      	ja	0x949 <filter_64ty_range+0x199>
     943:      	cmpq	0x28(%rdi), %rsi
     947:      	jbe	0x8c9 <filter_64ty_range+0x119>
     949:      	cmpl	$0x29, %edx
     94c:      	jb	0x977 <filter_64ty_range+0x1c7>
     94e:      	cmpq	%rsi, 0x30(%rdi)
     952:      	ja	0x95e <filter_64ty_range+0x1ae>
     954:      	cmpq	0x38(%rdi), %rsi
     958:      	jbe	0x8c9 <filter_64ty_range+0x119>
     95e:      	cmpl	$0x39, %edx
     961:      	jb	0x977 <filter_64ty_range+0x1c7>
     963:      	xorl	%edx, %edx
     965:      	cmpq	%rsi, 0x40(%rdi)
     969:      	ja	0x979 <filter_64ty_range+0x1c9>
     96b:      	cmpq	0x48(%rdi), %rsi
     96f:      	jbe	0x8c9 <filter_64ty_range+0x119>
     975:      	jmp	0x979 <filter_64ty_range+0x1c9>
     977:      	xorl	%edx, %edx
     979:      	cmpl	$0x20, %ecx
     97c:      	sete	%al
     97f:      	xorb	$0x1, %dl
     982:      	andb	%al, %dl
     984:      	movzbl	%dl, %eax
     987:      	retq
     988:      	nopl	(%rax,%rax)

0000000000000990 <filter_32ty_selector_val>:
     990:      	movl	0x4(%rdi), %ecx
     993:      	movl	$0x1, %eax
     998:      	cmpq	$0x25, %rcx
     99c:      	ja	0xa0d <filter_32ty_selector_val+0x7d>
     99e:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     9a8:      	btq	%rcx, %rdx
     9ac:      	jae	0x9af <filter_32ty_selector_val+0x1f>
     9ae:      	retq
     9af:      	movl	$0x18, %edx
     9b4:      	btq	%rcx, %rdx
     9b8:      	jae	0x9ce <filter_32ty_selector_val+0x3e>
     9ba:      	movl	(%rsi), %edx
     9bc:      	cmpl	0x10(%rdi), %edx
     9bf:      	jne	0xae1 <filter_32ty_selector_val+0x151>
     9c5:      	xorl	%eax, %eax
     9c7:      	cmpl	$0x3, %ecx
     9ca:      	sete	%al
     9cd:      	retq
     9ce:      	cmpq	$0xc, %rcx
     9d2:      	jne	0xa0d <filter_32ty_selector_val+0x7d>
     9d4:      	movl	(%rsi), %ecx
     9d6:      	testl	%ecx, 0x10(%rdi)
     9d9:      	jne	0x9ae <filter_32ty_selector_val+0x1e>
     9db:      	movl	0x8(%rdi), %edx
     9de:      	cmpl	$0xd, %edx
     9e1:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     9e7:      	testl	%ecx, 0x14(%rdi)
     9ea:      	jne	0x9ae <filter_32ty_selector_val+0x1e>
     9ec:      	cmpl	$0x11, %edx
     9ef:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     9f5:      	testl	%ecx, 0x18(%rdi)
     9f8:      	jne	0x9ae <filter_32ty_selector_val+0x1e>
     9fa:      	cmpl	$0x15, %edx
     9fd:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     a03:      	testl	%ecx, 0x1c(%rdi)
     a06:      	jne	0x9ae <filter_32ty_selector_val+0x1e>
     a08:      	jmp	0xba1 <filter_32ty_selector_val+0x211>
     a0d:      	cmpl	$0x1, %ecx
     a10:      	je	0xa7e <filter_32ty_selector_val+0xee>
     a12:      	cmpl	$0x2, %ecx
     a15:      	jne	0xba1 <filter_32ty_selector_val+0x211>
     a1b:      	movl	0xc(%rdi), %ecx
     a1e:      	cmpl	$0xc, %ecx
     a21:      	ja	0xb69 <filter_32ty_selector_val+0x1d9>
     a27:      	movl	$0x1402, %edx           # imm = 0x1402
     a2c:      	btl	%ecx, %edx
     a2f:      	jae	0xb69 <filter_32ty_selector_val+0x1d9>
     a35:      	movl	(%rsi), %ecx
     a37:      	cmpl	0x10(%rdi), %ecx
     a3a:      	jl	0x9ae <filter_32ty_selector_val+0x1e>
     a40:      	movl	0x8(%rdi), %edx
     a43:      	cmpl	$0xd, %edx
     a46:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     a4c:      	cmpl	0x14(%rdi), %ecx
     a4f:      	jl	0x9ae <filter_32ty_selector_val+0x1e>
     a55:      	cmpl	$0x11, %edx
     a58:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     a5e:      	cmpl	0x18(%rdi), %ecx
     a61:      	jl	0x9ae <filter_32ty_selector_val+0x1e>
     a67:      	cmpl	$0x15, %edx
     a6a:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     a70:      	cmpl	0x1c(%rdi), %ecx
     a73:      	jl	0x9ae <filter_32ty_selector_val+0x1e>
     a79:      	jmp	0xba1 <filter_32ty_selector_val+0x211>
     a7e:      	movl	0xc(%rdi), %ecx
     a81:      	cmpl	$0xc, %ecx
     a84:      	ja	0xb2f <filter_32ty_selector_val+0x19f>
     a8a:      	movl	$0x1402, %edx           # imm = 0x1402
     a8f:      	btl	%ecx, %edx
     a92:      	jae	0xb2f <filter_32ty_selector_val+0x19f>
     a98:      	movl	(%rsi), %ecx
     a9a:      	cmpl	0x10(%rdi), %ecx
     a9d:      	jg	0x9ae <filter_32ty_selector_val+0x1e>
     aa3:      	movl	0x8(%rdi), %edx
     aa6:      	cmpl	$0xd, %edx
     aa9:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     aaf:      	cmpl	0x14(%rdi), %ecx
     ab2:      	jg	0x9ae <filter_32ty_selector_val+0x1e>
     ab8:      	cmpl	$0x11, %edx
     abb:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     ac1:      	cmpl	0x18(%rdi), %ecx
     ac4:      	jg	0x9ae <filter_32ty_selector_val+0x1e>
     aca:      	cmpl	$0x15, %edx
     acd:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     ad3:      	cmpl	0x1c(%rdi), %ecx
     ad6:      	jg	0x9ae <filter_32ty_selector_val+0x1e>
     adc:      	jmp	0xba1 <filter_32ty_selector_val+0x211>
     ae1:      	movl	0x8(%rdi), %esi
     ae4:      	cmpl	$0xd, %esi
     ae7:      	jb	0xb0e <filter_32ty_selector_val+0x17e>
     ae9:      	cmpl	0x14(%rdi), %edx
     aec:      	je	0x9c5 <filter_32ty_selector_val+0x35>
     af2:      	cmpl	$0x11, %esi
     af5:      	jb	0xb0e <filter_32ty_selector_val+0x17e>
     af7:      	cmpl	0x18(%rdi), %edx
     afa:      	je	0x9c5 <filter_32ty_selector_val+0x35>
     b00:      	cmpl	$0x15, %esi
     b03:      	jb	0xb0e <filter_32ty_selector_val+0x17e>
     b05:      	cmpl	0x1c(%rdi), %edx
     b08:      	je	0x9c5 <filter_32ty_selector_val+0x35>
     b0e:      	cmpl	$0x25, %ecx
     b11:      	ja	0xba1 <filter_32ty_selector_val+0x211>
     b17:      	movl	%ecx, %ecx
     b19:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     b23:      	btq	%rcx, %rdx
     b27:      	jb	0x9ae <filter_32ty_selector_val+0x1e>
     b2d:      	jmp	0xba1 <filter_32ty_selector_val+0x211>
     b2f:      	movl	(%rsi), %ecx
     b31:      	cmpl	0x10(%rdi), %ecx
     b34:      	ja	0x9ae <filter_32ty_selector_val+0x1e>
     b3a:      	movl	0x8(%rdi), %edx
     b3d:      	cmpl	$0xd, %edx
     b40:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     b42:      	cmpl	0x14(%rdi), %ecx
     b45:      	ja	0x9ae <filter_32ty_selector_val+0x1e>
     b4b:      	cmpl	$0x11, %edx
     b4e:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     b50:      	cmpl	0x18(%rdi), %ecx
     b53:      	ja	0x9ae <filter_32ty_selector_val+0x1e>
     b59:      	cmpl	$0x15, %edx
     b5c:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     b5e:      	cmpl	0x1c(%rdi), %ecx
     b61:      	ja	0x9ae <filter_32ty_selector_val+0x1e>
     b67:      	jmp	0xba1 <filter_32ty_selector_val+0x211>
     b69:      	movl	(%rsi), %ecx
     b6b:      	cmpl	0x10(%rdi), %ecx
     b6e:      	jb	0x9ae <filter_32ty_selector_val+0x1e>
     b74:      	movl	0x8(%rdi), %edx
     b77:      	cmpl	$0xd, %edx
     b7a:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     b7c:      	cmpl	0x14(%rdi), %ecx
     b7f:      	jb	0x9ae <filter_32ty_selector_val+0x1e>
     b85:      	cmpl	$0x11, %edx
     b88:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     b8a:      	cmpl	0x18(%rdi), %ecx
     b8d:      	jb	0x9ae <filter_32ty_selector_val+0x1e>
     b93:      	cmpl	$0x15, %edx
     b96:      	jb	0xba1 <filter_32ty_selector_val+0x211>
     b98:      	cmpl	0x1c(%rdi), %ecx
     b9b:      	jb	0x9ae <filter_32ty_selector_val+0x1e>
     ba1:      	xorl	%eax, %eax
     ba3:      	retq
     ba4:      	nopw	%cs:(%rax,%rax)

0000000000000bb0 <filter_32ty_map>:
     bb0:      	pushq	%r14
     bb2:      	pushq	%rbx
     bb3:      	subq	$0x18, %rsp
     bb7:      	movq	%rsi, %r14
     bba:      	movq	%rdi, %rbx
     bbd:      	movzbl	0x10(%rdi), %eax
     bc1:      	movl	%eax, 0xc(%rsp)
     bc5:      	movq	(%rip), %rdi            # 0xbcc <filter_32ty_map+0x1c>
     bcc:      	leaq	0xc(%rsp), %rsi
     bd1:      	movl	$0x1, %eax
     bd6:      	callq	*%rax
     bd8:      	testq	%rax, %rax
     bdb:      	je	0xc10 <filter_32ty_map+0x60>
     bdd:      	movq	%rax, %rdi
     be0:      	movl	(%r14), %eax
     be3:      	movq	%rax, 0x10(%rsp)
     be8:      	leaq	0x10(%rsp), %rsi
     bed:      	movl	$0x1, %eax
     bf2:      	callq	*%rax
     bf4:      	movl	0x4(%rbx), %edx
     bf7:      	xorl	%ecx, %ecx
     bf9:      	cmpl	$0x1d, %edx
     bfc:      	ja	0xc2a <filter_32ty_map+0x7a>
     bfe:      	movl	$0x30038400, %esi       # imm = 0x30038400
     c03:      	btl	%edx, %esi
     c06:      	jae	0xc1a <filter_32ty_map+0x6a>
     c08:      	testq	%rax, %rax
     c0b:      	setne	%cl
     c0e:      	jmp	0xc2a <filter_32ty_map+0x7a>
     c10:      	xorl	%eax, %eax
     c12:      	addq	$0x18, %rsp
     c16:      	popq	%rbx
     c17:      	popq	%r14
     c19:      	retq
     c1a:      	movl	$0xc0800, %esi          # imm = 0xC0800
     c1f:      	btl	%edx, %esi
     c22:      	jae	0xc2a <filter_32ty_map+0x7a>
     c24:      	testq	%rax, %rax
     c27:      	sete	%cl
     c2a:      	movzbl	%cl, %eax
     c2d:      	addq	$0x18, %rsp
     c31:      	popq	%rbx
     c32:      	popq	%r14
     c34:      	retq
     c35:      	nopw	%cs:(%rax,%rax)

0000000000000c40 <filter_32ty_range>:
     c40:      	movl	0x4(%rdi), %ecx
     c43:      	movl	0xc(%rdi), %eax
     c46:      	cmpl	$0xc, %eax
     c49:      	ja	0xd2f <filter_32ty_range+0xef>
     c4f:      	movl	$0x1402, %edx           # imm = 0x1402
     c54:      	btl	%eax, %edx
     c57:      	jae	0xd2f <filter_32ty_range+0xef>
     c5d:      	movl	(%rsi), %esi
     c5f:      	cmpl	$0x1f, %ecx
     c62:      	jne	0xcca <filter_32ty_range+0x8a>
     c64:      	movl	$0x1, %eax
     c69:      	cmpl	%esi, 0x10(%rdi)
     c6c:      	jg	0xc77 <filter_32ty_range+0x37>
     c6e:      	cmpl	0x14(%rdi), %esi
     c71:      	jle	0xd45 <filter_32ty_range+0x105>
     c77:      	movl	0x8(%rdi), %edx
     c7a:      	cmpl	$0x11, %edx
     c7d:      	jb	0xde5 <filter_32ty_range+0x1a5>
     c83:      	cmpl	%esi, 0x18(%rdi)
     c86:      	jg	0xc91 <filter_32ty_range+0x51>
     c88:      	cmpl	0x1c(%rdi), %esi
     c8b:      	jle	0xd45 <filter_32ty_range+0x105>
     c91:      	cmpl	$0x19, %edx
     c94:      	jb	0xde5 <filter_32ty_range+0x1a5>
     c9a:      	cmpl	%esi, 0x20(%rdi)
     c9d:      	jg	0xca8 <filter_32ty_range+0x68>
     c9f:      	cmpl	0x24(%rdi), %esi
     ca2:      	jle	0xd45 <filter_32ty_range+0x105>
     ca8:      	cmpl	$0x21, %edx
     cab:      	jb	0xde5 <filter_32ty_range+0x1a5>
     cb1:      	xorl	%edx, %edx
     cb3:      	cmpl	%esi, 0x28(%rdi)
     cb6:      	jg	0xde7 <filter_32ty_range+0x1a7>
     cbc:      	cmpl	0x2c(%rdi), %esi
     cbf:      	jle	0xd45 <filter_32ty_range+0x105>
     cc5:      	jmp	0xde7 <filter_32ty_range+0x1a7>
     cca:      	movl	0x8(%rdi), %eax
     ccd:      	cmpl	%esi, 0x10(%rdi)
     cd0:      	setle	%r8b
     cd4:      	cmpl	0x14(%rdi), %esi
     cd7:      	setle	%dl
     cda:      	andb	%r8b, %dl
     cdd:      	cmpl	$0x11, %eax
     ce0:      	jb	0xde7 <filter_32ty_range+0x1a7>
     ce6:      	cmpl	%esi, 0x18(%rdi)
     ce9:      	setle	%r8b
     ced:      	cmpl	0x1c(%rdi), %esi
     cf0:      	setle	%r9b
     cf4:      	andb	%r8b, %r9b
     cf7:      	orb	%r9b, %dl
     cfa:      	cmpl	$0x19, %eax
     cfd:      	jb	0xde7 <filter_32ty_range+0x1a7>
     d03:      	cmpl	%esi, 0x20(%rdi)
     d06:      	setle	%r8b
     d0a:      	cmpl	0x24(%rdi), %esi
     d0d:      	setle	%r9b
     d11:      	andb	%r8b, %r9b
     d14:      	orb	%r9b, %dl
     d17:      	cmpl	$0x21, %eax
     d1a:      	jb	0xde7 <filter_32ty_range+0x1a7>
     d20:      	cmpl	%esi, 0x28(%rdi)
     d23:      	setle	%al
     d26:      	cmpl	0x2c(%rdi), %esi
     d29:      	setle	%sil
     d2d:      	jmp	0xda1 <filter_32ty_range+0x161>
     d2f:      	movl	(%rsi), %esi
     d31:      	cmpl	$0x1f, %ecx
     d34:      	jne	0xd46 <filter_32ty_range+0x106>
     d36:      	movl	$0x1, %eax
     d3b:      	cmpl	%esi, 0x10(%rdi)
     d3e:      	ja	0xda9 <filter_32ty_range+0x169>
     d40:      	cmpl	0x14(%rdi), %esi
     d43:      	ja	0xda9 <filter_32ty_range+0x169>
     d45:      	retq
     d46:      	movl	0x8(%rdi), %eax
     d49:      	cmpl	%esi, 0x10(%rdi)
     d4c:      	setbe	%r8b
     d50:      	cmpl	0x14(%rdi), %esi
     d53:      	setbe	%dl
     d56:      	andb	%r8b, %dl
     d59:      	cmpl	$0x11, %eax
     d5c:      	jb	0xde7 <filter_32ty_range+0x1a7>
     d62:      	cmpl	%esi, 0x18(%rdi)
     d65:      	setbe	%r8b
     d69:      	cmpl	0x1c(%rdi), %esi
     d6c:      	setbe	%r9b
     d70:      	andb	%r8b, %r9b
     d73:      	orb	%r9b, %dl
     d76:      	cmpl	$0x19, %eax
     d79:      	jb	0xde7 <filter_32ty_range+0x1a7>
     d7b:      	cmpl	%esi, 0x20(%rdi)
     d7e:      	setbe	%r8b
     d82:      	cmpl	0x24(%rdi), %esi
     d85:      	setbe	%r9b
     d89:      	andb	%r8b, %r9b
     d8c:      	orb	%r9b, %dl
     d8f:      	cmpl	$0x21, %eax
     d92:      	jb	0xde7 <filter_32ty_range+0x1a7>
     d94:      	cmpl	%esi, 0x28(%rdi)
     d97:      	setbe	%al
     d9a:      	cmpl	0x2c(%rdi), %esi
     d9d:      	setbe	%sil
     da1:      	andb	%al, %sil
     da4:      	orb	%sil, %dl
     da7:      	jmp	0xde7 <filter_32ty_range+0x1a7>
     da9:      	movl	0x8(%rdi), %edx
     dac:      	cmpl	$0x11, %edx
     daf:      	jb	0xde5 <filter_32ty_range+0x1a5>
     db1:      	cmpl	%esi, 0x18(%rdi)
     db4:      	ja	0xdbb <filter_32ty_range+0x17b>
     db6:      	cmpl	0x1c(%rdi), %esi
     db9:      	jbe	0xd45 <filter_32ty_range+0x105>
     dbb:      	cmpl	$0x19, %edx
     dbe:      	jb	0xde5 <filter_32ty_range+0x1a5>
     dc0:      	cmpl	%esi, 0x20(%rdi)
     dc3:      	ja	0xdce <filter_32ty_range+0x18e>
     dc5:      	cmpl	0x24(%rdi), %esi
     dc8:      	jbe	0xd45 <filter_32ty_range+0x105>
     dce:      	cmpl	$0x21, %edx
     dd1:      	jb	0xde5 <filter_32ty_range+0x1a5>
     dd3:      	xorl	%edx, %edx
     dd5:      	cmpl	%esi, 0x28(%rdi)
     dd8:      	ja	0xde7 <filter_32ty_range+0x1a7>
     dda:      	cmpl	0x2c(%rdi), %esi
     ddd:      	jbe	0xd45 <filter_32ty_range+0x105>
     de3:      	jmp	0xde7 <filter_32ty_range+0x1a7>
     de5:      	xorl	%edx, %edx
     de7:      	cmpl	$0x20, %ecx
     dea:      	sete	%al
     ded:      	xorb	$0x1, %dl
     df0:      	andb	%al, %dl
     df2:      	movzbl	%dl, %eax
     df5:      	retq
     df6:      	nopw	%cs:(%rax,%rax)

0000000000000e00 <filter_16ty_selector_val>:
     e00:      	movl	0x4(%rdi), %ecx
     e03:      	movl	$0x1, %eax
     e08:      	cmpq	$0x25, %rcx
     e0c:      	ja	0xe7f <filter_16ty_selector_val+0x7f>
     e0e:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     e18:      	btq	%rcx, %rdx
     e1c:      	jae	0xe1f <filter_16ty_selector_val+0x1f>
     e1e:      	retq
     e1f:      	movl	$0x18, %edx
     e24:      	btq	%rcx, %rdx
     e28:      	jae	0xe3f <filter_16ty_selector_val+0x3f>
     e2a:      	movzwl	(%rsi), %edx
     e2d:      	cmpl	%edx, 0x10(%rdi)
     e30:      	jne	0xf55 <filter_16ty_selector_val+0x155>
     e36:      	xorl	%eax, %eax
     e38:      	cmpl	$0x3, %ecx
     e3b:      	sete	%al
     e3e:      	retq
     e3f:      	cmpq	$0xc, %rcx
     e43:      	jne	0xe7f <filter_16ty_selector_val+0x7f>
     e45:      	movzwl	(%rsi), %ecx
     e48:      	testl	%ecx, 0x10(%rdi)
     e4b:      	jne	0xe1e <filter_16ty_selector_val+0x1e>
     e4d:      	movl	0x8(%rdi), %edx
     e50:      	cmpl	$0xd, %edx
     e53:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     e59:      	testl	%ecx, 0x14(%rdi)
     e5c:      	jne	0xe1e <filter_16ty_selector_val+0x1e>
     e5e:      	cmpl	$0x11, %edx
     e61:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     e67:      	testl	%ecx, 0x18(%rdi)
     e6a:      	jne	0xe1e <filter_16ty_selector_val+0x1e>
     e6c:      	cmpl	$0x15, %edx
     e6f:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     e75:      	testl	%ecx, 0x1c(%rdi)
     e78:      	jne	0xe1e <filter_16ty_selector_val+0x1e>
     e7a:      	jmp	0x1017 <filter_16ty_selector_val+0x217>
     e7f:      	cmpl	$0x1, %ecx
     e82:      	je	0xef1 <filter_16ty_selector_val+0xf1>
     e84:      	cmpl	$0x2, %ecx
     e87:      	jne	0x1017 <filter_16ty_selector_val+0x217>
     e8d:      	movl	0xc(%rdi), %ecx
     e90:      	cmpl	$0xc, %ecx
     e93:      	ja	0xfde <filter_16ty_selector_val+0x1de>
     e99:      	movl	$0x1402, %edx           # imm = 0x1402
     e9e:      	btl	%ecx, %edx
     ea1:      	jae	0xfde <filter_16ty_selector_val+0x1de>
     ea7:      	movswl	(%rsi), %ecx
     eaa:      	cmpl	%ecx, 0x10(%rdi)
     ead:      	jg	0xe1e <filter_16ty_selector_val+0x1e>
     eb3:      	movl	0x8(%rdi), %edx
     eb6:      	cmpl	$0xd, %edx
     eb9:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     ebf:      	cmpl	%ecx, 0x14(%rdi)
     ec2:      	jg	0xe1e <filter_16ty_selector_val+0x1e>
     ec8:      	cmpl	$0x11, %edx
     ecb:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     ed1:      	cmpl	%ecx, 0x18(%rdi)
     ed4:      	jg	0xe1e <filter_16ty_selector_val+0x1e>
     eda:      	cmpl	$0x15, %edx
     edd:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     ee3:      	cmpl	%ecx, 0x1c(%rdi)
     ee6:      	jg	0xe1e <filter_16ty_selector_val+0x1e>
     eec:      	jmp	0x1017 <filter_16ty_selector_val+0x217>
     ef1:      	movl	0xc(%rdi), %ecx
     ef4:      	cmpl	$0xc, %ecx
     ef7:      	ja	0xfa3 <filter_16ty_selector_val+0x1a3>
     efd:      	movl	$0x1402, %edx           # imm = 0x1402
     f02:      	btl	%ecx, %edx
     f05:      	jae	0xfa3 <filter_16ty_selector_val+0x1a3>
     f0b:      	movswl	(%rsi), %ecx
     f0e:      	cmpl	%ecx, 0x10(%rdi)
     f11:      	jl	0xe1e <filter_16ty_selector_val+0x1e>
     f17:      	movl	0x8(%rdi), %edx
     f1a:      	cmpl	$0xd, %edx
     f1d:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     f23:      	cmpl	%ecx, 0x14(%rdi)
     f26:      	jl	0xe1e <filter_16ty_selector_val+0x1e>
     f2c:      	cmpl	$0x11, %edx
     f2f:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     f35:      	cmpl	%ecx, 0x18(%rdi)
     f38:      	jl	0xe1e <filter_16ty_selector_val+0x1e>
     f3e:      	cmpl	$0x15, %edx
     f41:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     f47:      	cmpl	%ecx, 0x1c(%rdi)
     f4a:      	jl	0xe1e <filter_16ty_selector_val+0x1e>
     f50:      	jmp	0x1017 <filter_16ty_selector_val+0x217>
     f55:      	movl	0x8(%rdi), %esi
     f58:      	cmpl	$0xd, %esi
     f5b:      	jb	0xf82 <filter_16ty_selector_val+0x182>
     f5d:      	cmpl	%edx, 0x14(%rdi)
     f60:      	je	0xe36 <filter_16ty_selector_val+0x36>
     f66:      	cmpl	$0x11, %esi
     f69:      	jb	0xf82 <filter_16ty_selector_val+0x182>
     f6b:      	cmpl	%edx, 0x18(%rdi)
     f6e:      	je	0xe36 <filter_16ty_selector_val+0x36>
     f74:      	cmpl	$0x15, %esi
     f77:      	jb	0xf82 <filter_16ty_selector_val+0x182>
     f79:      	cmpl	%edx, 0x1c(%rdi)
     f7c:      	je	0xe36 <filter_16ty_selector_val+0x36>
     f82:      	cmpl	$0x25, %ecx
     f85:      	ja	0x1017 <filter_16ty_selector_val+0x217>
     f8b:      	movl	%ecx, %ecx
     f8d:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     f97:      	btq	%rcx, %rdx
     f9b:      	jb	0xe1e <filter_16ty_selector_val+0x1e>
     fa1:      	jmp	0x1017 <filter_16ty_selector_val+0x217>
     fa3:      	movzwl	(%rsi), %ecx
     fa6:      	cmpl	%ecx, 0x10(%rdi)
     fa9:      	jb	0xe1e <filter_16ty_selector_val+0x1e>
     faf:      	movl	0x8(%rdi), %edx
     fb2:      	cmpl	$0xd, %edx
     fb5:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     fb7:      	cmpl	%ecx, 0x14(%rdi)
     fba:      	jb	0xe1e <filter_16ty_selector_val+0x1e>
     fc0:      	cmpl	$0x11, %edx
     fc3:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     fc5:      	cmpl	%ecx, 0x18(%rdi)
     fc8:      	jb	0xe1e <filter_16ty_selector_val+0x1e>
     fce:      	cmpl	$0x15, %edx
     fd1:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     fd3:      	cmpl	%ecx, 0x1c(%rdi)
     fd6:      	jb	0xe1e <filter_16ty_selector_val+0x1e>
     fdc:      	jmp	0x1017 <filter_16ty_selector_val+0x217>
     fde:      	movzwl	(%rsi), %ecx
     fe1:      	cmpl	%ecx, 0x10(%rdi)
     fe4:      	ja	0xe1e <filter_16ty_selector_val+0x1e>
     fea:      	movl	0x8(%rdi), %edx
     fed:      	cmpl	$0xd, %edx
     ff0:      	jb	0x1017 <filter_16ty_selector_val+0x217>
     ff2:      	cmpl	%ecx, 0x14(%rdi)
     ff5:      	ja	0xe1e <filter_16ty_selector_val+0x1e>
     ffb:      	cmpl	$0x11, %edx
     ffe:      	jb	0x1017 <filter_16ty_selector_val+0x217>
    1000:      	cmpl	%ecx, 0x18(%rdi)
    1003:      	ja	0xe1e <filter_16ty_selector_val+0x1e>
    1009:      	cmpl	$0x15, %edx
    100c:      	jb	0x1017 <filter_16ty_selector_val+0x217>
    100e:      	cmpl	%ecx, 0x1c(%rdi)
    1011:      	ja	0xe1e <filter_16ty_selector_val+0x1e>
    1017:      	xorl	%eax, %eax
    1019:      	retq
    101a:      	nopw	(%rax,%rax)

0000000000001020 <filter_16ty_map>:
    1020:      	pushq	%r14
    1022:      	pushq	%rbx
    1023:      	subq	$0x18, %rsp
    1027:      	movq	%rsi, %r14
    102a:      	movq	%rdi, %rbx
    102d:      	movzbl	0x10(%rdi), %eax
    1031:      	movl	%eax, 0xc(%rsp)
    1035:      	movq	(%rip), %rdi            # 0x103c <filter_16ty_map+0x1c>
    103c:      	leaq	0xc(%rsp), %rsi
    1041:      	movl	$0x1, %eax
    1046:      	callq	*%rax
    1048:      	testq	%rax, %rax
    104b:      	je	0x1081 <filter_16ty_map+0x61>
    104d:      	movq	%rax, %rdi
    1050:      	movzwl	(%r14), %eax
    1054:      	movq	%rax, 0x10(%rsp)
    1059:      	leaq	0x10(%rsp), %rsi
    105e:      	movl	$0x1, %eax
    1063:      	callq	*%rax
    1065:      	movl	0x4(%rbx), %edx
    1068:      	xorl	%ecx, %ecx
    106a:      	cmpl	$0x1d, %edx
    106d:      	ja	0x109b <filter_16ty_map+0x7b>
    106f:      	movl	$0x30038400, %esi       # imm = 0x30038400
    1074:      	btl	%edx, %esi
    1077:      	jae	0x108b <filter_16ty_map+0x6b>
    1079:      	testq	%rax, %rax
    107c:      	setne	%cl
    107f:      	jmp	0x109b <filter_16ty_map+0x7b>
    1081:      	xorl	%eax, %eax
    1083:      	addq	$0x18, %rsp
    1087:      	popq	%rbx
    1088:      	popq	%r14
    108a:      	retq
    108b:      	movl	$0xc0800, %esi          # imm = 0xC0800
    1090:      	btl	%edx, %esi
    1093:      	jae	0x109b <filter_16ty_map+0x7b>
    1095:      	testq	%rax, %rax
    1098:      	sete	%cl
    109b:      	movzbl	%cl, %eax
    109e:      	addq	$0x18, %rsp
    10a2:      	popq	%rbx
    10a3:      	popq	%r14
    10a5:      	retq
    10a6:      	nopw	%cs:(%rax,%rax)

00000000000010b0 <filter_16ty_range>:
    10b0:      	movl	0x4(%rdi), %ecx
    10b3:      	movl	0xc(%rdi), %eax
    10b6:      	cmpl	$0xc, %eax
    10b9:      	ja	0x11a0 <filter_16ty_range+0xf0>
    10bf:      	movl	$0x1402, %edx           # imm = 0x1402
    10c4:      	btl	%eax, %edx
    10c7:      	jae	0x11a0 <filter_16ty_range+0xf0>
    10cd:      	movswl	(%rsi), %esi
    10d0:      	cmpl	$0x1f, %ecx
    10d3:      	jne	0x113b <filter_16ty_range+0x8b>
    10d5:      	movl	$0x1, %eax
    10da:      	cmpl	%esi, 0x10(%rdi)
    10dd:      	jg	0x10e8 <filter_16ty_range+0x38>
    10df:      	cmpl	%esi, 0x14(%rdi)
    10e2:      	jge	0x11b7 <filter_16ty_range+0x107>
    10e8:      	movl	0x8(%rdi), %edx
    10eb:      	cmpl	$0x11, %edx
    10ee:      	jb	0x1257 <filter_16ty_range+0x1a7>
    10f4:      	cmpl	%esi, 0x18(%rdi)
    10f7:      	jg	0x1102 <filter_16ty_range+0x52>
    10f9:      	cmpl	%esi, 0x1c(%rdi)
    10fc:      	jge	0x11b7 <filter_16ty_range+0x107>
    1102:      	cmpl	$0x19, %edx
    1105:      	jb	0x1257 <filter_16ty_range+0x1a7>
    110b:      	cmpl	%esi, 0x20(%rdi)
    110e:      	jg	0x1119 <filter_16ty_range+0x69>
    1110:      	cmpl	%esi, 0x24(%rdi)
    1113:      	jge	0x11b7 <filter_16ty_range+0x107>
    1119:      	cmpl	$0x21, %edx
    111c:      	jb	0x1257 <filter_16ty_range+0x1a7>
    1122:      	xorl	%edx, %edx
    1124:      	cmpl	%esi, 0x28(%rdi)
    1127:      	jg	0x1259 <filter_16ty_range+0x1a9>
    112d:      	cmpl	%esi, 0x2c(%rdi)
    1130:      	jge	0x11b7 <filter_16ty_range+0x107>
    1136:      	jmp	0x1259 <filter_16ty_range+0x1a9>
    113b:      	movl	0x8(%rdi), %eax
    113e:      	cmpl	%esi, 0x10(%rdi)
    1141:      	setle	%r8b
    1145:      	cmpl	%esi, 0x14(%rdi)
    1148:      	setge	%dl
    114b:      	andb	%r8b, %dl
    114e:      	cmpl	$0x11, %eax
    1151:      	jb	0x1259 <filter_16ty_range+0x1a9>
    1157:      	cmpl	%esi, 0x18(%rdi)
    115a:      	setle	%r8b
    115e:      	cmpl	%esi, 0x1c(%rdi)
    1161:      	setge	%r9b
    1165:      	andb	%r8b, %r9b
    1168:      	orb	%r9b, %dl
    116b:      	cmpl	$0x19, %eax
    116e:      	jb	0x1259 <filter_16ty_range+0x1a9>
    1174:      	cmpl	%esi, 0x20(%rdi)
    1177:      	setle	%r8b
    117b:      	cmpl	%esi, 0x24(%rdi)
    117e:      	setge	%r9b
    1182:      	andb	%r8b, %r9b
    1185:      	orb	%r9b, %dl
    1188:      	cmpl	$0x21, %eax
    118b:      	jb	0x1259 <filter_16ty_range+0x1a9>
    1191:      	cmpl	%esi, 0x28(%rdi)
    1194:      	setle	%al
    1197:      	cmpl	%esi, 0x2c(%rdi)
    119a:      	setge	%sil
    119e:      	jmp	0x1213 <filter_16ty_range+0x163>
    11a0:      	movzwl	(%rsi), %esi
    11a3:      	cmpl	$0x1f, %ecx
    11a6:      	jne	0x11b8 <filter_16ty_range+0x108>
    11a8:      	movl	$0x1, %eax
    11ad:      	cmpl	%esi, 0x10(%rdi)
    11b0:      	ja	0x121b <filter_16ty_range+0x16b>
    11b2:      	cmpl	%esi, 0x14(%rdi)
    11b5:      	jb	0x121b <filter_16ty_range+0x16b>
    11b7:      	retq
    11b8:      	movl	0x8(%rdi), %eax
    11bb:      	cmpl	%esi, 0x10(%rdi)
    11be:      	setbe	%r8b
    11c2:      	cmpl	%esi, 0x14(%rdi)
    11c5:      	setae	%dl
    11c8:      	andb	%r8b, %dl
    11cb:      	cmpl	$0x11, %eax
    11ce:      	jb	0x1259 <filter_16ty_range+0x1a9>
    11d4:      	cmpl	%esi, 0x18(%rdi)
    11d7:      	setbe	%r8b
    11db:      	cmpl	%esi, 0x1c(%rdi)
    11de:      	setae	%r9b
    11e2:      	andb	%r8b, %r9b
    11e5:      	orb	%r9b, %dl
    11e8:      	cmpl	$0x19, %eax
    11eb:      	jb	0x1259 <filter_16ty_range+0x1a9>
    11ed:      	cmpl	%esi, 0x20(%rdi)
    11f0:      	setbe	%r8b
    11f4:      	cmpl	%esi, 0x24(%rdi)
    11f7:      	setae	%r9b
    11fb:      	andb	%r8b, %r9b
    11fe:      	orb	%r9b, %dl
    1201:      	cmpl	$0x21, %eax
    1204:      	jb	0x1259 <filter_16ty_range+0x1a9>
    1206:      	cmpl	%esi, 0x28(%rdi)
    1209:      	setbe	%al
    120c:      	cmpl	%esi, 0x2c(%rdi)
    120f:      	setae	%sil
    1213:      	andb	%al, %sil
    1216:      	orb	%sil, %dl
    1219:      	jmp	0x1259 <filter_16ty_range+0x1a9>
    121b:      	movl	0x8(%rdi), %edx
    121e:      	cmpl	$0x11, %edx
    1221:      	jb	0x1257 <filter_16ty_range+0x1a7>
    1223:      	cmpl	%esi, 0x18(%rdi)
    1226:      	ja	0x122d <filter_16ty_range+0x17d>
    1228:      	cmpl	%esi, 0x1c(%rdi)
    122b:      	jae	0x11b7 <filter_16ty_range+0x107>
    122d:      	cmpl	$0x19, %edx
    1230:      	jb	0x1257 <filter_16ty_range+0x1a7>
    1232:      	cmpl	%esi, 0x20(%rdi)
    1235:      	ja	0x1240 <filter_16ty_range+0x190>
    1237:      	cmpl	%esi, 0x24(%rdi)
    123a:      	jae	0x11b7 <filter_16ty_range+0x107>
    1240:      	cmpl	$0x21, %edx
    1243:      	jb	0x1257 <filter_16ty_range+0x1a7>
    1245:      	xorl	%edx, %edx
    1247:      	cmpl	%esi, 0x28(%rdi)
    124a:      	ja	0x1259 <filter_16ty_range+0x1a9>
    124c:      	cmpl	%esi, 0x2c(%rdi)
    124f:      	jae	0x11b7 <filter_16ty_range+0x107>
    1255:      	jmp	0x1259 <filter_16ty_range+0x1a9>
    1257:      	xorl	%edx, %edx
    1259:      	cmpl	$0x20, %ecx
    125c:      	sete	%al
    125f:      	xorb	$0x1, %dl
    1262:      	andb	%al, %dl
    1264:      	movzbl	%dl, %eax
    1267:      	retq
    1268:      	nopl	(%rax,%rax)

0000000000001270 <filter_8ty_selector_val>:
    1270:      	movl	0x4(%rdi), %ecx
    1273:      	movl	$0x1, %eax
    1278:      	cmpq	$0x25, %rcx
    127c:      	ja	0x12ef <filter_8ty_selector_val+0x7f>
    127e:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
    1288:      	btq	%rcx, %rdx
    128c:      	jae	0x128f <filter_8ty_selector_val+0x1f>
    128e:      	retq
    128f:      	movl	$0x18, %edx
    1294:      	btq	%rcx, %rdx
    1298:      	jae	0x12af <filter_8ty_selector_val+0x3f>
    129a:      	movzbl	(%rsi), %edx
    129d:      	cmpl	%edx, 0x10(%rdi)
    12a0:      	jne	0x13c5 <filter_8ty_selector_val+0x155>
    12a6:      	xorl	%eax, %eax
    12a8:      	cmpl	$0x3, %ecx
    12ab:      	sete	%al
    12ae:      	retq
    12af:      	cmpq	$0xc, %rcx
    12b3:      	jne	0x12ef <filter_8ty_selector_val+0x7f>
    12b5:      	movzbl	(%rsi), %ecx
    12b8:      	testl	%ecx, 0x10(%rdi)
    12bb:      	jne	0x128e <filter_8ty_selector_val+0x1e>
    12bd:      	movl	0x8(%rdi), %edx
    12c0:      	cmpl	$0xd, %edx
    12c3:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    12c9:      	testl	%ecx, 0x14(%rdi)
    12cc:      	jne	0x128e <filter_8ty_selector_val+0x1e>
    12ce:      	cmpl	$0x11, %edx
    12d1:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    12d7:      	testl	%ecx, 0x18(%rdi)
    12da:      	jne	0x128e <filter_8ty_selector_val+0x1e>
    12dc:      	cmpl	$0x15, %edx
    12df:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    12e5:      	testl	%ecx, 0x1c(%rdi)
    12e8:      	jne	0x128e <filter_8ty_selector_val+0x1e>
    12ea:      	jmp	0x1487 <filter_8ty_selector_val+0x217>
    12ef:      	cmpl	$0x1, %ecx
    12f2:      	je	0x1361 <filter_8ty_selector_val+0xf1>
    12f4:      	cmpl	$0x2, %ecx
    12f7:      	jne	0x1487 <filter_8ty_selector_val+0x217>
    12fd:      	movl	0xc(%rdi), %ecx
    1300:      	cmpl	$0xc, %ecx
    1303:      	ja	0x144e <filter_8ty_selector_val+0x1de>
    1309:      	movl	$0x1402, %edx           # imm = 0x1402
    130e:      	btl	%ecx, %edx
    1311:      	jae	0x144e <filter_8ty_selector_val+0x1de>
    1317:      	movsbl	(%rsi), %ecx
    131a:      	cmpl	%ecx, 0x10(%rdi)
    131d:      	jg	0x128e <filter_8ty_selector_val+0x1e>
    1323:      	movl	0x8(%rdi), %edx
    1326:      	cmpl	$0xd, %edx
    1329:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    132f:      	cmpl	%ecx, 0x14(%rdi)
    1332:      	jg	0x128e <filter_8ty_selector_val+0x1e>
    1338:      	cmpl	$0x11, %edx
    133b:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    1341:      	cmpl	%ecx, 0x18(%rdi)
    1344:      	jg	0x128e <filter_8ty_selector_val+0x1e>
    134a:      	cmpl	$0x15, %edx
    134d:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    1353:      	cmpl	%ecx, 0x1c(%rdi)
    1356:      	jg	0x128e <filter_8ty_selector_val+0x1e>
    135c:      	jmp	0x1487 <filter_8ty_selector_val+0x217>
    1361:      	movl	0xc(%rdi), %ecx
    1364:      	cmpl	$0xc, %ecx
    1367:      	ja	0x1413 <filter_8ty_selector_val+0x1a3>
    136d:      	movl	$0x1402, %edx           # imm = 0x1402
    1372:      	btl	%ecx, %edx
    1375:      	jae	0x1413 <filter_8ty_selector_val+0x1a3>
    137b:      	movsbl	(%rsi), %ecx
    137e:      	cmpl	%ecx, 0x10(%rdi)
    1381:      	jl	0x128e <filter_8ty_selector_val+0x1e>
    1387:      	movl	0x8(%rdi), %edx
    138a:      	cmpl	$0xd, %edx
    138d:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    1393:      	cmpl	%ecx, 0x14(%rdi)
    1396:      	jl	0x128e <filter_8ty_selector_val+0x1e>
    139c:      	cmpl	$0x11, %edx
    139f:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    13a5:      	cmpl	%ecx, 0x18(%rdi)
    13a8:      	jl	0x128e <filter_8ty_selector_val+0x1e>
    13ae:      	cmpl	$0x15, %edx
    13b1:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    13b7:      	cmpl	%ecx, 0x1c(%rdi)
    13ba:      	jl	0x128e <filter_8ty_selector_val+0x1e>
    13c0:      	jmp	0x1487 <filter_8ty_selector_val+0x217>
    13c5:      	movl	0x8(%rdi), %esi
    13c8:      	cmpl	$0xd, %esi
    13cb:      	jb	0x13f2 <filter_8ty_selector_val+0x182>
    13cd:      	cmpl	%edx, 0x14(%rdi)
    13d0:      	je	0x12a6 <filter_8ty_selector_val+0x36>
    13d6:      	cmpl	$0x11, %esi
    13d9:      	jb	0x13f2 <filter_8ty_selector_val+0x182>
    13db:      	cmpl	%edx, 0x18(%rdi)
    13de:      	je	0x12a6 <filter_8ty_selector_val+0x36>
    13e4:      	cmpl	$0x15, %esi
    13e7:      	jb	0x13f2 <filter_8ty_selector_val+0x182>
    13e9:      	cmpl	%edx, 0x1c(%rdi)
    13ec:      	je	0x12a6 <filter_8ty_selector_val+0x36>
    13f2:      	cmpl	$0x25, %ecx
    13f5:      	ja	0x1487 <filter_8ty_selector_val+0x217>
    13fb:      	movl	%ecx, %ecx
    13fd:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1407:      	btq	%rcx, %rdx
    140b:      	jb	0x128e <filter_8ty_selector_val+0x1e>
    1411:      	jmp	0x1487 <filter_8ty_selector_val+0x217>
    1413:      	movzbl	(%rsi), %ecx
    1416:      	cmpl	%ecx, 0x10(%rdi)
    1419:      	jb	0x128e <filter_8ty_selector_val+0x1e>
    141f:      	movl	0x8(%rdi), %edx
    1422:      	cmpl	$0xd, %edx
    1425:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    1427:      	cmpl	%ecx, 0x14(%rdi)
    142a:      	jb	0x128e <filter_8ty_selector_val+0x1e>
    1430:      	cmpl	$0x11, %edx
    1433:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    1435:      	cmpl	%ecx, 0x18(%rdi)
    1438:      	jb	0x128e <filter_8ty_selector_val+0x1e>
    143e:      	cmpl	$0x15, %edx
    1441:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    1443:      	cmpl	%ecx, 0x1c(%rdi)
    1446:      	jb	0x128e <filter_8ty_selector_val+0x1e>
    144c:      	jmp	0x1487 <filter_8ty_selector_val+0x217>
    144e:      	movzbl	(%rsi), %ecx
    1451:      	cmpl	%ecx, 0x10(%rdi)
    1454:      	ja	0x128e <filter_8ty_selector_val+0x1e>
    145a:      	movl	0x8(%rdi), %edx
    145d:      	cmpl	$0xd, %edx
    1460:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    1462:      	cmpl	%ecx, 0x14(%rdi)
    1465:      	ja	0x128e <filter_8ty_selector_val+0x1e>
    146b:      	cmpl	$0x11, %edx
    146e:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    1470:      	cmpl	%ecx, 0x18(%rdi)
    1473:      	ja	0x128e <filter_8ty_selector_val+0x1e>
    1479:      	cmpl	$0x15, %edx
    147c:      	jb	0x1487 <filter_8ty_selector_val+0x217>
    147e:      	cmpl	%ecx, 0x1c(%rdi)
    1481:      	ja	0x128e <filter_8ty_selector_val+0x1e>
    1487:      	xorl	%eax, %eax
    1489:      	retq
    148a:      	nopw	(%rax,%rax)

0000000000001490 <filter_8ty_map>:
    1490:      	pushq	%r14
    1492:      	pushq	%rbx
    1493:      	subq	$0x18, %rsp
    1497:      	movq	%rsi, %r14
    149a:      	movq	%rdi, %rbx
    149d:      	movzbl	0x10(%rdi), %eax
    14a1:      	movl	%eax, 0xc(%rsp)
    14a5:      	movq	(%rip), %rdi            # 0x14ac <filter_8ty_map+0x1c>
    14ac:      	leaq	0xc(%rsp), %rsi
    14b1:      	movl	$0x1, %eax
    14b6:      	callq	*%rax
    14b8:      	testq	%rax, %rax
    14bb:      	je	0x14f1 <filter_8ty_map+0x61>
    14bd:      	movq	%rax, %rdi
    14c0:      	movzbl	(%r14), %eax
    14c4:      	movq	%rax, 0x10(%rsp)
    14c9:      	leaq	0x10(%rsp), %rsi
    14ce:      	movl	$0x1, %eax
    14d3:      	callq	*%rax
    14d5:      	movl	0x4(%rbx), %edx
    14d8:      	xorl	%ecx, %ecx
    14da:      	cmpl	$0x1d, %edx
    14dd:      	ja	0x150b <filter_8ty_map+0x7b>
    14df:      	movl	$0x30038400, %esi       # imm = 0x30038400
    14e4:      	btl	%edx, %esi
    14e7:      	jae	0x14fb <filter_8ty_map+0x6b>
    14e9:      	testq	%rax, %rax
    14ec:      	setne	%cl
    14ef:      	jmp	0x150b <filter_8ty_map+0x7b>
    14f1:      	xorl	%eax, %eax
    14f3:      	addq	$0x18, %rsp
    14f7:      	popq	%rbx
    14f8:      	popq	%r14
    14fa:      	retq
    14fb:      	movl	$0xc0800, %esi          # imm = 0xC0800
    1500:      	btl	%edx, %esi
    1503:      	jae	0x150b <filter_8ty_map+0x7b>
    1505:      	testq	%rax, %rax
    1508:      	sete	%cl
    150b:      	movzbl	%cl, %eax
    150e:      	addq	$0x18, %rsp
    1512:      	popq	%rbx
    1513:      	popq	%r14
    1515:      	retq
    1516:      	nopw	%cs:(%rax,%rax)

0000000000001520 <filter_8ty_range>:
    1520:      	movl	0x4(%rdi), %ecx
    1523:      	movl	0xc(%rdi), %eax
    1526:      	cmpl	$0xc, %eax
    1529:      	ja	0x1610 <filter_8ty_range+0xf0>
    152f:      	movl	$0x1402, %edx           # imm = 0x1402
    1534:      	btl	%eax, %edx
    1537:      	jae	0x1610 <filter_8ty_range+0xf0>
    153d:      	movsbl	(%rsi), %esi
    1540:      	cmpl	$0x1f, %ecx
    1543:      	jne	0x15ab <filter_8ty_range+0x8b>
    1545:      	movl	$0x1, %eax
    154a:      	cmpl	%esi, 0x10(%rdi)
    154d:      	jg	0x1558 <filter_8ty_range+0x38>
    154f:      	cmpl	%esi, 0x14(%rdi)
    1552:      	jge	0x1627 <filter_8ty_range+0x107>
    1558:      	movl	0x8(%rdi), %edx
    155b:      	cmpl	$0x11, %edx
    155e:      	jb	0x16c7 <filter_8ty_range+0x1a7>
    1564:      	cmpl	%esi, 0x18(%rdi)
    1567:      	jg	0x1572 <filter_8ty_range+0x52>
    1569:      	cmpl	%esi, 0x1c(%rdi)
    156c:      	jge	0x1627 <filter_8ty_range+0x107>
    1572:      	cmpl	$0x19, %edx
    1575:      	jb	0x16c7 <filter_8ty_range+0x1a7>
    157b:      	cmpl	%esi, 0x20(%rdi)
    157e:      	jg	0x1589 <filter_8ty_range+0x69>
    1580:      	cmpl	%esi, 0x24(%rdi)
    1583:      	jge	0x1627 <filter_8ty_range+0x107>
    1589:      	cmpl	$0x21, %edx
    158c:      	jb	0x16c7 <filter_8ty_range+0x1a7>
    1592:      	xorl	%edx, %edx
    1594:      	cmpl	%esi, 0x28(%rdi)
    1597:      	jg	0x16c9 <filter_8ty_range+0x1a9>
    159d:      	cmpl	%esi, 0x2c(%rdi)
    15a0:      	jge	0x1627 <filter_8ty_range+0x107>
    15a6:      	jmp	0x16c9 <filter_8ty_range+0x1a9>
    15ab:      	movl	0x8(%rdi), %eax
    15ae:      	cmpl	%esi, 0x10(%rdi)
    15b1:      	setle	%r8b
    15b5:      	cmpl	%esi, 0x14(%rdi)
    15b8:      	setge	%dl
    15bb:      	andb	%r8b, %dl
    15be:      	cmpl	$0x11, %eax
    15c1:      	jb	0x16c9 <filter_8ty_range+0x1a9>
    15c7:      	cmpl	%esi, 0x18(%rdi)
    15ca:      	setle	%r8b
    15ce:      	cmpl	%esi, 0x1c(%rdi)
    15d1:      	setge	%r9b
    15d5:      	andb	%r8b, %r9b
    15d8:      	orb	%r9b, %dl
    15db:      	cmpl	$0x19, %eax
    15de:      	jb	0x16c9 <filter_8ty_range+0x1a9>
    15e4:      	cmpl	%esi, 0x20(%rdi)
    15e7:      	setle	%r8b
    15eb:      	cmpl	%esi, 0x24(%rdi)
    15ee:      	setge	%r9b
    15f2:      	andb	%r8b, %r9b
    15f5:      	orb	%r9b, %dl
    15f8:      	cmpl	$0x21, %eax
    15fb:      	jb	0x16c9 <filter_8ty_range+0x1a9>
    1601:      	cmpl	%esi, 0x28(%rdi)
    1604:      	setle	%al
    1607:      	cmpl	%esi, 0x2c(%rdi)
    160a:      	setge	%sil
    160e:      	jmp	0x1683 <filter_8ty_range+0x163>
    1610:      	movzbl	(%rsi), %esi
    1613:      	cmpl	$0x1f, %ecx
    1616:      	jne	0x1628 <filter_8ty_range+0x108>
    1618:      	movl	$0x1, %eax
    161d:      	cmpl	%esi, 0x10(%rdi)
    1620:      	ja	0x168b <filter_8ty_range+0x16b>
    1622:      	cmpl	%esi, 0x14(%rdi)
    1625:      	jb	0x168b <filter_8ty_range+0x16b>
    1627:      	retq
    1628:      	movl	0x8(%rdi), %eax
    162b:      	cmpl	%esi, 0x10(%rdi)
    162e:      	setbe	%r8b
    1632:      	cmpl	%esi, 0x14(%rdi)
    1635:      	setae	%dl
    1638:      	andb	%r8b, %dl
    163b:      	cmpl	$0x11, %eax
    163e:      	jb	0x16c9 <filter_8ty_range+0x1a9>
    1644:      	cmpl	%esi, 0x18(%rdi)
    1647:      	setbe	%r8b
    164b:      	cmpl	%esi, 0x1c(%rdi)
    164e:      	setae	%r9b
    1652:      	andb	%r8b, %r9b
    1655:      	orb	%r9b, %dl
    1658:      	cmpl	$0x19, %eax
    165b:      	jb	0x16c9 <filter_8ty_range+0x1a9>
    165d:      	cmpl	%esi, 0x20(%rdi)
    1660:      	setbe	%r8b
    1664:      	cmpl	%esi, 0x24(%rdi)
    1667:      	setae	%r9b
    166b:      	andb	%r8b, %r9b
    166e:      	orb	%r9b, %dl
    1671:      	cmpl	$0x21, %eax
    1674:      	jb	0x16c9 <filter_8ty_range+0x1a9>
    1676:      	cmpl	%esi, 0x28(%rdi)
    1679:      	setbe	%al
    167c:      	cmpl	%esi, 0x2c(%rdi)
    167f:      	setae	%sil
    1683:      	andb	%al, %sil
    1686:      	orb	%sil, %dl
    1689:      	jmp	0x16c9 <filter_8ty_range+0x1a9>
    168b:      	movl	0x8(%rdi), %edx
    168e:      	cmpl	$0x11, %edx
    1691:      	jb	0x16c7 <filter_8ty_range+0x1a7>
    1693:      	cmpl	%esi, 0x18(%rdi)
    1696:      	ja	0x169d <filter_8ty_range+0x17d>
    1698:      	cmpl	%esi, 0x1c(%rdi)
    169b:      	jae	0x1627 <filter_8ty_range+0x107>
    169d:      	cmpl	$0x19, %edx
    16a0:      	jb	0x16c7 <filter_8ty_range+0x1a7>
    16a2:      	cmpl	%esi, 0x20(%rdi)
    16a5:      	ja	0x16b0 <filter_8ty_range+0x190>
    16a7:      	cmpl	%esi, 0x24(%rdi)
    16aa:      	jae	0x1627 <filter_8ty_range+0x107>
    16b0:      	cmpl	$0x21, %edx
    16b3:      	jb	0x16c7 <filter_8ty_range+0x1a7>
    16b5:      	xorl	%edx, %edx
    16b7:      	cmpl	%esi, 0x28(%rdi)
    16ba:      	ja	0x16c9 <filter_8ty_range+0x1a9>
    16bc:      	cmpl	%esi, 0x2c(%rdi)
    16bf:      	jae	0x1627 <filter_8ty_range+0x107>
    16c5:      	jmp	0x16c9 <filter_8ty_range+0x1a9>
    16c7:      	xorl	%edx, %edx
    16c9:      	cmpl	$0x20, %ecx
    16cc:      	sete	%al
    16cf:      	xorb	$0x1, %dl
    16d2:      	andb	%al, %dl
    16d4:      	movzbl	%dl, %eax
    16d7:      	retq
    16d8:      	nopl	(%rax,%rax)

00000000000016e0 <filter_file_buf>:
    16e0:      	pushq	%rbx
    16e1:      	movq	%rdi, %rbx
    16e4:      	movl	(%rsi), %edx
    16e6:      	movl	0x4(%rdi), %ecx
    16e9:      	testl	%edx, %edx
    16eb:      	jne	0x16fb <filter_file_buf+0x1b>
    16ed:      	movl	%ecx, %eax
    16ef:      	andl	$-0x2, %eax
    16f2:      	cmpl	$0x24, %eax
    16f5:      	je	0x16fb <filter_file_buf+0x1b>
    16f7:      	xorl	%eax, %eax
    16f9:      	popq	%rbx
    16fa:      	retq
    16fb:      	cmpl	$0x25, %ecx
    16fe:      	ja	0x173a <filter_file_buf+0x5a>
    1700:      	movl	%ecx, %eax
    1702:      	movl	$0x4000100, %edi        # imm = 0x4000100
    1707:      	btq	%rax, %rdi
    170b:      	jb	0x176e <filter_file_buf+0x8e>
    170d:      	movl	$0x8000200, %edi        # imm = 0x8000200
    1712:      	btq	%rax, %rdi
    1716:      	jb	0x1758 <filter_file_buf+0x78>
    1718:      	movabsq	$0x3000000000, %rdi     # imm = 0x3000000000
    1722:      	btq	%rax, %rdi
    1726:      	jae	0x173a <filter_file_buf+0x5a>
    1728:      	movq	%rbx, %rdi
    172b:      	callq	0x21d0 <filter_file_type>
    1730:      	movl	0x4(%rbx), %ecx
    1733:      	cmpl	$0x25, %ecx
    1736:      	jbe	0x178b <filter_file_buf+0xab>
    1738:      	jmp	0x17a1 <filter_file_buf+0xc1>
    173a:      	leal	-0x3(%rcx), %eax
    173d:      	cmpl	$0x2, %eax
    1740:      	jae	0x1784 <filter_file_buf+0xa4>
    1742:      	addq	$0x4, %rsi
    1746:      	movq	%rbx, %rdi
    1749:      	callq	0x1c60 <filter_char_buf_equal>
    174e:      	movl	0x4(%rbx), %ecx
    1751:      	cmpl	$0x25, %ecx
    1754:      	jbe	0x178b <filter_file_buf+0xab>
    1756:      	jmp	0x17a1 <filter_file_buf+0xc1>
    1758:      	addq	$0x4, %rsi
    175c:      	movl	0x10(%rbx), %edi
    175f:      	callq	0x2080 <filter_char_buf_postfix>
    1764:      	movl	0x4(%rbx), %ecx
    1767:      	cmpl	$0x25, %ecx
    176a:      	jbe	0x178b <filter_file_buf+0xab>
    176c:      	jmp	0x17a1 <filter_file_buf+0xc1>
    176e:      	addq	$0x4, %rsi
    1772:      	movl	0x10(%rbx), %edi
    1775:      	callq	0x1fe0 <filter_char_buf_prefix>
    177a:      	movl	0x4(%rbx), %ecx
    177d:      	cmpl	$0x25, %ecx
    1780:      	jbe	0x178b <filter_file_buf+0xab>
    1782:      	jmp	0x17a1 <filter_file_buf+0xc1>
    1784:      	xorl	%eax, %eax
    1786:      	cmpl	$0x25, %ecx
    1789:      	ja	0x17a1 <filter_file_buf+0xc1>
    178b:      	movl	%ecx, %ecx
    178d:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1797:      	btq	%rcx, %rdx
    179b:      	jae	0x17a1 <filter_file_buf+0xc1>
    179d:      	xorq	$0x1, %rax
    17a1:      	popq	%rbx
    17a2:      	retq
    17a3:      	nopw	%cs:(%rax,%rax)

00000000000017b0 <filter_char_buf>:
    17b0:      	pushq	%rbx
    17b1:      	movq	%rsi, %rax
    17b4:      	movq	%rdi, %rbx
    17b7:      	movslq	%edx, %rcx
    17ba:      	movl	-0x4(%rsi,%rcx), %edx
    17be:      	movl	%ecx, %esi
    17c0:      	addq	%rax, %rsi
    17c3:      	movl	0x4(%rdi), %ecx
    17c6:      	xorl	%eax, %eax
    17c8:      	cmpl	$0x19, %ecx
    17cb:      	jg	0x17e1 <filter_char_buf+0x31>
    17cd:      	leal	-0x3(%rcx), %edi
    17d0:      	cmpl	$0x2, %edi
    17d3:      	jb	0x1818 <filter_char_buf+0x68>
    17d5:      	cmpl	$0x8, %ecx
    17d8:      	je	0x180e <filter_char_buf+0x5e>
    17da:      	cmpl	$0x9, %ecx
    17dd:      	je	0x17f0 <filter_char_buf+0x40>
    17df:      	jmp	0x182f <filter_char_buf+0x7f>
    17e1:      	cmpl	$0x20, %ecx
    17e4:      	jg	0x17fa <filter_char_buf+0x4a>
    17e6:      	cmpl	$0x1a, %ecx
    17e9:      	je	0x180e <filter_char_buf+0x5e>
    17eb:      	cmpl	$0x1b, %ecx
    17ee:      	jne	0x182f <filter_char_buf+0x7f>
    17f0:      	movl	0x10(%rbx), %edi
    17f3:      	callq	0x2080 <filter_char_buf_postfix>
    17f8:      	jmp	0x182c <filter_char_buf+0x7c>
    17fa:      	cmpl	$0x21, %ecx
    17fd:      	je	0x1822 <filter_char_buf+0x72>
    17ff:      	cmpl	$0x22, %ecx
    1802:      	jne	0x182f <filter_char_buf+0x7f>
    1804:      	movq	%rbx, %rdi
    1807:      	movl	$0x1, %ecx
    180c:      	jmp	0x1827 <filter_char_buf+0x77>
    180e:      	movl	0x10(%rbx), %edi
    1811:      	callq	0x1fe0 <filter_char_buf_prefix>
    1816:      	jmp	0x182c <filter_char_buf+0x7c>
    1818:      	movq	%rbx, %rdi
    181b:      	callq	0x1c60 <filter_char_buf_equal>
    1820:      	jmp	0x182c <filter_char_buf+0x7c>
    1822:      	movq	%rbx, %rdi
    1825:      	xorl	%ecx, %ecx
    1827:      	callq	0x2280 <filter_char_substring>
    182c:      	movl	0x4(%rbx), %ecx
    182f:      	cmpl	$0x25, %ecx
    1832:      	ja	0x1851 <filter_char_buf+0xa1>
    1834:      	movl	%ecx, %ecx
    1836:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1840:      	btq	%rcx, %rdx
    1844:      	jae	0x1851 <filter_char_buf+0xa1>
    1846:      	xorl	%ecx, %ecx
    1848:      	testq	%rax, %rax
    184b:      	sete	%cl
    184e:      	movq	%rcx, %rax
    1851:      	popq	%rbx
    1852:      	retq
    1853:      	nopw	%cs:(%rax,%rax)

0000000000001860 <filter_inet>:
    1860:      	pushq	%r15
    1862:      	pushq	%r14
    1864:      	pushq	%r12
    1866:      	pushq	%rbx
    1867:      	subq	$0x48, %rsp
    186b:      	movq	$0x0, 0x40(%rsp)
    1874:      	movq	$0x0, 0x38(%rsp)
    187d:      	movq	$0x0, 0x30(%rsp)
    1886:      	movq	$0x0, 0x28(%rsp)
    188f:      	movq	$0x0, 0x20(%rsp)
    1898:      	movl	$0x0, (%rsp)
    189f:      	movl	$0x0, 0x4(%rsp)
    18a7:      	movl	0xc(%rdi), %edx
    18aa:      	xorl	%eax, %eax
    18ac:      	cmpl	$0x27, %edx
    18af:      	jg	0x18c7 <filter_inet+0x67>
    18b1:      	cmpl	$0x5, %edx
    18b4:      	je	0x194c <filter_inet+0xec>
    18ba:      	movq	%rsi, %r8
    18bd:      	cmpl	$0x7, %edx
    18c0:      	je	0x18d8 <filter_inet+0x78>
    18c2:      	jmp	0x1b5d <filter_inet+0x2fd>
    18c7:      	cmpl	$0x28, %edx
    18ca:      	je	0x1924 <filter_inet+0xc4>
    18cc:      	movq	%rsi, %r8
    18cf:      	cmpl	$0x29, %edx
    18d2:      	jne	0x1b5d <filter_inet+0x2fd>
    18d8:      	movl	0x4(%rdi), %ecx
    18db:      	xorl	%eax, %eax
    18dd:      	cmpl	$0x13, %ecx
    18e0:      	jle	0x1959 <filter_inet+0xf9>
    18e2:      	cmpl	$0x17, %ecx
    18e5:      	jg	0x1904 <filter_inet+0xa4>
    18e7:      	leal	-0x14(%rcx), %edx
    18ea:      	cmpl	$0x2, %edx
    18ed:      	jb	0x19aa <filter_inet+0x14a>
    18f3:      	leal	-0x16(%rcx), %edx
    18f6:      	cmpl	$0x2, %edx
    18f9:      	jb	0x19a4 <filter_inet+0x144>
    18ff:      	jmp	0x1b5d <filter_inet+0x2fd>
    1904:      	cmpl	$0x1b, %ecx
    1907:      	jg	0x19e7 <filter_inet+0x187>
    190d:      	cmpl	$0x18, %ecx
    1910:      	je	0x1a1a <filter_inet+0x1ba>
    1916:      	cmpl	$0x19, %ecx
    1919:      	je	0x1a10 <filter_inet+0x1b0>
    191f:      	jmp	0x1b5d <filter_inet+0x2fd>
    1924:      	movzwl	(%rsi), %eax
    1927:      	movw	%ax, 0x46(%rsp)
    192c:      	movzwl	0x2(%rsi), %eax
    1930:      	movw	%ax, 0x40(%rsp)
    1935:      	movq	0x8(%rsi), %rax
    1939:      	movq	%rax, 0x20(%rsp)
    193e:      	movq	0x10(%rsi), %rax
    1942:      	movq	%rax, 0x28(%rsp)
    1947:      	leaq	0x20(%rsp), %rsi
    194c:      	xorl	%r8d, %r8d
    194f:      	movl	0x4(%rdi), %ecx
    1952:      	xorl	%eax, %eax
    1954:      	cmpl	$0x13, %ecx
    1957:      	jg	0x18e2 <filter_inet+0x82>
    1959:      	cmpl	$0xf, %ecx
    195c:      	jle	0x197a <filter_inet+0x11a>
    195e:      	cmpl	$0x11, %ecx
    1961:      	jg	0x1996 <filter_inet+0x136>
    1963:      	cmpl	$0x10, %ecx
    1966:      	je	0x19a4 <filter_inet+0x144>
    1968:      	cmpl	$0x11, %ecx
    196b:      	jne	0x1b5d <filter_inet+0x2fd>
    1971:      	movzwl	0x24(%rsi), %eax
    1975:      	jmp	0x1b52 <filter_inet+0x2f2>
    197a:      	cmpl	$0xd, %ecx
    197d:      	je	0x1a1a <filter_inet+0x1ba>
    1983:      	cmpl	$0xe, %ecx
    1986:      	je	0x1a10 <filter_inet+0x1b0>
    198c:      	cmpl	$0xf, %ecx
    198f:      	je	0x19aa <filter_inet+0x14a>
    1991:      	jmp	0x1b5d <filter_inet+0x2fd>
    1996:      	cmpl	$0x12, %ecx
    1999:      	je	0x19aa <filter_inet+0x14a>
    199b:      	cmpl	$0x13, %ecx
    199e:      	jne	0x1b5d <filter_inet+0x2fd>
    19a4:      	movzwl	0x22(%rsi), %edx
    19a8:      	jmp	0x19ae <filter_inet+0x14e>
    19aa:      	movzwl	0x20(%rsi), %edx
    19ae:      	movl	%edx, 0x4(%rsp)
    19b2:      	xorl	%ebx, %ebx
    19b4:      	xorl	%r15d, %r15d
    19b7:      	xorl	%r14d, %r14d
    19ba:      	xorl	%eax, %eax
    19bc:      	cmpl	$0x11, %ecx
    19bf:      	jg	0x1a31 <filter_inet+0x1d1>
    19c1:      	leal	-0xd(%rcx), %edx
    19c4:      	cmpl	$0x2, %edx
    19c7:      	jb	0x1a58 <filter_inet+0x1f8>
    19cd:      	leal	-0xf(%rcx), %edx
    19d0:      	cmpl	$0x2, %edx
    19d3:      	jb	0x1aad <filter_inet+0x24d>
    19d9:      	cmpl	$0x11, %ecx
    19dc:      	je	0x1b55 <filter_inet+0x2f5>
    19e2:      	jmp	0x1b5d <filter_inet+0x2fd>
    19e7:      	cmpl	$0x1c, %ecx
    19ea:      	je	0x1b4e <filter_inet+0x2ee>
    19f0:      	cmpl	$0x1d, %ecx
    19f3:      	jne	0x1b5d <filter_inet+0x2fd>
    19f9:      	cmpl	$0x7, %edx
    19fc:      	jne	0x1b81 <filter_inet+0x321>
    1a02:      	testq	%r8, %r8
    1a05:      	jne	0x1b8b <filter_inet+0x32b>
    1a0b:      	jmp	0x1b55 <filter_inet+0x2f5>
    1a10:      	movq	0x10(%rsi), %rbx
    1a14:      	movq	0x18(%rsi), %r14
    1a18:      	jmp	0x1a21 <filter_inet+0x1c1>
    1a1a:      	movq	(%rsi), %rbx
    1a1d:      	movq	0x8(%rsi), %r14
    1a21:      	movq	%rbx, %r15
    1a24:      	shrq	$0x20, %r15
    1a28:      	xorl	%edx, %edx
    1a2a:      	xorl	%eax, %eax
    1a2c:      	cmpl	$0x11, %ecx
    1a2f:      	jle	0x19c1 <filter_inet+0x161>
    1a31:      	cmpl	$0x19, %ecx
    1a34:      	ja	0x1aa1 <filter_inet+0x241>
    1a36:      	movl	$0x500000, %r8d         # imm = 0x500000
    1a3c:      	btl	%ecx, %r8d
    1a40:      	jb	0x1ab7 <filter_inet+0x257>
    1a42:      	movl	$0xa00000, %r8d         # imm = 0xA00000
    1a48:      	btl	%ecx, %r8d
    1a4c:      	jb	0x1ac7 <filter_inet+0x267>
    1a4e:      	movl	$0x3000000, %edx        # imm = 0x3000000
    1a53:      	btl	%ecx, %edx
    1a56:      	jae	0x1aa1 <filter_inet+0x241>
    1a58:      	movzwl	0x26(%rsi), %eax
    1a5c:      	cmpl	$0xa, %eax
    1a5f:      	je	0x1ad7 <filter_inet+0x277>
    1a61:      	cmpl	$0x2, %eax
    1a64:      	jne	0x1b47 <filter_inet+0x2e7>
    1a6a:      	movq	%rdi, %r12
    1a6d:      	movl	0x10(%rdi), %eax
    1a70:      	movl	%eax, 0x8(%rsp)
    1a74:      	movq	(%rip), %rdi            # 0x1a7b <filter_inet+0x21b>
    1a7b:      	leaq	0x8(%rsp), %rsi
    1a80:      	movl	$0x1, %eax
    1a85:      	callq	*%rax
    1a87:      	testq	%rax, %rax
    1a8a:      	je	0x1b69 <filter_inet+0x309>
    1a90:      	movq	%rax, %rdi
    1a93:      	movl	$0x20, 0xc(%rsp)
    1a9b:      	movl	%ebx, 0x10(%rsp)
    1a9f:      	jmp	0x1b1b <filter_inet+0x2bb>
    1aa1:      	addl	$-0x12, %ecx
    1aa4:      	cmpl	$0x2, %ecx
    1aa7:      	jae	0x1b5d <filter_inet+0x2fd>
    1aad:      	leaq	0x4(%rsp), %rsi
    1ab2:      	jmp	0x1b58 <filter_inet+0x2f8>
    1ab7:      	xorl	%eax, %eax
    1ab9:      	cmpl	$0x400, %edx            # imm = 0x400
    1abf:      	setb	%al
    1ac2:      	jmp	0x1b5d <filter_inet+0x2fd>
    1ac7:      	xorl	%eax, %eax
    1ac9:      	cmpl	$0x400, %edx            # imm = 0x400
    1acf:      	setae	%al
    1ad2:      	jmp	0x1b5d <filter_inet+0x2fd>
    1ad7:      	movq	%rdi, %r12
    1ada:      	movl	0x14(%rdi), %eax
    1add:      	movl	%eax, 0x8(%rsp)
    1ae1:      	movq	(%rip), %rdi            # 0x1ae8 <filter_inet+0x288>
    1ae8:      	leaq	0x8(%rsp), %rsi
    1aed:      	movl	$0x1, %eax
    1af2:      	callq	*%rax
    1af4:      	testq	%rax, %rax
    1af7:      	je	0x1b69 <filter_inet+0x309>
    1af9:      	movq	%rax, %rdi
    1afc:      	movl	$0x80, 0xc(%rsp)
    1b04:      	movl	%ebx, 0x10(%rsp)
    1b08:      	movl	%r15d, 0x14(%rsp)
    1b0d:      	movl	%r14d, 0x18(%rsp)
    1b12:      	shrq	$0x20, %r14
    1b16:      	movl	%r14d, 0x1c(%rsp)
    1b1b:      	leaq	0xc(%rsp), %rsi
    1b20:      	movl	$0x1, %eax
    1b25:      	callq	*%rax
    1b27:      	movl	0x4(%r12), %ecx
    1b2c:      	leal	-0x18(%rcx), %edx
    1b2f:      	cmpl	$0x2, %edx
    1b32:      	jb	0x1b76 <filter_inet+0x316>
    1b34:      	addl	$-0xd, %ecx
    1b37:      	cmpl	$0x1, %ecx
    1b3a:      	ja	0x1b47 <filter_inet+0x2e7>
    1b3c:      	testq	%rax, %rax
    1b3f:      	setne	%al
    1b42:      	movzbl	%al, %eax
    1b45:      	jmp	0x1b5d <filter_inet+0x2fd>
    1b47:      	xorl	%eax, %eax
    1b49:      	movzbl	%al, %eax
    1b4c:      	jmp	0x1b5d <filter_inet+0x2fd>
    1b4e:      	movzwl	0x26(%rsi), %eax
    1b52:      	movl	%eax, (%rsp)
    1b55:      	movq	%rsp, %rsi
    1b58:      	callq	0xbb0 <filter_32ty_map>
    1b5d:      	addq	$0x48, %rsp
    1b61:      	popq	%rbx
    1b62:      	popq	%r12
    1b64:      	popq	%r14
    1b66:      	popq	%r15
    1b68:      	retq
    1b69:      	movl	0x4(%r12), %eax
    1b6e:      	andl	$-0x2, %eax
    1b71:      	cmpl	$0x18, %eax
    1b74:      	jmp	0x1b79 <filter_inet+0x319>
    1b76:      	testq	%rax, %rax
    1b79:      	sete	%al
    1b7c:      	movzbl	%al, %eax
    1b7f:      	jmp	0x1b5d <filter_inet+0x2fd>
    1b81:      	cmpl	$0x29, %edx
    1b84:      	jne	0x1b93 <filter_inet+0x333>
    1b86:      	testq	%r8, %r8
    1b89:      	je	0x1b93 <filter_inet+0x333>
    1b8b:      	movzbl	0x3a(%r8), %eax
    1b90:      	movl	%eax, (%rsp)
    1b93:      	cmpl	$0x29, %edx
    1b96:      	je	0x1b55 <filter_inet+0x2f5>
    1b98:      	cmpl	$0x7, %edx
    1b9b:      	je	0x1b55 <filter_inet+0x2f5>
    1b9d:      	xorl	%eax, %eax
    1b9f:      	jmp	0x1b5d <filter_inet+0x2fd>
    1ba1:      	nopw	%cs:(%rax,%rax)

0000000000001bb0 <filter_sockaddr_un>:
    1bb0:      	pushq	%rbx
    1bb1:      	subq	$0x10, %rsp
    1bb5:      	movq	%rsi, %rcx
    1bb8:      	addq	$0x4, %rsi
    1bbc:      	movzbl	0x3(%rcx), %edx
    1bc0:      	movl	0x4(%rdi), %r8d
    1bc4:      	xorl	%eax, %eax
    1bc6:      	cmpl	$0x19, %r8d
    1bca:      	jg	0x1c00 <filter_sockaddr_un+0x50>
    1bcc:      	leal	-0x3(%r8), %ecx
    1bd0:      	cmpl	$0x2, %ecx
    1bd3:      	jae	0x1c0e <filter_sockaddr_un+0x5e>
    1bd5:      	movq	%rdi, %rbx
    1bd8:      	callq	0x1c60 <filter_char_buf_equal>
    1bdd:      	movl	0x4(%rbx), %ecx
    1be0:      	cmpq	$0x25, %rcx
    1be4:      	ja	0x1bfa <filter_sockaddr_un+0x4a>
    1be6:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1bf0:      	btq	%rcx, %rdx
    1bf4:      	jae	0x1bfa <filter_sockaddr_un+0x4a>
    1bf6:      	xorq	$0x1, %rax
    1bfa:      	addq	$0x10, %rsp
    1bfe:      	popq	%rbx
    1bff:      	retq
    1c00:      	cmpl	$0x1c, %r8d
    1c04:      	je	0x1c44 <filter_sockaddr_un+0x94>
    1c06:      	cmpl	$0x1a, %r8d
    1c0a:      	je	0x1c14 <filter_sockaddr_un+0x64>
    1c0c:      	jmp	0x1bfa <filter_sockaddr_un+0x4a>
    1c0e:      	cmpl	$0x8, %r8d
    1c12:      	jne	0x1bfa <filter_sockaddr_un+0x4a>
    1c14:      	movl	0x10(%rdi), %eax
    1c17:      	movq	%rdi, %rbx
    1c1a:      	movl	%eax, %edi
    1c1c:      	callq	0x1fe0 <filter_char_buf_prefix>
    1c21:      	movl	0x4(%rbx), %ecx
    1c24:      	cmpq	$0x25, %rcx
    1c28:      	ja	0x1bfa <filter_sockaddr_un+0x4a>
    1c2a:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1c34:      	btq	%rcx, %rdx
    1c38:      	jae	0x1bfa <filter_sockaddr_un+0x4a>
    1c3a:      	xorq	$0x1, %rax
    1c3e:      	addq	$0x10, %rsp
    1c42:      	popq	%rbx
    1c43:      	retq
    1c44:      	movzwl	(%rcx), %eax
    1c47:      	movl	%eax, 0xc(%rsp)
    1c4b:      	leaq	0xc(%rsp), %rsi
    1c50:      	callq	0xbb0 <filter_32ty_map>
    1c55:      	addq	$0x10, %rsp
    1c59:      	popq	%rbx
    1c5a:      	retq
    1c5b:      	nopl	(%rax,%rax)

0000000000001c60 <filter_char_buf_equal>:
    1c60:      	pushq	%rbp
    1c61:      	pushq	%r15
    1c63:      	pushq	%r14
    1c65:      	pushq	%r13
    1c67:      	pushq	%r12
    1c69:      	pushq	%rbx
    1c6a:      	subq	$0x28, %rsp
    1c6e:      	movl	$0x0, 0x14(%rsp)
    1c76:      	cmpl	$0x1000, %edx           # imm = 0x1000
    1c7c:      	ja	0x1fce <filter_char_buf_equal+0x36e>
    1c82:      	movl	%edx, %ebp
    1c84:      	movzwl	%bp, %eax
    1c87:      	cmpl	$0x90, %eax
    1c8c:      	ja	0x1cd5 <filter_char_buf_equal+0x75>
    1c8e:      	testw	%bp, %bp
    1c91:      	je	0x1ca4 <filter_char_buf_equal+0x44>
    1c93:      	movl	$0x18, %ecx
    1c98:      	movl	%ebp, %eax
    1c9a:      	cltd
    1c9b:      	idivl	%ecx
    1c9d:      	movl	%ebp, %r14d
    1ca0:      	testl	%edx, %edx
    1ca2:      	je	0x1cc4 <filter_char_buf_equal+0x64>
    1ca4:      	movl	$0x18, %ecx
    1ca9:      	movl	%ebp, %eax
    1cab:      	cltd
    1cac:      	idivl	%ecx
    1cae:      	shll	$0x3, %eax
    1cb1:      	leal	(%rax,%rax,2), %eax
    1cb4:      	addl	$0x18, %eax
    1cb7:      	movzwl	%ax, %r14d
    1cbb:      	cmpl	$0x90, %r14d
    1cc2:      	ja	0x1d13 <filter_char_buf_equal+0xb3>
    1cc4:      	movl	%r14d, %eax
    1cc7:      	cltd
    1cc8:      	idivl	%ecx
    1cca:      	movl	%eax, %r15d
    1ccd:      	decl	%r15d
    1cd0:      	jmp	0x1d5e <filter_char_buf_equal+0xfe>
    1cd5:      	movl	$0x100, %r14d           # imm = 0x100
    1cdb:      	cmpl	$0x101, %eax            # imm = 0x101
    1ce0:      	jb	0x1d13 <filter_char_buf_equal+0xb3>
    1ce2:      	movl	$0x200, %r14d           # imm = 0x200
    1ce8:      	cmpl	$0x201, %eax            # imm = 0x201
    1ced:      	jb	0x1d13 <filter_char_buf_equal+0xb3>
    1cef:      	movl	$0x400, %r14d           # imm = 0x400
    1cf5:      	cmpl	$0x401, %eax            # imm = 0x401
    1cfa:      	jb	0x1d13 <filter_char_buf_equal+0xb3>
    1cfc:      	xorl	%r14d, %r14d
    1cff:      	cmpl	$0x801, %eax            # imm = 0x801
    1d04:      	setae	%r14b
    1d08:      	shll	$0xb, %r14d
    1d0c:      	addl	$0x800, %r14d           # imm = 0x800
    1d13:      	leal	-0x100(%r14), %eax
    1d1a:      	rorxl	$0x8, %eax, %eax
    1d20:      	cmpl	$0x2, %eax
    1d23:      	jg	0x1d36 <filter_char_buf_equal+0xd6>
    1d25:      	testl	%eax, %eax
    1d27:      	je	0x1d50 <filter_char_buf_equal+0xf0>
    1d29:      	cmpl	$0x1, %eax
    1d2c:      	jne	0x1d48 <filter_char_buf_equal+0xe8>
    1d2e:      	movl	$0x7, %r15d
    1d34:      	jmp	0x1d5e <filter_char_buf_equal+0xfe>
    1d36:      	cmpl	$0x3, %eax
    1d39:      	je	0x1d58 <filter_char_buf_equal+0xf8>
    1d3b:      	cmpl	$0x7, %eax
    1d3e:      	jne	0x1d48 <filter_char_buf_equal+0xe8>
    1d40:      	movl	$0x9, %r15d
    1d46:      	jmp	0x1d5e <filter_char_buf_equal+0xfe>
    1d48:      	movl	$0xa, %r15d
    1d4e:      	jmp	0x1d5e <filter_char_buf_equal+0xfe>
    1d50:      	movl	$0x6, %r15d
    1d56:      	jmp	0x1d5e <filter_char_buf_equal+0xfe>
    1d58:      	movl	$0x8, %r15d
    1d5e:      	movl	%r15d, %eax
    1d61:      	andl	$0xf, %eax
    1d64:      	movl	0x10(%rdi,%rax,4), %r13d
    1d69:      	cmpl	$-0x1, %r13d
    1d6d:      	je	0x1fce <filter_char_buf_equal+0x36e>
    1d73:      	movq	%rsi, 0x20(%rsp)
    1d78:      	movq	(%rip), %rdi            # 0x1d7f <filter_char_buf_equal+0x11f>
    1d7f:      	leaq	0x14(%rsp), %r12
    1d84:      	movl	$0x1, %eax
    1d89:      	movq	%r12, %rsi
    1d8c:      	callq	*%rax
    1d8e:      	movq	%rax, %rbx
    1d91:      	movq	(%rip), %rdi            # 0x1d98 <filter_char_buf_equal+0x138>
    1d98:      	movl	$0x1, %eax
    1d9d:      	movq	%r12, %rsi
    1da0:      	callq	*%rax
    1da2:      	movq	%rax, %rcx
    1da5:      	xorl	%eax, %eax
    1da7:      	movq	%rbx, 0x8(%rsp)
    1dac:      	testq	%rbx, %rbx
    1daf:      	je	0x1fd0 <filter_char_buf_equal+0x370>
    1db5:      	testq	%rcx, %rcx
    1db8:      	je	0x1fd0 <filter_char_buf_equal+0x370>
    1dbe:      	movq	%rcx, 0x18(%rsp)
    1dc3:      	cmpl	$0x5, %r15d
    1dc7:      	jg	0x1e0a <filter_char_buf_equal+0x1aa>
    1dc9:      	movq	0x8(%rsp), %rax
    1dce:      	movb	%bpl, (%rax)
    1dd1:      	leaq	0x1(%rax), %rdi
    1dd5:      	movl	%ebp, %r12d
    1dd8:      	movl	$0x4, %eax
    1ddd:      	movq	0x20(%rsp), %rdx
    1de2:      	movl	%ebp, %esi
    1de4:      	callq	*%rax
    1de6:      	subl	%ebp, %r14d
    1de9:      	jbe	0x1e4f <filter_char_buf_equal+0x1ef>
    1deb:      	movq	0x8(%rsp), %rax
    1df0:      	leaq	(%rax,%r12), %rdi
    1df4:      	incq	%rdi
    1df7:      	andl	$0xfff, %r14d           # imm = 0xFFF
    1dfe:      	movl	$0x4, %eax
    1e03:      	movq	0x18(%rsp), %rdx
    1e08:      	jmp	0x1e4a <filter_char_buf_equal+0x1ea>
    1e0a:      	movq	0x8(%rsp), %rax
    1e0f:      	movw	%bp, (%rax)
    1e12:      	leaq	0x2(%rax), %rdi
    1e16:      	movl	%ebp, %r12d
    1e19:      	movl	$0x4, %eax
    1e1e:      	movq	0x20(%rsp), %rdx
    1e23:      	movl	%ebp, %esi
    1e25:      	callq	*%rax
    1e27:      	subl	%ebp, %r14d
    1e2a:      	jbe	0x1e4f <filter_char_buf_equal+0x1ef>
    1e2c:      	movq	0x8(%rsp), %rax
    1e31:      	leaq	(%rax,%r12), %rdi
    1e35:      	addq	$0x2, %rdi
    1e39:      	andl	$0xfff, %r14d           # imm = 0xFFF
    1e40:      	movl	$0x4, %eax
    1e45:      	movq	0x18(%rsp), %rdx
    1e4a:      	movl	%r14d, %esi
    1e4d:      	callq	*%rax
    1e4f:      	movl	%r13d, 0x4(%rsp)
    1e54:      	cmpl	$0x4, %r15d
    1e58:      	jle	0x1e94 <filter_char_buf_equal+0x234>
    1e5a:      	cmpl	$0x7, %r15d
    1e5e:      	jg	0x1ece <filter_char_buf_equal+0x26e>
    1e60:      	cmpl	$0x5, %r15d
    1e64:      	je	0x1f82 <filter_char_buf_equal+0x322>
    1e6a:      	cmpl	$0x6, %r15d
    1e6e:      	je	0x1f49 <filter_char_buf_equal+0x2e9>
    1e74:      	cmpl	$0x7, %r15d
    1e78:      	jne	0x1fce <filter_char_buf_equal+0x36e>
    1e7e:      	movq	(%rip), %rdi            # 0x1e85 <filter_char_buf_equal+0x225>
    1e85:      	leaq	0x4(%rsp), %rcx
    1e8a:      	movl	$0x1, %eax
    1e8f:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1e94:      	cmpl	$0x1, %r15d
    1e98:      	jle	0x1efe <filter_char_buf_equal+0x29e>
    1e9a:      	cmpl	$0x2, %r15d
    1e9e:      	je	0x1f6f <filter_char_buf_equal+0x30f>
    1ea4:      	cmpl	$0x3, %r15d
    1ea8:      	je	0x1f36 <filter_char_buf_equal+0x2d6>
    1eae:      	cmpl	$0x4, %r15d
    1eb2:      	jne	0x1fce <filter_char_buf_equal+0x36e>
    1eb8:      	movq	(%rip), %rdi            # 0x1ebf <filter_char_buf_equal+0x25f>
    1ebf:      	leaq	0x4(%rsp), %rcx
    1ec4:      	movl	$0x1, %eax
    1ec9:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1ece:      	cmpl	$0x8, %r15d
    1ed2:      	je	0x1f95 <filter_char_buf_equal+0x335>
    1ed8:      	cmpl	$0x9, %r15d
    1edc:      	je	0x1f5c <filter_char_buf_equal+0x2fc>
    1ede:      	cmpl	$0xa, %r15d
    1ee2:      	jne	0x1fce <filter_char_buf_equal+0x36e>
    1ee8:      	movq	(%rip), %rdi            # 0x1eef <filter_char_buf_equal+0x28f>
    1eef:      	leaq	0x4(%rsp), %rcx
    1ef4:      	movl	$0x1, %eax
    1ef9:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1efe:      	testl	%r15d, %r15d
    1f01:      	je	0x1f23 <filter_char_buf_equal+0x2c3>
    1f03:      	cmpl	$0x1, %r15d
    1f07:      	jne	0x1fce <filter_char_buf_equal+0x36e>
    1f0d:      	movq	(%rip), %rdi            # 0x1f14 <filter_char_buf_equal+0x2b4>
    1f14:      	leaq	0x4(%rsp), %rcx
    1f19:      	movl	$0x1, %eax
    1f1e:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1f23:      	movq	(%rip), %rdi            # 0x1f2a <filter_char_buf_equal+0x2ca>
    1f2a:      	leaq	0x4(%rsp), %rcx
    1f2f:      	movl	$0x1, %eax
    1f34:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1f36:      	movq	(%rip), %rdi            # 0x1f3d <filter_char_buf_equal+0x2dd>
    1f3d:      	leaq	0x4(%rsp), %rcx
    1f42:      	movl	$0x1, %eax
    1f47:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1f49:      	movq	(%rip), %rdi            # 0x1f50 <filter_char_buf_equal+0x2f0>
    1f50:      	leaq	0x4(%rsp), %rcx
    1f55:      	movl	$0x1, %eax
    1f5a:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1f5c:      	movq	(%rip), %rdi            # 0x1f63 <filter_char_buf_equal+0x303>
    1f63:      	leaq	0x4(%rsp), %rcx
    1f68:      	movl	$0x1, %eax
    1f6d:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1f6f:      	movq	(%rip), %rdi            # 0x1f76 <filter_char_buf_equal+0x316>
    1f76:      	leaq	0x4(%rsp), %rcx
    1f7b:      	movl	$0x1, %eax
    1f80:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1f82:      	movq	(%rip), %rdi            # 0x1f89 <filter_char_buf_equal+0x329>
    1f89:      	leaq	0x4(%rsp), %rcx
    1f8e:      	movl	$0x1, %eax
    1f93:      	jmp	0x1fa6 <filter_char_buf_equal+0x346>
    1f95:      	movq	(%rip), %rdi            # 0x1f9c <filter_char_buf_equal+0x33c>
    1f9c:      	leaq	0x4(%rsp), %rcx
    1fa1:      	movl	$0x1, %eax
    1fa6:      	leaq	0x4(%rsp), %rsi
    1fab:      	callq	*%rax
    1fad:      	testq	%rax, %rax
    1fb0:      	je	0x1fce <filter_char_buf_equal+0x36e>
    1fb2:      	movq	%rax, %rdi
    1fb5:      	movl	$0x1, %eax
    1fba:      	movq	0x8(%rsp), %rsi
    1fbf:      	callq	*%rax
    1fc1:      	movq	%rax, %rcx
    1fc4:      	xorl	%eax, %eax
    1fc6:      	testq	%rcx, %rcx
    1fc9:      	setne	%al
    1fcc:      	jmp	0x1fd0 <filter_char_buf_equal+0x370>
    1fce:      	xorl	%eax, %eax
    1fd0:      	addq	$0x28, %rsp
    1fd4:      	popq	%rbx
    1fd5:      	popq	%r12
    1fd7:      	popq	%r13
    1fd9:      	popq	%r14
    1fdb:      	popq	%r15
    1fdd:      	popq	%rbp
    1fde:      	retq
    1fdf:      	nop

0000000000001fe0 <filter_char_buf_prefix>:
    1fe0:      	pushq	%rbp
    1fe1:      	pushq	%r15
    1fe3:      	pushq	%r14
    1fe5:      	pushq	%rbx
    1fe6:      	pushq	%rax
    1fe7:      	movl	%edx, %ebp
    1fe9:      	movq	%rsi, %rbx
    1fec:      	movl	%edi, 0x4(%rsp)
    1ff0:      	movl	$0x0, (%rsp)
    1ff7:      	movq	(%rip), %rdi            # 0x1ffe <filter_char_buf_prefix+0x1e>
    1ffe:      	leaq	0x4(%rsp), %rsi
    2003:      	movl	$0x1, %eax
    2008:      	callq	*%rax
    200a:      	movq	%rax, %r14
    200d:      	xorl	%eax, %eax
    200f:      	testl	%ebp, %ebp
    2011:      	je	0x2075 <filter_char_buf_prefix+0x95>
    2013:      	testq	%r14, %r14
    2016:      	je	0x2075 <filter_char_buf_prefix+0x95>
    2018:      	movq	(%rip), %rdi            # 0x201f <filter_char_buf_prefix+0x3f>
    201f:      	movq	%rsp, %rsi
    2022:      	movl	$0x1, %eax
    2027:      	callq	*%rax
    2029:      	testq	%rax, %rax
    202c:      	je	0x2073 <filter_char_buf_prefix+0x93>
    202e:      	cmpl	$0xff, %ebp
    2034:      	movl	$0xff, %esi
    2039:      	cmovbl	%ebp, %esi
    203c:      	leal	(,%rsi,8), %ecx
    2043:      	movl	%ecx, (%rax)
    2045:      	movq	%rax, %rdi
    2048:      	addq	$0x4, %rdi
    204c:      	movq	%rax, %r15
    204f:      	movl	$0x4, %eax
    2054:      	movq	%rbx, %rdx
    2057:      	callq	*%rax
    2059:      	movl	$0x1, %eax
    205e:      	movq	%r14, %rdi
    2061:      	movq	%r15, %rsi
    2064:      	callq	*%rax
    2066:      	movq	%rax, %rcx
    2069:      	xorl	%eax, %eax
    206b:      	testq	%rcx, %rcx
    206e:      	setne	%al
    2071:      	jmp	0x2075 <filter_char_buf_prefix+0x95>
    2073:      	xorl	%eax, %eax
    2075:      	addq	$0x8, %rsp
    2079:      	popq	%rbx
    207a:      	popq	%r14
    207c:      	popq	%r15
    207e:      	popq	%rbp
    207f:      	retq

0000000000002080 <filter_char_buf_postfix>:
    2080:      	pushq	%r15
    2082:      	pushq	%r14
    2084:      	pushq	%rbx
    2085:      	subq	$0x10, %rsp
    2089:      	movl	%edx, %ebx
    208b:      	movq	%rsi, %r14
    208e:      	movl	%edi, 0xc(%rsp)
    2092:      	movl	$0x0, 0x8(%rsp)
    209a:      	movq	(%rip), %rdi            # 0x20a1 <filter_char_buf_postfix+0x21>
    20a1:      	leaq	0xc(%rsp), %rsi
    20a6:      	movl	$0x1, %eax
    20ab:      	callq	*%rax
    20ad:      	movq	%rax, %r15
    20b0:      	xorl	%eax, %eax
    20b2:      	testl	%ebx, %ebx
    20b4:      	je	0x21c0 <filter_char_buf_postfix+0x140>
    20ba:      	testq	%r15, %r15
    20bd:      	je	0x21c0 <filter_char_buf_postfix+0x140>
    20c3:      	movq	(%rip), %rdi            # 0x20ca <filter_char_buf_postfix+0x4a>
    20ca:      	leaq	0x8(%rsp), %rsi
    20cf:      	movl	$0x1, %eax
    20d4:      	callq	*%rax
    20d6:      	testq	%rax, %rax
    20d9:      	je	0x21be <filter_char_buf_postfix+0x13e>
    20df:      	movq	%rax, %rsi
    20e2:      	cmpl	$0x7f, %ebx
    20e5:      	movl	$0x7f, %eax
    20ea:      	cmovbl	%ebx, %eax
    20ed:      	shll	$0x3, %eax
    20f0:      	movl	%eax, (%rsi)
    20f2:      	movl	%ebx, %eax
    20f4:      	leal	-0x4(%rbx), %ecx
    20f7:      	movq	%rsi, %rdx
    20fa:      	addq	$0x7, %rdx
    20fe:      	leal	-0x3(%rbx), %edi
    2101:      	leal	-0x2(%rbx), %r8d
    2105:      	decl	%ebx
    2107:      	movq	$-0x3, %r9
    210e:      	nop
    2110:      	leal	(%rbx,%r9), %r10d
    2114:      	addl	$0x3, %r10d
    2118:      	andl	$0xfff, %r10d           # imm = 0xFFF
    211f:      	movzbl	(%r14,%r10), %r10d
    2124:      	movb	%r10b, -0x3(%rdx)
    2128:      	leaq	(%rax,%r9), %r10
    212c:      	cmpq	$-0x2, %r10
    2130:      	je	0x21a7 <filter_char_buf_postfix+0x127>
    2132:      	leal	(%r8,%r9), %r11d
    2136:      	addl	$0x3, %r11d
    213a:      	andl	$0xfff, %r11d           # imm = 0xFFF
    2141:      	movzbl	(%r14,%r11), %r11d
    2146:      	movb	%r11b, -0x2(%rdx)
    214a:      	cmpq	$-0x1, %r10
    214e:      	je	0x21a7 <filter_char_buf_postfix+0x127>
    2150:      	leal	(%rdi,%r9), %r10d
    2154:      	addl	$0x3, %r10d
    2158:      	andl	$0xfff, %r10d           # imm = 0xFFF
    215f:      	movzbl	(%r14,%r10), %r10d
    2164:      	movb	%r10b, -0x1(%rdx)
    2168:      	movq	%rax, %r10
    216b:      	addq	%r9, %r10
    216e:      	je	0x21a7 <filter_char_buf_postfix+0x127>
    2170:      	cmpq	$-0x7f, %r9
    2174:      	je	0x21a7 <filter_char_buf_postfix+0x127>
    2176:      	leal	(%rcx,%r9), %r10d
    217a:      	addl	$0x3, %r10d
    217e:      	andl	$0xfff, %r10d           # imm = 0xFFF
    2185:      	movzbl	(%r14,%r10), %r10d
    218a:      	movb	%r10b, (%rdx)
    218d:      	addq	$0x4, %rdx
    2191:      	leaq	(%rax,%r9), %r10
    2195:      	addq	$-0x4, %r10
    2199:      	addq	$-0x4, %r9
    219d:      	cmpq	$-0x3, %r10
    21a1:      	jne	0x2110 <filter_char_buf_postfix+0x90>
    21a7:      	movl	$0x1, %eax
    21ac:      	movq	%r15, %rdi
    21af:      	callq	*%rax
    21b1:      	movq	%rax, %rcx
    21b4:      	xorl	%eax, %eax
    21b6:      	testq	%rcx, %rcx
    21b9:      	setne	%al
    21bc:      	jmp	0x21c0 <filter_char_buf_postfix+0x140>
    21be:      	xorl	%eax, %eax
    21c0:      	addq	$0x10, %rsp
    21c4:      	popq	%rbx
    21c5:      	popq	%r14
    21c7:      	popq	%r15
    21c9:      	retq
    21ca:      	nopw	(%rax,%rax)

00000000000021d0 <filter_file_type>:
    21d0:      	pushq	%rbx
    21d1:      	subq	$0x10, %rsp
    21d5:      	movw	$0x0, 0xe(%rsp)
    21dc:      	movl	(%rsi), %eax
    21de:      	cmpq	$0x1000, %rax           # imm = 0x1000
    21e4:      	ja	0x226c <filter_file_type+0x9c>
    21ea:      	movq	%rdi, %rbx
    21ed:      	leaq	(%rsi,%rax), %rcx
    21f1:      	addq	$0x8, %rcx
    21f5:      	leaq	0xe(%rsp), %rdi
    21fa:      	movl	$0x2, %edx
    21ff:      	movl	$0x4, %eax
    2204:      	movl	(%rsi), %ecx
    2206:      	leaq	(%rsi,%rcx), %rdx
    220a:      	addq	$0x8, %rdx
    220e:      	movl	$0x2, %esi
    2213:      	callq	*%rax
    2215:      	movl	0x10(%rbx), %edx
    2218:      	testl	%edx, %edx
    221a:      	je	0x226c <filter_file_type+0x9c>
    221c:      	movzwl	0xe(%rsp), %ecx
    2221:      	andl	$0xf000, %ecx           # imm = 0xF000
    2227:      	movl	$0x1, %eax
    222c:      	cmpl	%ecx, %edx
    222e:      	je	0x226e <filter_file_type+0x9e>
    2230:      	movl	0x8(%rbx), %edx
    2233:      	cmpl	$0xc, %edx
    2236:      	jbe	0x226c <filter_file_type+0x9c>
    2238:      	movl	0x14(%rbx), %esi
    223b:      	testl	%esi, %esi
    223d:      	je	0x226c <filter_file_type+0x9c>
    223f:      	cmpl	%ecx, %esi
    2241:      	je	0x226e <filter_file_type+0x9e>
    2243:      	cmpl	$0x11, %edx
    2246:      	jb	0x226c <filter_file_type+0x9c>
    2248:      	movl	0x18(%rbx), %esi
    224b:      	testl	%esi, %esi
    224d:      	je	0x226c <filter_file_type+0x9c>
    224f:      	cmpl	%ecx, %esi
    2251:      	je	0x226e <filter_file_type+0x9e>
    2253:      	cmpl	$0x15, %edx
    2256:      	jb	0x226c <filter_file_type+0x9c>
    2258:      	movl	0x1c(%rbx), %edx
    225b:      	testl	%edx, %edx
    225d:      	je	0x226c <filter_file_type+0x9c>
    225f:      	xorl	%eax, %eax
    2261:      	cmpl	%ecx, %edx
    2263:      	sete	%al
    2266:      	addq	$0x10, %rsp
    226a:      	popq	%rbx
    226b:      	retq
    226c:      	xorl	%eax, %eax
    226e:      	addq	$0x10, %rsp
    2272:      	popq	%rbx
    2273:      	retq
    2274:      	nopw	%cs:(%rax,%rax)

0000000000002280 <filter_char_substring>:
    2280:      	pushq	%rbp
    2281:      	pushq	%r15
    2283:      	pushq	%r14
    2285:      	pushq	%r13
    2287:      	pushq	%r12
    2289:      	pushq	%rbx
    228a:      	pushq	%rax
    228b:      	movq	%rsi, %r15
    228e:      	movq	%rdi, %r14
    2291:      	movl	%edx, %ebp
    2293:      	testl	%ecx, %ecx
    2295:      	je	0x236d <filter_char_substring+0xed>
    229b:      	testl	%edx, %edx
    229d:      	je	0x241d <filter_char_substring+0x19d>
    22a3:      	leaq	0x4(%rsp), %r13
    22a8:      	xorl	%ebx, %ebx
    22aa:      	xorl	%r12d, %r12d
    22ad:      	nopl	(%rax)
    22b0:      	movl	0x10(%r14,%rbx,4), %eax
    22b5:      	movl	%eax, 0x4(%rsp)
    22b9:      	movl	$0x1, %eax
    22be:      	movq	(%rip), %rdi            # 0x22c5 <filter_char_substring+0x45>
    22c5:      	movq	%r13, %rsi
    22c8:      	callq	*%rax
    22ca:      	testq	%rax, %rax
    22cd:      	je	0x24b0 <filter_char_substring+0x230>
    22d3:      	movq	%r15, %rdx
    22d6:      	xorl	%ecx, %ecx
    22d8:      	jmp	0x22eb <filter_char_substring+0x6b>
    22da:      	nopw	(%rax,%rax)
    22e0:      	incq	%rcx
    22e3:      	incq	%rdx
    22e6:      	cmpq	%rbp, %rcx
    22e9:      	je	0x2348 <filter_char_substring+0xc8>
    22eb:      	xorl	%esi, %esi
    22ed:      	nopl	(%rax)
    22f0:      	leaq	(%rcx,%rsi), %rdi
    22f4:      	cmpq	%rbp, %rdi
    22f7:      	jae	0x22e0 <filter_char_substring+0x60>
    22f9:      	movsbl	(%rax,%rsi), %edi
    22fd:      	testl	%edi, %edi
    22ff:      	je	0x2340 <filter_char_substring+0xc0>
    2301:      	movsbl	(%rdx,%rsi), %r9d
    2306:      	leal	-0x41(%r9), %r10d
    230a:      	movl	%r9d, %r8d
    230d:      	orl	$0x20, %r8d
    2311:      	cmpl	$0x1a, %r10d
    2315:      	cmovael	%r9d, %r8d
    2319:      	leal	-0x41(%rdi), %r10d
    231d:      	movl	%edi, %r9d
    2320:      	orl	$0x20, %r9d
    2324:      	cmpl	$0x1a, %r10d
    2328:      	cmovael	%edi, %r9d
    232c:      	cmpq	$0x62, %rsi
    2330:      	ja	0x22e0 <filter_char_substring+0x60>
    2332:      	incq	%rsi
    2335:      	cmpl	%r9d, %r8d
    2338:      	je	0x22f0 <filter_char_substring+0x70>
    233a:      	jmp	0x22e0 <filter_char_substring+0x60>
    233c:      	nopl	(%rax)
    2340:      	testl	%ecx, %ecx
    2342:      	jns	0x24c1 <filter_char_substring+0x241>
    2348:      	leal	0xc(%r12), %eax
    234d:      	cmpl	0x8(%r14), %eax
    2351:      	jae	0x24b0 <filter_char_substring+0x230>
    2357:      	addl	$0x4, %r12d
    235b:      	incq	%rbx
    235e:      	cmpq	$0x64, %rbx
    2362:      	jne	0x22b0 <filter_char_substring+0x30>
    2368:      	jmp	0x24b0 <filter_char_substring+0x230>
    236d:      	testl	%edx, %edx
    236f:      	je	0x2462 <filter_char_substring+0x1e2>
    2375:      	leaq	0x4(%rsp), %r13
    237a:      	xorl	%ebx, %ebx
    237c:      	xorl	%r12d, %r12d
    237f:      	nop
    2380:      	movl	0x10(%r14,%rbx,4), %eax
    2385:      	movl	%eax, 0x4(%rsp)
    2389:      	movl	$0x1, %eax
    238e:      	movq	(%rip), %rdi            # 0x2395 <filter_char_substring+0x115>
    2395:      	movq	%r13, %rsi
    2398:      	callq	*%rax
    239a:      	testq	%rax, %rax
    239d:      	je	0x24b0 <filter_char_substring+0x230>
    23a3:      	movq	%r15, %rdx
    23a6:      	xorl	%ecx, %ecx
    23a8:      	jmp	0x23bb <filter_char_substring+0x13b>
    23aa:      	nopw	(%rax,%rax)
    23b0:      	incq	%rcx
    23b3:      	incq	%rdx
    23b6:      	cmpq	%rbp, %rcx
    23b9:      	je	0x23f8 <filter_char_substring+0x178>
    23bb:      	xorl	%esi, %esi
    23bd:      	nopl	(%rax)
    23c0:      	leaq	(%rcx,%rsi), %rdi
    23c4:      	cmpq	%rbp, %rdi
    23c7:      	jae	0x23b0 <filter_char_substring+0x130>
    23c9:      	movzbl	(%rax,%rsi), %edi
    23cd:      	testb	%dil, %dil
    23d0:      	je	0x23f0 <filter_char_substring+0x170>
    23d2:      	cmpq	$0x62, %rsi
    23d6:      	ja	0x23b0 <filter_char_substring+0x130>
    23d8:      	leaq	0x1(%rsi), %r8
    23dc:      	cmpb	%dil, (%rdx,%rsi)
    23e0:      	movq	%r8, %rsi
    23e3:      	je	0x23c0 <filter_char_substring+0x140>
    23e5:      	jmp	0x23b0 <filter_char_substring+0x130>
    23e7:      	nopw	(%rax,%rax)
    23f0:      	testl	%ecx, %ecx
    23f2:      	jns	0x24c1 <filter_char_substring+0x241>
    23f8:      	leal	0xc(%r12), %eax
    23fd:      	cmpl	0x8(%r14), %eax
    2401:      	jae	0x24b0 <filter_char_substring+0x230>
    2407:      	addl	$0x4, %r12d
    240b:      	incq	%rbx
    240e:      	cmpq	$0x64, %rbx
    2412:      	jne	0x2380 <filter_char_substring+0x100>
    2418:      	jmp	0x24b0 <filter_char_substring+0x230>
    241d:      	movl	$0x10, %ebx
    2422:      	movq	(%rip), %r15            # 0x2429 <filter_char_substring+0x1a9>
    2429:      	leaq	0x4(%rsp), %r12
    242e:      	nop
    2430:      	movl	(%r14,%rbx), %eax
    2434:      	movl	%eax, 0x4(%rsp)
    2438:      	movl	$0x1, %eax
    243d:      	movq	%r15, %rdi
    2440:      	movq	%r12, %rsi
    2443:      	callq	*%rax
    2445:      	testq	%rax, %rax
    2448:      	je	0x24b0 <filter_char_substring+0x230>
    244a:      	addq	$0x4, %rbx
    244e:      	leal	-0x8(%rbx), %eax
    2451:      	cmpl	0x8(%r14), %eax
    2455:      	jae	0x24b0 <filter_char_substring+0x230>
    2457:      	cmpq	$0x1a0, %rbx            # imm = 0x1A0
    245e:      	jne	0x2430 <filter_char_substring+0x1b0>
    2460:      	jmp	0x24b0 <filter_char_substring+0x230>
    2462:      	movl	$0x10, %ebx
    2467:      	movq	(%rip), %r15            # 0x246e <filter_char_substring+0x1ee>
    246e:      	leaq	0x4(%rsp), %r12
    2473:      	nopw	%cs:(%rax,%rax)
    2480:      	movl	(%r14,%rbx), %eax
    2484:      	movl	%eax, 0x4(%rsp)
    2488:      	movl	$0x1, %eax
    248d:      	movq	%r15, %rdi
    2490:      	movq	%r12, %rsi
    2493:      	callq	*%rax
    2495:      	testq	%rax, %rax
    2498:      	je	0x24b0 <filter_char_substring+0x230>
    249a:      	addq	$0x4, %rbx
    249e:      	leal	-0x8(%rbx), %eax
    24a1:      	cmpl	0x8(%r14), %eax
    24a5:      	jae	0x24b0 <filter_char_substring+0x230>
    24a7:      	cmpq	$0x1a0, %rbx            # imm = 0x1A0
    24ae:      	jne	0x2480 <filter_char_substring+0x200>
    24b0:      	xorl	%eax, %eax
    24b2:      	addq	$0x8, %rsp
    24b6:      	popq	%rbx
    24b7:      	popq	%r12
    24b9:      	popq	%r13
    24bb:      	popq	%r14
    24bd:      	popq	%r15
    24bf:      	popq	%rbp
    24c0:      	retq
    24c1:      	movl	$0x1, %eax
    24c6:      	jmp	0x24b2 <filter_char_substring+0x232>
    24c8:      	nopl	(%rax,%rax)

00000000000024d0 <do_action>:
    24d0:      	pushq	%rbp
    24d1:      	pushq	%r15
    24d3:      	pushq	%r14
    24d5:      	pushq	%r13
    24d7:      	pushq	%r12
    24d9:      	pushq	%rbx
    24da:      	subq	$0x78, %rsp
    24de:      	movl	%r8d, %ebp
    24e1:      	movq	%rcx, 0x38(%rsp)
    24e6:      	movq	%rdx, %r15
    24e9:      	movl	%esi, %ebx
    24eb:      	movq	%rdi, %r14
    24ee:      	movl	%esi, %eax
    24f0:      	movslq	0x4(%rdx,%rax,4), %r12
    24f5:      	movl	$0x0, 0x50(%rsp)
    24fd:      	movq	(%rip), %rdi            # 0x2504 <do_action+0x34>
    2504:      	leaq	0x50(%rsp), %rsi
    2509:      	movl	$0x1, %eax
    250e:      	callq	*%rax
    2510:      	movq	%rax, %r13
    2513:      	xorl	%eax, %eax
    2515:      	testq	%r13, %r13
    2518:      	je	0x2d30 <do_action+0x860>
    251e:      	cmpl	$0x7, %r12d
    2522:      	jg	0x254c <do_action+0x7c>
    2524:      	cmpl	$0x3, %r12d
    2528:      	jg	0x2584 <do_action+0xb4>
    252a:      	cmpl	$0x1, %r12d
    252e:      	jg	0x26b7 <do_action+0x1e7>
    2534:      	testl	%r12d, %r12d
    2537:      	je	0x295c <do_action+0x48c>
    253d:      	cmpl	$0x1, %r12d
    2541:      	je	0x26d0 <do_action+0x200>
    2547:      	jmp	0x2d28 <do_action+0x858>
    254c:      	cmpl	$0xb, %r12d
    2550:      	jg	0x2689 <do_action+0x1b9>
    2556:      	leal	-0xa(%r12), %ecx
    255b:      	cmpl	$0x2, %ecx
    255e:      	jb	0x27db <do_action+0x30b>
    2564:      	cmpl	$0x8, %r12d
    2568:      	je	0x28c8 <do_action+0x3f8>
    256e:      	cmpl	$0x9, %r12d
    2572:      	jne	0x2d28 <do_action+0x858>
    2578:      	incl	%ebx
    257a:      	movl	0x4(%r15,%rbx,4), %eax
    257f:      	jmp	0x2894 <do_action+0x3c4>
    2584:      	leal	-0x6(%r12), %eax
    2589:      	cmpl	$0x2, %eax
    258c:      	jb	0x28b8 <do_action+0x3e8>
    2592:      	cmpl	$0x4, %r12d
    2596:      	je	0x28d5 <do_action+0x405>
    259c:      	cmpl	$0x5, %r12d
    25a0:      	jne	0x2d28 <do_action+0x858>
    25a6:      	leal	0x1(%rbx), %eax
    25a9:      	movl	0x4(%r15,%rax,4), %eax
    25ae:      	addl	$0x2, %ebx
    25b1:      	andl	$0x7, %eax
    25b4:      	cmpl	$0x4, %eax
    25b7:      	ja	0x2d28 <do_action+0x858>
    25bd:      	cmpl	$0x0, 0x5ea0(%r13,%rax,4)
    25c6:      	jne	0x2d28 <do_action+0x858>
    25cc:      	movl	0x4(%r15,%rbx,4), %r14d
    25d1:      	movq	0x5e78(%r13,%rax,8), %rax
    25d9:      	movl	$0x0, 0xc(%rsp)
    25e1:      	andl	$0x7ff, %eax            # imm = 0x7FF
    25e6:      	movl	0x90(%r13,%rax), %eax
    25ee:      	movl	%eax, 0x8(%rsp)
    25f2:      	movl	$0xe, %eax
    25f7:      	callq	*%rax
    25f9:      	shrq	$0x20, %rax
    25fd:      	movq	%rax, (%rsp)
    2601:      	movq	(%rip), %rdi            # 0x2608 <do_action+0x138>
    2608:      	movq	%rsp, %rsi
    260b:      	movl	$0x1, %eax
    2610:      	callq	*%rax
    2612:      	testq	%rax, %rax
    2615:      	je	0x2d28 <do_action+0x858>
    261b:      	andl	$0x7, %r14d
    261f:      	cmpl	$0x4, %r14d
    2623:      	ja	0x2d28 <do_action+0x858>
    2629:      	cmpl	$0x0, 0x5ea0(%r13,%r14,4)
    2632:      	jne	0x2d28 <do_action+0x858>
    2638:      	movq	0x5e78(%r13,%r14,8), %rcx
    2640:      	movl	$0x0, 0xc(%rsp)
    2648:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    264e:      	movl	0x90(%r13,%rcx), %ecx
    2656:      	movl	%ecx, 0x8(%rsp)
    265a:      	movq	%rax, %r15
    265d:      	movl	$0xe, %eax
    2662:      	callq	*%rax
    2664:      	shrq	$0x20, %rax
    2668:      	movq	%rax, (%rsp)
    266c:      	movq	(%rip), %rdi            # 0x2673 <do_action+0x1a3>
    2673:      	xorl	%ecx, %ecx
    2675:      	movq	%rsp, %rsi
    2678:      	movl	$0x2, %eax
    267d:      	movq	%r15, %rdx
    2680:      	xorl	%ecx, %ecx
    2682:      	callq	*%rax
    2684:      	jmp	0x2d28 <do_action+0x858>
    2689:      	cmpl	$0xc, %r12d
    268d:      	je	0x2a18 <do_action+0x548>
    2693:      	cmpl	$0xd, %r12d
    2697:      	je	0x28e4 <do_action+0x414>
    269d:      	cmpl	$0xe, %r12d
    26a1:      	jne	0x2d28 <do_action+0x858>
    26a7:      	addl	$0x2, %ebx
    26aa:      	movzbl	%bpl, %r14d
    26ae:      	xorq	$0x9, %r14
    26b2:      	jmp	0x2a23 <do_action+0x553>
    26b7:      	movl	$0x9, %eax
    26bc:      	cmpl	$0x2, %r12d
    26c0:      	je	0x2894 <do_action+0x3c4>
    26c6:      	cmpl	$0x3, %r12d
    26ca:      	jne	0x2d28 <do_action+0x858>
    26d0:      	leal	0x1(%rbx), %eax
    26d3:      	movl	0x4(%r15,%rax,4), %ebp
    26d8:      	addl	$0x2, %ebx
    26db:      	movl	0x4(%r15,%rbx,4), %r14d
    26e0:      	movl	$0x0, 0x10(%rsp)
    26e8:      	movq	(%rip), %rdi            # 0x26ef <do_action+0x21f>
    26ef:      	leaq	0x10(%rsp), %rsi
    26f4:      	movl	$0x1, %eax
    26f9:      	callq	*%rax
    26fb:      	xorl	%r15d, %r15d
    26fe:      	testq	%rax, %rax
    2701:      	je	0x2adb <do_action+0x60b>
    2707:      	movq	%rax, 0x38(%rsp)
    270c:      	andl	$0x7, %ebp
    270f:      	cmpl	$0x4, %ebp
    2712:      	movl	$0x0, %eax
    2717:      	ja	0x2add <do_action+0x60d>
    271d:      	cmpl	$0x0, 0x5ea0(%r13,%rbp,4)
    2726:      	jne	0x2add <do_action+0x60d>
    272c:      	movq	0x5e78(%r13,%rbp,8), %rax
    2734:      	movl	$0x0, 0xc(%rsp)
    273c:      	andl	$0x7ff, %eax            # imm = 0x7FF
    2741:      	movl	0x90(%r13,%rax), %eax
    2749:      	movl	%eax, 0x8(%rsp)
    274d:      	movl	$0xe, %eax
    2752:      	callq	*%rax
    2754:      	shrq	$0x20, %rax
    2758:      	movq	%rax, (%rsp)
    275c:      	cmpl	$0x1, %r12d
    2760:      	jne	0x2ab4 <do_action+0x5e4>
    2766:      	andl	$0x7, %r14d
    276a:      	cmpl	$0x4, %r14d
    276e:      	ja	0x2adb <do_action+0x60b>
    2774:      	cmpl	$0x0, 0x5ea0(%r13,%r14,4)
    277d:      	movl	$0x0, %eax
    2782:      	jne	0x2add <do_action+0x60d>
    2788:      	movq	0x5e78(%r13,%r14,8), %rax
    2790:      	andl	$0x7ff, %eax            # imm = 0x7FF
    2795:      	leaq	(%rax,%r13), %rdx
    2799:      	addq	$0x90, %rdx
    27a0:      	movl	0x90(%r13,%rax), %esi
    27a8:      	andl	$0xfff, %esi            # imm = 0xFFF
    27ae:      	addq	$0x8, %rsi
    27b2:      	movl	$0x4, %eax
    27b7:      	movq	0x38(%rsp), %r14
    27bc:      	movq	%r14, %rdi
    27bf:      	callq	*%rax
    27c1:      	movq	(%rip), %rdi            # 0x27c8 <do_action+0x2f8>
    27c8:      	xorl	%r15d, %r15d
    27cb:      	movq	%rsp, %rsi
    27ce:      	movl	$0x2, %eax
    27d3:      	movq	%r14, %rdx
    27d6:      	jmp	0x288b <do_action+0x3bb>
    27db:      	incl	%ebx
    27dd:      	movl	0x4(%r15,%rbx,4), %ecx
    27e2:      	andl	$0x7, %ecx
    27e5:      	xorl	%r15d, %r15d
    27e8:      	cmpl	$0x4, %ecx
    27eb:      	ja	0x2add <do_action+0x60d>
    27f1:      	cmpl	$0x0, 0x5ea0(%r13,%rcx,4)
    27fa:      	jne	0x2add <do_action+0x60d>
    2800:      	movq	0x5e78(%r13,%rcx,8), %rcx
    2808:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    280e:      	movq	0xb8(%r13,%rcx), %rcx
    2816:      	movq	%rcx, 0x10(%rsp)
    281b:      	testq	%rcx, %rcx
    281e:      	je	0x2add <do_action+0x60d>
    2824:      	cmpl	$0xa, %r12d
    2828:      	jne	0x2ac5 <do_action+0x5f5>
    282e:      	movl	$0xe, %eax
    2833:      	callq	*%rax
    2835:      	movq	%rax, %r14
    2838:      	shrq	$0x20, %rax
    283c:      	movl	%eax, (%rsp)
    283f:      	movq	(%rip), %rdi            # 0x2846 <do_action+0x376>
    2846:      	movq	%rsp, %rsi
    2849:      	movl	$0x1, %eax
    284e:      	callq	*%rax
    2850:      	movq	%rax, %rcx
    2853:      	testq	%rax, %rax
    2856:      	movl	$0x0, %eax
    285b:      	je	0x2add <do_action+0x60d>
    2861:      	movl	(%rcx), %eax
    2863:      	movl	%eax, (%rsp)
    2866:      	movl	%r14d, 0x4(%rsp)
    286b:      	movq	0x8(%rcx), %rax
    286f:      	movq	%rax, 0x8(%rsp)
    2874:      	movq	(%rip), %rdi            # 0x287b <do_action+0x3ab>
    287b:      	xorl	%r15d, %r15d
    287e:      	leaq	0x10(%rsp), %rsi
    2883:      	movq	%rsp, %rdx
    2886:      	movl	$0x2, %eax
    288b:      	xorl	%ecx, %ecx
    288d:      	callq	*%rax
    288f:      	jmp	0x2adb <do_action+0x60b>
    2894:      	movl	$0x3, %r14d
    289a:      	testb	%bpl, %bpl
    289d:      	je	0x2a23 <do_action+0x553>
    28a3:      	movslq	%eax, %rdi
    28a6:      	movl	$0x6d, %eax
    28ab:      	callq	*%rax
    28ad:      	movl	$0x2, %r14d
    28b3:      	jmp	0x2a23 <do_action+0x553>
    28b8:      	incl	%ebx
    28ba:      	movl	0x4(%r15,%rbx,4), %eax
    28bf:      	movl	%eax, 0x78(%r13)
    28c3:      	jmp	0x2d28 <do_action+0x858>
    28c8:      	movq	0x38(%rsp), %rax
    28cd:      	movb	$0x0, (%rax)
    28d0:      	jmp	0x2d28 <do_action+0x858>
    28d5:      	incl	%ebx
    28d7:      	movzbl	%bpl, %r14d
    28db:      	xorq	$0x5, %r14
    28df:      	jmp	0x2a23 <do_action+0x553>
    28e4:      	movl	$0xe, %eax
    28e9:      	callq	*%rax
    28eb:      	movq	%rax, 0x20(%rsp)
    28f0:      	movq	(%rip), %rdi            # 0x28f7 <do_action+0x427>
    28f7:      	leaq	0x20(%rsp), %rsi
    28fc:      	movl	$0x1, %eax
    2901:      	callq	*%rax
    2903:      	testq	%rax, %rax
    2906:      	je	0x2d28 <do_action+0x858>
    290c:      	movq	0x4(%rax), %rax
    2910:      	movq	%rax, 0x10(%rsp)
    2915:      	movl	$0x2, 0x18(%rsp)
    291d:      	movq	(%rip), %rdi            # 0x2924 <do_action+0x454>
    2924:      	leaq	0x10(%rsp), %rsi
    2929:      	movl	$0x1, %eax
    292e:      	callq	*%rax
    2930:      	movl	$0x1, 0x2c(%rsp)
    2938:      	testq	%rax, %rax
    293b:      	je	0x2a4e <do_action+0x57e>
    2941:      	lock
    2942:      	incl	(%rax)
    2944:      	movq	(%rip), %rdi            # 0x294b <do_action+0x47b>
    294b:      	leaq	0x20(%rsp), %rsi
    2950:      	movl	$0x3, %eax
    2955:      	callq	*%rax
    2957:      	jmp	0x2d28 <do_action+0x858>
    295c:      	leal	0x1(%rbx), %eax
    295f:      	movl	0x4(%r15,%rax,4), %ebp
    2964:      	leal	0x2(%rbx), %eax
    2967:      	movl	0x4(%r15,%rax,4), %eax
    296c:      	movl	%eax, 0x30(%rsp)
    2970:      	movl	$0x7d, %eax
    2975:      	callq	*%rax
    2977:      	movq	%rax, 0x68(%rsp)
    297c:      	movq	%rax, (%rsp)
    2980:      	movl	$0x0, 0x20(%rsp)
    2988:      	movq	%rbp, 0x70(%rsp)
    298d:      	testq	%rbp, %rbp
    2990:      	je	0x2cba <do_action+0x7ea>
    2996:      	movq	(%rip), %rdi            # 0x299d <do_action+0x4cd>
    299d:      	leaq	0x20(%rsp), %rsi
    29a2:      	movl	$0x1, %eax
    29a7:      	callq	*%rax
    29a9:      	testq	%rax, %rax
    29ac:      	je	0x2cba <do_action+0x7ea>
    29b2:      	movq	%rax, 0x48(%rsp)
    29b7:      	movq	%rax, %rbp
    29ba:      	movq	(%rip), %rdi            # 0x29c1 <do_action+0x4f1>
    29c1:      	leaq	0x20(%rsp), %rsi
    29c6:      	movl	$0x1, %eax
    29cb:      	callq	*%rax
    29cd:      	movq	%rax, %rdx
    29d0:      	movq	0x60(%r13), %rax
    29d4:      	movq	%rax, (%rbp)
    29d8:      	movq	0x70(%r13), %rax
    29dc:      	movq	%rbp, 0x40(%rsp)
    29e1:      	movq	%rax, 0x8(%rbp)
    29e5:      	xorl	%eax, %eax
    29e7:      	movq	%rax, 0x60(%rsp)
    29ec:      	movl	$0x0, %eax
    29f1:      	movl	0x30(%rsp), %ecx
    29f5:      	cmpl	$0x2, %ecx
    29f8:      	je	0x2aef <do_action+0x61f>
    29fe:      	cmpl	$0x1, %ecx
    2a01:      	je	0x2aeb <do_action+0x61b>
    2a07:      	testl	%ecx, %ecx
    2a09:      	jne	0x2cba <do_action+0x7ea>
    2a0f:      	movl	0x7c(%r13), %eax
    2a13:      	jmp	0x2aef <do_action+0x61f>
    2a18:      	addl	$0x3, %ebx
    2a1b:      	movzbl	%bpl, %r14d
    2a1f:      	xorq	$0x7, %r14
    2a23:      	movl	$0x0, (%rsp)
    2a2a:      	movq	(%rip), %rdi            # 0x2a31 <do_action+0x561>
    2a31:      	movq	%rsp, %rsi
    2a34:      	movl	$0x1, %eax
    2a39:      	callq	*%rax
    2a3b:      	testq	%rax, %rax
    2a3e:      	je	0x2d28 <do_action+0x858>
    2a44:      	lock
    2a45:      	incq	(%rax,%r14,8)
    2a49:      	jmp	0x2d28 <do_action+0x858>
    2a4e:      	movq	(%rip), %rdi            # 0x2a55 <do_action+0x585>
    2a55:      	leaq	0x10(%rsp), %rsi
    2a5a:      	leaq	0x2c(%rsp), %rdx
    2a5f:      	movl	$0x1, %ecx
    2a64:      	movl	$0x2, %eax
    2a69:      	callq	*%rax
    2a6b:      	testq	%rax, %rax
    2a6e:      	je	0x2944 <do_action+0x474>
    2a74:      	movq	%rax, %r15
    2a77:      	negl	%eax
    2a79:      	movw	%ax, (%rsp)
    2a7d:      	movw	$0x3, 0x2(%rsp)
    2a84:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    2a8e:      	movq	%rax, 0x4(%rsp)
    2a93:      	movq	(%rip), %rdi            # 0x2a9a <do_action+0x5ca>
    2a9a:      	movq	%rsp, %rsi
    2a9d:      	movl	$0x1, %eax
    2aa2:      	callq	*%rax
    2aa4:      	testq	%rax, %rax
    2aa7:      	je	0x2d3f <do_action+0x86f>
    2aad:      	incl	(%rax)
    2aaf:      	jmp	0x2d61 <do_action+0x891>
    2ab4:      	movq	(%rip), %rdi            # 0x2abb <do_action+0x5eb>
    2abb:      	movq	%rsp, %rsi
    2abe:      	movl	$0x3, %eax
    2ac3:      	jmp	0x2ad6 <do_action+0x606>
    2ac5:      	movq	(%rip), %rdi            # 0x2acc <do_action+0x5fc>
    2acc:      	leaq	0x10(%rsp), %rsi
    2ad1:      	movl	$0x3, %eax
    2ad6:      	callq	*%rax
    2ad8:      	movq	%rax, %r15
    2adb:      	xorl	%eax, %eax
    2add:      	testl	%r15d, %r15d
    2ae0:      	jne	0x2d30 <do_action+0x860>
    2ae6:      	jmp	0x2d28 <do_action+0x858>
    2aeb:      	movl	0x10(%r13), %eax
    2aef:      	movq	%r14, 0x30(%rsp)
    2af4:      	movl	%eax, %eax
    2af6:      	movq	0x40(%rsp), %rcx
    2afb:      	movq	%rax, 0x10(%rcx)
    2aff:      	movq	0x48(%rsp), %rdi
    2b04:      	addq	$0x18, %rdi
    2b08:      	movl	$0xc8, %ecx
    2b0d:      	movl	$0x4, %eax
    2b12:      	movq	%rdi, 0x48(%rsp)
    2b17:      	movl	$0xc8, %esi
    2b1c:      	callq	*%rax
    2b1e:      	xorl	%r14d, %r14d
    2b21:      	movq	%r13, 0x58(%rsp)
    2b26:      	jmp	0x2b36 <do_action+0x666>
    2b28:      	addq	$0x4, %r14
    2b2c:      	cmpq	$0x14, %r14
    2b30:      	je	0x2c63 <do_action+0x793>
    2b36:      	movl	$0x0, 0x10(%rsp)
    2b3e:      	movl	$0x1, %eax
    2b43:      	movq	(%rip), %rdi            # 0x2b4a <do_action+0x67a>
    2b4a:      	leaq	0x10(%rsp), %rsi
    2b4f:      	callq	*%rax
    2b51:      	testq	%rax, %rax
    2b54:      	je	0x2c63 <do_action+0x793>
    2b5a:      	movq	%rax, %rsi
    2b5d:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    2b64:      	movl	$0x1, %eax
    2b69:      	movq	(%rip), %rdi            # 0x2b70 <do_action+0x6a0>
    2b70:      	callq	*%rax
    2b72:      	testq	%rax, %rax
    2b75:      	je	0x2c63 <do_action+0x793>
    2b7b:      	cmpl	$-0x1, 0x40(%rax,%r14)
    2b81:      	je	0x2c63 <do_action+0x793>
    2b87:      	movq	0x5e78(%r13,%r14,2), %rax
    2b8f:      	movl	0x4(%r13), %ecx
    2b93:      	cmpq	%rcx, %rax
    2b96:      	jge	0x2c63 <do_action+0x793>
    2b9c:      	cmpq	$0x10, %r14
    2ba0:      	je	0x2c03 <do_action+0x733>
    2ba2:      	movl	$0x0, 0x10(%rsp)
    2baa:      	movl	$0x1, %eax
    2baf:      	movq	(%rip), %rdi            # 0x2bb6 <do_action+0x6e6>
    2bb6:      	leaq	0x10(%rsp), %rsi
    2bbb:      	callq	*%rax
    2bbd:      	testq	%rax, %rax
    2bc0:      	je	0x2bfb <do_action+0x72b>
    2bc2:      	movq	%rax, %rsi
    2bc5:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    2bcc:      	movl	$0x1, %eax
    2bd1:      	movq	(%rip), %rdi            # 0x2bd8 <do_action+0x708>
    2bd8:      	callq	*%rax
    2bda:      	testq	%rax, %rax
    2bdd:      	je	0x2bfb <do_action+0x72b>
    2bdf:      	cmpl	$-0x1, 0x44(%rax,%r14)
    2be5:      	movq	0x5e78(%r13,%r14,2), %rax
    2bed:      	je	0x2c03 <do_action+0x733>
    2bef:      	movl	0x5e80(%r13,%r14,2), %ebp
    2bf7:      	subl	%eax, %ebp
    2bf9:      	jmp	0x2c0c <do_action+0x73c>
    2bfb:      	movq	0x5e78(%r13,%r14,2), %rax
    2c03:      	movl	0x4(%r13), %ebp
    2c07:      	subl	%eax, %ebp
    2c09:      	addl	$0x4, %ebp
    2c0c:      	testl	%ebp, %ebp
    2c0e:      	jle	0x2b28 <do_action+0x658>
    2c14:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    2c19:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    2c1e:      	cmpl	$0x28, %ebp
    2c21:      	movl	$0x28, %ecx
    2c26:      	cmovgel	%ecx, %ebp
    2c29:      	movzbl	0x60(%rsp), %r13d
    2c2f:      	movq	0x48(%rsp), %rcx
    2c34:      	leaq	(%rcx,%r13), %rdi
    2c38:      	movq	0x58(%rsp), %rcx
    2c3d:      	leaq	(%rcx,%rax), %rdx
    2c41:      	addq	$0x90, %rdx
    2c48:      	movl	$0x4, %eax
    2c4d:      	movl	%ebp, %esi
    2c4f:      	callq	*%rax
    2c51:      	addl	%r13d, %ebp
    2c54:      	movq	0x58(%rsp), %r13
    2c59:      	movq	%rbp, 0x60(%rsp)
    2c5e:      	jmp	0x2b28 <do_action+0x658>
    2c63:      	movq	(%rip), %rdi            # 0x2c6a <do_action+0x79a>
    2c6a:      	movl	$0x1, %eax
    2c6f:      	movq	0x40(%rsp), %rsi
    2c74:      	callq	*%rax
    2c76:      	testq	%rax, %rax
    2c79:      	je	0x2c9b <do_action+0x7cb>
    2c7b:      	imulq	$-0xf4240, 0x70(%rsp), %rcx # imm = 0xFFF0BDC0
    2c84:      	movq	0x68(%rsp), %rdx
    2c89:      	addq	%rcx, %rdx
    2c8c:      	cmpq	%rdx, (%rax)
    2c8f:      	jbe	0x2c9b <do_action+0x7cb>
    2c91:      	movq	0x38(%rsp), %rax
    2c96:      	movb	$0x0, (%rax)
    2c99:      	jmp	0x2cb5 <do_action+0x7e5>
    2c9b:      	movq	(%rip), %rdi            # 0x2ca2 <do_action+0x7d2>
    2ca2:      	xorl	%ecx, %ecx
    2ca4:      	movq	%rsp, %rdx
    2ca7:      	movl	$0x2, %eax
    2cac:      	movq	0x40(%rsp), %rsi
    2cb1:      	xorl	%ecx, %ecx
    2cb3:      	callq	*%rax
    2cb5:      	movq	0x30(%rsp), %r14
    2cba:      	leal	0x3(%rbx), %eax
    2cbd:      	cmpl	$0x0, 0x4(%r15,%rax,4)
    2cc3:      	je	0x2ce6 <do_action+0x816>
    2cc5:      	orb	$0x2, 0x1(%r13)
    2cca:      	movq	(%rip), %rsi            # 0x2cd1 <do_action+0x801>
    2cd1:      	xorl	%ecx, %ecx
    2cd3:      	movl	$0x1b, %eax
    2cd8:      	movq	%r14, %rdi
    2cdb:      	xorl	%edx, %edx
    2cdd:      	callq	*%rax
    2cdf:      	movq	%rax, 0x80(%r13)
    2ce6:      	leal	0x4(%rbx), %eax
    2ce9:      	cmpl	$0x0, 0x4(%r15,%rax,4)
    2cef:      	je	0x2d18 <do_action+0x848>
    2cf1:      	orb	$0x4, 0x1(%r13)
    2cf6:      	movq	(%rip), %rsi            # 0x2cfd <do_action+0x82d>
    2cfd:      	movl	$0x100, %ecx            # imm = 0x100
    2d02:      	movl	$0x1b, %eax
    2d07:      	movl	$0x100, %edx            # imm = 0x100
    2d0c:      	movq	%r14, %rdi
    2d0f:      	callq	*%rax
    2d11:      	movq	%rax, 0x88(%r13)
    2d18:      	addl	$0x5, %ebx
    2d1b:      	cmpl	$0x0, 0x4(%r15,%rbx,4)
    2d21:      	je	0x2d28 <do_action+0x858>
    2d23:      	orb	$0x8, 0x1(%r13)
    2d28:      	movq	%r12, 0x70(%r13)
    2d2c:      	incl	%ebx
    2d2e:      	movl	%ebx, %eax
    2d30:      	addq	$0x78, %rsp
    2d34:      	popq	%rbx
    2d35:      	popq	%r12
    2d37:      	popq	%r13
    2d39:      	popq	%r14
    2d3b:      	popq	%r15
    2d3d:      	popq	%rbp
    2d3e:      	retq
    2d3f:      	movl	$0x1, 0x54(%rsp)
    2d47:      	movq	(%rip), %rdi            # 0x2d4e <do_action+0x87e>
    2d4e:      	xorl	%ecx, %ecx
    2d50:      	movq	%rsp, %rsi
    2d53:      	leaq	0x54(%rsp), %rdx
    2d58:      	movl	$0x2, %eax
    2d5d:      	xorl	%ecx, %ecx
    2d5f:      	callq	*%rax
    2d61:      	testl	%r15d, %r15d
    2d64:      	je	0x2944 <do_action+0x474>
    2d6a:      	movq	(%rip), %rdi            # 0x2d71 <do_action+0x8a1>
    2d71:      	leaq	0x10(%rsp), %rsi
    2d76:      	movl	$0x1, %eax
    2d7b:      	callq	*%rax
    2d7d:      	testq	%rax, %rax
    2d80:      	je	0x2944 <do_action+0x474>
    2d86:      	movl	0x2c(%rsp), %ecx
    2d8a:      	lock
    2d8b:      	addl	%ecx, (%rax)
    2d8d:      	jmp	0x2944 <do_action+0x474>

Disassembly of section fentry/generic_fentry_tail:

0000000000000000 <generic_fentry_setup_event>:
       0:      	pushq	%r15
       2:      	pushq	%r14
       4:      	pushq	%r12
       6:      	pushq	%rbx
       7:      	subq	$0x48, %rsp
       b:      	movq	%rdi, %rbx
       e:      	movl	$0x0, 0x24(%rsp)
      16:      	movq	(%rip), %rdi            # 0x1d <generic_fentry_setup_event+0x1d>
      1d:      	leaq	0x24(%rsp), %rsi
      22:      	movl	$0x1, %eax
      27:      	callq	*%rax
      29:      	testq	%rax, %rax
      2c:      	je	0x394 <generic_fentry_setup_event+0x394>
      32:      	movq	%rax, %r14
      35:      	leaq	0x5ef8(%rax), %rsi
      3c:      	movq	(%rip), %rdi            # 0x43 <generic_fentry_setup_event+0x43>
      43:      	movl	$0x1, %eax
      48:      	callq	*%rax
      4a:      	testq	%rax, %rax
      4d:      	je	0x394 <generic_fentry_setup_event+0x394>
      53:      	movq	%rax, %r15
      56:      	cmpl	$0x0, 0x54(%rax)
      5a:      	je	0x143 <generic_fentry_setup_event+0x143>
      60:      	leaq	0x8(%rsp), %rdi
      65:      	movl	$0x8, %ecx
      6a:      	movl	$0x4, %eax
      6f:      	movl	$0x8, %esi
      74:      	movq	%rbx, %rdx
      77:      	callq	*%rax
      79:      	movq	0x8(%rsp), %r12
      7e:      	testq	%r12, %r12
      81:      	je	0x394 <generic_fentry_setup_event+0x394>
      87:      	leaq	0x70(%r12), %rdx
      8c:      	leaq	0x8(%rsp), %rdi
      91:      	movl	$0x8, %ecx
      96:      	movl	$0x4, %eax
      9b:      	movl	$0x8, %esi
      a0:      	callq	*%rax
      a2:      	movq	0x8(%rsp), %rax
      a7:      	movq	%rax, 0x5e50(%r14)
      ae:      	leaq	0x68(%r12), %rdx
      b3:      	leaq	0x8(%rsp), %rdi
      b8:      	movl	$0x8, %ecx
      bd:      	movl	$0x4, %eax
      c2:      	movl	$0x8, %esi
      c7:      	callq	*%rax
      c9:      	movq	0x8(%rsp), %rax
      ce:      	movq	%rax, 0x5e58(%r14)
      d5:      	leaq	0x60(%r12), %rdx
      da:      	leaq	0x8(%rsp), %rdi
      df:      	movl	$0x8, %ecx
      e4:      	movl	$0x4, %eax
      e9:      	movl	$0x8, %esi
      ee:      	callq	*%rax
      f0:      	movq	0x8(%rsp), %rax
      f5:      	movq	%rax, 0x5e60(%r14)
      fc:      	leaq	0x38(%r12), %rdx
     101:      	leaq	0x8(%rsp), %rdi
     106:      	movl	$0x8, %ecx
     10b:      	movl	$0x4, %eax
     110:      	movl	$0x8, %esi
     115:      	callq	*%rax
     117:      	movq	0x8(%rsp), %rax
     11c:      	movq	%rax, 0x5e68(%r14)
     123:      	addq	$0x48, %r12
     127:      	leaq	0x8(%rsp), %rdi
     12c:      	movl	$0x8, %ecx
     131:      	movl	$0x4, %eax
     136:      	movl	$0x8, %esi
     13b:      	movq	%r12, %rdx
     13e:      	jmp	0x1f2 <generic_fentry_setup_event+0x1f2>
     143:      	leaq	0x8(%rsp), %rdi
     148:      	movl	$0x8, %ecx
     14d:      	movl	$0x4, %eax
     152:      	movl	$0x8, %esi
     157:      	movq	%rbx, %rdx
     15a:      	callq	*%rax
     15c:      	movq	0x8(%rsp), %rax
     161:      	movq	%rax, 0x5e50(%r14)
     168:      	leaq	0x8(%rbx), %rdx
     16c:      	leaq	0x8(%rsp), %rdi
     171:      	movl	$0x8, %ecx
     176:      	movl	$0x4, %eax
     17b:      	movl	$0x8, %esi
     180:      	callq	*%rax
     182:      	movq	0x8(%rsp), %rax
     187:      	movq	%rax, 0x5e58(%r14)
     18e:      	leaq	0x10(%rbx), %rdx
     192:      	leaq	0x8(%rsp), %rdi
     197:      	movl	$0x8, %ecx
     19c:      	movl	$0x4, %eax
     1a1:      	movl	$0x8, %esi
     1a6:      	callq	*%rax
     1a8:      	movq	0x8(%rsp), %rax
     1ad:      	movq	%rax, 0x5e60(%r14)
     1b4:      	leaq	0x18(%rbx), %rdx
     1b8:      	leaq	0x8(%rsp), %rdi
     1bd:      	movl	$0x8, %ecx
     1c2:      	movl	$0x4, %eax
     1c7:      	movl	$0x8, %esi
     1cc:      	callq	*%rax
     1ce:      	movq	0x8(%rsp), %rax
     1d3:      	movq	%rax, 0x5e68(%r14)
     1da:      	leaq	0x20(%rbx), %rdx
     1de:      	leaq	0x8(%rsp), %rdi
     1e3:      	movl	$0x8, %ecx
     1e8:      	movl	$0x4, %eax
     1ed:      	movl	$0x8, %esi
     1f2:      	callq	*%rax
     1f4:      	movq	0x8(%rsp), %rax
     1f9:      	movq	%rax, 0x5e70(%r14)
     200:      	movb	$0xd, (%r14)
     204:      	movw	$0x0, 0x2(%r14)
     20b:      	movl	$0x0, 0x4(%r14)
     213:      	movl	$0x7d, %eax
     218:      	callq	*%rax
     21a:      	movq	%rax, 0x8(%r14)
     21e:      	movq	$0x0, 0x70(%r14)
     226:      	movl	$0x0, 0x14(%r14)
     22e:      	movl	$0xe, %eax
     233:      	callq	*%rax
     235:      	movl	%eax, 0x7c(%r14)
     239:      	movl	$0xe, %eax
     23e:      	callq	*%rax
     240:      	cmpq	$-0x16, %rax
     244:      	jne	0x265 <generic_fentry_setup_event+0x265>
     246:      	leaq	0x20(%rbx), %rdx
     24a:      	leaq	0x8(%rsp), %rdi
     24f:      	movl	$0x8, %ecx
     254:      	movl	$0x4, %eax
     259:      	movl	$0x8, %esi
     25e:      	callq	*%rax
     260:      	movq	0x8(%rsp), %rax
     265:      	movq	%rax, 0x68(%r14)
     269:      	cmpl	$0x0, 0x5c(%r15)
     26e:      	jle	0x31b <generic_fentry_setup_event+0x31b>
     274:      	movq	0x8(%r14), %rcx
     278:      	movq	0x60(%r14), %rdx
     27c:      	movq	%rcx, 0x8(%rsp)
     281:      	movq	$0x1, 0x10(%rsp)
     28a:      	movq	$0x0, 0x18(%rsp)
     293:      	movq	%rdx, 0x38(%rsp)
     298:      	movq	%rax, 0x40(%rsp)
     29d:      	movq	(%rip), %rdi            # 0x2a4 <generic_fentry_setup_event+0x2a4>
     2a4:      	xorl	%ecx, %ecx
     2a6:      	leaq	0x38(%rsp), %rsi
     2ab:      	leaq	0x8(%rsp), %rdx
     2b0:      	movl	$0x2, %eax
     2b5:      	xorl	%ecx, %ecx
     2b7:      	callq	*%rax
     2b9:      	testq	%rax, %rax
     2bc:      	je	0x31b <generic_fentry_setup_event+0x31b>
     2be:      	negl	%eax
     2c0:      	movw	%ax, 0x2c(%rsp)
     2c5:      	movw	$0x5, 0x2e(%rsp)
     2cc:      	movabsq	$0x200000046, %rax      # imm = 0x200000046
     2d6:      	movq	%rax, 0x30(%rsp)
     2db:      	movq	(%rip), %rdi            # 0x2e2 <generic_fentry_setup_event+0x2e2>
     2e2:      	leaq	0x2c(%rsp), %rsi
     2e7:      	movl	$0x1, %eax
     2ec:      	callq	*%rax
     2ee:      	testq	%rax, %rax
     2f1:      	je	0x2f7 <generic_fentry_setup_event+0x2f7>
     2f3:      	incl	(%rax)
     2f5:      	jmp	0x31b <generic_fentry_setup_event+0x31b>
     2f7:      	movl	$0x1, 0x28(%rsp)
     2ff:      	movq	(%rip), %rdi            # 0x306 <generic_fentry_setup_event+0x306>
     306:      	xorl	%ecx, %ecx
     308:      	leaq	0x2c(%rsp), %rsi
     30d:      	leaq	0x28(%rsp), %rdx
     312:      	movl	$0x2, %eax
     317:      	xorl	%ecx, %ecx
     319:      	callq	*%rax
     31b:      	movl	$0x0, 0x8(%rsp)
     323:      	movq	(%rip), %rdi            # 0x32a <generic_fentry_setup_event+0x32a>
     32a:      	leaq	0x8(%rsp), %rsi
     32f:      	movl	$0x1, %eax
     334:      	callq	*%rax
     336:      	testq	%rax, %rax
     339:      	je	0x35e <generic_fentry_setup_event+0x35e>
     33b:      	movq	%rax, %rsi
     33e:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     345:      	movq	(%rip), %rdi            # 0x34c <generic_fentry_setup_event+0x34c>
     34c:      	movl	$0x1, %eax
     351:      	callq	*%rax
     353:      	testq	%rax, %rax
     356:      	je	0x35e <generic_fentry_setup_event+0x35e>
     358:      	cmpl	$-0x1, 0x40(%rax)
     35c:      	jne	0x379 <generic_fentry_setup_event+0x379>
     35e:      	movq	(%rip), %rsi            # 0x365 <generic_fentry_setup_event+0x365>
     365:      	movl	$0x3, %ecx
     36a:      	movl	$0xc, %eax
     36f:      	movq	%rbx, %rdi
     372:      	movl	$0x3, %edx
     377:      	callq	*%rax
     379:      	movq	(%rip), %rsi            # 0x380 <generic_fentry_setup_event+0x380>
     380:      	movl	$0x1, %ecx
     385:      	movl	$0xc, %eax
     38a:      	movq	%rbx, %rdi
     38d:      	movl	$0x1, %edx
     392:      	callq	*%rax
     394:      	xorl	%eax, %eax
     396:      	addq	$0x48, %rsp
     39a:      	popq	%rbx
     39b:      	popq	%r12
     39d:      	popq	%r14
     39f:      	popq	%r15
     3a1:      	retq
     3a2:      	nopw	%cs:(%rax,%rax)

00000000000003b0 <generic_fentry_process_event>:
     3b0:      	pushq	%rbp
     3b1:      	pushq	%r15
     3b3:      	pushq	%r14
     3b5:      	pushq	%r13
     3b7:      	pushq	%r12
     3b9:      	pushq	%rbx
     3ba:      	subq	$0x108, %rsp            # imm = 0x108
     3c1:      	movq	%rdi, %rbx
     3c4:      	movl	$0x0, 0xec(%rsp)
     3cf:      	movq	(%rip), %rdi            # 0x3d6 <generic_fentry_process_event+0x26>
     3d6:      	leaq	0xec(%rsp), %rsi
     3de:      	movl	$0x1, %eax
     3e3:      	callq	*%rax
     3e5:      	testq	%rax, %rax
     3e8:      	je	0x3563 <generic_fentry_process_event+0x31b3>
     3ee:      	movq	%rax, %r14
     3f1:      	movl	0x5efc(%rax), %r13d
     3f8:      	movl	0x4(%rax), %ebp
     3fb:      	cmpq	$0x2327, %rbp           # imm = 0x2327
     402:      	ja	0x34c4 <generic_fentry_process_event+0x3114>
     408:      	movl	$0x0, 0xf0(%rsp)
     413:      	movq	(%rip), %rdi            # 0x41a <generic_fentry_process_event+0x6a>
     41a:      	leaq	0xf0(%rsp), %rsi
     422:      	movl	$0x1, %eax
     427:      	callq	*%rax
     429:      	testq	%rax, %rax
     42c:      	je	0x34c4 <generic_fentry_process_event+0x3114>
     432:      	movq	%rax, %r15
     435:      	leaq	0x5ef8(%rax), %rsi
     43c:      	movq	(%rip), %rdi            # 0x443 <generic_fentry_process_event+0x93>
     443:      	movl	$0x1, %eax
     448:      	callq	*%rax
     44a:      	cmpl	$0x4, %r13d
     44e:      	jg	0x34c4 <generic_fentry_process_event+0x3114>
     454:      	testq	%rax, %rax
     457:      	je	0x34c4 <generic_fentry_process_event+0x3114>
     45d:      	movq	%rbp, 0x18(%rsp)
     462:      	movl	%r13d, %edx
     465:      	andl	$0x7, %edx
     468:      	movl	%edx, %ebp
     46a:      	movl	0x4(%rax,%rbp,4), %r12d
     46f:      	movslq	0x18(%rax,%rbp,4), %rsi
     474:      	movl	%esi, %ecx
     476:      	movl	$0x0, 0x5ea0(%r15,%rbp,4)
     482:      	testl	$0x100, %esi            # imm = 0x100
     488:      	movq	%rdx, (%rsp)
     48c:      	movq	%rcx, 0xc8(%rsp)
     494:      	movq	%rsi, 0x28(%rsp)
     499:      	jne	0x4b6 <generic_fentry_process_event+0x106>
     49b:      	testb	%cl, %cl
     49d:      	js	0x4c9 <generic_fentry_process_event+0x119>
     49f:      	testb	$0x40, %sil
     4a3:      	jne	0x4d9 <generic_fentry_process_event+0x129>
     4a5:      	movl	0x40(%rax,%rdx,4), %ecx
     4a9:      	andl	$0x7, %ecx
     4ac:      	movq	0x5e50(%r15,%rcx,8), %rsi
     4b4:      	jmp	0x4fd <generic_fentry_process_event+0x14d>
     4b6:      	movq	$0x0, 0xd8(%rsp)
     4c2:      	xorl	%esi, %esi
     4c4:      	jmp	0x5ef <generic_fentry_process_event+0x23f>
     4c9:      	movq	$0x0, 0xd8(%rsp)
     4d5:      	xorl	%esi, %esi
     4d7:      	jmp	0x505 <generic_fentry_process_event+0x155>
     4d9:      	movq	%r13, 0x48(%rsp)
     4de:      	movq	%rbx, %r13
     4e1:      	movq	%rax, %rbx
     4e4:      	movl	$0x23, %eax
     4e9:      	callq	*%rax
     4eb:      	movq	(%rsp), %rdx
     4ef:      	movq	%rax, %rsi
     4f2:      	movq	%rbx, %rax
     4f5:      	movq	%r13, %rbx
     4f8:      	movq	0x48(%rsp), %r13
     4fd:      	movq	%rsi, 0xd8(%rsp)
     505:      	cmpl	$0x4, %edx
     508:      	ja	0x5ef <generic_fentry_process_event+0x23f>
     50e:      	leaq	(%rdx,%rdx,4), %rcx
     512:      	shll	$0x4, %ecx
     515:      	cmpw	$0x0, 0x76(%rax,%rcx)
     51b:      	je	0x5ef <generic_fentry_process_event+0x23f>
     521:      	addq	%rcx, %rax
     524:      	addq	$0x70, %rax
     528:      	movq	%rax, 0x60(%rsp)
     52d:      	leaq	0xd8(%rsp), %rax
     535:      	movq	%rax, 0x68(%rsp)
     53a:      	movb	$0x0, 0x70(%rsp)
     53f:      	leaq	(%r15,%rbp,4), %rax
     543:      	addq	$0x5ea0, %rax           # imm = 0x5EA0
     549:      	movq	%rax, 0x78(%rsp)
     54e:      	movq	(%rip), %rax            # 0x555 <generic_fentry_process_event+0x1a5>
     555:      	cmpb	$0x0, (%rax)
     558:      	je	0x5b9 <generic_fentry_process_event+0x209>
     55a:      	xorl	%r15d, %r15d
     55d:      	movl	$0x8, %ebp
     562:      	jmp	0x585 <generic_fentry_process_event+0x1d5>
     564:      	movl	$0x4, %eax
     569:      	movq	0x68(%rsp), %rdi
     56e:      	movq	(%rdi), %rdx
     571:      	movl	$0x8, %esi
     576:      	callq	*%rax
     578:      	testl	%eax, %eax
     57a:      	js	0x5dc <generic_fentry_process_event+0x22c>
     57c:      	incq	%r15
     57f:      	cmpq	$0xa, %r15
     583:      	je	0x5e7 <generic_fentry_process_event+0x237>
     585:      	movq	0x60(%rsp), %rax
     58a:      	cmpw	$0x0, 0x6(%rax,%r15,8)
     591:      	je	0x5e7 <generic_fentry_process_event+0x237>
     593:      	movq	0x68(%rsp), %rcx
     598:      	movl	(%rax,%r15,8), %edx
     59c:      	addq	(%rcx), %rdx
     59f:      	movq	%rdx, (%rcx)
     5a2:      	cmpw	$0x0, 0x4(%rax,%r15,8)
     5a9:      	je	0x57c <generic_fentry_process_event+0x1cc>
     5ab:      	cmpb	$0x0, 0x70(%rsp)
     5b0:      	je	0x564 <generic_fentry_process_event+0x1b4>
     5b2:      	movl	$0x94, %eax
     5b7:      	jmp	0x569 <generic_fentry_process_event+0x1b9>
     5b9:      	leaq	(%rip), %rsi            # 0x5c0 <generic_fentry_process_event+0x210>
     5c0:      	xorl	%ecx, %ecx
     5c2:      	leaq	0x60(%rsp), %rdx
     5c7:      	movl	$0xa, %edi
     5cc:      	movl	$0xb5, %eax
     5d1:      	movl	$0xa, %edi
     5d6:      	xorl	%ecx, %ecx
     5d8:      	callq	*%rax
     5da:      	jmp	0x5e7 <generic_fentry_process_event+0x237>
     5dc:      	incl	%r15d
     5df:      	movq	0x78(%rsp), %rax
     5e4:      	movl	%r15d, (%rax)
     5e7:      	movq	0xd8(%rsp), %rsi
     5ef:      	movl	$0x1000, %r15d          # imm = 0x1000
     5f5:      	cmpl	$0x15, %r12d
     5f9:      	jg	0x637 <generic_fentry_process_event+0x287>
     5fb:      	cmpl	$0xb, %r12d
     5ff:      	movq	0x18(%rsp), %rbp
     604:      	jg	0x66f <generic_fentry_process_event+0x2bf>
     606:      	cmpl	$0x5, %r12d
     60a:      	jg	0x6fa <generic_fentry_process_event+0x34a>
     610:      	cmpl	$0x3, %r12d
     614:      	jg	0x784 <generic_fentry_process_event+0x3d4>
     61a:      	leal	-0x2(%r12), %eax
     61f:      	cmpl	$0x2, %eax
     622:      	jb	0x74a <generic_fentry_process_event+0x39a>
     628:      	cmpl	$0x1, %r12d
     62c:      	je	0x74a <generic_fentry_process_event+0x39a>
     632:      	jmp	0x7b6 <generic_fentry_process_event+0x406>
     637:      	cmpl	$0x20, %r12d
     63b:      	movq	0x18(%rsp), %rbp
     640:      	jle	0x69a <generic_fentry_process_event+0x2ea>
     642:      	cmpl	$0x27, %r12d
     646:      	jg	0x6c7 <generic_fentry_process_event+0x317>
     648:      	leal	-0x21(%r12), %eax
     64d:      	cmpl	$0x4, %eax
     650:      	jb	0x798 <generic_fentry_process_event+0x3e8>
     656:      	cmpl	$0x25, %r12d
     65a:      	je	0x7b9 <generic_fentry_process_event+0x409>
     660:      	cmpl	$0x27, %r12d
     664:      	je	0x752 <generic_fentry_process_event+0x3a2>
     66a:      	jmp	0x7b6 <generic_fentry_process_event+0x406>
     66f:      	cmpl	$0x11, %r12d
     673:      	jg	0x723 <generic_fentry_process_event+0x373>
     679:      	leal	-0xf(%r12), %eax
     67e:      	cmpl	$0x3, %eax
     681:      	jb	0x7b9 <generic_fentry_process_event+0x409>
     687:      	leal	-0xc(%r12), %eax
     68c:      	cmpl	$0x2, %eax
     68f:      	jb	0x74a <generic_fentry_process_event+0x39a>
     695:      	jmp	0x7b6 <generic_fentry_process_event+0x406>
     69a:      	cmpl	$0x1a, %r12d
     69e:      	jg	0x740 <generic_fentry_process_event+0x390>
     6a4:      	cmpl	$0x16, %r12d
     6a8:      	je	0x752 <generic_fentry_process_event+0x3a2>
     6ae:      	cmpl	$0x17, %r12d
     6b2:      	je	0x798 <generic_fentry_process_event+0x3e8>
     6b8:      	cmpl	$0x1a, %r12d
     6bc:      	je	0x7ae <generic_fentry_process_event+0x3fe>
     6c2:      	jmp	0x7b6 <generic_fentry_process_event+0x406>
     6c7:      	cmpl	$0x29, %r12d
     6cb:      	jle	0x76e <generic_fentry_process_event+0x3be>
     6d1:      	cmpl	$0x2a, %r12d
     6d5:      	je	0x7b9 <generic_fentry_process_event+0x409>
     6db:      	cmpl	$0x2b, %r12d
     6df:      	je	0x77c <generic_fentry_process_event+0x3cc>
     6e5:      	cmpl	$0x2c, %r12d
     6e9:      	jne	0x7b6 <generic_fentry_process_event+0x406>
     6ef:      	movl	$0x70, %r15d
     6f5:      	jmp	0x7b9 <generic_fentry_process_event+0x409>
     6fa:      	cmpl	$0x9, %r12d
     6fe:      	jg	0x798 <generic_fentry_process_event+0x3e8>
     704:      	cmpl	$0x6, %r12d
     708:      	je	0x7b9 <generic_fentry_process_event+0x409>
     70e:      	cmpl	$0x7, %r12d
     712:      	je	0x790 <generic_fentry_process_event+0x3e0>
     714:      	cmpl	$0x8, %r12d
     718:      	je	0x7ae <generic_fentry_process_event+0x3fe>
     71e:      	jmp	0x7b6 <generic_fentry_process_event+0x406>
     723:      	cmpl	$0x13, %r12d
     727:      	jg	0x75a <generic_fentry_process_event+0x3aa>
     729:      	movq	0x28(%rsp), %r15
     72e:      	cmpl	$0x12, %r12d
     732:      	je	0x7b9 <generic_fentry_process_event+0x409>
     738:      	cmpl	$0x13, %r12d
     73c:      	je	0x77c <generic_fentry_process_event+0x3cc>
     73e:      	jmp	0x7b6 <generic_fentry_process_event+0x406>
     740:      	leal	-0x1d(%r12), %eax
     745:      	cmpl	$0x4, %eax
     748:      	jae	0x7a8 <generic_fentry_process_event+0x3f8>
     74a:      	movl	$0x4, %r15d
     750:      	jmp	0x7b9 <generic_fentry_process_event+0x409>
     752:      	movl	$0x10, %r15d
     758:      	jmp	0x7b9 <generic_fentry_process_event+0x409>
     75a:      	cmpl	$0x14, %r12d
     75e:      	je	0x7a0 <generic_fentry_process_event+0x3f0>
     760:      	cmpl	$0x15, %r12d
     764:      	jne	0x7b6 <generic_fentry_process_event+0x406>
     766:      	movl	$0x20, %r15d
     76c:      	jmp	0x7b9 <generic_fentry_process_event+0x409>
     76e:      	cmpl	$0x28, %r12d
     772:      	je	0x77c <generic_fentry_process_event+0x3cc>
     774:      	cmpl	$0x29, %r12d
     778:      	je	0x790 <generic_fentry_process_event+0x3e0>
     77a:      	jmp	0x7b6 <generic_fentry_process_event+0x406>
     77c:      	movl	$0x18, %r15d
     782:      	jmp	0x7b9 <generic_fentry_process_event+0x409>
     784:      	cmpl	$0x4, %r12d
     788:      	je	0x798 <generic_fentry_process_event+0x3e8>
     78a:      	cmpl	$0x5, %r12d
     78e:      	jne	0x7b6 <generic_fentry_process_event+0x406>
     790:      	movl	$0x40, %r15d
     796:      	jmp	0x7b9 <generic_fentry_process_event+0x409>
     798:      	movl	$0x8, %r15d
     79e:      	jmp	0x7b9 <generic_fentry_process_event+0x409>
     7a0:      	movl	$0x98, %r15d
     7a6:      	jmp	0x7b9 <generic_fentry_process_event+0x409>
     7a8:      	cmpl	$0x1b, %r12d
     7ac:      	jne	0x7b6 <generic_fentry_process_event+0x406>
     7ae:      	movl	$0x50, %r15d
     7b4:      	jmp	0x7b9 <generic_fentry_process_event+0x409>
     7b6:      	xorl	%r15d, %r15d
     7b9:      	movq	%rsi, 0x20(%rsp)
     7be:      	movl	$0x0, 0xf4(%rsp)
     7c9:      	movq	(%rip), %rdi            # 0x7d0 <generic_fentry_process_event+0x420>
     7d0:      	leaq	0xf4(%rsp), %rsi
     7d8:      	movl	$0x1, %eax
     7dd:      	callq	*%rax
     7df:      	testq	%rax, %rax
     7e2:      	je	0x34c4 <generic_fentry_process_event+0x3114>
     7e8:      	movl	$0x3ffb, %ecx           # imm = 0x3FFB
     7ed:      	subq	%r15, %rcx
     7f0:      	cmpq	%rbp, %rcx
     7f3:      	jbe	0x34c4 <generic_fentry_process_event+0x3114>
     7f9:      	movq	(%rsp), %rdx
     7fd:      	movl	0x5ea0(%rax,%rdx,4), %ecx
     804:      	movl	%ecx, 0x90(%rax,%rbp)
     80b:      	leaq	0x4(%rbp), %r15
     80f:      	movq	%r15, 0x5e78(%rax,%rdx,8)
     817:      	movl	$0x4, %edx
     81c:      	testl	%ecx, %ecx
     81e:      	jne	0x34c0 <generic_fentry_process_event+0x3110>
     824:      	movq	%rax, %rbp
     827:      	addq	$0x90, %rbp
     82e:      	andl	$0x3fff, %r15d          # imm = 0x3FFF
     835:      	addq	%r15, %rbp
     838:      	movq	0x20(%rsp), %rdx
     83d:      	movq	%rdx, 0x60(%rsp)
     842:      	movq	$0x0, 0xa0(%rsp)
     84e:      	cmpl	$0x17, %r12d
     852:      	movq	%r14, 0x30(%rsp)
     857:      	movq	%rax, 0x8(%rsp)
     85c:      	movq	%r13, 0x48(%rsp)
     861:      	jle	0x89e <generic_fentry_process_event+0x4ee>
     863:      	cmpl	$0x18, %r12d
     867:      	je	0x8b9 <generic_fentry_process_event+0x509>
     869:      	cmpl	$0x25, %r12d
     86d:      	je	0x8f7 <generic_fentry_process_event+0x547>
     873:      	cmpl	$0x2a, %r12d
     877:      	jne	0x1000 <generic_fentry_process_event+0xc50>
     87d:      	movq	$0x0, 0xf8(%rsp)
     889:      	movq	%rdx, 0x100(%rsp)
     891:      	leaq	0xf8(%rsp), %rax
     899:      	jmp	0x924 <generic_fentry_process_event+0x574>
     89e:      	cmpl	$0xf, %r12d
     8a2:      	je	0xf19 <generic_fentry_process_event+0xb69>
     8a8:      	cmpl	$0x10, %r12d
     8ac:      	jne	0x1000 <generic_fentry_process_event+0xc50>
     8b2:      	leaq	0x38(%rsp), %r15
     8b7:      	jmp	0x8e1 <generic_fentry_process_event+0x531>
     8b9:      	leaq	0x38(%rsp), %r15
     8be:      	movl	$0x8, %ecx
     8c3:      	movl	$0x4, %eax
     8c8:      	movq	0x60(%rsp), %rdx
     8cd:      	movq	%r15, %rdi
     8d0:      	movl	$0x8, %esi
     8d5:      	callq	*%rax
     8d7:      	movq	0x38(%rsp), %rax
     8dc:      	movq	%rax, 0x60(%rsp)
     8e1:      	leaq	0x60(%rsp), %rdx
     8e6:      	movl	$0x8, %ecx
     8eb:      	movl	$0x4, %eax
     8f0:      	leaq	0x38(%rsp), %rdi
     8f5:      	jmp	0x914 <generic_fentry_process_event+0x564>
     8f7:      	addq	$0x40, %rdx
     8fb:      	movq	%rdx, 0x60(%rsp)
     900:      	leaq	0x38(%rsp), %rdi
     905:      	movl	$0x8, %ecx
     90a:      	movl	$0x4, %eax
     90f:      	movq	0x60(%rsp), %rdx
     914:      	movl	$0x8, %esi
     919:      	callq	*%rax
     91b:      	movq	0x38(%rsp), %rax
     920:      	addq	$0x40, %rax
     924:      	movq	%rax, 0xb0(%rsp)
     92c:      	movl	$0x0, 0xb8(%rsp)
     937:      	movq	(%rip), %rdi            # 0x93e <generic_fentry_process_event+0x58e>
     93e:      	leaq	0xb8(%rsp), %rsi
     946:      	movl	$0x1, %eax
     94b:      	callq	*%rax
     94d:      	testq	%rax, %rax
     950:      	je	0xa04 <generic_fentry_process_event+0x654>
     956:      	movq	%rax, %r12
     959:      	movq	%rbp, 0x10(%rsp)
     95e:      	addq	$0x1000, %rax           # imm = 0x1000
     964:      	movq	%rax, 0x20(%rsp)
     969:      	movl	$0x23, %eax
     96e:      	callq	*%rax
     970:      	leaq	0xd50(%rax), %rdx
     977:      	leaq	0xe0(%rsp), %rdi
     97f:      	movl	$0x8, %ecx
     984:      	movl	$0x4, %eax
     989:      	movl	$0x8, %esi
     98e:      	callq	*%rax
     990:      	movq	0xe0(%rsp), %r13
     998:      	movq	0xb0(%rsp), %rax
     9a0:      	leaq	0x8(%rax), %rdx
     9a4:      	leaq	0xd0(%rsp), %rdi
     9ac:      	movl	$0x8, %ecx
     9b1:      	movl	$0x4, %eax
     9b6:      	leaq	0x18(%r13), %rcx
     9ba:      	movq	%rcx, 0xc8(%rsp)
     9c2:      	movl	$0x8, %esi
     9c7:      	movq	%rdx, 0x28(%rsp)
     9cc:      	callq	*%rax
     9ce:      	movq	0xd0(%rsp), %r15
     9d6:      	leaq	0x10(%r15), %rdx
     9da:      	leaq	0x60(%rsp), %rdi
     9df:      	movl	$0x8, %ecx
     9e4:      	movl	$0x4, %eax
     9e9:      	movl	$0x8, %esi
     9ee:      	callq	*%rax
     9f0:      	cmpq	$0x0, 0x60(%rsp)
     9f6:      	movl	$0x1000, %ebp           # imm = 0x1000
     9fb:      	je	0xa11 <generic_fentry_process_event+0x661>
     9fd:      	movq	0x20(%rsp), %rcx
     a02:      	jmp	0xa63 <generic_fentry_process_event+0x6b3>
     a04:      	xorl	%r15d, %r15d
     a07:      	movq	0x48(%rsp), %r13
     a0c:      	jmp	0x11ef <generic_fentry_process_event+0xe3f>
     a11:      	leaq	0x18(%r15), %rdx
     a15:      	leaq	0x60(%rsp), %rdi
     a1a:      	movl	$0x8, %ecx
     a1f:      	movl	$0x4, %eax
     a24:      	movl	$0x8, %esi
     a29:      	callq	*%rax
     a2b:      	cmpq	%r15, 0x60(%rsp)
     a30:      	movq	0x20(%rsp), %rcx
     a35:      	je	0xa63 <generic_fentry_process_event+0x6b3>
     a37:      	movq	%r12, %rcx
     a3a:      	addq	$0xff6, %rcx            # imm = 0xFF6
     a41:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
     a4b:      	movq	%rax, 0xff6(%r12)
     a53:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
     a5e:      	movl	$0xff6, %ebp            # imm = 0xFF6
     a63:      	movq	$0x0, 0x68(%rsp)
     a6c:      	movq	$0x0, 0x60(%rsp)
     a75:      	movq	%r12, 0x70(%rsp)
     a7a:      	movq	$0x0, 0x78(%rsp)
     a83:      	movq	$0x0, 0x80(%rsp)
     a8f:      	movq	$0x0, 0x88(%rsp)
     a9b:      	movq	%rcx, 0x20(%rsp)
     aa0:      	movq	%rcx, 0x90(%rsp)
     aa8:      	movl	%ebp, 0x98(%rsp)
     aaf:      	movb	$0x0, 0x9c(%rsp)
     ab7:      	addq	$0x20, %r13
     abb:      	leaq	0x60(%rsp), %rdi
     ac0:      	movl	$0x8, %ecx
     ac5:      	movl	$0x4, %eax
     aca:      	leaq	0x68(%rsp), %r12
     acf:      	leaq	0x78(%rsp), %r15
     ad4:      	leaq	0x80(%rsp), %rbp
     adc:      	movl	$0x8, %esi
     ae1:      	movq	%r13, %rdx
     ae4:      	callq	*%rax
     ae6:      	movl	$0x8, %ecx
     aeb:      	movl	$0x4, %eax
     af0:      	movq	0xc8(%rsp), %rdx
     af8:      	movq	%r12, %rdi
     afb:      	movl	$0x8, %esi
     b00:      	callq	*%rax
     b02:      	movl	$0x8, %ecx
     b07:      	movl	$0x4, %eax
     b0c:      	movq	0x28(%rsp), %rdx
     b11:      	movq	%r15, %rdi
     b14:      	movl	$0x8, %esi
     b19:      	callq	*%rax
     b1b:      	movl	$0x8, %ecx
     b20:      	movl	$0x4, %eax
     b25:      	movq	0xb0(%rsp), %rdx
     b2d:      	movq	%rbp, %rdi
     b30:      	movl	$0x8, %esi
     b35:      	callq	*%rax
     b37:      	movq	0x80(%rsp), %rax
     b3f:      	addq	$-0x20, %rax
     b43:      	movq	%rax, 0x88(%rsp)
     b4b:      	movq	(%rip), %rax            # 0xb52 <generic_fentry_process_event+0x7a2>
     b52:      	cmpb	$0x0, (%rax)
     b55:      	je	0xd3d <generic_fentry_process_event+0x98d>
     b5b:      	movl	$0x800, %ebp            # imm = 0x800
     b60:      	movl	$0x8, %r15d
     b66:      	movq	0x78(%rsp), %r12
     b6b:      	movq	0x80(%rsp), %rdx
     b73:      	movq	0x88(%rsp), %r13
     b7b:      	cmpq	0x60(%rsp), %r12
     b80:      	jne	0xb8d <generic_fentry_process_event+0x7dd>
     b82:      	cmpq	0x68(%rsp), %rdx
     b87:      	je	0x10b3 <generic_fentry_process_event+0xd03>
     b8d:      	movl	$0x4, %eax
     b92:      	leaq	0x50(%rsp), %rdi
     b97:      	movl	$0x8, %esi
     b9c:      	callq	*%rax
     b9e:      	cmpq	0x50(%rsp), %r12
     ba3:      	movl	$0x8, %r14d
     ba9:      	je	0xccc <generic_fentry_process_event+0x91c>
     baf:      	leaq	0x18(%r12), %r15
     bb4:      	movl	$0x4, %eax
     bb9:      	leaq	0x38(%rsp), %rdi
     bbe:      	movl	$0x8, %esi
     bc3:      	movq	%r15, %rdx
     bc6:      	callq	*%rax
     bc8:      	cmpq	%r12, 0x38(%rsp)
     bcd:      	je	0xccc <generic_fentry_process_event+0x91c>
     bd3:      	movl	$0x4, %eax
     bd8:      	leaq	0xc0(%rsp), %rdi
     be0:      	movl	$0x8, %esi
     be5:      	movq	%r15, %rdx
     be8:      	callq	*%rax
     bea:      	addq	$0x20, %r12
     bee:      	movl	$0x4, %eax
     bf3:      	leaq	0xa0(%rsp), %rdi
     bfb:      	movl	$0x10, %ecx
     c00:      	movl	$0x10, %esi
     c05:      	movq	%r12, %rdx
     c08:      	callq	*%rax
     c0a:      	movq	0x70(%rsp), %r15
     c0f:      	movq	0x90(%rsp), %rax
     c17:      	movl	0xa4(%rsp), %r12d
     c1f:      	subq	%r15, %rax
     c22:      	movl	0x98(%rsp), %r13d
     c2a:      	movl	%r12d, %edx
     c2d:      	subl	%r13d, %edx
     c30:      	movl	$0x0, %ecx
     c35:      	cmovbl	%ecx, %edx
     c38:      	addq	0xa8(%rsp), %rdx
     c40:      	xorl	%esi, %esi
     c42:      	cmpl	%r12d, %r13d
     c45:      	seta	%sil
     c49:      	movl	%r12d, %ecx
     c4c:      	cmovbl	%r13d, %ecx
     c50:      	addl	%ecx, %esi
     c52:      	movl	%r13d, %edi
     c55:      	subl	%esi, %edi
     c57:      	movl	%edi, 0x98(%rsp)
     c5e:      	subq	%rsi, %rax
     c61:      	movq	0x30(%rsp), %r14
     c66:      	jb	0x10dc <generic_fentry_process_event+0xd2c>
     c6c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     c72:      	ja	0x10dc <generic_fentry_process_event+0xd2c>
     c78:      	cmpl	%r12d, %r13d
     c7b:      	jbe	0xc82 <generic_fentry_process_event+0x8d2>
     c7d:      	movb	$0x2f, (%r15,%rax)
     c82:      	xorl	%edi, %edi
     c84:      	cmpl	%r12d, %r13d
     c87:      	seta	%dil
     c8b:      	movzbl	%cl, %esi
     c8e:      	addq	%rax, %r15
     c91:      	addq	%r15, %rdi
     c94:      	movl	$0x4, %eax
     c99:      	callq	*%rax
     c9b:      	movq	%r15, 0x90(%rsp)
     ca3:      	cmpl	%r12d, %r13d
     ca6:      	jbe	0x10dc <generic_fentry_process_event+0xd2c>
     cac:      	movq	0xc0(%rsp), %rax
     cb4:      	movq	%rax, 0x78(%rsp)
     cb9:      	movl	$0x8, %r15d
     cbf:      	decl	%ebp
     cc1:      	jne	0xb66 <generic_fentry_process_event+0x7b6>
     cc7:      	jmp	0x10dc <generic_fentry_process_event+0xd2c>
     ccc:      	leaq	0x10(%r13), %rdx
     cd0:      	movl	$0x4, %eax
     cd5:      	leaq	0x38(%rsp), %rdi
     cda:      	movl	$0x8, %esi
     cdf:      	callq	*%rax
     ce1:      	movq	0x88(%rsp), %rax
     ce9:      	cmpq	0x38(%rsp), %rax
     cee:      	movl	$0x8, %r15d
     cf4:      	je	0x10cf <generic_fentry_process_event+0xd1f>
     cfa:      	addq	$0x18, %r13
     cfe:      	movl	$0x4, %eax
     d03:      	leaq	0x78(%rsp), %rdi
     d08:      	movl	$0x8, %esi
     d0d:      	movq	%r13, %rdx
     d10:      	callq	*%rax
     d12:      	movq	0x38(%rsp), %rax
     d17:      	movq	%rax, 0x88(%rsp)
     d1f:      	addq	$0x20, %rax
     d23:      	movq	%rax, 0x80(%rsp)
     d2b:      	movq	0x30(%rsp), %r14
     d30:      	decl	%ebp
     d32:      	jne	0xb66 <generic_fentry_process_event+0x7b6>
     d38:      	jmp	0x10dc <generic_fentry_process_event+0xd2c>
     d3d:      	movl	$0x800, %ebp            # imm = 0x800
     d42:      	movl	$0x8, %r15d
     d48:      	movq	0x78(%rsp), %r12
     d4d:      	movq	0x80(%rsp), %rdx
     d55:      	movq	0x88(%rsp), %r13
     d5d:      	cmpq	0x60(%rsp), %r12
     d62:      	jne	0xd6f <generic_fentry_process_event+0x9bf>
     d64:      	cmpq	0x68(%rsp), %rdx
     d69:      	je	0x10b3 <generic_fentry_process_event+0xd03>
     d6f:      	movl	$0x4, %eax
     d74:      	leaq	0x50(%rsp), %rdi
     d79:      	movl	$0x8, %esi
     d7e:      	callq	*%rax
     d80:      	cmpq	0x50(%rsp), %r12
     d85:      	movl	$0x8, %ecx
     d8a:      	je	0xead <generic_fentry_process_event+0xafd>
     d90:      	leaq	0x18(%r12), %r15
     d95:      	movl	$0x4, %eax
     d9a:      	leaq	0x38(%rsp), %rdi
     d9f:      	movl	$0x8, %esi
     da4:      	movq	%r15, %rdx
     da7:      	callq	*%rax
     da9:      	movl	$0x8, %ecx
     dae:      	cmpq	%r12, 0x38(%rsp)
     db3:      	je	0xead <generic_fentry_process_event+0xafd>
     db9:      	movl	$0x4, %eax
     dbe:      	leaq	0xc0(%rsp), %rdi
     dc6:      	movl	$0x8, %esi
     dcb:      	movq	%r15, %rdx
     dce:      	callq	*%rax
     dd0:      	addq	$0x20, %r12
     dd4:      	movl	$0x4, %eax
     dd9:      	leaq	0xa0(%rsp), %rdi
     de1:      	movl	$0x10, %ecx
     de6:      	movl	$0x10, %esi
     deb:      	movq	%r12, %rdx
     dee:      	callq	*%rax
     df0:      	movq	0x70(%rsp), %r15
     df5:      	movq	0x90(%rsp), %rax
     dfd:      	movl	0xa4(%rsp), %r12d
     e05:      	subq	%r15, %rax
     e08:      	movl	0x98(%rsp), %r13d
     e10:      	movl	%r12d, %edx
     e13:      	subl	%r13d, %edx
     e16:      	movl	$0x0, %ecx
     e1b:      	cmovbl	%ecx, %edx
     e1e:      	addq	0xa8(%rsp), %rdx
     e26:      	xorl	%esi, %esi
     e28:      	cmpl	%r12d, %r13d
     e2b:      	seta	%sil
     e2f:      	movl	%r12d, %ecx
     e32:      	cmovbl	%r13d, %ecx
     e36:      	addl	%ecx, %esi
     e38:      	movl	%r13d, %edi
     e3b:      	subl	%esi, %edi
     e3d:      	movl	%edi, 0x98(%rsp)
     e44:      	subq	%rsi, %rax
     e47:      	jb	0x10dc <generic_fentry_process_event+0xd2c>
     e4d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     e53:      	ja	0x10dc <generic_fentry_process_event+0xd2c>
     e59:      	cmpl	%r12d, %r13d
     e5c:      	jbe	0xe63 <generic_fentry_process_event+0xab3>
     e5e:      	movb	$0x2f, (%r15,%rax)
     e63:      	xorl	%edi, %edi
     e65:      	cmpl	%r12d, %r13d
     e68:      	seta	%dil
     e6c:      	movzbl	%cl, %esi
     e6f:      	addq	%rax, %r15
     e72:      	addq	%r15, %rdi
     e75:      	movl	$0x4, %eax
     e7a:      	callq	*%rax
     e7c:      	movq	%r15, 0x90(%rsp)
     e84:      	cmpl	%r12d, %r13d
     e87:      	jbe	0x10dc <generic_fentry_process_event+0xd2c>
     e8d:      	movq	0xc0(%rsp), %rax
     e95:      	movq	%rax, 0x78(%rsp)
     e9a:      	movl	$0x8, %r15d
     ea0:      	decl	%ebp
     ea2:      	jne	0xd48 <generic_fentry_process_event+0x998>
     ea8:      	jmp	0x10dc <generic_fentry_process_event+0xd2c>
     ead:      	leaq	0x10(%r13), %rdx
     eb1:      	movl	$0x4, %eax
     eb6:      	leaq	0x38(%rsp), %rdi
     ebb:      	movl	$0x8, %esi
     ec0:      	callq	*%rax
     ec2:      	movq	0x88(%rsp), %rax
     eca:      	cmpq	0x38(%rsp), %rax
     ecf:      	movl	$0x8, %r15d
     ed5:      	je	0x10b3 <generic_fentry_process_event+0xd03>
     edb:      	addq	$0x18, %r13
     edf:      	movl	$0x4, %eax
     ee4:      	leaq	0x78(%rsp), %rdi
     ee9:      	movl	$0x8, %esi
     eee:      	movq	%r13, %rdx
     ef1:      	callq	*%rax
     ef3:      	movq	0x38(%rsp), %rax
     ef8:      	movq	%rax, 0x88(%rsp)
     f00:      	addq	$0x20, %rax
     f04:      	movq	%rax, 0x80(%rsp)
     f0c:      	decl	%ebp
     f0e:      	jne	0xd48 <generic_fentry_process_event+0x998>
     f14:      	jmp	0x10dc <generic_fentry_process_event+0xd2c>
     f19:      	leaq	0xa0(%rsp), %rdi
     f21:      	leaq	0x60(%rsp), %rdx
     f26:      	movl	$0x8, %ecx
     f2b:      	movl	$0x4, %eax
     f30:      	movl	$0x8, %esi
     f35:      	callq	*%rax
     f37:      	movq	0xa0(%rsp), %rax
     f3f:      	movq	%rax, 0xb0(%rsp)
     f47:      	testq	%rax, %rax
     f4a:      	jne	0x92c <generic_fentry_process_event+0x57c>
     f50:      	movl	$0x0, 0xe0(%rsp)
     f5b:      	movq	(%rip), %rdi            # 0xf62 <generic_fentry_process_event+0xbb2>
     f62:      	leaq	0xe0(%rsp), %rsi
     f6a:      	movl	$0x1, %eax
     f6f:      	callq	*%rax
     f71:      	testq	%rax, %rax
     f74:      	je	0x135e <generic_fentry_process_event+0xfae>
     f7a:      	movq	%r15, 0xb0(%rsp)
     f82:      	movq	%rbp, 0x10(%rsp)
     f87:      	xorl	%r15d, %r15d
     f8a:      	cmpl	$0x19, %r12d
     f8e:      	movq	0x48(%rsp), %r13
     f93:      	movq	0x18(%rsp), %rbp
     f98:      	jg	0x142a <generic_fentry_process_event+0x107a>
     f9e:      	cmpl	$0x12, %r12d
     fa2:      	jle	0x1596 <generic_fentry_process_event+0x11e6>
     fa8:      	cmpl	$0x14, %r12d
     fac:      	jle	0x192b <generic_fentry_process_event+0x157b>
     fb2:      	cmpl	$0x15, %r12d
     fb6:      	je	0x2267 <generic_fentry_process_event+0x1eb7>
     fbc:      	cmpl	$0x16, %r12d
     fc0:      	je	0x21da <generic_fentry_process_event+0x1e2a>
     fc6:      	cmpl	$0x17, %r12d
     fca:      	movq	0x8(%rsp), %rcx
     fcf:      	movq	(%rsp), %rsi
     fd3:      	movq	0x20(%rsp), %rdx
     fd8:      	jne	0x29cb <generic_fentry_process_event+0x261b>
     fde:      	movq	0x10(%rsp), %rax
     fe3:      	movl	$0x0, 0x4(%rax)
     fea:      	movl	%edx, (%rax)
     fec:      	movl	$0x8, %r15d
     ff2:      	testl	%r15d, %r15d
     ff5:      	js	0x34a5 <generic_fentry_process_event+0x30f5>
     ffb:      	jmp	0x29d4 <generic_fentry_process_event+0x2624>
    1000:      	cmpl	$0x2c, %r12d
    1004:      	ja	0xf50 <generic_fentry_process_event+0xba0>
    100a:      	movl	%r12d, %eax
    100d:      	movabsq	$0x11c1f2027cf2, %rcx   # imm = 0x11C1F2027CF2
    1017:      	btq	%rax, %rcx
    101b:      	jae	0xf50 <generic_fentry_process_event+0xba0>
    1021:      	movq	%rdx, 0x50(%rsp)
    1026:      	movl	$0x0, 0xe0(%rsp)
    1031:      	movq	(%rip), %rdi            # 0x1038 <generic_fentry_process_event+0xc88>
    1038:      	leaq	0xe0(%rsp), %rsi
    1040:      	movl	$0x1, %eax
    1045:      	callq	*%rax
    1047:      	testq	%rax, %rax
    104a:      	je	0x10bd <generic_fentry_process_event+0xd0d>
    104c:      	movq	%r15, %r13
    104f:      	movq	%rbp, 0x10(%rsp)
    1054:      	xorl	%r15d, %r15d
    1057:      	cmpl	$0x10, %r12d
    105b:      	movq	0x8(%rsp), %rcx
    1060:      	jle	0x11f9 <generic_fentry_process_event+0xe49>
    1066:      	cmpl	$0x1e, %r12d
    106a:      	movq	0x18(%rsp), %rbp
    106f:      	jle	0x1370 <generic_fentry_process_event+0xfc0>
    1075:      	cmpl	$0x26, %r12d
    1079:      	jg	0x146e <generic_fentry_process_event+0x10be>
    107f:      	leal	-0x1f(%r12), %eax
    1084:      	cmpl	$0x2, %eax
    1087:      	jae	0x1a25 <generic_fentry_process_event+0x1675>
    108d:      	leaq	0x50(%rsp), %rdx
    1092:      	movl	$0x4, %r15d
    1098:      	movl	$0x1, %ecx
    109d:      	movl	$0x4, %eax
    10a2:      	movq	0x10(%rsp), %rdi
    10a7:      	movl	$0x1, %esi
    10ac:      	callq	*%rax
    10ae:      	jmp	0x29bd <generic_fentry_process_event+0x260d>
    10b3:      	movb	$0x1, 0x9c(%rsp)
    10bb:      	jmp	0x10dc <generic_fentry_process_event+0xd2c>
    10bd:      	xorl	%r15d, %r15d
    10c0:      	movq	0x8(%rsp), %rcx
    10c5:      	movq	0x18(%rsp), %rbp
    10ca:      	jmp	0x29c2 <generic_fentry_process_event+0x2612>
    10cf:      	movb	$0x1, 0x9c(%rsp)
    10d7:      	movq	0x30(%rsp), %r14
    10dc:      	movq	0x90(%rsp), %rax
    10e4:      	movq	0x20(%rsp), %rdx
    10e9:      	xorl	%ebp, %ebp
    10eb:      	cmpq	%rdx, %rax
    10ee:      	je	0x1129 <generic_fentry_process_event+0xd79>
    10f0:      	cmpb	$0x0, 0x9c(%rsp)
    10f8:      	sete	%cl
    10fb:      	movl	0x98(%rsp), %edx
    1102:      	movl	$0x1000, %r15d          # imm = 0x1000
    1108:      	subl	%edx, %r15d
    110b:      	testl	%edx, %edx
    110d:      	cmovlel	%edx, %r15d
    1111:      	testq	%rax, %rax
    1114:      	movq	0x48(%rsp), %r13
    1119:      	je	0x11ec <generic_fentry_process_event+0xe3c>
    111f:      	movb	%cl, %bpl
    1122:      	addl	%ebp, %ebp
    1124:      	movq	%rax, %rdx
    1127:      	jmp	0x1131 <generic_fentry_process_event+0xd81>
    1129:      	xorl	%r15d, %r15d
    112c:      	movq	0x48(%rsp), %r13
    1131:      	movq	0x10(%rsp), %r12
    1136:      	leaq	0x4(%r12), %rdi
    113b:      	andl	$0xfff, %r15d           # imm = 0xFFF
    1142:      	movl	$0x4, %eax
    1147:      	movl	%r15d, %esi
    114a:      	callq	*%rax
    114c:      	movl	%r15d, (%r12)
    1150:      	leaq	0x60(%rsp), %rdi
    1155:      	movl	$0x8, %ecx
    115a:      	movl	$0x4, %eax
    115f:      	movq	0x28(%rsp), %rdx
    1164:      	movl	$0x8, %esi
    1169:      	callq	*%rax
    116b:      	movq	0x60(%rsp), %rcx
    1170:      	addq	$0x30, %rcx
    1174:      	leaq	0xa0(%rsp), %rdi
    117c:      	movl	$0x8, %edx
    1181:      	movl	$0x4, %eax
    1186:      	movq	0x60(%rsp), %rdx
    118b:      	addq	$0x30, %rdx
    118f:      	movl	$0x8, %esi
    1194:      	callq	*%rax
    1196:      	movq	0xa0(%rsp), %rcx
    119e:      	leaq	0x38(%rsp), %rdi
    11a3:      	movl	$0x2, %edx
    11a8:      	movl	$0x4, %eax
    11ad:      	movq	0xa0(%rsp), %rdx
    11b5:      	movl	$0x2, %esi
    11ba:      	callq	*%rax
    11bc:      	movl	%ebp, 0x4(%r12,%r15)
    11c1:      	movzwl	0x38(%rsp), %eax
    11c6:      	movw	%ax, 0x8(%r12,%r15)
    11cc:      	addl	$0xa, %r15d
    11d0:      	movq	0x8(%rsp), %rcx
    11d5:      	movq	0x18(%rsp), %rbp
    11da:      	movq	(%rsp), %rsi
    11de:      	testl	%r15d, %r15d
    11e1:      	js	0x34a5 <generic_fentry_process_event+0x30f5>
    11e7:      	jmp	0x29d4 <generic_fentry_process_event+0x2624>
    11ec:      	xorl	%r15d, %r15d
    11ef:      	movq	0x18(%rsp), %rbp
    11f4:      	jmp	0x29d4 <generic_fentry_process_event+0x2624>
    11f9:      	cmpl	$0x9, %r12d
    11fd:      	movq	0x18(%rsp), %rbp
    1202:      	movq	(%rsp), %rsi
    1206:      	jg	0x13a6 <generic_fentry_process_event+0xff6>
    120c:      	cmpl	$0x4, %r12d
    1210:      	jle	0x1636 <generic_fentry_process_event+0x1286>
    1216:      	cmpl	$0x5, %r12d
    121a:      	je	0x1cc6 <generic_fentry_process_event+0x1916>
    1220:      	cmpl	$0x6, %r12d
    1224:      	je	0x1408 <generic_fentry_process_event+0x1058>
    122a:      	movq	%rax, 0x20(%rsp)
    122f:      	cmpl	$0x7, %r12d
    1233:      	movq	0x8(%rsp), %rcx
    1238:      	movq	(%rsp), %rsi
    123c:      	jne	0x29c6 <generic_fentry_process_event+0x2616>
    1242:      	movq	0x50(%rsp), %r15
    1247:      	movq	0x10(%rsp), %rbp
    124c:      	movq	%r15, 0x28(%rbp)
    1250:      	leaq	0x26(%rbp), %rdi
    1254:      	leaq	0x10(%r15), %rdx
    1258:      	movl	$0x2, %ecx
    125d:      	movl	$0x4, %eax
    1262:      	movl	$0x2, %esi
    1267:      	callq	*%rax
    1269:      	leaq	0x3a(%rbp), %rdi
    126d:      	leaq	0x12(%r15), %rdx
    1271:      	movl	$0x1, %ecx
    1276:      	movl	$0x4, %eax
    127b:      	movl	$0x1, %esi
    1280:      	callq	*%rax
    1282:      	leaq	0x38(%rbp), %rdi
    1286:      	leaq	0x226(%r15), %rdx
    128d:      	movl	$0x2, %ecx
    1292:      	movl	$0x4, %eax
    1297:      	movl	$0x2, %esi
    129c:      	callq	*%rax
    129e:      	leaq	0x24(%rbp), %rdi
    12a2:      	leaq	0x224(%r15), %rdx
    12a9:      	movl	$0x2, %ecx
    12ae:      	movl	$0x4, %eax
    12b3:      	movl	$0x2, %esi
    12b8:      	callq	*%rax
    12ba:      	leaq	0x30(%rbp), %rdi
    12be:      	leaq	0x21c(%r15), %rdx
    12c5:      	movl	$0x4, %ecx
    12ca:      	movl	$0x4, %eax
    12cf:      	movl	$0x4, %esi
    12d4:      	callq	*%rax
    12d6:      	leaq	0x34(%rbp), %rdi
    12da:      	leaq	0x218(%r15), %rdx
    12e1:      	movl	$0x4, %ecx
    12e6:      	movl	$0x4, %eax
    12eb:      	movl	$0x4, %esi
    12f0:      	callq	*%rax
    12f2:      	leaq	0x10(%rbp), %r12
    12f6:      	movq	$0x0, (%rbp)
    12fe:      	movq	$0x0, 0x8(%rbp)
    1306:      	movq	$0x0, 0x10(%rbp)
    130e:      	movq	$0x0, 0x18(%rbp)
    1316:      	movzwl	0x26(%rbp), %eax
    131a:      	cmpl	$0xa, %eax
    131d:      	je	0x2689 <generic_fentry_process_event+0x22d9>
    1323:      	cmpl	$0x2, %eax
    1326:      	jne	0x26b9 <generic_fentry_process_event+0x2309>
    132c:      	leaq	0x4(%r15), %rdx
    1330:      	movl	$0x4, %ecx
    1335:      	movl	$0x4, %eax
    133a:      	movq	%rbp, %rdi
    133d:      	movl	$0x4, %esi
    1342:      	callq	*%rax
    1344:      	movl	$0x4, %ecx
    1349:      	movl	$0x4, %eax
    134e:      	movq	%r12, %rdi
    1351:      	movl	$0x4, %esi
    1356:      	movq	%r15, %rdx
    1359:      	jmp	0x26b7 <generic_fentry_process_event+0x2307>
    135e:      	xorl	%r15d, %r15d
    1361:      	movq	0x8(%rsp), %rcx
    1366:      	movq	0x48(%rsp), %r13
    136b:      	jmp	0x11d5 <generic_fentry_process_event+0xe25>
    1370:      	cmpl	$0x1c, %r12d
    1374:      	jg	0x1610 <generic_fentry_process_event+0x1260>
    137a:      	cmpl	$0x11, %r12d
    137e:      	je	0x1a5c <generic_fentry_process_event+0x16ac>
    1384:      	movq	%rax, 0x20(%rsp)
    1389:      	cmpl	$0x19, %r12d
    138d:      	je	0x1b20 <generic_fentry_process_event+0x1770>
    1393:      	cmpl	$0x1c, %r12d
    1397:      	movq	(%rsp), %rsi
    139b:      	je	0x1646 <generic_fentry_process_event+0x1296>
    13a1:      	jmp	0x29c6 <generic_fentry_process_event+0x2616>
    13a6:      	leal	-0xa(%r12), %eax
    13ab:      	cmpl	$0x2, %eax
    13ae:      	jb	0x1646 <generic_fentry_process_event+0x1296>
    13b4:      	leal	-0xc(%r12), %eax
    13b9:      	cmpl	$0x2, %eax
    13bc:      	jb	0x1667 <generic_fentry_process_event+0x12b7>
    13c2:      	cmpl	$0xe, %r12d
    13c6:      	jne	0x29c6 <generic_fentry_process_event+0x2616>
    13cc:      	leaq	0x60(%rsp), %rdi
    13d1:      	leaq	0x50(%rsp), %r15
    13d6:      	movl	$0x8, %ecx
    13db:      	movl	$0x4, %eax
    13e0:      	movl	$0x8, %esi
    13e5:      	movq	%r15, %rdx
    13e8:      	callq	*%rax
    13ea:      	movq	0x60(%rsp), %rcx
    13ef:      	movl	$0x8, %edx
    13f4:      	movl	$0x4, %eax
    13f9:      	movq	0x60(%rsp), %rdx
    13fe:      	movq	%r15, %rdi
    1401:      	movl	$0x8, %esi
    1406:      	callq	*%rax
    1408:      	movq	0x50(%rsp), %rdx
    140d:      	movq	0x10(%rsp), %r13
    1412:      	leaq	0x4(%r13), %rdi
    1416:      	movl	$0x1001, %ecx           # imm = 0x1001
    141b:      	movl	$0x2d, %eax
    1420:      	movl	$0x1001, %esi           # imm = 0x1001
    1425:      	jmp	0x1ead <generic_fentry_process_event+0x1afd>
    142a:      	cmpl	$0x20, %r12d
    142e:      	movq	0x20(%rsp), %r8
    1433:      	jle	0x17fb <generic_fentry_process_event+0x144b>
    1439:      	movq	%rax, %rcx
    143c:      	leal	-0x21(%r12), %eax
    1441:      	cmpl	$0x4, %eax
    1444:      	jae	0x1696 <generic_fentry_process_event+0x12e6>
    144a:      	movl	$0x8, %r15d
    1450:      	movl	$0x8, %ecx
    1455:      	movl	$0x4, %eax
    145a:      	movq	0x10(%rsp), %rdi
    145f:      	movl	$0x8, %esi
    1464:      	movq	%r8, %rdx
    1467:      	callq	*%rax
    1469:      	jmp	0x23f8 <generic_fentry_process_event+0x2048>
    146e:      	cmpl	$0x27, %r12d
    1472:      	je	0x1e8b <generic_fentry_process_event+0x1adb>
    1478:      	cmpl	$0x28, %r12d
    147c:      	je	0x1ecc <generic_fentry_process_event+0x1b1c>
    1482:      	cmpl	$0x2c, %r12d
    1486:      	movq	(%rsp), %rsi
    148a:      	jne	0x29c6 <generic_fentry_process_event+0x2616>
    1490:      	movq	0x50(%rsp), %r15
    1495:      	movb	$0x0, 0x60(%rsp)
    149a:      	movq	0x10(%rsp), %rdi
    149f:      	movq	$0x0, 0x68(%rdi)
    14a7:      	movq	$0x0, 0x60(%rdi)
    14af:      	movq	$0x0, 0x58(%rdi)
    14b7:      	movq	$0x0, 0x50(%rdi)
    14bf:      	movq	$0x0, 0x48(%rdi)
    14c7:      	movq	$0x0, 0x40(%rdi)
    14cf:      	movq	$0x0, 0x38(%rdi)
    14d7:      	movq	$0x0, 0x30(%rdi)
    14df:      	movq	$0x0, 0x28(%rdi)
    14e7:      	movq	$0x0, 0x20(%rdi)
    14ef:      	movq	$0x0, 0x18(%rdi)
    14f7:      	movq	$0x0, 0x10(%rdi)
    14ff:      	movq	$0x0, 0x8(%rdi)
    1507:      	movq	$0x0, (%rdi)
    150e:      	movl	$0x2, %ecx
    1513:      	movl	$0x4, %eax
    1518:      	movl	$0x2, %esi
    151d:      	movq	%r15, %rdx
    1520:      	callq	*%rax
    1522:      	testq	%rax, %rax
    1525:      	js	0x29b7 <generic_fentry_process_event+0x2607>
    152b:      	leaq	0x2(%r15), %r12
    152f:      	leaq	0x60(%rsp), %rdi
    1534:      	movl	$0x1, %ecx
    1539:      	movl	$0x4, %eax
    153e:      	movl	$0x1, %esi
    1543:      	movq	%r12, %rdx
    1546:      	callq	*%rax
    1548:      	testq	%rax, %rax
    154b:      	js	0x29b7 <generic_fentry_process_event+0x2607>
    1551:      	movq	0x10(%rsp), %rax
    1556:      	leaq	0x4(%rax), %rdi
    155a:      	cmpb	$0x0, 0x60(%rsp)
    155f:      	sete	0x2(%rax)
    1563:      	je	0x2984 <generic_fentry_process_event+0x25d4>
    1569:      	movl	$0x6c, %ecx
    156e:      	movl	$0x2d, %eax
    1573:      	movl	$0x6c, %esi
    1578:      	movq	%r12, %rdx
    157b:      	callq	*%rax
    157d:      	testl	%eax, %eax
    157f:      	movq	0x18(%rsp), %rbp
    1584:      	movq	0x30(%rsp), %r14
    1589:      	js	0x29b7 <generic_fentry_process_event+0x2607>
    158f:      	decb	%al
    1591:      	jmp	0x29af <generic_fentry_process_event+0x25ff>
    1596:      	cmpl	$0x7, %r12d
    159a:      	jg	0x18c5 <generic_fentry_process_event+0x1515>
    15a0:      	movq	%rax, %rcx
    15a3:      	cmpl	$0x2, %r12d
    15a7:      	je	0x1f65 <generic_fentry_process_event+0x1bb5>
    15ad:      	movq	%rcx, 0x28(%rsp)
    15b2:      	cmpl	$0x3, %r12d
    15b6:      	movq	0x8(%rsp), %rcx
    15bb:      	movq	(%rsp), %rsi
    15bf:      	jne	0x29cb <generic_fentry_process_event+0x261b>
    15c5:      	movq	0x28(%rsp), %rax
    15ca:      	leaq	0x90(%rax), %rbp
    15d1:      	movq	0xc8(%rsp), %rax
    15d9:      	andl	$0xf, %eax
    15dc:      	cmpl	$0x2, %eax
    15df:      	jle	0x282c <generic_fentry_process_event+0x247c>
    15e5:      	cmpl	$0x3, %eax
    15e8:      	je	0x2aca <generic_fentry_process_event+0x271a>
    15ee:      	cmpl	$0x4, %eax
    15f1:      	je	0x2ad7 <generic_fentry_process_event+0x2727>
    15f7:      	cmpl	$0x5, %eax
    15fa:      	jne	0x2f09 <generic_fentry_process_event+0x2b59>
    1600:      	movq	0x28(%rsp), %rax
    1605:      	addq	$0x5e70, %rax           # imm = 0x5E70
    160b:      	jmp	0x2aef <generic_fentry_process_event+0x273f>
    1610:      	leaq	0x50(%rsp), %rdx
    1615:      	movl	$0x4, %r15d
    161b:      	movl	$0x2, %ecx
    1620:      	movl	$0x4, %eax
    1625:      	movq	0x10(%rsp), %rdi
    162a:      	movl	$0x2, %esi
    162f:      	callq	*%rax
    1631:      	jmp	0x29bd <generic_fentry_process_event+0x260d>
    1636:      	cmpl	$0x1, %r12d
    163a:      	je	0x1667 <generic_fentry_process_event+0x12b7>
    163c:      	cmpl	$0x4, %r12d
    1640:      	jne	0x29c6 <generic_fentry_process_event+0x2616>
    1646:      	movl	$0x8, %r15d
    164c:      	leaq	0x50(%rsp), %rdx
    1651:      	movl	$0x8, %ecx
    1656:      	movl	$0x4, %eax
    165b:      	movq	0x10(%rsp), %rdi
    1660:      	movl	$0x8, %esi
    1665:      	jmp	0x1686 <generic_fentry_process_event+0x12d6>
    1667:      	leaq	0x50(%rsp), %rdx
    166c:      	movl	$0x4, %r15d
    1672:      	movl	$0x4, %ecx
    1677:      	movl	$0x4, %eax
    167c:      	movq	0x10(%rsp), %rdi
    1681:      	movl	$0x4, %esi
    1686:      	callq	*%rax
    1688:      	movq	(%rsp), %rsi
    168c:      	movq	0x8(%rsp), %rcx
    1691:      	jmp	0x29c6 <generic_fentry_process_event+0x2616>
    1696:      	movq	%rcx, 0x28(%rsp)
    169b:      	cmpl	$0x2b, %r12d
    169f:      	je	0x235f <generic_fentry_process_event+0x1faf>
    16a5:      	cmpl	$0x29, %r12d
    16a9:      	movq	0x8(%rsp), %rcx
    16ae:      	movq	(%rsp), %rsi
    16b2:      	jne	0x29cb <generic_fentry_process_event+0x261b>
    16b8:      	movq	%rcx, %r13
    16bb:      	addq	$0x18, %r8
    16bf:      	leaq	0x60(%rsp), %rdi
    16c4:      	movl	$0x4, %r12d
    16ca:      	movl	$0x8, %ecx
    16cf:      	movl	$0x4, %eax
    16d4:      	movl	$0x8, %esi
    16d9:      	movq	%r8, %rdx
    16dc:      	callq	*%rax
    16de:      	movq	0x60(%rsp), %r15
    16e3:      	testq	%r15, %r15
    16e6:      	je	0x2a7e <generic_fentry_process_event+0x26ce>
    16ec:      	movq	0x10(%rsp), %rbp
    16f1:      	movq	%r15, 0x28(%rbp)
    16f5:      	leaq	0x26(%rbp), %rdi
    16f9:      	leaq	0x10(%r15), %rdx
    16fd:      	movl	$0x2, %ecx
    1702:      	movl	$0x4, %eax
    1707:      	movl	$0x2, %esi
    170c:      	callq	*%rax
    170e:      	leaq	0x3a(%rbp), %rdi
    1712:      	leaq	0x12(%r15), %rdx
    1716:      	movl	$0x1, %ecx
    171b:      	movl	$0x4, %eax
    1720:      	movl	$0x1, %esi
    1725:      	callq	*%rax
    1727:      	leaq	0x38(%rbp), %rdi
    172b:      	leaq	0x226(%r15), %rdx
    1732:      	movl	$0x2, %ecx
    1737:      	movl	$0x4, %eax
    173c:      	movl	$0x2, %esi
    1741:      	callq	*%rax
    1743:      	leaq	0x24(%rbp), %rdi
    1747:      	leaq	0x224(%r15), %rdx
    174e:      	movl	$0x2, %ecx
    1753:      	movl	$0x4, %eax
    1758:      	movl	$0x2, %esi
    175d:      	callq	*%rax
    175f:      	leaq	0x30(%rbp), %rdi
    1763:      	leaq	0x21c(%r15), %rdx
    176a:      	movl	$0x4, %eax
    176f:      	movl	$0x4, %esi
    1774:      	callq	*%rax
    1776:      	leaq	0x34(%rbp), %rdi
    177a:      	leaq	0x218(%r15), %rdx
    1781:      	movl	$0x4, %eax
    1786:      	movl	$0x4, %esi
    178b:      	callq	*%rax
    178d:      	leaq	0x10(%rbp), %r12
    1791:      	movq	$0x0, (%rbp)
    1799:      	movq	$0x0, 0x8(%rbp)
    17a1:      	movq	$0x0, 0x10(%rbp)
    17a9:      	movq	$0x0, 0x18(%rbp)
    17b1:      	movzwl	0x26(%rbp), %eax
    17b5:      	cmpl	$0xa, %eax
    17b8:      	je	0x2a05 <generic_fentry_process_event+0x2655>
    17be:      	cmpl	$0x2, %eax
    17c1:      	jne	0x2a37 <generic_fentry_process_event+0x2687>
    17c7:      	leaq	0x4(%r15), %rdx
    17cb:      	movl	$0x4, %ecx
    17d0:      	movl	$0x4, %eax
    17d5:      	movq	0x10(%rsp), %rdi
    17da:      	movl	$0x4, %esi
    17df:      	callq	*%rax
    17e1:      	movl	$0x4, %ecx
    17e6:      	movl	$0x4, %eax
    17eb:      	movq	%r12, %rdi
    17ee:      	movl	$0x4, %esi
    17f3:      	movq	%r15, %rdx
    17f6:      	jmp	0x2a35 <generic_fentry_process_event+0x2685>
    17fb:      	cmpl	$0x1a, %r12d
    17ff:      	je	0x2402 <generic_fentry_process_event+0x2052>
    1805:      	cmpl	$0x1b, %r12d
    1809:      	movq	0x8(%rsp), %rcx
    180e:      	movq	(%rsp), %rsi
    1812:      	jne	0x29cb <generic_fentry_process_event+0x261b>
    1818:      	movq	%rcx, %r12
    181b:      	movq	0x10(%rsp), %rax
    1820:      	movq	$0x0, 0x48(%rax)
    1828:      	movq	$0x0, 0x40(%rax)
    1830:      	movq	$0x0, 0x38(%rax)
    1838:      	movq	$0x0, 0x30(%rax)
    1840:      	movq	$0x0, 0x28(%rax)
    1848:      	movq	$0x0, 0x20(%rax)
    1850:      	movq	$0x0, 0x18(%rax)
    1858:      	movq	$0x0, 0x10(%rax)
    1860:      	movq	$0x0, 0x8(%rax)
    1868:      	movq	$0x0, (%rax)
    186f:      	leaq	0x10(%rax), %rdi
    1873:      	leaq	0x18(%r8), %rdx
    1877:      	movl	$0x3f, %ecx
    187c:      	movl	$0x2d, %eax
    1881:      	movl	$0x3f, %esi
    1886:      	callq	*%rax
    1888:      	testq	%rax, %rax
    188b:      	js	0x2979 <generic_fentry_process_event+0x25c9>
    1891:      	movq	0x10(%rsp), %rdi
    1896:      	addq	$0x8, %rdi
    189a:      	movq	0x20(%rsp), %rdx
    189f:      	addq	$0x348, %rdx            # imm = 0x348
    18a6:      	movl	$0x8, %ecx
    18ab:      	movl	$0x4, %eax
    18b0:      	movl	$0x8, %esi
    18b5:      	callq	*%rax
    18b7:      	movl	$0x50, %r15d
    18bd:      	movq	%r12, %rcx
    18c0:      	jmp	0x348e <generic_fentry_process_event+0x30de>
    18c5:      	movq	%r13, %rbp
    18c8:      	cmpl	$0x8, %r12d
    18cc:      	je	0x1fd3 <generic_fentry_process_event+0x1c23>
    18d2:      	cmpl	$0x12, %r12d
    18d6:      	movq	0x8(%rsp), %rcx
    18db:      	movq	%rbp, %r13
    18de:      	movq	0x18(%rsp), %rbp
    18e3:      	movq	(%rsp), %rsi
    18e7:      	movq	0x20(%rsp), %rdx
    18ec:      	jne	0x29cb <generic_fentry_process_event+0x261b>
    18f2:      	movq	0xc8(%rsp), %r12
    18fa:      	andl	$0x3ff, %r12d           # imm = 0x3FF
    1901:      	movq	%rcx, %r15
    1904:      	movl	$0x4, %eax
    1909:      	movq	0x10(%rsp), %rdi
    190e:      	movl	%r12d, %esi
    1911:      	callq	*%rax
    1913:      	movq	(%rsp), %rsi
    1917:      	movq	%r15, %rcx
    191a:      	movq	%r12, %r15
    191d:      	testl	%r15d, %r15d
    1920:      	js	0x34a5 <generic_fentry_process_event+0x30f5>
    1926:      	jmp	0x29d4 <generic_fentry_process_event+0x2624>
    192b:      	cmpl	$0x13, %r12d
    192f:      	je	0x2302 <generic_fentry_process_event+0x1f52>
    1935:      	cmpl	$0x14, %r12d
    1939:      	movq	0x8(%rsp), %rcx
    193e:      	movq	(%rsp), %rsi
    1942:      	movq	0x20(%rsp), %r8
    1947:      	jne	0x29cb <generic_fentry_process_event+0x261b>
    194d:      	movq	$0x0, 0x60(%rsp)
    1956:      	leaq	0x110(%r8), %rdx
    195d:      	leaq	0x60(%rsp), %rdi
    1962:      	movl	$0x8, %esi
    1967:      	movl	$0x4, %eax
    196c:      	leaq	0xd8(%r8), %rcx
    1973:      	movq	%rcx, 0x28(%rsp)
    1978:      	movl	$0x8, %esi
    197d:      	movq	%r8, %r15
    1980:      	callq	*%rax
    1982:      	movq	0x60(%rsp), %rcx
    1987:      	movl	$0x80, %edx
    198c:      	movl	$0x2d, %eax
    1991:      	movq	0x10(%rsp), %r12
    1996:      	movq	0x60(%rsp), %rdx
    199b:      	movq	%r12, %rdi
    199e:      	movl	$0x80, %esi
    19a3:      	callq	*%rax
    19a5:      	leaq	0x90(%r12), %rdi
    19ad:      	movl	$0x4, %ecx
    19b2:      	movl	$0x4, %eax
    19b7:      	movq	0x28(%rsp), %rdx
    19bc:      	movl	$0x4, %esi
    19c1:      	callq	*%rax
    19c3:      	leaq	0x80(%r12), %rdi
    19cb:      	leaq	0xe0(%r15), %rdx
    19d2:      	movl	$0x8, %ecx
    19d7:      	movl	$0x4, %eax
    19dc:      	movl	$0x8, %esi
    19e1:      	callq	*%rax
    19e3:      	addq	$0x88, %r12
    19ea:      	addq	$0x118, %r15            # imm = 0x118
    19f1:      	movl	$0x8, %ecx
    19f6:      	movl	$0x4, %eax
    19fb:      	movq	%r12, %rdi
    19fe:      	movl	$0x8, %esi
    1a03:      	movq	%r15, %rdx
    1a06:      	callq	*%rax
    1a08:      	movq	(%rsp), %rsi
    1a0c:      	movq	0x8(%rsp), %rcx
    1a11:      	movl	$0x98, %r15d
    1a17:      	testl	%r15d, %r15d
    1a1a:      	js	0x34a5 <generic_fentry_process_event+0x30f5>
    1a20:      	jmp	0x29d4 <generic_fentry_process_event+0x2624>
    1a25:      	cmpl	$0x26, %r12d
    1a29:      	movq	(%rsp), %rsi
    1a2d:      	jne	0x29c6 <generic_fentry_process_event+0x2616>
    1a33:      	movq	0x50(%rsp), %rsi
    1a38:      	movzwl	%si, %edx
    1a3b:      	addq	%rbx, %rdx
    1a3e:      	shrl	$0x10, %esi
    1a41:      	andl	$0xfff, %esi            # imm = 0xFFF
    1a47:      	movq	0x10(%rsp), %r13
    1a4c:      	leaq	0x4(%r13), %rdi
    1a50:      	incl	%esi
    1a52:      	movl	$0x2d, %eax
    1a57:      	jmp	0x1ead <generic_fentry_process_event+0x1afd>
    1a5c:      	movq	$0x0, 0x68(%rsp)
    1a65:      	movl	$0xe, %eax
    1a6a:      	callq	*%rax
    1a6c:      	shrq	$0x20, %rax
    1a70:      	movq	%rax, 0x60(%rsp)
    1a75:      	leaq	0xa0(%rsp), %rdi
    1a7d:      	leaq	0x50(%rsp), %rdx
    1a82:      	movl	$0x4, %ecx
    1a87:      	movl	$0x4, %eax
    1a8c:      	movl	$0x4, %r14d
    1a92:      	movl	$0x4, %esi
    1a97:      	callq	*%rax
    1a99:      	movl	0xa0(%rsp), %eax
    1aa0:      	movl	%eax, 0x68(%rsp)
    1aa4:      	movq	(%rip), %rdi            # 0x1aab <generic_fentry_process_event+0x16fb>
    1aab:      	leaq	0x60(%rsp), %rsi
    1ab0:      	movl	$0x1, %eax
    1ab5:      	callq	*%rax
    1ab7:      	testq	%rax, %rax
    1aba:      	je	0x2485 <generic_fentry_process_event+0x20d5>
    1ac0:      	movl	(%rax), %r15d
    1ac3:      	leaq	0xa0(%rsp), %rdx
    1acb:      	movq	%rax, %r12
    1ace:      	movl	$0x4, %eax
    1ad3:      	movq	0x10(%rsp), %rbp
    1ad8:      	movq	%rbp, %rdi
    1adb:      	movl	$0x4, %esi
    1ae0:      	callq	*%rax
    1ae2:      	andl	$0xfff, %r15d           # imm = 0xFFF
    1ae9:      	leaq	0x4(%rbp), %rdi
    1aed:      	leaq	0x4(%r15), %rsi
    1af1:      	movl	$0x4, %eax
    1af6:      	movq	%r12, %rdx
    1af9:      	callq	*%rax
    1afb:      	leaq	(%r15,%rbp), %rdi
    1aff:      	addq	$0x8, %rdi
    1b03:      	leaq	(%r15,%r12), %rdx
    1b07:      	addq	$0x4, %rdx
    1b0b:      	movl	$0x4, %eax
    1b10:      	movl	$0x4, %esi
    1b15:      	callq	*%rax
    1b17:      	addq	$0xc, %r15
    1b1b:      	jmp	0x273d <generic_fentry_process_event+0x238d>
    1b20:      	movq	%rbx, 0x58(%rsp)
    1b25:      	movq	0x50(%rsp), %r14
    1b2a:      	leaq	0xb8(%rsp), %rdi
    1b32:      	movl	$0x1, %ecx
    1b37:      	movl	$0x4, %eax
    1b3c:      	movl	$0x1, %esi
    1b41:      	movq	%r14, %rdx
    1b44:      	callq	*%rax
    1b46:      	movzbl	0xb8(%rsp), %eax
    1b4e:      	testl	%eax, %eax
    1b50:      	je	0x2491 <generic_fentry_process_event+0x20e1>
    1b56:      	cmpl	$0x1, %eax
    1b59:      	jne	0x2747 <generic_fentry_process_event+0x2397>
    1b5f:      	addq	$0x10, %r14
    1b63:      	leaq	0xa0(%rsp), %rdi
    1b6b:      	movl	$0x8, %r15d
    1b71:      	movl	$0x8, %ecx
    1b76:      	movl	$0x4, %eax
    1b7b:      	movl	$0x8, %esi
    1b80:      	movq	%r14, %rdx
    1b83:      	callq	*%rax
    1b85:      	movq	0xa0(%rsp), %rdx
    1b8d:      	leaq	0x38(%rsp), %rdi
    1b92:      	movl	$0x8, %ecx
    1b97:      	movl	$0x4, %eax
    1b9c:      	movl	$0x8, %esi
    1ba1:      	callq	*%rax
    1ba3:      	movq	0xa0(%rsp), %rdx
    1bab:      	addq	$0x8, %rdx
    1baf:      	leaq	0xc0(%rsp), %rdi
    1bb7:      	movl	$0x8, %ecx
    1bbc:      	movl	$0x4, %eax
    1bc1:      	movl	$0x8, %esi
    1bc6:      	callq	*%rax
    1bc8:      	movq	0x38(%rsp), %r14
    1bcd:      	movq	0xc0(%rsp), %rbx
    1bd5:      	movq	0x20(%rsp), %rax
    1bda:      	leaq	(%rax,%r13), %r12
    1bde:      	addq	$0x90, %r12
    1be5:      	testb	$0x20, 0x28(%rsp)
    1bea:      	je	0x3032 <generic_fentry_process_event+0x2c82>
    1bf0:      	cmpq	$0x1000, %rbx           # imm = 0x1000
    1bf7:      	jb	0x3006 <generic_fentry_process_event+0x2c56>
    1bfd:      	movl	$0x1, (%r12)
    1c05:      	movl	$0x0, 0xd0(%rsp)
    1c10:      	movq	(%rip), %rdi            # 0x1c17 <generic_fentry_process_event+0x1867>
    1c17:      	leaq	0xd0(%rsp), %rsi
    1c1f:      	movl	$0x1, %eax
    1c24:      	callq	*%rax
    1c26:      	testq	%rax, %rax
    1c29:      	je	0x31a5 <generic_fentry_process_event+0x2df5>
    1c2f:      	movq	%rax, %r13
    1c32:      	movl	$0x18, (%rax)
    1c38:      	movl	$0xe, %eax
    1c3d:      	callq	*%rax
    1c3f:      	movq	%r13, %r15
    1c42:      	addq	$0x10, %r15
    1c46:      	movq	%rax, 0x10(%r13)
    1c4a:      	cmpq	$-0x16, %rax
    1c4e:      	jne	0x1c77 <generic_fentry_process_event+0x18c7>
    1c50:      	movq	0x58(%rsp), %rax
    1c55:      	leaq	0x20(%rax), %rdx
    1c59:      	leaq	0x60(%rsp), %rdi
    1c5e:      	movl	$0x8, %ecx
    1c63:      	movl	$0x4, %eax
    1c68:      	movl	$0x8, %esi
    1c6d:      	callq	*%rax
    1c6f:      	movq	0x60(%rsp), %rax
    1c74:      	movq	%rax, (%r15)
    1c77:      	movl	$0x7d, %eax
    1c7c:      	callq	*%rax
    1c7e:      	movq	%rax, 0x18(%r13)
    1c82:      	movq	(%r15), %rax
    1c85:      	movq	0x8(%r15), %rcx
    1c89:      	movq	%rax, 0x14(%r12)
    1c8e:      	movq	%rcx, 0x1c(%r12)
    1c93:      	movq	0x58(%rsp), %rdi
    1c98:      	movq	%r13, %rsi
    1c9b:      	movq	%r14, %rdx
    1c9e:      	movq	%rbx, %rcx
    1ca1:      	callq	0x1ca6 <generic_fentry_process_event+0x18f6>
    1ca6:      	testl	%eax, %eax
    1ca8:      	js	0x3357 <generic_fentry_process_event+0x2fa7>
    1cae:      	movq	$0x0, 0x4(%r12)
    1cb7:      	movl	%ebx, %edx
    1cb9:      	subl	%eax, %edx
    1cbb:      	xorl	%ecx, %ecx
    1cbd:      	cmpq	$-0x1, %rbx
    1cc1:      	jmp	0x25d6 <generic_fentry_process_event+0x2226>
    1cc6:      	movq	%rbx, 0x58(%rsp)
    1ccb:      	movq	0x50(%rsp), %r12
    1cd0:      	movq	0x10(%rsp), %rbx
    1cd5:      	leaq	0x28(%rbx), %rdi
    1cd9:      	leaq	0x98(%r12), %rdx
    1ce1:      	movl	$0x4, %ecx
    1ce6:      	movl	$0x4, %eax
    1ceb:      	movl	$0x4, %esi
    1cf0:      	callq	*%rax
    1cf2:      	leaq	0x2c(%rbx), %rdi
    1cf6:      	leaq	0x70(%r12), %rdx
    1cfb:      	movl	$0x4, %ecx
    1d00:      	movl	$0x4, %eax
    1d05:      	movl	$0x4, %esi
    1d0a:      	callq	*%rax
    1d0c:      	leaq	0x30(%rbx), %rdi
    1d10:      	leaq	0x90(%r12), %rdx
    1d18:      	movl	$0x4, %ecx
    1d1d:      	movl	$0x4, %eax
    1d22:      	movl	$0x4, %esi
    1d27:      	callq	*%rax
    1d29:      	leaq	0x34(%rbx), %rdi
    1d2d:      	leaq	0xa8(%r12), %rdx
    1d35:      	movl	$0x4, %ecx
    1d3a:      	movl	$0x4, %eax
    1d3f:      	movl	$0x4, %esi
    1d44:      	callq	*%rax
    1d46:      	movq	$0x0, 0x60(%rsp)
    1d4f:      	leaq	0xc8(%r12), %rdx
    1d57:      	leaq	0x60(%rsp), %rdi
    1d5c:      	movl	$0x8, %ecx
    1d61:      	movl	$0x4, %eax
    1d66:      	movl	$0x8, %esi
    1d6b:      	callq	*%rax
    1d6d:      	leaq	0xb8(%r12), %rdx
    1d75:      	leaq	0xc0(%rsp), %rdi
    1d7d:      	movl	$0x2, %ecx
    1d82:      	movl	$0x4, %eax
    1d87:      	movl	$0x2, %esi
    1d8c:      	callq	*%rax
    1d8e:      	movzwl	0xc0(%rsp), %r15d
    1d97:      	addq	0x60(%rsp), %r15
    1d9c:      	leaq	0xbf(%rsp), %rdi
    1da4:      	movl	$0x1, %ecx
    1da9:      	movl	$0x4, %eax
    1dae:      	movl	$0x1, %esi
    1db3:      	movq	%r15, %rdx
    1db6:      	callq	*%rax
    1db8:      	movzbl	0xbf(%rsp), %eax
    1dc0:      	shrl	$0x4, %eax
    1dc3:      	cmpl	$0x6, %eax
    1dc6:      	je	0x25de <generic_fentry_process_event+0x222e>
    1dcc:      	cmpl	$0x4, %eax
    1dcf:      	jne	0x3b5d <generic_fentry_process_event+0x37ad>
    1dd5:      	leaq	0x9(%r15), %rdx
    1dd9:      	leaq	0xb8(%rsp), %rdi
    1de1:      	movl	$0x1, %ecx
    1de6:      	movl	$0x4, %eax
    1deb:      	movl	$0x1, %esi
    1df0:      	callq	*%rax
    1df2:      	movzbl	0xb8(%rsp), %eax
    1dfa:      	movq	0x10(%rsp), %rdi
    1dff:      	movw	%ax, 0x24(%rdi)
    1e03:      	movw	$0x2, 0x26(%rdi)
    1e09:      	leaq	0xc(%r15), %rdx
    1e0d:      	movq	$0x0, (%rdi)
    1e14:      	movq	$0x0, 0x8(%rdi)
    1e1c:      	movq	$0x0, 0x10(%rdi)
    1e24:      	movq	$0x0, 0x18(%rdi)
    1e2c:      	movl	$0x4, %ecx
    1e31:      	movl	$0x4, %eax
    1e36:      	leaq	0x10(%rdi), %rbx
    1e3a:      	movl	$0x4, %esi
    1e3f:      	callq	*%rax
    1e41:      	addq	$0x10, %r15
    1e45:      	movl	$0x4, %ecx
    1e4a:      	movl	$0x4, %eax
    1e4f:      	movq	%rbx, %rdi
    1e52:      	movl	$0x4, %esi
    1e57:      	movq	%r15, %rdx
    1e5a:      	callq	*%rax
    1e5c:      	leaq	0xb6(%r12), %rdx
    1e64:      	leaq	0xd0(%rsp), %rdi
    1e6c:      	movl	$0x2, %ecx
    1e71:      	movl	$0x4, %eax
    1e76:      	movl	$0x2, %esi
    1e7b:      	callq	*%rax
    1e7d:      	movzbl	0xb8(%rsp), %r15d
    1e86:      	jmp	0x39f5 <generic_fentry_process_event+0x3645>
    1e8b:      	movl	$0x120, %edx            # imm = 0x120
    1e90:      	addq	0x50(%rsp), %rdx
    1e95:      	movq	0x10(%rsp), %r13
    1e9a:      	leaq	0x4(%r13), %rdi
    1e9e:      	movl	$0x11, %ecx
    1ea3:      	movl	$0x2d, %eax
    1ea8:      	movl	$0x11, %esi
    1ead:      	callq	*%rax
    1eaf:      	movq	%rax, %r15
    1eb2:      	testq	%rax, %rax
    1eb5:      	js	0x29bd <generic_fentry_process_event+0x260d>
    1ebb:      	leal	-0x1(%r15), %eax
    1ebf:      	movl	%eax, (%r13)
    1ec3:      	addq	$0x3, %r15
    1ec7:      	jmp	0x29bd <generic_fentry_process_event+0x260d>
    1ecc:      	movq	0x50(%rsp), %r15
    1ed1:      	movq	0x10(%rsp), %r12
    1ed6:      	movq	$0x0, 0x10(%r12)
    1edf:      	movq	$0x0, 0x8(%r12)
    1ee8:      	movq	$0x0, (%r12)
    1ef0:      	movl	$0x2, %ecx
    1ef5:      	movl	$0x4, %eax
    1efa:      	movq	%r12, %rdi
    1efd:      	movl	$0x2, %esi
    1f02:      	movq	%r15, %rdx
    1f05:      	callq	*%rax
    1f07:      	testq	%rax, %rax
    1f0a:      	js	0x28a5 <generic_fentry_process_event+0x24f5>
    1f10:      	movzwl	(%r12), %eax
    1f15:      	cmpl	$0xa, %eax
    1f18:      	je	0x284e <generic_fentry_process_event+0x249e>
    1f1e:      	cmpl	$0x2, %eax
    1f21:      	jne	0x288a <generic_fentry_process_event+0x24da>
    1f27:      	leaq	0x4(%r15), %rdx
    1f2b:      	leaq	0x60(%rsp), %rdi
    1f30:      	movl	$0x4, %ecx
    1f35:      	movl	$0x4, %eax
    1f3a:      	movl	$0x4, %esi
    1f3f:      	callq	*%rax
    1f41:      	movl	0x60(%rsp), %eax
    1f45:      	movq	0x10(%rsp), %rcx
    1f4a:      	movq	%rax, 0x8(%rcx)
    1f4e:      	leaq	0x2(%rcx), %rdi
    1f52:      	addq	$0x2, %r15
    1f56:      	movl	$0x2, %ecx
    1f5b:      	movl	$0x4, %eax
    1f60:      	jmp	0x2880 <generic_fentry_process_event+0x24d0>
    1f65:      	movq	%rbx, 0x58(%rsp)
    1f6a:      	movq	0xb0(%rsp), %rax
    1f72:      	movq	%rcx, %r13
    1f75:      	leaq	(%rcx,%rax), %rbx
    1f79:      	addq	$0x90, %rbx
    1f80:      	movq	$0x0, 0x50(%rsp)
    1f89:      	testb	$0x10, 0x28(%rsp)
    1f8e:      	jne	0x2763 <generic_fentry_process_event+0x23b3>
    1f94:      	movq	0x28(%rsp), %rdx
    1f99:      	movl	%edx, %ebp
    1f9b:      	andl	$0xf, %edx
    1f9e:      	xorl	%eax, %eax
    1fa0:      	movq	%rdx, %rcx
    1fa3:      	cmpl	$0x2, %edx
    1fa6:      	jle	0x29e7 <generic_fentry_process_event+0x2637>
    1fac:      	cmpl	$0x3, %ecx
    1faf:      	je	0x31c0 <generic_fentry_process_event+0x2e10>
    1fb5:      	cmpl	$0x4, %ecx
    1fb8:      	je	0x31c9 <generic_fentry_process_event+0x2e19>
    1fbe:      	cmpl	$0x5, %ecx
    1fc1:      	jne	0x31dc <generic_fentry_process_event+0x2e2c>
    1fc7:      	leaq	0x5e70(%r13), %rax
    1fce:      	jmp	0x31d9 <generic_fentry_process_event+0x2e29>
    1fd3:      	movq	0x10(%rsp), %r15
    1fd8:      	leaq	0x28(%r15), %r13
    1fdc:      	leaq	0x40(%r15), %rax
    1fe0:      	movq	%rax, 0x28(%rsp)
    1fe5:      	movq	0x20(%rsp), %r12
    1fea:      	leaq	0x8(%r12), %rdx
    1fef:      	movl	$0x4, %ecx
    1ff4:      	movl	$0x4, %eax
    1ff9:      	movq	%r15, %rdi
    1ffc:      	movl	$0x4, %esi
    2001:      	callq	*%rax
    2003:      	leaq	0x4(%r15), %rdi
    2007:      	leaq	0xc(%r12), %rdx
    200c:      	movl	$0x4, %ecx
    2011:      	movl	$0x4, %eax
    2016:      	movl	$0x4, %esi
    201b:      	callq	*%rax
    201d:      	leaq	0x10(%r15), %rdi
    2021:      	leaq	0x18(%r12), %rdx
    2026:      	movl	$0x4, %ecx
    202b:      	movl	$0x4, %eax
    2030:      	movl	$0x4, %esi
    2035:      	callq	*%rax
    2037:      	leaq	0x14(%r15), %rdi
    203b:      	leaq	0x1c(%r12), %rdx
    2040:      	movl	$0x4, %ecx
    2045:      	movl	$0x4, %eax
    204a:      	movl	$0x4, %esi
    204f:      	callq	*%rax
    2051:      	leaq	0x8(%r15), %rdi
    2055:      	leaq	0x10(%r12), %rdx
    205a:      	movl	$0x4, %ecx
    205f:      	movl	$0x4, %eax
    2064:      	movl	$0x4, %esi
    2069:      	callq	*%rax
    206b:      	leaq	0xc(%r15), %rdi
    206f:      	leaq	0x14(%r12), %rdx
    2074:      	movl	$0x4, %ecx
    2079:      	movl	$0x4, %eax
    207e:      	movl	$0x4, %esi
    2083:      	callq	*%rax
    2085:      	leaq	0x18(%r15), %rdi
    2089:      	leaq	0x20(%r12), %rdx
    208e:      	movl	$0x4, %ecx
    2093:      	movl	$0x4, %eax
    2098:      	movl	$0x4, %esi
    209d:      	callq	*%rax
    209f:      	leaq	0x1c(%r15), %rdi
    20a3:      	leaq	0x24(%r12), %rdx
    20a8:      	movl	$0x4, %ecx
    20ad:      	movl	$0x4, %eax
    20b2:      	movl	$0x4, %esi
    20b7:      	callq	*%rax
    20b9:      	movl	$0x0, 0x24(%r15)
    20c1:      	leaq	0x20(%r15), %rdi
    20c5:      	leaq	0x28(%r12), %rdx
    20ca:      	movl	$0x4, %ecx
    20cf:      	movl	$0x4, %eax
    20d4:      	movl	$0x4, %esi
    20d9:      	callq	*%rax
    20db:      	leaq	0x30(%r15), %rdi
    20df:      	leaq	0x40(%r12), %rdx
    20e4:      	movl	$0x8, %ecx
    20e9:      	movl	$0x4, %eax
    20ee:      	movl	$0x8, %esi
    20f3:      	callq	*%rax
    20f5:      	leaq	0x38(%r15), %rdi
    20f9:      	leaq	0x30(%r12), %rdx
    20fe:      	movl	$0x8, %ecx
    2103:      	movl	$0x4, %eax
    2108:      	movl	$0x8, %esi
    210d:      	callq	*%rax
    210f:      	leaq	0x38(%r12), %rdx
    2114:      	movl	$0x8, %ecx
    2119:      	movl	$0x4, %eax
    211e:      	movq	%r13, %rdi
    2121:      	movl	$0x8, %esi
    2126:      	callq	*%rax
    2128:      	addq	$0x90, %r12
    212f:      	leaq	0x60(%rsp), %rdi
    2134:      	movl	$0x8, %ecx
    2139:      	movl	$0x4, %eax
    213e:      	movl	$0x8, %esi
    2143:      	movq	%r12, %rdx
    2146:      	callq	*%rax
    2148:      	movq	0x60(%rsp), %r12
    214d:      	leaq	0xc8(%r12), %rdx
    2155:      	movl	$0x4, %ecx
    215a:      	movl	$0x4, %eax
    215f:      	movq	0x28(%rsp), %rdi
    2164:      	movl	$0x4, %esi
    2169:      	callq	*%rax
    216b:      	leaq	0x44(%r15), %rdi
    216f:      	leaq	0xcc(%r12), %rdx
    2177:      	movl	$0x4, %ecx
    217c:      	movl	$0x4, %eax
    2181:      	movl	$0x4, %esi
    2186:      	callq	*%rax
    2188:      	leaq	0x48(%r15), %rdi
    218c:      	leaq	0xd0(%r12), %rdx
    2194:      	movl	$0x4, %ecx
    2199:      	movl	$0x4, %eax
    219e:      	movl	$0x4, %esi
    21a3:      	callq	*%rax
    21a5:      	addq	$0x4c, %r15
    21a9:      	addq	$0x158, %r12            # imm = 0x158
    21b0:      	movl	$0x4, %ecx
    21b5:      	movl	$0x4, %eax
    21ba:      	movq	%r15, %rdi
    21bd:      	movl	$0x4, %esi
    21c2:      	movq	%r12, %rdx
    21c5:      	callq	*%rax
    21c7:      	movl	$0x50, %r15d
    21cd:      	movq	0x8(%rsp), %rcx
    21d2:      	movq	%rbp, %r13
    21d5:      	jmp	0x11d5 <generic_fentry_process_event+0xe25>
    21da:      	movq	0x20(%rsp), %r12
    21df:      	leaq	0xc8(%r12), %rdx
    21e7:      	movl	$0x4, %ecx
    21ec:      	movl	$0x4, %eax
    21f1:      	movq	0x10(%rsp), %r15
    21f6:      	movq	%r15, %rdi
    21f9:      	movl	$0x4, %esi
    21fe:      	callq	*%rax
    2200:      	leaq	0x4(%r15), %rdi
    2204:      	leaq	0xcc(%r12), %rdx
    220c:      	movl	$0x4, %ecx
    2211:      	movl	$0x4, %eax
    2216:      	movl	$0x4, %esi
    221b:      	callq	*%rax
    221d:      	leaq	0x8(%r15), %rdi
    2221:      	leaq	0xd0(%r12), %rdx
    2229:      	movl	$0x4, %ecx
    222e:      	movl	$0x4, %eax
    2233:      	movl	$0x4, %esi
    2238:      	callq	*%rax
    223a:      	addq	$0xc, %r15
    223e:      	addq	$0x158, %r12            # imm = 0x158
    2245:      	movl	$0x4, %ecx
    224a:      	movl	$0x4, %eax
    224f:      	movq	%r15, %rdi
    2252:      	movl	$0x4, %esi
    2257:      	movq	%r12, %rdx
    225a:      	callq	*%rax
    225c:      	movl	$0x10, %r15d
    2262:      	jmp	0x23f8 <generic_fentry_process_event+0x2048>
    2267:      	movq	0x20(%rsp), %r12
    226c:      	leaq	0x38(%r12), %rdx
    2271:      	movl	$0x4, %ecx
    2276:      	movl	$0x4, %eax
    227b:      	movq	0x10(%rsp), %r15
    2280:      	movq	%r15, %rdi
    2283:      	movl	$0x4, %esi
    2288:      	callq	*%rax
    228a:      	leaq	0x4(%r15), %rdi
    228e:      	leaq	0x3c(%r12), %rdx
    2293:      	movl	$0x4, %ecx
    2298:      	movl	$0x4, %eax
    229d:      	movl	$0x4, %esi
    22a2:      	callq	*%rax
    22a4:      	leaq	0x8(%r15), %rdi
    22a8:      	leaq	0x40(%r12), %rdx
    22ad:      	movl	$0x4, %ecx
    22b2:      	movl	$0x4, %eax
    22b7:      	movl	$0x4, %esi
    22bc:      	callq	*%rax
    22be:      	leaq	0xc(%r15), %rdi
    22c2:      	leaq	0x44(%r12), %rdx
    22c7:      	movl	$0x4, %ecx
    22cc:      	movl	$0x4, %eax
    22d1:      	movl	$0x4, %esi
    22d6:      	callq	*%rax
    22d8:      	addq	$0x10, %r15
    22dc:      	subq	$-0x80, %r12
    22e0:      	movl	$0x10, %ecx
    22e5:      	movl	$0x4, %eax
    22ea:      	movq	%r15, %rdi
    22ed:      	movl	$0x10, %esi
    22f2:      	movq	%r12, %rdx
    22f5:      	callq	*%rax
    22f7:      	movl	$0x20, %r15d
    22fd:      	jmp	0x23f8 <generic_fentry_process_event+0x2048>
    2302:      	movl	$0x4, %ecx
    2307:      	movl	$0x4, %eax
    230c:      	movq	0x10(%rsp), %r15
    2311:      	movq	0x20(%rsp), %r12
    2316:      	movq	%r15, %rdi
    2319:      	movl	$0x4, %esi
    231e:      	movq	%r12, %rdx
    2321:      	callq	*%rax
    2323:      	leaq	0x4(%r15), %rdi
    2327:      	leaq	0x4(%r12), %rdx
    232c:      	movl	$0x4, %ecx
    2331:      	movl	$0x4, %eax
    2336:      	movl	$0x4, %esi
    233b:      	callq	*%rax
    233d:      	addq	$0x8, %r15
    2341:      	addq	$0x30, %r12
    2345:      	movl	$0x10, %ecx
    234a:      	movl	$0x4, %eax
    234f:      	movq	%r15, %rdi
    2352:      	movl	$0x10, %esi
    2357:      	movq	%r12, %rdx
    235a:      	jmp	0x23f0 <generic_fentry_process_event+0x2040>
    235f:      	leaq	0x4(%r8), %rdx
    2363:      	leaq	0x60(%rsp), %rdi
    2368:      	movl	$0x4, %ecx
    236d:      	movl	$0x4, %eax
    2372:      	movl	$0x4, %esi
    2377:      	movq	%r8, %r12
    237a:      	callq	*%rax
    237c:      	movl	0x60(%rsp), %eax
    2380:      	movq	0x10(%rsp), %r15
    2385:      	movl	%eax, (%r15)
    2388:      	leaq	0xc(%r12), %rdx
    238d:      	leaq	0x60(%rsp), %rdi
    2392:      	movl	$0x4, %ecx
    2397:      	movl	$0x4, %eax
    239c:      	movl	$0x4, %esi
    23a1:      	callq	*%rax
    23a3:      	movl	0x60(%rsp), %eax
    23a7:      	movl	%eax, 0x4(%r15)
    23ab:      	addq	$0x50, %r12
    23af:      	leaq	0x60(%rsp), %rdi
    23b4:      	movl	$0x8, %ecx
    23b9:      	movl	$0x2d, %eax
    23be:      	movl	$0x8, %esi
    23c3:      	movq	%r12, %rdx
    23c6:      	callq	*%rax
    23c8:      	addq	$0x8, %r15
    23cc:      	movl	$0x3f8, %edx            # imm = 0x3F8
    23d1:      	movq	0x60(%rsp), %rcx
    23d6:      	addq	%rdx, %rcx
    23d9:      	movl	$0x10, %esi
    23de:      	movl	$0x2d, %eax
    23e3:      	addq	0x60(%rsp), %rdx
    23e8:      	movq	%r15, %rdi
    23eb:      	movl	$0x10, %esi
    23f0:      	callq	*%rax
    23f2:      	movl	$0x18, %r15d
    23f8:      	movq	0x8(%rsp), %rcx
    23fd:      	jmp	0x11da <generic_fentry_process_event+0xe2a>
    2402:      	movq	0x10(%rsp), %rax
    2407:      	movq	$0x0, 0x48(%rax)
    240f:      	movq	$0x0, 0x40(%rax)
    2417:      	movq	$0x0, 0x38(%rax)
    241f:      	movq	$0x0, 0x30(%rax)
    2427:      	movq	$0x0, 0x28(%rax)
    242f:      	movq	$0x0, 0x20(%rax)
    2437:      	movq	$0x0, 0x18(%rax)
    243f:      	movq	$0x0, 0x10(%rax)
    2447:      	movq	$0x0, 0x8(%rax)
    244f:      	movq	$0x0, (%rax)
    2456:      	leaq	0x60(%rsp), %rdi
    245b:      	movl	$0x8, %ecx
    2460:      	movl	$0x4, %eax
    2465:      	movl	$0x8, %esi
    246a:      	movq	%r8, %rdx
    246d:      	callq	*%rax
    246f:      	testq	%rax, %rax
    2472:      	je	0x28b0 <generic_fentry_process_event+0x2500>
    2478:      	xorl	%r15d, %r15d
    247b:      	movq	0x8(%rsp), %rcx
    2480:      	jmp	0x348e <generic_fentry_process_event+0x30de>
    2485:      	movq	$-0x1, %r15
    248c:      	jmp	0x273d <generic_fentry_process_event+0x238d>
    2491:      	leaq	0x10(%r14), %rdx
    2495:      	leaq	0x38(%rsp), %rdi
    249a:      	movl	$0x8, %ebx
    249f:      	movl	$0x8, %ecx
    24a4:      	movl	$0x4, %eax
    24a9:      	movl	$0x8, %esi
    24ae:      	callq	*%rax
    24b0:      	addq	$0x18, %r14
    24b4:      	leaq	0xc0(%rsp), %rdi
    24bc:      	movl	$0x8, %ecx
    24c1:      	movl	$0x4, %eax
    24c6:      	movl	$0x8, %esi
    24cb:      	movq	%r14, %rdx
    24ce:      	callq	*%rax
    24d0:      	movq	0x38(%rsp), %rax
    24d5:      	movq	%rax, 0x28(%rsp)
    24da:      	movq	0xc0(%rsp), %r14
    24e2:      	movq	0x20(%rsp), %rax
    24e7:      	leaq	(%rax,%r13), %r12
    24eb:      	addq	$0x90, %r12
    24f2:      	testb	$0x20, 0xc8(%rsp)
    24fa:      	je	0x30a6 <generic_fentry_process_event+0x2cf6>
    2500:      	cmpq	$0x1000, %r14           # imm = 0x1000
    2507:      	jb	0x307b <generic_fentry_process_event+0x2ccb>
    250d:      	movl	$0x1, (%r12)
    2515:      	movl	$0x0, 0xd0(%rsp)
    2520:      	movq	(%rip), %rdi            # 0x2527 <generic_fentry_process_event+0x2177>
    2527:      	leaq	0xd0(%rsp), %rsi
    252f:      	movl	$0x1, %eax
    2534:      	callq	*%rax
    2536:      	testq	%rax, %rax
    2539:      	je	0x31a5 <generic_fentry_process_event+0x2df5>
    253f:      	movq	%rax, %r15
    2542:      	movl	$0x18, (%rax)
    2548:      	movl	$0xe, %eax
    254d:      	callq	*%rax
    254f:      	movq	%r15, %r13
    2552:      	addq	$0x10, %r13
    2556:      	movq	%rax, 0x10(%r15)
    255a:      	cmpq	$-0x16, %rax
    255e:      	jne	0x2588 <generic_fentry_process_event+0x21d8>
    2560:      	movq	0x58(%rsp), %rax
    2565:      	leaq	0x20(%rax), %rdx
    2569:      	leaq	0x60(%rsp), %rdi
    256e:      	movl	$0x8, %ecx
    2573:      	movl	$0x4, %eax
    2578:      	movl	$0x8, %esi
    257d:      	callq	*%rax
    257f:      	movq	0x60(%rsp), %rax
    2584:      	movq	%rax, (%r13)
    2588:      	movl	$0x7d, %eax
    258d:      	callq	*%rax
    258f:      	movq	%rax, 0x18(%r15)
    2593:      	movq	(%r13), %rax
    2597:      	movq	0x8(%r13), %rcx
    259b:      	movq	%rax, 0x14(%r12)
    25a0:      	movq	%rcx, 0x1c(%r12)
    25a5:      	movq	0x58(%rsp), %rdi
    25aa:      	movq	%r15, %rsi
    25ad:      	movq	0x28(%rsp), %rdx
    25b2:      	movq	%r14, %rcx
    25b5:      	callq	0x25ba <generic_fentry_process_event+0x220a>
    25ba:      	testl	%eax, %eax
    25bc:      	js	0x3357 <generic_fentry_process_event+0x2fa7>
    25c2:      	movq	$0x0, 0x4(%r12)
    25cb:      	movl	%r14d, %edx
    25ce:      	subl	%eax, %edx
    25d0:      	xorl	%ecx, %ecx
    25d2:      	cmpq	$-0x1, %r14
    25d6:      	cmovnel	%edx, %ecx
    25d9:      	jmp	0x3369 <generic_fentry_process_event+0x2fb9>
    25de:      	movq	0x60(%rsp), %rbx
    25e3:      	movl	$0x0, 0xa0(%rsp)
    25ee:      	movzwl	0xc0(%rsp), %r15d
    25f7:      	movq	(%rip), %rdi            # 0x25fe <generic_fentry_process_event+0x224e>
    25fe:      	leaq	0xa0(%rsp), %rsi
    2606:      	movl	$0x1, %eax
    260b:      	leaq	(%rbx,%r15), %r13
    260f:      	callq	*%rax
    2611:      	testq	%rax, %rax
    2614:      	je	0x39a3 <generic_fentry_process_event+0x35f3>
    261a:      	movq	%rax, %rbp
    261d:      	movw	%r15w, (%rax)
    2621:      	movb	$-0x1, 0x5(%rax)
    2625:      	movb	$0x0, 0x7(%rax)
    2629:      	movq	%rax, %rdi
    262c:      	addq	$0x6, %rdi
    2630:      	leaq	0x6(%r13), %rdx
    2634:      	movl	$0x1, %ecx
    2639:      	movl	$0x4, %eax
    263e:      	movq	%rdi, 0x20(%rsp)
    2643:      	movl	$0x1, %esi
    2648:      	callq	*%rax
    264a:      	testq	%rax, %rax
    264d:      	js	0x39a3 <generic_fentry_process_event+0x35f3>
    2653:      	movzbl	0x5(%rbp), %eax
    2657:      	cmpl	$0x32, %eax
    265a:      	jg	0x30f4 <generic_fentry_process_event+0x2d44>
    2660:      	testl	%eax, %eax
    2662:      	je	0x31b0 <generic_fentry_process_event+0x2e00>
    2668:      	cmpl	$0x2b, %eax
    266b:      	je	0x31b0 <generic_fentry_process_event+0x2e00>
    2671:      	cmpl	$0x2c, %eax
    2674:      	jne	0x3459 <generic_fentry_process_event+0x30a9>
    267a:      	movw	$0x8, 0x2(%rbp)
    2680:      	movw	$0x8, %ax
    2684:      	jmp	0x3398 <generic_fentry_process_event+0x2fe8>
    2689:      	leaq	0x48(%r15), %rdx
    268d:      	movl	$0x10, %ecx
    2692:      	movl	$0x4, %eax
    2697:      	movq	%rbp, %rdi
    269a:      	movl	$0x10, %esi
    269f:      	callq	*%rax
    26a1:      	leaq	0x38(%r15), %rdx
    26a5:      	movl	$0x10, %ecx
    26aa:      	movl	$0x4, %eax
    26af:      	movq	%r12, %rdi
    26b2:      	movl	$0x10, %esi
    26b7:      	callq	*%rax
    26b9:      	leaq	0x20(%rbp), %rdi
    26bd:      	leaq	0xc(%r15), %r12
    26c1:      	addq	$0xe, %r15
    26c5:      	movl	$0x2, %ecx
    26ca:      	movl	$0x4, %eax
    26cf:      	movl	$0x2, %esi
    26d4:      	movq	%r15, %rdx
    26d7:      	callq	*%rax
    26d9:      	leaq	0x22(%rbp), %rdi
    26dd:      	movl	$0x2, %ecx
    26e2:      	movl	$0x4, %eax
    26e7:      	movl	$0x2, %esi
    26ec:      	movq	%r12, %rdx
    26ef:      	callq	*%rax
    26f1:      	movzwl	0x22(%rbp), %eax
    26f5:      	movbew	%ax, 0x22(%rbp)
    26fb:      	movq	0x50(%rsp), %rax
    2700:      	movq	%rax, 0x60(%rsp)
    2705:      	movq	(%rip), %rdi            # 0x270c <generic_fentry_process_event+0x235c>
    270c:      	leaq	0x60(%rsp), %rsi
    2711:      	movl	$0x1, %eax
    2716:      	callq	*%rax
    2718:      	testq	%rax, %rax
    271b:      	je	0x2737 <generic_fentry_process_event+0x2387>
    271d:      	movl	(%rax), %ecx
    271f:      	movq	0x20(%rsp), %r13
    2724:      	movl	%ecx, 0x10(%r13)
    2728:      	movq	0x8(%rax), %rcx
    272c:      	movq	%rcx, 0x18(%r13)
    2730:      	movl	0x4(%rax), %eax
    2733:      	movl	%eax, 0x7c(%r13)
    2737:      	movl	$0x40, %r15d
    273d:      	movq	0x8(%rsp), %rcx
    2742:      	jmp	0x3b6d <generic_fentry_process_event+0x37bd>
    2747:      	movq	0x20(%rsp), %rax
    274c:      	movq	$0x0, 0x90(%rax,%r13)
    2758:      	movl	$0x8, %r15d
    275e:      	jmp	0x3b63 <generic_fentry_process_event+0x37b3>
    2763:      	movl	$0xe, %eax
    2768:      	callq	*%rax
    276a:      	cmpq	$-0x16, %rax
    276e:      	jne	0x2794 <generic_fentry_process_event+0x23e4>
    2770:      	movq	0x58(%rsp), %rax
    2775:      	leaq	0x20(%rax), %rdx
    2779:      	leaq	0x60(%rsp), %rdi
    277e:      	movl	$0x8, %ecx
    2783:      	movl	$0x4, %eax
    2788:      	movl	$0x8, %esi
    278d:      	callq	*%rax
    278f:      	movq	0x60(%rsp), %rax
    2794:      	movq	0x8(%r13), %rcx
    2798:      	movq	0x60(%r13), %rdx
    279c:      	movq	%rcx, 0x60(%rsp)
    27a1:      	movq	0x20(%rsp), %rcx
    27a6:      	movq	%rcx, 0x68(%rsp)
    27ab:      	movq	$0x0, 0x70(%rsp)
    27b4:      	movq	%rdx, 0xa0(%rsp)
    27bc:      	movq	%rax, 0xa8(%rsp)
    27c4:      	movq	(%rip), %rdi            # 0x27cb <generic_fentry_process_event+0x241b>
    27cb:      	xorl	%ecx, %ecx
    27cd:      	leaq	0xa0(%rsp), %rsi
    27d5:      	leaq	0x60(%rsp), %rdx
    27da:      	movl	$0x2, %eax
    27df:      	xorl	%ecx, %ecx
    27e1:      	callq	*%rax
    27e3:      	testq	%rax, %rax
    27e6:      	je	0x314a <generic_fentry_process_event+0x2d9a>
    27ec:      	negl	%eax
    27ee:      	movw	%ax, 0x38(%rsp)
    27f3:      	movw	$0x5, 0x3a(%rsp)
    27fa:      	movabsq	$0x200000046, %rax      # imm = 0x200000046
    2804:      	movq	%rax, 0x3c(%rsp)
    2809:      	movq	(%rip), %rdi            # 0x2810 <generic_fentry_process_event+0x2460>
    2810:      	leaq	0x38(%rsp), %rsi
    2815:      	movl	$0x1, %eax
    281a:      	callq	*%rax
    281c:      	testq	%rax, %rax
    281f:      	je	0x3120 <generic_fentry_process_event+0x2d70>
    2825:      	incl	(%rax)
    2827:      	jmp	0x314a <generic_fentry_process_event+0x2d9a>
    282c:      	cmpl	$0x1, %eax
    282f:      	je	0x2ae4 <generic_fentry_process_event+0x2734>
    2835:      	cmpl	$0x2, %eax
    2838:      	jne	0x2f09 <generic_fentry_process_event+0x2b59>
    283e:      	movq	0x28(%rsp), %rax
    2843:      	addq	$0x5e58, %rax           # imm = 0x5E58
    2849:      	jmp	0x2aef <generic_fentry_process_event+0x273f>
    284e:      	movq	0x10(%rsp), %r12
    2853:      	leaq	0x8(%r12), %rdi
    2858:      	leaq	0x8(%r15), %rdx
    285c:      	movl	$0x10, %ecx
    2861:      	movl	$0x4, %eax
    2866:      	movl	$0x10, %esi
    286b:      	callq	*%rax
    286d:      	leaq	0x2(%r12), %rdi
    2872:      	addq	$0x2, %r15
    2876:      	movl	$0x2, %ecx
    287b:      	movl	$0x4, %eax
    2880:      	movl	$0x2, %esi
    2885:      	movq	%r15, %rdx
    2888:      	callq	*%rax
    288a:      	movq	0x10(%rsp), %r13
    288f:      	movzwl	0x2(%r13), %eax
    2894:      	movbew	%ax, 0x2(%r13)
    289b:      	movq	0x18(%rsp), %rbp
    28a0:      	movq	0x30(%rsp), %r14
    28a5:      	movl	$0x18, %r15d
    28ab:      	jmp	0x29bd <generic_fentry_process_event+0x260d>
    28b0:      	movq	0x10(%rsp), %rax
    28b5:      	leaq	0x10(%rax), %rdi
    28b9:      	movq	0x60(%rsp), %rcx
    28be:      	movl	$0x3f, %edx
    28c3:      	movl	$0x2d, %eax
    28c8:      	movq	0x60(%rsp), %rdx
    28cd:      	movl	$0x3f, %esi
    28d2:      	callq	*%rax
    28d4:      	testq	%rax, %rax
    28d7:      	js	0x2478 <generic_fentry_process_event+0x20c8>
    28dd:      	movq	0x20(%rsp), %r15
    28e2:      	leaq	0x8(%r15), %rdx
    28e6:      	leaq	0xa0(%rsp), %rdi
    28ee:      	movl	$0x8, %ecx
    28f3:      	movl	$0x4, %eax
    28f8:      	movl	$0x8, %esi
    28fd:      	callq	*%rax
    28ff:      	movq	0x10(%rsp), %rax
    2904:      	leaq	0x8(%rax), %rdi
    2908:      	movl	$0x348, %edx            # imm = 0x348
    290d:      	movq	0xa0(%rsp), %rcx
    2915:      	addq	%rdx, %rcx
    2918:      	movl	$0x8, %esi
    291d:      	movl	$0x4, %eax
    2922:      	addq	0xa0(%rsp), %rdx
    292a:      	movl	$0x8, %esi
    292f:      	callq	*%rax
    2931:      	addq	$0x58, %r15
    2935:      	leaq	0xa0(%rsp), %rdi
    293d:      	movl	$0x4, %ecx
    2942:      	movl	$0x4, %eax
    2947:      	movl	$0x4, %esi
    294c:      	movq	%r15, %rdx
    294f:      	callq	*%rax
    2951:      	movl	$0x50, %r15d
    2957:      	testq	%rax, %rax
    295a:      	jne	0x247b <generic_fentry_process_event+0x20cb>
    2960:      	xorl	%eax, %eax
    2962:      	cmpl	$0x0, 0xa0(%rsp)
    296a:      	setne	%al
    296d:      	movq	0x10(%rsp), %rcx
    2972:      	movl	%eax, (%rcx)
    2974:      	jmp	0x247b <generic_fentry_process_event+0x20cb>
    2979:      	xorl	%r15d, %r15d
    297c:      	movq	%r12, %rcx
    297f:      	jmp	0x348e <generic_fentry_process_event+0x30de>
    2984:      	addq	$0x3, %r15
    2988:      	movl	$0x6b, %ecx
    298d:      	movl	$0x71, %eax
    2992:      	movl	$0x6b, %esi
    2997:      	movq	%r15, %rdx
    299a:      	callq	*%rax
    299c:      	movq	%rax, %rcx
    299f:      	movb	$0x6b, %al
    29a1:      	testl	%ecx, %ecx
    29a3:      	movq	0x18(%rsp), %rbp
    29a8:      	movq	0x30(%rsp), %r14
    29ad:      	js	0x29b7 <generic_fentry_process_event+0x2607>
    29af:      	movq	0x10(%rsp), %rcx
    29b4:      	movb	%al, 0x3(%rcx)
    29b7:      	movl	$0x70, %r15d
    29bd:      	movq	0x8(%rsp), %rcx
    29c2:      	movq	(%rsp), %rsi
    29c6:      	movq	0x48(%rsp), %r13
    29cb:      	testl	%r15d, %r15d
    29ce:      	js	0x34a5 <generic_fentry_process_event+0x30f5>
    29d4:      	andl	$0x7fffffff, %r15d      # imm = 0x7FFFFFFF
    29db:      	addl	$0x4, %r15d
    29df:      	movl	%r15d, %edx
    29e2:      	jmp	0x34c0 <generic_fentry_process_event+0x3110>
    29e7:      	cmpl	$0x1, %ecx
    29ea:      	je	0x31d2 <generic_fentry_process_event+0x2e22>
    29f0:      	cmpl	$0x2, %ecx
    29f3:      	jne	0x31dc <generic_fentry_process_event+0x2e2c>
    29f9:      	leaq	0x5e58(%r13), %rax
    2a00:      	jmp	0x31d9 <generic_fentry_process_event+0x2e29>
    2a05:      	leaq	0x48(%r15), %rdx
    2a09:      	movl	$0x10, %ecx
    2a0e:      	movl	$0x4, %eax
    2a13:      	movq	0x10(%rsp), %rdi
    2a18:      	movl	$0x10, %esi
    2a1d:      	callq	*%rax
    2a1f:      	leaq	0x38(%r15), %rdx
    2a23:      	movl	$0x10, %ecx
    2a28:      	movl	$0x4, %eax
    2a2d:      	movq	%r12, %rdi
    2a30:      	movl	$0x10, %esi
    2a35:      	callq	*%rax
    2a37:      	movq	0x10(%rsp), %rbp
    2a3c:      	leaq	0x20(%rbp), %rdi
    2a40:      	leaq	0xc(%r15), %r12
    2a44:      	addq	$0xe, %r15
    2a48:      	movl	$0x2, %ecx
    2a4d:      	movl	$0x4, %eax
    2a52:      	movl	$0x2, %esi
    2a57:      	movq	%r15, %rdx
    2a5a:      	callq	*%rax
    2a5c:      	leaq	0x22(%rbp), %rdi
    2a60:      	movl	$0x2, %ecx
    2a65:      	movl	$0x4, %eax
    2a6a:      	movl	$0x2, %esi
    2a6f:      	movq	%r12, %rdx
    2a72:      	callq	*%rax
    2a74:      	movzwl	0x22(%rbp), %eax
    2a78:      	movbew	%ax, 0x22(%rbp)
    2a7e:      	movq	0x10(%rsp), %rax
    2a83:      	movq	0x28(%rax), %rax
    2a87:      	movq	%rax, 0x60(%rsp)
    2a8c:      	movq	(%rip), %rdi            # 0x2a93 <generic_fentry_process_event+0x26e3>
    2a93:      	leaq	0x60(%rsp), %rsi
    2a98:      	movl	$0x1, %eax
    2a9d:      	callq	*%rax
    2a9f:      	testq	%rax, %rax
    2aa2:      	je	0x2abc <generic_fentry_process_event+0x270c>
    2aa4:      	movl	(%rax), %ecx
    2aa6:      	movq	0x28(%rsp), %rdx
    2aab:      	movl	%ecx, 0x10(%rdx)
    2aae:      	movq	0x8(%rax), %rcx
    2ab2:      	movq	%rcx, 0x18(%rdx)
    2ab6:      	movl	0x4(%rax), %eax
    2ab9:      	movl	%eax, 0x7c(%rdx)
    2abc:      	movl	$0x40, %r15d
    2ac2:      	movq	%r13, %rcx
    2ac5:      	jmp	0x3489 <generic_fentry_process_event+0x30d9>
    2aca:      	movq	0x28(%rsp), %rax
    2acf:      	addq	$0x5e60, %rax           # imm = 0x5E60
    2ad5:      	jmp	0x2aef <generic_fentry_process_event+0x273f>
    2ad7:      	movq	0x28(%rsp), %rax
    2adc:      	addq	$0x5e68, %rax           # imm = 0x5E68
    2ae2:      	jmp	0x2aef <generic_fentry_process_event+0x273f>
    2ae4:      	movq	0x28(%rsp), %rax
    2ae9:      	addq	$0x5e50, %rax           # imm = 0x5E50
    2aef:      	movq	(%rax), %r12
    2af2:      	testb	$0x10, 0xc8(%rsp)
    2afa:      	jne	0x2f20 <generic_fentry_process_event+0x2b70>
    2b00:      	testq	%r12, %r12
    2b03:      	je	0x2fe5 <generic_fentry_process_event+0x2c35>
    2b09:      	leaq	0x60(%rsp), %rdi
    2b0e:      	movl	$0x4, %r15d
    2b14:      	movl	$0x10, %ecx
    2b19:      	movl	$0x4, %eax
    2b1e:      	movq	0x20(%rsp), %rdx
    2b23:      	movl	$0x10, %esi
    2b28:      	callq	*%rax
    2b2a:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2b2f:      	testl	%eax, %eax
    2b31:      	js	0x2ef8 <generic_fentry_process_event+0x2b48>
    2b37:      	movq	0x68(%rsp), %r13
    2b3c:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2b41:      	cmpq	$0xffe, %r13            # imm = 0xFFE
    2b48:      	ja	0x2ef8 <generic_fentry_process_event+0x2b48>
    2b4e:      	movq	0x18(%rsp), %rax
    2b53:      	leaq	0xc(%rax), %rdi
    2b57:      	movq	%rdi, %r14
    2b5a:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2b60:      	addq	%rbp, %rdi
    2b63:      	movq	0x60(%rsp), %rcx
    2b68:      	movl	$0x4, %eax
    2b6d:      	movq	0x60(%rsp), %rdx
    2b72:      	movl	%r13d, %esi
    2b75:      	callq	*%rax
    2b77:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2b7c:      	testl	%eax, %eax
    2b7e:      	js	0x2ef8 <generic_fentry_process_event+0x2b48>
    2b84:      	cmpq	$0x1, %r12
    2b88:      	je	0x2fe8 <generic_fentry_process_event+0x2c38>
    2b8e:      	movq	0x20(%rsp), %rax
    2b93:      	leaq	0x10(%rax), %rdx
    2b97:      	leaq	0x60(%rsp), %rdi
    2b9c:      	movl	$0x4, %r15d
    2ba2:      	movl	$0x10, %ecx
    2ba7:      	movl	$0x4, %eax
    2bac:      	movl	$0x10, %esi
    2bb1:      	callq	*%rax
    2bb3:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2bb8:      	testl	%eax, %eax
    2bba:      	js	0x2ef8 <generic_fentry_process_event+0x2b48>
    2bc0:      	movq	0x68(%rsp), %rax
    2bc5:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2bca:      	movq	%rax, 0x28(%rsp)
    2bcf:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2bd5:      	ja	0x2ef8 <generic_fentry_process_event+0x2b48>
    2bdb:      	addq	%r13, %r14
    2bde:      	movq	%r14, 0xc8(%rsp)
    2be6:      	movl	%r14d, %edi
    2be9:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2bef:      	addq	%rbp, %rdi
    2bf2:      	movq	0x60(%rsp), %rcx
    2bf7:      	movl	$0x4, %eax
    2bfc:      	movq	0x28(%rsp), %rsi
    2c01:      	movq	0x60(%rsp), %rdx
    2c06:      	callq	*%rax
    2c08:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2c0d:      	testl	%eax, %eax
    2c0f:      	js	0x2ef8 <generic_fentry_process_event+0x2b48>
    2c15:      	addq	0x28(%rsp), %r13
    2c1a:      	cmpq	$0x3, %r12
    2c1e:      	jb	0x2fe8 <generic_fentry_process_event+0x2c38>
    2c24:      	movq	0x20(%rsp), %rax
    2c29:      	leaq	0x20(%rax), %rdx
    2c2d:      	leaq	0x60(%rsp), %rdi
    2c32:      	movl	$0x4, %r15d
    2c38:      	movl	$0x10, %ecx
    2c3d:      	movl	$0x4, %eax
    2c42:      	movl	$0x10, %esi
    2c47:      	callq	*%rax
    2c49:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2c4e:      	testl	%eax, %eax
    2c50:      	js	0x2ef8 <generic_fentry_process_event+0x2b48>
    2c56:      	movq	0x68(%rsp), %rax
    2c5b:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2c60:      	movq	%rax, 0x10(%rsp)
    2c65:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2c6b:      	ja	0x2ef8 <generic_fentry_process_event+0x2b48>
    2c71:      	movq	0x28(%rsp), %rdi
    2c76:      	addq	0xc8(%rsp), %rdi
    2c7e:      	movq	%rdi, %r14
    2c81:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2c87:      	addq	%rbp, %rdi
    2c8a:      	movq	0x60(%rsp), %rcx
    2c8f:      	movl	$0x4, %eax
    2c94:      	movq	0x10(%rsp), %rsi
    2c99:      	movq	0x60(%rsp), %rdx
    2c9e:      	callq	*%rax
    2ca0:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2ca5:      	testl	%eax, %eax
    2ca7:      	js	0x2ef8 <generic_fentry_process_event+0x2b48>
    2cad:      	addq	0x10(%rsp), %r13
    2cb2:      	cmpq	$0x3, %r12
    2cb6:      	je	0x2fe8 <generic_fentry_process_event+0x2c38>
    2cbc:      	movq	0x20(%rsp), %rax
    2cc1:      	leaq	0x30(%rax), %rdx
    2cc5:      	leaq	0x60(%rsp), %rdi
    2cca:      	movl	$0x4, %r15d
    2cd0:      	movl	$0x10, %ecx
    2cd5:      	movl	$0x4, %eax
    2cda:      	movl	$0x10, %esi
    2cdf:      	callq	*%rax
    2ce1:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2ce6:      	testl	%eax, %eax
    2ce8:      	js	0x2ef8 <generic_fentry_process_event+0x2b48>
    2cee:      	movq	0x68(%rsp), %rax
    2cf3:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2cf8:      	movq	%rax, 0x28(%rsp)
    2cfd:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2d03:      	ja	0x2ef8 <generic_fentry_process_event+0x2b48>
    2d09:      	movq	0x10(%rsp), %rdi
    2d0e:      	addq	%r14, %rdi
    2d11:      	movq	%rdi, %r14
    2d14:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2d1a:      	addq	%rbp, %rdi
    2d1d:      	movq	0x60(%rsp), %rcx
    2d22:      	movl	$0x4, %eax
    2d27:      	movq	0x28(%rsp), %rsi
    2d2c:      	movq	0x60(%rsp), %rdx
    2d31:      	callq	*%rax
    2d33:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2d38:      	testl	%eax, %eax
    2d3a:      	js	0x2ef8 <generic_fentry_process_event+0x2b48>
    2d40:      	addq	0x28(%rsp), %r13
    2d45:      	cmpq	$0x5, %r12
    2d49:      	jb	0x2fe8 <generic_fentry_process_event+0x2c38>
    2d4f:      	movq	0x20(%rsp), %rax
    2d54:      	leaq	0x40(%rax), %rdx
    2d58:      	leaq	0x60(%rsp), %rdi
    2d5d:      	movl	$0x4, %r15d
    2d63:      	movl	$0x10, %ecx
    2d68:      	movl	$0x4, %eax
    2d6d:      	movl	$0x10, %esi
    2d72:      	callq	*%rax
    2d74:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2d79:      	testl	%eax, %eax
    2d7b:      	js	0x2ef8 <generic_fentry_process_event+0x2b48>
    2d81:      	movq	0x68(%rsp), %rax
    2d86:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2d8b:      	movq	%rax, 0xc8(%rsp)
    2d93:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2d99:      	ja	0x2ef8 <generic_fentry_process_event+0x2b48>
    2d9f:      	movq	0x28(%rsp), %rdi
    2da4:      	addq	%r14, %rdi
    2da7:      	movq	%rdi, %r14
    2daa:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2db0:      	addq	%rbp, %rdi
    2db3:      	movq	0x60(%rsp), %rcx
    2db8:      	movl	$0x4, %eax
    2dbd:      	movq	0xc8(%rsp), %rsi
    2dc5:      	movq	0x60(%rsp), %rdx
    2dca:      	callq	*%rax
    2dcc:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2dd1:      	testl	%eax, %eax
    2dd3:      	js	0x2ef8 <generic_fentry_process_event+0x2b48>
    2dd9:      	addq	0xc8(%rsp), %r13
    2de1:      	cmpq	$0x5, %r12
    2de5:      	je	0x2fe8 <generic_fentry_process_event+0x2c38>
    2deb:      	movq	0x20(%rsp), %rax
    2df0:      	leaq	0x50(%rax), %rdx
    2df4:      	leaq	0x60(%rsp), %rdi
    2df9:      	movl	$0x4, %r15d
    2dff:      	movl	$0x10, %ecx
    2e04:      	movl	$0x4, %eax
    2e09:      	movl	$0x10, %esi
    2e0e:      	callq	*%rax
    2e10:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2e15:      	testl	%eax, %eax
    2e17:      	js	0x2ef8 <generic_fentry_process_event+0x2b48>
    2e1d:      	movq	0x68(%rsp), %rax
    2e22:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2e27:      	movq	%rax, 0x28(%rsp)
    2e2c:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2e32:      	ja	0x2ef8 <generic_fentry_process_event+0x2b48>
    2e38:      	movq	0xc8(%rsp), %rdi
    2e40:      	addq	%r14, %rdi
    2e43:      	movq	%rdi, %r14
    2e46:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2e4c:      	addq	%rbp, %rdi
    2e4f:      	movq	0x60(%rsp), %rcx
    2e54:      	movl	$0x4, %eax
    2e59:      	movq	0x28(%rsp), %rsi
    2e5e:      	movq	0x60(%rsp), %rdx
    2e63:      	callq	*%rax
    2e65:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2e6a:      	testl	%eax, %eax
    2e6c:      	js	0x2ef8 <generic_fentry_process_event+0x2b48>
    2e72:      	addq	0x28(%rsp), %r13
    2e77:      	cmpq	$0x7, %r12
    2e7b:      	jb	0x2fe8 <generic_fentry_process_event+0x2c38>
    2e81:      	movq	0x20(%rsp), %rdx
    2e86:      	addq	$0x60, %rdx
    2e8a:      	leaq	0x60(%rsp), %rdi
    2e8f:      	movl	$0x4, %r15d
    2e95:      	movl	$0x10, %ecx
    2e9a:      	movl	$0x4, %eax
    2e9f:      	movl	$0x10, %esi
    2ea4:      	callq	*%rax
    2ea6:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2eab:      	testl	%eax, %eax
    2ead:      	js	0x2ef8 <generic_fentry_process_event+0x2b48>
    2eaf:      	movq	0x68(%rsp), %r12
    2eb4:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2eb9:      	cmpq	$0xffe, %r12            # imm = 0xFFE
    2ec0:      	ja	0x2ef8 <generic_fentry_process_event+0x2b48>
    2ec2:      	movq	0x28(%rsp), %rdi
    2ec7:      	addq	%r14, %rdi
    2eca:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2ed0:      	addq	%rbp, %rdi
    2ed3:      	movq	0x60(%rsp), %rcx
    2ed8:      	movl	$0x4, %eax
    2edd:      	movq	0x60(%rsp), %rdx
    2ee2:      	movl	%r12d, %esi
    2ee5:      	callq	*%rax
    2ee7:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2eec:      	testl	%eax, %eax
    2eee:      	js	0x2ef8 <generic_fentry_process_event+0x2b48>
    2ef0:      	addq	%r12, %r13
    2ef3:      	jmp	0x2fe8 <generic_fentry_process_event+0x2c38>
    2ef8:      	movq	0xb0(%rsp), %rax
    2f00:      	movl	%ecx, (%rbp,%rax)
    2f04:      	jmp	0x319b <generic_fentry_process_event+0x2deb>
    2f09:      	xorl	%r12d, %r12d
    2f0c:      	movl	$0x0, %r13d
    2f12:      	testb	$0x10, 0xc8(%rsp)
    2f1a:      	je	0x2fe8 <generic_fentry_process_event+0x2c38>
    2f20:      	movl	$0xe, %eax
    2f25:      	callq	*%rax
    2f27:      	cmpq	$-0x16, %rax
    2f2b:      	jne	0x2f4c <generic_fentry_process_event+0x2b9c>
    2f2d:      	leaq	0x20(%rbx), %rdx
    2f31:      	leaq	0x60(%rsp), %rdi
    2f36:      	movl	$0x8, %ecx
    2f3b:      	movl	$0x4, %eax
    2f40:      	movl	$0x8, %esi
    2f45:      	callq	*%rax
    2f47:      	movq	0x60(%rsp), %rax
    2f4c:      	movq	0x28(%rsp), %rdx
    2f51:      	movq	0x8(%rdx), %rcx
    2f55:      	movq	0x60(%rdx), %rdx
    2f59:      	movq	%rcx, 0x60(%rsp)
    2f5e:      	movq	0x20(%rsp), %rcx
    2f63:      	movq	%rcx, 0x68(%rsp)
    2f68:      	movq	%r12, 0x70(%rsp)
    2f6d:      	movq	%rdx, 0xa0(%rsp)
    2f75:      	movq	%rax, 0xa8(%rsp)
    2f7d:      	movq	(%rip), %rdi            # 0x2f84 <generic_fentry_process_event+0x2bd4>
    2f84:      	xorl	%ecx, %ecx
    2f86:      	leaq	0xa0(%rsp), %rsi
    2f8e:      	leaq	0x60(%rsp), %rdx
    2f93:      	movl	$0x2, %eax
    2f98:      	xorl	%ecx, %ecx
    2f9a:      	callq	*%rax
    2f9c:      	testq	%rax, %rax
    2f9f:      	je	0x3185 <generic_fentry_process_event+0x2dd5>
    2fa5:      	negl	%eax
    2fa7:      	movw	%ax, 0x38(%rsp)
    2fac:      	movw	$0x5, 0x3a(%rsp)
    2fb3:      	movabsq	$0x200000057, %rax      # imm = 0x200000057
    2fbd:      	movq	%rax, 0x3c(%rsp)
    2fc2:      	movq	(%rip), %rdi            # 0x2fc9 <generic_fentry_process_event+0x2c19>
    2fc9:      	leaq	0x38(%rsp), %rsi
    2fce:      	movl	$0x1, %eax
    2fd3:      	callq	*%rax
    2fd5:      	testq	%rax, %rax
    2fd8:      	je	0x315b <generic_fentry_process_event+0x2dab>
    2fde:      	incl	(%rax)
    2fe0:      	jmp	0x3185 <generic_fentry_process_event+0x2dd5>
    2fe5:      	xorl	%r13d, %r13d
    2fe8:      	movq	0xb0(%rsp), %rax
    2ff0:      	movl	%r13d, (%rbp,%rax)
    2ff5:      	movl	%r13d, 0x4(%rbp,%rax)
    2ffa:      	addq	$0x8, %r13
    2ffe:      	movq	%r13, %r15
    3001:      	jmp	0x319b <generic_fentry_process_event+0x2deb>
    3006:      	movq	0x20(%rsp), %rax
    300b:      	addq	$0x90, %rax
    3011:      	movl	$0x0, (%r12)
    3019:      	movq	0x18(%rsp), %rcx
    301e:      	leal	0x8(%rcx), %r12d
    3022:      	andl	$0x3fff, %r12d          # imm = 0x3FFF
    3029:      	addq	%rax, %r12
    302c:      	movl	$0xc, %r15d
    3032:      	cmpq	$0xfff, %rbx            # imm = 0xFFF
    3039:      	movl	$0xfff, %ebp            # imm = 0xFFF
    303e:      	cmovbq	%rbx, %rbp
    3042:      	leaq	0x8(%r12), %rdi
    3047:      	movl	$0x4, %eax
    304c:      	movl	%ebp, %esi
    304e:      	movq	%r14, %rdx
    3051:      	callq	*%rax
    3053:      	testl	%eax, %eax
    3055:      	js	0x3068 <generic_fentry_process_event+0x2cb8>
    3057:      	movl	%ebx, (%r12)
    305b:      	movl	%ebp, 0x4(%r12)
    3060:      	addq	%rbp, %r15
    3063:      	jmp	0x3b63 <generic_fentry_process_event+0x37b3>
    3068:      	movl	$0xfffffffe, (%r12)     # imm = 0xFFFFFFFE
    3070:      	movl	$0x4, %r15d
    3076:      	jmp	0x3b63 <generic_fentry_process_event+0x37b3>
    307b:      	movq	0x20(%rsp), %rax
    3080:      	addq	$0x90, %rax
    3086:      	movl	$0x0, (%r12)
    308e:      	movq	0x18(%rsp), %rcx
    3093:      	leal	0x8(%rcx), %r12d
    3097:      	andl	$0x3fff, %r12d          # imm = 0x3FFF
    309e:      	addq	%rax, %r12
    30a1:      	movl	$0xc, %ebx
    30a6:      	cmpq	$0xfff, %r14            # imm = 0xFFF
    30ad:      	movl	$0xfff, %ebp            # imm = 0xFFF
    30b2:      	cmovbq	%r14, %rbp
    30b6:      	leaq	0x8(%r12), %rdi
    30bb:      	movl	$0x4, %eax
    30c0:      	movq	0x28(%rsp), %rdx
    30c5:      	movl	$0x4, %r15d
    30cb:      	movl	%ebp, %esi
    30cd:      	callq	*%rax
    30cf:      	testl	%eax, %eax
    30d1:      	js	0x30e7 <generic_fentry_process_event+0x2d37>
    30d3:      	movl	%r14d, (%r12)
    30d7:      	movl	%ebp, 0x4(%r12)
    30dc:      	addq	%rbp, %rbx
    30df:      	movq	%rbx, %r15
    30e2:      	jmp	0x3b63 <generic_fentry_process_event+0x37b3>
    30e7:      	movl	$0xfffffffe, (%r12)     # imm = 0xFFFFFFFE
    30ef:      	jmp	0x3b63 <generic_fentry_process_event+0x37b3>
    30f4:      	cmpl	$0x33, %eax
    30f7:      	je	0x3389 <generic_fentry_process_event+0x2fd9>
    30fd:      	cmpl	$0x3c, %eax
    3100:      	je	0x31b0 <generic_fentry_process_event+0x2e00>
    3106:      	cmpl	$0xff, %eax
    310b:      	jne	0x3459 <generic_fentry_process_event+0x30a9>
    3111:      	movw	$0x28, 0x2(%rbp)
    3117:      	movw	$0x28, %ax
    311b:      	jmp	0x3398 <generic_fentry_process_event+0x2fe8>
    3120:      	movl	$0x1, 0xd0(%rsp)
    312b:      	movq	(%rip), %rdi            # 0x3132 <generic_fentry_process_event+0x2d82>
    3132:      	xorl	%ecx, %ecx
    3134:      	leaq	0x38(%rsp), %rsi
    3139:      	leaq	0xd0(%rsp), %rdx
    3141:      	movl	$0x2, %eax
    3146:      	xorl	%ecx, %ecx
    3148:      	callq	*%rax
    314a:      	movl	$0xfffffffc, (%rbx)     # imm = 0xFFFFFFFC
    3150:      	movl	$0x4, %r15d
    3156:      	jmp	0x347f <generic_fentry_process_event+0x30cf>
    315b:      	movl	$0x1, 0xc0(%rsp)
    3166:      	movq	(%rip), %rdi            # 0x316d <generic_fentry_process_event+0x2dbd>
    316d:      	xorl	%ecx, %ecx
    316f:      	leaq	0x38(%rsp), %rsi
    3174:      	leaq	0xc0(%rsp), %rdx
    317c:      	movl	$0x2, %eax
    3181:      	xorl	%ecx, %ecx
    3183:      	callq	*%rax
    3185:      	movq	0xb0(%rsp), %rax
    318d:      	movl	$0xfffffffc, (%rbp,%rax) # imm = 0xFFFFFFFC
    3195:      	movl	$0x4, %r15d
    319b:      	movq	0x8(%rsp), %rcx
    31a0:      	jmp	0x3489 <generic_fentry_process_event+0x30d9>
    31a5:      	movl	$0x4, %r15d
    31ab:      	jmp	0x3b63 <generic_fentry_process_event+0x37b3>
    31b0:      	movzbl	0x7(%rbp), %eax
    31b4:      	leal	0x8(,%rax,8), %eax
    31bb:      	jmp	0x3394 <generic_fentry_process_event+0x2fe4>
    31c0:      	leaq	0x5e60(%r13), %rax
    31c7:      	jmp	0x31d9 <generic_fentry_process_event+0x2e29>
    31c9:      	leaq	0x5e68(%r13), %rax
    31d0:      	jmp	0x31d9 <generic_fentry_process_event+0x2e29>
    31d2:      	leaq	0x5e50(%r13), %rax
    31d9:      	movq	(%rax), %rax
    31dc:      	movq	%rax, 0xc0(%rsp)
    31e4:      	leaq	0x50(%rsp), %rdi
    31e9:      	leaq	0xc0(%rsp), %rdx
    31f1:      	movl	$0x8, %ecx
    31f6:      	movl	$0x4, %eax
    31fb:      	movl	$0x8, %r15d
    3201:      	movl	$0x8, %esi
    3206:      	callq	*%rax
    3208:      	movq	0x50(%rsp), %r12
    320d:      	testb	$0x20, %bpl
    3211:      	je	0x3312 <generic_fentry_process_event+0x2f62>
    3217:      	cmpq	$0x1000, %r12           # imm = 0x1000
    321e:      	jb	0x32ee <generic_fentry_process_event+0x2f3e>
    3224:      	movl	$0x1, (%rbx)
    322a:      	movl	$0x0, 0xa0(%rsp)
    3235:      	movq	(%rip), %rdi            # 0x323c <generic_fentry_process_event+0x2e8c>
    323c:      	leaq	0xa0(%rsp), %rsi
    3244:      	movl	$0x1, %eax
    3249:      	callq	*%rax
    324b:      	testq	%rax, %rax
    324e:      	je	0x337e <generic_fentry_process_event+0x2fce>
    3254:      	movq	%rax, %r13
    3257:      	movl	$0x18, (%rax)
    325d:      	movl	$0xe, %eax
    3262:      	callq	*%rax
    3264:      	movq	%r13, %r15
    3267:      	addq	$0x10, %r15
    326b:      	movq	%rax, 0x10(%r13)
    326f:      	cmpq	$-0x16, %rax
    3273:      	jne	0x329c <generic_fentry_process_event+0x2eec>
    3275:      	movq	0x58(%rsp), %rax
    327a:      	leaq	0x20(%rax), %rdx
    327e:      	leaq	0x60(%rsp), %rdi
    3283:      	movl	$0x8, %ecx
    3288:      	movl	$0x4, %eax
    328d:      	movl	$0x8, %esi
    3292:      	callq	*%rax
    3294:      	movq	0x60(%rsp), %rax
    3299:      	movq	%rax, (%r15)
    329c:      	movl	$0x7d, %eax
    32a1:      	callq	*%rax
    32a3:      	movq	%rax, 0x18(%r13)
    32a7:      	movq	(%r15), %rax
    32aa:      	movq	0x8(%r15), %rcx
    32ae:      	movq	%rax, 0x14(%rbx)
    32b2:      	movq	%rcx, 0x1c(%rbx)
    32b6:      	movq	0x58(%rsp), %rdi
    32bb:      	movq	%r13, %rsi
    32be:      	movq	0x20(%rsp), %rdx
    32c3:      	movq	%r12, %rcx
    32c6:      	callq	0x32cb <generic_fentry_process_event+0x2f1b>
    32cb:      	testl	%eax, %eax
    32cd:      	js	0x3462 <generic_fentry_process_event+0x30b2>
    32d3:      	movq	$0x0, 0x4(%rbx)
    32db:      	movl	%r12d, %edx
    32de:      	subl	%eax, %edx
    32e0:      	xorl	%ecx, %ecx
    32e2:      	cmpq	$-0x1, %r12
    32e6:      	cmovnel	%edx, %ecx
    32e9:      	jmp	0x3473 <generic_fentry_process_event+0x30c3>
    32ee:      	addq	$0x90, %r13
    32f5:      	movl	$0x0, (%rbx)
    32fb:      	movq	0x18(%rsp), %rax
    3300:      	leal	0x8(%rax), %ebx
    3303:      	andl	$0x3fff, %ebx           # imm = 0x3FFF
    3309:      	addq	%r13, %rbx
    330c:      	movl	$0xc, %r15d
    3312:      	cmpq	$0xfff, %r12            # imm = 0xFFF
    3319:      	movl	$0xfff, %ebp            # imm = 0xFFF
    331e:      	cmovbq	%r12, %rbp
    3322:      	leaq	0x8(%rbx), %rdi
    3326:      	movl	$0x4, %eax
    332b:      	movq	0x20(%rsp), %rdx
    3330:      	movl	%ebp, %esi
    3332:      	callq	*%rax
    3334:      	testl	%eax, %eax
    3336:      	js	0x3346 <generic_fentry_process_event+0x2f96>
    3338:      	movl	%r12d, (%rbx)
    333b:      	movl	%ebp, 0x4(%rbx)
    333e:      	addq	%rbp, %r15
    3341:      	jmp	0x347f <generic_fentry_process_event+0x30cf>
    3346:      	movl	$0xfffffffe, (%rbx)     # imm = 0xFFFFFFFE
    334c:      	movl	$0x4, %r15d
    3352:      	jmp	0x347f <generic_fentry_process_event+0x30cf>
    3357:      	movl	%eax, 0x4(%r12)
    335c:      	movl	$0x0, 0x8(%r12)
    3365:      	xorl	%ecx, %ecx
    3367:      	xorl	%eax, %eax
    3369:      	movl	%ecx, 0xc(%r12)
    336e:      	movl	%eax, 0x10(%r12)
    3373:      	movl	$0x24, %r15d
    3379:      	jmp	0x3b63 <generic_fentry_process_event+0x37b3>
    337e:      	movl	$0x4, %r15d
    3384:      	jmp	0x347f <generic_fentry_process_event+0x30cf>
    3389:      	movzbl	0x7(%rbp), %eax
    338d:      	leal	0x8(,%rax,4), %eax
    3394:      	movw	%ax, 0x2(%rbp)
    3398:      	addw	(%rbp), %ax
    339c:      	movw	%ax, (%rbp)
    33a0:      	movzbl	0x6(%rbp), %r15d
    33a5:      	cmpq	$0x3c, %r15
    33a9:      	ja	0x3b80 <generic_fentry_process_event+0x37d0>
    33af:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    33b9:      	btq	%r15, %rcx
    33bd:      	jae	0x3b80 <generic_fentry_process_event+0x37d0>
    33c3:      	movb	%r15b, 0x5(%rbp)
    33c7:      	movzwl	%ax, %ecx
    33ca:      	addq	%rbx, %rcx
    33cd:      	movl	$0x2, %edx
    33d2:      	movl	$0x4, %eax
    33d7:      	movq	0x20(%rsp), %rdi
    33dc:      	movzwl	(%rbp), %edx
    33e0:      	addq	%rbx, %rdx
    33e3:      	movl	$0x2, %esi
    33e8:      	callq	*%rax
    33ea:      	testq	%rax, %rax
    33ed:      	js	0x39a3 <generic_fentry_process_event+0x35f3>
    33f3:      	movzbl	0x5(%rbp), %eax
    33f7:      	cmpl	$0x32, %eax
    33fa:      	jg	0x341d <generic_fentry_process_event+0x306d>
    33fc:      	testl	%eax, %eax
    33fe:      	je	0x3445 <generic_fentry_process_event+0x3095>
    3400:      	cmpl	$0x2b, %eax
    3403:      	je	0x3445 <generic_fentry_process_event+0x3095>
    3405:      	cmpl	$0x2c, %eax
    3408:      	jne	0x3588 <generic_fentry_process_event+0x31d8>
    340e:      	movw	$0x8, 0x2(%rbp)
    3414:      	movw	$0x8, %ax
    3418:      	jmp	0x358c <generic_fentry_process_event+0x31dc>
    341d:      	cmpl	$0x33, %eax
    3420:      	je	0x3577 <generic_fentry_process_event+0x31c7>
    3426:      	cmpl	$0x3c, %eax
    3429:      	je	0x3445 <generic_fentry_process_event+0x3095>
    342b:      	cmpl	$0xff, %eax
    3430:      	jne	0x3588 <generic_fentry_process_event+0x31d8>
    3436:      	movw	$0x28, 0x2(%rbp)
    343c:      	movw	$0x28, %ax
    3440:      	jmp	0x358c <generic_fentry_process_event+0x31dc>
    3445:      	movzbl	0x7(%rbp), %eax
    3449:      	leal	0x8(,%rax,8), %eax
    3450:      	movw	%ax, 0x2(%rbp)
    3454:      	jmp	0x358c <generic_fentry_process_event+0x31dc>
    3459:      	movzwl	0x2(%rbp), %eax
    345d:      	jmp	0x3398 <generic_fentry_process_event+0x2fe8>
    3462:      	movq	%rbx, %rcx
    3465:      	movl	%eax, 0x4(%rbx)
    3468:      	movl	$0x0, 0x8(%rbx)
    346f:      	xorl	%ecx, %ecx
    3471:      	xorl	%eax, %eax
    3473:      	movl	%ecx, 0xc(%rbx)
    3476:      	movl	%eax, 0x10(%rbx)
    3479:      	movl	$0x24, %r15d
    347f:      	movq	0x8(%rsp), %rcx
    3484:      	movq	0x58(%rsp), %rbx
    3489:      	movq	0x48(%rsp), %r13
    348e:      	movq	0x18(%rsp), %rbp
    3493:      	movq	(%rsp), %rsi
    3497:      	movq	0x30(%rsp), %r14
    349c:      	testl	%r15d, %r15d
    349f:      	jns	0x29d4 <generic_fentry_process_event+0x2624>
    34a5:      	movl	$0xffffffff, 0x5ea0(%rcx,%rsi,4) # imm = 0xFFFFFFFF
    34b0:      	movl	$0xffffffff, 0x90(%rcx,%rbp) # imm = 0xFFFFFFFF
    34bb:      	movl	$0x4, %edx
    34c0:      	addl	%ebp, %edx
    34c2:      	movl	%edx, %ebp
    34c4:      	movl	%ebp, 0x4(%r14)
    34c8:      	cmpl	$0x3, %r13d
    34cc:      	jg	0x353d <generic_fentry_process_event+0x318d>
    34ce:      	movl	$0x0, 0x60(%rsp)
    34d6:      	movq	(%rip), %rdi            # 0x34dd <generic_fentry_process_event+0x312d>
    34dd:      	leaq	0x60(%rsp), %rsi
    34e2:      	movl	$0x1, %eax
    34e7:      	callq	*%rax
    34e9:      	testq	%rax, %rax
    34ec:      	je	0x353d <generic_fentry_process_event+0x318d>
    34ee:      	movq	%rax, %rsi
    34f1:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    34f8:      	movq	(%rip), %rdi            # 0x34ff <generic_fentry_process_event+0x314f>
    34ff:      	movl	$0x1, %eax
    3504:      	callq	*%rax
    3506:      	testq	%rax, %rax
    3509:      	je	0x353d <generic_fentry_process_event+0x318d>
    350b:      	incl	%r13d
    350e:      	movl	%r13d, %ecx
    3511:      	andl	$0x7, %ecx
    3514:      	cmpl	$-0x1, 0x40(%rax,%rcx,4)
    3519:      	je	0x353d <generic_fentry_process_event+0x318d>
    351b:      	movl	%r13d, 0x5efc(%r14)
    3522:      	movq	(%rip), %rsi            # 0x3529 <generic_fentry_process_event+0x3179>
    3529:      	movl	$0x1, %ecx
    352e:      	movl	$0xc, %eax
    3533:      	movq	%rbx, %rdi
    3536:      	movl	$0x1, %edx
    353b:      	callq	*%rax
    353d:      	movl	$0x0, 0x5efc(%r14)
    3548:      	movq	(%rip), %rsi            # 0x354f <generic_fentry_process_event+0x319f>
    354f:      	movl	$0x3, %ecx
    3554:      	movl	$0xc, %eax
    3559:      	movq	%rbx, %rdi
    355c:      	movl	$0x3, %edx
    3561:      	callq	*%rax
    3563:      	xorl	%eax, %eax
    3565:      	addq	$0x108, %rsp            # imm = 0x108
    356c:      	popq	%rbx
    356d:      	popq	%r12
    356f:      	popq	%r13
    3571:      	popq	%r14
    3573:      	popq	%r15
    3575:      	popq	%rbp
    3576:      	retq
    3577:      	movzbl	0x7(%rbp), %eax
    357b:      	leal	0x8(,%rax,4), %eax
    3582:      	movw	%ax, 0x2(%rbp)
    3586:      	jmp	0x358c <generic_fentry_process_event+0x31dc>
    3588:      	movzwl	0x2(%rbp), %eax
    358c:      	addw	(%rbp), %ax
    3590:      	movw	%ax, (%rbp)
    3594:      	movzbl	0x6(%rbp), %r15d
    3599:      	cmpq	$0x3c, %r15
    359d:      	ja	0x3b80 <generic_fentry_process_event+0x37d0>
    35a3:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    35ad:      	btq	%r15, %rcx
    35b1:      	jae	0x3b80 <generic_fentry_process_event+0x37d0>
    35b7:      	movb	%r15b, 0x5(%rbp)
    35bb:      	movzwl	%ax, %ecx
    35be:      	addq	%rbx, %rcx
    35c1:      	movl	$0x2, %edx
    35c6:      	movl	$0x4, %eax
    35cb:      	movq	0x20(%rsp), %rdi
    35d0:      	movzwl	(%rbp), %edx
    35d4:      	addq	%rbx, %rdx
    35d7:      	movl	$0x2, %esi
    35dc:      	callq	*%rax
    35de:      	testq	%rax, %rax
    35e1:      	js	0x39a3 <generic_fentry_process_event+0x35f3>
    35e7:      	movzbl	0x5(%rbp), %eax
    35eb:      	cmpl	$0x32, %eax
    35ee:      	jg	0x360a <generic_fentry_process_event+0x325a>
    35f0:      	testl	%eax, %eax
    35f2:      	je	0x3627 <generic_fentry_process_event+0x3277>
    35f4:      	cmpl	$0x2b, %eax
    35f7:      	je	0x3627 <generic_fentry_process_event+0x3277>
    35f9:      	cmpl	$0x2c, %eax
    35fc:      	jne	0x3649 <generic_fentry_process_event+0x3299>
    35fe:      	movw	$0x8, 0x2(%rbp)
    3604:      	movw	$0x8, %ax
    3608:      	jmp	0x364d <generic_fentry_process_event+0x329d>
    360a:      	cmpl	$0x33, %eax
    360d:      	je	0x3638 <generic_fentry_process_event+0x3288>
    360f:      	cmpl	$0x3c, %eax
    3612:      	je	0x3627 <generic_fentry_process_event+0x3277>
    3614:      	cmpl	$0xff, %eax
    3619:      	jne	0x3649 <generic_fentry_process_event+0x3299>
    361b:      	movw	$0x28, 0x2(%rbp)
    3621:      	movw	$0x28, %ax
    3625:      	jmp	0x364d <generic_fentry_process_event+0x329d>
    3627:      	movzbl	0x7(%rbp), %eax
    362b:      	leal	0x8(,%rax,8), %eax
    3632:      	movw	%ax, 0x2(%rbp)
    3636:      	jmp	0x364d <generic_fentry_process_event+0x329d>
    3638:      	movzbl	0x7(%rbp), %eax
    363c:      	leal	0x8(,%rax,4), %eax
    3643:      	movw	%ax, 0x2(%rbp)
    3647:      	jmp	0x364d <generic_fentry_process_event+0x329d>
    3649:      	movzwl	0x2(%rbp), %eax
    364d:      	addw	(%rbp), %ax
    3651:      	movw	%ax, (%rbp)
    3655:      	movzbl	0x6(%rbp), %r15d
    365a:      	cmpq	$0x3c, %r15
    365e:      	ja	0x3b80 <generic_fentry_process_event+0x37d0>
    3664:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    366e:      	btq	%r15, %rcx
    3672:      	jae	0x3b80 <generic_fentry_process_event+0x37d0>
    3678:      	movb	%r15b, 0x5(%rbp)
    367c:      	movzwl	%ax, %ecx
    367f:      	addq	%rbx, %rcx
    3682:      	movl	$0x2, %edx
    3687:      	movl	$0x4, %eax
    368c:      	movq	0x20(%rsp), %rdi
    3691:      	movzwl	(%rbp), %edx
    3695:      	addq	%rbx, %rdx
    3698:      	movl	$0x2, %esi
    369d:      	callq	*%rax
    369f:      	testq	%rax, %rax
    36a2:      	js	0x39a3 <generic_fentry_process_event+0x35f3>
    36a8:      	movzbl	0x5(%rbp), %eax
    36ac:      	cmpl	$0x32, %eax
    36af:      	jg	0x36cb <generic_fentry_process_event+0x331b>
    36b1:      	testl	%eax, %eax
    36b3:      	je	0x36e8 <generic_fentry_process_event+0x3338>
    36b5:      	cmpl	$0x2b, %eax
    36b8:      	je	0x36e8 <generic_fentry_process_event+0x3338>
    36ba:      	cmpl	$0x2c, %eax
    36bd:      	jne	0x370a <generic_fentry_process_event+0x335a>
    36bf:      	movw	$0x8, 0x2(%rbp)
    36c5:      	movw	$0x8, %ax
    36c9:      	jmp	0x370e <generic_fentry_process_event+0x335e>
    36cb:      	cmpl	$0x33, %eax
    36ce:      	je	0x36f9 <generic_fentry_process_event+0x3349>
    36d0:      	cmpl	$0x3c, %eax
    36d3:      	je	0x36e8 <generic_fentry_process_event+0x3338>
    36d5:      	cmpl	$0xff, %eax
    36da:      	jne	0x370a <generic_fentry_process_event+0x335a>
    36dc:      	movw	$0x28, 0x2(%rbp)
    36e2:      	movw	$0x28, %ax
    36e6:      	jmp	0x370e <generic_fentry_process_event+0x335e>
    36e8:      	movzbl	0x7(%rbp), %eax
    36ec:      	leal	0x8(,%rax,8), %eax
    36f3:      	movw	%ax, 0x2(%rbp)
    36f7:      	jmp	0x370e <generic_fentry_process_event+0x335e>
    36f9:      	movzbl	0x7(%rbp), %eax
    36fd:      	leal	0x8(,%rax,4), %eax
    3704:      	movw	%ax, 0x2(%rbp)
    3708:      	jmp	0x370e <generic_fentry_process_event+0x335e>
    370a:      	movzwl	0x2(%rbp), %eax
    370e:      	addw	(%rbp), %ax
    3712:      	movw	%ax, (%rbp)
    3716:      	movzbl	0x6(%rbp), %r15d
    371b:      	cmpq	$0x3c, %r15
    371f:      	ja	0x3b80 <generic_fentry_process_event+0x37d0>
    3725:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    372f:      	btq	%r15, %rcx
    3733:      	jae	0x3b80 <generic_fentry_process_event+0x37d0>
    3739:      	movb	%r15b, 0x5(%rbp)
    373d:      	movzwl	%ax, %ecx
    3740:      	addq	%rbx, %rcx
    3743:      	movl	$0x2, %edx
    3748:      	movl	$0x4, %eax
    374d:      	movq	0x20(%rsp), %rdi
    3752:      	movzwl	(%rbp), %edx
    3756:      	addq	%rbx, %rdx
    3759:      	movl	$0x2, %esi
    375e:      	callq	*%rax
    3760:      	testq	%rax, %rax
    3763:      	js	0x39a3 <generic_fentry_process_event+0x35f3>
    3769:      	movzbl	0x5(%rbp), %eax
    376d:      	cmpl	$0x32, %eax
    3770:      	jg	0x378c <generic_fentry_process_event+0x33dc>
    3772:      	testl	%eax, %eax
    3774:      	je	0x37a9 <generic_fentry_process_event+0x33f9>
    3776:      	cmpl	$0x2b, %eax
    3779:      	je	0x37a9 <generic_fentry_process_event+0x33f9>
    377b:      	cmpl	$0x2c, %eax
    377e:      	jne	0x37cb <generic_fentry_process_event+0x341b>
    3780:      	movw	$0x8, 0x2(%rbp)
    3786:      	movw	$0x8, %ax
    378a:      	jmp	0x37cf <generic_fentry_process_event+0x341f>
    378c:      	cmpl	$0x33, %eax
    378f:      	je	0x37ba <generic_fentry_process_event+0x340a>
    3791:      	cmpl	$0x3c, %eax
    3794:      	je	0x37a9 <generic_fentry_process_event+0x33f9>
    3796:      	cmpl	$0xff, %eax
    379b:      	jne	0x37cb <generic_fentry_process_event+0x341b>
    379d:      	movw	$0x28, 0x2(%rbp)
    37a3:      	movw	$0x28, %ax
    37a7:      	jmp	0x37cf <generic_fentry_process_event+0x341f>
    37a9:      	movzbl	0x7(%rbp), %eax
    37ad:      	leal	0x8(,%rax,8), %eax
    37b4:      	movw	%ax, 0x2(%rbp)
    37b8:      	jmp	0x37cf <generic_fentry_process_event+0x341f>
    37ba:      	movzbl	0x7(%rbp), %eax
    37be:      	leal	0x8(,%rax,4), %eax
    37c5:      	movw	%ax, 0x2(%rbp)
    37c9:      	jmp	0x37cf <generic_fentry_process_event+0x341f>
    37cb:      	movzwl	0x2(%rbp), %eax
    37cf:      	addw	(%rbp), %ax
    37d3:      	movw	%ax, (%rbp)
    37d7:      	movzbl	0x6(%rbp), %r15d
    37dc:      	cmpq	$0x3c, %r15
    37e0:      	ja	0x3b80 <generic_fentry_process_event+0x37d0>
    37e6:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    37f0:      	btq	%r15, %rcx
    37f4:      	jae	0x3b80 <generic_fentry_process_event+0x37d0>
    37fa:      	movb	%r15b, 0x5(%rbp)
    37fe:      	movzwl	%ax, %ecx
    3801:      	addq	%rbx, %rcx
    3804:      	movl	$0x2, %edx
    3809:      	movl	$0x4, %eax
    380e:      	movq	0x20(%rsp), %rdi
    3813:      	movzwl	(%rbp), %edx
    3817:      	addq	%rbx, %rdx
    381a:      	movl	$0x2, %esi
    381f:      	callq	*%rax
    3821:      	testq	%rax, %rax
    3824:      	js	0x39a3 <generic_fentry_process_event+0x35f3>
    382a:      	movzbl	0x5(%rbp), %eax
    382e:      	cmpl	$0x32, %eax
    3831:      	jg	0x384d <generic_fentry_process_event+0x349d>
    3833:      	testl	%eax, %eax
    3835:      	je	0x386a <generic_fentry_process_event+0x34ba>
    3837:      	cmpl	$0x2b, %eax
    383a:      	je	0x386a <generic_fentry_process_event+0x34ba>
    383c:      	cmpl	$0x2c, %eax
    383f:      	jne	0x388c <generic_fentry_process_event+0x34dc>
    3841:      	movw	$0x8, 0x2(%rbp)
    3847:      	movw	$0x8, %ax
    384b:      	jmp	0x3890 <generic_fentry_process_event+0x34e0>
    384d:      	cmpl	$0x33, %eax
    3850:      	je	0x387b <generic_fentry_process_event+0x34cb>
    3852:      	cmpl	$0x3c, %eax
    3855:      	je	0x386a <generic_fentry_process_event+0x34ba>
    3857:      	cmpl	$0xff, %eax
    385c:      	jne	0x388c <generic_fentry_process_event+0x34dc>
    385e:      	movw	$0x28, 0x2(%rbp)
    3864:      	movw	$0x28, %ax
    3868:      	jmp	0x3890 <generic_fentry_process_event+0x34e0>
    386a:      	movzbl	0x7(%rbp), %eax
    386e:      	leal	0x8(,%rax,8), %eax
    3875:      	movw	%ax, 0x2(%rbp)
    3879:      	jmp	0x3890 <generic_fentry_process_event+0x34e0>
    387b:      	movzbl	0x7(%rbp), %eax
    387f:      	leal	0x8(,%rax,4), %eax
    3886:      	movw	%ax, 0x2(%rbp)
    388a:      	jmp	0x3890 <generic_fentry_process_event+0x34e0>
    388c:      	movzwl	0x2(%rbp), %eax
    3890:      	addw	(%rbp), %ax
    3894:      	movw	%ax, (%rbp)
    3898:      	movzbl	0x6(%rbp), %r15d
    389d:      	cmpq	$0x3c, %r15
    38a1:      	ja	0x3b80 <generic_fentry_process_event+0x37d0>
    38a7:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    38b1:      	btq	%r15, %rcx
    38b5:      	jae	0x3b80 <generic_fentry_process_event+0x37d0>
    38bb:      	movb	%r15b, 0x5(%rbp)
    38bf:      	movzwl	%ax, %ecx
    38c2:      	addq	%rbx, %rcx
    38c5:      	movl	$0x2, %edx
    38ca:      	movl	$0x4, %eax
    38cf:      	movq	0x20(%rsp), %rdi
    38d4:      	movzwl	(%rbp), %edx
    38d8:      	addq	%rbx, %rdx
    38db:      	movl	$0x2, %esi
    38e0:      	callq	*%rax
    38e2:      	testq	%rax, %rax
    38e5:      	js	0x39a3 <generic_fentry_process_event+0x35f3>
    38eb:      	movzbl	0x5(%rbp), %eax
    38ef:      	cmpl	$0x32, %eax
    38f2:      	jg	0x390e <generic_fentry_process_event+0x355e>
    38f4:      	testl	%eax, %eax
    38f6:      	je	0x392b <generic_fentry_process_event+0x357b>
    38f8:      	cmpl	$0x2b, %eax
    38fb:      	je	0x392b <generic_fentry_process_event+0x357b>
    38fd:      	cmpl	$0x2c, %eax
    3900:      	jne	0x394d <generic_fentry_process_event+0x359d>
    3902:      	movw	$0x8, 0x2(%rbp)
    3908:      	movw	$0x8, %ax
    390c:      	jmp	0x3951 <generic_fentry_process_event+0x35a1>
    390e:      	cmpl	$0x33, %eax
    3911:      	je	0x393c <generic_fentry_process_event+0x358c>
    3913:      	cmpl	$0x3c, %eax
    3916:      	je	0x392b <generic_fentry_process_event+0x357b>
    3918:      	cmpl	$0xff, %eax
    391d:      	jne	0x394d <generic_fentry_process_event+0x359d>
    391f:      	movw	$0x28, 0x2(%rbp)
    3925:      	movw	$0x28, %ax
    3929:      	jmp	0x3951 <generic_fentry_process_event+0x35a1>
    392b:      	movzbl	0x7(%rbp), %eax
    392f:      	leal	0x8(,%rax,8), %eax
    3936:      	movw	%ax, 0x2(%rbp)
    393a:      	jmp	0x3951 <generic_fentry_process_event+0x35a1>
    393c:      	movzbl	0x7(%rbp), %eax
    3940:      	leal	0x8(,%rax,4), %eax
    3947:      	movw	%ax, 0x2(%rbp)
    394b:      	jmp	0x3951 <generic_fentry_process_event+0x35a1>
    394d:      	movzwl	0x2(%rbp), %eax
    3951:      	addw	(%rbp), %ax
    3955:      	movw	%ax, (%rbp)
    3959:      	movzbl	0x6(%rbp), %r15d
    395e:      	cmpq	$0x3c, %r15
    3962:      	ja	0x3b80 <generic_fentry_process_event+0x37d0>
    3968:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3972:      	btq	%r15, %rcx
    3976:      	jae	0x3b80 <generic_fentry_process_event+0x37d0>
    397c:      	movb	%r15b, 0x5(%rbp)
    3980:      	movzwl	%ax, %ecx
    3983:      	addq	%rbx, %rcx
    3986:      	movl	$0x2, %edx
    398b:      	movl	$0x4, %eax
    3990:      	movq	0x20(%rsp), %rdi
    3995:      	movzwl	(%rbp), %edx
    3999:      	addq	%rbx, %rdx
    399c:      	movl	$0x2, %esi
    39a1:      	callq	*%rax
    39a3:      	xorl	%r15d, %r15d
    39a6:      	movb	%r15b, 0xb8(%rsp)
    39ae:      	movzbl	%r15b, %eax
    39b2:      	movq	0x10(%rsp), %rbx
    39b7:      	movw	%ax, 0x24(%rbx)
    39bb:      	movw	$0xa, 0x26(%rbx)
    39c1:      	leaq	0x8(%r13), %rdx
    39c5:      	movl	$0x10, %ecx
    39ca:      	movl	$0x4, %eax
    39cf:      	movq	%rbx, %rdi
    39d2:      	movl	$0x10, %esi
    39d7:      	callq	*%rax
    39d9:      	leaq	0x10(%rbx), %rdi
    39dd:      	addq	$0x18, %r13
    39e1:      	movl	$0x10, %ecx
    39e6:      	movl	$0x4, %eax
    39eb:      	movl	$0x10, %esi
    39f0:      	movq	%r13, %rdx
    39f3:      	callq	*%rax
    39f5:      	cmpb	$0x11, %r15b
    39f9:      	je	0x3a4c <generic_fentry_process_event+0x369c>
    39fb:      	movzbl	%r15b, %eax
    39ff:      	cmpl	$0x6, %eax
    3a02:      	jne	0x3a97 <generic_fentry_process_event+0x36e7>
    3a08:      	movq	0x60(%rsp), %rbx
    3a0d:      	movzwl	0xd0(%rsp), %r15d
    3a16:      	leaq	(%rbx,%r15), %rdx
    3a1a:      	movq	0x10(%rsp), %rbp
    3a1f:      	leaq	0x20(%rbp), %rdi
    3a23:      	movl	$0x2, %ecx
    3a28:      	movl	$0x4, %eax
    3a2d:      	movl	$0x2, %esi
    3a32:      	callq	*%rax
    3a34:      	leaq	0x22(%rbp), %rdi
    3a38:      	leaq	(%rbx,%r15), %rdx
    3a3c:      	addq	$0x2, %rdx
    3a40:      	movl	$0x2, %ecx
    3a45:      	movl	$0x4, %eax
    3a4a:      	jmp	0x3a8e <generic_fentry_process_event+0x36de>
    3a4c:      	movq	0x60(%rsp), %rbx
    3a51:      	movzwl	0xd0(%rsp), %r15d
    3a5a:      	leaq	(%rbx,%r15), %rdx
    3a5e:      	movq	0x10(%rsp), %rbp
    3a63:      	leaq	0x20(%rbp), %rdi
    3a67:      	movl	$0x2, %ecx
    3a6c:      	movl	$0x4, %eax
    3a71:      	movl	$0x2, %esi
    3a76:      	callq	*%rax
    3a78:      	leaq	0x22(%rbp), %rdi
    3a7c:      	leaq	(%rbx,%r15), %rdx
    3a80:      	addq	$0x2, %rdx
    3a84:      	movl	$0x2, %ecx
    3a89:      	movl	$0x4, %eax
    3a8e:      	movl	$0x2, %esi
    3a93:      	callq	*%rax
    3a95:      	jmp	0x3aa3 <generic_fentry_process_event+0x36f3>
    3a97:      	movq	0x10(%rsp), %rax
    3a9c:      	movl	$0x0, 0x20(%rax)
    3aa3:      	movq	0x10(%rsp), %rdx
    3aa8:      	movzwl	0x20(%rdx), %eax
    3aac:      	movzwl	0x22(%rdx), %ecx
    3ab0:      	movbew	%ax, 0x20(%rdx)
    3ab6:      	movbew	%cx, 0x22(%rdx)
    3abc:      	addq	$0xe0, %r12
    3ac3:      	leaq	0xa0(%rsp), %rdi
    3acb:      	movl	$0x8, %ecx
    3ad0:      	movl	$0x4, %eax
    3ad5:      	movl	$0x4, %r15d
    3adb:      	movl	$0x8, %esi
    3ae0:      	movq	%r12, %rdx
    3ae3:      	callq	*%rax
    3ae5:      	movq	0xa0(%rsp), %rcx
    3aed:      	testq	%rcx, %rcx
    3af0:      	je	0x3b5d <generic_fentry_process_event+0x37ad>
    3af2:      	addq	$0x5, %rcx
    3af6:      	leaq	0x38(%rsp), %rdi
    3afb:      	movl	$0x8, %edx
    3b00:      	movl	$0x4, %eax
    3b05:      	movq	0xa0(%rsp), %rdx
    3b0d:      	addq	$0x5, %rdx
    3b11:      	movl	$0x8, %esi
    3b16:      	callq	*%rax
    3b18:      	movq	0xa0(%rsp), %rbx
    3b20:      	movq	0x38(%rsp), %r12
    3b25:      	movq	0x10(%rsp), %r13
    3b2a:      	leaq	0x38(%r13), %rdi
    3b2e:      	leaq	(%rbx,%r12,8), %rdx
    3b32:      	addq	$0x44, %rdx
    3b36:      	movl	$0x4, %eax
    3b3b:      	movl	$0x4, %esi
    3b40:      	callq	*%rax
    3b42:      	addq	$0x3c, %r13
    3b46:      	leaq	(%rbx,%r12,8), %rdx
    3b4a:      	addq	$0x45, %rdx
    3b4e:      	movl	$0x4, %eax
    3b53:      	movq	%r13, %rdi
    3b56:      	movl	$0x4, %esi
    3b5b:      	callq	*%rax
    3b5d:      	movl	$0x40, %r15d
    3b63:      	movq	0x8(%rsp), %rcx
    3b68:      	movq	0x58(%rsp), %rbx
    3b6d:      	movq	0x18(%rsp), %rbp
    3b72:      	movq	(%rsp), %rsi
    3b76:      	movq	0x30(%rsp), %r14
    3b7b:      	jmp	0x29c6 <generic_fentry_process_event+0x2616>
    3b80:      	movw	%ax, 0xd0(%rsp)
    3b88:      	jmp	0x39a6 <generic_fentry_process_event+0x35f6>
    3b8d:      	nopl	(%rax)

0000000000003b90 <generic_fentry_process_filter>:
    3b90:      	pushq	%rbp
    3b91:      	pushq	%r15
    3b93:      	pushq	%r14
    3b95:      	pushq	%r13
    3b97:      	pushq	%r12
    3b99:      	pushq	%rbx
    3b9a:      	subq	$0xe8, %rsp
    3ba1:      	movq	%rdi, %rbx
    3ba4:      	movl	$0x0, 0xc8(%rsp)
    3baf:      	movq	(%rip), %rdi            # 0x3bb6 <generic_fentry_process_filter+0x26>
    3bb6:      	leaq	0xc8(%rsp), %rsi
    3bbe:      	movl	$0x1, %eax
    3bc3:      	callq	*%rax
    3bc5:      	testq	%rax, %rax
    3bc8:      	je	0x61b3 <generic_fentry_process_filter+0x2623>
    3bce:      	movq	%rax, %r14
    3bd1:      	movl	$0x23, %eax
    3bd6:      	callq	*%rax
    3bd8:      	movq	%rax, %rcx
    3bdb:      	movq	%rax, 0x60(%rsp)
    3be0:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3be7:      	leaq	0x10(%rsp), %rdi
    3bec:      	movl	$0x4, %edx
    3bf1:      	movl	$0x71, %eax
    3bf6:      	movl	$0xaf4, %edx            # imm = 0xAF4
    3bfb:      	addq	0x60(%rsp), %rdx
    3c00:      	movl	$0x4, %esi
    3c05:      	callq	*%rax
    3c07:      	movl	0x10(%rsp), %eax
    3c0b:      	movl	%eax, 0x40(%rsp)
    3c0f:      	movq	(%rip), %rdi            # 0x3c16 <generic_fentry_process_filter+0x86>
    3c16:      	leaq	0x40(%rsp), %rsi
    3c1b:      	movl	$0x1, %eax
    3c20:      	callq	*%rax
    3c22:      	testq	%rax, %rax
    3c25:      	movq	%r14, 0x50(%rsp)
    3c2a:      	je	0x3c3a <generic_fentry_process_filter+0xaa>
    3c2c:      	movq	%rax, %r15
    3c2f:      	cmpq	$0x0, 0x8(%rax)
    3c34:      	jne	0x4bbf <generic_fentry_process_filter+0x102f>
    3c3a:      	movl	$0xb00, %edx            # imm = 0xB00
    3c3f:      	movq	0x60(%rsp), %rcx
    3c44:      	addq	%rdx, %rcx
    3c47:      	leaq	0x60(%rsp), %rdi
    3c4c:      	movl	$0x8, %esi
    3c51:      	movl	$0x71, %eax
    3c56:      	addq	0x60(%rsp), %rdx
    3c5b:      	movl	$0x8, %esi
    3c60:      	callq	*%rax
    3c62:      	movq	0x60(%rsp), %rcx
    3c67:      	testq	%rcx, %rcx
    3c6a:      	je	0x3dff <generic_fentry_process_filter+0x26f>
    3c70:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3c77:      	leaq	0x10(%rsp), %rdi
    3c7c:      	movl	$0x4, %edx
    3c81:      	movl	$0x71, %eax
    3c86:      	movl	$0xaf4, %edx            # imm = 0xAF4
    3c8b:      	addq	0x60(%rsp), %rdx
    3c90:      	movl	$0x4, %esi
    3c95:      	callq	*%rax
    3c97:      	movl	0x10(%rsp), %eax
    3c9b:      	movl	%eax, 0x40(%rsp)
    3c9f:      	movq	(%rip), %rdi            # 0x3ca6 <generic_fentry_process_filter+0x116>
    3ca6:      	leaq	0x40(%rsp), %rsi
    3cab:      	movl	$0x1, %eax
    3cb0:      	callq	*%rax
    3cb2:      	testq	%rax, %rax
    3cb5:      	je	0x3cc5 <generic_fentry_process_filter+0x135>
    3cb7:      	movq	%rax, %r15
    3cba:      	cmpq	$0x0, 0x8(%rax)
    3cbf:      	jne	0x4bbf <generic_fentry_process_filter+0x102f>
    3cc5:      	movl	$0xb00, %edx            # imm = 0xB00
    3cca:      	movq	0x60(%rsp), %rcx
    3ccf:      	addq	%rdx, %rcx
    3cd2:      	leaq	0x60(%rsp), %rdi
    3cd7:      	movl	$0x8, %esi
    3cdc:      	movl	$0x71, %eax
    3ce1:      	addq	0x60(%rsp), %rdx
    3ce6:      	movl	$0x8, %esi
    3ceb:      	callq	*%rax
    3ced:      	movq	0x60(%rsp), %rcx
    3cf2:      	testq	%rcx, %rcx
    3cf5:      	je	0x3dff <generic_fentry_process_filter+0x26f>
    3cfb:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3d02:      	leaq	0x10(%rsp), %rdi
    3d07:      	movl	$0x4, %edx
    3d0c:      	movl	$0x71, %eax
    3d11:      	movl	$0xaf4, %edx            # imm = 0xAF4
    3d16:      	addq	0x60(%rsp), %rdx
    3d1b:      	movl	$0x4, %esi
    3d20:      	callq	*%rax
    3d22:      	movl	0x10(%rsp), %eax
    3d26:      	movl	%eax, 0x40(%rsp)
    3d2a:      	movq	(%rip), %rdi            # 0x3d31 <generic_fentry_process_filter+0x1a1>
    3d31:      	leaq	0x40(%rsp), %rsi
    3d36:      	movl	$0x1, %eax
    3d3b:      	callq	*%rax
    3d3d:      	testq	%rax, %rax
    3d40:      	je	0x3d50 <generic_fentry_process_filter+0x1c0>
    3d42:      	movq	%rax, %r15
    3d45:      	cmpq	$0x0, 0x8(%rax)
    3d4a:      	jne	0x4bbf <generic_fentry_process_filter+0x102f>
    3d50:      	movl	$0xb00, %edx            # imm = 0xB00
    3d55:      	movq	0x60(%rsp), %rcx
    3d5a:      	addq	%rdx, %rcx
    3d5d:      	leaq	0x60(%rsp), %rdi
    3d62:      	movl	$0x8, %esi
    3d67:      	movl	$0x71, %eax
    3d6c:      	addq	0x60(%rsp), %rdx
    3d71:      	movl	$0x8, %esi
    3d76:      	callq	*%rax
    3d78:      	movq	0x60(%rsp), %rcx
    3d7d:      	testq	%rcx, %rcx
    3d80:      	je	0x3dff <generic_fentry_process_filter+0x26f>
    3d82:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3d89:      	leaq	0x10(%rsp), %rdi
    3d8e:      	movl	$0x4, %edx
    3d93:      	movl	$0x71, %eax
    3d98:      	movl	$0xaf4, %edx            # imm = 0xAF4
    3d9d:      	addq	0x60(%rsp), %rdx
    3da2:      	movl	$0x4, %esi
    3da7:      	callq	*%rax
    3da9:      	movl	0x10(%rsp), %eax
    3dad:      	movl	%eax, 0x40(%rsp)
    3db1:      	movq	(%rip), %rdi            # 0x3db8 <generic_fentry_process_filter+0x228>
    3db8:      	leaq	0x40(%rsp), %rsi
    3dbd:      	movl	$0x1, %eax
    3dc2:      	callq	*%rax
    3dc4:      	testq	%rax, %rax
    3dc7:      	je	0x3dd7 <generic_fentry_process_filter+0x247>
    3dc9:      	movq	%rax, %r15
    3dcc:      	cmpq	$0x0, 0x8(%rax)
    3dd1:      	jne	0x4bbf <generic_fentry_process_filter+0x102f>
    3dd7:      	movl	$0xb00, %edx            # imm = 0xB00
    3ddc:      	movq	0x60(%rsp), %rcx
    3de1:      	addq	%rdx, %rcx
    3de4:      	leaq	0x60(%rsp), %rdi
    3de9:      	movl	$0x8, %esi
    3dee:      	movl	$0x71, %eax
    3df3:      	addq	0x60(%rsp), %rdx
    3df8:      	movl	$0x8, %esi
    3dfd:      	callq	*%rax
    3dff:      	movq	%rbx, 0xb8(%rsp)
    3e07:      	movl	$0x23, %eax
    3e0c:      	callq	*%rax
    3e0e:      	movq	%rax, %r13
    3e11:      	leaq	0xaf4(%rax), %rdx
    3e18:      	leaq	0x60(%rsp), %rdi
    3e1d:      	movl	$0x4, %ecx
    3e22:      	movl	$0x4, %eax
    3e27:      	movl	$0x4, %ebp
    3e2c:      	movl	$0x4, %esi
    3e31:      	callq	*%rax
    3e33:      	movl	0x60(%rsp), %eax
    3e37:      	movl	%eax, 0x5f10(%r14)
    3e3e:      	movl	$0x7d, %eax
    3e43:      	callq	*%rax
    3e45:      	movq	%rax, 0x5f18(%r14)
    3e4c:      	movl	$0x0, 0x5f20(%r14)
    3e57:      	movq	$0x0, 0x5f28(%r14)
    3e62:      	movl	$0x0, 0x5f30(%r14)
    3e6d:      	leaq	0x60(%r13), %rdx
    3e71:      	leaq	0x40(%rsp), %rdi
    3e76:      	movl	$0x8, %ecx
    3e7b:      	movl	$0x71, %eax
    3e80:      	movl	$0x8, %esi
    3e85:      	callq	*%rax
    3e87:      	movq	0x40(%rsp), %rcx
    3e8c:      	xorl	%ebx, %ebx
    3e8e:      	testq	%rcx, %rcx
    3e91:      	je	0x3f00 <generic_fentry_process_filter+0x370>
    3e93:      	addq	$0x4, %rcx
    3e97:      	leaq	0x10(%rsp), %rdi
    3e9c:      	movl	$0x4, %edx
    3ea1:      	movl	$0x71, %eax
    3ea6:      	movq	0x40(%rsp), %rdx
    3eab:      	addq	$0x4, %rdx
    3eaf:      	movl	$0x4, %esi
    3eb4:      	callq	*%rax
    3eb6:      	movl	0x10(%rsp), %eax
    3eba:      	testl	%eax, %eax
    3ebc:      	je	0x3f00 <generic_fentry_process_filter+0x370>
    3ebe:      	movq	0x40(%rsp), %rcx
    3ec3:      	shll	$0x4, %eax
    3ec6:      	addq	%rax, %rcx
    3ec9:      	addq	$0x80, %rcx
    3ed0:      	leaq	0x60(%rsp), %rdi
    3ed5:      	movl	$0x10, %edx
    3eda:      	movl	$0x71, %eax
    3edf:      	movq	0x40(%rsp), %rcx
    3ee4:      	movl	0x10(%rsp), %edx
    3ee8:      	shll	$0x4, %edx
    3eeb:      	addq	%rcx, %rdx
    3eee:      	addq	$0x80, %rdx
    3ef5:      	movl	$0x10, %esi
    3efa:      	callq	*%rax
    3efc:      	movl	0x60(%rsp), %ebx
    3f00:      	movl	%ebx, 0x5f34(%r14)
    3f07:      	leaq	0xd00(%r13), %r15
    3f0e:      	leaq	0x60(%rsp), %rdi
    3f13:      	movl	$0x8, %ecx
    3f18:      	movl	$0x4, %eax
    3f1d:      	leaq	0x5f60(%r14), %rbx
    3f24:      	movl	$0x8, %esi
    3f29:      	movq	%r15, %rdx
    3f2c:      	callq	*%rax
    3f2e:      	movq	0x60(%rsp), %r12
    3f33:      	leaq	0x5f68(%r14), %rdi
    3f3a:      	leaq	0x40(%r12), %rdx
    3f3f:      	movl	$0x8, %ecx
    3f44:      	movl	$0x4, %eax
    3f49:      	movl	$0x8, %esi
    3f4e:      	callq	*%rax
    3f50:      	leaq	0x5f70(%r14), %rdi
    3f57:      	leaq	0x30(%r12), %rdx
    3f5c:      	movl	$0x8, %ecx
    3f61:      	movl	$0x4, %eax
    3f66:      	movl	$0x8, %esi
    3f6b:      	callq	*%rax
    3f6d:      	addq	$0x38, %r12
    3f71:      	movl	$0x8, %ecx
    3f76:      	movl	$0x4, %eax
    3f7b:      	movq	%rbx, %rdi
    3f7e:      	movl	$0x8, %esi
    3f83:      	movq	%r12, %rdx
    3f86:      	callq	*%rax
    3f88:      	leaq	0x5f38(%r14), %rbx
    3f8f:      	leaq	0xd70(%r13), %rdx
    3f96:      	leaq	0x10(%rsp), %rdi
    3f9b:      	movl	$0x8, %ecx
    3fa0:      	movl	$0x4, %eax
    3fa5:      	movl	$0x8, %esi
    3faa:      	callq	*%rax
    3fac:      	movq	0x10(%rsp), %rcx
    3fb1:      	leaq	0x60(%rsp), %rdi
    3fb6:      	movl	$0x48, %edx
    3fbb:      	movl	$0x4, %eax
    3fc0:      	movq	0x10(%rsp), %rdx
    3fc5:      	movl	$0x48, %esi
    3fca:      	callq	*%rax
    3fcc:      	movl	$0x218, %edx            # imm = 0x218
    3fd1:      	movq	0x68(%rsp), %rcx
    3fd6:      	addq	%rdx, %rcx
    3fd9:      	movl	$0x4, %eax
    3fde:      	addq	0x68(%rsp), %rdx
    3fe3:      	movq	%rbx, %rdi
    3fe6:      	movl	$0x4, %esi
    3feb:      	callq	*%rax
    3fed:      	leaq	0x5f3c(%r14), %rdi
    3ff4:      	movl	$0x4d8, %edx            # imm = 0x4D8
    3ff9:      	movq	0x70(%rsp), %rcx
    3ffe:      	addq	%rdx, %rcx
    4001:      	movl	$0x4, %eax
    4006:      	addq	0x70(%rsp), %rdx
    400b:      	movl	$0x4, %esi
    4010:      	callq	*%rax
    4012:      	leaq	0x5f40(%r14), %rdi
    4019:      	movq	0x78(%rsp), %rcx
    401e:      	addq	$0x58, %rcx
    4022:      	movl	$0x4, %eax
    4027:      	movq	0x78(%rsp), %rdx
    402c:      	addq	$0x58, %rdx
    4030:      	movl	$0x4, %esi
    4035:      	callq	*%rax
    4037:      	movq	$0x0, 0x58(%rsp)
    4040:      	leaq	0xb58(%r13), %rdx
    4047:      	leaq	0x58(%rsp), %rdi
    404c:      	movl	$0x8, %ecx
    4051:      	movl	$0x4, %eax
    4056:      	movl	$0x8, %esi
    405b:      	callq	*%rax
    405d:      	movq	0x58(%rsp), %rcx
    4062:      	testq	%rcx, %rcx
    4065:      	je	0x4114 <generic_fentry_process_filter+0x584>
    406b:      	movl	$0x0, 0xa8(%rsp)
    4076:      	addq	$0x4, %rcx
    407a:      	leaq	0xa8(%rsp), %rdi
    4082:      	movl	$0x4, %edx
    4087:      	movl	$0x4, %eax
    408c:      	movq	0x58(%rsp), %rdx
    4091:      	addq	$0x4, %rdx
    4095:      	movl	$0x4, %esi
    409a:      	callq	*%rax
    409c:      	movq	0x58(%rsp), %rax
    40a1:      	movslq	0xa8(%rsp), %rcx
    40a9:      	shlq	$0x4, %rcx
    40ad:      	addq	%rax, %rcx
    40b0:      	addq	$0x80, %rcx
    40b7:      	leaq	0x40(%rsp), %rdi
    40bc:      	movl	$0x10, %edx
    40c1:      	movl	$0x4, %eax
    40c6:      	movq	0x58(%rsp), %rcx
    40cb:      	movslq	0xa8(%rsp), %rdx
    40d3:      	shlq	$0x4, %rdx
    40d7:      	addq	%rcx, %rdx
    40da:      	addq	$0x80, %rdx
    40e1:      	movl	$0x10, %esi
    40e6:      	callq	*%rax
    40e8:      	leaq	0x5f44(%r14), %rdi
    40ef:      	movl	$0x158, %edx            # imm = 0x158
    40f4:      	movq	0x48(%rsp), %rcx
    40f9:      	addq	%rdx, %rcx
    40fc:      	movl	$0x4, %esi
    4101:      	movl	$0x4, %eax
    4106:      	addq	0x48(%rsp), %rdx
    410b:      	movl	$0x4, %esi
    4110:      	callq	*%rax
    4112:      	jmp	0x411f <generic_fentry_process_filter+0x58f>
    4114:      	movl	$0x0, 0x5f44(%r14)
    411f:      	leaq	0x5f48(%r14), %rdi
    4126:      	movl	$0x158, %ebx            # imm = 0x158
    412b:      	movq	0x80(%rsp), %rcx
    4133:      	addq	%rbx, %rcx
    4136:      	movl	$0x4, %edx
    413b:      	movl	$0x4, %eax
    4140:      	movq	0x80(%rsp), %rdx
    4148:      	addq	%rbx, %rdx
    414b:      	movl	$0x4, %esi
    4150:      	callq	*%rax
    4152:      	leaq	0x5f4c(%r14), %rdi
    4159:      	movl	$0x118, %edx            # imm = 0x118
    415e:      	movq	0x88(%rsp), %rcx
    4166:      	addq	%rdx, %rcx
    4169:      	movl	$0x4, %esi
    416e:      	movl	$0x4, %eax
    4173:      	addq	0x88(%rsp), %rdx
    417b:      	movl	$0x4, %esi
    4180:      	callq	*%rax
    4182:      	leaq	0x5f50(%r14), %rdi
    4189:      	movl	$0x98, %r12d
    418f:      	movq	0x90(%rsp), %rcx
    4197:      	addq	%r12, %rcx
    419a:      	movl	$0x4, %edx
    419f:      	movl	$0x4, %eax
    41a4:      	movq	0x90(%rsp), %rdx
    41ac:      	addq	%r12, %rdx
    41af:      	movl	$0x4, %esi
    41b4:      	callq	*%rax
    41b6:      	leaq	0x5f54(%r14), %rdi
    41bd:      	movq	0x98(%rsp), %rcx
    41c5:      	addq	%r12, %rcx
    41c8:      	movl	$0x4, %edx
    41cd:      	movl	$0x4, %eax
    41d2:      	addq	0x98(%rsp), %r12
    41da:      	movl	$0x4, %esi
    41df:      	movq	%r12, %rdx
    41e2:      	callq	*%rax
    41e4:      	leaq	0x5f58(%r14), %rdi
    41eb:      	movq	0xa0(%rsp), %rcx
    41f3:      	addq	$0x58, %rcx
    41f7:      	movl	$0x4, %edx
    41fc:      	movl	$0x4, %eax
    4201:      	movq	0xa0(%rsp), %rdx
    4209:      	addq	$0x58, %rdx
    420d:      	movl	$0x4, %esi
    4212:      	callq	*%rax
    4214:      	movq	$0x0, 0x40(%rsp)
    421d:      	movq	$0x0, 0x58(%rsp)
    4226:      	leaq	0x40(%rsp), %rdi
    422b:      	movl	$0x8, %ecx
    4230:      	movl	$0x4, %eax
    4235:      	movl	$0x8, %esi
    423a:      	movq	%r15, %rdx
    423d:      	callq	*%rax
    423f:      	movl	$0x90, %edx
    4244:      	movq	0x40(%rsp), %rcx
    4249:      	addq	%rdx, %rcx
    424c:      	leaq	0x58(%rsp), %rdi
    4251:      	movl	$0x8, %esi
    4256:      	movl	$0x4, %eax
    425b:      	addq	0x40(%rsp), %rdx
    4260:      	movl	$0x8, %esi
    4265:      	callq	*%rax
    4267:      	leaq	0x5f5c(%r14), %rdi
    426e:      	movq	0x58(%rsp), %rcx
    4273:      	addq	%rbx, %rcx
    4276:      	movl	$0x4, %edx
    427b:      	movl	$0x4, %eax
    4280:      	addq	0x58(%rsp), %rbx
    4285:      	movl	$0x4, %esi
    428a:      	movq	%rbx, %rdx
    428d:      	callq	*%rax
    428f:      	cmpl	$0x1, 0x5f34(%r14)
    4297:      	jne	0x42a1 <generic_fentry_process_filter+0x711>
    4299:      	orb	$0x2, 0x5f33(%r14)
    42a1:      	leaq	0x5f78(%r14), %rdi
    42a8:      	movl	$0x308, %edx            # imm = 0x308
    42ad:      	movq	%rdi, 0x8(%rsp)
    42b2:      	xorl	%esi, %esi
    42b4:      	callq	0x42b9 <generic_fentry_process_filter+0x729>
    42b9:      	leaq	0x6290(%r14), %rbp
    42c0:      	addq	$0xa78, %r13            # imm = 0xA78
    42c7:      	leaq	0x40(%rsp), %rdi
    42cc:      	movl	$0x8, %ecx
    42d1:      	movl	$0x4, %eax
    42d6:      	movl	$0x8, %esi
    42db:      	movq	%r13, %rdx
    42de:      	callq	*%rax
    42e0:      	movl	$0x5f8, %edx            # imm = 0x5F8
    42e5:      	movq	0x40(%rsp), %rcx
    42ea:      	addq	%rdx, %rcx
    42ed:      	leaq	0x60(%rsp), %rdi
    42f2:      	movl	$0x8, %esi
    42f7:      	movl	$0x4, %eax
    42fc:      	addq	0x40(%rsp), %rdx
    4301:      	movl	$0x8, %esi
    4306:      	callq	*%rax
    4308:      	movq	0x60(%rsp), %rbx
    430d:      	movl	$0x0, 0xcc(%rsp)
    4318:      	movq	(%rip), %rdi            # 0x431f <generic_fentry_process_filter+0x78f>
    431f:      	leaq	0xcc(%rsp), %rsi
    4327:      	movl	$0x1, %eax
    432c:      	callq	*%rax
    432e:      	testq	%rax, %rax
    4331:      	je	0x4a37 <generic_fentry_process_filter+0xea7>
    4337:      	movq	%rax, %r12
    433a:      	movq	%rbp, 0x38(%rsp)
    433f:      	movl	$0x1000, 0x6410(%r14)   # imm = 0x1000
    434a:      	leaq	0x1000(%rax), %r13
    4351:      	movl	$0x23, %eax
    4356:      	callq	*%rax
    4358:      	leaq	0xd50(%rax), %rdx
    435f:      	leaq	0xd8(%rsp), %rdi
    4367:      	movl	$0x8, %ecx
    436c:      	movl	$0x4, %eax
    4371:      	movl	$0x8, %esi
    4376:      	callq	*%rax
    4378:      	movq	0xd8(%rsp), %rbp
    4380:      	leaq	0x48(%rbx), %r15
    4384:      	leaq	0xe0(%rsp), %rdi
    438c:      	movl	$0x8, %ecx
    4391:      	movl	$0x4, %eax
    4396:      	movl	$0x8, %esi
    439b:      	movq	%r15, %rdx
    439e:      	callq	*%rax
    43a0:      	movq	0xe0(%rsp), %r14
    43a8:      	leaq	0x10(%r14), %rdx
    43ac:      	leaq	0x60(%rsp), %rdi
    43b1:      	movl	$0x8, %ecx
    43b6:      	movl	$0x4, %eax
    43bb:      	movl	$0x8, %esi
    43c0:      	callq	*%rax
    43c2:      	cmpq	$0x0, 0x60(%rsp)
    43c8:      	je	0x4696 <generic_fentry_process_filter+0xb06>
    43ce:      	movq	0x50(%rsp), %r14
    43d3:      	movq	$0x0, 0x68(%rsp)
    43dc:      	movq	$0x0, 0x60(%rsp)
    43e5:      	movq	%r12, 0x70(%rsp)
    43ea:      	movq	$0x0, 0x78(%rsp)
    43f3:      	movq	$0x0, 0x80(%rsp)
    43ff:      	movq	$0x0, 0x88(%rsp)
    440b:      	movq	%r13, 0xc0(%rsp)
    4413:      	movq	%r13, 0x90(%rsp)
    441b:      	movl	0x6410(%r14), %eax
    4422:      	movl	%eax, 0x98(%rsp)
    4429:      	leaq	0x18(%rbp), %r13
    442d:      	movb	$0x0, 0x9c(%rsp)
    4435:      	addq	$0x20, %rbp
    4439:      	leaq	0x60(%rsp), %rdi
    443e:      	movl	$0x8, %ecx
    4443:      	movl	$0x4, %eax
    4448:      	addq	$0x40, %rbx
    444c:      	leaq	0x68(%rsp), %r12
    4451:      	leaq	0x78(%rsp), %r14
    4456:      	movl	$0x8, %esi
    445b:      	movq	%rbp, %rdx
    445e:      	callq	*%rax
    4460:      	movl	$0x8, %ecx
    4465:      	movl	$0x4, %eax
    446a:      	movq	%r12, %rdi
    446d:      	movl	$0x8, %esi
    4472:      	movq	%r13, %rdx
    4475:      	callq	*%rax
    4477:      	movl	$0x8, %ecx
    447c:      	movl	$0x4, %eax
    4481:      	movq	%r14, %rdi
    4484:      	movl	$0x8, %esi
    4489:      	movq	%r15, %rdx
    448c:      	callq	*%rax
    448e:      	movl	$0x8, %ecx
    4493:      	movl	$0x4, %eax
    4498:      	leaq	0x80(%rsp), %rdi
    44a0:      	movl	$0x8, %esi
    44a5:      	movq	%rbx, %rdx
    44a8:      	callq	*%rax
    44aa:      	movq	0x80(%rsp), %rax
    44b2:      	addq	$-0x20, %rax
    44b6:      	movq	%rax, 0x88(%rsp)
    44be:      	movq	(%rip), %rax            # 0x44c5 <generic_fentry_process_filter+0x935>
    44c5:      	cmpb	$0x0, (%rax)
    44c8:      	je	0x46ed <generic_fentry_process_filter+0xb5d>
    44ce:      	movl	$0x800, %r14d           # imm = 0x800
    44d4:      	movl	$0x8, %ebp
    44d9:      	leaq	0x10(%rsp), %rbx
    44de:      	nop
    44e0:      	movq	0x78(%rsp), %r15
    44e5:      	movq	0x80(%rsp), %rdx
    44ed:      	movq	0x88(%rsp), %r12
    44f5:      	cmpq	0x60(%rsp), %r15
    44fa:      	jne	0x4507 <generic_fentry_process_filter+0x977>
    44fc:      	cmpq	0x68(%rsp), %rdx
    4501:      	je	0x48af <generic_fentry_process_filter+0xd1f>
    4507:      	movl	$0x4, %eax
    450c:      	leaq	0xa8(%rsp), %rdi
    4514:      	movl	$0x8, %esi
    4519:      	callq	*%rax
    451b:      	cmpq	0xa8(%rsp), %r15
    4523:      	je	0x4630 <generic_fentry_process_filter+0xaa0>
    4529:      	leaq	0x18(%r15), %r13
    452d:      	movl	$0x4, %eax
    4532:      	movq	%rbx, %rdi
    4535:      	movl	$0x8, %esi
    453a:      	movq	%r13, %rdx
    453d:      	callq	*%rax
    453f:      	cmpq	%r15, 0x10(%rsp)
    4544:      	je	0x4630 <generic_fentry_process_filter+0xaa0>
    454a:      	movl	$0x4, %eax
    454f:      	leaq	0x58(%rsp), %rdi
    4554:      	movl	$0x8, %esi
    4559:      	movq	%r13, %rdx
    455c:      	callq	*%rax
    455e:      	addq	$0x20, %r15
    4562:      	movl	$0x4, %eax
    4567:      	leaq	0x40(%rsp), %rdi
    456c:      	movl	$0x10, %ecx
    4571:      	movl	$0x10, %esi
    4576:      	movq	%r15, %rdx
    4579:      	callq	*%rax
    457b:      	movq	0x70(%rsp), %r15
    4580:      	movq	0x90(%rsp), %rax
    4588:      	movl	0x44(%rsp), %r12d
    458d:      	subq	%r15, %rax
    4590:      	movl	0x98(%rsp), %r13d
    4598:      	movl	%r12d, %edx
    459b:      	subl	%r13d, %edx
    459e:      	movl	$0x0, %ecx
    45a3:      	cmovbl	%ecx, %edx
    45a6:      	addq	0x48(%rsp), %rdx
    45ab:      	xorl	%esi, %esi
    45ad:      	cmpl	%r12d, %r13d
    45b0:      	seta	%sil
    45b4:      	movl	%r12d, %ecx
    45b7:      	cmovbl	%r13d, %ecx
    45bb:      	addl	%ecx, %esi
    45bd:      	movl	%r13d, %edi
    45c0:      	subl	%esi, %edi
    45c2:      	movl	%edi, 0x98(%rsp)
    45c9:      	subq	%rsi, %rax
    45cc:      	jb	0x48b7 <generic_fentry_process_filter+0xd27>
    45d2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    45d8:      	ja	0x48b7 <generic_fentry_process_filter+0xd27>
    45de:      	cmpl	%r12d, %r13d
    45e1:      	jbe	0x45e8 <generic_fentry_process_filter+0xa58>
    45e3:      	movb	$0x2f, (%r15,%rax)
    45e8:      	xorl	%edi, %edi
    45ea:      	cmpl	%r12d, %r13d
    45ed:      	seta	%dil
    45f1:      	movzbl	%cl, %esi
    45f4:      	addq	%rax, %r15
    45f7:      	addq	%r15, %rdi
    45fa:      	movl	$0x4, %eax
    45ff:      	callq	*%rax
    4601:      	movq	%r15, 0x90(%rsp)
    4609:      	cmpl	%r12d, %r13d
    460c:      	jbe	0x48b7 <generic_fentry_process_filter+0xd27>
    4612:      	movq	0x58(%rsp), %rax
    4617:      	movq	%rax, 0x78(%rsp)
    461c:      	decl	%r14d
    461f:      	jne	0x44e0 <generic_fentry_process_filter+0x950>
    4625:      	jmp	0x48b7 <generic_fentry_process_filter+0xd27>
    462a:      	nopw	(%rax,%rax)
    4630:      	leaq	0x10(%r12), %rdx
    4635:      	movl	$0x4, %eax
    463a:      	movq	%rbx, %rdi
    463d:      	movl	$0x8, %esi
    4642:      	callq	*%rax
    4644:      	movq	0x88(%rsp), %rax
    464c:      	cmpq	0x10(%rsp), %rax
    4651:      	je	0x48af <generic_fentry_process_filter+0xd1f>
    4657:      	addq	$0x18, %r12
    465b:      	movl	$0x4, %eax
    4660:      	leaq	0x78(%rsp), %rdi
    4665:      	movl	$0x8, %esi
    466a:      	movq	%r12, %rdx
    466d:      	callq	*%rax
    466f:      	movq	0x10(%rsp), %rax
    4674:      	movq	%rax, 0x88(%rsp)
    467c:      	addq	$0x20, %rax
    4680:      	movq	%rax, 0x80(%rsp)
    4688:      	decl	%r14d
    468b:      	jne	0x44e0 <generic_fentry_process_filter+0x950>
    4691:      	jmp	0x48b7 <generic_fentry_process_filter+0xd27>
    4696:      	leaq	0x18(%r14), %rdx
    469a:      	leaq	0x60(%rsp), %rdi
    469f:      	movl	$0x8, %ecx
    46a4:      	movl	$0x4, %eax
    46a9:      	movl	$0x8, %esi
    46ae:      	callq	*%rax
    46b0:      	cmpq	%r14, 0x60(%rsp)
    46b5:      	je	0x43ce <generic_fentry_process_filter+0x83e>
    46bb:      	movq	0x50(%rsp), %r14
    46c0:      	movl	0x6410(%r14), %ecx
    46c7:      	leal	-0xa(%rcx), %eax
    46ca:      	movl	%eax, 0x6410(%r14)
    46d1:      	cmpl	$0x9, %ecx
    46d4:      	jg	0x5074 <generic_fentry_process_filter+0x14e4>
    46da:      	movl	$0xffffffdc, 0x6414(%r14) # imm = 0xFFFFFFDC
    46e5:      	movq	%r13, %rbx
    46e8:      	jmp	0x4938 <generic_fentry_process_filter+0xda8>
    46ed:      	movl	$0x800, %r14d           # imm = 0x800
    46f3:      	movl	$0x8, %ebp
    46f8:      	leaq	0x10(%rsp), %rbx
    46fd:      	nopl	(%rax)
    4700:      	movq	0x78(%rsp), %r15
    4705:      	movq	0x80(%rsp), %rdx
    470d:      	movq	0x88(%rsp), %r12
    4715:      	cmpq	0x60(%rsp), %r15
    471a:      	jne	0x4727 <generic_fentry_process_filter+0xb97>
    471c:      	cmpq	0x68(%rsp), %rdx
    4721:      	je	0x48af <generic_fentry_process_filter+0xd1f>
    4727:      	movl	$0x4, %eax
    472c:      	leaq	0xa8(%rsp), %rdi
    4734:      	movl	$0x8, %esi
    4739:      	callq	*%rax
    473b:      	cmpq	0xa8(%rsp), %r15
    4743:      	je	0x4850 <generic_fentry_process_filter+0xcc0>
    4749:      	leaq	0x18(%r15), %r13
    474d:      	movl	$0x4, %eax
    4752:      	movq	%rbx, %rdi
    4755:      	movl	$0x8, %esi
    475a:      	movq	%r13, %rdx
    475d:      	callq	*%rax
    475f:      	cmpq	%r15, 0x10(%rsp)
    4764:      	je	0x4850 <generic_fentry_process_filter+0xcc0>
    476a:      	movl	$0x4, %eax
    476f:      	leaq	0x58(%rsp), %rdi
    4774:      	movl	$0x8, %esi
    4779:      	movq	%r13, %rdx
    477c:      	callq	*%rax
    477e:      	addq	$0x20, %r15
    4782:      	movl	$0x4, %eax
    4787:      	leaq	0x40(%rsp), %rdi
    478c:      	movl	$0x10, %ecx
    4791:      	movl	$0x10, %esi
    4796:      	movq	%r15, %rdx
    4799:      	callq	*%rax
    479b:      	movq	0x70(%rsp), %r15
    47a0:      	movq	0x90(%rsp), %rax
    47a8:      	movl	0x44(%rsp), %r12d
    47ad:      	subq	%r15, %rax
    47b0:      	movl	0x98(%rsp), %r13d
    47b8:      	movl	%r12d, %edx
    47bb:      	subl	%r13d, %edx
    47be:      	movl	$0x0, %ecx
    47c3:      	cmovbl	%ecx, %edx
    47c6:      	addq	0x48(%rsp), %rdx
    47cb:      	xorl	%esi, %esi
    47cd:      	cmpl	%r12d, %r13d
    47d0:      	seta	%sil
    47d4:      	movl	%r12d, %ecx
    47d7:      	cmovbl	%r13d, %ecx
    47db:      	addl	%ecx, %esi
    47dd:      	movl	%r13d, %edi
    47e0:      	subl	%esi, %edi
    47e2:      	movl	%edi, 0x98(%rsp)
    47e9:      	subq	%rsi, %rax
    47ec:      	jb	0x48b7 <generic_fentry_process_filter+0xd27>
    47f2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    47f8:      	ja	0x48b7 <generic_fentry_process_filter+0xd27>
    47fe:      	cmpl	%r12d, %r13d
    4801:      	jbe	0x4808 <generic_fentry_process_filter+0xc78>
    4803:      	movb	$0x2f, (%r15,%rax)
    4808:      	xorl	%edi, %edi
    480a:      	cmpl	%r12d, %r13d
    480d:      	seta	%dil
    4811:      	movzbl	%cl, %esi
    4814:      	addq	%rax, %r15
    4817:      	addq	%r15, %rdi
    481a:      	movl	$0x4, %eax
    481f:      	callq	*%rax
    4821:      	movq	%r15, 0x90(%rsp)
    4829:      	cmpl	%r12d, %r13d
    482c:      	jbe	0x48b7 <generic_fentry_process_filter+0xd27>
    4832:      	movq	0x58(%rsp), %rax
    4837:      	movq	%rax, 0x78(%rsp)
    483c:      	decl	%r14d
    483f:      	jne	0x4700 <generic_fentry_process_filter+0xb70>
    4845:      	jmp	0x48b7 <generic_fentry_process_filter+0xd27>
    4847:      	nopw	(%rax,%rax)
    4850:      	leaq	0x10(%r12), %rdx
    4855:      	movl	$0x4, %eax
    485a:      	movq	%rbx, %rdi
    485d:      	movl	$0x8, %esi
    4862:      	callq	*%rax
    4864:      	movq	0x88(%rsp), %rax
    486c:      	cmpq	0x10(%rsp), %rax
    4871:      	je	0x48af <generic_fentry_process_filter+0xd1f>
    4873:      	addq	$0x18, %r12
    4877:      	movl	$0x4, %eax
    487c:      	leaq	0x78(%rsp), %rdi
    4881:      	movl	$0x8, %esi
    4886:      	movq	%r12, %rdx
    4889:      	callq	*%rax
    488b:      	movq	0x10(%rsp), %rax
    4890:      	movq	%rax, 0x88(%rsp)
    4898:      	addq	$0x20, %rax
    489c:      	movq	%rax, 0x80(%rsp)
    48a4:      	decl	%r14d
    48a7:      	jne	0x4700 <generic_fentry_process_filter+0xb70>
    48ad:      	jmp	0x48b7 <generic_fentry_process_filter+0xd27>
    48af:      	movb	$0x1, 0x9c(%rsp)
    48b7:      	movq	0x90(%rsp), %rbx
    48bf:      	movq	0xc0(%rsp), %rcx
    48c7:      	cmpq	%rcx, %rbx
    48ca:      	je	0x4918 <generic_fentry_process_filter+0xd88>
    48cc:      	xorl	%ecx, %ecx
    48ce:      	cmpb	$0x0, 0x9c(%rsp)
    48d6:      	sete	%cl
    48d9:      	addl	%ecx, %ecx
    48db:      	movl	0x98(%rsp), %eax
    48e2:      	movq	0x50(%rsp), %r14
    48e7:      	movl	%eax, 0x6410(%r14)
    48ee:      	movl	%ecx, 0x6414(%r14)
    48f5:      	testl	%eax, %eax
    48f7:      	movq	0x38(%rsp), %rbp
    48fc:      	jle	0x490e <generic_fentry_process_filter+0xd7e>
    48fe:      	movl	$0x1000, %ecx           # imm = 0x1000
    4903:      	subl	%eax, %ecx
    4905:      	movl	%ecx, 0x6410(%r14)
    490c:      	movl	%ecx, %eax
    490e:      	testq	%rbx, %rbx
    4911:      	jne	0x493d <generic_fentry_process_filter+0xdad>
    4913:      	jmp	0x4a37 <generic_fentry_process_filter+0xea7>
    4918:      	movq	0x50(%rsp), %r14
    491d:      	movl	$0x0, 0x6410(%r14)
    4928:      	movl	$0x0, 0x6414(%r14)
    4933:      	xorl	%eax, %eax
    4935:      	movq	%rcx, %rbx
    4938:      	movq	0x38(%rsp), %rbp
    493d:      	xorl	%ecx, %ecx
    493f:      	movq	%r14, %rdx
    4942:      	movl	%eax, %r14d
    4945:      	subl	$0x7f, %r14d
    4949:      	movl	$0x7f, %r15d
    494f:      	cmovbl	%eax, %r15d
    4953:      	cmovbl	%ecx, %r14d
    4957:      	cmpl	$0xff, %eax
    495c:      	movl	$0xff, %ecx
    4961:      	cmovbl	%eax, %ecx
    4964:      	movzbl	%cl, %esi
    4967:      	movl	%esi, 0x6410(%rdx)
    496d:      	movl	$0x4, %eax
    4972:      	movq	%rbp, %rdi
    4975:      	movq	%rbx, %rdx
    4978:      	callq	*%rax
    497a:      	testq	%rax, %rax
    497d:      	je	0x49dc <generic_fentry_process_filter+0xe4c>
    497f:      	negl	%eax
    4981:      	movw	%ax, 0x60(%rsp)
    4986:      	movw	$0x8, 0x62(%rsp)
    498d:      	movabsq	$0x4000002de, %rax      # imm = 0x4000002DE
    4997:      	movq	%rax, 0x64(%rsp)
    499c:      	movq	(%rip), %rdi            # 0x49a3 <generic_fentry_process_filter+0xe13>
    49a3:      	leaq	0x60(%rsp), %rsi
    49a8:      	movl	$0x1, %eax
    49ad:      	callq	*%rax
    49af:      	testq	%rax, %rax
    49b2:      	je	0x49b8 <generic_fentry_process_filter+0xe28>
    49b4:      	incl	(%rax)
    49b6:      	jmp	0x49dc <generic_fentry_process_filter+0xe4c>
    49b8:      	movl	$0x1, 0x40(%rsp)
    49c0:      	movq	(%rip), %rdi            # 0x49c7 <generic_fentry_process_filter+0xe37>
    49c7:      	xorl	%ecx, %ecx
    49c9:      	leaq	0x60(%rsp), %rsi
    49ce:      	leaq	0x40(%rsp), %rdx
    49d3:      	movl	$0x2, %eax
    49d8:      	xorl	%ecx, %ecx
    49da:      	callq	*%rax
    49dc:      	movq	0x50(%rsp), %rax
    49e1:      	leaq	0x6390(%rax), %rdi
    49e8:      	addq	%r14, %rbx
    49eb:      	movq	%rax, %r14
    49ee:      	movl	$0x4, %eax
    49f3:      	movl	%r15d, %esi
    49f6:      	movq	%rbx, %rdx
    49f9:      	callq	*%rax
    49fb:      	testq	%rax, %rax
    49fe:      	je	0x4a37 <generic_fentry_process_filter+0xea7>
    4a00:      	negl	%eax
    4a02:      	movw	%ax, 0x60(%rsp)
    4a07:      	movw	$0x8, 0x62(%rsp)
    4a0e:      	movabsq	$0x4000002e0, %rax      # imm = 0x4000002E0
    4a18:      	movq	%rax, 0x64(%rsp)
    4a1d:      	movq	(%rip), %rdi            # 0x4a24 <generic_fentry_process_filter+0xe94>
    4a24:      	leaq	0x60(%rsp), %rsi
    4a29:      	movl	$0x1, %eax
    4a2e:      	callq	*%rax
    4a30:      	testq	%rax, %rax
    4a33:      	je	0x4a64 <generic_fentry_process_filter+0xed4>
    4a35:      	incl	(%rax)
    4a37:      	movl	0x6410(%r14), %eax
    4a3e:      	leal	-0x101(%rax), %ecx
    4a44:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    4a4a:      	ja	0x4a9d <generic_fentry_process_filter+0xf0d>
    4a4c:      	movq	0x8(%rsp), %rax
    4a51:      	movl	$0xffffffff, (%rax)     # imm = 0xFFFFFFFF
    4a57:      	movq	0xb8(%rsp), %rbx
    4a5f:      	jmp	0x4bb3 <generic_fentry_process_filter+0x1023>
    4a64:      	movl	$0x1, 0x40(%rsp)
    4a6c:      	movq	(%rip), %rdi            # 0x4a73 <generic_fentry_process_filter+0xee3>
    4a73:      	xorl	%ecx, %ecx
    4a75:      	leaq	0x60(%rsp), %rsi
    4a7a:      	leaq	0x40(%rsp), %rdx
    4a7f:      	movl	$0x2, %eax
    4a84:      	xorl	%ecx, %ecx
    4a86:      	callq	*%rax
    4a88:      	movl	0x6410(%r14), %eax
    4a8f:      	leal	-0x101(%rax), %ecx
    4a95:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    4a9b:      	jbe	0x4a4c <generic_fentry_process_filter+0xebc>
    4a9d:      	movzbl	%al, %ebx
    4aa0:      	leaq	0x5f80(%r14), %rdi
    4aa7:      	movl	$0x4, %eax
    4aac:      	movl	%ebx, %esi
    4aae:      	movq	%rbp, %rdx
    4ab1:      	callq	*%rax
    4ab3:      	movq	%rax, %r15
    4ab6:      	testq	%rax, %rax
    4ab9:      	je	0x4b1b <generic_fentry_process_filter+0xf8b>
    4abb:      	movl	%r15d, %eax
    4abe:      	negl	%eax
    4ac0:      	movw	%ax, 0x60(%rsp)
    4ac5:      	movw	$0xf, 0x62(%rsp)
    4acc:      	movabsq	$0x400000164, %rax      # imm = 0x400000164
    4ad6:      	movq	%rax, 0x64(%rsp)
    4adb:      	movq	(%rip), %rdi            # 0x4ae2 <generic_fentry_process_filter+0xf52>
    4ae2:      	leaq	0x60(%rsp), %rsi
    4ae7:      	movl	$0x1, %eax
    4aec:      	callq	*%rax
    4aee:      	testq	%rax, %rax
    4af1:      	je	0x4af7 <generic_fentry_process_filter+0xf67>
    4af3:      	incl	(%rax)
    4af5:      	jmp	0x4b1b <generic_fentry_process_filter+0xf8b>
    4af7:      	movl	$0x1, 0x40(%rsp)
    4aff:      	movq	(%rip), %rdi            # 0x4b06 <generic_fentry_process_filter+0xf76>
    4b06:      	xorl	%ecx, %ecx
    4b08:      	leaq	0x60(%rsp), %rsi
    4b0d:      	leaq	0x40(%rsp), %rdx
    4b12:      	movl	$0x2, %eax
    4b17:      	xorl	%ecx, %ecx
    4b19:      	callq	*%rax
    4b1b:      	testl	%r15d, %r15d
    4b1e:      	cmovel	%ebx, %r15d
    4b22:      	movl	%r15d, 0x5f78(%r14)
    4b29:      	cmpl	$0x7f, %ebx
    4b2c:      	movl	$0x7f, %esi
    4b31:      	cmovbl	%ebx, %esi
    4b34:      	leaq	0x6080(%r14), %rdi
    4b3b:      	leaq	0x6390(%r14), %rdx
    4b42:      	movl	$0x4, %eax
    4b47:      	callq	*%rax
    4b49:      	testq	%rax, %rax
    4b4c:      	movq	0xb8(%rsp), %rbx
    4b54:      	je	0x4bb3 <generic_fentry_process_filter+0x1023>
    4b56:      	negl	%eax
    4b58:      	movw	%ax, 0x60(%rsp)
    4b5d:      	movw	$0xf, 0x62(%rsp)
    4b64:      	movabsq	$0x40000016a, %rax      # imm = 0x40000016A
    4b6e:      	movq	%rax, 0x64(%rsp)
    4b73:      	movq	(%rip), %rdi            # 0x4b7a <generic_fentry_process_filter+0xfea>
    4b7a:      	leaq	0x60(%rsp), %rsi
    4b7f:      	movl	$0x1, %eax
    4b84:      	callq	*%rax
    4b86:      	testq	%rax, %rax
    4b89:      	je	0x4b8f <generic_fentry_process_filter+0xfff>
    4b8b:      	incl	(%rax)
    4b8d:      	jmp	0x4bb3 <generic_fentry_process_filter+0x1023>
    4b8f:      	movl	$0x1, 0x40(%rsp)
    4b97:      	movq	(%rip), %rdi            # 0x4b9e <generic_fentry_process_filter+0x100e>
    4b9e:      	xorl	%ecx, %ecx
    4ba0:      	leaq	0x60(%rsp), %rsi
    4ba5:      	leaq	0x40(%rsp), %rdx
    4baa:      	movl	$0x2, %eax
    4baf:      	xorl	%ecx, %ecx
    4bb1:      	callq	*%rax
    4bb3:      	leaq	0x5f10(%r14), %r15
    4bba:      	orb	$0x10, 0x1(%r14)
    4bbf:      	leaq	0x5ef8(%r14), %rsi
    4bc6:      	movq	(%rip), %rdi            # 0x4bcd <generic_fentry_process_filter+0x103d>
    4bcd:      	movl	$0x1, %eax
    4bd2:      	callq	*%rax
    4bd4:      	testq	%rax, %rax
    4bd7:      	je	0x61b3 <generic_fentry_process_filter+0x2623>
    4bdd:      	movq	0x5eb8(%r14), %r13
    4be4:      	cmpq	$0x6, %r13
    4be8:      	jae	0x4e16 <generic_fentry_process_filter+0x1286>
    4bee:      	movslq	(%rax), %rcx
    4bf1:      	testq	%rcx, %rcx
    4bf4:      	je	0x4e38 <generic_fentry_process_filter+0x12a8>
    4bfa:      	cmpq	%rcx, %r13
    4bfd:      	jae	0x4e16 <generic_fentry_process_filter+0x1286>
    4c03:      	movq	%rax, 0x8(%rsp)
    4c08:      	movq	%rcx, 0xc0(%rsp)
    4c10:      	movq	%rbx, 0xb8(%rsp)
    4c18:      	movl	%r13d, 0x10(%rsp)
    4c1d:      	movl	$0x0, 0x58(%rsp)
    4c25:      	movq	(%rip), %rdi            # 0x4c2c <generic_fentry_process_filter+0x109c>
    4c2c:      	leaq	0x10(%rsp), %rsi
    4c31:      	movl	$0x1, %eax
    4c36:      	callq	*%rax
    4c38:      	testq	%rax, %rax
    4c3b:      	movq	%r15, 0x38(%rsp)
    4c40:      	je	0x4e54 <generic_fentry_process_filter+0x12c4>
    4c46:      	movq	%rax, %rbx
    4c49:      	movl	(%rax), %eax
    4c4b:      	testl	%eax, %eax
    4c4d:      	je	0x4e54 <generic_fentry_process_filter+0x12c4>
    4c53:      	cmpl	$0x0, 0x68(%r15)
    4c58:      	js	0x615b <generic_fentry_process_filter+0x25cb>
    4c5e:      	cmpl	$0x1b, %eax
    4c61:      	ja	0x615b <generic_fentry_process_filter+0x25cb>
    4c67:      	movl	$0x60, %ecx
    4c6c:      	btl	%eax, %ecx
    4c6f:      	jb	0x58ec <generic_fentry_process_filter+0x1d5c>
    4c75:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    4c7a:      	btl	%eax, %ecx
    4c7d:      	jb	0x5859 <generic_fentry_process_filter+0x1cc9>
    4c83:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    4c88:      	btl	%eax, %ecx
    4c8b:      	jae	0x615b <generic_fentry_process_filter+0x25cb>
    4c91:      	movq	%rbx, %rsi
    4c94:      	addq	$0x4, %rsi
    4c98:      	movq	(%rip), %rdi            # 0x4c9f <generic_fentry_process_filter+0x110f>
    4c9f:      	movl	$0x1, %eax
    4ca4:      	callq	*%rax
    4ca6:      	testq	%rax, %rax
    4ca9:      	je	0x615b <generic_fentry_process_filter+0x25cb>
    4caf:      	movq	%rax, %r12
    4cb2:      	movq	0x38(%rsp), %rax
    4cb7:      	movl	0x68(%rax), %eax
    4cba:      	cmpl	$0x7f, %eax
    4cbd:      	movl	$0x7f, %r14d
    4cc3:      	cmovll	%eax, %r14d
    4cc7:      	movq	(%rip), %rdi            # 0x4cce <generic_fentry_process_filter+0x113e>
    4cce:      	leaq	0x58(%rsp), %rsi
    4cd3:      	movl	$0x1, %eax
    4cd8:      	callq	*%rax
    4cda:      	testq	%rax, %rax
    4cdd:      	je	0x615b <generic_fentry_process_filter+0x25cb>
    4ce3:      	movq	%rax, %rbp
    4ce6:      	leal	(,%r14,8), %eax
    4cee:      	movl	%eax, (%rbp)
    4cf1:      	movq	0x38(%rsp), %rax
    4cf6:      	cmpl	$0x0, 0x6c(%rax)
    4cfa:      	jne	0x4ddd <generic_fentry_process_filter+0x124d>
    4d00:      	movq	0x38(%rsp), %r15
    4d05:      	movl	0x68(%r15), %ecx
    4d09:      	movl	%ecx, %eax
    4d0b:      	subl	%r14d, %eax
    4d0e:      	movl	%r14d, %edx
    4d11:      	andl	$0x7f, %edx
    4d14:      	addl	%edx, %eax
    4d16:      	addl	%ecx, %edx
    4d18:      	movl	%r14d, %ecx
    4d1b:      	notl	%ecx
    4d1d:      	addl	%edx, %ecx
    4d1f:      	subl	%r14d, %edx
    4d22:      	leal	-0x4(%rdx), %esi
    4d25:      	leaq	0x1f3(%r15), %rdi
    4d2c:      	leal	-0x3(%rdx), %r8d
    4d30:      	addl	$-0x2, %edx
    4d33:      	movq	$-0x3, %r9
    4d3a:      	leal	(%rcx,%r9), %r10d
    4d3e:      	addl	$0x3, %r10d
    4d42:      	andl	$0x7f, %r10d
    4d46:      	movzbl	0x170(%r15,%r10), %r10d
    4d4f:      	movb	%r10b, -0x3(%rdi)
    4d53:      	leaq	(%rax,%r9), %r10
    4d57:      	cmpq	$-0x2, %r10
    4d5b:      	je	0x4dd5 <generic_fentry_process_filter+0x1245>
    4d5d:      	leal	(%rdx,%r9), %r11d
    4d61:      	addl	$0x3, %r11d
    4d65:      	andl	$0x7f, %r11d
    4d69:      	movzbl	0x170(%r15,%r11), %r11d
    4d72:      	movb	%r11b, -0x2(%rdi)
    4d76:      	cmpq	$-0x1, %r10
    4d7a:      	je	0x4dd5 <generic_fentry_process_filter+0x1245>
    4d7c:      	leal	(%r8,%r9), %r10d
    4d80:      	addl	$0x3, %r10d
    4d84:      	andl	$0x7f, %r10d
    4d88:      	movzbl	0x170(%r15,%r10), %r10d
    4d91:      	movb	%r10b, -0x1(%rdi)
    4d95:      	movq	%rax, %r10
    4d98:      	addq	%r9, %r10
    4d9b:      	je	0x4dd5 <generic_fentry_process_filter+0x1245>
    4d9d:      	cmpq	$-0x7f, %r9
    4da1:      	je	0x4dd5 <generic_fentry_process_filter+0x1245>
    4da3:      	leal	(%rsi,%r9), %r10d
    4da7:      	addl	$0x3, %r10d
    4dab:      	andl	$0x7f, %r10d
    4daf:      	movzbl	0x170(%r15,%r10), %r10d
    4db8:      	movb	%r10b, (%rdi)
    4dbb:      	addq	$0x4, %rdi
    4dbf:      	leaq	(%rax,%r9), %r10
    4dc3:      	addq	$-0x4, %r10
    4dc7:      	addq	$-0x4, %r9
    4dcb:      	cmpq	$-0x3, %r10
    4dcf:      	jne	0x4d3a <generic_fentry_process_filter+0x11aa>
    4dd5:      	movl	$0x1, 0x6c(%r15)
    4ddd:      	cmpl	$0x7f, %r14d
    4de1:      	ja	0x4e09 <generic_fentry_process_filter+0x1279>
    4de3:      	movslq	%r14d, %rsi
    4de6:      	movq	%rbp, %rdi
    4de9:      	addq	$0x4, %rdi
    4ded:      	movq	0x38(%rsp), %rax
    4df2:      	leaq	0x1f0(%rax), %rdx
    4df9:      	movl	$0x4, %eax
    4dfe:      	callq	*%rax
    4e00:      	testq	%rax, %rax
    4e03:      	js	0x615b <generic_fentry_process_filter+0x25cb>
    4e09:      	movl	$0x1, %eax
    4e0e:      	movq	%r12, %rdi
    4e11:      	jmp	0x58e4 <generic_fentry_process_filter+0x1d54>
    4e16:      	movl	(%r15), %eax
    4e19:      	movl	%eax, 0x10(%r14)
    4e1d:      	movq	0x8(%r15), %rax
    4e21:      	movq	%rax, 0x18(%r14)
    4e25:      	cmpb	$0x0, 0x5ec0(%r14)
    4e2d:      	jne	0x619e <generic_fentry_process_filter+0x260e>
    4e33:      	jmp	0x61b3 <generic_fentry_process_filter+0x2623>
    4e38:      	movb	$0x1, 0x5ec0(%r14)
    4e40:      	movl	(%r15), %eax
    4e43:      	movl	%eax, 0x10(%r14)
    4e47:      	movq	0x8(%r15), %rax
    4e4b:      	movq	%rax, 0x18(%r14)
    4e4f:      	jmp	0x619e <generic_fentry_process_filter+0x260e>
    4e54:      	movq	0x8(%rsp), %r10
    4e59:      	movq	(%rip), %rax            # 0x4e60 <generic_fentry_process_filter+0x12d0>
    4e60:      	cmpb	$0x0, (%rax)
    4e63:      	je	0x50a5 <generic_fentry_process_filter+0x1515>
    4e69:      	movq	(%rip), %rdi            # 0x4e70 <generic_fentry_process_filter+0x12e0>
    4e70:      	movl	$0x1, %eax
    4e75:      	movq	0x38(%rsp), %rsi
    4e7a:      	callq	*%rax
    4e7c:      	movq	0x8(%rsp), %r10
    4e81:      	testq	%rax, %rax
    4e84:      	je	0x50a5 <generic_fentry_process_filter+0x1515>
    4e8a:      	movq	%rax, %rbp
    4e8d:      	leal	0x5(%r13), %eax
    4e91:      	movl	%eax, 0x10(%rsp)
    4e95:      	movl	$0x0, 0x58(%rsp)
    4e9d:      	movq	(%rip), %rdi            # 0x4ea4 <generic_fentry_process_filter+0x1314>
    4ea4:      	leaq	0x10(%rsp), %rsi
    4ea9:      	movl	$0x1, %eax
    4eae:      	callq	*%rax
    4eb0:      	testq	%rax, %rax
    4eb3:      	je	0x50a0 <generic_fentry_process_filter+0x1510>
    4eb9:      	movq	%rax, %r12
    4ebc:      	movl	(%rax), %eax
    4ebe:      	testl	%eax, %eax
    4ec0:      	je	0x50a0 <generic_fentry_process_filter+0x1510>
    4ec6:      	cmpl	$0x0, (%rbp)
    4eca:      	js	0x615b <generic_fentry_process_filter+0x25cb>
    4ed0:      	cmpl	$0x1b, %eax
    4ed3:      	ja	0x615b <generic_fentry_process_filter+0x25cb>
    4ed9:      	movl	$0x60, %ecx
    4ede:      	btl	%eax, %ecx
    4ee1:      	jb	0x5b48 <generic_fentry_process_filter+0x1fb8>
    4ee7:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    4eec:      	btl	%eax, %ecx
    4eef:      	jb	0x5ab8 <generic_fentry_process_filter+0x1f28>
    4ef5:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    4efa:      	btl	%eax, %ecx
    4efd:      	jae	0x615b <generic_fentry_process_filter+0x25cb>
    4f03:      	movq	%r12, %rsi
    4f06:      	addq	$0x4, %rsi
    4f0a:      	movq	(%rip), %rdi            # 0x4f11 <generic_fentry_process_filter+0x1381>
    4f11:      	movl	$0x1, %eax
    4f16:      	callq	*%rax
    4f18:      	testq	%rax, %rax
    4f1b:      	je	0x615b <generic_fentry_process_filter+0x25cb>
    4f21:      	movq	%rax, %r15
    4f24:      	movl	(%rbp), %eax
    4f27:      	cmpl	$0x7f, %eax
    4f2a:      	movl	$0x7f, %r14d
    4f30:      	cmovll	%eax, %r14d
    4f34:      	movq	(%rip), %rdi            # 0x4f3b <generic_fentry_process_filter+0x13ab>
    4f3b:      	leaq	0x58(%rsp), %rsi
    4f40:      	movl	$0x1, %eax
    4f45:      	callq	*%rax
    4f47:      	testq	%rax, %rax
    4f4a:      	je	0x615b <generic_fentry_process_filter+0x25cb>
    4f50:      	movq	%rax, %rbx
    4f53:      	leal	(,%r14,8), %eax
    4f5b:      	movl	%eax, (%rbx)
    4f5d:      	cmpl	$0x0, 0x4(%rbp)
    4f61:      	jne	0x503d <generic_fentry_process_filter+0x14ad>
    4f67:      	movl	(%rbp), %ecx
    4f6a:      	movl	%ecx, %eax
    4f6c:      	subl	%r14d, %eax
    4f6f:      	movl	%r14d, %edx
    4f72:      	andl	$0x7f, %edx
    4f75:      	addl	%edx, %eax
    4f77:      	addl	%ecx, %edx
    4f79:      	movl	%r14d, %ecx
    4f7c:      	notl	%ecx
    4f7e:      	addl	%edx, %ecx
    4f80:      	subl	%r14d, %edx
    4f83:      	leal	-0x4(%rdx), %esi
    4f86:      	leaq	0x18b(%rbp), %rdi
    4f8d:      	leal	-0x3(%rdx), %r8d
    4f91:      	addl	$-0x2, %edx
    4f94:      	movq	$-0x3, %r9
    4f9b:      	leal	(%rcx,%r9), %r10d
    4f9f:      	addl	$0x3, %r10d
    4fa3:      	andl	$0x7f, %r10d
    4fa7:      	movzbl	0x108(%rbp,%r10), %r10d
    4fb0:      	movb	%r10b, -0x3(%rdi)
    4fb4:      	leaq	(%rax,%r9), %r10
    4fb8:      	cmpq	$-0x2, %r10
    4fbc:      	je	0x5036 <generic_fentry_process_filter+0x14a6>
    4fbe:      	leal	(%rdx,%r9), %r11d
    4fc2:      	addl	$0x3, %r11d
    4fc6:      	andl	$0x7f, %r11d
    4fca:      	movzbl	0x108(%rbp,%r11), %r11d
    4fd3:      	movb	%r11b, -0x2(%rdi)
    4fd7:      	cmpq	$-0x1, %r10
    4fdb:      	je	0x5036 <generic_fentry_process_filter+0x14a6>
    4fdd:      	leal	(%r8,%r9), %r10d
    4fe1:      	addl	$0x3, %r10d
    4fe5:      	andl	$0x7f, %r10d
    4fe9:      	movzbl	0x108(%rbp,%r10), %r10d
    4ff2:      	movb	%r10b, -0x1(%rdi)
    4ff6:      	movq	%rax, %r10
    4ff9:      	addq	%r9, %r10
    4ffc:      	je	0x5036 <generic_fentry_process_filter+0x14a6>
    4ffe:      	cmpq	$-0x7f, %r9
    5002:      	je	0x5036 <generic_fentry_process_filter+0x14a6>
    5004:      	leal	(%rsi,%r9), %r10d
    5008:      	addl	$0x3, %r10d
    500c:      	andl	$0x7f, %r10d
    5010:      	movzbl	0x108(%rbp,%r10), %r10d
    5019:      	movb	%r10b, (%rdi)
    501c:      	addq	$0x4, %rdi
    5020:      	leaq	(%rax,%r9), %r10
    5024:      	addq	$-0x4, %r10
    5028:      	addq	$-0x4, %r9
    502c:      	cmpq	$-0x3, %r10
    5030:      	jne	0x4f9b <generic_fentry_process_filter+0x140b>
    5036:      	movl	$0x1, 0x4(%rbp)
    503d:      	cmpl	$0x7f, %r14d
    5041:      	ja	0x5067 <generic_fentry_process_filter+0x14d7>
    5043:      	movslq	%r14d, %rsi
    5046:      	movq	%rbx, %rdi
    5049:      	addq	$0x4, %rdi
    504d:      	addq	$0x188, %rbp            # imm = 0x188
    5054:      	movl	$0x4, %eax
    5059:      	movq	%rbp, %rdx
    505c:      	callq	*%rax
    505e:      	testq	%rax, %rax
    5061:      	js	0x615b <generic_fentry_process_filter+0x25cb>
    5067:      	movl	$0x1, %eax
    506c:      	movq	%r15, %rdi
    506f:      	jmp	0x5b40 <generic_fentry_process_filter+0x1fb0>
    5074:      	movq	%r12, %r13
    5077:      	addq	$0xff6, %r13            # imm = 0xFF6
    507e:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    5088:      	movq	%rax, 0xff6(%r12)
    5090:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
    509b:      	jmp	0x43d3 <generic_fentry_process_filter+0x843>
    50a0:      	movq	0x8(%rsp), %r10
    50a5:      	movl	%r13d, %eax
    50a8:      	leaq	0x4(,%rax,4), %rcx
    50b0:      	movl	0x4(%r10,%rax,4), %eax
    50b5:      	leal	(%rax,%rcx), %r14d
    50b9:      	andl	$0x3ff, %r14d           # imm = 0x3FF
    50c0:      	addl	%eax, %ecx
    50c2:      	addl	$0x4, %ecx
    50c5:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    50cb:      	leaq	0x8(%r14), %rbp
    50cf:      	cmpl	$0x5, (%rcx,%r10)
    50d4:      	jb	0x55fe <generic_fentry_process_filter+0x1a6e>
    50da:      	movl	(%rbp,%r10), %r12d
    50df:      	movl	0x4(%rbp,%r10), %edi
    50e4:      	movl	0x8(%rbp,%r10), %edx
    50e9:      	movq	$0x0, 0x68(%rsp)
    50f2:      	movq	$0x0, 0x60(%rsp)
    50fb:      	cmpl	$0x4, %edx
    50fe:      	movl	$0x4, %ecx
    5103:      	cmovbl	%edx, %ecx
    5106:      	cmpl	$0x6, %r12d
    510a:      	jne	0x5120 <generic_fentry_process_filter+0x1590>
    510c:      	movabsq	$0x100000001, %rsi      # imm = 0x100000001
    5116:      	movq	%rsi, 0x60(%rsp)
    511b:      	movq	%rsi, 0x68(%rsp)
    5120:      	testl	%edx, %edx
    5122:      	je	0x5605 <generic_fentry_process_filter+0x1a75>
    5128:      	movq	0x38(%rsp), %rdx
    512d:      	leaq	0x24(%rdx), %rsi
    5131:      	testb	$0x1, %dil
    5135:      	movq	%rsi, 0xb0(%rsp)
    513d:      	movq	%rsi, %r8
    5140:      	cmoveq	%rdx, %r8
    5144:      	addq	$0x10, %rdx
    5148:      	movq	%rdx, 0xd0(%rsp)
    5150:      	leal	(%rax,%r13,4), %r9d
    5154:      	addl	$0x4, %r9d
    5158:      	andl	$0x3ff, %r9d            # imm = 0x3FF
    515f:      	addq	$0x14, %r9
    5163:      	decq	%rcx
    5166:      	cmpq	$0x3, %rcx
    516a:      	movl	$0x3, %eax
    516f:      	cmovbq	%rcx, %rax
    5173:      	movl	%eax, %eax
    5175:      	leaq	0x4(,%rax,4), %r11
    517d:      	xorl	%r13d, %r13d
    5180:      	movq	%rdi, 0x30(%rsp)
    5185:      	movq	%r8, 0x28(%rsp)
    518a:      	movq	%r9, 0x20(%rsp)
    518f:      	movq	%r11, 0x18(%rsp)
    5194:      	jmp	0x51d0 <generic_fentry_process_filter+0x1640>
    5196:      	movq	0x8(%rsp), %r10
    519b:      	movq	0x30(%rsp), %rdi
    51a0:      	movq	0x28(%rsp), %r8
    51a5:      	movq	0x20(%rsp), %r9
    51aa:      	movq	0x18(%rsp), %r11
    51af:      	cmpl	$0x6, %r12d
    51b3:      	setne	%al
    51b6:      	xorb	$0x1, %bl
    51b9:      	orb	%al, %bl
    51bb:      	movzbl	%bl, %eax
    51be:      	movl	%eax, 0x60(%rsp,%r13)
    51c3:      	addq	$0x4, %r13
    51c7:      	cmpq	%r13, %r11
    51ca:      	je	0x5605 <generic_fentry_process_filter+0x1a75>
    51d0:      	leaq	(%r9,%r13), %rax
    51d4:      	movl	(%r8), %ecx
    51d7:      	cmpq	$0x3e8, %rax            # imm = 0x3E8
    51dd:      	jbe	0x53ea <generic_fentry_process_filter+0x185a>
    51e3:      	xorl	%r15d, %r15d
    51e6:      	testb	$0x2, %dil
    51ea:      	je	0x5407 <generic_fentry_process_filter+0x1877>
    51f0:      	testb	$0x1, %dil
    51f4:      	jne	0x5428 <generic_fentry_process_filter+0x1898>
    51fa:      	movq	0x38(%rsp), %rcx
    51ff:      	movl	(%rcx), %eax
    5201:      	movb	$0x1, %bl
    5203:      	cmpq	%rax, %r15
    5206:      	je	0x51af <generic_fentry_process_filter+0x161f>
    5208:      	movl	0x10(%rcx), %eax
    520b:      	cmpq	%rax, %r15
    520e:      	je	0x51af <generic_fentry_process_filter+0x161f>
    5210:      	movl	$0x1, %eax
    5215:      	movq	0xd0(%rsp), %rsi
    521d:      	movq	(%rip), %rdi            # 0x5224 <generic_fentry_process_filter+0x1694>
    5224:      	callq	*%rax
    5226:      	testq	%rax, %rax
    5229:      	je	0x55cd <generic_fentry_process_filter+0x1a3d>
    522f:      	movq	%rax, %rsi
    5232:      	movl	(%rax), %eax
    5234:      	cmpq	%rax, %r15
    5237:      	je	0x5196 <generic_fentry_process_filter+0x1606>
    523d:      	movl	0x10(%rsi), %eax
    5240:      	cmpq	%rax, %r15
    5243:      	je	0x5196 <generic_fentry_process_filter+0x1606>
    5249:      	addq	$0x10, %rsi
    524d:      	movl	$0x1, %eax
    5252:      	movq	(%rip), %rdi            # 0x5259 <generic_fentry_process_filter+0x16c9>
    5259:      	callq	*%rax
    525b:      	testq	%rax, %rax
    525e:      	je	0x55cd <generic_fentry_process_filter+0x1a3d>
    5264:      	movq	%rax, %rsi
    5267:      	movl	(%rax), %eax
    5269:      	cmpq	%rax, %r15
    526c:      	je	0x5196 <generic_fentry_process_filter+0x1606>
    5272:      	movl	0x10(%rsi), %eax
    5275:      	cmpq	%rax, %r15
    5278:      	je	0x5196 <generic_fentry_process_filter+0x1606>
    527e:      	addq	$0x10, %rsi
    5282:      	movl	$0x1, %eax
    5287:      	movq	(%rip), %rdi            # 0x528e <generic_fentry_process_filter+0x16fe>
    528e:      	callq	*%rax
    5290:      	testq	%rax, %rax
    5293:      	je	0x55cd <generic_fentry_process_filter+0x1a3d>
    5299:      	movq	%rax, %rsi
    529c:      	movl	(%rax), %eax
    529e:      	cmpq	%rax, %r15
    52a1:      	je	0x5196 <generic_fentry_process_filter+0x1606>
    52a7:      	movl	0x10(%rsi), %eax
    52aa:      	cmpq	%rax, %r15
    52ad:      	je	0x5196 <generic_fentry_process_filter+0x1606>
    52b3:      	addq	$0x10, %rsi
    52b7:      	movl	$0x1, %eax
    52bc:      	movq	(%rip), %rdi            # 0x52c3 <generic_fentry_process_filter+0x1733>
    52c3:      	callq	*%rax
    52c5:      	testq	%rax, %rax
    52c8:      	je	0x55cd <generic_fentry_process_filter+0x1a3d>
    52ce:      	movq	%rax, %rsi
    52d1:      	movl	(%rax), %eax
    52d3:      	cmpq	%rax, %r15
    52d6:      	je	0x5196 <generic_fentry_process_filter+0x1606>
    52dc:      	movl	0x10(%rsi), %eax
    52df:      	cmpq	%rax, %r15
    52e2:      	je	0x5196 <generic_fentry_process_filter+0x1606>
    52e8:      	addq	$0x10, %rsi
    52ec:      	movl	$0x1, %eax
    52f1:      	movq	(%rip), %rdi            # 0x52f8 <generic_fentry_process_filter+0x1768>
    52f8:      	callq	*%rax
    52fa:      	testq	%rax, %rax
    52fd:      	je	0x55cd <generic_fentry_process_filter+0x1a3d>
    5303:      	movq	%rax, %rsi
    5306:      	movl	(%rax), %eax
    5308:      	cmpq	%rax, %r15
    530b:      	je	0x5196 <generic_fentry_process_filter+0x1606>
    5311:      	movl	0x10(%rsi), %eax
    5314:      	cmpq	%rax, %r15
    5317:      	je	0x5196 <generic_fentry_process_filter+0x1606>
    531d:      	addq	$0x10, %rsi
    5321:      	movl	$0x1, %eax
    5326:      	movq	(%rip), %rdi            # 0x532d <generic_fentry_process_filter+0x179d>
    532d:      	callq	*%rax
    532f:      	testq	%rax, %rax
    5332:      	je	0x55cd <generic_fentry_process_filter+0x1a3d>
    5338:      	movq	%rax, %rsi
    533b:      	movl	(%rax), %eax
    533d:      	cmpq	%rax, %r15
    5340:      	je	0x5196 <generic_fentry_process_filter+0x1606>
    5346:      	movl	0x10(%rsi), %eax
    5349:      	cmpq	%rax, %r15
    534c:      	je	0x5196 <generic_fentry_process_filter+0x1606>
    5352:      	addq	$0x10, %rsi
    5356:      	movl	$0x1, %eax
    535b:      	movq	(%rip), %rdi            # 0x5362 <generic_fentry_process_filter+0x17d2>
    5362:      	callq	*%rax
    5364:      	testq	%rax, %rax
    5367:      	je	0x55cd <generic_fentry_process_filter+0x1a3d>
    536d:      	movq	%rax, %rsi
    5370:      	movl	(%rax), %eax
    5372:      	cmpq	%rax, %r15
    5375:      	je	0x5196 <generic_fentry_process_filter+0x1606>
    537b:      	movl	0x10(%rsi), %eax
    537e:      	cmpq	%rax, %r15
    5381:      	je	0x5196 <generic_fentry_process_filter+0x1606>
    5387:      	addq	$0x10, %rsi
    538b:      	movl	$0x1, %eax
    5390:      	movq	(%rip), %rdi            # 0x5397 <generic_fentry_process_filter+0x1807>
    5397:      	callq	*%rax
    5399:      	testq	%rax, %rax
    539c:      	je	0x55cd <generic_fentry_process_filter+0x1a3d>
    53a2:      	movq	%rax, %rsi
    53a5:      	movl	(%rax), %eax
    53a7:      	cmpq	%rax, %r15
    53aa:      	je	0x5196 <generic_fentry_process_filter+0x1606>
    53b0:      	movl	0x10(%rsi), %eax
    53b3:      	cmpq	%rax, %r15
    53b6:      	movq	0x8(%rsp), %r10
    53bb:      	movq	0x30(%rsp), %rdi
    53c0:      	movq	0x28(%rsp), %r8
    53c5:      	movq	0x20(%rsp), %r9
    53ca:      	movq	0x18(%rsp), %r11
    53cf:      	je	0x51af <generic_fentry_process_filter+0x161f>
    53d5:      	addq	$0x10, %rsi
    53d9:      	movl	$0x1, %eax
    53de:      	movq	(%rip), %rcx            # 0x53e5 <generic_fentry_process_filter+0x1855>
    53e5:      	jmp	0x55c4 <generic_fentry_process_filter+0x1a34>
    53ea:      	movl	$0x4, %esi
    53ef:      	xorl	%edx, %edx
    53f1:      	divq	%rsi
    53f4:      	andl	$0x3ff, %eax            # imm = 0x3FF
    53f9:      	movl	(%r10,%rax,4), %r15d
    53fd:      	testb	$0x2, %dil
    5401:      	jne	0x51f0 <generic_fentry_process_filter+0x1660>
    5407:      	cmpl	$0x5, %r12d
    540b:      	jne	0x5416 <generic_fentry_process_filter+0x1886>
    540d:      	cmpq	%rcx, %r15
    5410:      	jne	0x55f7 <generic_fentry_process_filter+0x1a67>
    5416:      	cmpq	%rcx, %r15
    5419:      	setne	%al
    541c:      	cmpl	$0x6, %r12d
    5420:      	setne	%bl
    5423:      	jmp	0x51b9 <generic_fentry_process_filter+0x1629>
    5428:      	movq	0xb0(%rsp), %rax
    5430:      	movl	(%rax), %eax
    5432:      	testq	%rax, %rax
    5435:      	je	0x55f7 <generic_fentry_process_filter+0x1a67>
    543b:      	movb	$0x1, %bl
    543d:      	testq	%r15, %r15
    5440:      	je	0x51af <generic_fentry_process_filter+0x161f>
    5446:      	cmpq	%rax, %r15
    5449:      	je	0x51af <generic_fentry_process_filter+0x161f>
    544f:      	movl	$0x1, %eax
    5454:      	movq	0xd0(%rsp), %rsi
    545c:      	movq	(%rip), %rdi            # 0x5463 <generic_fentry_process_filter+0x18d3>
    5463:      	callq	*%rax
    5465:      	testq	%rax, %rax
    5468:      	je	0x55cd <generic_fentry_process_filter+0x1a3d>
    546e:      	movq	%rax, %rsi
    5471:      	movl	0x24(%rax), %eax
    5474:      	cmpq	%rax, %r15
    5477:      	je	0x5196 <generic_fentry_process_filter+0x1606>
    547d:      	addq	$0x10, %rsi
    5481:      	movl	$0x1, %eax
    5486:      	movq	(%rip), %rdi            # 0x548d <generic_fentry_process_filter+0x18fd>
    548d:      	callq	*%rax
    548f:      	testq	%rax, %rax
    5492:      	je	0x55cd <generic_fentry_process_filter+0x1a3d>
    5498:      	movq	%rax, %rsi
    549b:      	movl	0x24(%rax), %eax
    549e:      	cmpq	%rax, %r15
    54a1:      	je	0x5196 <generic_fentry_process_filter+0x1606>
    54a7:      	addq	$0x10, %rsi
    54ab:      	movl	$0x1, %eax
    54b0:      	movq	(%rip), %rdi            # 0x54b7 <generic_fentry_process_filter+0x1927>
    54b7:      	callq	*%rax
    54b9:      	testq	%rax, %rax
    54bc:      	je	0x55cd <generic_fentry_process_filter+0x1a3d>
    54c2:      	movq	%rax, %rsi
    54c5:      	movl	0x24(%rax), %eax
    54c8:      	cmpq	%rax, %r15
    54cb:      	je	0x5196 <generic_fentry_process_filter+0x1606>
    54d1:      	addq	$0x10, %rsi
    54d5:      	movl	$0x1, %eax
    54da:      	movq	(%rip), %rdi            # 0x54e1 <generic_fentry_process_filter+0x1951>
    54e1:      	callq	*%rax
    54e3:      	testq	%rax, %rax
    54e6:      	je	0x55cd <generic_fentry_process_filter+0x1a3d>
    54ec:      	movq	%rax, %rsi
    54ef:      	movl	0x24(%rax), %eax
    54f2:      	cmpq	%rax, %r15
    54f5:      	je	0x5196 <generic_fentry_process_filter+0x1606>
    54fb:      	addq	$0x10, %rsi
    54ff:      	movl	$0x1, %eax
    5504:      	movq	(%rip), %rdi            # 0x550b <generic_fentry_process_filter+0x197b>
    550b:      	callq	*%rax
    550d:      	testq	%rax, %rax
    5510:      	je	0x55cd <generic_fentry_process_filter+0x1a3d>
    5516:      	movq	%rax, %rsi
    5519:      	movl	0x24(%rax), %eax
    551c:      	cmpq	%rax, %r15
    551f:      	je	0x5196 <generic_fentry_process_filter+0x1606>
    5525:      	addq	$0x10, %rsi
    5529:      	movl	$0x1, %eax
    552e:      	movq	(%rip), %rdi            # 0x5535 <generic_fentry_process_filter+0x19a5>
    5535:      	callq	*%rax
    5537:      	testq	%rax, %rax
    553a:      	je	0x55cd <generic_fentry_process_filter+0x1a3d>
    5540:      	movq	%rax, %rsi
    5543:      	movl	0x24(%rax), %eax
    5546:      	cmpq	%rax, %r15
    5549:      	je	0x5196 <generic_fentry_process_filter+0x1606>
    554f:      	addq	$0x10, %rsi
    5553:      	movl	$0x1, %eax
    5558:      	movq	(%rip), %rdi            # 0x555f <generic_fentry_process_filter+0x19cf>
    555f:      	callq	*%rax
    5561:      	testq	%rax, %rax
    5564:      	je	0x55cd <generic_fentry_process_filter+0x1a3d>
    5566:      	movq	%rax, %rsi
    5569:      	movl	0x24(%rax), %eax
    556c:      	cmpq	%rax, %r15
    556f:      	je	0x5196 <generic_fentry_process_filter+0x1606>
    5575:      	addq	$0x10, %rsi
    5579:      	movl	$0x1, %eax
    557e:      	movq	(%rip), %rdi            # 0x5585 <generic_fentry_process_filter+0x19f5>
    5585:      	callq	*%rax
    5587:      	testq	%rax, %rax
    558a:      	je	0x55cd <generic_fentry_process_filter+0x1a3d>
    558c:      	movq	%rax, %rsi
    558f:      	movl	0x24(%rax), %eax
    5592:      	cmpq	%rax, %r15
    5595:      	movq	0x8(%rsp), %r10
    559a:      	movq	0x30(%rsp), %rdi
    559f:      	movq	0x28(%rsp), %r8
    55a4:      	movq	0x20(%rsp), %r9
    55a9:      	movq	0x18(%rsp), %r11
    55ae:      	je	0x51af <generic_fentry_process_filter+0x161f>
    55b4:      	addq	$0x10, %rsi
    55b8:      	movl	$0x1, %eax
    55bd:      	movq	(%rip), %rcx            # 0x55c4 <generic_fentry_process_filter+0x1a34>
    55c4:      	movq	(%rip), %rdi            # 0x55cb <generic_fentry_process_filter+0x1a3b>
    55cb:      	callq	*%rax
    55cd:      	xorl	%ebx, %ebx
    55cf:      	cmpl	$0x5, %r12d
    55d3:      	movq	0x8(%rsp), %r10
    55d8:      	movq	0x30(%rsp), %rdi
    55dd:      	movq	0x28(%rsp), %r8
    55e2:      	movq	0x20(%rsp), %r9
    55e7:      	movq	0x18(%rsp), %r11
    55ec:      	jne	0x51af <generic_fentry_process_filter+0x161f>
    55f2:      	jmp	0x51bb <generic_fentry_process_filter+0x162b>
    55f7:      	xorl	%ebx, %ebx
    55f9:      	jmp	0x51bb <generic_fentry_process_filter+0x162b>
    55fe:      	movl	$0x1, %eax
    5603:      	jmp	0x5641 <generic_fentry_process_filter+0x1ab1>
    5605:      	movl	0x60(%rsp), %esi
    5609:      	movl	0x64(%rsp), %ecx
    560d:      	movl	0x68(%rsp), %eax
    5611:      	movl	0x6c(%rsp), %edx
    5615:      	cmpl	$0x6, %r12d
    5619:      	jne	0x5623 <generic_fentry_process_filter+0x1a93>
    561b:      	andl	%esi, %ecx
    561d:      	andl	%edx, %eax
    561f:      	andl	%ecx, %eax
    5621:      	jmp	0x5629 <generic_fentry_process_filter+0x1a99>
    5623:      	orl	%esi, %ecx
    5625:      	orl	%edx, %eax
    5627:      	orl	%ecx, %eax
    5629:      	testl	%eax, %eax
    562b:      	je	0x615b <generic_fentry_process_filter+0x25cb>
    5631:      	addl	$0x14, %r14d
    5635:      	movl	0x8(%r10,%rbp), %ecx
    563a:      	andl	$0x7, %ecx
    563d:      	leal	(%r14,%rcx,4), %ebp
    5641:      	movq	0x50(%rsp), %r9
    5646:      	movl	%ebp, %ecx
    5648:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    564e:      	movl	(%rcx,%r10), %ecx
    5652:      	addl	$0x4, %ebp
    5655:      	addl	$-0x4, %ecx
    5658:      	xorl	%esi, %esi
    565a:      	movl	$0x4, %r8d
    5660:      	jmp	0x567f <generic_fentry_process_filter+0x1aef>
    5662:      	nopw	%cs:(%rax,%rax)
    5670:      	xorl	%ecx, %ecx
    5672:      	incq	%rsi
    5675:      	cmpq	$0xa, %rsi
    5679:      	je	0x5808 <generic_fentry_process_filter+0x1c78>
    567f:      	testl	%ecx, %ecx
    5681:      	je	0x5670 <generic_fentry_process_filter+0x1ae0>
    5683:      	movl	%ebp, %r9d
    5686:      	andl	$0x3ff, %r9d            # imm = 0x3FF
    568d:      	movl	(%r9,%r10), %r11d
    5691:      	movq	%r10, %rax
    5694:      	movl	0x4(%r9,%r10), %r10d
    5699:      	movl	0x8(%r9,%rax), %edx
    569e:      	movq	$0x0, 0x68(%rsp)
    56a7:      	movq	$0x0, 0x60(%rsp)
    56b0:      	cmpl	$0x4, %edx
    56b3:      	movl	$0x4, %eax
    56b8:      	cmovbl	%edx, %eax
    56bb:      	cmpl	$0x6, %r10d
    56bf:      	jne	0x56d5 <generic_fentry_process_filter+0x1b45>
    56c1:      	movabsq	$0x100000001, %rdi      # imm = 0x100000001
    56cb:      	movq	%rdi, 0x60(%rsp)
    56d0:      	movq	%rdi, 0x68(%rsp)
    56d5:      	addl	$0xc, %ebp
    56d8:      	testl	%edx, %edx
    56da:      	je	0x57b0 <generic_fentry_process_filter+0x1c20>
    56e0:      	andl	$0xf, %r11d
    56e4:      	decq	%rax
    56e7:      	cmpq	$0x3, %rax
    56eb:      	movl	$0x3, %edx
    56f0:      	cmovaeq	%rdx, %rax
    56f4:      	leaq	0x4(,%rax,4), %rbx
    56fc:      	movl	%ebp, %r14d
    56ff:      	cmpl	$0x9, %r11d
    5703:      	jbe	0x573a <generic_fentry_process_filter+0x1baa>
    5705:      	xorl	%r11d, %r11d
    5708:      	jmp	0x5726 <generic_fentry_process_filter+0x1b96>
    570a:      	nopw	(%rax,%rax)
    5710:      	movl	$0x0, 0x60(%rsp,%r11)
    5719:      	addq	$0x4, %r11
    571d:      	cmpq	%r11, %rbx
    5720:      	je	0x57b0 <generic_fentry_process_filter+0x1c20>
    5726:      	leaq	(%r14,%r11), %rax
    572a:      	cmpl	$0x3e8, %eax            # imm = 0x3E8
    572f:      	ja	0x5710 <generic_fentry_process_filter+0x1b80>
    5731:      	movl	%eax, %eax
    5733:      	xorl	%edx, %edx
    5735:      	divq	%r8
    5738:      	jmp	0x5710 <generic_fentry_process_filter+0x1b80>
    573a:      	xorl	%r15d, %r15d
    573d:      	jmp	0x5781 <generic_fentry_process_filter+0x1bf1>
    573f:      	nop
    5740:      	cmpl	$0x5, %r10d
    5744:      	setne	%dl
    5747:      	movl	%r10d, %r13d
    574a:      	xorl	$0x6, %r13d
    574e:      	movq	0x50(%rsp), %rax
    5753:      	movl	0x20(%rax,%r11,4), %edi
    5758:      	movl	%r12d, %eax
    575b:      	xorl	%edi, %eax
    575d:      	cmpl	%edi, %r12d
    5760:      	sete	%dil
    5764:      	orb	%dl, %dil
    5767:      	orl	%r13d, %eax
    576a:      	setne	%al
    576d:      	andb	%dil, %al
    5770:      	movzbl	%al, %eax
    5773:      	movl	%eax, 0x60(%rsp,%r15)
    5778:      	addq	$0x4, %r15
    577c:      	cmpq	%r15, %rbx
    577f:      	je	0x57b0 <generic_fentry_process_filter+0x1c20>
    5781:      	leaq	(%r14,%r15), %rdx
    5785:      	xorl	%r12d, %r12d
    5788:      	cmpl	$0x3e8, %edx            # imm = 0x3E8
    578e:      	ja	0x5740 <generic_fentry_process_filter+0x1bb0>
    5790:      	movl	%edx, %eax
    5792:      	xorl	%edx, %edx
    5794:      	divq	%r8
    5797:      	andl	$0x3ff, %eax            # imm = 0x3FF
    579c:      	movq	0x8(%rsp), %rdx
    57a1:      	movl	(%rdx,%rax,4), %r12d
    57a5:      	jmp	0x5740 <generic_fentry_process_filter+0x1bb0>
    57a7:      	nopw	(%rax,%rax)
    57b0:      	movl	0x60(%rsp), %ebx
    57b4:      	movl	0x64(%rsp), %edx
    57b8:      	movl	0x68(%rsp), %eax
    57bc:      	movl	0x6c(%rsp), %r11d
    57c1:      	cmpl	$0x6, %r10d
    57c5:      	jne	0x57d0 <generic_fentry_process_filter+0x1c40>
    57c7:      	andl	%ebx, %edx
    57c9:      	andl	%r11d, %eax
    57cc:      	andl	%edx, %eax
    57ce:      	jmp	0x57d7 <generic_fentry_process_filter+0x1c47>
    57d0:      	orl	%ebx, %edx
    57d2:      	orl	%r11d, %eax
    57d5:      	orl	%edx, %eax
    57d7:      	movq	0x8(%rsp), %r10
    57dc:      	testl	%eax, %eax
    57de:      	je	0x615b <generic_fentry_process_filter+0x25cb>
    57e4:      	movl	0x8(%r10,%r9), %edx
    57e9:      	shll	$0x2, %edx
    57ec:      	subl	%edx, %ecx
    57ee:      	andl	$0x1c, %edx
    57f1:      	addl	%edx, %ebp
    57f3:      	addl	$-0xc, %ecx
    57f6:      	movq	0x50(%rsp), %r9
    57fb:      	incq	%rsi
    57fe:      	cmpq	$0xa, %rsi
    5802:      	jne	0x567f <generic_fentry_process_filter+0x1aef>
    5808:      	movl	%ebp, %ecx
    580a:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5810:      	leal	0x4(%rbp), %ebx
    5813:      	cmpl	$0x4, (%rcx,%r10)
    5818:      	je	0x59e8 <generic_fentry_process_filter+0x1e58>
    581e:      	andl	$0x3ff, %ebx            # imm = 0x3FF
    5824:      	movl	(%rbx,%r10), %ecx
    5828:      	movl	0x4(%rbx,%r10), %edx
    582d:      	movl	0x8(%rbx,%r10), %edi
    5832:      	movq	0xc(%rbx,%r10), %rax
    5837:      	testl	%edi, %edi
    5839:      	je	0x59bc <generic_fentry_process_filter+0x1e2c>
    583f:      	xorl	%esi, %esi
    5841:      	cmpl	$0x2, %ecx
    5844:      	ja	0x59df <generic_fentry_process_filter+0x1e4f>
    584a:      	cmpl	%edi, 0x44(%r9)
    584e:      	jne	0x59c5 <generic_fentry_process_filter+0x1e35>
    5854:      	jmp	0x59df <generic_fentry_process_filter+0x1e4f>
    5859:      	movq	%rbx, %rsi
    585c:      	addq	$0x4, %rsi
    5860:      	movq	(%rip), %rdi            # 0x5867 <generic_fentry_process_filter+0x1cd7>
    5867:      	movl	$0x1, %eax
    586c:      	callq	*%rax
    586e:      	testq	%rax, %rax
    5871:      	je	0x615b <generic_fentry_process_filter+0x25cb>
    5877:      	movq	%rax, %r14
    587a:      	movq	(%rip), %rdi            # 0x5881 <generic_fentry_process_filter+0x1cf1>
    5881:      	leaq	0x58(%rsp), %rsi
    5886:      	movl	$0x1, %eax
    588b:      	callq	*%rax
    588d:      	testq	%rax, %rax
    5890:      	je	0x615b <generic_fentry_process_filter+0x25cb>
    5896:      	movq	%rax, %rbp
    5899:      	movl	$0x104, %edx            # imm = 0x104
    589e:      	movq	%rax, %rdi
    58a1:      	xorl	%esi, %esi
    58a3:      	callq	0x58a8 <generic_fentry_process_filter+0x1d18>
    58a8:      	movq	0x38(%rsp), %rsi
    58ad:      	movl	0x68(%rsi), %eax
    58b0:      	leal	(,%rax,8), %ecx
    58b7:      	movl	%ecx, (%rbp)
    58ba:      	movq	%rbp, %rdi
    58bd:      	addq	$0x4, %rdi
    58c1:      	movzbl	%al, %ecx
    58c4:      	leaq	0x70(%rsi), %rdx
    58c8:      	movl	$0x4, %eax
    58cd:      	movzbl	0x68(%rsi), %esi
    58d1:      	callq	*%rax
    58d3:      	testq	%rax, %rax
    58d6:      	js	0x615b <generic_fentry_process_filter+0x25cb>
    58dc:      	movl	$0x1, %eax
    58e1:      	movq	%r14, %rdi
    58e4:      	movq	%rbp, %rsi
    58e7:      	jmp	0x5ce7 <generic_fentry_process_filter+0x2157>
    58ec:      	movl	$0x0, 0x40(%rsp)
    58f4:      	movq	(%rip), %rdi            # 0x58fb <generic_fentry_process_filter+0x1d6b>
    58fb:      	leaq	0x40(%rsp), %rsi
    5900:      	movl	$0x1, %eax
    5905:      	callq	*%rax
    5907:      	testq	%rax, %rax
    590a:      	movq	0x38(%rsp), %rdx
    590f:      	je	0x5c94 <generic_fentry_process_filter+0x2104>
    5915:      	movq	(%rax), %rcx
    5918:      	cmpq	0x378(%rdx), %rcx
    591f:      	je	0x5c94 <generic_fentry_process_filter+0x2104>
    5925:      	movq	%rax, 0xb0(%rsp)
    592d:      	movq	(%rip), %rax            # 0x5934 <generic_fentry_process_filter+0x1da4>
    5934:      	cmpb	$0x0, (%rax)
    5937:      	je	0x5c0b <generic_fentry_process_filter+0x207b>
    593d:      	movl	$0x1869f, %r15d         # imm = 0x1869F
    5943:      	xorl	%r14d, %r14d
    5946:      	movq	(%rip), %r12            # 0x594d <generic_fentry_process_filter+0x1dbd>
    594d:      	movq	0x38(%rsp), %rax
    5952:      	movl	0x10(%rax), %eax
    5955:      	movl	%eax, 0x60(%rsp)
    5959:      	movl	$0x1, %eax
    595e:      	leaq	0x60(%rsp), %rsi
    5963:      	movq	%r12, %rdi
    5966:      	callq	*%rax
    5968:      	testq	%rax, %rax
    596b:      	je	0x5c7d <generic_fentry_process_filter+0x20ed>
    5971:      	movq	%rax, %rbp
    5974:      	leaq	0x70(%rax), %rsi
    5978:      	movl	$0x1, %eax
    597d:      	movq	(%rip), %rdi            # 0x5984 <generic_fentry_process_filter+0x1df4>
    5984:      	callq	*%rax
    5986:      	testq	%rax, %rax
    5989:      	je	0x59a0 <generic_fentry_process_filter+0x1e10>
    598b:      	movq	(%rax), %rax
    598e:      	testq	%rax, %rax
    5991:      	je	0x59a0 <generic_fentry_process_filter+0x1e10>
    5993:      	movq	0x38(%rsp), %rcx
    5998:      	lock
    5999:      	orq	%rax, 0x370(%rcx)
    59a0:      	subl	$0x1, %r15d
    59a4:      	setb	%al
    59a7:      	cmpq	%r14, %rbp
    59aa:      	je	0x5c7d <generic_fentry_process_filter+0x20ed>
    59b0:      	movq	%rbp, %r14
    59b3:      	testb	%al, %al
    59b5:      	je	0x594d <generic_fentry_process_filter+0x1dbd>
    59b7:      	jmp	0x5c7d <generic_fentry_process_filter+0x20ed>
    59bc:      	cmpl	$0x2, %ecx
    59bf:      	jbe	0x59c5 <generic_fentry_process_filter+0x1e35>
    59c1:      	xorl	%esi, %esi
    59c3:      	jmp	0x59df <generic_fentry_process_filter+0x1e4f>
    59c5:      	andq	0x48(%r9,%rcx,8), %rax
    59ca:      	cmpl	$0x5, %edx
    59cd:      	jne	0x59d8 <generic_fentry_process_filter+0x1e48>
    59cf:      	testq	%rax, %rax
    59d2:      	setne	%sil
    59d6:      	jmp	0x59df <generic_fentry_process_filter+0x1e4f>
    59d8:      	testq	%rax, %rax
    59db:      	sete	%sil
    59df:      	addl	$0x18, %ebp
    59e2:      	movzbl	%sil, %eax
    59e6:      	movl	%ebp, %ebx
    59e8:      	testl	%eax, %eax
    59ea:      	je	0x615b <generic_fentry_process_filter+0x25cb>
    59f0:      	movl	%ebx, %ecx
    59f2:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    59f8:      	leal	0x4(%rbx), %eax
    59fb:      	cmpl	$0x4, (%rcx,%r10)
    5a00:      	je	0x6063 <generic_fentry_process_filter+0x24d3>
    5a06:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5a0b:      	movl	(%rax,%r10), %r14d
    5a0f:      	movl	0x4(%rax,%r10), %ebp
    5a14:      	movl	$0xe, %eax
    5a19:      	callq	*%rax
    5a1b:      	shrq	$0x20, %rax
    5a1f:      	movl	%eax, 0x60(%rsp)
    5a23:      	movq	(%rip), %rdi            # 0x5a2a <generic_fentry_process_filter+0x1e9a>
    5a2a:      	leaq	0x60(%rsp), %rsi
    5a2f:      	movl	$0x1, %eax
    5a34:      	callq	*%rax
    5a36:      	movq	0x8(%rsp), %r10
    5a3b:      	testq	%rax, %rax
    5a3e:      	je	0x615b <generic_fentry_process_filter+0x25cb>
    5a44:      	cmpl	$0x5, %r14d
    5a48:      	je	0x5a86 <generic_fentry_process_filter+0x1ef6>
    5a4a:      	cmpl	$0x6, %r14d
    5a4e:      	jne	0x615b <generic_fentry_process_filter+0x25cb>
    5a54:      	movq	0x50(%rsp), %rsi
    5a59:      	movq	%rsi, %rcx
    5a5c:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    5a63:      	testb	$0x1, %bpl
    5a67:      	jne	0x5d29 <generic_fentry_process_filter+0x2199>
    5a6d:      	movl	0x28(%rax), %edx
    5a70:      	testl	%edx, %edx
    5a72:      	je	0x5d22 <generic_fentry_process_filter+0x2192>
    5a78:      	cmpl	0x20(%rsi), %edx
    5a7b:      	je	0x5d29 <generic_fentry_process_filter+0x2199>
    5a81:      	jmp	0x6057 <generic_fentry_process_filter+0x24c7>
    5a86:      	movq	0x50(%rsp), %rsi
    5a8b:      	movq	%rsi, %rcx
    5a8e:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    5a95:      	testb	$0x1, %bpl
    5a99:      	je	0x5d47 <generic_fentry_process_filter+0x21b7>
    5a9f:      	movl	0x28(%rax), %edx
    5aa2:      	testl	%edx, %edx
    5aa4:      	je	0x5d40 <generic_fentry_process_filter+0x21b0>
    5aaa:      	cmpl	0x20(%rsi), %edx
    5aad:      	je	0x5d47 <generic_fentry_process_filter+0x21b7>
    5ab3:      	jmp	0x6057 <generic_fentry_process_filter+0x24c7>
    5ab8:      	movq	%r12, %rsi
    5abb:      	addq	$0x4, %rsi
    5abf:      	movq	(%rip), %rdi            # 0x5ac6 <generic_fentry_process_filter+0x1f36>
    5ac6:      	movl	$0x1, %eax
    5acb:      	callq	*%rax
    5acd:      	testq	%rax, %rax
    5ad0:      	je	0x615b <generic_fentry_process_filter+0x25cb>
    5ad6:      	movq	%rax, %r14
    5ad9:      	movq	(%rip), %rdi            # 0x5ae0 <generic_fentry_process_filter+0x1f50>
    5ae0:      	leaq	0x58(%rsp), %rsi
    5ae5:      	movl	$0x1, %eax
    5aea:      	callq	*%rax
    5aec:      	testq	%rax, %rax
    5aef:      	je	0x615b <generic_fentry_process_filter+0x25cb>
    5af5:      	movq	%rax, %rbx
    5af8:      	movl	$0x104, %edx            # imm = 0x104
    5afd:      	movq	%rax, %rdi
    5b00:      	xorl	%esi, %esi
    5b02:      	callq	0x5b07 <generic_fentry_process_filter+0x1f77>
    5b07:      	movl	(%rbp), %eax
    5b0a:      	leal	(,%rax,8), %ecx
    5b11:      	movl	%ecx, (%rbx)
    5b13:      	movq	%rbx, %rdi
    5b16:      	addq	$0x4, %rdi
    5b1a:      	movzbl	%al, %ecx
    5b1d:      	movq	%rbp, %rdx
    5b20:      	addq	$0x8, %rdx
    5b24:      	movl	$0x4, %eax
    5b29:      	movzbl	(%rbp), %esi
    5b2d:      	callq	*%rax
    5b2f:      	testq	%rax, %rax
    5b32:      	js	0x615b <generic_fentry_process_filter+0x25cb>
    5b38:      	movl	$0x1, %eax
    5b3d:      	movq	%r14, %rdi
    5b40:      	movq	%rbx, %rsi
    5b43:      	jmp	0x5ebd <generic_fentry_process_filter+0x232d>
    5b48:      	movl	$0x0, 0x40(%rsp)
    5b50:      	movq	(%rip), %rdi            # 0x5b57 <generic_fentry_process_filter+0x1fc7>
    5b57:      	leaq	0x40(%rsp), %rsi
    5b5c:      	movl	$0x1, %eax
    5b61:      	callq	*%rax
    5b63:      	testq	%rax, %rax
    5b66:      	je	0x5e6a <generic_fentry_process_filter+0x22da>
    5b6c:      	movq	(%rax), %rcx
    5b6f:      	cmpq	0x310(%rbp), %rcx
    5b76:      	je	0x5e6a <generic_fentry_process_filter+0x22da>
    5b7c:      	movq	%rax, 0xb0(%rsp)
    5b84:      	movq	(%rip), %rax            # 0x5b8b <generic_fentry_process_filter+0x1ffb>
    5b8b:      	cmpb	$0x0, (%rax)
    5b8e:      	je	0x5dee <generic_fentry_process_filter+0x225e>
    5b94:      	movl	$0x1869f, %r15d         # imm = 0x1869F
    5b9a:      	xorl	%r14d, %r14d
    5b9d:      	movq	0x38(%rsp), %rax
    5ba2:      	movl	0x10(%rax), %eax
    5ba5:      	movl	%eax, 0x60(%rsp)
    5ba9:      	movl	$0x1, %eax
    5bae:      	movq	(%rip), %rdi            # 0x5bb5 <generic_fentry_process_filter+0x2025>
    5bb5:      	leaq	0x60(%rsp), %rsi
    5bba:      	callq	*%rax
    5bbc:      	testq	%rax, %rax
    5bbf:      	je	0x5e58 <generic_fentry_process_filter+0x22c8>
    5bc5:      	movq	%rax, %rbx
    5bc8:      	leaq	0x70(%rax), %rsi
    5bcc:      	movl	$0x1, %eax
    5bd1:      	movq	(%rip), %rdi            # 0x5bd8 <generic_fentry_process_filter+0x2048>
    5bd8:      	callq	*%rax
    5bda:      	testq	%rax, %rax
    5bdd:      	je	0x5bef <generic_fentry_process_filter+0x205f>
    5bdf:      	movq	(%rax), %rax
    5be2:      	testq	%rax, %rax
    5be5:      	je	0x5bef <generic_fentry_process_filter+0x205f>
    5be7:      	lock
    5be8:      	orq	%rax, 0x308(%rbp)
    5bef:      	subl	$0x1, %r15d
    5bf3:      	setb	%al
    5bf6:      	cmpq	%r14, %rbx
    5bf9:      	je	0x5e58 <generic_fentry_process_filter+0x22c8>
    5bff:      	movq	%rbx, %r14
    5c02:      	testb	%al, %al
    5c04:      	je	0x5b9d <generic_fentry_process_filter+0x200d>
    5c06:      	jmp	0x5e58 <generic_fentry_process_filter+0x22c8>
    5c0b:      	movl	$0x3ff, %r15d           # imm = 0x3FF
    5c11:      	xorl	%r14d, %r14d
    5c14:      	movq	(%rip), %r12            # 0x5c1b <generic_fentry_process_filter+0x208b>
    5c1b:      	movq	0x38(%rsp), %rax
    5c20:      	movl	0x10(%rax), %eax
    5c23:      	movl	%eax, 0x60(%rsp)
    5c27:      	movl	$0x1, %eax
    5c2c:      	leaq	0x60(%rsp), %rsi
    5c31:      	movq	%r12, %rdi
    5c34:      	callq	*%rax
    5c36:      	testq	%rax, %rax
    5c39:      	je	0x5c7d <generic_fentry_process_filter+0x20ed>
    5c3b:      	movq	%rax, %rbp
    5c3e:      	leaq	0x70(%rax), %rsi
    5c42:      	movl	$0x1, %eax
    5c47:      	movq	(%rip), %rdi            # 0x5c4e <generic_fentry_process_filter+0x20be>
    5c4e:      	callq	*%rax
    5c50:      	testq	%rax, %rax
    5c53:      	je	0x5c6a <generic_fentry_process_filter+0x20da>
    5c55:      	movq	(%rax), %rax
    5c58:      	testq	%rax, %rax
    5c5b:      	je	0x5c6a <generic_fentry_process_filter+0x20da>
    5c5d:      	movq	0x38(%rsp), %rcx
    5c62:      	lock
    5c63:      	orq	%rax, 0x370(%rcx)
    5c6a:      	subl	$0x1, %r15d
    5c6e:      	setb	%al
    5c71:      	cmpq	%r14, %rbp
    5c74:      	je	0x5c7d <generic_fentry_process_filter+0x20ed>
    5c76:      	movq	%rbp, %r14
    5c79:      	testb	%al, %al
    5c7b:      	je	0x5c1b <generic_fentry_process_filter+0x208b>
    5c7d:      	movq	0xb0(%rsp), %rax
    5c85:      	movq	(%rax), %rax
    5c88:      	movq	0x38(%rsp), %rdx
    5c8d:      	movq	%rax, 0x378(%rdx)
    5c94:      	movl	0x8(%rbx), %eax
    5c97:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    5c9c:      	cmpq	%rcx, %rax
    5c9f:      	je	0x5cba <generic_fentry_process_filter+0x212a>
    5ca1:      	movq	0x370(%rdx), %rcx
    5ca8:      	btq	%rax, %rcx
    5cac:      	jae	0x5cba <generic_fentry_process_filter+0x212a>
    5cae:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    5cb8:      	jmp	0x5ce9 <generic_fentry_process_filter+0x2159>
    5cba:      	movq	(%rip), %rdi            # 0x5cc1 <generic_fentry_process_filter+0x2131>
    5cc1:      	leaq	0x10(%rsp), %rsi
    5cc6:      	movl	$0x1, %eax
    5ccb:      	callq	*%rax
    5ccd:      	testq	%rax, %rax
    5cd0:      	je	0x615b <generic_fentry_process_filter+0x25cb>
    5cd6:      	movq	%rax, %rdi
    5cd9:      	movq	0x38(%rsp), %rax
    5cde:      	leaq	0x70(%rax), %rsi
    5ce2:      	movl	$0x1, %eax
    5ce7:      	callq	*%rax
    5ce9:      	movl	(%rbx), %ecx
    5ceb:      	cmpq	$0x25, %rcx
    5cef:      	movq	0x8(%rsp), %r10
    5cf4:      	ja	0x5d14 <generic_fentry_process_filter+0x2184>
    5cf6:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    5d00:      	btq	%rcx, %rdx
    5d04:      	jae	0x5d14 <generic_fentry_process_filter+0x2184>
    5d06:      	testq	%rax, %rax
    5d09:      	jne	0x615b <generic_fentry_process_filter+0x25cb>
    5d0f:      	jmp	0x4e59 <generic_fentry_process_filter+0x12c9>
    5d14:      	testq	%rax, %rax
    5d17:      	jne	0x4e59 <generic_fentry_process_filter+0x12c9>
    5d1d:      	jmp	0x615b <generic_fentry_process_filter+0x25cb>
    5d22:      	movq	$0x1, (%rcx)
    5d29:      	testb	$0x2, %bpl
    5d2d:      	jne	0x5d65 <generic_fentry_process_filter+0x21d5>
    5d2f:      	movl	0x2c(%rax), %edx
    5d32:      	testl	%edx, %edx
    5d34:      	je	0x5d5e <generic_fentry_process_filter+0x21ce>
    5d36:      	cmpl	0x24(%rsi), %edx
    5d39:      	je	0x5d65 <generic_fentry_process_filter+0x21d5>
    5d3b:      	jmp	0x6057 <generic_fentry_process_filter+0x24c7>
    5d40:      	movq	$0x1, (%rcx)
    5d47:      	testb	$0x2, %bpl
    5d4b:      	je	0x5d83 <generic_fentry_process_filter+0x21f3>
    5d4d:      	movl	0x2c(%rax), %edx
    5d50:      	testl	%edx, %edx
    5d52:      	je	0x5d7c <generic_fentry_process_filter+0x21ec>
    5d54:      	cmpl	0x24(%rsi), %edx
    5d57:      	je	0x5d83 <generic_fentry_process_filter+0x21f3>
    5d59:      	jmp	0x6057 <generic_fentry_process_filter+0x24c7>
    5d5e:      	movq	$0x1, (%rcx)
    5d65:      	testb	$0x4, %bpl
    5d69:      	jne	0x5da1 <generic_fentry_process_filter+0x2211>
    5d6b:      	movl	0x30(%rax), %edx
    5d6e:      	testl	%edx, %edx
    5d70:      	je	0x5d9a <generic_fentry_process_filter+0x220a>
    5d72:      	cmpl	0x28(%rsi), %edx
    5d75:      	je	0x5da1 <generic_fentry_process_filter+0x2211>
    5d77:      	jmp	0x6057 <generic_fentry_process_filter+0x24c7>
    5d7c:      	movq	$0x1, (%rcx)
    5d83:      	testb	$0x4, %bpl
    5d87:      	je	0x5dcb <generic_fentry_process_filter+0x223b>
    5d89:      	movl	0x30(%rax), %edx
    5d8c:      	testl	%edx, %edx
    5d8e:      	je	0x5dc4 <generic_fentry_process_filter+0x2234>
    5d90:      	cmpl	0x28(%rsi), %edx
    5d93:      	je	0x5dcb <generic_fentry_process_filter+0x223b>
    5d95:      	jmp	0x6057 <generic_fentry_process_filter+0x24c7>
    5d9a:      	movq	$0x1, (%rcx)
    5da1:      	testb	$0x8, %bpl
    5da5:      	jne	0x5f01 <generic_fentry_process_filter+0x2371>
    5dab:      	movl	0x34(%rax), %edx
    5dae:      	testl	%edx, %edx
    5db0:      	je	0x5efa <generic_fentry_process_filter+0x236a>
    5db6:      	cmpl	0x2c(%rsi), %edx
    5db9:      	je	0x5f01 <generic_fentry_process_filter+0x2371>
    5dbf:      	jmp	0x6057 <generic_fentry_process_filter+0x24c7>
    5dc4:      	movq	$0x1, (%rcx)
    5dcb:      	testb	$0x8, %bpl
    5dcf:      	je	0x5f1f <generic_fentry_process_filter+0x238f>
    5dd5:      	movl	0x34(%rax), %edx
    5dd8:      	testl	%edx, %edx
    5dda:      	je	0x5f18 <generic_fentry_process_filter+0x2388>
    5de0:      	cmpl	0x2c(%rsi), %edx
    5de3:      	je	0x5f1f <generic_fentry_process_filter+0x238f>
    5de9:      	jmp	0x6057 <generic_fentry_process_filter+0x24c7>
    5dee:      	movl	$0x3ff, %r15d           # imm = 0x3FF
    5df4:      	xorl	%r14d, %r14d
    5df7:      	movq	0x38(%rsp), %rax
    5dfc:      	movl	0x10(%rax), %eax
    5dff:      	movl	%eax, 0x60(%rsp)
    5e03:      	movl	$0x1, %eax
    5e08:      	movq	(%rip), %rdi            # 0x5e0f <generic_fentry_process_filter+0x227f>
    5e0f:      	leaq	0x60(%rsp), %rsi
    5e14:      	callq	*%rax
    5e16:      	testq	%rax, %rax
    5e19:      	je	0x5e58 <generic_fentry_process_filter+0x22c8>
    5e1b:      	movq	%rax, %rbx
    5e1e:      	leaq	0x70(%rax), %rsi
    5e22:      	movl	$0x1, %eax
    5e27:      	movq	(%rip), %rdi            # 0x5e2e <generic_fentry_process_filter+0x229e>
    5e2e:      	callq	*%rax
    5e30:      	testq	%rax, %rax
    5e33:      	je	0x5e45 <generic_fentry_process_filter+0x22b5>
    5e35:      	movq	(%rax), %rax
    5e38:      	testq	%rax, %rax
    5e3b:      	je	0x5e45 <generic_fentry_process_filter+0x22b5>
    5e3d:      	lock
    5e3e:      	orq	%rax, 0x308(%rbp)
    5e45:      	subl	$0x1, %r15d
    5e49:      	setb	%al
    5e4c:      	cmpq	%r14, %rbx
    5e4f:      	je	0x5e58 <generic_fentry_process_filter+0x22c8>
    5e51:      	movq	%rbx, %r14
    5e54:      	testb	%al, %al
    5e56:      	je	0x5df7 <generic_fentry_process_filter+0x2267>
    5e58:      	movq	0xb0(%rsp), %rax
    5e60:      	movq	(%rax), %rax
    5e63:      	movq	%rax, 0x310(%rbp)
    5e6a:      	movl	0x8(%r12), %eax
    5e6f:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    5e74:      	cmpq	%rcx, %rax
    5e77:      	je	0x5e92 <generic_fentry_process_filter+0x2302>
    5e79:      	movq	0x308(%rbp), %rcx
    5e80:      	btq	%rax, %rcx
    5e84:      	jae	0x5e92 <generic_fentry_process_filter+0x2302>
    5e86:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    5e90:      	jmp	0x5ebf <generic_fentry_process_filter+0x232f>
    5e92:      	movq	(%rip), %rdi            # 0x5e99 <generic_fentry_process_filter+0x2309>
    5e99:      	leaq	0x10(%rsp), %rsi
    5e9e:      	movl	$0x1, %eax
    5ea3:      	callq	*%rax
    5ea5:      	testq	%rax, %rax
    5ea8:      	je	0x615b <generic_fentry_process_filter+0x25cb>
    5eae:      	movq	%rax, %rdi
    5eb1:      	addq	$0x8, %rbp
    5eb5:      	movl	$0x1, %eax
    5eba:      	movq	%rbp, %rsi
    5ebd:      	callq	*%rax
    5ebf:      	movl	(%r12), %ecx
    5ec3:      	cmpq	$0x25, %rcx
    5ec7:      	movq	0x8(%rsp), %r10
    5ecc:      	ja	0x5eec <generic_fentry_process_filter+0x235c>
    5ece:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    5ed8:      	btq	%rcx, %rdx
    5edc:      	jae	0x5eec <generic_fentry_process_filter+0x235c>
    5ede:      	testq	%rax, %rax
    5ee1:      	jne	0x615b <generic_fentry_process_filter+0x25cb>
    5ee7:      	jmp	0x50a5 <generic_fentry_process_filter+0x1515>
    5eec:      	testq	%rax, %rax
    5eef:      	jne	0x50a5 <generic_fentry_process_filter+0x1515>
    5ef5:      	jmp	0x615b <generic_fentry_process_filter+0x25cb>
    5efa:      	movq	$0x1, (%rcx)
    5f01:      	testb	$0x10, %bpl
    5f05:      	jne	0x5f3d <generic_fentry_process_filter+0x23ad>
    5f07:      	movl	0x38(%rax), %edx
    5f0a:      	testl	%edx, %edx
    5f0c:      	je	0x5f36 <generic_fentry_process_filter+0x23a6>
    5f0e:      	cmpl	0x30(%rsi), %edx
    5f11:      	je	0x5f3d <generic_fentry_process_filter+0x23ad>
    5f13:      	jmp	0x6057 <generic_fentry_process_filter+0x24c7>
    5f18:      	movq	$0x1, (%rcx)
    5f1f:      	testb	$0x10, %bpl
    5f23:      	je	0x5f5b <generic_fentry_process_filter+0x23cb>
    5f25:      	movl	0x38(%rax), %edx
    5f28:      	testl	%edx, %edx
    5f2a:      	je	0x5f54 <generic_fentry_process_filter+0x23c4>
    5f2c:      	cmpl	0x30(%rsi), %edx
    5f2f:      	je	0x5f5b <generic_fentry_process_filter+0x23cb>
    5f31:      	jmp	0x6057 <generic_fentry_process_filter+0x24c7>
    5f36:      	movq	$0x1, (%rcx)
    5f3d:      	testb	$0x20, %bpl
    5f41:      	jne	0x5f79 <generic_fentry_process_filter+0x23e9>
    5f43:      	movl	0x3c(%rax), %edx
    5f46:      	testl	%edx, %edx
    5f48:      	je	0x5f72 <generic_fentry_process_filter+0x23e2>
    5f4a:      	cmpl	0x34(%rsi), %edx
    5f4d:      	je	0x5f79 <generic_fentry_process_filter+0x23e9>
    5f4f:      	jmp	0x6057 <generic_fentry_process_filter+0x24c7>
    5f54:      	movq	$0x1, (%rcx)
    5f5b:      	testb	$0x20, %bpl
    5f5f:      	je	0x5f97 <generic_fentry_process_filter+0x2407>
    5f61:      	movl	0x3c(%rax), %edx
    5f64:      	testl	%edx, %edx
    5f66:      	je	0x5f90 <generic_fentry_process_filter+0x2400>
    5f68:      	cmpl	0x34(%rsi), %edx
    5f6b:      	je	0x5f97 <generic_fentry_process_filter+0x2407>
    5f6d:      	jmp	0x6057 <generic_fentry_process_filter+0x24c7>
    5f72:      	movq	$0x1, (%rcx)
    5f79:      	testb	$0x40, %bpl
    5f7d:      	jne	0x5fb5 <generic_fentry_process_filter+0x2425>
    5f7f:      	movl	0x40(%rax), %edx
    5f82:      	testl	%edx, %edx
    5f84:      	je	0x5fae <generic_fentry_process_filter+0x241e>
    5f86:      	cmpl	0x38(%rsi), %edx
    5f89:      	je	0x5fb5 <generic_fentry_process_filter+0x2425>
    5f8b:      	jmp	0x6057 <generic_fentry_process_filter+0x24c7>
    5f90:      	movq	$0x1, (%rcx)
    5f97:      	testb	$0x40, %bpl
    5f9b:      	je	0x5fd2 <generic_fentry_process_filter+0x2442>
    5f9d:      	movl	0x40(%rax), %edx
    5fa0:      	testl	%edx, %edx
    5fa2:      	je	0x5fcb <generic_fentry_process_filter+0x243b>
    5fa4:      	cmpl	0x38(%rsi), %edx
    5fa7:      	je	0x5fd2 <generic_fentry_process_filter+0x2442>
    5fa9:      	jmp	0x6057 <generic_fentry_process_filter+0x24c7>
    5fae:      	movq	$0x1, (%rcx)
    5fb5:      	testb	%bpl, %bpl
    5fb8:      	js	0x5fec <generic_fentry_process_filter+0x245c>
    5fba:      	movl	0x44(%rax), %edx
    5fbd:      	testl	%edx, %edx
    5fbf:      	je	0x5fe5 <generic_fentry_process_filter+0x2455>
    5fc1:      	cmpl	0x3c(%rsi), %edx
    5fc4:      	je	0x5fec <generic_fentry_process_filter+0x245c>
    5fc6:      	jmp	0x6057 <generic_fentry_process_filter+0x24c7>
    5fcb:      	movq	$0x1, (%rcx)
    5fd2:      	testb	%bpl, %bpl
    5fd5:      	jns	0x6009 <generic_fentry_process_filter+0x2479>
    5fd7:      	movl	0x44(%rax), %edx
    5fda:      	testl	%edx, %edx
    5fdc:      	je	0x6002 <generic_fentry_process_filter+0x2472>
    5fde:      	cmpl	0x3c(%rsi), %edx
    5fe1:      	je	0x6009 <generic_fentry_process_filter+0x2479>
    5fe3:      	jmp	0x6057 <generic_fentry_process_filter+0x24c7>
    5fe5:      	movq	$0x1, (%rcx)
    5fec:      	testl	$0x100, %ebp            # imm = 0x100
    5ff2:      	jne	0x6032 <generic_fentry_process_filter+0x24a2>
    5ff4:      	movl	0x48(%rax), %edx
    5ff7:      	testl	%edx, %edx
    5ff9:      	je	0x602b <generic_fentry_process_filter+0x249b>
    5ffb:      	cmpl	0x40(%rsi), %edx
    5ffe:      	je	0x6032 <generic_fentry_process_filter+0x24a2>
    6000:      	jmp	0x6057 <generic_fentry_process_filter+0x24c7>
    6002:      	movq	$0x1, (%rcx)
    6009:      	testl	$0x100, %ebp            # imm = 0x100
    600f:      	je	0x6141 <generic_fentry_process_filter+0x25b1>
    6015:      	movl	0x48(%rax), %edx
    6018:      	testl	%edx, %edx
    601a:      	je	0x613a <generic_fentry_process_filter+0x25aa>
    6020:      	cmpl	0x40(%rsi), %edx
    6023:      	je	0x6141 <generic_fentry_process_filter+0x25b1>
    6029:      	jmp	0x6057 <generic_fentry_process_filter+0x24c7>
    602b:      	movq	$0x1, (%rcx)
    6032:      	testl	$0x200, %ebp            # imm = 0x200
    6038:      	jne	0x615b <generic_fentry_process_filter+0x25cb>
    603e:      	movl	0x4c(%rax), %eax
    6041:      	testl	%eax, %eax
    6043:      	je	0x6154 <generic_fentry_process_filter+0x25c4>
    6049:      	movq	0x50(%rsp), %rdx
    604e:      	cmpl	0x44(%rdx), %eax
    6051:      	je	0x615b <generic_fentry_process_filter+0x25cb>
    6057:      	addl	$0xc, %ebx
    605a:      	movq	$0x1, (%rcx)
    6061:      	movl	%ebx, %eax
    6063:      	movl	%eax, %ecx
    6065:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    606b:      	cmpl	$0x4, (%rcx,%r10)
    6070:      	movq	0x50(%rsp), %rcx
    6075:      	jne	0x609c <generic_fentry_process_filter+0x250c>
    6077:      	movq	0x5eb8(%rcx), %rax
    607e:      	andl	$0x1f, %eax
    6081:      	movb	$0x1, 0x5ec1(%rcx,%rax)
    6089:      	movb	$0x1, 0x5ee0(%rcx)
    6090:      	movb	$0x1, 0x5ec0(%rcx)
    6097:      	jmp	0x615b <generic_fentry_process_filter+0x25cb>
    609c:      	addl	$0x4, %eax
    609f:      	andl	$0x3ff, %eax            # imm = 0x3FF
    60a4:      	movl	(%rax,%r10), %r14d
    60a8:      	movl	0x4(%rax,%r10), %ebx
    60ad:      	movl	0x8(%rax,%r10), %ebp
    60b2:      	movq	0xc(%rax,%r10), %r15
    60b7:      	movl	$0xe, %eax
    60bc:      	callq	*%rax
    60be:      	shrq	$0x20, %rax
    60c2:      	movl	%eax, 0x60(%rsp)
    60c6:      	movq	(%rip), %rdi            # 0x60cd <generic_fentry_process_filter+0x253d>
    60cd:      	leaq	0x60(%rsp), %rsi
    60d2:      	movl	$0x1, %eax
    60d7:      	callq	*%rax
    60d9:      	testq	%rax, %rax
    60dc:      	je	0x615b <generic_fentry_process_filter+0x25cb>
    60de:      	testl	%ebp, %ebp
    60e0:      	je	0x60f4 <generic_fentry_process_filter+0x2564>
    60e2:      	cmpl	$0x2, %r14d
    60e6:      	ja	0x615b <generic_fentry_process_filter+0x25cb>
    60e8:      	movq	0x50(%rsp), %rcx
    60ed:      	cmpl	%ebp, 0x44(%rcx)
    60f0:      	jne	0x60fa <generic_fentry_process_filter+0x256a>
    60f2:      	jmp	0x615b <generic_fentry_process_filter+0x25cb>
    60f4:      	cmpl	$0x2, %r14d
    60f8:      	ja	0x615b <generic_fentry_process_filter+0x25cb>
    60fa:      	movq	0x50(%rax,%r14,8), %rax
    60ff:      	movq	0x50(%rsp), %rcx
    6104:      	movq	0x48(%rcx,%r14,8), %rcx
    6109:      	movq	%rcx, %rdx
    610c:      	xorq	%rax, %rdx
    610f:      	testq	%r15, %rdx
    6112:      	je	0x611b <generic_fentry_process_filter+0x258b>
    6114:      	cmpl	$0x5, %ebx
    6117:      	jne	0x615b <generic_fentry_process_filter+0x25cb>
    6119:      	jmp	0x6125 <generic_fentry_process_filter+0x2595>
    611b:      	cmpq	%rcx, %rax
    611e:      	je	0x615b <generic_fentry_process_filter+0x25cb>
    6120:      	cmpl	$0x6, %ebx
    6123:      	jne	0x615b <generic_fentry_process_filter+0x25cb>
    6125:      	movq	0x50(%rsp), %rcx
    612a:      	movq	$0x1, 0x5ef0(%rcx)
    6135:      	jmp	0x6077 <generic_fentry_process_filter+0x24e7>
    613a:      	movq	$0x1, (%rcx)
    6141:      	testl	$0x200, %ebp            # imm = 0x200
    6147:      	je	0x615b <generic_fentry_process_filter+0x25cb>
    6149:      	movl	0x4c(%rax), %eax
    614c:      	testl	%eax, %eax
    614e:      	jne	0x6049 <generic_fentry_process_filter+0x24b9>
    6154:      	movq	$0x1, (%rcx)
    615b:      	movq	0x50(%rsp), %rcx
    6160:      	movq	0x5eb8(%rcx), %rax
    6167:      	incq	%rax
    616a:      	movq	%rax, 0x5eb8(%rcx)
    6171:      	cmpq	0xc0(%rsp), %rax
    6179:      	jbe	0x61c7 <generic_fentry_process_filter+0x2637>
    617b:      	movq	0x38(%rsp), %rdx
    6180:      	movl	(%rdx), %eax
    6182:      	movl	%eax, 0x10(%rcx)
    6185:      	movq	0x8(%rdx), %rax
    6189:      	movq	%rax, 0x18(%rcx)
    618d:      	cmpb	$0x0, 0x5ec0(%rcx)
    6194:      	movq	0xb8(%rsp), %rbx
    619c:      	je	0x61b3 <generic_fentry_process_filter+0x2623>
    619e:      	movq	(%rip), %rsi            # 0x61a5 <generic_fentry_process_filter+0x2615>
    61a5:      	xorl	%ecx, %ecx
    61a7:      	movl	$0xc, %eax
    61ac:      	movq	%rbx, %rdi
    61af:      	xorl	%edx, %edx
    61b1:      	callq	*%rax
    61b3:      	xorl	%eax, %eax
    61b5:      	addq	$0xe8, %rsp
    61bc:      	popq	%rbx
    61bd:      	popq	%r12
    61bf:      	popq	%r13
    61c1:      	popq	%r14
    61c3:      	popq	%r15
    61c5:      	popq	%rbp
    61c6:      	retq
    61c7:      	movq	(%rip), %rsi            # 0x61ce <generic_fentry_process_filter+0x263e>
    61ce:      	movl	$0x2, %ecx
    61d3:      	movl	$0xc, %eax
    61d8:      	movq	0xb8(%rsp), %rdi
    61e0:      	movl	$0x2, %edx
    61e5:      	jmp	0x61b1 <generic_fentry_process_filter+0x2621>
    61e7:      	nopw	(%rax,%rax)

00000000000061f0 <generic_fentry_filter_arg>:
    61f0:      	pushq	%rbp
    61f1:      	pushq	%r15
    61f3:      	pushq	%r14
    61f5:      	pushq	%r13
    61f7:      	pushq	%r12
    61f9:      	pushq	%rbx
    61fa:      	subq	$0x28, %rsp
    61fe:      	movq	%rdi, %rbx
    6201:      	movl	$0x0, 0xc(%rsp)
    6209:      	movq	(%rip), %rdi            # 0x6210 <generic_fentry_filter_arg+0x20>
    6210:      	leaq	0xc(%rsp), %rsi
    6215:      	movl	$0x1, %eax
    621a:      	callq	*%rax
    621c:      	testq	%rax, %rax
    621f:      	je	0x65ec <generic_fentry_filter_arg+0x3fc>
    6225:      	movq	%rax, %r14
    6228:      	movl	0x5f00(%rax), %r12d
    622f:      	leaq	0x5ef8(%rax), %rsi
    6236:      	movq	(%rip), %rdi            # 0x623d <generic_fentry_filter_arg+0x4d>
    623d:      	movl	$0x1, %eax
    6242:      	callq	*%rax
    6244:      	testq	%rax, %rax
    6247:      	je	0x65d1 <generic_fentry_filter_arg+0x3e1>
    624d:      	cmpb	$0x0, 0x5ee0(%r14)
    6255:      	je	0x65d1 <generic_fentry_filter_arg+0x3e1>
    625b:      	movq	%rax, %r15
    625e:      	movl	%r12d, %eax
    6261:      	andl	$0x7, %eax
    6264:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
    626d:      	je	0x62fc <generic_fentry_filter_arg+0x10c>
    6273:      	movl	%eax, %eax
    6275:      	movl	0x4(%r15,%rax,4), %ecx
    627a:      	leaq	(%rcx,%rax,4), %rdx
    627e:      	addq	$0x4, %rdx
    6282:      	leaq	(%rcx,%rax,4), %rax
    6286:      	addq	$0x8, %rax
    628a:      	andl	$0x3ff, %eax            # imm = 0x3FF
    628f:      	movl	(%rax,%r15), %eax
    6293:      	addq	%rdx, %rax
    6296:      	addq	$0x4, %rax
    629a:      	movl	%eax, %ecx
    629c:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    62a2:      	movl	(%rcx,%r15), %ecx
    62a6:      	addq	%rax, %rcx
    62a9:      	movl	%ecx, %eax
    62ab:      	andl	$0x3ff, %eax            # imm = 0x3FF
    62b0:      	movl	(%rax,%r15), %eax
    62b4:      	addq	%rcx, %rax
    62b7:      	movl	%eax, %ecx
    62b9:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    62bf:      	movl	(%rcx,%r15), %ecx
    62c3:      	addq	%rax, %rcx
    62c6:      	movl	%ecx, %eax
    62c8:      	andl	$0x3ff, %eax            # imm = 0x3FF
    62cd:      	movl	(%rax,%r15), %ebp
    62d1:      	addq	%rcx, %rbp
    62d4:      	movl	%ebp, %eax
    62d6:      	andl	$0x3ff, %eax            # imm = 0x3FF
    62db:      	movq	%rax, (%rsp)
    62df:      	cmpl	$0x19, (%r15,%rax)
    62e4:      	jae	0x6351 <generic_fentry_filter_arg+0x161>
    62e6:      	movq	(%rsp), %rax
    62ea:      	cmpq	$0x1, %rax
    62ee:      	je	0x65d1 <generic_fentry_filter_arg+0x3e1>
    62f4:      	testl	%eax, %eax
    62f6:      	jne	0x65ab <generic_fentry_filter_arg+0x3bb>
    62fc:      	cmpl	$0x1, %r12d
    6300:      	jg	0x6321 <generic_fentry_filter_arg+0x131>
    6302:      	cmpl	$-0x1, %r12d
    6306:      	je	0x65fd <generic_fentry_filter_arg+0x40d>
    630c:      	testl	%r12d, %r12d
    630f:      	je	0x660a <generic_fentry_filter_arg+0x41a>
    6315:      	cmpl	$0x1, %r12d
    6319:      	je	0x661a <generic_fentry_filter_arg+0x42a>
    631f:      	jmp	0x633f <generic_fentry_filter_arg+0x14f>
    6321:      	cmpl	$0x2, %r12d
    6325:      	je	0x662a <generic_fentry_filter_arg+0x43a>
    632b:      	cmpl	$0x3, %r12d
    632f:      	je	0x663a <generic_fentry_filter_arg+0x44a>
    6335:      	cmpl	$0x4, %r12d
    6339:      	je	0x664a <generic_fentry_filter_arg+0x45a>
    633f:      	cmpl	$0x4, %r12d
    6343:      	jg	0x667c <generic_fentry_filter_arg+0x48c>
    6349:      	incl	%r12d
    634c:      	jmp	0x665a <generic_fentry_filter_arg+0x46a>
    6351:      	movq	(%rsp), %rax
    6355:      	addq	%r15, %rax
    6358:      	movq	%rax, 0x10(%rsp)
    635d:      	movl	$0x1, %r13d
    6363:      	nopw	%cs:(%rax,%rax)
    6370:      	movq	0x10(%rsp), %rax
    6375:      	movl	(%rax,%r13,4), %edi
    6379:      	testl	$0x3ff, %edi            # imm = 0x3FF
    637f:      	je	0x62e6 <generic_fentry_filter_arg+0xf6>
    6385:      	addl	%ebp, %edi
    6387:      	andl	$0x3ff, %edi            # imm = 0x3FF
    638d:      	movl	0x4(%r15,%rdi), %ecx
    6392:      	cmpl	$0x23, %ecx
    6395:      	je	0x62fc <generic_fentry_filter_arg+0x10c>
    639b:      	addq	%r15, %rdi
    639e:      	movl	(%rdi), %eax
    63a0:      	cmpq	$0x4, %rax
    63a4:      	ja	0x62fc <generic_fentry_filter_arg+0x10c>
    63aa:      	cmpl	$0x0, 0x5ea0(%r14,%rax,4)
    63b3:      	jne	0x62fc <generic_fentry_filter_arg+0x10c>
    63b9:      	movq	0x5e78(%r14,%rax,8), %rax
    63c1:      	andl	$0x7ff, %eax            # imm = 0x7FF
    63c6:      	leaq	(%r14,%rax), %rsi
    63ca:      	addq	$0x90, %rsi
    63d1:      	movl	0xc(%rdi), %eax
    63d4:      	cmpl	$0x1b, %eax
    63d7:      	jle	0x63f8 <generic_fentry_filter_arg+0x208>
    63d9:      	cmpl	$0x25, %eax
    63dc:      	jg	0x6428 <generic_fentry_filter_arg+0x238>
    63de:      	leal	-0x1c(%rax), %edx
    63e1:      	cmpl	$0x9, %edx
    63e4:      	jb	0x646e <generic_fentry_filter_arg+0x27e>
    63ea:      	cmpl	$0x25, %eax
    63ed:      	je	0x6551 <generic_fentry_filter_arg+0x361>
    63f3:      	jmp	0x6599 <generic_fentry_filter_arg+0x3a9>
    63f8:      	cmpl	$0x9, %eax
    63fb:      	jle	0x644e <generic_fentry_filter_arg+0x25e>
    63fd:      	leal	-0xa(%rax), %edx
    6400:      	cmpl	$0x4, %edx
    6403:      	jb	0x646e <generic_fentry_filter_arg+0x27e>
    6405:      	leal	-0xf(%rax), %ecx
    6408:      	cmpl	$0x2, %ecx
    640b:      	jb	0x6551 <generic_fentry_filter_arg+0x361>
    6411:      	cmpl	$0x11, %eax
    6414:      	jne	0x6599 <generic_fentry_filter_arg+0x3a9>
    641a:      	addq	$0x4, %rsi
    641e:      	callq	0x6423 <generic_fentry_filter_arg+0x233>
    6423:      	jmp	0x6590 <generic_fentry_filter_arg+0x3a0>
    6428:      	cmpl	$0x29, %eax
    642b:      	jg	0x6540 <generic_fentry_filter_arg+0x350>
    6431:      	leal	-0x26(%rax), %ecx
    6434:      	cmpl	$0x2, %ecx
    6437:      	jb	0x64fb <generic_fentry_filter_arg+0x30b>
    643d:      	addl	$-0x28, %eax
    6440:      	cmpl	$0x2, %eax
    6443:      	jb	0x64f1 <generic_fentry_filter_arg+0x301>
    6449:      	jmp	0x6599 <generic_fentry_filter_arg+0x3a9>
    644e:      	cmpl	$0x4, %eax
    6451:      	jg	0x64de <generic_fentry_filter_arg+0x2ee>
    6457:      	cmpl	$0x1, %eax
    645a:      	je	0x646e <generic_fentry_filter_arg+0x27e>
    645c:      	cmpl	$0x2, %eax
    645f:      	je	0x656e <generic_fentry_filter_arg+0x37e>
    6465:      	cmpl	$0x4, %eax
    6468:      	jne	0x6599 <generic_fentry_filter_arg+0x3a9>
    646e:      	cmpl	$0xb, %eax
    6471:      	jle	0x64bb <generic_fentry_filter_arg+0x2cb>
    6473:      	cmpl	$0x24, %eax
    6476:      	ja	0x6558 <generic_fentry_filter_arg+0x368>
    647c:      	movl	%eax, %edx
    647e:      	movabsq	$0x1e00000000, %r8      # imm = 0x1E00000000
    6488:      	btq	%rdx, %r8
    648c:      	jb	0x6502 <generic_fentry_filter_arg+0x312>
    648e:      	movl	$0x60000000, %ecx       # imm = 0x60000000
    6493:      	btq	%rdx, %rcx
    6497:      	jb	0x6567 <generic_fentry_filter_arg+0x377>
    649d:      	movabsq	$0x180000000, %rcx      # imm = 0x180000000
    64a7:      	btq	%rdx, %rcx
    64ab:      	jae	0x6558 <generic_fentry_filter_arg+0x368>
    64b1:      	callq	0x64b6 <generic_fentry_filter_arg+0x2c6>
    64b6:      	jmp	0x6590 <generic_fentry_filter_arg+0x3a0>
    64bb:      	leal	-0xa(%rax), %ecx
    64be:      	cmpl	$0x2, %ecx
    64c1:      	jb	0x657f <generic_fentry_filter_arg+0x38f>
    64c7:      	cmpl	$0x1, %eax
    64ca:      	je	0x6560 <generic_fentry_filter_arg+0x370>
    64d0:      	cmpl	$0x4, %eax
    64d3:      	je	0x6560 <generic_fentry_filter_arg+0x370>
    64d9:      	jmp	0x6599 <generic_fentry_filter_arg+0x3a9>
    64de:      	cmpl	$0x5, %eax
    64e1:      	je	0x64f1 <generic_fentry_filter_arg+0x301>
    64e3:      	cmpl	$0x6, %eax
    64e6:      	je	0x64fb <generic_fentry_filter_arg+0x30b>
    64e8:      	cmpl	$0x7, %eax
    64eb:      	jne	0x6599 <generic_fentry_filter_arg+0x3a9>
    64f1:      	callq	0x64f6 <generic_fentry_filter_arg+0x306>
    64f6:      	jmp	0x6590 <generic_fentry_filter_arg+0x3a0>
    64fb:      	movl	$0x4, %edx
    6500:      	jmp	0x6573 <generic_fentry_filter_arg+0x383>
    6502:      	cmpl	$0x1e, %ecx
    6505:      	jne	0x657f <generic_fentry_filter_arg+0x38f>
    6507:      	movl	0x10(%rdi), %eax
    650a:      	andl	$0x7, %eax
    650d:      	movl	%eax, %ecx
    650f:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    6518:      	jne	0x62fc <generic_fentry_filter_arg+0x10c>
    651e:      	movq	(%rsi), %rcx
    6521:      	movq	0x5e78(%r14,%rax,8), %rdx
    6529:      	andl	$0x7ff, %edx            # imm = 0x7FF
    652f:      	xorl	%eax, %eax
    6531:      	andnq	0x90(%r14,%rdx), %rcx, %rcx
    653b:      	setne	%al
    653e:      	jmp	0x6590 <generic_fentry_filter_arg+0x3a0>
    6540:      	cmpl	$0x2a, %eax
    6543:      	je	0x6551 <generic_fentry_filter_arg+0x361>
    6545:      	cmpl	$0x2c, %eax
    6548:      	jne	0x6599 <generic_fentry_filter_arg+0x3a9>
    654a:      	callq	0x654f <generic_fentry_filter_arg+0x35f>
    654f:      	jmp	0x6590 <generic_fentry_filter_arg+0x3a0>
    6551:      	callq	0x6556 <generic_fentry_filter_arg+0x366>
    6556:      	jmp	0x6590 <generic_fentry_filter_arg+0x3a0>
    6558:      	leal	-0xc(%rax), %ecx
    655b:      	cmpl	$0x2, %ecx
    655e:      	jae	0x657a <generic_fentry_filter_arg+0x38a>
    6560:      	callq	0x6565 <generic_fentry_filter_arg+0x375>
    6565:      	jmp	0x6590 <generic_fentry_filter_arg+0x3a0>
    6567:      	callq	0x656c <generic_fentry_filter_arg+0x37c>
    656c:      	jmp	0x6590 <generic_fentry_filter_arg+0x3a0>
    656e:      	movl	$0x8, %edx
    6573:      	callq	0x6578 <generic_fentry_filter_arg+0x388>
    6578:      	jmp	0x6590 <generic_fentry_filter_arg+0x3a0>
    657a:      	cmpl	$0x1c, %eax
    657d:      	jne	0x6599 <generic_fentry_filter_arg+0x3a9>
    657f:      	callq	0x6584 <generic_fentry_filter_arg+0x394>
    6584:      	nopw	%cs:(%rax,%rax)
    6590:      	testq	%rax, %rax
    6593:      	je	0x62fc <generic_fentry_filter_arg+0x10c>
    6599:      	incq	%r13
    659c:      	cmpq	$0x6, %r13
    65a0:      	jne	0x6370 <generic_fentry_filter_arg+0x180>
    65a6:      	jmp	0x62e6 <generic_fentry_filter_arg+0xf6>
    65ab:      	movq	(%rsp), %rax
    65af:      	movl	%eax, 0x5f04(%r14)
    65b6:      	movq	(%rip), %rsi            # 0x65bd <generic_fentry_filter_arg+0x3cd>
    65bd:      	movl	$0x4, %ecx
    65c2:      	movl	$0xc, %eax
    65c7:      	movq	%rbx, %rdi
    65ca:      	movl	$0x4, %edx
    65cf:      	callq	*%rax
    65d1:      	movq	(%rip), %rsi            # 0x65d8 <generic_fentry_filter_arg+0x3e8>
    65d8:      	movl	$0x5, %ecx
    65dd:      	movl	$0xc, %eax
    65e2:      	movq	%rbx, %rdi
    65e5:      	movl	$0x5, %edx
    65ea:      	callq	*%rax
    65ec:      	xorl	%eax, %eax
    65ee:      	addq	$0x28, %rsp
    65f2:      	popq	%rbx
    65f3:      	popq	%r12
    65f5:      	popq	%r13
    65f7:      	popq	%r14
    65f9:      	popq	%r15
    65fb:      	popq	%rbp
    65fc:      	retq
    65fd:      	xorl	%r12d, %r12d
    6600:      	cmpb	$0x0, 0x5ec1(%r14)
    6608:      	jne	0x665a <generic_fentry_filter_arg+0x46a>
    660a:      	movl	$0x1, %r12d
    6610:      	cmpb	$0x0, 0x5ec2(%r14)
    6618:      	jne	0x665a <generic_fentry_filter_arg+0x46a>
    661a:      	movl	$0x2, %r12d
    6620:      	cmpb	$0x0, 0x5ec3(%r14)
    6628:      	jne	0x665a <generic_fentry_filter_arg+0x46a>
    662a:      	movl	$0x3, %r12d
    6630:      	cmpb	$0x0, 0x5ec4(%r14)
    6638:      	jne	0x665a <generic_fentry_filter_arg+0x46a>
    663a:      	movl	$0x4, %r12d
    6640:      	cmpb	$0x0, 0x5ec5(%r14)
    6648:      	jne	0x665a <generic_fentry_filter_arg+0x46a>
    664a:      	movl	$0x5, %r12d
    6650:      	cmpb	$0x0, 0x5ec6(%r14)
    6658:      	je	0x667c <generic_fentry_filter_arg+0x48c>
    665a:      	movl	%r12d, 0x5f00(%r14)
    6661:      	movq	(%rip), %rsi            # 0x6668 <generic_fentry_filter_arg+0x478>
    6668:      	movl	$0x3, %ecx
    666d:      	movl	$0xc, %eax
    6672:      	movq	%rbx, %rdi
    6675:      	movl	$0x3, %edx
    667a:      	callq	*%rax
    667c:      	movq	0x60(%r14), %rbx
    6680:      	movl	$0xe, %eax
    6685:      	callq	*%rax
    6687:      	movq	%rbx, 0x18(%rsp)
    668c:      	movq	%rax, 0x20(%rsp)
    6691:      	movq	(%rip), %rdi            # 0x6698 <generic_fentry_filter_arg+0x4a8>
    6698:      	leaq	0x18(%rsp), %rsi
    669d:      	movl	$0x1, %eax
    66a2:      	callq	*%rax
    66a4:      	testq	%rax, %rax
    66a7:      	je	0x65ec <generic_fentry_filter_arg+0x3fc>
    66ad:      	movq	(%rip), %rdi            # 0x66b4 <generic_fentry_filter_arg+0x4c4>
    66b4:      	leaq	0x18(%rsp), %rsi
    66b9:      	movl	$0x3, %eax
    66be:      	callq	*%rax
    66c0:      	jmp	0x65ec <generic_fentry_filter_arg+0x3fc>
    66c5:      	nopw	%cs:(%rax,%rax)

00000000000066d0 <generic_fentry_actions>:
    66d0:      	pushq	%rbp
    66d1:      	pushq	%r14
    66d3:      	pushq	%rbx
    66d4:      	subq	$0x10, %rsp
    66d8:      	movq	%rdi, %rbx
    66db:      	movl	$0x0, 0x8(%rsp)
    66e3:      	movq	(%rip), %rdi            # 0x66ea <generic_fentry_actions+0x1a>
    66ea:      	leaq	0x8(%rsp), %rsi
    66ef:      	movl	$0x1, %eax
    66f4:      	callq	*%rax
    66f6:      	testq	%rax, %rax
    66f9:      	je	0x6802 <generic_fentry_actions+0x132>
    66ff:      	movq	%rax, %rsi
    6702:      	movl	0x5f04(%rax), %r14d
    6709:      	cmpl	$0x2, %r14d
    670d:      	jl	0x6802 <generic_fentry_actions+0x132>
    6713:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    671a:      	movq	(%rip), %rdi            # 0x6721 <generic_fentry_actions+0x51>
    6721:      	movl	$0x1, %eax
    6726:      	callq	*%rax
    6728:      	testq	%rax, %rax
    672b:      	je	0x6802 <generic_fentry_actions+0x132>
    6731:      	movl	%r14d, %ecx
    6734:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    673a:      	addl	(%rax,%rcx), %r14d
    673e:      	movb	$0x1, 0x7(%rsp)
    6743:      	movl	$0x0, 0xc(%rsp)
    674b:      	movq	(%rip), %rdi            # 0x6752 <generic_fentry_actions+0x82>
    6752:      	leaq	0xc(%rsp), %rsi
    6757:      	movq	%rax, %rcx
    675a:      	movl	$0x1, %eax
    675f:      	andl	$0x7ff, %r14d           # imm = 0x7FF
    6766:      	addq	%rcx, %r14
    6769:      	callq	*%rax
    676b:      	testq	%rax, %rax
    676e:      	je	0x677e <generic_fentry_actions+0xae>
    6770:      	cmpb	$0x0, (%rax)
    6773:      	sete	%al
    6776:      	cmpl	$0x5, (%r14)
    677a:      	jae	0x6786 <generic_fentry_actions+0xb6>
    677c:      	jmp	0x67e0 <generic_fentry_actions+0x110>
    677e:      	movb	$0x1, %al
    6780:      	cmpl	$0x5, (%r14)
    6784:      	jb	0x67e0 <generic_fentry_actions+0x110>
    6786:      	movzbl	%al, %ebp
    6789:      	leaq	0x7(%rsp), %rcx
    678e:      	movq	%rbx, %rdi
    6791:      	xorl	%esi, %esi
    6793:      	movq	%r14, %rdx
    6796:      	movl	%ebp, %r8d
    6799:      	callq	0x679e <generic_fentry_actions+0xce>
    679e:      	leal	0x4(,%rax,4), %ecx
    67a5:      	cmpl	(%r14), %ecx
    67a8:      	jae	0x67e0 <generic_fentry_actions+0x110>
    67aa:      	leaq	0x7(%rsp), %rcx
    67af:      	movq	%rbx, %rdi
    67b2:      	movl	%eax, %esi
    67b4:      	movq	%r14, %rdx
    67b7:      	movl	%ebp, %r8d
    67ba:      	callq	0x67bf <generic_fentry_actions+0xef>
    67bf:      	leal	0x4(,%rax,4), %ecx
    67c6:      	cmpl	(%r14), %ecx
    67c9:      	jae	0x67e0 <generic_fentry_actions+0x110>
    67cb:      	leaq	0x7(%rsp), %rcx
    67d0:      	movq	%rbx, %rdi
    67d3:      	movl	%eax, %esi
    67d5:      	movq	%r14, %rdx
    67d8:      	movl	%ebp, %r8d
    67db:      	callq	0x67e0 <generic_fentry_actions+0x110>
    67e0:      	cmpb	$0x0, 0x7(%rsp)
    67e5:      	je	0x6802 <generic_fentry_actions+0x132>
    67e7:      	movq	(%rip), %rsi            # 0x67ee <generic_fentry_actions+0x11e>
    67ee:      	movl	$0x5, %ecx
    67f3:      	movl	$0xc, %eax
    67f8:      	movq	%rbx, %rdi
    67fb:      	movl	$0x5, %edx
    6800:      	callq	*%rax
    6802:      	xorl	%eax, %eax
    6804:      	addq	$0x10, %rsp
    6808:      	popq	%rbx
    6809:      	popq	%r14
    680b:      	popq	%rbp
    680c:      	retq
    680d:      	nopl	(%rax)

0000000000006810 <generic_fentry_output>:
    6810:      	pushq	%rbp
    6811:      	pushq	%r15
    6813:      	pushq	%r14
    6815:      	pushq	%r13
    6817:      	pushq	%r12
    6819:      	pushq	%rbx
    681a:      	subq	$0x78, %rsp
    681e:      	movq	%rdi, %r14
    6821:      	movl	$0x0, 0x24(%rsp)
    6829:      	movq	(%rip), %rdi            # 0x6830 <generic_fentry_output+0x20>
    6830:      	leaq	0x24(%rsp), %rsi
    6835:      	movl	$0x1, %eax
    683a:      	callq	*%rax
    683c:      	testq	%rax, %rax
    683f:      	je	0x6ce9 <generic_fentry_output+0x4d9>
    6845:      	movq	%rax, %rbx
    6848:      	cmpq	$0x0, 0x5ee8(%rax)
    6850:      	je	0x6b58 <generic_fentry_output+0x348>
    6856:      	movl	$0xe, %eax
    685b:      	callq	*%rax
    685d:      	movq	%rax, %r15
    6860:      	shrq	$0x20, %r15
    6864:      	movl	$0x23, %eax
    6869:      	callq	*%rax
    686b:      	movq	%rax, %r12
    686e:      	movl	%r15d, 0x28(%rsp)
    6873:      	movq	(%rip), %rdi            # 0x687a <generic_fentry_output+0x6a>
    687a:      	leaq	0x28(%rsp), %rsi
    687f:      	movl	$0x1, %eax
    6884:      	callq	*%rax
    6886:      	testq	%rax, %rax
    6889:      	je	0x6b58 <generic_fentry_output+0x348>
    688f:      	movq	%rax, %r15
    6892:      	leaq	0xd70(%r12), %rdx
    689a:      	leaq	0x70(%rsp), %rdi
    689f:      	movl	$0x8, %ecx
    68a4:      	movl	$0x4, %eax
    68a9:      	leaq	0x28(%r15), %r13
    68ad:      	movl	$0x4, %ebp
    68b2:      	movl	$0x8, %esi
    68b7:      	callq	*%rax
    68b9:      	movq	0x70(%rsp), %rcx
    68be:      	leaq	0x28(%rsp), %rdi
    68c3:      	movl	$0x48, %edx
    68c8:      	movl	$0x4, %eax
    68cd:      	movq	0x70(%rsp), %rdx
    68d2:      	movl	$0x48, %esi
    68d7:      	callq	*%rax
    68d9:      	movl	$0x218, %edx            # imm = 0x218
    68de:      	movq	0x30(%rsp), %rcx
    68e3:      	addq	%rdx, %rcx
    68e6:      	movl	$0x4, %esi
    68eb:      	movl	$0x4, %eax
    68f0:      	addq	0x30(%rsp), %rdx
    68f5:      	movq	%r13, %rdi
    68f8:      	movl	$0x4, %esi
    68fd:      	callq	*%rax
    68ff:      	leaq	0x2c(%r15), %rdi
    6903:      	movl	$0x4d8, %edx            # imm = 0x4D8
    6908:      	movq	0x38(%rsp), %rcx
    690d:      	addq	%rdx, %rcx
    6910:      	movl	$0x4, %esi
    6915:      	movl	$0x4, %eax
    691a:      	addq	0x38(%rsp), %rdx
    691f:      	movl	$0x4, %esi
    6924:      	callq	*%rax
    6926:      	leaq	0x30(%r15), %rdi
    692a:      	movq	0x40(%rsp), %rcx
    692f:      	addq	$0x58, %rcx
    6933:      	movl	$0x4, %edx
    6938:      	movl	$0x4, %eax
    693d:      	movq	0x40(%rsp), %rdx
    6942:      	addq	$0x58, %rdx
    6946:      	movl	$0x4, %esi
    694b:      	callq	*%rax
    694d:      	movq	$0x0, (%rsp)
    6955:      	leaq	0xb58(%r12), %rdx
    695d:      	movq	%rsp, %rdi
    6960:      	movl	$0x8, %ecx
    6965:      	movl	$0x4, %eax
    696a:      	movl	$0x8, %esi
    696f:      	callq	*%rax
    6971:      	movq	(%rsp), %rcx
    6975:      	testq	%rcx, %rcx
    6978:      	je	0x6a0b <generic_fentry_output+0x1fb>
    697e:      	movl	$0x0, 0xc(%rsp)
    6986:      	addq	$0x4, %rcx
    698a:      	leaq	0xc(%rsp), %rdi
    698f:      	movl	$0x4, %eax
    6994:      	movq	(%rsp), %rdx
    6998:      	addq	$0x4, %rdx
    699c:      	movl	$0x4, %esi
    69a1:      	callq	*%rax
    69a3:      	movq	(%rsp), %rax
    69a7:      	movslq	0xc(%rsp), %rcx
    69ac:      	shlq	$0x4, %rcx
    69b0:      	addq	%rax, %rcx
    69b3:      	addq	$0x80, %rcx
    69ba:      	leaq	0x10(%rsp), %rdi
    69bf:      	movl	$0x10, %edx
    69c4:      	movl	$0x4, %eax
    69c9:      	movq	(%rsp), %rcx
    69cd:      	movslq	0xc(%rsp), %rdx
    69d2:      	shlq	$0x4, %rdx
    69d6:      	addq	%rcx, %rdx
    69d9:      	addq	$0x80, %rdx
    69e0:      	movl	$0x10, %esi
    69e5:      	callq	*%rax
    69e7:      	leaq	0x34(%r15), %rdi
    69eb:      	movl	$0x158, %edx            # imm = 0x158
    69f0:      	movq	0x18(%rsp), %rcx
    69f5:      	addq	%rdx, %rcx
    69f8:      	movl	$0x4, %eax
    69fd:      	addq	0x18(%rsp), %rdx
    6a02:      	movl	$0x4, %esi
    6a07:      	callq	*%rax
    6a09:      	jmp	0x6a13 <generic_fentry_output+0x203>
    6a0b:      	movl	$0x0, 0x34(%r15)
    6a13:      	leaq	0x38(%r15), %rdi
    6a17:      	movl	$0x158, %r13d           # imm = 0x158
    6a1d:      	movq	0x48(%rsp), %rcx
    6a22:      	addq	%r13, %rcx
    6a25:      	movl	$0x4, %edx
    6a2a:      	movl	$0x4, %eax
    6a2f:      	movq	0x48(%rsp), %rdx
    6a34:      	addq	%r13, %rdx
    6a37:      	movl	$0x4, %esi
    6a3c:      	callq	*%rax
    6a3e:      	leaq	0x3c(%r15), %rdi
    6a42:      	movl	$0x118, %edx            # imm = 0x118
    6a47:      	movq	0x50(%rsp), %rcx
    6a4c:      	addq	%rdx, %rcx
    6a4f:      	movl	$0x4, %esi
    6a54:      	movl	$0x4, %eax
    6a59:      	addq	0x50(%rsp), %rdx
    6a5e:      	movl	$0x4, %esi
    6a63:      	callq	*%rax
    6a65:      	leaq	0x40(%r15), %rdi
    6a69:      	movl	$0x98, %ebp
    6a6e:      	movq	0x58(%rsp), %rcx
    6a73:      	addq	%rbp, %rcx
    6a76:      	movl	$0x4, %edx
    6a7b:      	movl	$0x4, %eax
    6a80:      	movq	0x58(%rsp), %rdx
    6a85:      	addq	%rbp, %rdx
    6a88:      	movl	$0x4, %esi
    6a8d:      	callq	*%rax
    6a8f:      	leaq	0x44(%r15), %rdi
    6a93:      	movq	0x60(%rsp), %rcx
    6a98:      	addq	%rbp, %rcx
    6a9b:      	movl	$0x4, %edx
    6aa0:      	movl	$0x4, %eax
    6aa5:      	addq	0x60(%rsp), %rbp
    6aaa:      	movl	$0x4, %esi
    6aaf:      	movq	%rbp, %rdx
    6ab2:      	callq	*%rax
    6ab4:      	leaq	0x48(%r15), %rdi
    6ab8:      	movq	0x68(%rsp), %rcx
    6abd:      	addq	$0x58, %rcx
    6ac1:      	movl	$0x4, %edx
    6ac6:      	movl	$0x4, %eax
    6acb:      	movq	0x68(%rsp), %rdx
    6ad0:      	addq	$0x58, %rdx
    6ad4:      	movl	$0x4, %esi
    6ad9:      	callq	*%rax
    6adb:      	movq	$0x0, 0x10(%rsp)
    6ae4:      	movq	$0x0, (%rsp)
    6aec:      	addq	$0xd00, %r12            # imm = 0xD00
    6af3:      	leaq	0x10(%rsp), %rdi
    6af8:      	movl	$0x8, %ecx
    6afd:      	movl	$0x4, %eax
    6b02:      	movl	$0x8, %esi
    6b07:      	movq	%r12, %rdx
    6b0a:      	callq	*%rax
    6b0c:      	movl	$0x90, %edx
    6b11:      	movq	0x10(%rsp), %rcx
    6b16:      	addq	%rdx, %rcx
    6b19:      	movq	%rsp, %rdi
    6b1c:      	movl	$0x8, %esi
    6b21:      	movl	$0x4, %eax
    6b26:      	addq	0x10(%rsp), %rdx
    6b2b:      	movl	$0x8, %esi
    6b30:      	callq	*%rax
    6b32:      	addq	$0x4c, %r15
    6b36:      	movq	(%rsp), %rcx
    6b3a:      	addq	%r13, %rcx
    6b3d:      	movl	$0x4, %edx
    6b42:      	movl	$0x4, %eax
    6b47:      	addq	(%rsp), %r13
    6b4b:      	movq	%r15, %rdi
    6b4e:      	movl	$0x4, %esi
    6b53:      	movq	%r13, %rdx
    6b56:      	callq	*%rax
    6b58:      	cmpq	$0x0, 0x5ef0(%rbx)
    6b60:      	je	0x6c19 <generic_fentry_output+0x409>
    6b66:      	movl	$0xe, %eax
    6b6b:      	callq	*%rax
    6b6d:      	movq	%rax, %r15
    6b70:      	shrq	$0x20, %r15
    6b74:      	movl	$0x23, %eax
    6b79:      	callq	*%rax
    6b7b:      	movq	%rax, %r12
    6b7e:      	movl	%r15d, 0x28(%rsp)
    6b83:      	movq	(%rip), %rdi            # 0x6b8a <generic_fentry_output+0x37a>
    6b8a:      	leaq	0x28(%rsp), %rsi
    6b8f:      	movl	$0x1, %eax
    6b94:      	callq	*%rax
    6b96:      	testq	%rax, %rax
    6b99:      	je	0x6c19 <generic_fentry_output+0x409>
    6b9b:      	leaq	0x50(%rax), %r15
    6b9f:      	addq	$0xd00, %r12            # imm = 0xD00
    6ba6:      	leaq	0x28(%rsp), %rdi
    6bab:      	movl	$0x8, %ecx
    6bb0:      	movq	%rax, %r13
    6bb3:      	movl	$0x4, %eax
    6bb8:      	movl	$0x8, %esi
    6bbd:      	movq	%r12, %rdx
    6bc0:      	callq	*%rax
    6bc2:      	movq	0x28(%rsp), %r12
    6bc7:      	leaq	0x58(%r13), %rdi
    6bcb:      	leaq	0x40(%r12), %rdx
    6bd0:      	movl	$0x8, %ecx
    6bd5:      	movl	$0x4, %eax
    6bda:      	movl	$0x8, %esi
    6bdf:      	callq	*%rax
    6be1:      	addq	$0x60, %r13
    6be5:      	leaq	0x30(%r12), %rdx
    6bea:      	movl	$0x8, %ecx
    6bef:      	movl	$0x4, %eax
    6bf4:      	movq	%r13, %rdi
    6bf7:      	movl	$0x8, %esi
    6bfc:      	callq	*%rax
    6bfe:      	addq	$0x38, %r12
    6c02:      	movl	$0x8, %ecx
    6c07:      	movl	$0x4, %eax
    6c0c:      	movq	%r15, %rdi
    6c0f:      	movl	$0x8, %esi
    6c14:      	movq	%r12, %rdx
    6c17:      	callq	*%rax
    6c19:      	movl	$0x90, %eax
    6c1e:      	addl	0x4(%rbx), %eax
    6c21:      	andl	$0x7fff, %eax           # imm = 0x7FFF
    6c26:      	cmpl	$0x2328, %eax           # imm = 0x2328
    6c2b:      	movl	$0x2328, %r15d          # imm = 0x2328
    6c31:      	cmovbl	%eax, %r15d
    6c35:      	movl	$0x0, 0x10(%rsp)
    6c3d:      	movq	(%rip), %rdi            # 0x6c44 <generic_fentry_output+0x434>
    6c44:      	leaq	0x10(%rsp), %rsi
    6c49:      	movl	$0x1, %eax
    6c4e:      	callq	*%rax
    6c50:      	testq	%rax, %rax
    6c53:      	je	0x6ca7 <generic_fentry_output+0x497>
    6c55:      	cmpb	$0x0, 0x28(%rax)
    6c59:      	je	0x6ca7 <generic_fentry_output+0x497>
    6c5b:      	movq	(%rip), %rsi            # 0x6c62 <generic_fentry_output+0x452>
    6c62:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    6c67:      	movl	$0x19, %eax
    6c6c:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    6c71:      	movq	%r14, %rdi
    6c74:      	movq	%rbx, %rcx
    6c77:      	movq	%r15, %r8
    6c7a:      	callq	*%rax
    6c7c:      	testq	%rax, %rax
    6c7f:      	js	0x6d49 <generic_fentry_output+0x539>
    6c85:      	movl	$0x0, 0x28(%rsp)
    6c8d:      	movq	(%rip), %rdi            # 0x6c94 <generic_fentry_output+0x484>
    6c94:      	leaq	0x28(%rsp), %rsi
    6c99:      	movl	$0x1, %eax
    6c9e:      	callq	*%rax
    6ca0:      	testq	%rax, %rax
    6ca3:      	jne	0x6ce4 <generic_fentry_output+0x4d4>
    6ca5:      	jmp	0x6ce9 <generic_fentry_output+0x4d9>
    6ca7:      	movq	(%rip), %rdi            # 0x6cae <generic_fentry_output+0x49e>
    6cae:      	xorl	%ecx, %ecx
    6cb0:      	movl	$0x82, %eax
    6cb5:      	movq	%rbx, %rsi
    6cb8:      	movq	%r15, %rdx
    6cbb:      	xorl	%ecx, %ecx
    6cbd:      	callq	*%rax
    6cbf:      	testq	%rax, %rax
    6cc2:      	js	0x6cfa <generic_fentry_output+0x4ea>
    6cc4:      	movl	$0x0, 0x28(%rsp)
    6ccc:      	movq	(%rip), %rdi            # 0x6cd3 <generic_fentry_output+0x4c3>
    6cd3:      	leaq	0x28(%rsp), %rsi
    6cd8:      	movl	$0x1, %eax
    6cdd:      	callq	*%rax
    6cdf:      	testq	%rax, %rax
    6ce2:      	je	0x6ce9 <generic_fentry_output+0x4d9>
    6ce4:      	lock
    6ce5:      	incq	0x8(%rax)
    6ce9:      	xorl	%eax, %eax
    6ceb:      	addq	$0x78, %rsp
    6cef:      	popq	%rbx
    6cf0:      	popq	%r12
    6cf2:      	popq	%r13
    6cf4:      	popq	%r14
    6cf6:      	popq	%r15
    6cf8:      	popq	%rbp
    6cf9:      	retq
    6cfa:      	movq	%rax, %rbx
    6cfd:      	movl	$0x0, 0x28(%rsp)
    6d05:      	movq	(%rip), %rdi            # 0x6d0c <generic_fentry_output+0x4fc>
    6d0c:      	leaq	0x28(%rsp), %rsi
    6d11:      	movl	$0x1, %eax
    6d16:      	callq	*%rax
    6d18:      	testq	%rax, %rax
    6d1b:      	je	0x6ce9 <generic_fentry_output+0x4d9>
    6d1d:      	cmpq	$-0xc, %rbx
    6d21:      	jg	0x6d91 <generic_fentry_output+0x581>
    6d23:      	cmpq	$-0x1c, %rbx
    6d27:      	je	0x6dd3 <generic_fentry_output+0x5c3>
    6d2d:      	cmpq	$-0x16, %rbx
    6d31:      	je	0x6d82 <generic_fentry_output+0x572>
    6d33:      	cmpq	$-0x10, %rbx
    6d37:      	jne	0x6dc4 <generic_fentry_output+0x5b4>
    6d3d:      	addq	$0x2f0, %rax            # imm = 0x2F0
    6d43:      	lock
    6d44:      	incq	(%rax)
    6d47:      	jmp	0x6ce9 <generic_fentry_output+0x4d9>
    6d49:      	movq	%rax, %rbx
    6d4c:      	movl	$0x0, 0x28(%rsp)
    6d54:      	movq	(%rip), %rdi            # 0x6d5b <generic_fentry_output+0x54b>
    6d5b:      	leaq	0x28(%rsp), %rsi
    6d60:      	movl	$0x1, %eax
    6d65:      	callq	*%rax
    6d67:      	testq	%rax, %rax
    6d6a:      	je	0x6ce9 <generic_fentry_output+0x4d9>
    6d70:      	cmpq	$-0xc, %rbx
    6d74:      	jg	0x6db2 <generic_fentry_output+0x5a2>
    6d76:      	cmpq	$-0x1c, %rbx
    6d7a:      	je	0x6dd3 <generic_fentry_output+0x5c3>
    6d7c:      	cmpq	$-0x16, %rbx
    6d80:      	jne	0x6d33 <generic_fentry_output+0x523>
    6d82:      	addq	$0x2f8, %rax            # imm = 0x2F8
    6d88:      	lock
    6d89:      	incq	(%rax)
    6d8c:      	jmp	0x6ce9 <generic_fentry_output+0x4d9>
    6d91:      	cmpq	$-0xb, %rbx
    6d95:      	je	0x6de2 <generic_fentry_output+0x5d2>
    6d97:      	cmpq	$-0x7, %rbx
    6d9b:      	je	0x6df1 <generic_fentry_output+0x5e1>
    6d9d:      	cmpq	$-0x2, %rbx
    6da1:      	jne	0x6dc4 <generic_fentry_output+0x5b4>
    6da3:      	addq	$0x2e0, %rax            # imm = 0x2E0
    6da9:      	lock
    6daa:      	incq	(%rax)
    6dad:      	jmp	0x6ce9 <generic_fentry_output+0x4d9>
    6db2:      	cmpq	$-0xb, %rbx
    6db6:      	je	0x6de2 <generic_fentry_output+0x5d2>
    6db8:      	cmpq	$-0x7, %rbx
    6dbc:      	je	0x6df1 <generic_fentry_output+0x5e1>
    6dbe:      	cmpq	$-0x2, %rbx
    6dc2:      	je	0x6da3 <generic_fentry_output+0x593>
    6dc4:      	addq	$0x2d8, %rax            # imm = 0x2D8
    6dca:      	lock
    6dcb:      	incq	(%rax)
    6dce:      	jmp	0x6ce9 <generic_fentry_output+0x4d9>
    6dd3:      	addq	$0x300, %rax            # imm = 0x300
    6dd9:      	lock
    6dda:      	incq	(%rax)
    6ddd:      	jmp	0x6ce9 <generic_fentry_output+0x4d9>
    6de2:      	addq	$0x308, %rax            # imm = 0x308
    6de8:      	lock
    6de9:      	incq	(%rax)
    6dec:      	jmp	0x6ce9 <generic_fentry_output+0x4d9>
    6df1:      	addq	$0x2e8, %rax            # imm = 0x2E8
    6df7:      	lock
    6df8:      	incq	(%rax)
    6dfb:      	jmp	0x6ce9 <generic_fentry_output+0x4d9>

Disassembly of section fentry/generic_fentry:

0000000000000000 <generic_fentry_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x88, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x38(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <generic_fentry_event+0x23>
      23:      	leaq	0x38(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x622 <generic_fentry_event+0x622>
      38:      	movq	%rax, %r14
      3b:      	leaq	0x5ef8(%rax), %rsi
      42:      	movl	$0x0, 0x5ef8(%rax)
      4c:      	movq	(%rip), %rdi            # 0x53 <generic_fentry_event+0x53>
      53:      	movl	$0x1, %eax
      58:      	callq	*%rax
      5a:      	testq	%rax, %rax
      5d:      	je	0x622 <generic_fentry_event+0x622>
      63:      	movl	0x64(%rax), %ecx
      66:      	movl	%ecx, 0x14(%rsp)
      6a:      	testl	%ecx, %ecx
      6c:      	je	0x23b <generic_fentry_event+0x23b>
      72:      	movq	%rax, %r12
      75:      	movq	(%rip), %rdi            # 0x7c <generic_fentry_event+0x7c>
      7c:      	leaq	0x14(%rsp), %rsi
      81:      	movl	$0x1, %eax
      86:      	callq	*%rax
      88:      	testq	%rax, %rax
      8b:      	je	0x622 <generic_fentry_event+0x622>
      91:      	movq	%rax, %r15
      94:      	movl	$0x0, 0x3c(%rsp)
      9c:      	movq	(%rip), %rdi            # 0xa3 <generic_fentry_event+0xa3>
      a3:      	leaq	0x3c(%rsp), %rsi
      a8:      	movl	$0x1, %eax
      ad:      	callq	*%rax
      af:      	testq	%rax, %rax
      b2:      	je	0xd8 <generic_fentry_event+0xd8>
      b4:      	cmpq	$0x63677270, 0x20(%rax) # imm = 0x63677270
      bc:      	jne	0xdc <generic_fentry_event+0xdc>
      be:      	movl	$0x50, %eax
      c3:      	callq	*%rax
      c5:      	movq	%rax, 0x8(%rsp)
      ca:      	testq	%rax, %rax
      cd:      	jne	0x1f6 <generic_fentry_event+0x1f6>
      d3:      	jmp	0x622 <generic_fentry_event+0x622>
      d8:      	xorl	%ebp, %ebp
      da:      	jmp	0xdf <generic_fentry_event+0xdf>
      dc:      	movl	0x10(%rax), %ebp
      df:      	movl	$0x23, %eax
      e4:      	callq	*%rax
      e6:      	movq	$0x0, 0x20(%rsp)
      ef:      	leaq	0xf90(%rax), %rdx
      f6:      	leaq	0x28(%rsp), %rdi
      fb:      	movl	$0x8, %ecx
     100:      	movl	$0x71, %eax
     105:      	movl	$0x8, %esi
     10a:      	callq	*%rax
     10c:      	movq	0x28(%rsp), %rax
     111:      	testq	%rax, %rax
     114:      	je	0x622 <generic_fentry_event+0x622>
     11a:      	cmpl	$0xb, %ebp
     11d:      	ja	0x622 <generic_fentry_event+0x622>
     123:      	movl	%ebp, %edx
     125:      	leaq	(%rax,%rdx,8), %rcx
     129:      	leaq	0x40(%rsp), %rdi
     12e:      	movl	$0x8, %esi
     133:      	movl	$0x71, %eax
     138:      	shlq	$0x3, %rdx
     13c:      	addq	0x28(%rsp), %rdx
     141:      	movl	$0x8, %esi
     146:      	callq	*%rax
     148:      	movq	0x40(%rsp), %rcx
     14d:      	testq	%rcx, %rcx
     150:      	je	0x622 <generic_fentry_event+0x622>
     156:      	leaq	0x20(%rsp), %rdi
     15b:      	movl	$0x8, %edx
     160:      	movl	$0x71, %eax
     165:      	movq	0x40(%rsp), %rdx
     16a:      	movl	$0x8, %esi
     16f:      	callq	*%rax
     171:      	movq	0x20(%rsp), %rdx
     176:      	testq	%rdx, %rdx
     179:      	je	0x622 <generic_fentry_event+0x622>
     17f:      	movq	$0x0, 0x40(%rsp)
     188:      	addq	$0x100, %rdx            # imm = 0x100
     18f:      	leaq	0x40(%rsp), %rdi
     194:      	movl	$0x8, %ecx
     199:      	movl	$0x71, %eax
     19e:      	movl	$0x8, %esi
     1a3:      	callq	*%rax
     1a5:      	movq	0x40(%rsp), %rdx
     1aa:      	movq	$0x0, 0x40(%rsp)
     1b3:      	testq	%rdx, %rdx
     1b6:      	je	0x1e6 <generic_fentry_event+0x1e6>
     1b8:      	addq	$0x60, %rdx
     1bc:      	leaq	0x40(%rsp), %rdi
     1c1:      	movl	$0x8, %ecx
     1c6:      	movl	$0x71, %eax
     1cb:      	movl	$0x8, %esi
     1d0:      	callq	*%rax
     1d2:      	movq	0x40(%rsp), %rax
     1d7:      	movq	%rax, 0x8(%rsp)
     1dc:      	testq	%rax, %rax
     1df:      	jne	0x1f6 <generic_fentry_event+0x1f6>
     1e1:      	jmp	0x622 <generic_fentry_event+0x622>
     1e6:      	xorl	%eax, %eax
     1e8:      	movq	%rax, 0x8(%rsp)
     1ed:      	testq	%rax, %rax
     1f0:      	je	0x622 <generic_fentry_event+0x622>
     1f6:      	movq	%rax, 0x40(%rsp)
     1fb:      	movq	(%rip), %rdi            # 0x202 <generic_fentry_event+0x202>
     202:      	leaq	0x40(%rsp), %rsi
     207:      	movl	$0x1, %eax
     20c:      	callq	*%rax
     20e:      	testq	%rax, %rax
     211:      	je	0x220 <generic_fentry_event+0x220>
     213:      	movq	(%rax), %rax
     216:      	testq	%rax, %rax
     219:      	je	0x220 <generic_fentry_event+0x220>
     21b:      	movq	%rax, 0x8(%rsp)
     220:      	leaq	0x8(%rsp), %rsi
     225:      	movl	$0x1, %eax
     22a:      	movq	%r15, %rdi
     22d:      	callq	*%rax
     22f:      	testq	%rax, %rax
     232:      	movq	%r12, %rax
     235:      	je	0x636 <generic_fentry_event+0x636>
     23b:      	movl	(%rax), %eax
     23d:      	movq	%rax, 0x60(%r14)
     241:      	movq	$0x0, 0x68(%r14)
     249:      	movq	$0x0, 0x5efc(%r14)
     254:      	movq	$0x0, 0x5eb8(%r14)
     25f:      	movq	$0x0, 0x5ec0(%r14)
     26a:      	movq	$0x0, 0x5ec8(%r14)
     275:      	movq	$0x0, 0x5ed0(%r14)
     280:      	movq	$0x0, 0x5ed8(%r14)
     28b:      	movb	$0x0, 0x5ee0(%r14)
     293:      	movl	$0x23, %eax
     298:      	callq	*%rax
     29a:      	movq	%rax, %r15
     29d:      	leaq	0xd70(%rax), %rdx
     2a4:      	leaq	0x20(%rsp), %rdi
     2a9:      	movl	$0x8, %ecx
     2ae:      	movl	$0x4, %eax
     2b3:      	leaq	0x20(%r14), %r12
     2b7:      	movl	$0x4, %r13d
     2bd:      	movl	$0x8, %esi
     2c2:      	callq	*%rax
     2c4:      	movq	0x20(%rsp), %rcx
     2c9:      	leaq	0x40(%rsp), %rdi
     2ce:      	movl	$0x48, %edx
     2d3:      	movl	$0x4, %eax
     2d8:      	movq	0x20(%rsp), %rdx
     2dd:      	movl	$0x48, %esi
     2e2:      	callq	*%rax
     2e4:      	movl	$0x218, %edx            # imm = 0x218
     2e9:      	movq	0x48(%rsp), %rcx
     2ee:      	addq	%rdx, %rcx
     2f1:      	movl	$0x4, %esi
     2f6:      	movl	$0x4, %eax
     2fb:      	addq	0x48(%rsp), %rdx
     300:      	movq	%r12, %rdi
     303:      	movl	$0x4, %esi
     308:      	callq	*%rax
     30a:      	leaq	0x24(%r14), %rdi
     30e:      	movl	$0x4d8, %edx            # imm = 0x4D8
     313:      	movq	0x50(%rsp), %rcx
     318:      	addq	%rdx, %rcx
     31b:      	movl	$0x4, %esi
     320:      	movl	$0x4, %eax
     325:      	addq	0x50(%rsp), %rdx
     32a:      	movl	$0x4, %esi
     32f:      	callq	*%rax
     331:      	leaq	0x28(%r14), %rdi
     335:      	movq	0x58(%rsp), %rcx
     33a:      	addq	$0x58, %rcx
     33e:      	movl	$0x4, %edx
     343:      	movl	$0x4, %eax
     348:      	movq	0x58(%rsp), %rdx
     34d:      	addq	$0x58, %rdx
     351:      	movl	$0x4, %esi
     356:      	callq	*%rax
     358:      	movq	$0x0, 0x8(%rsp)
     361:      	leaq	0xb58(%r15), %rdx
     368:      	leaq	0x8(%rsp), %rdi
     36d:      	movl	$0x8, %ecx
     372:      	movl	$0x4, %eax
     377:      	movl	$0x8, %esi
     37c:      	callq	*%rax
     37e:      	movq	0x8(%rsp), %rcx
     383:      	testq	%rcx, %rcx
     386:      	je	0x41c <generic_fentry_event+0x41c>
     38c:      	movl	$0x0, 0x18(%rsp)
     394:      	addq	$0x4, %rcx
     398:      	leaq	0x18(%rsp), %rdi
     39d:      	movl	$0x4, %eax
     3a2:      	movq	0x8(%rsp), %rdx
     3a7:      	addq	$0x4, %rdx
     3ab:      	movl	$0x4, %esi
     3b0:      	callq	*%rax
     3b2:      	movq	0x8(%rsp), %rax
     3b7:      	movslq	0x18(%rsp), %rcx
     3bc:      	shlq	$0x4, %rcx
     3c0:      	addq	%rax, %rcx
     3c3:      	addq	$0x80, %rcx
     3ca:      	leaq	0x28(%rsp), %rdi
     3cf:      	movl	$0x10, %edx
     3d4:      	movl	$0x4, %eax
     3d9:      	movq	0x8(%rsp), %rcx
     3de:      	movslq	0x18(%rsp), %rdx
     3e3:      	shlq	$0x4, %rdx
     3e7:      	addq	%rcx, %rdx
     3ea:      	addq	$0x80, %rdx
     3f1:      	movl	$0x10, %esi
     3f6:      	callq	*%rax
     3f8:      	leaq	0x2c(%r14), %rdi
     3fc:      	movl	$0x158, %edx            # imm = 0x158
     401:      	movq	0x30(%rsp), %rcx
     406:      	addq	%rdx, %rcx
     409:      	movl	$0x4, %eax
     40e:      	addq	0x30(%rsp), %rdx
     413:      	movl	$0x4, %esi
     418:      	callq	*%rax
     41a:      	jmp	0x424 <generic_fentry_event+0x424>
     41c:      	movl	$0x0, 0x2c(%r14)
     424:      	leaq	0x30(%r14), %rdi
     428:      	movl	$0x158, %r12d           # imm = 0x158
     42e:      	movq	0x60(%rsp), %rcx
     433:      	addq	%r12, %rcx
     436:      	movl	$0x4, %edx
     43b:      	movl	$0x4, %eax
     440:      	movq	0x60(%rsp), %rdx
     445:      	addq	%r12, %rdx
     448:      	movl	$0x4, %esi
     44d:      	callq	*%rax
     44f:      	leaq	0x34(%r14), %rdi
     453:      	movl	$0x118, %edx            # imm = 0x118
     458:      	movq	0x68(%rsp), %rcx
     45d:      	addq	%rdx, %rcx
     460:      	movl	$0x4, %esi
     465:      	movl	$0x4, %eax
     46a:      	addq	0x68(%rsp), %rdx
     46f:      	movl	$0x4, %esi
     474:      	callq	*%rax
     476:      	leaq	0x38(%r14), %rdi
     47a:      	movl	$0x98, %r13d
     480:      	movq	0x70(%rsp), %rcx
     485:      	addq	%r13, %rcx
     488:      	movl	$0x4, %edx
     48d:      	movl	$0x4, %eax
     492:      	movq	0x70(%rsp), %rdx
     497:      	addq	%r13, %rdx
     49a:      	movl	$0x4, %esi
     49f:      	callq	*%rax
     4a1:      	leaq	0x3c(%r14), %rdi
     4a5:      	movq	0x78(%rsp), %rcx
     4aa:      	addq	%r13, %rcx
     4ad:      	movl	$0x4, %edx
     4b2:      	movl	$0x4, %eax
     4b7:      	addq	0x78(%rsp), %r13
     4bc:      	movl	$0x4, %esi
     4c1:      	movq	%r13, %rdx
     4c4:      	callq	*%rax
     4c6:      	leaq	0x40(%r14), %rdi
     4ca:      	movq	0x80(%rsp), %rcx
     4d2:      	addq	$0x58, %rcx
     4d6:      	movl	$0x4, %edx
     4db:      	movl	$0x4, %eax
     4e0:      	movq	0x80(%rsp), %rdx
     4e8:      	addq	$0x58, %rdx
     4ec:      	movl	$0x4, %esi
     4f1:      	callq	*%rax
     4f3:      	movq	$0x0, 0x28(%rsp)
     4fc:      	movq	$0x0, 0x8(%rsp)
     505:      	addq	$0xd00, %r15            # imm = 0xD00
     50c:      	leaq	0x28(%rsp), %rdi
     511:      	movl	$0x8, %ecx
     516:      	movl	$0x4, %eax
     51b:      	movl	$0x8, %esi
     520:      	movq	%r15, %rdx
     523:      	callq	*%rax
     525:      	movl	$0x90, %edx
     52a:      	movq	0x28(%rsp), %rcx
     52f:      	addq	%rdx, %rcx
     532:      	leaq	0x8(%rsp), %rdi
     537:      	movl	$0x8, %esi
     53c:      	movl	$0x4, %eax
     541:      	addq	0x28(%rsp), %rdx
     546:      	movl	$0x8, %esi
     54b:      	callq	*%rax
     54d:      	leaq	0x44(%r14), %rdi
     551:      	movq	0x8(%rsp), %rcx
     556:      	addq	%r12, %rcx
     559:      	movl	$0x4, %edx
     55e:      	movl	$0x4, %eax
     563:      	addq	0x8(%rsp), %r12
     568:      	movl	$0x4, %esi
     56d:      	movq	%r12, %rdx
     570:      	callq	*%rax
     572:      	leaq	0x48(%r14), %r12
     576:      	leaq	0x40(%rsp), %rdi
     57b:      	movl	$0x8, %ecx
     580:      	movl	$0x4, %eax
     585:      	movl	$0x8, %esi
     58a:      	movq	%r15, %rdx
     58d:      	callq	*%rax
     58f:      	movq	0x40(%rsp), %r15
     594:      	leaq	0x50(%r14), %rdi
     598:      	leaq	0x40(%r15), %rdx
     59c:      	movl	$0x8, %ecx
     5a1:      	movl	$0x4, %eax
     5a6:      	movl	$0x8, %esi
     5ab:      	callq	*%rax
     5ad:      	movq	%r14, %rdi
     5b0:      	addq	$0x58, %rdi
     5b4:      	leaq	0x30(%r15), %rdx
     5b8:      	movl	$0x8, %ecx
     5bd:      	movl	$0x4, %eax
     5c2:      	movl	$0x8, %esi
     5c7:      	callq	*%rax
     5c9:      	addq	$0x38, %r15
     5cd:      	movl	$0x8, %ecx
     5d2:      	movl	$0x4, %eax
     5d7:      	movq	%r12, %rdi
     5da:      	movl	$0x8, %esi
     5df:      	movq	%r15, %rdx
     5e2:      	callq	*%rax
     5e4:      	movb	$0x0, 0x5f08(%r14)
     5ec:      	movb	$0x0, 0x1(%r14)
     5f1:      	movq	$0x0, 0x5ee8(%r14)
     5fc:      	movq	$0x0, 0x5ef0(%r14)
     607:      	movq	(%rip), %rsi            # 0x60e <generic_fentry_event+0x60e>
     60e:      	movl	$0x2, %ecx
     613:      	movl	$0xc, %eax
     618:      	movq	%rbx, %rdi
     61b:      	movl	$0x2, %edx
     620:      	callq	*%rax
     622:      	xorl	%eax, %eax
     624:      	addq	$0x88, %rsp
     62b:      	popq	%rbx
     62c:      	popq	%r12
     62e:      	popq	%r13
     630:      	popq	%r14
     632:      	popq	%r15
     634:      	popq	%rbp
     635:      	retq
     636:      	movq	$-0x1, 0x18(%rsp)
     63f:      	leaq	0x18(%rsp), %rsi
     644:      	movl	$0x1, %eax
     649:      	movq	%r15, %rdi
     64c:      	callq	*%rax
     64e:      	testq	%rax, %rax
     651:      	je	0x622 <generic_fentry_event+0x622>
     653:      	movl	$0x1, 0x14(%rsp)
     65b:      	movq	(%rip), %rdi            # 0x662 <generic_fentry_event+0x662>
     662:      	leaq	0x14(%rsp), %rsi
     667:      	movl	$0x1, %eax
     66c:      	callq	*%rax
     66e:      	testq	%rax, %rax
     671:      	je	0x622 <generic_fentry_event+0x622>
     673:      	movq	%rax, %rdi
     676:      	leaq	0x8(%rsp), %rsi
     67b:      	movl	$0x1, %eax
     680:      	callq	*%rax
     682:      	testq	%rax, %rax
     685:      	movq	%r12, %rax
     688:      	jne	0x622 <generic_fentry_event+0x622>
     68a:      	jmp	0x23b <generic_fentry_event+0x23b>
