
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_generic_fexit_v61.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <filter_64ty>:
       0:      	pushq	%rax
       1:      	movl	0x4(%rdi), %ecx
       4:      	xorl	%eax, %eax
       6:      	cmpq	$0x20, %rcx
       a:      	ja	0x45 <filter_64ty+0x45>
       c:      	movl	$0x101e, %edx           # imm = 0x101E
      11:      	btq	%rcx, %rdx
      15:      	jae	0x1e <filter_64ty+0x1e>
      17:      	callq	0x140 <filter_64ty_selector_val>
      1c:      	popq	%rcx
      1d:      	retq
      1e:      	movl	$0xc00, %edx            # imm = 0xC00
      23:      	btq	%rcx, %rdx
      27:      	jb	0x40 <filter_64ty+0x40>
      29:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
      33:      	btq	%rcx, %rdx
      37:      	jae	0x45 <filter_64ty+0x45>
      39:      	callq	0x400 <filter_64ty_range>
      3e:      	popq	%rcx
      3f:      	retq
      40:      	callq	0x380 <filter_64ty_map>
      45:      	popq	%rcx
      46:      	retq
      47:      	nopw	(%rax,%rax)

0000000000000050 <filter_32ty>:
      50:      	pushq	%rax
      51:      	movl	0x4(%rdi), %ecx
      54:      	xorl	%eax, %eax
      56:      	cmpq	$0x20, %rcx
      5a:      	ja	0x95 <filter_32ty+0x45>
      5c:      	movl	$0x101e, %edx           # imm = 0x101E
      61:      	btq	%rcx, %rdx
      65:      	jae	0x6e <filter_32ty+0x1e>
      67:      	callq	0x5e0 <filter_32ty_selector_val>
      6c:      	popq	%rcx
      6d:      	retq
      6e:      	movl	$0xc00, %edx            # imm = 0xC00
      73:      	btq	%rcx, %rdx
      77:      	jb	0x90 <filter_32ty+0x40>
      79:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
      83:      	btq	%rcx, %rdx
      87:      	jae	0x95 <filter_32ty+0x45>
      89:      	callq	0x890 <filter_32ty_range>
      8e:      	popq	%rcx
      8f:      	retq
      90:      	callq	0x800 <filter_32ty_map>
      95:      	popq	%rcx
      96:      	retq
      97:      	nopw	(%rax,%rax)

00000000000000a0 <filter_16ty>:
      a0:      	pushq	%rax
      a1:      	movl	0x4(%rdi), %ecx
      a4:      	xorl	%eax, %eax
      a6:      	cmpq	$0x20, %rcx
      aa:      	ja	0xe5 <filter_16ty+0x45>
      ac:      	movl	$0x101e, %edx           # imm = 0x101E
      b1:      	btq	%rcx, %rdx
      b5:      	jae	0xbe <filter_16ty+0x1e>
      b7:      	callq	0xa50 <filter_16ty_selector_val>
      bc:      	popq	%rcx
      bd:      	retq
      be:      	movl	$0xc00, %edx            # imm = 0xC00
      c3:      	btq	%rcx, %rdx
      c7:      	jb	0xe0 <filter_16ty+0x40>
      c9:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
      d3:      	btq	%rcx, %rdx
      d7:      	jae	0xe5 <filter_16ty+0x45>
      d9:      	callq	0xd00 <filter_16ty_range>
      de:      	popq	%rcx
      df:      	retq
      e0:      	callq	0xc70 <filter_16ty_map>
      e5:      	popq	%rcx
      e6:      	retq
      e7:      	nopw	(%rax,%rax)

00000000000000f0 <filter_8ty>:
      f0:      	pushq	%rax
      f1:      	movl	0x4(%rdi), %ecx
      f4:      	xorl	%eax, %eax
      f6:      	cmpq	$0x20, %rcx
      fa:      	ja	0x135 <filter_8ty+0x45>
      fc:      	movl	$0x101e, %edx           # imm = 0x101E
     101:      	btq	%rcx, %rdx
     105:      	jae	0x10e <filter_8ty+0x1e>
     107:      	callq	0xec0 <filter_8ty_selector_val>
     10c:      	popq	%rcx
     10d:      	retq
     10e:      	movl	$0xc00, %edx            # imm = 0xC00
     113:      	btq	%rcx, %rdx
     117:      	jb	0x130 <filter_8ty+0x40>
     119:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     123:      	btq	%rcx, %rdx
     127:      	jae	0x135 <filter_8ty+0x45>
     129:      	callq	0x1170 <filter_8ty_range>
     12e:      	popq	%rcx
     12f:      	retq
     130:      	callq	0x10e0 <filter_8ty_map>
     135:      	popq	%rcx
     136:      	retq
     137:      	nopw	(%rax,%rax)

0000000000000140 <filter_64ty_selector_val>:
     140:      	movl	0x4(%rdi), %ecx
     143:      	movl	$0x1, %eax
     148:      	cmpq	$0x25, %rcx
     14c:      	ja	0x1c4 <filter_64ty_selector_val+0x84>
     14e:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     158:      	btq	%rcx, %rdx
     15c:      	jae	0x15f <filter_64ty_selector_val+0x1f>
     15e:      	retq
     15f:      	movl	$0x18, %edx
     164:      	btq	%rcx, %rdx
     168:      	jae	0x180 <filter_64ty_selector_val+0x40>
     16a:      	movq	(%rsi), %rdx
     16d:      	cmpq	0x10(%rdi), %rdx
     171:      	jne	0x2a2 <filter_64ty_selector_val+0x162>
     177:      	xorl	%eax, %eax
     179:      	cmpl	$0x3, %ecx
     17c:      	sete	%al
     17f:      	retq
     180:      	cmpq	$0xc, %rcx
     184:      	jne	0x1c4 <filter_64ty_selector_val+0x84>
     186:      	movq	(%rsi), %rcx
     189:      	testq	%rcx, 0x10(%rdi)
     18d:      	jne	0x15e <filter_64ty_selector_val+0x1e>
     18f:      	movl	0x8(%rdi), %edx
     192:      	cmpl	$0x11, %edx
     195:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     19b:      	testq	%rcx, 0x18(%rdi)
     19f:      	jne	0x15e <filter_64ty_selector_val+0x1e>
     1a1:      	cmpl	$0x19, %edx
     1a4:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     1aa:      	testq	%rcx, 0x20(%rdi)
     1ae:      	jne	0x15e <filter_64ty_selector_val+0x1e>
     1b0:      	cmpl	$0x21, %edx
     1b3:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     1b9:      	testq	%rcx, 0x28(%rdi)
     1bd:      	jne	0x15e <filter_64ty_selector_val+0x1e>
     1bf:      	jmp	0x36f <filter_64ty_selector_val+0x22f>
     1c4:      	cmpl	$0x1, %ecx
     1c7:      	je	0x23a <filter_64ty_selector_val+0xfa>
     1c9:      	cmpl	$0x2, %ecx
     1cc:      	jne	0x36f <filter_64ty_selector_val+0x22f>
     1d2:      	movl	0xc(%rdi), %ecx
     1d5:      	cmpl	$0xc, %ecx
     1d8:      	ja	0x332 <filter_64ty_selector_val+0x1f2>
     1de:      	movl	$0x1402, %edx           # imm = 0x1402
     1e3:      	btl	%ecx, %edx
     1e6:      	jae	0x332 <filter_64ty_selector_val+0x1f2>
     1ec:      	movq	(%rsi), %rcx
     1ef:      	cmpq	0x10(%rdi), %rcx
     1f3:      	jl	0x15e <filter_64ty_selector_val+0x1e>
     1f9:      	movl	0x8(%rdi), %edx
     1fc:      	cmpl	$0x11, %edx
     1ff:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     205:      	cmpq	0x18(%rdi), %rcx
     209:      	jl	0x15e <filter_64ty_selector_val+0x1e>
     20f:      	cmpl	$0x19, %edx
     212:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     218:      	cmpq	0x20(%rdi), %rcx
     21c:      	jl	0x15e <filter_64ty_selector_val+0x1e>
     222:      	cmpl	$0x21, %edx
     225:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     22b:      	cmpq	0x28(%rdi), %rcx
     22f:      	jl	0x15e <filter_64ty_selector_val+0x1e>
     235:      	jmp	0x36f <filter_64ty_selector_val+0x22f>
     23a:      	movl	0xc(%rdi), %ecx
     23d:      	cmpl	$0xc, %ecx
     240:      	ja	0x2f3 <filter_64ty_selector_val+0x1b3>
     246:      	movl	$0x1402, %edx           # imm = 0x1402
     24b:      	btl	%ecx, %edx
     24e:      	jae	0x2f3 <filter_64ty_selector_val+0x1b3>
     254:      	movq	(%rsi), %rcx
     257:      	cmpq	0x10(%rdi), %rcx
     25b:      	jg	0x15e <filter_64ty_selector_val+0x1e>
     261:      	movl	0x8(%rdi), %edx
     264:      	cmpl	$0x11, %edx
     267:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     26d:      	cmpq	0x18(%rdi), %rcx
     271:      	jg	0x15e <filter_64ty_selector_val+0x1e>
     277:      	cmpl	$0x19, %edx
     27a:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     280:      	cmpq	0x20(%rdi), %rcx
     284:      	jg	0x15e <filter_64ty_selector_val+0x1e>
     28a:      	cmpl	$0x21, %edx
     28d:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     293:      	cmpq	0x28(%rdi), %rcx
     297:      	jg	0x15e <filter_64ty_selector_val+0x1e>
     29d:      	jmp	0x36f <filter_64ty_selector_val+0x22f>
     2a2:      	movl	0x8(%rdi), %esi
     2a5:      	cmpl	$0x11, %esi
     2a8:      	jb	0x2d2 <filter_64ty_selector_val+0x192>
     2aa:      	cmpq	0x18(%rdi), %rdx
     2ae:      	je	0x177 <filter_64ty_selector_val+0x37>
     2b4:      	cmpl	$0x19, %esi
     2b7:      	jb	0x2d2 <filter_64ty_selector_val+0x192>
     2b9:      	cmpq	0x20(%rdi), %rdx
     2bd:      	je	0x177 <filter_64ty_selector_val+0x37>
     2c3:      	cmpl	$0x21, %esi
     2c6:      	jb	0x2d2 <filter_64ty_selector_val+0x192>
     2c8:      	cmpq	0x28(%rdi), %rdx
     2cc:      	je	0x177 <filter_64ty_selector_val+0x37>
     2d2:      	cmpl	$0x25, %ecx
     2d5:      	ja	0x36f <filter_64ty_selector_val+0x22f>
     2db:      	movl	%ecx, %ecx
     2dd:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     2e7:      	btq	%rcx, %rdx
     2eb:      	jb	0x15e <filter_64ty_selector_val+0x1e>
     2f1:      	jmp	0x36f <filter_64ty_selector_val+0x22f>
     2f3:      	movq	(%rsi), %rcx
     2f6:      	cmpq	0x10(%rdi), %rcx
     2fa:      	ja	0x15e <filter_64ty_selector_val+0x1e>
     300:      	movl	0x8(%rdi), %edx
     303:      	cmpl	$0x11, %edx
     306:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     308:      	cmpq	0x18(%rdi), %rcx
     30c:      	ja	0x15e <filter_64ty_selector_val+0x1e>
     312:      	cmpl	$0x19, %edx
     315:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     317:      	cmpq	0x20(%rdi), %rcx
     31b:      	ja	0x15e <filter_64ty_selector_val+0x1e>
     321:      	cmpl	$0x21, %edx
     324:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     326:      	cmpq	0x28(%rdi), %rcx
     32a:      	ja	0x15e <filter_64ty_selector_val+0x1e>
     330:      	jmp	0x36f <filter_64ty_selector_val+0x22f>
     332:      	movq	(%rsi), %rcx
     335:      	cmpq	0x10(%rdi), %rcx
     339:      	jb	0x15e <filter_64ty_selector_val+0x1e>
     33f:      	movl	0x8(%rdi), %edx
     342:      	cmpl	$0x11, %edx
     345:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     347:      	cmpq	0x18(%rdi), %rcx
     34b:      	jb	0x15e <filter_64ty_selector_val+0x1e>
     351:      	cmpl	$0x19, %edx
     354:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     356:      	cmpq	0x20(%rdi), %rcx
     35a:      	jb	0x15e <filter_64ty_selector_val+0x1e>
     360:      	cmpl	$0x21, %edx
     363:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     365:      	cmpq	0x28(%rdi), %rcx
     369:      	jb	0x15e <filter_64ty_selector_val+0x1e>
     36f:      	xorl	%eax, %eax
     371:      	retq
     372:      	nopw	%cs:(%rax,%rax)

0000000000000380 <filter_64ty_map>:
     380:      	pushq	%r14
     382:      	pushq	%rbx
     383:      	subq	$0x18, %rsp
     387:      	movq	%rsi, %r14
     38a:      	movq	%rdi, %rbx
     38d:      	movzbl	0x10(%rdi), %eax
     391:      	movl	%eax, 0xc(%rsp)
     395:      	movq	(%rip), %rdi            # 0x39c <filter_64ty_map+0x1c>
     39c:      	leaq	0xc(%rsp), %rsi
     3a1:      	movl	$0x1, %eax
     3a6:      	callq	*%rax
     3a8:      	testq	%rax, %rax
     3ab:      	je	0x3d9 <filter_64ty_map+0x59>
     3ad:      	movq	%rax, %rdi
     3b0:      	movq	(%r14), %rax
     3b3:      	movq	%rax, 0x10(%rsp)
     3b8:      	leaq	0x10(%rsp), %rsi
     3bd:      	movl	$0x1, %eax
     3c2:      	callq	*%rax
     3c4:      	movl	0x4(%rbx), %ecx
     3c7:      	cmpl	$0xb, %ecx
     3ca:      	je	0x3e3 <filter_64ty_map+0x63>
     3cc:      	cmpl	$0xa, %ecx
     3cf:      	jne	0x3eb <filter_64ty_map+0x6b>
     3d1:      	testq	%rax, %rax
     3d4:      	setne	%al
     3d7:      	jmp	0x3ed <filter_64ty_map+0x6d>
     3d9:      	xorl	%eax, %eax
     3db:      	addq	$0x18, %rsp
     3df:      	popq	%rbx
     3e0:      	popq	%r14
     3e2:      	retq
     3e3:      	testq	%rax, %rax
     3e6:      	sete	%al
     3e9:      	jmp	0x3ed <filter_64ty_map+0x6d>
     3eb:      	xorl	%eax, %eax
     3ed:      	movzbl	%al, %eax
     3f0:      	addq	$0x18, %rsp
     3f4:      	popq	%rbx
     3f5:      	popq	%r14
     3f7:      	retq
     3f8:      	nopl	(%rax,%rax)

0000000000000400 <filter_64ty_range>:
     400:      	movl	0x4(%rdi), %ecx
     403:      	movl	0xc(%rdi), %eax
     406:      	cmpl	$0xc, %eax
     409:      	ja	0x500 <filter_64ty_range+0x100>
     40f:      	movl	$0x1402, %edx           # imm = 0x1402
     414:      	btl	%eax, %edx
     417:      	jae	0x500 <filter_64ty_range+0x100>
     41d:      	movq	(%rsi), %rsi
     420:      	cmpl	$0x1f, %ecx
     423:      	jne	0x493 <filter_64ty_range+0x93>
     425:      	movl	$0x1, %eax
     42a:      	cmpq	%rsi, 0x10(%rdi)
     42e:      	jg	0x43a <filter_64ty_range+0x3a>
     430:      	cmpq	0x18(%rdi), %rsi
     434:      	jle	0x519 <filter_64ty_range+0x119>
     43a:      	movl	0x8(%rdi), %edx
     43d:      	cmpl	$0x19, %edx
     440:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     446:      	cmpq	%rsi, 0x20(%rdi)
     44a:      	jg	0x456 <filter_64ty_range+0x56>
     44c:      	cmpq	0x28(%rdi), %rsi
     450:      	jle	0x519 <filter_64ty_range+0x119>
     456:      	cmpl	$0x29, %edx
     459:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     45f:      	cmpq	%rsi, 0x30(%rdi)
     463:      	jg	0x46f <filter_64ty_range+0x6f>
     465:      	cmpq	0x38(%rdi), %rsi
     469:      	jle	0x519 <filter_64ty_range+0x119>
     46f:      	cmpl	$0x39, %edx
     472:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     478:      	xorl	%edx, %edx
     47a:      	cmpq	%rsi, 0x40(%rdi)
     47e:      	jg	0x5c9 <filter_64ty_range+0x1c9>
     484:      	cmpq	0x48(%rdi), %rsi
     488:      	jle	0x519 <filter_64ty_range+0x119>
     48e:      	jmp	0x5c9 <filter_64ty_range+0x1c9>
     493:      	movl	0x8(%rdi), %eax
     496:      	cmpq	%rsi, 0x10(%rdi)
     49a:      	setle	%r8b
     49e:      	cmpq	0x18(%rdi), %rsi
     4a2:      	setle	%dl
     4a5:      	andb	%r8b, %dl
     4a8:      	cmpl	$0x19, %eax
     4ab:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     4b1:      	cmpq	%rsi, 0x20(%rdi)
     4b5:      	setle	%r8b
     4b9:      	cmpq	0x28(%rdi), %rsi
     4bd:      	setle	%r9b
     4c1:      	andb	%r8b, %r9b
     4c4:      	orb	%r9b, %dl
     4c7:      	cmpl	$0x29, %eax
     4ca:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     4d0:      	cmpq	%rsi, 0x30(%rdi)
     4d4:      	setle	%r8b
     4d8:      	cmpq	0x38(%rdi), %rsi
     4dc:      	setle	%r9b
     4e0:      	andb	%r8b, %r9b
     4e3:      	orb	%r9b, %dl
     4e6:      	cmpl	$0x39, %eax
     4e9:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     4ef:      	cmpq	%rsi, 0x40(%rdi)
     4f3:      	setle	%al
     4f6:      	cmpq	0x48(%rdi), %rsi
     4fa:      	setle	%sil
     4fe:      	jmp	0x57d <filter_64ty_range+0x17d>
     500:      	movq	(%rsi), %rsi
     503:      	cmpl	$0x1f, %ecx
     506:      	jne	0x51a <filter_64ty_range+0x11a>
     508:      	movl	$0x1, %eax
     50d:      	cmpq	%rsi, 0x10(%rdi)
     511:      	ja	0x585 <filter_64ty_range+0x185>
     513:      	cmpq	0x18(%rdi), %rsi
     517:      	ja	0x585 <filter_64ty_range+0x185>
     519:      	retq
     51a:      	movl	0x8(%rdi), %eax
     51d:      	cmpq	%rsi, 0x10(%rdi)
     521:      	setbe	%r8b
     525:      	cmpq	0x18(%rdi), %rsi
     529:      	setbe	%dl
     52c:      	andb	%r8b, %dl
     52f:      	cmpl	$0x19, %eax
     532:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     538:      	cmpq	%rsi, 0x20(%rdi)
     53c:      	setbe	%r8b
     540:      	cmpq	0x28(%rdi), %rsi
     544:      	setbe	%r9b
     548:      	andb	%r8b, %r9b
     54b:      	orb	%r9b, %dl
     54e:      	cmpl	$0x29, %eax
     551:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     553:      	cmpq	%rsi, 0x30(%rdi)
     557:      	setbe	%r8b
     55b:      	cmpq	0x38(%rdi), %rsi
     55f:      	setbe	%r9b
     563:      	andb	%r8b, %r9b
     566:      	orb	%r9b, %dl
     569:      	cmpl	$0x39, %eax
     56c:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     56e:      	cmpq	%rsi, 0x40(%rdi)
     572:      	setbe	%al
     575:      	cmpq	0x48(%rdi), %rsi
     579:      	setbe	%sil
     57d:      	andb	%al, %sil
     580:      	orb	%sil, %dl
     583:      	jmp	0x5c9 <filter_64ty_range+0x1c9>
     585:      	movl	0x8(%rdi), %edx
     588:      	cmpl	$0x19, %edx
     58b:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     58d:      	cmpq	%rsi, 0x20(%rdi)
     591:      	ja	0x599 <filter_64ty_range+0x199>
     593:      	cmpq	0x28(%rdi), %rsi
     597:      	jbe	0x519 <filter_64ty_range+0x119>
     599:      	cmpl	$0x29, %edx
     59c:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     59e:      	cmpq	%rsi, 0x30(%rdi)
     5a2:      	ja	0x5ae <filter_64ty_range+0x1ae>
     5a4:      	cmpq	0x38(%rdi), %rsi
     5a8:      	jbe	0x519 <filter_64ty_range+0x119>
     5ae:      	cmpl	$0x39, %edx
     5b1:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     5b3:      	xorl	%edx, %edx
     5b5:      	cmpq	%rsi, 0x40(%rdi)
     5b9:      	ja	0x5c9 <filter_64ty_range+0x1c9>
     5bb:      	cmpq	0x48(%rdi), %rsi
     5bf:      	jbe	0x519 <filter_64ty_range+0x119>
     5c5:      	jmp	0x5c9 <filter_64ty_range+0x1c9>
     5c7:      	xorl	%edx, %edx
     5c9:      	cmpl	$0x20, %ecx
     5cc:      	sete	%al
     5cf:      	xorb	$0x1, %dl
     5d2:      	andb	%al, %dl
     5d4:      	movzbl	%dl, %eax
     5d7:      	retq
     5d8:      	nopl	(%rax,%rax)

00000000000005e0 <filter_32ty_selector_val>:
     5e0:      	movl	0x4(%rdi), %ecx
     5e3:      	movl	$0x1, %eax
     5e8:      	cmpq	$0x25, %rcx
     5ec:      	ja	0x65d <filter_32ty_selector_val+0x7d>
     5ee:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     5f8:      	btq	%rcx, %rdx
     5fc:      	jae	0x5ff <filter_32ty_selector_val+0x1f>
     5fe:      	retq
     5ff:      	movl	$0x18, %edx
     604:      	btq	%rcx, %rdx
     608:      	jae	0x61e <filter_32ty_selector_val+0x3e>
     60a:      	movl	(%rsi), %edx
     60c:      	cmpl	0x10(%rdi), %edx
     60f:      	jne	0x731 <filter_32ty_selector_val+0x151>
     615:      	xorl	%eax, %eax
     617:      	cmpl	$0x3, %ecx
     61a:      	sete	%al
     61d:      	retq
     61e:      	cmpq	$0xc, %rcx
     622:      	jne	0x65d <filter_32ty_selector_val+0x7d>
     624:      	movl	(%rsi), %ecx
     626:      	testl	%ecx, 0x10(%rdi)
     629:      	jne	0x5fe <filter_32ty_selector_val+0x1e>
     62b:      	movl	0x8(%rdi), %edx
     62e:      	cmpl	$0xd, %edx
     631:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     637:      	testl	%ecx, 0x14(%rdi)
     63a:      	jne	0x5fe <filter_32ty_selector_val+0x1e>
     63c:      	cmpl	$0x11, %edx
     63f:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     645:      	testl	%ecx, 0x18(%rdi)
     648:      	jne	0x5fe <filter_32ty_selector_val+0x1e>
     64a:      	cmpl	$0x15, %edx
     64d:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     653:      	testl	%ecx, 0x1c(%rdi)
     656:      	jne	0x5fe <filter_32ty_selector_val+0x1e>
     658:      	jmp	0x7f1 <filter_32ty_selector_val+0x211>
     65d:      	cmpl	$0x1, %ecx
     660:      	je	0x6ce <filter_32ty_selector_val+0xee>
     662:      	cmpl	$0x2, %ecx
     665:      	jne	0x7f1 <filter_32ty_selector_val+0x211>
     66b:      	movl	0xc(%rdi), %ecx
     66e:      	cmpl	$0xc, %ecx
     671:      	ja	0x7b9 <filter_32ty_selector_val+0x1d9>
     677:      	movl	$0x1402, %edx           # imm = 0x1402
     67c:      	btl	%ecx, %edx
     67f:      	jae	0x7b9 <filter_32ty_selector_val+0x1d9>
     685:      	movl	(%rsi), %ecx
     687:      	cmpl	0x10(%rdi), %ecx
     68a:      	jl	0x5fe <filter_32ty_selector_val+0x1e>
     690:      	movl	0x8(%rdi), %edx
     693:      	cmpl	$0xd, %edx
     696:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     69c:      	cmpl	0x14(%rdi), %ecx
     69f:      	jl	0x5fe <filter_32ty_selector_val+0x1e>
     6a5:      	cmpl	$0x11, %edx
     6a8:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     6ae:      	cmpl	0x18(%rdi), %ecx
     6b1:      	jl	0x5fe <filter_32ty_selector_val+0x1e>
     6b7:      	cmpl	$0x15, %edx
     6ba:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     6c0:      	cmpl	0x1c(%rdi), %ecx
     6c3:      	jl	0x5fe <filter_32ty_selector_val+0x1e>
     6c9:      	jmp	0x7f1 <filter_32ty_selector_val+0x211>
     6ce:      	movl	0xc(%rdi), %ecx
     6d1:      	cmpl	$0xc, %ecx
     6d4:      	ja	0x77f <filter_32ty_selector_val+0x19f>
     6da:      	movl	$0x1402, %edx           # imm = 0x1402
     6df:      	btl	%ecx, %edx
     6e2:      	jae	0x77f <filter_32ty_selector_val+0x19f>
     6e8:      	movl	(%rsi), %ecx
     6ea:      	cmpl	0x10(%rdi), %ecx
     6ed:      	jg	0x5fe <filter_32ty_selector_val+0x1e>
     6f3:      	movl	0x8(%rdi), %edx
     6f6:      	cmpl	$0xd, %edx
     6f9:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     6ff:      	cmpl	0x14(%rdi), %ecx
     702:      	jg	0x5fe <filter_32ty_selector_val+0x1e>
     708:      	cmpl	$0x11, %edx
     70b:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     711:      	cmpl	0x18(%rdi), %ecx
     714:      	jg	0x5fe <filter_32ty_selector_val+0x1e>
     71a:      	cmpl	$0x15, %edx
     71d:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     723:      	cmpl	0x1c(%rdi), %ecx
     726:      	jg	0x5fe <filter_32ty_selector_val+0x1e>
     72c:      	jmp	0x7f1 <filter_32ty_selector_val+0x211>
     731:      	movl	0x8(%rdi), %esi
     734:      	cmpl	$0xd, %esi
     737:      	jb	0x75e <filter_32ty_selector_val+0x17e>
     739:      	cmpl	0x14(%rdi), %edx
     73c:      	je	0x615 <filter_32ty_selector_val+0x35>
     742:      	cmpl	$0x11, %esi
     745:      	jb	0x75e <filter_32ty_selector_val+0x17e>
     747:      	cmpl	0x18(%rdi), %edx
     74a:      	je	0x615 <filter_32ty_selector_val+0x35>
     750:      	cmpl	$0x15, %esi
     753:      	jb	0x75e <filter_32ty_selector_val+0x17e>
     755:      	cmpl	0x1c(%rdi), %edx
     758:      	je	0x615 <filter_32ty_selector_val+0x35>
     75e:      	cmpl	$0x25, %ecx
     761:      	ja	0x7f1 <filter_32ty_selector_val+0x211>
     767:      	movl	%ecx, %ecx
     769:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     773:      	btq	%rcx, %rdx
     777:      	jb	0x5fe <filter_32ty_selector_val+0x1e>
     77d:      	jmp	0x7f1 <filter_32ty_selector_val+0x211>
     77f:      	movl	(%rsi), %ecx
     781:      	cmpl	0x10(%rdi), %ecx
     784:      	ja	0x5fe <filter_32ty_selector_val+0x1e>
     78a:      	movl	0x8(%rdi), %edx
     78d:      	cmpl	$0xd, %edx
     790:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     792:      	cmpl	0x14(%rdi), %ecx
     795:      	ja	0x5fe <filter_32ty_selector_val+0x1e>
     79b:      	cmpl	$0x11, %edx
     79e:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     7a0:      	cmpl	0x18(%rdi), %ecx
     7a3:      	ja	0x5fe <filter_32ty_selector_val+0x1e>
     7a9:      	cmpl	$0x15, %edx
     7ac:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     7ae:      	cmpl	0x1c(%rdi), %ecx
     7b1:      	ja	0x5fe <filter_32ty_selector_val+0x1e>
     7b7:      	jmp	0x7f1 <filter_32ty_selector_val+0x211>
     7b9:      	movl	(%rsi), %ecx
     7bb:      	cmpl	0x10(%rdi), %ecx
     7be:      	jb	0x5fe <filter_32ty_selector_val+0x1e>
     7c4:      	movl	0x8(%rdi), %edx
     7c7:      	cmpl	$0xd, %edx
     7ca:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     7cc:      	cmpl	0x14(%rdi), %ecx
     7cf:      	jb	0x5fe <filter_32ty_selector_val+0x1e>
     7d5:      	cmpl	$0x11, %edx
     7d8:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     7da:      	cmpl	0x18(%rdi), %ecx
     7dd:      	jb	0x5fe <filter_32ty_selector_val+0x1e>
     7e3:      	cmpl	$0x15, %edx
     7e6:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     7e8:      	cmpl	0x1c(%rdi), %ecx
     7eb:      	jb	0x5fe <filter_32ty_selector_val+0x1e>
     7f1:      	xorl	%eax, %eax
     7f3:      	retq
     7f4:      	nopw	%cs:(%rax,%rax)

0000000000000800 <filter_32ty_map>:
     800:      	pushq	%r14
     802:      	pushq	%rbx
     803:      	subq	$0x18, %rsp
     807:      	movq	%rsi, %r14
     80a:      	movq	%rdi, %rbx
     80d:      	movzbl	0x10(%rdi), %eax
     811:      	movl	%eax, 0xc(%rsp)
     815:      	movq	(%rip), %rdi            # 0x81c <filter_32ty_map+0x1c>
     81c:      	leaq	0xc(%rsp), %rsi
     821:      	movl	$0x1, %eax
     826:      	callq	*%rax
     828:      	testq	%rax, %rax
     82b:      	je	0x860 <filter_32ty_map+0x60>
     82d:      	movq	%rax, %rdi
     830:      	movl	(%r14), %eax
     833:      	movq	%rax, 0x10(%rsp)
     838:      	leaq	0x10(%rsp), %rsi
     83d:      	movl	$0x1, %eax
     842:      	callq	*%rax
     844:      	movl	0x4(%rbx), %edx
     847:      	xorl	%ecx, %ecx
     849:      	cmpl	$0x1d, %edx
     84c:      	ja	0x87a <filter_32ty_map+0x7a>
     84e:      	movl	$0x30038400, %esi       # imm = 0x30038400
     853:      	btl	%edx, %esi
     856:      	jae	0x86a <filter_32ty_map+0x6a>
     858:      	testq	%rax, %rax
     85b:      	setne	%cl
     85e:      	jmp	0x87a <filter_32ty_map+0x7a>
     860:      	xorl	%eax, %eax
     862:      	addq	$0x18, %rsp
     866:      	popq	%rbx
     867:      	popq	%r14
     869:      	retq
     86a:      	movl	$0xc0800, %esi          # imm = 0xC0800
     86f:      	btl	%edx, %esi
     872:      	jae	0x87a <filter_32ty_map+0x7a>
     874:      	testq	%rax, %rax
     877:      	sete	%cl
     87a:      	movzbl	%cl, %eax
     87d:      	addq	$0x18, %rsp
     881:      	popq	%rbx
     882:      	popq	%r14
     884:      	retq
     885:      	nopw	%cs:(%rax,%rax)

0000000000000890 <filter_32ty_range>:
     890:      	movl	0x4(%rdi), %ecx
     893:      	movl	0xc(%rdi), %eax
     896:      	cmpl	$0xc, %eax
     899:      	ja	0x97f <filter_32ty_range+0xef>
     89f:      	movl	$0x1402, %edx           # imm = 0x1402
     8a4:      	btl	%eax, %edx
     8a7:      	jae	0x97f <filter_32ty_range+0xef>
     8ad:      	movl	(%rsi), %esi
     8af:      	cmpl	$0x1f, %ecx
     8b2:      	jne	0x91a <filter_32ty_range+0x8a>
     8b4:      	movl	$0x1, %eax
     8b9:      	cmpl	%esi, 0x10(%rdi)
     8bc:      	jg	0x8c7 <filter_32ty_range+0x37>
     8be:      	cmpl	0x14(%rdi), %esi
     8c1:      	jle	0x995 <filter_32ty_range+0x105>
     8c7:      	movl	0x8(%rdi), %edx
     8ca:      	cmpl	$0x11, %edx
     8cd:      	jb	0xa35 <filter_32ty_range+0x1a5>
     8d3:      	cmpl	%esi, 0x18(%rdi)
     8d6:      	jg	0x8e1 <filter_32ty_range+0x51>
     8d8:      	cmpl	0x1c(%rdi), %esi
     8db:      	jle	0x995 <filter_32ty_range+0x105>
     8e1:      	cmpl	$0x19, %edx
     8e4:      	jb	0xa35 <filter_32ty_range+0x1a5>
     8ea:      	cmpl	%esi, 0x20(%rdi)
     8ed:      	jg	0x8f8 <filter_32ty_range+0x68>
     8ef:      	cmpl	0x24(%rdi), %esi
     8f2:      	jle	0x995 <filter_32ty_range+0x105>
     8f8:      	cmpl	$0x21, %edx
     8fb:      	jb	0xa35 <filter_32ty_range+0x1a5>
     901:      	xorl	%edx, %edx
     903:      	cmpl	%esi, 0x28(%rdi)
     906:      	jg	0xa37 <filter_32ty_range+0x1a7>
     90c:      	cmpl	0x2c(%rdi), %esi
     90f:      	jle	0x995 <filter_32ty_range+0x105>
     915:      	jmp	0xa37 <filter_32ty_range+0x1a7>
     91a:      	movl	0x8(%rdi), %eax
     91d:      	cmpl	%esi, 0x10(%rdi)
     920:      	setle	%r8b
     924:      	cmpl	0x14(%rdi), %esi
     927:      	setle	%dl
     92a:      	andb	%r8b, %dl
     92d:      	cmpl	$0x11, %eax
     930:      	jb	0xa37 <filter_32ty_range+0x1a7>
     936:      	cmpl	%esi, 0x18(%rdi)
     939:      	setle	%r8b
     93d:      	cmpl	0x1c(%rdi), %esi
     940:      	setle	%r9b
     944:      	andb	%r8b, %r9b
     947:      	orb	%r9b, %dl
     94a:      	cmpl	$0x19, %eax
     94d:      	jb	0xa37 <filter_32ty_range+0x1a7>
     953:      	cmpl	%esi, 0x20(%rdi)
     956:      	setle	%r8b
     95a:      	cmpl	0x24(%rdi), %esi
     95d:      	setle	%r9b
     961:      	andb	%r8b, %r9b
     964:      	orb	%r9b, %dl
     967:      	cmpl	$0x21, %eax
     96a:      	jb	0xa37 <filter_32ty_range+0x1a7>
     970:      	cmpl	%esi, 0x28(%rdi)
     973:      	setle	%al
     976:      	cmpl	0x2c(%rdi), %esi
     979:      	setle	%sil
     97d:      	jmp	0x9f1 <filter_32ty_range+0x161>
     97f:      	movl	(%rsi), %esi
     981:      	cmpl	$0x1f, %ecx
     984:      	jne	0x996 <filter_32ty_range+0x106>
     986:      	movl	$0x1, %eax
     98b:      	cmpl	%esi, 0x10(%rdi)
     98e:      	ja	0x9f9 <filter_32ty_range+0x169>
     990:      	cmpl	0x14(%rdi), %esi
     993:      	ja	0x9f9 <filter_32ty_range+0x169>
     995:      	retq
     996:      	movl	0x8(%rdi), %eax
     999:      	cmpl	%esi, 0x10(%rdi)
     99c:      	setbe	%r8b
     9a0:      	cmpl	0x14(%rdi), %esi
     9a3:      	setbe	%dl
     9a6:      	andb	%r8b, %dl
     9a9:      	cmpl	$0x11, %eax
     9ac:      	jb	0xa37 <filter_32ty_range+0x1a7>
     9b2:      	cmpl	%esi, 0x18(%rdi)
     9b5:      	setbe	%r8b
     9b9:      	cmpl	0x1c(%rdi), %esi
     9bc:      	setbe	%r9b
     9c0:      	andb	%r8b, %r9b
     9c3:      	orb	%r9b, %dl
     9c6:      	cmpl	$0x19, %eax
     9c9:      	jb	0xa37 <filter_32ty_range+0x1a7>
     9cb:      	cmpl	%esi, 0x20(%rdi)
     9ce:      	setbe	%r8b
     9d2:      	cmpl	0x24(%rdi), %esi
     9d5:      	setbe	%r9b
     9d9:      	andb	%r8b, %r9b
     9dc:      	orb	%r9b, %dl
     9df:      	cmpl	$0x21, %eax
     9e2:      	jb	0xa37 <filter_32ty_range+0x1a7>
     9e4:      	cmpl	%esi, 0x28(%rdi)
     9e7:      	setbe	%al
     9ea:      	cmpl	0x2c(%rdi), %esi
     9ed:      	setbe	%sil
     9f1:      	andb	%al, %sil
     9f4:      	orb	%sil, %dl
     9f7:      	jmp	0xa37 <filter_32ty_range+0x1a7>
     9f9:      	movl	0x8(%rdi), %edx
     9fc:      	cmpl	$0x11, %edx
     9ff:      	jb	0xa35 <filter_32ty_range+0x1a5>
     a01:      	cmpl	%esi, 0x18(%rdi)
     a04:      	ja	0xa0b <filter_32ty_range+0x17b>
     a06:      	cmpl	0x1c(%rdi), %esi
     a09:      	jbe	0x995 <filter_32ty_range+0x105>
     a0b:      	cmpl	$0x19, %edx
     a0e:      	jb	0xa35 <filter_32ty_range+0x1a5>
     a10:      	cmpl	%esi, 0x20(%rdi)
     a13:      	ja	0xa1e <filter_32ty_range+0x18e>
     a15:      	cmpl	0x24(%rdi), %esi
     a18:      	jbe	0x995 <filter_32ty_range+0x105>
     a1e:      	cmpl	$0x21, %edx
     a21:      	jb	0xa35 <filter_32ty_range+0x1a5>
     a23:      	xorl	%edx, %edx
     a25:      	cmpl	%esi, 0x28(%rdi)
     a28:      	ja	0xa37 <filter_32ty_range+0x1a7>
     a2a:      	cmpl	0x2c(%rdi), %esi
     a2d:      	jbe	0x995 <filter_32ty_range+0x105>
     a33:      	jmp	0xa37 <filter_32ty_range+0x1a7>
     a35:      	xorl	%edx, %edx
     a37:      	cmpl	$0x20, %ecx
     a3a:      	sete	%al
     a3d:      	xorb	$0x1, %dl
     a40:      	andb	%al, %dl
     a42:      	movzbl	%dl, %eax
     a45:      	retq
     a46:      	nopw	%cs:(%rax,%rax)

0000000000000a50 <filter_16ty_selector_val>:
     a50:      	movl	0x4(%rdi), %ecx
     a53:      	movl	$0x1, %eax
     a58:      	cmpq	$0x25, %rcx
     a5c:      	ja	0xacf <filter_16ty_selector_val+0x7f>
     a5e:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     a68:      	btq	%rcx, %rdx
     a6c:      	jae	0xa6f <filter_16ty_selector_val+0x1f>
     a6e:      	retq
     a6f:      	movl	$0x18, %edx
     a74:      	btq	%rcx, %rdx
     a78:      	jae	0xa8f <filter_16ty_selector_val+0x3f>
     a7a:      	movzwl	(%rsi), %edx
     a7d:      	cmpl	%edx, 0x10(%rdi)
     a80:      	jne	0xba5 <filter_16ty_selector_val+0x155>
     a86:      	xorl	%eax, %eax
     a88:      	cmpl	$0x3, %ecx
     a8b:      	sete	%al
     a8e:      	retq
     a8f:      	cmpq	$0xc, %rcx
     a93:      	jne	0xacf <filter_16ty_selector_val+0x7f>
     a95:      	movzwl	(%rsi), %ecx
     a98:      	testl	%ecx, 0x10(%rdi)
     a9b:      	jne	0xa6e <filter_16ty_selector_val+0x1e>
     a9d:      	movl	0x8(%rdi), %edx
     aa0:      	cmpl	$0xd, %edx
     aa3:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     aa9:      	testl	%ecx, 0x14(%rdi)
     aac:      	jne	0xa6e <filter_16ty_selector_val+0x1e>
     aae:      	cmpl	$0x11, %edx
     ab1:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     ab7:      	testl	%ecx, 0x18(%rdi)
     aba:      	jne	0xa6e <filter_16ty_selector_val+0x1e>
     abc:      	cmpl	$0x15, %edx
     abf:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     ac5:      	testl	%ecx, 0x1c(%rdi)
     ac8:      	jne	0xa6e <filter_16ty_selector_val+0x1e>
     aca:      	jmp	0xc67 <filter_16ty_selector_val+0x217>
     acf:      	cmpl	$0x1, %ecx
     ad2:      	je	0xb41 <filter_16ty_selector_val+0xf1>
     ad4:      	cmpl	$0x2, %ecx
     ad7:      	jne	0xc67 <filter_16ty_selector_val+0x217>
     add:      	movl	0xc(%rdi), %ecx
     ae0:      	cmpl	$0xc, %ecx
     ae3:      	ja	0xc2e <filter_16ty_selector_val+0x1de>
     ae9:      	movl	$0x1402, %edx           # imm = 0x1402
     aee:      	btl	%ecx, %edx
     af1:      	jae	0xc2e <filter_16ty_selector_val+0x1de>
     af7:      	movswl	(%rsi), %ecx
     afa:      	cmpl	%ecx, 0x10(%rdi)
     afd:      	jg	0xa6e <filter_16ty_selector_val+0x1e>
     b03:      	movl	0x8(%rdi), %edx
     b06:      	cmpl	$0xd, %edx
     b09:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b0f:      	cmpl	%ecx, 0x14(%rdi)
     b12:      	jg	0xa6e <filter_16ty_selector_val+0x1e>
     b18:      	cmpl	$0x11, %edx
     b1b:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b21:      	cmpl	%ecx, 0x18(%rdi)
     b24:      	jg	0xa6e <filter_16ty_selector_val+0x1e>
     b2a:      	cmpl	$0x15, %edx
     b2d:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b33:      	cmpl	%ecx, 0x1c(%rdi)
     b36:      	jg	0xa6e <filter_16ty_selector_val+0x1e>
     b3c:      	jmp	0xc67 <filter_16ty_selector_val+0x217>
     b41:      	movl	0xc(%rdi), %ecx
     b44:      	cmpl	$0xc, %ecx
     b47:      	ja	0xbf3 <filter_16ty_selector_val+0x1a3>
     b4d:      	movl	$0x1402, %edx           # imm = 0x1402
     b52:      	btl	%ecx, %edx
     b55:      	jae	0xbf3 <filter_16ty_selector_val+0x1a3>
     b5b:      	movswl	(%rsi), %ecx
     b5e:      	cmpl	%ecx, 0x10(%rdi)
     b61:      	jl	0xa6e <filter_16ty_selector_val+0x1e>
     b67:      	movl	0x8(%rdi), %edx
     b6a:      	cmpl	$0xd, %edx
     b6d:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b73:      	cmpl	%ecx, 0x14(%rdi)
     b76:      	jl	0xa6e <filter_16ty_selector_val+0x1e>
     b7c:      	cmpl	$0x11, %edx
     b7f:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b85:      	cmpl	%ecx, 0x18(%rdi)
     b88:      	jl	0xa6e <filter_16ty_selector_val+0x1e>
     b8e:      	cmpl	$0x15, %edx
     b91:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b97:      	cmpl	%ecx, 0x1c(%rdi)
     b9a:      	jl	0xa6e <filter_16ty_selector_val+0x1e>
     ba0:      	jmp	0xc67 <filter_16ty_selector_val+0x217>
     ba5:      	movl	0x8(%rdi), %esi
     ba8:      	cmpl	$0xd, %esi
     bab:      	jb	0xbd2 <filter_16ty_selector_val+0x182>
     bad:      	cmpl	%edx, 0x14(%rdi)
     bb0:      	je	0xa86 <filter_16ty_selector_val+0x36>
     bb6:      	cmpl	$0x11, %esi
     bb9:      	jb	0xbd2 <filter_16ty_selector_val+0x182>
     bbb:      	cmpl	%edx, 0x18(%rdi)
     bbe:      	je	0xa86 <filter_16ty_selector_val+0x36>
     bc4:      	cmpl	$0x15, %esi
     bc7:      	jb	0xbd2 <filter_16ty_selector_val+0x182>
     bc9:      	cmpl	%edx, 0x1c(%rdi)
     bcc:      	je	0xa86 <filter_16ty_selector_val+0x36>
     bd2:      	cmpl	$0x25, %ecx
     bd5:      	ja	0xc67 <filter_16ty_selector_val+0x217>
     bdb:      	movl	%ecx, %ecx
     bdd:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     be7:      	btq	%rcx, %rdx
     beb:      	jb	0xa6e <filter_16ty_selector_val+0x1e>
     bf1:      	jmp	0xc67 <filter_16ty_selector_val+0x217>
     bf3:      	movzwl	(%rsi), %ecx
     bf6:      	cmpl	%ecx, 0x10(%rdi)
     bf9:      	jb	0xa6e <filter_16ty_selector_val+0x1e>
     bff:      	movl	0x8(%rdi), %edx
     c02:      	cmpl	$0xd, %edx
     c05:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c07:      	cmpl	%ecx, 0x14(%rdi)
     c0a:      	jb	0xa6e <filter_16ty_selector_val+0x1e>
     c10:      	cmpl	$0x11, %edx
     c13:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c15:      	cmpl	%ecx, 0x18(%rdi)
     c18:      	jb	0xa6e <filter_16ty_selector_val+0x1e>
     c1e:      	cmpl	$0x15, %edx
     c21:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c23:      	cmpl	%ecx, 0x1c(%rdi)
     c26:      	jb	0xa6e <filter_16ty_selector_val+0x1e>
     c2c:      	jmp	0xc67 <filter_16ty_selector_val+0x217>
     c2e:      	movzwl	(%rsi), %ecx
     c31:      	cmpl	%ecx, 0x10(%rdi)
     c34:      	ja	0xa6e <filter_16ty_selector_val+0x1e>
     c3a:      	movl	0x8(%rdi), %edx
     c3d:      	cmpl	$0xd, %edx
     c40:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c42:      	cmpl	%ecx, 0x14(%rdi)
     c45:      	ja	0xa6e <filter_16ty_selector_val+0x1e>
     c4b:      	cmpl	$0x11, %edx
     c4e:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c50:      	cmpl	%ecx, 0x18(%rdi)
     c53:      	ja	0xa6e <filter_16ty_selector_val+0x1e>
     c59:      	cmpl	$0x15, %edx
     c5c:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c5e:      	cmpl	%ecx, 0x1c(%rdi)
     c61:      	ja	0xa6e <filter_16ty_selector_val+0x1e>
     c67:      	xorl	%eax, %eax
     c69:      	retq
     c6a:      	nopw	(%rax,%rax)

0000000000000c70 <filter_16ty_map>:
     c70:      	pushq	%r14
     c72:      	pushq	%rbx
     c73:      	subq	$0x18, %rsp
     c77:      	movq	%rsi, %r14
     c7a:      	movq	%rdi, %rbx
     c7d:      	movzbl	0x10(%rdi), %eax
     c81:      	movl	%eax, 0xc(%rsp)
     c85:      	movq	(%rip), %rdi            # 0xc8c <filter_16ty_map+0x1c>
     c8c:      	leaq	0xc(%rsp), %rsi
     c91:      	movl	$0x1, %eax
     c96:      	callq	*%rax
     c98:      	testq	%rax, %rax
     c9b:      	je	0xcd1 <filter_16ty_map+0x61>
     c9d:      	movq	%rax, %rdi
     ca0:      	movzwl	(%r14), %eax
     ca4:      	movq	%rax, 0x10(%rsp)
     ca9:      	leaq	0x10(%rsp), %rsi
     cae:      	movl	$0x1, %eax
     cb3:      	callq	*%rax
     cb5:      	movl	0x4(%rbx), %edx
     cb8:      	xorl	%ecx, %ecx
     cba:      	cmpl	$0x1d, %edx
     cbd:      	ja	0xceb <filter_16ty_map+0x7b>
     cbf:      	movl	$0x30038400, %esi       # imm = 0x30038400
     cc4:      	btl	%edx, %esi
     cc7:      	jae	0xcdb <filter_16ty_map+0x6b>
     cc9:      	testq	%rax, %rax
     ccc:      	setne	%cl
     ccf:      	jmp	0xceb <filter_16ty_map+0x7b>
     cd1:      	xorl	%eax, %eax
     cd3:      	addq	$0x18, %rsp
     cd7:      	popq	%rbx
     cd8:      	popq	%r14
     cda:      	retq
     cdb:      	movl	$0xc0800, %esi          # imm = 0xC0800
     ce0:      	btl	%edx, %esi
     ce3:      	jae	0xceb <filter_16ty_map+0x7b>
     ce5:      	testq	%rax, %rax
     ce8:      	sete	%cl
     ceb:      	movzbl	%cl, %eax
     cee:      	addq	$0x18, %rsp
     cf2:      	popq	%rbx
     cf3:      	popq	%r14
     cf5:      	retq
     cf6:      	nopw	%cs:(%rax,%rax)

0000000000000d00 <filter_16ty_range>:
     d00:      	movl	0x4(%rdi), %ecx
     d03:      	movl	0xc(%rdi), %eax
     d06:      	cmpl	$0xc, %eax
     d09:      	ja	0xdf0 <filter_16ty_range+0xf0>
     d0f:      	movl	$0x1402, %edx           # imm = 0x1402
     d14:      	btl	%eax, %edx
     d17:      	jae	0xdf0 <filter_16ty_range+0xf0>
     d1d:      	movswl	(%rsi), %esi
     d20:      	cmpl	$0x1f, %ecx
     d23:      	jne	0xd8b <filter_16ty_range+0x8b>
     d25:      	movl	$0x1, %eax
     d2a:      	cmpl	%esi, 0x10(%rdi)
     d2d:      	jg	0xd38 <filter_16ty_range+0x38>
     d2f:      	cmpl	%esi, 0x14(%rdi)
     d32:      	jge	0xe07 <filter_16ty_range+0x107>
     d38:      	movl	0x8(%rdi), %edx
     d3b:      	cmpl	$0x11, %edx
     d3e:      	jb	0xea7 <filter_16ty_range+0x1a7>
     d44:      	cmpl	%esi, 0x18(%rdi)
     d47:      	jg	0xd52 <filter_16ty_range+0x52>
     d49:      	cmpl	%esi, 0x1c(%rdi)
     d4c:      	jge	0xe07 <filter_16ty_range+0x107>
     d52:      	cmpl	$0x19, %edx
     d55:      	jb	0xea7 <filter_16ty_range+0x1a7>
     d5b:      	cmpl	%esi, 0x20(%rdi)
     d5e:      	jg	0xd69 <filter_16ty_range+0x69>
     d60:      	cmpl	%esi, 0x24(%rdi)
     d63:      	jge	0xe07 <filter_16ty_range+0x107>
     d69:      	cmpl	$0x21, %edx
     d6c:      	jb	0xea7 <filter_16ty_range+0x1a7>
     d72:      	xorl	%edx, %edx
     d74:      	cmpl	%esi, 0x28(%rdi)
     d77:      	jg	0xea9 <filter_16ty_range+0x1a9>
     d7d:      	cmpl	%esi, 0x2c(%rdi)
     d80:      	jge	0xe07 <filter_16ty_range+0x107>
     d86:      	jmp	0xea9 <filter_16ty_range+0x1a9>
     d8b:      	movl	0x8(%rdi), %eax
     d8e:      	cmpl	%esi, 0x10(%rdi)
     d91:      	setle	%r8b
     d95:      	cmpl	%esi, 0x14(%rdi)
     d98:      	setge	%dl
     d9b:      	andb	%r8b, %dl
     d9e:      	cmpl	$0x11, %eax
     da1:      	jb	0xea9 <filter_16ty_range+0x1a9>
     da7:      	cmpl	%esi, 0x18(%rdi)
     daa:      	setle	%r8b
     dae:      	cmpl	%esi, 0x1c(%rdi)
     db1:      	setge	%r9b
     db5:      	andb	%r8b, %r9b
     db8:      	orb	%r9b, %dl
     dbb:      	cmpl	$0x19, %eax
     dbe:      	jb	0xea9 <filter_16ty_range+0x1a9>
     dc4:      	cmpl	%esi, 0x20(%rdi)
     dc7:      	setle	%r8b
     dcb:      	cmpl	%esi, 0x24(%rdi)
     dce:      	setge	%r9b
     dd2:      	andb	%r8b, %r9b
     dd5:      	orb	%r9b, %dl
     dd8:      	cmpl	$0x21, %eax
     ddb:      	jb	0xea9 <filter_16ty_range+0x1a9>
     de1:      	cmpl	%esi, 0x28(%rdi)
     de4:      	setle	%al
     de7:      	cmpl	%esi, 0x2c(%rdi)
     dea:      	setge	%sil
     dee:      	jmp	0xe63 <filter_16ty_range+0x163>
     df0:      	movzwl	(%rsi), %esi
     df3:      	cmpl	$0x1f, %ecx
     df6:      	jne	0xe08 <filter_16ty_range+0x108>
     df8:      	movl	$0x1, %eax
     dfd:      	cmpl	%esi, 0x10(%rdi)
     e00:      	ja	0xe6b <filter_16ty_range+0x16b>
     e02:      	cmpl	%esi, 0x14(%rdi)
     e05:      	jb	0xe6b <filter_16ty_range+0x16b>
     e07:      	retq
     e08:      	movl	0x8(%rdi), %eax
     e0b:      	cmpl	%esi, 0x10(%rdi)
     e0e:      	setbe	%r8b
     e12:      	cmpl	%esi, 0x14(%rdi)
     e15:      	setae	%dl
     e18:      	andb	%r8b, %dl
     e1b:      	cmpl	$0x11, %eax
     e1e:      	jb	0xea9 <filter_16ty_range+0x1a9>
     e24:      	cmpl	%esi, 0x18(%rdi)
     e27:      	setbe	%r8b
     e2b:      	cmpl	%esi, 0x1c(%rdi)
     e2e:      	setae	%r9b
     e32:      	andb	%r8b, %r9b
     e35:      	orb	%r9b, %dl
     e38:      	cmpl	$0x19, %eax
     e3b:      	jb	0xea9 <filter_16ty_range+0x1a9>
     e3d:      	cmpl	%esi, 0x20(%rdi)
     e40:      	setbe	%r8b
     e44:      	cmpl	%esi, 0x24(%rdi)
     e47:      	setae	%r9b
     e4b:      	andb	%r8b, %r9b
     e4e:      	orb	%r9b, %dl
     e51:      	cmpl	$0x21, %eax
     e54:      	jb	0xea9 <filter_16ty_range+0x1a9>
     e56:      	cmpl	%esi, 0x28(%rdi)
     e59:      	setbe	%al
     e5c:      	cmpl	%esi, 0x2c(%rdi)
     e5f:      	setae	%sil
     e63:      	andb	%al, %sil
     e66:      	orb	%sil, %dl
     e69:      	jmp	0xea9 <filter_16ty_range+0x1a9>
     e6b:      	movl	0x8(%rdi), %edx
     e6e:      	cmpl	$0x11, %edx
     e71:      	jb	0xea7 <filter_16ty_range+0x1a7>
     e73:      	cmpl	%esi, 0x18(%rdi)
     e76:      	ja	0xe7d <filter_16ty_range+0x17d>
     e78:      	cmpl	%esi, 0x1c(%rdi)
     e7b:      	jae	0xe07 <filter_16ty_range+0x107>
     e7d:      	cmpl	$0x19, %edx
     e80:      	jb	0xea7 <filter_16ty_range+0x1a7>
     e82:      	cmpl	%esi, 0x20(%rdi)
     e85:      	ja	0xe90 <filter_16ty_range+0x190>
     e87:      	cmpl	%esi, 0x24(%rdi)
     e8a:      	jae	0xe07 <filter_16ty_range+0x107>
     e90:      	cmpl	$0x21, %edx
     e93:      	jb	0xea7 <filter_16ty_range+0x1a7>
     e95:      	xorl	%edx, %edx
     e97:      	cmpl	%esi, 0x28(%rdi)
     e9a:      	ja	0xea9 <filter_16ty_range+0x1a9>
     e9c:      	cmpl	%esi, 0x2c(%rdi)
     e9f:      	jae	0xe07 <filter_16ty_range+0x107>
     ea5:      	jmp	0xea9 <filter_16ty_range+0x1a9>
     ea7:      	xorl	%edx, %edx
     ea9:      	cmpl	$0x20, %ecx
     eac:      	sete	%al
     eaf:      	xorb	$0x1, %dl
     eb2:      	andb	%al, %dl
     eb4:      	movzbl	%dl, %eax
     eb7:      	retq
     eb8:      	nopl	(%rax,%rax)

0000000000000ec0 <filter_8ty_selector_val>:
     ec0:      	movl	0x4(%rdi), %ecx
     ec3:      	movl	$0x1, %eax
     ec8:      	cmpq	$0x25, %rcx
     ecc:      	ja	0xf3f <filter_8ty_selector_val+0x7f>
     ece:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     ed8:      	btq	%rcx, %rdx
     edc:      	jae	0xedf <filter_8ty_selector_val+0x1f>
     ede:      	retq
     edf:      	movl	$0x18, %edx
     ee4:      	btq	%rcx, %rdx
     ee8:      	jae	0xeff <filter_8ty_selector_val+0x3f>
     eea:      	movzbl	(%rsi), %edx
     eed:      	cmpl	%edx, 0x10(%rdi)
     ef0:      	jne	0x1015 <filter_8ty_selector_val+0x155>
     ef6:      	xorl	%eax, %eax
     ef8:      	cmpl	$0x3, %ecx
     efb:      	sete	%al
     efe:      	retq
     eff:      	cmpq	$0xc, %rcx
     f03:      	jne	0xf3f <filter_8ty_selector_val+0x7f>
     f05:      	movzbl	(%rsi), %ecx
     f08:      	testl	%ecx, 0x10(%rdi)
     f0b:      	jne	0xede <filter_8ty_selector_val+0x1e>
     f0d:      	movl	0x8(%rdi), %edx
     f10:      	cmpl	$0xd, %edx
     f13:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     f19:      	testl	%ecx, 0x14(%rdi)
     f1c:      	jne	0xede <filter_8ty_selector_val+0x1e>
     f1e:      	cmpl	$0x11, %edx
     f21:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     f27:      	testl	%ecx, 0x18(%rdi)
     f2a:      	jne	0xede <filter_8ty_selector_val+0x1e>
     f2c:      	cmpl	$0x15, %edx
     f2f:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     f35:      	testl	%ecx, 0x1c(%rdi)
     f38:      	jne	0xede <filter_8ty_selector_val+0x1e>
     f3a:      	jmp	0x10d7 <filter_8ty_selector_val+0x217>
     f3f:      	cmpl	$0x1, %ecx
     f42:      	je	0xfb1 <filter_8ty_selector_val+0xf1>
     f44:      	cmpl	$0x2, %ecx
     f47:      	jne	0x10d7 <filter_8ty_selector_val+0x217>
     f4d:      	movl	0xc(%rdi), %ecx
     f50:      	cmpl	$0xc, %ecx
     f53:      	ja	0x109e <filter_8ty_selector_val+0x1de>
     f59:      	movl	$0x1402, %edx           # imm = 0x1402
     f5e:      	btl	%ecx, %edx
     f61:      	jae	0x109e <filter_8ty_selector_val+0x1de>
     f67:      	movsbl	(%rsi), %ecx
     f6a:      	cmpl	%ecx, 0x10(%rdi)
     f6d:      	jg	0xede <filter_8ty_selector_val+0x1e>
     f73:      	movl	0x8(%rdi), %edx
     f76:      	cmpl	$0xd, %edx
     f79:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     f7f:      	cmpl	%ecx, 0x14(%rdi)
     f82:      	jg	0xede <filter_8ty_selector_val+0x1e>
     f88:      	cmpl	$0x11, %edx
     f8b:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     f91:      	cmpl	%ecx, 0x18(%rdi)
     f94:      	jg	0xede <filter_8ty_selector_val+0x1e>
     f9a:      	cmpl	$0x15, %edx
     f9d:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     fa3:      	cmpl	%ecx, 0x1c(%rdi)
     fa6:      	jg	0xede <filter_8ty_selector_val+0x1e>
     fac:      	jmp	0x10d7 <filter_8ty_selector_val+0x217>
     fb1:      	movl	0xc(%rdi), %ecx
     fb4:      	cmpl	$0xc, %ecx
     fb7:      	ja	0x1063 <filter_8ty_selector_val+0x1a3>
     fbd:      	movl	$0x1402, %edx           # imm = 0x1402
     fc2:      	btl	%ecx, %edx
     fc5:      	jae	0x1063 <filter_8ty_selector_val+0x1a3>
     fcb:      	movsbl	(%rsi), %ecx
     fce:      	cmpl	%ecx, 0x10(%rdi)
     fd1:      	jl	0xede <filter_8ty_selector_val+0x1e>
     fd7:      	movl	0x8(%rdi), %edx
     fda:      	cmpl	$0xd, %edx
     fdd:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     fe3:      	cmpl	%ecx, 0x14(%rdi)
     fe6:      	jl	0xede <filter_8ty_selector_val+0x1e>
     fec:      	cmpl	$0x11, %edx
     fef:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     ff5:      	cmpl	%ecx, 0x18(%rdi)
     ff8:      	jl	0xede <filter_8ty_selector_val+0x1e>
     ffe:      	cmpl	$0x15, %edx
    1001:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    1007:      	cmpl	%ecx, 0x1c(%rdi)
    100a:      	jl	0xede <filter_8ty_selector_val+0x1e>
    1010:      	jmp	0x10d7 <filter_8ty_selector_val+0x217>
    1015:      	movl	0x8(%rdi), %esi
    1018:      	cmpl	$0xd, %esi
    101b:      	jb	0x1042 <filter_8ty_selector_val+0x182>
    101d:      	cmpl	%edx, 0x14(%rdi)
    1020:      	je	0xef6 <filter_8ty_selector_val+0x36>
    1026:      	cmpl	$0x11, %esi
    1029:      	jb	0x1042 <filter_8ty_selector_val+0x182>
    102b:      	cmpl	%edx, 0x18(%rdi)
    102e:      	je	0xef6 <filter_8ty_selector_val+0x36>
    1034:      	cmpl	$0x15, %esi
    1037:      	jb	0x1042 <filter_8ty_selector_val+0x182>
    1039:      	cmpl	%edx, 0x1c(%rdi)
    103c:      	je	0xef6 <filter_8ty_selector_val+0x36>
    1042:      	cmpl	$0x25, %ecx
    1045:      	ja	0x10d7 <filter_8ty_selector_val+0x217>
    104b:      	movl	%ecx, %ecx
    104d:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1057:      	btq	%rcx, %rdx
    105b:      	jb	0xede <filter_8ty_selector_val+0x1e>
    1061:      	jmp	0x10d7 <filter_8ty_selector_val+0x217>
    1063:      	movzbl	(%rsi), %ecx
    1066:      	cmpl	%ecx, 0x10(%rdi)
    1069:      	jb	0xede <filter_8ty_selector_val+0x1e>
    106f:      	movl	0x8(%rdi), %edx
    1072:      	cmpl	$0xd, %edx
    1075:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    1077:      	cmpl	%ecx, 0x14(%rdi)
    107a:      	jb	0xede <filter_8ty_selector_val+0x1e>
    1080:      	cmpl	$0x11, %edx
    1083:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    1085:      	cmpl	%ecx, 0x18(%rdi)
    1088:      	jb	0xede <filter_8ty_selector_val+0x1e>
    108e:      	cmpl	$0x15, %edx
    1091:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    1093:      	cmpl	%ecx, 0x1c(%rdi)
    1096:      	jb	0xede <filter_8ty_selector_val+0x1e>
    109c:      	jmp	0x10d7 <filter_8ty_selector_val+0x217>
    109e:      	movzbl	(%rsi), %ecx
    10a1:      	cmpl	%ecx, 0x10(%rdi)
    10a4:      	ja	0xede <filter_8ty_selector_val+0x1e>
    10aa:      	movl	0x8(%rdi), %edx
    10ad:      	cmpl	$0xd, %edx
    10b0:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    10b2:      	cmpl	%ecx, 0x14(%rdi)
    10b5:      	ja	0xede <filter_8ty_selector_val+0x1e>
    10bb:      	cmpl	$0x11, %edx
    10be:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    10c0:      	cmpl	%ecx, 0x18(%rdi)
    10c3:      	ja	0xede <filter_8ty_selector_val+0x1e>
    10c9:      	cmpl	$0x15, %edx
    10cc:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    10ce:      	cmpl	%ecx, 0x1c(%rdi)
    10d1:      	ja	0xede <filter_8ty_selector_val+0x1e>
    10d7:      	xorl	%eax, %eax
    10d9:      	retq
    10da:      	nopw	(%rax,%rax)

00000000000010e0 <filter_8ty_map>:
    10e0:      	pushq	%r14
    10e2:      	pushq	%rbx
    10e3:      	subq	$0x18, %rsp
    10e7:      	movq	%rsi, %r14
    10ea:      	movq	%rdi, %rbx
    10ed:      	movzbl	0x10(%rdi), %eax
    10f1:      	movl	%eax, 0xc(%rsp)
    10f5:      	movq	(%rip), %rdi            # 0x10fc <filter_8ty_map+0x1c>
    10fc:      	leaq	0xc(%rsp), %rsi
    1101:      	movl	$0x1, %eax
    1106:      	callq	*%rax
    1108:      	testq	%rax, %rax
    110b:      	je	0x1141 <filter_8ty_map+0x61>
    110d:      	movq	%rax, %rdi
    1110:      	movzbl	(%r14), %eax
    1114:      	movq	%rax, 0x10(%rsp)
    1119:      	leaq	0x10(%rsp), %rsi
    111e:      	movl	$0x1, %eax
    1123:      	callq	*%rax
    1125:      	movl	0x4(%rbx), %edx
    1128:      	xorl	%ecx, %ecx
    112a:      	cmpl	$0x1d, %edx
    112d:      	ja	0x115b <filter_8ty_map+0x7b>
    112f:      	movl	$0x30038400, %esi       # imm = 0x30038400
    1134:      	btl	%edx, %esi
    1137:      	jae	0x114b <filter_8ty_map+0x6b>
    1139:      	testq	%rax, %rax
    113c:      	setne	%cl
    113f:      	jmp	0x115b <filter_8ty_map+0x7b>
    1141:      	xorl	%eax, %eax
    1143:      	addq	$0x18, %rsp
    1147:      	popq	%rbx
    1148:      	popq	%r14
    114a:      	retq
    114b:      	movl	$0xc0800, %esi          # imm = 0xC0800
    1150:      	btl	%edx, %esi
    1153:      	jae	0x115b <filter_8ty_map+0x7b>
    1155:      	testq	%rax, %rax
    1158:      	sete	%cl
    115b:      	movzbl	%cl, %eax
    115e:      	addq	$0x18, %rsp
    1162:      	popq	%rbx
    1163:      	popq	%r14
    1165:      	retq
    1166:      	nopw	%cs:(%rax,%rax)

0000000000001170 <filter_8ty_range>:
    1170:      	movl	0x4(%rdi), %ecx
    1173:      	movl	0xc(%rdi), %eax
    1176:      	cmpl	$0xc, %eax
    1179:      	ja	0x1260 <filter_8ty_range+0xf0>
    117f:      	movl	$0x1402, %edx           # imm = 0x1402
    1184:      	btl	%eax, %edx
    1187:      	jae	0x1260 <filter_8ty_range+0xf0>
    118d:      	movsbl	(%rsi), %esi
    1190:      	cmpl	$0x1f, %ecx
    1193:      	jne	0x11fb <filter_8ty_range+0x8b>
    1195:      	movl	$0x1, %eax
    119a:      	cmpl	%esi, 0x10(%rdi)
    119d:      	jg	0x11a8 <filter_8ty_range+0x38>
    119f:      	cmpl	%esi, 0x14(%rdi)
    11a2:      	jge	0x1277 <filter_8ty_range+0x107>
    11a8:      	movl	0x8(%rdi), %edx
    11ab:      	cmpl	$0x11, %edx
    11ae:      	jb	0x1317 <filter_8ty_range+0x1a7>
    11b4:      	cmpl	%esi, 0x18(%rdi)
    11b7:      	jg	0x11c2 <filter_8ty_range+0x52>
    11b9:      	cmpl	%esi, 0x1c(%rdi)
    11bc:      	jge	0x1277 <filter_8ty_range+0x107>
    11c2:      	cmpl	$0x19, %edx
    11c5:      	jb	0x1317 <filter_8ty_range+0x1a7>
    11cb:      	cmpl	%esi, 0x20(%rdi)
    11ce:      	jg	0x11d9 <filter_8ty_range+0x69>
    11d0:      	cmpl	%esi, 0x24(%rdi)
    11d3:      	jge	0x1277 <filter_8ty_range+0x107>
    11d9:      	cmpl	$0x21, %edx
    11dc:      	jb	0x1317 <filter_8ty_range+0x1a7>
    11e2:      	xorl	%edx, %edx
    11e4:      	cmpl	%esi, 0x28(%rdi)
    11e7:      	jg	0x1319 <filter_8ty_range+0x1a9>
    11ed:      	cmpl	%esi, 0x2c(%rdi)
    11f0:      	jge	0x1277 <filter_8ty_range+0x107>
    11f6:      	jmp	0x1319 <filter_8ty_range+0x1a9>
    11fb:      	movl	0x8(%rdi), %eax
    11fe:      	cmpl	%esi, 0x10(%rdi)
    1201:      	setle	%r8b
    1205:      	cmpl	%esi, 0x14(%rdi)
    1208:      	setge	%dl
    120b:      	andb	%r8b, %dl
    120e:      	cmpl	$0x11, %eax
    1211:      	jb	0x1319 <filter_8ty_range+0x1a9>
    1217:      	cmpl	%esi, 0x18(%rdi)
    121a:      	setle	%r8b
    121e:      	cmpl	%esi, 0x1c(%rdi)
    1221:      	setge	%r9b
    1225:      	andb	%r8b, %r9b
    1228:      	orb	%r9b, %dl
    122b:      	cmpl	$0x19, %eax
    122e:      	jb	0x1319 <filter_8ty_range+0x1a9>
    1234:      	cmpl	%esi, 0x20(%rdi)
    1237:      	setle	%r8b
    123b:      	cmpl	%esi, 0x24(%rdi)
    123e:      	setge	%r9b
    1242:      	andb	%r8b, %r9b
    1245:      	orb	%r9b, %dl
    1248:      	cmpl	$0x21, %eax
    124b:      	jb	0x1319 <filter_8ty_range+0x1a9>
    1251:      	cmpl	%esi, 0x28(%rdi)
    1254:      	setle	%al
    1257:      	cmpl	%esi, 0x2c(%rdi)
    125a:      	setge	%sil
    125e:      	jmp	0x12d3 <filter_8ty_range+0x163>
    1260:      	movzbl	(%rsi), %esi
    1263:      	cmpl	$0x1f, %ecx
    1266:      	jne	0x1278 <filter_8ty_range+0x108>
    1268:      	movl	$0x1, %eax
    126d:      	cmpl	%esi, 0x10(%rdi)
    1270:      	ja	0x12db <filter_8ty_range+0x16b>
    1272:      	cmpl	%esi, 0x14(%rdi)
    1275:      	jb	0x12db <filter_8ty_range+0x16b>
    1277:      	retq
    1278:      	movl	0x8(%rdi), %eax
    127b:      	cmpl	%esi, 0x10(%rdi)
    127e:      	setbe	%r8b
    1282:      	cmpl	%esi, 0x14(%rdi)
    1285:      	setae	%dl
    1288:      	andb	%r8b, %dl
    128b:      	cmpl	$0x11, %eax
    128e:      	jb	0x1319 <filter_8ty_range+0x1a9>
    1294:      	cmpl	%esi, 0x18(%rdi)
    1297:      	setbe	%r8b
    129b:      	cmpl	%esi, 0x1c(%rdi)
    129e:      	setae	%r9b
    12a2:      	andb	%r8b, %r9b
    12a5:      	orb	%r9b, %dl
    12a8:      	cmpl	$0x19, %eax
    12ab:      	jb	0x1319 <filter_8ty_range+0x1a9>
    12ad:      	cmpl	%esi, 0x20(%rdi)
    12b0:      	setbe	%r8b
    12b4:      	cmpl	%esi, 0x24(%rdi)
    12b7:      	setae	%r9b
    12bb:      	andb	%r8b, %r9b
    12be:      	orb	%r9b, %dl
    12c1:      	cmpl	$0x21, %eax
    12c4:      	jb	0x1319 <filter_8ty_range+0x1a9>
    12c6:      	cmpl	%esi, 0x28(%rdi)
    12c9:      	setbe	%al
    12cc:      	cmpl	%esi, 0x2c(%rdi)
    12cf:      	setae	%sil
    12d3:      	andb	%al, %sil
    12d6:      	orb	%sil, %dl
    12d9:      	jmp	0x1319 <filter_8ty_range+0x1a9>
    12db:      	movl	0x8(%rdi), %edx
    12de:      	cmpl	$0x11, %edx
    12e1:      	jb	0x1317 <filter_8ty_range+0x1a7>
    12e3:      	cmpl	%esi, 0x18(%rdi)
    12e6:      	ja	0x12ed <filter_8ty_range+0x17d>
    12e8:      	cmpl	%esi, 0x1c(%rdi)
    12eb:      	jae	0x1277 <filter_8ty_range+0x107>
    12ed:      	cmpl	$0x19, %edx
    12f0:      	jb	0x1317 <filter_8ty_range+0x1a7>
    12f2:      	cmpl	%esi, 0x20(%rdi)
    12f5:      	ja	0x1300 <filter_8ty_range+0x190>
    12f7:      	cmpl	%esi, 0x24(%rdi)
    12fa:      	jae	0x1277 <filter_8ty_range+0x107>
    1300:      	cmpl	$0x21, %edx
    1303:      	jb	0x1317 <filter_8ty_range+0x1a7>
    1305:      	xorl	%edx, %edx
    1307:      	cmpl	%esi, 0x28(%rdi)
    130a:      	ja	0x1319 <filter_8ty_range+0x1a9>
    130c:      	cmpl	%esi, 0x2c(%rdi)
    130f:      	jae	0x1277 <filter_8ty_range+0x107>
    1315:      	jmp	0x1319 <filter_8ty_range+0x1a9>
    1317:      	xorl	%edx, %edx
    1319:      	cmpl	$0x20, %ecx
    131c:      	sete	%al
    131f:      	xorb	$0x1, %dl
    1322:      	andb	%al, %dl
    1324:      	movzbl	%dl, %eax
    1327:      	retq
    1328:      	nopl	(%rax,%rax)

0000000000001330 <filter_file_buf>:
    1330:      	pushq	%rbx
    1331:      	movq	%rdi, %rbx
    1334:      	movl	(%rsi), %edx
    1336:      	movl	0x4(%rdi), %ecx
    1339:      	testl	%edx, %edx
    133b:      	jne	0x134b <filter_file_buf+0x1b>
    133d:      	movl	%ecx, %eax
    133f:      	andl	$-0x2, %eax
    1342:      	cmpl	$0x24, %eax
    1345:      	je	0x134b <filter_file_buf+0x1b>
    1347:      	xorl	%eax, %eax
    1349:      	popq	%rbx
    134a:      	retq
    134b:      	cmpl	$0x25, %ecx
    134e:      	ja	0x138a <filter_file_buf+0x5a>
    1350:      	movl	%ecx, %eax
    1352:      	movl	$0x4000100, %edi        # imm = 0x4000100
    1357:      	btq	%rax, %rdi
    135b:      	jb	0x13be <filter_file_buf+0x8e>
    135d:      	movl	$0x8000200, %edi        # imm = 0x8000200
    1362:      	btq	%rax, %rdi
    1366:      	jb	0x13a8 <filter_file_buf+0x78>
    1368:      	movabsq	$0x3000000000, %rdi     # imm = 0x3000000000
    1372:      	btq	%rax, %rdi
    1376:      	jae	0x138a <filter_file_buf+0x5a>
    1378:      	movq	%rbx, %rdi
    137b:      	callq	0x1e20 <filter_file_type>
    1380:      	movl	0x4(%rbx), %ecx
    1383:      	cmpl	$0x25, %ecx
    1386:      	jbe	0x13db <filter_file_buf+0xab>
    1388:      	jmp	0x13f1 <filter_file_buf+0xc1>
    138a:      	leal	-0x3(%rcx), %eax
    138d:      	cmpl	$0x2, %eax
    1390:      	jae	0x13d4 <filter_file_buf+0xa4>
    1392:      	addq	$0x4, %rsi
    1396:      	movq	%rbx, %rdi
    1399:      	callq	0x18b0 <filter_char_buf_equal>
    139e:      	movl	0x4(%rbx), %ecx
    13a1:      	cmpl	$0x25, %ecx
    13a4:      	jbe	0x13db <filter_file_buf+0xab>
    13a6:      	jmp	0x13f1 <filter_file_buf+0xc1>
    13a8:      	addq	$0x4, %rsi
    13ac:      	movl	0x10(%rbx), %edi
    13af:      	callq	0x1cd0 <filter_char_buf_postfix>
    13b4:      	movl	0x4(%rbx), %ecx
    13b7:      	cmpl	$0x25, %ecx
    13ba:      	jbe	0x13db <filter_file_buf+0xab>
    13bc:      	jmp	0x13f1 <filter_file_buf+0xc1>
    13be:      	addq	$0x4, %rsi
    13c2:      	movl	0x10(%rbx), %edi
    13c5:      	callq	0x1c30 <filter_char_buf_prefix>
    13ca:      	movl	0x4(%rbx), %ecx
    13cd:      	cmpl	$0x25, %ecx
    13d0:      	jbe	0x13db <filter_file_buf+0xab>
    13d2:      	jmp	0x13f1 <filter_file_buf+0xc1>
    13d4:      	xorl	%eax, %eax
    13d6:      	cmpl	$0x25, %ecx
    13d9:      	ja	0x13f1 <filter_file_buf+0xc1>
    13db:      	movl	%ecx, %ecx
    13dd:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    13e7:      	btq	%rcx, %rdx
    13eb:      	jae	0x13f1 <filter_file_buf+0xc1>
    13ed:      	xorq	$0x1, %rax
    13f1:      	popq	%rbx
    13f2:      	retq
    13f3:      	nopw	%cs:(%rax,%rax)

0000000000001400 <filter_char_buf>:
    1400:      	pushq	%rbx
    1401:      	movq	%rsi, %rax
    1404:      	movq	%rdi, %rbx
    1407:      	movslq	%edx, %rcx
    140a:      	movl	-0x4(%rsi,%rcx), %edx
    140e:      	movl	%ecx, %esi
    1410:      	addq	%rax, %rsi
    1413:      	movl	0x4(%rdi), %ecx
    1416:      	xorl	%eax, %eax
    1418:      	cmpl	$0x19, %ecx
    141b:      	jg	0x1431 <filter_char_buf+0x31>
    141d:      	leal	-0x3(%rcx), %edi
    1420:      	cmpl	$0x2, %edi
    1423:      	jb	0x1468 <filter_char_buf+0x68>
    1425:      	cmpl	$0x8, %ecx
    1428:      	je	0x145e <filter_char_buf+0x5e>
    142a:      	cmpl	$0x9, %ecx
    142d:      	je	0x1440 <filter_char_buf+0x40>
    142f:      	jmp	0x147f <filter_char_buf+0x7f>
    1431:      	cmpl	$0x20, %ecx
    1434:      	jg	0x144a <filter_char_buf+0x4a>
    1436:      	cmpl	$0x1a, %ecx
    1439:      	je	0x145e <filter_char_buf+0x5e>
    143b:      	cmpl	$0x1b, %ecx
    143e:      	jne	0x147f <filter_char_buf+0x7f>
    1440:      	movl	0x10(%rbx), %edi
    1443:      	callq	0x1cd0 <filter_char_buf_postfix>
    1448:      	jmp	0x147c <filter_char_buf+0x7c>
    144a:      	cmpl	$0x21, %ecx
    144d:      	je	0x1472 <filter_char_buf+0x72>
    144f:      	cmpl	$0x22, %ecx
    1452:      	jne	0x147f <filter_char_buf+0x7f>
    1454:      	movq	%rbx, %rdi
    1457:      	movl	$0x1, %ecx
    145c:      	jmp	0x1477 <filter_char_buf+0x77>
    145e:      	movl	0x10(%rbx), %edi
    1461:      	callq	0x1c30 <filter_char_buf_prefix>
    1466:      	jmp	0x147c <filter_char_buf+0x7c>
    1468:      	movq	%rbx, %rdi
    146b:      	callq	0x18b0 <filter_char_buf_equal>
    1470:      	jmp	0x147c <filter_char_buf+0x7c>
    1472:      	movq	%rbx, %rdi
    1475:      	xorl	%ecx, %ecx
    1477:      	callq	0x1ed0 <filter_char_substring>
    147c:      	movl	0x4(%rbx), %ecx
    147f:      	cmpl	$0x25, %ecx
    1482:      	ja	0x14a1 <filter_char_buf+0xa1>
    1484:      	movl	%ecx, %ecx
    1486:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1490:      	btq	%rcx, %rdx
    1494:      	jae	0x14a1 <filter_char_buf+0xa1>
    1496:      	xorl	%ecx, %ecx
    1498:      	testq	%rax, %rax
    149b:      	sete	%cl
    149e:      	movq	%rcx, %rax
    14a1:      	popq	%rbx
    14a2:      	retq
    14a3:      	nopw	%cs:(%rax,%rax)

00000000000014b0 <filter_inet>:
    14b0:      	pushq	%r15
    14b2:      	pushq	%r14
    14b4:      	pushq	%r12
    14b6:      	pushq	%rbx
    14b7:      	subq	$0x48, %rsp
    14bb:      	movq	$0x0, 0x40(%rsp)
    14c4:      	movq	$0x0, 0x38(%rsp)
    14cd:      	movq	$0x0, 0x30(%rsp)
    14d6:      	movq	$0x0, 0x28(%rsp)
    14df:      	movq	$0x0, 0x20(%rsp)
    14e8:      	movl	$0x0, (%rsp)
    14ef:      	movl	$0x0, 0x4(%rsp)
    14f7:      	movl	0xc(%rdi), %edx
    14fa:      	xorl	%eax, %eax
    14fc:      	cmpl	$0x27, %edx
    14ff:      	jg	0x1517 <filter_inet+0x67>
    1501:      	cmpl	$0x5, %edx
    1504:      	je	0x159c <filter_inet+0xec>
    150a:      	movq	%rsi, %r8
    150d:      	cmpl	$0x7, %edx
    1510:      	je	0x1528 <filter_inet+0x78>
    1512:      	jmp	0x17ad <filter_inet+0x2fd>
    1517:      	cmpl	$0x28, %edx
    151a:      	je	0x1574 <filter_inet+0xc4>
    151c:      	movq	%rsi, %r8
    151f:      	cmpl	$0x29, %edx
    1522:      	jne	0x17ad <filter_inet+0x2fd>
    1528:      	movl	0x4(%rdi), %ecx
    152b:      	xorl	%eax, %eax
    152d:      	cmpl	$0x13, %ecx
    1530:      	jle	0x15a9 <filter_inet+0xf9>
    1532:      	cmpl	$0x17, %ecx
    1535:      	jg	0x1554 <filter_inet+0xa4>
    1537:      	leal	-0x14(%rcx), %edx
    153a:      	cmpl	$0x2, %edx
    153d:      	jb	0x15fa <filter_inet+0x14a>
    1543:      	leal	-0x16(%rcx), %edx
    1546:      	cmpl	$0x2, %edx
    1549:      	jb	0x15f4 <filter_inet+0x144>
    154f:      	jmp	0x17ad <filter_inet+0x2fd>
    1554:      	cmpl	$0x1b, %ecx
    1557:      	jg	0x1637 <filter_inet+0x187>
    155d:      	cmpl	$0x18, %ecx
    1560:      	je	0x166a <filter_inet+0x1ba>
    1566:      	cmpl	$0x19, %ecx
    1569:      	je	0x1660 <filter_inet+0x1b0>
    156f:      	jmp	0x17ad <filter_inet+0x2fd>
    1574:      	movzwl	(%rsi), %eax
    1577:      	movw	%ax, 0x46(%rsp)
    157c:      	movzwl	0x2(%rsi), %eax
    1580:      	movw	%ax, 0x40(%rsp)
    1585:      	movq	0x8(%rsi), %rax
    1589:      	movq	%rax, 0x20(%rsp)
    158e:      	movq	0x10(%rsi), %rax
    1592:      	movq	%rax, 0x28(%rsp)
    1597:      	leaq	0x20(%rsp), %rsi
    159c:      	xorl	%r8d, %r8d
    159f:      	movl	0x4(%rdi), %ecx
    15a2:      	xorl	%eax, %eax
    15a4:      	cmpl	$0x13, %ecx
    15a7:      	jg	0x1532 <filter_inet+0x82>
    15a9:      	cmpl	$0xf, %ecx
    15ac:      	jle	0x15ca <filter_inet+0x11a>
    15ae:      	cmpl	$0x11, %ecx
    15b1:      	jg	0x15e6 <filter_inet+0x136>
    15b3:      	cmpl	$0x10, %ecx
    15b6:      	je	0x15f4 <filter_inet+0x144>
    15b8:      	cmpl	$0x11, %ecx
    15bb:      	jne	0x17ad <filter_inet+0x2fd>
    15c1:      	movzwl	0x24(%rsi), %eax
    15c5:      	jmp	0x17a2 <filter_inet+0x2f2>
    15ca:      	cmpl	$0xd, %ecx
    15cd:      	je	0x166a <filter_inet+0x1ba>
    15d3:      	cmpl	$0xe, %ecx
    15d6:      	je	0x1660 <filter_inet+0x1b0>
    15dc:      	cmpl	$0xf, %ecx
    15df:      	je	0x15fa <filter_inet+0x14a>
    15e1:      	jmp	0x17ad <filter_inet+0x2fd>
    15e6:      	cmpl	$0x12, %ecx
    15e9:      	je	0x15fa <filter_inet+0x14a>
    15eb:      	cmpl	$0x13, %ecx
    15ee:      	jne	0x17ad <filter_inet+0x2fd>
    15f4:      	movzwl	0x22(%rsi), %edx
    15f8:      	jmp	0x15fe <filter_inet+0x14e>
    15fa:      	movzwl	0x20(%rsi), %edx
    15fe:      	movl	%edx, 0x4(%rsp)
    1602:      	xorl	%ebx, %ebx
    1604:      	xorl	%r15d, %r15d
    1607:      	xorl	%r14d, %r14d
    160a:      	xorl	%eax, %eax
    160c:      	cmpl	$0x11, %ecx
    160f:      	jg	0x1681 <filter_inet+0x1d1>
    1611:      	leal	-0xd(%rcx), %edx
    1614:      	cmpl	$0x2, %edx
    1617:      	jb	0x16a8 <filter_inet+0x1f8>
    161d:      	leal	-0xf(%rcx), %edx
    1620:      	cmpl	$0x2, %edx
    1623:      	jb	0x16fd <filter_inet+0x24d>
    1629:      	cmpl	$0x11, %ecx
    162c:      	je	0x17a5 <filter_inet+0x2f5>
    1632:      	jmp	0x17ad <filter_inet+0x2fd>
    1637:      	cmpl	$0x1c, %ecx
    163a:      	je	0x179e <filter_inet+0x2ee>
    1640:      	cmpl	$0x1d, %ecx
    1643:      	jne	0x17ad <filter_inet+0x2fd>
    1649:      	cmpl	$0x7, %edx
    164c:      	jne	0x17d1 <filter_inet+0x321>
    1652:      	testq	%r8, %r8
    1655:      	jne	0x17db <filter_inet+0x32b>
    165b:      	jmp	0x17a5 <filter_inet+0x2f5>
    1660:      	movq	0x10(%rsi), %rbx
    1664:      	movq	0x18(%rsi), %r14
    1668:      	jmp	0x1671 <filter_inet+0x1c1>
    166a:      	movq	(%rsi), %rbx
    166d:      	movq	0x8(%rsi), %r14
    1671:      	movq	%rbx, %r15
    1674:      	shrq	$0x20, %r15
    1678:      	xorl	%edx, %edx
    167a:      	xorl	%eax, %eax
    167c:      	cmpl	$0x11, %ecx
    167f:      	jle	0x1611 <filter_inet+0x161>
    1681:      	cmpl	$0x19, %ecx
    1684:      	ja	0x16f1 <filter_inet+0x241>
    1686:      	movl	$0x500000, %r8d         # imm = 0x500000
    168c:      	btl	%ecx, %r8d
    1690:      	jb	0x1707 <filter_inet+0x257>
    1692:      	movl	$0xa00000, %r8d         # imm = 0xA00000
    1698:      	btl	%ecx, %r8d
    169c:      	jb	0x1717 <filter_inet+0x267>
    169e:      	movl	$0x3000000, %edx        # imm = 0x3000000
    16a3:      	btl	%ecx, %edx
    16a6:      	jae	0x16f1 <filter_inet+0x241>
    16a8:      	movzwl	0x26(%rsi), %eax
    16ac:      	cmpl	$0xa, %eax
    16af:      	je	0x1727 <filter_inet+0x277>
    16b1:      	cmpl	$0x2, %eax
    16b4:      	jne	0x1797 <filter_inet+0x2e7>
    16ba:      	movq	%rdi, %r12
    16bd:      	movl	0x10(%rdi), %eax
    16c0:      	movl	%eax, 0x8(%rsp)
    16c4:      	movq	(%rip), %rdi            # 0x16cb <filter_inet+0x21b>
    16cb:      	leaq	0x8(%rsp), %rsi
    16d0:      	movl	$0x1, %eax
    16d5:      	callq	*%rax
    16d7:      	testq	%rax, %rax
    16da:      	je	0x17b9 <filter_inet+0x309>
    16e0:      	movq	%rax, %rdi
    16e3:      	movl	$0x20, 0xc(%rsp)
    16eb:      	movl	%ebx, 0x10(%rsp)
    16ef:      	jmp	0x176b <filter_inet+0x2bb>
    16f1:      	addl	$-0x12, %ecx
    16f4:      	cmpl	$0x2, %ecx
    16f7:      	jae	0x17ad <filter_inet+0x2fd>
    16fd:      	leaq	0x4(%rsp), %rsi
    1702:      	jmp	0x17a8 <filter_inet+0x2f8>
    1707:      	xorl	%eax, %eax
    1709:      	cmpl	$0x400, %edx            # imm = 0x400
    170f:      	setb	%al
    1712:      	jmp	0x17ad <filter_inet+0x2fd>
    1717:      	xorl	%eax, %eax
    1719:      	cmpl	$0x400, %edx            # imm = 0x400
    171f:      	setae	%al
    1722:      	jmp	0x17ad <filter_inet+0x2fd>
    1727:      	movq	%rdi, %r12
    172a:      	movl	0x14(%rdi), %eax
    172d:      	movl	%eax, 0x8(%rsp)
    1731:      	movq	(%rip), %rdi            # 0x1738 <filter_inet+0x288>
    1738:      	leaq	0x8(%rsp), %rsi
    173d:      	movl	$0x1, %eax
    1742:      	callq	*%rax
    1744:      	testq	%rax, %rax
    1747:      	je	0x17b9 <filter_inet+0x309>
    1749:      	movq	%rax, %rdi
    174c:      	movl	$0x80, 0xc(%rsp)
    1754:      	movl	%ebx, 0x10(%rsp)
    1758:      	movl	%r15d, 0x14(%rsp)
    175d:      	movl	%r14d, 0x18(%rsp)
    1762:      	shrq	$0x20, %r14
    1766:      	movl	%r14d, 0x1c(%rsp)
    176b:      	leaq	0xc(%rsp), %rsi
    1770:      	movl	$0x1, %eax
    1775:      	callq	*%rax
    1777:      	movl	0x4(%r12), %ecx
    177c:      	leal	-0x18(%rcx), %edx
    177f:      	cmpl	$0x2, %edx
    1782:      	jb	0x17c6 <filter_inet+0x316>
    1784:      	addl	$-0xd, %ecx
    1787:      	cmpl	$0x1, %ecx
    178a:      	ja	0x1797 <filter_inet+0x2e7>
    178c:      	testq	%rax, %rax
    178f:      	setne	%al
    1792:      	movzbl	%al, %eax
    1795:      	jmp	0x17ad <filter_inet+0x2fd>
    1797:      	xorl	%eax, %eax
    1799:      	movzbl	%al, %eax
    179c:      	jmp	0x17ad <filter_inet+0x2fd>
    179e:      	movzwl	0x26(%rsi), %eax
    17a2:      	movl	%eax, (%rsp)
    17a5:      	movq	%rsp, %rsi
    17a8:      	callq	0x800 <filter_32ty_map>
    17ad:      	addq	$0x48, %rsp
    17b1:      	popq	%rbx
    17b2:      	popq	%r12
    17b4:      	popq	%r14
    17b6:      	popq	%r15
    17b8:      	retq
    17b9:      	movl	0x4(%r12), %eax
    17be:      	andl	$-0x2, %eax
    17c1:      	cmpl	$0x18, %eax
    17c4:      	jmp	0x17c9 <filter_inet+0x319>
    17c6:      	testq	%rax, %rax
    17c9:      	sete	%al
    17cc:      	movzbl	%al, %eax
    17cf:      	jmp	0x17ad <filter_inet+0x2fd>
    17d1:      	cmpl	$0x29, %edx
    17d4:      	jne	0x17e3 <filter_inet+0x333>
    17d6:      	testq	%r8, %r8
    17d9:      	je	0x17e3 <filter_inet+0x333>
    17db:      	movzbl	0x3a(%r8), %eax
    17e0:      	movl	%eax, (%rsp)
    17e3:      	cmpl	$0x29, %edx
    17e6:      	je	0x17a5 <filter_inet+0x2f5>
    17e8:      	cmpl	$0x7, %edx
    17eb:      	je	0x17a5 <filter_inet+0x2f5>
    17ed:      	xorl	%eax, %eax
    17ef:      	jmp	0x17ad <filter_inet+0x2fd>
    17f1:      	nopw	%cs:(%rax,%rax)

0000000000001800 <filter_sockaddr_un>:
    1800:      	pushq	%rbx
    1801:      	subq	$0x10, %rsp
    1805:      	movq	%rsi, %rcx
    1808:      	addq	$0x4, %rsi
    180c:      	movzbl	0x3(%rcx), %edx
    1810:      	movl	0x4(%rdi), %r8d
    1814:      	xorl	%eax, %eax
    1816:      	cmpl	$0x19, %r8d
    181a:      	jg	0x1850 <filter_sockaddr_un+0x50>
    181c:      	leal	-0x3(%r8), %ecx
    1820:      	cmpl	$0x2, %ecx
    1823:      	jae	0x185e <filter_sockaddr_un+0x5e>
    1825:      	movq	%rdi, %rbx
    1828:      	callq	0x18b0 <filter_char_buf_equal>
    182d:      	movl	0x4(%rbx), %ecx
    1830:      	cmpq	$0x25, %rcx
    1834:      	ja	0x184a <filter_sockaddr_un+0x4a>
    1836:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1840:      	btq	%rcx, %rdx
    1844:      	jae	0x184a <filter_sockaddr_un+0x4a>
    1846:      	xorq	$0x1, %rax
    184a:      	addq	$0x10, %rsp
    184e:      	popq	%rbx
    184f:      	retq
    1850:      	cmpl	$0x1c, %r8d
    1854:      	je	0x1894 <filter_sockaddr_un+0x94>
    1856:      	cmpl	$0x1a, %r8d
    185a:      	je	0x1864 <filter_sockaddr_un+0x64>
    185c:      	jmp	0x184a <filter_sockaddr_un+0x4a>
    185e:      	cmpl	$0x8, %r8d
    1862:      	jne	0x184a <filter_sockaddr_un+0x4a>
    1864:      	movl	0x10(%rdi), %eax
    1867:      	movq	%rdi, %rbx
    186a:      	movl	%eax, %edi
    186c:      	callq	0x1c30 <filter_char_buf_prefix>
    1871:      	movl	0x4(%rbx), %ecx
    1874:      	cmpq	$0x25, %rcx
    1878:      	ja	0x184a <filter_sockaddr_un+0x4a>
    187a:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1884:      	btq	%rcx, %rdx
    1888:      	jae	0x184a <filter_sockaddr_un+0x4a>
    188a:      	xorq	$0x1, %rax
    188e:      	addq	$0x10, %rsp
    1892:      	popq	%rbx
    1893:      	retq
    1894:      	movzwl	(%rcx), %eax
    1897:      	movl	%eax, 0xc(%rsp)
    189b:      	leaq	0xc(%rsp), %rsi
    18a0:      	callq	0x800 <filter_32ty_map>
    18a5:      	addq	$0x10, %rsp
    18a9:      	popq	%rbx
    18aa:      	retq
    18ab:      	nopl	(%rax,%rax)

00000000000018b0 <filter_char_buf_equal>:
    18b0:      	pushq	%rbp
    18b1:      	pushq	%r15
    18b3:      	pushq	%r14
    18b5:      	pushq	%r13
    18b7:      	pushq	%r12
    18b9:      	pushq	%rbx
    18ba:      	subq	$0x28, %rsp
    18be:      	movl	$0x0, 0x14(%rsp)
    18c6:      	cmpl	$0x1000, %edx           # imm = 0x1000
    18cc:      	ja	0x1c1e <filter_char_buf_equal+0x36e>
    18d2:      	movl	%edx, %ebp
    18d4:      	movzwl	%bp, %eax
    18d7:      	cmpl	$0x90, %eax
    18dc:      	ja	0x1925 <filter_char_buf_equal+0x75>
    18de:      	testw	%bp, %bp
    18e1:      	je	0x18f4 <filter_char_buf_equal+0x44>
    18e3:      	movl	$0x18, %ecx
    18e8:      	movl	%ebp, %eax
    18ea:      	cltd
    18eb:      	idivl	%ecx
    18ed:      	movl	%ebp, %r14d
    18f0:      	testl	%edx, %edx
    18f2:      	je	0x1914 <filter_char_buf_equal+0x64>
    18f4:      	movl	$0x18, %ecx
    18f9:      	movl	%ebp, %eax
    18fb:      	cltd
    18fc:      	idivl	%ecx
    18fe:      	shll	$0x3, %eax
    1901:      	leal	(%rax,%rax,2), %eax
    1904:      	addl	$0x18, %eax
    1907:      	movzwl	%ax, %r14d
    190b:      	cmpl	$0x90, %r14d
    1912:      	ja	0x1963 <filter_char_buf_equal+0xb3>
    1914:      	movl	%r14d, %eax
    1917:      	cltd
    1918:      	idivl	%ecx
    191a:      	movl	%eax, %r15d
    191d:      	decl	%r15d
    1920:      	jmp	0x19ae <filter_char_buf_equal+0xfe>
    1925:      	movl	$0x100, %r14d           # imm = 0x100
    192b:      	cmpl	$0x101, %eax            # imm = 0x101
    1930:      	jb	0x1963 <filter_char_buf_equal+0xb3>
    1932:      	movl	$0x200, %r14d           # imm = 0x200
    1938:      	cmpl	$0x201, %eax            # imm = 0x201
    193d:      	jb	0x1963 <filter_char_buf_equal+0xb3>
    193f:      	movl	$0x400, %r14d           # imm = 0x400
    1945:      	cmpl	$0x401, %eax            # imm = 0x401
    194a:      	jb	0x1963 <filter_char_buf_equal+0xb3>
    194c:      	xorl	%r14d, %r14d
    194f:      	cmpl	$0x801, %eax            # imm = 0x801
    1954:      	setae	%r14b
    1958:      	shll	$0xb, %r14d
    195c:      	addl	$0x800, %r14d           # imm = 0x800
    1963:      	leal	-0x100(%r14), %eax
    196a:      	rorxl	$0x8, %eax, %eax
    1970:      	cmpl	$0x2, %eax
    1973:      	jg	0x1986 <filter_char_buf_equal+0xd6>
    1975:      	testl	%eax, %eax
    1977:      	je	0x19a0 <filter_char_buf_equal+0xf0>
    1979:      	cmpl	$0x1, %eax
    197c:      	jne	0x1998 <filter_char_buf_equal+0xe8>
    197e:      	movl	$0x7, %r15d
    1984:      	jmp	0x19ae <filter_char_buf_equal+0xfe>
    1986:      	cmpl	$0x3, %eax
    1989:      	je	0x19a8 <filter_char_buf_equal+0xf8>
    198b:      	cmpl	$0x7, %eax
    198e:      	jne	0x1998 <filter_char_buf_equal+0xe8>
    1990:      	movl	$0x9, %r15d
    1996:      	jmp	0x19ae <filter_char_buf_equal+0xfe>
    1998:      	movl	$0xa, %r15d
    199e:      	jmp	0x19ae <filter_char_buf_equal+0xfe>
    19a0:      	movl	$0x6, %r15d
    19a6:      	jmp	0x19ae <filter_char_buf_equal+0xfe>
    19a8:      	movl	$0x8, %r15d
    19ae:      	movl	%r15d, %eax
    19b1:      	andl	$0xf, %eax
    19b4:      	movl	0x10(%rdi,%rax,4), %r13d
    19b9:      	cmpl	$-0x1, %r13d
    19bd:      	je	0x1c1e <filter_char_buf_equal+0x36e>
    19c3:      	movq	%rsi, 0x20(%rsp)
    19c8:      	movq	(%rip), %rdi            # 0x19cf <filter_char_buf_equal+0x11f>
    19cf:      	leaq	0x14(%rsp), %r12
    19d4:      	movl	$0x1, %eax
    19d9:      	movq	%r12, %rsi
    19dc:      	callq	*%rax
    19de:      	movq	%rax, %rbx
    19e1:      	movq	(%rip), %rdi            # 0x19e8 <filter_char_buf_equal+0x138>
    19e8:      	movl	$0x1, %eax
    19ed:      	movq	%r12, %rsi
    19f0:      	callq	*%rax
    19f2:      	movq	%rax, %rcx
    19f5:      	xorl	%eax, %eax
    19f7:      	movq	%rbx, 0x8(%rsp)
    19fc:      	testq	%rbx, %rbx
    19ff:      	je	0x1c20 <filter_char_buf_equal+0x370>
    1a05:      	testq	%rcx, %rcx
    1a08:      	je	0x1c20 <filter_char_buf_equal+0x370>
    1a0e:      	movq	%rcx, 0x18(%rsp)
    1a13:      	cmpl	$0x5, %r15d
    1a17:      	jg	0x1a5a <filter_char_buf_equal+0x1aa>
    1a19:      	movq	0x8(%rsp), %rax
    1a1e:      	movb	%bpl, (%rax)
    1a21:      	leaq	0x1(%rax), %rdi
    1a25:      	movl	%ebp, %r12d
    1a28:      	movl	$0x4, %eax
    1a2d:      	movq	0x20(%rsp), %rdx
    1a32:      	movl	%ebp, %esi
    1a34:      	callq	*%rax
    1a36:      	subl	%ebp, %r14d
    1a39:      	jbe	0x1a9f <filter_char_buf_equal+0x1ef>
    1a3b:      	movq	0x8(%rsp), %rax
    1a40:      	leaq	(%rax,%r12), %rdi
    1a44:      	incq	%rdi
    1a47:      	andl	$0xfff, %r14d           # imm = 0xFFF
    1a4e:      	movl	$0x4, %eax
    1a53:      	movq	0x18(%rsp), %rdx
    1a58:      	jmp	0x1a9a <filter_char_buf_equal+0x1ea>
    1a5a:      	movq	0x8(%rsp), %rax
    1a5f:      	movw	%bp, (%rax)
    1a62:      	leaq	0x2(%rax), %rdi
    1a66:      	movl	%ebp, %r12d
    1a69:      	movl	$0x4, %eax
    1a6e:      	movq	0x20(%rsp), %rdx
    1a73:      	movl	%ebp, %esi
    1a75:      	callq	*%rax
    1a77:      	subl	%ebp, %r14d
    1a7a:      	jbe	0x1a9f <filter_char_buf_equal+0x1ef>
    1a7c:      	movq	0x8(%rsp), %rax
    1a81:      	leaq	(%rax,%r12), %rdi
    1a85:      	addq	$0x2, %rdi
    1a89:      	andl	$0xfff, %r14d           # imm = 0xFFF
    1a90:      	movl	$0x4, %eax
    1a95:      	movq	0x18(%rsp), %rdx
    1a9a:      	movl	%r14d, %esi
    1a9d:      	callq	*%rax
    1a9f:      	movl	%r13d, 0x4(%rsp)
    1aa4:      	cmpl	$0x4, %r15d
    1aa8:      	jle	0x1ae4 <filter_char_buf_equal+0x234>
    1aaa:      	cmpl	$0x7, %r15d
    1aae:      	jg	0x1b1e <filter_char_buf_equal+0x26e>
    1ab0:      	cmpl	$0x5, %r15d
    1ab4:      	je	0x1bd2 <filter_char_buf_equal+0x322>
    1aba:      	cmpl	$0x6, %r15d
    1abe:      	je	0x1b99 <filter_char_buf_equal+0x2e9>
    1ac4:      	cmpl	$0x7, %r15d
    1ac8:      	jne	0x1c1e <filter_char_buf_equal+0x36e>
    1ace:      	movq	(%rip), %rdi            # 0x1ad5 <filter_char_buf_equal+0x225>
    1ad5:      	leaq	0x4(%rsp), %rcx
    1ada:      	movl	$0x1, %eax
    1adf:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1ae4:      	cmpl	$0x1, %r15d
    1ae8:      	jle	0x1b4e <filter_char_buf_equal+0x29e>
    1aea:      	cmpl	$0x2, %r15d
    1aee:      	je	0x1bbf <filter_char_buf_equal+0x30f>
    1af4:      	cmpl	$0x3, %r15d
    1af8:      	je	0x1b86 <filter_char_buf_equal+0x2d6>
    1afe:      	cmpl	$0x4, %r15d
    1b02:      	jne	0x1c1e <filter_char_buf_equal+0x36e>
    1b08:      	movq	(%rip), %rdi            # 0x1b0f <filter_char_buf_equal+0x25f>
    1b0f:      	leaq	0x4(%rsp), %rcx
    1b14:      	movl	$0x1, %eax
    1b19:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1b1e:      	cmpl	$0x8, %r15d
    1b22:      	je	0x1be5 <filter_char_buf_equal+0x335>
    1b28:      	cmpl	$0x9, %r15d
    1b2c:      	je	0x1bac <filter_char_buf_equal+0x2fc>
    1b2e:      	cmpl	$0xa, %r15d
    1b32:      	jne	0x1c1e <filter_char_buf_equal+0x36e>
    1b38:      	movq	(%rip), %rdi            # 0x1b3f <filter_char_buf_equal+0x28f>
    1b3f:      	leaq	0x4(%rsp), %rcx
    1b44:      	movl	$0x1, %eax
    1b49:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1b4e:      	testl	%r15d, %r15d
    1b51:      	je	0x1b73 <filter_char_buf_equal+0x2c3>
    1b53:      	cmpl	$0x1, %r15d
    1b57:      	jne	0x1c1e <filter_char_buf_equal+0x36e>
    1b5d:      	movq	(%rip), %rdi            # 0x1b64 <filter_char_buf_equal+0x2b4>
    1b64:      	leaq	0x4(%rsp), %rcx
    1b69:      	movl	$0x1, %eax
    1b6e:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1b73:      	movq	(%rip), %rdi            # 0x1b7a <filter_char_buf_equal+0x2ca>
    1b7a:      	leaq	0x4(%rsp), %rcx
    1b7f:      	movl	$0x1, %eax
    1b84:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1b86:      	movq	(%rip), %rdi            # 0x1b8d <filter_char_buf_equal+0x2dd>
    1b8d:      	leaq	0x4(%rsp), %rcx
    1b92:      	movl	$0x1, %eax
    1b97:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1b99:      	movq	(%rip), %rdi            # 0x1ba0 <filter_char_buf_equal+0x2f0>
    1ba0:      	leaq	0x4(%rsp), %rcx
    1ba5:      	movl	$0x1, %eax
    1baa:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1bac:      	movq	(%rip), %rdi            # 0x1bb3 <filter_char_buf_equal+0x303>
    1bb3:      	leaq	0x4(%rsp), %rcx
    1bb8:      	movl	$0x1, %eax
    1bbd:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1bbf:      	movq	(%rip), %rdi            # 0x1bc6 <filter_char_buf_equal+0x316>
    1bc6:      	leaq	0x4(%rsp), %rcx
    1bcb:      	movl	$0x1, %eax
    1bd0:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1bd2:      	movq	(%rip), %rdi            # 0x1bd9 <filter_char_buf_equal+0x329>
    1bd9:      	leaq	0x4(%rsp), %rcx
    1bde:      	movl	$0x1, %eax
    1be3:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1be5:      	movq	(%rip), %rdi            # 0x1bec <filter_char_buf_equal+0x33c>
    1bec:      	leaq	0x4(%rsp), %rcx
    1bf1:      	movl	$0x1, %eax
    1bf6:      	leaq	0x4(%rsp), %rsi
    1bfb:      	callq	*%rax
    1bfd:      	testq	%rax, %rax
    1c00:      	je	0x1c1e <filter_char_buf_equal+0x36e>
    1c02:      	movq	%rax, %rdi
    1c05:      	movl	$0x1, %eax
    1c0a:      	movq	0x8(%rsp), %rsi
    1c0f:      	callq	*%rax
    1c11:      	movq	%rax, %rcx
    1c14:      	xorl	%eax, %eax
    1c16:      	testq	%rcx, %rcx
    1c19:      	setne	%al
    1c1c:      	jmp	0x1c20 <filter_char_buf_equal+0x370>
    1c1e:      	xorl	%eax, %eax
    1c20:      	addq	$0x28, %rsp
    1c24:      	popq	%rbx
    1c25:      	popq	%r12
    1c27:      	popq	%r13
    1c29:      	popq	%r14
    1c2b:      	popq	%r15
    1c2d:      	popq	%rbp
    1c2e:      	retq
    1c2f:      	nop

0000000000001c30 <filter_char_buf_prefix>:
    1c30:      	pushq	%rbp
    1c31:      	pushq	%r15
    1c33:      	pushq	%r14
    1c35:      	pushq	%rbx
    1c36:      	pushq	%rax
    1c37:      	movl	%edx, %ebp
    1c39:      	movq	%rsi, %rbx
    1c3c:      	movl	%edi, 0x4(%rsp)
    1c40:      	movl	$0x0, (%rsp)
    1c47:      	movq	(%rip), %rdi            # 0x1c4e <filter_char_buf_prefix+0x1e>
    1c4e:      	leaq	0x4(%rsp), %rsi
    1c53:      	movl	$0x1, %eax
    1c58:      	callq	*%rax
    1c5a:      	movq	%rax, %r14
    1c5d:      	xorl	%eax, %eax
    1c5f:      	testl	%ebp, %ebp
    1c61:      	je	0x1cc5 <filter_char_buf_prefix+0x95>
    1c63:      	testq	%r14, %r14
    1c66:      	je	0x1cc5 <filter_char_buf_prefix+0x95>
    1c68:      	movq	(%rip), %rdi            # 0x1c6f <filter_char_buf_prefix+0x3f>
    1c6f:      	movq	%rsp, %rsi
    1c72:      	movl	$0x1, %eax
    1c77:      	callq	*%rax
    1c79:      	testq	%rax, %rax
    1c7c:      	je	0x1cc3 <filter_char_buf_prefix+0x93>
    1c7e:      	cmpl	$0xff, %ebp
    1c84:      	movl	$0xff, %esi
    1c89:      	cmovbl	%ebp, %esi
    1c8c:      	leal	(,%rsi,8), %ecx
    1c93:      	movl	%ecx, (%rax)
    1c95:      	movq	%rax, %rdi
    1c98:      	addq	$0x4, %rdi
    1c9c:      	movq	%rax, %r15
    1c9f:      	movl	$0x4, %eax
    1ca4:      	movq	%rbx, %rdx
    1ca7:      	callq	*%rax
    1ca9:      	movl	$0x1, %eax
    1cae:      	movq	%r14, %rdi
    1cb1:      	movq	%r15, %rsi
    1cb4:      	callq	*%rax
    1cb6:      	movq	%rax, %rcx
    1cb9:      	xorl	%eax, %eax
    1cbb:      	testq	%rcx, %rcx
    1cbe:      	setne	%al
    1cc1:      	jmp	0x1cc5 <filter_char_buf_prefix+0x95>
    1cc3:      	xorl	%eax, %eax
    1cc5:      	addq	$0x8, %rsp
    1cc9:      	popq	%rbx
    1cca:      	popq	%r14
    1ccc:      	popq	%r15
    1cce:      	popq	%rbp
    1ccf:      	retq

0000000000001cd0 <filter_char_buf_postfix>:
    1cd0:      	pushq	%r15
    1cd2:      	pushq	%r14
    1cd4:      	pushq	%rbx
    1cd5:      	subq	$0x10, %rsp
    1cd9:      	movl	%edx, %ebx
    1cdb:      	movq	%rsi, %r14
    1cde:      	movl	%edi, 0xc(%rsp)
    1ce2:      	movl	$0x0, 0x8(%rsp)
    1cea:      	movq	(%rip), %rdi            # 0x1cf1 <filter_char_buf_postfix+0x21>
    1cf1:      	leaq	0xc(%rsp), %rsi
    1cf6:      	movl	$0x1, %eax
    1cfb:      	callq	*%rax
    1cfd:      	movq	%rax, %r15
    1d00:      	xorl	%eax, %eax
    1d02:      	testl	%ebx, %ebx
    1d04:      	je	0x1e10 <filter_char_buf_postfix+0x140>
    1d0a:      	testq	%r15, %r15
    1d0d:      	je	0x1e10 <filter_char_buf_postfix+0x140>
    1d13:      	movq	(%rip), %rdi            # 0x1d1a <filter_char_buf_postfix+0x4a>
    1d1a:      	leaq	0x8(%rsp), %rsi
    1d1f:      	movl	$0x1, %eax
    1d24:      	callq	*%rax
    1d26:      	testq	%rax, %rax
    1d29:      	je	0x1e0e <filter_char_buf_postfix+0x13e>
    1d2f:      	movq	%rax, %rsi
    1d32:      	cmpl	$0x7f, %ebx
    1d35:      	movl	$0x7f, %eax
    1d3a:      	cmovbl	%ebx, %eax
    1d3d:      	shll	$0x3, %eax
    1d40:      	movl	%eax, (%rsi)
    1d42:      	movl	%ebx, %eax
    1d44:      	leal	-0x4(%rbx), %ecx
    1d47:      	movq	%rsi, %rdx
    1d4a:      	addq	$0x7, %rdx
    1d4e:      	leal	-0x3(%rbx), %edi
    1d51:      	leal	-0x2(%rbx), %r8d
    1d55:      	decl	%ebx
    1d57:      	movq	$-0x3, %r9
    1d5e:      	nop
    1d60:      	leal	(%rbx,%r9), %r10d
    1d64:      	addl	$0x3, %r10d
    1d68:      	andl	$0xfff, %r10d           # imm = 0xFFF
    1d6f:      	movzbl	(%r14,%r10), %r10d
    1d74:      	movb	%r10b, -0x3(%rdx)
    1d78:      	leaq	(%rax,%r9), %r10
    1d7c:      	cmpq	$-0x2, %r10
    1d80:      	je	0x1df7 <filter_char_buf_postfix+0x127>
    1d82:      	leal	(%r8,%r9), %r11d
    1d86:      	addl	$0x3, %r11d
    1d8a:      	andl	$0xfff, %r11d           # imm = 0xFFF
    1d91:      	movzbl	(%r14,%r11), %r11d
    1d96:      	movb	%r11b, -0x2(%rdx)
    1d9a:      	cmpq	$-0x1, %r10
    1d9e:      	je	0x1df7 <filter_char_buf_postfix+0x127>
    1da0:      	leal	(%rdi,%r9), %r10d
    1da4:      	addl	$0x3, %r10d
    1da8:      	andl	$0xfff, %r10d           # imm = 0xFFF
    1daf:      	movzbl	(%r14,%r10), %r10d
    1db4:      	movb	%r10b, -0x1(%rdx)
    1db8:      	movq	%rax, %r10
    1dbb:      	addq	%r9, %r10
    1dbe:      	je	0x1df7 <filter_char_buf_postfix+0x127>
    1dc0:      	cmpq	$-0x7f, %r9
    1dc4:      	je	0x1df7 <filter_char_buf_postfix+0x127>
    1dc6:      	leal	(%rcx,%r9), %r10d
    1dca:      	addl	$0x3, %r10d
    1dce:      	andl	$0xfff, %r10d           # imm = 0xFFF
    1dd5:      	movzbl	(%r14,%r10), %r10d
    1dda:      	movb	%r10b, (%rdx)
    1ddd:      	addq	$0x4, %rdx
    1de1:      	leaq	(%rax,%r9), %r10
    1de5:      	addq	$-0x4, %r10
    1de9:      	addq	$-0x4, %r9
    1ded:      	cmpq	$-0x3, %r10
    1df1:      	jne	0x1d60 <filter_char_buf_postfix+0x90>
    1df7:      	movl	$0x1, %eax
    1dfc:      	movq	%r15, %rdi
    1dff:      	callq	*%rax
    1e01:      	movq	%rax, %rcx
    1e04:      	xorl	%eax, %eax
    1e06:      	testq	%rcx, %rcx
    1e09:      	setne	%al
    1e0c:      	jmp	0x1e10 <filter_char_buf_postfix+0x140>
    1e0e:      	xorl	%eax, %eax
    1e10:      	addq	$0x10, %rsp
    1e14:      	popq	%rbx
    1e15:      	popq	%r14
    1e17:      	popq	%r15
    1e19:      	retq
    1e1a:      	nopw	(%rax,%rax)

0000000000001e20 <filter_file_type>:
    1e20:      	pushq	%rbx
    1e21:      	subq	$0x10, %rsp
    1e25:      	movw	$0x0, 0xe(%rsp)
    1e2c:      	movl	(%rsi), %eax
    1e2e:      	cmpq	$0x1000, %rax           # imm = 0x1000
    1e34:      	ja	0x1ebc <filter_file_type+0x9c>
    1e3a:      	movq	%rdi, %rbx
    1e3d:      	leaq	(%rsi,%rax), %rcx
    1e41:      	addq	$0x8, %rcx
    1e45:      	leaq	0xe(%rsp), %rdi
    1e4a:      	movl	$0x2, %edx
    1e4f:      	movl	$0x4, %eax
    1e54:      	movl	(%rsi), %ecx
    1e56:      	leaq	(%rsi,%rcx), %rdx
    1e5a:      	addq	$0x8, %rdx
    1e5e:      	movl	$0x2, %esi
    1e63:      	callq	*%rax
    1e65:      	movl	0x10(%rbx), %edx
    1e68:      	testl	%edx, %edx
    1e6a:      	je	0x1ebc <filter_file_type+0x9c>
    1e6c:      	movzwl	0xe(%rsp), %ecx
    1e71:      	andl	$0xf000, %ecx           # imm = 0xF000
    1e77:      	movl	$0x1, %eax
    1e7c:      	cmpl	%ecx, %edx
    1e7e:      	je	0x1ebe <filter_file_type+0x9e>
    1e80:      	movl	0x8(%rbx), %edx
    1e83:      	cmpl	$0xc, %edx
    1e86:      	jbe	0x1ebc <filter_file_type+0x9c>
    1e88:      	movl	0x14(%rbx), %esi
    1e8b:      	testl	%esi, %esi
    1e8d:      	je	0x1ebc <filter_file_type+0x9c>
    1e8f:      	cmpl	%ecx, %esi
    1e91:      	je	0x1ebe <filter_file_type+0x9e>
    1e93:      	cmpl	$0x11, %edx
    1e96:      	jb	0x1ebc <filter_file_type+0x9c>
    1e98:      	movl	0x18(%rbx), %esi
    1e9b:      	testl	%esi, %esi
    1e9d:      	je	0x1ebc <filter_file_type+0x9c>
    1e9f:      	cmpl	%ecx, %esi
    1ea1:      	je	0x1ebe <filter_file_type+0x9e>
    1ea3:      	cmpl	$0x15, %edx
    1ea6:      	jb	0x1ebc <filter_file_type+0x9c>
    1ea8:      	movl	0x1c(%rbx), %edx
    1eab:      	testl	%edx, %edx
    1ead:      	je	0x1ebc <filter_file_type+0x9c>
    1eaf:      	xorl	%eax, %eax
    1eb1:      	cmpl	%ecx, %edx
    1eb3:      	sete	%al
    1eb6:      	addq	$0x10, %rsp
    1eba:      	popq	%rbx
    1ebb:      	retq
    1ebc:      	xorl	%eax, %eax
    1ebe:      	addq	$0x10, %rsp
    1ec2:      	popq	%rbx
    1ec3:      	retq
    1ec4:      	nopw	%cs:(%rax,%rax)

0000000000001ed0 <filter_char_substring>:
    1ed0:      	pushq	%rbp
    1ed1:      	pushq	%r15
    1ed3:      	pushq	%r14
    1ed5:      	pushq	%r13
    1ed7:      	pushq	%r12
    1ed9:      	pushq	%rbx
    1eda:      	pushq	%rax
    1edb:      	movq	%rsi, %r15
    1ede:      	movq	%rdi, %r14
    1ee1:      	movl	%edx, %ebp
    1ee3:      	testl	%ecx, %ecx
    1ee5:      	je	0x1fbd <filter_char_substring+0xed>
    1eeb:      	testl	%edx, %edx
    1eed:      	je	0x206d <filter_char_substring+0x19d>
    1ef3:      	leaq	0x4(%rsp), %r13
    1ef8:      	xorl	%ebx, %ebx
    1efa:      	xorl	%r12d, %r12d
    1efd:      	nopl	(%rax)
    1f00:      	movl	0x10(%r14,%rbx,4), %eax
    1f05:      	movl	%eax, 0x4(%rsp)
    1f09:      	movl	$0x1, %eax
    1f0e:      	movq	(%rip), %rdi            # 0x1f15 <filter_char_substring+0x45>
    1f15:      	movq	%r13, %rsi
    1f18:      	callq	*%rax
    1f1a:      	testq	%rax, %rax
    1f1d:      	je	0x2100 <filter_char_substring+0x230>
    1f23:      	movq	%r15, %rdx
    1f26:      	xorl	%ecx, %ecx
    1f28:      	jmp	0x1f3b <filter_char_substring+0x6b>
    1f2a:      	nopw	(%rax,%rax)
    1f30:      	incq	%rcx
    1f33:      	incq	%rdx
    1f36:      	cmpq	%rbp, %rcx
    1f39:      	je	0x1f98 <filter_char_substring+0xc8>
    1f3b:      	xorl	%esi, %esi
    1f3d:      	nopl	(%rax)
    1f40:      	leaq	(%rcx,%rsi), %rdi
    1f44:      	cmpq	%rbp, %rdi
    1f47:      	jae	0x1f30 <filter_char_substring+0x60>
    1f49:      	movsbl	(%rax,%rsi), %edi
    1f4d:      	testl	%edi, %edi
    1f4f:      	je	0x1f90 <filter_char_substring+0xc0>
    1f51:      	movsbl	(%rdx,%rsi), %r9d
    1f56:      	leal	-0x41(%r9), %r10d
    1f5a:      	movl	%r9d, %r8d
    1f5d:      	orl	$0x20, %r8d
    1f61:      	cmpl	$0x1a, %r10d
    1f65:      	cmovael	%r9d, %r8d
    1f69:      	leal	-0x41(%rdi), %r10d
    1f6d:      	movl	%edi, %r9d
    1f70:      	orl	$0x20, %r9d
    1f74:      	cmpl	$0x1a, %r10d
    1f78:      	cmovael	%edi, %r9d
    1f7c:      	cmpq	$0x62, %rsi
    1f80:      	ja	0x1f30 <filter_char_substring+0x60>
    1f82:      	incq	%rsi
    1f85:      	cmpl	%r9d, %r8d
    1f88:      	je	0x1f40 <filter_char_substring+0x70>
    1f8a:      	jmp	0x1f30 <filter_char_substring+0x60>
    1f8c:      	nopl	(%rax)
    1f90:      	testl	%ecx, %ecx
    1f92:      	jns	0x2111 <filter_char_substring+0x241>
    1f98:      	leal	0xc(%r12), %eax
    1f9d:      	cmpl	0x8(%r14), %eax
    1fa1:      	jae	0x2100 <filter_char_substring+0x230>
    1fa7:      	addl	$0x4, %r12d
    1fab:      	incq	%rbx
    1fae:      	cmpq	$0x64, %rbx
    1fb2:      	jne	0x1f00 <filter_char_substring+0x30>
    1fb8:      	jmp	0x2100 <filter_char_substring+0x230>
    1fbd:      	testl	%edx, %edx
    1fbf:      	je	0x20b2 <filter_char_substring+0x1e2>
    1fc5:      	leaq	0x4(%rsp), %r13
    1fca:      	xorl	%ebx, %ebx
    1fcc:      	xorl	%r12d, %r12d
    1fcf:      	nop
    1fd0:      	movl	0x10(%r14,%rbx,4), %eax
    1fd5:      	movl	%eax, 0x4(%rsp)
    1fd9:      	movl	$0x1, %eax
    1fde:      	movq	(%rip), %rdi            # 0x1fe5 <filter_char_substring+0x115>
    1fe5:      	movq	%r13, %rsi
    1fe8:      	callq	*%rax
    1fea:      	testq	%rax, %rax
    1fed:      	je	0x2100 <filter_char_substring+0x230>
    1ff3:      	movq	%r15, %rdx
    1ff6:      	xorl	%ecx, %ecx
    1ff8:      	jmp	0x200b <filter_char_substring+0x13b>
    1ffa:      	nopw	(%rax,%rax)
    2000:      	incq	%rcx
    2003:      	incq	%rdx
    2006:      	cmpq	%rbp, %rcx
    2009:      	je	0x2048 <filter_char_substring+0x178>
    200b:      	xorl	%esi, %esi
    200d:      	nopl	(%rax)
    2010:      	leaq	(%rcx,%rsi), %rdi
    2014:      	cmpq	%rbp, %rdi
    2017:      	jae	0x2000 <filter_char_substring+0x130>
    2019:      	movzbl	(%rax,%rsi), %edi
    201d:      	testb	%dil, %dil
    2020:      	je	0x2040 <filter_char_substring+0x170>
    2022:      	cmpq	$0x62, %rsi
    2026:      	ja	0x2000 <filter_char_substring+0x130>
    2028:      	leaq	0x1(%rsi), %r8
    202c:      	cmpb	%dil, (%rdx,%rsi)
    2030:      	movq	%r8, %rsi
    2033:      	je	0x2010 <filter_char_substring+0x140>
    2035:      	jmp	0x2000 <filter_char_substring+0x130>
    2037:      	nopw	(%rax,%rax)
    2040:      	testl	%ecx, %ecx
    2042:      	jns	0x2111 <filter_char_substring+0x241>
    2048:      	leal	0xc(%r12), %eax
    204d:      	cmpl	0x8(%r14), %eax
    2051:      	jae	0x2100 <filter_char_substring+0x230>
    2057:      	addl	$0x4, %r12d
    205b:      	incq	%rbx
    205e:      	cmpq	$0x64, %rbx
    2062:      	jne	0x1fd0 <filter_char_substring+0x100>
    2068:      	jmp	0x2100 <filter_char_substring+0x230>
    206d:      	movl	$0x10, %ebx
    2072:      	movq	(%rip), %r15            # 0x2079 <filter_char_substring+0x1a9>
    2079:      	leaq	0x4(%rsp), %r12
    207e:      	nop
    2080:      	movl	(%r14,%rbx), %eax
    2084:      	movl	%eax, 0x4(%rsp)
    2088:      	movl	$0x1, %eax
    208d:      	movq	%r15, %rdi
    2090:      	movq	%r12, %rsi
    2093:      	callq	*%rax
    2095:      	testq	%rax, %rax
    2098:      	je	0x2100 <filter_char_substring+0x230>
    209a:      	addq	$0x4, %rbx
    209e:      	leal	-0x8(%rbx), %eax
    20a1:      	cmpl	0x8(%r14), %eax
    20a5:      	jae	0x2100 <filter_char_substring+0x230>
    20a7:      	cmpq	$0x1a0, %rbx            # imm = 0x1A0
    20ae:      	jne	0x2080 <filter_char_substring+0x1b0>
    20b0:      	jmp	0x2100 <filter_char_substring+0x230>
    20b2:      	movl	$0x10, %ebx
    20b7:      	movq	(%rip), %r15            # 0x20be <filter_char_substring+0x1ee>
    20be:      	leaq	0x4(%rsp), %r12
    20c3:      	nopw	%cs:(%rax,%rax)
    20d0:      	movl	(%r14,%rbx), %eax
    20d4:      	movl	%eax, 0x4(%rsp)
    20d8:      	movl	$0x1, %eax
    20dd:      	movq	%r15, %rdi
    20e0:      	movq	%r12, %rsi
    20e3:      	callq	*%rax
    20e5:      	testq	%rax, %rax
    20e8:      	je	0x2100 <filter_char_substring+0x230>
    20ea:      	addq	$0x4, %rbx
    20ee:      	leal	-0x8(%rbx), %eax
    20f1:      	cmpl	0x8(%r14), %eax
    20f5:      	jae	0x2100 <filter_char_substring+0x230>
    20f7:      	cmpq	$0x1a0, %rbx            # imm = 0x1A0
    20fe:      	jne	0x20d0 <filter_char_substring+0x200>
    2100:      	xorl	%eax, %eax
    2102:      	addq	$0x8, %rsp
    2106:      	popq	%rbx
    2107:      	popq	%r12
    2109:      	popq	%r13
    210b:      	popq	%r14
    210d:      	popq	%r15
    210f:      	popq	%rbp
    2110:      	retq
    2111:      	movl	$0x1, %eax
    2116:      	jmp	0x2102 <filter_char_substring+0x232>
    2118:      	nopl	(%rax,%rax)

0000000000002120 <do_action>:
    2120:      	pushq	%rbp
    2121:      	pushq	%r15
    2123:      	pushq	%r14
    2125:      	pushq	%r13
    2127:      	pushq	%r12
    2129:      	pushq	%rbx
    212a:      	subq	$0x78, %rsp
    212e:      	movl	%r8d, %ebp
    2131:      	movq	%rcx, 0x38(%rsp)
    2136:      	movq	%rdx, %r15
    2139:      	movl	%esi, %ebx
    213b:      	movq	%rdi, %r14
    213e:      	movl	%esi, %eax
    2140:      	movslq	0x4(%rdx,%rax,4), %r12
    2145:      	movl	$0x0, 0x50(%rsp)
    214d:      	movq	(%rip), %rdi            # 0x2154 <do_action+0x34>
    2154:      	leaq	0x50(%rsp), %rsi
    2159:      	movl	$0x1, %eax
    215e:      	callq	*%rax
    2160:      	movq	%rax, %r13
    2163:      	xorl	%eax, %eax
    2165:      	testq	%r13, %r13
    2168:      	je	0x2980 <do_action+0x860>
    216e:      	cmpl	$0x7, %r12d
    2172:      	jg	0x219c <do_action+0x7c>
    2174:      	cmpl	$0x3, %r12d
    2178:      	jg	0x21d4 <do_action+0xb4>
    217a:      	cmpl	$0x1, %r12d
    217e:      	jg	0x2307 <do_action+0x1e7>
    2184:      	testl	%r12d, %r12d
    2187:      	je	0x25ac <do_action+0x48c>
    218d:      	cmpl	$0x1, %r12d
    2191:      	je	0x2320 <do_action+0x200>
    2197:      	jmp	0x2978 <do_action+0x858>
    219c:      	cmpl	$0xb, %r12d
    21a0:      	jg	0x22d9 <do_action+0x1b9>
    21a6:      	leal	-0xa(%r12), %ecx
    21ab:      	cmpl	$0x2, %ecx
    21ae:      	jb	0x242b <do_action+0x30b>
    21b4:      	cmpl	$0x8, %r12d
    21b8:      	je	0x2518 <do_action+0x3f8>
    21be:      	cmpl	$0x9, %r12d
    21c2:      	jne	0x2978 <do_action+0x858>
    21c8:      	incl	%ebx
    21ca:      	movl	0x4(%r15,%rbx,4), %eax
    21cf:      	jmp	0x24e4 <do_action+0x3c4>
    21d4:      	leal	-0x6(%r12), %eax
    21d9:      	cmpl	$0x2, %eax
    21dc:      	jb	0x2508 <do_action+0x3e8>
    21e2:      	cmpl	$0x4, %r12d
    21e6:      	je	0x2525 <do_action+0x405>
    21ec:      	cmpl	$0x5, %r12d
    21f0:      	jne	0x2978 <do_action+0x858>
    21f6:      	leal	0x1(%rbx), %eax
    21f9:      	movl	0x4(%r15,%rax,4), %eax
    21fe:      	addl	$0x2, %ebx
    2201:      	andl	$0x7, %eax
    2204:      	cmpl	$0x4, %eax
    2207:      	ja	0x2978 <do_action+0x858>
    220d:      	cmpl	$0x0, 0x5ea0(%r13,%rax,4)
    2216:      	jne	0x2978 <do_action+0x858>
    221c:      	movl	0x4(%r15,%rbx,4), %r14d
    2221:      	movq	0x5e78(%r13,%rax,8), %rax
    2229:      	movl	$0x0, 0xc(%rsp)
    2231:      	andl	$0x7ff, %eax            # imm = 0x7FF
    2236:      	movl	0x90(%r13,%rax), %eax
    223e:      	movl	%eax, 0x8(%rsp)
    2242:      	movl	$0xe, %eax
    2247:      	callq	*%rax
    2249:      	shrq	$0x20, %rax
    224d:      	movq	%rax, (%rsp)
    2251:      	movq	(%rip), %rdi            # 0x2258 <do_action+0x138>
    2258:      	movq	%rsp, %rsi
    225b:      	movl	$0x1, %eax
    2260:      	callq	*%rax
    2262:      	testq	%rax, %rax
    2265:      	je	0x2978 <do_action+0x858>
    226b:      	andl	$0x7, %r14d
    226f:      	cmpl	$0x4, %r14d
    2273:      	ja	0x2978 <do_action+0x858>
    2279:      	cmpl	$0x0, 0x5ea0(%r13,%r14,4)
    2282:      	jne	0x2978 <do_action+0x858>
    2288:      	movq	0x5e78(%r13,%r14,8), %rcx
    2290:      	movl	$0x0, 0xc(%rsp)
    2298:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    229e:      	movl	0x90(%r13,%rcx), %ecx
    22a6:      	movl	%ecx, 0x8(%rsp)
    22aa:      	movq	%rax, %r15
    22ad:      	movl	$0xe, %eax
    22b2:      	callq	*%rax
    22b4:      	shrq	$0x20, %rax
    22b8:      	movq	%rax, (%rsp)
    22bc:      	movq	(%rip), %rdi            # 0x22c3 <do_action+0x1a3>
    22c3:      	xorl	%ecx, %ecx
    22c5:      	movq	%rsp, %rsi
    22c8:      	movl	$0x2, %eax
    22cd:      	movq	%r15, %rdx
    22d0:      	xorl	%ecx, %ecx
    22d2:      	callq	*%rax
    22d4:      	jmp	0x2978 <do_action+0x858>
    22d9:      	cmpl	$0xc, %r12d
    22dd:      	je	0x2668 <do_action+0x548>
    22e3:      	cmpl	$0xd, %r12d
    22e7:      	je	0x2534 <do_action+0x414>
    22ed:      	cmpl	$0xe, %r12d
    22f1:      	jne	0x2978 <do_action+0x858>
    22f7:      	addl	$0x2, %ebx
    22fa:      	movzbl	%bpl, %r14d
    22fe:      	xorq	$0x9, %r14
    2302:      	jmp	0x2673 <do_action+0x553>
    2307:      	movl	$0x9, %eax
    230c:      	cmpl	$0x2, %r12d
    2310:      	je	0x24e4 <do_action+0x3c4>
    2316:      	cmpl	$0x3, %r12d
    231a:      	jne	0x2978 <do_action+0x858>
    2320:      	leal	0x1(%rbx), %eax
    2323:      	movl	0x4(%r15,%rax,4), %ebp
    2328:      	addl	$0x2, %ebx
    232b:      	movl	0x4(%r15,%rbx,4), %r14d
    2330:      	movl	$0x0, 0x10(%rsp)
    2338:      	movq	(%rip), %rdi            # 0x233f <do_action+0x21f>
    233f:      	leaq	0x10(%rsp), %rsi
    2344:      	movl	$0x1, %eax
    2349:      	callq	*%rax
    234b:      	xorl	%r15d, %r15d
    234e:      	testq	%rax, %rax
    2351:      	je	0x272b <do_action+0x60b>
    2357:      	movq	%rax, 0x38(%rsp)
    235c:      	andl	$0x7, %ebp
    235f:      	cmpl	$0x4, %ebp
    2362:      	movl	$0x0, %eax
    2367:      	ja	0x272d <do_action+0x60d>
    236d:      	cmpl	$0x0, 0x5ea0(%r13,%rbp,4)
    2376:      	jne	0x272d <do_action+0x60d>
    237c:      	movq	0x5e78(%r13,%rbp,8), %rax
    2384:      	movl	$0x0, 0xc(%rsp)
    238c:      	andl	$0x7ff, %eax            # imm = 0x7FF
    2391:      	movl	0x90(%r13,%rax), %eax
    2399:      	movl	%eax, 0x8(%rsp)
    239d:      	movl	$0xe, %eax
    23a2:      	callq	*%rax
    23a4:      	shrq	$0x20, %rax
    23a8:      	movq	%rax, (%rsp)
    23ac:      	cmpl	$0x1, %r12d
    23b0:      	jne	0x2704 <do_action+0x5e4>
    23b6:      	andl	$0x7, %r14d
    23ba:      	cmpl	$0x4, %r14d
    23be:      	ja	0x272b <do_action+0x60b>
    23c4:      	cmpl	$0x0, 0x5ea0(%r13,%r14,4)
    23cd:      	movl	$0x0, %eax
    23d2:      	jne	0x272d <do_action+0x60d>
    23d8:      	movq	0x5e78(%r13,%r14,8), %rax
    23e0:      	andl	$0x7ff, %eax            # imm = 0x7FF
    23e5:      	leaq	(%rax,%r13), %rdx
    23e9:      	addq	$0x90, %rdx
    23f0:      	movl	0x90(%r13,%rax), %esi
    23f8:      	andl	$0xfff, %esi            # imm = 0xFFF
    23fe:      	addq	$0x8, %rsi
    2402:      	movl	$0x4, %eax
    2407:      	movq	0x38(%rsp), %r14
    240c:      	movq	%r14, %rdi
    240f:      	callq	*%rax
    2411:      	movq	(%rip), %rdi            # 0x2418 <do_action+0x2f8>
    2418:      	xorl	%r15d, %r15d
    241b:      	movq	%rsp, %rsi
    241e:      	movl	$0x2, %eax
    2423:      	movq	%r14, %rdx
    2426:      	jmp	0x24db <do_action+0x3bb>
    242b:      	incl	%ebx
    242d:      	movl	0x4(%r15,%rbx,4), %ecx
    2432:      	andl	$0x7, %ecx
    2435:      	xorl	%r15d, %r15d
    2438:      	cmpl	$0x4, %ecx
    243b:      	ja	0x272d <do_action+0x60d>
    2441:      	cmpl	$0x0, 0x5ea0(%r13,%rcx,4)
    244a:      	jne	0x272d <do_action+0x60d>
    2450:      	movq	0x5e78(%r13,%rcx,8), %rcx
    2458:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    245e:      	movq	0xb8(%r13,%rcx), %rcx
    2466:      	movq	%rcx, 0x10(%rsp)
    246b:      	testq	%rcx, %rcx
    246e:      	je	0x272d <do_action+0x60d>
    2474:      	cmpl	$0xa, %r12d
    2478:      	jne	0x2715 <do_action+0x5f5>
    247e:      	movl	$0xe, %eax
    2483:      	callq	*%rax
    2485:      	movq	%rax, %r14
    2488:      	shrq	$0x20, %rax
    248c:      	movl	%eax, (%rsp)
    248f:      	movq	(%rip), %rdi            # 0x2496 <do_action+0x376>
    2496:      	movq	%rsp, %rsi
    2499:      	movl	$0x1, %eax
    249e:      	callq	*%rax
    24a0:      	movq	%rax, %rcx
    24a3:      	testq	%rax, %rax
    24a6:      	movl	$0x0, %eax
    24ab:      	je	0x272d <do_action+0x60d>
    24b1:      	movl	(%rcx), %eax
    24b3:      	movl	%eax, (%rsp)
    24b6:      	movl	%r14d, 0x4(%rsp)
    24bb:      	movq	0x8(%rcx), %rax
    24bf:      	movq	%rax, 0x8(%rsp)
    24c4:      	movq	(%rip), %rdi            # 0x24cb <do_action+0x3ab>
    24cb:      	xorl	%r15d, %r15d
    24ce:      	leaq	0x10(%rsp), %rsi
    24d3:      	movq	%rsp, %rdx
    24d6:      	movl	$0x2, %eax
    24db:      	xorl	%ecx, %ecx
    24dd:      	callq	*%rax
    24df:      	jmp	0x272b <do_action+0x60b>
    24e4:      	movl	$0x3, %r14d
    24ea:      	testb	%bpl, %bpl
    24ed:      	je	0x2673 <do_action+0x553>
    24f3:      	movslq	%eax, %rdi
    24f6:      	movl	$0x6d, %eax
    24fb:      	callq	*%rax
    24fd:      	movl	$0x2, %r14d
    2503:      	jmp	0x2673 <do_action+0x553>
    2508:      	incl	%ebx
    250a:      	movl	0x4(%r15,%rbx,4), %eax
    250f:      	movl	%eax, 0x78(%r13)
    2513:      	jmp	0x2978 <do_action+0x858>
    2518:      	movq	0x38(%rsp), %rax
    251d:      	movb	$0x0, (%rax)
    2520:      	jmp	0x2978 <do_action+0x858>
    2525:      	incl	%ebx
    2527:      	movzbl	%bpl, %r14d
    252b:      	xorq	$0x5, %r14
    252f:      	jmp	0x2673 <do_action+0x553>
    2534:      	movl	$0xe, %eax
    2539:      	callq	*%rax
    253b:      	movq	%rax, 0x20(%rsp)
    2540:      	movq	(%rip), %rdi            # 0x2547 <do_action+0x427>
    2547:      	leaq	0x20(%rsp), %rsi
    254c:      	movl	$0x1, %eax
    2551:      	callq	*%rax
    2553:      	testq	%rax, %rax
    2556:      	je	0x2978 <do_action+0x858>
    255c:      	movq	0x4(%rax), %rax
    2560:      	movq	%rax, 0x10(%rsp)
    2565:      	movl	$0x2, 0x18(%rsp)
    256d:      	movq	(%rip), %rdi            # 0x2574 <do_action+0x454>
    2574:      	leaq	0x10(%rsp), %rsi
    2579:      	movl	$0x1, %eax
    257e:      	callq	*%rax
    2580:      	movl	$0x1, 0x2c(%rsp)
    2588:      	testq	%rax, %rax
    258b:      	je	0x269e <do_action+0x57e>
    2591:      	lock
    2592:      	incl	(%rax)
    2594:      	movq	(%rip), %rdi            # 0x259b <do_action+0x47b>
    259b:      	leaq	0x20(%rsp), %rsi
    25a0:      	movl	$0x3, %eax
    25a5:      	callq	*%rax
    25a7:      	jmp	0x2978 <do_action+0x858>
    25ac:      	leal	0x1(%rbx), %eax
    25af:      	movl	0x4(%r15,%rax,4), %ebp
    25b4:      	leal	0x2(%rbx), %eax
    25b7:      	movl	0x4(%r15,%rax,4), %eax
    25bc:      	movl	%eax, 0x30(%rsp)
    25c0:      	movl	$0x7d, %eax
    25c5:      	callq	*%rax
    25c7:      	movq	%rax, 0x68(%rsp)
    25cc:      	movq	%rax, (%rsp)
    25d0:      	movl	$0x0, 0x20(%rsp)
    25d8:      	movq	%rbp, 0x70(%rsp)
    25dd:      	testq	%rbp, %rbp
    25e0:      	je	0x290a <do_action+0x7ea>
    25e6:      	movq	(%rip), %rdi            # 0x25ed <do_action+0x4cd>
    25ed:      	leaq	0x20(%rsp), %rsi
    25f2:      	movl	$0x1, %eax
    25f7:      	callq	*%rax
    25f9:      	testq	%rax, %rax
    25fc:      	je	0x290a <do_action+0x7ea>
    2602:      	movq	%rax, 0x48(%rsp)
    2607:      	movq	%rax, %rbp
    260a:      	movq	(%rip), %rdi            # 0x2611 <do_action+0x4f1>
    2611:      	leaq	0x20(%rsp), %rsi
    2616:      	movl	$0x1, %eax
    261b:      	callq	*%rax
    261d:      	movq	%rax, %rdx
    2620:      	movq	0x60(%r13), %rax
    2624:      	movq	%rax, (%rbp)
    2628:      	movq	0x70(%r13), %rax
    262c:      	movq	%rbp, 0x40(%rsp)
    2631:      	movq	%rax, 0x8(%rbp)
    2635:      	xorl	%eax, %eax
    2637:      	movq	%rax, 0x60(%rsp)
    263c:      	movl	$0x0, %eax
    2641:      	movl	0x30(%rsp), %ecx
    2645:      	cmpl	$0x2, %ecx
    2648:      	je	0x273f <do_action+0x61f>
    264e:      	cmpl	$0x1, %ecx
    2651:      	je	0x273b <do_action+0x61b>
    2657:      	testl	%ecx, %ecx
    2659:      	jne	0x290a <do_action+0x7ea>
    265f:      	movl	0x7c(%r13), %eax
    2663:      	jmp	0x273f <do_action+0x61f>
    2668:      	addl	$0x3, %ebx
    266b:      	movzbl	%bpl, %r14d
    266f:      	xorq	$0x7, %r14
    2673:      	movl	$0x0, (%rsp)
    267a:      	movq	(%rip), %rdi            # 0x2681 <do_action+0x561>
    2681:      	movq	%rsp, %rsi
    2684:      	movl	$0x1, %eax
    2689:      	callq	*%rax
    268b:      	testq	%rax, %rax
    268e:      	je	0x2978 <do_action+0x858>
    2694:      	lock
    2695:      	incq	(%rax,%r14,8)
    2699:      	jmp	0x2978 <do_action+0x858>
    269e:      	movq	(%rip), %rdi            # 0x26a5 <do_action+0x585>
    26a5:      	leaq	0x10(%rsp), %rsi
    26aa:      	leaq	0x2c(%rsp), %rdx
    26af:      	movl	$0x1, %ecx
    26b4:      	movl	$0x2, %eax
    26b9:      	callq	*%rax
    26bb:      	testq	%rax, %rax
    26be:      	je	0x2594 <do_action+0x474>
    26c4:      	movq	%rax, %r15
    26c7:      	negl	%eax
    26c9:      	movw	%ax, (%rsp)
    26cd:      	movw	$0x3, 0x2(%rsp)
    26d4:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    26de:      	movq	%rax, 0x4(%rsp)
    26e3:      	movq	(%rip), %rdi            # 0x26ea <do_action+0x5ca>
    26ea:      	movq	%rsp, %rsi
    26ed:      	movl	$0x1, %eax
    26f2:      	callq	*%rax
    26f4:      	testq	%rax, %rax
    26f7:      	je	0x298f <do_action+0x86f>
    26fd:      	incl	(%rax)
    26ff:      	jmp	0x29b1 <do_action+0x891>
    2704:      	movq	(%rip), %rdi            # 0x270b <do_action+0x5eb>
    270b:      	movq	%rsp, %rsi
    270e:      	movl	$0x3, %eax
    2713:      	jmp	0x2726 <do_action+0x606>
    2715:      	movq	(%rip), %rdi            # 0x271c <do_action+0x5fc>
    271c:      	leaq	0x10(%rsp), %rsi
    2721:      	movl	$0x3, %eax
    2726:      	callq	*%rax
    2728:      	movq	%rax, %r15
    272b:      	xorl	%eax, %eax
    272d:      	testl	%r15d, %r15d
    2730:      	jne	0x2980 <do_action+0x860>
    2736:      	jmp	0x2978 <do_action+0x858>
    273b:      	movl	0x10(%r13), %eax
    273f:      	movq	%r14, 0x30(%rsp)
    2744:      	movl	%eax, %eax
    2746:      	movq	0x40(%rsp), %rcx
    274b:      	movq	%rax, 0x10(%rcx)
    274f:      	movq	0x48(%rsp), %rdi
    2754:      	addq	$0x18, %rdi
    2758:      	movl	$0xc8, %ecx
    275d:      	movl	$0x4, %eax
    2762:      	movq	%rdi, 0x48(%rsp)
    2767:      	movl	$0xc8, %esi
    276c:      	callq	*%rax
    276e:      	xorl	%r14d, %r14d
    2771:      	movq	%r13, 0x58(%rsp)
    2776:      	jmp	0x2786 <do_action+0x666>
    2778:      	addq	$0x4, %r14
    277c:      	cmpq	$0x14, %r14
    2780:      	je	0x28b3 <do_action+0x793>
    2786:      	movl	$0x0, 0x10(%rsp)
    278e:      	movl	$0x1, %eax
    2793:      	movq	(%rip), %rdi            # 0x279a <do_action+0x67a>
    279a:      	leaq	0x10(%rsp), %rsi
    279f:      	callq	*%rax
    27a1:      	testq	%rax, %rax
    27a4:      	je	0x28b3 <do_action+0x793>
    27aa:      	movq	%rax, %rsi
    27ad:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    27b4:      	movl	$0x1, %eax
    27b9:      	movq	(%rip), %rdi            # 0x27c0 <do_action+0x6a0>
    27c0:      	callq	*%rax
    27c2:      	testq	%rax, %rax
    27c5:      	je	0x28b3 <do_action+0x793>
    27cb:      	cmpl	$-0x1, 0x40(%rax,%r14)
    27d1:      	je	0x28b3 <do_action+0x793>
    27d7:      	movq	0x5e78(%r13,%r14,2), %rax
    27df:      	movl	0x4(%r13), %ecx
    27e3:      	cmpq	%rcx, %rax
    27e6:      	jge	0x28b3 <do_action+0x793>
    27ec:      	cmpq	$0x10, %r14
    27f0:      	je	0x2853 <do_action+0x733>
    27f2:      	movl	$0x0, 0x10(%rsp)
    27fa:      	movl	$0x1, %eax
    27ff:      	movq	(%rip), %rdi            # 0x2806 <do_action+0x6e6>
    2806:      	leaq	0x10(%rsp), %rsi
    280b:      	callq	*%rax
    280d:      	testq	%rax, %rax
    2810:      	je	0x284b <do_action+0x72b>
    2812:      	movq	%rax, %rsi
    2815:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    281c:      	movl	$0x1, %eax
    2821:      	movq	(%rip), %rdi            # 0x2828 <do_action+0x708>
    2828:      	callq	*%rax
    282a:      	testq	%rax, %rax
    282d:      	je	0x284b <do_action+0x72b>
    282f:      	cmpl	$-0x1, 0x44(%rax,%r14)
    2835:      	movq	0x5e78(%r13,%r14,2), %rax
    283d:      	je	0x2853 <do_action+0x733>
    283f:      	movl	0x5e80(%r13,%r14,2), %ebp
    2847:      	subl	%eax, %ebp
    2849:      	jmp	0x285c <do_action+0x73c>
    284b:      	movq	0x5e78(%r13,%r14,2), %rax
    2853:      	movl	0x4(%r13), %ebp
    2857:      	subl	%eax, %ebp
    2859:      	addl	$0x4, %ebp
    285c:      	testl	%ebp, %ebp
    285e:      	jle	0x2778 <do_action+0x658>
    2864:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    2869:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    286e:      	cmpl	$0x28, %ebp
    2871:      	movl	$0x28, %ecx
    2876:      	cmovgel	%ecx, %ebp
    2879:      	movzbl	0x60(%rsp), %r13d
    287f:      	movq	0x48(%rsp), %rcx
    2884:      	leaq	(%rcx,%r13), %rdi
    2888:      	movq	0x58(%rsp), %rcx
    288d:      	leaq	(%rcx,%rax), %rdx
    2891:      	addq	$0x90, %rdx
    2898:      	movl	$0x4, %eax
    289d:      	movl	%ebp, %esi
    289f:      	callq	*%rax
    28a1:      	addl	%r13d, %ebp
    28a4:      	movq	0x58(%rsp), %r13
    28a9:      	movq	%rbp, 0x60(%rsp)
    28ae:      	jmp	0x2778 <do_action+0x658>
    28b3:      	movq	(%rip), %rdi            # 0x28ba <do_action+0x79a>
    28ba:      	movl	$0x1, %eax
    28bf:      	movq	0x40(%rsp), %rsi
    28c4:      	callq	*%rax
    28c6:      	testq	%rax, %rax
    28c9:      	je	0x28eb <do_action+0x7cb>
    28cb:      	imulq	$-0xf4240, 0x70(%rsp), %rcx # imm = 0xFFF0BDC0
    28d4:      	movq	0x68(%rsp), %rdx
    28d9:      	addq	%rcx, %rdx
    28dc:      	cmpq	%rdx, (%rax)
    28df:      	jbe	0x28eb <do_action+0x7cb>
    28e1:      	movq	0x38(%rsp), %rax
    28e6:      	movb	$0x0, (%rax)
    28e9:      	jmp	0x2905 <do_action+0x7e5>
    28eb:      	movq	(%rip), %rdi            # 0x28f2 <do_action+0x7d2>
    28f2:      	xorl	%ecx, %ecx
    28f4:      	movq	%rsp, %rdx
    28f7:      	movl	$0x2, %eax
    28fc:      	movq	0x40(%rsp), %rsi
    2901:      	xorl	%ecx, %ecx
    2903:      	callq	*%rax
    2905:      	movq	0x30(%rsp), %r14
    290a:      	leal	0x3(%rbx), %eax
    290d:      	cmpl	$0x0, 0x4(%r15,%rax,4)
    2913:      	je	0x2936 <do_action+0x816>
    2915:      	orb	$0x2, 0x1(%r13)
    291a:      	movq	(%rip), %rsi            # 0x2921 <do_action+0x801>
    2921:      	xorl	%ecx, %ecx
    2923:      	movl	$0x1b, %eax
    2928:      	movq	%r14, %rdi
    292b:      	xorl	%edx, %edx
    292d:      	callq	*%rax
    292f:      	movq	%rax, 0x80(%r13)
    2936:      	leal	0x4(%rbx), %eax
    2939:      	cmpl	$0x0, 0x4(%r15,%rax,4)
    293f:      	je	0x2968 <do_action+0x848>
    2941:      	orb	$0x4, 0x1(%r13)
    2946:      	movq	(%rip), %rsi            # 0x294d <do_action+0x82d>
    294d:      	movl	$0x100, %ecx            # imm = 0x100
    2952:      	movl	$0x1b, %eax
    2957:      	movl	$0x100, %edx            # imm = 0x100
    295c:      	movq	%r14, %rdi
    295f:      	callq	*%rax
    2961:      	movq	%rax, 0x88(%r13)
    2968:      	addl	$0x5, %ebx
    296b:      	cmpl	$0x0, 0x4(%r15,%rbx,4)
    2971:      	je	0x2978 <do_action+0x858>
    2973:      	orb	$0x8, 0x1(%r13)
    2978:      	movq	%r12, 0x70(%r13)
    297c:      	incl	%ebx
    297e:      	movl	%ebx, %eax
    2980:      	addq	$0x78, %rsp
    2984:      	popq	%rbx
    2985:      	popq	%r12
    2987:      	popq	%r13
    2989:      	popq	%r14
    298b:      	popq	%r15
    298d:      	popq	%rbp
    298e:      	retq
    298f:      	movl	$0x1, 0x54(%rsp)
    2997:      	movq	(%rip), %rdi            # 0x299e <do_action+0x87e>
    299e:      	xorl	%ecx, %ecx
    29a0:      	movq	%rsp, %rsi
    29a3:      	leaq	0x54(%rsp), %rdx
    29a8:      	movl	$0x2, %eax
    29ad:      	xorl	%ecx, %ecx
    29af:      	callq	*%rax
    29b1:      	testl	%r15d, %r15d
    29b4:      	je	0x2594 <do_action+0x474>
    29ba:      	movq	(%rip), %rdi            # 0x29c1 <do_action+0x8a1>
    29c1:      	leaq	0x10(%rsp), %rsi
    29c6:      	movl	$0x1, %eax
    29cb:      	callq	*%rax
    29cd:      	testq	%rax, %rax
    29d0:      	je	0x2594 <do_action+0x474>
    29d6:      	movl	0x2c(%rsp), %ecx
    29da:      	lock
    29db:      	addl	%ecx, (%rax)
    29dd:      	jmp	0x2594 <do_action+0x474>

Disassembly of section fexit/generic_fexit_tail:

0000000000000000 <generic_fexit_filter_arg>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x28, %rsp
       e:      	movq	%rdi, %rbx
      11:      	movl	$0x0, 0x4(%rsp)
      19:      	movq	(%rip), %rdi            # 0x20 <generic_fexit_filter_arg+0x20>
      20:      	leaq	0x4(%rsp), %rsi
      25:      	movl	$0x1, %eax
      2a:      	callq	*%rax
      2c:      	testq	%rax, %rax
      2f:      	je	0x398 <generic_fexit_filter_arg+0x398>
      35:      	movq	%rax, %r14
      38:      	movl	0x5f00(%rax), %r12d
      3f:      	leaq	0x5ef8(%rax), %rsi
      46:      	movq	(%rip), %rdi            # 0x4d <generic_fexit_filter_arg+0x4d>
      4d:      	movl	$0x1, %eax
      52:      	callq	*%rax
      54:      	testq	%rax, %rax
      57:      	je	0x37d <generic_fexit_filter_arg+0x37d>
      5d:      	cmpb	$0x0, 0x5ee0(%r14)
      65:      	je	0x37d <generic_fexit_filter_arg+0x37d>
      6b:      	movq	%rax, %r15
      6e:      	movl	%r12d, %eax
      71:      	andl	$0x7, %eax
      74:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
      7d:      	je	0xb7 <generic_fexit_filter_arg+0xb7>
      7f:      	movl	%eax, %eax
      81:      	movl	0x4(%r15,%rax,4), %ecx
      86:      	leaq	(%rcx,%rax,4), %r13
      8a:      	addq	$0x8, %r13
      8e:      	movq	%r13, %rax
      91:      	movq	%r13, 0x10(%rsp)
      96:      	andl	$0x3ff, %r13d           # imm = 0x3FF
      9d:      	cmpl	$0x19, (%r15,%r13)
      a2:      	jae	0x10c <generic_fexit_filter_arg+0x10c>
      a4:      	cmpq	$0x1, %r13
      a8:      	je	0x37d <generic_fexit_filter_arg+0x37d>
      ae:      	testl	%r13d, %r13d
      b1:      	jne	0x35b <generic_fexit_filter_arg+0x35b>
      b7:      	cmpl	$0x1, %r12d
      bb:      	jg	0xdc <generic_fexit_filter_arg+0xdc>
      bd:      	cmpl	$-0x1, %r12d
      c1:      	je	0x3a9 <generic_fexit_filter_arg+0x3a9>
      c7:      	testl	%r12d, %r12d
      ca:      	je	0x3b6 <generic_fexit_filter_arg+0x3b6>
      d0:      	cmpl	$0x1, %r12d
      d4:      	je	0x3c6 <generic_fexit_filter_arg+0x3c6>
      da:      	jmp	0xfa <generic_fexit_filter_arg+0xfa>
      dc:      	cmpl	$0x2, %r12d
      e0:      	je	0x3d6 <generic_fexit_filter_arg+0x3d6>
      e6:      	cmpl	$0x3, %r12d
      ea:      	je	0x3e6 <generic_fexit_filter_arg+0x3e6>
      f0:      	cmpl	$0x4, %r12d
      f4:      	je	0x3f6 <generic_fexit_filter_arg+0x3f6>
      fa:      	cmpl	$0x4, %r12d
      fe:      	jg	0x428 <generic_fexit_filter_arg+0x428>
     104:      	incl	%r12d
     107:      	jmp	0x406 <generic_fexit_filter_arg+0x406>
     10c:      	leaq	(%r15,%r13), %rax
     110:      	movq	%rax, 0x8(%rsp)
     115:      	movl	$0x1, %ebp
     11a:      	nopw	(%rax,%rax)
     120:      	movq	0x8(%rsp), %rax
     125:      	movl	(%rax,%rbp,4), %edi
     128:      	testl	$0x3ff, %edi            # imm = 0x3FF
     12e:      	je	0xa4 <generic_fexit_filter_arg+0xa4>
     134:      	addl	0x10(%rsp), %edi
     138:      	andl	$0x3ff, %edi            # imm = 0x3FF
     13e:      	movl	0x4(%r15,%rdi), %ecx
     143:      	cmpl	$0x23, %ecx
     146:      	je	0xb7 <generic_fexit_filter_arg+0xb7>
     14c:      	addq	%r15, %rdi
     14f:      	movl	(%rdi), %eax
     151:      	cmpq	$0x4, %rax
     155:      	ja	0xb7 <generic_fexit_filter_arg+0xb7>
     15b:      	cmpl	$0x0, 0x5ea0(%r14,%rax,4)
     164:      	jne	0xb7 <generic_fexit_filter_arg+0xb7>
     16a:      	movq	0x5e78(%r14,%rax,8), %rax
     172:      	andl	$0x7ff, %eax            # imm = 0x7FF
     177:      	leaq	(%r14,%rax), %rsi
     17b:      	addq	$0x90, %rsi
     182:      	movl	0xc(%rdi), %eax
     185:      	cmpl	$0x1b, %eax
     188:      	jle	0x1a9 <generic_fexit_filter_arg+0x1a9>
     18a:      	cmpl	$0x25, %eax
     18d:      	jg	0x1d9 <generic_fexit_filter_arg+0x1d9>
     18f:      	leal	-0x1c(%rax), %edx
     192:      	cmpl	$0x9, %edx
     195:      	jb	0x21f <generic_fexit_filter_arg+0x21f>
     19b:      	cmpl	$0x25, %eax
     19e:      	je	0x302 <generic_fexit_filter_arg+0x302>
     1a4:      	jmp	0x349 <generic_fexit_filter_arg+0x349>
     1a9:      	cmpl	$0x9, %eax
     1ac:      	jle	0x1ff <generic_fexit_filter_arg+0x1ff>
     1ae:      	leal	-0xa(%rax), %edx
     1b1:      	cmpl	$0x4, %edx
     1b4:      	jb	0x21f <generic_fexit_filter_arg+0x21f>
     1b6:      	leal	-0xf(%rax), %ecx
     1b9:      	cmpl	$0x2, %ecx
     1bc:      	jb	0x302 <generic_fexit_filter_arg+0x302>
     1c2:      	cmpl	$0x11, %eax
     1c5:      	jne	0x349 <generic_fexit_filter_arg+0x349>
     1cb:      	addq	$0x4, %rsi
     1cf:      	callq	0x1d4 <generic_fexit_filter_arg+0x1d4>
     1d4:      	jmp	0x340 <generic_fexit_filter_arg+0x340>
     1d9:      	cmpl	$0x29, %eax
     1dc:      	jg	0x2f1 <generic_fexit_filter_arg+0x2f1>
     1e2:      	leal	-0x26(%rax), %ecx
     1e5:      	cmpl	$0x2, %ecx
     1e8:      	jb	0x2ac <generic_fexit_filter_arg+0x2ac>
     1ee:      	addl	$-0x28, %eax
     1f1:      	cmpl	$0x2, %eax
     1f4:      	jb	0x2a2 <generic_fexit_filter_arg+0x2a2>
     1fa:      	jmp	0x349 <generic_fexit_filter_arg+0x349>
     1ff:      	cmpl	$0x4, %eax
     202:      	jg	0x28f <generic_fexit_filter_arg+0x28f>
     208:      	cmpl	$0x1, %eax
     20b:      	je	0x21f <generic_fexit_filter_arg+0x21f>
     20d:      	cmpl	$0x2, %eax
     210:      	je	0x31f <generic_fexit_filter_arg+0x31f>
     216:      	cmpl	$0x4, %eax
     219:      	jne	0x349 <generic_fexit_filter_arg+0x349>
     21f:      	cmpl	$0xb, %eax
     222:      	jle	0x26c <generic_fexit_filter_arg+0x26c>
     224:      	cmpl	$0x24, %eax
     227:      	ja	0x309 <generic_fexit_filter_arg+0x309>
     22d:      	movl	%eax, %edx
     22f:      	movabsq	$0x1e00000000, %r8      # imm = 0x1E00000000
     239:      	btq	%rdx, %r8
     23d:      	jb	0x2b3 <generic_fexit_filter_arg+0x2b3>
     23f:      	movl	$0x60000000, %ecx       # imm = 0x60000000
     244:      	btq	%rdx, %rcx
     248:      	jb	0x318 <generic_fexit_filter_arg+0x318>
     24e:      	movabsq	$0x180000000, %rcx      # imm = 0x180000000
     258:      	btq	%rdx, %rcx
     25c:      	jae	0x309 <generic_fexit_filter_arg+0x309>
     262:      	callq	0x267 <generic_fexit_filter_arg+0x267>
     267:      	jmp	0x340 <generic_fexit_filter_arg+0x340>
     26c:      	leal	-0xa(%rax), %ecx
     26f:      	cmpl	$0x2, %ecx
     272:      	jb	0x330 <generic_fexit_filter_arg+0x330>
     278:      	cmpl	$0x1, %eax
     27b:      	je	0x311 <generic_fexit_filter_arg+0x311>
     281:      	cmpl	$0x4, %eax
     284:      	je	0x311 <generic_fexit_filter_arg+0x311>
     28a:      	jmp	0x349 <generic_fexit_filter_arg+0x349>
     28f:      	cmpl	$0x5, %eax
     292:      	je	0x2a2 <generic_fexit_filter_arg+0x2a2>
     294:      	cmpl	$0x6, %eax
     297:      	je	0x2ac <generic_fexit_filter_arg+0x2ac>
     299:      	cmpl	$0x7, %eax
     29c:      	jne	0x349 <generic_fexit_filter_arg+0x349>
     2a2:      	callq	0x2a7 <generic_fexit_filter_arg+0x2a7>
     2a7:      	jmp	0x340 <generic_fexit_filter_arg+0x340>
     2ac:      	movl	$0x4, %edx
     2b1:      	jmp	0x324 <generic_fexit_filter_arg+0x324>
     2b3:      	cmpl	$0x1e, %ecx
     2b6:      	jne	0x330 <generic_fexit_filter_arg+0x330>
     2b8:      	movl	0x10(%rdi), %eax
     2bb:      	andl	$0x7, %eax
     2be:      	movl	%eax, %ecx
     2c0:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
     2c9:      	jne	0xb7 <generic_fexit_filter_arg+0xb7>
     2cf:      	movq	(%rsi), %rcx
     2d2:      	movq	0x5e78(%r14,%rax,8), %rdx
     2da:      	andl	$0x7ff, %edx            # imm = 0x7FF
     2e0:      	xorl	%eax, %eax
     2e2:      	andnq	0x90(%r14,%rdx), %rcx, %rcx
     2ec:      	setne	%al
     2ef:      	jmp	0x340 <generic_fexit_filter_arg+0x340>
     2f1:      	cmpl	$0x2a, %eax
     2f4:      	je	0x302 <generic_fexit_filter_arg+0x302>
     2f6:      	cmpl	$0x2c, %eax
     2f9:      	jne	0x349 <generic_fexit_filter_arg+0x349>
     2fb:      	callq	0x300 <generic_fexit_filter_arg+0x300>
     300:      	jmp	0x340 <generic_fexit_filter_arg+0x340>
     302:      	callq	0x307 <generic_fexit_filter_arg+0x307>
     307:      	jmp	0x340 <generic_fexit_filter_arg+0x340>
     309:      	leal	-0xc(%rax), %ecx
     30c:      	cmpl	$0x2, %ecx
     30f:      	jae	0x32b <generic_fexit_filter_arg+0x32b>
     311:      	callq	0x316 <generic_fexit_filter_arg+0x316>
     316:      	jmp	0x340 <generic_fexit_filter_arg+0x340>
     318:      	callq	0x31d <generic_fexit_filter_arg+0x31d>
     31d:      	jmp	0x340 <generic_fexit_filter_arg+0x340>
     31f:      	movl	$0x8, %edx
     324:      	callq	0x329 <generic_fexit_filter_arg+0x329>
     329:      	jmp	0x340 <generic_fexit_filter_arg+0x340>
     32b:      	cmpl	$0x1c, %eax
     32e:      	jne	0x349 <generic_fexit_filter_arg+0x349>
     330:      	callq	0x335 <generic_fexit_filter_arg+0x335>
     335:      	nopw	%cs:(%rax,%rax)
     340:      	testq	%rax, %rax
     343:      	je	0xb7 <generic_fexit_filter_arg+0xb7>
     349:      	incq	%rbp
     34c:      	cmpq	$0x6, %rbp
     350:      	jne	0x120 <generic_fexit_filter_arg+0x120>
     356:      	jmp	0xa4 <generic_fexit_filter_arg+0xa4>
     35b:      	movl	%r13d, 0x5f04(%r14)
     362:      	movq	(%rip), %rsi            # 0x369 <generic_fexit_filter_arg+0x369>
     369:      	movl	$0x4, %ecx
     36e:      	movl	$0xc, %eax
     373:      	movq	%rbx, %rdi
     376:      	movl	$0x4, %edx
     37b:      	callq	*%rax
     37d:      	movq	(%rip), %rsi            # 0x384 <generic_fexit_filter_arg+0x384>
     384:      	movl	$0x5, %ecx
     389:      	movl	$0xc, %eax
     38e:      	movq	%rbx, %rdi
     391:      	movl	$0x5, %edx
     396:      	callq	*%rax
     398:      	xorl	%eax, %eax
     39a:      	addq	$0x28, %rsp
     39e:      	popq	%rbx
     39f:      	popq	%r12
     3a1:      	popq	%r13
     3a3:      	popq	%r14
     3a5:      	popq	%r15
     3a7:      	popq	%rbp
     3a8:      	retq
     3a9:      	xorl	%r12d, %r12d
     3ac:      	cmpb	$0x0, 0x5ec1(%r14)
     3b4:      	jne	0x406 <generic_fexit_filter_arg+0x406>
     3b6:      	movl	$0x1, %r12d
     3bc:      	cmpb	$0x0, 0x5ec2(%r14)
     3c4:      	jne	0x406 <generic_fexit_filter_arg+0x406>
     3c6:      	movl	$0x2, %r12d
     3cc:      	cmpb	$0x0, 0x5ec3(%r14)
     3d4:      	jne	0x406 <generic_fexit_filter_arg+0x406>
     3d6:      	movl	$0x3, %r12d
     3dc:      	cmpb	$0x0, 0x5ec4(%r14)
     3e4:      	jne	0x406 <generic_fexit_filter_arg+0x406>
     3e6:      	movl	$0x4, %r12d
     3ec:      	cmpb	$0x0, 0x5ec5(%r14)
     3f4:      	jne	0x406 <generic_fexit_filter_arg+0x406>
     3f6:      	movl	$0x5, %r12d
     3fc:      	cmpb	$0x0, 0x5ec6(%r14)
     404:      	je	0x428 <generic_fexit_filter_arg+0x428>
     406:      	movl	%r12d, 0x5f00(%r14)
     40d:      	movq	(%rip), %rsi            # 0x414 <generic_fexit_filter_arg+0x414>
     414:      	movl	$0x3, %ecx
     419:      	movl	$0xc, %eax
     41e:      	movq	%rbx, %rdi
     421:      	movl	$0x3, %edx
     426:      	callq	*%rax
     428:      	movq	0x60(%r14), %rbx
     42c:      	movl	$0xe, %eax
     431:      	callq	*%rax
     433:      	movq	%rbx, 0x18(%rsp)
     438:      	movq	%rax, 0x20(%rsp)
     43d:      	movq	(%rip), %rdi            # 0x444 <generic_fexit_filter_arg+0x444>
     444:      	leaq	0x18(%rsp), %rsi
     449:      	movl	$0x1, %eax
     44e:      	callq	*%rax
     450:      	testq	%rax, %rax
     453:      	je	0x398 <generic_fexit_filter_arg+0x398>
     459:      	movq	(%rip), %rdi            # 0x460 <generic_fexit_filter_arg+0x460>
     460:      	leaq	0x18(%rsp), %rsi
     465:      	movl	$0x3, %eax
     46a:      	callq	*%rax
     46c:      	jmp	0x398 <generic_fexit_filter_arg+0x398>
     471:      	nopw	%cs:(%rax,%rax)

0000000000000480 <generic_fexit_actions>:
     480:      	pushq	%rbp
     481:      	pushq	%r14
     483:      	pushq	%rbx
     484:      	subq	$0x10, %rsp
     488:      	movq	%rdi, %rbx
     48b:      	movl	$0x0, 0x8(%rsp)
     493:      	movq	(%rip), %rdi            # 0x49a <generic_fexit_actions+0x1a>
     49a:      	leaq	0x8(%rsp), %rsi
     49f:      	movl	$0x1, %eax
     4a4:      	callq	*%rax
     4a6:      	testq	%rax, %rax
     4a9:      	je	0x5b2 <generic_fexit_actions+0x132>
     4af:      	movq	%rax, %rsi
     4b2:      	movl	0x5f04(%rax), %r14d
     4b9:      	cmpl	$0x2, %r14d
     4bd:      	jl	0x5b2 <generic_fexit_actions+0x132>
     4c3:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     4ca:      	movq	(%rip), %rdi            # 0x4d1 <generic_fexit_actions+0x51>
     4d1:      	movl	$0x1, %eax
     4d6:      	callq	*%rax
     4d8:      	testq	%rax, %rax
     4db:      	je	0x5b2 <generic_fexit_actions+0x132>
     4e1:      	movl	%r14d, %ecx
     4e4:      	andl	$0x7ff, %ecx            # imm = 0x7FF
     4ea:      	addl	(%rax,%rcx), %r14d
     4ee:      	movb	$0x1, 0x7(%rsp)
     4f3:      	movl	$0x0, 0xc(%rsp)
     4fb:      	movq	(%rip), %rdi            # 0x502 <generic_fexit_actions+0x82>
     502:      	leaq	0xc(%rsp), %rsi
     507:      	movq	%rax, %rcx
     50a:      	movl	$0x1, %eax
     50f:      	andl	$0x7ff, %r14d           # imm = 0x7FF
     516:      	addq	%rcx, %r14
     519:      	callq	*%rax
     51b:      	testq	%rax, %rax
     51e:      	je	0x52e <generic_fexit_actions+0xae>
     520:      	cmpb	$0x0, (%rax)
     523:      	sete	%al
     526:      	cmpl	$0x5, (%r14)
     52a:      	jae	0x536 <generic_fexit_actions+0xb6>
     52c:      	jmp	0x590 <generic_fexit_actions+0x110>
     52e:      	movb	$0x1, %al
     530:      	cmpl	$0x5, (%r14)
     534:      	jb	0x590 <generic_fexit_actions+0x110>
     536:      	movzbl	%al, %ebp
     539:      	leaq	0x7(%rsp), %rcx
     53e:      	movq	%rbx, %rdi
     541:      	xorl	%esi, %esi
     543:      	movq	%r14, %rdx
     546:      	movl	%ebp, %r8d
     549:      	callq	0x54e <generic_fexit_actions+0xce>
     54e:      	leal	0x4(,%rax,4), %ecx
     555:      	cmpl	(%r14), %ecx
     558:      	jae	0x590 <generic_fexit_actions+0x110>
     55a:      	leaq	0x7(%rsp), %rcx
     55f:      	movq	%rbx, %rdi
     562:      	movl	%eax, %esi
     564:      	movq	%r14, %rdx
     567:      	movl	%ebp, %r8d
     56a:      	callq	0x56f <generic_fexit_actions+0xef>
     56f:      	leal	0x4(,%rax,4), %ecx
     576:      	cmpl	(%r14), %ecx
     579:      	jae	0x590 <generic_fexit_actions+0x110>
     57b:      	leaq	0x7(%rsp), %rcx
     580:      	movq	%rbx, %rdi
     583:      	movl	%eax, %esi
     585:      	movq	%r14, %rdx
     588:      	movl	%ebp, %r8d
     58b:      	callq	0x590 <generic_fexit_actions+0x110>
     590:      	cmpb	$0x0, 0x7(%rsp)
     595:      	je	0x5b2 <generic_fexit_actions+0x132>
     597:      	movq	(%rip), %rsi            # 0x59e <generic_fexit_actions+0x11e>
     59e:      	movl	$0x5, %ecx
     5a3:      	movl	$0xc, %eax
     5a8:      	movq	%rbx, %rdi
     5ab:      	movl	$0x5, %edx
     5b0:      	callq	*%rax
     5b2:      	xorl	%eax, %eax
     5b4:      	addq	$0x10, %rsp
     5b8:      	popq	%rbx
     5b9:      	popq	%r14
     5bb:      	popq	%rbp
     5bc:      	retq
     5bd:      	nopl	(%rax)

00000000000005c0 <generic_fexit_output>:
     5c0:      	pushq	%r15
     5c2:      	pushq	%r14
     5c4:      	pushq	%rbx
     5c5:      	subq	$0x10, %rsp
     5c9:      	movq	%rdi, %r14
     5cc:      	movl	$0x0, 0x8(%rsp)
     5d4:      	movq	(%rip), %rdi            # 0x5db <generic_fexit_output+0x1b>
     5db:      	leaq	0x8(%rsp), %rsi
     5e0:      	movl	$0x1, %eax
     5e5:      	callq	*%rax
     5e7:      	testq	%rax, %rax
     5ea:      	je	0x6c3 <generic_fexit_output+0x103>
     5f0:      	movq	%rax, %rbx
     5f3:      	movl	$0x90, %eax
     5f8:      	addl	0x4(%rbx), %eax
     5fb:      	andl	$0x7fff, %eax           # imm = 0x7FFF
     600:      	cmpl	$0x2328, %eax           # imm = 0x2328
     605:      	movl	$0x2328, %r15d          # imm = 0x2328
     60b:      	cmovbl	%eax, %r15d
     60f:      	movl	$0x0, 0xc(%rsp)
     617:      	movq	(%rip), %rdi            # 0x61e <generic_fexit_output+0x5e>
     61e:      	leaq	0xc(%rsp), %rsi
     623:      	movl	$0x1, %eax
     628:      	callq	*%rax
     62a:      	testq	%rax, %rax
     62d:      	je	0x681 <generic_fexit_output+0xc1>
     62f:      	cmpb	$0x0, 0x28(%rax)
     633:      	je	0x681 <generic_fexit_output+0xc1>
     635:      	movq	(%rip), %rsi            # 0x63c <generic_fexit_output+0x7c>
     63c:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     641:      	movl	$0x19, %eax
     646:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     64b:      	movq	%r14, %rdi
     64e:      	movq	%rbx, %rcx
     651:      	movq	%r15, %r8
     654:      	callq	*%rax
     656:      	testq	%rax, %rax
     659:      	js	0x71e <generic_fexit_output+0x15e>
     65f:      	movl	$0x0, 0x4(%rsp)
     667:      	movq	(%rip), %rdi            # 0x66e <generic_fexit_output+0xae>
     66e:      	leaq	0x4(%rsp), %rsi
     673:      	movl	$0x1, %eax
     678:      	callq	*%rax
     67a:      	testq	%rax, %rax
     67d:      	jne	0x6be <generic_fexit_output+0xfe>
     67f:      	jmp	0x6c3 <generic_fexit_output+0x103>
     681:      	movq	(%rip), %rdi            # 0x688 <generic_fexit_output+0xc8>
     688:      	xorl	%ecx, %ecx
     68a:      	movl	$0x82, %eax
     68f:      	movq	%rbx, %rsi
     692:      	movq	%r15, %rdx
     695:      	xorl	%ecx, %ecx
     697:      	callq	*%rax
     699:      	testq	%rax, %rax
     69c:      	js	0x6cf <generic_fexit_output+0x10f>
     69e:      	movl	$0x0, 0x4(%rsp)
     6a6:      	movq	(%rip), %rdi            # 0x6ad <generic_fexit_output+0xed>
     6ad:      	leaq	0x4(%rsp), %rsi
     6b2:      	movl	$0x1, %eax
     6b7:      	callq	*%rax
     6b9:      	testq	%rax, %rax
     6bc:      	je	0x6c3 <generic_fexit_output+0x103>
     6be:      	lock
     6bf:      	incq	0x8(%rax)
     6c3:      	xorl	%eax, %eax
     6c5:      	addq	$0x10, %rsp
     6c9:      	popq	%rbx
     6ca:      	popq	%r14
     6cc:      	popq	%r15
     6ce:      	retq
     6cf:      	movq	%rax, %rbx
     6d2:      	movl	$0x0, 0x4(%rsp)
     6da:      	movq	(%rip), %rdi            # 0x6e1 <generic_fexit_output+0x121>
     6e1:      	leaq	0x4(%rsp), %rsi
     6e6:      	movl	$0x1, %eax
     6eb:      	callq	*%rax
     6ed:      	testq	%rax, %rax
     6f0:      	je	0x6c3 <generic_fexit_output+0x103>
     6f2:      	cmpq	$-0xc, %rbx
     6f6:      	jg	0x762 <generic_fexit_output+0x1a2>
     6f8:      	cmpq	$-0x1c, %rbx
     6fc:      	je	0x7a4 <generic_fexit_output+0x1e4>
     702:      	cmpq	$-0x16, %rbx
     706:      	je	0x753 <generic_fexit_output+0x193>
     708:      	cmpq	$-0x10, %rbx
     70c:      	jne	0x795 <generic_fexit_output+0x1d5>
     712:      	addq	$0x2f0, %rax            # imm = 0x2F0
     718:      	lock
     719:      	incq	(%rax)
     71c:      	jmp	0x6c3 <generic_fexit_output+0x103>
     71e:      	movq	%rax, %rbx
     721:      	movl	$0x0, 0x4(%rsp)
     729:      	movq	(%rip), %rdi            # 0x730 <generic_fexit_output+0x170>
     730:      	leaq	0x4(%rsp), %rsi
     735:      	movl	$0x1, %eax
     73a:      	callq	*%rax
     73c:      	testq	%rax, %rax
     73f:      	je	0x6c3 <generic_fexit_output+0x103>
     741:      	cmpq	$-0xc, %rbx
     745:      	jg	0x783 <generic_fexit_output+0x1c3>
     747:      	cmpq	$-0x1c, %rbx
     74b:      	je	0x7a4 <generic_fexit_output+0x1e4>
     74d:      	cmpq	$-0x16, %rbx
     751:      	jne	0x708 <generic_fexit_output+0x148>
     753:      	addq	$0x2f8, %rax            # imm = 0x2F8
     759:      	lock
     75a:      	incq	(%rax)
     75d:      	jmp	0x6c3 <generic_fexit_output+0x103>
     762:      	cmpq	$-0xb, %rbx
     766:      	je	0x7b3 <generic_fexit_output+0x1f3>
     768:      	cmpq	$-0x7, %rbx
     76c:      	je	0x7c2 <generic_fexit_output+0x202>
     76e:      	cmpq	$-0x2, %rbx
     772:      	jne	0x795 <generic_fexit_output+0x1d5>
     774:      	addq	$0x2e0, %rax            # imm = 0x2E0
     77a:      	lock
     77b:      	incq	(%rax)
     77e:      	jmp	0x6c3 <generic_fexit_output+0x103>
     783:      	cmpq	$-0xb, %rbx
     787:      	je	0x7b3 <generic_fexit_output+0x1f3>
     789:      	cmpq	$-0x7, %rbx
     78d:      	je	0x7c2 <generic_fexit_output+0x202>
     78f:      	cmpq	$-0x2, %rbx
     793:      	je	0x774 <generic_fexit_output+0x1b4>
     795:      	addq	$0x2d8, %rax            # imm = 0x2D8
     79b:      	lock
     79c:      	incq	(%rax)
     79f:      	jmp	0x6c3 <generic_fexit_output+0x103>
     7a4:      	addq	$0x300, %rax            # imm = 0x300
     7aa:      	lock
     7ab:      	incq	(%rax)
     7ae:      	jmp	0x6c3 <generic_fexit_output+0x103>
     7b3:      	addq	$0x308, %rax            # imm = 0x308
     7b9:      	lock
     7ba:      	incq	(%rax)
     7bd:      	jmp	0x6c3 <generic_fexit_output+0x103>
     7c2:      	addq	$0x2e8, %rax            # imm = 0x2E8
     7c8:      	lock
     7c9:      	incq	(%rax)
     7cc:      	jmp	0x6c3 <generic_fexit_output+0x103>

Disassembly of section fexit/generic_fexit:

0000000000000000 <generic_fexit_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x108, %rsp            # imm = 0x108
      11:      	movq	%rdi, %r12
      14:      	leaq	0x100(%rsp), %rsi
      1c:      	movl	$0xb8, %eax
      21:      	callq	*%rax
      23:      	movq	0x100(%rsp), %rax
      2b:      	movq	%rax, 0xc8(%rsp)
      33:      	movl	$0x0, 0xe8(%rsp)
      3e:      	movq	(%rip), %rdi            # 0x45 <generic_fexit_event+0x45>
      45:      	leaq	0xe8(%rsp), %rsi
      4d:      	movl	$0x1, %eax
      52:      	callq	*%rax
      54:      	testq	%rax, %rax
      57:      	je	0x1de5 <generic_fexit_event+0x1de5>
      5d:      	movq	%rax, %r15
      60:      	movq	%rax, %rbx
      63:      	leaq	0x5ef8(%rax), %rsi
      6a:      	movl	$0x0, 0x5ef8(%r15)
      75:      	movq	(%rip), %rdi            # 0x7c <generic_fexit_event+0x7c>
      7c:      	movl	$0x1, %eax
      81:      	callq	*%rax
      83:      	testq	%rax, %rax
      86:      	je	0x1de5 <generic_fexit_event+0x1de5>
      8c:      	movq	%rax, %rbp
      8f:      	movl	(%rax), %eax
      91:      	movq	%rax, 0x60(%rbx)
      95:      	movl	$0xe, %eax
      9a:      	callq	*%rax
      9c:      	cmpq	$-0x16, %rax
      a0:      	jne	0xc2 <generic_fexit_event+0xc2>
      a2:      	leaq	0x20(%r12), %rdx
      a7:      	leaq	0x30(%rsp), %rdi
      ac:      	movl	$0x8, %ecx
      b1:      	movl	$0x4, %eax
      b6:      	movl	$0x8, %esi
      bb:      	callq	*%rax
      bd:      	movq	0x30(%rsp), %rax
      c2:      	movq	%rax, 0x68(%rbx)
      c6:      	movl	$0xe, %eax
      cb:      	callq	*%rax
      cd:      	movl	%eax, 0x7c(%rbx)
      d0:      	movq	0x60(%rbx), %rax
      d4:      	movq	0x68(%rbx), %rcx
      d8:      	movq	%rax, 0x30(%rsp)
      dd:      	movq	%rcx, 0x38(%rsp)
      e2:      	movq	(%rip), %rdi            # 0xe9 <generic_fexit_event+0xe9>
      e9:      	leaq	0x30(%rsp), %rsi
      ee:      	movl	$0x1, %eax
      f3:      	callq	*%rax
      f5:      	testq	%rax, %rax
      f8:      	je	0x1de5 <generic_fexit_event+0x1de5>
      fe:      	movq	(%rax), %r14
     101:      	movq	0x8(%rax), %rcx
     105:      	movq	%rcx, 0xa0(%rsp)
     10d:      	movq	0x10(%rax), %rax
     111:      	movq	%rax, 0x88(%rsp)
     119:      	movq	(%rip), %rdi            # 0x120 <generic_fexit_event+0x120>
     120:      	leaq	0x30(%rsp), %rsi
     125:      	movl	$0x3, %eax
     12a:      	callq	*%rax
     12c:      	movq	%r14, 0x90(%rbx)
     133:      	movl	0x58(%rbp), %eax
     136:      	movl	0x5c(%rbp), %r14d
     13a:      	testl	%r14d, %r14d
     13d:      	movq	%rbp, 0xb0(%rsp)
     145:      	je	0x220 <generic_fexit_event+0x220>
     14b:      	movl	%eax, 0x28(%rsp)
     14f:      	movl	$0x0, 0x5ea0(%rbx)
     159:      	movq	0xc8(%rsp), %rbp
     161:      	movl	$0x0, 0xec(%rsp)
     16c:      	movq	(%rip), %rdi            # 0x173 <generic_fexit_event+0x173>
     173:      	leaq	0xec(%rsp), %rsi
     17b:      	movl	$0x1, %eax
     180:      	callq	*%rax
     182:      	testq	%rax, %rax
     185:      	je	0x312 <generic_fexit_event+0x312>
     18b:      	movl	0x5ea0(%rax), %ecx
     191:      	movl	%ecx, 0x98(%rax)
     197:      	movq	$0xc, 0x5e78(%rax)
     1a2:      	movl	$0x4, %r13d
     1a8:      	testl	%ecx, %ecx
     1aa:      	jne	0x315 <generic_fexit_event+0x315>
     1b0:      	leaq	0x9c(%rax), %rcx
     1b7:      	movq	%rbp, 0x30(%rsp)
     1bc:      	movq	$0x0, 0x70(%rsp)
     1c5:      	cmpl	$0x17, %r14d
     1c9:      	movq	%rax, 0x8(%rsp)
     1ce:      	movq	%r15, 0x18(%rsp)
     1d3:      	movq	%r12, 0xc0(%rsp)
     1db:      	jle	0x389 <generic_fexit_event+0x389>
     1e1:      	cmpl	$0x18, %r14d
     1e5:      	je	0x3a4 <generic_fexit_event+0x3a4>
     1eb:      	cmpl	$0x25, %r14d
     1ef:      	je	0x3e2 <generic_fexit_event+0x3e2>
     1f5:      	cmpl	$0x2a, %r14d
     1f9:      	jne	0xa7d <generic_fexit_event+0xa7d>
     1ff:      	movq	$0x0, 0x90(%rsp)
     20b:      	movq	%rbp, 0x98(%rsp)
     213:      	leaq	0x90(%rsp), %rax
     21b:      	jmp	0x40f <generic_fexit_event+0x40f>
     220:      	movl	$0x8, %r13d
     226:      	addq	$0x90, %r15
     22d:      	cmpl	$0x3, %eax
     230:      	jne	0x1435 <generic_fexit_event+0x1435>
     236:      	movl	$0x0, (%r15,%r13)
     23e:      	leaq	0x4(%r13), %r14
     242:      	cmpq	$0x0, 0x88(%rsp)
     24b:      	movq	%r12, 0xc0(%rsp)
     253:      	je	0x371 <generic_fexit_event+0x371>
     259:      	movq	0xc8(%rsp), %r12
     261:      	leaq	0x30(%rsp), %rdi
     266:      	movl	$0x4, %ebp
     26b:      	movl	$0x10, %ecx
     270:      	movl	$0x4, %eax
     275:      	movq	0xa0(%rsp), %rdx
     27d:      	movl	$0x10, %esi
     282:      	callq	*%rax
     284:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     289:      	testl	%eax, %eax
     28b:      	js	0x1b36 <generic_fexit_event+0x1b36>
     291:      	movq	%r13, %rax
     294:      	movq	%r12, %rcx
     297:      	movq	0x38(%rsp), %rsi
     29c:      	cmpq	%r12, %rsi
     29f:      	movq	%r12, %r13
     2a2:      	cmovbq	%rsi, %r13
     2a6:      	testq	%r12, %r12
     2a9:      	cmovneq	%r13, %rsi
     2ad:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
     2b2:      	cmpq	$0xffe, %rsi            # imm = 0xFFE
     2b9:      	ja	0x1b36 <generic_fexit_event+0x1b36>
     2bf:      	addq	$0xc, %rax
     2c3:      	movq	%rax, 0x18(%rsp)
     2c8:      	leaq	(%r15,%rax), %rdi
     2cc:      	movq	0x30(%rsp), %rcx
     2d1:      	movl	$0x4, %eax
     2d6:      	movq	0x30(%rsp), %rdx
     2db:      	movq	%rsi, 0x28(%rsp)
     2e0:      	movq	0x28(%rsp), %rsi
     2e5:      	callq	*%rax
     2e7:      	movq	0x28(%rsp), %rdx
     2ec:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     2f1:      	testl	%eax, %eax
     2f3:      	js	0x1b36 <generic_fexit_event+0x1b36>
     2f9:      	testq	%r12, %r12
     2fc:      	je	0xc2c <generic_fexit_event+0xc2c>
     302:      	subq	%r13, %r12
     305:      	movq	%r12, 0x10(%rsp)
     30a:      	jne	0xc33 <generic_fexit_event+0xc33>
     310:      	jmp	0x374 <generic_fexit_event+0x374>
     312:      	xorl	%r13d, %r13d
     315:      	movq	0xb0(%rsp), %rbp
     31d:      	addq	$0x8, %r13
     321:      	movl	0x60(%rbp), %eax
     324:      	cmpl	$0xb, %eax
     327:      	je	0x1404 <generic_fexit_event+0x1404>
     32d:      	cmpl	$0xa, %eax
     330:      	jne	0x141a <generic_fexit_event+0x141a>
     336:      	movl	0x10(%rbx), %eax
     339:      	movl	%eax, 0x30(%rsp)
     33d:      	movl	0x7c(%rbx), %eax
     340:      	movl	%eax, 0x34(%rsp)
     344:      	movq	0x18(%rbx), %rax
     348:      	movq	%rax, 0x38(%rsp)
     34d:      	movq	(%rip), %rdi            # 0x354 <generic_fexit_event+0x354>
     354:      	xorl	%ecx, %ecx
     356:      	leaq	0xc8(%rsp), %rsi
     35e:      	leaq	0x30(%rsp), %rdx
     363:      	movl	$0x2, %eax
     368:      	xorl	%ecx, %ecx
     36a:      	callq	*%rax
     36c:      	jmp	0x141a <generic_fexit_event+0x141a>
     371:      	xorl	%r13d, %r13d
     374:      	movl	%r13d, (%r15,%r14)
     378:      	movl	%r13d, 0x4(%r15,%r14)
     37d:      	addq	$0x8, %r13
     381:      	movq	%r13, %rbp
     384:      	jmp	0x1b3a <generic_fexit_event+0x1b3a>
     389:      	cmpl	$0xf, %r14d
     38d:      	je	0x9b9 <generic_fexit_event+0x9b9>
     393:      	cmpl	$0x10, %r14d
     397:      	jne	0xa7d <generic_fexit_event+0xa7d>
     39d:      	leaq	0x20(%rsp), %r12
     3a2:      	jmp	0x3cc <generic_fexit_event+0x3cc>
     3a4:      	leaq	0x20(%rsp), %r12
     3a9:      	movl	$0x8, %ecx
     3ae:      	movl	$0x4, %eax
     3b3:      	movq	0x30(%rsp), %rdx
     3b8:      	movq	%r12, %rdi
     3bb:      	movl	$0x8, %esi
     3c0:      	callq	*%rax
     3c2:      	movq	0x20(%rsp), %rax
     3c7:      	movq	%rax, 0x30(%rsp)
     3cc:      	leaq	0x30(%rsp), %rdx
     3d1:      	movl	$0x8, %ecx
     3d6:      	movl	$0x4, %eax
     3db:      	leaq	0x20(%rsp), %rdi
     3e0:      	jmp	0x3ff <generic_fexit_event+0x3ff>
     3e2:      	addq	$0x40, %rbp
     3e6:      	movq	%rbp, 0x30(%rsp)
     3eb:      	leaq	0x20(%rsp), %rdi
     3f0:      	movl	$0x8, %ecx
     3f5:      	movl	$0x4, %eax
     3fa:      	movq	0x30(%rsp), %rdx
     3ff:      	movl	$0x8, %esi
     404:      	callq	*%rax
     406:      	movq	0x20(%rsp), %rax
     40b:      	addq	$0x40, %rax
     40f:      	movq	%rax, 0x80(%rsp)
     417:      	movl	$0x0, 0xbc(%rsp)
     422:      	movq	(%rip), %rdi            # 0x429 <generic_fexit_event+0x429>
     429:      	leaq	0xbc(%rsp), %rsi
     431:      	movl	$0x1, %eax
     436:      	callq	*%rax
     438:      	testq	%rax, %rax
     43b:      	je	0xb6a <generic_fexit_event+0xb6a>
     441:      	movq	%rax, %r12
     444:      	addq	$0x1000, %rax           # imm = 0x1000
     44a:      	movq	%rax, 0x10(%rsp)
     44f:      	movl	$0x23, %eax
     454:      	callq	*%rax
     456:      	leaq	0xd50(%rax), %rdx
     45d:      	leaq	0xd0(%rsp), %rdi
     465:      	movl	$0x8, %ecx
     46a:      	movl	$0x4, %eax
     46f:      	movl	$0x8, %esi
     474:      	callq	*%rax
     476:      	movq	0xd0(%rsp), %rbp
     47e:      	movq	0x80(%rsp), %rax
     486:      	leaq	0x8(%rax), %rdx
     48a:      	leaq	0xd8(%rsp), %rdi
     492:      	movl	$0x8, %ecx
     497:      	movl	$0x4, %eax
     49c:      	leaq	0x18(%rbp), %rcx
     4a0:      	movq	%rcx, 0xf8(%rsp)
     4a8:      	movl	$0x8, %esi
     4ad:      	movq	%rdx, 0xf0(%rsp)
     4b5:      	callq	*%rax
     4b7:      	movq	0xd8(%rsp), %r13
     4bf:      	leaq	0x10(%r13), %rdx
     4c3:      	leaq	0x30(%rsp), %rdi
     4c8:      	movl	$0x8, %ecx
     4cd:      	movl	$0x4, %eax
     4d2:      	movl	$0x8, %esi
     4d7:      	callq	*%rax
     4d9:      	cmpq	$0x0, 0x30(%rsp)
     4df:      	movl	$0x1000, %r14d          # imm = 0x1000
     4e5:      	je	0x4ee <generic_fexit_event+0x4ee>
     4e7:      	movq	0x10(%rsp), %rcx
     4ec:      	jmp	0x541 <generic_fexit_event+0x541>
     4ee:      	leaq	0x18(%r13), %rdx
     4f2:      	leaq	0x30(%rsp), %rdi
     4f7:      	movl	$0x8, %ecx
     4fc:      	movl	$0x4, %eax
     501:      	movl	$0x8, %esi
     506:      	callq	*%rax
     508:      	cmpq	%r13, 0x30(%rsp)
     50d:      	movq	0x10(%rsp), %rcx
     512:      	je	0x541 <generic_fexit_event+0x541>
     514:      	movq	%r12, %rcx
     517:      	addq	$0xff6, %rcx            # imm = 0xFF6
     51e:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
     528:      	movq	%rax, 0xff6(%r12)
     530:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
     53b:      	movl	$0xff6, %r14d           # imm = 0xFF6
     541:      	movq	$0x0, 0x38(%rsp)
     54a:      	movq	$0x0, 0x30(%rsp)
     553:      	movq	%r12, 0x40(%rsp)
     558:      	movq	$0x0, 0x48(%rsp)
     561:      	movq	$0x0, 0x50(%rsp)
     56a:      	movq	$0x0, 0x58(%rsp)
     573:      	movq	%rcx, 0x10(%rsp)
     578:      	movq	%rcx, 0x60(%rsp)
     57d:      	movl	%r14d, 0x68(%rsp)
     582:      	movb	$0x0, 0x6c(%rsp)
     587:      	addq	$0x20, %rbp
     58b:      	leaq	0x30(%rsp), %rdi
     590:      	movl	$0x8, %ecx
     595:      	movl	$0x4, %eax
     59a:      	leaq	0x38(%rsp), %r14
     59f:      	leaq	0x48(%rsp), %r13
     5a4:      	leaq	0x50(%rsp), %r12
     5a9:      	movl	$0x8, %esi
     5ae:      	movq	%rbp, %rdx
     5b1:      	callq	*%rax
     5b3:      	movl	$0x8, %ecx
     5b8:      	movl	$0x4, %eax
     5bd:      	movq	0xf8(%rsp), %rdx
     5c5:      	movq	%r14, %rdi
     5c8:      	movl	$0x8, %esi
     5cd:      	callq	*%rax
     5cf:      	movl	$0x8, %ecx
     5d4:      	movl	$0x4, %eax
     5d9:      	movq	0xf0(%rsp), %rdx
     5e1:      	movq	%r13, %rdi
     5e4:      	movl	$0x8, %esi
     5e9:      	callq	*%rax
     5eb:      	movl	$0x8, %ecx
     5f0:      	movl	$0x4, %eax
     5f5:      	movq	0x80(%rsp), %rdx
     5fd:      	movq	%r12, %rdi
     600:      	movl	$0x8, %esi
     605:      	callq	*%rax
     607:      	movq	0x50(%rsp), %rax
     60c:      	addq	$-0x20, %rax
     610:      	movq	%rax, 0x58(%rsp)
     615:      	movq	(%rip), %rax            # 0x61c <generic_fexit_event+0x61c>
     61c:      	cmpb	$0x0, (%rax)
     61f:      	je	0x7f5 <generic_fexit_event+0x7f5>
     625:      	movl	$0x800, %ebp            # imm = 0x800
     62a:      	movl	$0x8, %r14d
     630:      	movq	0x48(%rsp), %r13
     635:      	movq	0x50(%rsp), %rdx
     63a:      	movq	0x58(%rsp), %r12
     63f:      	cmpq	0x30(%rsp), %r13
     644:      	jne	0x651 <generic_fexit_event+0x651>
     646:      	cmpq	0x38(%rsp), %rdx
     64b:      	je	0xb24 <generic_fexit_event+0xb24>
     651:      	movl	$0x4, %eax
     656:      	leaq	0xa8(%rsp), %rdi
     65e:      	movl	$0x8, %esi
     663:      	callq	*%rax
     665:      	cmpq	0xa8(%rsp), %r13
     66d:      	movl	$0x8, %r15d
     673:      	je	0x786 <generic_fexit_event+0x786>
     679:      	leaq	0x18(%r13), %r14
     67d:      	movl	$0x4, %eax
     682:      	leaq	0x20(%rsp), %rdi
     687:      	movl	$0x8, %esi
     68c:      	movq	%r14, %rdx
     68f:      	callq	*%rax
     691:      	cmpq	%r13, 0x20(%rsp)
     696:      	je	0x786 <generic_fexit_event+0x786>
     69c:      	movl	$0x4, %eax
     6a1:      	leaq	0xe0(%rsp), %rdi
     6a9:      	movl	$0x8, %esi
     6ae:      	movq	%r14, %rdx
     6b1:      	callq	*%rax
     6b3:      	addq	$0x20, %r13
     6b7:      	movl	$0x4, %eax
     6bc:      	leaq	0x70(%rsp), %rdi
     6c1:      	movl	$0x10, %ecx
     6c6:      	movl	$0x10, %esi
     6cb:      	movq	%r13, %rdx
     6ce:      	callq	*%rax
     6d0:      	movq	0x40(%rsp), %r14
     6d5:      	movq	0x60(%rsp), %rax
     6da:      	movl	0x74(%rsp), %r12d
     6df:      	subq	%r14, %rax
     6e2:      	movl	0x68(%rsp), %r13d
     6e7:      	movl	%r12d, %edx
     6ea:      	subl	%r13d, %edx
     6ed:      	movl	$0x0, %ecx
     6f2:      	cmovbl	%ecx, %edx
     6f5:      	addq	0x78(%rsp), %rdx
     6fa:      	xorl	%esi, %esi
     6fc:      	cmpl	%r12d, %r13d
     6ff:      	seta	%sil
     703:      	movl	%r12d, %ecx
     706:      	cmovbl	%r13d, %ecx
     70a:      	addl	%ecx, %esi
     70c:      	movl	%r13d, %edi
     70f:      	subl	%esi, %edi
     711:      	movl	%edi, 0x68(%rsp)
     715:      	subq	%rsi, %rax
     718:      	movq	0x18(%rsp), %r15
     71d:      	jb	0xb29 <generic_fexit_event+0xb29>
     723:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     729:      	ja	0xb29 <generic_fexit_event+0xb29>
     72f:      	cmpl	%r12d, %r13d
     732:      	jbe	0x739 <generic_fexit_event+0x739>
     734:      	movb	$0x2f, (%r14,%rax)
     739:      	xorl	%edi, %edi
     73b:      	cmpl	%r12d, %r13d
     73e:      	seta	%dil
     742:      	movzbl	%cl, %esi
     745:      	addq	%rax, %r14
     748:      	addq	%r14, %rdi
     74b:      	movl	$0x4, %eax
     750:      	callq	*%rax
     752:      	movq	%r14, 0x60(%rsp)
     757:      	cmpl	%r12d, %r13d
     75a:      	jbe	0xb29 <generic_fexit_event+0xb29>
     760:      	movq	0xe0(%rsp), %rax
     768:      	movq	%rax, 0x48(%rsp)
     76d:      	movl	$0x4, %r13d
     773:      	movl	$0x8, %r14d
     779:      	decl	%ebp
     77b:      	jne	0x630 <generic_fexit_event+0x630>
     781:      	jmp	0xb2f <generic_fexit_event+0xb2f>
     786:      	leaq	0x10(%r12), %rdx
     78b:      	movl	$0x4, %eax
     790:      	leaq	0x20(%rsp), %rdi
     795:      	movl	$0x8, %esi
     79a:      	callq	*%rax
     79c:      	movq	0x58(%rsp), %rax
     7a1:      	cmpq	0x20(%rsp), %rax
     7a6:      	movl	$0x8, %r14d
     7ac:      	je	0xd0c <generic_fexit_event+0xd0c>
     7b2:      	addq	$0x18, %r12
     7b6:      	movl	$0x4, %eax
     7bb:      	leaq	0x48(%rsp), %rdi
     7c0:      	movl	$0x8, %esi
     7c5:      	movq	%r12, %rdx
     7c8:      	callq	*%rax
     7ca:      	movq	0x20(%rsp), %rax
     7cf:      	movq	%rax, 0x58(%rsp)
     7d4:      	addq	$0x20, %rax
     7d8:      	movq	%rax, 0x50(%rsp)
     7dd:      	movl	$0x4, %r13d
     7e3:      	movq	0x18(%rsp), %r15
     7e8:      	decl	%ebp
     7ea:      	jne	0x630 <generic_fexit_event+0x630>
     7f0:      	jmp	0xb2f <generic_fexit_event+0xb2f>
     7f5:      	movl	$0x800, %ebp            # imm = 0x800
     7fa:      	movl	$0x8, %r14d
     800:      	jmp	0x80a <generic_fexit_event+0x80a>
     802:      	decl	%ebp
     804:      	je	0xb2f <generic_fexit_event+0xb2f>
     80a:      	movq	0x48(%rsp), %r13
     80f:      	movq	0x50(%rsp), %rdx
     814:      	movq	0x58(%rsp), %r12
     819:      	cmpq	0x30(%rsp), %r13
     81e:      	jne	0x82b <generic_fexit_event+0x82b>
     820:      	cmpq	0x38(%rsp), %rdx
     825:      	je	0xb24 <generic_fexit_event+0xb24>
     82b:      	movl	$0x4, %eax
     830:      	leaq	0xa8(%rsp), %rdi
     838:      	movl	$0x8, %esi
     83d:      	callq	*%rax
     83f:      	cmpq	0xa8(%rsp), %r13
     847:      	movl	$0x8, %ecx
     84c:      	je	0x957 <generic_fexit_event+0x957>
     852:      	leaq	0x18(%r13), %r14
     856:      	movl	$0x4, %eax
     85b:      	leaq	0x20(%rsp), %rdi
     860:      	movl	$0x8, %esi
     865:      	movq	%r14, %rdx
     868:      	callq	*%rax
     86a:      	movl	$0x8, %ecx
     86f:      	cmpq	%r13, 0x20(%rsp)
     874:      	je	0x957 <generic_fexit_event+0x957>
     87a:      	movl	$0x4, %eax
     87f:      	leaq	0xe0(%rsp), %rdi
     887:      	movl	$0x8, %esi
     88c:      	movq	%r14, %rdx
     88f:      	callq	*%rax
     891:      	addq	$0x20, %r13
     895:      	movl	$0x4, %eax
     89a:      	leaq	0x70(%rsp), %rdi
     89f:      	movl	$0x10, %ecx
     8a4:      	movl	$0x10, %esi
     8a9:      	movq	%r13, %rdx
     8ac:      	callq	*%rax
     8ae:      	movq	0x40(%rsp), %r14
     8b3:      	movq	0x60(%rsp), %rax
     8b8:      	movl	0x74(%rsp), %r12d
     8bd:      	subq	%r14, %rax
     8c0:      	movl	0x68(%rsp), %r13d
     8c5:      	movl	%r12d, %edx
     8c8:      	subl	%r13d, %edx
     8cb:      	movl	$0x0, %ecx
     8d0:      	cmovbl	%ecx, %edx
     8d3:      	addq	0x78(%rsp), %rdx
     8d8:      	xorl	%esi, %esi
     8da:      	cmpl	%r12d, %r13d
     8dd:      	seta	%sil
     8e1:      	movl	%r12d, %ecx
     8e4:      	cmovbl	%r13d, %ecx
     8e8:      	addl	%ecx, %esi
     8ea:      	movl	%r13d, %edi
     8ed:      	subl	%esi, %edi
     8ef:      	movl	%edi, 0x68(%rsp)
     8f3:      	subq	%rsi, %rax
     8f6:      	jb	0xb29 <generic_fexit_event+0xb29>
     8fc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     902:      	ja	0xb29 <generic_fexit_event+0xb29>
     908:      	cmpl	%r12d, %r13d
     90b:      	jbe	0x912 <generic_fexit_event+0x912>
     90d:      	movb	$0x2f, (%r14,%rax)
     912:      	xorl	%edi, %edi
     914:      	cmpl	%r12d, %r13d
     917:      	seta	%dil
     91b:      	movzbl	%cl, %esi
     91e:      	addq	%rax, %r14
     921:      	addq	%r14, %rdi
     924:      	movl	$0x4, %eax
     929:      	callq	*%rax
     92b:      	movq	%r14, 0x60(%rsp)
     930:      	cmpl	%r12d, %r13d
     933:      	jbe	0xb29 <generic_fexit_event+0xb29>
     939:      	movq	0xe0(%rsp), %rax
     941:      	movq	%rax, 0x48(%rsp)
     946:      	movl	$0x4, %r13d
     94c:      	movl	$0x8, %r14d
     952:      	jmp	0x802 <generic_fexit_event+0x802>
     957:      	leaq	0x10(%r12), %rdx
     95c:      	movl	$0x4, %eax
     961:      	leaq	0x20(%rsp), %rdi
     966:      	movl	$0x8, %esi
     96b:      	callq	*%rax
     96d:      	movq	0x58(%rsp), %rax
     972:      	cmpq	0x20(%rsp), %rax
     977:      	movl	$0x8, %r14d
     97d:      	je	0xb24 <generic_fexit_event+0xb24>
     983:      	addq	$0x18, %r12
     987:      	movl	$0x4, %eax
     98c:      	leaq	0x48(%rsp), %rdi
     991:      	movl	$0x8, %esi
     996:      	movq	%r12, %rdx
     999:      	callq	*%rax
     99b:      	movq	0x20(%rsp), %rax
     9a0:      	movq	%rax, 0x58(%rsp)
     9a5:      	addq	$0x20, %rax
     9a9:      	movq	%rax, 0x50(%rsp)
     9ae:      	movl	$0x4, %r13d
     9b4:      	jmp	0x802 <generic_fexit_event+0x802>
     9b9:      	movq	%rcx, 0x10(%rsp)
     9be:      	leaq	0x70(%rsp), %rdi
     9c3:      	leaq	0x30(%rsp), %rdx
     9c8:      	movl	$0x8, %ecx
     9cd:      	movl	$0x4, %eax
     9d2:      	movl	$0x8, %esi
     9d7:      	callq	*%rax
     9d9:      	movq	0x70(%rsp), %rax
     9de:      	movq	%rax, 0x80(%rsp)
     9e6:      	testq	%rax, %rax
     9e9:      	jne	0x417 <generic_fexit_event+0x417>
     9ef:      	movl	$0x0, 0x90(%rsp)
     9fa:      	movq	(%rip), %rdi            # 0xa01 <generic_fexit_event+0xa01>
     a01:      	leaq	0x90(%rsp), %rsi
     a09:      	movl	$0x1, %eax
     a0e:      	callq	*%rax
     a10:      	testq	%rax, %rax
     a13:      	je	0x1392 <generic_fexit_event+0x1392>
     a19:      	xorl	%r12d, %r12d
     a1c:      	cmpl	$0x19, %r14d
     a20:      	movq	0x8(%rsp), %rcx
     a25:      	jg	0xf5d <generic_fexit_event+0xf5d>
     a2b:      	cmpl	$0x12, %r14d
     a2f:      	movq	0x10(%rsp), %rdi
     a34:      	jle	0x10b7 <generic_fexit_event+0x10b7>
     a3a:      	cmpl	$0x14, %r14d
     a3e:      	jle	0x14ca <generic_fexit_event+0x14ca>
     a44:      	cmpl	$0x15, %r14d
     a48:      	je	0x219f <generic_fexit_event+0x219f>
     a4e:      	cmpl	$0x16, %r14d
     a52:      	je	0x2108 <generic_fexit_event+0x2108>
     a58:      	cmpl	$0x17, %r14d
     a5c:      	jne	0x13bb <generic_fexit_event+0x13bb>
     a62:      	movl	$0x0, 0xa0(%rcx)
     a6c:      	movl	%ebp, 0x9c(%rcx)
     a72:      	movl	$0x8, %r12d
     a78:      	jmp	0x13bb <generic_fexit_event+0x13bb>
     a7d:      	movq	%rcx, 0x10(%rsp)
     a82:      	cmpl	$0x2c, %r14d
     a86:      	ja	0x9ef <generic_fexit_event+0x9ef>
     a8c:      	movl	%r14d, %eax
     a8f:      	movabsq	$0x11c1f2027cf2, %rcx   # imm = 0x11C1F2027CF2
     a99:      	btq	%rax, %rcx
     a9d:      	jae	0x9ef <generic_fexit_event+0x9ef>
     aa3:      	movq	%rbp, 0x20(%rsp)
     aa8:      	movl	$0x0, 0xe0(%rsp)
     ab3:      	movq	(%rip), %rdi            # 0xaba <generic_fexit_event+0xaba>
     aba:      	leaq	0xe0(%rsp), %rsi
     ac2:      	movl	$0x1, %eax
     ac7:      	callq	*%rax
     ac9:      	xorl	%r12d, %r12d
     acc:      	testq	%rax, %rax
     acf:      	je	0x13b6 <generic_fexit_event+0x13b6>
     ad5:      	cmpl	$0x10, %r14d
     ad9:      	jle	0xd21 <generic_fexit_event+0xd21>
     adf:      	cmpl	$0x1e, %r14d
     ae3:      	movq	0x10(%rsp), %rdi
     ae8:      	jle	0xe9e <generic_fexit_event+0xe9e>
     aee:      	cmpl	$0x26, %r14d
     af2:      	jg	0xf93 <generic_fexit_event+0xf93>
     af8:      	leal	-0x1f(%r14), %eax
     afc:      	cmpl	$0x2, %eax
     aff:      	jae	0x15a7 <generic_fexit_event+0x15a7>
     b05:      	leaq	0x20(%rsp), %rdx
     b0a:      	movl	$0x4, %r12d
     b10:      	movl	$0x1, %ecx
     b15:      	movl	$0x4, %eax
     b1a:      	movl	$0x1, %esi
     b1f:      	jmp	0x13b4 <generic_fexit_event+0x13b4>
     b24:      	movb	$0x1, 0x6c(%rsp)
     b29:      	movl	$0x4, %r13d
     b2f:      	movq	0x60(%rsp), %rax
     b34:      	movq	0x10(%rsp), %rdx
     b39:      	xorl	%ebp, %ebp
     b3b:      	cmpq	%rdx, %rax
     b3e:      	je	0xb7a <generic_fexit_event+0xb7a>
     b40:      	cmpb	$0x0, 0x6c(%rsp)
     b45:      	sete	%cl
     b48:      	movl	0x68(%rsp), %edx
     b4c:      	movl	$0x1000, %r12d          # imm = 0x1000
     b52:      	subl	%edx, %r12d
     b55:      	testl	%edx, %edx
     b57:      	cmovlel	%edx, %r12d
     b5b:      	testq	%rax, %rax
     b5e:      	je	0xb6a <generic_fexit_event+0xb6a>
     b60:      	movb	%cl, %bpl
     b63:      	addl	%ebp, %ebp
     b65:      	movq	%rax, %rdx
     b68:      	jmp	0xb7d <generic_fexit_event+0xb7d>
     b6a:      	xorl	%r12d, %r12d
     b6d:      	movq	0xb0(%rsp), %rbp
     b75:      	jmp	0x13c8 <generic_fexit_event+0x13c8>
     b7a:      	xorl	%r12d, %r12d
     b7d:      	movq	0x8(%rsp), %r14
     b82:      	movq	%r14, %rdi
     b85:      	addq	$0xa0, %rdi
     b8c:      	andl	$0xfff, %r12d           # imm = 0xFFF
     b93:      	movl	$0x4, %eax
     b98:      	movl	%r12d, %esi
     b9b:      	callq	*%rax
     b9d:      	movl	%r12d, 0x9c(%r14)
     ba4:      	leaq	0x30(%rsp), %rdi
     ba9:      	movl	$0x8, %ecx
     bae:      	movl	$0x4, %eax
     bb3:      	movq	0xf0(%rsp), %rdx
     bbb:      	movl	$0x8, %esi
     bc0:      	callq	*%rax
     bc2:      	movq	0x30(%rsp), %rcx
     bc7:      	addq	$0x30, %rcx
     bcb:      	leaq	0x70(%rsp), %rdi
     bd0:      	movl	$0x8, %edx
     bd5:      	movl	$0x4, %eax
     bda:      	movq	0x30(%rsp), %rdx
     bdf:      	addq	$0x30, %rdx
     be3:      	movl	$0x8, %esi
     be8:      	callq	*%rax
     bea:      	movq	0x70(%rsp), %rcx
     bef:      	leaq	0x20(%rsp), %rdi
     bf4:      	movl	$0x2, %edx
     bf9:      	movl	$0x4, %eax
     bfe:      	movq	0x70(%rsp), %rdx
     c03:      	movl	$0x2, %esi
     c08:      	callq	*%rax
     c0a:      	movq	%r14, %rcx
     c0d:      	movl	%ebp, 0xa0(%r14,%r12)
     c15:      	movzwl	0x20(%rsp), %eax
     c1a:      	movw	%ax, 0xa4(%r14,%r12)
     c23:      	addl	$0xa, %r12d
     c27:      	jmp	0x13bb <generic_fexit_event+0x13bb>
     c2c:      	xorl	%eax, %eax
     c2e:      	movq	%rax, 0x10(%rsp)
     c33:      	cmpq	$0x1, 0x88(%rsp)
     c3c:      	jne	0xc46 <generic_fexit_event+0xc46>
     c3e:      	movq	%rdx, %r13
     c41:      	jmp	0x374 <generic_fexit_event+0x374>
     c46:      	movq	0xa0(%rsp), %rax
     c4e:      	leaq	0x10(%rax), %rdx
     c52:      	leaq	0x30(%rsp), %rdi
     c57:      	movl	$0x4, %ebp
     c5c:      	movl	$0x10, %ecx
     c61:      	movl	$0x4, %eax
     c66:      	movl	$0x10, %esi
     c6b:      	callq	*%rax
     c6d:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     c72:      	testl	%eax, %eax
     c74:      	js	0x1b36 <generic_fexit_event+0x1b36>
     c7a:      	movq	0x38(%rsp), %r12
     c7f:      	movq	0x10(%rsp), %rax
     c84:      	cmpq	%rax, %r12
     c87:      	movq	%rax, %r13
     c8a:      	cmovbq	%r12, %r13
     c8e:      	testq	%rax, %rax
     c91:      	cmovneq	%r13, %r12
     c95:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
     c9a:      	cmpq	$0xffe, %r12            # imm = 0xFFE
     ca1:      	ja	0x1b36 <generic_fexit_event+0x1b36>
     ca7:      	movq	0x18(%rsp), %rax
     cac:      	addq	0x28(%rsp), %rax
     cb1:      	movq	%rax, 0x18(%rsp)
     cb6:      	leaq	(%r15,%rax), %rdi
     cba:      	movq	0x30(%rsp), %rcx
     cbf:      	movl	$0x4, %eax
     cc4:      	movq	0x30(%rsp), %rdx
     cc9:      	movl	%r12d, %esi
     ccc:      	callq	*%rax
     cce:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     cd3:      	testl	%eax, %eax
     cd5:      	js	0x1b36 <generic_fexit_event+0x1b36>
     cdb:      	movq	%r12, %rax
     cde:      	movq	0x28(%rsp), %r12
     ce3:      	movq	%rax, 0x8(%rsp)
     ce8:      	addq	%rax, %r12
     ceb:      	movq	0x10(%rsp), %rax
     cf0:      	testq	%rax, %rax
     cf3:      	je	0x1a5d <generic_fexit_event+0x1a5d>
     cf9:      	subq	%r13, %rax
     cfc:      	movq	%rax, 0x10(%rsp)
     d01:      	jne	0x1a64 <generic_fexit_event+0x1a64>
     d07:      	jmp	0x1df9 <generic_fexit_event+0x1df9>
     d0c:      	movb	$0x1, 0x6c(%rsp)
     d11:      	movl	$0x4, %r13d
     d17:      	movq	0x18(%rsp), %r15
     d1c:      	jmp	0xb2f <generic_fexit_event+0xb2f>
     d21:      	cmpl	$0x9, %r14d
     d25:      	movq	0x10(%rsp), %rdi
     d2a:      	jg	0xed0 <generic_fexit_event+0xed0>
     d30:      	cmpl	$0x4, %r14d
     d34:      	movq	0x8(%rsp), %rcx
     d39:      	jle	0x110a <generic_fexit_event+0x110a>
     d3f:      	cmpl	$0x5, %r14d
     d43:      	je	0x17a9 <generic_fexit_event+0x17a9>
     d49:      	cmpl	$0x6, %r14d
     d4d:      	je	0xf3a <generic_fexit_event+0xf3a>
     d53:      	cmpl	$0x7, %r14d
     d57:      	jne	0x13bb <generic_fexit_event+0x13bb>
     d5d:      	movq	%rax, %rbp
     d60:      	movq	0x20(%rsp), %r12
     d65:      	movq	%r12, 0xc4(%rcx)
     d6c:      	leaq	0xc2(%rcx), %rdi
     d73:      	leaq	0x10(%r12), %rdx
     d78:      	movq	%rcx, %r14
     d7b:      	movl	$0x2, %ecx
     d80:      	movl	$0x4, %eax
     d85:      	movl	$0x2, %esi
     d8a:      	callq	*%rax
     d8c:      	leaq	0xd6(%r14), %rdi
     d93:      	leaq	0x12(%r12), %rdx
     d98:      	movl	$0x1, %ecx
     d9d:      	movl	$0x4, %eax
     da2:      	movl	$0x1, %esi
     da7:      	callq	*%rax
     da9:      	leaq	0xd4(%r14), %rdi
     db0:      	leaq	0x226(%r12), %rdx
     db8:      	movl	$0x2, %ecx
     dbd:      	movl	$0x4, %eax
     dc2:      	movl	$0x2, %esi
     dc7:      	callq	*%rax
     dc9:      	leaq	0xc0(%r14), %rdi
     dd0:      	leaq	0x224(%r12), %rdx
     dd8:      	movl	$0x2, %ecx
     ddd:      	movl	$0x4, %eax
     de2:      	movl	$0x2, %esi
     de7:      	callq	*%rax
     de9:      	leaq	0xcc(%r14), %rdi
     df0:      	leaq	0x21c(%r12), %rdx
     df8:      	movl	$0x4, %ecx
     dfd:      	movl	$0x4, %eax
     e02:      	movl	$0x4, %esi
     e07:      	callq	*%rax
     e09:      	leaq	0xd0(%r14), %rdi
     e10:      	leaq	0x218(%r12), %rdx
     e18:      	movl	$0x4, %ecx
     e1d:      	movl	$0x4, %eax
     e22:      	movl	$0x4, %esi
     e27:      	callq	*%rax
     e29:      	movq	0x10(%rsp), %rdi
     e2e:      	leaq	0xac(%r14), %r13
     e35:      	movq	$0x0, (%rdi)
     e3c:      	movq	$0x0, 0x8(%rdi)
     e44:      	movq	$0x0, 0x10(%rdi)
     e4c:      	movq	$0x0, 0x18(%rdi)
     e54:      	movzwl	0xc2(%r14), %eax
     e5c:      	cmpl	$0xa, %eax
     e5f:      	je	0x251d <generic_fexit_event+0x251d>
     e65:      	cmpl	$0x2, %eax
     e68:      	jne	0x254c <generic_fexit_event+0x254c>
     e6e:      	leaq	0x4(%r12), %rdx
     e73:      	movl	$0x4, %ecx
     e78:      	movl	$0x4, %eax
     e7d:      	movl	$0x4, %esi
     e82:      	callq	*%rax
     e84:      	movl	$0x4, %ecx
     e89:      	movl	$0x4, %eax
     e8e:      	movq	%r13, %rdi
     e91:      	movl	$0x4, %esi
     e96:      	movq	%r12, %rdx
     e99:      	jmp	0x254a <generic_fexit_event+0x254a>
     e9e:      	cmpl	$0x1c, %r14d
     ea2:      	jg	0x10eb <generic_fexit_event+0x10eb>
     ea8:      	cmpl	$0x11, %r14d
     eac:      	je	0x15e5 <generic_fexit_event+0x15e5>
     eb2:      	cmpl	$0x19, %r14d
     eb6:      	je	0x16b8 <generic_fexit_event+0x16b8>
     ebc:      	cmpl	$0x1c, %r14d
     ec0:      	movq	0x8(%rsp), %rcx
     ec5:      	je	0x111a <generic_fexit_event+0x111a>
     ecb:      	jmp	0x13bb <generic_fexit_event+0x13bb>
     ed0:      	leal	-0xa(%r14), %eax
     ed4:      	cmpl	$0x2, %eax
     ed7:      	movq	0x8(%rsp), %rcx
     edc:      	jb	0x111a <generic_fexit_event+0x111a>
     ee2:      	leal	-0xc(%r14), %eax
     ee6:      	cmpl	$0x2, %eax
     ee9:      	jb	0x1139 <generic_fexit_event+0x1139>
     eef:      	cmpl	$0xe, %r14d
     ef3:      	jne	0x13bb <generic_fexit_event+0x13bb>
     ef9:      	leaq	0x30(%rsp), %rdi
     efe:      	leaq	0x20(%rsp), %r14
     f03:      	movl	$0x8, %ecx
     f08:      	movl	$0x4, %eax
     f0d:      	movl	$0x8, %esi
     f12:      	movq	%r14, %rdx
     f15:      	callq	*%rax
     f17:      	movq	0x30(%rsp), %rcx
     f1c:      	movl	$0x8, %edx
     f21:      	movl	$0x4, %eax
     f26:      	movq	0x30(%rsp), %rdx
     f2b:      	movq	%r14, %rdi
     f2e:      	movl	$0x8, %esi
     f33:      	callq	*%rax
     f35:      	movq	0x8(%rsp), %rcx
     f3a:      	movq	0x20(%rsp), %rdx
     f3f:      	movq	%rcx, %rdi
     f42:      	addq	$0xa0, %rdi
     f49:      	movl	$0x1001, %ecx           # imm = 0x1001
     f4e:      	movl	$0x2d, %eax
     f53:      	movl	$0x1001, %esi           # imm = 0x1001
     f58:      	jmp	0x199e <generic_fexit_event+0x199e>
     f5d:      	cmpl	$0x20, %r14d
     f61:      	movq	0x10(%rsp), %rdi
     f66:      	jle	0x12d9 <generic_fexit_event+0x12d9>
     f6c:      	leal	-0x21(%r14), %edx
     f70:      	cmpl	$0x4, %edx
     f73:      	jae	0x1158 <generic_fexit_event+0x1158>
     f79:      	movl	$0x8, %r12d
     f7f:      	movl	$0x8, %ecx
     f84:      	movl	$0x4, %eax
     f89:      	movl	$0x8, %esi
     f8e:      	jmp	0x13b1 <generic_fexit_event+0x13b1>
     f93:      	cmpl	$0x27, %r14d
     f97:      	je	0x1979 <generic_fexit_event+0x1979>
     f9d:      	cmpl	$0x28, %r14d
     fa1:      	je	0x19c1 <generic_fexit_event+0x19c1>
     fa7:      	cmpl	$0x2c, %r14d
     fab:      	movq	0x8(%rsp), %rcx
     fb0:      	jne	0x13bb <generic_fexit_event+0x13bb>
     fb6:      	movq	0x20(%rsp), %r12
     fbb:      	movb	$0x0, 0x30(%rsp)
     fc0:      	movq	$0x0, 0x68(%rdi)
     fc8:      	movq	$0x0, 0x60(%rdi)
     fd0:      	movq	$0x0, 0x58(%rdi)
     fd8:      	movq	$0x0, 0x50(%rdi)
     fe0:      	movq	$0x0, 0x48(%rdi)
     fe8:      	movq	$0x0, 0x40(%rdi)
     ff0:      	movq	$0x0, 0x38(%rdi)
     ff8:      	movq	$0x0, 0x30(%rdi)
    1000:      	movq	$0x0, 0x28(%rdi)
    1008:      	movq	$0x0, 0x20(%rdi)
    1010:      	movq	$0x0, 0x18(%rdi)
    1018:      	movq	$0x0, 0x10(%rdi)
    1020:      	movq	$0x0, 0x8(%rdi)
    1028:      	movq	$0x0, (%rdi)
    102f:      	movl	$0x2, %ecx
    1034:      	movl	$0x4, %eax
    1039:      	movl	$0x2, %esi
    103e:      	movq	%r12, %rdx
    1041:      	callq	*%rax
    1043:      	testq	%rax, %rax
    1046:      	js	0x277d <generic_fexit_event+0x277d>
    104c:      	leaq	0x2(%r12), %r13
    1051:      	leaq	0x30(%rsp), %rdi
    1056:      	movl	$0x1, %ecx
    105b:      	movl	$0x4, %eax
    1060:      	movl	$0x1, %esi
    1065:      	movq	%r13, %rdx
    1068:      	callq	*%rax
    106a:      	testq	%rax, %rax
    106d:      	js	0x277d <generic_fexit_event+0x277d>
    1073:      	movq	0x8(%rsp), %rax
    1078:      	movq	%rax, %rdi
    107b:      	addq	$0xa0, %rdi
    1082:      	cmpb	$0x0, 0x30(%rsp)
    1087:      	sete	0x9e(%rax)
    108e:      	je	0x2751 <generic_fexit_event+0x2751>
    1094:      	movl	$0x6c, %ecx
    1099:      	movl	$0x2d, %eax
    109e:      	movl	$0x6c, %esi
    10a3:      	movq	%r13, %rdx
    10a6:      	callq	*%rax
    10a8:      	testl	%eax, %eax
    10aa:      	js	0x277d <generic_fexit_event+0x277d>
    10b0:      	decb	%al
    10b2:      	jmp	0x2772 <generic_fexit_event+0x2772>
    10b7:      	cmpl	$0x7, %r14d
    10bb:      	jg	0x1397 <generic_fexit_event+0x1397>
    10c1:      	cmpl	$0x2, %r14d
    10c5:      	je	0x1e01 <generic_fexit_event+0x1e01>
    10cb:      	cmpl	$0x3, %r14d
    10cf:      	jne	0x13bb <generic_fexit_event+0x13bb>
    10d5:      	movq	$0x0, 0x9c(%rax)
    10e0:      	movl	$0x8, %r12d
    10e6:      	jmp	0x13bb <generic_fexit_event+0x13bb>
    10eb:      	leaq	0x20(%rsp), %rdx
    10f0:      	movl	$0x4, %r12d
    10f6:      	movl	$0x2, %ecx
    10fb:      	movl	$0x4, %eax
    1100:      	movl	$0x2, %esi
    1105:      	jmp	0x13b4 <generic_fexit_event+0x13b4>
    110a:      	cmpl	$0x1, %r14d
    110e:      	je	0x1139 <generic_fexit_event+0x1139>
    1110:      	cmpl	$0x4, %r14d
    1114:      	jne	0x13bb <generic_fexit_event+0x13bb>
    111a:      	movl	$0x8, %r12d
    1120:      	leaq	0x20(%rsp), %rdx
    1125:      	movl	$0x8, %ecx
    112a:      	movl	$0x4, %eax
    112f:      	movl	$0x8, %esi
    1134:      	jmp	0x13b4 <generic_fexit_event+0x13b4>
    1139:      	leaq	0x20(%rsp), %rdx
    113e:      	movl	$0x4, %r12d
    1144:      	movl	$0x4, %ecx
    1149:      	movl	$0x4, %eax
    114e:      	movl	$0x4, %esi
    1153:      	jmp	0x13b4 <generic_fexit_event+0x13b4>
    1158:      	cmpl	$0x2b, %r14d
    115c:      	je	0x22a7 <generic_fexit_event+0x22a7>
    1162:      	cmpl	$0x29, %r14d
    1166:      	jne	0x13bb <generic_fexit_event+0x13bb>
    116c:      	movq	%rax, 0x80(%rsp)
    1174:      	movq	%rdi, %r14
    1177:      	addq	$0x18, %rbp
    117b:      	leaq	0x30(%rsp), %rdi
    1180:      	movl	$0x4, %r13d
    1186:      	movl	$0x8, %ecx
    118b:      	movl	$0x4, %eax
    1190:      	movl	$0x8, %esi
    1195:      	movq	%rbp, %rdx
    1198:      	callq	*%rax
    119a:      	movq	0x30(%rsp), %r12
    119f:      	testq	%r12, %r12
    11a2:      	je	0x2819 <generic_fexit_event+0x2819>
    11a8:      	movq	0x8(%rsp), %rbp
    11ad:      	movq	%r12, 0xc4(%rbp)
    11b4:      	leaq	0xc2(%rbp), %rdi
    11bb:      	leaq	0x10(%r12), %rdx
    11c0:      	movl	$0x2, %ecx
    11c5:      	movl	$0x4, %eax
    11ca:      	movl	$0x2, %esi
    11cf:      	callq	*%rax
    11d1:      	leaq	0xd6(%rbp), %rdi
    11d8:      	leaq	0x12(%r12), %rdx
    11dd:      	movl	$0x1, %ecx
    11e2:      	movl	$0x4, %eax
    11e7:      	movl	$0x1, %esi
    11ec:      	callq	*%rax
    11ee:      	leaq	0xd4(%rbp), %rdi
    11f5:      	leaq	0x226(%r12), %rdx
    11fd:      	movl	$0x2, %ecx
    1202:      	movl	$0x4, %eax
    1207:      	movl	$0x2, %esi
    120c:      	callq	*%rax
    120e:      	leaq	0xc0(%rbp), %rdi
    1215:      	leaq	0x224(%r12), %rdx
    121d:      	movl	$0x2, %ecx
    1222:      	movl	$0x4, %eax
    1227:      	movl	$0x2, %esi
    122c:      	callq	*%rax
    122e:      	leaq	0xcc(%rbp), %rdi
    1235:      	leaq	0x21c(%r12), %rdx
    123d:      	movl	$0x4, %eax
    1242:      	movl	$0x4, %esi
    1247:      	callq	*%rax
    1249:      	leaq	0xd0(%rbp), %rdi
    1250:      	leaq	0x218(%r12), %rdx
    1258:      	movl	$0x4, %eax
    125d:      	movl	$0x4, %esi
    1262:      	callq	*%rax
    1264:      	leaq	0xac(%rbp), %r13
    126b:      	movq	%r14, %rax
    126e:      	movq	$0x0, (%r14)
    1275:      	movq	$0x0, 0x8(%r14)
    127d:      	movq	$0x0, 0x10(%r14)
    1285:      	movq	$0x0, 0x18(%r14)
    128d:      	movzwl	0xc2(%rbp), %eax
    1294:      	cmpl	$0xa, %eax
    1297:      	je	0x278e <generic_fexit_event+0x278e>
    129d:      	cmpl	$0x2, %eax
    12a0:      	jne	0x27c0 <generic_fexit_event+0x27c0>
    12a6:      	leaq	0x4(%r12), %rdx
    12ab:      	movl	$0x4, %ecx
    12b0:      	movl	$0x4, %eax
    12b5:      	movq	%r14, %rdi
    12b8:      	movl	$0x4, %esi
    12bd:      	callq	*%rax
    12bf:      	movl	$0x4, %ecx
    12c4:      	movl	$0x4, %eax
    12c9:      	movq	%r13, %rdi
    12cc:      	movl	$0x4, %esi
    12d1:      	movq	%r12, %rdx
    12d4:      	jmp	0x27be <generic_fexit_event+0x27be>
    12d9:      	cmpl	$0x1a, %r14d
    12dd:      	je	0x2355 <generic_fexit_event+0x2355>
    12e3:      	cmpl	$0x1b, %r14d
    12e7:      	jne	0x13bb <generic_fexit_event+0x13bb>
    12ed:      	movq	$0x0, 0x48(%rdi)
    12f5:      	movq	$0x0, 0x40(%rdi)
    12fd:      	movq	$0x0, 0x38(%rdi)
    1305:      	movq	$0x0, 0x30(%rdi)
    130d:      	movq	$0x0, 0x28(%rdi)
    1315:      	movq	$0x0, 0x20(%rdi)
    131d:      	movq	$0x0, 0x18(%rdi)
    1325:      	movq	$0x0, 0x10(%rdi)
    132d:      	movq	$0x0, 0x8(%rdi)
    1335:      	movq	$0x0, (%rdi)
    133c:      	leaq	0xac(%rcx), %rdi
    1343:      	leaq	0x18(%rbp), %rdx
    1347:      	movl	$0x3f, %ecx
    134c:      	movl	$0x2d, %eax
    1351:      	movl	$0x3f, %esi
    1356:      	callq	*%rax
    1358:      	testq	%rax, %rax
    135b:      	js	0x1392 <generic_fexit_event+0x1392>
    135d:      	movq	0x8(%rsp), %r14
    1362:      	movq	%r14, %rdi
    1365:      	addq	$0xa4, %rdi
    136c:      	addq	$0x348, %rbp            # imm = 0x348
    1373:      	movl	$0x8, %ecx
    1378:      	movl	$0x4, %eax
    137d:      	movl	$0x8, %esi
    1382:      	movq	%rbp, %rdx
    1385:      	callq	*%rax
    1387:      	movq	%r14, %rcx
    138a:      	movl	$0x50, %r12d
    1390:      	jmp	0x13bb <generic_fexit_event+0x13bb>
    1392:      	xorl	%r12d, %r12d
    1395:      	jmp	0x13b6 <generic_fexit_event+0x13b6>
    1397:      	cmpl	$0x8, %r14d
    139b:      	je	0x1eaf <generic_fexit_event+0x1eaf>
    13a1:      	cmpl	$0x12, %r14d
    13a5:      	jne	0x13bb <generic_fexit_event+0x13bb>
    13a7:      	xorl	%r12d, %r12d
    13aa:      	movl	$0x4, %eax
    13af:      	xorl	%esi, %esi
    13b1:      	movq	%rbp, %rdx
    13b4:      	callq	*%rax
    13b6:      	movq	0x8(%rsp), %rcx
    13bb:      	testl	%r12d, %r12d
    13be:      	movq	0xb0(%rsp), %rbp
    13c6:      	js	0x13d8 <generic_fexit_event+0x13d8>
    13c8:      	andl	$0x7fffffff, %r12d      # imm = 0x7FFFFFFF
    13cf:      	addq	$0x4, %r12
    13d3:      	movq	%r12, %r13
    13d6:      	jmp	0x13ec <generic_fexit_event+0x13ec>
    13d8:      	movl	$0xffffffff, 0x5ea0(%rcx) # imm = 0xFFFFFFFF
    13e2:      	movl	$0xffffffff, 0x98(%rcx) # imm = 0xFFFFFFFF
    13ec:      	movq	0xc0(%rsp), %r12
    13f4:      	addq	$0x8, %r13
    13f8:      	movl	0x60(%rbp), %eax
    13fb:      	cmpl	$0xb, %eax
    13fe:      	jne	0x32d <generic_fexit_event+0x32d>
    1404:      	movq	(%rip), %rdi            # 0x140b <generic_fexit_event+0x140b>
    140b:      	leaq	0xc8(%rsp), %rsi
    1413:      	movl	$0x3, %eax
    1418:      	callq	*%rax
    141a:      	andl	$0x1fff, %r13d          # imm = 0x1FFF
    1421:      	movl	0x28(%rsp), %eax
    1425:      	addq	$0x90, %r15
    142c:      	cmpl	$0x3, %eax
    142f:      	je	0x236 <generic_fexit_event+0x236>
    1435:      	cmpl	$0x2, %eax
    1438:      	jne	0x1b50 <generic_fexit_event+0x1b50>
    143e:      	movq	%rbx, 0x88(%rsp)
    1446:      	movq	%r12, %rbp
    1449:      	movl	$0x0, (%r15,%r13)
    1451:      	movq	0xc8(%rsp), %r14
    1459:      	cmpq	$0xfff, %r14            # imm = 0xFFF
    1460:      	movl	$0xfff, %r12d           # imm = 0xFFF
    1466:      	cmovbq	%r14, %r12
    146a:      	leaq	(%r15,%r13), %rdi
    146e:      	addq	$0xc, %rdi
    1472:      	movl	$0x4, %eax
    1477:      	movq	0xa0(%rsp), %rdx
    147f:      	leaq	0x4(%r13), %rbx
    1483:      	addq	%r13, %r15
    1486:      	addq	$0x4, %r15
    148a:      	movl	$0x4, %r13d
    1490:      	movl	%r12d, %esi
    1493:      	callq	*%rax
    1495:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    149a:      	testl	%eax, %eax
    149c:      	js	0x14ac <generic_fexit_event+0x14ac>
    149e:      	movl	%r12d, 0x4(%r15)
    14a2:      	addq	$0x8, %r12
    14a6:      	movl	%r14d, %ecx
    14a9:      	movq	%r12, %r13
    14ac:      	addq	%rbx, %r13
    14af:      	movl	%ecx, (%r15)
    14b2:      	movq	%rbp, %r12
    14b5:      	movq	0xb0(%rsp), %rbp
    14bd:      	movq	0x88(%rsp), %rbx
    14c5:      	jmp	0x1b50 <generic_fexit_event+0x1b50>
    14ca:      	cmpl	$0x13, %r14d
    14ce:      	je	0x224b <generic_fexit_event+0x224b>
    14d4:      	cmpl	$0x14, %r14d
    14d8:      	jne	0x13bb <generic_fexit_event+0x13bb>
    14de:      	movq	$0x0, 0x30(%rsp)
    14e7:      	leaq	0x110(%rbp), %rdx
    14ee:      	movq	%rdi, %r14
    14f1:      	leaq	0x30(%rsp), %rdi
    14f6:      	movl	$0x8, %ecx
    14fb:      	movl	$0x4, %eax
    1500:      	leaq	0xd8(%rbp), %r12
    1507:      	movl	$0x8, %esi
    150c:      	callq	*%rax
    150e:      	movq	0x30(%rsp), %rcx
    1513:      	movl	$0x80, %edx
    1518:      	movl	$0x2d, %eax
    151d:      	movq	0x30(%rsp), %rdx
    1522:      	movq	%r14, %rdi
    1525:      	movl	$0x80, %esi
    152a:      	callq	*%rax
    152c:      	movq	0x8(%rsp), %rax
    1531:      	leaq	0x12c(%rax), %rdi
    1538:      	movl	$0x4, %ecx
    153d:      	movl	$0x4, %eax
    1542:      	movl	$0x4, %esi
    1547:      	movq	%r12, %rdx
    154a:      	callq	*%rax
    154c:      	movq	0x8(%rsp), %rax
    1551:      	leaq	0x11c(%rax), %rdi
    1558:      	leaq	0xe0(%rbp), %rdx
    155f:      	movl	$0x8, %ecx
    1564:      	movl	$0x4, %eax
    1569:      	movl	$0x8, %esi
    156e:      	callq	*%rax
    1570:      	movq	0x8(%rsp), %rdi
    1575:      	addq	$0x124, %rdi            # imm = 0x124
    157c:      	addq	$0x118, %rbp            # imm = 0x118
    1583:      	movl	$0x8, %ecx
    1588:      	movl	$0x4, %eax
    158d:      	movl	$0x8, %esi
    1592:      	movq	%rbp, %rdx
    1595:      	callq	*%rax
    1597:      	movq	0x8(%rsp), %rcx
    159c:      	movl	$0x98, %r12d
    15a2:      	jmp	0x13bb <generic_fexit_event+0x13bb>
    15a7:      	cmpl	$0x26, %r14d
    15ab:      	movq	0x8(%rsp), %rcx
    15b0:      	jne	0x13bb <generic_fexit_event+0x13bb>
    15b6:      	movq	0x20(%rsp), %rsi
    15bb:      	movzwl	%si, %edx
    15be:      	addq	0xc0(%rsp), %rdx
    15c6:      	shrl	$0x10, %esi
    15c9:      	andl	$0xfff, %esi            # imm = 0xFFF
    15cf:      	movq	%rcx, %rdi
    15d2:      	addq	$0xa0, %rdi
    15d9:      	incl	%esi
    15db:      	movl	$0x2d, %eax
    15e0:      	jmp	0x199e <generic_fexit_event+0x199e>
    15e5:      	movq	$0x0, 0x38(%rsp)
    15ee:      	movq	$0x0, 0x30(%rsp)
    15f7:      	movl	$0xe, %eax
    15fc:      	callq	*%rax
    15fe:      	shrq	$0x20, %rax
    1602:      	movq	%rax, 0x30(%rsp)
    1607:      	leaq	0x70(%rsp), %rdi
    160c:      	leaq	0x20(%rsp), %rdx
    1611:      	movl	$0x4, %ecx
    1616:      	movl	$0x4, %eax
    161b:      	movl	$0x4, %r14d
    1621:      	movl	$0x4, %esi
    1626:      	callq	*%rax
    1628:      	movl	0x70(%rsp), %eax
    162c:      	movl	%eax, 0x38(%rsp)
    1630:      	movq	(%rip), %rdi            # 0x1637 <generic_fexit_event+0x1637>
    1637:      	leaq	0x30(%rsp), %rsi
    163c:      	movl	$0x1, %eax
    1641:      	callq	*%rax
    1643:      	testq	%rax, %rax
    1646:      	je	0x23d1 <generic_fexit_event+0x23d1>
    164c:      	movl	(%rax), %r12d
    164f:      	leaq	0x70(%rsp), %rdx
    1654:      	movq	%rax, %r13
    1657:      	movl	$0x4, %eax
    165c:      	movq	0x10(%rsp), %rbp
    1661:      	movq	%rbp, %rdi
    1664:      	movl	$0x4, %esi
    1669:      	callq	*%rax
    166b:      	andl	$0xfff, %r12d           # imm = 0xFFF
    1672:      	movq	0x8(%rsp), %rdi
    1677:      	addq	$0xa0, %rdi
    167e:      	leaq	0x4(%r12), %rsi
    1683:      	movl	$0x4, %eax
    1688:      	movq	%r13, %rdx
    168b:      	callq	*%rax
    168d:      	leaq	(%r12,%rbp), %rdi
    1691:      	addq	$0x8, %rdi
    1695:      	leaq	(%r12,%r13), %rdx
    1699:      	addq	$0x4, %rdx
    169d:      	movl	$0x4, %eax
    16a2:      	movl	$0x4, %esi
    16a7:      	callq	*%rax
    16a9:      	addq	$0xc, %r12
    16ad:      	movl	$0x4, %r13d
    16b3:      	jmp	0x13b6 <generic_fexit_event+0x13b6>
    16b8:      	movq	%rax, %r14
    16bb:      	movq	0x20(%rsp), %r13
    16c0:      	leaq	0xa8(%rsp), %rdi
    16c8:      	movl	$0x1, %ecx
    16cd:      	movl	$0x4, %eax
    16d2:      	movl	$0x1, %esi
    16d7:      	movq	%r13, %rdx
    16da:      	callq	*%rax
    16dc:      	movzbl	0xa8(%rsp), %eax
    16e4:      	testl	%eax, %eax
    16e6:      	je	0x23e3 <generic_fexit_event+0x23e3>
    16ec:      	cmpl	$0x1, %eax
    16ef:      	jne	0x25eb <generic_fexit_event+0x25eb>
    16f5:      	addq	$0x10, %r13
    16f9:      	leaq	0x30(%rsp), %rdi
    16fe:      	movl	$0x4, %r12d
    1704:      	movl	$0x8, %ecx
    1709:      	movl	$0x4, %eax
    170e:      	movl	$0x8, %esi
    1713:      	movq	%r13, %rdx
    1716:      	callq	*%rax
    1718:      	movq	0x30(%rsp), %rdx
    171d:      	leaq	0x70(%rsp), %rdi
    1722:      	movl	$0x8, %ecx
    1727:      	movl	$0x4, %eax
    172c:      	movl	$0x8, %esi
    1731:      	callq	*%rax
    1733:      	movq	0x30(%rsp), %rdx
    1738:      	addq	$0x8, %rdx
    173c:      	leaq	0x90(%rsp), %rdi
    1744:      	movl	$0x8, %ecx
    1749:      	movl	$0x4, %eax
    174e:      	movl	$0x8, %esi
    1753:      	callq	*%rax
    1755:      	movq	0x70(%rsp), %rdx
    175a:      	movq	0x90(%rsp), %rbp
    1762:      	cmpq	$0xfff, %rbp            # imm = 0xFFF
    1769:      	movl	$0xfff, %r13d           # imm = 0xFFF
    176f:      	cmovbq	%rbp, %r13
    1773:      	movq	%r14, %rdi
    1776:      	addq	$0xa4, %rdi
    177d:      	movl	$0x4, %eax
    1782:      	movl	%r13d, %esi
    1785:      	callq	*%rax
    1787:      	testl	%eax, %eax
    1789:      	js	0x272b <generic_fexit_event+0x272b>
    178f:      	movl	%ebp, 0x9c(%r14)
    1796:      	movl	%r13d, 0xa0(%r14)
    179d:      	addq	$0x8, %r13
    17a1:      	movq	%r13, %r12
    17a4:      	jmp	0x2863 <generic_fexit_event+0x2863>
    17a9:      	movq	0x20(%rsp), %rbp
    17ae:      	leaq	0xc4(%rcx), %rdi
    17b5:      	leaq	0x98(%rbp), %rdx
    17bc:      	movq	%rcx, %r14
    17bf:      	movl	$0x4, %ecx
    17c4:      	movl	$0x4, %eax
    17c9:      	movl	$0x4, %esi
    17ce:      	callq	*%rax
    17d0:      	leaq	0xc8(%r14), %rdi
    17d7:      	leaq	0x70(%rbp), %rdx
    17db:      	movl	$0x4, %ecx
    17e0:      	movl	$0x4, %eax
    17e5:      	movl	$0x4, %esi
    17ea:      	callq	*%rax
    17ec:      	leaq	0xcc(%r14), %rdi
    17f3:      	leaq	0x90(%rbp), %rdx
    17fa:      	movl	$0x4, %ecx
    17ff:      	movl	$0x4, %eax
    1804:      	movl	$0x4, %esi
    1809:      	callq	*%rax
    180b:      	leaq	0xd0(%r14), %rdi
    1812:      	leaq	0xa8(%rbp), %rdx
    1819:      	movl	$0x4, %ecx
    181e:      	movl	$0x4, %eax
    1823:      	movl	$0x4, %esi
    1828:      	callq	*%rax
    182a:      	movq	$0x0, 0x30(%rsp)
    1833:      	leaq	0xc8(%rbp), %rdx
    183a:      	leaq	0x30(%rsp), %rdi
    183f:      	movl	$0x8, %ecx
    1844:      	movl	$0x4, %eax
    1849:      	movl	$0x8, %esi
    184e:      	callq	*%rax
    1850:      	leaq	0xb8(%rbp), %rdx
    1857:      	leaq	0xa8(%rsp), %rdi
    185f:      	movl	$0x2, %ecx
    1864:      	movl	$0x4, %eax
    1869:      	movl	$0x2, %esi
    186e:      	callq	*%rax
    1870:      	movzwl	0xa8(%rsp), %r12d
    1879:      	addq	0x30(%rsp), %r12
    187e:      	leaq	0xbc(%rsp), %rdi
    1886:      	movl	$0x1, %ecx
    188b:      	movl	$0x4, %eax
    1890:      	movl	$0x1, %esi
    1895:      	movq	%r12, %rdx
    1898:      	callq	*%rax
    189a:      	movzbl	0xbc(%rsp), %eax
    18a2:      	shrl	$0x4, %eax
    18a5:      	cmpl	$0x6, %eax
    18a8:      	je	0x246e <generic_fexit_event+0x246e>
    18ae:      	cmpl	$0x4, %eax
    18b1:      	jne	0x31e1 <generic_fexit_event+0x31e1>
    18b7:      	leaq	0x9(%r12), %rdx
    18bc:      	leaq	0xd0(%rsp), %rdi
    18c4:      	movl	$0x1, %ecx
    18c9:      	movl	$0x4, %eax
    18ce:      	movl	$0x1, %esi
    18d3:      	callq	*%rax
    18d5:      	movzbl	0xd0(%rsp), %eax
    18dd:      	movq	0x8(%rsp), %rsi
    18e2:      	movw	%ax, 0xc0(%rsi)
    18e9:      	movw	$0x2, 0xc2(%rsi)
    18f2:      	leaq	0xc(%r12), %rdx
    18f7:      	movq	0x10(%rsp), %rdi
    18fc:      	movq	$0x0, (%rdi)
    1903:      	movq	$0x0, 0x8(%rdi)
    190b:      	movq	$0x0, 0x10(%rdi)
    1913:      	movq	$0x0, 0x18(%rdi)
    191b:      	movl	$0x4, %ecx
    1920:      	movl	$0x4, %eax
    1925:      	leaq	0xac(%rsi), %r14
    192c:      	movl	$0x4, %esi
    1931:      	callq	*%rax
    1933:      	addq	$0x10, %r12
    1937:      	movl	$0x4, %ecx
    193c:      	movl	$0x4, %eax
    1941:      	movq	%r14, %rdi
    1944:      	movl	$0x4, %esi
    1949:      	movq	%r12, %rdx
    194c:      	callq	*%rax
    194e:      	movq	%rbp, 0x80(%rsp)
    1956:      	leaq	0xb6(%rbp), %rdx
    195d:      	leaq	0xd8(%rsp), %rdi
    1965:      	movl	$0x2, %ecx
    196a:      	movl	$0x4, %eax
    196f:      	movl	$0x2, %esi
    1974:      	jmp	0x3049 <generic_fexit_event+0x3049>
    1979:      	movl	$0x120, %edx            # imm = 0x120
    197e:      	addq	0x20(%rsp), %rdx
    1983:      	movq	0x8(%rsp), %rdi
    1988:      	addq	$0xa0, %rdi
    198f:      	movl	$0x11, %ecx
    1994:      	movl	$0x2d, %eax
    1999:      	movl	$0x11, %esi
    199e:      	callq	*%rax
    19a0:      	movq	%rax, %r12
    19a3:      	testq	%rax, %rax
    19a6:      	js	0x13b6 <generic_fexit_event+0x13b6>
    19ac:      	leal	-0x1(%r12), %eax
    19b1:      	movq	0x10(%rsp), %rcx
    19b6:      	movl	%eax, (%rcx)
    19b8:      	addq	$0x3, %r12
    19bc:      	jmp	0x13b6 <generic_fexit_event+0x13b6>
    19c1:      	movq	0x20(%rsp), %r12
    19c6:      	movq	$0x0, 0x10(%rdi)
    19ce:      	movq	$0x0, 0x8(%rdi)
    19d6:      	movq	$0x0, (%rdi)
    19dd:      	movl	$0x2, %ecx
    19e2:      	movl	$0x4, %eax
    19e7:      	movq	%rdi, %r14
    19ea:      	movl	$0x2, %esi
    19ef:      	movq	%r12, %rdx
    19f2:      	callq	*%rax
    19f4:      	testq	%rax, %rax
    19f7:      	movq	0x8(%rsp), %rcx
    19fc:      	js	0x2669 <generic_fexit_event+0x2669>
    1a02:      	movzwl	(%r14), %eax
    1a06:      	cmpl	$0xa, %eax
    1a09:      	je	0x2607 <generic_fexit_event+0x2607>
    1a0f:      	cmpl	$0x2, %eax
    1a12:      	jne	0x2649 <generic_fexit_event+0x2649>
    1a18:      	leaq	0x4(%r12), %rdx
    1a1d:      	leaq	0x30(%rsp), %rdi
    1a22:      	movl	$0x4, %ecx
    1a27:      	movl	$0x4, %eax
    1a2c:      	movl	$0x4, %esi
    1a31:      	callq	*%rax
    1a33:      	movl	0x30(%rsp), %eax
    1a37:      	movq	0x8(%rsp), %rdi
    1a3c:      	movq	%rax, 0xa4(%rdi)
    1a43:      	addq	$0x9e, %rdi
    1a4a:      	addq	$0x2, %r12
    1a4e:      	movl	$0x2, %ecx
    1a53:      	movl	$0x4, %eax
    1a58:      	jmp	0x263f <generic_fexit_event+0x263f>
    1a5d:      	xorl	%eax, %eax
    1a5f:      	movq	%rax, 0x10(%rsp)
    1a64:      	cmpq	$0x3, 0x88(%rsp)
    1a6d:      	jb	0x1df9 <generic_fexit_event+0x1df9>
    1a73:      	movq	%r12, 0x28(%rsp)
    1a78:      	movq	0xa0(%rsp), %rax
    1a80:      	leaq	0x20(%rax), %rdx
    1a84:      	leaq	0x30(%rsp), %rdi
    1a89:      	movl	$0x4, %ebp
    1a8e:      	movl	$0x10, %ecx
    1a93:      	movl	$0x4, %eax
    1a98:      	movl	$0x10, %esi
    1a9d:      	callq	*%rax
    1a9f:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1aa4:      	testl	%eax, %eax
    1aa6:      	js	0x1b36 <generic_fexit_event+0x1b36>
    1aac:      	movq	0x38(%rsp), %r13
    1ab1:      	movq	0x10(%rsp), %rax
    1ab6:      	cmpq	%rax, %r13
    1ab9:      	movq	%rax, %rcx
    1abc:      	cmovbq	%r13, %rcx
    1ac0:      	testq	%rax, %rax
    1ac3:      	movq	%rcx, %r12
    1ac6:      	cmovneq	%rcx, %r13
    1aca:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    1acf:      	cmpq	$0xffe, %r13            # imm = 0xFFE
    1ad6:      	ja	0x1b36 <generic_fexit_event+0x1b36>
    1ad8:      	movq	0x8(%rsp), %rdi
    1add:      	addq	0x18(%rsp), %rdi
    1ae2:      	movq	%rdi, 0x8(%rsp)
    1ae7:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    1aed:      	addq	%r15, %rdi
    1af0:      	movq	0x30(%rsp), %rcx
    1af5:      	movl	$0x4, %eax
    1afa:      	movq	0x30(%rsp), %rdx
    1aff:      	movl	%r13d, %esi
    1b02:      	callq	*%rax
    1b04:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1b09:      	testl	%eax, %eax
    1b0b:      	js	0x1b36 <generic_fexit_event+0x1b36>
    1b0d:      	movq	%r15, 0x18(%rsp)
    1b12:      	movq	%r13, %r15
    1b15:      	addq	%r13, 0x28(%rsp)
    1b1a:      	cmpq	$0x0, 0x10(%rsp)
    1b20:      	je	0x28b4 <generic_fexit_event+0x28b4>
    1b26:      	subq	%r12, 0x10(%rsp)
    1b2b:      	jne	0x28bb <generic_fexit_event+0x28bb>
    1b31:      	jmp	0x28c6 <generic_fexit_event+0x28c6>
    1b36:      	movl	%ecx, (%r15,%r14)
    1b3a:      	addq	%r14, %rbp
    1b3d:      	movq	%rbp, %r13
    1b40:      	movq	0xc0(%rsp), %r12
    1b48:      	movq	0xb0(%rsp), %rbp
    1b50:      	movl	$0x23, %eax
    1b55:      	callq	*%rax
    1b57:      	movq	%rax, %rcx
    1b5a:      	movq	%rax, 0x30(%rsp)
    1b5f:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    1b66:      	leaq	0x90(%rsp), %rdi
    1b6e:      	movl	$0x4, %edx
    1b73:      	movl	$0x71, %eax
    1b78:      	movl	$0xaf4, %edx            # imm = 0xAF4
    1b7d:      	addq	0x30(%rsp), %rdx
    1b82:      	movl	$0x4, %esi
    1b87:      	callq	*%rax
    1b89:      	movl	0x90(%rsp), %eax
    1b90:      	movl	%eax, 0x70(%rsp)
    1b94:      	movq	(%rip), %rdi            # 0x1b9b <generic_fexit_event+0x1b9b>
    1b9b:      	leaq	0x70(%rsp), %rsi
    1ba0:      	movl	$0x1, %eax
    1ba5:      	callq	*%rax
    1ba7:      	testq	%rax, %rax
    1baa:      	je	0x1bba <generic_fexit_event+0x1bba>
    1bac:      	movq	%rax, %r15
    1baf:      	cmpq	$0x0, 0x8(%rax)
    1bb4:      	jne	0x1d90 <generic_fexit_event+0x1d90>
    1bba:      	movl	$0xb00, %edx            # imm = 0xB00
    1bbf:      	movq	0x30(%rsp), %rcx
    1bc4:      	addq	%rdx, %rcx
    1bc7:      	leaq	0x30(%rsp), %rdi
    1bcc:      	movl	$0x8, %esi
    1bd1:      	movl	$0x71, %eax
    1bd6:      	addq	0x30(%rsp), %rdx
    1bdb:      	movl	$0x8, %esi
    1be0:      	callq	*%rax
    1be2:      	movq	0x30(%rsp), %rcx
    1be7:      	testq	%rcx, %rcx
    1bea:      	je	0x1d8d <generic_fexit_event+0x1d8d>
    1bf0:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    1bf7:      	leaq	0x90(%rsp), %rdi
    1bff:      	movl	$0x4, %edx
    1c04:      	movl	$0x71, %eax
    1c09:      	movl	$0xaf4, %edx            # imm = 0xAF4
    1c0e:      	addq	0x30(%rsp), %rdx
    1c13:      	movl	$0x4, %esi
    1c18:      	callq	*%rax
    1c1a:      	movl	0x90(%rsp), %eax
    1c21:      	movl	%eax, 0x70(%rsp)
    1c25:      	movq	(%rip), %rdi            # 0x1c2c <generic_fexit_event+0x1c2c>
    1c2c:      	leaq	0x70(%rsp), %rsi
    1c31:      	movl	$0x1, %eax
    1c36:      	callq	*%rax
    1c38:      	testq	%rax, %rax
    1c3b:      	je	0x1c4b <generic_fexit_event+0x1c4b>
    1c3d:      	movq	%rax, %r15
    1c40:      	cmpq	$0x0, 0x8(%rax)
    1c45:      	jne	0x1d90 <generic_fexit_event+0x1d90>
    1c4b:      	movl	$0xb00, %edx            # imm = 0xB00
    1c50:      	movq	0x30(%rsp), %rcx
    1c55:      	addq	%rdx, %rcx
    1c58:      	leaq	0x30(%rsp), %rdi
    1c5d:      	movl	$0x8, %esi
    1c62:      	movl	$0x71, %eax
    1c67:      	addq	0x30(%rsp), %rdx
    1c6c:      	movl	$0x8, %esi
    1c71:      	callq	*%rax
    1c73:      	movq	0x30(%rsp), %rcx
    1c78:      	testq	%rcx, %rcx
    1c7b:      	je	0x1d8d <generic_fexit_event+0x1d8d>
    1c81:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    1c88:      	leaq	0x90(%rsp), %rdi
    1c90:      	movl	$0x4, %edx
    1c95:      	movl	$0x71, %eax
    1c9a:      	movl	$0xaf4, %edx            # imm = 0xAF4
    1c9f:      	addq	0x30(%rsp), %rdx
    1ca4:      	movl	$0x4, %esi
    1ca9:      	callq	*%rax
    1cab:      	movl	0x90(%rsp), %eax
    1cb2:      	movl	%eax, 0x70(%rsp)
    1cb6:      	movq	(%rip), %rdi            # 0x1cbd <generic_fexit_event+0x1cbd>
    1cbd:      	leaq	0x70(%rsp), %rsi
    1cc2:      	movl	$0x1, %eax
    1cc7:      	callq	*%rax
    1cc9:      	testq	%rax, %rax
    1ccc:      	je	0x1cdc <generic_fexit_event+0x1cdc>
    1cce:      	movq	%rax, %r15
    1cd1:      	cmpq	$0x0, 0x8(%rax)
    1cd6:      	jne	0x1d90 <generic_fexit_event+0x1d90>
    1cdc:      	movl	$0xb00, %edx            # imm = 0xB00
    1ce1:      	movq	0x30(%rsp), %rcx
    1ce6:      	addq	%rdx, %rcx
    1ce9:      	leaq	0x30(%rsp), %rdi
    1cee:      	movl	$0x8, %esi
    1cf3:      	movl	$0x71, %eax
    1cf8:      	addq	0x30(%rsp), %rdx
    1cfd:      	movl	$0x8, %esi
    1d02:      	callq	*%rax
    1d04:      	movq	0x30(%rsp), %rcx
    1d09:      	testq	%rcx, %rcx
    1d0c:      	je	0x1d8d <generic_fexit_event+0x1d8d>
    1d0e:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    1d15:      	leaq	0x90(%rsp), %rdi
    1d1d:      	movl	$0x4, %edx
    1d22:      	movl	$0x71, %eax
    1d27:      	movl	$0xaf4, %edx            # imm = 0xAF4
    1d2c:      	addq	0x30(%rsp), %rdx
    1d31:      	movl	$0x4, %esi
    1d36:      	callq	*%rax
    1d38:      	movl	0x90(%rsp), %eax
    1d3f:      	movl	%eax, 0x70(%rsp)
    1d43:      	movq	(%rip), %rdi            # 0x1d4a <generic_fexit_event+0x1d4a>
    1d4a:      	leaq	0x70(%rsp), %rsi
    1d4f:      	movl	$0x1, %eax
    1d54:      	callq	*%rax
    1d56:      	testq	%rax, %rax
    1d59:      	je	0x1d65 <generic_fexit_event+0x1d65>
    1d5b:      	movq	%rax, %r15
    1d5e:      	cmpq	$0x0, 0x8(%rax)
    1d63:      	jne	0x1d90 <generic_fexit_event+0x1d90>
    1d65:      	movl	$0xb00, %edx            # imm = 0xB00
    1d6a:      	movq	0x30(%rsp), %rcx
    1d6f:      	addq	%rdx, %rcx
    1d72:      	leaq	0x30(%rsp), %rdi
    1d77:      	movl	$0x8, %esi
    1d7c:      	movl	$0x71, %eax
    1d81:      	addq	0x30(%rsp), %rdx
    1d86:      	movl	$0x8, %esi
    1d8b:      	callq	*%rax
    1d8d:      	xorl	%r15d, %r15d
    1d90:      	movl	$0x10d, (%rbx)          # imm = 0x10D
    1d96:      	movl	%r13d, 0x4(%rbx)
    1d9a:      	movl	$0x7d, %eax
    1d9f:      	callq	*%rax
    1da1:      	movq	%rax, 0x8(%rbx)
    1da5:      	testq	%r15, %r15
    1da8:      	je	0x1db8 <generic_fexit_event+0x1db8>
    1daa:      	movl	(%r15), %eax
    1dad:      	movl	%eax, 0x10(%rbx)
    1db0:      	movq	0x8(%r15), %rax
    1db4:      	movq	%rax, 0x18(%rbx)
    1db8:      	movl	$0x0, 0x14(%rbx)
    1dbf:      	movl	(%rbp), %eax
    1dc2:      	movq	%rax, 0x60(%rbx)
    1dc6:      	movl	%r13d, 0x4(%rbx)
    1dca:      	movq	(%rip), %rsi            # 0x1dd1 <generic_fexit_event+0x1dd1>
    1dd1:      	movl	$0x3, %ecx
    1dd6:      	movl	$0xc, %eax
    1ddb:      	movq	%r12, %rdi
    1dde:      	movl	$0x3, %edx
    1de3:      	callq	*%rax
    1de5:      	xorl	%eax, %eax
    1de7:      	addq	$0x108, %rsp            # imm = 0x108
    1dee:      	popq	%rbx
    1def:      	popq	%r12
    1df1:      	popq	%r13
    1df3:      	popq	%r14
    1df5:      	popq	%r15
    1df7:      	popq	%rbp
    1df8:      	retq
    1df9:      	movq	%r12, %r13
    1dfc:      	jmp	0x374 <generic_fexit_event+0x374>
    1e01:      	movq	$0x0, 0x70(%rsp)
    1e0a:      	movq	$0x0, 0x30(%rsp)
    1e13:      	leaq	0x70(%rsp), %rdi
    1e18:      	movq	%rax, %r14
    1e1b:      	leaq	0x30(%rsp), %rdx
    1e20:      	movl	$0x8, %ecx
    1e25:      	movl	$0x4, %eax
    1e2a:      	movl	$0x4, %r12d
    1e30:      	movl	$0x8, %esi
    1e35:      	callq	*%rax
    1e37:      	movq	0x70(%rsp), %rax
    1e3c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    1e42:      	movl	$0xfff, %r13d           # imm = 0xFFF
    1e48:      	movq	%rax, 0x18(%rsp)
    1e4d:      	cmovbq	%rax, %r13
    1e51:      	movq	%r14, 0x80(%rsp)
    1e59:      	addq	$0xa4, %r14
    1e60:      	movl	$0x4, %eax
    1e65:      	movq	%r14, %rdi
    1e68:      	movl	%r13d, %esi
    1e6b:      	movq	%rbp, %rdx
    1e6e:      	callq	*%rax
    1e70:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1e75:      	testl	%eax, %eax
    1e77:      	js	0x1e96 <generic_fexit_event+0x1e96>
    1e79:      	movq	0x80(%rsp), %rax
    1e81:      	movl	%r13d, 0xa0(%rax)
    1e88:      	addq	$0x8, %r13
    1e8c:      	movq	0x18(%rsp), %rax
    1e91:      	movl	%eax, %ecx
    1e93:      	movq	%r13, %r12
    1e96:      	movq	0x80(%rsp), %rax
    1e9e:      	movl	%ecx, 0x9c(%rax)
    1ea4:      	movl	$0x4, %r13d
    1eaa:      	jmp	0x13b6 <generic_fexit_event+0x13b6>
    1eaf:      	leaq	0xc4(%rcx), %r13
    1eb6:      	leaq	0xdc(%rcx), %r12
    1ebd:      	leaq	0x8(%rbp), %rdx
    1ec1:      	movl	$0x4, %ecx
    1ec6:      	movl	$0x4, %eax
    1ecb:      	movl	$0x4, %esi
    1ed0:      	callq	*%rax
    1ed2:      	movq	0x8(%rsp), %rax
    1ed7:      	leaq	0xa0(%rax), %rdi
    1ede:      	leaq	0xc(%rbp), %rdx
    1ee2:      	movl	$0x4, %ecx
    1ee7:      	movl	$0x4, %eax
    1eec:      	movl	$0x4, %esi
    1ef1:      	callq	*%rax
    1ef3:      	movq	0x8(%rsp), %rax
    1ef8:      	leaq	0xac(%rax), %rdi
    1eff:      	leaq	0x18(%rbp), %rdx
    1f03:      	movl	$0x4, %ecx
    1f08:      	movl	$0x4, %eax
    1f0d:      	movl	$0x4, %esi
    1f12:      	callq	*%rax
    1f14:      	movq	0x8(%rsp), %rax
    1f19:      	leaq	0xb0(%rax), %rdi
    1f20:      	leaq	0x1c(%rbp), %rdx
    1f24:      	movl	$0x4, %ecx
    1f29:      	movl	$0x4, %eax
    1f2e:      	movl	$0x4, %esi
    1f33:      	callq	*%rax
    1f35:      	movq	0x8(%rsp), %rax
    1f3a:      	leaq	0xa4(%rax), %rdi
    1f41:      	leaq	0x10(%rbp), %rdx
    1f45:      	movl	$0x4, %ecx
    1f4a:      	movl	$0x4, %eax
    1f4f:      	movl	$0x4, %esi
    1f54:      	callq	*%rax
    1f56:      	movq	0x8(%rsp), %rax
    1f5b:      	leaq	0xa8(%rax), %rdi
    1f62:      	leaq	0x14(%rbp), %rdx
    1f66:      	movl	$0x4, %ecx
    1f6b:      	movl	$0x4, %eax
    1f70:      	movl	$0x4, %esi
    1f75:      	callq	*%rax
    1f77:      	movq	0x8(%rsp), %rax
    1f7c:      	leaq	0xb4(%rax), %rdi
    1f83:      	leaq	0x20(%rbp), %rdx
    1f87:      	movl	$0x4, %ecx
    1f8c:      	movl	$0x4, %eax
    1f91:      	movl	$0x4, %esi
    1f96:      	callq	*%rax
    1f98:      	movq	0x8(%rsp), %rax
    1f9d:      	leaq	0xb8(%rax), %rdi
    1fa4:      	leaq	0x24(%rbp), %rdx
    1fa8:      	movl	$0x4, %ecx
    1fad:      	movl	$0x4, %eax
    1fb2:      	movl	$0x4, %esi
    1fb7:      	callq	*%rax
    1fb9:      	movq	0x8(%rsp), %rax
    1fbe:      	movl	$0x0, 0xc0(%rax)
    1fc8:      	movq	0x8(%rsp), %rax
    1fcd:      	leaq	0xbc(%rax), %rdi
    1fd4:      	leaq	0x28(%rbp), %rdx
    1fd8:      	movl	$0x4, %ecx
    1fdd:      	movl	$0x4, %eax
    1fe2:      	movl	$0x4, %esi
    1fe7:      	callq	*%rax
    1fe9:      	movq	0x8(%rsp), %rax
    1fee:      	leaq	0xcc(%rax), %rdi
    1ff5:      	leaq	0x40(%rbp), %rdx
    1ff9:      	movl	$0x8, %ecx
    1ffe:      	movl	$0x4, %eax
    2003:      	movl	$0x8, %esi
    2008:      	callq	*%rax
    200a:      	movq	0x8(%rsp), %rax
    200f:      	leaq	0xd4(%rax), %rdi
    2016:      	leaq	0x30(%rbp), %rdx
    201a:      	movl	$0x8, %ecx
    201f:      	movl	$0x4, %eax
    2024:      	movl	$0x8, %esi
    2029:      	callq	*%rax
    202b:      	leaq	0x38(%rbp), %rdx
    202f:      	movl	$0x8, %ecx
    2034:      	movl	$0x4, %eax
    2039:      	movq	%r13, %rdi
    203c:      	movl	$0x8, %esi
    2041:      	callq	*%rax
    2043:      	addq	$0x90, %rbp
    204a:      	leaq	0x30(%rsp), %rdi
    204f:      	movl	$0x8, %ecx
    2054:      	movl	$0x4, %eax
    2059:      	movl	$0x8, %esi
    205e:      	movq	%rbp, %rdx
    2061:      	callq	*%rax
    2063:      	movq	0x30(%rsp), %r13
    2068:      	leaq	0xc8(%r13), %rdx
    206f:      	movl	$0x4, %ecx
    2074:      	movl	$0x4, %eax
    2079:      	movq	%r12, %rdi
    207c:      	movl	$0x4, %esi
    2081:      	callq	*%rax
    2083:      	movq	0x8(%rsp), %rax
    2088:      	leaq	0xe0(%rax), %rdi
    208f:      	leaq	0xcc(%r13), %rdx
    2096:      	movl	$0x4, %ecx
    209b:      	movl	$0x4, %eax
    20a0:      	movl	$0x4, %esi
    20a5:      	callq	*%rax
    20a7:      	movq	0x8(%rsp), %rax
    20ac:      	leaq	0xe4(%rax), %rdi
    20b3:      	leaq	0xd0(%r13), %rdx
    20ba:      	movl	$0x4, %ecx
    20bf:      	movl	$0x4, %eax
    20c4:      	movl	$0x4, %esi
    20c9:      	callq	*%rax
    20cb:      	movq	0x8(%rsp), %rdi
    20d0:      	addq	$0xe8, %rdi
    20d7:      	addq	$0x158, %r13            # imm = 0x158
    20de:      	movl	$0x4, %ecx
    20e3:      	movl	$0x4, %eax
    20e8:      	movl	$0x4, %esi
    20ed:      	movq	%r13, %rdx
    20f0:      	movl	$0x4, %r13d
    20f6:      	callq	*%rax
    20f8:      	movq	0x8(%rsp), %rcx
    20fd:      	movl	$0x50, %r12d
    2103:      	jmp	0x13bb <generic_fexit_event+0x13bb>
    2108:      	leaq	0xc8(%rbp), %rdx
    210f:      	movl	$0x4, %ecx
    2114:      	movl	$0x4, %eax
    2119:      	movl	$0x4, %esi
    211e:      	callq	*%rax
    2120:      	movq	0x8(%rsp), %rax
    2125:      	leaq	0xa0(%rax), %rdi
    212c:      	leaq	0xcc(%rbp), %rdx
    2133:      	movl	$0x4, %ecx
    2138:      	movl	$0x4, %eax
    213d:      	movl	$0x4, %esi
    2142:      	callq	*%rax
    2144:      	movq	0x8(%rsp), %rax
    2149:      	leaq	0xa4(%rax), %rdi
    2150:      	leaq	0xd0(%rbp), %rdx
    2157:      	movl	$0x4, %ecx
    215c:      	movl	$0x4, %eax
    2161:      	movl	$0x4, %esi
    2166:      	callq	*%rax
    2168:      	movq	0x8(%rsp), %rdi
    216d:      	addq	$0xa8, %rdi
    2174:      	addq	$0x158, %rbp            # imm = 0x158
    217b:      	movl	$0x4, %ecx
    2180:      	movl	$0x4, %eax
    2185:      	movl	$0x4, %esi
    218a:      	movq	%rbp, %rdx
    218d:      	callq	*%rax
    218f:      	movq	0x8(%rsp), %rcx
    2194:      	movl	$0x10, %r12d
    219a:      	jmp	0x13bb <generic_fexit_event+0x13bb>
    219f:      	leaq	0x38(%rbp), %rdx
    21a3:      	movl	$0x4, %ecx
    21a8:      	movl	$0x4, %eax
    21ad:      	movl	$0x4, %esi
    21b2:      	callq	*%rax
    21b4:      	movq	0x8(%rsp), %rax
    21b9:      	leaq	0xa0(%rax), %rdi
    21c0:      	leaq	0x3c(%rbp), %rdx
    21c4:      	movl	$0x4, %ecx
    21c9:      	movl	$0x4, %eax
    21ce:      	movl	$0x4, %esi
    21d3:      	callq	*%rax
    21d5:      	movq	0x8(%rsp), %rax
    21da:      	leaq	0xa4(%rax), %rdi
    21e1:      	leaq	0x40(%rbp), %rdx
    21e5:      	movl	$0x4, %ecx
    21ea:      	movl	$0x4, %eax
    21ef:      	movl	$0x4, %esi
    21f4:      	callq	*%rax
    21f6:      	movq	0x8(%rsp), %rax
    21fb:      	leaq	0xa8(%rax), %rdi
    2202:      	leaq	0x44(%rbp), %rdx
    2206:      	movl	$0x4, %ecx
    220b:      	movl	$0x4, %eax
    2210:      	movl	$0x4, %esi
    2215:      	callq	*%rax
    2217:      	movq	0x8(%rsp), %rdi
    221c:      	addq	$0xac, %rdi
    2223:      	subq	$-0x80, %rbp
    2227:      	movl	$0x10, %ecx
    222c:      	movl	$0x4, %eax
    2231:      	movl	$0x10, %esi
    2236:      	movq	%rbp, %rdx
    2239:      	callq	*%rax
    223b:      	movq	0x8(%rsp), %rcx
    2240:      	movl	$0x20, %r12d
    2246:      	jmp	0x13bb <generic_fexit_event+0x13bb>
    224b:      	movl	$0x4, %ecx
    2250:      	movl	$0x4, %eax
    2255:      	movl	$0x4, %esi
    225a:      	movq	%rbp, %rdx
    225d:      	callq	*%rax
    225f:      	movq	0x8(%rsp), %rax
    2264:      	leaq	0xa0(%rax), %rdi
    226b:      	leaq	0x4(%rbp), %rdx
    226f:      	movl	$0x4, %ecx
    2274:      	movl	$0x4, %eax
    2279:      	movl	$0x4, %esi
    227e:      	callq	*%rax
    2280:      	movq	0x8(%rsp), %rdi
    2285:      	addq	$0xa4, %rdi
    228c:      	addq	$0x30, %rbp
    2290:      	movl	$0x10, %ecx
    2295:      	movl	$0x4, %eax
    229a:      	movl	$0x10, %esi
    229f:      	movq	%rbp, %rdx
    22a2:      	jmp	0x2343 <generic_fexit_event+0x2343>
    22a7:      	leaq	0x4(%rbp), %rdx
    22ab:      	leaq	0x30(%rsp), %rdi
    22b0:      	movl	$0x4, %ecx
    22b5:      	movl	$0x4, %eax
    22ba:      	movl	$0x4, %esi
    22bf:      	callq	*%rax
    22c1:      	movl	0x30(%rsp), %eax
    22c5:      	movq	0x8(%rsp), %rcx
    22ca:      	movl	%eax, 0x9c(%rcx)
    22d0:      	leaq	0xc(%rbp), %rdx
    22d4:      	leaq	0x30(%rsp), %rdi
    22d9:      	movl	$0x4, %ecx
    22de:      	movl	$0x4, %eax
    22e3:      	movl	$0x4, %esi
    22e8:      	callq	*%rax
    22ea:      	movl	0x30(%rsp), %eax
    22ee:      	movq	0x8(%rsp), %rcx
    22f3:      	movl	%eax, 0xa0(%rcx)
    22f9:      	addq	$0x50, %rbp
    22fd:      	leaq	0x30(%rsp), %rdi
    2302:      	movl	$0x8, %ecx
    2307:      	movl	$0x2d, %eax
    230c:      	movl	$0x8, %esi
    2311:      	movq	%rbp, %rdx
    2314:      	callq	*%rax
    2316:      	movq	0x8(%rsp), %rdi
    231b:      	addq	$0xa4, %rdi
    2322:      	movl	$0x3f8, %edx            # imm = 0x3F8
    2327:      	movq	0x30(%rsp), %rcx
    232c:      	addq	%rdx, %rcx
    232f:      	movl	$0x10, %esi
    2334:      	movl	$0x2d, %eax
    2339:      	addq	0x30(%rsp), %rdx
    233e:      	movl	$0x10, %esi
    2343:      	callq	*%rax
    2345:      	movq	0x8(%rsp), %rcx
    234a:      	movl	$0x18, %r12d
    2350:      	jmp	0x13bb <generic_fexit_event+0x13bb>
    2355:      	movq	$0x0, 0x48(%rdi)
    235d:      	movq	$0x0, 0x40(%rdi)
    2365:      	movq	$0x0, 0x38(%rdi)
    236d:      	movq	$0x0, 0x30(%rdi)
    2375:      	movq	$0x0, 0x28(%rdi)
    237d:      	movq	$0x0, 0x20(%rdi)
    2385:      	movq	$0x0, 0x18(%rdi)
    238d:      	movq	$0x0, 0x10(%rdi)
    2395:      	movq	$0x0, 0x8(%rdi)
    239d:      	movq	%rdi, %r14
    23a0:      	movq	$0x0, (%rdi)
    23a7:      	leaq	0x30(%rsp), %rdi
    23ac:      	movl	$0x8, %ecx
    23b1:      	movl	$0x4, %eax
    23b6:      	movl	$0x8, %esi
    23bb:      	movq	%rbp, %rdx
    23be:      	callq	*%rax
    23c0:      	testq	%rax, %rax
    23c3:      	je	0x2674 <generic_fexit_event+0x2674>
    23c9:      	xorl	%r12d, %r12d
    23cc:      	jmp	0x2863 <generic_fexit_event+0x2863>
    23d1:      	movq	$-0x1, %r12
    23d8:      	movl	$0x4, %r13d
    23de:      	jmp	0x13b6 <generic_fexit_event+0x13b6>
    23e3:      	leaq	0x10(%r13), %rdx
    23e7:      	leaq	0x70(%rsp), %rdi
    23ec:      	movl	$0x8, %ecx
    23f1:      	movl	$0x4, %eax
    23f6:      	movl	$0x8, %esi
    23fb:      	callq	*%rax
    23fd:      	addq	$0x18, %r13
    2401:      	leaq	0x90(%rsp), %rdi
    2409:      	movl	$0x8, %ecx
    240e:      	movl	$0x4, %eax
    2413:      	movl	$0x8, %esi
    2418:      	movq	%r13, %rdx
    241b:      	callq	*%rax
    241d:      	movq	0x70(%rsp), %rdx
    2422:      	movq	0x90(%rsp), %r13
    242a:      	cmpq	$0xfff, %r13            # imm = 0xFFF
    2431:      	movl	$0xfff, %r12d           # imm = 0xFFF
    2437:      	cmovbq	%r13, %r12
    243b:      	movq	%r14, %rdi
    243e:      	addq	$0xa4, %rdi
    2445:      	movl	$0x4, %eax
    244a:      	movl	%r12d, %esi
    244d:      	callq	*%rax
    244f:      	testl	%eax, %eax
    2451:      	js	0x273b <generic_fexit_event+0x273b>
    2457:      	movl	%r13d, 0x9c(%r14)
    245e:      	movl	%r12d, 0xa0(%r14)
    2465:      	addq	$0x8, %r12
    2469:      	jmp	0x2863 <generic_fexit_event+0x2863>
    246e:      	movq	%rbp, 0x80(%rsp)
    2476:      	movq	0x30(%rsp), %r14
    247b:      	movl	$0x0, 0x70(%rsp)
    2483:      	movzwl	0xa8(%rsp), %r13d
    248c:      	movq	(%rip), %rdi            # 0x2493 <generic_fexit_event+0x2493>
    2493:      	leaq	0x70(%rsp), %rsi
    2498:      	movl	$0x1, %eax
    249d:      	leaq	(%r14,%r13), %rbp
    24a1:      	callq	*%rax
    24a3:      	testq	%rax, %rax
    24a6:      	je	0x2fef <generic_fexit_event+0x2fef>
    24ac:      	movq	%rax, %r12
    24af:      	movw	%r13w, (%rax)
    24b3:      	movb	$-0x1, 0x5(%rax)
    24b7:      	movb	$0x0, 0x7(%rax)
    24bb:      	movq	%rax, %rdi
    24be:      	addq	$0x6, %rdi
    24c2:      	leaq	0x6(%rbp), %rdx
    24c6:      	movl	$0x1, %ecx
    24cb:      	movl	$0x4, %eax
    24d0:      	movq	%rdi, %r13
    24d3:      	movl	$0x1, %esi
    24d8:      	callq	*%rax
    24da:      	testq	%rax, %rax
    24dd:      	js	0x2fef <generic_fexit_event+0x2fef>
    24e3:      	movzbl	0x5(%r12), %eax
    24e9:      	cmpl	$0x32, %eax
    24ec:      	jg	0x2878 <generic_fexit_event+0x2878>
    24f2:      	testl	%eax, %eax
    24f4:      	je	0x28a2 <generic_fexit_event+0x28a2>
    24fa:      	cmpl	$0x2b, %eax
    24fd:      	je	0x28a2 <generic_fexit_event+0x28a2>
    2503:      	cmpl	$0x2c, %eax
    2506:      	jne	0x2a5d <generic_fexit_event+0x2a5d>
    250c:      	movw	$0x8, 0x2(%r12)
    2514:      	movw	$0x8, %ax
    2518:      	jmp	0x29a4 <generic_fexit_event+0x29a4>
    251d:      	leaq	0x48(%r12), %rdx
    2522:      	movl	$0x10, %ecx
    2527:      	movl	$0x4, %eax
    252c:      	movl	$0x10, %esi
    2531:      	callq	*%rax
    2533:      	leaq	0x38(%r12), %rdx
    2538:      	movl	$0x10, %ecx
    253d:      	movl	$0x4, %eax
    2542:      	movq	%r13, %rdi
    2545:      	movl	$0x10, %esi
    254a:      	callq	*%rax
    254c:      	movq	0x8(%rsp), %r13
    2551:      	leaq	0xbc(%r13), %rdi
    2558:      	leaq	0xc(%r12), %r14
    255d:      	addq	$0xe, %r12
    2561:      	movl	$0x2, %ecx
    2566:      	movl	$0x4, %eax
    256b:      	movl	$0x2, %esi
    2570:      	movq	%r12, %rdx
    2573:      	callq	*%rax
    2575:      	movq	%r13, %rdi
    2578:      	addq	$0xbe, %rdi
    257f:      	movl	$0x2, %ecx
    2584:      	movl	$0x4, %eax
    2589:      	movl	$0x2, %esi
    258e:      	movq	%r14, %rdx
    2591:      	callq	*%rax
    2593:      	movzwl	0xbe(%r13), %eax
    259b:      	movbew	%ax, 0xbe(%r13)
    25a5:      	movq	0x20(%rsp), %rax
    25aa:      	movq	%rax, 0x30(%rsp)
    25af:      	movq	(%rip), %rdi            # 0x25b6 <generic_fexit_event+0x25b6>
    25b6:      	leaq	0x30(%rsp), %rsi
    25bb:      	movl	$0x1, %eax
    25c0:      	callq	*%rax
    25c2:      	testq	%rax, %rax
    25c5:      	je	0x25da <generic_fexit_event+0x25da>
    25c7:      	movl	(%rax), %ecx
    25c9:      	movl	%ecx, 0x10(%rbp)
    25cc:      	movq	0x8(%rax), %rcx
    25d0:      	movq	%rcx, 0x18(%rbp)
    25d4:      	movl	0x4(%rax), %eax
    25d7:      	movl	%eax, 0x7c(%rbp)
    25da:      	movl	$0x40, %r12d
    25e0:      	movl	$0x4, %r13d
    25e6:      	jmp	0x13b6 <generic_fexit_event+0x13b6>
    25eb:      	movq	$0x0, 0x9c(%r14)
    25f6:      	movl	$0x8, %r12d
    25fc:      	movl	$0x4, %r13d
    2602:      	jmp	0x13b6 <generic_fexit_event+0x13b6>
    2607:      	leaq	0xa4(%rcx), %rdi
    260e:      	leaq	0x8(%r12), %rdx
    2613:      	movq	%rcx, %r14
    2616:      	movl	$0x10, %ecx
    261b:      	movl	$0x4, %eax
    2620:      	movl	$0x10, %esi
    2625:      	callq	*%rax
    2627:      	movq	%r14, %rdi
    262a:      	addq	$0x9e, %rdi
    2631:      	addq	$0x2, %r12
    2635:      	movl	$0x2, %ecx
    263a:      	movl	$0x4, %eax
    263f:      	movl	$0x2, %esi
    2644:      	movq	%r12, %rdx
    2647:      	callq	*%rax
    2649:      	movq	0x8(%rsp), %rcx
    264e:      	movzwl	0x9e(%rcx), %eax
    2655:      	movbew	%ax, 0x9e(%rcx)
    265e:      	movl	$0x4, %r13d
    2664:      	movq	0x18(%rsp), %r15
    2669:      	movl	$0x18, %r12d
    266f:      	jmp	0x13bb <generic_fexit_event+0x13bb>
    2674:      	movq	0x8(%rsp), %rax
    2679:      	leaq	0xac(%rax), %rdi
    2680:      	movq	0x30(%rsp), %rcx
    2685:      	movl	$0x3f, %edx
    268a:      	movl	$0x2d, %eax
    268f:      	movq	0x30(%rsp), %rdx
    2694:      	movl	$0x3f, %esi
    2699:      	callq	*%rax
    269b:      	testq	%rax, %rax
    269e:      	js	0x23c9 <generic_fexit_event+0x23c9>
    26a4:      	leaq	0x8(%rbp), %rdx
    26a8:      	leaq	0x70(%rsp), %rdi
    26ad:      	movl	$0x8, %ecx
    26b2:      	movl	$0x4, %eax
    26b7:      	movl	$0x8, %esi
    26bc:      	callq	*%rax
    26be:      	movq	0x8(%rsp), %rdi
    26c3:      	addq	$0xa4, %rdi
    26ca:      	movl	$0x348, %edx            # imm = 0x348
    26cf:      	movq	0x70(%rsp), %rcx
    26d4:      	addq	%rdx, %rcx
    26d7:      	movl	$0x8, %esi
    26dc:      	movl	$0x4, %eax
    26e1:      	addq	0x70(%rsp), %rdx
    26e6:      	movl	$0x8, %esi
    26eb:      	callq	*%rax
    26ed:      	addq	$0x58, %rbp
    26f1:      	leaq	0x70(%rsp), %rdi
    26f6:      	movl	$0x4, %ecx
    26fb:      	movl	$0x4, %eax
    2700:      	movl	$0x4, %esi
    2705:      	movq	%rbp, %rdx
    2708:      	callq	*%rax
    270a:      	movl	$0x50, %r12d
    2710:      	testq	%rax, %rax
    2713:      	jne	0x2863 <generic_fexit_event+0x2863>
    2719:      	xorl	%eax, %eax
    271b:      	cmpl	$0x0, 0x70(%rsp)
    2720:      	setne	%al
    2723:      	movl	%eax, (%r14)
    2726:      	jmp	0x2863 <generic_fexit_event+0x2863>
    272b:      	movl	$0xfffffffe, 0x9c(%r14) # imm = 0xFFFFFFFE
    2736:      	jmp	0x2863 <generic_fexit_event+0x2863>
    273b:      	movl	$0xfffffffe, 0x9c(%r14) # imm = 0xFFFFFFFE
    2746:      	movl	$0x4, %r12d
    274c:      	jmp	0x2863 <generic_fexit_event+0x2863>
    2751:      	addq	$0x3, %r12
    2755:      	movl	$0x6b, %ecx
    275a:      	movl	$0x71, %eax
    275f:      	movl	$0x6b, %esi
    2764:      	movq	%r12, %rdx
    2767:      	callq	*%rax
    2769:      	movq	%rax, %rcx
    276c:      	movb	$0x6b, %al
    276e:      	testl	%ecx, %ecx
    2770:      	js	0x277d <generic_fexit_event+0x277d>
    2772:      	movq	0x8(%rsp), %rcx
    2777:      	movb	%al, 0x9f(%rcx)
    277d:      	movl	$0x70, %r12d
    2783:      	movl	$0x4, %r13d
    2789:      	jmp	0x13b6 <generic_fexit_event+0x13b6>
    278e:      	leaq	0x48(%r12), %rdx
    2793:      	movl	$0x10, %ecx
    2798:      	movl	$0x4, %eax
    279d:      	movq	%r14, %rdi
    27a0:      	movl	$0x10, %esi
    27a5:      	callq	*%rax
    27a7:      	leaq	0x38(%r12), %rdx
    27ac:      	movl	$0x10, %ecx
    27b1:      	movl	$0x4, %eax
    27b6:      	movq	%r13, %rdi
    27b9:      	movl	$0x10, %esi
    27be:      	callq	*%rax
    27c0:      	movq	0x8(%rsp), %r13
    27c5:      	leaq	0xbc(%r13), %rdi
    27cc:      	leaq	0xc(%r12), %r14
    27d1:      	addq	$0xe, %r12
    27d5:      	movl	$0x2, %ecx
    27da:      	movl	$0x4, %eax
    27df:      	movl	$0x2, %esi
    27e4:      	movq	%r12, %rdx
    27e7:      	callq	*%rax
    27e9:      	movq	%r13, %rdi
    27ec:      	addq	$0xbe, %rdi
    27f3:      	movl	$0x2, %ecx
    27f8:      	movl	$0x4, %eax
    27fd:      	movl	$0x2, %esi
    2802:      	movq	%r14, %rdx
    2805:      	callq	*%rax
    2807:      	movzwl	0xbe(%r13), %eax
    280f:      	movbew	%ax, 0xbe(%r13)
    2819:      	movq	0x8(%rsp), %rax
    281e:      	movq	0xc4(%rax), %rax
    2825:      	movq	%rax, 0x30(%rsp)
    282a:      	movq	(%rip), %rdi            # 0x2831 <generic_fexit_event+0x2831>
    2831:      	leaq	0x30(%rsp), %rsi
    2836:      	movl	$0x1, %eax
    283b:      	callq	*%rax
    283d:      	testq	%rax, %rax
    2840:      	je	0x285d <generic_fexit_event+0x285d>
    2842:      	movl	(%rax), %ecx
    2844:      	movq	0x80(%rsp), %rdx
    284c:      	movl	%ecx, 0x10(%rdx)
    284f:      	movq	0x8(%rax), %rcx
    2853:      	movq	%rcx, 0x18(%rdx)
    2857:      	movl	0x4(%rax), %eax
    285a:      	movl	%eax, 0x7c(%rdx)
    285d:      	movl	$0x40, %r12d
    2863:      	movl	$0x4, %r13d
    2869:      	movq	0x8(%rsp), %rcx
    286e:      	movq	0x18(%rsp), %r15
    2873:      	jmp	0x13bb <generic_fexit_event+0x13bb>
    2878:      	cmpl	$0x33, %eax
    287b:      	je	0x2991 <generic_fexit_event+0x2991>
    2881:      	cmpl	$0x3c, %eax
    2884:      	je	0x28a2 <generic_fexit_event+0x28a2>
    2886:      	cmpl	$0xff, %eax
    288b:      	jne	0x2a5d <generic_fexit_event+0x2a5d>
    2891:      	movw	$0x28, 0x2(%r12)
    2899:      	movw	$0x28, %ax
    289d:      	jmp	0x29a4 <generic_fexit_event+0x29a4>
    28a2:      	movzbl	0x7(%r12), %eax
    28a8:      	leal	0x8(,%rax,8), %eax
    28af:      	jmp	0x299e <generic_fexit_event+0x299e>
    28b4:      	xorl	%eax, %eax
    28b6:      	movq	%rax, 0x10(%rsp)
    28bb:      	cmpq	$0x3, 0x88(%rsp)
    28c4:      	jne	0x28d5 <generic_fexit_event+0x28d5>
    28c6:      	movq	0x28(%rsp), %r13
    28cb:      	movq	0x18(%rsp), %r15
    28d0:      	jmp	0x374 <generic_fexit_event+0x374>
    28d5:      	movq	0xa0(%rsp), %rax
    28dd:      	leaq	0x30(%rax), %rdx
    28e1:      	leaq	0x30(%rsp), %rdi
    28e6:      	movl	$0x4, %ebp
    28eb:      	movl	$0x10, %ecx
    28f0:      	movl	$0x4, %eax
    28f5:      	movl	$0x10, %esi
    28fa:      	callq	*%rax
    28fc:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2901:      	testl	%eax, %eax
    2903:      	js	0x338a <generic_fexit_event+0x338a>
    2909:      	movq	0x38(%rsp), %rdx
    290e:      	movq	0x10(%rsp), %rax
    2913:      	cmpq	%rax, %rdx
    2916:      	movq	%rax, %r12
    2919:      	cmovbq	%rdx, %r12
    291d:      	testq	%rax, %rax
    2920:      	cmovneq	%r12, %rdx
    2924:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2929:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    2930:      	ja	0x338a <generic_fexit_event+0x338a>
    2936:      	movq	%rdx, %r13
    2939:      	movq	%r15, %rdi
    293c:      	addq	0x8(%rsp), %rdi
    2941:      	movq	%rdi, %r15
    2944:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    294a:      	addq	0x18(%rsp), %rdi
    294f:      	movq	0x30(%rsp), %rcx
    2954:      	movl	$0x4, %eax
    2959:      	movq	%rdx, %rsi
    295c:      	movq	0x30(%rsp), %rdx
    2961:      	callq	*%rax
    2963:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2968:      	testl	%eax, %eax
    296a:      	js	0x338a <generic_fexit_event+0x338a>
    2970:      	addq	%r13, 0x28(%rsp)
    2975:      	cmpq	$0x0, 0x10(%rsp)
    297b:      	je	0x2cf9 <generic_fexit_event+0x2cf9>
    2981:      	subq	%r12, 0x10(%rsp)
    2986:      	jne	0x2d00 <generic_fexit_event+0x2d00>
    298c:      	jmp	0x28c6 <generic_fexit_event+0x28c6>
    2991:      	movzbl	0x7(%r12), %eax
    2997:      	leal	0x8(,%rax,4), %eax
    299e:      	movw	%ax, 0x2(%r12)
    29a4:      	addw	(%r12), %ax
    29a9:      	movw	%ax, (%r12)
    29ae:      	movzbl	0x6(%r12), %ecx
    29b4:      	cmpq	$0x3c, %rcx
    29b8:      	ja	0x31ec <generic_fexit_event+0x31ec>
    29be:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    29c8:      	btq	%rcx, %rdx
    29cc:      	jae	0x31ec <generic_fexit_event+0x31ec>
    29d2:      	movb	%cl, 0x5(%r12)
    29d7:      	movzwl	%ax, %ecx
    29da:      	addq	%r14, %rcx
    29dd:      	movl	$0x2, %edx
    29e2:      	movl	$0x4, %eax
    29e7:      	movq	%r13, %rdi
    29ea:      	movzwl	(%r12), %edx
    29ef:      	addq	%r14, %rdx
    29f2:      	movl	$0x2, %esi
    29f7:      	callq	*%rax
    29f9:      	testq	%rax, %rax
    29fc:      	js	0x2fef <generic_fexit_event+0x2fef>
    2a02:      	movzbl	0x5(%r12), %eax
    2a08:      	cmpl	$0x32, %eax
    2a0b:      	jg	0x2a29 <generic_fexit_event+0x2a29>
    2a0d:      	testl	%eax, %eax
    2a0f:      	je	0x2a48 <generic_fexit_event+0x2a48>
    2a11:      	cmpl	$0x2b, %eax
    2a14:      	je	0x2a48 <generic_fexit_event+0x2a48>
    2a16:      	cmpl	$0x2c, %eax
    2a19:      	jne	0x2a7d <generic_fexit_event+0x2a7d>
    2a1b:      	movw	$0x8, 0x2(%r12)
    2a23:      	movw	$0x8, %ax
    2a27:      	jmp	0x2a83 <generic_fexit_event+0x2a83>
    2a29:      	cmpl	$0x33, %eax
    2a2c:      	je	0x2a68 <generic_fexit_event+0x2a68>
    2a2e:      	cmpl	$0x3c, %eax
    2a31:      	je	0x2a48 <generic_fexit_event+0x2a48>
    2a33:      	cmpl	$0xff, %eax
    2a38:      	jne	0x2a7d <generic_fexit_event+0x2a7d>
    2a3a:      	movw	$0x28, 0x2(%r12)
    2a42:      	movw	$0x28, %ax
    2a46:      	jmp	0x2a83 <generic_fexit_event+0x2a83>
    2a48:      	movzbl	0x7(%r12), %eax
    2a4e:      	leal	0x8(,%rax,8), %eax
    2a55:      	movw	%ax, 0x2(%r12)
    2a5b:      	jmp	0x2a83 <generic_fexit_event+0x2a83>
    2a5d:      	movzwl	0x2(%r12), %eax
    2a63:      	jmp	0x29a4 <generic_fexit_event+0x29a4>
    2a68:      	movzbl	0x7(%r12), %eax
    2a6e:      	leal	0x8(,%rax,4), %eax
    2a75:      	movw	%ax, 0x2(%r12)
    2a7b:      	jmp	0x2a83 <generic_fexit_event+0x2a83>
    2a7d:      	movzwl	0x2(%r12), %eax
    2a83:      	addw	(%r12), %ax
    2a88:      	movw	%ax, (%r12)
    2a8d:      	movzbl	0x6(%r12), %ecx
    2a93:      	cmpq	$0x3c, %rcx
    2a97:      	ja	0x31ec <generic_fexit_event+0x31ec>
    2a9d:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2aa7:      	btq	%rcx, %rdx
    2aab:      	jae	0x31ec <generic_fexit_event+0x31ec>
    2ab1:      	movb	%cl, 0x5(%r12)
    2ab6:      	movzwl	%ax, %ecx
    2ab9:      	addq	%r14, %rcx
    2abc:      	movl	$0x2, %edx
    2ac1:      	movl	$0x4, %eax
    2ac6:      	movq	%r13, %rdi
    2ac9:      	movzwl	(%r12), %edx
    2ace:      	addq	%r14, %rdx
    2ad1:      	movl	$0x2, %esi
    2ad6:      	callq	*%rax
    2ad8:      	testq	%rax, %rax
    2adb:      	js	0x2fef <generic_fexit_event+0x2fef>
    2ae1:      	movzbl	0x5(%r12), %eax
    2ae7:      	cmpl	$0x32, %eax
    2aea:      	jg	0x2b08 <generic_fexit_event+0x2b08>
    2aec:      	testl	%eax, %eax
    2aee:      	je	0x2b27 <generic_fexit_event+0x2b27>
    2af0:      	cmpl	$0x2b, %eax
    2af3:      	je	0x2b27 <generic_fexit_event+0x2b27>
    2af5:      	cmpl	$0x2c, %eax
    2af8:      	jne	0x2b51 <generic_fexit_event+0x2b51>
    2afa:      	movw	$0x8, 0x2(%r12)
    2b02:      	movw	$0x8, %ax
    2b06:      	jmp	0x2b57 <generic_fexit_event+0x2b57>
    2b08:      	cmpl	$0x33, %eax
    2b0b:      	je	0x2b3c <generic_fexit_event+0x2b3c>
    2b0d:      	cmpl	$0x3c, %eax
    2b10:      	je	0x2b27 <generic_fexit_event+0x2b27>
    2b12:      	cmpl	$0xff, %eax
    2b17:      	jne	0x2b51 <generic_fexit_event+0x2b51>
    2b19:      	movw	$0x28, 0x2(%r12)
    2b21:      	movw	$0x28, %ax
    2b25:      	jmp	0x2b57 <generic_fexit_event+0x2b57>
    2b27:      	movzbl	0x7(%r12), %eax
    2b2d:      	leal	0x8(,%rax,8), %eax
    2b34:      	movw	%ax, 0x2(%r12)
    2b3a:      	jmp	0x2b57 <generic_fexit_event+0x2b57>
    2b3c:      	movzbl	0x7(%r12), %eax
    2b42:      	leal	0x8(,%rax,4), %eax
    2b49:      	movw	%ax, 0x2(%r12)
    2b4f:      	jmp	0x2b57 <generic_fexit_event+0x2b57>
    2b51:      	movzwl	0x2(%r12), %eax
    2b57:      	addw	(%r12), %ax
    2b5c:      	movw	%ax, (%r12)
    2b61:      	movzbl	0x6(%r12), %ecx
    2b67:      	cmpq	$0x3c, %rcx
    2b6b:      	ja	0x31ec <generic_fexit_event+0x31ec>
    2b71:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2b7b:      	btq	%rcx, %rdx
    2b7f:      	jae	0x31ec <generic_fexit_event+0x31ec>
    2b85:      	movb	%cl, 0x5(%r12)
    2b8a:      	movzwl	%ax, %ecx
    2b8d:      	addq	%r14, %rcx
    2b90:      	movl	$0x2, %edx
    2b95:      	movl	$0x4, %eax
    2b9a:      	movq	%r13, %rdi
    2b9d:      	movzwl	(%r12), %edx
    2ba2:      	addq	%r14, %rdx
    2ba5:      	movl	$0x2, %esi
    2baa:      	callq	*%rax
    2bac:      	testq	%rax, %rax
    2baf:      	js	0x2fef <generic_fexit_event+0x2fef>
    2bb5:      	movzbl	0x5(%r12), %eax
    2bbb:      	cmpl	$0x32, %eax
    2bbe:      	jg	0x2bdc <generic_fexit_event+0x2bdc>
    2bc0:      	testl	%eax, %eax
    2bc2:      	je	0x2bfb <generic_fexit_event+0x2bfb>
    2bc4:      	cmpl	$0x2b, %eax
    2bc7:      	je	0x2bfb <generic_fexit_event+0x2bfb>
    2bc9:      	cmpl	$0x2c, %eax
    2bcc:      	jne	0x2c25 <generic_fexit_event+0x2c25>
    2bce:      	movw	$0x8, 0x2(%r12)
    2bd6:      	movw	$0x8, %ax
    2bda:      	jmp	0x2c2b <generic_fexit_event+0x2c2b>
    2bdc:      	cmpl	$0x33, %eax
    2bdf:      	je	0x2c10 <generic_fexit_event+0x2c10>
    2be1:      	cmpl	$0x3c, %eax
    2be4:      	je	0x2bfb <generic_fexit_event+0x2bfb>
    2be6:      	cmpl	$0xff, %eax
    2beb:      	jne	0x2c25 <generic_fexit_event+0x2c25>
    2bed:      	movw	$0x28, 0x2(%r12)
    2bf5:      	movw	$0x28, %ax
    2bf9:      	jmp	0x2c2b <generic_fexit_event+0x2c2b>
    2bfb:      	movzbl	0x7(%r12), %eax
    2c01:      	leal	0x8(,%rax,8), %eax
    2c08:      	movw	%ax, 0x2(%r12)
    2c0e:      	jmp	0x2c2b <generic_fexit_event+0x2c2b>
    2c10:      	movzbl	0x7(%r12), %eax
    2c16:      	leal	0x8(,%rax,4), %eax
    2c1d:      	movw	%ax, 0x2(%r12)
    2c23:      	jmp	0x2c2b <generic_fexit_event+0x2c2b>
    2c25:      	movzwl	0x2(%r12), %eax
    2c2b:      	addw	(%r12), %ax
    2c30:      	movw	%ax, (%r12)
    2c35:      	movzbl	0x6(%r12), %ecx
    2c3b:      	cmpq	$0x3c, %rcx
    2c3f:      	ja	0x31ec <generic_fexit_event+0x31ec>
    2c45:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2c4f:      	btq	%rcx, %rdx
    2c53:      	jae	0x31ec <generic_fexit_event+0x31ec>
    2c59:      	movb	%cl, 0x5(%r12)
    2c5e:      	movzwl	%ax, %ecx
    2c61:      	addq	%r14, %rcx
    2c64:      	movl	$0x2, %edx
    2c69:      	movl	$0x4, %eax
    2c6e:      	movq	%r13, %rdi
    2c71:      	movzwl	(%r12), %edx
    2c76:      	addq	%r14, %rdx
    2c79:      	movl	$0x2, %esi
    2c7e:      	callq	*%rax
    2c80:      	testq	%rax, %rax
    2c83:      	js	0x2fef <generic_fexit_event+0x2fef>
    2c89:      	movzbl	0x5(%r12), %eax
    2c8f:      	cmpl	$0x32, %eax
    2c92:      	jg	0x2cb7 <generic_fexit_event+0x2cb7>
    2c94:      	testl	%eax, %eax
    2c96:      	je	0x2ce1 <generic_fexit_event+0x2ce1>
    2c98:      	cmpl	$0x2b, %eax
    2c9b:      	je	0x2ce1 <generic_fexit_event+0x2ce1>
    2c9d:      	cmpl	$0x2c, %eax
    2ca0:      	jne	0x2dec <generic_fexit_event+0x2dec>
    2ca6:      	movw	$0x8, 0x2(%r12)
    2cae:      	movw	$0x8, %ax
    2cb2:      	jmp	0x2df2 <generic_fexit_event+0x2df2>
    2cb7:      	cmpl	$0x33, %eax
    2cba:      	je	0x2dd7 <generic_fexit_event+0x2dd7>
    2cc0:      	cmpl	$0x3c, %eax
    2cc3:      	je	0x2ce1 <generic_fexit_event+0x2ce1>
    2cc5:      	cmpl	$0xff, %eax
    2cca:      	jne	0x2dec <generic_fexit_event+0x2dec>
    2cd0:      	movw	$0x28, 0x2(%r12)
    2cd8:      	movw	$0x28, %ax
    2cdc:      	jmp	0x2df2 <generic_fexit_event+0x2df2>
    2ce1:      	movzbl	0x7(%r12), %eax
    2ce7:      	leal	0x8(,%rax,8), %eax
    2cee:      	movw	%ax, 0x2(%r12)
    2cf4:      	jmp	0x2df2 <generic_fexit_event+0x2df2>
    2cf9:      	xorl	%eax, %eax
    2cfb:      	movq	%rax, 0x10(%rsp)
    2d00:      	cmpq	$0x5, 0x88(%rsp)
    2d09:      	jb	0x28c6 <generic_fexit_event+0x28c6>
    2d0f:      	movq	0xa0(%rsp), %rax
    2d17:      	leaq	0x40(%rax), %rdx
    2d1b:      	leaq	0x30(%rsp), %rdi
    2d20:      	movl	$0x4, %ebp
    2d25:      	movl	$0x10, %ecx
    2d2a:      	movl	$0x4, %eax
    2d2f:      	movl	$0x10, %esi
    2d34:      	callq	*%rax
    2d36:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2d3b:      	testl	%eax, %eax
    2d3d:      	js	0x338a <generic_fexit_event+0x338a>
    2d43:      	movq	0x38(%rsp), %rdx
    2d48:      	movq	0x10(%rsp), %rax
    2d4d:      	cmpq	%rax, %rdx
    2d50:      	movq	%rax, %r12
    2d53:      	cmovbq	%rdx, %r12
    2d57:      	testq	%rax, %rax
    2d5a:      	cmovneq	%r12, %rdx
    2d5e:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2d63:      	movq	%rdx, 0x8(%rsp)
    2d68:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    2d6f:      	ja	0x338a <generic_fexit_event+0x338a>
    2d75:      	addq	%r15, %r13
    2d78:      	movq	%r13, %r15
    2d7b:      	movl	%r13d, %edi
    2d7e:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2d84:      	addq	0x18(%rsp), %rdi
    2d89:      	movq	0x30(%rsp), %rcx
    2d8e:      	movl	$0x4, %eax
    2d93:      	movq	0x8(%rsp), %rsi
    2d98:      	movq	0x30(%rsp), %rdx
    2d9d:      	callq	*%rax
    2d9f:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2da4:      	testl	%eax, %eax
    2da6:      	js	0x338a <generic_fexit_event+0x338a>
    2dac:      	movq	0x28(%rsp), %rax
    2db1:      	addq	0x8(%rsp), %rax
    2db6:      	movq	%rax, 0x28(%rsp)
    2dbb:      	cmpq	$0x0, 0x10(%rsp)
    2dc1:      	je	0x31f9 <generic_fexit_event+0x31f9>
    2dc7:      	subq	%r12, 0x10(%rsp)
    2dcc:      	jne	0x3200 <generic_fexit_event+0x3200>
    2dd2:      	jmp	0x28c6 <generic_fexit_event+0x28c6>
    2dd7:      	movzbl	0x7(%r12), %eax
    2ddd:      	leal	0x8(,%rax,4), %eax
    2de4:      	movw	%ax, 0x2(%r12)
    2dea:      	jmp	0x2df2 <generic_fexit_event+0x2df2>
    2dec:      	movzwl	0x2(%r12), %eax
    2df2:      	addw	(%r12), %ax
    2df7:      	movw	%ax, (%r12)
    2dfc:      	movzbl	0x6(%r12), %ecx
    2e02:      	cmpq	$0x3c, %rcx
    2e06:      	ja	0x31ec <generic_fexit_event+0x31ec>
    2e0c:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2e16:      	btq	%rcx, %rdx
    2e1a:      	jae	0x31ec <generic_fexit_event+0x31ec>
    2e20:      	movb	%cl, 0x5(%r12)
    2e25:      	movzwl	%ax, %ecx
    2e28:      	addq	%r14, %rcx
    2e2b:      	movl	$0x2, %edx
    2e30:      	movl	$0x4, %eax
    2e35:      	movq	%r13, %rdi
    2e38:      	movzwl	(%r12), %edx
    2e3d:      	addq	%r14, %rdx
    2e40:      	movl	$0x2, %esi
    2e45:      	callq	*%rax
    2e47:      	testq	%rax, %rax
    2e4a:      	js	0x2fef <generic_fexit_event+0x2fef>
    2e50:      	movzbl	0x5(%r12), %eax
    2e56:      	cmpl	$0x32, %eax
    2e59:      	jg	0x2e77 <generic_fexit_event+0x2e77>
    2e5b:      	testl	%eax, %eax
    2e5d:      	je	0x2e96 <generic_fexit_event+0x2e96>
    2e5f:      	cmpl	$0x2b, %eax
    2e62:      	je	0x2e96 <generic_fexit_event+0x2e96>
    2e64:      	cmpl	$0x2c, %eax
    2e67:      	jne	0x2ec0 <generic_fexit_event+0x2ec0>
    2e69:      	movw	$0x8, 0x2(%r12)
    2e71:      	movw	$0x8, %ax
    2e75:      	jmp	0x2ec6 <generic_fexit_event+0x2ec6>
    2e77:      	cmpl	$0x33, %eax
    2e7a:      	je	0x2eab <generic_fexit_event+0x2eab>
    2e7c:      	cmpl	$0x3c, %eax
    2e7f:      	je	0x2e96 <generic_fexit_event+0x2e96>
    2e81:      	cmpl	$0xff, %eax
    2e86:      	jne	0x2ec0 <generic_fexit_event+0x2ec0>
    2e88:      	movw	$0x28, 0x2(%r12)
    2e90:      	movw	$0x28, %ax
    2e94:      	jmp	0x2ec6 <generic_fexit_event+0x2ec6>
    2e96:      	movzbl	0x7(%r12), %eax
    2e9c:      	leal	0x8(,%rax,8), %eax
    2ea3:      	movw	%ax, 0x2(%r12)
    2ea9:      	jmp	0x2ec6 <generic_fexit_event+0x2ec6>
    2eab:      	movzbl	0x7(%r12), %eax
    2eb1:      	leal	0x8(,%rax,4), %eax
    2eb8:      	movw	%ax, 0x2(%r12)
    2ebe:      	jmp	0x2ec6 <generic_fexit_event+0x2ec6>
    2ec0:      	movzwl	0x2(%r12), %eax
    2ec6:      	addw	(%r12), %ax
    2ecb:      	movw	%ax, (%r12)
    2ed0:      	movzbl	0x6(%r12), %ecx
    2ed6:      	cmpq	$0x3c, %rcx
    2eda:      	ja	0x31ec <generic_fexit_event+0x31ec>
    2ee0:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2eea:      	btq	%rcx, %rdx
    2eee:      	jae	0x31ec <generic_fexit_event+0x31ec>
    2ef4:      	movb	%cl, 0x5(%r12)
    2ef9:      	movzwl	%ax, %ecx
    2efc:      	addq	%r14, %rcx
    2eff:      	movl	$0x2, %edx
    2f04:      	movl	$0x4, %eax
    2f09:      	movq	%r13, %rdi
    2f0c:      	movzwl	(%r12), %edx
    2f11:      	addq	%r14, %rdx
    2f14:      	movl	$0x2, %esi
    2f19:      	callq	*%rax
    2f1b:      	testq	%rax, %rax
    2f1e:      	js	0x2fef <generic_fexit_event+0x2fef>
    2f24:      	movzbl	0x5(%r12), %eax
    2f2a:      	cmpl	$0x32, %eax
    2f2d:      	jg	0x2f4b <generic_fexit_event+0x2f4b>
    2f2f:      	testl	%eax, %eax
    2f31:      	je	0x2f6a <generic_fexit_event+0x2f6a>
    2f33:      	cmpl	$0x2b, %eax
    2f36:      	je	0x2f6a <generic_fexit_event+0x2f6a>
    2f38:      	cmpl	$0x2c, %eax
    2f3b:      	jne	0x2f94 <generic_fexit_event+0x2f94>
    2f3d:      	movw	$0x8, 0x2(%r12)
    2f45:      	movw	$0x8, %ax
    2f49:      	jmp	0x2f9a <generic_fexit_event+0x2f9a>
    2f4b:      	cmpl	$0x33, %eax
    2f4e:      	je	0x2f7f <generic_fexit_event+0x2f7f>
    2f50:      	cmpl	$0x3c, %eax
    2f53:      	je	0x2f6a <generic_fexit_event+0x2f6a>
    2f55:      	cmpl	$0xff, %eax
    2f5a:      	jne	0x2f94 <generic_fexit_event+0x2f94>
    2f5c:      	movw	$0x28, 0x2(%r12)
    2f64:      	movw	$0x28, %ax
    2f68:      	jmp	0x2f9a <generic_fexit_event+0x2f9a>
    2f6a:      	movzbl	0x7(%r12), %eax
    2f70:      	leal	0x8(,%rax,8), %eax
    2f77:      	movw	%ax, 0x2(%r12)
    2f7d:      	jmp	0x2f9a <generic_fexit_event+0x2f9a>
    2f7f:      	movzbl	0x7(%r12), %eax
    2f85:      	leal	0x8(,%rax,4), %eax
    2f8c:      	movw	%ax, 0x2(%r12)
    2f92:      	jmp	0x2f9a <generic_fexit_event+0x2f9a>
    2f94:      	movzwl	0x2(%r12), %eax
    2f9a:      	addw	(%r12), %ax
    2f9f:      	movw	%ax, (%r12)
    2fa4:      	movzbl	0x6(%r12), %ecx
    2faa:      	cmpq	$0x3c, %rcx
    2fae:      	ja	0x31ec <generic_fexit_event+0x31ec>
    2fb4:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2fbe:      	btq	%rcx, %rdx
    2fc2:      	jae	0x31ec <generic_fexit_event+0x31ec>
    2fc8:      	movb	%cl, 0x5(%r12)
    2fcd:      	movzwl	%ax, %ecx
    2fd0:      	addq	%r14, %rcx
    2fd3:      	movl	$0x2, %edx
    2fd8:      	movl	$0x4, %eax
    2fdd:      	movzwl	(%r12), %edx
    2fe2:      	addq	%r14, %rdx
    2fe5:      	movq	%r13, %rdi
    2fe8:      	movl	$0x2, %esi
    2fed:      	callq	*%rax
    2fef:      	xorl	%ecx, %ecx
    2ff1:      	movb	%cl, 0xd0(%rsp)
    2ff8:      	movzbl	%cl, %eax
    2ffb:      	movq	0x8(%rsp), %r14
    3000:      	movw	%ax, 0xc0(%r14)
    3008:      	movw	$0xa, 0xc2(%r14)
    3012:      	leaq	0x8(%rbp), %rdx
    3016:      	movl	$0x10, %ecx
    301b:      	movl	$0x4, %eax
    3020:      	movq	0x10(%rsp), %rdi
    3025:      	movl	$0x10, %esi
    302a:      	callq	*%rax
    302c:      	leaq	0xac(%r14), %rdi
    3033:      	addq	$0x18, %rbp
    3037:      	movl	$0x10, %ecx
    303c:      	movl	$0x4, %eax
    3041:      	movl	$0x10, %esi
    3046:      	movq	%rbp, %rdx
    3049:      	callq	*%rax
    304b:      	movzbl	0xd0(%rsp), %eax
    3053:      	cmpl	$0x11, %eax
    3056:      	je	0x30ab <generic_fexit_event+0x30ab>
    3058:      	cmpl	$0x6, %eax
    305b:      	jne	0x30fc <generic_fexit_event+0x30fc>
    3061:      	movq	0x30(%rsp), %r14
    3066:      	movzwl	0xd8(%rsp), %r12d
    306f:      	leaq	(%r14,%r12), %rdx
    3073:      	movq	0x8(%rsp), %r13
    3078:      	leaq	0xbc(%r13), %rdi
    307f:      	movl	$0x2, %ecx
    3084:      	movl	$0x4, %eax
    3089:      	movl	$0x2, %esi
    308e:      	callq	*%rax
    3090:      	leaq	0xbe(%r13), %rdi
    3097:      	leaq	(%r14,%r12), %rdx
    309b:      	addq	$0x2, %rdx
    309f:      	movl	$0x2, %ecx
    30a4:      	movl	$0x4, %eax
    30a9:      	jmp	0x30f3 <generic_fexit_event+0x30f3>
    30ab:      	movq	0x30(%rsp), %r14
    30b0:      	movzwl	0xd8(%rsp), %r12d
    30b9:      	leaq	(%r14,%r12), %rdx
    30bd:      	movq	0x8(%rsp), %r13
    30c2:      	leaq	0xbc(%r13), %rdi
    30c9:      	movl	$0x2, %ecx
    30ce:      	movl	$0x4, %eax
    30d3:      	movl	$0x2, %esi
    30d8:      	callq	*%rax
    30da:      	leaq	0xbe(%r13), %rdi
    30e1:      	leaq	(%r14,%r12), %rdx
    30e5:      	addq	$0x2, %rdx
    30e9:      	movl	$0x2, %ecx
    30ee:      	movl	$0x4, %eax
    30f3:      	movl	$0x2, %esi
    30f8:      	callq	*%rax
    30fa:      	jmp	0x310c <generic_fexit_event+0x310c>
    30fc:      	movq	0x8(%rsp), %r13
    3101:      	movl	$0x0, 0xbc(%r13)
    310c:      	movzwl	0xbc(%r13), %eax
    3114:      	movzwl	0xbe(%r13), %ecx
    311c:      	movbew	%ax, 0xbc(%r13)
    3126:      	movbew	%cx, 0xbe(%r13)
    3130:      	movq	0x80(%rsp), %rdx
    3138:      	addq	$0xe0, %rdx
    313f:      	leaq	0x70(%rsp), %rdi
    3144:      	movl	$0x8, %ecx
    3149:      	movl	$0x4, %eax
    314e:      	movl	$0x4, %r14d
    3154:      	movl	$0x8, %esi
    3159:      	callq	*%rax
    315b:      	movq	0x70(%rsp), %rcx
    3160:      	testq	%rcx, %rcx
    3163:      	je	0x31d6 <generic_fexit_event+0x31d6>
    3165:      	addq	$0x5, %rcx
    3169:      	leaq	0x90(%rsp), %rdi
    3171:      	movl	$0x8, %edx
    3176:      	movl	$0x4, %eax
    317b:      	movq	0x70(%rsp), %rdx
    3180:      	addq	$0x5, %rdx
    3184:      	movl	$0x8, %esi
    3189:      	callq	*%rax
    318b:      	movq	0x70(%rsp), %r12
    3190:      	movq	0x90(%rsp), %r13
    3198:      	movq	0x8(%rsp), %rbp
    319d:      	leaq	0xd4(%rbp), %rdi
    31a4:      	leaq	(%r12,%r13,8), %rdx
    31a8:      	addq	$0x44, %rdx
    31ac:      	movl	$0x4, %eax
    31b1:      	movl	$0x4, %esi
    31b6:      	callq	*%rax
    31b8:      	movq	%rbp, %rdi
    31bb:      	addq	$0xd8, %rdi
    31c2:      	leaq	(%r12,%r13,8), %rdx
    31c6:      	addq	$0x45, %rdx
    31ca:      	movl	$0x4, %eax
    31cf:      	movl	$0x4, %esi
    31d4:      	callq	*%rax
    31d6:      	movl	$0x4, %r13d
    31dc:      	movq	0x18(%rsp), %r15
    31e1:      	movl	$0x40, %r12d
    31e7:      	jmp	0x13b6 <generic_fexit_event+0x13b6>
    31ec:      	movw	%ax, 0xd8(%rsp)
    31f4:      	jmp	0x2ff1 <generic_fexit_event+0x2ff1>
    31f9:      	xorl	%eax, %eax
    31fb:      	movq	%rax, 0x10(%rsp)
    3200:      	cmpq	$0x5, 0x88(%rsp)
    3209:      	je	0x28c6 <generic_fexit_event+0x28c6>
    320f:      	movq	0xa0(%rsp), %rax
    3217:      	leaq	0x50(%rax), %rdx
    321b:      	leaq	0x30(%rsp), %rdi
    3220:      	movl	$0x4, %ebp
    3225:      	movl	$0x10, %ecx
    322a:      	movl	$0x4, %eax
    322f:      	movl	$0x10, %esi
    3234:      	callq	*%rax
    3236:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    323b:      	testl	%eax, %eax
    323d:      	js	0x338a <generic_fexit_event+0x338a>
    3243:      	movq	0x38(%rsp), %rdx
    3248:      	movq	0x10(%rsp), %rax
    324d:      	cmpq	%rax, %rdx
    3250:      	movq	%rax, %r12
    3253:      	cmovbq	%rdx, %r12
    3257:      	testq	%rax, %rax
    325a:      	cmovneq	%r12, %rdx
    325e:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    3263:      	movq	%rdx, 0x80(%rsp)
    326b:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    3272:      	ja	0x338a <generic_fexit_event+0x338a>
    3278:      	movq	0x8(%rsp), %rdi
    327d:      	addq	%r15, %rdi
    3280:      	movq	%rdi, 0x8(%rsp)
    3285:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    328b:      	addq	0x18(%rsp), %rdi
    3290:      	movq	0x30(%rsp), %rcx
    3295:      	movl	$0x4, %eax
    329a:      	movq	0x80(%rsp), %rsi
    32a2:      	movq	0x30(%rsp), %rdx
    32a7:      	callq	*%rax
    32a9:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    32ae:      	testl	%eax, %eax
    32b0:      	js	0x338a <generic_fexit_event+0x338a>
    32b6:      	movq	0x28(%rsp), %rax
    32bb:      	addq	0x80(%rsp), %rax
    32c3:      	movq	%rax, 0x28(%rsp)
    32c8:      	cmpq	$0x0, 0x10(%rsp)
    32ce:      	je	0x32dc <generic_fexit_event+0x32dc>
    32d0:      	subq	%r12, 0x10(%rsp)
    32d5:      	jne	0x32e3 <generic_fexit_event+0x32e3>
    32d7:      	jmp	0x28c6 <generic_fexit_event+0x28c6>
    32dc:      	xorl	%eax, %eax
    32de:      	movq	%rax, 0x10(%rsp)
    32e3:      	cmpq	$0x7, 0x88(%rsp)
    32ec:      	jb	0x28c6 <generic_fexit_event+0x28c6>
    32f2:      	movq	0xa0(%rsp), %rdx
    32fa:      	addq	$0x60, %rdx
    32fe:      	leaq	0x30(%rsp), %rdi
    3303:      	movl	$0x4, %ebp
    3308:      	movl	$0x10, %ecx
    330d:      	movl	$0x4, %eax
    3312:      	movl	$0x10, %esi
    3317:      	callq	*%rax
    3319:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    331e:      	testl	%eax, %eax
    3320:      	js	0x338a <generic_fexit_event+0x338a>
    3322:      	movq	0x38(%rsp), %rax
    3327:      	movq	0x10(%rsp), %rcx
    332c:      	cmpq	%rcx, %rax
    332f:      	movq	%rcx, %r13
    3332:      	cmovbq	%rax, %r13
    3336:      	testq	%rcx, %rcx
    3339:      	cmoveq	%rax, %r13
    333d:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    3342:      	cmpq	$0xffe, %r13            # imm = 0xFFE
    3349:      	ja	0x338a <generic_fexit_event+0x338a>
    334b:      	movq	0x80(%rsp), %rdi
    3353:      	addq	0x8(%rsp), %rdi
    3358:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    335e:      	addq	0x18(%rsp), %rdi
    3363:      	movq	0x30(%rsp), %rcx
    3368:      	movl	$0x4, %eax
    336d:      	movq	0x30(%rsp), %rdx
    3372:      	movl	%r13d, %esi
    3375:      	callq	*%rax
    3377:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    337c:      	testl	%eax, %eax
    337e:      	js	0x338a <generic_fexit_event+0x338a>
    3380:      	addq	0x28(%rsp), %r13
    3385:      	jmp	0x28cb <generic_fexit_event+0x28cb>
    338a:      	movq	0x18(%rsp), %rax
    338f:      	movl	%ecx, (%rax,%r14)
    3393:      	jmp	0x1b3a <generic_fexit_event+0x1b3a>
