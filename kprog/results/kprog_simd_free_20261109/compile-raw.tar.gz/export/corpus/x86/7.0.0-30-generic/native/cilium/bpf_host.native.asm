
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/cilium/bpf_host.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <__check_cluster_id_bits>:
       0:      	movq	(%rip), %rax            # 0x7 <__check_cluster_id_bits+0x7>
       7:      	movl	(%rax), %eax
       9:      	retq
       a:      	nopw	(%rax,%rax)

0000000000000010 <__check_eth_header_length>:
      10:      	movq	(%rip), %rax            # 0x17 <__check_eth_header_length+0x7>
      17:      	movzbl	(%rax), %eax
      1a:      	retq
      1b:      	nopl	(%rax,%rax)

0000000000000020 <__check_device_mtu>:
      20:      	movq	(%rip), %rax            # 0x27 <__check_device_mtu+0x7>
      27:      	movzwl	(%rax), %eax
      2a:      	retq

Disassembly of section tc/tail:

0000000000000000 <tail_drop_notify>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x58, %rsp
       e:      	movq	%rdi, %rbx
      11:      	movl	0x38(%rdi), %r12d
      15:      	movq	(%rip), %rax            # 0x1c <tail_drop_notify+0x1c>
      1c:      	cmpb	$0x0, (%rax)
      1f:      	je	0x46 <tail_drop_notify+0x46>
      21:      	movl	$0x0, 0x10(%rsp)
      29:      	movl	$0x1, %eax
      2e:      	movq	(%rip), %rdi            # 0x35 <tail_drop_notify+0x35>
      35:      	leaq	0x10(%rsp), %rsi
      3a:      	callq	*%rax
      3c:      	testq	%rax, %rax
      3f:      	je	0x46 <tail_drop_notify+0x46>
      41:      	movq	(%rax), %rax
      44:      	jmp	0x48 <tail_drop_notify+0x48>
      46:      	xorl	%eax, %eax
      48:      	movq	%rax, 0x8(%rsp)
      4d:      	movl	0x40(%rbx), %ebp
      50:      	movl	0x70(%rbx), %r13d
      54:      	movq	$0x2, 0x40(%rsp)
      5d:      	movq	(%rip), %rcx            # 0x64 <tail_drop_notify+0x64>
      64:      	cmpl	$0x0, (%rcx)
      67:      	movl	%r13d, %eax
      6a:      	je	0x1b4 <tail_drop_notify+0x1b4>
      70:      	movl	%r12d, (%rsp)
      74:      	movq	(%rip), %rax            # 0x7b <tail_drop_notify+0x7b>
      7b:      	movl	(%rax), %eax
      7d:      	movq	%rax, 0x48(%rsp)
      82:      	movl	(%rcx), %r12d
      85:      	movl	$0x5, %ecx
      8a:      	xorl	%eax, %eax
      8c:      	callq	*%rcx
      8e:      	movq	%rax, %r15
      91:      	movl	$0x2, 0x4(%rsp)
      99:      	movl	$0x1, %eax
      9e:      	movq	(%rip), %rdi            # 0xa5 <tail_drop_notify+0xa5>
      a5:      	leaq	0x4(%rsp), %rsi
      aa:      	callq	*%rax
      ac:      	movq	%rax, %r14
      af:      	testq	%rax, %rax
      b2:      	jne	0xe2 <tail_drop_notify+0xe2>
      b4:      	movq	$0x0, 0x50(%rsp)
      bd:      	movl	$0x2, %eax
      c2:      	movq	(%rip), %rdi            # 0xc9 <tail_drop_notify+0xc9>
      c9:      	leaq	0x4(%rsp), %rsi
      ce:      	leaq	0x50(%rsp), %r14
      d3:      	movq	%r14, %rdx
      d6:      	xorl	%ecx, %ecx
      d8:      	callq	*%rax
      da:      	testl	%eax, %eax
      dc:      	js	0x2b7 <tail_drop_notify+0x2b7>
      e2:      	movl	$0x1, %eax
      e7:      	movq	(%rip), %rdi            # 0xee <tail_drop_notify+0xee>
      ee:      	leaq	0x40(%rsp), %rsi
      f3:      	callq	*%rax
      f5:      	testq	%rax, %rax
      f8:      	je	0x165 <tail_drop_notify+0x165>
      fa:      	movq	(%rax), %rcx
      fd:      	movq	%r15, %rsi
     100:      	subq	%rcx, %rsi
     103:      	cmpq	$0x3b9aca00, %rsi       # imm = 0x3B9ACA00
     10a:      	jbe	0x199 <tail_drop_notify+0x199>
     110:      	movl	$0x3b9aca00, %ecx       # imm = 0x3B9ACA00
     115:      	movq	%rax, %rdi
     118:      	movq	%rsi, %rax
     11b:      	xorl	%edx, %edx
     11d:      	divq	%rcx
     120:      	movq	%rax, %rcx
     123:      	movl	$0x3b9aca00, %r8d       # imm = 0x3B9ACA00
     129:      	movq	%rsi, %rax
     12c:      	xorl	%edx, %edx
     12e:      	divq	%r8
     131:      	movq	%rdi, %rax
     134:      	imulq	%r12, %rcx
     138:      	addq	0x8(%rdi), %rcx
     13c:      	movq	%rcx, 0x8(%rdi)
     140:      	subq	%rdx, %r15
     143:      	movq	%r15, (%rdi)
     146:      	movq	0x48(%rsp), %rdx
     14b:      	cmpq	%rdx, %rcx
     14e:      	movl	(%rsp), %r12d
     152:      	jbe	0x15b <tail_drop_notify+0x15b>
     154:      	movq	%rdx, 0x8(%rax)
     158:      	movq	%rdx, %rcx
     15b:      	testq	%rcx, %rcx
     15e:      	jne	0x1aa <tail_drop_notify+0x1aa>
     160:      	jmp	0x2ca <tail_drop_notify+0x2ca>
     165:      	movq	%r15, 0x10(%rsp)
     16a:      	decq	%r12
     16d:      	movq	%r12, 0x18(%rsp)
     172:      	movl	$0x2, %eax
     177:      	movq	(%rip), %rdi            # 0x17e <tail_drop_notify+0x17e>
     17e:      	leaq	0x40(%rsp), %rsi
     183:      	leaq	0x10(%rsp), %rdx
     188:      	xorl	%ecx, %ecx
     18a:      	callq	*%rax
     18c:      	testl	%eax, %eax
     18e:      	movl	(%rsp), %r12d
     192:      	jns	0x1b1 <tail_drop_notify+0x1b1>
     194:      	jmp	0x2ca <tail_drop_notify+0x2ca>
     199:      	movq	0x8(%rax), %rcx
     19d:      	movl	(%rsp), %r12d
     1a1:      	testq	%rcx, %rcx
     1a4:      	je	0x2ca <tail_drop_notify+0x2ca>
     1aa:      	decq	%rcx
     1ad:      	movq	%rcx, 0x8(%rax)
     1b1:      	movl	0x70(%rbx), %eax
     1b4:      	movl	%ebp, %ecx
     1b6:      	shrl	$0x10, %ecx
     1b9:      	movl	%ebp, %edx
     1bb:      	shrl	$0x8, %edx
     1be:      	movzwl	0xb4(%rbx), %esi
     1c5:      	movq	(%rip), %rdi            # 0x1cc <tail_drop_notify+0x1cc>
     1cc:      	cmpb	$0x0, (%rdi)
     1cf:      	sete	%dil
     1d3:      	addb	%dil, %dil
     1d6:      	cmpl	$0xdd86, %esi           # imm = 0xDD86
     1dc:      	sete	%sil
     1e0:      	orb	%dil, %sil
     1e3:      	movq	(%rip), %rdi            # 0x1ea <tail_drop_notify+0x1ea>
     1ea:      	movl	(%rdi), %edi
     1ec:      	cmpl	%eax, %edi
     1ee:      	cmovbl	%edi, %eax
     1f1:      	movq	(%rip), %rdi            # 0x1f8 <tail_drop_notify+0x1f8>
     1f8:      	movzwl	(%rdi), %r11d
     1fc:      	movl	0x98(%rbx), %r14d
     203:      	movl	0x30(%rbx), %r8d
     207:      	movl	0x34(%rbx), %r9d
     20b:      	movl	0x3c(%rbx), %r10d
     20f:      	movl	%r12d, %edi
     212:      	shrl	$0x8, %edi
     215:      	movq	0x10(%rbx), %r15
     219:      	testq	%r15, %r15
     21c:      	je	0x227 <tail_drop_notify+0x227>
     21e:      	movl	0xe0(%r15), %r15d
     225:      	jmp	0x22a <tail_drop_notify+0x22a>
     227:      	xorl	%r15d, %r15d
     22a:      	movb	$0x0, 0x37(%rsp)
     22f:      	movw	$0x0, 0x35(%rsp)
     236:      	movb	$0x1, 0x10(%rsp)
     23b:      	movb	%r12b, 0x11(%rsp)
     240:      	movw	%r11w, 0x12(%rsp)
     246:      	movl	%r14d, 0x14(%rsp)
     24b:      	movl	%r13d, 0x18(%rsp)
     250:      	movw	%ax, 0x1c(%rsp)
     255:      	movw	$0x3, 0x1e(%rsp)
     25c:      	movl	%r8d, 0x20(%rsp)
     261:      	movl	%r9d, 0x24(%rsp)
     266:      	movl	%r10d, 0x28(%rsp)
     26b:      	movw	%cx, 0x2c(%rsp)
     270:      	movb	%dl, 0x2e(%rsp)
     274:      	movb	%dil, 0x2f(%rsp)
     279:      	movl	%r15d, 0x30(%rsp)
     27e:      	movb	%sil, 0x34(%rsp)
     283:      	movq	0x8(%rsp), %rcx
     288:      	movq	%rcx, 0x38(%rsp)
     28d:      	movl	$0x19, %r9d
     293:      	shlq	$0x20, %rax
     297:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     29c:      	orq	%rax, %rdx
     29f:      	movq	(%rip), %rsi            # 0x2a6 <tail_drop_notify+0x2a6>
     2a6:      	leaq	0x10(%rsp), %rcx
     2ab:      	movq	%rbx, %rdi
     2ae:      	movl	$0x30, %r8d
     2b4:      	callq	*%r9
     2b7:      	movzbl	%bpl, %eax
     2bb:      	addq	$0x58, %rsp
     2bf:      	popq	%rbx
     2c0:      	popq	%r12
     2c2:      	popq	%r13
     2c4:      	popq	%r14
     2c6:      	popq	%r15
     2c8:      	popq	%rbp
     2c9:      	retq
     2ca:      	incq	(%r14)
     2cd:      	jmp	0x2b7 <tail_drop_notify+0x2b7>
     2cf:      	nop

00000000000002d0 <tail_icmp6_send_time_exceeded>:
     2d0:      	pushq	%rbp
     2d1:      	pushq	%r15
     2d3:      	pushq	%r14
     2d5:      	pushq	%r13
     2d7:      	pushq	%r12
     2d9:      	pushq	%rbx
     2da:      	subq	$0xd8, %rsp
     2e1:      	movq	%rdi, %rbx
     2e4:      	movl	0x30(%rdi), %r14d
     2e8:      	movl	0x34(%rdi), %r13d
     2ec:      	movl	$0x0, 0x30(%rdi)
     2f3:      	movq	$0x0, 0x88(%rsp)
     2ff:      	movq	$0x0, 0x80(%rsp)
     30b:      	movq	$0x0, 0x78(%rsp)
     314:      	movq	$0x0, 0x70(%rsp)
     31d:      	movq	$0x0, 0x68(%rsp)
     326:      	movq	$0x0, 0x60(%rsp)
     32f:      	movq	$0x0, 0x58(%rsp)
     338:      	movq	$0x0, 0x50(%rsp)
     341:      	movq	$0x0, 0x48(%rsp)
     34a:      	movq	$0x0, 0x40(%rsp)
     353:      	movw	$0x0, 0xc(%rsp)
     35a:      	movb	$0x3a, 0xf(%rsp)
     35f:      	movq	(%rip), %rax            # 0x366 <tail_icmp6_send_time_exceeded+0x96>
     366:      	movq	(%rax), %rcx
     369:      	movq	%rcx, 0xa0(%rsp)
     371:      	movq	0x8(%rax), %rax
     375:      	movq	%rax, 0x98(%rsp)
     37d:      	movq	$0x3, 0x40(%rsp)
     386:      	movw	$0xe02, 0x10(%rsp)      # imm = 0xE02
     38d:      	movq	(%rip), %r12            # 0x394 <tail_icmp6_send_time_exceeded+0xc4>
     394:      	movzwl	(%r12), %eax
     399:      	leaq	0x48(%rsp), %r15
     39e:      	movw	%ax, 0x12(%rsp)
     3a3:      	movl	0x98(%rdi), %eax
     3a9:      	movl	%eax, 0x14(%rsp)
     3ad:      	movq	$0x0, 0x18(%rsp)
     3b6:      	movl	$0x0, 0x20(%rsp)
     3be:      	movl	$0x19, %eax
     3c3:      	movq	(%rip), %rsi            # 0x3ca <tail_icmp6_send_time_exceeded+0xfa>
     3ca:      	leaq	0x10(%rsp), %rcx
     3cf:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     3d4:      	movl	$0x14, %r8d
     3da:      	callq	*%rax
     3dc:      	movl	$0x1a, %eax
     3e1:      	movq	%rbx, %rdi
     3e4:      	movl	%r14d, %esi
     3e7:      	movq	%r15, %rdx
     3ea:      	movl	$0x28, %ecx
     3ef:      	callq	*%rax
     3f1:      	movl	$0xffffff7a, %ebp       # imm = 0xFFFFFF7A
     3f6:      	testl	%eax, %eax
     3f8:      	js	0x918 <tail_icmp6_send_time_exceeded+0x648>
     3fe:      	movl	$0x9, %eax
     403:      	leal	0x6(%r14), %esi
     407:      	leaq	0xf(%rsp), %rdx
     40c:      	movq	%rbx, %rdi
     40f:      	movl	$0x1, %ecx
     414:      	xorl	%r8d, %r8d
     417:      	callq	*%rax
     419:      	testl	%eax, %eax
     41b:      	js	0x913 <tail_icmp6_send_time_exceeded+0x643>
     421:      	leaq	0x70(%rsp), %rdx
     426:      	movzbl	0x4e(%rsp), %eax
     42b:      	cmpl	$0x6, %eax
     42e:      	je	0x55b <tail_icmp6_send_time_exceeded+0x28b>
     434:      	cmpl	$0x3a, %eax
     437:      	je	0x447 <tail_icmp6_send_time_exceeded+0x177>
     439:      	movl	$0xffffff72, %ebp       # imm = 0xFFFFFF72
     43e:      	cmpl	$0x11, %eax
     441:      	jne	0x918 <tail_icmp6_send_time_exceeded+0x648>
     447:      	movl	$0x1a, %eax
     44c:      	leal	0x28(%r14), %r15d
     450:      	movq	%rbx, %rdi
     453:      	movl	%r15d, %esi
     456:      	movl	$0x8, %ecx
     45b:      	callq	*%rax
     45d:      	movl	$0xffffff7a, %ebp       # imm = 0xFFFFFF7A
     462:      	testl	%eax, %eax
     464:      	js	0x918 <tail_icmp6_send_time_exceeded+0x648>
     46a:      	movl	$0x1c, %eax
     46f:      	leaq	0x40(%rsp), %rdx
     474:      	xorl	%edi, %edi
     476:      	xorl	%esi, %esi
     478:      	movl	$0x38, %ecx
     47d:      	xorl	%r8d, %r8d
     480:      	callq	*%rax
     482:      	movl	$0x38000000, 0x10(%rsp) # imm = 0x38000000
     48a:      	movl	$0x3a000000, 0x28(%rsp) # imm = 0x3A000000
     492:      	leaq	0x50(%rsp), %rdx
     497:      	movl	$0x1c, %r9d
     49d:      	xorl	%edi, %edi
     49f:      	xorl	%esi, %esi
     4a1:      	movl	$0x10, %ecx
     4a6:      	movl	%eax, %r8d
     4a9:      	callq	*%r9
     4ac:      	leaq	0x60(%rsp), %rdx
     4b1:      	movl	$0x1c, %r9d
     4b7:      	xorl	%edi, %edi
     4b9:      	xorl	%esi, %esi
     4bb:      	movl	$0x10, %ecx
     4c0:      	movl	%eax, %r8d
     4c3:      	callq	*%r9
     4c6:      	movl	$0x1c, %r9d
     4cc:      	leaq	0x10(%rsp), %rdx
     4d1:      	xorl	%edi, %edi
     4d3:      	xorl	%esi, %esi
     4d5:      	movl	$0x4, %ecx
     4da:      	movl	%eax, %r8d
     4dd:      	callq	*%r9
     4e0:      	movl	$0x1c, %r9d
     4e6:      	leaq	0x28(%rsp), %rdx
     4eb:      	xorl	%edi, %edi
     4ed:      	xorl	%esi, %esi
     4ef:      	movl	$0x4, %ecx
     4f4:      	movl	%eax, %r8d
     4f7:      	callq	*%r9
     4fa:      	movl	%eax, %ebp
     4fc:      	movw	$0x3800, 0xc(%rsp)      # imm = 0x3800
     503:      	movbew	0x4c(%rsp), %ax
     50a:      	movzwl	%ax, %eax
     50d:      	movl	$0x26, %ecx
     512:      	movl	0x70(%rbx), %edx
     515:      	negl	%eax
     517:      	leal	(%rdx,%rax), %esi
     51a:      	addl	$0x38, %esi
     51d:      	movq	%rbx, %rdi
     520:      	xorl	%edx, %edx
     522:      	callq	*%rcx
     524:      	testl	%eax, %eax
     526:      	js	0x913 <tail_icmp6_send_time_exceeded+0x643>
     52c:      	movl	$0x9, %eax
     531:      	leaq	0x40(%rsp), %rdx
     536:      	movq	%rbx, %rdi
     539:      	movl	%r15d, %esi
     53c:      	movl	$0x38, %ecx
     541:      	xorl	%r8d, %r8d
     544:      	callq	*%rax
     546:      	testl	%eax, %eax
     548:      	js	0x913 <tail_icmp6_send_time_exceeded+0x643>
     54e:      	movl	%ebp, %r15d
     551:      	movl	$0x9, %eax
     556:      	jmp	0x665 <tail_icmp6_send_time_exceeded+0x395>
     55b:      	movl	$0x1a, %eax
     560:      	leal	0x28(%r14), %r15d
     564:      	movq	%rbx, %rdi
     567:      	movl	%r15d, %esi
     56a:      	movl	$0x14, %ecx
     56f:      	callq	*%rax
     571:      	testl	%eax, %eax
     573:      	js	0x918 <tail_icmp6_send_time_exceeded+0x648>
     579:      	movl	$0x1c, %eax
     57e:      	leaq	0x40(%rsp), %rdx
     583:      	xorl	%edi, %edi
     585:      	xorl	%esi, %esi
     587:      	movl	$0x44, %ecx
     58c:      	xorl	%r8d, %r8d
     58f:      	callq	*%rax
     591:      	movl	$0x44000000, 0x10(%rsp) # imm = 0x44000000
     599:      	movl	$0x3a000000, 0x28(%rsp) # imm = 0x3A000000
     5a1:      	leaq	0x50(%rsp), %rdx
     5a6:      	movl	$0x1c, %r9d
     5ac:      	xorl	%edi, %edi
     5ae:      	xorl	%esi, %esi
     5b0:      	movl	$0x10, %ecx
     5b5:      	movl	%eax, %r8d
     5b8:      	callq	*%r9
     5bb:      	leaq	0x60(%rsp), %rdx
     5c0:      	movl	$0x1c, %r9d
     5c6:      	xorl	%edi, %edi
     5c8:      	xorl	%esi, %esi
     5ca:      	movl	$0x10, %ecx
     5cf:      	movl	%eax, %r8d
     5d2:      	callq	*%r9
     5d5:      	movl	$0x1c, %r9d
     5db:      	leaq	0x10(%rsp), %rdx
     5e0:      	xorl	%edi, %edi
     5e2:      	xorl	%esi, %esi
     5e4:      	movl	$0x4, %ecx
     5e9:      	movl	%eax, %r8d
     5ec:      	callq	*%r9
     5ef:      	movl	$0x1c, %r9d
     5f5:      	leaq	0x28(%rsp), %rdx
     5fa:      	xorl	%edi, %edi
     5fc:      	xorl	%esi, %esi
     5fe:      	movl	$0x4, %ecx
     603:      	movl	%eax, %r8d
     606:      	callq	*%r9
     609:      	movl	%eax, %ebp
     60b:      	movw	$0x4400, 0xc(%rsp)      # imm = 0x4400
     612:      	movbew	0x4c(%rsp), %ax
     619:      	movzwl	%ax, %eax
     61c:      	movl	$0x26, %ecx
     621:      	movl	0x70(%rbx), %edx
     624:      	negl	%eax
     626:      	leal	(%rdx,%rax), %esi
     629:      	addl	$0x44, %esi
     62c:      	movq	%rbx, %rdi
     62f:      	xorl	%edx, %edx
     631:      	callq	*%rcx
     633:      	testl	%eax, %eax
     635:      	js	0x913 <tail_icmp6_send_time_exceeded+0x643>
     63b:      	movl	$0x9, %eax
     640:      	leaq	0x40(%rsp), %rdx
     645:      	movq	%rbx, %rdi
     648:      	movl	%r15d, %esi
     64b:      	movl	$0x44, %ecx
     650:      	xorl	%r8d, %r8d
     653:      	callq	*%rax
     655:      	testl	%eax, %eax
     657:      	js	0x913 <tail_icmp6_send_time_exceeded+0x643>
     65d:      	movl	%ebp, %r15d
     660:      	movl	$0x9, %eax
     665:      	leal	0x4(%r14), %esi
     669:      	leaq	0xc(%rsp), %rdx
     66e:      	movq	%rbx, %rdi
     671:      	movl	$0x2, %ecx
     676:      	xorl	%r8d, %r8d
     679:      	callq	*%rax
     67b:      	movl	$0xffffff73, %ebp       # imm = 0xFFFFFF73
     680:      	testl	%eax, %eax
     682:      	js	0x918 <tail_icmp6_send_time_exceeded+0x648>
     688:      	leal	0x2a(%r14), %ebp
     68c:      	movl	$0xb, %eax
     691:      	movq	%rbx, %rdi
     694:      	movl	%ebp, %esi
     696:      	xorl	%edx, %edx
     698:      	movl	%r15d, %ecx
     69b:      	movl	$0x10, %r8d
     6a1:      	callq	*%rax
     6a3:      	testl	%eax, %eax
     6a5:      	js	0x9d3 <tail_icmp6_send_time_exceeded+0x703>
     6ab:      	movl	%ebp, 0x3c(%rsp)
     6af:      	movq	0xa0(%rsp), %rax
     6b7:      	movq	0x98(%rsp), %rcx
     6bf:      	movq	%rax, 0x28(%rsp)
     6c4:      	movq	%rcx, 0x30(%rsp)
     6c9:      	movq	(%rip), %rax            # 0x6d0 <tail_icmp6_send_time_exceeded+0x400>
     6d0:      	movq	(%rax), %rax
     6d3:      	movq	%rax, 0xa8(%rsp)
     6db:      	movl	$0x1a, %eax
     6e0:      	leal	0x8(%r14), %r15d
     6e4:      	leaq	0xb8(%rsp), %rdx
     6ec:      	movq	%rbx, %rdi
     6ef:      	movl	%r15d, %esi
     6f2:      	movl	$0x10, %ecx
     6f7:      	callq	*%rax
     6f9:      	movl	$0xffffff7a, %ebp       # imm = 0xFFFFFF7A
     6fe:      	testl	%eax, %eax
     700:      	js	0x918 <tail_icmp6_send_time_exceeded+0x648>
     706:      	movl	$0x1a, %eax
     70b:      	addl	$0x18, %r14d
     70f:      	leaq	0xc8(%rsp), %rdx
     717:      	movq	%rbx, %rdi
     71a:      	movl	%r14d, %esi
     71d:      	movl	$0x10, %ecx
     722:      	callq	*%rax
     724:      	testl	%eax, %eax
     726:      	js	0x918 <tail_icmp6_send_time_exceeded+0x648>
     72c:      	movl	$0x9, %eax
     731:      	leaq	0x28(%rsp), %rdx
     736:      	movq	%rbx, %rdi
     739:      	movl	%r15d, %esi
     73c:      	movl	$0x10, %ecx
     741:      	xorl	%r8d, %r8d
     744:      	callq	*%rax
     746:      	testl	%eax, %eax
     748:      	js	0x913 <tail_icmp6_send_time_exceeded+0x643>
     74e:      	movl	$0x9, %eax
     753:      	leaq	0xb8(%rsp), %rdx
     75b:      	movq	%rbx, %rdi
     75e:      	movl	%r14d, %esi
     761:      	movl	$0x10, %ecx
     766:      	xorl	%r8d, %r8d
     769:      	callq	*%rax
     76b:      	testl	%eax, %eax
     76d:      	js	0x913 <tail_icmp6_send_time_exceeded+0x643>
     773:      	movl	$0x1c, %eax
     778:      	leaq	0xb8(%rsp), %rdi
     780:      	leaq	0x28(%rsp), %rdx
     785:      	movl	$0x10, %esi
     78a:      	movl	$0x10, %ecx
     78f:      	xorl	%r8d, %r8d
     792:      	callq	*%rax
     794:      	movl	$0xb, %r14d
     79a:      	movq	%rbx, %rdi
     79d:      	movl	0x3c(%rsp), %r15d
     7a2:      	movl	%r15d, %esi
     7a5:      	xorl	%edx, %edx
     7a7:      	movl	%eax, %ecx
     7a9:      	movl	$0x10, %r8d
     7af:      	callq	*%r14
     7b2:      	movl	$0xffffff66, %ebp       # imm = 0xFFFFFF66
     7b7:      	testl	%eax, %eax
     7b9:      	js	0x918 <tail_icmp6_send_time_exceeded+0x648>
     7bf:      	movl	$0x1c, %eax
     7c4:      	leaq	0xc8(%rsp), %rdi
     7cc:      	leaq	0xb8(%rsp), %rdx
     7d4:      	movl	$0x10, %esi
     7d9:      	movl	$0x10, %ecx
     7de:      	xorl	%r8d, %r8d
     7e1:      	callq	*%rax
     7e3:      	movq	%rbx, %rdi
     7e6:      	movl	%r15d, %esi
     7e9:      	xorl	%edx, %edx
     7eb:      	movl	%eax, %ecx
     7ed:      	movl	$0x10, %r8d
     7f3:      	callq	*%r14
     7f6:      	testl	%eax, %eax
     7f8:      	js	0x918 <tail_icmp6_send_time_exceeded+0x648>
     7fe:      	movl	$0x1a, %eax
     803:      	leaq	0xb0(%rsp), %rdx
     80b:      	movq	%rbx, %rdi
     80e:      	movl	$0x6, %esi
     813:      	movl	$0x6, %ecx
     818:      	callq	*%rax
     81a:      	movl	$0xffffff7a, %ebp       # imm = 0xFFFFFF7A
     81f:      	testl	%eax, %eax
     821:      	js	0x918 <tail_icmp6_send_time_exceeded+0x648>
     827:      	movl	$0x9, %eax
     82c:      	leaq	0xb0(%rsp), %rdx
     834:      	movq	%rbx, %rdi
     837:      	xorl	%esi, %esi
     839:      	movl	$0x6, %ecx
     83e:      	xorl	%r8d, %r8d
     841:      	callq	*%rax
     843:      	testl	%eax, %eax
     845:      	js	0x913 <tail_icmp6_send_time_exceeded+0x643>
     84b:      	movl	$0x9, %eax
     850:      	leaq	0xa8(%rsp), %rdx
     858:      	xorl	%r14d, %r14d
     85b:      	movq	%rbx, %rdi
     85e:      	movl	$0x6, %esi
     863:      	movl	$0x6, %ecx
     868:      	xorl	%r8d, %r8d
     86b:      	callq	*%rax
     86d:      	movl	$0xffffff73, %ebp       # imm = 0xFFFFFF73
     872:      	testl	%eax, %eax
     874:      	js	0x918 <tail_icmp6_send_time_exceeded+0x648>
     87a:      	movq	0x10(%rbx), %rax
     87e:      	testq	%rax, %rax
     881:      	je	0x88a <tail_icmp6_send_time_exceeded+0x5ba>
     883:      	movl	0xe0(%rax), %r14d
     88a:      	movl	0x70(%rbx), %eax
     88d:      	movq	(%rip), %rcx            # 0x894 <tail_icmp6_send_time_exceeded+0x5c4>
     894:      	movl	(%rcx), %edx
     896:      	cmpl	%edx, %eax
     898:      	movw	$0x403, 0x10(%rsp)      # imm = 0x403
     89f:      	movzwl	(%r12), %ecx
     8a4:      	movw	%cx, 0x12(%rsp)
     8a9:      	cmovbl	%eax, %edx
     8ac:      	movl	0x98(%rbx), %ecx
     8b2:      	movl	%ecx, 0x14(%rsp)
     8b6:      	movl	%eax, 0x18(%rsp)
     8ba:      	movw	%dx, 0x1c(%rsp)
     8bf:      	movw	$0x1, 0x1e(%rsp)
     8c6:      	movl	%r14d, 0x20(%rsp)
     8cb:      	movl	$0x0, 0x24(%rsp)
     8d3:      	movl	$0x19, %eax
     8d8:      	shlq	$0x20, %rdx
     8dc:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     8e1:      	orq	%rcx, %rdx
     8e4:      	movq	(%rip), %rsi            # 0x8eb <tail_icmp6_send_time_exceeded+0x61b>
     8eb:      	leaq	0x10(%rsp), %rcx
     8f0:      	movq	%rbx, %rdi
     8f3:      	movl	$0x18, %r8d
     8f9:      	callq	*%rax
     8fb:      	movq	0x10(%rbx), %rax
     8ff:      	testq	%rax, %rax
     902:      	je	0x9dd <tail_icmp6_send_time_exceeded+0x70d>
     908:      	movl	0xe0(%rax), %edi
     90e:      	jmp	0x9df <tail_icmp6_send_time_exceeded+0x70f>
     913:      	movl	$0xffffff73, %ebp       # imm = 0xFFFFFF73
     918:      	movl	%ebp, %eax
     91a:      	negl	%eax
     91c:      	cmovsl	%ebp, %eax
     91f:      	movq	$0x0, 0x30(%rbx)
     927:      	movzbl	%al, %eax
     92a:      	movl	%eax, 0x38(%rbx)
     92d:      	movabsq	$0x142670200000000, %rcx # imm = 0x142670200000000
     937:      	movq	%rcx, 0x3c(%rbx)
     93b:      	movl	0x70(%rbx), %r14d
     93f:      	movabsq	$0x6701420000, %rcx     # imm = 0x6701420000
     949:      	movq	%rcx, 0x10(%rsp)
     94e:      	movb	%al, 0x10(%rsp)
     952:      	andb	$0x3, %r13b
     956:      	movb	%r13b, 0x11(%rsp)
     95b:      	movl	$0x1, %eax
     960:      	movq	(%rip), %rdi            # 0x967 <tail_icmp6_send_time_exceeded+0x697>
     967:      	leaq	0x10(%rsp), %rsi
     96c:      	callq	*%rax
     96e:      	testq	%rax, %rax
     971:      	je	0x97c <tail_icmp6_send_time_exceeded+0x6ac>
     973:      	incq	(%rax)
     976:      	addq	%r14, 0x8(%rax)
     97a:      	jmp	0x9a4 <tail_icmp6_send_time_exceeded+0x6d4>
     97c:      	movq	$0x1, 0x40(%rsp)
     985:      	movq	%r14, 0x48(%rsp)
     98a:      	movl	$0x2, %eax
     98f:      	movq	(%rip), %rdi            # 0x996 <tail_icmp6_send_time_exceeded+0x6c6>
     996:      	leaq	0x10(%rsp), %rsi
     99b:      	leaq	0x40(%rsp), %rdx
     9a0:      	xorl	%ecx, %ecx
     9a2:      	callq	*%rax
     9a4:      	movl	$0xc, %eax
     9a9:      	movq	(%rip), %rsi            # 0x9b0 <tail_icmp6_send_time_exceeded+0x6e0>
     9b0:      	movq	%rbx, %rdi
     9b3:      	movl	$0x1, %edx
     9b8:      	callq	*%rax
     9ba:      	movl	$0x2, %ebp
     9bf:      	movl	%ebp, %eax
     9c1:      	addq	$0xd8, %rsp
     9c8:      	popq	%rbx
     9c9:      	popq	%r12
     9cb:      	popq	%r13
     9cd:      	popq	%r14
     9cf:      	popq	%r15
     9d1:      	popq	%rbp
     9d2:      	retq
     9d3:      	movl	$0xffffff66, %ebp       # imm = 0xFFFFFF66
     9d8:      	jmp	0x918 <tail_icmp6_send_time_exceeded+0x648>
     9dd:      	xorl	%edi, %edi
     9df:      	movl	$0x17, %eax
     9e4:      	xorl	%esi, %esi
     9e6:      	callq	*%rax
     9e8:      	movl	%eax, %ebp
     9ea:      	testl	%eax, %eax
     9ec:      	js	0x918 <tail_icmp6_send_time_exceeded+0x648>
     9f2:      	cmpl	$0x2, %ebp
     9f5:      	jne	0x9bf <tail_icmp6_send_time_exceeded+0x6ef>
     9f7:      	jmp	0x918 <tail_icmp6_send_time_exceeded+0x648>
     9fc:      	nopl	(%rax)

0000000000000a00 <tail_icmp6_handle_ns>:
     a00:      	pushq	%rbp
     a01:      	pushq	%r15
     a03:      	pushq	%r14
     a05:      	pushq	%r13
     a07:      	pushq	%r12
     a09:      	pushq	%rbx
     a0a:      	subq	$0xc8, %rsp
     a11:      	movq	%rdi, %rbx
     a14:      	movl	0x30(%rdi), %r14d
     a18:      	movl	0x34(%rdi), %r13d
     a1c:      	movl	$0x0, 0x30(%rdi)
     a23:      	movq	(%rip), %rax            # 0xa2a <tail_icmp6_handle_ns+0x2a>
     a2a:      	movq	(%rax), %rcx
     a2d:      	movq	%rcx, 0xb0(%rsp)
     a35:      	movq	0x8(%rax), %rax
     a39:      	movq	%rax, 0xa8(%rsp)
     a41:      	movq	(%rip), %r15            # 0xa48 <tail_icmp6_handle_ns+0x48>
     a48:      	movzbl	(%r15), %eax
     a4c:      	movb	%al, (%rsp)
     a4f:      	movzbl	0x1(%r15), %eax
     a54:      	movb	%al, 0x13(%rsp)
     a58:      	movzbl	0x2(%r15), %eax
     a5d:      	movb	%al, 0x10(%rsp)
     a61:      	movzbl	0x3(%r15), %eax
     a66:      	movb	%al, 0x12(%rsp)
     a6a:      	movzbl	0x4(%r15), %eax
     a6f:      	movb	%al, 0xc(%rsp)
     a73:      	movzbl	0x5(%r15), %eax
     a78:      	movb	%al, 0x11(%rsp)
     a7c:      	movzwl	0x6(%r15), %eax
     a81:      	movw	%ax, 0x76(%rsp)
     a86:      	movl	$0x1a, %eax
     a8b:      	leal	0x30(%r14), %ebp
     a8f:      	leaq	0x88(%rsp), %rdx
     a97:      	movl	%ebp, %esi
     a99:      	movl	$0x10, %ecx
     a9e:      	callq	*%rax
     aa0:      	testl	%eax, %eax
     aa2:      	js	0x1364 <tail_icmp6_handle_ns+0x964>
     aa8:      	movq	0x90(%rsp), %rax
     ab0:      	movw	$0xd02, 0x20(%rsp)      # imm = 0xD02
     ab7:      	movq	(%rip), %rcx            # 0xabe <tail_icmp6_handle_ns+0xbe>
     abe:      	movzwl	(%rcx), %ecx
     ac1:      	movw	%cx, 0x22(%rsp)
     ac6:      	movl	0x98(%rbx), %ecx
     acc:      	movl	%ecx, 0x24(%rsp)
     ad0:      	movq	%rax, 0x28(%rsp)
     ad5:      	movl	$0x0, 0x30(%rsp)
     add:      	movl	$0x19, %eax
     ae2:      	movq	(%rip), %rsi            # 0xae9 <tail_icmp6_handle_ns+0xe9>
     ae9:      	leaq	0x20(%rsp), %rcx
     aee:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     af3:      	movq	%rbx, %rdi
     af6:      	movl	$0x14, %r8d
     afc:      	callq	*%rax
     afe:      	movq	0x88(%rsp), %rax
     b06:      	cmpq	0xb0(%rsp), %rax
     b0e:      	jne	0xf1e <tail_icmp6_handle_ns+0x51e>
     b14:      	movq	0x90(%rsp), %rax
     b1c:      	cmpq	0xa8(%rsp), %rax
     b24:      	jne	0xf1e <tail_icmp6_handle_ns+0x51e>
     b2a:      	movabsq	$0xc000000088, %rax     # imm = 0xC000000088
     b34:      	movq	%rax, 0x38(%rsp)
     b39:      	movl	$0x1a, %eax
     b3e:      	leal	0x40(%r14), %esi
     b42:      	leaq	0x58(%rsp), %rdx
     b47:      	movq	%rbx, %rdi
     b4a:      	movl	%esi, 0x1c(%rsp)
     b4e:      	movl	$0x8, %ecx
     b53:      	callq	*%rax
     b55:      	xorl	%r12d, %r12d
     b58:      	testl	%eax, %eax
     b5a:      	js	0x143f <tail_icmp6_handle_ns+0xa3f>
     b60:      	movl	%r13d, 0x8(%rsp)
     b65:      	movl	$0x1a, %eax
     b6a:      	leal	0x28(%r14), %r13d
     b6e:      	leaq	0x50(%rsp), %rdx
     b73:      	movq	%rbx, %rdi
     b76:      	movl	%r13d, %esi
     b79:      	movl	$0x8, %ecx
     b7e:      	callq	*%rax
     b80:      	movl	%eax, %ecx
     b82:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
     b87:      	testl	%ecx, %ecx
     b89:      	js	0x1417 <tail_icmp6_handle_ns+0xa17>
     b8f:      	movzwl	0x52(%rsp), %eax
     b94:      	movw	%ax, 0x3a(%rsp)
     b99:      	movl	$0x1a, %eax
     b9e:      	leaq	0x98(%rsp), %rdx
     ba6:      	movq	%rbx, %rdi
     ba9:      	movl	%ebp, %esi
     bab:      	movl	$0x10, %ecx
     bb0:      	callq	*%rax
     bb2:      	testl	%eax, %eax
     bb4:      	js	0x1412 <tail_icmp6_handle_ns+0xa12>
     bba:      	movl	$0x9, %eax
     bbf:      	leaq	0x38(%rsp), %rdx
     bc4:      	movq	%rbx, %rdi
     bc7:      	movl	%r13d, %esi
     bca:      	movl	$0x8, %ecx
     bcf:      	xorl	%r8d, %r8d
     bd2:      	callq	*%rax
     bd4:      	testl	%eax, %eax
     bd6:      	js	0x1412 <tail_icmp6_handle_ns+0xa12>
     bdc:      	movl	$0x1c, %eax
     be1:      	leaq	0x50(%rsp), %rdi
     be6:      	leaq	0x38(%rsp), %rdx
     beb:      	movl	$0x8, %esi
     bf0:      	movl	$0x8, %ecx
     bf5:      	movl	%r12d, %r8d
     bf8:      	callq	*%rax
     bfa:      	movl	%eax, %r12d
     bfd:      	movl	$0x1a, %eax
     c02:      	leaq	0x58(%rsp), %rdx
     c07:      	movq	%rbx, %rdi
     c0a:      	movl	0x1c(%rsp), %esi
     c0e:      	movl	$0x8, %ecx
     c13:      	callq	*%rax
     c15:      	testl	%eax, %eax
     c17:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
     c1c:      	movl	0x8(%rsp), %r13d
     c21:      	js	0x141c <tail_icmp6_handle_ns+0xa1c>
     c27:      	movw	$0x102, 0x14(%rsp)      # imm = 0x102
     c2e:      	movzbl	(%rsp), %eax
     c32:      	movb	%al, 0x16(%rsp)
     c36:      	movzbl	0x13(%rsp), %eax
     c3b:      	movb	%al, 0x17(%rsp)
     c3f:      	movzbl	0x10(%rsp), %eax
     c44:      	movb	%al, 0x18(%rsp)
     c48:      	movzbl	0x12(%rsp), %eax
     c4d:      	movb	%al, 0x19(%rsp)
     c51:      	movzbl	0xc(%rsp), %eax
     c56:      	movb	%al, 0x1a(%rsp)
     c5a:      	movzbl	0x11(%rsp), %eax
     c5f:      	movb	%al, 0x1b(%rsp)
     c63:      	movl	$0x9, %eax
     c68:      	leaq	0x14(%rsp), %rdx
     c6d:      	movq	%rbx, %rdi
     c70:      	movl	0x1c(%rsp), %esi
     c74:      	movl	$0x8, %ecx
     c79:      	xorl	%r8d, %r8d
     c7c:      	callq	*%rax
     c7e:      	movl	%eax, %ecx
     c80:      	movl	$0xffffff73, %eax       # imm = 0xFFFFFF73
     c85:      	testl	%ecx, %ecx
     c87:      	js	0x141c <tail_icmp6_handle_ns+0xa1c>
     c8d:      	leal	0x2a(%r14), %ebp
     c91:      	movl	$0x1c, %eax
     c96:      	leaq	0x58(%rsp), %rdi
     c9b:      	leaq	0x14(%rsp), %rdx
     ca0:      	movl	$0x8, %esi
     ca5:      	movl	$0x8, %ecx
     caa:      	movl	%r12d, %r8d
     cad:      	callq	*%rax
     caf:      	movl	$0xb, %r9d
     cb5:      	movq	%rbx, %rdi
     cb8:      	movl	%ebp, %esi
     cba:      	xorl	%edx, %edx
     cbc:      	movl	%eax, %ecx
     cbe:      	movl	$0x10, %r8d
     cc4:      	callq	*%r9
     cc7:      	testl	%eax, %eax
     cc9:      	js	0x1525 <tail_icmp6_handle_ns+0xb25>
     ccf:      	movq	0x98(%rsp), %rax
     cd7:      	movq	0xa0(%rsp), %rcx
     cdf:      	movq	%rax, 0x40(%rsp)
     ce4:      	movq	%rcx, 0x48(%rsp)
     ce9:      	movq	(%r15), %rax
     cec:      	movq	%rax, 0x60(%rsp)
     cf1:      	movl	$0x1a, %eax
     cf6:      	leal	0x8(%r14), %r15d
     cfa:      	leaq	0x78(%rsp), %rdx
     cff:      	movq	%rbx, %rdi
     d02:      	movl	%r15d, %esi
     d05:      	movl	$0x10, %ecx
     d0a:      	callq	*%rax
     d0c:      	movl	%eax, %ecx
     d0e:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
     d13:      	testl	%ecx, %ecx
     d15:      	js	0x141c <tail_icmp6_handle_ns+0xa1c>
     d1b:      	movl	$0x1a, %eax
     d20:      	addl	$0x18, %r14d
     d24:      	leaq	0xb8(%rsp), %rdx
     d2c:      	movq	%rbx, %rdi
     d2f:      	movl	%r14d, %esi
     d32:      	movl	$0x10, %ecx
     d37:      	callq	*%rax
     d39:      	testl	%eax, %eax
     d3b:      	js	0x1539 <tail_icmp6_handle_ns+0xb39>
     d41:      	movl	$0x9, %eax
     d46:      	leaq	0x40(%rsp), %rdx
     d4b:      	movq	%rbx, %rdi
     d4e:      	movl	%r15d, %esi
     d51:      	movl	$0x10, %ecx
     d56:      	xorl	%r8d, %r8d
     d59:      	callq	*%rax
     d5b:      	testl	%eax, %eax
     d5d:      	js	0x152f <tail_icmp6_handle_ns+0xb2f>
     d63:      	movl	$0x9, %eax
     d68:      	leaq	0x78(%rsp), %rdx
     d6d:      	movq	%rbx, %rdi
     d70:      	movl	%r14d, %esi
     d73:      	movl	$0x10, %ecx
     d78:      	xorl	%r8d, %r8d
     d7b:      	callq	*%rax
     d7d:      	testl	%eax, %eax
     d7f:      	js	0x152f <tail_icmp6_handle_ns+0xb2f>
     d85:      	movl	$0x1c, %eax
     d8a:      	leaq	0x78(%rsp), %rdi
     d8f:      	leaq	0x40(%rsp), %rdx
     d94:      	movl	$0x10, %esi
     d99:      	movl	$0x10, %ecx
     d9e:      	xorl	%r8d, %r8d
     da1:      	callq	*%rax
     da3:      	movl	$0xb, %r14d
     da9:      	movq	%rbx, %rdi
     dac:      	movl	%ebp, %esi
     dae:      	xorl	%edx, %edx
     db0:      	movl	%eax, %ecx
     db2:      	movl	$0x10, %r8d
     db8:      	callq	*%r14
     dbb:      	movl	%eax, %ecx
     dbd:      	movl	$0xffffff66, %eax       # imm = 0xFFFFFF66
     dc2:      	testl	%ecx, %ecx
     dc4:      	js	0x141c <tail_icmp6_handle_ns+0xa1c>
     dca:      	movl	$0x1c, %eax
     dcf:      	leaq	0xb8(%rsp), %rdi
     dd7:      	leaq	0x78(%rsp), %rdx
     ddc:      	movl	$0x10, %esi
     de1:      	movl	$0x10, %ecx
     de6:      	xorl	%r8d, %r8d
     de9:      	callq	*%rax
     deb:      	movq	%rbx, %rdi
     dee:      	movl	%ebp, %esi
     df0:      	xorl	%edx, %edx
     df2:      	movl	%eax, %ecx
     df4:      	movl	$0x10, %r8d
     dfa:      	callq	*%r14
     dfd:      	movl	%eax, %ecx
     dff:      	movl	$0xffffff66, %eax       # imm = 0xFFFFFF66
     e04:      	testl	%ecx, %ecx
     e06:      	js	0x141c <tail_icmp6_handle_ns+0xa1c>
     e0c:      	movl	$0x1a, %eax
     e11:      	leaq	0x68(%rsp), %rdx
     e16:      	movq	%rbx, %rdi
     e19:      	movl	$0x6, %esi
     e1e:      	movl	$0x6, %ecx
     e23:      	callq	*%rax
     e25:      	movl	%eax, %ecx
     e27:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
     e2c:      	testl	%ecx, %ecx
     e2e:      	js	0x141c <tail_icmp6_handle_ns+0xa1c>
     e34:      	movl	$0x9, %eax
     e39:      	leaq	0x68(%rsp), %rdx
     e3e:      	movq	%rbx, %rdi
     e41:      	xorl	%esi, %esi
     e43:      	movl	$0x6, %ecx
     e48:      	xorl	%r8d, %r8d
     e4b:      	callq	*%rax
     e4d:      	testl	%eax, %eax
     e4f:      	js	0x152f <tail_icmp6_handle_ns+0xb2f>
     e55:      	movl	$0x9, %eax
     e5a:      	leaq	0x60(%rsp), %rdx
     e5f:      	xorl	%ebp, %ebp
     e61:      	movq	%rbx, %rdi
     e64:      	movl	$0x6, %esi
     e69:      	movl	$0x6, %ecx
     e6e:      	xorl	%r8d, %r8d
     e71:      	callq	*%rax
     e73:      	movl	%eax, %ecx
     e75:      	movl	$0xffffff73, %eax       # imm = 0xFFFFFF73
     e7a:      	testl	%ecx, %ecx
     e7c:      	js	0x141c <tail_icmp6_handle_ns+0xa1c>
     e82:      	movq	0x10(%rbx), %rax
     e86:      	testq	%rax, %rax
     e89:      	je	0xe91 <tail_icmp6_handle_ns+0x491>
     e8b:      	movl	0xe0(%rax), %ebp
     e91:      	movl	0x70(%rbx), %eax
     e94:      	movq	(%rip), %rcx            # 0xe9b <tail_icmp6_handle_ns+0x49b>
     e9b:      	movl	(%rcx), %edx
     e9d:      	cmpl	%edx, %eax
     e9f:      	movw	$0x403, 0x20(%rsp)      # imm = 0x403
     ea6:      	movq	(%rip), %rcx            # 0xead <tail_icmp6_handle_ns+0x4ad>
     ead:      	movzwl	(%rcx), %ecx
     eb0:      	movw	%cx, 0x22(%rsp)
     eb5:      	cmovbl	%eax, %edx
     eb8:      	movl	0x98(%rbx), %ecx
     ebe:      	movl	%ecx, 0x24(%rsp)
     ec2:      	movl	%eax, 0x28(%rsp)
     ec6:      	movw	%dx, 0x2c(%rsp)
     ecb:      	movw	$0x1, 0x2e(%rsp)
     ed2:      	movl	%ebp, 0x30(%rsp)
     ed6:      	movl	$0x0, 0x34(%rsp)
     ede:      	movl	$0x19, %eax
     ee3:      	shlq	$0x20, %rdx
     ee7:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     eec:      	orq	%rcx, %rdx
     eef:      	movq	(%rip), %rsi            # 0xef6 <tail_icmp6_handle_ns+0x4f6>
     ef6:      	leaq	0x20(%rsp), %rcx
     efb:      	movq	%rbx, %rdi
     efe:      	movl	$0x18, %r8d
     f04:      	callq	*%rax
     f06:      	movq	0x10(%rbx), %rax
     f0a:      	testq	%rax, %rax
     f0d:      	je	0x1543 <tail_icmp6_handle_ns+0xb43>
     f13:      	movl	0xe0(%rax), %edi
     f19:      	jmp	0x1545 <tail_icmp6_handle_ns+0xb45>
     f1e:      	movl	$0x0, 0x30(%rsp)
     f26:      	movq	0x88(%rsp), %rax
     f2e:      	movq	0x90(%rsp), %rcx
     f36:      	movq	%rax, 0x20(%rsp)
     f3b:      	movq	%rcx, 0x28(%rsp)
     f40:      	movb	$0x2, 0x30(%rsp)
     f45:      	movl	$0x1, %eax
     f4a:      	movq	(%rip), %rdi            # 0xf51 <tail_icmp6_handle_ns+0x551>
     f51:      	leaq	0x20(%rsp), %rsi
     f56:      	callq	*%rax
     f58:      	movq	%rax, %rcx
     f5b:      	xorl	%eax, %eax
     f5d:      	testq	%rcx, %rcx
     f60:      	je	0x141c <tail_icmp6_handle_ns+0xa1c>
     f66:      	testb	$0x1, 0x8(%rcx)
     f6a:      	jne	0x141c <tail_icmp6_handle_ns+0xa1c>
     f70:      	movabsq	$0x6000000088, %rax     # imm = 0x6000000088
     f7a:      	movq	%rax, 0x38(%rsp)
     f7f:      	movl	$0x1a, %eax
     f84:      	leal	0x40(%r14), %esi
     f88:      	leaq	0x58(%rsp), %rdx
     f8d:      	movq	%rbx, %rdi
     f90:      	movl	%esi, 0x1c(%rsp)
     f94:      	movl	$0x8, %ecx
     f99:      	callq	*%rax
     f9b:      	xorl	%r12d, %r12d
     f9e:      	testl	%eax, %eax
     fa0:      	js	0x14ac <tail_icmp6_handle_ns+0xaac>
     fa6:      	movl	%r13d, 0x8(%rsp)
     fab:      	movl	$0x1a, %eax
     fb0:      	leal	0x28(%r14), %r13d
     fb4:      	leaq	0x50(%rsp), %rdx
     fb9:      	movq	%rbx, %rdi
     fbc:      	movl	%r13d, %esi
     fbf:      	movl	$0x8, %ecx
     fc4:      	callq	*%rax
     fc6:      	movl	%eax, %ecx
     fc8:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
     fcd:      	testl	%ecx, %ecx
     fcf:      	js	0x1417 <tail_icmp6_handle_ns+0xa17>
     fd5:      	movzwl	0x52(%rsp), %eax
     fda:      	movw	%ax, 0x3a(%rsp)
     fdf:      	movl	$0x1a, %eax
     fe4:      	leaq	0x98(%rsp), %rdx
     fec:      	movq	%rbx, %rdi
     fef:      	movl	%ebp, %esi
     ff1:      	movl	$0x10, %ecx
     ff6:      	callq	*%rax
     ff8:      	testl	%eax, %eax
     ffa:      	js	0x1412 <tail_icmp6_handle_ns+0xa12>
    1000:      	movl	$0x9, %eax
    1005:      	leaq	0x38(%rsp), %rdx
    100a:      	movq	%rbx, %rdi
    100d:      	movl	%r13d, %esi
    1010:      	movl	$0x8, %ecx
    1015:      	xorl	%r8d, %r8d
    1018:      	callq	*%rax
    101a:      	testl	%eax, %eax
    101c:      	js	0x1412 <tail_icmp6_handle_ns+0xa12>
    1022:      	movl	$0x1c, %eax
    1027:      	leaq	0x50(%rsp), %rdi
    102c:      	leaq	0x38(%rsp), %rdx
    1031:      	movl	$0x8, %esi
    1036:      	movl	$0x8, %ecx
    103b:      	movl	%r12d, %r8d
    103e:      	callq	*%rax
    1040:      	movl	%eax, %r12d
    1043:      	movl	$0x1a, %eax
    1048:      	leaq	0x58(%rsp), %rdx
    104d:      	movq	%rbx, %rdi
    1050:      	movl	0x1c(%rsp), %esi
    1054:      	movl	$0x8, %ecx
    1059:      	callq	*%rax
    105b:      	testl	%eax, %eax
    105d:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
    1062:      	movl	0x8(%rsp), %r13d
    1067:      	js	0x141c <tail_icmp6_handle_ns+0xa1c>
    106d:      	movw	$0x102, 0x14(%rsp)      # imm = 0x102
    1074:      	movzbl	(%rsp), %eax
    1078:      	movb	%al, 0x16(%rsp)
    107c:      	movzbl	0x13(%rsp), %eax
    1081:      	movb	%al, 0x17(%rsp)
    1085:      	movzbl	0x10(%rsp), %eax
    108a:      	movb	%al, 0x18(%rsp)
    108e:      	movzbl	0x12(%rsp), %eax
    1093:      	movb	%al, 0x19(%rsp)
    1097:      	movzbl	0xc(%rsp), %eax
    109c:      	movb	%al, 0x1a(%rsp)
    10a0:      	movzbl	0x11(%rsp), %eax
    10a5:      	movb	%al, 0x1b(%rsp)
    10a9:      	movl	$0x9, %eax
    10ae:      	leaq	0x14(%rsp), %rdx
    10b3:      	movq	%rbx, %rdi
    10b6:      	movl	0x1c(%rsp), %esi
    10ba:      	movl	$0x8, %ecx
    10bf:      	xorl	%r8d, %r8d
    10c2:      	callq	*%rax
    10c4:      	movl	%eax, %ecx
    10c6:      	movl	$0xffffff73, %eax       # imm = 0xFFFFFF73
    10cb:      	testl	%ecx, %ecx
    10cd:      	js	0x141c <tail_icmp6_handle_ns+0xa1c>
    10d3:      	leal	0x2a(%r14), %ebp
    10d7:      	movl	$0x1c, %eax
    10dc:      	leaq	0x58(%rsp), %rdi
    10e1:      	leaq	0x14(%rsp), %rdx
    10e6:      	movl	$0x8, %esi
    10eb:      	movl	$0x8, %ecx
    10f0:      	movl	%r12d, %r8d
    10f3:      	callq	*%rax
    10f5:      	movl	$0xb, %r9d
    10fb:      	movq	%rbx, %rdi
    10fe:      	movl	%ebp, %esi
    1100:      	xorl	%edx, %edx
    1102:      	movl	%eax, %ecx
    1104:      	movl	$0x10, %r8d
    110a:      	callq	*%r9
    110d:      	testl	%eax, %eax
    110f:      	js	0x1525 <tail_icmp6_handle_ns+0xb25>
    1115:      	movq	0x98(%rsp), %rax
    111d:      	movq	0xa0(%rsp), %rcx
    1125:      	movq	%rax, 0x40(%rsp)
    112a:      	movq	%rcx, 0x48(%rsp)
    112f:      	movq	(%r15), %rax
    1132:      	movq	%rax, 0x60(%rsp)
    1137:      	movl	$0x1a, %eax
    113c:      	leal	0x8(%r14), %r15d
    1140:      	leaq	0x78(%rsp), %rdx
    1145:      	movq	%rbx, %rdi
    1148:      	movl	%r15d, %esi
    114b:      	movl	$0x10, %ecx
    1150:      	callq	*%rax
    1152:      	movl	%eax, %ecx
    1154:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
    1159:      	testl	%ecx, %ecx
    115b:      	js	0x141c <tail_icmp6_handle_ns+0xa1c>
    1161:      	movl	$0x1a, %eax
    1166:      	addl	$0x18, %r14d
    116a:      	leaq	0xb8(%rsp), %rdx
    1172:      	movq	%rbx, %rdi
    1175:      	movl	%r14d, %esi
    1178:      	movl	$0x10, %ecx
    117d:      	callq	*%rax
    117f:      	testl	%eax, %eax
    1181:      	js	0x1539 <tail_icmp6_handle_ns+0xb39>
    1187:      	movl	$0x9, %eax
    118c:      	leaq	0x40(%rsp), %rdx
    1191:      	movq	%rbx, %rdi
    1194:      	movl	%r15d, %esi
    1197:      	movl	$0x10, %ecx
    119c:      	xorl	%r8d, %r8d
    119f:      	callq	*%rax
    11a1:      	testl	%eax, %eax
    11a3:      	js	0x152f <tail_icmp6_handle_ns+0xb2f>
    11a9:      	movl	$0x9, %eax
    11ae:      	leaq	0x78(%rsp), %rdx
    11b3:      	movq	%rbx, %rdi
    11b6:      	movl	%r14d, %esi
    11b9:      	movl	$0x10, %ecx
    11be:      	xorl	%r8d, %r8d
    11c1:      	callq	*%rax
    11c3:      	testl	%eax, %eax
    11c5:      	js	0x152f <tail_icmp6_handle_ns+0xb2f>
    11cb:      	movl	$0x1c, %eax
    11d0:      	leaq	0x78(%rsp), %rdi
    11d5:      	leaq	0x40(%rsp), %rdx
    11da:      	movl	$0x10, %esi
    11df:      	movl	$0x10, %ecx
    11e4:      	xorl	%r8d, %r8d
    11e7:      	callq	*%rax
    11e9:      	movl	$0xb, %r14d
    11ef:      	movq	%rbx, %rdi
    11f2:      	movl	%ebp, %esi
    11f4:      	xorl	%edx, %edx
    11f6:      	movl	%eax, %ecx
    11f8:      	movl	$0x10, %r8d
    11fe:      	callq	*%r14
    1201:      	movl	%eax, %ecx
    1203:      	movl	$0xffffff66, %eax       # imm = 0xFFFFFF66
    1208:      	testl	%ecx, %ecx
    120a:      	js	0x141c <tail_icmp6_handle_ns+0xa1c>
    1210:      	movl	$0x1c, %eax
    1215:      	leaq	0xb8(%rsp), %rdi
    121d:      	leaq	0x78(%rsp), %rdx
    1222:      	movl	$0x10, %esi
    1227:      	movl	$0x10, %ecx
    122c:      	xorl	%r8d, %r8d
    122f:      	callq	*%rax
    1231:      	movq	%rbx, %rdi
    1234:      	movl	%ebp, %esi
    1236:      	xorl	%edx, %edx
    1238:      	movl	%eax, %ecx
    123a:      	movl	$0x10, %r8d
    1240:      	callq	*%r14
    1243:      	movl	%eax, %ecx
    1245:      	movl	$0xffffff66, %eax       # imm = 0xFFFFFF66
    124a:      	testl	%ecx, %ecx
    124c:      	js	0x141c <tail_icmp6_handle_ns+0xa1c>
    1252:      	movl	$0x1a, %eax
    1257:      	leaq	0x68(%rsp), %rdx
    125c:      	movq	%rbx, %rdi
    125f:      	movl	$0x6, %esi
    1264:      	movl	$0x6, %ecx
    1269:      	callq	*%rax
    126b:      	movl	%eax, %ecx
    126d:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
    1272:      	testl	%ecx, %ecx
    1274:      	js	0x141c <tail_icmp6_handle_ns+0xa1c>
    127a:      	movl	$0x9, %eax
    127f:      	leaq	0x68(%rsp), %rdx
    1284:      	movq	%rbx, %rdi
    1287:      	xorl	%esi, %esi
    1289:      	movl	$0x6, %ecx
    128e:      	xorl	%r8d, %r8d
    1291:      	callq	*%rax
    1293:      	testl	%eax, %eax
    1295:      	js	0x152f <tail_icmp6_handle_ns+0xb2f>
    129b:      	movl	$0x9, %eax
    12a0:      	leaq	0x60(%rsp), %rdx
    12a5:      	xorl	%ebp, %ebp
    12a7:      	movq	%rbx, %rdi
    12aa:      	movl	$0x6, %esi
    12af:      	movl	$0x6, %ecx
    12b4:      	xorl	%r8d, %r8d
    12b7:      	callq	*%rax
    12b9:      	movl	%eax, %ecx
    12bb:      	movl	$0xffffff73, %eax       # imm = 0xFFFFFF73
    12c0:      	testl	%ecx, %ecx
    12c2:      	js	0x141c <tail_icmp6_handle_ns+0xa1c>
    12c8:      	movq	0x10(%rbx), %rax
    12cc:      	testq	%rax, %rax
    12cf:      	je	0x12d7 <tail_icmp6_handle_ns+0x8d7>
    12d1:      	movl	0xe0(%rax), %ebp
    12d7:      	movl	0x70(%rbx), %eax
    12da:      	movq	(%rip), %rcx            # 0x12e1 <tail_icmp6_handle_ns+0x8e1>
    12e1:      	movl	(%rcx), %edx
    12e3:      	cmpl	%edx, %eax
    12e5:      	movw	$0x403, 0x20(%rsp)      # imm = 0x403
    12ec:      	movq	(%rip), %rcx            # 0x12f3 <tail_icmp6_handle_ns+0x8f3>
    12f3:      	movzwl	(%rcx), %ecx
    12f6:      	movw	%cx, 0x22(%rsp)
    12fb:      	cmovbl	%eax, %edx
    12fe:      	movl	0x98(%rbx), %ecx
    1304:      	movl	%ecx, 0x24(%rsp)
    1308:      	movl	%eax, 0x28(%rsp)
    130c:      	movw	%dx, 0x2c(%rsp)
    1311:      	movw	$0x1, 0x2e(%rsp)
    1318:      	movl	%ebp, 0x30(%rsp)
    131c:      	movl	$0x0, 0x34(%rsp)
    1324:      	movl	$0x19, %eax
    1329:      	shlq	$0x20, %rdx
    132d:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    1332:      	orq	%rcx, %rdx
    1335:      	movq	(%rip), %rsi            # 0x133c <tail_icmp6_handle_ns+0x93c>
    133c:      	leaq	0x20(%rsp), %rcx
    1341:      	movq	%rbx, %rdi
    1344:      	movl	$0x18, %r8d
    134a:      	callq	*%rax
    134c:      	movq	0x10(%rbx), %rax
    1350:      	testq	%rax, %rax
    1353:      	je	0x154c <tail_icmp6_handle_ns+0xb4c>
    1359:      	movl	0xe0(%rax), %edi
    135f:      	jmp	0x154e <tail_icmp6_handle_ns+0xb4e>
    1364:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
    1369:      	movl	%eax, %ecx
    136b:      	negl	%ecx
    136d:      	cmovsl	%eax, %ecx
    1370:      	movq	$0x0, 0x30(%rbx)
    1378:      	movzbl	%cl, %eax
    137b:      	movl	%eax, 0x38(%rbx)
    137e:      	movabsq	$0x196670200000000, %rcx # imm = 0x196670200000000
    1388:      	movq	%rcx, 0x3c(%rbx)
    138c:      	movl	0x70(%rbx), %r14d
    1390:      	movabsq	$0x6701960000, %rcx     # imm = 0x6701960000
    139a:      	movq	%rcx, 0x40(%rsp)
    139f:      	movb	%al, 0x40(%rsp)
    13a3:      	andb	$0x3, %r13b
    13a7:      	movb	%r13b, 0x41(%rsp)
    13ac:      	movl	$0x1, %eax
    13b1:      	movq	(%rip), %rdi            # 0x13b8 <tail_icmp6_handle_ns+0x9b8>
    13b8:      	leaq	0x40(%rsp), %rsi
    13bd:      	callq	*%rax
    13bf:      	testq	%rax, %rax
    13c2:      	je	0x13cd <tail_icmp6_handle_ns+0x9cd>
    13c4:      	incq	(%rax)
    13c7:      	addq	%r14, 0x8(%rax)
    13cb:      	jmp	0x13f5 <tail_icmp6_handle_ns+0x9f5>
    13cd:      	movq	$0x1, 0x20(%rsp)
    13d6:      	movq	%r14, 0x28(%rsp)
    13db:      	movl	$0x2, %eax
    13e0:      	movq	(%rip), %rdi            # 0x13e7 <tail_icmp6_handle_ns+0x9e7>
    13e7:      	leaq	0x40(%rsp), %rsi
    13ec:      	leaq	0x20(%rsp), %rdx
    13f1:      	xorl	%ecx, %ecx
    13f3:      	callq	*%rax
    13f5:      	movl	$0xc, %eax
    13fa:      	movq	(%rip), %rsi            # 0x1401 <tail_icmp6_handle_ns+0xa01>
    1401:      	movq	%rbx, %rdi
    1404:      	movl	$0x1, %edx
    1409:      	callq	*%rax
    140b:      	movl	$0x2, %eax
    1410:      	jmp	0x142d <tail_icmp6_handle_ns+0xa2d>
    1412:      	movl	$0xffffff73, %eax       # imm = 0xFFFFFF73
    1417:      	movl	0x8(%rsp), %r13d
    141c:      	testl	%eax, %eax
    141e:      	js	0x1369 <tail_icmp6_handle_ns+0x969>
    1424:      	cmpl	$0x2, %eax
    1427:      	je	0x1369 <tail_icmp6_handle_ns+0x969>
    142d:      	addq	$0xc8, %rsp
    1434:      	popq	%rbx
    1435:      	popq	%r12
    1437:      	popq	%r13
    1439:      	popq	%r14
    143b:      	popq	%r15
    143d:      	popq	%rbp
    143e:      	retq
    143f:      	movl	$0x26, %eax
    1444:      	movl	0x70(%rbx), %esi
    1447:      	addl	$0x8, %esi
    144a:      	movq	%rbx, %rdi
    144d:      	xorl	%edx, %edx
    144f:      	callq	*%rax
    1451:      	movl	%eax, %ecx
    1453:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
    1458:      	testl	%ecx, %ecx
    145a:      	js	0x141c <tail_icmp6_handle_ns+0xa1c>
    145c:      	movq	(%rip), %rcx            # 0x1463 <tail_icmp6_handle_ns+0xa63>
    1463:      	movzbl	(%rcx), %esi
    1466:      	movq	0x50(%rbx), %rdx
    146a:      	movq	0xd0(%rbx), %rcx
    1471:      	leaq	(%rcx,%rsi), %rdi
    1475:      	addq	$0x28, %rdi
    1479:      	cmpq	%rdx, %rdi
    147c:      	ja	0x141c <tail_icmp6_handle_ns+0xa1c>
    147e:      	addq	%rsi, %rcx
    1481:      	movbew	0x4(%rcx), %si
    1487:      	addl	$0x8, %esi
    148a:      	movbew	%si, 0x4(%rcx)
    1490:      	leaq	0x48(%rcx), %rsi
    1494:      	cmpq	%rdx, %rsi
    1497:      	ja	0x141c <tail_icmp6_handle_ns+0xa1c>
    1499:      	movq	$0x0, 0x40(%rcx)
    14a1:      	movl	$0x8000000, %r12d       # imm = 0x8000000
    14a7:      	jmp	0xb60 <tail_icmp6_handle_ns+0x160>
    14ac:      	movl	$0x26, %eax
    14b1:      	movl	0x70(%rbx), %esi
    14b4:      	addl	$0x8, %esi
    14b7:      	movq	%rbx, %rdi
    14ba:      	xorl	%edx, %edx
    14bc:      	callq	*%rax
    14be:      	movl	%eax, %ecx
    14c0:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
    14c5:      	testl	%ecx, %ecx
    14c7:      	js	0x141c <tail_icmp6_handle_ns+0xa1c>
    14cd:      	movq	(%rip), %rcx            # 0x14d4 <tail_icmp6_handle_ns+0xad4>
    14d4:      	movzbl	(%rcx), %esi
    14d7:      	movq	0x50(%rbx), %rdx
    14db:      	movq	0xd0(%rbx), %rcx
    14e2:      	leaq	(%rcx,%rsi), %rdi
    14e6:      	addq	$0x28, %rdi
    14ea:      	cmpq	%rdx, %rdi
    14ed:      	ja	0x141c <tail_icmp6_handle_ns+0xa1c>
    14f3:      	addq	%rsi, %rcx
    14f6:      	movbew	0x4(%rcx), %si
    14fc:      	addl	$0x8, %esi
    14ff:      	movbew	%si, 0x4(%rcx)
    1505:      	leaq	0x48(%rcx), %rsi
    1509:      	cmpq	%rdx, %rsi
    150c:      	ja	0x141c <tail_icmp6_handle_ns+0xa1c>
    1512:      	movq	$0x0, 0x40(%rcx)
    151a:      	movl	$0x8000000, %r12d       # imm = 0x8000000
    1520:      	jmp	0xfa6 <tail_icmp6_handle_ns+0x5a6>
    1525:      	movl	$0xffffff66, %eax       # imm = 0xFFFFFF66
    152a:      	jmp	0x141c <tail_icmp6_handle_ns+0xa1c>
    152f:      	movl	$0xffffff73, %eax       # imm = 0xFFFFFF73
    1534:      	jmp	0x141c <tail_icmp6_handle_ns+0xa1c>
    1539:      	movl	$0xffffff7a, %eax       # imm = 0xFFFFFF7A
    153e:      	jmp	0x141c <tail_icmp6_handle_ns+0xa1c>
    1543:      	xorl	%edi, %edi
    1545:      	movl	$0x17, %eax
    154a:      	jmp	0x1553 <tail_icmp6_handle_ns+0xb53>
    154c:      	xorl	%edi, %edi
    154e:      	movl	$0x17, %eax
    1553:      	xorl	%esi, %esi
    1555:      	callq	*%rax
    1557:      	jmp	0x1417 <tail_icmp6_handle_ns+0xa17>

Disassembly of section tc/entry:

0000000000000000 <cil_from_netdev>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x28, %rsp
       e:      	movq	%rdi, %rbx
      11:      	movl	$0x0, 0x30(%rdi)
      18:      	movl	$0x0, 0x34(%rdi)
      1f:      	movl	$0x0, 0x38(%rdi)
      26:      	movl	$0x0, 0x3c(%rdi)
      2d:      	movl	$0x0, 0x40(%rdi)
      34:      	movq	(%rip), %r15            # 0x3b <cil_from_netdev+0x3b>
      3b:      	cmpb	$0x0, (%r15)
      3f:      	je	0xc5 <cil_from_netdev+0xc5>
      45:      	movzbl	(%r15), %ebp
      49:      	movq	0x50(%rbx), %rdx
      4d:      	movq	(%rip), %rax            # 0x54 <cil_from_netdev+0x54>
      54:      	movzbl	(%rax), %esi
      57:      	movq	0xd0(%rbx), %rcx
      5e:      	cmpb	$0x0, (%rax)
      61:      	je	0x7d <cil_from_netdev+0x7d>
      63:      	addq	%rcx, %rsi
      66:      	cmpq	%rdx, %rsi
      69:      	ja	0x9e <cil_from_netdev+0x9e>
      6b:      	movzwl	0xc(%rcx), %esi
      6f:      	cmpw	$0x6, %si
      73:      	jb	0x9e <cil_from_netdev+0x9e>
      75:      	cmpw	$0x8, %si
      79:      	je	0x8a <cil_from_netdev+0x8a>
      7b:      	jmp	0x9e <cil_from_netdev+0x9e>
      7d:      	movzwl	0xb4(%rbx), %esi
      84:      	cmpw	$0x8, %si
      88:      	jne	0x9e <cil_from_netdev+0x9e>
      8a:      	movzbl	(%rax), %esi
      8d:      	leaq	(%rcx,%rsi), %rdi
      91:      	addq	$0x14, %rdi
      95:      	cmpq	%rdx, %rdi
      98:      	jbe	0x22c <cil_from_netdev+0x22c>
      9e:      	movl	$0x0, 0x18(%rsp)
      a6:      	movl	$0x1, %eax
      ab:      	movq	(%rip), %rdi            # 0xb2 <cil_from_netdev+0xb2>
      b2:      	leaq	0x18(%rsp), %rsi
      b7:      	callq	*%rax
      b9:      	testq	%rax, %rax
      bc:      	je	0xc5 <cil_from_netdev+0xc5>
      be:      	movq	$0x0, (%rax)
      c5:      	movl	0x9c(%rbx), %ecx
      cb:      	testl	%ecx, %ecx
      cd:      	je	0x115 <cil_from_netdev+0x115>
      cf:      	testl	$0xfff0000, %ecx        # imm = 0xFFF0000
      d5:      	je	0x115 <cil_from_netdev+0x115>
      d7:      	movq	0x10(%rbx), %rax
      db:      	testq	%rax, %rax
      de:      	je	0x2b0 <cil_from_netdev+0x2b0>
      e4:      	movl	0xe0(%rax), %eax
      ea:      	cmpl	$0x75, %eax
      ed:      	je	0x296 <cil_from_netdev+0x296>
      f3:      	cmpl	$0x74, %eax
      f6:      	jne	0x2b0 <cil_from_netdev+0x2b0>
      fc:      	andl	$0xffe0000, %ecx        # imm = 0xFFE0000
     102:      	xorl	%eax, %eax
     104:      	cmpl	$0xfa00000, %ecx        # imm = 0xFA00000
     10a:      	jne	0x2b0 <cil_from_netdev+0x2b0>
     110:      	jmp	0x344 <cil_from_netdev+0x344>
     115:      	movabsq	$0x1047e0103, %r14      # imm = 0x1047E0103
     11f:      	movq	0x50(%rbx), %rcx
     123:      	movq	(%rip), %rsi            # 0x12a <cil_from_netdev+0x12a>
     12a:      	movzbl	(%rsi), %edx
     12d:      	movq	0xd0(%rbx), %rax
     134:      	cmpb	$0x0, (%rsi)
     137:      	je	0x148 <cil_from_netdev+0x148>
     139:      	addq	%rax, %rdx
     13c:      	cmpq	%rcx, %rdx
     13f:      	ja	0x1a7 <cil_from_netdev+0x1a7>
     141:      	cmpw	$0x5, 0xc(%rax)
     146:      	jbe	0x1a7 <cil_from_netdev+0x1a7>
     148:      	movq	(%rip), %rax            # 0x14f <cil_from_netdev+0x14f>
     14f:      	movl	(%rax), %eax
     151:      	cmpb	$0x0, (%r15)
     155:      	je	0x172 <cil_from_netdev+0x172>
     157:      	movl	$0x0, 0x18(%rsp)
     15f:      	movl	$0x1, %eax
     164:      	movq	(%rip), %rdi            # 0x16b <cil_from_netdev+0x16b>
     16b:      	leaq	0x18(%rsp), %rsi
     170:      	callq	*%rax
     172:      	movl	0x70(%rbx), %ebx
     175:      	movq	%r14, 0x10(%rsp)
     17a:      	movl	$0x1, %eax
     17f:      	movq	(%rip), %rdi            # 0x186 <cil_from_netdev+0x186>
     186:      	leaq	0x10(%rsp), %rsi
     18b:      	callq	*%rax
     18d:      	testq	%rax, %rax
     190:      	jne	0x1ef <cil_from_netdev+0x1ef>
     192:      	movq	$0x1, 0x18(%rsp)
     19b:      	movq	%rbx, 0x20(%rsp)
     1a0:      	movl	$0x2, %eax
     1a5:      	jmp	0x210 <cil_from_netdev+0x210>
     1a7:      	cmpb	$0x0, (%r15)
     1ab:      	je	0x1c8 <cil_from_netdev+0x1c8>
     1ad:      	movl	$0x0, 0x18(%rsp)
     1b5:      	movl	$0x1, %eax
     1ba:      	movq	(%rip), %rdi            # 0x1c1 <cil_from_netdev+0x1c1>
     1c1:      	leaq	0x18(%rsp), %rsi
     1c6:      	callq	*%rax
     1c8:      	movl	0x70(%rbx), %ebx
     1cb:      	addq	$0x4700fd, %r14         # imm = 0x4700FD
     1d2:      	movq	%r14, 0x10(%rsp)
     1d7:      	movl	$0x1, %eax
     1dc:      	movq	(%rip), %rdi            # 0x1e3 <cil_from_netdev+0x1e3>
     1e3:      	leaq	0x10(%rsp), %rsi
     1e8:      	callq	*%rax
     1ea:      	testq	%rax, %rax
     1ed:      	je	0x1fd <cil_from_netdev+0x1fd>
     1ef:      	incq	(%rax)
     1f2:      	addq	%rbx, 0x8(%rax)
     1f6:      	xorl	%eax, %eax
     1f8:      	jmp	0x344 <cil_from_netdev+0x344>
     1fd:      	movq	$0x1, 0x18(%rsp)
     206:      	movq	%rbx, 0x20(%rsp)
     20b:      	movl	$0x2, %eax
     210:      	movq	(%rip), %rdi            # 0x217 <cil_from_netdev+0x217>
     217:      	leaq	0x10(%rsp), %rsi
     21c:      	leaq	0x18(%rsp), %rdx
     221:      	xorl	%ecx, %ecx
     223:      	callq	*%rax
     225:      	xorl	%eax, %eax
     227:      	jmp	0x344 <cil_from_netdev+0x344>
     22c:      	addq	%rsi, %rcx
     22f:      	movzbl	(%rcx), %r12d
     233:      	movl	%r12d, %ecx
     236:      	andb	$0xe, %cl
     239:      	cmpb	$0x6, %cl
     23c:      	jb	0x49b <cil_from_netdev+0x49b>
     242:      	movzbl	(%rax), %r13d
     246:      	shll	$0x2, %r12d
     24a:      	andl	$0x3c, %r12d
     24e:      	je	0x49b <cil_from_netdev+0x49b>
     254:      	leal	0x14(%r13), %r14d
     258:      	movl	$0x1a, %eax
     25d:      	leaq	0x10(%rsp), %rdx
     262:      	movq	%rbx, %rdi
     265:      	movl	%r14d, %esi
     268:      	movl	$0x1, %ecx
     26d:      	callq	*%rax
     26f:      	testl	%eax, %eax
     271:      	js	0x9e <cil_from_netdev+0x9e>
     277:      	movzbl	0x10(%rsp), %eax
     27c:      	testl	%eax, %eax
     27e:      	je	0x49b <cil_from_netdev+0x49b>
     284:      	cmpl	$0x1, %eax
     287:      	jne	0x353 <cil_from_netdev+0x353>
     28d:      	leal	0x15(%r13), %r14d
     291:      	jmp	0x3d1 <cil_from_netdev+0x3d1>
     296:      	shrl	$0x10, %ecx
     299:      	andl	$0xfff, %ecx            # imm = 0xFFF
     29f:      	addl	$0xfffff05d, %ecx       # imm = 0xFFFFF05D
     2a5:      	xorl	%eax, %eax
     2a7:      	cmpl	$0x3, %ecx
     2aa:      	jb	0x344 <cil_from_netdev+0x344>
     2b0:      	movq	$0x0, 0x30(%rbx)
     2b8:      	movq	$0xb6, 0x38(%rbx)
     2c0:      	movl	$0x4e00102, 0x40(%rbx)  # imm = 0x4E00102
     2c7:      	movl	0x70(%rbx), %r14d
     2cb:      	movabsq	$0x1047e0103, %rax      # imm = 0x1047E0103
     2d5:      	addq	$0x6200b3, %rax         # imm = 0x6200B3
     2db:      	movq	%rax, 0x10(%rsp)
     2e0:      	movl	$0x1, %eax
     2e5:      	movq	(%rip), %rdi            # 0x2ec <cil_from_netdev+0x2ec>
     2ec:      	leaq	0x10(%rsp), %rsi
     2f1:      	callq	*%rax
     2f3:      	testq	%rax, %rax
     2f6:      	je	0x301 <cil_from_netdev+0x301>
     2f8:      	incq	(%rax)
     2fb:      	addq	%r14, 0x8(%rax)
     2ff:      	jmp	0x329 <cil_from_netdev+0x329>
     301:      	movq	$0x1, 0x18(%rsp)
     30a:      	movq	%r14, 0x20(%rsp)
     30f:      	movl	$0x2, %eax
     314:      	movq	(%rip), %rdi            # 0x31b <cil_from_netdev+0x31b>
     31b:      	leaq	0x10(%rsp), %rsi
     320:      	leaq	0x18(%rsp), %rdx
     325:      	xorl	%ecx, %ecx
     327:      	callq	*%rax
     329:      	movl	$0xc, %eax
     32e:      	movq	(%rip), %rsi            # 0x335 <cil_from_netdev+0x335>
     335:      	movq	%rbx, %rdi
     338:      	movl	$0x1, %edx
     33d:      	callq	*%rax
     33f:      	movl	$0x2, %eax
     344:      	addq	$0x28, %rsp
     348:      	popq	%rbx
     349:      	popq	%r12
     34b:      	popq	%r13
     34d:      	popq	%r14
     34f:      	popq	%r15
     351:      	popq	%rbp
     352:      	retq
     353:      	movl	$0x1a, %eax
     358:      	leal	0x15(%r13), %esi
     35c:      	leaq	0xf(%rsp), %rdx
     361:      	movq	%rbx, %rdi
     364:      	movl	$0x1, %ecx
     369:      	callq	*%rax
     36b:      	testl	%eax, %eax
     36d:      	js	0x9e <cil_from_netdev+0x9e>
     373:      	cmpb	%bpl, 0x10(%rsp)
     378:      	jne	0x3c9 <cil_from_netdev+0x3c9>
     37a:      	movzbl	0xf(%rsp), %eax
     37f:      	cmpl	$0xa, %eax
     382:      	je	0x4f6 <cil_from_netdev+0x4f6>
     388:      	cmpl	$0x6, %eax
     38b:      	je	0x4ca <cil_from_netdev+0x4ca>
     391:      	cmpl	$0x4, %eax
     394:      	jne	0x9e <cil_from_netdev+0x9e>
     39a:      	movl	$0x1a, %eax
     39f:      	addl	$0x2, %r14d
     3a3:      	leaq	0x18(%rsp), %rdx
     3a8:      	movq	%rbx, %rdi
     3ab:      	movl	%r14d, %esi
     3ae:      	movl	$0x2, %ecx
     3b3:      	callq	*%rax
     3b5:      	xorl	%r14d, %r14d
     3b8:      	testl	%eax, %eax
     3ba:      	movbew	0x18(%rsp), %cx
     3c1:      	movzwl	%cx, %ecx
     3c4:      	jmp	0x51d <cil_from_netdev+0x51d>
     3c9:      	movzbl	0xf(%rsp), %eax
     3ce:      	addl	%eax, %r14d
     3d1:      	addl	%r13d, %r12d
     3d4:      	addl	$0x14, %r12d
     3d8:      	cmpl	%r12d, %r14d
     3db:      	jae	0x49b <cil_from_netdev+0x49b>
     3e1:      	movl	$0x1a, %eax
     3e6:      	leaq	0x10(%rsp), %rdx
     3eb:      	movq	%rbx, %rdi
     3ee:      	movl	%r14d, %esi
     3f1:      	movl	$0x1, %ecx
     3f6:      	callq	*%rax
     3f8:      	testl	%eax, %eax
     3fa:      	js	0x9e <cil_from_netdev+0x9e>
     400:      	movzbl	0x10(%rsp), %eax
     405:      	testl	%eax, %eax
     407:      	je	0x49b <cil_from_netdev+0x49b>
     40d:      	cmpl	$0x1, %eax
     410:      	je	0x442 <cil_from_netdev+0x442>
     412:      	movl	$0x1a, %eax
     417:      	leal	0x1(%r14), %esi
     41b:      	leaq	0xf(%rsp), %rdx
     420:      	movq	%rbx, %rdi
     423:      	movl	$0x1, %ecx
     428:      	callq	*%rax
     42a:      	testl	%eax, %eax
     42c:      	js	0x9e <cil_from_netdev+0x9e>
     432:      	cmpb	%bpl, 0x10(%rsp)
     437:      	je	0x37a <cil_from_netdev+0x37a>
     43d:      	movzbl	0xf(%rsp), %eax
     442:      	addl	%eax, %r14d
     445:      	cmpl	%r12d, %r14d
     448:      	jae	0x49b <cil_from_netdev+0x49b>
     44a:      	movl	$0x1a, %eax
     44f:      	leaq	0x10(%rsp), %rdx
     454:      	movq	%rbx, %rdi
     457:      	movl	%r14d, %esi
     45a:      	movl	$0x1, %ecx
     45f:      	callq	*%rax
     461:      	testl	%eax, %eax
     463:      	js	0x9e <cil_from_netdev+0x9e>
     469:      	cmpb	$0x2, 0x10(%rsp)
     46e:      	jb	0x49b <cil_from_netdev+0x49b>
     470:      	movl	$0x1a, %eax
     475:      	leal	0x1(%r14), %esi
     479:      	leaq	0xf(%rsp), %rdx
     47e:      	movq	%rbx, %rdi
     481:      	movl	$0x1, %ecx
     486:      	callq	*%rax
     488:      	testl	%eax, %eax
     48a:      	js	0x9e <cil_from_netdev+0x9e>
     490:      	cmpb	%bpl, 0x10(%rsp)
     495:      	je	0x37a <cil_from_netdev+0x37a>
     49b:      	xorl	%r14d, %r14d
     49e:      	movl	$0x0, 0x18(%rsp)
     4a6:      	movl	$0x1, %eax
     4ab:      	movq	(%rip), %rdi            # 0x4b2 <cil_from_netdev+0x4b2>
     4b2:      	leaq	0x18(%rsp), %rsi
     4b7:      	callq	*%rax
     4b9:      	testq	%rax, %rax
     4bc:      	je	0xc5 <cil_from_netdev+0xc5>
     4c2:      	movq	%r14, (%rax)
     4c5:      	jmp	0xc5 <cil_from_netdev+0xc5>
     4ca:      	movl	$0x1a, %eax
     4cf:      	addl	$0x2, %r14d
     4d3:      	leaq	0x18(%rsp), %rdx
     4d8:      	movq	%rbx, %rdi
     4db:      	movl	%r14d, %esi
     4de:      	movl	$0x4, %ecx
     4e3:      	callq	*%rax
     4e5:      	xorl	%ecx, %ecx
     4e7:      	testl	%eax, %eax
     4e9:      	movbel	0x18(%rsp), %r14d
     4f0:      	cmovsl	%ecx, %r14d
     4f4:      	jmp	0x521 <cil_from_netdev+0x521>
     4f6:      	movl	$0x1a, %eax
     4fb:      	addl	$0x2, %r14d
     4ff:      	leaq	0x18(%rsp), %rdx
     504:      	movq	%rbx, %rdi
     507:      	movl	%r14d, %esi
     50a:      	movl	$0x8, %ecx
     50f:      	callq	*%rax
     511:      	xorl	%r14d, %r14d
     514:      	testl	%eax, %eax
     516:      	movbeq	0x18(%rsp), %rcx
     51d:      	cmovnsq	%rcx, %r14
     521:      	testl	%eax, %eax
     523:      	jns	0x49e <cil_from_netdev+0x49e>
     529:      	jmp	0x9e <cil_from_netdev+0x9e>
     52e:      	nop

0000000000000530 <cil_from_host>:
     530:      	pushq	%rbp
     531:      	pushq	%r15
     533:      	pushq	%r14
     535:      	pushq	%r13
     537:      	pushq	%r12
     539:      	pushq	%rbx
     53a:      	subq	$0x28, %rsp
     53e:      	movq	%rdi, %rbx
     541:      	movl	$0x0, 0x30(%rdi)
     548:      	movl	$0x0, 0x34(%rdi)
     54f:      	movl	$0x0, 0x38(%rdi)
     556:      	movl	$0x0, 0x3c(%rdi)
     55d:      	movl	$0x0, 0x40(%rdi)
     564:      	movq	(%rip), %r15            # 0x56b <cil_from_host+0x3b>
     56b:      	cmpb	$0x0, (%r15)
     56f:      	je	0x5f5 <cil_from_host+0xc5>
     575:      	movzbl	(%r15), %ebp
     579:      	movq	0x50(%rbx), %rdx
     57d:      	movq	(%rip), %rax            # 0x584 <cil_from_host+0x54>
     584:      	movzbl	(%rax), %esi
     587:      	movq	0xd0(%rbx), %rcx
     58e:      	cmpb	$0x0, (%rax)
     591:      	je	0x5ad <cil_from_host+0x7d>
     593:      	addq	%rcx, %rsi
     596:      	cmpq	%rdx, %rsi
     599:      	ja	0x5ce <cil_from_host+0x9e>
     59b:      	movzwl	0xc(%rcx), %esi
     59f:      	cmpw	$0x6, %si
     5a3:      	jb	0x5ce <cil_from_host+0x9e>
     5a5:      	cmpw	$0x8, %si
     5a9:      	je	0x5ba <cil_from_host+0x8a>
     5ab:      	jmp	0x5ce <cil_from_host+0x9e>
     5ad:      	movzwl	0xb4(%rbx), %esi
     5b4:      	cmpw	$0x8, %si
     5b8:      	jne	0x5ce <cil_from_host+0x9e>
     5ba:      	movzbl	(%rax), %esi
     5bd:      	leaq	(%rcx,%rsi), %rdi
     5c1:      	addq	$0x14, %rdi
     5c5:      	cmpq	%rdx, %rdi
     5c8:      	jbe	0x8d9 <cil_from_host+0x3a9>
     5ce:      	movl	$0x0, 0x10(%rsp)
     5d6:      	movl	$0x1, %eax
     5db:      	movq	(%rip), %rdi            # 0x5e2 <cil_from_host+0xb2>
     5e2:      	leaq	0x10(%rsp), %rsi
     5e7:      	callq	*%rax
     5e9:      	testq	%rax, %rax
     5ec:      	je	0x5f5 <cil_from_host+0xc5>
     5ee:      	movq	$0x0, (%rax)
     5f5:      	movl	$0xffffffff, %r14d      # imm = 0xFFFFFFFF
     5fb:      	movq	0x50(%rbx), %rcx
     5ff:      	movq	(%rip), %rsi            # 0x606 <cil_from_host+0xd6>
     606:      	movzbl	(%rsi), %edx
     609:      	movq	0xd0(%rbx), %rax
     610:      	cmpb	$0x0, (%rsi)
     613:      	je	0x62c <cil_from_host+0xfc>
     615:      	addq	%rax, %rdx
     618:      	cmpq	%rcx, %rdx
     61b:      	ja	0x6b7 <cil_from_host+0x187>
     621:      	cmpw	$0x5, 0xc(%rax)
     626:      	jbe	0x6b7 <cil_from_host+0x187>
     62c:      	movl	0xa8(%rbx), %ebp
     632:      	movl	%ebp, %eax
     634:      	andl	$0xf00, %eax            # imm = 0xF00
     639:      	addl	$0xfffff600, %eax       # imm = 0xFFFFF600
     63e:      	shrl	$0x8, %eax
     641:      	cmpl	$0x1, %eax
     644:      	jg	0x71b <cil_from_host+0x1eb>
     64a:      	testl	%eax, %eax
     64c:      	je	0x782 <cil_from_host+0x252>
     652:      	cmpl	$0x1, %eax
     655:      	jne	0x77b <cil_from_host+0x24b>
     65b:      	movzbl	%bpl, %ecx
     65f:      	movq	(%rip), %rax            # 0x666 <cil_from_host+0x136>
     666:      	movl	(%rax), %edx
     668:      	movl	$0x7fffff00, %esi       # imm = 0x7FFFFF00
     66d:      	bzhil	%edx, %esi, %edx
     672:      	movl	(%rax), %esi
     674:      	negb	%sil
     677:      	shlxl	%esi, %edx, %edx
     67c:      	andl	%ebp, %edx
     67e:      	movl	(%rax), %esi
     680:      	negb	%sil
     683:      	shrxl	%esi, %edx, %edx
     688:      	orl	%ecx, %edx
     68a:      	movl	%ebp, %ecx
     68c:      	shrl	$0x10, %ecx
     68f:      	movl	(%rax), %esi
     691:      	movb	$0x18, %dil
     694:      	movb	$0x18, %r8b
     697:      	subb	%sil, %r8b
     69a:      	bzhil	%r8d, %ecx, %ecx
     69f:      	movl	(%rax), %eax
     6a1:      	subb	%al, %dil
     6a4:      	shlxl	%edi, %edx, %eax
     6a9:      	orl	%ecx, %eax
     6ab:      	orb	$0x2, 0x86(%rbx)
     6b2:      	jmp	0x7e0 <cil_from_host+0x2b0>
     6b7:      	cmpb	$0x0, (%r15)
     6bb:      	je	0x6d8 <cil_from_host+0x1a8>
     6bd:      	movl	$0x0, 0x10(%rsp)
     6c5:      	movl	$0x1, %eax
     6ca:      	movq	(%rip), %rdi            # 0x6d1 <cil_from_host+0x1a1>
     6d1:      	leaq	0x10(%rsp), %rsi
     6d6:      	callq	*%rax
     6d8:      	movl	0x70(%rbx), %ebx
     6db:      	addq	$0x5030201, %r14        # imm = 0x5030201
     6e2:      	movq	%r14, 0x8(%rsp)
     6e7:      	movl	$0x1, %eax
     6ec:      	movq	(%rip), %rdi            # 0x6f3 <cil_from_host+0x1c3>
     6f3:      	leaq	0x8(%rsp), %rsi
     6f8:      	callq	*%rax
     6fa:      	testq	%rax, %rax
     6fd:      	jne	0x897 <cil_from_host+0x367>
     703:      	movq	$0x1, 0x10(%rsp)
     70c:      	movq	%rbx, 0x18(%rsp)
     711:      	movl	$0x2, %eax
     716:      	jmp	0x8b3 <cil_from_host+0x383>
     71b:      	cmpl	$0x2, %eax
     71e:      	je	0x7db <cil_from_host+0x2ab>
     724:      	cmpl	$0x5, %eax
     727:      	jne	0x77b <cil_from_host+0x24b>
     729:      	movzbl	%bpl, %ecx
     72d:      	movq	(%rip), %rax            # 0x734 <cil_from_host+0x204>
     734:      	movl	(%rax), %edx
     736:      	movl	$0x7fffff00, %esi       # imm = 0x7FFFFF00
     73b:      	bzhil	%edx, %esi, %edx
     740:      	movl	(%rax), %esi
     742:      	negb	%sil
     745:      	shlxl	%esi, %edx, %edx
     74a:      	andl	%ebp, %edx
     74c:      	movl	(%rax), %esi
     74e:      	negb	%sil
     751:      	shrxl	%esi, %edx, %edx
     756:      	orl	%ecx, %edx
     758:      	movl	%ebp, %ecx
     75a:      	shrl	$0x10, %ecx
     75d:      	movl	(%rax), %esi
     75f:      	movb	$0x18, %dil
     762:      	movb	$0x18, %r8b
     765:      	subb	%sil, %r8b
     768:      	bzhil	%r8d, %ecx, %ecx
     76d:      	movl	(%rax), %eax
     76f:      	subb	%al, %dil
     772:      	shlxl	%edi, %edx, %eax
     777:      	orl	%ecx, %eax
     779:      	jmp	0x7e0 <cil_from_host+0x2b0>
     77b:      	movl	$0x2, %eax
     780:      	jmp	0x7e0 <cil_from_host+0x2b0>
     782:      	movzbl	%bpl, %ecx
     786:      	movq	(%rip), %rax            # 0x78d <cil_from_host+0x25d>
     78d:      	movl	(%rax), %edx
     78f:      	movl	$0x7fffff00, %esi       # imm = 0x7FFFFF00
     794:      	bzhil	%edx, %esi, %edx
     799:      	movl	(%rax), %esi
     79b:      	negb	%sil
     79e:      	shlxl	%esi, %edx, %edx
     7a3:      	andl	%ebp, %edx
     7a5:      	movl	(%rax), %esi
     7a7:      	negb	%sil
     7aa:      	shrxl	%esi, %edx, %edx
     7af:      	orl	%ecx, %edx
     7b1:      	movl	%ebp, %ecx
     7b3:      	shrl	$0x10, %ecx
     7b6:      	movl	(%rax), %esi
     7b8:      	movb	$0x18, %dil
     7bb:      	movb	$0x18, %r8b
     7be:      	subb	%sil, %r8b
     7c1:      	bzhil	%r8d, %ecx, %ecx
     7c6:      	movl	(%rax), %eax
     7c8:      	subb	%al, %dil
     7cb:      	shlxl	%edi, %edx, %eax
     7d0:      	orl	%ecx, %eax
     7d2:      	orb	$0x1, 0x86(%rbx)
     7d9:      	jmp	0x7e0 <cil_from_host+0x2b0>
     7db:      	movl	$0x1, %eax
     7e0:      	movl	$0x0, 0xa8(%rbx)
     7ea:      	movw	$0x3d02, 0x10(%rsp)     # imm = 0x3D02
     7f1:      	movq	(%rip), %rcx            # 0x7f8 <cil_from_host+0x2c8>
     7f8:      	movzwl	(%rcx), %ecx
     7fb:      	movw	%cx, 0x12(%rsp)
     800:      	movl	0x98(%rbx), %ecx
     806:      	movl	%ecx, 0x14(%rsp)
     80a:      	movl	%eax, 0x18(%rsp)
     80e:      	movq	$0x0, 0x1c(%rsp)
     817:      	movl	$0x19, %eax
     81c:      	movq	(%rip), %rsi            # 0x823 <cil_from_host+0x2f3>
     823:      	leaq	0x10(%rsp), %rcx
     828:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     82d:      	movq	%rbx, %rdi
     830:      	movl	$0x14, %r8d
     836:      	callq	*%rax
     838:      	movq	(%rip), %rax            # 0x83f <cil_from_host+0x30f>
     83f:      	movl	(%rax), %eax
     841:      	andl	$0xe00, %ebp            # imm = 0xE00
     847:      	cmpb	$0x0, (%r15)
     84b:      	je	0x868 <cil_from_host+0x338>
     84d:      	movl	$0x0, 0x10(%rsp)
     855:      	movl	$0x1, %eax
     85a:      	movq	(%rip), %rdi            # 0x861 <cil_from_host+0x331>
     861:      	leaq	0x10(%rsp), %rsi
     866:      	callq	*%rax
     868:      	cmpl	$0xa00, %ebp            # imm = 0xA00
     86e:      	je	0x8c8 <cil_from_host+0x398>
     870:      	movl	0x70(%rbx), %ebx
     873:      	addq	$0x47e0104, %r14        # imm = 0x47E0104
     87a:      	movq	%r14, 0x8(%rsp)
     87f:      	movl	$0x1, %eax
     884:      	movq	(%rip), %rdi            # 0x88b <cil_from_host+0x35b>
     88b:      	leaq	0x8(%rsp), %rsi
     890:      	callq	*%rax
     892:      	testq	%rax, %rax
     895:      	je	0x8a0 <cil_from_host+0x370>
     897:      	incq	(%rax)
     89a:      	addq	%rbx, 0x8(%rax)
     89e:      	jmp	0x8c8 <cil_from_host+0x398>
     8a0:      	movq	$0x1, 0x10(%rsp)
     8a9:      	movq	%rbx, 0x18(%rsp)
     8ae:      	movl	$0x2, %eax
     8b3:      	movq	(%rip), %rdi            # 0x8ba <cil_from_host+0x38a>
     8ba:      	leaq	0x8(%rsp), %rsi
     8bf:      	leaq	0x10(%rsp), %rdx
     8c4:      	xorl	%ecx, %ecx
     8c6:      	callq	*%rax
     8c8:      	xorl	%eax, %eax
     8ca:      	addq	$0x28, %rsp
     8ce:      	popq	%rbx
     8cf:      	popq	%r12
     8d1:      	popq	%r13
     8d3:      	popq	%r14
     8d5:      	popq	%r15
     8d7:      	popq	%rbp
     8d8:      	retq
     8d9:      	addq	%rsi, %rcx
     8dc:      	movzbl	(%rcx), %r12d
     8e0:      	movl	%r12d, %ecx
     8e3:      	andb	$0xe, %cl
     8e6:      	cmpb	$0x6, %cl
     8e9:      	jb	0xa84 <cil_from_host+0x554>
     8ef:      	movzbl	(%rax), %r13d
     8f3:      	shll	$0x2, %r12d
     8f7:      	andl	$0x3c, %r12d
     8fb:      	je	0xa84 <cil_from_host+0x554>
     901:      	leal	0x14(%r13), %r14d
     905:      	movl	$0x1a, %eax
     90a:      	leaq	0x8(%rsp), %rdx
     90f:      	movq	%rbx, %rdi
     912:      	movl	%r14d, %esi
     915:      	movl	$0x1, %ecx
     91a:      	callq	*%rax
     91c:      	testl	%eax, %eax
     91e:      	js	0x5ce <cil_from_host+0x9e>
     924:      	movzbl	0x8(%rsp), %eax
     929:      	testl	%eax, %eax
     92b:      	je	0xa84 <cil_from_host+0x554>
     931:      	cmpl	$0x1, %eax
     934:      	jne	0x93c <cil_from_host+0x40c>
     936:      	leal	0x15(%r13), %r14d
     93a:      	jmp	0x9ba <cil_from_host+0x48a>
     93c:      	movl	$0x1a, %eax
     941:      	leal	0x15(%r13), %esi
     945:      	leaq	0x7(%rsp), %rdx
     94a:      	movq	%rbx, %rdi
     94d:      	movl	$0x1, %ecx
     952:      	callq	*%rax
     954:      	testl	%eax, %eax
     956:      	js	0x5ce <cil_from_host+0x9e>
     95c:      	cmpb	%bpl, 0x8(%rsp)
     961:      	jne	0x9b2 <cil_from_host+0x482>
     963:      	movzbl	0x7(%rsp), %eax
     968:      	cmpl	$0xa, %eax
     96b:      	je	0xadf <cil_from_host+0x5af>
     971:      	cmpl	$0x6, %eax
     974:      	je	0xab3 <cil_from_host+0x583>
     97a:      	cmpl	$0x4, %eax
     97d:      	jne	0x5ce <cil_from_host+0x9e>
     983:      	movl	$0x1a, %eax
     988:      	addl	$0x2, %r14d
     98c:      	leaq	0x10(%rsp), %rdx
     991:      	movq	%rbx, %rdi
     994:      	movl	%r14d, %esi
     997:      	movl	$0x2, %ecx
     99c:      	callq	*%rax
     99e:      	xorl	%r14d, %r14d
     9a1:      	testl	%eax, %eax
     9a3:      	movbew	0x10(%rsp), %cx
     9aa:      	movzwl	%cx, %ecx
     9ad:      	jmp	0xb06 <cil_from_host+0x5d6>
     9b2:      	movzbl	0x7(%rsp), %eax
     9b7:      	addl	%eax, %r14d
     9ba:      	addl	%r13d, %r12d
     9bd:      	addl	$0x14, %r12d
     9c1:      	cmpl	%r12d, %r14d
     9c4:      	jae	0xa84 <cil_from_host+0x554>
     9ca:      	movl	$0x1a, %eax
     9cf:      	leaq	0x8(%rsp), %rdx
     9d4:      	movq	%rbx, %rdi
     9d7:      	movl	%r14d, %esi
     9da:      	movl	$0x1, %ecx
     9df:      	callq	*%rax
     9e1:      	testl	%eax, %eax
     9e3:      	js	0x5ce <cil_from_host+0x9e>
     9e9:      	movzbl	0x8(%rsp), %eax
     9ee:      	testl	%eax, %eax
     9f0:      	je	0xa84 <cil_from_host+0x554>
     9f6:      	cmpl	$0x1, %eax
     9f9:      	je	0xa2b <cil_from_host+0x4fb>
     9fb:      	movl	$0x1a, %eax
     a00:      	leal	0x1(%r14), %esi
     a04:      	leaq	0x7(%rsp), %rdx
     a09:      	movq	%rbx, %rdi
     a0c:      	movl	$0x1, %ecx
     a11:      	callq	*%rax
     a13:      	testl	%eax, %eax
     a15:      	js	0x5ce <cil_from_host+0x9e>
     a1b:      	cmpb	%bpl, 0x8(%rsp)
     a20:      	je	0x963 <cil_from_host+0x433>
     a26:      	movzbl	0x7(%rsp), %eax
     a2b:      	addl	%eax, %r14d
     a2e:      	cmpl	%r12d, %r14d
     a31:      	jae	0xa84 <cil_from_host+0x554>
     a33:      	movl	$0x1a, %eax
     a38:      	leaq	0x8(%rsp), %rdx
     a3d:      	movq	%rbx, %rdi
     a40:      	movl	%r14d, %esi
     a43:      	movl	$0x1, %ecx
     a48:      	callq	*%rax
     a4a:      	testl	%eax, %eax
     a4c:      	js	0x5ce <cil_from_host+0x9e>
     a52:      	cmpb	$0x2, 0x8(%rsp)
     a57:      	jb	0xa84 <cil_from_host+0x554>
     a59:      	movl	$0x1a, %eax
     a5e:      	leal	0x1(%r14), %esi
     a62:      	leaq	0x7(%rsp), %rdx
     a67:      	movq	%rbx, %rdi
     a6a:      	movl	$0x1, %ecx
     a6f:      	callq	*%rax
     a71:      	testl	%eax, %eax
     a73:      	js	0x5ce <cil_from_host+0x9e>
     a79:      	cmpb	%bpl, 0x8(%rsp)
     a7e:      	je	0x963 <cil_from_host+0x433>
     a84:      	xorl	%r14d, %r14d
     a87:      	movl	$0x0, 0x10(%rsp)
     a8f:      	movl	$0x1, %eax
     a94:      	movq	(%rip), %rdi            # 0xa9b <cil_from_host+0x56b>
     a9b:      	leaq	0x10(%rsp), %rsi
     aa0:      	callq	*%rax
     aa2:      	testq	%rax, %rax
     aa5:      	je	0x5f5 <cil_from_host+0xc5>
     aab:      	movq	%r14, (%rax)
     aae:      	jmp	0x5f5 <cil_from_host+0xc5>
     ab3:      	movl	$0x1a, %eax
     ab8:      	addl	$0x2, %r14d
     abc:      	leaq	0x10(%rsp), %rdx
     ac1:      	movq	%rbx, %rdi
     ac4:      	movl	%r14d, %esi
     ac7:      	movl	$0x4, %ecx
     acc:      	callq	*%rax
     ace:      	xorl	%ecx, %ecx
     ad0:      	testl	%eax, %eax
     ad2:      	movbel	0x10(%rsp), %r14d
     ad9:      	cmovsl	%ecx, %r14d
     add:      	jmp	0xb0a <cil_from_host+0x5da>
     adf:      	movl	$0x1a, %eax
     ae4:      	addl	$0x2, %r14d
     ae8:      	leaq	0x10(%rsp), %rdx
     aed:      	movq	%rbx, %rdi
     af0:      	movl	%r14d, %esi
     af3:      	movl	$0x8, %ecx
     af8:      	callq	*%rax
     afa:      	xorl	%r14d, %r14d
     afd:      	testl	%eax, %eax
     aff:      	movbeq	0x10(%rsp), %rcx
     b06:      	cmovnsq	%rcx, %r14
     b0a:      	testl	%eax, %eax
     b0c:      	jns	0xa87 <cil_from_host+0x557>
     b12:      	jmp	0x5ce <cil_from_host+0x9e>
     b17:      	nopw	(%rax,%rax)

0000000000000b20 <cil_to_netdev>:
     b20:      	pushq	%rbp
     b21:      	pushq	%r15
     b23:      	pushq	%r14
     b25:      	pushq	%r13
     b27:      	pushq	%r12
     b29:      	pushq	%rbx
     b2a:      	subq	$0x28, %rsp
     b2e:      	movq	%rdi, %rbx
     b31:      	movl	0xa8(%rdi), %ebp
     b37:      	movq	(%rip), %rax            # 0xb3e <cil_to_netdev+0x1e>
     b3e:      	movzbl	(%rax), %ecx
     b41:      	movzbl	(%rax), %ecx
     b44:      	movl	$0x0, 0x30(%rdi)
     b4b:      	movl	$0x0, 0x34(%rdi)
     b52:      	movl	$0x0, 0x38(%rdi)
     b59:      	movl	$0x0, 0x3c(%rdi)
     b60:      	movl	$0x0, 0x40(%rdi)
     b67:      	movq	(%rip), %r15            # 0xb6e <cil_to_netdev+0x4e>
     b6e:      	cmpb	$0x0, (%r15)
     b72:      	je	0xbed <cil_to_netdev+0xcd>
     b74:      	movzbl	(%r15), %r12d
     b78:      	movq	0x50(%rbx), %rdx
     b7c:      	movzbl	(%rax), %esi
     b7f:      	movq	0xd0(%rbx), %rcx
     b86:      	cmpb	$0x0, (%rax)
     b89:      	je	0xba5 <cil_to_netdev+0x85>
     b8b:      	addq	%rcx, %rsi
     b8e:      	cmpq	%rdx, %rsi
     b91:      	ja	0xbc6 <cil_to_netdev+0xa6>
     b93:      	movzwl	0xc(%rcx), %esi
     b97:      	cmpw	$0x6, %si
     b9b:      	jb	0xbc6 <cil_to_netdev+0xa6>
     b9d:      	cmpw	$0x8, %si
     ba1:      	je	0xbb2 <cil_to_netdev+0x92>
     ba3:      	jmp	0xbc6 <cil_to_netdev+0xa6>
     ba5:      	movzwl	0xb4(%rbx), %esi
     bac:      	cmpw	$0x8, %si
     bb0:      	jne	0xbc6 <cil_to_netdev+0xa6>
     bb2:      	movzbl	(%rax), %esi
     bb5:      	leaq	(%rcx,%rsi), %rdi
     bb9:      	addq	$0x14, %rdi
     bbd:      	cmpq	%rdx, %rdi
     bc0:      	jbe	0xd60 <cil_to_netdev+0x240>
     bc6:      	movl	$0x0, 0x18(%rsp)
     bce:      	movl	$0x1, %eax
     bd3:      	movq	(%rip), %rdi            # 0xbda <cil_to_netdev+0xba>
     bda:      	leaq	0x18(%rsp), %rsi
     bdf:      	callq	*%rax
     be1:      	testq	%rax, %rax
     be4:      	je	0xbed <cil_to_netdev+0xcd>
     be6:      	movq	$0x0, (%rax)
     bed:      	movl	%ebp, %eax
     bef:      	andl	$0x700, %eax            # imm = 0x700
     bf4:      	movl	$0x1, %ecx
     bf9:      	cmpl	$0x400, %eax            # imm = 0x400
     bfe:      	je	0xc7f <cil_to_netdev+0x15f>
     c00:      	andl	$0xf00, %ebp            # imm = 0xF00
     c06:      	cmpl	$0xe00, %ebp            # imm = 0xE00
     c0c:      	je	0xc7f <cil_to_netdev+0x15f>
     c0e:      	cmpl	$0xb00, %ebp            # imm = 0xB00
     c14:      	je	0xc2c <cil_to_netdev+0x10c>
     c16:      	movq	(%rip), %rax            # 0xc1d <cil_to_netdev+0xfd>
     c1d:      	xorl	%ecx, %ecx
     c1f:      	cmpb	$0x0, (%rax)
     c22:      	je	0xc7f <cil_to_netdev+0x15f>
     c24:      	cmpl	$0xf00, %ebp            # imm = 0xF00
     c2a:      	jne	0xc7f <cil_to_netdev+0x15f>
     c2c:      	movl	0xa8(%rbx), %eax
     c32:      	movzbl	%al, %edx
     c35:      	movq	(%rip), %rcx            # 0xc3c <cil_to_netdev+0x11c>
     c3c:      	movl	(%rcx), %esi
     c3e:      	movl	$0x7fffff00, %edi       # imm = 0x7FFFFF00
     c43:      	bzhil	%esi, %edi, %esi
     c48:      	movl	(%rcx), %edi
     c4a:      	negb	%dil
     c4d:      	shlxl	%edi, %esi, %esi
     c52:      	andl	%eax, %esi
     c54:      	movl	(%rcx), %edi
     c56:      	negb	%dil
     c59:      	shrxl	%edi, %esi, %esi
     c5e:      	orl	%edx, %esi
     c60:      	shrl	$0x10, %eax
     c63:      	movl	(%rcx), %edx
     c65:      	movb	$0x18, %dil
     c68:      	movb	$0x18, %r8b
     c6b:      	subb	%dl, %r8b
     c6e:      	bzhil	%r8d, %eax, %eax
     c73:      	movl	(%rcx), %ecx
     c75:      	subb	%cl, %dil
     c78:      	shlxl	%edi, %esi, %ecx
     c7d:      	orl	%eax, %ecx
     c7f:      	movl	0x9c(%rbx), %edx
     c85:      	testl	%edx, %edx
     c87:      	je	0xccf <cil_to_netdev+0x1af>
     c89:      	testl	$0xfff0000, %edx        # imm = 0xFFF0000
     c8f:      	je	0xccf <cil_to_netdev+0x1af>
     c91:      	movq	0x10(%rbx), %rax
     c95:      	testq	%rax, %rax
     c98:      	je	0xde6 <cil_to_netdev+0x2c6>
     c9e:      	movl	0xe0(%rax), %eax
     ca4:      	cmpl	$0x75, %eax
     ca7:      	je	0xdcc <cil_to_netdev+0x2ac>
     cad:      	cmpl	$0x74, %eax
     cb0:      	jne	0xde6 <cil_to_netdev+0x2c6>
     cb6:      	andl	$0xffe0000, %edx        # imm = 0xFFE0000
     cbc:      	xorl	%eax, %eax
     cbe:      	cmpl	$0xfa00000, %edx        # imm = 0xFA00000
     cc4:      	jne	0xde6 <cil_to_netdev+0x2c6>
     cca:      	jmp	0xe82 <cil_to_netdev+0x362>
     ccf:      	movq	(%rip), %rax            # 0xcd6 <cil_to_netdev+0x1b6>
     cd6:      	movl	(%rax), %eax
     cd8:      	cmpb	$0x0, (%r15)
     cdc:      	je	0xcf9 <cil_to_netdev+0x1d9>
     cde:      	movl	$0x0, 0x18(%rsp)
     ce6:      	movl	$0x1, %eax
     ceb:      	movq	(%rip), %rdi            # 0xcf2 <cil_to_netdev+0x1d2>
     cf2:      	leaq	0x18(%rsp), %rsi
     cf7:      	callq	*%rax
     cf9:      	movl	0x70(%rbx), %ebx
     cfc:      	movabsq	$0x105f30200, %rax      # imm = 0x105F30200
     d06:      	movq	%rax, 0x8(%rsp)
     d0b:      	movl	$0x1, %eax
     d10:      	movq	(%rip), %rdi            # 0xd17 <cil_to_netdev+0x1f7>
     d17:      	leaq	0x8(%rsp), %rsi
     d1c:      	callq	*%rax
     d1e:      	testq	%rax, %rax
     d21:      	je	0xd31 <cil_to_netdev+0x211>
     d23:      	incq	(%rax)
     d26:      	addq	%rbx, 0x8(%rax)
     d2a:      	xorl	%eax, %eax
     d2c:      	jmp	0xe82 <cil_to_netdev+0x362>
     d31:      	movq	$0x1, 0x18(%rsp)
     d3a:      	movq	%rbx, 0x20(%rsp)
     d3f:      	movl	$0x2, %eax
     d44:      	movq	(%rip), %rdi            # 0xd4b <cil_to_netdev+0x22b>
     d4b:      	leaq	0x8(%rsp), %rsi
     d50:      	leaq	0x18(%rsp), %rdx
     d55:      	xorl	%ecx, %ecx
     d57:      	callq	*%rax
     d59:      	xorl	%eax, %eax
     d5b:      	jmp	0xe82 <cil_to_netdev+0x362>
     d60:      	addq	%rsi, %rcx
     d63:      	movzbl	(%rcx), %r13d
     d67:      	movl	%r13d, %ecx
     d6a:      	andb	$0xe, %cl
     d6d:      	cmpb	$0x6, %cl
     d70:      	jb	0xffb <cil_to_netdev+0x4db>
     d76:      	movzbl	(%rax), %r14d
     d7a:      	shll	$0x2, %r13d
     d7e:      	andl	$0x3c, %r13d
     d82:      	je	0xffb <cil_to_netdev+0x4db>
     d88:      	leal	0x14(%r14), %esi
     d8c:      	movl	$0x1a, %eax
     d91:      	leaq	0x8(%rsp), %rdx
     d96:      	movq	%rbx, %rdi
     d99:      	movq	%rsi, 0x10(%rsp)
     d9e:      	movl	$0x1, %ecx
     da3:      	callq	*%rax
     da5:      	testl	%eax, %eax
     da7:      	js	0xbc6 <cil_to_netdev+0xa6>
     dad:      	movzbl	0x8(%rsp), %eax
     db2:      	testl	%eax, %eax
     db4:      	je	0xffb <cil_to_netdev+0x4db>
     dba:      	cmpl	$0x1, %eax
     dbd:      	jne	0xe91 <cil_to_netdev+0x371>
     dc3:      	leal	0x15(%r14), %eax
     dc7:      	jmp	0xf17 <cil_to_netdev+0x3f7>
     dcc:      	shrl	$0x10, %edx
     dcf:      	andl	$0xfff, %edx            # imm = 0xFFF
     dd5:      	addl	$0xfffff05d, %edx       # imm = 0xFFFFF05D
     ddb:      	xorl	%eax, %eax
     ddd:      	cmpl	$0x3, %edx
     de0:      	jb	0xe82 <cil_to_netdev+0x362>
     de6:      	movl	%ecx, 0x30(%rbx)
     de9:      	movabsq	$0xb600000000, %rax     # imm = 0xB600000000
     df3:      	movq	%rax, 0x34(%rbx)
     df7:      	movabsq	$0x5f9010200000000, %rax # imm = 0x5F9010200000000
     e01:      	movq	%rax, 0x3c(%rbx)
     e05:      	movl	0x70(%rbx), %r14d
     e09:      	movabsq	$0x105f30200, %rax      # imm = 0x105F30200
     e13:      	addq	$0x600b6, %rax          # imm = 0x600B6
     e19:      	movq	%rax, 0x8(%rsp)
     e1e:      	movl	$0x1, %eax
     e23:      	movq	(%rip), %rdi            # 0xe2a <cil_to_netdev+0x30a>
     e2a:      	leaq	0x8(%rsp), %rsi
     e2f:      	callq	*%rax
     e31:      	testq	%rax, %rax
     e34:      	je	0xe3f <cil_to_netdev+0x31f>
     e36:      	incq	(%rax)
     e39:      	addq	%r14, 0x8(%rax)
     e3d:      	jmp	0xe67 <cil_to_netdev+0x347>
     e3f:      	movq	$0x1, 0x18(%rsp)
     e48:      	movq	%r14, 0x20(%rsp)
     e4d:      	movl	$0x2, %eax
     e52:      	movq	(%rip), %rdi            # 0xe59 <cil_to_netdev+0x339>
     e59:      	leaq	0x8(%rsp), %rsi
     e5e:      	leaq	0x18(%rsp), %rdx
     e63:      	xorl	%ecx, %ecx
     e65:      	callq	*%rax
     e67:      	movl	$0xc, %eax
     e6c:      	movq	(%rip), %rsi            # 0xe73 <cil_to_netdev+0x353>
     e73:      	movq	%rbx, %rdi
     e76:      	movl	$0x1, %edx
     e7b:      	callq	*%rax
     e7d:      	movl	$0x2, %eax
     e82:      	addq	$0x28, %rsp
     e86:      	popq	%rbx
     e87:      	popq	%r12
     e89:      	popq	%r13
     e8b:      	popq	%r14
     e8d:      	popq	%r15
     e8f:      	popq	%rbp
     e90:      	retq
     e91:      	movl	$0x1a, %eax
     e96:      	leal	0x15(%r14), %esi
     e9a:      	leaq	0x7(%rsp), %rdx
     e9f:      	movq	%rbx, %rdi
     ea2:      	movl	$0x1, %ecx
     ea7:      	callq	*%rax
     ea9:      	testl	%eax, %eax
     eab:      	js	0xbc6 <cil_to_netdev+0xa6>
     eb1:      	cmpb	%r12b, 0x8(%rsp)
     eb6:      	jne	0xf08 <cil_to_netdev+0x3e8>
     eb8:      	movzbl	0x7(%rsp), %eax
     ebd:      	cmpl	$0xa, %eax
     ec0:      	je	0x1057 <cil_to_netdev+0x537>
     ec6:      	cmpl	$0x6, %eax
     ec9:      	je	0x102a <cil_to_netdev+0x50a>
     ecf:      	cmpl	$0x4, %eax
     ed2:      	jne	0xbc6 <cil_to_netdev+0xa6>
     ed8:      	movl	$0x1a, %eax
     edd:      	movq	0x10(%rsp), %rsi
     ee2:      	addl	$0x2, %esi
     ee5:      	leaq	0x18(%rsp), %rdx
     eea:      	movq	%rbx, %rdi
     eed:      	movl	$0x2, %ecx
     ef2:      	callq	*%rax
     ef4:      	xorl	%r14d, %r14d
     ef7:      	testl	%eax, %eax
     ef9:      	movbew	0x18(%rsp), %cx
     f00:      	movzwl	%cx, %ecx
     f03:      	jmp	0x107f <cil_to_netdev+0x55f>
     f08:      	movzbl	0x7(%rsp), %eax
     f0d:      	movq	0x10(%rsp), %rcx
     f12:      	addl	%eax, %ecx
     f14:      	movq	%rcx, %rax
     f17:      	addl	%r13d, %r14d
     f1a:      	addl	$0x14, %r14d
     f1e:      	movq	%rax, 0x10(%rsp)
     f23:      	cmpl	%r14d, %eax
     f26:      	jae	0xffb <cil_to_netdev+0x4db>
     f2c:      	movl	$0x1a, %eax
     f31:      	leaq	0x8(%rsp), %rdx
     f36:      	movq	%rbx, %rdi
     f39:      	movq	0x10(%rsp), %rsi
     f3e:      	movl	$0x1, %ecx
     f43:      	callq	*%rax
     f45:      	testl	%eax, %eax
     f47:      	js	0xbc6 <cil_to_netdev+0xa6>
     f4d:      	movzbl	0x8(%rsp), %eax
     f52:      	testl	%eax, %eax
     f54:      	je	0xffb <cil_to_netdev+0x4db>
     f5a:      	cmpl	$0x1, %eax
     f5d:      	je	0xf93 <cil_to_netdev+0x473>
     f5f:      	movl	$0x1a, %eax
     f64:      	movq	0x10(%rsp), %rcx
     f69:      	leal	0x1(%rcx), %esi
     f6c:      	leaq	0x7(%rsp), %rdx
     f71:      	movq	%rbx, %rdi
     f74:      	movl	$0x1, %ecx
     f79:      	callq	*%rax
     f7b:      	testl	%eax, %eax
     f7d:      	js	0xbc6 <cil_to_netdev+0xa6>
     f83:      	cmpb	%r12b, 0x8(%rsp)
     f88:      	je	0xeb8 <cil_to_netdev+0x398>
     f8e:      	movzbl	0x7(%rsp), %eax
     f93:      	movq	0x10(%rsp), %rcx
     f98:      	addl	%eax, %ecx
     f9a:      	movq	%rcx, 0x10(%rsp)
     f9f:      	cmpl	%r14d, %ecx
     fa2:      	jae	0xffb <cil_to_netdev+0x4db>
     fa4:      	movl	$0x1a, %eax
     fa9:      	leaq	0x8(%rsp), %rdx
     fae:      	movq	%rbx, %rdi
     fb1:      	movq	0x10(%rsp), %rsi
     fb6:      	movl	$0x1, %ecx
     fbb:      	callq	*%rax
     fbd:      	testl	%eax, %eax
     fbf:      	js	0xbc6 <cil_to_netdev+0xa6>
     fc5:      	cmpb	$0x2, 0x8(%rsp)
     fca:      	jb	0xffb <cil_to_netdev+0x4db>
     fcc:      	movl	$0x1a, %eax
     fd1:      	movq	0x10(%rsp), %rcx
     fd6:      	leal	0x1(%rcx), %esi
     fd9:      	leaq	0x7(%rsp), %rdx
     fde:      	movq	%rbx, %rdi
     fe1:      	movl	$0x1, %ecx
     fe6:      	callq	*%rax
     fe8:      	testl	%eax, %eax
     fea:      	js	0xbc6 <cil_to_netdev+0xa6>
     ff0:      	cmpb	%r12b, 0x8(%rsp)
     ff5:      	je	0xeb8 <cil_to_netdev+0x398>
     ffb:      	xorl	%r14d, %r14d
     ffe:      	movl	$0x0, 0x18(%rsp)
    1006:      	movl	$0x1, %eax
    100b:      	movq	(%rip), %rdi            # 0x1012 <cil_to_netdev+0x4f2>
    1012:      	leaq	0x18(%rsp), %rsi
    1017:      	callq	*%rax
    1019:      	testq	%rax, %rax
    101c:      	je	0xbed <cil_to_netdev+0xcd>
    1022:      	movq	%r14, (%rax)
    1025:      	jmp	0xbed <cil_to_netdev+0xcd>
    102a:      	movl	$0x1a, %eax
    102f:      	movq	0x10(%rsp), %rsi
    1034:      	addl	$0x2, %esi
    1037:      	leaq	0x18(%rsp), %rdx
    103c:      	movq	%rbx, %rdi
    103f:      	movl	$0x4, %ecx
    1044:      	callq	*%rax
    1046:      	xorl	%ecx, %ecx
    1048:      	testl	%eax, %eax
    104a:      	movbel	0x18(%rsp), %r14d
    1051:      	cmovsl	%ecx, %r14d
    1055:      	jmp	0x1083 <cil_to_netdev+0x563>
    1057:      	movl	$0x1a, %eax
    105c:      	movq	0x10(%rsp), %rsi
    1061:      	addl	$0x2, %esi
    1064:      	leaq	0x18(%rsp), %rdx
    1069:      	movq	%rbx, %rdi
    106c:      	movl	$0x8, %ecx
    1071:      	callq	*%rax
    1073:      	xorl	%r14d, %r14d
    1076:      	testl	%eax, %eax
    1078:      	movbeq	0x18(%rsp), %rcx
    107f:      	cmovnsq	%rcx, %r14
    1083:      	testl	%eax, %eax
    1085:      	jns	0xffe <cil_to_netdev+0x4de>
    108b:      	jmp	0xbc6 <cil_to_netdev+0xa6>

0000000000001090 <cil_to_host>:
    1090:      	pushq	%rbp
    1091:      	pushq	%r15
    1093:      	pushq	%r14
    1095:      	pushq	%r13
    1097:      	pushq	%r12
    1099:      	pushq	%rbx
    109a:      	subq	$0x38, %rsp
    109e:      	movq	%rdi, %rbx
    10a1:      	movl	0x30(%rdi), %ebp
    10a4:      	movq	(%rip), %r15            # 0x10ab <cil_to_host+0x1b>
    10ab:      	cmpb	$0x0, (%r15)
    10af:      	je	0x1135 <cil_to_host+0xa5>
    10b5:      	movzbl	(%r15), %r12d
    10b9:      	movq	0x50(%rbx), %rdx
    10bd:      	movq	(%rip), %rax            # 0x10c4 <cil_to_host+0x34>
    10c4:      	movzbl	(%rax), %esi
    10c7:      	movq	0xd0(%rbx), %rcx
    10ce:      	cmpb	$0x0, (%rax)
    10d1:      	je	0x10ed <cil_to_host+0x5d>
    10d3:      	addq	%rcx, %rsi
    10d6:      	cmpq	%rdx, %rsi
    10d9:      	ja	0x110e <cil_to_host+0x7e>
    10db:      	movzwl	0xc(%rcx), %esi
    10df:      	cmpw	$0x6, %si
    10e3:      	jb	0x110e <cil_to_host+0x7e>
    10e5:      	cmpw	$0x8, %si
    10e9:      	je	0x10fa <cil_to_host+0x6a>
    10eb:      	jmp	0x110e <cil_to_host+0x7e>
    10ed:      	movzwl	0xb4(%rbx), %esi
    10f4:      	cmpw	$0x8, %si
    10f8:      	jne	0x110e <cil_to_host+0x7e>
    10fa:      	movzbl	(%rax), %esi
    10fd:      	leaq	(%rcx,%rsi), %rdi
    1101:      	addq	$0x14, %rdi
    1105:      	cmpq	%rdx, %rdi
    1108:      	jbe	0x13f2 <cil_to_host+0x362>
    110e:      	movl	$0x0, 0x20(%rsp)
    1116:      	movl	$0x1, %eax
    111b:      	movq	(%rip), %rdi            # 0x1122 <cil_to_host+0x92>
    1122:      	leaq	0x20(%rsp), %rsi
    1127:      	callq	*%rax
    1129:      	testq	%rax, %rax
    112c:      	je	0x1135 <cil_to_host+0xa5>
    112e:      	movq	$0x0, (%rax)
    1135:      	movq	(%rip), %rax            # 0x113c <cil_to_host+0xac>
    113c:      	movzbl	(%rax), %edx
    113f:      	movl	0xa8(%rbx), %eax
    1145:      	movl	%eax, %ecx
    1147:      	andl	$0xf00, %ecx            # imm = 0xF00
    114d:      	testb	%dl, %dl
    114f:      	je	0x1220 <cil_to_host+0x190>
    1155:      	cmpl	$0xf00, %ecx            # imm = 0xF00
    115b:      	jne	0x1220 <cil_to_host+0x190>
    1161:      	movzbl	%al, %edx
    1164:      	movq	(%rip), %rcx            # 0x116b <cil_to_host+0xdb>
    116b:      	movl	(%rcx), %esi
    116d:      	movl	$0x7fffff00, %edi       # imm = 0x7FFFFF00
    1172:      	bzhil	%esi, %edi, %esi
    1177:      	movl	(%rcx), %edi
    1179:      	negb	%dil
    117c:      	shlxl	%edi, %esi, %esi
    1181:      	andl	%eax, %esi
    1183:      	movl	(%rcx), %edi
    1185:      	negb	%dil
    1188:      	shrxl	%edi, %esi, %esi
    118d:      	orl	%edx, %esi
    118f:      	shrl	$0x10, %eax
    1192:      	movl	(%rcx), %edx
    1194:      	movb	$0x18, %dil
    1197:      	movb	$0x18, %r8b
    119a:      	subb	%dl, %r8b
    119d:      	bzhil	%r8d, %eax, %edx
    11a2:      	movl	(%rcx), %eax
    11a4:      	subb	%al, %dil
    11a7:      	shlxl	%edi, %esi, %eax
    11ac:      	orl	%edx, %eax
    11ae:      	movl	$0xffffffff, %r14d      # imm = 0xFFFFFFFF
    11b4:      	movzwl	%bp, %ecx
    11b7:      	cmpl	$0x200, %ecx            # imm = 0x200
    11bd:      	je	0x123c <cil_to_host+0x1ac>
    11bf:      	movq	(%rip), %rax            # 0x11c6 <cil_to_host+0x136>
    11c6:      	movl	(%rax), %eax
    11c8:      	cmpb	$0x0, (%r15)
    11cc:      	je	0x11e9 <cil_to_host+0x159>
    11ce:      	movl	$0x0, 0x20(%rsp)
    11d6:      	movl	$0x1, %eax
    11db:      	movq	(%rip), %rdi            # 0x11e2 <cil_to_host+0x152>
    11e2:      	leaq	0x20(%rsp), %rsi
    11e7:      	callq	*%rax
    11e9:      	movl	0x70(%rbx), %ebx
    11ec:      	addq	$0x6f60201, %r14        # imm = 0x6F60201
    11f3:      	movq	%r14, 0x10(%rsp)
    11f8:      	movl	$0x1, %eax
    11fd:      	movq	(%rip), %rdi            # 0x1204 <cil_to_host+0x174>
    1204:      	leaq	0x10(%rsp), %rsi
    1209:      	callq	*%rax
    120b:      	testq	%rax, %rax
    120e:      	je	0x1374 <cil_to_host+0x2e4>
    1214:      	incq	(%rax)
    1217:      	addq	%rbx, 0x8(%rax)
    121b:      	jmp	0x139c <cil_to_host+0x30c>
    1220:      	cmpl	$0x200, %ecx            # imm = 0x200
    1226:      	cmovel	%eax, %ebp
    1229:      	xorl	%eax, %eax
    122b:      	movl	$0xffffffff, %r14d      # imm = 0xFFFFFFFF
    1231:      	movzwl	%bp, %ecx
    1234:      	cmpl	$0x200, %ecx            # imm = 0x200
    123a:      	jne	0x11bf <cil_to_host+0x12f>
    123c:      	movl	$0x0, 0x30(%rbx)
    1243:      	movq	(%rip), %rcx            # 0x124a <cil_to_host+0x1ba>
    124a:      	movzbl	(%rcx), %ecx
    124d:      	cmpl	$0x10000, %ebp          # imm = 0x10000
    1253:      	jb	0x12eb <cil_to_host+0x25b>
    1259:      	testb	%cl, %cl
    125b:      	je	0x12eb <cil_to_host+0x25b>
    1261:      	movq	0x50(%rbx), %rdx
    1265:      	movq	(%rip), %rcx            # 0x126c <cil_to_host+0x1dc>
    126c:      	movzbl	(%rcx), %edi
    126f:      	movq	0xd0(%rbx), %rsi
    1276:      	cmpb	$0x0, (%rcx)
    1279:      	je	0x128f <cil_to_host+0x1ff>
    127b:      	addq	%rsi, %rdi
    127e:      	movl	$0xa6, %ecx
    1283:      	cmpq	%rdx, %rdi
    1286:      	ja	0x1294 <cil_to_host+0x204>
    1288:      	cmpw	$0x6, 0xc(%rsi)
    128d:      	jb	0x1294 <cil_to_host+0x204>
    128f:      	movl	$0x8b, %ecx
    1294:      	movl	%eax, 0x30(%rbx)
    1297:      	movl	$0x0, 0x34(%rbx)
    129e:      	movl	%ecx, 0x38(%rbx)
    12a1:      	movabsq	$0x6f1010200000000, %rax # imm = 0x6F1010200000000
    12ab:      	movq	%rax, 0x3c(%rbx)
    12af:      	movl	0x70(%rbx), %r15d
    12b3:      	addq	$0x6f10101, %r14        # imm = 0x6F10101
    12ba:      	movq	%r14, 0x10(%rsp)
    12bf:      	movb	%cl, 0x10(%rsp)
    12c3:      	movl	$0x1, %eax
    12c8:      	movq	(%rip), %rdi            # 0x12cf <cil_to_host+0x23f>
    12cf:      	leaq	0x10(%rsp), %rsi
    12d4:      	callq	*%rax
    12d6:      	testq	%rax, %rax
    12d9:      	je	0x13a0 <cil_to_host+0x310>
    12df:      	incq	(%rax)
    12e2:      	addq	%r15, 0x8(%rax)
    12e6:      	jmp	0x13c8 <cil_to_host+0x338>
    12eb:      	movl	%ebp, %eax
    12ed:      	shrl	$0x10, %eax
    12f0:      	movl	0x70(%rbx), %ecx
    12f3:      	movq	(%rip), %rdx            # 0x12fa <cil_to_host+0x26a>
    12fa:      	movl	(%rdx), %edx
    12fc:      	movw	$0x903, 0x20(%rsp)      # imm = 0x903
    1303:      	cmpl	%edx, %ecx
    1305:      	movq	(%rip), %rsi            # 0x130c <cil_to_host+0x27c>
    130c:      	movzwl	(%rsi), %esi
    130f:      	movw	%si, 0x22(%rsp)
    1314:      	cmovbl	%ecx, %edx
    1317:      	movl	0x98(%rbx), %esi
    131d:      	movl	%esi, 0x24(%rsp)
    1321:      	movl	%ecx, 0x28(%rsp)
    1325:      	movw	%dx, 0x2c(%rsp)
    132a:      	movw	$0x1, 0x2e(%rsp)
    1331:      	movl	%eax, 0x30(%rsp)
    1335:      	movl	$0x0, 0x34(%rsp)
    133d:      	movl	$0x19, %eax
    1342:      	shlq	$0x20, %rdx
    1346:      	orq	%r14, %rdx
    1349:      	movq	(%rip), %rsi            # 0x1350 <cil_to_host+0x2c0>
    1350:      	leaq	0x20(%rsp), %rcx
    1355:      	movq	%rbx, %rdi
    1358:      	movl	$0x18, %r8d
    135e:      	callq	*%rax
    1360:      	movl	%ebp, 0xa8(%rbx)
    1366:      	movl	$0x20, %eax
    136b:      	movq	%rbx, %rdi
    136e:      	xorl	%esi, %esi
    1370:      	callq	*%rax
    1372:      	jmp	0x139c <cil_to_host+0x30c>
    1374:      	movq	$0x1, 0x20(%rsp)
    137d:      	movq	%rbx, 0x28(%rsp)
    1382:      	movl	$0x2, %eax
    1387:      	movq	(%rip), %rdi            # 0x138e <cil_to_host+0x2fe>
    138e:      	leaq	0x10(%rsp), %rsi
    1393:      	leaq	0x20(%rsp), %rdx
    1398:      	xorl	%ecx, %ecx
    139a:      	callq	*%rax
    139c:      	xorl	%eax, %eax
    139e:      	jmp	0x13e3 <cil_to_host+0x353>
    13a0:      	movq	$0x1, 0x20(%rsp)
    13a9:      	movq	%r15, 0x28(%rsp)
    13ae:      	movl	$0x2, %eax
    13b3:      	movq	(%rip), %rdi            # 0x13ba <cil_to_host+0x32a>
    13ba:      	leaq	0x10(%rsp), %rsi
    13bf:      	leaq	0x20(%rsp), %rdx
    13c4:      	xorl	%ecx, %ecx
    13c6:      	callq	*%rax
    13c8:      	movl	$0xc, %eax
    13cd:      	movq	(%rip), %rsi            # 0x13d4 <cil_to_host+0x344>
    13d4:      	movq	%rbx, %rdi
    13d7:      	movl	$0x1, %edx
    13dc:      	callq	*%rax
    13de:      	movl	$0x2, %eax
    13e3:      	addq	$0x38, %rsp
    13e7:      	popq	%rbx
    13e8:      	popq	%r12
    13ea:      	popq	%r13
    13ec:      	popq	%r14
    13ee:      	popq	%r15
    13f0:      	popq	%rbp
    13f1:      	retq
    13f2:      	addq	%rsi, %rcx
    13f5:      	movzbl	(%rcx), %r13d
    13f9:      	movl	%r13d, %ecx
    13fc:      	andb	$0xe, %cl
    13ff:      	cmpb	$0x6, %cl
    1402:      	jb	0x15c4 <cil_to_host+0x534>
    1408:      	movzbl	(%rax), %r14d
    140c:      	shll	$0x2, %r13d
    1410:      	andl	$0x3c, %r13d
    1414:      	je	0x15c4 <cil_to_host+0x534>
    141a:      	leal	0x14(%r14), %esi
    141e:      	movl	$0x1a, %eax
    1423:      	leaq	0x10(%rsp), %rdx
    1428:      	movq	%rbx, %rdi
    142b:      	movq	%rsi, 0x18(%rsp)
    1430:      	movl	$0x1, %ecx
    1435:      	callq	*%rax
    1437:      	testl	%eax, %eax
    1439:      	js	0x110e <cil_to_host+0x7e>
    143f:      	movzbl	0x10(%rsp), %eax
    1444:      	testl	%eax, %eax
    1446:      	je	0x15c4 <cil_to_host+0x534>
    144c:      	cmpl	$0x1, %eax
    144f:      	jne	0x145a <cil_to_host+0x3ca>
    1451:      	leal	0x15(%r14), %eax
    1455:      	jmp	0x14e0 <cil_to_host+0x450>
    145a:      	movl	$0x1a, %eax
    145f:      	leal	0x15(%r14), %esi
    1463:      	leaq	0xf(%rsp), %rdx
    1468:      	movq	%rbx, %rdi
    146b:      	movl	$0x1, %ecx
    1470:      	callq	*%rax
    1472:      	testl	%eax, %eax
    1474:      	js	0x110e <cil_to_host+0x7e>
    147a:      	cmpb	%r12b, 0x10(%rsp)
    147f:      	jne	0x14d1 <cil_to_host+0x441>
    1481:      	movzbl	0xf(%rsp), %eax
    1486:      	cmpl	$0xa, %eax
    1489:      	je	0x1620 <cil_to_host+0x590>
    148f:      	cmpl	$0x6, %eax
    1492:      	je	0x15f3 <cil_to_host+0x563>
    1498:      	cmpl	$0x4, %eax
    149b:      	jne	0x110e <cil_to_host+0x7e>
    14a1:      	movl	$0x1a, %eax
    14a6:      	movq	0x18(%rsp), %rsi
    14ab:      	addl	$0x2, %esi
    14ae:      	leaq	0x20(%rsp), %rdx
    14b3:      	movq	%rbx, %rdi
    14b6:      	movl	$0x2, %ecx
    14bb:      	callq	*%rax
    14bd:      	xorl	%r14d, %r14d
    14c0:      	testl	%eax, %eax
    14c2:      	movbew	0x20(%rsp), %cx
    14c9:      	movzwl	%cx, %ecx
    14cc:      	jmp	0x1648 <cil_to_host+0x5b8>
    14d1:      	movzbl	0xf(%rsp), %eax
    14d6:      	movq	0x18(%rsp), %rcx
    14db:      	addl	%eax, %ecx
    14dd:      	movq	%rcx, %rax
    14e0:      	addl	%r13d, %r14d
    14e3:      	addl	$0x14, %r14d
    14e7:      	movq	%rax, 0x18(%rsp)
    14ec:      	cmpl	%r14d, %eax
    14ef:      	jae	0x15c4 <cil_to_host+0x534>
    14f5:      	movl	$0x1a, %eax
    14fa:      	leaq	0x10(%rsp), %rdx
    14ff:      	movq	%rbx, %rdi
    1502:      	movq	0x18(%rsp), %rsi
    1507:      	movl	$0x1, %ecx
    150c:      	callq	*%rax
    150e:      	testl	%eax, %eax
    1510:      	js	0x110e <cil_to_host+0x7e>
    1516:      	movzbl	0x10(%rsp), %eax
    151b:      	testl	%eax, %eax
    151d:      	je	0x15c4 <cil_to_host+0x534>
    1523:      	cmpl	$0x1, %eax
    1526:      	je	0x155c <cil_to_host+0x4cc>
    1528:      	movl	$0x1a, %eax
    152d:      	movq	0x18(%rsp), %rcx
    1532:      	leal	0x1(%rcx), %esi
    1535:      	leaq	0xf(%rsp), %rdx
    153a:      	movq	%rbx, %rdi
    153d:      	movl	$0x1, %ecx
    1542:      	callq	*%rax
    1544:      	testl	%eax, %eax
    1546:      	js	0x110e <cil_to_host+0x7e>
    154c:      	cmpb	%r12b, 0x10(%rsp)
    1551:      	je	0x1481 <cil_to_host+0x3f1>
    1557:      	movzbl	0xf(%rsp), %eax
    155c:      	movq	0x18(%rsp), %rcx
    1561:      	addl	%eax, %ecx
    1563:      	movq	%rcx, 0x18(%rsp)
    1568:      	cmpl	%r14d, %ecx
    156b:      	jae	0x15c4 <cil_to_host+0x534>
    156d:      	movl	$0x1a, %eax
    1572:      	leaq	0x10(%rsp), %rdx
    1577:      	movq	%rbx, %rdi
    157a:      	movq	0x18(%rsp), %rsi
    157f:      	movl	$0x1, %ecx
    1584:      	callq	*%rax
    1586:      	testl	%eax, %eax
    1588:      	js	0x110e <cil_to_host+0x7e>
    158e:      	cmpb	$0x2, 0x10(%rsp)
    1593:      	jb	0x15c4 <cil_to_host+0x534>
    1595:      	movl	$0x1a, %eax
    159a:      	movq	0x18(%rsp), %rcx
    159f:      	leal	0x1(%rcx), %esi
    15a2:      	leaq	0xf(%rsp), %rdx
    15a7:      	movq	%rbx, %rdi
    15aa:      	movl	$0x1, %ecx
    15af:      	callq	*%rax
    15b1:      	testl	%eax, %eax
    15b3:      	js	0x110e <cil_to_host+0x7e>
    15b9:      	cmpb	%r12b, 0x10(%rsp)
    15be:      	je	0x1481 <cil_to_host+0x3f1>
    15c4:      	xorl	%r14d, %r14d
    15c7:      	movl	$0x0, 0x20(%rsp)
    15cf:      	movl	$0x1, %eax
    15d4:      	movq	(%rip), %rdi            # 0x15db <cil_to_host+0x54b>
    15db:      	leaq	0x20(%rsp), %rsi
    15e0:      	callq	*%rax
    15e2:      	testq	%rax, %rax
    15e5:      	je	0x1135 <cil_to_host+0xa5>
    15eb:      	movq	%r14, (%rax)
    15ee:      	jmp	0x1135 <cil_to_host+0xa5>
    15f3:      	movl	$0x1a, %eax
    15f8:      	movq	0x18(%rsp), %rsi
    15fd:      	addl	$0x2, %esi
    1600:      	leaq	0x20(%rsp), %rdx
    1605:      	movq	%rbx, %rdi
    1608:      	movl	$0x4, %ecx
    160d:      	callq	*%rax
    160f:      	xorl	%ecx, %ecx
    1611:      	testl	%eax, %eax
    1613:      	movbel	0x20(%rsp), %r14d
    161a:      	cmovsl	%ecx, %r14d
    161e:      	jmp	0x164c <cil_to_host+0x5bc>
    1620:      	movl	$0x1a, %eax
    1625:      	movq	0x18(%rsp), %rsi
    162a:      	addl	$0x2, %esi
    162d:      	leaq	0x20(%rsp), %rdx
    1632:      	movq	%rbx, %rdi
    1635:      	movl	$0x8, %ecx
    163a:      	callq	*%rax
    163c:      	xorl	%r14d, %r14d
    163f:      	testl	%eax, %eax
    1641:      	movbeq	0x20(%rsp), %rcx
    1648:      	cmovnsq	%rcx, %r14
    164c:      	testl	%eax, %eax
    164e:      	jns	0x15c7 <cil_to_host+0x537>
    1654:      	jmp	0x110e <cil_to_host+0x7e>
    1659:      	nopl	(%rax)

0000000000001660 <cil_host_policy>:
    1660:      	xorl	%eax, %eax
    1662:      	retq
