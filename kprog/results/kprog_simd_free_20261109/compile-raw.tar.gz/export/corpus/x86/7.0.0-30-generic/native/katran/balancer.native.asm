
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/katran/balancer.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <jhash_2words>:
       0:      	addl	$0xe0adc0f7, %edi       # imm = 0xE0ADC0F7
       6:      	addl	$0xe0adc0f7, %esi       # imm = 0xE0ADC0F7
       c:      	movl	%esi, %eax
       e:      	xorl	$0xe0adc0f7, %eax       # imm = 0xE0ADC0F7
      13:      	rorxl	$0x12, %esi, %ecx
      19:      	subl	%ecx, %eax
      1b:      	xorl	%eax, %edi
      1d:      	rorxl	$0x15, %eax, %ecx
      23:      	subl	%ecx, %edi
      25:      	xorl	%edi, %esi
      27:      	rorxl	$0x7, %edi, %ecx
      2d:      	subl	%ecx, %esi
      2f:      	xorl	%esi, %eax
      31:      	rorxl	$0x10, %esi, %ecx
      37:      	subl	%ecx, %eax
      39:      	xorl	%eax, %edi
      3b:      	rorxl	$0x1c, %eax, %ecx
      41:      	subl	%ecx, %edi
      43:      	xorl	%edi, %esi
      45:      	rorxl	$0x12, %edi, %ecx
      4b:      	subl	%ecx, %esi
      4d:      	xorl	%esi, %eax
      4f:      	rorxl	$0x8, %esi, %ecx
      55:      	subl	%ecx, %eax
      57:      	retq
      58:      	nopl	(%rax,%rax)

0000000000000060 <jhash>:
      60:      	movl	(%rdi), %eax
      62:      	movl	0x4(%rdi), %ecx
      65:      	leal	-0x21523f01(%rcx), %edx
      6b:      	movl	0x8(%rdi), %esi
      6e:      	subl	%esi, %eax
      70:      	leal	-0x21523f01(%rsi), %r8d
      77:      	rorxl	$0x1c, %r8d, %r8d
      7d:      	xorl	%eax, %r8d
      80:      	subl	%r8d, %edx
      83:      	rorxl	$0x1a, %r8d, %eax
      89:      	xorl	%edx, %eax
      8b:      	addl	%esi, %ecx
      8d:      	addl	$0xbd5b81fe, %ecx       # imm = 0xBD5B81FE
      93:      	addl	%ecx, %r8d
      96:      	leal	(%rax,%r8), %esi
      9a:      	subl	%eax, %ecx
      9c:      	rorxl	$0x18, %eax, %r9d
      a2:      	xorl	%ecx, %r9d
      a5:      	subl	%r9d, %r8d
      a8:      	rorxl	$0x10, %r9d, %edx
      ae:      	xorl	%r8d, %edx
      b1:      	addl	%esi, %r9d
      b4:      	subl	%edx, %esi
      b6:      	rorxl	$0xd, %edx, %ecx
      bc:      	xorl	%esi, %ecx
      be:      	addl	%r9d, %edx
      c1:      	leal	(%rcx,%rdx), %eax
      c4:      	subl	%ecx, %r9d
      c7:      	rorxl	$0x1c, %ecx, %ecx
      cd:      	xorl	%r9d, %ecx
      d0:      	movzbl	0xf(%rdi), %esi
      d4:      	shll	$0x18, %esi
      d7:      	movzbl	0xe(%rdi), %r8d
      dc:      	shll	$0x10, %r8d
      e0:      	addl	%esi, %r8d
      e3:      	movzbl	0xd(%rdi), %r9d
      e8:      	shll	$0x8, %r9d
      ec:      	addl	%r8d, %r9d
      ef:      	movzbl	0xc(%rdi), %esi
      f3:      	addl	%r9d, %esi
      f6:      	addl	%edx, %esi
      f8:      	xorl	%eax, %ecx
      fa:      	rorxl	$0x12, %eax, %edx
     100:      	subl	%edx, %ecx
     102:      	xorl	%ecx, %esi
     104:      	rorxl	$0x15, %ecx, %edx
     10a:      	subl	%edx, %esi
     10c:      	xorl	%esi, %eax
     10e:      	rorxl	$0x7, %esi, %edx
     114:      	subl	%edx, %eax
     116:      	xorl	%eax, %ecx
     118:      	rorxl	$0x10, %eax, %edx
     11e:      	subl	%edx, %ecx
     120:      	xorl	%ecx, %esi
     122:      	rorxl	$0x1c, %ecx, %edx
     128:      	subl	%edx, %esi
     12a:      	xorl	%esi, %eax
     12c:      	rorxl	$0x12, %esi, %edx
     132:      	subl	%edx, %eax
     134:      	rorxl	$0x8, %eax, %edx
     13a:      	xorl	%ecx, %eax
     13c:      	subl	%edx, %eax
     13e:      	retq

Disassembly of section xdp:

0000000000000000 <balancer_ingress>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xb8, %rsp
      11:      	movq	(%rdi), %r12
      14:      	movq	0x8(%rdi), %r15
      18:      	leaq	0xe(%r12), %rax
      1d:      	movl	$0x1, %ebx
      22:      	cmpq	%r15, %rax
      25:      	ja	0x1bad <balancer_ingress+0x1bad>
      2b:      	movq	%rdi, %r14
      2e:      	movl	$0x210, 0x94(%rsp)      # imm = 0x210
      39:      	movq	(%rip), %rdi            # 0x40 <balancer_ingress+0x40>
      40:      	leaq	0x94(%rsp), %rsi
      48:      	movl	$0x1, %eax
      4d:      	callq	*%rax
      4f:      	testq	%rax, %rax
      52:      	je	0x1bad <balancer_ingress+0x1bad>
      58:      	subq	%r12, %r15
      5b:      	incq	(%rax)
      5e:      	addq	%r15, 0x8(%rax)
      62:      	movzwl	0xc(%r12), %eax
      68:      	cmpl	$0xdd86, %eax           # imm = 0xDD86
      6d:      	je	0x1cf <balancer_ingress+0x1cf>
      73:      	cmpl	$0x8, %eax
      76:      	jne	0x1b67 <balancer_ingress+0x1b67>
      7c:      	movq	(%r14), %r12
      7f:      	movq	0x8(%r14), %r9
      83:      	movq	$0x0, 0x68(%rsp)
      8c:      	movq	$0x0, 0x60(%rsp)
      95:      	movq	$0x0, 0x58(%rsp)
      9e:      	movq	$0x0, 0x50(%rsp)
      a7:      	movq	$0x0, 0x48(%rsp)
      b0:      	movq	$0x0, 0x40(%rsp)
      b9:      	movl	$0x0, 0x90(%rsp)
      c4:      	movq	$0x0, 0x88(%rsp)
      d0:      	movq	$0x0, 0x80(%rsp)
      dc:      	movl	$0x0, 0xa0(%rsp)
      e7:      	leaq	0x22(%r12), %rbp
      ec:      	cmpq	%r9, %rbp
      ef:      	ja	0x1b43 <balancer_ingress+0x1b43>
      f5:      	movzbl	0xe(%r12), %eax
      fb:      	andb	$0xf, %al
      fd:      	cmpb	$0x5, %al
      ff:      	jne	0x1b43 <balancer_ingress+0x1b43>
     105:      	movzbl	0xf(%r12), %eax
     10b:      	movb	%al, 0x6d(%rsp)
     10f:      	movzbl	0x17(%r12), %eax
     115:      	movb	%al, 0x64(%rsp)
     119:      	movzwl	0x14(%r12), %ecx
     11f:      	testl	$0xff3f, %ecx           # imm = 0xFF3F
     125:      	jne	0x1b43 <balancer_ingress+0x1b43>
     12b:      	movzwl	0x10(%r12), %r8d
     131:      	cmpb	$0x1, %al
     133:      	jne	0x516 <balancer_ingress+0x516>
     139:      	leaq	0x2a(%r12), %r13
     13e:      	cmpq	%r9, %r13
     141:      	ja	0x1b43 <balancer_ingress+0x1b43>
     147:      	movzbl	(%rbp), %eax
     14b:      	cmpl	$0x3, %eax
     14e:      	je	0x9b3 <balancer_ingress+0x9b3>
     154:      	movl	$0x2, %r13d
     15a:      	cmpl	$0x8, %eax
     15d:      	jne	0x1b49 <balancer_ingress+0x1b49>
     163:      	movb	$0x0, 0x22(%r12)
     169:      	addw	$0x8, 0x24(%r12)
     170:      	movzwl	%r8w, %eax
     174:      	movb	$0x40, 0x16(%r12)
     17a:      	movl	0x1a(%r12), %edx
     17f:      	movl	0x1e(%r12), %esi
     184:      	movl	%edx, 0x1e(%r12)
     189:      	movl	%esi, 0x1a(%r12)
     18e:      	movzwl	0xe(%r12), %edi
     194:      	movzwl	0x12(%r12), %r8d
     19a:      	addq	%rdi, %r8
     19d:      	addq	%rcx, %r8
     1a0:      	addq	%rax, %r8
     1a3:      	movzwl	0x16(%r12), %eax
     1a9:      	movzwl	%si, %ecx
     1ac:      	addq	%rax, %rcx
     1af:      	movzwl	0x1c(%r12), %eax
     1b5:      	addq	%rcx, %rax
     1b8:      	addq	%r8, %rax
     1bb:      	movzwl	%dx, %ecx
     1be:      	movzwl	0x20(%r12), %edx
     1c4:      	addq	%rcx, %rdx
     1c7:      	addq	%rax, %rdx
     1ca:      	jmp	0x40d <balancer_ingress+0x40d>
     1cf:      	movq	(%r14), %r12
     1d2:      	movq	0x8(%r14), %rbp
     1d6:      	movq	$0x0, 0x68(%rsp)
     1df:      	movq	$0x0, 0x60(%rsp)
     1e8:      	movq	$0x0, 0x58(%rsp)
     1f1:      	movq	$0x0, 0x50(%rsp)
     1fa:      	movq	$0x0, 0x48(%rsp)
     203:      	movq	$0x0, 0x40(%rsp)
     20c:      	movl	$0x0, 0x90(%rsp)
     217:      	movq	$0x0, 0x88(%rsp)
     223:      	movq	$0x0, 0x80(%rsp)
     22f:      	movl	$0x0, 0xa0(%rsp)
     23a:      	leaq	0x36(%r12), %r8
     23f:      	cmpq	%rbp, %r8
     242:      	ja	0x1b43 <balancer_ingress+0x1b43>
     248:      	movzbl	0x14(%r12), %eax
     24e:      	movb	%al, 0x64(%rsp)
     252:      	movzbl	0xe(%r12), %ecx
     258:      	shlb	$0x4, %cl
     25b:      	movb	%cl, 0x6d(%rsp)
     25f:      	movzbl	0xf(%r12), %edx
     265:      	shrb	$0x4, %dl
     268:      	orb	%cl, %dl
     26a:      	movb	%dl, 0x6d(%rsp)
     26e:      	cmpl	$0x2c, %eax
     271:      	je	0x1b43 <balancer_ingress+0x1b43>
     277:      	movbew	0x12(%r12), %di
     27f:      	cmpl	$0x3a, %eax
     282:      	jne	0x344 <balancer_ingress+0x344>
     288:      	leaq	0x3e(%r12), %rax
     28d:      	cmpq	%rbp, %rax
     290:      	ja	0x1b43 <balancer_ingress+0x1b43>
     296:      	movzbl	(%r8), %eax
     29a:      	cmpl	$0x1, %eax
     29d:      	je	0x66d <balancer_ingress+0x66d>
     2a3:      	cmpl	$0x2, %eax
     2a6:      	je	0x626 <balancer_ingress+0x626>
     2ac:      	movl	$0x2, %r13d
     2b2:      	cmpl	$0x80, %eax
     2b7:      	jne	0x1b49 <balancer_ingress+0x1b49>
     2bd:      	movb	$-0x7f, 0x36(%r12)
     2c3:      	decw	0x38(%r12)
     2c9:      	movb	$0x40, 0x15(%r12)
     2cf:      	movq	0x16(%r12), %rax
     2d4:      	movq	0x1e(%r12), %rcx
     2d9:      	movq	%rcx, 0x8(%rsp)
     2de:      	movq	%rax, (%rsp)
     2e2:      	movq	0x26(%r12), %rax
     2e7:      	movq	0x2e(%r12), %rcx
     2ec:      	movq	%rax, 0x16(%r12)
     2f1:      	movq	%rcx, 0x1e(%r12)
     2f6:      	movq	(%rsp), %rax
     2fa:      	movq	0x8(%rsp), %rcx
     2ff:      	movq	%rax, 0x26(%r12)
     304:      	movq	%rcx, 0x2e(%r12)
     309:      	movzwl	0xa(%r12), %eax
     30f:      	movw	%ax, 0x20(%rsp)
     314:      	movl	0x6(%r12), %eax
     319:      	movl	%eax, 0x1c(%rsp)
     31d:      	movl	(%r12), %eax
     321:      	movl	%eax, 0x6(%r12)
     326:      	movzwl	0x4(%r12), %eax
     32c:      	movw	%ax, 0xa(%r12)
     332:      	movl	0x1c(%rsp), %eax
     336:      	movl	%eax, (%r12)
     33a:      	movzwl	0x20(%rsp), %eax
     33f:      	jmp	0x496 <balancer_ingress+0x496>
     344:      	movq	0x16(%r12), %rcx
     349:      	movq	0x1e(%r12), %rdx
     34e:      	movq	%rdx, 0x48(%rsp)
     353:      	movq	%rcx, 0x40(%rsp)
     358:      	movq	0x26(%r12), %rcx
     35d:      	movq	0x2e(%r12), %rdx
     362:      	movq	%rcx, 0x50(%rsp)
     367:      	movq	%rdx, 0x58(%rsp)
     36c:      	cmpb	$0x1, %al
     36e:      	jne	0x4a7 <balancer_ingress+0x4a7>
     374:      	leaq	0x3e(%r12), %r13
     379:      	cmpq	%rbp, %r13
     37c:      	ja	0x1b43 <balancer_ingress+0x1b43>
     382:      	movzbl	(%r8), %eax
     386:      	cmpl	$0x3, %eax
     389:      	je	0x8a3 <balancer_ingress+0x8a3>
     38f:      	movl	$0x2, %r13d
     395:      	cmpl	$0x8, %eax
     398:      	jne	0x1b49 <balancer_ingress+0x1b49>
     39e:      	movb	$0x0, 0x22(%r12)
     3a4:      	addw	$0x8, 0x24(%r12)
     3ab:      	movb	$0x40, 0x16(%r12)
     3b1:      	movl	0x1a(%r12), %eax
     3b6:      	movl	0x1e(%r12), %ecx
     3bb:      	movl	%eax, 0x1e(%r12)
     3c0:      	movl	%ecx, 0x1a(%r12)
     3c5:      	movzwl	0xe(%r12), %edx
     3cb:      	movzwl	0x10(%r12), %esi
     3d1:      	addq	%rdx, %rsi
     3d4:      	movzwl	0x12(%r12), %edx
     3da:      	movzwl	0x14(%r12), %edi
     3e0:      	addq	%rdx, %rdi
     3e3:      	addq	%rsi, %rdi
     3e6:      	movzwl	0x16(%r12), %edx
     3ec:      	movzwl	%cx, %ecx
     3ef:      	addq	%rdx, %rcx
     3f2:      	addq	%rdi, %rcx
     3f5:      	movzwl	0x1c(%r12), %edx
     3fb:      	movzwl	%ax, %eax
     3fe:      	addq	%rdx, %rax
     401:      	movzwl	0x20(%r12), %edx
     407:      	addq	%rax, %rdx
     40a:      	addq	%rcx, %rdx
     40d:      	movq	%rdx, %rax
     410:      	shrq	$0x10, %rax
     414:      	movzwl	%dx, %ecx
     417:      	addq	%rax, %rcx
     41a:      	cmpq	$0x10000, %rdx          # imm = 0x10000
     421:      	cmovbq	%rdx, %rcx
     425:      	movq	%rcx, %rax
     428:      	shrq	$0x10, %rax
     42c:      	movzwl	%cx, %edx
     42f:      	addq	%rax, %rdx
     432:      	cmpq	$0x10000, %rcx          # imm = 0x10000
     439:      	cmovbq	%rcx, %rdx
     43d:      	movq	%rdx, %rax
     440:      	shrq	$0x10, %rax
     444:      	movzwl	%dx, %ecx
     447:      	addl	%ecx, %eax
     449:      	cmpq	$0x10000, %rdx          # imm = 0x10000
     450:      	cmovbl	%edx, %eax
     453:      	movl	%eax, %ecx
     455:      	shrl	$0x10, %ecx
     458:      	addl	%eax, %ecx
     45a:      	notl	%ecx
     45c:      	movw	%cx, 0x18(%r12)
     462:      	movzwl	0xa(%r12), %eax
     468:      	movw	%ax, 0x4(%rsp)
     46d:      	movl	0x6(%r12), %eax
     472:      	movl	%eax, (%rsp)
     475:      	movl	(%r12), %eax
     479:      	movl	%eax, 0x6(%r12)
     47e:      	movzwl	0x4(%r12), %eax
     484:      	movw	%ax, 0xa(%r12)
     48a:      	movl	(%rsp), %eax
     48d:      	movl	%eax, (%r12)
     491:      	movzwl	0x4(%rsp), %eax
     496:      	movw	%ax, 0x4(%r12)
     49c:      	movl	$0x3, %r13d
     4a2:      	jmp	0x1b49 <balancer_ingress+0x1b49>
     4a7:      	xorl	%ecx, %ecx
     4a9:      	movl	$0x2, %r13d
     4af:      	cmpb	$0x11, %al
     4b1:      	je	0x57e <balancer_ingress+0x57e>
     4b7:      	movzbl	%al, %edx
     4ba:      	cmpl	$0x6, %edx
     4bd:      	jne	0x1b49 <balancer_ingress+0x1b49>
     4c3:      	leaq	0x66(%r12), %rdx
     4c8:      	testb	$0x1, %cl
     4cb:      	cmoveq	%r8, %rdx
     4cf:      	leaq	0x14(%rdx), %rsi
     4d3:      	cmpq	%rbp, %rsi
     4d6:      	ja	0x1b43 <balancer_ingress+0x1b43>
     4dc:      	movl	%edi, 0x34(%rsp)
     4e0:      	movzwl	0xc(%rdx), %edi
     4e4:      	movl	%ecx, %esi
     4e6:      	testl	$0x200, %edi            # imm = 0x200
     4ec:      	je	0x4fd <balancer_ingress+0x4fd>
     4ee:      	movl	%ecx, %esi
     4f0:      	orb	$0x2, %sil
     4f4:      	movb	%sil, 0x6c(%rsp)
     4f9:      	movzwl	0xc(%rdx), %edi
     4fd:      	testl	$0x400, %edi            # imm = 0x400
     503:      	je	0x50e <balancer_ingress+0x50e>
     505:      	orb	$0x4, %sil
     509:      	movb	%sil, 0x6c(%rsp)
     50e:      	testb	$0x1, %cl
     511:      	jmp	0x59e <balancer_ingress+0x59e>
     516:      	movl	0x1a(%r12), %ecx
     51b:      	movl	%ecx, 0x40(%rsp)
     51f:      	movl	0x1e(%r12), %ecx
     524:      	movl	%ecx, 0x50(%rsp)
     528:      	cmpb	$0x3a, %al
     52a:      	jne	0x5ba <balancer_ingress+0x5ba>
     530:      	leaq	0x2a(%r12), %rax
     535:      	cmpq	%r9, %rax
     538:      	ja	0x1b43 <balancer_ingress+0x1b43>
     53e:      	movzbl	(%rbp), %eax
     542:      	cmpl	$0x1, %eax
     545:      	je	0xca7 <balancer_ingress+0xca7>
     54b:      	cmpl	$0x2, %eax
     54e:      	je	0xc60 <balancer_ingress+0xc60>
     554:      	movl	$0x2, %r13d
     55a:      	cmpl	$0x80, %eax
     55f:      	jne	0x1b49 <balancer_ingress+0x1b49>
     565:      	leaq	0x3e(%r12), %rax
     56a:      	movl	$0x1, %r13d
     570:      	cmpq	%r9, %rax
     573:      	jbe	0x2bd <balancer_ingress+0x2bd>
     579:      	jmp	0x1b49 <balancer_ingress+0x1b49>
     57e:      	leaq	0x66(%r12), %rdx
     583:      	testb	$0x1, %cl
     586:      	cmoveq	%r8, %rdx
     58a:      	leaq	0x8(%rdx), %rsi
     58e:      	cmpq	%rbp, %rsi
     591:      	ja	0x1b43 <balancer_ingress+0x1b43>
     597:      	testb	$0x1, %cl
     59a:      	movl	%edi, 0x34(%rsp)
     59e:      	movq	%r8, 0x38(%rsp)
     5a3:      	jne	0x6be <balancer_ingress+0x6be>
     5a9:      	movzwl	(%rdx), %ecx
     5ac:      	movw	%cx, 0x60(%rsp)
     5b1:      	movzwl	0x2(%rdx), %ecx
     5b5:      	jmp	0x6ca <balancer_ingress+0x6ca>
     5ba:      	xorl	%ecx, %ecx
     5bc:      	movl	$0x2, %r13d
     5c2:      	cmpb	$0x11, %al
     5c4:      	je	0x975 <balancer_ingress+0x975>
     5ca:      	movzbl	%al, %edx
     5cd:      	cmpl	$0x6, %edx
     5d0:      	jne	0x1b49 <balancer_ingress+0x1b49>
     5d6:      	leaq	0x3e(%r12), %rdx
     5db:      	testb	$0x1, %cl
     5de:      	cmoveq	%rbp, %rdx
     5e2:      	leaq	0x14(%rdx), %rsi
     5e6:      	cmpq	%r9, %rsi
     5e9:      	ja	0x1b43 <balancer_ingress+0x1b43>
     5ef:      	movzwl	0xc(%rdx), %edi
     5f3:      	movl	%ecx, %esi
     5f5:      	testl	$0x200, %edi            # imm = 0x200
     5fb:      	je	0x60c <balancer_ingress+0x60c>
     5fd:      	movl	%ecx, %esi
     5ff:      	orb	$0x2, %sil
     603:      	movb	%sil, 0x6c(%rsp)
     608:      	movzwl	0xc(%rdx), %edi
     60c:      	testl	$0x400, %edi            # imm = 0x400
     612:      	je	0x98e <balancer_ingress+0x98e>
     618:      	orb	$0x4, %sil
     61c:      	movb	%sil, 0x6c(%rsp)
     621:      	jmp	0x98e <balancer_ingress+0x98e>
     626:      	movq	%r8, 0x38(%rsp)
     62b:      	movl	%edi, %r13d
     62e:      	movl	$0x20c, (%rsp)          # imm = 0x20C
     635:      	movq	(%rip), %rdi            # 0x63c <balancer_ingress+0x63c>
     63c:      	movq	%rsp, %rsi
     63f:      	movl	$0x1, %eax
     644:      	callq	*%rax
     646:      	testq	%rax, %rax
     649:      	je	0x1b43 <balancer_ingress+0x1b43>
     64f:      	incq	(%rax)
     652:      	movbel	0x3a(%r12), %ecx
     659:      	cmpl	$0x4ff, %ecx            # imm = 0x4FF
     65f:      	movl	%r13d, %edi
     662:      	movq	0x38(%rsp), %r8
     667:      	ja	0x66d <balancer_ingress+0x66d>
     669:      	incq	0x8(%rax)
     66d:      	leaq	0x66(%r12), %rax
     672:      	cmpq	%rbp, %rax
     675:      	ja	0x1b43 <balancer_ingress+0x1b43>
     67b:      	movzbl	0x44(%r12), %eax
     681:      	movb	%al, 0x64(%rsp)
     685:      	movzbl	0x6c(%rsp), %ecx
     68a:      	orb	$0x1, %cl
     68d:      	movb	%cl, 0x6c(%rsp)
     691:      	movq	0x56(%r12), %rdx
     696:      	movq	0x5e(%r12), %rsi
     69b:      	movq	%rdx, 0x40(%rsp)
     6a0:      	movq	%rsi, 0x48(%rsp)
     6a5:      	movq	0x46(%r12), %rdx
     6aa:      	movq	0x4e(%r12), %rsi
     6af:      	movq	%rdx, 0x50(%rsp)
     6b4:      	movq	%rsi, 0x58(%rsp)
     6b9:      	jmp	0x4a9 <balancer_ingress+0x4a9>
     6be:      	movzwl	0x2(%rdx), %ecx
     6c2:      	movw	%cx, 0x60(%rsp)
     6c7:      	movzwl	(%rdx), %ecx
     6ca:      	movw	%cx, 0x62(%rsp)
     6cf:      	movq	0x50(%rsp), %rdx
     6d4:      	movq	0x58(%rsp), %rsi
     6d9:      	movq	%rsi, 0x88(%rsp)
     6e1:      	movq	%rdx, 0x80(%rsp)
     6e9:      	movw	%cx, 0x90(%rsp)
     6f1:      	movb	%al, 0x92(%rsp)
     6f8:      	movq	(%rip), %rdi            # 0x6ff <balancer_ingress+0x6ff>
     6ff:      	leaq	0x80(%rsp), %rsi
     707:      	movl	$0x1, %eax
     70c:      	callq	*%rax
     70e:      	testq	%rax, %rax
     711:      	je	0x937 <balancer_ingress+0x937>
     717:      	movq	%rbp, %rcx
     71a:      	subq	%r12, %rcx
     71d:      	movl	$0x1, %r13d
     723:      	cmpq	$0x5ea, %rcx            # imm = 0x5EA
     72a:      	jg	0x1b49 <balancer_ingress+0x1b49>
     730:      	movq	%rax, 0x28(%rsp)
     735:      	movl	$0x200, 0x9c(%rsp)      # imm = 0x200
     740:      	movq	(%rip), %rdi            # 0x747 <balancer_ingress+0x747>
     747:      	leaq	0x9c(%rsp), %rsi
     74f:      	movl	$0x1, %eax
     754:      	callq	*%rax
     756:      	testq	%rax, %rax
     759:      	je	0x1b43 <balancer_ingress+0x1b43>
     75f:      	movq	%rax, 0xb0(%rsp)
     767:      	incq	(%rax)
     76a:      	movq	0x28(%rsp), %r13
     76f:      	testb	$0x1, (%r13)
     774:      	je	0x77d <balancer_ingress+0x77d>
     776:      	movw	$0x0, 0x60(%rsp)
     77d:      	movl	0x4(%r13), %eax
     781:      	movl	%eax, 0x70(%rsp)
     785:      	movl	%eax, 0xa4(%rsp)
     78c:      	movl	$0x8, %eax
     791:      	callq	*%rax
     793:      	movl	%eax, 0x98(%rsp)
     79a:      	movq	(%rip), %rdi            # 0x7a1 <balancer_ingress+0x7a1>
     7a1:      	leaq	0x98(%rsp), %rsi
     7a9:      	movl	$0x1, %eax
     7ae:      	callq	*%rax
     7b0:      	movq	%rax, 0x78(%rsp)
     7b5:      	testq	%rax, %rax
     7b8:      	jne	0x7ef <balancer_ingress+0x7ef>
     7ba:      	movl	$0x203, (%rsp)          # imm = 0x203
     7c1:      	movq	(%rip), %rdi            # 0x7c8 <balancer_ingress+0x7c8>
     7c8:      	movq	%rsp, %rsi
     7cb:      	movl	$0x1, %eax
     7d0:      	callq	*%rax
     7d2:      	testq	%rax, %rax
     7d5:      	je	0x1b43 <balancer_ingress+0x1b43>
     7db:      	incq	(%rax)
     7de:      	movq	(%rip), %rax            # 0x7e5 <balancer_ingress+0x7e5>
     7e5:      	movq	%rax, 0x78(%rsp)
     7ea:      	movq	0x28(%rsp), %r13
     7ef:      	testb	$0x4, (%r13)
     7f4:      	je	0xe80 <balancer_ingress+0xe80>
     7fa:      	testb	$0x1, 0x6c(%rsp)
     7ff:      	jne	0xcfa <balancer_ingress+0xcfa>
     805:      	movl	$0x0, 0x1c(%rsp)
     80d:      	movq	(%rip), %rdi            # 0x814 <balancer_ingress+0x814>
     814:      	leaq	0x1c(%rsp), %rsi
     819:      	movl	$0x1, %eax
     81e:      	callq	*%rax
     820:      	testq	%rax, %rax
     823:      	je	0x1b43 <balancer_ingress+0x1b43>
     829:      	addq	$0x66, %r12
     82d:      	testb	$0x1, 0x6c(%rsp)
     832:      	cmoveq	0x38(%rsp), %r12
     838:      	leaq	0x9(%r12), %rdx
     83d:      	cmpq	%rbp, %rdx
     840:      	ja	0xe78 <balancer_ingress+0xe78>
     846:      	movzbl	0x8(%r12), %ecx
     84c:      	testb	%cl, %cl
     84e:      	js	0xd78 <balancer_ingress+0xd78>
     854:      	addq	$0x11, %r12
     858:      	cmpq	%rbp, %r12
     85b:      	ja	0xe78 <balancer_ingress+0xe78>
     861:      	movq	%rax, %rbp
     864:      	movzbl	(%rdx), %esi
     867:      	movl	%esi, %ecx
     869:      	shrl	$0x6, %ecx
     86c:      	cmpl	$0x3, %ecx
     86f:      	je	0xe24 <balancer_ingress+0xe24>
     875:      	cmpl	$0x2, %ecx
     878:      	je	0xe0e <balancer_ingress+0xe0e>
     87e:      	cmpl	$0x1, %ecx
     881:      	movq	%rbp, %rax
     884:      	jne	0xe78 <balancer_ingress+0xe78>
     88a:      	andl	$0x3f, %esi
     88d:      	shll	$0xa, %esi
     890:      	movzbl	0x1(%rdx), %eax
     894:      	leal	(%rsi,%rax,4), %eax
     897:      	movzbl	0x2(%rdx), %edx
     89b:      	shrb	$0x6, %dl
     89e:      	jmp	0xe41 <balancer_ingress+0xe41>
     8a3:      	cmpb	$0x4, 0x37(%r12)
     8a9:      	jne	0x8ed <balancer_ingress+0x8ed>
     8ab:      	movq	%r8, 0x38(%rsp)
     8b0:      	movl	%edi, 0x34(%rsp)
     8b4:      	movl	$0x20d, (%rsp)          # imm = 0x20D
     8bb:      	movq	(%rip), %rdi            # 0x8c2 <balancer_ingress+0x8c2>
     8c2:      	movq	%rsp, %rsi
     8c5:      	movl	$0x1, %eax
     8ca:      	callq	*%rax
     8cc:      	testq	%rax, %rax
     8cf:      	je	0x1b43 <balancer_ingress+0x1b43>
     8d5:      	incq	(%rax)
     8d8:      	cmpb	$0x4, 0x3c(%r12)
     8de:      	ja	0x8e4 <balancer_ingress+0x8e4>
     8e0:      	incq	0x8(%rax)
     8e4:      	movl	0x34(%rsp), %edi
     8e8:      	movq	0x38(%rsp), %r8
     8ed:      	leaq	0x52(%r12), %rax
     8f2:      	cmpq	%rbp, %rax
     8f5:      	ja	0x1b43 <balancer_ingress+0x1b43>
     8fb:      	movzbl	(%r13), %eax
     900:      	andb	$0xf, %al
     902:      	cmpb	$0x5, %al
     904:      	jne	0x1b43 <balancer_ingress+0x1b43>
     90a:      	movzbl	0x47(%r12), %eax
     910:      	movb	%al, 0x64(%rsp)
     914:      	movzbl	0x6c(%rsp), %ecx
     919:      	orb	$0x1, %cl
     91c:      	movb	%cl, 0x6c(%rsp)
     920:      	movl	0x4e(%r12), %edx
     925:      	movl	%edx, 0x40(%rsp)
     929:      	movl	0x4a(%r12), %edx
     92e:      	movl	%edx, 0x50(%rsp)
     932:      	jmp	0x4a9 <balancer_ingress+0x4a9>
     937:      	movw	$0x0, 0x90(%rsp)
     941:      	movq	(%rip), %rdi            # 0x948 <balancer_ingress+0x948>
     948:      	leaq	0x80(%rsp), %rsi
     950:      	movl	$0x1, %eax
     955:      	callq	*%rax
     957:      	testq	%rax, %rax
     95a:      	je	0x1b49 <balancer_ingress+0x1b49>
     960:      	testb	$-0x78, (%rax)
     963:      	jne	0x717 <balancer_ingress+0x717>
     969:      	movw	$0x0, 0x62(%rsp)
     970:      	jmp	0x717 <balancer_ingress+0x717>
     975:      	leaq	0x3e(%r12), %rdx
     97a:      	testb	$0x1, %cl
     97d:      	cmoveq	%rbp, %rdx
     981:      	leaq	0x8(%rdx), %rsi
     985:      	cmpq	%r9, %rsi
     988:      	ja	0x1b43 <balancer_ingress+0x1b43>
     98e:      	movq	%r9, 0x38(%rsp)
     993:      	movw	%r8w, 0x34(%rsp)
     999:      	testb	$0x1, %cl
     99c:      	jne	0xa4b <balancer_ingress+0xa4b>
     9a2:      	movzwl	(%rdx), %ecx
     9a5:      	movw	%cx, 0x60(%rsp)
     9aa:      	movzwl	0x2(%rdx), %ecx
     9ae:      	jmp	0xa57 <balancer_ingress+0xa57>
     9b3:      	cmpb	$0x4, 0x23(%r12)
     9b9:      	jne	0xa01 <balancer_ingress+0xa01>
     9bb:      	movq	%r9, 0x38(%rsp)
     9c0:      	movw	%r8w, 0x34(%rsp)
     9c6:      	movl	$0x20d, (%rsp)          # imm = 0x20D
     9cd:      	movq	(%rip), %rdi            # 0x9d4 <balancer_ingress+0x9d4>
     9d4:      	movq	%rsp, %rsi
     9d7:      	movl	$0x1, %eax
     9dc:      	callq	*%rax
     9de:      	testq	%rax, %rax
     9e1:      	je	0x1b43 <balancer_ingress+0x1b43>
     9e7:      	incq	(%rax)
     9ea:      	cmpb	$0x4, 0x28(%r12)
     9f0:      	ja	0x9f6 <balancer_ingress+0x9f6>
     9f2:      	incq	0x8(%rax)
     9f6:      	movzwl	0x34(%rsp), %r8d
     9fc:      	movq	0x38(%rsp), %r9
     a01:      	leaq	0x3e(%r12), %rax
     a06:      	cmpq	%r9, %rax
     a09:      	ja	0x1b43 <balancer_ingress+0x1b43>
     a0f:      	movzbl	(%r13), %eax
     a14:      	andb	$0xf, %al
     a16:      	cmpb	$0x5, %al
     a18:      	jne	0x1b43 <balancer_ingress+0x1b43>
     a1e:      	movzbl	0x33(%r12), %eax
     a24:      	movb	%al, 0x64(%rsp)
     a28:      	movzbl	0x6c(%rsp), %ecx
     a2d:      	orb	$0x1, %cl
     a30:      	movb	%cl, 0x6c(%rsp)
     a34:      	movl	0x3a(%r12), %edx
     a39:      	movl	%edx, 0x40(%rsp)
     a3d:      	movl	0x36(%r12), %edx
     a42:      	movl	%edx, 0x50(%rsp)
     a46:      	jmp	0x5bc <balancer_ingress+0x5bc>
     a4b:      	movzwl	0x2(%rdx), %ecx
     a4f:      	movw	%cx, 0x60(%rsp)
     a54:      	movzwl	(%rdx), %ecx
     a57:      	movw	%cx, 0x62(%rsp)
     a5c:      	movl	0x50(%rsp), %edx
     a60:      	movl	%edx, 0x80(%rsp)
     a67:      	movw	%cx, 0x90(%rsp)
     a6f:      	movb	%al, 0x92(%rsp)
     a76:      	movq	(%rip), %rdi            # 0xa7d <balancer_ingress+0xa7d>
     a7d:      	leaq	0x80(%rsp), %rsi
     a85:      	movl	$0x1, %eax
     a8a:      	callq	*%rax
     a8c:      	testq	%rax, %rax
     a8f:      	je	0xc22 <balancer_ingress+0xc22>
     a95:      	movq	0x38(%rsp), %rcx
     a9a:      	subq	%r12, %rcx
     a9d:      	movl	$0x1, %r13d
     aa3:      	cmpq	$0x5ea, %rcx            # imm = 0x5EA
     aaa:      	jg	0x1b49 <balancer_ingress+0x1b49>
     ab0:      	movq	%rax, 0x28(%rsp)
     ab5:      	movl	$0x200, 0x9c(%rsp)      # imm = 0x200
     ac0:      	movq	(%rip), %rdi            # 0xac7 <balancer_ingress+0xac7>
     ac7:      	leaq	0x9c(%rsp), %rsi
     acf:      	movl	$0x1, %eax
     ad4:      	callq	*%rax
     ad6:      	testq	%rax, %rax
     ad9:      	je	0x1b43 <balancer_ingress+0x1b43>
     adf:      	movq	%rax, 0xb0(%rsp)
     ae7:      	incq	(%rax)
     aea:      	movq	0x28(%rsp), %r13
     aef:      	testb	$0x1, (%r13)
     af4:      	je	0xafd <balancer_ingress+0xafd>
     af6:      	movw	$0x0, 0x60(%rsp)
     afd:      	movl	0x4(%r13), %eax
     b01:      	movl	%eax, 0x70(%rsp)
     b05:      	movl	%eax, 0xa4(%rsp)
     b0c:      	movl	$0x8, %eax
     b11:      	callq	*%rax
     b13:      	movl	%eax, 0x98(%rsp)
     b1a:      	movq	(%rip), %rdi            # 0xb21 <balancer_ingress+0xb21>
     b21:      	leaq	0x98(%rsp), %rsi
     b29:      	movl	$0x1, %eax
     b2e:      	callq	*%rax
     b30:      	movq	%rax, 0x78(%rsp)
     b35:      	testq	%rax, %rax
     b38:      	jne	0xb6f <balancer_ingress+0xb6f>
     b3a:      	movl	$0x203, (%rsp)          # imm = 0x203
     b41:      	movq	(%rip), %rdi            # 0xb48 <balancer_ingress+0xb48>
     b48:      	movq	%rsp, %rsi
     b4b:      	movl	$0x1, %eax
     b50:      	callq	*%rax
     b52:      	testq	%rax, %rax
     b55:      	je	0x1b43 <balancer_ingress+0x1b43>
     b5b:      	incq	(%rax)
     b5e:      	movq	(%rip), %rax            # 0xb65 <balancer_ingress+0xb65>
     b65:      	movq	%rax, 0x78(%rsp)
     b6a:      	movq	0x28(%rsp), %r13
     b6f:      	testb	$0x4, (%r13)
     b74:      	je	0x1697 <balancer_ingress+0x1697>
     b7a:      	testb	$0x1, 0x6c(%rsp)
     b7f:      	jne	0xd39 <balancer_ingress+0xd39>
     b85:      	movl	$0x0, 0x1c(%rsp)
     b8d:      	movq	(%rip), %rdi            # 0xb94 <balancer_ingress+0xb94>
     b94:      	leaq	0x1c(%rsp), %rsi
     b99:      	movl	$0x1, %eax
     b9e:      	callq	*%rax
     ba0:      	testq	%rax, %rax
     ba3:      	je	0x1b43 <balancer_ingress+0x1b43>
     ba9:      	movq	%rax, %r13
     bac:      	addq	$0x3e, %r12
     bb0:      	testb	$0x1, 0x6c(%rsp)
     bb5:      	cmoveq	%rbp, %r12
     bb9:      	leaq	0x9(%r12), %rcx
     bbe:      	cmpq	0x38(%rsp), %rcx
     bc3:      	ja	0x168e <balancer_ingress+0x168e>
     bc9:      	movzbl	0x8(%r12), %eax
     bcf:      	testb	%al, %al
     bd1:      	js	0xdb5 <balancer_ingress+0xdb5>
     bd7:      	addq	$0x11, %r12
     bdb:      	cmpq	0x38(%rsp), %r12
     be0:      	ja	0x168e <balancer_ingress+0x168e>
     be6:      	movzbl	(%rcx), %edx
     be9:      	movl	%edx, %eax
     beb:      	shrl	$0x6, %eax
     bee:      	cmpl	$0x3, %eax
     bf1:      	je	0x1517 <balancer_ingress+0x1517>
     bf7:      	cmpl	$0x2, %eax
     bfa:      	je	0x1501 <balancer_ingress+0x1501>
     c00:      	cmpl	$0x1, %eax
     c03:      	jne	0x168e <balancer_ingress+0x168e>
     c09:      	andl	$0x3f, %edx
     c0c:      	shll	$0xa, %edx
     c0f:      	movzbl	0x1(%rcx), %esi
     c13:      	leal	(%rdx,%rsi,4), %edx
     c16:      	movzbl	0x2(%rcx), %ecx
     c1a:      	shrb	$0x6, %cl
     c1d:      	jmp	0x1534 <balancer_ingress+0x1534>
     c22:      	movw	$0x0, 0x90(%rsp)
     c2c:      	movq	(%rip), %rdi            # 0xc33 <balancer_ingress+0xc33>
     c33:      	leaq	0x80(%rsp), %rsi
     c3b:      	movl	$0x1, %eax
     c40:      	callq	*%rax
     c42:      	testq	%rax, %rax
     c45:      	je	0x1b49 <balancer_ingress+0x1b49>
     c4b:      	testb	$-0x78, (%rax)
     c4e:      	jne	0xa95 <balancer_ingress+0xa95>
     c54:      	movw	$0x0, 0x62(%rsp)
     c5b:      	jmp	0xa95 <balancer_ingress+0xa95>
     c60:      	movq	%r9, 0x38(%rsp)
     c65:      	movl	%r8d, %r13d
     c68:      	movl	$0x20c, (%rsp)          # imm = 0x20C
     c6f:      	movq	(%rip), %rdi            # 0xc76 <balancer_ingress+0xc76>
     c76:      	movq	%rsp, %rsi
     c79:      	movl	$0x1, %eax
     c7e:      	callq	*%rax
     c80:      	testq	%rax, %rax
     c83:      	je	0x1b43 <balancer_ingress+0x1b43>
     c89:      	incq	(%rax)
     c8c:      	movbel	0x26(%r12), %ecx
     c93:      	cmpl	$0x4ff, %ecx            # imm = 0x4FF
     c99:      	movl	%r13d, %r8d
     c9c:      	movq	0x38(%rsp), %r9
     ca1:      	ja	0xca7 <balancer_ingress+0xca7>
     ca3:      	incq	0x8(%rax)
     ca7:      	leaq	0x52(%r12), %rax
     cac:      	cmpq	%r9, %rax
     caf:      	ja	0x1b43 <balancer_ingress+0x1b43>
     cb5:      	movzbl	0x30(%r12), %eax
     cbb:      	movb	%al, 0x64(%rsp)
     cbf:      	leaq	0x50(%rsp), %rdx
     cc4:      	movzbl	0x6c(%rsp), %ecx
     cc9:      	orb	$0x1, %cl
     ccc:      	movb	%cl, 0x6c(%rsp)
     cd0:      	movq	0x42(%r12), %rsi
     cd5:      	movq	0x4a(%r12), %rdi
     cda:      	movq	%rdi, 0x48(%rsp)
     cdf:      	movq	%rsi, 0x40(%rsp)
     ce4:      	movq	0x32(%r12), %rsi
     ce9:      	movq	0x3a(%r12), %rdi
     cee:      	movq	%rsi, (%rdx)
     cf1:      	movq	%rdi, 0x8(%rdx)
     cf5:      	jmp	0x5bc <balancer_ingress+0x5bc>
     cfa:      	movl	$0x20b, (%rsp)          # imm = 0x20B
     d01:      	movq	(%rip), %rdi            # 0xd08 <balancer_ingress+0xd08>
     d08:      	movq	%rsp, %rsi
     d0b:      	movl	$0x1, %eax
     d10:      	callq	*%rax
     d12:      	testq	%rax, %rax
     d15:      	je	0x1b43 <balancer_ingress+0x1b43>
     d1b:      	incq	(%rax)
     d1e:      	movzbl	0x37(%r12), %ecx
     d24:      	addb	$-0x3, %cl
     d27:      	cmpb	$0x1, %cl
     d2a:      	ja	0xe7b <balancer_ingress+0xe7b>
     d30:      	incq	0x8(%rax)
     d34:      	jmp	0xe7b <balancer_ingress+0xe7b>
     d39:      	movl	$0x20b, (%rsp)          # imm = 0x20B
     d40:      	movq	(%rip), %rdi            # 0xd47 <balancer_ingress+0xd47>
     d47:      	movq	%rsp, %rsi
     d4a:      	movl	$0x1, %eax
     d4f:      	callq	*%rax
     d51:      	testq	%rax, %rax
     d54:      	je	0x1b43 <balancer_ingress+0x1b43>
     d5a:      	incq	(%rax)
     d5d:      	movzbl	0x23(%r12), %ecx
     d63:      	orl	$0x2, %ecx
     d66:      	cmpl	$0x3, %ecx
     d69:      	jne	0x1692 <balancer_ingress+0x1692>
     d6f:      	incq	0x8(%rax)
     d73:      	jmp	0x1692 <balancer_ingress+0x1692>
     d78:      	leaq	0x16(%r12), %rdx
     d7d:      	cmpq	%rbp, %rdx
     d80:      	ja	0xe78 <balancer_ingress+0xe78>
     d86:      	testb	$0x20, %cl
     d89:      	jne	0xdfa <balancer_ingress+0xdfa>
     d8b:      	incq	0x8(%rax)
     d8f:      	movl	0x70(%rsp), %eax
     d93:      	movl	%eax, (%rsp)
     d96:      	movq	(%rip), %rdi            # 0xd9d <balancer_ingress+0xd9d>
     d9d:      	movq	%rsp, %rsi
     da0:      	movl	$0x1, %eax
     da5:      	callq	*%rax
     da7:      	testq	%rax, %rax
     daa:      	jne	0xe78 <balancer_ingress+0xe78>
     db0:      	jmp	0xe7b <balancer_ingress+0xe7b>
     db5:      	leaq	0x16(%r12), %rcx
     dba:      	cmpq	0x38(%rsp), %rcx
     dbf:      	ja	0x168e <balancer_ingress+0x168e>
     dc5:      	testb	$0x20, %al
     dc7:      	jne	0x14e0 <balancer_ingress+0x14e0>
     dcd:      	incq	0x8(%r13)
     dd1:      	movl	0x70(%rsp), %eax
     dd5:      	movl	%eax, (%rsp)
     dd8:      	movq	(%rip), %rdi            # 0xddf <balancer_ingress+0xddf>
     ddf:      	movq	%rsp, %rsi
     de2:      	movl	$0x1, %eax
     de7:      	callq	*%rax
     de9:      	testq	%rax, %rax
     dec:      	je	0x1692 <balancer_ingress+0x1692>
     df2:      	incq	(%rax)
     df5:      	jmp	0x1692 <balancer_ingress+0x1692>
     dfa:      	cmpb	$0x7, 0xd(%r12)
     e00:      	jbe	0xe78 <balancer_ingress+0xe78>
     e02:      	addq	$0xe, %r12
     e06:      	movq	%r12, %rdx
     e09:      	jmp	0x861 <balancer_ingress+0x861>
     e0e:      	movzbl	0x1(%rdx), %esi
     e12:      	shll	$0x10, %esi
     e15:      	movzbl	0x2(%rdx), %eax
     e19:      	shll	$0x8, %eax
     e1c:      	orl	%esi, %eax
     e1e:      	movzbl	0x3(%rdx), %edx
     e22:      	jmp	0xe41 <balancer_ingress+0xe41>
     e24:      	movzbl	0x1(%rdx), %eax
     e28:      	shll	$0x18, %eax
     e2b:      	movzbl	0x2(%rdx), %esi
     e2f:      	shll	$0x10, %esi
     e32:      	orl	%eax, %esi
     e34:      	movzbl	0x3(%rdx), %eax
     e38:      	shll	$0x8, %eax
     e3b:      	orl	%esi, %eax
     e3d:      	movzbl	0x4(%rdx), %edx
     e41:      	movzbl	%dl, %r12d
     e45:      	orq	%rax, %r12
     e48:      	testl	%r12d, %r12d
     e4b:      	movq	%rbp, %rax
     e4e:      	jle	0xe78 <balancer_ingress+0xe78>
     e50:      	movq	%rbp, %rax
     e53:      	cmpq	$0x3, %rcx
     e57:      	je	0x144f <balancer_ingress+0x144f>
     e5d:      	cmpl	$0x2, %ecx
     e60:      	je	0x1449 <balancer_ingress+0x1449>
     e66:      	cmpl	$0x1, %ecx
     e69:      	jne	0x1455 <balancer_ingress+0x1455>
     e6f:      	addq	$0x38, %rax
     e73:      	jmp	0x1459 <balancer_ingress+0x1459>
     e78:      	incq	(%rax)
     e7b:      	movq	0x28(%rsp), %r13
     e80:      	movzwl	0x60(%rsp), %ecx
     e85:      	movl	%ecx, 0x38(%rsp)
     e89:      	testb	$0x2, 0x6c(%rsp)
     e8e:      	jne	0xed8 <balancer_ingress+0xed8>
     e90:      	testb	$0x2, (%r13)
     e95:      	jne	0xed8 <balancer_ingress+0xed8>
     e97:      	leaq	0x40(%rsp), %rsi
     e9c:      	movl	$0x1, %eax
     ea1:      	movq	0x78(%rsp), %rdi
     ea6:      	callq	*%rax
     ea8:      	testq	%rax, %rax
     eab:      	je	0xed4 <balancer_ingress+0xed4>
     ead:      	movq	%rax, %r13
     eb0:      	cmpb	$0x11, 0x64(%rsp)
     eb5:      	jne	0xee0 <balancer_ingress+0xee0>
     eb7:      	movl	$0x5, %eax
     ebc:      	callq	*%rax
     ebe:      	movq	%rax, %rcx
     ec1:      	subq	0x8(%r13), %rcx
     ec5:      	movabsq	$0x6fc23ac00, %rdx      # imm = 0x6FC23AC00
     ecf:      	cmpq	%rdx, %rcx
     ed2:      	jbe	0xedc <balancer_ingress+0xedc>
     ed4:      	xorl	%ebp, %ebp
     ed6:      	jmp	0xeff <balancer_ingress+0xeff>
     ed8:      	xorl	%ebp, %ebp
     eda:      	jmp	0xf04 <balancer_ingress+0xf04>
     edc:      	movq	%rax, 0x8(%r13)
     ee0:      	movl	(%r13), %eax
     ee4:      	movl	%eax, (%rsp)
     ee7:      	movl	%eax, 0x68(%rsp)
     eeb:      	movq	(%rip), %rdi            # 0xef2 <balancer_ingress+0xef2>
     ef2:      	movq	%rsp, %rsi
     ef5:      	movl	$0x1, %eax
     efa:      	callq	*%rax
     efc:      	movq	%rax, %rbp
     eff:      	movq	0x28(%rsp), %r13
     f04:      	cmpb	$0x11, 0x64(%rsp)
     f09:      	jne	0xfcc <balancer_ingress+0xfcc>
     f0f:      	testb	$0x2, 0x1(%r13)
     f14:      	je	0xfcc <balancer_ingress+0xfcc>
     f1a:      	movl	$0x202, (%rsp)          # imm = 0x202
     f21:      	movq	(%rip), %rdi            # 0xf28 <balancer_ingress+0xf28>
     f28:      	movq	%rsp, %rsi
     f2b:      	movl	$0x1, %eax
     f30:      	callq	*%rax
     f32:      	testq	%rax, %rax
     f35:      	je	0xfcc <balancer_ingress+0xfcc>
     f3b:      	movq	%rax, %r13
     f3e:      	movl	$0x5, %eax
     f43:      	callq	*%rax
     f45:      	movq	%rax, %rcx
     f48:      	subq	0x8(%r13), %rcx
     f4c:      	cmpq	$0x3b9aca01, %rcx       # imm = 0x3B9ACA01
     f53:      	jb	0xf63 <balancer_ingress+0xf63>
     f55:      	movq	$0x1, (%r13)
     f5d:      	movq	%rax, 0x8(%r13)
     f61:      	jmp	0xf76 <balancer_ingress+0xf76>
     f63:      	movq	(%r13), %rax
     f67:      	incq	%rax
     f6a:      	movq	%rax, (%r13)
     f6e:      	cmpq	$0x1e849, %rax          # imm = 0x1E849
     f74:      	jae	0xfcc <balancer_ingress+0xfcc>
     f76:      	movq	(%rip), %rdi            # 0xf7d <balancer_ingress+0xf7d>
     f7d:      	leaq	0x80(%rsp), %rsi
     f85:      	movl	$0x1, %r12d
     f8b:      	callq	*%r12
     f8e:      	testq	%rax, %rax
     f91:      	je	0xfcc <balancer_ingress+0xfcc>
     f93:      	leaq	0x68(%rsp), %rsi
     f98:      	movq	%rax, %rdi
     f9b:      	callq	*%r12
     f9e:      	testq	%rax, %rax
     fa1:      	je	0xfcc <balancer_ingress+0xfcc>
     fa3:      	movl	$0x20f, (%rsp)          # imm = 0x20F
     faa:      	movq	(%rip), %rdi            # 0xfb1 <balancer_ingress+0xfb1>
     fb1:      	movq	%rsp, %rsi
     fb4:      	movl	$0x1, %eax
     fb9:      	callq	*%rax
     fbb:      	testq	%rax, %rax
     fbe:      	je	0x1134 <balancer_ingress+0x1134>
     fc4:      	incq	(%rax)
     fc7:      	jmp	0x1134 <balancer_ingress+0x1134>
     fcc:      	testq	%rbp, %rbp
     fcf:      	je	0x1134 <balancer_ingress+0x1134>
     fd5:      	movq	(%rip), %rdi            # 0xfdc <balancer_ingress+0xfdc>
     fdc:      	leaq	0xa0(%rsp), %rsi
     fe4:      	movl	$0x1, %r12d
     fea:      	callq	*%r12
     fed:      	movl	$0x1, %r13d
     ff3:      	testq	%rax, %rax
     ff6:      	je	0x1b49 <balancer_ingress+0x1b49>
     ffc:      	movq	%rbp, 0x70(%rsp)
    1001:      	movq	%rax, %rbp
    1004:      	movq	(%rip), %rdi            # 0x100b <balancer_ingress+0x100b>
    100b:      	leaq	0xa4(%rsp), %rsi
    1013:      	callq	*%r12
    1016:      	testq	%rax, %rax
    1019:      	je	0x1b49 <balancer_ingress+0x1b49>
    101f:      	incq	(%rax)
    1022:      	movzwl	0x34(%rsp), %r12d
    1028:      	addq	%r12, 0x8(%rax)
    102c:      	leaq	0x68(%rsp), %rsi
    1031:      	movq	(%rip), %rdi            # 0x1038 <balancer_ingress+0x1038>
    1038:      	movl	$0x1, %eax
    103d:      	callq	*%rax
    103f:      	testq	%rax, %rax
    1042:      	je	0x1b49 <balancer_ingress+0x1b49>
    1048:      	incq	(%rax)
    104b:      	addq	%r12, 0x8(%rax)
    104f:      	movl	0x38(%rsp), %eax
    1053:      	movw	%ax, 0x60(%rsp)
    1058:      	movq	0x70(%rsp), %rax
    105d:      	testb	$0x1, 0x10(%rax)
    1061:      	jne	0x1337 <balancer_ingress+0x1337>
    1067:      	movzwl	0x42(%rsp), %r12d
    106d:      	movl	$0x2c, %eax
    1072:      	movq	%r14, %rdi
    1075:      	movl	$0xffffffec, %esi       # imm = 0xFFFFFFEC
    107a:      	callq	*%rax
    107c:      	testl	%eax, %eax
    107e:      	jne	0x18b0 <balancer_ingress+0x18b0>
    1084:      	movq	(%r14), %rax
    1087:      	movq	0x8(%r14), %rcx
    108b:      	leaq	0xe(%rax), %rdx
    108f:      	cmpq	%rcx, %rdx
    1092:      	ja	0x18b0 <balancer_ingress+0x18b0>
    1098:      	leaq	0x22(%rax), %rdx
    109c:      	cmpq	%rcx, %rdx
    109f:      	ja	0x18b0 <balancer_ingress+0x18b0>
    10a5:      	movl	0x38(%rsp), %ecx
    10a9:      	rolw	$0x8, %cx
    10ad:      	xorl	%ecx, %r12d
    10b0:      	shll	$0x10, %r12d
    10b4:      	movzwl	0x4(%rbp), %ecx
    10b8:      	movw	%cx, 0x4(%rax)
    10bc:      	movl	(%rbp), %ecx
    10bf:      	movl	%ecx, (%rax)
    10c1:      	movl	0x14(%rax), %ecx
    10c4:      	movl	%ecx, 0x6(%rax)
    10c7:      	movzwl	0x18(%rax), %ecx
    10cb:      	movw	%cx, 0xa(%rax)
    10cf:      	movw	$0x8, 0xc(%rax)
    10d5:      	leal	0x10ac(%r12), %ecx
    10dd:      	movzbl	0x6d(%rsp), %edx
    10e2:      	movq	0x70(%rsp), %rsi
    10e7:      	movl	(%rsi), %esi
    10e9:      	movb	$0x45, 0xe(%rax)
    10ed:      	movb	%dl, 0xf(%rax)
    10f0:      	movl	0x34(%rsp), %edx
    10f4:      	addl	$0x14, %edx
    10f7:      	movbew	%dx, 0x10(%rax)
    10fd:      	rolw	$0x8, %dx
    1101:      	movl	$0x0, 0x12(%rax)
    1108:      	movl	%esi, 0x1e(%rax)
    110b:      	movl	%ecx, 0x1a(%rax)
    110e:      	movw	$0x440, 0x16(%rax)      # imm = 0x440
    1114:      	movzwl	0xe(%rax), %ecx
    1118:      	movzwl	%dx, %edx
    111b:      	movzwl	0x16(%rax), %edi
    111f:      	addq	%rcx, %rdi
    1122:      	shrl	$0x10, %r12d
    1126:      	addq	%rdi, %r12
    1129:      	movzwl	%si, %ecx
    112c:      	addq	%r12, %rcx
    112f:      	jmp	0x1cae <balancer_ingress+0x1cae>
    1134:      	cmpb	$0x6, 0x64(%rsp)
    1139:      	jne	0x116a <balancer_ingress+0x116a>
    113b:      	movl	$0x201, (%rsp)          # imm = 0x201
    1142:      	movq	(%rip), %rdi            # 0x1149 <balancer_ingress+0x1149>
    1149:      	movq	%rsp, %rsi
    114c:      	movl	$0x1, %eax
    1151:      	callq	*%rax
    1153:      	testq	%rax, %rax
    1156:      	je	0x1b43 <balancer_ingress+0x1b43>
    115c:      	xorl	%ecx, %ecx
    115e:      	testb	$0x2, 0x6c(%rsp)
    1163:      	sete	%cl
    1166:      	incq	(%rax,%rcx,8)
    116a:      	movq	$0x0, 0x8(%rsp)
    1173:      	movq	$0x0, (%rsp)
    117b:      	movl	$0x202, 0x1c(%rsp)      # imm = 0x202
    1183:      	movq	(%rip), %rdi            # 0x118a <balancer_ingress+0x118a>
    118a:      	leaq	0x1c(%rsp), %rsi
    118f:      	movl	$0x1, %eax
    1194:      	callq	*%rax
    1196:      	movb	$0x1, %bpl
    1199:      	testq	%rax, %rax
    119c:      	je	0x11ca <balancer_ingress+0x11ca>
    119e:      	movq	%rax, %r13
    11a1:      	movl	$0x5, %eax
    11a6:      	callq	*%rax
    11a8:      	movq	%rax, %r12
    11ab:      	subq	0x8(%r13), %rax
    11af:      	cmpq	$0x3b9aca01, %rax       # imm = 0x3B9ACA01
    11b5:      	jb	0x11d4 <balancer_ingress+0x11d4>
    11b7:      	movq	$0x1, (%r13)
    11bf:      	movq	%r12, 0x8(%r13)
    11c3:      	movq	0x28(%rsp), %rax
    11c8:      	jmp	0x11ec <balancer_ingress+0x11ec>
    11ca:      	xorl	%r12d, %r12d
    11cd:      	movq	0x28(%rsp), %rax
    11d2:      	jmp	0x11ee <balancer_ingress+0x11ee>
    11d4:      	movq	(%r13), %rax
    11d8:      	incq	%rax
    11db:      	movq	%rax, (%r13)
    11df:      	cmpq	$0x1e848, %rax          # imm = 0x1E848
    11e5:      	movq	0x28(%rsp), %rax
    11ea:      	ja	0x11ee <balancer_ingress+0x11ee>
    11ec:      	xorl	%ebp, %ebp
    11ee:      	testb	$0x8, (%rax)
    11f1:      	je	0x120f <balancer_ingress+0x120f>
    11f3:      	movzwl	0x62(%rsp), %eax
    11f8:      	movw	%ax, 0x60(%rsp)
    11fd:      	movq	$0x0, 0x40(%rsp)
    1206:      	movq	$0x0, 0x48(%rsp)
    120f:      	leaq	0x40(%rsp), %rdi
    1214:      	callq	0x1219 <balancer_ingress+0x1219>
    1219:      	movl	0x60(%rsp), %esi
    121d:      	movl	%eax, %edi
    121f:      	callq	0x1224 <balancer_ingress+0x1224>
    1224:      	movl	$0x10001, %ecx          # imm = 0x10001
    1229:      	xorl	%edx, %edx
    122b:      	divl	%ecx
    122d:      	movq	0x28(%rsp), %rax
    1232:      	movl	0x4(%rax), %eax
    1235:      	addl	%eax, %edx
    1237:      	shll	$0x10, %eax
    123a:      	addl	%eax, %edx
    123c:      	movl	%edx, 0x24(%rsp)
    1240:      	movq	(%rip), %rdi            # 0x1247 <balancer_ingress+0x1247>
    1247:      	leaq	0x24(%rsp), %rsi
    124c:      	movl	$0x1, %eax
    1251:      	callq	*%rax
    1253:      	testq	%rax, %rax
    1256:      	je	0x1b43 <balancer_ingress+0x1b43>
    125c:      	movl	(%rax), %eax
    125e:      	movl	%eax, 0x24(%rsp)
    1262:      	testl	%eax, %eax
    1264:      	je	0x1afe <balancer_ingress+0x1afe>
    126a:      	movq	%r12, %r13
    126d:      	movl	%eax, 0x68(%rsp)
    1271:      	movq	(%rip), %rdi            # 0x1278 <balancer_ingress+0x1278>
    1278:      	leaq	0x24(%rsp), %rsi
    127d:      	movl	$0x1, %r12d
    1283:      	callq	*%r12
    1286:      	movq	%rax, 0x70(%rsp)
    128b:      	testq	%rax, %rax
    128e:      	je	0x1b24 <balancer_ingress+0x1b24>
    1294:      	movq	0x28(%rsp), %rax
    1299:      	movzbl	(%rax), %eax
    129c:      	andb	$0x2, %al
    129e:      	shrb	%al
    12a0:      	orb	%al, %bpl
    12a3:      	jne	0x12d5 <balancer_ingress+0x12d5>
    12a5:      	testb	$0x4, 0x6c(%rsp)
    12aa:      	jne	0x12d5 <balancer_ingress+0x12d5>
    12ac:      	cmpb	$0x11, 0x64(%rsp)
    12b1:      	jne	0x12b8 <balancer_ingress+0x12b8>
    12b3:      	movq	%r13, 0x8(%rsp)
    12b8:      	movl	0x24(%rsp), %eax
    12bc:      	movl	%eax, (%rsp)
    12bf:      	leaq	0x40(%rsp), %rsi
    12c4:      	movq	%rsp, %rdx
    12c7:      	movl	$0x2, %eax
    12cc:      	movq	0x78(%rsp), %rdi
    12d1:      	xorl	%ecx, %ecx
    12d3:      	callq	*%rax
    12d5:      	movl	$0x0, (%rsp)
    12dc:      	movq	(%rip), %rdi            # 0x12e3 <balancer_ingress+0x12e3>
    12e3:      	movq	%rsp, %rsi
    12e6:      	movl	$0x1, %eax
    12eb:      	callq	*%rax
    12ed:      	testq	%rax, %rax
    12f0:      	je	0x1b43 <balancer_ingress+0x1b43>
    12f6:      	movl	(%rax), %ecx
    12f8:      	cmpl	0x80(%rsp), %ecx
    12ff:      	jne	0x13e7 <balancer_ingress+0x13e7>
    1305:      	movl	0x4(%rax), %ecx
    1308:      	cmpl	0x84(%rsp), %ecx
    130f:      	jne	0x13e7 <balancer_ingress+0x13e7>
    1315:      	movl	0x8(%rax), %ecx
    1318:      	cmpl	0x88(%rsp), %ecx
    131f:      	jne	0x13e7 <balancer_ingress+0x13e7>
    1325:      	movl	0xc(%rax), %ecx
    1328:      	cmpl	0x8c(%rsp), %ecx
    132f:      	sete	%cl
    1332:      	jmp	0x13e9 <balancer_ingress+0x13e9>
    1337:      	movl	$0x2c, %eax
    133c:      	movq	%r14, %rdi
    133f:      	movl	$0xffffffd8, %esi       # imm = 0xFFFFFFD8
    1344:      	callq	*%rax
    1346:      	testl	%eax, %eax
    1348:      	jne	0x1bd8 <balancer_ingress+0x1bd8>
    134e:      	movq	(%r14), %rax
    1351:      	movq	0x8(%r14), %rcx
    1355:      	leaq	0xe(%rax), %rdx
    1359:      	cmpq	%rcx, %rdx
    135c:      	ja	0x1bd8 <balancer_ingress+0x1bd8>
    1362:      	leaq	0x36(%rax), %rdx
    1366:      	cmpq	%rcx, %rdx
    1369:      	ja	0x1bd8 <balancer_ingress+0x1bd8>
    136f:      	movzwl	0x4(%rbp), %ecx
    1373:      	movw	%cx, 0x4(%rax)
    1377:      	movl	(%rbp), %ecx
    137a:      	movl	%ecx, (%rax)
    137c:      	movl	0x28(%rax), %ecx
    137f:      	movl	%ecx, 0x6(%rax)
    1382:      	movzwl	0x2c(%rax), %ecx
    1386:      	movw	%cx, 0xa(%rax)
    138a:      	movw	$0xdd86, 0xc(%rax)      # imm = 0xDD86
    1390:      	movzwl	0x60(%rsp), %ecx
    1395:      	xorl	0x4c(%rsp), %ecx
    1399:      	movzbl	0x6d(%rsp), %edx
    139e:      	movw	$0x0, 0x10(%rax)
    13a4:      	movl	%edx, %esi
    13a6:      	shrb	$0x4, %sil
    13aa:      	orb	$0x60, %sil
    13ae:      	movb	%sil, 0xe(%rax)
    13b2:      	shlb	$0x4, %dl
    13b5:      	movb	%dl, 0xf(%rax)
    13b8:      	movw	$0x4029, 0x14(%rax)     # imm = 0x4029
    13be:      	movl	0x34(%rsp), %edx
    13c2:      	addl	$0x28, %edx
    13c5:      	movbew	%dx, 0x12(%rax)
    13cb:      	movq	$0x1, 0x16(%rax)
    13d3:      	movl	$0x0, 0x1e(%rax)
    13da:      	movl	%ecx, 0x22(%rax)
    13dd:      	movq	0x70(%rsp), %rdx
    13e2:      	jmp	0x1db3 <balancer_ingress+0x1db3>
    13e7:      	xorl	%ecx, %ecx
    13e9:      	movzwl	0x10(%rax), %esi
    13ed:      	movzwl	0x90(%rsp), %edi
    13f5:      	movzbl	0x92(%rsp), %edx
    13fd:      	movb	%dl, 0x12(%rax)
    1400:      	testb	%cl, %cl
    1402:      	je	0x1433 <balancer_ingress+0x1433>
    1404:      	cmpw	%di, %si
    1407:      	jne	0x1433 <balancer_ingress+0x1433>
    1409:      	testb	%dl, %dl
    140b:      	je	0x1433 <balancer_ingress+0x1433>
    140d:      	movl	0x68(%rsp), %eax
    1411:      	movl	%eax, 0x1c(%rsp)
    1415:      	movq	(%rip), %rdi            # 0x141c <balancer_ingress+0x141c>
    141c:      	leaq	0x1c(%rsp), %rsi
    1421:      	movl	$0x1, %eax
    1426:      	callq	*%rax
    1428:      	testq	%rax, %rax
    142b:      	je	0x1b43 <balancer_ingress+0x1b43>
    1431:      	incl	(%rax)
    1433:      	movq	0xb0(%rsp), %rax
    143b:      	incq	0x8(%rax)
    143f:      	movq	0x70(%rsp), %rbp
    1444:      	jmp	0xfd5 <balancer_ingress+0xfd5>
    1449:      	addq	$0x40, %rax
    144d:      	jmp	0x1459 <balancer_ingress+0x1459>
    144f:      	addq	$0x48, %rax
    1453:      	jmp	0x1459 <balancer_ingress+0x1459>
    1455:      	addq	$0x30, %rax
    1459:      	incq	(%rax)
    145c:      	movl	%r12d, 0x24(%rsp)
    1461:      	movq	(%rip), %rdi            # 0x1468 <balancer_ingress+0x1468>
    1468:      	leaq	0x24(%rsp), %rsi
    146d:      	movl	$0x1, %eax
    1472:      	callq	*%rax
    1474:      	testq	%rax, %rax
    1477:      	je	0x14cf <balancer_ingress+0x14cf>
    1479:      	movl	(%rax), %eax
    147b:      	movl	%eax, 0x24(%rsp)
    147f:      	testl	%eax, %eax
    1481:      	je	0x14cf <balancer_ingress+0x14cf>
    1483:      	movl	%eax, 0x68(%rsp)
    1487:      	movq	(%rip), %rdi            # 0x148e <balancer_ingress+0x148e>
    148e:      	leaq	0x24(%rsp), %rsi
    1493:      	movl	$0x1, %r12d
    1499:      	callq	*%r12
    149c:      	testq	%rax, %rax
    149f:      	je	0x14f8 <balancer_ingress+0x14f8>
    14a1:      	movq	%rax, %r13
    14a4:      	leaq	0x40(%rsp), %rsi
    14a9:      	movq	0x78(%rsp), %rdi
    14ae:      	callq	*%r12
    14b1:      	testq	%rax, %rax
    14b4:      	je	0x156c <balancer_ingress+0x156c>
    14ba:      	movl	0x68(%rsp), %ecx
    14be:      	cmpl	%ecx, (%rax)
    14c0:      	jne	0x15be <balancer_ingress+0x15be>
    14c6:      	incq	0x50(%rbp)
    14ca:      	jmp	0x1e1b <balancer_ingress+0x1e1b>
    14cf:      	incq	0x10(%rbp)
    14d3:      	movq	%r12, 0x18(%rbp)
    14d7:      	incq	(%rbp)
    14db:      	jmp	0xe7b <balancer_ingress+0xe7b>
    14e0:      	cmpb	$0x7, 0xd(%r12)
    14e6:      	jbe	0x168e <balancer_ingress+0x168e>
    14ec:      	addq	$0xe, %r12
    14f0:      	movq	%r12, %rcx
    14f3:      	jmp	0xbe6 <balancer_ingress+0xbe6>
    14f8:      	incq	0x28(%rbp)
    14fc:      	jmp	0x1b43 <balancer_ingress+0x1b43>
    1501:      	movzbl	0x1(%rcx), %esi
    1505:      	shll	$0x10, %esi
    1508:      	movzbl	0x2(%rcx), %edx
    150c:      	shll	$0x8, %edx
    150f:      	orl	%esi, %edx
    1511:      	movzbl	0x3(%rcx), %ecx
    1515:      	jmp	0x1534 <balancer_ingress+0x1534>
    1517:      	movzbl	0x1(%rcx), %edx
    151b:      	shll	$0x18, %edx
    151e:      	movzbl	0x2(%rcx), %esi
    1522:      	shll	$0x10, %esi
    1525:      	orl	%edx, %esi
    1527:      	movzbl	0x3(%rcx), %edx
    152b:      	shll	$0x8, %edx
    152e:      	orl	%esi, %edx
    1530:      	movzbl	0x4(%rcx), %ecx
    1534:      	movzbl	%cl, %r12d
    1538:      	orq	%rdx, %r12
    153b:      	testl	%r12d, %r12d
    153e:      	jle	0x168e <balancer_ingress+0x168e>
    1544:      	cmpq	$0x3, %rax
    1548:      	je	0x15f7 <balancer_ingress+0x15f7>
    154e:      	cmpl	$0x2, %eax
    1551:      	je	0x15ee <balancer_ingress+0x15ee>
    1557:      	cmpl	$0x1, %eax
    155a:      	jne	0x1600 <balancer_ingress+0x1600>
    1560:      	movq	%r13, %rax
    1563:      	addq	$0x38, %rax
    1567:      	jmp	0x1607 <balancer_ingress+0x1607>
    156c:      	movl	$0x202, (%rsp)          # imm = 0x202
    1573:      	movq	(%rip), %rdi            # 0x157a <balancer_ingress+0x157a>
    157a:      	movq	%rsp, %rsi
    157d:      	movl	$0x1, %eax
    1582:      	callq	*%rax
    1584:      	testq	%rax, %rax
    1587:      	je	0x1e17 <balancer_ingress+0x1e17>
    158d:      	movq	%rax, %r12
    1590:      	movl	$0x5, %eax
    1595:      	callq	*%rax
    1597:      	movq	%rax, %rcx
    159a:      	subq	0x8(%r12), %rcx
    159f:      	cmpq	$0x3b9aca01, %rcx       # imm = 0x3B9ACA01
    15a6:      	jb	0x1dd6 <balancer_ingress+0x1dd6>
    15ac:      	movq	$0x1, (%r12)
    15b4:      	movq	%rax, 0x8(%r12)
    15b9:      	jmp	0x1de9 <balancer_ingress+0x1de9>
    15be:      	movl	%ecx, (%rax)
    15c0:      	incq	0x58(%rbp)
    15c4:      	movl	0x70(%rsp), %eax
    15c8:      	movl	%eax, (%rsp)
    15cb:      	movq	(%rip), %rdi            # 0x15d2 <balancer_ingress+0x15d2>
    15d2:      	movq	%rsp, %rsi
    15d5:      	movl	$0x1, %eax
    15da:      	callq	*%rax
    15dc:      	testq	%rax, %rax
    15df:      	je	0x1e1b <balancer_ingress+0x1e1b>
    15e5:      	incq	0x8(%rax)
    15e9:      	jmp	0x1e1b <balancer_ingress+0x1e1b>
    15ee:      	movq	%r13, %rax
    15f1:      	addq	$0x40, %rax
    15f5:      	jmp	0x1607 <balancer_ingress+0x1607>
    15f7:      	movq	%r13, %rax
    15fa:      	addq	$0x48, %rax
    15fe:      	jmp	0x1607 <balancer_ingress+0x1607>
    1600:      	movq	%r13, %rax
    1603:      	addq	$0x30, %rax
    1607:      	incq	(%rax)
    160a:      	movl	%r12d, 0x24(%rsp)
    160f:      	movq	(%rip), %rdi            # 0x1616 <balancer_ingress+0x1616>
    1616:      	leaq	0x24(%rsp), %rsi
    161b:      	movl	$0x1, %eax
    1620:      	callq	*%rax
    1622:      	testq	%rax, %rax
    1625:      	je	0x1686 <balancer_ingress+0x1686>
    1627:      	movl	(%rax), %eax
    1629:      	movl	%eax, 0x24(%rsp)
    162d:      	testl	%eax, %eax
    162f:      	je	0x1686 <balancer_ingress+0x1686>
    1631:      	movl	%eax, 0x68(%rsp)
    1635:      	movq	(%rip), %rdi            # 0x163c <balancer_ingress+0x163c>
    163c:      	leaq	0x24(%rsp), %rsi
    1641:      	movl	$0x1, %r12d
    1647:      	callq	*%r12
    164a:      	movq	%rax, 0xa8(%rsp)
    1652:      	testq	%rax, %rax
    1655:      	je	0x1dcd <balancer_ingress+0x1dcd>
    165b:      	leaq	0x40(%rsp), %rsi
    1660:      	movq	0x78(%rsp), %rdi
    1665:      	callq	*%r12
    1668:      	testq	%rax, %rax
    166b:      	je	0x1e30 <balancer_ingress+0x1e30>
    1671:      	movl	0x68(%rsp), %ecx
    1675:      	cmpl	%ecx, (%rax)
    1677:      	jne	0x1e7b <balancer_ingress+0x1e7b>
    167d:      	incq	0x50(%r13)
    1681:      	jmp	0x1ee9 <balancer_ingress+0x1ee9>
    1686:      	incq	0x10(%r13)
    168a:      	movq	%r12, 0x18(%r13)
    168e:      	incq	(%r13)
    1692:      	movq	0x28(%rsp), %r13
    1697:      	movzwl	0x60(%rsp), %ecx
    169c:      	movl	%ecx, 0x38(%rsp)
    16a0:      	testb	$0x2, 0x6c(%rsp)
    16a5:      	jne	0x16ef <balancer_ingress+0x16ef>
    16a7:      	testb	$0x2, (%r13)
    16ac:      	jne	0x16f3 <balancer_ingress+0x16f3>
    16ae:      	leaq	0x40(%rsp), %rsi
    16b3:      	movl	$0x1, %eax
    16b8:      	movq	0x78(%rsp), %rdi
    16bd:      	callq	*%rax
    16bf:      	testq	%rax, %rax
    16c2:      	je	0x16eb <balancer_ingress+0x16eb>
    16c4:      	movq	%rax, %r13
    16c7:      	cmpb	$0x11, 0x64(%rsp)
    16cc:      	jne	0x1700 <balancer_ingress+0x1700>
    16ce:      	movl	$0x5, %eax
    16d3:      	callq	*%rax
    16d5:      	movq	%rax, %rcx
    16d8:      	subq	0x8(%r13), %rcx
    16dc:      	movabsq	$0x6fc23ac00, %rdx      # imm = 0x6FC23AC00
    16e6:      	cmpq	%rdx, %rcx
    16e9:      	jbe	0x16fc <balancer_ingress+0x16fc>
    16eb:      	xorl	%eax, %eax
    16ed:      	jmp	0x171c <balancer_ingress+0x171c>
    16ef:      	xorl	%ebp, %ebp
    16f1:      	jmp	0x1724 <balancer_ingress+0x1724>
    16f3:      	xorl	%ebp, %ebp
    16f5:      	movq	0x28(%rsp), %r13
    16fa:      	jmp	0x1724 <balancer_ingress+0x1724>
    16fc:      	movq	%rax, 0x8(%r13)
    1700:      	movl	(%r13), %eax
    1704:      	movl	%eax, (%rsp)
    1707:      	movl	%eax, 0x68(%rsp)
    170b:      	movq	(%rip), %rdi            # 0x1712 <balancer_ingress+0x1712>
    1712:      	movq	%rsp, %rsi
    1715:      	movl	$0x1, %eax
    171a:      	callq	*%rax
    171c:      	movq	0x28(%rsp), %r13
    1721:      	movq	%rax, %rbp
    1724:      	cmpb	$0x11, 0x64(%rsp)
    1729:      	jne	0x17ec <balancer_ingress+0x17ec>
    172f:      	testb	$0x2, 0x1(%r13)
    1734:      	je	0x17ec <balancer_ingress+0x17ec>
    173a:      	movl	$0x202, (%rsp)          # imm = 0x202
    1741:      	movq	(%rip), %rdi            # 0x1748 <balancer_ingress+0x1748>
    1748:      	movq	%rsp, %rsi
    174b:      	movl	$0x1, %eax
    1750:      	callq	*%rax
    1752:      	testq	%rax, %rax
    1755:      	je	0x17ec <balancer_ingress+0x17ec>
    175b:      	movq	%rax, %r13
    175e:      	movl	$0x5, %eax
    1763:      	callq	*%rax
    1765:      	movq	%rax, %rcx
    1768:      	subq	0x8(%r13), %rcx
    176c:      	cmpq	$0x3b9aca01, %rcx       # imm = 0x3B9ACA01
    1773:      	jb	0x1783 <balancer_ingress+0x1783>
    1775:      	movq	$0x1, (%r13)
    177d:      	movq	%rax, 0x8(%r13)
    1781:      	jmp	0x1796 <balancer_ingress+0x1796>
    1783:      	movq	(%r13), %rax
    1787:      	incq	%rax
    178a:      	movq	%rax, (%r13)
    178e:      	cmpq	$0x1e849, %rax          # imm = 0x1E849
    1794:      	jae	0x17ec <balancer_ingress+0x17ec>
    1796:      	movq	(%rip), %rdi            # 0x179d <balancer_ingress+0x179d>
    179d:      	leaq	0x80(%rsp), %rsi
    17a5:      	movl	$0x1, %r12d
    17ab:      	callq	*%r12
    17ae:      	testq	%rax, %rax
    17b1:      	je	0x17ec <balancer_ingress+0x17ec>
    17b3:      	leaq	0x68(%rsp), %rsi
    17b8:      	movq	%rax, %rdi
    17bb:      	callq	*%r12
    17be:      	testq	%rax, %rax
    17c1:      	je	0x17ec <balancer_ingress+0x17ec>
    17c3:      	movl	$0x20f, (%rsp)          # imm = 0x20F
    17ca:      	movq	(%rip), %rdi            # 0x17d1 <balancer_ingress+0x17d1>
    17d1:      	movq	%rsp, %rsi
    17d4:      	movl	$0x1, %eax
    17d9:      	callq	*%rax
    17db:      	testq	%rax, %rax
    17de:      	je	0x18d9 <balancer_ingress+0x18d9>
    17e4:      	incq	(%rax)
    17e7:      	jmp	0x18d9 <balancer_ingress+0x18d9>
    17ec:      	testq	%rbp, %rbp
    17ef:      	je	0x18d9 <balancer_ingress+0x18d9>
    17f5:      	movq	%rbp, 0xa8(%rsp)
    17fd:      	movq	(%rip), %rdi            # 0x1804 <balancer_ingress+0x1804>
    1804:      	leaq	0xa0(%rsp), %rsi
    180c:      	movl	$0x1, %ebp
    1811:      	callq	*%rbp
    1813:      	movl	$0x1, %r13d
    1819:      	testq	%rax, %rax
    181c:      	je	0x1b49 <balancer_ingress+0x1b49>
    1822:      	movq	%rax, %r12
    1825:      	movq	(%rip), %rdi            # 0x182c <balancer_ingress+0x182c>
    182c:      	leaq	0xa4(%rsp), %rsi
    1834:      	callq	*%rbp
    1836:      	testq	%rax, %rax
    1839:      	je	0x1b49 <balancer_ingress+0x1b49>
    183f:      	movzwl	0x34(%rsp), %ecx
    1844:      	rolw	$0x8, %cx
    1848:      	incq	(%rax)
    184b:      	movl	%ecx, 0x28(%rsp)
    184f:      	movzwl	%cx, %ebp
    1852:      	addq	%rbp, 0x8(%rax)
    1856:      	leaq	0x68(%rsp), %rsi
    185b:      	movq	(%rip), %rdi            # 0x1862 <balancer_ingress+0x1862>
    1862:      	movl	$0x1, %eax
    1867:      	callq	*%rax
    1869:      	testq	%rax, %rax
    186c:      	je	0x1b49 <balancer_ingress+0x1b49>
    1872:      	incq	(%rax)
    1875:      	addq	%rbp, 0x8(%rax)
    1879:      	movl	0x38(%rsp), %eax
    187d:      	movw	%ax, 0x60(%rsp)
    1882:      	movq	0xa8(%rsp), %rax
    188a:      	testb	$0x1, 0x10(%rax)
    188e:      	jne	0x1bc1 <balancer_ingress+0x1bc1>
    1894:      	movzwl	0x42(%rsp), %ebp
    1899:      	movl	$0x2c, %eax
    189e:      	movq	%r14, %rdi
    18a1:      	movl	$0xffffffec, %esi       # imm = 0xFFFFFFEC
    18a6:      	callq	*%rax
    18a8:      	testl	%eax, %eax
    18aa:      	je	0x1c02 <balancer_ingress+0x1c02>
    18b0:      	movl	$0x207, (%rsp)          # imm = 0x207
    18b7:      	movq	(%rip), %rdi            # 0x18be <balancer_ingress+0x18be>
    18be:      	movq	%rsp, %rsi
    18c1:      	movl	$0x1, %eax
    18c6:      	callq	*%rax
    18c8:      	testq	%rax, %rax
    18cb:      	je	0x1b49 <balancer_ingress+0x1b49>
    18d1:      	incq	(%rax)
    18d4:      	jmp	0x1b49 <balancer_ingress+0x1b49>
    18d9:      	cmpb	$0x6, 0x64(%rsp)
    18de:      	jne	0x190f <balancer_ingress+0x190f>
    18e0:      	movl	$0x201, (%rsp)          # imm = 0x201
    18e7:      	movq	(%rip), %rdi            # 0x18ee <balancer_ingress+0x18ee>
    18ee:      	movq	%rsp, %rsi
    18f1:      	movl	$0x1, %eax
    18f6:      	callq	*%rax
    18f8:      	testq	%rax, %rax
    18fb:      	je	0x1b43 <balancer_ingress+0x1b43>
    1901:      	xorl	%ecx, %ecx
    1903:      	testb	$0x2, 0x6c(%rsp)
    1908:      	sete	%cl
    190b:      	incq	(%rax,%rcx,8)
    190f:      	movq	$0x0, 0x8(%rsp)
    1918:      	movq	$0x0, (%rsp)
    1920:      	movl	$0x202, 0x1c(%rsp)      # imm = 0x202
    1928:      	movq	(%rip), %rdi            # 0x192f <balancer_ingress+0x192f>
    192f:      	leaq	0x1c(%rsp), %rsi
    1934:      	movl	$0x1, %eax
    1939:      	callq	*%rax
    193b:      	movb	$0x1, %bpl
    193e:      	testq	%rax, %rax
    1941:      	je	0x1974 <balancer_ingress+0x1974>
    1943:      	movq	%rax, %r13
    1946:      	movl	$0x5, %eax
    194b:      	callq	*%rax
    194d:      	movq	%rax, %rcx
    1950:      	movq	%rax, 0x70(%rsp)
    1955:      	subq	0x8(%r13), %rax
    1959:      	cmpq	$0x3b9aca01, %rax       # imm = 0x3B9ACA01
    195f:      	jb	0x197d <balancer_ingress+0x197d>
    1961:      	movq	$0x1, (%r13)
    1969:      	movq	0x70(%rsp), %rax
    196e:      	movq	%rax, 0x8(%r13)
    1972:      	jmp	0x1990 <balancer_ingress+0x1990>
    1974:      	xorl	%eax, %eax
    1976:      	movq	%rax, 0x70(%rsp)
    197b:      	jmp	0x1992 <balancer_ingress+0x1992>
    197d:      	movq	(%r13), %rax
    1981:      	incq	%rax
    1984:      	movq	%rax, (%r13)
    1988:      	cmpq	$0x1e848, %rax          # imm = 0x1E848
    198e:      	ja	0x1992 <balancer_ingress+0x1992>
    1990:      	xorl	%ebp, %ebp
    1992:      	movq	0x28(%rsp), %rax
    1997:      	testb	$0x8, (%rax)
    199a:      	jne	0x19a2 <balancer_ingress+0x19a2>
    199c:      	movl	0x40(%rsp), %edi
    19a0:      	jmp	0x19c0 <balancer_ingress+0x19c0>
    19a2:      	movzwl	0x62(%rsp), %eax
    19a7:      	movw	%ax, 0x60(%rsp)
    19ac:      	movq	$0x0, 0x40(%rsp)
    19b5:      	movq	$0x0, 0x48(%rsp)
    19be:      	xorl	%edi, %edi
    19c0:      	movl	0x60(%rsp), %esi
    19c4:      	callq	0x19c9 <balancer_ingress+0x19c9>
    19c9:      	movl	$0x10001, %ecx          # imm = 0x10001
    19ce:      	xorl	%edx, %edx
    19d0:      	divl	%ecx
    19d2:      	movq	0x28(%rsp), %rax
    19d7:      	movl	0x4(%rax), %eax
    19da:      	addl	%eax, %edx
    19dc:      	shll	$0x10, %eax
    19df:      	addl	%eax, %edx
    19e1:      	movl	%edx, 0x24(%rsp)
    19e5:      	movq	(%rip), %rdi            # 0x19ec <balancer_ingress+0x19ec>
    19ec:      	leaq	0x24(%rsp), %rsi
    19f1:      	movl	$0x1, %eax
    19f6:      	callq	*%rax
    19f8:      	testq	%rax, %rax
    19fb:      	je	0x1b43 <balancer_ingress+0x1b43>
    1a01:      	movl	(%rax), %eax
    1a03:      	movl	%eax, 0x24(%rsp)
    1a07:      	testl	%eax, %eax
    1a09:      	je	0x1afe <balancer_ingress+0x1afe>
    1a0f:      	movl	%eax, 0x68(%rsp)
    1a13:      	movq	(%rip), %rdi            # 0x1a1a <balancer_ingress+0x1a1a>
    1a1a:      	leaq	0x24(%rsp), %rsi
    1a1f:      	movl	$0x1, %r12d
    1a25:      	callq	*%r12
    1a28:      	movq	%rax, 0xa8(%rsp)
    1a30:      	testq	%rax, %rax
    1a33:      	je	0x1b24 <balancer_ingress+0x1b24>
    1a39:      	movq	0x28(%rsp), %rax
    1a3e:      	movzbl	(%rax), %eax
    1a41:      	andb	$0x2, %al
    1a43:      	shrb	%al
    1a45:      	orb	%al, %bpl
    1a48:      	jne	0x1a7f <balancer_ingress+0x1a7f>
    1a4a:      	testb	$0x4, 0x6c(%rsp)
    1a4f:      	jne	0x1a7f <balancer_ingress+0x1a7f>
    1a51:      	cmpb	$0x11, 0x64(%rsp)
    1a56:      	jne	0x1a62 <balancer_ingress+0x1a62>
    1a58:      	movq	0x70(%rsp), %rax
    1a5d:      	movq	%rax, 0x8(%rsp)
    1a62:      	movl	0x24(%rsp), %eax
    1a66:      	movl	%eax, (%rsp)
    1a69:      	leaq	0x40(%rsp), %rsi
    1a6e:      	movq	%rsp, %rdx
    1a71:      	movl	$0x2, %eax
    1a76:      	movq	0x78(%rsp), %rdi
    1a7b:      	xorl	%ecx, %ecx
    1a7d:      	callq	*%rax
    1a7f:      	movl	$0x0, (%rsp)
    1a86:      	movq	(%rip), %rdi            # 0x1a8d <balancer_ingress+0x1a8d>
    1a8d:      	movq	%rsp, %rsi
    1a90:      	movl	$0x1, %eax
    1a95:      	callq	*%rax
    1a97:      	testq	%rax, %rax
    1a9a:      	je	0x1b43 <balancer_ingress+0x1b43>
    1aa0:      	movl	(%rax), %edi
    1aa2:      	movzwl	0x10(%rax), %edx
    1aa6:      	movzwl	0x90(%rsp), %esi
    1aae:      	movzbl	0x92(%rsp), %ecx
    1ab6:      	cmpl	0x80(%rsp), %edi
    1abd:      	movb	%cl, 0x12(%rax)
    1ac0:      	jne	0x1aed <balancer_ingress+0x1aed>
    1ac2:      	cmpw	%si, %dx
    1ac5:      	jne	0x1aed <balancer_ingress+0x1aed>
    1ac7:      	testb	%cl, %cl
    1ac9:      	je	0x1aed <balancer_ingress+0x1aed>
    1acb:      	movl	0x68(%rsp), %eax
    1acf:      	movl	%eax, 0x1c(%rsp)
    1ad3:      	movq	(%rip), %rdi            # 0x1ada <balancer_ingress+0x1ada>
    1ada:      	leaq	0x1c(%rsp), %rsi
    1adf:      	movl	$0x1, %eax
    1ae4:      	callq	*%rax
    1ae6:      	testq	%rax, %rax
    1ae9:      	je	0x1b43 <balancer_ingress+0x1b43>
    1aeb:      	incl	(%rax)
    1aed:      	movq	0xb0(%rsp), %rax
    1af5:      	incq	0x8(%rax)
    1af9:      	jmp	0x17fd <balancer_ingress+0x17fd>
    1afe:      	movl	$0x209, 0x1c(%rsp)      # imm = 0x209
    1b06:      	movq	(%rip), %rdi            # 0x1b0d <balancer_ingress+0x1b0d>
    1b0d:      	leaq	0x1c(%rsp), %rsi
    1b12:      	movl	$0x1, %eax
    1b17:      	callq	*%rax
    1b19:      	testq	%rax, %rax
    1b1c:      	je	0x1b43 <balancer_ingress+0x1b43>
    1b1e:      	incq	0x8(%rax)
    1b22:      	jmp	0x1b43 <balancer_ingress+0x1b43>
    1b24:      	movl	$0x209, 0x1c(%rsp)      # imm = 0x209
    1b2c:      	movq	(%rip), %rdi            # 0x1b33 <balancer_ingress+0x1b33>
    1b33:      	leaq	0x1c(%rsp), %rsi
    1b38:      	callq	*%r12
    1b3b:      	testq	%rax, %rax
    1b3e:      	je	0x1b43 <balancer_ingress+0x1b43>
    1b40:      	incq	(%rax)
    1b43:      	movl	$0x1, %r13d
    1b49:      	cmpl	$0x1, %r13d
    1b4d:      	je	0x1b79 <balancer_ingress+0x1b79>
    1b4f:      	cmpl	$0x3, %r13d
    1b53:      	jne	0x1b67 <balancer_ingress+0x1b67>
    1b55:      	movl	$0x211, 0x94(%rsp)      # imm = 0x211
    1b60:      	movl	$0x3, %ebp
    1b65:      	jmp	0x1b89 <balancer_ingress+0x1b89>
    1b67:      	movl	$0x213, 0x94(%rsp)      # imm = 0x213
    1b72:      	movl	$0x2, %ebp
    1b77:      	jmp	0x1b89 <balancer_ingress+0x1b89>
    1b79:      	movl	$0x212, 0x94(%rsp)      # imm = 0x212
    1b84:      	movl	$0x1, %ebp
    1b89:      	movq	(%rip), %rdi            # 0x1b90 <balancer_ingress+0x1b90>
    1b90:      	leaq	0x94(%rsp), %rsi
    1b98:      	movl	$0x1, %eax
    1b9d:      	callq	*%rax
    1b9f:      	testq	%rax, %rax
    1ba2:      	je	0x1bad <balancer_ingress+0x1bad>
    1ba4:      	incq	(%rax)
    1ba7:      	addq	%r15, 0x8(%rax)
    1bab:      	movl	%ebp, %ebx
    1bad:      	movl	%ebx, %eax
    1baf:      	addq	$0xb8, %rsp
    1bb6:      	popq	%rbx
    1bb7:      	popq	%r12
    1bb9:      	popq	%r13
    1bbb:      	popq	%r14
    1bbd:      	popq	%r15
    1bbf:      	popq	%rbp
    1bc0:      	retq
    1bc1:      	movl	$0x2c, %eax
    1bc6:      	movq	%r14, %rdi
    1bc9:      	movl	$0xffffffd8, %esi       # imm = 0xFFFFFFD8
    1bce:      	callq	*%rax
    1bd0:      	testl	%eax, %eax
    1bd2:      	je	0x1d1d <balancer_ingress+0x1d1d>
    1bd8:      	movl	$0x207, (%rsp)          # imm = 0x207
    1bdf:      	movq	(%rip), %rdi            # 0x1be6 <balancer_ingress+0x1be6>
    1be6:      	movq	%rsp, %rsi
    1be9:      	movl	$0x1, %eax
    1bee:      	callq	*%rax
    1bf0:      	testq	%rax, %rax
    1bf3:      	je	0x1b49 <balancer_ingress+0x1b49>
    1bf9:      	incq	0x8(%rax)
    1bfd:      	jmp	0x1b49 <balancer_ingress+0x1b49>
    1c02:      	movq	(%r14), %rax
    1c05:      	movq	0x8(%r14), %rcx
    1c09:      	leaq	0xe(%rax), %rdx
    1c0d:      	cmpq	%rcx, %rdx
    1c10:      	ja	0x18b0 <balancer_ingress+0x18b0>
    1c16:      	leaq	0x22(%rax), %rdx
    1c1a:      	cmpq	%rcx, %rdx
    1c1d:      	ja	0x18b0 <balancer_ingress+0x18b0>
    1c23:      	movl	0x38(%rsp), %ecx
    1c27:      	rolw	$0x8, %cx
    1c2b:      	xorl	%ecx, %ebp
    1c2d:      	shll	$0x10, %ebp
    1c30:      	movzwl	0x4(%r12), %ecx
    1c36:      	movw	%cx, 0x4(%rax)
    1c3a:      	movl	(%r12), %ecx
    1c3e:      	movl	%ecx, (%rax)
    1c40:      	movl	0x14(%rax), %ecx
    1c43:      	movl	%ecx, 0x6(%rax)
    1c46:      	movzwl	0x18(%rax), %ecx
    1c4a:      	movw	%cx, 0xa(%rax)
    1c4e:      	movw	$0x8, 0xc(%rax)
    1c54:      	leal	0x10ac(%rbp), %ecx
    1c5a:      	movzbl	0x6d(%rsp), %edx
    1c5f:      	movq	0xa8(%rsp), %rsi
    1c67:      	movl	(%rsi), %esi
    1c69:      	movb	$0x45, 0xe(%rax)
    1c6d:      	movb	%dl, 0xf(%rax)
    1c70:      	movl	0x28(%rsp), %edx
    1c74:      	addl	$0x14, %edx
    1c77:      	movbew	%dx, 0x10(%rax)
    1c7d:      	rolw	$0x8, %dx
    1c81:      	movl	$0x0, 0x12(%rax)
    1c88:      	movl	%esi, 0x1e(%rax)
    1c8b:      	movl	%ecx, 0x1a(%rax)
    1c8e:      	movw	$0x440, 0x16(%rax)      # imm = 0x440
    1c94:      	movzwl	0xe(%rax), %ecx
    1c98:      	movzwl	%dx, %edx
    1c9b:      	movzwl	0x16(%rax), %edi
    1c9f:      	addq	%rcx, %rdi
    1ca2:      	shrl	$0x10, %ebp
    1ca5:      	addq	%rdi, %rbp
    1ca8:      	movzwl	%si, %ecx
    1cab:      	addq	%rbp, %rcx
    1cae:      	addq	%rdx, %rcx
    1cb1:      	movzwl	0x20(%rax), %edx
    1cb5:      	addq	%rdx, %rcx
    1cb8:      	addq	$0x10ac, %rcx           # imm = 0x10AC
    1cbf:      	movq	%rcx, %rdx
    1cc2:      	shrq	$0x10, %rdx
    1cc6:      	movzwl	%cx, %esi
    1cc9:      	addq	%rdx, %rsi
    1ccc:      	cmpq	$0x10000, %rcx          # imm = 0x10000
    1cd3:      	cmovbq	%rcx, %rsi
    1cd7:      	movq	%rsi, %rcx
    1cda:      	shrq	$0x10, %rcx
    1cde:      	movzwl	%si, %edx
    1ce1:      	addq	%rcx, %rdx
    1ce4:      	cmpq	$0x10000, %rsi          # imm = 0x10000
    1ceb:      	cmovbq	%rsi, %rdx
    1cef:      	movq	%rdx, %rcx
    1cf2:      	shrq	$0x10, %rcx
    1cf6:      	movzwl	%dx, %esi
    1cf9:      	addl	%esi, %ecx
    1cfb:      	cmpq	$0x10000, %rdx          # imm = 0x10000
    1d02:      	cmovbl	%edx, %ecx
    1d05:      	movl	%ecx, %edx
    1d07:      	shrl	$0x10, %edx
    1d0a:      	addl	%ecx, %edx
    1d0c:      	notl	%edx
    1d0e:      	movw	%dx, 0x18(%rax)
    1d12:      	movl	$0x3, %r13d
    1d18:      	jmp	0x1b49 <balancer_ingress+0x1b49>
    1d1d:      	movq	(%r14), %rax
    1d20:      	movq	0x8(%r14), %rcx
    1d24:      	leaq	0xe(%rax), %rdx
    1d28:      	cmpq	%rcx, %rdx
    1d2b:      	ja	0x1bd8 <balancer_ingress+0x1bd8>
    1d31:      	leaq	0x36(%rax), %rdx
    1d35:      	cmpq	%rcx, %rdx
    1d38:      	ja	0x1bd8 <balancer_ingress+0x1bd8>
    1d3e:      	movzwl	0x4(%r12), %ecx
    1d44:      	movw	%cx, 0x4(%rax)
    1d48:      	movl	(%r12), %ecx
    1d4c:      	movl	%ecx, (%rax)
    1d4e:      	movl	0x28(%rax), %ecx
    1d51:      	movl	%ecx, 0x6(%rax)
    1d54:      	movzwl	0x2c(%rax), %ecx
    1d58:      	movw	%cx, 0xa(%rax)
    1d5c:      	movw	$0xdd86, 0xc(%rax)      # imm = 0xDD86
    1d62:      	movzwl	0x60(%rsp), %ecx
    1d67:      	xorl	0x40(%rsp), %ecx
    1d6b:      	movzbl	0x6d(%rsp), %edx
    1d70:      	movw	$0x0, 0x10(%rax)
    1d76:      	movl	%edx, %esi
    1d78:      	shrb	$0x4, %sil
    1d7c:      	orb	$0x60, %sil
    1d80:      	movb	%sil, 0xe(%rax)
    1d84:      	shlb	$0x4, %dl
    1d87:      	movb	%dl, 0xf(%rax)
    1d8a:      	movw	$0x4004, 0x14(%rax)     # imm = 0x4004
    1d90:      	movzwl	0x34(%rsp), %edx
    1d95:      	movw	%dx, 0x12(%rax)
    1d99:      	movq	$0x1, 0x16(%rax)
    1da1:      	movl	$0x0, 0x1e(%rax)
    1da8:      	movl	%ecx, 0x22(%rax)
    1dab:      	movq	0xa8(%rsp), %rdx
    1db3:      	movq	(%rdx), %rcx
    1db6:      	movq	0x8(%rdx), %rdx
    1dba:      	movq	%rcx, 0x26(%rax)
    1dbe:      	movq	%rdx, 0x2e(%rax)
    1dc2:      	movl	$0x3, %r13d
    1dc8:      	jmp	0x1b49 <balancer_ingress+0x1b49>
    1dcd:      	incq	0x28(%r13)
    1dd1:      	jmp	0x1b43 <balancer_ingress+0x1b43>
    1dd6:      	movq	(%r12), %rax
    1dda:      	incq	%rax
    1ddd:      	movq	%rax, (%r12)
    1de1:      	cmpq	$0x1e849, %rax          # imm = 0x1E849
    1de7:      	jae	0x1e17 <balancer_ingress+0x1e17>
    1de9:      	movq	$0x0, (%rsp)
    1df1:      	movq	$0x0, 0x8(%rsp)
    1dfa:      	movl	0x68(%rsp), %eax
    1dfe:      	movl	%eax, (%rsp)
    1e01:      	leaq	0x40(%rsp), %rsi
    1e06:      	movq	%rsp, %rdx
    1e09:      	movl	$0x2, %eax
    1e0e:      	movq	0x78(%rsp), %rdi
    1e13:      	xorl	%ecx, %ecx
    1e15:      	callq	*%rax
    1e17:      	incq	0x60(%rbp)
    1e1b:      	incq	0x20(%rbp)
    1e1f:      	movzwl	0x60(%rsp), %eax
    1e24:      	movl	%eax, 0x38(%rsp)
    1e28:      	movq	%r13, %rbp
    1e2b:      	jmp	0xfd5 <balancer_ingress+0xfd5>
    1e30:      	movl	$0x202, (%rsp)          # imm = 0x202
    1e37:      	movq	(%rip), %rdi            # 0x1e3e <balancer_ingress+0x1e3e>
    1e3e:      	movq	%rsp, %rsi
    1e41:      	movl	$0x1, %eax
    1e46:      	callq	*%rax
    1e48:      	testq	%rax, %rax
    1e4b:      	je	0x1ee5 <balancer_ingress+0x1ee5>
    1e51:      	movq	%rax, %r12
    1e54:      	movl	$0x5, %eax
    1e59:      	callq	*%rax
    1e5b:      	movq	%rax, %rcx
    1e5e:      	subq	0x8(%r12), %rcx
    1e63:      	cmpq	$0x3b9aca01, %rcx       # imm = 0x3B9ACA01
    1e6a:      	jb	0x1ea4 <balancer_ingress+0x1ea4>
    1e6c:      	movq	$0x1, (%r12)
    1e74:      	movq	%rax, 0x8(%r12)
    1e79:      	jmp	0x1eb7 <balancer_ingress+0x1eb7>
    1e7b:      	movl	%ecx, (%rax)
    1e7d:      	incq	0x58(%r13)
    1e81:      	movl	0x70(%rsp), %eax
    1e85:      	movl	%eax, (%rsp)
    1e88:      	movq	(%rip), %rdi            # 0x1e8f <balancer_ingress+0x1e8f>
    1e8f:      	movq	%rsp, %rsi
    1e92:      	movl	$0x1, %eax
    1e97:      	callq	*%rax
    1e99:      	testq	%rax, %rax
    1e9c:      	je	0x1ee9 <balancer_ingress+0x1ee9>
    1e9e:      	incq	0x8(%rax)
    1ea2:      	jmp	0x1ee9 <balancer_ingress+0x1ee9>
    1ea4:      	movq	(%r12), %rax
    1ea8:      	incq	%rax
    1eab:      	movq	%rax, (%r12)
    1eaf:      	cmpq	$0x1e849, %rax          # imm = 0x1E849
    1eb5:      	jae	0x1ee5 <balancer_ingress+0x1ee5>
    1eb7:      	movq	$0x0, (%rsp)
    1ebf:      	movq	$0x0, 0x8(%rsp)
    1ec8:      	movl	0x68(%rsp), %eax
    1ecc:      	movl	%eax, (%rsp)
    1ecf:      	leaq	0x40(%rsp), %rsi
    1ed4:      	movq	%rsp, %rdx
    1ed7:      	movl	$0x2, %eax
    1edc:      	movq	0x78(%rsp), %rdi
    1ee1:      	xorl	%ecx, %ecx
    1ee3:      	callq	*%rax
    1ee5:      	incq	0x60(%r13)
    1ee9:      	incq	0x20(%r13)
    1eed:      	movzwl	0x60(%rsp), %eax
    1ef2:      	movl	%eax, 0x38(%rsp)
    1ef6:      	jmp	0x17fd <balancer_ingress+0x17fd>
