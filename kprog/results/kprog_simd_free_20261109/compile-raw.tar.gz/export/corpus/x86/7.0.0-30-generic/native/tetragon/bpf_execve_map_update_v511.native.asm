
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_execve_map_update_v511.native.o:	file format elf64-x86-64

Disassembly of section socket:

0000000000000000 <execve_map_update>:
       0:      	pushq	%r15
       2:      	pushq	%r14
       4:      	pushq	%r13
       6:      	pushq	%r12
       8:      	pushq	%rbx
       9:      	subq	$0x10, %rsp
       d:      	movl	$0x0, 0x4(%rsp)
      15:      	movq	(%rip), %rdi            # 0x1c <execve_map_update+0x1c>
      1c:      	leaq	0x4(%rsp), %rsi
      21:      	movl	$0x1, %eax
      26:      	callq	*%rax
      28:      	testq	%rax, %rax
      2b:      	je	0x98 <execve_map_update+0x98>
      2d:      	movq	%rax, %r14
      30:      	movq	(%rip), %rax            # 0x37 <execve_map_update+0x37>
      37:      	cmpb	$0x0, (%rax)
      3a:      	je	0xad <execve_map_update+0xad>
      3c:      	xorl	%ebx, %ebx
      3e:      	movq	(%rip), %r15            # 0x45 <execve_map_update+0x45>
      45:      	leaq	0x8(%rsp), %r12
      4a:      	xorl	%r13d, %r13d
      4d:      	jmp	0x5c <execve_map_update+0x5c>
      4f:      	nop
      50:      	incq	%r13
      53:      	cmpq	$0x8000, %r13           # imm = 0x8000
      5a:      	je	0x9d <execve_map_update+0x9d>
      5c:      	movl	0x4(%r14), %eax
      60:      	cmpq	%rax, %r13
      63:      	je	0x9d <execve_map_update+0x9d>
      65:      	movl	0x8(%r14,%r13,4), %eax
      6a:      	movl	%eax, 0x8(%rsp)
      6e:      	movl	$0x1, %eax
      73:      	movq	%r15, %rdi
      76:      	movq	%r12, %rsi
      79:      	callq	*%rax
      7b:      	testq	%rax, %rax
      7e:      	je	0x50 <execve_map_update+0x50>
      80:      	movzbl	(%r14), %ecx
      84:      	movl	$0xfffffffe, %edx       # imm = 0xFFFFFFFE
      89:      	roll	%cl, %edx
      8b:      	movslq	%edx, %rcx
      8e:      	lock
      8f:      	andq	%rcx, 0x370(%rax)
      96:      	jmp	0x50 <execve_map_update+0x50>
      98:      	movl	$0xffffffff, %ebx       # imm = 0xFFFFFFFF
      9d:      	movl	%ebx, %eax
      9f:      	addq	$0x10, %rsp
      a3:      	popq	%rbx
      a4:      	popq	%r12
      a6:      	popq	%r13
      a8:      	popq	%r14
      aa:      	popq	%r15
      ac:      	retq
      ad:      	xorl	%ebx, %ebx
      af:      	movq	(%rip), %r15            # 0xb6 <execve_map_update+0xb6>
      b6:      	leaq	0xc(%rsp), %r12
      bb:      	xorl	%r13d, %r13d
      be:      	jmp	0xcc <execve_map_update+0xcc>
      c0:      	incq	%r13
      c3:      	cmpq	$0x400, %r13            # imm = 0x400
      ca:      	je	0x9d <execve_map_update+0x9d>
      cc:      	movl	0x4(%r14), %eax
      d0:      	cmpq	%rax, %r13
      d3:      	je	0x9d <execve_map_update+0x9d>
      d5:      	movl	0x8(%r14,%r13,4), %eax
      da:      	movl	%eax, 0xc(%rsp)
      de:      	movl	$0x1, %eax
      e3:      	movq	%r15, %rdi
      e6:      	movq	%r12, %rsi
      e9:      	callq	*%rax
      eb:      	testq	%rax, %rax
      ee:      	je	0xc0 <execve_map_update+0xc0>
      f0:      	movzbl	(%r14), %ecx
      f4:      	movl	$0xfffffffe, %edx       # imm = 0xFFFFFFFE
      f9:      	roll	%cl, %edx
      fb:      	movslq	%edx, %rcx
      fe:      	lock
      ff:      	andq	%rcx, 0x370(%rax)
     106:      	jmp	0xc0 <execve_map_update+0xc0>
