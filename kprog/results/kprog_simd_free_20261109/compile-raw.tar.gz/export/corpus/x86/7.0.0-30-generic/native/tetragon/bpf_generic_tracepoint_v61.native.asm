
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_generic_tracepoint_v61.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <extract_arg_depth>:
       0:      	movl	$0x1, %eax
       5:      	cmpl	$0x9, %edi
       8:      	ja	0x82 <extract_arg_depth+0x82>
       a:      	pushq	%r14
       c:      	pushq	%rbx
       d:      	pushq	%rax
       e:      	movq	(%rsi), %r8
      11:      	movl	%edi, %r9d
      14:      	cmpw	$0x0, 0x6(%r8,%r9,8)
      1b:      	je	0x7b <extract_arg_depth+0x7b>
      1d:      	movq	0x8(%rsi), %rcx
      21:      	movl	(%r8,%r9,8), %edx
      25:      	addq	(%rcx), %rdx
      28:      	movq	%rdx, (%rcx)
      2b:      	xorl	%eax, %eax
      2d:      	cmpw	$0x0, 0x4(%r8,%r9,8)
      34:      	je	0x7b <extract_arg_depth+0x7b>
      36:      	movl	%edi, %ebx
      38:      	cmpb	$0x0, 0x10(%rsi)
      3c:      	je	0x4a <extract_arg_depth+0x4a>
      3e:      	movl	$0x8, %edi
      43:      	movl	$0x94, %eax
      48:      	jmp	0x54 <extract_arg_depth+0x54>
      4a:      	movl	$0x8, %edi
      4f:      	movl	$0x4, %eax
      54:      	movq	%rsi, %r14
      57:      	movq	0x8(%rsi), %rdi
      5b:      	movq	(%rdi), %rdx
      5e:      	movl	$0x8, %esi
      63:      	callq	*%rax
      65:      	testl	%eax, %eax
      67:      	movl	$0x0, %eax
      6c:      	jns	0x7b <extract_arg_depth+0x7b>
      6e:      	incl	%ebx
      70:      	movq	0x18(%r14), %rax
      74:      	movl	%ebx, (%rax)
      76:      	movl	$0x1, %eax
      7b:      	addq	$0x8, %rsp
      7f:      	popq	%rbx
      80:      	popq	%r14
      82:      	retq
      83:      	nopw	%cs:(%rax,%rax)

0000000000000090 <filter_64ty>:
      90:      	pushq	%rax
      91:      	movl	0x4(%rdi), %ecx
      94:      	xorl	%eax, %eax
      96:      	cmpq	$0x20, %rcx
      9a:      	ja	0xd5 <filter_64ty+0x45>
      9c:      	movl	$0x101e, %edx           # imm = 0x101E
      a1:      	btq	%rcx, %rdx
      a5:      	jae	0xae <filter_64ty+0x1e>
      a7:      	callq	0x1d0 <filter_64ty_selector_val>
      ac:      	popq	%rcx
      ad:      	retq
      ae:      	movl	$0xc00, %edx            # imm = 0xC00
      b3:      	btq	%rcx, %rdx
      b7:      	jb	0xd0 <filter_64ty+0x40>
      b9:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
      c3:      	btq	%rcx, %rdx
      c7:      	jae	0xd5 <filter_64ty+0x45>
      c9:      	callq	0x490 <filter_64ty_range>
      ce:      	popq	%rcx
      cf:      	retq
      d0:      	callq	0x410 <filter_64ty_map>
      d5:      	popq	%rcx
      d6:      	retq
      d7:      	nopw	(%rax,%rax)

00000000000000e0 <filter_32ty>:
      e0:      	pushq	%rax
      e1:      	movl	0x4(%rdi), %ecx
      e4:      	xorl	%eax, %eax
      e6:      	cmpq	$0x20, %rcx
      ea:      	ja	0x125 <filter_32ty+0x45>
      ec:      	movl	$0x101e, %edx           # imm = 0x101E
      f1:      	btq	%rcx, %rdx
      f5:      	jae	0xfe <filter_32ty+0x1e>
      f7:      	callq	0x670 <filter_32ty_selector_val>
      fc:      	popq	%rcx
      fd:      	retq
      fe:      	movl	$0xc00, %edx            # imm = 0xC00
     103:      	btq	%rcx, %rdx
     107:      	jb	0x120 <filter_32ty+0x40>
     109:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     113:      	btq	%rcx, %rdx
     117:      	jae	0x125 <filter_32ty+0x45>
     119:      	callq	0x920 <filter_32ty_range>
     11e:      	popq	%rcx
     11f:      	retq
     120:      	callq	0x890 <filter_32ty_map>
     125:      	popq	%rcx
     126:      	retq
     127:      	nopw	(%rax,%rax)

0000000000000130 <filter_16ty>:
     130:      	pushq	%rax
     131:      	movl	0x4(%rdi), %ecx
     134:      	xorl	%eax, %eax
     136:      	cmpq	$0x20, %rcx
     13a:      	ja	0x175 <filter_16ty+0x45>
     13c:      	movl	$0x101e, %edx           # imm = 0x101E
     141:      	btq	%rcx, %rdx
     145:      	jae	0x14e <filter_16ty+0x1e>
     147:      	callq	0xae0 <filter_16ty_selector_val>
     14c:      	popq	%rcx
     14d:      	retq
     14e:      	movl	$0xc00, %edx            # imm = 0xC00
     153:      	btq	%rcx, %rdx
     157:      	jb	0x170 <filter_16ty+0x40>
     159:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     163:      	btq	%rcx, %rdx
     167:      	jae	0x175 <filter_16ty+0x45>
     169:      	callq	0xd90 <filter_16ty_range>
     16e:      	popq	%rcx
     16f:      	retq
     170:      	callq	0xd00 <filter_16ty_map>
     175:      	popq	%rcx
     176:      	retq
     177:      	nopw	(%rax,%rax)

0000000000000180 <filter_8ty>:
     180:      	pushq	%rax
     181:      	movl	0x4(%rdi), %ecx
     184:      	xorl	%eax, %eax
     186:      	cmpq	$0x20, %rcx
     18a:      	ja	0x1c5 <filter_8ty+0x45>
     18c:      	movl	$0x101e, %edx           # imm = 0x101E
     191:      	btq	%rcx, %rdx
     195:      	jae	0x19e <filter_8ty+0x1e>
     197:      	callq	0xf50 <filter_8ty_selector_val>
     19c:      	popq	%rcx
     19d:      	retq
     19e:      	movl	$0xc00, %edx            # imm = 0xC00
     1a3:      	btq	%rcx, %rdx
     1a7:      	jb	0x1c0 <filter_8ty+0x40>
     1a9:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     1b3:      	btq	%rcx, %rdx
     1b7:      	jae	0x1c5 <filter_8ty+0x45>
     1b9:      	callq	0x1200 <filter_8ty_range>
     1be:      	popq	%rcx
     1bf:      	retq
     1c0:      	callq	0x1170 <filter_8ty_map>
     1c5:      	popq	%rcx
     1c6:      	retq
     1c7:      	nopw	(%rax,%rax)

00000000000001d0 <filter_64ty_selector_val>:
     1d0:      	movl	0x4(%rdi), %ecx
     1d3:      	movl	$0x1, %eax
     1d8:      	cmpq	$0x25, %rcx
     1dc:      	ja	0x254 <filter_64ty_selector_val+0x84>
     1de:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     1e8:      	btq	%rcx, %rdx
     1ec:      	jae	0x1ef <filter_64ty_selector_val+0x1f>
     1ee:      	retq
     1ef:      	movl	$0x18, %edx
     1f4:      	btq	%rcx, %rdx
     1f8:      	jae	0x210 <filter_64ty_selector_val+0x40>
     1fa:      	movq	(%rsi), %rdx
     1fd:      	cmpq	0x10(%rdi), %rdx
     201:      	jne	0x332 <filter_64ty_selector_val+0x162>
     207:      	xorl	%eax, %eax
     209:      	cmpl	$0x3, %ecx
     20c:      	sete	%al
     20f:      	retq
     210:      	cmpq	$0xc, %rcx
     214:      	jne	0x254 <filter_64ty_selector_val+0x84>
     216:      	movq	(%rsi), %rcx
     219:      	testq	%rcx, 0x10(%rdi)
     21d:      	jne	0x1ee <filter_64ty_selector_val+0x1e>
     21f:      	movl	0x8(%rdi), %edx
     222:      	cmpl	$0x11, %edx
     225:      	jb	0x3ff <filter_64ty_selector_val+0x22f>
     22b:      	testq	%rcx, 0x18(%rdi)
     22f:      	jne	0x1ee <filter_64ty_selector_val+0x1e>
     231:      	cmpl	$0x19, %edx
     234:      	jb	0x3ff <filter_64ty_selector_val+0x22f>
     23a:      	testq	%rcx, 0x20(%rdi)
     23e:      	jne	0x1ee <filter_64ty_selector_val+0x1e>
     240:      	cmpl	$0x21, %edx
     243:      	jb	0x3ff <filter_64ty_selector_val+0x22f>
     249:      	testq	%rcx, 0x28(%rdi)
     24d:      	jne	0x1ee <filter_64ty_selector_val+0x1e>
     24f:      	jmp	0x3ff <filter_64ty_selector_val+0x22f>
     254:      	cmpl	$0x1, %ecx
     257:      	je	0x2ca <filter_64ty_selector_val+0xfa>
     259:      	cmpl	$0x2, %ecx
     25c:      	jne	0x3ff <filter_64ty_selector_val+0x22f>
     262:      	movl	0xc(%rdi), %ecx
     265:      	cmpl	$0xc, %ecx
     268:      	ja	0x3c2 <filter_64ty_selector_val+0x1f2>
     26e:      	movl	$0x1402, %edx           # imm = 0x1402
     273:      	btl	%ecx, %edx
     276:      	jae	0x3c2 <filter_64ty_selector_val+0x1f2>
     27c:      	movq	(%rsi), %rcx
     27f:      	cmpq	0x10(%rdi), %rcx
     283:      	jl	0x1ee <filter_64ty_selector_val+0x1e>
     289:      	movl	0x8(%rdi), %edx
     28c:      	cmpl	$0x11, %edx
     28f:      	jb	0x3ff <filter_64ty_selector_val+0x22f>
     295:      	cmpq	0x18(%rdi), %rcx
     299:      	jl	0x1ee <filter_64ty_selector_val+0x1e>
     29f:      	cmpl	$0x19, %edx
     2a2:      	jb	0x3ff <filter_64ty_selector_val+0x22f>
     2a8:      	cmpq	0x20(%rdi), %rcx
     2ac:      	jl	0x1ee <filter_64ty_selector_val+0x1e>
     2b2:      	cmpl	$0x21, %edx
     2b5:      	jb	0x3ff <filter_64ty_selector_val+0x22f>
     2bb:      	cmpq	0x28(%rdi), %rcx
     2bf:      	jl	0x1ee <filter_64ty_selector_val+0x1e>
     2c5:      	jmp	0x3ff <filter_64ty_selector_val+0x22f>
     2ca:      	movl	0xc(%rdi), %ecx
     2cd:      	cmpl	$0xc, %ecx
     2d0:      	ja	0x383 <filter_64ty_selector_val+0x1b3>
     2d6:      	movl	$0x1402, %edx           # imm = 0x1402
     2db:      	btl	%ecx, %edx
     2de:      	jae	0x383 <filter_64ty_selector_val+0x1b3>
     2e4:      	movq	(%rsi), %rcx
     2e7:      	cmpq	0x10(%rdi), %rcx
     2eb:      	jg	0x1ee <filter_64ty_selector_val+0x1e>
     2f1:      	movl	0x8(%rdi), %edx
     2f4:      	cmpl	$0x11, %edx
     2f7:      	jb	0x3ff <filter_64ty_selector_val+0x22f>
     2fd:      	cmpq	0x18(%rdi), %rcx
     301:      	jg	0x1ee <filter_64ty_selector_val+0x1e>
     307:      	cmpl	$0x19, %edx
     30a:      	jb	0x3ff <filter_64ty_selector_val+0x22f>
     310:      	cmpq	0x20(%rdi), %rcx
     314:      	jg	0x1ee <filter_64ty_selector_val+0x1e>
     31a:      	cmpl	$0x21, %edx
     31d:      	jb	0x3ff <filter_64ty_selector_val+0x22f>
     323:      	cmpq	0x28(%rdi), %rcx
     327:      	jg	0x1ee <filter_64ty_selector_val+0x1e>
     32d:      	jmp	0x3ff <filter_64ty_selector_val+0x22f>
     332:      	movl	0x8(%rdi), %esi
     335:      	cmpl	$0x11, %esi
     338:      	jb	0x362 <filter_64ty_selector_val+0x192>
     33a:      	cmpq	0x18(%rdi), %rdx
     33e:      	je	0x207 <filter_64ty_selector_val+0x37>
     344:      	cmpl	$0x19, %esi
     347:      	jb	0x362 <filter_64ty_selector_val+0x192>
     349:      	cmpq	0x20(%rdi), %rdx
     34d:      	je	0x207 <filter_64ty_selector_val+0x37>
     353:      	cmpl	$0x21, %esi
     356:      	jb	0x362 <filter_64ty_selector_val+0x192>
     358:      	cmpq	0x28(%rdi), %rdx
     35c:      	je	0x207 <filter_64ty_selector_val+0x37>
     362:      	cmpl	$0x25, %ecx
     365:      	ja	0x3ff <filter_64ty_selector_val+0x22f>
     36b:      	movl	%ecx, %ecx
     36d:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     377:      	btq	%rcx, %rdx
     37b:      	jb	0x1ee <filter_64ty_selector_val+0x1e>
     381:      	jmp	0x3ff <filter_64ty_selector_val+0x22f>
     383:      	movq	(%rsi), %rcx
     386:      	cmpq	0x10(%rdi), %rcx
     38a:      	ja	0x1ee <filter_64ty_selector_val+0x1e>
     390:      	movl	0x8(%rdi), %edx
     393:      	cmpl	$0x11, %edx
     396:      	jb	0x3ff <filter_64ty_selector_val+0x22f>
     398:      	cmpq	0x18(%rdi), %rcx
     39c:      	ja	0x1ee <filter_64ty_selector_val+0x1e>
     3a2:      	cmpl	$0x19, %edx
     3a5:      	jb	0x3ff <filter_64ty_selector_val+0x22f>
     3a7:      	cmpq	0x20(%rdi), %rcx
     3ab:      	ja	0x1ee <filter_64ty_selector_val+0x1e>
     3b1:      	cmpl	$0x21, %edx
     3b4:      	jb	0x3ff <filter_64ty_selector_val+0x22f>
     3b6:      	cmpq	0x28(%rdi), %rcx
     3ba:      	ja	0x1ee <filter_64ty_selector_val+0x1e>
     3c0:      	jmp	0x3ff <filter_64ty_selector_val+0x22f>
     3c2:      	movq	(%rsi), %rcx
     3c5:      	cmpq	0x10(%rdi), %rcx
     3c9:      	jb	0x1ee <filter_64ty_selector_val+0x1e>
     3cf:      	movl	0x8(%rdi), %edx
     3d2:      	cmpl	$0x11, %edx
     3d5:      	jb	0x3ff <filter_64ty_selector_val+0x22f>
     3d7:      	cmpq	0x18(%rdi), %rcx
     3db:      	jb	0x1ee <filter_64ty_selector_val+0x1e>
     3e1:      	cmpl	$0x19, %edx
     3e4:      	jb	0x3ff <filter_64ty_selector_val+0x22f>
     3e6:      	cmpq	0x20(%rdi), %rcx
     3ea:      	jb	0x1ee <filter_64ty_selector_val+0x1e>
     3f0:      	cmpl	$0x21, %edx
     3f3:      	jb	0x3ff <filter_64ty_selector_val+0x22f>
     3f5:      	cmpq	0x28(%rdi), %rcx
     3f9:      	jb	0x1ee <filter_64ty_selector_val+0x1e>
     3ff:      	xorl	%eax, %eax
     401:      	retq
     402:      	nopw	%cs:(%rax,%rax)

0000000000000410 <filter_64ty_map>:
     410:      	pushq	%r14
     412:      	pushq	%rbx
     413:      	subq	$0x18, %rsp
     417:      	movq	%rsi, %r14
     41a:      	movq	%rdi, %rbx
     41d:      	movzbl	0x10(%rdi), %eax
     421:      	movl	%eax, 0xc(%rsp)
     425:      	movq	(%rip), %rdi            # 0x42c <filter_64ty_map+0x1c>
     42c:      	leaq	0xc(%rsp), %rsi
     431:      	movl	$0x1, %eax
     436:      	callq	*%rax
     438:      	testq	%rax, %rax
     43b:      	je	0x469 <filter_64ty_map+0x59>
     43d:      	movq	%rax, %rdi
     440:      	movq	(%r14), %rax
     443:      	movq	%rax, 0x10(%rsp)
     448:      	leaq	0x10(%rsp), %rsi
     44d:      	movl	$0x1, %eax
     452:      	callq	*%rax
     454:      	movl	0x4(%rbx), %ecx
     457:      	cmpl	$0xb, %ecx
     45a:      	je	0x473 <filter_64ty_map+0x63>
     45c:      	cmpl	$0xa, %ecx
     45f:      	jne	0x47b <filter_64ty_map+0x6b>
     461:      	testq	%rax, %rax
     464:      	setne	%al
     467:      	jmp	0x47d <filter_64ty_map+0x6d>
     469:      	xorl	%eax, %eax
     46b:      	addq	$0x18, %rsp
     46f:      	popq	%rbx
     470:      	popq	%r14
     472:      	retq
     473:      	testq	%rax, %rax
     476:      	sete	%al
     479:      	jmp	0x47d <filter_64ty_map+0x6d>
     47b:      	xorl	%eax, %eax
     47d:      	movzbl	%al, %eax
     480:      	addq	$0x18, %rsp
     484:      	popq	%rbx
     485:      	popq	%r14
     487:      	retq
     488:      	nopl	(%rax,%rax)

0000000000000490 <filter_64ty_range>:
     490:      	movl	0x4(%rdi), %ecx
     493:      	movl	0xc(%rdi), %eax
     496:      	cmpl	$0xc, %eax
     499:      	ja	0x590 <filter_64ty_range+0x100>
     49f:      	movl	$0x1402, %edx           # imm = 0x1402
     4a4:      	btl	%eax, %edx
     4a7:      	jae	0x590 <filter_64ty_range+0x100>
     4ad:      	movq	(%rsi), %rsi
     4b0:      	cmpl	$0x1f, %ecx
     4b3:      	jne	0x523 <filter_64ty_range+0x93>
     4b5:      	movl	$0x1, %eax
     4ba:      	cmpq	%rsi, 0x10(%rdi)
     4be:      	jg	0x4ca <filter_64ty_range+0x3a>
     4c0:      	cmpq	0x18(%rdi), %rsi
     4c4:      	jle	0x5a9 <filter_64ty_range+0x119>
     4ca:      	movl	0x8(%rdi), %edx
     4cd:      	cmpl	$0x19, %edx
     4d0:      	jb	0x657 <filter_64ty_range+0x1c7>
     4d6:      	cmpq	%rsi, 0x20(%rdi)
     4da:      	jg	0x4e6 <filter_64ty_range+0x56>
     4dc:      	cmpq	0x28(%rdi), %rsi
     4e0:      	jle	0x5a9 <filter_64ty_range+0x119>
     4e6:      	cmpl	$0x29, %edx
     4e9:      	jb	0x657 <filter_64ty_range+0x1c7>
     4ef:      	cmpq	%rsi, 0x30(%rdi)
     4f3:      	jg	0x4ff <filter_64ty_range+0x6f>
     4f5:      	cmpq	0x38(%rdi), %rsi
     4f9:      	jle	0x5a9 <filter_64ty_range+0x119>
     4ff:      	cmpl	$0x39, %edx
     502:      	jb	0x657 <filter_64ty_range+0x1c7>
     508:      	xorl	%edx, %edx
     50a:      	cmpq	%rsi, 0x40(%rdi)
     50e:      	jg	0x659 <filter_64ty_range+0x1c9>
     514:      	cmpq	0x48(%rdi), %rsi
     518:      	jle	0x5a9 <filter_64ty_range+0x119>
     51e:      	jmp	0x659 <filter_64ty_range+0x1c9>
     523:      	movl	0x8(%rdi), %eax
     526:      	cmpq	%rsi, 0x10(%rdi)
     52a:      	setle	%r8b
     52e:      	cmpq	0x18(%rdi), %rsi
     532:      	setle	%dl
     535:      	andb	%r8b, %dl
     538:      	cmpl	$0x19, %eax
     53b:      	jb	0x659 <filter_64ty_range+0x1c9>
     541:      	cmpq	%rsi, 0x20(%rdi)
     545:      	setle	%r8b
     549:      	cmpq	0x28(%rdi), %rsi
     54d:      	setle	%r9b
     551:      	andb	%r8b, %r9b
     554:      	orb	%r9b, %dl
     557:      	cmpl	$0x29, %eax
     55a:      	jb	0x659 <filter_64ty_range+0x1c9>
     560:      	cmpq	%rsi, 0x30(%rdi)
     564:      	setle	%r8b
     568:      	cmpq	0x38(%rdi), %rsi
     56c:      	setle	%r9b
     570:      	andb	%r8b, %r9b
     573:      	orb	%r9b, %dl
     576:      	cmpl	$0x39, %eax
     579:      	jb	0x659 <filter_64ty_range+0x1c9>
     57f:      	cmpq	%rsi, 0x40(%rdi)
     583:      	setle	%al
     586:      	cmpq	0x48(%rdi), %rsi
     58a:      	setle	%sil
     58e:      	jmp	0x60d <filter_64ty_range+0x17d>
     590:      	movq	(%rsi), %rsi
     593:      	cmpl	$0x1f, %ecx
     596:      	jne	0x5aa <filter_64ty_range+0x11a>
     598:      	movl	$0x1, %eax
     59d:      	cmpq	%rsi, 0x10(%rdi)
     5a1:      	ja	0x615 <filter_64ty_range+0x185>
     5a3:      	cmpq	0x18(%rdi), %rsi
     5a7:      	ja	0x615 <filter_64ty_range+0x185>
     5a9:      	retq
     5aa:      	movl	0x8(%rdi), %eax
     5ad:      	cmpq	%rsi, 0x10(%rdi)
     5b1:      	setbe	%r8b
     5b5:      	cmpq	0x18(%rdi), %rsi
     5b9:      	setbe	%dl
     5bc:      	andb	%r8b, %dl
     5bf:      	cmpl	$0x19, %eax
     5c2:      	jb	0x659 <filter_64ty_range+0x1c9>
     5c8:      	cmpq	%rsi, 0x20(%rdi)
     5cc:      	setbe	%r8b
     5d0:      	cmpq	0x28(%rdi), %rsi
     5d4:      	setbe	%r9b
     5d8:      	andb	%r8b, %r9b
     5db:      	orb	%r9b, %dl
     5de:      	cmpl	$0x29, %eax
     5e1:      	jb	0x659 <filter_64ty_range+0x1c9>
     5e3:      	cmpq	%rsi, 0x30(%rdi)
     5e7:      	setbe	%r8b
     5eb:      	cmpq	0x38(%rdi), %rsi
     5ef:      	setbe	%r9b
     5f3:      	andb	%r8b, %r9b
     5f6:      	orb	%r9b, %dl
     5f9:      	cmpl	$0x39, %eax
     5fc:      	jb	0x659 <filter_64ty_range+0x1c9>
     5fe:      	cmpq	%rsi, 0x40(%rdi)
     602:      	setbe	%al
     605:      	cmpq	0x48(%rdi), %rsi
     609:      	setbe	%sil
     60d:      	andb	%al, %sil
     610:      	orb	%sil, %dl
     613:      	jmp	0x659 <filter_64ty_range+0x1c9>
     615:      	movl	0x8(%rdi), %edx
     618:      	cmpl	$0x19, %edx
     61b:      	jb	0x657 <filter_64ty_range+0x1c7>
     61d:      	cmpq	%rsi, 0x20(%rdi)
     621:      	ja	0x629 <filter_64ty_range+0x199>
     623:      	cmpq	0x28(%rdi), %rsi
     627:      	jbe	0x5a9 <filter_64ty_range+0x119>
     629:      	cmpl	$0x29, %edx
     62c:      	jb	0x657 <filter_64ty_range+0x1c7>
     62e:      	cmpq	%rsi, 0x30(%rdi)
     632:      	ja	0x63e <filter_64ty_range+0x1ae>
     634:      	cmpq	0x38(%rdi), %rsi
     638:      	jbe	0x5a9 <filter_64ty_range+0x119>
     63e:      	cmpl	$0x39, %edx
     641:      	jb	0x657 <filter_64ty_range+0x1c7>
     643:      	xorl	%edx, %edx
     645:      	cmpq	%rsi, 0x40(%rdi)
     649:      	ja	0x659 <filter_64ty_range+0x1c9>
     64b:      	cmpq	0x48(%rdi), %rsi
     64f:      	jbe	0x5a9 <filter_64ty_range+0x119>
     655:      	jmp	0x659 <filter_64ty_range+0x1c9>
     657:      	xorl	%edx, %edx
     659:      	cmpl	$0x20, %ecx
     65c:      	sete	%al
     65f:      	xorb	$0x1, %dl
     662:      	andb	%al, %dl
     664:      	movzbl	%dl, %eax
     667:      	retq
     668:      	nopl	(%rax,%rax)

0000000000000670 <filter_32ty_selector_val>:
     670:      	movl	0x4(%rdi), %ecx
     673:      	movl	$0x1, %eax
     678:      	cmpq	$0x25, %rcx
     67c:      	ja	0x6ed <filter_32ty_selector_val+0x7d>
     67e:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     688:      	btq	%rcx, %rdx
     68c:      	jae	0x68f <filter_32ty_selector_val+0x1f>
     68e:      	retq
     68f:      	movl	$0x18, %edx
     694:      	btq	%rcx, %rdx
     698:      	jae	0x6ae <filter_32ty_selector_val+0x3e>
     69a:      	movl	(%rsi), %edx
     69c:      	cmpl	0x10(%rdi), %edx
     69f:      	jne	0x7c1 <filter_32ty_selector_val+0x151>
     6a5:      	xorl	%eax, %eax
     6a7:      	cmpl	$0x3, %ecx
     6aa:      	sete	%al
     6ad:      	retq
     6ae:      	cmpq	$0xc, %rcx
     6b2:      	jne	0x6ed <filter_32ty_selector_val+0x7d>
     6b4:      	movl	(%rsi), %ecx
     6b6:      	testl	%ecx, 0x10(%rdi)
     6b9:      	jne	0x68e <filter_32ty_selector_val+0x1e>
     6bb:      	movl	0x8(%rdi), %edx
     6be:      	cmpl	$0xd, %edx
     6c1:      	jb	0x881 <filter_32ty_selector_val+0x211>
     6c7:      	testl	%ecx, 0x14(%rdi)
     6ca:      	jne	0x68e <filter_32ty_selector_val+0x1e>
     6cc:      	cmpl	$0x11, %edx
     6cf:      	jb	0x881 <filter_32ty_selector_val+0x211>
     6d5:      	testl	%ecx, 0x18(%rdi)
     6d8:      	jne	0x68e <filter_32ty_selector_val+0x1e>
     6da:      	cmpl	$0x15, %edx
     6dd:      	jb	0x881 <filter_32ty_selector_val+0x211>
     6e3:      	testl	%ecx, 0x1c(%rdi)
     6e6:      	jne	0x68e <filter_32ty_selector_val+0x1e>
     6e8:      	jmp	0x881 <filter_32ty_selector_val+0x211>
     6ed:      	cmpl	$0x1, %ecx
     6f0:      	je	0x75e <filter_32ty_selector_val+0xee>
     6f2:      	cmpl	$0x2, %ecx
     6f5:      	jne	0x881 <filter_32ty_selector_val+0x211>
     6fb:      	movl	0xc(%rdi), %ecx
     6fe:      	cmpl	$0xc, %ecx
     701:      	ja	0x849 <filter_32ty_selector_val+0x1d9>
     707:      	movl	$0x1402, %edx           # imm = 0x1402
     70c:      	btl	%ecx, %edx
     70f:      	jae	0x849 <filter_32ty_selector_val+0x1d9>
     715:      	movl	(%rsi), %ecx
     717:      	cmpl	0x10(%rdi), %ecx
     71a:      	jl	0x68e <filter_32ty_selector_val+0x1e>
     720:      	movl	0x8(%rdi), %edx
     723:      	cmpl	$0xd, %edx
     726:      	jb	0x881 <filter_32ty_selector_val+0x211>
     72c:      	cmpl	0x14(%rdi), %ecx
     72f:      	jl	0x68e <filter_32ty_selector_val+0x1e>
     735:      	cmpl	$0x11, %edx
     738:      	jb	0x881 <filter_32ty_selector_val+0x211>
     73e:      	cmpl	0x18(%rdi), %ecx
     741:      	jl	0x68e <filter_32ty_selector_val+0x1e>
     747:      	cmpl	$0x15, %edx
     74a:      	jb	0x881 <filter_32ty_selector_val+0x211>
     750:      	cmpl	0x1c(%rdi), %ecx
     753:      	jl	0x68e <filter_32ty_selector_val+0x1e>
     759:      	jmp	0x881 <filter_32ty_selector_val+0x211>
     75e:      	movl	0xc(%rdi), %ecx
     761:      	cmpl	$0xc, %ecx
     764:      	ja	0x80f <filter_32ty_selector_val+0x19f>
     76a:      	movl	$0x1402, %edx           # imm = 0x1402
     76f:      	btl	%ecx, %edx
     772:      	jae	0x80f <filter_32ty_selector_val+0x19f>
     778:      	movl	(%rsi), %ecx
     77a:      	cmpl	0x10(%rdi), %ecx
     77d:      	jg	0x68e <filter_32ty_selector_val+0x1e>
     783:      	movl	0x8(%rdi), %edx
     786:      	cmpl	$0xd, %edx
     789:      	jb	0x881 <filter_32ty_selector_val+0x211>
     78f:      	cmpl	0x14(%rdi), %ecx
     792:      	jg	0x68e <filter_32ty_selector_val+0x1e>
     798:      	cmpl	$0x11, %edx
     79b:      	jb	0x881 <filter_32ty_selector_val+0x211>
     7a1:      	cmpl	0x18(%rdi), %ecx
     7a4:      	jg	0x68e <filter_32ty_selector_val+0x1e>
     7aa:      	cmpl	$0x15, %edx
     7ad:      	jb	0x881 <filter_32ty_selector_val+0x211>
     7b3:      	cmpl	0x1c(%rdi), %ecx
     7b6:      	jg	0x68e <filter_32ty_selector_val+0x1e>
     7bc:      	jmp	0x881 <filter_32ty_selector_val+0x211>
     7c1:      	movl	0x8(%rdi), %esi
     7c4:      	cmpl	$0xd, %esi
     7c7:      	jb	0x7ee <filter_32ty_selector_val+0x17e>
     7c9:      	cmpl	0x14(%rdi), %edx
     7cc:      	je	0x6a5 <filter_32ty_selector_val+0x35>
     7d2:      	cmpl	$0x11, %esi
     7d5:      	jb	0x7ee <filter_32ty_selector_val+0x17e>
     7d7:      	cmpl	0x18(%rdi), %edx
     7da:      	je	0x6a5 <filter_32ty_selector_val+0x35>
     7e0:      	cmpl	$0x15, %esi
     7e3:      	jb	0x7ee <filter_32ty_selector_val+0x17e>
     7e5:      	cmpl	0x1c(%rdi), %edx
     7e8:      	je	0x6a5 <filter_32ty_selector_val+0x35>
     7ee:      	cmpl	$0x25, %ecx
     7f1:      	ja	0x881 <filter_32ty_selector_val+0x211>
     7f7:      	movl	%ecx, %ecx
     7f9:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     803:      	btq	%rcx, %rdx
     807:      	jb	0x68e <filter_32ty_selector_val+0x1e>
     80d:      	jmp	0x881 <filter_32ty_selector_val+0x211>
     80f:      	movl	(%rsi), %ecx
     811:      	cmpl	0x10(%rdi), %ecx
     814:      	ja	0x68e <filter_32ty_selector_val+0x1e>
     81a:      	movl	0x8(%rdi), %edx
     81d:      	cmpl	$0xd, %edx
     820:      	jb	0x881 <filter_32ty_selector_val+0x211>
     822:      	cmpl	0x14(%rdi), %ecx
     825:      	ja	0x68e <filter_32ty_selector_val+0x1e>
     82b:      	cmpl	$0x11, %edx
     82e:      	jb	0x881 <filter_32ty_selector_val+0x211>
     830:      	cmpl	0x18(%rdi), %ecx
     833:      	ja	0x68e <filter_32ty_selector_val+0x1e>
     839:      	cmpl	$0x15, %edx
     83c:      	jb	0x881 <filter_32ty_selector_val+0x211>
     83e:      	cmpl	0x1c(%rdi), %ecx
     841:      	ja	0x68e <filter_32ty_selector_val+0x1e>
     847:      	jmp	0x881 <filter_32ty_selector_val+0x211>
     849:      	movl	(%rsi), %ecx
     84b:      	cmpl	0x10(%rdi), %ecx
     84e:      	jb	0x68e <filter_32ty_selector_val+0x1e>
     854:      	movl	0x8(%rdi), %edx
     857:      	cmpl	$0xd, %edx
     85a:      	jb	0x881 <filter_32ty_selector_val+0x211>
     85c:      	cmpl	0x14(%rdi), %ecx
     85f:      	jb	0x68e <filter_32ty_selector_val+0x1e>
     865:      	cmpl	$0x11, %edx
     868:      	jb	0x881 <filter_32ty_selector_val+0x211>
     86a:      	cmpl	0x18(%rdi), %ecx
     86d:      	jb	0x68e <filter_32ty_selector_val+0x1e>
     873:      	cmpl	$0x15, %edx
     876:      	jb	0x881 <filter_32ty_selector_val+0x211>
     878:      	cmpl	0x1c(%rdi), %ecx
     87b:      	jb	0x68e <filter_32ty_selector_val+0x1e>
     881:      	xorl	%eax, %eax
     883:      	retq
     884:      	nopw	%cs:(%rax,%rax)

0000000000000890 <filter_32ty_map>:
     890:      	pushq	%r14
     892:      	pushq	%rbx
     893:      	subq	$0x18, %rsp
     897:      	movq	%rsi, %r14
     89a:      	movq	%rdi, %rbx
     89d:      	movzbl	0x10(%rdi), %eax
     8a1:      	movl	%eax, 0xc(%rsp)
     8a5:      	movq	(%rip), %rdi            # 0x8ac <filter_32ty_map+0x1c>
     8ac:      	leaq	0xc(%rsp), %rsi
     8b1:      	movl	$0x1, %eax
     8b6:      	callq	*%rax
     8b8:      	testq	%rax, %rax
     8bb:      	je	0x8f0 <filter_32ty_map+0x60>
     8bd:      	movq	%rax, %rdi
     8c0:      	movl	(%r14), %eax
     8c3:      	movq	%rax, 0x10(%rsp)
     8c8:      	leaq	0x10(%rsp), %rsi
     8cd:      	movl	$0x1, %eax
     8d2:      	callq	*%rax
     8d4:      	movl	0x4(%rbx), %edx
     8d7:      	xorl	%ecx, %ecx
     8d9:      	cmpl	$0x1d, %edx
     8dc:      	ja	0x90a <filter_32ty_map+0x7a>
     8de:      	movl	$0x30038400, %esi       # imm = 0x30038400
     8e3:      	btl	%edx, %esi
     8e6:      	jae	0x8fa <filter_32ty_map+0x6a>
     8e8:      	testq	%rax, %rax
     8eb:      	setne	%cl
     8ee:      	jmp	0x90a <filter_32ty_map+0x7a>
     8f0:      	xorl	%eax, %eax
     8f2:      	addq	$0x18, %rsp
     8f6:      	popq	%rbx
     8f7:      	popq	%r14
     8f9:      	retq
     8fa:      	movl	$0xc0800, %esi          # imm = 0xC0800
     8ff:      	btl	%edx, %esi
     902:      	jae	0x90a <filter_32ty_map+0x7a>
     904:      	testq	%rax, %rax
     907:      	sete	%cl
     90a:      	movzbl	%cl, %eax
     90d:      	addq	$0x18, %rsp
     911:      	popq	%rbx
     912:      	popq	%r14
     914:      	retq
     915:      	nopw	%cs:(%rax,%rax)

0000000000000920 <filter_32ty_range>:
     920:      	movl	0x4(%rdi), %ecx
     923:      	movl	0xc(%rdi), %eax
     926:      	cmpl	$0xc, %eax
     929:      	ja	0xa0f <filter_32ty_range+0xef>
     92f:      	movl	$0x1402, %edx           # imm = 0x1402
     934:      	btl	%eax, %edx
     937:      	jae	0xa0f <filter_32ty_range+0xef>
     93d:      	movl	(%rsi), %esi
     93f:      	cmpl	$0x1f, %ecx
     942:      	jne	0x9aa <filter_32ty_range+0x8a>
     944:      	movl	$0x1, %eax
     949:      	cmpl	%esi, 0x10(%rdi)
     94c:      	jg	0x957 <filter_32ty_range+0x37>
     94e:      	cmpl	0x14(%rdi), %esi
     951:      	jle	0xa25 <filter_32ty_range+0x105>
     957:      	movl	0x8(%rdi), %edx
     95a:      	cmpl	$0x11, %edx
     95d:      	jb	0xac5 <filter_32ty_range+0x1a5>
     963:      	cmpl	%esi, 0x18(%rdi)
     966:      	jg	0x971 <filter_32ty_range+0x51>
     968:      	cmpl	0x1c(%rdi), %esi
     96b:      	jle	0xa25 <filter_32ty_range+0x105>
     971:      	cmpl	$0x19, %edx
     974:      	jb	0xac5 <filter_32ty_range+0x1a5>
     97a:      	cmpl	%esi, 0x20(%rdi)
     97d:      	jg	0x988 <filter_32ty_range+0x68>
     97f:      	cmpl	0x24(%rdi), %esi
     982:      	jle	0xa25 <filter_32ty_range+0x105>
     988:      	cmpl	$0x21, %edx
     98b:      	jb	0xac5 <filter_32ty_range+0x1a5>
     991:      	xorl	%edx, %edx
     993:      	cmpl	%esi, 0x28(%rdi)
     996:      	jg	0xac7 <filter_32ty_range+0x1a7>
     99c:      	cmpl	0x2c(%rdi), %esi
     99f:      	jle	0xa25 <filter_32ty_range+0x105>
     9a5:      	jmp	0xac7 <filter_32ty_range+0x1a7>
     9aa:      	movl	0x8(%rdi), %eax
     9ad:      	cmpl	%esi, 0x10(%rdi)
     9b0:      	setle	%r8b
     9b4:      	cmpl	0x14(%rdi), %esi
     9b7:      	setle	%dl
     9ba:      	andb	%r8b, %dl
     9bd:      	cmpl	$0x11, %eax
     9c0:      	jb	0xac7 <filter_32ty_range+0x1a7>
     9c6:      	cmpl	%esi, 0x18(%rdi)
     9c9:      	setle	%r8b
     9cd:      	cmpl	0x1c(%rdi), %esi
     9d0:      	setle	%r9b
     9d4:      	andb	%r8b, %r9b
     9d7:      	orb	%r9b, %dl
     9da:      	cmpl	$0x19, %eax
     9dd:      	jb	0xac7 <filter_32ty_range+0x1a7>
     9e3:      	cmpl	%esi, 0x20(%rdi)
     9e6:      	setle	%r8b
     9ea:      	cmpl	0x24(%rdi), %esi
     9ed:      	setle	%r9b
     9f1:      	andb	%r8b, %r9b
     9f4:      	orb	%r9b, %dl
     9f7:      	cmpl	$0x21, %eax
     9fa:      	jb	0xac7 <filter_32ty_range+0x1a7>
     a00:      	cmpl	%esi, 0x28(%rdi)
     a03:      	setle	%al
     a06:      	cmpl	0x2c(%rdi), %esi
     a09:      	setle	%sil
     a0d:      	jmp	0xa81 <filter_32ty_range+0x161>
     a0f:      	movl	(%rsi), %esi
     a11:      	cmpl	$0x1f, %ecx
     a14:      	jne	0xa26 <filter_32ty_range+0x106>
     a16:      	movl	$0x1, %eax
     a1b:      	cmpl	%esi, 0x10(%rdi)
     a1e:      	ja	0xa89 <filter_32ty_range+0x169>
     a20:      	cmpl	0x14(%rdi), %esi
     a23:      	ja	0xa89 <filter_32ty_range+0x169>
     a25:      	retq
     a26:      	movl	0x8(%rdi), %eax
     a29:      	cmpl	%esi, 0x10(%rdi)
     a2c:      	setbe	%r8b
     a30:      	cmpl	0x14(%rdi), %esi
     a33:      	setbe	%dl
     a36:      	andb	%r8b, %dl
     a39:      	cmpl	$0x11, %eax
     a3c:      	jb	0xac7 <filter_32ty_range+0x1a7>
     a42:      	cmpl	%esi, 0x18(%rdi)
     a45:      	setbe	%r8b
     a49:      	cmpl	0x1c(%rdi), %esi
     a4c:      	setbe	%r9b
     a50:      	andb	%r8b, %r9b
     a53:      	orb	%r9b, %dl
     a56:      	cmpl	$0x19, %eax
     a59:      	jb	0xac7 <filter_32ty_range+0x1a7>
     a5b:      	cmpl	%esi, 0x20(%rdi)
     a5e:      	setbe	%r8b
     a62:      	cmpl	0x24(%rdi), %esi
     a65:      	setbe	%r9b
     a69:      	andb	%r8b, %r9b
     a6c:      	orb	%r9b, %dl
     a6f:      	cmpl	$0x21, %eax
     a72:      	jb	0xac7 <filter_32ty_range+0x1a7>
     a74:      	cmpl	%esi, 0x28(%rdi)
     a77:      	setbe	%al
     a7a:      	cmpl	0x2c(%rdi), %esi
     a7d:      	setbe	%sil
     a81:      	andb	%al, %sil
     a84:      	orb	%sil, %dl
     a87:      	jmp	0xac7 <filter_32ty_range+0x1a7>
     a89:      	movl	0x8(%rdi), %edx
     a8c:      	cmpl	$0x11, %edx
     a8f:      	jb	0xac5 <filter_32ty_range+0x1a5>
     a91:      	cmpl	%esi, 0x18(%rdi)
     a94:      	ja	0xa9b <filter_32ty_range+0x17b>
     a96:      	cmpl	0x1c(%rdi), %esi
     a99:      	jbe	0xa25 <filter_32ty_range+0x105>
     a9b:      	cmpl	$0x19, %edx
     a9e:      	jb	0xac5 <filter_32ty_range+0x1a5>
     aa0:      	cmpl	%esi, 0x20(%rdi)
     aa3:      	ja	0xaae <filter_32ty_range+0x18e>
     aa5:      	cmpl	0x24(%rdi), %esi
     aa8:      	jbe	0xa25 <filter_32ty_range+0x105>
     aae:      	cmpl	$0x21, %edx
     ab1:      	jb	0xac5 <filter_32ty_range+0x1a5>
     ab3:      	xorl	%edx, %edx
     ab5:      	cmpl	%esi, 0x28(%rdi)
     ab8:      	ja	0xac7 <filter_32ty_range+0x1a7>
     aba:      	cmpl	0x2c(%rdi), %esi
     abd:      	jbe	0xa25 <filter_32ty_range+0x105>
     ac3:      	jmp	0xac7 <filter_32ty_range+0x1a7>
     ac5:      	xorl	%edx, %edx
     ac7:      	cmpl	$0x20, %ecx
     aca:      	sete	%al
     acd:      	xorb	$0x1, %dl
     ad0:      	andb	%al, %dl
     ad2:      	movzbl	%dl, %eax
     ad5:      	retq
     ad6:      	nopw	%cs:(%rax,%rax)

0000000000000ae0 <filter_16ty_selector_val>:
     ae0:      	movl	0x4(%rdi), %ecx
     ae3:      	movl	$0x1, %eax
     ae8:      	cmpq	$0x25, %rcx
     aec:      	ja	0xb5f <filter_16ty_selector_val+0x7f>
     aee:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     af8:      	btq	%rcx, %rdx
     afc:      	jae	0xaff <filter_16ty_selector_val+0x1f>
     afe:      	retq
     aff:      	movl	$0x18, %edx
     b04:      	btq	%rcx, %rdx
     b08:      	jae	0xb1f <filter_16ty_selector_val+0x3f>
     b0a:      	movzwl	(%rsi), %edx
     b0d:      	cmpl	%edx, 0x10(%rdi)
     b10:      	jne	0xc35 <filter_16ty_selector_val+0x155>
     b16:      	xorl	%eax, %eax
     b18:      	cmpl	$0x3, %ecx
     b1b:      	sete	%al
     b1e:      	retq
     b1f:      	cmpq	$0xc, %rcx
     b23:      	jne	0xb5f <filter_16ty_selector_val+0x7f>
     b25:      	movzwl	(%rsi), %ecx
     b28:      	testl	%ecx, 0x10(%rdi)
     b2b:      	jne	0xafe <filter_16ty_selector_val+0x1e>
     b2d:      	movl	0x8(%rdi), %edx
     b30:      	cmpl	$0xd, %edx
     b33:      	jb	0xcf7 <filter_16ty_selector_val+0x217>
     b39:      	testl	%ecx, 0x14(%rdi)
     b3c:      	jne	0xafe <filter_16ty_selector_val+0x1e>
     b3e:      	cmpl	$0x11, %edx
     b41:      	jb	0xcf7 <filter_16ty_selector_val+0x217>
     b47:      	testl	%ecx, 0x18(%rdi)
     b4a:      	jne	0xafe <filter_16ty_selector_val+0x1e>
     b4c:      	cmpl	$0x15, %edx
     b4f:      	jb	0xcf7 <filter_16ty_selector_val+0x217>
     b55:      	testl	%ecx, 0x1c(%rdi)
     b58:      	jne	0xafe <filter_16ty_selector_val+0x1e>
     b5a:      	jmp	0xcf7 <filter_16ty_selector_val+0x217>
     b5f:      	cmpl	$0x1, %ecx
     b62:      	je	0xbd1 <filter_16ty_selector_val+0xf1>
     b64:      	cmpl	$0x2, %ecx
     b67:      	jne	0xcf7 <filter_16ty_selector_val+0x217>
     b6d:      	movl	0xc(%rdi), %ecx
     b70:      	cmpl	$0xc, %ecx
     b73:      	ja	0xcbe <filter_16ty_selector_val+0x1de>
     b79:      	movl	$0x1402, %edx           # imm = 0x1402
     b7e:      	btl	%ecx, %edx
     b81:      	jae	0xcbe <filter_16ty_selector_val+0x1de>
     b87:      	movswl	(%rsi), %ecx
     b8a:      	cmpl	%ecx, 0x10(%rdi)
     b8d:      	jg	0xafe <filter_16ty_selector_val+0x1e>
     b93:      	movl	0x8(%rdi), %edx
     b96:      	cmpl	$0xd, %edx
     b99:      	jb	0xcf7 <filter_16ty_selector_val+0x217>
     b9f:      	cmpl	%ecx, 0x14(%rdi)
     ba2:      	jg	0xafe <filter_16ty_selector_val+0x1e>
     ba8:      	cmpl	$0x11, %edx
     bab:      	jb	0xcf7 <filter_16ty_selector_val+0x217>
     bb1:      	cmpl	%ecx, 0x18(%rdi)
     bb4:      	jg	0xafe <filter_16ty_selector_val+0x1e>
     bba:      	cmpl	$0x15, %edx
     bbd:      	jb	0xcf7 <filter_16ty_selector_val+0x217>
     bc3:      	cmpl	%ecx, 0x1c(%rdi)
     bc6:      	jg	0xafe <filter_16ty_selector_val+0x1e>
     bcc:      	jmp	0xcf7 <filter_16ty_selector_val+0x217>
     bd1:      	movl	0xc(%rdi), %ecx
     bd4:      	cmpl	$0xc, %ecx
     bd7:      	ja	0xc83 <filter_16ty_selector_val+0x1a3>
     bdd:      	movl	$0x1402, %edx           # imm = 0x1402
     be2:      	btl	%ecx, %edx
     be5:      	jae	0xc83 <filter_16ty_selector_val+0x1a3>
     beb:      	movswl	(%rsi), %ecx
     bee:      	cmpl	%ecx, 0x10(%rdi)
     bf1:      	jl	0xafe <filter_16ty_selector_val+0x1e>
     bf7:      	movl	0x8(%rdi), %edx
     bfa:      	cmpl	$0xd, %edx
     bfd:      	jb	0xcf7 <filter_16ty_selector_val+0x217>
     c03:      	cmpl	%ecx, 0x14(%rdi)
     c06:      	jl	0xafe <filter_16ty_selector_val+0x1e>
     c0c:      	cmpl	$0x11, %edx
     c0f:      	jb	0xcf7 <filter_16ty_selector_val+0x217>
     c15:      	cmpl	%ecx, 0x18(%rdi)
     c18:      	jl	0xafe <filter_16ty_selector_val+0x1e>
     c1e:      	cmpl	$0x15, %edx
     c21:      	jb	0xcf7 <filter_16ty_selector_val+0x217>
     c27:      	cmpl	%ecx, 0x1c(%rdi)
     c2a:      	jl	0xafe <filter_16ty_selector_val+0x1e>
     c30:      	jmp	0xcf7 <filter_16ty_selector_val+0x217>
     c35:      	movl	0x8(%rdi), %esi
     c38:      	cmpl	$0xd, %esi
     c3b:      	jb	0xc62 <filter_16ty_selector_val+0x182>
     c3d:      	cmpl	%edx, 0x14(%rdi)
     c40:      	je	0xb16 <filter_16ty_selector_val+0x36>
     c46:      	cmpl	$0x11, %esi
     c49:      	jb	0xc62 <filter_16ty_selector_val+0x182>
     c4b:      	cmpl	%edx, 0x18(%rdi)
     c4e:      	je	0xb16 <filter_16ty_selector_val+0x36>
     c54:      	cmpl	$0x15, %esi
     c57:      	jb	0xc62 <filter_16ty_selector_val+0x182>
     c59:      	cmpl	%edx, 0x1c(%rdi)
     c5c:      	je	0xb16 <filter_16ty_selector_val+0x36>
     c62:      	cmpl	$0x25, %ecx
     c65:      	ja	0xcf7 <filter_16ty_selector_val+0x217>
     c6b:      	movl	%ecx, %ecx
     c6d:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     c77:      	btq	%rcx, %rdx
     c7b:      	jb	0xafe <filter_16ty_selector_val+0x1e>
     c81:      	jmp	0xcf7 <filter_16ty_selector_val+0x217>
     c83:      	movzwl	(%rsi), %ecx
     c86:      	cmpl	%ecx, 0x10(%rdi)
     c89:      	jb	0xafe <filter_16ty_selector_val+0x1e>
     c8f:      	movl	0x8(%rdi), %edx
     c92:      	cmpl	$0xd, %edx
     c95:      	jb	0xcf7 <filter_16ty_selector_val+0x217>
     c97:      	cmpl	%ecx, 0x14(%rdi)
     c9a:      	jb	0xafe <filter_16ty_selector_val+0x1e>
     ca0:      	cmpl	$0x11, %edx
     ca3:      	jb	0xcf7 <filter_16ty_selector_val+0x217>
     ca5:      	cmpl	%ecx, 0x18(%rdi)
     ca8:      	jb	0xafe <filter_16ty_selector_val+0x1e>
     cae:      	cmpl	$0x15, %edx
     cb1:      	jb	0xcf7 <filter_16ty_selector_val+0x217>
     cb3:      	cmpl	%ecx, 0x1c(%rdi)
     cb6:      	jb	0xafe <filter_16ty_selector_val+0x1e>
     cbc:      	jmp	0xcf7 <filter_16ty_selector_val+0x217>
     cbe:      	movzwl	(%rsi), %ecx
     cc1:      	cmpl	%ecx, 0x10(%rdi)
     cc4:      	ja	0xafe <filter_16ty_selector_val+0x1e>
     cca:      	movl	0x8(%rdi), %edx
     ccd:      	cmpl	$0xd, %edx
     cd0:      	jb	0xcf7 <filter_16ty_selector_val+0x217>
     cd2:      	cmpl	%ecx, 0x14(%rdi)
     cd5:      	ja	0xafe <filter_16ty_selector_val+0x1e>
     cdb:      	cmpl	$0x11, %edx
     cde:      	jb	0xcf7 <filter_16ty_selector_val+0x217>
     ce0:      	cmpl	%ecx, 0x18(%rdi)
     ce3:      	ja	0xafe <filter_16ty_selector_val+0x1e>
     ce9:      	cmpl	$0x15, %edx
     cec:      	jb	0xcf7 <filter_16ty_selector_val+0x217>
     cee:      	cmpl	%ecx, 0x1c(%rdi)
     cf1:      	ja	0xafe <filter_16ty_selector_val+0x1e>
     cf7:      	xorl	%eax, %eax
     cf9:      	retq
     cfa:      	nopw	(%rax,%rax)

0000000000000d00 <filter_16ty_map>:
     d00:      	pushq	%r14
     d02:      	pushq	%rbx
     d03:      	subq	$0x18, %rsp
     d07:      	movq	%rsi, %r14
     d0a:      	movq	%rdi, %rbx
     d0d:      	movzbl	0x10(%rdi), %eax
     d11:      	movl	%eax, 0xc(%rsp)
     d15:      	movq	(%rip), %rdi            # 0xd1c <filter_16ty_map+0x1c>
     d1c:      	leaq	0xc(%rsp), %rsi
     d21:      	movl	$0x1, %eax
     d26:      	callq	*%rax
     d28:      	testq	%rax, %rax
     d2b:      	je	0xd61 <filter_16ty_map+0x61>
     d2d:      	movq	%rax, %rdi
     d30:      	movzwl	(%r14), %eax
     d34:      	movq	%rax, 0x10(%rsp)
     d39:      	leaq	0x10(%rsp), %rsi
     d3e:      	movl	$0x1, %eax
     d43:      	callq	*%rax
     d45:      	movl	0x4(%rbx), %edx
     d48:      	xorl	%ecx, %ecx
     d4a:      	cmpl	$0x1d, %edx
     d4d:      	ja	0xd7b <filter_16ty_map+0x7b>
     d4f:      	movl	$0x30038400, %esi       # imm = 0x30038400
     d54:      	btl	%edx, %esi
     d57:      	jae	0xd6b <filter_16ty_map+0x6b>
     d59:      	testq	%rax, %rax
     d5c:      	setne	%cl
     d5f:      	jmp	0xd7b <filter_16ty_map+0x7b>
     d61:      	xorl	%eax, %eax
     d63:      	addq	$0x18, %rsp
     d67:      	popq	%rbx
     d68:      	popq	%r14
     d6a:      	retq
     d6b:      	movl	$0xc0800, %esi          # imm = 0xC0800
     d70:      	btl	%edx, %esi
     d73:      	jae	0xd7b <filter_16ty_map+0x7b>
     d75:      	testq	%rax, %rax
     d78:      	sete	%cl
     d7b:      	movzbl	%cl, %eax
     d7e:      	addq	$0x18, %rsp
     d82:      	popq	%rbx
     d83:      	popq	%r14
     d85:      	retq
     d86:      	nopw	%cs:(%rax,%rax)

0000000000000d90 <filter_16ty_range>:
     d90:      	movl	0x4(%rdi), %ecx
     d93:      	movl	0xc(%rdi), %eax
     d96:      	cmpl	$0xc, %eax
     d99:      	ja	0xe80 <filter_16ty_range+0xf0>
     d9f:      	movl	$0x1402, %edx           # imm = 0x1402
     da4:      	btl	%eax, %edx
     da7:      	jae	0xe80 <filter_16ty_range+0xf0>
     dad:      	movswl	(%rsi), %esi
     db0:      	cmpl	$0x1f, %ecx
     db3:      	jne	0xe1b <filter_16ty_range+0x8b>
     db5:      	movl	$0x1, %eax
     dba:      	cmpl	%esi, 0x10(%rdi)
     dbd:      	jg	0xdc8 <filter_16ty_range+0x38>
     dbf:      	cmpl	%esi, 0x14(%rdi)
     dc2:      	jge	0xe97 <filter_16ty_range+0x107>
     dc8:      	movl	0x8(%rdi), %edx
     dcb:      	cmpl	$0x11, %edx
     dce:      	jb	0xf37 <filter_16ty_range+0x1a7>
     dd4:      	cmpl	%esi, 0x18(%rdi)
     dd7:      	jg	0xde2 <filter_16ty_range+0x52>
     dd9:      	cmpl	%esi, 0x1c(%rdi)
     ddc:      	jge	0xe97 <filter_16ty_range+0x107>
     de2:      	cmpl	$0x19, %edx
     de5:      	jb	0xf37 <filter_16ty_range+0x1a7>
     deb:      	cmpl	%esi, 0x20(%rdi)
     dee:      	jg	0xdf9 <filter_16ty_range+0x69>
     df0:      	cmpl	%esi, 0x24(%rdi)
     df3:      	jge	0xe97 <filter_16ty_range+0x107>
     df9:      	cmpl	$0x21, %edx
     dfc:      	jb	0xf37 <filter_16ty_range+0x1a7>
     e02:      	xorl	%edx, %edx
     e04:      	cmpl	%esi, 0x28(%rdi)
     e07:      	jg	0xf39 <filter_16ty_range+0x1a9>
     e0d:      	cmpl	%esi, 0x2c(%rdi)
     e10:      	jge	0xe97 <filter_16ty_range+0x107>
     e16:      	jmp	0xf39 <filter_16ty_range+0x1a9>
     e1b:      	movl	0x8(%rdi), %eax
     e1e:      	cmpl	%esi, 0x10(%rdi)
     e21:      	setle	%r8b
     e25:      	cmpl	%esi, 0x14(%rdi)
     e28:      	setge	%dl
     e2b:      	andb	%r8b, %dl
     e2e:      	cmpl	$0x11, %eax
     e31:      	jb	0xf39 <filter_16ty_range+0x1a9>
     e37:      	cmpl	%esi, 0x18(%rdi)
     e3a:      	setle	%r8b
     e3e:      	cmpl	%esi, 0x1c(%rdi)
     e41:      	setge	%r9b
     e45:      	andb	%r8b, %r9b
     e48:      	orb	%r9b, %dl
     e4b:      	cmpl	$0x19, %eax
     e4e:      	jb	0xf39 <filter_16ty_range+0x1a9>
     e54:      	cmpl	%esi, 0x20(%rdi)
     e57:      	setle	%r8b
     e5b:      	cmpl	%esi, 0x24(%rdi)
     e5e:      	setge	%r9b
     e62:      	andb	%r8b, %r9b
     e65:      	orb	%r9b, %dl
     e68:      	cmpl	$0x21, %eax
     e6b:      	jb	0xf39 <filter_16ty_range+0x1a9>
     e71:      	cmpl	%esi, 0x28(%rdi)
     e74:      	setle	%al
     e77:      	cmpl	%esi, 0x2c(%rdi)
     e7a:      	setge	%sil
     e7e:      	jmp	0xef3 <filter_16ty_range+0x163>
     e80:      	movzwl	(%rsi), %esi
     e83:      	cmpl	$0x1f, %ecx
     e86:      	jne	0xe98 <filter_16ty_range+0x108>
     e88:      	movl	$0x1, %eax
     e8d:      	cmpl	%esi, 0x10(%rdi)
     e90:      	ja	0xefb <filter_16ty_range+0x16b>
     e92:      	cmpl	%esi, 0x14(%rdi)
     e95:      	jb	0xefb <filter_16ty_range+0x16b>
     e97:      	retq
     e98:      	movl	0x8(%rdi), %eax
     e9b:      	cmpl	%esi, 0x10(%rdi)
     e9e:      	setbe	%r8b
     ea2:      	cmpl	%esi, 0x14(%rdi)
     ea5:      	setae	%dl
     ea8:      	andb	%r8b, %dl
     eab:      	cmpl	$0x11, %eax
     eae:      	jb	0xf39 <filter_16ty_range+0x1a9>
     eb4:      	cmpl	%esi, 0x18(%rdi)
     eb7:      	setbe	%r8b
     ebb:      	cmpl	%esi, 0x1c(%rdi)
     ebe:      	setae	%r9b
     ec2:      	andb	%r8b, %r9b
     ec5:      	orb	%r9b, %dl
     ec8:      	cmpl	$0x19, %eax
     ecb:      	jb	0xf39 <filter_16ty_range+0x1a9>
     ecd:      	cmpl	%esi, 0x20(%rdi)
     ed0:      	setbe	%r8b
     ed4:      	cmpl	%esi, 0x24(%rdi)
     ed7:      	setae	%r9b
     edb:      	andb	%r8b, %r9b
     ede:      	orb	%r9b, %dl
     ee1:      	cmpl	$0x21, %eax
     ee4:      	jb	0xf39 <filter_16ty_range+0x1a9>
     ee6:      	cmpl	%esi, 0x28(%rdi)
     ee9:      	setbe	%al
     eec:      	cmpl	%esi, 0x2c(%rdi)
     eef:      	setae	%sil
     ef3:      	andb	%al, %sil
     ef6:      	orb	%sil, %dl
     ef9:      	jmp	0xf39 <filter_16ty_range+0x1a9>
     efb:      	movl	0x8(%rdi), %edx
     efe:      	cmpl	$0x11, %edx
     f01:      	jb	0xf37 <filter_16ty_range+0x1a7>
     f03:      	cmpl	%esi, 0x18(%rdi)
     f06:      	ja	0xf0d <filter_16ty_range+0x17d>
     f08:      	cmpl	%esi, 0x1c(%rdi)
     f0b:      	jae	0xe97 <filter_16ty_range+0x107>
     f0d:      	cmpl	$0x19, %edx
     f10:      	jb	0xf37 <filter_16ty_range+0x1a7>
     f12:      	cmpl	%esi, 0x20(%rdi)
     f15:      	ja	0xf20 <filter_16ty_range+0x190>
     f17:      	cmpl	%esi, 0x24(%rdi)
     f1a:      	jae	0xe97 <filter_16ty_range+0x107>
     f20:      	cmpl	$0x21, %edx
     f23:      	jb	0xf37 <filter_16ty_range+0x1a7>
     f25:      	xorl	%edx, %edx
     f27:      	cmpl	%esi, 0x28(%rdi)
     f2a:      	ja	0xf39 <filter_16ty_range+0x1a9>
     f2c:      	cmpl	%esi, 0x2c(%rdi)
     f2f:      	jae	0xe97 <filter_16ty_range+0x107>
     f35:      	jmp	0xf39 <filter_16ty_range+0x1a9>
     f37:      	xorl	%edx, %edx
     f39:      	cmpl	$0x20, %ecx
     f3c:      	sete	%al
     f3f:      	xorb	$0x1, %dl
     f42:      	andb	%al, %dl
     f44:      	movzbl	%dl, %eax
     f47:      	retq
     f48:      	nopl	(%rax,%rax)

0000000000000f50 <filter_8ty_selector_val>:
     f50:      	movl	0x4(%rdi), %ecx
     f53:      	movl	$0x1, %eax
     f58:      	cmpq	$0x25, %rcx
     f5c:      	ja	0xfcf <filter_8ty_selector_val+0x7f>
     f5e:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     f68:      	btq	%rcx, %rdx
     f6c:      	jae	0xf6f <filter_8ty_selector_val+0x1f>
     f6e:      	retq
     f6f:      	movl	$0x18, %edx
     f74:      	btq	%rcx, %rdx
     f78:      	jae	0xf8f <filter_8ty_selector_val+0x3f>
     f7a:      	movzbl	(%rsi), %edx
     f7d:      	cmpl	%edx, 0x10(%rdi)
     f80:      	jne	0x10a5 <filter_8ty_selector_val+0x155>
     f86:      	xorl	%eax, %eax
     f88:      	cmpl	$0x3, %ecx
     f8b:      	sete	%al
     f8e:      	retq
     f8f:      	cmpq	$0xc, %rcx
     f93:      	jne	0xfcf <filter_8ty_selector_val+0x7f>
     f95:      	movzbl	(%rsi), %ecx
     f98:      	testl	%ecx, 0x10(%rdi)
     f9b:      	jne	0xf6e <filter_8ty_selector_val+0x1e>
     f9d:      	movl	0x8(%rdi), %edx
     fa0:      	cmpl	$0xd, %edx
     fa3:      	jb	0x1167 <filter_8ty_selector_val+0x217>
     fa9:      	testl	%ecx, 0x14(%rdi)
     fac:      	jne	0xf6e <filter_8ty_selector_val+0x1e>
     fae:      	cmpl	$0x11, %edx
     fb1:      	jb	0x1167 <filter_8ty_selector_val+0x217>
     fb7:      	testl	%ecx, 0x18(%rdi)
     fba:      	jne	0xf6e <filter_8ty_selector_val+0x1e>
     fbc:      	cmpl	$0x15, %edx
     fbf:      	jb	0x1167 <filter_8ty_selector_val+0x217>
     fc5:      	testl	%ecx, 0x1c(%rdi)
     fc8:      	jne	0xf6e <filter_8ty_selector_val+0x1e>
     fca:      	jmp	0x1167 <filter_8ty_selector_val+0x217>
     fcf:      	cmpl	$0x1, %ecx
     fd2:      	je	0x1041 <filter_8ty_selector_val+0xf1>
     fd4:      	cmpl	$0x2, %ecx
     fd7:      	jne	0x1167 <filter_8ty_selector_val+0x217>
     fdd:      	movl	0xc(%rdi), %ecx
     fe0:      	cmpl	$0xc, %ecx
     fe3:      	ja	0x112e <filter_8ty_selector_val+0x1de>
     fe9:      	movl	$0x1402, %edx           # imm = 0x1402
     fee:      	btl	%ecx, %edx
     ff1:      	jae	0x112e <filter_8ty_selector_val+0x1de>
     ff7:      	movsbl	(%rsi), %ecx
     ffa:      	cmpl	%ecx, 0x10(%rdi)
     ffd:      	jg	0xf6e <filter_8ty_selector_val+0x1e>
    1003:      	movl	0x8(%rdi), %edx
    1006:      	cmpl	$0xd, %edx
    1009:      	jb	0x1167 <filter_8ty_selector_val+0x217>
    100f:      	cmpl	%ecx, 0x14(%rdi)
    1012:      	jg	0xf6e <filter_8ty_selector_val+0x1e>
    1018:      	cmpl	$0x11, %edx
    101b:      	jb	0x1167 <filter_8ty_selector_val+0x217>
    1021:      	cmpl	%ecx, 0x18(%rdi)
    1024:      	jg	0xf6e <filter_8ty_selector_val+0x1e>
    102a:      	cmpl	$0x15, %edx
    102d:      	jb	0x1167 <filter_8ty_selector_val+0x217>
    1033:      	cmpl	%ecx, 0x1c(%rdi)
    1036:      	jg	0xf6e <filter_8ty_selector_val+0x1e>
    103c:      	jmp	0x1167 <filter_8ty_selector_val+0x217>
    1041:      	movl	0xc(%rdi), %ecx
    1044:      	cmpl	$0xc, %ecx
    1047:      	ja	0x10f3 <filter_8ty_selector_val+0x1a3>
    104d:      	movl	$0x1402, %edx           # imm = 0x1402
    1052:      	btl	%ecx, %edx
    1055:      	jae	0x10f3 <filter_8ty_selector_val+0x1a3>
    105b:      	movsbl	(%rsi), %ecx
    105e:      	cmpl	%ecx, 0x10(%rdi)
    1061:      	jl	0xf6e <filter_8ty_selector_val+0x1e>
    1067:      	movl	0x8(%rdi), %edx
    106a:      	cmpl	$0xd, %edx
    106d:      	jb	0x1167 <filter_8ty_selector_val+0x217>
    1073:      	cmpl	%ecx, 0x14(%rdi)
    1076:      	jl	0xf6e <filter_8ty_selector_val+0x1e>
    107c:      	cmpl	$0x11, %edx
    107f:      	jb	0x1167 <filter_8ty_selector_val+0x217>
    1085:      	cmpl	%ecx, 0x18(%rdi)
    1088:      	jl	0xf6e <filter_8ty_selector_val+0x1e>
    108e:      	cmpl	$0x15, %edx
    1091:      	jb	0x1167 <filter_8ty_selector_val+0x217>
    1097:      	cmpl	%ecx, 0x1c(%rdi)
    109a:      	jl	0xf6e <filter_8ty_selector_val+0x1e>
    10a0:      	jmp	0x1167 <filter_8ty_selector_val+0x217>
    10a5:      	movl	0x8(%rdi), %esi
    10a8:      	cmpl	$0xd, %esi
    10ab:      	jb	0x10d2 <filter_8ty_selector_val+0x182>
    10ad:      	cmpl	%edx, 0x14(%rdi)
    10b0:      	je	0xf86 <filter_8ty_selector_val+0x36>
    10b6:      	cmpl	$0x11, %esi
    10b9:      	jb	0x10d2 <filter_8ty_selector_val+0x182>
    10bb:      	cmpl	%edx, 0x18(%rdi)
    10be:      	je	0xf86 <filter_8ty_selector_val+0x36>
    10c4:      	cmpl	$0x15, %esi
    10c7:      	jb	0x10d2 <filter_8ty_selector_val+0x182>
    10c9:      	cmpl	%edx, 0x1c(%rdi)
    10cc:      	je	0xf86 <filter_8ty_selector_val+0x36>
    10d2:      	cmpl	$0x25, %ecx
    10d5:      	ja	0x1167 <filter_8ty_selector_val+0x217>
    10db:      	movl	%ecx, %ecx
    10dd:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    10e7:      	btq	%rcx, %rdx
    10eb:      	jb	0xf6e <filter_8ty_selector_val+0x1e>
    10f1:      	jmp	0x1167 <filter_8ty_selector_val+0x217>
    10f3:      	movzbl	(%rsi), %ecx
    10f6:      	cmpl	%ecx, 0x10(%rdi)
    10f9:      	jb	0xf6e <filter_8ty_selector_val+0x1e>
    10ff:      	movl	0x8(%rdi), %edx
    1102:      	cmpl	$0xd, %edx
    1105:      	jb	0x1167 <filter_8ty_selector_val+0x217>
    1107:      	cmpl	%ecx, 0x14(%rdi)
    110a:      	jb	0xf6e <filter_8ty_selector_val+0x1e>
    1110:      	cmpl	$0x11, %edx
    1113:      	jb	0x1167 <filter_8ty_selector_val+0x217>
    1115:      	cmpl	%ecx, 0x18(%rdi)
    1118:      	jb	0xf6e <filter_8ty_selector_val+0x1e>
    111e:      	cmpl	$0x15, %edx
    1121:      	jb	0x1167 <filter_8ty_selector_val+0x217>
    1123:      	cmpl	%ecx, 0x1c(%rdi)
    1126:      	jb	0xf6e <filter_8ty_selector_val+0x1e>
    112c:      	jmp	0x1167 <filter_8ty_selector_val+0x217>
    112e:      	movzbl	(%rsi), %ecx
    1131:      	cmpl	%ecx, 0x10(%rdi)
    1134:      	ja	0xf6e <filter_8ty_selector_val+0x1e>
    113a:      	movl	0x8(%rdi), %edx
    113d:      	cmpl	$0xd, %edx
    1140:      	jb	0x1167 <filter_8ty_selector_val+0x217>
    1142:      	cmpl	%ecx, 0x14(%rdi)
    1145:      	ja	0xf6e <filter_8ty_selector_val+0x1e>
    114b:      	cmpl	$0x11, %edx
    114e:      	jb	0x1167 <filter_8ty_selector_val+0x217>
    1150:      	cmpl	%ecx, 0x18(%rdi)
    1153:      	ja	0xf6e <filter_8ty_selector_val+0x1e>
    1159:      	cmpl	$0x15, %edx
    115c:      	jb	0x1167 <filter_8ty_selector_val+0x217>
    115e:      	cmpl	%ecx, 0x1c(%rdi)
    1161:      	ja	0xf6e <filter_8ty_selector_val+0x1e>
    1167:      	xorl	%eax, %eax
    1169:      	retq
    116a:      	nopw	(%rax,%rax)

0000000000001170 <filter_8ty_map>:
    1170:      	pushq	%r14
    1172:      	pushq	%rbx
    1173:      	subq	$0x18, %rsp
    1177:      	movq	%rsi, %r14
    117a:      	movq	%rdi, %rbx
    117d:      	movzbl	0x10(%rdi), %eax
    1181:      	movl	%eax, 0xc(%rsp)
    1185:      	movq	(%rip), %rdi            # 0x118c <filter_8ty_map+0x1c>
    118c:      	leaq	0xc(%rsp), %rsi
    1191:      	movl	$0x1, %eax
    1196:      	callq	*%rax
    1198:      	testq	%rax, %rax
    119b:      	je	0x11d1 <filter_8ty_map+0x61>
    119d:      	movq	%rax, %rdi
    11a0:      	movzbl	(%r14), %eax
    11a4:      	movq	%rax, 0x10(%rsp)
    11a9:      	leaq	0x10(%rsp), %rsi
    11ae:      	movl	$0x1, %eax
    11b3:      	callq	*%rax
    11b5:      	movl	0x4(%rbx), %edx
    11b8:      	xorl	%ecx, %ecx
    11ba:      	cmpl	$0x1d, %edx
    11bd:      	ja	0x11eb <filter_8ty_map+0x7b>
    11bf:      	movl	$0x30038400, %esi       # imm = 0x30038400
    11c4:      	btl	%edx, %esi
    11c7:      	jae	0x11db <filter_8ty_map+0x6b>
    11c9:      	testq	%rax, %rax
    11cc:      	setne	%cl
    11cf:      	jmp	0x11eb <filter_8ty_map+0x7b>
    11d1:      	xorl	%eax, %eax
    11d3:      	addq	$0x18, %rsp
    11d7:      	popq	%rbx
    11d8:      	popq	%r14
    11da:      	retq
    11db:      	movl	$0xc0800, %esi          # imm = 0xC0800
    11e0:      	btl	%edx, %esi
    11e3:      	jae	0x11eb <filter_8ty_map+0x7b>
    11e5:      	testq	%rax, %rax
    11e8:      	sete	%cl
    11eb:      	movzbl	%cl, %eax
    11ee:      	addq	$0x18, %rsp
    11f2:      	popq	%rbx
    11f3:      	popq	%r14
    11f5:      	retq
    11f6:      	nopw	%cs:(%rax,%rax)

0000000000001200 <filter_8ty_range>:
    1200:      	movl	0x4(%rdi), %ecx
    1203:      	movl	0xc(%rdi), %eax
    1206:      	cmpl	$0xc, %eax
    1209:      	ja	0x12f0 <filter_8ty_range+0xf0>
    120f:      	movl	$0x1402, %edx           # imm = 0x1402
    1214:      	btl	%eax, %edx
    1217:      	jae	0x12f0 <filter_8ty_range+0xf0>
    121d:      	movsbl	(%rsi), %esi
    1220:      	cmpl	$0x1f, %ecx
    1223:      	jne	0x128b <filter_8ty_range+0x8b>
    1225:      	movl	$0x1, %eax
    122a:      	cmpl	%esi, 0x10(%rdi)
    122d:      	jg	0x1238 <filter_8ty_range+0x38>
    122f:      	cmpl	%esi, 0x14(%rdi)
    1232:      	jge	0x1307 <filter_8ty_range+0x107>
    1238:      	movl	0x8(%rdi), %edx
    123b:      	cmpl	$0x11, %edx
    123e:      	jb	0x13a7 <filter_8ty_range+0x1a7>
    1244:      	cmpl	%esi, 0x18(%rdi)
    1247:      	jg	0x1252 <filter_8ty_range+0x52>
    1249:      	cmpl	%esi, 0x1c(%rdi)
    124c:      	jge	0x1307 <filter_8ty_range+0x107>
    1252:      	cmpl	$0x19, %edx
    1255:      	jb	0x13a7 <filter_8ty_range+0x1a7>
    125b:      	cmpl	%esi, 0x20(%rdi)
    125e:      	jg	0x1269 <filter_8ty_range+0x69>
    1260:      	cmpl	%esi, 0x24(%rdi)
    1263:      	jge	0x1307 <filter_8ty_range+0x107>
    1269:      	cmpl	$0x21, %edx
    126c:      	jb	0x13a7 <filter_8ty_range+0x1a7>
    1272:      	xorl	%edx, %edx
    1274:      	cmpl	%esi, 0x28(%rdi)
    1277:      	jg	0x13a9 <filter_8ty_range+0x1a9>
    127d:      	cmpl	%esi, 0x2c(%rdi)
    1280:      	jge	0x1307 <filter_8ty_range+0x107>
    1286:      	jmp	0x13a9 <filter_8ty_range+0x1a9>
    128b:      	movl	0x8(%rdi), %eax
    128e:      	cmpl	%esi, 0x10(%rdi)
    1291:      	setle	%r8b
    1295:      	cmpl	%esi, 0x14(%rdi)
    1298:      	setge	%dl
    129b:      	andb	%r8b, %dl
    129e:      	cmpl	$0x11, %eax
    12a1:      	jb	0x13a9 <filter_8ty_range+0x1a9>
    12a7:      	cmpl	%esi, 0x18(%rdi)
    12aa:      	setle	%r8b
    12ae:      	cmpl	%esi, 0x1c(%rdi)
    12b1:      	setge	%r9b
    12b5:      	andb	%r8b, %r9b
    12b8:      	orb	%r9b, %dl
    12bb:      	cmpl	$0x19, %eax
    12be:      	jb	0x13a9 <filter_8ty_range+0x1a9>
    12c4:      	cmpl	%esi, 0x20(%rdi)
    12c7:      	setle	%r8b
    12cb:      	cmpl	%esi, 0x24(%rdi)
    12ce:      	setge	%r9b
    12d2:      	andb	%r8b, %r9b
    12d5:      	orb	%r9b, %dl
    12d8:      	cmpl	$0x21, %eax
    12db:      	jb	0x13a9 <filter_8ty_range+0x1a9>
    12e1:      	cmpl	%esi, 0x28(%rdi)
    12e4:      	setle	%al
    12e7:      	cmpl	%esi, 0x2c(%rdi)
    12ea:      	setge	%sil
    12ee:      	jmp	0x1363 <filter_8ty_range+0x163>
    12f0:      	movzbl	(%rsi), %esi
    12f3:      	cmpl	$0x1f, %ecx
    12f6:      	jne	0x1308 <filter_8ty_range+0x108>
    12f8:      	movl	$0x1, %eax
    12fd:      	cmpl	%esi, 0x10(%rdi)
    1300:      	ja	0x136b <filter_8ty_range+0x16b>
    1302:      	cmpl	%esi, 0x14(%rdi)
    1305:      	jb	0x136b <filter_8ty_range+0x16b>
    1307:      	retq
    1308:      	movl	0x8(%rdi), %eax
    130b:      	cmpl	%esi, 0x10(%rdi)
    130e:      	setbe	%r8b
    1312:      	cmpl	%esi, 0x14(%rdi)
    1315:      	setae	%dl
    1318:      	andb	%r8b, %dl
    131b:      	cmpl	$0x11, %eax
    131e:      	jb	0x13a9 <filter_8ty_range+0x1a9>
    1324:      	cmpl	%esi, 0x18(%rdi)
    1327:      	setbe	%r8b
    132b:      	cmpl	%esi, 0x1c(%rdi)
    132e:      	setae	%r9b
    1332:      	andb	%r8b, %r9b
    1335:      	orb	%r9b, %dl
    1338:      	cmpl	$0x19, %eax
    133b:      	jb	0x13a9 <filter_8ty_range+0x1a9>
    133d:      	cmpl	%esi, 0x20(%rdi)
    1340:      	setbe	%r8b
    1344:      	cmpl	%esi, 0x24(%rdi)
    1347:      	setae	%r9b
    134b:      	andb	%r8b, %r9b
    134e:      	orb	%r9b, %dl
    1351:      	cmpl	$0x21, %eax
    1354:      	jb	0x13a9 <filter_8ty_range+0x1a9>
    1356:      	cmpl	%esi, 0x28(%rdi)
    1359:      	setbe	%al
    135c:      	cmpl	%esi, 0x2c(%rdi)
    135f:      	setae	%sil
    1363:      	andb	%al, %sil
    1366:      	orb	%sil, %dl
    1369:      	jmp	0x13a9 <filter_8ty_range+0x1a9>
    136b:      	movl	0x8(%rdi), %edx
    136e:      	cmpl	$0x11, %edx
    1371:      	jb	0x13a7 <filter_8ty_range+0x1a7>
    1373:      	cmpl	%esi, 0x18(%rdi)
    1376:      	ja	0x137d <filter_8ty_range+0x17d>
    1378:      	cmpl	%esi, 0x1c(%rdi)
    137b:      	jae	0x1307 <filter_8ty_range+0x107>
    137d:      	cmpl	$0x19, %edx
    1380:      	jb	0x13a7 <filter_8ty_range+0x1a7>
    1382:      	cmpl	%esi, 0x20(%rdi)
    1385:      	ja	0x1390 <filter_8ty_range+0x190>
    1387:      	cmpl	%esi, 0x24(%rdi)
    138a:      	jae	0x1307 <filter_8ty_range+0x107>
    1390:      	cmpl	$0x21, %edx
    1393:      	jb	0x13a7 <filter_8ty_range+0x1a7>
    1395:      	xorl	%edx, %edx
    1397:      	cmpl	%esi, 0x28(%rdi)
    139a:      	ja	0x13a9 <filter_8ty_range+0x1a9>
    139c:      	cmpl	%esi, 0x2c(%rdi)
    139f:      	jae	0x1307 <filter_8ty_range+0x107>
    13a5:      	jmp	0x13a9 <filter_8ty_range+0x1a9>
    13a7:      	xorl	%edx, %edx
    13a9:      	cmpl	$0x20, %ecx
    13ac:      	sete	%al
    13af:      	xorb	$0x1, %dl
    13b2:      	andb	%al, %dl
    13b4:      	movzbl	%dl, %eax
    13b7:      	retq
    13b8:      	nopl	(%rax,%rax)

00000000000013c0 <filter_file_buf>:
    13c0:      	pushq	%rbx
    13c1:      	movq	%rdi, %rbx
    13c4:      	movl	(%rsi), %edx
    13c6:      	movl	0x4(%rdi), %ecx
    13c9:      	testl	%edx, %edx
    13cb:      	jne	0x13db <filter_file_buf+0x1b>
    13cd:      	movl	%ecx, %eax
    13cf:      	andl	$-0x2, %eax
    13d2:      	cmpl	$0x24, %eax
    13d5:      	je	0x13db <filter_file_buf+0x1b>
    13d7:      	xorl	%eax, %eax
    13d9:      	popq	%rbx
    13da:      	retq
    13db:      	cmpl	$0x25, %ecx
    13de:      	ja	0x141a <filter_file_buf+0x5a>
    13e0:      	movl	%ecx, %eax
    13e2:      	movl	$0x4000100, %edi        # imm = 0x4000100
    13e7:      	btq	%rax, %rdi
    13eb:      	jb	0x144e <filter_file_buf+0x8e>
    13ed:      	movl	$0x8000200, %edi        # imm = 0x8000200
    13f2:      	btq	%rax, %rdi
    13f6:      	jb	0x1438 <filter_file_buf+0x78>
    13f8:      	movabsq	$0x3000000000, %rdi     # imm = 0x3000000000
    1402:      	btq	%rax, %rdi
    1406:      	jae	0x141a <filter_file_buf+0x5a>
    1408:      	movq	%rbx, %rdi
    140b:      	callq	0x1eb0 <filter_file_type>
    1410:      	movl	0x4(%rbx), %ecx
    1413:      	cmpl	$0x25, %ecx
    1416:      	jbe	0x146b <filter_file_buf+0xab>
    1418:      	jmp	0x1481 <filter_file_buf+0xc1>
    141a:      	leal	-0x3(%rcx), %eax
    141d:      	cmpl	$0x2, %eax
    1420:      	jae	0x1464 <filter_file_buf+0xa4>
    1422:      	addq	$0x4, %rsi
    1426:      	movq	%rbx, %rdi
    1429:      	callq	0x1940 <filter_char_buf_equal>
    142e:      	movl	0x4(%rbx), %ecx
    1431:      	cmpl	$0x25, %ecx
    1434:      	jbe	0x146b <filter_file_buf+0xab>
    1436:      	jmp	0x1481 <filter_file_buf+0xc1>
    1438:      	addq	$0x4, %rsi
    143c:      	movl	0x10(%rbx), %edi
    143f:      	callq	0x1d60 <filter_char_buf_postfix>
    1444:      	movl	0x4(%rbx), %ecx
    1447:      	cmpl	$0x25, %ecx
    144a:      	jbe	0x146b <filter_file_buf+0xab>
    144c:      	jmp	0x1481 <filter_file_buf+0xc1>
    144e:      	addq	$0x4, %rsi
    1452:      	movl	0x10(%rbx), %edi
    1455:      	callq	0x1cc0 <filter_char_buf_prefix>
    145a:      	movl	0x4(%rbx), %ecx
    145d:      	cmpl	$0x25, %ecx
    1460:      	jbe	0x146b <filter_file_buf+0xab>
    1462:      	jmp	0x1481 <filter_file_buf+0xc1>
    1464:      	xorl	%eax, %eax
    1466:      	cmpl	$0x25, %ecx
    1469:      	ja	0x1481 <filter_file_buf+0xc1>
    146b:      	movl	%ecx, %ecx
    146d:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1477:      	btq	%rcx, %rdx
    147b:      	jae	0x1481 <filter_file_buf+0xc1>
    147d:      	xorq	$0x1, %rax
    1481:      	popq	%rbx
    1482:      	retq
    1483:      	nopw	%cs:(%rax,%rax)

0000000000001490 <filter_char_buf>:
    1490:      	pushq	%rbx
    1491:      	movq	%rsi, %rax
    1494:      	movq	%rdi, %rbx
    1497:      	movslq	%edx, %rcx
    149a:      	movl	-0x4(%rsi,%rcx), %edx
    149e:      	movl	%ecx, %esi
    14a0:      	addq	%rax, %rsi
    14a3:      	movl	0x4(%rdi), %ecx
    14a6:      	xorl	%eax, %eax
    14a8:      	cmpl	$0x19, %ecx
    14ab:      	jg	0x14c1 <filter_char_buf+0x31>
    14ad:      	leal	-0x3(%rcx), %edi
    14b0:      	cmpl	$0x2, %edi
    14b3:      	jb	0x14f8 <filter_char_buf+0x68>
    14b5:      	cmpl	$0x8, %ecx
    14b8:      	je	0x14ee <filter_char_buf+0x5e>
    14ba:      	cmpl	$0x9, %ecx
    14bd:      	je	0x14d0 <filter_char_buf+0x40>
    14bf:      	jmp	0x150f <filter_char_buf+0x7f>
    14c1:      	cmpl	$0x20, %ecx
    14c4:      	jg	0x14da <filter_char_buf+0x4a>
    14c6:      	cmpl	$0x1a, %ecx
    14c9:      	je	0x14ee <filter_char_buf+0x5e>
    14cb:      	cmpl	$0x1b, %ecx
    14ce:      	jne	0x150f <filter_char_buf+0x7f>
    14d0:      	movl	0x10(%rbx), %edi
    14d3:      	callq	0x1d60 <filter_char_buf_postfix>
    14d8:      	jmp	0x150c <filter_char_buf+0x7c>
    14da:      	cmpl	$0x21, %ecx
    14dd:      	je	0x1502 <filter_char_buf+0x72>
    14df:      	cmpl	$0x22, %ecx
    14e2:      	jne	0x150f <filter_char_buf+0x7f>
    14e4:      	movq	%rbx, %rdi
    14e7:      	movl	$0x1, %ecx
    14ec:      	jmp	0x1507 <filter_char_buf+0x77>
    14ee:      	movl	0x10(%rbx), %edi
    14f1:      	callq	0x1cc0 <filter_char_buf_prefix>
    14f6:      	jmp	0x150c <filter_char_buf+0x7c>
    14f8:      	movq	%rbx, %rdi
    14fb:      	callq	0x1940 <filter_char_buf_equal>
    1500:      	jmp	0x150c <filter_char_buf+0x7c>
    1502:      	movq	%rbx, %rdi
    1505:      	xorl	%ecx, %ecx
    1507:      	callq	0x1f60 <filter_char_substring>
    150c:      	movl	0x4(%rbx), %ecx
    150f:      	cmpl	$0x25, %ecx
    1512:      	ja	0x1531 <filter_char_buf+0xa1>
    1514:      	movl	%ecx, %ecx
    1516:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1520:      	btq	%rcx, %rdx
    1524:      	jae	0x1531 <filter_char_buf+0xa1>
    1526:      	xorl	%ecx, %ecx
    1528:      	testq	%rax, %rax
    152b:      	sete	%cl
    152e:      	movq	%rcx, %rax
    1531:      	popq	%rbx
    1532:      	retq
    1533:      	nopw	%cs:(%rax,%rax)

0000000000001540 <filter_inet>:
    1540:      	pushq	%r15
    1542:      	pushq	%r14
    1544:      	pushq	%r12
    1546:      	pushq	%rbx
    1547:      	subq	$0x48, %rsp
    154b:      	movq	$0x0, 0x40(%rsp)
    1554:      	movq	$0x0, 0x38(%rsp)
    155d:      	movq	$0x0, 0x30(%rsp)
    1566:      	movq	$0x0, 0x28(%rsp)
    156f:      	movq	$0x0, 0x20(%rsp)
    1578:      	movl	$0x0, (%rsp)
    157f:      	movl	$0x0, 0x4(%rsp)
    1587:      	movl	0xc(%rdi), %edx
    158a:      	xorl	%eax, %eax
    158c:      	cmpl	$0x27, %edx
    158f:      	jg	0x15a7 <filter_inet+0x67>
    1591:      	cmpl	$0x5, %edx
    1594:      	je	0x162c <filter_inet+0xec>
    159a:      	movq	%rsi, %r8
    159d:      	cmpl	$0x7, %edx
    15a0:      	je	0x15b8 <filter_inet+0x78>
    15a2:      	jmp	0x183d <filter_inet+0x2fd>
    15a7:      	cmpl	$0x28, %edx
    15aa:      	je	0x1604 <filter_inet+0xc4>
    15ac:      	movq	%rsi, %r8
    15af:      	cmpl	$0x29, %edx
    15b2:      	jne	0x183d <filter_inet+0x2fd>
    15b8:      	movl	0x4(%rdi), %ecx
    15bb:      	xorl	%eax, %eax
    15bd:      	cmpl	$0x13, %ecx
    15c0:      	jle	0x1639 <filter_inet+0xf9>
    15c2:      	cmpl	$0x17, %ecx
    15c5:      	jg	0x15e4 <filter_inet+0xa4>
    15c7:      	leal	-0x14(%rcx), %edx
    15ca:      	cmpl	$0x2, %edx
    15cd:      	jb	0x168a <filter_inet+0x14a>
    15d3:      	leal	-0x16(%rcx), %edx
    15d6:      	cmpl	$0x2, %edx
    15d9:      	jb	0x1684 <filter_inet+0x144>
    15df:      	jmp	0x183d <filter_inet+0x2fd>
    15e4:      	cmpl	$0x1b, %ecx
    15e7:      	jg	0x16c7 <filter_inet+0x187>
    15ed:      	cmpl	$0x18, %ecx
    15f0:      	je	0x16fa <filter_inet+0x1ba>
    15f6:      	cmpl	$0x19, %ecx
    15f9:      	je	0x16f0 <filter_inet+0x1b0>
    15ff:      	jmp	0x183d <filter_inet+0x2fd>
    1604:      	movzwl	(%rsi), %eax
    1607:      	movw	%ax, 0x46(%rsp)
    160c:      	movzwl	0x2(%rsi), %eax
    1610:      	movw	%ax, 0x40(%rsp)
    1615:      	movq	0x8(%rsi), %rax
    1619:      	movq	%rax, 0x20(%rsp)
    161e:      	movq	0x10(%rsi), %rax
    1622:      	movq	%rax, 0x28(%rsp)
    1627:      	leaq	0x20(%rsp), %rsi
    162c:      	xorl	%r8d, %r8d
    162f:      	movl	0x4(%rdi), %ecx
    1632:      	xorl	%eax, %eax
    1634:      	cmpl	$0x13, %ecx
    1637:      	jg	0x15c2 <filter_inet+0x82>
    1639:      	cmpl	$0xf, %ecx
    163c:      	jle	0x165a <filter_inet+0x11a>
    163e:      	cmpl	$0x11, %ecx
    1641:      	jg	0x1676 <filter_inet+0x136>
    1643:      	cmpl	$0x10, %ecx
    1646:      	je	0x1684 <filter_inet+0x144>
    1648:      	cmpl	$0x11, %ecx
    164b:      	jne	0x183d <filter_inet+0x2fd>
    1651:      	movzwl	0x24(%rsi), %eax
    1655:      	jmp	0x1832 <filter_inet+0x2f2>
    165a:      	cmpl	$0xd, %ecx
    165d:      	je	0x16fa <filter_inet+0x1ba>
    1663:      	cmpl	$0xe, %ecx
    1666:      	je	0x16f0 <filter_inet+0x1b0>
    166c:      	cmpl	$0xf, %ecx
    166f:      	je	0x168a <filter_inet+0x14a>
    1671:      	jmp	0x183d <filter_inet+0x2fd>
    1676:      	cmpl	$0x12, %ecx
    1679:      	je	0x168a <filter_inet+0x14a>
    167b:      	cmpl	$0x13, %ecx
    167e:      	jne	0x183d <filter_inet+0x2fd>
    1684:      	movzwl	0x22(%rsi), %edx
    1688:      	jmp	0x168e <filter_inet+0x14e>
    168a:      	movzwl	0x20(%rsi), %edx
    168e:      	movl	%edx, 0x4(%rsp)
    1692:      	xorl	%ebx, %ebx
    1694:      	xorl	%r15d, %r15d
    1697:      	xorl	%r14d, %r14d
    169a:      	xorl	%eax, %eax
    169c:      	cmpl	$0x11, %ecx
    169f:      	jg	0x1711 <filter_inet+0x1d1>
    16a1:      	leal	-0xd(%rcx), %edx
    16a4:      	cmpl	$0x2, %edx
    16a7:      	jb	0x1738 <filter_inet+0x1f8>
    16ad:      	leal	-0xf(%rcx), %edx
    16b0:      	cmpl	$0x2, %edx
    16b3:      	jb	0x178d <filter_inet+0x24d>
    16b9:      	cmpl	$0x11, %ecx
    16bc:      	je	0x1835 <filter_inet+0x2f5>
    16c2:      	jmp	0x183d <filter_inet+0x2fd>
    16c7:      	cmpl	$0x1c, %ecx
    16ca:      	je	0x182e <filter_inet+0x2ee>
    16d0:      	cmpl	$0x1d, %ecx
    16d3:      	jne	0x183d <filter_inet+0x2fd>
    16d9:      	cmpl	$0x7, %edx
    16dc:      	jne	0x1861 <filter_inet+0x321>
    16e2:      	testq	%r8, %r8
    16e5:      	jne	0x186b <filter_inet+0x32b>
    16eb:      	jmp	0x1835 <filter_inet+0x2f5>
    16f0:      	movq	0x10(%rsi), %rbx
    16f4:      	movq	0x18(%rsi), %r14
    16f8:      	jmp	0x1701 <filter_inet+0x1c1>
    16fa:      	movq	(%rsi), %rbx
    16fd:      	movq	0x8(%rsi), %r14
    1701:      	movq	%rbx, %r15
    1704:      	shrq	$0x20, %r15
    1708:      	xorl	%edx, %edx
    170a:      	xorl	%eax, %eax
    170c:      	cmpl	$0x11, %ecx
    170f:      	jle	0x16a1 <filter_inet+0x161>
    1711:      	cmpl	$0x19, %ecx
    1714:      	ja	0x1781 <filter_inet+0x241>
    1716:      	movl	$0x500000, %r8d         # imm = 0x500000
    171c:      	btl	%ecx, %r8d
    1720:      	jb	0x1797 <filter_inet+0x257>
    1722:      	movl	$0xa00000, %r8d         # imm = 0xA00000
    1728:      	btl	%ecx, %r8d
    172c:      	jb	0x17a7 <filter_inet+0x267>
    172e:      	movl	$0x3000000, %edx        # imm = 0x3000000
    1733:      	btl	%ecx, %edx
    1736:      	jae	0x1781 <filter_inet+0x241>
    1738:      	movzwl	0x26(%rsi), %eax
    173c:      	cmpl	$0xa, %eax
    173f:      	je	0x17b7 <filter_inet+0x277>
    1741:      	cmpl	$0x2, %eax
    1744:      	jne	0x1827 <filter_inet+0x2e7>
    174a:      	movq	%rdi, %r12
    174d:      	movl	0x10(%rdi), %eax
    1750:      	movl	%eax, 0x8(%rsp)
    1754:      	movq	(%rip), %rdi            # 0x175b <filter_inet+0x21b>
    175b:      	leaq	0x8(%rsp), %rsi
    1760:      	movl	$0x1, %eax
    1765:      	callq	*%rax
    1767:      	testq	%rax, %rax
    176a:      	je	0x1849 <filter_inet+0x309>
    1770:      	movq	%rax, %rdi
    1773:      	movl	$0x20, 0xc(%rsp)
    177b:      	movl	%ebx, 0x10(%rsp)
    177f:      	jmp	0x17fb <filter_inet+0x2bb>
    1781:      	addl	$-0x12, %ecx
    1784:      	cmpl	$0x2, %ecx
    1787:      	jae	0x183d <filter_inet+0x2fd>
    178d:      	leaq	0x4(%rsp), %rsi
    1792:      	jmp	0x1838 <filter_inet+0x2f8>
    1797:      	xorl	%eax, %eax
    1799:      	cmpl	$0x400, %edx            # imm = 0x400
    179f:      	setb	%al
    17a2:      	jmp	0x183d <filter_inet+0x2fd>
    17a7:      	xorl	%eax, %eax
    17a9:      	cmpl	$0x400, %edx            # imm = 0x400
    17af:      	setae	%al
    17b2:      	jmp	0x183d <filter_inet+0x2fd>
    17b7:      	movq	%rdi, %r12
    17ba:      	movl	0x14(%rdi), %eax
    17bd:      	movl	%eax, 0x8(%rsp)
    17c1:      	movq	(%rip), %rdi            # 0x17c8 <filter_inet+0x288>
    17c8:      	leaq	0x8(%rsp), %rsi
    17cd:      	movl	$0x1, %eax
    17d2:      	callq	*%rax
    17d4:      	testq	%rax, %rax
    17d7:      	je	0x1849 <filter_inet+0x309>
    17d9:      	movq	%rax, %rdi
    17dc:      	movl	$0x80, 0xc(%rsp)
    17e4:      	movl	%ebx, 0x10(%rsp)
    17e8:      	movl	%r15d, 0x14(%rsp)
    17ed:      	movl	%r14d, 0x18(%rsp)
    17f2:      	shrq	$0x20, %r14
    17f6:      	movl	%r14d, 0x1c(%rsp)
    17fb:      	leaq	0xc(%rsp), %rsi
    1800:      	movl	$0x1, %eax
    1805:      	callq	*%rax
    1807:      	movl	0x4(%r12), %ecx
    180c:      	leal	-0x18(%rcx), %edx
    180f:      	cmpl	$0x2, %edx
    1812:      	jb	0x1856 <filter_inet+0x316>
    1814:      	addl	$-0xd, %ecx
    1817:      	cmpl	$0x1, %ecx
    181a:      	ja	0x1827 <filter_inet+0x2e7>
    181c:      	testq	%rax, %rax
    181f:      	setne	%al
    1822:      	movzbl	%al, %eax
    1825:      	jmp	0x183d <filter_inet+0x2fd>
    1827:      	xorl	%eax, %eax
    1829:      	movzbl	%al, %eax
    182c:      	jmp	0x183d <filter_inet+0x2fd>
    182e:      	movzwl	0x26(%rsi), %eax
    1832:      	movl	%eax, (%rsp)
    1835:      	movq	%rsp, %rsi
    1838:      	callq	0x890 <filter_32ty_map>
    183d:      	addq	$0x48, %rsp
    1841:      	popq	%rbx
    1842:      	popq	%r12
    1844:      	popq	%r14
    1846:      	popq	%r15
    1848:      	retq
    1849:      	movl	0x4(%r12), %eax
    184e:      	andl	$-0x2, %eax
    1851:      	cmpl	$0x18, %eax
    1854:      	jmp	0x1859 <filter_inet+0x319>
    1856:      	testq	%rax, %rax
    1859:      	sete	%al
    185c:      	movzbl	%al, %eax
    185f:      	jmp	0x183d <filter_inet+0x2fd>
    1861:      	cmpl	$0x29, %edx
    1864:      	jne	0x1873 <filter_inet+0x333>
    1866:      	testq	%r8, %r8
    1869:      	je	0x1873 <filter_inet+0x333>
    186b:      	movzbl	0x3a(%r8), %eax
    1870:      	movl	%eax, (%rsp)
    1873:      	cmpl	$0x29, %edx
    1876:      	je	0x1835 <filter_inet+0x2f5>
    1878:      	cmpl	$0x7, %edx
    187b:      	je	0x1835 <filter_inet+0x2f5>
    187d:      	xorl	%eax, %eax
    187f:      	jmp	0x183d <filter_inet+0x2fd>
    1881:      	nopw	%cs:(%rax,%rax)

0000000000001890 <filter_sockaddr_un>:
    1890:      	pushq	%rbx
    1891:      	subq	$0x10, %rsp
    1895:      	movq	%rsi, %rcx
    1898:      	addq	$0x4, %rsi
    189c:      	movzbl	0x3(%rcx), %edx
    18a0:      	movl	0x4(%rdi), %r8d
    18a4:      	xorl	%eax, %eax
    18a6:      	cmpl	$0x19, %r8d
    18aa:      	jg	0x18e0 <filter_sockaddr_un+0x50>
    18ac:      	leal	-0x3(%r8), %ecx
    18b0:      	cmpl	$0x2, %ecx
    18b3:      	jae	0x18ee <filter_sockaddr_un+0x5e>
    18b5:      	movq	%rdi, %rbx
    18b8:      	callq	0x1940 <filter_char_buf_equal>
    18bd:      	movl	0x4(%rbx), %ecx
    18c0:      	cmpq	$0x25, %rcx
    18c4:      	ja	0x18da <filter_sockaddr_un+0x4a>
    18c6:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    18d0:      	btq	%rcx, %rdx
    18d4:      	jae	0x18da <filter_sockaddr_un+0x4a>
    18d6:      	xorq	$0x1, %rax
    18da:      	addq	$0x10, %rsp
    18de:      	popq	%rbx
    18df:      	retq
    18e0:      	cmpl	$0x1c, %r8d
    18e4:      	je	0x1924 <filter_sockaddr_un+0x94>
    18e6:      	cmpl	$0x1a, %r8d
    18ea:      	je	0x18f4 <filter_sockaddr_un+0x64>
    18ec:      	jmp	0x18da <filter_sockaddr_un+0x4a>
    18ee:      	cmpl	$0x8, %r8d
    18f2:      	jne	0x18da <filter_sockaddr_un+0x4a>
    18f4:      	movl	0x10(%rdi), %eax
    18f7:      	movq	%rdi, %rbx
    18fa:      	movl	%eax, %edi
    18fc:      	callq	0x1cc0 <filter_char_buf_prefix>
    1901:      	movl	0x4(%rbx), %ecx
    1904:      	cmpq	$0x25, %rcx
    1908:      	ja	0x18da <filter_sockaddr_un+0x4a>
    190a:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1914:      	btq	%rcx, %rdx
    1918:      	jae	0x18da <filter_sockaddr_un+0x4a>
    191a:      	xorq	$0x1, %rax
    191e:      	addq	$0x10, %rsp
    1922:      	popq	%rbx
    1923:      	retq
    1924:      	movzwl	(%rcx), %eax
    1927:      	movl	%eax, 0xc(%rsp)
    192b:      	leaq	0xc(%rsp), %rsi
    1930:      	callq	0x890 <filter_32ty_map>
    1935:      	addq	$0x10, %rsp
    1939:      	popq	%rbx
    193a:      	retq
    193b:      	nopl	(%rax,%rax)

0000000000001940 <filter_char_buf_equal>:
    1940:      	pushq	%rbp
    1941:      	pushq	%r15
    1943:      	pushq	%r14
    1945:      	pushq	%r13
    1947:      	pushq	%r12
    1949:      	pushq	%rbx
    194a:      	subq	$0x28, %rsp
    194e:      	movl	$0x0, 0x14(%rsp)
    1956:      	cmpl	$0x1000, %edx           # imm = 0x1000
    195c:      	ja	0x1cae <filter_char_buf_equal+0x36e>
    1962:      	movl	%edx, %ebp
    1964:      	movzwl	%bp, %eax
    1967:      	cmpl	$0x90, %eax
    196c:      	ja	0x19b5 <filter_char_buf_equal+0x75>
    196e:      	testw	%bp, %bp
    1971:      	je	0x1984 <filter_char_buf_equal+0x44>
    1973:      	movl	$0x18, %ecx
    1978:      	movl	%ebp, %eax
    197a:      	cltd
    197b:      	idivl	%ecx
    197d:      	movl	%ebp, %r14d
    1980:      	testl	%edx, %edx
    1982:      	je	0x19a4 <filter_char_buf_equal+0x64>
    1984:      	movl	$0x18, %ecx
    1989:      	movl	%ebp, %eax
    198b:      	cltd
    198c:      	idivl	%ecx
    198e:      	shll	$0x3, %eax
    1991:      	leal	(%rax,%rax,2), %eax
    1994:      	addl	$0x18, %eax
    1997:      	movzwl	%ax, %r14d
    199b:      	cmpl	$0x90, %r14d
    19a2:      	ja	0x19f3 <filter_char_buf_equal+0xb3>
    19a4:      	movl	%r14d, %eax
    19a7:      	cltd
    19a8:      	idivl	%ecx
    19aa:      	movl	%eax, %r15d
    19ad:      	decl	%r15d
    19b0:      	jmp	0x1a3e <filter_char_buf_equal+0xfe>
    19b5:      	movl	$0x100, %r14d           # imm = 0x100
    19bb:      	cmpl	$0x101, %eax            # imm = 0x101
    19c0:      	jb	0x19f3 <filter_char_buf_equal+0xb3>
    19c2:      	movl	$0x200, %r14d           # imm = 0x200
    19c8:      	cmpl	$0x201, %eax            # imm = 0x201
    19cd:      	jb	0x19f3 <filter_char_buf_equal+0xb3>
    19cf:      	movl	$0x400, %r14d           # imm = 0x400
    19d5:      	cmpl	$0x401, %eax            # imm = 0x401
    19da:      	jb	0x19f3 <filter_char_buf_equal+0xb3>
    19dc:      	xorl	%r14d, %r14d
    19df:      	cmpl	$0x801, %eax            # imm = 0x801
    19e4:      	setae	%r14b
    19e8:      	shll	$0xb, %r14d
    19ec:      	addl	$0x800, %r14d           # imm = 0x800
    19f3:      	leal	-0x100(%r14), %eax
    19fa:      	rorxl	$0x8, %eax, %eax
    1a00:      	cmpl	$0x2, %eax
    1a03:      	jg	0x1a16 <filter_char_buf_equal+0xd6>
    1a05:      	testl	%eax, %eax
    1a07:      	je	0x1a30 <filter_char_buf_equal+0xf0>
    1a09:      	cmpl	$0x1, %eax
    1a0c:      	jne	0x1a28 <filter_char_buf_equal+0xe8>
    1a0e:      	movl	$0x7, %r15d
    1a14:      	jmp	0x1a3e <filter_char_buf_equal+0xfe>
    1a16:      	cmpl	$0x3, %eax
    1a19:      	je	0x1a38 <filter_char_buf_equal+0xf8>
    1a1b:      	cmpl	$0x7, %eax
    1a1e:      	jne	0x1a28 <filter_char_buf_equal+0xe8>
    1a20:      	movl	$0x9, %r15d
    1a26:      	jmp	0x1a3e <filter_char_buf_equal+0xfe>
    1a28:      	movl	$0xa, %r15d
    1a2e:      	jmp	0x1a3e <filter_char_buf_equal+0xfe>
    1a30:      	movl	$0x6, %r15d
    1a36:      	jmp	0x1a3e <filter_char_buf_equal+0xfe>
    1a38:      	movl	$0x8, %r15d
    1a3e:      	movl	%r15d, %eax
    1a41:      	andl	$0xf, %eax
    1a44:      	movl	0x10(%rdi,%rax,4), %r13d
    1a49:      	cmpl	$-0x1, %r13d
    1a4d:      	je	0x1cae <filter_char_buf_equal+0x36e>
    1a53:      	movq	%rsi, 0x20(%rsp)
    1a58:      	movq	(%rip), %rdi            # 0x1a5f <filter_char_buf_equal+0x11f>
    1a5f:      	leaq	0x14(%rsp), %r12
    1a64:      	movl	$0x1, %eax
    1a69:      	movq	%r12, %rsi
    1a6c:      	callq	*%rax
    1a6e:      	movq	%rax, %rbx
    1a71:      	movq	(%rip), %rdi            # 0x1a78 <filter_char_buf_equal+0x138>
    1a78:      	movl	$0x1, %eax
    1a7d:      	movq	%r12, %rsi
    1a80:      	callq	*%rax
    1a82:      	movq	%rax, %rcx
    1a85:      	xorl	%eax, %eax
    1a87:      	movq	%rbx, 0x8(%rsp)
    1a8c:      	testq	%rbx, %rbx
    1a8f:      	je	0x1cb0 <filter_char_buf_equal+0x370>
    1a95:      	testq	%rcx, %rcx
    1a98:      	je	0x1cb0 <filter_char_buf_equal+0x370>
    1a9e:      	movq	%rcx, 0x18(%rsp)
    1aa3:      	cmpl	$0x5, %r15d
    1aa7:      	jg	0x1aea <filter_char_buf_equal+0x1aa>
    1aa9:      	movq	0x8(%rsp), %rax
    1aae:      	movb	%bpl, (%rax)
    1ab1:      	leaq	0x1(%rax), %rdi
    1ab5:      	movl	%ebp, %r12d
    1ab8:      	movl	$0x4, %eax
    1abd:      	movq	0x20(%rsp), %rdx
    1ac2:      	movl	%ebp, %esi
    1ac4:      	callq	*%rax
    1ac6:      	subl	%ebp, %r14d
    1ac9:      	jbe	0x1b2f <filter_char_buf_equal+0x1ef>
    1acb:      	movq	0x8(%rsp), %rax
    1ad0:      	leaq	(%rax,%r12), %rdi
    1ad4:      	incq	%rdi
    1ad7:      	andl	$0xfff, %r14d           # imm = 0xFFF
    1ade:      	movl	$0x4, %eax
    1ae3:      	movq	0x18(%rsp), %rdx
    1ae8:      	jmp	0x1b2a <filter_char_buf_equal+0x1ea>
    1aea:      	movq	0x8(%rsp), %rax
    1aef:      	movw	%bp, (%rax)
    1af2:      	leaq	0x2(%rax), %rdi
    1af6:      	movl	%ebp, %r12d
    1af9:      	movl	$0x4, %eax
    1afe:      	movq	0x20(%rsp), %rdx
    1b03:      	movl	%ebp, %esi
    1b05:      	callq	*%rax
    1b07:      	subl	%ebp, %r14d
    1b0a:      	jbe	0x1b2f <filter_char_buf_equal+0x1ef>
    1b0c:      	movq	0x8(%rsp), %rax
    1b11:      	leaq	(%rax,%r12), %rdi
    1b15:      	addq	$0x2, %rdi
    1b19:      	andl	$0xfff, %r14d           # imm = 0xFFF
    1b20:      	movl	$0x4, %eax
    1b25:      	movq	0x18(%rsp), %rdx
    1b2a:      	movl	%r14d, %esi
    1b2d:      	callq	*%rax
    1b2f:      	movl	%r13d, 0x4(%rsp)
    1b34:      	cmpl	$0x4, %r15d
    1b38:      	jle	0x1b74 <filter_char_buf_equal+0x234>
    1b3a:      	cmpl	$0x7, %r15d
    1b3e:      	jg	0x1bae <filter_char_buf_equal+0x26e>
    1b40:      	cmpl	$0x5, %r15d
    1b44:      	je	0x1c62 <filter_char_buf_equal+0x322>
    1b4a:      	cmpl	$0x6, %r15d
    1b4e:      	je	0x1c29 <filter_char_buf_equal+0x2e9>
    1b54:      	cmpl	$0x7, %r15d
    1b58:      	jne	0x1cae <filter_char_buf_equal+0x36e>
    1b5e:      	movq	(%rip), %rdi            # 0x1b65 <filter_char_buf_equal+0x225>
    1b65:      	leaq	0x4(%rsp), %rcx
    1b6a:      	movl	$0x1, %eax
    1b6f:      	jmp	0x1c86 <filter_char_buf_equal+0x346>
    1b74:      	cmpl	$0x1, %r15d
    1b78:      	jle	0x1bde <filter_char_buf_equal+0x29e>
    1b7a:      	cmpl	$0x2, %r15d
    1b7e:      	je	0x1c4f <filter_char_buf_equal+0x30f>
    1b84:      	cmpl	$0x3, %r15d
    1b88:      	je	0x1c16 <filter_char_buf_equal+0x2d6>
    1b8e:      	cmpl	$0x4, %r15d
    1b92:      	jne	0x1cae <filter_char_buf_equal+0x36e>
    1b98:      	movq	(%rip), %rdi            # 0x1b9f <filter_char_buf_equal+0x25f>
    1b9f:      	leaq	0x4(%rsp), %rcx
    1ba4:      	movl	$0x1, %eax
    1ba9:      	jmp	0x1c86 <filter_char_buf_equal+0x346>
    1bae:      	cmpl	$0x8, %r15d
    1bb2:      	je	0x1c75 <filter_char_buf_equal+0x335>
    1bb8:      	cmpl	$0x9, %r15d
    1bbc:      	je	0x1c3c <filter_char_buf_equal+0x2fc>
    1bbe:      	cmpl	$0xa, %r15d
    1bc2:      	jne	0x1cae <filter_char_buf_equal+0x36e>
    1bc8:      	movq	(%rip), %rdi            # 0x1bcf <filter_char_buf_equal+0x28f>
    1bcf:      	leaq	0x4(%rsp), %rcx
    1bd4:      	movl	$0x1, %eax
    1bd9:      	jmp	0x1c86 <filter_char_buf_equal+0x346>
    1bde:      	testl	%r15d, %r15d
    1be1:      	je	0x1c03 <filter_char_buf_equal+0x2c3>
    1be3:      	cmpl	$0x1, %r15d
    1be7:      	jne	0x1cae <filter_char_buf_equal+0x36e>
    1bed:      	movq	(%rip), %rdi            # 0x1bf4 <filter_char_buf_equal+0x2b4>
    1bf4:      	leaq	0x4(%rsp), %rcx
    1bf9:      	movl	$0x1, %eax
    1bfe:      	jmp	0x1c86 <filter_char_buf_equal+0x346>
    1c03:      	movq	(%rip), %rdi            # 0x1c0a <filter_char_buf_equal+0x2ca>
    1c0a:      	leaq	0x4(%rsp), %rcx
    1c0f:      	movl	$0x1, %eax
    1c14:      	jmp	0x1c86 <filter_char_buf_equal+0x346>
    1c16:      	movq	(%rip), %rdi            # 0x1c1d <filter_char_buf_equal+0x2dd>
    1c1d:      	leaq	0x4(%rsp), %rcx
    1c22:      	movl	$0x1, %eax
    1c27:      	jmp	0x1c86 <filter_char_buf_equal+0x346>
    1c29:      	movq	(%rip), %rdi            # 0x1c30 <filter_char_buf_equal+0x2f0>
    1c30:      	leaq	0x4(%rsp), %rcx
    1c35:      	movl	$0x1, %eax
    1c3a:      	jmp	0x1c86 <filter_char_buf_equal+0x346>
    1c3c:      	movq	(%rip), %rdi            # 0x1c43 <filter_char_buf_equal+0x303>
    1c43:      	leaq	0x4(%rsp), %rcx
    1c48:      	movl	$0x1, %eax
    1c4d:      	jmp	0x1c86 <filter_char_buf_equal+0x346>
    1c4f:      	movq	(%rip), %rdi            # 0x1c56 <filter_char_buf_equal+0x316>
    1c56:      	leaq	0x4(%rsp), %rcx
    1c5b:      	movl	$0x1, %eax
    1c60:      	jmp	0x1c86 <filter_char_buf_equal+0x346>
    1c62:      	movq	(%rip), %rdi            # 0x1c69 <filter_char_buf_equal+0x329>
    1c69:      	leaq	0x4(%rsp), %rcx
    1c6e:      	movl	$0x1, %eax
    1c73:      	jmp	0x1c86 <filter_char_buf_equal+0x346>
    1c75:      	movq	(%rip), %rdi            # 0x1c7c <filter_char_buf_equal+0x33c>
    1c7c:      	leaq	0x4(%rsp), %rcx
    1c81:      	movl	$0x1, %eax
    1c86:      	leaq	0x4(%rsp), %rsi
    1c8b:      	callq	*%rax
    1c8d:      	testq	%rax, %rax
    1c90:      	je	0x1cae <filter_char_buf_equal+0x36e>
    1c92:      	movq	%rax, %rdi
    1c95:      	movl	$0x1, %eax
    1c9a:      	movq	0x8(%rsp), %rsi
    1c9f:      	callq	*%rax
    1ca1:      	movq	%rax, %rcx
    1ca4:      	xorl	%eax, %eax
    1ca6:      	testq	%rcx, %rcx
    1ca9:      	setne	%al
    1cac:      	jmp	0x1cb0 <filter_char_buf_equal+0x370>
    1cae:      	xorl	%eax, %eax
    1cb0:      	addq	$0x28, %rsp
    1cb4:      	popq	%rbx
    1cb5:      	popq	%r12
    1cb7:      	popq	%r13
    1cb9:      	popq	%r14
    1cbb:      	popq	%r15
    1cbd:      	popq	%rbp
    1cbe:      	retq
    1cbf:      	nop

0000000000001cc0 <filter_char_buf_prefix>:
    1cc0:      	pushq	%rbp
    1cc1:      	pushq	%r15
    1cc3:      	pushq	%r14
    1cc5:      	pushq	%rbx
    1cc6:      	pushq	%rax
    1cc7:      	movl	%edx, %ebp
    1cc9:      	movq	%rsi, %rbx
    1ccc:      	movl	%edi, 0x4(%rsp)
    1cd0:      	movl	$0x0, (%rsp)
    1cd7:      	movq	(%rip), %rdi            # 0x1cde <filter_char_buf_prefix+0x1e>
    1cde:      	leaq	0x4(%rsp), %rsi
    1ce3:      	movl	$0x1, %eax
    1ce8:      	callq	*%rax
    1cea:      	movq	%rax, %r14
    1ced:      	xorl	%eax, %eax
    1cef:      	testl	%ebp, %ebp
    1cf1:      	je	0x1d55 <filter_char_buf_prefix+0x95>
    1cf3:      	testq	%r14, %r14
    1cf6:      	je	0x1d55 <filter_char_buf_prefix+0x95>
    1cf8:      	movq	(%rip), %rdi            # 0x1cff <filter_char_buf_prefix+0x3f>
    1cff:      	movq	%rsp, %rsi
    1d02:      	movl	$0x1, %eax
    1d07:      	callq	*%rax
    1d09:      	testq	%rax, %rax
    1d0c:      	je	0x1d53 <filter_char_buf_prefix+0x93>
    1d0e:      	cmpl	$0xff, %ebp
    1d14:      	movl	$0xff, %esi
    1d19:      	cmovbl	%ebp, %esi
    1d1c:      	leal	(,%rsi,8), %ecx
    1d23:      	movl	%ecx, (%rax)
    1d25:      	movq	%rax, %rdi
    1d28:      	addq	$0x4, %rdi
    1d2c:      	movq	%rax, %r15
    1d2f:      	movl	$0x4, %eax
    1d34:      	movq	%rbx, %rdx
    1d37:      	callq	*%rax
    1d39:      	movl	$0x1, %eax
    1d3e:      	movq	%r14, %rdi
    1d41:      	movq	%r15, %rsi
    1d44:      	callq	*%rax
    1d46:      	movq	%rax, %rcx
    1d49:      	xorl	%eax, %eax
    1d4b:      	testq	%rcx, %rcx
    1d4e:      	setne	%al
    1d51:      	jmp	0x1d55 <filter_char_buf_prefix+0x95>
    1d53:      	xorl	%eax, %eax
    1d55:      	addq	$0x8, %rsp
    1d59:      	popq	%rbx
    1d5a:      	popq	%r14
    1d5c:      	popq	%r15
    1d5e:      	popq	%rbp
    1d5f:      	retq

0000000000001d60 <filter_char_buf_postfix>:
    1d60:      	pushq	%r15
    1d62:      	pushq	%r14
    1d64:      	pushq	%rbx
    1d65:      	subq	$0x10, %rsp
    1d69:      	movl	%edx, %ebx
    1d6b:      	movq	%rsi, %r14
    1d6e:      	movl	%edi, 0xc(%rsp)
    1d72:      	movl	$0x0, 0x8(%rsp)
    1d7a:      	movq	(%rip), %rdi            # 0x1d81 <filter_char_buf_postfix+0x21>
    1d81:      	leaq	0xc(%rsp), %rsi
    1d86:      	movl	$0x1, %eax
    1d8b:      	callq	*%rax
    1d8d:      	movq	%rax, %r15
    1d90:      	xorl	%eax, %eax
    1d92:      	testl	%ebx, %ebx
    1d94:      	je	0x1ea0 <filter_char_buf_postfix+0x140>
    1d9a:      	testq	%r15, %r15
    1d9d:      	je	0x1ea0 <filter_char_buf_postfix+0x140>
    1da3:      	movq	(%rip), %rdi            # 0x1daa <filter_char_buf_postfix+0x4a>
    1daa:      	leaq	0x8(%rsp), %rsi
    1daf:      	movl	$0x1, %eax
    1db4:      	callq	*%rax
    1db6:      	testq	%rax, %rax
    1db9:      	je	0x1e9e <filter_char_buf_postfix+0x13e>
    1dbf:      	movq	%rax, %rsi
    1dc2:      	cmpl	$0x7f, %ebx
    1dc5:      	movl	$0x7f, %eax
    1dca:      	cmovbl	%ebx, %eax
    1dcd:      	shll	$0x3, %eax
    1dd0:      	movl	%eax, (%rsi)
    1dd2:      	movl	%ebx, %eax
    1dd4:      	leal	-0x4(%rbx), %ecx
    1dd7:      	movq	%rsi, %rdx
    1dda:      	addq	$0x7, %rdx
    1dde:      	leal	-0x3(%rbx), %edi
    1de1:      	leal	-0x2(%rbx), %r8d
    1de5:      	decl	%ebx
    1de7:      	movq	$-0x3, %r9
    1dee:      	nop
    1df0:      	leal	(%rbx,%r9), %r10d
    1df4:      	addl	$0x3, %r10d
    1df8:      	andl	$0xfff, %r10d           # imm = 0xFFF
    1dff:      	movzbl	(%r14,%r10), %r10d
    1e04:      	movb	%r10b, -0x3(%rdx)
    1e08:      	leaq	(%rax,%r9), %r10
    1e0c:      	cmpq	$-0x2, %r10
    1e10:      	je	0x1e87 <filter_char_buf_postfix+0x127>
    1e12:      	leal	(%r8,%r9), %r11d
    1e16:      	addl	$0x3, %r11d
    1e1a:      	andl	$0xfff, %r11d           # imm = 0xFFF
    1e21:      	movzbl	(%r14,%r11), %r11d
    1e26:      	movb	%r11b, -0x2(%rdx)
    1e2a:      	cmpq	$-0x1, %r10
    1e2e:      	je	0x1e87 <filter_char_buf_postfix+0x127>
    1e30:      	leal	(%rdi,%r9), %r10d
    1e34:      	addl	$0x3, %r10d
    1e38:      	andl	$0xfff, %r10d           # imm = 0xFFF
    1e3f:      	movzbl	(%r14,%r10), %r10d
    1e44:      	movb	%r10b, -0x1(%rdx)
    1e48:      	movq	%rax, %r10
    1e4b:      	addq	%r9, %r10
    1e4e:      	je	0x1e87 <filter_char_buf_postfix+0x127>
    1e50:      	cmpq	$-0x7f, %r9
    1e54:      	je	0x1e87 <filter_char_buf_postfix+0x127>
    1e56:      	leal	(%rcx,%r9), %r10d
    1e5a:      	addl	$0x3, %r10d
    1e5e:      	andl	$0xfff, %r10d           # imm = 0xFFF
    1e65:      	movzbl	(%r14,%r10), %r10d
    1e6a:      	movb	%r10b, (%rdx)
    1e6d:      	addq	$0x4, %rdx
    1e71:      	leaq	(%rax,%r9), %r10
    1e75:      	addq	$-0x4, %r10
    1e79:      	addq	$-0x4, %r9
    1e7d:      	cmpq	$-0x3, %r10
    1e81:      	jne	0x1df0 <filter_char_buf_postfix+0x90>
    1e87:      	movl	$0x1, %eax
    1e8c:      	movq	%r15, %rdi
    1e8f:      	callq	*%rax
    1e91:      	movq	%rax, %rcx
    1e94:      	xorl	%eax, %eax
    1e96:      	testq	%rcx, %rcx
    1e99:      	setne	%al
    1e9c:      	jmp	0x1ea0 <filter_char_buf_postfix+0x140>
    1e9e:      	xorl	%eax, %eax
    1ea0:      	addq	$0x10, %rsp
    1ea4:      	popq	%rbx
    1ea5:      	popq	%r14
    1ea7:      	popq	%r15
    1ea9:      	retq
    1eaa:      	nopw	(%rax,%rax)

0000000000001eb0 <filter_file_type>:
    1eb0:      	pushq	%rbx
    1eb1:      	subq	$0x10, %rsp
    1eb5:      	movw	$0x0, 0xe(%rsp)
    1ebc:      	movl	(%rsi), %eax
    1ebe:      	cmpq	$0x1000, %rax           # imm = 0x1000
    1ec4:      	ja	0x1f4c <filter_file_type+0x9c>
    1eca:      	movq	%rdi, %rbx
    1ecd:      	leaq	(%rsi,%rax), %rcx
    1ed1:      	addq	$0x8, %rcx
    1ed5:      	leaq	0xe(%rsp), %rdi
    1eda:      	movl	$0x2, %edx
    1edf:      	movl	$0x4, %eax
    1ee4:      	movl	(%rsi), %ecx
    1ee6:      	leaq	(%rsi,%rcx), %rdx
    1eea:      	addq	$0x8, %rdx
    1eee:      	movl	$0x2, %esi
    1ef3:      	callq	*%rax
    1ef5:      	movl	0x10(%rbx), %edx
    1ef8:      	testl	%edx, %edx
    1efa:      	je	0x1f4c <filter_file_type+0x9c>
    1efc:      	movzwl	0xe(%rsp), %ecx
    1f01:      	andl	$0xf000, %ecx           # imm = 0xF000
    1f07:      	movl	$0x1, %eax
    1f0c:      	cmpl	%ecx, %edx
    1f0e:      	je	0x1f4e <filter_file_type+0x9e>
    1f10:      	movl	0x8(%rbx), %edx
    1f13:      	cmpl	$0xc, %edx
    1f16:      	jbe	0x1f4c <filter_file_type+0x9c>
    1f18:      	movl	0x14(%rbx), %esi
    1f1b:      	testl	%esi, %esi
    1f1d:      	je	0x1f4c <filter_file_type+0x9c>
    1f1f:      	cmpl	%ecx, %esi
    1f21:      	je	0x1f4e <filter_file_type+0x9e>
    1f23:      	cmpl	$0x11, %edx
    1f26:      	jb	0x1f4c <filter_file_type+0x9c>
    1f28:      	movl	0x18(%rbx), %esi
    1f2b:      	testl	%esi, %esi
    1f2d:      	je	0x1f4c <filter_file_type+0x9c>
    1f2f:      	cmpl	%ecx, %esi
    1f31:      	je	0x1f4e <filter_file_type+0x9e>
    1f33:      	cmpl	$0x15, %edx
    1f36:      	jb	0x1f4c <filter_file_type+0x9c>
    1f38:      	movl	0x1c(%rbx), %edx
    1f3b:      	testl	%edx, %edx
    1f3d:      	je	0x1f4c <filter_file_type+0x9c>
    1f3f:      	xorl	%eax, %eax
    1f41:      	cmpl	%ecx, %edx
    1f43:      	sete	%al
    1f46:      	addq	$0x10, %rsp
    1f4a:      	popq	%rbx
    1f4b:      	retq
    1f4c:      	xorl	%eax, %eax
    1f4e:      	addq	$0x10, %rsp
    1f52:      	popq	%rbx
    1f53:      	retq
    1f54:      	nopw	%cs:(%rax,%rax)

0000000000001f60 <filter_char_substring>:
    1f60:      	pushq	%rbp
    1f61:      	pushq	%r15
    1f63:      	pushq	%r14
    1f65:      	pushq	%r13
    1f67:      	pushq	%r12
    1f69:      	pushq	%rbx
    1f6a:      	pushq	%rax
    1f6b:      	movq	%rsi, %r15
    1f6e:      	movq	%rdi, %r14
    1f71:      	movl	%edx, %ebp
    1f73:      	testl	%ecx, %ecx
    1f75:      	je	0x204d <filter_char_substring+0xed>
    1f7b:      	testl	%edx, %edx
    1f7d:      	je	0x20fd <filter_char_substring+0x19d>
    1f83:      	leaq	0x4(%rsp), %r13
    1f88:      	xorl	%ebx, %ebx
    1f8a:      	xorl	%r12d, %r12d
    1f8d:      	nopl	(%rax)
    1f90:      	movl	0x10(%r14,%rbx,4), %eax
    1f95:      	movl	%eax, 0x4(%rsp)
    1f99:      	movl	$0x1, %eax
    1f9e:      	movq	(%rip), %rdi            # 0x1fa5 <filter_char_substring+0x45>
    1fa5:      	movq	%r13, %rsi
    1fa8:      	callq	*%rax
    1faa:      	testq	%rax, %rax
    1fad:      	je	0x2190 <filter_char_substring+0x230>
    1fb3:      	movq	%r15, %rdx
    1fb6:      	xorl	%ecx, %ecx
    1fb8:      	jmp	0x1fcb <filter_char_substring+0x6b>
    1fba:      	nopw	(%rax,%rax)
    1fc0:      	incq	%rcx
    1fc3:      	incq	%rdx
    1fc6:      	cmpq	%rbp, %rcx
    1fc9:      	je	0x2028 <filter_char_substring+0xc8>
    1fcb:      	xorl	%esi, %esi
    1fcd:      	nopl	(%rax)
    1fd0:      	leaq	(%rcx,%rsi), %rdi
    1fd4:      	cmpq	%rbp, %rdi
    1fd7:      	jae	0x1fc0 <filter_char_substring+0x60>
    1fd9:      	movsbl	(%rax,%rsi), %edi
    1fdd:      	testl	%edi, %edi
    1fdf:      	je	0x2020 <filter_char_substring+0xc0>
    1fe1:      	movsbl	(%rdx,%rsi), %r9d
    1fe6:      	leal	-0x41(%r9), %r10d
    1fea:      	movl	%r9d, %r8d
    1fed:      	orl	$0x20, %r8d
    1ff1:      	cmpl	$0x1a, %r10d
    1ff5:      	cmovael	%r9d, %r8d
    1ff9:      	leal	-0x41(%rdi), %r10d
    1ffd:      	movl	%edi, %r9d
    2000:      	orl	$0x20, %r9d
    2004:      	cmpl	$0x1a, %r10d
    2008:      	cmovael	%edi, %r9d
    200c:      	cmpq	$0x62, %rsi
    2010:      	ja	0x1fc0 <filter_char_substring+0x60>
    2012:      	incq	%rsi
    2015:      	cmpl	%r9d, %r8d
    2018:      	je	0x1fd0 <filter_char_substring+0x70>
    201a:      	jmp	0x1fc0 <filter_char_substring+0x60>
    201c:      	nopl	(%rax)
    2020:      	testl	%ecx, %ecx
    2022:      	jns	0x21a1 <filter_char_substring+0x241>
    2028:      	leal	0xc(%r12), %eax
    202d:      	cmpl	0x8(%r14), %eax
    2031:      	jae	0x2190 <filter_char_substring+0x230>
    2037:      	addl	$0x4, %r12d
    203b:      	incq	%rbx
    203e:      	cmpq	$0x64, %rbx
    2042:      	jne	0x1f90 <filter_char_substring+0x30>
    2048:      	jmp	0x2190 <filter_char_substring+0x230>
    204d:      	testl	%edx, %edx
    204f:      	je	0x2142 <filter_char_substring+0x1e2>
    2055:      	leaq	0x4(%rsp), %r13
    205a:      	xorl	%ebx, %ebx
    205c:      	xorl	%r12d, %r12d
    205f:      	nop
    2060:      	movl	0x10(%r14,%rbx,4), %eax
    2065:      	movl	%eax, 0x4(%rsp)
    2069:      	movl	$0x1, %eax
    206e:      	movq	(%rip), %rdi            # 0x2075 <filter_char_substring+0x115>
    2075:      	movq	%r13, %rsi
    2078:      	callq	*%rax
    207a:      	testq	%rax, %rax
    207d:      	je	0x2190 <filter_char_substring+0x230>
    2083:      	movq	%r15, %rdx
    2086:      	xorl	%ecx, %ecx
    2088:      	jmp	0x209b <filter_char_substring+0x13b>
    208a:      	nopw	(%rax,%rax)
    2090:      	incq	%rcx
    2093:      	incq	%rdx
    2096:      	cmpq	%rbp, %rcx
    2099:      	je	0x20d8 <filter_char_substring+0x178>
    209b:      	xorl	%esi, %esi
    209d:      	nopl	(%rax)
    20a0:      	leaq	(%rcx,%rsi), %rdi
    20a4:      	cmpq	%rbp, %rdi
    20a7:      	jae	0x2090 <filter_char_substring+0x130>
    20a9:      	movzbl	(%rax,%rsi), %edi
    20ad:      	testb	%dil, %dil
    20b0:      	je	0x20d0 <filter_char_substring+0x170>
    20b2:      	cmpq	$0x62, %rsi
    20b6:      	ja	0x2090 <filter_char_substring+0x130>
    20b8:      	leaq	0x1(%rsi), %r8
    20bc:      	cmpb	%dil, (%rdx,%rsi)
    20c0:      	movq	%r8, %rsi
    20c3:      	je	0x20a0 <filter_char_substring+0x140>
    20c5:      	jmp	0x2090 <filter_char_substring+0x130>
    20c7:      	nopw	(%rax,%rax)
    20d0:      	testl	%ecx, %ecx
    20d2:      	jns	0x21a1 <filter_char_substring+0x241>
    20d8:      	leal	0xc(%r12), %eax
    20dd:      	cmpl	0x8(%r14), %eax
    20e1:      	jae	0x2190 <filter_char_substring+0x230>
    20e7:      	addl	$0x4, %r12d
    20eb:      	incq	%rbx
    20ee:      	cmpq	$0x64, %rbx
    20f2:      	jne	0x2060 <filter_char_substring+0x100>
    20f8:      	jmp	0x2190 <filter_char_substring+0x230>
    20fd:      	movl	$0x10, %ebx
    2102:      	movq	(%rip), %r15            # 0x2109 <filter_char_substring+0x1a9>
    2109:      	leaq	0x4(%rsp), %r12
    210e:      	nop
    2110:      	movl	(%r14,%rbx), %eax
    2114:      	movl	%eax, 0x4(%rsp)
    2118:      	movl	$0x1, %eax
    211d:      	movq	%r15, %rdi
    2120:      	movq	%r12, %rsi
    2123:      	callq	*%rax
    2125:      	testq	%rax, %rax
    2128:      	je	0x2190 <filter_char_substring+0x230>
    212a:      	addq	$0x4, %rbx
    212e:      	leal	-0x8(%rbx), %eax
    2131:      	cmpl	0x8(%r14), %eax
    2135:      	jae	0x2190 <filter_char_substring+0x230>
    2137:      	cmpq	$0x1a0, %rbx            # imm = 0x1A0
    213e:      	jne	0x2110 <filter_char_substring+0x1b0>
    2140:      	jmp	0x2190 <filter_char_substring+0x230>
    2142:      	movl	$0x10, %ebx
    2147:      	movq	(%rip), %r15            # 0x214e <filter_char_substring+0x1ee>
    214e:      	leaq	0x4(%rsp), %r12
    2153:      	nopw	%cs:(%rax,%rax)
    2160:      	movl	(%r14,%rbx), %eax
    2164:      	movl	%eax, 0x4(%rsp)
    2168:      	movl	$0x1, %eax
    216d:      	movq	%r15, %rdi
    2170:      	movq	%r12, %rsi
    2173:      	callq	*%rax
    2175:      	testq	%rax, %rax
    2178:      	je	0x2190 <filter_char_substring+0x230>
    217a:      	addq	$0x4, %rbx
    217e:      	leal	-0x8(%rbx), %eax
    2181:      	cmpl	0x8(%r14), %eax
    2185:      	jae	0x2190 <filter_char_substring+0x230>
    2187:      	cmpq	$0x1a0, %rbx            # imm = 0x1A0
    218e:      	jne	0x2160 <filter_char_substring+0x200>
    2190:      	xorl	%eax, %eax
    2192:      	addq	$0x8, %rsp
    2196:      	popq	%rbx
    2197:      	popq	%r12
    2199:      	popq	%r13
    219b:      	popq	%r14
    219d:      	popq	%r15
    219f:      	popq	%rbp
    21a0:      	retq
    21a1:      	movl	$0x1, %eax
    21a6:      	jmp	0x2192 <filter_char_substring+0x232>
    21a8:      	nopl	(%rax,%rax)

00000000000021b0 <do_action>:
    21b0:      	pushq	%rbp
    21b1:      	pushq	%r15
    21b3:      	pushq	%r14
    21b5:      	pushq	%r13
    21b7:      	pushq	%r12
    21b9:      	pushq	%rbx
    21ba:      	subq	$0x88, %rsp
    21c1:      	movl	%r8d, %ebp
    21c4:      	movq	%rcx, %r13
    21c7:      	movq	%rdx, %r15
    21ca:      	movl	%esi, %r14d
    21cd:      	movq	%rdi, %r12
    21d0:      	movl	%esi, %eax
    21d2:      	movslq	0x4(%rdx,%rax,4), %rbx
    21d7:      	movl	$0x0, 0x64(%rsp)
    21df:      	movq	(%rip), %rdi            # 0x21e6 <do_action+0x36>
    21e6:      	leaq	0x64(%rsp), %rsi
    21eb:      	movl	$0x1, %eax
    21f0:      	callq	*%rax
    21f2:      	movq	%rax, %rdx
    21f5:      	xorl	%eax, %eax
    21f7:      	testq	%rdx, %rdx
    21fa:      	je	0x2bf5 <do_action+0xa45>
    2200:      	cmpl	$0x7, %ebx
    2203:      	jg	0x2229 <do_action+0x79>
    2205:      	cmpl	$0x3, %ebx
    2208:      	jg	0x225d <do_action+0xad>
    220a:      	cmpl	$0x1, %ebx
    220d:      	jg	0x2395 <do_action+0x1e5>
    2213:      	testl	%ebx, %ebx
    2215:      	je	0x2655 <do_action+0x4a5>
    221b:      	cmpl	$0x1, %ebx
    221e:      	je	0x23ac <do_action+0x1fc>
    2224:      	jmp	0x2beb <do_action+0xa3b>
    2229:      	cmpl	$0xb, %ebx
    222c:      	jg	0x2363 <do_action+0x1b3>
    2232:      	leal	-0xa(%rbx), %ecx
    2235:      	cmpl	$0x2, %ecx
    2238:      	jb	0x24be <do_action+0x30e>
    223e:      	cmpl	$0x8, %ebx
    2241:      	je	0x25bb <do_action+0x40b>
    2247:      	cmpl	$0x9, %ebx
    224a:      	jne	0x2beb <do_action+0xa3b>
    2250:      	incl	%r14d
    2253:      	movl	0x4(%r15,%r14,4), %eax
    2258:      	jmp	0x2581 <do_action+0x3d1>
    225d:      	leal	-0x6(%rbx), %eax
    2260:      	cmpl	$0x2, %eax
    2263:      	jb	0x25ab <do_action+0x3fb>
    2269:      	cmpl	$0x4, %ebx
    226c:      	je	0x25c5 <do_action+0x415>
    2272:      	cmpl	$0x5, %ebx
    2275:      	jne	0x2beb <do_action+0xa3b>
    227b:      	leal	0x1(%r14), %eax
    227f:      	movl	0x4(%r15,%rax,4), %eax
    2284:      	addl	$0x2, %r14d
    2288:      	andl	$0x7, %eax
    228b:      	cmpl	$0x4, %eax
    228e:      	ja	0x2beb <do_action+0xa3b>
    2294:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    229c:      	jne	0x2beb <do_action+0xa3b>
    22a2:      	movl	0x4(%r15,%r14,4), %r15d
    22a7:      	movq	0x5e78(%rdx,%rax,8), %rax
    22af:      	movl	$0x0, 0xc(%rsp)
    22b7:      	andl	$0x7ff, %eax            # imm = 0x7FF
    22bc:      	movl	0x90(%rdx,%rax), %eax
    22c3:      	movl	%eax, 0x8(%rsp)
    22c7:      	movl	$0xe, %eax
    22cc:      	movq	%rdx, %r12
    22cf:      	callq	*%rax
    22d1:      	shrq	$0x20, %rax
    22d5:      	movq	%rax, (%rsp)
    22d9:      	movq	(%rip), %rdi            # 0x22e0 <do_action+0x130>
    22e0:      	movq	%rsp, %rsi
    22e3:      	movl	$0x1, %eax
    22e8:      	callq	*%rax
    22ea:      	movq	%r12, %rdx
    22ed:      	testq	%rax, %rax
    22f0:      	je	0x2beb <do_action+0xa3b>
    22f6:      	andl	$0x7, %r15d
    22fa:      	cmpl	$0x4, %r15d
    22fe:      	ja	0x2beb <do_action+0xa3b>
    2304:      	cmpl	$0x0, 0x5ea0(%rdx,%r15,4)
    230d:      	jne	0x2beb <do_action+0xa3b>
    2313:      	movq	0x5e78(%rdx,%r15,8), %rcx
    231b:      	movl	$0x0, 0xc(%rsp)
    2323:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    2329:      	movl	0x90(%rdx,%rcx), %ecx
    2330:      	movl	%ecx, 0x8(%rsp)
    2334:      	movq	%rax, %r15
    2337:      	movl	$0xe, %eax
    233c:      	callq	*%rax
    233e:      	shrq	$0x20, %rax
    2342:      	movq	%rax, (%rsp)
    2346:      	movq	(%rip), %rdi            # 0x234d <do_action+0x19d>
    234d:      	xorl	%ecx, %ecx
    234f:      	movq	%rsp, %rsi
    2352:      	movl	$0x2, %eax
    2357:      	movq	%r15, %rdx
    235a:      	xorl	%ecx, %ecx
    235c:      	callq	*%rax
    235e:      	jmp	0x264d <do_action+0x49d>
    2363:      	cmpl	$0xc, %ebx
    2366:      	je	0x2721 <do_action+0x571>
    236c:      	cmpl	$0xd, %ebx
    236f:      	je	0x25db <do_action+0x42b>
    2375:      	cmpl	$0xe, %ebx
    2378:      	jne	0x2beb <do_action+0xa3b>
    237e:      	movq	%rdx, %r15
    2381:      	addl	$0x2, %r14d
    2385:      	movzbl	%bpl, %r13d
    2389:      	xorq	$0x9, %r13
    238d:      	movl	%r14d, %r12d
    2390:      	jmp	0x2800 <do_action+0x650>
    2395:      	movl	$0x9, %eax
    239a:      	cmpl	$0x2, %ebx
    239d:      	je	0x2581 <do_action+0x3d1>
    23a3:      	cmpl	$0x3, %ebx
    23a6:      	jne	0x2beb <do_action+0xa3b>
    23ac:      	movq	%rdx, %r13
    23af:      	leal	0x1(%r14), %eax
    23b3:      	movl	0x4(%r15,%rax,4), %ebp
    23b8:      	addl	$0x2, %r14d
    23bc:      	movl	0x4(%r15,%r14,4), %r12d
    23c1:      	movl	$0x0, 0x10(%rsp)
    23c9:      	movq	(%rip), %rdi            # 0x23d0 <do_action+0x220>
    23d0:      	leaq	0x10(%rsp), %rsi
    23d5:      	movl	$0x1, %eax
    23da:      	callq	*%rax
    23dc:      	xorl	%r15d, %r15d
    23df:      	testq	%rax, %rax
    23e2:      	je	0x291f <do_action+0x76f>
    23e8:      	movq	%rax, 0x20(%rsp)
    23ed:      	andl	$0x7, %ebp
    23f0:      	cmpl	$0x4, %ebp
    23f3:      	movl	$0x0, %eax
    23f8:      	movq	%r13, %rdx
    23fb:      	ja	0x2924 <do_action+0x774>
    2401:      	cmpl	$0x0, 0x5ea0(%rdx,%rbp,4)
    2409:      	jne	0x2924 <do_action+0x774>
    240f:      	movq	0x5e78(%rdx,%rbp,8), %rax
    2417:      	movl	$0x0, 0xc(%rsp)
    241f:      	andl	$0x7ff, %eax            # imm = 0x7FF
    2424:      	movl	0x90(%rdx,%rax), %eax
    242b:      	movl	%eax, 0x8(%rsp)
    242f:      	movl	$0xe, %eax
    2434:      	callq	*%rax
    2436:      	shrq	$0x20, %rax
    243a:      	movq	%rax, (%rsp)
    243e:      	cmpl	$0x1, %ebx
    2441:      	jne	0x28f8 <do_action+0x748>
    2447:      	andl	$0x7, %r12d
    244b:      	cmpl	$0x4, %r12d
    244f:      	ja	0x291f <do_action+0x76f>
    2455:      	movq	%r13, %rdx
    2458:      	cmpl	$0x0, 0x5ea0(%r13,%r12,4)
    2461:      	movl	$0x0, %eax
    2466:      	jne	0x2924 <do_action+0x774>
    246c:      	movq	0x5e78(%rdx,%r12,8), %rax
    2474:      	andl	$0x7ff, %eax            # imm = 0x7FF
    2479:      	addq	%rax, %rdx
    247c:      	addq	$0x90, %rdx
    2483:      	movl	0x90(%r13,%rax), %esi
    248b:      	andl	$0xfff, %esi            # imm = 0xFFF
    2491:      	addq	$0x8, %rsi
    2495:      	movl	$0x4, %eax
    249a:      	movq	0x20(%rsp), %r12
    249f:      	movq	%r12, %rdi
    24a2:      	callq	*%rax
    24a4:      	movq	(%rip), %rdi            # 0x24ab <do_action+0x2fb>
    24ab:      	xorl	%r15d, %r15d
    24ae:      	movq	%rsp, %rsi
    24b1:      	movl	$0x2, %eax
    24b6:      	movq	%r12, %rdx
    24b9:      	jmp	0x2573 <do_action+0x3c3>
    24be:      	incl	%r14d
    24c1:      	movl	0x4(%r15,%r14,4), %ecx
    24c6:      	andl	$0x7, %ecx
    24c9:      	xorl	%r15d, %r15d
    24cc:      	cmpl	$0x4, %ecx
    24cf:      	ja	0x2924 <do_action+0x774>
    24d5:      	cmpl	$0x0, 0x5ea0(%rdx,%rcx,4)
    24dd:      	jne	0x2924 <do_action+0x774>
    24e3:      	movq	0x5e78(%rdx,%rcx,8), %rcx
    24eb:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    24f1:      	movq	0xb8(%rdx,%rcx), %rcx
    24f9:      	movq	%rcx, 0x10(%rsp)
    24fe:      	testq	%rcx, %rcx
    2501:      	je	0x2924 <do_action+0x774>
    2507:      	movq	%rdx, %r13
    250a:      	cmpl	$0xa, %ebx
    250d:      	jne	0x2909 <do_action+0x759>
    2513:      	movl	$0xe, %eax
    2518:      	callq	*%rax
    251a:      	movq	%rax, %r12
    251d:      	shrq	$0x20, %rax
    2521:      	movl	%eax, (%rsp)
    2524:      	movq	(%rip), %rdi            # 0x252b <do_action+0x37b>
    252b:      	movq	%rsp, %rsi
    252e:      	movl	$0x1, %eax
    2533:      	callq	*%rax
    2535:      	movq	%rax, %rcx
    2538:      	testq	%rax, %rax
    253b:      	movl	$0x0, %eax
    2540:      	movq	%r13, %rdx
    2543:      	je	0x2924 <do_action+0x774>
    2549:      	movl	(%rcx), %eax
    254b:      	movl	%eax, (%rsp)
    254e:      	movl	%r12d, 0x4(%rsp)
    2553:      	movq	0x8(%rcx), %rax
    2557:      	movq	%rax, 0x8(%rsp)
    255c:      	movq	(%rip), %rdi            # 0x2563 <do_action+0x3b3>
    2563:      	xorl	%r15d, %r15d
    2566:      	leaq	0x10(%rsp), %rsi
    256b:      	movq	%rsp, %rdx
    256e:      	movl	$0x2, %eax
    2573:      	xorl	%ecx, %ecx
    2575:      	callq	*%rax
    2577:      	movq	%r13, %rdx
    257a:      	xorl	%eax, %eax
    257c:      	jmp	0x2924 <do_action+0x774>
    2581:      	movl	%r14d, %r12d
    2584:      	movq	%rdx, %r15
    2587:      	movl	$0x3, %r13d
    258d:      	testb	%bpl, %bpl
    2590:      	je	0x2800 <do_action+0x650>
    2596:      	movslq	%eax, %rdi
    2599:      	movl	$0x6d, %eax
    259e:      	callq	*%rax
    25a0:      	movl	$0x2, %r13d
    25a6:      	jmp	0x2800 <do_action+0x650>
    25ab:      	incl	%r14d
    25ae:      	movl	0x4(%r15,%r14,4), %eax
    25b3:      	movl	%eax, 0x78(%rdx)
    25b6:      	jmp	0x2beb <do_action+0xa3b>
    25bb:      	movb	$0x0, (%r13)
    25c0:      	jmp	0x2beb <do_action+0xa3b>
    25c5:      	movq	%rdx, %r15
    25c8:      	incl	%r14d
    25cb:      	movzbl	%bpl, %r13d
    25cf:      	xorq	$0x5, %r13
    25d3:      	movl	%r14d, %r12d
    25d6:      	jmp	0x2800 <do_action+0x650>
    25db:      	movq	%rdx, %r12
    25de:      	movl	$0xe, %eax
    25e3:      	callq	*%rax
    25e5:      	movq	%rax, 0x30(%rsp)
    25ea:      	movq	(%rip), %rdi            # 0x25f1 <do_action+0x441>
    25f1:      	leaq	0x30(%rsp), %rsi
    25f6:      	movl	$0x1, %eax
    25fb:      	callq	*%rax
    25fd:      	testq	%rax, %rax
    2600:      	je	0x264d <do_action+0x49d>
    2602:      	movq	0x4(%rax), %rax
    2606:      	movq	%rax, 0x10(%rsp)
    260b:      	movl	$0x2, 0x18(%rsp)
    2613:      	movq	(%rip), %rdi            # 0x261a <do_action+0x46a>
    261a:      	leaq	0x10(%rsp), %rsi
    261f:      	movl	$0x1, %eax
    2624:      	callq	*%rax
    2626:      	movl	$0x1, 0x2c(%rsp)
    262e:      	testq	%rax, %rax
    2631:      	je	0x282d <do_action+0x67d>
    2637:      	lock
    2638:      	incl	(%rax)
    263a:      	movq	(%rip), %rdi            # 0x2641 <do_action+0x491>
    2641:      	leaq	0x30(%rsp), %rsi
    2646:      	movl	$0x3, %eax
    264b:      	callq	*%rax
    264d:      	movq	%r12, %rdx
    2650:      	jmp	0x2beb <do_action+0xa3b>
    2655:      	movq	%rdx, 0x20(%rsp)
    265a:      	leal	0x1(%r14), %eax
    265e:      	movl	0x4(%r15,%rax,4), %ebp
    2663:      	leal	0x2(%r14), %eax
    2667:      	movl	0x4(%r15,%rax,4), %eax
    266c:      	movl	%eax, 0x40(%rsp)
    2670:      	movl	$0x7d, %eax
    2675:      	callq	*%rax
    2677:      	movq	%rax, 0x70(%rsp)
    267c:      	movq	%rax, (%rsp)
    2680:      	movl	$0x0, 0x30(%rsp)
    2688:      	movq	%rbp, 0x78(%rsp)
    268d:      	testq	%rbp, %rbp
    2690:      	je	0x2b6e <do_action+0x9be>
    2696:      	movq	(%rip), %rdi            # 0x269d <do_action+0x4ed>
    269d:      	leaq	0x30(%rsp), %rsi
    26a2:      	movl	$0x1, %eax
    26a7:      	callq	*%rax
    26a9:      	testq	%rax, %rax
    26ac:      	je	0x2b6e <do_action+0x9be>
    26b2:      	movq	%rax, 0x58(%rsp)
    26b7:      	movq	%rax, %rbp
    26ba:      	movq	(%rip), %rdi            # 0x26c1 <do_action+0x511>
    26c1:      	leaq	0x30(%rsp), %rsi
    26c6:      	movl	$0x1, %eax
    26cb:      	callq	*%rax
    26cd:      	movq	%rax, %rdx
    26d0:      	movq	0x20(%rsp), %rcx
    26d5:      	movq	0x60(%rcx), %rax
    26d9:      	movq	%rax, (%rbp)
    26dd:      	movq	0x70(%rcx), %rax
    26e1:      	movq	%rbp, 0x50(%rsp)
    26e6:      	movq	%rax, 0x8(%rbp)
    26ea:      	xorl	%eax, %eax
    26ec:      	movq	%rax, 0x68(%rsp)
    26f1:      	movl	$0x0, %eax
    26f6:      	movl	0x40(%rsp), %esi
    26fa:      	cmpl	$0x2, %esi
    26fd:      	je	0x299b <do_action+0x7eb>
    2703:      	cmpl	$0x1, %esi
    2706:      	je	0x2998 <do_action+0x7e8>
    270c:      	testl	%esi, %esi
    270e:      	jne	0x2b6e <do_action+0x9be>
    2714:      	movq	0x20(%rsp), %rax
    2719:      	movl	0x7c(%rax), %eax
    271c:      	jmp	0x299b <do_action+0x7eb>
    2721:      	leal	0x3(%r14), %r12d
    2725:      	movl	$0x7, %r13d
    272b:      	testb	%bpl, %bpl
    272e:      	je	0x27fd <do_action+0x64d>
    2734:      	movl	%r12d, %eax
    2737:      	movl	0x4(%r15,%rax,4), %eax
    273c:      	leal	0x2(%r14), %ecx
    2740:      	incl	%r14d
    2743:      	movl	0x4(%r15,%rcx,4), %ebp
    2748:      	movl	0x4(%r15,%r14,4), %r14d
    274d:      	cmpq	$0x4, %rax
    2751:      	ja	0x2761 <do_action+0x5b1>
    2753:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    275b:      	je	0x2c07 <do_action+0xa57>
    2761:      	movq	%rbx, %r13
    2764:      	xorl	%eax, %eax
    2766:      	movq	%rdx, %r15
    2769:      	movl	0x60(%rdx), %ebx
    276c:      	orq	%rax, %rbx
    276f:      	movl	$0xe, %eax
    2774:      	callq	*%rax
    2776:      	movq	%rax, 0x48(%rsp)
    277b:      	movw	%r14w, 0x10(%rsp)
    2781:      	movw	%bp, 0x12(%rsp)
    2786:      	movq	%rbx, 0x14(%rsp)
    278b:      	movq	(%rip), %rdi            # 0x2792 <do_action+0x5e2>
    2792:      	leaq	0x48(%rsp), %rsi
    2797:      	movl	$0x1, %eax
    279c:      	callq	*%rax
    279e:      	testq	%rax, %rax
    27a1:      	je	0x2893 <do_action+0x6e3>
    27a7:      	movq	%rax, %r14
    27aa:      	movq	0x4(%rax), %rax
    27ae:      	movq	%rax, 0x30(%rsp)
    27b3:      	movl	$0x1, 0x38(%rsp)
    27bb:      	movq	(%rip), %rdi            # 0x27c2 <do_action+0x612>
    27c2:      	leaq	0x30(%rsp), %rsi
    27c7:      	movl	$0x1, %eax
    27cc:      	callq	*%rax
    27ce:      	movl	$0x1, 0x3c(%rsp)
    27d6:      	testq	%rax, %rax
    27d9:      	movq	%r13, %rbx
    27dc:      	je	0x2932 <do_action+0x782>
    27e2:      	lock
    27e3:      	incl	(%rax)
    27e5:      	movl	0x18(%rsp), %eax
    27e9:      	movl	%eax, 0x8(%r14)
    27ed:      	movq	0x10(%rsp), %rax
    27f2:      	movq	%rax, (%r14)
    27f5:      	movl	$0x6, %r13d
    27fb:      	jmp	0x2800 <do_action+0x650>
    27fd:      	movq	%rdx, %r15
    2800:      	movl	$0x0, (%rsp)
    2807:      	movq	(%rip), %rdi            # 0x280e <do_action+0x65e>
    280e:      	movq	%rsp, %rsi
    2811:      	movl	$0x1, %eax
    2816:      	callq	*%rax
    2818:      	testq	%rax, %rax
    281b:      	je	0x2822 <do_action+0x672>
    281d:      	lock
    281e:      	incq	(%rax,%r13,8)
    2822:      	movl	%r12d, %r14d
    2825:      	movq	%r15, %rdx
    2828:      	jmp	0x2beb <do_action+0xa3b>
    282d:      	movq	(%rip), %rdi            # 0x2834 <do_action+0x684>
    2834:      	leaq	0x10(%rsp), %rsi
    2839:      	leaq	0x2c(%rsp), %rdx
    283e:      	movl	$0x1, %ecx
    2843:      	movl	$0x2, %eax
    2848:      	callq	*%rax
    284a:      	testq	%rax, %rax
    284d:      	je	0x263a <do_action+0x48a>
    2853:      	movq	%rax, %r15
    2856:      	negl	%eax
    2858:      	movw	%ax, (%rsp)
    285c:      	movw	$0x3, 0x2(%rsp)
    2863:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    286d:      	movq	%rax, 0x4(%rsp)
    2872:      	movq	(%rip), %rdi            # 0x2879 <do_action+0x6c9>
    2879:      	movq	%rsp, %rsi
    287c:      	movl	$0x1, %eax
    2881:      	callq	*%rax
    2883:      	testq	%rax, %rax
    2886:      	je	0x2c28 <do_action+0xa78>
    288c:      	incl	(%rax)
    288e:      	jmp	0x2c4a <do_action+0xa9a>
    2893:      	movq	(%rip), %rdi            # 0x289a <do_action+0x6ea>
    289a:      	xorl	%ecx, %ecx
    289c:      	leaq	0x48(%rsp), %rsi
    28a1:      	leaq	0x10(%rsp), %rdx
    28a6:      	movl	$0x2, %eax
    28ab:      	xorl	%ecx, %ecx
    28ad:      	callq	*%rax
    28af:      	testq	%rax, %rax
    28b2:      	movq	%r13, %rbx
    28b5:      	je	0x27f5 <do_action+0x645>
    28bb:      	negl	%eax
    28bd:      	movw	%ax, (%rsp)
    28c1:      	movw	$0x3, 0x2(%rsp)
    28c8:      	movabsq	$0x20000006b, %rax      # imm = 0x20000006B
    28d2:      	movq	%rax, 0x4(%rsp)
    28d7:      	movq	(%rip), %rdi            # 0x28de <do_action+0x72e>
    28de:      	movq	%rsp, %rsi
    28e1:      	movl	$0x1, %eax
    28e6:      	callq	*%rax
    28e8:      	testq	%rax, %rax
    28eb:      	je	0x2c7b <do_action+0xacb>
    28f1:      	incl	(%rax)
    28f3:      	jmp	0x27f5 <do_action+0x645>
    28f8:      	movq	(%rip), %rdi            # 0x28ff <do_action+0x74f>
    28ff:      	movq	%rsp, %rsi
    2902:      	movl	$0x3, %eax
    2907:      	jmp	0x291a <do_action+0x76a>
    2909:      	movq	(%rip), %rdi            # 0x2910 <do_action+0x760>
    2910:      	leaq	0x10(%rsp), %rsi
    2915:      	movl	$0x3, %eax
    291a:      	callq	*%rax
    291c:      	movq	%rax, %r15
    291f:      	xorl	%eax, %eax
    2921:      	movq	%r13, %rdx
    2924:      	testl	%r15d, %r15d
    2927:      	jne	0x2bf5 <do_action+0xa45>
    292d:      	jmp	0x2beb <do_action+0xa3b>
    2932:      	movq	(%rip), %rdi            # 0x2939 <do_action+0x789>
    2939:      	leaq	0x30(%rsp), %rsi
    293e:      	leaq	0x3c(%rsp), %rdx
    2943:      	movl	$0x1, %ecx
    2948:      	movl	$0x2, %eax
    294d:      	callq	*%rax
    294f:      	testq	%rax, %rax
    2952:      	je	0x27e5 <do_action+0x635>
    2958:      	movq	%rax, %r13
    295b:      	negl	%eax
    295d:      	movw	%ax, (%rsp)
    2961:      	movw	$0x3, 0x2(%rsp)
    2968:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    2972:      	movq	%rax, 0x4(%rsp)
    2977:      	movq	(%rip), %rdi            # 0x297e <do_action+0x7ce>
    297e:      	movq	%rsp, %rsi
    2981:      	movl	$0x1, %eax
    2986:      	callq	*%rax
    2988:      	testq	%rax, %rax
    298b:      	je	0x2ca2 <do_action+0xaf2>
    2991:      	incl	(%rax)
    2993:      	jmp	0x2cc4 <do_action+0xb14>
    2998:      	movl	0x10(%rcx), %eax
    299b:      	movq	%r12, 0x40(%rsp)
    29a0:      	movl	%eax, %eax
    29a2:      	movq	0x50(%rsp), %rcx
    29a7:      	movq	%rax, 0x10(%rcx)
    29ab:      	movq	0x58(%rsp), %rdi
    29b0:      	addq	$0x18, %rdi
    29b4:      	movl	$0xc8, %ecx
    29b9:      	movl	$0x4, %eax
    29be:      	movq	%rdi, 0x58(%rsp)
    29c3:      	movl	$0xc8, %esi
    29c8:      	callq	*%rax
    29ca:      	xorl	%r12d, %r12d
    29cd:      	movq	%rbx, 0x80(%rsp)
    29d5:      	jmp	0x29e5 <do_action+0x835>
    29d7:      	addq	$0x4, %r12
    29db:      	cmpq	$0x14, %r12
    29df:      	je	0x2b1a <do_action+0x96a>
    29e5:      	movl	$0x0, 0x10(%rsp)
    29ed:      	movl	$0x1, %eax
    29f2:      	movq	(%rip), %rdi            # 0x29f9 <do_action+0x849>
    29f9:      	leaq	0x10(%rsp), %rsi
    29fe:      	callq	*%rax
    2a00:      	testq	%rax, %rax
    2a03:      	je	0x2b1a <do_action+0x96a>
    2a09:      	movq	%rax, %rsi
    2a0c:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    2a13:      	movl	$0x1, %eax
    2a18:      	movq	(%rip), %rdi            # 0x2a1f <do_action+0x86f>
    2a1f:      	callq	*%rax
    2a21:      	testq	%rax, %rax
    2a24:      	je	0x2b1a <do_action+0x96a>
    2a2a:      	cmpl	$-0x1, 0x40(%rax,%r12)
    2a30:      	movq	0x20(%rsp), %rdx
    2a35:      	je	0x2b1a <do_action+0x96a>
    2a3b:      	movq	0x5e78(%rdx,%r12,2), %rax
    2a43:      	movl	0x4(%rdx), %ecx
    2a46:      	cmpq	%rcx, %rax
    2a49:      	jge	0x2b1a <do_action+0x96a>
    2a4f:      	cmpq	$0x10, %r12
    2a53:      	je	0x2ac0 <do_action+0x910>
    2a55:      	movl	$0x0, 0x10(%rsp)
    2a5d:      	movl	$0x1, %eax
    2a62:      	movq	(%rip), %rdi            # 0x2a69 <do_action+0x8b9>
    2a69:      	leaq	0x10(%rsp), %rsi
    2a6e:      	callq	*%rax
    2a70:      	testq	%rax, %rax
    2a73:      	je	0x2ab3 <do_action+0x903>
    2a75:      	movq	%rax, %rsi
    2a78:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    2a7f:      	movl	$0x1, %eax
    2a84:      	movq	(%rip), %rdi            # 0x2a8b <do_action+0x8db>
    2a8b:      	callq	*%rax
    2a8d:      	testq	%rax, %rax
    2a90:      	je	0x2ab3 <do_action+0x903>
    2a92:      	cmpl	$-0x1, 0x44(%rax,%r12)
    2a98:      	movq	0x20(%rsp), %rdx
    2a9d:      	movq	0x5e78(%rdx,%r12,2), %rax
    2aa5:      	je	0x2ac0 <do_action+0x910>
    2aa7:      	movl	0x5e80(%rdx,%r12,2), %ebp
    2aaf:      	subl	%eax, %ebp
    2ab1:      	jmp	0x2ac8 <do_action+0x918>
    2ab3:      	movq	0x20(%rsp), %rdx
    2ab8:      	movq	0x5e78(%rdx,%r12,2), %rax
    2ac0:      	movl	0x4(%rdx), %ebp
    2ac3:      	subl	%eax, %ebp
    2ac5:      	addl	$0x4, %ebp
    2ac8:      	testl	%ebp, %ebp
    2aca:      	jle	0x29d7 <do_action+0x827>
    2ad0:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    2ad5:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    2ada:      	cmpl	$0x28, %ebp
    2add:      	movl	$0x28, %ecx
    2ae2:      	cmovgel	%ecx, %ebp
    2ae5:      	movzbl	0x68(%rsp), %ebx
    2aea:      	movq	0x58(%rsp), %rcx
    2aef:      	leaq	(%rcx,%rbx), %rdi
    2af3:      	addq	%rax, %rdx
    2af6:      	addq	$0x90, %rdx
    2afd:      	movl	$0x4, %eax
    2b02:      	movl	%ebp, %esi
    2b04:      	callq	*%rax
    2b06:      	addl	%ebx, %ebp
    2b08:      	movq	0x80(%rsp), %rbx
    2b10:      	movq	%rbp, 0x68(%rsp)
    2b15:      	jmp	0x29d7 <do_action+0x827>
    2b1a:      	movq	(%rip), %rdi            # 0x2b21 <do_action+0x971>
    2b21:      	movl	$0x1, %eax
    2b26:      	movq	0x50(%rsp), %rsi
    2b2b:      	callq	*%rax
    2b2d:      	testq	%rax, %rax
    2b30:      	je	0x2b4f <do_action+0x99f>
    2b32:      	imulq	$-0xf4240, 0x78(%rsp), %rcx # imm = 0xFFF0BDC0
    2b3b:      	movq	0x70(%rsp), %rdx
    2b40:      	addq	%rcx, %rdx
    2b43:      	cmpq	%rdx, (%rax)
    2b46:      	jbe	0x2b4f <do_action+0x99f>
    2b48:      	movb	$0x0, (%r13)
    2b4d:      	jmp	0x2b69 <do_action+0x9b9>
    2b4f:      	movq	(%rip), %rdi            # 0x2b56 <do_action+0x9a6>
    2b56:      	xorl	%ecx, %ecx
    2b58:      	movq	%rsp, %rdx
    2b5b:      	movl	$0x2, %eax
    2b60:      	movq	0x50(%rsp), %rsi
    2b65:      	xorl	%ecx, %ecx
    2b67:      	callq	*%rax
    2b69:      	movq	0x40(%rsp), %r12
    2b6e:      	leal	0x3(%r14), %eax
    2b72:      	cmpl	$0x0, 0x4(%r15,%rax,4)
    2b78:      	movq	0x20(%rsp), %rdx
    2b7d:      	je	0x2ba4 <do_action+0x9f4>
    2b7f:      	orb	$0x2, 0x1(%rdx)
    2b83:      	movq	(%rip), %rsi            # 0x2b8a <do_action+0x9da>
    2b8a:      	xorl	%ecx, %ecx
    2b8c:      	movl	$0x1b, %eax
    2b91:      	movq	%r12, %rdi
    2b94:      	xorl	%edx, %edx
    2b96:      	callq	*%rax
    2b98:      	movq	0x20(%rsp), %rdx
    2b9d:      	movq	%rax, 0x80(%rdx)
    2ba4:      	leal	0x4(%r14), %eax
    2ba8:      	cmpl	$0x0, 0x4(%r15,%rax,4)
    2bae:      	je	0x2bdb <do_action+0xa2b>
    2bb0:      	orb	$0x4, 0x1(%rdx)
    2bb4:      	movq	(%rip), %rsi            # 0x2bbb <do_action+0xa0b>
    2bbb:      	movl	$0x100, %ecx            # imm = 0x100
    2bc0:      	movl	$0x1b, %eax
    2bc5:      	movl	$0x100, %edx            # imm = 0x100
    2bca:      	movq	%r12, %rdi
    2bcd:      	callq	*%rax
    2bcf:      	movq	0x20(%rsp), %rdx
    2bd4:      	movq	%rax, 0x88(%rdx)
    2bdb:      	addl	$0x5, %r14d
    2bdf:      	cmpl	$0x0, 0x4(%r15,%r14,4)
    2be5:      	je	0x2beb <do_action+0xa3b>
    2be7:      	orb	$0x8, 0x1(%rdx)
    2beb:      	movq	%rbx, 0x70(%rdx)
    2bef:      	incl	%r14d
    2bf2:      	movl	%r14d, %eax
    2bf5:      	addq	$0x88, %rsp
    2bfc:      	popq	%rbx
    2bfd:      	popq	%r12
    2bff:      	popq	%r13
    2c01:      	popq	%r14
    2c03:      	popq	%r15
    2c05:      	popq	%rbp
    2c06:      	retq
    2c07:      	movq	%rbx, %r13
    2c0a:      	movq	0x5e78(%rdx,%rax,8), %rax
    2c12:      	andl	$0x7ff, %eax            # imm = 0x7FF
    2c17:      	movq	0x90(%rdx,%rax), %rax
    2c1f:      	shlq	$0x20, %rax
    2c23:      	jmp	0x2766 <do_action+0x5b6>
    2c28:      	movl	$0x1, 0x48(%rsp)
    2c30:      	movq	(%rip), %rdi            # 0x2c37 <do_action+0xa87>
    2c37:      	xorl	%ecx, %ecx
    2c39:      	movq	%rsp, %rsi
    2c3c:      	leaq	0x48(%rsp), %rdx
    2c41:      	movl	$0x2, %eax
    2c46:      	xorl	%ecx, %ecx
    2c48:      	callq	*%rax
    2c4a:      	testl	%r15d, %r15d
    2c4d:      	je	0x263a <do_action+0x48a>
    2c53:      	movq	(%rip), %rdi            # 0x2c5a <do_action+0xaaa>
    2c5a:      	leaq	0x10(%rsp), %rsi
    2c5f:      	movl	$0x1, %eax
    2c64:      	callq	*%rax
    2c66:      	testq	%rax, %rax
    2c69:      	je	0x263a <do_action+0x48a>
    2c6f:      	movl	0x2c(%rsp), %ecx
    2c73:      	lock
    2c74:      	addl	%ecx, (%rax)
    2c76:      	jmp	0x263a <do_action+0x48a>
    2c7b:      	movl	$0x1, 0x30(%rsp)
    2c83:      	movq	(%rip), %rdi            # 0x2c8a <do_action+0xada>
    2c8a:      	xorl	%ecx, %ecx
    2c8c:      	movq	%rsp, %rsi
    2c8f:      	leaq	0x30(%rsp), %rdx
    2c94:      	movl	$0x2, %eax
    2c99:      	xorl	%ecx, %ecx
    2c9b:      	callq	*%rax
    2c9d:      	jmp	0x27f5 <do_action+0x645>
    2ca2:      	movl	$0x1, 0x2c(%rsp)
    2caa:      	movq	(%rip), %rdi            # 0x2cb1 <do_action+0xb01>
    2cb1:      	xorl	%ecx, %ecx
    2cb3:      	movq	%rsp, %rsi
    2cb6:      	leaq	0x2c(%rsp), %rdx
    2cbb:      	movl	$0x2, %eax
    2cc0:      	xorl	%ecx, %ecx
    2cc2:      	callq	*%rax
    2cc4:      	testl	%r13d, %r13d
    2cc7:      	je	0x27e5 <do_action+0x635>
    2ccd:      	movq	(%rip), %rdi            # 0x2cd4 <do_action+0xb24>
    2cd4:      	leaq	0x30(%rsp), %rsi
    2cd9:      	movl	$0x1, %eax
    2cde:      	callq	*%rax
    2ce0:      	testq	%rax, %rax
    2ce3:      	je	0x27e5 <do_action+0x635>
    2ce9:      	movl	0x3c(%rsp), %ecx
    2ced:      	lock
    2cee:      	addl	%ecx, (%rax)
    2cf0:      	jmp	0x27e5 <do_action+0x635>

Disassembly of section tracepoint:

0000000000000000 <generic_tracepoint_process_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x108, %rsp            # imm = 0x108
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0xe4(%rsp)
      1f:      	movq	(%rip), %rdi            # 0x26 <generic_tracepoint_process_event+0x26>
      26:      	leaq	0xe4(%rsp), %rsi
      2e:      	movl	$0x1, %eax
      33:      	callq	*%rax
      35:      	testq	%rax, %rax
      38:      	je	0x33a6 <generic_tracepoint_process_event+0x33a6>
      3e:      	movq	%rax, %r14
      41:      	movl	0x5efc(%rax), %ebp
      47:      	movl	0x4(%rax), %r12d
      4b:      	cmpq	$0x2327, %r12           # imm = 0x2327
      52:      	ja	0x444 <generic_tracepoint_process_event+0x444>
      58:      	movl	$0x0, 0xe8(%rsp)
      63:      	movq	(%rip), %rdi            # 0x6a <generic_tracepoint_process_event+0x6a>
      6a:      	leaq	0xe8(%rsp), %rsi
      72:      	movl	$0x1, %eax
      77:      	callq	*%rax
      79:      	testq	%rax, %rax
      7c:      	je	0x444 <generic_tracepoint_process_event+0x444>
      82:      	movq	%rax, %r15
      85:      	leaq	0x5ef8(%rax), %rsi
      8c:      	movq	(%rip), %rdi            # 0x93 <generic_tracepoint_process_event+0x93>
      93:      	movl	$0x1, %eax
      98:      	callq	*%rax
      9a:      	cmpl	$0x4, %ebp
      9d:      	jg	0x444 <generic_tracepoint_process_event+0x444>
      a3:      	testq	%rax, %rax
      a6:      	je	0x444 <generic_tracepoint_process_event+0x444>
      ac:      	movq	%r12, 0xb0(%rsp)
      b4:      	movl	%ebp, %edx
      b6:      	andl	$0x7, %edx
      b9:      	movl	%edx, %ecx
      bb:      	movl	0x4(%rax,%rcx,4), %r13d
      c0:      	movslq	0x18(%rax,%rcx,4), %r12
      c5:      	movl	$0x0, 0x5ea0(%r15,%rcx,4)
      d1:      	movq	0x5e50(%r15,%rcx,8), %rsi
      d9:      	movq	%rsi, 0xd8(%rsp)
      e1:      	testl	$0x100, %r12d           # imm = 0x100
      e8:      	movq	%rdx, 0x8(%rsp)
      ed:      	jne	0x152 <generic_tracepoint_process_event+0x152>
      ef:      	cmpl	$0x4, %edx
      f2:      	ja	0x160 <generic_tracepoint_process_event+0x160>
      f4:      	leaq	(%rdx,%rdx,4), %rdx
      f8:      	shll	$0x4, %edx
      fb:      	cmpw	$0x0, 0x76(%rax,%rdx)
     101:      	je	0x160 <generic_tracepoint_process_event+0x160>
     103:      	movq	%rbp, 0x50(%rsp)
     108:      	addq	%rdx, %rax
     10b:      	addq	$0x70, %rax
     10f:      	movq	%rax, 0x58(%rsp)
     114:      	leaq	0xd8(%rsp), %rax
     11c:      	movq	%rax, 0x60(%rsp)
     121:      	movb	$0x0, 0x68(%rsp)
     126:      	leaq	(%r15,%rcx,4), %rax
     12a:      	addq	$0x5ea0, %rax           # imm = 0x5EA0
     130:      	movq	%rax, 0x70(%rsp)
     135:      	movq	(%rip), %rax            # 0x13c <generic_tracepoint_process_event+0x13c>
     13c:      	cmpb	$0x0, (%rax)
     13f:      	je	0x27f <generic_tracepoint_process_event+0x27f>
     145:      	xorl	%r15d, %r15d
     148:      	movl	$0x8, %ebp
     14d:      	jmp	0x1d3 <generic_tracepoint_process_event+0x1d3>
     152:      	movq	$0x0, 0xd8(%rsp)
     15e:      	xorl	%esi, %esi
     160:      	movl	$0x1000, %r15d          # imm = 0x1000
     166:      	cmpl	$0x15, %r13d
     16a:      	jg	0x309 <generic_tracepoint_process_event+0x309>
     170:      	cmpl	$0xb, %r13d
     174:      	jg	0x20b <generic_tracepoint_process_event+0x20b>
     17a:      	cmpl	$0x5, %r13d
     17e:      	jg	0x230 <generic_tracepoint_process_event+0x230>
     184:      	cmpl	$0x3, %r13d
     188:      	jg	0x2bd <generic_tracepoint_process_event+0x2bd>
     18e:      	leal	-0x2(%r13), %eax
     192:      	cmpl	$0x2, %eax
     195:      	jb	0x37e <generic_tracepoint_process_event+0x37e>
     19b:      	cmpl	$0x1, %r13d
     19f:      	je	0x37e <generic_tracepoint_process_event+0x37e>
     1a5:      	jmp	0x3b8 <generic_tracepoint_process_event+0x3b8>
     1aa:      	movl	$0x4, %eax
     1af:      	movq	0x60(%rsp), %rdi
     1b4:      	movq	(%rdi), %rdx
     1b7:      	movl	$0x8, %esi
     1bc:      	callq	*%rax
     1be:      	testl	%eax, %eax
     1c0:      	js	0x2e1 <generic_tracepoint_process_event+0x2e1>
     1c6:      	incq	%r15
     1c9:      	cmpq	$0xa, %r15
     1cd:      	je	0x2ec <generic_tracepoint_process_event+0x2ec>
     1d3:      	movq	0x58(%rsp), %rax
     1d8:      	cmpw	$0x0, 0x6(%rax,%r15,8)
     1df:      	je	0x2ec <generic_tracepoint_process_event+0x2ec>
     1e5:      	movq	0x60(%rsp), %rcx
     1ea:      	movl	(%rax,%r15,8), %edx
     1ee:      	addq	(%rcx), %rdx
     1f1:      	movq	%rdx, (%rcx)
     1f4:      	cmpw	$0x0, 0x4(%rax,%r15,8)
     1fb:      	je	0x1c6 <generic_tracepoint_process_event+0x1c6>
     1fd:      	cmpb	$0x0, 0x68(%rsp)
     202:      	je	0x1aa <generic_tracepoint_process_event+0x1aa>
     204:      	movl	$0x94, %eax
     209:      	jmp	0x1af <generic_tracepoint_process_event+0x1af>
     20b:      	cmpl	$0x11, %r13d
     20f:      	jg	0x25d <generic_tracepoint_process_event+0x25d>
     211:      	leal	-0xf(%r13), %eax
     215:      	cmpl	$0x3, %eax
     218:      	jb	0x3bb <generic_tracepoint_process_event+0x3bb>
     21e:      	leal	-0xc(%r13), %eax
     222:      	cmpl	$0x2, %eax
     225:      	jb	0x37e <generic_tracepoint_process_event+0x37e>
     22b:      	jmp	0x3b8 <generic_tracepoint_process_event+0x3b8>
     230:      	cmpl	$0x9, %r13d
     234:      	jg	0x34d <generic_tracepoint_process_event+0x34d>
     23a:      	cmpl	$0x6, %r13d
     23e:      	je	0x3bb <generic_tracepoint_process_event+0x3bb>
     244:      	cmpl	$0x7, %r13d
     248:      	je	0x39a <generic_tracepoint_process_event+0x39a>
     24e:      	cmpl	$0x8, %r13d
     252:      	je	0x3b0 <generic_tracepoint_process_event+0x3b0>
     258:      	jmp	0x3b8 <generic_tracepoint_process_event+0x3b8>
     25d:      	cmpl	$0x13, %r13d
     261:      	jg	0x2a2 <generic_tracepoint_process_event+0x2a2>
     263:      	movq	%r12, %r15
     266:      	cmpl	$0x12, %r13d
     26a:      	je	0x3bb <generic_tracepoint_process_event+0x3bb>
     270:      	cmpl	$0x13, %r13d
     274:      	je	0x3a2 <generic_tracepoint_process_event+0x3a2>
     27a:      	jmp	0x3b8 <generic_tracepoint_process_event+0x3b8>
     27f:      	leaq	(%rip), %rsi            # 0x286 <generic_tracepoint_process_event+0x286>
     286:      	xorl	%ecx, %ecx
     288:      	leaq	0x58(%rsp), %rdx
     28d:      	movl	$0xa, %edi
     292:      	movl	$0xb5, %eax
     297:      	movl	$0xa, %edi
     29c:      	xorl	%ecx, %ecx
     29e:      	callq	*%rax
     2a0:      	jmp	0x2ec <generic_tracepoint_process_event+0x2ec>
     2a2:      	cmpl	$0x14, %r13d
     2a6:      	je	0x2d6 <generic_tracepoint_process_event+0x2d6>
     2a8:      	cmpl	$0x15, %r13d
     2ac:      	jne	0x3b8 <generic_tracepoint_process_event+0x3b8>
     2b2:      	movl	$0x20, %r15d
     2b8:      	jmp	0x3bb <generic_tracepoint_process_event+0x3bb>
     2bd:      	cmpl	$0x4, %r13d
     2c1:      	je	0x34d <generic_tracepoint_process_event+0x34d>
     2c7:      	cmpl	$0x5, %r13d
     2cb:      	je	0x39a <generic_tracepoint_process_event+0x39a>
     2d1:      	jmp	0x3b8 <generic_tracepoint_process_event+0x3b8>
     2d6:      	movl	$0x98, %r15d
     2dc:      	jmp	0x3bb <generic_tracepoint_process_event+0x3bb>
     2e1:      	incl	%r15d
     2e4:      	movq	0x70(%rsp), %rax
     2e9:      	movl	%r15d, (%rax)
     2ec:      	movq	0xd8(%rsp), %rsi
     2f4:      	movq	0x50(%rsp), %rbp
     2f9:      	movl	$0x1000, %r15d          # imm = 0x1000
     2ff:      	cmpl	$0x15, %r13d
     303:      	jle	0x170 <generic_tracepoint_process_event+0x170>
     309:      	cmpl	$0x20, %r13d
     30d:      	jle	0x333 <generic_tracepoint_process_event+0x333>
     30f:      	cmpl	$0x27, %r13d
     313:      	jg	0x355 <generic_tracepoint_process_event+0x355>
     315:      	leal	-0x21(%r13), %eax
     319:      	cmpl	$0x4, %eax
     31c:      	jb	0x34d <generic_tracepoint_process_event+0x34d>
     31e:      	cmpl	$0x25, %r13d
     322:      	je	0x3bb <generic_tracepoint_process_event+0x3bb>
     328:      	cmpl	$0x27, %r13d
     32c:      	je	0x386 <generic_tracepoint_process_event+0x386>
     32e:      	jmp	0x3b8 <generic_tracepoint_process_event+0x3b8>
     333:      	cmpl	$0x1a, %r13d
     337:      	jg	0x375 <generic_tracepoint_process_event+0x375>
     339:      	cmpl	$0x16, %r13d
     33d:      	je	0x386 <generic_tracepoint_process_event+0x386>
     33f:      	cmpl	$0x17, %r13d
     343:      	je	0x34d <generic_tracepoint_process_event+0x34d>
     345:      	cmpl	$0x1a, %r13d
     349:      	je	0x3b0 <generic_tracepoint_process_event+0x3b0>
     34b:      	jmp	0x3b8 <generic_tracepoint_process_event+0x3b8>
     34d:      	movl	$0x8, %r15d
     353:      	jmp	0x3bb <generic_tracepoint_process_event+0x3bb>
     355:      	cmpl	$0x29, %r13d
     359:      	jle	0x38e <generic_tracepoint_process_event+0x38e>
     35b:      	cmpl	$0x2a, %r13d
     35f:      	je	0x3bb <generic_tracepoint_process_event+0x3bb>
     361:      	cmpl	$0x2b, %r13d
     365:      	je	0x3a2 <generic_tracepoint_process_event+0x3a2>
     367:      	cmpl	$0x2c, %r13d
     36b:      	jne	0x3b8 <generic_tracepoint_process_event+0x3b8>
     36d:      	movl	$0x70, %r15d
     373:      	jmp	0x3bb <generic_tracepoint_process_event+0x3bb>
     375:      	leal	-0x1d(%r13), %eax
     379:      	cmpl	$0x4, %eax
     37c:      	jae	0x3aa <generic_tracepoint_process_event+0x3aa>
     37e:      	movl	$0x4, %r15d
     384:      	jmp	0x3bb <generic_tracepoint_process_event+0x3bb>
     386:      	movl	$0x10, %r15d
     38c:      	jmp	0x3bb <generic_tracepoint_process_event+0x3bb>
     38e:      	cmpl	$0x28, %r13d
     392:      	je	0x3a2 <generic_tracepoint_process_event+0x3a2>
     394:      	cmpl	$0x29, %r13d
     398:      	jne	0x3b8 <generic_tracepoint_process_event+0x3b8>
     39a:      	movl	$0x40, %r15d
     3a0:      	jmp	0x3bb <generic_tracepoint_process_event+0x3bb>
     3a2:      	movl	$0x18, %r15d
     3a8:      	jmp	0x3bb <generic_tracepoint_process_event+0x3bb>
     3aa:      	cmpl	$0x1b, %r13d
     3ae:      	jne	0x3b8 <generic_tracepoint_process_event+0x3b8>
     3b0:      	movl	$0x50, %r15d
     3b6:      	jmp	0x3bb <generic_tracepoint_process_event+0x3bb>
     3b8:      	xorl	%r15d, %r15d
     3bb:      	movq	%rsi, 0x20(%rsp)
     3c0:      	movl	$0x0, 0xec(%rsp)
     3cb:      	movq	(%rip), %rdi            # 0x3d2 <generic_tracepoint_process_event+0x3d2>
     3d2:      	leaq	0xec(%rsp), %rsi
     3da:      	movl	$0x1, %eax
     3df:      	callq	*%rax
     3e1:      	testq	%rax, %rax
     3e4:      	je	0x43c <generic_tracepoint_process_event+0x43c>
     3e6:      	movl	$0x3ffb, %ecx           # imm = 0x3FFB
     3eb:      	subq	%r15, %rcx
     3ee:      	cmpq	0xb0(%rsp), %rcx
     3f6:      	jbe	0x43c <generic_tracepoint_process_event+0x43c>
     3f8:      	movq	0x8(%rsp), %rsi
     3fd:      	movl	0x5ea0(%rax,%rsi,4), %ecx
     404:      	movq	0xb0(%rsp), %rdx
     40c:      	movl	%ecx, 0x90(%rax,%rdx)
     413:      	leaq	0x4(%rdx), %r15
     417:      	movq	%rsi, %rdx
     41a:      	movq	%r15, 0x5e78(%rax,%rsi,8)
     422:      	movl	$0x4, %edx
     427:      	testl	%ecx, %ecx
     429:      	je	0x4cf <generic_tracepoint_process_event+0x4cf>
     42f:      	movq	0xb0(%rsp), %r12
     437:      	jmp	0x336d <generic_tracepoint_process_event+0x336d>
     43c:      	movq	0xb0(%rsp), %r12
     444:      	movl	%r12d, 0x4(%r14)
     448:      	cmpl	$0x3, %ebp
     44b:      	jg	0x3380 <generic_tracepoint_process_event+0x3380>
     451:      	movl	$0x0, 0x58(%rsp)
     459:      	movq	(%rip), %rdi            # 0x460 <generic_tracepoint_process_event+0x460>
     460:      	leaq	0x58(%rsp), %rsi
     465:      	movl	$0x1, %eax
     46a:      	callq	*%rax
     46c:      	testq	%rax, %rax
     46f:      	je	0x3380 <generic_tracepoint_process_event+0x3380>
     475:      	movq	%rax, %rsi
     478:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     47f:      	movq	(%rip), %rdi            # 0x486 <generic_tracepoint_process_event+0x486>
     486:      	movl	$0x1, %eax
     48b:      	callq	*%rax
     48d:      	testq	%rax, %rax
     490:      	je	0x3380 <generic_tracepoint_process_event+0x3380>
     496:      	incl	%ebp
     498:      	movl	%ebp, %ecx
     49a:      	andl	$0x7, %ecx
     49d:      	cmpl	$-0x1, 0x40(%rax,%rcx,4)
     4a2:      	je	0x3380 <generic_tracepoint_process_event+0x3380>
     4a8:      	movl	%ebp, 0x5efc(%r14)
     4af:      	movq	(%rip), %rsi            # 0x4b6 <generic_tracepoint_process_event+0x4b6>
     4b6:      	movl	$0x1, %ecx
     4bb:      	movl	$0xc, %eax
     4c0:      	movq	%rbx, %rdi
     4c3:      	movl	$0x1, %edx
     4c8:      	callq	*%rax
     4ca:      	jmp	0x3380 <generic_tracepoint_process_event+0x3380>
     4cf:      	movq	%rax, %rcx
     4d2:      	addq	$0x90, %rcx
     4d9:      	andl	$0x3fff, %r15d          # imm = 0x3FFF
     4e0:      	addq	%r15, %rcx
     4e3:      	movq	%rcx, 0x10(%rsp)
     4e8:      	movq	0x20(%rsp), %rdx
     4ed:      	movq	%rdx, 0x58(%rsp)
     4f2:      	movq	$0x0, 0x98(%rsp)
     4fe:      	cmpl	$0x17, %r13d
     502:      	movq	%rbx, 0x28(%rsp)
     507:      	movq	%rax, 0x18(%rsp)
     50c:      	movq	%rbp, 0x50(%rsp)
     511:      	jle	0x54e <generic_tracepoint_process_event+0x54e>
     513:      	cmpl	$0x18, %r13d
     517:      	je	0x569 <generic_tracepoint_process_event+0x569>
     519:      	cmpl	$0x25, %r13d
     51d:      	je	0x5a7 <generic_tracepoint_process_event+0x5a7>
     523:      	cmpl	$0x2a, %r13d
     527:      	jne	0xc73 <generic_tracepoint_process_event+0xc73>
     52d:      	movq	$0x0, 0xf8(%rsp)
     539:      	movq	%rdx, 0x100(%rsp)
     541:      	leaq	0xf8(%rsp), %rbp
     549:      	jmp	0x5d4 <generic_tracepoint_process_event+0x5d4>
     54e:      	cmpl	$0xf, %r13d
     552:      	je	0xbae <generic_tracepoint_process_event+0xbae>
     558:      	cmpl	$0x10, %r13d
     55c:      	jne	0xc73 <generic_tracepoint_process_event+0xc73>
     562:      	leaq	0x40(%rsp), %r15
     567:      	jmp	0x591 <generic_tracepoint_process_event+0x591>
     569:      	leaq	0x40(%rsp), %r15
     56e:      	movl	$0x8, %ecx
     573:      	movl	$0x4, %eax
     578:      	movq	0x58(%rsp), %rdx
     57d:      	movq	%r15, %rdi
     580:      	movl	$0x8, %esi
     585:      	callq	*%rax
     587:      	movq	0x40(%rsp), %rax
     58c:      	movq	%rax, 0x58(%rsp)
     591:      	leaq	0x58(%rsp), %rdx
     596:      	movl	$0x8, %ecx
     59b:      	movl	$0x4, %eax
     5a0:      	leaq	0x40(%rsp), %rdi
     5a5:      	jmp	0x5c4 <generic_tracepoint_process_event+0x5c4>
     5a7:      	addq	$0x40, %rdx
     5ab:      	movq	%rdx, 0x58(%rsp)
     5b0:      	leaq	0x40(%rsp), %rdi
     5b5:      	movl	$0x8, %ecx
     5ba:      	movl	$0x4, %eax
     5bf:      	movq	0x58(%rsp), %rdx
     5c4:      	movl	$0x8, %esi
     5c9:      	callq	*%rax
     5cb:      	movq	0x40(%rsp), %rbp
     5d0:      	addq	$0x40, %rbp
     5d4:      	movl	$0x0, 0xac(%rsp)
     5df:      	movq	(%rip), %rdi            # 0x5e6 <generic_tracepoint_process_event+0x5e6>
     5e6:      	leaq	0xac(%rsp), %rsi
     5ee:      	movl	$0x1, %eax
     5f3:      	callq	*%rax
     5f5:      	testq	%rax, %rax
     5f8:      	je	0x6a7 <generic_tracepoint_process_event+0x6a7>
     5fe:      	movq	%rax, %r12
     601:      	addq	$0x1000, %rax           # imm = 0x1000
     607:      	movq	%rax, 0x20(%rsp)
     60c:      	movl	$0x23, %eax
     611:      	callq	*%rax
     613:      	leaq	0xd50(%rax), %rdx
     61a:      	leaq	0xd0(%rsp), %rdi
     622:      	movl	$0x8, %ecx
     627:      	movl	$0x4, %eax
     62c:      	movl	$0x8, %esi
     631:      	callq	*%rax
     633:      	movq	0xd0(%rsp), %r13
     63b:      	movq	%rbp, 0xb8(%rsp)
     643:      	leaq	0x8(%rbp), %rdx
     647:      	leaq	0xc0(%rsp), %rdi
     64f:      	movl	$0x8, %ecx
     654:      	movl	$0x4, %eax
     659:      	leaq	0x18(%r13), %rcx
     65d:      	movq	%rcx, 0xf0(%rsp)
     665:      	movl	$0x8, %esi
     66a:      	movq	%rdx, 0x30(%rsp)
     66f:      	callq	*%rax
     671:      	movq	0xc0(%rsp), %r15
     679:      	leaq	0x10(%r15), %rdx
     67d:      	leaq	0x58(%rsp), %rdi
     682:      	movl	$0x8, %ecx
     687:      	movl	$0x4, %eax
     68c:      	movl	$0x8, %esi
     691:      	callq	*%rax
     693:      	cmpq	$0x0, 0x58(%rsp)
     699:      	movl	$0x1000, %ebp           # imm = 0x1000
     69e:      	je	0x6bc <generic_tracepoint_process_event+0x6bc>
     6a0:      	movq	0x20(%rsp), %rcx
     6a5:      	jmp	0x70e <generic_tracepoint_process_event+0x70e>
     6a7:      	xorl	%r15d, %r15d
     6aa:      	movq	0x50(%rsp), %rbp
     6af:      	movq	0xb0(%rsp), %r12
     6b7:      	jmp	0x3340 <generic_tracepoint_process_event+0x3340>
     6bc:      	leaq	0x18(%r15), %rdx
     6c0:      	leaq	0x58(%rsp), %rdi
     6c5:      	movl	$0x8, %ecx
     6ca:      	movl	$0x4, %eax
     6cf:      	movl	$0x8, %esi
     6d4:      	callq	*%rax
     6d6:      	cmpq	%r15, 0x58(%rsp)
     6db:      	movq	0x20(%rsp), %rcx
     6e0:      	je	0x70e <generic_tracepoint_process_event+0x70e>
     6e2:      	movq	%r12, %rcx
     6e5:      	addq	$0xff6, %rcx            # imm = 0xFF6
     6ec:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
     6f6:      	movq	%rax, 0xff6(%r12)
     6fe:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
     709:      	movl	$0xff6, %ebp            # imm = 0xFF6
     70e:      	movq	$0x0, 0x60(%rsp)
     717:      	movq	$0x0, 0x58(%rsp)
     720:      	movq	%r12, 0x68(%rsp)
     725:      	movq	$0x0, 0x70(%rsp)
     72e:      	movq	$0x0, 0x78(%rsp)
     737:      	movq	$0x0, 0x80(%rsp)
     743:      	movq	%rcx, 0x20(%rsp)
     748:      	movq	%rcx, 0x88(%rsp)
     750:      	movl	%ebp, 0x90(%rsp)
     757:      	movb	$0x0, 0x94(%rsp)
     75f:      	addq	$0x20, %r13
     763:      	leaq	0x58(%rsp), %rdi
     768:      	movl	$0x8, %ecx
     76d:      	movl	$0x4, %eax
     772:      	leaq	0x60(%rsp), %r12
     777:      	leaq	0x70(%rsp), %r15
     77c:      	leaq	0x78(%rsp), %rbp
     781:      	movl	$0x8, %esi
     786:      	movq	%r13, %rdx
     789:      	callq	*%rax
     78b:      	movl	$0x8, %ecx
     790:      	movl	$0x4, %eax
     795:      	movq	0xf0(%rsp), %rdx
     79d:      	movq	%r12, %rdi
     7a0:      	movl	$0x8, %esi
     7a5:      	callq	*%rax
     7a7:      	movl	$0x8, %ecx
     7ac:      	movl	$0x4, %eax
     7b1:      	movq	0x30(%rsp), %rdx
     7b6:      	movq	%r15, %rdi
     7b9:      	movl	$0x8, %esi
     7be:      	callq	*%rax
     7c0:      	movl	$0x8, %ecx
     7c5:      	movl	$0x4, %eax
     7ca:      	movq	0xb8(%rsp), %rdx
     7d2:      	movq	%rbp, %rdi
     7d5:      	movl	$0x8, %esi
     7da:      	callq	*%rax
     7dc:      	movq	0x78(%rsp), %rax
     7e1:      	addq	$-0x20, %rax
     7e5:      	movq	%rax, 0x80(%rsp)
     7ed:      	movq	(%rip), %rax            # 0x7f4 <generic_tracepoint_process_event+0x7f4>
     7f4:      	cmpb	$0x0, (%rax)
     7f7:      	je	0x9d8 <generic_tracepoint_process_event+0x9d8>
     7fd:      	movl	$0x800, %ebp            # imm = 0x800
     802:      	movl	$0x8, %r15d
     808:      	movq	0x70(%rsp), %r12
     80d:      	movq	0x78(%rsp), %rdx
     812:      	movq	0x80(%rsp), %r13
     81a:      	cmpq	0x58(%rsp), %r12
     81f:      	jne	0x82c <generic_tracepoint_process_event+0x82c>
     821:      	cmpq	0x60(%rsp), %rdx
     826:      	je	0xd25 <generic_tracepoint_process_event+0xd25>
     82c:      	movl	$0x4, %eax
     831:      	leaq	0xc8(%rsp), %rdi
     839:      	movl	$0x8, %esi
     83e:      	callq	*%rax
     840:      	cmpq	0xc8(%rsp), %r12
     848:      	movl	$0x8, %ebx
     84d:      	je	0x96a <generic_tracepoint_process_event+0x96a>
     853:      	leaq	0x18(%r12), %r15
     858:      	movl	$0x4, %eax
     85d:      	leaq	0x40(%rsp), %rdi
     862:      	movl	$0x8, %esi
     867:      	movq	%r15, %rdx
     86a:      	callq	*%rax
     86c:      	cmpq	%r12, 0x40(%rsp)
     871:      	je	0x96a <generic_tracepoint_process_event+0x96a>
     877:      	movl	$0x4, %eax
     87c:      	leaq	0x38(%rsp), %rdi
     881:      	movl	$0x8, %esi
     886:      	movq	%r15, %rdx
     889:      	callq	*%rax
     88b:      	addq	$0x20, %r12
     88f:      	movl	$0x4, %eax
     894:      	leaq	0x98(%rsp), %rdi
     89c:      	movl	$0x10, %ecx
     8a1:      	movl	$0x10, %esi
     8a6:      	movq	%r12, %rdx
     8a9:      	callq	*%rax
     8ab:      	movq	0x68(%rsp), %r15
     8b0:      	movq	0x88(%rsp), %rax
     8b8:      	movl	0x9c(%rsp), %r12d
     8c0:      	subq	%r15, %rax
     8c3:      	movl	0x90(%rsp), %r13d
     8cb:      	movl	%r12d, %edx
     8ce:      	subl	%r13d, %edx
     8d1:      	movl	$0x0, %ecx
     8d6:      	cmovbl	%ecx, %edx
     8d9:      	addq	0xa0(%rsp), %rdx
     8e1:      	xorl	%esi, %esi
     8e3:      	cmpl	%r12d, %r13d
     8e6:      	seta	%sil
     8ea:      	movl	%r12d, %ecx
     8ed:      	cmovbl	%r13d, %ecx
     8f1:      	addl	%ecx, %esi
     8f3:      	movl	%r13d, %edi
     8f6:      	subl	%esi, %edi
     8f8:      	movl	%edi, 0x90(%rsp)
     8ff:      	subq	%rsi, %rax
     902:      	movq	0x28(%rsp), %rbx
     907:      	jb	0xd53 <generic_tracepoint_process_event+0xd53>
     90d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     913:      	ja	0xd53 <generic_tracepoint_process_event+0xd53>
     919:      	cmpl	%r12d, %r13d
     91c:      	jbe	0x923 <generic_tracepoint_process_event+0x923>
     91e:      	movb	$0x2f, (%r15,%rax)
     923:      	xorl	%edi, %edi
     925:      	cmpl	%r12d, %r13d
     928:      	seta	%dil
     92c:      	movzbl	%cl, %esi
     92f:      	addq	%rax, %r15
     932:      	addq	%r15, %rdi
     935:      	movl	$0x4, %eax
     93a:      	callq	*%rax
     93c:      	movq	%r15, 0x88(%rsp)
     944:      	cmpl	%r12d, %r13d
     947:      	jbe	0xd53 <generic_tracepoint_process_event+0xd53>
     94d:      	movq	0x38(%rsp), %rax
     952:      	movq	%rax, 0x70(%rsp)
     957:      	movl	$0x8, %r15d
     95d:      	decl	%ebp
     95f:      	jne	0x808 <generic_tracepoint_process_event+0x808>
     965:      	jmp	0xd53 <generic_tracepoint_process_event+0xd53>
     96a:      	leaq	0x10(%r13), %rdx
     96e:      	movl	$0x4, %eax
     973:      	leaq	0x40(%rsp), %rdi
     978:      	movl	$0x8, %esi
     97d:      	callq	*%rax
     97f:      	movq	0x80(%rsp), %rax
     987:      	cmpq	0x40(%rsp), %rax
     98c:      	movl	$0x8, %r15d
     992:      	je	0xd46 <generic_tracepoint_process_event+0xd46>
     998:      	addq	$0x18, %r13
     99c:      	movl	$0x4, %eax
     9a1:      	leaq	0x70(%rsp), %rdi
     9a6:      	movl	$0x8, %esi
     9ab:      	movq	%r13, %rdx
     9ae:      	callq	*%rax
     9b0:      	movq	0x40(%rsp), %rax
     9b5:      	movq	%rax, 0x80(%rsp)
     9bd:      	addq	$0x20, %rax
     9c1:      	movq	%rax, 0x78(%rsp)
     9c6:      	movq	0x28(%rsp), %rbx
     9cb:      	decl	%ebp
     9cd:      	jne	0x808 <generic_tracepoint_process_event+0x808>
     9d3:      	jmp	0xd53 <generic_tracepoint_process_event+0xd53>
     9d8:      	movl	$0x800, %ebp            # imm = 0x800
     9dd:      	movl	$0x8, %r15d
     9e3:      	movq	0x70(%rsp), %r12
     9e8:      	movq	0x78(%rsp), %rdx
     9ed:      	movq	0x80(%rsp), %r13
     9f5:      	cmpq	0x58(%rsp), %r12
     9fa:      	jne	0xa07 <generic_tracepoint_process_event+0xa07>
     9fc:      	cmpq	0x60(%rsp), %rdx
     a01:      	je	0xd25 <generic_tracepoint_process_event+0xd25>
     a07:      	movl	$0x4, %eax
     a0c:      	leaq	0xc8(%rsp), %rdi
     a14:      	movl	$0x8, %esi
     a19:      	callq	*%rax
     a1b:      	cmpq	0xc8(%rsp), %r12
     a23:      	movl	$0x8, %ecx
     a28:      	je	0xb45 <generic_tracepoint_process_event+0xb45>
     a2e:      	leaq	0x18(%r12), %r15
     a33:      	movl	$0x4, %eax
     a38:      	leaq	0x40(%rsp), %rdi
     a3d:      	movl	$0x8, %esi
     a42:      	movq	%r15, %rdx
     a45:      	callq	*%rax
     a47:      	movl	$0x8, %ecx
     a4c:      	cmpq	%r12, 0x40(%rsp)
     a51:      	je	0xb45 <generic_tracepoint_process_event+0xb45>
     a57:      	movl	$0x4, %eax
     a5c:      	leaq	0x38(%rsp), %rdi
     a61:      	movl	$0x8, %esi
     a66:      	movq	%r15, %rdx
     a69:      	callq	*%rax
     a6b:      	addq	$0x20, %r12
     a6f:      	movl	$0x4, %eax
     a74:      	leaq	0x98(%rsp), %rdi
     a7c:      	movl	$0x10, %ecx
     a81:      	movl	$0x10, %esi
     a86:      	movq	%r12, %rdx
     a89:      	callq	*%rax
     a8b:      	movq	0x68(%rsp), %r15
     a90:      	movq	0x88(%rsp), %rax
     a98:      	movl	0x9c(%rsp), %r12d
     aa0:      	subq	%r15, %rax
     aa3:      	movl	0x90(%rsp), %r13d
     aab:      	movl	%r12d, %edx
     aae:      	subl	%r13d, %edx
     ab1:      	movl	$0x0, %ecx
     ab6:      	cmovbl	%ecx, %edx
     ab9:      	addq	0xa0(%rsp), %rdx
     ac1:      	xorl	%esi, %esi
     ac3:      	cmpl	%r12d, %r13d
     ac6:      	seta	%sil
     aca:      	movl	%r12d, %ecx
     acd:      	cmovbl	%r13d, %ecx
     ad1:      	addl	%ecx, %esi
     ad3:      	movl	%r13d, %edi
     ad6:      	subl	%esi, %edi
     ad8:      	movl	%edi, 0x90(%rsp)
     adf:      	subq	%rsi, %rax
     ae2:      	jb	0xd53 <generic_tracepoint_process_event+0xd53>
     ae8:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     aee:      	ja	0xd53 <generic_tracepoint_process_event+0xd53>
     af4:      	cmpl	%r12d, %r13d
     af7:      	jbe	0xafe <generic_tracepoint_process_event+0xafe>
     af9:      	movb	$0x2f, (%r15,%rax)
     afe:      	xorl	%edi, %edi
     b00:      	cmpl	%r12d, %r13d
     b03:      	seta	%dil
     b07:      	movzbl	%cl, %esi
     b0a:      	addq	%rax, %r15
     b0d:      	addq	%r15, %rdi
     b10:      	movl	$0x4, %eax
     b15:      	callq	*%rax
     b17:      	movq	%r15, 0x88(%rsp)
     b1f:      	cmpl	%r12d, %r13d
     b22:      	jbe	0xd53 <generic_tracepoint_process_event+0xd53>
     b28:      	movq	0x38(%rsp), %rax
     b2d:      	movq	%rax, 0x70(%rsp)
     b32:      	movl	$0x8, %r15d
     b38:      	decl	%ebp
     b3a:      	jne	0x9e3 <generic_tracepoint_process_event+0x9e3>
     b40:      	jmp	0xd53 <generic_tracepoint_process_event+0xd53>
     b45:      	leaq	0x10(%r13), %rdx
     b49:      	movl	$0x4, %eax
     b4e:      	leaq	0x40(%rsp), %rdi
     b53:      	movl	$0x8, %esi
     b58:      	callq	*%rax
     b5a:      	movq	0x80(%rsp), %rax
     b62:      	cmpq	0x40(%rsp), %rax
     b67:      	movl	$0x8, %r15d
     b6d:      	je	0xd25 <generic_tracepoint_process_event+0xd25>
     b73:      	addq	$0x18, %r13
     b77:      	movl	$0x4, %eax
     b7c:      	leaq	0x70(%rsp), %rdi
     b81:      	movl	$0x8, %esi
     b86:      	movq	%r13, %rdx
     b89:      	callq	*%rax
     b8b:      	movq	0x40(%rsp), %rax
     b90:      	movq	%rax, 0x80(%rsp)
     b98:      	addq	$0x20, %rax
     b9c:      	movq	%rax, 0x78(%rsp)
     ba1:      	decl	%ebp
     ba3:      	jne	0x9e3 <generic_tracepoint_process_event+0x9e3>
     ba9:      	jmp	0xd53 <generic_tracepoint_process_event+0xd53>
     bae:      	leaq	0x98(%rsp), %rdi
     bb6:      	leaq	0x58(%rsp), %rdx
     bbb:      	movl	$0x8, %ecx
     bc0:      	movl	$0x4, %eax
     bc5:      	movl	$0x8, %esi
     bca:      	callq	*%rax
     bcc:      	movq	0x98(%rsp), %rbp
     bd4:      	testq	%rbp, %rbp
     bd7:      	jne	0x5d4 <generic_tracepoint_process_event+0x5d4>
     bdd:      	movl	$0x0, 0xd0(%rsp)
     be8:      	movq	(%rip), %rdi            # 0xbef <generic_tracepoint_process_event+0xbef>
     bef:      	leaq	0xd0(%rsp), %rsi
     bf7:      	movl	$0x1, %eax
     bfc:      	callq	*%rax
     bfe:      	testq	%rax, %rax
     c01:      	je	0xfdf <generic_tracepoint_process_event+0xfdf>
     c07:      	movq	%r15, 0x30(%rsp)
     c0c:      	xorl	%r15d, %r15d
     c0f:      	cmpl	$0x19, %r13d
     c13:      	jg	0x109c <generic_tracepoint_process_event+0x109c>
     c19:      	cmpl	$0x12, %r13d
     c1d:      	jle	0x1211 <generic_tracepoint_process_event+0x1211>
     c23:      	cmpl	$0x14, %r13d
     c27:      	jle	0x157f <generic_tracepoint_process_event+0x157f>
     c2d:      	cmpl	$0x15, %r13d
     c31:      	je	0x1dcf <generic_tracepoint_process_event+0x1dcf>
     c37:      	cmpl	$0x16, %r13d
     c3b:      	je	0x1d42 <generic_tracepoint_process_event+0x1d42>
     c41:      	cmpl	$0x17, %r13d
     c45:      	movq	0x18(%rsp), %rcx
     c4a:      	movq	0x8(%rsp), %r9
     c4f:      	movq	0x20(%rsp), %rdx
     c54:      	jne	0x1f6c <generic_tracepoint_process_event+0x1f6c>
     c5a:      	movq	0x10(%rsp), %rax
     c5f:      	movl	$0x0, 0x4(%rax)
     c66:      	movl	%edx, (%rax)
     c68:      	movl	$0x8, %r15d
     c6e:      	jmp	0x1f6c <generic_tracepoint_process_event+0x1f6c>
     c73:      	cmpl	$0x2c, %r13d
     c77:      	ja	0xbdd <generic_tracepoint_process_event+0xbdd>
     c7d:      	movl	%r13d, %eax
     c80:      	movabsq	$0x11c1f2027cf2, %rcx   # imm = 0x11C1F2027CF2
     c8a:      	btq	%rax, %rcx
     c8e:      	jae	0xbdd <generic_tracepoint_process_event+0xbdd>
     c94:      	movq	%rdx, 0x38(%rsp)
     c99:      	movl	$0x0, 0xc8(%rsp)
     ca4:      	movq	(%rip), %rdi            # 0xcab <generic_tracepoint_process_event+0xcab>
     cab:      	leaq	0xc8(%rsp), %rsi
     cb3:      	movl	$0x1, %eax
     cb8:      	callq	*%rax
     cba:      	testq	%rax, %rax
     cbd:      	je	0xd2f <generic_tracepoint_process_event+0xd2f>
     cbf:      	movq	%r15, 0x30(%rsp)
     cc4:      	xorl	%r15d, %r15d
     cc7:      	cmpl	$0x10, %r13d
     ccb:      	movq	0x18(%rsp), %rcx
     cd0:      	jle	0xe6d <generic_tracepoint_process_event+0xe6d>
     cd6:      	cmpl	$0x1e, %r13d
     cda:      	movq	0x50(%rsp), %rbp
     cdf:      	movq	0x10(%rsp), %r12
     ce4:      	jle	0xfe7 <generic_tracepoint_process_event+0xfe7>
     cea:      	cmpl	$0x26, %r13d
     cee:      	jg	0x10dc <generic_tracepoint_process_event+0x10dc>
     cf4:      	leal	-0x1f(%r13), %eax
     cf8:      	cmpl	$0x2, %eax
     cfb:      	jae	0x1667 <generic_tracepoint_process_event+0x1667>
     d01:      	leaq	0x38(%rsp), %rdx
     d06:      	movl	$0x4, %r15d
     d0c:      	movl	$0x1, %ecx
     d11:      	movl	$0x4, %eax
     d16:      	movq	%r12, %rdi
     d19:      	movl	$0x1, %esi
     d1e:      	callq	*%rax
     d20:      	jmp	0x249e <generic_tracepoint_process_event+0x249e>
     d25:      	movb	$0x1, 0x94(%rsp)
     d2d:      	jmp	0xd53 <generic_tracepoint_process_event+0xd53>
     d2f:      	xorl	%r15d, %r15d
     d32:      	movq	0x18(%rsp), %rcx
     d37:      	movq	0x50(%rsp), %rbp
     d3c:      	movq	0x8(%rsp), %r9
     d41:      	jmp	0x3333 <generic_tracepoint_process_event+0x3333>
     d46:      	movb	$0x1, 0x94(%rsp)
     d4e:      	movq	0x28(%rsp), %rbx
     d53:      	movq	0x88(%rsp), %rax
     d5b:      	movq	0x20(%rsp), %rdx
     d60:      	xorl	%ebp, %ebp
     d62:      	cmpq	%rdx, %rax
     d65:      	je	0xda3 <generic_tracepoint_process_event+0xda3>
     d67:      	cmpb	$0x0, 0x94(%rsp)
     d6f:      	sete	%cl
     d72:      	movl	0x90(%rsp), %edx
     d79:      	movl	$0x1000, %r15d          # imm = 0x1000
     d7f:      	subl	%edx, %r15d
     d82:      	testl	%edx, %edx
     d84:      	cmovlel	%edx, %r15d
     d88:      	testq	%rax, %rax
     d8b:      	movq	0xb0(%rsp), %r12
     d93:      	je	0xe60 <generic_tracepoint_process_event+0xe60>
     d99:      	movb	%cl, %bpl
     d9c:      	addl	%ebp, %ebp
     d9e:      	movq	%rax, %rdx
     da1:      	jmp	0xdae <generic_tracepoint_process_event+0xdae>
     da3:      	xorl	%r15d, %r15d
     da6:      	movq	0xb0(%rsp), %r12
     dae:      	movq	0x10(%rsp), %r13
     db3:      	leaq	0x4(%r13), %rdi
     db7:      	andl	$0xfff, %r15d           # imm = 0xFFF
     dbe:      	movl	$0x4, %eax
     dc3:      	movl	%r15d, %esi
     dc6:      	callq	*%rax
     dc8:      	movl	%r15d, (%r13)
     dcc:      	leaq	0x58(%rsp), %rdi
     dd1:      	movl	$0x8, %ecx
     dd6:      	movl	$0x4, %eax
     ddb:      	movq	0x30(%rsp), %rdx
     de0:      	movl	$0x8, %esi
     de5:      	callq	*%rax
     de7:      	movq	0x58(%rsp), %rcx
     dec:      	addq	$0x30, %rcx
     df0:      	leaq	0x98(%rsp), %rdi
     df8:      	movl	$0x8, %edx
     dfd:      	movl	$0x4, %eax
     e02:      	movq	0x58(%rsp), %rdx
     e07:      	addq	$0x30, %rdx
     e0b:      	movl	$0x8, %esi
     e10:      	callq	*%rax
     e12:      	movq	0x98(%rsp), %rcx
     e1a:      	leaq	0x40(%rsp), %rdi
     e1f:      	movl	$0x2, %edx
     e24:      	movl	$0x4, %eax
     e29:      	movq	0x98(%rsp), %rdx
     e31:      	movl	$0x2, %esi
     e36:      	callq	*%rax
     e38:      	movl	%ebp, 0x4(%r13,%r15)
     e3d:      	movzwl	0x40(%rsp), %eax
     e42:      	movw	%ax, 0x8(%r13,%r15)
     e48:      	addl	$0xa, %r15d
     e4c:      	movq	0x18(%rsp), %rcx
     e51:      	movq	0x50(%rsp), %rbp
     e56:      	movq	0x8(%rsp), %r9
     e5b:      	jmp	0x333b <generic_tracepoint_process_event+0x333b>
     e60:      	xorl	%r15d, %r15d
     e63:      	movq	0x50(%rsp), %rbp
     e68:      	jmp	0x3340 <generic_tracepoint_process_event+0x3340>
     e6d:      	cmpl	$0x9, %r13d
     e71:      	movq	0x50(%rsp), %rbp
     e76:      	movq	0x8(%rsp), %r9
     e7b:      	movq	0x10(%rsp), %r12
     e80:      	jg	0x101e <generic_tracepoint_process_event+0x101e>
     e86:      	cmpl	$0x4, %r13d
     e8a:      	jle	0x12a1 <generic_tracepoint_process_event+0x12a1>
     e90:      	cmpl	$0x5, %r13d
     e94:      	je	0x185a <generic_tracepoint_process_event+0x185a>
     e9a:      	cmpl	$0x6, %r13d
     e9e:      	je	0x107e <generic_tracepoint_process_event+0x107e>
     ea4:      	movq	%rax, 0x20(%rsp)
     ea9:      	cmpl	$0x7, %r13d
     ead:      	movq	0x18(%rsp), %rcx
     eb2:      	movq	0x8(%rsp), %r9
     eb7:      	jne	0x3333 <generic_tracepoint_process_event+0x3333>
     ebd:      	movq	0x38(%rsp), %r15
     ec2:      	movq	%r15, 0x28(%r12)
     ec7:      	leaq	0x26(%r12), %rdi
     ecc:      	leaq	0x10(%r15), %rdx
     ed0:      	movl	$0x2, %ecx
     ed5:      	movl	$0x4, %eax
     eda:      	movl	$0x2, %esi
     edf:      	callq	*%rax
     ee1:      	leaq	0x3a(%r12), %rdi
     ee6:      	leaq	0x12(%r15), %rdx
     eea:      	movl	$0x1, %ecx
     eef:      	movl	$0x4, %eax
     ef4:      	movl	$0x1, %esi
     ef9:      	callq	*%rax
     efb:      	leaq	0x38(%r12), %rdi
     f00:      	leaq	0x226(%r15), %rdx
     f07:      	movl	$0x2, %ecx
     f0c:      	movl	$0x4, %eax
     f11:      	movl	$0x2, %esi
     f16:      	callq	*%rax
     f18:      	leaq	0x24(%r12), %rdi
     f1d:      	leaq	0x224(%r15), %rdx
     f24:      	movl	$0x2, %ecx
     f29:      	movl	$0x4, %eax
     f2e:      	movl	$0x2, %esi
     f33:      	callq	*%rax
     f35:      	leaq	0x30(%r12), %rdi
     f3a:      	leaq	0x21c(%r15), %rdx
     f41:      	movl	$0x4, %ecx
     f46:      	movl	$0x4, %eax
     f4b:      	movl	$0x4, %esi
     f50:      	callq	*%rax
     f52:      	leaq	0x34(%r12), %rdi
     f57:      	leaq	0x218(%r15), %rdx
     f5e:      	movl	$0x4, %ecx
     f63:      	movl	$0x4, %eax
     f68:      	movl	$0x4, %esi
     f6d:      	callq	*%rax
     f6f:      	movq	%r12, %rax
     f72:      	addq	$0x10, %r12
     f76:      	movq	$0x0, (%rax)
     f7d:      	movq	$0x0, 0x8(%rax)
     f85:      	movq	$0x0, 0x10(%rax)
     f8d:      	movq	$0x0, 0x18(%rax)
     f95:      	movzwl	0x26(%rax), %eax
     f99:      	cmpl	$0xa, %eax
     f9c:      	je	0x2147 <generic_tracepoint_process_event+0x2147>
     fa2:      	cmpl	$0x2, %eax
     fa5:      	jne	0x2179 <generic_tracepoint_process_event+0x2179>
     fab:      	leaq	0x4(%r15), %rdx
     faf:      	movl	$0x4, %ecx
     fb4:      	movl	$0x4, %eax
     fb9:      	movq	0x10(%rsp), %rdi
     fbe:      	movl	$0x4, %esi
     fc3:      	callq	*%rax
     fc5:      	movl	$0x4, %ecx
     fca:      	movl	$0x4, %eax
     fcf:      	movq	%r12, %rdi
     fd2:      	movl	$0x4, %esi
     fd7:      	movq	%r15, %rdx
     fda:      	jmp	0x2177 <generic_tracepoint_process_event+0x2177>
     fdf:      	xorl	%r15d, %r15d
     fe2:      	jmp	0x1f62 <generic_tracepoint_process_event+0x1f62>
     fe7:      	cmpl	$0x1c, %r13d
     feb:      	jg	0x127d <generic_tracepoint_process_event+0x127d>
     ff1:      	cmpl	$0x11, %r13d
     ff5:      	je	0x169b <generic_tracepoint_process_event+0x169b>
     ffb:      	cmpl	$0x19, %r13d
     fff:      	je	0x175f <generic_tracepoint_process_event+0x175f>
    1005:      	cmpl	$0x1c, %r13d
    1009:      	movq	0x50(%rsp), %rbp
    100e:      	movq	0x8(%rsp), %r9
    1013:      	je	0x12b1 <generic_tracepoint_process_event+0x12b1>
    1019:      	jmp	0x3333 <generic_tracepoint_process_event+0x3333>
    101e:      	leal	-0xa(%r13), %eax
    1022:      	cmpl	$0x2, %eax
    1025:      	jb	0x12b1 <generic_tracepoint_process_event+0x12b1>
    102b:      	leal	-0xc(%r13), %eax
    102f:      	cmpl	$0x2, %eax
    1032:      	jb	0x12d0 <generic_tracepoint_process_event+0x12d0>
    1038:      	cmpl	$0xe, %r13d
    103c:      	jne	0x3333 <generic_tracepoint_process_event+0x3333>
    1042:      	leaq	0x58(%rsp), %rdi
    1047:      	leaq	0x38(%rsp), %r15
    104c:      	movl	$0x8, %ecx
    1051:      	movl	$0x4, %eax
    1056:      	movl	$0x8, %esi
    105b:      	movq	%r15, %rdx
    105e:      	callq	*%rax
    1060:      	movq	0x58(%rsp), %rcx
    1065:      	movl	$0x8, %edx
    106a:      	movl	$0x4, %eax
    106f:      	movq	0x58(%rsp), %rdx
    1074:      	movq	%r15, %rdi
    1077:      	movl	$0x8, %esi
    107c:      	callq	*%rax
    107e:      	movq	0x38(%rsp), %rdx
    1083:      	leaq	0x4(%r12), %rdi
    1088:      	movl	$0x1001, %ecx           # imm = 0x1001
    108d:      	movl	$0x2d, %eax
    1092:      	movl	$0x1001, %esi           # imm = 0x1001
    1097:      	jmp	0x1a35 <generic_tracepoint_process_event+0x1a35>
    109c:      	cmpl	$0x20, %r13d
    10a0:      	movq	0x20(%rsp), %r8
    10a5:      	jle	0x1464 <generic_tracepoint_process_event+0x1464>
    10ab:      	leal	-0x21(%r13), %ecx
    10af:      	cmpl	$0x4, %ecx
    10b2:      	movq	0x10(%rsp), %rdi
    10b7:      	jae	0x12fe <generic_tracepoint_process_event+0x12fe>
    10bd:      	movl	$0x8, %r15d
    10c3:      	movl	$0x8, %ecx
    10c8:      	movl	$0x4, %eax
    10cd:      	movl	$0x8, %esi
    10d2:      	movq	%r8, %rdx
    10d5:      	callq	*%rax
    10d7:      	jmp	0x1f62 <generic_tracepoint_process_event+0x1f62>
    10dc:      	cmpl	$0x27, %r13d
    10e0:      	je	0x1a17 <generic_tracepoint_process_event+0x1a17>
    10e6:      	cmpl	$0x28, %r13d
    10ea:      	je	0x1a54 <generic_tracepoint_process_event+0x1a54>
    10f0:      	cmpl	$0x2c, %r13d
    10f4:      	movq	0x8(%rsp), %r9
    10f9:      	jne	0x3333 <generic_tracepoint_process_event+0x3333>
    10ff:      	movq	0x38(%rsp), %r15
    1104:      	movb	$0x0, 0x58(%rsp)
    1109:      	movq	$0x0, 0x68(%r12)
    1112:      	movq	$0x0, 0x60(%r12)
    111b:      	movq	$0x0, 0x58(%r12)
    1124:      	movq	$0x0, 0x50(%r12)
    112d:      	movq	$0x0, 0x48(%r12)
    1136:      	movq	$0x0, 0x40(%r12)
    113f:      	movq	$0x0, 0x38(%r12)
    1148:      	movq	$0x0, 0x30(%r12)
    1151:      	movq	$0x0, 0x28(%r12)
    115a:      	movq	$0x0, 0x20(%r12)
    1163:      	movq	$0x0, 0x18(%r12)
    116c:      	movq	$0x0, 0x10(%r12)
    1175:      	movq	$0x0, 0x8(%r12)
    117e:      	movq	$0x0, (%r12)
    1186:      	movl	$0x2, %ecx
    118b:      	movl	$0x4, %eax
    1190:      	movq	%r12, %rdi
    1193:      	movl	$0x2, %esi
    1198:      	movq	%r15, %rdx
    119b:      	callq	*%rax
    119d:      	testq	%rax, %rax
    11a0:      	js	0x2498 <generic_tracepoint_process_event+0x2498>
    11a6:      	leaq	0x2(%r15), %r12
    11aa:      	leaq	0x58(%rsp), %rdi
    11af:      	movl	$0x1, %ecx
    11b4:      	movl	$0x4, %eax
    11b9:      	movl	$0x1, %esi
    11be:      	movq	%r12, %rdx
    11c1:      	callq	*%rax
    11c3:      	testq	%rax, %rax
    11c6:      	js	0x2498 <generic_tracepoint_process_event+0x2498>
    11cc:      	movq	0x10(%rsp), %rax
    11d1:      	leaq	0x4(%rax), %rdi
    11d5:      	cmpb	$0x0, 0x58(%rsp)
    11da:      	sete	0x2(%rax)
    11de:      	je	0x2465 <generic_tracepoint_process_event+0x2465>
    11e4:      	movl	$0x6c, %ecx
    11e9:      	movl	$0x2d, %eax
    11ee:      	movl	$0x6c, %esi
    11f3:      	movq	%r12, %rdx
    11f6:      	callq	*%rax
    11f8:      	testl	%eax, %eax
    11fa:      	movq	0x50(%rsp), %rbp
    11ff:      	movq	0x28(%rsp), %rbx
    1204:      	js	0x2498 <generic_tracepoint_process_event+0x2498>
    120a:      	decb	%al
    120c:      	jmp	0x2490 <generic_tracepoint_process_event+0x2490>
    1211:      	movl	%r12d, %esi
    1214:      	cmpl	$0x7, %r13d
    1218:      	jg	0x152f <generic_tracepoint_process_event+0x152f>
    121e:      	cmpl	$0x2, %r13d
    1222:      	je	0x1ae8 <generic_tracepoint_process_event+0x1ae8>
    1228:      	cmpl	$0x3, %r13d
    122c:      	movq	0x18(%rsp), %rcx
    1231:      	movq	0x8(%rsp), %r9
    1236:      	jne	0x1f6c <generic_tracepoint_process_event+0x1f6c>
    123c:      	movq	%rax, %rbp
    123f:      	leaq	0x90(%rax), %r13
    1246:      	movl	%esi, %eax
    1248:      	andl	$0xf, %eax
    124b:      	cmpl	$0x2, %eax
    124e:      	jle	0x22ea <generic_tracepoint_process_event+0x22ea>
    1254:      	cmpl	$0x3, %eax
    1257:      	je	0x2592 <generic_tracepoint_process_event+0x2592>
    125d:      	cmpl	$0x4, %eax
    1260:      	je	0x259d <generic_tracepoint_process_event+0x259d>
    1266:      	cmpl	$0x5, %eax
    1269:      	jne	0x29c0 <generic_tracepoint_process_event+0x29c0>
    126f:      	movq	%rbp, %rax
    1272:      	addq	$0x5e70, %rax           # imm = 0x5E70
    1278:      	jmp	0x25b1 <generic_tracepoint_process_event+0x25b1>
    127d:      	leaq	0x38(%rsp), %rdx
    1282:      	movl	$0x4, %r15d
    1288:      	movl	$0x2, %ecx
    128d:      	movl	$0x4, %eax
    1292:      	movq	%r12, %rdi
    1295:      	movl	$0x2, %esi
    129a:      	callq	*%rax
    129c:      	jmp	0x249e <generic_tracepoint_process_event+0x249e>
    12a1:      	cmpl	$0x1, %r13d
    12a5:      	je	0x12d0 <generic_tracepoint_process_event+0x12d0>
    12a7:      	cmpl	$0x4, %r13d
    12ab:      	jne	0x3333 <generic_tracepoint_process_event+0x3333>
    12b1:      	movl	$0x8, %r15d
    12b7:      	leaq	0x38(%rsp), %rdx
    12bc:      	movl	$0x8, %ecx
    12c1:      	movl	$0x4, %eax
    12c6:      	movq	%r12, %rdi
    12c9:      	movl	$0x8, %esi
    12ce:      	jmp	0x12ed <generic_tracepoint_process_event+0x12ed>
    12d0:      	leaq	0x38(%rsp), %rdx
    12d5:      	movl	$0x4, %r15d
    12db:      	movl	$0x4, %ecx
    12e0:      	movl	$0x4, %eax
    12e5:      	movq	%r12, %rdi
    12e8:      	movl	$0x4, %esi
    12ed:      	callq	*%rax
    12ef:      	movq	0x8(%rsp), %r9
    12f4:      	movq	0x18(%rsp), %rcx
    12f9:      	jmp	0x3333 <generic_tracepoint_process_event+0x3333>
    12fe:      	movq	%rax, 0x30(%rsp)
    1303:      	cmpl	$0x2b, %r13d
    1307:      	je	0x1ec7 <generic_tracepoint_process_event+0x1ec7>
    130d:      	cmpl	$0x29, %r13d
    1311:      	movq	0x18(%rsp), %rcx
    1316:      	movq	0x8(%rsp), %r9
    131b:      	jne	0x1f6c <generic_tracepoint_process_event+0x1f6c>
    1321:      	movq	%rcx, %r13
    1324:      	addq	$0x18, %r8
    1328:      	leaq	0x58(%rsp), %rdi
    132d:      	movl	$0x4, %r12d
    1333:      	movl	$0x8, %ecx
    1338:      	movl	$0x4, %eax
    133d:      	movl	$0x8, %esi
    1342:      	movq	%r8, %rdx
    1345:      	callq	*%rax
    1347:      	movq	0x58(%rsp), %r15
    134c:      	testq	%r15, %r15
    134f:      	je	0x2546 <generic_tracepoint_process_event+0x2546>
    1355:      	movq	0x10(%rsp), %rbp
    135a:      	movq	%r15, 0x28(%rbp)
    135e:      	leaq	0x26(%rbp), %rdi
    1362:      	leaq	0x10(%r15), %rdx
    1366:      	movl	$0x2, %ecx
    136b:      	movl	$0x4, %eax
    1370:      	movl	$0x2, %esi
    1375:      	callq	*%rax
    1377:      	leaq	0x3a(%rbp), %rdi
    137b:      	leaq	0x12(%r15), %rdx
    137f:      	movl	$0x1, %ecx
    1384:      	movl	$0x4, %eax
    1389:      	movl	$0x1, %esi
    138e:      	callq	*%rax
    1390:      	leaq	0x38(%rbp), %rdi
    1394:      	leaq	0x226(%r15), %rdx
    139b:      	movl	$0x2, %ecx
    13a0:      	movl	$0x4, %eax
    13a5:      	movl	$0x2, %esi
    13aa:      	callq	*%rax
    13ac:      	leaq	0x24(%rbp), %rdi
    13b0:      	leaq	0x224(%r15), %rdx
    13b7:      	movl	$0x2, %ecx
    13bc:      	movl	$0x4, %eax
    13c1:      	movl	$0x2, %esi
    13c6:      	callq	*%rax
    13c8:      	leaq	0x30(%rbp), %rdi
    13cc:      	leaq	0x21c(%r15), %rdx
    13d3:      	movl	$0x4, %eax
    13d8:      	movl	$0x4, %esi
    13dd:      	callq	*%rax
    13df:      	leaq	0x34(%rbp), %rdi
    13e3:      	leaq	0x218(%r15), %rdx
    13ea:      	movl	$0x4, %eax
    13ef:      	movl	$0x4, %esi
    13f4:      	callq	*%rax
    13f6:      	leaq	0x10(%rbp), %r12
    13fa:      	movq	$0x0, (%rbp)
    1402:      	movq	$0x0, 0x8(%rbp)
    140a:      	movq	$0x0, 0x10(%rbp)
    1412:      	movq	$0x0, 0x18(%rbp)
    141a:      	movzwl	0x26(%rbp), %eax
    141e:      	cmpl	$0xa, %eax
    1421:      	je	0x24cd <generic_tracepoint_process_event+0x24cd>
    1427:      	cmpl	$0x2, %eax
    142a:      	jne	0x24ff <generic_tracepoint_process_event+0x24ff>
    1430:      	leaq	0x4(%r15), %rdx
    1434:      	movl	$0x4, %ecx
    1439:      	movl	$0x4, %eax
    143e:      	movq	0x10(%rsp), %rdi
    1443:      	movl	$0x4, %esi
    1448:      	callq	*%rax
    144a:      	movl	$0x4, %ecx
    144f:      	movl	$0x4, %eax
    1454:      	movq	%r12, %rdi
    1457:      	movl	$0x4, %esi
    145c:      	movq	%r15, %rdx
    145f:      	jmp	0x24fd <generic_tracepoint_process_event+0x24fd>
    1464:      	cmpl	$0x1a, %r13d
    1468:      	je	0x1f76 <generic_tracepoint_process_event+0x1f76>
    146e:      	cmpl	$0x1b, %r13d
    1472:      	movq	0x18(%rsp), %rcx
    1477:      	movq	0x8(%rsp), %r9
    147c:      	jne	0x1f6c <generic_tracepoint_process_event+0x1f6c>
    1482:      	movq	%r9, %r13
    1485:      	movq	%rcx, %r12
    1488:      	movq	0x10(%rsp), %rax
    148d:      	movq	$0x0, 0x48(%rax)
    1495:      	movq	$0x0, 0x40(%rax)
    149d:      	movq	$0x0, 0x38(%rax)
    14a5:      	movq	$0x0, 0x30(%rax)
    14ad:      	movq	$0x0, 0x28(%rax)
    14b5:      	movq	$0x0, 0x20(%rax)
    14bd:      	movq	$0x0, 0x18(%rax)
    14c5:      	movq	$0x0, 0x10(%rax)
    14cd:      	movq	$0x0, 0x8(%rax)
    14d5:      	movq	$0x0, (%rax)
    14dc:      	leaq	0x10(%rax), %rdi
    14e0:      	leaq	0x18(%r8), %rdx
    14e4:      	movl	$0x3f, %ecx
    14e9:      	movl	$0x2d, %eax
    14ee:      	movl	$0x3f, %esi
    14f3:      	callq	*%rax
    14f5:      	testq	%rax, %rax
    14f8:      	js	0x2433 <generic_tracepoint_process_event+0x2433>
    14fe:      	movq	0x10(%rsp), %rdi
    1503:      	addq	$0x8, %rdi
    1507:      	movq	0x20(%rsp), %rdx
    150c:      	addq	$0x348, %rdx            # imm = 0x348
    1513:      	movl	$0x8, %ecx
    1518:      	movl	$0x4, %eax
    151d:      	movl	$0x8, %esi
    1522:      	callq	*%rax
    1524:      	movl	$0x50, %r15d
    152a:      	jmp	0x2436 <generic_tracepoint_process_event+0x2436>
    152f:      	cmpl	$0x8, %r13d
    1533:      	je	0x1b4b <generic_tracepoint_process_event+0x1b4b>
    1539:      	cmpl	$0x12, %r13d
    153d:      	movq	0x18(%rsp), %rcx
    1542:      	movq	0x8(%rsp), %r9
    1547:      	movq	0x20(%rsp), %rdx
    154c:      	jne	0x1f6c <generic_tracepoint_process_event+0x1f6c>
    1552:      	movq	%rsi, %r13
    1555:      	andl	$0x3ff, %r13d           # imm = 0x3FF
    155c:      	movq	%rcx, %r15
    155f:      	movl	$0x4, %eax
    1564:      	movq	0x10(%rsp), %rdi
    1569:      	movl	%r13d, %esi
    156c:      	movq	%r9, %r12
    156f:      	callq	*%rax
    1571:      	movq	%r12, %r9
    1574:      	movq	%r15, %rcx
    1577:      	movq	%r13, %r15
    157a:      	jmp	0x1f6c <generic_tracepoint_process_event+0x1f6c>
    157f:      	cmpl	$0x13, %r13d
    1583:      	je	0x1e6a <generic_tracepoint_process_event+0x1e6a>
    1589:      	cmpl	$0x14, %r13d
    158d:      	movq	0x18(%rsp), %rcx
    1592:      	movq	0x8(%rsp), %r9
    1597:      	movq	0x20(%rsp), %r13
    159c:      	jne	0x1f6c <generic_tracepoint_process_event+0x1f6c>
    15a2:      	movq	$0x0, 0x58(%rsp)
    15ab:      	leaq	0x110(%r13), %rdx
    15b2:      	leaq	0x58(%rsp), %rdi
    15b7:      	movl	$0x8, %esi
    15bc:      	movq	%rcx, %r12
    15bf:      	movl	$0x4, %eax
    15c4:      	leaq	0xd8(%r13), %r15
    15cb:      	movl	$0x8, %esi
    15d0:      	callq	*%rax
    15d2:      	movq	0x58(%rsp), %rcx
    15d7:      	movl	$0x80, %edx
    15dc:      	movl	$0x2d, %eax
    15e1:      	movq	0x10(%rsp), %rbp
    15e6:      	movq	0x58(%rsp), %rdx
    15eb:      	movq	%rbp, %rdi
    15ee:      	movl	$0x80, %esi
    15f3:      	callq	*%rax
    15f5:      	leaq	0x90(%rbp), %rdi
    15fc:      	movl	$0x4, %ecx
    1601:      	movl	$0x4, %eax
    1606:      	movl	$0x4, %esi
    160b:      	movq	%r15, %rdx
    160e:      	callq	*%rax
    1610:      	leaq	0x80(%rbp), %rdi
    1617:      	leaq	0xe0(%r13), %rdx
    161e:      	movl	$0x8, %ecx
    1623:      	movl	$0x4, %eax
    1628:      	movl	$0x8, %esi
    162d:      	callq	*%rax
    162f:      	addq	$0x88, %rbp
    1636:      	addq	$0x118, %r13            # imm = 0x118
    163d:      	movl	$0x8, %ecx
    1642:      	movl	$0x4, %eax
    1647:      	movq	%rbp, %rdi
    164a:      	movl	$0x8, %esi
    164f:      	movq	%r13, %rdx
    1652:      	callq	*%rax
    1654:      	movq	0x8(%rsp), %r9
    1659:      	movq	%r12, %rcx
    165c:      	movl	$0x98, %r15d
    1662:      	jmp	0x1f6c <generic_tracepoint_process_event+0x1f6c>
    1667:      	cmpl	$0x26, %r13d
    166b:      	movq	0x8(%rsp), %r9
    1670:      	jne	0x3333 <generic_tracepoint_process_event+0x3333>
    1676:      	movq	0x38(%rsp), %rsi
    167b:      	movzwl	%si, %edx
    167e:      	addq	%rbx, %rdx
    1681:      	shrl	$0x10, %esi
    1684:      	andl	$0xfff, %esi            # imm = 0xFFF
    168a:      	leaq	0x4(%r12), %rdi
    168f:      	incl	%esi
    1691:      	movl	$0x2d, %eax
    1696:      	jmp	0x1a35 <generic_tracepoint_process_event+0x1a35>
    169b:      	movq	$0x0, 0x60(%rsp)
    16a4:      	movl	$0xe, %eax
    16a9:      	callq	*%rax
    16ab:      	shrq	$0x20, %rax
    16af:      	movq	%rax, 0x58(%rsp)
    16b4:      	leaq	0x98(%rsp), %rdi
    16bc:      	leaq	0x38(%rsp), %rdx
    16c1:      	movl	$0x4, %ecx
    16c6:      	movl	$0x4, %eax
    16cb:      	movl	$0x4, %r13d
    16d1:      	movl	$0x4, %esi
    16d6:      	callq	*%rax
    16d8:      	movl	0x98(%rsp), %eax
    16df:      	movl	%eax, 0x60(%rsp)
    16e3:      	movq	(%rip), %rdi            # 0x16ea <generic_tracepoint_process_event+0x16ea>
    16ea:      	leaq	0x58(%rsp), %rsi
    16ef:      	movl	$0x1, %eax
    16f4:      	callq	*%rax
    16f6:      	testq	%rax, %rax
    16f9:      	je	0x1ff4 <generic_tracepoint_process_event+0x1ff4>
    16ff:      	movl	(%rax), %r15d
    1702:      	leaq	0x98(%rsp), %rdx
    170a:      	movq	%rax, %r12
    170d:      	movl	$0x4, %eax
    1712:      	movq	0x10(%rsp), %rbp
    1717:      	movq	%rbp, %rdi
    171a:      	movl	$0x4, %esi
    171f:      	callq	*%rax
    1721:      	andl	$0xfff, %r15d           # imm = 0xFFF
    1728:      	leaq	0x4(%rbp), %rdi
    172c:      	leaq	0x4(%r15), %rsi
    1730:      	movl	$0x4, %eax
    1735:      	movq	%r12, %rdx
    1738:      	callq	*%rax
    173a:      	leaq	(%r15,%rbp), %rdi
    173e:      	addq	$0x8, %rdi
    1742:      	leaq	(%r15,%r12), %rdx
    1746:      	addq	$0x4, %rdx
    174a:      	movl	$0x4, %eax
    174f:      	movl	$0x4, %esi
    1754:      	callq	*%rax
    1756:      	addq	$0xc, %r15
    175a:      	jmp	0x331f <generic_tracepoint_process_event+0x331f>
    175f:      	movq	%rax, %rbp
    1762:      	movq	0x38(%rsp), %r12
    1767:      	leaq	0xc0(%rsp), %rdi
    176f:      	movl	$0x1, %ecx
    1774:      	movl	$0x4, %eax
    1779:      	movl	$0x1, %esi
    177e:      	movq	%r12, %rdx
    1781:      	callq	*%rax
    1783:      	movzbl	0xc0(%rsp), %eax
    178b:      	testl	%eax, %eax
    178d:      	je	0x2000 <generic_tracepoint_process_event+0x2000>
    1793:      	cmpl	$0x1, %eax
    1796:      	jne	0x2205 <generic_tracepoint_process_event+0x2205>
    179c:      	addq	$0x10, %r12
    17a0:      	leaq	0x58(%rsp), %rdi
    17a5:      	movl	$0x4, %r15d
    17ab:      	movl	$0x8, %ecx
    17b0:      	movl	$0x4, %eax
    17b5:      	movl	$0x8, %esi
    17ba:      	movq	%r12, %rdx
    17bd:      	callq	*%rax
    17bf:      	movq	0x58(%rsp), %rdx
    17c4:      	leaq	0x98(%rsp), %rdi
    17cc:      	movl	$0x8, %ecx
    17d1:      	movl	$0x4, %eax
    17d6:      	movl	$0x8, %esi
    17db:      	callq	*%rax
    17dd:      	movq	0x58(%rsp), %rdx
    17e2:      	addq	$0x8, %rdx
    17e6:      	leaq	0x40(%rsp), %rdi
    17eb:      	movl	$0x8, %ecx
    17f0:      	movl	$0x4, %eax
    17f5:      	movl	$0x8, %esi
    17fa:      	callq	*%rax
    17fc:      	movq	0x98(%rsp), %rdx
    1804:      	movq	0x40(%rsp), %r13
    1809:      	cmpq	$0xfff, %r13            # imm = 0xFFF
    1810:      	movl	$0xfff, %r12d           # imm = 0xFFF
    1816:      	cmovbq	%r13, %r12
    181a:      	movq	0x30(%rsp), %rcx
    181f:      	leaq	(%rcx,%rbp), %rdi
    1823:      	addq	$0x98, %rdi
    182a:      	movl	$0x4, %eax
    182f:      	addq	%rcx, %rbp
    1832:      	addq	$0x90, %rbp
    1839:      	movl	%r12d, %esi
    183c:      	callq	*%rax
    183e:      	testl	%eax, %eax
    1840:      	js	0x2446 <generic_tracepoint_process_event+0x2446>
    1846:      	movl	%r13d, (%rbp)
    184a:      	movl	%r12d, 0x4(%rbp)
    184e:      	addq	$0x8, %r12
    1852:      	movq	%r12, %r15
    1855:      	jmp	0x331f <generic_tracepoint_process_event+0x331f>
    185a:      	movq	%r12, %r15
    185d:      	movq	0x38(%rsp), %r12
    1862:      	leaq	0x28(%r15), %rdi
    1866:      	leaq	0x98(%r12), %rdx
    186e:      	movl	$0x4, %ecx
    1873:      	movl	$0x4, %eax
    1878:      	movl	$0x4, %esi
    187d:      	callq	*%rax
    187f:      	leaq	0x2c(%r15), %rdi
    1883:      	leaq	0x70(%r12), %rdx
    1888:      	movl	$0x4, %ecx
    188d:      	movl	$0x4, %eax
    1892:      	movl	$0x4, %esi
    1897:      	callq	*%rax
    1899:      	leaq	0x30(%r15), %rdi
    189d:      	leaq	0x90(%r12), %rdx
    18a5:      	movl	$0x4, %ecx
    18aa:      	movl	$0x4, %eax
    18af:      	movl	$0x4, %esi
    18b4:      	callq	*%rax
    18b6:      	leaq	0x34(%r15), %rdi
    18ba:      	leaq	0xa8(%r12), %rdx
    18c2:      	movl	$0x4, %ecx
    18c7:      	movl	$0x4, %eax
    18cc:      	movl	$0x4, %esi
    18d1:      	callq	*%rax
    18d3:      	movq	$0x0, 0x58(%rsp)
    18dc:      	leaq	0xc8(%r12), %rdx
    18e4:      	leaq	0x58(%rsp), %rdi
    18e9:      	movl	$0x8, %ecx
    18ee:      	movl	$0x4, %eax
    18f3:      	movl	$0x8, %esi
    18f8:      	callq	*%rax
    18fa:      	leaq	0xb8(%r12), %rdx
    1902:      	leaq	0xc0(%rsp), %rdi
    190a:      	movl	$0x2, %ecx
    190f:      	movl	$0x4, %eax
    1914:      	movl	$0x2, %esi
    1919:      	callq	*%rax
    191b:      	movzwl	0xc0(%rsp), %r15d
    1924:      	addq	0x58(%rsp), %r15
    1929:      	leaq	0xab(%rsp), %rdi
    1931:      	movl	$0x1, %ecx
    1936:      	movl	$0x4, %eax
    193b:      	movl	$0x1, %esi
    1940:      	movq	%r15, %rdx
    1943:      	callq	*%rax
    1945:      	movzbl	0xab(%rsp), %eax
    194d:      	shrl	$0x4, %eax
    1950:      	cmpl	$0x6, %eax
    1953:      	je	0x2097 <generic_tracepoint_process_event+0x2097>
    1959:      	cmpl	$0x4, %eax
    195c:      	jne	0x3319 <generic_tracepoint_process_event+0x3319>
    1962:      	leaq	0x9(%r15), %rdx
    1966:      	leaq	0xac(%rsp), %rdi
    196e:      	movl	$0x1, %ecx
    1973:      	movl	$0x4, %eax
    1978:      	movl	$0x1, %esi
    197d:      	callq	*%rax
    197f:      	movzbl	0xac(%rsp), %eax
    1987:      	movq	0x10(%rsp), %rdi
    198c:      	movw	%ax, 0x24(%rdi)
    1990:      	movw	$0x2, 0x26(%rdi)
    1996:      	leaq	0xc(%r15), %rdx
    199a:      	movq	$0x0, (%rdi)
    19a1:      	movq	$0x0, 0x8(%rdi)
    19a9:      	movq	$0x0, 0x10(%rdi)
    19b1:      	movq	$0x0, 0x18(%rdi)
    19b9:      	movl	$0x4, %ecx
    19be:      	movl	$0x4, %eax
    19c3:      	leaq	0x10(%rdi), %r13
    19c7:      	movl	$0x4, %esi
    19cc:      	callq	*%rax
    19ce:      	addq	$0x10, %r15
    19d2:      	movl	$0x4, %ecx
    19d7:      	movl	$0x4, %eax
    19dc:      	movq	%r13, %rdi
    19df:      	movl	$0x4, %esi
    19e4:      	movq	%r15, %rdx
    19e7:      	callq	*%rax
    19e9:      	leaq	0xb6(%r12), %rdx
    19f1:      	leaq	0xd0(%rsp), %rdi
    19f9:      	movl	$0x2, %ecx
    19fe:      	movl	$0x4, %eax
    1a03:      	movl	$0x2, %esi
    1a08:      	callq	*%rax
    1a0a:      	movzbl	0xac(%rsp), %ebp
    1a12:      	jmp	0x31b1 <generic_tracepoint_process_event+0x31b1>
    1a17:      	movl	$0x120, %edx            # imm = 0x120
    1a1c:      	addq	0x38(%rsp), %rdx
    1a21:      	leaq	0x4(%r12), %rdi
    1a26:      	movl	$0x11, %ecx
    1a2b:      	movl	$0x2d, %eax
    1a30:      	movl	$0x11, %esi
    1a35:      	callq	*%rax
    1a37:      	movq	%rax, %r15
    1a3a:      	testq	%rax, %rax
    1a3d:      	js	0x249e <generic_tracepoint_process_event+0x249e>
    1a43:      	leal	-0x1(%r15), %eax
    1a47:      	movl	%eax, (%r12)
    1a4b:      	addq	$0x3, %r15
    1a4f:      	jmp	0x249e <generic_tracepoint_process_event+0x249e>
    1a54:      	movq	0x38(%rsp), %r15
    1a59:      	movq	$0x0, 0x10(%r12)
    1a62:      	movq	$0x0, 0x8(%r12)
    1a6b:      	movq	$0x0, (%r12)
    1a73:      	movl	$0x2, %ecx
    1a78:      	movl	$0x4, %eax
    1a7d:      	movq	%r12, %rdi
    1a80:      	movl	$0x2, %esi
    1a85:      	movq	%r15, %rdx
    1a88:      	callq	*%rax
    1a8a:      	testq	%rax, %rax
    1a8d:      	js	0x235f <generic_tracepoint_process_event+0x235f>
    1a93:      	movzwl	(%r12), %eax
    1a98:      	cmpl	$0xa, %eax
    1a9b:      	je	0x230a <generic_tracepoint_process_event+0x230a>
    1aa1:      	cmpl	$0x2, %eax
    1aa4:      	jne	0x2346 <generic_tracepoint_process_event+0x2346>
    1aaa:      	leaq	0x4(%r15), %rdx
    1aae:      	leaq	0x58(%rsp), %rdi
    1ab3:      	movl	$0x4, %ecx
    1ab8:      	movl	$0x4, %eax
    1abd:      	movl	$0x4, %esi
    1ac2:      	callq	*%rax
    1ac4:      	movl	0x58(%rsp), %eax
    1ac8:      	movq	0x10(%rsp), %rcx
    1acd:      	movq	%rax, 0x8(%rcx)
    1ad1:      	leaq	0x2(%rcx), %rdi
    1ad5:      	addq	$0x2, %r15
    1ad9:      	movl	$0x2, %ecx
    1ade:      	movl	$0x4, %eax
    1ae3:      	jmp	0x233c <generic_tracepoint_process_event+0x233c>
    1ae8:      	movq	%rax, %r15
    1aeb:      	movq	0x30(%rsp), %rcx
    1af0:      	leaq	(%rax,%rcx), %rbp
    1af4:      	addq	$0x90, %rbp
    1afb:      	movq	$0x0, 0xc8(%rsp)
    1b07:      	testb	$0x10, %r12b
    1b0b:      	jne	0x2221 <generic_tracepoint_process_event+0x2221>
    1b11:      	andl	$0xf, %r12d
    1b15:      	xorl	%eax, %eax
    1b17:      	cmpl	$0x2, %r12d
    1b1b:      	jle	0x24ad <generic_tracepoint_process_event+0x24ad>
    1b21:      	cmpl	$0x3, %r12d
    1b25:      	je	0x2b77 <generic_tracepoint_process_event+0x2b77>
    1b2b:      	cmpl	$0x4, %r12d
    1b2f:      	je	0x2b80 <generic_tracepoint_process_event+0x2b80>
    1b35:      	cmpl	$0x5, %r12d
    1b39:      	jne	0x2b93 <generic_tracepoint_process_event+0x2b93>
    1b3f:      	addq	$0x5e70, %r15           # imm = 0x5E70
    1b46:      	jmp	0x2b90 <generic_tracepoint_process_event+0x2b90>
    1b4b:      	movq	0x10(%rsp), %rbp
    1b50:      	leaq	0x28(%rbp), %r13
    1b54:      	leaq	0x40(%rbp), %r15
    1b58:      	movq	0x20(%rsp), %r12
    1b5d:      	leaq	0x8(%r12), %rdx
    1b62:      	movl	$0x4, %ecx
    1b67:      	movl	$0x4, %eax
    1b6c:      	movq	%rbp, %rdi
    1b6f:      	movl	$0x4, %esi
    1b74:      	callq	*%rax
    1b76:      	leaq	0x4(%rbp), %rdi
    1b7a:      	leaq	0xc(%r12), %rdx
    1b7f:      	movl	$0x4, %ecx
    1b84:      	movl	$0x4, %eax
    1b89:      	movl	$0x4, %esi
    1b8e:      	callq	*%rax
    1b90:      	leaq	0x10(%rbp), %rdi
    1b94:      	leaq	0x18(%r12), %rdx
    1b99:      	movl	$0x4, %ecx
    1b9e:      	movl	$0x4, %eax
    1ba3:      	movl	$0x4, %esi
    1ba8:      	callq	*%rax
    1baa:      	leaq	0x14(%rbp), %rdi
    1bae:      	leaq	0x1c(%r12), %rdx
    1bb3:      	movl	$0x4, %ecx
    1bb8:      	movl	$0x4, %eax
    1bbd:      	movl	$0x4, %esi
    1bc2:      	callq	*%rax
    1bc4:      	leaq	0x8(%rbp), %rdi
    1bc8:      	leaq	0x10(%r12), %rdx
    1bcd:      	movl	$0x4, %ecx
    1bd2:      	movl	$0x4, %eax
    1bd7:      	movl	$0x4, %esi
    1bdc:      	callq	*%rax
    1bde:      	leaq	0xc(%rbp), %rdi
    1be2:      	leaq	0x14(%r12), %rdx
    1be7:      	movl	$0x4, %ecx
    1bec:      	movl	$0x4, %eax
    1bf1:      	movl	$0x4, %esi
    1bf6:      	callq	*%rax
    1bf8:      	leaq	0x18(%rbp), %rdi
    1bfc:      	leaq	0x20(%r12), %rdx
    1c01:      	movl	$0x4, %ecx
    1c06:      	movl	$0x4, %eax
    1c0b:      	movl	$0x4, %esi
    1c10:      	callq	*%rax
    1c12:      	leaq	0x1c(%rbp), %rdi
    1c16:      	leaq	0x24(%r12), %rdx
    1c1b:      	movl	$0x4, %ecx
    1c20:      	movl	$0x4, %eax
    1c25:      	movl	$0x4, %esi
    1c2a:      	callq	*%rax
    1c2c:      	movl	$0x0, 0x24(%rbp)
    1c33:      	leaq	0x20(%rbp), %rdi
    1c37:      	leaq	0x28(%r12), %rdx
    1c3c:      	movl	$0x4, %ecx
    1c41:      	movl	$0x4, %eax
    1c46:      	movl	$0x4, %esi
    1c4b:      	callq	*%rax
    1c4d:      	leaq	0x30(%rbp), %rdi
    1c51:      	leaq	0x40(%r12), %rdx
    1c56:      	movl	$0x8, %ecx
    1c5b:      	movl	$0x4, %eax
    1c60:      	movl	$0x8, %esi
    1c65:      	callq	*%rax
    1c67:      	leaq	0x38(%rbp), %rdi
    1c6b:      	leaq	0x30(%r12), %rdx
    1c70:      	movl	$0x8, %ecx
    1c75:      	movl	$0x4, %eax
    1c7a:      	movl	$0x8, %esi
    1c7f:      	callq	*%rax
    1c81:      	leaq	0x38(%r12), %rdx
    1c86:      	movl	$0x8, %ecx
    1c8b:      	movl	$0x4, %eax
    1c90:      	movq	%r13, %rdi
    1c93:      	movl	$0x8, %esi
    1c98:      	callq	*%rax
    1c9a:      	addq	$0x90, %r12
    1ca1:      	leaq	0x58(%rsp), %rdi
    1ca6:      	movl	$0x8, %ecx
    1cab:      	movl	$0x4, %eax
    1cb0:      	movl	$0x8, %esi
    1cb5:      	movq	%r12, %rdx
    1cb8:      	callq	*%rax
    1cba:      	movq	0x58(%rsp), %r12
    1cbf:      	leaq	0xc8(%r12), %rdx
    1cc7:      	movl	$0x4, %ecx
    1ccc:      	movl	$0x4, %eax
    1cd1:      	movq	%r15, %rdi
    1cd4:      	movl	$0x4, %esi
    1cd9:      	callq	*%rax
    1cdb:      	leaq	0x44(%rbp), %rdi
    1cdf:      	leaq	0xcc(%r12), %rdx
    1ce7:      	movl	$0x4, %ecx
    1cec:      	movl	$0x4, %eax
    1cf1:      	movl	$0x4, %esi
    1cf6:      	callq	*%rax
    1cf8:      	leaq	0x48(%rbp), %rdi
    1cfc:      	leaq	0xd0(%r12), %rdx
    1d04:      	movl	$0x4, %ecx
    1d09:      	movl	$0x4, %eax
    1d0e:      	movl	$0x4, %esi
    1d13:      	callq	*%rax
    1d15:      	addq	$0x4c, %rbp
    1d19:      	addq	$0x158, %r12            # imm = 0x158
    1d20:      	movl	$0x4, %ecx
    1d25:      	movl	$0x4, %eax
    1d2a:      	movq	%rbp, %rdi
    1d2d:      	movl	$0x4, %esi
    1d32:      	movq	%r12, %rdx
    1d35:      	callq	*%rax
    1d37:      	movl	$0x50, %r15d
    1d3d:      	jmp	0x1f62 <generic_tracepoint_process_event+0x1f62>
    1d42:      	movq	0x20(%rsp), %r12
    1d47:      	leaq	0xc8(%r12), %rdx
    1d4f:      	movl	$0x4, %ecx
    1d54:      	movl	$0x4, %eax
    1d59:      	movq	0x10(%rsp), %r15
    1d5e:      	movq	%r15, %rdi
    1d61:      	movl	$0x4, %esi
    1d66:      	callq	*%rax
    1d68:      	leaq	0x4(%r15), %rdi
    1d6c:      	leaq	0xcc(%r12), %rdx
    1d74:      	movl	$0x4, %ecx
    1d79:      	movl	$0x4, %eax
    1d7e:      	movl	$0x4, %esi
    1d83:      	callq	*%rax
    1d85:      	leaq	0x8(%r15), %rdi
    1d89:      	leaq	0xd0(%r12), %rdx
    1d91:      	movl	$0x4, %ecx
    1d96:      	movl	$0x4, %eax
    1d9b:      	movl	$0x4, %esi
    1da0:      	callq	*%rax
    1da2:      	addq	$0xc, %r15
    1da6:      	addq	$0x158, %r12            # imm = 0x158
    1dad:      	movl	$0x4, %ecx
    1db2:      	movl	$0x4, %eax
    1db7:      	movq	%r15, %rdi
    1dba:      	movl	$0x4, %esi
    1dbf:      	movq	%r12, %rdx
    1dc2:      	callq	*%rax
    1dc4:      	movl	$0x10, %r15d
    1dca:      	jmp	0x1f62 <generic_tracepoint_process_event+0x1f62>
    1dcf:      	movq	0x20(%rsp), %r12
    1dd4:      	leaq	0x38(%r12), %rdx
    1dd9:      	movl	$0x4, %ecx
    1dde:      	movl	$0x4, %eax
    1de3:      	movq	0x10(%rsp), %r15
    1de8:      	movq	%r15, %rdi
    1deb:      	movl	$0x4, %esi
    1df0:      	callq	*%rax
    1df2:      	leaq	0x4(%r15), %rdi
    1df6:      	leaq	0x3c(%r12), %rdx
    1dfb:      	movl	$0x4, %ecx
    1e00:      	movl	$0x4, %eax
    1e05:      	movl	$0x4, %esi
    1e0a:      	callq	*%rax
    1e0c:      	leaq	0x8(%r15), %rdi
    1e10:      	leaq	0x40(%r12), %rdx
    1e15:      	movl	$0x4, %ecx
    1e1a:      	movl	$0x4, %eax
    1e1f:      	movl	$0x4, %esi
    1e24:      	callq	*%rax
    1e26:      	leaq	0xc(%r15), %rdi
    1e2a:      	leaq	0x44(%r12), %rdx
    1e2f:      	movl	$0x4, %ecx
    1e34:      	movl	$0x4, %eax
    1e39:      	movl	$0x4, %esi
    1e3e:      	callq	*%rax
    1e40:      	addq	$0x10, %r15
    1e44:      	subq	$-0x80, %r12
    1e48:      	movl	$0x10, %ecx
    1e4d:      	movl	$0x4, %eax
    1e52:      	movq	%r15, %rdi
    1e55:      	movl	$0x10, %esi
    1e5a:      	movq	%r12, %rdx
    1e5d:      	callq	*%rax
    1e5f:      	movl	$0x20, %r15d
    1e65:      	jmp	0x1f62 <generic_tracepoint_process_event+0x1f62>
    1e6a:      	movl	$0x4, %ecx
    1e6f:      	movl	$0x4, %eax
    1e74:      	movq	0x10(%rsp), %r15
    1e79:      	movq	0x20(%rsp), %r12
    1e7e:      	movq	%r15, %rdi
    1e81:      	movl	$0x4, %esi
    1e86:      	movq	%r12, %rdx
    1e89:      	callq	*%rax
    1e8b:      	leaq	0x4(%r15), %rdi
    1e8f:      	leaq	0x4(%r12), %rdx
    1e94:      	movl	$0x4, %ecx
    1e99:      	movl	$0x4, %eax
    1e9e:      	movl	$0x4, %esi
    1ea3:      	callq	*%rax
    1ea5:      	addq	$0x8, %r15
    1ea9:      	addq	$0x30, %r12
    1ead:      	movl	$0x10, %ecx
    1eb2:      	movl	$0x4, %eax
    1eb7:      	movq	%r15, %rdi
    1eba:      	movl	$0x10, %esi
    1ebf:      	movq	%r12, %rdx
    1ec2:      	jmp	0x1f5a <generic_tracepoint_process_event+0x1f5a>
    1ec7:      	movq	%rdi, %r12
    1eca:      	leaq	0x4(%r8), %rdx
    1ece:      	leaq	0x58(%rsp), %rdi
    1ed3:      	movl	$0x4, %ecx
    1ed8:      	movl	$0x4, %eax
    1edd:      	movl	$0x4, %esi
    1ee2:      	movq	%r8, %r13
    1ee5:      	callq	*%rax
    1ee7:      	movl	0x58(%rsp), %eax
    1eeb:      	movq	%r12, %r15
    1eee:      	movl	%eax, (%r12)
    1ef2:      	leaq	0xc(%r13), %rdx
    1ef6:      	leaq	0x58(%rsp), %rdi
    1efb:      	movl	$0x4, %ecx
    1f00:      	movl	$0x4, %eax
    1f05:      	movl	$0x4, %esi
    1f0a:      	callq	*%rax
    1f0c:      	movl	0x58(%rsp), %eax
    1f10:      	movl	%eax, 0x4(%r12)
    1f15:      	addq	$0x50, %r13
    1f19:      	leaq	0x58(%rsp), %rdi
    1f1e:      	movl	$0x8, %ecx
    1f23:      	movl	$0x2d, %eax
    1f28:      	movl	$0x8, %esi
    1f2d:      	movq	%r13, %rdx
    1f30:      	callq	*%rax
    1f32:      	addq	$0x8, %r15
    1f36:      	movl	$0x3f8, %edx            # imm = 0x3F8
    1f3b:      	movq	0x58(%rsp), %rcx
    1f40:      	addq	%rdx, %rcx
    1f43:      	movl	$0x10, %esi
    1f48:      	movl	$0x2d, %eax
    1f4d:      	addq	0x58(%rsp), %rdx
    1f52:      	movq	%r15, %rdi
    1f55:      	movl	$0x10, %esi
    1f5a:      	callq	*%rax
    1f5c:      	movl	$0x18, %r15d
    1f62:      	movq	0x18(%rsp), %rcx
    1f67:      	movq	0x8(%rsp), %r9
    1f6c:      	movq	0x50(%rsp), %rbp
    1f71:      	jmp	0x3333 <generic_tracepoint_process_event+0x3333>
    1f76:      	movq	0x10(%rsp), %rax
    1f7b:      	movq	$0x0, 0x48(%rax)
    1f83:      	movq	$0x0, 0x40(%rax)
    1f8b:      	movq	$0x0, 0x38(%rax)
    1f93:      	movq	$0x0, 0x30(%rax)
    1f9b:      	movq	$0x0, 0x28(%rax)
    1fa3:      	movq	$0x0, 0x20(%rax)
    1fab:      	movq	$0x0, 0x18(%rax)
    1fb3:      	movq	$0x0, 0x10(%rax)
    1fbb:      	movq	$0x0, 0x8(%rax)
    1fc3:      	movq	$0x0, (%rax)
    1fca:      	leaq	0x58(%rsp), %rdi
    1fcf:      	movl	$0x8, %ecx
    1fd4:      	movl	$0x4, %eax
    1fd9:      	movl	$0x8, %esi
    1fde:      	movq	%r8, %rdx
    1fe1:      	callq	*%rax
    1fe3:      	testq	%rax, %rax
    1fe6:      	je	0x236a <generic_tracepoint_process_event+0x236a>
    1fec:      	xorl	%r15d, %r15d
    1fef:      	jmp	0x2c04 <generic_tracepoint_process_event+0x2c04>
    1ff4:      	movq	$-0x1, %r15
    1ffb:      	jmp	0x331f <generic_tracepoint_process_event+0x331f>
    2000:      	leaq	0x10(%r12), %rdx
    2005:      	leaq	0x98(%rsp), %rdi
    200d:      	movl	$0x8, %ecx
    2012:      	movl	$0x4, %eax
    2017:      	movl	$0x8, %esi
    201c:      	callq	*%rax
    201e:      	addq	$0x18, %r12
    2022:      	leaq	0x40(%rsp), %rdi
    2027:      	movl	$0x8, %ecx
    202c:      	movl	$0x4, %eax
    2031:      	movl	$0x8, %esi
    2036:      	movq	%r12, %rdx
    2039:      	callq	*%rax
    203b:      	movq	0x98(%rsp), %rdx
    2043:      	movq	0x40(%rsp), %r12
    2048:      	cmpq	$0xfff, %r12            # imm = 0xFFF
    204f:      	movl	$0xfff, %r15d           # imm = 0xFFF
    2055:      	cmovbq	%r12, %r15
    2059:      	movq	0x30(%rsp), %rcx
    205e:      	leaq	(%rcx,%rbp), %rdi
    2062:      	addq	$0x98, %rdi
    2069:      	movl	$0x4, %eax
    206e:      	leaq	(%rcx,%rbp), %r13
    2072:      	addq	$0x90, %r13
    2079:      	movl	%r15d, %esi
    207c:      	callq	*%rax
    207e:      	testl	%eax, %eax
    2080:      	js	0x2452 <generic_tracepoint_process_event+0x2452>
    2086:      	movl	%r12d, (%r13)
    208a:      	movl	%r15d, 0x4(%r13)
    208e:      	addq	$0x8, %r15
    2092:      	jmp	0x331f <generic_tracepoint_process_event+0x331f>
    2097:      	movq	0x58(%rsp), %rcx
    209c:      	movl	$0x0, 0x98(%rsp)
    20a7:      	movzwl	0xc0(%rsp), %ebp
    20af:      	movq	(%rip), %rdi            # 0x20b6 <generic_tracepoint_process_event+0x20b6>
    20b6:      	leaq	0x98(%rsp), %rsi
    20be:      	movl	$0x1, %eax
    20c3:      	movq	%rcx, 0x20(%rsp)
    20c8:      	leaq	(%rcx,%rbp), %r13
    20cc:      	callq	*%rax
    20ce:      	testq	%rax, %rax
    20d1:      	je	0x315e <generic_tracepoint_process_event+0x315e>
    20d7:      	movq	%rax, %r15
    20da:      	movw	%bp, (%rax)
    20dd:      	movb	$-0x1, 0x5(%rax)
    20e1:      	movb	$0x0, 0x7(%rax)
    20e5:      	movq	%rax, %rdi
    20e8:      	addq	$0x6, %rdi
    20ec:      	leaq	0x6(%r13), %rdx
    20f0:      	movl	$0x1, %ecx
    20f5:      	movl	$0x4, %eax
    20fa:      	movq	%rdi, 0x30(%rsp)
    20ff:      	movl	$0x1, %esi
    2104:      	callq	*%rax
    2106:      	testq	%rax, %rax
    2109:      	js	0x315e <generic_tracepoint_process_event+0x315e>
    210f:      	movzbl	0x5(%r15), %eax
    2114:      	cmpl	$0x32, %eax
    2117:      	jg	0x2ac0 <generic_tracepoint_process_event+0x2ac0>
    211d:      	testl	%eax, %eax
    211f:      	je	0x2b66 <generic_tracepoint_process_event+0x2b66>
    2125:      	cmpl	$0x2b, %eax
    2128:      	je	0x2b66 <generic_tracepoint_process_event+0x2b66>
    212e:      	cmpl	$0x2c, %eax
    2131:      	jne	0x2cdf <generic_tracepoint_process_event+0x2cdf>
    2137:      	movw	$0x8, 0x2(%r15)
    213e:      	movw	$0x8, %ax
    2142:      	jmp	0x2c29 <generic_tracepoint_process_event+0x2c29>
    2147:      	leaq	0x48(%r15), %rdx
    214b:      	movl	$0x10, %ecx
    2150:      	movl	$0x4, %eax
    2155:      	movq	0x10(%rsp), %rdi
    215a:      	movl	$0x10, %esi
    215f:      	callq	*%rax
    2161:      	leaq	0x38(%r15), %rdx
    2165:      	movl	$0x10, %ecx
    216a:      	movl	$0x4, %eax
    216f:      	movq	%r12, %rdi
    2172:      	movl	$0x10, %esi
    2177:      	callq	*%rax
    2179:      	movq	0x10(%rsp), %r13
    217e:      	leaq	0x20(%r13), %rdi
    2182:      	leaq	0xc(%r15), %r12
    2186:      	addq	$0xe, %r15
    218a:      	movl	$0x2, %ecx
    218f:      	movl	$0x4, %eax
    2194:      	movl	$0x2, %esi
    2199:      	movq	%r15, %rdx
    219c:      	callq	*%rax
    219e:      	leaq	0x22(%r13), %rdi
    21a2:      	movl	$0x2, %ecx
    21a7:      	movl	$0x4, %eax
    21ac:      	movl	$0x2, %esi
    21b1:      	movq	%r12, %rdx
    21b4:      	callq	*%rax
    21b6:      	movzwl	0x22(%r13), %eax
    21bb:      	movbew	%ax, 0x22(%r13)
    21c2:      	movq	0x38(%rsp), %rax
    21c7:      	movq	%rax, 0x58(%rsp)
    21cc:      	movq	(%rip), %rdi            # 0x21d3 <generic_tracepoint_process_event+0x21d3>
    21d3:      	leaq	0x58(%rsp), %rsi
    21d8:      	movl	$0x1, %eax
    21dd:      	callq	*%rax
    21df:      	testq	%rax, %rax
    21e2:      	je	0x3319 <generic_tracepoint_process_event+0x3319>
    21e8:      	movl	(%rax), %ecx
    21ea:      	movq	0x20(%rsp), %rdx
    21ef:      	movl	%ecx, 0x10(%rdx)
    21f2:      	movq	0x8(%rax), %rcx
    21f6:      	movq	%rcx, 0x18(%rdx)
    21fa:      	movl	0x4(%rax), %eax
    21fd:      	movl	%eax, 0x7c(%rdx)
    2200:      	jmp	0x3319 <generic_tracepoint_process_event+0x3319>
    2205:      	movq	0x30(%rsp), %rax
    220a:      	movq	$0x0, 0x90(%rbp,%rax)
    2216:      	movl	$0x8, %r15d
    221c:      	jmp	0x331f <generic_tracepoint_process_event+0x331f>
    2221:      	movl	$0xe, %eax
    2226:      	callq	*%rax
    2228:      	cmpq	$-0x16, %rax
    222c:      	jne	0x2252 <generic_tracepoint_process_event+0x2252>
    222e:      	movq	0x28(%rsp), %rax
    2233:      	leaq	0x20(%rax), %rdx
    2237:      	leaq	0x58(%rsp), %rdi
    223c:      	movl	$0x8, %ecx
    2241:      	movl	$0x4, %eax
    2246:      	movl	$0x8, %esi
    224b:      	callq	*%rax
    224d:      	movq	0x58(%rsp), %rax
    2252:      	movq	0x8(%r15), %rcx
    2256:      	movq	0x60(%r15), %rdx
    225a:      	movq	%rcx, 0x58(%rsp)
    225f:      	movq	0x20(%rsp), %rcx
    2264:      	movq	%rcx, 0x60(%rsp)
    2269:      	movq	$0x0, 0x68(%rsp)
    2272:      	movq	%rdx, 0x98(%rsp)
    227a:      	movq	%rax, 0xa0(%rsp)
    2282:      	movq	(%rip), %rdi            # 0x2289 <generic_tracepoint_process_event+0x2289>
    2289:      	xorl	%ecx, %ecx
    228b:      	leaq	0x98(%rsp), %rsi
    2293:      	leaq	0x58(%rsp), %rdx
    2298:      	movl	$0x2, %eax
    229d:      	xorl	%ecx, %ecx
    229f:      	callq	*%rax
    22a1:      	testq	%rax, %rax
    22a4:      	je	0x2b17 <generic_tracepoint_process_event+0x2b17>
    22aa:      	negl	%eax
    22ac:      	movw	%ax, 0x40(%rsp)
    22b1:      	movw	$0x5, 0x42(%rsp)
    22b8:      	movabsq	$0x200000046, %rax      # imm = 0x200000046
    22c2:      	movq	%rax, 0x44(%rsp)
    22c7:      	movq	(%rip), %rdi            # 0x22ce <generic_tracepoint_process_event+0x22ce>
    22ce:      	leaq	0x40(%rsp), %rsi
    22d3:      	movl	$0x1, %eax
    22d8:      	callq	*%rax
    22da:      	testq	%rax, %rax
    22dd:      	je	0x2aed <generic_tracepoint_process_event+0x2aed>
    22e3:      	incl	(%rax)
    22e5:      	jmp	0x2b17 <generic_tracepoint_process_event+0x2b17>
    22ea:      	cmpl	$0x1, %eax
    22ed:      	je	0x25a8 <generic_tracepoint_process_event+0x25a8>
    22f3:      	cmpl	$0x2, %eax
    22f6:      	jne	0x29c0 <generic_tracepoint_process_event+0x29c0>
    22fc:      	movq	%rbp, %rax
    22ff:      	addq	$0x5e58, %rax           # imm = 0x5E58
    2305:      	jmp	0x25b1 <generic_tracepoint_process_event+0x25b1>
    230a:      	movq	0x10(%rsp), %r12
    230f:      	leaq	0x8(%r12), %rdi
    2314:      	leaq	0x8(%r15), %rdx
    2318:      	movl	$0x10, %ecx
    231d:      	movl	$0x4, %eax
    2322:      	movl	$0x10, %esi
    2327:      	callq	*%rax
    2329:      	leaq	0x2(%r12), %rdi
    232e:      	addq	$0x2, %r15
    2332:      	movl	$0x2, %ecx
    2337:      	movl	$0x4, %eax
    233c:      	movl	$0x2, %esi
    2341:      	movq	%r15, %rdx
    2344:      	callq	*%rax
    2346:      	movq	0x10(%rsp), %rcx
    234b:      	movzwl	0x2(%rcx), %eax
    234f:      	movbew	%ax, 0x2(%rcx)
    2355:      	movq	0x50(%rsp), %rbp
    235a:      	movq	0x28(%rsp), %rbx
    235f:      	movl	$0x18, %r15d
    2365:      	jmp	0x249e <generic_tracepoint_process_event+0x249e>
    236a:      	movq	0x10(%rsp), %rax
    236f:      	leaq	0x10(%rax), %rdi
    2373:      	movq	0x58(%rsp), %rcx
    2378:      	movl	$0x3f, %edx
    237d:      	movl	$0x2d, %eax
    2382:      	movq	0x58(%rsp), %rdx
    2387:      	movl	$0x3f, %esi
    238c:      	callq	*%rax
    238e:      	testq	%rax, %rax
    2391:      	js	0x1fec <generic_tracepoint_process_event+0x1fec>
    2397:      	movq	0x20(%rsp), %r15
    239c:      	leaq	0x8(%r15), %rdx
    23a0:      	leaq	0x98(%rsp), %rdi
    23a8:      	movl	$0x8, %ecx
    23ad:      	movl	$0x4, %eax
    23b2:      	movl	$0x8, %esi
    23b7:      	callq	*%rax
    23b9:      	movq	0x10(%rsp), %rax
    23be:      	leaq	0x8(%rax), %rdi
    23c2:      	movl	$0x348, %edx            # imm = 0x348
    23c7:      	movq	0x98(%rsp), %rcx
    23cf:      	addq	%rdx, %rcx
    23d2:      	movl	$0x8, %esi
    23d7:      	movl	$0x4, %eax
    23dc:      	addq	0x98(%rsp), %rdx
    23e4:      	movl	$0x8, %esi
    23e9:      	callq	*%rax
    23eb:      	addq	$0x58, %r15
    23ef:      	leaq	0x98(%rsp), %rdi
    23f7:      	movl	$0x4, %ecx
    23fc:      	movl	$0x4, %eax
    2401:      	movl	$0x4, %esi
    2406:      	movq	%r15, %rdx
    2409:      	callq	*%rax
    240b:      	movl	$0x50, %r15d
    2411:      	testq	%rax, %rax
    2414:      	jne	0x2c04 <generic_tracepoint_process_event+0x2c04>
    241a:      	xorl	%eax, %eax
    241c:      	cmpl	$0x0, 0x98(%rsp)
    2424:      	setne	%al
    2427:      	movq	0x10(%rsp), %rcx
    242c:      	movl	%eax, (%rcx)
    242e:      	jmp	0x2c04 <generic_tracepoint_process_event+0x2c04>
    2433:      	xorl	%r15d, %r15d
    2436:      	movq	%r12, %rcx
    2439:      	movq	%r13, %r9
    243c:      	movq	0x28(%rsp), %rbx
    2441:      	jmp	0x1f6c <generic_tracepoint_process_event+0x1f6c>
    2446:      	movl	$0xfffffffe, (%rbp)     # imm = 0xFFFFFFFE
    244d:      	jmp	0x331f <generic_tracepoint_process_event+0x331f>
    2452:      	movl	$0xfffffffe, (%r13)     # imm = 0xFFFFFFFE
    245a:      	movl	$0x4, %r15d
    2460:      	jmp	0x331f <generic_tracepoint_process_event+0x331f>
    2465:      	addq	$0x3, %r15
    2469:      	movl	$0x6b, %ecx
    246e:      	movl	$0x71, %eax
    2473:      	movl	$0x6b, %esi
    2478:      	movq	%r15, %rdx
    247b:      	callq	*%rax
    247d:      	movq	%rax, %rcx
    2480:      	movb	$0x6b, %al
    2482:      	testl	%ecx, %ecx
    2484:      	movq	0x50(%rsp), %rbp
    2489:      	movq	0x28(%rsp), %rbx
    248e:      	js	0x2498 <generic_tracepoint_process_event+0x2498>
    2490:      	movq	0x10(%rsp), %rcx
    2495:      	movb	%al, 0x3(%rcx)
    2498:      	movl	$0x70, %r15d
    249e:      	movq	0x18(%rsp), %rcx
    24a3:      	movq	0x8(%rsp), %r9
    24a8:      	jmp	0x3333 <generic_tracepoint_process_event+0x3333>
    24ad:      	cmpl	$0x1, %r12d
    24b1:      	je	0x2b89 <generic_tracepoint_process_event+0x2b89>
    24b7:      	cmpl	$0x2, %r12d
    24bb:      	jne	0x2b93 <generic_tracepoint_process_event+0x2b93>
    24c1:      	addq	$0x5e58, %r15           # imm = 0x5E58
    24c8:      	jmp	0x2b90 <generic_tracepoint_process_event+0x2b90>
    24cd:      	leaq	0x48(%r15), %rdx
    24d1:      	movl	$0x10, %ecx
    24d6:      	movl	$0x4, %eax
    24db:      	movq	0x10(%rsp), %rdi
    24e0:      	movl	$0x10, %esi
    24e5:      	callq	*%rax
    24e7:      	leaq	0x38(%r15), %rdx
    24eb:      	movl	$0x10, %ecx
    24f0:      	movl	$0x4, %eax
    24f5:      	movq	%r12, %rdi
    24f8:      	movl	$0x10, %esi
    24fd:      	callq	*%rax
    24ff:      	movq	0x10(%rsp), %rbp
    2504:      	leaq	0x20(%rbp), %rdi
    2508:      	leaq	0xc(%r15), %r12
    250c:      	addq	$0xe, %r15
    2510:      	movl	$0x2, %ecx
    2515:      	movl	$0x4, %eax
    251a:      	movl	$0x2, %esi
    251f:      	movq	%r15, %rdx
    2522:      	callq	*%rax
    2524:      	leaq	0x22(%rbp), %rdi
    2528:      	movl	$0x2, %ecx
    252d:      	movl	$0x4, %eax
    2532:      	movl	$0x2, %esi
    2537:      	movq	%r12, %rdx
    253a:      	callq	*%rax
    253c:      	movzwl	0x22(%rbp), %eax
    2540:      	movbew	%ax, 0x22(%rbp)
    2546:      	movq	0x10(%rsp), %rax
    254b:      	movq	0x28(%rax), %rax
    254f:      	movq	%rax, 0x58(%rsp)
    2554:      	movq	(%rip), %rdi            # 0x255b <generic_tracepoint_process_event+0x255b>
    255b:      	leaq	0x58(%rsp), %rsi
    2560:      	movl	$0x1, %eax
    2565:      	callq	*%rax
    2567:      	testq	%rax, %rax
    256a:      	je	0x2584 <generic_tracepoint_process_event+0x2584>
    256c:      	movl	(%rax), %ecx
    256e:      	movq	0x30(%rsp), %rdx
    2573:      	movl	%ecx, 0x10(%rdx)
    2576:      	movq	0x8(%rax), %rcx
    257a:      	movq	%rcx, 0x18(%rdx)
    257e:      	movl	0x4(%rax), %eax
    2581:      	movl	%eax, 0x7c(%rdx)
    2584:      	movl	$0x40, %r15d
    258a:      	movq	%r13, %rcx
    258d:      	jmp	0x2c09 <generic_tracepoint_process_event+0x2c09>
    2592:      	movq	%rbp, %rax
    2595:      	addq	$0x5e60, %rax           # imm = 0x5E60
    259b:      	jmp	0x25b1 <generic_tracepoint_process_event+0x25b1>
    259d:      	movq	%rbp, %rax
    25a0:      	addq	$0x5e68, %rax           # imm = 0x5E68
    25a6:      	jmp	0x25b1 <generic_tracepoint_process_event+0x25b1>
    25a8:      	movq	%rbp, %rax
    25ab:      	addq	$0x5e50, %rax           # imm = 0x5E50
    25b1:      	movq	(%rax), %r12
    25b4:      	testb	$0x10, %sil
    25b8:      	jne	0x29d7 <generic_tracepoint_process_event+0x29d7>
    25be:      	testq	%r12, %r12
    25c1:      	je	0x2a9c <generic_tracepoint_process_event+0x2a9c>
    25c7:      	leaq	0x58(%rsp), %rdi
    25cc:      	movl	$0x4, %r15d
    25d2:      	movl	$0x10, %ecx
    25d7:      	movl	$0x4, %eax
    25dc:      	movq	0x20(%rsp), %rdx
    25e1:      	movl	$0x10, %esi
    25e6:      	callq	*%rax
    25e8:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    25ed:      	testl	%eax, %eax
    25ef:      	js	0x29b1 <generic_tracepoint_process_event+0x29b1>
    25f5:      	movq	0x60(%rsp), %rdx
    25fa:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    25ff:      	movq	%rdx, %rax
    2602:      	movq	%rdx, 0x10(%rsp)
    2607:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    260e:      	ja	0x29b1 <generic_tracepoint_process_event+0x29b1>
    2614:      	movq	0xb0(%rsp), %rax
    261c:      	leaq	0xc(%rax), %rbp
    2620:      	movl	%ebp, %edi
    2622:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2628:      	addq	%r13, %rdi
    262b:      	movq	0x58(%rsp), %rcx
    2630:      	movl	$0x4, %eax
    2635:      	movq	0x10(%rsp), %rsi
    263a:      	movq	0x58(%rsp), %rdx
    263f:      	callq	*%rax
    2641:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2646:      	testl	%eax, %eax
    2648:      	js	0x29b1 <generic_tracepoint_process_event+0x29b1>
    264e:      	cmpq	$0x1, %r12
    2652:      	je	0x2aa3 <generic_tracepoint_process_event+0x2aa3>
    2658:      	movq	0x20(%rsp), %rax
    265d:      	leaq	0x10(%rax), %rdx
    2661:      	leaq	0x58(%rsp), %rdi
    2666:      	movl	$0x4, %r15d
    266c:      	movl	$0x10, %ecx
    2671:      	movl	$0x4, %eax
    2676:      	movl	$0x10, %esi
    267b:      	callq	*%rax
    267d:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2682:      	testl	%eax, %eax
    2684:      	js	0x29b1 <generic_tracepoint_process_event+0x29b1>
    268a:      	movq	0x60(%rsp), %rbx
    268f:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2694:      	cmpq	$0xffe, %rbx            # imm = 0xFFE
    269b:      	ja	0x29b1 <generic_tracepoint_process_event+0x29b1>
    26a1:      	addq	0x10(%rsp), %rbp
    26a6:      	movl	%ebp, %edi
    26a8:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    26ae:      	addq	%r13, %rdi
    26b1:      	movq	0x58(%rsp), %rcx
    26b6:      	movl	$0x4, %eax
    26bb:      	movq	0x58(%rsp), %rdx
    26c0:      	movl	%ebx, %esi
    26c2:      	callq	*%rax
    26c4:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    26c9:      	testl	%eax, %eax
    26cb:      	js	0x29b1 <generic_tracepoint_process_event+0x29b1>
    26d1:      	addq	%rbx, 0x10(%rsp)
    26d6:      	cmpq	$0x3, %r12
    26da:      	jb	0x2aa3 <generic_tracepoint_process_event+0x2aa3>
    26e0:      	movq	0x20(%rsp), %rax
    26e5:      	leaq	0x20(%rax), %rdx
    26e9:      	leaq	0x58(%rsp), %rdi
    26ee:      	movl	$0x4, %r15d
    26f4:      	movl	$0x10, %ecx
    26f9:      	movl	$0x4, %eax
    26fe:      	movl	$0x10, %esi
    2703:      	callq	*%rax
    2705:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    270a:      	testl	%eax, %eax
    270c:      	js	0x29b1 <generic_tracepoint_process_event+0x29b1>
    2712:      	movq	0x60(%rsp), %rax
    2717:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    271c:      	movq	%rax, 0xb8(%rsp)
    2724:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    272a:      	ja	0x29b1 <generic_tracepoint_process_event+0x29b1>
    2730:      	addq	%rbp, %rbx
    2733:      	movl	%ebx, %edi
    2735:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    273b:      	addq	%r13, %rdi
    273e:      	movq	0x58(%rsp), %rcx
    2743:      	movl	$0x4, %eax
    2748:      	movq	0xb8(%rsp), %rsi
    2750:      	movq	0x58(%rsp), %rdx
    2755:      	callq	*%rax
    2757:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    275c:      	testl	%eax, %eax
    275e:      	js	0x29b1 <generic_tracepoint_process_event+0x29b1>
    2764:      	movq	0xb8(%rsp), %rax
    276c:      	addq	%rax, 0x10(%rsp)
    2771:      	cmpq	$0x3, %r12
    2775:      	je	0x2aa3 <generic_tracepoint_process_event+0x2aa3>
    277b:      	movq	0x20(%rsp), %rax
    2780:      	leaq	0x30(%rax), %rdx
    2784:      	leaq	0x58(%rsp), %rdi
    2789:      	movl	$0x4, %r15d
    278f:      	movl	$0x10, %ecx
    2794:      	movl	$0x4, %eax
    2799:      	movl	$0x10, %esi
    279e:      	callq	*%rax
    27a0:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    27a5:      	testl	%eax, %eax
    27a7:      	js	0x29b1 <generic_tracepoint_process_event+0x29b1>
    27ad:      	movq	0x60(%rsp), %rax
    27b2:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    27b7:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    27bd:      	ja	0x29b1 <generic_tracepoint_process_event+0x29b1>
    27c3:      	movq	%rax, %rbp
    27c6:      	movq	0xb8(%rsp), %rdi
    27ce:      	addq	%rbx, %rdi
    27d1:      	movq	%rdi, %rbx
    27d4:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    27da:      	addq	%r13, %rdi
    27dd:      	movq	0x58(%rsp), %rcx
    27e2:      	movl	$0x4, %eax
    27e7:      	movq	%rbp, %rsi
    27ea:      	movq	0x58(%rsp), %rdx
    27ef:      	callq	*%rax
    27f1:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    27f6:      	testl	%eax, %eax
    27f8:      	js	0x29b1 <generic_tracepoint_process_event+0x29b1>
    27fe:      	addq	%rbp, 0x10(%rsp)
    2803:      	cmpq	$0x5, %r12
    2807:      	jb	0x2aa3 <generic_tracepoint_process_event+0x2aa3>
    280d:      	movq	0x20(%rsp), %rax
    2812:      	leaq	0x40(%rax), %rdx
    2816:      	leaq	0x58(%rsp), %rdi
    281b:      	movl	$0x4, %r15d
    2821:      	movl	$0x10, %ecx
    2826:      	movl	$0x4, %eax
    282b:      	movl	$0x10, %esi
    2830:      	callq	*%rax
    2832:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2837:      	testl	%eax, %eax
    2839:      	js	0x29b1 <generic_tracepoint_process_event+0x29b1>
    283f:      	movq	0x60(%rsp), %rax
    2844:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2849:      	movq	%rax, 0xb8(%rsp)
    2851:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2857:      	ja	0x29b1 <generic_tracepoint_process_event+0x29b1>
    285d:      	addq	%rbx, %rbp
    2860:      	movq	%rbp, %rbx
    2863:      	movl	%ebp, %edi
    2865:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    286b:      	addq	%r13, %rdi
    286e:      	movq	0x58(%rsp), %rcx
    2873:      	movl	$0x4, %eax
    2878:      	movq	0xb8(%rsp), %rsi
    2880:      	movq	0x58(%rsp), %rdx
    2885:      	callq	*%rax
    2887:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    288c:      	testl	%eax, %eax
    288e:      	js	0x29b1 <generic_tracepoint_process_event+0x29b1>
    2894:      	movq	0xb8(%rsp), %rax
    289c:      	addq	%rax, 0x10(%rsp)
    28a1:      	cmpq	$0x5, %r12
    28a5:      	je	0x2aa3 <generic_tracepoint_process_event+0x2aa3>
    28ab:      	movq	0x20(%rsp), %rax
    28b0:      	leaq	0x50(%rax), %rdx
    28b4:      	leaq	0x58(%rsp), %rdi
    28b9:      	movl	$0x4, %r15d
    28bf:      	movl	$0x10, %ecx
    28c4:      	movl	$0x4, %eax
    28c9:      	movl	$0x10, %esi
    28ce:      	callq	*%rax
    28d0:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    28d5:      	testl	%eax, %eax
    28d7:      	js	0x29b1 <generic_tracepoint_process_event+0x29b1>
    28dd:      	movq	0x60(%rsp), %rbp
    28e2:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    28e7:      	cmpq	$0xffe, %rbp            # imm = 0xFFE
    28ee:      	ja	0x29b1 <generic_tracepoint_process_event+0x29b1>
    28f4:      	movq	0xb8(%rsp), %rdi
    28fc:      	addq	%rbx, %rdi
    28ff:      	movq	%rdi, %rbx
    2902:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2908:      	addq	%r13, %rdi
    290b:      	movq	0x58(%rsp), %rcx
    2910:      	movl	$0x4, %eax
    2915:      	movq	0x58(%rsp), %rdx
    291a:      	movl	%ebp, %esi
    291c:      	callq	*%rax
    291e:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2923:      	testl	%eax, %eax
    2925:      	js	0x29b1 <generic_tracepoint_process_event+0x29b1>
    292b:      	addq	%rbp, 0x10(%rsp)
    2930:      	cmpq	$0x7, %r12
    2934:      	jb	0x2aa3 <generic_tracepoint_process_event+0x2aa3>
    293a:      	movq	0x20(%rsp), %rdx
    293f:      	addq	$0x60, %rdx
    2943:      	leaq	0x58(%rsp), %rdi
    2948:      	movl	$0x4, %r15d
    294e:      	movl	$0x10, %ecx
    2953:      	movl	$0x4, %eax
    2958:      	movl	$0x10, %esi
    295d:      	callq	*%rax
    295f:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2964:      	testl	%eax, %eax
    2966:      	js	0x29b1 <generic_tracepoint_process_event+0x29b1>
    2968:      	movq	0x60(%rsp), %r12
    296d:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2972:      	cmpq	$0xffe, %r12            # imm = 0xFFE
    2979:      	ja	0x29b1 <generic_tracepoint_process_event+0x29b1>
    297b:      	addq	%rbx, %rbp
    297e:      	andl	$0x3fff, %ebp           # imm = 0x3FFF
    2984:      	addq	%r13, %rbp
    2987:      	movq	0x58(%rsp), %rcx
    298c:      	movl	$0x4, %eax
    2991:      	movq	0x58(%rsp), %rdx
    2996:      	movq	%rbp, %rdi
    2999:      	movl	%r12d, %esi
    299c:      	callq	*%rax
    299e:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    29a3:      	testl	%eax, %eax
    29a5:      	js	0x29b1 <generic_tracepoint_process_event+0x29b1>
    29a7:      	addq	%r12, 0x10(%rsp)
    29ac:      	jmp	0x2aa3 <generic_tracepoint_process_event+0x2aa3>
    29b1:      	movq	0x30(%rsp), %rax
    29b6:      	movl	%ecx, (%r13,%rax)
    29bb:      	jmp	0x2c04 <generic_tracepoint_process_event+0x2c04>
    29c0:      	xorl	%r12d, %r12d
    29c3:      	movl	$0x0, %eax
    29c8:      	movq	%rax, 0x10(%rsp)
    29cd:      	testb	$0x10, %sil
    29d1:      	je	0x2aa3 <generic_tracepoint_process_event+0x2aa3>
    29d7:      	movl	$0xe, %eax
    29dc:      	callq	*%rax
    29de:      	cmpq	$-0x16, %rax
    29e2:      	jne	0x2a08 <generic_tracepoint_process_event+0x2a08>
    29e4:      	movq	0x28(%rsp), %rax
    29e9:      	leaq	0x20(%rax), %rdx
    29ed:      	leaq	0x58(%rsp), %rdi
    29f2:      	movl	$0x8, %ecx
    29f7:      	movl	$0x4, %eax
    29fc:      	movl	$0x8, %esi
    2a01:      	callq	*%rax
    2a03:      	movq	0x58(%rsp), %rax
    2a08:      	movq	0x8(%rbp), %rcx
    2a0c:      	movq	0x60(%rbp), %rdx
    2a10:      	movq	%rcx, 0x58(%rsp)
    2a15:      	movq	0x20(%rsp), %rcx
    2a1a:      	movq	%rcx, 0x60(%rsp)
    2a1f:      	movq	%r12, 0x68(%rsp)
    2a24:      	movq	%rdx, 0x98(%rsp)
    2a2c:      	movq	%rax, 0xa0(%rsp)
    2a34:      	movq	(%rip), %rdi            # 0x2a3b <generic_tracepoint_process_event+0x2a3b>
    2a3b:      	xorl	%ecx, %ecx
    2a3d:      	leaq	0x98(%rsp), %rsi
    2a45:      	leaq	0x58(%rsp), %rdx
    2a4a:      	movl	$0x2, %eax
    2a4f:      	xorl	%ecx, %ecx
    2a51:      	callq	*%rax
    2a53:      	testq	%rax, %rax
    2a56:      	je	0x2b4d <generic_tracepoint_process_event+0x2b4d>
    2a5c:      	negl	%eax
    2a5e:      	movw	%ax, 0x40(%rsp)
    2a63:      	movw	$0x5, 0x42(%rsp)
    2a6a:      	movabsq	$0x200000057, %rax      # imm = 0x200000057
    2a74:      	movq	%rax, 0x44(%rsp)
    2a79:      	movq	(%rip), %rdi            # 0x2a80 <generic_tracepoint_process_event+0x2a80>
    2a80:      	leaq	0x40(%rsp), %rsi
    2a85:      	movl	$0x1, %eax
    2a8a:      	callq	*%rax
    2a8c:      	testq	%rax, %rax
    2a8f:      	je	0x2b29 <generic_tracepoint_process_event+0x2b29>
    2a95:      	incl	(%rax)
    2a97:      	jmp	0x2b4d <generic_tracepoint_process_event+0x2b4d>
    2a9c:      	xorl	%eax, %eax
    2a9e:      	movq	%rax, 0x10(%rsp)
    2aa3:      	movq	0x30(%rsp), %rax
    2aa8:      	movq	0x10(%rsp), %r15
    2aad:      	movl	%r15d, (%r13,%rax)
    2ab2:      	movl	%r15d, 0x4(%r13,%rax)
    2ab7:      	addq	$0x8, %r15
    2abb:      	jmp	0x2c04 <generic_tracepoint_process_event+0x2c04>
    2ac0:      	cmpl	$0x33, %eax
    2ac3:      	je	0x2c18 <generic_tracepoint_process_event+0x2c18>
    2ac9:      	cmpl	$0x3c, %eax
    2acc:      	je	0x2b66 <generic_tracepoint_process_event+0x2b66>
    2ad2:      	cmpl	$0xff, %eax
    2ad7:      	jne	0x2cdf <generic_tracepoint_process_event+0x2cdf>
    2add:      	movw	$0x28, 0x2(%r15)
    2ae4:      	movw	$0x28, %ax
    2ae8:      	jmp	0x2c29 <generic_tracepoint_process_event+0x2c29>
    2aed:      	movl	$0x1, 0xc0(%rsp)
    2af8:      	movq	(%rip), %rdi            # 0x2aff <generic_tracepoint_process_event+0x2aff>
    2aff:      	xorl	%ecx, %ecx
    2b01:      	leaq	0x40(%rsp), %rsi
    2b06:      	leaq	0xc0(%rsp), %rdx
    2b0e:      	movl	$0x2, %eax
    2b13:      	xorl	%ecx, %ecx
    2b15:      	callq	*%rax
    2b17:      	movl	$0xfffffffc, (%rbp)     # imm = 0xFFFFFFFC
    2b1e:      	movl	$0x4, %r15d
    2b24:      	jmp	0x2c04 <generic_tracepoint_process_event+0x2c04>
    2b29:      	movl	$0x1, 0x38(%rsp)
    2b31:      	movq	(%rip), %rdi            # 0x2b38 <generic_tracepoint_process_event+0x2b38>
    2b38:      	xorl	%ecx, %ecx
    2b3a:      	leaq	0x40(%rsp), %rsi
    2b3f:      	leaq	0x38(%rsp), %rdx
    2b44:      	movl	$0x2, %eax
    2b49:      	xorl	%ecx, %ecx
    2b4b:      	callq	*%rax
    2b4d:      	movq	0x30(%rsp), %rax
    2b52:      	movl	$0xfffffffc, (%r13,%rax) # imm = 0xFFFFFFFC
    2b5b:      	movl	$0x4, %r15d
    2b61:      	jmp	0x2c04 <generic_tracepoint_process_event+0x2c04>
    2b66:      	movzbl	0x7(%r15), %eax
    2b6b:      	leal	0x8(,%rax,8), %eax
    2b72:      	jmp	0x2c24 <generic_tracepoint_process_event+0x2c24>
    2b77:      	addq	$0x5e60, %r15           # imm = 0x5E60
    2b7e:      	jmp	0x2b90 <generic_tracepoint_process_event+0x2b90>
    2b80:      	addq	$0x5e68, %r15           # imm = 0x5E68
    2b87:      	jmp	0x2b90 <generic_tracepoint_process_event+0x2b90>
    2b89:      	addq	$0x5e50, %r15           # imm = 0x5E50
    2b90:      	movq	(%r15), %rax
    2b93:      	movq	%rax, 0x38(%rsp)
    2b98:      	leaq	0xc8(%rsp), %rdi
    2ba0:      	leaq	0x38(%rsp), %rdx
    2ba5:      	movl	$0x8, %ecx
    2baa:      	movl	$0x4, %eax
    2baf:      	movl	$0x4, %r15d
    2bb5:      	movl	$0x8, %esi
    2bba:      	callq	*%rax
    2bbc:      	movq	0xc8(%rsp), %r12
    2bc4:      	cmpq	$0xfff, %r12            # imm = 0xFFF
    2bcb:      	movl	$0xfff, %r13d           # imm = 0xFFF
    2bd1:      	cmovbq	%r12, %r13
    2bd5:      	leaq	0x8(%rbp), %rdi
    2bd9:      	movl	$0x4, %eax
    2bde:      	movq	0x20(%rsp), %rdx
    2be3:      	movl	%r13d, %esi
    2be6:      	callq	*%rax
    2be8:      	testl	%eax, %eax
    2bea:      	js	0x2bfd <generic_tracepoint_process_event+0x2bfd>
    2bec:      	movl	%r12d, (%rbp)
    2bf0:      	movl	%r13d, 0x4(%rbp)
    2bf4:      	addq	$0x8, %r13
    2bf8:      	movq	%r13, %r15
    2bfb:      	jmp	0x2c04 <generic_tracepoint_process_event+0x2c04>
    2bfd:      	movl	$0xfffffffe, (%rbp)     # imm = 0xFFFFFFFE
    2c04:      	movq	0x18(%rsp), %rcx
    2c09:      	movq	0x8(%rsp), %r9
    2c0e:      	movq	0x28(%rsp), %rbx
    2c13:      	jmp	0x1f6c <generic_tracepoint_process_event+0x1f6c>
    2c18:      	movzbl	0x7(%r15), %eax
    2c1d:      	leal	0x8(,%rax,4), %eax
    2c24:      	movw	%ax, 0x2(%r15)
    2c29:      	addw	(%r15), %ax
    2c2d:      	movw	%ax, (%r15)
    2c31:      	movzbl	0x6(%r15), %ebp
    2c36:      	cmpq	$0x3c, %rbp
    2c3a:      	ja	0x33ba <generic_tracepoint_process_event+0x33ba>
    2c40:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    2c4a:      	btq	%rbp, %rcx
    2c4e:      	jae	0x33ba <generic_tracepoint_process_event+0x33ba>
    2c54:      	movb	%bpl, 0x5(%r15)
    2c58:      	movzwl	%ax, %ecx
    2c5b:      	movq	0x20(%rsp), %rsi
    2c60:      	addq	%rsi, %rcx
    2c63:      	movl	$0x2, %edx
    2c68:      	movl	$0x4, %eax
    2c6d:      	movq	0x30(%rsp), %rdi
    2c72:      	movzwl	(%r15), %edx
    2c76:      	addq	%rsi, %rdx
    2c79:      	movl	$0x2, %esi
    2c7e:      	callq	*%rax
    2c80:      	testq	%rax, %rax
    2c83:      	js	0x315e <generic_tracepoint_process_event+0x315e>
    2c89:      	movzbl	0x5(%r15), %eax
    2c8e:      	cmpl	$0x32, %eax
    2c91:      	jg	0x2cae <generic_tracepoint_process_event+0x2cae>
    2c93:      	testl	%eax, %eax
    2c95:      	je	0x2ccc <generic_tracepoint_process_event+0x2ccc>
    2c97:      	cmpl	$0x2b, %eax
    2c9a:      	je	0x2ccc <generic_tracepoint_process_event+0x2ccc>
    2c9c:      	cmpl	$0x2c, %eax
    2c9f:      	jne	0x2cfc <generic_tracepoint_process_event+0x2cfc>
    2ca1:      	movw	$0x8, 0x2(%r15)
    2ca8:      	movw	$0x8, %ax
    2cac:      	jmp	0x2d01 <generic_tracepoint_process_event+0x2d01>
    2cae:      	cmpl	$0x33, %eax
    2cb1:      	je	0x2ce9 <generic_tracepoint_process_event+0x2ce9>
    2cb3:      	cmpl	$0x3c, %eax
    2cb6:      	je	0x2ccc <generic_tracepoint_process_event+0x2ccc>
    2cb8:      	cmpl	$0xff, %eax
    2cbd:      	jne	0x2cfc <generic_tracepoint_process_event+0x2cfc>
    2cbf:      	movw	$0x28, 0x2(%r15)
    2cc6:      	movw	$0x28, %ax
    2cca:      	jmp	0x2d01 <generic_tracepoint_process_event+0x2d01>
    2ccc:      	movzbl	0x7(%r15), %eax
    2cd1:      	leal	0x8(,%rax,8), %eax
    2cd8:      	movw	%ax, 0x2(%r15)
    2cdd:      	jmp	0x2d01 <generic_tracepoint_process_event+0x2d01>
    2cdf:      	movzwl	0x2(%r15), %eax
    2ce4:      	jmp	0x2c29 <generic_tracepoint_process_event+0x2c29>
    2ce9:      	movzbl	0x7(%r15), %eax
    2cee:      	leal	0x8(,%rax,4), %eax
    2cf5:      	movw	%ax, 0x2(%r15)
    2cfa:      	jmp	0x2d01 <generic_tracepoint_process_event+0x2d01>
    2cfc:      	movzwl	0x2(%r15), %eax
    2d01:      	addw	(%r15), %ax
    2d05:      	movw	%ax, (%r15)
    2d09:      	movzbl	0x6(%r15), %ebp
    2d0e:      	cmpq	$0x3c, %rbp
    2d12:      	ja	0x33ba <generic_tracepoint_process_event+0x33ba>
    2d18:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    2d22:      	btq	%rbp, %rcx
    2d26:      	jae	0x33ba <generic_tracepoint_process_event+0x33ba>
    2d2c:      	movb	%bpl, 0x5(%r15)
    2d30:      	movzwl	%ax, %ecx
    2d33:      	movq	0x20(%rsp), %rsi
    2d38:      	addq	%rsi, %rcx
    2d3b:      	movl	$0x2, %edx
    2d40:      	movl	$0x4, %eax
    2d45:      	movq	0x30(%rsp), %rdi
    2d4a:      	movzwl	(%r15), %edx
    2d4e:      	addq	%rsi, %rdx
    2d51:      	movl	$0x2, %esi
    2d56:      	callq	*%rax
    2d58:      	testq	%rax, %rax
    2d5b:      	js	0x315e <generic_tracepoint_process_event+0x315e>
    2d61:      	movzbl	0x5(%r15), %eax
    2d66:      	cmpl	$0x32, %eax
    2d69:      	jg	0x2d86 <generic_tracepoint_process_event+0x2d86>
    2d6b:      	testl	%eax, %eax
    2d6d:      	je	0x2da4 <generic_tracepoint_process_event+0x2da4>
    2d6f:      	cmpl	$0x2b, %eax
    2d72:      	je	0x2da4 <generic_tracepoint_process_event+0x2da4>
    2d74:      	cmpl	$0x2c, %eax
    2d77:      	jne	0x2dca <generic_tracepoint_process_event+0x2dca>
    2d79:      	movw	$0x8, 0x2(%r15)
    2d80:      	movw	$0x8, %ax
    2d84:      	jmp	0x2dcf <generic_tracepoint_process_event+0x2dcf>
    2d86:      	cmpl	$0x33, %eax
    2d89:      	je	0x2db7 <generic_tracepoint_process_event+0x2db7>
    2d8b:      	cmpl	$0x3c, %eax
    2d8e:      	je	0x2da4 <generic_tracepoint_process_event+0x2da4>
    2d90:      	cmpl	$0xff, %eax
    2d95:      	jne	0x2dca <generic_tracepoint_process_event+0x2dca>
    2d97:      	movw	$0x28, 0x2(%r15)
    2d9e:      	movw	$0x28, %ax
    2da2:      	jmp	0x2dcf <generic_tracepoint_process_event+0x2dcf>
    2da4:      	movzbl	0x7(%r15), %eax
    2da9:      	leal	0x8(,%rax,8), %eax
    2db0:      	movw	%ax, 0x2(%r15)
    2db5:      	jmp	0x2dcf <generic_tracepoint_process_event+0x2dcf>
    2db7:      	movzbl	0x7(%r15), %eax
    2dbc:      	leal	0x8(,%rax,4), %eax
    2dc3:      	movw	%ax, 0x2(%r15)
    2dc8:      	jmp	0x2dcf <generic_tracepoint_process_event+0x2dcf>
    2dca:      	movzwl	0x2(%r15), %eax
    2dcf:      	addw	(%r15), %ax
    2dd3:      	movw	%ax, (%r15)
    2dd7:      	movzbl	0x6(%r15), %ebp
    2ddc:      	cmpq	$0x3c, %rbp
    2de0:      	ja	0x33ba <generic_tracepoint_process_event+0x33ba>
    2de6:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    2df0:      	btq	%rbp, %rcx
    2df4:      	jae	0x33ba <generic_tracepoint_process_event+0x33ba>
    2dfa:      	movb	%bpl, 0x5(%r15)
    2dfe:      	movzwl	%ax, %ecx
    2e01:      	movq	0x20(%rsp), %rsi
    2e06:      	addq	%rsi, %rcx
    2e09:      	movl	$0x2, %edx
    2e0e:      	movl	$0x4, %eax
    2e13:      	movq	0x30(%rsp), %rdi
    2e18:      	movzwl	(%r15), %edx
    2e1c:      	addq	%rsi, %rdx
    2e1f:      	movl	$0x2, %esi
    2e24:      	callq	*%rax
    2e26:      	testq	%rax, %rax
    2e29:      	js	0x315e <generic_tracepoint_process_event+0x315e>
    2e2f:      	movzbl	0x5(%r15), %eax
    2e34:      	cmpl	$0x32, %eax
    2e37:      	jg	0x2e54 <generic_tracepoint_process_event+0x2e54>
    2e39:      	testl	%eax, %eax
    2e3b:      	je	0x2e72 <generic_tracepoint_process_event+0x2e72>
    2e3d:      	cmpl	$0x2b, %eax
    2e40:      	je	0x2e72 <generic_tracepoint_process_event+0x2e72>
    2e42:      	cmpl	$0x2c, %eax
    2e45:      	jne	0x2e98 <generic_tracepoint_process_event+0x2e98>
    2e47:      	movw	$0x8, 0x2(%r15)
    2e4e:      	movw	$0x8, %ax
    2e52:      	jmp	0x2e9d <generic_tracepoint_process_event+0x2e9d>
    2e54:      	cmpl	$0x33, %eax
    2e57:      	je	0x2e85 <generic_tracepoint_process_event+0x2e85>
    2e59:      	cmpl	$0x3c, %eax
    2e5c:      	je	0x2e72 <generic_tracepoint_process_event+0x2e72>
    2e5e:      	cmpl	$0xff, %eax
    2e63:      	jne	0x2e98 <generic_tracepoint_process_event+0x2e98>
    2e65:      	movw	$0x28, 0x2(%r15)
    2e6c:      	movw	$0x28, %ax
    2e70:      	jmp	0x2e9d <generic_tracepoint_process_event+0x2e9d>
    2e72:      	movzbl	0x7(%r15), %eax
    2e77:      	leal	0x8(,%rax,8), %eax
    2e7e:      	movw	%ax, 0x2(%r15)
    2e83:      	jmp	0x2e9d <generic_tracepoint_process_event+0x2e9d>
    2e85:      	movzbl	0x7(%r15), %eax
    2e8a:      	leal	0x8(,%rax,4), %eax
    2e91:      	movw	%ax, 0x2(%r15)
    2e96:      	jmp	0x2e9d <generic_tracepoint_process_event+0x2e9d>
    2e98:      	movzwl	0x2(%r15), %eax
    2e9d:      	addw	(%r15), %ax
    2ea1:      	movw	%ax, (%r15)
    2ea5:      	movzbl	0x6(%r15), %ebp
    2eaa:      	cmpq	$0x3c, %rbp
    2eae:      	ja	0x33ba <generic_tracepoint_process_event+0x33ba>
    2eb4:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    2ebe:      	btq	%rbp, %rcx
    2ec2:      	jae	0x33ba <generic_tracepoint_process_event+0x33ba>
    2ec8:      	movb	%bpl, 0x5(%r15)
    2ecc:      	movzwl	%ax, %ecx
    2ecf:      	movq	0x20(%rsp), %rsi
    2ed4:      	addq	%rsi, %rcx
    2ed7:      	movl	$0x2, %edx
    2edc:      	movl	$0x4, %eax
    2ee1:      	movq	0x30(%rsp), %rdi
    2ee6:      	movzwl	(%r15), %edx
    2eea:      	addq	%rsi, %rdx
    2eed:      	movl	$0x2, %esi
    2ef2:      	callq	*%rax
    2ef4:      	testq	%rax, %rax
    2ef7:      	js	0x315e <generic_tracepoint_process_event+0x315e>
    2efd:      	movzbl	0x5(%r15), %eax
    2f02:      	cmpl	$0x32, %eax
    2f05:      	jg	0x2f22 <generic_tracepoint_process_event+0x2f22>
    2f07:      	testl	%eax, %eax
    2f09:      	je	0x2f40 <generic_tracepoint_process_event+0x2f40>
    2f0b:      	cmpl	$0x2b, %eax
    2f0e:      	je	0x2f40 <generic_tracepoint_process_event+0x2f40>
    2f10:      	cmpl	$0x2c, %eax
    2f13:      	jne	0x2f66 <generic_tracepoint_process_event+0x2f66>
    2f15:      	movw	$0x8, 0x2(%r15)
    2f1c:      	movw	$0x8, %ax
    2f20:      	jmp	0x2f6b <generic_tracepoint_process_event+0x2f6b>
    2f22:      	cmpl	$0x33, %eax
    2f25:      	je	0x2f53 <generic_tracepoint_process_event+0x2f53>
    2f27:      	cmpl	$0x3c, %eax
    2f2a:      	je	0x2f40 <generic_tracepoint_process_event+0x2f40>
    2f2c:      	cmpl	$0xff, %eax
    2f31:      	jne	0x2f66 <generic_tracepoint_process_event+0x2f66>
    2f33:      	movw	$0x28, 0x2(%r15)
    2f3a:      	movw	$0x28, %ax
    2f3e:      	jmp	0x2f6b <generic_tracepoint_process_event+0x2f6b>
    2f40:      	movzbl	0x7(%r15), %eax
    2f45:      	leal	0x8(,%rax,8), %eax
    2f4c:      	movw	%ax, 0x2(%r15)
    2f51:      	jmp	0x2f6b <generic_tracepoint_process_event+0x2f6b>
    2f53:      	movzbl	0x7(%r15), %eax
    2f58:      	leal	0x8(,%rax,4), %eax
    2f5f:      	movw	%ax, 0x2(%r15)
    2f64:      	jmp	0x2f6b <generic_tracepoint_process_event+0x2f6b>
    2f66:      	movzwl	0x2(%r15), %eax
    2f6b:      	addw	(%r15), %ax
    2f6f:      	movw	%ax, (%r15)
    2f73:      	movzbl	0x6(%r15), %ebp
    2f78:      	cmpq	$0x3c, %rbp
    2f7c:      	ja	0x33ba <generic_tracepoint_process_event+0x33ba>
    2f82:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    2f8c:      	btq	%rbp, %rcx
    2f90:      	jae	0x33ba <generic_tracepoint_process_event+0x33ba>
    2f96:      	movb	%bpl, 0x5(%r15)
    2f9a:      	movzwl	%ax, %ecx
    2f9d:      	movq	0x20(%rsp), %rsi
    2fa2:      	addq	%rsi, %rcx
    2fa5:      	movl	$0x2, %edx
    2faa:      	movl	$0x4, %eax
    2faf:      	movq	0x30(%rsp), %rdi
    2fb4:      	movzwl	(%r15), %edx
    2fb8:      	addq	%rsi, %rdx
    2fbb:      	movl	$0x2, %esi
    2fc0:      	callq	*%rax
    2fc2:      	testq	%rax, %rax
    2fc5:      	js	0x315e <generic_tracepoint_process_event+0x315e>
    2fcb:      	movzbl	0x5(%r15), %eax
    2fd0:      	cmpl	$0x32, %eax
    2fd3:      	jg	0x2ff0 <generic_tracepoint_process_event+0x2ff0>
    2fd5:      	testl	%eax, %eax
    2fd7:      	je	0x300e <generic_tracepoint_process_event+0x300e>
    2fd9:      	cmpl	$0x2b, %eax
    2fdc:      	je	0x300e <generic_tracepoint_process_event+0x300e>
    2fde:      	cmpl	$0x2c, %eax
    2fe1:      	jne	0x3034 <generic_tracepoint_process_event+0x3034>
    2fe3:      	movw	$0x8, 0x2(%r15)
    2fea:      	movw	$0x8, %ax
    2fee:      	jmp	0x3039 <generic_tracepoint_process_event+0x3039>
    2ff0:      	cmpl	$0x33, %eax
    2ff3:      	je	0x3021 <generic_tracepoint_process_event+0x3021>
    2ff5:      	cmpl	$0x3c, %eax
    2ff8:      	je	0x300e <generic_tracepoint_process_event+0x300e>
    2ffa:      	cmpl	$0xff, %eax
    2fff:      	jne	0x3034 <generic_tracepoint_process_event+0x3034>
    3001:      	movw	$0x28, 0x2(%r15)
    3008:      	movw	$0x28, %ax
    300c:      	jmp	0x3039 <generic_tracepoint_process_event+0x3039>
    300e:      	movzbl	0x7(%r15), %eax
    3013:      	leal	0x8(,%rax,8), %eax
    301a:      	movw	%ax, 0x2(%r15)
    301f:      	jmp	0x3039 <generic_tracepoint_process_event+0x3039>
    3021:      	movzbl	0x7(%r15), %eax
    3026:      	leal	0x8(,%rax,4), %eax
    302d:      	movw	%ax, 0x2(%r15)
    3032:      	jmp	0x3039 <generic_tracepoint_process_event+0x3039>
    3034:      	movzwl	0x2(%r15), %eax
    3039:      	addw	(%r15), %ax
    303d:      	movw	%ax, (%r15)
    3041:      	movzbl	0x6(%r15), %ebp
    3046:      	cmpq	$0x3c, %rbp
    304a:      	ja	0x33ba <generic_tracepoint_process_event+0x33ba>
    3050:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    305a:      	btq	%rbp, %rcx
    305e:      	jae	0x33ba <generic_tracepoint_process_event+0x33ba>
    3064:      	movb	%bpl, 0x5(%r15)
    3068:      	movzwl	%ax, %ecx
    306b:      	movq	0x20(%rsp), %rsi
    3070:      	addq	%rsi, %rcx
    3073:      	movl	$0x2, %edx
    3078:      	movl	$0x4, %eax
    307d:      	movq	0x30(%rsp), %rdi
    3082:      	movzwl	(%r15), %edx
    3086:      	addq	%rsi, %rdx
    3089:      	movl	$0x2, %esi
    308e:      	callq	*%rax
    3090:      	testq	%rax, %rax
    3093:      	js	0x315e <generic_tracepoint_process_event+0x315e>
    3099:      	movzbl	0x5(%r15), %eax
    309e:      	cmpl	$0x32, %eax
    30a1:      	jg	0x30be <generic_tracepoint_process_event+0x30be>
    30a3:      	testl	%eax, %eax
    30a5:      	je	0x30dc <generic_tracepoint_process_event+0x30dc>
    30a7:      	cmpl	$0x2b, %eax
    30aa:      	je	0x30dc <generic_tracepoint_process_event+0x30dc>
    30ac:      	cmpl	$0x2c, %eax
    30af:      	jne	0x3102 <generic_tracepoint_process_event+0x3102>
    30b1:      	movw	$0x8, 0x2(%r15)
    30b8:      	movw	$0x8, %ax
    30bc:      	jmp	0x3107 <generic_tracepoint_process_event+0x3107>
    30be:      	cmpl	$0x33, %eax
    30c1:      	je	0x30ef <generic_tracepoint_process_event+0x30ef>
    30c3:      	cmpl	$0x3c, %eax
    30c6:      	je	0x30dc <generic_tracepoint_process_event+0x30dc>
    30c8:      	cmpl	$0xff, %eax
    30cd:      	jne	0x3102 <generic_tracepoint_process_event+0x3102>
    30cf:      	movw	$0x28, 0x2(%r15)
    30d6:      	movw	$0x28, %ax
    30da:      	jmp	0x3107 <generic_tracepoint_process_event+0x3107>
    30dc:      	movzbl	0x7(%r15), %eax
    30e1:      	leal	0x8(,%rax,8), %eax
    30e8:      	movw	%ax, 0x2(%r15)
    30ed:      	jmp	0x3107 <generic_tracepoint_process_event+0x3107>
    30ef:      	movzbl	0x7(%r15), %eax
    30f4:      	leal	0x8(,%rax,4), %eax
    30fb:      	movw	%ax, 0x2(%r15)
    3100:      	jmp	0x3107 <generic_tracepoint_process_event+0x3107>
    3102:      	movzwl	0x2(%r15), %eax
    3107:      	addw	(%r15), %ax
    310b:      	movw	%ax, (%r15)
    310f:      	movzbl	0x6(%r15), %ebp
    3114:      	cmpq	$0x3c, %rbp
    3118:      	ja	0x33ba <generic_tracepoint_process_event+0x33ba>
    311e:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3128:      	btq	%rbp, %rcx
    312c:      	jae	0x33ba <generic_tracepoint_process_event+0x33ba>
    3132:      	movb	%bpl, 0x5(%r15)
    3136:      	movzwl	%ax, %ecx
    3139:      	movq	0x20(%rsp), %rsi
    313e:      	addq	%rsi, %rcx
    3141:      	movl	$0x2, %edx
    3146:      	movl	$0x4, %eax
    314b:      	movq	0x30(%rsp), %rdi
    3150:      	movzwl	(%r15), %edx
    3154:      	addq	%rsi, %rdx
    3157:      	movl	$0x2, %esi
    315c:      	callq	*%rax
    315e:      	xorl	%ebp, %ebp
    3160:      	movb	%bpl, 0xac(%rsp)
    3168:      	movzbl	%bpl, %eax
    316c:      	movq	0x10(%rsp), %r15
    3171:      	movw	%ax, 0x24(%r15)
    3176:      	movw	$0xa, 0x26(%r15)
    317d:      	leaq	0x8(%r13), %rdx
    3181:      	movl	$0x10, %ecx
    3186:      	movl	$0x4, %eax
    318b:      	movq	%r15, %rdi
    318e:      	movl	$0x10, %esi
    3193:      	callq	*%rax
    3195:      	leaq	0x10(%r15), %rdi
    3199:      	addq	$0x18, %r13
    319d:      	movl	$0x10, %ecx
    31a2:      	movl	$0x4, %eax
    31a7:      	movl	$0x10, %esi
    31ac:      	movq	%r13, %rdx
    31af:      	callq	*%rax
    31b1:      	cmpb	$0x11, %bpl
    31b5:      	je	0x3208 <generic_tracepoint_process_event+0x3208>
    31b7:      	movzbl	%bpl, %eax
    31bb:      	cmpl	$0x6, %eax
    31be:      	jne	0x3253 <generic_tracepoint_process_event+0x3253>
    31c4:      	movq	0x58(%rsp), %r15
    31c9:      	movzwl	0xd0(%rsp), %r13d
    31d2:      	leaq	(%r15,%r13), %rdx
    31d6:      	movq	0x10(%rsp), %rbp
    31db:      	leaq	0x20(%rbp), %rdi
    31df:      	movl	$0x2, %ecx
    31e4:      	movl	$0x4, %eax
    31e9:      	movl	$0x2, %esi
    31ee:      	callq	*%rax
    31f0:      	leaq	0x22(%rbp), %rdi
    31f4:      	leaq	(%r15,%r13), %rdx
    31f8:      	addq	$0x2, %rdx
    31fc:      	movl	$0x2, %ecx
    3201:      	movl	$0x4, %eax
    3206:      	jmp	0x324a <generic_tracepoint_process_event+0x324a>
    3208:      	movq	0x58(%rsp), %r15
    320d:      	movzwl	0xd0(%rsp), %r13d
    3216:      	leaq	(%r15,%r13), %rdx
    321a:      	movq	0x10(%rsp), %rbp
    321f:      	leaq	0x20(%rbp), %rdi
    3223:      	movl	$0x2, %ecx
    3228:      	movl	$0x4, %eax
    322d:      	movl	$0x2, %esi
    3232:      	callq	*%rax
    3234:      	leaq	0x22(%rbp), %rdi
    3238:      	leaq	(%r15,%r13), %rdx
    323c:      	addq	$0x2, %rdx
    3240:      	movl	$0x2, %ecx
    3245:      	movl	$0x4, %eax
    324a:      	movl	$0x2, %esi
    324f:      	callq	*%rax
    3251:      	jmp	0x325f <generic_tracepoint_process_event+0x325f>
    3253:      	movq	0x10(%rsp), %rax
    3258:      	movl	$0x0, 0x20(%rax)
    325f:      	movq	0x10(%rsp), %rdx
    3264:      	movzwl	0x20(%rdx), %eax
    3268:      	movzwl	0x22(%rdx), %ecx
    326c:      	movbew	%ax, 0x20(%rdx)
    3272:      	movbew	%cx, 0x22(%rdx)
    3278:      	addq	$0xe0, %r12
    327f:      	leaq	0x98(%rsp), %rdi
    3287:      	movl	$0x8, %ecx
    328c:      	movl	$0x4, %eax
    3291:      	movl	$0x4, %r15d
    3297:      	movl	$0x8, %esi
    329c:      	movq	%r12, %rdx
    329f:      	callq	*%rax
    32a1:      	movq	0x98(%rsp), %rcx
    32a9:      	testq	%rcx, %rcx
    32ac:      	je	0x3319 <generic_tracepoint_process_event+0x3319>
    32ae:      	addq	$0x5, %rcx
    32b2:      	leaq	0x40(%rsp), %rdi
    32b7:      	movl	$0x8, %edx
    32bc:      	movl	$0x4, %eax
    32c1:      	movq	0x98(%rsp), %rdx
    32c9:      	addq	$0x5, %rdx
    32cd:      	movl	$0x8, %esi
    32d2:      	callq	*%rax
    32d4:      	movq	0x98(%rsp), %r12
    32dc:      	movq	0x40(%rsp), %r13
    32e1:      	movq	0x10(%rsp), %rbp
    32e6:      	leaq	0x38(%rbp), %rdi
    32ea:      	leaq	(%r12,%r13,8), %rdx
    32ee:      	addq	$0x44, %rdx
    32f2:      	movl	$0x4, %eax
    32f7:      	movl	$0x4, %esi
    32fc:      	callq	*%rax
    32fe:      	addq	$0x3c, %rbp
    3302:      	leaq	(%r12,%r13,8), %rdx
    3306:      	addq	$0x45, %rdx
    330a:      	movl	$0x4, %eax
    330f:      	movq	%rbp, %rdi
    3312:      	movl	$0x4, %esi
    3317:      	callq	*%rax
    3319:      	movl	$0x40, %r15d
    331f:      	movq	0x18(%rsp), %rcx
    3324:      	movq	0x50(%rsp), %rbp
    3329:      	movq	0x8(%rsp), %r9
    332e:      	movq	0x28(%rsp), %rbx
    3333:      	movq	0xb0(%rsp), %r12
    333b:      	testl	%r15d, %r15d
    333e:      	js	0x3350 <generic_tracepoint_process_event+0x3350>
    3340:      	andl	$0x7fffffff, %r15d      # imm = 0x7FFFFFFF
    3347:      	addl	$0x4, %r15d
    334b:      	movl	%r15d, %edx
    334e:      	jmp	0x336d <generic_tracepoint_process_event+0x336d>
    3350:      	movl	$0xffffffff, 0x5ea0(%rcx,%r9,4) # imm = 0xFFFFFFFF
    335c:      	movl	$0xffffffff, 0x90(%rcx,%r12) # imm = 0xFFFFFFFF
    3368:      	movl	$0x4, %edx
    336d:      	addl	%r12d, %edx
    3370:      	movl	%edx, %r12d
    3373:      	movl	%r12d, 0x4(%r14)
    3377:      	cmpl	$0x3, %ebp
    337a:      	jle	0x451 <generic_tracepoint_process_event+0x451>
    3380:      	movl	$0x0, 0x5efc(%r14)
    338b:      	movq	(%rip), %rsi            # 0x3392 <generic_tracepoint_process_event+0x3392>
    3392:      	movl	$0x3, %ecx
    3397:      	movl	$0xc, %eax
    339c:      	movq	%rbx, %rdi
    339f:      	movl	$0x3, %edx
    33a4:      	callq	*%rax
    33a6:      	xorl	%eax, %eax
    33a8:      	addq	$0x108, %rsp            # imm = 0x108
    33af:      	popq	%rbx
    33b0:      	popq	%r12
    33b2:      	popq	%r13
    33b4:      	popq	%r14
    33b6:      	popq	%r15
    33b8:      	popq	%rbp
    33b9:      	retq
    33ba:      	movw	%ax, 0xd0(%rsp)
    33c2:      	jmp	0x3160 <generic_tracepoint_process_event+0x3160>
    33c7:      	nopw	(%rax,%rax)

00000000000033d0 <generic_tracepoint_filter>:
    33d0:      	pushq	%rbp
    33d1:      	pushq	%r15
    33d3:      	pushq	%r14
    33d5:      	pushq	%r13
    33d7:      	pushq	%r12
    33d9:      	pushq	%rbx
    33da:      	subq	$0xe8, %rsp
    33e1:      	movq	%rdi, %rbx
    33e4:      	movl	$0x0, 0xc8(%rsp)
    33ef:      	movq	(%rip), %rdi            # 0x33f6 <generic_tracepoint_filter+0x26>
    33f6:      	leaq	0xc8(%rsp), %rsi
    33fe:      	movl	$0x1, %eax
    3403:      	callq	*%rax
    3405:      	testq	%rax, %rax
    3408:      	je	0x59f9 <generic_tracepoint_filter+0x2629>
    340e:      	movq	%rax, %r14
    3411:      	movl	$0x23, %eax
    3416:      	callq	*%rax
    3418:      	movq	%rax, %rcx
    341b:      	movq	%rax, 0x60(%rsp)
    3420:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3427:      	leaq	0x10(%rsp), %rdi
    342c:      	movl	$0x4, %edx
    3431:      	movl	$0x71, %eax
    3436:      	movl	$0xaf4, %edx            # imm = 0xAF4
    343b:      	addq	0x60(%rsp), %rdx
    3440:      	movl	$0x4, %esi
    3445:      	callq	*%rax
    3447:      	movl	0x10(%rsp), %eax
    344b:      	movl	%eax, 0x40(%rsp)
    344f:      	movq	(%rip), %rdi            # 0x3456 <generic_tracepoint_filter+0x86>
    3456:      	leaq	0x40(%rsp), %rsi
    345b:      	movl	$0x1, %eax
    3460:      	callq	*%rax
    3462:      	testq	%rax, %rax
    3465:      	movq	%r14, 0x50(%rsp)
    346a:      	je	0x347a <generic_tracepoint_filter+0xaa>
    346c:      	movq	%rax, %r15
    346f:      	cmpq	$0x0, 0x8(%rax)
    3474:      	jne	0x43ff <generic_tracepoint_filter+0x102f>
    347a:      	movl	$0xb00, %edx            # imm = 0xB00
    347f:      	movq	0x60(%rsp), %rcx
    3484:      	addq	%rdx, %rcx
    3487:      	leaq	0x60(%rsp), %rdi
    348c:      	movl	$0x8, %esi
    3491:      	movl	$0x71, %eax
    3496:      	addq	0x60(%rsp), %rdx
    349b:      	movl	$0x8, %esi
    34a0:      	callq	*%rax
    34a2:      	movq	0x60(%rsp), %rcx
    34a7:      	testq	%rcx, %rcx
    34aa:      	je	0x363f <generic_tracepoint_filter+0x26f>
    34b0:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    34b7:      	leaq	0x10(%rsp), %rdi
    34bc:      	movl	$0x4, %edx
    34c1:      	movl	$0x71, %eax
    34c6:      	movl	$0xaf4, %edx            # imm = 0xAF4
    34cb:      	addq	0x60(%rsp), %rdx
    34d0:      	movl	$0x4, %esi
    34d5:      	callq	*%rax
    34d7:      	movl	0x10(%rsp), %eax
    34db:      	movl	%eax, 0x40(%rsp)
    34df:      	movq	(%rip), %rdi            # 0x34e6 <generic_tracepoint_filter+0x116>
    34e6:      	leaq	0x40(%rsp), %rsi
    34eb:      	movl	$0x1, %eax
    34f0:      	callq	*%rax
    34f2:      	testq	%rax, %rax
    34f5:      	je	0x3505 <generic_tracepoint_filter+0x135>
    34f7:      	movq	%rax, %r15
    34fa:      	cmpq	$0x0, 0x8(%rax)
    34ff:      	jne	0x43ff <generic_tracepoint_filter+0x102f>
    3505:      	movl	$0xb00, %edx            # imm = 0xB00
    350a:      	movq	0x60(%rsp), %rcx
    350f:      	addq	%rdx, %rcx
    3512:      	leaq	0x60(%rsp), %rdi
    3517:      	movl	$0x8, %esi
    351c:      	movl	$0x71, %eax
    3521:      	addq	0x60(%rsp), %rdx
    3526:      	movl	$0x8, %esi
    352b:      	callq	*%rax
    352d:      	movq	0x60(%rsp), %rcx
    3532:      	testq	%rcx, %rcx
    3535:      	je	0x363f <generic_tracepoint_filter+0x26f>
    353b:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3542:      	leaq	0x10(%rsp), %rdi
    3547:      	movl	$0x4, %edx
    354c:      	movl	$0x71, %eax
    3551:      	movl	$0xaf4, %edx            # imm = 0xAF4
    3556:      	addq	0x60(%rsp), %rdx
    355b:      	movl	$0x4, %esi
    3560:      	callq	*%rax
    3562:      	movl	0x10(%rsp), %eax
    3566:      	movl	%eax, 0x40(%rsp)
    356a:      	movq	(%rip), %rdi            # 0x3571 <generic_tracepoint_filter+0x1a1>
    3571:      	leaq	0x40(%rsp), %rsi
    3576:      	movl	$0x1, %eax
    357b:      	callq	*%rax
    357d:      	testq	%rax, %rax
    3580:      	je	0x3590 <generic_tracepoint_filter+0x1c0>
    3582:      	movq	%rax, %r15
    3585:      	cmpq	$0x0, 0x8(%rax)
    358a:      	jne	0x43ff <generic_tracepoint_filter+0x102f>
    3590:      	movl	$0xb00, %edx            # imm = 0xB00
    3595:      	movq	0x60(%rsp), %rcx
    359a:      	addq	%rdx, %rcx
    359d:      	leaq	0x60(%rsp), %rdi
    35a2:      	movl	$0x8, %esi
    35a7:      	movl	$0x71, %eax
    35ac:      	addq	0x60(%rsp), %rdx
    35b1:      	movl	$0x8, %esi
    35b6:      	callq	*%rax
    35b8:      	movq	0x60(%rsp), %rcx
    35bd:      	testq	%rcx, %rcx
    35c0:      	je	0x363f <generic_tracepoint_filter+0x26f>
    35c2:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    35c9:      	leaq	0x10(%rsp), %rdi
    35ce:      	movl	$0x4, %edx
    35d3:      	movl	$0x71, %eax
    35d8:      	movl	$0xaf4, %edx            # imm = 0xAF4
    35dd:      	addq	0x60(%rsp), %rdx
    35e2:      	movl	$0x4, %esi
    35e7:      	callq	*%rax
    35e9:      	movl	0x10(%rsp), %eax
    35ed:      	movl	%eax, 0x40(%rsp)
    35f1:      	movq	(%rip), %rdi            # 0x35f8 <generic_tracepoint_filter+0x228>
    35f8:      	leaq	0x40(%rsp), %rsi
    35fd:      	movl	$0x1, %eax
    3602:      	callq	*%rax
    3604:      	testq	%rax, %rax
    3607:      	je	0x3617 <generic_tracepoint_filter+0x247>
    3609:      	movq	%rax, %r15
    360c:      	cmpq	$0x0, 0x8(%rax)
    3611:      	jne	0x43ff <generic_tracepoint_filter+0x102f>
    3617:      	movl	$0xb00, %edx            # imm = 0xB00
    361c:      	movq	0x60(%rsp), %rcx
    3621:      	addq	%rdx, %rcx
    3624:      	leaq	0x60(%rsp), %rdi
    3629:      	movl	$0x8, %esi
    362e:      	movl	$0x71, %eax
    3633:      	addq	0x60(%rsp), %rdx
    3638:      	movl	$0x8, %esi
    363d:      	callq	*%rax
    363f:      	movq	%rbx, 0xb8(%rsp)
    3647:      	movl	$0x23, %eax
    364c:      	callq	*%rax
    364e:      	movq	%rax, %r13
    3651:      	leaq	0xaf4(%rax), %rdx
    3658:      	leaq	0x60(%rsp), %rdi
    365d:      	movl	$0x4, %ecx
    3662:      	movl	$0x4, %eax
    3667:      	movl	$0x4, %ebp
    366c:      	movl	$0x4, %esi
    3671:      	callq	*%rax
    3673:      	movl	0x60(%rsp), %eax
    3677:      	movl	%eax, 0x5f10(%r14)
    367e:      	movl	$0x7d, %eax
    3683:      	callq	*%rax
    3685:      	movq	%rax, 0x5f18(%r14)
    368c:      	movl	$0x0, 0x5f20(%r14)
    3697:      	movq	$0x0, 0x5f28(%r14)
    36a2:      	movl	$0x0, 0x5f30(%r14)
    36ad:      	leaq	0x60(%r13), %rdx
    36b1:      	leaq	0x40(%rsp), %rdi
    36b6:      	movl	$0x8, %ecx
    36bb:      	movl	$0x71, %eax
    36c0:      	movl	$0x8, %esi
    36c5:      	callq	*%rax
    36c7:      	movq	0x40(%rsp), %rcx
    36cc:      	xorl	%ebx, %ebx
    36ce:      	testq	%rcx, %rcx
    36d1:      	je	0x3740 <generic_tracepoint_filter+0x370>
    36d3:      	addq	$0x4, %rcx
    36d7:      	leaq	0x10(%rsp), %rdi
    36dc:      	movl	$0x4, %edx
    36e1:      	movl	$0x71, %eax
    36e6:      	movq	0x40(%rsp), %rdx
    36eb:      	addq	$0x4, %rdx
    36ef:      	movl	$0x4, %esi
    36f4:      	callq	*%rax
    36f6:      	movl	0x10(%rsp), %eax
    36fa:      	testl	%eax, %eax
    36fc:      	je	0x3740 <generic_tracepoint_filter+0x370>
    36fe:      	movq	0x40(%rsp), %rcx
    3703:      	shll	$0x4, %eax
    3706:      	addq	%rax, %rcx
    3709:      	addq	$0x80, %rcx
    3710:      	leaq	0x60(%rsp), %rdi
    3715:      	movl	$0x10, %edx
    371a:      	movl	$0x71, %eax
    371f:      	movq	0x40(%rsp), %rcx
    3724:      	movl	0x10(%rsp), %edx
    3728:      	shll	$0x4, %edx
    372b:      	addq	%rcx, %rdx
    372e:      	addq	$0x80, %rdx
    3735:      	movl	$0x10, %esi
    373a:      	callq	*%rax
    373c:      	movl	0x60(%rsp), %ebx
    3740:      	movl	%ebx, 0x5f34(%r14)
    3747:      	leaq	0xd00(%r13), %r15
    374e:      	leaq	0x60(%rsp), %rdi
    3753:      	movl	$0x8, %ecx
    3758:      	movl	$0x4, %eax
    375d:      	leaq	0x5f60(%r14), %rbx
    3764:      	movl	$0x8, %esi
    3769:      	movq	%r15, %rdx
    376c:      	callq	*%rax
    376e:      	movq	0x60(%rsp), %r12
    3773:      	leaq	0x5f68(%r14), %rdi
    377a:      	leaq	0x40(%r12), %rdx
    377f:      	movl	$0x8, %ecx
    3784:      	movl	$0x4, %eax
    3789:      	movl	$0x8, %esi
    378e:      	callq	*%rax
    3790:      	leaq	0x5f70(%r14), %rdi
    3797:      	leaq	0x30(%r12), %rdx
    379c:      	movl	$0x8, %ecx
    37a1:      	movl	$0x4, %eax
    37a6:      	movl	$0x8, %esi
    37ab:      	callq	*%rax
    37ad:      	addq	$0x38, %r12
    37b1:      	movl	$0x8, %ecx
    37b6:      	movl	$0x4, %eax
    37bb:      	movq	%rbx, %rdi
    37be:      	movl	$0x8, %esi
    37c3:      	movq	%r12, %rdx
    37c6:      	callq	*%rax
    37c8:      	leaq	0x5f38(%r14), %rbx
    37cf:      	leaq	0xd70(%r13), %rdx
    37d6:      	leaq	0x10(%rsp), %rdi
    37db:      	movl	$0x8, %ecx
    37e0:      	movl	$0x4, %eax
    37e5:      	movl	$0x8, %esi
    37ea:      	callq	*%rax
    37ec:      	movq	0x10(%rsp), %rcx
    37f1:      	leaq	0x60(%rsp), %rdi
    37f6:      	movl	$0x48, %edx
    37fb:      	movl	$0x4, %eax
    3800:      	movq	0x10(%rsp), %rdx
    3805:      	movl	$0x48, %esi
    380a:      	callq	*%rax
    380c:      	movl	$0x218, %edx            # imm = 0x218
    3811:      	movq	0x68(%rsp), %rcx
    3816:      	addq	%rdx, %rcx
    3819:      	movl	$0x4, %eax
    381e:      	addq	0x68(%rsp), %rdx
    3823:      	movq	%rbx, %rdi
    3826:      	movl	$0x4, %esi
    382b:      	callq	*%rax
    382d:      	leaq	0x5f3c(%r14), %rdi
    3834:      	movl	$0x4d8, %edx            # imm = 0x4D8
    3839:      	movq	0x70(%rsp), %rcx
    383e:      	addq	%rdx, %rcx
    3841:      	movl	$0x4, %eax
    3846:      	addq	0x70(%rsp), %rdx
    384b:      	movl	$0x4, %esi
    3850:      	callq	*%rax
    3852:      	leaq	0x5f40(%r14), %rdi
    3859:      	movq	0x78(%rsp), %rcx
    385e:      	addq	$0x58, %rcx
    3862:      	movl	$0x4, %eax
    3867:      	movq	0x78(%rsp), %rdx
    386c:      	addq	$0x58, %rdx
    3870:      	movl	$0x4, %esi
    3875:      	callq	*%rax
    3877:      	movq	$0x0, 0x58(%rsp)
    3880:      	leaq	0xb58(%r13), %rdx
    3887:      	leaq	0x58(%rsp), %rdi
    388c:      	movl	$0x8, %ecx
    3891:      	movl	$0x4, %eax
    3896:      	movl	$0x8, %esi
    389b:      	callq	*%rax
    389d:      	movq	0x58(%rsp), %rcx
    38a2:      	testq	%rcx, %rcx
    38a5:      	je	0x3954 <generic_tracepoint_filter+0x584>
    38ab:      	movl	$0x0, 0xa8(%rsp)
    38b6:      	addq	$0x4, %rcx
    38ba:      	leaq	0xa8(%rsp), %rdi
    38c2:      	movl	$0x4, %edx
    38c7:      	movl	$0x4, %eax
    38cc:      	movq	0x58(%rsp), %rdx
    38d1:      	addq	$0x4, %rdx
    38d5:      	movl	$0x4, %esi
    38da:      	callq	*%rax
    38dc:      	movq	0x58(%rsp), %rax
    38e1:      	movslq	0xa8(%rsp), %rcx
    38e9:      	shlq	$0x4, %rcx
    38ed:      	addq	%rax, %rcx
    38f0:      	addq	$0x80, %rcx
    38f7:      	leaq	0x40(%rsp), %rdi
    38fc:      	movl	$0x10, %edx
    3901:      	movl	$0x4, %eax
    3906:      	movq	0x58(%rsp), %rcx
    390b:      	movslq	0xa8(%rsp), %rdx
    3913:      	shlq	$0x4, %rdx
    3917:      	addq	%rcx, %rdx
    391a:      	addq	$0x80, %rdx
    3921:      	movl	$0x10, %esi
    3926:      	callq	*%rax
    3928:      	leaq	0x5f44(%r14), %rdi
    392f:      	movl	$0x158, %edx            # imm = 0x158
    3934:      	movq	0x48(%rsp), %rcx
    3939:      	addq	%rdx, %rcx
    393c:      	movl	$0x4, %esi
    3941:      	movl	$0x4, %eax
    3946:      	addq	0x48(%rsp), %rdx
    394b:      	movl	$0x4, %esi
    3950:      	callq	*%rax
    3952:      	jmp	0x395f <generic_tracepoint_filter+0x58f>
    3954:      	movl	$0x0, 0x5f44(%r14)
    395f:      	leaq	0x5f48(%r14), %rdi
    3966:      	movl	$0x158, %ebx            # imm = 0x158
    396b:      	movq	0x80(%rsp), %rcx
    3973:      	addq	%rbx, %rcx
    3976:      	movl	$0x4, %edx
    397b:      	movl	$0x4, %eax
    3980:      	movq	0x80(%rsp), %rdx
    3988:      	addq	%rbx, %rdx
    398b:      	movl	$0x4, %esi
    3990:      	callq	*%rax
    3992:      	leaq	0x5f4c(%r14), %rdi
    3999:      	movl	$0x118, %edx            # imm = 0x118
    399e:      	movq	0x88(%rsp), %rcx
    39a6:      	addq	%rdx, %rcx
    39a9:      	movl	$0x4, %esi
    39ae:      	movl	$0x4, %eax
    39b3:      	addq	0x88(%rsp), %rdx
    39bb:      	movl	$0x4, %esi
    39c0:      	callq	*%rax
    39c2:      	leaq	0x5f50(%r14), %rdi
    39c9:      	movl	$0x98, %r12d
    39cf:      	movq	0x90(%rsp), %rcx
    39d7:      	addq	%r12, %rcx
    39da:      	movl	$0x4, %edx
    39df:      	movl	$0x4, %eax
    39e4:      	movq	0x90(%rsp), %rdx
    39ec:      	addq	%r12, %rdx
    39ef:      	movl	$0x4, %esi
    39f4:      	callq	*%rax
    39f6:      	leaq	0x5f54(%r14), %rdi
    39fd:      	movq	0x98(%rsp), %rcx
    3a05:      	addq	%r12, %rcx
    3a08:      	movl	$0x4, %edx
    3a0d:      	movl	$0x4, %eax
    3a12:      	addq	0x98(%rsp), %r12
    3a1a:      	movl	$0x4, %esi
    3a1f:      	movq	%r12, %rdx
    3a22:      	callq	*%rax
    3a24:      	leaq	0x5f58(%r14), %rdi
    3a2b:      	movq	0xa0(%rsp), %rcx
    3a33:      	addq	$0x58, %rcx
    3a37:      	movl	$0x4, %edx
    3a3c:      	movl	$0x4, %eax
    3a41:      	movq	0xa0(%rsp), %rdx
    3a49:      	addq	$0x58, %rdx
    3a4d:      	movl	$0x4, %esi
    3a52:      	callq	*%rax
    3a54:      	movq	$0x0, 0x40(%rsp)
    3a5d:      	movq	$0x0, 0x58(%rsp)
    3a66:      	leaq	0x40(%rsp), %rdi
    3a6b:      	movl	$0x8, %ecx
    3a70:      	movl	$0x4, %eax
    3a75:      	movl	$0x8, %esi
    3a7a:      	movq	%r15, %rdx
    3a7d:      	callq	*%rax
    3a7f:      	movl	$0x90, %edx
    3a84:      	movq	0x40(%rsp), %rcx
    3a89:      	addq	%rdx, %rcx
    3a8c:      	leaq	0x58(%rsp), %rdi
    3a91:      	movl	$0x8, %esi
    3a96:      	movl	$0x4, %eax
    3a9b:      	addq	0x40(%rsp), %rdx
    3aa0:      	movl	$0x8, %esi
    3aa5:      	callq	*%rax
    3aa7:      	leaq	0x5f5c(%r14), %rdi
    3aae:      	movq	0x58(%rsp), %rcx
    3ab3:      	addq	%rbx, %rcx
    3ab6:      	movl	$0x4, %edx
    3abb:      	movl	$0x4, %eax
    3ac0:      	addq	0x58(%rsp), %rbx
    3ac5:      	movl	$0x4, %esi
    3aca:      	movq	%rbx, %rdx
    3acd:      	callq	*%rax
    3acf:      	cmpl	$0x1, 0x5f34(%r14)
    3ad7:      	jne	0x3ae1 <generic_tracepoint_filter+0x711>
    3ad9:      	orb	$0x2, 0x5f33(%r14)
    3ae1:      	leaq	0x5f78(%r14), %rdi
    3ae8:      	movl	$0x308, %edx            # imm = 0x308
    3aed:      	movq	%rdi, 0x8(%rsp)
    3af2:      	xorl	%esi, %esi
    3af4:      	callq	0x3af9 <generic_tracepoint_filter+0x729>
    3af9:      	leaq	0x6290(%r14), %rbp
    3b00:      	addq	$0xa78, %r13            # imm = 0xA78
    3b07:      	leaq	0x40(%rsp), %rdi
    3b0c:      	movl	$0x8, %ecx
    3b11:      	movl	$0x4, %eax
    3b16:      	movl	$0x8, %esi
    3b1b:      	movq	%r13, %rdx
    3b1e:      	callq	*%rax
    3b20:      	movl	$0x5f8, %edx            # imm = 0x5F8
    3b25:      	movq	0x40(%rsp), %rcx
    3b2a:      	addq	%rdx, %rcx
    3b2d:      	leaq	0x60(%rsp), %rdi
    3b32:      	movl	$0x8, %esi
    3b37:      	movl	$0x4, %eax
    3b3c:      	addq	0x40(%rsp), %rdx
    3b41:      	movl	$0x8, %esi
    3b46:      	callq	*%rax
    3b48:      	movq	0x60(%rsp), %rbx
    3b4d:      	movl	$0x0, 0xcc(%rsp)
    3b58:      	movq	(%rip), %rdi            # 0x3b5f <generic_tracepoint_filter+0x78f>
    3b5f:      	leaq	0xcc(%rsp), %rsi
    3b67:      	movl	$0x1, %eax
    3b6c:      	callq	*%rax
    3b6e:      	testq	%rax, %rax
    3b71:      	je	0x4277 <generic_tracepoint_filter+0xea7>
    3b77:      	movq	%rax, %r12
    3b7a:      	movq	%rbp, 0x38(%rsp)
    3b7f:      	movl	$0x1000, 0x6410(%r14)   # imm = 0x1000
    3b8a:      	leaq	0x1000(%rax), %r13
    3b91:      	movl	$0x23, %eax
    3b96:      	callq	*%rax
    3b98:      	leaq	0xd50(%rax), %rdx
    3b9f:      	leaq	0xd8(%rsp), %rdi
    3ba7:      	movl	$0x8, %ecx
    3bac:      	movl	$0x4, %eax
    3bb1:      	movl	$0x8, %esi
    3bb6:      	callq	*%rax
    3bb8:      	movq	0xd8(%rsp), %rbp
    3bc0:      	leaq	0x48(%rbx), %r15
    3bc4:      	leaq	0xe0(%rsp), %rdi
    3bcc:      	movl	$0x8, %ecx
    3bd1:      	movl	$0x4, %eax
    3bd6:      	movl	$0x8, %esi
    3bdb:      	movq	%r15, %rdx
    3bde:      	callq	*%rax
    3be0:      	movq	0xe0(%rsp), %r14
    3be8:      	leaq	0x10(%r14), %rdx
    3bec:      	leaq	0x60(%rsp), %rdi
    3bf1:      	movl	$0x8, %ecx
    3bf6:      	movl	$0x4, %eax
    3bfb:      	movl	$0x8, %esi
    3c00:      	callq	*%rax
    3c02:      	cmpq	$0x0, 0x60(%rsp)
    3c08:      	je	0x3ed6 <generic_tracepoint_filter+0xb06>
    3c0e:      	movq	0x50(%rsp), %r14
    3c13:      	movq	$0x0, 0x68(%rsp)
    3c1c:      	movq	$0x0, 0x60(%rsp)
    3c25:      	movq	%r12, 0x70(%rsp)
    3c2a:      	movq	$0x0, 0x78(%rsp)
    3c33:      	movq	$0x0, 0x80(%rsp)
    3c3f:      	movq	$0x0, 0x88(%rsp)
    3c4b:      	movq	%r13, 0xc0(%rsp)
    3c53:      	movq	%r13, 0x90(%rsp)
    3c5b:      	movl	0x6410(%r14), %eax
    3c62:      	movl	%eax, 0x98(%rsp)
    3c69:      	leaq	0x18(%rbp), %r13
    3c6d:      	movb	$0x0, 0x9c(%rsp)
    3c75:      	addq	$0x20, %rbp
    3c79:      	leaq	0x60(%rsp), %rdi
    3c7e:      	movl	$0x8, %ecx
    3c83:      	movl	$0x4, %eax
    3c88:      	addq	$0x40, %rbx
    3c8c:      	leaq	0x68(%rsp), %r12
    3c91:      	leaq	0x78(%rsp), %r14
    3c96:      	movl	$0x8, %esi
    3c9b:      	movq	%rbp, %rdx
    3c9e:      	callq	*%rax
    3ca0:      	movl	$0x8, %ecx
    3ca5:      	movl	$0x4, %eax
    3caa:      	movq	%r12, %rdi
    3cad:      	movl	$0x8, %esi
    3cb2:      	movq	%r13, %rdx
    3cb5:      	callq	*%rax
    3cb7:      	movl	$0x8, %ecx
    3cbc:      	movl	$0x4, %eax
    3cc1:      	movq	%r14, %rdi
    3cc4:      	movl	$0x8, %esi
    3cc9:      	movq	%r15, %rdx
    3ccc:      	callq	*%rax
    3cce:      	movl	$0x8, %ecx
    3cd3:      	movl	$0x4, %eax
    3cd8:      	leaq	0x80(%rsp), %rdi
    3ce0:      	movl	$0x8, %esi
    3ce5:      	movq	%rbx, %rdx
    3ce8:      	callq	*%rax
    3cea:      	movq	0x80(%rsp), %rax
    3cf2:      	addq	$-0x20, %rax
    3cf6:      	movq	%rax, 0x88(%rsp)
    3cfe:      	movq	(%rip), %rax            # 0x3d05 <generic_tracepoint_filter+0x935>
    3d05:      	cmpb	$0x0, (%rax)
    3d08:      	je	0x3f2d <generic_tracepoint_filter+0xb5d>
    3d0e:      	movl	$0x800, %r14d           # imm = 0x800
    3d14:      	movl	$0x8, %ebp
    3d19:      	leaq	0x10(%rsp), %rbx
    3d1e:      	nop
    3d20:      	movq	0x78(%rsp), %r15
    3d25:      	movq	0x80(%rsp), %rdx
    3d2d:      	movq	0x88(%rsp), %r12
    3d35:      	cmpq	0x60(%rsp), %r15
    3d3a:      	jne	0x3d47 <generic_tracepoint_filter+0x977>
    3d3c:      	cmpq	0x68(%rsp), %rdx
    3d41:      	je	0x40ef <generic_tracepoint_filter+0xd1f>
    3d47:      	movl	$0x4, %eax
    3d4c:      	leaq	0xa8(%rsp), %rdi
    3d54:      	movl	$0x8, %esi
    3d59:      	callq	*%rax
    3d5b:      	cmpq	0xa8(%rsp), %r15
    3d63:      	je	0x3e70 <generic_tracepoint_filter+0xaa0>
    3d69:      	leaq	0x18(%r15), %r13
    3d6d:      	movl	$0x4, %eax
    3d72:      	movq	%rbx, %rdi
    3d75:      	movl	$0x8, %esi
    3d7a:      	movq	%r13, %rdx
    3d7d:      	callq	*%rax
    3d7f:      	cmpq	%r15, 0x10(%rsp)
    3d84:      	je	0x3e70 <generic_tracepoint_filter+0xaa0>
    3d8a:      	movl	$0x4, %eax
    3d8f:      	leaq	0x58(%rsp), %rdi
    3d94:      	movl	$0x8, %esi
    3d99:      	movq	%r13, %rdx
    3d9c:      	callq	*%rax
    3d9e:      	addq	$0x20, %r15
    3da2:      	movl	$0x4, %eax
    3da7:      	leaq	0x40(%rsp), %rdi
    3dac:      	movl	$0x10, %ecx
    3db1:      	movl	$0x10, %esi
    3db6:      	movq	%r15, %rdx
    3db9:      	callq	*%rax
    3dbb:      	movq	0x70(%rsp), %r15
    3dc0:      	movq	0x90(%rsp), %rax
    3dc8:      	movl	0x44(%rsp), %r12d
    3dcd:      	subq	%r15, %rax
    3dd0:      	movl	0x98(%rsp), %r13d
    3dd8:      	movl	%r12d, %edx
    3ddb:      	subl	%r13d, %edx
    3dde:      	movl	$0x0, %ecx
    3de3:      	cmovbl	%ecx, %edx
    3de6:      	addq	0x48(%rsp), %rdx
    3deb:      	xorl	%esi, %esi
    3ded:      	cmpl	%r12d, %r13d
    3df0:      	seta	%sil
    3df4:      	movl	%r12d, %ecx
    3df7:      	cmovbl	%r13d, %ecx
    3dfb:      	addl	%ecx, %esi
    3dfd:      	movl	%r13d, %edi
    3e00:      	subl	%esi, %edi
    3e02:      	movl	%edi, 0x98(%rsp)
    3e09:      	subq	%rsi, %rax
    3e0c:      	jb	0x40f7 <generic_tracepoint_filter+0xd27>
    3e12:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    3e18:      	ja	0x40f7 <generic_tracepoint_filter+0xd27>
    3e1e:      	cmpl	%r12d, %r13d
    3e21:      	jbe	0x3e28 <generic_tracepoint_filter+0xa58>
    3e23:      	movb	$0x2f, (%r15,%rax)
    3e28:      	xorl	%edi, %edi
    3e2a:      	cmpl	%r12d, %r13d
    3e2d:      	seta	%dil
    3e31:      	movzbl	%cl, %esi
    3e34:      	addq	%rax, %r15
    3e37:      	addq	%r15, %rdi
    3e3a:      	movl	$0x4, %eax
    3e3f:      	callq	*%rax
    3e41:      	movq	%r15, 0x90(%rsp)
    3e49:      	cmpl	%r12d, %r13d
    3e4c:      	jbe	0x40f7 <generic_tracepoint_filter+0xd27>
    3e52:      	movq	0x58(%rsp), %rax
    3e57:      	movq	%rax, 0x78(%rsp)
    3e5c:      	decl	%r14d
    3e5f:      	jne	0x3d20 <generic_tracepoint_filter+0x950>
    3e65:      	jmp	0x40f7 <generic_tracepoint_filter+0xd27>
    3e6a:      	nopw	(%rax,%rax)
    3e70:      	leaq	0x10(%r12), %rdx
    3e75:      	movl	$0x4, %eax
    3e7a:      	movq	%rbx, %rdi
    3e7d:      	movl	$0x8, %esi
    3e82:      	callq	*%rax
    3e84:      	movq	0x88(%rsp), %rax
    3e8c:      	cmpq	0x10(%rsp), %rax
    3e91:      	je	0x40ef <generic_tracepoint_filter+0xd1f>
    3e97:      	addq	$0x18, %r12
    3e9b:      	movl	$0x4, %eax
    3ea0:      	leaq	0x78(%rsp), %rdi
    3ea5:      	movl	$0x8, %esi
    3eaa:      	movq	%r12, %rdx
    3ead:      	callq	*%rax
    3eaf:      	movq	0x10(%rsp), %rax
    3eb4:      	movq	%rax, 0x88(%rsp)
    3ebc:      	addq	$0x20, %rax
    3ec0:      	movq	%rax, 0x80(%rsp)
    3ec8:      	decl	%r14d
    3ecb:      	jne	0x3d20 <generic_tracepoint_filter+0x950>
    3ed1:      	jmp	0x40f7 <generic_tracepoint_filter+0xd27>
    3ed6:      	leaq	0x18(%r14), %rdx
    3eda:      	leaq	0x60(%rsp), %rdi
    3edf:      	movl	$0x8, %ecx
    3ee4:      	movl	$0x4, %eax
    3ee9:      	movl	$0x8, %esi
    3eee:      	callq	*%rax
    3ef0:      	cmpq	%r14, 0x60(%rsp)
    3ef5:      	je	0x3c0e <generic_tracepoint_filter+0x83e>
    3efb:      	movq	0x50(%rsp), %r14
    3f00:      	movl	0x6410(%r14), %ecx
    3f07:      	leal	-0xa(%rcx), %eax
    3f0a:      	movl	%eax, 0x6410(%r14)
    3f11:      	cmpl	$0x9, %ecx
    3f14:      	jg	0x48b4 <generic_tracepoint_filter+0x14e4>
    3f1a:      	movl	$0xffffffdc, 0x6414(%r14) # imm = 0xFFFFFFDC
    3f25:      	movq	%r13, %rbx
    3f28:      	jmp	0x4178 <generic_tracepoint_filter+0xda8>
    3f2d:      	movl	$0x800, %r14d           # imm = 0x800
    3f33:      	movl	$0x8, %ebp
    3f38:      	leaq	0x10(%rsp), %rbx
    3f3d:      	nopl	(%rax)
    3f40:      	movq	0x78(%rsp), %r15
    3f45:      	movq	0x80(%rsp), %rdx
    3f4d:      	movq	0x88(%rsp), %r12
    3f55:      	cmpq	0x60(%rsp), %r15
    3f5a:      	jne	0x3f67 <generic_tracepoint_filter+0xb97>
    3f5c:      	cmpq	0x68(%rsp), %rdx
    3f61:      	je	0x40ef <generic_tracepoint_filter+0xd1f>
    3f67:      	movl	$0x4, %eax
    3f6c:      	leaq	0xa8(%rsp), %rdi
    3f74:      	movl	$0x8, %esi
    3f79:      	callq	*%rax
    3f7b:      	cmpq	0xa8(%rsp), %r15
    3f83:      	je	0x4090 <generic_tracepoint_filter+0xcc0>
    3f89:      	leaq	0x18(%r15), %r13
    3f8d:      	movl	$0x4, %eax
    3f92:      	movq	%rbx, %rdi
    3f95:      	movl	$0x8, %esi
    3f9a:      	movq	%r13, %rdx
    3f9d:      	callq	*%rax
    3f9f:      	cmpq	%r15, 0x10(%rsp)
    3fa4:      	je	0x4090 <generic_tracepoint_filter+0xcc0>
    3faa:      	movl	$0x4, %eax
    3faf:      	leaq	0x58(%rsp), %rdi
    3fb4:      	movl	$0x8, %esi
    3fb9:      	movq	%r13, %rdx
    3fbc:      	callq	*%rax
    3fbe:      	addq	$0x20, %r15
    3fc2:      	movl	$0x4, %eax
    3fc7:      	leaq	0x40(%rsp), %rdi
    3fcc:      	movl	$0x10, %ecx
    3fd1:      	movl	$0x10, %esi
    3fd6:      	movq	%r15, %rdx
    3fd9:      	callq	*%rax
    3fdb:      	movq	0x70(%rsp), %r15
    3fe0:      	movq	0x90(%rsp), %rax
    3fe8:      	movl	0x44(%rsp), %r12d
    3fed:      	subq	%r15, %rax
    3ff0:      	movl	0x98(%rsp), %r13d
    3ff8:      	movl	%r12d, %edx
    3ffb:      	subl	%r13d, %edx
    3ffe:      	movl	$0x0, %ecx
    4003:      	cmovbl	%ecx, %edx
    4006:      	addq	0x48(%rsp), %rdx
    400b:      	xorl	%esi, %esi
    400d:      	cmpl	%r12d, %r13d
    4010:      	seta	%sil
    4014:      	movl	%r12d, %ecx
    4017:      	cmovbl	%r13d, %ecx
    401b:      	addl	%ecx, %esi
    401d:      	movl	%r13d, %edi
    4020:      	subl	%esi, %edi
    4022:      	movl	%edi, 0x98(%rsp)
    4029:      	subq	%rsi, %rax
    402c:      	jb	0x40f7 <generic_tracepoint_filter+0xd27>
    4032:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    4038:      	ja	0x40f7 <generic_tracepoint_filter+0xd27>
    403e:      	cmpl	%r12d, %r13d
    4041:      	jbe	0x4048 <generic_tracepoint_filter+0xc78>
    4043:      	movb	$0x2f, (%r15,%rax)
    4048:      	xorl	%edi, %edi
    404a:      	cmpl	%r12d, %r13d
    404d:      	seta	%dil
    4051:      	movzbl	%cl, %esi
    4054:      	addq	%rax, %r15
    4057:      	addq	%r15, %rdi
    405a:      	movl	$0x4, %eax
    405f:      	callq	*%rax
    4061:      	movq	%r15, 0x90(%rsp)
    4069:      	cmpl	%r12d, %r13d
    406c:      	jbe	0x40f7 <generic_tracepoint_filter+0xd27>
    4072:      	movq	0x58(%rsp), %rax
    4077:      	movq	%rax, 0x78(%rsp)
    407c:      	decl	%r14d
    407f:      	jne	0x3f40 <generic_tracepoint_filter+0xb70>
    4085:      	jmp	0x40f7 <generic_tracepoint_filter+0xd27>
    4087:      	nopw	(%rax,%rax)
    4090:      	leaq	0x10(%r12), %rdx
    4095:      	movl	$0x4, %eax
    409a:      	movq	%rbx, %rdi
    409d:      	movl	$0x8, %esi
    40a2:      	callq	*%rax
    40a4:      	movq	0x88(%rsp), %rax
    40ac:      	cmpq	0x10(%rsp), %rax
    40b1:      	je	0x40ef <generic_tracepoint_filter+0xd1f>
    40b3:      	addq	$0x18, %r12
    40b7:      	movl	$0x4, %eax
    40bc:      	leaq	0x78(%rsp), %rdi
    40c1:      	movl	$0x8, %esi
    40c6:      	movq	%r12, %rdx
    40c9:      	callq	*%rax
    40cb:      	movq	0x10(%rsp), %rax
    40d0:      	movq	%rax, 0x88(%rsp)
    40d8:      	addq	$0x20, %rax
    40dc:      	movq	%rax, 0x80(%rsp)
    40e4:      	decl	%r14d
    40e7:      	jne	0x3f40 <generic_tracepoint_filter+0xb70>
    40ed:      	jmp	0x40f7 <generic_tracepoint_filter+0xd27>
    40ef:      	movb	$0x1, 0x9c(%rsp)
    40f7:      	movq	0x90(%rsp), %rbx
    40ff:      	movq	0xc0(%rsp), %rcx
    4107:      	cmpq	%rcx, %rbx
    410a:      	je	0x4158 <generic_tracepoint_filter+0xd88>
    410c:      	xorl	%ecx, %ecx
    410e:      	cmpb	$0x0, 0x9c(%rsp)
    4116:      	sete	%cl
    4119:      	addl	%ecx, %ecx
    411b:      	movl	0x98(%rsp), %eax
    4122:      	movq	0x50(%rsp), %r14
    4127:      	movl	%eax, 0x6410(%r14)
    412e:      	movl	%ecx, 0x6414(%r14)
    4135:      	testl	%eax, %eax
    4137:      	movq	0x38(%rsp), %rbp
    413c:      	jle	0x414e <generic_tracepoint_filter+0xd7e>
    413e:      	movl	$0x1000, %ecx           # imm = 0x1000
    4143:      	subl	%eax, %ecx
    4145:      	movl	%ecx, 0x6410(%r14)
    414c:      	movl	%ecx, %eax
    414e:      	testq	%rbx, %rbx
    4151:      	jne	0x417d <generic_tracepoint_filter+0xdad>
    4153:      	jmp	0x4277 <generic_tracepoint_filter+0xea7>
    4158:      	movq	0x50(%rsp), %r14
    415d:      	movl	$0x0, 0x6410(%r14)
    4168:      	movl	$0x0, 0x6414(%r14)
    4173:      	xorl	%eax, %eax
    4175:      	movq	%rcx, %rbx
    4178:      	movq	0x38(%rsp), %rbp
    417d:      	xorl	%ecx, %ecx
    417f:      	movq	%r14, %rdx
    4182:      	movl	%eax, %r14d
    4185:      	subl	$0x7f, %r14d
    4189:      	movl	$0x7f, %r15d
    418f:      	cmovbl	%eax, %r15d
    4193:      	cmovbl	%ecx, %r14d
    4197:      	cmpl	$0xff, %eax
    419c:      	movl	$0xff, %ecx
    41a1:      	cmovbl	%eax, %ecx
    41a4:      	movzbl	%cl, %esi
    41a7:      	movl	%esi, 0x6410(%rdx)
    41ad:      	movl	$0x4, %eax
    41b2:      	movq	%rbp, %rdi
    41b5:      	movq	%rbx, %rdx
    41b8:      	callq	*%rax
    41ba:      	testq	%rax, %rax
    41bd:      	je	0x421c <generic_tracepoint_filter+0xe4c>
    41bf:      	negl	%eax
    41c1:      	movw	%ax, 0x60(%rsp)
    41c6:      	movw	$0x8, 0x62(%rsp)
    41cd:      	movabsq	$0x4000002de, %rax      # imm = 0x4000002DE
    41d7:      	movq	%rax, 0x64(%rsp)
    41dc:      	movq	(%rip), %rdi            # 0x41e3 <generic_tracepoint_filter+0xe13>
    41e3:      	leaq	0x60(%rsp), %rsi
    41e8:      	movl	$0x1, %eax
    41ed:      	callq	*%rax
    41ef:      	testq	%rax, %rax
    41f2:      	je	0x41f8 <generic_tracepoint_filter+0xe28>
    41f4:      	incl	(%rax)
    41f6:      	jmp	0x421c <generic_tracepoint_filter+0xe4c>
    41f8:      	movl	$0x1, 0x40(%rsp)
    4200:      	movq	(%rip), %rdi            # 0x4207 <generic_tracepoint_filter+0xe37>
    4207:      	xorl	%ecx, %ecx
    4209:      	leaq	0x60(%rsp), %rsi
    420e:      	leaq	0x40(%rsp), %rdx
    4213:      	movl	$0x2, %eax
    4218:      	xorl	%ecx, %ecx
    421a:      	callq	*%rax
    421c:      	movq	0x50(%rsp), %rax
    4221:      	leaq	0x6390(%rax), %rdi
    4228:      	addq	%r14, %rbx
    422b:      	movq	%rax, %r14
    422e:      	movl	$0x4, %eax
    4233:      	movl	%r15d, %esi
    4236:      	movq	%rbx, %rdx
    4239:      	callq	*%rax
    423b:      	testq	%rax, %rax
    423e:      	je	0x4277 <generic_tracepoint_filter+0xea7>
    4240:      	negl	%eax
    4242:      	movw	%ax, 0x60(%rsp)
    4247:      	movw	$0x8, 0x62(%rsp)
    424e:      	movabsq	$0x4000002e0, %rax      # imm = 0x4000002E0
    4258:      	movq	%rax, 0x64(%rsp)
    425d:      	movq	(%rip), %rdi            # 0x4264 <generic_tracepoint_filter+0xe94>
    4264:      	leaq	0x60(%rsp), %rsi
    4269:      	movl	$0x1, %eax
    426e:      	callq	*%rax
    4270:      	testq	%rax, %rax
    4273:      	je	0x42a4 <generic_tracepoint_filter+0xed4>
    4275:      	incl	(%rax)
    4277:      	movl	0x6410(%r14), %eax
    427e:      	leal	-0x101(%rax), %ecx
    4284:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    428a:      	ja	0x42dd <generic_tracepoint_filter+0xf0d>
    428c:      	movq	0x8(%rsp), %rax
    4291:      	movl	$0xffffffff, (%rax)     # imm = 0xFFFFFFFF
    4297:      	movq	0xb8(%rsp), %rbx
    429f:      	jmp	0x43f3 <generic_tracepoint_filter+0x1023>
    42a4:      	movl	$0x1, 0x40(%rsp)
    42ac:      	movq	(%rip), %rdi            # 0x42b3 <generic_tracepoint_filter+0xee3>
    42b3:      	xorl	%ecx, %ecx
    42b5:      	leaq	0x60(%rsp), %rsi
    42ba:      	leaq	0x40(%rsp), %rdx
    42bf:      	movl	$0x2, %eax
    42c4:      	xorl	%ecx, %ecx
    42c6:      	callq	*%rax
    42c8:      	movl	0x6410(%r14), %eax
    42cf:      	leal	-0x101(%rax), %ecx
    42d5:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    42db:      	jbe	0x428c <generic_tracepoint_filter+0xebc>
    42dd:      	movzbl	%al, %ebx
    42e0:      	leaq	0x5f80(%r14), %rdi
    42e7:      	movl	$0x4, %eax
    42ec:      	movl	%ebx, %esi
    42ee:      	movq	%rbp, %rdx
    42f1:      	callq	*%rax
    42f3:      	movq	%rax, %r15
    42f6:      	testq	%rax, %rax
    42f9:      	je	0x435b <generic_tracepoint_filter+0xf8b>
    42fb:      	movl	%r15d, %eax
    42fe:      	negl	%eax
    4300:      	movw	%ax, 0x60(%rsp)
    4305:      	movw	$0xf, 0x62(%rsp)
    430c:      	movabsq	$0x400000164, %rax      # imm = 0x400000164
    4316:      	movq	%rax, 0x64(%rsp)
    431b:      	movq	(%rip), %rdi            # 0x4322 <generic_tracepoint_filter+0xf52>
    4322:      	leaq	0x60(%rsp), %rsi
    4327:      	movl	$0x1, %eax
    432c:      	callq	*%rax
    432e:      	testq	%rax, %rax
    4331:      	je	0x4337 <generic_tracepoint_filter+0xf67>
    4333:      	incl	(%rax)
    4335:      	jmp	0x435b <generic_tracepoint_filter+0xf8b>
    4337:      	movl	$0x1, 0x40(%rsp)
    433f:      	movq	(%rip), %rdi            # 0x4346 <generic_tracepoint_filter+0xf76>
    4346:      	xorl	%ecx, %ecx
    4348:      	leaq	0x60(%rsp), %rsi
    434d:      	leaq	0x40(%rsp), %rdx
    4352:      	movl	$0x2, %eax
    4357:      	xorl	%ecx, %ecx
    4359:      	callq	*%rax
    435b:      	testl	%r15d, %r15d
    435e:      	cmovel	%ebx, %r15d
    4362:      	movl	%r15d, 0x5f78(%r14)
    4369:      	cmpl	$0x7f, %ebx
    436c:      	movl	$0x7f, %esi
    4371:      	cmovbl	%ebx, %esi
    4374:      	leaq	0x6080(%r14), %rdi
    437b:      	leaq	0x6390(%r14), %rdx
    4382:      	movl	$0x4, %eax
    4387:      	callq	*%rax
    4389:      	testq	%rax, %rax
    438c:      	movq	0xb8(%rsp), %rbx
    4394:      	je	0x43f3 <generic_tracepoint_filter+0x1023>
    4396:      	negl	%eax
    4398:      	movw	%ax, 0x60(%rsp)
    439d:      	movw	$0xf, 0x62(%rsp)
    43a4:      	movabsq	$0x40000016a, %rax      # imm = 0x40000016A
    43ae:      	movq	%rax, 0x64(%rsp)
    43b3:      	movq	(%rip), %rdi            # 0x43ba <generic_tracepoint_filter+0xfea>
    43ba:      	leaq	0x60(%rsp), %rsi
    43bf:      	movl	$0x1, %eax
    43c4:      	callq	*%rax
    43c6:      	testq	%rax, %rax
    43c9:      	je	0x43cf <generic_tracepoint_filter+0xfff>
    43cb:      	incl	(%rax)
    43cd:      	jmp	0x43f3 <generic_tracepoint_filter+0x1023>
    43cf:      	movl	$0x1, 0x40(%rsp)
    43d7:      	movq	(%rip), %rdi            # 0x43de <generic_tracepoint_filter+0x100e>
    43de:      	xorl	%ecx, %ecx
    43e0:      	leaq	0x60(%rsp), %rsi
    43e5:      	leaq	0x40(%rsp), %rdx
    43ea:      	movl	$0x2, %eax
    43ef:      	xorl	%ecx, %ecx
    43f1:      	callq	*%rax
    43f3:      	leaq	0x5f10(%r14), %r15
    43fa:      	orb	$0x10, 0x1(%r14)
    43ff:      	leaq	0x5ef8(%r14), %rsi
    4406:      	movq	(%rip), %rdi            # 0x440d <generic_tracepoint_filter+0x103d>
    440d:      	movl	$0x1, %eax
    4412:      	callq	*%rax
    4414:      	testq	%rax, %rax
    4417:      	je	0x59f9 <generic_tracepoint_filter+0x2629>
    441d:      	movq	0x5eb8(%r14), %r13
    4424:      	cmpq	$0x6, %r13
    4428:      	jae	0x4656 <generic_tracepoint_filter+0x1286>
    442e:      	movslq	(%rax), %rcx
    4431:      	testq	%rcx, %rcx
    4434:      	je	0x4678 <generic_tracepoint_filter+0x12a8>
    443a:      	cmpq	%rcx, %r13
    443d:      	jae	0x4656 <generic_tracepoint_filter+0x1286>
    4443:      	movq	%rax, 0x8(%rsp)
    4448:      	movq	%rcx, 0xc0(%rsp)
    4450:      	movq	%rbx, 0xb8(%rsp)
    4458:      	movl	%r13d, 0x10(%rsp)
    445d:      	movl	$0x0, 0x58(%rsp)
    4465:      	movq	(%rip), %rdi            # 0x446c <generic_tracepoint_filter+0x109c>
    446c:      	leaq	0x10(%rsp), %rsi
    4471:      	movl	$0x1, %eax
    4476:      	callq	*%rax
    4478:      	testq	%rax, %rax
    447b:      	movq	%r15, 0x38(%rsp)
    4480:      	je	0x4694 <generic_tracepoint_filter+0x12c4>
    4486:      	movq	%rax, %rbx
    4489:      	movl	(%rax), %eax
    448b:      	testl	%eax, %eax
    448d:      	je	0x4694 <generic_tracepoint_filter+0x12c4>
    4493:      	cmpl	$0x0, 0x68(%r15)
    4498:      	js	0x599b <generic_tracepoint_filter+0x25cb>
    449e:      	cmpl	$0x1b, %eax
    44a1:      	ja	0x599b <generic_tracepoint_filter+0x25cb>
    44a7:      	movl	$0x60, %ecx
    44ac:      	btl	%eax, %ecx
    44af:      	jb	0x512c <generic_tracepoint_filter+0x1d5c>
    44b5:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    44ba:      	btl	%eax, %ecx
    44bd:      	jb	0x5099 <generic_tracepoint_filter+0x1cc9>
    44c3:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    44c8:      	btl	%eax, %ecx
    44cb:      	jae	0x599b <generic_tracepoint_filter+0x25cb>
    44d1:      	movq	%rbx, %rsi
    44d4:      	addq	$0x4, %rsi
    44d8:      	movq	(%rip), %rdi            # 0x44df <generic_tracepoint_filter+0x110f>
    44df:      	movl	$0x1, %eax
    44e4:      	callq	*%rax
    44e6:      	testq	%rax, %rax
    44e9:      	je	0x599b <generic_tracepoint_filter+0x25cb>
    44ef:      	movq	%rax, %r12
    44f2:      	movq	0x38(%rsp), %rax
    44f7:      	movl	0x68(%rax), %eax
    44fa:      	cmpl	$0x7f, %eax
    44fd:      	movl	$0x7f, %r14d
    4503:      	cmovll	%eax, %r14d
    4507:      	movq	(%rip), %rdi            # 0x450e <generic_tracepoint_filter+0x113e>
    450e:      	leaq	0x58(%rsp), %rsi
    4513:      	movl	$0x1, %eax
    4518:      	callq	*%rax
    451a:      	testq	%rax, %rax
    451d:      	je	0x599b <generic_tracepoint_filter+0x25cb>
    4523:      	movq	%rax, %rbp
    4526:      	leal	(,%r14,8), %eax
    452e:      	movl	%eax, (%rbp)
    4531:      	movq	0x38(%rsp), %rax
    4536:      	cmpl	$0x0, 0x6c(%rax)
    453a:      	jne	0x461d <generic_tracepoint_filter+0x124d>
    4540:      	movq	0x38(%rsp), %r15
    4545:      	movl	0x68(%r15), %ecx
    4549:      	movl	%ecx, %eax
    454b:      	subl	%r14d, %eax
    454e:      	movl	%r14d, %edx
    4551:      	andl	$0x7f, %edx
    4554:      	addl	%edx, %eax
    4556:      	addl	%ecx, %edx
    4558:      	movl	%r14d, %ecx
    455b:      	notl	%ecx
    455d:      	addl	%edx, %ecx
    455f:      	subl	%r14d, %edx
    4562:      	leal	-0x4(%rdx), %esi
    4565:      	leaq	0x1f3(%r15), %rdi
    456c:      	leal	-0x3(%rdx), %r8d
    4570:      	addl	$-0x2, %edx
    4573:      	movq	$-0x3, %r9
    457a:      	leal	(%rcx,%r9), %r10d
    457e:      	addl	$0x3, %r10d
    4582:      	andl	$0x7f, %r10d
    4586:      	movzbl	0x170(%r15,%r10), %r10d
    458f:      	movb	%r10b, -0x3(%rdi)
    4593:      	leaq	(%rax,%r9), %r10
    4597:      	cmpq	$-0x2, %r10
    459b:      	je	0x4615 <generic_tracepoint_filter+0x1245>
    459d:      	leal	(%rdx,%r9), %r11d
    45a1:      	addl	$0x3, %r11d
    45a5:      	andl	$0x7f, %r11d
    45a9:      	movzbl	0x170(%r15,%r11), %r11d
    45b2:      	movb	%r11b, -0x2(%rdi)
    45b6:      	cmpq	$-0x1, %r10
    45ba:      	je	0x4615 <generic_tracepoint_filter+0x1245>
    45bc:      	leal	(%r8,%r9), %r10d
    45c0:      	addl	$0x3, %r10d
    45c4:      	andl	$0x7f, %r10d
    45c8:      	movzbl	0x170(%r15,%r10), %r10d
    45d1:      	movb	%r10b, -0x1(%rdi)
    45d5:      	movq	%rax, %r10
    45d8:      	addq	%r9, %r10
    45db:      	je	0x4615 <generic_tracepoint_filter+0x1245>
    45dd:      	cmpq	$-0x7f, %r9
    45e1:      	je	0x4615 <generic_tracepoint_filter+0x1245>
    45e3:      	leal	(%rsi,%r9), %r10d
    45e7:      	addl	$0x3, %r10d
    45eb:      	andl	$0x7f, %r10d
    45ef:      	movzbl	0x170(%r15,%r10), %r10d
    45f8:      	movb	%r10b, (%rdi)
    45fb:      	addq	$0x4, %rdi
    45ff:      	leaq	(%rax,%r9), %r10
    4603:      	addq	$-0x4, %r10
    4607:      	addq	$-0x4, %r9
    460b:      	cmpq	$-0x3, %r10
    460f:      	jne	0x457a <generic_tracepoint_filter+0x11aa>
    4615:      	movl	$0x1, 0x6c(%r15)
    461d:      	cmpl	$0x7f, %r14d
    4621:      	ja	0x4649 <generic_tracepoint_filter+0x1279>
    4623:      	movslq	%r14d, %rsi
    4626:      	movq	%rbp, %rdi
    4629:      	addq	$0x4, %rdi
    462d:      	movq	0x38(%rsp), %rax
    4632:      	leaq	0x1f0(%rax), %rdx
    4639:      	movl	$0x4, %eax
    463e:      	callq	*%rax
    4640:      	testq	%rax, %rax
    4643:      	js	0x599b <generic_tracepoint_filter+0x25cb>
    4649:      	movl	$0x1, %eax
    464e:      	movq	%r12, %rdi
    4651:      	jmp	0x5124 <generic_tracepoint_filter+0x1d54>
    4656:      	movl	(%r15), %eax
    4659:      	movl	%eax, 0x10(%r14)
    465d:      	movq	0x8(%r15), %rax
    4661:      	movq	%rax, 0x18(%r14)
    4665:      	cmpb	$0x0, 0x5ec0(%r14)
    466d:      	jne	0x59de <generic_tracepoint_filter+0x260e>
    4673:      	jmp	0x59f9 <generic_tracepoint_filter+0x2629>
    4678:      	movb	$0x1, 0x5ec0(%r14)
    4680:      	movl	(%r15), %eax
    4683:      	movl	%eax, 0x10(%r14)
    4687:      	movq	0x8(%r15), %rax
    468b:      	movq	%rax, 0x18(%r14)
    468f:      	jmp	0x59de <generic_tracepoint_filter+0x260e>
    4694:      	movq	0x8(%rsp), %r10
    4699:      	movq	(%rip), %rax            # 0x46a0 <generic_tracepoint_filter+0x12d0>
    46a0:      	cmpb	$0x0, (%rax)
    46a3:      	je	0x48e5 <generic_tracepoint_filter+0x1515>
    46a9:      	movq	(%rip), %rdi            # 0x46b0 <generic_tracepoint_filter+0x12e0>
    46b0:      	movl	$0x1, %eax
    46b5:      	movq	0x38(%rsp), %rsi
    46ba:      	callq	*%rax
    46bc:      	movq	0x8(%rsp), %r10
    46c1:      	testq	%rax, %rax
    46c4:      	je	0x48e5 <generic_tracepoint_filter+0x1515>
    46ca:      	movq	%rax, %rbp
    46cd:      	leal	0x5(%r13), %eax
    46d1:      	movl	%eax, 0x10(%rsp)
    46d5:      	movl	$0x0, 0x58(%rsp)
    46dd:      	movq	(%rip), %rdi            # 0x46e4 <generic_tracepoint_filter+0x1314>
    46e4:      	leaq	0x10(%rsp), %rsi
    46e9:      	movl	$0x1, %eax
    46ee:      	callq	*%rax
    46f0:      	testq	%rax, %rax
    46f3:      	je	0x48e0 <generic_tracepoint_filter+0x1510>
    46f9:      	movq	%rax, %r12
    46fc:      	movl	(%rax), %eax
    46fe:      	testl	%eax, %eax
    4700:      	je	0x48e0 <generic_tracepoint_filter+0x1510>
    4706:      	cmpl	$0x0, (%rbp)
    470a:      	js	0x599b <generic_tracepoint_filter+0x25cb>
    4710:      	cmpl	$0x1b, %eax
    4713:      	ja	0x599b <generic_tracepoint_filter+0x25cb>
    4719:      	movl	$0x60, %ecx
    471e:      	btl	%eax, %ecx
    4721:      	jb	0x5388 <generic_tracepoint_filter+0x1fb8>
    4727:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    472c:      	btl	%eax, %ecx
    472f:      	jb	0x52f8 <generic_tracepoint_filter+0x1f28>
    4735:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    473a:      	btl	%eax, %ecx
    473d:      	jae	0x599b <generic_tracepoint_filter+0x25cb>
    4743:      	movq	%r12, %rsi
    4746:      	addq	$0x4, %rsi
    474a:      	movq	(%rip), %rdi            # 0x4751 <generic_tracepoint_filter+0x1381>
    4751:      	movl	$0x1, %eax
    4756:      	callq	*%rax
    4758:      	testq	%rax, %rax
    475b:      	je	0x599b <generic_tracepoint_filter+0x25cb>
    4761:      	movq	%rax, %r15
    4764:      	movl	(%rbp), %eax
    4767:      	cmpl	$0x7f, %eax
    476a:      	movl	$0x7f, %r14d
    4770:      	cmovll	%eax, %r14d
    4774:      	movq	(%rip), %rdi            # 0x477b <generic_tracepoint_filter+0x13ab>
    477b:      	leaq	0x58(%rsp), %rsi
    4780:      	movl	$0x1, %eax
    4785:      	callq	*%rax
    4787:      	testq	%rax, %rax
    478a:      	je	0x599b <generic_tracepoint_filter+0x25cb>
    4790:      	movq	%rax, %rbx
    4793:      	leal	(,%r14,8), %eax
    479b:      	movl	%eax, (%rbx)
    479d:      	cmpl	$0x0, 0x4(%rbp)
    47a1:      	jne	0x487d <generic_tracepoint_filter+0x14ad>
    47a7:      	movl	(%rbp), %ecx
    47aa:      	movl	%ecx, %eax
    47ac:      	subl	%r14d, %eax
    47af:      	movl	%r14d, %edx
    47b2:      	andl	$0x7f, %edx
    47b5:      	addl	%edx, %eax
    47b7:      	addl	%ecx, %edx
    47b9:      	movl	%r14d, %ecx
    47bc:      	notl	%ecx
    47be:      	addl	%edx, %ecx
    47c0:      	subl	%r14d, %edx
    47c3:      	leal	-0x4(%rdx), %esi
    47c6:      	leaq	0x18b(%rbp), %rdi
    47cd:      	leal	-0x3(%rdx), %r8d
    47d1:      	addl	$-0x2, %edx
    47d4:      	movq	$-0x3, %r9
    47db:      	leal	(%rcx,%r9), %r10d
    47df:      	addl	$0x3, %r10d
    47e3:      	andl	$0x7f, %r10d
    47e7:      	movzbl	0x108(%rbp,%r10), %r10d
    47f0:      	movb	%r10b, -0x3(%rdi)
    47f4:      	leaq	(%rax,%r9), %r10
    47f8:      	cmpq	$-0x2, %r10
    47fc:      	je	0x4876 <generic_tracepoint_filter+0x14a6>
    47fe:      	leal	(%rdx,%r9), %r11d
    4802:      	addl	$0x3, %r11d
    4806:      	andl	$0x7f, %r11d
    480a:      	movzbl	0x108(%rbp,%r11), %r11d
    4813:      	movb	%r11b, -0x2(%rdi)
    4817:      	cmpq	$-0x1, %r10
    481b:      	je	0x4876 <generic_tracepoint_filter+0x14a6>
    481d:      	leal	(%r8,%r9), %r10d
    4821:      	addl	$0x3, %r10d
    4825:      	andl	$0x7f, %r10d
    4829:      	movzbl	0x108(%rbp,%r10), %r10d
    4832:      	movb	%r10b, -0x1(%rdi)
    4836:      	movq	%rax, %r10
    4839:      	addq	%r9, %r10
    483c:      	je	0x4876 <generic_tracepoint_filter+0x14a6>
    483e:      	cmpq	$-0x7f, %r9
    4842:      	je	0x4876 <generic_tracepoint_filter+0x14a6>
    4844:      	leal	(%rsi,%r9), %r10d
    4848:      	addl	$0x3, %r10d
    484c:      	andl	$0x7f, %r10d
    4850:      	movzbl	0x108(%rbp,%r10), %r10d
    4859:      	movb	%r10b, (%rdi)
    485c:      	addq	$0x4, %rdi
    4860:      	leaq	(%rax,%r9), %r10
    4864:      	addq	$-0x4, %r10
    4868:      	addq	$-0x4, %r9
    486c:      	cmpq	$-0x3, %r10
    4870:      	jne	0x47db <generic_tracepoint_filter+0x140b>
    4876:      	movl	$0x1, 0x4(%rbp)
    487d:      	cmpl	$0x7f, %r14d
    4881:      	ja	0x48a7 <generic_tracepoint_filter+0x14d7>
    4883:      	movslq	%r14d, %rsi
    4886:      	movq	%rbx, %rdi
    4889:      	addq	$0x4, %rdi
    488d:      	addq	$0x188, %rbp            # imm = 0x188
    4894:      	movl	$0x4, %eax
    4899:      	movq	%rbp, %rdx
    489c:      	callq	*%rax
    489e:      	testq	%rax, %rax
    48a1:      	js	0x599b <generic_tracepoint_filter+0x25cb>
    48a7:      	movl	$0x1, %eax
    48ac:      	movq	%r15, %rdi
    48af:      	jmp	0x5380 <generic_tracepoint_filter+0x1fb0>
    48b4:      	movq	%r12, %r13
    48b7:      	addq	$0xff6, %r13            # imm = 0xFF6
    48be:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    48c8:      	movq	%rax, 0xff6(%r12)
    48d0:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
    48db:      	jmp	0x3c13 <generic_tracepoint_filter+0x843>
    48e0:      	movq	0x8(%rsp), %r10
    48e5:      	movl	%r13d, %eax
    48e8:      	leaq	0x4(,%rax,4), %rcx
    48f0:      	movl	0x4(%r10,%rax,4), %eax
    48f5:      	leal	(%rax,%rcx), %r14d
    48f9:      	andl	$0x3ff, %r14d           # imm = 0x3FF
    4900:      	addl	%eax, %ecx
    4902:      	addl	$0x4, %ecx
    4905:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    490b:      	leaq	0x8(%r14), %rbp
    490f:      	cmpl	$0x5, (%rcx,%r10)
    4914:      	jb	0x4e3e <generic_tracepoint_filter+0x1a6e>
    491a:      	movl	(%rbp,%r10), %r12d
    491f:      	movl	0x4(%rbp,%r10), %edi
    4924:      	movl	0x8(%rbp,%r10), %edx
    4929:      	movq	$0x0, 0x68(%rsp)
    4932:      	movq	$0x0, 0x60(%rsp)
    493b:      	cmpl	$0x4, %edx
    493e:      	movl	$0x4, %ecx
    4943:      	cmovbl	%edx, %ecx
    4946:      	cmpl	$0x6, %r12d
    494a:      	jne	0x4960 <generic_tracepoint_filter+0x1590>
    494c:      	movabsq	$0x100000001, %rsi      # imm = 0x100000001
    4956:      	movq	%rsi, 0x60(%rsp)
    495b:      	movq	%rsi, 0x68(%rsp)
    4960:      	testl	%edx, %edx
    4962:      	je	0x4e45 <generic_tracepoint_filter+0x1a75>
    4968:      	movq	0x38(%rsp), %rdx
    496d:      	leaq	0x24(%rdx), %rsi
    4971:      	testb	$0x1, %dil
    4975:      	movq	%rsi, 0xb0(%rsp)
    497d:      	movq	%rsi, %r8
    4980:      	cmoveq	%rdx, %r8
    4984:      	addq	$0x10, %rdx
    4988:      	movq	%rdx, 0xd0(%rsp)
    4990:      	leal	(%rax,%r13,4), %r9d
    4994:      	addl	$0x4, %r9d
    4998:      	andl	$0x3ff, %r9d            # imm = 0x3FF
    499f:      	addq	$0x14, %r9
    49a3:      	decq	%rcx
    49a6:      	cmpq	$0x3, %rcx
    49aa:      	movl	$0x3, %eax
    49af:      	cmovbq	%rcx, %rax
    49b3:      	movl	%eax, %eax
    49b5:      	leaq	0x4(,%rax,4), %r11
    49bd:      	xorl	%r13d, %r13d
    49c0:      	movq	%rdi, 0x30(%rsp)
    49c5:      	movq	%r8, 0x28(%rsp)
    49ca:      	movq	%r9, 0x20(%rsp)
    49cf:      	movq	%r11, 0x18(%rsp)
    49d4:      	jmp	0x4a10 <generic_tracepoint_filter+0x1640>
    49d6:      	movq	0x8(%rsp), %r10
    49db:      	movq	0x30(%rsp), %rdi
    49e0:      	movq	0x28(%rsp), %r8
    49e5:      	movq	0x20(%rsp), %r9
    49ea:      	movq	0x18(%rsp), %r11
    49ef:      	cmpl	$0x6, %r12d
    49f3:      	setne	%al
    49f6:      	xorb	$0x1, %bl
    49f9:      	orb	%al, %bl
    49fb:      	movzbl	%bl, %eax
    49fe:      	movl	%eax, 0x60(%rsp,%r13)
    4a03:      	addq	$0x4, %r13
    4a07:      	cmpq	%r13, %r11
    4a0a:      	je	0x4e45 <generic_tracepoint_filter+0x1a75>
    4a10:      	leaq	(%r9,%r13), %rax
    4a14:      	movl	(%r8), %ecx
    4a17:      	cmpq	$0x3e8, %rax            # imm = 0x3E8
    4a1d:      	jbe	0x4c2a <generic_tracepoint_filter+0x185a>
    4a23:      	xorl	%r15d, %r15d
    4a26:      	testb	$0x2, %dil
    4a2a:      	je	0x4c47 <generic_tracepoint_filter+0x1877>
    4a30:      	testb	$0x1, %dil
    4a34:      	jne	0x4c68 <generic_tracepoint_filter+0x1898>
    4a3a:      	movq	0x38(%rsp), %rcx
    4a3f:      	movl	(%rcx), %eax
    4a41:      	movb	$0x1, %bl
    4a43:      	cmpq	%rax, %r15
    4a46:      	je	0x49ef <generic_tracepoint_filter+0x161f>
    4a48:      	movl	0x10(%rcx), %eax
    4a4b:      	cmpq	%rax, %r15
    4a4e:      	je	0x49ef <generic_tracepoint_filter+0x161f>
    4a50:      	movl	$0x1, %eax
    4a55:      	movq	0xd0(%rsp), %rsi
    4a5d:      	movq	(%rip), %rdi            # 0x4a64 <generic_tracepoint_filter+0x1694>
    4a64:      	callq	*%rax
    4a66:      	testq	%rax, %rax
    4a69:      	je	0x4e0d <generic_tracepoint_filter+0x1a3d>
    4a6f:      	movq	%rax, %rsi
    4a72:      	movl	(%rax), %eax
    4a74:      	cmpq	%rax, %r15
    4a77:      	je	0x49d6 <generic_tracepoint_filter+0x1606>
    4a7d:      	movl	0x10(%rsi), %eax
    4a80:      	cmpq	%rax, %r15
    4a83:      	je	0x49d6 <generic_tracepoint_filter+0x1606>
    4a89:      	addq	$0x10, %rsi
    4a8d:      	movl	$0x1, %eax
    4a92:      	movq	(%rip), %rdi            # 0x4a99 <generic_tracepoint_filter+0x16c9>
    4a99:      	callq	*%rax
    4a9b:      	testq	%rax, %rax
    4a9e:      	je	0x4e0d <generic_tracepoint_filter+0x1a3d>
    4aa4:      	movq	%rax, %rsi
    4aa7:      	movl	(%rax), %eax
    4aa9:      	cmpq	%rax, %r15
    4aac:      	je	0x49d6 <generic_tracepoint_filter+0x1606>
    4ab2:      	movl	0x10(%rsi), %eax
    4ab5:      	cmpq	%rax, %r15
    4ab8:      	je	0x49d6 <generic_tracepoint_filter+0x1606>
    4abe:      	addq	$0x10, %rsi
    4ac2:      	movl	$0x1, %eax
    4ac7:      	movq	(%rip), %rdi            # 0x4ace <generic_tracepoint_filter+0x16fe>
    4ace:      	callq	*%rax
    4ad0:      	testq	%rax, %rax
    4ad3:      	je	0x4e0d <generic_tracepoint_filter+0x1a3d>
    4ad9:      	movq	%rax, %rsi
    4adc:      	movl	(%rax), %eax
    4ade:      	cmpq	%rax, %r15
    4ae1:      	je	0x49d6 <generic_tracepoint_filter+0x1606>
    4ae7:      	movl	0x10(%rsi), %eax
    4aea:      	cmpq	%rax, %r15
    4aed:      	je	0x49d6 <generic_tracepoint_filter+0x1606>
    4af3:      	addq	$0x10, %rsi
    4af7:      	movl	$0x1, %eax
    4afc:      	movq	(%rip), %rdi            # 0x4b03 <generic_tracepoint_filter+0x1733>
    4b03:      	callq	*%rax
    4b05:      	testq	%rax, %rax
    4b08:      	je	0x4e0d <generic_tracepoint_filter+0x1a3d>
    4b0e:      	movq	%rax, %rsi
    4b11:      	movl	(%rax), %eax
    4b13:      	cmpq	%rax, %r15
    4b16:      	je	0x49d6 <generic_tracepoint_filter+0x1606>
    4b1c:      	movl	0x10(%rsi), %eax
    4b1f:      	cmpq	%rax, %r15
    4b22:      	je	0x49d6 <generic_tracepoint_filter+0x1606>
    4b28:      	addq	$0x10, %rsi
    4b2c:      	movl	$0x1, %eax
    4b31:      	movq	(%rip), %rdi            # 0x4b38 <generic_tracepoint_filter+0x1768>
    4b38:      	callq	*%rax
    4b3a:      	testq	%rax, %rax
    4b3d:      	je	0x4e0d <generic_tracepoint_filter+0x1a3d>
    4b43:      	movq	%rax, %rsi
    4b46:      	movl	(%rax), %eax
    4b48:      	cmpq	%rax, %r15
    4b4b:      	je	0x49d6 <generic_tracepoint_filter+0x1606>
    4b51:      	movl	0x10(%rsi), %eax
    4b54:      	cmpq	%rax, %r15
    4b57:      	je	0x49d6 <generic_tracepoint_filter+0x1606>
    4b5d:      	addq	$0x10, %rsi
    4b61:      	movl	$0x1, %eax
    4b66:      	movq	(%rip), %rdi            # 0x4b6d <generic_tracepoint_filter+0x179d>
    4b6d:      	callq	*%rax
    4b6f:      	testq	%rax, %rax
    4b72:      	je	0x4e0d <generic_tracepoint_filter+0x1a3d>
    4b78:      	movq	%rax, %rsi
    4b7b:      	movl	(%rax), %eax
    4b7d:      	cmpq	%rax, %r15
    4b80:      	je	0x49d6 <generic_tracepoint_filter+0x1606>
    4b86:      	movl	0x10(%rsi), %eax
    4b89:      	cmpq	%rax, %r15
    4b8c:      	je	0x49d6 <generic_tracepoint_filter+0x1606>
    4b92:      	addq	$0x10, %rsi
    4b96:      	movl	$0x1, %eax
    4b9b:      	movq	(%rip), %rdi            # 0x4ba2 <generic_tracepoint_filter+0x17d2>
    4ba2:      	callq	*%rax
    4ba4:      	testq	%rax, %rax
    4ba7:      	je	0x4e0d <generic_tracepoint_filter+0x1a3d>
    4bad:      	movq	%rax, %rsi
    4bb0:      	movl	(%rax), %eax
    4bb2:      	cmpq	%rax, %r15
    4bb5:      	je	0x49d6 <generic_tracepoint_filter+0x1606>
    4bbb:      	movl	0x10(%rsi), %eax
    4bbe:      	cmpq	%rax, %r15
    4bc1:      	je	0x49d6 <generic_tracepoint_filter+0x1606>
    4bc7:      	addq	$0x10, %rsi
    4bcb:      	movl	$0x1, %eax
    4bd0:      	movq	(%rip), %rdi            # 0x4bd7 <generic_tracepoint_filter+0x1807>
    4bd7:      	callq	*%rax
    4bd9:      	testq	%rax, %rax
    4bdc:      	je	0x4e0d <generic_tracepoint_filter+0x1a3d>
    4be2:      	movq	%rax, %rsi
    4be5:      	movl	(%rax), %eax
    4be7:      	cmpq	%rax, %r15
    4bea:      	je	0x49d6 <generic_tracepoint_filter+0x1606>
    4bf0:      	movl	0x10(%rsi), %eax
    4bf3:      	cmpq	%rax, %r15
    4bf6:      	movq	0x8(%rsp), %r10
    4bfb:      	movq	0x30(%rsp), %rdi
    4c00:      	movq	0x28(%rsp), %r8
    4c05:      	movq	0x20(%rsp), %r9
    4c0a:      	movq	0x18(%rsp), %r11
    4c0f:      	je	0x49ef <generic_tracepoint_filter+0x161f>
    4c15:      	addq	$0x10, %rsi
    4c19:      	movl	$0x1, %eax
    4c1e:      	movq	(%rip), %rcx            # 0x4c25 <generic_tracepoint_filter+0x1855>
    4c25:      	jmp	0x4e04 <generic_tracepoint_filter+0x1a34>
    4c2a:      	movl	$0x4, %esi
    4c2f:      	xorl	%edx, %edx
    4c31:      	divq	%rsi
    4c34:      	andl	$0x3ff, %eax            # imm = 0x3FF
    4c39:      	movl	(%r10,%rax,4), %r15d
    4c3d:      	testb	$0x2, %dil
    4c41:      	jne	0x4a30 <generic_tracepoint_filter+0x1660>
    4c47:      	cmpl	$0x5, %r12d
    4c4b:      	jne	0x4c56 <generic_tracepoint_filter+0x1886>
    4c4d:      	cmpq	%rcx, %r15
    4c50:      	jne	0x4e37 <generic_tracepoint_filter+0x1a67>
    4c56:      	cmpq	%rcx, %r15
    4c59:      	setne	%al
    4c5c:      	cmpl	$0x6, %r12d
    4c60:      	setne	%bl
    4c63:      	jmp	0x49f9 <generic_tracepoint_filter+0x1629>
    4c68:      	movq	0xb0(%rsp), %rax
    4c70:      	movl	(%rax), %eax
    4c72:      	testq	%rax, %rax
    4c75:      	je	0x4e37 <generic_tracepoint_filter+0x1a67>
    4c7b:      	movb	$0x1, %bl
    4c7d:      	testq	%r15, %r15
    4c80:      	je	0x49ef <generic_tracepoint_filter+0x161f>
    4c86:      	cmpq	%rax, %r15
    4c89:      	je	0x49ef <generic_tracepoint_filter+0x161f>
    4c8f:      	movl	$0x1, %eax
    4c94:      	movq	0xd0(%rsp), %rsi
    4c9c:      	movq	(%rip), %rdi            # 0x4ca3 <generic_tracepoint_filter+0x18d3>
    4ca3:      	callq	*%rax
    4ca5:      	testq	%rax, %rax
    4ca8:      	je	0x4e0d <generic_tracepoint_filter+0x1a3d>
    4cae:      	movq	%rax, %rsi
    4cb1:      	movl	0x24(%rax), %eax
    4cb4:      	cmpq	%rax, %r15
    4cb7:      	je	0x49d6 <generic_tracepoint_filter+0x1606>
    4cbd:      	addq	$0x10, %rsi
    4cc1:      	movl	$0x1, %eax
    4cc6:      	movq	(%rip), %rdi            # 0x4ccd <generic_tracepoint_filter+0x18fd>
    4ccd:      	callq	*%rax
    4ccf:      	testq	%rax, %rax
    4cd2:      	je	0x4e0d <generic_tracepoint_filter+0x1a3d>
    4cd8:      	movq	%rax, %rsi
    4cdb:      	movl	0x24(%rax), %eax
    4cde:      	cmpq	%rax, %r15
    4ce1:      	je	0x49d6 <generic_tracepoint_filter+0x1606>
    4ce7:      	addq	$0x10, %rsi
    4ceb:      	movl	$0x1, %eax
    4cf0:      	movq	(%rip), %rdi            # 0x4cf7 <generic_tracepoint_filter+0x1927>
    4cf7:      	callq	*%rax
    4cf9:      	testq	%rax, %rax
    4cfc:      	je	0x4e0d <generic_tracepoint_filter+0x1a3d>
    4d02:      	movq	%rax, %rsi
    4d05:      	movl	0x24(%rax), %eax
    4d08:      	cmpq	%rax, %r15
    4d0b:      	je	0x49d6 <generic_tracepoint_filter+0x1606>
    4d11:      	addq	$0x10, %rsi
    4d15:      	movl	$0x1, %eax
    4d1a:      	movq	(%rip), %rdi            # 0x4d21 <generic_tracepoint_filter+0x1951>
    4d21:      	callq	*%rax
    4d23:      	testq	%rax, %rax
    4d26:      	je	0x4e0d <generic_tracepoint_filter+0x1a3d>
    4d2c:      	movq	%rax, %rsi
    4d2f:      	movl	0x24(%rax), %eax
    4d32:      	cmpq	%rax, %r15
    4d35:      	je	0x49d6 <generic_tracepoint_filter+0x1606>
    4d3b:      	addq	$0x10, %rsi
    4d3f:      	movl	$0x1, %eax
    4d44:      	movq	(%rip), %rdi            # 0x4d4b <generic_tracepoint_filter+0x197b>
    4d4b:      	callq	*%rax
    4d4d:      	testq	%rax, %rax
    4d50:      	je	0x4e0d <generic_tracepoint_filter+0x1a3d>
    4d56:      	movq	%rax, %rsi
    4d59:      	movl	0x24(%rax), %eax
    4d5c:      	cmpq	%rax, %r15
    4d5f:      	je	0x49d6 <generic_tracepoint_filter+0x1606>
    4d65:      	addq	$0x10, %rsi
    4d69:      	movl	$0x1, %eax
    4d6e:      	movq	(%rip), %rdi            # 0x4d75 <generic_tracepoint_filter+0x19a5>
    4d75:      	callq	*%rax
    4d77:      	testq	%rax, %rax
    4d7a:      	je	0x4e0d <generic_tracepoint_filter+0x1a3d>
    4d80:      	movq	%rax, %rsi
    4d83:      	movl	0x24(%rax), %eax
    4d86:      	cmpq	%rax, %r15
    4d89:      	je	0x49d6 <generic_tracepoint_filter+0x1606>
    4d8f:      	addq	$0x10, %rsi
    4d93:      	movl	$0x1, %eax
    4d98:      	movq	(%rip), %rdi            # 0x4d9f <generic_tracepoint_filter+0x19cf>
    4d9f:      	callq	*%rax
    4da1:      	testq	%rax, %rax
    4da4:      	je	0x4e0d <generic_tracepoint_filter+0x1a3d>
    4da6:      	movq	%rax, %rsi
    4da9:      	movl	0x24(%rax), %eax
    4dac:      	cmpq	%rax, %r15
    4daf:      	je	0x49d6 <generic_tracepoint_filter+0x1606>
    4db5:      	addq	$0x10, %rsi
    4db9:      	movl	$0x1, %eax
    4dbe:      	movq	(%rip), %rdi            # 0x4dc5 <generic_tracepoint_filter+0x19f5>
    4dc5:      	callq	*%rax
    4dc7:      	testq	%rax, %rax
    4dca:      	je	0x4e0d <generic_tracepoint_filter+0x1a3d>
    4dcc:      	movq	%rax, %rsi
    4dcf:      	movl	0x24(%rax), %eax
    4dd2:      	cmpq	%rax, %r15
    4dd5:      	movq	0x8(%rsp), %r10
    4dda:      	movq	0x30(%rsp), %rdi
    4ddf:      	movq	0x28(%rsp), %r8
    4de4:      	movq	0x20(%rsp), %r9
    4de9:      	movq	0x18(%rsp), %r11
    4dee:      	je	0x49ef <generic_tracepoint_filter+0x161f>
    4df4:      	addq	$0x10, %rsi
    4df8:      	movl	$0x1, %eax
    4dfd:      	movq	(%rip), %rcx            # 0x4e04 <generic_tracepoint_filter+0x1a34>
    4e04:      	movq	(%rip), %rdi            # 0x4e0b <generic_tracepoint_filter+0x1a3b>
    4e0b:      	callq	*%rax
    4e0d:      	xorl	%ebx, %ebx
    4e0f:      	cmpl	$0x5, %r12d
    4e13:      	movq	0x8(%rsp), %r10
    4e18:      	movq	0x30(%rsp), %rdi
    4e1d:      	movq	0x28(%rsp), %r8
    4e22:      	movq	0x20(%rsp), %r9
    4e27:      	movq	0x18(%rsp), %r11
    4e2c:      	jne	0x49ef <generic_tracepoint_filter+0x161f>
    4e32:      	jmp	0x49fb <generic_tracepoint_filter+0x162b>
    4e37:      	xorl	%ebx, %ebx
    4e39:      	jmp	0x49fb <generic_tracepoint_filter+0x162b>
    4e3e:      	movl	$0x1, %eax
    4e43:      	jmp	0x4e81 <generic_tracepoint_filter+0x1ab1>
    4e45:      	movl	0x60(%rsp), %esi
    4e49:      	movl	0x64(%rsp), %ecx
    4e4d:      	movl	0x68(%rsp), %eax
    4e51:      	movl	0x6c(%rsp), %edx
    4e55:      	cmpl	$0x6, %r12d
    4e59:      	jne	0x4e63 <generic_tracepoint_filter+0x1a93>
    4e5b:      	andl	%esi, %ecx
    4e5d:      	andl	%edx, %eax
    4e5f:      	andl	%ecx, %eax
    4e61:      	jmp	0x4e69 <generic_tracepoint_filter+0x1a99>
    4e63:      	orl	%esi, %ecx
    4e65:      	orl	%edx, %eax
    4e67:      	orl	%ecx, %eax
    4e69:      	testl	%eax, %eax
    4e6b:      	je	0x599b <generic_tracepoint_filter+0x25cb>
    4e71:      	addl	$0x14, %r14d
    4e75:      	movl	0x8(%r10,%rbp), %ecx
    4e7a:      	andl	$0x7, %ecx
    4e7d:      	leal	(%r14,%rcx,4), %ebp
    4e81:      	movq	0x50(%rsp), %r9
    4e86:      	movl	%ebp, %ecx
    4e88:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    4e8e:      	movl	(%rcx,%r10), %ecx
    4e92:      	addl	$0x4, %ebp
    4e95:      	addl	$-0x4, %ecx
    4e98:      	xorl	%esi, %esi
    4e9a:      	movl	$0x4, %r8d
    4ea0:      	jmp	0x4ebf <generic_tracepoint_filter+0x1aef>
    4ea2:      	nopw	%cs:(%rax,%rax)
    4eb0:      	xorl	%ecx, %ecx
    4eb2:      	incq	%rsi
    4eb5:      	cmpq	$0xa, %rsi
    4eb9:      	je	0x5048 <generic_tracepoint_filter+0x1c78>
    4ebf:      	testl	%ecx, %ecx
    4ec1:      	je	0x4eb0 <generic_tracepoint_filter+0x1ae0>
    4ec3:      	movl	%ebp, %r9d
    4ec6:      	andl	$0x3ff, %r9d            # imm = 0x3FF
    4ecd:      	movl	(%r9,%r10), %r11d
    4ed1:      	movq	%r10, %rax
    4ed4:      	movl	0x4(%r9,%r10), %r10d
    4ed9:      	movl	0x8(%r9,%rax), %edx
    4ede:      	movq	$0x0, 0x68(%rsp)
    4ee7:      	movq	$0x0, 0x60(%rsp)
    4ef0:      	cmpl	$0x4, %edx
    4ef3:      	movl	$0x4, %eax
    4ef8:      	cmovbl	%edx, %eax
    4efb:      	cmpl	$0x6, %r10d
    4eff:      	jne	0x4f15 <generic_tracepoint_filter+0x1b45>
    4f01:      	movabsq	$0x100000001, %rdi      # imm = 0x100000001
    4f0b:      	movq	%rdi, 0x60(%rsp)
    4f10:      	movq	%rdi, 0x68(%rsp)
    4f15:      	addl	$0xc, %ebp
    4f18:      	testl	%edx, %edx
    4f1a:      	je	0x4ff0 <generic_tracepoint_filter+0x1c20>
    4f20:      	andl	$0xf, %r11d
    4f24:      	decq	%rax
    4f27:      	cmpq	$0x3, %rax
    4f2b:      	movl	$0x3, %edx
    4f30:      	cmovaeq	%rdx, %rax
    4f34:      	leaq	0x4(,%rax,4), %rbx
    4f3c:      	movl	%ebp, %r14d
    4f3f:      	cmpl	$0x9, %r11d
    4f43:      	jbe	0x4f7a <generic_tracepoint_filter+0x1baa>
    4f45:      	xorl	%r11d, %r11d
    4f48:      	jmp	0x4f66 <generic_tracepoint_filter+0x1b96>
    4f4a:      	nopw	(%rax,%rax)
    4f50:      	movl	$0x0, 0x60(%rsp,%r11)
    4f59:      	addq	$0x4, %r11
    4f5d:      	cmpq	%r11, %rbx
    4f60:      	je	0x4ff0 <generic_tracepoint_filter+0x1c20>
    4f66:      	leaq	(%r14,%r11), %rax
    4f6a:      	cmpl	$0x3e8, %eax            # imm = 0x3E8
    4f6f:      	ja	0x4f50 <generic_tracepoint_filter+0x1b80>
    4f71:      	movl	%eax, %eax
    4f73:      	xorl	%edx, %edx
    4f75:      	divq	%r8
    4f78:      	jmp	0x4f50 <generic_tracepoint_filter+0x1b80>
    4f7a:      	xorl	%r15d, %r15d
    4f7d:      	jmp	0x4fc1 <generic_tracepoint_filter+0x1bf1>
    4f7f:      	nop
    4f80:      	cmpl	$0x5, %r10d
    4f84:      	setne	%dl
    4f87:      	movl	%r10d, %r13d
    4f8a:      	xorl	$0x6, %r13d
    4f8e:      	movq	0x50(%rsp), %rax
    4f93:      	movl	0x20(%rax,%r11,4), %edi
    4f98:      	movl	%r12d, %eax
    4f9b:      	xorl	%edi, %eax
    4f9d:      	cmpl	%edi, %r12d
    4fa0:      	sete	%dil
    4fa4:      	orb	%dl, %dil
    4fa7:      	orl	%r13d, %eax
    4faa:      	setne	%al
    4fad:      	andb	%dil, %al
    4fb0:      	movzbl	%al, %eax
    4fb3:      	movl	%eax, 0x60(%rsp,%r15)
    4fb8:      	addq	$0x4, %r15
    4fbc:      	cmpq	%r15, %rbx
    4fbf:      	je	0x4ff0 <generic_tracepoint_filter+0x1c20>
    4fc1:      	leaq	(%r14,%r15), %rdx
    4fc5:      	xorl	%r12d, %r12d
    4fc8:      	cmpl	$0x3e8, %edx            # imm = 0x3E8
    4fce:      	ja	0x4f80 <generic_tracepoint_filter+0x1bb0>
    4fd0:      	movl	%edx, %eax
    4fd2:      	xorl	%edx, %edx
    4fd4:      	divq	%r8
    4fd7:      	andl	$0x3ff, %eax            # imm = 0x3FF
    4fdc:      	movq	0x8(%rsp), %rdx
    4fe1:      	movl	(%rdx,%rax,4), %r12d
    4fe5:      	jmp	0x4f80 <generic_tracepoint_filter+0x1bb0>
    4fe7:      	nopw	(%rax,%rax)
    4ff0:      	movl	0x60(%rsp), %ebx
    4ff4:      	movl	0x64(%rsp), %edx
    4ff8:      	movl	0x68(%rsp), %eax
    4ffc:      	movl	0x6c(%rsp), %r11d
    5001:      	cmpl	$0x6, %r10d
    5005:      	jne	0x5010 <generic_tracepoint_filter+0x1c40>
    5007:      	andl	%ebx, %edx
    5009:      	andl	%r11d, %eax
    500c:      	andl	%edx, %eax
    500e:      	jmp	0x5017 <generic_tracepoint_filter+0x1c47>
    5010:      	orl	%ebx, %edx
    5012:      	orl	%r11d, %eax
    5015:      	orl	%edx, %eax
    5017:      	movq	0x8(%rsp), %r10
    501c:      	testl	%eax, %eax
    501e:      	je	0x599b <generic_tracepoint_filter+0x25cb>
    5024:      	movl	0x8(%r10,%r9), %edx
    5029:      	shll	$0x2, %edx
    502c:      	subl	%edx, %ecx
    502e:      	andl	$0x1c, %edx
    5031:      	addl	%edx, %ebp
    5033:      	addl	$-0xc, %ecx
    5036:      	movq	0x50(%rsp), %r9
    503b:      	incq	%rsi
    503e:      	cmpq	$0xa, %rsi
    5042:      	jne	0x4ebf <generic_tracepoint_filter+0x1aef>
    5048:      	movl	%ebp, %ecx
    504a:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5050:      	leal	0x4(%rbp), %ebx
    5053:      	cmpl	$0x4, (%rcx,%r10)
    5058:      	je	0x5228 <generic_tracepoint_filter+0x1e58>
    505e:      	andl	$0x3ff, %ebx            # imm = 0x3FF
    5064:      	movl	(%rbx,%r10), %ecx
    5068:      	movl	0x4(%rbx,%r10), %edx
    506d:      	movl	0x8(%rbx,%r10), %edi
    5072:      	movq	0xc(%rbx,%r10), %rax
    5077:      	testl	%edi, %edi
    5079:      	je	0x51fc <generic_tracepoint_filter+0x1e2c>
    507f:      	xorl	%esi, %esi
    5081:      	cmpl	$0x2, %ecx
    5084:      	ja	0x521f <generic_tracepoint_filter+0x1e4f>
    508a:      	cmpl	%edi, 0x44(%r9)
    508e:      	jne	0x5205 <generic_tracepoint_filter+0x1e35>
    5094:      	jmp	0x521f <generic_tracepoint_filter+0x1e4f>
    5099:      	movq	%rbx, %rsi
    509c:      	addq	$0x4, %rsi
    50a0:      	movq	(%rip), %rdi            # 0x50a7 <generic_tracepoint_filter+0x1cd7>
    50a7:      	movl	$0x1, %eax
    50ac:      	callq	*%rax
    50ae:      	testq	%rax, %rax
    50b1:      	je	0x599b <generic_tracepoint_filter+0x25cb>
    50b7:      	movq	%rax, %r14
    50ba:      	movq	(%rip), %rdi            # 0x50c1 <generic_tracepoint_filter+0x1cf1>
    50c1:      	leaq	0x58(%rsp), %rsi
    50c6:      	movl	$0x1, %eax
    50cb:      	callq	*%rax
    50cd:      	testq	%rax, %rax
    50d0:      	je	0x599b <generic_tracepoint_filter+0x25cb>
    50d6:      	movq	%rax, %rbp
    50d9:      	movl	$0x104, %edx            # imm = 0x104
    50de:      	movq	%rax, %rdi
    50e1:      	xorl	%esi, %esi
    50e3:      	callq	0x50e8 <generic_tracepoint_filter+0x1d18>
    50e8:      	movq	0x38(%rsp), %rsi
    50ed:      	movl	0x68(%rsi), %eax
    50f0:      	leal	(,%rax,8), %ecx
    50f7:      	movl	%ecx, (%rbp)
    50fa:      	movq	%rbp, %rdi
    50fd:      	addq	$0x4, %rdi
    5101:      	movzbl	%al, %ecx
    5104:      	leaq	0x70(%rsi), %rdx
    5108:      	movl	$0x4, %eax
    510d:      	movzbl	0x68(%rsi), %esi
    5111:      	callq	*%rax
    5113:      	testq	%rax, %rax
    5116:      	js	0x599b <generic_tracepoint_filter+0x25cb>
    511c:      	movl	$0x1, %eax
    5121:      	movq	%r14, %rdi
    5124:      	movq	%rbp, %rsi
    5127:      	jmp	0x5527 <generic_tracepoint_filter+0x2157>
    512c:      	movl	$0x0, 0x40(%rsp)
    5134:      	movq	(%rip), %rdi            # 0x513b <generic_tracepoint_filter+0x1d6b>
    513b:      	leaq	0x40(%rsp), %rsi
    5140:      	movl	$0x1, %eax
    5145:      	callq	*%rax
    5147:      	testq	%rax, %rax
    514a:      	movq	0x38(%rsp), %rdx
    514f:      	je	0x54d4 <generic_tracepoint_filter+0x2104>
    5155:      	movq	(%rax), %rcx
    5158:      	cmpq	0x378(%rdx), %rcx
    515f:      	je	0x54d4 <generic_tracepoint_filter+0x2104>
    5165:      	movq	%rax, 0xb0(%rsp)
    516d:      	movq	(%rip), %rax            # 0x5174 <generic_tracepoint_filter+0x1da4>
    5174:      	cmpb	$0x0, (%rax)
    5177:      	je	0x544b <generic_tracepoint_filter+0x207b>
    517d:      	movl	$0x1869f, %r15d         # imm = 0x1869F
    5183:      	xorl	%r14d, %r14d
    5186:      	movq	(%rip), %r12            # 0x518d <generic_tracepoint_filter+0x1dbd>
    518d:      	movq	0x38(%rsp), %rax
    5192:      	movl	0x10(%rax), %eax
    5195:      	movl	%eax, 0x60(%rsp)
    5199:      	movl	$0x1, %eax
    519e:      	leaq	0x60(%rsp), %rsi
    51a3:      	movq	%r12, %rdi
    51a6:      	callq	*%rax
    51a8:      	testq	%rax, %rax
    51ab:      	je	0x54bd <generic_tracepoint_filter+0x20ed>
    51b1:      	movq	%rax, %rbp
    51b4:      	leaq	0x70(%rax), %rsi
    51b8:      	movl	$0x1, %eax
    51bd:      	movq	(%rip), %rdi            # 0x51c4 <generic_tracepoint_filter+0x1df4>
    51c4:      	callq	*%rax
    51c6:      	testq	%rax, %rax
    51c9:      	je	0x51e0 <generic_tracepoint_filter+0x1e10>
    51cb:      	movq	(%rax), %rax
    51ce:      	testq	%rax, %rax
    51d1:      	je	0x51e0 <generic_tracepoint_filter+0x1e10>
    51d3:      	movq	0x38(%rsp), %rcx
    51d8:      	lock
    51d9:      	orq	%rax, 0x370(%rcx)
    51e0:      	subl	$0x1, %r15d
    51e4:      	setb	%al
    51e7:      	cmpq	%r14, %rbp
    51ea:      	je	0x54bd <generic_tracepoint_filter+0x20ed>
    51f0:      	movq	%rbp, %r14
    51f3:      	testb	%al, %al
    51f5:      	je	0x518d <generic_tracepoint_filter+0x1dbd>
    51f7:      	jmp	0x54bd <generic_tracepoint_filter+0x20ed>
    51fc:      	cmpl	$0x2, %ecx
    51ff:      	jbe	0x5205 <generic_tracepoint_filter+0x1e35>
    5201:      	xorl	%esi, %esi
    5203:      	jmp	0x521f <generic_tracepoint_filter+0x1e4f>
    5205:      	andq	0x48(%r9,%rcx,8), %rax
    520a:      	cmpl	$0x5, %edx
    520d:      	jne	0x5218 <generic_tracepoint_filter+0x1e48>
    520f:      	testq	%rax, %rax
    5212:      	setne	%sil
    5216:      	jmp	0x521f <generic_tracepoint_filter+0x1e4f>
    5218:      	testq	%rax, %rax
    521b:      	sete	%sil
    521f:      	addl	$0x18, %ebp
    5222:      	movzbl	%sil, %eax
    5226:      	movl	%ebp, %ebx
    5228:      	testl	%eax, %eax
    522a:      	je	0x599b <generic_tracepoint_filter+0x25cb>
    5230:      	movl	%ebx, %ecx
    5232:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5238:      	leal	0x4(%rbx), %eax
    523b:      	cmpl	$0x4, (%rcx,%r10)
    5240:      	je	0x58a3 <generic_tracepoint_filter+0x24d3>
    5246:      	andl	$0x3ff, %eax            # imm = 0x3FF
    524b:      	movl	(%rax,%r10), %r14d
    524f:      	movl	0x4(%rax,%r10), %ebp
    5254:      	movl	$0xe, %eax
    5259:      	callq	*%rax
    525b:      	shrq	$0x20, %rax
    525f:      	movl	%eax, 0x60(%rsp)
    5263:      	movq	(%rip), %rdi            # 0x526a <generic_tracepoint_filter+0x1e9a>
    526a:      	leaq	0x60(%rsp), %rsi
    526f:      	movl	$0x1, %eax
    5274:      	callq	*%rax
    5276:      	movq	0x8(%rsp), %r10
    527b:      	testq	%rax, %rax
    527e:      	je	0x599b <generic_tracepoint_filter+0x25cb>
    5284:      	cmpl	$0x5, %r14d
    5288:      	je	0x52c6 <generic_tracepoint_filter+0x1ef6>
    528a:      	cmpl	$0x6, %r14d
    528e:      	jne	0x599b <generic_tracepoint_filter+0x25cb>
    5294:      	movq	0x50(%rsp), %rsi
    5299:      	movq	%rsi, %rcx
    529c:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    52a3:      	testb	$0x1, %bpl
    52a7:      	jne	0x5569 <generic_tracepoint_filter+0x2199>
    52ad:      	movl	0x28(%rax), %edx
    52b0:      	testl	%edx, %edx
    52b2:      	je	0x5562 <generic_tracepoint_filter+0x2192>
    52b8:      	cmpl	0x20(%rsi), %edx
    52bb:      	je	0x5569 <generic_tracepoint_filter+0x2199>
    52c1:      	jmp	0x5897 <generic_tracepoint_filter+0x24c7>
    52c6:      	movq	0x50(%rsp), %rsi
    52cb:      	movq	%rsi, %rcx
    52ce:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    52d5:      	testb	$0x1, %bpl
    52d9:      	je	0x5587 <generic_tracepoint_filter+0x21b7>
    52df:      	movl	0x28(%rax), %edx
    52e2:      	testl	%edx, %edx
    52e4:      	je	0x5580 <generic_tracepoint_filter+0x21b0>
    52ea:      	cmpl	0x20(%rsi), %edx
    52ed:      	je	0x5587 <generic_tracepoint_filter+0x21b7>
    52f3:      	jmp	0x5897 <generic_tracepoint_filter+0x24c7>
    52f8:      	movq	%r12, %rsi
    52fb:      	addq	$0x4, %rsi
    52ff:      	movq	(%rip), %rdi            # 0x5306 <generic_tracepoint_filter+0x1f36>
    5306:      	movl	$0x1, %eax
    530b:      	callq	*%rax
    530d:      	testq	%rax, %rax
    5310:      	je	0x599b <generic_tracepoint_filter+0x25cb>
    5316:      	movq	%rax, %r14
    5319:      	movq	(%rip), %rdi            # 0x5320 <generic_tracepoint_filter+0x1f50>
    5320:      	leaq	0x58(%rsp), %rsi
    5325:      	movl	$0x1, %eax
    532a:      	callq	*%rax
    532c:      	testq	%rax, %rax
    532f:      	je	0x599b <generic_tracepoint_filter+0x25cb>
    5335:      	movq	%rax, %rbx
    5338:      	movl	$0x104, %edx            # imm = 0x104
    533d:      	movq	%rax, %rdi
    5340:      	xorl	%esi, %esi
    5342:      	callq	0x5347 <generic_tracepoint_filter+0x1f77>
    5347:      	movl	(%rbp), %eax
    534a:      	leal	(,%rax,8), %ecx
    5351:      	movl	%ecx, (%rbx)
    5353:      	movq	%rbx, %rdi
    5356:      	addq	$0x4, %rdi
    535a:      	movzbl	%al, %ecx
    535d:      	movq	%rbp, %rdx
    5360:      	addq	$0x8, %rdx
    5364:      	movl	$0x4, %eax
    5369:      	movzbl	(%rbp), %esi
    536d:      	callq	*%rax
    536f:      	testq	%rax, %rax
    5372:      	js	0x599b <generic_tracepoint_filter+0x25cb>
    5378:      	movl	$0x1, %eax
    537d:      	movq	%r14, %rdi
    5380:      	movq	%rbx, %rsi
    5383:      	jmp	0x56fd <generic_tracepoint_filter+0x232d>
    5388:      	movl	$0x0, 0x40(%rsp)
    5390:      	movq	(%rip), %rdi            # 0x5397 <generic_tracepoint_filter+0x1fc7>
    5397:      	leaq	0x40(%rsp), %rsi
    539c:      	movl	$0x1, %eax
    53a1:      	callq	*%rax
    53a3:      	testq	%rax, %rax
    53a6:      	je	0x56aa <generic_tracepoint_filter+0x22da>
    53ac:      	movq	(%rax), %rcx
    53af:      	cmpq	0x310(%rbp), %rcx
    53b6:      	je	0x56aa <generic_tracepoint_filter+0x22da>
    53bc:      	movq	%rax, 0xb0(%rsp)
    53c4:      	movq	(%rip), %rax            # 0x53cb <generic_tracepoint_filter+0x1ffb>
    53cb:      	cmpb	$0x0, (%rax)
    53ce:      	je	0x562e <generic_tracepoint_filter+0x225e>
    53d4:      	movl	$0x1869f, %r15d         # imm = 0x1869F
    53da:      	xorl	%r14d, %r14d
    53dd:      	movq	0x38(%rsp), %rax
    53e2:      	movl	0x10(%rax), %eax
    53e5:      	movl	%eax, 0x60(%rsp)
    53e9:      	movl	$0x1, %eax
    53ee:      	movq	(%rip), %rdi            # 0x53f5 <generic_tracepoint_filter+0x2025>
    53f5:      	leaq	0x60(%rsp), %rsi
    53fa:      	callq	*%rax
    53fc:      	testq	%rax, %rax
    53ff:      	je	0x5698 <generic_tracepoint_filter+0x22c8>
    5405:      	movq	%rax, %rbx
    5408:      	leaq	0x70(%rax), %rsi
    540c:      	movl	$0x1, %eax
    5411:      	movq	(%rip), %rdi            # 0x5418 <generic_tracepoint_filter+0x2048>
    5418:      	callq	*%rax
    541a:      	testq	%rax, %rax
    541d:      	je	0x542f <generic_tracepoint_filter+0x205f>
    541f:      	movq	(%rax), %rax
    5422:      	testq	%rax, %rax
    5425:      	je	0x542f <generic_tracepoint_filter+0x205f>
    5427:      	lock
    5428:      	orq	%rax, 0x308(%rbp)
    542f:      	subl	$0x1, %r15d
    5433:      	setb	%al
    5436:      	cmpq	%r14, %rbx
    5439:      	je	0x5698 <generic_tracepoint_filter+0x22c8>
    543f:      	movq	%rbx, %r14
    5442:      	testb	%al, %al
    5444:      	je	0x53dd <generic_tracepoint_filter+0x200d>
    5446:      	jmp	0x5698 <generic_tracepoint_filter+0x22c8>
    544b:      	movl	$0x3ff, %r15d           # imm = 0x3FF
    5451:      	xorl	%r14d, %r14d
    5454:      	movq	(%rip), %r12            # 0x545b <generic_tracepoint_filter+0x208b>
    545b:      	movq	0x38(%rsp), %rax
    5460:      	movl	0x10(%rax), %eax
    5463:      	movl	%eax, 0x60(%rsp)
    5467:      	movl	$0x1, %eax
    546c:      	leaq	0x60(%rsp), %rsi
    5471:      	movq	%r12, %rdi
    5474:      	callq	*%rax
    5476:      	testq	%rax, %rax
    5479:      	je	0x54bd <generic_tracepoint_filter+0x20ed>
    547b:      	movq	%rax, %rbp
    547e:      	leaq	0x70(%rax), %rsi
    5482:      	movl	$0x1, %eax
    5487:      	movq	(%rip), %rdi            # 0x548e <generic_tracepoint_filter+0x20be>
    548e:      	callq	*%rax
    5490:      	testq	%rax, %rax
    5493:      	je	0x54aa <generic_tracepoint_filter+0x20da>
    5495:      	movq	(%rax), %rax
    5498:      	testq	%rax, %rax
    549b:      	je	0x54aa <generic_tracepoint_filter+0x20da>
    549d:      	movq	0x38(%rsp), %rcx
    54a2:      	lock
    54a3:      	orq	%rax, 0x370(%rcx)
    54aa:      	subl	$0x1, %r15d
    54ae:      	setb	%al
    54b1:      	cmpq	%r14, %rbp
    54b4:      	je	0x54bd <generic_tracepoint_filter+0x20ed>
    54b6:      	movq	%rbp, %r14
    54b9:      	testb	%al, %al
    54bb:      	je	0x545b <generic_tracepoint_filter+0x208b>
    54bd:      	movq	0xb0(%rsp), %rax
    54c5:      	movq	(%rax), %rax
    54c8:      	movq	0x38(%rsp), %rdx
    54cd:      	movq	%rax, 0x378(%rdx)
    54d4:      	movl	0x8(%rbx), %eax
    54d7:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    54dc:      	cmpq	%rcx, %rax
    54df:      	je	0x54fa <generic_tracepoint_filter+0x212a>
    54e1:      	movq	0x370(%rdx), %rcx
    54e8:      	btq	%rax, %rcx
    54ec:      	jae	0x54fa <generic_tracepoint_filter+0x212a>
    54ee:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    54f8:      	jmp	0x5529 <generic_tracepoint_filter+0x2159>
    54fa:      	movq	(%rip), %rdi            # 0x5501 <generic_tracepoint_filter+0x2131>
    5501:      	leaq	0x10(%rsp), %rsi
    5506:      	movl	$0x1, %eax
    550b:      	callq	*%rax
    550d:      	testq	%rax, %rax
    5510:      	je	0x599b <generic_tracepoint_filter+0x25cb>
    5516:      	movq	%rax, %rdi
    5519:      	movq	0x38(%rsp), %rax
    551e:      	leaq	0x70(%rax), %rsi
    5522:      	movl	$0x1, %eax
    5527:      	callq	*%rax
    5529:      	movl	(%rbx), %ecx
    552b:      	cmpq	$0x25, %rcx
    552f:      	movq	0x8(%rsp), %r10
    5534:      	ja	0x5554 <generic_tracepoint_filter+0x2184>
    5536:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    5540:      	btq	%rcx, %rdx
    5544:      	jae	0x5554 <generic_tracepoint_filter+0x2184>
    5546:      	testq	%rax, %rax
    5549:      	jne	0x599b <generic_tracepoint_filter+0x25cb>
    554f:      	jmp	0x4699 <generic_tracepoint_filter+0x12c9>
    5554:      	testq	%rax, %rax
    5557:      	jne	0x4699 <generic_tracepoint_filter+0x12c9>
    555d:      	jmp	0x599b <generic_tracepoint_filter+0x25cb>
    5562:      	movq	$0x1, (%rcx)
    5569:      	testb	$0x2, %bpl
    556d:      	jne	0x55a5 <generic_tracepoint_filter+0x21d5>
    556f:      	movl	0x2c(%rax), %edx
    5572:      	testl	%edx, %edx
    5574:      	je	0x559e <generic_tracepoint_filter+0x21ce>
    5576:      	cmpl	0x24(%rsi), %edx
    5579:      	je	0x55a5 <generic_tracepoint_filter+0x21d5>
    557b:      	jmp	0x5897 <generic_tracepoint_filter+0x24c7>
    5580:      	movq	$0x1, (%rcx)
    5587:      	testb	$0x2, %bpl
    558b:      	je	0x55c3 <generic_tracepoint_filter+0x21f3>
    558d:      	movl	0x2c(%rax), %edx
    5590:      	testl	%edx, %edx
    5592:      	je	0x55bc <generic_tracepoint_filter+0x21ec>
    5594:      	cmpl	0x24(%rsi), %edx
    5597:      	je	0x55c3 <generic_tracepoint_filter+0x21f3>
    5599:      	jmp	0x5897 <generic_tracepoint_filter+0x24c7>
    559e:      	movq	$0x1, (%rcx)
    55a5:      	testb	$0x4, %bpl
    55a9:      	jne	0x55e1 <generic_tracepoint_filter+0x2211>
    55ab:      	movl	0x30(%rax), %edx
    55ae:      	testl	%edx, %edx
    55b0:      	je	0x55da <generic_tracepoint_filter+0x220a>
    55b2:      	cmpl	0x28(%rsi), %edx
    55b5:      	je	0x55e1 <generic_tracepoint_filter+0x2211>
    55b7:      	jmp	0x5897 <generic_tracepoint_filter+0x24c7>
    55bc:      	movq	$0x1, (%rcx)
    55c3:      	testb	$0x4, %bpl
    55c7:      	je	0x560b <generic_tracepoint_filter+0x223b>
    55c9:      	movl	0x30(%rax), %edx
    55cc:      	testl	%edx, %edx
    55ce:      	je	0x5604 <generic_tracepoint_filter+0x2234>
    55d0:      	cmpl	0x28(%rsi), %edx
    55d3:      	je	0x560b <generic_tracepoint_filter+0x223b>
    55d5:      	jmp	0x5897 <generic_tracepoint_filter+0x24c7>
    55da:      	movq	$0x1, (%rcx)
    55e1:      	testb	$0x8, %bpl
    55e5:      	jne	0x5741 <generic_tracepoint_filter+0x2371>
    55eb:      	movl	0x34(%rax), %edx
    55ee:      	testl	%edx, %edx
    55f0:      	je	0x573a <generic_tracepoint_filter+0x236a>
    55f6:      	cmpl	0x2c(%rsi), %edx
    55f9:      	je	0x5741 <generic_tracepoint_filter+0x2371>
    55ff:      	jmp	0x5897 <generic_tracepoint_filter+0x24c7>
    5604:      	movq	$0x1, (%rcx)
    560b:      	testb	$0x8, %bpl
    560f:      	je	0x575f <generic_tracepoint_filter+0x238f>
    5615:      	movl	0x34(%rax), %edx
    5618:      	testl	%edx, %edx
    561a:      	je	0x5758 <generic_tracepoint_filter+0x2388>
    5620:      	cmpl	0x2c(%rsi), %edx
    5623:      	je	0x575f <generic_tracepoint_filter+0x238f>
    5629:      	jmp	0x5897 <generic_tracepoint_filter+0x24c7>
    562e:      	movl	$0x3ff, %r15d           # imm = 0x3FF
    5634:      	xorl	%r14d, %r14d
    5637:      	movq	0x38(%rsp), %rax
    563c:      	movl	0x10(%rax), %eax
    563f:      	movl	%eax, 0x60(%rsp)
    5643:      	movl	$0x1, %eax
    5648:      	movq	(%rip), %rdi            # 0x564f <generic_tracepoint_filter+0x227f>
    564f:      	leaq	0x60(%rsp), %rsi
    5654:      	callq	*%rax
    5656:      	testq	%rax, %rax
    5659:      	je	0x5698 <generic_tracepoint_filter+0x22c8>
    565b:      	movq	%rax, %rbx
    565e:      	leaq	0x70(%rax), %rsi
    5662:      	movl	$0x1, %eax
    5667:      	movq	(%rip), %rdi            # 0x566e <generic_tracepoint_filter+0x229e>
    566e:      	callq	*%rax
    5670:      	testq	%rax, %rax
    5673:      	je	0x5685 <generic_tracepoint_filter+0x22b5>
    5675:      	movq	(%rax), %rax
    5678:      	testq	%rax, %rax
    567b:      	je	0x5685 <generic_tracepoint_filter+0x22b5>
    567d:      	lock
    567e:      	orq	%rax, 0x308(%rbp)
    5685:      	subl	$0x1, %r15d
    5689:      	setb	%al
    568c:      	cmpq	%r14, %rbx
    568f:      	je	0x5698 <generic_tracepoint_filter+0x22c8>
    5691:      	movq	%rbx, %r14
    5694:      	testb	%al, %al
    5696:      	je	0x5637 <generic_tracepoint_filter+0x2267>
    5698:      	movq	0xb0(%rsp), %rax
    56a0:      	movq	(%rax), %rax
    56a3:      	movq	%rax, 0x310(%rbp)
    56aa:      	movl	0x8(%r12), %eax
    56af:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    56b4:      	cmpq	%rcx, %rax
    56b7:      	je	0x56d2 <generic_tracepoint_filter+0x2302>
    56b9:      	movq	0x308(%rbp), %rcx
    56c0:      	btq	%rax, %rcx
    56c4:      	jae	0x56d2 <generic_tracepoint_filter+0x2302>
    56c6:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    56d0:      	jmp	0x56ff <generic_tracepoint_filter+0x232f>
    56d2:      	movq	(%rip), %rdi            # 0x56d9 <generic_tracepoint_filter+0x2309>
    56d9:      	leaq	0x10(%rsp), %rsi
    56de:      	movl	$0x1, %eax
    56e3:      	callq	*%rax
    56e5:      	testq	%rax, %rax
    56e8:      	je	0x599b <generic_tracepoint_filter+0x25cb>
    56ee:      	movq	%rax, %rdi
    56f1:      	addq	$0x8, %rbp
    56f5:      	movl	$0x1, %eax
    56fa:      	movq	%rbp, %rsi
    56fd:      	callq	*%rax
    56ff:      	movl	(%r12), %ecx
    5703:      	cmpq	$0x25, %rcx
    5707:      	movq	0x8(%rsp), %r10
    570c:      	ja	0x572c <generic_tracepoint_filter+0x235c>
    570e:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    5718:      	btq	%rcx, %rdx
    571c:      	jae	0x572c <generic_tracepoint_filter+0x235c>
    571e:      	testq	%rax, %rax
    5721:      	jne	0x599b <generic_tracepoint_filter+0x25cb>
    5727:      	jmp	0x48e5 <generic_tracepoint_filter+0x1515>
    572c:      	testq	%rax, %rax
    572f:      	jne	0x48e5 <generic_tracepoint_filter+0x1515>
    5735:      	jmp	0x599b <generic_tracepoint_filter+0x25cb>
    573a:      	movq	$0x1, (%rcx)
    5741:      	testb	$0x10, %bpl
    5745:      	jne	0x577d <generic_tracepoint_filter+0x23ad>
    5747:      	movl	0x38(%rax), %edx
    574a:      	testl	%edx, %edx
    574c:      	je	0x5776 <generic_tracepoint_filter+0x23a6>
    574e:      	cmpl	0x30(%rsi), %edx
    5751:      	je	0x577d <generic_tracepoint_filter+0x23ad>
    5753:      	jmp	0x5897 <generic_tracepoint_filter+0x24c7>
    5758:      	movq	$0x1, (%rcx)
    575f:      	testb	$0x10, %bpl
    5763:      	je	0x579b <generic_tracepoint_filter+0x23cb>
    5765:      	movl	0x38(%rax), %edx
    5768:      	testl	%edx, %edx
    576a:      	je	0x5794 <generic_tracepoint_filter+0x23c4>
    576c:      	cmpl	0x30(%rsi), %edx
    576f:      	je	0x579b <generic_tracepoint_filter+0x23cb>
    5771:      	jmp	0x5897 <generic_tracepoint_filter+0x24c7>
    5776:      	movq	$0x1, (%rcx)
    577d:      	testb	$0x20, %bpl
    5781:      	jne	0x57b9 <generic_tracepoint_filter+0x23e9>
    5783:      	movl	0x3c(%rax), %edx
    5786:      	testl	%edx, %edx
    5788:      	je	0x57b2 <generic_tracepoint_filter+0x23e2>
    578a:      	cmpl	0x34(%rsi), %edx
    578d:      	je	0x57b9 <generic_tracepoint_filter+0x23e9>
    578f:      	jmp	0x5897 <generic_tracepoint_filter+0x24c7>
    5794:      	movq	$0x1, (%rcx)
    579b:      	testb	$0x20, %bpl
    579f:      	je	0x57d7 <generic_tracepoint_filter+0x2407>
    57a1:      	movl	0x3c(%rax), %edx
    57a4:      	testl	%edx, %edx
    57a6:      	je	0x57d0 <generic_tracepoint_filter+0x2400>
    57a8:      	cmpl	0x34(%rsi), %edx
    57ab:      	je	0x57d7 <generic_tracepoint_filter+0x2407>
    57ad:      	jmp	0x5897 <generic_tracepoint_filter+0x24c7>
    57b2:      	movq	$0x1, (%rcx)
    57b9:      	testb	$0x40, %bpl
    57bd:      	jne	0x57f5 <generic_tracepoint_filter+0x2425>
    57bf:      	movl	0x40(%rax), %edx
    57c2:      	testl	%edx, %edx
    57c4:      	je	0x57ee <generic_tracepoint_filter+0x241e>
    57c6:      	cmpl	0x38(%rsi), %edx
    57c9:      	je	0x57f5 <generic_tracepoint_filter+0x2425>
    57cb:      	jmp	0x5897 <generic_tracepoint_filter+0x24c7>
    57d0:      	movq	$0x1, (%rcx)
    57d7:      	testb	$0x40, %bpl
    57db:      	je	0x5812 <generic_tracepoint_filter+0x2442>
    57dd:      	movl	0x40(%rax), %edx
    57e0:      	testl	%edx, %edx
    57e2:      	je	0x580b <generic_tracepoint_filter+0x243b>
    57e4:      	cmpl	0x38(%rsi), %edx
    57e7:      	je	0x5812 <generic_tracepoint_filter+0x2442>
    57e9:      	jmp	0x5897 <generic_tracepoint_filter+0x24c7>
    57ee:      	movq	$0x1, (%rcx)
    57f5:      	testb	%bpl, %bpl
    57f8:      	js	0x582c <generic_tracepoint_filter+0x245c>
    57fa:      	movl	0x44(%rax), %edx
    57fd:      	testl	%edx, %edx
    57ff:      	je	0x5825 <generic_tracepoint_filter+0x2455>
    5801:      	cmpl	0x3c(%rsi), %edx
    5804:      	je	0x582c <generic_tracepoint_filter+0x245c>
    5806:      	jmp	0x5897 <generic_tracepoint_filter+0x24c7>
    580b:      	movq	$0x1, (%rcx)
    5812:      	testb	%bpl, %bpl
    5815:      	jns	0x5849 <generic_tracepoint_filter+0x2479>
    5817:      	movl	0x44(%rax), %edx
    581a:      	testl	%edx, %edx
    581c:      	je	0x5842 <generic_tracepoint_filter+0x2472>
    581e:      	cmpl	0x3c(%rsi), %edx
    5821:      	je	0x5849 <generic_tracepoint_filter+0x2479>
    5823:      	jmp	0x5897 <generic_tracepoint_filter+0x24c7>
    5825:      	movq	$0x1, (%rcx)
    582c:      	testl	$0x100, %ebp            # imm = 0x100
    5832:      	jne	0x5872 <generic_tracepoint_filter+0x24a2>
    5834:      	movl	0x48(%rax), %edx
    5837:      	testl	%edx, %edx
    5839:      	je	0x586b <generic_tracepoint_filter+0x249b>
    583b:      	cmpl	0x40(%rsi), %edx
    583e:      	je	0x5872 <generic_tracepoint_filter+0x24a2>
    5840:      	jmp	0x5897 <generic_tracepoint_filter+0x24c7>
    5842:      	movq	$0x1, (%rcx)
    5849:      	testl	$0x100, %ebp            # imm = 0x100
    584f:      	je	0x5981 <generic_tracepoint_filter+0x25b1>
    5855:      	movl	0x48(%rax), %edx
    5858:      	testl	%edx, %edx
    585a:      	je	0x597a <generic_tracepoint_filter+0x25aa>
    5860:      	cmpl	0x40(%rsi), %edx
    5863:      	je	0x5981 <generic_tracepoint_filter+0x25b1>
    5869:      	jmp	0x5897 <generic_tracepoint_filter+0x24c7>
    586b:      	movq	$0x1, (%rcx)
    5872:      	testl	$0x200, %ebp            # imm = 0x200
    5878:      	jne	0x599b <generic_tracepoint_filter+0x25cb>
    587e:      	movl	0x4c(%rax), %eax
    5881:      	testl	%eax, %eax
    5883:      	je	0x5994 <generic_tracepoint_filter+0x25c4>
    5889:      	movq	0x50(%rsp), %rdx
    588e:      	cmpl	0x44(%rdx), %eax
    5891:      	je	0x599b <generic_tracepoint_filter+0x25cb>
    5897:      	addl	$0xc, %ebx
    589a:      	movq	$0x1, (%rcx)
    58a1:      	movl	%ebx, %eax
    58a3:      	movl	%eax, %ecx
    58a5:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    58ab:      	cmpl	$0x4, (%rcx,%r10)
    58b0:      	movq	0x50(%rsp), %rcx
    58b5:      	jne	0x58dc <generic_tracepoint_filter+0x250c>
    58b7:      	movq	0x5eb8(%rcx), %rax
    58be:      	andl	$0x1f, %eax
    58c1:      	movb	$0x1, 0x5ec1(%rcx,%rax)
    58c9:      	movb	$0x1, 0x5ee0(%rcx)
    58d0:      	movb	$0x1, 0x5ec0(%rcx)
    58d7:      	jmp	0x599b <generic_tracepoint_filter+0x25cb>
    58dc:      	addl	$0x4, %eax
    58df:      	andl	$0x3ff, %eax            # imm = 0x3FF
    58e4:      	movl	(%rax,%r10), %r14d
    58e8:      	movl	0x4(%rax,%r10), %ebx
    58ed:      	movl	0x8(%rax,%r10), %ebp
    58f2:      	movq	0xc(%rax,%r10), %r15
    58f7:      	movl	$0xe, %eax
    58fc:      	callq	*%rax
    58fe:      	shrq	$0x20, %rax
    5902:      	movl	%eax, 0x60(%rsp)
    5906:      	movq	(%rip), %rdi            # 0x590d <generic_tracepoint_filter+0x253d>
    590d:      	leaq	0x60(%rsp), %rsi
    5912:      	movl	$0x1, %eax
    5917:      	callq	*%rax
    5919:      	testq	%rax, %rax
    591c:      	je	0x599b <generic_tracepoint_filter+0x25cb>
    591e:      	testl	%ebp, %ebp
    5920:      	je	0x5934 <generic_tracepoint_filter+0x2564>
    5922:      	cmpl	$0x2, %r14d
    5926:      	ja	0x599b <generic_tracepoint_filter+0x25cb>
    5928:      	movq	0x50(%rsp), %rcx
    592d:      	cmpl	%ebp, 0x44(%rcx)
    5930:      	jne	0x593a <generic_tracepoint_filter+0x256a>
    5932:      	jmp	0x599b <generic_tracepoint_filter+0x25cb>
    5934:      	cmpl	$0x2, %r14d
    5938:      	ja	0x599b <generic_tracepoint_filter+0x25cb>
    593a:      	movq	0x50(%rax,%r14,8), %rax
    593f:      	movq	0x50(%rsp), %rcx
    5944:      	movq	0x48(%rcx,%r14,8), %rcx
    5949:      	movq	%rcx, %rdx
    594c:      	xorq	%rax, %rdx
    594f:      	testq	%r15, %rdx
    5952:      	je	0x595b <generic_tracepoint_filter+0x258b>
    5954:      	cmpl	$0x5, %ebx
    5957:      	jne	0x599b <generic_tracepoint_filter+0x25cb>
    5959:      	jmp	0x5965 <generic_tracepoint_filter+0x2595>
    595b:      	cmpq	%rcx, %rax
    595e:      	je	0x599b <generic_tracepoint_filter+0x25cb>
    5960:      	cmpl	$0x6, %ebx
    5963:      	jne	0x599b <generic_tracepoint_filter+0x25cb>
    5965:      	movq	0x50(%rsp), %rcx
    596a:      	movq	$0x1, 0x5ef0(%rcx)
    5975:      	jmp	0x58b7 <generic_tracepoint_filter+0x24e7>
    597a:      	movq	$0x1, (%rcx)
    5981:      	testl	$0x200, %ebp            # imm = 0x200
    5987:      	je	0x599b <generic_tracepoint_filter+0x25cb>
    5989:      	movl	0x4c(%rax), %eax
    598c:      	testl	%eax, %eax
    598e:      	jne	0x5889 <generic_tracepoint_filter+0x24b9>
    5994:      	movq	$0x1, (%rcx)
    599b:      	movq	0x50(%rsp), %rcx
    59a0:      	movq	0x5eb8(%rcx), %rax
    59a7:      	incq	%rax
    59aa:      	movq	%rax, 0x5eb8(%rcx)
    59b1:      	cmpq	0xc0(%rsp), %rax
    59b9:      	jbe	0x5a0d <generic_tracepoint_filter+0x263d>
    59bb:      	movq	0x38(%rsp), %rdx
    59c0:      	movl	(%rdx), %eax
    59c2:      	movl	%eax, 0x10(%rcx)
    59c5:      	movq	0x8(%rdx), %rax
    59c9:      	movq	%rax, 0x18(%rcx)
    59cd:      	cmpb	$0x0, 0x5ec0(%rcx)
    59d4:      	movq	0xb8(%rsp), %rbx
    59dc:      	je	0x59f9 <generic_tracepoint_filter+0x2629>
    59de:      	movq	(%rip), %rsi            # 0x59e5 <generic_tracepoint_filter+0x2615>
    59e5:      	movl	$0x1, %ecx
    59ea:      	movl	$0xc, %eax
    59ef:      	movq	%rbx, %rdi
    59f2:      	movl	$0x1, %edx
    59f7:      	callq	*%rax
    59f9:      	xorl	%eax, %eax
    59fb:      	addq	$0xe8, %rsp
    5a02:      	popq	%rbx
    5a03:      	popq	%r12
    5a05:      	popq	%r13
    5a07:      	popq	%r14
    5a09:      	popq	%r15
    5a0b:      	popq	%rbp
    5a0c:      	retq
    5a0d:      	movq	(%rip), %rsi            # 0x5a14 <generic_tracepoint_filter+0x2644>
    5a14:      	movl	$0x2, %ecx
    5a19:      	movl	$0xc, %eax
    5a1e:      	movq	0xb8(%rsp), %rdi
    5a26:      	movl	$0x2, %edx
    5a2b:      	jmp	0x59f7 <generic_tracepoint_filter+0x2627>
    5a2d:      	nopl	(%rax)

0000000000005a30 <generic_tracepoint_arg>:
    5a30:      	pushq	%rbp
    5a31:      	pushq	%r15
    5a33:      	pushq	%r14
    5a35:      	pushq	%r13
    5a37:      	pushq	%r12
    5a39:      	pushq	%rbx
    5a3a:      	subq	$0x28, %rsp
    5a3e:      	movq	%rdi, %rbx
    5a41:      	movl	$0x0, 0xc(%rsp)
    5a49:      	movq	(%rip), %rdi            # 0x5a50 <generic_tracepoint_arg+0x20>
    5a50:      	leaq	0xc(%rsp), %rsi
    5a55:      	movl	$0x1, %eax
    5a5a:      	callq	*%rax
    5a5c:      	testq	%rax, %rax
    5a5f:      	je	0x5e2c <generic_tracepoint_arg+0x3fc>
    5a65:      	movq	%rax, %r14
    5a68:      	movl	0x5f00(%rax), %r12d
    5a6f:      	leaq	0x5ef8(%rax), %rsi
    5a76:      	movq	(%rip), %rdi            # 0x5a7d <generic_tracepoint_arg+0x4d>
    5a7d:      	movl	$0x1, %eax
    5a82:      	callq	*%rax
    5a84:      	testq	%rax, %rax
    5a87:      	je	0x5e11 <generic_tracepoint_arg+0x3e1>
    5a8d:      	cmpb	$0x0, 0x5ee0(%r14)
    5a95:      	je	0x5e11 <generic_tracepoint_arg+0x3e1>
    5a9b:      	movq	%rax, %r15
    5a9e:      	movl	%r12d, %eax
    5aa1:      	andl	$0x7, %eax
    5aa4:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
    5aad:      	je	0x5b3c <generic_tracepoint_arg+0x10c>
    5ab3:      	movl	%eax, %eax
    5ab5:      	movl	0x4(%r15,%rax,4), %ecx
    5aba:      	leaq	(%rcx,%rax,4), %rdx
    5abe:      	addq	$0x4, %rdx
    5ac2:      	leaq	(%rcx,%rax,4), %rax
    5ac6:      	addq	$0x8, %rax
    5aca:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5acf:      	movl	(%rax,%r15), %eax
    5ad3:      	addq	%rdx, %rax
    5ad6:      	addq	$0x4, %rax
    5ada:      	movl	%eax, %ecx
    5adc:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5ae2:      	movl	(%rcx,%r15), %ecx
    5ae6:      	addq	%rax, %rcx
    5ae9:      	movl	%ecx, %eax
    5aeb:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5af0:      	movl	(%rax,%r15), %eax
    5af4:      	addq	%rcx, %rax
    5af7:      	movl	%eax, %ecx
    5af9:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5aff:      	movl	(%rcx,%r15), %ecx
    5b03:      	addq	%rax, %rcx
    5b06:      	movl	%ecx, %eax
    5b08:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5b0d:      	movl	(%rax,%r15), %ebp
    5b11:      	addq	%rcx, %rbp
    5b14:      	movl	%ebp, %eax
    5b16:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5b1b:      	movq	%rax, (%rsp)
    5b1f:      	cmpl	$0x19, (%r15,%rax)
    5b24:      	jae	0x5b91 <generic_tracepoint_arg+0x161>
    5b26:      	movq	(%rsp), %rax
    5b2a:      	cmpq	$0x1, %rax
    5b2e:      	je	0x5e11 <generic_tracepoint_arg+0x3e1>
    5b34:      	testl	%eax, %eax
    5b36:      	jne	0x5deb <generic_tracepoint_arg+0x3bb>
    5b3c:      	cmpl	$0x1, %r12d
    5b40:      	jg	0x5b61 <generic_tracepoint_arg+0x131>
    5b42:      	cmpl	$-0x1, %r12d
    5b46:      	je	0x5e3d <generic_tracepoint_arg+0x40d>
    5b4c:      	testl	%r12d, %r12d
    5b4f:      	je	0x5e4a <generic_tracepoint_arg+0x41a>
    5b55:      	cmpl	$0x1, %r12d
    5b59:      	je	0x5e5a <generic_tracepoint_arg+0x42a>
    5b5f:      	jmp	0x5b7f <generic_tracepoint_arg+0x14f>
    5b61:      	cmpl	$0x2, %r12d
    5b65:      	je	0x5e6a <generic_tracepoint_arg+0x43a>
    5b6b:      	cmpl	$0x3, %r12d
    5b6f:      	je	0x5e7a <generic_tracepoint_arg+0x44a>
    5b75:      	cmpl	$0x4, %r12d
    5b79:      	je	0x5e8a <generic_tracepoint_arg+0x45a>
    5b7f:      	cmpl	$0x4, %r12d
    5b83:      	jg	0x5ebc <generic_tracepoint_arg+0x48c>
    5b89:      	incl	%r12d
    5b8c:      	jmp	0x5e9a <generic_tracepoint_arg+0x46a>
    5b91:      	movq	(%rsp), %rax
    5b95:      	addq	%r15, %rax
    5b98:      	movq	%rax, 0x10(%rsp)
    5b9d:      	movl	$0x1, %r13d
    5ba3:      	nopw	%cs:(%rax,%rax)
    5bb0:      	movq	0x10(%rsp), %rax
    5bb5:      	movl	(%rax,%r13,4), %edi
    5bb9:      	testl	$0x3ff, %edi            # imm = 0x3FF
    5bbf:      	je	0x5b26 <generic_tracepoint_arg+0xf6>
    5bc5:      	addl	%ebp, %edi
    5bc7:      	andl	$0x3ff, %edi            # imm = 0x3FF
    5bcd:      	movl	0x4(%r15,%rdi), %ecx
    5bd2:      	cmpl	$0x23, %ecx
    5bd5:      	je	0x5b3c <generic_tracepoint_arg+0x10c>
    5bdb:      	addq	%r15, %rdi
    5bde:      	movl	(%rdi), %eax
    5be0:      	cmpq	$0x4, %rax
    5be4:      	ja	0x5b3c <generic_tracepoint_arg+0x10c>
    5bea:      	cmpl	$0x0, 0x5ea0(%r14,%rax,4)
    5bf3:      	jne	0x5b3c <generic_tracepoint_arg+0x10c>
    5bf9:      	movq	0x5e78(%r14,%rax,8), %rax
    5c01:      	andl	$0x7ff, %eax            # imm = 0x7FF
    5c06:      	leaq	(%r14,%rax), %rsi
    5c0a:      	addq	$0x90, %rsi
    5c11:      	movl	0xc(%rdi), %eax
    5c14:      	cmpl	$0x1b, %eax
    5c17:      	jle	0x5c38 <generic_tracepoint_arg+0x208>
    5c19:      	cmpl	$0x25, %eax
    5c1c:      	jg	0x5c68 <generic_tracepoint_arg+0x238>
    5c1e:      	leal	-0x1c(%rax), %edx
    5c21:      	cmpl	$0x9, %edx
    5c24:      	jb	0x5cae <generic_tracepoint_arg+0x27e>
    5c2a:      	cmpl	$0x25, %eax
    5c2d:      	je	0x5d91 <generic_tracepoint_arg+0x361>
    5c33:      	jmp	0x5dd9 <generic_tracepoint_arg+0x3a9>
    5c38:      	cmpl	$0x9, %eax
    5c3b:      	jle	0x5c8e <generic_tracepoint_arg+0x25e>
    5c3d:      	leal	-0xa(%rax), %edx
    5c40:      	cmpl	$0x4, %edx
    5c43:      	jb	0x5cae <generic_tracepoint_arg+0x27e>
    5c45:      	leal	-0xf(%rax), %ecx
    5c48:      	cmpl	$0x2, %ecx
    5c4b:      	jb	0x5d91 <generic_tracepoint_arg+0x361>
    5c51:      	cmpl	$0x11, %eax
    5c54:      	jne	0x5dd9 <generic_tracepoint_arg+0x3a9>
    5c5a:      	addq	$0x4, %rsi
    5c5e:      	callq	0x5c63 <generic_tracepoint_arg+0x233>
    5c63:      	jmp	0x5dd0 <generic_tracepoint_arg+0x3a0>
    5c68:      	cmpl	$0x29, %eax
    5c6b:      	jg	0x5d80 <generic_tracepoint_arg+0x350>
    5c71:      	leal	-0x26(%rax), %ecx
    5c74:      	cmpl	$0x2, %ecx
    5c77:      	jb	0x5d3b <generic_tracepoint_arg+0x30b>
    5c7d:      	addl	$-0x28, %eax
    5c80:      	cmpl	$0x2, %eax
    5c83:      	jb	0x5d31 <generic_tracepoint_arg+0x301>
    5c89:      	jmp	0x5dd9 <generic_tracepoint_arg+0x3a9>
    5c8e:      	cmpl	$0x4, %eax
    5c91:      	jg	0x5d1e <generic_tracepoint_arg+0x2ee>
    5c97:      	cmpl	$0x1, %eax
    5c9a:      	je	0x5cae <generic_tracepoint_arg+0x27e>
    5c9c:      	cmpl	$0x2, %eax
    5c9f:      	je	0x5dae <generic_tracepoint_arg+0x37e>
    5ca5:      	cmpl	$0x4, %eax
    5ca8:      	jne	0x5dd9 <generic_tracepoint_arg+0x3a9>
    5cae:      	cmpl	$0xb, %eax
    5cb1:      	jle	0x5cfb <generic_tracepoint_arg+0x2cb>
    5cb3:      	cmpl	$0x24, %eax
    5cb6:      	ja	0x5d98 <generic_tracepoint_arg+0x368>
    5cbc:      	movl	%eax, %edx
    5cbe:      	movabsq	$0x1e00000000, %r8      # imm = 0x1E00000000
    5cc8:      	btq	%rdx, %r8
    5ccc:      	jb	0x5d42 <generic_tracepoint_arg+0x312>
    5cce:      	movl	$0x60000000, %ecx       # imm = 0x60000000
    5cd3:      	btq	%rdx, %rcx
    5cd7:      	jb	0x5da7 <generic_tracepoint_arg+0x377>
    5cdd:      	movabsq	$0x180000000, %rcx      # imm = 0x180000000
    5ce7:      	btq	%rdx, %rcx
    5ceb:      	jae	0x5d98 <generic_tracepoint_arg+0x368>
    5cf1:      	callq	0x5cf6 <generic_tracepoint_arg+0x2c6>
    5cf6:      	jmp	0x5dd0 <generic_tracepoint_arg+0x3a0>
    5cfb:      	leal	-0xa(%rax), %ecx
    5cfe:      	cmpl	$0x2, %ecx
    5d01:      	jb	0x5dbf <generic_tracepoint_arg+0x38f>
    5d07:      	cmpl	$0x1, %eax
    5d0a:      	je	0x5da0 <generic_tracepoint_arg+0x370>
    5d10:      	cmpl	$0x4, %eax
    5d13:      	je	0x5da0 <generic_tracepoint_arg+0x370>
    5d19:      	jmp	0x5dd9 <generic_tracepoint_arg+0x3a9>
    5d1e:      	cmpl	$0x5, %eax
    5d21:      	je	0x5d31 <generic_tracepoint_arg+0x301>
    5d23:      	cmpl	$0x6, %eax
    5d26:      	je	0x5d3b <generic_tracepoint_arg+0x30b>
    5d28:      	cmpl	$0x7, %eax
    5d2b:      	jne	0x5dd9 <generic_tracepoint_arg+0x3a9>
    5d31:      	callq	0x5d36 <generic_tracepoint_arg+0x306>
    5d36:      	jmp	0x5dd0 <generic_tracepoint_arg+0x3a0>
    5d3b:      	movl	$0x4, %edx
    5d40:      	jmp	0x5db3 <generic_tracepoint_arg+0x383>
    5d42:      	cmpl	$0x1e, %ecx
    5d45:      	jne	0x5dbf <generic_tracepoint_arg+0x38f>
    5d47:      	movl	0x10(%rdi), %eax
    5d4a:      	andl	$0x7, %eax
    5d4d:      	movl	%eax, %ecx
    5d4f:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    5d58:      	jne	0x5b3c <generic_tracepoint_arg+0x10c>
    5d5e:      	movq	(%rsi), %rcx
    5d61:      	movq	0x5e78(%r14,%rax,8), %rdx
    5d69:      	andl	$0x7ff, %edx            # imm = 0x7FF
    5d6f:      	xorl	%eax, %eax
    5d71:      	andnq	0x90(%r14,%rdx), %rcx, %rcx
    5d7b:      	setne	%al
    5d7e:      	jmp	0x5dd0 <generic_tracepoint_arg+0x3a0>
    5d80:      	cmpl	$0x2a, %eax
    5d83:      	je	0x5d91 <generic_tracepoint_arg+0x361>
    5d85:      	cmpl	$0x2c, %eax
    5d88:      	jne	0x5dd9 <generic_tracepoint_arg+0x3a9>
    5d8a:      	callq	0x5d8f <generic_tracepoint_arg+0x35f>
    5d8f:      	jmp	0x5dd0 <generic_tracepoint_arg+0x3a0>
    5d91:      	callq	0x5d96 <generic_tracepoint_arg+0x366>
    5d96:      	jmp	0x5dd0 <generic_tracepoint_arg+0x3a0>
    5d98:      	leal	-0xc(%rax), %ecx
    5d9b:      	cmpl	$0x2, %ecx
    5d9e:      	jae	0x5dba <generic_tracepoint_arg+0x38a>
    5da0:      	callq	0x5da5 <generic_tracepoint_arg+0x375>
    5da5:      	jmp	0x5dd0 <generic_tracepoint_arg+0x3a0>
    5da7:      	callq	0x5dac <generic_tracepoint_arg+0x37c>
    5dac:      	jmp	0x5dd0 <generic_tracepoint_arg+0x3a0>
    5dae:      	movl	$0x8, %edx
    5db3:      	callq	0x5db8 <generic_tracepoint_arg+0x388>
    5db8:      	jmp	0x5dd0 <generic_tracepoint_arg+0x3a0>
    5dba:      	cmpl	$0x1c, %eax
    5dbd:      	jne	0x5dd9 <generic_tracepoint_arg+0x3a9>
    5dbf:      	callq	0x5dc4 <generic_tracepoint_arg+0x394>
    5dc4:      	nopw	%cs:(%rax,%rax)
    5dd0:      	testq	%rax, %rax
    5dd3:      	je	0x5b3c <generic_tracepoint_arg+0x10c>
    5dd9:      	incq	%r13
    5ddc:      	cmpq	$0x6, %r13
    5de0:      	jne	0x5bb0 <generic_tracepoint_arg+0x180>
    5de6:      	jmp	0x5b26 <generic_tracepoint_arg+0xf6>
    5deb:      	movq	(%rsp), %rax
    5def:      	movl	%eax, 0x5f04(%r14)
    5df6:      	movq	(%rip), %rsi            # 0x5dfd <generic_tracepoint_arg+0x3cd>
    5dfd:      	movl	$0x4, %ecx
    5e02:      	movl	$0xc, %eax
    5e07:      	movq	%rbx, %rdi
    5e0a:      	movl	$0x4, %edx
    5e0f:      	callq	*%rax
    5e11:      	movq	(%rip), %rsi            # 0x5e18 <generic_tracepoint_arg+0x3e8>
    5e18:      	movl	$0x5, %ecx
    5e1d:      	movl	$0xc, %eax
    5e22:      	movq	%rbx, %rdi
    5e25:      	movl	$0x5, %edx
    5e2a:      	callq	*%rax
    5e2c:      	xorl	%eax, %eax
    5e2e:      	addq	$0x28, %rsp
    5e32:      	popq	%rbx
    5e33:      	popq	%r12
    5e35:      	popq	%r13
    5e37:      	popq	%r14
    5e39:      	popq	%r15
    5e3b:      	popq	%rbp
    5e3c:      	retq
    5e3d:      	xorl	%r12d, %r12d
    5e40:      	cmpb	$0x0, 0x5ec1(%r14)
    5e48:      	jne	0x5e9a <generic_tracepoint_arg+0x46a>
    5e4a:      	movl	$0x1, %r12d
    5e50:      	cmpb	$0x0, 0x5ec2(%r14)
    5e58:      	jne	0x5e9a <generic_tracepoint_arg+0x46a>
    5e5a:      	movl	$0x2, %r12d
    5e60:      	cmpb	$0x0, 0x5ec3(%r14)
    5e68:      	jne	0x5e9a <generic_tracepoint_arg+0x46a>
    5e6a:      	movl	$0x3, %r12d
    5e70:      	cmpb	$0x0, 0x5ec4(%r14)
    5e78:      	jne	0x5e9a <generic_tracepoint_arg+0x46a>
    5e7a:      	movl	$0x4, %r12d
    5e80:      	cmpb	$0x0, 0x5ec5(%r14)
    5e88:      	jne	0x5e9a <generic_tracepoint_arg+0x46a>
    5e8a:      	movl	$0x5, %r12d
    5e90:      	cmpb	$0x0, 0x5ec6(%r14)
    5e98:      	je	0x5ebc <generic_tracepoint_arg+0x48c>
    5e9a:      	movl	%r12d, 0x5f00(%r14)
    5ea1:      	movq	(%rip), %rsi            # 0x5ea8 <generic_tracepoint_arg+0x478>
    5ea8:      	movl	$0x3, %ecx
    5ead:      	movl	$0xc, %eax
    5eb2:      	movq	%rbx, %rdi
    5eb5:      	movl	$0x3, %edx
    5eba:      	callq	*%rax
    5ebc:      	movq	0x60(%r14), %rbx
    5ec0:      	movl	$0xe, %eax
    5ec5:      	callq	*%rax
    5ec7:      	movq	%rbx, 0x18(%rsp)
    5ecc:      	movq	%rax, 0x20(%rsp)
    5ed1:      	movq	(%rip), %rdi            # 0x5ed8 <generic_tracepoint_arg+0x4a8>
    5ed8:      	leaq	0x18(%rsp), %rsi
    5edd:      	movl	$0x1, %eax
    5ee2:      	callq	*%rax
    5ee4:      	testq	%rax, %rax
    5ee7:      	je	0x5e2c <generic_tracepoint_arg+0x3fc>
    5eed:      	movq	(%rip), %rdi            # 0x5ef4 <generic_tracepoint_arg+0x4c4>
    5ef4:      	leaq	0x18(%rsp), %rsi
    5ef9:      	movl	$0x3, %eax
    5efe:      	callq	*%rax
    5f00:      	jmp	0x5e2c <generic_tracepoint_arg+0x3fc>
    5f05:      	nopw	%cs:(%rax,%rax)

0000000000005f10 <generic_tracepoint_actions>:
    5f10:      	pushq	%rbp
    5f11:      	pushq	%r14
    5f13:      	pushq	%rbx
    5f14:      	subq	$0x10, %rsp
    5f18:      	movq	%rdi, %rbx
    5f1b:      	movl	$0x0, 0x8(%rsp)
    5f23:      	movq	(%rip), %rdi            # 0x5f2a <generic_tracepoint_actions+0x1a>
    5f2a:      	leaq	0x8(%rsp), %rsi
    5f2f:      	movl	$0x1, %eax
    5f34:      	callq	*%rax
    5f36:      	testq	%rax, %rax
    5f39:      	je	0x6042 <generic_tracepoint_actions+0x132>
    5f3f:      	movq	%rax, %rsi
    5f42:      	movl	0x5f04(%rax), %r14d
    5f49:      	cmpl	$0x2, %r14d
    5f4d:      	jl	0x6042 <generic_tracepoint_actions+0x132>
    5f53:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    5f5a:      	movq	(%rip), %rdi            # 0x5f61 <generic_tracepoint_actions+0x51>
    5f61:      	movl	$0x1, %eax
    5f66:      	callq	*%rax
    5f68:      	testq	%rax, %rax
    5f6b:      	je	0x6042 <generic_tracepoint_actions+0x132>
    5f71:      	movl	%r14d, %ecx
    5f74:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    5f7a:      	addl	(%rax,%rcx), %r14d
    5f7e:      	movb	$0x1, 0x7(%rsp)
    5f83:      	movl	$0x0, 0xc(%rsp)
    5f8b:      	movq	(%rip), %rdi            # 0x5f92 <generic_tracepoint_actions+0x82>
    5f92:      	leaq	0xc(%rsp), %rsi
    5f97:      	movq	%rax, %rcx
    5f9a:      	movl	$0x1, %eax
    5f9f:      	andl	$0x7ff, %r14d           # imm = 0x7FF
    5fa6:      	addq	%rcx, %r14
    5fa9:      	callq	*%rax
    5fab:      	testq	%rax, %rax
    5fae:      	je	0x5fbe <generic_tracepoint_actions+0xae>
    5fb0:      	cmpb	$0x0, (%rax)
    5fb3:      	sete	%al
    5fb6:      	cmpl	$0x5, (%r14)
    5fba:      	jae	0x5fc6 <generic_tracepoint_actions+0xb6>
    5fbc:      	jmp	0x6020 <generic_tracepoint_actions+0x110>
    5fbe:      	movb	$0x1, %al
    5fc0:      	cmpl	$0x5, (%r14)
    5fc4:      	jb	0x6020 <generic_tracepoint_actions+0x110>
    5fc6:      	movzbl	%al, %ebp
    5fc9:      	leaq	0x7(%rsp), %rcx
    5fce:      	movq	%rbx, %rdi
    5fd1:      	xorl	%esi, %esi
    5fd3:      	movq	%r14, %rdx
    5fd6:      	movl	%ebp, %r8d
    5fd9:      	callq	0x5fde <generic_tracepoint_actions+0xce>
    5fde:      	leal	0x4(,%rax,4), %ecx
    5fe5:      	cmpl	(%r14), %ecx
    5fe8:      	jae	0x6020 <generic_tracepoint_actions+0x110>
    5fea:      	leaq	0x7(%rsp), %rcx
    5fef:      	movq	%rbx, %rdi
    5ff2:      	movl	%eax, %esi
    5ff4:      	movq	%r14, %rdx
    5ff7:      	movl	%ebp, %r8d
    5ffa:      	callq	0x5fff <generic_tracepoint_actions+0xef>
    5fff:      	leal	0x4(,%rax,4), %ecx
    6006:      	cmpl	(%r14), %ecx
    6009:      	jae	0x6020 <generic_tracepoint_actions+0x110>
    600b:      	leaq	0x7(%rsp), %rcx
    6010:      	movq	%rbx, %rdi
    6013:      	movl	%eax, %esi
    6015:      	movq	%r14, %rdx
    6018:      	movl	%ebp, %r8d
    601b:      	callq	0x6020 <generic_tracepoint_actions+0x110>
    6020:      	cmpb	$0x0, 0x7(%rsp)
    6025:      	je	0x6042 <generic_tracepoint_actions+0x132>
    6027:      	movq	(%rip), %rsi            # 0x602e <generic_tracepoint_actions+0x11e>
    602e:      	movl	$0x5, %ecx
    6033:      	movl	$0xc, %eax
    6038:      	movq	%rbx, %rdi
    603b:      	movl	$0x5, %edx
    6040:      	callq	*%rax
    6042:      	xorl	%eax, %eax
    6044:      	addq	$0x10, %rsp
    6048:      	popq	%rbx
    6049:      	popq	%r14
    604b:      	popq	%rbp
    604c:      	retq
    604d:      	nopl	(%rax)

0000000000006050 <generic_tracepoint_output>:
    6050:      	pushq	%rbp
    6051:      	pushq	%r15
    6053:      	pushq	%r14
    6055:      	pushq	%r13
    6057:      	pushq	%r12
    6059:      	pushq	%rbx
    605a:      	subq	$0x78, %rsp
    605e:      	movq	%rdi, %r14
    6061:      	movl	$0x0, 0x24(%rsp)
    6069:      	movq	(%rip), %rdi            # 0x6070 <generic_tracepoint_output+0x20>
    6070:      	leaq	0x24(%rsp), %rsi
    6075:      	movl	$0x1, %eax
    607a:      	callq	*%rax
    607c:      	testq	%rax, %rax
    607f:      	je	0x6529 <generic_tracepoint_output+0x4d9>
    6085:      	movq	%rax, %rbx
    6088:      	cmpq	$0x0, 0x5ee8(%rax)
    6090:      	je	0x6398 <generic_tracepoint_output+0x348>
    6096:      	movl	$0xe, %eax
    609b:      	callq	*%rax
    609d:      	movq	%rax, %r15
    60a0:      	shrq	$0x20, %r15
    60a4:      	movl	$0x23, %eax
    60a9:      	callq	*%rax
    60ab:      	movq	%rax, %r12
    60ae:      	movl	%r15d, 0x28(%rsp)
    60b3:      	movq	(%rip), %rdi            # 0x60ba <generic_tracepoint_output+0x6a>
    60ba:      	leaq	0x28(%rsp), %rsi
    60bf:      	movl	$0x1, %eax
    60c4:      	callq	*%rax
    60c6:      	testq	%rax, %rax
    60c9:      	je	0x6398 <generic_tracepoint_output+0x348>
    60cf:      	movq	%rax, %r15
    60d2:      	leaq	0xd70(%r12), %rdx
    60da:      	leaq	0x70(%rsp), %rdi
    60df:      	movl	$0x8, %ecx
    60e4:      	movl	$0x4, %eax
    60e9:      	leaq	0x28(%r15), %r13
    60ed:      	movl	$0x4, %ebp
    60f2:      	movl	$0x8, %esi
    60f7:      	callq	*%rax
    60f9:      	movq	0x70(%rsp), %rcx
    60fe:      	leaq	0x28(%rsp), %rdi
    6103:      	movl	$0x48, %edx
    6108:      	movl	$0x4, %eax
    610d:      	movq	0x70(%rsp), %rdx
    6112:      	movl	$0x48, %esi
    6117:      	callq	*%rax
    6119:      	movl	$0x218, %edx            # imm = 0x218
    611e:      	movq	0x30(%rsp), %rcx
    6123:      	addq	%rdx, %rcx
    6126:      	movl	$0x4, %esi
    612b:      	movl	$0x4, %eax
    6130:      	addq	0x30(%rsp), %rdx
    6135:      	movq	%r13, %rdi
    6138:      	movl	$0x4, %esi
    613d:      	callq	*%rax
    613f:      	leaq	0x2c(%r15), %rdi
    6143:      	movl	$0x4d8, %edx            # imm = 0x4D8
    6148:      	movq	0x38(%rsp), %rcx
    614d:      	addq	%rdx, %rcx
    6150:      	movl	$0x4, %esi
    6155:      	movl	$0x4, %eax
    615a:      	addq	0x38(%rsp), %rdx
    615f:      	movl	$0x4, %esi
    6164:      	callq	*%rax
    6166:      	leaq	0x30(%r15), %rdi
    616a:      	movq	0x40(%rsp), %rcx
    616f:      	addq	$0x58, %rcx
    6173:      	movl	$0x4, %edx
    6178:      	movl	$0x4, %eax
    617d:      	movq	0x40(%rsp), %rdx
    6182:      	addq	$0x58, %rdx
    6186:      	movl	$0x4, %esi
    618b:      	callq	*%rax
    618d:      	movq	$0x0, (%rsp)
    6195:      	leaq	0xb58(%r12), %rdx
    619d:      	movq	%rsp, %rdi
    61a0:      	movl	$0x8, %ecx
    61a5:      	movl	$0x4, %eax
    61aa:      	movl	$0x8, %esi
    61af:      	callq	*%rax
    61b1:      	movq	(%rsp), %rcx
    61b5:      	testq	%rcx, %rcx
    61b8:      	je	0x624b <generic_tracepoint_output+0x1fb>
    61be:      	movl	$0x0, 0xc(%rsp)
    61c6:      	addq	$0x4, %rcx
    61ca:      	leaq	0xc(%rsp), %rdi
    61cf:      	movl	$0x4, %eax
    61d4:      	movq	(%rsp), %rdx
    61d8:      	addq	$0x4, %rdx
    61dc:      	movl	$0x4, %esi
    61e1:      	callq	*%rax
    61e3:      	movq	(%rsp), %rax
    61e7:      	movslq	0xc(%rsp), %rcx
    61ec:      	shlq	$0x4, %rcx
    61f0:      	addq	%rax, %rcx
    61f3:      	addq	$0x80, %rcx
    61fa:      	leaq	0x10(%rsp), %rdi
    61ff:      	movl	$0x10, %edx
    6204:      	movl	$0x4, %eax
    6209:      	movq	(%rsp), %rcx
    620d:      	movslq	0xc(%rsp), %rdx
    6212:      	shlq	$0x4, %rdx
    6216:      	addq	%rcx, %rdx
    6219:      	addq	$0x80, %rdx
    6220:      	movl	$0x10, %esi
    6225:      	callq	*%rax
    6227:      	leaq	0x34(%r15), %rdi
    622b:      	movl	$0x158, %edx            # imm = 0x158
    6230:      	movq	0x18(%rsp), %rcx
    6235:      	addq	%rdx, %rcx
    6238:      	movl	$0x4, %eax
    623d:      	addq	0x18(%rsp), %rdx
    6242:      	movl	$0x4, %esi
    6247:      	callq	*%rax
    6249:      	jmp	0x6253 <generic_tracepoint_output+0x203>
    624b:      	movl	$0x0, 0x34(%r15)
    6253:      	leaq	0x38(%r15), %rdi
    6257:      	movl	$0x158, %r13d           # imm = 0x158
    625d:      	movq	0x48(%rsp), %rcx
    6262:      	addq	%r13, %rcx
    6265:      	movl	$0x4, %edx
    626a:      	movl	$0x4, %eax
    626f:      	movq	0x48(%rsp), %rdx
    6274:      	addq	%r13, %rdx
    6277:      	movl	$0x4, %esi
    627c:      	callq	*%rax
    627e:      	leaq	0x3c(%r15), %rdi
    6282:      	movl	$0x118, %edx            # imm = 0x118
    6287:      	movq	0x50(%rsp), %rcx
    628c:      	addq	%rdx, %rcx
    628f:      	movl	$0x4, %esi
    6294:      	movl	$0x4, %eax
    6299:      	addq	0x50(%rsp), %rdx
    629e:      	movl	$0x4, %esi
    62a3:      	callq	*%rax
    62a5:      	leaq	0x40(%r15), %rdi
    62a9:      	movl	$0x98, %ebp
    62ae:      	movq	0x58(%rsp), %rcx
    62b3:      	addq	%rbp, %rcx
    62b6:      	movl	$0x4, %edx
    62bb:      	movl	$0x4, %eax
    62c0:      	movq	0x58(%rsp), %rdx
    62c5:      	addq	%rbp, %rdx
    62c8:      	movl	$0x4, %esi
    62cd:      	callq	*%rax
    62cf:      	leaq	0x44(%r15), %rdi
    62d3:      	movq	0x60(%rsp), %rcx
    62d8:      	addq	%rbp, %rcx
    62db:      	movl	$0x4, %edx
    62e0:      	movl	$0x4, %eax
    62e5:      	addq	0x60(%rsp), %rbp
    62ea:      	movl	$0x4, %esi
    62ef:      	movq	%rbp, %rdx
    62f2:      	callq	*%rax
    62f4:      	leaq	0x48(%r15), %rdi
    62f8:      	movq	0x68(%rsp), %rcx
    62fd:      	addq	$0x58, %rcx
    6301:      	movl	$0x4, %edx
    6306:      	movl	$0x4, %eax
    630b:      	movq	0x68(%rsp), %rdx
    6310:      	addq	$0x58, %rdx
    6314:      	movl	$0x4, %esi
    6319:      	callq	*%rax
    631b:      	movq	$0x0, 0x10(%rsp)
    6324:      	movq	$0x0, (%rsp)
    632c:      	addq	$0xd00, %r12            # imm = 0xD00
    6333:      	leaq	0x10(%rsp), %rdi
    6338:      	movl	$0x8, %ecx
    633d:      	movl	$0x4, %eax
    6342:      	movl	$0x8, %esi
    6347:      	movq	%r12, %rdx
    634a:      	callq	*%rax
    634c:      	movl	$0x90, %edx
    6351:      	movq	0x10(%rsp), %rcx
    6356:      	addq	%rdx, %rcx
    6359:      	movq	%rsp, %rdi
    635c:      	movl	$0x8, %esi
    6361:      	movl	$0x4, %eax
    6366:      	addq	0x10(%rsp), %rdx
    636b:      	movl	$0x8, %esi
    6370:      	callq	*%rax
    6372:      	addq	$0x4c, %r15
    6376:      	movq	(%rsp), %rcx
    637a:      	addq	%r13, %rcx
    637d:      	movl	$0x4, %edx
    6382:      	movl	$0x4, %eax
    6387:      	addq	(%rsp), %r13
    638b:      	movq	%r15, %rdi
    638e:      	movl	$0x4, %esi
    6393:      	movq	%r13, %rdx
    6396:      	callq	*%rax
    6398:      	cmpq	$0x0, 0x5ef0(%rbx)
    63a0:      	je	0x6459 <generic_tracepoint_output+0x409>
    63a6:      	movl	$0xe, %eax
    63ab:      	callq	*%rax
    63ad:      	movq	%rax, %r15
    63b0:      	shrq	$0x20, %r15
    63b4:      	movl	$0x23, %eax
    63b9:      	callq	*%rax
    63bb:      	movq	%rax, %r12
    63be:      	movl	%r15d, 0x28(%rsp)
    63c3:      	movq	(%rip), %rdi            # 0x63ca <generic_tracepoint_output+0x37a>
    63ca:      	leaq	0x28(%rsp), %rsi
    63cf:      	movl	$0x1, %eax
    63d4:      	callq	*%rax
    63d6:      	testq	%rax, %rax
    63d9:      	je	0x6459 <generic_tracepoint_output+0x409>
    63db:      	leaq	0x50(%rax), %r15
    63df:      	addq	$0xd00, %r12            # imm = 0xD00
    63e6:      	leaq	0x28(%rsp), %rdi
    63eb:      	movl	$0x8, %ecx
    63f0:      	movq	%rax, %r13
    63f3:      	movl	$0x4, %eax
    63f8:      	movl	$0x8, %esi
    63fd:      	movq	%r12, %rdx
    6400:      	callq	*%rax
    6402:      	movq	0x28(%rsp), %r12
    6407:      	leaq	0x58(%r13), %rdi
    640b:      	leaq	0x40(%r12), %rdx
    6410:      	movl	$0x8, %ecx
    6415:      	movl	$0x4, %eax
    641a:      	movl	$0x8, %esi
    641f:      	callq	*%rax
    6421:      	addq	$0x60, %r13
    6425:      	leaq	0x30(%r12), %rdx
    642a:      	movl	$0x8, %ecx
    642f:      	movl	$0x4, %eax
    6434:      	movq	%r13, %rdi
    6437:      	movl	$0x8, %esi
    643c:      	callq	*%rax
    643e:      	addq	$0x38, %r12
    6442:      	movl	$0x8, %ecx
    6447:      	movl	$0x4, %eax
    644c:      	movq	%r15, %rdi
    644f:      	movl	$0x8, %esi
    6454:      	movq	%r12, %rdx
    6457:      	callq	*%rax
    6459:      	movl	$0x90, %eax
    645e:      	addl	0x4(%rbx), %eax
    6461:      	andl	$0x7fff, %eax           # imm = 0x7FFF
    6466:      	cmpl	$0x2328, %eax           # imm = 0x2328
    646b:      	movl	$0x2328, %r15d          # imm = 0x2328
    6471:      	cmovbl	%eax, %r15d
    6475:      	movl	$0x0, 0x10(%rsp)
    647d:      	movq	(%rip), %rdi            # 0x6484 <generic_tracepoint_output+0x434>
    6484:      	leaq	0x10(%rsp), %rsi
    6489:      	movl	$0x1, %eax
    648e:      	callq	*%rax
    6490:      	testq	%rax, %rax
    6493:      	je	0x64e7 <generic_tracepoint_output+0x497>
    6495:      	cmpb	$0x0, 0x28(%rax)
    6499:      	je	0x64e7 <generic_tracepoint_output+0x497>
    649b:      	movq	(%rip), %rsi            # 0x64a2 <generic_tracepoint_output+0x452>
    64a2:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    64a7:      	movl	$0x19, %eax
    64ac:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    64b1:      	movq	%r14, %rdi
    64b4:      	movq	%rbx, %rcx
    64b7:      	movq	%r15, %r8
    64ba:      	callq	*%rax
    64bc:      	testq	%rax, %rax
    64bf:      	js	0x6589 <generic_tracepoint_output+0x539>
    64c5:      	movl	$0x0, 0x28(%rsp)
    64cd:      	movq	(%rip), %rdi            # 0x64d4 <generic_tracepoint_output+0x484>
    64d4:      	leaq	0x28(%rsp), %rsi
    64d9:      	movl	$0x1, %eax
    64de:      	callq	*%rax
    64e0:      	testq	%rax, %rax
    64e3:      	jne	0x6524 <generic_tracepoint_output+0x4d4>
    64e5:      	jmp	0x6529 <generic_tracepoint_output+0x4d9>
    64e7:      	movq	(%rip), %rdi            # 0x64ee <generic_tracepoint_output+0x49e>
    64ee:      	xorl	%ecx, %ecx
    64f0:      	movl	$0x82, %eax
    64f5:      	movq	%rbx, %rsi
    64f8:      	movq	%r15, %rdx
    64fb:      	xorl	%ecx, %ecx
    64fd:      	callq	*%rax
    64ff:      	testq	%rax, %rax
    6502:      	js	0x653a <generic_tracepoint_output+0x4ea>
    6504:      	movl	$0x0, 0x28(%rsp)
    650c:      	movq	(%rip), %rdi            # 0x6513 <generic_tracepoint_output+0x4c3>
    6513:      	leaq	0x28(%rsp), %rsi
    6518:      	movl	$0x1, %eax
    651d:      	callq	*%rax
    651f:      	testq	%rax, %rax
    6522:      	je	0x6529 <generic_tracepoint_output+0x4d9>
    6524:      	lock
    6525:      	incq	0x8(%rax)
    6529:      	xorl	%eax, %eax
    652b:      	addq	$0x78, %rsp
    652f:      	popq	%rbx
    6530:      	popq	%r12
    6532:      	popq	%r13
    6534:      	popq	%r14
    6536:      	popq	%r15
    6538:      	popq	%rbp
    6539:      	retq
    653a:      	movq	%rax, %rbx
    653d:      	movl	$0x0, 0x28(%rsp)
    6545:      	movq	(%rip), %rdi            # 0x654c <generic_tracepoint_output+0x4fc>
    654c:      	leaq	0x28(%rsp), %rsi
    6551:      	movl	$0x1, %eax
    6556:      	callq	*%rax
    6558:      	testq	%rax, %rax
    655b:      	je	0x6529 <generic_tracepoint_output+0x4d9>
    655d:      	cmpq	$-0xc, %rbx
    6561:      	jg	0x65d1 <generic_tracepoint_output+0x581>
    6563:      	cmpq	$-0x1c, %rbx
    6567:      	je	0x6613 <generic_tracepoint_output+0x5c3>
    656d:      	cmpq	$-0x16, %rbx
    6571:      	je	0x65c2 <generic_tracepoint_output+0x572>
    6573:      	cmpq	$-0x10, %rbx
    6577:      	jne	0x6604 <generic_tracepoint_output+0x5b4>
    657d:      	addq	$0x328, %rax            # imm = 0x328
    6583:      	lock
    6584:      	incq	(%rax)
    6587:      	jmp	0x6529 <generic_tracepoint_output+0x4d9>
    6589:      	movq	%rax, %rbx
    658c:      	movl	$0x0, 0x28(%rsp)
    6594:      	movq	(%rip), %rdi            # 0x659b <generic_tracepoint_output+0x54b>
    659b:      	leaq	0x28(%rsp), %rsi
    65a0:      	movl	$0x1, %eax
    65a5:      	callq	*%rax
    65a7:      	testq	%rax, %rax
    65aa:      	je	0x6529 <generic_tracepoint_output+0x4d9>
    65b0:      	cmpq	$-0xc, %rbx
    65b4:      	jg	0x65f2 <generic_tracepoint_output+0x5a2>
    65b6:      	cmpq	$-0x1c, %rbx
    65ba:      	je	0x6613 <generic_tracepoint_output+0x5c3>
    65bc:      	cmpq	$-0x16, %rbx
    65c0:      	jne	0x6573 <generic_tracepoint_output+0x523>
    65c2:      	addq	$0x330, %rax            # imm = 0x330
    65c8:      	lock
    65c9:      	incq	(%rax)
    65cc:      	jmp	0x6529 <generic_tracepoint_output+0x4d9>
    65d1:      	cmpq	$-0xb, %rbx
    65d5:      	je	0x6622 <generic_tracepoint_output+0x5d2>
    65d7:      	cmpq	$-0x7, %rbx
    65db:      	je	0x6631 <generic_tracepoint_output+0x5e1>
    65dd:      	cmpq	$-0x2, %rbx
    65e1:      	jne	0x6604 <generic_tracepoint_output+0x5b4>
    65e3:      	addq	$0x318, %rax            # imm = 0x318
    65e9:      	lock
    65ea:      	incq	(%rax)
    65ed:      	jmp	0x6529 <generic_tracepoint_output+0x4d9>
    65f2:      	cmpq	$-0xb, %rbx
    65f6:      	je	0x6622 <generic_tracepoint_output+0x5d2>
    65f8:      	cmpq	$-0x7, %rbx
    65fc:      	je	0x6631 <generic_tracepoint_output+0x5e1>
    65fe:      	cmpq	$-0x2, %rbx
    6602:      	je	0x65e3 <generic_tracepoint_output+0x593>
    6604:      	addq	$0x310, %rax            # imm = 0x310
    660a:      	lock
    660b:      	incq	(%rax)
    660e:      	jmp	0x6529 <generic_tracepoint_output+0x4d9>
    6613:      	addq	$0x338, %rax            # imm = 0x338
    6619:      	lock
    661a:      	incq	(%rax)
    661d:      	jmp	0x6529 <generic_tracepoint_output+0x4d9>
    6622:      	addq	$0x340, %rax            # imm = 0x340
    6628:      	lock
    6629:      	incq	(%rax)
    662c:      	jmp	0x6529 <generic_tracepoint_output+0x4d9>
    6631:      	addq	$0x320, %rax            # imm = 0x320
    6637:      	lock
    6638:      	incq	(%rax)
    663b:      	jmp	0x6529 <generic_tracepoint_output+0x4d9>

Disassembly of section tracepoint/generic_tracepoint:

0000000000000000 <generic_tracepoint_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x88, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x80(%rsp)
      1f:      	movq	(%rip), %rdi            # 0x26 <generic_tracepoint_event+0x26>
      26:      	leaq	0x80(%rsp), %rsi
      2e:      	movl	$0x1, %eax
      33:      	callq	*%rax
      35:      	testq	%rax, %rax
      38:      	je	0x32ec <generic_tracepoint_event+0x32ec>
      3e:      	movq	%rax, %r14
      41:      	movq	(%rip), %rdi            # 0x48 <generic_tracepoint_event+0x48>
      48:      	leaq	0x80(%rsp), %rsi
      50:      	movl	$0x1, %eax
      55:      	callq	*%rax
      57:      	testq	%rax, %rax
      5a:      	je	0x32ec <generic_tracepoint_event+0x32ec>
      60:      	movq	%rax, %r15
      63:      	movl	0x64(%rax), %eax
      66:      	movl	%eax, 0x7c(%rsp)
      6a:      	testl	%eax, %eax
      6c:      	je	0x23f <generic_tracepoint_event+0x23f>
      72:      	movq	(%rip), %rdi            # 0x79 <generic_tracepoint_event+0x79>
      79:      	leaq	0x7c(%rsp), %rsi
      7e:      	movl	$0x1, %eax
      83:      	callq	*%rax
      85:      	testq	%rax, %rax
      88:      	je	0x32ec <generic_tracepoint_event+0x32ec>
      8e:      	movq	%rax, %r12
      91:      	movl	$0x0, 0x84(%rsp)
      9c:      	movq	(%rip), %rdi            # 0xa3 <generic_tracepoint_event+0xa3>
      a3:      	leaq	0x84(%rsp), %rsi
      ab:      	movl	$0x1, %eax
      b0:      	callq	*%rax
      b2:      	testq	%rax, %rax
      b5:      	je	0xdb <generic_tracepoint_event+0xdb>
      b7:      	cmpq	$0x63677270, 0x20(%rax) # imm = 0x63677270
      bf:      	jne	0xdf <generic_tracepoint_event+0xdf>
      c1:      	movl	$0x50, %eax
      c6:      	callq	*%rax
      c8:      	movq	%rax, 0x68(%rsp)
      cd:      	testq	%rax, %rax
      d0:      	jne	0x1ed <generic_tracepoint_event+0x1ed>
      d6:      	jmp	0x32ec <generic_tracepoint_event+0x32ec>
      db:      	xorl	%ebp, %ebp
      dd:      	jmp	0xe2 <generic_tracepoint_event+0xe2>
      df:      	movl	0x10(%rax), %ebp
      e2:      	movl	$0x23, %eax
      e7:      	callq	*%rax
      e9:      	movq	$0x0, 0x8(%rsp)
      f2:      	leaq	0xf90(%rax), %rdx
      f9:      	leaq	0x10(%rsp), %rdi
      fe:      	movl	$0x8, %ecx
     103:      	movl	$0x71, %eax
     108:      	movl	$0x8, %esi
     10d:      	callq	*%rax
     10f:      	movq	0x10(%rsp), %rax
     114:      	testq	%rax, %rax
     117:      	je	0x168 <generic_tracepoint_event+0x168>
     119:      	cmpl	$0xb, %ebp
     11c:      	ja	0x168 <generic_tracepoint_event+0x168>
     11e:      	movl	%ebp, %edx
     120:      	leaq	(%rax,%rdx,8), %rcx
     124:      	leaq	0x20(%rsp), %rdi
     129:      	movl	$0x8, %esi
     12e:      	movl	$0x71, %eax
     133:      	shlq	$0x3, %rdx
     137:      	addq	0x10(%rsp), %rdx
     13c:      	movl	$0x8, %esi
     141:      	callq	*%rax
     143:      	movq	0x20(%rsp), %rcx
     148:      	testq	%rcx, %rcx
     14b:      	je	0x168 <generic_tracepoint_event+0x168>
     14d:      	leaq	0x8(%rsp), %rdi
     152:      	movl	$0x8, %edx
     157:      	movl	$0x71, %eax
     15c:      	movq	0x20(%rsp), %rdx
     161:      	movl	$0x8, %esi
     166:      	callq	*%rax
     168:      	movq	0x8(%rsp), %rdx
     16d:      	testq	%rdx, %rdx
     170:      	je	0x32ec <generic_tracepoint_event+0x32ec>
     176:      	movq	$0x0, 0x20(%rsp)
     17f:      	addq	$0x100, %rdx            # imm = 0x100
     186:      	leaq	0x20(%rsp), %rdi
     18b:      	movl	$0x8, %ecx
     190:      	movl	$0x71, %eax
     195:      	movl	$0x8, %esi
     19a:      	callq	*%rax
     19c:      	movq	0x20(%rsp), %rdx
     1a1:      	movq	$0x0, 0x20(%rsp)
     1aa:      	testq	%rdx, %rdx
     1ad:      	je	0x1dd <generic_tracepoint_event+0x1dd>
     1af:      	addq	$0x60, %rdx
     1b3:      	leaq	0x20(%rsp), %rdi
     1b8:      	movl	$0x8, %ecx
     1bd:      	movl	$0x71, %eax
     1c2:      	movl	$0x8, %esi
     1c7:      	callq	*%rax
     1c9:      	movq	0x20(%rsp), %rax
     1ce:      	movq	%rax, 0x68(%rsp)
     1d3:      	testq	%rax, %rax
     1d6:      	jne	0x1ed <generic_tracepoint_event+0x1ed>
     1d8:      	jmp	0x32ec <generic_tracepoint_event+0x32ec>
     1dd:      	xorl	%eax, %eax
     1df:      	movq	%rax, 0x68(%rsp)
     1e4:      	testq	%rax, %rax
     1e7:      	je	0x32ec <generic_tracepoint_event+0x32ec>
     1ed:      	movq	%rax, 0x20(%rsp)
     1f2:      	movq	(%rip), %rdi            # 0x1f9 <generic_tracepoint_event+0x1f9>
     1f9:      	leaq	0x20(%rsp), %rsi
     1fe:      	movl	$0x1, %eax
     203:      	callq	*%rax
     205:      	testq	%rax, %rax
     208:      	je	0x21e <generic_tracepoint_event+0x21e>
     20a:      	movq	(%rax), %rax
     20d:      	movq	%rax, 0x70(%rsp)
     212:      	testq	%rax, %rax
     215:      	je	0x227 <generic_tracepoint_event+0x227>
     217:      	movq	%rax, 0x68(%rsp)
     21c:      	jmp	0x227 <generic_tracepoint_event+0x227>
     21e:      	movq	$0x0, 0x70(%rsp)
     227:      	leaq	0x68(%rsp), %rsi
     22c:      	movl	$0x1, %eax
     231:      	movq	%r12, %rdi
     234:      	callq	*%rax
     236:      	testq	%rax, %rax
     239:      	je	0x461 <generic_tracepoint_event+0x461>
     23f:      	movl	$0x0, 0x5ef8(%r14)
     24a:      	movl	(%r15), %eax
     24d:      	movq	%rax, 0x60(%r14)
     251:      	movq	$0x0, 0x68(%r14)
     259:      	movzwl	0x2c(%r15), %edx
     25e:      	movl	0x4(%r15), %r13d
     262:      	addq	%rbx, %rdx
     265:      	xorl	%r12d, %r12d
     268:      	cmpl	$0xb, %r13d
     26c:      	jg	0x2a5 <generic_tracepoint_event+0x2a5>
     26e:      	cmpl	$0x3, %r13d
     272:      	jle	0x336 <generic_tracepoint_event+0x336>
     278:      	cmpl	$0x6, %r13d
     27c:      	jg	0x4c3 <generic_tracepoint_event+0x4c3>
     282:      	cmpl	$0x4, %r13d
     286:      	je	0x924 <generic_tracepoint_event+0x924>
     28c:      	cmpl	$0x5, %r13d
     290:      	je	0x7c9 <generic_tracepoint_event+0x7c9>
     296:      	cmpl	$0x6, %r13d
     29a:      	je	0x357 <generic_tracepoint_event+0x357>
     2a0:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     2a5:      	cmpl	$0x1d, %r13d
     2a9:      	jle	0x3d4 <generic_tracepoint_event+0x3d4>
     2af:      	cmpl	$0x25, %r13d
     2b3:      	jg	0x52f <generic_tracepoint_event+0x52f>
     2b9:      	cmpl	$0x1e, %r13d
     2bd:      	je	0x983 <generic_tracepoint_event+0x983>
     2c3:      	cmpl	$0x1f, %r13d
     2c7:      	je	0x846 <generic_tracepoint_event+0x846>
     2cd:      	cmpl	$0x20, %r13d
     2d1:      	jne	0xb87 <generic_tracepoint_event+0xb87>
     2d7:      	leaq	0x8(%rsp), %rdi
     2dc:      	movl	$0x1, %ecx
     2e1:      	movl	$0x4, %eax
     2e6:      	movl	$0x1, %esi
     2eb:      	callq	*%rax
     2ed:      	testq	%rax, %rax
     2f0:      	je	0xafc <generic_tracepoint_event+0xafc>
     2f6:      	negl	%eax
     2f8:      	movw	%ax, 0x20(%rsp)
     2fd:      	movw	$0x7, 0x22(%rsp)
     304:      	movabsq	$0x400000073, %rax      # imm = 0x400000073
     30e:      	movq	%rax, 0x24(%rsp)
     313:      	movq	(%rip), %rdi            # 0x31a <generic_tracepoint_event+0x31a>
     31a:      	leaq	0x20(%rsp), %rsi
     31f:      	movl	$0x1, %eax
     324:      	callq	*%rax
     326:      	testq	%rax, %rax
     329:      	je	0xad8 <generic_tracepoint_event+0xad8>
     32f:      	incl	(%rax)
     331:      	jmp	0xafc <generic_tracepoint_event+0xafc>
     336:      	cmpl	$-0xc, %r13d
     33a:      	jle	0x5ca <generic_tracepoint_event+0x5ca>
     340:      	leal	0xb(%r13), %eax
     344:      	cmpl	$0x2, %eax
     347:      	jb	0x4d0 <generic_tracepoint_event+0x4d0>
     34d:      	cmpl	$0x2, %r13d
     351:      	jne	0xb87 <generic_tracepoint_event+0xb87>
     357:      	leaq	0x10(%rsp), %rdi
     35c:      	movl	$0x8, %ecx
     361:      	movl	$0x4, %eax
     366:      	movl	$0x8, %esi
     36b:      	callq	*%rax
     36d:      	testq	%rax, %rax
     370:      	je	0xb2b <generic_tracepoint_event+0xb2b>
     376:      	negl	%eax
     378:      	movw	%ax, 0x20(%rsp)
     37d:      	movw	$0x7, 0x22(%rsp)
     384:      	movabsq	$0x400000081, %rax      # imm = 0x400000081
     38e:      	movq	%rax, 0x24(%rsp)
     393:      	movq	(%rip), %rdi            # 0x39a <generic_tracepoint_event+0x39a>
     39a:      	leaq	0x20(%rsp), %rsi
     39f:      	movl	$0x1, %eax
     3a4:      	callq	*%rax
     3a6:      	testq	%rax, %rax
     3a9:      	jne	0x97c <generic_tracepoint_event+0x97c>
     3af:      	movl	$0x1, 0x8(%rsp)
     3b7:      	movq	(%rip), %rdi            # 0x3be <generic_tracepoint_event+0x3be>
     3be:      	xorl	%ecx, %ecx
     3c0:      	leaq	0x20(%rsp), %rsi
     3c5:      	leaq	0x8(%rsp), %rdx
     3ca:      	movl	$0x2, %eax
     3cf:      	jmp	0xb27 <generic_tracepoint_event+0xb27>
     3d4:      	cmpl	$0x11, %r13d
     3d8:      	jle	0x5df <generic_tracepoint_event+0x5df>
     3de:      	cmpl	$0x12, %r13d
     3e2:      	je	0x7c1 <generic_tracepoint_event+0x7c1>
     3e8:      	cmpl	$0x1c, %r13d
     3ec:      	je	0x4d0 <generic_tracepoint_event+0x4d0>
     3f2:      	cmpl	$0x1d, %r13d
     3f6:      	jne	0xb87 <generic_tracepoint_event+0xb87>
     3fc:      	leaq	0x8(%rsp), %rdi
     401:      	movl	$0x2, %ecx
     406:      	movl	$0x4, %eax
     40b:      	movl	$0x2, %esi
     410:      	callq	*%rax
     412:      	testq	%rax, %rax
     415:      	je	0xa9e <generic_tracepoint_event+0xa9e>
     41b:      	negl	%eax
     41d:      	movw	%ax, 0x20(%rsp)
     422:      	movw	$0x7, 0x22(%rsp)
     429:      	movabsq	$0x40000006c, %rax      # imm = 0x40000006C
     433:      	movq	%rax, 0x24(%rsp)
     438:      	movq	(%rip), %rdi            # 0x43f <generic_tracepoint_event+0x43f>
     43f:      	leaq	0x20(%rsp), %rsi
     444:      	movl	$0x1, %eax
     449:      	callq	*%rax
     44b:      	testq	%rax, %rax
     44e:      	je	0xa7a <generic_tracepoint_event+0xa7a>
     454:      	incl	(%rax)
     456:      	movswq	0x8(%rsp), %r12
     45c:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     461:      	movq	$-0x1, 0x70(%rsp)
     46a:      	leaq	0x70(%rsp), %rsi
     46f:      	movl	$0x1, %eax
     474:      	movq	%r12, %rdi
     477:      	callq	*%rax
     479:      	testq	%rax, %rax
     47c:      	je	0x32ec <generic_tracepoint_event+0x32ec>
     482:      	movl	$0x1, 0x7c(%rsp)
     48a:      	movq	(%rip), %rdi            # 0x491 <generic_tracepoint_event+0x491>
     491:      	leaq	0x7c(%rsp), %rsi
     496:      	movl	$0x1, %eax
     49b:      	callq	*%rax
     49d:      	testq	%rax, %rax
     4a0:      	je	0x32ec <generic_tracepoint_event+0x32ec>
     4a6:      	movq	%rax, %rdi
     4a9:      	leaq	0x68(%rsp), %rsi
     4ae:      	movl	$0x1, %eax
     4b3:      	callq	*%rax
     4b5:      	testq	%rax, %rax
     4b8:      	jne	0x32ec <generic_tracepoint_event+0x32ec>
     4be:      	jmp	0x23f <generic_tracepoint_event+0x23f>
     4c3:      	leal	-0xa(%r13), %eax
     4c7:      	cmpl	$0x2, %eax
     4ca:      	jae	0x73a <generic_tracepoint_event+0x73a>
     4d0:      	leaq	0x10(%rsp), %rdi
     4d5:      	movl	$0x8, %ecx
     4da:      	movl	$0x4, %eax
     4df:      	movl	$0x8, %esi
     4e4:      	callq	*%rax
     4e6:      	testq	%rax, %rax
     4e9:      	je	0x6f8 <generic_tracepoint_event+0x6f8>
     4ef:      	negl	%eax
     4f1:      	movw	%ax, 0x20(%rsp)
     4f6:      	movw	$0x7, 0x22(%rsp)
     4fd:      	movabsq	$0x400000045, %rax      # imm = 0x400000045
     507:      	movq	%rax, 0x24(%rsp)
     50c:      	movq	(%rip), %rdi            # 0x513 <generic_tracepoint_event+0x513>
     513:      	leaq	0x20(%rsp), %rsi
     518:      	movl	$0x1, %eax
     51d:      	callq	*%rax
     51f:      	testq	%rax, %rax
     522:      	je	0x6d4 <generic_tracepoint_event+0x6d4>
     528:      	incl	(%rax)
     52a:      	jmp	0x6f8 <generic_tracepoint_event+0x6f8>
     52f:      	cmpl	$0x26, %r13d
     533:      	je	0x9e8 <generic_tracepoint_event+0x9e8>
     539:      	cmpl	$0x28, %r13d
     53d:      	je	0x8ab <generic_tracepoint_event+0x8ab>
     543:      	cmpl	$0x29, %r13d
     547:      	jne	0xb87 <generic_tracepoint_event+0xb87>
     54d:      	leaq	0x10(%rsp), %rdi
     552:      	movl	$0x8, %ecx
     557:      	movl	$0x4, %eax
     55c:      	movl	$0x8, %esi
     561:      	callq	*%rax
     563:      	testq	%rax, %rax
     566:      	je	0xb2b <generic_tracepoint_event+0xb2b>
     56c:      	negl	%eax
     56e:      	movw	%ax, 0x20(%rsp)
     573:      	movw	$0x7, 0x22(%rsp)
     57a:      	movabsq	$0x4000000a8, %rax      # imm = 0x4000000A8
     584:      	movq	%rax, 0x24(%rsp)
     589:      	movq	(%rip), %rdi            # 0x590 <generic_tracepoint_event+0x590>
     590:      	leaq	0x20(%rsp), %rsi
     595:      	movl	$0x1, %eax
     59a:      	callq	*%rax
     59c:      	testq	%rax, %rax
     59f:      	jne	0x97c <generic_tracepoint_event+0x97c>
     5a5:      	movl	$0x1, 0x8(%rsp)
     5ad:      	movq	(%rip), %rdi            # 0x5b4 <generic_tracepoint_event+0x5b4>
     5b4:      	xorl	%ecx, %ecx
     5b6:      	leaq	0x20(%rsp), %rsi
     5bb:      	leaq	0x8(%rsp), %rdx
     5c0:      	movl	$0x2, %eax
     5c5:      	jmp	0xb27 <generic_tracepoint_event+0xb27>
     5ca:      	cmpl	$-0xd, %r13d
     5ce:      	je	0x670 <generic_tracepoint_event+0x670>
     5d4:      	cmpl	$-0xc, %r13d
     5d8:      	je	0x5f3 <generic_tracepoint_event+0x5f3>
     5da:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     5df:      	cmpl	$0xc, %r13d
     5e3:      	je	0x670 <generic_tracepoint_event+0x670>
     5e9:      	cmpl	$0xd, %r13d
     5ed:      	jne	0xb87 <generic_tracepoint_event+0xb87>
     5f3:      	leaq	0x8(%rsp), %rdi
     5f8:      	movl	$0x4, %ecx
     5fd:      	movl	$0x4, %eax
     602:      	movl	$0x4, %esi
     607:      	callq	*%rax
     609:      	testq	%rax, %rax
     60c:      	je	0xb82 <generic_tracepoint_event+0xb82>
     612:      	negl	%eax
     614:      	movw	%ax, 0x20(%rsp)
     619:      	movw	$0x7, 0x22(%rsp)
     620:      	movabsq	$0x40000005e, %rax      # imm = 0x40000005E
     62a:      	movq	%rax, 0x24(%rsp)
     62f:      	movq	(%rip), %rdi            # 0x636 <generic_tracepoint_event+0x636>
     636:      	leaq	0x20(%rsp), %rsi
     63b:      	movl	$0x1, %eax
     640:      	callq	*%rax
     642:      	testq	%rax, %rax
     645:      	jne	0xa40 <generic_tracepoint_event+0xa40>
     64b:      	movl	$0x1, 0x10(%rsp)
     653:      	movq	(%rip), %rdi            # 0x65a <generic_tracepoint_event+0x65a>
     65a:      	xorl	%ecx, %ecx
     65c:      	leaq	0x20(%rsp), %rsi
     661:      	leaq	0x10(%rsp), %rdx
     666:      	movl	$0x2, %eax
     66b:      	jmp	0xb7e <generic_tracepoint_event+0xb7e>
     670:      	leaq	0x8(%rsp), %rdi
     675:      	movl	$0x4, %ecx
     67a:      	movl	$0x4, %eax
     67f:      	movl	$0x4, %esi
     684:      	callq	*%rax
     686:      	testq	%rax, %rax
     689:      	je	0xa70 <generic_tracepoint_event+0xa70>
     68f:      	negl	%eax
     691:      	movw	%ax, 0x20(%rsp)
     696:      	movw	$0x7, 0x22(%rsp)
     69d:      	movabsq	$0x400000056, %rax      # imm = 0x400000056
     6a7:      	movq	%rax, 0x24(%rsp)
     6ac:      	movq	(%rip), %rdi            # 0x6b3 <generic_tracepoint_event+0x6b3>
     6b3:      	leaq	0x20(%rsp), %rsi
     6b8:      	movl	$0x1, %eax
     6bd:      	callq	*%rax
     6bf:      	testq	%rax, %rax
     6c2:      	je	0xa4c <generic_tracepoint_event+0xa4c>
     6c8:      	incl	(%rax)
     6ca:      	movslq	0x8(%rsp), %r12
     6cf:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     6d4:      	movl	$0x1, 0x8(%rsp)
     6dc:      	movq	(%rip), %rdi            # 0x6e3 <generic_tracepoint_event+0x6e3>
     6e3:      	xorl	%ecx, %ecx
     6e5:      	leaq	0x20(%rsp), %rsi
     6ea:      	leaq	0x8(%rsp), %rdx
     6ef:      	movl	$0x2, %eax
     6f4:      	xorl	%ecx, %ecx
     6f6:      	callq	*%rax
     6f8:      	movq	0x10(%rsp), %r12
     6fd:      	cmpl	$0x1c, %r13d
     701:      	jne	0xb87 <generic_tracepoint_event+0xb87>
     707:      	movl	$0x23, %eax
     70c:      	callq	*%rax
     70e:      	leaq	0x10(%rax), %rdx
     712:      	leaq	0x20(%rsp), %rdi
     717:      	movl	$0x4, %ecx
     71c:      	movl	$0x4, %eax
     721:      	movl	$0x4, %esi
     726:      	callq	*%rax
     728:      	movl	0x20(%rsp), %eax
     72c:      	andl	$-0x2, %eax
     72f:      	shll	$0x1e, %eax
     732:      	orq	%rax, %r12
     735:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     73a:      	cmpl	$0x7, %r13d
     73e:      	jne	0xb87 <generic_tracepoint_event+0xb87>
     744:      	leaq	0x10(%rsp), %rdi
     749:      	movl	$0x8, %ecx
     74e:      	movl	$0x4, %eax
     753:      	movl	$0x8, %esi
     758:      	callq	*%rax
     75a:      	testq	%rax, %rax
     75d:      	je	0xb2b <generic_tracepoint_event+0xb2b>
     763:      	negl	%eax
     765:      	movw	%ax, 0x20(%rsp)
     76a:      	movw	$0x7, 0x22(%rsp)
     771:      	movabsq	$0x40000009a, %rax      # imm = 0x40000009A
     77b:      	movq	%rax, 0x24(%rsp)
     780:      	movq	(%rip), %rdi            # 0x787 <generic_tracepoint_event+0x787>
     787:      	leaq	0x20(%rsp), %rsi
     78c:      	movl	$0x1, %eax
     791:      	callq	*%rax
     793:      	testq	%rax, %rax
     796:      	jne	0x97c <generic_tracepoint_event+0x97c>
     79c:      	movl	$0x1, 0x8(%rsp)
     7a4:      	movq	(%rip), %rdi            # 0x7ab <generic_tracepoint_event+0x7ab>
     7ab:      	xorl	%ecx, %ecx
     7ad:      	leaq	0x20(%rsp), %rsi
     7b2:      	leaq	0x8(%rsp), %rdx
     7b7:      	movl	$0x2, %eax
     7bc:      	jmp	0xb27 <generic_tracepoint_event+0xb27>
     7c1:      	movq	%rdx, %r12
     7c4:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     7c9:      	leaq	0x10(%rsp), %rdi
     7ce:      	movl	$0x8, %ecx
     7d3:      	movl	$0x4, %eax
     7d8:      	movl	$0x8, %esi
     7dd:      	callq	*%rax
     7df:      	testq	%rax, %rax
     7e2:      	je	0xb2b <generic_tracepoint_event+0xb2b>
     7e8:      	negl	%eax
     7ea:      	movw	%ax, 0x20(%rsp)
     7ef:      	movw	$0x7, 0x22(%rsp)
     7f6:      	movabsq	$0x400000093, %rax      # imm = 0x400000093
     800:      	movq	%rax, 0x24(%rsp)
     805:      	movq	(%rip), %rdi            # 0x80c <generic_tracepoint_event+0x80c>
     80c:      	leaq	0x20(%rsp), %rsi
     811:      	movl	$0x1, %eax
     816:      	callq	*%rax
     818:      	testq	%rax, %rax
     81b:      	jne	0x97c <generic_tracepoint_event+0x97c>
     821:      	movl	$0x1, 0x8(%rsp)
     829:      	movq	(%rip), %rdi            # 0x830 <generic_tracepoint_event+0x830>
     830:      	xorl	%ecx, %ecx
     832:      	leaq	0x20(%rsp), %rsi
     837:      	leaq	0x8(%rsp), %rdx
     83c:      	movl	$0x2, %eax
     841:      	jmp	0xb27 <generic_tracepoint_event+0xb27>
     846:      	leaq	0x8(%rsp), %rdi
     84b:      	movl	$0x1, %ecx
     850:      	movl	$0x4, %eax
     855:      	movl	$0x1, %esi
     85a:      	callq	*%rax
     85c:      	testq	%rax, %rax
     85f:      	je	0xacd <generic_tracepoint_event+0xacd>
     865:      	negl	%eax
     867:      	movw	%ax, 0x20(%rsp)
     86c:      	movw	$0x7, 0x22(%rsp)
     873:      	movabsq	$0x40000007a, %rax      # imm = 0x40000007A
     87d:      	movq	%rax, 0x24(%rsp)
     882:      	movq	(%rip), %rdi            # 0x889 <generic_tracepoint_event+0x889>
     889:      	leaq	0x20(%rsp), %rsi
     88e:      	movl	$0x1, %eax
     893:      	callq	*%rax
     895:      	testq	%rax, %rax
     898:      	je	0xaa9 <generic_tracepoint_event+0xaa9>
     89e:      	incl	(%rax)
     8a0:      	movsbq	0x8(%rsp), %r12
     8a6:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     8ab:      	leaq	0x10(%rsp), %rdi
     8b0:      	movl	$0x8, %ecx
     8b5:      	movl	$0x4, %eax
     8ba:      	movl	$0x8, %esi
     8bf:      	callq	*%rax
     8c1:      	testq	%rax, %rax
     8c4:      	je	0xb2b <generic_tracepoint_event+0xb2b>
     8ca:      	negl	%eax
     8cc:      	movw	%ax, 0x20(%rsp)
     8d1:      	movw	$0x7, 0x22(%rsp)
     8d8:      	movabsq	$0x4000000a1, %rax      # imm = 0x4000000A1
     8e2:      	movq	%rax, 0x24(%rsp)
     8e7:      	movq	(%rip), %rdi            # 0x8ee <generic_tracepoint_event+0x8ee>
     8ee:      	leaq	0x20(%rsp), %rsi
     8f3:      	movl	$0x1, %eax
     8f8:      	callq	*%rax
     8fa:      	testq	%rax, %rax
     8fd:      	jne	0x97c <generic_tracepoint_event+0x97c>
     8ff:      	movl	$0x1, 0x8(%rsp)
     907:      	movq	(%rip), %rdi            # 0x90e <generic_tracepoint_event+0x90e>
     90e:      	xorl	%ecx, %ecx
     910:      	leaq	0x20(%rsp), %rsi
     915:      	leaq	0x8(%rsp), %rdx
     91a:      	movl	$0x2, %eax
     91f:      	jmp	0xb27 <generic_tracepoint_event+0xb27>
     924:      	leaq	0x10(%rsp), %rdi
     929:      	movl	$0x8, %ecx
     92e:      	movl	$0x4, %eax
     933:      	movl	$0x8, %esi
     938:      	callq	*%rax
     93a:      	testq	%rax, %rax
     93d:      	je	0xb2b <generic_tracepoint_event+0xb2b>
     943:      	negl	%eax
     945:      	movw	%ax, 0x20(%rsp)
     94a:      	movw	$0x7, 0x22(%rsp)
     951:      	movabsq	$0x40000004e, %rax      # imm = 0x40000004E
     95b:      	movq	%rax, 0x24(%rsp)
     960:      	movq	(%rip), %rdi            # 0x967 <generic_tracepoint_event+0x967>
     967:      	leaq	0x20(%rsp), %rsi
     96c:      	movl	$0x1, %eax
     971:      	callq	*%rax
     973:      	testq	%rax, %rax
     976:      	je	0xb07 <generic_tracepoint_event+0xb07>
     97c:      	incl	(%rax)
     97e:      	jmp	0xb2b <generic_tracepoint_event+0xb2b>
     983:      	leaq	0x8(%rsp), %rdi
     988:      	movl	$0x2, %ecx
     98d:      	movl	$0x4, %eax
     992:      	movl	$0x2, %esi
     997:      	callq	*%rax
     999:      	testq	%rax, %rax
     99c:      	je	0xb56 <generic_tracepoint_event+0xb56>
     9a2:      	negl	%eax
     9a4:      	movw	%ax, 0x20(%rsp)
     9a9:      	movw	$0x7, 0x22(%rsp)
     9b0:      	movabsq	$0x400000065, %rax      # imm = 0x400000065
     9ba:      	movq	%rax, 0x24(%rsp)
     9bf:      	movq	(%rip), %rdi            # 0x9c6 <generic_tracepoint_event+0x9c6>
     9c6:      	leaq	0x20(%rsp), %rsi
     9cb:      	movl	$0x1, %eax
     9d0:      	callq	*%rax
     9d2:      	testq	%rax, %rax
     9d5:      	je	0xb32 <generic_tracepoint_event+0xb32>
     9db:      	incl	(%rax)
     9dd:      	movzwl	0x8(%rsp), %r12d
     9e3:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     9e8:      	leaq	0x8(%rsp), %rdi
     9ed:      	movl	$0x4, %ecx
     9f2:      	movl	$0x4, %eax
     9f7:      	movl	$0x4, %esi
     9fc:      	callq	*%rax
     9fe:      	testq	%rax, %rax
     a01:      	je	0xb82 <generic_tracepoint_event+0xb82>
     a07:      	negl	%eax
     a09:      	movw	%ax, 0x20(%rsp)
     a0e:      	movw	$0x7, 0x22(%rsp)
     a15:      	movabsq	$0x400000088, %rax      # imm = 0x400000088
     a1f:      	movq	%rax, 0x24(%rsp)
     a24:      	movq	(%rip), %rdi            # 0xa2b <generic_tracepoint_event+0xa2b>
     a2b:      	leaq	0x20(%rsp), %rsi
     a30:      	movl	$0x1, %eax
     a35:      	callq	*%rax
     a37:      	testq	%rax, %rax
     a3a:      	je	0xb5e <generic_tracepoint_event+0xb5e>
     a40:      	incl	(%rax)
     a42:      	movl	0x8(%rsp), %r12d
     a47:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     a4c:      	movl	$0x1, 0x10(%rsp)
     a54:      	movq	(%rip), %rdi            # 0xa5b <generic_tracepoint_event+0xa5b>
     a5b:      	xorl	%ecx, %ecx
     a5d:      	leaq	0x20(%rsp), %rsi
     a62:      	leaq	0x10(%rsp), %rdx
     a67:      	movl	$0x2, %eax
     a6c:      	xorl	%ecx, %ecx
     a6e:      	callq	*%rax
     a70:      	movslq	0x8(%rsp), %r12
     a75:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     a7a:      	movl	$0x1, 0x10(%rsp)
     a82:      	movq	(%rip), %rdi            # 0xa89 <generic_tracepoint_event+0xa89>
     a89:      	xorl	%ecx, %ecx
     a8b:      	leaq	0x20(%rsp), %rsi
     a90:      	leaq	0x10(%rsp), %rdx
     a95:      	movl	$0x2, %eax
     a9a:      	xorl	%ecx, %ecx
     a9c:      	callq	*%rax
     a9e:      	movswq	0x8(%rsp), %r12
     aa4:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     aa9:      	movl	$0x1, 0x10(%rsp)
     ab1:      	movq	(%rip), %rdi            # 0xab8 <generic_tracepoint_event+0xab8>
     ab8:      	xorl	%ecx, %ecx
     aba:      	leaq	0x20(%rsp), %rsi
     abf:      	leaq	0x10(%rsp), %rdx
     ac4:      	movl	$0x2, %eax
     ac9:      	xorl	%ecx, %ecx
     acb:      	callq	*%rax
     acd:      	movsbq	0x8(%rsp), %r12
     ad3:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     ad8:      	movl	$0x1, 0x10(%rsp)
     ae0:      	movq	(%rip), %rdi            # 0xae7 <generic_tracepoint_event+0xae7>
     ae7:      	xorl	%ecx, %ecx
     ae9:      	leaq	0x20(%rsp), %rsi
     aee:      	leaq	0x10(%rsp), %rdx
     af3:      	movl	$0x2, %eax
     af8:      	xorl	%ecx, %ecx
     afa:      	callq	*%rax
     afc:      	movzbl	0x8(%rsp), %r12d
     b02:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     b07:      	movl	$0x1, 0x8(%rsp)
     b0f:      	movq	(%rip), %rdi            # 0xb16 <generic_tracepoint_event+0xb16>
     b16:      	xorl	%ecx, %ecx
     b18:      	leaq	0x20(%rsp), %rsi
     b1d:      	leaq	0x8(%rsp), %rdx
     b22:      	movl	$0x2, %eax
     b27:      	xorl	%ecx, %ecx
     b29:      	callq	*%rax
     b2b:      	movq	0x10(%rsp), %r12
     b30:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     b32:      	movl	$0x1, 0x10(%rsp)
     b3a:      	movq	(%rip), %rdi            # 0xb41 <generic_tracepoint_event+0xb41>
     b41:      	xorl	%ecx, %ecx
     b43:      	leaq	0x20(%rsp), %rsi
     b48:      	leaq	0x10(%rsp), %rdx
     b4d:      	movl	$0x2, %eax
     b52:      	xorl	%ecx, %ecx
     b54:      	callq	*%rax
     b56:      	movzwl	0x8(%rsp), %r12d
     b5c:      	jmp	0xb87 <generic_tracepoint_event+0xb87>
     b5e:      	movl	$0x1, 0x10(%rsp)
     b66:      	movq	(%rip), %rdi            # 0xb6d <generic_tracepoint_event+0xb6d>
     b6d:      	xorl	%ecx, %ecx
     b6f:      	leaq	0x20(%rsp), %rsi
     b74:      	leaq	0x10(%rsp), %rdx
     b79:      	movl	$0x2, %eax
     b7e:      	xorl	%ecx, %ecx
     b80:      	callq	*%rax
     b82:      	movl	0x8(%rsp), %r12d
     b87:      	movq	%r12, 0x5e50(%r14)
     b8e:      	movzwl	0x30(%r15), %edx
     b93:      	movl	0x8(%r15), %r13d
     b97:      	addq	%rbx, %rdx
     b9a:      	xorl	%r12d, %r12d
     b9d:      	cmpl	$0xb, %r13d
     ba1:      	jg	0xbda <generic_tracepoint_event+0xbda>
     ba3:      	cmpl	$0x3, %r13d
     ba7:      	jle	0xc71 <generic_tracepoint_event+0xc71>
     bad:      	cmpl	$0x6, %r13d
     bb1:      	jg	0xd98 <generic_tracepoint_event+0xd98>
     bb7:      	cmpl	$0x4, %r13d
     bbb:      	je	0x11f9 <generic_tracepoint_event+0x11f9>
     bc1:      	cmpl	$0x5, %r13d
     bc5:      	je	0x109e <generic_tracepoint_event+0x109e>
     bcb:      	cmpl	$0x6, %r13d
     bcf:      	je	0xc92 <generic_tracepoint_event+0xc92>
     bd5:      	jmp	0x145c <generic_tracepoint_event+0x145c>
     bda:      	cmpl	$0x1d, %r13d
     bde:      	jle	0xd0f <generic_tracepoint_event+0xd0f>
     be4:      	cmpl	$0x25, %r13d
     be8:      	jg	0xe04 <generic_tracepoint_event+0xe04>
     bee:      	cmpl	$0x1e, %r13d
     bf2:      	je	0x1258 <generic_tracepoint_event+0x1258>
     bf8:      	cmpl	$0x1f, %r13d
     bfc:      	je	0x111b <generic_tracepoint_event+0x111b>
     c02:      	cmpl	$0x20, %r13d
     c06:      	jne	0x145c <generic_tracepoint_event+0x145c>
     c0c:      	leaq	0x8(%rsp), %rdi
     c11:      	movl	$0x1, %ecx
     c16:      	movl	$0x4, %eax
     c1b:      	movl	$0x1, %esi
     c20:      	callq	*%rax
     c22:      	testq	%rax, %rax
     c25:      	je	0x13d1 <generic_tracepoint_event+0x13d1>
     c2b:      	negl	%eax
     c2d:      	movw	%ax, 0x20(%rsp)
     c32:      	movw	$0x7, 0x22(%rsp)
     c39:      	movabsq	$0x400000073, %rax      # imm = 0x400000073
     c43:      	movq	%rax, 0x24(%rsp)
     c48:      	movq	(%rip), %rdi            # 0xc4f <generic_tracepoint_event+0xc4f>
     c4f:      	leaq	0x20(%rsp), %rsi
     c54:      	movl	$0x1, %eax
     c59:      	callq	*%rax
     c5b:      	testq	%rax, %rax
     c5e:      	je	0x13ad <generic_tracepoint_event+0x13ad>
     c64:      	incl	(%rax)
     c66:      	movzbl	0x8(%rsp), %r12d
     c6c:      	jmp	0x145c <generic_tracepoint_event+0x145c>
     c71:      	cmpl	$-0xc, %r13d
     c75:      	jle	0xe9f <generic_tracepoint_event+0xe9f>
     c7b:      	leal	0xb(%r13), %eax
     c7f:      	cmpl	$0x2, %eax
     c82:      	jb	0xda5 <generic_tracepoint_event+0xda5>
     c88:      	cmpl	$0x2, %r13d
     c8c:      	jne	0x145c <generic_tracepoint_event+0x145c>
     c92:      	leaq	0x10(%rsp), %rdi
     c97:      	movl	$0x8, %ecx
     c9c:      	movl	$0x4, %eax
     ca1:      	movl	$0x8, %esi
     ca6:      	callq	*%rax
     ca8:      	testq	%rax, %rax
     cab:      	je	0x1400 <generic_tracepoint_event+0x1400>
     cb1:      	negl	%eax
     cb3:      	movw	%ax, 0x20(%rsp)
     cb8:      	movw	$0x7, 0x22(%rsp)
     cbf:      	movabsq	$0x400000081, %rax      # imm = 0x400000081
     cc9:      	movq	%rax, 0x24(%rsp)
     cce:      	movq	(%rip), %rdi            # 0xcd5 <generic_tracepoint_event+0xcd5>
     cd5:      	leaq	0x20(%rsp), %rsi
     cda:      	movl	$0x1, %eax
     cdf:      	callq	*%rax
     ce1:      	testq	%rax, %rax
     ce4:      	jne	0x1251 <generic_tracepoint_event+0x1251>
     cea:      	movl	$0x1, 0x8(%rsp)
     cf2:      	movq	(%rip), %rdi            # 0xcf9 <generic_tracepoint_event+0xcf9>
     cf9:      	xorl	%ecx, %ecx
     cfb:      	leaq	0x20(%rsp), %rsi
     d00:      	leaq	0x8(%rsp), %rdx
     d05:      	movl	$0x2, %eax
     d0a:      	jmp	0x13fc <generic_tracepoint_event+0x13fc>
     d0f:      	cmpl	$0x11, %r13d
     d13:      	jle	0xeb4 <generic_tracepoint_event+0xeb4>
     d19:      	cmpl	$0x12, %r13d
     d1d:      	je	0x1096 <generic_tracepoint_event+0x1096>
     d23:      	cmpl	$0x1c, %r13d
     d27:      	je	0xda5 <generic_tracepoint_event+0xda5>
     d29:      	cmpl	$0x1d, %r13d
     d2d:      	jne	0x145c <generic_tracepoint_event+0x145c>
     d33:      	leaq	0x8(%rsp), %rdi
     d38:      	movl	$0x2, %ecx
     d3d:      	movl	$0x4, %eax
     d42:      	movl	$0x2, %esi
     d47:      	callq	*%rax
     d49:      	testq	%rax, %rax
     d4c:      	je	0x1373 <generic_tracepoint_event+0x1373>
     d52:      	negl	%eax
     d54:      	movw	%ax, 0x20(%rsp)
     d59:      	movw	$0x7, 0x22(%rsp)
     d60:      	movabsq	$0x40000006c, %rax      # imm = 0x40000006C
     d6a:      	movq	%rax, 0x24(%rsp)
     d6f:      	movq	(%rip), %rdi            # 0xd76 <generic_tracepoint_event+0xd76>
     d76:      	leaq	0x20(%rsp), %rsi
     d7b:      	movl	$0x1, %eax
     d80:      	callq	*%rax
     d82:      	testq	%rax, %rax
     d85:      	je	0x134f <generic_tracepoint_event+0x134f>
     d8b:      	incl	(%rax)
     d8d:      	movswq	0x8(%rsp), %r12
     d93:      	jmp	0x145c <generic_tracepoint_event+0x145c>
     d98:      	leal	-0xa(%r13), %eax
     d9c:      	cmpl	$0x2, %eax
     d9f:      	jae	0x100f <generic_tracepoint_event+0x100f>
     da5:      	leaq	0x10(%rsp), %rdi
     daa:      	movl	$0x8, %ecx
     daf:      	movl	$0x4, %eax
     db4:      	movl	$0x8, %esi
     db9:      	callq	*%rax
     dbb:      	testq	%rax, %rax
     dbe:      	je	0xfcd <generic_tracepoint_event+0xfcd>
     dc4:      	negl	%eax
     dc6:      	movw	%ax, 0x20(%rsp)
     dcb:      	movw	$0x7, 0x22(%rsp)
     dd2:      	movabsq	$0x400000045, %rax      # imm = 0x400000045
     ddc:      	movq	%rax, 0x24(%rsp)
     de1:      	movq	(%rip), %rdi            # 0xde8 <generic_tracepoint_event+0xde8>
     de8:      	leaq	0x20(%rsp), %rsi
     ded:      	movl	$0x1, %eax
     df2:      	callq	*%rax
     df4:      	testq	%rax, %rax
     df7:      	je	0xfa9 <generic_tracepoint_event+0xfa9>
     dfd:      	incl	(%rax)
     dff:      	jmp	0xfcd <generic_tracepoint_event+0xfcd>
     e04:      	cmpl	$0x26, %r13d
     e08:      	je	0x12bd <generic_tracepoint_event+0x12bd>
     e0e:      	cmpl	$0x28, %r13d
     e12:      	je	0x1180 <generic_tracepoint_event+0x1180>
     e18:      	cmpl	$0x29, %r13d
     e1c:      	jne	0x145c <generic_tracepoint_event+0x145c>
     e22:      	leaq	0x10(%rsp), %rdi
     e27:      	movl	$0x8, %ecx
     e2c:      	movl	$0x4, %eax
     e31:      	movl	$0x8, %esi
     e36:      	callq	*%rax
     e38:      	testq	%rax, %rax
     e3b:      	je	0x1400 <generic_tracepoint_event+0x1400>
     e41:      	negl	%eax
     e43:      	movw	%ax, 0x20(%rsp)
     e48:      	movw	$0x7, 0x22(%rsp)
     e4f:      	movabsq	$0x4000000a8, %rax      # imm = 0x4000000A8
     e59:      	movq	%rax, 0x24(%rsp)
     e5e:      	movq	(%rip), %rdi            # 0xe65 <generic_tracepoint_event+0xe65>
     e65:      	leaq	0x20(%rsp), %rsi
     e6a:      	movl	$0x1, %eax
     e6f:      	callq	*%rax
     e71:      	testq	%rax, %rax
     e74:      	jne	0x1251 <generic_tracepoint_event+0x1251>
     e7a:      	movl	$0x1, 0x8(%rsp)
     e82:      	movq	(%rip), %rdi            # 0xe89 <generic_tracepoint_event+0xe89>
     e89:      	xorl	%ecx, %ecx
     e8b:      	leaq	0x20(%rsp), %rsi
     e90:      	leaq	0x8(%rsp), %rdx
     e95:      	movl	$0x2, %eax
     e9a:      	jmp	0x13fc <generic_tracepoint_event+0x13fc>
     e9f:      	cmpl	$-0xd, %r13d
     ea3:      	je	0xf45 <generic_tracepoint_event+0xf45>
     ea9:      	cmpl	$-0xc, %r13d
     ead:      	je	0xec8 <generic_tracepoint_event+0xec8>
     eaf:      	jmp	0x145c <generic_tracepoint_event+0x145c>
     eb4:      	cmpl	$0xc, %r13d
     eb8:      	je	0xf45 <generic_tracepoint_event+0xf45>
     ebe:      	cmpl	$0xd, %r13d
     ec2:      	jne	0x145c <generic_tracepoint_event+0x145c>
     ec8:      	leaq	0x8(%rsp), %rdi
     ecd:      	movl	$0x4, %ecx
     ed2:      	movl	$0x4, %eax
     ed7:      	movl	$0x4, %esi
     edc:      	callq	*%rax
     ede:      	testq	%rax, %rax
     ee1:      	je	0x1457 <generic_tracepoint_event+0x1457>
     ee7:      	negl	%eax
     ee9:      	movw	%ax, 0x20(%rsp)
     eee:      	movw	$0x7, 0x22(%rsp)
     ef5:      	movabsq	$0x40000005e, %rax      # imm = 0x40000005E
     eff:      	movq	%rax, 0x24(%rsp)
     f04:      	movq	(%rip), %rdi            # 0xf0b <generic_tracepoint_event+0xf0b>
     f0b:      	leaq	0x20(%rsp), %rsi
     f10:      	movl	$0x1, %eax
     f15:      	callq	*%rax
     f17:      	testq	%rax, %rax
     f1a:      	jne	0x1315 <generic_tracepoint_event+0x1315>
     f20:      	movl	$0x1, 0x10(%rsp)
     f28:      	movq	(%rip), %rdi            # 0xf2f <generic_tracepoint_event+0xf2f>
     f2f:      	xorl	%ecx, %ecx
     f31:      	leaq	0x20(%rsp), %rsi
     f36:      	leaq	0x10(%rsp), %rdx
     f3b:      	movl	$0x2, %eax
     f40:      	jmp	0x1453 <generic_tracepoint_event+0x1453>
     f45:      	leaq	0x8(%rsp), %rdi
     f4a:      	movl	$0x4, %ecx
     f4f:      	movl	$0x4, %eax
     f54:      	movl	$0x4, %esi
     f59:      	callq	*%rax
     f5b:      	testq	%rax, %rax
     f5e:      	je	0x1345 <generic_tracepoint_event+0x1345>
     f64:      	negl	%eax
     f66:      	movw	%ax, 0x20(%rsp)
     f6b:      	movw	$0x7, 0x22(%rsp)
     f72:      	movabsq	$0x400000056, %rax      # imm = 0x400000056
     f7c:      	movq	%rax, 0x24(%rsp)
     f81:      	movq	(%rip), %rdi            # 0xf88 <generic_tracepoint_event+0xf88>
     f88:      	leaq	0x20(%rsp), %rsi
     f8d:      	movl	$0x1, %eax
     f92:      	callq	*%rax
     f94:      	testq	%rax, %rax
     f97:      	je	0x1321 <generic_tracepoint_event+0x1321>
     f9d:      	incl	(%rax)
     f9f:      	movslq	0x8(%rsp), %r12
     fa4:      	jmp	0x145c <generic_tracepoint_event+0x145c>
     fa9:      	movl	$0x1, 0x8(%rsp)
     fb1:      	movq	(%rip), %rdi            # 0xfb8 <generic_tracepoint_event+0xfb8>
     fb8:      	xorl	%ecx, %ecx
     fba:      	leaq	0x20(%rsp), %rsi
     fbf:      	leaq	0x8(%rsp), %rdx
     fc4:      	movl	$0x2, %eax
     fc9:      	xorl	%ecx, %ecx
     fcb:      	callq	*%rax
     fcd:      	movq	0x10(%rsp), %r12
     fd2:      	cmpl	$0x1c, %r13d
     fd6:      	jne	0x145c <generic_tracepoint_event+0x145c>
     fdc:      	movl	$0x23, %eax
     fe1:      	callq	*%rax
     fe3:      	leaq	0x10(%rax), %rdx
     fe7:      	leaq	0x20(%rsp), %rdi
     fec:      	movl	$0x4, %ecx
     ff1:      	movl	$0x4, %eax
     ff6:      	movl	$0x4, %esi
     ffb:      	callq	*%rax
     ffd:      	movl	0x20(%rsp), %eax
    1001:      	andl	$-0x2, %eax
    1004:      	shll	$0x1e, %eax
    1007:      	orq	%rax, %r12
    100a:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    100f:      	cmpl	$0x7, %r13d
    1013:      	jne	0x145c <generic_tracepoint_event+0x145c>
    1019:      	leaq	0x10(%rsp), %rdi
    101e:      	movl	$0x8, %ecx
    1023:      	movl	$0x4, %eax
    1028:      	movl	$0x8, %esi
    102d:      	callq	*%rax
    102f:      	testq	%rax, %rax
    1032:      	je	0x1400 <generic_tracepoint_event+0x1400>
    1038:      	negl	%eax
    103a:      	movw	%ax, 0x20(%rsp)
    103f:      	movw	$0x7, 0x22(%rsp)
    1046:      	movabsq	$0x40000009a, %rax      # imm = 0x40000009A
    1050:      	movq	%rax, 0x24(%rsp)
    1055:      	movq	(%rip), %rdi            # 0x105c <generic_tracepoint_event+0x105c>
    105c:      	leaq	0x20(%rsp), %rsi
    1061:      	movl	$0x1, %eax
    1066:      	callq	*%rax
    1068:      	testq	%rax, %rax
    106b:      	jne	0x1251 <generic_tracepoint_event+0x1251>
    1071:      	movl	$0x1, 0x8(%rsp)
    1079:      	movq	(%rip), %rdi            # 0x1080 <generic_tracepoint_event+0x1080>
    1080:      	xorl	%ecx, %ecx
    1082:      	leaq	0x20(%rsp), %rsi
    1087:      	leaq	0x8(%rsp), %rdx
    108c:      	movl	$0x2, %eax
    1091:      	jmp	0x13fc <generic_tracepoint_event+0x13fc>
    1096:      	movq	%rdx, %r12
    1099:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    109e:      	leaq	0x10(%rsp), %rdi
    10a3:      	movl	$0x8, %ecx
    10a8:      	movl	$0x4, %eax
    10ad:      	movl	$0x8, %esi
    10b2:      	callq	*%rax
    10b4:      	testq	%rax, %rax
    10b7:      	je	0x1400 <generic_tracepoint_event+0x1400>
    10bd:      	negl	%eax
    10bf:      	movw	%ax, 0x20(%rsp)
    10c4:      	movw	$0x7, 0x22(%rsp)
    10cb:      	movabsq	$0x400000093, %rax      # imm = 0x400000093
    10d5:      	movq	%rax, 0x24(%rsp)
    10da:      	movq	(%rip), %rdi            # 0x10e1 <generic_tracepoint_event+0x10e1>
    10e1:      	leaq	0x20(%rsp), %rsi
    10e6:      	movl	$0x1, %eax
    10eb:      	callq	*%rax
    10ed:      	testq	%rax, %rax
    10f0:      	jne	0x1251 <generic_tracepoint_event+0x1251>
    10f6:      	movl	$0x1, 0x8(%rsp)
    10fe:      	movq	(%rip), %rdi            # 0x1105 <generic_tracepoint_event+0x1105>
    1105:      	xorl	%ecx, %ecx
    1107:      	leaq	0x20(%rsp), %rsi
    110c:      	leaq	0x8(%rsp), %rdx
    1111:      	movl	$0x2, %eax
    1116:      	jmp	0x13fc <generic_tracepoint_event+0x13fc>
    111b:      	leaq	0x8(%rsp), %rdi
    1120:      	movl	$0x1, %ecx
    1125:      	movl	$0x4, %eax
    112a:      	movl	$0x1, %esi
    112f:      	callq	*%rax
    1131:      	testq	%rax, %rax
    1134:      	je	0x13a2 <generic_tracepoint_event+0x13a2>
    113a:      	negl	%eax
    113c:      	movw	%ax, 0x20(%rsp)
    1141:      	movw	$0x7, 0x22(%rsp)
    1148:      	movabsq	$0x40000007a, %rax      # imm = 0x40000007A
    1152:      	movq	%rax, 0x24(%rsp)
    1157:      	movq	(%rip), %rdi            # 0x115e <generic_tracepoint_event+0x115e>
    115e:      	leaq	0x20(%rsp), %rsi
    1163:      	movl	$0x1, %eax
    1168:      	callq	*%rax
    116a:      	testq	%rax, %rax
    116d:      	je	0x137e <generic_tracepoint_event+0x137e>
    1173:      	incl	(%rax)
    1175:      	movsbq	0x8(%rsp), %r12
    117b:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    1180:      	leaq	0x10(%rsp), %rdi
    1185:      	movl	$0x8, %ecx
    118a:      	movl	$0x4, %eax
    118f:      	movl	$0x8, %esi
    1194:      	callq	*%rax
    1196:      	testq	%rax, %rax
    1199:      	je	0x1400 <generic_tracepoint_event+0x1400>
    119f:      	negl	%eax
    11a1:      	movw	%ax, 0x20(%rsp)
    11a6:      	movw	$0x7, 0x22(%rsp)
    11ad:      	movabsq	$0x4000000a1, %rax      # imm = 0x4000000A1
    11b7:      	movq	%rax, 0x24(%rsp)
    11bc:      	movq	(%rip), %rdi            # 0x11c3 <generic_tracepoint_event+0x11c3>
    11c3:      	leaq	0x20(%rsp), %rsi
    11c8:      	movl	$0x1, %eax
    11cd:      	callq	*%rax
    11cf:      	testq	%rax, %rax
    11d2:      	jne	0x1251 <generic_tracepoint_event+0x1251>
    11d4:      	movl	$0x1, 0x8(%rsp)
    11dc:      	movq	(%rip), %rdi            # 0x11e3 <generic_tracepoint_event+0x11e3>
    11e3:      	xorl	%ecx, %ecx
    11e5:      	leaq	0x20(%rsp), %rsi
    11ea:      	leaq	0x8(%rsp), %rdx
    11ef:      	movl	$0x2, %eax
    11f4:      	jmp	0x13fc <generic_tracepoint_event+0x13fc>
    11f9:      	leaq	0x10(%rsp), %rdi
    11fe:      	movl	$0x8, %ecx
    1203:      	movl	$0x4, %eax
    1208:      	movl	$0x8, %esi
    120d:      	callq	*%rax
    120f:      	testq	%rax, %rax
    1212:      	je	0x1400 <generic_tracepoint_event+0x1400>
    1218:      	negl	%eax
    121a:      	movw	%ax, 0x20(%rsp)
    121f:      	movw	$0x7, 0x22(%rsp)
    1226:      	movabsq	$0x40000004e, %rax      # imm = 0x40000004E
    1230:      	movq	%rax, 0x24(%rsp)
    1235:      	movq	(%rip), %rdi            # 0x123c <generic_tracepoint_event+0x123c>
    123c:      	leaq	0x20(%rsp), %rsi
    1241:      	movl	$0x1, %eax
    1246:      	callq	*%rax
    1248:      	testq	%rax, %rax
    124b:      	je	0x13dc <generic_tracepoint_event+0x13dc>
    1251:      	incl	(%rax)
    1253:      	jmp	0x1400 <generic_tracepoint_event+0x1400>
    1258:      	leaq	0x8(%rsp), %rdi
    125d:      	movl	$0x2, %ecx
    1262:      	movl	$0x4, %eax
    1267:      	movl	$0x2, %esi
    126c:      	callq	*%rax
    126e:      	testq	%rax, %rax
    1271:      	je	0x142b <generic_tracepoint_event+0x142b>
    1277:      	negl	%eax
    1279:      	movw	%ax, 0x20(%rsp)
    127e:      	movw	$0x7, 0x22(%rsp)
    1285:      	movabsq	$0x400000065, %rax      # imm = 0x400000065
    128f:      	movq	%rax, 0x24(%rsp)
    1294:      	movq	(%rip), %rdi            # 0x129b <generic_tracepoint_event+0x129b>
    129b:      	leaq	0x20(%rsp), %rsi
    12a0:      	movl	$0x1, %eax
    12a5:      	callq	*%rax
    12a7:      	testq	%rax, %rax
    12aa:      	je	0x1407 <generic_tracepoint_event+0x1407>
    12b0:      	incl	(%rax)
    12b2:      	movzwl	0x8(%rsp), %r12d
    12b8:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    12bd:      	leaq	0x8(%rsp), %rdi
    12c2:      	movl	$0x4, %ecx
    12c7:      	movl	$0x4, %eax
    12cc:      	movl	$0x4, %esi
    12d1:      	callq	*%rax
    12d3:      	testq	%rax, %rax
    12d6:      	je	0x1457 <generic_tracepoint_event+0x1457>
    12dc:      	negl	%eax
    12de:      	movw	%ax, 0x20(%rsp)
    12e3:      	movw	$0x7, 0x22(%rsp)
    12ea:      	movabsq	$0x400000088, %rax      # imm = 0x400000088
    12f4:      	movq	%rax, 0x24(%rsp)
    12f9:      	movq	(%rip), %rdi            # 0x1300 <generic_tracepoint_event+0x1300>
    1300:      	leaq	0x20(%rsp), %rsi
    1305:      	movl	$0x1, %eax
    130a:      	callq	*%rax
    130c:      	testq	%rax, %rax
    130f:      	je	0x1433 <generic_tracepoint_event+0x1433>
    1315:      	incl	(%rax)
    1317:      	movl	0x8(%rsp), %r12d
    131c:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    1321:      	movl	$0x1, 0x10(%rsp)
    1329:      	movq	(%rip), %rdi            # 0x1330 <generic_tracepoint_event+0x1330>
    1330:      	xorl	%ecx, %ecx
    1332:      	leaq	0x20(%rsp), %rsi
    1337:      	leaq	0x10(%rsp), %rdx
    133c:      	movl	$0x2, %eax
    1341:      	xorl	%ecx, %ecx
    1343:      	callq	*%rax
    1345:      	movslq	0x8(%rsp), %r12
    134a:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    134f:      	movl	$0x1, 0x10(%rsp)
    1357:      	movq	(%rip), %rdi            # 0x135e <generic_tracepoint_event+0x135e>
    135e:      	xorl	%ecx, %ecx
    1360:      	leaq	0x20(%rsp), %rsi
    1365:      	leaq	0x10(%rsp), %rdx
    136a:      	movl	$0x2, %eax
    136f:      	xorl	%ecx, %ecx
    1371:      	callq	*%rax
    1373:      	movswq	0x8(%rsp), %r12
    1379:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    137e:      	movl	$0x1, 0x10(%rsp)
    1386:      	movq	(%rip), %rdi            # 0x138d <generic_tracepoint_event+0x138d>
    138d:      	xorl	%ecx, %ecx
    138f:      	leaq	0x20(%rsp), %rsi
    1394:      	leaq	0x10(%rsp), %rdx
    1399:      	movl	$0x2, %eax
    139e:      	xorl	%ecx, %ecx
    13a0:      	callq	*%rax
    13a2:      	movsbq	0x8(%rsp), %r12
    13a8:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    13ad:      	movl	$0x1, 0x10(%rsp)
    13b5:      	movq	(%rip), %rdi            # 0x13bc <generic_tracepoint_event+0x13bc>
    13bc:      	xorl	%ecx, %ecx
    13be:      	leaq	0x20(%rsp), %rsi
    13c3:      	leaq	0x10(%rsp), %rdx
    13c8:      	movl	$0x2, %eax
    13cd:      	xorl	%ecx, %ecx
    13cf:      	callq	*%rax
    13d1:      	movzbl	0x8(%rsp), %r12d
    13d7:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    13dc:      	movl	$0x1, 0x8(%rsp)
    13e4:      	movq	(%rip), %rdi            # 0x13eb <generic_tracepoint_event+0x13eb>
    13eb:      	xorl	%ecx, %ecx
    13ed:      	leaq	0x20(%rsp), %rsi
    13f2:      	leaq	0x8(%rsp), %rdx
    13f7:      	movl	$0x2, %eax
    13fc:      	xorl	%ecx, %ecx
    13fe:      	callq	*%rax
    1400:      	movq	0x10(%rsp), %r12
    1405:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    1407:      	movl	$0x1, 0x10(%rsp)
    140f:      	movq	(%rip), %rdi            # 0x1416 <generic_tracepoint_event+0x1416>
    1416:      	xorl	%ecx, %ecx
    1418:      	leaq	0x20(%rsp), %rsi
    141d:      	leaq	0x10(%rsp), %rdx
    1422:      	movl	$0x2, %eax
    1427:      	xorl	%ecx, %ecx
    1429:      	callq	*%rax
    142b:      	movzwl	0x8(%rsp), %r12d
    1431:      	jmp	0x145c <generic_tracepoint_event+0x145c>
    1433:      	movl	$0x1, 0x10(%rsp)
    143b:      	movq	(%rip), %rdi            # 0x1442 <generic_tracepoint_event+0x1442>
    1442:      	xorl	%ecx, %ecx
    1444:      	leaq	0x20(%rsp), %rsi
    1449:      	leaq	0x10(%rsp), %rdx
    144e:      	movl	$0x2, %eax
    1453:      	xorl	%ecx, %ecx
    1455:      	callq	*%rax
    1457:      	movl	0x8(%rsp), %r12d
    145c:      	movq	%r12, 0x5e58(%r14)
    1463:      	movzwl	0x34(%r15), %edx
    1468:      	movl	0xc(%r15), %r13d
    146c:      	addq	%rbx, %rdx
    146f:      	xorl	%r12d, %r12d
    1472:      	cmpl	$0xb, %r13d
    1476:      	jg	0x14af <generic_tracepoint_event+0x14af>
    1478:      	cmpl	$0x3, %r13d
    147c:      	jle	0x1546 <generic_tracepoint_event+0x1546>
    1482:      	cmpl	$0x6, %r13d
    1486:      	jg	0x166d <generic_tracepoint_event+0x166d>
    148c:      	cmpl	$0x4, %r13d
    1490:      	je	0x1ace <generic_tracepoint_event+0x1ace>
    1496:      	cmpl	$0x5, %r13d
    149a:      	je	0x1973 <generic_tracepoint_event+0x1973>
    14a0:      	cmpl	$0x6, %r13d
    14a4:      	je	0x1567 <generic_tracepoint_event+0x1567>
    14aa:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    14af:      	cmpl	$0x1d, %r13d
    14b3:      	jle	0x15e4 <generic_tracepoint_event+0x15e4>
    14b9:      	cmpl	$0x25, %r13d
    14bd:      	jg	0x16d9 <generic_tracepoint_event+0x16d9>
    14c3:      	cmpl	$0x1e, %r13d
    14c7:      	je	0x1b2d <generic_tracepoint_event+0x1b2d>
    14cd:      	cmpl	$0x1f, %r13d
    14d1:      	je	0x19f0 <generic_tracepoint_event+0x19f0>
    14d7:      	cmpl	$0x20, %r13d
    14db:      	jne	0x1d31 <generic_tracepoint_event+0x1d31>
    14e1:      	leaq	0x8(%rsp), %rdi
    14e6:      	movl	$0x1, %ecx
    14eb:      	movl	$0x4, %eax
    14f0:      	movl	$0x1, %esi
    14f5:      	callq	*%rax
    14f7:      	testq	%rax, %rax
    14fa:      	je	0x1ca6 <generic_tracepoint_event+0x1ca6>
    1500:      	negl	%eax
    1502:      	movw	%ax, 0x20(%rsp)
    1507:      	movw	$0x7, 0x22(%rsp)
    150e:      	movabsq	$0x400000073, %rax      # imm = 0x400000073
    1518:      	movq	%rax, 0x24(%rsp)
    151d:      	movq	(%rip), %rdi            # 0x1524 <generic_tracepoint_event+0x1524>
    1524:      	leaq	0x20(%rsp), %rsi
    1529:      	movl	$0x1, %eax
    152e:      	callq	*%rax
    1530:      	testq	%rax, %rax
    1533:      	je	0x1c82 <generic_tracepoint_event+0x1c82>
    1539:      	incl	(%rax)
    153b:      	movzbl	0x8(%rsp), %r12d
    1541:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1546:      	cmpl	$-0xc, %r13d
    154a:      	jle	0x1774 <generic_tracepoint_event+0x1774>
    1550:      	leal	0xb(%r13), %eax
    1554:      	cmpl	$0x2, %eax
    1557:      	jb	0x167a <generic_tracepoint_event+0x167a>
    155d:      	cmpl	$0x2, %r13d
    1561:      	jne	0x1d31 <generic_tracepoint_event+0x1d31>
    1567:      	leaq	0x10(%rsp), %rdi
    156c:      	movl	$0x8, %ecx
    1571:      	movl	$0x4, %eax
    1576:      	movl	$0x8, %esi
    157b:      	callq	*%rax
    157d:      	testq	%rax, %rax
    1580:      	je	0x1cd5 <generic_tracepoint_event+0x1cd5>
    1586:      	negl	%eax
    1588:      	movw	%ax, 0x20(%rsp)
    158d:      	movw	$0x7, 0x22(%rsp)
    1594:      	movabsq	$0x400000081, %rax      # imm = 0x400000081
    159e:      	movq	%rax, 0x24(%rsp)
    15a3:      	movq	(%rip), %rdi            # 0x15aa <generic_tracepoint_event+0x15aa>
    15aa:      	leaq	0x20(%rsp), %rsi
    15af:      	movl	$0x1, %eax
    15b4:      	callq	*%rax
    15b6:      	testq	%rax, %rax
    15b9:      	jne	0x1b26 <generic_tracepoint_event+0x1b26>
    15bf:      	movl	$0x1, 0x8(%rsp)
    15c7:      	movq	(%rip), %rdi            # 0x15ce <generic_tracepoint_event+0x15ce>
    15ce:      	xorl	%ecx, %ecx
    15d0:      	leaq	0x20(%rsp), %rsi
    15d5:      	leaq	0x8(%rsp), %rdx
    15da:      	movl	$0x2, %eax
    15df:      	jmp	0x1cd1 <generic_tracepoint_event+0x1cd1>
    15e4:      	cmpl	$0x11, %r13d
    15e8:      	jle	0x1789 <generic_tracepoint_event+0x1789>
    15ee:      	cmpl	$0x12, %r13d
    15f2:      	je	0x196b <generic_tracepoint_event+0x196b>
    15f8:      	cmpl	$0x1c, %r13d
    15fc:      	je	0x167a <generic_tracepoint_event+0x167a>
    15fe:      	cmpl	$0x1d, %r13d
    1602:      	jne	0x1d31 <generic_tracepoint_event+0x1d31>
    1608:      	leaq	0x8(%rsp), %rdi
    160d:      	movl	$0x2, %ecx
    1612:      	movl	$0x4, %eax
    1617:      	movl	$0x2, %esi
    161c:      	callq	*%rax
    161e:      	testq	%rax, %rax
    1621:      	je	0x1c48 <generic_tracepoint_event+0x1c48>
    1627:      	negl	%eax
    1629:      	movw	%ax, 0x20(%rsp)
    162e:      	movw	$0x7, 0x22(%rsp)
    1635:      	movabsq	$0x40000006c, %rax      # imm = 0x40000006C
    163f:      	movq	%rax, 0x24(%rsp)
    1644:      	movq	(%rip), %rdi            # 0x164b <generic_tracepoint_event+0x164b>
    164b:      	leaq	0x20(%rsp), %rsi
    1650:      	movl	$0x1, %eax
    1655:      	callq	*%rax
    1657:      	testq	%rax, %rax
    165a:      	je	0x1c24 <generic_tracepoint_event+0x1c24>
    1660:      	incl	(%rax)
    1662:      	movswq	0x8(%rsp), %r12
    1668:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    166d:      	leal	-0xa(%r13), %eax
    1671:      	cmpl	$0x2, %eax
    1674:      	jae	0x18e4 <generic_tracepoint_event+0x18e4>
    167a:      	leaq	0x10(%rsp), %rdi
    167f:      	movl	$0x8, %ecx
    1684:      	movl	$0x4, %eax
    1689:      	movl	$0x8, %esi
    168e:      	callq	*%rax
    1690:      	testq	%rax, %rax
    1693:      	je	0x18a2 <generic_tracepoint_event+0x18a2>
    1699:      	negl	%eax
    169b:      	movw	%ax, 0x20(%rsp)
    16a0:      	movw	$0x7, 0x22(%rsp)
    16a7:      	movabsq	$0x400000045, %rax      # imm = 0x400000045
    16b1:      	movq	%rax, 0x24(%rsp)
    16b6:      	movq	(%rip), %rdi            # 0x16bd <generic_tracepoint_event+0x16bd>
    16bd:      	leaq	0x20(%rsp), %rsi
    16c2:      	movl	$0x1, %eax
    16c7:      	callq	*%rax
    16c9:      	testq	%rax, %rax
    16cc:      	je	0x187e <generic_tracepoint_event+0x187e>
    16d2:      	incl	(%rax)
    16d4:      	jmp	0x18a2 <generic_tracepoint_event+0x18a2>
    16d9:      	cmpl	$0x26, %r13d
    16dd:      	je	0x1b92 <generic_tracepoint_event+0x1b92>
    16e3:      	cmpl	$0x28, %r13d
    16e7:      	je	0x1a55 <generic_tracepoint_event+0x1a55>
    16ed:      	cmpl	$0x29, %r13d
    16f1:      	jne	0x1d31 <generic_tracepoint_event+0x1d31>
    16f7:      	leaq	0x10(%rsp), %rdi
    16fc:      	movl	$0x8, %ecx
    1701:      	movl	$0x4, %eax
    1706:      	movl	$0x8, %esi
    170b:      	callq	*%rax
    170d:      	testq	%rax, %rax
    1710:      	je	0x1cd5 <generic_tracepoint_event+0x1cd5>
    1716:      	negl	%eax
    1718:      	movw	%ax, 0x20(%rsp)
    171d:      	movw	$0x7, 0x22(%rsp)
    1724:      	movabsq	$0x4000000a8, %rax      # imm = 0x4000000A8
    172e:      	movq	%rax, 0x24(%rsp)
    1733:      	movq	(%rip), %rdi            # 0x173a <generic_tracepoint_event+0x173a>
    173a:      	leaq	0x20(%rsp), %rsi
    173f:      	movl	$0x1, %eax
    1744:      	callq	*%rax
    1746:      	testq	%rax, %rax
    1749:      	jne	0x1b26 <generic_tracepoint_event+0x1b26>
    174f:      	movl	$0x1, 0x8(%rsp)
    1757:      	movq	(%rip), %rdi            # 0x175e <generic_tracepoint_event+0x175e>
    175e:      	xorl	%ecx, %ecx
    1760:      	leaq	0x20(%rsp), %rsi
    1765:      	leaq	0x8(%rsp), %rdx
    176a:      	movl	$0x2, %eax
    176f:      	jmp	0x1cd1 <generic_tracepoint_event+0x1cd1>
    1774:      	cmpl	$-0xd, %r13d
    1778:      	je	0x181a <generic_tracepoint_event+0x181a>
    177e:      	cmpl	$-0xc, %r13d
    1782:      	je	0x179d <generic_tracepoint_event+0x179d>
    1784:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1789:      	cmpl	$0xc, %r13d
    178d:      	je	0x181a <generic_tracepoint_event+0x181a>
    1793:      	cmpl	$0xd, %r13d
    1797:      	jne	0x1d31 <generic_tracepoint_event+0x1d31>
    179d:      	leaq	0x8(%rsp), %rdi
    17a2:      	movl	$0x4, %ecx
    17a7:      	movl	$0x4, %eax
    17ac:      	movl	$0x4, %esi
    17b1:      	callq	*%rax
    17b3:      	testq	%rax, %rax
    17b6:      	je	0x1d2c <generic_tracepoint_event+0x1d2c>
    17bc:      	negl	%eax
    17be:      	movw	%ax, 0x20(%rsp)
    17c3:      	movw	$0x7, 0x22(%rsp)
    17ca:      	movabsq	$0x40000005e, %rax      # imm = 0x40000005E
    17d4:      	movq	%rax, 0x24(%rsp)
    17d9:      	movq	(%rip), %rdi            # 0x17e0 <generic_tracepoint_event+0x17e0>
    17e0:      	leaq	0x20(%rsp), %rsi
    17e5:      	movl	$0x1, %eax
    17ea:      	callq	*%rax
    17ec:      	testq	%rax, %rax
    17ef:      	jne	0x1bea <generic_tracepoint_event+0x1bea>
    17f5:      	movl	$0x1, 0x10(%rsp)
    17fd:      	movq	(%rip), %rdi            # 0x1804 <generic_tracepoint_event+0x1804>
    1804:      	xorl	%ecx, %ecx
    1806:      	leaq	0x20(%rsp), %rsi
    180b:      	leaq	0x10(%rsp), %rdx
    1810:      	movl	$0x2, %eax
    1815:      	jmp	0x1d28 <generic_tracepoint_event+0x1d28>
    181a:      	leaq	0x8(%rsp), %rdi
    181f:      	movl	$0x4, %ecx
    1824:      	movl	$0x4, %eax
    1829:      	movl	$0x4, %esi
    182e:      	callq	*%rax
    1830:      	testq	%rax, %rax
    1833:      	je	0x1c1a <generic_tracepoint_event+0x1c1a>
    1839:      	negl	%eax
    183b:      	movw	%ax, 0x20(%rsp)
    1840:      	movw	$0x7, 0x22(%rsp)
    1847:      	movabsq	$0x400000056, %rax      # imm = 0x400000056
    1851:      	movq	%rax, 0x24(%rsp)
    1856:      	movq	(%rip), %rdi            # 0x185d <generic_tracepoint_event+0x185d>
    185d:      	leaq	0x20(%rsp), %rsi
    1862:      	movl	$0x1, %eax
    1867:      	callq	*%rax
    1869:      	testq	%rax, %rax
    186c:      	je	0x1bf6 <generic_tracepoint_event+0x1bf6>
    1872:      	incl	(%rax)
    1874:      	movslq	0x8(%rsp), %r12
    1879:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    187e:      	movl	$0x1, 0x8(%rsp)
    1886:      	movq	(%rip), %rdi            # 0x188d <generic_tracepoint_event+0x188d>
    188d:      	xorl	%ecx, %ecx
    188f:      	leaq	0x20(%rsp), %rsi
    1894:      	leaq	0x8(%rsp), %rdx
    1899:      	movl	$0x2, %eax
    189e:      	xorl	%ecx, %ecx
    18a0:      	callq	*%rax
    18a2:      	movq	0x10(%rsp), %r12
    18a7:      	cmpl	$0x1c, %r13d
    18ab:      	jne	0x1d31 <generic_tracepoint_event+0x1d31>
    18b1:      	movl	$0x23, %eax
    18b6:      	callq	*%rax
    18b8:      	leaq	0x10(%rax), %rdx
    18bc:      	leaq	0x20(%rsp), %rdi
    18c1:      	movl	$0x4, %ecx
    18c6:      	movl	$0x4, %eax
    18cb:      	movl	$0x4, %esi
    18d0:      	callq	*%rax
    18d2:      	movl	0x20(%rsp), %eax
    18d6:      	andl	$-0x2, %eax
    18d9:      	shll	$0x1e, %eax
    18dc:      	orq	%rax, %r12
    18df:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    18e4:      	cmpl	$0x7, %r13d
    18e8:      	jne	0x1d31 <generic_tracepoint_event+0x1d31>
    18ee:      	leaq	0x10(%rsp), %rdi
    18f3:      	movl	$0x8, %ecx
    18f8:      	movl	$0x4, %eax
    18fd:      	movl	$0x8, %esi
    1902:      	callq	*%rax
    1904:      	testq	%rax, %rax
    1907:      	je	0x1cd5 <generic_tracepoint_event+0x1cd5>
    190d:      	negl	%eax
    190f:      	movw	%ax, 0x20(%rsp)
    1914:      	movw	$0x7, 0x22(%rsp)
    191b:      	movabsq	$0x40000009a, %rax      # imm = 0x40000009A
    1925:      	movq	%rax, 0x24(%rsp)
    192a:      	movq	(%rip), %rdi            # 0x1931 <generic_tracepoint_event+0x1931>
    1931:      	leaq	0x20(%rsp), %rsi
    1936:      	movl	$0x1, %eax
    193b:      	callq	*%rax
    193d:      	testq	%rax, %rax
    1940:      	jne	0x1b26 <generic_tracepoint_event+0x1b26>
    1946:      	movl	$0x1, 0x8(%rsp)
    194e:      	movq	(%rip), %rdi            # 0x1955 <generic_tracepoint_event+0x1955>
    1955:      	xorl	%ecx, %ecx
    1957:      	leaq	0x20(%rsp), %rsi
    195c:      	leaq	0x8(%rsp), %rdx
    1961:      	movl	$0x2, %eax
    1966:      	jmp	0x1cd1 <generic_tracepoint_event+0x1cd1>
    196b:      	movq	%rdx, %r12
    196e:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1973:      	leaq	0x10(%rsp), %rdi
    1978:      	movl	$0x8, %ecx
    197d:      	movl	$0x4, %eax
    1982:      	movl	$0x8, %esi
    1987:      	callq	*%rax
    1989:      	testq	%rax, %rax
    198c:      	je	0x1cd5 <generic_tracepoint_event+0x1cd5>
    1992:      	negl	%eax
    1994:      	movw	%ax, 0x20(%rsp)
    1999:      	movw	$0x7, 0x22(%rsp)
    19a0:      	movabsq	$0x400000093, %rax      # imm = 0x400000093
    19aa:      	movq	%rax, 0x24(%rsp)
    19af:      	movq	(%rip), %rdi            # 0x19b6 <generic_tracepoint_event+0x19b6>
    19b6:      	leaq	0x20(%rsp), %rsi
    19bb:      	movl	$0x1, %eax
    19c0:      	callq	*%rax
    19c2:      	testq	%rax, %rax
    19c5:      	jne	0x1b26 <generic_tracepoint_event+0x1b26>
    19cb:      	movl	$0x1, 0x8(%rsp)
    19d3:      	movq	(%rip), %rdi            # 0x19da <generic_tracepoint_event+0x19da>
    19da:      	xorl	%ecx, %ecx
    19dc:      	leaq	0x20(%rsp), %rsi
    19e1:      	leaq	0x8(%rsp), %rdx
    19e6:      	movl	$0x2, %eax
    19eb:      	jmp	0x1cd1 <generic_tracepoint_event+0x1cd1>
    19f0:      	leaq	0x8(%rsp), %rdi
    19f5:      	movl	$0x1, %ecx
    19fa:      	movl	$0x4, %eax
    19ff:      	movl	$0x1, %esi
    1a04:      	callq	*%rax
    1a06:      	testq	%rax, %rax
    1a09:      	je	0x1c77 <generic_tracepoint_event+0x1c77>
    1a0f:      	negl	%eax
    1a11:      	movw	%ax, 0x20(%rsp)
    1a16:      	movw	$0x7, 0x22(%rsp)
    1a1d:      	movabsq	$0x40000007a, %rax      # imm = 0x40000007A
    1a27:      	movq	%rax, 0x24(%rsp)
    1a2c:      	movq	(%rip), %rdi            # 0x1a33 <generic_tracepoint_event+0x1a33>
    1a33:      	leaq	0x20(%rsp), %rsi
    1a38:      	movl	$0x1, %eax
    1a3d:      	callq	*%rax
    1a3f:      	testq	%rax, %rax
    1a42:      	je	0x1c53 <generic_tracepoint_event+0x1c53>
    1a48:      	incl	(%rax)
    1a4a:      	movsbq	0x8(%rsp), %r12
    1a50:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1a55:      	leaq	0x10(%rsp), %rdi
    1a5a:      	movl	$0x8, %ecx
    1a5f:      	movl	$0x4, %eax
    1a64:      	movl	$0x8, %esi
    1a69:      	callq	*%rax
    1a6b:      	testq	%rax, %rax
    1a6e:      	je	0x1cd5 <generic_tracepoint_event+0x1cd5>
    1a74:      	negl	%eax
    1a76:      	movw	%ax, 0x20(%rsp)
    1a7b:      	movw	$0x7, 0x22(%rsp)
    1a82:      	movabsq	$0x4000000a1, %rax      # imm = 0x4000000A1
    1a8c:      	movq	%rax, 0x24(%rsp)
    1a91:      	movq	(%rip), %rdi            # 0x1a98 <generic_tracepoint_event+0x1a98>
    1a98:      	leaq	0x20(%rsp), %rsi
    1a9d:      	movl	$0x1, %eax
    1aa2:      	callq	*%rax
    1aa4:      	testq	%rax, %rax
    1aa7:      	jne	0x1b26 <generic_tracepoint_event+0x1b26>
    1aa9:      	movl	$0x1, 0x8(%rsp)
    1ab1:      	movq	(%rip), %rdi            # 0x1ab8 <generic_tracepoint_event+0x1ab8>
    1ab8:      	xorl	%ecx, %ecx
    1aba:      	leaq	0x20(%rsp), %rsi
    1abf:      	leaq	0x8(%rsp), %rdx
    1ac4:      	movl	$0x2, %eax
    1ac9:      	jmp	0x1cd1 <generic_tracepoint_event+0x1cd1>
    1ace:      	leaq	0x10(%rsp), %rdi
    1ad3:      	movl	$0x8, %ecx
    1ad8:      	movl	$0x4, %eax
    1add:      	movl	$0x8, %esi
    1ae2:      	callq	*%rax
    1ae4:      	testq	%rax, %rax
    1ae7:      	je	0x1cd5 <generic_tracepoint_event+0x1cd5>
    1aed:      	negl	%eax
    1aef:      	movw	%ax, 0x20(%rsp)
    1af4:      	movw	$0x7, 0x22(%rsp)
    1afb:      	movabsq	$0x40000004e, %rax      # imm = 0x40000004E
    1b05:      	movq	%rax, 0x24(%rsp)
    1b0a:      	movq	(%rip), %rdi            # 0x1b11 <generic_tracepoint_event+0x1b11>
    1b11:      	leaq	0x20(%rsp), %rsi
    1b16:      	movl	$0x1, %eax
    1b1b:      	callq	*%rax
    1b1d:      	testq	%rax, %rax
    1b20:      	je	0x1cb1 <generic_tracepoint_event+0x1cb1>
    1b26:      	incl	(%rax)
    1b28:      	jmp	0x1cd5 <generic_tracepoint_event+0x1cd5>
    1b2d:      	leaq	0x8(%rsp), %rdi
    1b32:      	movl	$0x2, %ecx
    1b37:      	movl	$0x4, %eax
    1b3c:      	movl	$0x2, %esi
    1b41:      	callq	*%rax
    1b43:      	testq	%rax, %rax
    1b46:      	je	0x1d00 <generic_tracepoint_event+0x1d00>
    1b4c:      	negl	%eax
    1b4e:      	movw	%ax, 0x20(%rsp)
    1b53:      	movw	$0x7, 0x22(%rsp)
    1b5a:      	movabsq	$0x400000065, %rax      # imm = 0x400000065
    1b64:      	movq	%rax, 0x24(%rsp)
    1b69:      	movq	(%rip), %rdi            # 0x1b70 <generic_tracepoint_event+0x1b70>
    1b70:      	leaq	0x20(%rsp), %rsi
    1b75:      	movl	$0x1, %eax
    1b7a:      	callq	*%rax
    1b7c:      	testq	%rax, %rax
    1b7f:      	je	0x1cdc <generic_tracepoint_event+0x1cdc>
    1b85:      	incl	(%rax)
    1b87:      	movzwl	0x8(%rsp), %r12d
    1b8d:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1b92:      	leaq	0x8(%rsp), %rdi
    1b97:      	movl	$0x4, %ecx
    1b9c:      	movl	$0x4, %eax
    1ba1:      	movl	$0x4, %esi
    1ba6:      	callq	*%rax
    1ba8:      	testq	%rax, %rax
    1bab:      	je	0x1d2c <generic_tracepoint_event+0x1d2c>
    1bb1:      	negl	%eax
    1bb3:      	movw	%ax, 0x20(%rsp)
    1bb8:      	movw	$0x7, 0x22(%rsp)
    1bbf:      	movabsq	$0x400000088, %rax      # imm = 0x400000088
    1bc9:      	movq	%rax, 0x24(%rsp)
    1bce:      	movq	(%rip), %rdi            # 0x1bd5 <generic_tracepoint_event+0x1bd5>
    1bd5:      	leaq	0x20(%rsp), %rsi
    1bda:      	movl	$0x1, %eax
    1bdf:      	callq	*%rax
    1be1:      	testq	%rax, %rax
    1be4:      	je	0x1d08 <generic_tracepoint_event+0x1d08>
    1bea:      	incl	(%rax)
    1bec:      	movl	0x8(%rsp), %r12d
    1bf1:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1bf6:      	movl	$0x1, 0x10(%rsp)
    1bfe:      	movq	(%rip), %rdi            # 0x1c05 <generic_tracepoint_event+0x1c05>
    1c05:      	xorl	%ecx, %ecx
    1c07:      	leaq	0x20(%rsp), %rsi
    1c0c:      	leaq	0x10(%rsp), %rdx
    1c11:      	movl	$0x2, %eax
    1c16:      	xorl	%ecx, %ecx
    1c18:      	callq	*%rax
    1c1a:      	movslq	0x8(%rsp), %r12
    1c1f:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1c24:      	movl	$0x1, 0x10(%rsp)
    1c2c:      	movq	(%rip), %rdi            # 0x1c33 <generic_tracepoint_event+0x1c33>
    1c33:      	xorl	%ecx, %ecx
    1c35:      	leaq	0x20(%rsp), %rsi
    1c3a:      	leaq	0x10(%rsp), %rdx
    1c3f:      	movl	$0x2, %eax
    1c44:      	xorl	%ecx, %ecx
    1c46:      	callq	*%rax
    1c48:      	movswq	0x8(%rsp), %r12
    1c4e:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1c53:      	movl	$0x1, 0x10(%rsp)
    1c5b:      	movq	(%rip), %rdi            # 0x1c62 <generic_tracepoint_event+0x1c62>
    1c62:      	xorl	%ecx, %ecx
    1c64:      	leaq	0x20(%rsp), %rsi
    1c69:      	leaq	0x10(%rsp), %rdx
    1c6e:      	movl	$0x2, %eax
    1c73:      	xorl	%ecx, %ecx
    1c75:      	callq	*%rax
    1c77:      	movsbq	0x8(%rsp), %r12
    1c7d:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1c82:      	movl	$0x1, 0x10(%rsp)
    1c8a:      	movq	(%rip), %rdi            # 0x1c91 <generic_tracepoint_event+0x1c91>
    1c91:      	xorl	%ecx, %ecx
    1c93:      	leaq	0x20(%rsp), %rsi
    1c98:      	leaq	0x10(%rsp), %rdx
    1c9d:      	movl	$0x2, %eax
    1ca2:      	xorl	%ecx, %ecx
    1ca4:      	callq	*%rax
    1ca6:      	movzbl	0x8(%rsp), %r12d
    1cac:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1cb1:      	movl	$0x1, 0x8(%rsp)
    1cb9:      	movq	(%rip), %rdi            # 0x1cc0 <generic_tracepoint_event+0x1cc0>
    1cc0:      	xorl	%ecx, %ecx
    1cc2:      	leaq	0x20(%rsp), %rsi
    1cc7:      	leaq	0x8(%rsp), %rdx
    1ccc:      	movl	$0x2, %eax
    1cd1:      	xorl	%ecx, %ecx
    1cd3:      	callq	*%rax
    1cd5:      	movq	0x10(%rsp), %r12
    1cda:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1cdc:      	movl	$0x1, 0x10(%rsp)
    1ce4:      	movq	(%rip), %rdi            # 0x1ceb <generic_tracepoint_event+0x1ceb>
    1ceb:      	xorl	%ecx, %ecx
    1ced:      	leaq	0x20(%rsp), %rsi
    1cf2:      	leaq	0x10(%rsp), %rdx
    1cf7:      	movl	$0x2, %eax
    1cfc:      	xorl	%ecx, %ecx
    1cfe:      	callq	*%rax
    1d00:      	movzwl	0x8(%rsp), %r12d
    1d06:      	jmp	0x1d31 <generic_tracepoint_event+0x1d31>
    1d08:      	movl	$0x1, 0x10(%rsp)
    1d10:      	movq	(%rip), %rdi            # 0x1d17 <generic_tracepoint_event+0x1d17>
    1d17:      	xorl	%ecx, %ecx
    1d19:      	leaq	0x20(%rsp), %rsi
    1d1e:      	leaq	0x10(%rsp), %rdx
    1d23:      	movl	$0x2, %eax
    1d28:      	xorl	%ecx, %ecx
    1d2a:      	callq	*%rax
    1d2c:      	movl	0x8(%rsp), %r12d
    1d31:      	movq	%r12, 0x5e60(%r14)
    1d38:      	movzwl	0x38(%r15), %edx
    1d3d:      	movl	0x10(%r15), %r13d
    1d41:      	addq	%rbx, %rdx
    1d44:      	xorl	%r12d, %r12d
    1d47:      	cmpl	$0xb, %r13d
    1d4b:      	jg	0x1d84 <generic_tracepoint_event+0x1d84>
    1d4d:      	cmpl	$0x3, %r13d
    1d51:      	jle	0x1e1b <generic_tracepoint_event+0x1e1b>
    1d57:      	cmpl	$0x6, %r13d
    1d5b:      	jg	0x1f42 <generic_tracepoint_event+0x1f42>
    1d61:      	cmpl	$0x4, %r13d
    1d65:      	je	0x23a3 <generic_tracepoint_event+0x23a3>
    1d6b:      	cmpl	$0x5, %r13d
    1d6f:      	je	0x2248 <generic_tracepoint_event+0x2248>
    1d75:      	cmpl	$0x6, %r13d
    1d79:      	je	0x1e3c <generic_tracepoint_event+0x1e3c>
    1d7f:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    1d84:      	cmpl	$0x1d, %r13d
    1d88:      	jle	0x1eb9 <generic_tracepoint_event+0x1eb9>
    1d8e:      	cmpl	$0x25, %r13d
    1d92:      	jg	0x1fae <generic_tracepoint_event+0x1fae>
    1d98:      	cmpl	$0x1e, %r13d
    1d9c:      	je	0x2402 <generic_tracepoint_event+0x2402>
    1da2:      	cmpl	$0x1f, %r13d
    1da6:      	je	0x22c5 <generic_tracepoint_event+0x22c5>
    1dac:      	cmpl	$0x20, %r13d
    1db0:      	jne	0x2606 <generic_tracepoint_event+0x2606>
    1db6:      	leaq	0x8(%rsp), %rdi
    1dbb:      	movl	$0x1, %ecx
    1dc0:      	movl	$0x4, %eax
    1dc5:      	movl	$0x1, %esi
    1dca:      	callq	*%rax
    1dcc:      	testq	%rax, %rax
    1dcf:      	je	0x257b <generic_tracepoint_event+0x257b>
    1dd5:      	negl	%eax
    1dd7:      	movw	%ax, 0x20(%rsp)
    1ddc:      	movw	$0x7, 0x22(%rsp)
    1de3:      	movabsq	$0x400000073, %rax      # imm = 0x400000073
    1ded:      	movq	%rax, 0x24(%rsp)
    1df2:      	movq	(%rip), %rdi            # 0x1df9 <generic_tracepoint_event+0x1df9>
    1df9:      	leaq	0x20(%rsp), %rsi
    1dfe:      	movl	$0x1, %eax
    1e03:      	callq	*%rax
    1e05:      	testq	%rax, %rax
    1e08:      	je	0x2557 <generic_tracepoint_event+0x2557>
    1e0e:      	incl	(%rax)
    1e10:      	movzbl	0x8(%rsp), %r12d
    1e16:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    1e1b:      	cmpl	$-0xc, %r13d
    1e1f:      	jle	0x2049 <generic_tracepoint_event+0x2049>
    1e25:      	leal	0xb(%r13), %eax
    1e29:      	cmpl	$0x2, %eax
    1e2c:      	jb	0x1f4f <generic_tracepoint_event+0x1f4f>
    1e32:      	cmpl	$0x2, %r13d
    1e36:      	jne	0x2606 <generic_tracepoint_event+0x2606>
    1e3c:      	leaq	0x10(%rsp), %rdi
    1e41:      	movl	$0x8, %ecx
    1e46:      	movl	$0x4, %eax
    1e4b:      	movl	$0x8, %esi
    1e50:      	callq	*%rax
    1e52:      	testq	%rax, %rax
    1e55:      	je	0x25aa <generic_tracepoint_event+0x25aa>
    1e5b:      	negl	%eax
    1e5d:      	movw	%ax, 0x20(%rsp)
    1e62:      	movw	$0x7, 0x22(%rsp)
    1e69:      	movabsq	$0x400000081, %rax      # imm = 0x400000081
    1e73:      	movq	%rax, 0x24(%rsp)
    1e78:      	movq	(%rip), %rdi            # 0x1e7f <generic_tracepoint_event+0x1e7f>
    1e7f:      	leaq	0x20(%rsp), %rsi
    1e84:      	movl	$0x1, %eax
    1e89:      	callq	*%rax
    1e8b:      	testq	%rax, %rax
    1e8e:      	jne	0x23fb <generic_tracepoint_event+0x23fb>
    1e94:      	movl	$0x1, 0x8(%rsp)
    1e9c:      	movq	(%rip), %rdi            # 0x1ea3 <generic_tracepoint_event+0x1ea3>
    1ea3:      	xorl	%ecx, %ecx
    1ea5:      	leaq	0x20(%rsp), %rsi
    1eaa:      	leaq	0x8(%rsp), %rdx
    1eaf:      	movl	$0x2, %eax
    1eb4:      	jmp	0x25a6 <generic_tracepoint_event+0x25a6>
    1eb9:      	cmpl	$0x11, %r13d
    1ebd:      	jle	0x205e <generic_tracepoint_event+0x205e>
    1ec3:      	cmpl	$0x12, %r13d
    1ec7:      	je	0x2240 <generic_tracepoint_event+0x2240>
    1ecd:      	cmpl	$0x1c, %r13d
    1ed1:      	je	0x1f4f <generic_tracepoint_event+0x1f4f>
    1ed3:      	cmpl	$0x1d, %r13d
    1ed7:      	jne	0x2606 <generic_tracepoint_event+0x2606>
    1edd:      	leaq	0x8(%rsp), %rdi
    1ee2:      	movl	$0x2, %ecx
    1ee7:      	movl	$0x4, %eax
    1eec:      	movl	$0x2, %esi
    1ef1:      	callq	*%rax
    1ef3:      	testq	%rax, %rax
    1ef6:      	je	0x251d <generic_tracepoint_event+0x251d>
    1efc:      	negl	%eax
    1efe:      	movw	%ax, 0x20(%rsp)
    1f03:      	movw	$0x7, 0x22(%rsp)
    1f0a:      	movabsq	$0x40000006c, %rax      # imm = 0x40000006C
    1f14:      	movq	%rax, 0x24(%rsp)
    1f19:      	movq	(%rip), %rdi            # 0x1f20 <generic_tracepoint_event+0x1f20>
    1f20:      	leaq	0x20(%rsp), %rsi
    1f25:      	movl	$0x1, %eax
    1f2a:      	callq	*%rax
    1f2c:      	testq	%rax, %rax
    1f2f:      	je	0x24f9 <generic_tracepoint_event+0x24f9>
    1f35:      	incl	(%rax)
    1f37:      	movswq	0x8(%rsp), %r12
    1f3d:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    1f42:      	leal	-0xa(%r13), %eax
    1f46:      	cmpl	$0x2, %eax
    1f49:      	jae	0x21b9 <generic_tracepoint_event+0x21b9>
    1f4f:      	leaq	0x10(%rsp), %rdi
    1f54:      	movl	$0x8, %ecx
    1f59:      	movl	$0x4, %eax
    1f5e:      	movl	$0x8, %esi
    1f63:      	callq	*%rax
    1f65:      	testq	%rax, %rax
    1f68:      	je	0x2177 <generic_tracepoint_event+0x2177>
    1f6e:      	negl	%eax
    1f70:      	movw	%ax, 0x20(%rsp)
    1f75:      	movw	$0x7, 0x22(%rsp)
    1f7c:      	movabsq	$0x400000045, %rax      # imm = 0x400000045
    1f86:      	movq	%rax, 0x24(%rsp)
    1f8b:      	movq	(%rip), %rdi            # 0x1f92 <generic_tracepoint_event+0x1f92>
    1f92:      	leaq	0x20(%rsp), %rsi
    1f97:      	movl	$0x1, %eax
    1f9c:      	callq	*%rax
    1f9e:      	testq	%rax, %rax
    1fa1:      	je	0x2153 <generic_tracepoint_event+0x2153>
    1fa7:      	incl	(%rax)
    1fa9:      	jmp	0x2177 <generic_tracepoint_event+0x2177>
    1fae:      	cmpl	$0x26, %r13d
    1fb2:      	je	0x2467 <generic_tracepoint_event+0x2467>
    1fb8:      	cmpl	$0x28, %r13d
    1fbc:      	je	0x232a <generic_tracepoint_event+0x232a>
    1fc2:      	cmpl	$0x29, %r13d
    1fc6:      	jne	0x2606 <generic_tracepoint_event+0x2606>
    1fcc:      	leaq	0x10(%rsp), %rdi
    1fd1:      	movl	$0x8, %ecx
    1fd6:      	movl	$0x4, %eax
    1fdb:      	movl	$0x8, %esi
    1fe0:      	callq	*%rax
    1fe2:      	testq	%rax, %rax
    1fe5:      	je	0x25aa <generic_tracepoint_event+0x25aa>
    1feb:      	negl	%eax
    1fed:      	movw	%ax, 0x20(%rsp)
    1ff2:      	movw	$0x7, 0x22(%rsp)
    1ff9:      	movabsq	$0x4000000a8, %rax      # imm = 0x4000000A8
    2003:      	movq	%rax, 0x24(%rsp)
    2008:      	movq	(%rip), %rdi            # 0x200f <generic_tracepoint_event+0x200f>
    200f:      	leaq	0x20(%rsp), %rsi
    2014:      	movl	$0x1, %eax
    2019:      	callq	*%rax
    201b:      	testq	%rax, %rax
    201e:      	jne	0x23fb <generic_tracepoint_event+0x23fb>
    2024:      	movl	$0x1, 0x8(%rsp)
    202c:      	movq	(%rip), %rdi            # 0x2033 <generic_tracepoint_event+0x2033>
    2033:      	xorl	%ecx, %ecx
    2035:      	leaq	0x20(%rsp), %rsi
    203a:      	leaq	0x8(%rsp), %rdx
    203f:      	movl	$0x2, %eax
    2044:      	jmp	0x25a6 <generic_tracepoint_event+0x25a6>
    2049:      	cmpl	$-0xd, %r13d
    204d:      	je	0x20ef <generic_tracepoint_event+0x20ef>
    2053:      	cmpl	$-0xc, %r13d
    2057:      	je	0x2072 <generic_tracepoint_event+0x2072>
    2059:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    205e:      	cmpl	$0xc, %r13d
    2062:      	je	0x20ef <generic_tracepoint_event+0x20ef>
    2068:      	cmpl	$0xd, %r13d
    206c:      	jne	0x2606 <generic_tracepoint_event+0x2606>
    2072:      	leaq	0x8(%rsp), %rdi
    2077:      	movl	$0x4, %ecx
    207c:      	movl	$0x4, %eax
    2081:      	movl	$0x4, %esi
    2086:      	callq	*%rax
    2088:      	testq	%rax, %rax
    208b:      	je	0x2601 <generic_tracepoint_event+0x2601>
    2091:      	negl	%eax
    2093:      	movw	%ax, 0x20(%rsp)
    2098:      	movw	$0x7, 0x22(%rsp)
    209f:      	movabsq	$0x40000005e, %rax      # imm = 0x40000005E
    20a9:      	movq	%rax, 0x24(%rsp)
    20ae:      	movq	(%rip), %rdi            # 0x20b5 <generic_tracepoint_event+0x20b5>
    20b5:      	leaq	0x20(%rsp), %rsi
    20ba:      	movl	$0x1, %eax
    20bf:      	callq	*%rax
    20c1:      	testq	%rax, %rax
    20c4:      	jne	0x24bf <generic_tracepoint_event+0x24bf>
    20ca:      	movl	$0x1, 0x10(%rsp)
    20d2:      	movq	(%rip), %rdi            # 0x20d9 <generic_tracepoint_event+0x20d9>
    20d9:      	xorl	%ecx, %ecx
    20db:      	leaq	0x20(%rsp), %rsi
    20e0:      	leaq	0x10(%rsp), %rdx
    20e5:      	movl	$0x2, %eax
    20ea:      	jmp	0x25fd <generic_tracepoint_event+0x25fd>
    20ef:      	leaq	0x8(%rsp), %rdi
    20f4:      	movl	$0x4, %ecx
    20f9:      	movl	$0x4, %eax
    20fe:      	movl	$0x4, %esi
    2103:      	callq	*%rax
    2105:      	testq	%rax, %rax
    2108:      	je	0x24ef <generic_tracepoint_event+0x24ef>
    210e:      	negl	%eax
    2110:      	movw	%ax, 0x20(%rsp)
    2115:      	movw	$0x7, 0x22(%rsp)
    211c:      	movabsq	$0x400000056, %rax      # imm = 0x400000056
    2126:      	movq	%rax, 0x24(%rsp)
    212b:      	movq	(%rip), %rdi            # 0x2132 <generic_tracepoint_event+0x2132>
    2132:      	leaq	0x20(%rsp), %rsi
    2137:      	movl	$0x1, %eax
    213c:      	callq	*%rax
    213e:      	testq	%rax, %rax
    2141:      	je	0x24cb <generic_tracepoint_event+0x24cb>
    2147:      	incl	(%rax)
    2149:      	movslq	0x8(%rsp), %r12
    214e:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    2153:      	movl	$0x1, 0x8(%rsp)
    215b:      	movq	(%rip), %rdi            # 0x2162 <generic_tracepoint_event+0x2162>
    2162:      	xorl	%ecx, %ecx
    2164:      	leaq	0x20(%rsp), %rsi
    2169:      	leaq	0x8(%rsp), %rdx
    216e:      	movl	$0x2, %eax
    2173:      	xorl	%ecx, %ecx
    2175:      	callq	*%rax
    2177:      	movq	0x10(%rsp), %r12
    217c:      	cmpl	$0x1c, %r13d
    2180:      	jne	0x2606 <generic_tracepoint_event+0x2606>
    2186:      	movl	$0x23, %eax
    218b:      	callq	*%rax
    218d:      	leaq	0x10(%rax), %rdx
    2191:      	leaq	0x20(%rsp), %rdi
    2196:      	movl	$0x4, %ecx
    219b:      	movl	$0x4, %eax
    21a0:      	movl	$0x4, %esi
    21a5:      	callq	*%rax
    21a7:      	movl	0x20(%rsp), %eax
    21ab:      	andl	$-0x2, %eax
    21ae:      	shll	$0x1e, %eax
    21b1:      	orq	%rax, %r12
    21b4:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    21b9:      	cmpl	$0x7, %r13d
    21bd:      	jne	0x2606 <generic_tracepoint_event+0x2606>
    21c3:      	leaq	0x10(%rsp), %rdi
    21c8:      	movl	$0x8, %ecx
    21cd:      	movl	$0x4, %eax
    21d2:      	movl	$0x8, %esi
    21d7:      	callq	*%rax
    21d9:      	testq	%rax, %rax
    21dc:      	je	0x25aa <generic_tracepoint_event+0x25aa>
    21e2:      	negl	%eax
    21e4:      	movw	%ax, 0x20(%rsp)
    21e9:      	movw	$0x7, 0x22(%rsp)
    21f0:      	movabsq	$0x40000009a, %rax      # imm = 0x40000009A
    21fa:      	movq	%rax, 0x24(%rsp)
    21ff:      	movq	(%rip), %rdi            # 0x2206 <generic_tracepoint_event+0x2206>
    2206:      	leaq	0x20(%rsp), %rsi
    220b:      	movl	$0x1, %eax
    2210:      	callq	*%rax
    2212:      	testq	%rax, %rax
    2215:      	jne	0x23fb <generic_tracepoint_event+0x23fb>
    221b:      	movl	$0x1, 0x8(%rsp)
    2223:      	movq	(%rip), %rdi            # 0x222a <generic_tracepoint_event+0x222a>
    222a:      	xorl	%ecx, %ecx
    222c:      	leaq	0x20(%rsp), %rsi
    2231:      	leaq	0x8(%rsp), %rdx
    2236:      	movl	$0x2, %eax
    223b:      	jmp	0x25a6 <generic_tracepoint_event+0x25a6>
    2240:      	movq	%rdx, %r12
    2243:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    2248:      	leaq	0x10(%rsp), %rdi
    224d:      	movl	$0x8, %ecx
    2252:      	movl	$0x4, %eax
    2257:      	movl	$0x8, %esi
    225c:      	callq	*%rax
    225e:      	testq	%rax, %rax
    2261:      	je	0x25aa <generic_tracepoint_event+0x25aa>
    2267:      	negl	%eax
    2269:      	movw	%ax, 0x20(%rsp)
    226e:      	movw	$0x7, 0x22(%rsp)
    2275:      	movabsq	$0x400000093, %rax      # imm = 0x400000093
    227f:      	movq	%rax, 0x24(%rsp)
    2284:      	movq	(%rip), %rdi            # 0x228b <generic_tracepoint_event+0x228b>
    228b:      	leaq	0x20(%rsp), %rsi
    2290:      	movl	$0x1, %eax
    2295:      	callq	*%rax
    2297:      	testq	%rax, %rax
    229a:      	jne	0x23fb <generic_tracepoint_event+0x23fb>
    22a0:      	movl	$0x1, 0x8(%rsp)
    22a8:      	movq	(%rip), %rdi            # 0x22af <generic_tracepoint_event+0x22af>
    22af:      	xorl	%ecx, %ecx
    22b1:      	leaq	0x20(%rsp), %rsi
    22b6:      	leaq	0x8(%rsp), %rdx
    22bb:      	movl	$0x2, %eax
    22c0:      	jmp	0x25a6 <generic_tracepoint_event+0x25a6>
    22c5:      	leaq	0x8(%rsp), %rdi
    22ca:      	movl	$0x1, %ecx
    22cf:      	movl	$0x4, %eax
    22d4:      	movl	$0x1, %esi
    22d9:      	callq	*%rax
    22db:      	testq	%rax, %rax
    22de:      	je	0x254c <generic_tracepoint_event+0x254c>
    22e4:      	negl	%eax
    22e6:      	movw	%ax, 0x20(%rsp)
    22eb:      	movw	$0x7, 0x22(%rsp)
    22f2:      	movabsq	$0x40000007a, %rax      # imm = 0x40000007A
    22fc:      	movq	%rax, 0x24(%rsp)
    2301:      	movq	(%rip), %rdi            # 0x2308 <generic_tracepoint_event+0x2308>
    2308:      	leaq	0x20(%rsp), %rsi
    230d:      	movl	$0x1, %eax
    2312:      	callq	*%rax
    2314:      	testq	%rax, %rax
    2317:      	je	0x2528 <generic_tracepoint_event+0x2528>
    231d:      	incl	(%rax)
    231f:      	movsbq	0x8(%rsp), %r12
    2325:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    232a:      	leaq	0x10(%rsp), %rdi
    232f:      	movl	$0x8, %ecx
    2334:      	movl	$0x4, %eax
    2339:      	movl	$0x8, %esi
    233e:      	callq	*%rax
    2340:      	testq	%rax, %rax
    2343:      	je	0x25aa <generic_tracepoint_event+0x25aa>
    2349:      	negl	%eax
    234b:      	movw	%ax, 0x20(%rsp)
    2350:      	movw	$0x7, 0x22(%rsp)
    2357:      	movabsq	$0x4000000a1, %rax      # imm = 0x4000000A1
    2361:      	movq	%rax, 0x24(%rsp)
    2366:      	movq	(%rip), %rdi            # 0x236d <generic_tracepoint_event+0x236d>
    236d:      	leaq	0x20(%rsp), %rsi
    2372:      	movl	$0x1, %eax
    2377:      	callq	*%rax
    2379:      	testq	%rax, %rax
    237c:      	jne	0x23fb <generic_tracepoint_event+0x23fb>
    237e:      	movl	$0x1, 0x8(%rsp)
    2386:      	movq	(%rip), %rdi            # 0x238d <generic_tracepoint_event+0x238d>
    238d:      	xorl	%ecx, %ecx
    238f:      	leaq	0x20(%rsp), %rsi
    2394:      	leaq	0x8(%rsp), %rdx
    2399:      	movl	$0x2, %eax
    239e:      	jmp	0x25a6 <generic_tracepoint_event+0x25a6>
    23a3:      	leaq	0x10(%rsp), %rdi
    23a8:      	movl	$0x8, %ecx
    23ad:      	movl	$0x4, %eax
    23b2:      	movl	$0x8, %esi
    23b7:      	callq	*%rax
    23b9:      	testq	%rax, %rax
    23bc:      	je	0x25aa <generic_tracepoint_event+0x25aa>
    23c2:      	negl	%eax
    23c4:      	movw	%ax, 0x20(%rsp)
    23c9:      	movw	$0x7, 0x22(%rsp)
    23d0:      	movabsq	$0x40000004e, %rax      # imm = 0x40000004E
    23da:      	movq	%rax, 0x24(%rsp)
    23df:      	movq	(%rip), %rdi            # 0x23e6 <generic_tracepoint_event+0x23e6>
    23e6:      	leaq	0x20(%rsp), %rsi
    23eb:      	movl	$0x1, %eax
    23f0:      	callq	*%rax
    23f2:      	testq	%rax, %rax
    23f5:      	je	0x2586 <generic_tracepoint_event+0x2586>
    23fb:      	incl	(%rax)
    23fd:      	jmp	0x25aa <generic_tracepoint_event+0x25aa>
    2402:      	leaq	0x8(%rsp), %rdi
    2407:      	movl	$0x2, %ecx
    240c:      	movl	$0x4, %eax
    2411:      	movl	$0x2, %esi
    2416:      	callq	*%rax
    2418:      	testq	%rax, %rax
    241b:      	je	0x25d5 <generic_tracepoint_event+0x25d5>
    2421:      	negl	%eax
    2423:      	movw	%ax, 0x20(%rsp)
    2428:      	movw	$0x7, 0x22(%rsp)
    242f:      	movabsq	$0x400000065, %rax      # imm = 0x400000065
    2439:      	movq	%rax, 0x24(%rsp)
    243e:      	movq	(%rip), %rdi            # 0x2445 <generic_tracepoint_event+0x2445>
    2445:      	leaq	0x20(%rsp), %rsi
    244a:      	movl	$0x1, %eax
    244f:      	callq	*%rax
    2451:      	testq	%rax, %rax
    2454:      	je	0x25b1 <generic_tracepoint_event+0x25b1>
    245a:      	incl	(%rax)
    245c:      	movzwl	0x8(%rsp), %r12d
    2462:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    2467:      	leaq	0x8(%rsp), %rdi
    246c:      	movl	$0x4, %ecx
    2471:      	movl	$0x4, %eax
    2476:      	movl	$0x4, %esi
    247b:      	callq	*%rax
    247d:      	testq	%rax, %rax
    2480:      	je	0x2601 <generic_tracepoint_event+0x2601>
    2486:      	negl	%eax
    2488:      	movw	%ax, 0x20(%rsp)
    248d:      	movw	$0x7, 0x22(%rsp)
    2494:      	movabsq	$0x400000088, %rax      # imm = 0x400000088
    249e:      	movq	%rax, 0x24(%rsp)
    24a3:      	movq	(%rip), %rdi            # 0x24aa <generic_tracepoint_event+0x24aa>
    24aa:      	leaq	0x20(%rsp), %rsi
    24af:      	movl	$0x1, %eax
    24b4:      	callq	*%rax
    24b6:      	testq	%rax, %rax
    24b9:      	je	0x25dd <generic_tracepoint_event+0x25dd>
    24bf:      	incl	(%rax)
    24c1:      	movl	0x8(%rsp), %r12d
    24c6:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    24cb:      	movl	$0x1, 0x10(%rsp)
    24d3:      	movq	(%rip), %rdi            # 0x24da <generic_tracepoint_event+0x24da>
    24da:      	xorl	%ecx, %ecx
    24dc:      	leaq	0x20(%rsp), %rsi
    24e1:      	leaq	0x10(%rsp), %rdx
    24e6:      	movl	$0x2, %eax
    24eb:      	xorl	%ecx, %ecx
    24ed:      	callq	*%rax
    24ef:      	movslq	0x8(%rsp), %r12
    24f4:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    24f9:      	movl	$0x1, 0x10(%rsp)
    2501:      	movq	(%rip), %rdi            # 0x2508 <generic_tracepoint_event+0x2508>
    2508:      	xorl	%ecx, %ecx
    250a:      	leaq	0x20(%rsp), %rsi
    250f:      	leaq	0x10(%rsp), %rdx
    2514:      	movl	$0x2, %eax
    2519:      	xorl	%ecx, %ecx
    251b:      	callq	*%rax
    251d:      	movswq	0x8(%rsp), %r12
    2523:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    2528:      	movl	$0x1, 0x10(%rsp)
    2530:      	movq	(%rip), %rdi            # 0x2537 <generic_tracepoint_event+0x2537>
    2537:      	xorl	%ecx, %ecx
    2539:      	leaq	0x20(%rsp), %rsi
    253e:      	leaq	0x10(%rsp), %rdx
    2543:      	movl	$0x2, %eax
    2548:      	xorl	%ecx, %ecx
    254a:      	callq	*%rax
    254c:      	movsbq	0x8(%rsp), %r12
    2552:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    2557:      	movl	$0x1, 0x10(%rsp)
    255f:      	movq	(%rip), %rdi            # 0x2566 <generic_tracepoint_event+0x2566>
    2566:      	xorl	%ecx, %ecx
    2568:      	leaq	0x20(%rsp), %rsi
    256d:      	leaq	0x10(%rsp), %rdx
    2572:      	movl	$0x2, %eax
    2577:      	xorl	%ecx, %ecx
    2579:      	callq	*%rax
    257b:      	movzbl	0x8(%rsp), %r12d
    2581:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    2586:      	movl	$0x1, 0x8(%rsp)
    258e:      	movq	(%rip), %rdi            # 0x2595 <generic_tracepoint_event+0x2595>
    2595:      	xorl	%ecx, %ecx
    2597:      	leaq	0x20(%rsp), %rsi
    259c:      	leaq	0x8(%rsp), %rdx
    25a1:      	movl	$0x2, %eax
    25a6:      	xorl	%ecx, %ecx
    25a8:      	callq	*%rax
    25aa:      	movq	0x10(%rsp), %r12
    25af:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    25b1:      	movl	$0x1, 0x10(%rsp)
    25b9:      	movq	(%rip), %rdi            # 0x25c0 <generic_tracepoint_event+0x25c0>
    25c0:      	xorl	%ecx, %ecx
    25c2:      	leaq	0x20(%rsp), %rsi
    25c7:      	leaq	0x10(%rsp), %rdx
    25cc:      	movl	$0x2, %eax
    25d1:      	xorl	%ecx, %ecx
    25d3:      	callq	*%rax
    25d5:      	movzwl	0x8(%rsp), %r12d
    25db:      	jmp	0x2606 <generic_tracepoint_event+0x2606>
    25dd:      	movl	$0x1, 0x10(%rsp)
    25e5:      	movq	(%rip), %rdi            # 0x25ec <generic_tracepoint_event+0x25ec>
    25ec:      	xorl	%ecx, %ecx
    25ee:      	leaq	0x20(%rsp), %rsi
    25f3:      	leaq	0x10(%rsp), %rdx
    25f8:      	movl	$0x2, %eax
    25fd:      	xorl	%ecx, %ecx
    25ff:      	callq	*%rax
    2601:      	movl	0x8(%rsp), %r12d
    2606:      	movq	%r12, 0x5e68(%r14)
    260d:      	movzwl	0x3c(%r15), %edx
    2612:      	movl	0x14(%r15), %r12d
    2616:      	addq	%rbx, %rdx
    2619:      	xorl	%r15d, %r15d
    261c:      	cmpl	$0xb, %r12d
    2620:      	jg	0x2659 <generic_tracepoint_event+0x2659>
    2622:      	cmpl	$0x3, %r12d
    2626:      	jle	0x26f0 <generic_tracepoint_event+0x26f0>
    262c:      	cmpl	$0x6, %r12d
    2630:      	jg	0x2818 <generic_tracepoint_event+0x2818>
    2636:      	cmpl	$0x4, %r12d
    263a:      	je	0x2c7a <generic_tracepoint_event+0x2c7a>
    2640:      	cmpl	$0x5, %r12d
    2644:      	je	0x2b1f <generic_tracepoint_event+0x2b1f>
    264a:      	cmpl	$0x6, %r12d
    264e:      	je	0x2712 <generic_tracepoint_event+0x2712>
    2654:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2659:      	cmpl	$0x1d, %r12d
    265d:      	jle	0x278f <generic_tracepoint_event+0x278f>
    2663:      	cmpl	$0x25, %r12d
    2667:      	jg	0x2885 <generic_tracepoint_event+0x2885>
    266d:      	cmpl	$0x1e, %r12d
    2671:      	je	0x2cd9 <generic_tracepoint_event+0x2cd9>
    2677:      	cmpl	$0x1f, %r12d
    267b:      	je	0x2b9c <generic_tracepoint_event+0x2b9c>
    2681:      	cmpl	$0x20, %r12d
    2685:      	jne	0x2edd <generic_tracepoint_event+0x2edd>
    268b:      	leaq	0x8(%rsp), %rdi
    2690:      	movl	$0x1, %ecx
    2695:      	movl	$0x4, %eax
    269a:      	movl	$0x1, %esi
    269f:      	callq	*%rax
    26a1:      	testq	%rax, %rax
    26a4:      	je	0x2e52 <generic_tracepoint_event+0x2e52>
    26aa:      	negl	%eax
    26ac:      	movw	%ax, 0x20(%rsp)
    26b1:      	movw	$0x7, 0x22(%rsp)
    26b8:      	movabsq	$0x400000073, %rax      # imm = 0x400000073
    26c2:      	movq	%rax, 0x24(%rsp)
    26c7:      	movq	(%rip), %rdi            # 0x26ce <generic_tracepoint_event+0x26ce>
    26ce:      	leaq	0x20(%rsp), %rsi
    26d3:      	movl	$0x1, %eax
    26d8:      	callq	*%rax
    26da:      	testq	%rax, %rax
    26dd:      	je	0x2e2e <generic_tracepoint_event+0x2e2e>
    26e3:      	incl	(%rax)
    26e5:      	movzbl	0x8(%rsp), %r15d
    26eb:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    26f0:      	cmpl	$-0xc, %r12d
    26f4:      	jle	0x2920 <generic_tracepoint_event+0x2920>
    26fa:      	leal	0xb(%r12), %eax
    26ff:      	cmpl	$0x2, %eax
    2702:      	jb	0x2826 <generic_tracepoint_event+0x2826>
    2708:      	cmpl	$0x2, %r12d
    270c:      	jne	0x2edd <generic_tracepoint_event+0x2edd>
    2712:      	leaq	0x10(%rsp), %rdi
    2717:      	movl	$0x8, %ecx
    271c:      	movl	$0x4, %eax
    2721:      	movl	$0x8, %esi
    2726:      	callq	*%rax
    2728:      	testq	%rax, %rax
    272b:      	je	0x2e81 <generic_tracepoint_event+0x2e81>
    2731:      	negl	%eax
    2733:      	movw	%ax, 0x20(%rsp)
    2738:      	movw	$0x7, 0x22(%rsp)
    273f:      	movabsq	$0x400000081, %rax      # imm = 0x400000081
    2749:      	movq	%rax, 0x24(%rsp)
    274e:      	movq	(%rip), %rdi            # 0x2755 <generic_tracepoint_event+0x2755>
    2755:      	leaq	0x20(%rsp), %rsi
    275a:      	movl	$0x1, %eax
    275f:      	callq	*%rax
    2761:      	testq	%rax, %rax
    2764:      	jne	0x2cd2 <generic_tracepoint_event+0x2cd2>
    276a:      	movl	$0x1, 0x8(%rsp)
    2772:      	movq	(%rip), %rdi            # 0x2779 <generic_tracepoint_event+0x2779>
    2779:      	xorl	%ecx, %ecx
    277b:      	leaq	0x20(%rsp), %rsi
    2780:      	leaq	0x8(%rsp), %rdx
    2785:      	movl	$0x2, %eax
    278a:      	jmp	0x2e7d <generic_tracepoint_event+0x2e7d>
    278f:      	cmpl	$0x11, %r12d
    2793:      	jle	0x2935 <generic_tracepoint_event+0x2935>
    2799:      	cmpl	$0x12, %r12d
    279d:      	je	0x2b17 <generic_tracepoint_event+0x2b17>
    27a3:      	cmpl	$0x1c, %r12d
    27a7:      	je	0x2826 <generic_tracepoint_event+0x2826>
    27a9:      	cmpl	$0x1d, %r12d
    27ad:      	jne	0x2edd <generic_tracepoint_event+0x2edd>
    27b3:      	leaq	0x8(%rsp), %rdi
    27b8:      	movl	$0x2, %ecx
    27bd:      	movl	$0x4, %eax
    27c2:      	movl	$0x2, %esi
    27c7:      	callq	*%rax
    27c9:      	testq	%rax, %rax
    27cc:      	je	0x2df4 <generic_tracepoint_event+0x2df4>
    27d2:      	negl	%eax
    27d4:      	movw	%ax, 0x20(%rsp)
    27d9:      	movw	$0x7, 0x22(%rsp)
    27e0:      	movabsq	$0x40000006c, %rax      # imm = 0x40000006C
    27ea:      	movq	%rax, 0x24(%rsp)
    27ef:      	movq	(%rip), %rdi            # 0x27f6 <generic_tracepoint_event+0x27f6>
    27f6:      	leaq	0x20(%rsp), %rsi
    27fb:      	movl	$0x1, %eax
    2800:      	callq	*%rax
    2802:      	testq	%rax, %rax
    2805:      	je	0x2dd0 <generic_tracepoint_event+0x2dd0>
    280b:      	incl	(%rax)
    280d:      	movswq	0x8(%rsp), %r15
    2813:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2818:      	leal	-0xa(%r12), %eax
    281d:      	cmpl	$0x2, %eax
    2820:      	jae	0x2a90 <generic_tracepoint_event+0x2a90>
    2826:      	leaq	0x10(%rsp), %rdi
    282b:      	movl	$0x8, %ecx
    2830:      	movl	$0x4, %eax
    2835:      	movl	$0x8, %esi
    283a:      	callq	*%rax
    283c:      	testq	%rax, %rax
    283f:      	je	0x2a4e <generic_tracepoint_event+0x2a4e>
    2845:      	negl	%eax
    2847:      	movw	%ax, 0x20(%rsp)
    284c:      	movw	$0x7, 0x22(%rsp)
    2853:      	movabsq	$0x400000045, %rax      # imm = 0x400000045
    285d:      	movq	%rax, 0x24(%rsp)
    2862:      	movq	(%rip), %rdi            # 0x2869 <generic_tracepoint_event+0x2869>
    2869:      	leaq	0x20(%rsp), %rsi
    286e:      	movl	$0x1, %eax
    2873:      	callq	*%rax
    2875:      	testq	%rax, %rax
    2878:      	je	0x2a2a <generic_tracepoint_event+0x2a2a>
    287e:      	incl	(%rax)
    2880:      	jmp	0x2a4e <generic_tracepoint_event+0x2a4e>
    2885:      	cmpl	$0x26, %r12d
    2889:      	je	0x2d3e <generic_tracepoint_event+0x2d3e>
    288f:      	cmpl	$0x28, %r12d
    2893:      	je	0x2c01 <generic_tracepoint_event+0x2c01>
    2899:      	cmpl	$0x29, %r12d
    289d:      	jne	0x2edd <generic_tracepoint_event+0x2edd>
    28a3:      	leaq	0x10(%rsp), %rdi
    28a8:      	movl	$0x8, %ecx
    28ad:      	movl	$0x4, %eax
    28b2:      	movl	$0x8, %esi
    28b7:      	callq	*%rax
    28b9:      	testq	%rax, %rax
    28bc:      	je	0x2e81 <generic_tracepoint_event+0x2e81>
    28c2:      	negl	%eax
    28c4:      	movw	%ax, 0x20(%rsp)
    28c9:      	movw	$0x7, 0x22(%rsp)
    28d0:      	movabsq	$0x4000000a8, %rax      # imm = 0x4000000A8
    28da:      	movq	%rax, 0x24(%rsp)
    28df:      	movq	(%rip), %rdi            # 0x28e6 <generic_tracepoint_event+0x28e6>
    28e6:      	leaq	0x20(%rsp), %rsi
    28eb:      	movl	$0x1, %eax
    28f0:      	callq	*%rax
    28f2:      	testq	%rax, %rax
    28f5:      	jne	0x2cd2 <generic_tracepoint_event+0x2cd2>
    28fb:      	movl	$0x1, 0x8(%rsp)
    2903:      	movq	(%rip), %rdi            # 0x290a <generic_tracepoint_event+0x290a>
    290a:      	xorl	%ecx, %ecx
    290c:      	leaq	0x20(%rsp), %rsi
    2911:      	leaq	0x8(%rsp), %rdx
    2916:      	movl	$0x2, %eax
    291b:      	jmp	0x2e7d <generic_tracepoint_event+0x2e7d>
    2920:      	cmpl	$-0xd, %r12d
    2924:      	je	0x29c6 <generic_tracepoint_event+0x29c6>
    292a:      	cmpl	$-0xc, %r12d
    292e:      	je	0x2949 <generic_tracepoint_event+0x2949>
    2930:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2935:      	cmpl	$0xc, %r12d
    2939:      	je	0x29c6 <generic_tracepoint_event+0x29c6>
    293f:      	cmpl	$0xd, %r12d
    2943:      	jne	0x2edd <generic_tracepoint_event+0x2edd>
    2949:      	leaq	0x8(%rsp), %rdi
    294e:      	movl	$0x4, %ecx
    2953:      	movl	$0x4, %eax
    2958:      	movl	$0x4, %esi
    295d:      	callq	*%rax
    295f:      	testq	%rax, %rax
    2962:      	je	0x2ed8 <generic_tracepoint_event+0x2ed8>
    2968:      	negl	%eax
    296a:      	movw	%ax, 0x20(%rsp)
    296f:      	movw	$0x7, 0x22(%rsp)
    2976:      	movabsq	$0x40000005e, %rax      # imm = 0x40000005E
    2980:      	movq	%rax, 0x24(%rsp)
    2985:      	movq	(%rip), %rdi            # 0x298c <generic_tracepoint_event+0x298c>
    298c:      	leaq	0x20(%rsp), %rsi
    2991:      	movl	$0x1, %eax
    2996:      	callq	*%rax
    2998:      	testq	%rax, %rax
    299b:      	jne	0x2d96 <generic_tracepoint_event+0x2d96>
    29a1:      	movl	$0x1, 0x10(%rsp)
    29a9:      	movq	(%rip), %rdi            # 0x29b0 <generic_tracepoint_event+0x29b0>
    29b0:      	xorl	%ecx, %ecx
    29b2:      	leaq	0x20(%rsp), %rsi
    29b7:      	leaq	0x10(%rsp), %rdx
    29bc:      	movl	$0x2, %eax
    29c1:      	jmp	0x2ed4 <generic_tracepoint_event+0x2ed4>
    29c6:      	leaq	0x8(%rsp), %rdi
    29cb:      	movl	$0x4, %ecx
    29d0:      	movl	$0x4, %eax
    29d5:      	movl	$0x4, %esi
    29da:      	callq	*%rax
    29dc:      	testq	%rax, %rax
    29df:      	je	0x2dc6 <generic_tracepoint_event+0x2dc6>
    29e5:      	negl	%eax
    29e7:      	movw	%ax, 0x20(%rsp)
    29ec:      	movw	$0x7, 0x22(%rsp)
    29f3:      	movabsq	$0x400000056, %rax      # imm = 0x400000056
    29fd:      	movq	%rax, 0x24(%rsp)
    2a02:      	movq	(%rip), %rdi            # 0x2a09 <generic_tracepoint_event+0x2a09>
    2a09:      	leaq	0x20(%rsp), %rsi
    2a0e:      	movl	$0x1, %eax
    2a13:      	callq	*%rax
    2a15:      	testq	%rax, %rax
    2a18:      	je	0x2da2 <generic_tracepoint_event+0x2da2>
    2a1e:      	incl	(%rax)
    2a20:      	movslq	0x8(%rsp), %r15
    2a25:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2a2a:      	movl	$0x1, 0x8(%rsp)
    2a32:      	movq	(%rip), %rdi            # 0x2a39 <generic_tracepoint_event+0x2a39>
    2a39:      	xorl	%ecx, %ecx
    2a3b:      	leaq	0x20(%rsp), %rsi
    2a40:      	leaq	0x8(%rsp), %rdx
    2a45:      	movl	$0x2, %eax
    2a4a:      	xorl	%ecx, %ecx
    2a4c:      	callq	*%rax
    2a4e:      	movq	0x10(%rsp), %r15
    2a53:      	cmpl	$0x1c, %r12d
    2a57:      	jne	0x2edd <generic_tracepoint_event+0x2edd>
    2a5d:      	movl	$0x23, %eax
    2a62:      	callq	*%rax
    2a64:      	leaq	0x10(%rax), %rdx
    2a68:      	leaq	0x20(%rsp), %rdi
    2a6d:      	movl	$0x4, %ecx
    2a72:      	movl	$0x4, %eax
    2a77:      	movl	$0x4, %esi
    2a7c:      	callq	*%rax
    2a7e:      	movl	0x20(%rsp), %eax
    2a82:      	andl	$-0x2, %eax
    2a85:      	shll	$0x1e, %eax
    2a88:      	orq	%rax, %r15
    2a8b:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2a90:      	cmpl	$0x7, %r12d
    2a94:      	jne	0x2edd <generic_tracepoint_event+0x2edd>
    2a9a:      	leaq	0x10(%rsp), %rdi
    2a9f:      	movl	$0x8, %ecx
    2aa4:      	movl	$0x4, %eax
    2aa9:      	movl	$0x8, %esi
    2aae:      	callq	*%rax
    2ab0:      	testq	%rax, %rax
    2ab3:      	je	0x2e81 <generic_tracepoint_event+0x2e81>
    2ab9:      	negl	%eax
    2abb:      	movw	%ax, 0x20(%rsp)
    2ac0:      	movw	$0x7, 0x22(%rsp)
    2ac7:      	movabsq	$0x40000009a, %rax      # imm = 0x40000009A
    2ad1:      	movq	%rax, 0x24(%rsp)
    2ad6:      	movq	(%rip), %rdi            # 0x2add <generic_tracepoint_event+0x2add>
    2add:      	leaq	0x20(%rsp), %rsi
    2ae2:      	movl	$0x1, %eax
    2ae7:      	callq	*%rax
    2ae9:      	testq	%rax, %rax
    2aec:      	jne	0x2cd2 <generic_tracepoint_event+0x2cd2>
    2af2:      	movl	$0x1, 0x8(%rsp)
    2afa:      	movq	(%rip), %rdi            # 0x2b01 <generic_tracepoint_event+0x2b01>
    2b01:      	xorl	%ecx, %ecx
    2b03:      	leaq	0x20(%rsp), %rsi
    2b08:      	leaq	0x8(%rsp), %rdx
    2b0d:      	movl	$0x2, %eax
    2b12:      	jmp	0x2e7d <generic_tracepoint_event+0x2e7d>
    2b17:      	movq	%rdx, %r15
    2b1a:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2b1f:      	leaq	0x10(%rsp), %rdi
    2b24:      	movl	$0x8, %ecx
    2b29:      	movl	$0x4, %eax
    2b2e:      	movl	$0x8, %esi
    2b33:      	callq	*%rax
    2b35:      	testq	%rax, %rax
    2b38:      	je	0x2e81 <generic_tracepoint_event+0x2e81>
    2b3e:      	negl	%eax
    2b40:      	movw	%ax, 0x20(%rsp)
    2b45:      	movw	$0x7, 0x22(%rsp)
    2b4c:      	movabsq	$0x400000093, %rax      # imm = 0x400000093
    2b56:      	movq	%rax, 0x24(%rsp)
    2b5b:      	movq	(%rip), %rdi            # 0x2b62 <generic_tracepoint_event+0x2b62>
    2b62:      	leaq	0x20(%rsp), %rsi
    2b67:      	movl	$0x1, %eax
    2b6c:      	callq	*%rax
    2b6e:      	testq	%rax, %rax
    2b71:      	jne	0x2cd2 <generic_tracepoint_event+0x2cd2>
    2b77:      	movl	$0x1, 0x8(%rsp)
    2b7f:      	movq	(%rip), %rdi            # 0x2b86 <generic_tracepoint_event+0x2b86>
    2b86:      	xorl	%ecx, %ecx
    2b88:      	leaq	0x20(%rsp), %rsi
    2b8d:      	leaq	0x8(%rsp), %rdx
    2b92:      	movl	$0x2, %eax
    2b97:      	jmp	0x2e7d <generic_tracepoint_event+0x2e7d>
    2b9c:      	leaq	0x8(%rsp), %rdi
    2ba1:      	movl	$0x1, %ecx
    2ba6:      	movl	$0x4, %eax
    2bab:      	movl	$0x1, %esi
    2bb0:      	callq	*%rax
    2bb2:      	testq	%rax, %rax
    2bb5:      	je	0x2e23 <generic_tracepoint_event+0x2e23>
    2bbb:      	negl	%eax
    2bbd:      	movw	%ax, 0x20(%rsp)
    2bc2:      	movw	$0x7, 0x22(%rsp)
    2bc9:      	movabsq	$0x40000007a, %rax      # imm = 0x40000007A
    2bd3:      	movq	%rax, 0x24(%rsp)
    2bd8:      	movq	(%rip), %rdi            # 0x2bdf <generic_tracepoint_event+0x2bdf>
    2bdf:      	leaq	0x20(%rsp), %rsi
    2be4:      	movl	$0x1, %eax
    2be9:      	callq	*%rax
    2beb:      	testq	%rax, %rax
    2bee:      	je	0x2dff <generic_tracepoint_event+0x2dff>
    2bf4:      	incl	(%rax)
    2bf6:      	movsbq	0x8(%rsp), %r15
    2bfc:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2c01:      	leaq	0x10(%rsp), %rdi
    2c06:      	movl	$0x8, %ecx
    2c0b:      	movl	$0x4, %eax
    2c10:      	movl	$0x8, %esi
    2c15:      	callq	*%rax
    2c17:      	testq	%rax, %rax
    2c1a:      	je	0x2e81 <generic_tracepoint_event+0x2e81>
    2c20:      	negl	%eax
    2c22:      	movw	%ax, 0x20(%rsp)
    2c27:      	movw	$0x7, 0x22(%rsp)
    2c2e:      	movabsq	$0x4000000a1, %rax      # imm = 0x4000000A1
    2c38:      	movq	%rax, 0x24(%rsp)
    2c3d:      	movq	(%rip), %rdi            # 0x2c44 <generic_tracepoint_event+0x2c44>
    2c44:      	leaq	0x20(%rsp), %rsi
    2c49:      	movl	$0x1, %eax
    2c4e:      	callq	*%rax
    2c50:      	testq	%rax, %rax
    2c53:      	jne	0x2cd2 <generic_tracepoint_event+0x2cd2>
    2c55:      	movl	$0x1, 0x8(%rsp)
    2c5d:      	movq	(%rip), %rdi            # 0x2c64 <generic_tracepoint_event+0x2c64>
    2c64:      	xorl	%ecx, %ecx
    2c66:      	leaq	0x20(%rsp), %rsi
    2c6b:      	leaq	0x8(%rsp), %rdx
    2c70:      	movl	$0x2, %eax
    2c75:      	jmp	0x2e7d <generic_tracepoint_event+0x2e7d>
    2c7a:      	leaq	0x10(%rsp), %rdi
    2c7f:      	movl	$0x8, %ecx
    2c84:      	movl	$0x4, %eax
    2c89:      	movl	$0x8, %esi
    2c8e:      	callq	*%rax
    2c90:      	testq	%rax, %rax
    2c93:      	je	0x2e81 <generic_tracepoint_event+0x2e81>
    2c99:      	negl	%eax
    2c9b:      	movw	%ax, 0x20(%rsp)
    2ca0:      	movw	$0x7, 0x22(%rsp)
    2ca7:      	movabsq	$0x40000004e, %rax      # imm = 0x40000004E
    2cb1:      	movq	%rax, 0x24(%rsp)
    2cb6:      	movq	(%rip), %rdi            # 0x2cbd <generic_tracepoint_event+0x2cbd>
    2cbd:      	leaq	0x20(%rsp), %rsi
    2cc2:      	movl	$0x1, %eax
    2cc7:      	callq	*%rax
    2cc9:      	testq	%rax, %rax
    2ccc:      	je	0x2e5d <generic_tracepoint_event+0x2e5d>
    2cd2:      	incl	(%rax)
    2cd4:      	jmp	0x2e81 <generic_tracepoint_event+0x2e81>
    2cd9:      	leaq	0x8(%rsp), %rdi
    2cde:      	movl	$0x2, %ecx
    2ce3:      	movl	$0x4, %eax
    2ce8:      	movl	$0x2, %esi
    2ced:      	callq	*%rax
    2cef:      	testq	%rax, %rax
    2cf2:      	je	0x2eac <generic_tracepoint_event+0x2eac>
    2cf8:      	negl	%eax
    2cfa:      	movw	%ax, 0x20(%rsp)
    2cff:      	movw	$0x7, 0x22(%rsp)
    2d06:      	movabsq	$0x400000065, %rax      # imm = 0x400000065
    2d10:      	movq	%rax, 0x24(%rsp)
    2d15:      	movq	(%rip), %rdi            # 0x2d1c <generic_tracepoint_event+0x2d1c>
    2d1c:      	leaq	0x20(%rsp), %rsi
    2d21:      	movl	$0x1, %eax
    2d26:      	callq	*%rax
    2d28:      	testq	%rax, %rax
    2d2b:      	je	0x2e88 <generic_tracepoint_event+0x2e88>
    2d31:      	incl	(%rax)
    2d33:      	movzwl	0x8(%rsp), %r15d
    2d39:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2d3e:      	leaq	0x8(%rsp), %rdi
    2d43:      	movl	$0x4, %ecx
    2d48:      	movl	$0x4, %eax
    2d4d:      	movl	$0x4, %esi
    2d52:      	callq	*%rax
    2d54:      	testq	%rax, %rax
    2d57:      	je	0x2ed8 <generic_tracepoint_event+0x2ed8>
    2d5d:      	negl	%eax
    2d5f:      	movw	%ax, 0x20(%rsp)
    2d64:      	movw	$0x7, 0x22(%rsp)
    2d6b:      	movabsq	$0x400000088, %rax      # imm = 0x400000088
    2d75:      	movq	%rax, 0x24(%rsp)
    2d7a:      	movq	(%rip), %rdi            # 0x2d81 <generic_tracepoint_event+0x2d81>
    2d81:      	leaq	0x20(%rsp), %rsi
    2d86:      	movl	$0x1, %eax
    2d8b:      	callq	*%rax
    2d8d:      	testq	%rax, %rax
    2d90:      	je	0x2eb4 <generic_tracepoint_event+0x2eb4>
    2d96:      	incl	(%rax)
    2d98:      	movl	0x8(%rsp), %r15d
    2d9d:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2da2:      	movl	$0x1, 0x10(%rsp)
    2daa:      	movq	(%rip), %rdi            # 0x2db1 <generic_tracepoint_event+0x2db1>
    2db1:      	xorl	%ecx, %ecx
    2db3:      	leaq	0x20(%rsp), %rsi
    2db8:      	leaq	0x10(%rsp), %rdx
    2dbd:      	movl	$0x2, %eax
    2dc2:      	xorl	%ecx, %ecx
    2dc4:      	callq	*%rax
    2dc6:      	movslq	0x8(%rsp), %r15
    2dcb:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2dd0:      	movl	$0x1, 0x10(%rsp)
    2dd8:      	movq	(%rip), %rdi            # 0x2ddf <generic_tracepoint_event+0x2ddf>
    2ddf:      	xorl	%ecx, %ecx
    2de1:      	leaq	0x20(%rsp), %rsi
    2de6:      	leaq	0x10(%rsp), %rdx
    2deb:      	movl	$0x2, %eax
    2df0:      	xorl	%ecx, %ecx
    2df2:      	callq	*%rax
    2df4:      	movswq	0x8(%rsp), %r15
    2dfa:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2dff:      	movl	$0x1, 0x10(%rsp)
    2e07:      	movq	(%rip), %rdi            # 0x2e0e <generic_tracepoint_event+0x2e0e>
    2e0e:      	xorl	%ecx, %ecx
    2e10:      	leaq	0x20(%rsp), %rsi
    2e15:      	leaq	0x10(%rsp), %rdx
    2e1a:      	movl	$0x2, %eax
    2e1f:      	xorl	%ecx, %ecx
    2e21:      	callq	*%rax
    2e23:      	movsbq	0x8(%rsp), %r15
    2e29:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2e2e:      	movl	$0x1, 0x10(%rsp)
    2e36:      	movq	(%rip), %rdi            # 0x2e3d <generic_tracepoint_event+0x2e3d>
    2e3d:      	xorl	%ecx, %ecx
    2e3f:      	leaq	0x20(%rsp), %rsi
    2e44:      	leaq	0x10(%rsp), %rdx
    2e49:      	movl	$0x2, %eax
    2e4e:      	xorl	%ecx, %ecx
    2e50:      	callq	*%rax
    2e52:      	movzbl	0x8(%rsp), %r15d
    2e58:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2e5d:      	movl	$0x1, 0x8(%rsp)
    2e65:      	movq	(%rip), %rdi            # 0x2e6c <generic_tracepoint_event+0x2e6c>
    2e6c:      	xorl	%ecx, %ecx
    2e6e:      	leaq	0x20(%rsp), %rsi
    2e73:      	leaq	0x8(%rsp), %rdx
    2e78:      	movl	$0x2, %eax
    2e7d:      	xorl	%ecx, %ecx
    2e7f:      	callq	*%rax
    2e81:      	movq	0x10(%rsp), %r15
    2e86:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2e88:      	movl	$0x1, 0x10(%rsp)
    2e90:      	movq	(%rip), %rdi            # 0x2e97 <generic_tracepoint_event+0x2e97>
    2e97:      	xorl	%ecx, %ecx
    2e99:      	leaq	0x20(%rsp), %rsi
    2e9e:      	leaq	0x10(%rsp), %rdx
    2ea3:      	movl	$0x2, %eax
    2ea8:      	xorl	%ecx, %ecx
    2eaa:      	callq	*%rax
    2eac:      	movzwl	0x8(%rsp), %r15d
    2eb2:      	jmp	0x2edd <generic_tracepoint_event+0x2edd>
    2eb4:      	movl	$0x1, 0x10(%rsp)
    2ebc:      	movq	(%rip), %rdi            # 0x2ec3 <generic_tracepoint_event+0x2ec3>
    2ec3:      	xorl	%ecx, %ecx
    2ec5:      	leaq	0x20(%rsp), %rsi
    2eca:      	leaq	0x10(%rsp), %rdx
    2ecf:      	movl	$0x2, %eax
    2ed4:      	xorl	%ecx, %ecx
    2ed6:      	callq	*%rax
    2ed8:      	movl	0x8(%rsp), %r15d
    2edd:      	movq	%r15, 0x5e70(%r14)
    2ee4:      	movb	$0xe, (%r14)
    2ee8:      	movw	$0x0, 0x2(%r14)
    2eef:      	movl	$0x0, 0x4(%r14)
    2ef7:      	movl	$0x7d, %eax
    2efc:      	callq	*%rax
    2efe:      	movq	%rax, 0x8(%r14)
    2f02:      	movq	$0x0, 0x70(%r14)
    2f0a:      	movl	$0x0, 0x14(%r14)
    2f12:      	movl	$0xe, %eax
    2f17:      	callq	*%rax
    2f19:      	movl	%eax, 0x7c(%r14)
    2f1d:      	movb	$0xe, (%r14)
    2f21:      	movq	$0x0, 0x5efc(%r14)
    2f2c:      	movq	$0x0, 0x5eb8(%r14)
    2f37:      	movq	$0x0, 0x5ec0(%r14)
    2f42:      	movq	$0x0, 0x5ec8(%r14)
    2f4d:      	movq	$0x0, 0x5ed0(%r14)
    2f58:      	movq	$0x0, 0x5ed8(%r14)
    2f63:      	movb	$0x0, 0x5ee0(%r14)
    2f6b:      	movl	$0x23, %eax
    2f70:      	callq	*%rax
    2f72:      	movq	%rax, %r15
    2f75:      	leaq	0xd70(%rax), %rdx
    2f7c:      	leaq	0x8(%rsp), %rdi
    2f81:      	movl	$0x8, %ecx
    2f86:      	movl	$0x4, %eax
    2f8b:      	leaq	0x20(%r14), %r12
    2f8f:      	movl	$0x4, %r13d
    2f95:      	movl	$0x8, %esi
    2f9a:      	callq	*%rax
    2f9c:      	movq	0x8(%rsp), %rcx
    2fa1:      	leaq	0x20(%rsp), %rdi
    2fa6:      	movl	$0x48, %edx
    2fab:      	movl	$0x4, %eax
    2fb0:      	movq	0x8(%rsp), %rdx
    2fb5:      	movl	$0x48, %esi
    2fba:      	callq	*%rax
    2fbc:      	movl	$0x218, %edx            # imm = 0x218
    2fc1:      	movq	0x28(%rsp), %rcx
    2fc6:      	addq	%rdx, %rcx
    2fc9:      	movl	$0x4, %esi
    2fce:      	movl	$0x4, %eax
    2fd3:      	addq	0x28(%rsp), %rdx
    2fd8:      	movq	%r12, %rdi
    2fdb:      	movl	$0x4, %esi
    2fe0:      	callq	*%rax
    2fe2:      	leaq	0x24(%r14), %rdi
    2fe6:      	movl	$0x4d8, %edx            # imm = 0x4D8
    2feb:      	movq	0x30(%rsp), %rcx
    2ff0:      	addq	%rdx, %rcx
    2ff3:      	movl	$0x4, %esi
    2ff8:      	movl	$0x4, %eax
    2ffd:      	addq	0x30(%rsp), %rdx
    3002:      	movl	$0x4, %esi
    3007:      	callq	*%rax
    3009:      	leaq	0x28(%r14), %rdi
    300d:      	movq	0x38(%rsp), %rcx
    3012:      	addq	$0x58, %rcx
    3016:      	movl	$0x4, %edx
    301b:      	movl	$0x4, %eax
    3020:      	movq	0x38(%rsp), %rdx
    3025:      	addq	$0x58, %rdx
    3029:      	movl	$0x4, %esi
    302e:      	callq	*%rax
    3030:      	movq	$0x0, 0x68(%rsp)
    3039:      	leaq	0xb58(%r15), %rdx
    3040:      	leaq	0x68(%rsp), %rdi
    3045:      	movl	$0x8, %ecx
    304a:      	movl	$0x4, %eax
    304f:      	movl	$0x8, %esi
    3054:      	callq	*%rax
    3056:      	movq	0x68(%rsp), %rcx
    305b:      	testq	%rcx, %rcx
    305e:      	je	0x30f4 <generic_tracepoint_event+0x30f4>
    3064:      	movl	$0x0, 0x70(%rsp)
    306c:      	addq	$0x4, %rcx
    3070:      	leaq	0x70(%rsp), %rdi
    3075:      	movl	$0x4, %eax
    307a:      	movq	0x68(%rsp), %rdx
    307f:      	addq	$0x4, %rdx
    3083:      	movl	$0x4, %esi
    3088:      	callq	*%rax
    308a:      	movq	0x68(%rsp), %rax
    308f:      	movslq	0x70(%rsp), %rcx
    3094:      	shlq	$0x4, %rcx
    3098:      	addq	%rax, %rcx
    309b:      	addq	$0x80, %rcx
    30a2:      	leaq	0x10(%rsp), %rdi
    30a7:      	movl	$0x10, %edx
    30ac:      	movl	$0x4, %eax
    30b1:      	movq	0x68(%rsp), %rcx
    30b6:      	movslq	0x70(%rsp), %rdx
    30bb:      	shlq	$0x4, %rdx
    30bf:      	addq	%rcx, %rdx
    30c2:      	addq	$0x80, %rdx
    30c9:      	movl	$0x10, %esi
    30ce:      	callq	*%rax
    30d0:      	leaq	0x2c(%r14), %rdi
    30d4:      	movl	$0x158, %edx            # imm = 0x158
    30d9:      	movq	0x18(%rsp), %rcx
    30de:      	addq	%rdx, %rcx
    30e1:      	movl	$0x4, %eax
    30e6:      	addq	0x18(%rsp), %rdx
    30eb:      	movl	$0x4, %esi
    30f0:      	callq	*%rax
    30f2:      	jmp	0x30fc <generic_tracepoint_event+0x30fc>
    30f4:      	movl	$0x0, 0x2c(%r14)
    30fc:      	leaq	0x30(%r14), %rdi
    3100:      	movl	$0x158, %r12d           # imm = 0x158
    3106:      	movq	0x40(%rsp), %rcx
    310b:      	addq	%r12, %rcx
    310e:      	movl	$0x4, %edx
    3113:      	movl	$0x4, %eax
    3118:      	movq	0x40(%rsp), %rdx
    311d:      	addq	%r12, %rdx
    3120:      	movl	$0x4, %esi
    3125:      	callq	*%rax
    3127:      	leaq	0x34(%r14), %rdi
    312b:      	movl	$0x118, %edx            # imm = 0x118
    3130:      	movq	0x48(%rsp), %rcx
    3135:      	addq	%rdx, %rcx
    3138:      	movl	$0x4, %esi
    313d:      	movl	$0x4, %eax
    3142:      	addq	0x48(%rsp), %rdx
    3147:      	movl	$0x4, %esi
    314c:      	callq	*%rax
    314e:      	leaq	0x38(%r14), %rdi
    3152:      	movl	$0x98, %r13d
    3158:      	movq	0x50(%rsp), %rcx
    315d:      	addq	%r13, %rcx
    3160:      	movl	$0x4, %edx
    3165:      	movl	$0x4, %eax
    316a:      	movq	0x50(%rsp), %rdx
    316f:      	addq	%r13, %rdx
    3172:      	movl	$0x4, %esi
    3177:      	callq	*%rax
    3179:      	leaq	0x3c(%r14), %rdi
    317d:      	movq	0x58(%rsp), %rcx
    3182:      	addq	%r13, %rcx
    3185:      	movl	$0x4, %edx
    318a:      	movl	$0x4, %eax
    318f:      	addq	0x58(%rsp), %r13
    3194:      	movl	$0x4, %esi
    3199:      	movq	%r13, %rdx
    319c:      	callq	*%rax
    319e:      	leaq	0x40(%r14), %rdi
    31a2:      	movq	0x60(%rsp), %rcx
    31a7:      	addq	$0x58, %rcx
    31ab:      	movl	$0x4, %edx
    31b0:      	movl	$0x4, %eax
    31b5:      	movq	0x60(%rsp), %rdx
    31ba:      	addq	$0x58, %rdx
    31be:      	movl	$0x4, %esi
    31c3:      	callq	*%rax
    31c5:      	movq	$0x0, 0x10(%rsp)
    31ce:      	movq	$0x0, 0x68(%rsp)
    31d7:      	addq	$0xd00, %r15            # imm = 0xD00
    31de:      	leaq	0x10(%rsp), %rdi
    31e3:      	movl	$0x8, %ecx
    31e8:      	movl	$0x4, %eax
    31ed:      	movl	$0x8, %esi
    31f2:      	movq	%r15, %rdx
    31f5:      	callq	*%rax
    31f7:      	movl	$0x90, %edx
    31fc:      	movq	0x10(%rsp), %rcx
    3201:      	addq	%rdx, %rcx
    3204:      	leaq	0x68(%rsp), %rdi
    3209:      	movl	$0x8, %esi
    320e:      	movl	$0x4, %eax
    3213:      	addq	0x10(%rsp), %rdx
    3218:      	movl	$0x8, %esi
    321d:      	callq	*%rax
    321f:      	leaq	0x44(%r14), %rdi
    3223:      	movq	0x68(%rsp), %rcx
    3228:      	addq	%r12, %rcx
    322b:      	movl	$0x4, %edx
    3230:      	movl	$0x4, %eax
    3235:      	addq	0x68(%rsp), %r12
    323a:      	movl	$0x4, %esi
    323f:      	movq	%r12, %rdx
    3242:      	callq	*%rax
    3244:      	leaq	0x48(%r14), %r12
    3248:      	leaq	0x20(%rsp), %rdi
    324d:      	movl	$0x8, %ecx
    3252:      	movl	$0x4, %eax
    3257:      	movl	$0x8, %esi
    325c:      	movq	%r15, %rdx
    325f:      	callq	*%rax
    3261:      	movq	0x20(%rsp), %r15
    3266:      	leaq	0x50(%r14), %rdi
    326a:      	leaq	0x40(%r15), %rdx
    326e:      	movl	$0x8, %ecx
    3273:      	movl	$0x4, %eax
    3278:      	movl	$0x8, %esi
    327d:      	callq	*%rax
    327f:      	movq	%r14, %rdi
    3282:      	addq	$0x58, %rdi
    3286:      	leaq	0x30(%r15), %rdx
    328a:      	movl	$0x8, %ecx
    328f:      	movl	$0x4, %eax
    3294:      	movl	$0x8, %esi
    3299:      	callq	*%rax
    329b:      	addq	$0x38, %r15
    329f:      	movl	$0x8, %ecx
    32a4:      	movl	$0x4, %eax
    32a9:      	movq	%r12, %rdi
    32ac:      	movl	$0x8, %esi
    32b1:      	movq	%r15, %rdx
    32b4:      	callq	*%rax
    32b6:      	movb	$0x0, 0x1(%r14)
    32bb:      	movq	$0x0, 0x5ee8(%r14)
    32c6:      	movq	$0x0, 0x5ef0(%r14)
    32d1:      	movq	(%rip), %rsi            # 0x32d8 <generic_tracepoint_event+0x32d8>
    32d8:      	movl	$0x2, %ecx
    32dd:      	movl	$0xc, %eax
    32e2:      	movq	%rbx, %rdi
    32e5:      	movl	$0x2, %edx
    32ea:      	callq	*%rax
    32ec:      	xorl	%eax, %eax
    32ee:      	addq	$0x88, %rsp
    32f5:      	popq	%rbx
    32f6:      	popq	%r12
    32f8:      	popq	%r13
    32fa:      	popq	%r14
    32fc:      	popq	%r15
    32fe:      	popq	%rbp
    32ff:      	retq
