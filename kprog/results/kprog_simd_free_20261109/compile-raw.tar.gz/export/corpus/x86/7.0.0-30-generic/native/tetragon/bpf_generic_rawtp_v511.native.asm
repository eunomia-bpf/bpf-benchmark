
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_generic_rawtp_v511.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
       5:      	testq	%rdx, %rdx
       8:      	je	0x74 <native_bpf_strncasestr+0x74>
       a:      	pushq	%rbx
       b:      	xorl	%ecx, %ecx
       d:      	jmp	0x1b <native_bpf_strncasestr+0x1b>
       f:      	nop
      10:      	incq	%rcx
      13:      	incq	%rdi
      16:      	cmpq	%rdx, %rcx
      19:      	je	0x73 <native_bpf_strncasestr+0x73>
      1b:      	xorl	%r8d, %r8d
      1e:      	nop
      20:      	leaq	(%rcx,%r8), %r9
      24:      	cmpq	%rdx, %r9
      27:      	jae	0x10 <native_bpf_strncasestr+0x10>
      29:      	movsbl	(%rsi,%r8), %r9d
      2e:      	testl	%r9d, %r9d
      31:      	je	0x71 <native_bpf_strncasestr+0x71>
      33:      	movsbl	(%rdi,%r8), %r10d
      38:      	leal	-0x41(%r10), %r11d
      3c:      	movl	%r10d, %ebx
      3f:      	orl	$0x20, %ebx
      42:      	cmpl	$0x1a, %r11d
      46:      	cmovael	%r10d, %ebx
      4a:      	leal	-0x41(%r9), %r10d
      4e:      	movl	%r9d, %r11d
      51:      	orl	$0x20, %r11d
      55:      	cmpl	$0x1a, %r10d
      59:      	cmovael	%r9d, %r11d
      5d:      	cmpl	%r11d, %ebx
      60:      	jne	0x10 <native_bpf_strncasestr+0x10>
      62:      	leaq	0x1(%r8), %r9
      66:      	cmpq	$0x63, %r8
      6a:      	movq	%r9, %r8
      6d:      	jb	0x20 <native_bpf_strncasestr+0x20>
      6f:      	jmp	0x10 <native_bpf_strncasestr+0x10>
      71:      	movl	%ecx, %eax
      73:      	popq	%rbx
      74:      	retq

Disassembly of section raw_tp:

0000000000000000 <generic_rawtp_setup_event>:
       0:      	pushq	%r14
       2:      	pushq	%rbx
       3:      	subq	$0x18, %rsp
       7:      	movq	%rdi, %rbx
       a:      	movl	$0x0, 0x14(%rsp)
      12:      	movq	(%rip), %rdi            # 0x19 <generic_rawtp_setup_event+0x19>
      19:      	leaq	0x14(%rsp), %rsi
      1e:      	movl	$0x1, %eax
      23:      	callq	*%rax
      25:      	testq	%rax, %rax
      28:      	je	0x1be <generic_rawtp_setup_event+0x1be>
      2e:      	movq	%rax, %r14
      31:      	leaq	0x5ef8(%rax), %rsi
      38:      	movq	(%rip), %rdi            # 0x3f <generic_rawtp_setup_event+0x3f>
      3f:      	movl	$0x1, %eax
      44:      	callq	*%rax
      46:      	testq	%rax, %rax
      49:      	je	0x1be <generic_rawtp_setup_event+0x1be>
      4f:      	leaq	0x8(%rsp), %rdi
      54:      	movl	$0x8, %ecx
      59:      	movl	$0x4, %eax
      5e:      	movl	$0x8, %esi
      63:      	movq	%rbx, %rdx
      66:      	callq	*%rax
      68:      	movq	0x8(%rsp), %rax
      6d:      	movq	%rax, 0x5e50(%r14)
      74:      	leaq	0x8(%rbx), %rdx
      78:      	leaq	0x8(%rsp), %rdi
      7d:      	movl	$0x8, %ecx
      82:      	movl	$0x4, %eax
      87:      	movl	$0x8, %esi
      8c:      	callq	*%rax
      8e:      	movq	0x8(%rsp), %rax
      93:      	movq	%rax, 0x5e58(%r14)
      9a:      	leaq	0x10(%rbx), %rdx
      9e:      	leaq	0x8(%rsp), %rdi
      a3:      	movl	$0x8, %ecx
      a8:      	movl	$0x4, %eax
      ad:      	movl	$0x8, %esi
      b2:      	callq	*%rax
      b4:      	movq	0x8(%rsp), %rax
      b9:      	movq	%rax, 0x5e60(%r14)
      c0:      	leaq	0x18(%rbx), %rdx
      c4:      	leaq	0x8(%rsp), %rdi
      c9:      	movl	$0x8, %ecx
      ce:      	movl	$0x4, %eax
      d3:      	movl	$0x8, %esi
      d8:      	callq	*%rax
      da:      	movq	0x8(%rsp), %rax
      df:      	movq	%rax, 0x5e68(%r14)
      e6:      	leaq	0x20(%rbx), %rdx
      ea:      	leaq	0x8(%rsp), %rdi
      ef:      	movl	$0x8, %ecx
      f4:      	movl	$0x4, %eax
      f9:      	movl	$0x8, %esi
      fe:      	callq	*%rax
     100:      	movq	0x8(%rsp), %rax
     105:      	movq	%rax, 0x5e70(%r14)
     10c:      	movb	$0xe, (%r14)
     110:      	movw	$0x0, 0x2(%r14)
     117:      	movl	$0x0, 0x4(%r14)
     11f:      	movl	$0x7d, %eax
     124:      	callq	*%rax
     126:      	movq	%rax, 0x8(%r14)
     12a:      	movq	$0x0, 0x70(%r14)
     132:      	movl	$0x0, 0x14(%r14)
     13a:      	movl	$0xe, %eax
     13f:      	callq	*%rax
     141:      	movl	%eax, 0x7c(%r14)
     145:      	movl	$0x0, 0x8(%rsp)
     14d:      	movq	(%rip), %rdi            # 0x154 <generic_rawtp_setup_event+0x154>
     154:      	leaq	0x8(%rsp), %rsi
     159:      	movl	$0x1, %eax
     15e:      	callq	*%rax
     160:      	testq	%rax, %rax
     163:      	je	0x188 <generic_rawtp_setup_event+0x188>
     165:      	movq	%rax, %rsi
     168:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     16f:      	movq	(%rip), %rdi            # 0x176 <generic_rawtp_setup_event+0x176>
     176:      	movl	$0x1, %eax
     17b:      	callq	*%rax
     17d:      	testq	%rax, %rax
     180:      	je	0x188 <generic_rawtp_setup_event+0x188>
     182:      	cmpl	$-0x1, 0x40(%rax)
     186:      	jne	0x1a3 <generic_rawtp_setup_event+0x1a3>
     188:      	movq	(%rip), %rsi            # 0x18f <generic_rawtp_setup_event+0x18f>
     18f:      	movl	$0x3, %ecx
     194:      	movl	$0xc, %eax
     199:      	movq	%rbx, %rdi
     19c:      	movl	$0x3, %edx
     1a1:      	callq	*%rax
     1a3:      	movq	(%rip), %rsi            # 0x1aa <generic_rawtp_setup_event+0x1aa>
     1aa:      	movl	$0x1, %ecx
     1af:      	movl	$0xc, %eax
     1b4:      	movq	%rbx, %rdi
     1b7:      	movl	$0x1, %edx
     1bc:      	callq	*%rax
     1be:      	xorl	%eax, %eax
     1c0:      	addq	$0x18, %rsp
     1c4:      	popq	%rbx
     1c5:      	popq	%r14
     1c7:      	retq
     1c8:      	nopl	(%rax,%rax)

00000000000001d0 <generic_rawtp_process_event>:
     1d0:      	pushq	%rbp
     1d1:      	pushq	%r15
     1d3:      	pushq	%r14
     1d5:      	pushq	%r13
     1d7:      	pushq	%r12
     1d9:      	pushq	%rbx
     1da:      	subq	$0x108, %rsp            # imm = 0x108
     1e1:      	movq	%rdi, %rbx
     1e4:      	movl	$0x0, 0xf4(%rsp)
     1ef:      	movq	(%rip), %rdi            # 0x1f6 <generic_rawtp_process_event+0x26>
     1f6:      	leaq	0xf4(%rsp), %rsi
     1fe:      	movl	$0x1, %eax
     203:      	callq	*%rax
     205:      	testq	%rax, %rax
     208:      	je	0xe5f <generic_rawtp_process_event+0xc8f>
     20e:      	movq	%rax, %r14
     211:      	movl	0x5efc(%rax), %r12d
     218:      	movl	0x4(%rax), %ebp
     21b:      	cmpq	$0x2327, %rbp           # imm = 0x2327
     222:      	ja	0xdc0 <generic_rawtp_process_event+0xbf0>
     228:      	movl	$0x0, 0xf8(%rsp)
     233:      	movq	(%rip), %rdi            # 0x23a <generic_rawtp_process_event+0x6a>
     23a:      	leaq	0xf8(%rsp), %rsi
     242:      	movl	$0x1, %eax
     247:      	callq	*%rax
     249:      	testq	%rax, %rax
     24c:      	je	0xdc0 <generic_rawtp_process_event+0xbf0>
     252:      	movq	%rax, %r15
     255:      	leaq	0x5ef8(%rax), %rsi
     25c:      	movq	(%rip), %rdi            # 0x263 <generic_rawtp_process_event+0x93>
     263:      	movl	$0x1, %eax
     268:      	callq	*%rax
     26a:      	cmpl	$0x4, %r12d
     26e:      	jg	0xdc0 <generic_rawtp_process_event+0xbf0>
     274:      	testq	%rax, %rax
     277:      	je	0xdc0 <generic_rawtp_process_event+0xbf0>
     27d:      	movq	%r12, 0x100(%rsp)
     285:      	movl	%r12d, %edx
     288:      	andl	$0x7, %edx
     28b:      	movl	%edx, %ecx
     28d:      	movl	0x4(%rax,%rcx,4), %r13d
     292:      	movslq	0x18(%rax,%rcx,4), %r12
     297:      	movl	%r12d, %esi
     29a:      	movl	$0x0, 0x5ea0(%r15,%rcx,4)
     2a6:      	testl	$0x100, %r12d           # imm = 0x100
     2ad:      	movq	%rbp, 0xc8(%rsp)
     2b5:      	movq	%rdx, 0x20(%rsp)
     2ba:      	jne	0x2d8 <generic_rawtp_process_event+0x108>
     2bc:      	testb	%r12b, %r12b
     2bf:      	js	0x2e6 <generic_rawtp_process_event+0x116>
     2c1:      	testb	$0x40, %sil
     2c5:      	jne	0x2f3 <generic_rawtp_process_event+0x123>
     2c7:      	movl	0x40(%rax,%rdx,4), %ecx
     2cb:      	andl	$0x7, %ecx
     2ce:      	movq	0x5e50(%r15,%rcx,8), %rcx
     2d6:      	jmp	0x324 <generic_rawtp_process_event+0x154>
     2d8:      	movq	$0x0, 0x8(%rsp)
     2e1:      	jmp	0x9e9 <generic_rawtp_process_event+0x819>
     2e6:      	movq	$0x0, 0x8(%rsp)
     2ef:      	xorl	%ecx, %ecx
     2f1:      	jmp	0x329 <generic_rawtp_process_event+0x159>
     2f3:      	movq	%rax, 0x10(%rsp)
     2f8:      	movl	$0x23, %eax
     2fd:      	movq	%r14, %rbp
     300:      	movq	%r13, %r14
     303:      	movq	%r12, %r13
     306:      	movq	%rsi, %r12
     309:      	callq	*%rax
     30b:      	movq	%r12, %rsi
     30e:      	movq	%r13, %r12
     311:      	movq	%r14, %r13
     314:      	movq	%rbp, %r14
     317:      	movq	0x20(%rsp), %rdx
     31c:      	movq	%rax, %rcx
     31f:      	movq	0x10(%rsp), %rax
     324:      	movq	%rcx, 0x8(%rsp)
     329:      	cmpl	$0x4, %edx
     32c:      	ja	0x9e9 <generic_rawtp_process_event+0x819>
     332:      	leaq	(%rdx,%rdx,4), %rdx
     336:      	shll	$0x4, %edx
     339:      	cmpw	$0x0, 0x76(%rax,%rdx)
     33f:      	je	0x9e9 <generic_rawtp_process_event+0x819>
     345:      	leaq	(%rax,%rdx), %rdi
     349:      	addq	$0x70, %rdi
     34d:      	movq	(%rip), %rax            # 0x354 <generic_rawtp_process_event+0x184>
     354:      	movzbl	(%rax), %edx
     357:      	movl	(%rdi), %eax
     359:      	addq	%rax, %rcx
     35c:      	movq	%rcx, 0x8(%rsp)
     361:      	movzwl	0x4(%rdi), %eax
     365:      	testb	%dl, %dl
     367:      	movq	%rdi, 0x10(%rsp)
     36c:      	je	0x6a2 <generic_rawtp_process_event+0x4d2>
     372:      	testw	%ax, %ax
     375:      	je	0x3af <generic_rawtp_process_event+0x1df>
     377:      	leaq	0x8(%rsp), %rdi
     37c:      	movl	$0x8, %edx
     381:      	movl	$0x4, %eax
     386:      	movq	0x8(%rsp), %rdx
     38b:      	movq	%rsi, %rbp
     38e:      	movl	$0x8, %esi
     393:      	callq	*%rax
     395:      	movq	0x10(%rsp), %rdi
     39a:      	movq	%rbp, %rsi
     39d:      	movq	0x20(%rsp), %rcx
     3a2:      	movl	$0x1, %ebp
     3a7:      	testl	%eax, %eax
     3a9:      	js	0x9e1 <generic_rawtp_process_event+0x811>
     3af:      	cmpw	$0x0, 0xe(%rdi)
     3b4:      	je	0x9e9 <generic_rawtp_process_event+0x819>
     3ba:      	movl	0x8(%rdi), %ecx
     3bd:      	addq	0x8(%rsp), %rcx
     3c2:      	movq	%rcx, 0x8(%rsp)
     3c7:      	cmpw	$0x0, 0xc(%rdi)
     3cc:      	je	0x406 <generic_rawtp_process_event+0x236>
     3ce:      	leaq	0x8(%rsp), %rdi
     3d3:      	movl	$0x8, %edx
     3d8:      	movl	$0x4, %eax
     3dd:      	movq	0x8(%rsp), %rdx
     3e2:      	movq	%rsi, %rbp
     3e5:      	movl	$0x8, %esi
     3ea:      	callq	*%rax
     3ec:      	movq	0x10(%rsp), %rdi
     3f1:      	movq	%rbp, %rsi
     3f4:      	movq	0x20(%rsp), %rcx
     3f9:      	movl	$0x2, %ebp
     3fe:      	testl	%eax, %eax
     400:      	js	0x9e1 <generic_rawtp_process_event+0x811>
     406:      	cmpw	$0x0, 0x16(%rdi)
     40b:      	je	0x9e9 <generic_rawtp_process_event+0x819>
     411:      	movl	0x10(%rdi), %ecx
     414:      	addq	0x8(%rsp), %rcx
     419:      	movq	%rcx, 0x8(%rsp)
     41e:      	cmpw	$0x0, 0x14(%rdi)
     423:      	je	0x45d <generic_rawtp_process_event+0x28d>
     425:      	leaq	0x8(%rsp), %rdi
     42a:      	movl	$0x8, %edx
     42f:      	movl	$0x4, %eax
     434:      	movq	0x8(%rsp), %rdx
     439:      	movq	%rsi, %rbp
     43c:      	movl	$0x8, %esi
     441:      	callq	*%rax
     443:      	movq	0x10(%rsp), %rdi
     448:      	movq	%rbp, %rsi
     44b:      	movq	0x20(%rsp), %rcx
     450:      	movl	$0x3, %ebp
     455:      	testl	%eax, %eax
     457:      	js	0x9e1 <generic_rawtp_process_event+0x811>
     45d:      	cmpw	$0x0, 0x1e(%rdi)
     462:      	je	0x9e9 <generic_rawtp_process_event+0x819>
     468:      	movl	0x18(%rdi), %ecx
     46b:      	addq	0x8(%rsp), %rcx
     470:      	movq	%rcx, 0x8(%rsp)
     475:      	cmpw	$0x0, 0x1c(%rdi)
     47a:      	je	0x4b4 <generic_rawtp_process_event+0x2e4>
     47c:      	leaq	0x8(%rsp), %rdi
     481:      	movl	$0x8, %edx
     486:      	movl	$0x4, %eax
     48b:      	movq	0x8(%rsp), %rdx
     490:      	movq	%rsi, %rbp
     493:      	movl	$0x8, %esi
     498:      	callq	*%rax
     49a:      	movq	0x10(%rsp), %rdi
     49f:      	movq	%rbp, %rsi
     4a2:      	movq	0x20(%rsp), %rcx
     4a7:      	movl	$0x4, %ebp
     4ac:      	testl	%eax, %eax
     4ae:      	js	0x9e1 <generic_rawtp_process_event+0x811>
     4b4:      	cmpw	$0x0, 0x26(%rdi)
     4b9:      	je	0x9e9 <generic_rawtp_process_event+0x819>
     4bf:      	movl	0x20(%rdi), %ecx
     4c2:      	addq	0x8(%rsp), %rcx
     4c7:      	movq	%rcx, 0x8(%rsp)
     4cc:      	cmpw	$0x0, 0x24(%rdi)
     4d1:      	je	0x50b <generic_rawtp_process_event+0x33b>
     4d3:      	leaq	0x8(%rsp), %rdi
     4d8:      	movl	$0x8, %edx
     4dd:      	movl	$0x4, %eax
     4e2:      	movq	0x8(%rsp), %rdx
     4e7:      	movq	%rsi, %rbp
     4ea:      	movl	$0x8, %esi
     4ef:      	callq	*%rax
     4f1:      	movq	0x10(%rsp), %rdi
     4f6:      	movq	%rbp, %rsi
     4f9:      	movq	0x20(%rsp), %rcx
     4fe:      	movl	$0x5, %ebp
     503:      	testl	%eax, %eax
     505:      	js	0x9e1 <generic_rawtp_process_event+0x811>
     50b:      	cmpw	$0x0, 0x2e(%rdi)
     510:      	je	0x9e9 <generic_rawtp_process_event+0x819>
     516:      	movl	0x28(%rdi), %ecx
     519:      	addq	0x8(%rsp), %rcx
     51e:      	movq	%rcx, 0x8(%rsp)
     523:      	cmpw	$0x0, 0x2c(%rdi)
     528:      	je	0x562 <generic_rawtp_process_event+0x392>
     52a:      	leaq	0x8(%rsp), %rdi
     52f:      	movl	$0x8, %edx
     534:      	movl	$0x4, %eax
     539:      	movq	0x8(%rsp), %rdx
     53e:      	movq	%rsi, %rbp
     541:      	movl	$0x8, %esi
     546:      	callq	*%rax
     548:      	movq	0x10(%rsp), %rdi
     54d:      	movq	%rbp, %rsi
     550:      	movq	0x20(%rsp), %rcx
     555:      	movl	$0x6, %ebp
     55a:      	testl	%eax, %eax
     55c:      	js	0x9e1 <generic_rawtp_process_event+0x811>
     562:      	cmpw	$0x0, 0x36(%rdi)
     567:      	je	0x9e9 <generic_rawtp_process_event+0x819>
     56d:      	movl	0x30(%rdi), %ecx
     570:      	addq	0x8(%rsp), %rcx
     575:      	movq	%rcx, 0x8(%rsp)
     57a:      	cmpw	$0x0, 0x34(%rdi)
     57f:      	je	0x5b9 <generic_rawtp_process_event+0x3e9>
     581:      	leaq	0x8(%rsp), %rdi
     586:      	movl	$0x8, %edx
     58b:      	movl	$0x4, %eax
     590:      	movq	0x8(%rsp), %rdx
     595:      	movq	%rsi, %rbp
     598:      	movl	$0x8, %esi
     59d:      	callq	*%rax
     59f:      	movq	0x10(%rsp), %rdi
     5a4:      	movq	%rbp, %rsi
     5a7:      	movq	0x20(%rsp), %rcx
     5ac:      	movl	$0x7, %ebp
     5b1:      	testl	%eax, %eax
     5b3:      	js	0x9e1 <generic_rawtp_process_event+0x811>
     5b9:      	cmpw	$0x0, 0x3e(%rdi)
     5be:      	je	0x9e9 <generic_rawtp_process_event+0x819>
     5c4:      	movl	0x38(%rdi), %ecx
     5c7:      	addq	0x8(%rsp), %rcx
     5cc:      	movq	%rcx, 0x8(%rsp)
     5d1:      	cmpw	$0x0, 0x3c(%rdi)
     5d6:      	je	0x614 <generic_rawtp_process_event+0x444>
     5d8:      	leaq	0x8(%rsp), %rdi
     5dd:      	movl	$0x8, %edx
     5e2:      	movl	$0x4, %eax
     5e7:      	movq	0x8(%rsp), %rdx
     5ec:      	movl	$0x8, %ebp
     5f1:      	movq	%rsi, 0x40(%rsp)
     5f6:      	movl	$0x8, %esi
     5fb:      	callq	*%rax
     5fd:      	movq	0x10(%rsp), %rdi
     602:      	movq	0x40(%rsp), %rsi
     607:      	movq	0x20(%rsp), %rcx
     60c:      	testl	%eax, %eax
     60e:      	js	0x9e1 <generic_rawtp_process_event+0x811>
     614:      	cmpw	$0x0, 0x46(%rdi)
     619:      	je	0x9e9 <generic_rawtp_process_event+0x819>
     61f:      	movl	0x40(%rdi), %ecx
     622:      	addq	0x8(%rsp), %rcx
     627:      	movq	%rcx, 0x8(%rsp)
     62c:      	cmpw	$0x0, 0x44(%rdi)
     631:      	je	0x66b <generic_rawtp_process_event+0x49b>
     633:      	leaq	0x8(%rsp), %rdi
     638:      	movl	$0x8, %edx
     63d:      	movl	$0x4, %eax
     642:      	movq	0x8(%rsp), %rdx
     647:      	movq	%rsi, %rbp
     64a:      	movl	$0x8, %esi
     64f:      	callq	*%rax
     651:      	movq	0x10(%rsp), %rdi
     656:      	movq	%rbp, %rsi
     659:      	movq	0x20(%rsp), %rcx
     65e:      	movl	$0x9, %ebp
     663:      	testl	%eax, %eax
     665:      	js	0x9e1 <generic_rawtp_process_event+0x811>
     66b:      	cmpw	$0x0, 0x4e(%rdi)
     670:      	je	0x9e9 <generic_rawtp_process_event+0x819>
     676:      	movl	0x48(%rdi), %ecx
     679:      	addq	0x8(%rsp), %rcx
     67e:      	movq	%rcx, 0x8(%rsp)
     683:      	cmpw	$0x0, 0x4c(%rdi)
     688:      	je	0x9e9 <generic_rawtp_process_event+0x819>
     68e:      	leaq	0x8(%rsp), %rdi
     693:      	movl	$0x8, %edx
     698:      	movl	$0x4, %eax
     69d:      	jmp	0x9c1 <generic_rawtp_process_event+0x7f1>
     6a2:      	testw	%ax, %ax
     6a5:      	je	0x6df <generic_rawtp_process_event+0x50f>
     6a7:      	leaq	0x8(%rsp), %rdi
     6ac:      	movl	$0x8, %edx
     6b1:      	movl	$0x4, %eax
     6b6:      	movq	0x8(%rsp), %rdx
     6bb:      	movq	%rsi, %rbp
     6be:      	movl	$0x8, %esi
     6c3:      	callq	*%rax
     6c5:      	movq	0x10(%rsp), %rdi
     6ca:      	movq	%rbp, %rsi
     6cd:      	movq	0x20(%rsp), %rcx
     6d2:      	movl	$0x1, %ebp
     6d7:      	testl	%eax, %eax
     6d9:      	js	0x9e1 <generic_rawtp_process_event+0x811>
     6df:      	cmpw	$0x0, 0xe(%rdi)
     6e4:      	je	0x9e9 <generic_rawtp_process_event+0x819>
     6ea:      	movl	0x8(%rdi), %ecx
     6ed:      	addq	0x8(%rsp), %rcx
     6f2:      	movq	%rcx, 0x8(%rsp)
     6f7:      	cmpw	$0x0, 0xc(%rdi)
     6fc:      	je	0x736 <generic_rawtp_process_event+0x566>
     6fe:      	leaq	0x8(%rsp), %rdi
     703:      	movl	$0x8, %edx
     708:      	movl	$0x4, %eax
     70d:      	movq	0x8(%rsp), %rdx
     712:      	movq	%rsi, %rbp
     715:      	movl	$0x8, %esi
     71a:      	callq	*%rax
     71c:      	movq	0x10(%rsp), %rdi
     721:      	movq	%rbp, %rsi
     724:      	movq	0x20(%rsp), %rcx
     729:      	movl	$0x2, %ebp
     72e:      	testl	%eax, %eax
     730:      	js	0x9e1 <generic_rawtp_process_event+0x811>
     736:      	cmpw	$0x0, 0x16(%rdi)
     73b:      	je	0x9e9 <generic_rawtp_process_event+0x819>
     741:      	movl	0x10(%rdi), %ecx
     744:      	addq	0x8(%rsp), %rcx
     749:      	movq	%rcx, 0x8(%rsp)
     74e:      	cmpw	$0x0, 0x14(%rdi)
     753:      	je	0x78d <generic_rawtp_process_event+0x5bd>
     755:      	leaq	0x8(%rsp), %rdi
     75a:      	movl	$0x8, %edx
     75f:      	movl	$0x4, %eax
     764:      	movq	0x8(%rsp), %rdx
     769:      	movq	%rsi, %rbp
     76c:      	movl	$0x8, %esi
     771:      	callq	*%rax
     773:      	movq	0x10(%rsp), %rdi
     778:      	movq	%rbp, %rsi
     77b:      	movq	0x20(%rsp), %rcx
     780:      	movl	$0x3, %ebp
     785:      	testl	%eax, %eax
     787:      	js	0x9e1 <generic_rawtp_process_event+0x811>
     78d:      	cmpw	$0x0, 0x1e(%rdi)
     792:      	je	0x9e9 <generic_rawtp_process_event+0x819>
     798:      	movl	0x18(%rdi), %ecx
     79b:      	addq	0x8(%rsp), %rcx
     7a0:      	movq	%rcx, 0x8(%rsp)
     7a5:      	cmpw	$0x0, 0x1c(%rdi)
     7aa:      	je	0x7e4 <generic_rawtp_process_event+0x614>
     7ac:      	leaq	0x8(%rsp), %rdi
     7b1:      	movl	$0x8, %edx
     7b6:      	movl	$0x4, %eax
     7bb:      	movq	0x8(%rsp), %rdx
     7c0:      	movq	%rsi, %rbp
     7c3:      	movl	$0x8, %esi
     7c8:      	callq	*%rax
     7ca:      	movq	0x10(%rsp), %rdi
     7cf:      	movq	%rbp, %rsi
     7d2:      	movq	0x20(%rsp), %rcx
     7d7:      	movl	$0x4, %ebp
     7dc:      	testl	%eax, %eax
     7de:      	js	0x9e1 <generic_rawtp_process_event+0x811>
     7e4:      	cmpw	$0x0, 0x26(%rdi)
     7e9:      	je	0x9e9 <generic_rawtp_process_event+0x819>
     7ef:      	movl	0x20(%rdi), %ecx
     7f2:      	addq	0x8(%rsp), %rcx
     7f7:      	movq	%rcx, 0x8(%rsp)
     7fc:      	cmpw	$0x0, 0x24(%rdi)
     801:      	je	0x83b <generic_rawtp_process_event+0x66b>
     803:      	leaq	0x8(%rsp), %rdi
     808:      	movl	$0x8, %edx
     80d:      	movl	$0x4, %eax
     812:      	movq	0x8(%rsp), %rdx
     817:      	movq	%rsi, %rbp
     81a:      	movl	$0x8, %esi
     81f:      	callq	*%rax
     821:      	movq	0x10(%rsp), %rdi
     826:      	movq	%rbp, %rsi
     829:      	movq	0x20(%rsp), %rcx
     82e:      	movl	$0x5, %ebp
     833:      	testl	%eax, %eax
     835:      	js	0x9e1 <generic_rawtp_process_event+0x811>
     83b:      	cmpw	$0x0, 0x2e(%rdi)
     840:      	je	0x9e9 <generic_rawtp_process_event+0x819>
     846:      	movl	0x28(%rdi), %ecx
     849:      	addq	0x8(%rsp), %rcx
     84e:      	movq	%rcx, 0x8(%rsp)
     853:      	cmpw	$0x0, 0x2c(%rdi)
     858:      	je	0x892 <generic_rawtp_process_event+0x6c2>
     85a:      	leaq	0x8(%rsp), %rdi
     85f:      	movl	$0x8, %edx
     864:      	movl	$0x4, %eax
     869:      	movq	0x8(%rsp), %rdx
     86e:      	movq	%rsi, %rbp
     871:      	movl	$0x8, %esi
     876:      	callq	*%rax
     878:      	movq	0x10(%rsp), %rdi
     87d:      	movq	%rbp, %rsi
     880:      	movq	0x20(%rsp), %rcx
     885:      	movl	$0x6, %ebp
     88a:      	testl	%eax, %eax
     88c:      	js	0x9e1 <generic_rawtp_process_event+0x811>
     892:      	cmpw	$0x0, 0x36(%rdi)
     897:      	je	0x9e9 <generic_rawtp_process_event+0x819>
     89d:      	movl	0x30(%rdi), %ecx
     8a0:      	addq	0x8(%rsp), %rcx
     8a5:      	movq	%rcx, 0x8(%rsp)
     8aa:      	cmpw	$0x0, 0x34(%rdi)
     8af:      	je	0x8e9 <generic_rawtp_process_event+0x719>
     8b1:      	leaq	0x8(%rsp), %rdi
     8b6:      	movl	$0x8, %edx
     8bb:      	movl	$0x4, %eax
     8c0:      	movq	0x8(%rsp), %rdx
     8c5:      	movq	%rsi, %rbp
     8c8:      	movl	$0x8, %esi
     8cd:      	callq	*%rax
     8cf:      	movq	0x10(%rsp), %rdi
     8d4:      	movq	%rbp, %rsi
     8d7:      	movq	0x20(%rsp), %rcx
     8dc:      	movl	$0x7, %ebp
     8e1:      	testl	%eax, %eax
     8e3:      	js	0x9e1 <generic_rawtp_process_event+0x811>
     8e9:      	cmpw	$0x0, 0x3e(%rdi)
     8ee:      	je	0x9e9 <generic_rawtp_process_event+0x819>
     8f4:      	movl	0x38(%rdi), %ecx
     8f7:      	addq	0x8(%rsp), %rcx
     8fc:      	movq	%rcx, 0x8(%rsp)
     901:      	cmpw	$0x0, 0x3c(%rdi)
     906:      	je	0x944 <generic_rawtp_process_event+0x774>
     908:      	leaq	0x8(%rsp), %rdi
     90d:      	movl	$0x8, %edx
     912:      	movl	$0x4, %eax
     917:      	movq	0x8(%rsp), %rdx
     91c:      	movl	$0x8, %ebp
     921:      	movq	%rsi, 0x40(%rsp)
     926:      	movl	$0x8, %esi
     92b:      	callq	*%rax
     92d:      	movq	0x10(%rsp), %rdi
     932:      	movq	0x40(%rsp), %rsi
     937:      	movq	0x20(%rsp), %rcx
     93c:      	testl	%eax, %eax
     93e:      	js	0x9e1 <generic_rawtp_process_event+0x811>
     944:      	cmpw	$0x0, 0x46(%rdi)
     949:      	je	0x9e9 <generic_rawtp_process_event+0x819>
     94f:      	movl	0x40(%rdi), %ecx
     952:      	addq	0x8(%rsp), %rcx
     957:      	movq	%rcx, 0x8(%rsp)
     95c:      	cmpw	$0x0, 0x44(%rdi)
     961:      	je	0x997 <generic_rawtp_process_event+0x7c7>
     963:      	leaq	0x8(%rsp), %rdi
     968:      	movl	$0x8, %edx
     96d:      	movl	$0x4, %eax
     972:      	movq	0x8(%rsp), %rdx
     977:      	movq	%rsi, %rbp
     97a:      	movl	$0x8, %esi
     97f:      	callq	*%rax
     981:      	movq	0x10(%rsp), %rdi
     986:      	movq	%rbp, %rsi
     989:      	movq	0x20(%rsp), %rcx
     98e:      	movl	$0x9, %ebp
     993:      	testl	%eax, %eax
     995:      	js	0x9e1 <generic_rawtp_process_event+0x811>
     997:      	cmpw	$0x0, 0x4e(%rdi)
     99c:      	je	0x9e9 <generic_rawtp_process_event+0x819>
     99e:      	movl	0x48(%rdi), %ecx
     9a1:      	addq	0x8(%rsp), %rcx
     9a6:      	movq	%rcx, 0x8(%rsp)
     9ab:      	cmpw	$0x0, 0x4c(%rdi)
     9b0:      	je	0x9e9 <generic_rawtp_process_event+0x819>
     9b2:      	leaq	0x8(%rsp), %rdi
     9b7:      	movl	$0x8, %edx
     9bc:      	movl	$0x4, %eax
     9c1:      	movq	0x8(%rsp), %rdx
     9c6:      	movq	%rsi, %rbp
     9c9:      	movl	$0x8, %esi
     9ce:      	callq	*%rax
     9d0:      	movq	%rbp, %rsi
     9d3:      	movq	0x20(%rsp), %rcx
     9d8:      	movl	$0xa, %ebp
     9dd:      	testl	%eax, %eax
     9df:      	jns	0x9e9 <generic_rawtp_process_event+0x819>
     9e1:      	movl	%ebp, 0x5ea0(%r15,%rcx,4)
     9e9:      	movl	%r13d, %ebp
     9ec:      	cmpl	$0x2a, %r13d
     9f0:      	ja	0xbdb <generic_rawtp_process_event+0xa0b>
     9f6:      	movabsq	$0x42001018000, %rax    # imm = 0x42001018000
     a00:      	btq	%rbp, %rax
     a04:      	jae	0xbdb <generic_rawtp_process_event+0xa0b>
     a0a:      	movq	0x8(%rsp), %rbp
     a0f:      	movl	$0x0, 0x30(%rsp)
     a17:      	movq	(%rip), %rdi            # 0xa1e <generic_rawtp_process_event+0x84e>
     a1e:      	leaq	0x30(%rsp), %rsi
     a23:      	movl	$0x1, %eax
     a28:      	callq	*%rax
     a2a:      	testq	%rax, %rax
     a2d:      	je	0xdad <generic_rawtp_process_event+0xbdd>
     a33:      	movq	%rax, %r12
     a36:      	cmpl	$0x0, 0x6420(%rax)
     a3d:      	je	0xb83 <generic_rawtp_process_event+0x9b3>
     a43:      	movl	$0x0, 0x6420(%r12)
     a4f:      	movq	(%rip), %rdi            # 0xa56 <generic_rawtp_process_event+0x886>
     a56:      	leaq	0x30(%rsp), %rsi
     a5b:      	movl	$0x1, %eax
     a60:      	callq	*%rax
     a62:      	testq	%rax, %rax
     a65:      	je	0xdad <generic_rawtp_process_event+0xbdd>
     a6b:      	movq	%rax, %rdx
     a6e:      	movq	0x20(%rsp), %rcx
     a73:      	movl	0x5ea0(%r12,%rcx,4), %eax
     a7b:      	movq	0xc8(%rsp), %rbp
     a83:      	movl	%eax, 0x90(%r12,%rbp)
     a8b:      	addq	$0x4, %rbp
     a8f:      	movq	%rbp, 0x5e78(%r12,%rcx,8)
     a97:      	movl	$0x4, %esi
     a9c:      	testl	%eax, %eax
     a9e:      	jne	0xdaf <generic_rawtp_process_event+0xbdf>
     aa4:      	movq	%r12, %r15
     aa7:      	addq	$0x90, %r15
     aae:      	movl	0x6424(%r12), %eax
     ab6:      	movq	%rbx, 0x18(%rsp)
     abb:      	movl	$0xfff, %ebx            # imm = 0xFFF
     ac0:      	subl	%eax, %ebx
     ac2:      	andl	$0xfff, %eax            # imm = 0xFFF
     ac7:      	addq	%rax, %rdx
     aca:      	movq	0x6440(%r12), %r13
     ad2:      	leaq	(%r15,%rbp), %rdi
     ad6:      	addq	$0x4, %rdi
     ada:      	andl	$0xfff, %ebx            # imm = 0xFFF
     ae0:      	movl	$0x4, %eax
     ae5:      	addq	%rbp, %r15
     ae8:      	movl	%ebx, %esi
     aea:      	callq	*%rax
     aec:      	movl	%ebx, 0x90(%r12,%rbp)
     af4:      	addq	$0x8, %r13
     af8:      	leaq	0x68(%rsp), %rdi
     afd:      	movl	$0x8, %ecx
     b02:      	movl	$0x4, %eax
     b07:      	movl	$0x8, %esi
     b0c:      	movq	%r13, %rdx
     b0f:      	callq	*%rax
     b11:      	movq	0x68(%rsp), %rcx
     b16:      	addq	$0x30, %rcx
     b1a:      	leaq	0x58(%rsp), %rdi
     b1f:      	movl	$0x8, %edx
     b24:      	movl	$0x4, %eax
     b29:      	movq	0x68(%rsp), %rdx
     b2e:      	addq	$0x30, %rdx
     b32:      	movl	$0x8, %esi
     b37:      	callq	*%rax
     b39:      	movq	0x58(%rsp), %rcx
     b3e:      	leaq	0xb0(%rsp), %rdi
     b46:      	movl	$0x2, %edx
     b4b:      	movl	$0x4, %eax
     b50:      	movq	0x58(%rsp), %rdx
     b55:      	movl	$0x2, %esi
     b5a:      	callq	*%rax
     b5c:      	movq	%rbx, %rsi
     b5f:      	movq	0x18(%rsp), %rbx
     b64:      	movl	$0x0, 0x4(%rsi,%r15)
     b6d:      	movzwl	0xb0(%rsp), %eax
     b75:      	movw	%ax, 0x8(%rsi,%r15)
     b7b:      	addl	$0xe, %esi
     b7e:      	jmp	0xdaf <generic_rawtp_process_event+0xbdf>
     b83:      	movq	%rbp, 0x68(%rsp)
     b88:      	movq	$0x0, 0x58(%rsp)
     b91:      	cmpl	$0x17, %r13d
     b95:      	jle	0xc69 <generic_rawtp_process_event+0xa99>
     b9b:      	cmpl	$0x18, %r13d
     b9f:      	je	0xce7 <generic_rawtp_process_event+0xb17>
     ba5:      	cmpl	$0x25, %r13d
     ba9:      	je	0xd2e <generic_rawtp_process_event+0xb5e>
     baf:      	cmpl	$0x2a, %r13d
     bb3:      	jne	0xdad <generic_rawtp_process_event+0xbdd>
     bb9:      	movq	%r12, %rax
     bbc:      	addq	$0x6430, %rax           # imm = 0x6430
     bc2:      	movq	$0x0, 0x6430(%r12)
     bce:      	movq	%rbp, 0x6438(%r12)
     bd6:      	jmp	0xd61 <generic_rawtp_process_event+0xb91>
     bdb:      	movq	0x8(%rsp), %rax
     be0:      	movq	%rax, 0x10(%rsp)
     be5:      	cmpl	$0x15, %r13d
     be9:      	movq	%rsi, 0x40(%rsp)
     bee:      	jg	0xc3d <generic_rawtp_process_event+0xa6d>
     bf0:      	movl	$0x1000, %r15d          # imm = 0x1000
     bf6:      	cmpl	$0x9, %r13d
     bfa:      	jle	0xc8a <generic_rawtp_process_event+0xaba>
     c00:      	cmpl	$0x10, %r13d
     c04:      	jle	0xe73 <generic_rawtp_process_event+0xca3>
     c0a:      	cmpl	$0x12, %r13d
     c0e:      	jle	0xef5 <generic_rawtp_process_event+0xd25>
     c14:      	cmpl	$0x13, %r13d
     c18:      	je	0xeed <generic_rawtp_process_event+0xd1d>
     c1e:      	cmpl	$0x14, %r13d
     c22:      	je	0xf22 <generic_rawtp_process_event+0xd52>
     c28:      	cmpl	$0x15, %r13d
     c2c:      	jne	0xf30 <generic_rawtp_process_event+0xd60>
     c32:      	movl	$0x20, %r15d
     c38:      	jmp	0xf33 <generic_rawtp_process_event+0xd63>
     c3d:      	cmpl	$0x20, %r13d
     c41:      	jle	0xcba <generic_rawtp_process_event+0xaea>
     c43:      	cmpl	$0x27, %r13d
     c47:      	jg	0xe95 <generic_rawtp_process_event+0xcc5>
     c4d:      	leal	-0x21(%r13), %eax
     c51:      	cmpl	$0x4, %eax
     c54:      	jb	0xe8a <generic_rawtp_process_event+0xcba>
     c5a:      	cmpl	$0x27, %r13d
     c5e:      	je	0xed1 <generic_rawtp_process_event+0xd01>
     c64:      	jmp	0xf30 <generic_rawtp_process_event+0xd60>
     c69:      	cmpl	$0xf, %r13d
     c6d:      	je	0xd88 <generic_rawtp_process_event+0xbb8>
     c73:      	cmpl	$0x10, %r13d
     c77:      	jne	0xdad <generic_rawtp_process_event+0xbdd>
     c7d:      	leaq	0xb0(%rsp), %r15
     c85:      	jmp	0xd15 <generic_rawtp_process_event+0xb45>
     c8a:      	cmpl	$0x4, %r13d
     c8e:      	jg	0xeac <generic_rawtp_process_event+0xcdc>
     c94:      	leal	-0x2(%r13), %eax
     c98:      	cmpl	$0x2, %eax
     c9b:      	jb	0xec9 <generic_rawtp_process_event+0xcf9>
     ca1:      	cmpl	$0x1, %r13d
     ca5:      	je	0xec9 <generic_rawtp_process_event+0xcf9>
     cab:      	cmpl	$0x4, %r13d
     caf:      	je	0xe8a <generic_rawtp_process_event+0xcba>
     cb5:      	jmp	0xf30 <generic_rawtp_process_event+0xd60>
     cba:      	cmpl	$0x1a, %r13d
     cbe:      	jg	0xec0 <generic_rawtp_process_event+0xcf0>
     cc4:      	cmpl	$0x16, %r13d
     cc8:      	je	0xed1 <generic_rawtp_process_event+0xd01>
     cce:      	cmpl	$0x17, %r13d
     cd2:      	je	0xe8a <generic_rawtp_process_event+0xcba>
     cd8:      	cmpl	$0x1a, %r13d
     cdc:      	je	0xf12 <generic_rawtp_process_event+0xd42>
     ce2:      	jmp	0xf30 <generic_rawtp_process_event+0xd60>
     ce7:      	leaq	0xb0(%rsp), %r15
     cef:      	movl	$0x8, %ecx
     cf4:      	movl	$0x4, %eax
     cf9:      	movq	0x68(%rsp), %rdx
     cfe:      	movq	%r15, %rdi
     d01:      	movl	$0x8, %esi
     d06:      	callq	*%rax
     d08:      	movq	0xb0(%rsp), %rax
     d10:      	movq	%rax, 0x68(%rsp)
     d15:      	leaq	0x68(%rsp), %rdx
     d1a:      	movl	$0x8, %ecx
     d1f:      	movl	$0x4, %eax
     d24:      	leaq	0xb0(%rsp), %rdi
     d2c:      	jmp	0xd4e <generic_rawtp_process_event+0xb7e>
     d2e:      	addq	$0x40, %rbp
     d32:      	movq	%rbp, 0x68(%rsp)
     d37:      	leaq	0xb0(%rsp), %rdi
     d3f:      	movl	$0x8, %ecx
     d44:      	movl	$0x4, %eax
     d49:      	movq	0x68(%rsp), %rdx
     d4e:      	movl	$0x8, %esi
     d53:      	callq	*%rax
     d55:      	movq	0xb0(%rsp), %rax
     d5d:      	addq	$0x40, %rax
     d61:      	movq	%rax, 0x6440(%r12)
     d69:      	movq	(%rip), %rsi            # 0xd70 <generic_rawtp_process_event+0xba0>
     d70:      	movl	$0x6, %ecx
     d75:      	movl	$0xc, %eax
     d7a:      	movq	%rbx, %rdi
     d7d:      	movl	$0x6, %edx
     d82:      	callq	*%rax
     d84:      	xorl	%esi, %esi
     d86:      	jmp	0xdaf <generic_rawtp_process_event+0xbdf>
     d88:      	leaq	0x58(%rsp), %rdi
     d8d:      	leaq	0x68(%rsp), %rdx
     d92:      	movl	$0x8, %ecx
     d97:      	movl	$0x4, %eax
     d9c:      	movl	$0x8, %esi
     da1:      	callq	*%rax
     da3:      	movq	0x58(%rsp), %rax
     da8:      	testq	%rax, %rax
     dab:      	jne	0xd61 <generic_rawtp_process_event+0xb91>
     dad:      	xorl	%esi, %esi
     daf:      	addl	0xc8(%rsp), %esi
     db6:      	movl	%esi, %ebp
     db8:      	movq	0x100(%rsp), %r12
     dc0:      	movl	%ebp, 0x4(%r14)
     dc4:      	cmpl	$0x3, %r12d
     dc8:      	jg	0xe39 <generic_rawtp_process_event+0xc69>
     dca:      	movl	$0x0, 0x68(%rsp)
     dd2:      	movq	(%rip), %rdi            # 0xdd9 <generic_rawtp_process_event+0xc09>
     dd9:      	leaq	0x68(%rsp), %rsi
     dde:      	movl	$0x1, %eax
     de3:      	callq	*%rax
     de5:      	testq	%rax, %rax
     de8:      	je	0xe39 <generic_rawtp_process_event+0xc69>
     dea:      	movq	%rax, %rsi
     ded:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     df4:      	movq	(%rip), %rdi            # 0xdfb <generic_rawtp_process_event+0xc2b>
     dfb:      	movl	$0x1, %eax
     e00:      	callq	*%rax
     e02:      	testq	%rax, %rax
     e05:      	je	0xe39 <generic_rawtp_process_event+0xc69>
     e07:      	incl	%r12d
     e0a:      	movl	%r12d, %ecx
     e0d:      	andl	$0x7, %ecx
     e10:      	cmpl	$-0x1, 0x40(%rax,%rcx,4)
     e15:      	je	0xe39 <generic_rawtp_process_event+0xc69>
     e17:      	movl	%r12d, 0x5efc(%r14)
     e1e:      	movq	(%rip), %rsi            # 0xe25 <generic_rawtp_process_event+0xc55>
     e25:      	movl	$0x1, %ecx
     e2a:      	movl	$0xc, %eax
     e2f:      	movq	%rbx, %rdi
     e32:      	movl	$0x1, %edx
     e37:      	callq	*%rax
     e39:      	movl	$0x0, 0x5efc(%r14)
     e44:      	movq	(%rip), %rsi            # 0xe4b <generic_rawtp_process_event+0xc7b>
     e4b:      	movl	$0x3, %ecx
     e50:      	movl	$0xc, %eax
     e55:      	movq	%rbx, %rdi
     e58:      	movl	$0x3, %edx
     e5d:      	callq	*%rax
     e5f:      	xorl	%eax, %eax
     e61:      	addq	$0x108, %rsp            # imm = 0x108
     e68:      	popq	%rbx
     e69:      	popq	%r12
     e6b:      	popq	%r13
     e6d:      	popq	%r14
     e6f:      	popq	%r15
     e71:      	popq	%rbp
     e72:      	retq
     e73:      	leal	-0xa(%r13), %eax
     e77:      	cmpl	$0x2, %eax
     e7a:      	jb	0xe8a <generic_rawtp_process_event+0xcba>
     e7c:      	leal	-0xc(%r13), %eax
     e80:      	cmpl	$0x2, %eax
     e83:      	jb	0xec9 <generic_rawtp_process_event+0xcf9>
     e85:      	jmp	0xf30 <generic_rawtp_process_event+0xd60>
     e8a:      	movl	$0x8, %r15d
     e90:      	jmp	0xf33 <generic_rawtp_process_event+0xd63>
     e95:      	cmpl	$0x2a, %r13d
     e99:      	jg	0xed9 <generic_rawtp_process_event+0xd09>
     e9b:      	cmpl	$0x28, %r13d
     e9f:      	je	0xeed <generic_rawtp_process_event+0xd1d>
     ea1:      	cmpl	$0x29, %r13d
     ea5:      	je	0xf1a <generic_rawtp_process_event+0xd4a>
     ea7:      	jmp	0xf30 <generic_rawtp_process_event+0xd60>
     eac:      	cmpl	$0x6, %r13d
     eb0:      	jg	0xf06 <generic_rawtp_process_event+0xd36>
     eb2:      	cmpl	$0x5, %r13d
     eb6:      	je	0xf1a <generic_rawtp_process_event+0xd4a>
     eb8:      	cmpl	$0x6, %r13d
     ebc:      	je	0xf33 <generic_rawtp_process_event+0xd63>
     ebe:      	jmp	0xf30 <generic_rawtp_process_event+0xd60>
     ec0:      	leal	-0x1d(%r13), %eax
     ec4:      	cmpl	$0x4, %eax
     ec7:      	jae	0xf2a <generic_rawtp_process_event+0xd5a>
     ec9:      	movl	$0x4, %r15d
     ecf:      	jmp	0xf33 <generic_rawtp_process_event+0xd63>
     ed1:      	movl	$0x10, %r15d
     ed7:      	jmp	0xf33 <generic_rawtp_process_event+0xd63>
     ed9:      	cmpl	$0x2b, %r13d
     edd:      	je	0xeed <generic_rawtp_process_event+0xd1d>
     edf:      	cmpl	$0x2c, %r13d
     ee3:      	jne	0xf30 <generic_rawtp_process_event+0xd60>
     ee5:      	movl	$0x70, %r15d
     eeb:      	jmp	0xf33 <generic_rawtp_process_event+0xd63>
     eed:      	movl	$0x18, %r15d
     ef3:      	jmp	0xf33 <generic_rawtp_process_event+0xd63>
     ef5:      	cmpl	$0x11, %r13d
     ef9:      	je	0xf33 <generic_rawtp_process_event+0xd63>
     efb:      	movq	%r12, %r15
     efe:      	cmpl	$0x12, %r13d
     f02:      	je	0xf33 <generic_rawtp_process_event+0xd63>
     f04:      	jmp	0xf30 <generic_rawtp_process_event+0xd60>
     f06:      	cmpl	$0x7, %r13d
     f0a:      	je	0xf1a <generic_rawtp_process_event+0xd4a>
     f0c:      	cmpl	$0x8, %r13d
     f10:      	jne	0xf30 <generic_rawtp_process_event+0xd60>
     f12:      	movl	$0x50, %r15d
     f18:      	jmp	0xf33 <generic_rawtp_process_event+0xd63>
     f1a:      	movl	$0x40, %r15d
     f20:      	jmp	0xf33 <generic_rawtp_process_event+0xd63>
     f22:      	movl	$0x98, %r15d
     f28:      	jmp	0xf33 <generic_rawtp_process_event+0xd63>
     f2a:      	cmpl	$0x1b, %r13d
     f2e:      	je	0xf12 <generic_rawtp_process_event+0xd42>
     f30:      	xorl	%r15d, %r15d
     f33:      	movl	$0x0, 0xfc(%rsp)
     f3e:      	movq	(%rip), %rdi            # 0xf45 <generic_rawtp_process_event+0xd75>
     f45:      	leaq	0xfc(%rsp), %rsi
     f4d:      	movl	$0x1, %eax
     f52:      	callq	*%rax
     f54:      	xorl	%esi, %esi
     f56:      	testq	%rax, %rax
     f59:      	je	0xdaf <generic_rawtp_process_event+0xbdf>
     f5f:      	movl	$0x3ffb, %ecx           # imm = 0x3FFB
     f64:      	subq	%r15, %rcx
     f67:      	cmpq	0xc8(%rsp), %rcx
     f6f:      	jbe	0xdaf <generic_rawtp_process_event+0xbdf>
     f75:      	movq	0x20(%rsp), %rsi
     f7a:      	movl	0x5ea0(%rax,%rsi,4), %ecx
     f81:      	movq	0xc8(%rsp), %rdx
     f89:      	movl	%ecx, 0x90(%rax,%rdx)
     f90:      	leaq	0x4(%rdx), %rdi
     f94:      	movq	%rdi, 0x5e78(%rax,%rsi,8)
     f9c:      	movl	$0x4, %esi
     fa1:      	testl	%ecx, %ecx
     fa3:      	jne	0xdaf <generic_rawtp_process_event+0xbdf>
     fa9:      	movq	%rax, %r15
     fac:      	addq	$0x90, %r15
     fb3:      	addq	%rdi, %r15
     fb6:      	movq	0x10(%rsp), %rdx
     fbb:      	movq	%rdx, 0x68(%rsp)
     fc0:      	movq	$0x0, 0x58(%rsp)
     fc9:      	cmpl	$0x17, %r13d
     fcd:      	movq	%rax, 0x38(%rsp)
     fd2:      	jle	0x100f <generic_rawtp_process_event+0xe3f>
     fd4:      	cmpl	$0x18, %r13d
     fd8:      	je	0x102a <generic_rawtp_process_event+0xe5a>
     fda:      	cmpl	$0x25, %r13d
     fde:      	je	0x1068 <generic_rawtp_process_event+0xe98>
     fe4:      	cmpl	$0x2a, %r13d
     fe8:      	jne	0x187c <generic_rawtp_process_event+0x16ac>
     fee:      	movq	$0x0, 0xb0(%rsp)
     ffa:      	movq	%rdx, 0xb8(%rsp)
    1002:      	leaq	0xb0(%rsp), %rax
    100a:      	jmp	0x1095 <generic_rawtp_process_event+0xec5>
    100f:      	cmpl	$0xf, %r13d
    1013:      	je	0x17ab <generic_rawtp_process_event+0x15db>
    1019:      	cmpl	$0x10, %r13d
    101d:      	jne	0x187c <generic_rawtp_process_event+0x16ac>
    1023:      	leaq	0x30(%rsp), %r12
    1028:      	jmp	0x1052 <generic_rawtp_process_event+0xe82>
    102a:      	leaq	0x30(%rsp), %r12
    102f:      	movl	$0x8, %ecx
    1034:      	movl	$0x4, %eax
    1039:      	movq	0x68(%rsp), %rdx
    103e:      	movq	%r12, %rdi
    1041:      	movl	$0x8, %esi
    1046:      	callq	*%rax
    1048:      	movq	0x30(%rsp), %rax
    104d:      	movq	%rax, 0x68(%rsp)
    1052:      	leaq	0x68(%rsp), %rdx
    1057:      	movl	$0x8, %ecx
    105c:      	movl	$0x4, %eax
    1061:      	leaq	0x30(%rsp), %rdi
    1066:      	jmp	0x1085 <generic_rawtp_process_event+0xeb5>
    1068:      	addq	$0x40, %rdx
    106c:      	movq	%rdx, 0x68(%rsp)
    1071:      	leaq	0x30(%rsp), %rdi
    1076:      	movl	$0x8, %ecx
    107b:      	movl	$0x4, %eax
    1080:      	movq	0x68(%rsp), %rdx
    1085:      	movl	$0x8, %esi
    108a:      	callq	*%rax
    108c:      	movq	0x30(%rsp), %rax
    1091:      	addq	$0x40, %rax
    1095:      	movq	%rax, 0xa8(%rsp)
    109d:      	movl	$0x0, 0xdc(%rsp)
    10a8:      	movq	(%rip), %rdi            # 0x10af <generic_rawtp_process_event+0xedf>
    10af:      	leaq	0xdc(%rsp), %rsi
    10b7:      	movl	$0x1, %eax
    10bc:      	callq	*%rax
    10be:      	testq	%rax, %rax
    10c1:      	je	0x16c0 <generic_rawtp_process_event+0x14f0>
    10c7:      	movq	%rax, %r12
    10ca:      	movq	%r15, 0x48(%rsp)
    10cf:      	addq	$0x1000, %rax           # imm = 0x1000
    10d5:      	movq	%rax, 0x10(%rsp)
    10da:      	movl	$0x23, %eax
    10df:      	callq	*%rax
    10e1:      	leaq	0xd50(%rax), %rdx
    10e8:      	leaq	0xd0(%rsp), %rdi
    10f0:      	movl	$0x8, %ecx
    10f5:      	movl	$0x4, %eax
    10fa:      	movl	$0x8, %esi
    10ff:      	callq	*%rax
    1101:      	movq	0xd0(%rsp), %rbp
    1109:      	movq	0xa8(%rsp), %rax
    1111:      	leaq	0x8(%rax), %rdx
    1115:      	leaq	0xe0(%rsp), %rdi
    111d:      	movl	$0x8, %ecx
    1122:      	movl	$0x4, %eax
    1127:      	leaq	0x18(%rbp), %rcx
    112b:      	movq	%rcx, 0xe8(%rsp)
    1133:      	movl	$0x8, %esi
    1138:      	movq	%rdx, 0x40(%rsp)
    113d:      	callq	*%rax
    113f:      	movq	0xe0(%rsp), %r13
    1147:      	leaq	0x10(%r13), %rdx
    114b:      	leaq	0x68(%rsp), %rdi
    1150:      	movl	$0x8, %ecx
    1155:      	movl	$0x4, %eax
    115a:      	movl	$0x8, %esi
    115f:      	callq	*%rax
    1161:      	cmpq	$0x0, 0x68(%rsp)
    1167:      	movl	$0x1000, %r15d          # imm = 0x1000
    116d:      	je	0x1176 <generic_rawtp_process_event+0xfa6>
    116f:      	movq	0x10(%rsp), %rcx
    1174:      	jmp	0x11c9 <generic_rawtp_process_event+0xff9>
    1176:      	leaq	0x18(%r13), %rdx
    117a:      	leaq	0x68(%rsp), %rdi
    117f:      	movl	$0x8, %ecx
    1184:      	movl	$0x4, %eax
    1189:      	movl	$0x8, %esi
    118e:      	callq	*%rax
    1190:      	cmpq	%r13, 0x68(%rsp)
    1195:      	movq	0x10(%rsp), %rcx
    119a:      	je	0x11c9 <generic_rawtp_process_event+0xff9>
    119c:      	movq	%r12, %rcx
    119f:      	addq	$0xff6, %rcx            # imm = 0xFF6
    11a6:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    11b0:      	movq	%rax, 0xff6(%r12)
    11b8:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
    11c3:      	movl	$0xff6, %r15d           # imm = 0xFF6
    11c9:      	movq	$0x0, 0x70(%rsp)
    11d2:      	movq	$0x0, 0x68(%rsp)
    11db:      	movq	%r12, 0x78(%rsp)
    11e0:      	movq	$0x0, 0x80(%rsp)
    11ec:      	movq	$0x0, 0x88(%rsp)
    11f8:      	movq	$0x0, 0x90(%rsp)
    1204:      	movq	%rcx, 0x10(%rsp)
    1209:      	movq	%rcx, 0x98(%rsp)
    1211:      	movl	%r15d, 0xa0(%rsp)
    1219:      	movb	$0x0, 0xa4(%rsp)
    1221:      	addq	$0x20, %rbp
    1225:      	leaq	0x68(%rsp), %rdi
    122a:      	movl	$0x8, %ecx
    122f:      	movl	$0x4, %eax
    1234:      	leaq	0x70(%rsp), %r12
    1239:      	leaq	0x80(%rsp), %r15
    1241:      	leaq	0x88(%rsp), %r13
    1249:      	movl	$0x8, %esi
    124e:      	movq	%rbp, %rdx
    1251:      	callq	*%rax
    1253:      	movl	$0x8, %ecx
    1258:      	movl	$0x4, %eax
    125d:      	movq	0xe8(%rsp), %rdx
    1265:      	movq	%r12, %rdi
    1268:      	movl	$0x8, %esi
    126d:      	callq	*%rax
    126f:      	movl	$0x8, %ecx
    1274:      	movl	$0x4, %eax
    1279:      	movq	0x40(%rsp), %rdx
    127e:      	movq	%r15, %rdi
    1281:      	movl	$0x8, %esi
    1286:      	callq	*%rax
    1288:      	movl	$0x8, %ecx
    128d:      	movl	$0x4, %eax
    1292:      	movq	0xa8(%rsp), %rdx
    129a:      	movq	%r13, %rdi
    129d:      	movl	$0x8, %esi
    12a2:      	callq	*%rax
    12a4:      	movq	0x88(%rsp), %rax
    12ac:      	addq	$-0x20, %rax
    12b0:      	movq	%rax, 0x90(%rsp)
    12b8:      	movq	(%rip), %rax            # 0x12bf <generic_rawtp_process_event+0x10ef>
    12bf:      	cmpb	$0x0, (%rax)
    12c2:      	je	0x149d <generic_rawtp_process_event+0x12cd>
    12c8:      	movl	$0x80, %r15d
    12ce:      	movl	$0x8, %r13d
    12d4:      	jmp	0x12df <generic_rawtp_process_event+0x110f>
    12d6:      	decl	%r15d
    12d9:      	je	0x1677 <generic_rawtp_process_event+0x14a7>
    12df:      	movq	0x80(%rsp), %rbp
    12e7:      	movq	0x88(%rsp), %rdx
    12ef:      	movq	0x90(%rsp), %r12
    12f7:      	cmpq	0x68(%rsp), %rbp
    12fc:      	jne	0x1309 <generic_rawtp_process_event+0x1139>
    12fe:      	cmpq	0x70(%rsp), %rdx
    1303:      	je	0x166f <generic_rawtp_process_event+0x149f>
    1309:      	movl	$0x4, %eax
    130e:      	leaq	0xc0(%rsp), %rdi
    1316:      	movl	$0x8, %esi
    131b:      	callq	*%rax
    131d:      	cmpq	0xc0(%rsp), %rbp
    1325:      	movl	$0x8, %ecx
    132a:      	je	0x1435 <generic_rawtp_process_event+0x1265>
    1330:      	leaq	0x18(%rbp), %r13
    1334:      	movl	$0x4, %eax
    1339:      	leaq	0x30(%rsp), %rdi
    133e:      	movl	$0x8, %esi
    1343:      	movq	%r13, %rdx
    1346:      	callq	*%rax
    1348:      	movl	$0x8, %ecx
    134d:      	cmpq	%rbp, 0x30(%rsp)
    1352:      	je	0x1435 <generic_rawtp_process_event+0x1265>
    1358:      	movl	$0x4, %eax
    135d:      	leaq	0x50(%rsp), %rdi
    1362:      	movl	$0x8, %esi
    1367:      	movq	%r13, %rdx
    136a:      	callq	*%rax
    136c:      	addq	$0x20, %rbp
    1370:      	movl	$0x4, %eax
    1375:      	leaq	0x58(%rsp), %rdi
    137a:      	movl	$0x10, %ecx
    137f:      	movl	$0x10, %esi
    1384:      	movq	%rbp, %rdx
    1387:      	callq	*%rax
    1389:      	movq	0x78(%rsp), %r12
    138e:      	movq	0x98(%rsp), %rax
    1396:      	movl	0x5c(%rsp), %ebp
    139a:      	subq	%r12, %rax
    139d:      	movl	0xa0(%rsp), %r13d
    13a5:      	movl	%ebp, %edx
    13a7:      	subl	%r13d, %edx
    13aa:      	movl	$0x0, %ecx
    13af:      	cmovbl	%ecx, %edx
    13b2:      	addq	0x60(%rsp), %rdx
    13b7:      	xorl	%esi, %esi
    13b9:      	cmpl	%ebp, %r13d
    13bc:      	seta	%sil
    13c0:      	movl	%ebp, %ecx
    13c2:      	cmovbl	%r13d, %ecx
    13c6:      	addl	%ecx, %esi
    13c8:      	movl	%r13d, %edi
    13cb:      	subl	%esi, %edi
    13cd:      	movl	%edi, 0xa0(%rsp)
    13d4:      	subq	%rsi, %rax
    13d7:      	jb	0x1677 <generic_rawtp_process_event+0x14a7>
    13dd:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    13e3:      	ja	0x1677 <generic_rawtp_process_event+0x14a7>
    13e9:      	cmpl	%ebp, %r13d
    13ec:      	jbe	0x13f3 <generic_rawtp_process_event+0x1223>
    13ee:      	movb	$0x2f, (%r12,%rax)
    13f3:      	xorl	%edi, %edi
    13f5:      	cmpl	%ebp, %r13d
    13f8:      	seta	%dil
    13fc:      	movzbl	%cl, %esi
    13ff:      	addq	%rax, %r12
    1402:      	addq	%r12, %rdi
    1405:      	movl	$0x4, %eax
    140a:      	callq	*%rax
    140c:      	movq	%r12, 0x98(%rsp)
    1414:      	cmpl	%ebp, %r13d
    1417:      	jbe	0x1677 <generic_rawtp_process_event+0x14a7>
    141d:      	movq	0x50(%rsp), %rax
    1422:      	movq	%rax, 0x80(%rsp)
    142a:      	movl	$0x8, %r13d
    1430:      	jmp	0x12d6 <generic_rawtp_process_event+0x1106>
    1435:      	leaq	0x10(%r12), %rdx
    143a:      	movl	$0x4, %eax
    143f:      	leaq	0x30(%rsp), %rdi
    1444:      	movl	$0x8, %esi
    1449:      	callq	*%rax
    144b:      	movq	0x90(%rsp), %rax
    1453:      	cmpq	0x30(%rsp), %rax
    1458:      	movl	$0x8, %r13d
    145e:      	je	0x166f <generic_rawtp_process_event+0x149f>
    1464:      	addq	$0x18, %r12
    1468:      	movl	$0x4, %eax
    146d:      	leaq	0x80(%rsp), %rdi
    1475:      	movl	$0x8, %esi
    147a:      	movq	%r12, %rdx
    147d:      	callq	*%rax
    147f:      	movq	0x30(%rsp), %rax
    1484:      	movq	%rax, 0x90(%rsp)
    148c:      	addq	$0x20, %rax
    1490:      	movq	%rax, 0x88(%rsp)
    1498:      	jmp	0x12d6 <generic_rawtp_process_event+0x1106>
    149d:      	movl	$0x80, %r15d
    14a3:      	movl	$0x8, %r13d
    14a9:      	movq	0x80(%rsp), %rbp
    14b1:      	movq	0x88(%rsp), %rdx
    14b9:      	movq	0x90(%rsp), %r12
    14c1:      	cmpq	0x68(%rsp), %rbp
    14c6:      	jne	0x14d3 <generic_rawtp_process_event+0x1303>
    14c8:      	cmpq	0x70(%rsp), %rdx
    14cd:      	je	0x166f <generic_rawtp_process_event+0x149f>
    14d3:      	movl	$0x4, %eax
    14d8:      	leaq	0xc0(%rsp), %rdi
    14e0:      	movl	$0x8, %esi
    14e5:      	callq	*%rax
    14e7:      	cmpq	0xc0(%rsp), %rbp
    14ef:      	movl	$0x8, %ecx
    14f4:      	je	0x1605 <generic_rawtp_process_event+0x1435>
    14fa:      	leaq	0x18(%rbp), %r13
    14fe:      	movl	$0x4, %eax
    1503:      	leaq	0x30(%rsp), %rdi
    1508:      	movl	$0x8, %esi
    150d:      	movq	%r13, %rdx
    1510:      	callq	*%rax
    1512:      	movl	$0x8, %ecx
    1517:      	cmpq	%rbp, 0x30(%rsp)
    151c:      	je	0x1605 <generic_rawtp_process_event+0x1435>
    1522:      	movl	$0x4, %eax
    1527:      	leaq	0x50(%rsp), %rdi
    152c:      	movl	$0x8, %esi
    1531:      	movq	%r13, %rdx
    1534:      	callq	*%rax
    1536:      	addq	$0x20, %rbp
    153a:      	movl	$0x4, %eax
    153f:      	leaq	0x58(%rsp), %rdi
    1544:      	movl	$0x10, %ecx
    1549:      	movl	$0x10, %esi
    154e:      	movq	%rbp, %rdx
    1551:      	callq	*%rax
    1553:      	movq	0x78(%rsp), %r12
    1558:      	movq	0x98(%rsp), %rax
    1560:      	movl	0x5c(%rsp), %ebp
    1564:      	subq	%r12, %rax
    1567:      	movl	0xa0(%rsp), %r13d
    156f:      	movl	%ebp, %edx
    1571:      	subl	%r13d, %edx
    1574:      	movl	$0x0, %ecx
    1579:      	cmovbl	%ecx, %edx
    157c:      	addq	0x60(%rsp), %rdx
    1581:      	xorl	%esi, %esi
    1583:      	cmpl	%ebp, %r13d
    1586:      	seta	%sil
    158a:      	movl	%ebp, %ecx
    158c:      	cmovbl	%r13d, %ecx
    1590:      	addl	%ecx, %esi
    1592:      	movl	%r13d, %edi
    1595:      	subl	%esi, %edi
    1597:      	movl	%edi, 0xa0(%rsp)
    159e:      	subq	%rsi, %rax
    15a1:      	jb	0x1677 <generic_rawtp_process_event+0x14a7>
    15a7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    15ad:      	ja	0x1677 <generic_rawtp_process_event+0x14a7>
    15b3:      	cmpl	%ebp, %r13d
    15b6:      	jbe	0x15bd <generic_rawtp_process_event+0x13ed>
    15b8:      	movb	$0x2f, (%r12,%rax)
    15bd:      	xorl	%edi, %edi
    15bf:      	cmpl	%ebp, %r13d
    15c2:      	seta	%dil
    15c6:      	movzbl	%cl, %esi
    15c9:      	addq	%rax, %r12
    15cc:      	addq	%r12, %rdi
    15cf:      	movl	$0x4, %eax
    15d4:      	callq	*%rax
    15d6:      	movq	%r12, 0x98(%rsp)
    15de:      	cmpl	%ebp, %r13d
    15e1:      	jbe	0x1677 <generic_rawtp_process_event+0x14a7>
    15e7:      	movq	0x50(%rsp), %rax
    15ec:      	movq	%rax, 0x80(%rsp)
    15f4:      	movl	$0x8, %r13d
    15fa:      	decl	%r15d
    15fd:      	jne	0x14a9 <generic_rawtp_process_event+0x12d9>
    1603:      	jmp	0x1677 <generic_rawtp_process_event+0x14a7>
    1605:      	leaq	0x10(%r12), %rdx
    160a:      	movl	$0x4, %eax
    160f:      	leaq	0x30(%rsp), %rdi
    1614:      	movl	$0x8, %esi
    1619:      	callq	*%rax
    161b:      	movq	0x90(%rsp), %rax
    1623:      	cmpq	0x30(%rsp), %rax
    1628:      	movl	$0x8, %r13d
    162e:      	je	0x166f <generic_rawtp_process_event+0x149f>
    1630:      	addq	$0x18, %r12
    1634:      	movl	$0x4, %eax
    1639:      	leaq	0x80(%rsp), %rdi
    1641:      	movl	$0x8, %esi
    1646:      	movq	%r12, %rdx
    1649:      	callq	*%rax
    164b:      	movq	0x30(%rsp), %rax
    1650:      	movq	%rax, 0x90(%rsp)
    1658:      	addq	$0x20, %rax
    165c:      	movq	%rax, 0x88(%rsp)
    1664:      	decl	%r15d
    1667:      	jne	0x14a9 <generic_rawtp_process_event+0x12d9>
    166d:      	jmp	0x1677 <generic_rawtp_process_event+0x14a7>
    166f:      	movb	$0x1, 0xa4(%rsp)
    1677:      	movq	0x98(%rsp), %rax
    167f:      	movq	0x10(%rsp), %rdx
    1684:      	cmpq	%rdx, %rax
    1687:      	je	0x16c8 <generic_rawtp_process_event+0x14f8>
    1689:      	xorl	%ebp, %ebp
    168b:      	cmpb	$0x0, 0xa4(%rsp)
    1693:      	sete	%cl
    1696:      	movl	0xa0(%rsp), %edx
    169d:      	movl	$0x1000, %r13d          # imm = 0x1000
    16a3:      	subl	%edx, %r13d
    16a6:      	testl	%edx, %edx
    16a8:      	cmovlel	%edx, %r13d
    16ac:      	testq	%rax, %rax
    16af:      	movq	0x48(%rsp), %r15
    16b4:      	je	0x16c0 <generic_rawtp_process_event+0x14f0>
    16b6:      	movb	%cl, %bpl
    16b9:      	addl	%ebp, %ebp
    16bb:      	movq	%rax, %rdx
    16be:      	jmp	0x16d2 <generic_rawtp_process_event+0x1502>
    16c0:      	xorl	%r13d, %r13d
    16c3:      	jmp	0x1775 <generic_rawtp_process_event+0x15a5>
    16c8:      	xorl	%r13d, %r13d
    16cb:      	xorl	%ebp, %ebp
    16cd:      	movq	0x48(%rsp), %r15
    16d2:      	leaq	0x4(%r15), %rdi
    16d6:      	andl	$0xfff, %r13d           # imm = 0xFFF
    16dd:      	movl	$0x4, %eax
    16e2:      	movl	%r13d, %esi
    16e5:      	callq	*%rax
    16e7:      	movl	%r13d, (%r15)
    16ea:      	leaq	0x68(%rsp), %rdi
    16ef:      	movl	$0x8, %ecx
    16f4:      	movl	$0x4, %eax
    16f9:      	movq	0x40(%rsp), %rdx
    16fe:      	movl	$0x8, %esi
    1703:      	callq	*%rax
    1705:      	movq	0x68(%rsp), %rcx
    170a:      	addq	$0x30, %rcx
    170e:      	leaq	0x58(%rsp), %rdi
    1713:      	movl	$0x8, %edx
    1718:      	movl	$0x4, %eax
    171d:      	movq	0x68(%rsp), %rdx
    1722:      	addq	$0x30, %rdx
    1726:      	movl	$0x8, %esi
    172b:      	callq	*%rax
    172d:      	movq	0x58(%rsp), %rcx
    1732:      	leaq	0x30(%rsp), %rdi
    1737:      	movl	$0x2, %edx
    173c:      	movl	$0x4, %eax
    1741:      	movq	0x58(%rsp), %rdx
    1746:      	movl	$0x2, %esi
    174b:      	callq	*%rax
    174d:      	movl	%ebp, 0x4(%r15,%r13)
    1752:      	movzwl	0x30(%rsp), %eax
    1757:      	movw	%ax, 0x8(%r15,%r13)
    175d:      	addl	$0xa, %r13d
    1761:      	movq	0x38(%rsp), %rax
    1766:      	movq	0x20(%rsp), %rcx
    176b:      	movl	$0x4, %esi
    1770:      	testl	%r13d, %r13d
    1773:      	js	0x1788 <generic_rawtp_process_event+0x15b8>
    1775:      	andl	$0x7fffffff, %r13d      # imm = 0x7FFFFFFF
    177c:      	addq	$0x4, %r13
    1780:      	movq	%r13, %rsi
    1783:      	jmp	0xdaf <generic_rawtp_process_event+0xbdf>
    1788:      	movl	$0xffffffff, 0x5ea0(%rax,%rcx,4) # imm = 0xFFFFFFFF
    1793:      	movq	0xc8(%rsp), %rcx
    179b:      	movl	$0xffffffff, 0x90(%rax,%rcx) # imm = 0xFFFFFFFF
    17a6:      	jmp	0xdaf <generic_rawtp_process_event+0xbdf>
    17ab:      	movq	%rdi, 0x48(%rsp)
    17b0:      	leaq	0x58(%rsp), %rdi
    17b5:      	leaq	0x68(%rsp), %rdx
    17ba:      	movl	$0x8, %ecx
    17bf:      	movl	$0x4, %eax
    17c4:      	movl	$0x8, %esi
    17c9:      	callq	*%rax
    17cb:      	movq	0x58(%rsp), %rax
    17d0:      	movq	%rax, 0xa8(%rsp)
    17d8:      	testq	%rax, %rax
    17db:      	jne	0x109d <generic_rawtp_process_event+0xecd>
    17e1:      	movl	$0x0, 0xe0(%rsp)
    17ec:      	movq	(%rip), %rdi            # 0x17f3 <generic_rawtp_process_event+0x1623>
    17f3:      	leaq	0xe0(%rsp), %rsi
    17fb:      	movl	$0x1, %eax
    1800:      	callq	*%rax
    1802:      	testq	%rax, %rax
    1805:      	je	0x1920 <generic_rawtp_process_event+0x1750>
    180b:      	cmpl	$0x19, %r13d
    180f:      	movq	%rbx, 0x18(%rsp)
    1814:      	movq	%r14, 0x28(%rsp)
    1819:      	jg	0x1ba2 <generic_rawtp_process_event+0x19d2>
    181f:      	cmpl	$0x12, %r13d
    1823:      	jle	0x1d1b <generic_rawtp_process_event+0x1b4b>
    1829:      	movq	%r13, %rax
    182c:      	cmpl	$0x14, %r13d
    1830:      	jle	0x20ac <generic_rawtp_process_event+0x1edc>
    1836:      	cmpl	$0x15, %eax
    1839:      	je	0x2a4e <generic_rawtp_process_event+0x287e>
    183f:      	cmpl	$0x16, %eax
    1842:      	je	0x29c6 <generic_rawtp_process_event+0x27f6>
    1848:      	cmpl	$0x17, %eax
    184b:      	movq	0x18(%rsp), %rbx
    1850:      	movq	0x28(%rsp), %r14
    1855:      	movl	$0x0, %r13d
    185b:      	jne	0x1761 <generic_rawtp_process_event+0x1591>
    1861:      	movl	$0x0, 0x4(%r15)
    1869:      	movq	0x10(%rsp), %rax
    186e:      	movl	%eax, (%r15)
    1871:      	movl	$0x8, %r13d
    1877:      	jmp	0x1761 <generic_rawtp_process_event+0x1591>
    187c:      	movq	%rdi, 0x48(%rsp)
    1881:      	cmpl	$0x2c, %r13d
    1885:      	ja	0x17e1 <generic_rawtp_process_event+0x1611>
    188b:      	movabsq	$0x11c1f2027cf2, %rax   # imm = 0x11C1F2027CF2
    1895:      	btq	%rbp, %rax
    1899:      	jae	0x17e1 <generic_rawtp_process_event+0x1611>
    189f:      	movq	%rdx, 0x50(%rsp)
    18a4:      	movl	$0x0, 0xe0(%rsp)
    18af:      	movq	(%rip), %rdi            # 0x18b6 <generic_rawtp_process_event+0x16e6>
    18b6:      	leaq	0xe0(%rsp), %rsi
    18be:      	movl	$0x1, %eax
    18c3:      	callq	*%rax
    18c5:      	testq	%rax, %rax
    18c8:      	je	0x1920 <generic_rawtp_process_event+0x1750>
    18ca:      	movq	%r15, %rbp
    18cd:      	cmpl	$0x10, %r13d
    18d1:      	jle	0x1928 <generic_rawtp_process_event+0x1758>
    18d3:      	cmpl	$0x1e, %r13d
    18d7:      	jle	0x1aa8 <generic_rawtp_process_event+0x18d8>
    18dd:      	movq	%r14, %r15
    18e0:      	movq	%rbx, 0x18(%rsp)
    18e5:      	cmpl	$0x26, %r13d
    18e9:      	jg	0x1be5 <generic_rawtp_process_event+0x1a15>
    18ef:      	leal	-0x1f(%r13), %eax
    18f3:      	cmpl	$0x2, %eax
    18f6:      	jae	0x2188 <generic_rawtp_process_event+0x1fb8>
    18fc:      	leaq	0x50(%rsp), %rdx
    1901:      	movl	$0x4, %r13d
    1907:      	movl	$0x1, %ecx
    190c:      	movl	$0x4, %eax
    1911:      	movq	%rbp, %rdi
    1914:      	movl	$0x1, %esi
    1919:      	callq	*%rax
    191b:      	jmp	0x2fe6 <generic_rawtp_process_event+0x2e16>
    1920:      	xorl	%r13d, %r13d
    1923:      	jmp	0x1761 <generic_rawtp_process_event+0x1591>
    1928:      	cmpl	$0x9, %r13d
    192c:      	jg	0x1ae1 <generic_rawtp_process_event+0x1911>
    1932:      	movq	%r14, 0x28(%rsp)
    1937:      	movq	%rbx, 0x18(%rsp)
    193c:      	cmpl	$0x4, %r13d
    1940:      	jle	0x1db2 <generic_rawtp_process_event+0x1be2>
    1946:      	cmpl	$0x5, %r13d
    194a:      	je	0x24fd <generic_rawtp_process_event+0x232d>
    1950:      	movq	%rax, %r15
    1953:      	movq	%r13, %rax
    1956:      	cmpl	$0x6, %eax
    1959:      	je	0x1b6c <generic_rawtp_process_event+0x199c>
    195f:      	cmpl	$0x7, %eax
    1962:      	movq	0x38(%rsp), %rax
    1967:      	movq	0x20(%rsp), %rcx
    196c:      	movl	$0x4, %esi
    1971:      	movq	0x18(%rsp), %rbx
    1976:      	movq	0x28(%rsp), %r14
    197b:      	movl	$0x0, %r13d
    1981:      	jne	0x1770 <generic_rawtp_process_event+0x15a0>
    1987:      	movq	0x50(%rsp), %r12
    198c:      	movq	%rbp, %rbx
    198f:      	movq	%r12, 0x28(%rbp)
    1993:      	leaq	0x26(%rbp), %rdi
    1997:      	leaq	0x10(%r12), %rdx
    199c:      	movl	$0x2, %ecx
    19a1:      	movl	$0x4, %eax
    19a6:      	movl	$0x2, %esi
    19ab:      	callq	*%rax
    19ad:      	leaq	0x3a(%rbp), %rdi
    19b1:      	leaq	0x12(%r12), %rdx
    19b6:      	movl	$0x1, %ecx
    19bb:      	movl	$0x4, %eax
    19c0:      	movl	$0x1, %esi
    19c5:      	callq	*%rax
    19c7:      	leaq	0x38(%rbp), %rdi
    19cb:      	leaq	0x226(%r12), %rdx
    19d3:      	movl	$0x2, %ecx
    19d8:      	movl	$0x4, %eax
    19dd:      	movl	$0x2, %esi
    19e2:      	callq	*%rax
    19e4:      	leaq	0x24(%rbp), %rdi
    19e8:      	leaq	0x224(%r12), %rdx
    19f0:      	movl	$0x2, %ecx
    19f5:      	movl	$0x4, %eax
    19fa:      	movl	$0x2, %esi
    19ff:      	callq	*%rax
    1a01:      	leaq	0x30(%rbp), %rdi
    1a05:      	leaq	0x21c(%r12), %rdx
    1a0d:      	movl	$0x4, %ecx
    1a12:      	movl	$0x4, %eax
    1a17:      	movl	$0x4, %esi
    1a1c:      	callq	*%rax
    1a1e:      	leaq	0x34(%rbp), %rdi
    1a22:      	leaq	0x218(%r12), %rdx
    1a2a:      	movl	$0x4, %ecx
    1a2f:      	movl	$0x4, %eax
    1a34:      	movl	$0x4, %esi
    1a39:      	callq	*%rax
    1a3b:      	leaq	0x10(%rbp), %r13
    1a3f:      	movq	$0x0, (%rbp)
    1a47:      	movq	$0x0, 0x8(%rbp)
    1a4f:      	movq	$0x0, 0x10(%rbp)
    1a57:      	movq	$0x0, 0x18(%rbp)
    1a5f:      	movzwl	0x26(%rbp), %eax
    1a63:      	cmpl	$0xa, %eax
    1a66:      	je	0x2d1e <generic_rawtp_process_event+0x2b4e>
    1a6c:      	cmpl	$0x2, %eax
    1a6f:      	jne	0x2d50 <generic_rawtp_process_event+0x2b80>
    1a75:      	leaq	0x4(%r12), %rdx
    1a7a:      	movl	$0x4, %ecx
    1a7f:      	movl	$0x4, %eax
    1a84:      	movq	%rbp, %rdi
    1a87:      	movl	$0x4, %esi
    1a8c:      	callq	*%rax
    1a8e:      	movl	$0x4, %ecx
    1a93:      	movl	$0x4, %eax
    1a98:      	movq	%r13, %rdi
    1a9b:      	movl	$0x4, %esi
    1aa0:      	movq	%r12, %rdx
    1aa3:      	jmp	0x2d4e <generic_rawtp_process_event+0x2b7e>
    1aa8:      	cmpl	$0x1c, %r13d
    1aac:      	jg	0x1d8e <generic_rawtp_process_event+0x1bbe>
    1ab2:      	movq	%rax, %r15
    1ab5:      	movq	%r13, %rax
    1ab8:      	cmpl	$0x11, %eax
    1abb:      	je	0x21d5 <generic_rawtp_process_event+0x2005>
    1ac1:      	cmpl	$0x19, %eax
    1ac4:      	je	0x2291 <generic_rawtp_process_event+0x20c1>
    1aca:      	cmpl	$0x1c, %eax
    1acd:      	movq	0x38(%rsp), %rax
    1ad2:      	movq	0x20(%rsp), %rcx
    1ad7:      	movl	$0x4, %esi
    1adc:      	jmp	0x1dd7 <generic_rawtp_process_event+0x1c07>
    1ae1:      	leal	-0xa(%r13), %eax
    1ae5:      	cmpl	$0x2, %eax
    1ae8:      	jb	0x1de3 <generic_rawtp_process_event+0x1c13>
    1aee:      	movq	%r13, %rcx
    1af1:      	movq	%r14, 0x28(%rsp)
    1af6:      	movq	%rbx, 0x18(%rsp)
    1afb:      	leal	-0xc(%r13), %eax
    1aff:      	cmpl	$0x2, %eax
    1b02:      	jb	0x1e16 <generic_rawtp_process_event+0x1c46>
    1b08:      	cmpl	$0xe, %ecx
    1b0b:      	movq	0x38(%rsp), %rax
    1b10:      	movq	0x20(%rsp), %rcx
    1b15:      	movl	$0x4, %esi
    1b1a:      	movq	0x18(%rsp), %rbx
    1b1f:      	movq	0x28(%rsp), %r14
    1b24:      	movl	$0x0, %r13d
    1b2a:      	jne	0x1770 <generic_rawtp_process_event+0x15a0>
    1b30:      	leaq	0x68(%rsp), %rdi
    1b35:      	leaq	0x50(%rsp), %r12
    1b3a:      	movl	$0x8, %ecx
    1b3f:      	movl	$0x4, %eax
    1b44:      	movl	$0x8, %esi
    1b49:      	movq	%r12, %rdx
    1b4c:      	callq	*%rax
    1b4e:      	movq	0x68(%rsp), %rcx
    1b53:      	movl	$0x8, %edx
    1b58:      	movl	$0x4, %eax
    1b5d:      	movq	0x68(%rsp), %rdx
    1b62:      	movq	%r12, %rdi
    1b65:      	movl	$0x8, %esi
    1b6a:      	callq	*%rax
    1b6c:      	movq	0x50(%rsp), %rdx
    1b71:      	leaq	0x4(%rbp), %rdi
    1b75:      	movl	$0x1001, %ecx           # imm = 0x1001
    1b7a:      	movl	$0x2d, %eax
    1b7f:      	movl	$0x1001, %esi           # imm = 0x1001
    1b84:      	callq	*%rax
    1b86:      	movq	%rax, %r13
    1b89:      	testq	%rax, %rax
    1b8c:      	js	0x424f <generic_rawtp_process_event+0x407f>
    1b92:      	leal	-0x1(%r13), %eax
    1b96:      	movl	%eax, (%rbp)
    1b99:      	addq	$0x3, %r13
    1b9d:      	jmp	0x424f <generic_rawtp_process_event+0x407f>
    1ba2:      	movq	%rax, 0x40(%rsp)
    1ba7:      	movq	%r15, %rbp
    1baa:      	cmpl	$0x20, %r13d
    1bae:      	jle	0x1fa3 <generic_rawtp_process_event+0x1dd3>
    1bb4:      	leal	-0x21(%r13), %eax
    1bb8:      	cmpl	$0x4, %eax
    1bbb:      	jae	0x1e3a <generic_rawtp_process_event+0x1c6a>
    1bc1:      	movl	$0x8, %r13d
    1bc7:      	movl	$0x8, %ecx
    1bcc:      	movl	$0x4, %eax
    1bd1:      	movq	0x10(%rsp), %rdx
    1bd6:      	movq	%rbp, %rdi
    1bd9:      	movl	$0x8, %esi
    1bde:      	callq	*%rax
    1be0:      	jmp	0x3eba <generic_rawtp_process_event+0x3cea>
    1be5:      	cmpl	$0x27, %r13d
    1be9:      	je	0x26af <generic_rawtp_process_event+0x24df>
    1bef:      	movq	%r13, %rax
    1bf2:      	cmpl	$0x28, %eax
    1bf5:      	je	0x26ea <generic_rawtp_process_event+0x251a>
    1bfb:      	cmpl	$0x2c, %eax
    1bfe:      	movq	0x38(%rsp), %rax
    1c03:      	movq	0x20(%rsp), %rcx
    1c08:      	movl	$0x4, %esi
    1c0d:      	movq	0x18(%rsp), %rbx
    1c12:      	movq	%r15, %r14
    1c15:      	movl	$0x0, %r13d
    1c1b:      	jne	0x1770 <generic_rawtp_process_event+0x15a0>
    1c21:      	movq	0x50(%rsp), %r12
    1c26:      	movb	$0x0, 0x68(%rsp)
    1c2b:      	movq	%rbp, %rdi
    1c2e:      	movq	$0x0, 0x68(%rbp)
    1c36:      	movq	$0x0, 0x60(%rbp)
    1c3e:      	movq	$0x0, 0x58(%rbp)
    1c46:      	movq	$0x0, 0x50(%rbp)
    1c4e:      	movq	$0x0, 0x48(%rbp)
    1c56:      	movq	$0x0, 0x40(%rbp)
    1c5e:      	movq	$0x0, 0x38(%rbp)
    1c66:      	movq	$0x0, 0x30(%rbp)
    1c6e:      	movq	$0x0, 0x28(%rbp)
    1c76:      	movq	$0x0, 0x20(%rbp)
    1c7e:      	movq	$0x0, 0x18(%rbp)
    1c86:      	movq	$0x0, 0x10(%rbp)
    1c8e:      	movq	$0x0, 0x8(%rbp)
    1c96:      	movq	$0x0, (%rbp)
    1c9e:      	movl	$0x2, %ecx
    1ca3:      	movl	$0x4, %eax
    1ca8:      	movl	$0x2, %esi
    1cad:      	movq	%r12, %rdx
    1cb0:      	callq	*%rax
    1cb2:      	testq	%rax, %rax
    1cb5:      	js	0x2fe0 <generic_rawtp_process_event+0x2e10>
    1cbb:      	leaq	0x2(%r12), %r13
    1cc0:      	leaq	0x68(%rsp), %rdi
    1cc5:      	movl	$0x1, %ecx
    1cca:      	movl	$0x4, %eax
    1ccf:      	movl	$0x1, %esi
    1cd4:      	movq	%r13, %rdx
    1cd7:      	callq	*%rax
    1cd9:      	testq	%rax, %rax
    1cdc:      	js	0x2fe0 <generic_rawtp_process_event+0x2e10>
    1ce2:      	movq	%rbp, %rax
    1ce5:      	leaq	0x4(%rbp), %rdi
    1ce9:      	cmpb	$0x0, 0x68(%rsp)
    1cee:      	sete	0x2(%rbp)
    1cf2:      	je	0x2fbc <generic_rawtp_process_event+0x2dec>
    1cf8:      	movl	$0x6c, %ecx
    1cfd:      	movl	$0x2d, %eax
    1d02:      	movl	$0x6c, %esi
    1d07:      	movq	%r13, %rdx
    1d0a:      	callq	*%rax
    1d0c:      	testl	%eax, %eax
    1d0e:      	js	0x2fe0 <generic_rawtp_process_event+0x2e10>
    1d14:      	decb	%al
    1d16:      	jmp	0x2fdd <generic_rawtp_process_event+0x2e0d>
    1d1b:      	movq	%rax, %rbp
    1d1e:      	movq	%r13, %rax
    1d21:      	cmpl	$0x7, %r13d
    1d25:      	jg	0x2067 <generic_rawtp_process_event+0x1e97>
    1d2b:      	cmpl	$0x2, %eax
    1d2e:      	je	0x2777 <generic_rawtp_process_event+0x25a7>
    1d34:      	cmpl	$0x3, %eax
    1d37:      	movq	0x18(%rsp), %rbx
    1d3c:      	movq	0x28(%rsp), %r14
    1d41:      	movl	$0x0, %r13d
    1d47:      	jne	0x1761 <generic_rawtp_process_event+0x1591>
    1d4d:      	leaq	0x90(%rbp), %r13
    1d54:      	andl	$0xf, %r12d
    1d58:      	movq	%r12, %rax
    1d5b:      	cmpl	$0x2, %r12d
    1d5f:      	jle	0x2ea2 <generic_rawtp_process_event+0x2cd2>
    1d65:      	cmpl	$0x3, %eax
    1d68:      	je	0x3179 <generic_rawtp_process_event+0x2fa9>
    1d6e:      	cmpl	$0x4, %eax
    1d71:      	je	0x3184 <generic_rawtp_process_event+0x2fb4>
    1d77:      	cmpl	$0x5, %eax
    1d7a:      	jne	0x3531 <generic_rawtp_process_event+0x3361>
    1d80:      	movq	%rbp, %rax
    1d83:      	addq	$0x5e70, %rax           # imm = 0x5E70
    1d89:      	jmp	0x3198 <generic_rawtp_process_event+0x2fc8>
    1d8e:      	leaq	0x50(%rsp), %rdx
    1d93:      	movl	$0x4, %r13d
    1d99:      	movl	$0x2, %ecx
    1d9e:      	movl	$0x4, %eax
    1da3:      	movq	%rbp, %rdi
    1da6:      	movl	$0x2, %esi
    1dab:      	callq	*%rax
    1dad:      	jmp	0x1761 <generic_rawtp_process_event+0x1591>
    1db2:      	cmpl	$0x1, %r13d
    1db6:      	je	0x1e16 <generic_rawtp_process_event+0x1c46>
    1db8:      	movq	%r13, %rax
    1dbb:      	cmpl	$0x4, %eax
    1dbe:      	movq	0x38(%rsp), %rax
    1dc3:      	movq	0x20(%rsp), %rcx
    1dc8:      	movl	$0x4, %esi
    1dcd:      	movq	0x18(%rsp), %rbx
    1dd2:      	movq	0x28(%rsp), %r14
    1dd7:      	movl	$0x0, %r13d
    1ddd:      	jne	0x1770 <generic_rawtp_process_event+0x15a0>
    1de3:      	movl	$0x8, %r13d
    1de9:      	leaq	0x50(%rsp), %rdx
    1dee:      	movl	$0x8, %ecx
    1df3:      	movl	$0x4, %eax
    1df8:      	movq	%rbp, %rdi
    1dfb:      	movl	$0x8, %esi
    1e00:      	callq	*%rax
    1e02:      	movl	$0x4, %esi
    1e07:      	movq	0x20(%rsp), %rcx
    1e0c:      	movq	0x38(%rsp), %rax
    1e11:      	jmp	0x1770 <generic_rawtp_process_event+0x15a0>
    1e16:      	leaq	0x50(%rsp), %rdx
    1e1b:      	movl	$0x4, %r13d
    1e21:      	movl	$0x4, %ecx
    1e26:      	movl	$0x4, %eax
    1e2b:      	movq	%rbp, %rdi
    1e2e:      	movl	$0x4, %esi
    1e33:      	callq	*%rax
    1e35:      	jmp	0x424f <generic_rawtp_process_event+0x407f>
    1e3a:      	movq	%r13, %rcx
    1e3d:      	cmpl	$0x2b, %ecx
    1e40:      	je	0x2b3e <generic_rawtp_process_event+0x296e>
    1e46:      	cmpl	$0x29, %ecx
    1e49:      	movq	0x18(%rsp), %rbx
    1e4e:      	movq	0x28(%rsp), %r14
    1e53:      	movl	$0x0, %r13d
    1e59:      	jne	0x1761 <generic_rawtp_process_event+0x1591>
    1e5f:      	movq	0x10(%rsp), %rdx
    1e64:      	addq	$0x18, %rdx
    1e68:      	leaq	0x68(%rsp), %rdi
    1e6d:      	movl	$0x4, %ebx
    1e72:      	movl	$0x8, %ecx
    1e77:      	movl	$0x4, %eax
    1e7c:      	movl	$0x8, %esi
    1e81:      	callq	*%rax
    1e83:      	movq	0x68(%rsp), %r12
    1e88:      	testq	%r12, %r12
    1e8b:      	je	0x3135 <generic_rawtp_process_event+0x2f65>
    1e91:      	movq	%rbp, %r15
    1e94:      	movq	%r12, 0x28(%rbp)
    1e98:      	leaq	0x26(%rbp), %rdi
    1e9c:      	leaq	0x10(%r12), %rdx
    1ea1:      	movl	$0x2, %ecx
    1ea6:      	movl	$0x4, %eax
    1eab:      	movl	$0x2, %esi
    1eb0:      	callq	*%rax
    1eb2:      	leaq	0x3a(%rbp), %rdi
    1eb6:      	leaq	0x12(%r12), %rdx
    1ebb:      	movl	$0x1, %ecx
    1ec0:      	movl	$0x4, %eax
    1ec5:      	movl	$0x1, %esi
    1eca:      	callq	*%rax
    1ecc:      	leaq	0x38(%rbp), %rdi
    1ed0:      	leaq	0x226(%r12), %rdx
    1ed8:      	movl	$0x2, %ecx
    1edd:      	movl	$0x4, %eax
    1ee2:      	movl	$0x2, %esi
    1ee7:      	callq	*%rax
    1ee9:      	leaq	0x24(%rbp), %rdi
    1eed:      	leaq	0x224(%r12), %rdx
    1ef5:      	movl	$0x2, %ecx
    1efa:      	movl	$0x4, %eax
    1eff:      	movl	$0x2, %esi
    1f04:      	callq	*%rax
    1f06:      	leaq	0x30(%rbp), %rdi
    1f0a:      	leaq	0x21c(%r12), %rdx
    1f12:      	movl	$0x4, %eax
    1f17:      	movl	$0x4, %esi
    1f1c:      	callq	*%rax
    1f1e:      	leaq	0x34(%rbp), %rdi
    1f22:      	leaq	0x218(%r12), %rdx
    1f2a:      	movl	$0x4, %eax
    1f2f:      	movl	$0x4, %esi
    1f34:      	callq	*%rax
    1f36:      	leaq	0x10(%rbp), %r13
    1f3a:      	movq	$0x0, (%rbp)
    1f42:      	movq	$0x0, 0x8(%rbp)
    1f4a:      	movq	$0x0, 0x10(%rbp)
    1f52:      	movq	$0x0, 0x18(%rbp)
    1f5a:      	movzwl	0x26(%rbp), %eax
    1f5e:      	cmpl	$0xa, %eax
    1f61:      	je	0x30bd <generic_rawtp_process_event+0x2eed>
    1f67:      	cmpl	$0x2, %eax
    1f6a:      	jne	0x30ef <generic_rawtp_process_event+0x2f1f>
    1f70:      	leaq	0x4(%r12), %rdx
    1f75:      	movl	$0x4, %ecx
    1f7a:      	movl	$0x4, %eax
    1f7f:      	movq	%rbp, %rdi
    1f82:      	movl	$0x4, %esi
    1f87:      	callq	*%rax
    1f89:      	movl	$0x4, %ecx
    1f8e:      	movl	$0x4, %eax
    1f93:      	movq	%r13, %rdi
    1f96:      	movl	$0x4, %esi
    1f9b:      	movq	%r12, %rdx
    1f9e:      	jmp	0x30ed <generic_rawtp_process_event+0x2f1d>
    1fa3:      	cmpl	$0x1a, %r13d
    1fa7:      	je	0x2bd7 <generic_rawtp_process_event+0x2a07>
    1fad:      	movq	%r13, %rax
    1fb0:      	cmpl	$0x1b, %eax
    1fb3:      	movq	0x18(%rsp), %rbx
    1fb8:      	movq	0x28(%rsp), %r14
    1fbd:      	movl	$0x0, %r13d
    1fc3:      	jne	0x1761 <generic_rawtp_process_event+0x1591>
    1fc9:      	movq	$0x0, 0x48(%rbp)
    1fd1:      	movq	$0x0, 0x40(%rbp)
    1fd9:      	movq	$0x0, 0x38(%rbp)
    1fe1:      	movq	$0x0, 0x30(%rbp)
    1fe9:      	movq	$0x0, 0x28(%rbp)
    1ff1:      	movq	$0x0, 0x20(%rbp)
    1ff9:      	movq	$0x0, 0x18(%rbp)
    2001:      	movq	$0x0, 0x10(%rbp)
    2009:      	movq	$0x0, 0x8(%rbp)
    2011:      	movq	$0x0, (%rbp)
    2019:      	leaq	0x10(%rbp), %rdi
    201d:      	movq	0x10(%rsp), %rax
    2022:      	leaq	0x18(%rax), %rdx
    2026:      	movl	$0x3f, %ecx
    202b:      	movl	$0x2d, %eax
    2030:      	movl	$0x3f, %esi
    2035:      	callq	*%rax
    2037:      	testq	%rax, %rax
    203a:      	js	0x2c4b <generic_rawtp_process_event+0x2a7b>
    2040:      	addq	$0x8, %rbp
    2044:      	movq	0x10(%rsp), %rdx
    2049:      	addq	$0x348, %rdx            # imm = 0x348
    2050:      	movl	$0x8, %ecx
    2055:      	movl	$0x4, %eax
    205a:      	movq	%rbp, %rdi
    205d:      	movl	$0x8, %esi
    2062:      	jmp	0x29b9 <generic_rawtp_process_event+0x27e9>
    2067:      	cmpl	$0x8, %eax
    206a:      	je	0x27e0 <generic_rawtp_process_event+0x2610>
    2070:      	cmpl	$0x12, %eax
    2073:      	movq	0x18(%rsp), %rbx
    2078:      	movq	0x28(%rsp), %r14
    207d:      	movl	$0x0, %r13d
    2083:      	jne	0x1761 <generic_rawtp_process_event+0x1591>
    2089:      	movq	0x40(%rsp), %r13
    208e:      	andl	$0x3ff, %r13d           # imm = 0x3FF
    2095:      	movl	$0x4, %eax
    209a:      	movq	0x10(%rsp), %rdx
    209f:      	movq	%r15, %rdi
    20a2:      	movl	%r13d, %esi
    20a5:      	callq	*%rax
    20a7:      	jmp	0x1761 <generic_rawtp_process_event+0x1591>
    20ac:      	cmpl	$0x13, %eax
    20af:      	je	0x2ae4 <generic_rawtp_process_event+0x2914>
    20b5:      	cmpl	$0x14, %eax
    20b8:      	movq	0x18(%rsp), %rbx
    20bd:      	movq	0x28(%rsp), %r14
    20c2:      	movl	$0x0, %r13d
    20c8:      	jne	0x1761 <generic_rawtp_process_event+0x1591>
    20ce:      	movq	$0x0, 0x68(%rsp)
    20d7:      	movq	0x10(%rsp), %r13
    20dc:      	leaq	0x110(%r13), %rdx
    20e3:      	leaq	0x68(%rsp), %rdi
    20e8:      	movl	$0x8, %ecx
    20ed:      	movl	$0x4, %eax
    20f2:      	leaq	0xd8(%r13), %r12
    20f9:      	movl	$0x8, %esi
    20fe:      	callq	*%rax
    2100:      	movq	0x68(%rsp), %rcx
    2105:      	movl	$0x80, %edx
    210a:      	movl	$0x2d, %eax
    210f:      	movq	0x68(%rsp), %rdx
    2114:      	movq	%r15, %rdi
    2117:      	movl	$0x80, %esi
    211c:      	callq	*%rax
    211e:      	leaq	0x90(%r15), %rdi
    2125:      	movl	$0x4, %ecx
    212a:      	movl	$0x4, %eax
    212f:      	movl	$0x4, %esi
    2134:      	movq	%r12, %rdx
    2137:      	callq	*%rax
    2139:      	leaq	0x80(%r15), %rdi
    2140:      	leaq	0xe0(%r13), %rdx
    2147:      	movl	$0x8, %ecx
    214c:      	movl	$0x4, %eax
    2151:      	movl	$0x8, %esi
    2156:      	callq	*%rax
    2158:      	addq	$0x88, %r15
    215f:      	addq	$0x118, %r13            # imm = 0x118
    2166:      	movl	$0x8, %ecx
    216b:      	movl	$0x4, %eax
    2170:      	movq	%r15, %rdi
    2173:      	movl	$0x8, %esi
    2178:      	movq	%r13, %rdx
    217b:      	callq	*%rax
    217d:      	movl	$0x98, %r13d
    2183:      	jmp	0x1761 <generic_rawtp_process_event+0x1591>
    2188:      	movq	%r13, %rcx
    218b:      	cmpl	$0x26, %ecx
    218e:      	movq	0x38(%rsp), %rax
    2193:      	movq	0x20(%rsp), %rcx
    2198:      	movl	$0x4, %esi
    219d:      	movq	0x18(%rsp), %rbx
    21a2:      	movq	%r15, %r14
    21a5:      	movl	$0x0, %r13d
    21ab:      	jne	0x1770 <generic_rawtp_process_event+0x15a0>
    21b1:      	movq	0x50(%rsp), %rsi
    21b6:      	movzwl	%si, %edx
    21b9:      	addq	%rbx, %rdx
    21bc:      	shrl	$0x10, %esi
    21bf:      	andl	$0xfff, %esi            # imm = 0xFFF
    21c5:      	leaq	0x4(%rbp), %rdi
    21c9:      	incl	%esi
    21cb:      	movl	$0x2d, %eax
    21d0:      	jmp	0x26cc <generic_rawtp_process_event+0x24fc>
    21d5:      	movq	$0x0, 0x70(%rsp)
    21de:      	movl	$0xe, %eax
    21e3:      	callq	*%rax
    21e5:      	shrq	$0x20, %rax
    21e9:      	movq	%rax, 0x68(%rsp)
    21ee:      	leaq	0x58(%rsp), %rdi
    21f3:      	leaq	0x50(%rsp), %rdx
    21f8:      	movl	$0x4, %ecx
    21fd:      	movl	$0x4, %eax
    2202:      	movl	$0x4, %esi
    2207:      	callq	*%rax
    2209:      	movl	0x58(%rsp), %eax
    220d:      	movl	%eax, 0x70(%rsp)
    2211:      	movq	(%rip), %rdi            # 0x2218 <generic_rawtp_process_event+0x2048>
    2218:      	leaq	0x68(%rsp), %rsi
    221d:      	movl	$0x1, %eax
    2222:      	callq	*%rax
    2224:      	testq	%rax, %rax
    2227:      	je	0x2c6f <generic_rawtp_process_event+0x2a9f>
    222d:      	movq	%rax, %r13
    2230:      	movl	(%rax), %r15d
    2233:      	leaq	0x58(%rsp), %rdx
    2238:      	movl	$0x4, %eax
    223d:      	movq	%rbp, %r12
    2240:      	movl	$0x4, %ebp
    2245:      	movq	%r12, %rdi
    2248:      	movl	$0x4, %esi
    224d:      	callq	*%rax
    224f:      	andl	$0xfff, %r15d           # imm = 0xFFF
    2256:      	leaq	0x4(%r12), %rdi
    225b:      	leaq	0x4(%r15), %rsi
    225f:      	movl	$0x4, %eax
    2264:      	movq	%r13, %rdx
    2267:      	callq	*%rax
    2269:      	leaq	(%r12,%r15), %rdi
    226d:      	addq	$0x8, %rdi
    2271:      	leaq	(%r15,%r13), %rdx
    2275:      	addq	$0x4, %rdx
    2279:      	movl	$0x4, %eax
    227e:      	movl	$0x4, %esi
    2283:      	callq	*%rax
    2285:      	addq	$0xc, %r15
    2289:      	movq	%r15, %r13
    228c:      	jmp	0x1761 <generic_rawtp_process_event+0x1591>
    2291:      	movq	0x50(%rsp), %r13
    2296:      	leaq	0xd0(%rsp), %rdi
    229e:      	movl	$0x1, %ecx
    22a3:      	movl	$0x4, %eax
    22a8:      	movl	$0x1, %esi
    22ad:      	movq	%r13, %rdx
    22b0:      	callq	*%rax
    22b2:      	cmpb	$0x1, 0xd0(%rsp)
    22ba:      	jne	0x2c53 <generic_rawtp_process_event+0x2a83>
    22c0:      	addq	$0x10, %r13
    22c4:      	leaq	0x58(%rsp), %rdi
    22c9:      	movl	$0x8, %ebp
    22ce:      	movl	$0x8, %ecx
    22d3:      	movl	$0x4, %eax
    22d8:      	movl	$0x8, %esi
    22dd:      	movq	%r13, %rdx
    22e0:      	callq	*%rax
    22e2:      	movq	0x58(%rsp), %rdx
    22e7:      	leaq	0xb0(%rsp), %rdi
    22ef:      	movl	$0x8, %ecx
    22f4:      	movl	$0x4, %eax
    22f9:      	movl	$0x8, %esi
    22fe:      	callq	*%rax
    2300:      	movq	0x58(%rsp), %rdx
    2305:      	addq	$0x8, %rdx
    2309:      	leaq	0x30(%rsp), %rdi
    230e:      	movl	$0x8, %ecx
    2313:      	movl	$0x4, %eax
    2318:      	movl	$0x8, %esi
    231d:      	callq	*%rax
    231f:      	movq	0xb0(%rsp), %rax
    2327:      	movq	%rax, 0xa8(%rsp)
    232f:      	movq	0x30(%rsp), %rax
    2334:      	movq	%rax, 0x10(%rsp)
    2339:      	movq	0x48(%rsp), %rax
    233e:      	addq	%r15, %rax
    2341:      	addq	$0x90, %rax
    2347:      	movq	%rax, 0x40(%rsp)
    234c:      	testb	$0x20, %r12b
    2350:      	je	0x302b <generic_rawtp_process_event+0x2e5b>
    2356:      	cmpq	$0x1000, 0x10(%rsp)     # imm = 0x1000
    235f:      	jb	0x3002 <generic_rawtp_process_event+0x2e32>
    2365:      	movq	0x40(%rsp), %rax
    236a:      	movl	$0x1, (%rax)
    2370:      	movl	$0x0, 0xc0(%rsp)
    237b:      	movq	(%rip), %rdi            # 0x2382 <generic_rawtp_process_event+0x21b2>
    2382:      	leaq	0xc0(%rsp), %rsi
    238a:      	movl	$0x1, %eax
    238f:      	callq	*%rax
    2391:      	movq	%rax, 0x48(%rsp)
    2396:      	testq	%rax, %rax
    2399:      	je	0x36ec <generic_rawtp_process_event+0x351c>
    239f:      	movq	0x48(%rsp), %r12
    23a4:      	movl	$0x18, (%r12)
    23ac:      	movl	$0xe, %eax
    23b1:      	callq	*%rax
    23b3:      	leaq	0x10(%r12), %r15
    23b8:      	movq	%rax, 0x10(%r12)
    23bd:      	cmpq	$-0x16, %rax
    23c1:      	jne	0x23e5 <generic_rawtp_process_event+0x2215>
    23c3:      	leaq	0x20(%rbx), %rdx
    23c7:      	leaq	0x68(%rsp), %rdi
    23cc:      	movl	$0x8, %ecx
    23d1:      	movl	$0x4, %eax
    23d6:      	movl	$0x8, %esi
    23db:      	callq	*%rax
    23dd:      	movq	0x68(%rsp), %rax
    23e2:      	movq	%rax, (%r15)
    23e5:      	movl	$0x7d, %eax
    23ea:      	callq	*%rax
    23ec:      	movq	0x48(%rsp), %rsi
    23f1:      	movq	%rax, 0x18(%rsi)
    23f5:      	movq	(%r15), %rax
    23f8:      	movq	0x8(%r15), %rcx
    23fc:      	movq	0x40(%rsp), %rdx
    2401:      	movq	%rax, 0x14(%rdx)
    2405:      	movq	%rcx, 0x1c(%rdx)
    2409:      	addq	$0x20, %rsi
    240d:      	movq	%rsi, 0xe8(%rsp)
    2415:      	movl	$0xa, %r15d
    241b:      	xorl	%ebp, %ebp
    241d:      	movq	0x10(%rsp), %r13
    2422:      	subq	%rbp, %r13
    2425:      	js	0x3961 <generic_rawtp_process_event+0x3791>
    242b:      	movq	0xa8(%rsp), %rax
    2433:      	leaq	(%rax,%rbp), %rdx
    2437:      	cmpq	$0x7fe0, %r13           # imm = 0x7FE0
    243e:      	movl	$0x7fe0, %eax           # imm = 0x7FE0
    2443:      	cmovaeq	%rax, %r13
    2447:      	movl	$0x4, %eax
    244c:      	movq	0xe8(%rsp), %rdi
    2454:      	movl	%r13d, %esi
    2457:      	callq	*%rax
    2459:      	testl	%eax, %eax
    245b:      	js	0x24ce <generic_rawtp_process_event+0x22fe>
    245d:      	leal	0x20(%r13), %r12d
    2461:      	movq	0x48(%rsp), %rax
    2466:      	movl	%r12d, 0x4(%rax)
    246a:      	movl	$0x0, 0x68(%rsp)
    2472:      	movl	$0x1, %eax
    2477:      	movq	(%rip), %rdi            # 0x247e <generic_rawtp_process_event+0x22ae>
    247e:      	leaq	0x68(%rsp), %rsi
    2483:      	callq	*%rax
    2485:      	testq	%rax, %rax
    2488:      	je	0x24b0 <generic_rawtp_process_event+0x22e0>
    248a:      	cmpb	$0x0, 0x28(%rax)
    248e:      	je	0x24b0 <generic_rawtp_process_event+0x22e0>
    2490:      	movl	$0x19, %eax
    2495:      	movq	%rbx, %rdi
    2498:      	movq	0x48(%rsp), %rcx
    249d:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    24a2:      	movq	(%rip), %rsi            # 0x24a9 <generic_rawtp_process_event+0x22d9>
    24a9:      	movq	%r12, %r8
    24ac:      	callq	*%rax
    24ae:      	jmp	0x24ca <generic_rawtp_process_event+0x22fa>
    24b0:      	movl	$0x82, %eax
    24b5:      	movq	0x48(%rsp), %rsi
    24ba:      	xorl	%ecx, %ecx
    24bc:      	movq	(%rip), %rdi            # 0x24c3 <generic_rawtp_process_event+0x22f3>
    24c3:      	movq	%r12, %rdx
    24c6:      	xorl	%ecx, %ecx
    24c8:      	callq	*%rax
    24ca:      	testl	%eax, %eax
    24cc:      	jns	0x24d1 <generic_rawtp_process_event+0x2301>
    24ce:      	movslq	%eax, %r13
    24d1:      	testl	%r13d, %r13d
    24d4:      	js	0x396a <generic_rawtp_process_event+0x379a>
    24da:      	andl	$0x7fffffff, %r13d      # imm = 0x7FFFFFFF
    24e1:      	addq	%r13, %rbp
    24e4:      	cmpq	0x10(%rsp), %rbp
    24e9:      	je	0x39c4 <generic_rawtp_process_event+0x37f4>
    24ef:      	decl	%r15d
    24f2:      	jne	0x241d <generic_rawtp_process_event+0x224d>
    24f8:      	jmp	0x3d1c <generic_rawtp_process_event+0x3b4c>
    24fd:      	movq	0x50(%rsp), %r13
    2502:      	movq	%rbp, %rbx
    2505:      	leaq	0x28(%rbp), %rdi
    2509:      	leaq	0x98(%r13), %rdx
    2510:      	movl	$0x4, %ecx
    2515:      	movl	$0x4, %eax
    251a:      	movl	$0x4, %esi
    251f:      	callq	*%rax
    2521:      	leaq	0x2c(%rbp), %rdi
    2525:      	leaq	0x70(%r13), %rdx
    2529:      	movl	$0x4, %ecx
    252e:      	movl	$0x4, %eax
    2533:      	movl	$0x4, %esi
    2538:      	callq	*%rax
    253a:      	leaq	0x30(%rbp), %rdi
    253e:      	leaq	0x90(%r13), %rdx
    2545:      	movl	$0x4, %ecx
    254a:      	movl	$0x4, %eax
    254f:      	movl	$0x4, %esi
    2554:      	callq	*%rax
    2556:      	leaq	0x34(%rbp), %rdi
    255a:      	leaq	0xa8(%r13), %rdx
    2561:      	movl	$0x4, %ecx
    2566:      	movl	$0x4, %eax
    256b:      	movl	$0x4, %esi
    2570:      	callq	*%rax
    2572:      	movq	$0x0, 0x68(%rsp)
    257b:      	leaq	0xc8(%r13), %rdx
    2582:      	leaq	0x68(%rsp), %rdi
    2587:      	movl	$0x8, %ecx
    258c:      	movl	$0x4, %eax
    2591:      	movl	$0x8, %esi
    2596:      	callq	*%rax
    2598:      	leaq	0xb8(%r13), %rdx
    259f:      	leaq	0x30(%rsp), %rdi
    25a4:      	movl	$0x2, %ecx
    25a9:      	movl	$0x4, %eax
    25ae:      	movl	$0x2, %esi
    25b3:      	callq	*%rax
    25b5:      	movzwl	0x30(%rsp), %r12d
    25bb:      	addq	0x68(%rsp), %r12
    25c0:      	leaq	0xdc(%rsp), %rdi
    25c8:      	movl	$0x1, %ecx
    25cd:      	movl	$0x4, %eax
    25d2:      	movl	$0x1, %esi
    25d7:      	movq	%r12, %rdx
    25da:      	callq	*%rax
    25dc:      	movzbl	0xdc(%rsp), %eax
    25e4:      	shrl	$0x4, %eax
    25e7:      	cmpl	$0x6, %eax
    25ea:      	je	0x2c7b <generic_rawtp_process_event+0x2aab>
    25f0:      	cmpl	$0x4, %eax
    25f3:      	jne	0x4249 <generic_rawtp_process_event+0x4079>
    25f9:      	leaq	0x9(%r12), %rdx
    25fe:      	leaq	0xd0(%rsp), %rdi
    2606:      	movl	$0x1, %ecx
    260b:      	movl	$0x4, %eax
    2610:      	movl	$0x1, %esi
    2615:      	callq	*%rax
    2617:      	movzbl	0xd0(%rsp), %eax
    261f:      	movq	%rbp, %rdi
    2622:      	movw	%ax, 0x24(%rbp)
    2626:      	movw	$0x2, 0x26(%rbp)
    262c:      	leaq	0xc(%r12), %rdx
    2631:      	movq	$0x0, (%rbp)
    2639:      	movq	$0x0, 0x8(%rbp)
    2641:      	movq	$0x0, 0x10(%rbp)
    2649:      	movq	$0x0, 0x18(%rbp)
    2651:      	movl	$0x4, %ecx
    2656:      	movl	$0x4, %eax
    265b:      	leaq	0x10(%rbp), %rbx
    265f:      	movl	$0x4, %esi
    2664:      	callq	*%rax
    2666:      	addq	$0x10, %r12
    266a:      	movl	$0x4, %ecx
    266f:      	movl	$0x4, %eax
    2674:      	movq	%rbx, %rdi
    2677:      	movl	$0x4, %esi
    267c:      	movq	%r12, %rdx
    267f:      	callq	*%rax
    2681:      	leaq	0xb6(%r13), %rdx
    2688:      	leaq	0xc0(%rsp), %rdi
    2690:      	movl	$0x2, %ecx
    2695:      	movl	$0x4, %eax
    269a:      	movl	$0x2, %esi
    269f:      	callq	*%rax
    26a1:      	movzbl	0xd0(%rsp), %r15d
    26aa:      	jmp	0x40fa <generic_rawtp_process_event+0x3f2a>
    26af:      	movl	$0x120, %edx            # imm = 0x120
    26b4:      	addq	0x50(%rsp), %rdx
    26b9:      	leaq	0x4(%rbp), %rdi
    26bd:      	movl	$0x11, %ecx
    26c2:      	movl	$0x2d, %eax
    26c7:      	movl	$0x11, %esi
    26cc:      	callq	*%rax
    26ce:      	movq	%rax, %r13
    26d1:      	testq	%rax, %rax
    26d4:      	js	0x2fe6 <generic_rawtp_process_event+0x2e16>
    26da:      	leal	-0x1(%r13), %eax
    26de:      	movl	%eax, (%rbp)
    26e1:      	addq	$0x3, %r13
    26e5:      	jmp	0x2fe6 <generic_rawtp_process_event+0x2e16>
    26ea:      	movq	0x50(%rsp), %r12
    26ef:      	movq	%rbp, %rdi
    26f2:      	movq	$0x0, 0x10(%rbp)
    26fa:      	movq	$0x0, 0x8(%rbp)
    2702:      	movq	$0x0, (%rbp)
    270a:      	movl	$0x2, %ecx
    270f:      	movl	$0x4, %eax
    2714:      	movl	$0x2, %esi
    2719:      	movq	%r12, %rdx
    271c:      	callq	*%rax
    271e:      	testq	%rax, %rax
    2721:      	js	0x2f05 <generic_rawtp_process_event+0x2d35>
    2727:      	movzwl	(%rbp), %eax
    272b:      	cmpl	$0xa, %eax
    272e:      	je	0x2ec2 <generic_rawtp_process_event+0x2cf2>
    2734:      	cmpl	$0x2, %eax
    2737:      	jne	0x2efb <generic_rawtp_process_event+0x2d2b>
    273d:      	leaq	0x4(%r12), %rdx
    2742:      	leaq	0x68(%rsp), %rdi
    2747:      	movl	$0x4, %ecx
    274c:      	movl	$0x4, %eax
    2751:      	movl	$0x4, %esi
    2756:      	callq	*%rax
    2758:      	movl	0x68(%rsp), %eax
    275c:      	movq	%rax, 0x8(%rbp)
    2760:      	leaq	0x2(%rbp), %rdi
    2764:      	addq	$0x2, %r12
    2768:      	movl	$0x2, %ecx
    276d:      	movl	$0x4, %eax
    2772:      	jmp	0x2ef1 <generic_rawtp_process_event+0x2d21>
    2777:      	movq	0x48(%rsp), %rax
    277c:      	addq	%rbp, %rax
    277f:      	addq	$0x90, %rax
    2785:      	movq	%rax, 0xa8(%rsp)
    278d:      	movq	$0x0, 0x50(%rsp)
    2796:      	testb	$0x10, %r12b
    279a:      	jne	0x2dd6 <generic_rawtp_process_event+0x2c06>
    27a0:      	movl	%r12d, %r15d
    27a3:      	movq	0x40(%rsp), %rdx
    27a8:      	andl	$0xf, %edx
    27ab:      	xorl	%eax, %eax
    27ad:      	movq	%rdx, %rcx
    27b0:      	cmpl	$0x2, %edx
    27b3:      	jle	0x309f <generic_rawtp_process_event+0x2ecf>
    27b9:      	cmpl	$0x3, %ecx
    27bc:      	je	0x36f7 <generic_rawtp_process_event+0x3527>
    27c2:      	cmpl	$0x4, %ecx
    27c5:      	je	0x3700 <generic_rawtp_process_event+0x3530>
    27cb:      	cmpl	$0x5, %ecx
    27ce:      	jne	0x3713 <generic_rawtp_process_event+0x3543>
    27d4:      	leaq	0x5e70(%rbp), %rax
    27db:      	jmp	0x3710 <generic_rawtp_process_event+0x3540>
    27e0:      	movq	%r15, %rbx
    27e3:      	leaq	0x28(%r15), %r13
    27e7:      	leaq	0x40(%r15), %r12
    27eb:      	movq	0x10(%rsp), %r15
    27f0:      	leaq	0x8(%r15), %rdx
    27f4:      	movl	$0x4, %ecx
    27f9:      	movl	$0x4, %eax
    27fe:      	movq	%rbx, %rdi
    2801:      	movl	$0x4, %esi
    2806:      	callq	*%rax
    2808:      	leaq	0x4(%rbx), %rdi
    280c:      	leaq	0xc(%r15), %rdx
    2810:      	movl	$0x4, %ecx
    2815:      	movl	$0x4, %eax
    281a:      	movl	$0x4, %esi
    281f:      	callq	*%rax
    2821:      	leaq	0x10(%rbx), %rdi
    2825:      	leaq	0x18(%r15), %rdx
    2829:      	movl	$0x4, %ecx
    282e:      	movl	$0x4, %eax
    2833:      	movl	$0x4, %esi
    2838:      	callq	*%rax
    283a:      	leaq	0x14(%rbx), %rdi
    283e:      	leaq	0x1c(%r15), %rdx
    2842:      	movl	$0x4, %ecx
    2847:      	movl	$0x4, %eax
    284c:      	movl	$0x4, %esi
    2851:      	callq	*%rax
    2853:      	leaq	0x8(%rbx), %rdi
    2857:      	leaq	0x10(%r15), %rdx
    285b:      	movl	$0x4, %ecx
    2860:      	movl	$0x4, %eax
    2865:      	movl	$0x4, %esi
    286a:      	callq	*%rax
    286c:      	leaq	0xc(%rbx), %rdi
    2870:      	leaq	0x14(%r15), %rdx
    2874:      	movl	$0x4, %ecx
    2879:      	movl	$0x4, %eax
    287e:      	movl	$0x4, %esi
    2883:      	callq	*%rax
    2885:      	leaq	0x18(%rbx), %rdi
    2889:      	leaq	0x20(%r15), %rdx
    288d:      	movl	$0x4, %ecx
    2892:      	movl	$0x4, %eax
    2897:      	movl	$0x4, %esi
    289c:      	callq	*%rax
    289e:      	leaq	0x1c(%rbx), %rdi
    28a2:      	leaq	0x24(%r15), %rdx
    28a6:      	movl	$0x4, %ecx
    28ab:      	movl	$0x4, %eax
    28b0:      	movl	$0x4, %esi
    28b5:      	callq	*%rax
    28b7:      	movl	$0x0, 0x24(%rbx)
    28be:      	leaq	0x20(%rbx), %rdi
    28c2:      	leaq	0x28(%r15), %rdx
    28c6:      	movl	$0x4, %ecx
    28cb:      	movl	$0x4, %eax
    28d0:      	movl	$0x4, %esi
    28d5:      	callq	*%rax
    28d7:      	leaq	0x30(%rbx), %rdi
    28db:      	leaq	0x40(%r15), %rdx
    28df:      	movl	$0x8, %ecx
    28e4:      	movl	$0x4, %eax
    28e9:      	movl	$0x8, %esi
    28ee:      	callq	*%rax
    28f0:      	leaq	0x38(%rbx), %rdi
    28f4:      	leaq	0x30(%r15), %rdx
    28f8:      	movl	$0x8, %ecx
    28fd:      	movl	$0x4, %eax
    2902:      	movl	$0x8, %esi
    2907:      	callq	*%rax
    2909:      	leaq	0x38(%r15), %rdx
    290d:      	movl	$0x8, %ecx
    2912:      	movl	$0x4, %eax
    2917:      	movq	%r13, %rdi
    291a:      	movl	$0x8, %esi
    291f:      	callq	*%rax
    2921:      	addq	$0x90, %r15
    2928:      	leaq	0x68(%rsp), %rdi
    292d:      	movl	$0x8, %ecx
    2932:      	movl	$0x4, %eax
    2937:      	movl	$0x8, %esi
    293c:      	movq	%r15, %rdx
    293f:      	callq	*%rax
    2941:      	movq	0x68(%rsp), %r13
    2946:      	leaq	0xc8(%r13), %rdx
    294d:      	movl	$0x4, %ecx
    2952:      	movl	$0x4, %eax
    2957:      	movq	%r12, %rdi
    295a:      	movl	$0x4, %esi
    295f:      	callq	*%rax
    2961:      	leaq	0x44(%rbx), %rdi
    2965:      	leaq	0xcc(%r13), %rdx
    296c:      	movl	$0x4, %ecx
    2971:      	movl	$0x4, %eax
    2976:      	movl	$0x4, %esi
    297b:      	callq	*%rax
    297d:      	leaq	0x48(%rbx), %rdi
    2981:      	leaq	0xd0(%r13), %rdx
    2988:      	movl	$0x4, %ecx
    298d:      	movl	$0x4, %eax
    2992:      	movl	$0x4, %esi
    2997:      	callq	*%rax
    2999:      	addq	$0x4c, %rbx
    299d:      	addq	$0x158, %r13            # imm = 0x158
    29a4:      	movl	$0x4, %ecx
    29a9:      	movl	$0x4, %eax
    29ae:      	movq	%rbx, %rdi
    29b1:      	movl	$0x4, %esi
    29b6:      	movq	%r13, %rdx
    29b9:      	callq	*%rax
    29bb:      	movl	$0x50, %r13d
    29c1:      	jmp	0x3eba <generic_rawtp_process_event+0x3cea>
    29c6:      	movq	0x10(%rsp), %r12
    29cb:      	leaq	0xc8(%r12), %rdx
    29d3:      	movl	$0x4, %ecx
    29d8:      	movl	$0x4, %eax
    29dd:      	movq	%r15, %rdi
    29e0:      	movl	$0x4, %esi
    29e5:      	callq	*%rax
    29e7:      	leaq	0x4(%r15), %rdi
    29eb:      	leaq	0xcc(%r12), %rdx
    29f3:      	movl	$0x4, %ecx
    29f8:      	movl	$0x4, %eax
    29fd:      	movl	$0x4, %esi
    2a02:      	callq	*%rax
    2a04:      	leaq	0x8(%r15), %rdi
    2a08:      	leaq	0xd0(%r12), %rdx
    2a10:      	movl	$0x4, %ecx
    2a15:      	movl	$0x4, %eax
    2a1a:      	movl	$0x4, %esi
    2a1f:      	callq	*%rax
    2a21:      	addq	$0xc, %r15
    2a25:      	addq	$0x158, %r12            # imm = 0x158
    2a2c:      	movl	$0x4, %ecx
    2a31:      	movl	$0x4, %eax
    2a36:      	movq	%r15, %rdi
    2a39:      	movl	$0x4, %esi
    2a3e:      	movq	%r12, %rdx
    2a41:      	callq	*%rax
    2a43:      	movl	$0x10, %r13d
    2a49:      	jmp	0x3eba <generic_rawtp_process_event+0x3cea>
    2a4e:      	movq	0x10(%rsp), %r12
    2a53:      	leaq	0x38(%r12), %rdx
    2a58:      	movl	$0x4, %ecx
    2a5d:      	movl	$0x4, %eax
    2a62:      	movq	%r15, %rdi
    2a65:      	movl	$0x4, %esi
    2a6a:      	callq	*%rax
    2a6c:      	leaq	0x4(%r15), %rdi
    2a70:      	leaq	0x3c(%r12), %rdx
    2a75:      	movl	$0x4, %ecx
    2a7a:      	movl	$0x4, %eax
    2a7f:      	movl	$0x4, %esi
    2a84:      	callq	*%rax
    2a86:      	leaq	0x8(%r15), %rdi
    2a8a:      	leaq	0x40(%r12), %rdx
    2a8f:      	movl	$0x4, %ecx
    2a94:      	movl	$0x4, %eax
    2a99:      	movl	$0x4, %esi
    2a9e:      	callq	*%rax
    2aa0:      	leaq	0xc(%r15), %rdi
    2aa4:      	leaq	0x44(%r12), %rdx
    2aa9:      	movl	$0x4, %ecx
    2aae:      	movl	$0x4, %eax
    2ab3:      	movl	$0x4, %esi
    2ab8:      	callq	*%rax
    2aba:      	addq	$0x10, %r15
    2abe:      	subq	$-0x80, %r12
    2ac2:      	movl	$0x10, %ecx
    2ac7:      	movl	$0x4, %eax
    2acc:      	movq	%r15, %rdi
    2acf:      	movl	$0x10, %esi
    2ad4:      	movq	%r12, %rdx
    2ad7:      	callq	*%rax
    2ad9:      	movl	$0x20, %r13d
    2adf:      	jmp	0x3eba <generic_rawtp_process_event+0x3cea>
    2ae4:      	movl	$0x4, %ecx
    2ae9:      	movl	$0x4, %eax
    2aee:      	movq	%r15, %rbx
    2af1:      	movq	0x10(%rsp), %r15
    2af6:      	movq	%rbx, %rdi
    2af9:      	movl	$0x4, %esi
    2afe:      	movq	%r15, %rdx
    2b01:      	callq	*%rax
    2b03:      	leaq	0x4(%rbx), %rdi
    2b07:      	leaq	0x4(%r15), %rdx
    2b0b:      	movl	$0x4, %ecx
    2b10:      	movl	$0x4, %eax
    2b15:      	movl	$0x4, %esi
    2b1a:      	callq	*%rax
    2b1c:      	addq	$0x8, %rbx
    2b20:      	addq	$0x30, %r15
    2b24:      	movl	$0x10, %ecx
    2b29:      	movl	$0x4, %eax
    2b2e:      	movq	%rbx, %rdi
    2b31:      	movl	$0x10, %esi
    2b36:      	movq	%r15, %rdx
    2b39:      	jmp	0x2bca <generic_rawtp_process_event+0x29fa>
    2b3e:      	movq	0x10(%rsp), %r15
    2b43:      	leaq	0x4(%r15), %rdx
    2b47:      	leaq	0x68(%rsp), %rdi
    2b4c:      	movl	$0x4, %ecx
    2b51:      	movl	$0x4, %eax
    2b56:      	movl	$0x4, %esi
    2b5b:      	callq	*%rax
    2b5d:      	movl	0x68(%rsp), %eax
    2b61:      	movl	%eax, (%rbp)
    2b64:      	leaq	0xc(%r15), %rdx
    2b68:      	leaq	0x68(%rsp), %rdi
    2b6d:      	movl	$0x4, %ecx
    2b72:      	movl	$0x4, %eax
    2b77:      	movl	$0x4, %esi
    2b7c:      	callq	*%rax
    2b7e:      	movl	0x68(%rsp), %eax
    2b82:      	movl	%eax, 0x4(%rbp)
    2b85:      	addq	$0x50, %r15
    2b89:      	leaq	0x68(%rsp), %rdi
    2b8e:      	movl	$0x8, %ecx
    2b93:      	movl	$0x2d, %eax
    2b98:      	movl	$0x8, %esi
    2b9d:      	movq	%r15, %rdx
    2ba0:      	callq	*%rax
    2ba2:      	addq	$0x8, %rbp
    2ba6:      	movl	$0x3f8, %edx            # imm = 0x3F8
    2bab:      	movq	0x68(%rsp), %rcx
    2bb0:      	addq	%rdx, %rcx
    2bb3:      	movl	$0x10, %esi
    2bb8:      	movl	$0x2d, %eax
    2bbd:      	addq	0x68(%rsp), %rdx
    2bc2:      	movq	%rbp, %rdi
    2bc5:      	movl	$0x10, %esi
    2bca:      	callq	*%rax
    2bcc:      	movl	$0x18, %r13d
    2bd2:      	jmp	0x3eba <generic_rawtp_process_event+0x3cea>
    2bd7:      	movq	$0x0, 0x48(%rbp)
    2bdf:      	movq	$0x0, 0x40(%rbp)
    2be7:      	movq	$0x0, 0x38(%rbp)
    2bef:      	movq	$0x0, 0x30(%rbp)
    2bf7:      	movq	$0x0, 0x28(%rbp)
    2bff:      	movq	$0x0, 0x20(%rbp)
    2c07:      	movq	$0x0, 0x18(%rbp)
    2c0f:      	movq	$0x0, 0x10(%rbp)
    2c17:      	movq	$0x0, 0x8(%rbp)
    2c1f:      	movq	$0x0, (%rbp)
    2c27:      	leaq	0x68(%rsp), %rdi
    2c2c:      	movl	$0x8, %ecx
    2c31:      	movl	$0x4, %eax
    2c36:      	movq	0x10(%rsp), %rdx
    2c3b:      	movl	$0x8, %esi
    2c40:      	callq	*%rax
    2c42:      	testq	%rax, %rax
    2c45:      	je	0x2f10 <generic_rawtp_process_event+0x2d40>
    2c4b:      	xorl	%r13d, %r13d
    2c4e:      	jmp	0x3eba <generic_rawtp_process_event+0x3cea>
    2c53:      	movq	0x48(%rsp), %rax
    2c58:      	movq	$0x0, 0x90(%r15,%rax)
    2c64:      	movl	$0x8, %r13d
    2c6a:      	jmp	0x1761 <generic_rawtp_process_event+0x1591>
    2c6f:      	movq	$-0x1, %r13
    2c76:      	jmp	0x1761 <generic_rawtp_process_event+0x1591>
    2c7b:      	movq	0x68(%rsp), %r14
    2c80:      	movl	$0x0, 0x58(%rsp)
    2c88:      	movzwl	0x30(%rsp), %r15d
    2c8e:      	movq	(%rip), %rdi            # 0x2c95 <generic_rawtp_process_event+0x2ac5>
    2c95:      	leaq	0x58(%rsp), %rsi
    2c9a:      	movl	$0x1, %eax
    2c9f:      	leaq	(%r14,%r15), %r12
    2ca3:      	callq	*%rax
    2ca5:      	testq	%rax, %rax
    2ca8:      	je	0x40a9 <generic_rawtp_process_event+0x3ed9>
    2cae:      	movq	%rax, %rbx
    2cb1:      	movw	%r15w, (%rax)
    2cb5:      	movb	$-0x1, 0x5(%rax)
    2cb9:      	movb	$0x0, 0x7(%rax)
    2cbd:      	movq	%rax, %rdi
    2cc0:      	addq	$0x6, %rdi
    2cc4:      	leaq	0x6(%r12), %rdx
    2cc9:      	movl	$0x1, %ecx
    2cce:      	movl	$0x4, %eax
    2cd3:      	movq	%rdi, 0x10(%rsp)
    2cd8:      	movl	$0x1, %esi
    2cdd:      	callq	*%rax
    2cdf:      	testq	%rax, %rax
    2ce2:      	js	0x40a9 <generic_rawtp_process_event+0x3ed9>
    2ce8:      	movzbl	0x5(%rbx), %eax
    2cec:      	cmpl	$0x32, %eax
    2cef:      	jg	0x362a <generic_rawtp_process_event+0x345a>
    2cf5:      	testl	%eax, %eax
    2cf7:      	je	0x36dc <generic_rawtp_process_event+0x350c>
    2cfd:      	cmpl	$0x2b, %eax
    2d00:      	je	0x36dc <generic_rawtp_process_event+0x350c>
    2d06:      	cmpl	$0x2c, %eax
    2d09:      	jne	0x3a9b <generic_rawtp_process_event+0x38cb>
    2d0f:      	movw	$0x8, 0x2(%rbx)
    2d15:      	movw	$0x8, %ax
    2d19:      	jmp	0x39dd <generic_rawtp_process_event+0x380d>
    2d1e:      	leaq	0x48(%r12), %rdx
    2d23:      	movl	$0x10, %ecx
    2d28:      	movl	$0x4, %eax
    2d2d:      	movq	%rbp, %rdi
    2d30:      	movl	$0x10, %esi
    2d35:      	callq	*%rax
    2d37:      	leaq	0x38(%r12), %rdx
    2d3c:      	movl	$0x10, %ecx
    2d41:      	movl	$0x4, %eax
    2d46:      	movq	%r13, %rdi
    2d49:      	movl	$0x10, %esi
    2d4e:      	callq	*%rax
    2d50:      	leaq	0x20(%rbp), %rdi
    2d54:      	leaq	0xc(%r12), %r13
    2d59:      	addq	$0xe, %r12
    2d5d:      	movl	$0x2, %ecx
    2d62:      	movl	$0x4, %eax
    2d67:      	movl	$0x2, %esi
    2d6c:      	movq	%r12, %rdx
    2d6f:      	callq	*%rax
    2d71:      	leaq	0x22(%rbp), %rdi
    2d75:      	movl	$0x2, %ecx
    2d7a:      	movl	$0x4, %eax
    2d7f:      	movl	$0x2, %esi
    2d84:      	movq	%r13, %rdx
    2d87:      	callq	*%rax
    2d89:      	movzwl	0x22(%rbp), %eax
    2d8d:      	movbew	%ax, 0x22(%rbp)
    2d93:      	movq	0x50(%rsp), %rax
    2d98:      	movq	%rax, 0x68(%rsp)
    2d9d:      	movq	(%rip), %rdi            # 0x2da4 <generic_rawtp_process_event+0x2bd4>
    2da4:      	leaq	0x68(%rsp), %rsi
    2da9:      	movl	$0x1, %eax
    2dae:      	callq	*%rax
    2db0:      	testq	%rax, %rax
    2db3:      	je	0x4249 <generic_rawtp_process_event+0x4079>
    2db9:      	movl	(%rax), %ecx
    2dbb:      	movq	%r15, %rbp
    2dbe:      	movl	%ecx, 0x10(%r15)
    2dc2:      	movq	0x8(%rax), %rcx
    2dc6:      	movq	%rcx, 0x18(%r15)
    2dca:      	movl	0x4(%rax), %eax
    2dcd:      	movl	%eax, 0x7c(%r15)
    2dd1:      	jmp	0x4249 <generic_rawtp_process_event+0x4079>
    2dd6:      	movl	$0xe, %eax
    2ddb:      	callq	*%rax
    2ddd:      	cmpq	$-0x16, %rax
    2de1:      	jne	0x2e07 <generic_rawtp_process_event+0x2c37>
    2de3:      	movq	0x18(%rsp), %rax
    2de8:      	leaq	0x20(%rax), %rdx
    2dec:      	leaq	0x68(%rsp), %rdi
    2df1:      	movl	$0x8, %ecx
    2df6:      	movl	$0x4, %eax
    2dfb:      	movl	$0x8, %esi
    2e00:      	callq	*%rax
    2e02:      	movq	0x68(%rsp), %rax
    2e07:      	movq	0x8(%rbp), %rcx
    2e0b:      	movq	0x60(%rbp), %rdx
    2e0f:      	movq	%rcx, 0x68(%rsp)
    2e14:      	movq	0x10(%rsp), %rcx
    2e19:      	movq	%rcx, 0x70(%rsp)
    2e1e:      	movq	$0x0, 0x78(%rsp)
    2e27:      	movq	%rdx, 0x58(%rsp)
    2e2c:      	movq	%rax, 0x60(%rsp)
    2e31:      	movq	(%rip), %rdi            # 0x2e38 <generic_rawtp_process_event+0x2c68>
    2e38:      	xorl	%ecx, %ecx
    2e3a:      	leaq	0x58(%rsp), %rsi
    2e3f:      	leaq	0x68(%rsp), %rdx
    2e44:      	movl	$0x2, %eax
    2e49:      	xorl	%ecx, %ecx
    2e4b:      	callq	*%rax
    2e4d:      	testq	%rax, %rax
    2e50:      	je	0x3683 <generic_rawtp_process_event+0x34b3>
    2e56:      	negl	%eax
    2e58:      	movw	%ax, 0xb0(%rsp)
    2e60:      	movw	$0x5, 0xb2(%rsp)
    2e6a:      	movabsq	$0x200000046, %rax      # imm = 0x200000046
    2e74:      	movq	%rax, 0xb4(%rsp)
    2e7c:      	movq	(%rip), %rdi            # 0x2e83 <generic_rawtp_process_event+0x2cb3>
    2e83:      	leaq	0xb0(%rsp), %rsi
    2e8b:      	movl	$0x1, %eax
    2e90:      	callq	*%rax
    2e92:      	testq	%rax, %rax
    2e95:      	je	0x3656 <generic_rawtp_process_event+0x3486>
    2e9b:      	incl	(%rax)
    2e9d:      	jmp	0x3683 <generic_rawtp_process_event+0x34b3>
    2ea2:      	cmpl	$0x1, %eax
    2ea5:      	je	0x318f <generic_rawtp_process_event+0x2fbf>
    2eab:      	cmpl	$0x2, %eax
    2eae:      	jne	0x3531 <generic_rawtp_process_event+0x3361>
    2eb4:      	movq	%rbp, %rax
    2eb7:      	addq	$0x5e58, %rax           # imm = 0x5E58
    2ebd:      	jmp	0x3198 <generic_rawtp_process_event+0x2fc8>
    2ec2:      	movq	%rbp, %rbx
    2ec5:      	leaq	0x8(%rbp), %rdi
    2ec9:      	leaq	0x8(%r12), %rdx
    2ece:      	movl	$0x10, %ecx
    2ed3:      	movl	$0x4, %eax
    2ed8:      	movl	$0x10, %esi
    2edd:      	callq	*%rax
    2edf:      	leaq	0x2(%rbp), %rdi
    2ee3:      	addq	$0x2, %r12
    2ee7:      	movl	$0x2, %ecx
    2eec:      	movl	$0x4, %eax
    2ef1:      	movl	$0x2, %esi
    2ef6:      	movq	%r12, %rdx
    2ef9:      	callq	*%rax
    2efb:      	movzwl	0x2(%rbp), %eax
    2eff:      	movbew	%ax, 0x2(%rbp)
    2f05:      	movl	$0x18, %r13d
    2f0b:      	jmp	0x2fe6 <generic_rawtp_process_event+0x2e16>
    2f10:      	leaq	0x10(%rbp), %rdi
    2f14:      	movq	0x68(%rsp), %rcx
    2f19:      	movl	$0x3f, %edx
    2f1e:      	movl	$0x2d, %eax
    2f23:      	movq	0x68(%rsp), %rdx
    2f28:      	movl	$0x3f, %esi
    2f2d:      	callq	*%rax
    2f2f:      	testq	%rax, %rax
    2f32:      	js	0x2c4b <generic_rawtp_process_event+0x2a7b>
    2f38:      	movq	0x10(%rsp), %rbx
    2f3d:      	leaq	0x8(%rbx), %rdx
    2f41:      	leaq	0x58(%rsp), %rdi
    2f46:      	movl	$0x8, %ecx
    2f4b:      	movl	$0x4, %eax
    2f50:      	movl	$0x8, %esi
    2f55:      	callq	*%rax
    2f57:      	leaq	0x8(%rbp), %rdi
    2f5b:      	movl	$0x348, %edx            # imm = 0x348
    2f60:      	movq	0x58(%rsp), %rcx
    2f65:      	addq	%rdx, %rcx
    2f68:      	movl	$0x8, %esi
    2f6d:      	movl	$0x4, %eax
    2f72:      	addq	0x58(%rsp), %rdx
    2f77:      	movl	$0x8, %esi
    2f7c:      	callq	*%rax
    2f7e:      	addq	$0x58, %rbx
    2f82:      	leaq	0x58(%rsp), %rdi
    2f87:      	movl	$0x4, %ecx
    2f8c:      	movl	$0x4, %eax
    2f91:      	movl	$0x4, %esi
    2f96:      	movq	%rbx, %rdx
    2f99:      	callq	*%rax
    2f9b:      	movl	$0x50, %r13d
    2fa1:      	testq	%rax, %rax
    2fa4:      	jne	0x3eba <generic_rawtp_process_event+0x3cea>
    2faa:      	xorl	%eax, %eax
    2fac:      	cmpl	$0x0, 0x58(%rsp)
    2fb1:      	setne	%al
    2fb4:      	movl	%eax, (%rbp)
    2fb7:      	jmp	0x3eba <generic_rawtp_process_event+0x3cea>
    2fbc:      	addq	$0x3, %r12
    2fc0:      	movl	$0x6b, %ecx
    2fc5:      	movl	$0x71, %eax
    2fca:      	movl	$0x6b, %esi
    2fcf:      	movq	%r12, %rdx
    2fd2:      	callq	*%rax
    2fd4:      	movq	%rax, %rcx
    2fd7:      	movb	$0x6b, %al
    2fd9:      	testl	%ecx, %ecx
    2fdb:      	js	0x2fe0 <generic_rawtp_process_event+0x2e10>
    2fdd:      	movb	%al, 0x3(%rbp)
    2fe0:      	movl	$0x70, %r13d
    2fe6:      	movq	0x38(%rsp), %rax
    2feb:      	movq	0x20(%rsp), %rcx
    2ff0:      	movl	$0x4, %esi
    2ff5:      	movq	0x18(%rsp), %rbx
    2ffa:      	movq	%r15, %r14
    2ffd:      	jmp	0x1770 <generic_rawtp_process_event+0x15a0>
    3002:      	addq	$0x90, %r15
    3009:      	movq	0xc8(%rsp), %rax
    3011:      	movl	$0x0, 0x4(%r15,%rax)
    301a:      	addq	%r15, %rax
    301d:      	addq	$0x8, %rax
    3021:      	movq	%rax, 0x40(%rsp)
    3026:      	movl	$0xc, %ebp
    302b:      	movq	0x10(%rsp), %rax
    3030:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    3036:      	movl	$0xfff, %r13d           # imm = 0xFFF
    303c:      	cmovbq	%rax, %r13
    3040:      	movq	0x40(%rsp), %rax
    3045:      	leaq	0x8(%rax), %rdi
    3049:      	movl	$0x4, %eax
    304e:      	movq	0xa8(%rsp), %rdx
    3056:      	movl	%r13d, %esi
    3059:      	callq	*%rax
    305b:      	testl	%eax, %eax
    305d:      	js	0x307a <generic_rawtp_process_event+0x2eaa>
    305f:      	movq	0x40(%rsp), %rax
    3064:      	movq	0x10(%rsp), %rcx
    3069:      	movl	%ecx, (%rax)
    306b:      	movl	%r13d, 0x4(%rax)
    306f:      	addq	%r13, %rbp
    3072:      	movq	%rbp, %r13
    3075:      	jmp	0x1761 <generic_rawtp_process_event+0x1591>
    307a:      	movq	0x40(%rsp), %rax
    307f:      	movl	$0xfffffffe, (%rax)     # imm = 0xFFFFFFFE
    3085:      	movq	0x38(%rsp), %rax
    308a:      	movq	0x20(%rsp), %rcx
    308f:      	movl	$0x4, %esi
    3094:      	movl	$0x4, %r13d
    309a:      	jmp	0x1770 <generic_rawtp_process_event+0x15a0>
    309f:      	cmpl	$0x1, %ecx
    30a2:      	je	0x3709 <generic_rawtp_process_event+0x3539>
    30a8:      	cmpl	$0x2, %ecx
    30ab:      	jne	0x3713 <generic_rawtp_process_event+0x3543>
    30b1:      	leaq	0x5e58(%rbp), %rax
    30b8:      	jmp	0x3710 <generic_rawtp_process_event+0x3540>
    30bd:      	leaq	0x48(%r12), %rdx
    30c2:      	movl	$0x10, %ecx
    30c7:      	movl	$0x4, %eax
    30cc:      	movq	%rbp, %rdi
    30cf:      	movl	$0x10, %esi
    30d4:      	callq	*%rax
    30d6:      	leaq	0x38(%r12), %rdx
    30db:      	movl	$0x10, %ecx
    30e0:      	movl	$0x4, %eax
    30e5:      	movq	%r13, %rdi
    30e8:      	movl	$0x10, %esi
    30ed:      	callq	*%rax
    30ef:      	movq	%rbp, %rbx
    30f2:      	leaq	0x20(%rbp), %rdi
    30f6:      	leaq	0xc(%r12), %r13
    30fb:      	addq	$0xe, %r12
    30ff:      	movl	$0x2, %ecx
    3104:      	movl	$0x4, %eax
    3109:      	movl	$0x2, %esi
    310e:      	movq	%r12, %rdx
    3111:      	callq	*%rax
    3113:      	leaq	0x22(%rbp), %rdi
    3117:      	movl	$0x2, %ecx
    311c:      	movl	$0x4, %eax
    3121:      	movl	$0x2, %esi
    3126:      	movq	%r13, %rdx
    3129:      	callq	*%rax
    312b:      	movzwl	0x22(%rbp), %eax
    312f:      	movbew	%ax, 0x22(%rbp)
    3135:      	movq	0x28(%rbp), %rax
    3139:      	movq	%rax, 0x68(%rsp)
    313e:      	movq	(%rip), %rdi            # 0x3145 <generic_rawtp_process_event+0x2f75>
    3145:      	leaq	0x68(%rsp), %rsi
    314a:      	movl	$0x1, %eax
    314f:      	callq	*%rax
    3151:      	testq	%rax, %rax
    3154:      	je	0x316e <generic_rawtp_process_event+0x2f9e>
    3156:      	movl	(%rax), %ecx
    3158:      	movq	0x40(%rsp), %rdx
    315d:      	movl	%ecx, 0x10(%rdx)
    3160:      	movq	0x8(%rax), %rcx
    3164:      	movq	%rcx, 0x18(%rdx)
    3168:      	movl	0x4(%rax), %eax
    316b:      	movl	%eax, 0x7c(%rdx)
    316e:      	movl	$0x40, %r13d
    3174:      	jmp	0x3eba <generic_rawtp_process_event+0x3cea>
    3179:      	movq	%rbp, %rax
    317c:      	addq	$0x5e60, %rax           # imm = 0x5E60
    3182:      	jmp	0x3198 <generic_rawtp_process_event+0x2fc8>
    3184:      	movq	%rbp, %rax
    3187:      	addq	$0x5e68, %rax           # imm = 0x5E68
    318d:      	jmp	0x3198 <generic_rawtp_process_event+0x2fc8>
    318f:      	movq	%rbp, %rax
    3192:      	addq	$0x5e50, %rax           # imm = 0x5E50
    3198:      	movq	(%rax), %rbx
    319b:      	testb	$0x10, 0x40(%rsp)
    31a0:      	jne	0x3544 <generic_rawtp_process_event+0x3374>
    31a6:      	testq	%rbx, %rbx
    31a9:      	je	0x360c <generic_rawtp_process_event+0x343c>
    31af:      	leaq	0x68(%rsp), %rdi
    31b4:      	movl	$0x10, %ecx
    31b9:      	movl	$0x4, %eax
    31be:      	movq	0x10(%rsp), %rdx
    31c3:      	movl	$0x10, %esi
    31c8:      	callq	*%rax
    31ca:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    31cf:      	testl	%eax, %eax
    31d1:      	js	0x3512 <generic_rawtp_process_event+0x3342>
    31d7:      	movq	0x70(%rsp), %r14
    31dc:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    31e1:      	cmpq	$0xffe, %r14            # imm = 0xFFE
    31e8:      	ja	0x3512 <generic_rawtp_process_event+0x3342>
    31ee:      	movq	0xc8(%rsp), %rax
    31f6:      	leaq	0xc(%rax), %r15
    31fa:      	leaq	(%r15,%r13), %rdi
    31fe:      	movq	0x68(%rsp), %rcx
    3203:      	movl	$0x4, %eax
    3208:      	movq	0x68(%rsp), %rdx
    320d:      	movl	%r14d, %esi
    3210:      	callq	*%rax
    3212:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3217:      	testl	%eax, %eax
    3219:      	js	0x3512 <generic_rawtp_process_event+0x3342>
    321f:      	cmpq	$0x1, %rbx
    3223:      	je	0x360f <generic_rawtp_process_event+0x343f>
    3229:      	movq	0x10(%rsp), %rax
    322e:      	leaq	0x10(%rax), %rdx
    3232:      	leaq	0x68(%rsp), %rdi
    3237:      	movl	$0x10, %ecx
    323c:      	movl	$0x4, %eax
    3241:      	movl	$0x10, %esi
    3246:      	callq	*%rax
    3248:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    324d:      	testl	%eax, %eax
    324f:      	js	0x3512 <generic_rawtp_process_event+0x3342>
    3255:      	movq	0x70(%rsp), %r12
    325a:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    325f:      	cmpq	$0xffe, %r12            # imm = 0xFFE
    3266:      	ja	0x3512 <generic_rawtp_process_event+0x3342>
    326c:      	addq	%r14, %r15
    326f:      	leaq	(%r15,%r13), %rdi
    3273:      	movq	0x68(%rsp), %rcx
    3278:      	movl	$0x4, %eax
    327d:      	movq	0x68(%rsp), %rdx
    3282:      	movl	%r12d, %esi
    3285:      	callq	*%rax
    3287:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    328c:      	testl	%eax, %eax
    328e:      	js	0x3512 <generic_rawtp_process_event+0x3342>
    3294:      	addq	%r12, %r14
    3297:      	cmpq	$0x3, %rbx
    329b:      	jb	0x360f <generic_rawtp_process_event+0x343f>
    32a1:      	movq	0x10(%rsp), %rax
    32a6:      	leaq	0x20(%rax), %rdx
    32aa:      	leaq	0x68(%rsp), %rdi
    32af:      	movl	$0x10, %ecx
    32b4:      	movl	$0x4, %eax
    32b9:      	movl	$0x10, %esi
    32be:      	callq	*%rax
    32c0:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    32c5:      	testl	%eax, %eax
    32c7:      	js	0x3512 <generic_rawtp_process_event+0x3342>
    32cd:      	movq	0x70(%rsp), %rbp
    32d2:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    32d7:      	cmpq	$0xffe, %rbp            # imm = 0xFFE
    32de:      	ja	0x3512 <generic_rawtp_process_event+0x3342>
    32e4:      	addq	%r15, %r12
    32e7:      	movl	%r12d, %edi
    32ea:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    32f0:      	addq	%r13, %rdi
    32f3:      	movq	0x68(%rsp), %rcx
    32f8:      	movl	$0x4, %eax
    32fd:      	movq	0x68(%rsp), %rdx
    3302:      	movl	%ebp, %esi
    3304:      	callq	*%rax
    3306:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    330b:      	testl	%eax, %eax
    330d:      	js	0x3512 <generic_rawtp_process_event+0x3342>
    3313:      	addq	%rbp, %r14
    3316:      	cmpq	$0x3, %rbx
    331a:      	je	0x360f <generic_rawtp_process_event+0x343f>
    3320:      	movq	0x10(%rsp), %rax
    3325:      	leaq	0x30(%rax), %rdx
    3329:      	leaq	0x68(%rsp), %rdi
    332e:      	movl	$0x10, %ecx
    3333:      	movl	$0x4, %eax
    3338:      	movl	$0x10, %esi
    333d:      	callq	*%rax
    333f:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3344:      	testl	%eax, %eax
    3346:      	js	0x3512 <generic_rawtp_process_event+0x3342>
    334c:      	movq	0x70(%rsp), %rax
    3351:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    3356:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    335c:      	ja	0x3512 <generic_rawtp_process_event+0x3342>
    3362:      	movq	%rax, %r15
    3365:      	addq	%r12, %rbp
    3368:      	movl	%ebp, %edi
    336a:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    3370:      	addq	%r13, %rdi
    3373:      	movq	0x68(%rsp), %rcx
    3378:      	movl	$0x4, %eax
    337d:      	movq	%r15, %rsi
    3380:      	movq	0x68(%rsp), %rdx
    3385:      	callq	*%rax
    3387:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    338c:      	testl	%eax, %eax
    338e:      	js	0x3512 <generic_rawtp_process_event+0x3342>
    3394:      	addq	%r15, %r14
    3397:      	cmpq	$0x5, %rbx
    339b:      	jb	0x360f <generic_rawtp_process_event+0x343f>
    33a1:      	movq	0x10(%rsp), %rax
    33a6:      	leaq	0x40(%rax), %rdx
    33aa:      	leaq	0x68(%rsp), %rdi
    33af:      	movl	$0x10, %ecx
    33b4:      	movl	$0x4, %eax
    33b9:      	movl	$0x10, %esi
    33be:      	callq	*%rax
    33c0:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    33c5:      	testl	%eax, %eax
    33c7:      	js	0x3512 <generic_rawtp_process_event+0x3342>
    33cd:      	movq	0x70(%rsp), %rax
    33d2:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    33d7:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    33dd:      	ja	0x3512 <generic_rawtp_process_event+0x3342>
    33e3:      	movq	%rax, %r12
    33e6:      	movq	%r15, %rdi
    33e9:      	addq	%rbp, %rdi
    33ec:      	movq	%rdi, %r15
    33ef:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    33f5:      	addq	%r13, %rdi
    33f8:      	movq	0x68(%rsp), %rcx
    33fd:      	movl	$0x4, %eax
    3402:      	movq	%r12, %rsi
    3405:      	movq	0x68(%rsp), %rdx
    340a:      	callq	*%rax
    340c:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3411:      	testl	%eax, %eax
    3413:      	js	0x3512 <generic_rawtp_process_event+0x3342>
    3419:      	addq	%r12, %r14
    341c:      	cmpq	$0x5, %rbx
    3420:      	je	0x360f <generic_rawtp_process_event+0x343f>
    3426:      	movq	0x10(%rsp), %rax
    342b:      	leaq	0x50(%rax), %rdx
    342f:      	leaq	0x68(%rsp), %rdi
    3434:      	movl	$0x10, %ecx
    3439:      	movl	$0x4, %eax
    343e:      	movl	$0x10, %esi
    3443:      	callq	*%rax
    3445:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    344a:      	testl	%eax, %eax
    344c:      	js	0x3512 <generic_rawtp_process_event+0x3342>
    3452:      	movq	0x70(%rsp), %rbp
    3457:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    345c:      	cmpq	$0xffe, %rbp            # imm = 0xFFE
    3463:      	ja	0x3512 <generic_rawtp_process_event+0x3342>
    3469:      	addq	%r15, %r12
    346c:      	movq	%r12, %r15
    346f:      	movl	%r12d, %edi
    3472:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    3478:      	addq	%r13, %rdi
    347b:      	movq	0x68(%rsp), %rcx
    3480:      	movl	$0x4, %eax
    3485:      	movq	0x68(%rsp), %rdx
    348a:      	movl	%ebp, %esi
    348c:      	callq	*%rax
    348e:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3493:      	testl	%eax, %eax
    3495:      	js	0x3512 <generic_rawtp_process_event+0x3342>
    3497:      	addq	%rbp, %r14
    349a:      	cmpq	$0x7, %rbx
    349e:      	jb	0x360f <generic_rawtp_process_event+0x343f>
    34a4:      	movq	0x10(%rsp), %rdx
    34a9:      	addq	$0x60, %rdx
    34ad:      	leaq	0x68(%rsp), %rdi
    34b2:      	movl	$0x10, %ecx
    34b7:      	movl	$0x4, %eax
    34bc:      	movl	$0x10, %esi
    34c1:      	callq	*%rax
    34c3:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    34c8:      	testl	%eax, %eax
    34ca:      	js	0x3512 <generic_rawtp_process_event+0x3342>
    34cc:      	movq	0x70(%rsp), %rbx
    34d1:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    34d6:      	cmpq	$0xffe, %rbx            # imm = 0xFFE
    34dd:      	ja	0x3512 <generic_rawtp_process_event+0x3342>
    34df:      	addq	%r15, %rbp
    34e2:      	andl	$0x3fff, %ebp           # imm = 0x3FFF
    34e8:      	addq	%r13, %rbp
    34eb:      	movq	0x68(%rsp), %rcx
    34f0:      	movl	$0x4, %eax
    34f5:      	movq	0x68(%rsp), %rdx
    34fa:      	movq	%rbp, %rdi
    34fd:      	movl	%ebx, %esi
    34ff:      	callq	*%rax
    3501:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3506:      	testl	%eax, %eax
    3508:      	js	0x3512 <generic_rawtp_process_event+0x3342>
    350a:      	addq	%rbx, %r14
    350d:      	jmp	0x360f <generic_rawtp_process_event+0x343f>
    3512:      	movq	0x48(%rsp), %rax
    3517:      	movl	%ecx, (%r13,%rax)
    351c:      	movq	0x18(%rsp), %rbx
    3521:      	movq	0x28(%rsp), %r14
    3526:      	movl	$0x4, %r13d
    352c:      	jmp	0x1761 <generic_rawtp_process_event+0x1591>
    3531:      	xorl	%ebx, %ebx
    3533:      	movl	$0x0, %r14d
    3539:      	testb	$0x10, 0x40(%rsp)
    353e:      	je	0x360f <generic_rawtp_process_event+0x343f>
    3544:      	movl	$0xe, %eax
    3549:      	callq	*%rax
    354b:      	cmpq	$-0x16, %rax
    354f:      	jne	0x3575 <generic_rawtp_process_event+0x33a5>
    3551:      	movq	0x18(%rsp), %rax
    3556:      	leaq	0x20(%rax), %rdx
    355a:      	leaq	0x68(%rsp), %rdi
    355f:      	movl	$0x8, %ecx
    3564:      	movl	$0x4, %eax
    3569:      	movl	$0x8, %esi
    356e:      	callq	*%rax
    3570:      	movq	0x68(%rsp), %rax
    3575:      	movq	0x8(%rbp), %rcx
    3579:      	movq	0x60(%rbp), %rdx
    357d:      	movq	%rcx, 0x68(%rsp)
    3582:      	movq	0x10(%rsp), %rcx
    3587:      	movq	%rcx, 0x70(%rsp)
    358c:      	movq	%rbx, 0x78(%rsp)
    3591:      	movq	%rdx, 0x58(%rsp)
    3596:      	movq	%rax, 0x60(%rsp)
    359b:      	movq	(%rip), %rdi            # 0x35a2 <generic_rawtp_process_event+0x33d2>
    35a2:      	xorl	%ecx, %ecx
    35a4:      	leaq	0x58(%rsp), %rsi
    35a9:      	leaq	0x68(%rsp), %rdx
    35ae:      	movl	$0x2, %eax
    35b3:      	xorl	%ecx, %ecx
    35b5:      	callq	*%rax
    35b7:      	testq	%rax, %rax
    35ba:      	je	0x36c3 <generic_rawtp_process_event+0x34f3>
    35c0:      	negl	%eax
    35c2:      	movw	%ax, 0xb0(%rsp)
    35ca:      	movw	$0x5, 0xb2(%rsp)
    35d4:      	movabsq	$0x200000057, %rax      # imm = 0x200000057
    35de:      	movq	%rax, 0xb4(%rsp)
    35e6:      	movq	(%rip), %rdi            # 0x35ed <generic_rawtp_process_event+0x341d>
    35ed:      	leaq	0xb0(%rsp), %rsi
    35f5:      	movl	$0x1, %eax
    35fa:      	callq	*%rax
    35fc:      	testq	%rax, %rax
    35ff:      	je	0x369c <generic_rawtp_process_event+0x34cc>
    3605:      	incl	(%rax)
    3607:      	jmp	0x36c3 <generic_rawtp_process_event+0x34f3>
    360c:      	xorl	%r14d, %r14d
    360f:      	movq	0x48(%rsp), %rax
    3614:      	movl	%r14d, (%r13,%rax)
    3619:      	movl	%r14d, 0x4(%r13,%rax)
    361e:      	addq	$0x8, %r14
    3622:      	movq	%r14, %r13
    3625:      	jmp	0x3eba <generic_rawtp_process_event+0x3cea>
    362a:      	cmpl	$0x33, %eax
    362d:      	je	0x39ce <generic_rawtp_process_event+0x37fe>
    3633:      	cmpl	$0x3c, %eax
    3636:      	je	0x36dc <generic_rawtp_process_event+0x350c>
    363c:      	cmpl	$0xff, %eax
    3641:      	jne	0x3a9b <generic_rawtp_process_event+0x38cb>
    3647:      	movw	$0x28, 0x2(%rbx)
    364d:      	movw	$0x28, %ax
    3651:      	jmp	0x39dd <generic_rawtp_process_event+0x380d>
    3656:      	movl	$0x1, 0xc0(%rsp)
    3661:      	movq	(%rip), %rdi            # 0x3668 <generic_rawtp_process_event+0x3498>
    3668:      	xorl	%ecx, %ecx
    366a:      	leaq	0xb0(%rsp), %rsi
    3672:      	leaq	0xc0(%rsp), %rdx
    367a:      	movl	$0x2, %eax
    367f:      	xorl	%ecx, %ecx
    3681:      	callq	*%rax
    3683:      	movq	0xa8(%rsp), %rax
    368b:      	movl	$0xfffffffc, (%rax)     # imm = 0xFFFFFFFC
    3691:      	movl	$0x4, %r13d
    3697:      	jmp	0x3eba <generic_rawtp_process_event+0x3cea>
    369c:      	movl	$0x1, 0x30(%rsp)
    36a4:      	movq	(%rip), %rdi            # 0x36ab <generic_rawtp_process_event+0x34db>
    36ab:      	xorl	%ecx, %ecx
    36ad:      	leaq	0xb0(%rsp), %rsi
    36b5:      	leaq	0x30(%rsp), %rdx
    36ba:      	movl	$0x2, %eax
    36bf:      	xorl	%ecx, %ecx
    36c1:      	callq	*%rax
    36c3:      	movq	0x48(%rsp), %rax
    36c8:      	movl	$0xfffffffc, (%r13,%rax) # imm = 0xFFFFFFFC
    36d1:      	movl	$0x4, %r13d
    36d7:      	jmp	0x3eba <generic_rawtp_process_event+0x3cea>
    36dc:      	movzbl	0x7(%rbx), %eax
    36e0:      	leal	0x8(,%rax,8), %eax
    36e7:      	jmp	0x39d9 <generic_rawtp_process_event+0x3809>
    36ec:      	movl	$0x4, %r13d
    36f2:      	jmp	0x1761 <generic_rawtp_process_event+0x1591>
    36f7:      	leaq	0x5e60(%rbp), %rax
    36fe:      	jmp	0x3710 <generic_rawtp_process_event+0x3540>
    3700:      	leaq	0x5e68(%rbp), %rax
    3707:      	jmp	0x3710 <generic_rawtp_process_event+0x3540>
    3709:      	leaq	0x5e50(%rbp), %rax
    3710:      	movq	(%rax), %rax
    3713:      	movq	%rax, 0x30(%rsp)
    3718:      	leaq	0x50(%rsp), %rdi
    371d:      	leaq	0x30(%rsp), %rdx
    3722:      	movl	$0x8, %ecx
    3727:      	movl	$0x4, %eax
    372c:      	movl	$0x8, %ebx
    3731:      	movl	$0x8, %esi
    3736:      	callq	*%rax
    3738:      	movq	0x50(%rsp), %r14
    373d:      	testb	$0x20, %r15b
    3741:      	je	0x38fe <generic_rawtp_process_event+0x372e>
    3747:      	cmpq	$0x1000, %r14           # imm = 0x1000
    374e:      	jb	0x38d3 <generic_rawtp_process_event+0x3703>
    3754:      	movq	0xa8(%rsp), %rax
    375c:      	movl	$0x1, (%rax)
    3762:      	movl	$0x0, 0x58(%rsp)
    376a:      	movq	(%rip), %rdi            # 0x3771 <generic_rawtp_process_event+0x35a1>
    3771:      	leaq	0x58(%rsp), %rsi
    3776:      	movl	$0x1, %eax
    377b:      	callq	*%rax
    377d:      	testq	%rax, %rax
    3780:      	je	0x3956 <generic_rawtp_process_event+0x3786>
    3786:      	movq	%rax, %rbx
    3789:      	movl	$0x18, (%rax)
    378f:      	movl	$0xe, %eax
    3794:      	callq	*%rax
    3796:      	leaq	0x10(%rbx), %r15
    379a:      	movq	%rax, 0x10(%rbx)
    379e:      	cmpq	$-0x16, %rax
    37a2:      	jne	0x37cb <generic_rawtp_process_event+0x35fb>
    37a4:      	movq	0x18(%rsp), %rax
    37a9:      	leaq	0x20(%rax), %rdx
    37ad:      	leaq	0x68(%rsp), %rdi
    37b2:      	movl	$0x8, %ecx
    37b7:      	movl	$0x4, %eax
    37bc:      	movl	$0x8, %esi
    37c1:      	callq	*%rax
    37c3:      	movq	0x68(%rsp), %rax
    37c8:      	movq	%rax, (%r15)
    37cb:      	movl	$0x7d, %eax
    37d0:      	callq	*%rax
    37d2:      	movq	%rax, 0x18(%rbx)
    37d6:      	movq	(%r15), %rax
    37d9:      	movq	0x8(%r15), %rcx
    37dd:      	movq	0xa8(%rsp), %rdx
    37e5:      	movq	%rax, 0x14(%rdx)
    37e9:      	movq	%rcx, 0x1c(%rdx)
    37ed:      	movq	%rbx, %rax
    37f0:      	addq	$0x20, %rax
    37f4:      	movq	%rax, 0x40(%rsp)
    37f9:      	movl	$0xa, %r15d
    37ff:      	xorl	%r13d, %r13d
    3802:      	movq	%r14, %rbp
    3805:      	subq	%r13, %rbp
    3808:      	js	0x3acd <generic_rawtp_process_event+0x38fd>
    380e:      	movq	0x10(%rsp), %rax
    3813:      	leaq	(%rax,%r13), %rdx
    3817:      	cmpq	$0x7fe0, %rbp           # imm = 0x7FE0
    381e:      	movl	$0x7fe0, %eax           # imm = 0x7FE0
    3823:      	cmovaeq	%rax, %rbp
    3827:      	movl	$0x4, %eax
    382c:      	movq	0x40(%rsp), %rdi
    3831:      	movl	%ebp, %esi
    3833:      	callq	*%rax
    3835:      	testl	%eax, %eax
    3837:      	js	0x38a8 <generic_rawtp_process_event+0x36d8>
    3839:      	leal	0x20(%rbp), %r12d
    383d:      	movl	%r12d, 0x4(%rbx)
    3841:      	movl	$0x0, 0x68(%rsp)
    3849:      	movl	$0x1, %eax
    384e:      	movq	(%rip), %rdi            # 0x3855 <generic_rawtp_process_event+0x3685>
    3855:      	leaq	0x68(%rsp), %rsi
    385a:      	callq	*%rax
    385c:      	testq	%rax, %rax
    385f:      	je	0x388c <generic_rawtp_process_event+0x36bc>
    3861:      	cmpb	$0x0, 0x28(%rax)
    3865:      	je	0x388c <generic_rawtp_process_event+0x36bc>
    3867:      	movl	$0x19, %eax
    386c:      	movq	0x18(%rsp), %rdi
    3871:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    3876:      	movq	(%rip), %rsi            # 0x387d <generic_rawtp_process_event+0x36ad>
    387d:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    3882:      	movq	%rbx, %rcx
    3885:      	movq	%r12, %r8
    3888:      	callq	*%rax
    388a:      	jmp	0x38a4 <generic_rawtp_process_event+0x36d4>
    388c:      	movl	$0x82, %eax
    3891:      	xorl	%ecx, %ecx
    3893:      	movq	(%rip), %rdi            # 0x389a <generic_rawtp_process_event+0x36ca>
    389a:      	movq	%rbx, %rsi
    389d:      	movq	%r12, %rdx
    38a0:      	xorl	%ecx, %ecx
    38a2:      	callq	*%rax
    38a4:      	testl	%eax, %eax
    38a6:      	jns	0x38ab <generic_rawtp_process_event+0x36db>
    38a8:      	movslq	%eax, %rbp
    38ab:      	testl	%ebp, %ebp
    38ad:      	js	0x3ad6 <generic_rawtp_process_event+0x3906>
    38b3:      	andl	$0x7fffffff, %ebp       # imm = 0x7FFFFFFF
    38b9:      	addq	%rbp, %r13
    38bc:      	cmpq	%r14, %r13
    38bf:      	je	0x3b30 <generic_rawtp_process_event+0x3960>
    38c5:      	decl	%r15d
    38c8:      	jne	0x3802 <generic_rawtp_process_event+0x3632>
    38ce:      	jmp	0x3e67 <generic_rawtp_process_event+0x3c97>
    38d3:      	addq	$0x90, %rbp
    38da:      	movq	0xc8(%rsp), %rax
    38e2:      	movl	$0x0, 0x4(%rbp,%rax)
    38ea:      	addq	%rbp, %rax
    38ed:      	addq	$0x8, %rax
    38f1:      	movq	%rax, 0xa8(%rsp)
    38f9:      	movl	$0xc, %ebx
    38fe:      	cmpq	$0xfff, %r14            # imm = 0xFFF
    3905:      	movl	$0xfff, %r13d           # imm = 0xFFF
    390b:      	cmovbq	%r14, %r13
    390f:      	movq	0xa8(%rsp), %rax
    3917:      	leaq	0x8(%rax), %rdi
    391b:      	movl	$0x4, %eax
    3920:      	movq	0x10(%rsp), %rdx
    3925:      	movl	%r13d, %esi
    3928:      	callq	*%rax
    392a:      	testl	%eax, %eax
    392c:      	js	0x3948 <generic_rawtp_process_event+0x3778>
    392e:      	movq	0xa8(%rsp), %rax
    3936:      	movl	%r14d, (%rax)
    3939:      	movl	%r13d, 0x4(%rax)
    393d:      	addq	%r13, %rbx
    3940:      	movq	%rbx, %r13
    3943:      	jmp	0x3eba <generic_rawtp_process_event+0x3cea>
    3948:      	movq	0xa8(%rsp), %rax
    3950:      	movl	$0xfffffffe, (%rax)     # imm = 0xFFFFFFFE
    3956:      	movl	$0x4, %r13d
    395c:      	jmp	0x3eba <generic_rawtp_process_event+0x3cea>
    3961:      	movq	$-0x1, %rbp
    3968:      	jmp	0x396d <generic_rawtp_process_event+0x379d>
    396a:      	movq	%r13, %rbp
    396d:      	movl	$0x0, 0x68(%rsp)
    3975:      	movq	(%rip), %rdi            # 0x397c <generic_rawtp_process_event+0x37ac>
    397c:      	leaq	0x68(%rsp), %rsi
    3981:      	movl	$0x1, %eax
    3986:      	callq	*%rax
    3988:      	testq	%rax, %rax
    398b:      	je	0x3d1c <generic_rawtp_process_event+0x3b4c>
    3991:      	cmpq	$-0xc, %rbp
    3995:      	jg	0x3aa4 <generic_rawtp_process_event+0x38d4>
    399b:      	cmpq	$-0x1c, %rbp
    399f:      	je	0x3cf2 <generic_rawtp_process_event+0x3b22>
    39a5:      	cmpq	$-0x16, %rbp
    39a9:      	je	0x3d0a <generic_rawtp_process_event+0x3b3a>
    39af:      	cmpq	$-0x10, %rbp
    39b3:      	jne	0x3d02 <generic_rawtp_process_event+0x3b32>
    39b9:      	addq	$0x558, %rax            # imm = 0x558
    39bf:      	jmp	0x3d18 <generic_rawtp_process_event+0x3b48>
    39c4:      	movq	0x10(%rsp), %rbp
    39c9:      	jmp	0x3d1c <generic_rawtp_process_event+0x3b4c>
    39ce:      	movzbl	0x7(%rbx), %eax
    39d2:      	leal	0x8(,%rax,4), %eax
    39d9:      	movw	%ax, 0x2(%rbx)
    39dd:      	addw	(%rbx), %ax
    39e0:      	movw	%ax, (%rbx)
    39e3:      	movzbl	0x6(%rbx), %r15d
    39e8:      	cmpq	$0x3c, %r15
    39ec:      	ja	0x426d <generic_rawtp_process_event+0x409d>
    39f2:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    39fc:      	btq	%r15, %rcx
    3a00:      	jae	0x426d <generic_rawtp_process_event+0x409d>
    3a06:      	movb	%r15b, 0x5(%rbx)
    3a0a:      	movzwl	%ax, %ecx
    3a0d:      	addq	%r14, %rcx
    3a10:      	movl	$0x2, %edx
    3a15:      	movl	$0x4, %eax
    3a1a:      	movq	0x10(%rsp), %rdi
    3a1f:      	movzwl	(%rbx), %edx
    3a22:      	addq	%r14, %rdx
    3a25:      	movl	$0x2, %esi
    3a2a:      	callq	*%rax
    3a2c:      	testq	%rax, %rax
    3a2f:      	js	0x40a9 <generic_rawtp_process_event+0x3ed9>
    3a35:      	movzbl	0x5(%rbx), %eax
    3a39:      	cmpl	$0x32, %eax
    3a3c:      	jg	0x3a5f <generic_rawtp_process_event+0x388f>
    3a3e:      	testl	%eax, %eax
    3a40:      	je	0x3a87 <generic_rawtp_process_event+0x38b7>
    3a42:      	cmpl	$0x2b, %eax
    3a45:      	je	0x3a87 <generic_rawtp_process_event+0x38b7>
    3a47:      	cmpl	$0x2c, %eax
    3a4a:      	jne	0x3b49 <generic_rawtp_process_event+0x3979>
    3a50:      	movw	$0x8, 0x2(%rbx)
    3a56:      	movw	$0x8, %ax
    3a5a:      	jmp	0x3b4d <generic_rawtp_process_event+0x397d>
    3a5f:      	cmpl	$0x33, %eax
    3a62:      	je	0x3b38 <generic_rawtp_process_event+0x3968>
    3a68:      	cmpl	$0x3c, %eax
    3a6b:      	je	0x3a87 <generic_rawtp_process_event+0x38b7>
    3a6d:      	cmpl	$0xff, %eax
    3a72:      	jne	0x3b49 <generic_rawtp_process_event+0x3979>
    3a78:      	movw	$0x28, 0x2(%rbx)
    3a7e:      	movw	$0x28, %ax
    3a82:      	jmp	0x3b4d <generic_rawtp_process_event+0x397d>
    3a87:      	movzbl	0x7(%rbx), %eax
    3a8b:      	leal	0x8(,%rax,8), %eax
    3a92:      	movw	%ax, 0x2(%rbx)
    3a96:      	jmp	0x3b4d <generic_rawtp_process_event+0x397d>
    3a9b:      	movzwl	0x2(%rbx), %eax
    3a9f:      	jmp	0x39dd <generic_rawtp_process_event+0x380d>
    3aa4:      	cmpq	$-0xb, %rbp
    3aa8:      	je	0x3cfa <generic_rawtp_process_event+0x3b2a>
    3aae:      	cmpq	$-0x7, %rbp
    3ab2:      	je	0x3d12 <generic_rawtp_process_event+0x3b42>
    3ab8:      	cmpq	$-0x2, %rbp
    3abc:      	jne	0x3d02 <generic_rawtp_process_event+0x3b32>
    3ac2:      	addq	$0x548, %rax            # imm = 0x548
    3ac8:      	jmp	0x3d18 <generic_rawtp_process_event+0x3b48>
    3acd:      	movq	$-0x1, %r13
    3ad4:      	jmp	0x3ad9 <generic_rawtp_process_event+0x3909>
    3ad6:      	movq	%rbp, %r13
    3ad9:      	movl	$0x0, 0x68(%rsp)
    3ae1:      	movq	(%rip), %rdi            # 0x3ae8 <generic_rawtp_process_event+0x3918>
    3ae8:      	leaq	0x68(%rsp), %rsi
    3aed:      	movl	$0x1, %eax
    3af2:      	callq	*%rax
    3af4:      	testq	%rax, %rax
    3af7:      	je	0x3e67 <generic_rawtp_process_event+0x3c97>
    3afd:      	cmpq	$-0xc, %r13
    3b01:      	jg	0x3bf6 <generic_rawtp_process_event+0x3a26>
    3b07:      	cmpq	$-0x1c, %r13
    3b0b:      	je	0x3e3d <generic_rawtp_process_event+0x3c6d>
    3b11:      	cmpq	$-0x16, %r13
    3b15:      	je	0x3e45 <generic_rawtp_process_event+0x3c75>
    3b1b:      	cmpq	$-0x10, %r13
    3b1f:      	jne	0x3e5d <generic_rawtp_process_event+0x3c8d>
    3b25:      	addq	$0x558, %rax            # imm = 0x558
    3b2b:      	jmp	0x3e63 <generic_rawtp_process_event+0x3c93>
    3b30:      	movq	%r14, %r13
    3b33:      	jmp	0x3e67 <generic_rawtp_process_event+0x3c97>
    3b38:      	movzbl	0x7(%rbx), %eax
    3b3c:      	leal	0x8(,%rax,4), %eax
    3b43:      	movw	%ax, 0x2(%rbx)
    3b47:      	jmp	0x3b4d <generic_rawtp_process_event+0x397d>
    3b49:      	movzwl	0x2(%rbx), %eax
    3b4d:      	addw	(%rbx), %ax
    3b50:      	movw	%ax, (%rbx)
    3b53:      	movzbl	0x6(%rbx), %r15d
    3b58:      	cmpq	$0x3c, %r15
    3b5c:      	ja	0x426d <generic_rawtp_process_event+0x409d>
    3b62:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3b6c:      	btq	%r15, %rcx
    3b70:      	jae	0x426d <generic_rawtp_process_event+0x409d>
    3b76:      	movb	%r15b, 0x5(%rbx)
    3b7a:      	movzwl	%ax, %ecx
    3b7d:      	addq	%r14, %rcx
    3b80:      	movl	$0x2, %edx
    3b85:      	movl	$0x4, %eax
    3b8a:      	movq	0x10(%rsp), %rdi
    3b8f:      	movzwl	(%rbx), %edx
    3b92:      	addq	%r14, %rdx
    3b95:      	movl	$0x2, %esi
    3b9a:      	callq	*%rax
    3b9c:      	testq	%rax, %rax
    3b9f:      	js	0x40a9 <generic_rawtp_process_event+0x3ed9>
    3ba5:      	movzbl	0x5(%rbx), %eax
    3ba9:      	cmpl	$0x32, %eax
    3bac:      	jg	0x3bc8 <generic_rawtp_process_event+0x39f8>
    3bae:      	testl	%eax, %eax
    3bb0:      	je	0x3be5 <generic_rawtp_process_event+0x3a15>
    3bb2:      	cmpl	$0x2b, %eax
    3bb5:      	je	0x3be5 <generic_rawtp_process_event+0x3a15>
    3bb7:      	cmpl	$0x2c, %eax
    3bba:      	jne	0x3c30 <generic_rawtp_process_event+0x3a60>
    3bbc:      	movw	$0x8, 0x2(%rbx)
    3bc2:      	movw	$0x8, %ax
    3bc6:      	jmp	0x3c34 <generic_rawtp_process_event+0x3a64>
    3bc8:      	cmpl	$0x33, %eax
    3bcb:      	je	0x3c1f <generic_rawtp_process_event+0x3a4f>
    3bcd:      	cmpl	$0x3c, %eax
    3bd0:      	je	0x3be5 <generic_rawtp_process_event+0x3a15>
    3bd2:      	cmpl	$0xff, %eax
    3bd7:      	jne	0x3c30 <generic_rawtp_process_event+0x3a60>
    3bd9:      	movw	$0x28, 0x2(%rbx)
    3bdf:      	movw	$0x28, %ax
    3be3:      	jmp	0x3c34 <generic_rawtp_process_event+0x3a64>
    3be5:      	movzbl	0x7(%rbx), %eax
    3be9:      	leal	0x8(,%rax,8), %eax
    3bf0:      	movw	%ax, 0x2(%rbx)
    3bf4:      	jmp	0x3c34 <generic_rawtp_process_event+0x3a64>
    3bf6:      	cmpq	$-0xb, %r13
    3bfa:      	je	0x3e4d <generic_rawtp_process_event+0x3c7d>
    3c00:      	cmpq	$-0x7, %r13
    3c04:      	je	0x3e55 <generic_rawtp_process_event+0x3c85>
    3c0a:      	cmpq	$-0x2, %r13
    3c0e:      	jne	0x3e5d <generic_rawtp_process_event+0x3c8d>
    3c14:      	addq	$0x548, %rax            # imm = 0x548
    3c1a:      	jmp	0x3e63 <generic_rawtp_process_event+0x3c93>
    3c1f:      	movzbl	0x7(%rbx), %eax
    3c23:      	leal	0x8(,%rax,4), %eax
    3c2a:      	movw	%ax, 0x2(%rbx)
    3c2e:      	jmp	0x3c34 <generic_rawtp_process_event+0x3a64>
    3c30:      	movzwl	0x2(%rbx), %eax
    3c34:      	addw	(%rbx), %ax
    3c37:      	movw	%ax, (%rbx)
    3c3a:      	movzbl	0x6(%rbx), %r15d
    3c3f:      	cmpq	$0x3c, %r15
    3c43:      	ja	0x426d <generic_rawtp_process_event+0x409d>
    3c49:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3c53:      	btq	%r15, %rcx
    3c57:      	jae	0x426d <generic_rawtp_process_event+0x409d>
    3c5d:      	movb	%r15b, 0x5(%rbx)
    3c61:      	movzwl	%ax, %ecx
    3c64:      	addq	%r14, %rcx
    3c67:      	movl	$0x2, %edx
    3c6c:      	movl	$0x4, %eax
    3c71:      	movq	0x10(%rsp), %rdi
    3c76:      	movzwl	(%rbx), %edx
    3c79:      	addq	%r14, %rdx
    3c7c:      	movl	$0x2, %esi
    3c81:      	callq	*%rax
    3c83:      	testq	%rax, %rax
    3c86:      	js	0x40a9 <generic_rawtp_process_event+0x3ed9>
    3c8c:      	movzbl	0x5(%rbx), %eax
    3c90:      	cmpl	$0x32, %eax
    3c93:      	jg	0x3cb6 <generic_rawtp_process_event+0x3ae6>
    3c95:      	testl	%eax, %eax
    3c97:      	je	0x3cde <generic_rawtp_process_event+0x3b0e>
    3c99:      	cmpl	$0x2b, %eax
    3c9c:      	je	0x3cde <generic_rawtp_process_event+0x3b0e>
    3c9e:      	cmpl	$0x2c, %eax
    3ca1:      	jne	0x3d7b <generic_rawtp_process_event+0x3bab>
    3ca7:      	movw	$0x8, 0x2(%rbx)
    3cad:      	movw	$0x8, %ax
    3cb1:      	jmp	0x3d7f <generic_rawtp_process_event+0x3baf>
    3cb6:      	cmpl	$0x33, %eax
    3cb9:      	je	0x3d6a <generic_rawtp_process_event+0x3b9a>
    3cbf:      	cmpl	$0x3c, %eax
    3cc2:      	je	0x3cde <generic_rawtp_process_event+0x3b0e>
    3cc4:      	cmpl	$0xff, %eax
    3cc9:      	jne	0x3d7b <generic_rawtp_process_event+0x3bab>
    3ccf:      	movw	$0x28, 0x2(%rbx)
    3cd5:      	movw	$0x28, %ax
    3cd9:      	jmp	0x3d7f <generic_rawtp_process_event+0x3baf>
    3cde:      	movzbl	0x7(%rbx), %eax
    3ce2:      	leal	0x8(,%rax,8), %eax
    3ce9:      	movw	%ax, 0x2(%rbx)
    3ced:      	jmp	0x3d7f <generic_rawtp_process_event+0x3baf>
    3cf2:      	addq	$0x568, %rax            # imm = 0x568
    3cf8:      	jmp	0x3d18 <generic_rawtp_process_event+0x3b48>
    3cfa:      	addq	$0x570, %rax            # imm = 0x570
    3d00:      	jmp	0x3d18 <generic_rawtp_process_event+0x3b48>
    3d02:      	addq	$0x540, %rax            # imm = 0x540
    3d08:      	jmp	0x3d18 <generic_rawtp_process_event+0x3b48>
    3d0a:      	addq	$0x560, %rax            # imm = 0x560
    3d10:      	jmp	0x3d18 <generic_rawtp_process_event+0x3b48>
    3d12:      	addq	$0x550, %rax            # imm = 0x550
    3d18:      	lock
    3d19:      	incq	(%rax)
    3d1c:      	testl	%ebp, %ebp
    3d1e:      	js	0x3d41 <generic_rawtp_process_event+0x3b71>
    3d20:      	movq	0x40(%rsp), %rax
    3d25:      	movq	$0x0, 0x4(%rax)
    3d2d:      	movq	0x10(%rsp), %rdx
    3d32:      	movl	%edx, %ecx
    3d34:      	subl	%ebp, %ecx
    3d36:      	xorl	%eax, %eax
    3d38:      	cmpq	$-0x1, %rdx
    3d3c:      	cmovnel	%ecx, %eax
    3d3f:      	jmp	0x3d54 <generic_rawtp_process_event+0x3b84>
    3d41:      	movq	0x40(%rsp), %rax
    3d46:      	movl	%ebp, 0x4(%rax)
    3d49:      	movl	$0x0, 0x8(%rax)
    3d50:      	xorl	%eax, %eax
    3d52:      	xorl	%ebp, %ebp
    3d54:      	movq	0x40(%rsp), %rcx
    3d59:      	movl	%eax, 0xc(%rcx)
    3d5c:      	movl	%ebp, 0x10(%rcx)
    3d5f:      	movl	$0x24, %r13d
    3d65:      	jmp	0x1761 <generic_rawtp_process_event+0x1591>
    3d6a:      	movzbl	0x7(%rbx), %eax
    3d6e:      	leal	0x8(,%rax,4), %eax
    3d75:      	movw	%ax, 0x2(%rbx)
    3d79:      	jmp	0x3d7f <generic_rawtp_process_event+0x3baf>
    3d7b:      	movzwl	0x2(%rbx), %eax
    3d7f:      	addw	(%rbx), %ax
    3d82:      	movw	%ax, (%rbx)
    3d85:      	movzbl	0x6(%rbx), %r15d
    3d8a:      	cmpq	$0x3c, %r15
    3d8e:      	ja	0x426d <generic_rawtp_process_event+0x409d>
    3d94:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3d9e:      	btq	%r15, %rcx
    3da2:      	jae	0x426d <generic_rawtp_process_event+0x409d>
    3da8:      	movb	%r15b, 0x5(%rbx)
    3dac:      	movzwl	%ax, %ecx
    3daf:      	addq	%r14, %rcx
    3db2:      	movl	$0x2, %edx
    3db7:      	movl	$0x4, %eax
    3dbc:      	movq	0x10(%rsp), %rdi
    3dc1:      	movzwl	(%rbx), %edx
    3dc4:      	addq	%r14, %rdx
    3dc7:      	movl	$0x2, %esi
    3dcc:      	callq	*%rax
    3dce:      	testq	%rax, %rax
    3dd1:      	js	0x40a9 <generic_rawtp_process_event+0x3ed9>
    3dd7:      	movzbl	0x5(%rbx), %eax
    3ddb:      	cmpl	$0x32, %eax
    3dde:      	jg	0x3e01 <generic_rawtp_process_event+0x3c31>
    3de0:      	testl	%eax, %eax
    3de2:      	je	0x3e29 <generic_rawtp_process_event+0x3c59>
    3de4:      	cmpl	$0x2b, %eax
    3de7:      	je	0x3e29 <generic_rawtp_process_event+0x3c59>
    3de9:      	cmpl	$0x2c, %eax
    3dec:      	jne	0x3eda <generic_rawtp_process_event+0x3d0a>
    3df2:      	movw	$0x8, 0x2(%rbx)
    3df8:      	movw	$0x8, %ax
    3dfc:      	jmp	0x3ede <generic_rawtp_process_event+0x3d0e>
    3e01:      	cmpl	$0x33, %eax
    3e04:      	je	0x3ec9 <generic_rawtp_process_event+0x3cf9>
    3e0a:      	cmpl	$0x3c, %eax
    3e0d:      	je	0x3e29 <generic_rawtp_process_event+0x3c59>
    3e0f:      	cmpl	$0xff, %eax
    3e14:      	jne	0x3eda <generic_rawtp_process_event+0x3d0a>
    3e1a:      	movw	$0x28, 0x2(%rbx)
    3e20:      	movw	$0x28, %ax
    3e24:      	jmp	0x3ede <generic_rawtp_process_event+0x3d0e>
    3e29:      	movzbl	0x7(%rbx), %eax
    3e2d:      	leal	0x8(,%rax,8), %eax
    3e34:      	movw	%ax, 0x2(%rbx)
    3e38:      	jmp	0x3ede <generic_rawtp_process_event+0x3d0e>
    3e3d:      	addq	$0x568, %rax            # imm = 0x568
    3e43:      	jmp	0x3e63 <generic_rawtp_process_event+0x3c93>
    3e45:      	addq	$0x560, %rax            # imm = 0x560
    3e4b:      	jmp	0x3e63 <generic_rawtp_process_event+0x3c93>
    3e4d:      	addq	$0x570, %rax            # imm = 0x570
    3e53:      	jmp	0x3e63 <generic_rawtp_process_event+0x3c93>
    3e55:      	addq	$0x550, %rax            # imm = 0x550
    3e5b:      	jmp	0x3e63 <generic_rawtp_process_event+0x3c93>
    3e5d:      	addq	$0x540, %rax            # imm = 0x540
    3e63:      	lock
    3e64:      	incq	(%rax)
    3e67:      	testl	%r13d, %r13d
    3e6a:      	js	0x3e8d <generic_rawtp_process_event+0x3cbd>
    3e6c:      	movq	0xa8(%rsp), %rax
    3e74:      	movq	$0x0, 0x4(%rax)
    3e7c:      	movl	%r14d, %ecx
    3e7f:      	subl	%r13d, %ecx
    3e82:      	xorl	%eax, %eax
    3e84:      	cmpq	$-0x1, %r14
    3e88:      	cmovnel	%ecx, %eax
    3e8b:      	jmp	0x3ea5 <generic_rawtp_process_event+0x3cd5>
    3e8d:      	movq	0xa8(%rsp), %rax
    3e95:      	movl	%r13d, 0x4(%rax)
    3e99:      	movl	$0x0, 0x8(%rax)
    3ea0:      	xorl	%eax, %eax
    3ea2:      	xorl	%r13d, %r13d
    3ea5:      	movq	0xa8(%rsp), %rcx
    3ead:      	movl	%eax, 0xc(%rcx)
    3eb0:      	movl	%r13d, 0x10(%rcx)
    3eb4:      	movl	$0x24, %r13d
    3eba:      	movq	0x18(%rsp), %rbx
    3ebf:      	movq	0x28(%rsp), %r14
    3ec4:      	jmp	0x1761 <generic_rawtp_process_event+0x1591>
    3ec9:      	movzbl	0x7(%rbx), %eax
    3ecd:      	leal	0x8(,%rax,4), %eax
    3ed4:      	movw	%ax, 0x2(%rbx)
    3ed8:      	jmp	0x3ede <generic_rawtp_process_event+0x3d0e>
    3eda:      	movzwl	0x2(%rbx), %eax
    3ede:      	addw	(%rbx), %ax
    3ee1:      	movw	%ax, (%rbx)
    3ee4:      	movzbl	0x6(%rbx), %r15d
    3ee9:      	cmpq	$0x3c, %r15
    3eed:      	ja	0x426d <generic_rawtp_process_event+0x409d>
    3ef3:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3efd:      	btq	%r15, %rcx
    3f01:      	jae	0x426d <generic_rawtp_process_event+0x409d>
    3f07:      	movb	%r15b, 0x5(%rbx)
    3f0b:      	movzwl	%ax, %ecx
    3f0e:      	addq	%r14, %rcx
    3f11:      	movl	$0x2, %edx
    3f16:      	movl	$0x4, %eax
    3f1b:      	movq	0x10(%rsp), %rdi
    3f20:      	movzwl	(%rbx), %edx
    3f23:      	addq	%r14, %rdx
    3f26:      	movl	$0x2, %esi
    3f2b:      	callq	*%rax
    3f2d:      	testq	%rax, %rax
    3f30:      	js	0x40a9 <generic_rawtp_process_event+0x3ed9>
    3f36:      	movzbl	0x5(%rbx), %eax
    3f3a:      	cmpl	$0x32, %eax
    3f3d:      	jg	0x3f59 <generic_rawtp_process_event+0x3d89>
    3f3f:      	testl	%eax, %eax
    3f41:      	je	0x3f76 <generic_rawtp_process_event+0x3da6>
    3f43:      	cmpl	$0x2b, %eax
    3f46:      	je	0x3f76 <generic_rawtp_process_event+0x3da6>
    3f48:      	cmpl	$0x2c, %eax
    3f4b:      	jne	0x3f98 <generic_rawtp_process_event+0x3dc8>
    3f4d:      	movw	$0x8, 0x2(%rbx)
    3f53:      	movw	$0x8, %ax
    3f57:      	jmp	0x3f9c <generic_rawtp_process_event+0x3dcc>
    3f59:      	cmpl	$0x33, %eax
    3f5c:      	je	0x3f87 <generic_rawtp_process_event+0x3db7>
    3f5e:      	cmpl	$0x3c, %eax
    3f61:      	je	0x3f76 <generic_rawtp_process_event+0x3da6>
    3f63:      	cmpl	$0xff, %eax
    3f68:      	jne	0x3f98 <generic_rawtp_process_event+0x3dc8>
    3f6a:      	movw	$0x28, 0x2(%rbx)
    3f70:      	movw	$0x28, %ax
    3f74:      	jmp	0x3f9c <generic_rawtp_process_event+0x3dcc>
    3f76:      	movzbl	0x7(%rbx), %eax
    3f7a:      	leal	0x8(,%rax,8), %eax
    3f81:      	movw	%ax, 0x2(%rbx)
    3f85:      	jmp	0x3f9c <generic_rawtp_process_event+0x3dcc>
    3f87:      	movzbl	0x7(%rbx), %eax
    3f8b:      	leal	0x8(,%rax,4), %eax
    3f92:      	movw	%ax, 0x2(%rbx)
    3f96:      	jmp	0x3f9c <generic_rawtp_process_event+0x3dcc>
    3f98:      	movzwl	0x2(%rbx), %eax
    3f9c:      	addw	(%rbx), %ax
    3f9f:      	movw	%ax, (%rbx)
    3fa2:      	movzbl	0x6(%rbx), %r15d
    3fa7:      	cmpq	$0x3c, %r15
    3fab:      	ja	0x426d <generic_rawtp_process_event+0x409d>
    3fb1:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3fbb:      	btq	%r15, %rcx
    3fbf:      	jae	0x426d <generic_rawtp_process_event+0x409d>
    3fc5:      	movb	%r15b, 0x5(%rbx)
    3fc9:      	movzwl	%ax, %ecx
    3fcc:      	addq	%r14, %rcx
    3fcf:      	movl	$0x2, %edx
    3fd4:      	movl	$0x4, %eax
    3fd9:      	movq	0x10(%rsp), %rdi
    3fde:      	movzwl	(%rbx), %edx
    3fe1:      	addq	%r14, %rdx
    3fe4:      	movl	$0x2, %esi
    3fe9:      	callq	*%rax
    3feb:      	testq	%rax, %rax
    3fee:      	js	0x40a9 <generic_rawtp_process_event+0x3ed9>
    3ff4:      	movzbl	0x5(%rbx), %eax
    3ff8:      	cmpl	$0x32, %eax
    3ffb:      	jg	0x4017 <generic_rawtp_process_event+0x3e47>
    3ffd:      	testl	%eax, %eax
    3fff:      	je	0x4034 <generic_rawtp_process_event+0x3e64>
    4001:      	cmpl	$0x2b, %eax
    4004:      	je	0x4034 <generic_rawtp_process_event+0x3e64>
    4006:      	cmpl	$0x2c, %eax
    4009:      	jne	0x4056 <generic_rawtp_process_event+0x3e86>
    400b:      	movw	$0x8, 0x2(%rbx)
    4011:      	movw	$0x8, %ax
    4015:      	jmp	0x405a <generic_rawtp_process_event+0x3e8a>
    4017:      	cmpl	$0x33, %eax
    401a:      	je	0x4045 <generic_rawtp_process_event+0x3e75>
    401c:      	cmpl	$0x3c, %eax
    401f:      	je	0x4034 <generic_rawtp_process_event+0x3e64>
    4021:      	cmpl	$0xff, %eax
    4026:      	jne	0x4056 <generic_rawtp_process_event+0x3e86>
    4028:      	movw	$0x28, 0x2(%rbx)
    402e:      	movw	$0x28, %ax
    4032:      	jmp	0x405a <generic_rawtp_process_event+0x3e8a>
    4034:      	movzbl	0x7(%rbx), %eax
    4038:      	leal	0x8(,%rax,8), %eax
    403f:      	movw	%ax, 0x2(%rbx)
    4043:      	jmp	0x405a <generic_rawtp_process_event+0x3e8a>
    4045:      	movzbl	0x7(%rbx), %eax
    4049:      	leal	0x8(,%rax,4), %eax
    4050:      	movw	%ax, 0x2(%rbx)
    4054:      	jmp	0x405a <generic_rawtp_process_event+0x3e8a>
    4056:      	movzwl	0x2(%rbx), %eax
    405a:      	addw	(%rbx), %ax
    405d:      	movw	%ax, (%rbx)
    4060:      	movzbl	0x6(%rbx), %r15d
    4065:      	cmpq	$0x3c, %r15
    4069:      	ja	0x426d <generic_rawtp_process_event+0x409d>
    406f:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    4079:      	btq	%r15, %rcx
    407d:      	jae	0x426d <generic_rawtp_process_event+0x409d>
    4083:      	movb	%r15b, 0x5(%rbx)
    4087:      	movzwl	%ax, %ecx
    408a:      	addq	%r14, %rcx
    408d:      	movl	$0x2, %edx
    4092:      	movl	$0x4, %eax
    4097:      	movq	0x10(%rsp), %rdi
    409c:      	movzwl	(%rbx), %edx
    409f:      	addq	%r14, %rdx
    40a2:      	movl	$0x2, %esi
    40a7:      	callq	*%rax
    40a9:      	xorl	%r15d, %r15d
    40ac:      	movb	%r15b, 0xd0(%rsp)
    40b4:      	movzbl	%r15b, %eax
    40b8:      	movq	%rbp, %rbx
    40bb:      	movw	%ax, 0x24(%rbp)
    40bf:      	movw	$0xa, 0x26(%rbp)
    40c5:      	leaq	0x8(%r12), %rdx
    40ca:      	movl	$0x10, %ecx
    40cf:      	movl	$0x4, %eax
    40d4:      	movq	%rbp, %rdi
    40d7:      	movl	$0x10, %esi
    40dc:      	callq	*%rax
    40de:      	leaq	0x10(%rbp), %rdi
    40e2:      	addq	$0x18, %r12
    40e6:      	movl	$0x10, %ecx
    40eb:      	movl	$0x4, %eax
    40f0:      	movl	$0x10, %esi
    40f5:      	movq	%r12, %rdx
    40f8:      	callq	*%rax
    40fa:      	cmpb	$0x11, %r15b
    40fe:      	je	0x414f <generic_rawtp_process_event+0x3f7f>
    4100:      	movzbl	%r15b, %eax
    4104:      	cmpl	$0x6, %eax
    4107:      	jne	0x4198 <generic_rawtp_process_event+0x3fc8>
    410d:      	movq	0x68(%rsp), %r15
    4112:      	movzwl	0xc0(%rsp), %r12d
    411b:      	leaq	(%r15,%r12), %rdx
    411f:      	movq	%rbp, %rbx
    4122:      	leaq	0x20(%rbp), %rdi
    4126:      	movl	$0x2, %ecx
    412b:      	movl	$0x4, %eax
    4130:      	movl	$0x2, %esi
    4135:      	callq	*%rax
    4137:      	leaq	0x22(%rbp), %rdi
    413b:      	leaq	(%r15,%r12), %rdx
    413f:      	addq	$0x2, %rdx
    4143:      	movl	$0x2, %ecx
    4148:      	movl	$0x4, %eax
    414d:      	jmp	0x418f <generic_rawtp_process_event+0x3fbf>
    414f:      	movq	0x68(%rsp), %r15
    4154:      	movzwl	0xc0(%rsp), %r12d
    415d:      	leaq	(%r15,%r12), %rdx
    4161:      	movq	%rbp, %rbx
    4164:      	leaq	0x20(%rbp), %rdi
    4168:      	movl	$0x2, %ecx
    416d:      	movl	$0x4, %eax
    4172:      	movl	$0x2, %esi
    4177:      	callq	*%rax
    4179:      	leaq	0x22(%rbp), %rdi
    417d:      	leaq	(%r15,%r12), %rdx
    4181:      	addq	$0x2, %rdx
    4185:      	movl	$0x2, %ecx
    418a:      	movl	$0x4, %eax
    418f:      	movl	$0x2, %esi
    4194:      	callq	*%rax
    4196:      	jmp	0x419f <generic_rawtp_process_event+0x3fcf>
    4198:      	movl	$0x0, 0x20(%rbp)
    419f:      	movzwl	0x20(%rbp), %eax
    41a3:      	movzwl	0x22(%rbp), %ecx
    41a7:      	movbew	%ax, 0x20(%rbp)
    41ad:      	movbew	%cx, 0x22(%rbp)
    41b3:      	addq	$0xe0, %r13
    41ba:      	leaq	0x58(%rsp), %rdi
    41bf:      	movl	$0x8, %ecx
    41c4:      	movl	$0x4, %eax
    41c9:      	movl	$0x4, %r15d
    41cf:      	movl	$0x8, %esi
    41d4:      	movq	%r13, %rdx
    41d7:      	callq	*%rax
    41d9:      	movq	0x58(%rsp), %rcx
    41de:      	testq	%rcx, %rcx
    41e1:      	je	0x4249 <generic_rawtp_process_event+0x4079>
    41e3:      	addq	$0x5, %rcx
    41e7:      	leaq	0xb0(%rsp), %rdi
    41ef:      	movl	$0x8, %edx
    41f4:      	movl	$0x4, %eax
    41f9:      	movq	0x58(%rsp), %rdx
    41fe:      	addq	$0x5, %rdx
    4202:      	movl	$0x8, %esi
    4207:      	callq	*%rax
    4209:      	movq	0x58(%rsp), %r12
    420e:      	movq	0xb0(%rsp), %r13
    4216:      	leaq	0x38(%rbp), %rdi
    421a:      	leaq	(%r12,%r13,8), %rdx
    421e:      	addq	$0x44, %rdx
    4222:      	movl	$0x4, %eax
    4227:      	movl	$0x4, %esi
    422c:      	callq	*%rax
    422e:      	addq	$0x3c, %rbp
    4232:      	leaq	(%r12,%r13,8), %rdx
    4236:      	addq	$0x45, %rdx
    423a:      	movl	$0x4, %eax
    423f:      	movq	%rbp, %rdi
    4242:      	movl	$0x4, %esi
    4247:      	callq	*%rax
    4249:      	movl	$0x40, %r13d
    424f:      	movq	0x38(%rsp), %rax
    4254:      	movq	0x20(%rsp), %rcx
    4259:      	movl	$0x4, %esi
    425e:      	movq	0x18(%rsp), %rbx
    4263:      	movq	0x28(%rsp), %r14
    4268:      	jmp	0x1770 <generic_rawtp_process_event+0x15a0>
    426d:      	movw	%ax, 0xc0(%rsp)
    4275:      	jmp	0x40ac <generic_rawtp_process_event+0x3edc>
    427a:      	nopw	(%rax,%rax)

0000000000004280 <generic_rawtp_process_filter>:
    4280:      	pushq	%rbp
    4281:      	pushq	%r15
    4283:      	pushq	%r14
    4285:      	pushq	%r13
    4287:      	pushq	%r12
    4289:      	pushq	%rbx
    428a:      	subq	$0xe8, %rsp
    4291:      	movq	%rdi, %rbx
    4294:      	movl	$0x0, 0xc8(%rsp)
    429f:      	movq	(%rip), %rdi            # 0x42a6 <generic_rawtp_process_filter+0x26>
    42a6:      	leaq	0xc8(%rsp), %rsi
    42ae:      	movl	$0x1, %eax
    42b3:      	callq	*%rax
    42b5:      	testq	%rax, %rax
    42b8:      	je	0x68a3 <generic_rawtp_process_filter+0x2623>
    42be:      	movq	%rax, %r14
    42c1:      	movl	$0x23, %eax
    42c6:      	callq	*%rax
    42c8:      	movq	%rax, %rcx
    42cb:      	movq	%rax, 0x60(%rsp)
    42d0:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    42d7:      	leaq	0x10(%rsp), %rdi
    42dc:      	movl	$0x4, %edx
    42e1:      	movl	$0x71, %eax
    42e6:      	movl	$0xaf4, %edx            # imm = 0xAF4
    42eb:      	addq	0x60(%rsp), %rdx
    42f0:      	movl	$0x4, %esi
    42f5:      	callq	*%rax
    42f7:      	movl	0x10(%rsp), %eax
    42fb:      	movl	%eax, 0x40(%rsp)
    42ff:      	movq	(%rip), %rdi            # 0x4306 <generic_rawtp_process_filter+0x86>
    4306:      	leaq	0x40(%rsp), %rsi
    430b:      	movl	$0x1, %eax
    4310:      	callq	*%rax
    4312:      	testq	%rax, %rax
    4315:      	movq	%r14, 0x50(%rsp)
    431a:      	je	0x432a <generic_rawtp_process_filter+0xaa>
    431c:      	movq	%rax, %r15
    431f:      	cmpq	$0x0, 0x8(%rax)
    4324:      	jne	0x52af <generic_rawtp_process_filter+0x102f>
    432a:      	movl	$0xb00, %edx            # imm = 0xB00
    432f:      	movq	0x60(%rsp), %rcx
    4334:      	addq	%rdx, %rcx
    4337:      	leaq	0x60(%rsp), %rdi
    433c:      	movl	$0x8, %esi
    4341:      	movl	$0x71, %eax
    4346:      	addq	0x60(%rsp), %rdx
    434b:      	movl	$0x8, %esi
    4350:      	callq	*%rax
    4352:      	movq	0x60(%rsp), %rcx
    4357:      	testq	%rcx, %rcx
    435a:      	je	0x44ef <generic_rawtp_process_filter+0x26f>
    4360:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    4367:      	leaq	0x10(%rsp), %rdi
    436c:      	movl	$0x4, %edx
    4371:      	movl	$0x71, %eax
    4376:      	movl	$0xaf4, %edx            # imm = 0xAF4
    437b:      	addq	0x60(%rsp), %rdx
    4380:      	movl	$0x4, %esi
    4385:      	callq	*%rax
    4387:      	movl	0x10(%rsp), %eax
    438b:      	movl	%eax, 0x40(%rsp)
    438f:      	movq	(%rip), %rdi            # 0x4396 <generic_rawtp_process_filter+0x116>
    4396:      	leaq	0x40(%rsp), %rsi
    439b:      	movl	$0x1, %eax
    43a0:      	callq	*%rax
    43a2:      	testq	%rax, %rax
    43a5:      	je	0x43b5 <generic_rawtp_process_filter+0x135>
    43a7:      	movq	%rax, %r15
    43aa:      	cmpq	$0x0, 0x8(%rax)
    43af:      	jne	0x52af <generic_rawtp_process_filter+0x102f>
    43b5:      	movl	$0xb00, %edx            # imm = 0xB00
    43ba:      	movq	0x60(%rsp), %rcx
    43bf:      	addq	%rdx, %rcx
    43c2:      	leaq	0x60(%rsp), %rdi
    43c7:      	movl	$0x8, %esi
    43cc:      	movl	$0x71, %eax
    43d1:      	addq	0x60(%rsp), %rdx
    43d6:      	movl	$0x8, %esi
    43db:      	callq	*%rax
    43dd:      	movq	0x60(%rsp), %rcx
    43e2:      	testq	%rcx, %rcx
    43e5:      	je	0x44ef <generic_rawtp_process_filter+0x26f>
    43eb:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    43f2:      	leaq	0x10(%rsp), %rdi
    43f7:      	movl	$0x4, %edx
    43fc:      	movl	$0x71, %eax
    4401:      	movl	$0xaf4, %edx            # imm = 0xAF4
    4406:      	addq	0x60(%rsp), %rdx
    440b:      	movl	$0x4, %esi
    4410:      	callq	*%rax
    4412:      	movl	0x10(%rsp), %eax
    4416:      	movl	%eax, 0x40(%rsp)
    441a:      	movq	(%rip), %rdi            # 0x4421 <generic_rawtp_process_filter+0x1a1>
    4421:      	leaq	0x40(%rsp), %rsi
    4426:      	movl	$0x1, %eax
    442b:      	callq	*%rax
    442d:      	testq	%rax, %rax
    4430:      	je	0x4440 <generic_rawtp_process_filter+0x1c0>
    4432:      	movq	%rax, %r15
    4435:      	cmpq	$0x0, 0x8(%rax)
    443a:      	jne	0x52af <generic_rawtp_process_filter+0x102f>
    4440:      	movl	$0xb00, %edx            # imm = 0xB00
    4445:      	movq	0x60(%rsp), %rcx
    444a:      	addq	%rdx, %rcx
    444d:      	leaq	0x60(%rsp), %rdi
    4452:      	movl	$0x8, %esi
    4457:      	movl	$0x71, %eax
    445c:      	addq	0x60(%rsp), %rdx
    4461:      	movl	$0x8, %esi
    4466:      	callq	*%rax
    4468:      	movq	0x60(%rsp), %rcx
    446d:      	testq	%rcx, %rcx
    4470:      	je	0x44ef <generic_rawtp_process_filter+0x26f>
    4472:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    4479:      	leaq	0x10(%rsp), %rdi
    447e:      	movl	$0x4, %edx
    4483:      	movl	$0x71, %eax
    4488:      	movl	$0xaf4, %edx            # imm = 0xAF4
    448d:      	addq	0x60(%rsp), %rdx
    4492:      	movl	$0x4, %esi
    4497:      	callq	*%rax
    4499:      	movl	0x10(%rsp), %eax
    449d:      	movl	%eax, 0x40(%rsp)
    44a1:      	movq	(%rip), %rdi            # 0x44a8 <generic_rawtp_process_filter+0x228>
    44a8:      	leaq	0x40(%rsp), %rsi
    44ad:      	movl	$0x1, %eax
    44b2:      	callq	*%rax
    44b4:      	testq	%rax, %rax
    44b7:      	je	0x44c7 <generic_rawtp_process_filter+0x247>
    44b9:      	movq	%rax, %r15
    44bc:      	cmpq	$0x0, 0x8(%rax)
    44c1:      	jne	0x52af <generic_rawtp_process_filter+0x102f>
    44c7:      	movl	$0xb00, %edx            # imm = 0xB00
    44cc:      	movq	0x60(%rsp), %rcx
    44d1:      	addq	%rdx, %rcx
    44d4:      	leaq	0x60(%rsp), %rdi
    44d9:      	movl	$0x8, %esi
    44de:      	movl	$0x71, %eax
    44e3:      	addq	0x60(%rsp), %rdx
    44e8:      	movl	$0x8, %esi
    44ed:      	callq	*%rax
    44ef:      	movq	%rbx, 0xb8(%rsp)
    44f7:      	movl	$0x23, %eax
    44fc:      	callq	*%rax
    44fe:      	movq	%rax, %r13
    4501:      	leaq	0xaf4(%rax), %rdx
    4508:      	leaq	0x60(%rsp), %rdi
    450d:      	movl	$0x4, %ecx
    4512:      	movl	$0x4, %eax
    4517:      	movl	$0x4, %ebp
    451c:      	movl	$0x4, %esi
    4521:      	callq	*%rax
    4523:      	movl	0x60(%rsp), %eax
    4527:      	movl	%eax, 0x5f10(%r14)
    452e:      	movl	$0x7d, %eax
    4533:      	callq	*%rax
    4535:      	movq	%rax, 0x5f18(%r14)
    453c:      	movl	$0x0, 0x5f20(%r14)
    4547:      	movq	$0x0, 0x5f28(%r14)
    4552:      	movl	$0x0, 0x5f30(%r14)
    455d:      	leaq	0x60(%r13), %rdx
    4561:      	leaq	0x40(%rsp), %rdi
    4566:      	movl	$0x8, %ecx
    456b:      	movl	$0x71, %eax
    4570:      	movl	$0x8, %esi
    4575:      	callq	*%rax
    4577:      	movq	0x40(%rsp), %rcx
    457c:      	xorl	%ebx, %ebx
    457e:      	testq	%rcx, %rcx
    4581:      	je	0x45f0 <generic_rawtp_process_filter+0x370>
    4583:      	addq	$0x4, %rcx
    4587:      	leaq	0x10(%rsp), %rdi
    458c:      	movl	$0x4, %edx
    4591:      	movl	$0x71, %eax
    4596:      	movq	0x40(%rsp), %rdx
    459b:      	addq	$0x4, %rdx
    459f:      	movl	$0x4, %esi
    45a4:      	callq	*%rax
    45a6:      	movl	0x10(%rsp), %eax
    45aa:      	testl	%eax, %eax
    45ac:      	je	0x45f0 <generic_rawtp_process_filter+0x370>
    45ae:      	movq	0x40(%rsp), %rcx
    45b3:      	shll	$0x4, %eax
    45b6:      	addq	%rax, %rcx
    45b9:      	addq	$0x80, %rcx
    45c0:      	leaq	0x60(%rsp), %rdi
    45c5:      	movl	$0x10, %edx
    45ca:      	movl	$0x71, %eax
    45cf:      	movq	0x40(%rsp), %rcx
    45d4:      	movl	0x10(%rsp), %edx
    45d8:      	shll	$0x4, %edx
    45db:      	addq	%rcx, %rdx
    45de:      	addq	$0x80, %rdx
    45e5:      	movl	$0x10, %esi
    45ea:      	callq	*%rax
    45ec:      	movl	0x60(%rsp), %ebx
    45f0:      	movl	%ebx, 0x5f34(%r14)
    45f7:      	leaq	0xd00(%r13), %r15
    45fe:      	leaq	0x60(%rsp), %rdi
    4603:      	movl	$0x8, %ecx
    4608:      	movl	$0x4, %eax
    460d:      	leaq	0x5f60(%r14), %rbx
    4614:      	movl	$0x8, %esi
    4619:      	movq	%r15, %rdx
    461c:      	callq	*%rax
    461e:      	movq	0x60(%rsp), %r12
    4623:      	leaq	0x5f68(%r14), %rdi
    462a:      	leaq	0x40(%r12), %rdx
    462f:      	movl	$0x8, %ecx
    4634:      	movl	$0x4, %eax
    4639:      	movl	$0x8, %esi
    463e:      	callq	*%rax
    4640:      	leaq	0x5f70(%r14), %rdi
    4647:      	leaq	0x30(%r12), %rdx
    464c:      	movl	$0x8, %ecx
    4651:      	movl	$0x4, %eax
    4656:      	movl	$0x8, %esi
    465b:      	callq	*%rax
    465d:      	addq	$0x38, %r12
    4661:      	movl	$0x8, %ecx
    4666:      	movl	$0x4, %eax
    466b:      	movq	%rbx, %rdi
    466e:      	movl	$0x8, %esi
    4673:      	movq	%r12, %rdx
    4676:      	callq	*%rax
    4678:      	leaq	0x5f38(%r14), %rbx
    467f:      	leaq	0xd70(%r13), %rdx
    4686:      	leaq	0x10(%rsp), %rdi
    468b:      	movl	$0x8, %ecx
    4690:      	movl	$0x4, %eax
    4695:      	movl	$0x8, %esi
    469a:      	callq	*%rax
    469c:      	movq	0x10(%rsp), %rcx
    46a1:      	leaq	0x60(%rsp), %rdi
    46a6:      	movl	$0x48, %edx
    46ab:      	movl	$0x4, %eax
    46b0:      	movq	0x10(%rsp), %rdx
    46b5:      	movl	$0x48, %esi
    46ba:      	callq	*%rax
    46bc:      	movl	$0x218, %edx            # imm = 0x218
    46c1:      	movq	0x68(%rsp), %rcx
    46c6:      	addq	%rdx, %rcx
    46c9:      	movl	$0x4, %eax
    46ce:      	addq	0x68(%rsp), %rdx
    46d3:      	movq	%rbx, %rdi
    46d6:      	movl	$0x4, %esi
    46db:      	callq	*%rax
    46dd:      	leaq	0x5f3c(%r14), %rdi
    46e4:      	movl	$0x4d8, %edx            # imm = 0x4D8
    46e9:      	movq	0x70(%rsp), %rcx
    46ee:      	addq	%rdx, %rcx
    46f1:      	movl	$0x4, %eax
    46f6:      	addq	0x70(%rsp), %rdx
    46fb:      	movl	$0x4, %esi
    4700:      	callq	*%rax
    4702:      	leaq	0x5f40(%r14), %rdi
    4709:      	movq	0x78(%rsp), %rcx
    470e:      	addq	$0x58, %rcx
    4712:      	movl	$0x4, %eax
    4717:      	movq	0x78(%rsp), %rdx
    471c:      	addq	$0x58, %rdx
    4720:      	movl	$0x4, %esi
    4725:      	callq	*%rax
    4727:      	movq	$0x0, 0x58(%rsp)
    4730:      	leaq	0xb58(%r13), %rdx
    4737:      	leaq	0x58(%rsp), %rdi
    473c:      	movl	$0x8, %ecx
    4741:      	movl	$0x4, %eax
    4746:      	movl	$0x8, %esi
    474b:      	callq	*%rax
    474d:      	movq	0x58(%rsp), %rcx
    4752:      	testq	%rcx, %rcx
    4755:      	je	0x4804 <generic_rawtp_process_filter+0x584>
    475b:      	movl	$0x0, 0xa8(%rsp)
    4766:      	addq	$0x4, %rcx
    476a:      	leaq	0xa8(%rsp), %rdi
    4772:      	movl	$0x4, %edx
    4777:      	movl	$0x4, %eax
    477c:      	movq	0x58(%rsp), %rdx
    4781:      	addq	$0x4, %rdx
    4785:      	movl	$0x4, %esi
    478a:      	callq	*%rax
    478c:      	movq	0x58(%rsp), %rax
    4791:      	movslq	0xa8(%rsp), %rcx
    4799:      	shlq	$0x4, %rcx
    479d:      	addq	%rax, %rcx
    47a0:      	addq	$0x80, %rcx
    47a7:      	leaq	0x40(%rsp), %rdi
    47ac:      	movl	$0x10, %edx
    47b1:      	movl	$0x4, %eax
    47b6:      	movq	0x58(%rsp), %rcx
    47bb:      	movslq	0xa8(%rsp), %rdx
    47c3:      	shlq	$0x4, %rdx
    47c7:      	addq	%rcx, %rdx
    47ca:      	addq	$0x80, %rdx
    47d1:      	movl	$0x10, %esi
    47d6:      	callq	*%rax
    47d8:      	leaq	0x5f44(%r14), %rdi
    47df:      	movl	$0x158, %edx            # imm = 0x158
    47e4:      	movq	0x48(%rsp), %rcx
    47e9:      	addq	%rdx, %rcx
    47ec:      	movl	$0x4, %esi
    47f1:      	movl	$0x4, %eax
    47f6:      	addq	0x48(%rsp), %rdx
    47fb:      	movl	$0x4, %esi
    4800:      	callq	*%rax
    4802:      	jmp	0x480f <generic_rawtp_process_filter+0x58f>
    4804:      	movl	$0x0, 0x5f44(%r14)
    480f:      	leaq	0x5f48(%r14), %rdi
    4816:      	movl	$0x158, %ebx            # imm = 0x158
    481b:      	movq	0x80(%rsp), %rcx
    4823:      	addq	%rbx, %rcx
    4826:      	movl	$0x4, %edx
    482b:      	movl	$0x4, %eax
    4830:      	movq	0x80(%rsp), %rdx
    4838:      	addq	%rbx, %rdx
    483b:      	movl	$0x4, %esi
    4840:      	callq	*%rax
    4842:      	leaq	0x5f4c(%r14), %rdi
    4849:      	movl	$0x118, %edx            # imm = 0x118
    484e:      	movq	0x88(%rsp), %rcx
    4856:      	addq	%rdx, %rcx
    4859:      	movl	$0x4, %esi
    485e:      	movl	$0x4, %eax
    4863:      	addq	0x88(%rsp), %rdx
    486b:      	movl	$0x4, %esi
    4870:      	callq	*%rax
    4872:      	leaq	0x5f50(%r14), %rdi
    4879:      	movl	$0x98, %r12d
    487f:      	movq	0x90(%rsp), %rcx
    4887:      	addq	%r12, %rcx
    488a:      	movl	$0x4, %edx
    488f:      	movl	$0x4, %eax
    4894:      	movq	0x90(%rsp), %rdx
    489c:      	addq	%r12, %rdx
    489f:      	movl	$0x4, %esi
    48a4:      	callq	*%rax
    48a6:      	leaq	0x5f54(%r14), %rdi
    48ad:      	movq	0x98(%rsp), %rcx
    48b5:      	addq	%r12, %rcx
    48b8:      	movl	$0x4, %edx
    48bd:      	movl	$0x4, %eax
    48c2:      	addq	0x98(%rsp), %r12
    48ca:      	movl	$0x4, %esi
    48cf:      	movq	%r12, %rdx
    48d2:      	callq	*%rax
    48d4:      	leaq	0x5f58(%r14), %rdi
    48db:      	movq	0xa0(%rsp), %rcx
    48e3:      	addq	$0x58, %rcx
    48e7:      	movl	$0x4, %edx
    48ec:      	movl	$0x4, %eax
    48f1:      	movq	0xa0(%rsp), %rdx
    48f9:      	addq	$0x58, %rdx
    48fd:      	movl	$0x4, %esi
    4902:      	callq	*%rax
    4904:      	movq	$0x0, 0x40(%rsp)
    490d:      	movq	$0x0, 0x58(%rsp)
    4916:      	leaq	0x40(%rsp), %rdi
    491b:      	movl	$0x8, %ecx
    4920:      	movl	$0x4, %eax
    4925:      	movl	$0x8, %esi
    492a:      	movq	%r15, %rdx
    492d:      	callq	*%rax
    492f:      	movl	$0x90, %edx
    4934:      	movq	0x40(%rsp), %rcx
    4939:      	addq	%rdx, %rcx
    493c:      	leaq	0x58(%rsp), %rdi
    4941:      	movl	$0x8, %esi
    4946:      	movl	$0x4, %eax
    494b:      	addq	0x40(%rsp), %rdx
    4950:      	movl	$0x8, %esi
    4955:      	callq	*%rax
    4957:      	leaq	0x5f5c(%r14), %rdi
    495e:      	movq	0x58(%rsp), %rcx
    4963:      	addq	%rbx, %rcx
    4966:      	movl	$0x4, %edx
    496b:      	movl	$0x4, %eax
    4970:      	addq	0x58(%rsp), %rbx
    4975:      	movl	$0x4, %esi
    497a:      	movq	%rbx, %rdx
    497d:      	callq	*%rax
    497f:      	cmpl	$0x1, 0x5f34(%r14)
    4987:      	jne	0x4991 <generic_rawtp_process_filter+0x711>
    4989:      	orb	$0x2, 0x5f33(%r14)
    4991:      	leaq	0x5f78(%r14), %rdi
    4998:      	movl	$0x308, %edx            # imm = 0x308
    499d:      	movq	%rdi, 0x8(%rsp)
    49a2:      	xorl	%esi, %esi
    49a4:      	callq	0x49a9 <generic_rawtp_process_filter+0x729>
    49a9:      	leaq	0x6290(%r14), %rbp
    49b0:      	addq	$0xa78, %r13            # imm = 0xA78
    49b7:      	leaq	0x40(%rsp), %rdi
    49bc:      	movl	$0x8, %ecx
    49c1:      	movl	$0x4, %eax
    49c6:      	movl	$0x8, %esi
    49cb:      	movq	%r13, %rdx
    49ce:      	callq	*%rax
    49d0:      	movl	$0x5f8, %edx            # imm = 0x5F8
    49d5:      	movq	0x40(%rsp), %rcx
    49da:      	addq	%rdx, %rcx
    49dd:      	leaq	0x60(%rsp), %rdi
    49e2:      	movl	$0x8, %esi
    49e7:      	movl	$0x4, %eax
    49ec:      	addq	0x40(%rsp), %rdx
    49f1:      	movl	$0x8, %esi
    49f6:      	callq	*%rax
    49f8:      	movq	0x60(%rsp), %rbx
    49fd:      	movl	$0x0, 0xcc(%rsp)
    4a08:      	movq	(%rip), %rdi            # 0x4a0f <generic_rawtp_process_filter+0x78f>
    4a0f:      	leaq	0xcc(%rsp), %rsi
    4a17:      	movl	$0x1, %eax
    4a1c:      	callq	*%rax
    4a1e:      	testq	%rax, %rax
    4a21:      	je	0x5127 <generic_rawtp_process_filter+0xea7>
    4a27:      	movq	%rax, %r12
    4a2a:      	movq	%rbp, 0x38(%rsp)
    4a2f:      	movl	$0x1000, 0x6410(%r14)   # imm = 0x1000
    4a3a:      	leaq	0x1000(%rax), %r13
    4a41:      	movl	$0x23, %eax
    4a46:      	callq	*%rax
    4a48:      	leaq	0xd50(%rax), %rdx
    4a4f:      	leaq	0xd8(%rsp), %rdi
    4a57:      	movl	$0x8, %ecx
    4a5c:      	movl	$0x4, %eax
    4a61:      	movl	$0x8, %esi
    4a66:      	callq	*%rax
    4a68:      	movq	0xd8(%rsp), %rbp
    4a70:      	leaq	0x48(%rbx), %r15
    4a74:      	leaq	0xe0(%rsp), %rdi
    4a7c:      	movl	$0x8, %ecx
    4a81:      	movl	$0x4, %eax
    4a86:      	movl	$0x8, %esi
    4a8b:      	movq	%r15, %rdx
    4a8e:      	callq	*%rax
    4a90:      	movq	0xe0(%rsp), %r14
    4a98:      	leaq	0x10(%r14), %rdx
    4a9c:      	leaq	0x60(%rsp), %rdi
    4aa1:      	movl	$0x8, %ecx
    4aa6:      	movl	$0x4, %eax
    4aab:      	movl	$0x8, %esi
    4ab0:      	callq	*%rax
    4ab2:      	cmpq	$0x0, 0x60(%rsp)
    4ab8:      	je	0x4d86 <generic_rawtp_process_filter+0xb06>
    4abe:      	movq	0x50(%rsp), %r14
    4ac3:      	movq	$0x0, 0x68(%rsp)
    4acc:      	movq	$0x0, 0x60(%rsp)
    4ad5:      	movq	%r12, 0x70(%rsp)
    4ada:      	movq	$0x0, 0x78(%rsp)
    4ae3:      	movq	$0x0, 0x80(%rsp)
    4aef:      	movq	$0x0, 0x88(%rsp)
    4afb:      	movq	%r13, 0xc0(%rsp)
    4b03:      	movq	%r13, 0x90(%rsp)
    4b0b:      	movl	0x6410(%r14), %eax
    4b12:      	movl	%eax, 0x98(%rsp)
    4b19:      	leaq	0x18(%rbp), %r13
    4b1d:      	movb	$0x0, 0x9c(%rsp)
    4b25:      	addq	$0x20, %rbp
    4b29:      	leaq	0x60(%rsp), %rdi
    4b2e:      	movl	$0x8, %ecx
    4b33:      	movl	$0x4, %eax
    4b38:      	addq	$0x40, %rbx
    4b3c:      	leaq	0x68(%rsp), %r12
    4b41:      	leaq	0x78(%rsp), %r14
    4b46:      	movl	$0x8, %esi
    4b4b:      	movq	%rbp, %rdx
    4b4e:      	callq	*%rax
    4b50:      	movl	$0x8, %ecx
    4b55:      	movl	$0x4, %eax
    4b5a:      	movq	%r12, %rdi
    4b5d:      	movl	$0x8, %esi
    4b62:      	movq	%r13, %rdx
    4b65:      	callq	*%rax
    4b67:      	movl	$0x8, %ecx
    4b6c:      	movl	$0x4, %eax
    4b71:      	movq	%r14, %rdi
    4b74:      	movl	$0x8, %esi
    4b79:      	movq	%r15, %rdx
    4b7c:      	callq	*%rax
    4b7e:      	movl	$0x8, %ecx
    4b83:      	movl	$0x4, %eax
    4b88:      	leaq	0x80(%rsp), %rdi
    4b90:      	movl	$0x8, %esi
    4b95:      	movq	%rbx, %rdx
    4b98:      	callq	*%rax
    4b9a:      	movq	0x80(%rsp), %rax
    4ba2:      	addq	$-0x20, %rax
    4ba6:      	movq	%rax, 0x88(%rsp)
    4bae:      	movq	(%rip), %rax            # 0x4bb5 <generic_rawtp_process_filter+0x935>
    4bb5:      	cmpb	$0x0, (%rax)
    4bb8:      	je	0x4ddd <generic_rawtp_process_filter+0xb5d>
    4bbe:      	movl	$0x80, %r14d
    4bc4:      	movl	$0x8, %ebp
    4bc9:      	leaq	0x10(%rsp), %rbx
    4bce:      	nop
    4bd0:      	movq	0x78(%rsp), %r15
    4bd5:      	movq	0x80(%rsp), %rdx
    4bdd:      	movq	0x88(%rsp), %r12
    4be5:      	cmpq	0x60(%rsp), %r15
    4bea:      	jne	0x4bf7 <generic_rawtp_process_filter+0x977>
    4bec:      	cmpq	0x68(%rsp), %rdx
    4bf1:      	je	0x4f9f <generic_rawtp_process_filter+0xd1f>
    4bf7:      	movl	$0x4, %eax
    4bfc:      	leaq	0xa8(%rsp), %rdi
    4c04:      	movl	$0x8, %esi
    4c09:      	callq	*%rax
    4c0b:      	cmpq	0xa8(%rsp), %r15
    4c13:      	je	0x4d20 <generic_rawtp_process_filter+0xaa0>
    4c19:      	leaq	0x18(%r15), %r13
    4c1d:      	movl	$0x4, %eax
    4c22:      	movq	%rbx, %rdi
    4c25:      	movl	$0x8, %esi
    4c2a:      	movq	%r13, %rdx
    4c2d:      	callq	*%rax
    4c2f:      	cmpq	%r15, 0x10(%rsp)
    4c34:      	je	0x4d20 <generic_rawtp_process_filter+0xaa0>
    4c3a:      	movl	$0x4, %eax
    4c3f:      	leaq	0x58(%rsp), %rdi
    4c44:      	movl	$0x8, %esi
    4c49:      	movq	%r13, %rdx
    4c4c:      	callq	*%rax
    4c4e:      	addq	$0x20, %r15
    4c52:      	movl	$0x4, %eax
    4c57:      	leaq	0x40(%rsp), %rdi
    4c5c:      	movl	$0x10, %ecx
    4c61:      	movl	$0x10, %esi
    4c66:      	movq	%r15, %rdx
    4c69:      	callq	*%rax
    4c6b:      	movq	0x70(%rsp), %r15
    4c70:      	movq	0x90(%rsp), %rax
    4c78:      	movl	0x44(%rsp), %r12d
    4c7d:      	subq	%r15, %rax
    4c80:      	movl	0x98(%rsp), %r13d
    4c88:      	movl	%r12d, %edx
    4c8b:      	subl	%r13d, %edx
    4c8e:      	movl	$0x0, %ecx
    4c93:      	cmovbl	%ecx, %edx
    4c96:      	addq	0x48(%rsp), %rdx
    4c9b:      	xorl	%esi, %esi
    4c9d:      	cmpl	%r12d, %r13d
    4ca0:      	seta	%sil
    4ca4:      	movl	%r12d, %ecx
    4ca7:      	cmovbl	%r13d, %ecx
    4cab:      	addl	%ecx, %esi
    4cad:      	movl	%r13d, %edi
    4cb0:      	subl	%esi, %edi
    4cb2:      	movl	%edi, 0x98(%rsp)
    4cb9:      	subq	%rsi, %rax
    4cbc:      	jb	0x4fa7 <generic_rawtp_process_filter+0xd27>
    4cc2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    4cc8:      	ja	0x4fa7 <generic_rawtp_process_filter+0xd27>
    4cce:      	cmpl	%r12d, %r13d
    4cd1:      	jbe	0x4cd8 <generic_rawtp_process_filter+0xa58>
    4cd3:      	movb	$0x2f, (%r15,%rax)
    4cd8:      	xorl	%edi, %edi
    4cda:      	cmpl	%r12d, %r13d
    4cdd:      	seta	%dil
    4ce1:      	movzbl	%cl, %esi
    4ce4:      	addq	%rax, %r15
    4ce7:      	addq	%r15, %rdi
    4cea:      	movl	$0x4, %eax
    4cef:      	callq	*%rax
    4cf1:      	movq	%r15, 0x90(%rsp)
    4cf9:      	cmpl	%r12d, %r13d
    4cfc:      	jbe	0x4fa7 <generic_rawtp_process_filter+0xd27>
    4d02:      	movq	0x58(%rsp), %rax
    4d07:      	movq	%rax, 0x78(%rsp)
    4d0c:      	decl	%r14d
    4d0f:      	jne	0x4bd0 <generic_rawtp_process_filter+0x950>
    4d15:      	jmp	0x4fa7 <generic_rawtp_process_filter+0xd27>
    4d1a:      	nopw	(%rax,%rax)
    4d20:      	leaq	0x10(%r12), %rdx
    4d25:      	movl	$0x4, %eax
    4d2a:      	movq	%rbx, %rdi
    4d2d:      	movl	$0x8, %esi
    4d32:      	callq	*%rax
    4d34:      	movq	0x88(%rsp), %rax
    4d3c:      	cmpq	0x10(%rsp), %rax
    4d41:      	je	0x4f9f <generic_rawtp_process_filter+0xd1f>
    4d47:      	addq	$0x18, %r12
    4d4b:      	movl	$0x4, %eax
    4d50:      	leaq	0x78(%rsp), %rdi
    4d55:      	movl	$0x8, %esi
    4d5a:      	movq	%r12, %rdx
    4d5d:      	callq	*%rax
    4d5f:      	movq	0x10(%rsp), %rax
    4d64:      	movq	%rax, 0x88(%rsp)
    4d6c:      	addq	$0x20, %rax
    4d70:      	movq	%rax, 0x80(%rsp)
    4d78:      	decl	%r14d
    4d7b:      	jne	0x4bd0 <generic_rawtp_process_filter+0x950>
    4d81:      	jmp	0x4fa7 <generic_rawtp_process_filter+0xd27>
    4d86:      	leaq	0x18(%r14), %rdx
    4d8a:      	leaq	0x60(%rsp), %rdi
    4d8f:      	movl	$0x8, %ecx
    4d94:      	movl	$0x4, %eax
    4d99:      	movl	$0x8, %esi
    4d9e:      	callq	*%rax
    4da0:      	cmpq	%r14, 0x60(%rsp)
    4da5:      	je	0x4abe <generic_rawtp_process_filter+0x83e>
    4dab:      	movq	0x50(%rsp), %r14
    4db0:      	movl	0x6410(%r14), %ecx
    4db7:      	leal	-0xa(%rcx), %eax
    4dba:      	movl	%eax, 0x6410(%r14)
    4dc1:      	cmpl	$0x9, %ecx
    4dc4:      	jg	0x5764 <generic_rawtp_process_filter+0x14e4>
    4dca:      	movl	$0xffffffdc, 0x6414(%r14) # imm = 0xFFFFFFDC
    4dd5:      	movq	%r13, %rbx
    4dd8:      	jmp	0x5028 <generic_rawtp_process_filter+0xda8>
    4ddd:      	movl	$0x80, %r14d
    4de3:      	movl	$0x8, %ebp
    4de8:      	leaq	0x10(%rsp), %rbx
    4ded:      	nopl	(%rax)
    4df0:      	movq	0x78(%rsp), %r15
    4df5:      	movq	0x80(%rsp), %rdx
    4dfd:      	movq	0x88(%rsp), %r12
    4e05:      	cmpq	0x60(%rsp), %r15
    4e0a:      	jne	0x4e17 <generic_rawtp_process_filter+0xb97>
    4e0c:      	cmpq	0x68(%rsp), %rdx
    4e11:      	je	0x4f9f <generic_rawtp_process_filter+0xd1f>
    4e17:      	movl	$0x4, %eax
    4e1c:      	leaq	0xa8(%rsp), %rdi
    4e24:      	movl	$0x8, %esi
    4e29:      	callq	*%rax
    4e2b:      	cmpq	0xa8(%rsp), %r15
    4e33:      	je	0x4f40 <generic_rawtp_process_filter+0xcc0>
    4e39:      	leaq	0x18(%r15), %r13
    4e3d:      	movl	$0x4, %eax
    4e42:      	movq	%rbx, %rdi
    4e45:      	movl	$0x8, %esi
    4e4a:      	movq	%r13, %rdx
    4e4d:      	callq	*%rax
    4e4f:      	cmpq	%r15, 0x10(%rsp)
    4e54:      	je	0x4f40 <generic_rawtp_process_filter+0xcc0>
    4e5a:      	movl	$0x4, %eax
    4e5f:      	leaq	0x58(%rsp), %rdi
    4e64:      	movl	$0x8, %esi
    4e69:      	movq	%r13, %rdx
    4e6c:      	callq	*%rax
    4e6e:      	addq	$0x20, %r15
    4e72:      	movl	$0x4, %eax
    4e77:      	leaq	0x40(%rsp), %rdi
    4e7c:      	movl	$0x10, %ecx
    4e81:      	movl	$0x10, %esi
    4e86:      	movq	%r15, %rdx
    4e89:      	callq	*%rax
    4e8b:      	movq	0x70(%rsp), %r15
    4e90:      	movq	0x90(%rsp), %rax
    4e98:      	movl	0x44(%rsp), %r12d
    4e9d:      	subq	%r15, %rax
    4ea0:      	movl	0x98(%rsp), %r13d
    4ea8:      	movl	%r12d, %edx
    4eab:      	subl	%r13d, %edx
    4eae:      	movl	$0x0, %ecx
    4eb3:      	cmovbl	%ecx, %edx
    4eb6:      	addq	0x48(%rsp), %rdx
    4ebb:      	xorl	%esi, %esi
    4ebd:      	cmpl	%r12d, %r13d
    4ec0:      	seta	%sil
    4ec4:      	movl	%r12d, %ecx
    4ec7:      	cmovbl	%r13d, %ecx
    4ecb:      	addl	%ecx, %esi
    4ecd:      	movl	%r13d, %edi
    4ed0:      	subl	%esi, %edi
    4ed2:      	movl	%edi, 0x98(%rsp)
    4ed9:      	subq	%rsi, %rax
    4edc:      	jb	0x4fa7 <generic_rawtp_process_filter+0xd27>
    4ee2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    4ee8:      	ja	0x4fa7 <generic_rawtp_process_filter+0xd27>
    4eee:      	cmpl	%r12d, %r13d
    4ef1:      	jbe	0x4ef8 <generic_rawtp_process_filter+0xc78>
    4ef3:      	movb	$0x2f, (%r15,%rax)
    4ef8:      	xorl	%edi, %edi
    4efa:      	cmpl	%r12d, %r13d
    4efd:      	seta	%dil
    4f01:      	movzbl	%cl, %esi
    4f04:      	addq	%rax, %r15
    4f07:      	addq	%r15, %rdi
    4f0a:      	movl	$0x4, %eax
    4f0f:      	callq	*%rax
    4f11:      	movq	%r15, 0x90(%rsp)
    4f19:      	cmpl	%r12d, %r13d
    4f1c:      	jbe	0x4fa7 <generic_rawtp_process_filter+0xd27>
    4f22:      	movq	0x58(%rsp), %rax
    4f27:      	movq	%rax, 0x78(%rsp)
    4f2c:      	decl	%r14d
    4f2f:      	jne	0x4df0 <generic_rawtp_process_filter+0xb70>
    4f35:      	jmp	0x4fa7 <generic_rawtp_process_filter+0xd27>
    4f37:      	nopw	(%rax,%rax)
    4f40:      	leaq	0x10(%r12), %rdx
    4f45:      	movl	$0x4, %eax
    4f4a:      	movq	%rbx, %rdi
    4f4d:      	movl	$0x8, %esi
    4f52:      	callq	*%rax
    4f54:      	movq	0x88(%rsp), %rax
    4f5c:      	cmpq	0x10(%rsp), %rax
    4f61:      	je	0x4f9f <generic_rawtp_process_filter+0xd1f>
    4f63:      	addq	$0x18, %r12
    4f67:      	movl	$0x4, %eax
    4f6c:      	leaq	0x78(%rsp), %rdi
    4f71:      	movl	$0x8, %esi
    4f76:      	movq	%r12, %rdx
    4f79:      	callq	*%rax
    4f7b:      	movq	0x10(%rsp), %rax
    4f80:      	movq	%rax, 0x88(%rsp)
    4f88:      	addq	$0x20, %rax
    4f8c:      	movq	%rax, 0x80(%rsp)
    4f94:      	decl	%r14d
    4f97:      	jne	0x4df0 <generic_rawtp_process_filter+0xb70>
    4f9d:      	jmp	0x4fa7 <generic_rawtp_process_filter+0xd27>
    4f9f:      	movb	$0x1, 0x9c(%rsp)
    4fa7:      	movq	0x90(%rsp), %rbx
    4faf:      	movq	0xc0(%rsp), %rcx
    4fb7:      	cmpq	%rcx, %rbx
    4fba:      	je	0x5008 <generic_rawtp_process_filter+0xd88>
    4fbc:      	xorl	%ecx, %ecx
    4fbe:      	cmpb	$0x0, 0x9c(%rsp)
    4fc6:      	sete	%cl
    4fc9:      	addl	%ecx, %ecx
    4fcb:      	movl	0x98(%rsp), %eax
    4fd2:      	movq	0x50(%rsp), %r14
    4fd7:      	movl	%eax, 0x6410(%r14)
    4fde:      	movl	%ecx, 0x6414(%r14)
    4fe5:      	testl	%eax, %eax
    4fe7:      	movq	0x38(%rsp), %rbp
    4fec:      	jle	0x4ffe <generic_rawtp_process_filter+0xd7e>
    4fee:      	movl	$0x1000, %ecx           # imm = 0x1000
    4ff3:      	subl	%eax, %ecx
    4ff5:      	movl	%ecx, 0x6410(%r14)
    4ffc:      	movl	%ecx, %eax
    4ffe:      	testq	%rbx, %rbx
    5001:      	jne	0x502d <generic_rawtp_process_filter+0xdad>
    5003:      	jmp	0x5127 <generic_rawtp_process_filter+0xea7>
    5008:      	movq	0x50(%rsp), %r14
    500d:      	movl	$0x0, 0x6410(%r14)
    5018:      	movl	$0x0, 0x6414(%r14)
    5023:      	xorl	%eax, %eax
    5025:      	movq	%rcx, %rbx
    5028:      	movq	0x38(%rsp), %rbp
    502d:      	xorl	%ecx, %ecx
    502f:      	movq	%r14, %rdx
    5032:      	movl	%eax, %r14d
    5035:      	subl	$0x7f, %r14d
    5039:      	movl	$0x7f, %r15d
    503f:      	cmovbl	%eax, %r15d
    5043:      	cmovbl	%ecx, %r14d
    5047:      	cmpl	$0xff, %eax
    504c:      	movl	$0xff, %ecx
    5051:      	cmovbl	%eax, %ecx
    5054:      	movzbl	%cl, %esi
    5057:      	movl	%esi, 0x6410(%rdx)
    505d:      	movl	$0x4, %eax
    5062:      	movq	%rbp, %rdi
    5065:      	movq	%rbx, %rdx
    5068:      	callq	*%rax
    506a:      	testq	%rax, %rax
    506d:      	je	0x50cc <generic_rawtp_process_filter+0xe4c>
    506f:      	negl	%eax
    5071:      	movw	%ax, 0x60(%rsp)
    5076:      	movw	$0x8, 0x62(%rsp)
    507d:      	movabsq	$0x4000002de, %rax      # imm = 0x4000002DE
    5087:      	movq	%rax, 0x64(%rsp)
    508c:      	movq	(%rip), %rdi            # 0x5093 <generic_rawtp_process_filter+0xe13>
    5093:      	leaq	0x60(%rsp), %rsi
    5098:      	movl	$0x1, %eax
    509d:      	callq	*%rax
    509f:      	testq	%rax, %rax
    50a2:      	je	0x50a8 <generic_rawtp_process_filter+0xe28>
    50a4:      	incl	(%rax)
    50a6:      	jmp	0x50cc <generic_rawtp_process_filter+0xe4c>
    50a8:      	movl	$0x1, 0x40(%rsp)
    50b0:      	movq	(%rip), %rdi            # 0x50b7 <generic_rawtp_process_filter+0xe37>
    50b7:      	xorl	%ecx, %ecx
    50b9:      	leaq	0x60(%rsp), %rsi
    50be:      	leaq	0x40(%rsp), %rdx
    50c3:      	movl	$0x2, %eax
    50c8:      	xorl	%ecx, %ecx
    50ca:      	callq	*%rax
    50cc:      	movq	0x50(%rsp), %rax
    50d1:      	leaq	0x6390(%rax), %rdi
    50d8:      	addq	%r14, %rbx
    50db:      	movq	%rax, %r14
    50de:      	movl	$0x4, %eax
    50e3:      	movl	%r15d, %esi
    50e6:      	movq	%rbx, %rdx
    50e9:      	callq	*%rax
    50eb:      	testq	%rax, %rax
    50ee:      	je	0x5127 <generic_rawtp_process_filter+0xea7>
    50f0:      	negl	%eax
    50f2:      	movw	%ax, 0x60(%rsp)
    50f7:      	movw	$0x8, 0x62(%rsp)
    50fe:      	movabsq	$0x4000002e0, %rax      # imm = 0x4000002E0
    5108:      	movq	%rax, 0x64(%rsp)
    510d:      	movq	(%rip), %rdi            # 0x5114 <generic_rawtp_process_filter+0xe94>
    5114:      	leaq	0x60(%rsp), %rsi
    5119:      	movl	$0x1, %eax
    511e:      	callq	*%rax
    5120:      	testq	%rax, %rax
    5123:      	je	0x5154 <generic_rawtp_process_filter+0xed4>
    5125:      	incl	(%rax)
    5127:      	movl	0x6410(%r14), %eax
    512e:      	leal	-0x101(%rax), %ecx
    5134:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    513a:      	ja	0x518d <generic_rawtp_process_filter+0xf0d>
    513c:      	movq	0x8(%rsp), %rax
    5141:      	movl	$0xffffffff, (%rax)     # imm = 0xFFFFFFFF
    5147:      	movq	0xb8(%rsp), %rbx
    514f:      	jmp	0x52a3 <generic_rawtp_process_filter+0x1023>
    5154:      	movl	$0x1, 0x40(%rsp)
    515c:      	movq	(%rip), %rdi            # 0x5163 <generic_rawtp_process_filter+0xee3>
    5163:      	xorl	%ecx, %ecx
    5165:      	leaq	0x60(%rsp), %rsi
    516a:      	leaq	0x40(%rsp), %rdx
    516f:      	movl	$0x2, %eax
    5174:      	xorl	%ecx, %ecx
    5176:      	callq	*%rax
    5178:      	movl	0x6410(%r14), %eax
    517f:      	leal	-0x101(%rax), %ecx
    5185:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    518b:      	jbe	0x513c <generic_rawtp_process_filter+0xebc>
    518d:      	movzbl	%al, %ebx
    5190:      	leaq	0x5f80(%r14), %rdi
    5197:      	movl	$0x4, %eax
    519c:      	movl	%ebx, %esi
    519e:      	movq	%rbp, %rdx
    51a1:      	callq	*%rax
    51a3:      	movq	%rax, %r15
    51a6:      	testq	%rax, %rax
    51a9:      	je	0x520b <generic_rawtp_process_filter+0xf8b>
    51ab:      	movl	%r15d, %eax
    51ae:      	negl	%eax
    51b0:      	movw	%ax, 0x60(%rsp)
    51b5:      	movw	$0xf, 0x62(%rsp)
    51bc:      	movabsq	$0x400000164, %rax      # imm = 0x400000164
    51c6:      	movq	%rax, 0x64(%rsp)
    51cb:      	movq	(%rip), %rdi            # 0x51d2 <generic_rawtp_process_filter+0xf52>
    51d2:      	leaq	0x60(%rsp), %rsi
    51d7:      	movl	$0x1, %eax
    51dc:      	callq	*%rax
    51de:      	testq	%rax, %rax
    51e1:      	je	0x51e7 <generic_rawtp_process_filter+0xf67>
    51e3:      	incl	(%rax)
    51e5:      	jmp	0x520b <generic_rawtp_process_filter+0xf8b>
    51e7:      	movl	$0x1, 0x40(%rsp)
    51ef:      	movq	(%rip), %rdi            # 0x51f6 <generic_rawtp_process_filter+0xf76>
    51f6:      	xorl	%ecx, %ecx
    51f8:      	leaq	0x60(%rsp), %rsi
    51fd:      	leaq	0x40(%rsp), %rdx
    5202:      	movl	$0x2, %eax
    5207:      	xorl	%ecx, %ecx
    5209:      	callq	*%rax
    520b:      	testl	%r15d, %r15d
    520e:      	cmovel	%ebx, %r15d
    5212:      	movl	%r15d, 0x5f78(%r14)
    5219:      	cmpl	$0x7f, %ebx
    521c:      	movl	$0x7f, %esi
    5221:      	cmovbl	%ebx, %esi
    5224:      	leaq	0x6080(%r14), %rdi
    522b:      	leaq	0x6390(%r14), %rdx
    5232:      	movl	$0x4, %eax
    5237:      	callq	*%rax
    5239:      	testq	%rax, %rax
    523c:      	movq	0xb8(%rsp), %rbx
    5244:      	je	0x52a3 <generic_rawtp_process_filter+0x1023>
    5246:      	negl	%eax
    5248:      	movw	%ax, 0x60(%rsp)
    524d:      	movw	$0xf, 0x62(%rsp)
    5254:      	movabsq	$0x40000016a, %rax      # imm = 0x40000016A
    525e:      	movq	%rax, 0x64(%rsp)
    5263:      	movq	(%rip), %rdi            # 0x526a <generic_rawtp_process_filter+0xfea>
    526a:      	leaq	0x60(%rsp), %rsi
    526f:      	movl	$0x1, %eax
    5274:      	callq	*%rax
    5276:      	testq	%rax, %rax
    5279:      	je	0x527f <generic_rawtp_process_filter+0xfff>
    527b:      	incl	(%rax)
    527d:      	jmp	0x52a3 <generic_rawtp_process_filter+0x1023>
    527f:      	movl	$0x1, 0x40(%rsp)
    5287:      	movq	(%rip), %rdi            # 0x528e <generic_rawtp_process_filter+0x100e>
    528e:      	xorl	%ecx, %ecx
    5290:      	leaq	0x60(%rsp), %rsi
    5295:      	leaq	0x40(%rsp), %rdx
    529a:      	movl	$0x2, %eax
    529f:      	xorl	%ecx, %ecx
    52a1:      	callq	*%rax
    52a3:      	leaq	0x5f10(%r14), %r15
    52aa:      	orb	$0x10, 0x1(%r14)
    52af:      	leaq	0x5ef8(%r14), %rsi
    52b6:      	movq	(%rip), %rdi            # 0x52bd <generic_rawtp_process_filter+0x103d>
    52bd:      	movl	$0x1, %eax
    52c2:      	callq	*%rax
    52c4:      	testq	%rax, %rax
    52c7:      	je	0x68a3 <generic_rawtp_process_filter+0x2623>
    52cd:      	movq	0x5eb8(%r14), %r13
    52d4:      	cmpq	$0x6, %r13
    52d8:      	jae	0x5506 <generic_rawtp_process_filter+0x1286>
    52de:      	movslq	(%rax), %rcx
    52e1:      	testq	%rcx, %rcx
    52e4:      	je	0x5528 <generic_rawtp_process_filter+0x12a8>
    52ea:      	cmpq	%rcx, %r13
    52ed:      	jae	0x5506 <generic_rawtp_process_filter+0x1286>
    52f3:      	movq	%rax, 0x8(%rsp)
    52f8:      	movq	%rcx, 0xc0(%rsp)
    5300:      	movq	%rbx, 0xb8(%rsp)
    5308:      	movl	%r13d, 0x10(%rsp)
    530d:      	movl	$0x0, 0x58(%rsp)
    5315:      	movq	(%rip), %rdi            # 0x531c <generic_rawtp_process_filter+0x109c>
    531c:      	leaq	0x10(%rsp), %rsi
    5321:      	movl	$0x1, %eax
    5326:      	callq	*%rax
    5328:      	testq	%rax, %rax
    532b:      	movq	%r15, 0x38(%rsp)
    5330:      	je	0x5544 <generic_rawtp_process_filter+0x12c4>
    5336:      	movq	%rax, %rbx
    5339:      	movl	(%rax), %eax
    533b:      	testl	%eax, %eax
    533d:      	je	0x5544 <generic_rawtp_process_filter+0x12c4>
    5343:      	cmpl	$0x0, 0x68(%r15)
    5348:      	js	0x684b <generic_rawtp_process_filter+0x25cb>
    534e:      	cmpl	$0x1b, %eax
    5351:      	ja	0x684b <generic_rawtp_process_filter+0x25cb>
    5357:      	movl	$0x60, %ecx
    535c:      	btl	%eax, %ecx
    535f:      	jb	0x5fdc <generic_rawtp_process_filter+0x1d5c>
    5365:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    536a:      	btl	%eax, %ecx
    536d:      	jb	0x5f49 <generic_rawtp_process_filter+0x1cc9>
    5373:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    5378:      	btl	%eax, %ecx
    537b:      	jae	0x684b <generic_rawtp_process_filter+0x25cb>
    5381:      	movq	%rbx, %rsi
    5384:      	addq	$0x4, %rsi
    5388:      	movq	(%rip), %rdi            # 0x538f <generic_rawtp_process_filter+0x110f>
    538f:      	movl	$0x1, %eax
    5394:      	callq	*%rax
    5396:      	testq	%rax, %rax
    5399:      	je	0x684b <generic_rawtp_process_filter+0x25cb>
    539f:      	movq	%rax, %r12
    53a2:      	movq	0x38(%rsp), %rax
    53a7:      	movl	0x68(%rax), %eax
    53aa:      	cmpl	$0x7f, %eax
    53ad:      	movl	$0x7f, %r14d
    53b3:      	cmovll	%eax, %r14d
    53b7:      	movq	(%rip), %rdi            # 0x53be <generic_rawtp_process_filter+0x113e>
    53be:      	leaq	0x58(%rsp), %rsi
    53c3:      	movl	$0x1, %eax
    53c8:      	callq	*%rax
    53ca:      	testq	%rax, %rax
    53cd:      	je	0x684b <generic_rawtp_process_filter+0x25cb>
    53d3:      	movq	%rax, %rbp
    53d6:      	leal	(,%r14,8), %eax
    53de:      	movl	%eax, (%rbp)
    53e1:      	movq	0x38(%rsp), %rax
    53e6:      	cmpl	$0x0, 0x6c(%rax)
    53ea:      	jne	0x54cd <generic_rawtp_process_filter+0x124d>
    53f0:      	movq	0x38(%rsp), %r15
    53f5:      	movl	0x68(%r15), %ecx
    53f9:      	movl	%ecx, %eax
    53fb:      	subl	%r14d, %eax
    53fe:      	movl	%r14d, %edx
    5401:      	andl	$0x7f, %edx
    5404:      	addl	%edx, %eax
    5406:      	addl	%ecx, %edx
    5408:      	movl	%r14d, %ecx
    540b:      	notl	%ecx
    540d:      	addl	%edx, %ecx
    540f:      	subl	%r14d, %edx
    5412:      	leal	-0x4(%rdx), %esi
    5415:      	leaq	0x1f3(%r15), %rdi
    541c:      	leal	-0x3(%rdx), %r8d
    5420:      	addl	$-0x2, %edx
    5423:      	movq	$-0x3, %r9
    542a:      	leal	(%rcx,%r9), %r10d
    542e:      	addl	$0x3, %r10d
    5432:      	andl	$0x7f, %r10d
    5436:      	movzbl	0x170(%r15,%r10), %r10d
    543f:      	movb	%r10b, -0x3(%rdi)
    5443:      	leaq	(%rax,%r9), %r10
    5447:      	cmpq	$-0x2, %r10
    544b:      	je	0x54c5 <generic_rawtp_process_filter+0x1245>
    544d:      	leal	(%rdx,%r9), %r11d
    5451:      	addl	$0x3, %r11d
    5455:      	andl	$0x7f, %r11d
    5459:      	movzbl	0x170(%r15,%r11), %r11d
    5462:      	movb	%r11b, -0x2(%rdi)
    5466:      	cmpq	$-0x1, %r10
    546a:      	je	0x54c5 <generic_rawtp_process_filter+0x1245>
    546c:      	leal	(%r8,%r9), %r10d
    5470:      	addl	$0x3, %r10d
    5474:      	andl	$0x7f, %r10d
    5478:      	movzbl	0x170(%r15,%r10), %r10d
    5481:      	movb	%r10b, -0x1(%rdi)
    5485:      	movq	%rax, %r10
    5488:      	addq	%r9, %r10
    548b:      	je	0x54c5 <generic_rawtp_process_filter+0x1245>
    548d:      	cmpq	$-0x7f, %r9
    5491:      	je	0x54c5 <generic_rawtp_process_filter+0x1245>
    5493:      	leal	(%rsi,%r9), %r10d
    5497:      	addl	$0x3, %r10d
    549b:      	andl	$0x7f, %r10d
    549f:      	movzbl	0x170(%r15,%r10), %r10d
    54a8:      	movb	%r10b, (%rdi)
    54ab:      	addq	$0x4, %rdi
    54af:      	leaq	(%rax,%r9), %r10
    54b3:      	addq	$-0x4, %r10
    54b7:      	addq	$-0x4, %r9
    54bb:      	cmpq	$-0x3, %r10
    54bf:      	jne	0x542a <generic_rawtp_process_filter+0x11aa>
    54c5:      	movl	$0x1, 0x6c(%r15)
    54cd:      	cmpl	$0x7f, %r14d
    54d1:      	ja	0x54f9 <generic_rawtp_process_filter+0x1279>
    54d3:      	movslq	%r14d, %rsi
    54d6:      	movq	%rbp, %rdi
    54d9:      	addq	$0x4, %rdi
    54dd:      	movq	0x38(%rsp), %rax
    54e2:      	leaq	0x1f0(%rax), %rdx
    54e9:      	movl	$0x4, %eax
    54ee:      	callq	*%rax
    54f0:      	testq	%rax, %rax
    54f3:      	js	0x684b <generic_rawtp_process_filter+0x25cb>
    54f9:      	movl	$0x1, %eax
    54fe:      	movq	%r12, %rdi
    5501:      	jmp	0x5fd4 <generic_rawtp_process_filter+0x1d54>
    5506:      	movl	(%r15), %eax
    5509:      	movl	%eax, 0x10(%r14)
    550d:      	movq	0x8(%r15), %rax
    5511:      	movq	%rax, 0x18(%r14)
    5515:      	cmpb	$0x0, 0x5ec0(%r14)
    551d:      	jne	0x688e <generic_rawtp_process_filter+0x260e>
    5523:      	jmp	0x68a3 <generic_rawtp_process_filter+0x2623>
    5528:      	movb	$0x1, 0x5ec0(%r14)
    5530:      	movl	(%r15), %eax
    5533:      	movl	%eax, 0x10(%r14)
    5537:      	movq	0x8(%r15), %rax
    553b:      	movq	%rax, 0x18(%r14)
    553f:      	jmp	0x688e <generic_rawtp_process_filter+0x260e>
    5544:      	movq	0x8(%rsp), %r10
    5549:      	movq	(%rip), %rax            # 0x5550 <generic_rawtp_process_filter+0x12d0>
    5550:      	cmpb	$0x0, (%rax)
    5553:      	je	0x5795 <generic_rawtp_process_filter+0x1515>
    5559:      	movq	(%rip), %rdi            # 0x5560 <generic_rawtp_process_filter+0x12e0>
    5560:      	movl	$0x1, %eax
    5565:      	movq	0x38(%rsp), %rsi
    556a:      	callq	*%rax
    556c:      	movq	0x8(%rsp), %r10
    5571:      	testq	%rax, %rax
    5574:      	je	0x5795 <generic_rawtp_process_filter+0x1515>
    557a:      	movq	%rax, %rbp
    557d:      	leal	0x5(%r13), %eax
    5581:      	movl	%eax, 0x10(%rsp)
    5585:      	movl	$0x0, 0x58(%rsp)
    558d:      	movq	(%rip), %rdi            # 0x5594 <generic_rawtp_process_filter+0x1314>
    5594:      	leaq	0x10(%rsp), %rsi
    5599:      	movl	$0x1, %eax
    559e:      	callq	*%rax
    55a0:      	testq	%rax, %rax
    55a3:      	je	0x5790 <generic_rawtp_process_filter+0x1510>
    55a9:      	movq	%rax, %r12
    55ac:      	movl	(%rax), %eax
    55ae:      	testl	%eax, %eax
    55b0:      	je	0x5790 <generic_rawtp_process_filter+0x1510>
    55b6:      	cmpl	$0x0, (%rbp)
    55ba:      	js	0x684b <generic_rawtp_process_filter+0x25cb>
    55c0:      	cmpl	$0x1b, %eax
    55c3:      	ja	0x684b <generic_rawtp_process_filter+0x25cb>
    55c9:      	movl	$0x60, %ecx
    55ce:      	btl	%eax, %ecx
    55d1:      	jb	0x6238 <generic_rawtp_process_filter+0x1fb8>
    55d7:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    55dc:      	btl	%eax, %ecx
    55df:      	jb	0x61a8 <generic_rawtp_process_filter+0x1f28>
    55e5:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    55ea:      	btl	%eax, %ecx
    55ed:      	jae	0x684b <generic_rawtp_process_filter+0x25cb>
    55f3:      	movq	%r12, %rsi
    55f6:      	addq	$0x4, %rsi
    55fa:      	movq	(%rip), %rdi            # 0x5601 <generic_rawtp_process_filter+0x1381>
    5601:      	movl	$0x1, %eax
    5606:      	callq	*%rax
    5608:      	testq	%rax, %rax
    560b:      	je	0x684b <generic_rawtp_process_filter+0x25cb>
    5611:      	movq	%rax, %r15
    5614:      	movl	(%rbp), %eax
    5617:      	cmpl	$0x7f, %eax
    561a:      	movl	$0x7f, %r14d
    5620:      	cmovll	%eax, %r14d
    5624:      	movq	(%rip), %rdi            # 0x562b <generic_rawtp_process_filter+0x13ab>
    562b:      	leaq	0x58(%rsp), %rsi
    5630:      	movl	$0x1, %eax
    5635:      	callq	*%rax
    5637:      	testq	%rax, %rax
    563a:      	je	0x684b <generic_rawtp_process_filter+0x25cb>
    5640:      	movq	%rax, %rbx
    5643:      	leal	(,%r14,8), %eax
    564b:      	movl	%eax, (%rbx)
    564d:      	cmpl	$0x0, 0x4(%rbp)
    5651:      	jne	0x572d <generic_rawtp_process_filter+0x14ad>
    5657:      	movl	(%rbp), %ecx
    565a:      	movl	%ecx, %eax
    565c:      	subl	%r14d, %eax
    565f:      	movl	%r14d, %edx
    5662:      	andl	$0x7f, %edx
    5665:      	addl	%edx, %eax
    5667:      	addl	%ecx, %edx
    5669:      	movl	%r14d, %ecx
    566c:      	notl	%ecx
    566e:      	addl	%edx, %ecx
    5670:      	subl	%r14d, %edx
    5673:      	leal	-0x4(%rdx), %esi
    5676:      	leaq	0x18b(%rbp), %rdi
    567d:      	leal	-0x3(%rdx), %r8d
    5681:      	addl	$-0x2, %edx
    5684:      	movq	$-0x3, %r9
    568b:      	leal	(%rcx,%r9), %r10d
    568f:      	addl	$0x3, %r10d
    5693:      	andl	$0x7f, %r10d
    5697:      	movzbl	0x108(%rbp,%r10), %r10d
    56a0:      	movb	%r10b, -0x3(%rdi)
    56a4:      	leaq	(%rax,%r9), %r10
    56a8:      	cmpq	$-0x2, %r10
    56ac:      	je	0x5726 <generic_rawtp_process_filter+0x14a6>
    56ae:      	leal	(%rdx,%r9), %r11d
    56b2:      	addl	$0x3, %r11d
    56b6:      	andl	$0x7f, %r11d
    56ba:      	movzbl	0x108(%rbp,%r11), %r11d
    56c3:      	movb	%r11b, -0x2(%rdi)
    56c7:      	cmpq	$-0x1, %r10
    56cb:      	je	0x5726 <generic_rawtp_process_filter+0x14a6>
    56cd:      	leal	(%r8,%r9), %r10d
    56d1:      	addl	$0x3, %r10d
    56d5:      	andl	$0x7f, %r10d
    56d9:      	movzbl	0x108(%rbp,%r10), %r10d
    56e2:      	movb	%r10b, -0x1(%rdi)
    56e6:      	movq	%rax, %r10
    56e9:      	addq	%r9, %r10
    56ec:      	je	0x5726 <generic_rawtp_process_filter+0x14a6>
    56ee:      	cmpq	$-0x7f, %r9
    56f2:      	je	0x5726 <generic_rawtp_process_filter+0x14a6>
    56f4:      	leal	(%rsi,%r9), %r10d
    56f8:      	addl	$0x3, %r10d
    56fc:      	andl	$0x7f, %r10d
    5700:      	movzbl	0x108(%rbp,%r10), %r10d
    5709:      	movb	%r10b, (%rdi)
    570c:      	addq	$0x4, %rdi
    5710:      	leaq	(%rax,%r9), %r10
    5714:      	addq	$-0x4, %r10
    5718:      	addq	$-0x4, %r9
    571c:      	cmpq	$-0x3, %r10
    5720:      	jne	0x568b <generic_rawtp_process_filter+0x140b>
    5726:      	movl	$0x1, 0x4(%rbp)
    572d:      	cmpl	$0x7f, %r14d
    5731:      	ja	0x5757 <generic_rawtp_process_filter+0x14d7>
    5733:      	movslq	%r14d, %rsi
    5736:      	movq	%rbx, %rdi
    5739:      	addq	$0x4, %rdi
    573d:      	addq	$0x188, %rbp            # imm = 0x188
    5744:      	movl	$0x4, %eax
    5749:      	movq	%rbp, %rdx
    574c:      	callq	*%rax
    574e:      	testq	%rax, %rax
    5751:      	js	0x684b <generic_rawtp_process_filter+0x25cb>
    5757:      	movl	$0x1, %eax
    575c:      	movq	%r15, %rdi
    575f:      	jmp	0x6230 <generic_rawtp_process_filter+0x1fb0>
    5764:      	movq	%r12, %r13
    5767:      	addq	$0xff6, %r13            # imm = 0xFF6
    576e:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    5778:      	movq	%rax, 0xff6(%r12)
    5780:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
    578b:      	jmp	0x4ac3 <generic_rawtp_process_filter+0x843>
    5790:      	movq	0x8(%rsp), %r10
    5795:      	movl	%r13d, %eax
    5798:      	leaq	0x4(,%rax,4), %rcx
    57a0:      	movl	0x4(%r10,%rax,4), %eax
    57a5:      	leal	(%rax,%rcx), %r14d
    57a9:      	andl	$0x3ff, %r14d           # imm = 0x3FF
    57b0:      	addl	%eax, %ecx
    57b2:      	addl	$0x4, %ecx
    57b5:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    57bb:      	leaq	0x8(%r14), %rbp
    57bf:      	cmpl	$0x5, (%rcx,%r10)
    57c4:      	jb	0x5cee <generic_rawtp_process_filter+0x1a6e>
    57ca:      	movl	(%rbp,%r10), %r12d
    57cf:      	movl	0x4(%rbp,%r10), %edi
    57d4:      	movl	0x8(%rbp,%r10), %edx
    57d9:      	movq	$0x0, 0x68(%rsp)
    57e2:      	movq	$0x0, 0x60(%rsp)
    57eb:      	cmpl	$0x4, %edx
    57ee:      	movl	$0x4, %ecx
    57f3:      	cmovbl	%edx, %ecx
    57f6:      	cmpl	$0x6, %r12d
    57fa:      	jne	0x5810 <generic_rawtp_process_filter+0x1590>
    57fc:      	movabsq	$0x100000001, %rsi      # imm = 0x100000001
    5806:      	movq	%rsi, 0x60(%rsp)
    580b:      	movq	%rsi, 0x68(%rsp)
    5810:      	testl	%edx, %edx
    5812:      	je	0x5cf5 <generic_rawtp_process_filter+0x1a75>
    5818:      	movq	0x38(%rsp), %rdx
    581d:      	leaq	0x24(%rdx), %rsi
    5821:      	testb	$0x1, %dil
    5825:      	movq	%rsi, 0xb0(%rsp)
    582d:      	movq	%rsi, %r8
    5830:      	cmoveq	%rdx, %r8
    5834:      	addq	$0x10, %rdx
    5838:      	movq	%rdx, 0xd0(%rsp)
    5840:      	leal	(%rax,%r13,4), %r9d
    5844:      	addl	$0x4, %r9d
    5848:      	andl	$0x3ff, %r9d            # imm = 0x3FF
    584f:      	addq	$0x14, %r9
    5853:      	decq	%rcx
    5856:      	cmpq	$0x3, %rcx
    585a:      	movl	$0x3, %eax
    585f:      	cmovbq	%rcx, %rax
    5863:      	movl	%eax, %eax
    5865:      	leaq	0x4(,%rax,4), %r11
    586d:      	xorl	%r13d, %r13d
    5870:      	movq	%rdi, 0x30(%rsp)
    5875:      	movq	%r8, 0x28(%rsp)
    587a:      	movq	%r9, 0x20(%rsp)
    587f:      	movq	%r11, 0x18(%rsp)
    5884:      	jmp	0x58c0 <generic_rawtp_process_filter+0x1640>
    5886:      	movq	0x8(%rsp), %r10
    588b:      	movq	0x30(%rsp), %rdi
    5890:      	movq	0x28(%rsp), %r8
    5895:      	movq	0x20(%rsp), %r9
    589a:      	movq	0x18(%rsp), %r11
    589f:      	cmpl	$0x6, %r12d
    58a3:      	setne	%al
    58a6:      	xorb	$0x1, %bl
    58a9:      	orb	%al, %bl
    58ab:      	movzbl	%bl, %eax
    58ae:      	movl	%eax, 0x60(%rsp,%r13)
    58b3:      	addq	$0x4, %r13
    58b7:      	cmpq	%r13, %r11
    58ba:      	je	0x5cf5 <generic_rawtp_process_filter+0x1a75>
    58c0:      	leaq	(%r9,%r13), %rax
    58c4:      	movl	(%r8), %ecx
    58c7:      	cmpq	$0x3e8, %rax            # imm = 0x3E8
    58cd:      	jbe	0x5ada <generic_rawtp_process_filter+0x185a>
    58d3:      	xorl	%r15d, %r15d
    58d6:      	testb	$0x2, %dil
    58da:      	je	0x5af7 <generic_rawtp_process_filter+0x1877>
    58e0:      	testb	$0x1, %dil
    58e4:      	jne	0x5b18 <generic_rawtp_process_filter+0x1898>
    58ea:      	movq	0x38(%rsp), %rcx
    58ef:      	movl	(%rcx), %eax
    58f1:      	movb	$0x1, %bl
    58f3:      	cmpq	%rax, %r15
    58f6:      	je	0x589f <generic_rawtp_process_filter+0x161f>
    58f8:      	movl	0x10(%rcx), %eax
    58fb:      	cmpq	%rax, %r15
    58fe:      	je	0x589f <generic_rawtp_process_filter+0x161f>
    5900:      	movl	$0x1, %eax
    5905:      	movq	0xd0(%rsp), %rsi
    590d:      	movq	(%rip), %rdi            # 0x5914 <generic_rawtp_process_filter+0x1694>
    5914:      	callq	*%rax
    5916:      	testq	%rax, %rax
    5919:      	je	0x5cbd <generic_rawtp_process_filter+0x1a3d>
    591f:      	movq	%rax, %rsi
    5922:      	movl	(%rax), %eax
    5924:      	cmpq	%rax, %r15
    5927:      	je	0x5886 <generic_rawtp_process_filter+0x1606>
    592d:      	movl	0x10(%rsi), %eax
    5930:      	cmpq	%rax, %r15
    5933:      	je	0x5886 <generic_rawtp_process_filter+0x1606>
    5939:      	addq	$0x10, %rsi
    593d:      	movl	$0x1, %eax
    5942:      	movq	(%rip), %rdi            # 0x5949 <generic_rawtp_process_filter+0x16c9>
    5949:      	callq	*%rax
    594b:      	testq	%rax, %rax
    594e:      	je	0x5cbd <generic_rawtp_process_filter+0x1a3d>
    5954:      	movq	%rax, %rsi
    5957:      	movl	(%rax), %eax
    5959:      	cmpq	%rax, %r15
    595c:      	je	0x5886 <generic_rawtp_process_filter+0x1606>
    5962:      	movl	0x10(%rsi), %eax
    5965:      	cmpq	%rax, %r15
    5968:      	je	0x5886 <generic_rawtp_process_filter+0x1606>
    596e:      	addq	$0x10, %rsi
    5972:      	movl	$0x1, %eax
    5977:      	movq	(%rip), %rdi            # 0x597e <generic_rawtp_process_filter+0x16fe>
    597e:      	callq	*%rax
    5980:      	testq	%rax, %rax
    5983:      	je	0x5cbd <generic_rawtp_process_filter+0x1a3d>
    5989:      	movq	%rax, %rsi
    598c:      	movl	(%rax), %eax
    598e:      	cmpq	%rax, %r15
    5991:      	je	0x5886 <generic_rawtp_process_filter+0x1606>
    5997:      	movl	0x10(%rsi), %eax
    599a:      	cmpq	%rax, %r15
    599d:      	je	0x5886 <generic_rawtp_process_filter+0x1606>
    59a3:      	addq	$0x10, %rsi
    59a7:      	movl	$0x1, %eax
    59ac:      	movq	(%rip), %rdi            # 0x59b3 <generic_rawtp_process_filter+0x1733>
    59b3:      	callq	*%rax
    59b5:      	testq	%rax, %rax
    59b8:      	je	0x5cbd <generic_rawtp_process_filter+0x1a3d>
    59be:      	movq	%rax, %rsi
    59c1:      	movl	(%rax), %eax
    59c3:      	cmpq	%rax, %r15
    59c6:      	je	0x5886 <generic_rawtp_process_filter+0x1606>
    59cc:      	movl	0x10(%rsi), %eax
    59cf:      	cmpq	%rax, %r15
    59d2:      	je	0x5886 <generic_rawtp_process_filter+0x1606>
    59d8:      	addq	$0x10, %rsi
    59dc:      	movl	$0x1, %eax
    59e1:      	movq	(%rip), %rdi            # 0x59e8 <generic_rawtp_process_filter+0x1768>
    59e8:      	callq	*%rax
    59ea:      	testq	%rax, %rax
    59ed:      	je	0x5cbd <generic_rawtp_process_filter+0x1a3d>
    59f3:      	movq	%rax, %rsi
    59f6:      	movl	(%rax), %eax
    59f8:      	cmpq	%rax, %r15
    59fb:      	je	0x5886 <generic_rawtp_process_filter+0x1606>
    5a01:      	movl	0x10(%rsi), %eax
    5a04:      	cmpq	%rax, %r15
    5a07:      	je	0x5886 <generic_rawtp_process_filter+0x1606>
    5a0d:      	addq	$0x10, %rsi
    5a11:      	movl	$0x1, %eax
    5a16:      	movq	(%rip), %rdi            # 0x5a1d <generic_rawtp_process_filter+0x179d>
    5a1d:      	callq	*%rax
    5a1f:      	testq	%rax, %rax
    5a22:      	je	0x5cbd <generic_rawtp_process_filter+0x1a3d>
    5a28:      	movq	%rax, %rsi
    5a2b:      	movl	(%rax), %eax
    5a2d:      	cmpq	%rax, %r15
    5a30:      	je	0x5886 <generic_rawtp_process_filter+0x1606>
    5a36:      	movl	0x10(%rsi), %eax
    5a39:      	cmpq	%rax, %r15
    5a3c:      	je	0x5886 <generic_rawtp_process_filter+0x1606>
    5a42:      	addq	$0x10, %rsi
    5a46:      	movl	$0x1, %eax
    5a4b:      	movq	(%rip), %rdi            # 0x5a52 <generic_rawtp_process_filter+0x17d2>
    5a52:      	callq	*%rax
    5a54:      	testq	%rax, %rax
    5a57:      	je	0x5cbd <generic_rawtp_process_filter+0x1a3d>
    5a5d:      	movq	%rax, %rsi
    5a60:      	movl	(%rax), %eax
    5a62:      	cmpq	%rax, %r15
    5a65:      	je	0x5886 <generic_rawtp_process_filter+0x1606>
    5a6b:      	movl	0x10(%rsi), %eax
    5a6e:      	cmpq	%rax, %r15
    5a71:      	je	0x5886 <generic_rawtp_process_filter+0x1606>
    5a77:      	addq	$0x10, %rsi
    5a7b:      	movl	$0x1, %eax
    5a80:      	movq	(%rip), %rdi            # 0x5a87 <generic_rawtp_process_filter+0x1807>
    5a87:      	callq	*%rax
    5a89:      	testq	%rax, %rax
    5a8c:      	je	0x5cbd <generic_rawtp_process_filter+0x1a3d>
    5a92:      	movq	%rax, %rsi
    5a95:      	movl	(%rax), %eax
    5a97:      	cmpq	%rax, %r15
    5a9a:      	je	0x5886 <generic_rawtp_process_filter+0x1606>
    5aa0:      	movl	0x10(%rsi), %eax
    5aa3:      	cmpq	%rax, %r15
    5aa6:      	movq	0x8(%rsp), %r10
    5aab:      	movq	0x30(%rsp), %rdi
    5ab0:      	movq	0x28(%rsp), %r8
    5ab5:      	movq	0x20(%rsp), %r9
    5aba:      	movq	0x18(%rsp), %r11
    5abf:      	je	0x589f <generic_rawtp_process_filter+0x161f>
    5ac5:      	addq	$0x10, %rsi
    5ac9:      	movl	$0x1, %eax
    5ace:      	movq	(%rip), %rcx            # 0x5ad5 <generic_rawtp_process_filter+0x1855>
    5ad5:      	jmp	0x5cb4 <generic_rawtp_process_filter+0x1a34>
    5ada:      	movl	$0x4, %esi
    5adf:      	xorl	%edx, %edx
    5ae1:      	divq	%rsi
    5ae4:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5ae9:      	movl	(%r10,%rax,4), %r15d
    5aed:      	testb	$0x2, %dil
    5af1:      	jne	0x58e0 <generic_rawtp_process_filter+0x1660>
    5af7:      	cmpl	$0x5, %r12d
    5afb:      	jne	0x5b06 <generic_rawtp_process_filter+0x1886>
    5afd:      	cmpq	%rcx, %r15
    5b00:      	jne	0x5ce7 <generic_rawtp_process_filter+0x1a67>
    5b06:      	cmpq	%rcx, %r15
    5b09:      	setne	%al
    5b0c:      	cmpl	$0x6, %r12d
    5b10:      	setne	%bl
    5b13:      	jmp	0x58a9 <generic_rawtp_process_filter+0x1629>
    5b18:      	movq	0xb0(%rsp), %rax
    5b20:      	movl	(%rax), %eax
    5b22:      	testq	%rax, %rax
    5b25:      	je	0x5ce7 <generic_rawtp_process_filter+0x1a67>
    5b2b:      	movb	$0x1, %bl
    5b2d:      	testq	%r15, %r15
    5b30:      	je	0x589f <generic_rawtp_process_filter+0x161f>
    5b36:      	cmpq	%rax, %r15
    5b39:      	je	0x589f <generic_rawtp_process_filter+0x161f>
    5b3f:      	movl	$0x1, %eax
    5b44:      	movq	0xd0(%rsp), %rsi
    5b4c:      	movq	(%rip), %rdi            # 0x5b53 <generic_rawtp_process_filter+0x18d3>
    5b53:      	callq	*%rax
    5b55:      	testq	%rax, %rax
    5b58:      	je	0x5cbd <generic_rawtp_process_filter+0x1a3d>
    5b5e:      	movq	%rax, %rsi
    5b61:      	movl	0x24(%rax), %eax
    5b64:      	cmpq	%rax, %r15
    5b67:      	je	0x5886 <generic_rawtp_process_filter+0x1606>
    5b6d:      	addq	$0x10, %rsi
    5b71:      	movl	$0x1, %eax
    5b76:      	movq	(%rip), %rdi            # 0x5b7d <generic_rawtp_process_filter+0x18fd>
    5b7d:      	callq	*%rax
    5b7f:      	testq	%rax, %rax
    5b82:      	je	0x5cbd <generic_rawtp_process_filter+0x1a3d>
    5b88:      	movq	%rax, %rsi
    5b8b:      	movl	0x24(%rax), %eax
    5b8e:      	cmpq	%rax, %r15
    5b91:      	je	0x5886 <generic_rawtp_process_filter+0x1606>
    5b97:      	addq	$0x10, %rsi
    5b9b:      	movl	$0x1, %eax
    5ba0:      	movq	(%rip), %rdi            # 0x5ba7 <generic_rawtp_process_filter+0x1927>
    5ba7:      	callq	*%rax
    5ba9:      	testq	%rax, %rax
    5bac:      	je	0x5cbd <generic_rawtp_process_filter+0x1a3d>
    5bb2:      	movq	%rax, %rsi
    5bb5:      	movl	0x24(%rax), %eax
    5bb8:      	cmpq	%rax, %r15
    5bbb:      	je	0x5886 <generic_rawtp_process_filter+0x1606>
    5bc1:      	addq	$0x10, %rsi
    5bc5:      	movl	$0x1, %eax
    5bca:      	movq	(%rip), %rdi            # 0x5bd1 <generic_rawtp_process_filter+0x1951>
    5bd1:      	callq	*%rax
    5bd3:      	testq	%rax, %rax
    5bd6:      	je	0x5cbd <generic_rawtp_process_filter+0x1a3d>
    5bdc:      	movq	%rax, %rsi
    5bdf:      	movl	0x24(%rax), %eax
    5be2:      	cmpq	%rax, %r15
    5be5:      	je	0x5886 <generic_rawtp_process_filter+0x1606>
    5beb:      	addq	$0x10, %rsi
    5bef:      	movl	$0x1, %eax
    5bf4:      	movq	(%rip), %rdi            # 0x5bfb <generic_rawtp_process_filter+0x197b>
    5bfb:      	callq	*%rax
    5bfd:      	testq	%rax, %rax
    5c00:      	je	0x5cbd <generic_rawtp_process_filter+0x1a3d>
    5c06:      	movq	%rax, %rsi
    5c09:      	movl	0x24(%rax), %eax
    5c0c:      	cmpq	%rax, %r15
    5c0f:      	je	0x5886 <generic_rawtp_process_filter+0x1606>
    5c15:      	addq	$0x10, %rsi
    5c19:      	movl	$0x1, %eax
    5c1e:      	movq	(%rip), %rdi            # 0x5c25 <generic_rawtp_process_filter+0x19a5>
    5c25:      	callq	*%rax
    5c27:      	testq	%rax, %rax
    5c2a:      	je	0x5cbd <generic_rawtp_process_filter+0x1a3d>
    5c30:      	movq	%rax, %rsi
    5c33:      	movl	0x24(%rax), %eax
    5c36:      	cmpq	%rax, %r15
    5c39:      	je	0x5886 <generic_rawtp_process_filter+0x1606>
    5c3f:      	addq	$0x10, %rsi
    5c43:      	movl	$0x1, %eax
    5c48:      	movq	(%rip), %rdi            # 0x5c4f <generic_rawtp_process_filter+0x19cf>
    5c4f:      	callq	*%rax
    5c51:      	testq	%rax, %rax
    5c54:      	je	0x5cbd <generic_rawtp_process_filter+0x1a3d>
    5c56:      	movq	%rax, %rsi
    5c59:      	movl	0x24(%rax), %eax
    5c5c:      	cmpq	%rax, %r15
    5c5f:      	je	0x5886 <generic_rawtp_process_filter+0x1606>
    5c65:      	addq	$0x10, %rsi
    5c69:      	movl	$0x1, %eax
    5c6e:      	movq	(%rip), %rdi            # 0x5c75 <generic_rawtp_process_filter+0x19f5>
    5c75:      	callq	*%rax
    5c77:      	testq	%rax, %rax
    5c7a:      	je	0x5cbd <generic_rawtp_process_filter+0x1a3d>
    5c7c:      	movq	%rax, %rsi
    5c7f:      	movl	0x24(%rax), %eax
    5c82:      	cmpq	%rax, %r15
    5c85:      	movq	0x8(%rsp), %r10
    5c8a:      	movq	0x30(%rsp), %rdi
    5c8f:      	movq	0x28(%rsp), %r8
    5c94:      	movq	0x20(%rsp), %r9
    5c99:      	movq	0x18(%rsp), %r11
    5c9e:      	je	0x589f <generic_rawtp_process_filter+0x161f>
    5ca4:      	addq	$0x10, %rsi
    5ca8:      	movl	$0x1, %eax
    5cad:      	movq	(%rip), %rcx            # 0x5cb4 <generic_rawtp_process_filter+0x1a34>
    5cb4:      	movq	(%rip), %rdi            # 0x5cbb <generic_rawtp_process_filter+0x1a3b>
    5cbb:      	callq	*%rax
    5cbd:      	xorl	%ebx, %ebx
    5cbf:      	cmpl	$0x5, %r12d
    5cc3:      	movq	0x8(%rsp), %r10
    5cc8:      	movq	0x30(%rsp), %rdi
    5ccd:      	movq	0x28(%rsp), %r8
    5cd2:      	movq	0x20(%rsp), %r9
    5cd7:      	movq	0x18(%rsp), %r11
    5cdc:      	jne	0x589f <generic_rawtp_process_filter+0x161f>
    5ce2:      	jmp	0x58ab <generic_rawtp_process_filter+0x162b>
    5ce7:      	xorl	%ebx, %ebx
    5ce9:      	jmp	0x58ab <generic_rawtp_process_filter+0x162b>
    5cee:      	movl	$0x1, %eax
    5cf3:      	jmp	0x5d31 <generic_rawtp_process_filter+0x1ab1>
    5cf5:      	movl	0x60(%rsp), %esi
    5cf9:      	movl	0x64(%rsp), %ecx
    5cfd:      	movl	0x68(%rsp), %eax
    5d01:      	movl	0x6c(%rsp), %edx
    5d05:      	cmpl	$0x6, %r12d
    5d09:      	jne	0x5d13 <generic_rawtp_process_filter+0x1a93>
    5d0b:      	andl	%esi, %ecx
    5d0d:      	andl	%edx, %eax
    5d0f:      	andl	%ecx, %eax
    5d11:      	jmp	0x5d19 <generic_rawtp_process_filter+0x1a99>
    5d13:      	orl	%esi, %ecx
    5d15:      	orl	%edx, %eax
    5d17:      	orl	%ecx, %eax
    5d19:      	testl	%eax, %eax
    5d1b:      	je	0x684b <generic_rawtp_process_filter+0x25cb>
    5d21:      	addl	$0x14, %r14d
    5d25:      	movl	0x8(%r10,%rbp), %ecx
    5d2a:      	andl	$0x7, %ecx
    5d2d:      	leal	(%r14,%rcx,4), %ebp
    5d31:      	movq	0x50(%rsp), %r9
    5d36:      	movl	%ebp, %ecx
    5d38:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5d3e:      	movl	(%rcx,%r10), %ecx
    5d42:      	addl	$0x4, %ebp
    5d45:      	addl	$-0x4, %ecx
    5d48:      	xorl	%esi, %esi
    5d4a:      	movl	$0x4, %r8d
    5d50:      	jmp	0x5d6f <generic_rawtp_process_filter+0x1aef>
    5d52:      	nopw	%cs:(%rax,%rax)
    5d60:      	xorl	%ecx, %ecx
    5d62:      	incq	%rsi
    5d65:      	cmpq	$0xa, %rsi
    5d69:      	je	0x5ef8 <generic_rawtp_process_filter+0x1c78>
    5d6f:      	testl	%ecx, %ecx
    5d71:      	je	0x5d60 <generic_rawtp_process_filter+0x1ae0>
    5d73:      	movl	%ebp, %r9d
    5d76:      	andl	$0x3ff, %r9d            # imm = 0x3FF
    5d7d:      	movl	(%r9,%r10), %r11d
    5d81:      	movq	%r10, %rax
    5d84:      	movl	0x4(%r9,%r10), %r10d
    5d89:      	movl	0x8(%r9,%rax), %edx
    5d8e:      	movq	$0x0, 0x68(%rsp)
    5d97:      	movq	$0x0, 0x60(%rsp)
    5da0:      	cmpl	$0x4, %edx
    5da3:      	movl	$0x4, %eax
    5da8:      	cmovbl	%edx, %eax
    5dab:      	cmpl	$0x6, %r10d
    5daf:      	jne	0x5dc5 <generic_rawtp_process_filter+0x1b45>
    5db1:      	movabsq	$0x100000001, %rdi      # imm = 0x100000001
    5dbb:      	movq	%rdi, 0x60(%rsp)
    5dc0:      	movq	%rdi, 0x68(%rsp)
    5dc5:      	addl	$0xc, %ebp
    5dc8:      	testl	%edx, %edx
    5dca:      	je	0x5ea0 <generic_rawtp_process_filter+0x1c20>
    5dd0:      	andl	$0xf, %r11d
    5dd4:      	decq	%rax
    5dd7:      	cmpq	$0x3, %rax
    5ddb:      	movl	$0x3, %edx
    5de0:      	cmovaeq	%rdx, %rax
    5de4:      	leaq	0x4(,%rax,4), %rbx
    5dec:      	movl	%ebp, %r14d
    5def:      	cmpl	$0x9, %r11d
    5df3:      	jbe	0x5e2a <generic_rawtp_process_filter+0x1baa>
    5df5:      	xorl	%r11d, %r11d
    5df8:      	jmp	0x5e16 <generic_rawtp_process_filter+0x1b96>
    5dfa:      	nopw	(%rax,%rax)
    5e00:      	movl	$0x0, 0x60(%rsp,%r11)
    5e09:      	addq	$0x4, %r11
    5e0d:      	cmpq	%r11, %rbx
    5e10:      	je	0x5ea0 <generic_rawtp_process_filter+0x1c20>
    5e16:      	leaq	(%r14,%r11), %rax
    5e1a:      	cmpl	$0x3e8, %eax            # imm = 0x3E8
    5e1f:      	ja	0x5e00 <generic_rawtp_process_filter+0x1b80>
    5e21:      	movl	%eax, %eax
    5e23:      	xorl	%edx, %edx
    5e25:      	divq	%r8
    5e28:      	jmp	0x5e00 <generic_rawtp_process_filter+0x1b80>
    5e2a:      	xorl	%r15d, %r15d
    5e2d:      	jmp	0x5e71 <generic_rawtp_process_filter+0x1bf1>
    5e2f:      	nop
    5e30:      	cmpl	$0x5, %r10d
    5e34:      	setne	%dl
    5e37:      	movl	%r10d, %r13d
    5e3a:      	xorl	$0x6, %r13d
    5e3e:      	movq	0x50(%rsp), %rax
    5e43:      	movl	0x20(%rax,%r11,4), %edi
    5e48:      	movl	%r12d, %eax
    5e4b:      	xorl	%edi, %eax
    5e4d:      	cmpl	%edi, %r12d
    5e50:      	sete	%dil
    5e54:      	orb	%dl, %dil
    5e57:      	orl	%r13d, %eax
    5e5a:      	setne	%al
    5e5d:      	andb	%dil, %al
    5e60:      	movzbl	%al, %eax
    5e63:      	movl	%eax, 0x60(%rsp,%r15)
    5e68:      	addq	$0x4, %r15
    5e6c:      	cmpq	%r15, %rbx
    5e6f:      	je	0x5ea0 <generic_rawtp_process_filter+0x1c20>
    5e71:      	leaq	(%r14,%r15), %rdx
    5e75:      	xorl	%r12d, %r12d
    5e78:      	cmpl	$0x3e8, %edx            # imm = 0x3E8
    5e7e:      	ja	0x5e30 <generic_rawtp_process_filter+0x1bb0>
    5e80:      	movl	%edx, %eax
    5e82:      	xorl	%edx, %edx
    5e84:      	divq	%r8
    5e87:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5e8c:      	movq	0x8(%rsp), %rdx
    5e91:      	movl	(%rdx,%rax,4), %r12d
    5e95:      	jmp	0x5e30 <generic_rawtp_process_filter+0x1bb0>
    5e97:      	nopw	(%rax,%rax)
    5ea0:      	movl	0x60(%rsp), %ebx
    5ea4:      	movl	0x64(%rsp), %edx
    5ea8:      	movl	0x68(%rsp), %eax
    5eac:      	movl	0x6c(%rsp), %r11d
    5eb1:      	cmpl	$0x6, %r10d
    5eb5:      	jne	0x5ec0 <generic_rawtp_process_filter+0x1c40>
    5eb7:      	andl	%ebx, %edx
    5eb9:      	andl	%r11d, %eax
    5ebc:      	andl	%edx, %eax
    5ebe:      	jmp	0x5ec7 <generic_rawtp_process_filter+0x1c47>
    5ec0:      	orl	%ebx, %edx
    5ec2:      	orl	%r11d, %eax
    5ec5:      	orl	%edx, %eax
    5ec7:      	movq	0x8(%rsp), %r10
    5ecc:      	testl	%eax, %eax
    5ece:      	je	0x684b <generic_rawtp_process_filter+0x25cb>
    5ed4:      	movl	0x8(%r10,%r9), %edx
    5ed9:      	shll	$0x2, %edx
    5edc:      	subl	%edx, %ecx
    5ede:      	andl	$0x1c, %edx
    5ee1:      	addl	%edx, %ebp
    5ee3:      	addl	$-0xc, %ecx
    5ee6:      	movq	0x50(%rsp), %r9
    5eeb:      	incq	%rsi
    5eee:      	cmpq	$0xa, %rsi
    5ef2:      	jne	0x5d6f <generic_rawtp_process_filter+0x1aef>
    5ef8:      	movl	%ebp, %ecx
    5efa:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5f00:      	leal	0x4(%rbp), %ebx
    5f03:      	cmpl	$0x4, (%rcx,%r10)
    5f08:      	je	0x60d8 <generic_rawtp_process_filter+0x1e58>
    5f0e:      	andl	$0x3ff, %ebx            # imm = 0x3FF
    5f14:      	movl	(%rbx,%r10), %ecx
    5f18:      	movl	0x4(%rbx,%r10), %edx
    5f1d:      	movl	0x8(%rbx,%r10), %edi
    5f22:      	movq	0xc(%rbx,%r10), %rax
    5f27:      	testl	%edi, %edi
    5f29:      	je	0x60ac <generic_rawtp_process_filter+0x1e2c>
    5f2f:      	xorl	%esi, %esi
    5f31:      	cmpl	$0x2, %ecx
    5f34:      	ja	0x60cf <generic_rawtp_process_filter+0x1e4f>
    5f3a:      	cmpl	%edi, 0x44(%r9)
    5f3e:      	jne	0x60b5 <generic_rawtp_process_filter+0x1e35>
    5f44:      	jmp	0x60cf <generic_rawtp_process_filter+0x1e4f>
    5f49:      	movq	%rbx, %rsi
    5f4c:      	addq	$0x4, %rsi
    5f50:      	movq	(%rip), %rdi            # 0x5f57 <generic_rawtp_process_filter+0x1cd7>
    5f57:      	movl	$0x1, %eax
    5f5c:      	callq	*%rax
    5f5e:      	testq	%rax, %rax
    5f61:      	je	0x684b <generic_rawtp_process_filter+0x25cb>
    5f67:      	movq	%rax, %r14
    5f6a:      	movq	(%rip), %rdi            # 0x5f71 <generic_rawtp_process_filter+0x1cf1>
    5f71:      	leaq	0x58(%rsp), %rsi
    5f76:      	movl	$0x1, %eax
    5f7b:      	callq	*%rax
    5f7d:      	testq	%rax, %rax
    5f80:      	je	0x684b <generic_rawtp_process_filter+0x25cb>
    5f86:      	movq	%rax, %rbp
    5f89:      	movl	$0x104, %edx            # imm = 0x104
    5f8e:      	movq	%rax, %rdi
    5f91:      	xorl	%esi, %esi
    5f93:      	callq	0x5f98 <generic_rawtp_process_filter+0x1d18>
    5f98:      	movq	0x38(%rsp), %rsi
    5f9d:      	movl	0x68(%rsi), %eax
    5fa0:      	leal	(,%rax,8), %ecx
    5fa7:      	movl	%ecx, (%rbp)
    5faa:      	movq	%rbp, %rdi
    5fad:      	addq	$0x4, %rdi
    5fb1:      	movzbl	%al, %ecx
    5fb4:      	leaq	0x70(%rsi), %rdx
    5fb8:      	movl	$0x4, %eax
    5fbd:      	movzbl	0x68(%rsi), %esi
    5fc1:      	callq	*%rax
    5fc3:      	testq	%rax, %rax
    5fc6:      	js	0x684b <generic_rawtp_process_filter+0x25cb>
    5fcc:      	movl	$0x1, %eax
    5fd1:      	movq	%r14, %rdi
    5fd4:      	movq	%rbp, %rsi
    5fd7:      	jmp	0x63d7 <generic_rawtp_process_filter+0x2157>
    5fdc:      	movl	$0x0, 0x40(%rsp)
    5fe4:      	movq	(%rip), %rdi            # 0x5feb <generic_rawtp_process_filter+0x1d6b>
    5feb:      	leaq	0x40(%rsp), %rsi
    5ff0:      	movl	$0x1, %eax
    5ff5:      	callq	*%rax
    5ff7:      	testq	%rax, %rax
    5ffa:      	movq	0x38(%rsp), %rdx
    5fff:      	je	0x6384 <generic_rawtp_process_filter+0x2104>
    6005:      	movq	(%rax), %rcx
    6008:      	cmpq	0x378(%rdx), %rcx
    600f:      	je	0x6384 <generic_rawtp_process_filter+0x2104>
    6015:      	movq	%rax, 0xb0(%rsp)
    601d:      	movq	(%rip), %rax            # 0x6024 <generic_rawtp_process_filter+0x1da4>
    6024:      	cmpb	$0x0, (%rax)
    6027:      	je	0x62fb <generic_rawtp_process_filter+0x207b>
    602d:      	movl	$0x1869f, %r15d         # imm = 0x1869F
    6033:      	xorl	%r14d, %r14d
    6036:      	movq	(%rip), %r12            # 0x603d <generic_rawtp_process_filter+0x1dbd>
    603d:      	movq	0x38(%rsp), %rax
    6042:      	movl	0x10(%rax), %eax
    6045:      	movl	%eax, 0x60(%rsp)
    6049:      	movl	$0x1, %eax
    604e:      	leaq	0x60(%rsp), %rsi
    6053:      	movq	%r12, %rdi
    6056:      	callq	*%rax
    6058:      	testq	%rax, %rax
    605b:      	je	0x636d <generic_rawtp_process_filter+0x20ed>
    6061:      	movq	%rax, %rbp
    6064:      	leaq	0x70(%rax), %rsi
    6068:      	movl	$0x1, %eax
    606d:      	movq	(%rip), %rdi            # 0x6074 <generic_rawtp_process_filter+0x1df4>
    6074:      	callq	*%rax
    6076:      	testq	%rax, %rax
    6079:      	je	0x6090 <generic_rawtp_process_filter+0x1e10>
    607b:      	movq	(%rax), %rax
    607e:      	testq	%rax, %rax
    6081:      	je	0x6090 <generic_rawtp_process_filter+0x1e10>
    6083:      	movq	0x38(%rsp), %rcx
    6088:      	lock
    6089:      	orq	%rax, 0x370(%rcx)
    6090:      	subl	$0x1, %r15d
    6094:      	setb	%al
    6097:      	cmpq	%r14, %rbp
    609a:      	je	0x636d <generic_rawtp_process_filter+0x20ed>
    60a0:      	movq	%rbp, %r14
    60a3:      	testb	%al, %al
    60a5:      	je	0x603d <generic_rawtp_process_filter+0x1dbd>
    60a7:      	jmp	0x636d <generic_rawtp_process_filter+0x20ed>
    60ac:      	cmpl	$0x2, %ecx
    60af:      	jbe	0x60b5 <generic_rawtp_process_filter+0x1e35>
    60b1:      	xorl	%esi, %esi
    60b3:      	jmp	0x60cf <generic_rawtp_process_filter+0x1e4f>
    60b5:      	andq	0x48(%r9,%rcx,8), %rax
    60ba:      	cmpl	$0x5, %edx
    60bd:      	jne	0x60c8 <generic_rawtp_process_filter+0x1e48>
    60bf:      	testq	%rax, %rax
    60c2:      	setne	%sil
    60c6:      	jmp	0x60cf <generic_rawtp_process_filter+0x1e4f>
    60c8:      	testq	%rax, %rax
    60cb:      	sete	%sil
    60cf:      	addl	$0x18, %ebp
    60d2:      	movzbl	%sil, %eax
    60d6:      	movl	%ebp, %ebx
    60d8:      	testl	%eax, %eax
    60da:      	je	0x684b <generic_rawtp_process_filter+0x25cb>
    60e0:      	movl	%ebx, %ecx
    60e2:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    60e8:      	leal	0x4(%rbx), %eax
    60eb:      	cmpl	$0x4, (%rcx,%r10)
    60f0:      	je	0x6753 <generic_rawtp_process_filter+0x24d3>
    60f6:      	andl	$0x3ff, %eax            # imm = 0x3FF
    60fb:      	movl	(%rax,%r10), %r14d
    60ff:      	movl	0x4(%rax,%r10), %ebp
    6104:      	movl	$0xe, %eax
    6109:      	callq	*%rax
    610b:      	shrq	$0x20, %rax
    610f:      	movl	%eax, 0x60(%rsp)
    6113:      	movq	(%rip), %rdi            # 0x611a <generic_rawtp_process_filter+0x1e9a>
    611a:      	leaq	0x60(%rsp), %rsi
    611f:      	movl	$0x1, %eax
    6124:      	callq	*%rax
    6126:      	movq	0x8(%rsp), %r10
    612b:      	testq	%rax, %rax
    612e:      	je	0x684b <generic_rawtp_process_filter+0x25cb>
    6134:      	cmpl	$0x5, %r14d
    6138:      	je	0x6176 <generic_rawtp_process_filter+0x1ef6>
    613a:      	cmpl	$0x6, %r14d
    613e:      	jne	0x684b <generic_rawtp_process_filter+0x25cb>
    6144:      	movq	0x50(%rsp), %rsi
    6149:      	movq	%rsi, %rcx
    614c:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    6153:      	testb	$0x1, %bpl
    6157:      	jne	0x6419 <generic_rawtp_process_filter+0x2199>
    615d:      	movl	0x28(%rax), %edx
    6160:      	testl	%edx, %edx
    6162:      	je	0x6412 <generic_rawtp_process_filter+0x2192>
    6168:      	cmpl	0x20(%rsi), %edx
    616b:      	je	0x6419 <generic_rawtp_process_filter+0x2199>
    6171:      	jmp	0x6747 <generic_rawtp_process_filter+0x24c7>
    6176:      	movq	0x50(%rsp), %rsi
    617b:      	movq	%rsi, %rcx
    617e:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    6185:      	testb	$0x1, %bpl
    6189:      	je	0x6437 <generic_rawtp_process_filter+0x21b7>
    618f:      	movl	0x28(%rax), %edx
    6192:      	testl	%edx, %edx
    6194:      	je	0x6430 <generic_rawtp_process_filter+0x21b0>
    619a:      	cmpl	0x20(%rsi), %edx
    619d:      	je	0x6437 <generic_rawtp_process_filter+0x21b7>
    61a3:      	jmp	0x6747 <generic_rawtp_process_filter+0x24c7>
    61a8:      	movq	%r12, %rsi
    61ab:      	addq	$0x4, %rsi
    61af:      	movq	(%rip), %rdi            # 0x61b6 <generic_rawtp_process_filter+0x1f36>
    61b6:      	movl	$0x1, %eax
    61bb:      	callq	*%rax
    61bd:      	testq	%rax, %rax
    61c0:      	je	0x684b <generic_rawtp_process_filter+0x25cb>
    61c6:      	movq	%rax, %r14
    61c9:      	movq	(%rip), %rdi            # 0x61d0 <generic_rawtp_process_filter+0x1f50>
    61d0:      	leaq	0x58(%rsp), %rsi
    61d5:      	movl	$0x1, %eax
    61da:      	callq	*%rax
    61dc:      	testq	%rax, %rax
    61df:      	je	0x684b <generic_rawtp_process_filter+0x25cb>
    61e5:      	movq	%rax, %rbx
    61e8:      	movl	$0x104, %edx            # imm = 0x104
    61ed:      	movq	%rax, %rdi
    61f0:      	xorl	%esi, %esi
    61f2:      	callq	0x61f7 <generic_rawtp_process_filter+0x1f77>
    61f7:      	movl	(%rbp), %eax
    61fa:      	leal	(,%rax,8), %ecx
    6201:      	movl	%ecx, (%rbx)
    6203:      	movq	%rbx, %rdi
    6206:      	addq	$0x4, %rdi
    620a:      	movzbl	%al, %ecx
    620d:      	movq	%rbp, %rdx
    6210:      	addq	$0x8, %rdx
    6214:      	movl	$0x4, %eax
    6219:      	movzbl	(%rbp), %esi
    621d:      	callq	*%rax
    621f:      	testq	%rax, %rax
    6222:      	js	0x684b <generic_rawtp_process_filter+0x25cb>
    6228:      	movl	$0x1, %eax
    622d:      	movq	%r14, %rdi
    6230:      	movq	%rbx, %rsi
    6233:      	jmp	0x65ad <generic_rawtp_process_filter+0x232d>
    6238:      	movl	$0x0, 0x40(%rsp)
    6240:      	movq	(%rip), %rdi            # 0x6247 <generic_rawtp_process_filter+0x1fc7>
    6247:      	leaq	0x40(%rsp), %rsi
    624c:      	movl	$0x1, %eax
    6251:      	callq	*%rax
    6253:      	testq	%rax, %rax
    6256:      	je	0x655a <generic_rawtp_process_filter+0x22da>
    625c:      	movq	(%rax), %rcx
    625f:      	cmpq	0x310(%rbp), %rcx
    6266:      	je	0x655a <generic_rawtp_process_filter+0x22da>
    626c:      	movq	%rax, 0xb0(%rsp)
    6274:      	movq	(%rip), %rax            # 0x627b <generic_rawtp_process_filter+0x1ffb>
    627b:      	cmpb	$0x0, (%rax)
    627e:      	je	0x64de <generic_rawtp_process_filter+0x225e>
    6284:      	movl	$0x1869f, %r15d         # imm = 0x1869F
    628a:      	xorl	%r14d, %r14d
    628d:      	movq	0x38(%rsp), %rax
    6292:      	movl	0x10(%rax), %eax
    6295:      	movl	%eax, 0x60(%rsp)
    6299:      	movl	$0x1, %eax
    629e:      	movq	(%rip), %rdi            # 0x62a5 <generic_rawtp_process_filter+0x2025>
    62a5:      	leaq	0x60(%rsp), %rsi
    62aa:      	callq	*%rax
    62ac:      	testq	%rax, %rax
    62af:      	je	0x6548 <generic_rawtp_process_filter+0x22c8>
    62b5:      	movq	%rax, %rbx
    62b8:      	leaq	0x70(%rax), %rsi
    62bc:      	movl	$0x1, %eax
    62c1:      	movq	(%rip), %rdi            # 0x62c8 <generic_rawtp_process_filter+0x2048>
    62c8:      	callq	*%rax
    62ca:      	testq	%rax, %rax
    62cd:      	je	0x62df <generic_rawtp_process_filter+0x205f>
    62cf:      	movq	(%rax), %rax
    62d2:      	testq	%rax, %rax
    62d5:      	je	0x62df <generic_rawtp_process_filter+0x205f>
    62d7:      	lock
    62d8:      	orq	%rax, 0x308(%rbp)
    62df:      	subl	$0x1, %r15d
    62e3:      	setb	%al
    62e6:      	cmpq	%r14, %rbx
    62e9:      	je	0x6548 <generic_rawtp_process_filter+0x22c8>
    62ef:      	movq	%rbx, %r14
    62f2:      	testb	%al, %al
    62f4:      	je	0x628d <generic_rawtp_process_filter+0x200d>
    62f6:      	jmp	0x6548 <generic_rawtp_process_filter+0x22c8>
    62fb:      	movl	$0x3ff, %r15d           # imm = 0x3FF
    6301:      	xorl	%r14d, %r14d
    6304:      	movq	(%rip), %r12            # 0x630b <generic_rawtp_process_filter+0x208b>
    630b:      	movq	0x38(%rsp), %rax
    6310:      	movl	0x10(%rax), %eax
    6313:      	movl	%eax, 0x60(%rsp)
    6317:      	movl	$0x1, %eax
    631c:      	leaq	0x60(%rsp), %rsi
    6321:      	movq	%r12, %rdi
    6324:      	callq	*%rax
    6326:      	testq	%rax, %rax
    6329:      	je	0x636d <generic_rawtp_process_filter+0x20ed>
    632b:      	movq	%rax, %rbp
    632e:      	leaq	0x70(%rax), %rsi
    6332:      	movl	$0x1, %eax
    6337:      	movq	(%rip), %rdi            # 0x633e <generic_rawtp_process_filter+0x20be>
    633e:      	callq	*%rax
    6340:      	testq	%rax, %rax
    6343:      	je	0x635a <generic_rawtp_process_filter+0x20da>
    6345:      	movq	(%rax), %rax
    6348:      	testq	%rax, %rax
    634b:      	je	0x635a <generic_rawtp_process_filter+0x20da>
    634d:      	movq	0x38(%rsp), %rcx
    6352:      	lock
    6353:      	orq	%rax, 0x370(%rcx)
    635a:      	subl	$0x1, %r15d
    635e:      	setb	%al
    6361:      	cmpq	%r14, %rbp
    6364:      	je	0x636d <generic_rawtp_process_filter+0x20ed>
    6366:      	movq	%rbp, %r14
    6369:      	testb	%al, %al
    636b:      	je	0x630b <generic_rawtp_process_filter+0x208b>
    636d:      	movq	0xb0(%rsp), %rax
    6375:      	movq	(%rax), %rax
    6378:      	movq	0x38(%rsp), %rdx
    637d:      	movq	%rax, 0x378(%rdx)
    6384:      	movl	0x8(%rbx), %eax
    6387:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    638c:      	cmpq	%rcx, %rax
    638f:      	je	0x63aa <generic_rawtp_process_filter+0x212a>
    6391:      	movq	0x370(%rdx), %rcx
    6398:      	btq	%rax, %rcx
    639c:      	jae	0x63aa <generic_rawtp_process_filter+0x212a>
    639e:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    63a8:      	jmp	0x63d9 <generic_rawtp_process_filter+0x2159>
    63aa:      	movq	(%rip), %rdi            # 0x63b1 <generic_rawtp_process_filter+0x2131>
    63b1:      	leaq	0x10(%rsp), %rsi
    63b6:      	movl	$0x1, %eax
    63bb:      	callq	*%rax
    63bd:      	testq	%rax, %rax
    63c0:      	je	0x684b <generic_rawtp_process_filter+0x25cb>
    63c6:      	movq	%rax, %rdi
    63c9:      	movq	0x38(%rsp), %rax
    63ce:      	leaq	0x70(%rax), %rsi
    63d2:      	movl	$0x1, %eax
    63d7:      	callq	*%rax
    63d9:      	movl	(%rbx), %ecx
    63db:      	cmpq	$0x25, %rcx
    63df:      	movq	0x8(%rsp), %r10
    63e4:      	ja	0x6404 <generic_rawtp_process_filter+0x2184>
    63e6:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    63f0:      	btq	%rcx, %rdx
    63f4:      	jae	0x6404 <generic_rawtp_process_filter+0x2184>
    63f6:      	testq	%rax, %rax
    63f9:      	jne	0x684b <generic_rawtp_process_filter+0x25cb>
    63ff:      	jmp	0x5549 <generic_rawtp_process_filter+0x12c9>
    6404:      	testq	%rax, %rax
    6407:      	jne	0x5549 <generic_rawtp_process_filter+0x12c9>
    640d:      	jmp	0x684b <generic_rawtp_process_filter+0x25cb>
    6412:      	movq	$0x1, (%rcx)
    6419:      	testb	$0x2, %bpl
    641d:      	jne	0x6455 <generic_rawtp_process_filter+0x21d5>
    641f:      	movl	0x2c(%rax), %edx
    6422:      	testl	%edx, %edx
    6424:      	je	0x644e <generic_rawtp_process_filter+0x21ce>
    6426:      	cmpl	0x24(%rsi), %edx
    6429:      	je	0x6455 <generic_rawtp_process_filter+0x21d5>
    642b:      	jmp	0x6747 <generic_rawtp_process_filter+0x24c7>
    6430:      	movq	$0x1, (%rcx)
    6437:      	testb	$0x2, %bpl
    643b:      	je	0x6473 <generic_rawtp_process_filter+0x21f3>
    643d:      	movl	0x2c(%rax), %edx
    6440:      	testl	%edx, %edx
    6442:      	je	0x646c <generic_rawtp_process_filter+0x21ec>
    6444:      	cmpl	0x24(%rsi), %edx
    6447:      	je	0x6473 <generic_rawtp_process_filter+0x21f3>
    6449:      	jmp	0x6747 <generic_rawtp_process_filter+0x24c7>
    644e:      	movq	$0x1, (%rcx)
    6455:      	testb	$0x4, %bpl
    6459:      	jne	0x6491 <generic_rawtp_process_filter+0x2211>
    645b:      	movl	0x30(%rax), %edx
    645e:      	testl	%edx, %edx
    6460:      	je	0x648a <generic_rawtp_process_filter+0x220a>
    6462:      	cmpl	0x28(%rsi), %edx
    6465:      	je	0x6491 <generic_rawtp_process_filter+0x2211>
    6467:      	jmp	0x6747 <generic_rawtp_process_filter+0x24c7>
    646c:      	movq	$0x1, (%rcx)
    6473:      	testb	$0x4, %bpl
    6477:      	je	0x64bb <generic_rawtp_process_filter+0x223b>
    6479:      	movl	0x30(%rax), %edx
    647c:      	testl	%edx, %edx
    647e:      	je	0x64b4 <generic_rawtp_process_filter+0x2234>
    6480:      	cmpl	0x28(%rsi), %edx
    6483:      	je	0x64bb <generic_rawtp_process_filter+0x223b>
    6485:      	jmp	0x6747 <generic_rawtp_process_filter+0x24c7>
    648a:      	movq	$0x1, (%rcx)
    6491:      	testb	$0x8, %bpl
    6495:      	jne	0x65f1 <generic_rawtp_process_filter+0x2371>
    649b:      	movl	0x34(%rax), %edx
    649e:      	testl	%edx, %edx
    64a0:      	je	0x65ea <generic_rawtp_process_filter+0x236a>
    64a6:      	cmpl	0x2c(%rsi), %edx
    64a9:      	je	0x65f1 <generic_rawtp_process_filter+0x2371>
    64af:      	jmp	0x6747 <generic_rawtp_process_filter+0x24c7>
    64b4:      	movq	$0x1, (%rcx)
    64bb:      	testb	$0x8, %bpl
    64bf:      	je	0x660f <generic_rawtp_process_filter+0x238f>
    64c5:      	movl	0x34(%rax), %edx
    64c8:      	testl	%edx, %edx
    64ca:      	je	0x6608 <generic_rawtp_process_filter+0x2388>
    64d0:      	cmpl	0x2c(%rsi), %edx
    64d3:      	je	0x660f <generic_rawtp_process_filter+0x238f>
    64d9:      	jmp	0x6747 <generic_rawtp_process_filter+0x24c7>
    64de:      	movl	$0x3ff, %r15d           # imm = 0x3FF
    64e4:      	xorl	%r14d, %r14d
    64e7:      	movq	0x38(%rsp), %rax
    64ec:      	movl	0x10(%rax), %eax
    64ef:      	movl	%eax, 0x60(%rsp)
    64f3:      	movl	$0x1, %eax
    64f8:      	movq	(%rip), %rdi            # 0x64ff <generic_rawtp_process_filter+0x227f>
    64ff:      	leaq	0x60(%rsp), %rsi
    6504:      	callq	*%rax
    6506:      	testq	%rax, %rax
    6509:      	je	0x6548 <generic_rawtp_process_filter+0x22c8>
    650b:      	movq	%rax, %rbx
    650e:      	leaq	0x70(%rax), %rsi
    6512:      	movl	$0x1, %eax
    6517:      	movq	(%rip), %rdi            # 0x651e <generic_rawtp_process_filter+0x229e>
    651e:      	callq	*%rax
    6520:      	testq	%rax, %rax
    6523:      	je	0x6535 <generic_rawtp_process_filter+0x22b5>
    6525:      	movq	(%rax), %rax
    6528:      	testq	%rax, %rax
    652b:      	je	0x6535 <generic_rawtp_process_filter+0x22b5>
    652d:      	lock
    652e:      	orq	%rax, 0x308(%rbp)
    6535:      	subl	$0x1, %r15d
    6539:      	setb	%al
    653c:      	cmpq	%r14, %rbx
    653f:      	je	0x6548 <generic_rawtp_process_filter+0x22c8>
    6541:      	movq	%rbx, %r14
    6544:      	testb	%al, %al
    6546:      	je	0x64e7 <generic_rawtp_process_filter+0x2267>
    6548:      	movq	0xb0(%rsp), %rax
    6550:      	movq	(%rax), %rax
    6553:      	movq	%rax, 0x310(%rbp)
    655a:      	movl	0x8(%r12), %eax
    655f:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    6564:      	cmpq	%rcx, %rax
    6567:      	je	0x6582 <generic_rawtp_process_filter+0x2302>
    6569:      	movq	0x308(%rbp), %rcx
    6570:      	btq	%rax, %rcx
    6574:      	jae	0x6582 <generic_rawtp_process_filter+0x2302>
    6576:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    6580:      	jmp	0x65af <generic_rawtp_process_filter+0x232f>
    6582:      	movq	(%rip), %rdi            # 0x6589 <generic_rawtp_process_filter+0x2309>
    6589:      	leaq	0x10(%rsp), %rsi
    658e:      	movl	$0x1, %eax
    6593:      	callq	*%rax
    6595:      	testq	%rax, %rax
    6598:      	je	0x684b <generic_rawtp_process_filter+0x25cb>
    659e:      	movq	%rax, %rdi
    65a1:      	addq	$0x8, %rbp
    65a5:      	movl	$0x1, %eax
    65aa:      	movq	%rbp, %rsi
    65ad:      	callq	*%rax
    65af:      	movl	(%r12), %ecx
    65b3:      	cmpq	$0x25, %rcx
    65b7:      	movq	0x8(%rsp), %r10
    65bc:      	ja	0x65dc <generic_rawtp_process_filter+0x235c>
    65be:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    65c8:      	btq	%rcx, %rdx
    65cc:      	jae	0x65dc <generic_rawtp_process_filter+0x235c>
    65ce:      	testq	%rax, %rax
    65d1:      	jne	0x684b <generic_rawtp_process_filter+0x25cb>
    65d7:      	jmp	0x5795 <generic_rawtp_process_filter+0x1515>
    65dc:      	testq	%rax, %rax
    65df:      	jne	0x5795 <generic_rawtp_process_filter+0x1515>
    65e5:      	jmp	0x684b <generic_rawtp_process_filter+0x25cb>
    65ea:      	movq	$0x1, (%rcx)
    65f1:      	testb	$0x10, %bpl
    65f5:      	jne	0x662d <generic_rawtp_process_filter+0x23ad>
    65f7:      	movl	0x38(%rax), %edx
    65fa:      	testl	%edx, %edx
    65fc:      	je	0x6626 <generic_rawtp_process_filter+0x23a6>
    65fe:      	cmpl	0x30(%rsi), %edx
    6601:      	je	0x662d <generic_rawtp_process_filter+0x23ad>
    6603:      	jmp	0x6747 <generic_rawtp_process_filter+0x24c7>
    6608:      	movq	$0x1, (%rcx)
    660f:      	testb	$0x10, %bpl
    6613:      	je	0x664b <generic_rawtp_process_filter+0x23cb>
    6615:      	movl	0x38(%rax), %edx
    6618:      	testl	%edx, %edx
    661a:      	je	0x6644 <generic_rawtp_process_filter+0x23c4>
    661c:      	cmpl	0x30(%rsi), %edx
    661f:      	je	0x664b <generic_rawtp_process_filter+0x23cb>
    6621:      	jmp	0x6747 <generic_rawtp_process_filter+0x24c7>
    6626:      	movq	$0x1, (%rcx)
    662d:      	testb	$0x20, %bpl
    6631:      	jne	0x6669 <generic_rawtp_process_filter+0x23e9>
    6633:      	movl	0x3c(%rax), %edx
    6636:      	testl	%edx, %edx
    6638:      	je	0x6662 <generic_rawtp_process_filter+0x23e2>
    663a:      	cmpl	0x34(%rsi), %edx
    663d:      	je	0x6669 <generic_rawtp_process_filter+0x23e9>
    663f:      	jmp	0x6747 <generic_rawtp_process_filter+0x24c7>
    6644:      	movq	$0x1, (%rcx)
    664b:      	testb	$0x20, %bpl
    664f:      	je	0x6687 <generic_rawtp_process_filter+0x2407>
    6651:      	movl	0x3c(%rax), %edx
    6654:      	testl	%edx, %edx
    6656:      	je	0x6680 <generic_rawtp_process_filter+0x2400>
    6658:      	cmpl	0x34(%rsi), %edx
    665b:      	je	0x6687 <generic_rawtp_process_filter+0x2407>
    665d:      	jmp	0x6747 <generic_rawtp_process_filter+0x24c7>
    6662:      	movq	$0x1, (%rcx)
    6669:      	testb	$0x40, %bpl
    666d:      	jne	0x66a5 <generic_rawtp_process_filter+0x2425>
    666f:      	movl	0x40(%rax), %edx
    6672:      	testl	%edx, %edx
    6674:      	je	0x669e <generic_rawtp_process_filter+0x241e>
    6676:      	cmpl	0x38(%rsi), %edx
    6679:      	je	0x66a5 <generic_rawtp_process_filter+0x2425>
    667b:      	jmp	0x6747 <generic_rawtp_process_filter+0x24c7>
    6680:      	movq	$0x1, (%rcx)
    6687:      	testb	$0x40, %bpl
    668b:      	je	0x66c2 <generic_rawtp_process_filter+0x2442>
    668d:      	movl	0x40(%rax), %edx
    6690:      	testl	%edx, %edx
    6692:      	je	0x66bb <generic_rawtp_process_filter+0x243b>
    6694:      	cmpl	0x38(%rsi), %edx
    6697:      	je	0x66c2 <generic_rawtp_process_filter+0x2442>
    6699:      	jmp	0x6747 <generic_rawtp_process_filter+0x24c7>
    669e:      	movq	$0x1, (%rcx)
    66a5:      	testb	%bpl, %bpl
    66a8:      	js	0x66dc <generic_rawtp_process_filter+0x245c>
    66aa:      	movl	0x44(%rax), %edx
    66ad:      	testl	%edx, %edx
    66af:      	je	0x66d5 <generic_rawtp_process_filter+0x2455>
    66b1:      	cmpl	0x3c(%rsi), %edx
    66b4:      	je	0x66dc <generic_rawtp_process_filter+0x245c>
    66b6:      	jmp	0x6747 <generic_rawtp_process_filter+0x24c7>
    66bb:      	movq	$0x1, (%rcx)
    66c2:      	testb	%bpl, %bpl
    66c5:      	jns	0x66f9 <generic_rawtp_process_filter+0x2479>
    66c7:      	movl	0x44(%rax), %edx
    66ca:      	testl	%edx, %edx
    66cc:      	je	0x66f2 <generic_rawtp_process_filter+0x2472>
    66ce:      	cmpl	0x3c(%rsi), %edx
    66d1:      	je	0x66f9 <generic_rawtp_process_filter+0x2479>
    66d3:      	jmp	0x6747 <generic_rawtp_process_filter+0x24c7>
    66d5:      	movq	$0x1, (%rcx)
    66dc:      	testl	$0x100, %ebp            # imm = 0x100
    66e2:      	jne	0x6722 <generic_rawtp_process_filter+0x24a2>
    66e4:      	movl	0x48(%rax), %edx
    66e7:      	testl	%edx, %edx
    66e9:      	je	0x671b <generic_rawtp_process_filter+0x249b>
    66eb:      	cmpl	0x40(%rsi), %edx
    66ee:      	je	0x6722 <generic_rawtp_process_filter+0x24a2>
    66f0:      	jmp	0x6747 <generic_rawtp_process_filter+0x24c7>
    66f2:      	movq	$0x1, (%rcx)
    66f9:      	testl	$0x100, %ebp            # imm = 0x100
    66ff:      	je	0x6831 <generic_rawtp_process_filter+0x25b1>
    6705:      	movl	0x48(%rax), %edx
    6708:      	testl	%edx, %edx
    670a:      	je	0x682a <generic_rawtp_process_filter+0x25aa>
    6710:      	cmpl	0x40(%rsi), %edx
    6713:      	je	0x6831 <generic_rawtp_process_filter+0x25b1>
    6719:      	jmp	0x6747 <generic_rawtp_process_filter+0x24c7>
    671b:      	movq	$0x1, (%rcx)
    6722:      	testl	$0x200, %ebp            # imm = 0x200
    6728:      	jne	0x684b <generic_rawtp_process_filter+0x25cb>
    672e:      	movl	0x4c(%rax), %eax
    6731:      	testl	%eax, %eax
    6733:      	je	0x6844 <generic_rawtp_process_filter+0x25c4>
    6739:      	movq	0x50(%rsp), %rdx
    673e:      	cmpl	0x44(%rdx), %eax
    6741:      	je	0x684b <generic_rawtp_process_filter+0x25cb>
    6747:      	addl	$0xc, %ebx
    674a:      	movq	$0x1, (%rcx)
    6751:      	movl	%ebx, %eax
    6753:      	movl	%eax, %ecx
    6755:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    675b:      	cmpl	$0x4, (%rcx,%r10)
    6760:      	movq	0x50(%rsp), %rcx
    6765:      	jne	0x678c <generic_rawtp_process_filter+0x250c>
    6767:      	movq	0x5eb8(%rcx), %rax
    676e:      	andl	$0x1f, %eax
    6771:      	movb	$0x1, 0x5ec1(%rcx,%rax)
    6779:      	movb	$0x1, 0x5ee0(%rcx)
    6780:      	movb	$0x1, 0x5ec0(%rcx)
    6787:      	jmp	0x684b <generic_rawtp_process_filter+0x25cb>
    678c:      	addl	$0x4, %eax
    678f:      	andl	$0x3ff, %eax            # imm = 0x3FF
    6794:      	movl	(%rax,%r10), %r14d
    6798:      	movl	0x4(%rax,%r10), %ebx
    679d:      	movl	0x8(%rax,%r10), %ebp
    67a2:      	movq	0xc(%rax,%r10), %r15
    67a7:      	movl	$0xe, %eax
    67ac:      	callq	*%rax
    67ae:      	shrq	$0x20, %rax
    67b2:      	movl	%eax, 0x60(%rsp)
    67b6:      	movq	(%rip), %rdi            # 0x67bd <generic_rawtp_process_filter+0x253d>
    67bd:      	leaq	0x60(%rsp), %rsi
    67c2:      	movl	$0x1, %eax
    67c7:      	callq	*%rax
    67c9:      	testq	%rax, %rax
    67cc:      	je	0x684b <generic_rawtp_process_filter+0x25cb>
    67ce:      	testl	%ebp, %ebp
    67d0:      	je	0x67e4 <generic_rawtp_process_filter+0x2564>
    67d2:      	cmpl	$0x2, %r14d
    67d6:      	ja	0x684b <generic_rawtp_process_filter+0x25cb>
    67d8:      	movq	0x50(%rsp), %rcx
    67dd:      	cmpl	%ebp, 0x44(%rcx)
    67e0:      	jne	0x67ea <generic_rawtp_process_filter+0x256a>
    67e2:      	jmp	0x684b <generic_rawtp_process_filter+0x25cb>
    67e4:      	cmpl	$0x2, %r14d
    67e8:      	ja	0x684b <generic_rawtp_process_filter+0x25cb>
    67ea:      	movq	0x50(%rax,%r14,8), %rax
    67ef:      	movq	0x50(%rsp), %rcx
    67f4:      	movq	0x48(%rcx,%r14,8), %rcx
    67f9:      	movq	%rcx, %rdx
    67fc:      	xorq	%rax, %rdx
    67ff:      	testq	%r15, %rdx
    6802:      	je	0x680b <generic_rawtp_process_filter+0x258b>
    6804:      	cmpl	$0x5, %ebx
    6807:      	jne	0x684b <generic_rawtp_process_filter+0x25cb>
    6809:      	jmp	0x6815 <generic_rawtp_process_filter+0x2595>
    680b:      	cmpq	%rcx, %rax
    680e:      	je	0x684b <generic_rawtp_process_filter+0x25cb>
    6810:      	cmpl	$0x6, %ebx
    6813:      	jne	0x684b <generic_rawtp_process_filter+0x25cb>
    6815:      	movq	0x50(%rsp), %rcx
    681a:      	movq	$0x1, 0x5ef0(%rcx)
    6825:      	jmp	0x6767 <generic_rawtp_process_filter+0x24e7>
    682a:      	movq	$0x1, (%rcx)
    6831:      	testl	$0x200, %ebp            # imm = 0x200
    6837:      	je	0x684b <generic_rawtp_process_filter+0x25cb>
    6839:      	movl	0x4c(%rax), %eax
    683c:      	testl	%eax, %eax
    683e:      	jne	0x6739 <generic_rawtp_process_filter+0x24b9>
    6844:      	movq	$0x1, (%rcx)
    684b:      	movq	0x50(%rsp), %rcx
    6850:      	movq	0x5eb8(%rcx), %rax
    6857:      	incq	%rax
    685a:      	movq	%rax, 0x5eb8(%rcx)
    6861:      	cmpq	0xc0(%rsp), %rax
    6869:      	jbe	0x68b7 <generic_rawtp_process_filter+0x2637>
    686b:      	movq	0x38(%rsp), %rdx
    6870:      	movl	(%rdx), %eax
    6872:      	movl	%eax, 0x10(%rcx)
    6875:      	movq	0x8(%rdx), %rax
    6879:      	movq	%rax, 0x18(%rcx)
    687d:      	cmpb	$0x0, 0x5ec0(%rcx)
    6884:      	movq	0xb8(%rsp), %rbx
    688c:      	je	0x68a3 <generic_rawtp_process_filter+0x2623>
    688e:      	movq	(%rip), %rsi            # 0x6895 <generic_rawtp_process_filter+0x2615>
    6895:      	xorl	%ecx, %ecx
    6897:      	movl	$0xc, %eax
    689c:      	movq	%rbx, %rdi
    689f:      	xorl	%edx, %edx
    68a1:      	callq	*%rax
    68a3:      	xorl	%eax, %eax
    68a5:      	addq	$0xe8, %rsp
    68ac:      	popq	%rbx
    68ad:      	popq	%r12
    68af:      	popq	%r13
    68b1:      	popq	%r14
    68b3:      	popq	%r15
    68b5:      	popq	%rbp
    68b6:      	retq
    68b7:      	movq	(%rip), %rsi            # 0x68be <generic_rawtp_process_filter+0x263e>
    68be:      	movl	$0x2, %ecx
    68c3:      	movl	$0xc, %eax
    68c8:      	movq	0xb8(%rsp), %rdi
    68d0:      	movl	$0x2, %edx
    68d5:      	jmp	0x68a1 <generic_rawtp_process_filter+0x2621>
    68d7:      	nopw	(%rax,%rax)

00000000000068e0 <generic_rawtp_filter_arg>:
    68e0:      	pushq	%rbp
    68e1:      	pushq	%r15
    68e3:      	pushq	%r14
    68e5:      	pushq	%r13
    68e7:      	pushq	%r12
    68e9:      	pushq	%rbx
    68ea:      	subq	$0xb8, %rsp
    68f1:      	movq	%rdi, %r12
    68f4:      	movl	$0x0, 0xa4(%rsp)
    68ff:      	movq	(%rip), %rdi            # 0x6906 <generic_rawtp_filter_arg+0x26>
    6906:      	leaq	0xa4(%rsp), %rsi
    690e:      	movl	$0x1, %eax
    6913:      	callq	*%rax
    6915:      	testq	%rax, %rax
    6918:      	je	0x6ad2 <generic_rawtp_filter_arg+0x1f2>
    691e:      	movq	%rax, %r14
    6921:      	movl	0x5f00(%rax), %ebx
    6927:      	leaq	0x5ef8(%rax), %rsi
    692e:      	movq	(%rip), %rdi            # 0x6935 <generic_rawtp_filter_arg+0x55>
    6935:      	movl	$0x1, %eax
    693a:      	callq	*%rax
    693c:      	testq	%rax, %rax
    693f:      	je	0x6ab7 <generic_rawtp_filter_arg+0x1d7>
    6945:      	cmpb	$0x0, 0x5ee0(%r14)
    694d:      	je	0x6ab7 <generic_rawtp_filter_arg+0x1d7>
    6953:      	movq	%rax, %r15
    6956:      	movq	%r12, 0x98(%rsp)
    695e:      	movl	%ebx, %eax
    6960:      	andl	$0x7, %eax
    6963:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
    696c:      	je	0x69fd <generic_rawtp_filter_arg+0x11d>
    6972:      	movl	%eax, %eax
    6974:      	movl	0x4(%r15,%rax,4), %ecx
    6979:      	leaq	(%rcx,%rax,4), %rdx
    697d:      	addq	$0x4, %rdx
    6981:      	leaq	(%rcx,%rax,4), %rax
    6985:      	addq	$0x8, %rax
    6989:      	andl	$0x3ff, %eax            # imm = 0x3FF
    698e:      	movl	(%rax,%r15), %eax
    6992:      	addq	%rdx, %rax
    6995:      	addq	$0x4, %rax
    6999:      	movl	%eax, %ecx
    699b:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    69a1:      	movl	(%rcx,%r15), %ecx
    69a5:      	addq	%rax, %rcx
    69a8:      	movl	%ecx, %eax
    69aa:      	andl	$0x3ff, %eax            # imm = 0x3FF
    69af:      	movl	(%rax,%r15), %eax
    69b3:      	addq	%rcx, %rax
    69b6:      	movl	%eax, %ecx
    69b8:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    69be:      	movl	(%rcx,%r15), %ecx
    69c2:      	addq	%rax, %rcx
    69c5:      	movl	%ecx, %eax
    69c7:      	andl	$0x3ff, %eax            # imm = 0x3FF
    69cc:      	movl	(%rax,%r15), %r9d
    69d0:      	addq	%rcx, %r9
    69d3:      	movl	%r9d, %edi
    69d6:      	andl	$0x3ff, %edi            # imm = 0x3FF
    69dc:      	cmpl	$0x19, (%r15,%rdi)
    69e1:      	jae	0x6a59 <generic_rawtp_filter_arg+0x179>
    69e3:      	cmpq	$0x1, %rdi
    69e7:      	movq	0x98(%rsp), %r12
    69ef:      	je	0x6ab7 <generic_rawtp_filter_arg+0x1d7>
    69f5:      	testl	%edi, %edi
    69f7:      	jne	0x6a8d <generic_rawtp_filter_arg+0x1ad>
    69fd:      	cmpl	$0x1, %ebx
    6a00:      	jg	0x6a26 <generic_rawtp_filter_arg+0x146>
    6a02:      	cmpl	$-0x1, %ebx
    6a05:      	movq	0x98(%rsp), %rdi
    6a0d:      	je	0x6ae6 <generic_rawtp_filter_arg+0x206>
    6a13:      	testl	%ebx, %ebx
    6a15:      	je	0x6af2 <generic_rawtp_filter_arg+0x212>
    6a1b:      	cmpl	$0x1, %ebx
    6a1e:      	je	0x6b01 <generic_rawtp_filter_arg+0x221>
    6a24:      	jmp	0x6a49 <generic_rawtp_filter_arg+0x169>
    6a26:      	cmpl	$0x2, %ebx
    6a29:      	movq	0x98(%rsp), %rdi
    6a31:      	je	0x6b10 <generic_rawtp_filter_arg+0x230>
    6a37:      	cmpl	$0x3, %ebx
    6a3a:      	je	0x6b1f <generic_rawtp_filter_arg+0x23f>
    6a40:      	cmpl	$0x4, %ebx
    6a43:      	je	0x6b2e <generic_rawtp_filter_arg+0x24e>
    6a49:      	cmpl	$0x4, %ebx
    6a4c:      	jg	0x6b5c <generic_rawtp_filter_arg+0x27c>
    6a52:      	incl	%ebx
    6a54:      	jmp	0x6b3d <generic_rawtp_filter_arg+0x25d>
    6a59:      	leaq	(%r15,%rdi), %rax
    6a5d:      	movq	%rax, 0xb0(%rsp)
    6a65:      	xorl	%r11d, %r11d
    6a68:      	leaq	0x70(%rsp), %rax
    6a6d:      	movq	%rax, 0x28(%rsp)
    6a72:      	movq	%rbx, 0xa8(%rsp)
    6a7a:      	movq	%rdi, (%rsp)
    6a7e:      	movq	%r9, 0x8(%rsp)
    6a83:      	movq	%r15, 0x68(%rsp)
    6a88:      	jmp	0x6bce <generic_rawtp_filter_arg+0x2ee>
    6a8d:      	movl	%edi, 0x5f04(%r14)
    6a94:      	movq	(%rip), %rsi            # 0x6a9b <generic_rawtp_filter_arg+0x1bb>
    6a9b:      	movl	$0x4, %ecx
    6aa0:      	movl	$0xc, %eax
    6aa5:      	movq	0x98(%rsp), %r12
    6aad:      	movq	%r12, %rdi
    6ab0:      	movl	$0x4, %edx
    6ab5:      	callq	*%rax
    6ab7:      	movq	(%rip), %rsi            # 0x6abe <generic_rawtp_filter_arg+0x1de>
    6abe:      	movl	$0x5, %ecx
    6ac3:      	movl	$0xc, %eax
    6ac8:      	movq	%r12, %rdi
    6acb:      	movl	$0x5, %edx
    6ad0:      	callq	*%rax
    6ad2:      	xorl	%eax, %eax
    6ad4:      	addq	$0xb8, %rsp
    6adb:      	popq	%rbx
    6adc:      	popq	%r12
    6ade:      	popq	%r13
    6ae0:      	popq	%r14
    6ae2:      	popq	%r15
    6ae4:      	popq	%rbp
    6ae5:      	retq
    6ae6:      	xorl	%ebx, %ebx
    6ae8:      	cmpb	$0x0, 0x5ec1(%r14)
    6af0:      	jne	0x6b3d <generic_rawtp_filter_arg+0x25d>
    6af2:      	movl	$0x1, %ebx
    6af7:      	cmpb	$0x0, 0x5ec2(%r14)
    6aff:      	jne	0x6b3d <generic_rawtp_filter_arg+0x25d>
    6b01:      	movl	$0x2, %ebx
    6b06:      	cmpb	$0x0, 0x5ec3(%r14)
    6b0e:      	jne	0x6b3d <generic_rawtp_filter_arg+0x25d>
    6b10:      	movl	$0x3, %ebx
    6b15:      	cmpb	$0x0, 0x5ec4(%r14)
    6b1d:      	jne	0x6b3d <generic_rawtp_filter_arg+0x25d>
    6b1f:      	movl	$0x4, %ebx
    6b24:      	cmpb	$0x0, 0x5ec5(%r14)
    6b2c:      	jne	0x6b3d <generic_rawtp_filter_arg+0x25d>
    6b2e:      	movl	$0x5, %ebx
    6b33:      	cmpb	$0x0, 0x5ec6(%r14)
    6b3b:      	je	0x6b5c <generic_rawtp_filter_arg+0x27c>
    6b3d:      	movl	%ebx, 0x5f00(%r14)
    6b44:      	movq	(%rip), %rsi            # 0x6b4b <generic_rawtp_filter_arg+0x26b>
    6b4b:      	movl	$0x3, %ecx
    6b50:      	movl	$0xc, %eax
    6b55:      	movl	$0x3, %edx
    6b5a:      	callq	*%rax
    6b5c:      	movq	0x60(%r14), %rbx
    6b60:      	movl	$0xe, %eax
    6b65:      	callq	*%rax
    6b67:      	movq	%rbx, 0x38(%rsp)
    6b6c:      	movq	%rax, 0x40(%rsp)
    6b71:      	movq	(%rip), %rdi            # 0x6b78 <generic_rawtp_filter_arg+0x298>
    6b78:      	leaq	0x38(%rsp), %rsi
    6b7d:      	movl	$0x1, %eax
    6b82:      	callq	*%rax
    6b84:      	testq	%rax, %rax
    6b87:      	je	0x6ad2 <generic_rawtp_filter_arg+0x1f2>
    6b8d:      	movq	(%rip), %rdi            # 0x6b94 <generic_rawtp_filter_arg+0x2b4>
    6b94:      	leaq	0x38(%rsp), %rsi
    6b99:      	movl	$0x3, %eax
    6b9e:      	callq	*%rax
    6ba0:      	jmp	0x6ad2 <generic_rawtp_filter_arg+0x1f2>
    6ba5:      	xorl	%ebx, %ebx
    6ba7:      	cmpl	$0x3, %eax
    6baa:      	sete	%bl
    6bad:      	nopl	(%rax)
    6bb0:      	testq	%rbx, %rbx
    6bb3:      	movq	0xa8(%rsp), %rbx
    6bbb:      	je	0x69fd <generic_rawtp_filter_arg+0x11d>
    6bc1:      	incq	%r11
    6bc4:      	cmpq	$0x5, %r11
    6bc8:      	je	0x69e3 <generic_rawtp_filter_arg+0x103>
    6bce:      	movq	0xb0(%rsp), %rax
    6bd6:      	movl	0x4(%rax,%r11,4), %r13d
    6bdb:      	testl	$0x3ff, %r13d           # imm = 0x3FF
    6be2:      	je	0x69e3 <generic_rawtp_filter_arg+0x103>
    6be8:      	addl	%r9d, %r13d
    6beb:      	andl	$0x3ff, %r13d           # imm = 0x3FF
    6bf2:      	movl	0x4(%r15,%r13), %eax
    6bf7:      	cmpl	$0x23, %eax
    6bfa:      	je	0x69fd <generic_rawtp_filter_arg+0x11d>
    6c00:      	addq	%r15, %r13
    6c03:      	movl	(%r13), %ecx
    6c07:      	cmpq	$0x4, %rcx
    6c0b:      	ja	0x69fd <generic_rawtp_filter_arg+0x11d>
    6c11:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    6c1a:      	jne	0x69fd <generic_rawtp_filter_arg+0x11d>
    6c20:      	movq	0x5e78(%r14,%rcx,8), %rcx
    6c28:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    6c2e:      	leaq	(%r14,%rcx), %r12
    6c32:      	addq	$0x90, %r12
    6c39:      	movl	0xc(%r13), %ecx
    6c3d:      	cmpl	$0x1b, %ecx
    6c40:      	jle	0x6c5d <generic_rawtp_filter_arg+0x37d>
    6c42:      	cmpl	$0x25, %ecx
    6c45:      	jg	0x6c88 <generic_rawtp_filter_arg+0x3a8>
    6c47:      	leal	-0x1c(%rcx), %edx
    6c4a:      	cmpl	$0x9, %edx
    6c4d:      	jb	0x6cce <generic_rawtp_filter_arg+0x3ee>
    6c4f:      	cmpl	$0x25, %ecx
    6c52:      	je	0x6ee6 <generic_rawtp_filter_arg+0x606>
    6c58:      	jmp	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    6c5d:      	cmpl	$0x9, %ecx
    6c60:      	jle	0x6cae <generic_rawtp_filter_arg+0x3ce>
    6c62:      	leal	-0xa(%rcx), %edx
    6c65:      	cmpl	$0x4, %edx
    6c68:      	jb	0x6cce <generic_rawtp_filter_arg+0x3ee>
    6c6a:      	leal	-0xf(%rcx), %edx
    6c6d:      	cmpl	$0x2, %edx
    6c70:      	jb	0x6ee6 <generic_rawtp_filter_arg+0x606>
    6c76:      	cmpl	$0x11, %ecx
    6c79:      	jne	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    6c7f:      	addq	$0x4, %r12
    6c83:      	jmp	0x6ee6 <generic_rawtp_filter_arg+0x606>
    6c88:      	cmpl	$0x29, %ecx
    6c8b:      	jg	0x6e53 <generic_rawtp_filter_arg+0x573>
    6c91:      	leal	-0x26(%rcx), %edx
    6c94:      	cmpl	$0x2, %edx
    6c97:      	jb	0x6de9 <generic_rawtp_filter_arg+0x509>
    6c9d:      	leal	-0x28(%rcx), %edx
    6ca0:      	cmpl	$0x2, %edx
    6ca3:      	jb	0x6d94 <generic_rawtp_filter_arg+0x4b4>
    6ca9:      	jmp	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    6cae:      	cmpl	$0x4, %ecx
    6cb1:      	jg	0x6d81 <generic_rawtp_filter_arg+0x4a1>
    6cb7:      	cmpl	$0x1, %ecx
    6cba:      	je	0x6cce <generic_rawtp_filter_arg+0x3ee>
    6cbc:      	cmpl	$0x2, %ecx
    6cbf:      	je	0x74d3 <generic_rawtp_filter_arg+0xbf3>
    6cc5:      	cmpl	$0x4, %ecx
    6cc8:      	jne	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    6cce:      	cmpl	$0xb, %ecx
    6cd1:      	jle	0x6d5e <generic_rawtp_filter_arg+0x47e>
    6cd7:      	cmpl	$0x24, %ecx
    6cda:      	ja	0x700b <generic_rawtp_filter_arg+0x72b>
    6ce0:      	movl	%ecx, %edx
    6ce2:      	movabsq	$0x1e00000000, %rsi     # imm = 0x1E00000000
    6cec:      	btq	%rdx, %rsi
    6cf0:      	jb	0x6e27 <generic_rawtp_filter_arg+0x547>
    6cf6:      	movl	$0x60000000, %esi       # imm = 0x60000000
    6cfb:      	btq	%rdx, %rsi
    6cff:      	jb	0x72a5 <generic_rawtp_filter_arg+0x9c5>
    6d05:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    6d0f:      	btq	%rdx, %rsi
    6d13:      	jae	0x700b <generic_rawtp_filter_arg+0x72b>
    6d19:      	cmpl	$0x20, %eax
    6d1c:      	ja	0x69fd <generic_rawtp_filter_arg+0x11d>
    6d22:      	movl	%eax, %ecx
    6d24:      	movl	$0x101e, %edx           # imm = 0x101E
    6d29:      	btq	%rcx, %rdx
    6d2d:      	jae	0x79e9 <generic_rawtp_filter_arg+0x1109>
    6d33:      	movl	0x10(%r13), %ecx
    6d37:      	cmpl	$0x2, %eax
    6d3a:      	jle	0x7f13 <generic_rawtp_filter_arg+0x1633>
    6d40:      	leal	-0x3(%rax), %edx
    6d43:      	cmpl	$0x2, %edx
    6d46:      	jae	0x866e <generic_rawtp_filter_arg+0x1d8e>
    6d4c:      	movzbl	(%r12), %edx
    6d51:      	cmpl	%edx, %ecx
    6d53:      	je	0x6ba5 <generic_rawtp_filter_arg+0x2c5>
    6d59:      	jmp	0x87a6 <generic_rawtp_filter_arg+0x1ec6>
    6d5e:      	leal	-0xa(%rcx), %edx
    6d61:      	cmpl	$0x2, %edx
    6d64:      	jb	0x7553 <generic_rawtp_filter_arg+0xc73>
    6d6a:      	cmpl	$0x1, %ecx
    6d6d:      	je	0x7017 <generic_rawtp_filter_arg+0x737>
    6d73:      	cmpl	$0x4, %ecx
    6d76:      	je	0x7017 <generic_rawtp_filter_arg+0x737>
    6d7c:      	jmp	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    6d81:      	cmpl	$0x5, %ecx
    6d84:      	je	0x6d94 <generic_rawtp_filter_arg+0x4b4>
    6d86:      	cmpl	$0x6, %ecx
    6d89:      	je	0x6de9 <generic_rawtp_filter_arg+0x509>
    6d8b:      	cmpl	$0x7, %ecx
    6d8e:      	jne	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    6d94:      	movq	$0x0, 0x58(%rsp)
    6d9d:      	movq	$0x0, 0x50(%rsp)
    6da6:      	movq	$0x0, 0x48(%rsp)
    6daf:      	movq	$0x0, 0x40(%rsp)
    6db8:      	movq	$0x0, 0x38(%rsp)
    6dc1:      	cmpl	$0x27, %ecx
    6dc4:      	jg	0x7055 <generic_rawtp_filter_arg+0x775>
    6dca:      	cmpl	$0x5, %ecx
    6dcd:      	je	0x76b8 <generic_rawtp_filter_arg+0xdd8>
    6dd3:      	movq	%r12, %rdx
    6dd6:      	movl	$0x0, %ebx
    6ddb:      	cmpl	$0x7, %ecx
    6dde:      	je	0x76ba <generic_rawtp_filter_arg+0xdda>
    6de4:      	jmp	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    6de9:      	movl	(%r12), %ebp
    6ded:      	addq	$0x4, %r12
    6df1:      	movq	%r12, 0x18(%rsp)
    6df6:      	cmpl	$0x19, %eax
    6df9:      	jg	0x70d8 <generic_rawtp_filter_arg+0x7f8>
    6dff:      	leal	-0x3(%rax), %ecx
    6e02:      	cmpl	$0x2, %ecx
    6e05:      	jb	0x791b <generic_rawtp_filter_arg+0x103b>
    6e0b:      	cmpl	$0x8, %eax
    6e0e:      	je	0x7885 <generic_rawtp_filter_arg+0xfa5>
    6e14:      	movl	$0x0, %ebx
    6e19:      	cmpl	$0x9, %eax
    6e1c:      	je	0x70f8 <generic_rawtp_filter_arg+0x818>
    6e22:      	jmp	0x9f1b <generic_rawtp_filter_arg+0x363b>
    6e27:      	cmpl	$0x9, %eax
    6e2a:      	jle	0x74c2 <generic_rawtp_filter_arg+0xbe2>
    6e30:      	cmpl	$0x1d, %eax
    6e33:      	jg	0x783f <generic_rawtp_filter_arg+0xf5f>
    6e39:      	leal	-0xa(%rax), %edx
    6e3c:      	cmpl	$0x2, %edx
    6e3f:      	jb	0x75e0 <generic_rawtp_filter_arg+0xd00>
    6e45:      	cmpl	$0xc, %eax
    6e48:      	je	0x7569 <generic_rawtp_filter_arg+0xc89>
    6e4e:      	jmp	0x69fd <generic_rawtp_filter_arg+0x11d>
    6e53:      	cmpl	$0x2a, %ecx
    6e56:      	je	0x6ee6 <generic_rawtp_filter_arg+0x606>
    6e5c:      	cmpl	$0x2c, %ecx
    6e5f:      	jne	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    6e65:      	movq	%r12, %rcx
    6e68:      	leaq	0x4(%r12), %r8
    6e6d:      	movzbl	0x3(%r12), %ebp
    6e73:      	movzbl	%bpl, %esi
    6e77:      	cmpl	$0x19, %eax
    6e7a:      	jg	0x7c5c <generic_rawtp_filter_arg+0x137c>
    6e80:      	leal	-0x3(%rax), %ecx
    6e83:      	cmpl	$0x2, %ecx
    6e86:      	jae	0x8201 <generic_rawtp_filter_arg+0x1921>
    6e8c:      	movl	$0x0, 0x70(%rsp)
    6e94:      	movl	$0x100, %ebx            # imm = 0x100
    6e99:      	cmpb	$-0x70, %bpl
    6e9d:      	ja	0x7ee3 <generic_rawtp_filter_arg+0x1603>
    6ea3:      	testb	%bpl, %bpl
    6ea6:      	je	0x6eb8 <generic_rawtp_filter_arg+0x5d8>
    6ea8:      	movl	%esi, %eax
    6eaa:      	movl	$0x18, %ecx
    6eaf:      	cltd
    6eb0:      	idivl	%ecx
    6eb2:      	movl	%esi, %ebx
    6eb4:      	testl	%edx, %edx
    6eb6:      	je	0x6eda <generic_rawtp_filter_arg+0x5fa>
    6eb8:      	movl	%esi, %eax
    6eba:      	movl	$0x18, %ecx
    6ebf:      	cltd
    6ec0:      	idivl	%ecx
    6ec2:      	shll	$0x3, %eax
    6ec5:      	leal	(%rax,%rax,2), %eax
    6ec8:      	addl	$0x18, %eax
    6ecb:      	movzwl	%ax, %ebx
    6ece:      	cmpl	$0x90, %ebx
    6ed4:      	ja	0x7ee3 <generic_rawtp_filter_arg+0x1603>
    6eda:      	movl	%ebx, %eax
    6edc:      	cltd
    6edd:      	idivl	%ecx
    6edf:      	decl	%eax
    6ee1:      	jmp	0x8dc9 <generic_rawtp_filter_arg+0x24e9>
    6ee6:      	movl	(%r12), %ebp
    6eea:      	movl	%eax, %ecx
    6eec:      	andl	$-0x2, %ecx
    6eef:      	cmpl	$0x24, %ecx
    6ef2:      	je	0x6efc <generic_rawtp_filter_arg+0x61c>
    6ef4:      	testl	%ebp, %ebp
    6ef6:      	je	0x69fd <generic_rawtp_filter_arg+0x11d>
    6efc:      	cmpl	$0x25, %eax
    6eff:      	ja	0x722f <generic_rawtp_filter_arg+0x94f>
    6f05:      	movl	%eax, %ecx
    6f07:      	movl	$0x4000100, %edx        # imm = 0x4000100
    6f0c:      	btq	%rcx, %rdx
    6f10:      	jb	0x7420 <generic_rawtp_filter_arg+0xb40>
    6f16:      	movl	$0x8000200, %edx        # imm = 0x8000200
    6f1b:      	btq	%rcx, %rdx
    6f1f:      	jb	0x72ea <generic_rawtp_filter_arg+0xa0a>
    6f25:      	movabsq	$0x3000000000, %rdx     # imm = 0x3000000000
    6f2f:      	btq	%rcx, %rdx
    6f33:      	jae	0x722f <generic_rawtp_filter_arg+0x94f>
    6f39:      	movw	$0x0, 0x38(%rsp)
    6f40:      	cmpl	$0x1000, %ebp           # imm = 0x1000
    6f46:      	ja	0x96cc <generic_rawtp_filter_arg+0x2dec>
    6f4c:      	movq	%r11, 0x10(%rsp)
    6f51:      	leaq	(%r12,%rbp), %rcx
    6f55:      	addq	$0x8, %rcx
    6f59:      	movl	$0x4, %eax
    6f5e:      	leaq	0x38(%rsp), %rdi
    6f63:      	movl	$0x2, %edx
    6f68:      	movl	(%r12), %ecx
    6f6c:      	leaq	(%r12,%rcx), %rdx
    6f70:      	addq	$0x8, %rdx
    6f74:      	movl	$0x2, %esi
    6f79:      	callq	*%rax
    6f7b:      	movl	0x10(%r13), %ecx
    6f7f:      	testl	%ecx, %ecx
    6f81:      	je	0x9b73 <generic_rawtp_filter_arg+0x3293>
    6f87:      	movzwl	0x38(%rsp), %eax
    6f8c:      	andl	$0xf000, %eax           # imm = 0xF000
    6f91:      	movl	$0x1, %ebx
    6f96:      	cmpl	%eax, %ecx
    6f98:      	je	0x9b75 <generic_rawtp_filter_arg+0x3295>
    6f9e:      	movl	0x8(%r13), %ecx
    6fa2:      	cmpl	$0xd, %ecx
    6fa5:      	movq	(%rsp), %rdi
    6fa9:      	movq	0x8(%rsp), %r9
    6fae:      	movq	0x10(%rsp), %r11
    6fb3:      	jb	0x96cc <generic_rawtp_filter_arg+0x2dec>
    6fb9:      	movl	0x14(%r13), %edx
    6fbd:      	testl	%edx, %edx
    6fbf:      	je	0x96cc <generic_rawtp_filter_arg+0x2dec>
    6fc5:      	cmpl	%eax, %edx
    6fc7:      	je	0x9b83 <generic_rawtp_filter_arg+0x32a3>
    6fcd:      	cmpl	$0x11, %ecx
    6fd0:      	jb	0x96cc <generic_rawtp_filter_arg+0x2dec>
    6fd6:      	movl	0x18(%r13), %edx
    6fda:      	testl	%edx, %edx
    6fdc:      	je	0x96cc <generic_rawtp_filter_arg+0x2dec>
    6fe2:      	cmpl	%eax, %edx
    6fe4:      	je	0x9b83 <generic_rawtp_filter_arg+0x32a3>
    6fea:      	cmpl	$0x15, %ecx
    6fed:      	jb	0x9f4d <generic_rawtp_filter_arg+0x366d>
    6ff3:      	movl	0x1c(%r13), %ecx
    6ff7:      	testl	%ecx, %ecx
    6ff9:      	je	0x9f4d <generic_rawtp_filter_arg+0x366d>
    6fff:      	xorl	%ebx, %ebx
    7001:      	cmpl	%eax, %ecx
    7003:      	sete	%bl
    7006:      	jmp	0x9f4f <generic_rawtp_filter_arg+0x366f>
    700b:      	leal	-0xc(%rcx), %edx
    700e:      	cmpl	$0x2, %edx
    7011:      	jae	0x754a <generic_rawtp_filter_arg+0xc6a>
    7017:      	cmpl	$0x20, %eax
    701a:      	ja	0x69fd <generic_rawtp_filter_arg+0x11d>
    7020:      	movl	%eax, %edx
    7022:      	movl	$0x101e, %esi           # imm = 0x101E
    7027:      	btq	%rdx, %rsi
    702b:      	jae	0x7074 <generic_rawtp_filter_arg+0x794>
    702d:      	movl	0x10(%r13), %edx
    7031:      	cmpl	$0x2, %eax
    7034:      	jle	0x7512 <generic_rawtp_filter_arg+0xc32>
    703a:      	leal	-0x3(%rax), %esi
    703d:      	cmpl	$0x2, %esi
    7040:      	jae	0x79d1 <generic_rawtp_filter_arg+0x10f1>
    7046:      	cmpl	%edx, (%r12)
    704a:      	je	0x6ba5 <generic_rawtp_filter_arg+0x2c5>
    7050:      	jmp	0x8b07 <generic_rawtp_filter_arg+0x2227>
    7055:      	cmpl	$0x28, %ecx
    7058:      	je	0x768a <generic_rawtp_filter_arg+0xdaa>
    705e:      	movq	%r12, %rdx
    7061:      	movl	$0x0, %ebx
    7066:      	cmpl	$0x29, %ecx
    7069:      	je	0x76ba <generic_rawtp_filter_arg+0xdda>
    706f:      	jmp	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    7074:      	movl	$0xc00, %esi            # imm = 0xC00
    7079:      	btq	%rdx, %rsi
    707d:      	jb	0x7647 <generic_rawtp_filter_arg+0xd67>
    7083:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    708d:      	btq	%rdx, %rsi
    7091:      	jae	0x69fd <generic_rawtp_filter_arg+0x11d>
    7097:      	cmpl	$0x1f, %eax
    709a:      	jne	0x7c29 <generic_rawtp_filter_arg+0x1349>
    70a0:      	movl	0x10(%r13), %esi
    70a4:      	movl	0x14(%r13), %edx
    70a8:      	cmpl	$0xc, %ecx
    70ab:      	ja	0x8823 <generic_rawtp_filter_arg+0x1f43>
    70b1:      	movl	$0x1402, %eax           # imm = 0x1402
    70b6:      	btl	%ecx, %eax
    70b9:      	jae	0x8823 <generic_rawtp_filter_arg+0x1f43>
    70bf:      	movl	(%r12), %eax
    70c3:      	cmpl	%eax, %esi
    70c5:      	jg	0x8833 <generic_rawtp_filter_arg+0x1f53>
    70cb:      	cmpl	%edx, %eax
    70cd:      	jle	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    70d3:      	jmp	0x8833 <generic_rawtp_filter_arg+0x1f53>
    70d8:      	cmpl	$0x20, %eax
    70db:      	jg	0x773f <generic_rawtp_filter_arg+0xe5f>
    70e1:      	cmpl	$0x1a, %eax
    70e4:      	je	0x7885 <generic_rawtp_filter_arg+0xfa5>
    70ea:      	movl	$0x0, %ebx
    70ef:      	cmpl	$0x1b, %eax
    70f2:      	jne	0x9f1b <generic_rawtp_filter_arg+0x363b>
    70f8:      	movq	%r11, 0x10(%rsp)
    70fd:      	movl	0x10(%r13), %eax
    7101:      	movl	%eax, 0x38(%rsp)
    7105:      	movl	$0x0, 0x70(%rsp)
    710d:      	movl	$0x1, %eax
    7112:      	leaq	0x38(%rsp), %rsi
    7117:      	movq	(%rip), %rdi            # 0x711e <generic_rawtp_filter_arg+0x83e>
    711e:      	callq	*%rax
    7120:      	testl	%ebp, %ebp
    7122:      	je	0x9f0b <generic_rawtp_filter_arg+0x362b>
    7128:      	movq	%rax, %r12
    712b:      	movl	$0x0, %ebx
    7130:      	testq	%rax, %rax
    7133:      	je	0x9f0d <generic_rawtp_filter_arg+0x362d>
    7139:      	movl	$0x1, %eax
    713e:      	movq	0x28(%rsp), %rsi
    7143:      	movq	(%rip), %rdi            # 0x714a <generic_rawtp_filter_arg+0x86a>
    714a:      	callq	*%rax
    714c:      	testq	%rax, %rax
    714f:      	je	0x9f0b <generic_rawtp_filter_arg+0x362b>
    7155:      	movq	%rax, %rdi
    7158:      	movq	%r12, 0x20(%rsp)
    715d:      	cmpl	$0x7f, %ebp
    7160:      	movl	$0x7f, %eax
    7165:      	cmovbl	%ebp, %eax
    7168:      	shll	$0x3, %eax
    716b:      	movl	%eax, (%rdi)
    716d:      	movq	%rbp, %rax
    7170:      	negq	%rax
    7173:      	movl	$0x3, %ecx
    7178:      	subq	%rbp, %rcx
    717b:      	leal	-0x4(%rbp), %edx
    717e:      	movq	%rdi, 0x60(%rsp)
    7183:      	addq	$0x7, %rdi
    7187:      	movl	$0x2, %r8d
    718d:      	subq	%rbp, %r8
    7190:      	leal	-0x3(%rbp), %r9d
    7194:      	movl	$0x1, %r10d
    719a:      	subq	%rbp, %r10
    719d:      	leal	-0x2(%rbp), %r11d
    71a1:      	decl	%ebp
    71a3:      	xorl	%ebx, %ebx
    71a5:      	movq	0x18(%rsp), %rsi
    71aa:      	leal	(%rbx,%rbp), %r12d
    71ae:      	andl	$0xfff, %r12d           # imm = 0xFFF
    71b5:      	movzbl	(%rsi,%r12), %r12d
    71ba:      	movb	%r12b, -0x3(%rdi)
    71be:      	cmpq	%rbx, %r10
    71c1:      	je	0x721b <generic_rawtp_filter_arg+0x93b>
    71c3:      	leal	(%r11,%rbx), %r12d
    71c7:      	andl	$0xfff, %r12d           # imm = 0xFFF
    71ce:      	movzbl	(%rsi,%r12), %r12d
    71d3:      	movb	%r12b, -0x2(%rdi)
    71d7:      	cmpq	%rbx, %r8
    71da:      	je	0x721b <generic_rawtp_filter_arg+0x93b>
    71dc:      	leal	(%r9,%rbx), %r12d
    71e0:      	andl	$0xfff, %r12d           # imm = 0xFFF
    71e7:      	movzbl	(%rsi,%r12), %r12d
    71ec:      	movb	%r12b, -0x1(%rdi)
    71f0:      	cmpq	%rbx, %rcx
    71f3:      	je	0x721b <generic_rawtp_filter_arg+0x93b>
    71f5:      	cmpq	$-0x7c, %rbx
    71f9:      	je	0x721b <generic_rawtp_filter_arg+0x93b>
    71fb:      	leal	(%rdx,%rbx), %r12d
    71ff:      	andl	$0xfff, %r12d           # imm = 0xFFF
    7206:      	movzbl	(%rsi,%r12), %r12d
    720b:      	movb	%r12b, (%rdi)
    720e:      	addq	$-0x4, %rbx
    7212:      	addq	$0x4, %rdi
    7216:      	cmpq	%rbx, %rax
    7219:      	jne	0x71aa <generic_rawtp_filter_arg+0x8ca>
    721b:      	movl	$0x1, %eax
    7220:      	movq	0x20(%rsp), %rdi
    7225:      	movq	0x60(%rsp), %rsi
    722a:      	jmp	0x83c8 <generic_rawtp_filter_arg+0x1ae8>
    722f:      	addl	$-0x3, %eax
    7232:      	cmpl	$0x2, %eax
    7235:      	jae	0x96cc <generic_rawtp_filter_arg+0x2dec>
    723b:      	movl	$0x0, 0x70(%rsp)
    7243:      	cmpl	$0x1000, %ebp           # imm = 0x1000
    7249:      	ja	0x96cc <generic_rawtp_filter_arg+0x2dec>
    724f:      	movzwl	%bp, %eax
    7252:      	cmpl	$0x90, %eax
    7257:      	movq	%r11, 0x10(%rsp)
    725c:      	ja	0x8023 <generic_rawtp_filter_arg+0x1743>
    7262:      	testw	%bp, %bp
    7265:      	je	0x7277 <generic_rawtp_filter_arg+0x997>
    7267:      	movl	%ebp, %eax
    7269:      	movl	$0x18, %ecx
    726e:      	cltd
    726f:      	idivl	%ecx
    7271:      	movl	%ebp, %esi
    7273:      	testl	%edx, %edx
    7275:      	je	0x7299 <generic_rawtp_filter_arg+0x9b9>
    7277:      	movl	%ebp, %eax
    7279:      	movl	$0x18, %ecx
    727e:      	cltd
    727f:      	idivl	%ecx
    7281:      	shll	$0x3, %eax
    7284:      	leal	(%rax,%rax,2), %eax
    7287:      	addl	$0x18, %eax
    728a:      	movzwl	%ax, %esi
    728d:      	cmpl	$0x90, %esi
    7293:      	ja	0x805b <generic_rawtp_filter_arg+0x177b>
    7299:      	movl	%esi, %eax
    729b:      	cltd
    729c:      	idivl	%ecx
    729e:      	decl	%eax
    72a0:      	jmp	0x8c2f <generic_rawtp_filter_arg+0x234f>
    72a5:      	cmpl	$0x20, %eax
    72a8:      	ja	0x69fd <generic_rawtp_filter_arg+0x11d>
    72ae:      	movl	%eax, %ecx
    72b0:      	movl	$0x101e, %edx           # imm = 0x101E
    72b5:      	btq	%rcx, %rdx
    72b9:      	jae	0x7a1c <generic_rawtp_filter_arg+0x113c>
    72bf:      	movl	0x10(%r13), %ecx
    72c3:      	cmpl	$0x2, %eax
    72c6:      	jle	0x7f37 <generic_rawtp_filter_arg+0x1657>
    72cc:      	leal	-0x3(%rax), %edx
    72cf:      	cmpl	$0x2, %edx
    72d2:      	jae	0x8689 <generic_rawtp_filter_arg+0x1da9>
    72d8:      	movzwl	(%r12), %edx
    72dd:      	cmpl	%edx, %ecx
    72df:      	je	0x6ba5 <generic_rawtp_filter_arg+0x2c5>
    72e5:      	jmp	0x87eb <generic_rawtp_filter_arg+0x1f0b>
    72ea:      	movq	%r11, 0x10(%rsp)
    72ef:      	movl	0x10(%r13), %eax
    72f3:      	movl	%eax, 0x38(%rsp)
    72f7:      	movl	$0x0, 0x70(%rsp)
    72ff:      	movl	$0x1, %eax
    7304:      	leaq	0x38(%rsp), %rsi
    7309:      	movq	(%rip), %rdi            # 0x7310 <generic_rawtp_filter_arg+0xa30>
    7310:      	callq	*%rax
    7312:      	testl	%ebp, %ebp
    7314:      	je	0x9b73 <generic_rawtp_filter_arg+0x3293>
    731a:      	movl	$0x0, %ebx
    731f:      	testq	%rax, %rax
    7322:      	je	0x9b75 <generic_rawtp_filter_arg+0x3295>
    7328:      	movq	%rax, 0x18(%rsp)
    732d:      	movl	$0x1, %eax
    7332:      	movq	0x28(%rsp), %rsi
    7337:      	movq	(%rip), %rdi            # 0x733e <generic_rawtp_filter_arg+0xa5e>
    733e:      	callq	*%rax
    7340:      	testq	%rax, %rax
    7343:      	je	0x9b73 <generic_rawtp_filter_arg+0x3293>
    7349:      	movq	%rax, %rdi
    734c:      	cmpl	$0x7f, %ebp
    734f:      	movl	$0x7f, %eax
    7354:      	cmovbl	%ebp, %eax
    7357:      	shll	$0x3, %eax
    735a:      	movl	%eax, (%rdi)
    735c:      	movq	%rbp, %rax
    735f:      	negq	%rax
    7362:      	movl	$0x3, %ecx
    7367:      	subq	%rbp, %rcx
    736a:      	leal	-0x4(%rbp), %edx
    736d:      	movq	%rdi, 0x20(%rsp)
    7372:      	addq	$0x7, %rdi
    7376:      	movl	$0x2, %r8d
    737c:      	subq	%rbp, %r8
    737f:      	leal	-0x3(%rbp), %r9d
    7383:      	movl	$0x1, %r10d
    7389:      	subq	%rbp, %r10
    738c:      	leal	-0x2(%rbp), %r11d
    7390:      	decl	%ebp
    7392:      	xorl	%ebx, %ebx
    7394:      	movq	%r12, %rsi
    7397:      	leal	(%rbx,%rbp), %r12d
    739b:      	andl	$0xfff, %r12d           # imm = 0xFFF
    73a2:      	movzbl	0x4(%rsi,%r12), %r12d
    73a8:      	movb	%r12b, -0x3(%rdi)
    73ac:      	cmpq	%rbx, %r10
    73af:      	je	0x740c <generic_rawtp_filter_arg+0xb2c>
    73b1:      	leal	(%r11,%rbx), %r12d
    73b5:      	andl	$0xfff, %r12d           # imm = 0xFFF
    73bc:      	movzbl	0x4(%rsi,%r12), %r12d
    73c2:      	movb	%r12b, -0x2(%rdi)
    73c6:      	cmpq	%rbx, %r8
    73c9:      	je	0x740c <generic_rawtp_filter_arg+0xb2c>
    73cb:      	leal	(%r9,%rbx), %r12d
    73cf:      	andl	$0xfff, %r12d           # imm = 0xFFF
    73d6:      	movzbl	0x4(%rsi,%r12), %r12d
    73dc:      	movb	%r12b, -0x1(%rdi)
    73e0:      	cmpq	%rbx, %rcx
    73e3:      	je	0x740c <generic_rawtp_filter_arg+0xb2c>
    73e5:      	cmpq	$-0x7c, %rbx
    73e9:      	je	0x740c <generic_rawtp_filter_arg+0xb2c>
    73eb:      	leal	(%rdx,%rbx), %r12d
    73ef:      	andl	$0xfff, %r12d           # imm = 0xFFF
    73f6:      	movzbl	0x4(%rsi,%r12), %r12d
    73fc:      	movb	%r12b, (%rdi)
    73ff:      	addq	$-0x4, %rbx
    7403:      	addq	$0x4, %rdi
    7407:      	cmpq	%rbx, %rax
    740a:      	jne	0x7397 <generic_rawtp_filter_arg+0xab7>
    740c:      	movl	$0x1, %eax
    7411:      	movq	0x18(%rsp), %rdi
    7416:      	movq	0x20(%rsp), %rsi
    741b:      	jmp	0x9b67 <generic_rawtp_filter_arg+0x3287>
    7420:      	movq	%r11, 0x10(%rsp)
    7425:      	movl	0x10(%r13), %eax
    7429:      	movl	%eax, 0x38(%rsp)
    742d:      	movl	$0x0, 0x70(%rsp)
    7435:      	movl	$0x1, %eax
    743a:      	leaq	0x38(%rsp), %rsi
    743f:      	movq	(%rip), %rdi            # 0x7446 <generic_rawtp_filter_arg+0xb66>
    7446:      	callq	*%rax
    7448:      	testl	%ebp, %ebp
    744a:      	je	0x9b73 <generic_rawtp_filter_arg+0x3293>
    7450:      	movl	$0x0, %ebx
    7455:      	testq	%rax, %rax
    7458:      	je	0x9b75 <generic_rawtp_filter_arg+0x3295>
    745e:      	movq	%rax, 0x18(%rsp)
    7463:      	movl	$0x1, %eax
    7468:      	movq	0x28(%rsp), %rsi
    746d:      	movq	(%rip), %rdi            # 0x7474 <generic_rawtp_filter_arg+0xb94>
    7474:      	callq	*%rax
    7476:      	testq	%rax, %rax
    7479:      	je	0x9b73 <generic_rawtp_filter_arg+0x3293>
    747f:      	movq	%rax, %rbx
    7482:      	addq	$0x4, %r12
    7486:      	cmpl	$0xff, %ebp
    748c:      	movl	$0xff, %eax
    7491:      	cmovael	%eax, %ebp
    7494:      	leal	(,%rbp,8), %eax
    749b:      	movl	%eax, (%rbx)
    749d:      	movq	%rbx, %rdi
    74a0:      	addq	$0x4, %rdi
    74a4:      	movl	$0x4, %eax
    74a9:      	movl	%ebp, %esi
    74ab:      	movq	%r12, %rdx
    74ae:      	callq	*%rax
    74b0:      	movl	$0x1, %eax
    74b5:      	movq	0x18(%rsp), %rdi
    74ba:      	movq	%rbx, %rsi
    74bd:      	jmp	0x9b67 <generic_rawtp_filter_arg+0x3287>
    74c2:      	leal	-0x1(%rax), %edx
    74c5:      	cmpl	$0x4, %edx
    74c8:      	jb	0x7569 <generic_rawtp_filter_arg+0xc89>
    74ce:      	jmp	0x69fd <generic_rawtp_filter_arg+0x11d>
    74d3:      	movl	0x4(%r12), %ebp
    74d8:      	addq	$0x8, %r12
    74dc:      	movq	%r12, 0x18(%rsp)
    74e1:      	cmpl	$0x19, %eax
    74e4:      	jg	0x7ad2 <generic_rawtp_filter_arg+0x11f2>
    74ea:      	leal	-0x3(%rax), %ecx
    74ed:      	cmpl	$0x2, %ecx
    74f0:      	jb	0x83d7 <generic_rawtp_filter_arg+0x1af7>
    74f6:      	cmpl	$0x8, %eax
    74f9:      	je	0x8331 <generic_rawtp_filter_arg+0x1a51>
    74ff:      	movl	$0x0, %ebx
    7504:      	cmpl	$0x9, %eax
    7507:      	je	0x7af2 <generic_rawtp_filter_arg+0x1212>
    750d:      	jmp	0x9f1b <generic_rawtp_filter_arg+0x363b>
    7512:      	cmpl	$0x1, %eax
    7515:      	je	0x7dc4 <generic_rawtp_filter_arg+0x14e4>
    751b:      	cmpl	$0x2, %eax
    751e:      	jne	0x8b07 <generic_rawtp_filter_arg+0x2227>
    7524:      	cmpl	$0xc, %ecx
    7527:      	ja	0x8afd <generic_rawtp_filter_arg+0x221d>
    752d:      	movl	$0x1402, %esi           # imm = 0x1402
    7532:      	btl	%ecx, %esi
    7535:      	jae	0x8afd <generic_rawtp_filter_arg+0x221d>
    753b:      	cmpl	%edx, (%r12)
    753f:      	jl	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    7545:      	jmp	0x8b07 <generic_rawtp_filter_arg+0x2227>
    754a:      	cmpl	$0x1c, %ecx
    754d:      	jne	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    7553:      	cmpl	$0x20, %eax
    7556:      	ja	0x69fd <generic_rawtp_filter_arg+0x11d>
    755c:      	movl	%eax, %edx
    755e:      	movl	$0x101e, %esi           # imm = 0x101E
    7563:      	btq	%rdx, %rsi
    7567:      	jae	0x758d <generic_rawtp_filter_arg+0xcad>
    7569:      	movq	0x10(%r13), %rdx
    756d:      	cmpl	$0x2, %eax
    7570:      	jle	0x75b1 <generic_rawtp_filter_arg+0xcd1>
    7572:      	leal	-0x3(%rax), %esi
    7575:      	cmpl	$0x2, %esi
    7578:      	jae	0x7827 <generic_rawtp_filter_arg+0xf47>
    757e:      	cmpq	%rdx, (%r12)
    7582:      	je	0x6ba5 <generic_rawtp_filter_arg+0x2c5>
    7588:      	jmp	0x85f2 <generic_rawtp_filter_arg+0x1d12>
    758d:      	movl	$0xc00, %esi            # imm = 0xC00
    7592:      	btq	%rdx, %rsi
    7596:      	jb	0x75e0 <generic_rawtp_filter_arg+0xd00>
    7598:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    75a2:      	btq	%rdx, %rsi
    75a6:      	jb	0x784b <generic_rawtp_filter_arg+0xf6b>
    75ac:      	jmp	0x69fd <generic_rawtp_filter_arg+0x11d>
    75b1:      	cmpl	$0x1, %eax
    75b4:      	je	0x7ab5 <generic_rawtp_filter_arg+0x11d5>
    75ba:      	cmpl	$0x2, %eax
    75bd:      	jne	0x85f2 <generic_rawtp_filter_arg+0x1d12>
    75c3:      	cmpl	$0xc, %ecx
    75c6:      	je	0x75d1 <generic_rawtp_filter_arg+0xcf1>
    75c8:      	cmpl	$0xa, %ecx
    75cb:      	jne	0x85e8 <generic_rawtp_filter_arg+0x1d08>
    75d1:      	cmpq	%rdx, (%r12)
    75d5:      	jl	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    75db:      	jmp	0x85f2 <generic_rawtp_filter_arg+0x1d12>
    75e0:      	movq	%r11, %rbp
    75e3:      	movzbl	0x10(%r13), %eax
    75e8:      	movl	%eax, 0x70(%rsp)
    75ec:      	movl	$0x1, %eax
    75f1:      	movq	0x28(%rsp), %rsi
    75f6:      	movq	(%rip), %rdi            # 0x75fd <generic_rawtp_filter_arg+0xd1d>
    75fd:      	callq	*%rax
    75ff:      	testq	%rax, %rax
    7602:      	je	0x831e <generic_rawtp_filter_arg+0x1a3e>
    7608:      	movq	%rax, %rdi
    760b:      	movq	(%r12), %rax
    760f:      	movq	%rax, 0x38(%rsp)
    7614:      	movl	$0x1, %eax
    7619:      	leaq	0x38(%rsp), %rsi
    761e:      	callq	*%rax
    7620:      	movl	0x4(%r13), %ecx
    7624:      	cmpl	$0xb, %ecx
    7627:      	je	0x8009 <generic_rawtp_filter_arg+0x1729>
    762d:      	cmpl	$0xa, %ecx
    7630:      	movq	(%rsp), %rdi
    7634:      	movq	0x8(%rsp), %r9
    7639:      	movq	%rbp, %r11
    763c:      	je	0x810f <generic_rawtp_filter_arg+0x182f>
    7642:      	jmp	0x811d <generic_rawtp_filter_arg+0x183d>
    7647:      	movq	%r11, %rbp
    764a:      	movzbl	0x10(%r13), %eax
    764f:      	movl	%eax, 0x70(%rsp)
    7653:      	movl	$0x1, %eax
    7658:      	movq	0x28(%rsp), %rsi
    765d:      	movq	(%rip), %rdi            # 0x7664 <generic_rawtp_filter_arg+0xd84>
    7664:      	callq	*%rax
    7666:      	testq	%rax, %rax
    7669:      	je	0x831e <generic_rawtp_filter_arg+0x1a3e>
    766f:      	movq	%rax, %rdi
    7672:      	movl	(%r12), %eax
    7676:      	movq	%rax, 0x38(%rsp)
    767b:      	movl	$0x1, %eax
    7680:      	leaq	0x38(%rsp), %rsi
    7685:      	jmp	0x82e5 <generic_rawtp_filter_arg+0x1a05>
    768a:      	movzwl	(%r12), %edx
    768f:      	movw	%dx, 0x5e(%rsp)
    7694:      	movzwl	0x2(%r12), %edx
    769a:      	movw	%dx, 0x58(%rsp)
    769f:      	movq	0x8(%r12), %rdx
    76a4:      	movq	%rdx, 0x38(%rsp)
    76a9:      	movq	0x10(%r12), %rdx
    76ae:      	movq	%rdx, 0x40(%rsp)
    76b3:      	leaq	0x38(%rsp), %r12
    76b8:      	xorl	%edx, %edx
    76ba:      	cmpl	$0x13, %eax
    76bd:      	jle	0x76e6 <generic_rawtp_filter_arg+0xe06>
    76bf:      	cmpl	$0x17, %eax
    76c2:      	jg	0x771a <generic_rawtp_filter_arg+0xe3a>
    76c4:      	leal	-0x14(%rax), %ecx
    76c7:      	cmpl	$0x2, %ecx
    76ca:      	jb	0x7c99 <generic_rawtp_filter_arg+0x13b9>
    76d0:      	leal	-0x16(%rax), %ecx
    76d3:      	movl	$0x0, %ebx
    76d8:      	cmpl	$0x2, %ecx
    76db:      	jb	0x7c8e <generic_rawtp_filter_arg+0x13ae>
    76e1:      	jmp	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    76e6:      	cmpl	$0xf, %eax
    76e9:      	jle	0x7980 <generic_rawtp_filter_arg+0x10a0>
    76ef:      	cmpl	$0x11, %eax
    76f2:      	jg	0x7c7b <generic_rawtp_filter_arg+0x139b>
    76f8:      	cmpl	$0x10, %eax
    76fb:      	je	0x7c8e <generic_rawtp_filter_arg+0x13ae>
    7701:      	movl	$0x0, %ebx
    7706:      	cmpl	$0x11, %eax
    7709:      	jne	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    770f:      	movzwl	0x24(%r12), %ebx
    7715:      	jmp	0x8492 <generic_rawtp_filter_arg+0x1bb2>
    771a:      	cmpl	$0x1b, %eax
    771d:      	jg	0x7cda <generic_rawtp_filter_arg+0x13fa>
    7723:      	cmpl	$0x18, %eax
    7726:      	je	0x7d19 <generic_rawtp_filter_arg+0x1439>
    772c:      	movl	$0x0, %ebx
    7731:      	cmpl	$0x19, %eax
    7734:      	je	0x7d0a <generic_rawtp_filter_arg+0x142a>
    773a:      	jmp	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    773f:      	cmpl	$0x21, %eax
    7742:      	je	0x7dea <generic_rawtp_filter_arg+0x150a>
    7748:      	movl	$0x0, %ebx
    774d:      	cmpl	$0x22, %eax
    7750:      	jne	0x9f1b <generic_rawtp_filter_arg+0x363b>
    7756:      	xorl	%ebx, %ebx
    7758:      	xorl	%r12d, %r12d
    775b:      	movq	%r11, %r15
    775e:      	movl	0x10(%r13,%rbx,4), %eax
    7763:      	movl	%eax, 0x38(%rsp)
    7767:      	movl	$0x1, %eax
    776c:      	leaq	0x38(%rsp), %rsi
    7771:      	movq	(%rip), %rdi            # 0x7778 <generic_rawtp_filter_arg+0xe98>
    7778:      	callq	*%rax
    777a:      	testq	%rax, %rax
    777d:      	je	0x8a96 <generic_rawtp_filter_arg+0x21b6>
    7783:      	testl	%ebp, %ebp
    7785:      	movq	%r15, %r11
    7788:      	movq	0x68(%rsp), %r15
    778d:      	je	0x7804 <generic_rawtp_filter_arg+0xf24>
    778f:      	movq	0x18(%rsp), %rdx
    7794:      	xorl	%ecx, %ecx
    7796:      	jmp	0x77a3 <generic_rawtp_filter_arg+0xec3>
    7798:      	incq	%rcx
    779b:      	incq	%rdx
    779e:      	cmpq	%rbp, %rcx
    77a1:      	je	0x7804 <generic_rawtp_filter_arg+0xf24>
    77a3:      	xorl	%esi, %esi
    77a5:      	nopw	%cs:(%rax,%rax)
    77b0:      	leaq	(%rcx,%rsi), %rdi
    77b4:      	cmpq	%rbp, %rdi
    77b7:      	jae	0x7798 <generic_rawtp_filter_arg+0xeb8>
    77b9:      	movsbl	(%rax,%rsi), %edi
    77bd:      	testl	%edi, %edi
    77bf:      	je	0x77fc <generic_rawtp_filter_arg+0xf1c>
    77c1:      	movsbl	(%rdx,%rsi), %r9d
    77c6:      	leal	-0x41(%r9), %r10d
    77ca:      	movl	%r9d, %r8d
    77cd:      	orl	$0x20, %r8d
    77d1:      	cmpl	$0x1a, %r10d
    77d5:      	cmovael	%r9d, %r8d
    77d9:      	leal	-0x41(%rdi), %r10d
    77dd:      	movl	%edi, %r9d
    77e0:      	orl	$0x20, %r9d
    77e4:      	cmpl	$0x1a, %r10d
    77e8:      	cmovael	%edi, %r9d
    77ec:      	cmpq	$0x62, %rsi
    77f0:      	ja	0x7798 <generic_rawtp_filter_arg+0xeb8>
    77f2:      	incq	%rsi
    77f5:      	cmpl	%r9d, %r8d
    77f8:      	je	0x77b0 <generic_rawtp_filter_arg+0xed0>
    77fa:      	jmp	0x7798 <generic_rawtp_filter_arg+0xeb8>
    77fc:      	testl	%ecx, %ecx
    77fe:      	jns	0x8f6e <generic_rawtp_filter_arg+0x268e>
    7804:      	leal	0xc(%r12), %eax
    7809:      	cmpl	0x8(%r13), %eax
    780d:      	jae	0x7820 <generic_rawtp_filter_arg+0xf40>
    780f:      	addl	$0x4, %r12d
    7813:      	incq	%rbx
    7816:      	cmpq	$0x64, %rbx
    781a:      	jne	0x775b <generic_rawtp_filter_arg+0xe7b>
    7820:      	xorl	%ebx, %ebx
    7822:      	jmp	0x8f73 <generic_rawtp_filter_arg+0x2693>
    7827:      	cmpl	$0xc, %eax
    782a:      	jne	0x85f2 <generic_rawtp_filter_arg+0x1d12>
    7830:      	testq	%rdx, (%r12)
    7834:      	jne	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    783a:      	jmp	0x85f2 <generic_rawtp_filter_arg+0x1d12>
    783f:      	leal	-0x1f(%rax), %edx
    7842:      	cmpl	$0x2, %edx
    7845:      	jae	0x8127 <generic_rawtp_filter_arg+0x1847>
    784b:      	cmpl	$0x1f, %eax
    784e:      	jne	0x79a5 <generic_rawtp_filter_arg+0x10c5>
    7854:      	movq	0x10(%r13), %rsi
    7858:      	movq	0x18(%r13), %rdx
    785c:      	cmpl	$0xa, %ecx
    785f:      	je	0x786a <generic_rawtp_filter_arg+0xf8a>
    7861:      	cmpl	$0xc, %ecx
    7864:      	jne	0x83f2 <generic_rawtp_filter_arg+0x1b12>
    786a:      	movq	(%r12), %rax
    786e:      	cmpq	%rax, %rsi
    7871:      	jg	0x8404 <generic_rawtp_filter_arg+0x1b24>
    7877:      	cmpq	%rdx, %rax
    787a:      	jle	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    7880:      	jmp	0x8404 <generic_rawtp_filter_arg+0x1b24>
    7885:      	movq	%r11, 0x10(%rsp)
    788a:      	movl	0x10(%r13), %eax
    788e:      	movl	%eax, 0x38(%rsp)
    7892:      	movl	$0x0, 0x70(%rsp)
    789a:      	movl	$0x1, %eax
    789f:      	leaq	0x38(%rsp), %rsi
    78a4:      	movq	(%rip), %rdi            # 0x78ab <generic_rawtp_filter_arg+0xfcb>
    78ab:      	callq	*%rax
    78ad:      	testl	%ebp, %ebp
    78af:      	je	0x9f0b <generic_rawtp_filter_arg+0x362b>
    78b5:      	movq	%rax, %r12
    78b8:      	movl	$0x0, %ebx
    78bd:      	testq	%rax, %rax
    78c0:      	je	0x9f0d <generic_rawtp_filter_arg+0x362d>
    78c6:      	movl	$0x1, %eax
    78cb:      	movq	0x28(%rsp), %rsi
    78d0:      	movq	(%rip), %rdi            # 0x78d7 <generic_rawtp_filter_arg+0xff7>
    78d7:      	callq	*%rax
    78d9:      	testq	%rax, %rax
    78dc:      	je	0x9f0b <generic_rawtp_filter_arg+0x362b>
    78e2:      	cmpl	$0xff, %ebp
    78e8:      	movl	$0xff, %ecx
    78ed:      	cmovael	%ecx, %ebp
    78f0:      	leal	(,%rbp,8), %ecx
    78f7:      	movl	%ecx, (%rax)
    78f9:      	movq	%rax, %rdi
    78fc:      	addq	$0x4, %rdi
    7900:      	movq	%rax, %rbx
    7903:      	movl	$0x4, %eax
    7908:      	movq	0x18(%rsp), %rdx
    790d:      	movl	%ebp, %esi
    790f:      	callq	*%rax
    7911:      	movl	$0x1, %eax
    7916:      	jmp	0x83c2 <generic_rawtp_filter_arg+0x1ae2>
    791b:      	movl	$0x0, 0x70(%rsp)
    7923:      	cmpl	$0x1000, %ebp           # imm = 0x1000
    7929:      	ja	0x83eb <generic_rawtp_filter_arg+0x1b0b>
    792f:      	movzwl	%bp, %eax
    7932:      	cmpl	$0x90, %eax
    7937:      	ja	0x8574 <generic_rawtp_filter_arg+0x1c94>
    793d:      	testw	%bp, %bp
    7940:      	je	0x7952 <generic_rawtp_filter_arg+0x1072>
    7942:      	movl	%ebp, %eax
    7944:      	movl	$0x18, %ecx
    7949:      	cltd
    794a:      	idivl	%ecx
    794c:      	movl	%ebp, %esi
    794e:      	testl	%edx, %edx
    7950:      	je	0x7974 <generic_rawtp_filter_arg+0x1094>
    7952:      	movl	%ebp, %eax
    7954:      	movl	$0x18, %ecx
    7959:      	cltd
    795a:      	idivl	%ecx
    795c:      	shll	$0x3, %eax
    795f:      	leal	(%rax,%rax,2), %eax
    7962:      	addl	$0x18, %eax
    7965:      	movzwl	%ax, %esi
    7968:      	cmpl	$0x90, %esi
    796e:      	ja	0x85ac <generic_rawtp_filter_arg+0x1ccc>
    7974:      	movl	%esi, %eax
    7976:      	cltd
    7977:      	idivl	%ecx
    7979:      	decl	%eax
    797b:      	jmp	0x91bc <generic_rawtp_filter_arg+0x28dc>
    7980:      	cmpl	$0xd, %eax
    7983:      	je	0x7d19 <generic_rawtp_filter_arg+0x1439>
    7989:      	cmpl	$0xe, %eax
    798c:      	je	0x7d0a <generic_rawtp_filter_arg+0x142a>
    7992:      	movl	$0x0, %ebx
    7997:      	cmpl	$0xf, %eax
    799a:      	je	0x7c99 <generic_rawtp_filter_arg+0x13b9>
    79a0:      	jmp	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    79a5:      	movq	0x10(%r13), %rsi
    79a9:      	movq	0x18(%r13), %rax
    79ad:      	cmpl	$0xc, %ecx
    79b0:      	je	0x79bb <generic_rawtp_filter_arg+0x10db>
    79b2:      	cmpl	$0xa, %ecx
    79b5:      	jne	0x8442 <generic_rawtp_filter_arg+0x1b62>
    79bb:      	movq	(%r12), %rdx
    79bf:      	cmpq	%rdx, %rsi
    79c2:      	setle	%sil
    79c6:      	cmpq	%rax, %rdx
    79c9:      	setle	%al
    79cc:      	jmp	0x8453 <generic_rawtp_filter_arg+0x1b73>
    79d1:      	cmpl	$0xc, %eax
    79d4:      	jne	0x8b07 <generic_rawtp_filter_arg+0x2227>
    79da:      	testl	%edx, (%r12)
    79de:      	jne	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    79e4:      	jmp	0x8b07 <generic_rawtp_filter_arg+0x2227>
    79e9:      	movl	$0xc00, %edx            # imm = 0xC00
    79ee:      	btq	%rcx, %rdx
    79f2:      	jb	0x7f5b <generic_rawtp_filter_arg+0x167b>
    79f8:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    7a02:      	btq	%rcx, %rdx
    7a06:      	jae	0x69fd <generic_rawtp_filter_arg+0x11d>
    7a0c:      	cmpl	$0x1f, %eax
    7a0f:      	jne	0x86dd <generic_rawtp_filter_arg+0x1dfd>
    7a15:      	movzbl	(%r12), %eax
    7a1a:      	jmp	0x7a4d <generic_rawtp_filter_arg+0x116d>
    7a1c:      	movl	$0xc00, %edx            # imm = 0xC00
    7a21:      	btq	%rcx, %rdx
    7a25:      	jb	0x7f9f <generic_rawtp_filter_arg+0x16bf>
    7a2b:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    7a35:      	btq	%rcx, %rdx
    7a39:      	jae	0x69fd <generic_rawtp_filter_arg+0x11d>
    7a3f:      	cmpl	$0x1f, %eax
    7a42:      	jne	0x86e8 <generic_rawtp_filter_arg+0x1e08>
    7a48:      	movzwl	(%r12), %eax
    7a4d:      	cmpl	%eax, 0x10(%r13)
    7a51:      	ja	0x7a5d <generic_rawtp_filter_arg+0x117d>
    7a53:      	cmpl	%eax, 0x14(%r13)
    7a57:      	jae	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    7a5d:      	movl	0x8(%r13), %ecx
    7a61:      	cmpl	$0x11, %ecx
    7a64:      	jb	0x69fd <generic_rawtp_filter_arg+0x11d>
    7a6a:      	cmpl	%eax, 0x18(%r13)
    7a6e:      	ja	0x7a7a <generic_rawtp_filter_arg+0x119a>
    7a70:      	cmpl	%eax, 0x1c(%r13)
    7a74:      	jae	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    7a7a:      	cmpl	$0x19, %ecx
    7a7d:      	jb	0x69fd <generic_rawtp_filter_arg+0x11d>
    7a83:      	cmpl	%eax, 0x20(%r13)
    7a87:      	ja	0x7a93 <generic_rawtp_filter_arg+0x11b3>
    7a89:      	cmpl	%eax, 0x24(%r13)
    7a8d:      	jae	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    7a93:      	cmpl	$0x21, %ecx
    7a96:      	jb	0x69fd <generic_rawtp_filter_arg+0x11d>
    7a9c:      	cmpl	%eax, 0x28(%r13)
    7aa0:      	ja	0x69fd <generic_rawtp_filter_arg+0x11d>
    7aa6:      	cmpl	%eax, 0x2c(%r13)
    7aaa:      	jae	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    7ab0:      	jmp	0x69fd <generic_rawtp_filter_arg+0x11d>
    7ab5:      	cmpl	$0xc, %ecx
    7ab8:      	je	0x7ac3 <generic_rawtp_filter_arg+0x11e3>
    7aba:      	cmpl	$0xa, %ecx
    7abd:      	jne	0x85dc <generic_rawtp_filter_arg+0x1cfc>
    7ac3:      	cmpq	%rdx, (%r12)
    7ac7:      	jg	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    7acd:      	jmp	0x85f2 <generic_rawtp_filter_arg+0x1d12>
    7ad2:      	cmpl	$0x20, %eax
    7ad5:      	jg	0x816d <generic_rawtp_filter_arg+0x188d>
    7adb:      	cmpl	$0x1a, %eax
    7ade:      	je	0x8331 <generic_rawtp_filter_arg+0x1a51>
    7ae4:      	movl	$0x0, %ebx
    7ae9:      	cmpl	$0x1b, %eax
    7aec:      	jne	0x9f1b <generic_rawtp_filter_arg+0x363b>
    7af2:      	movq	%r11, 0x10(%rsp)
    7af7:      	movl	0x10(%r13), %eax
    7afb:      	movl	%eax, 0x38(%rsp)
    7aff:      	movl	$0x0, 0x70(%rsp)
    7b07:      	movl	$0x1, %eax
    7b0c:      	leaq	0x38(%rsp), %rsi
    7b11:      	movq	(%rip), %rdi            # 0x7b18 <generic_rawtp_filter_arg+0x1238>
    7b18:      	callq	*%rax
    7b1a:      	testl	%ebp, %ebp
    7b1c:      	je	0x9f0b <generic_rawtp_filter_arg+0x362b>
    7b22:      	movq	%rax, %r12
    7b25:      	movl	$0x0, %ebx
    7b2a:      	testq	%rax, %rax
    7b2d:      	je	0x9f0d <generic_rawtp_filter_arg+0x362d>
    7b33:      	movl	$0x1, %eax
    7b38:      	movq	0x28(%rsp), %rsi
    7b3d:      	movq	(%rip), %rdi            # 0x7b44 <generic_rawtp_filter_arg+0x1264>
    7b44:      	callq	*%rax
    7b46:      	testq	%rax, %rax
    7b49:      	je	0x9f0b <generic_rawtp_filter_arg+0x362b>
    7b4f:      	movq	%rax, %rdi
    7b52:      	movq	%r12, 0x20(%rsp)
    7b57:      	cmpl	$0x7f, %ebp
    7b5a:      	movl	$0x7f, %eax
    7b5f:      	cmovbl	%ebp, %eax
    7b62:      	shll	$0x3, %eax
    7b65:      	movl	%eax, (%rdi)
    7b67:      	movq	%rbp, %rax
    7b6a:      	negq	%rax
    7b6d:      	movl	$0x3, %ecx
    7b72:      	subq	%rbp, %rcx
    7b75:      	leal	-0x4(%rbp), %edx
    7b78:      	movq	%rdi, 0x60(%rsp)
    7b7d:      	addq	$0x7, %rdi
    7b81:      	movl	$0x2, %r8d
    7b87:      	subq	%rbp, %r8
    7b8a:      	leal	-0x3(%rbp), %r9d
    7b8e:      	movl	$0x1, %r10d
    7b94:      	subq	%rbp, %r10
    7b97:      	leal	-0x2(%rbp), %r11d
    7b9b:      	decl	%ebp
    7b9d:      	xorl	%ebx, %ebx
    7b9f:      	movq	0x18(%rsp), %rsi
    7ba4:      	leal	(%rbx,%rbp), %r12d
    7ba8:      	andl	$0xfff, %r12d           # imm = 0xFFF
    7baf:      	movzbl	(%rsi,%r12), %r12d
    7bb4:      	movb	%r12b, -0x3(%rdi)
    7bb8:      	cmpq	%rbx, %r10
    7bbb:      	je	0x7c15 <generic_rawtp_filter_arg+0x1335>
    7bbd:      	leal	(%r11,%rbx), %r12d
    7bc1:      	andl	$0xfff, %r12d           # imm = 0xFFF
    7bc8:      	movzbl	(%rsi,%r12), %r12d
    7bcd:      	movb	%r12b, -0x2(%rdi)
    7bd1:      	cmpq	%rbx, %r8
    7bd4:      	je	0x7c15 <generic_rawtp_filter_arg+0x1335>
    7bd6:      	leal	(%r9,%rbx), %r12d
    7bda:      	andl	$0xfff, %r12d           # imm = 0xFFF
    7be1:      	movzbl	(%rsi,%r12), %r12d
    7be6:      	movb	%r12b, -0x1(%rdi)
    7bea:      	cmpq	%rbx, %rcx
    7bed:      	je	0x7c15 <generic_rawtp_filter_arg+0x1335>
    7bef:      	cmpq	$-0x7c, %rbx
    7bf3:      	je	0x7c15 <generic_rawtp_filter_arg+0x1335>
    7bf5:      	leal	(%rdx,%rbx), %r12d
    7bf9:      	andl	$0xfff, %r12d           # imm = 0xFFF
    7c00:      	movzbl	(%rsi,%r12), %r12d
    7c05:      	movb	%r12b, (%rdi)
    7c08:      	addq	$-0x4, %rbx
    7c0c:      	addq	$0x4, %rdi
    7c10:      	cmpq	%rbx, %rax
    7c13:      	jne	0x7ba4 <generic_rawtp_filter_arg+0x12c4>
    7c15:      	movl	$0x1, %eax
    7c1a:      	movq	0x20(%rsp), %rdi
    7c1f:      	movq	0x60(%rsp), %rsi
    7c24:      	jmp	0x83c8 <generic_rawtp_filter_arg+0x1ae8>
    7c29:      	movl	0x10(%r13), %esi
    7c2d:      	movl	0x14(%r13), %eax
    7c31:      	cmpl	$0xc, %ecx
    7c34:      	ja	0x887a <generic_rawtp_filter_arg+0x1f9a>
    7c3a:      	movl	$0x1402, %edx           # imm = 0x1402
    7c3f:      	btl	%ecx, %edx
    7c42:      	jae	0x887a <generic_rawtp_filter_arg+0x1f9a>
    7c48:      	movl	(%r12), %edx
    7c4c:      	cmpl	%edx, %esi
    7c4e:      	setle	%sil
    7c52:      	cmpl	%eax, %edx
    7c54:      	setle	%al
    7c57:      	jmp	0x8889 <generic_rawtp_filter_arg+0x1fa9>
    7c5c:      	cmpl	$0x1c, %eax
    7c5f:      	je	0x82aa <generic_rawtp_filter_arg+0x19ca>
    7c65:      	movq	%r8, 0x18(%rsp)
    7c6a:      	movq	%rsi, %r12
    7c6d:      	cmpl	$0x1a, %eax
    7c70:      	je	0x8212 <generic_rawtp_filter_arg+0x1932>
    7c76:      	jmp	0x69fd <generic_rawtp_filter_arg+0x11d>
    7c7b:      	cmpl	$0x12, %eax
    7c7e:      	je	0x7c99 <generic_rawtp_filter_arg+0x13b9>
    7c80:      	movl	$0x0, %ebx
    7c85:      	cmpl	$0x13, %eax
    7c88:      	jne	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    7c8e:      	movq	%r12, %rdx
    7c91:      	movzwl	0x22(%r12), %r12d
    7c97:      	jmp	0x7ca2 <generic_rawtp_filter_arg+0x13c2>
    7c99:      	movq	%r12, %rdx
    7c9c:      	movzwl	0x20(%r12), %r12d
    7ca2:      	xorl	%esi, %esi
    7ca4:      	xorl	%ebp, %ebp
    7ca6:      	xorl	%r8d, %r8d
    7ca9:      	xorl	%ebx, %ebx
    7cab:      	cmpl	$0x11, %eax
    7cae:      	jg	0x7d3a <generic_rawtp_filter_arg+0x145a>
    7cb4:      	leal	-0xd(%rax), %ecx
    7cb7:      	cmpl	$0x2, %ecx
    7cba:      	jb	0x7d6d <generic_rawtp_filter_arg+0x148d>
    7cc0:      	leal	-0xf(%rax), %ecx
    7cc3:      	cmpl	$0x2, %ecx
    7cc6:      	jb	0x7ea0 <generic_rawtp_filter_arg+0x15c0>
    7ccc:      	cmpl	$0x11, %eax
    7ccf:      	je	0x8492 <generic_rawtp_filter_arg+0x1bb2>
    7cd5:      	jmp	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    7cda:      	cmpl	$0x1c, %eax
    7cdd:      	je	0x848c <generic_rawtp_filter_arg+0x1bac>
    7ce3:      	movl	$0x0, %ebx
    7ce8:      	cmpl	$0x1d, %eax
    7ceb:      	jne	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    7cf1:      	cmpl	$0x7, %ecx
    7cf4:      	jne	0x8a28 <generic_rawtp_filter_arg+0x2148>
    7cfa:      	testq	%rdx, %rdx
    7cfd:      	jne	0x8a34 <generic_rawtp_filter_arg+0x2154>
    7d03:      	xorl	%ebx, %ebx
    7d05:      	jmp	0x8a46 <generic_rawtp_filter_arg+0x2166>
    7d0a:      	movq	0x10(%r12), %rsi
    7d0f:      	movq	%r12, %rdx
    7d12:      	movq	0x18(%r12), %r8
    7d17:      	jmp	0x7d25 <generic_rawtp_filter_arg+0x1445>
    7d19:      	movq	(%r12), %rsi
    7d1d:      	movq	%r12, %rdx
    7d20:      	movq	0x8(%r12), %r8
    7d25:      	movq	%rsi, %rbp
    7d28:      	shrq	$0x20, %rbp
    7d2c:      	xorl	%r12d, %r12d
    7d2f:      	xorl	%ebx, %ebx
    7d31:      	cmpl	$0x11, %eax
    7d34:      	jle	0x7cb4 <generic_rawtp_filter_arg+0x13d4>
    7d3a:      	cmpl	$0x19, %eax
    7d3d:      	ja	0x7e94 <generic_rawtp_filter_arg+0x15b4>
    7d43:      	movl	$0x500000, %ecx         # imm = 0x500000
    7d48:      	btl	%eax, %ecx
    7d4b:      	jb	0x7fe3 <generic_rawtp_filter_arg+0x1703>
    7d51:      	movl	$0xa00000, %ecx         # imm = 0xA00000
    7d56:      	btl	%eax, %ecx
    7d59:      	jb	0x7ff6 <generic_rawtp_filter_arg+0x1716>
    7d5f:      	movl	$0x3000000, %ecx        # imm = 0x3000000
    7d64:      	btl	%eax, %ecx
    7d67:      	jae	0x7e94 <generic_rawtp_filter_arg+0x15b4>
    7d6d:      	movzwl	0x26(%rdx), %eax
    7d71:      	cmpl	$0xa, %eax
    7d74:      	je	0x808b <generic_rawtp_filter_arg+0x17ab>
    7d7a:      	cmpl	$0x2, %eax
    7d7d:      	jne	0x811d <generic_rawtp_filter_arg+0x183d>
    7d83:      	movq	%rsi, %r12
    7d86:      	movq	%r11, 0x10(%rsp)
    7d8b:      	movl	0x10(%r13), %eax
    7d8f:      	movl	%eax, 0x34(%rsp)
    7d93:      	movl	$0x1, %eax
    7d98:      	leaq	0x34(%rsp), %rsi
    7d9d:      	movq	(%rip), %rdi            # 0x7da4 <generic_rawtp_filter_arg+0x14c4>
    7da4:      	callq	*%rax
    7da6:      	testq	%rax, %rax
    7da9:      	je	0x8549 <generic_rawtp_filter_arg+0x1c69>
    7daf:      	movq	%rax, %rdi
    7db2:      	movl	$0x20, 0x70(%rsp)
    7dba:      	movl	%r12d, 0x74(%rsp)
    7dbf:      	jmp	0x80dd <generic_rawtp_filter_arg+0x17fd>
    7dc4:      	cmpl	$0xc, %ecx
    7dc7:      	ja	0x8af1 <generic_rawtp_filter_arg+0x2211>
    7dcd:      	movl	$0x1402, %esi           # imm = 0x1402
    7dd2:      	btl	%ecx, %esi
    7dd5:      	jae	0x8af1 <generic_rawtp_filter_arg+0x2211>
    7ddb:      	cmpl	%edx, (%r12)
    7ddf:      	jg	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    7de5:      	jmp	0x8b07 <generic_rawtp_filter_arg+0x2227>
    7dea:      	xorl	%ebx, %ebx
    7dec:      	xorl	%r12d, %r12d
    7def:      	movq	%r11, %r15
    7df2:      	movl	0x10(%r13,%rbx,4), %eax
    7df7:      	movl	%eax, 0x38(%rsp)
    7dfb:      	movl	$0x1, %eax
    7e00:      	leaq	0x38(%rsp), %rsi
    7e05:      	movq	(%rip), %rdi            # 0x7e0c <generic_rawtp_filter_arg+0x152c>
    7e0c:      	callq	*%rax
    7e0e:      	testq	%rax, %rax
    7e11:      	je	0x8974 <generic_rawtp_filter_arg+0x2094>
    7e17:      	testl	%ebp, %ebp
    7e19:      	movq	0x8(%rsp), %r9
    7e1e:      	movq	%r15, %r11
    7e21:      	movq	0x68(%rsp), %r15
    7e26:      	je	0x7e6f <generic_rawtp_filter_arg+0x158f>
    7e28:      	movq	0x18(%rsp), %rdx
    7e2d:      	xorl	%ecx, %ecx
    7e2f:      	jmp	0x7e3c <generic_rawtp_filter_arg+0x155c>
    7e31:      	incq	%rcx
    7e34:      	incq	%rdx
    7e37:      	cmpq	%rbp, %rcx
    7e3a:      	je	0x7e6f <generic_rawtp_filter_arg+0x158f>
    7e3c:      	xorl	%esi, %esi
    7e3e:      	nop
    7e40:      	leaq	(%rcx,%rsi), %rdi
    7e44:      	cmpq	%rbp, %rdi
    7e47:      	jae	0x7e31 <generic_rawtp_filter_arg+0x1551>
    7e49:      	movzbl	(%rax,%rsi), %edi
    7e4d:      	testb	%dil, %dil
    7e50:      	je	0x7e67 <generic_rawtp_filter_arg+0x1587>
    7e52:      	cmpq	$0x62, %rsi
    7e56:      	ja	0x7e31 <generic_rawtp_filter_arg+0x1551>
    7e58:      	leaq	0x1(%rsi), %r8
    7e5c:      	cmpb	%dil, (%rdx,%rsi)
    7e60:      	movq	%r8, %rsi
    7e63:      	je	0x7e40 <generic_rawtp_filter_arg+0x1560>
    7e65:      	jmp	0x7e31 <generic_rawtp_filter_arg+0x1551>
    7e67:      	testl	%ecx, %ecx
    7e69:      	jns	0x8bfa <generic_rawtp_filter_arg+0x231a>
    7e6f:      	leal	0xc(%r12), %eax
    7e74:      	cmpl	0x8(%r13), %eax
    7e78:      	jae	0x9777 <generic_rawtp_filter_arg+0x2e97>
    7e7e:      	addl	$0x4, %r12d
    7e82:      	incq	%rbx
    7e85:      	cmpq	$0x64, %rbx
    7e89:      	jne	0x7def <generic_rawtp_filter_arg+0x150f>
    7e8f:      	jmp	0x9777 <generic_rawtp_filter_arg+0x2e97>
    7e94:      	addl	$-0x12, %eax
    7e97:      	cmpl	$0x2, %eax
    7e9a:      	jae	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    7ea0:      	movq	%r11, %rbp
    7ea3:      	movzbl	0x10(%r13), %eax
    7ea8:      	movl	%eax, 0x34(%rsp)
    7eac:      	movl	$0x1, %eax
    7eb1:      	movq	(%rip), %rdi            # 0x7eb8 <generic_rawtp_filter_arg+0x15d8>
    7eb8:      	leaq	0x34(%rsp), %rsi
    7ebd:      	callq	*%rax
    7ebf:      	testq	%rax, %rax
    7ec2:      	je	0x831e <generic_rawtp_filter_arg+0x1a3e>
    7ec8:      	movq	%rax, %rdi
    7ecb:      	movzwl	%r12w, %eax
    7ecf:      	movq	%rax, 0x70(%rsp)
    7ed4:      	movl	$0x1, %eax
    7ed9:      	movq	0x28(%rsp), %rsi
    7ede:      	jmp	0x82e5 <generic_rawtp_filter_arg+0x1a05>
    7ee3:      	leal	-0x100(%rbx), %eax
    7ee9:      	rorxl	$0x8, %eax, %eax
    7eef:      	cmpl	$0x2, %eax
    7ef2:      	jg	0x86a4 <generic_rawtp_filter_arg+0x1dc4>
    7ef8:      	testl	%eax, %eax
    7efa:      	je	0x8dbd <generic_rawtp_filter_arg+0x24dd>
    7f00:      	cmpl	$0x1, %eax
    7f03:      	jne	0x8db6 <generic_rawtp_filter_arg+0x24d6>
    7f09:      	movl	$0x7, %eax
    7f0e:      	jmp	0x8dc9 <generic_rawtp_filter_arg+0x24e9>
    7f13:      	cmpl	$0x1, %eax
    7f16:      	je	0x8799 <generic_rawtp_filter_arg+0x1eb9>
    7f1c:      	cmpl	$0x2, %eax
    7f1f:      	jne	0x87a6 <generic_rawtp_filter_arg+0x1ec6>
    7f25:      	movzbl	(%r12), %edx
    7f2a:      	cmpl	%edx, %ecx
    7f2c:      	ja	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    7f32:      	jmp	0x87a6 <generic_rawtp_filter_arg+0x1ec6>
    7f37:      	cmpl	$0x1, %eax
    7f3a:      	je	0x87de <generic_rawtp_filter_arg+0x1efe>
    7f40:      	cmpl	$0x2, %eax
    7f43:      	jne	0x87eb <generic_rawtp_filter_arg+0x1f0b>
    7f49:      	movzwl	(%r12), %edx
    7f4e:      	cmpl	%edx, %ecx
    7f50:      	ja	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    7f56:      	jmp	0x87eb <generic_rawtp_filter_arg+0x1f0b>
    7f5b:      	movq	%r11, %rbp
    7f5e:      	movzbl	0x10(%r13), %eax
    7f63:      	movl	%eax, 0x70(%rsp)
    7f67:      	movl	$0x1, %eax
    7f6c:      	movq	0x28(%rsp), %rsi
    7f71:      	movq	(%rip), %rdi            # 0x7f78 <generic_rawtp_filter_arg+0x1698>
    7f78:      	callq	*%rax
    7f7a:      	testq	%rax, %rax
    7f7d:      	je	0x831e <generic_rawtp_filter_arg+0x1a3e>
    7f83:      	movq	%rax, %rdi
    7f86:      	movzbl	(%r12), %eax
    7f8b:      	movq	%rax, 0x38(%rsp)
    7f90:      	movl	$0x1, %eax
    7f95:      	leaq	0x38(%rsp), %rsi
    7f9a:      	jmp	0x82e5 <generic_rawtp_filter_arg+0x1a05>
    7f9f:      	movq	%r11, %rbp
    7fa2:      	movzbl	0x10(%r13), %eax
    7fa7:      	movl	%eax, 0x70(%rsp)
    7fab:      	movl	$0x1, %eax
    7fb0:      	movq	0x28(%rsp), %rsi
    7fb5:      	movq	(%rip), %rdi            # 0x7fbc <generic_rawtp_filter_arg+0x16dc>
    7fbc:      	callq	*%rax
    7fbe:      	testq	%rax, %rax
    7fc1:      	je	0x831e <generic_rawtp_filter_arg+0x1a3e>
    7fc7:      	movq	%rax, %rdi
    7fca:      	movzwl	(%r12), %eax
    7fcf:      	movq	%rax, 0x38(%rsp)
    7fd4:      	movl	$0x1, %eax
    7fd9:      	leaq	0x38(%rsp), %rsi
    7fde:      	jmp	0x82e5 <generic_rawtp_filter_arg+0x1a05>
    7fe3:      	movzwl	%r12w, %eax
    7fe7:      	xorl	%ebx, %ebx
    7fe9:      	cmpl	$0x400, %eax            # imm = 0x400
    7fee:      	setb	%bl
    7ff1:      	jmp	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    7ff6:      	movzwl	%r12w, %eax
    7ffa:      	xorl	%ebx, %ebx
    7ffc:      	cmpl	$0x400, %eax            # imm = 0x400
    8001:      	setae	%bl
    8004:      	jmp	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    8009:      	testq	%rax, %rax
    800c:      	sete	%al
    800f:      	movq	(%rsp), %rdi
    8013:      	movq	0x8(%rsp), %r9
    8018:      	movq	%rbp, %r11
    801b:      	movzbl	%al, %ebx
    801e:      	jmp	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    8023:      	movl	$0x100, %esi            # imm = 0x100
    8028:      	cmpl	$0x101, %eax            # imm = 0x101
    802d:      	jb	0x805b <generic_rawtp_filter_arg+0x177b>
    802f:      	movl	$0x200, %esi            # imm = 0x200
    8034:      	cmpl	$0x201, %eax            # imm = 0x201
    8039:      	jb	0x805b <generic_rawtp_filter_arg+0x177b>
    803b:      	movl	$0x400, %esi            # imm = 0x400
    8040:      	cmpl	$0x401, %eax            # imm = 0x401
    8045:      	jb	0x805b <generic_rawtp_filter_arg+0x177b>
    8047:      	xorl	%esi, %esi
    8049:      	cmpl	$0x801, %eax            # imm = 0x801
    804e:      	setae	%sil
    8052:      	shll	$0xb, %esi
    8055:      	addl	$0x800, %esi            # imm = 0x800
    805b:      	leal	-0x100(%rsi), %eax
    8061:      	rorxl	$0x8, %eax, %eax
    8067:      	cmpl	$0x2, %eax
    806a:      	jg	0x8558 <generic_rawtp_filter_arg+0x1c78>
    8070:      	testl	%eax, %eax
    8072:      	je	0x8c23 <generic_rawtp_filter_arg+0x2343>
    8078:      	cmpl	$0x1, %eax
    807b:      	jne	0x8c1c <generic_rawtp_filter_arg+0x233c>
    8081:      	movl	$0x7, %eax
    8086:      	jmp	0x8c2f <generic_rawtp_filter_arg+0x234f>
    808b:      	movq	%r8, %rbx
    808e:      	movq	%rsi, %r12
    8091:      	movq	%r11, 0x10(%rsp)
    8096:      	movl	0x14(%r13), %eax
    809a:      	movl	%eax, 0x34(%rsp)
    809e:      	movl	$0x1, %eax
    80a3:      	movq	(%rip), %rdi            # 0x80aa <generic_rawtp_filter_arg+0x17ca>
    80aa:      	leaq	0x34(%rsp), %rsi
    80af:      	callq	*%rax
    80b1:      	testq	%rax, %rax
    80b4:      	je	0x8549 <generic_rawtp_filter_arg+0x1c69>
    80ba:      	movq	%rax, %rdi
    80bd:      	movl	$0x80, 0x70(%rsp)
    80c5:      	movl	%r12d, 0x74(%rsp)
    80ca:      	movl	%ebp, 0x78(%rsp)
    80ce:      	movl	%ebx, 0x7c(%rsp)
    80d2:      	shrq	$0x20, %rbx
    80d6:      	movl	%ebx, 0x80(%rsp)
    80dd:      	movl	$0x1, %eax
    80e2:      	movq	0x28(%rsp), %rsi
    80e7:      	callq	*%rax
    80e9:      	movl	0x4(%r13), %ecx
    80ed:      	leal	-0x18(%rcx), %edx
    80f0:      	cmpl	$0x2, %edx
    80f3:      	jb	0x8761 <generic_rawtp_filter_arg+0x1e81>
    80f9:      	addl	$-0xd, %ecx
    80fc:      	cmpl	$0x1, %ecx
    80ff:      	movq	(%rsp), %rdi
    8103:      	movq	0x8(%rsp), %r9
    8108:      	movq	0x10(%rsp), %r11
    810d:      	ja	0x811d <generic_rawtp_filter_arg+0x183d>
    810f:      	testq	%rax, %rax
    8112:      	setne	%al
    8115:      	movzbl	%al, %ebx
    8118:      	jmp	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    811d:      	xorl	%eax, %eax
    811f:      	movzbl	%al, %ebx
    8122:      	jmp	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    8127:      	cmpl	$0x1e, %eax
    812a:      	jne	0x69fd <generic_rawtp_filter_arg+0x11d>
    8130:      	movl	0x10(%r13), %eax
    8134:      	andl	$0x7, %eax
    8137:      	movl	%eax, %ecx
    8139:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    8142:      	jne	0x69fd <generic_rawtp_filter_arg+0x11d>
    8148:      	movq	(%r12), %rcx
    814c:      	movq	0x5e78(%r14,%rax,8), %rax
    8154:      	andl	$0x7ff, %eax            # imm = 0x7FF
    8159:      	xorl	%ebx, %ebx
    815b:      	andnq	0x90(%r14,%rax), %rcx, %rax
    8165:      	setne	%bl
    8168:      	jmp	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    816d:      	cmpl	$0x21, %eax
    8170:      	je	0x88cc <generic_rawtp_filter_arg+0x1fec>
    8176:      	movl	$0x0, %ebx
    817b:      	cmpl	$0x22, %eax
    817e:      	jne	0x9f1b <generic_rawtp_filter_arg+0x363b>
    8184:      	movl	$0x10, %r12d
    818a:      	movq	%r11, %r15
    818d:      	movl	(%r13,%r12), %eax
    8192:      	movl	%eax, 0x38(%rsp)
    8196:      	movl	$0x1, %eax
    819b:      	leaq	0x38(%rsp), %rsi
    81a0:      	movq	(%rip), %rdi            # 0x81a7 <generic_rawtp_filter_arg+0x18c7>
    81a7:      	callq	*%rax
    81a9:      	testq	%rax, %rax
    81ac:      	je	0x9564 <generic_rawtp_filter_arg+0x2c84>
    81b2:      	movq	0x18(%rsp), %rdi
    81b7:      	movq	%rax, %rsi
    81ba:      	movq	%rbp, %rdx
    81bd:      	callq	0x81c2 <generic_rawtp_filter_arg+0x18e2>
    81c2:      	testl	%eax, %eax
    81c4:      	jns	0x9568 <generic_rawtp_filter_arg+0x2c88>
    81ca:      	addq	$0x4, %r12
    81ce:      	leal	-0x8(%r12), %eax
    81d3:      	cmpl	0x8(%r13), %eax
    81d7:      	movq	(%rsp), %rdi
    81db:      	movq	0x8(%rsp), %r9
    81e0:      	movq	%r15, %r11
    81e3:      	jae	0x969d <generic_rawtp_filter_arg+0x2dbd>
    81e9:      	movl	$0x0, %ebx
    81ee:      	cmpq	$0x1a0, %r12            # imm = 0x1A0
    81f5:      	movq	0x68(%rsp), %r15
    81fa:      	jne	0x818a <generic_rawtp_filter_arg+0x18aa>
    81fc:      	jmp	0x9f1b <generic_rawtp_filter_arg+0x363b>
    8201:      	movq	%r8, 0x18(%rsp)
    8206:      	movq	%rsi, %r12
    8209:      	cmpl	$0x8, %eax
    820c:      	jne	0x69fd <generic_rawtp_filter_arg+0x11d>
    8212:      	movq	%r11, 0x10(%rsp)
    8217:      	movl	0x10(%r13), %eax
    821b:      	movl	%eax, 0x38(%rsp)
    821f:      	movl	$0x0, 0x70(%rsp)
    8227:      	movl	$0x1, %eax
    822c:      	leaq	0x38(%rsp), %rsi
    8231:      	movq	(%rip), %rdi            # 0x8238 <generic_rawtp_filter_arg+0x1958>
    8238:      	callq	*%rax
    823a:      	testb	%bpl, %bpl
    823d:      	je	0x8512 <generic_rawtp_filter_arg+0x1c32>
    8243:      	movl	$0x0, %ebx
    8248:      	testq	%rax, %rax
    824b:      	je	0x8514 <generic_rawtp_filter_arg+0x1c34>
    8251:      	movq	%rax, %rbp
    8254:      	movl	$0x1, %eax
    8259:      	movq	0x28(%rsp), %rsi
    825e:      	movq	(%rip), %rdi            # 0x8265 <generic_rawtp_filter_arg+0x1985>
    8265:      	callq	*%rax
    8267:      	testq	%rax, %rax
    826a:      	je	0x8512 <generic_rawtp_filter_arg+0x1c32>
    8270:      	movq	%r12, %rsi
    8273:      	movl	%esi, %ecx
    8275:      	shll	$0x3, %ecx
    8278:      	movl	%ecx, (%rax)
    827a:      	movq	%rax, %rdi
    827d:      	addq	$0x4, %rdi
    8281:      	movq	%rax, %rbx
    8284:      	movl	$0x4, %eax
    8289:      	movq	0x18(%rsp), %rdx
    828e:      	callq	*%rax
    8290:      	movl	$0x1, %eax
    8295:      	movq	%rbp, %rdi
    8298:      	movq	%rbx, %rsi
    829b:      	callq	*%rax
    829d:      	xorl	%ebx, %ebx
    829f:      	testq	%rax, %rax
    82a2:      	setne	%bl
    82a5:      	jmp	0x8514 <generic_rawtp_filter_arg+0x1c34>
    82aa:      	movq	%r11, %rbp
    82ad:      	movzwl	(%r12), %ebx
    82b2:      	movzbl	0x10(%r13), %eax
    82b7:      	movl	%eax, 0x70(%rsp)
    82bb:      	movl	$0x1, %eax
    82c0:      	movq	0x28(%rsp), %rsi
    82c5:      	movq	(%rip), %rdi            # 0x82cc <generic_rawtp_filter_arg+0x19ec>
    82cc:      	callq	*%rax
    82ce:      	testq	%rax, %rax
    82d1:      	je	0x831e <generic_rawtp_filter_arg+0x1a3e>
    82d3:      	movq	%rax, %rdi
    82d6:      	movq	%rbx, 0x38(%rsp)
    82db:      	movl	$0x1, %eax
    82e0:      	leaq	0x38(%rsp), %rsi
    82e5:      	callq	*%rax
    82e7:      	movl	0x4(%r13), %edx
    82eb:      	xorl	%ecx, %ecx
    82ed:      	cmpl	$0x1d, %edx
    82f0:      	ja	0x8c08 <generic_rawtp_filter_arg+0x2328>
    82f6:      	movl	$0x30038400, %esi       # imm = 0x30038400
    82fb:      	btl	%edx, %esi
    82fe:      	movq	(%rsp), %rdi
    8302:      	movq	0x8(%rsp), %r9
    8307:      	movq	%rbp, %r11
    830a:      	jae	0x84fa <generic_rawtp_filter_arg+0x1c1a>
    8310:      	testq	%rax, %rax
    8313:      	setne	%cl
    8316:      	movzbl	%cl, %ebx
    8319:      	jmp	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    831e:      	xorl	%ebx, %ebx
    8320:      	movq	(%rsp), %rdi
    8324:      	movq	0x8(%rsp), %r9
    8329:      	movq	%rbp, %r11
    832c:      	jmp	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    8331:      	movq	%r11, 0x10(%rsp)
    8336:      	movl	0x10(%r13), %eax
    833a:      	movl	%eax, 0x38(%rsp)
    833e:      	movl	$0x0, 0x70(%rsp)
    8346:      	movl	$0x1, %eax
    834b:      	leaq	0x38(%rsp), %rsi
    8350:      	movq	(%rip), %rdi            # 0x8357 <generic_rawtp_filter_arg+0x1a77>
    8357:      	callq	*%rax
    8359:      	testl	%ebp, %ebp
    835b:      	je	0x9f0b <generic_rawtp_filter_arg+0x362b>
    8361:      	movq	%rax, %r12
    8364:      	movl	$0x0, %ebx
    8369:      	testq	%rax, %rax
    836c:      	je	0x9f0d <generic_rawtp_filter_arg+0x362d>
    8372:      	movl	$0x1, %eax
    8377:      	movq	0x28(%rsp), %rsi
    837c:      	movq	(%rip), %rdi            # 0x8383 <generic_rawtp_filter_arg+0x1aa3>
    8383:      	callq	*%rax
    8385:      	testq	%rax, %rax
    8388:      	je	0x9f0b <generic_rawtp_filter_arg+0x362b>
    838e:      	cmpl	$0xff, %ebp
    8394:      	movl	$0xff, %ecx
    8399:      	cmovael	%ecx, %ebp
    839c:      	leal	(,%rbp,8), %ecx
    83a3:      	movl	%ecx, (%rax)
    83a5:      	movq	%rax, %rdi
    83a8:      	addq	$0x4, %rdi
    83ac:      	movq	%rax, %rbx
    83af:      	movl	$0x4, %eax
    83b4:      	movq	0x18(%rsp), %rdx
    83b9:      	movl	%ebp, %esi
    83bb:      	callq	*%rax
    83bd:      	movl	$0x1, %eax
    83c2:      	movq	%r12, %rdi
    83c5:      	movq	%rbx, %rsi
    83c8:      	callq	*%rax
    83ca:      	xorl	%ebx, %ebx
    83cc:      	testq	%rax, %rax
    83cf:      	setne	%bl
    83d2:      	jmp	0x9f0d <generic_rawtp_filter_arg+0x362d>
    83d7:      	movl	$0x0, 0x70(%rsp)
    83df:      	cmpl	$0x1000, %ebp           # imm = 0x1000
    83e5:      	jbe	0x898c <generic_rawtp_filter_arg+0x20ac>
    83eb:      	xorl	%ebx, %ebx
    83ed:      	jmp	0x9f1b <generic_rawtp_filter_arg+0x363b>
    83f2:      	movq	(%r12), %rax
    83f6:      	cmpq	%rax, %rsi
    83f9:      	ja	0x8404 <generic_rawtp_filter_arg+0x1b24>
    83fb:      	cmpq	%rdx, %rax
    83fe:      	jbe	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    8404:      	movl	0x8(%r13), %edx
    8408:      	cmpl	$0x19, %edx
    840b:      	jb	0x69fd <generic_rawtp_filter_arg+0x11d>
    8411:      	movq	0x20(%r13), %rdi
    8415:      	movq	0x28(%r13), %rsi
    8419:      	cmpl	$0xc, %ecx
    841c:      	je	0x8427 <generic_rawtp_filter_arg+0x1b47>
    841e:      	cmpl	$0xa, %ecx
    8421:      	jne	0x8aa5 <generic_rawtp_filter_arg+0x21c5>
    8427:      	cmpq	%rax, %rdi
    842a:      	movq	(%rsp), %rdi
    842e:      	jg	0x8ab7 <generic_rawtp_filter_arg+0x21d7>
    8434:      	cmpq	%rsi, %rax
    8437:      	jle	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    843d:      	jmp	0x8ab7 <generic_rawtp_filter_arg+0x21d7>
    8442:      	movq	(%r12), %rdx
    8446:      	cmpq	%rdx, %rsi
    8449:      	setbe	%sil
    844d:      	cmpq	%rax, %rdx
    8450:      	setbe	%al
    8453:      	andb	%sil, %al
    8456:      	movl	0x8(%r13), %esi
    845a:      	cmpl	$0x19, %esi
    845d:      	jb	0x9930 <generic_rawtp_filter_arg+0x3050>
    8463:      	movq	0x20(%r13), %r8
    8467:      	movq	0x28(%r13), %rdi
    846b:      	cmpl	$0xc, %ecx
    846e:      	je	0x8479 <generic_rawtp_filter_arg+0x1b99>
    8470:      	cmpl	$0xa, %ecx
    8473:      	jne	0x89e2 <generic_rawtp_filter_arg+0x2102>
    8479:      	cmpq	%rdx, %r8
    847c:      	setle	%r8b
    8480:      	cmpq	%rdi, %rdx
    8483:      	setle	%dil
    8487:      	jmp	0x89f0 <generic_rawtp_filter_arg+0x2110>
    848c:      	movzwl	0x26(%r12), %ebx
    8492:      	movq	%r11, %r12
    8495:      	movzbl	0x10(%r13), %eax
    849a:      	movl	%eax, 0x34(%rsp)
    849e:      	movl	$0x1, %eax
    84a3:      	movq	(%rip), %rdi            # 0x84aa <generic_rawtp_filter_arg+0x1bca>
    84aa:      	leaq	0x34(%rsp), %rsi
    84af:      	callq	*%rax
    84b1:      	testq	%rax, %rax
    84b4:      	je	0x8a83 <generic_rawtp_filter_arg+0x21a3>
    84ba:      	movq	%rax, %rdi
    84bd:      	movzwl	%bx, %eax
    84c0:      	movq	%rax, 0x70(%rsp)
    84c5:      	movl	$0x1, %eax
    84ca:      	movq	0x28(%rsp), %rsi
    84cf:      	callq	*%rax
    84d1:      	movl	0x4(%r13), %edx
    84d5:      	xorl	%ecx, %ecx
    84d7:      	cmpl	$0x1d, %edx
    84da:      	ja	0x96e1 <generic_rawtp_filter_arg+0x2e01>
    84e0:      	movl	$0x30038400, %esi       # imm = 0x30038400
    84e5:      	btl	%edx, %esi
    84e8:      	movq	(%rsp), %rdi
    84ec:      	movq	0x8(%rsp), %r9
    84f1:      	movq	%r12, %r11
    84f4:      	jb	0x8310 <generic_rawtp_filter_arg+0x1a30>
    84fa:      	movl	$0xc0800, %esi          # imm = 0xC0800
    84ff:      	btl	%edx, %esi
    8502:      	jae	0x850a <generic_rawtp_filter_arg+0x1c2a>
    8504:      	testq	%rax, %rax
    8507:      	sete	%cl
    850a:      	movzbl	%cl, %ebx
    850d:      	jmp	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    8512:      	xorl	%ebx, %ebx
    8514:      	movl	0x4(%r13), %eax
    8518:      	cmpq	$0x25, %rax
    851c:      	ja	0x940f <generic_rawtp_filter_arg+0x2b2f>
    8522:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    852c:      	btq	%rax, %rcx
    8530:      	movq	(%rsp), %rdi
    8534:      	movq	0x8(%rsp), %r9
    8539:      	movq	0x10(%rsp), %r11
    853e:      	jb	0x9ba5 <generic_rawtp_filter_arg+0x32c5>
    8544:      	jmp	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    8549:      	movl	0x4(%r13), %eax
    854d:      	andl	$-0x2, %eax
    8550:      	cmpl	$0x18, %eax
    8553:      	jmp	0x8764 <generic_rawtp_filter_arg+0x1e84>
    8558:      	cmpl	$0x3, %eax
    855b:      	je	0x8c2a <generic_rawtp_filter_arg+0x234a>
    8561:      	cmpl	$0x7, %eax
    8564:      	jne	0x8c1c <generic_rawtp_filter_arg+0x233c>
    856a:      	movl	$0x9, %eax
    856f:      	jmp	0x8c2f <generic_rawtp_filter_arg+0x234f>
    8574:      	movl	$0x100, %esi            # imm = 0x100
    8579:      	cmpl	$0x101, %eax            # imm = 0x101
    857e:      	jb	0x85ac <generic_rawtp_filter_arg+0x1ccc>
    8580:      	movl	$0x200, %esi            # imm = 0x200
    8585:      	cmpl	$0x201, %eax            # imm = 0x201
    858a:      	jb	0x85ac <generic_rawtp_filter_arg+0x1ccc>
    858c:      	movl	$0x400, %esi            # imm = 0x400
    8591:      	cmpl	$0x401, %eax            # imm = 0x401
    8596:      	jb	0x85ac <generic_rawtp_filter_arg+0x1ccc>
    8598:      	xorl	%esi, %esi
    859a:      	cmpl	$0x801, %eax            # imm = 0x801
    859f:      	setae	%sil
    85a3:      	shll	$0xb, %esi
    85a6:      	addl	$0x800, %esi            # imm = 0x800
    85ac:      	leal	-0x100(%rsi), %eax
    85b2:      	rorxl	$0x8, %eax, %eax
    85b8:      	cmpl	$0x2, %eax
    85bb:      	jg	0x877d <generic_rawtp_filter_arg+0x1e9d>
    85c1:      	testl	%eax, %eax
    85c3:      	je	0x91b0 <generic_rawtp_filter_arg+0x28d0>
    85c9:      	cmpl	$0x1, %eax
    85cc:      	jne	0x91a9 <generic_rawtp_filter_arg+0x28c9>
    85d2:      	movl	$0x7, %eax
    85d7:      	jmp	0x91bc <generic_rawtp_filter_arg+0x28dc>
    85dc:      	cmpq	%rdx, (%r12)
    85e0:      	ja	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    85e6:      	jmp	0x85f2 <generic_rawtp_filter_arg+0x1d12>
    85e8:      	cmpq	%rdx, (%r12)
    85ec:      	jb	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    85f2:      	movl	0x8(%r13), %edx
    85f6:      	cmpl	$0x11, %edx
    85f9:      	jb	0x9fa1 <generic_rawtp_filter_arg+0x36c1>
    85ff:      	movq	0x18(%r13), %rsi
    8603:      	cmpl	$0x2, %eax
    8606:      	jle	0x8623 <generic_rawtp_filter_arg+0x1d43>
    8608:      	leal	-0x3(%rax), %edi
    860b:      	cmpl	$0x2, %edi
    860e:      	jae	0x8652 <generic_rawtp_filter_arg+0x1d72>
    8610:      	cmpq	%rsi, (%r12)
    8614:      	movq	(%rsp), %rdi
    8618:      	je	0x6ba5 <generic_rawtp_filter_arg+0x2c5>
    861e:      	jmp	0x9131 <generic_rawtp_filter_arg+0x2851>
    8623:      	cmpl	$0x1, %eax
    8626:      	je	0x86c0 <generic_rawtp_filter_arg+0x1de0>
    862c:      	cmpl	$0x2, %eax
    862f:      	jne	0x9131 <generic_rawtp_filter_arg+0x2851>
    8635:      	cmpl	$0xc, %ecx
    8638:      	je	0x8643 <generic_rawtp_filter_arg+0x1d63>
    863a:      	cmpl	$0xa, %ecx
    863d:      	jne	0x9127 <generic_rawtp_filter_arg+0x2847>
    8643:      	cmpq	%rsi, (%r12)
    8647:      	jl	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    864d:      	jmp	0x9131 <generic_rawtp_filter_arg+0x2851>
    8652:      	cmpl	$0xc, %eax
    8655:      	movq	(%rsp), %rdi
    8659:      	jne	0x9131 <generic_rawtp_filter_arg+0x2851>
    865f:      	testq	%rsi, (%r12)
    8663:      	jne	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    8669:      	jmp	0x9131 <generic_rawtp_filter_arg+0x2851>
    866e:      	cmpl	$0xc, %eax
    8671:      	jne	0x87a6 <generic_rawtp_filter_arg+0x1ec6>
    8677:      	movzbl	(%r12), %edx
    867c:      	testl	%edx, %ecx
    867e:      	jne	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    8684:      	jmp	0x87a6 <generic_rawtp_filter_arg+0x1ec6>
    8689:      	cmpl	$0xc, %eax
    868c:      	jne	0x87eb <generic_rawtp_filter_arg+0x1f0b>
    8692:      	movzwl	(%r12), %edx
    8697:      	testl	%edx, %ecx
    8699:      	jne	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    869f:      	jmp	0x87eb <generic_rawtp_filter_arg+0x1f0b>
    86a4:      	cmpl	$0x3, %eax
    86a7:      	je	0x8dc4 <generic_rawtp_filter_arg+0x24e4>
    86ad:      	cmpl	$0x7, %eax
    86b0:      	jne	0x8db6 <generic_rawtp_filter_arg+0x24d6>
    86b6:      	movl	$0x9, %eax
    86bb:      	jmp	0x8dc9 <generic_rawtp_filter_arg+0x24e9>
    86c0:      	cmpl	$0xc, %ecx
    86c3:      	je	0x86ce <generic_rawtp_filter_arg+0x1dee>
    86c5:      	cmpl	$0xa, %ecx
    86c8:      	jne	0x911b <generic_rawtp_filter_arg+0x283b>
    86ce:      	cmpq	%rsi, (%r12)
    86d2:      	jg	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    86d8:      	jmp	0x9131 <generic_rawtp_filter_arg+0x2851>
    86dd:      	movl	0x8(%r13), %edx
    86e1:      	movzbl	(%r12), %ecx
    86e6:      	jmp	0x86f1 <generic_rawtp_filter_arg+0x1e11>
    86e8:      	movl	0x8(%r13), %edx
    86ec:      	movzwl	(%r12), %ecx
    86f1:      	cmpl	%ecx, 0x10(%r13)
    86f5:      	setbe	%sil
    86f9:      	cmpl	%ecx, 0x14(%r13)
    86fd:      	setae	%al
    8700:      	andb	%sil, %al
    8703:      	cmpl	$0x11, %edx
    8706:      	jb	0x9930 <generic_rawtp_filter_arg+0x3050>
    870c:      	cmpl	%ecx, 0x18(%r13)
    8710:      	setbe	%sil
    8714:      	cmpl	%ecx, 0x1c(%r13)
    8718:      	setae	%dil
    871c:      	andb	%sil, %dil
    871f:      	orb	%dil, %al
    8722:      	cmpl	$0x19, %edx
    8725:      	jb	0x992c <generic_rawtp_filter_arg+0x304c>
    872b:      	cmpl	%ecx, 0x20(%r13)
    872f:      	setbe	%sil
    8733:      	cmpl	%ecx, 0x24(%r13)
    8737:      	setae	%dil
    873b:      	andb	%sil, %dil
    873e:      	orb	%dil, %al
    8741:      	cmpl	$0x21, %edx
    8744:      	jb	0x992c <generic_rawtp_filter_arg+0x304c>
    874a:      	cmpl	%ecx, 0x28(%r13)
    874e:      	setbe	%dl
    8751:      	cmpl	%ecx, 0x2c(%r13)
    8755:      	setae	%cl
    8758:      	andb	%dl, %cl
    875a:      	orb	%cl, %al
    875c:      	jmp	0x992c <generic_rawtp_filter_arg+0x304c>
    8761:      	testq	%rax, %rax
    8764:      	sete	%al
    8767:      	movq	(%rsp), %rdi
    876b:      	movq	0x8(%rsp), %r9
    8770:      	movq	0x10(%rsp), %r11
    8775:      	movzbl	%al, %ebx
    8778:      	jmp	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    877d:      	cmpl	$0x3, %eax
    8780:      	je	0x91b7 <generic_rawtp_filter_arg+0x28d7>
    8786:      	cmpl	$0x7, %eax
    8789:      	jne	0x91a9 <generic_rawtp_filter_arg+0x28c9>
    878f:      	movl	$0x9, %eax
    8794:      	jmp	0x91bc <generic_rawtp_filter_arg+0x28dc>
    8799:      	movzbl	(%r12), %edx
    879e:      	cmpl	%edx, %ecx
    87a0:      	jb	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    87a6:      	movl	0x8(%r13), %ecx
    87aa:      	cmpl	$0xd, %ecx
    87ad:      	jb	0x9fa1 <generic_rawtp_filter_arg+0x36c1>
    87b3:      	movl	0x14(%r13), %edx
    87b7:      	cmpl	$0x2, %eax
    87ba:      	jle	0x8bb2 <generic_rawtp_filter_arg+0x22d2>
    87c0:      	leal	-0x3(%rax), %esi
    87c3:      	cmpl	$0x2, %esi
    87c6:      	jae	0x935a <generic_rawtp_filter_arg+0x2a7a>
    87cc:      	movzbl	(%r12), %esi
    87d1:      	cmpl	%esi, %edx
    87d3:      	je	0x6ba5 <generic_rawtp_filter_arg+0x2c5>
    87d9:      	jmp	0x944b <generic_rawtp_filter_arg+0x2b6b>
    87de:      	movzwl	(%r12), %edx
    87e3:      	cmpl	%edx, %ecx
    87e5:      	jb	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    87eb:      	movl	0x8(%r13), %ecx
    87ef:      	cmpl	$0xd, %ecx
    87f2:      	jb	0x9fa1 <generic_rawtp_filter_arg+0x36c1>
    87f8:      	movl	0x14(%r13), %edx
    87fc:      	cmpl	$0x2, %eax
    87ff:      	jle	0x8bd6 <generic_rawtp_filter_arg+0x22f6>
    8805:      	leal	-0x3(%rax), %esi
    8808:      	cmpl	$0x2, %esi
    880b:      	jae	0x9375 <generic_rawtp_filter_arg+0x2a95>
    8811:      	movzwl	(%r12), %esi
    8816:      	cmpl	%esi, %edx
    8818:      	je	0x6ba5 <generic_rawtp_filter_arg+0x2c5>
    881e:      	jmp	0x948c <generic_rawtp_filter_arg+0x2bac>
    8823:      	movl	(%r12), %eax
    8827:      	cmpl	%eax, %esi
    8829:      	ja	0x8833 <generic_rawtp_filter_arg+0x1f53>
    882b:      	cmpl	%edx, %eax
    882d:      	jbe	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    8833:      	movl	0x8(%r13), %edx
    8837:      	cmpl	$0x11, %edx
    883a:      	jb	0x69fd <generic_rawtp_filter_arg+0x11d>
    8840:      	movl	0x18(%r13), %edi
    8844:      	movl	0x1c(%r13), %esi
    8848:      	cmpl	$0xc, %ecx
    884b:      	ja	0x8fd7 <generic_rawtp_filter_arg+0x26f7>
    8851:      	movl	$0x1402, %r8d           # imm = 0x1402
    8857:      	btl	%ecx, %r8d
    885b:      	jae	0x8fd7 <generic_rawtp_filter_arg+0x26f7>
    8861:      	cmpl	%eax, %edi
    8863:      	movq	(%rsp), %rdi
    8867:      	jg	0x8fe7 <generic_rawtp_filter_arg+0x2707>
    886d:      	cmpl	%esi, %eax
    886f:      	jle	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    8875:      	jmp	0x8fe7 <generic_rawtp_filter_arg+0x2707>
    887a:      	movl	(%r12), %edx
    887e:      	cmpl	%edx, %esi
    8880:      	setbe	%sil
    8884:      	cmpl	%eax, %edx
    8886:      	setbe	%al
    8889:      	andb	%sil, %al
    888c:      	movl	0x8(%r13), %esi
    8890:      	cmpl	$0x11, %esi
    8893:      	jb	0x9930 <generic_rawtp_filter_arg+0x3050>
    8899:      	movl	0x18(%r13), %r8d
    889d:      	movl	0x1c(%r13), %edi
    88a1:      	cmpl	$0xc, %ecx
    88a4:      	ja	0x8f81 <generic_rawtp_filter_arg+0x26a1>
    88aa:      	movl	$0x1402, %r10d          # imm = 0x1402
    88b0:      	btl	%ecx, %r10d
    88b4:      	jae	0x8f81 <generic_rawtp_filter_arg+0x26a1>
    88ba:      	cmpl	%edx, %r8d
    88bd:      	setle	%r8b
    88c1:      	cmpl	%edi, %edx
    88c3:      	setle	%dil
    88c7:      	jmp	0x8f8e <generic_rawtp_filter_arg+0x26ae>
    88cc:      	xorl	%ebx, %ebx
    88ce:      	xorl	%r12d, %r12d
    88d1:      	movq	%r11, %r15
    88d4:      	movl	0x10(%r13,%rbx,4), %eax
    88d9:      	movl	%eax, 0x38(%rsp)
    88dd:      	movl	$0x1, %eax
    88e2:      	leaq	0x38(%rsp), %rsi
    88e7:      	movq	(%rip), %rdi            # 0x88ee <generic_rawtp_filter_arg+0x200e>
    88ee:      	callq	*%rax
    88f0:      	testq	%rax, %rax
    88f3:      	je	0x8974 <generic_rawtp_filter_arg+0x2094>
    88f9:      	testl	%ebp, %ebp
    88fb:      	movq	0x8(%rsp), %r9
    8900:      	movq	%r15, %r11
    8903:      	movq	0x68(%rsp), %r15
    8908:      	je	0x894f <generic_rawtp_filter_arg+0x206f>
    890a:      	movq	0x18(%rsp), %rdx
    890f:      	xorl	%ecx, %ecx
    8911:      	jmp	0x891e <generic_rawtp_filter_arg+0x203e>
    8913:      	incq	%rcx
    8916:      	incq	%rdx
    8919:      	cmpq	%rbp, %rcx
    891c:      	je	0x894f <generic_rawtp_filter_arg+0x206f>
    891e:      	xorl	%esi, %esi
    8920:      	leaq	(%rcx,%rsi), %rdi
    8924:      	cmpq	%rbp, %rdi
    8927:      	jae	0x8913 <generic_rawtp_filter_arg+0x2033>
    8929:      	movzbl	(%rax,%rsi), %edi
    892d:      	testb	%dil, %dil
    8930:      	je	0x8947 <generic_rawtp_filter_arg+0x2067>
    8932:      	cmpq	$0x62, %rsi
    8936:      	ja	0x8913 <generic_rawtp_filter_arg+0x2033>
    8938:      	leaq	0x1(%rsi), %r8
    893c:      	cmpb	%dil, (%rdx,%rsi)
    8940:      	movq	%r8, %rsi
    8943:      	je	0x8920 <generic_rawtp_filter_arg+0x2040>
    8945:      	jmp	0x8913 <generic_rawtp_filter_arg+0x2033>
    8947:      	testl	%ecx, %ecx
    8949:      	jns	0x8bfa <generic_rawtp_filter_arg+0x231a>
    894f:      	leal	0xc(%r12), %eax
    8954:      	cmpl	0x8(%r13), %eax
    8958:      	jae	0x9777 <generic_rawtp_filter_arg+0x2e97>
    895e:      	addl	$0x4, %r12d
    8962:      	incq	%rbx
    8965:      	cmpq	$0x64, %rbx
    8969:      	jne	0x88d1 <generic_rawtp_filter_arg+0x1ff1>
    896f:      	jmp	0x9777 <generic_rawtp_filter_arg+0x2e97>
    8974:      	xorl	%ebx, %ebx
    8976:      	movq	0x8(%rsp), %r9
    897b:      	movq	%r15, %r11
    897e:      	movq	0x68(%rsp), %r15
    8983:      	movq	(%rsp), %rdi
    8987:      	jmp	0x9f1b <generic_rawtp_filter_arg+0x363b>
    898c:      	movzwl	%bp, %eax
    898f:      	cmpl	$0x90, %eax
    8994:      	movq	%r11, 0x10(%rsp)
    8999:      	ja	0x902a <generic_rawtp_filter_arg+0x274a>
    899f:      	testw	%bp, %bp
    89a2:      	je	0x89b4 <generic_rawtp_filter_arg+0x20d4>
    89a4:      	movl	%ebp, %eax
    89a6:      	movl	$0x18, %ecx
    89ab:      	cltd
    89ac:      	idivl	%ecx
    89ae:      	movl	%ebp, %esi
    89b0:      	testl	%edx, %edx
    89b2:      	je	0x89d6 <generic_rawtp_filter_arg+0x20f6>
    89b4:      	movl	%ebp, %eax
    89b6:      	movl	$0x18, %ecx
    89bb:      	cltd
    89bc:      	idivl	%ecx
    89be:      	shll	$0x3, %eax
    89c1:      	leal	(%rax,%rax,2), %eax
    89c4:      	addl	$0x18, %eax
    89c7:      	movzwl	%ax, %esi
    89ca:      	cmpl	$0x90, %esi
    89d0:      	ja	0x9062 <generic_rawtp_filter_arg+0x2782>
    89d6:      	movl	%esi, %eax
    89d8:      	cltd
    89d9:      	idivl	%ecx
    89db:      	decl	%eax
    89dd:      	jmp	0x9795 <generic_rawtp_filter_arg+0x2eb5>
    89e2:      	cmpq	%rdx, %r8
    89e5:      	setbe	%r8b
    89e9:      	cmpq	%rdi, %rdx
    89ec:      	setbe	%dil
    89f0:      	andb	%r8b, %dil
    89f3:      	orb	%dil, %al
    89f6:      	cmpl	$0x29, %esi
    89f9:      	jb	0x992c <generic_rawtp_filter_arg+0x304c>
    89ff:      	movq	0x30(%r13), %r8
    8a03:      	movq	0x38(%r13), %rdi
    8a07:      	cmpl	$0xc, %ecx
    8a0a:      	je	0x8a15 <generic_rawtp_filter_arg+0x2135>
    8a0c:      	cmpl	$0xa, %ecx
    8a0f:      	jne	0x9092 <generic_rawtp_filter_arg+0x27b2>
    8a15:      	cmpq	%rdx, %r8
    8a18:      	setle	%r8b
    8a1c:      	cmpq	%rdi, %rdx
    8a1f:      	setle	%dil
    8a23:      	jmp	0x90a0 <generic_rawtp_filter_arg+0x27c0>
    8a28:      	xorl	%ebx, %ebx
    8a2a:      	cmpl	$0x29, %ecx
    8a2d:      	jne	0x8a38 <generic_rawtp_filter_arg+0x2158>
    8a2f:      	testq	%rdx, %rdx
    8a32:      	je	0x8a38 <generic_rawtp_filter_arg+0x2158>
    8a34:      	movzbl	0x3a(%rdx), %ebx
    8a38:      	cmpl	$0x29, %ecx
    8a3b:      	je	0x8a46 <generic_rawtp_filter_arg+0x2166>
    8a3d:      	cmpl	$0x7, %ecx
    8a40:      	jne	0x8fd0 <generic_rawtp_filter_arg+0x26f0>
    8a46:      	movq	%r11, %r12
    8a49:      	movzbl	0x10(%r13), %eax
    8a4e:      	movl	%eax, 0x34(%rsp)
    8a52:      	movl	$0x1, %eax
    8a57:      	movq	(%rip), %rdi            # 0x8a5e <generic_rawtp_filter_arg+0x217e>
    8a5e:      	leaq	0x34(%rsp), %rsi
    8a63:      	callq	*%rax
    8a65:      	testq	%rax, %rax
    8a68:      	je	0x8a83 <generic_rawtp_filter_arg+0x21a3>
    8a6a:      	movq	%rax, %rdi
    8a6d:      	movl	%ebx, %eax
    8a6f:      	movq	%rax, 0x70(%rsp)
    8a74:      	movl	$0x1, %eax
    8a79:      	movq	0x28(%rsp), %rsi
    8a7e:      	jmp	0x84cf <generic_rawtp_filter_arg+0x1bef>
    8a83:      	xorl	%ebx, %ebx
    8a85:      	movq	(%rsp), %rdi
    8a89:      	movq	0x8(%rsp), %r9
    8a8e:      	movq	%r12, %r11
    8a91:      	jmp	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    8a96:      	xorl	%ebx, %ebx
    8a98:      	movq	%r15, %r11
    8a9b:      	movq	0x68(%rsp), %r15
    8aa0:      	jmp	0x8f73 <generic_rawtp_filter_arg+0x2693>
    8aa5:      	cmpq	%rax, %rdi
    8aa8:      	movq	(%rsp), %rdi
    8aac:      	ja	0x8ab7 <generic_rawtp_filter_arg+0x21d7>
    8aae:      	cmpq	%rsi, %rax
    8ab1:      	jbe	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    8ab7:      	cmpl	$0x29, %edx
    8aba:      	jb	0x69fd <generic_rawtp_filter_arg+0x11d>
    8ac0:      	movq	0x30(%r13), %rdi
    8ac4:      	movq	0x38(%r13), %rsi
    8ac8:      	cmpl	$0xc, %ecx
    8acb:      	je	0x8ad6 <generic_rawtp_filter_arg+0x21f6>
    8acd:      	cmpl	$0xa, %ecx
    8ad0:      	jne	0x90d3 <generic_rawtp_filter_arg+0x27f3>
    8ad6:      	cmpq	%rax, %rdi
    8ad9:      	movq	(%rsp), %rdi
    8add:      	jg	0x90e5 <generic_rawtp_filter_arg+0x2805>
    8ae3:      	cmpq	%rsi, %rax
    8ae6:      	jle	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    8aec:      	jmp	0x90e5 <generic_rawtp_filter_arg+0x2805>
    8af1:      	cmpl	%edx, (%r12)
    8af5:      	ja	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    8afb:      	jmp	0x8b07 <generic_rawtp_filter_arg+0x2227>
    8afd:      	cmpl	%edx, (%r12)
    8b01:      	jb	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    8b07:      	movl	0x8(%r13), %edx
    8b0b:      	cmpl	$0xd, %edx
    8b0e:      	jb	0x9fa1 <generic_rawtp_filter_arg+0x36c1>
    8b14:      	movl	0x14(%r13), %esi
    8b18:      	cmpl	$0x2, %eax
    8b1b:      	jle	0x8b38 <generic_rawtp_filter_arg+0x2258>
    8b1d:      	leal	-0x3(%rax), %edi
    8b20:      	cmpl	$0x2, %edi
    8b23:      	jae	0x8b6e <generic_rawtp_filter_arg+0x228e>
    8b25:      	cmpl	%esi, (%r12)
    8b29:      	movq	(%rsp), %rdi
    8b2d:      	je	0x6ba5 <generic_rawtp_filter_arg+0x2c5>
    8b33:      	jmp	0x95e8 <generic_rawtp_filter_arg+0x2d08>
    8b38:      	cmpl	$0x1, %eax
    8b3b:      	je	0x8b8a <generic_rawtp_filter_arg+0x22aa>
    8b3d:      	cmpl	$0x2, %eax
    8b40:      	jne	0x95e8 <generic_rawtp_filter_arg+0x2d08>
    8b46:      	cmpl	$0xc, %ecx
    8b49:      	ja	0x95de <generic_rawtp_filter_arg+0x2cfe>
    8b4f:      	movl	$0x1402, %r8d           # imm = 0x1402
    8b55:      	btl	%ecx, %r8d
    8b59:      	jae	0x95de <generic_rawtp_filter_arg+0x2cfe>
    8b5f:      	cmpl	%esi, (%r12)
    8b63:      	jl	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    8b69:      	jmp	0x95e8 <generic_rawtp_filter_arg+0x2d08>
    8b6e:      	cmpl	$0xc, %eax
    8b71:      	movq	(%rsp), %rdi
    8b75:      	jne	0x95e8 <generic_rawtp_filter_arg+0x2d08>
    8b7b:      	testl	%esi, (%r12)
    8b7f:      	jne	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    8b85:      	jmp	0x95e8 <generic_rawtp_filter_arg+0x2d08>
    8b8a:      	cmpl	$0xc, %ecx
    8b8d:      	ja	0x95d2 <generic_rawtp_filter_arg+0x2cf2>
    8b93:      	movl	$0x1402, %r8d           # imm = 0x1402
    8b99:      	btl	%ecx, %r8d
    8b9d:      	jae	0x95d2 <generic_rawtp_filter_arg+0x2cf2>
    8ba3:      	cmpl	%esi, (%r12)
    8ba7:      	jg	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    8bad:      	jmp	0x95e8 <generic_rawtp_filter_arg+0x2d08>
    8bb2:      	cmpl	$0x1, %eax
    8bb5:      	je	0x943e <generic_rawtp_filter_arg+0x2b5e>
    8bbb:      	cmpl	$0x2, %eax
    8bbe:      	jne	0x944b <generic_rawtp_filter_arg+0x2b6b>
    8bc4:      	movzbl	(%r12), %esi
    8bc9:      	cmpl	%esi, %edx
    8bcb:      	ja	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    8bd1:      	jmp	0x944b <generic_rawtp_filter_arg+0x2b6b>
    8bd6:      	cmpl	$0x1, %eax
    8bd9:      	je	0x947f <generic_rawtp_filter_arg+0x2b9f>
    8bdf:      	cmpl	$0x2, %eax
    8be2:      	jne	0x948c <generic_rawtp_filter_arg+0x2bac>
    8be8:      	movzwl	(%r12), %esi
    8bed:      	cmpl	%esi, %edx
    8bef:      	ja	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    8bf5:      	jmp	0x948c <generic_rawtp_filter_arg+0x2bac>
    8bfa:      	movl	$0x1, %ebx
    8bff:      	movq	(%rsp), %rdi
    8c03:      	jmp	0x9f1b <generic_rawtp_filter_arg+0x363b>
    8c08:      	movq	(%rsp), %rdi
    8c0c:      	movq	0x8(%rsp), %r9
    8c11:      	movq	%rbp, %r11
    8c14:      	movzbl	%cl, %ebx
    8c17:      	jmp	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    8c1c:      	movl	$0xa, %eax
    8c21:      	jmp	0x8c2f <generic_rawtp_filter_arg+0x234f>
    8c23:      	movl	$0x6, %eax
    8c28:      	jmp	0x8c2f <generic_rawtp_filter_arg+0x234f>
    8c2a:      	movl	$0x8, %eax
    8c2f:      	movl	%eax, %ecx
    8c31:      	andl	$0xf, %ecx
    8c34:      	movl	0x10(%r13,%rcx,4), %ecx
    8c39:      	cmpl	$-0x1, %ecx
    8c3c:      	je	0x9b73 <generic_rawtp_filter_arg+0x3293>
    8c42:      	movl	%ecx, 0x88(%rsp)
    8c49:      	movl	%eax, 0x18(%rsp)
    8c4d:      	movq	%rsi, 0x60(%rsp)
    8c52:      	movl	$0x1, %eax
    8c57:      	movq	(%rip), %rdi            # 0x8c5e <generic_rawtp_filter_arg+0x237e>
    8c5e:      	movq	0x28(%rsp), %rbx
    8c63:      	movq	%rbx, %rsi
    8c66:      	callq	*%rax
    8c68:      	movq	%rax, 0x20(%rsp)
    8c6d:      	movl	$0x1, %eax
    8c72:      	movq	(%rip), %rdi            # 0x8c79 <generic_rawtp_filter_arg+0x2399>
    8c79:      	movq	%rbx, %rsi
    8c7c:      	callq	*%rax
    8c7e:      	movq	0x20(%rsp), %rdx
    8c83:      	testq	%rdx, %rdx
    8c86:      	je	0x9b73 <generic_rawtp_filter_arg+0x3293>
    8c8c:      	movl	$0x0, %ebx
    8c91:      	testq	%rax, %rax
    8c94:      	movq	(%rsp), %rdi
    8c98:      	movq	0x8(%rsp), %r9
    8c9d:      	movq	0x10(%rsp), %r11
    8ca2:      	je	0x9b83 <generic_rawtp_filter_arg+0x32a3>
    8ca8:      	movq	%rdx, %rcx
    8cab:      	movq	%rax, %rbx
    8cae:      	movq	%r12, %rdx
    8cb1:      	addq	$0x4, %rdx
    8cb5:      	cmpl	$0x5, 0x18(%rsp)
    8cba:      	jg	0x8cec <generic_rawtp_filter_arg+0x240c>
    8cbc:      	movq	%rcx, %r12
    8cbf:      	movb	%bpl, (%rcx)
    8cc2:      	leaq	0x1(%rcx), %rdi
    8cc6:      	movl	$0x4, %eax
    8ccb:      	movl	%ebp, %esi
    8ccd:      	callq	*%rax
    8ccf:      	movq	0x60(%rsp), %rsi
    8cd4:      	subl	%ebp, %esi
    8cd6:      	jbe	0x8d20 <generic_rawtp_filter_arg+0x2440>
    8cd8:      	leaq	(%r12,%rbp), %rdi
    8cdc:      	incq	%rdi
    8cdf:      	andl	$0xfff, %esi            # imm = 0xFFF
    8ce5:      	movl	$0x4, %eax
    8cea:      	jmp	0x8d1b <generic_rawtp_filter_arg+0x243b>
    8cec:      	movq	%rcx, %r12
    8cef:      	movw	%bp, (%rcx)
    8cf2:      	leaq	0x2(%rcx), %rdi
    8cf6:      	movl	$0x4, %eax
    8cfb:      	movl	%ebp, %esi
    8cfd:      	callq	*%rax
    8cff:      	movq	0x60(%rsp), %rsi
    8d04:      	subl	%ebp, %esi
    8d06:      	jbe	0x8d20 <generic_rawtp_filter_arg+0x2440>
    8d08:      	leaq	(%r12,%rbp), %rdi
    8d0c:      	addq	$0x2, %rdi
    8d10:      	andl	$0xfff, %esi            # imm = 0xFFF
    8d16:      	movl	$0x4, %eax
    8d1b:      	movq	%rbx, %rdx
    8d1e:      	callq	*%rax
    8d20:      	movl	0x88(%rsp), %eax
    8d27:      	movl	%eax, 0x38(%rsp)
    8d2b:      	movl	0x18(%rsp), %eax
    8d2f:      	cmpl	$0x4, %eax
    8d32:      	movq	(%rsp), %rdi
    8d36:      	movq	0x8(%rsp), %r9
    8d3b:      	movq	0x10(%rsp), %r11
    8d40:      	jle	0x8d7c <generic_rawtp_filter_arg+0x249c>
    8d42:      	cmpl	$0x7, %eax
    8d45:      	jg	0x9390 <generic_rawtp_filter_arg+0x2ab0>
    8d4b:      	cmpl	$0x5, %eax
    8d4e:      	je	0x9a61 <generic_rawtp_filter_arg+0x3181>
    8d54:      	cmpl	$0x6, %eax
    8d57:      	je	0x9a28 <generic_rawtp_filter_arg+0x3148>
    8d5d:      	cmpl	$0x7, %eax
    8d60:      	jne	0x96cc <generic_rawtp_filter_arg+0x2dec>
    8d66:      	movl	$0x1, %eax
    8d6b:      	leaq	0x38(%rsp), %rsi
    8d70:      	movq	(%rip), %rdi            # 0x8d77 <generic_rawtp_filter_arg+0x2497>
    8d77:      	jmp	0x9a85 <generic_rawtp_filter_arg+0x31a5>
    8d7c:      	cmpl	$0x1, %eax
    8d7f:      	jle	0x94c0 <generic_rawtp_filter_arg+0x2be0>
    8d85:      	cmpl	$0x2, %eax
    8d88:      	je	0x9a4e <generic_rawtp_filter_arg+0x316e>
    8d8e:      	cmpl	$0x3, %eax
    8d91:      	je	0x9a15 <generic_rawtp_filter_arg+0x3135>
    8d97:      	cmpl	$0x4, %eax
    8d9a:      	jne	0x96cc <generic_rawtp_filter_arg+0x2dec>
    8da0:      	movl	$0x1, %eax
    8da5:      	leaq	0x38(%rsp), %rsi
    8daa:      	movq	(%rip), %rdi            # 0x8db1 <generic_rawtp_filter_arg+0x24d1>
    8db1:      	jmp	0x9a85 <generic_rawtp_filter_arg+0x31a5>
    8db6:      	movl	$0xa, %eax
    8dbb:      	jmp	0x8dc9 <generic_rawtp_filter_arg+0x24e9>
    8dbd:      	movl	$0x6, %eax
    8dc2:      	jmp	0x8dc9 <generic_rawtp_filter_arg+0x24e9>
    8dc4:      	movl	$0x8, %eax
    8dc9:      	movl	%eax, %ecx
    8dcb:      	andl	$0xf, %ecx
    8dce:      	movl	0x10(%r13,%rcx,4), %ecx
    8dd3:      	cmpl	$-0x1, %ecx
    8dd6:      	je	0x96cc <generic_rawtp_filter_arg+0x2dec>
    8ddc:      	movl	%ecx, 0x90(%rsp)
    8de3:      	movq	%rbx, 0x88(%rsp)
    8deb:      	movl	%eax, 0x20(%rsp)
    8def:      	movq	%r8, 0x18(%rsp)
    8df4:      	movq	%rsi, 0x60(%rsp)
    8df9:      	movq	%r11, 0x10(%rsp)
    8dfe:      	movl	$0x1, %eax
    8e03:      	movq	(%rip), %rdi            # 0x8e0a <generic_rawtp_filter_arg+0x252a>
    8e0a:      	movq	0x28(%rsp), %rbx
    8e0f:      	movq	%rbx, %rsi
    8e12:      	callq	*%rax
    8e14:      	movq	%rax, %r12
    8e17:      	movl	$0x1, %eax
    8e1c:      	movq	(%rip), %rdi            # 0x8e23 <generic_rawtp_filter_arg+0x2543>
    8e23:      	movq	%rbx, %rsi
    8e26:      	callq	*%rax
    8e28:      	testq	%r12, %r12
    8e2b:      	je	0x9b73 <generic_rawtp_filter_arg+0x3293>
    8e31:      	movl	$0x0, %ebx
    8e36:      	testq	%rax, %rax
    8e39:      	movq	(%rsp), %rdi
    8e3d:      	movq	0x8(%rsp), %r9
    8e42:      	movq	0x10(%rsp), %r11
    8e47:      	je	0x9b83 <generic_rawtp_filter_arg+0x32a3>
    8e4d:      	movq	%r12, %rcx
    8e50:      	movq	%rax, %r12
    8e53:      	cmpl	$0x5, 0x20(%rsp)
    8e58:      	jg	0x8e97 <generic_rawtp_filter_arg+0x25b7>
    8e5a:      	movb	%bpl, (%rcx)
    8e5d:      	movq	%rcx, %rbp
    8e60:      	leaq	0x1(%rcx), %rdi
    8e64:      	movl	$0x4, %eax
    8e69:      	movq	0x60(%rsp), %rbx
    8e6e:      	movq	0x18(%rsp), %rdx
    8e73:      	movl	%ebx, %esi
    8e75:      	callq	*%rax
    8e77:      	movq	0x88(%rsp), %rsi
    8e7f:      	subl	%ebx, %esi
    8e81:      	jbe	0x8ed8 <generic_rawtp_filter_arg+0x25f8>
    8e83:      	leaq	(%rbx,%rbp), %rdi
    8e87:      	incq	%rdi
    8e8a:      	andl	$0xfff, %esi            # imm = 0xFFF
    8e90:      	movl	$0x4, %eax
    8e95:      	jmp	0x8ed3 <generic_rawtp_filter_arg+0x25f3>
    8e97:      	movq	0x60(%rsp), %rbx
    8e9c:      	movq	%rcx, %rbp
    8e9f:      	movw	%bx, (%rcx)
    8ea2:      	leaq	0x2(%rcx), %rdi
    8ea6:      	movl	$0x4, %eax
    8eab:      	movq	0x18(%rsp), %rdx
    8eb0:      	movl	%ebx, %esi
    8eb2:      	callq	*%rax
    8eb4:      	movq	0x88(%rsp), %rsi
    8ebc:      	subl	%ebx, %esi
    8ebe:      	jbe	0x8ed8 <generic_rawtp_filter_arg+0x25f8>
    8ec0:      	leaq	(%rbx,%rbp), %rdi
    8ec4:      	addq	$0x2, %rdi
    8ec8:      	andl	$0xfff, %esi            # imm = 0xFFF
    8ece:      	movl	$0x4, %eax
    8ed3:      	movq	%r12, %rdx
    8ed6:      	callq	*%rax
    8ed8:      	movl	0x90(%rsp), %eax
    8edf:      	movl	%eax, 0x38(%rsp)
    8ee3:      	movl	0x20(%rsp), %eax
    8ee7:      	cmpl	$0x4, %eax
    8eea:      	movq	(%rsp), %rdi
    8eee:      	movq	0x8(%rsp), %r9
    8ef3:      	movq	0x10(%rsp), %r11
    8ef8:      	jle	0x8f34 <generic_rawtp_filter_arg+0x2654>
    8efa:      	cmpl	$0x7, %eax
    8efd:      	jg	0x93de <generic_rawtp_filter_arg+0x2afe>
    8f03:      	cmpl	$0x5, %eax
    8f06:      	je	0x9b31 <generic_rawtp_filter_arg+0x3251>
    8f0c:      	cmpl	$0x6, %eax
    8f0f:      	je	0x9af8 <generic_rawtp_filter_arg+0x3218>
    8f15:      	cmpl	$0x7, %eax
    8f18:      	jne	0x96cc <generic_rawtp_filter_arg+0x2dec>
    8f1e:      	movl	$0x1, %eax
    8f23:      	leaq	0x38(%rsp), %rsi
    8f28:      	movq	(%rip), %rdi            # 0x8f2f <generic_rawtp_filter_arg+0x264f>
    8f2f:      	jmp	0x9b55 <generic_rawtp_filter_arg+0x3275>
    8f34:      	cmpl	$0x1, %eax
    8f37:      	jle	0x96a9 <generic_rawtp_filter_arg+0x2dc9>
    8f3d:      	cmpl	$0x2, %eax
    8f40:      	je	0x9b1e <generic_rawtp_filter_arg+0x323e>
    8f46:      	cmpl	$0x3, %eax
    8f49:      	je	0x9ae5 <generic_rawtp_filter_arg+0x3205>
    8f4f:      	cmpl	$0x4, %eax
    8f52:      	jne	0x96cc <generic_rawtp_filter_arg+0x2dec>
    8f58:      	movl	$0x1, %eax
    8f5d:      	leaq	0x38(%rsp), %rsi
    8f62:      	movq	(%rip), %rdi            # 0x8f69 <generic_rawtp_filter_arg+0x2689>
    8f69:      	jmp	0x9b55 <generic_rawtp_filter_arg+0x3275>
    8f6e:      	movl	$0x1, %ebx
    8f73:      	movq	(%rsp), %rdi
    8f77:      	movq	0x8(%rsp), %r9
    8f7c:      	jmp	0x9f1b <generic_rawtp_filter_arg+0x363b>
    8f81:      	cmpl	%edx, %r8d
    8f84:      	setbe	%r8b
    8f88:      	cmpl	%edi, %edx
    8f8a:      	setbe	%dil
    8f8e:      	andb	%r8b, %dil
    8f91:      	orb	%dil, %al
    8f94:      	cmpl	$0x19, %esi
    8f97:      	jb	0x992c <generic_rawtp_filter_arg+0x304c>
    8f9d:      	movl	0x20(%r13), %r8d
    8fa1:      	movl	0x24(%r13), %edi
    8fa5:      	cmpl	$0xc, %ecx
    8fa8:      	ja	0x9518 <generic_rawtp_filter_arg+0x2c38>
    8fae:      	movl	$0x1402, %r10d          # imm = 0x1402
    8fb4:      	btl	%ecx, %r10d
    8fb8:      	jae	0x9518 <generic_rawtp_filter_arg+0x2c38>
    8fbe:      	cmpl	%edx, %r8d
    8fc1:      	setle	%r8b
    8fc5:      	cmpl	%edi, %edx
    8fc7:      	setle	%dil
    8fcb:      	jmp	0x9525 <generic_rawtp_filter_arg+0x2c45>
    8fd0:      	xorl	%ebx, %ebx
    8fd2:      	jmp	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    8fd7:      	cmpl	%eax, %edi
    8fd9:      	movq	(%rsp), %rdi
    8fdd:      	ja	0x8fe7 <generic_rawtp_filter_arg+0x2707>
    8fdf:      	cmpl	%esi, %eax
    8fe1:      	jbe	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    8fe7:      	cmpl	$0x19, %edx
    8fea:      	jb	0x69fd <generic_rawtp_filter_arg+0x11d>
    8ff0:      	movl	0x20(%r13), %edi
    8ff4:      	movl	0x24(%r13), %esi
    8ff8:      	cmpl	$0xc, %ecx
    8ffb:      	ja	0x9583 <generic_rawtp_filter_arg+0x2ca3>
    9001:      	movl	$0x1402, %r8d           # imm = 0x1402
    9007:      	btl	%ecx, %r8d
    900b:      	jae	0x9583 <generic_rawtp_filter_arg+0x2ca3>
    9011:      	cmpl	%eax, %edi
    9013:      	movq	(%rsp), %rdi
    9017:      	jg	0x9593 <generic_rawtp_filter_arg+0x2cb3>
    901d:      	cmpl	%esi, %eax
    901f:      	jle	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9025:      	jmp	0x9593 <generic_rawtp_filter_arg+0x2cb3>
    902a:      	movl	$0x100, %esi            # imm = 0x100
    902f:      	cmpl	$0x101, %eax            # imm = 0x101
    9034:      	jb	0x9062 <generic_rawtp_filter_arg+0x2782>
    9036:      	movl	$0x200, %esi            # imm = 0x200
    903b:      	cmpl	$0x201, %eax            # imm = 0x201
    9040:      	jb	0x9062 <generic_rawtp_filter_arg+0x2782>
    9042:      	movl	$0x400, %esi            # imm = 0x400
    9047:      	cmpl	$0x401, %eax            # imm = 0x401
    904c:      	jb	0x9062 <generic_rawtp_filter_arg+0x2782>
    904e:      	xorl	%esi, %esi
    9050:      	cmpl	$0x801, %eax            # imm = 0x801
    9055:      	setae	%sil
    9059:      	shll	$0xb, %esi
    905c:      	addl	$0x800, %esi            # imm = 0x800
    9062:      	leal	-0x100(%rsi), %eax
    9068:      	rorxl	$0x8, %eax, %eax
    906e:      	cmpl	$0x2, %eax
    9071:      	jg	0x9422 <generic_rawtp_filter_arg+0x2b42>
    9077:      	testl	%eax, %eax
    9079:      	je	0x9789 <generic_rawtp_filter_arg+0x2ea9>
    907f:      	cmpl	$0x1, %eax
    9082:      	jne	0x9782 <generic_rawtp_filter_arg+0x2ea2>
    9088:      	movl	$0x7, %eax
    908d:      	jmp	0x9795 <generic_rawtp_filter_arg+0x2eb5>
    9092:      	cmpq	%rdx, %r8
    9095:      	setbe	%r8b
    9099:      	cmpq	%rdi, %rdx
    909c:      	setbe	%dil
    90a0:      	andb	%r8b, %dil
    90a3:      	orb	%dil, %al
    90a6:      	cmpl	$0x39, %esi
    90a9:      	jb	0x992c <generic_rawtp_filter_arg+0x304c>
    90af:      	movq	0x40(%r13), %rdi
    90b3:      	movq	0x48(%r13), %rsi
    90b7:      	cmpl	$0xc, %ecx
    90ba:      	je	0x90c5 <generic_rawtp_filter_arg+0x27e5>
    90bc:      	cmpl	$0xa, %ecx
    90bf:      	jne	0x968f <generic_rawtp_filter_arg+0x2daf>
    90c5:      	cmpq	%rdx, %rdi
    90c8:      	setle	%cl
    90cb:      	cmpq	%rsi, %rdx
    90ce:      	jmp	0x955c <generic_rawtp_filter_arg+0x2c7c>
    90d3:      	cmpq	%rax, %rdi
    90d6:      	movq	(%rsp), %rdi
    90da:      	ja	0x90e5 <generic_rawtp_filter_arg+0x2805>
    90dc:      	cmpq	%rsi, %rax
    90df:      	jbe	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    90e5:      	cmpl	$0x39, %edx
    90e8:      	jb	0x69fd <generic_rawtp_filter_arg+0x11d>
    90ee:      	movq	0x40(%r13), %rsi
    90f2:      	movq	0x48(%r13), %rdx
    90f6:      	cmpl	$0xc, %ecx
    90f9:      	je	0x9104 <generic_rawtp_filter_arg+0x2824>
    90fb:      	cmpl	$0xa, %ecx
    90fe:      	jne	0x96f5 <generic_rawtp_filter_arg+0x2e15>
    9104:      	cmpq	%rax, %rsi
    9107:      	jg	0x69fd <generic_rawtp_filter_arg+0x11d>
    910d:      	cmpq	%rdx, %rax
    9110:      	jle	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9116:      	jmp	0x69fd <generic_rawtp_filter_arg+0x11d>
    911b:      	cmpq	%rsi, (%r12)
    911f:      	ja	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9125:      	jmp	0x9131 <generic_rawtp_filter_arg+0x2851>
    9127:      	cmpq	%rsi, (%r12)
    912b:      	jb	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9131:      	cmpl	$0x19, %edx
    9134:      	jb	0x9fa1 <generic_rawtp_filter_arg+0x36c1>
    913a:      	movq	0x20(%r13), %rsi
    913e:      	cmpl	$0x2, %eax
    9141:      	jle	0x915e <generic_rawtp_filter_arg+0x287e>
    9143:      	leal	-0x3(%rax), %edi
    9146:      	cmpl	$0x2, %edi
    9149:      	jae	0x918d <generic_rawtp_filter_arg+0x28ad>
    914b:      	cmpq	%rsi, (%r12)
    914f:      	movq	(%rsp), %rdi
    9153:      	je	0x6ba5 <generic_rawtp_filter_arg+0x2c5>
    9159:      	jmp	0x9953 <generic_rawtp_filter_arg+0x3073>
    915e:      	cmpl	$0x1, %eax
    9161:      	je	0x93c1 <generic_rawtp_filter_arg+0x2ae1>
    9167:      	cmpl	$0x2, %eax
    916a:      	jne	0x9953 <generic_rawtp_filter_arg+0x3073>
    9170:      	cmpl	$0xc, %ecx
    9173:      	je	0x917e <generic_rawtp_filter_arg+0x289e>
    9175:      	cmpl	$0xa, %ecx
    9178:      	jne	0x9949 <generic_rawtp_filter_arg+0x3069>
    917e:      	cmpq	%rsi, (%r12)
    9182:      	jl	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9188:      	jmp	0x9953 <generic_rawtp_filter_arg+0x3073>
    918d:      	cmpl	$0xc, %eax
    9190:      	movq	(%rsp), %rdi
    9194:      	jne	0x9953 <generic_rawtp_filter_arg+0x3073>
    919a:      	testq	%rsi, (%r12)
    919e:      	jne	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    91a4:      	jmp	0x9953 <generic_rawtp_filter_arg+0x3073>
    91a9:      	movl	$0xa, %eax
    91ae:      	jmp	0x91bc <generic_rawtp_filter_arg+0x28dc>
    91b0:      	movl	$0x6, %eax
    91b5:      	jmp	0x91bc <generic_rawtp_filter_arg+0x28dc>
    91b7:      	movl	$0x8, %eax
    91bc:      	movl	%eax, %ecx
    91be:      	andl	$0xf, %ecx
    91c1:      	movl	0x10(%r13,%rcx,4), %ecx
    91c6:      	cmpl	$-0x1, %ecx
    91c9:      	je	0x9777 <generic_rawtp_filter_arg+0x2e97>
    91cf:      	movl	%ecx, 0x88(%rsp)
    91d6:      	movl	%eax, 0x60(%rsp)
    91da:      	movq	%rsi, 0x90(%rsp)
    91e2:      	movq	%r11, 0x10(%rsp)
    91e7:      	movl	$0x1, %eax
    91ec:      	movq	(%rip), %rdi            # 0x91f3 <generic_rawtp_filter_arg+0x2913>
    91f3:      	movq	0x28(%rsp), %rbx
    91f8:      	movq	%rbx, %rsi
    91fb:      	callq	*%rax
    91fd:      	movq	%rax, %r12
    9200:      	movl	$0x1, %eax
    9205:      	movq	(%rip), %rdi            # 0x920c <generic_rawtp_filter_arg+0x292c>
    920c:      	movq	%rbx, %rsi
    920f:      	callq	*%rax
    9211:      	movq	%r12, 0x20(%rsp)
    9216:      	testq	%r12, %r12
    9219:      	je	0x9f0b <generic_rawtp_filter_arg+0x362b>
    921f:      	movl	$0x0, %ebx
    9224:      	testq	%rax, %rax
    9227:      	movq	(%rsp), %rdi
    922b:      	movq	0x8(%rsp), %r9
    9230:      	movq	0x10(%rsp), %r11
    9235:      	je	0x9f1b <generic_rawtp_filter_arg+0x363b>
    923b:      	movq	%rax, %r12
    923e:      	movl	0x60(%rsp), %ebx
    9242:      	cmpl	$0x5, %ebx
    9245:      	jg	0x9289 <generic_rawtp_filter_arg+0x29a9>
    9247:      	movq	0x20(%rsp), %rax
    924c:      	movb	%bpl, (%rax)
    924f:      	leaq	0x1(%rax), %rdi
    9253:      	movl	$0x4, %eax
    9258:      	movq	0x18(%rsp), %rdx
    925d:      	movl	%ebp, %esi
    925f:      	callq	*%rax
    9261:      	movq	0x90(%rsp), %rsi
    9269:      	subl	%ebp, %esi
    926b:      	jbe	0x92cc <generic_rawtp_filter_arg+0x29ec>
    926d:      	movq	0x20(%rsp), %rax
    9272:      	leaq	(%rax,%rbp), %rdi
    9276:      	incq	%rdi
    9279:      	andl	$0xfff, %esi            # imm = 0xFFF
    927f:      	movl	$0x4, %eax
    9284:      	movq	%r12, %rdx
    9287:      	jmp	0x92ca <generic_rawtp_filter_arg+0x29ea>
    9289:      	movq	0x20(%rsp), %rax
    928e:      	movw	%bp, (%rax)
    9291:      	leaq	0x2(%rax), %rdi
    9295:      	movl	$0x4, %eax
    929a:      	movq	0x18(%rsp), %rdx
    929f:      	movl	%ebp, %esi
    92a1:      	callq	*%rax
    92a3:      	movq	0x90(%rsp), %rsi
    92ab:      	subl	%ebp, %esi
    92ad:      	jbe	0x92cc <generic_rawtp_filter_arg+0x29ec>
    92af:      	movq	0x20(%rsp), %rax
    92b4:      	leaq	(%rax,%rbp), %rdi
    92b8:      	addq	$0x2, %rdi
    92bc:      	andl	$0xfff, %esi            # imm = 0xFFF
    92c2:      	movl	$0x4, %eax
    92c7:      	movq	%r12, %rdx
    92ca:      	callq	*%rax
    92cc:      	movl	0x88(%rsp), %eax
    92d3:      	movl	%eax, 0x38(%rsp)
    92d7:      	cmpl	$0x4, %ebx
    92da:      	movq	0x8(%rsp), %r9
    92df:      	movq	0x10(%rsp), %r11
    92e4:      	jle	0x9320 <generic_rawtp_filter_arg+0x2a40>
    92e6:      	cmpl	$0x7, %ebx
    92e9:      	jg	0x94e7 <generic_rawtp_filter_arg+0x2c07>
    92ef:      	cmpl	$0x5, %ebx
    92f2:      	je	0x9c0d <generic_rawtp_filter_arg+0x332d>
    92f8:      	cmpl	$0x6, %ebx
    92fb:      	je	0x9bd4 <generic_rawtp_filter_arg+0x32f4>
    9301:      	cmpl	$0x7, %ebx
    9304:      	jne	0x9777 <generic_rawtp_filter_arg+0x2e97>
    930a:      	movl	$0x1, %eax
    930f:      	leaq	0x38(%rsp), %rsi
    9314:      	movq	(%rip), %rdi            # 0x931b <generic_rawtp_filter_arg+0x2a3b>
    931b:      	jmp	0x9c31 <generic_rawtp_filter_arg+0x3351>
    9320:      	cmpl	$0x1, %ebx
    9323:      	jle	0x9754 <generic_rawtp_filter_arg+0x2e74>
    9329:      	cmpl	$0x2, %ebx
    932c:      	je	0x9bfa <generic_rawtp_filter_arg+0x331a>
    9332:      	cmpl	$0x3, %ebx
    9335:      	je	0x9bc1 <generic_rawtp_filter_arg+0x32e1>
    933b:      	cmpl	$0x4, %ebx
    933e:      	jne	0x9777 <generic_rawtp_filter_arg+0x2e97>
    9344:      	movl	$0x1, %eax
    9349:      	leaq	0x38(%rsp), %rsi
    934e:      	movq	(%rip), %rdi            # 0x9355 <generic_rawtp_filter_arg+0x2a75>
    9355:      	jmp	0x9c31 <generic_rawtp_filter_arg+0x3351>
    935a:      	cmpl	$0xc, %eax
    935d:      	jne	0x944b <generic_rawtp_filter_arg+0x2b6b>
    9363:      	movzbl	(%r12), %esi
    9368:      	testl	%esi, %edx
    936a:      	jne	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9370:      	jmp	0x944b <generic_rawtp_filter_arg+0x2b6b>
    9375:      	cmpl	$0xc, %eax
    9378:      	jne	0x948c <generic_rawtp_filter_arg+0x2bac>
    937e:      	movzwl	(%r12), %esi
    9383:      	testl	%esi, %edx
    9385:      	jne	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    938b:      	jmp	0x948c <generic_rawtp_filter_arg+0x2bac>
    9390:      	cmpl	$0x8, %eax
    9393:      	je	0x9a74 <generic_rawtp_filter_arg+0x3194>
    9399:      	cmpl	$0x9, %eax
    939c:      	je	0x9a3b <generic_rawtp_filter_arg+0x315b>
    93a2:      	cmpl	$0xa, %eax
    93a5:      	jne	0x96cc <generic_rawtp_filter_arg+0x2dec>
    93ab:      	movl	$0x1, %eax
    93b0:      	leaq	0x38(%rsp), %rsi
    93b5:      	movq	(%rip), %rdi            # 0x93bc <generic_rawtp_filter_arg+0x2adc>
    93bc:      	jmp	0x9a85 <generic_rawtp_filter_arg+0x31a5>
    93c1:      	cmpl	$0xc, %ecx
    93c4:      	je	0x93cf <generic_rawtp_filter_arg+0x2aef>
    93c6:      	cmpl	$0xa, %ecx
    93c9:      	jne	0x993d <generic_rawtp_filter_arg+0x305d>
    93cf:      	cmpq	%rsi, (%r12)
    93d3:      	jg	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    93d9:      	jmp	0x9953 <generic_rawtp_filter_arg+0x3073>
    93de:      	cmpl	$0x8, %eax
    93e1:      	je	0x9b44 <generic_rawtp_filter_arg+0x3264>
    93e7:      	cmpl	$0x9, %eax
    93ea:      	je	0x9b0b <generic_rawtp_filter_arg+0x322b>
    93f0:      	cmpl	$0xa, %eax
    93f3:      	jne	0x96cc <generic_rawtp_filter_arg+0x2dec>
    93f9:      	movl	$0x1, %eax
    93fe:      	leaq	0x38(%rsp), %rsi
    9403:      	movq	(%rip), %rdi            # 0x940a <generic_rawtp_filter_arg+0x2b2a>
    940a:      	jmp	0x9b55 <generic_rawtp_filter_arg+0x3275>
    940f:      	movq	(%rsp), %rdi
    9413:      	movq	0x8(%rsp), %r9
    9418:      	movq	0x10(%rsp), %r11
    941d:      	jmp	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    9422:      	cmpl	$0x3, %eax
    9425:      	je	0x9790 <generic_rawtp_filter_arg+0x2eb0>
    942b:      	cmpl	$0x7, %eax
    942e:      	jne	0x9782 <generic_rawtp_filter_arg+0x2ea2>
    9434:      	movl	$0x9, %eax
    9439:      	jmp	0x9795 <generic_rawtp_filter_arg+0x2eb5>
    943e:      	movzbl	(%r12), %esi
    9443:      	cmpl	%esi, %edx
    9445:      	jb	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    944b:      	cmpl	$0x11, %ecx
    944e:      	jb	0x9fa1 <generic_rawtp_filter_arg+0x36c1>
    9454:      	movl	0x18(%r13), %edx
    9458:      	cmpl	$0x2, %eax
    945b:      	jle	0x970c <generic_rawtp_filter_arg+0x2e2c>
    9461:      	leal	-0x3(%rax), %esi
    9464:      	cmpl	$0x2, %esi
    9467:      	jae	0x99cc <generic_rawtp_filter_arg+0x30ec>
    946d:      	movzbl	(%r12), %esi
    9472:      	cmpl	%esi, %edx
    9474:      	je	0x6ba5 <generic_rawtp_filter_arg+0x2c5>
    947a:      	jmp	0x9c5b <generic_rawtp_filter_arg+0x337b>
    947f:      	movzwl	(%r12), %esi
    9484:      	cmpl	%esi, %edx
    9486:      	jb	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    948c:      	cmpl	$0x11, %ecx
    948f:      	jb	0x9fa1 <generic_rawtp_filter_arg+0x36c1>
    9495:      	movl	0x18(%r13), %edx
    9499:      	cmpl	$0x2, %eax
    949c:      	jle	0x9730 <generic_rawtp_filter_arg+0x2e50>
    94a2:      	leal	-0x3(%rax), %esi
    94a5:      	cmpl	$0x2, %esi
    94a8:      	jae	0x99e7 <generic_rawtp_filter_arg+0x3107>
    94ae:      	movzwl	(%r12), %esi
    94b3:      	cmpl	%esi, %edx
    94b5:      	je	0x6ba5 <generic_rawtp_filter_arg+0x2c5>
    94bb:      	jmp	0x9ca3 <generic_rawtp_filter_arg+0x33c3>
    94c0:      	testl	%eax, %eax
    94c2:      	je	0x9a02 <generic_rawtp_filter_arg+0x3122>
    94c8:      	cmpl	$0x1, %eax
    94cb:      	jne	0x96cc <generic_rawtp_filter_arg+0x2dec>
    94d1:      	movl	$0x1, %eax
    94d6:      	leaq	0x38(%rsp), %rsi
    94db:      	movq	(%rip), %rdi            # 0x94e2 <generic_rawtp_filter_arg+0x2c02>
    94e2:      	jmp	0x9a85 <generic_rawtp_filter_arg+0x31a5>
    94e7:      	cmpl	$0x8, %ebx
    94ea:      	je	0x9c20 <generic_rawtp_filter_arg+0x3340>
    94f0:      	cmpl	$0x9, %ebx
    94f3:      	je	0x9be7 <generic_rawtp_filter_arg+0x3307>
    94f9:      	cmpl	$0xa, %ebx
    94fc:      	jne	0x9777 <generic_rawtp_filter_arg+0x2e97>
    9502:      	movl	$0x1, %eax
    9507:      	leaq	0x38(%rsp), %rsi
    950c:      	movq	(%rip), %rdi            # 0x9513 <generic_rawtp_filter_arg+0x2c33>
    9513:      	jmp	0x9c31 <generic_rawtp_filter_arg+0x3351>
    9518:      	cmpl	%edx, %r8d
    951b:      	setbe	%r8b
    951f:      	cmpl	%edi, %edx
    9521:      	setbe	%dil
    9525:      	andb	%r8b, %dil
    9528:      	orb	%dil, %al
    952b:      	cmpl	$0x21, %esi
    952e:      	jb	0x992c <generic_rawtp_filter_arg+0x304c>
    9534:      	movl	0x28(%r13), %edi
    9538:      	movl	0x2c(%r13), %esi
    953c:      	cmpl	$0xc, %ecx
    953f:      	ja	0x991e <generic_rawtp_filter_arg+0x303e>
    9545:      	movl	$0x1402, %r8d           # imm = 0x1402
    954b:      	btl	%ecx, %r8d
    954f:      	jae	0x991e <generic_rawtp_filter_arg+0x303e>
    9555:      	cmpl	%edx, %edi
    9557:      	setle	%cl
    955a:      	cmpl	%esi, %edx
    955c:      	setle	%dl
    955f:      	jmp	0x9928 <generic_rawtp_filter_arg+0x3048>
    9564:      	xorl	%ebx, %ebx
    9566:      	jmp	0x956d <generic_rawtp_filter_arg+0x2c8d>
    9568:      	movl	$0x1, %ebx
    956d:      	movq	(%rsp), %rdi
    9571:      	movq	0x8(%rsp), %r9
    9576:      	movq	%r15, %r11
    9579:      	movq	0x68(%rsp), %r15
    957e:      	jmp	0x9f1b <generic_rawtp_filter_arg+0x363b>
    9583:      	cmpl	%eax, %edi
    9585:      	movq	(%rsp), %rdi
    9589:      	ja	0x9593 <generic_rawtp_filter_arg+0x2cb3>
    958b:      	cmpl	%esi, %eax
    958d:      	jbe	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9593:      	cmpl	$0x21, %edx
    9596:      	jb	0x69fd <generic_rawtp_filter_arg+0x11d>
    959c:      	movl	0x28(%r13), %esi
    95a0:      	movl	0x2c(%r13), %edx
    95a4:      	cmpl	$0xc, %ecx
    95a7:      	ja	0x9aa0 <generic_rawtp_filter_arg+0x31c0>
    95ad:      	movl	$0x1402, %r8d           # imm = 0x1402
    95b3:      	btl	%ecx, %r8d
    95b7:      	jae	0x9aa0 <generic_rawtp_filter_arg+0x31c0>
    95bd:      	cmpl	%eax, %esi
    95bf:      	jg	0x69fd <generic_rawtp_filter_arg+0x11d>
    95c5:      	cmpl	%edx, %eax
    95c7:      	jle	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    95cd:      	jmp	0x69fd <generic_rawtp_filter_arg+0x11d>
    95d2:      	cmpl	%esi, (%r12)
    95d6:      	ja	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    95dc:      	jmp	0x95e8 <generic_rawtp_filter_arg+0x2d08>
    95de:      	cmpl	%esi, (%r12)
    95e2:      	jb	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    95e8:      	cmpl	$0x11, %edx
    95eb:      	jb	0x9fa1 <generic_rawtp_filter_arg+0x36c1>
    95f1:      	movl	0x18(%r13), %esi
    95f5:      	cmpl	$0x2, %eax
    95f8:      	jle	0x9615 <generic_rawtp_filter_arg+0x2d35>
    95fa:      	leal	-0x3(%rax), %edi
    95fd:      	cmpl	$0x2, %edi
    9600:      	jae	0x964b <generic_rawtp_filter_arg+0x2d6b>
    9602:      	cmpl	%esi, (%r12)
    9606:      	movq	(%rsp), %rdi
    960a:      	je	0x6ba5 <generic_rawtp_filter_arg+0x2c5>
    9610:      	jmp	0x9d30 <generic_rawtp_filter_arg+0x3450>
    9615:      	cmpl	$0x1, %eax
    9618:      	je	0x9667 <generic_rawtp_filter_arg+0x2d87>
    961a:      	cmpl	$0x2, %eax
    961d:      	jne	0x9d30 <generic_rawtp_filter_arg+0x3450>
    9623:      	cmpl	$0xc, %ecx
    9626:      	ja	0x9d26 <generic_rawtp_filter_arg+0x3446>
    962c:      	movl	$0x1402, %r8d           # imm = 0x1402
    9632:      	btl	%ecx, %r8d
    9636:      	jae	0x9d26 <generic_rawtp_filter_arg+0x3446>
    963c:      	cmpl	%esi, (%r12)
    9640:      	jl	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9646:      	jmp	0x9d30 <generic_rawtp_filter_arg+0x3450>
    964b:      	cmpl	$0xc, %eax
    964e:      	movq	(%rsp), %rdi
    9652:      	jne	0x9d30 <generic_rawtp_filter_arg+0x3450>
    9658:      	testl	%esi, (%r12)
    965c:      	jne	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9662:      	jmp	0x9d30 <generic_rawtp_filter_arg+0x3450>
    9667:      	cmpl	$0xc, %ecx
    966a:      	ja	0x9d1a <generic_rawtp_filter_arg+0x343a>
    9670:      	movl	$0x1402, %r8d           # imm = 0x1402
    9676:      	btl	%ecx, %r8d
    967a:      	jae	0x9d1a <generic_rawtp_filter_arg+0x343a>
    9680:      	cmpl	%esi, (%r12)
    9684:      	jg	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    968a:      	jmp	0x9d30 <generic_rawtp_filter_arg+0x3450>
    968f:      	cmpq	%rdx, %rdi
    9692:      	setbe	%cl
    9695:      	cmpq	%rsi, %rdx
    9698:      	jmp	0x9925 <generic_rawtp_filter_arg+0x3045>
    969d:      	xorl	%ebx, %ebx
    969f:      	movq	0x68(%rsp), %r15
    96a4:      	jmp	0x9f1b <generic_rawtp_filter_arg+0x363b>
    96a9:      	testl	%eax, %eax
    96ab:      	je	0x9ad2 <generic_rawtp_filter_arg+0x31f2>
    96b1:      	cmpl	$0x1, %eax
    96b4:      	jne	0x96cc <generic_rawtp_filter_arg+0x2dec>
    96b6:      	movl	$0x1, %eax
    96bb:      	leaq	0x38(%rsp), %rsi
    96c0:      	movq	(%rip), %rdi            # 0x96c7 <generic_rawtp_filter_arg+0x2de7>
    96c7:      	jmp	0x9b55 <generic_rawtp_filter_arg+0x3275>
    96cc:      	xorl	%ebx, %ebx
    96ce:      	movl	0x4(%r13), %eax
    96d2:      	cmpq	$0x25, %rax
    96d6:      	jbe	0x9b91 <generic_rawtp_filter_arg+0x32b1>
    96dc:      	jmp	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    96e1:      	movq	(%rsp), %rdi
    96e5:      	movq	0x8(%rsp), %r9
    96ea:      	movq	%r12, %r11
    96ed:      	movzbl	%cl, %ebx
    96f0:      	jmp	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    96f5:      	cmpq	%rax, %rsi
    96f8:      	ja	0x69fd <generic_rawtp_filter_arg+0x11d>
    96fe:      	cmpq	%rdx, %rax
    9701:      	jbe	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9707:      	jmp	0x69fd <generic_rawtp_filter_arg+0x11d>
    970c:      	cmpl	$0x1, %eax
    970f:      	je	0x9c4e <generic_rawtp_filter_arg+0x336e>
    9715:      	cmpl	$0x2, %eax
    9718:      	jne	0x9c5b <generic_rawtp_filter_arg+0x337b>
    971e:      	movzbl	(%r12), %esi
    9723:      	cmpl	%esi, %edx
    9725:      	ja	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    972b:      	jmp	0x9c5b <generic_rawtp_filter_arg+0x337b>
    9730:      	cmpl	$0x1, %eax
    9733:      	je	0x9c96 <generic_rawtp_filter_arg+0x33b6>
    9739:      	cmpl	$0x2, %eax
    973c:      	jne	0x9ca3 <generic_rawtp_filter_arg+0x33c3>
    9742:      	movzwl	(%r12), %esi
    9747:      	cmpl	%esi, %edx
    9749:      	ja	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    974f:      	jmp	0x9ca3 <generic_rawtp_filter_arg+0x33c3>
    9754:      	testl	%ebx, %ebx
    9756:      	je	0x9bae <generic_rawtp_filter_arg+0x32ce>
    975c:      	cmpl	$0x1, %ebx
    975f:      	jne	0x9777 <generic_rawtp_filter_arg+0x2e97>
    9761:      	movl	$0x1, %eax
    9766:      	leaq	0x38(%rsp), %rsi
    976b:      	movq	(%rip), %rdi            # 0x9772 <generic_rawtp_filter_arg+0x2e92>
    9772:      	jmp	0x9c31 <generic_rawtp_filter_arg+0x3351>
    9777:      	xorl	%ebx, %ebx
    9779:      	movq	(%rsp), %rdi
    977d:      	jmp	0x9f1b <generic_rawtp_filter_arg+0x363b>
    9782:      	movl	$0xa, %eax
    9787:      	jmp	0x9795 <generic_rawtp_filter_arg+0x2eb5>
    9789:      	movl	$0x6, %eax
    978e:      	jmp	0x9795 <generic_rawtp_filter_arg+0x2eb5>
    9790:      	movl	$0x8, %eax
    9795:      	movl	%eax, %ecx
    9797:      	andl	$0xf, %ecx
    979a:      	movl	0x10(%r13,%rcx,4), %ecx
    979f:      	cmpl	$-0x1, %ecx
    97a2:      	je	0x9f0b <generic_rawtp_filter_arg+0x362b>
    97a8:      	movl	%ecx, 0x90(%rsp)
    97af:      	movl	%eax, 0x88(%rsp)
    97b6:      	movq	%rsi, 0x60(%rsp)
    97bb:      	movl	$0x1, %eax
    97c0:      	movq	(%rip), %rdi            # 0x97c7 <generic_rawtp_filter_arg+0x2ee7>
    97c7:      	movq	0x28(%rsp), %rbx
    97cc:      	movq	%rbx, %rsi
    97cf:      	callq	*%rax
    97d1:      	movq	%rax, %r12
    97d4:      	movl	$0x1, %eax
    97d9:      	movq	(%rip), %rdi            # 0x97e0 <generic_rawtp_filter_arg+0x2f00>
    97e0:      	movq	%rbx, %rsi
    97e3:      	callq	*%rax
    97e5:      	movq	%r12, 0x20(%rsp)
    97ea:      	testq	%r12, %r12
    97ed:      	je	0x9f0b <generic_rawtp_filter_arg+0x362b>
    97f3:      	movl	$0x0, %ebx
    97f8:      	testq	%rax, %rax
    97fb:      	movq	(%rsp), %rdi
    97ff:      	movq	0x8(%rsp), %r9
    9804:      	movq	0x10(%rsp), %r11
    9809:      	je	0x9f1b <generic_rawtp_filter_arg+0x363b>
    980f:      	movq	%rax, %r12
    9812:      	movl	0x88(%rsp), %ebx
    9819:      	cmpl	$0x5, %ebx
    981c:      	jg	0x985a <generic_rawtp_filter_arg+0x2f7a>
    981e:      	movq	0x20(%rsp), %rax
    9823:      	movb	%bpl, (%rax)
    9826:      	leaq	0x1(%rax), %rdi
    982a:      	movl	$0x4, %eax
    982f:      	movq	0x18(%rsp), %rdx
    9834:      	movl	%ebp, %esi
    9836:      	callq	*%rax
    9838:      	movq	0x60(%rsp), %rsi
    983d:      	subl	%ebp, %esi
    983f:      	jbe	0x989a <generic_rawtp_filter_arg+0x2fba>
    9841:      	movq	0x20(%rsp), %rax
    9846:      	leaq	(%rax,%rbp), %rdi
    984a:      	incq	%rdi
    984d:      	andl	$0xfff, %esi            # imm = 0xFFF
    9853:      	movl	$0x4, %eax
    9858:      	jmp	0x9895 <generic_rawtp_filter_arg+0x2fb5>
    985a:      	movq	0x20(%rsp), %rax
    985f:      	movw	%bp, (%rax)
    9862:      	leaq	0x2(%rax), %rdi
    9866:      	movl	$0x4, %eax
    986b:      	movq	0x18(%rsp), %rdx
    9870:      	movl	%ebp, %esi
    9872:      	callq	*%rax
    9874:      	movq	0x60(%rsp), %rsi
    9879:      	subl	%ebp, %esi
    987b:      	jbe	0x989a <generic_rawtp_filter_arg+0x2fba>
    987d:      	movq	0x20(%rsp), %rax
    9882:      	leaq	(%rax,%rbp), %rdi
    9886:      	addq	$0x2, %rdi
    988a:      	andl	$0xfff, %esi            # imm = 0xFFF
    9890:      	movl	$0x4, %eax
    9895:      	movq	%r12, %rdx
    9898:      	callq	*%rax
    989a:      	movl	0x90(%rsp), %eax
    98a1:      	movl	%eax, 0x38(%rsp)
    98a5:      	cmpl	$0x4, %ebx
    98a8:      	jle	0x98e4 <generic_rawtp_filter_arg+0x3004>
    98aa:      	cmpl	$0x7, %ebx
    98ad:      	jg	0x9ce9 <generic_rawtp_filter_arg+0x3409>
    98b3:      	cmpl	$0x5, %ebx
    98b6:      	je	0x9ece <generic_rawtp_filter_arg+0x35ee>
    98bc:      	cmpl	$0x6, %ebx
    98bf:      	je	0x9e95 <generic_rawtp_filter_arg+0x35b5>
    98c5:      	cmpl	$0x7, %ebx
    98c8:      	jne	0x9f0b <generic_rawtp_filter_arg+0x362b>
    98ce:      	movl	$0x1, %eax
    98d3:      	leaq	0x38(%rsp), %rsi
    98d8:      	movq	(%rip), %rdi            # 0x98df <generic_rawtp_filter_arg+0x2fff>
    98df:      	jmp	0x9ef2 <generic_rawtp_filter_arg+0x3612>
    98e4:      	cmpl	$0x1, %ebx
    98e7:      	jle	0x9dd4 <generic_rawtp_filter_arg+0x34f4>
    98ed:      	cmpl	$0x2, %ebx
    98f0:      	je	0x9ebb <generic_rawtp_filter_arg+0x35db>
    98f6:      	cmpl	$0x3, %ebx
    98f9:      	je	0x9e82 <generic_rawtp_filter_arg+0x35a2>
    98ff:      	cmpl	$0x4, %ebx
    9902:      	jne	0x9f0b <generic_rawtp_filter_arg+0x362b>
    9908:      	movl	$0x1, %eax
    990d:      	leaq	0x38(%rsp), %rsi
    9912:      	movq	(%rip), %rdi            # 0x9919 <generic_rawtp_filter_arg+0x3039>
    9919:      	jmp	0x9ef2 <generic_rawtp_filter_arg+0x3612>
    991e:      	cmpl	%edx, %edi
    9920:      	setbe	%cl
    9923:      	cmpl	%esi, %edx
    9925:      	setbe	%dl
    9928:      	andb	%cl, %dl
    992a:      	orb	%dl, %al
    992c:      	movq	(%rsp), %rdi
    9930:      	testb	%al, %al
    9932:      	je	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9938:      	jmp	0x69fd <generic_rawtp_filter_arg+0x11d>
    993d:      	cmpq	%rsi, (%r12)
    9941:      	ja	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9947:      	jmp	0x9953 <generic_rawtp_filter_arg+0x3073>
    9949:      	cmpq	%rsi, (%r12)
    994d:      	jb	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9953:      	cmpl	$0x21, %edx
    9956:      	jb	0x9fa1 <generic_rawtp_filter_arg+0x36c1>
    995c:      	movq	0x28(%r13), %rdx
    9960:      	cmpl	$0x2, %eax
    9963:      	jle	0x998e <generic_rawtp_filter_arg+0x30ae>
    9965:      	leal	-0x3(%rax), %ecx
    9968:      	cmpl	$0x2, %ecx
    996b:      	jb	0x99bd <generic_rawtp_filter_arg+0x30dd>
    996d:      	cmpl	$0x6, %eax
    9970:      	je	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9976:      	cmpl	$0xc, %eax
    9979:      	jne	0x69fd <generic_rawtp_filter_arg+0x11d>
    997f:      	testq	%rdx, (%r12)
    9983:      	jne	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9989:      	jmp	0x9fa1 <generic_rawtp_filter_arg+0x36c1>
    998e:      	cmpl	$0x1, %eax
    9991:      	je	0x9ab5 <generic_rawtp_filter_arg+0x31d5>
    9997:      	cmpl	$0x2, %eax
    999a:      	jne	0x69fd <generic_rawtp_filter_arg+0x11d>
    99a0:      	cmpl	$0xc, %ecx
    99a3:      	je	0x99ae <generic_rawtp_filter_arg+0x30ce>
    99a5:      	cmpl	$0xa, %ecx
    99a8:      	jne	0x9e51 <generic_rawtp_filter_arg+0x3571>
    99ae:      	cmpq	%rdx, (%r12)
    99b2:      	jl	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    99b8:      	jmp	0x9fa1 <generic_rawtp_filter_arg+0x36c1>
    99bd:      	cmpq	%rdx, (%r12)
    99c1:      	jne	0x9fa1 <generic_rawtp_filter_arg+0x36c1>
    99c7:      	jmp	0x6ba5 <generic_rawtp_filter_arg+0x2c5>
    99cc:      	cmpl	$0xc, %eax
    99cf:      	jne	0x9c5b <generic_rawtp_filter_arg+0x337b>
    99d5:      	movzbl	(%r12), %esi
    99da:      	testl	%esi, %edx
    99dc:      	jne	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    99e2:      	jmp	0x9c5b <generic_rawtp_filter_arg+0x337b>
    99e7:      	cmpl	$0xc, %eax
    99ea:      	jne	0x9ca3 <generic_rawtp_filter_arg+0x33c3>
    99f0:      	movzwl	(%r12), %esi
    99f5:      	testl	%esi, %edx
    99f7:      	jne	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    99fd:      	jmp	0x9ca3 <generic_rawtp_filter_arg+0x33c3>
    9a02:      	movl	$0x1, %eax
    9a07:      	movq	(%rip), %rdi            # 0x9a0e <generic_rawtp_filter_arg+0x312e>
    9a0e:      	leaq	0x38(%rsp), %rsi
    9a13:      	jmp	0x9a85 <generic_rawtp_filter_arg+0x31a5>
    9a15:      	movl	$0x1, %eax
    9a1a:      	leaq	0x38(%rsp), %rsi
    9a1f:      	movq	(%rip), %rdi            # 0x9a26 <generic_rawtp_filter_arg+0x3146>
    9a26:      	jmp	0x9a85 <generic_rawtp_filter_arg+0x31a5>
    9a28:      	movl	$0x1, %eax
    9a2d:      	leaq	0x38(%rsp), %rsi
    9a32:      	movq	(%rip), %rdi            # 0x9a39 <generic_rawtp_filter_arg+0x3159>
    9a39:      	jmp	0x9a85 <generic_rawtp_filter_arg+0x31a5>
    9a3b:      	movl	$0x1, %eax
    9a40:      	leaq	0x38(%rsp), %rsi
    9a45:      	movq	(%rip), %rdi            # 0x9a4c <generic_rawtp_filter_arg+0x316c>
    9a4c:      	jmp	0x9a85 <generic_rawtp_filter_arg+0x31a5>
    9a4e:      	movl	$0x1, %eax
    9a53:      	leaq	0x38(%rsp), %rsi
    9a58:      	movq	(%rip), %rdi            # 0x9a5f <generic_rawtp_filter_arg+0x317f>
    9a5f:      	jmp	0x9a85 <generic_rawtp_filter_arg+0x31a5>
    9a61:      	movl	$0x1, %eax
    9a66:      	leaq	0x38(%rsp), %rsi
    9a6b:      	movq	(%rip), %rdi            # 0x9a72 <generic_rawtp_filter_arg+0x3192>
    9a72:      	jmp	0x9a85 <generic_rawtp_filter_arg+0x31a5>
    9a74:      	movl	$0x1, %eax
    9a79:      	leaq	0x38(%rsp), %rsi
    9a7e:      	movq	(%rip), %rdi            # 0x9a85 <generic_rawtp_filter_arg+0x31a5>
    9a85:      	callq	*%rax
    9a87:      	testq	%rax, %rax
    9a8a:      	je	0x9b73 <generic_rawtp_filter_arg+0x3293>
    9a90:      	movq	%rax, %rdi
    9a93:      	movl	$0x1, %eax
    9a98:      	movq	%r12, %rsi
    9a9b:      	jmp	0x9b67 <generic_rawtp_filter_arg+0x3287>
    9aa0:      	cmpl	%eax, %esi
    9aa2:      	ja	0x69fd <generic_rawtp_filter_arg+0x11d>
    9aa8:      	cmpl	%edx, %eax
    9aaa:      	jbe	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9ab0:      	jmp	0x69fd <generic_rawtp_filter_arg+0x11d>
    9ab5:      	cmpl	$0xc, %ecx
    9ab8:      	je	0x9ac3 <generic_rawtp_filter_arg+0x31e3>
    9aba:      	cmpl	$0xa, %ecx
    9abd:      	jne	0x9e60 <generic_rawtp_filter_arg+0x3580>
    9ac3:      	cmpq	%rdx, (%r12)
    9ac7:      	jg	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9acd:      	jmp	0x9fa1 <generic_rawtp_filter_arg+0x36c1>
    9ad2:      	movl	$0x1, %eax
    9ad7:      	movq	(%rip), %rdi            # 0x9ade <generic_rawtp_filter_arg+0x31fe>
    9ade:      	leaq	0x38(%rsp), %rsi
    9ae3:      	jmp	0x9b55 <generic_rawtp_filter_arg+0x3275>
    9ae5:      	movl	$0x1, %eax
    9aea:      	leaq	0x38(%rsp), %rsi
    9aef:      	movq	(%rip), %rdi            # 0x9af6 <generic_rawtp_filter_arg+0x3216>
    9af6:      	jmp	0x9b55 <generic_rawtp_filter_arg+0x3275>
    9af8:      	movl	$0x1, %eax
    9afd:      	leaq	0x38(%rsp), %rsi
    9b02:      	movq	(%rip), %rdi            # 0x9b09 <generic_rawtp_filter_arg+0x3229>
    9b09:      	jmp	0x9b55 <generic_rawtp_filter_arg+0x3275>
    9b0b:      	movl	$0x1, %eax
    9b10:      	leaq	0x38(%rsp), %rsi
    9b15:      	movq	(%rip), %rdi            # 0x9b1c <generic_rawtp_filter_arg+0x323c>
    9b1c:      	jmp	0x9b55 <generic_rawtp_filter_arg+0x3275>
    9b1e:      	movl	$0x1, %eax
    9b23:      	leaq	0x38(%rsp), %rsi
    9b28:      	movq	(%rip), %rdi            # 0x9b2f <generic_rawtp_filter_arg+0x324f>
    9b2f:      	jmp	0x9b55 <generic_rawtp_filter_arg+0x3275>
    9b31:      	movl	$0x1, %eax
    9b36:      	leaq	0x38(%rsp), %rsi
    9b3b:      	movq	(%rip), %rdi            # 0x9b42 <generic_rawtp_filter_arg+0x3262>
    9b42:      	jmp	0x9b55 <generic_rawtp_filter_arg+0x3275>
    9b44:      	movl	$0x1, %eax
    9b49:      	leaq	0x38(%rsp), %rsi
    9b4e:      	movq	(%rip), %rdi            # 0x9b55 <generic_rawtp_filter_arg+0x3275>
    9b55:      	callq	*%rax
    9b57:      	testq	%rax, %rax
    9b5a:      	je	0x9b73 <generic_rawtp_filter_arg+0x3293>
    9b5c:      	movq	%rax, %rdi
    9b5f:      	movl	$0x1, %eax
    9b64:      	movq	%rbp, %rsi
    9b67:      	callq	*%rax
    9b69:      	xorl	%ebx, %ebx
    9b6b:      	testq	%rax, %rax
    9b6e:      	setne	%bl
    9b71:      	jmp	0x9b75 <generic_rawtp_filter_arg+0x3295>
    9b73:      	xorl	%ebx, %ebx
    9b75:      	movq	(%rsp), %rdi
    9b79:      	movq	0x8(%rsp), %r9
    9b7e:      	movq	0x10(%rsp), %r11
    9b83:      	movl	0x4(%r13), %eax
    9b87:      	cmpq	$0x25, %rax
    9b8b:      	ja	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    9b91:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    9b9b:      	btq	%rax, %rcx
    9b9f:      	jae	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    9ba5:      	xorq	$0x1, %rbx
    9ba9:      	jmp	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    9bae:      	movl	$0x1, %eax
    9bb3:      	movq	(%rip), %rdi            # 0x9bba <generic_rawtp_filter_arg+0x32da>
    9bba:      	leaq	0x38(%rsp), %rsi
    9bbf:      	jmp	0x9c31 <generic_rawtp_filter_arg+0x3351>
    9bc1:      	movl	$0x1, %eax
    9bc6:      	leaq	0x38(%rsp), %rsi
    9bcb:      	movq	(%rip), %rdi            # 0x9bd2 <generic_rawtp_filter_arg+0x32f2>
    9bd2:      	jmp	0x9c31 <generic_rawtp_filter_arg+0x3351>
    9bd4:      	movl	$0x1, %eax
    9bd9:      	leaq	0x38(%rsp), %rsi
    9bde:      	movq	(%rip), %rdi            # 0x9be5 <generic_rawtp_filter_arg+0x3305>
    9be5:      	jmp	0x9c31 <generic_rawtp_filter_arg+0x3351>
    9be7:      	movl	$0x1, %eax
    9bec:      	leaq	0x38(%rsp), %rsi
    9bf1:      	movq	(%rip), %rdi            # 0x9bf8 <generic_rawtp_filter_arg+0x3318>
    9bf8:      	jmp	0x9c31 <generic_rawtp_filter_arg+0x3351>
    9bfa:      	movl	$0x1, %eax
    9bff:      	leaq	0x38(%rsp), %rsi
    9c04:      	movq	(%rip), %rdi            # 0x9c0b <generic_rawtp_filter_arg+0x332b>
    9c0b:      	jmp	0x9c31 <generic_rawtp_filter_arg+0x3351>
    9c0d:      	movl	$0x1, %eax
    9c12:      	leaq	0x38(%rsp), %rsi
    9c17:      	movq	(%rip), %rdi            # 0x9c1e <generic_rawtp_filter_arg+0x333e>
    9c1e:      	jmp	0x9c31 <generic_rawtp_filter_arg+0x3351>
    9c20:      	movl	$0x1, %eax
    9c25:      	leaq	0x38(%rsp), %rsi
    9c2a:      	movq	(%rip), %rdi            # 0x9c31 <generic_rawtp_filter_arg+0x3351>
    9c31:      	callq	*%rax
    9c33:      	testq	%rax, %rax
    9c36:      	je	0x9f0b <generic_rawtp_filter_arg+0x362b>
    9c3c:      	movq	%rax, %rdi
    9c3f:      	movl	$0x1, %eax
    9c44:      	movq	0x20(%rsp), %rsi
    9c49:      	jmp	0x83c8 <generic_rawtp_filter_arg+0x1ae8>
    9c4e:      	movzbl	(%r12), %esi
    9c53:      	cmpl	%esi, %edx
    9c55:      	jb	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9c5b:      	cmpl	$0x15, %ecx
    9c5e:      	jb	0x9fa1 <generic_rawtp_filter_arg+0x36c1>
    9c64:      	movl	0x1c(%r13), %ecx
    9c68:      	cmpl	$0x2, %eax
    9c6b:      	jle	0x9dfb <generic_rawtp_filter_arg+0x351b>
    9c71:      	leal	-0x3(%rax), %edx
    9c74:      	cmpl	$0x2, %edx
    9c77:      	jb	0x9e38 <generic_rawtp_filter_arg+0x3558>
    9c7d:      	cmpl	$0x6, %eax
    9c80:      	je	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9c86:      	cmpl	$0xc, %eax
    9c89:      	jne	0x69fd <generic_rawtp_filter_arg+0x11d>
    9c8f:      	movzbl	(%r12), %edx
    9c94:      	jmp	0x9cdc <generic_rawtp_filter_arg+0x33fc>
    9c96:      	movzwl	(%r12), %esi
    9c9b:      	cmpl	%esi, %edx
    9c9d:      	jb	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9ca3:      	cmpl	$0x15, %ecx
    9ca6:      	jb	0x9fa1 <generic_rawtp_filter_arg+0x36c1>
    9cac:      	movl	0x1c(%r13), %ecx
    9cb0:      	cmpl	$0x2, %eax
    9cb3:      	jle	0x9e14 <generic_rawtp_filter_arg+0x3534>
    9cb9:      	leal	-0x3(%rax), %edx
    9cbc:      	cmpl	$0x2, %edx
    9cbf:      	jb	0x9e3f <generic_rawtp_filter_arg+0x355f>
    9cc5:      	cmpl	$0x6, %eax
    9cc8:      	je	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9cce:      	cmpl	$0xc, %eax
    9cd1:      	jne	0x69fd <generic_rawtp_filter_arg+0x11d>
    9cd7:      	movzwl	(%r12), %edx
    9cdc:      	testl	%edx, %ecx
    9cde:      	jne	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9ce4:      	jmp	0x9fa1 <generic_rawtp_filter_arg+0x36c1>
    9ce9:      	cmpl	$0x8, %ebx
    9cec:      	je	0x9ee1 <generic_rawtp_filter_arg+0x3601>
    9cf2:      	cmpl	$0x9, %ebx
    9cf5:      	je	0x9ea8 <generic_rawtp_filter_arg+0x35c8>
    9cfb:      	cmpl	$0xa, %ebx
    9cfe:      	jne	0x9f0b <generic_rawtp_filter_arg+0x362b>
    9d04:      	movl	$0x1, %eax
    9d09:      	leaq	0x38(%rsp), %rsi
    9d0e:      	movq	(%rip), %rdi            # 0x9d15 <generic_rawtp_filter_arg+0x3435>
    9d15:      	jmp	0x9ef2 <generic_rawtp_filter_arg+0x3612>
    9d1a:      	cmpl	%esi, (%r12)
    9d1e:      	ja	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9d24:      	jmp	0x9d30 <generic_rawtp_filter_arg+0x3450>
    9d26:      	cmpl	%esi, (%r12)
    9d2a:      	jb	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9d30:      	cmpl	$0x15, %edx
    9d33:      	jb	0x9fa1 <generic_rawtp_filter_arg+0x36c1>
    9d39:      	movl	0x1c(%r13), %edx
    9d3d:      	cmpl	$0x2, %eax
    9d40:      	jle	0x9d6b <generic_rawtp_filter_arg+0x348b>
    9d42:      	leal	-0x3(%rax), %ecx
    9d45:      	cmpl	$0x2, %ecx
    9d48:      	jb	0x9d9f <generic_rawtp_filter_arg+0x34bf>
    9d4a:      	cmpl	$0x6, %eax
    9d4d:      	je	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9d53:      	cmpl	$0xc, %eax
    9d56:      	jne	0x69fd <generic_rawtp_filter_arg+0x11d>
    9d5c:      	testl	%edx, (%r12)
    9d60:      	jne	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9d66:      	jmp	0x9fa1 <generic_rawtp_filter_arg+0x36c1>
    9d6b:      	cmpl	$0x1, %eax
    9d6e:      	je	0x9dae <generic_rawtp_filter_arg+0x34ce>
    9d70:      	cmpl	$0x2, %eax
    9d73:      	jne	0x69fd <generic_rawtp_filter_arg+0x11d>
    9d79:      	cmpl	$0xc, %ecx
    9d7c:      	ja	0x9f8b <generic_rawtp_filter_arg+0x36ab>
    9d82:      	movl	$0x1402, %esi           # imm = 0x1402
    9d87:      	btl	%ecx, %esi
    9d8a:      	jae	0x9f8b <generic_rawtp_filter_arg+0x36ab>
    9d90:      	cmpl	%edx, (%r12)
    9d94:      	jl	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9d9a:      	jmp	0x9fa1 <generic_rawtp_filter_arg+0x36c1>
    9d9f:      	cmpl	%edx, (%r12)
    9da3:      	je	0x6ba5 <generic_rawtp_filter_arg+0x2c5>
    9da9:      	jmp	0x9fa1 <generic_rawtp_filter_arg+0x36c1>
    9dae:      	cmpl	$0xc, %ecx
    9db1:      	ja	0x9f97 <generic_rawtp_filter_arg+0x36b7>
    9db7:      	movl	$0x1402, %esi           # imm = 0x1402
    9dbc:      	btl	%ecx, %esi
    9dbf:      	jae	0x9f97 <generic_rawtp_filter_arg+0x36b7>
    9dc5:      	cmpl	%edx, (%r12)
    9dc9:      	jg	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9dcf:      	jmp	0x9fa1 <generic_rawtp_filter_arg+0x36c1>
    9dd4:      	testl	%ebx, %ebx
    9dd6:      	je	0x9e6f <generic_rawtp_filter_arg+0x358f>
    9ddc:      	cmpl	$0x1, %ebx
    9ddf:      	jne	0x9f0b <generic_rawtp_filter_arg+0x362b>
    9de5:      	movl	$0x1, %eax
    9dea:      	leaq	0x38(%rsp), %rsi
    9def:      	movq	(%rip), %rdi            # 0x9df6 <generic_rawtp_filter_arg+0x3516>
    9df6:      	jmp	0x9ef2 <generic_rawtp_filter_arg+0x3612>
    9dfb:      	cmpl	$0x1, %eax
    9dfe:      	je	0x9f75 <generic_rawtp_filter_arg+0x3695>
    9e04:      	cmpl	$0x2, %eax
    9e07:      	jne	0x69fd <generic_rawtp_filter_arg+0x11d>
    9e0d:      	movzbl	(%r12), %edx
    9e12:      	jmp	0x9e2b <generic_rawtp_filter_arg+0x354b>
    9e14:      	cmpl	$0x1, %eax
    9e17:      	je	0x9f7c <generic_rawtp_filter_arg+0x369c>
    9e1d:      	cmpl	$0x2, %eax
    9e20:      	jne	0x69fd <generic_rawtp_filter_arg+0x11d>
    9e26:      	movzwl	(%r12), %edx
    9e2b:      	cmpl	%edx, %ecx
    9e2d:      	ja	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9e33:      	jmp	0x9fa1 <generic_rawtp_filter_arg+0x36c1>
    9e38:      	movzbl	(%r12), %edx
    9e3d:      	jmp	0x9e44 <generic_rawtp_filter_arg+0x3564>
    9e3f:      	movzwl	(%r12), %edx
    9e44:      	cmpl	%edx, %ecx
    9e46:      	je	0x6ba5 <generic_rawtp_filter_arg+0x2c5>
    9e4c:      	jmp	0x9fa1 <generic_rawtp_filter_arg+0x36c1>
    9e51:      	cmpq	%rdx, (%r12)
    9e55:      	jb	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9e5b:      	jmp	0x9fa1 <generic_rawtp_filter_arg+0x36c1>
    9e60:      	cmpq	%rdx, (%r12)
    9e64:      	ja	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9e6a:      	jmp	0x9fa1 <generic_rawtp_filter_arg+0x36c1>
    9e6f:      	movl	$0x1, %eax
    9e74:      	movq	(%rip), %rdi            # 0x9e7b <generic_rawtp_filter_arg+0x359b>
    9e7b:      	leaq	0x38(%rsp), %rsi
    9e80:      	jmp	0x9ef2 <generic_rawtp_filter_arg+0x3612>
    9e82:      	movl	$0x1, %eax
    9e87:      	leaq	0x38(%rsp), %rsi
    9e8c:      	movq	(%rip), %rdi            # 0x9e93 <generic_rawtp_filter_arg+0x35b3>
    9e93:      	jmp	0x9ef2 <generic_rawtp_filter_arg+0x3612>
    9e95:      	movl	$0x1, %eax
    9e9a:      	leaq	0x38(%rsp), %rsi
    9e9f:      	movq	(%rip), %rdi            # 0x9ea6 <generic_rawtp_filter_arg+0x35c6>
    9ea6:      	jmp	0x9ef2 <generic_rawtp_filter_arg+0x3612>
    9ea8:      	movl	$0x1, %eax
    9ead:      	leaq	0x38(%rsp), %rsi
    9eb2:      	movq	(%rip), %rdi            # 0x9eb9 <generic_rawtp_filter_arg+0x35d9>
    9eb9:      	jmp	0x9ef2 <generic_rawtp_filter_arg+0x3612>
    9ebb:      	movl	$0x1, %eax
    9ec0:      	leaq	0x38(%rsp), %rsi
    9ec5:      	movq	(%rip), %rdi            # 0x9ecc <generic_rawtp_filter_arg+0x35ec>
    9ecc:      	jmp	0x9ef2 <generic_rawtp_filter_arg+0x3612>
    9ece:      	movl	$0x1, %eax
    9ed3:      	leaq	0x38(%rsp), %rsi
    9ed8:      	movq	(%rip), %rdi            # 0x9edf <generic_rawtp_filter_arg+0x35ff>
    9edf:      	jmp	0x9ef2 <generic_rawtp_filter_arg+0x3612>
    9ee1:      	movl	$0x1, %eax
    9ee6:      	leaq	0x38(%rsp), %rsi
    9eeb:      	movq	(%rip), %rdi            # 0x9ef2 <generic_rawtp_filter_arg+0x3612>
    9ef2:      	callq	*%rax
    9ef4:      	testq	%rax, %rax
    9ef7:      	je	0x9f0b <generic_rawtp_filter_arg+0x362b>
    9ef9:      	movq	%rax, %rdi
    9efc:      	movl	$0x1, %eax
    9f01:      	movq	0x20(%rsp), %rsi
    9f06:      	jmp	0x83c8 <generic_rawtp_filter_arg+0x1ae8>
    9f0b:      	xorl	%ebx, %ebx
    9f0d:      	movq	(%rsp), %rdi
    9f11:      	movq	0x8(%rsp), %r9
    9f16:      	movq	0x10(%rsp), %r11
    9f1b:      	movl	0x4(%r13), %eax
    9f1f:      	cmpq	$0x25, %rax
    9f23:      	ja	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    9f29:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    9f33:      	btq	%rax, %rcx
    9f37:      	jae	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    9f3d:      	xorl	%eax, %eax
    9f3f:      	testq	%rbx, %rbx
    9f42:      	sete	%al
    9f45:      	movq	%rax, %rbx
    9f48:      	jmp	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    9f4d:      	xorl	%ebx, %ebx
    9f4f:      	movq	(%rsp), %rdi
    9f53:      	movq	0x8(%rsp), %r9
    9f58:      	movq	0x10(%rsp), %r11
    9f5d:      	movq	0x68(%rsp), %r15
    9f62:      	movl	0x4(%r13), %eax
    9f66:      	cmpq	$0x25, %rax
    9f6a:      	jbe	0x9b91 <generic_rawtp_filter_arg+0x32b1>
    9f70:      	jmp	0x6bb0 <generic_rawtp_filter_arg+0x2d0>
    9f75:      	movzbl	(%r12), %edx
    9f7a:      	jmp	0x9f81 <generic_rawtp_filter_arg+0x36a1>
    9f7c:      	movzwl	(%r12), %edx
    9f81:      	cmpl	%edx, %ecx
    9f83:      	jb	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9f89:      	jmp	0x9fa1 <generic_rawtp_filter_arg+0x36c1>
    9f8b:      	cmpl	%edx, (%r12)
    9f8f:      	jb	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9f95:      	jmp	0x9fa1 <generic_rawtp_filter_arg+0x36c1>
    9f97:      	cmpl	%edx, (%r12)
    9f9b:      	ja	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9fa1:      	orl	$0x2, %eax
    9fa4:      	cmpl	$0x6, %eax
    9fa7:      	je	0x6bc1 <generic_rawtp_filter_arg+0x2e1>
    9fad:      	jmp	0x69fd <generic_rawtp_filter_arg+0x11d>
    9fb2:      	nopw	%cs:(%rax,%rax)

0000000000009fc0 <generic_rawtp_actions>:
    9fc0:      	pushq	%rbp
    9fc1:      	pushq	%r15
    9fc3:      	pushq	%r14
    9fc5:      	pushq	%r13
    9fc7:      	pushq	%r12
    9fc9:      	pushq	%rbx
    9fca:      	subq	$0xa8, %rsp
    9fd1:      	movq	%rdi, 0x80(%rsp)
    9fd9:      	movl	$0x0, 0x88(%rsp)
    9fe4:      	movq	(%rip), %rdi            # 0x9feb <generic_rawtp_actions+0x2b>
    9feb:      	leaq	0x88(%rsp), %rsi
    9ff3:      	movl	$0x1, %eax
    9ff8:      	callq	*%rax
    9ffa:      	testq	%rax, %rax
    9ffd:      	je	0xaaf8 <generic_rawtp_actions+0xb38>
    a003:      	movq	%rax, %rsi
    a006:      	movl	0x5f04(%rax), %ebx
    a00c:      	cmpl	$0x2, %ebx
    a00f:      	jl	0xaaf8 <generic_rawtp_actions+0xb38>
    a015:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    a01c:      	movq	(%rip), %rdi            # 0xa023 <generic_rawtp_actions+0x63>
    a023:      	movl	$0x1, %eax
    a028:      	callq	*%rax
    a02a:      	testq	%rax, %rax
    a02d:      	je	0xaaf8 <generic_rawtp_actions+0xb38>
    a033:      	movq	%rax, %r14
    a036:      	movl	%ebx, %eax
    a038:      	andl	$0x7ff, %eax            # imm = 0x7FF
    a03d:      	addl	(%r14,%rax), %ebx
    a041:      	movl	$0x0, 0x8c(%rsp)
    a04c:      	movq	(%rip), %rdi            # 0xa053 <generic_rawtp_actions+0x93>
    a053:      	leaq	0x8c(%rsp), %rsi
    a05b:      	movl	$0x1, %eax
    a060:      	andl	$0x7ff, %ebx            # imm = 0x7FF
    a066:      	callq	*%rax
    a068:      	testq	%rax, %rax
    a06b:      	je	0xa092 <generic_rawtp_actions+0xd2>
    a06d:      	cmpb	$0x0, (%rax)
    a070:      	sete	0x17(%rsp)
    a075:      	je	0xa0ad <generic_rawtp_actions+0xed>
    a077:      	movl	$0x5, %eax
    a07c:      	movq	%rax, 0x78(%rsp)
    a081:      	movl	$0x9, %eax
    a086:      	movq	%rax, 0x70(%rsp)
    a08b:      	movl	$0x7, %eax
    a090:      	jmp	0xa0c6 <generic_rawtp_actions+0x106>
    a092:      	movl	$0x4, %eax
    a097:      	movq	%rax, 0x78(%rsp)
    a09c:      	movl	$0x8, %eax
    a0a1:      	movq	%rax, 0x70(%rsp)
    a0a6:      	movb	$0x1, 0x17(%rsp)
    a0ab:      	jmp	0xa0c1 <generic_rawtp_actions+0x101>
    a0ad:      	movl	$0x4, %eax
    a0b2:      	movq	%rax, 0x78(%rsp)
    a0b7:      	movl	$0x8, %eax
    a0bc:      	movq	%rax, 0x70(%rsp)
    a0c1:      	movl	$0x6, %eax
    a0c6:      	movq	%rax, 0x68(%rsp)
    a0cb:      	addq	%rbx, %r14
    a0ce:      	movb	$0x1, %al
    a0d0:      	movl	%eax, 0x44(%rsp)
    a0d4:      	movq	(%rip), %rbp            # 0xa0db <generic_rawtp_actions+0x11b>
    a0db:      	xorl	%r12d, %r12d
    a0de:      	xorl	%r15d, %r15d
    a0e1:      	jmp	0xa10a <generic_rawtp_actions+0x14a>
    a0e3:      	incl	%r15d
    a0e6:      	movl	0x4(%r14,%r15,4), %eax
    a0eb:      	movl	%eax, 0x78(%rdx)
    a0ee:      	nop
    a0f0:      	movq	%r13, 0x70(%rdx)
    a0f4:      	incl	%r15d
    a0f7:      	movl	%r15d, %ebx
    a0fa:      	incl	%r12d
    a0fd:      	movl	%ebx, %r15d
    a100:      	cmpl	$0x3, %r12d
    a104:      	je	0xaad1 <generic_rawtp_actions+0xb11>
    a10a:      	leal	0x4(,%r15,4), %eax
    a112:      	cmpl	(%r14), %eax
    a115:      	jae	0xaad1 <generic_rawtp_actions+0xb11>
    a11b:      	movl	%r15d, %eax
    a11e:      	movslq	0x4(%r14,%rax,4), %r13
    a123:      	movl	$0x0, 0x90(%rsp)
    a12e:      	movl	$0x1, %eax
    a133:      	leaq	0x90(%rsp), %rsi
    a13b:      	movq	%rbp, %rdi
    a13e:      	callq	*%rax
    a140:      	xorl	%ebx, %ebx
    a142:      	testq	%rax, %rax
    a145:      	je	0xa0fa <generic_rawtp_actions+0x13a>
    a147:      	movq	%rax, %rdx
    a14a:      	cmpl	$0x7, %r13d
    a14e:      	jg	0xa180 <generic_rawtp_actions+0x1c0>
    a150:      	cmpl	$0x3, %r13d
    a154:      	jg	0xa1d6 <generic_rawtp_actions+0x216>
    a15a:      	cmpl	$0x1, %r13d
    a15e:      	jg	0xa327 <generic_rawtp_actions+0x367>
    a164:      	testl	%r13d, %r13d
    a167:      	je	0xa537 <generic_rawtp_actions+0x577>
    a16d:      	cmpl	$0x1, %r13d
    a171:      	je	0xa340 <generic_rawtp_actions+0x380>
    a177:      	jmp	0xa0f0 <generic_rawtp_actions+0x130>
    a17c:      	nopl	(%rax)
    a180:      	cmpl	$0xb, %r13d
    a184:      	jg	0xa2f0 <generic_rawtp_actions+0x330>
    a18a:      	leal	-0xa(%r13), %eax
    a18e:      	cmpl	$0x2, %eax
    a191:      	jb	0xa3cf <generic_rawtp_actions+0x40f>
    a197:      	cmpl	$0x8, %r13d
    a19b:      	je	0xa491 <generic_rawtp_actions+0x4d1>
    a1a1:      	cmpl	$0x9, %r13d
    a1a5:      	jne	0xa0f0 <generic_rawtp_actions+0x130>
    a1ab:      	movq	%r13, 0x8(%rsp)
    a1b0:      	movq	%r14, %rax
    a1b3:      	movq	%rbp, %r13
    a1b6:      	incl	%r15d
    a1b9:      	movl	0x4(%r14,%r15,4), %eax
    a1be:      	movq	%rdx, %rbp
    a1c1:      	movl	$0x3, %ebx
    a1c6:      	cmpb	$0x0, 0x17(%rsp)
    a1cb:      	jne	0xa613 <generic_rawtp_actions+0x653>
    a1d1:      	jmp	0xa638 <generic_rawtp_actions+0x678>
    a1d6:      	leal	-0x6(%r13), %eax
    a1da:      	cmpl	$0x2, %eax
    a1dd:      	jb	0xa0e3 <generic_rawtp_actions+0x123>
    a1e3:      	cmpl	$0x4, %r13d
    a1e7:      	je	0xa49e <generic_rawtp_actions+0x4de>
    a1ed:      	cmpl	$0x5, %r13d
    a1f1:      	jne	0xa0f0 <generic_rawtp_actions+0x130>
    a1f7:      	leal	0x1(%r15), %eax
    a1fb:      	movl	0x4(%r14,%rax,4), %eax
    a200:      	addl	$0x2, %r15d
    a204:      	movl	0x4(%r14,%r15,4), %ebx
    a209:      	movq	$0x0, 0x20(%rsp)
    a212:      	movq	$0x0, 0x18(%rsp)
    a21b:      	andl	$0x7, %eax
    a21e:      	cmpl	$0x4, %eax
    a221:      	ja	0xa0f0 <generic_rawtp_actions+0x130>
    a227:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    a22f:      	jne	0xa0f0 <generic_rawtp_actions+0x130>
    a235:      	movq	0x5e78(%rdx,%rax,8), %rax
    a23d:      	andl	$0x7ff, %eax            # imm = 0x7FF
    a242:      	movl	0x90(%rdx,%rax), %eax
    a249:      	movl	%eax, 0x20(%rsp)
    a24d:      	movl	$0xe, %eax
    a252:      	movq	%rdx, 0x8(%rsp)
    a257:      	callq	*%rax
    a259:      	shrq	$0x20, %rax
    a25d:      	movq	%rax, 0x18(%rsp)
    a262:      	movl	$0x1, %eax
    a267:      	leaq	0x18(%rsp), %rsi
    a26c:      	movq	(%rip), %rdi            # 0xa273 <generic_rawtp_actions+0x2b3>
    a273:      	callq	*%rax
    a275:      	movq	0x8(%rsp), %rdx
    a27a:      	testq	%rax, %rax
    a27d:      	je	0xa0f0 <generic_rawtp_actions+0x130>
    a283:      	andl	$0x7, %ebx
    a286:      	cmpl	$0x4, %ebx
    a289:      	ja	0xa0f0 <generic_rawtp_actions+0x130>
    a28f:      	cmpl	$0x0, 0x5ea0(%rdx,%rbx,4)
    a297:      	jne	0xa0f0 <generic_rawtp_actions+0x130>
    a29d:      	movq	0x5e78(%rdx,%rbx,8), %rcx
    a2a5:      	movl	$0x0, 0x24(%rsp)
    a2ad:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    a2b3:      	movl	0x90(%rdx,%rcx), %ecx
    a2ba:      	movl	%ecx, 0x20(%rsp)
    a2be:      	movq	%rax, %rbx
    a2c1:      	movl	$0xe, %eax
    a2c6:      	callq	*%rax
    a2c8:      	shrq	$0x20, %rax
    a2cc:      	movq	%rax, 0x18(%rsp)
    a2d1:      	movl	$0x2, %eax
    a2d6:      	xorl	%ecx, %ecx
    a2d8:      	leaq	0x18(%rsp), %rsi
    a2dd:      	movq	(%rip), %rdi            # 0xa2e4 <generic_rawtp_actions+0x324>
    a2e4:      	movq	%rbx, %rdx
    a2e7:      	xorl	%ecx, %ecx
    a2e9:      	callq	*%rax
    a2eb:      	jmp	0xa52d <generic_rawtp_actions+0x56d>
    a2f0:      	cmpl	$0xc, %r13d
    a2f4:      	je	0xa624 <generic_rawtp_actions+0x664>
    a2fa:      	cmpl	$0xd, %r13d
    a2fe:      	je	0xa4b6 <generic_rawtp_actions+0x4f6>
    a304:      	cmpl	$0xe, %r13d
    a308:      	jne	0xa0f0 <generic_rawtp_actions+0x130>
    a30e:      	movq	%r13, 0x8(%rsp)
    a313:      	movq	%rbp, %r13
    a316:      	movq	%rdx, %rbp
    a319:      	addl	$0x2, %r15d
    a31d:      	movq	0x70(%rsp), %rbx
    a322:      	jmp	0xa638 <generic_rawtp_actions+0x678>
    a327:      	movl	$0x9, %eax
    a32c:      	cmpl	$0x2, %r13d
    a330:      	je	0xa5fc <generic_rawtp_actions+0x63c>
    a336:      	cmpl	$0x3, %r13d
    a33a:      	jne	0xa0f0 <generic_rawtp_actions+0x130>
    a340:      	movq	%rdx, 0x8(%rsp)
    a345:      	leal	0x1(%r15), %eax
    a349:      	movq	%r14, %rcx
    a34c:      	movl	0x4(%r14,%rax,4), %r14d
    a351:      	addl	$0x2, %r15d
    a355:      	movq	%rcx, %rbp
    a358:      	movl	0x4(%rcx,%r15,4), %eax
    a35d:      	movq	%rax, 0x38(%rsp)
    a362:      	movq	$0x0, 0x20(%rsp)
    a36b:      	movq	$0x0, 0x18(%rsp)
    a374:      	movl	$0x0, 0x28(%rsp)
    a37c:      	movl	$0x1, %eax
    a381:      	leaq	0x28(%rsp), %rsi
    a386:      	movq	(%rip), %rdi            # 0xa38d <generic_rawtp_actions+0x3cd>
    a38d:      	callq	*%rax
    a38f:      	xorl	%ecx, %ecx
    a391:      	testq	%rax, %rax
    a394:      	je	0xa7c8 <generic_rawtp_actions+0x808>
    a39a:      	andl	$0x7, %r14d
    a39e:      	cmpl	$0x4, %r14d
    a3a2:      	movq	0x8(%rsp), %rdx
    a3a7:      	ja	0xa3b8 <generic_rawtp_actions+0x3f8>
    a3a9:      	cmpl	$0x0, 0x5ea0(%rdx,%r14,4)
    a3b2:      	je	0xa66d <generic_rawtp_actions+0x6ad>
    a3b8:      	movq	%rbp, %r14
    a3bb:      	movq	(%rip), %rbp            # 0xa3c2 <generic_rawtp_actions+0x402>
    a3c2:      	testl	%ecx, %ecx
    a3c4:      	jne	0xa0fa <generic_rawtp_actions+0x13a>
    a3ca:      	jmp	0xa0f0 <generic_rawtp_actions+0x130>
    a3cf:      	incl	%r15d
    a3d2:      	movl	0x4(%r14,%r15,4), %eax
    a3d7:      	andl	$0x7, %eax
    a3da:      	xorl	%ecx, %ecx
    a3dc:      	cmpl	$0x4, %eax
    a3df:      	ja	0xa7d7 <generic_rawtp_actions+0x817>
    a3e5:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    a3ed:      	jne	0xa7d7 <generic_rawtp_actions+0x817>
    a3f3:      	movq	0x5e78(%rdx,%rax,8), %rax
    a3fb:      	andl	$0x7ff, %eax            # imm = 0x7FF
    a400:      	movq	0xb8(%rdx,%rax), %rax
    a408:      	movq	%rax, 0x28(%rsp)
    a40d:      	testq	%rax, %rax
    a410:      	je	0xa7d7 <generic_rawtp_actions+0x817>
    a416:      	movq	%rdx, 0x8(%rsp)
    a41b:      	cmpl	$0xa, %r13d
    a41f:      	jne	0xa7e4 <generic_rawtp_actions+0x824>
    a425:      	movl	$0xe, %eax
    a42a:      	callq	*%rax
    a42c:      	movq	%rax, 0x38(%rsp)
    a431:      	shrq	$0x20, %rax
    a435:      	movl	%eax, 0x18(%rsp)
    a439:      	movl	$0x1, %eax
    a43e:      	leaq	0x18(%rsp), %rsi
    a443:      	movq	(%rip), %rdi            # 0xa44a <generic_rawtp_actions+0x48a>
    a44a:      	callq	*%rax
    a44c:      	xorl	%ecx, %ecx
    a44e:      	testq	%rax, %rax
    a451:      	movq	0x8(%rsp), %rdx
    a456:      	je	0xa7d7 <generic_rawtp_actions+0x817>
    a45c:      	movl	(%rax), %ecx
    a45e:      	movl	%ecx, 0x18(%rsp)
    a462:      	movq	0x38(%rsp), %rcx
    a467:      	movl	%ecx, 0x1c(%rsp)
    a46b:      	movq	0x8(%rax), %rax
    a46f:      	movq	%rax, 0x20(%rsp)
    a474:      	xorl	%ecx, %ecx
    a476:      	movl	$0x2, %eax
    a47b:      	leaq	0x28(%rsp), %rsi
    a480:      	leaq	0x18(%rsp), %rdx
    a485:      	movq	(%rip), %rdi            # 0xa48c <generic_rawtp_actions+0x4cc>
    a48c:      	jmp	0xa730 <generic_rawtp_actions+0x770>
    a491:      	movl	$0x0, 0x44(%rsp)
    a499:      	jmp	0xa0f0 <generic_rawtp_actions+0x130>
    a49e:      	movq	%r13, 0x8(%rsp)
    a4a3:      	movq	%rbp, %r13
    a4a6:      	movq	%rdx, %rbp
    a4a9:      	incl	%r15d
    a4ac:      	movq	0x78(%rsp), %rbx
    a4b1:      	jmp	0xa638 <generic_rawtp_actions+0x678>
    a4b6:      	movq	%rdx, 0x8(%rsp)
    a4bb:      	movl	$0xe, %eax
    a4c0:      	callq	*%rax
    a4c2:      	movq	%rax, 0x50(%rsp)
    a4c7:      	movl	$0x1, %eax
    a4cc:      	leaq	0x50(%rsp), %rsi
    a4d1:      	movq	(%rip), %rdi            # 0xa4d8 <generic_rawtp_actions+0x518>
    a4d8:      	callq	*%rax
    a4da:      	testq	%rax, %rax
    a4dd:      	je	0xa52d <generic_rawtp_actions+0x56d>
    a4df:      	movq	0x4(%rax), %rax
    a4e3:      	movq	%rax, 0x28(%rsp)
    a4e8:      	movl	$0x2, 0x30(%rsp)
    a4f0:      	movl	$0x1, %eax
    a4f5:      	leaq	0x28(%rsp), %rsi
    a4fa:      	movq	(%rip), %rbx            # 0xa501 <generic_rawtp_actions+0x541>
    a501:      	movq	%rbx, %rdi
    a504:      	callq	*%rax
    a506:      	movl	$0x1, 0x5c(%rsp)
    a50e:      	testq	%rax, %rax
    a511:      	je	0xa748 <generic_rawtp_actions+0x788>
    a517:      	lock
    a518:      	incl	(%rax)
    a51a:      	movl	$0x3, %eax
    a51f:      	leaq	0x50(%rsp), %rsi
    a524:      	movq	(%rip), %rdi            # 0xa52b <generic_rawtp_actions+0x56b>
    a52b:      	callq	*%rax
    a52d:      	movq	0x8(%rsp), %rdx
    a532:      	jmp	0xa0f0 <generic_rawtp_actions+0x130>
    a537:      	movq	%rdx, 0x8(%rsp)
    a53c:      	leal	0x1(%r15), %eax
    a540:      	movl	0x4(%r14,%rax,4), %ebx
    a545:      	leal	0x2(%r15), %eax
    a549:      	movl	0x4(%r14,%rax,4), %eax
    a54e:      	movl	%eax, 0x60(%rsp)
    a552:      	movl	$0x7d, %eax
    a557:      	callq	*%rax
    a559:      	movq	%rax, 0x18(%rsp)
    a55e:      	movl	$0x0, 0x50(%rsp)
    a566:      	movq	%rbx, 0xa0(%rsp)
    a56e:      	testq	%rbx, %rbx
    a571:      	je	0xa9e8 <generic_rawtp_actions+0xa28>
    a577:      	movl	$0x1, %eax
    a57c:      	movq	(%rip), %rdi            # 0xa583 <generic_rawtp_actions+0x5c3>
    a583:      	leaq	0x50(%rsp), %rsi
    a588:      	callq	*%rax
    a58a:      	testq	%rax, %rax
    a58d:      	je	0xa9e8 <generic_rawtp_actions+0xa28>
    a593:      	movq	%rax, 0x48(%rsp)
    a598:      	movq	%rax, %rbx
    a59b:      	movl	$0x1, %eax
    a5a0:      	leaq	0x50(%rsp), %rsi
    a5a5:      	movq	(%rip), %rdi            # 0xa5ac <generic_rawtp_actions+0x5ec>
    a5ac:      	callq	*%rax
    a5ae:      	movq	%rax, %rdx
    a5b1:      	movq	0x8(%rsp), %rcx
    a5b6:      	movq	0x60(%rcx), %rax
    a5ba:      	movq	%rax, (%rbx)
    a5bd:      	movq	0x70(%rcx), %rax
    a5c1:      	movq	%rax, 0x8(%rbx)
    a5c5:      	xorl	%eax, %eax
    a5c7:      	movq	%rax, 0x38(%rsp)
    a5cc:      	movl	$0x0, %eax
    a5d1:      	movl	0x60(%rsp), %esi
    a5d5:      	cmpl	$0x2, %esi
    a5d8:      	je	0xa80f <generic_rawtp_actions+0x84f>
    a5de:      	cmpl	$0x1, %esi
    a5e1:      	je	0xa80c <generic_rawtp_actions+0x84c>
    a5e7:      	testl	%esi, %esi
    a5e9:      	jne	0xa9e8 <generic_rawtp_actions+0xa28>
    a5ef:      	movq	0x8(%rsp), %rax
    a5f4:      	movl	0x7c(%rax), %eax
    a5f7:      	jmp	0xa80f <generic_rawtp_actions+0x84f>
    a5fc:      	movq	%r13, 0x8(%rsp)
    a601:      	movq	%rbp, %r13
    a604:      	movq	%rdx, %rbp
    a607:      	movl	$0x3, %ebx
    a60c:      	cmpb	$0x0, 0x17(%rsp)
    a611:      	je	0xa638 <generic_rawtp_actions+0x678>
    a613:      	movslq	%eax, %rdi
    a616:      	movl	$0x6d, %eax
    a61b:      	callq	*%rax
    a61d:      	movl	$0x2, %ebx
    a622:      	jmp	0xa638 <generic_rawtp_actions+0x678>
    a624:      	movq	%r13, 0x8(%rsp)
    a629:      	movq	%rbp, %r13
    a62c:      	movq	%rdx, %rbp
    a62f:      	addl	$0x3, %r15d
    a633:      	movq	0x68(%rsp), %rbx
    a638:      	movl	$0x0, 0x18(%rsp)
    a640:      	movl	$0x1, %eax
    a645:      	leaq	0x18(%rsp), %rsi
    a64a:      	movq	(%rip), %rdi            # 0xa651 <generic_rawtp_actions+0x691>
    a651:      	callq	*%rax
    a653:      	testq	%rax, %rax
    a656:      	je	0xa65d <generic_rawtp_actions+0x69d>
    a658:      	lock
    a659:      	incq	(%rax,%rbx,8)
    a65d:      	movq	%rbp, %rdx
    a660:      	movq	%r13, %rbp
    a663:      	movq	0x8(%rsp), %r13
    a668:      	jmp	0xa0f0 <generic_rawtp_actions+0x130>
    a66d:      	movq	%rax, 0x48(%rsp)
    a672:      	movq	0x5e78(%rdx,%r14,8), %rax
    a67a:      	movl	$0x0, 0x24(%rsp)
    a682:      	andl	$0x7ff, %eax            # imm = 0x7FF
    a687:      	movl	0x90(%rdx,%rax), %eax
    a68e:      	movl	%eax, 0x20(%rsp)
    a692:      	movl	$0xe, %eax
    a697:      	callq	*%rax
    a699:      	shrq	$0x20, %rax
    a69d:      	movq	%rax, 0x18(%rsp)
    a6a2:      	cmpl	$0x1, %r13d
    a6a6:      	jne	0xa7b2 <generic_rawtp_actions+0x7f2>
    a6ac:      	movq	0x38(%rsp), %rax
    a6b1:      	andl	$0x7, %eax
    a6b4:      	cmpl	$0x4, %eax
    a6b7:      	movq	%rbp, %r14
    a6ba:      	movl	$0x0, %ecx
    a6bf:      	ja	0xa7cb <generic_rawtp_actions+0x80b>
    a6c5:      	movq	0x8(%rsp), %rdx
    a6ca:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    a6d2:      	movq	(%rip), %rbp            # 0xa6d9 <generic_rawtp_actions+0x719>
    a6d9:      	jne	0xa7d7 <generic_rawtp_actions+0x817>
    a6df:      	movq	0x5e78(%rdx,%rax,8), %rax
    a6e7:      	andl	$0x7ff, %eax            # imm = 0x7FF
    a6ec:      	addq	%rax, %rdx
    a6ef:      	addq	$0x90, %rdx
    a6f6:      	movq	0x8(%rsp), %rcx
    a6fb:      	movl	0x90(%rcx,%rax), %esi
    a702:      	andl	$0xfff, %esi            # imm = 0xFFF
    a708:      	addq	$0x8, %rsi
    a70c:      	movl	$0x4, %eax
    a711:      	movq	0x48(%rsp), %rdi
    a716:      	callq	*%rax
    a718:      	xorl	%ecx, %ecx
    a71a:      	movl	$0x2, %eax
    a71f:      	leaq	0x18(%rsp), %rsi
    a724:      	movq	(%rip), %rdi            # 0xa72b <generic_rawtp_actions+0x76b>
    a72b:      	movq	0x48(%rsp), %rdx
    a730:      	xorl	%ecx, %ecx
    a732:      	callq	*%rax
    a734:      	xorl	%ecx, %ecx
    a736:      	movq	0x8(%rsp), %rdx
    a73b:      	testl	%ecx, %ecx
    a73d:      	jne	0xa0fa <generic_rawtp_actions+0x13a>
    a743:      	jmp	0xa0f0 <generic_rawtp_actions+0x130>
    a748:      	movl	$0x2, %eax
    a74d:      	movl	$0x1, %ecx
    a752:      	leaq	0x5c(%rsp), %rdx
    a757:      	leaq	0x28(%rsp), %rsi
    a75c:      	movq	%rbx, %rdi
    a75f:      	callq	*%rax
    a761:      	testq	%rax, %rax
    a764:      	je	0xa51a <generic_rawtp_actions+0x55a>
    a76a:      	movq	%rax, 0x38(%rsp)
    a76f:      	negl	%eax
    a771:      	movw	%ax, 0x18(%rsp)
    a776:      	movw	$0x3, 0x1a(%rsp)
    a77d:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    a787:      	movq	%rax, 0x1c(%rsp)
    a78c:      	movl	$0x1, %eax
    a791:      	leaq	0x18(%rsp), %rsi
    a796:      	movq	(%rip), %rbx            # 0xa79d <generic_rawtp_actions+0x7dd>
    a79d:      	movq	%rbx, %rdi
    a7a0:      	callq	*%rax
    a7a2:      	testq	%rax, %rax
    a7a5:      	je	0xaa78 <generic_rawtp_actions+0xab8>
    a7ab:      	incl	(%rax)
    a7ad:      	jmp	0xaa9e <generic_rawtp_actions+0xade>
    a7b2:      	movl	$0x3, %eax
    a7b7:      	leaq	0x18(%rsp), %rsi
    a7bc:      	movq	(%rip), %rdi            # 0xa7c3 <generic_rawtp_actions+0x803>
    a7c3:      	callq	*%rax
    a7c5:      	movq	%rax, %rcx
    a7c8:      	movq	%rbp, %r14
    a7cb:      	movq	(%rip), %rbp            # 0xa7d2 <generic_rawtp_actions+0x812>
    a7d2:      	movq	0x8(%rsp), %rdx
    a7d7:      	testl	%ecx, %ecx
    a7d9:      	jne	0xa0fa <generic_rawtp_actions+0x13a>
    a7df:      	jmp	0xa0f0 <generic_rawtp_actions+0x130>
    a7e4:      	movl	$0x3, %eax
    a7e9:      	leaq	0x28(%rsp), %rsi
    a7ee:      	movq	(%rip), %rdi            # 0xa7f5 <generic_rawtp_actions+0x835>
    a7f5:      	callq	*%rax
    a7f7:      	movq	%rax, %rcx
    a7fa:      	movq	0x8(%rsp), %rdx
    a7ff:      	testl	%ecx, %ecx
    a801:      	jne	0xa0fa <generic_rawtp_actions+0x13a>
    a807:      	jmp	0xa0f0 <generic_rawtp_actions+0x130>
    a80c:      	movl	0x10(%rcx), %eax
    a80f:      	movq	%r14, 0x60(%rsp)
    a814:      	movl	%eax, %eax
    a816:      	movq	%rbx, 0x98(%rsp)
    a81e:      	movq	%rax, 0x10(%rbx)
    a822:      	movq	0x48(%rsp), %rdi
    a827:      	addq	$0x18, %rdi
    a82b:      	movl	$0x4, %eax
    a830:      	movl	$0xc8, %ecx
    a835:      	movq	%rdi, 0x48(%rsp)
    a83a:      	movl	$0xc8, %esi
    a83f:      	callq	*%rax
    a841:      	xorl	%r14d, %r14d
    a844:      	leaq	0x28(%rsp), %rbx
    a849:      	jmp	0xa863 <generic_rawtp_actions+0x8a3>
    a84b:      	nopl	(%rax,%rax)
    a850:      	leaq	0x28(%rsp), %rbx
    a855:      	addq	$0x4, %r14
    a859:      	cmpq	$0x14, %r14
    a85d:      	je	0xa98b <generic_rawtp_actions+0x9cb>
    a863:      	movl	$0x0, 0x28(%rsp)
    a86b:      	movl	$0x1, %eax
    a870:      	movq	%rbp, %rdi
    a873:      	movq	%rbx, %rsi
    a876:      	callq	*%rax
    a878:      	testq	%rax, %rax
    a87b:      	je	0xa98b <generic_rawtp_actions+0x9cb>
    a881:      	movq	%rax, %rsi
    a884:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    a88b:      	movl	$0x1, %eax
    a890:      	movq	(%rip), %rdi            # 0xa897 <generic_rawtp_actions+0x8d7>
    a897:      	callq	*%rax
    a899:      	testq	%rax, %rax
    a89c:      	je	0xa98b <generic_rawtp_actions+0x9cb>
    a8a2:      	cmpl	$-0x1, 0x40(%rax,%r14)
    a8a8:      	movq	0x8(%rsp), %rdx
    a8ad:      	je	0xa98b <generic_rawtp_actions+0x9cb>
    a8b3:      	movq	0x5e78(%rdx,%r14,2), %rax
    a8bb:      	movl	0x4(%rdx), %ecx
    a8be:      	cmpq	%rcx, %rax
    a8c1:      	jge	0xa98b <generic_rawtp_actions+0x9cb>
    a8c7:      	cmpq	$0x10, %r14
    a8cb:      	je	0xa932 <generic_rawtp_actions+0x972>
    a8cd:      	movl	$0x0, 0x28(%rsp)
    a8d5:      	movl	$0x1, %eax
    a8da:      	movq	%rbp, %rdi
    a8dd:      	movq	%rbx, %rsi
    a8e0:      	callq	*%rax
    a8e2:      	testq	%rax, %rax
    a8e5:      	je	0xa925 <generic_rawtp_actions+0x965>
    a8e7:      	movq	%rax, %rsi
    a8ea:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    a8f1:      	movl	$0x1, %eax
    a8f6:      	movq	(%rip), %rdi            # 0xa8fd <generic_rawtp_actions+0x93d>
    a8fd:      	callq	*%rax
    a8ff:      	testq	%rax, %rax
    a902:      	je	0xa925 <generic_rawtp_actions+0x965>
    a904:      	cmpl	$-0x1, 0x44(%rax,%r14)
    a90a:      	movq	0x8(%rsp), %rdx
    a90f:      	movq	0x5e78(%rdx,%r14,2), %rax
    a917:      	je	0xa932 <generic_rawtp_actions+0x972>
    a919:      	movl	0x5e80(%rdx,%r14,2), %ebx
    a921:      	subl	%eax, %ebx
    a923:      	jmp	0xa93a <generic_rawtp_actions+0x97a>
    a925:      	movq	0x8(%rsp), %rdx
    a92a:      	movq	0x5e78(%rdx,%r14,2), %rax
    a932:      	movl	0x4(%rdx), %ebx
    a935:      	subl	%eax, %ebx
    a937:      	addl	$0x4, %ebx
    a93a:      	testl	%ebx, %ebx
    a93c:      	jle	0xa850 <generic_rawtp_actions+0x890>
    a942:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    a947:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    a94c:      	cmpl	$0x28, %ebx
    a94f:      	movl	$0x28, %ecx
    a954:      	cmovgel	%ecx, %ebx
    a957:      	movzbl	0x38(%rsp), %ebp
    a95c:      	movq	0x48(%rsp), %rcx
    a961:      	leaq	(%rcx,%rbp), %rdi
    a965:      	addq	%rax, %rdx
    a968:      	addq	$0x90, %rdx
    a96f:      	movl	$0x4, %eax
    a974:      	movl	%ebx, %esi
    a976:      	callq	*%rax
    a978:      	addl	%ebp, %ebx
    a97a:      	movq	(%rip), %rbp            # 0xa981 <generic_rawtp_actions+0x9c1>
    a981:      	movq	%rbx, 0x38(%rsp)
    a986:      	jmp	0xa850 <generic_rawtp_actions+0x890>
    a98b:      	movl	$0x1, %eax
    a990:      	movq	(%rip), %rdi            # 0xa997 <generic_rawtp_actions+0x9d7>
    a997:      	movq	0x98(%rsp), %rbx
    a99f:      	movq	%rbx, %rsi
    a9a2:      	callq	*%rax
    a9a4:      	testq	%rax, %rax
    a9a7:      	movq	0x60(%rsp), %r14
    a9ac:      	je	0xa9ce <generic_rawtp_actions+0xa0e>
    a9ae:      	imulq	$-0xf4240, 0xa0(%rsp), %rcx # imm = 0xFFF0BDC0
    a9ba:      	addq	0x18(%rsp), %rcx
    a9bf:      	cmpq	%rcx, (%rax)
    a9c2:      	jbe	0xa9ce <generic_rawtp_actions+0xa0e>
    a9c4:      	movl	$0x0, 0x44(%rsp)
    a9cc:      	jmp	0xa9e8 <generic_rawtp_actions+0xa28>
    a9ce:      	movl	$0x2, %eax
    a9d3:      	xorl	%ecx, %ecx
    a9d5:      	movq	(%rip), %rdi            # 0xa9dc <generic_rawtp_actions+0xa1c>
    a9dc:      	leaq	0x18(%rsp), %rdx
    a9e1:      	movq	%rbx, %rsi
    a9e4:      	xorl	%ecx, %ecx
    a9e6:      	callq	*%rax
    a9e8:      	leal	0x3(%r15), %eax
    a9ec:      	cmpl	$0x0, 0x4(%r14,%rax,4)
    a9f2:      	movq	0x8(%rsp), %rdx
    a9f7:      	je	0xaa23 <generic_rawtp_actions+0xa63>
    a9f9:      	orb	$0x2, 0x1(%rdx)
    a9fd:      	movl	$0x1b, %eax
    aa02:      	movq	0x80(%rsp), %rdi
    aa0a:      	xorl	%ecx, %ecx
    aa0c:      	movq	(%rip), %rsi            # 0xaa13 <generic_rawtp_actions+0xa53>
    aa13:      	xorl	%edx, %edx
    aa15:      	callq	*%rax
    aa17:      	movq	0x8(%rsp), %rdx
    aa1c:      	movq	%rax, 0x80(%rdx)
    aa23:      	leal	0x4(%r15), %eax
    aa27:      	cmpl	$0x0, 0x4(%r14,%rax,4)
    aa2d:      	je	0xaa5f <generic_rawtp_actions+0xa9f>
    aa2f:      	orb	$0x4, 0x1(%rdx)
    aa33:      	movl	$0x1b, %eax
    aa38:      	movq	0x80(%rsp), %rdi
    aa40:      	movq	(%rip), %rsi            # 0xaa47 <generic_rawtp_actions+0xa87>
    aa47:      	movl	$0x100, %ecx            # imm = 0x100
    aa4c:      	movl	$0x100, %edx            # imm = 0x100
    aa51:      	callq	*%rax
    aa53:      	movq	0x8(%rsp), %rdx
    aa58:      	movq	%rax, 0x88(%rdx)
    aa5f:      	addl	$0x5, %r15d
    aa63:      	cmpl	$0x0, 0x4(%r14,%r15,4)
    aa69:      	je	0xa0f0 <generic_rawtp_actions+0x130>
    aa6f:      	orb	$0x8, 0x1(%rdx)
    aa73:      	jmp	0xa0f0 <generic_rawtp_actions+0x130>
    aa78:      	movl	$0x1, 0x94(%rsp)
    aa83:      	movl	$0x2, %eax
    aa88:      	xorl	%ecx, %ecx
    aa8a:      	leaq	0x94(%rsp), %rdx
    aa92:      	leaq	0x18(%rsp), %rsi
    aa97:      	movq	%rbx, %rdi
    aa9a:      	xorl	%ecx, %ecx
    aa9c:      	callq	*%rax
    aa9e:      	cmpl	$0x0, 0x38(%rsp)
    aaa3:      	je	0xa51a <generic_rawtp_actions+0x55a>
    aaa9:      	movl	$0x1, %eax
    aaae:      	leaq	0x28(%rsp), %rsi
    aab3:      	movq	(%rip), %rdi            # 0xaaba <generic_rawtp_actions+0xafa>
    aaba:      	callq	*%rax
    aabc:      	testq	%rax, %rax
    aabf:      	je	0xa51a <generic_rawtp_actions+0x55a>
    aac5:      	movl	0x5c(%rsp), %ecx
    aac9:      	lock
    aaca:      	addl	%ecx, (%rax)
    aacc:      	jmp	0xa51a <generic_rawtp_actions+0x55a>
    aad1:      	cmpb	$0x0, 0x44(%rsp)
    aad6:      	je	0xaaf8 <generic_rawtp_actions+0xb38>
    aad8:      	movq	(%rip), %rsi            # 0xaadf <generic_rawtp_actions+0xb1f>
    aadf:      	movl	$0x5, %ecx
    aae4:      	movl	$0xc, %eax
    aae9:      	movq	0x80(%rsp), %rdi
    aaf1:      	movl	$0x5, %edx
    aaf6:      	callq	*%rax
    aaf8:      	xorl	%eax, %eax
    aafa:      	addq	$0xa8, %rsp
    ab01:      	popq	%rbx
    ab02:      	popq	%r12
    ab04:      	popq	%r13
    ab06:      	popq	%r14
    ab08:      	popq	%r15
    ab0a:      	popq	%rbp
    ab0b:      	retq
    ab0c:      	nopl	(%rax)

000000000000ab10 <generic_rawtp_output>:
    ab10:      	pushq	%rbp
    ab11:      	pushq	%r15
    ab13:      	pushq	%r14
    ab15:      	pushq	%r13
    ab17:      	pushq	%r12
    ab19:      	pushq	%rbx
    ab1a:      	subq	$0x78, %rsp
    ab1e:      	movq	%rdi, %r14
    ab21:      	movl	$0x0, 0x24(%rsp)
    ab29:      	movq	(%rip), %rdi            # 0xab30 <generic_rawtp_output+0x20>
    ab30:      	leaq	0x24(%rsp), %rsi
    ab35:      	movl	$0x1, %eax
    ab3a:      	callq	*%rax
    ab3c:      	testq	%rax, %rax
    ab3f:      	je	0xafe9 <generic_rawtp_output+0x4d9>
    ab45:      	movq	%rax, %rbx
    ab48:      	cmpq	$0x0, 0x5ee8(%rax)
    ab50:      	je	0xae58 <generic_rawtp_output+0x348>
    ab56:      	movl	$0xe, %eax
    ab5b:      	callq	*%rax
    ab5d:      	movq	%rax, %r15
    ab60:      	shrq	$0x20, %r15
    ab64:      	movl	$0x23, %eax
    ab69:      	callq	*%rax
    ab6b:      	movq	%rax, %r12
    ab6e:      	movl	%r15d, 0x28(%rsp)
    ab73:      	movq	(%rip), %rdi            # 0xab7a <generic_rawtp_output+0x6a>
    ab7a:      	leaq	0x28(%rsp), %rsi
    ab7f:      	movl	$0x1, %eax
    ab84:      	callq	*%rax
    ab86:      	testq	%rax, %rax
    ab89:      	je	0xae58 <generic_rawtp_output+0x348>
    ab8f:      	movq	%rax, %r15
    ab92:      	leaq	0xd70(%r12), %rdx
    ab9a:      	leaq	0x70(%rsp), %rdi
    ab9f:      	movl	$0x8, %ecx
    aba4:      	movl	$0x4, %eax
    aba9:      	leaq	0x28(%r15), %r13
    abad:      	movl	$0x4, %ebp
    abb2:      	movl	$0x8, %esi
    abb7:      	callq	*%rax
    abb9:      	movq	0x70(%rsp), %rcx
    abbe:      	leaq	0x28(%rsp), %rdi
    abc3:      	movl	$0x48, %edx
    abc8:      	movl	$0x4, %eax
    abcd:      	movq	0x70(%rsp), %rdx
    abd2:      	movl	$0x48, %esi
    abd7:      	callq	*%rax
    abd9:      	movl	$0x218, %edx            # imm = 0x218
    abde:      	movq	0x30(%rsp), %rcx
    abe3:      	addq	%rdx, %rcx
    abe6:      	movl	$0x4, %esi
    abeb:      	movl	$0x4, %eax
    abf0:      	addq	0x30(%rsp), %rdx
    abf5:      	movq	%r13, %rdi
    abf8:      	movl	$0x4, %esi
    abfd:      	callq	*%rax
    abff:      	leaq	0x2c(%r15), %rdi
    ac03:      	movl	$0x4d8, %edx            # imm = 0x4D8
    ac08:      	movq	0x38(%rsp), %rcx
    ac0d:      	addq	%rdx, %rcx
    ac10:      	movl	$0x4, %esi
    ac15:      	movl	$0x4, %eax
    ac1a:      	addq	0x38(%rsp), %rdx
    ac1f:      	movl	$0x4, %esi
    ac24:      	callq	*%rax
    ac26:      	leaq	0x30(%r15), %rdi
    ac2a:      	movq	0x40(%rsp), %rcx
    ac2f:      	addq	$0x58, %rcx
    ac33:      	movl	$0x4, %edx
    ac38:      	movl	$0x4, %eax
    ac3d:      	movq	0x40(%rsp), %rdx
    ac42:      	addq	$0x58, %rdx
    ac46:      	movl	$0x4, %esi
    ac4b:      	callq	*%rax
    ac4d:      	movq	$0x0, (%rsp)
    ac55:      	leaq	0xb58(%r12), %rdx
    ac5d:      	movq	%rsp, %rdi
    ac60:      	movl	$0x8, %ecx
    ac65:      	movl	$0x4, %eax
    ac6a:      	movl	$0x8, %esi
    ac6f:      	callq	*%rax
    ac71:      	movq	(%rsp), %rcx
    ac75:      	testq	%rcx, %rcx
    ac78:      	je	0xad0b <generic_rawtp_output+0x1fb>
    ac7e:      	movl	$0x0, 0xc(%rsp)
    ac86:      	addq	$0x4, %rcx
    ac8a:      	leaq	0xc(%rsp), %rdi
    ac8f:      	movl	$0x4, %eax
    ac94:      	movq	(%rsp), %rdx
    ac98:      	addq	$0x4, %rdx
    ac9c:      	movl	$0x4, %esi
    aca1:      	callq	*%rax
    aca3:      	movq	(%rsp), %rax
    aca7:      	movslq	0xc(%rsp), %rcx
    acac:      	shlq	$0x4, %rcx
    acb0:      	addq	%rax, %rcx
    acb3:      	addq	$0x80, %rcx
    acba:      	leaq	0x10(%rsp), %rdi
    acbf:      	movl	$0x10, %edx
    acc4:      	movl	$0x4, %eax
    acc9:      	movq	(%rsp), %rcx
    accd:      	movslq	0xc(%rsp), %rdx
    acd2:      	shlq	$0x4, %rdx
    acd6:      	addq	%rcx, %rdx
    acd9:      	addq	$0x80, %rdx
    ace0:      	movl	$0x10, %esi
    ace5:      	callq	*%rax
    ace7:      	leaq	0x34(%r15), %rdi
    aceb:      	movl	$0x158, %edx            # imm = 0x158
    acf0:      	movq	0x18(%rsp), %rcx
    acf5:      	addq	%rdx, %rcx
    acf8:      	movl	$0x4, %eax
    acfd:      	addq	0x18(%rsp), %rdx
    ad02:      	movl	$0x4, %esi
    ad07:      	callq	*%rax
    ad09:      	jmp	0xad13 <generic_rawtp_output+0x203>
    ad0b:      	movl	$0x0, 0x34(%r15)
    ad13:      	leaq	0x38(%r15), %rdi
    ad17:      	movl	$0x158, %r13d           # imm = 0x158
    ad1d:      	movq	0x48(%rsp), %rcx
    ad22:      	addq	%r13, %rcx
    ad25:      	movl	$0x4, %edx
    ad2a:      	movl	$0x4, %eax
    ad2f:      	movq	0x48(%rsp), %rdx
    ad34:      	addq	%r13, %rdx
    ad37:      	movl	$0x4, %esi
    ad3c:      	callq	*%rax
    ad3e:      	leaq	0x3c(%r15), %rdi
    ad42:      	movl	$0x118, %edx            # imm = 0x118
    ad47:      	movq	0x50(%rsp), %rcx
    ad4c:      	addq	%rdx, %rcx
    ad4f:      	movl	$0x4, %esi
    ad54:      	movl	$0x4, %eax
    ad59:      	addq	0x50(%rsp), %rdx
    ad5e:      	movl	$0x4, %esi
    ad63:      	callq	*%rax
    ad65:      	leaq	0x40(%r15), %rdi
    ad69:      	movl	$0x98, %ebp
    ad6e:      	movq	0x58(%rsp), %rcx
    ad73:      	addq	%rbp, %rcx
    ad76:      	movl	$0x4, %edx
    ad7b:      	movl	$0x4, %eax
    ad80:      	movq	0x58(%rsp), %rdx
    ad85:      	addq	%rbp, %rdx
    ad88:      	movl	$0x4, %esi
    ad8d:      	callq	*%rax
    ad8f:      	leaq	0x44(%r15), %rdi
    ad93:      	movq	0x60(%rsp), %rcx
    ad98:      	addq	%rbp, %rcx
    ad9b:      	movl	$0x4, %edx
    ada0:      	movl	$0x4, %eax
    ada5:      	addq	0x60(%rsp), %rbp
    adaa:      	movl	$0x4, %esi
    adaf:      	movq	%rbp, %rdx
    adb2:      	callq	*%rax
    adb4:      	leaq	0x48(%r15), %rdi
    adb8:      	movq	0x68(%rsp), %rcx
    adbd:      	addq	$0x58, %rcx
    adc1:      	movl	$0x4, %edx
    adc6:      	movl	$0x4, %eax
    adcb:      	movq	0x68(%rsp), %rdx
    add0:      	addq	$0x58, %rdx
    add4:      	movl	$0x4, %esi
    add9:      	callq	*%rax
    addb:      	movq	$0x0, 0x10(%rsp)
    ade4:      	movq	$0x0, (%rsp)
    adec:      	addq	$0xd00, %r12            # imm = 0xD00
    adf3:      	leaq	0x10(%rsp), %rdi
    adf8:      	movl	$0x8, %ecx
    adfd:      	movl	$0x4, %eax
    ae02:      	movl	$0x8, %esi
    ae07:      	movq	%r12, %rdx
    ae0a:      	callq	*%rax
    ae0c:      	movl	$0x90, %edx
    ae11:      	movq	0x10(%rsp), %rcx
    ae16:      	addq	%rdx, %rcx
    ae19:      	movq	%rsp, %rdi
    ae1c:      	movl	$0x8, %esi
    ae21:      	movl	$0x4, %eax
    ae26:      	addq	0x10(%rsp), %rdx
    ae2b:      	movl	$0x8, %esi
    ae30:      	callq	*%rax
    ae32:      	addq	$0x4c, %r15
    ae36:      	movq	(%rsp), %rcx
    ae3a:      	addq	%r13, %rcx
    ae3d:      	movl	$0x4, %edx
    ae42:      	movl	$0x4, %eax
    ae47:      	addq	(%rsp), %r13
    ae4b:      	movq	%r15, %rdi
    ae4e:      	movl	$0x4, %esi
    ae53:      	movq	%r13, %rdx
    ae56:      	callq	*%rax
    ae58:      	cmpq	$0x0, 0x5ef0(%rbx)
    ae60:      	je	0xaf19 <generic_rawtp_output+0x409>
    ae66:      	movl	$0xe, %eax
    ae6b:      	callq	*%rax
    ae6d:      	movq	%rax, %r15
    ae70:      	shrq	$0x20, %r15
    ae74:      	movl	$0x23, %eax
    ae79:      	callq	*%rax
    ae7b:      	movq	%rax, %r12
    ae7e:      	movl	%r15d, 0x28(%rsp)
    ae83:      	movq	(%rip), %rdi            # 0xae8a <generic_rawtp_output+0x37a>
    ae8a:      	leaq	0x28(%rsp), %rsi
    ae8f:      	movl	$0x1, %eax
    ae94:      	callq	*%rax
    ae96:      	testq	%rax, %rax
    ae99:      	je	0xaf19 <generic_rawtp_output+0x409>
    ae9b:      	leaq	0x50(%rax), %r15
    ae9f:      	addq	$0xd00, %r12            # imm = 0xD00
    aea6:      	leaq	0x28(%rsp), %rdi
    aeab:      	movl	$0x8, %ecx
    aeb0:      	movq	%rax, %r13
    aeb3:      	movl	$0x4, %eax
    aeb8:      	movl	$0x8, %esi
    aebd:      	movq	%r12, %rdx
    aec0:      	callq	*%rax
    aec2:      	movq	0x28(%rsp), %r12
    aec7:      	leaq	0x58(%r13), %rdi
    aecb:      	leaq	0x40(%r12), %rdx
    aed0:      	movl	$0x8, %ecx
    aed5:      	movl	$0x4, %eax
    aeda:      	movl	$0x8, %esi
    aedf:      	callq	*%rax
    aee1:      	addq	$0x60, %r13
    aee5:      	leaq	0x30(%r12), %rdx
    aeea:      	movl	$0x8, %ecx
    aeef:      	movl	$0x4, %eax
    aef4:      	movq	%r13, %rdi
    aef7:      	movl	$0x8, %esi
    aefc:      	callq	*%rax
    aefe:      	addq	$0x38, %r12
    af02:      	movl	$0x8, %ecx
    af07:      	movl	$0x4, %eax
    af0c:      	movq	%r15, %rdi
    af0f:      	movl	$0x8, %esi
    af14:      	movq	%r12, %rdx
    af17:      	callq	*%rax
    af19:      	movl	$0x90, %eax
    af1e:      	addl	0x4(%rbx), %eax
    af21:      	andl	$0x7fff, %eax           # imm = 0x7FFF
    af26:      	cmpl	$0x2328, %eax           # imm = 0x2328
    af2b:      	movl	$0x2328, %r15d          # imm = 0x2328
    af31:      	cmovbl	%eax, %r15d
    af35:      	movl	$0x0, 0x10(%rsp)
    af3d:      	movq	(%rip), %rdi            # 0xaf44 <generic_rawtp_output+0x434>
    af44:      	leaq	0x10(%rsp), %rsi
    af49:      	movl	$0x1, %eax
    af4e:      	callq	*%rax
    af50:      	testq	%rax, %rax
    af53:      	je	0xafa7 <generic_rawtp_output+0x497>
    af55:      	cmpb	$0x0, 0x28(%rax)
    af59:      	je	0xafa7 <generic_rawtp_output+0x497>
    af5b:      	movq	(%rip), %rsi            # 0xaf62 <generic_rawtp_output+0x452>
    af62:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    af67:      	movl	$0x19, %eax
    af6c:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    af71:      	movq	%r14, %rdi
    af74:      	movq	%rbx, %rcx
    af77:      	movq	%r15, %r8
    af7a:      	callq	*%rax
    af7c:      	testq	%rax, %rax
    af7f:      	js	0xb049 <generic_rawtp_output+0x539>
    af85:      	movl	$0x0, 0x28(%rsp)
    af8d:      	movq	(%rip), %rdi            # 0xaf94 <generic_rawtp_output+0x484>
    af94:      	leaq	0x28(%rsp), %rsi
    af99:      	movl	$0x1, %eax
    af9e:      	callq	*%rax
    afa0:      	testq	%rax, %rax
    afa3:      	jne	0xafe4 <generic_rawtp_output+0x4d4>
    afa5:      	jmp	0xafe9 <generic_rawtp_output+0x4d9>
    afa7:      	movq	(%rip), %rdi            # 0xafae <generic_rawtp_output+0x49e>
    afae:      	xorl	%ecx, %ecx
    afb0:      	movl	$0x82, %eax
    afb5:      	movq	%rbx, %rsi
    afb8:      	movq	%r15, %rdx
    afbb:      	xorl	%ecx, %ecx
    afbd:      	callq	*%rax
    afbf:      	testq	%rax, %rax
    afc2:      	js	0xaffa <generic_rawtp_output+0x4ea>
    afc4:      	movl	$0x0, 0x28(%rsp)
    afcc:      	movq	(%rip), %rdi            # 0xafd3 <generic_rawtp_output+0x4c3>
    afd3:      	leaq	0x28(%rsp), %rsi
    afd8:      	movl	$0x1, %eax
    afdd:      	callq	*%rax
    afdf:      	testq	%rax, %rax
    afe2:      	je	0xafe9 <generic_rawtp_output+0x4d9>
    afe4:      	lock
    afe5:      	incq	0x8(%rax)
    afe9:      	xorl	%eax, %eax
    afeb:      	addq	$0x78, %rsp
    afef:      	popq	%rbx
    aff0:      	popq	%r12
    aff2:      	popq	%r13
    aff4:      	popq	%r14
    aff6:      	popq	%r15
    aff8:      	popq	%rbp
    aff9:      	retq
    affa:      	movq	%rax, %rbx
    affd:      	movl	$0x0, 0x28(%rsp)
    b005:      	movq	(%rip), %rdi            # 0xb00c <generic_rawtp_output+0x4fc>
    b00c:      	leaq	0x28(%rsp), %rsi
    b011:      	movl	$0x1, %eax
    b016:      	callq	*%rax
    b018:      	testq	%rax, %rax
    b01b:      	je	0xafe9 <generic_rawtp_output+0x4d9>
    b01d:      	cmpq	$-0xc, %rbx
    b021:      	jg	0xb091 <generic_rawtp_output+0x581>
    b023:      	cmpq	$-0x1c, %rbx
    b027:      	je	0xb0d3 <generic_rawtp_output+0x5c3>
    b02d:      	cmpq	$-0x16, %rbx
    b031:      	je	0xb082 <generic_rawtp_output+0x572>
    b033:      	cmpq	$-0x10, %rbx
    b037:      	jne	0xb0c4 <generic_rawtp_output+0x5b4>
    b03d:      	addq	$0x328, %rax            # imm = 0x328
    b043:      	lock
    b044:      	incq	(%rax)
    b047:      	jmp	0xafe9 <generic_rawtp_output+0x4d9>
    b049:      	movq	%rax, %rbx
    b04c:      	movl	$0x0, 0x28(%rsp)
    b054:      	movq	(%rip), %rdi            # 0xb05b <generic_rawtp_output+0x54b>
    b05b:      	leaq	0x28(%rsp), %rsi
    b060:      	movl	$0x1, %eax
    b065:      	callq	*%rax
    b067:      	testq	%rax, %rax
    b06a:      	je	0xafe9 <generic_rawtp_output+0x4d9>
    b070:      	cmpq	$-0xc, %rbx
    b074:      	jg	0xb0b2 <generic_rawtp_output+0x5a2>
    b076:      	cmpq	$-0x1c, %rbx
    b07a:      	je	0xb0d3 <generic_rawtp_output+0x5c3>
    b07c:      	cmpq	$-0x16, %rbx
    b080:      	jne	0xb033 <generic_rawtp_output+0x523>
    b082:      	addq	$0x330, %rax            # imm = 0x330
    b088:      	lock
    b089:      	incq	(%rax)
    b08c:      	jmp	0xafe9 <generic_rawtp_output+0x4d9>
    b091:      	cmpq	$-0xb, %rbx
    b095:      	je	0xb0e2 <generic_rawtp_output+0x5d2>
    b097:      	cmpq	$-0x7, %rbx
    b09b:      	je	0xb0f1 <generic_rawtp_output+0x5e1>
    b09d:      	cmpq	$-0x2, %rbx
    b0a1:      	jne	0xb0c4 <generic_rawtp_output+0x5b4>
    b0a3:      	addq	$0x318, %rax            # imm = 0x318
    b0a9:      	lock
    b0aa:      	incq	(%rax)
    b0ad:      	jmp	0xafe9 <generic_rawtp_output+0x4d9>
    b0b2:      	cmpq	$-0xb, %rbx
    b0b6:      	je	0xb0e2 <generic_rawtp_output+0x5d2>
    b0b8:      	cmpq	$-0x7, %rbx
    b0bc:      	je	0xb0f1 <generic_rawtp_output+0x5e1>
    b0be:      	cmpq	$-0x2, %rbx
    b0c2:      	je	0xb0a3 <generic_rawtp_output+0x593>
    b0c4:      	addq	$0x310, %rax            # imm = 0x310
    b0ca:      	lock
    b0cb:      	incq	(%rax)
    b0ce:      	jmp	0xafe9 <generic_rawtp_output+0x4d9>
    b0d3:      	addq	$0x338, %rax            # imm = 0x338
    b0d9:      	lock
    b0da:      	incq	(%rax)
    b0dd:      	jmp	0xafe9 <generic_rawtp_output+0x4d9>
    b0e2:      	addq	$0x340, %rax            # imm = 0x340
    b0e8:      	lock
    b0e9:      	incq	(%rax)
    b0ec:      	jmp	0xafe9 <generic_rawtp_output+0x4d9>
    b0f1:      	addq	$0x320, %rax            # imm = 0x320
    b0f7:      	lock
    b0f8:      	incq	(%rax)
    b0fb:      	jmp	0xafe9 <generic_rawtp_output+0x4d9>

000000000000b100 <generic_rawtp_path>:
    b100:      	pushq	%rbp
    b101:      	pushq	%r15
    b103:      	pushq	%r14
    b105:      	pushq	%r13
    b107:      	pushq	%r12
    b109:      	pushq	%rbx
    b10a:      	subq	$0x88, %rsp
    b111:      	movq	%rdi, %rbp
    b114:      	movl	$0x0, 0x70(%rsp)
    b11c:      	movq	(%rip), %rdi            # 0xb123 <generic_rawtp_path+0x23>
    b123:      	leaq	0x70(%rsp), %rsi
    b128:      	movl	$0x1, %eax
    b12d:      	callq	*%rax
    b12f:      	testq	%rax, %rax
    b132:      	je	0x16f79 <generic_rawtp_path+0xbe79>
    b138:      	movq	%rax, %r14
    b13b:      	movl	0x6420(%rax), %eax
    b141:      	cmpl	$0x1, %eax
    b144:      	je	0xb1e6 <generic_rawtp_path+0xe6>
    b14a:      	testl	%eax, %eax
    b14c:      	jne	0x16f79 <generic_rawtp_path+0xbe79>
    b152:      	movq	0x6440(%r14), %r12
    b159:      	movl	$0x0, 0x10(%rsp)
    b161:      	movq	(%rip), %rdi            # 0xb168 <generic_rawtp_path+0x68>
    b168:      	leaq	0x10(%rsp), %rsi
    b16d:      	movl	$0x1, %eax
    b172:      	callq	*%rax
    b174:      	testq	%rax, %rax
    b177:      	je	0x16f79 <generic_rawtp_path+0xbe79>
    b17d:      	movq	%rax, %r15
    b180:      	addq	$0x8, %r12
    b184:      	leaq	0x58(%rsp), %rdi
    b189:      	movl	$0x8, %ecx
    b18e:      	movl	$0x4, %eax
    b193:      	movl	$0x8, %esi
    b198:      	movq	%r12, %rdx
    b19b:      	callq	*%rax
    b19d:      	testq	%rax, %rax
    b1a0:      	je	0x16c29 <generic_rawtp_path+0xbb29>
    b1a6:      	negl	%eax
    b1a8:      	movw	%ax, 0x18(%rsp)
    b1ad:      	movw	$0x6, 0x1a(%rsp)
    b1b4:      	movabsq	$0x40000002c, %rax      # imm = 0x40000002C
    b1be:      	movq	%rax, 0x1c(%rsp)
    b1c3:      	movq	(%rip), %rdi            # 0xb1ca <generic_rawtp_path+0xca>
    b1ca:      	leaq	0x18(%rsp), %rsi
    b1cf:      	movl	$0x1, %eax
    b1d4:      	callq	*%rax
    b1d6:      	testq	%rax, %rax
    b1d9:      	je	0x16c08 <generic_rawtp_path+0xbb08>
    b1df:      	incl	(%rax)
    b1e1:      	jmp	0x16c29 <generic_rawtp_path+0xbb29>
    b1e6:      	movq	0x6448(%r14), %rax
    b1ed:      	movq	%rax, 0x18(%rsp)
    b1f2:      	movq	0x6450(%r14), %rax
    b1f9:      	movq	%rax, 0x20(%rsp)
    b1fe:      	movq	$0x0, 0x28(%rsp)
    b207:      	movq	0x6458(%r14), %rax
    b20e:      	movq	%rax, 0x30(%rsp)
    b213:      	movq	0x6460(%r14), %rax
    b21a:      	movq	%rax, 0x38(%rsp)
    b21f:      	movq	0x6468(%r14), %rax
    b226:      	movq	%rax, 0x40(%rsp)
    b22b:      	movq	$0x0, 0x48(%rsp)
    b234:      	movl	$0x0, 0x50(%rsp)
    b23c:      	movb	$0x0, 0x54(%rsp)
    b241:      	movl	$0x0, 0x74(%rsp)
    b249:      	movq	(%rip), %rdi            # 0xb250 <generic_rawtp_path+0x150>
    b250:      	leaq	0x74(%rsp), %rsi
    b255:      	movl	$0x1, %eax
    b25a:      	callq	*%rax
    b25c:      	testq	%rax, %rax
    b25f:      	je	0x16f79 <generic_rawtp_path+0xbe79>
    b265:      	movq	%rbp, 0x78(%rsp)
    b26a:      	movq	%rax, 0x28(%rsp)
    b26f:      	movl	0x6424(%r14), %edx
    b276:      	movl	%edx, %ecx
    b278:      	andl	$0xfff, %ecx            # imm = 0xFFF
    b27e:      	movq	%rax, %rsi
    b281:      	movq	%rax, 0x80(%rsp)
    b289:      	addq	%rax, %rcx
    b28c:      	movq	%rcx, 0x48(%rsp)
    b291:      	movl	%edx, 0x50(%rsp)
    b295:      	movl	$0x200, %eax            # imm = 0x200
    b29a:      	movl	$0x8, %r13d
    b2a0:      	movq	%rsp, %rbp
    b2a3:      	movl	%eax, 0x6c(%rsp)
    b2a7:      	movq	0x30(%rsp), %r12
    b2ac:      	movq	0x38(%rsp), %rdx
    b2b1:      	movq	0x40(%rsp), %r15
    b2b6:      	cmpq	0x18(%rsp), %r12
    b2bb:      	jne	0xb2c8 <generic_rawtp_path+0x1c8>
    b2bd:      	cmpq	0x20(%rsp), %rdx
    b2c2:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    b2c8:      	movl	$0x4, %eax
    b2cd:      	leaq	0x10(%rsp), %rdi
    b2d2:      	movl	$0x8, %esi
    b2d7:      	callq	*%rax
    b2d9:      	cmpq	0x10(%rsp), %r12
    b2de:      	je	0xb3dd <generic_rawtp_path+0x2dd>
    b2e4:      	leaq	0x18(%r12), %rbx
    b2e9:      	movl	$0x4, %eax
    b2ee:      	movq	%rbp, %rdi
    b2f1:      	movl	$0x8, %esi
    b2f6:      	movq	%rbx, %rdx
    b2f9:      	callq	*%rax
    b2fb:      	cmpq	%r12, (%rsp)
    b2ff:      	je	0xb3dd <generic_rawtp_path+0x2dd>
    b305:      	movl	$0x4, %eax
    b30a:      	leaq	0x8(%rsp), %rdi
    b30f:      	movl	$0x8, %esi
    b314:      	movq	%rbx, %rdx
    b317:      	callq	*%rax
    b319:      	addq	$0x20, %r12
    b31d:      	movl	$0x4, %eax
    b322:      	leaq	0x58(%rsp), %rdi
    b327:      	movl	$0x10, %ecx
    b32c:      	movl	$0x10, %esi
    b331:      	movq	%r12, %rdx
    b334:      	callq	*%rax
    b336:      	movq	0x28(%rsp), %rbx
    b33b:      	movq	0x48(%rsp), %rax
    b340:      	movl	0x5c(%rsp), %r15d
    b345:      	subq	%rbx, %rax
    b348:      	movl	0x50(%rsp), %r12d
    b34d:      	movl	%r15d, %edx
    b350:      	subl	%r12d, %edx
    b353:      	movl	$0x0, %ecx
    b358:      	cmovbl	%ecx, %edx
    b35b:      	addq	0x60(%rsp), %rdx
    b360:      	xorl	%esi, %esi
    b362:      	cmpl	%r15d, %r12d
    b365:      	seta	%sil
    b369:      	movl	%r15d, %ecx
    b36c:      	cmovbl	%r12d, %ecx
    b370:      	addl	%ecx, %esi
    b372:      	movl	%r12d, %edi
    b375:      	subl	%esi, %edi
    b377:      	movl	%edi, 0x50(%rsp)
    b37b:      	subq	%rsi, %rax
    b37e:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    b384:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b38a:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    b390:      	cmpl	%r15d, %r12d
    b393:      	jbe	0xb399 <generic_rawtp_path+0x299>
    b395:      	movb	$0x2f, (%rbx,%rax)
    b399:      	xorl	%edi, %edi
    b39b:      	cmpl	%r15d, %r12d
    b39e:      	seta	%dil
    b3a2:      	movzbl	%cl, %esi
    b3a5:      	addq	%rax, %rbx
    b3a8:      	addq	%rbx, %rdi
    b3ab:      	movl	$0x4, %eax
    b3b0:      	callq	*%rax
    b3b2:      	movq	%rbx, 0x48(%rsp)
    b3b7:      	cmpl	%r15d, %r12d
    b3ba:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    b3c0:      	movq	0x8(%rsp), %r12
    b3c5:      	movq	%r12, 0x30(%rsp)
    b3ca:      	movq	0x38(%rsp), %rdx
    b3cf:      	movq	0x40(%rsp), %r15
    b3d4:      	cmpq	0x18(%rsp), %r12
    b3d9:      	je	0xb435 <generic_rawtp_path+0x335>
    b3db:      	jmp	0xb440 <generic_rawtp_path+0x340>
    b3dd:      	leaq	0x10(%r15), %rdx
    b3e1:      	movl	$0x4, %eax
    b3e6:      	movq	%rbp, %rdi
    b3e9:      	movl	$0x8, %esi
    b3ee:      	callq	*%rax
    b3f0:      	movq	0x40(%rsp), %rax
    b3f5:      	cmpq	(%rsp), %rax
    b3f9:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    b3ff:      	addq	$0x18, %r15
    b403:      	movl	$0x4, %eax
    b408:      	leaq	0x30(%rsp), %rdi
    b40d:      	movl	$0x8, %esi
    b412:      	movq	%r15, %rdx
    b415:      	callq	*%rax
    b417:      	movq	(%rsp), %r15
    b41b:      	movq	%r15, 0x40(%rsp)
    b420:      	leaq	0x20(%r15), %rdx
    b424:      	movq	%rdx, 0x38(%rsp)
    b429:      	movq	0x30(%rsp), %r12
    b42e:      	cmpq	0x18(%rsp), %r12
    b433:      	jne	0xb440 <generic_rawtp_path+0x340>
    b435:      	cmpq	0x20(%rsp), %rdx
    b43a:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    b440:      	movl	$0x4, %eax
    b445:      	leaq	0x10(%rsp), %rdi
    b44a:      	movl	$0x8, %esi
    b44f:      	callq	*%rax
    b451:      	cmpq	0x10(%rsp), %r12
    b456:      	je	0xb555 <generic_rawtp_path+0x455>
    b45c:      	leaq	0x18(%r12), %rbx
    b461:      	movl	$0x4, %eax
    b466:      	movq	%rbp, %rdi
    b469:      	movl	$0x8, %esi
    b46e:      	movq	%rbx, %rdx
    b471:      	callq	*%rax
    b473:      	cmpq	%r12, (%rsp)
    b477:      	je	0xb555 <generic_rawtp_path+0x455>
    b47d:      	movl	$0x4, %eax
    b482:      	leaq	0x8(%rsp), %rdi
    b487:      	movl	$0x8, %esi
    b48c:      	movq	%rbx, %rdx
    b48f:      	callq	*%rax
    b491:      	addq	$0x20, %r12
    b495:      	movl	$0x4, %eax
    b49a:      	leaq	0x58(%rsp), %rdi
    b49f:      	movl	$0x10, %ecx
    b4a4:      	movl	$0x10, %esi
    b4a9:      	movq	%r12, %rdx
    b4ac:      	callq	*%rax
    b4ae:      	movq	0x28(%rsp), %rbx
    b4b3:      	movq	0x48(%rsp), %rax
    b4b8:      	movl	0x5c(%rsp), %r15d
    b4bd:      	subq	%rbx, %rax
    b4c0:      	movl	0x50(%rsp), %r12d
    b4c5:      	movl	%r15d, %edx
    b4c8:      	subl	%r12d, %edx
    b4cb:      	movl	$0x0, %ecx
    b4d0:      	cmovbl	%ecx, %edx
    b4d3:      	addq	0x60(%rsp), %rdx
    b4d8:      	xorl	%esi, %esi
    b4da:      	cmpl	%r15d, %r12d
    b4dd:      	seta	%sil
    b4e1:      	movl	%r15d, %ecx
    b4e4:      	cmovbl	%r12d, %ecx
    b4e8:      	addl	%ecx, %esi
    b4ea:      	movl	%r12d, %edi
    b4ed:      	subl	%esi, %edi
    b4ef:      	movl	%edi, 0x50(%rsp)
    b4f3:      	subq	%rsi, %rax
    b4f6:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    b4fc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b502:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    b508:      	cmpl	%r15d, %r12d
    b50b:      	jbe	0xb511 <generic_rawtp_path+0x411>
    b50d:      	movb	$0x2f, (%rbx,%rax)
    b511:      	xorl	%edi, %edi
    b513:      	cmpl	%r15d, %r12d
    b516:      	seta	%dil
    b51a:      	movzbl	%cl, %esi
    b51d:      	addq	%rax, %rbx
    b520:      	addq	%rbx, %rdi
    b523:      	movl	$0x4, %eax
    b528:      	callq	*%rax
    b52a:      	movq	%rbx, 0x48(%rsp)
    b52f:      	cmpl	%r15d, %r12d
    b532:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    b538:      	movq	0x8(%rsp), %r12
    b53d:      	movq	%r12, 0x30(%rsp)
    b542:      	movq	0x38(%rsp), %rdx
    b547:      	movq	0x40(%rsp), %r15
    b54c:      	cmpq	0x18(%rsp), %r12
    b551:      	je	0xb5ad <generic_rawtp_path+0x4ad>
    b553:      	jmp	0xb5b8 <generic_rawtp_path+0x4b8>
    b555:      	leaq	0x10(%r15), %rdx
    b559:      	movl	$0x4, %eax
    b55e:      	movq	%rbp, %rdi
    b561:      	movl	$0x8, %esi
    b566:      	callq	*%rax
    b568:      	movq	0x40(%rsp), %rax
    b56d:      	cmpq	(%rsp), %rax
    b571:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    b577:      	addq	$0x18, %r15
    b57b:      	movl	$0x4, %eax
    b580:      	leaq	0x30(%rsp), %rdi
    b585:      	movl	$0x8, %esi
    b58a:      	movq	%r15, %rdx
    b58d:      	callq	*%rax
    b58f:      	movq	(%rsp), %r15
    b593:      	movq	%r15, 0x40(%rsp)
    b598:      	leaq	0x20(%r15), %rdx
    b59c:      	movq	%rdx, 0x38(%rsp)
    b5a1:      	movq	0x30(%rsp), %r12
    b5a6:      	cmpq	0x18(%rsp), %r12
    b5ab:      	jne	0xb5b8 <generic_rawtp_path+0x4b8>
    b5ad:      	cmpq	0x20(%rsp), %rdx
    b5b2:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    b5b8:      	movl	$0x4, %eax
    b5bd:      	leaq	0x10(%rsp), %rdi
    b5c2:      	movl	$0x8, %esi
    b5c7:      	callq	*%rax
    b5c9:      	cmpq	0x10(%rsp), %r12
    b5ce:      	je	0xb6cd <generic_rawtp_path+0x5cd>
    b5d4:      	leaq	0x18(%r12), %rbx
    b5d9:      	movl	$0x4, %eax
    b5de:      	movq	%rbp, %rdi
    b5e1:      	movl	$0x8, %esi
    b5e6:      	movq	%rbx, %rdx
    b5e9:      	callq	*%rax
    b5eb:      	cmpq	%r12, (%rsp)
    b5ef:      	je	0xb6cd <generic_rawtp_path+0x5cd>
    b5f5:      	movl	$0x4, %eax
    b5fa:      	leaq	0x8(%rsp), %rdi
    b5ff:      	movl	$0x8, %esi
    b604:      	movq	%rbx, %rdx
    b607:      	callq	*%rax
    b609:      	addq	$0x20, %r12
    b60d:      	movl	$0x4, %eax
    b612:      	leaq	0x58(%rsp), %rdi
    b617:      	movl	$0x10, %ecx
    b61c:      	movl	$0x10, %esi
    b621:      	movq	%r12, %rdx
    b624:      	callq	*%rax
    b626:      	movq	0x28(%rsp), %rbx
    b62b:      	movq	0x48(%rsp), %rax
    b630:      	movl	0x5c(%rsp), %r15d
    b635:      	subq	%rbx, %rax
    b638:      	movl	0x50(%rsp), %r12d
    b63d:      	movl	%r15d, %edx
    b640:      	subl	%r12d, %edx
    b643:      	movl	$0x0, %ecx
    b648:      	cmovbl	%ecx, %edx
    b64b:      	addq	0x60(%rsp), %rdx
    b650:      	xorl	%esi, %esi
    b652:      	cmpl	%r15d, %r12d
    b655:      	seta	%sil
    b659:      	movl	%r15d, %ecx
    b65c:      	cmovbl	%r12d, %ecx
    b660:      	addl	%ecx, %esi
    b662:      	movl	%r12d, %edi
    b665:      	subl	%esi, %edi
    b667:      	movl	%edi, 0x50(%rsp)
    b66b:      	subq	%rsi, %rax
    b66e:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    b674:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b67a:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    b680:      	cmpl	%r15d, %r12d
    b683:      	jbe	0xb689 <generic_rawtp_path+0x589>
    b685:      	movb	$0x2f, (%rbx,%rax)
    b689:      	xorl	%edi, %edi
    b68b:      	cmpl	%r15d, %r12d
    b68e:      	seta	%dil
    b692:      	movzbl	%cl, %esi
    b695:      	addq	%rax, %rbx
    b698:      	addq	%rbx, %rdi
    b69b:      	movl	$0x4, %eax
    b6a0:      	callq	*%rax
    b6a2:      	movq	%rbx, 0x48(%rsp)
    b6a7:      	cmpl	%r15d, %r12d
    b6aa:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    b6b0:      	movq	0x8(%rsp), %r12
    b6b5:      	movq	%r12, 0x30(%rsp)
    b6ba:      	movq	0x38(%rsp), %rdx
    b6bf:      	movq	0x40(%rsp), %r15
    b6c4:      	cmpq	0x18(%rsp), %r12
    b6c9:      	je	0xb725 <generic_rawtp_path+0x625>
    b6cb:      	jmp	0xb730 <generic_rawtp_path+0x630>
    b6cd:      	leaq	0x10(%r15), %rdx
    b6d1:      	movl	$0x4, %eax
    b6d6:      	movq	%rbp, %rdi
    b6d9:      	movl	$0x8, %esi
    b6de:      	callq	*%rax
    b6e0:      	movq	0x40(%rsp), %rax
    b6e5:      	cmpq	(%rsp), %rax
    b6e9:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    b6ef:      	addq	$0x18, %r15
    b6f3:      	movl	$0x4, %eax
    b6f8:      	leaq	0x30(%rsp), %rdi
    b6fd:      	movl	$0x8, %esi
    b702:      	movq	%r15, %rdx
    b705:      	callq	*%rax
    b707:      	movq	(%rsp), %r15
    b70b:      	movq	%r15, 0x40(%rsp)
    b710:      	leaq	0x20(%r15), %rdx
    b714:      	movq	%rdx, 0x38(%rsp)
    b719:      	movq	0x30(%rsp), %r12
    b71e:      	cmpq	0x18(%rsp), %r12
    b723:      	jne	0xb730 <generic_rawtp_path+0x630>
    b725:      	cmpq	0x20(%rsp), %rdx
    b72a:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    b730:      	movl	$0x4, %eax
    b735:      	leaq	0x10(%rsp), %rdi
    b73a:      	movl	$0x8, %esi
    b73f:      	callq	*%rax
    b741:      	cmpq	0x10(%rsp), %r12
    b746:      	je	0xb845 <generic_rawtp_path+0x745>
    b74c:      	leaq	0x18(%r12), %rbx
    b751:      	movl	$0x4, %eax
    b756:      	movq	%rbp, %rdi
    b759:      	movl	$0x8, %esi
    b75e:      	movq	%rbx, %rdx
    b761:      	callq	*%rax
    b763:      	cmpq	%r12, (%rsp)
    b767:      	je	0xb845 <generic_rawtp_path+0x745>
    b76d:      	movl	$0x4, %eax
    b772:      	leaq	0x8(%rsp), %rdi
    b777:      	movl	$0x8, %esi
    b77c:      	movq	%rbx, %rdx
    b77f:      	callq	*%rax
    b781:      	addq	$0x20, %r12
    b785:      	movl	$0x4, %eax
    b78a:      	leaq	0x58(%rsp), %rdi
    b78f:      	movl	$0x10, %ecx
    b794:      	movl	$0x10, %esi
    b799:      	movq	%r12, %rdx
    b79c:      	callq	*%rax
    b79e:      	movq	0x28(%rsp), %rbx
    b7a3:      	movq	0x48(%rsp), %rax
    b7a8:      	movl	0x5c(%rsp), %r15d
    b7ad:      	subq	%rbx, %rax
    b7b0:      	movl	0x50(%rsp), %r12d
    b7b5:      	movl	%r15d, %edx
    b7b8:      	subl	%r12d, %edx
    b7bb:      	movl	$0x0, %ecx
    b7c0:      	cmovbl	%ecx, %edx
    b7c3:      	addq	0x60(%rsp), %rdx
    b7c8:      	xorl	%esi, %esi
    b7ca:      	cmpl	%r15d, %r12d
    b7cd:      	seta	%sil
    b7d1:      	movl	%r15d, %ecx
    b7d4:      	cmovbl	%r12d, %ecx
    b7d8:      	addl	%ecx, %esi
    b7da:      	movl	%r12d, %edi
    b7dd:      	subl	%esi, %edi
    b7df:      	movl	%edi, 0x50(%rsp)
    b7e3:      	subq	%rsi, %rax
    b7e6:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    b7ec:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b7f2:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    b7f8:      	cmpl	%r15d, %r12d
    b7fb:      	jbe	0xb801 <generic_rawtp_path+0x701>
    b7fd:      	movb	$0x2f, (%rbx,%rax)
    b801:      	xorl	%edi, %edi
    b803:      	cmpl	%r15d, %r12d
    b806:      	seta	%dil
    b80a:      	movzbl	%cl, %esi
    b80d:      	addq	%rax, %rbx
    b810:      	addq	%rbx, %rdi
    b813:      	movl	$0x4, %eax
    b818:      	callq	*%rax
    b81a:      	movq	%rbx, 0x48(%rsp)
    b81f:      	cmpl	%r15d, %r12d
    b822:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    b828:      	movq	0x8(%rsp), %r12
    b82d:      	movq	%r12, 0x30(%rsp)
    b832:      	movq	0x38(%rsp), %rdx
    b837:      	movq	0x40(%rsp), %r15
    b83c:      	cmpq	0x18(%rsp), %r12
    b841:      	je	0xb89d <generic_rawtp_path+0x79d>
    b843:      	jmp	0xb8a8 <generic_rawtp_path+0x7a8>
    b845:      	leaq	0x10(%r15), %rdx
    b849:      	movl	$0x4, %eax
    b84e:      	movq	%rbp, %rdi
    b851:      	movl	$0x8, %esi
    b856:      	callq	*%rax
    b858:      	movq	0x40(%rsp), %rax
    b85d:      	cmpq	(%rsp), %rax
    b861:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    b867:      	addq	$0x18, %r15
    b86b:      	movl	$0x4, %eax
    b870:      	leaq	0x30(%rsp), %rdi
    b875:      	movl	$0x8, %esi
    b87a:      	movq	%r15, %rdx
    b87d:      	callq	*%rax
    b87f:      	movq	(%rsp), %r15
    b883:      	movq	%r15, 0x40(%rsp)
    b888:      	leaq	0x20(%r15), %rdx
    b88c:      	movq	%rdx, 0x38(%rsp)
    b891:      	movq	0x30(%rsp), %r12
    b896:      	cmpq	0x18(%rsp), %r12
    b89b:      	jne	0xb8a8 <generic_rawtp_path+0x7a8>
    b89d:      	cmpq	0x20(%rsp), %rdx
    b8a2:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    b8a8:      	movl	$0x4, %eax
    b8ad:      	leaq	0x10(%rsp), %rdi
    b8b2:      	movl	$0x8, %esi
    b8b7:      	callq	*%rax
    b8b9:      	cmpq	0x10(%rsp), %r12
    b8be:      	je	0xb9bd <generic_rawtp_path+0x8bd>
    b8c4:      	leaq	0x18(%r12), %rbx
    b8c9:      	movl	$0x4, %eax
    b8ce:      	movq	%rbp, %rdi
    b8d1:      	movl	$0x8, %esi
    b8d6:      	movq	%rbx, %rdx
    b8d9:      	callq	*%rax
    b8db:      	cmpq	%r12, (%rsp)
    b8df:      	je	0xb9bd <generic_rawtp_path+0x8bd>
    b8e5:      	movl	$0x4, %eax
    b8ea:      	leaq	0x8(%rsp), %rdi
    b8ef:      	movl	$0x8, %esi
    b8f4:      	movq	%rbx, %rdx
    b8f7:      	callq	*%rax
    b8f9:      	addq	$0x20, %r12
    b8fd:      	movl	$0x4, %eax
    b902:      	leaq	0x58(%rsp), %rdi
    b907:      	movl	$0x10, %ecx
    b90c:      	movl	$0x10, %esi
    b911:      	movq	%r12, %rdx
    b914:      	callq	*%rax
    b916:      	movq	0x28(%rsp), %rbx
    b91b:      	movq	0x48(%rsp), %rax
    b920:      	movl	0x5c(%rsp), %r15d
    b925:      	subq	%rbx, %rax
    b928:      	movl	0x50(%rsp), %r12d
    b92d:      	movl	%r15d, %edx
    b930:      	subl	%r12d, %edx
    b933:      	movl	$0x0, %ecx
    b938:      	cmovbl	%ecx, %edx
    b93b:      	addq	0x60(%rsp), %rdx
    b940:      	xorl	%esi, %esi
    b942:      	cmpl	%r15d, %r12d
    b945:      	seta	%sil
    b949:      	movl	%r15d, %ecx
    b94c:      	cmovbl	%r12d, %ecx
    b950:      	addl	%ecx, %esi
    b952:      	movl	%r12d, %edi
    b955:      	subl	%esi, %edi
    b957:      	movl	%edi, 0x50(%rsp)
    b95b:      	subq	%rsi, %rax
    b95e:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    b964:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b96a:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    b970:      	cmpl	%r15d, %r12d
    b973:      	jbe	0xb979 <generic_rawtp_path+0x879>
    b975:      	movb	$0x2f, (%rbx,%rax)
    b979:      	xorl	%edi, %edi
    b97b:      	cmpl	%r15d, %r12d
    b97e:      	seta	%dil
    b982:      	movzbl	%cl, %esi
    b985:      	addq	%rax, %rbx
    b988:      	addq	%rbx, %rdi
    b98b:      	movl	$0x4, %eax
    b990:      	callq	*%rax
    b992:      	movq	%rbx, 0x48(%rsp)
    b997:      	cmpl	%r15d, %r12d
    b99a:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    b9a0:      	movq	0x8(%rsp), %r12
    b9a5:      	movq	%r12, 0x30(%rsp)
    b9aa:      	movq	0x38(%rsp), %rdx
    b9af:      	movq	0x40(%rsp), %r15
    b9b4:      	cmpq	0x18(%rsp), %r12
    b9b9:      	je	0xba15 <generic_rawtp_path+0x915>
    b9bb:      	jmp	0xba20 <generic_rawtp_path+0x920>
    b9bd:      	leaq	0x10(%r15), %rdx
    b9c1:      	movl	$0x4, %eax
    b9c6:      	movq	%rbp, %rdi
    b9c9:      	movl	$0x8, %esi
    b9ce:      	callq	*%rax
    b9d0:      	movq	0x40(%rsp), %rax
    b9d5:      	cmpq	(%rsp), %rax
    b9d9:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    b9df:      	addq	$0x18, %r15
    b9e3:      	movl	$0x4, %eax
    b9e8:      	leaq	0x30(%rsp), %rdi
    b9ed:      	movl	$0x8, %esi
    b9f2:      	movq	%r15, %rdx
    b9f5:      	callq	*%rax
    b9f7:      	movq	(%rsp), %r15
    b9fb:      	movq	%r15, 0x40(%rsp)
    ba00:      	leaq	0x20(%r15), %rdx
    ba04:      	movq	%rdx, 0x38(%rsp)
    ba09:      	movq	0x30(%rsp), %r12
    ba0e:      	cmpq	0x18(%rsp), %r12
    ba13:      	jne	0xba20 <generic_rawtp_path+0x920>
    ba15:      	cmpq	0x20(%rsp), %rdx
    ba1a:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    ba20:      	movl	$0x4, %eax
    ba25:      	leaq	0x10(%rsp), %rdi
    ba2a:      	movl	$0x8, %esi
    ba2f:      	callq	*%rax
    ba31:      	cmpq	0x10(%rsp), %r12
    ba36:      	je	0xbb35 <generic_rawtp_path+0xa35>
    ba3c:      	leaq	0x18(%r12), %rbx
    ba41:      	movl	$0x4, %eax
    ba46:      	movq	%rbp, %rdi
    ba49:      	movl	$0x8, %esi
    ba4e:      	movq	%rbx, %rdx
    ba51:      	callq	*%rax
    ba53:      	cmpq	%r12, (%rsp)
    ba57:      	je	0xbb35 <generic_rawtp_path+0xa35>
    ba5d:      	movl	$0x4, %eax
    ba62:      	leaq	0x8(%rsp), %rdi
    ba67:      	movl	$0x8, %esi
    ba6c:      	movq	%rbx, %rdx
    ba6f:      	callq	*%rax
    ba71:      	addq	$0x20, %r12
    ba75:      	movl	$0x4, %eax
    ba7a:      	leaq	0x58(%rsp), %rdi
    ba7f:      	movl	$0x10, %ecx
    ba84:      	movl	$0x10, %esi
    ba89:      	movq	%r12, %rdx
    ba8c:      	callq	*%rax
    ba8e:      	movq	0x28(%rsp), %rbx
    ba93:      	movq	0x48(%rsp), %rax
    ba98:      	movl	0x5c(%rsp), %r15d
    ba9d:      	subq	%rbx, %rax
    baa0:      	movl	0x50(%rsp), %r12d
    baa5:      	movl	%r15d, %edx
    baa8:      	subl	%r12d, %edx
    baab:      	movl	$0x0, %ecx
    bab0:      	cmovbl	%ecx, %edx
    bab3:      	addq	0x60(%rsp), %rdx
    bab8:      	xorl	%esi, %esi
    baba:      	cmpl	%r15d, %r12d
    babd:      	seta	%sil
    bac1:      	movl	%r15d, %ecx
    bac4:      	cmovbl	%r12d, %ecx
    bac8:      	addl	%ecx, %esi
    baca:      	movl	%r12d, %edi
    bacd:      	subl	%esi, %edi
    bacf:      	movl	%edi, 0x50(%rsp)
    bad3:      	subq	%rsi, %rax
    bad6:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    badc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    bae2:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    bae8:      	cmpl	%r15d, %r12d
    baeb:      	jbe	0xbaf1 <generic_rawtp_path+0x9f1>
    baed:      	movb	$0x2f, (%rbx,%rax)
    baf1:      	xorl	%edi, %edi
    baf3:      	cmpl	%r15d, %r12d
    baf6:      	seta	%dil
    bafa:      	movzbl	%cl, %esi
    bafd:      	addq	%rax, %rbx
    bb00:      	addq	%rbx, %rdi
    bb03:      	movl	$0x4, %eax
    bb08:      	callq	*%rax
    bb0a:      	movq	%rbx, 0x48(%rsp)
    bb0f:      	cmpl	%r15d, %r12d
    bb12:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    bb18:      	movq	0x8(%rsp), %r12
    bb1d:      	movq	%r12, 0x30(%rsp)
    bb22:      	movq	0x38(%rsp), %rdx
    bb27:      	movq	0x40(%rsp), %r15
    bb2c:      	cmpq	0x18(%rsp), %r12
    bb31:      	je	0xbb8d <generic_rawtp_path+0xa8d>
    bb33:      	jmp	0xbb98 <generic_rawtp_path+0xa98>
    bb35:      	leaq	0x10(%r15), %rdx
    bb39:      	movl	$0x4, %eax
    bb3e:      	movq	%rbp, %rdi
    bb41:      	movl	$0x8, %esi
    bb46:      	callq	*%rax
    bb48:      	movq	0x40(%rsp), %rax
    bb4d:      	cmpq	(%rsp), %rax
    bb51:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    bb57:      	addq	$0x18, %r15
    bb5b:      	movl	$0x4, %eax
    bb60:      	leaq	0x30(%rsp), %rdi
    bb65:      	movl	$0x8, %esi
    bb6a:      	movq	%r15, %rdx
    bb6d:      	callq	*%rax
    bb6f:      	movq	(%rsp), %r15
    bb73:      	movq	%r15, 0x40(%rsp)
    bb78:      	leaq	0x20(%r15), %rdx
    bb7c:      	movq	%rdx, 0x38(%rsp)
    bb81:      	movq	0x30(%rsp), %r12
    bb86:      	cmpq	0x18(%rsp), %r12
    bb8b:      	jne	0xbb98 <generic_rawtp_path+0xa98>
    bb8d:      	cmpq	0x20(%rsp), %rdx
    bb92:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    bb98:      	movl	$0x4, %eax
    bb9d:      	leaq	0x10(%rsp), %rdi
    bba2:      	movl	$0x8, %esi
    bba7:      	callq	*%rax
    bba9:      	cmpq	0x10(%rsp), %r12
    bbae:      	je	0xbcad <generic_rawtp_path+0xbad>
    bbb4:      	leaq	0x18(%r12), %rbx
    bbb9:      	movl	$0x4, %eax
    bbbe:      	movq	%rbp, %rdi
    bbc1:      	movl	$0x8, %esi
    bbc6:      	movq	%rbx, %rdx
    bbc9:      	callq	*%rax
    bbcb:      	cmpq	%r12, (%rsp)
    bbcf:      	je	0xbcad <generic_rawtp_path+0xbad>
    bbd5:      	movl	$0x4, %eax
    bbda:      	leaq	0x8(%rsp), %rdi
    bbdf:      	movl	$0x8, %esi
    bbe4:      	movq	%rbx, %rdx
    bbe7:      	callq	*%rax
    bbe9:      	addq	$0x20, %r12
    bbed:      	movl	$0x4, %eax
    bbf2:      	leaq	0x58(%rsp), %rdi
    bbf7:      	movl	$0x10, %ecx
    bbfc:      	movl	$0x10, %esi
    bc01:      	movq	%r12, %rdx
    bc04:      	callq	*%rax
    bc06:      	movq	0x28(%rsp), %rbx
    bc0b:      	movq	0x48(%rsp), %rax
    bc10:      	movl	0x5c(%rsp), %r15d
    bc15:      	subq	%rbx, %rax
    bc18:      	movl	0x50(%rsp), %r12d
    bc1d:      	movl	%r15d, %edx
    bc20:      	subl	%r12d, %edx
    bc23:      	movl	$0x0, %ecx
    bc28:      	cmovbl	%ecx, %edx
    bc2b:      	addq	0x60(%rsp), %rdx
    bc30:      	xorl	%esi, %esi
    bc32:      	cmpl	%r15d, %r12d
    bc35:      	seta	%sil
    bc39:      	movl	%r15d, %ecx
    bc3c:      	cmovbl	%r12d, %ecx
    bc40:      	addl	%ecx, %esi
    bc42:      	movl	%r12d, %edi
    bc45:      	subl	%esi, %edi
    bc47:      	movl	%edi, 0x50(%rsp)
    bc4b:      	subq	%rsi, %rax
    bc4e:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    bc54:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    bc5a:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    bc60:      	cmpl	%r15d, %r12d
    bc63:      	jbe	0xbc69 <generic_rawtp_path+0xb69>
    bc65:      	movb	$0x2f, (%rbx,%rax)
    bc69:      	xorl	%edi, %edi
    bc6b:      	cmpl	%r15d, %r12d
    bc6e:      	seta	%dil
    bc72:      	movzbl	%cl, %esi
    bc75:      	addq	%rax, %rbx
    bc78:      	addq	%rbx, %rdi
    bc7b:      	movl	$0x4, %eax
    bc80:      	callq	*%rax
    bc82:      	movq	%rbx, 0x48(%rsp)
    bc87:      	cmpl	%r15d, %r12d
    bc8a:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    bc90:      	movq	0x8(%rsp), %r12
    bc95:      	movq	%r12, 0x30(%rsp)
    bc9a:      	movq	0x38(%rsp), %rdx
    bc9f:      	movq	0x40(%rsp), %r15
    bca4:      	cmpq	0x18(%rsp), %r12
    bca9:      	je	0xbd05 <generic_rawtp_path+0xc05>
    bcab:      	jmp	0xbd10 <generic_rawtp_path+0xc10>
    bcad:      	leaq	0x10(%r15), %rdx
    bcb1:      	movl	$0x4, %eax
    bcb6:      	movq	%rbp, %rdi
    bcb9:      	movl	$0x8, %esi
    bcbe:      	callq	*%rax
    bcc0:      	movq	0x40(%rsp), %rax
    bcc5:      	cmpq	(%rsp), %rax
    bcc9:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    bccf:      	addq	$0x18, %r15
    bcd3:      	movl	$0x4, %eax
    bcd8:      	leaq	0x30(%rsp), %rdi
    bcdd:      	movl	$0x8, %esi
    bce2:      	movq	%r15, %rdx
    bce5:      	callq	*%rax
    bce7:      	movq	(%rsp), %r15
    bceb:      	movq	%r15, 0x40(%rsp)
    bcf0:      	leaq	0x20(%r15), %rdx
    bcf4:      	movq	%rdx, 0x38(%rsp)
    bcf9:      	movq	0x30(%rsp), %r12
    bcfe:      	cmpq	0x18(%rsp), %r12
    bd03:      	jne	0xbd10 <generic_rawtp_path+0xc10>
    bd05:      	cmpq	0x20(%rsp), %rdx
    bd0a:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    bd10:      	movl	$0x4, %eax
    bd15:      	leaq	0x10(%rsp), %rdi
    bd1a:      	movl	$0x8, %esi
    bd1f:      	callq	*%rax
    bd21:      	cmpq	0x10(%rsp), %r12
    bd26:      	je	0xbe25 <generic_rawtp_path+0xd25>
    bd2c:      	leaq	0x18(%r12), %rbx
    bd31:      	movl	$0x4, %eax
    bd36:      	movq	%rbp, %rdi
    bd39:      	movl	$0x8, %esi
    bd3e:      	movq	%rbx, %rdx
    bd41:      	callq	*%rax
    bd43:      	cmpq	%r12, (%rsp)
    bd47:      	je	0xbe25 <generic_rawtp_path+0xd25>
    bd4d:      	movl	$0x4, %eax
    bd52:      	leaq	0x8(%rsp), %rdi
    bd57:      	movl	$0x8, %esi
    bd5c:      	movq	%rbx, %rdx
    bd5f:      	callq	*%rax
    bd61:      	addq	$0x20, %r12
    bd65:      	movl	$0x4, %eax
    bd6a:      	leaq	0x58(%rsp), %rdi
    bd6f:      	movl	$0x10, %ecx
    bd74:      	movl	$0x10, %esi
    bd79:      	movq	%r12, %rdx
    bd7c:      	callq	*%rax
    bd7e:      	movq	0x28(%rsp), %rbx
    bd83:      	movq	0x48(%rsp), %rax
    bd88:      	movl	0x5c(%rsp), %r15d
    bd8d:      	subq	%rbx, %rax
    bd90:      	movl	0x50(%rsp), %r12d
    bd95:      	movl	%r15d, %edx
    bd98:      	subl	%r12d, %edx
    bd9b:      	movl	$0x0, %ecx
    bda0:      	cmovbl	%ecx, %edx
    bda3:      	addq	0x60(%rsp), %rdx
    bda8:      	xorl	%esi, %esi
    bdaa:      	cmpl	%r15d, %r12d
    bdad:      	seta	%sil
    bdb1:      	movl	%r15d, %ecx
    bdb4:      	cmovbl	%r12d, %ecx
    bdb8:      	addl	%ecx, %esi
    bdba:      	movl	%r12d, %edi
    bdbd:      	subl	%esi, %edi
    bdbf:      	movl	%edi, 0x50(%rsp)
    bdc3:      	subq	%rsi, %rax
    bdc6:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    bdcc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    bdd2:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    bdd8:      	cmpl	%r15d, %r12d
    bddb:      	jbe	0xbde1 <generic_rawtp_path+0xce1>
    bddd:      	movb	$0x2f, (%rbx,%rax)
    bde1:      	xorl	%edi, %edi
    bde3:      	cmpl	%r15d, %r12d
    bde6:      	seta	%dil
    bdea:      	movzbl	%cl, %esi
    bded:      	addq	%rax, %rbx
    bdf0:      	addq	%rbx, %rdi
    bdf3:      	movl	$0x4, %eax
    bdf8:      	callq	*%rax
    bdfa:      	movq	%rbx, 0x48(%rsp)
    bdff:      	cmpl	%r15d, %r12d
    be02:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    be08:      	movq	0x8(%rsp), %r12
    be0d:      	movq	%r12, 0x30(%rsp)
    be12:      	movq	0x38(%rsp), %rdx
    be17:      	movq	0x40(%rsp), %r15
    be1c:      	cmpq	0x18(%rsp), %r12
    be21:      	je	0xbe7d <generic_rawtp_path+0xd7d>
    be23:      	jmp	0xbe88 <generic_rawtp_path+0xd88>
    be25:      	leaq	0x10(%r15), %rdx
    be29:      	movl	$0x4, %eax
    be2e:      	movq	%rbp, %rdi
    be31:      	movl	$0x8, %esi
    be36:      	callq	*%rax
    be38:      	movq	0x40(%rsp), %rax
    be3d:      	cmpq	(%rsp), %rax
    be41:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    be47:      	addq	$0x18, %r15
    be4b:      	movl	$0x4, %eax
    be50:      	leaq	0x30(%rsp), %rdi
    be55:      	movl	$0x8, %esi
    be5a:      	movq	%r15, %rdx
    be5d:      	callq	*%rax
    be5f:      	movq	(%rsp), %r15
    be63:      	movq	%r15, 0x40(%rsp)
    be68:      	leaq	0x20(%r15), %rdx
    be6c:      	movq	%rdx, 0x38(%rsp)
    be71:      	movq	0x30(%rsp), %r12
    be76:      	cmpq	0x18(%rsp), %r12
    be7b:      	jne	0xbe88 <generic_rawtp_path+0xd88>
    be7d:      	cmpq	0x20(%rsp), %rdx
    be82:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    be88:      	movl	$0x4, %eax
    be8d:      	leaq	0x10(%rsp), %rdi
    be92:      	movl	$0x8, %esi
    be97:      	callq	*%rax
    be99:      	cmpq	0x10(%rsp), %r12
    be9e:      	je	0xbf9d <generic_rawtp_path+0xe9d>
    bea4:      	leaq	0x18(%r12), %rbx
    bea9:      	movl	$0x4, %eax
    beae:      	movq	%rbp, %rdi
    beb1:      	movl	$0x8, %esi
    beb6:      	movq	%rbx, %rdx
    beb9:      	callq	*%rax
    bebb:      	cmpq	%r12, (%rsp)
    bebf:      	je	0xbf9d <generic_rawtp_path+0xe9d>
    bec5:      	movl	$0x4, %eax
    beca:      	leaq	0x8(%rsp), %rdi
    becf:      	movl	$0x8, %esi
    bed4:      	movq	%rbx, %rdx
    bed7:      	callq	*%rax
    bed9:      	addq	$0x20, %r12
    bedd:      	movl	$0x4, %eax
    bee2:      	leaq	0x58(%rsp), %rdi
    bee7:      	movl	$0x10, %ecx
    beec:      	movl	$0x10, %esi
    bef1:      	movq	%r12, %rdx
    bef4:      	callq	*%rax
    bef6:      	movq	0x28(%rsp), %rbx
    befb:      	movq	0x48(%rsp), %rax
    bf00:      	movl	0x5c(%rsp), %r15d
    bf05:      	subq	%rbx, %rax
    bf08:      	movl	0x50(%rsp), %r12d
    bf0d:      	movl	%r15d, %edx
    bf10:      	subl	%r12d, %edx
    bf13:      	movl	$0x0, %ecx
    bf18:      	cmovbl	%ecx, %edx
    bf1b:      	addq	0x60(%rsp), %rdx
    bf20:      	xorl	%esi, %esi
    bf22:      	cmpl	%r15d, %r12d
    bf25:      	seta	%sil
    bf29:      	movl	%r15d, %ecx
    bf2c:      	cmovbl	%r12d, %ecx
    bf30:      	addl	%ecx, %esi
    bf32:      	movl	%r12d, %edi
    bf35:      	subl	%esi, %edi
    bf37:      	movl	%edi, 0x50(%rsp)
    bf3b:      	subq	%rsi, %rax
    bf3e:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    bf44:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    bf4a:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    bf50:      	cmpl	%r15d, %r12d
    bf53:      	jbe	0xbf59 <generic_rawtp_path+0xe59>
    bf55:      	movb	$0x2f, (%rbx,%rax)
    bf59:      	xorl	%edi, %edi
    bf5b:      	cmpl	%r15d, %r12d
    bf5e:      	seta	%dil
    bf62:      	movzbl	%cl, %esi
    bf65:      	addq	%rax, %rbx
    bf68:      	addq	%rbx, %rdi
    bf6b:      	movl	$0x4, %eax
    bf70:      	callq	*%rax
    bf72:      	movq	%rbx, 0x48(%rsp)
    bf77:      	cmpl	%r15d, %r12d
    bf7a:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    bf80:      	movq	0x8(%rsp), %r12
    bf85:      	movq	%r12, 0x30(%rsp)
    bf8a:      	movq	0x38(%rsp), %rdx
    bf8f:      	movq	0x40(%rsp), %r15
    bf94:      	cmpq	0x18(%rsp), %r12
    bf99:      	je	0xbff5 <generic_rawtp_path+0xef5>
    bf9b:      	jmp	0xc000 <generic_rawtp_path+0xf00>
    bf9d:      	leaq	0x10(%r15), %rdx
    bfa1:      	movl	$0x4, %eax
    bfa6:      	movq	%rbp, %rdi
    bfa9:      	movl	$0x8, %esi
    bfae:      	callq	*%rax
    bfb0:      	movq	0x40(%rsp), %rax
    bfb5:      	cmpq	(%rsp), %rax
    bfb9:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    bfbf:      	addq	$0x18, %r15
    bfc3:      	movl	$0x4, %eax
    bfc8:      	leaq	0x30(%rsp), %rdi
    bfcd:      	movl	$0x8, %esi
    bfd2:      	movq	%r15, %rdx
    bfd5:      	callq	*%rax
    bfd7:      	movq	(%rsp), %r15
    bfdb:      	movq	%r15, 0x40(%rsp)
    bfe0:      	leaq	0x20(%r15), %rdx
    bfe4:      	movq	%rdx, 0x38(%rsp)
    bfe9:      	movq	0x30(%rsp), %r12
    bfee:      	cmpq	0x18(%rsp), %r12
    bff3:      	jne	0xc000 <generic_rawtp_path+0xf00>
    bff5:      	cmpq	0x20(%rsp), %rdx
    bffa:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    c000:      	movl	$0x4, %eax
    c005:      	leaq	0x10(%rsp), %rdi
    c00a:      	movl	$0x8, %esi
    c00f:      	callq	*%rax
    c011:      	cmpq	0x10(%rsp), %r12
    c016:      	je	0xc10e <generic_rawtp_path+0x100e>
    c01c:      	leaq	0x18(%r12), %rbx
    c021:      	movl	$0x4, %eax
    c026:      	movq	%rbp, %rdi
    c029:      	movl	$0x8, %esi
    c02e:      	movq	%rbx, %rdx
    c031:      	callq	*%rax
    c033:      	cmpq	%r12, (%rsp)
    c037:      	je	0xc10e <generic_rawtp_path+0x100e>
    c03d:      	movl	$0x4, %eax
    c042:      	leaq	0x8(%rsp), %rdi
    c047:      	movl	$0x8, %esi
    c04c:      	movq	%rbx, %rdx
    c04f:      	callq	*%rax
    c051:      	addq	$0x20, %r12
    c055:      	movl	$0x4, %eax
    c05a:      	leaq	0x58(%rsp), %rdi
    c05f:      	movl	$0x10, %ecx
    c064:      	movl	$0x10, %esi
    c069:      	movq	%r12, %rdx
    c06c:      	callq	*%rax
    c06e:      	movq	0x28(%rsp), %rbx
    c073:      	movq	0x48(%rsp), %rax
    c078:      	movl	0x5c(%rsp), %r15d
    c07d:      	subq	%rbx, %rax
    c080:      	movl	0x50(%rsp), %r12d
    c085:      	movl	%r15d, %edx
    c088:      	subl	%r12d, %edx
    c08b:      	movl	$0x0, %ecx
    c090:      	cmovbl	%ecx, %edx
    c093:      	addq	0x60(%rsp), %rdx
    c098:      	xorl	%esi, %esi
    c09a:      	cmpl	%r15d, %r12d
    c09d:      	seta	%sil
    c0a1:      	movl	%r15d, %ecx
    c0a4:      	cmovbl	%r12d, %ecx
    c0a8:      	addl	%ecx, %esi
    c0aa:      	movl	%r12d, %edi
    c0ad:      	subl	%esi, %edi
    c0af:      	movl	%edi, 0x50(%rsp)
    c0b3:      	subq	%rsi, %rax
    c0b6:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    c0bc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c0c2:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    c0c8:      	cmpl	%r15d, %r12d
    c0cb:      	jbe	0xc0d1 <generic_rawtp_path+0xfd1>
    c0cd:      	movb	$0x2f, (%rbx,%rax)
    c0d1:      	xorl	%edi, %edi
    c0d3:      	cmpl	%r15d, %r12d
    c0d6:      	seta	%dil
    c0da:      	movzbl	%cl, %esi
    c0dd:      	addq	%rax, %rbx
    c0e0:      	addq	%rbx, %rdi
    c0e3:      	movl	$0x4, %eax
    c0e8:      	callq	*%rax
    c0ea:      	movq	%rbx, 0x48(%rsp)
    c0ef:      	cmpl	%r15d, %r12d
    c0f2:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    c0f8:      	movq	0x8(%rsp), %r12
    c0fd:      	movq	%r12, 0x30(%rsp)
    c102:      	movq	0x38(%rsp), %rdx
    c107:      	movq	0x40(%rsp), %r15
    c10c:      	jmp	0xc15f <generic_rawtp_path+0x105f>
    c10e:      	leaq	0x10(%r15), %rdx
    c112:      	movl	$0x4, %eax
    c117:      	movq	%rbp, %rdi
    c11a:      	movl	$0x8, %esi
    c11f:      	callq	*%rax
    c121:      	movq	0x40(%rsp), %rax
    c126:      	cmpq	(%rsp), %rax
    c12a:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    c130:      	addq	$0x18, %r15
    c134:      	movl	$0x4, %eax
    c139:      	leaq	0x30(%rsp), %rdi
    c13e:      	movl	$0x8, %esi
    c143:      	movq	%r15, %rdx
    c146:      	callq	*%rax
    c148:      	movq	(%rsp), %r15
    c14c:      	movq	%r15, 0x40(%rsp)
    c151:      	leaq	0x20(%r15), %rdx
    c155:      	movq	%rdx, 0x38(%rsp)
    c15a:      	movq	0x30(%rsp), %r12
    c15f:      	cmpq	0x18(%rsp), %r12
    c164:      	jne	0xc171 <generic_rawtp_path+0x1071>
    c166:      	cmpq	0x20(%rsp), %rdx
    c16b:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    c171:      	movl	$0x4, %eax
    c176:      	leaq	0x10(%rsp), %rdi
    c17b:      	movl	$0x8, %esi
    c180:      	callq	*%rax
    c182:      	cmpq	0x10(%rsp), %r12
    c187:      	je	0xc27f <generic_rawtp_path+0x117f>
    c18d:      	leaq	0x18(%r12), %rbx
    c192:      	movl	$0x4, %eax
    c197:      	movq	%rbp, %rdi
    c19a:      	movl	$0x8, %esi
    c19f:      	movq	%rbx, %rdx
    c1a2:      	callq	*%rax
    c1a4:      	cmpq	%r12, (%rsp)
    c1a8:      	je	0xc27f <generic_rawtp_path+0x117f>
    c1ae:      	movl	$0x4, %eax
    c1b3:      	leaq	0x8(%rsp), %rdi
    c1b8:      	movl	$0x8, %esi
    c1bd:      	movq	%rbx, %rdx
    c1c0:      	callq	*%rax
    c1c2:      	addq	$0x20, %r12
    c1c6:      	movl	$0x4, %eax
    c1cb:      	leaq	0x58(%rsp), %rdi
    c1d0:      	movl	$0x10, %ecx
    c1d5:      	movl	$0x10, %esi
    c1da:      	movq	%r12, %rdx
    c1dd:      	callq	*%rax
    c1df:      	movq	0x28(%rsp), %rbx
    c1e4:      	movq	0x48(%rsp), %rax
    c1e9:      	movl	0x5c(%rsp), %r15d
    c1ee:      	subq	%rbx, %rax
    c1f1:      	movl	0x50(%rsp), %r12d
    c1f6:      	movl	%r15d, %edx
    c1f9:      	subl	%r12d, %edx
    c1fc:      	movl	$0x0, %ecx
    c201:      	cmovbl	%ecx, %edx
    c204:      	addq	0x60(%rsp), %rdx
    c209:      	xorl	%esi, %esi
    c20b:      	cmpl	%r15d, %r12d
    c20e:      	seta	%sil
    c212:      	movl	%r15d, %ecx
    c215:      	cmovbl	%r12d, %ecx
    c219:      	addl	%ecx, %esi
    c21b:      	movl	%r12d, %edi
    c21e:      	subl	%esi, %edi
    c220:      	movl	%edi, 0x50(%rsp)
    c224:      	subq	%rsi, %rax
    c227:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    c22d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c233:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    c239:      	cmpl	%r15d, %r12d
    c23c:      	jbe	0xc242 <generic_rawtp_path+0x1142>
    c23e:      	movb	$0x2f, (%rbx,%rax)
    c242:      	xorl	%edi, %edi
    c244:      	cmpl	%r15d, %r12d
    c247:      	seta	%dil
    c24b:      	movzbl	%cl, %esi
    c24e:      	addq	%rax, %rbx
    c251:      	addq	%rbx, %rdi
    c254:      	movl	$0x4, %eax
    c259:      	callq	*%rax
    c25b:      	movq	%rbx, 0x48(%rsp)
    c260:      	cmpl	%r15d, %r12d
    c263:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    c269:      	movq	0x8(%rsp), %r12
    c26e:      	movq	%r12, 0x30(%rsp)
    c273:      	movq	0x38(%rsp), %rdx
    c278:      	movq	0x40(%rsp), %r15
    c27d:      	jmp	0xc2d0 <generic_rawtp_path+0x11d0>
    c27f:      	leaq	0x10(%r15), %rdx
    c283:      	movl	$0x4, %eax
    c288:      	movq	%rbp, %rdi
    c28b:      	movl	$0x8, %esi
    c290:      	callq	*%rax
    c292:      	movq	0x40(%rsp), %rax
    c297:      	cmpq	(%rsp), %rax
    c29b:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    c2a1:      	addq	$0x18, %r15
    c2a5:      	movl	$0x4, %eax
    c2aa:      	leaq	0x30(%rsp), %rdi
    c2af:      	movl	$0x8, %esi
    c2b4:      	movq	%r15, %rdx
    c2b7:      	callq	*%rax
    c2b9:      	movq	(%rsp), %r15
    c2bd:      	movq	%r15, 0x40(%rsp)
    c2c2:      	leaq	0x20(%r15), %rdx
    c2c6:      	movq	%rdx, 0x38(%rsp)
    c2cb:      	movq	0x30(%rsp), %r12
    c2d0:      	cmpq	0x18(%rsp), %r12
    c2d5:      	jne	0xc2e2 <generic_rawtp_path+0x11e2>
    c2d7:      	cmpq	0x20(%rsp), %rdx
    c2dc:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    c2e2:      	movl	$0x4, %eax
    c2e7:      	leaq	0x10(%rsp), %rdi
    c2ec:      	movl	$0x8, %esi
    c2f1:      	callq	*%rax
    c2f3:      	cmpq	0x10(%rsp), %r12
    c2f8:      	je	0xc3f0 <generic_rawtp_path+0x12f0>
    c2fe:      	leaq	0x18(%r12), %rbx
    c303:      	movl	$0x4, %eax
    c308:      	movq	%rbp, %rdi
    c30b:      	movl	$0x8, %esi
    c310:      	movq	%rbx, %rdx
    c313:      	callq	*%rax
    c315:      	cmpq	%r12, (%rsp)
    c319:      	je	0xc3f0 <generic_rawtp_path+0x12f0>
    c31f:      	movl	$0x4, %eax
    c324:      	leaq	0x8(%rsp), %rdi
    c329:      	movl	$0x8, %esi
    c32e:      	movq	%rbx, %rdx
    c331:      	callq	*%rax
    c333:      	addq	$0x20, %r12
    c337:      	movl	$0x4, %eax
    c33c:      	leaq	0x58(%rsp), %rdi
    c341:      	movl	$0x10, %ecx
    c346:      	movl	$0x10, %esi
    c34b:      	movq	%r12, %rdx
    c34e:      	callq	*%rax
    c350:      	movq	0x28(%rsp), %rbx
    c355:      	movq	0x48(%rsp), %rax
    c35a:      	movl	0x5c(%rsp), %r15d
    c35f:      	subq	%rbx, %rax
    c362:      	movl	0x50(%rsp), %r12d
    c367:      	movl	%r15d, %edx
    c36a:      	subl	%r12d, %edx
    c36d:      	movl	$0x0, %ecx
    c372:      	cmovbl	%ecx, %edx
    c375:      	addq	0x60(%rsp), %rdx
    c37a:      	xorl	%esi, %esi
    c37c:      	cmpl	%r15d, %r12d
    c37f:      	seta	%sil
    c383:      	movl	%r15d, %ecx
    c386:      	cmovbl	%r12d, %ecx
    c38a:      	addl	%ecx, %esi
    c38c:      	movl	%r12d, %edi
    c38f:      	subl	%esi, %edi
    c391:      	movl	%edi, 0x50(%rsp)
    c395:      	subq	%rsi, %rax
    c398:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    c39e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c3a4:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    c3aa:      	cmpl	%r15d, %r12d
    c3ad:      	jbe	0xc3b3 <generic_rawtp_path+0x12b3>
    c3af:      	movb	$0x2f, (%rbx,%rax)
    c3b3:      	xorl	%edi, %edi
    c3b5:      	cmpl	%r15d, %r12d
    c3b8:      	seta	%dil
    c3bc:      	movzbl	%cl, %esi
    c3bf:      	addq	%rax, %rbx
    c3c2:      	addq	%rbx, %rdi
    c3c5:      	movl	$0x4, %eax
    c3ca:      	callq	*%rax
    c3cc:      	movq	%rbx, 0x48(%rsp)
    c3d1:      	cmpl	%r15d, %r12d
    c3d4:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    c3da:      	movq	0x8(%rsp), %r12
    c3df:      	movq	%r12, 0x30(%rsp)
    c3e4:      	movq	0x38(%rsp), %rdx
    c3e9:      	movq	0x40(%rsp), %r15
    c3ee:      	jmp	0xc441 <generic_rawtp_path+0x1341>
    c3f0:      	leaq	0x10(%r15), %rdx
    c3f4:      	movl	$0x4, %eax
    c3f9:      	movq	%rbp, %rdi
    c3fc:      	movl	$0x8, %esi
    c401:      	callq	*%rax
    c403:      	movq	0x40(%rsp), %rax
    c408:      	cmpq	(%rsp), %rax
    c40c:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    c412:      	addq	$0x18, %r15
    c416:      	movl	$0x4, %eax
    c41b:      	leaq	0x30(%rsp), %rdi
    c420:      	movl	$0x8, %esi
    c425:      	movq	%r15, %rdx
    c428:      	callq	*%rax
    c42a:      	movq	(%rsp), %r15
    c42e:      	movq	%r15, 0x40(%rsp)
    c433:      	leaq	0x20(%r15), %rdx
    c437:      	movq	%rdx, 0x38(%rsp)
    c43c:      	movq	0x30(%rsp), %r12
    c441:      	cmpq	0x18(%rsp), %r12
    c446:      	jne	0xc453 <generic_rawtp_path+0x1353>
    c448:      	cmpq	0x20(%rsp), %rdx
    c44d:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    c453:      	movl	$0x4, %eax
    c458:      	leaq	0x10(%rsp), %rdi
    c45d:      	movl	$0x8, %esi
    c462:      	callq	*%rax
    c464:      	cmpq	0x10(%rsp), %r12
    c469:      	je	0xc561 <generic_rawtp_path+0x1461>
    c46f:      	leaq	0x18(%r12), %rbx
    c474:      	movl	$0x4, %eax
    c479:      	movq	%rbp, %rdi
    c47c:      	movl	$0x8, %esi
    c481:      	movq	%rbx, %rdx
    c484:      	callq	*%rax
    c486:      	cmpq	%r12, (%rsp)
    c48a:      	je	0xc561 <generic_rawtp_path+0x1461>
    c490:      	movl	$0x4, %eax
    c495:      	leaq	0x8(%rsp), %rdi
    c49a:      	movl	$0x8, %esi
    c49f:      	movq	%rbx, %rdx
    c4a2:      	callq	*%rax
    c4a4:      	addq	$0x20, %r12
    c4a8:      	movl	$0x4, %eax
    c4ad:      	leaq	0x58(%rsp), %rdi
    c4b2:      	movl	$0x10, %ecx
    c4b7:      	movl	$0x10, %esi
    c4bc:      	movq	%r12, %rdx
    c4bf:      	callq	*%rax
    c4c1:      	movq	0x28(%rsp), %rbx
    c4c6:      	movq	0x48(%rsp), %rax
    c4cb:      	movl	0x5c(%rsp), %r15d
    c4d0:      	subq	%rbx, %rax
    c4d3:      	movl	0x50(%rsp), %r12d
    c4d8:      	movl	%r15d, %edx
    c4db:      	subl	%r12d, %edx
    c4de:      	movl	$0x0, %ecx
    c4e3:      	cmovbl	%ecx, %edx
    c4e6:      	addq	0x60(%rsp), %rdx
    c4eb:      	xorl	%esi, %esi
    c4ed:      	cmpl	%r15d, %r12d
    c4f0:      	seta	%sil
    c4f4:      	movl	%r15d, %ecx
    c4f7:      	cmovbl	%r12d, %ecx
    c4fb:      	addl	%ecx, %esi
    c4fd:      	movl	%r12d, %edi
    c500:      	subl	%esi, %edi
    c502:      	movl	%edi, 0x50(%rsp)
    c506:      	subq	%rsi, %rax
    c509:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    c50f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c515:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    c51b:      	cmpl	%r15d, %r12d
    c51e:      	jbe	0xc524 <generic_rawtp_path+0x1424>
    c520:      	movb	$0x2f, (%rbx,%rax)
    c524:      	xorl	%edi, %edi
    c526:      	cmpl	%r15d, %r12d
    c529:      	seta	%dil
    c52d:      	movzbl	%cl, %esi
    c530:      	addq	%rax, %rbx
    c533:      	addq	%rbx, %rdi
    c536:      	movl	$0x4, %eax
    c53b:      	callq	*%rax
    c53d:      	movq	%rbx, 0x48(%rsp)
    c542:      	cmpl	%r15d, %r12d
    c545:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    c54b:      	movq	0x8(%rsp), %r12
    c550:      	movq	%r12, 0x30(%rsp)
    c555:      	movq	0x38(%rsp), %rdx
    c55a:      	movq	0x40(%rsp), %r15
    c55f:      	jmp	0xc5b2 <generic_rawtp_path+0x14b2>
    c561:      	leaq	0x10(%r15), %rdx
    c565:      	movl	$0x4, %eax
    c56a:      	movq	%rbp, %rdi
    c56d:      	movl	$0x8, %esi
    c572:      	callq	*%rax
    c574:      	movq	0x40(%rsp), %rax
    c579:      	cmpq	(%rsp), %rax
    c57d:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    c583:      	addq	$0x18, %r15
    c587:      	movl	$0x4, %eax
    c58c:      	leaq	0x30(%rsp), %rdi
    c591:      	movl	$0x8, %esi
    c596:      	movq	%r15, %rdx
    c599:      	callq	*%rax
    c59b:      	movq	(%rsp), %r15
    c59f:      	movq	%r15, 0x40(%rsp)
    c5a4:      	leaq	0x20(%r15), %rdx
    c5a8:      	movq	%rdx, 0x38(%rsp)
    c5ad:      	movq	0x30(%rsp), %r12
    c5b2:      	cmpq	0x18(%rsp), %r12
    c5b7:      	jne	0xc5c4 <generic_rawtp_path+0x14c4>
    c5b9:      	cmpq	0x20(%rsp), %rdx
    c5be:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    c5c4:      	movl	$0x4, %eax
    c5c9:      	leaq	0x10(%rsp), %rdi
    c5ce:      	movl	$0x8, %esi
    c5d3:      	callq	*%rax
    c5d5:      	cmpq	0x10(%rsp), %r12
    c5da:      	je	0xc6d2 <generic_rawtp_path+0x15d2>
    c5e0:      	leaq	0x18(%r12), %rbx
    c5e5:      	movl	$0x4, %eax
    c5ea:      	movq	%rbp, %rdi
    c5ed:      	movl	$0x8, %esi
    c5f2:      	movq	%rbx, %rdx
    c5f5:      	callq	*%rax
    c5f7:      	cmpq	%r12, (%rsp)
    c5fb:      	je	0xc6d2 <generic_rawtp_path+0x15d2>
    c601:      	movl	$0x4, %eax
    c606:      	leaq	0x8(%rsp), %rdi
    c60b:      	movl	$0x8, %esi
    c610:      	movq	%rbx, %rdx
    c613:      	callq	*%rax
    c615:      	addq	$0x20, %r12
    c619:      	movl	$0x4, %eax
    c61e:      	leaq	0x58(%rsp), %rdi
    c623:      	movl	$0x10, %ecx
    c628:      	movl	$0x10, %esi
    c62d:      	movq	%r12, %rdx
    c630:      	callq	*%rax
    c632:      	movq	0x28(%rsp), %rbx
    c637:      	movq	0x48(%rsp), %rax
    c63c:      	movl	0x5c(%rsp), %r15d
    c641:      	subq	%rbx, %rax
    c644:      	movl	0x50(%rsp), %r12d
    c649:      	movl	%r15d, %edx
    c64c:      	subl	%r12d, %edx
    c64f:      	movl	$0x0, %ecx
    c654:      	cmovbl	%ecx, %edx
    c657:      	addq	0x60(%rsp), %rdx
    c65c:      	xorl	%esi, %esi
    c65e:      	cmpl	%r15d, %r12d
    c661:      	seta	%sil
    c665:      	movl	%r15d, %ecx
    c668:      	cmovbl	%r12d, %ecx
    c66c:      	addl	%ecx, %esi
    c66e:      	movl	%r12d, %edi
    c671:      	subl	%esi, %edi
    c673:      	movl	%edi, 0x50(%rsp)
    c677:      	subq	%rsi, %rax
    c67a:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    c680:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c686:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    c68c:      	cmpl	%r15d, %r12d
    c68f:      	jbe	0xc695 <generic_rawtp_path+0x1595>
    c691:      	movb	$0x2f, (%rbx,%rax)
    c695:      	xorl	%edi, %edi
    c697:      	cmpl	%r15d, %r12d
    c69a:      	seta	%dil
    c69e:      	movzbl	%cl, %esi
    c6a1:      	addq	%rax, %rbx
    c6a4:      	addq	%rbx, %rdi
    c6a7:      	movl	$0x4, %eax
    c6ac:      	callq	*%rax
    c6ae:      	movq	%rbx, 0x48(%rsp)
    c6b3:      	cmpl	%r15d, %r12d
    c6b6:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    c6bc:      	movq	0x8(%rsp), %r12
    c6c1:      	movq	%r12, 0x30(%rsp)
    c6c6:      	movq	0x38(%rsp), %rdx
    c6cb:      	movq	0x40(%rsp), %r15
    c6d0:      	jmp	0xc723 <generic_rawtp_path+0x1623>
    c6d2:      	leaq	0x10(%r15), %rdx
    c6d6:      	movl	$0x4, %eax
    c6db:      	movq	%rbp, %rdi
    c6de:      	movl	$0x8, %esi
    c6e3:      	callq	*%rax
    c6e5:      	movq	0x40(%rsp), %rax
    c6ea:      	cmpq	(%rsp), %rax
    c6ee:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    c6f4:      	addq	$0x18, %r15
    c6f8:      	movl	$0x4, %eax
    c6fd:      	leaq	0x30(%rsp), %rdi
    c702:      	movl	$0x8, %esi
    c707:      	movq	%r15, %rdx
    c70a:      	callq	*%rax
    c70c:      	movq	(%rsp), %r15
    c710:      	movq	%r15, 0x40(%rsp)
    c715:      	leaq	0x20(%r15), %rdx
    c719:      	movq	%rdx, 0x38(%rsp)
    c71e:      	movq	0x30(%rsp), %r12
    c723:      	cmpq	0x18(%rsp), %r12
    c728:      	jne	0xc735 <generic_rawtp_path+0x1635>
    c72a:      	cmpq	0x20(%rsp), %rdx
    c72f:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    c735:      	movl	$0x4, %eax
    c73a:      	leaq	0x10(%rsp), %rdi
    c73f:      	movl	$0x8, %esi
    c744:      	callq	*%rax
    c746:      	cmpq	0x10(%rsp), %r12
    c74b:      	je	0xc843 <generic_rawtp_path+0x1743>
    c751:      	leaq	0x18(%r12), %rbx
    c756:      	movl	$0x4, %eax
    c75b:      	movq	%rbp, %rdi
    c75e:      	movl	$0x8, %esi
    c763:      	movq	%rbx, %rdx
    c766:      	callq	*%rax
    c768:      	cmpq	%r12, (%rsp)
    c76c:      	je	0xc843 <generic_rawtp_path+0x1743>
    c772:      	movl	$0x4, %eax
    c777:      	leaq	0x8(%rsp), %rdi
    c77c:      	movl	$0x8, %esi
    c781:      	movq	%rbx, %rdx
    c784:      	callq	*%rax
    c786:      	addq	$0x20, %r12
    c78a:      	movl	$0x4, %eax
    c78f:      	leaq	0x58(%rsp), %rdi
    c794:      	movl	$0x10, %ecx
    c799:      	movl	$0x10, %esi
    c79e:      	movq	%r12, %rdx
    c7a1:      	callq	*%rax
    c7a3:      	movq	0x28(%rsp), %rbx
    c7a8:      	movq	0x48(%rsp), %rax
    c7ad:      	movl	0x5c(%rsp), %r15d
    c7b2:      	subq	%rbx, %rax
    c7b5:      	movl	0x50(%rsp), %r12d
    c7ba:      	movl	%r15d, %edx
    c7bd:      	subl	%r12d, %edx
    c7c0:      	movl	$0x0, %ecx
    c7c5:      	cmovbl	%ecx, %edx
    c7c8:      	addq	0x60(%rsp), %rdx
    c7cd:      	xorl	%esi, %esi
    c7cf:      	cmpl	%r15d, %r12d
    c7d2:      	seta	%sil
    c7d6:      	movl	%r15d, %ecx
    c7d9:      	cmovbl	%r12d, %ecx
    c7dd:      	addl	%ecx, %esi
    c7df:      	movl	%r12d, %edi
    c7e2:      	subl	%esi, %edi
    c7e4:      	movl	%edi, 0x50(%rsp)
    c7e8:      	subq	%rsi, %rax
    c7eb:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    c7f1:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c7f7:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    c7fd:      	cmpl	%r15d, %r12d
    c800:      	jbe	0xc806 <generic_rawtp_path+0x1706>
    c802:      	movb	$0x2f, (%rbx,%rax)
    c806:      	xorl	%edi, %edi
    c808:      	cmpl	%r15d, %r12d
    c80b:      	seta	%dil
    c80f:      	movzbl	%cl, %esi
    c812:      	addq	%rax, %rbx
    c815:      	addq	%rbx, %rdi
    c818:      	movl	$0x4, %eax
    c81d:      	callq	*%rax
    c81f:      	movq	%rbx, 0x48(%rsp)
    c824:      	cmpl	%r15d, %r12d
    c827:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    c82d:      	movq	0x8(%rsp), %r12
    c832:      	movq	%r12, 0x30(%rsp)
    c837:      	movq	0x38(%rsp), %rdx
    c83c:      	movq	0x40(%rsp), %r15
    c841:      	jmp	0xc894 <generic_rawtp_path+0x1794>
    c843:      	leaq	0x10(%r15), %rdx
    c847:      	movl	$0x4, %eax
    c84c:      	movq	%rbp, %rdi
    c84f:      	movl	$0x8, %esi
    c854:      	callq	*%rax
    c856:      	movq	0x40(%rsp), %rax
    c85b:      	cmpq	(%rsp), %rax
    c85f:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    c865:      	addq	$0x18, %r15
    c869:      	movl	$0x4, %eax
    c86e:      	leaq	0x30(%rsp), %rdi
    c873:      	movl	$0x8, %esi
    c878:      	movq	%r15, %rdx
    c87b:      	callq	*%rax
    c87d:      	movq	(%rsp), %r15
    c881:      	movq	%r15, 0x40(%rsp)
    c886:      	leaq	0x20(%r15), %rdx
    c88a:      	movq	%rdx, 0x38(%rsp)
    c88f:      	movq	0x30(%rsp), %r12
    c894:      	cmpq	0x18(%rsp), %r12
    c899:      	jne	0xc8a6 <generic_rawtp_path+0x17a6>
    c89b:      	cmpq	0x20(%rsp), %rdx
    c8a0:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    c8a6:      	movl	$0x4, %eax
    c8ab:      	leaq	0x10(%rsp), %rdi
    c8b0:      	movl	$0x8, %esi
    c8b5:      	callq	*%rax
    c8b7:      	cmpq	0x10(%rsp), %r12
    c8bc:      	je	0xc9b4 <generic_rawtp_path+0x18b4>
    c8c2:      	leaq	0x18(%r12), %rbx
    c8c7:      	movl	$0x4, %eax
    c8cc:      	movq	%rbp, %rdi
    c8cf:      	movl	$0x8, %esi
    c8d4:      	movq	%rbx, %rdx
    c8d7:      	callq	*%rax
    c8d9:      	cmpq	%r12, (%rsp)
    c8dd:      	je	0xc9b4 <generic_rawtp_path+0x18b4>
    c8e3:      	movl	$0x4, %eax
    c8e8:      	leaq	0x8(%rsp), %rdi
    c8ed:      	movl	$0x8, %esi
    c8f2:      	movq	%rbx, %rdx
    c8f5:      	callq	*%rax
    c8f7:      	addq	$0x20, %r12
    c8fb:      	movl	$0x4, %eax
    c900:      	leaq	0x58(%rsp), %rdi
    c905:      	movl	$0x10, %ecx
    c90a:      	movl	$0x10, %esi
    c90f:      	movq	%r12, %rdx
    c912:      	callq	*%rax
    c914:      	movq	0x28(%rsp), %rbx
    c919:      	movq	0x48(%rsp), %rax
    c91e:      	movl	0x5c(%rsp), %r15d
    c923:      	subq	%rbx, %rax
    c926:      	movl	0x50(%rsp), %r12d
    c92b:      	movl	%r15d, %edx
    c92e:      	subl	%r12d, %edx
    c931:      	movl	$0x0, %ecx
    c936:      	cmovbl	%ecx, %edx
    c939:      	addq	0x60(%rsp), %rdx
    c93e:      	xorl	%esi, %esi
    c940:      	cmpl	%r15d, %r12d
    c943:      	seta	%sil
    c947:      	movl	%r15d, %ecx
    c94a:      	cmovbl	%r12d, %ecx
    c94e:      	addl	%ecx, %esi
    c950:      	movl	%r12d, %edi
    c953:      	subl	%esi, %edi
    c955:      	movl	%edi, 0x50(%rsp)
    c959:      	subq	%rsi, %rax
    c95c:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    c962:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c968:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    c96e:      	cmpl	%r15d, %r12d
    c971:      	jbe	0xc977 <generic_rawtp_path+0x1877>
    c973:      	movb	$0x2f, (%rbx,%rax)
    c977:      	xorl	%edi, %edi
    c979:      	cmpl	%r15d, %r12d
    c97c:      	seta	%dil
    c980:      	movzbl	%cl, %esi
    c983:      	addq	%rax, %rbx
    c986:      	addq	%rbx, %rdi
    c989:      	movl	$0x4, %eax
    c98e:      	callq	*%rax
    c990:      	movq	%rbx, 0x48(%rsp)
    c995:      	cmpl	%r15d, %r12d
    c998:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    c99e:      	movq	0x8(%rsp), %r12
    c9a3:      	movq	%r12, 0x30(%rsp)
    c9a8:      	movq	0x38(%rsp), %rdx
    c9ad:      	movq	0x40(%rsp), %r15
    c9b2:      	jmp	0xca05 <generic_rawtp_path+0x1905>
    c9b4:      	leaq	0x10(%r15), %rdx
    c9b8:      	movl	$0x4, %eax
    c9bd:      	movq	%rbp, %rdi
    c9c0:      	movl	$0x8, %esi
    c9c5:      	callq	*%rax
    c9c7:      	movq	0x40(%rsp), %rax
    c9cc:      	cmpq	(%rsp), %rax
    c9d0:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    c9d6:      	addq	$0x18, %r15
    c9da:      	movl	$0x4, %eax
    c9df:      	leaq	0x30(%rsp), %rdi
    c9e4:      	movl	$0x8, %esi
    c9e9:      	movq	%r15, %rdx
    c9ec:      	callq	*%rax
    c9ee:      	movq	(%rsp), %r15
    c9f2:      	movq	%r15, 0x40(%rsp)
    c9f7:      	leaq	0x20(%r15), %rdx
    c9fb:      	movq	%rdx, 0x38(%rsp)
    ca00:      	movq	0x30(%rsp), %r12
    ca05:      	cmpq	0x18(%rsp), %r12
    ca0a:      	jne	0xca17 <generic_rawtp_path+0x1917>
    ca0c:      	cmpq	0x20(%rsp), %rdx
    ca11:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    ca17:      	movl	$0x4, %eax
    ca1c:      	leaq	0x10(%rsp), %rdi
    ca21:      	movl	$0x8, %esi
    ca26:      	callq	*%rax
    ca28:      	cmpq	0x10(%rsp), %r12
    ca2d:      	je	0xcb25 <generic_rawtp_path+0x1a25>
    ca33:      	leaq	0x18(%r12), %rbx
    ca38:      	movl	$0x4, %eax
    ca3d:      	movq	%rbp, %rdi
    ca40:      	movl	$0x8, %esi
    ca45:      	movq	%rbx, %rdx
    ca48:      	callq	*%rax
    ca4a:      	cmpq	%r12, (%rsp)
    ca4e:      	je	0xcb25 <generic_rawtp_path+0x1a25>
    ca54:      	movl	$0x4, %eax
    ca59:      	leaq	0x8(%rsp), %rdi
    ca5e:      	movl	$0x8, %esi
    ca63:      	movq	%rbx, %rdx
    ca66:      	callq	*%rax
    ca68:      	addq	$0x20, %r12
    ca6c:      	movl	$0x4, %eax
    ca71:      	leaq	0x58(%rsp), %rdi
    ca76:      	movl	$0x10, %ecx
    ca7b:      	movl	$0x10, %esi
    ca80:      	movq	%r12, %rdx
    ca83:      	callq	*%rax
    ca85:      	movq	0x28(%rsp), %rbx
    ca8a:      	movq	0x48(%rsp), %rax
    ca8f:      	movl	0x5c(%rsp), %r15d
    ca94:      	subq	%rbx, %rax
    ca97:      	movl	0x50(%rsp), %r12d
    ca9c:      	movl	%r15d, %edx
    ca9f:      	subl	%r12d, %edx
    caa2:      	movl	$0x0, %ecx
    caa7:      	cmovbl	%ecx, %edx
    caaa:      	addq	0x60(%rsp), %rdx
    caaf:      	xorl	%esi, %esi
    cab1:      	cmpl	%r15d, %r12d
    cab4:      	seta	%sil
    cab8:      	movl	%r15d, %ecx
    cabb:      	cmovbl	%r12d, %ecx
    cabf:      	addl	%ecx, %esi
    cac1:      	movl	%r12d, %edi
    cac4:      	subl	%esi, %edi
    cac6:      	movl	%edi, 0x50(%rsp)
    caca:      	subq	%rsi, %rax
    cacd:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    cad3:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    cad9:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    cadf:      	cmpl	%r15d, %r12d
    cae2:      	jbe	0xcae8 <generic_rawtp_path+0x19e8>
    cae4:      	movb	$0x2f, (%rbx,%rax)
    cae8:      	xorl	%edi, %edi
    caea:      	cmpl	%r15d, %r12d
    caed:      	seta	%dil
    caf1:      	movzbl	%cl, %esi
    caf4:      	addq	%rax, %rbx
    caf7:      	addq	%rbx, %rdi
    cafa:      	movl	$0x4, %eax
    caff:      	callq	*%rax
    cb01:      	movq	%rbx, 0x48(%rsp)
    cb06:      	cmpl	%r15d, %r12d
    cb09:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    cb0f:      	movq	0x8(%rsp), %r12
    cb14:      	movq	%r12, 0x30(%rsp)
    cb19:      	movq	0x38(%rsp), %rdx
    cb1e:      	movq	0x40(%rsp), %r15
    cb23:      	jmp	0xcb76 <generic_rawtp_path+0x1a76>
    cb25:      	leaq	0x10(%r15), %rdx
    cb29:      	movl	$0x4, %eax
    cb2e:      	movq	%rbp, %rdi
    cb31:      	movl	$0x8, %esi
    cb36:      	callq	*%rax
    cb38:      	movq	0x40(%rsp), %rax
    cb3d:      	cmpq	(%rsp), %rax
    cb41:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    cb47:      	addq	$0x18, %r15
    cb4b:      	movl	$0x4, %eax
    cb50:      	leaq	0x30(%rsp), %rdi
    cb55:      	movl	$0x8, %esi
    cb5a:      	movq	%r15, %rdx
    cb5d:      	callq	*%rax
    cb5f:      	movq	(%rsp), %r15
    cb63:      	movq	%r15, 0x40(%rsp)
    cb68:      	leaq	0x20(%r15), %rdx
    cb6c:      	movq	%rdx, 0x38(%rsp)
    cb71:      	movq	0x30(%rsp), %r12
    cb76:      	cmpq	0x18(%rsp), %r12
    cb7b:      	jne	0xcb88 <generic_rawtp_path+0x1a88>
    cb7d:      	cmpq	0x20(%rsp), %rdx
    cb82:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    cb88:      	movl	$0x4, %eax
    cb8d:      	leaq	0x10(%rsp), %rdi
    cb92:      	movl	$0x8, %esi
    cb97:      	callq	*%rax
    cb99:      	cmpq	0x10(%rsp), %r12
    cb9e:      	je	0xcc96 <generic_rawtp_path+0x1b96>
    cba4:      	leaq	0x18(%r12), %rbx
    cba9:      	movl	$0x4, %eax
    cbae:      	movq	%rbp, %rdi
    cbb1:      	movl	$0x8, %esi
    cbb6:      	movq	%rbx, %rdx
    cbb9:      	callq	*%rax
    cbbb:      	cmpq	%r12, (%rsp)
    cbbf:      	je	0xcc96 <generic_rawtp_path+0x1b96>
    cbc5:      	movl	$0x4, %eax
    cbca:      	leaq	0x8(%rsp), %rdi
    cbcf:      	movl	$0x8, %esi
    cbd4:      	movq	%rbx, %rdx
    cbd7:      	callq	*%rax
    cbd9:      	addq	$0x20, %r12
    cbdd:      	movl	$0x4, %eax
    cbe2:      	leaq	0x58(%rsp), %rdi
    cbe7:      	movl	$0x10, %ecx
    cbec:      	movl	$0x10, %esi
    cbf1:      	movq	%r12, %rdx
    cbf4:      	callq	*%rax
    cbf6:      	movq	0x28(%rsp), %rbx
    cbfb:      	movq	0x48(%rsp), %rax
    cc00:      	movl	0x5c(%rsp), %r15d
    cc05:      	subq	%rbx, %rax
    cc08:      	movl	0x50(%rsp), %r12d
    cc0d:      	movl	%r15d, %edx
    cc10:      	subl	%r12d, %edx
    cc13:      	movl	$0x0, %ecx
    cc18:      	cmovbl	%ecx, %edx
    cc1b:      	addq	0x60(%rsp), %rdx
    cc20:      	xorl	%esi, %esi
    cc22:      	cmpl	%r15d, %r12d
    cc25:      	seta	%sil
    cc29:      	movl	%r15d, %ecx
    cc2c:      	cmovbl	%r12d, %ecx
    cc30:      	addl	%ecx, %esi
    cc32:      	movl	%r12d, %edi
    cc35:      	subl	%esi, %edi
    cc37:      	movl	%edi, 0x50(%rsp)
    cc3b:      	subq	%rsi, %rax
    cc3e:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    cc44:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    cc4a:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    cc50:      	cmpl	%r15d, %r12d
    cc53:      	jbe	0xcc59 <generic_rawtp_path+0x1b59>
    cc55:      	movb	$0x2f, (%rbx,%rax)
    cc59:      	xorl	%edi, %edi
    cc5b:      	cmpl	%r15d, %r12d
    cc5e:      	seta	%dil
    cc62:      	movzbl	%cl, %esi
    cc65:      	addq	%rax, %rbx
    cc68:      	addq	%rbx, %rdi
    cc6b:      	movl	$0x4, %eax
    cc70:      	callq	*%rax
    cc72:      	movq	%rbx, 0x48(%rsp)
    cc77:      	cmpl	%r15d, %r12d
    cc7a:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    cc80:      	movq	0x8(%rsp), %r12
    cc85:      	movq	%r12, 0x30(%rsp)
    cc8a:      	movq	0x38(%rsp), %rdx
    cc8f:      	movq	0x40(%rsp), %r15
    cc94:      	jmp	0xcce7 <generic_rawtp_path+0x1be7>
    cc96:      	leaq	0x10(%r15), %rdx
    cc9a:      	movl	$0x4, %eax
    cc9f:      	movq	%rbp, %rdi
    cca2:      	movl	$0x8, %esi
    cca7:      	callq	*%rax
    cca9:      	movq	0x40(%rsp), %rax
    ccae:      	cmpq	(%rsp), %rax
    ccb2:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    ccb8:      	addq	$0x18, %r15
    ccbc:      	movl	$0x4, %eax
    ccc1:      	leaq	0x30(%rsp), %rdi
    ccc6:      	movl	$0x8, %esi
    cccb:      	movq	%r15, %rdx
    ccce:      	callq	*%rax
    ccd0:      	movq	(%rsp), %r15
    ccd4:      	movq	%r15, 0x40(%rsp)
    ccd9:      	leaq	0x20(%r15), %rdx
    ccdd:      	movq	%rdx, 0x38(%rsp)
    cce2:      	movq	0x30(%rsp), %r12
    cce7:      	cmpq	0x18(%rsp), %r12
    ccec:      	jne	0xccf9 <generic_rawtp_path+0x1bf9>
    ccee:      	cmpq	0x20(%rsp), %rdx
    ccf3:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    ccf9:      	movl	$0x4, %eax
    ccfe:      	leaq	0x10(%rsp), %rdi
    cd03:      	movl	$0x8, %esi
    cd08:      	callq	*%rax
    cd0a:      	cmpq	0x10(%rsp), %r12
    cd0f:      	je	0xce07 <generic_rawtp_path+0x1d07>
    cd15:      	leaq	0x18(%r12), %rbx
    cd1a:      	movl	$0x4, %eax
    cd1f:      	movq	%rbp, %rdi
    cd22:      	movl	$0x8, %esi
    cd27:      	movq	%rbx, %rdx
    cd2a:      	callq	*%rax
    cd2c:      	cmpq	%r12, (%rsp)
    cd30:      	je	0xce07 <generic_rawtp_path+0x1d07>
    cd36:      	movl	$0x4, %eax
    cd3b:      	leaq	0x8(%rsp), %rdi
    cd40:      	movl	$0x8, %esi
    cd45:      	movq	%rbx, %rdx
    cd48:      	callq	*%rax
    cd4a:      	addq	$0x20, %r12
    cd4e:      	movl	$0x4, %eax
    cd53:      	leaq	0x58(%rsp), %rdi
    cd58:      	movl	$0x10, %ecx
    cd5d:      	movl	$0x10, %esi
    cd62:      	movq	%r12, %rdx
    cd65:      	callq	*%rax
    cd67:      	movq	0x28(%rsp), %rbx
    cd6c:      	movq	0x48(%rsp), %rax
    cd71:      	movl	0x5c(%rsp), %r15d
    cd76:      	subq	%rbx, %rax
    cd79:      	movl	0x50(%rsp), %r12d
    cd7e:      	movl	%r15d, %edx
    cd81:      	subl	%r12d, %edx
    cd84:      	movl	$0x0, %ecx
    cd89:      	cmovbl	%ecx, %edx
    cd8c:      	addq	0x60(%rsp), %rdx
    cd91:      	xorl	%esi, %esi
    cd93:      	cmpl	%r15d, %r12d
    cd96:      	seta	%sil
    cd9a:      	movl	%r15d, %ecx
    cd9d:      	cmovbl	%r12d, %ecx
    cda1:      	addl	%ecx, %esi
    cda3:      	movl	%r12d, %edi
    cda6:      	subl	%esi, %edi
    cda8:      	movl	%edi, 0x50(%rsp)
    cdac:      	subq	%rsi, %rax
    cdaf:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    cdb5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    cdbb:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    cdc1:      	cmpl	%r15d, %r12d
    cdc4:      	jbe	0xcdca <generic_rawtp_path+0x1cca>
    cdc6:      	movb	$0x2f, (%rbx,%rax)
    cdca:      	xorl	%edi, %edi
    cdcc:      	cmpl	%r15d, %r12d
    cdcf:      	seta	%dil
    cdd3:      	movzbl	%cl, %esi
    cdd6:      	addq	%rax, %rbx
    cdd9:      	addq	%rbx, %rdi
    cddc:      	movl	$0x4, %eax
    cde1:      	callq	*%rax
    cde3:      	movq	%rbx, 0x48(%rsp)
    cde8:      	cmpl	%r15d, %r12d
    cdeb:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    cdf1:      	movq	0x8(%rsp), %r12
    cdf6:      	movq	%r12, 0x30(%rsp)
    cdfb:      	movq	0x38(%rsp), %rdx
    ce00:      	movq	0x40(%rsp), %r15
    ce05:      	jmp	0xce58 <generic_rawtp_path+0x1d58>
    ce07:      	leaq	0x10(%r15), %rdx
    ce0b:      	movl	$0x4, %eax
    ce10:      	movq	%rbp, %rdi
    ce13:      	movl	$0x8, %esi
    ce18:      	callq	*%rax
    ce1a:      	movq	0x40(%rsp), %rax
    ce1f:      	cmpq	(%rsp), %rax
    ce23:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    ce29:      	addq	$0x18, %r15
    ce2d:      	movl	$0x4, %eax
    ce32:      	leaq	0x30(%rsp), %rdi
    ce37:      	movl	$0x8, %esi
    ce3c:      	movq	%r15, %rdx
    ce3f:      	callq	*%rax
    ce41:      	movq	(%rsp), %r15
    ce45:      	movq	%r15, 0x40(%rsp)
    ce4a:      	leaq	0x20(%r15), %rdx
    ce4e:      	movq	%rdx, 0x38(%rsp)
    ce53:      	movq	0x30(%rsp), %r12
    ce58:      	cmpq	0x18(%rsp), %r12
    ce5d:      	jne	0xce6a <generic_rawtp_path+0x1d6a>
    ce5f:      	cmpq	0x20(%rsp), %rdx
    ce64:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    ce6a:      	movl	$0x4, %eax
    ce6f:      	leaq	0x10(%rsp), %rdi
    ce74:      	movl	$0x8, %esi
    ce79:      	callq	*%rax
    ce7b:      	cmpq	0x10(%rsp), %r12
    ce80:      	je	0xcf78 <generic_rawtp_path+0x1e78>
    ce86:      	leaq	0x18(%r12), %rbx
    ce8b:      	movl	$0x4, %eax
    ce90:      	movq	%rbp, %rdi
    ce93:      	movl	$0x8, %esi
    ce98:      	movq	%rbx, %rdx
    ce9b:      	callq	*%rax
    ce9d:      	cmpq	%r12, (%rsp)
    cea1:      	je	0xcf78 <generic_rawtp_path+0x1e78>
    cea7:      	movl	$0x4, %eax
    ceac:      	leaq	0x8(%rsp), %rdi
    ceb1:      	movl	$0x8, %esi
    ceb6:      	movq	%rbx, %rdx
    ceb9:      	callq	*%rax
    cebb:      	addq	$0x20, %r12
    cebf:      	movl	$0x4, %eax
    cec4:      	leaq	0x58(%rsp), %rdi
    cec9:      	movl	$0x10, %ecx
    cece:      	movl	$0x10, %esi
    ced3:      	movq	%r12, %rdx
    ced6:      	callq	*%rax
    ced8:      	movq	0x28(%rsp), %rbx
    cedd:      	movq	0x48(%rsp), %rax
    cee2:      	movl	0x5c(%rsp), %r15d
    cee7:      	subq	%rbx, %rax
    ceea:      	movl	0x50(%rsp), %r12d
    ceef:      	movl	%r15d, %edx
    cef2:      	subl	%r12d, %edx
    cef5:      	movl	$0x0, %ecx
    cefa:      	cmovbl	%ecx, %edx
    cefd:      	addq	0x60(%rsp), %rdx
    cf02:      	xorl	%esi, %esi
    cf04:      	cmpl	%r15d, %r12d
    cf07:      	seta	%sil
    cf0b:      	movl	%r15d, %ecx
    cf0e:      	cmovbl	%r12d, %ecx
    cf12:      	addl	%ecx, %esi
    cf14:      	movl	%r12d, %edi
    cf17:      	subl	%esi, %edi
    cf19:      	movl	%edi, 0x50(%rsp)
    cf1d:      	subq	%rsi, %rax
    cf20:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    cf26:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    cf2c:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    cf32:      	cmpl	%r15d, %r12d
    cf35:      	jbe	0xcf3b <generic_rawtp_path+0x1e3b>
    cf37:      	movb	$0x2f, (%rbx,%rax)
    cf3b:      	xorl	%edi, %edi
    cf3d:      	cmpl	%r15d, %r12d
    cf40:      	seta	%dil
    cf44:      	movzbl	%cl, %esi
    cf47:      	addq	%rax, %rbx
    cf4a:      	addq	%rbx, %rdi
    cf4d:      	movl	$0x4, %eax
    cf52:      	callq	*%rax
    cf54:      	movq	%rbx, 0x48(%rsp)
    cf59:      	cmpl	%r15d, %r12d
    cf5c:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    cf62:      	movq	0x8(%rsp), %r12
    cf67:      	movq	%r12, 0x30(%rsp)
    cf6c:      	movq	0x38(%rsp), %rdx
    cf71:      	movq	0x40(%rsp), %r15
    cf76:      	jmp	0xcfc9 <generic_rawtp_path+0x1ec9>
    cf78:      	leaq	0x10(%r15), %rdx
    cf7c:      	movl	$0x4, %eax
    cf81:      	movq	%rbp, %rdi
    cf84:      	movl	$0x8, %esi
    cf89:      	callq	*%rax
    cf8b:      	movq	0x40(%rsp), %rax
    cf90:      	cmpq	(%rsp), %rax
    cf94:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    cf9a:      	addq	$0x18, %r15
    cf9e:      	movl	$0x4, %eax
    cfa3:      	leaq	0x30(%rsp), %rdi
    cfa8:      	movl	$0x8, %esi
    cfad:      	movq	%r15, %rdx
    cfb0:      	callq	*%rax
    cfb2:      	movq	(%rsp), %r15
    cfb6:      	movq	%r15, 0x40(%rsp)
    cfbb:      	leaq	0x20(%r15), %rdx
    cfbf:      	movq	%rdx, 0x38(%rsp)
    cfc4:      	movq	0x30(%rsp), %r12
    cfc9:      	cmpq	0x18(%rsp), %r12
    cfce:      	jne	0xcfdb <generic_rawtp_path+0x1edb>
    cfd0:      	cmpq	0x20(%rsp), %rdx
    cfd5:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    cfdb:      	movl	$0x4, %eax
    cfe0:      	leaq	0x10(%rsp), %rdi
    cfe5:      	movl	$0x8, %esi
    cfea:      	callq	*%rax
    cfec:      	cmpq	0x10(%rsp), %r12
    cff1:      	je	0xd0e9 <generic_rawtp_path+0x1fe9>
    cff7:      	leaq	0x18(%r12), %rbx
    cffc:      	movl	$0x4, %eax
    d001:      	movq	%rbp, %rdi
    d004:      	movl	$0x8, %esi
    d009:      	movq	%rbx, %rdx
    d00c:      	callq	*%rax
    d00e:      	cmpq	%r12, (%rsp)
    d012:      	je	0xd0e9 <generic_rawtp_path+0x1fe9>
    d018:      	movl	$0x4, %eax
    d01d:      	leaq	0x8(%rsp), %rdi
    d022:      	movl	$0x8, %esi
    d027:      	movq	%rbx, %rdx
    d02a:      	callq	*%rax
    d02c:      	addq	$0x20, %r12
    d030:      	movl	$0x4, %eax
    d035:      	leaq	0x58(%rsp), %rdi
    d03a:      	movl	$0x10, %ecx
    d03f:      	movl	$0x10, %esi
    d044:      	movq	%r12, %rdx
    d047:      	callq	*%rax
    d049:      	movq	0x28(%rsp), %rbx
    d04e:      	movq	0x48(%rsp), %rax
    d053:      	movl	0x5c(%rsp), %r15d
    d058:      	subq	%rbx, %rax
    d05b:      	movl	0x50(%rsp), %r12d
    d060:      	movl	%r15d, %edx
    d063:      	subl	%r12d, %edx
    d066:      	movl	$0x0, %ecx
    d06b:      	cmovbl	%ecx, %edx
    d06e:      	addq	0x60(%rsp), %rdx
    d073:      	xorl	%esi, %esi
    d075:      	cmpl	%r15d, %r12d
    d078:      	seta	%sil
    d07c:      	movl	%r15d, %ecx
    d07f:      	cmovbl	%r12d, %ecx
    d083:      	addl	%ecx, %esi
    d085:      	movl	%r12d, %edi
    d088:      	subl	%esi, %edi
    d08a:      	movl	%edi, 0x50(%rsp)
    d08e:      	subq	%rsi, %rax
    d091:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    d097:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d09d:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    d0a3:      	cmpl	%r15d, %r12d
    d0a6:      	jbe	0xd0ac <generic_rawtp_path+0x1fac>
    d0a8:      	movb	$0x2f, (%rbx,%rax)
    d0ac:      	xorl	%edi, %edi
    d0ae:      	cmpl	%r15d, %r12d
    d0b1:      	seta	%dil
    d0b5:      	movzbl	%cl, %esi
    d0b8:      	addq	%rax, %rbx
    d0bb:      	addq	%rbx, %rdi
    d0be:      	movl	$0x4, %eax
    d0c3:      	callq	*%rax
    d0c5:      	movq	%rbx, 0x48(%rsp)
    d0ca:      	cmpl	%r15d, %r12d
    d0cd:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    d0d3:      	movq	0x8(%rsp), %r12
    d0d8:      	movq	%r12, 0x30(%rsp)
    d0dd:      	movq	0x38(%rsp), %rdx
    d0e2:      	movq	0x40(%rsp), %r15
    d0e7:      	jmp	0xd13a <generic_rawtp_path+0x203a>
    d0e9:      	leaq	0x10(%r15), %rdx
    d0ed:      	movl	$0x4, %eax
    d0f2:      	movq	%rbp, %rdi
    d0f5:      	movl	$0x8, %esi
    d0fa:      	callq	*%rax
    d0fc:      	movq	0x40(%rsp), %rax
    d101:      	cmpq	(%rsp), %rax
    d105:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    d10b:      	addq	$0x18, %r15
    d10f:      	movl	$0x4, %eax
    d114:      	leaq	0x30(%rsp), %rdi
    d119:      	movl	$0x8, %esi
    d11e:      	movq	%r15, %rdx
    d121:      	callq	*%rax
    d123:      	movq	(%rsp), %r15
    d127:      	movq	%r15, 0x40(%rsp)
    d12c:      	leaq	0x20(%r15), %rdx
    d130:      	movq	%rdx, 0x38(%rsp)
    d135:      	movq	0x30(%rsp), %r12
    d13a:      	cmpq	0x18(%rsp), %r12
    d13f:      	jne	0xd14c <generic_rawtp_path+0x204c>
    d141:      	cmpq	0x20(%rsp), %rdx
    d146:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    d14c:      	movl	$0x4, %eax
    d151:      	leaq	0x10(%rsp), %rdi
    d156:      	movl	$0x8, %esi
    d15b:      	callq	*%rax
    d15d:      	cmpq	0x10(%rsp), %r12
    d162:      	je	0xd25a <generic_rawtp_path+0x215a>
    d168:      	leaq	0x18(%r12), %rbx
    d16d:      	movl	$0x4, %eax
    d172:      	movq	%rbp, %rdi
    d175:      	movl	$0x8, %esi
    d17a:      	movq	%rbx, %rdx
    d17d:      	callq	*%rax
    d17f:      	cmpq	%r12, (%rsp)
    d183:      	je	0xd25a <generic_rawtp_path+0x215a>
    d189:      	movl	$0x4, %eax
    d18e:      	leaq	0x8(%rsp), %rdi
    d193:      	movl	$0x8, %esi
    d198:      	movq	%rbx, %rdx
    d19b:      	callq	*%rax
    d19d:      	addq	$0x20, %r12
    d1a1:      	movl	$0x4, %eax
    d1a6:      	leaq	0x58(%rsp), %rdi
    d1ab:      	movl	$0x10, %ecx
    d1b0:      	movl	$0x10, %esi
    d1b5:      	movq	%r12, %rdx
    d1b8:      	callq	*%rax
    d1ba:      	movq	0x28(%rsp), %rbx
    d1bf:      	movq	0x48(%rsp), %rax
    d1c4:      	movl	0x5c(%rsp), %r15d
    d1c9:      	subq	%rbx, %rax
    d1cc:      	movl	0x50(%rsp), %r12d
    d1d1:      	movl	%r15d, %edx
    d1d4:      	subl	%r12d, %edx
    d1d7:      	movl	$0x0, %ecx
    d1dc:      	cmovbl	%ecx, %edx
    d1df:      	addq	0x60(%rsp), %rdx
    d1e4:      	xorl	%esi, %esi
    d1e6:      	cmpl	%r15d, %r12d
    d1e9:      	seta	%sil
    d1ed:      	movl	%r15d, %ecx
    d1f0:      	cmovbl	%r12d, %ecx
    d1f4:      	addl	%ecx, %esi
    d1f6:      	movl	%r12d, %edi
    d1f9:      	subl	%esi, %edi
    d1fb:      	movl	%edi, 0x50(%rsp)
    d1ff:      	subq	%rsi, %rax
    d202:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    d208:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d20e:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    d214:      	cmpl	%r15d, %r12d
    d217:      	jbe	0xd21d <generic_rawtp_path+0x211d>
    d219:      	movb	$0x2f, (%rbx,%rax)
    d21d:      	xorl	%edi, %edi
    d21f:      	cmpl	%r15d, %r12d
    d222:      	seta	%dil
    d226:      	movzbl	%cl, %esi
    d229:      	addq	%rax, %rbx
    d22c:      	addq	%rbx, %rdi
    d22f:      	movl	$0x4, %eax
    d234:      	callq	*%rax
    d236:      	movq	%rbx, 0x48(%rsp)
    d23b:      	cmpl	%r15d, %r12d
    d23e:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    d244:      	movq	0x8(%rsp), %r12
    d249:      	movq	%r12, 0x30(%rsp)
    d24e:      	movq	0x38(%rsp), %rdx
    d253:      	movq	0x40(%rsp), %r15
    d258:      	jmp	0xd2ab <generic_rawtp_path+0x21ab>
    d25a:      	leaq	0x10(%r15), %rdx
    d25e:      	movl	$0x4, %eax
    d263:      	movq	%rbp, %rdi
    d266:      	movl	$0x8, %esi
    d26b:      	callq	*%rax
    d26d:      	movq	0x40(%rsp), %rax
    d272:      	cmpq	(%rsp), %rax
    d276:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    d27c:      	addq	$0x18, %r15
    d280:      	movl	$0x4, %eax
    d285:      	leaq	0x30(%rsp), %rdi
    d28a:      	movl	$0x8, %esi
    d28f:      	movq	%r15, %rdx
    d292:      	callq	*%rax
    d294:      	movq	(%rsp), %r15
    d298:      	movq	%r15, 0x40(%rsp)
    d29d:      	leaq	0x20(%r15), %rdx
    d2a1:      	movq	%rdx, 0x38(%rsp)
    d2a6:      	movq	0x30(%rsp), %r12
    d2ab:      	cmpq	0x18(%rsp), %r12
    d2b0:      	jne	0xd2bd <generic_rawtp_path+0x21bd>
    d2b2:      	cmpq	0x20(%rsp), %rdx
    d2b7:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    d2bd:      	movl	$0x4, %eax
    d2c2:      	leaq	0x10(%rsp), %rdi
    d2c7:      	movl	$0x8, %esi
    d2cc:      	callq	*%rax
    d2ce:      	cmpq	0x10(%rsp), %r12
    d2d3:      	je	0xd3cb <generic_rawtp_path+0x22cb>
    d2d9:      	leaq	0x18(%r12), %rbx
    d2de:      	movl	$0x4, %eax
    d2e3:      	movq	%rbp, %rdi
    d2e6:      	movl	$0x8, %esi
    d2eb:      	movq	%rbx, %rdx
    d2ee:      	callq	*%rax
    d2f0:      	cmpq	%r12, (%rsp)
    d2f4:      	je	0xd3cb <generic_rawtp_path+0x22cb>
    d2fa:      	movl	$0x4, %eax
    d2ff:      	leaq	0x8(%rsp), %rdi
    d304:      	movl	$0x8, %esi
    d309:      	movq	%rbx, %rdx
    d30c:      	callq	*%rax
    d30e:      	addq	$0x20, %r12
    d312:      	movl	$0x4, %eax
    d317:      	leaq	0x58(%rsp), %rdi
    d31c:      	movl	$0x10, %ecx
    d321:      	movl	$0x10, %esi
    d326:      	movq	%r12, %rdx
    d329:      	callq	*%rax
    d32b:      	movq	0x28(%rsp), %rbx
    d330:      	movq	0x48(%rsp), %rax
    d335:      	movl	0x5c(%rsp), %r15d
    d33a:      	subq	%rbx, %rax
    d33d:      	movl	0x50(%rsp), %r12d
    d342:      	movl	%r15d, %edx
    d345:      	subl	%r12d, %edx
    d348:      	movl	$0x0, %ecx
    d34d:      	cmovbl	%ecx, %edx
    d350:      	addq	0x60(%rsp), %rdx
    d355:      	xorl	%esi, %esi
    d357:      	cmpl	%r15d, %r12d
    d35a:      	seta	%sil
    d35e:      	movl	%r15d, %ecx
    d361:      	cmovbl	%r12d, %ecx
    d365:      	addl	%ecx, %esi
    d367:      	movl	%r12d, %edi
    d36a:      	subl	%esi, %edi
    d36c:      	movl	%edi, 0x50(%rsp)
    d370:      	subq	%rsi, %rax
    d373:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    d379:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d37f:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    d385:      	cmpl	%r15d, %r12d
    d388:      	jbe	0xd38e <generic_rawtp_path+0x228e>
    d38a:      	movb	$0x2f, (%rbx,%rax)
    d38e:      	xorl	%edi, %edi
    d390:      	cmpl	%r15d, %r12d
    d393:      	seta	%dil
    d397:      	movzbl	%cl, %esi
    d39a:      	addq	%rax, %rbx
    d39d:      	addq	%rbx, %rdi
    d3a0:      	movl	$0x4, %eax
    d3a5:      	callq	*%rax
    d3a7:      	movq	%rbx, 0x48(%rsp)
    d3ac:      	cmpl	%r15d, %r12d
    d3af:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    d3b5:      	movq	0x8(%rsp), %r12
    d3ba:      	movq	%r12, 0x30(%rsp)
    d3bf:      	movq	0x38(%rsp), %rdx
    d3c4:      	movq	0x40(%rsp), %r15
    d3c9:      	jmp	0xd41c <generic_rawtp_path+0x231c>
    d3cb:      	leaq	0x10(%r15), %rdx
    d3cf:      	movl	$0x4, %eax
    d3d4:      	movq	%rbp, %rdi
    d3d7:      	movl	$0x8, %esi
    d3dc:      	callq	*%rax
    d3de:      	movq	0x40(%rsp), %rax
    d3e3:      	cmpq	(%rsp), %rax
    d3e7:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    d3ed:      	addq	$0x18, %r15
    d3f1:      	movl	$0x4, %eax
    d3f6:      	leaq	0x30(%rsp), %rdi
    d3fb:      	movl	$0x8, %esi
    d400:      	movq	%r15, %rdx
    d403:      	callq	*%rax
    d405:      	movq	(%rsp), %r15
    d409:      	movq	%r15, 0x40(%rsp)
    d40e:      	leaq	0x20(%r15), %rdx
    d412:      	movq	%rdx, 0x38(%rsp)
    d417:      	movq	0x30(%rsp), %r12
    d41c:      	cmpq	0x18(%rsp), %r12
    d421:      	jne	0xd42e <generic_rawtp_path+0x232e>
    d423:      	cmpq	0x20(%rsp), %rdx
    d428:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    d42e:      	movl	$0x4, %eax
    d433:      	leaq	0x10(%rsp), %rdi
    d438:      	movl	$0x8, %esi
    d43d:      	callq	*%rax
    d43f:      	cmpq	0x10(%rsp), %r12
    d444:      	je	0xd53c <generic_rawtp_path+0x243c>
    d44a:      	leaq	0x18(%r12), %rbx
    d44f:      	movl	$0x4, %eax
    d454:      	movq	%rbp, %rdi
    d457:      	movl	$0x8, %esi
    d45c:      	movq	%rbx, %rdx
    d45f:      	callq	*%rax
    d461:      	cmpq	%r12, (%rsp)
    d465:      	je	0xd53c <generic_rawtp_path+0x243c>
    d46b:      	movl	$0x4, %eax
    d470:      	leaq	0x8(%rsp), %rdi
    d475:      	movl	$0x8, %esi
    d47a:      	movq	%rbx, %rdx
    d47d:      	callq	*%rax
    d47f:      	addq	$0x20, %r12
    d483:      	movl	$0x4, %eax
    d488:      	leaq	0x58(%rsp), %rdi
    d48d:      	movl	$0x10, %ecx
    d492:      	movl	$0x10, %esi
    d497:      	movq	%r12, %rdx
    d49a:      	callq	*%rax
    d49c:      	movq	0x28(%rsp), %rbx
    d4a1:      	movq	0x48(%rsp), %rax
    d4a6:      	movl	0x5c(%rsp), %r15d
    d4ab:      	subq	%rbx, %rax
    d4ae:      	movl	0x50(%rsp), %r12d
    d4b3:      	movl	%r15d, %edx
    d4b6:      	subl	%r12d, %edx
    d4b9:      	movl	$0x0, %ecx
    d4be:      	cmovbl	%ecx, %edx
    d4c1:      	addq	0x60(%rsp), %rdx
    d4c6:      	xorl	%esi, %esi
    d4c8:      	cmpl	%r15d, %r12d
    d4cb:      	seta	%sil
    d4cf:      	movl	%r15d, %ecx
    d4d2:      	cmovbl	%r12d, %ecx
    d4d6:      	addl	%ecx, %esi
    d4d8:      	movl	%r12d, %edi
    d4db:      	subl	%esi, %edi
    d4dd:      	movl	%edi, 0x50(%rsp)
    d4e1:      	subq	%rsi, %rax
    d4e4:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    d4ea:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d4f0:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    d4f6:      	cmpl	%r15d, %r12d
    d4f9:      	jbe	0xd4ff <generic_rawtp_path+0x23ff>
    d4fb:      	movb	$0x2f, (%rbx,%rax)
    d4ff:      	xorl	%edi, %edi
    d501:      	cmpl	%r15d, %r12d
    d504:      	seta	%dil
    d508:      	movzbl	%cl, %esi
    d50b:      	addq	%rax, %rbx
    d50e:      	addq	%rbx, %rdi
    d511:      	movl	$0x4, %eax
    d516:      	callq	*%rax
    d518:      	movq	%rbx, 0x48(%rsp)
    d51d:      	cmpl	%r15d, %r12d
    d520:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    d526:      	movq	0x8(%rsp), %r12
    d52b:      	movq	%r12, 0x30(%rsp)
    d530:      	movq	0x38(%rsp), %rdx
    d535:      	movq	0x40(%rsp), %r15
    d53a:      	jmp	0xd58d <generic_rawtp_path+0x248d>
    d53c:      	leaq	0x10(%r15), %rdx
    d540:      	movl	$0x4, %eax
    d545:      	movq	%rbp, %rdi
    d548:      	movl	$0x8, %esi
    d54d:      	callq	*%rax
    d54f:      	movq	0x40(%rsp), %rax
    d554:      	cmpq	(%rsp), %rax
    d558:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    d55e:      	addq	$0x18, %r15
    d562:      	movl	$0x4, %eax
    d567:      	leaq	0x30(%rsp), %rdi
    d56c:      	movl	$0x8, %esi
    d571:      	movq	%r15, %rdx
    d574:      	callq	*%rax
    d576:      	movq	(%rsp), %r15
    d57a:      	movq	%r15, 0x40(%rsp)
    d57f:      	leaq	0x20(%r15), %rdx
    d583:      	movq	%rdx, 0x38(%rsp)
    d588:      	movq	0x30(%rsp), %r12
    d58d:      	cmpq	0x18(%rsp), %r12
    d592:      	jne	0xd59f <generic_rawtp_path+0x249f>
    d594:      	cmpq	0x20(%rsp), %rdx
    d599:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    d59f:      	movl	$0x4, %eax
    d5a4:      	leaq	0x10(%rsp), %rdi
    d5a9:      	movl	$0x8, %esi
    d5ae:      	callq	*%rax
    d5b0:      	cmpq	0x10(%rsp), %r12
    d5b5:      	je	0xd6ad <generic_rawtp_path+0x25ad>
    d5bb:      	leaq	0x18(%r12), %rbx
    d5c0:      	movl	$0x4, %eax
    d5c5:      	movq	%rbp, %rdi
    d5c8:      	movl	$0x8, %esi
    d5cd:      	movq	%rbx, %rdx
    d5d0:      	callq	*%rax
    d5d2:      	cmpq	%r12, (%rsp)
    d5d6:      	je	0xd6ad <generic_rawtp_path+0x25ad>
    d5dc:      	movl	$0x4, %eax
    d5e1:      	leaq	0x8(%rsp), %rdi
    d5e6:      	movl	$0x8, %esi
    d5eb:      	movq	%rbx, %rdx
    d5ee:      	callq	*%rax
    d5f0:      	addq	$0x20, %r12
    d5f4:      	movl	$0x4, %eax
    d5f9:      	leaq	0x58(%rsp), %rdi
    d5fe:      	movl	$0x10, %ecx
    d603:      	movl	$0x10, %esi
    d608:      	movq	%r12, %rdx
    d60b:      	callq	*%rax
    d60d:      	movq	0x28(%rsp), %rbx
    d612:      	movq	0x48(%rsp), %rax
    d617:      	movl	0x5c(%rsp), %r15d
    d61c:      	subq	%rbx, %rax
    d61f:      	movl	0x50(%rsp), %r12d
    d624:      	movl	%r15d, %edx
    d627:      	subl	%r12d, %edx
    d62a:      	movl	$0x0, %ecx
    d62f:      	cmovbl	%ecx, %edx
    d632:      	addq	0x60(%rsp), %rdx
    d637:      	xorl	%esi, %esi
    d639:      	cmpl	%r15d, %r12d
    d63c:      	seta	%sil
    d640:      	movl	%r15d, %ecx
    d643:      	cmovbl	%r12d, %ecx
    d647:      	addl	%ecx, %esi
    d649:      	movl	%r12d, %edi
    d64c:      	subl	%esi, %edi
    d64e:      	movl	%edi, 0x50(%rsp)
    d652:      	subq	%rsi, %rax
    d655:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    d65b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d661:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    d667:      	cmpl	%r15d, %r12d
    d66a:      	jbe	0xd670 <generic_rawtp_path+0x2570>
    d66c:      	movb	$0x2f, (%rbx,%rax)
    d670:      	xorl	%edi, %edi
    d672:      	cmpl	%r15d, %r12d
    d675:      	seta	%dil
    d679:      	movzbl	%cl, %esi
    d67c:      	addq	%rax, %rbx
    d67f:      	addq	%rbx, %rdi
    d682:      	movl	$0x4, %eax
    d687:      	callq	*%rax
    d689:      	movq	%rbx, 0x48(%rsp)
    d68e:      	cmpl	%r15d, %r12d
    d691:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    d697:      	movq	0x8(%rsp), %r12
    d69c:      	movq	%r12, 0x30(%rsp)
    d6a1:      	movq	0x38(%rsp), %rdx
    d6a6:      	movq	0x40(%rsp), %r15
    d6ab:      	jmp	0xd6fe <generic_rawtp_path+0x25fe>
    d6ad:      	leaq	0x10(%r15), %rdx
    d6b1:      	movl	$0x4, %eax
    d6b6:      	movq	%rbp, %rdi
    d6b9:      	movl	$0x8, %esi
    d6be:      	callq	*%rax
    d6c0:      	movq	0x40(%rsp), %rax
    d6c5:      	cmpq	(%rsp), %rax
    d6c9:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    d6cf:      	addq	$0x18, %r15
    d6d3:      	movl	$0x4, %eax
    d6d8:      	leaq	0x30(%rsp), %rdi
    d6dd:      	movl	$0x8, %esi
    d6e2:      	movq	%r15, %rdx
    d6e5:      	callq	*%rax
    d6e7:      	movq	(%rsp), %r15
    d6eb:      	movq	%r15, 0x40(%rsp)
    d6f0:      	leaq	0x20(%r15), %rdx
    d6f4:      	movq	%rdx, 0x38(%rsp)
    d6f9:      	movq	0x30(%rsp), %r12
    d6fe:      	cmpq	0x18(%rsp), %r12
    d703:      	jne	0xd710 <generic_rawtp_path+0x2610>
    d705:      	cmpq	0x20(%rsp), %rdx
    d70a:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    d710:      	movl	$0x4, %eax
    d715:      	leaq	0x10(%rsp), %rdi
    d71a:      	movl	$0x8, %esi
    d71f:      	callq	*%rax
    d721:      	cmpq	0x10(%rsp), %r12
    d726:      	je	0xd81e <generic_rawtp_path+0x271e>
    d72c:      	leaq	0x18(%r12), %rbx
    d731:      	movl	$0x4, %eax
    d736:      	movq	%rbp, %rdi
    d739:      	movl	$0x8, %esi
    d73e:      	movq	%rbx, %rdx
    d741:      	callq	*%rax
    d743:      	cmpq	%r12, (%rsp)
    d747:      	je	0xd81e <generic_rawtp_path+0x271e>
    d74d:      	movl	$0x4, %eax
    d752:      	leaq	0x8(%rsp), %rdi
    d757:      	movl	$0x8, %esi
    d75c:      	movq	%rbx, %rdx
    d75f:      	callq	*%rax
    d761:      	addq	$0x20, %r12
    d765:      	movl	$0x4, %eax
    d76a:      	leaq	0x58(%rsp), %rdi
    d76f:      	movl	$0x10, %ecx
    d774:      	movl	$0x10, %esi
    d779:      	movq	%r12, %rdx
    d77c:      	callq	*%rax
    d77e:      	movq	0x28(%rsp), %rbx
    d783:      	movq	0x48(%rsp), %rax
    d788:      	movl	0x5c(%rsp), %r15d
    d78d:      	subq	%rbx, %rax
    d790:      	movl	0x50(%rsp), %r12d
    d795:      	movl	%r15d, %edx
    d798:      	subl	%r12d, %edx
    d79b:      	movl	$0x0, %ecx
    d7a0:      	cmovbl	%ecx, %edx
    d7a3:      	addq	0x60(%rsp), %rdx
    d7a8:      	xorl	%esi, %esi
    d7aa:      	cmpl	%r15d, %r12d
    d7ad:      	seta	%sil
    d7b1:      	movl	%r15d, %ecx
    d7b4:      	cmovbl	%r12d, %ecx
    d7b8:      	addl	%ecx, %esi
    d7ba:      	movl	%r12d, %edi
    d7bd:      	subl	%esi, %edi
    d7bf:      	movl	%edi, 0x50(%rsp)
    d7c3:      	subq	%rsi, %rax
    d7c6:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    d7cc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d7d2:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    d7d8:      	cmpl	%r15d, %r12d
    d7db:      	jbe	0xd7e1 <generic_rawtp_path+0x26e1>
    d7dd:      	movb	$0x2f, (%rbx,%rax)
    d7e1:      	xorl	%edi, %edi
    d7e3:      	cmpl	%r15d, %r12d
    d7e6:      	seta	%dil
    d7ea:      	movzbl	%cl, %esi
    d7ed:      	addq	%rax, %rbx
    d7f0:      	addq	%rbx, %rdi
    d7f3:      	movl	$0x4, %eax
    d7f8:      	callq	*%rax
    d7fa:      	movq	%rbx, 0x48(%rsp)
    d7ff:      	cmpl	%r15d, %r12d
    d802:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    d808:      	movq	0x8(%rsp), %r12
    d80d:      	movq	%r12, 0x30(%rsp)
    d812:      	movq	0x38(%rsp), %rdx
    d817:      	movq	0x40(%rsp), %r15
    d81c:      	jmp	0xd86f <generic_rawtp_path+0x276f>
    d81e:      	leaq	0x10(%r15), %rdx
    d822:      	movl	$0x4, %eax
    d827:      	movq	%rbp, %rdi
    d82a:      	movl	$0x8, %esi
    d82f:      	callq	*%rax
    d831:      	movq	0x40(%rsp), %rax
    d836:      	cmpq	(%rsp), %rax
    d83a:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    d840:      	addq	$0x18, %r15
    d844:      	movl	$0x4, %eax
    d849:      	leaq	0x30(%rsp), %rdi
    d84e:      	movl	$0x8, %esi
    d853:      	movq	%r15, %rdx
    d856:      	callq	*%rax
    d858:      	movq	(%rsp), %r15
    d85c:      	movq	%r15, 0x40(%rsp)
    d861:      	leaq	0x20(%r15), %rdx
    d865:      	movq	%rdx, 0x38(%rsp)
    d86a:      	movq	0x30(%rsp), %r12
    d86f:      	cmpq	0x18(%rsp), %r12
    d874:      	jne	0xd881 <generic_rawtp_path+0x2781>
    d876:      	cmpq	0x20(%rsp), %rdx
    d87b:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    d881:      	movl	$0x4, %eax
    d886:      	leaq	0x10(%rsp), %rdi
    d88b:      	movl	$0x8, %esi
    d890:      	callq	*%rax
    d892:      	cmpq	0x10(%rsp), %r12
    d897:      	je	0xd98f <generic_rawtp_path+0x288f>
    d89d:      	leaq	0x18(%r12), %rbx
    d8a2:      	movl	$0x4, %eax
    d8a7:      	movq	%rbp, %rdi
    d8aa:      	movl	$0x8, %esi
    d8af:      	movq	%rbx, %rdx
    d8b2:      	callq	*%rax
    d8b4:      	cmpq	%r12, (%rsp)
    d8b8:      	je	0xd98f <generic_rawtp_path+0x288f>
    d8be:      	movl	$0x4, %eax
    d8c3:      	leaq	0x8(%rsp), %rdi
    d8c8:      	movl	$0x8, %esi
    d8cd:      	movq	%rbx, %rdx
    d8d0:      	callq	*%rax
    d8d2:      	addq	$0x20, %r12
    d8d6:      	movl	$0x4, %eax
    d8db:      	leaq	0x58(%rsp), %rdi
    d8e0:      	movl	$0x10, %ecx
    d8e5:      	movl	$0x10, %esi
    d8ea:      	movq	%r12, %rdx
    d8ed:      	callq	*%rax
    d8ef:      	movq	0x28(%rsp), %rbx
    d8f4:      	movq	0x48(%rsp), %rax
    d8f9:      	movl	0x5c(%rsp), %r15d
    d8fe:      	subq	%rbx, %rax
    d901:      	movl	0x50(%rsp), %r12d
    d906:      	movl	%r15d, %edx
    d909:      	subl	%r12d, %edx
    d90c:      	movl	$0x0, %ecx
    d911:      	cmovbl	%ecx, %edx
    d914:      	addq	0x60(%rsp), %rdx
    d919:      	xorl	%esi, %esi
    d91b:      	cmpl	%r15d, %r12d
    d91e:      	seta	%sil
    d922:      	movl	%r15d, %ecx
    d925:      	cmovbl	%r12d, %ecx
    d929:      	addl	%ecx, %esi
    d92b:      	movl	%r12d, %edi
    d92e:      	subl	%esi, %edi
    d930:      	movl	%edi, 0x50(%rsp)
    d934:      	subq	%rsi, %rax
    d937:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    d93d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d943:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    d949:      	cmpl	%r15d, %r12d
    d94c:      	jbe	0xd952 <generic_rawtp_path+0x2852>
    d94e:      	movb	$0x2f, (%rbx,%rax)
    d952:      	xorl	%edi, %edi
    d954:      	cmpl	%r15d, %r12d
    d957:      	seta	%dil
    d95b:      	movzbl	%cl, %esi
    d95e:      	addq	%rax, %rbx
    d961:      	addq	%rbx, %rdi
    d964:      	movl	$0x4, %eax
    d969:      	callq	*%rax
    d96b:      	movq	%rbx, 0x48(%rsp)
    d970:      	cmpl	%r15d, %r12d
    d973:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    d979:      	movq	0x8(%rsp), %r12
    d97e:      	movq	%r12, 0x30(%rsp)
    d983:      	movq	0x38(%rsp), %rdx
    d988:      	movq	0x40(%rsp), %r15
    d98d:      	jmp	0xd9e0 <generic_rawtp_path+0x28e0>
    d98f:      	leaq	0x10(%r15), %rdx
    d993:      	movl	$0x4, %eax
    d998:      	movq	%rbp, %rdi
    d99b:      	movl	$0x8, %esi
    d9a0:      	callq	*%rax
    d9a2:      	movq	0x40(%rsp), %rax
    d9a7:      	cmpq	(%rsp), %rax
    d9ab:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    d9b1:      	addq	$0x18, %r15
    d9b5:      	movl	$0x4, %eax
    d9ba:      	leaq	0x30(%rsp), %rdi
    d9bf:      	movl	$0x8, %esi
    d9c4:      	movq	%r15, %rdx
    d9c7:      	callq	*%rax
    d9c9:      	movq	(%rsp), %r15
    d9cd:      	movq	%r15, 0x40(%rsp)
    d9d2:      	leaq	0x20(%r15), %rdx
    d9d6:      	movq	%rdx, 0x38(%rsp)
    d9db:      	movq	0x30(%rsp), %r12
    d9e0:      	cmpq	0x18(%rsp), %r12
    d9e5:      	jne	0xd9f2 <generic_rawtp_path+0x28f2>
    d9e7:      	cmpq	0x20(%rsp), %rdx
    d9ec:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    d9f2:      	movl	$0x4, %eax
    d9f7:      	leaq	0x10(%rsp), %rdi
    d9fc:      	movl	$0x8, %esi
    da01:      	callq	*%rax
    da03:      	cmpq	0x10(%rsp), %r12
    da08:      	je	0xdb00 <generic_rawtp_path+0x2a00>
    da0e:      	leaq	0x18(%r12), %rbx
    da13:      	movl	$0x4, %eax
    da18:      	movq	%rbp, %rdi
    da1b:      	movl	$0x8, %esi
    da20:      	movq	%rbx, %rdx
    da23:      	callq	*%rax
    da25:      	cmpq	%r12, (%rsp)
    da29:      	je	0xdb00 <generic_rawtp_path+0x2a00>
    da2f:      	movl	$0x4, %eax
    da34:      	leaq	0x8(%rsp), %rdi
    da39:      	movl	$0x8, %esi
    da3e:      	movq	%rbx, %rdx
    da41:      	callq	*%rax
    da43:      	addq	$0x20, %r12
    da47:      	movl	$0x4, %eax
    da4c:      	leaq	0x58(%rsp), %rdi
    da51:      	movl	$0x10, %ecx
    da56:      	movl	$0x10, %esi
    da5b:      	movq	%r12, %rdx
    da5e:      	callq	*%rax
    da60:      	movq	0x28(%rsp), %rbx
    da65:      	movq	0x48(%rsp), %rax
    da6a:      	movl	0x5c(%rsp), %r15d
    da6f:      	subq	%rbx, %rax
    da72:      	movl	0x50(%rsp), %r12d
    da77:      	movl	%r15d, %edx
    da7a:      	subl	%r12d, %edx
    da7d:      	movl	$0x0, %ecx
    da82:      	cmovbl	%ecx, %edx
    da85:      	addq	0x60(%rsp), %rdx
    da8a:      	xorl	%esi, %esi
    da8c:      	cmpl	%r15d, %r12d
    da8f:      	seta	%sil
    da93:      	movl	%r15d, %ecx
    da96:      	cmovbl	%r12d, %ecx
    da9a:      	addl	%ecx, %esi
    da9c:      	movl	%r12d, %edi
    da9f:      	subl	%esi, %edi
    daa1:      	movl	%edi, 0x50(%rsp)
    daa5:      	subq	%rsi, %rax
    daa8:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    daae:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    dab4:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    daba:      	cmpl	%r15d, %r12d
    dabd:      	jbe	0xdac3 <generic_rawtp_path+0x29c3>
    dabf:      	movb	$0x2f, (%rbx,%rax)
    dac3:      	xorl	%edi, %edi
    dac5:      	cmpl	%r15d, %r12d
    dac8:      	seta	%dil
    dacc:      	movzbl	%cl, %esi
    dacf:      	addq	%rax, %rbx
    dad2:      	addq	%rbx, %rdi
    dad5:      	movl	$0x4, %eax
    dada:      	callq	*%rax
    dadc:      	movq	%rbx, 0x48(%rsp)
    dae1:      	cmpl	%r15d, %r12d
    dae4:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    daea:      	movq	0x8(%rsp), %r12
    daef:      	movq	%r12, 0x30(%rsp)
    daf4:      	movq	0x38(%rsp), %rdx
    daf9:      	movq	0x40(%rsp), %r15
    dafe:      	jmp	0xdb51 <generic_rawtp_path+0x2a51>
    db00:      	leaq	0x10(%r15), %rdx
    db04:      	movl	$0x4, %eax
    db09:      	movq	%rbp, %rdi
    db0c:      	movl	$0x8, %esi
    db11:      	callq	*%rax
    db13:      	movq	0x40(%rsp), %rax
    db18:      	cmpq	(%rsp), %rax
    db1c:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    db22:      	addq	$0x18, %r15
    db26:      	movl	$0x4, %eax
    db2b:      	leaq	0x30(%rsp), %rdi
    db30:      	movl	$0x8, %esi
    db35:      	movq	%r15, %rdx
    db38:      	callq	*%rax
    db3a:      	movq	(%rsp), %r15
    db3e:      	movq	%r15, 0x40(%rsp)
    db43:      	leaq	0x20(%r15), %rdx
    db47:      	movq	%rdx, 0x38(%rsp)
    db4c:      	movq	0x30(%rsp), %r12
    db51:      	cmpq	0x18(%rsp), %r12
    db56:      	jne	0xdb63 <generic_rawtp_path+0x2a63>
    db58:      	cmpq	0x20(%rsp), %rdx
    db5d:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    db63:      	movl	$0x4, %eax
    db68:      	leaq	0x10(%rsp), %rdi
    db6d:      	movl	$0x8, %esi
    db72:      	callq	*%rax
    db74:      	cmpq	0x10(%rsp), %r12
    db79:      	je	0xdc71 <generic_rawtp_path+0x2b71>
    db7f:      	leaq	0x18(%r12), %rbx
    db84:      	movl	$0x4, %eax
    db89:      	movq	%rbp, %rdi
    db8c:      	movl	$0x8, %esi
    db91:      	movq	%rbx, %rdx
    db94:      	callq	*%rax
    db96:      	cmpq	%r12, (%rsp)
    db9a:      	je	0xdc71 <generic_rawtp_path+0x2b71>
    dba0:      	movl	$0x4, %eax
    dba5:      	leaq	0x8(%rsp), %rdi
    dbaa:      	movl	$0x8, %esi
    dbaf:      	movq	%rbx, %rdx
    dbb2:      	callq	*%rax
    dbb4:      	addq	$0x20, %r12
    dbb8:      	movl	$0x4, %eax
    dbbd:      	leaq	0x58(%rsp), %rdi
    dbc2:      	movl	$0x10, %ecx
    dbc7:      	movl	$0x10, %esi
    dbcc:      	movq	%r12, %rdx
    dbcf:      	callq	*%rax
    dbd1:      	movq	0x28(%rsp), %rbx
    dbd6:      	movq	0x48(%rsp), %rax
    dbdb:      	movl	0x5c(%rsp), %r15d
    dbe0:      	subq	%rbx, %rax
    dbe3:      	movl	0x50(%rsp), %r12d
    dbe8:      	movl	%r15d, %edx
    dbeb:      	subl	%r12d, %edx
    dbee:      	movl	$0x0, %ecx
    dbf3:      	cmovbl	%ecx, %edx
    dbf6:      	addq	0x60(%rsp), %rdx
    dbfb:      	xorl	%esi, %esi
    dbfd:      	cmpl	%r15d, %r12d
    dc00:      	seta	%sil
    dc04:      	movl	%r15d, %ecx
    dc07:      	cmovbl	%r12d, %ecx
    dc0b:      	addl	%ecx, %esi
    dc0d:      	movl	%r12d, %edi
    dc10:      	subl	%esi, %edi
    dc12:      	movl	%edi, 0x50(%rsp)
    dc16:      	subq	%rsi, %rax
    dc19:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    dc1f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    dc25:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    dc2b:      	cmpl	%r15d, %r12d
    dc2e:      	jbe	0xdc34 <generic_rawtp_path+0x2b34>
    dc30:      	movb	$0x2f, (%rbx,%rax)
    dc34:      	xorl	%edi, %edi
    dc36:      	cmpl	%r15d, %r12d
    dc39:      	seta	%dil
    dc3d:      	movzbl	%cl, %esi
    dc40:      	addq	%rax, %rbx
    dc43:      	addq	%rbx, %rdi
    dc46:      	movl	$0x4, %eax
    dc4b:      	callq	*%rax
    dc4d:      	movq	%rbx, 0x48(%rsp)
    dc52:      	cmpl	%r15d, %r12d
    dc55:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    dc5b:      	movq	0x8(%rsp), %r12
    dc60:      	movq	%r12, 0x30(%rsp)
    dc65:      	movq	0x38(%rsp), %rdx
    dc6a:      	movq	0x40(%rsp), %r15
    dc6f:      	jmp	0xdcc2 <generic_rawtp_path+0x2bc2>
    dc71:      	leaq	0x10(%r15), %rdx
    dc75:      	movl	$0x4, %eax
    dc7a:      	movq	%rbp, %rdi
    dc7d:      	movl	$0x8, %esi
    dc82:      	callq	*%rax
    dc84:      	movq	0x40(%rsp), %rax
    dc89:      	cmpq	(%rsp), %rax
    dc8d:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    dc93:      	addq	$0x18, %r15
    dc97:      	movl	$0x4, %eax
    dc9c:      	leaq	0x30(%rsp), %rdi
    dca1:      	movl	$0x8, %esi
    dca6:      	movq	%r15, %rdx
    dca9:      	callq	*%rax
    dcab:      	movq	(%rsp), %r15
    dcaf:      	movq	%r15, 0x40(%rsp)
    dcb4:      	leaq	0x20(%r15), %rdx
    dcb8:      	movq	%rdx, 0x38(%rsp)
    dcbd:      	movq	0x30(%rsp), %r12
    dcc2:      	cmpq	0x18(%rsp), %r12
    dcc7:      	jne	0xdcd4 <generic_rawtp_path+0x2bd4>
    dcc9:      	cmpq	0x20(%rsp), %rdx
    dcce:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    dcd4:      	movl	$0x4, %eax
    dcd9:      	leaq	0x10(%rsp), %rdi
    dcde:      	movl	$0x8, %esi
    dce3:      	callq	*%rax
    dce5:      	cmpq	0x10(%rsp), %r12
    dcea:      	je	0xdde2 <generic_rawtp_path+0x2ce2>
    dcf0:      	leaq	0x18(%r12), %rbx
    dcf5:      	movl	$0x4, %eax
    dcfa:      	movq	%rbp, %rdi
    dcfd:      	movl	$0x8, %esi
    dd02:      	movq	%rbx, %rdx
    dd05:      	callq	*%rax
    dd07:      	cmpq	%r12, (%rsp)
    dd0b:      	je	0xdde2 <generic_rawtp_path+0x2ce2>
    dd11:      	movl	$0x4, %eax
    dd16:      	leaq	0x8(%rsp), %rdi
    dd1b:      	movl	$0x8, %esi
    dd20:      	movq	%rbx, %rdx
    dd23:      	callq	*%rax
    dd25:      	addq	$0x20, %r12
    dd29:      	movl	$0x4, %eax
    dd2e:      	leaq	0x58(%rsp), %rdi
    dd33:      	movl	$0x10, %ecx
    dd38:      	movl	$0x10, %esi
    dd3d:      	movq	%r12, %rdx
    dd40:      	callq	*%rax
    dd42:      	movq	0x28(%rsp), %rbx
    dd47:      	movq	0x48(%rsp), %rax
    dd4c:      	movl	0x5c(%rsp), %r15d
    dd51:      	subq	%rbx, %rax
    dd54:      	movl	0x50(%rsp), %r12d
    dd59:      	movl	%r15d, %edx
    dd5c:      	subl	%r12d, %edx
    dd5f:      	movl	$0x0, %ecx
    dd64:      	cmovbl	%ecx, %edx
    dd67:      	addq	0x60(%rsp), %rdx
    dd6c:      	xorl	%esi, %esi
    dd6e:      	cmpl	%r15d, %r12d
    dd71:      	seta	%sil
    dd75:      	movl	%r15d, %ecx
    dd78:      	cmovbl	%r12d, %ecx
    dd7c:      	addl	%ecx, %esi
    dd7e:      	movl	%r12d, %edi
    dd81:      	subl	%esi, %edi
    dd83:      	movl	%edi, 0x50(%rsp)
    dd87:      	subq	%rsi, %rax
    dd8a:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    dd90:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    dd96:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    dd9c:      	cmpl	%r15d, %r12d
    dd9f:      	jbe	0xdda5 <generic_rawtp_path+0x2ca5>
    dda1:      	movb	$0x2f, (%rbx,%rax)
    dda5:      	xorl	%edi, %edi
    dda7:      	cmpl	%r15d, %r12d
    ddaa:      	seta	%dil
    ddae:      	movzbl	%cl, %esi
    ddb1:      	addq	%rax, %rbx
    ddb4:      	addq	%rbx, %rdi
    ddb7:      	movl	$0x4, %eax
    ddbc:      	callq	*%rax
    ddbe:      	movq	%rbx, 0x48(%rsp)
    ddc3:      	cmpl	%r15d, %r12d
    ddc6:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    ddcc:      	movq	0x8(%rsp), %r12
    ddd1:      	movq	%r12, 0x30(%rsp)
    ddd6:      	movq	0x38(%rsp), %rdx
    dddb:      	movq	0x40(%rsp), %r15
    dde0:      	jmp	0xde33 <generic_rawtp_path+0x2d33>
    dde2:      	leaq	0x10(%r15), %rdx
    dde6:      	movl	$0x4, %eax
    ddeb:      	movq	%rbp, %rdi
    ddee:      	movl	$0x8, %esi
    ddf3:      	callq	*%rax
    ddf5:      	movq	0x40(%rsp), %rax
    ddfa:      	cmpq	(%rsp), %rax
    ddfe:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    de04:      	addq	$0x18, %r15
    de08:      	movl	$0x4, %eax
    de0d:      	leaq	0x30(%rsp), %rdi
    de12:      	movl	$0x8, %esi
    de17:      	movq	%r15, %rdx
    de1a:      	callq	*%rax
    de1c:      	movq	(%rsp), %r15
    de20:      	movq	%r15, 0x40(%rsp)
    de25:      	leaq	0x20(%r15), %rdx
    de29:      	movq	%rdx, 0x38(%rsp)
    de2e:      	movq	0x30(%rsp), %r12
    de33:      	cmpq	0x18(%rsp), %r12
    de38:      	jne	0xde45 <generic_rawtp_path+0x2d45>
    de3a:      	cmpq	0x20(%rsp), %rdx
    de3f:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    de45:      	movl	$0x4, %eax
    de4a:      	leaq	0x10(%rsp), %rdi
    de4f:      	movl	$0x8, %esi
    de54:      	callq	*%rax
    de56:      	cmpq	0x10(%rsp), %r12
    de5b:      	je	0xdf53 <generic_rawtp_path+0x2e53>
    de61:      	leaq	0x18(%r12), %rbx
    de66:      	movl	$0x4, %eax
    de6b:      	movq	%rbp, %rdi
    de6e:      	movl	$0x8, %esi
    de73:      	movq	%rbx, %rdx
    de76:      	callq	*%rax
    de78:      	cmpq	%r12, (%rsp)
    de7c:      	je	0xdf53 <generic_rawtp_path+0x2e53>
    de82:      	movl	$0x4, %eax
    de87:      	leaq	0x8(%rsp), %rdi
    de8c:      	movl	$0x8, %esi
    de91:      	movq	%rbx, %rdx
    de94:      	callq	*%rax
    de96:      	addq	$0x20, %r12
    de9a:      	movl	$0x4, %eax
    de9f:      	leaq	0x58(%rsp), %rdi
    dea4:      	movl	$0x10, %ecx
    dea9:      	movl	$0x10, %esi
    deae:      	movq	%r12, %rdx
    deb1:      	callq	*%rax
    deb3:      	movq	0x28(%rsp), %rbx
    deb8:      	movq	0x48(%rsp), %rax
    debd:      	movl	0x5c(%rsp), %r15d
    dec2:      	subq	%rbx, %rax
    dec5:      	movl	0x50(%rsp), %r12d
    deca:      	movl	%r15d, %edx
    decd:      	subl	%r12d, %edx
    ded0:      	movl	$0x0, %ecx
    ded5:      	cmovbl	%ecx, %edx
    ded8:      	addq	0x60(%rsp), %rdx
    dedd:      	xorl	%esi, %esi
    dedf:      	cmpl	%r15d, %r12d
    dee2:      	seta	%sil
    dee6:      	movl	%r15d, %ecx
    dee9:      	cmovbl	%r12d, %ecx
    deed:      	addl	%ecx, %esi
    deef:      	movl	%r12d, %edi
    def2:      	subl	%esi, %edi
    def4:      	movl	%edi, 0x50(%rsp)
    def8:      	subq	%rsi, %rax
    defb:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    df01:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    df07:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    df0d:      	cmpl	%r15d, %r12d
    df10:      	jbe	0xdf16 <generic_rawtp_path+0x2e16>
    df12:      	movb	$0x2f, (%rbx,%rax)
    df16:      	xorl	%edi, %edi
    df18:      	cmpl	%r15d, %r12d
    df1b:      	seta	%dil
    df1f:      	movzbl	%cl, %esi
    df22:      	addq	%rax, %rbx
    df25:      	addq	%rbx, %rdi
    df28:      	movl	$0x4, %eax
    df2d:      	callq	*%rax
    df2f:      	movq	%rbx, 0x48(%rsp)
    df34:      	cmpl	%r15d, %r12d
    df37:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    df3d:      	movq	0x8(%rsp), %r12
    df42:      	movq	%r12, 0x30(%rsp)
    df47:      	movq	0x38(%rsp), %rdx
    df4c:      	movq	0x40(%rsp), %r15
    df51:      	jmp	0xdfa4 <generic_rawtp_path+0x2ea4>
    df53:      	leaq	0x10(%r15), %rdx
    df57:      	movl	$0x4, %eax
    df5c:      	movq	%rbp, %rdi
    df5f:      	movl	$0x8, %esi
    df64:      	callq	*%rax
    df66:      	movq	0x40(%rsp), %rax
    df6b:      	cmpq	(%rsp), %rax
    df6f:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    df75:      	addq	$0x18, %r15
    df79:      	movl	$0x4, %eax
    df7e:      	leaq	0x30(%rsp), %rdi
    df83:      	movl	$0x8, %esi
    df88:      	movq	%r15, %rdx
    df8b:      	callq	*%rax
    df8d:      	movq	(%rsp), %r15
    df91:      	movq	%r15, 0x40(%rsp)
    df96:      	leaq	0x20(%r15), %rdx
    df9a:      	movq	%rdx, 0x38(%rsp)
    df9f:      	movq	0x30(%rsp), %r12
    dfa4:      	cmpq	0x18(%rsp), %r12
    dfa9:      	jne	0xdfb6 <generic_rawtp_path+0x2eb6>
    dfab:      	cmpq	0x20(%rsp), %rdx
    dfb0:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    dfb6:      	movl	$0x4, %eax
    dfbb:      	leaq	0x10(%rsp), %rdi
    dfc0:      	movl	$0x8, %esi
    dfc5:      	callq	*%rax
    dfc7:      	cmpq	0x10(%rsp), %r12
    dfcc:      	je	0xe0c4 <generic_rawtp_path+0x2fc4>
    dfd2:      	leaq	0x18(%r12), %rbx
    dfd7:      	movl	$0x4, %eax
    dfdc:      	movq	%rbp, %rdi
    dfdf:      	movl	$0x8, %esi
    dfe4:      	movq	%rbx, %rdx
    dfe7:      	callq	*%rax
    dfe9:      	cmpq	%r12, (%rsp)
    dfed:      	je	0xe0c4 <generic_rawtp_path+0x2fc4>
    dff3:      	movl	$0x4, %eax
    dff8:      	leaq	0x8(%rsp), %rdi
    dffd:      	movl	$0x8, %esi
    e002:      	movq	%rbx, %rdx
    e005:      	callq	*%rax
    e007:      	addq	$0x20, %r12
    e00b:      	movl	$0x4, %eax
    e010:      	leaq	0x58(%rsp), %rdi
    e015:      	movl	$0x10, %ecx
    e01a:      	movl	$0x10, %esi
    e01f:      	movq	%r12, %rdx
    e022:      	callq	*%rax
    e024:      	movq	0x28(%rsp), %rbx
    e029:      	movq	0x48(%rsp), %rax
    e02e:      	movl	0x5c(%rsp), %r15d
    e033:      	subq	%rbx, %rax
    e036:      	movl	0x50(%rsp), %r12d
    e03b:      	movl	%r15d, %edx
    e03e:      	subl	%r12d, %edx
    e041:      	movl	$0x0, %ecx
    e046:      	cmovbl	%ecx, %edx
    e049:      	addq	0x60(%rsp), %rdx
    e04e:      	xorl	%esi, %esi
    e050:      	cmpl	%r15d, %r12d
    e053:      	seta	%sil
    e057:      	movl	%r15d, %ecx
    e05a:      	cmovbl	%r12d, %ecx
    e05e:      	addl	%ecx, %esi
    e060:      	movl	%r12d, %edi
    e063:      	subl	%esi, %edi
    e065:      	movl	%edi, 0x50(%rsp)
    e069:      	subq	%rsi, %rax
    e06c:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    e072:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e078:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    e07e:      	cmpl	%r15d, %r12d
    e081:      	jbe	0xe087 <generic_rawtp_path+0x2f87>
    e083:      	movb	$0x2f, (%rbx,%rax)
    e087:      	xorl	%edi, %edi
    e089:      	cmpl	%r15d, %r12d
    e08c:      	seta	%dil
    e090:      	movzbl	%cl, %esi
    e093:      	addq	%rax, %rbx
    e096:      	addq	%rbx, %rdi
    e099:      	movl	$0x4, %eax
    e09e:      	callq	*%rax
    e0a0:      	movq	%rbx, 0x48(%rsp)
    e0a5:      	cmpl	%r15d, %r12d
    e0a8:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    e0ae:      	movq	0x8(%rsp), %r12
    e0b3:      	movq	%r12, 0x30(%rsp)
    e0b8:      	movq	0x38(%rsp), %rdx
    e0bd:      	movq	0x40(%rsp), %r15
    e0c2:      	jmp	0xe115 <generic_rawtp_path+0x3015>
    e0c4:      	leaq	0x10(%r15), %rdx
    e0c8:      	movl	$0x4, %eax
    e0cd:      	movq	%rbp, %rdi
    e0d0:      	movl	$0x8, %esi
    e0d5:      	callq	*%rax
    e0d7:      	movq	0x40(%rsp), %rax
    e0dc:      	cmpq	(%rsp), %rax
    e0e0:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    e0e6:      	addq	$0x18, %r15
    e0ea:      	movl	$0x4, %eax
    e0ef:      	leaq	0x30(%rsp), %rdi
    e0f4:      	movl	$0x8, %esi
    e0f9:      	movq	%r15, %rdx
    e0fc:      	callq	*%rax
    e0fe:      	movq	(%rsp), %r15
    e102:      	movq	%r15, 0x40(%rsp)
    e107:      	leaq	0x20(%r15), %rdx
    e10b:      	movq	%rdx, 0x38(%rsp)
    e110:      	movq	0x30(%rsp), %r12
    e115:      	cmpq	0x18(%rsp), %r12
    e11a:      	jne	0xe127 <generic_rawtp_path+0x3027>
    e11c:      	cmpq	0x20(%rsp), %rdx
    e121:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    e127:      	movl	$0x4, %eax
    e12c:      	leaq	0x10(%rsp), %rdi
    e131:      	movl	$0x8, %esi
    e136:      	callq	*%rax
    e138:      	cmpq	0x10(%rsp), %r12
    e13d:      	je	0xe235 <generic_rawtp_path+0x3135>
    e143:      	leaq	0x18(%r12), %rbx
    e148:      	movl	$0x4, %eax
    e14d:      	movq	%rbp, %rdi
    e150:      	movl	$0x8, %esi
    e155:      	movq	%rbx, %rdx
    e158:      	callq	*%rax
    e15a:      	cmpq	%r12, (%rsp)
    e15e:      	je	0xe235 <generic_rawtp_path+0x3135>
    e164:      	movl	$0x4, %eax
    e169:      	leaq	0x8(%rsp), %rdi
    e16e:      	movl	$0x8, %esi
    e173:      	movq	%rbx, %rdx
    e176:      	callq	*%rax
    e178:      	addq	$0x20, %r12
    e17c:      	movl	$0x4, %eax
    e181:      	leaq	0x58(%rsp), %rdi
    e186:      	movl	$0x10, %ecx
    e18b:      	movl	$0x10, %esi
    e190:      	movq	%r12, %rdx
    e193:      	callq	*%rax
    e195:      	movq	0x28(%rsp), %rbx
    e19a:      	movq	0x48(%rsp), %rax
    e19f:      	movl	0x5c(%rsp), %r15d
    e1a4:      	subq	%rbx, %rax
    e1a7:      	movl	0x50(%rsp), %r12d
    e1ac:      	movl	%r15d, %edx
    e1af:      	subl	%r12d, %edx
    e1b2:      	movl	$0x0, %ecx
    e1b7:      	cmovbl	%ecx, %edx
    e1ba:      	addq	0x60(%rsp), %rdx
    e1bf:      	xorl	%esi, %esi
    e1c1:      	cmpl	%r15d, %r12d
    e1c4:      	seta	%sil
    e1c8:      	movl	%r15d, %ecx
    e1cb:      	cmovbl	%r12d, %ecx
    e1cf:      	addl	%ecx, %esi
    e1d1:      	movl	%r12d, %edi
    e1d4:      	subl	%esi, %edi
    e1d6:      	movl	%edi, 0x50(%rsp)
    e1da:      	subq	%rsi, %rax
    e1dd:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    e1e3:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e1e9:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    e1ef:      	cmpl	%r15d, %r12d
    e1f2:      	jbe	0xe1f8 <generic_rawtp_path+0x30f8>
    e1f4:      	movb	$0x2f, (%rbx,%rax)
    e1f8:      	xorl	%edi, %edi
    e1fa:      	cmpl	%r15d, %r12d
    e1fd:      	seta	%dil
    e201:      	movzbl	%cl, %esi
    e204:      	addq	%rax, %rbx
    e207:      	addq	%rbx, %rdi
    e20a:      	movl	$0x4, %eax
    e20f:      	callq	*%rax
    e211:      	movq	%rbx, 0x48(%rsp)
    e216:      	cmpl	%r15d, %r12d
    e219:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    e21f:      	movq	0x8(%rsp), %r12
    e224:      	movq	%r12, 0x30(%rsp)
    e229:      	movq	0x38(%rsp), %rdx
    e22e:      	movq	0x40(%rsp), %r15
    e233:      	jmp	0xe286 <generic_rawtp_path+0x3186>
    e235:      	leaq	0x10(%r15), %rdx
    e239:      	movl	$0x4, %eax
    e23e:      	movq	%rbp, %rdi
    e241:      	movl	$0x8, %esi
    e246:      	callq	*%rax
    e248:      	movq	0x40(%rsp), %rax
    e24d:      	cmpq	(%rsp), %rax
    e251:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    e257:      	addq	$0x18, %r15
    e25b:      	movl	$0x4, %eax
    e260:      	leaq	0x30(%rsp), %rdi
    e265:      	movl	$0x8, %esi
    e26a:      	movq	%r15, %rdx
    e26d:      	callq	*%rax
    e26f:      	movq	(%rsp), %r15
    e273:      	movq	%r15, 0x40(%rsp)
    e278:      	leaq	0x20(%r15), %rdx
    e27c:      	movq	%rdx, 0x38(%rsp)
    e281:      	movq	0x30(%rsp), %r12
    e286:      	cmpq	0x18(%rsp), %r12
    e28b:      	jne	0xe298 <generic_rawtp_path+0x3198>
    e28d:      	cmpq	0x20(%rsp), %rdx
    e292:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    e298:      	movl	$0x4, %eax
    e29d:      	leaq	0x10(%rsp), %rdi
    e2a2:      	movl	$0x8, %esi
    e2a7:      	callq	*%rax
    e2a9:      	cmpq	0x10(%rsp), %r12
    e2ae:      	je	0xe3a6 <generic_rawtp_path+0x32a6>
    e2b4:      	leaq	0x18(%r12), %rbx
    e2b9:      	movl	$0x4, %eax
    e2be:      	movq	%rbp, %rdi
    e2c1:      	movl	$0x8, %esi
    e2c6:      	movq	%rbx, %rdx
    e2c9:      	callq	*%rax
    e2cb:      	cmpq	%r12, (%rsp)
    e2cf:      	je	0xe3a6 <generic_rawtp_path+0x32a6>
    e2d5:      	movl	$0x4, %eax
    e2da:      	leaq	0x8(%rsp), %rdi
    e2df:      	movl	$0x8, %esi
    e2e4:      	movq	%rbx, %rdx
    e2e7:      	callq	*%rax
    e2e9:      	addq	$0x20, %r12
    e2ed:      	movl	$0x4, %eax
    e2f2:      	leaq	0x58(%rsp), %rdi
    e2f7:      	movl	$0x10, %ecx
    e2fc:      	movl	$0x10, %esi
    e301:      	movq	%r12, %rdx
    e304:      	callq	*%rax
    e306:      	movq	0x28(%rsp), %rbx
    e30b:      	movq	0x48(%rsp), %rax
    e310:      	movl	0x5c(%rsp), %r15d
    e315:      	subq	%rbx, %rax
    e318:      	movl	0x50(%rsp), %r12d
    e31d:      	movl	%r15d, %edx
    e320:      	subl	%r12d, %edx
    e323:      	movl	$0x0, %ecx
    e328:      	cmovbl	%ecx, %edx
    e32b:      	addq	0x60(%rsp), %rdx
    e330:      	xorl	%esi, %esi
    e332:      	cmpl	%r15d, %r12d
    e335:      	seta	%sil
    e339:      	movl	%r15d, %ecx
    e33c:      	cmovbl	%r12d, %ecx
    e340:      	addl	%ecx, %esi
    e342:      	movl	%r12d, %edi
    e345:      	subl	%esi, %edi
    e347:      	movl	%edi, 0x50(%rsp)
    e34b:      	subq	%rsi, %rax
    e34e:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    e354:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e35a:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    e360:      	cmpl	%r15d, %r12d
    e363:      	jbe	0xe369 <generic_rawtp_path+0x3269>
    e365:      	movb	$0x2f, (%rbx,%rax)
    e369:      	xorl	%edi, %edi
    e36b:      	cmpl	%r15d, %r12d
    e36e:      	seta	%dil
    e372:      	movzbl	%cl, %esi
    e375:      	addq	%rax, %rbx
    e378:      	addq	%rbx, %rdi
    e37b:      	movl	$0x4, %eax
    e380:      	callq	*%rax
    e382:      	movq	%rbx, 0x48(%rsp)
    e387:      	cmpl	%r15d, %r12d
    e38a:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    e390:      	movq	0x8(%rsp), %r12
    e395:      	movq	%r12, 0x30(%rsp)
    e39a:      	movq	0x38(%rsp), %rdx
    e39f:      	movq	0x40(%rsp), %r15
    e3a4:      	jmp	0xe3f7 <generic_rawtp_path+0x32f7>
    e3a6:      	leaq	0x10(%r15), %rdx
    e3aa:      	movl	$0x4, %eax
    e3af:      	movq	%rbp, %rdi
    e3b2:      	movl	$0x8, %esi
    e3b7:      	callq	*%rax
    e3b9:      	movq	0x40(%rsp), %rax
    e3be:      	cmpq	(%rsp), %rax
    e3c2:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    e3c8:      	addq	$0x18, %r15
    e3cc:      	movl	$0x4, %eax
    e3d1:      	leaq	0x30(%rsp), %rdi
    e3d6:      	movl	$0x8, %esi
    e3db:      	movq	%r15, %rdx
    e3de:      	callq	*%rax
    e3e0:      	movq	(%rsp), %r15
    e3e4:      	movq	%r15, 0x40(%rsp)
    e3e9:      	leaq	0x20(%r15), %rdx
    e3ed:      	movq	%rdx, 0x38(%rsp)
    e3f2:      	movq	0x30(%rsp), %r12
    e3f7:      	cmpq	0x18(%rsp), %r12
    e3fc:      	jne	0xe409 <generic_rawtp_path+0x3309>
    e3fe:      	cmpq	0x20(%rsp), %rdx
    e403:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    e409:      	movl	$0x4, %eax
    e40e:      	leaq	0x10(%rsp), %rdi
    e413:      	movl	$0x8, %esi
    e418:      	callq	*%rax
    e41a:      	cmpq	0x10(%rsp), %r12
    e41f:      	je	0xe517 <generic_rawtp_path+0x3417>
    e425:      	leaq	0x18(%r12), %rbx
    e42a:      	movl	$0x4, %eax
    e42f:      	movq	%rbp, %rdi
    e432:      	movl	$0x8, %esi
    e437:      	movq	%rbx, %rdx
    e43a:      	callq	*%rax
    e43c:      	cmpq	%r12, (%rsp)
    e440:      	je	0xe517 <generic_rawtp_path+0x3417>
    e446:      	movl	$0x4, %eax
    e44b:      	leaq	0x8(%rsp), %rdi
    e450:      	movl	$0x8, %esi
    e455:      	movq	%rbx, %rdx
    e458:      	callq	*%rax
    e45a:      	addq	$0x20, %r12
    e45e:      	movl	$0x4, %eax
    e463:      	leaq	0x58(%rsp), %rdi
    e468:      	movl	$0x10, %ecx
    e46d:      	movl	$0x10, %esi
    e472:      	movq	%r12, %rdx
    e475:      	callq	*%rax
    e477:      	movq	0x28(%rsp), %rbx
    e47c:      	movq	0x48(%rsp), %rax
    e481:      	movl	0x5c(%rsp), %r15d
    e486:      	subq	%rbx, %rax
    e489:      	movl	0x50(%rsp), %r12d
    e48e:      	movl	%r15d, %edx
    e491:      	subl	%r12d, %edx
    e494:      	movl	$0x0, %ecx
    e499:      	cmovbl	%ecx, %edx
    e49c:      	addq	0x60(%rsp), %rdx
    e4a1:      	xorl	%esi, %esi
    e4a3:      	cmpl	%r15d, %r12d
    e4a6:      	seta	%sil
    e4aa:      	movl	%r15d, %ecx
    e4ad:      	cmovbl	%r12d, %ecx
    e4b1:      	addl	%ecx, %esi
    e4b3:      	movl	%r12d, %edi
    e4b6:      	subl	%esi, %edi
    e4b8:      	movl	%edi, 0x50(%rsp)
    e4bc:      	subq	%rsi, %rax
    e4bf:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    e4c5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e4cb:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    e4d1:      	cmpl	%r15d, %r12d
    e4d4:      	jbe	0xe4da <generic_rawtp_path+0x33da>
    e4d6:      	movb	$0x2f, (%rbx,%rax)
    e4da:      	xorl	%edi, %edi
    e4dc:      	cmpl	%r15d, %r12d
    e4df:      	seta	%dil
    e4e3:      	movzbl	%cl, %esi
    e4e6:      	addq	%rax, %rbx
    e4e9:      	addq	%rbx, %rdi
    e4ec:      	movl	$0x4, %eax
    e4f1:      	callq	*%rax
    e4f3:      	movq	%rbx, 0x48(%rsp)
    e4f8:      	cmpl	%r15d, %r12d
    e4fb:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    e501:      	movq	0x8(%rsp), %r12
    e506:      	movq	%r12, 0x30(%rsp)
    e50b:      	movq	0x38(%rsp), %rdx
    e510:      	movq	0x40(%rsp), %r15
    e515:      	jmp	0xe568 <generic_rawtp_path+0x3468>
    e517:      	leaq	0x10(%r15), %rdx
    e51b:      	movl	$0x4, %eax
    e520:      	movq	%rbp, %rdi
    e523:      	movl	$0x8, %esi
    e528:      	callq	*%rax
    e52a:      	movq	0x40(%rsp), %rax
    e52f:      	cmpq	(%rsp), %rax
    e533:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    e539:      	addq	$0x18, %r15
    e53d:      	movl	$0x4, %eax
    e542:      	leaq	0x30(%rsp), %rdi
    e547:      	movl	$0x8, %esi
    e54c:      	movq	%r15, %rdx
    e54f:      	callq	*%rax
    e551:      	movq	(%rsp), %r15
    e555:      	movq	%r15, 0x40(%rsp)
    e55a:      	leaq	0x20(%r15), %rdx
    e55e:      	movq	%rdx, 0x38(%rsp)
    e563:      	movq	0x30(%rsp), %r12
    e568:      	cmpq	0x18(%rsp), %r12
    e56d:      	jne	0xe57a <generic_rawtp_path+0x347a>
    e56f:      	cmpq	0x20(%rsp), %rdx
    e574:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    e57a:      	movl	$0x4, %eax
    e57f:      	leaq	0x10(%rsp), %rdi
    e584:      	movl	$0x8, %esi
    e589:      	callq	*%rax
    e58b:      	cmpq	0x10(%rsp), %r12
    e590:      	je	0xe688 <generic_rawtp_path+0x3588>
    e596:      	leaq	0x18(%r12), %rbx
    e59b:      	movl	$0x4, %eax
    e5a0:      	movq	%rbp, %rdi
    e5a3:      	movl	$0x8, %esi
    e5a8:      	movq	%rbx, %rdx
    e5ab:      	callq	*%rax
    e5ad:      	cmpq	%r12, (%rsp)
    e5b1:      	je	0xe688 <generic_rawtp_path+0x3588>
    e5b7:      	movl	$0x4, %eax
    e5bc:      	leaq	0x8(%rsp), %rdi
    e5c1:      	movl	$0x8, %esi
    e5c6:      	movq	%rbx, %rdx
    e5c9:      	callq	*%rax
    e5cb:      	addq	$0x20, %r12
    e5cf:      	movl	$0x4, %eax
    e5d4:      	leaq	0x58(%rsp), %rdi
    e5d9:      	movl	$0x10, %ecx
    e5de:      	movl	$0x10, %esi
    e5e3:      	movq	%r12, %rdx
    e5e6:      	callq	*%rax
    e5e8:      	movq	0x28(%rsp), %rbx
    e5ed:      	movq	0x48(%rsp), %rax
    e5f2:      	movl	0x5c(%rsp), %r15d
    e5f7:      	subq	%rbx, %rax
    e5fa:      	movl	0x50(%rsp), %r12d
    e5ff:      	movl	%r15d, %edx
    e602:      	subl	%r12d, %edx
    e605:      	movl	$0x0, %ecx
    e60a:      	cmovbl	%ecx, %edx
    e60d:      	addq	0x60(%rsp), %rdx
    e612:      	xorl	%esi, %esi
    e614:      	cmpl	%r15d, %r12d
    e617:      	seta	%sil
    e61b:      	movl	%r15d, %ecx
    e61e:      	cmovbl	%r12d, %ecx
    e622:      	addl	%ecx, %esi
    e624:      	movl	%r12d, %edi
    e627:      	subl	%esi, %edi
    e629:      	movl	%edi, 0x50(%rsp)
    e62d:      	subq	%rsi, %rax
    e630:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    e636:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e63c:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    e642:      	cmpl	%r15d, %r12d
    e645:      	jbe	0xe64b <generic_rawtp_path+0x354b>
    e647:      	movb	$0x2f, (%rbx,%rax)
    e64b:      	xorl	%edi, %edi
    e64d:      	cmpl	%r15d, %r12d
    e650:      	seta	%dil
    e654:      	movzbl	%cl, %esi
    e657:      	addq	%rax, %rbx
    e65a:      	addq	%rbx, %rdi
    e65d:      	movl	$0x4, %eax
    e662:      	callq	*%rax
    e664:      	movq	%rbx, 0x48(%rsp)
    e669:      	cmpl	%r15d, %r12d
    e66c:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    e672:      	movq	0x8(%rsp), %r12
    e677:      	movq	%r12, 0x30(%rsp)
    e67c:      	movq	0x38(%rsp), %rdx
    e681:      	movq	0x40(%rsp), %r15
    e686:      	jmp	0xe6d9 <generic_rawtp_path+0x35d9>
    e688:      	leaq	0x10(%r15), %rdx
    e68c:      	movl	$0x4, %eax
    e691:      	movq	%rbp, %rdi
    e694:      	movl	$0x8, %esi
    e699:      	callq	*%rax
    e69b:      	movq	0x40(%rsp), %rax
    e6a0:      	cmpq	(%rsp), %rax
    e6a4:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    e6aa:      	addq	$0x18, %r15
    e6ae:      	movl	$0x4, %eax
    e6b3:      	leaq	0x30(%rsp), %rdi
    e6b8:      	movl	$0x8, %esi
    e6bd:      	movq	%r15, %rdx
    e6c0:      	callq	*%rax
    e6c2:      	movq	(%rsp), %r15
    e6c6:      	movq	%r15, 0x40(%rsp)
    e6cb:      	leaq	0x20(%r15), %rdx
    e6cf:      	movq	%rdx, 0x38(%rsp)
    e6d4:      	movq	0x30(%rsp), %r12
    e6d9:      	cmpq	0x18(%rsp), %r12
    e6de:      	jne	0xe6eb <generic_rawtp_path+0x35eb>
    e6e0:      	cmpq	0x20(%rsp), %rdx
    e6e5:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    e6eb:      	movl	$0x4, %eax
    e6f0:      	leaq	0x10(%rsp), %rdi
    e6f5:      	movl	$0x8, %esi
    e6fa:      	callq	*%rax
    e6fc:      	cmpq	0x10(%rsp), %r12
    e701:      	je	0xe7f9 <generic_rawtp_path+0x36f9>
    e707:      	leaq	0x18(%r12), %rbx
    e70c:      	movl	$0x4, %eax
    e711:      	movq	%rbp, %rdi
    e714:      	movl	$0x8, %esi
    e719:      	movq	%rbx, %rdx
    e71c:      	callq	*%rax
    e71e:      	cmpq	%r12, (%rsp)
    e722:      	je	0xe7f9 <generic_rawtp_path+0x36f9>
    e728:      	movl	$0x4, %eax
    e72d:      	leaq	0x8(%rsp), %rdi
    e732:      	movl	$0x8, %esi
    e737:      	movq	%rbx, %rdx
    e73a:      	callq	*%rax
    e73c:      	addq	$0x20, %r12
    e740:      	movl	$0x4, %eax
    e745:      	leaq	0x58(%rsp), %rdi
    e74a:      	movl	$0x10, %ecx
    e74f:      	movl	$0x10, %esi
    e754:      	movq	%r12, %rdx
    e757:      	callq	*%rax
    e759:      	movq	0x28(%rsp), %rbx
    e75e:      	movq	0x48(%rsp), %rax
    e763:      	movl	0x5c(%rsp), %r15d
    e768:      	subq	%rbx, %rax
    e76b:      	movl	0x50(%rsp), %r12d
    e770:      	movl	%r15d, %edx
    e773:      	subl	%r12d, %edx
    e776:      	movl	$0x0, %ecx
    e77b:      	cmovbl	%ecx, %edx
    e77e:      	addq	0x60(%rsp), %rdx
    e783:      	xorl	%esi, %esi
    e785:      	cmpl	%r15d, %r12d
    e788:      	seta	%sil
    e78c:      	movl	%r15d, %ecx
    e78f:      	cmovbl	%r12d, %ecx
    e793:      	addl	%ecx, %esi
    e795:      	movl	%r12d, %edi
    e798:      	subl	%esi, %edi
    e79a:      	movl	%edi, 0x50(%rsp)
    e79e:      	subq	%rsi, %rax
    e7a1:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    e7a7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e7ad:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    e7b3:      	cmpl	%r15d, %r12d
    e7b6:      	jbe	0xe7bc <generic_rawtp_path+0x36bc>
    e7b8:      	movb	$0x2f, (%rbx,%rax)
    e7bc:      	xorl	%edi, %edi
    e7be:      	cmpl	%r15d, %r12d
    e7c1:      	seta	%dil
    e7c5:      	movzbl	%cl, %esi
    e7c8:      	addq	%rax, %rbx
    e7cb:      	addq	%rbx, %rdi
    e7ce:      	movl	$0x4, %eax
    e7d3:      	callq	*%rax
    e7d5:      	movq	%rbx, 0x48(%rsp)
    e7da:      	cmpl	%r15d, %r12d
    e7dd:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    e7e3:      	movq	0x8(%rsp), %r12
    e7e8:      	movq	%r12, 0x30(%rsp)
    e7ed:      	movq	0x38(%rsp), %rdx
    e7f2:      	movq	0x40(%rsp), %r15
    e7f7:      	jmp	0xe84a <generic_rawtp_path+0x374a>
    e7f9:      	leaq	0x10(%r15), %rdx
    e7fd:      	movl	$0x4, %eax
    e802:      	movq	%rbp, %rdi
    e805:      	movl	$0x8, %esi
    e80a:      	callq	*%rax
    e80c:      	movq	0x40(%rsp), %rax
    e811:      	cmpq	(%rsp), %rax
    e815:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    e81b:      	addq	$0x18, %r15
    e81f:      	movl	$0x4, %eax
    e824:      	leaq	0x30(%rsp), %rdi
    e829:      	movl	$0x8, %esi
    e82e:      	movq	%r15, %rdx
    e831:      	callq	*%rax
    e833:      	movq	(%rsp), %r15
    e837:      	movq	%r15, 0x40(%rsp)
    e83c:      	leaq	0x20(%r15), %rdx
    e840:      	movq	%rdx, 0x38(%rsp)
    e845:      	movq	0x30(%rsp), %r12
    e84a:      	cmpq	0x18(%rsp), %r12
    e84f:      	jne	0xe85c <generic_rawtp_path+0x375c>
    e851:      	cmpq	0x20(%rsp), %rdx
    e856:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    e85c:      	movl	$0x4, %eax
    e861:      	leaq	0x10(%rsp), %rdi
    e866:      	movl	$0x8, %esi
    e86b:      	callq	*%rax
    e86d:      	cmpq	0x10(%rsp), %r12
    e872:      	je	0xe96a <generic_rawtp_path+0x386a>
    e878:      	leaq	0x18(%r12), %rbx
    e87d:      	movl	$0x4, %eax
    e882:      	movq	%rbp, %rdi
    e885:      	movl	$0x8, %esi
    e88a:      	movq	%rbx, %rdx
    e88d:      	callq	*%rax
    e88f:      	cmpq	%r12, (%rsp)
    e893:      	je	0xe96a <generic_rawtp_path+0x386a>
    e899:      	movl	$0x4, %eax
    e89e:      	leaq	0x8(%rsp), %rdi
    e8a3:      	movl	$0x8, %esi
    e8a8:      	movq	%rbx, %rdx
    e8ab:      	callq	*%rax
    e8ad:      	addq	$0x20, %r12
    e8b1:      	movl	$0x4, %eax
    e8b6:      	leaq	0x58(%rsp), %rdi
    e8bb:      	movl	$0x10, %ecx
    e8c0:      	movl	$0x10, %esi
    e8c5:      	movq	%r12, %rdx
    e8c8:      	callq	*%rax
    e8ca:      	movq	0x28(%rsp), %rbx
    e8cf:      	movq	0x48(%rsp), %rax
    e8d4:      	movl	0x5c(%rsp), %r15d
    e8d9:      	subq	%rbx, %rax
    e8dc:      	movl	0x50(%rsp), %r12d
    e8e1:      	movl	%r15d, %edx
    e8e4:      	subl	%r12d, %edx
    e8e7:      	movl	$0x0, %ecx
    e8ec:      	cmovbl	%ecx, %edx
    e8ef:      	addq	0x60(%rsp), %rdx
    e8f4:      	xorl	%esi, %esi
    e8f6:      	cmpl	%r15d, %r12d
    e8f9:      	seta	%sil
    e8fd:      	movl	%r15d, %ecx
    e900:      	cmovbl	%r12d, %ecx
    e904:      	addl	%ecx, %esi
    e906:      	movl	%r12d, %edi
    e909:      	subl	%esi, %edi
    e90b:      	movl	%edi, 0x50(%rsp)
    e90f:      	subq	%rsi, %rax
    e912:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    e918:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e91e:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    e924:      	cmpl	%r15d, %r12d
    e927:      	jbe	0xe92d <generic_rawtp_path+0x382d>
    e929:      	movb	$0x2f, (%rbx,%rax)
    e92d:      	xorl	%edi, %edi
    e92f:      	cmpl	%r15d, %r12d
    e932:      	seta	%dil
    e936:      	movzbl	%cl, %esi
    e939:      	addq	%rax, %rbx
    e93c:      	addq	%rbx, %rdi
    e93f:      	movl	$0x4, %eax
    e944:      	callq	*%rax
    e946:      	movq	%rbx, 0x48(%rsp)
    e94b:      	cmpl	%r15d, %r12d
    e94e:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    e954:      	movq	0x8(%rsp), %r12
    e959:      	movq	%r12, 0x30(%rsp)
    e95e:      	movq	0x38(%rsp), %rdx
    e963:      	movq	0x40(%rsp), %r15
    e968:      	jmp	0xe9bb <generic_rawtp_path+0x38bb>
    e96a:      	leaq	0x10(%r15), %rdx
    e96e:      	movl	$0x4, %eax
    e973:      	movq	%rbp, %rdi
    e976:      	movl	$0x8, %esi
    e97b:      	callq	*%rax
    e97d:      	movq	0x40(%rsp), %rax
    e982:      	cmpq	(%rsp), %rax
    e986:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    e98c:      	addq	$0x18, %r15
    e990:      	movl	$0x4, %eax
    e995:      	leaq	0x30(%rsp), %rdi
    e99a:      	movl	$0x8, %esi
    e99f:      	movq	%r15, %rdx
    e9a2:      	callq	*%rax
    e9a4:      	movq	(%rsp), %r15
    e9a8:      	movq	%r15, 0x40(%rsp)
    e9ad:      	leaq	0x20(%r15), %rdx
    e9b1:      	movq	%rdx, 0x38(%rsp)
    e9b6:      	movq	0x30(%rsp), %r12
    e9bb:      	cmpq	0x18(%rsp), %r12
    e9c0:      	jne	0xe9cd <generic_rawtp_path+0x38cd>
    e9c2:      	cmpq	0x20(%rsp), %rdx
    e9c7:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    e9cd:      	movl	$0x4, %eax
    e9d2:      	leaq	0x10(%rsp), %rdi
    e9d7:      	movl	$0x8, %esi
    e9dc:      	callq	*%rax
    e9de:      	cmpq	0x10(%rsp), %r12
    e9e3:      	je	0xeadb <generic_rawtp_path+0x39db>
    e9e9:      	leaq	0x18(%r12), %rbx
    e9ee:      	movl	$0x4, %eax
    e9f3:      	movq	%rbp, %rdi
    e9f6:      	movl	$0x8, %esi
    e9fb:      	movq	%rbx, %rdx
    e9fe:      	callq	*%rax
    ea00:      	cmpq	%r12, (%rsp)
    ea04:      	je	0xeadb <generic_rawtp_path+0x39db>
    ea0a:      	movl	$0x4, %eax
    ea0f:      	leaq	0x8(%rsp), %rdi
    ea14:      	movl	$0x8, %esi
    ea19:      	movq	%rbx, %rdx
    ea1c:      	callq	*%rax
    ea1e:      	addq	$0x20, %r12
    ea22:      	movl	$0x4, %eax
    ea27:      	leaq	0x58(%rsp), %rdi
    ea2c:      	movl	$0x10, %ecx
    ea31:      	movl	$0x10, %esi
    ea36:      	movq	%r12, %rdx
    ea39:      	callq	*%rax
    ea3b:      	movq	0x28(%rsp), %rbx
    ea40:      	movq	0x48(%rsp), %rax
    ea45:      	movl	0x5c(%rsp), %r15d
    ea4a:      	subq	%rbx, %rax
    ea4d:      	movl	0x50(%rsp), %r12d
    ea52:      	movl	%r15d, %edx
    ea55:      	subl	%r12d, %edx
    ea58:      	movl	$0x0, %ecx
    ea5d:      	cmovbl	%ecx, %edx
    ea60:      	addq	0x60(%rsp), %rdx
    ea65:      	xorl	%esi, %esi
    ea67:      	cmpl	%r15d, %r12d
    ea6a:      	seta	%sil
    ea6e:      	movl	%r15d, %ecx
    ea71:      	cmovbl	%r12d, %ecx
    ea75:      	addl	%ecx, %esi
    ea77:      	movl	%r12d, %edi
    ea7a:      	subl	%esi, %edi
    ea7c:      	movl	%edi, 0x50(%rsp)
    ea80:      	subq	%rsi, %rax
    ea83:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    ea89:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ea8f:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    ea95:      	cmpl	%r15d, %r12d
    ea98:      	jbe	0xea9e <generic_rawtp_path+0x399e>
    ea9a:      	movb	$0x2f, (%rbx,%rax)
    ea9e:      	xorl	%edi, %edi
    eaa0:      	cmpl	%r15d, %r12d
    eaa3:      	seta	%dil
    eaa7:      	movzbl	%cl, %esi
    eaaa:      	addq	%rax, %rbx
    eaad:      	addq	%rbx, %rdi
    eab0:      	movl	$0x4, %eax
    eab5:      	callq	*%rax
    eab7:      	movq	%rbx, 0x48(%rsp)
    eabc:      	cmpl	%r15d, %r12d
    eabf:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    eac5:      	movq	0x8(%rsp), %r12
    eaca:      	movq	%r12, 0x30(%rsp)
    eacf:      	movq	0x38(%rsp), %rdx
    ead4:      	movq	0x40(%rsp), %r15
    ead9:      	jmp	0xeb2c <generic_rawtp_path+0x3a2c>
    eadb:      	leaq	0x10(%r15), %rdx
    eadf:      	movl	$0x4, %eax
    eae4:      	movq	%rbp, %rdi
    eae7:      	movl	$0x8, %esi
    eaec:      	callq	*%rax
    eaee:      	movq	0x40(%rsp), %rax
    eaf3:      	cmpq	(%rsp), %rax
    eaf7:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    eafd:      	addq	$0x18, %r15
    eb01:      	movl	$0x4, %eax
    eb06:      	leaq	0x30(%rsp), %rdi
    eb0b:      	movl	$0x8, %esi
    eb10:      	movq	%r15, %rdx
    eb13:      	callq	*%rax
    eb15:      	movq	(%rsp), %r15
    eb19:      	movq	%r15, 0x40(%rsp)
    eb1e:      	leaq	0x20(%r15), %rdx
    eb22:      	movq	%rdx, 0x38(%rsp)
    eb27:      	movq	0x30(%rsp), %r12
    eb2c:      	cmpq	0x18(%rsp), %r12
    eb31:      	jne	0xeb3e <generic_rawtp_path+0x3a3e>
    eb33:      	cmpq	0x20(%rsp), %rdx
    eb38:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    eb3e:      	movl	$0x4, %eax
    eb43:      	leaq	0x10(%rsp), %rdi
    eb48:      	movl	$0x8, %esi
    eb4d:      	callq	*%rax
    eb4f:      	cmpq	0x10(%rsp), %r12
    eb54:      	je	0xec4c <generic_rawtp_path+0x3b4c>
    eb5a:      	leaq	0x18(%r12), %rbx
    eb5f:      	movl	$0x4, %eax
    eb64:      	movq	%rbp, %rdi
    eb67:      	movl	$0x8, %esi
    eb6c:      	movq	%rbx, %rdx
    eb6f:      	callq	*%rax
    eb71:      	cmpq	%r12, (%rsp)
    eb75:      	je	0xec4c <generic_rawtp_path+0x3b4c>
    eb7b:      	movl	$0x4, %eax
    eb80:      	leaq	0x8(%rsp), %rdi
    eb85:      	movl	$0x8, %esi
    eb8a:      	movq	%rbx, %rdx
    eb8d:      	callq	*%rax
    eb8f:      	addq	$0x20, %r12
    eb93:      	movl	$0x4, %eax
    eb98:      	leaq	0x58(%rsp), %rdi
    eb9d:      	movl	$0x10, %ecx
    eba2:      	movl	$0x10, %esi
    eba7:      	movq	%r12, %rdx
    ebaa:      	callq	*%rax
    ebac:      	movq	0x28(%rsp), %rbx
    ebb1:      	movq	0x48(%rsp), %rax
    ebb6:      	movl	0x5c(%rsp), %r15d
    ebbb:      	subq	%rbx, %rax
    ebbe:      	movl	0x50(%rsp), %r12d
    ebc3:      	movl	%r15d, %edx
    ebc6:      	subl	%r12d, %edx
    ebc9:      	movl	$0x0, %ecx
    ebce:      	cmovbl	%ecx, %edx
    ebd1:      	addq	0x60(%rsp), %rdx
    ebd6:      	xorl	%esi, %esi
    ebd8:      	cmpl	%r15d, %r12d
    ebdb:      	seta	%sil
    ebdf:      	movl	%r15d, %ecx
    ebe2:      	cmovbl	%r12d, %ecx
    ebe6:      	addl	%ecx, %esi
    ebe8:      	movl	%r12d, %edi
    ebeb:      	subl	%esi, %edi
    ebed:      	movl	%edi, 0x50(%rsp)
    ebf1:      	subq	%rsi, %rax
    ebf4:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    ebfa:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ec00:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    ec06:      	cmpl	%r15d, %r12d
    ec09:      	jbe	0xec0f <generic_rawtp_path+0x3b0f>
    ec0b:      	movb	$0x2f, (%rbx,%rax)
    ec0f:      	xorl	%edi, %edi
    ec11:      	cmpl	%r15d, %r12d
    ec14:      	seta	%dil
    ec18:      	movzbl	%cl, %esi
    ec1b:      	addq	%rax, %rbx
    ec1e:      	addq	%rbx, %rdi
    ec21:      	movl	$0x4, %eax
    ec26:      	callq	*%rax
    ec28:      	movq	%rbx, 0x48(%rsp)
    ec2d:      	cmpl	%r15d, %r12d
    ec30:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    ec36:      	movq	0x8(%rsp), %r12
    ec3b:      	movq	%r12, 0x30(%rsp)
    ec40:      	movq	0x38(%rsp), %rdx
    ec45:      	movq	0x40(%rsp), %r15
    ec4a:      	jmp	0xec9d <generic_rawtp_path+0x3b9d>
    ec4c:      	leaq	0x10(%r15), %rdx
    ec50:      	movl	$0x4, %eax
    ec55:      	movq	%rbp, %rdi
    ec58:      	movl	$0x8, %esi
    ec5d:      	callq	*%rax
    ec5f:      	movq	0x40(%rsp), %rax
    ec64:      	cmpq	(%rsp), %rax
    ec68:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    ec6e:      	addq	$0x18, %r15
    ec72:      	movl	$0x4, %eax
    ec77:      	leaq	0x30(%rsp), %rdi
    ec7c:      	movl	$0x8, %esi
    ec81:      	movq	%r15, %rdx
    ec84:      	callq	*%rax
    ec86:      	movq	(%rsp), %r15
    ec8a:      	movq	%r15, 0x40(%rsp)
    ec8f:      	leaq	0x20(%r15), %rdx
    ec93:      	movq	%rdx, 0x38(%rsp)
    ec98:      	movq	0x30(%rsp), %r12
    ec9d:      	cmpq	0x18(%rsp), %r12
    eca2:      	jne	0xecaf <generic_rawtp_path+0x3baf>
    eca4:      	cmpq	0x20(%rsp), %rdx
    eca9:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    ecaf:      	movl	$0x4, %eax
    ecb4:      	leaq	0x10(%rsp), %rdi
    ecb9:      	movl	$0x8, %esi
    ecbe:      	callq	*%rax
    ecc0:      	cmpq	0x10(%rsp), %r12
    ecc5:      	je	0xedbd <generic_rawtp_path+0x3cbd>
    eccb:      	leaq	0x18(%r12), %rbx
    ecd0:      	movl	$0x4, %eax
    ecd5:      	movq	%rbp, %rdi
    ecd8:      	movl	$0x8, %esi
    ecdd:      	movq	%rbx, %rdx
    ece0:      	callq	*%rax
    ece2:      	cmpq	%r12, (%rsp)
    ece6:      	je	0xedbd <generic_rawtp_path+0x3cbd>
    ecec:      	movl	$0x4, %eax
    ecf1:      	leaq	0x8(%rsp), %rdi
    ecf6:      	movl	$0x8, %esi
    ecfb:      	movq	%rbx, %rdx
    ecfe:      	callq	*%rax
    ed00:      	addq	$0x20, %r12
    ed04:      	movl	$0x4, %eax
    ed09:      	leaq	0x58(%rsp), %rdi
    ed0e:      	movl	$0x10, %ecx
    ed13:      	movl	$0x10, %esi
    ed18:      	movq	%r12, %rdx
    ed1b:      	callq	*%rax
    ed1d:      	movq	0x28(%rsp), %rbx
    ed22:      	movq	0x48(%rsp), %rax
    ed27:      	movl	0x5c(%rsp), %r15d
    ed2c:      	subq	%rbx, %rax
    ed2f:      	movl	0x50(%rsp), %r12d
    ed34:      	movl	%r15d, %edx
    ed37:      	subl	%r12d, %edx
    ed3a:      	movl	$0x0, %ecx
    ed3f:      	cmovbl	%ecx, %edx
    ed42:      	addq	0x60(%rsp), %rdx
    ed47:      	xorl	%esi, %esi
    ed49:      	cmpl	%r15d, %r12d
    ed4c:      	seta	%sil
    ed50:      	movl	%r15d, %ecx
    ed53:      	cmovbl	%r12d, %ecx
    ed57:      	addl	%ecx, %esi
    ed59:      	movl	%r12d, %edi
    ed5c:      	subl	%esi, %edi
    ed5e:      	movl	%edi, 0x50(%rsp)
    ed62:      	subq	%rsi, %rax
    ed65:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    ed6b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ed71:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    ed77:      	cmpl	%r15d, %r12d
    ed7a:      	jbe	0xed80 <generic_rawtp_path+0x3c80>
    ed7c:      	movb	$0x2f, (%rbx,%rax)
    ed80:      	xorl	%edi, %edi
    ed82:      	cmpl	%r15d, %r12d
    ed85:      	seta	%dil
    ed89:      	movzbl	%cl, %esi
    ed8c:      	addq	%rax, %rbx
    ed8f:      	addq	%rbx, %rdi
    ed92:      	movl	$0x4, %eax
    ed97:      	callq	*%rax
    ed99:      	movq	%rbx, 0x48(%rsp)
    ed9e:      	cmpl	%r15d, %r12d
    eda1:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    eda7:      	movq	0x8(%rsp), %r12
    edac:      	movq	%r12, 0x30(%rsp)
    edb1:      	movq	0x38(%rsp), %rdx
    edb6:      	movq	0x40(%rsp), %r15
    edbb:      	jmp	0xee0e <generic_rawtp_path+0x3d0e>
    edbd:      	leaq	0x10(%r15), %rdx
    edc1:      	movl	$0x4, %eax
    edc6:      	movq	%rbp, %rdi
    edc9:      	movl	$0x8, %esi
    edce:      	callq	*%rax
    edd0:      	movq	0x40(%rsp), %rax
    edd5:      	cmpq	(%rsp), %rax
    edd9:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    eddf:      	addq	$0x18, %r15
    ede3:      	movl	$0x4, %eax
    ede8:      	leaq	0x30(%rsp), %rdi
    eded:      	movl	$0x8, %esi
    edf2:      	movq	%r15, %rdx
    edf5:      	callq	*%rax
    edf7:      	movq	(%rsp), %r15
    edfb:      	movq	%r15, 0x40(%rsp)
    ee00:      	leaq	0x20(%r15), %rdx
    ee04:      	movq	%rdx, 0x38(%rsp)
    ee09:      	movq	0x30(%rsp), %r12
    ee0e:      	cmpq	0x18(%rsp), %r12
    ee13:      	jne	0xee20 <generic_rawtp_path+0x3d20>
    ee15:      	cmpq	0x20(%rsp), %rdx
    ee1a:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    ee20:      	movl	$0x4, %eax
    ee25:      	leaq	0x10(%rsp), %rdi
    ee2a:      	movl	$0x8, %esi
    ee2f:      	callq	*%rax
    ee31:      	cmpq	0x10(%rsp), %r12
    ee36:      	je	0xef2e <generic_rawtp_path+0x3e2e>
    ee3c:      	leaq	0x18(%r12), %rbx
    ee41:      	movl	$0x4, %eax
    ee46:      	movq	%rbp, %rdi
    ee49:      	movl	$0x8, %esi
    ee4e:      	movq	%rbx, %rdx
    ee51:      	callq	*%rax
    ee53:      	cmpq	%r12, (%rsp)
    ee57:      	je	0xef2e <generic_rawtp_path+0x3e2e>
    ee5d:      	movl	$0x4, %eax
    ee62:      	leaq	0x8(%rsp), %rdi
    ee67:      	movl	$0x8, %esi
    ee6c:      	movq	%rbx, %rdx
    ee6f:      	callq	*%rax
    ee71:      	addq	$0x20, %r12
    ee75:      	movl	$0x4, %eax
    ee7a:      	leaq	0x58(%rsp), %rdi
    ee7f:      	movl	$0x10, %ecx
    ee84:      	movl	$0x10, %esi
    ee89:      	movq	%r12, %rdx
    ee8c:      	callq	*%rax
    ee8e:      	movq	0x28(%rsp), %rbx
    ee93:      	movq	0x48(%rsp), %rax
    ee98:      	movl	0x5c(%rsp), %r15d
    ee9d:      	subq	%rbx, %rax
    eea0:      	movl	0x50(%rsp), %r12d
    eea5:      	movl	%r15d, %edx
    eea8:      	subl	%r12d, %edx
    eeab:      	movl	$0x0, %ecx
    eeb0:      	cmovbl	%ecx, %edx
    eeb3:      	addq	0x60(%rsp), %rdx
    eeb8:      	xorl	%esi, %esi
    eeba:      	cmpl	%r15d, %r12d
    eebd:      	seta	%sil
    eec1:      	movl	%r15d, %ecx
    eec4:      	cmovbl	%r12d, %ecx
    eec8:      	addl	%ecx, %esi
    eeca:      	movl	%r12d, %edi
    eecd:      	subl	%esi, %edi
    eecf:      	movl	%edi, 0x50(%rsp)
    eed3:      	subq	%rsi, %rax
    eed6:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    eedc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    eee2:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    eee8:      	cmpl	%r15d, %r12d
    eeeb:      	jbe	0xeef1 <generic_rawtp_path+0x3df1>
    eeed:      	movb	$0x2f, (%rbx,%rax)
    eef1:      	xorl	%edi, %edi
    eef3:      	cmpl	%r15d, %r12d
    eef6:      	seta	%dil
    eefa:      	movzbl	%cl, %esi
    eefd:      	addq	%rax, %rbx
    ef00:      	addq	%rbx, %rdi
    ef03:      	movl	$0x4, %eax
    ef08:      	callq	*%rax
    ef0a:      	movq	%rbx, 0x48(%rsp)
    ef0f:      	cmpl	%r15d, %r12d
    ef12:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    ef18:      	movq	0x8(%rsp), %r12
    ef1d:      	movq	%r12, 0x30(%rsp)
    ef22:      	movq	0x38(%rsp), %rdx
    ef27:      	movq	0x40(%rsp), %r15
    ef2c:      	jmp	0xef7f <generic_rawtp_path+0x3e7f>
    ef2e:      	leaq	0x10(%r15), %rdx
    ef32:      	movl	$0x4, %eax
    ef37:      	movq	%rbp, %rdi
    ef3a:      	movl	$0x8, %esi
    ef3f:      	callq	*%rax
    ef41:      	movq	0x40(%rsp), %rax
    ef46:      	cmpq	(%rsp), %rax
    ef4a:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    ef50:      	addq	$0x18, %r15
    ef54:      	movl	$0x4, %eax
    ef59:      	leaq	0x30(%rsp), %rdi
    ef5e:      	movl	$0x8, %esi
    ef63:      	movq	%r15, %rdx
    ef66:      	callq	*%rax
    ef68:      	movq	(%rsp), %r15
    ef6c:      	movq	%r15, 0x40(%rsp)
    ef71:      	leaq	0x20(%r15), %rdx
    ef75:      	movq	%rdx, 0x38(%rsp)
    ef7a:      	movq	0x30(%rsp), %r12
    ef7f:      	cmpq	0x18(%rsp), %r12
    ef84:      	jne	0xef91 <generic_rawtp_path+0x3e91>
    ef86:      	cmpq	0x20(%rsp), %rdx
    ef8b:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    ef91:      	movl	$0x4, %eax
    ef96:      	leaq	0x10(%rsp), %rdi
    ef9b:      	movl	$0x8, %esi
    efa0:      	callq	*%rax
    efa2:      	cmpq	0x10(%rsp), %r12
    efa7:      	je	0xf09f <generic_rawtp_path+0x3f9f>
    efad:      	leaq	0x18(%r12), %rbx
    efb2:      	movl	$0x4, %eax
    efb7:      	movq	%rbp, %rdi
    efba:      	movl	$0x8, %esi
    efbf:      	movq	%rbx, %rdx
    efc2:      	callq	*%rax
    efc4:      	cmpq	%r12, (%rsp)
    efc8:      	je	0xf09f <generic_rawtp_path+0x3f9f>
    efce:      	movl	$0x4, %eax
    efd3:      	leaq	0x8(%rsp), %rdi
    efd8:      	movl	$0x8, %esi
    efdd:      	movq	%rbx, %rdx
    efe0:      	callq	*%rax
    efe2:      	addq	$0x20, %r12
    efe6:      	movl	$0x4, %eax
    efeb:      	leaq	0x58(%rsp), %rdi
    eff0:      	movl	$0x10, %ecx
    eff5:      	movl	$0x10, %esi
    effa:      	movq	%r12, %rdx
    effd:      	callq	*%rax
    efff:      	movq	0x28(%rsp), %rbx
    f004:      	movq	0x48(%rsp), %rax
    f009:      	movl	0x5c(%rsp), %r15d
    f00e:      	subq	%rbx, %rax
    f011:      	movl	0x50(%rsp), %r12d
    f016:      	movl	%r15d, %edx
    f019:      	subl	%r12d, %edx
    f01c:      	movl	$0x0, %ecx
    f021:      	cmovbl	%ecx, %edx
    f024:      	addq	0x60(%rsp), %rdx
    f029:      	xorl	%esi, %esi
    f02b:      	cmpl	%r15d, %r12d
    f02e:      	seta	%sil
    f032:      	movl	%r15d, %ecx
    f035:      	cmovbl	%r12d, %ecx
    f039:      	addl	%ecx, %esi
    f03b:      	movl	%r12d, %edi
    f03e:      	subl	%esi, %edi
    f040:      	movl	%edi, 0x50(%rsp)
    f044:      	subq	%rsi, %rax
    f047:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    f04d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f053:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    f059:      	cmpl	%r15d, %r12d
    f05c:      	jbe	0xf062 <generic_rawtp_path+0x3f62>
    f05e:      	movb	$0x2f, (%rbx,%rax)
    f062:      	xorl	%edi, %edi
    f064:      	cmpl	%r15d, %r12d
    f067:      	seta	%dil
    f06b:      	movzbl	%cl, %esi
    f06e:      	addq	%rax, %rbx
    f071:      	addq	%rbx, %rdi
    f074:      	movl	$0x4, %eax
    f079:      	callq	*%rax
    f07b:      	movq	%rbx, 0x48(%rsp)
    f080:      	cmpl	%r15d, %r12d
    f083:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    f089:      	movq	0x8(%rsp), %r12
    f08e:      	movq	%r12, 0x30(%rsp)
    f093:      	movq	0x38(%rsp), %rdx
    f098:      	movq	0x40(%rsp), %r15
    f09d:      	jmp	0xf0f0 <generic_rawtp_path+0x3ff0>
    f09f:      	leaq	0x10(%r15), %rdx
    f0a3:      	movl	$0x4, %eax
    f0a8:      	movq	%rbp, %rdi
    f0ab:      	movl	$0x8, %esi
    f0b0:      	callq	*%rax
    f0b2:      	movq	0x40(%rsp), %rax
    f0b7:      	cmpq	(%rsp), %rax
    f0bb:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    f0c1:      	addq	$0x18, %r15
    f0c5:      	movl	$0x4, %eax
    f0ca:      	leaq	0x30(%rsp), %rdi
    f0cf:      	movl	$0x8, %esi
    f0d4:      	movq	%r15, %rdx
    f0d7:      	callq	*%rax
    f0d9:      	movq	(%rsp), %r15
    f0dd:      	movq	%r15, 0x40(%rsp)
    f0e2:      	leaq	0x20(%r15), %rdx
    f0e6:      	movq	%rdx, 0x38(%rsp)
    f0eb:      	movq	0x30(%rsp), %r12
    f0f0:      	cmpq	0x18(%rsp), %r12
    f0f5:      	jne	0xf102 <generic_rawtp_path+0x4002>
    f0f7:      	cmpq	0x20(%rsp), %rdx
    f0fc:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    f102:      	movl	$0x4, %eax
    f107:      	leaq	0x10(%rsp), %rdi
    f10c:      	movl	$0x8, %esi
    f111:      	callq	*%rax
    f113:      	cmpq	0x10(%rsp), %r12
    f118:      	je	0xf210 <generic_rawtp_path+0x4110>
    f11e:      	leaq	0x18(%r12), %rbx
    f123:      	movl	$0x4, %eax
    f128:      	movq	%rbp, %rdi
    f12b:      	movl	$0x8, %esi
    f130:      	movq	%rbx, %rdx
    f133:      	callq	*%rax
    f135:      	cmpq	%r12, (%rsp)
    f139:      	je	0xf210 <generic_rawtp_path+0x4110>
    f13f:      	movl	$0x4, %eax
    f144:      	leaq	0x8(%rsp), %rdi
    f149:      	movl	$0x8, %esi
    f14e:      	movq	%rbx, %rdx
    f151:      	callq	*%rax
    f153:      	addq	$0x20, %r12
    f157:      	movl	$0x4, %eax
    f15c:      	leaq	0x58(%rsp), %rdi
    f161:      	movl	$0x10, %ecx
    f166:      	movl	$0x10, %esi
    f16b:      	movq	%r12, %rdx
    f16e:      	callq	*%rax
    f170:      	movq	0x28(%rsp), %rbx
    f175:      	movq	0x48(%rsp), %rax
    f17a:      	movl	0x5c(%rsp), %r15d
    f17f:      	subq	%rbx, %rax
    f182:      	movl	0x50(%rsp), %r12d
    f187:      	movl	%r15d, %edx
    f18a:      	subl	%r12d, %edx
    f18d:      	movl	$0x0, %ecx
    f192:      	cmovbl	%ecx, %edx
    f195:      	addq	0x60(%rsp), %rdx
    f19a:      	xorl	%esi, %esi
    f19c:      	cmpl	%r15d, %r12d
    f19f:      	seta	%sil
    f1a3:      	movl	%r15d, %ecx
    f1a6:      	cmovbl	%r12d, %ecx
    f1aa:      	addl	%ecx, %esi
    f1ac:      	movl	%r12d, %edi
    f1af:      	subl	%esi, %edi
    f1b1:      	movl	%edi, 0x50(%rsp)
    f1b5:      	subq	%rsi, %rax
    f1b8:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    f1be:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f1c4:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    f1ca:      	cmpl	%r15d, %r12d
    f1cd:      	jbe	0xf1d3 <generic_rawtp_path+0x40d3>
    f1cf:      	movb	$0x2f, (%rbx,%rax)
    f1d3:      	xorl	%edi, %edi
    f1d5:      	cmpl	%r15d, %r12d
    f1d8:      	seta	%dil
    f1dc:      	movzbl	%cl, %esi
    f1df:      	addq	%rax, %rbx
    f1e2:      	addq	%rbx, %rdi
    f1e5:      	movl	$0x4, %eax
    f1ea:      	callq	*%rax
    f1ec:      	movq	%rbx, 0x48(%rsp)
    f1f1:      	cmpl	%r15d, %r12d
    f1f4:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    f1fa:      	movq	0x8(%rsp), %r12
    f1ff:      	movq	%r12, 0x30(%rsp)
    f204:      	movq	0x38(%rsp), %rdx
    f209:      	movq	0x40(%rsp), %r15
    f20e:      	jmp	0xf261 <generic_rawtp_path+0x4161>
    f210:      	leaq	0x10(%r15), %rdx
    f214:      	movl	$0x4, %eax
    f219:      	movq	%rbp, %rdi
    f21c:      	movl	$0x8, %esi
    f221:      	callq	*%rax
    f223:      	movq	0x40(%rsp), %rax
    f228:      	cmpq	(%rsp), %rax
    f22c:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    f232:      	addq	$0x18, %r15
    f236:      	movl	$0x4, %eax
    f23b:      	leaq	0x30(%rsp), %rdi
    f240:      	movl	$0x8, %esi
    f245:      	movq	%r15, %rdx
    f248:      	callq	*%rax
    f24a:      	movq	(%rsp), %r15
    f24e:      	movq	%r15, 0x40(%rsp)
    f253:      	leaq	0x20(%r15), %rdx
    f257:      	movq	%rdx, 0x38(%rsp)
    f25c:      	movq	0x30(%rsp), %r12
    f261:      	cmpq	0x18(%rsp), %r12
    f266:      	jne	0xf273 <generic_rawtp_path+0x4173>
    f268:      	cmpq	0x20(%rsp), %rdx
    f26d:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    f273:      	movl	$0x4, %eax
    f278:      	leaq	0x10(%rsp), %rdi
    f27d:      	movl	$0x8, %esi
    f282:      	callq	*%rax
    f284:      	cmpq	0x10(%rsp), %r12
    f289:      	je	0xf381 <generic_rawtp_path+0x4281>
    f28f:      	leaq	0x18(%r12), %rbx
    f294:      	movl	$0x4, %eax
    f299:      	movq	%rbp, %rdi
    f29c:      	movl	$0x8, %esi
    f2a1:      	movq	%rbx, %rdx
    f2a4:      	callq	*%rax
    f2a6:      	cmpq	%r12, (%rsp)
    f2aa:      	je	0xf381 <generic_rawtp_path+0x4281>
    f2b0:      	movl	$0x4, %eax
    f2b5:      	leaq	0x8(%rsp), %rdi
    f2ba:      	movl	$0x8, %esi
    f2bf:      	movq	%rbx, %rdx
    f2c2:      	callq	*%rax
    f2c4:      	addq	$0x20, %r12
    f2c8:      	movl	$0x4, %eax
    f2cd:      	leaq	0x58(%rsp), %rdi
    f2d2:      	movl	$0x10, %ecx
    f2d7:      	movl	$0x10, %esi
    f2dc:      	movq	%r12, %rdx
    f2df:      	callq	*%rax
    f2e1:      	movq	0x28(%rsp), %rbx
    f2e6:      	movq	0x48(%rsp), %rax
    f2eb:      	movl	0x5c(%rsp), %r15d
    f2f0:      	subq	%rbx, %rax
    f2f3:      	movl	0x50(%rsp), %r12d
    f2f8:      	movl	%r15d, %edx
    f2fb:      	subl	%r12d, %edx
    f2fe:      	movl	$0x0, %ecx
    f303:      	cmovbl	%ecx, %edx
    f306:      	addq	0x60(%rsp), %rdx
    f30b:      	xorl	%esi, %esi
    f30d:      	cmpl	%r15d, %r12d
    f310:      	seta	%sil
    f314:      	movl	%r15d, %ecx
    f317:      	cmovbl	%r12d, %ecx
    f31b:      	addl	%ecx, %esi
    f31d:      	movl	%r12d, %edi
    f320:      	subl	%esi, %edi
    f322:      	movl	%edi, 0x50(%rsp)
    f326:      	subq	%rsi, %rax
    f329:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    f32f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f335:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    f33b:      	cmpl	%r15d, %r12d
    f33e:      	jbe	0xf344 <generic_rawtp_path+0x4244>
    f340:      	movb	$0x2f, (%rbx,%rax)
    f344:      	xorl	%edi, %edi
    f346:      	cmpl	%r15d, %r12d
    f349:      	seta	%dil
    f34d:      	movzbl	%cl, %esi
    f350:      	addq	%rax, %rbx
    f353:      	addq	%rbx, %rdi
    f356:      	movl	$0x4, %eax
    f35b:      	callq	*%rax
    f35d:      	movq	%rbx, 0x48(%rsp)
    f362:      	cmpl	%r15d, %r12d
    f365:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    f36b:      	movq	0x8(%rsp), %r12
    f370:      	movq	%r12, 0x30(%rsp)
    f375:      	movq	0x38(%rsp), %rdx
    f37a:      	movq	0x40(%rsp), %r15
    f37f:      	jmp	0xf3d2 <generic_rawtp_path+0x42d2>
    f381:      	leaq	0x10(%r15), %rdx
    f385:      	movl	$0x4, %eax
    f38a:      	movq	%rbp, %rdi
    f38d:      	movl	$0x8, %esi
    f392:      	callq	*%rax
    f394:      	movq	0x40(%rsp), %rax
    f399:      	cmpq	(%rsp), %rax
    f39d:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    f3a3:      	addq	$0x18, %r15
    f3a7:      	movl	$0x4, %eax
    f3ac:      	leaq	0x30(%rsp), %rdi
    f3b1:      	movl	$0x8, %esi
    f3b6:      	movq	%r15, %rdx
    f3b9:      	callq	*%rax
    f3bb:      	movq	(%rsp), %r15
    f3bf:      	movq	%r15, 0x40(%rsp)
    f3c4:      	leaq	0x20(%r15), %rdx
    f3c8:      	movq	%rdx, 0x38(%rsp)
    f3cd:      	movq	0x30(%rsp), %r12
    f3d2:      	cmpq	0x18(%rsp), %r12
    f3d7:      	jne	0xf3e4 <generic_rawtp_path+0x42e4>
    f3d9:      	cmpq	0x20(%rsp), %rdx
    f3de:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    f3e4:      	movl	$0x4, %eax
    f3e9:      	leaq	0x10(%rsp), %rdi
    f3ee:      	movl	$0x8, %esi
    f3f3:      	callq	*%rax
    f3f5:      	cmpq	0x10(%rsp), %r12
    f3fa:      	je	0xf4f2 <generic_rawtp_path+0x43f2>
    f400:      	leaq	0x18(%r12), %rbx
    f405:      	movl	$0x4, %eax
    f40a:      	movq	%rbp, %rdi
    f40d:      	movl	$0x8, %esi
    f412:      	movq	%rbx, %rdx
    f415:      	callq	*%rax
    f417:      	cmpq	%r12, (%rsp)
    f41b:      	je	0xf4f2 <generic_rawtp_path+0x43f2>
    f421:      	movl	$0x4, %eax
    f426:      	leaq	0x8(%rsp), %rdi
    f42b:      	movl	$0x8, %esi
    f430:      	movq	%rbx, %rdx
    f433:      	callq	*%rax
    f435:      	addq	$0x20, %r12
    f439:      	movl	$0x4, %eax
    f43e:      	leaq	0x58(%rsp), %rdi
    f443:      	movl	$0x10, %ecx
    f448:      	movl	$0x10, %esi
    f44d:      	movq	%r12, %rdx
    f450:      	callq	*%rax
    f452:      	movq	0x28(%rsp), %rbx
    f457:      	movq	0x48(%rsp), %rax
    f45c:      	movl	0x5c(%rsp), %r15d
    f461:      	subq	%rbx, %rax
    f464:      	movl	0x50(%rsp), %r12d
    f469:      	movl	%r15d, %edx
    f46c:      	subl	%r12d, %edx
    f46f:      	movl	$0x0, %ecx
    f474:      	cmovbl	%ecx, %edx
    f477:      	addq	0x60(%rsp), %rdx
    f47c:      	xorl	%esi, %esi
    f47e:      	cmpl	%r15d, %r12d
    f481:      	seta	%sil
    f485:      	movl	%r15d, %ecx
    f488:      	cmovbl	%r12d, %ecx
    f48c:      	addl	%ecx, %esi
    f48e:      	movl	%r12d, %edi
    f491:      	subl	%esi, %edi
    f493:      	movl	%edi, 0x50(%rsp)
    f497:      	subq	%rsi, %rax
    f49a:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    f4a0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f4a6:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    f4ac:      	cmpl	%r15d, %r12d
    f4af:      	jbe	0xf4b5 <generic_rawtp_path+0x43b5>
    f4b1:      	movb	$0x2f, (%rbx,%rax)
    f4b5:      	xorl	%edi, %edi
    f4b7:      	cmpl	%r15d, %r12d
    f4ba:      	seta	%dil
    f4be:      	movzbl	%cl, %esi
    f4c1:      	addq	%rax, %rbx
    f4c4:      	addq	%rbx, %rdi
    f4c7:      	movl	$0x4, %eax
    f4cc:      	callq	*%rax
    f4ce:      	movq	%rbx, 0x48(%rsp)
    f4d3:      	cmpl	%r15d, %r12d
    f4d6:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    f4dc:      	movq	0x8(%rsp), %r12
    f4e1:      	movq	%r12, 0x30(%rsp)
    f4e6:      	movq	0x38(%rsp), %rdx
    f4eb:      	movq	0x40(%rsp), %r15
    f4f0:      	jmp	0xf543 <generic_rawtp_path+0x4443>
    f4f2:      	leaq	0x10(%r15), %rdx
    f4f6:      	movl	$0x4, %eax
    f4fb:      	movq	%rbp, %rdi
    f4fe:      	movl	$0x8, %esi
    f503:      	callq	*%rax
    f505:      	movq	0x40(%rsp), %rax
    f50a:      	cmpq	(%rsp), %rax
    f50e:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    f514:      	addq	$0x18, %r15
    f518:      	movl	$0x4, %eax
    f51d:      	leaq	0x30(%rsp), %rdi
    f522:      	movl	$0x8, %esi
    f527:      	movq	%r15, %rdx
    f52a:      	callq	*%rax
    f52c:      	movq	(%rsp), %r15
    f530:      	movq	%r15, 0x40(%rsp)
    f535:      	leaq	0x20(%r15), %rdx
    f539:      	movq	%rdx, 0x38(%rsp)
    f53e:      	movq	0x30(%rsp), %r12
    f543:      	cmpq	0x18(%rsp), %r12
    f548:      	jne	0xf555 <generic_rawtp_path+0x4455>
    f54a:      	cmpq	0x20(%rsp), %rdx
    f54f:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    f555:      	movl	$0x4, %eax
    f55a:      	leaq	0x10(%rsp), %rdi
    f55f:      	movl	$0x8, %esi
    f564:      	callq	*%rax
    f566:      	cmpq	0x10(%rsp), %r12
    f56b:      	je	0xf663 <generic_rawtp_path+0x4563>
    f571:      	leaq	0x18(%r12), %rbx
    f576:      	movl	$0x4, %eax
    f57b:      	movq	%rbp, %rdi
    f57e:      	movl	$0x8, %esi
    f583:      	movq	%rbx, %rdx
    f586:      	callq	*%rax
    f588:      	cmpq	%r12, (%rsp)
    f58c:      	je	0xf663 <generic_rawtp_path+0x4563>
    f592:      	movl	$0x4, %eax
    f597:      	leaq	0x8(%rsp), %rdi
    f59c:      	movl	$0x8, %esi
    f5a1:      	movq	%rbx, %rdx
    f5a4:      	callq	*%rax
    f5a6:      	addq	$0x20, %r12
    f5aa:      	movl	$0x4, %eax
    f5af:      	leaq	0x58(%rsp), %rdi
    f5b4:      	movl	$0x10, %ecx
    f5b9:      	movl	$0x10, %esi
    f5be:      	movq	%r12, %rdx
    f5c1:      	callq	*%rax
    f5c3:      	movq	0x28(%rsp), %rbx
    f5c8:      	movq	0x48(%rsp), %rax
    f5cd:      	movl	0x5c(%rsp), %r15d
    f5d2:      	subq	%rbx, %rax
    f5d5:      	movl	0x50(%rsp), %r12d
    f5da:      	movl	%r15d, %edx
    f5dd:      	subl	%r12d, %edx
    f5e0:      	movl	$0x0, %ecx
    f5e5:      	cmovbl	%ecx, %edx
    f5e8:      	addq	0x60(%rsp), %rdx
    f5ed:      	xorl	%esi, %esi
    f5ef:      	cmpl	%r15d, %r12d
    f5f2:      	seta	%sil
    f5f6:      	movl	%r15d, %ecx
    f5f9:      	cmovbl	%r12d, %ecx
    f5fd:      	addl	%ecx, %esi
    f5ff:      	movl	%r12d, %edi
    f602:      	subl	%esi, %edi
    f604:      	movl	%edi, 0x50(%rsp)
    f608:      	subq	%rsi, %rax
    f60b:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    f611:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f617:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    f61d:      	cmpl	%r15d, %r12d
    f620:      	jbe	0xf626 <generic_rawtp_path+0x4526>
    f622:      	movb	$0x2f, (%rbx,%rax)
    f626:      	xorl	%edi, %edi
    f628:      	cmpl	%r15d, %r12d
    f62b:      	seta	%dil
    f62f:      	movzbl	%cl, %esi
    f632:      	addq	%rax, %rbx
    f635:      	addq	%rbx, %rdi
    f638:      	movl	$0x4, %eax
    f63d:      	callq	*%rax
    f63f:      	movq	%rbx, 0x48(%rsp)
    f644:      	cmpl	%r15d, %r12d
    f647:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    f64d:      	movq	0x8(%rsp), %r12
    f652:      	movq	%r12, 0x30(%rsp)
    f657:      	movq	0x38(%rsp), %rdx
    f65c:      	movq	0x40(%rsp), %r15
    f661:      	jmp	0xf6b4 <generic_rawtp_path+0x45b4>
    f663:      	leaq	0x10(%r15), %rdx
    f667:      	movl	$0x4, %eax
    f66c:      	movq	%rbp, %rdi
    f66f:      	movl	$0x8, %esi
    f674:      	callq	*%rax
    f676:      	movq	0x40(%rsp), %rax
    f67b:      	cmpq	(%rsp), %rax
    f67f:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    f685:      	addq	$0x18, %r15
    f689:      	movl	$0x4, %eax
    f68e:      	leaq	0x30(%rsp), %rdi
    f693:      	movl	$0x8, %esi
    f698:      	movq	%r15, %rdx
    f69b:      	callq	*%rax
    f69d:      	movq	(%rsp), %r15
    f6a1:      	movq	%r15, 0x40(%rsp)
    f6a6:      	leaq	0x20(%r15), %rdx
    f6aa:      	movq	%rdx, 0x38(%rsp)
    f6af:      	movq	0x30(%rsp), %r12
    f6b4:      	cmpq	0x18(%rsp), %r12
    f6b9:      	jne	0xf6c6 <generic_rawtp_path+0x45c6>
    f6bb:      	cmpq	0x20(%rsp), %rdx
    f6c0:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    f6c6:      	movl	$0x4, %eax
    f6cb:      	leaq	0x10(%rsp), %rdi
    f6d0:      	movl	$0x8, %esi
    f6d5:      	callq	*%rax
    f6d7:      	cmpq	0x10(%rsp), %r12
    f6dc:      	je	0xf7d4 <generic_rawtp_path+0x46d4>
    f6e2:      	leaq	0x18(%r12), %rbx
    f6e7:      	movl	$0x4, %eax
    f6ec:      	movq	%rbp, %rdi
    f6ef:      	movl	$0x8, %esi
    f6f4:      	movq	%rbx, %rdx
    f6f7:      	callq	*%rax
    f6f9:      	cmpq	%r12, (%rsp)
    f6fd:      	je	0xf7d4 <generic_rawtp_path+0x46d4>
    f703:      	movl	$0x4, %eax
    f708:      	leaq	0x8(%rsp), %rdi
    f70d:      	movl	$0x8, %esi
    f712:      	movq	%rbx, %rdx
    f715:      	callq	*%rax
    f717:      	addq	$0x20, %r12
    f71b:      	movl	$0x4, %eax
    f720:      	leaq	0x58(%rsp), %rdi
    f725:      	movl	$0x10, %ecx
    f72a:      	movl	$0x10, %esi
    f72f:      	movq	%r12, %rdx
    f732:      	callq	*%rax
    f734:      	movq	0x28(%rsp), %rbx
    f739:      	movq	0x48(%rsp), %rax
    f73e:      	movl	0x5c(%rsp), %r15d
    f743:      	subq	%rbx, %rax
    f746:      	movl	0x50(%rsp), %r12d
    f74b:      	movl	%r15d, %edx
    f74e:      	subl	%r12d, %edx
    f751:      	movl	$0x0, %ecx
    f756:      	cmovbl	%ecx, %edx
    f759:      	addq	0x60(%rsp), %rdx
    f75e:      	xorl	%esi, %esi
    f760:      	cmpl	%r15d, %r12d
    f763:      	seta	%sil
    f767:      	movl	%r15d, %ecx
    f76a:      	cmovbl	%r12d, %ecx
    f76e:      	addl	%ecx, %esi
    f770:      	movl	%r12d, %edi
    f773:      	subl	%esi, %edi
    f775:      	movl	%edi, 0x50(%rsp)
    f779:      	subq	%rsi, %rax
    f77c:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    f782:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f788:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    f78e:      	cmpl	%r15d, %r12d
    f791:      	jbe	0xf797 <generic_rawtp_path+0x4697>
    f793:      	movb	$0x2f, (%rbx,%rax)
    f797:      	xorl	%edi, %edi
    f799:      	cmpl	%r15d, %r12d
    f79c:      	seta	%dil
    f7a0:      	movzbl	%cl, %esi
    f7a3:      	addq	%rax, %rbx
    f7a6:      	addq	%rbx, %rdi
    f7a9:      	movl	$0x4, %eax
    f7ae:      	callq	*%rax
    f7b0:      	movq	%rbx, 0x48(%rsp)
    f7b5:      	cmpl	%r15d, %r12d
    f7b8:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    f7be:      	movq	0x8(%rsp), %r12
    f7c3:      	movq	%r12, 0x30(%rsp)
    f7c8:      	movq	0x38(%rsp), %rdx
    f7cd:      	movq	0x40(%rsp), %r15
    f7d2:      	jmp	0xf825 <generic_rawtp_path+0x4725>
    f7d4:      	leaq	0x10(%r15), %rdx
    f7d8:      	movl	$0x4, %eax
    f7dd:      	movq	%rbp, %rdi
    f7e0:      	movl	$0x8, %esi
    f7e5:      	callq	*%rax
    f7e7:      	movq	0x40(%rsp), %rax
    f7ec:      	cmpq	(%rsp), %rax
    f7f0:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    f7f6:      	addq	$0x18, %r15
    f7fa:      	movl	$0x4, %eax
    f7ff:      	leaq	0x30(%rsp), %rdi
    f804:      	movl	$0x8, %esi
    f809:      	movq	%r15, %rdx
    f80c:      	callq	*%rax
    f80e:      	movq	(%rsp), %r15
    f812:      	movq	%r15, 0x40(%rsp)
    f817:      	leaq	0x20(%r15), %rdx
    f81b:      	movq	%rdx, 0x38(%rsp)
    f820:      	movq	0x30(%rsp), %r12
    f825:      	cmpq	0x18(%rsp), %r12
    f82a:      	jne	0xf837 <generic_rawtp_path+0x4737>
    f82c:      	cmpq	0x20(%rsp), %rdx
    f831:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    f837:      	movl	$0x4, %eax
    f83c:      	leaq	0x10(%rsp), %rdi
    f841:      	movl	$0x8, %esi
    f846:      	callq	*%rax
    f848:      	cmpq	0x10(%rsp), %r12
    f84d:      	je	0xf945 <generic_rawtp_path+0x4845>
    f853:      	leaq	0x18(%r12), %rbx
    f858:      	movl	$0x4, %eax
    f85d:      	movq	%rbp, %rdi
    f860:      	movl	$0x8, %esi
    f865:      	movq	%rbx, %rdx
    f868:      	callq	*%rax
    f86a:      	cmpq	%r12, (%rsp)
    f86e:      	je	0xf945 <generic_rawtp_path+0x4845>
    f874:      	movl	$0x4, %eax
    f879:      	leaq	0x8(%rsp), %rdi
    f87e:      	movl	$0x8, %esi
    f883:      	movq	%rbx, %rdx
    f886:      	callq	*%rax
    f888:      	addq	$0x20, %r12
    f88c:      	movl	$0x4, %eax
    f891:      	leaq	0x58(%rsp), %rdi
    f896:      	movl	$0x10, %ecx
    f89b:      	movl	$0x10, %esi
    f8a0:      	movq	%r12, %rdx
    f8a3:      	callq	*%rax
    f8a5:      	movq	0x28(%rsp), %rbx
    f8aa:      	movq	0x48(%rsp), %rax
    f8af:      	movl	0x5c(%rsp), %r15d
    f8b4:      	subq	%rbx, %rax
    f8b7:      	movl	0x50(%rsp), %r12d
    f8bc:      	movl	%r15d, %edx
    f8bf:      	subl	%r12d, %edx
    f8c2:      	movl	$0x0, %ecx
    f8c7:      	cmovbl	%ecx, %edx
    f8ca:      	addq	0x60(%rsp), %rdx
    f8cf:      	xorl	%esi, %esi
    f8d1:      	cmpl	%r15d, %r12d
    f8d4:      	seta	%sil
    f8d8:      	movl	%r15d, %ecx
    f8db:      	cmovbl	%r12d, %ecx
    f8df:      	addl	%ecx, %esi
    f8e1:      	movl	%r12d, %edi
    f8e4:      	subl	%esi, %edi
    f8e6:      	movl	%edi, 0x50(%rsp)
    f8ea:      	subq	%rsi, %rax
    f8ed:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    f8f3:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f8f9:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    f8ff:      	cmpl	%r15d, %r12d
    f902:      	jbe	0xf908 <generic_rawtp_path+0x4808>
    f904:      	movb	$0x2f, (%rbx,%rax)
    f908:      	xorl	%edi, %edi
    f90a:      	cmpl	%r15d, %r12d
    f90d:      	seta	%dil
    f911:      	movzbl	%cl, %esi
    f914:      	addq	%rax, %rbx
    f917:      	addq	%rbx, %rdi
    f91a:      	movl	$0x4, %eax
    f91f:      	callq	*%rax
    f921:      	movq	%rbx, 0x48(%rsp)
    f926:      	cmpl	%r15d, %r12d
    f929:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    f92f:      	movq	0x8(%rsp), %r12
    f934:      	movq	%r12, 0x30(%rsp)
    f939:      	movq	0x38(%rsp), %rdx
    f93e:      	movq	0x40(%rsp), %r15
    f943:      	jmp	0xf996 <generic_rawtp_path+0x4896>
    f945:      	leaq	0x10(%r15), %rdx
    f949:      	movl	$0x4, %eax
    f94e:      	movq	%rbp, %rdi
    f951:      	movl	$0x8, %esi
    f956:      	callq	*%rax
    f958:      	movq	0x40(%rsp), %rax
    f95d:      	cmpq	(%rsp), %rax
    f961:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    f967:      	addq	$0x18, %r15
    f96b:      	movl	$0x4, %eax
    f970:      	leaq	0x30(%rsp), %rdi
    f975:      	movl	$0x8, %esi
    f97a:      	movq	%r15, %rdx
    f97d:      	callq	*%rax
    f97f:      	movq	(%rsp), %r15
    f983:      	movq	%r15, 0x40(%rsp)
    f988:      	leaq	0x20(%r15), %rdx
    f98c:      	movq	%rdx, 0x38(%rsp)
    f991:      	movq	0x30(%rsp), %r12
    f996:      	cmpq	0x18(%rsp), %r12
    f99b:      	jne	0xf9a8 <generic_rawtp_path+0x48a8>
    f99d:      	cmpq	0x20(%rsp), %rdx
    f9a2:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    f9a8:      	movl	$0x4, %eax
    f9ad:      	leaq	0x10(%rsp), %rdi
    f9b2:      	movl	$0x8, %esi
    f9b7:      	callq	*%rax
    f9b9:      	cmpq	0x10(%rsp), %r12
    f9be:      	je	0xfab6 <generic_rawtp_path+0x49b6>
    f9c4:      	leaq	0x18(%r12), %rbx
    f9c9:      	movl	$0x4, %eax
    f9ce:      	movq	%rbp, %rdi
    f9d1:      	movl	$0x8, %esi
    f9d6:      	movq	%rbx, %rdx
    f9d9:      	callq	*%rax
    f9db:      	cmpq	%r12, (%rsp)
    f9df:      	je	0xfab6 <generic_rawtp_path+0x49b6>
    f9e5:      	movl	$0x4, %eax
    f9ea:      	leaq	0x8(%rsp), %rdi
    f9ef:      	movl	$0x8, %esi
    f9f4:      	movq	%rbx, %rdx
    f9f7:      	callq	*%rax
    f9f9:      	addq	$0x20, %r12
    f9fd:      	movl	$0x4, %eax
    fa02:      	leaq	0x58(%rsp), %rdi
    fa07:      	movl	$0x10, %ecx
    fa0c:      	movl	$0x10, %esi
    fa11:      	movq	%r12, %rdx
    fa14:      	callq	*%rax
    fa16:      	movq	0x28(%rsp), %rbx
    fa1b:      	movq	0x48(%rsp), %rax
    fa20:      	movl	0x5c(%rsp), %r15d
    fa25:      	subq	%rbx, %rax
    fa28:      	movl	0x50(%rsp), %r12d
    fa2d:      	movl	%r15d, %edx
    fa30:      	subl	%r12d, %edx
    fa33:      	movl	$0x0, %ecx
    fa38:      	cmovbl	%ecx, %edx
    fa3b:      	addq	0x60(%rsp), %rdx
    fa40:      	xorl	%esi, %esi
    fa42:      	cmpl	%r15d, %r12d
    fa45:      	seta	%sil
    fa49:      	movl	%r15d, %ecx
    fa4c:      	cmovbl	%r12d, %ecx
    fa50:      	addl	%ecx, %esi
    fa52:      	movl	%r12d, %edi
    fa55:      	subl	%esi, %edi
    fa57:      	movl	%edi, 0x50(%rsp)
    fa5b:      	subq	%rsi, %rax
    fa5e:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    fa64:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    fa6a:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    fa70:      	cmpl	%r15d, %r12d
    fa73:      	jbe	0xfa79 <generic_rawtp_path+0x4979>
    fa75:      	movb	$0x2f, (%rbx,%rax)
    fa79:      	xorl	%edi, %edi
    fa7b:      	cmpl	%r15d, %r12d
    fa7e:      	seta	%dil
    fa82:      	movzbl	%cl, %esi
    fa85:      	addq	%rax, %rbx
    fa88:      	addq	%rbx, %rdi
    fa8b:      	movl	$0x4, %eax
    fa90:      	callq	*%rax
    fa92:      	movq	%rbx, 0x48(%rsp)
    fa97:      	cmpl	%r15d, %r12d
    fa9a:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    faa0:      	movq	0x8(%rsp), %r12
    faa5:      	movq	%r12, 0x30(%rsp)
    faaa:      	movq	0x38(%rsp), %rdx
    faaf:      	movq	0x40(%rsp), %r15
    fab4:      	jmp	0xfb07 <generic_rawtp_path+0x4a07>
    fab6:      	leaq	0x10(%r15), %rdx
    faba:      	movl	$0x4, %eax
    fabf:      	movq	%rbp, %rdi
    fac2:      	movl	$0x8, %esi
    fac7:      	callq	*%rax
    fac9:      	movq	0x40(%rsp), %rax
    face:      	cmpq	(%rsp), %rax
    fad2:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    fad8:      	addq	$0x18, %r15
    fadc:      	movl	$0x4, %eax
    fae1:      	leaq	0x30(%rsp), %rdi
    fae6:      	movl	$0x8, %esi
    faeb:      	movq	%r15, %rdx
    faee:      	callq	*%rax
    faf0:      	movq	(%rsp), %r15
    faf4:      	movq	%r15, 0x40(%rsp)
    faf9:      	leaq	0x20(%r15), %rdx
    fafd:      	movq	%rdx, 0x38(%rsp)
    fb02:      	movq	0x30(%rsp), %r12
    fb07:      	cmpq	0x18(%rsp), %r12
    fb0c:      	jne	0xfb19 <generic_rawtp_path+0x4a19>
    fb0e:      	cmpq	0x20(%rsp), %rdx
    fb13:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    fb19:      	movl	$0x4, %eax
    fb1e:      	leaq	0x10(%rsp), %rdi
    fb23:      	movl	$0x8, %esi
    fb28:      	callq	*%rax
    fb2a:      	cmpq	0x10(%rsp), %r12
    fb2f:      	je	0xfc27 <generic_rawtp_path+0x4b27>
    fb35:      	leaq	0x18(%r12), %rbx
    fb3a:      	movl	$0x4, %eax
    fb3f:      	movq	%rbp, %rdi
    fb42:      	movl	$0x8, %esi
    fb47:      	movq	%rbx, %rdx
    fb4a:      	callq	*%rax
    fb4c:      	cmpq	%r12, (%rsp)
    fb50:      	je	0xfc27 <generic_rawtp_path+0x4b27>
    fb56:      	movl	$0x4, %eax
    fb5b:      	leaq	0x8(%rsp), %rdi
    fb60:      	movl	$0x8, %esi
    fb65:      	movq	%rbx, %rdx
    fb68:      	callq	*%rax
    fb6a:      	addq	$0x20, %r12
    fb6e:      	movl	$0x4, %eax
    fb73:      	leaq	0x58(%rsp), %rdi
    fb78:      	movl	$0x10, %ecx
    fb7d:      	movl	$0x10, %esi
    fb82:      	movq	%r12, %rdx
    fb85:      	callq	*%rax
    fb87:      	movq	0x28(%rsp), %rbx
    fb8c:      	movq	0x48(%rsp), %rax
    fb91:      	movl	0x5c(%rsp), %r15d
    fb96:      	subq	%rbx, %rax
    fb99:      	movl	0x50(%rsp), %r12d
    fb9e:      	movl	%r15d, %edx
    fba1:      	subl	%r12d, %edx
    fba4:      	movl	$0x0, %ecx
    fba9:      	cmovbl	%ecx, %edx
    fbac:      	addq	0x60(%rsp), %rdx
    fbb1:      	xorl	%esi, %esi
    fbb3:      	cmpl	%r15d, %r12d
    fbb6:      	seta	%sil
    fbba:      	movl	%r15d, %ecx
    fbbd:      	cmovbl	%r12d, %ecx
    fbc1:      	addl	%ecx, %esi
    fbc3:      	movl	%r12d, %edi
    fbc6:      	subl	%esi, %edi
    fbc8:      	movl	%edi, 0x50(%rsp)
    fbcc:      	subq	%rsi, %rax
    fbcf:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    fbd5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    fbdb:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    fbe1:      	cmpl	%r15d, %r12d
    fbe4:      	jbe	0xfbea <generic_rawtp_path+0x4aea>
    fbe6:      	movb	$0x2f, (%rbx,%rax)
    fbea:      	xorl	%edi, %edi
    fbec:      	cmpl	%r15d, %r12d
    fbef:      	seta	%dil
    fbf3:      	movzbl	%cl, %esi
    fbf6:      	addq	%rax, %rbx
    fbf9:      	addq	%rbx, %rdi
    fbfc:      	movl	$0x4, %eax
    fc01:      	callq	*%rax
    fc03:      	movq	%rbx, 0x48(%rsp)
    fc08:      	cmpl	%r15d, %r12d
    fc0b:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    fc11:      	movq	0x8(%rsp), %r12
    fc16:      	movq	%r12, 0x30(%rsp)
    fc1b:      	movq	0x38(%rsp), %rdx
    fc20:      	movq	0x40(%rsp), %r15
    fc25:      	jmp	0xfc78 <generic_rawtp_path+0x4b78>
    fc27:      	leaq	0x10(%r15), %rdx
    fc2b:      	movl	$0x4, %eax
    fc30:      	movq	%rbp, %rdi
    fc33:      	movl	$0x8, %esi
    fc38:      	callq	*%rax
    fc3a:      	movq	0x40(%rsp), %rax
    fc3f:      	cmpq	(%rsp), %rax
    fc43:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    fc49:      	addq	$0x18, %r15
    fc4d:      	movl	$0x4, %eax
    fc52:      	leaq	0x30(%rsp), %rdi
    fc57:      	movl	$0x8, %esi
    fc5c:      	movq	%r15, %rdx
    fc5f:      	callq	*%rax
    fc61:      	movq	(%rsp), %r15
    fc65:      	movq	%r15, 0x40(%rsp)
    fc6a:      	leaq	0x20(%r15), %rdx
    fc6e:      	movq	%rdx, 0x38(%rsp)
    fc73:      	movq	0x30(%rsp), %r12
    fc78:      	cmpq	0x18(%rsp), %r12
    fc7d:      	jne	0xfc8a <generic_rawtp_path+0x4b8a>
    fc7f:      	cmpq	0x20(%rsp), %rdx
    fc84:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    fc8a:      	movl	$0x4, %eax
    fc8f:      	leaq	0x10(%rsp), %rdi
    fc94:      	movl	$0x8, %esi
    fc99:      	callq	*%rax
    fc9b:      	cmpq	0x10(%rsp), %r12
    fca0:      	je	0xfd98 <generic_rawtp_path+0x4c98>
    fca6:      	leaq	0x18(%r12), %rbx
    fcab:      	movl	$0x4, %eax
    fcb0:      	movq	%rbp, %rdi
    fcb3:      	movl	$0x8, %esi
    fcb8:      	movq	%rbx, %rdx
    fcbb:      	callq	*%rax
    fcbd:      	cmpq	%r12, (%rsp)
    fcc1:      	je	0xfd98 <generic_rawtp_path+0x4c98>
    fcc7:      	movl	$0x4, %eax
    fccc:      	leaq	0x8(%rsp), %rdi
    fcd1:      	movl	$0x8, %esi
    fcd6:      	movq	%rbx, %rdx
    fcd9:      	callq	*%rax
    fcdb:      	addq	$0x20, %r12
    fcdf:      	movl	$0x4, %eax
    fce4:      	leaq	0x58(%rsp), %rdi
    fce9:      	movl	$0x10, %ecx
    fcee:      	movl	$0x10, %esi
    fcf3:      	movq	%r12, %rdx
    fcf6:      	callq	*%rax
    fcf8:      	movq	0x28(%rsp), %rbx
    fcfd:      	movq	0x48(%rsp), %rax
    fd02:      	movl	0x5c(%rsp), %r15d
    fd07:      	subq	%rbx, %rax
    fd0a:      	movl	0x50(%rsp), %r12d
    fd0f:      	movl	%r15d, %edx
    fd12:      	subl	%r12d, %edx
    fd15:      	movl	$0x0, %ecx
    fd1a:      	cmovbl	%ecx, %edx
    fd1d:      	addq	0x60(%rsp), %rdx
    fd22:      	xorl	%esi, %esi
    fd24:      	cmpl	%r15d, %r12d
    fd27:      	seta	%sil
    fd2b:      	movl	%r15d, %ecx
    fd2e:      	cmovbl	%r12d, %ecx
    fd32:      	addl	%ecx, %esi
    fd34:      	movl	%r12d, %edi
    fd37:      	subl	%esi, %edi
    fd39:      	movl	%edi, 0x50(%rsp)
    fd3d:      	subq	%rsi, %rax
    fd40:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    fd46:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    fd4c:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    fd52:      	cmpl	%r15d, %r12d
    fd55:      	jbe	0xfd5b <generic_rawtp_path+0x4c5b>
    fd57:      	movb	$0x2f, (%rbx,%rax)
    fd5b:      	xorl	%edi, %edi
    fd5d:      	cmpl	%r15d, %r12d
    fd60:      	seta	%dil
    fd64:      	movzbl	%cl, %esi
    fd67:      	addq	%rax, %rbx
    fd6a:      	addq	%rbx, %rdi
    fd6d:      	movl	$0x4, %eax
    fd72:      	callq	*%rax
    fd74:      	movq	%rbx, 0x48(%rsp)
    fd79:      	cmpl	%r15d, %r12d
    fd7c:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    fd82:      	movq	0x8(%rsp), %r12
    fd87:      	movq	%r12, 0x30(%rsp)
    fd8c:      	movq	0x38(%rsp), %rdx
    fd91:      	movq	0x40(%rsp), %r15
    fd96:      	jmp	0xfde9 <generic_rawtp_path+0x4ce9>
    fd98:      	leaq	0x10(%r15), %rdx
    fd9c:      	movl	$0x4, %eax
    fda1:      	movq	%rbp, %rdi
    fda4:      	movl	$0x8, %esi
    fda9:      	callq	*%rax
    fdab:      	movq	0x40(%rsp), %rax
    fdb0:      	cmpq	(%rsp), %rax
    fdb4:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    fdba:      	addq	$0x18, %r15
    fdbe:      	movl	$0x4, %eax
    fdc3:      	leaq	0x30(%rsp), %rdi
    fdc8:      	movl	$0x8, %esi
    fdcd:      	movq	%r15, %rdx
    fdd0:      	callq	*%rax
    fdd2:      	movq	(%rsp), %r15
    fdd6:      	movq	%r15, 0x40(%rsp)
    fddb:      	leaq	0x20(%r15), %rdx
    fddf:      	movq	%rdx, 0x38(%rsp)
    fde4:      	movq	0x30(%rsp), %r12
    fde9:      	cmpq	0x18(%rsp), %r12
    fdee:      	jne	0xfdfb <generic_rawtp_path+0x4cfb>
    fdf0:      	cmpq	0x20(%rsp), %rdx
    fdf5:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    fdfb:      	movl	$0x4, %eax
    fe00:      	leaq	0x10(%rsp), %rdi
    fe05:      	movl	$0x8, %esi
    fe0a:      	callq	*%rax
    fe0c:      	cmpq	0x10(%rsp), %r12
    fe11:      	je	0xff09 <generic_rawtp_path+0x4e09>
    fe17:      	leaq	0x18(%r12), %rbx
    fe1c:      	movl	$0x4, %eax
    fe21:      	movq	%rbp, %rdi
    fe24:      	movl	$0x8, %esi
    fe29:      	movq	%rbx, %rdx
    fe2c:      	callq	*%rax
    fe2e:      	cmpq	%r12, (%rsp)
    fe32:      	je	0xff09 <generic_rawtp_path+0x4e09>
    fe38:      	movl	$0x4, %eax
    fe3d:      	leaq	0x8(%rsp), %rdi
    fe42:      	movl	$0x8, %esi
    fe47:      	movq	%rbx, %rdx
    fe4a:      	callq	*%rax
    fe4c:      	addq	$0x20, %r12
    fe50:      	movl	$0x4, %eax
    fe55:      	leaq	0x58(%rsp), %rdi
    fe5a:      	movl	$0x10, %ecx
    fe5f:      	movl	$0x10, %esi
    fe64:      	movq	%r12, %rdx
    fe67:      	callq	*%rax
    fe69:      	movq	0x28(%rsp), %rbx
    fe6e:      	movq	0x48(%rsp), %rax
    fe73:      	movl	0x5c(%rsp), %r15d
    fe78:      	subq	%rbx, %rax
    fe7b:      	movl	0x50(%rsp), %r12d
    fe80:      	movl	%r15d, %edx
    fe83:      	subl	%r12d, %edx
    fe86:      	movl	$0x0, %ecx
    fe8b:      	cmovbl	%ecx, %edx
    fe8e:      	addq	0x60(%rsp), %rdx
    fe93:      	xorl	%esi, %esi
    fe95:      	cmpl	%r15d, %r12d
    fe98:      	seta	%sil
    fe9c:      	movl	%r15d, %ecx
    fe9f:      	cmovbl	%r12d, %ecx
    fea3:      	addl	%ecx, %esi
    fea5:      	movl	%r12d, %edi
    fea8:      	subl	%esi, %edi
    feaa:      	movl	%edi, 0x50(%rsp)
    feae:      	subq	%rsi, %rax
    feb1:      	jb	0x16b72 <generic_rawtp_path+0xba72>
    feb7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    febd:      	ja	0x16b72 <generic_rawtp_path+0xba72>
    fec3:      	cmpl	%r15d, %r12d
    fec6:      	jbe	0xfecc <generic_rawtp_path+0x4dcc>
    fec8:      	movb	$0x2f, (%rbx,%rax)
    fecc:      	xorl	%edi, %edi
    fece:      	cmpl	%r15d, %r12d
    fed1:      	seta	%dil
    fed5:      	movzbl	%cl, %esi
    fed8:      	addq	%rax, %rbx
    fedb:      	addq	%rbx, %rdi
    fede:      	movl	$0x4, %eax
    fee3:      	callq	*%rax
    fee5:      	movq	%rbx, 0x48(%rsp)
    feea:      	cmpl	%r15d, %r12d
    feed:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
    fef3:      	movq	0x8(%rsp), %r12
    fef8:      	movq	%r12, 0x30(%rsp)
    fefd:      	movq	0x38(%rsp), %rdx
    ff02:      	movq	0x40(%rsp), %r15
    ff07:      	jmp	0xff5a <generic_rawtp_path+0x4e5a>
    ff09:      	leaq	0x10(%r15), %rdx
    ff0d:      	movl	$0x4, %eax
    ff12:      	movq	%rbp, %rdi
    ff15:      	movl	$0x8, %esi
    ff1a:      	callq	*%rax
    ff1c:      	movq	0x40(%rsp), %rax
    ff21:      	cmpq	(%rsp), %rax
    ff25:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    ff2b:      	addq	$0x18, %r15
    ff2f:      	movl	$0x4, %eax
    ff34:      	leaq	0x30(%rsp), %rdi
    ff39:      	movl	$0x8, %esi
    ff3e:      	movq	%r15, %rdx
    ff41:      	callq	*%rax
    ff43:      	movq	(%rsp), %r15
    ff47:      	movq	%r15, 0x40(%rsp)
    ff4c:      	leaq	0x20(%r15), %rdx
    ff50:      	movq	%rdx, 0x38(%rsp)
    ff55:      	movq	0x30(%rsp), %r12
    ff5a:      	cmpq	0x18(%rsp), %r12
    ff5f:      	jne	0xff6c <generic_rawtp_path+0x4e6c>
    ff61:      	cmpq	0x20(%rsp), %rdx
    ff66:      	je	0x16b6d <generic_rawtp_path+0xba6d>
    ff6c:      	movl	$0x4, %eax
    ff71:      	leaq	0x10(%rsp), %rdi
    ff76:      	movl	$0x8, %esi
    ff7b:      	callq	*%rax
    ff7d:      	cmpq	0x10(%rsp), %r12
    ff82:      	je	0x1007a <generic_rawtp_path+0x4f7a>
    ff88:      	leaq	0x18(%r12), %rbx
    ff8d:      	movl	$0x4, %eax
    ff92:      	movq	%rbp, %rdi
    ff95:      	movl	$0x8, %esi
    ff9a:      	movq	%rbx, %rdx
    ff9d:      	callq	*%rax
    ff9f:      	cmpq	%r12, (%rsp)
    ffa3:      	je	0x1007a <generic_rawtp_path+0x4f7a>
    ffa9:      	movl	$0x4, %eax
    ffae:      	leaq	0x8(%rsp), %rdi
    ffb3:      	movl	$0x8, %esi
    ffb8:      	movq	%rbx, %rdx
    ffbb:      	callq	*%rax
    ffbd:      	addq	$0x20, %r12
    ffc1:      	movl	$0x4, %eax
    ffc6:      	leaq	0x58(%rsp), %rdi
    ffcb:      	movl	$0x10, %ecx
    ffd0:      	movl	$0x10, %esi
    ffd5:      	movq	%r12, %rdx
    ffd8:      	callq	*%rax
    ffda:      	movq	0x28(%rsp), %rbx
    ffdf:      	movq	0x48(%rsp), %rax
    ffe4:      	movl	0x5c(%rsp), %r15d
    ffe9:      	subq	%rbx, %rax
    ffec:      	movl	0x50(%rsp), %r12d
    fff1:      	movl	%r15d, %edx
    fff4:      	subl	%r12d, %edx
    fff7:      	movl	$0x0, %ecx
    fffc:      	cmovbl	%ecx, %edx
    ffff:      	addq	0x60(%rsp), %rdx
   10004:      	xorl	%esi, %esi
   10006:      	cmpl	%r15d, %r12d
   10009:      	seta	%sil
   1000d:      	movl	%r15d, %ecx
   10010:      	cmovbl	%r12d, %ecx
   10014:      	addl	%ecx, %esi
   10016:      	movl	%r12d, %edi
   10019:      	subl	%esi, %edi
   1001b:      	movl	%edi, 0x50(%rsp)
   1001f:      	subq	%rsi, %rax
   10022:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   10028:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1002e:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   10034:      	cmpl	%r15d, %r12d
   10037:      	jbe	0x1003d <generic_rawtp_path+0x4f3d>
   10039:      	movb	$0x2f, (%rbx,%rax)
   1003d:      	xorl	%edi, %edi
   1003f:      	cmpl	%r15d, %r12d
   10042:      	seta	%dil
   10046:      	movzbl	%cl, %esi
   10049:      	addq	%rax, %rbx
   1004c:      	addq	%rbx, %rdi
   1004f:      	movl	$0x4, %eax
   10054:      	callq	*%rax
   10056:      	movq	%rbx, 0x48(%rsp)
   1005b:      	cmpl	%r15d, %r12d
   1005e:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   10064:      	movq	0x8(%rsp), %r12
   10069:      	movq	%r12, 0x30(%rsp)
   1006e:      	movq	0x38(%rsp), %rdx
   10073:      	movq	0x40(%rsp), %r15
   10078:      	jmp	0x100cb <generic_rawtp_path+0x4fcb>
   1007a:      	leaq	0x10(%r15), %rdx
   1007e:      	movl	$0x4, %eax
   10083:      	movq	%rbp, %rdi
   10086:      	movl	$0x8, %esi
   1008b:      	callq	*%rax
   1008d:      	movq	0x40(%rsp), %rax
   10092:      	cmpq	(%rsp), %rax
   10096:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   1009c:      	addq	$0x18, %r15
   100a0:      	movl	$0x4, %eax
   100a5:      	leaq	0x30(%rsp), %rdi
   100aa:      	movl	$0x8, %esi
   100af:      	movq	%r15, %rdx
   100b2:      	callq	*%rax
   100b4:      	movq	(%rsp), %r15
   100b8:      	movq	%r15, 0x40(%rsp)
   100bd:      	leaq	0x20(%r15), %rdx
   100c1:      	movq	%rdx, 0x38(%rsp)
   100c6:      	movq	0x30(%rsp), %r12
   100cb:      	cmpq	0x18(%rsp), %r12
   100d0:      	jne	0x100dd <generic_rawtp_path+0x4fdd>
   100d2:      	cmpq	0x20(%rsp), %rdx
   100d7:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   100dd:      	movl	$0x4, %eax
   100e2:      	leaq	0x10(%rsp), %rdi
   100e7:      	movl	$0x8, %esi
   100ec:      	callq	*%rax
   100ee:      	cmpq	0x10(%rsp), %r12
   100f3:      	je	0x101eb <generic_rawtp_path+0x50eb>
   100f9:      	leaq	0x18(%r12), %rbx
   100fe:      	movl	$0x4, %eax
   10103:      	movq	%rbp, %rdi
   10106:      	movl	$0x8, %esi
   1010b:      	movq	%rbx, %rdx
   1010e:      	callq	*%rax
   10110:      	cmpq	%r12, (%rsp)
   10114:      	je	0x101eb <generic_rawtp_path+0x50eb>
   1011a:      	movl	$0x4, %eax
   1011f:      	leaq	0x8(%rsp), %rdi
   10124:      	movl	$0x8, %esi
   10129:      	movq	%rbx, %rdx
   1012c:      	callq	*%rax
   1012e:      	addq	$0x20, %r12
   10132:      	movl	$0x4, %eax
   10137:      	leaq	0x58(%rsp), %rdi
   1013c:      	movl	$0x10, %ecx
   10141:      	movl	$0x10, %esi
   10146:      	movq	%r12, %rdx
   10149:      	callq	*%rax
   1014b:      	movq	0x28(%rsp), %rbx
   10150:      	movq	0x48(%rsp), %rax
   10155:      	movl	0x5c(%rsp), %r15d
   1015a:      	subq	%rbx, %rax
   1015d:      	movl	0x50(%rsp), %r12d
   10162:      	movl	%r15d, %edx
   10165:      	subl	%r12d, %edx
   10168:      	movl	$0x0, %ecx
   1016d:      	cmovbl	%ecx, %edx
   10170:      	addq	0x60(%rsp), %rdx
   10175:      	xorl	%esi, %esi
   10177:      	cmpl	%r15d, %r12d
   1017a:      	seta	%sil
   1017e:      	movl	%r15d, %ecx
   10181:      	cmovbl	%r12d, %ecx
   10185:      	addl	%ecx, %esi
   10187:      	movl	%r12d, %edi
   1018a:      	subl	%esi, %edi
   1018c:      	movl	%edi, 0x50(%rsp)
   10190:      	subq	%rsi, %rax
   10193:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   10199:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1019f:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   101a5:      	cmpl	%r15d, %r12d
   101a8:      	jbe	0x101ae <generic_rawtp_path+0x50ae>
   101aa:      	movb	$0x2f, (%rbx,%rax)
   101ae:      	xorl	%edi, %edi
   101b0:      	cmpl	%r15d, %r12d
   101b3:      	seta	%dil
   101b7:      	movzbl	%cl, %esi
   101ba:      	addq	%rax, %rbx
   101bd:      	addq	%rbx, %rdi
   101c0:      	movl	$0x4, %eax
   101c5:      	callq	*%rax
   101c7:      	movq	%rbx, 0x48(%rsp)
   101cc:      	cmpl	%r15d, %r12d
   101cf:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   101d5:      	movq	0x8(%rsp), %r12
   101da:      	movq	%r12, 0x30(%rsp)
   101df:      	movq	0x38(%rsp), %rdx
   101e4:      	movq	0x40(%rsp), %r15
   101e9:      	jmp	0x1023c <generic_rawtp_path+0x513c>
   101eb:      	leaq	0x10(%r15), %rdx
   101ef:      	movl	$0x4, %eax
   101f4:      	movq	%rbp, %rdi
   101f7:      	movl	$0x8, %esi
   101fc:      	callq	*%rax
   101fe:      	movq	0x40(%rsp), %rax
   10203:      	cmpq	(%rsp), %rax
   10207:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   1020d:      	addq	$0x18, %r15
   10211:      	movl	$0x4, %eax
   10216:      	leaq	0x30(%rsp), %rdi
   1021b:      	movl	$0x8, %esi
   10220:      	movq	%r15, %rdx
   10223:      	callq	*%rax
   10225:      	movq	(%rsp), %r15
   10229:      	movq	%r15, 0x40(%rsp)
   1022e:      	leaq	0x20(%r15), %rdx
   10232:      	movq	%rdx, 0x38(%rsp)
   10237:      	movq	0x30(%rsp), %r12
   1023c:      	cmpq	0x18(%rsp), %r12
   10241:      	jne	0x1024e <generic_rawtp_path+0x514e>
   10243:      	cmpq	0x20(%rsp), %rdx
   10248:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   1024e:      	movl	$0x4, %eax
   10253:      	leaq	0x10(%rsp), %rdi
   10258:      	movl	$0x8, %esi
   1025d:      	callq	*%rax
   1025f:      	cmpq	0x10(%rsp), %r12
   10264:      	je	0x1035c <generic_rawtp_path+0x525c>
   1026a:      	leaq	0x18(%r12), %rbx
   1026f:      	movl	$0x4, %eax
   10274:      	movq	%rbp, %rdi
   10277:      	movl	$0x8, %esi
   1027c:      	movq	%rbx, %rdx
   1027f:      	callq	*%rax
   10281:      	cmpq	%r12, (%rsp)
   10285:      	je	0x1035c <generic_rawtp_path+0x525c>
   1028b:      	movl	$0x4, %eax
   10290:      	leaq	0x8(%rsp), %rdi
   10295:      	movl	$0x8, %esi
   1029a:      	movq	%rbx, %rdx
   1029d:      	callq	*%rax
   1029f:      	addq	$0x20, %r12
   102a3:      	movl	$0x4, %eax
   102a8:      	leaq	0x58(%rsp), %rdi
   102ad:      	movl	$0x10, %ecx
   102b2:      	movl	$0x10, %esi
   102b7:      	movq	%r12, %rdx
   102ba:      	callq	*%rax
   102bc:      	movq	0x28(%rsp), %rbx
   102c1:      	movq	0x48(%rsp), %rax
   102c6:      	movl	0x5c(%rsp), %r15d
   102cb:      	subq	%rbx, %rax
   102ce:      	movl	0x50(%rsp), %r12d
   102d3:      	movl	%r15d, %edx
   102d6:      	subl	%r12d, %edx
   102d9:      	movl	$0x0, %ecx
   102de:      	cmovbl	%ecx, %edx
   102e1:      	addq	0x60(%rsp), %rdx
   102e6:      	xorl	%esi, %esi
   102e8:      	cmpl	%r15d, %r12d
   102eb:      	seta	%sil
   102ef:      	movl	%r15d, %ecx
   102f2:      	cmovbl	%r12d, %ecx
   102f6:      	addl	%ecx, %esi
   102f8:      	movl	%r12d, %edi
   102fb:      	subl	%esi, %edi
   102fd:      	movl	%edi, 0x50(%rsp)
   10301:      	subq	%rsi, %rax
   10304:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   1030a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10310:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   10316:      	cmpl	%r15d, %r12d
   10319:      	jbe	0x1031f <generic_rawtp_path+0x521f>
   1031b:      	movb	$0x2f, (%rbx,%rax)
   1031f:      	xorl	%edi, %edi
   10321:      	cmpl	%r15d, %r12d
   10324:      	seta	%dil
   10328:      	movzbl	%cl, %esi
   1032b:      	addq	%rax, %rbx
   1032e:      	addq	%rbx, %rdi
   10331:      	movl	$0x4, %eax
   10336:      	callq	*%rax
   10338:      	movq	%rbx, 0x48(%rsp)
   1033d:      	cmpl	%r15d, %r12d
   10340:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   10346:      	movq	0x8(%rsp), %r12
   1034b:      	movq	%r12, 0x30(%rsp)
   10350:      	movq	0x38(%rsp), %rdx
   10355:      	movq	0x40(%rsp), %r15
   1035a:      	jmp	0x103ad <generic_rawtp_path+0x52ad>
   1035c:      	leaq	0x10(%r15), %rdx
   10360:      	movl	$0x4, %eax
   10365:      	movq	%rbp, %rdi
   10368:      	movl	$0x8, %esi
   1036d:      	callq	*%rax
   1036f:      	movq	0x40(%rsp), %rax
   10374:      	cmpq	(%rsp), %rax
   10378:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   1037e:      	addq	$0x18, %r15
   10382:      	movl	$0x4, %eax
   10387:      	leaq	0x30(%rsp), %rdi
   1038c:      	movl	$0x8, %esi
   10391:      	movq	%r15, %rdx
   10394:      	callq	*%rax
   10396:      	movq	(%rsp), %r15
   1039a:      	movq	%r15, 0x40(%rsp)
   1039f:      	leaq	0x20(%r15), %rdx
   103a3:      	movq	%rdx, 0x38(%rsp)
   103a8:      	movq	0x30(%rsp), %r12
   103ad:      	cmpq	0x18(%rsp), %r12
   103b2:      	jne	0x103bf <generic_rawtp_path+0x52bf>
   103b4:      	cmpq	0x20(%rsp), %rdx
   103b9:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   103bf:      	movl	$0x4, %eax
   103c4:      	leaq	0x10(%rsp), %rdi
   103c9:      	movl	$0x8, %esi
   103ce:      	callq	*%rax
   103d0:      	cmpq	0x10(%rsp), %r12
   103d5:      	je	0x104cd <generic_rawtp_path+0x53cd>
   103db:      	leaq	0x18(%r12), %rbx
   103e0:      	movl	$0x4, %eax
   103e5:      	movq	%rbp, %rdi
   103e8:      	movl	$0x8, %esi
   103ed:      	movq	%rbx, %rdx
   103f0:      	callq	*%rax
   103f2:      	cmpq	%r12, (%rsp)
   103f6:      	je	0x104cd <generic_rawtp_path+0x53cd>
   103fc:      	movl	$0x4, %eax
   10401:      	leaq	0x8(%rsp), %rdi
   10406:      	movl	$0x8, %esi
   1040b:      	movq	%rbx, %rdx
   1040e:      	callq	*%rax
   10410:      	addq	$0x20, %r12
   10414:      	movl	$0x4, %eax
   10419:      	leaq	0x58(%rsp), %rdi
   1041e:      	movl	$0x10, %ecx
   10423:      	movl	$0x10, %esi
   10428:      	movq	%r12, %rdx
   1042b:      	callq	*%rax
   1042d:      	movq	0x28(%rsp), %rbx
   10432:      	movq	0x48(%rsp), %rax
   10437:      	movl	0x5c(%rsp), %r15d
   1043c:      	subq	%rbx, %rax
   1043f:      	movl	0x50(%rsp), %r12d
   10444:      	movl	%r15d, %edx
   10447:      	subl	%r12d, %edx
   1044a:      	movl	$0x0, %ecx
   1044f:      	cmovbl	%ecx, %edx
   10452:      	addq	0x60(%rsp), %rdx
   10457:      	xorl	%esi, %esi
   10459:      	cmpl	%r15d, %r12d
   1045c:      	seta	%sil
   10460:      	movl	%r15d, %ecx
   10463:      	cmovbl	%r12d, %ecx
   10467:      	addl	%ecx, %esi
   10469:      	movl	%r12d, %edi
   1046c:      	subl	%esi, %edi
   1046e:      	movl	%edi, 0x50(%rsp)
   10472:      	subq	%rsi, %rax
   10475:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   1047b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10481:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   10487:      	cmpl	%r15d, %r12d
   1048a:      	jbe	0x10490 <generic_rawtp_path+0x5390>
   1048c:      	movb	$0x2f, (%rbx,%rax)
   10490:      	xorl	%edi, %edi
   10492:      	cmpl	%r15d, %r12d
   10495:      	seta	%dil
   10499:      	movzbl	%cl, %esi
   1049c:      	addq	%rax, %rbx
   1049f:      	addq	%rbx, %rdi
   104a2:      	movl	$0x4, %eax
   104a7:      	callq	*%rax
   104a9:      	movq	%rbx, 0x48(%rsp)
   104ae:      	cmpl	%r15d, %r12d
   104b1:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   104b7:      	movq	0x8(%rsp), %r12
   104bc:      	movq	%r12, 0x30(%rsp)
   104c1:      	movq	0x38(%rsp), %rdx
   104c6:      	movq	0x40(%rsp), %r15
   104cb:      	jmp	0x1051e <generic_rawtp_path+0x541e>
   104cd:      	leaq	0x10(%r15), %rdx
   104d1:      	movl	$0x4, %eax
   104d6:      	movq	%rbp, %rdi
   104d9:      	movl	$0x8, %esi
   104de:      	callq	*%rax
   104e0:      	movq	0x40(%rsp), %rax
   104e5:      	cmpq	(%rsp), %rax
   104e9:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   104ef:      	addq	$0x18, %r15
   104f3:      	movl	$0x4, %eax
   104f8:      	leaq	0x30(%rsp), %rdi
   104fd:      	movl	$0x8, %esi
   10502:      	movq	%r15, %rdx
   10505:      	callq	*%rax
   10507:      	movq	(%rsp), %r15
   1050b:      	movq	%r15, 0x40(%rsp)
   10510:      	leaq	0x20(%r15), %rdx
   10514:      	movq	%rdx, 0x38(%rsp)
   10519:      	movq	0x30(%rsp), %r12
   1051e:      	cmpq	0x18(%rsp), %r12
   10523:      	jne	0x10530 <generic_rawtp_path+0x5430>
   10525:      	cmpq	0x20(%rsp), %rdx
   1052a:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   10530:      	movl	$0x4, %eax
   10535:      	leaq	0x10(%rsp), %rdi
   1053a:      	movl	$0x8, %esi
   1053f:      	callq	*%rax
   10541:      	cmpq	0x10(%rsp), %r12
   10546:      	je	0x1063e <generic_rawtp_path+0x553e>
   1054c:      	leaq	0x18(%r12), %rbx
   10551:      	movl	$0x4, %eax
   10556:      	movq	%rbp, %rdi
   10559:      	movl	$0x8, %esi
   1055e:      	movq	%rbx, %rdx
   10561:      	callq	*%rax
   10563:      	cmpq	%r12, (%rsp)
   10567:      	je	0x1063e <generic_rawtp_path+0x553e>
   1056d:      	movl	$0x4, %eax
   10572:      	leaq	0x8(%rsp), %rdi
   10577:      	movl	$0x8, %esi
   1057c:      	movq	%rbx, %rdx
   1057f:      	callq	*%rax
   10581:      	addq	$0x20, %r12
   10585:      	movl	$0x4, %eax
   1058a:      	leaq	0x58(%rsp), %rdi
   1058f:      	movl	$0x10, %ecx
   10594:      	movl	$0x10, %esi
   10599:      	movq	%r12, %rdx
   1059c:      	callq	*%rax
   1059e:      	movq	0x28(%rsp), %rbx
   105a3:      	movq	0x48(%rsp), %rax
   105a8:      	movl	0x5c(%rsp), %r15d
   105ad:      	subq	%rbx, %rax
   105b0:      	movl	0x50(%rsp), %r12d
   105b5:      	movl	%r15d, %edx
   105b8:      	subl	%r12d, %edx
   105bb:      	movl	$0x0, %ecx
   105c0:      	cmovbl	%ecx, %edx
   105c3:      	addq	0x60(%rsp), %rdx
   105c8:      	xorl	%esi, %esi
   105ca:      	cmpl	%r15d, %r12d
   105cd:      	seta	%sil
   105d1:      	movl	%r15d, %ecx
   105d4:      	cmovbl	%r12d, %ecx
   105d8:      	addl	%ecx, %esi
   105da:      	movl	%r12d, %edi
   105dd:      	subl	%esi, %edi
   105df:      	movl	%edi, 0x50(%rsp)
   105e3:      	subq	%rsi, %rax
   105e6:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   105ec:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   105f2:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   105f8:      	cmpl	%r15d, %r12d
   105fb:      	jbe	0x10601 <generic_rawtp_path+0x5501>
   105fd:      	movb	$0x2f, (%rbx,%rax)
   10601:      	xorl	%edi, %edi
   10603:      	cmpl	%r15d, %r12d
   10606:      	seta	%dil
   1060a:      	movzbl	%cl, %esi
   1060d:      	addq	%rax, %rbx
   10610:      	addq	%rbx, %rdi
   10613:      	movl	$0x4, %eax
   10618:      	callq	*%rax
   1061a:      	movq	%rbx, 0x48(%rsp)
   1061f:      	cmpl	%r15d, %r12d
   10622:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   10628:      	movq	0x8(%rsp), %r12
   1062d:      	movq	%r12, 0x30(%rsp)
   10632:      	movq	0x38(%rsp), %rdx
   10637:      	movq	0x40(%rsp), %r15
   1063c:      	jmp	0x1068f <generic_rawtp_path+0x558f>
   1063e:      	leaq	0x10(%r15), %rdx
   10642:      	movl	$0x4, %eax
   10647:      	movq	%rbp, %rdi
   1064a:      	movl	$0x8, %esi
   1064f:      	callq	*%rax
   10651:      	movq	0x40(%rsp), %rax
   10656:      	cmpq	(%rsp), %rax
   1065a:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   10660:      	addq	$0x18, %r15
   10664:      	movl	$0x4, %eax
   10669:      	leaq	0x30(%rsp), %rdi
   1066e:      	movl	$0x8, %esi
   10673:      	movq	%r15, %rdx
   10676:      	callq	*%rax
   10678:      	movq	(%rsp), %r15
   1067c:      	movq	%r15, 0x40(%rsp)
   10681:      	leaq	0x20(%r15), %rdx
   10685:      	movq	%rdx, 0x38(%rsp)
   1068a:      	movq	0x30(%rsp), %r12
   1068f:      	cmpq	0x18(%rsp), %r12
   10694:      	jne	0x106a1 <generic_rawtp_path+0x55a1>
   10696:      	cmpq	0x20(%rsp), %rdx
   1069b:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   106a1:      	movl	$0x4, %eax
   106a6:      	leaq	0x10(%rsp), %rdi
   106ab:      	movl	$0x8, %esi
   106b0:      	callq	*%rax
   106b2:      	cmpq	0x10(%rsp), %r12
   106b7:      	je	0x107af <generic_rawtp_path+0x56af>
   106bd:      	leaq	0x18(%r12), %rbx
   106c2:      	movl	$0x4, %eax
   106c7:      	movq	%rbp, %rdi
   106ca:      	movl	$0x8, %esi
   106cf:      	movq	%rbx, %rdx
   106d2:      	callq	*%rax
   106d4:      	cmpq	%r12, (%rsp)
   106d8:      	je	0x107af <generic_rawtp_path+0x56af>
   106de:      	movl	$0x4, %eax
   106e3:      	leaq	0x8(%rsp), %rdi
   106e8:      	movl	$0x8, %esi
   106ed:      	movq	%rbx, %rdx
   106f0:      	callq	*%rax
   106f2:      	addq	$0x20, %r12
   106f6:      	movl	$0x4, %eax
   106fb:      	leaq	0x58(%rsp), %rdi
   10700:      	movl	$0x10, %ecx
   10705:      	movl	$0x10, %esi
   1070a:      	movq	%r12, %rdx
   1070d:      	callq	*%rax
   1070f:      	movq	0x28(%rsp), %rbx
   10714:      	movq	0x48(%rsp), %rax
   10719:      	movl	0x5c(%rsp), %r15d
   1071e:      	subq	%rbx, %rax
   10721:      	movl	0x50(%rsp), %r12d
   10726:      	movl	%r15d, %edx
   10729:      	subl	%r12d, %edx
   1072c:      	movl	$0x0, %ecx
   10731:      	cmovbl	%ecx, %edx
   10734:      	addq	0x60(%rsp), %rdx
   10739:      	xorl	%esi, %esi
   1073b:      	cmpl	%r15d, %r12d
   1073e:      	seta	%sil
   10742:      	movl	%r15d, %ecx
   10745:      	cmovbl	%r12d, %ecx
   10749:      	addl	%ecx, %esi
   1074b:      	movl	%r12d, %edi
   1074e:      	subl	%esi, %edi
   10750:      	movl	%edi, 0x50(%rsp)
   10754:      	subq	%rsi, %rax
   10757:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   1075d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10763:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   10769:      	cmpl	%r15d, %r12d
   1076c:      	jbe	0x10772 <generic_rawtp_path+0x5672>
   1076e:      	movb	$0x2f, (%rbx,%rax)
   10772:      	xorl	%edi, %edi
   10774:      	cmpl	%r15d, %r12d
   10777:      	seta	%dil
   1077b:      	movzbl	%cl, %esi
   1077e:      	addq	%rax, %rbx
   10781:      	addq	%rbx, %rdi
   10784:      	movl	$0x4, %eax
   10789:      	callq	*%rax
   1078b:      	movq	%rbx, 0x48(%rsp)
   10790:      	cmpl	%r15d, %r12d
   10793:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   10799:      	movq	0x8(%rsp), %r12
   1079e:      	movq	%r12, 0x30(%rsp)
   107a3:      	movq	0x38(%rsp), %rdx
   107a8:      	movq	0x40(%rsp), %r15
   107ad:      	jmp	0x10800 <generic_rawtp_path+0x5700>
   107af:      	leaq	0x10(%r15), %rdx
   107b3:      	movl	$0x4, %eax
   107b8:      	movq	%rbp, %rdi
   107bb:      	movl	$0x8, %esi
   107c0:      	callq	*%rax
   107c2:      	movq	0x40(%rsp), %rax
   107c7:      	cmpq	(%rsp), %rax
   107cb:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   107d1:      	addq	$0x18, %r15
   107d5:      	movl	$0x4, %eax
   107da:      	leaq	0x30(%rsp), %rdi
   107df:      	movl	$0x8, %esi
   107e4:      	movq	%r15, %rdx
   107e7:      	callq	*%rax
   107e9:      	movq	(%rsp), %r15
   107ed:      	movq	%r15, 0x40(%rsp)
   107f2:      	leaq	0x20(%r15), %rdx
   107f6:      	movq	%rdx, 0x38(%rsp)
   107fb:      	movq	0x30(%rsp), %r12
   10800:      	cmpq	0x18(%rsp), %r12
   10805:      	jne	0x10812 <generic_rawtp_path+0x5712>
   10807:      	cmpq	0x20(%rsp), %rdx
   1080c:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   10812:      	movl	$0x4, %eax
   10817:      	leaq	0x10(%rsp), %rdi
   1081c:      	movl	$0x8, %esi
   10821:      	callq	*%rax
   10823:      	cmpq	0x10(%rsp), %r12
   10828:      	je	0x10920 <generic_rawtp_path+0x5820>
   1082e:      	leaq	0x18(%r12), %rbx
   10833:      	movl	$0x4, %eax
   10838:      	movq	%rbp, %rdi
   1083b:      	movl	$0x8, %esi
   10840:      	movq	%rbx, %rdx
   10843:      	callq	*%rax
   10845:      	cmpq	%r12, (%rsp)
   10849:      	je	0x10920 <generic_rawtp_path+0x5820>
   1084f:      	movl	$0x4, %eax
   10854:      	leaq	0x8(%rsp), %rdi
   10859:      	movl	$0x8, %esi
   1085e:      	movq	%rbx, %rdx
   10861:      	callq	*%rax
   10863:      	addq	$0x20, %r12
   10867:      	movl	$0x4, %eax
   1086c:      	leaq	0x58(%rsp), %rdi
   10871:      	movl	$0x10, %ecx
   10876:      	movl	$0x10, %esi
   1087b:      	movq	%r12, %rdx
   1087e:      	callq	*%rax
   10880:      	movq	0x28(%rsp), %rbx
   10885:      	movq	0x48(%rsp), %rax
   1088a:      	movl	0x5c(%rsp), %r15d
   1088f:      	subq	%rbx, %rax
   10892:      	movl	0x50(%rsp), %r12d
   10897:      	movl	%r15d, %edx
   1089a:      	subl	%r12d, %edx
   1089d:      	movl	$0x0, %ecx
   108a2:      	cmovbl	%ecx, %edx
   108a5:      	addq	0x60(%rsp), %rdx
   108aa:      	xorl	%esi, %esi
   108ac:      	cmpl	%r15d, %r12d
   108af:      	seta	%sil
   108b3:      	movl	%r15d, %ecx
   108b6:      	cmovbl	%r12d, %ecx
   108ba:      	addl	%ecx, %esi
   108bc:      	movl	%r12d, %edi
   108bf:      	subl	%esi, %edi
   108c1:      	movl	%edi, 0x50(%rsp)
   108c5:      	subq	%rsi, %rax
   108c8:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   108ce:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   108d4:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   108da:      	cmpl	%r15d, %r12d
   108dd:      	jbe	0x108e3 <generic_rawtp_path+0x57e3>
   108df:      	movb	$0x2f, (%rbx,%rax)
   108e3:      	xorl	%edi, %edi
   108e5:      	cmpl	%r15d, %r12d
   108e8:      	seta	%dil
   108ec:      	movzbl	%cl, %esi
   108ef:      	addq	%rax, %rbx
   108f2:      	addq	%rbx, %rdi
   108f5:      	movl	$0x4, %eax
   108fa:      	callq	*%rax
   108fc:      	movq	%rbx, 0x48(%rsp)
   10901:      	cmpl	%r15d, %r12d
   10904:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   1090a:      	movq	0x8(%rsp), %r12
   1090f:      	movq	%r12, 0x30(%rsp)
   10914:      	movq	0x38(%rsp), %rdx
   10919:      	movq	0x40(%rsp), %r15
   1091e:      	jmp	0x10971 <generic_rawtp_path+0x5871>
   10920:      	leaq	0x10(%r15), %rdx
   10924:      	movl	$0x4, %eax
   10929:      	movq	%rbp, %rdi
   1092c:      	movl	$0x8, %esi
   10931:      	callq	*%rax
   10933:      	movq	0x40(%rsp), %rax
   10938:      	cmpq	(%rsp), %rax
   1093c:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   10942:      	addq	$0x18, %r15
   10946:      	movl	$0x4, %eax
   1094b:      	leaq	0x30(%rsp), %rdi
   10950:      	movl	$0x8, %esi
   10955:      	movq	%r15, %rdx
   10958:      	callq	*%rax
   1095a:      	movq	(%rsp), %r15
   1095e:      	movq	%r15, 0x40(%rsp)
   10963:      	leaq	0x20(%r15), %rdx
   10967:      	movq	%rdx, 0x38(%rsp)
   1096c:      	movq	0x30(%rsp), %r12
   10971:      	cmpq	0x18(%rsp), %r12
   10976:      	jne	0x10983 <generic_rawtp_path+0x5883>
   10978:      	cmpq	0x20(%rsp), %rdx
   1097d:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   10983:      	movl	$0x4, %eax
   10988:      	leaq	0x10(%rsp), %rdi
   1098d:      	movl	$0x8, %esi
   10992:      	callq	*%rax
   10994:      	cmpq	0x10(%rsp), %r12
   10999:      	je	0x10a91 <generic_rawtp_path+0x5991>
   1099f:      	leaq	0x18(%r12), %rbx
   109a4:      	movl	$0x4, %eax
   109a9:      	movq	%rbp, %rdi
   109ac:      	movl	$0x8, %esi
   109b1:      	movq	%rbx, %rdx
   109b4:      	callq	*%rax
   109b6:      	cmpq	%r12, (%rsp)
   109ba:      	je	0x10a91 <generic_rawtp_path+0x5991>
   109c0:      	movl	$0x4, %eax
   109c5:      	leaq	0x8(%rsp), %rdi
   109ca:      	movl	$0x8, %esi
   109cf:      	movq	%rbx, %rdx
   109d2:      	callq	*%rax
   109d4:      	addq	$0x20, %r12
   109d8:      	movl	$0x4, %eax
   109dd:      	leaq	0x58(%rsp), %rdi
   109e2:      	movl	$0x10, %ecx
   109e7:      	movl	$0x10, %esi
   109ec:      	movq	%r12, %rdx
   109ef:      	callq	*%rax
   109f1:      	movq	0x28(%rsp), %rbx
   109f6:      	movq	0x48(%rsp), %rax
   109fb:      	movl	0x5c(%rsp), %r15d
   10a00:      	subq	%rbx, %rax
   10a03:      	movl	0x50(%rsp), %r12d
   10a08:      	movl	%r15d, %edx
   10a0b:      	subl	%r12d, %edx
   10a0e:      	movl	$0x0, %ecx
   10a13:      	cmovbl	%ecx, %edx
   10a16:      	addq	0x60(%rsp), %rdx
   10a1b:      	xorl	%esi, %esi
   10a1d:      	cmpl	%r15d, %r12d
   10a20:      	seta	%sil
   10a24:      	movl	%r15d, %ecx
   10a27:      	cmovbl	%r12d, %ecx
   10a2b:      	addl	%ecx, %esi
   10a2d:      	movl	%r12d, %edi
   10a30:      	subl	%esi, %edi
   10a32:      	movl	%edi, 0x50(%rsp)
   10a36:      	subq	%rsi, %rax
   10a39:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   10a3f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10a45:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   10a4b:      	cmpl	%r15d, %r12d
   10a4e:      	jbe	0x10a54 <generic_rawtp_path+0x5954>
   10a50:      	movb	$0x2f, (%rbx,%rax)
   10a54:      	xorl	%edi, %edi
   10a56:      	cmpl	%r15d, %r12d
   10a59:      	seta	%dil
   10a5d:      	movzbl	%cl, %esi
   10a60:      	addq	%rax, %rbx
   10a63:      	addq	%rbx, %rdi
   10a66:      	movl	$0x4, %eax
   10a6b:      	callq	*%rax
   10a6d:      	movq	%rbx, 0x48(%rsp)
   10a72:      	cmpl	%r15d, %r12d
   10a75:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   10a7b:      	movq	0x8(%rsp), %r12
   10a80:      	movq	%r12, 0x30(%rsp)
   10a85:      	movq	0x38(%rsp), %rdx
   10a8a:      	movq	0x40(%rsp), %r15
   10a8f:      	jmp	0x10ae2 <generic_rawtp_path+0x59e2>
   10a91:      	leaq	0x10(%r15), %rdx
   10a95:      	movl	$0x4, %eax
   10a9a:      	movq	%rbp, %rdi
   10a9d:      	movl	$0x8, %esi
   10aa2:      	callq	*%rax
   10aa4:      	movq	0x40(%rsp), %rax
   10aa9:      	cmpq	(%rsp), %rax
   10aad:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   10ab3:      	addq	$0x18, %r15
   10ab7:      	movl	$0x4, %eax
   10abc:      	leaq	0x30(%rsp), %rdi
   10ac1:      	movl	$0x8, %esi
   10ac6:      	movq	%r15, %rdx
   10ac9:      	callq	*%rax
   10acb:      	movq	(%rsp), %r15
   10acf:      	movq	%r15, 0x40(%rsp)
   10ad4:      	leaq	0x20(%r15), %rdx
   10ad8:      	movq	%rdx, 0x38(%rsp)
   10add:      	movq	0x30(%rsp), %r12
   10ae2:      	cmpq	0x18(%rsp), %r12
   10ae7:      	jne	0x10af4 <generic_rawtp_path+0x59f4>
   10ae9:      	cmpq	0x20(%rsp), %rdx
   10aee:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   10af4:      	movl	$0x4, %eax
   10af9:      	leaq	0x10(%rsp), %rdi
   10afe:      	movl	$0x8, %esi
   10b03:      	callq	*%rax
   10b05:      	cmpq	0x10(%rsp), %r12
   10b0a:      	je	0x10c02 <generic_rawtp_path+0x5b02>
   10b10:      	leaq	0x18(%r12), %rbx
   10b15:      	movl	$0x4, %eax
   10b1a:      	movq	%rbp, %rdi
   10b1d:      	movl	$0x8, %esi
   10b22:      	movq	%rbx, %rdx
   10b25:      	callq	*%rax
   10b27:      	cmpq	%r12, (%rsp)
   10b2b:      	je	0x10c02 <generic_rawtp_path+0x5b02>
   10b31:      	movl	$0x4, %eax
   10b36:      	leaq	0x8(%rsp), %rdi
   10b3b:      	movl	$0x8, %esi
   10b40:      	movq	%rbx, %rdx
   10b43:      	callq	*%rax
   10b45:      	addq	$0x20, %r12
   10b49:      	movl	$0x4, %eax
   10b4e:      	leaq	0x58(%rsp), %rdi
   10b53:      	movl	$0x10, %ecx
   10b58:      	movl	$0x10, %esi
   10b5d:      	movq	%r12, %rdx
   10b60:      	callq	*%rax
   10b62:      	movq	0x28(%rsp), %rbx
   10b67:      	movq	0x48(%rsp), %rax
   10b6c:      	movl	0x5c(%rsp), %r15d
   10b71:      	subq	%rbx, %rax
   10b74:      	movl	0x50(%rsp), %r12d
   10b79:      	movl	%r15d, %edx
   10b7c:      	subl	%r12d, %edx
   10b7f:      	movl	$0x0, %ecx
   10b84:      	cmovbl	%ecx, %edx
   10b87:      	addq	0x60(%rsp), %rdx
   10b8c:      	xorl	%esi, %esi
   10b8e:      	cmpl	%r15d, %r12d
   10b91:      	seta	%sil
   10b95:      	movl	%r15d, %ecx
   10b98:      	cmovbl	%r12d, %ecx
   10b9c:      	addl	%ecx, %esi
   10b9e:      	movl	%r12d, %edi
   10ba1:      	subl	%esi, %edi
   10ba3:      	movl	%edi, 0x50(%rsp)
   10ba7:      	subq	%rsi, %rax
   10baa:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   10bb0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10bb6:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   10bbc:      	cmpl	%r15d, %r12d
   10bbf:      	jbe	0x10bc5 <generic_rawtp_path+0x5ac5>
   10bc1:      	movb	$0x2f, (%rbx,%rax)
   10bc5:      	xorl	%edi, %edi
   10bc7:      	cmpl	%r15d, %r12d
   10bca:      	seta	%dil
   10bce:      	movzbl	%cl, %esi
   10bd1:      	addq	%rax, %rbx
   10bd4:      	addq	%rbx, %rdi
   10bd7:      	movl	$0x4, %eax
   10bdc:      	callq	*%rax
   10bde:      	movq	%rbx, 0x48(%rsp)
   10be3:      	cmpl	%r15d, %r12d
   10be6:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   10bec:      	movq	0x8(%rsp), %r12
   10bf1:      	movq	%r12, 0x30(%rsp)
   10bf6:      	movq	0x38(%rsp), %rdx
   10bfb:      	movq	0x40(%rsp), %r15
   10c00:      	jmp	0x10c53 <generic_rawtp_path+0x5b53>
   10c02:      	leaq	0x10(%r15), %rdx
   10c06:      	movl	$0x4, %eax
   10c0b:      	movq	%rbp, %rdi
   10c0e:      	movl	$0x8, %esi
   10c13:      	callq	*%rax
   10c15:      	movq	0x40(%rsp), %rax
   10c1a:      	cmpq	(%rsp), %rax
   10c1e:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   10c24:      	addq	$0x18, %r15
   10c28:      	movl	$0x4, %eax
   10c2d:      	leaq	0x30(%rsp), %rdi
   10c32:      	movl	$0x8, %esi
   10c37:      	movq	%r15, %rdx
   10c3a:      	callq	*%rax
   10c3c:      	movq	(%rsp), %r15
   10c40:      	movq	%r15, 0x40(%rsp)
   10c45:      	leaq	0x20(%r15), %rdx
   10c49:      	movq	%rdx, 0x38(%rsp)
   10c4e:      	movq	0x30(%rsp), %r12
   10c53:      	cmpq	0x18(%rsp), %r12
   10c58:      	jne	0x10c65 <generic_rawtp_path+0x5b65>
   10c5a:      	cmpq	0x20(%rsp), %rdx
   10c5f:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   10c65:      	movl	$0x4, %eax
   10c6a:      	leaq	0x10(%rsp), %rdi
   10c6f:      	movl	$0x8, %esi
   10c74:      	callq	*%rax
   10c76:      	cmpq	0x10(%rsp), %r12
   10c7b:      	je	0x10d73 <generic_rawtp_path+0x5c73>
   10c81:      	leaq	0x18(%r12), %rbx
   10c86:      	movl	$0x4, %eax
   10c8b:      	movq	%rbp, %rdi
   10c8e:      	movl	$0x8, %esi
   10c93:      	movq	%rbx, %rdx
   10c96:      	callq	*%rax
   10c98:      	cmpq	%r12, (%rsp)
   10c9c:      	je	0x10d73 <generic_rawtp_path+0x5c73>
   10ca2:      	movl	$0x4, %eax
   10ca7:      	leaq	0x8(%rsp), %rdi
   10cac:      	movl	$0x8, %esi
   10cb1:      	movq	%rbx, %rdx
   10cb4:      	callq	*%rax
   10cb6:      	addq	$0x20, %r12
   10cba:      	movl	$0x4, %eax
   10cbf:      	leaq	0x58(%rsp), %rdi
   10cc4:      	movl	$0x10, %ecx
   10cc9:      	movl	$0x10, %esi
   10cce:      	movq	%r12, %rdx
   10cd1:      	callq	*%rax
   10cd3:      	movq	0x28(%rsp), %rbx
   10cd8:      	movq	0x48(%rsp), %rax
   10cdd:      	movl	0x5c(%rsp), %r15d
   10ce2:      	subq	%rbx, %rax
   10ce5:      	movl	0x50(%rsp), %r12d
   10cea:      	movl	%r15d, %edx
   10ced:      	subl	%r12d, %edx
   10cf0:      	movl	$0x0, %ecx
   10cf5:      	cmovbl	%ecx, %edx
   10cf8:      	addq	0x60(%rsp), %rdx
   10cfd:      	xorl	%esi, %esi
   10cff:      	cmpl	%r15d, %r12d
   10d02:      	seta	%sil
   10d06:      	movl	%r15d, %ecx
   10d09:      	cmovbl	%r12d, %ecx
   10d0d:      	addl	%ecx, %esi
   10d0f:      	movl	%r12d, %edi
   10d12:      	subl	%esi, %edi
   10d14:      	movl	%edi, 0x50(%rsp)
   10d18:      	subq	%rsi, %rax
   10d1b:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   10d21:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10d27:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   10d2d:      	cmpl	%r15d, %r12d
   10d30:      	jbe	0x10d36 <generic_rawtp_path+0x5c36>
   10d32:      	movb	$0x2f, (%rbx,%rax)
   10d36:      	xorl	%edi, %edi
   10d38:      	cmpl	%r15d, %r12d
   10d3b:      	seta	%dil
   10d3f:      	movzbl	%cl, %esi
   10d42:      	addq	%rax, %rbx
   10d45:      	addq	%rbx, %rdi
   10d48:      	movl	$0x4, %eax
   10d4d:      	callq	*%rax
   10d4f:      	movq	%rbx, 0x48(%rsp)
   10d54:      	cmpl	%r15d, %r12d
   10d57:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   10d5d:      	movq	0x8(%rsp), %r12
   10d62:      	movq	%r12, 0x30(%rsp)
   10d67:      	movq	0x38(%rsp), %rdx
   10d6c:      	movq	0x40(%rsp), %r15
   10d71:      	jmp	0x10dc4 <generic_rawtp_path+0x5cc4>
   10d73:      	leaq	0x10(%r15), %rdx
   10d77:      	movl	$0x4, %eax
   10d7c:      	movq	%rbp, %rdi
   10d7f:      	movl	$0x8, %esi
   10d84:      	callq	*%rax
   10d86:      	movq	0x40(%rsp), %rax
   10d8b:      	cmpq	(%rsp), %rax
   10d8f:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   10d95:      	addq	$0x18, %r15
   10d99:      	movl	$0x4, %eax
   10d9e:      	leaq	0x30(%rsp), %rdi
   10da3:      	movl	$0x8, %esi
   10da8:      	movq	%r15, %rdx
   10dab:      	callq	*%rax
   10dad:      	movq	(%rsp), %r15
   10db1:      	movq	%r15, 0x40(%rsp)
   10db6:      	leaq	0x20(%r15), %rdx
   10dba:      	movq	%rdx, 0x38(%rsp)
   10dbf:      	movq	0x30(%rsp), %r12
   10dc4:      	cmpq	0x18(%rsp), %r12
   10dc9:      	jne	0x10dd6 <generic_rawtp_path+0x5cd6>
   10dcb:      	cmpq	0x20(%rsp), %rdx
   10dd0:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   10dd6:      	movl	$0x4, %eax
   10ddb:      	leaq	0x10(%rsp), %rdi
   10de0:      	movl	$0x8, %esi
   10de5:      	callq	*%rax
   10de7:      	cmpq	0x10(%rsp), %r12
   10dec:      	je	0x10ee4 <generic_rawtp_path+0x5de4>
   10df2:      	leaq	0x18(%r12), %rbx
   10df7:      	movl	$0x4, %eax
   10dfc:      	movq	%rbp, %rdi
   10dff:      	movl	$0x8, %esi
   10e04:      	movq	%rbx, %rdx
   10e07:      	callq	*%rax
   10e09:      	cmpq	%r12, (%rsp)
   10e0d:      	je	0x10ee4 <generic_rawtp_path+0x5de4>
   10e13:      	movl	$0x4, %eax
   10e18:      	leaq	0x8(%rsp), %rdi
   10e1d:      	movl	$0x8, %esi
   10e22:      	movq	%rbx, %rdx
   10e25:      	callq	*%rax
   10e27:      	addq	$0x20, %r12
   10e2b:      	movl	$0x4, %eax
   10e30:      	leaq	0x58(%rsp), %rdi
   10e35:      	movl	$0x10, %ecx
   10e3a:      	movl	$0x10, %esi
   10e3f:      	movq	%r12, %rdx
   10e42:      	callq	*%rax
   10e44:      	movq	0x28(%rsp), %rbx
   10e49:      	movq	0x48(%rsp), %rax
   10e4e:      	movl	0x5c(%rsp), %r15d
   10e53:      	subq	%rbx, %rax
   10e56:      	movl	0x50(%rsp), %r12d
   10e5b:      	movl	%r15d, %edx
   10e5e:      	subl	%r12d, %edx
   10e61:      	movl	$0x0, %ecx
   10e66:      	cmovbl	%ecx, %edx
   10e69:      	addq	0x60(%rsp), %rdx
   10e6e:      	xorl	%esi, %esi
   10e70:      	cmpl	%r15d, %r12d
   10e73:      	seta	%sil
   10e77:      	movl	%r15d, %ecx
   10e7a:      	cmovbl	%r12d, %ecx
   10e7e:      	addl	%ecx, %esi
   10e80:      	movl	%r12d, %edi
   10e83:      	subl	%esi, %edi
   10e85:      	movl	%edi, 0x50(%rsp)
   10e89:      	subq	%rsi, %rax
   10e8c:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   10e92:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10e98:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   10e9e:      	cmpl	%r15d, %r12d
   10ea1:      	jbe	0x10ea7 <generic_rawtp_path+0x5da7>
   10ea3:      	movb	$0x2f, (%rbx,%rax)
   10ea7:      	xorl	%edi, %edi
   10ea9:      	cmpl	%r15d, %r12d
   10eac:      	seta	%dil
   10eb0:      	movzbl	%cl, %esi
   10eb3:      	addq	%rax, %rbx
   10eb6:      	addq	%rbx, %rdi
   10eb9:      	movl	$0x4, %eax
   10ebe:      	callq	*%rax
   10ec0:      	movq	%rbx, 0x48(%rsp)
   10ec5:      	cmpl	%r15d, %r12d
   10ec8:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   10ece:      	movq	0x8(%rsp), %r12
   10ed3:      	movq	%r12, 0x30(%rsp)
   10ed8:      	movq	0x38(%rsp), %rdx
   10edd:      	movq	0x40(%rsp), %r15
   10ee2:      	jmp	0x10f35 <generic_rawtp_path+0x5e35>
   10ee4:      	leaq	0x10(%r15), %rdx
   10ee8:      	movl	$0x4, %eax
   10eed:      	movq	%rbp, %rdi
   10ef0:      	movl	$0x8, %esi
   10ef5:      	callq	*%rax
   10ef7:      	movq	0x40(%rsp), %rax
   10efc:      	cmpq	(%rsp), %rax
   10f00:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   10f06:      	addq	$0x18, %r15
   10f0a:      	movl	$0x4, %eax
   10f0f:      	leaq	0x30(%rsp), %rdi
   10f14:      	movl	$0x8, %esi
   10f19:      	movq	%r15, %rdx
   10f1c:      	callq	*%rax
   10f1e:      	movq	(%rsp), %r15
   10f22:      	movq	%r15, 0x40(%rsp)
   10f27:      	leaq	0x20(%r15), %rdx
   10f2b:      	movq	%rdx, 0x38(%rsp)
   10f30:      	movq	0x30(%rsp), %r12
   10f35:      	cmpq	0x18(%rsp), %r12
   10f3a:      	jne	0x10f47 <generic_rawtp_path+0x5e47>
   10f3c:      	cmpq	0x20(%rsp), %rdx
   10f41:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   10f47:      	movl	$0x4, %eax
   10f4c:      	leaq	0x10(%rsp), %rdi
   10f51:      	movl	$0x8, %esi
   10f56:      	callq	*%rax
   10f58:      	cmpq	0x10(%rsp), %r12
   10f5d:      	je	0x11055 <generic_rawtp_path+0x5f55>
   10f63:      	leaq	0x18(%r12), %rbx
   10f68:      	movl	$0x4, %eax
   10f6d:      	movq	%rbp, %rdi
   10f70:      	movl	$0x8, %esi
   10f75:      	movq	%rbx, %rdx
   10f78:      	callq	*%rax
   10f7a:      	cmpq	%r12, (%rsp)
   10f7e:      	je	0x11055 <generic_rawtp_path+0x5f55>
   10f84:      	movl	$0x4, %eax
   10f89:      	leaq	0x8(%rsp), %rdi
   10f8e:      	movl	$0x8, %esi
   10f93:      	movq	%rbx, %rdx
   10f96:      	callq	*%rax
   10f98:      	addq	$0x20, %r12
   10f9c:      	movl	$0x4, %eax
   10fa1:      	leaq	0x58(%rsp), %rdi
   10fa6:      	movl	$0x10, %ecx
   10fab:      	movl	$0x10, %esi
   10fb0:      	movq	%r12, %rdx
   10fb3:      	callq	*%rax
   10fb5:      	movq	0x28(%rsp), %rbx
   10fba:      	movq	0x48(%rsp), %rax
   10fbf:      	movl	0x5c(%rsp), %r15d
   10fc4:      	subq	%rbx, %rax
   10fc7:      	movl	0x50(%rsp), %r12d
   10fcc:      	movl	%r15d, %edx
   10fcf:      	subl	%r12d, %edx
   10fd2:      	movl	$0x0, %ecx
   10fd7:      	cmovbl	%ecx, %edx
   10fda:      	addq	0x60(%rsp), %rdx
   10fdf:      	xorl	%esi, %esi
   10fe1:      	cmpl	%r15d, %r12d
   10fe4:      	seta	%sil
   10fe8:      	movl	%r15d, %ecx
   10feb:      	cmovbl	%r12d, %ecx
   10fef:      	addl	%ecx, %esi
   10ff1:      	movl	%r12d, %edi
   10ff4:      	subl	%esi, %edi
   10ff6:      	movl	%edi, 0x50(%rsp)
   10ffa:      	subq	%rsi, %rax
   10ffd:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   11003:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11009:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   1100f:      	cmpl	%r15d, %r12d
   11012:      	jbe	0x11018 <generic_rawtp_path+0x5f18>
   11014:      	movb	$0x2f, (%rbx,%rax)
   11018:      	xorl	%edi, %edi
   1101a:      	cmpl	%r15d, %r12d
   1101d:      	seta	%dil
   11021:      	movzbl	%cl, %esi
   11024:      	addq	%rax, %rbx
   11027:      	addq	%rbx, %rdi
   1102a:      	movl	$0x4, %eax
   1102f:      	callq	*%rax
   11031:      	movq	%rbx, 0x48(%rsp)
   11036:      	cmpl	%r15d, %r12d
   11039:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   1103f:      	movq	0x8(%rsp), %r12
   11044:      	movq	%r12, 0x30(%rsp)
   11049:      	movq	0x38(%rsp), %rdx
   1104e:      	movq	0x40(%rsp), %r15
   11053:      	jmp	0x110a6 <generic_rawtp_path+0x5fa6>
   11055:      	leaq	0x10(%r15), %rdx
   11059:      	movl	$0x4, %eax
   1105e:      	movq	%rbp, %rdi
   11061:      	movl	$0x8, %esi
   11066:      	callq	*%rax
   11068:      	movq	0x40(%rsp), %rax
   1106d:      	cmpq	(%rsp), %rax
   11071:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   11077:      	addq	$0x18, %r15
   1107b:      	movl	$0x4, %eax
   11080:      	leaq	0x30(%rsp), %rdi
   11085:      	movl	$0x8, %esi
   1108a:      	movq	%r15, %rdx
   1108d:      	callq	*%rax
   1108f:      	movq	(%rsp), %r15
   11093:      	movq	%r15, 0x40(%rsp)
   11098:      	leaq	0x20(%r15), %rdx
   1109c:      	movq	%rdx, 0x38(%rsp)
   110a1:      	movq	0x30(%rsp), %r12
   110a6:      	cmpq	0x18(%rsp), %r12
   110ab:      	jne	0x110b8 <generic_rawtp_path+0x5fb8>
   110ad:      	cmpq	0x20(%rsp), %rdx
   110b2:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   110b8:      	movl	$0x4, %eax
   110bd:      	leaq	0x10(%rsp), %rdi
   110c2:      	movl	$0x8, %esi
   110c7:      	callq	*%rax
   110c9:      	cmpq	0x10(%rsp), %r12
   110ce:      	je	0x111c6 <generic_rawtp_path+0x60c6>
   110d4:      	leaq	0x18(%r12), %rbx
   110d9:      	movl	$0x4, %eax
   110de:      	movq	%rbp, %rdi
   110e1:      	movl	$0x8, %esi
   110e6:      	movq	%rbx, %rdx
   110e9:      	callq	*%rax
   110eb:      	cmpq	%r12, (%rsp)
   110ef:      	je	0x111c6 <generic_rawtp_path+0x60c6>
   110f5:      	movl	$0x4, %eax
   110fa:      	leaq	0x8(%rsp), %rdi
   110ff:      	movl	$0x8, %esi
   11104:      	movq	%rbx, %rdx
   11107:      	callq	*%rax
   11109:      	addq	$0x20, %r12
   1110d:      	movl	$0x4, %eax
   11112:      	leaq	0x58(%rsp), %rdi
   11117:      	movl	$0x10, %ecx
   1111c:      	movl	$0x10, %esi
   11121:      	movq	%r12, %rdx
   11124:      	callq	*%rax
   11126:      	movq	0x28(%rsp), %rbx
   1112b:      	movq	0x48(%rsp), %rax
   11130:      	movl	0x5c(%rsp), %r15d
   11135:      	subq	%rbx, %rax
   11138:      	movl	0x50(%rsp), %r12d
   1113d:      	movl	%r15d, %edx
   11140:      	subl	%r12d, %edx
   11143:      	movl	$0x0, %ecx
   11148:      	cmovbl	%ecx, %edx
   1114b:      	addq	0x60(%rsp), %rdx
   11150:      	xorl	%esi, %esi
   11152:      	cmpl	%r15d, %r12d
   11155:      	seta	%sil
   11159:      	movl	%r15d, %ecx
   1115c:      	cmovbl	%r12d, %ecx
   11160:      	addl	%ecx, %esi
   11162:      	movl	%r12d, %edi
   11165:      	subl	%esi, %edi
   11167:      	movl	%edi, 0x50(%rsp)
   1116b:      	subq	%rsi, %rax
   1116e:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   11174:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1117a:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   11180:      	cmpl	%r15d, %r12d
   11183:      	jbe	0x11189 <generic_rawtp_path+0x6089>
   11185:      	movb	$0x2f, (%rbx,%rax)
   11189:      	xorl	%edi, %edi
   1118b:      	cmpl	%r15d, %r12d
   1118e:      	seta	%dil
   11192:      	movzbl	%cl, %esi
   11195:      	addq	%rax, %rbx
   11198:      	addq	%rbx, %rdi
   1119b:      	movl	$0x4, %eax
   111a0:      	callq	*%rax
   111a2:      	movq	%rbx, 0x48(%rsp)
   111a7:      	cmpl	%r15d, %r12d
   111aa:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   111b0:      	movq	0x8(%rsp), %r12
   111b5:      	movq	%r12, 0x30(%rsp)
   111ba:      	movq	0x38(%rsp), %rdx
   111bf:      	movq	0x40(%rsp), %r15
   111c4:      	jmp	0x11217 <generic_rawtp_path+0x6117>
   111c6:      	leaq	0x10(%r15), %rdx
   111ca:      	movl	$0x4, %eax
   111cf:      	movq	%rbp, %rdi
   111d2:      	movl	$0x8, %esi
   111d7:      	callq	*%rax
   111d9:      	movq	0x40(%rsp), %rax
   111de:      	cmpq	(%rsp), %rax
   111e2:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   111e8:      	addq	$0x18, %r15
   111ec:      	movl	$0x4, %eax
   111f1:      	leaq	0x30(%rsp), %rdi
   111f6:      	movl	$0x8, %esi
   111fb:      	movq	%r15, %rdx
   111fe:      	callq	*%rax
   11200:      	movq	(%rsp), %r15
   11204:      	movq	%r15, 0x40(%rsp)
   11209:      	leaq	0x20(%r15), %rdx
   1120d:      	movq	%rdx, 0x38(%rsp)
   11212:      	movq	0x30(%rsp), %r12
   11217:      	cmpq	0x18(%rsp), %r12
   1121c:      	jne	0x11229 <generic_rawtp_path+0x6129>
   1121e:      	cmpq	0x20(%rsp), %rdx
   11223:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   11229:      	movl	$0x4, %eax
   1122e:      	leaq	0x10(%rsp), %rdi
   11233:      	movl	$0x8, %esi
   11238:      	callq	*%rax
   1123a:      	cmpq	0x10(%rsp), %r12
   1123f:      	je	0x11337 <generic_rawtp_path+0x6237>
   11245:      	leaq	0x18(%r12), %rbx
   1124a:      	movl	$0x4, %eax
   1124f:      	movq	%rbp, %rdi
   11252:      	movl	$0x8, %esi
   11257:      	movq	%rbx, %rdx
   1125a:      	callq	*%rax
   1125c:      	cmpq	%r12, (%rsp)
   11260:      	je	0x11337 <generic_rawtp_path+0x6237>
   11266:      	movl	$0x4, %eax
   1126b:      	leaq	0x8(%rsp), %rdi
   11270:      	movl	$0x8, %esi
   11275:      	movq	%rbx, %rdx
   11278:      	callq	*%rax
   1127a:      	addq	$0x20, %r12
   1127e:      	movl	$0x4, %eax
   11283:      	leaq	0x58(%rsp), %rdi
   11288:      	movl	$0x10, %ecx
   1128d:      	movl	$0x10, %esi
   11292:      	movq	%r12, %rdx
   11295:      	callq	*%rax
   11297:      	movq	0x28(%rsp), %rbx
   1129c:      	movq	0x48(%rsp), %rax
   112a1:      	movl	0x5c(%rsp), %r15d
   112a6:      	subq	%rbx, %rax
   112a9:      	movl	0x50(%rsp), %r12d
   112ae:      	movl	%r15d, %edx
   112b1:      	subl	%r12d, %edx
   112b4:      	movl	$0x0, %ecx
   112b9:      	cmovbl	%ecx, %edx
   112bc:      	addq	0x60(%rsp), %rdx
   112c1:      	xorl	%esi, %esi
   112c3:      	cmpl	%r15d, %r12d
   112c6:      	seta	%sil
   112ca:      	movl	%r15d, %ecx
   112cd:      	cmovbl	%r12d, %ecx
   112d1:      	addl	%ecx, %esi
   112d3:      	movl	%r12d, %edi
   112d6:      	subl	%esi, %edi
   112d8:      	movl	%edi, 0x50(%rsp)
   112dc:      	subq	%rsi, %rax
   112df:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   112e5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   112eb:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   112f1:      	cmpl	%r15d, %r12d
   112f4:      	jbe	0x112fa <generic_rawtp_path+0x61fa>
   112f6:      	movb	$0x2f, (%rbx,%rax)
   112fa:      	xorl	%edi, %edi
   112fc:      	cmpl	%r15d, %r12d
   112ff:      	seta	%dil
   11303:      	movzbl	%cl, %esi
   11306:      	addq	%rax, %rbx
   11309:      	addq	%rbx, %rdi
   1130c:      	movl	$0x4, %eax
   11311:      	callq	*%rax
   11313:      	movq	%rbx, 0x48(%rsp)
   11318:      	cmpl	%r15d, %r12d
   1131b:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   11321:      	movq	0x8(%rsp), %r12
   11326:      	movq	%r12, 0x30(%rsp)
   1132b:      	movq	0x38(%rsp), %rdx
   11330:      	movq	0x40(%rsp), %r15
   11335:      	jmp	0x11388 <generic_rawtp_path+0x6288>
   11337:      	leaq	0x10(%r15), %rdx
   1133b:      	movl	$0x4, %eax
   11340:      	movq	%rbp, %rdi
   11343:      	movl	$0x8, %esi
   11348:      	callq	*%rax
   1134a:      	movq	0x40(%rsp), %rax
   1134f:      	cmpq	(%rsp), %rax
   11353:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   11359:      	addq	$0x18, %r15
   1135d:      	movl	$0x4, %eax
   11362:      	leaq	0x30(%rsp), %rdi
   11367:      	movl	$0x8, %esi
   1136c:      	movq	%r15, %rdx
   1136f:      	callq	*%rax
   11371:      	movq	(%rsp), %r15
   11375:      	movq	%r15, 0x40(%rsp)
   1137a:      	leaq	0x20(%r15), %rdx
   1137e:      	movq	%rdx, 0x38(%rsp)
   11383:      	movq	0x30(%rsp), %r12
   11388:      	cmpq	0x18(%rsp), %r12
   1138d:      	jne	0x1139a <generic_rawtp_path+0x629a>
   1138f:      	cmpq	0x20(%rsp), %rdx
   11394:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   1139a:      	movl	$0x4, %eax
   1139f:      	leaq	0x10(%rsp), %rdi
   113a4:      	movl	$0x8, %esi
   113a9:      	callq	*%rax
   113ab:      	cmpq	0x10(%rsp), %r12
   113b0:      	je	0x114a8 <generic_rawtp_path+0x63a8>
   113b6:      	leaq	0x18(%r12), %rbx
   113bb:      	movl	$0x4, %eax
   113c0:      	movq	%rbp, %rdi
   113c3:      	movl	$0x8, %esi
   113c8:      	movq	%rbx, %rdx
   113cb:      	callq	*%rax
   113cd:      	cmpq	%r12, (%rsp)
   113d1:      	je	0x114a8 <generic_rawtp_path+0x63a8>
   113d7:      	movl	$0x4, %eax
   113dc:      	leaq	0x8(%rsp), %rdi
   113e1:      	movl	$0x8, %esi
   113e6:      	movq	%rbx, %rdx
   113e9:      	callq	*%rax
   113eb:      	addq	$0x20, %r12
   113ef:      	movl	$0x4, %eax
   113f4:      	leaq	0x58(%rsp), %rdi
   113f9:      	movl	$0x10, %ecx
   113fe:      	movl	$0x10, %esi
   11403:      	movq	%r12, %rdx
   11406:      	callq	*%rax
   11408:      	movq	0x28(%rsp), %rbx
   1140d:      	movq	0x48(%rsp), %rax
   11412:      	movl	0x5c(%rsp), %r15d
   11417:      	subq	%rbx, %rax
   1141a:      	movl	0x50(%rsp), %r12d
   1141f:      	movl	%r15d, %edx
   11422:      	subl	%r12d, %edx
   11425:      	movl	$0x0, %ecx
   1142a:      	cmovbl	%ecx, %edx
   1142d:      	addq	0x60(%rsp), %rdx
   11432:      	xorl	%esi, %esi
   11434:      	cmpl	%r15d, %r12d
   11437:      	seta	%sil
   1143b:      	movl	%r15d, %ecx
   1143e:      	cmovbl	%r12d, %ecx
   11442:      	addl	%ecx, %esi
   11444:      	movl	%r12d, %edi
   11447:      	subl	%esi, %edi
   11449:      	movl	%edi, 0x50(%rsp)
   1144d:      	subq	%rsi, %rax
   11450:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   11456:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1145c:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   11462:      	cmpl	%r15d, %r12d
   11465:      	jbe	0x1146b <generic_rawtp_path+0x636b>
   11467:      	movb	$0x2f, (%rbx,%rax)
   1146b:      	xorl	%edi, %edi
   1146d:      	cmpl	%r15d, %r12d
   11470:      	seta	%dil
   11474:      	movzbl	%cl, %esi
   11477:      	addq	%rax, %rbx
   1147a:      	addq	%rbx, %rdi
   1147d:      	movl	$0x4, %eax
   11482:      	callq	*%rax
   11484:      	movq	%rbx, 0x48(%rsp)
   11489:      	cmpl	%r15d, %r12d
   1148c:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   11492:      	movq	0x8(%rsp), %r12
   11497:      	movq	%r12, 0x30(%rsp)
   1149c:      	movq	0x38(%rsp), %rdx
   114a1:      	movq	0x40(%rsp), %r15
   114a6:      	jmp	0x114f9 <generic_rawtp_path+0x63f9>
   114a8:      	leaq	0x10(%r15), %rdx
   114ac:      	movl	$0x4, %eax
   114b1:      	movq	%rbp, %rdi
   114b4:      	movl	$0x8, %esi
   114b9:      	callq	*%rax
   114bb:      	movq	0x40(%rsp), %rax
   114c0:      	cmpq	(%rsp), %rax
   114c4:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   114ca:      	addq	$0x18, %r15
   114ce:      	movl	$0x4, %eax
   114d3:      	leaq	0x30(%rsp), %rdi
   114d8:      	movl	$0x8, %esi
   114dd:      	movq	%r15, %rdx
   114e0:      	callq	*%rax
   114e2:      	movq	(%rsp), %r15
   114e6:      	movq	%r15, 0x40(%rsp)
   114eb:      	leaq	0x20(%r15), %rdx
   114ef:      	movq	%rdx, 0x38(%rsp)
   114f4:      	movq	0x30(%rsp), %r12
   114f9:      	cmpq	0x18(%rsp), %r12
   114fe:      	jne	0x1150b <generic_rawtp_path+0x640b>
   11500:      	cmpq	0x20(%rsp), %rdx
   11505:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   1150b:      	movl	$0x4, %eax
   11510:      	leaq	0x10(%rsp), %rdi
   11515:      	movl	$0x8, %esi
   1151a:      	callq	*%rax
   1151c:      	cmpq	0x10(%rsp), %r12
   11521:      	je	0x11619 <generic_rawtp_path+0x6519>
   11527:      	leaq	0x18(%r12), %rbx
   1152c:      	movl	$0x4, %eax
   11531:      	movq	%rbp, %rdi
   11534:      	movl	$0x8, %esi
   11539:      	movq	%rbx, %rdx
   1153c:      	callq	*%rax
   1153e:      	cmpq	%r12, (%rsp)
   11542:      	je	0x11619 <generic_rawtp_path+0x6519>
   11548:      	movl	$0x4, %eax
   1154d:      	leaq	0x8(%rsp), %rdi
   11552:      	movl	$0x8, %esi
   11557:      	movq	%rbx, %rdx
   1155a:      	callq	*%rax
   1155c:      	addq	$0x20, %r12
   11560:      	movl	$0x4, %eax
   11565:      	leaq	0x58(%rsp), %rdi
   1156a:      	movl	$0x10, %ecx
   1156f:      	movl	$0x10, %esi
   11574:      	movq	%r12, %rdx
   11577:      	callq	*%rax
   11579:      	movq	0x28(%rsp), %rbx
   1157e:      	movq	0x48(%rsp), %rax
   11583:      	movl	0x5c(%rsp), %r15d
   11588:      	subq	%rbx, %rax
   1158b:      	movl	0x50(%rsp), %r12d
   11590:      	movl	%r15d, %edx
   11593:      	subl	%r12d, %edx
   11596:      	movl	$0x0, %ecx
   1159b:      	cmovbl	%ecx, %edx
   1159e:      	addq	0x60(%rsp), %rdx
   115a3:      	xorl	%esi, %esi
   115a5:      	cmpl	%r15d, %r12d
   115a8:      	seta	%sil
   115ac:      	movl	%r15d, %ecx
   115af:      	cmovbl	%r12d, %ecx
   115b3:      	addl	%ecx, %esi
   115b5:      	movl	%r12d, %edi
   115b8:      	subl	%esi, %edi
   115ba:      	movl	%edi, 0x50(%rsp)
   115be:      	subq	%rsi, %rax
   115c1:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   115c7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   115cd:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   115d3:      	cmpl	%r15d, %r12d
   115d6:      	jbe	0x115dc <generic_rawtp_path+0x64dc>
   115d8:      	movb	$0x2f, (%rbx,%rax)
   115dc:      	xorl	%edi, %edi
   115de:      	cmpl	%r15d, %r12d
   115e1:      	seta	%dil
   115e5:      	movzbl	%cl, %esi
   115e8:      	addq	%rax, %rbx
   115eb:      	addq	%rbx, %rdi
   115ee:      	movl	$0x4, %eax
   115f3:      	callq	*%rax
   115f5:      	movq	%rbx, 0x48(%rsp)
   115fa:      	cmpl	%r15d, %r12d
   115fd:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   11603:      	movq	0x8(%rsp), %r12
   11608:      	movq	%r12, 0x30(%rsp)
   1160d:      	movq	0x38(%rsp), %rdx
   11612:      	movq	0x40(%rsp), %r15
   11617:      	jmp	0x1166a <generic_rawtp_path+0x656a>
   11619:      	leaq	0x10(%r15), %rdx
   1161d:      	movl	$0x4, %eax
   11622:      	movq	%rbp, %rdi
   11625:      	movl	$0x8, %esi
   1162a:      	callq	*%rax
   1162c:      	movq	0x40(%rsp), %rax
   11631:      	cmpq	(%rsp), %rax
   11635:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   1163b:      	addq	$0x18, %r15
   1163f:      	movl	$0x4, %eax
   11644:      	leaq	0x30(%rsp), %rdi
   11649:      	movl	$0x8, %esi
   1164e:      	movq	%r15, %rdx
   11651:      	callq	*%rax
   11653:      	movq	(%rsp), %r15
   11657:      	movq	%r15, 0x40(%rsp)
   1165c:      	leaq	0x20(%r15), %rdx
   11660:      	movq	%rdx, 0x38(%rsp)
   11665:      	movq	0x30(%rsp), %r12
   1166a:      	cmpq	0x18(%rsp), %r12
   1166f:      	jne	0x1167c <generic_rawtp_path+0x657c>
   11671:      	cmpq	0x20(%rsp), %rdx
   11676:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   1167c:      	movl	$0x4, %eax
   11681:      	leaq	0x10(%rsp), %rdi
   11686:      	movl	$0x8, %esi
   1168b:      	callq	*%rax
   1168d:      	cmpq	0x10(%rsp), %r12
   11692:      	je	0x1178a <generic_rawtp_path+0x668a>
   11698:      	leaq	0x18(%r12), %rbx
   1169d:      	movl	$0x4, %eax
   116a2:      	movq	%rbp, %rdi
   116a5:      	movl	$0x8, %esi
   116aa:      	movq	%rbx, %rdx
   116ad:      	callq	*%rax
   116af:      	cmpq	%r12, (%rsp)
   116b3:      	je	0x1178a <generic_rawtp_path+0x668a>
   116b9:      	movl	$0x4, %eax
   116be:      	leaq	0x8(%rsp), %rdi
   116c3:      	movl	$0x8, %esi
   116c8:      	movq	%rbx, %rdx
   116cb:      	callq	*%rax
   116cd:      	addq	$0x20, %r12
   116d1:      	movl	$0x4, %eax
   116d6:      	leaq	0x58(%rsp), %rdi
   116db:      	movl	$0x10, %ecx
   116e0:      	movl	$0x10, %esi
   116e5:      	movq	%r12, %rdx
   116e8:      	callq	*%rax
   116ea:      	movq	0x28(%rsp), %rbx
   116ef:      	movq	0x48(%rsp), %rax
   116f4:      	movl	0x5c(%rsp), %r15d
   116f9:      	subq	%rbx, %rax
   116fc:      	movl	0x50(%rsp), %r12d
   11701:      	movl	%r15d, %edx
   11704:      	subl	%r12d, %edx
   11707:      	movl	$0x0, %ecx
   1170c:      	cmovbl	%ecx, %edx
   1170f:      	addq	0x60(%rsp), %rdx
   11714:      	xorl	%esi, %esi
   11716:      	cmpl	%r15d, %r12d
   11719:      	seta	%sil
   1171d:      	movl	%r15d, %ecx
   11720:      	cmovbl	%r12d, %ecx
   11724:      	addl	%ecx, %esi
   11726:      	movl	%r12d, %edi
   11729:      	subl	%esi, %edi
   1172b:      	movl	%edi, 0x50(%rsp)
   1172f:      	subq	%rsi, %rax
   11732:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   11738:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1173e:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   11744:      	cmpl	%r15d, %r12d
   11747:      	jbe	0x1174d <generic_rawtp_path+0x664d>
   11749:      	movb	$0x2f, (%rbx,%rax)
   1174d:      	xorl	%edi, %edi
   1174f:      	cmpl	%r15d, %r12d
   11752:      	seta	%dil
   11756:      	movzbl	%cl, %esi
   11759:      	addq	%rax, %rbx
   1175c:      	addq	%rbx, %rdi
   1175f:      	movl	$0x4, %eax
   11764:      	callq	*%rax
   11766:      	movq	%rbx, 0x48(%rsp)
   1176b:      	cmpl	%r15d, %r12d
   1176e:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   11774:      	movq	0x8(%rsp), %r12
   11779:      	movq	%r12, 0x30(%rsp)
   1177e:      	movq	0x38(%rsp), %rdx
   11783:      	movq	0x40(%rsp), %r15
   11788:      	jmp	0x117db <generic_rawtp_path+0x66db>
   1178a:      	leaq	0x10(%r15), %rdx
   1178e:      	movl	$0x4, %eax
   11793:      	movq	%rbp, %rdi
   11796:      	movl	$0x8, %esi
   1179b:      	callq	*%rax
   1179d:      	movq	0x40(%rsp), %rax
   117a2:      	cmpq	(%rsp), %rax
   117a6:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   117ac:      	addq	$0x18, %r15
   117b0:      	movl	$0x4, %eax
   117b5:      	leaq	0x30(%rsp), %rdi
   117ba:      	movl	$0x8, %esi
   117bf:      	movq	%r15, %rdx
   117c2:      	callq	*%rax
   117c4:      	movq	(%rsp), %r15
   117c8:      	movq	%r15, 0x40(%rsp)
   117cd:      	leaq	0x20(%r15), %rdx
   117d1:      	movq	%rdx, 0x38(%rsp)
   117d6:      	movq	0x30(%rsp), %r12
   117db:      	cmpq	0x18(%rsp), %r12
   117e0:      	jne	0x117ed <generic_rawtp_path+0x66ed>
   117e2:      	cmpq	0x20(%rsp), %rdx
   117e7:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   117ed:      	movl	$0x4, %eax
   117f2:      	leaq	0x10(%rsp), %rdi
   117f7:      	movl	$0x8, %esi
   117fc:      	callq	*%rax
   117fe:      	cmpq	0x10(%rsp), %r12
   11803:      	je	0x118fb <generic_rawtp_path+0x67fb>
   11809:      	leaq	0x18(%r12), %rbx
   1180e:      	movl	$0x4, %eax
   11813:      	movq	%rbp, %rdi
   11816:      	movl	$0x8, %esi
   1181b:      	movq	%rbx, %rdx
   1181e:      	callq	*%rax
   11820:      	cmpq	%r12, (%rsp)
   11824:      	je	0x118fb <generic_rawtp_path+0x67fb>
   1182a:      	movl	$0x4, %eax
   1182f:      	leaq	0x8(%rsp), %rdi
   11834:      	movl	$0x8, %esi
   11839:      	movq	%rbx, %rdx
   1183c:      	callq	*%rax
   1183e:      	addq	$0x20, %r12
   11842:      	movl	$0x4, %eax
   11847:      	leaq	0x58(%rsp), %rdi
   1184c:      	movl	$0x10, %ecx
   11851:      	movl	$0x10, %esi
   11856:      	movq	%r12, %rdx
   11859:      	callq	*%rax
   1185b:      	movq	0x28(%rsp), %rbx
   11860:      	movq	0x48(%rsp), %rax
   11865:      	movl	0x5c(%rsp), %r15d
   1186a:      	subq	%rbx, %rax
   1186d:      	movl	0x50(%rsp), %r12d
   11872:      	movl	%r15d, %edx
   11875:      	subl	%r12d, %edx
   11878:      	movl	$0x0, %ecx
   1187d:      	cmovbl	%ecx, %edx
   11880:      	addq	0x60(%rsp), %rdx
   11885:      	xorl	%esi, %esi
   11887:      	cmpl	%r15d, %r12d
   1188a:      	seta	%sil
   1188e:      	movl	%r15d, %ecx
   11891:      	cmovbl	%r12d, %ecx
   11895:      	addl	%ecx, %esi
   11897:      	movl	%r12d, %edi
   1189a:      	subl	%esi, %edi
   1189c:      	movl	%edi, 0x50(%rsp)
   118a0:      	subq	%rsi, %rax
   118a3:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   118a9:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   118af:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   118b5:      	cmpl	%r15d, %r12d
   118b8:      	jbe	0x118be <generic_rawtp_path+0x67be>
   118ba:      	movb	$0x2f, (%rbx,%rax)
   118be:      	xorl	%edi, %edi
   118c0:      	cmpl	%r15d, %r12d
   118c3:      	seta	%dil
   118c7:      	movzbl	%cl, %esi
   118ca:      	addq	%rax, %rbx
   118cd:      	addq	%rbx, %rdi
   118d0:      	movl	$0x4, %eax
   118d5:      	callq	*%rax
   118d7:      	movq	%rbx, 0x48(%rsp)
   118dc:      	cmpl	%r15d, %r12d
   118df:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   118e5:      	movq	0x8(%rsp), %r12
   118ea:      	movq	%r12, 0x30(%rsp)
   118ef:      	movq	0x38(%rsp), %rdx
   118f4:      	movq	0x40(%rsp), %r15
   118f9:      	jmp	0x1194c <generic_rawtp_path+0x684c>
   118fb:      	leaq	0x10(%r15), %rdx
   118ff:      	movl	$0x4, %eax
   11904:      	movq	%rbp, %rdi
   11907:      	movl	$0x8, %esi
   1190c:      	callq	*%rax
   1190e:      	movq	0x40(%rsp), %rax
   11913:      	cmpq	(%rsp), %rax
   11917:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   1191d:      	addq	$0x18, %r15
   11921:      	movl	$0x4, %eax
   11926:      	leaq	0x30(%rsp), %rdi
   1192b:      	movl	$0x8, %esi
   11930:      	movq	%r15, %rdx
   11933:      	callq	*%rax
   11935:      	movq	(%rsp), %r15
   11939:      	movq	%r15, 0x40(%rsp)
   1193e:      	leaq	0x20(%r15), %rdx
   11942:      	movq	%rdx, 0x38(%rsp)
   11947:      	movq	0x30(%rsp), %r12
   1194c:      	cmpq	0x18(%rsp), %r12
   11951:      	jne	0x1195e <generic_rawtp_path+0x685e>
   11953:      	cmpq	0x20(%rsp), %rdx
   11958:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   1195e:      	movl	$0x4, %eax
   11963:      	leaq	0x10(%rsp), %rdi
   11968:      	movl	$0x8, %esi
   1196d:      	callq	*%rax
   1196f:      	cmpq	0x10(%rsp), %r12
   11974:      	je	0x11a6c <generic_rawtp_path+0x696c>
   1197a:      	leaq	0x18(%r12), %rbx
   1197f:      	movl	$0x4, %eax
   11984:      	movq	%rbp, %rdi
   11987:      	movl	$0x8, %esi
   1198c:      	movq	%rbx, %rdx
   1198f:      	callq	*%rax
   11991:      	cmpq	%r12, (%rsp)
   11995:      	je	0x11a6c <generic_rawtp_path+0x696c>
   1199b:      	movl	$0x4, %eax
   119a0:      	leaq	0x8(%rsp), %rdi
   119a5:      	movl	$0x8, %esi
   119aa:      	movq	%rbx, %rdx
   119ad:      	callq	*%rax
   119af:      	addq	$0x20, %r12
   119b3:      	movl	$0x4, %eax
   119b8:      	leaq	0x58(%rsp), %rdi
   119bd:      	movl	$0x10, %ecx
   119c2:      	movl	$0x10, %esi
   119c7:      	movq	%r12, %rdx
   119ca:      	callq	*%rax
   119cc:      	movq	0x28(%rsp), %rbx
   119d1:      	movq	0x48(%rsp), %rax
   119d6:      	movl	0x5c(%rsp), %r15d
   119db:      	subq	%rbx, %rax
   119de:      	movl	0x50(%rsp), %r12d
   119e3:      	movl	%r15d, %edx
   119e6:      	subl	%r12d, %edx
   119e9:      	movl	$0x0, %ecx
   119ee:      	cmovbl	%ecx, %edx
   119f1:      	addq	0x60(%rsp), %rdx
   119f6:      	xorl	%esi, %esi
   119f8:      	cmpl	%r15d, %r12d
   119fb:      	seta	%sil
   119ff:      	movl	%r15d, %ecx
   11a02:      	cmovbl	%r12d, %ecx
   11a06:      	addl	%ecx, %esi
   11a08:      	movl	%r12d, %edi
   11a0b:      	subl	%esi, %edi
   11a0d:      	movl	%edi, 0x50(%rsp)
   11a11:      	subq	%rsi, %rax
   11a14:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   11a1a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11a20:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   11a26:      	cmpl	%r15d, %r12d
   11a29:      	jbe	0x11a2f <generic_rawtp_path+0x692f>
   11a2b:      	movb	$0x2f, (%rbx,%rax)
   11a2f:      	xorl	%edi, %edi
   11a31:      	cmpl	%r15d, %r12d
   11a34:      	seta	%dil
   11a38:      	movzbl	%cl, %esi
   11a3b:      	addq	%rax, %rbx
   11a3e:      	addq	%rbx, %rdi
   11a41:      	movl	$0x4, %eax
   11a46:      	callq	*%rax
   11a48:      	movq	%rbx, 0x48(%rsp)
   11a4d:      	cmpl	%r15d, %r12d
   11a50:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   11a56:      	movq	0x8(%rsp), %r12
   11a5b:      	movq	%r12, 0x30(%rsp)
   11a60:      	movq	0x38(%rsp), %rdx
   11a65:      	movq	0x40(%rsp), %r15
   11a6a:      	jmp	0x11abd <generic_rawtp_path+0x69bd>
   11a6c:      	leaq	0x10(%r15), %rdx
   11a70:      	movl	$0x4, %eax
   11a75:      	movq	%rbp, %rdi
   11a78:      	movl	$0x8, %esi
   11a7d:      	callq	*%rax
   11a7f:      	movq	0x40(%rsp), %rax
   11a84:      	cmpq	(%rsp), %rax
   11a88:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   11a8e:      	addq	$0x18, %r15
   11a92:      	movl	$0x4, %eax
   11a97:      	leaq	0x30(%rsp), %rdi
   11a9c:      	movl	$0x8, %esi
   11aa1:      	movq	%r15, %rdx
   11aa4:      	callq	*%rax
   11aa6:      	movq	(%rsp), %r15
   11aaa:      	movq	%r15, 0x40(%rsp)
   11aaf:      	leaq	0x20(%r15), %rdx
   11ab3:      	movq	%rdx, 0x38(%rsp)
   11ab8:      	movq	0x30(%rsp), %r12
   11abd:      	cmpq	0x18(%rsp), %r12
   11ac2:      	jne	0x11acf <generic_rawtp_path+0x69cf>
   11ac4:      	cmpq	0x20(%rsp), %rdx
   11ac9:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   11acf:      	movl	$0x4, %eax
   11ad4:      	leaq	0x10(%rsp), %rdi
   11ad9:      	movl	$0x8, %esi
   11ade:      	callq	*%rax
   11ae0:      	cmpq	0x10(%rsp), %r12
   11ae5:      	je	0x11bdd <generic_rawtp_path+0x6add>
   11aeb:      	leaq	0x18(%r12), %rbx
   11af0:      	movl	$0x4, %eax
   11af5:      	movq	%rbp, %rdi
   11af8:      	movl	$0x8, %esi
   11afd:      	movq	%rbx, %rdx
   11b00:      	callq	*%rax
   11b02:      	cmpq	%r12, (%rsp)
   11b06:      	je	0x11bdd <generic_rawtp_path+0x6add>
   11b0c:      	movl	$0x4, %eax
   11b11:      	leaq	0x8(%rsp), %rdi
   11b16:      	movl	$0x8, %esi
   11b1b:      	movq	%rbx, %rdx
   11b1e:      	callq	*%rax
   11b20:      	addq	$0x20, %r12
   11b24:      	movl	$0x4, %eax
   11b29:      	leaq	0x58(%rsp), %rdi
   11b2e:      	movl	$0x10, %ecx
   11b33:      	movl	$0x10, %esi
   11b38:      	movq	%r12, %rdx
   11b3b:      	callq	*%rax
   11b3d:      	movq	0x28(%rsp), %rbx
   11b42:      	movq	0x48(%rsp), %rax
   11b47:      	movl	0x5c(%rsp), %r15d
   11b4c:      	subq	%rbx, %rax
   11b4f:      	movl	0x50(%rsp), %r12d
   11b54:      	movl	%r15d, %edx
   11b57:      	subl	%r12d, %edx
   11b5a:      	movl	$0x0, %ecx
   11b5f:      	cmovbl	%ecx, %edx
   11b62:      	addq	0x60(%rsp), %rdx
   11b67:      	xorl	%esi, %esi
   11b69:      	cmpl	%r15d, %r12d
   11b6c:      	seta	%sil
   11b70:      	movl	%r15d, %ecx
   11b73:      	cmovbl	%r12d, %ecx
   11b77:      	addl	%ecx, %esi
   11b79:      	movl	%r12d, %edi
   11b7c:      	subl	%esi, %edi
   11b7e:      	movl	%edi, 0x50(%rsp)
   11b82:      	subq	%rsi, %rax
   11b85:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   11b8b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11b91:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   11b97:      	cmpl	%r15d, %r12d
   11b9a:      	jbe	0x11ba0 <generic_rawtp_path+0x6aa0>
   11b9c:      	movb	$0x2f, (%rbx,%rax)
   11ba0:      	xorl	%edi, %edi
   11ba2:      	cmpl	%r15d, %r12d
   11ba5:      	seta	%dil
   11ba9:      	movzbl	%cl, %esi
   11bac:      	addq	%rax, %rbx
   11baf:      	addq	%rbx, %rdi
   11bb2:      	movl	$0x4, %eax
   11bb7:      	callq	*%rax
   11bb9:      	movq	%rbx, 0x48(%rsp)
   11bbe:      	cmpl	%r15d, %r12d
   11bc1:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   11bc7:      	movq	0x8(%rsp), %r12
   11bcc:      	movq	%r12, 0x30(%rsp)
   11bd1:      	movq	0x38(%rsp), %rdx
   11bd6:      	movq	0x40(%rsp), %r15
   11bdb:      	jmp	0x11c2e <generic_rawtp_path+0x6b2e>
   11bdd:      	leaq	0x10(%r15), %rdx
   11be1:      	movl	$0x4, %eax
   11be6:      	movq	%rbp, %rdi
   11be9:      	movl	$0x8, %esi
   11bee:      	callq	*%rax
   11bf0:      	movq	0x40(%rsp), %rax
   11bf5:      	cmpq	(%rsp), %rax
   11bf9:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   11bff:      	addq	$0x18, %r15
   11c03:      	movl	$0x4, %eax
   11c08:      	leaq	0x30(%rsp), %rdi
   11c0d:      	movl	$0x8, %esi
   11c12:      	movq	%r15, %rdx
   11c15:      	callq	*%rax
   11c17:      	movq	(%rsp), %r15
   11c1b:      	movq	%r15, 0x40(%rsp)
   11c20:      	leaq	0x20(%r15), %rdx
   11c24:      	movq	%rdx, 0x38(%rsp)
   11c29:      	movq	0x30(%rsp), %r12
   11c2e:      	cmpq	0x18(%rsp), %r12
   11c33:      	jne	0x11c40 <generic_rawtp_path+0x6b40>
   11c35:      	cmpq	0x20(%rsp), %rdx
   11c3a:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   11c40:      	movl	$0x4, %eax
   11c45:      	leaq	0x10(%rsp), %rdi
   11c4a:      	movl	$0x8, %esi
   11c4f:      	callq	*%rax
   11c51:      	cmpq	0x10(%rsp), %r12
   11c56:      	je	0x11d4e <generic_rawtp_path+0x6c4e>
   11c5c:      	leaq	0x18(%r12), %rbx
   11c61:      	movl	$0x4, %eax
   11c66:      	movq	%rbp, %rdi
   11c69:      	movl	$0x8, %esi
   11c6e:      	movq	%rbx, %rdx
   11c71:      	callq	*%rax
   11c73:      	cmpq	%r12, (%rsp)
   11c77:      	je	0x11d4e <generic_rawtp_path+0x6c4e>
   11c7d:      	movl	$0x4, %eax
   11c82:      	leaq	0x8(%rsp), %rdi
   11c87:      	movl	$0x8, %esi
   11c8c:      	movq	%rbx, %rdx
   11c8f:      	callq	*%rax
   11c91:      	addq	$0x20, %r12
   11c95:      	movl	$0x4, %eax
   11c9a:      	leaq	0x58(%rsp), %rdi
   11c9f:      	movl	$0x10, %ecx
   11ca4:      	movl	$0x10, %esi
   11ca9:      	movq	%r12, %rdx
   11cac:      	callq	*%rax
   11cae:      	movq	0x28(%rsp), %rbx
   11cb3:      	movq	0x48(%rsp), %rax
   11cb8:      	movl	0x5c(%rsp), %r15d
   11cbd:      	subq	%rbx, %rax
   11cc0:      	movl	0x50(%rsp), %r12d
   11cc5:      	movl	%r15d, %edx
   11cc8:      	subl	%r12d, %edx
   11ccb:      	movl	$0x0, %ecx
   11cd0:      	cmovbl	%ecx, %edx
   11cd3:      	addq	0x60(%rsp), %rdx
   11cd8:      	xorl	%esi, %esi
   11cda:      	cmpl	%r15d, %r12d
   11cdd:      	seta	%sil
   11ce1:      	movl	%r15d, %ecx
   11ce4:      	cmovbl	%r12d, %ecx
   11ce8:      	addl	%ecx, %esi
   11cea:      	movl	%r12d, %edi
   11ced:      	subl	%esi, %edi
   11cef:      	movl	%edi, 0x50(%rsp)
   11cf3:      	subq	%rsi, %rax
   11cf6:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   11cfc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11d02:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   11d08:      	cmpl	%r15d, %r12d
   11d0b:      	jbe	0x11d11 <generic_rawtp_path+0x6c11>
   11d0d:      	movb	$0x2f, (%rbx,%rax)
   11d11:      	xorl	%edi, %edi
   11d13:      	cmpl	%r15d, %r12d
   11d16:      	seta	%dil
   11d1a:      	movzbl	%cl, %esi
   11d1d:      	addq	%rax, %rbx
   11d20:      	addq	%rbx, %rdi
   11d23:      	movl	$0x4, %eax
   11d28:      	callq	*%rax
   11d2a:      	movq	%rbx, 0x48(%rsp)
   11d2f:      	cmpl	%r15d, %r12d
   11d32:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   11d38:      	movq	0x8(%rsp), %r12
   11d3d:      	movq	%r12, 0x30(%rsp)
   11d42:      	movq	0x38(%rsp), %rdx
   11d47:      	movq	0x40(%rsp), %r15
   11d4c:      	jmp	0x11d9f <generic_rawtp_path+0x6c9f>
   11d4e:      	leaq	0x10(%r15), %rdx
   11d52:      	movl	$0x4, %eax
   11d57:      	movq	%rbp, %rdi
   11d5a:      	movl	$0x8, %esi
   11d5f:      	callq	*%rax
   11d61:      	movq	0x40(%rsp), %rax
   11d66:      	cmpq	(%rsp), %rax
   11d6a:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   11d70:      	addq	$0x18, %r15
   11d74:      	movl	$0x4, %eax
   11d79:      	leaq	0x30(%rsp), %rdi
   11d7e:      	movl	$0x8, %esi
   11d83:      	movq	%r15, %rdx
   11d86:      	callq	*%rax
   11d88:      	movq	(%rsp), %r15
   11d8c:      	movq	%r15, 0x40(%rsp)
   11d91:      	leaq	0x20(%r15), %rdx
   11d95:      	movq	%rdx, 0x38(%rsp)
   11d9a:      	movq	0x30(%rsp), %r12
   11d9f:      	cmpq	0x18(%rsp), %r12
   11da4:      	jne	0x11db1 <generic_rawtp_path+0x6cb1>
   11da6:      	cmpq	0x20(%rsp), %rdx
   11dab:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   11db1:      	movl	$0x4, %eax
   11db6:      	leaq	0x10(%rsp), %rdi
   11dbb:      	movl	$0x8, %esi
   11dc0:      	callq	*%rax
   11dc2:      	cmpq	0x10(%rsp), %r12
   11dc7:      	je	0x11ebf <generic_rawtp_path+0x6dbf>
   11dcd:      	leaq	0x18(%r12), %rbx
   11dd2:      	movl	$0x4, %eax
   11dd7:      	movq	%rbp, %rdi
   11dda:      	movl	$0x8, %esi
   11ddf:      	movq	%rbx, %rdx
   11de2:      	callq	*%rax
   11de4:      	cmpq	%r12, (%rsp)
   11de8:      	je	0x11ebf <generic_rawtp_path+0x6dbf>
   11dee:      	movl	$0x4, %eax
   11df3:      	leaq	0x8(%rsp), %rdi
   11df8:      	movl	$0x8, %esi
   11dfd:      	movq	%rbx, %rdx
   11e00:      	callq	*%rax
   11e02:      	addq	$0x20, %r12
   11e06:      	movl	$0x4, %eax
   11e0b:      	leaq	0x58(%rsp), %rdi
   11e10:      	movl	$0x10, %ecx
   11e15:      	movl	$0x10, %esi
   11e1a:      	movq	%r12, %rdx
   11e1d:      	callq	*%rax
   11e1f:      	movq	0x28(%rsp), %rbx
   11e24:      	movq	0x48(%rsp), %rax
   11e29:      	movl	0x5c(%rsp), %r15d
   11e2e:      	subq	%rbx, %rax
   11e31:      	movl	0x50(%rsp), %r12d
   11e36:      	movl	%r15d, %edx
   11e39:      	subl	%r12d, %edx
   11e3c:      	movl	$0x0, %ecx
   11e41:      	cmovbl	%ecx, %edx
   11e44:      	addq	0x60(%rsp), %rdx
   11e49:      	xorl	%esi, %esi
   11e4b:      	cmpl	%r15d, %r12d
   11e4e:      	seta	%sil
   11e52:      	movl	%r15d, %ecx
   11e55:      	cmovbl	%r12d, %ecx
   11e59:      	addl	%ecx, %esi
   11e5b:      	movl	%r12d, %edi
   11e5e:      	subl	%esi, %edi
   11e60:      	movl	%edi, 0x50(%rsp)
   11e64:      	subq	%rsi, %rax
   11e67:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   11e6d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11e73:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   11e79:      	cmpl	%r15d, %r12d
   11e7c:      	jbe	0x11e82 <generic_rawtp_path+0x6d82>
   11e7e:      	movb	$0x2f, (%rbx,%rax)
   11e82:      	xorl	%edi, %edi
   11e84:      	cmpl	%r15d, %r12d
   11e87:      	seta	%dil
   11e8b:      	movzbl	%cl, %esi
   11e8e:      	addq	%rax, %rbx
   11e91:      	addq	%rbx, %rdi
   11e94:      	movl	$0x4, %eax
   11e99:      	callq	*%rax
   11e9b:      	movq	%rbx, 0x48(%rsp)
   11ea0:      	cmpl	%r15d, %r12d
   11ea3:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   11ea9:      	movq	0x8(%rsp), %r12
   11eae:      	movq	%r12, 0x30(%rsp)
   11eb3:      	movq	0x38(%rsp), %rdx
   11eb8:      	movq	0x40(%rsp), %r15
   11ebd:      	jmp	0x11f10 <generic_rawtp_path+0x6e10>
   11ebf:      	leaq	0x10(%r15), %rdx
   11ec3:      	movl	$0x4, %eax
   11ec8:      	movq	%rbp, %rdi
   11ecb:      	movl	$0x8, %esi
   11ed0:      	callq	*%rax
   11ed2:      	movq	0x40(%rsp), %rax
   11ed7:      	cmpq	(%rsp), %rax
   11edb:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   11ee1:      	addq	$0x18, %r15
   11ee5:      	movl	$0x4, %eax
   11eea:      	leaq	0x30(%rsp), %rdi
   11eef:      	movl	$0x8, %esi
   11ef4:      	movq	%r15, %rdx
   11ef7:      	callq	*%rax
   11ef9:      	movq	(%rsp), %r15
   11efd:      	movq	%r15, 0x40(%rsp)
   11f02:      	leaq	0x20(%r15), %rdx
   11f06:      	movq	%rdx, 0x38(%rsp)
   11f0b:      	movq	0x30(%rsp), %r12
   11f10:      	cmpq	0x18(%rsp), %r12
   11f15:      	jne	0x11f22 <generic_rawtp_path+0x6e22>
   11f17:      	cmpq	0x20(%rsp), %rdx
   11f1c:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   11f22:      	movl	$0x4, %eax
   11f27:      	leaq	0x10(%rsp), %rdi
   11f2c:      	movl	$0x8, %esi
   11f31:      	callq	*%rax
   11f33:      	cmpq	0x10(%rsp), %r12
   11f38:      	je	0x12030 <generic_rawtp_path+0x6f30>
   11f3e:      	leaq	0x18(%r12), %rbx
   11f43:      	movl	$0x4, %eax
   11f48:      	movq	%rbp, %rdi
   11f4b:      	movl	$0x8, %esi
   11f50:      	movq	%rbx, %rdx
   11f53:      	callq	*%rax
   11f55:      	cmpq	%r12, (%rsp)
   11f59:      	je	0x12030 <generic_rawtp_path+0x6f30>
   11f5f:      	movl	$0x4, %eax
   11f64:      	leaq	0x8(%rsp), %rdi
   11f69:      	movl	$0x8, %esi
   11f6e:      	movq	%rbx, %rdx
   11f71:      	callq	*%rax
   11f73:      	addq	$0x20, %r12
   11f77:      	movl	$0x4, %eax
   11f7c:      	leaq	0x58(%rsp), %rdi
   11f81:      	movl	$0x10, %ecx
   11f86:      	movl	$0x10, %esi
   11f8b:      	movq	%r12, %rdx
   11f8e:      	callq	*%rax
   11f90:      	movq	0x28(%rsp), %rbx
   11f95:      	movq	0x48(%rsp), %rax
   11f9a:      	movl	0x5c(%rsp), %r15d
   11f9f:      	subq	%rbx, %rax
   11fa2:      	movl	0x50(%rsp), %r12d
   11fa7:      	movl	%r15d, %edx
   11faa:      	subl	%r12d, %edx
   11fad:      	movl	$0x0, %ecx
   11fb2:      	cmovbl	%ecx, %edx
   11fb5:      	addq	0x60(%rsp), %rdx
   11fba:      	xorl	%esi, %esi
   11fbc:      	cmpl	%r15d, %r12d
   11fbf:      	seta	%sil
   11fc3:      	movl	%r15d, %ecx
   11fc6:      	cmovbl	%r12d, %ecx
   11fca:      	addl	%ecx, %esi
   11fcc:      	movl	%r12d, %edi
   11fcf:      	subl	%esi, %edi
   11fd1:      	movl	%edi, 0x50(%rsp)
   11fd5:      	subq	%rsi, %rax
   11fd8:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   11fde:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11fe4:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   11fea:      	cmpl	%r15d, %r12d
   11fed:      	jbe	0x11ff3 <generic_rawtp_path+0x6ef3>
   11fef:      	movb	$0x2f, (%rbx,%rax)
   11ff3:      	xorl	%edi, %edi
   11ff5:      	cmpl	%r15d, %r12d
   11ff8:      	seta	%dil
   11ffc:      	movzbl	%cl, %esi
   11fff:      	addq	%rax, %rbx
   12002:      	addq	%rbx, %rdi
   12005:      	movl	$0x4, %eax
   1200a:      	callq	*%rax
   1200c:      	movq	%rbx, 0x48(%rsp)
   12011:      	cmpl	%r15d, %r12d
   12014:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   1201a:      	movq	0x8(%rsp), %r12
   1201f:      	movq	%r12, 0x30(%rsp)
   12024:      	movq	0x38(%rsp), %rdx
   12029:      	movq	0x40(%rsp), %r15
   1202e:      	jmp	0x12081 <generic_rawtp_path+0x6f81>
   12030:      	leaq	0x10(%r15), %rdx
   12034:      	movl	$0x4, %eax
   12039:      	movq	%rbp, %rdi
   1203c:      	movl	$0x8, %esi
   12041:      	callq	*%rax
   12043:      	movq	0x40(%rsp), %rax
   12048:      	cmpq	(%rsp), %rax
   1204c:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   12052:      	addq	$0x18, %r15
   12056:      	movl	$0x4, %eax
   1205b:      	leaq	0x30(%rsp), %rdi
   12060:      	movl	$0x8, %esi
   12065:      	movq	%r15, %rdx
   12068:      	callq	*%rax
   1206a:      	movq	(%rsp), %r15
   1206e:      	movq	%r15, 0x40(%rsp)
   12073:      	leaq	0x20(%r15), %rdx
   12077:      	movq	%rdx, 0x38(%rsp)
   1207c:      	movq	0x30(%rsp), %r12
   12081:      	cmpq	0x18(%rsp), %r12
   12086:      	jne	0x12093 <generic_rawtp_path+0x6f93>
   12088:      	cmpq	0x20(%rsp), %rdx
   1208d:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   12093:      	movl	$0x4, %eax
   12098:      	leaq	0x10(%rsp), %rdi
   1209d:      	movl	$0x8, %esi
   120a2:      	callq	*%rax
   120a4:      	cmpq	0x10(%rsp), %r12
   120a9:      	je	0x121a1 <generic_rawtp_path+0x70a1>
   120af:      	leaq	0x18(%r12), %rbx
   120b4:      	movl	$0x4, %eax
   120b9:      	movq	%rbp, %rdi
   120bc:      	movl	$0x8, %esi
   120c1:      	movq	%rbx, %rdx
   120c4:      	callq	*%rax
   120c6:      	cmpq	%r12, (%rsp)
   120ca:      	je	0x121a1 <generic_rawtp_path+0x70a1>
   120d0:      	movl	$0x4, %eax
   120d5:      	leaq	0x8(%rsp), %rdi
   120da:      	movl	$0x8, %esi
   120df:      	movq	%rbx, %rdx
   120e2:      	callq	*%rax
   120e4:      	addq	$0x20, %r12
   120e8:      	movl	$0x4, %eax
   120ed:      	leaq	0x58(%rsp), %rdi
   120f2:      	movl	$0x10, %ecx
   120f7:      	movl	$0x10, %esi
   120fc:      	movq	%r12, %rdx
   120ff:      	callq	*%rax
   12101:      	movq	0x28(%rsp), %rbx
   12106:      	movq	0x48(%rsp), %rax
   1210b:      	movl	0x5c(%rsp), %r15d
   12110:      	subq	%rbx, %rax
   12113:      	movl	0x50(%rsp), %r12d
   12118:      	movl	%r15d, %edx
   1211b:      	subl	%r12d, %edx
   1211e:      	movl	$0x0, %ecx
   12123:      	cmovbl	%ecx, %edx
   12126:      	addq	0x60(%rsp), %rdx
   1212b:      	xorl	%esi, %esi
   1212d:      	cmpl	%r15d, %r12d
   12130:      	seta	%sil
   12134:      	movl	%r15d, %ecx
   12137:      	cmovbl	%r12d, %ecx
   1213b:      	addl	%ecx, %esi
   1213d:      	movl	%r12d, %edi
   12140:      	subl	%esi, %edi
   12142:      	movl	%edi, 0x50(%rsp)
   12146:      	subq	%rsi, %rax
   12149:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   1214f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12155:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   1215b:      	cmpl	%r15d, %r12d
   1215e:      	jbe	0x12164 <generic_rawtp_path+0x7064>
   12160:      	movb	$0x2f, (%rbx,%rax)
   12164:      	xorl	%edi, %edi
   12166:      	cmpl	%r15d, %r12d
   12169:      	seta	%dil
   1216d:      	movzbl	%cl, %esi
   12170:      	addq	%rax, %rbx
   12173:      	addq	%rbx, %rdi
   12176:      	movl	$0x4, %eax
   1217b:      	callq	*%rax
   1217d:      	movq	%rbx, 0x48(%rsp)
   12182:      	cmpl	%r15d, %r12d
   12185:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   1218b:      	movq	0x8(%rsp), %r12
   12190:      	movq	%r12, 0x30(%rsp)
   12195:      	movq	0x38(%rsp), %rdx
   1219a:      	movq	0x40(%rsp), %r15
   1219f:      	jmp	0x121f2 <generic_rawtp_path+0x70f2>
   121a1:      	leaq	0x10(%r15), %rdx
   121a5:      	movl	$0x4, %eax
   121aa:      	movq	%rbp, %rdi
   121ad:      	movl	$0x8, %esi
   121b2:      	callq	*%rax
   121b4:      	movq	0x40(%rsp), %rax
   121b9:      	cmpq	(%rsp), %rax
   121bd:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   121c3:      	addq	$0x18, %r15
   121c7:      	movl	$0x4, %eax
   121cc:      	leaq	0x30(%rsp), %rdi
   121d1:      	movl	$0x8, %esi
   121d6:      	movq	%r15, %rdx
   121d9:      	callq	*%rax
   121db:      	movq	(%rsp), %r15
   121df:      	movq	%r15, 0x40(%rsp)
   121e4:      	leaq	0x20(%r15), %rdx
   121e8:      	movq	%rdx, 0x38(%rsp)
   121ed:      	movq	0x30(%rsp), %r12
   121f2:      	cmpq	0x18(%rsp), %r12
   121f7:      	jne	0x12204 <generic_rawtp_path+0x7104>
   121f9:      	cmpq	0x20(%rsp), %rdx
   121fe:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   12204:      	movl	$0x4, %eax
   12209:      	leaq	0x10(%rsp), %rdi
   1220e:      	movl	$0x8, %esi
   12213:      	callq	*%rax
   12215:      	cmpq	0x10(%rsp), %r12
   1221a:      	je	0x12312 <generic_rawtp_path+0x7212>
   12220:      	leaq	0x18(%r12), %rbx
   12225:      	movl	$0x4, %eax
   1222a:      	movq	%rbp, %rdi
   1222d:      	movl	$0x8, %esi
   12232:      	movq	%rbx, %rdx
   12235:      	callq	*%rax
   12237:      	cmpq	%r12, (%rsp)
   1223b:      	je	0x12312 <generic_rawtp_path+0x7212>
   12241:      	movl	$0x4, %eax
   12246:      	leaq	0x8(%rsp), %rdi
   1224b:      	movl	$0x8, %esi
   12250:      	movq	%rbx, %rdx
   12253:      	callq	*%rax
   12255:      	addq	$0x20, %r12
   12259:      	movl	$0x4, %eax
   1225e:      	leaq	0x58(%rsp), %rdi
   12263:      	movl	$0x10, %ecx
   12268:      	movl	$0x10, %esi
   1226d:      	movq	%r12, %rdx
   12270:      	callq	*%rax
   12272:      	movq	0x28(%rsp), %rbx
   12277:      	movq	0x48(%rsp), %rax
   1227c:      	movl	0x5c(%rsp), %r15d
   12281:      	subq	%rbx, %rax
   12284:      	movl	0x50(%rsp), %r12d
   12289:      	movl	%r15d, %edx
   1228c:      	subl	%r12d, %edx
   1228f:      	movl	$0x0, %ecx
   12294:      	cmovbl	%ecx, %edx
   12297:      	addq	0x60(%rsp), %rdx
   1229c:      	xorl	%esi, %esi
   1229e:      	cmpl	%r15d, %r12d
   122a1:      	seta	%sil
   122a5:      	movl	%r15d, %ecx
   122a8:      	cmovbl	%r12d, %ecx
   122ac:      	addl	%ecx, %esi
   122ae:      	movl	%r12d, %edi
   122b1:      	subl	%esi, %edi
   122b3:      	movl	%edi, 0x50(%rsp)
   122b7:      	subq	%rsi, %rax
   122ba:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   122c0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   122c6:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   122cc:      	cmpl	%r15d, %r12d
   122cf:      	jbe	0x122d5 <generic_rawtp_path+0x71d5>
   122d1:      	movb	$0x2f, (%rbx,%rax)
   122d5:      	xorl	%edi, %edi
   122d7:      	cmpl	%r15d, %r12d
   122da:      	seta	%dil
   122de:      	movzbl	%cl, %esi
   122e1:      	addq	%rax, %rbx
   122e4:      	addq	%rbx, %rdi
   122e7:      	movl	$0x4, %eax
   122ec:      	callq	*%rax
   122ee:      	movq	%rbx, 0x48(%rsp)
   122f3:      	cmpl	%r15d, %r12d
   122f6:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   122fc:      	movq	0x8(%rsp), %r12
   12301:      	movq	%r12, 0x30(%rsp)
   12306:      	movq	0x38(%rsp), %rdx
   1230b:      	movq	0x40(%rsp), %r15
   12310:      	jmp	0x12363 <generic_rawtp_path+0x7263>
   12312:      	leaq	0x10(%r15), %rdx
   12316:      	movl	$0x4, %eax
   1231b:      	movq	%rbp, %rdi
   1231e:      	movl	$0x8, %esi
   12323:      	callq	*%rax
   12325:      	movq	0x40(%rsp), %rax
   1232a:      	cmpq	(%rsp), %rax
   1232e:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   12334:      	addq	$0x18, %r15
   12338:      	movl	$0x4, %eax
   1233d:      	leaq	0x30(%rsp), %rdi
   12342:      	movl	$0x8, %esi
   12347:      	movq	%r15, %rdx
   1234a:      	callq	*%rax
   1234c:      	movq	(%rsp), %r15
   12350:      	movq	%r15, 0x40(%rsp)
   12355:      	leaq	0x20(%r15), %rdx
   12359:      	movq	%rdx, 0x38(%rsp)
   1235e:      	movq	0x30(%rsp), %r12
   12363:      	cmpq	0x18(%rsp), %r12
   12368:      	jne	0x12375 <generic_rawtp_path+0x7275>
   1236a:      	cmpq	0x20(%rsp), %rdx
   1236f:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   12375:      	movl	$0x4, %eax
   1237a:      	leaq	0x10(%rsp), %rdi
   1237f:      	movl	$0x8, %esi
   12384:      	callq	*%rax
   12386:      	cmpq	0x10(%rsp), %r12
   1238b:      	je	0x12483 <generic_rawtp_path+0x7383>
   12391:      	leaq	0x18(%r12), %rbx
   12396:      	movl	$0x4, %eax
   1239b:      	movq	%rbp, %rdi
   1239e:      	movl	$0x8, %esi
   123a3:      	movq	%rbx, %rdx
   123a6:      	callq	*%rax
   123a8:      	cmpq	%r12, (%rsp)
   123ac:      	je	0x12483 <generic_rawtp_path+0x7383>
   123b2:      	movl	$0x4, %eax
   123b7:      	leaq	0x8(%rsp), %rdi
   123bc:      	movl	$0x8, %esi
   123c1:      	movq	%rbx, %rdx
   123c4:      	callq	*%rax
   123c6:      	addq	$0x20, %r12
   123ca:      	movl	$0x4, %eax
   123cf:      	leaq	0x58(%rsp), %rdi
   123d4:      	movl	$0x10, %ecx
   123d9:      	movl	$0x10, %esi
   123de:      	movq	%r12, %rdx
   123e1:      	callq	*%rax
   123e3:      	movq	0x28(%rsp), %rbx
   123e8:      	movq	0x48(%rsp), %rax
   123ed:      	movl	0x5c(%rsp), %r15d
   123f2:      	subq	%rbx, %rax
   123f5:      	movl	0x50(%rsp), %r12d
   123fa:      	movl	%r15d, %edx
   123fd:      	subl	%r12d, %edx
   12400:      	movl	$0x0, %ecx
   12405:      	cmovbl	%ecx, %edx
   12408:      	addq	0x60(%rsp), %rdx
   1240d:      	xorl	%esi, %esi
   1240f:      	cmpl	%r15d, %r12d
   12412:      	seta	%sil
   12416:      	movl	%r15d, %ecx
   12419:      	cmovbl	%r12d, %ecx
   1241d:      	addl	%ecx, %esi
   1241f:      	movl	%r12d, %edi
   12422:      	subl	%esi, %edi
   12424:      	movl	%edi, 0x50(%rsp)
   12428:      	subq	%rsi, %rax
   1242b:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   12431:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12437:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   1243d:      	cmpl	%r15d, %r12d
   12440:      	jbe	0x12446 <generic_rawtp_path+0x7346>
   12442:      	movb	$0x2f, (%rbx,%rax)
   12446:      	xorl	%edi, %edi
   12448:      	cmpl	%r15d, %r12d
   1244b:      	seta	%dil
   1244f:      	movzbl	%cl, %esi
   12452:      	addq	%rax, %rbx
   12455:      	addq	%rbx, %rdi
   12458:      	movl	$0x4, %eax
   1245d:      	callq	*%rax
   1245f:      	movq	%rbx, 0x48(%rsp)
   12464:      	cmpl	%r15d, %r12d
   12467:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   1246d:      	movq	0x8(%rsp), %r12
   12472:      	movq	%r12, 0x30(%rsp)
   12477:      	movq	0x38(%rsp), %rdx
   1247c:      	movq	0x40(%rsp), %r15
   12481:      	jmp	0x124d4 <generic_rawtp_path+0x73d4>
   12483:      	leaq	0x10(%r15), %rdx
   12487:      	movl	$0x4, %eax
   1248c:      	movq	%rbp, %rdi
   1248f:      	movl	$0x8, %esi
   12494:      	callq	*%rax
   12496:      	movq	0x40(%rsp), %rax
   1249b:      	cmpq	(%rsp), %rax
   1249f:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   124a5:      	addq	$0x18, %r15
   124a9:      	movl	$0x4, %eax
   124ae:      	leaq	0x30(%rsp), %rdi
   124b3:      	movl	$0x8, %esi
   124b8:      	movq	%r15, %rdx
   124bb:      	callq	*%rax
   124bd:      	movq	(%rsp), %r15
   124c1:      	movq	%r15, 0x40(%rsp)
   124c6:      	leaq	0x20(%r15), %rdx
   124ca:      	movq	%rdx, 0x38(%rsp)
   124cf:      	movq	0x30(%rsp), %r12
   124d4:      	cmpq	0x18(%rsp), %r12
   124d9:      	jne	0x124e6 <generic_rawtp_path+0x73e6>
   124db:      	cmpq	0x20(%rsp), %rdx
   124e0:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   124e6:      	movl	$0x4, %eax
   124eb:      	leaq	0x10(%rsp), %rdi
   124f0:      	movl	$0x8, %esi
   124f5:      	callq	*%rax
   124f7:      	cmpq	0x10(%rsp), %r12
   124fc:      	je	0x125f4 <generic_rawtp_path+0x74f4>
   12502:      	leaq	0x18(%r12), %rbx
   12507:      	movl	$0x4, %eax
   1250c:      	movq	%rbp, %rdi
   1250f:      	movl	$0x8, %esi
   12514:      	movq	%rbx, %rdx
   12517:      	callq	*%rax
   12519:      	cmpq	%r12, (%rsp)
   1251d:      	je	0x125f4 <generic_rawtp_path+0x74f4>
   12523:      	movl	$0x4, %eax
   12528:      	leaq	0x8(%rsp), %rdi
   1252d:      	movl	$0x8, %esi
   12532:      	movq	%rbx, %rdx
   12535:      	callq	*%rax
   12537:      	addq	$0x20, %r12
   1253b:      	movl	$0x4, %eax
   12540:      	leaq	0x58(%rsp), %rdi
   12545:      	movl	$0x10, %ecx
   1254a:      	movl	$0x10, %esi
   1254f:      	movq	%r12, %rdx
   12552:      	callq	*%rax
   12554:      	movq	0x28(%rsp), %rbx
   12559:      	movq	0x48(%rsp), %rax
   1255e:      	movl	0x5c(%rsp), %r15d
   12563:      	subq	%rbx, %rax
   12566:      	movl	0x50(%rsp), %r12d
   1256b:      	movl	%r15d, %edx
   1256e:      	subl	%r12d, %edx
   12571:      	movl	$0x0, %ecx
   12576:      	cmovbl	%ecx, %edx
   12579:      	addq	0x60(%rsp), %rdx
   1257e:      	xorl	%esi, %esi
   12580:      	cmpl	%r15d, %r12d
   12583:      	seta	%sil
   12587:      	movl	%r15d, %ecx
   1258a:      	cmovbl	%r12d, %ecx
   1258e:      	addl	%ecx, %esi
   12590:      	movl	%r12d, %edi
   12593:      	subl	%esi, %edi
   12595:      	movl	%edi, 0x50(%rsp)
   12599:      	subq	%rsi, %rax
   1259c:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   125a2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   125a8:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   125ae:      	cmpl	%r15d, %r12d
   125b1:      	jbe	0x125b7 <generic_rawtp_path+0x74b7>
   125b3:      	movb	$0x2f, (%rbx,%rax)
   125b7:      	xorl	%edi, %edi
   125b9:      	cmpl	%r15d, %r12d
   125bc:      	seta	%dil
   125c0:      	movzbl	%cl, %esi
   125c3:      	addq	%rax, %rbx
   125c6:      	addq	%rbx, %rdi
   125c9:      	movl	$0x4, %eax
   125ce:      	callq	*%rax
   125d0:      	movq	%rbx, 0x48(%rsp)
   125d5:      	cmpl	%r15d, %r12d
   125d8:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   125de:      	movq	0x8(%rsp), %r12
   125e3:      	movq	%r12, 0x30(%rsp)
   125e8:      	movq	0x38(%rsp), %rdx
   125ed:      	movq	0x40(%rsp), %r15
   125f2:      	jmp	0x12645 <generic_rawtp_path+0x7545>
   125f4:      	leaq	0x10(%r15), %rdx
   125f8:      	movl	$0x4, %eax
   125fd:      	movq	%rbp, %rdi
   12600:      	movl	$0x8, %esi
   12605:      	callq	*%rax
   12607:      	movq	0x40(%rsp), %rax
   1260c:      	cmpq	(%rsp), %rax
   12610:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   12616:      	addq	$0x18, %r15
   1261a:      	movl	$0x4, %eax
   1261f:      	leaq	0x30(%rsp), %rdi
   12624:      	movl	$0x8, %esi
   12629:      	movq	%r15, %rdx
   1262c:      	callq	*%rax
   1262e:      	movq	(%rsp), %r15
   12632:      	movq	%r15, 0x40(%rsp)
   12637:      	leaq	0x20(%r15), %rdx
   1263b:      	movq	%rdx, 0x38(%rsp)
   12640:      	movq	0x30(%rsp), %r12
   12645:      	cmpq	0x18(%rsp), %r12
   1264a:      	jne	0x12657 <generic_rawtp_path+0x7557>
   1264c:      	cmpq	0x20(%rsp), %rdx
   12651:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   12657:      	movl	$0x4, %eax
   1265c:      	leaq	0x10(%rsp), %rdi
   12661:      	movl	$0x8, %esi
   12666:      	callq	*%rax
   12668:      	cmpq	0x10(%rsp), %r12
   1266d:      	je	0x12765 <generic_rawtp_path+0x7665>
   12673:      	leaq	0x18(%r12), %rbx
   12678:      	movl	$0x4, %eax
   1267d:      	movq	%rbp, %rdi
   12680:      	movl	$0x8, %esi
   12685:      	movq	%rbx, %rdx
   12688:      	callq	*%rax
   1268a:      	cmpq	%r12, (%rsp)
   1268e:      	je	0x12765 <generic_rawtp_path+0x7665>
   12694:      	movl	$0x4, %eax
   12699:      	leaq	0x8(%rsp), %rdi
   1269e:      	movl	$0x8, %esi
   126a3:      	movq	%rbx, %rdx
   126a6:      	callq	*%rax
   126a8:      	addq	$0x20, %r12
   126ac:      	movl	$0x4, %eax
   126b1:      	leaq	0x58(%rsp), %rdi
   126b6:      	movl	$0x10, %ecx
   126bb:      	movl	$0x10, %esi
   126c0:      	movq	%r12, %rdx
   126c3:      	callq	*%rax
   126c5:      	movq	0x28(%rsp), %rbx
   126ca:      	movq	0x48(%rsp), %rax
   126cf:      	movl	0x5c(%rsp), %r15d
   126d4:      	subq	%rbx, %rax
   126d7:      	movl	0x50(%rsp), %r12d
   126dc:      	movl	%r15d, %edx
   126df:      	subl	%r12d, %edx
   126e2:      	movl	$0x0, %ecx
   126e7:      	cmovbl	%ecx, %edx
   126ea:      	addq	0x60(%rsp), %rdx
   126ef:      	xorl	%esi, %esi
   126f1:      	cmpl	%r15d, %r12d
   126f4:      	seta	%sil
   126f8:      	movl	%r15d, %ecx
   126fb:      	cmovbl	%r12d, %ecx
   126ff:      	addl	%ecx, %esi
   12701:      	movl	%r12d, %edi
   12704:      	subl	%esi, %edi
   12706:      	movl	%edi, 0x50(%rsp)
   1270a:      	subq	%rsi, %rax
   1270d:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   12713:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12719:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   1271f:      	cmpl	%r15d, %r12d
   12722:      	jbe	0x12728 <generic_rawtp_path+0x7628>
   12724:      	movb	$0x2f, (%rbx,%rax)
   12728:      	xorl	%edi, %edi
   1272a:      	cmpl	%r15d, %r12d
   1272d:      	seta	%dil
   12731:      	movzbl	%cl, %esi
   12734:      	addq	%rax, %rbx
   12737:      	addq	%rbx, %rdi
   1273a:      	movl	$0x4, %eax
   1273f:      	callq	*%rax
   12741:      	movq	%rbx, 0x48(%rsp)
   12746:      	cmpl	%r15d, %r12d
   12749:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   1274f:      	movq	0x8(%rsp), %r12
   12754:      	movq	%r12, 0x30(%rsp)
   12759:      	movq	0x38(%rsp), %rdx
   1275e:      	movq	0x40(%rsp), %r15
   12763:      	jmp	0x127b6 <generic_rawtp_path+0x76b6>
   12765:      	leaq	0x10(%r15), %rdx
   12769:      	movl	$0x4, %eax
   1276e:      	movq	%rbp, %rdi
   12771:      	movl	$0x8, %esi
   12776:      	callq	*%rax
   12778:      	movq	0x40(%rsp), %rax
   1277d:      	cmpq	(%rsp), %rax
   12781:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   12787:      	addq	$0x18, %r15
   1278b:      	movl	$0x4, %eax
   12790:      	leaq	0x30(%rsp), %rdi
   12795:      	movl	$0x8, %esi
   1279a:      	movq	%r15, %rdx
   1279d:      	callq	*%rax
   1279f:      	movq	(%rsp), %r15
   127a3:      	movq	%r15, 0x40(%rsp)
   127a8:      	leaq	0x20(%r15), %rdx
   127ac:      	movq	%rdx, 0x38(%rsp)
   127b1:      	movq	0x30(%rsp), %r12
   127b6:      	cmpq	0x18(%rsp), %r12
   127bb:      	jne	0x127c8 <generic_rawtp_path+0x76c8>
   127bd:      	cmpq	0x20(%rsp), %rdx
   127c2:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   127c8:      	movl	$0x4, %eax
   127cd:      	leaq	0x10(%rsp), %rdi
   127d2:      	movl	$0x8, %esi
   127d7:      	callq	*%rax
   127d9:      	cmpq	0x10(%rsp), %r12
   127de:      	je	0x128d6 <generic_rawtp_path+0x77d6>
   127e4:      	leaq	0x18(%r12), %rbx
   127e9:      	movl	$0x4, %eax
   127ee:      	movq	%rbp, %rdi
   127f1:      	movl	$0x8, %esi
   127f6:      	movq	%rbx, %rdx
   127f9:      	callq	*%rax
   127fb:      	cmpq	%r12, (%rsp)
   127ff:      	je	0x128d6 <generic_rawtp_path+0x77d6>
   12805:      	movl	$0x4, %eax
   1280a:      	leaq	0x8(%rsp), %rdi
   1280f:      	movl	$0x8, %esi
   12814:      	movq	%rbx, %rdx
   12817:      	callq	*%rax
   12819:      	addq	$0x20, %r12
   1281d:      	movl	$0x4, %eax
   12822:      	leaq	0x58(%rsp), %rdi
   12827:      	movl	$0x10, %ecx
   1282c:      	movl	$0x10, %esi
   12831:      	movq	%r12, %rdx
   12834:      	callq	*%rax
   12836:      	movq	0x28(%rsp), %rbx
   1283b:      	movq	0x48(%rsp), %rax
   12840:      	movl	0x5c(%rsp), %r15d
   12845:      	subq	%rbx, %rax
   12848:      	movl	0x50(%rsp), %r12d
   1284d:      	movl	%r15d, %edx
   12850:      	subl	%r12d, %edx
   12853:      	movl	$0x0, %ecx
   12858:      	cmovbl	%ecx, %edx
   1285b:      	addq	0x60(%rsp), %rdx
   12860:      	xorl	%esi, %esi
   12862:      	cmpl	%r15d, %r12d
   12865:      	seta	%sil
   12869:      	movl	%r15d, %ecx
   1286c:      	cmovbl	%r12d, %ecx
   12870:      	addl	%ecx, %esi
   12872:      	movl	%r12d, %edi
   12875:      	subl	%esi, %edi
   12877:      	movl	%edi, 0x50(%rsp)
   1287b:      	subq	%rsi, %rax
   1287e:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   12884:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1288a:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   12890:      	cmpl	%r15d, %r12d
   12893:      	jbe	0x12899 <generic_rawtp_path+0x7799>
   12895:      	movb	$0x2f, (%rbx,%rax)
   12899:      	xorl	%edi, %edi
   1289b:      	cmpl	%r15d, %r12d
   1289e:      	seta	%dil
   128a2:      	movzbl	%cl, %esi
   128a5:      	addq	%rax, %rbx
   128a8:      	addq	%rbx, %rdi
   128ab:      	movl	$0x4, %eax
   128b0:      	callq	*%rax
   128b2:      	movq	%rbx, 0x48(%rsp)
   128b7:      	cmpl	%r15d, %r12d
   128ba:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   128c0:      	movq	0x8(%rsp), %r12
   128c5:      	movq	%r12, 0x30(%rsp)
   128ca:      	movq	0x38(%rsp), %rdx
   128cf:      	movq	0x40(%rsp), %r15
   128d4:      	jmp	0x12927 <generic_rawtp_path+0x7827>
   128d6:      	leaq	0x10(%r15), %rdx
   128da:      	movl	$0x4, %eax
   128df:      	movq	%rbp, %rdi
   128e2:      	movl	$0x8, %esi
   128e7:      	callq	*%rax
   128e9:      	movq	0x40(%rsp), %rax
   128ee:      	cmpq	(%rsp), %rax
   128f2:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   128f8:      	addq	$0x18, %r15
   128fc:      	movl	$0x4, %eax
   12901:      	leaq	0x30(%rsp), %rdi
   12906:      	movl	$0x8, %esi
   1290b:      	movq	%r15, %rdx
   1290e:      	callq	*%rax
   12910:      	movq	(%rsp), %r15
   12914:      	movq	%r15, 0x40(%rsp)
   12919:      	leaq	0x20(%r15), %rdx
   1291d:      	movq	%rdx, 0x38(%rsp)
   12922:      	movq	0x30(%rsp), %r12
   12927:      	cmpq	0x18(%rsp), %r12
   1292c:      	jne	0x12939 <generic_rawtp_path+0x7839>
   1292e:      	cmpq	0x20(%rsp), %rdx
   12933:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   12939:      	movl	$0x4, %eax
   1293e:      	leaq	0x10(%rsp), %rdi
   12943:      	movl	$0x8, %esi
   12948:      	callq	*%rax
   1294a:      	cmpq	0x10(%rsp), %r12
   1294f:      	je	0x12a47 <generic_rawtp_path+0x7947>
   12955:      	leaq	0x18(%r12), %rbx
   1295a:      	movl	$0x4, %eax
   1295f:      	movq	%rbp, %rdi
   12962:      	movl	$0x8, %esi
   12967:      	movq	%rbx, %rdx
   1296a:      	callq	*%rax
   1296c:      	cmpq	%r12, (%rsp)
   12970:      	je	0x12a47 <generic_rawtp_path+0x7947>
   12976:      	movl	$0x4, %eax
   1297b:      	leaq	0x8(%rsp), %rdi
   12980:      	movl	$0x8, %esi
   12985:      	movq	%rbx, %rdx
   12988:      	callq	*%rax
   1298a:      	addq	$0x20, %r12
   1298e:      	movl	$0x4, %eax
   12993:      	leaq	0x58(%rsp), %rdi
   12998:      	movl	$0x10, %ecx
   1299d:      	movl	$0x10, %esi
   129a2:      	movq	%r12, %rdx
   129a5:      	callq	*%rax
   129a7:      	movq	0x28(%rsp), %rbx
   129ac:      	movq	0x48(%rsp), %rax
   129b1:      	movl	0x5c(%rsp), %r15d
   129b6:      	subq	%rbx, %rax
   129b9:      	movl	0x50(%rsp), %r12d
   129be:      	movl	%r15d, %edx
   129c1:      	subl	%r12d, %edx
   129c4:      	movl	$0x0, %ecx
   129c9:      	cmovbl	%ecx, %edx
   129cc:      	addq	0x60(%rsp), %rdx
   129d1:      	xorl	%esi, %esi
   129d3:      	cmpl	%r15d, %r12d
   129d6:      	seta	%sil
   129da:      	movl	%r15d, %ecx
   129dd:      	cmovbl	%r12d, %ecx
   129e1:      	addl	%ecx, %esi
   129e3:      	movl	%r12d, %edi
   129e6:      	subl	%esi, %edi
   129e8:      	movl	%edi, 0x50(%rsp)
   129ec:      	subq	%rsi, %rax
   129ef:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   129f5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   129fb:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   12a01:      	cmpl	%r15d, %r12d
   12a04:      	jbe	0x12a0a <generic_rawtp_path+0x790a>
   12a06:      	movb	$0x2f, (%rbx,%rax)
   12a0a:      	xorl	%edi, %edi
   12a0c:      	cmpl	%r15d, %r12d
   12a0f:      	seta	%dil
   12a13:      	movzbl	%cl, %esi
   12a16:      	addq	%rax, %rbx
   12a19:      	addq	%rbx, %rdi
   12a1c:      	movl	$0x4, %eax
   12a21:      	callq	*%rax
   12a23:      	movq	%rbx, 0x48(%rsp)
   12a28:      	cmpl	%r15d, %r12d
   12a2b:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   12a31:      	movq	0x8(%rsp), %r12
   12a36:      	movq	%r12, 0x30(%rsp)
   12a3b:      	movq	0x38(%rsp), %rdx
   12a40:      	movq	0x40(%rsp), %r15
   12a45:      	jmp	0x12a98 <generic_rawtp_path+0x7998>
   12a47:      	leaq	0x10(%r15), %rdx
   12a4b:      	movl	$0x4, %eax
   12a50:      	movq	%rbp, %rdi
   12a53:      	movl	$0x8, %esi
   12a58:      	callq	*%rax
   12a5a:      	movq	0x40(%rsp), %rax
   12a5f:      	cmpq	(%rsp), %rax
   12a63:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   12a69:      	addq	$0x18, %r15
   12a6d:      	movl	$0x4, %eax
   12a72:      	leaq	0x30(%rsp), %rdi
   12a77:      	movl	$0x8, %esi
   12a7c:      	movq	%r15, %rdx
   12a7f:      	callq	*%rax
   12a81:      	movq	(%rsp), %r15
   12a85:      	movq	%r15, 0x40(%rsp)
   12a8a:      	leaq	0x20(%r15), %rdx
   12a8e:      	movq	%rdx, 0x38(%rsp)
   12a93:      	movq	0x30(%rsp), %r12
   12a98:      	cmpq	0x18(%rsp), %r12
   12a9d:      	jne	0x12aaa <generic_rawtp_path+0x79aa>
   12a9f:      	cmpq	0x20(%rsp), %rdx
   12aa4:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   12aaa:      	movl	$0x4, %eax
   12aaf:      	leaq	0x10(%rsp), %rdi
   12ab4:      	movl	$0x8, %esi
   12ab9:      	callq	*%rax
   12abb:      	cmpq	0x10(%rsp), %r12
   12ac0:      	je	0x12bb8 <generic_rawtp_path+0x7ab8>
   12ac6:      	leaq	0x18(%r12), %rbx
   12acb:      	movl	$0x4, %eax
   12ad0:      	movq	%rbp, %rdi
   12ad3:      	movl	$0x8, %esi
   12ad8:      	movq	%rbx, %rdx
   12adb:      	callq	*%rax
   12add:      	cmpq	%r12, (%rsp)
   12ae1:      	je	0x12bb8 <generic_rawtp_path+0x7ab8>
   12ae7:      	movl	$0x4, %eax
   12aec:      	leaq	0x8(%rsp), %rdi
   12af1:      	movl	$0x8, %esi
   12af6:      	movq	%rbx, %rdx
   12af9:      	callq	*%rax
   12afb:      	addq	$0x20, %r12
   12aff:      	movl	$0x4, %eax
   12b04:      	leaq	0x58(%rsp), %rdi
   12b09:      	movl	$0x10, %ecx
   12b0e:      	movl	$0x10, %esi
   12b13:      	movq	%r12, %rdx
   12b16:      	callq	*%rax
   12b18:      	movq	0x28(%rsp), %rbx
   12b1d:      	movq	0x48(%rsp), %rax
   12b22:      	movl	0x5c(%rsp), %r15d
   12b27:      	subq	%rbx, %rax
   12b2a:      	movl	0x50(%rsp), %r12d
   12b2f:      	movl	%r15d, %edx
   12b32:      	subl	%r12d, %edx
   12b35:      	movl	$0x0, %ecx
   12b3a:      	cmovbl	%ecx, %edx
   12b3d:      	addq	0x60(%rsp), %rdx
   12b42:      	xorl	%esi, %esi
   12b44:      	cmpl	%r15d, %r12d
   12b47:      	seta	%sil
   12b4b:      	movl	%r15d, %ecx
   12b4e:      	cmovbl	%r12d, %ecx
   12b52:      	addl	%ecx, %esi
   12b54:      	movl	%r12d, %edi
   12b57:      	subl	%esi, %edi
   12b59:      	movl	%edi, 0x50(%rsp)
   12b5d:      	subq	%rsi, %rax
   12b60:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   12b66:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12b6c:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   12b72:      	cmpl	%r15d, %r12d
   12b75:      	jbe	0x12b7b <generic_rawtp_path+0x7a7b>
   12b77:      	movb	$0x2f, (%rbx,%rax)
   12b7b:      	xorl	%edi, %edi
   12b7d:      	cmpl	%r15d, %r12d
   12b80:      	seta	%dil
   12b84:      	movzbl	%cl, %esi
   12b87:      	addq	%rax, %rbx
   12b8a:      	addq	%rbx, %rdi
   12b8d:      	movl	$0x4, %eax
   12b92:      	callq	*%rax
   12b94:      	movq	%rbx, 0x48(%rsp)
   12b99:      	cmpl	%r15d, %r12d
   12b9c:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   12ba2:      	movq	0x8(%rsp), %r12
   12ba7:      	movq	%r12, 0x30(%rsp)
   12bac:      	movq	0x38(%rsp), %rdx
   12bb1:      	movq	0x40(%rsp), %r15
   12bb6:      	jmp	0x12c09 <generic_rawtp_path+0x7b09>
   12bb8:      	leaq	0x10(%r15), %rdx
   12bbc:      	movl	$0x4, %eax
   12bc1:      	movq	%rbp, %rdi
   12bc4:      	movl	$0x8, %esi
   12bc9:      	callq	*%rax
   12bcb:      	movq	0x40(%rsp), %rax
   12bd0:      	cmpq	(%rsp), %rax
   12bd4:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   12bda:      	addq	$0x18, %r15
   12bde:      	movl	$0x4, %eax
   12be3:      	leaq	0x30(%rsp), %rdi
   12be8:      	movl	$0x8, %esi
   12bed:      	movq	%r15, %rdx
   12bf0:      	callq	*%rax
   12bf2:      	movq	(%rsp), %r15
   12bf6:      	movq	%r15, 0x40(%rsp)
   12bfb:      	leaq	0x20(%r15), %rdx
   12bff:      	movq	%rdx, 0x38(%rsp)
   12c04:      	movq	0x30(%rsp), %r12
   12c09:      	cmpq	0x18(%rsp), %r12
   12c0e:      	jne	0x12c1b <generic_rawtp_path+0x7b1b>
   12c10:      	cmpq	0x20(%rsp), %rdx
   12c15:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   12c1b:      	movl	$0x4, %eax
   12c20:      	leaq	0x10(%rsp), %rdi
   12c25:      	movl	$0x8, %esi
   12c2a:      	callq	*%rax
   12c2c:      	cmpq	0x10(%rsp), %r12
   12c31:      	je	0x12d29 <generic_rawtp_path+0x7c29>
   12c37:      	leaq	0x18(%r12), %rbx
   12c3c:      	movl	$0x4, %eax
   12c41:      	movq	%rbp, %rdi
   12c44:      	movl	$0x8, %esi
   12c49:      	movq	%rbx, %rdx
   12c4c:      	callq	*%rax
   12c4e:      	cmpq	%r12, (%rsp)
   12c52:      	je	0x12d29 <generic_rawtp_path+0x7c29>
   12c58:      	movl	$0x4, %eax
   12c5d:      	leaq	0x8(%rsp), %rdi
   12c62:      	movl	$0x8, %esi
   12c67:      	movq	%rbx, %rdx
   12c6a:      	callq	*%rax
   12c6c:      	addq	$0x20, %r12
   12c70:      	movl	$0x4, %eax
   12c75:      	leaq	0x58(%rsp), %rdi
   12c7a:      	movl	$0x10, %ecx
   12c7f:      	movl	$0x10, %esi
   12c84:      	movq	%r12, %rdx
   12c87:      	callq	*%rax
   12c89:      	movq	0x28(%rsp), %rbx
   12c8e:      	movq	0x48(%rsp), %rax
   12c93:      	movl	0x5c(%rsp), %r15d
   12c98:      	subq	%rbx, %rax
   12c9b:      	movl	0x50(%rsp), %r12d
   12ca0:      	movl	%r15d, %edx
   12ca3:      	subl	%r12d, %edx
   12ca6:      	movl	$0x0, %ecx
   12cab:      	cmovbl	%ecx, %edx
   12cae:      	addq	0x60(%rsp), %rdx
   12cb3:      	xorl	%esi, %esi
   12cb5:      	cmpl	%r15d, %r12d
   12cb8:      	seta	%sil
   12cbc:      	movl	%r15d, %ecx
   12cbf:      	cmovbl	%r12d, %ecx
   12cc3:      	addl	%ecx, %esi
   12cc5:      	movl	%r12d, %edi
   12cc8:      	subl	%esi, %edi
   12cca:      	movl	%edi, 0x50(%rsp)
   12cce:      	subq	%rsi, %rax
   12cd1:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   12cd7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12cdd:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   12ce3:      	cmpl	%r15d, %r12d
   12ce6:      	jbe	0x12cec <generic_rawtp_path+0x7bec>
   12ce8:      	movb	$0x2f, (%rbx,%rax)
   12cec:      	xorl	%edi, %edi
   12cee:      	cmpl	%r15d, %r12d
   12cf1:      	seta	%dil
   12cf5:      	movzbl	%cl, %esi
   12cf8:      	addq	%rax, %rbx
   12cfb:      	addq	%rbx, %rdi
   12cfe:      	movl	$0x4, %eax
   12d03:      	callq	*%rax
   12d05:      	movq	%rbx, 0x48(%rsp)
   12d0a:      	cmpl	%r15d, %r12d
   12d0d:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   12d13:      	movq	0x8(%rsp), %r12
   12d18:      	movq	%r12, 0x30(%rsp)
   12d1d:      	movq	0x38(%rsp), %rdx
   12d22:      	movq	0x40(%rsp), %r15
   12d27:      	jmp	0x12d7a <generic_rawtp_path+0x7c7a>
   12d29:      	leaq	0x10(%r15), %rdx
   12d2d:      	movl	$0x4, %eax
   12d32:      	movq	%rbp, %rdi
   12d35:      	movl	$0x8, %esi
   12d3a:      	callq	*%rax
   12d3c:      	movq	0x40(%rsp), %rax
   12d41:      	cmpq	(%rsp), %rax
   12d45:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   12d4b:      	addq	$0x18, %r15
   12d4f:      	movl	$0x4, %eax
   12d54:      	leaq	0x30(%rsp), %rdi
   12d59:      	movl	$0x8, %esi
   12d5e:      	movq	%r15, %rdx
   12d61:      	callq	*%rax
   12d63:      	movq	(%rsp), %r15
   12d67:      	movq	%r15, 0x40(%rsp)
   12d6c:      	leaq	0x20(%r15), %rdx
   12d70:      	movq	%rdx, 0x38(%rsp)
   12d75:      	movq	0x30(%rsp), %r12
   12d7a:      	cmpq	0x18(%rsp), %r12
   12d7f:      	jne	0x12d8c <generic_rawtp_path+0x7c8c>
   12d81:      	cmpq	0x20(%rsp), %rdx
   12d86:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   12d8c:      	movl	$0x4, %eax
   12d91:      	leaq	0x10(%rsp), %rdi
   12d96:      	movl	$0x8, %esi
   12d9b:      	callq	*%rax
   12d9d:      	cmpq	0x10(%rsp), %r12
   12da2:      	je	0x12e9a <generic_rawtp_path+0x7d9a>
   12da8:      	leaq	0x18(%r12), %rbx
   12dad:      	movl	$0x4, %eax
   12db2:      	movq	%rbp, %rdi
   12db5:      	movl	$0x8, %esi
   12dba:      	movq	%rbx, %rdx
   12dbd:      	callq	*%rax
   12dbf:      	cmpq	%r12, (%rsp)
   12dc3:      	je	0x12e9a <generic_rawtp_path+0x7d9a>
   12dc9:      	movl	$0x4, %eax
   12dce:      	leaq	0x8(%rsp), %rdi
   12dd3:      	movl	$0x8, %esi
   12dd8:      	movq	%rbx, %rdx
   12ddb:      	callq	*%rax
   12ddd:      	addq	$0x20, %r12
   12de1:      	movl	$0x4, %eax
   12de6:      	leaq	0x58(%rsp), %rdi
   12deb:      	movl	$0x10, %ecx
   12df0:      	movl	$0x10, %esi
   12df5:      	movq	%r12, %rdx
   12df8:      	callq	*%rax
   12dfa:      	movq	0x28(%rsp), %rbx
   12dff:      	movq	0x48(%rsp), %rax
   12e04:      	movl	0x5c(%rsp), %r15d
   12e09:      	subq	%rbx, %rax
   12e0c:      	movl	0x50(%rsp), %r12d
   12e11:      	movl	%r15d, %edx
   12e14:      	subl	%r12d, %edx
   12e17:      	movl	$0x0, %ecx
   12e1c:      	cmovbl	%ecx, %edx
   12e1f:      	addq	0x60(%rsp), %rdx
   12e24:      	xorl	%esi, %esi
   12e26:      	cmpl	%r15d, %r12d
   12e29:      	seta	%sil
   12e2d:      	movl	%r15d, %ecx
   12e30:      	cmovbl	%r12d, %ecx
   12e34:      	addl	%ecx, %esi
   12e36:      	movl	%r12d, %edi
   12e39:      	subl	%esi, %edi
   12e3b:      	movl	%edi, 0x50(%rsp)
   12e3f:      	subq	%rsi, %rax
   12e42:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   12e48:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12e4e:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   12e54:      	cmpl	%r15d, %r12d
   12e57:      	jbe	0x12e5d <generic_rawtp_path+0x7d5d>
   12e59:      	movb	$0x2f, (%rbx,%rax)
   12e5d:      	xorl	%edi, %edi
   12e5f:      	cmpl	%r15d, %r12d
   12e62:      	seta	%dil
   12e66:      	movzbl	%cl, %esi
   12e69:      	addq	%rax, %rbx
   12e6c:      	addq	%rbx, %rdi
   12e6f:      	movl	$0x4, %eax
   12e74:      	callq	*%rax
   12e76:      	movq	%rbx, 0x48(%rsp)
   12e7b:      	cmpl	%r15d, %r12d
   12e7e:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   12e84:      	movq	0x8(%rsp), %r12
   12e89:      	movq	%r12, 0x30(%rsp)
   12e8e:      	movq	0x38(%rsp), %rdx
   12e93:      	movq	0x40(%rsp), %r15
   12e98:      	jmp	0x12eeb <generic_rawtp_path+0x7deb>
   12e9a:      	leaq	0x10(%r15), %rdx
   12e9e:      	movl	$0x4, %eax
   12ea3:      	movq	%rbp, %rdi
   12ea6:      	movl	$0x8, %esi
   12eab:      	callq	*%rax
   12ead:      	movq	0x40(%rsp), %rax
   12eb2:      	cmpq	(%rsp), %rax
   12eb6:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   12ebc:      	addq	$0x18, %r15
   12ec0:      	movl	$0x4, %eax
   12ec5:      	leaq	0x30(%rsp), %rdi
   12eca:      	movl	$0x8, %esi
   12ecf:      	movq	%r15, %rdx
   12ed2:      	callq	*%rax
   12ed4:      	movq	(%rsp), %r15
   12ed8:      	movq	%r15, 0x40(%rsp)
   12edd:      	leaq	0x20(%r15), %rdx
   12ee1:      	movq	%rdx, 0x38(%rsp)
   12ee6:      	movq	0x30(%rsp), %r12
   12eeb:      	cmpq	0x18(%rsp), %r12
   12ef0:      	jne	0x12efd <generic_rawtp_path+0x7dfd>
   12ef2:      	cmpq	0x20(%rsp), %rdx
   12ef7:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   12efd:      	movl	$0x4, %eax
   12f02:      	leaq	0x10(%rsp), %rdi
   12f07:      	movl	$0x8, %esi
   12f0c:      	callq	*%rax
   12f0e:      	cmpq	0x10(%rsp), %r12
   12f13:      	je	0x1300b <generic_rawtp_path+0x7f0b>
   12f19:      	leaq	0x18(%r12), %rbx
   12f1e:      	movl	$0x4, %eax
   12f23:      	movq	%rbp, %rdi
   12f26:      	movl	$0x8, %esi
   12f2b:      	movq	%rbx, %rdx
   12f2e:      	callq	*%rax
   12f30:      	cmpq	%r12, (%rsp)
   12f34:      	je	0x1300b <generic_rawtp_path+0x7f0b>
   12f3a:      	movl	$0x4, %eax
   12f3f:      	leaq	0x8(%rsp), %rdi
   12f44:      	movl	$0x8, %esi
   12f49:      	movq	%rbx, %rdx
   12f4c:      	callq	*%rax
   12f4e:      	addq	$0x20, %r12
   12f52:      	movl	$0x4, %eax
   12f57:      	leaq	0x58(%rsp), %rdi
   12f5c:      	movl	$0x10, %ecx
   12f61:      	movl	$0x10, %esi
   12f66:      	movq	%r12, %rdx
   12f69:      	callq	*%rax
   12f6b:      	movq	0x28(%rsp), %rbx
   12f70:      	movq	0x48(%rsp), %rax
   12f75:      	movl	0x5c(%rsp), %r15d
   12f7a:      	subq	%rbx, %rax
   12f7d:      	movl	0x50(%rsp), %r12d
   12f82:      	movl	%r15d, %edx
   12f85:      	subl	%r12d, %edx
   12f88:      	movl	$0x0, %ecx
   12f8d:      	cmovbl	%ecx, %edx
   12f90:      	addq	0x60(%rsp), %rdx
   12f95:      	xorl	%esi, %esi
   12f97:      	cmpl	%r15d, %r12d
   12f9a:      	seta	%sil
   12f9e:      	movl	%r15d, %ecx
   12fa1:      	cmovbl	%r12d, %ecx
   12fa5:      	addl	%ecx, %esi
   12fa7:      	movl	%r12d, %edi
   12faa:      	subl	%esi, %edi
   12fac:      	movl	%edi, 0x50(%rsp)
   12fb0:      	subq	%rsi, %rax
   12fb3:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   12fb9:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12fbf:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   12fc5:      	cmpl	%r15d, %r12d
   12fc8:      	jbe	0x12fce <generic_rawtp_path+0x7ece>
   12fca:      	movb	$0x2f, (%rbx,%rax)
   12fce:      	xorl	%edi, %edi
   12fd0:      	cmpl	%r15d, %r12d
   12fd3:      	seta	%dil
   12fd7:      	movzbl	%cl, %esi
   12fda:      	addq	%rax, %rbx
   12fdd:      	addq	%rbx, %rdi
   12fe0:      	movl	$0x4, %eax
   12fe5:      	callq	*%rax
   12fe7:      	movq	%rbx, 0x48(%rsp)
   12fec:      	cmpl	%r15d, %r12d
   12fef:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   12ff5:      	movq	0x8(%rsp), %r12
   12ffa:      	movq	%r12, 0x30(%rsp)
   12fff:      	movq	0x38(%rsp), %rdx
   13004:      	movq	0x40(%rsp), %r15
   13009:      	jmp	0x1305c <generic_rawtp_path+0x7f5c>
   1300b:      	leaq	0x10(%r15), %rdx
   1300f:      	movl	$0x4, %eax
   13014:      	movq	%rbp, %rdi
   13017:      	movl	$0x8, %esi
   1301c:      	callq	*%rax
   1301e:      	movq	0x40(%rsp), %rax
   13023:      	cmpq	(%rsp), %rax
   13027:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   1302d:      	addq	$0x18, %r15
   13031:      	movl	$0x4, %eax
   13036:      	leaq	0x30(%rsp), %rdi
   1303b:      	movl	$0x8, %esi
   13040:      	movq	%r15, %rdx
   13043:      	callq	*%rax
   13045:      	movq	(%rsp), %r15
   13049:      	movq	%r15, 0x40(%rsp)
   1304e:      	leaq	0x20(%r15), %rdx
   13052:      	movq	%rdx, 0x38(%rsp)
   13057:      	movq	0x30(%rsp), %r12
   1305c:      	cmpq	0x18(%rsp), %r12
   13061:      	jne	0x1306e <generic_rawtp_path+0x7f6e>
   13063:      	cmpq	0x20(%rsp), %rdx
   13068:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   1306e:      	movl	$0x4, %eax
   13073:      	leaq	0x10(%rsp), %rdi
   13078:      	movl	$0x8, %esi
   1307d:      	callq	*%rax
   1307f:      	cmpq	0x10(%rsp), %r12
   13084:      	je	0x1317c <generic_rawtp_path+0x807c>
   1308a:      	leaq	0x18(%r12), %rbx
   1308f:      	movl	$0x4, %eax
   13094:      	movq	%rbp, %rdi
   13097:      	movl	$0x8, %esi
   1309c:      	movq	%rbx, %rdx
   1309f:      	callq	*%rax
   130a1:      	cmpq	%r12, (%rsp)
   130a5:      	je	0x1317c <generic_rawtp_path+0x807c>
   130ab:      	movl	$0x4, %eax
   130b0:      	leaq	0x8(%rsp), %rdi
   130b5:      	movl	$0x8, %esi
   130ba:      	movq	%rbx, %rdx
   130bd:      	callq	*%rax
   130bf:      	addq	$0x20, %r12
   130c3:      	movl	$0x4, %eax
   130c8:      	leaq	0x58(%rsp), %rdi
   130cd:      	movl	$0x10, %ecx
   130d2:      	movl	$0x10, %esi
   130d7:      	movq	%r12, %rdx
   130da:      	callq	*%rax
   130dc:      	movq	0x28(%rsp), %rbx
   130e1:      	movq	0x48(%rsp), %rax
   130e6:      	movl	0x5c(%rsp), %r15d
   130eb:      	subq	%rbx, %rax
   130ee:      	movl	0x50(%rsp), %r12d
   130f3:      	movl	%r15d, %edx
   130f6:      	subl	%r12d, %edx
   130f9:      	movl	$0x0, %ecx
   130fe:      	cmovbl	%ecx, %edx
   13101:      	addq	0x60(%rsp), %rdx
   13106:      	xorl	%esi, %esi
   13108:      	cmpl	%r15d, %r12d
   1310b:      	seta	%sil
   1310f:      	movl	%r15d, %ecx
   13112:      	cmovbl	%r12d, %ecx
   13116:      	addl	%ecx, %esi
   13118:      	movl	%r12d, %edi
   1311b:      	subl	%esi, %edi
   1311d:      	movl	%edi, 0x50(%rsp)
   13121:      	subq	%rsi, %rax
   13124:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   1312a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13130:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   13136:      	cmpl	%r15d, %r12d
   13139:      	jbe	0x1313f <generic_rawtp_path+0x803f>
   1313b:      	movb	$0x2f, (%rbx,%rax)
   1313f:      	xorl	%edi, %edi
   13141:      	cmpl	%r15d, %r12d
   13144:      	seta	%dil
   13148:      	movzbl	%cl, %esi
   1314b:      	addq	%rax, %rbx
   1314e:      	addq	%rbx, %rdi
   13151:      	movl	$0x4, %eax
   13156:      	callq	*%rax
   13158:      	movq	%rbx, 0x48(%rsp)
   1315d:      	cmpl	%r15d, %r12d
   13160:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   13166:      	movq	0x8(%rsp), %r12
   1316b:      	movq	%r12, 0x30(%rsp)
   13170:      	movq	0x38(%rsp), %rdx
   13175:      	movq	0x40(%rsp), %r15
   1317a:      	jmp	0x131cd <generic_rawtp_path+0x80cd>
   1317c:      	leaq	0x10(%r15), %rdx
   13180:      	movl	$0x4, %eax
   13185:      	movq	%rbp, %rdi
   13188:      	movl	$0x8, %esi
   1318d:      	callq	*%rax
   1318f:      	movq	0x40(%rsp), %rax
   13194:      	cmpq	(%rsp), %rax
   13198:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   1319e:      	addq	$0x18, %r15
   131a2:      	movl	$0x4, %eax
   131a7:      	leaq	0x30(%rsp), %rdi
   131ac:      	movl	$0x8, %esi
   131b1:      	movq	%r15, %rdx
   131b4:      	callq	*%rax
   131b6:      	movq	(%rsp), %r15
   131ba:      	movq	%r15, 0x40(%rsp)
   131bf:      	leaq	0x20(%r15), %rdx
   131c3:      	movq	%rdx, 0x38(%rsp)
   131c8:      	movq	0x30(%rsp), %r12
   131cd:      	cmpq	0x18(%rsp), %r12
   131d2:      	jne	0x131df <generic_rawtp_path+0x80df>
   131d4:      	cmpq	0x20(%rsp), %rdx
   131d9:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   131df:      	movl	$0x4, %eax
   131e4:      	leaq	0x10(%rsp), %rdi
   131e9:      	movl	$0x8, %esi
   131ee:      	callq	*%rax
   131f0:      	cmpq	0x10(%rsp), %r12
   131f5:      	je	0x132ed <generic_rawtp_path+0x81ed>
   131fb:      	leaq	0x18(%r12), %rbx
   13200:      	movl	$0x4, %eax
   13205:      	movq	%rbp, %rdi
   13208:      	movl	$0x8, %esi
   1320d:      	movq	%rbx, %rdx
   13210:      	callq	*%rax
   13212:      	cmpq	%r12, (%rsp)
   13216:      	je	0x132ed <generic_rawtp_path+0x81ed>
   1321c:      	movl	$0x4, %eax
   13221:      	leaq	0x8(%rsp), %rdi
   13226:      	movl	$0x8, %esi
   1322b:      	movq	%rbx, %rdx
   1322e:      	callq	*%rax
   13230:      	addq	$0x20, %r12
   13234:      	movl	$0x4, %eax
   13239:      	leaq	0x58(%rsp), %rdi
   1323e:      	movl	$0x10, %ecx
   13243:      	movl	$0x10, %esi
   13248:      	movq	%r12, %rdx
   1324b:      	callq	*%rax
   1324d:      	movq	0x28(%rsp), %rbx
   13252:      	movq	0x48(%rsp), %rax
   13257:      	movl	0x5c(%rsp), %r15d
   1325c:      	subq	%rbx, %rax
   1325f:      	movl	0x50(%rsp), %r12d
   13264:      	movl	%r15d, %edx
   13267:      	subl	%r12d, %edx
   1326a:      	movl	$0x0, %ecx
   1326f:      	cmovbl	%ecx, %edx
   13272:      	addq	0x60(%rsp), %rdx
   13277:      	xorl	%esi, %esi
   13279:      	cmpl	%r15d, %r12d
   1327c:      	seta	%sil
   13280:      	movl	%r15d, %ecx
   13283:      	cmovbl	%r12d, %ecx
   13287:      	addl	%ecx, %esi
   13289:      	movl	%r12d, %edi
   1328c:      	subl	%esi, %edi
   1328e:      	movl	%edi, 0x50(%rsp)
   13292:      	subq	%rsi, %rax
   13295:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   1329b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   132a1:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   132a7:      	cmpl	%r15d, %r12d
   132aa:      	jbe	0x132b0 <generic_rawtp_path+0x81b0>
   132ac:      	movb	$0x2f, (%rbx,%rax)
   132b0:      	xorl	%edi, %edi
   132b2:      	cmpl	%r15d, %r12d
   132b5:      	seta	%dil
   132b9:      	movzbl	%cl, %esi
   132bc:      	addq	%rax, %rbx
   132bf:      	addq	%rbx, %rdi
   132c2:      	movl	$0x4, %eax
   132c7:      	callq	*%rax
   132c9:      	movq	%rbx, 0x48(%rsp)
   132ce:      	cmpl	%r15d, %r12d
   132d1:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   132d7:      	movq	0x8(%rsp), %r12
   132dc:      	movq	%r12, 0x30(%rsp)
   132e1:      	movq	0x38(%rsp), %rdx
   132e6:      	movq	0x40(%rsp), %r15
   132eb:      	jmp	0x1333e <generic_rawtp_path+0x823e>
   132ed:      	leaq	0x10(%r15), %rdx
   132f1:      	movl	$0x4, %eax
   132f6:      	movq	%rbp, %rdi
   132f9:      	movl	$0x8, %esi
   132fe:      	callq	*%rax
   13300:      	movq	0x40(%rsp), %rax
   13305:      	cmpq	(%rsp), %rax
   13309:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   1330f:      	addq	$0x18, %r15
   13313:      	movl	$0x4, %eax
   13318:      	leaq	0x30(%rsp), %rdi
   1331d:      	movl	$0x8, %esi
   13322:      	movq	%r15, %rdx
   13325:      	callq	*%rax
   13327:      	movq	(%rsp), %r15
   1332b:      	movq	%r15, 0x40(%rsp)
   13330:      	leaq	0x20(%r15), %rdx
   13334:      	movq	%rdx, 0x38(%rsp)
   13339:      	movq	0x30(%rsp), %r12
   1333e:      	cmpq	0x18(%rsp), %r12
   13343:      	jne	0x13350 <generic_rawtp_path+0x8250>
   13345:      	cmpq	0x20(%rsp), %rdx
   1334a:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   13350:      	movl	$0x4, %eax
   13355:      	leaq	0x10(%rsp), %rdi
   1335a:      	movl	$0x8, %esi
   1335f:      	callq	*%rax
   13361:      	cmpq	0x10(%rsp), %r12
   13366:      	je	0x1345e <generic_rawtp_path+0x835e>
   1336c:      	leaq	0x18(%r12), %rbx
   13371:      	movl	$0x4, %eax
   13376:      	movq	%rbp, %rdi
   13379:      	movl	$0x8, %esi
   1337e:      	movq	%rbx, %rdx
   13381:      	callq	*%rax
   13383:      	cmpq	%r12, (%rsp)
   13387:      	je	0x1345e <generic_rawtp_path+0x835e>
   1338d:      	movl	$0x4, %eax
   13392:      	leaq	0x8(%rsp), %rdi
   13397:      	movl	$0x8, %esi
   1339c:      	movq	%rbx, %rdx
   1339f:      	callq	*%rax
   133a1:      	addq	$0x20, %r12
   133a5:      	movl	$0x4, %eax
   133aa:      	leaq	0x58(%rsp), %rdi
   133af:      	movl	$0x10, %ecx
   133b4:      	movl	$0x10, %esi
   133b9:      	movq	%r12, %rdx
   133bc:      	callq	*%rax
   133be:      	movq	0x28(%rsp), %rbx
   133c3:      	movq	0x48(%rsp), %rax
   133c8:      	movl	0x5c(%rsp), %r15d
   133cd:      	subq	%rbx, %rax
   133d0:      	movl	0x50(%rsp), %r12d
   133d5:      	movl	%r15d, %edx
   133d8:      	subl	%r12d, %edx
   133db:      	movl	$0x0, %ecx
   133e0:      	cmovbl	%ecx, %edx
   133e3:      	addq	0x60(%rsp), %rdx
   133e8:      	xorl	%esi, %esi
   133ea:      	cmpl	%r15d, %r12d
   133ed:      	seta	%sil
   133f1:      	movl	%r15d, %ecx
   133f4:      	cmovbl	%r12d, %ecx
   133f8:      	addl	%ecx, %esi
   133fa:      	movl	%r12d, %edi
   133fd:      	subl	%esi, %edi
   133ff:      	movl	%edi, 0x50(%rsp)
   13403:      	subq	%rsi, %rax
   13406:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   1340c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13412:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   13418:      	cmpl	%r15d, %r12d
   1341b:      	jbe	0x13421 <generic_rawtp_path+0x8321>
   1341d:      	movb	$0x2f, (%rbx,%rax)
   13421:      	xorl	%edi, %edi
   13423:      	cmpl	%r15d, %r12d
   13426:      	seta	%dil
   1342a:      	movzbl	%cl, %esi
   1342d:      	addq	%rax, %rbx
   13430:      	addq	%rbx, %rdi
   13433:      	movl	$0x4, %eax
   13438:      	callq	*%rax
   1343a:      	movq	%rbx, 0x48(%rsp)
   1343f:      	cmpl	%r15d, %r12d
   13442:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   13448:      	movq	0x8(%rsp), %r12
   1344d:      	movq	%r12, 0x30(%rsp)
   13452:      	movq	0x38(%rsp), %rdx
   13457:      	movq	0x40(%rsp), %r15
   1345c:      	jmp	0x134af <generic_rawtp_path+0x83af>
   1345e:      	leaq	0x10(%r15), %rdx
   13462:      	movl	$0x4, %eax
   13467:      	movq	%rbp, %rdi
   1346a:      	movl	$0x8, %esi
   1346f:      	callq	*%rax
   13471:      	movq	0x40(%rsp), %rax
   13476:      	cmpq	(%rsp), %rax
   1347a:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   13480:      	addq	$0x18, %r15
   13484:      	movl	$0x4, %eax
   13489:      	leaq	0x30(%rsp), %rdi
   1348e:      	movl	$0x8, %esi
   13493:      	movq	%r15, %rdx
   13496:      	callq	*%rax
   13498:      	movq	(%rsp), %r15
   1349c:      	movq	%r15, 0x40(%rsp)
   134a1:      	leaq	0x20(%r15), %rdx
   134a5:      	movq	%rdx, 0x38(%rsp)
   134aa:      	movq	0x30(%rsp), %r12
   134af:      	cmpq	0x18(%rsp), %r12
   134b4:      	jne	0x134c1 <generic_rawtp_path+0x83c1>
   134b6:      	cmpq	0x20(%rsp), %rdx
   134bb:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   134c1:      	movl	$0x4, %eax
   134c6:      	leaq	0x10(%rsp), %rdi
   134cb:      	movl	$0x8, %esi
   134d0:      	callq	*%rax
   134d2:      	cmpq	0x10(%rsp), %r12
   134d7:      	je	0x135cf <generic_rawtp_path+0x84cf>
   134dd:      	leaq	0x18(%r12), %rbx
   134e2:      	movl	$0x4, %eax
   134e7:      	movq	%rbp, %rdi
   134ea:      	movl	$0x8, %esi
   134ef:      	movq	%rbx, %rdx
   134f2:      	callq	*%rax
   134f4:      	cmpq	%r12, (%rsp)
   134f8:      	je	0x135cf <generic_rawtp_path+0x84cf>
   134fe:      	movl	$0x4, %eax
   13503:      	leaq	0x8(%rsp), %rdi
   13508:      	movl	$0x8, %esi
   1350d:      	movq	%rbx, %rdx
   13510:      	callq	*%rax
   13512:      	addq	$0x20, %r12
   13516:      	movl	$0x4, %eax
   1351b:      	leaq	0x58(%rsp), %rdi
   13520:      	movl	$0x10, %ecx
   13525:      	movl	$0x10, %esi
   1352a:      	movq	%r12, %rdx
   1352d:      	callq	*%rax
   1352f:      	movq	0x28(%rsp), %rbx
   13534:      	movq	0x48(%rsp), %rax
   13539:      	movl	0x5c(%rsp), %r15d
   1353e:      	subq	%rbx, %rax
   13541:      	movl	0x50(%rsp), %r12d
   13546:      	movl	%r15d, %edx
   13549:      	subl	%r12d, %edx
   1354c:      	movl	$0x0, %ecx
   13551:      	cmovbl	%ecx, %edx
   13554:      	addq	0x60(%rsp), %rdx
   13559:      	xorl	%esi, %esi
   1355b:      	cmpl	%r15d, %r12d
   1355e:      	seta	%sil
   13562:      	movl	%r15d, %ecx
   13565:      	cmovbl	%r12d, %ecx
   13569:      	addl	%ecx, %esi
   1356b:      	movl	%r12d, %edi
   1356e:      	subl	%esi, %edi
   13570:      	movl	%edi, 0x50(%rsp)
   13574:      	subq	%rsi, %rax
   13577:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   1357d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13583:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   13589:      	cmpl	%r15d, %r12d
   1358c:      	jbe	0x13592 <generic_rawtp_path+0x8492>
   1358e:      	movb	$0x2f, (%rbx,%rax)
   13592:      	xorl	%edi, %edi
   13594:      	cmpl	%r15d, %r12d
   13597:      	seta	%dil
   1359b:      	movzbl	%cl, %esi
   1359e:      	addq	%rax, %rbx
   135a1:      	addq	%rbx, %rdi
   135a4:      	movl	$0x4, %eax
   135a9:      	callq	*%rax
   135ab:      	movq	%rbx, 0x48(%rsp)
   135b0:      	cmpl	%r15d, %r12d
   135b3:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   135b9:      	movq	0x8(%rsp), %r12
   135be:      	movq	%r12, 0x30(%rsp)
   135c3:      	movq	0x38(%rsp), %rdx
   135c8:      	movq	0x40(%rsp), %r15
   135cd:      	jmp	0x13620 <generic_rawtp_path+0x8520>
   135cf:      	leaq	0x10(%r15), %rdx
   135d3:      	movl	$0x4, %eax
   135d8:      	movq	%rbp, %rdi
   135db:      	movl	$0x8, %esi
   135e0:      	callq	*%rax
   135e2:      	movq	0x40(%rsp), %rax
   135e7:      	cmpq	(%rsp), %rax
   135eb:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   135f1:      	addq	$0x18, %r15
   135f5:      	movl	$0x4, %eax
   135fa:      	leaq	0x30(%rsp), %rdi
   135ff:      	movl	$0x8, %esi
   13604:      	movq	%r15, %rdx
   13607:      	callq	*%rax
   13609:      	movq	(%rsp), %r15
   1360d:      	movq	%r15, 0x40(%rsp)
   13612:      	leaq	0x20(%r15), %rdx
   13616:      	movq	%rdx, 0x38(%rsp)
   1361b:      	movq	0x30(%rsp), %r12
   13620:      	cmpq	0x18(%rsp), %r12
   13625:      	jne	0x13632 <generic_rawtp_path+0x8532>
   13627:      	cmpq	0x20(%rsp), %rdx
   1362c:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   13632:      	movl	$0x4, %eax
   13637:      	leaq	0x10(%rsp), %rdi
   1363c:      	movl	$0x8, %esi
   13641:      	callq	*%rax
   13643:      	cmpq	0x10(%rsp), %r12
   13648:      	je	0x13740 <generic_rawtp_path+0x8640>
   1364e:      	leaq	0x18(%r12), %rbx
   13653:      	movl	$0x4, %eax
   13658:      	movq	%rbp, %rdi
   1365b:      	movl	$0x8, %esi
   13660:      	movq	%rbx, %rdx
   13663:      	callq	*%rax
   13665:      	cmpq	%r12, (%rsp)
   13669:      	je	0x13740 <generic_rawtp_path+0x8640>
   1366f:      	movl	$0x4, %eax
   13674:      	leaq	0x8(%rsp), %rdi
   13679:      	movl	$0x8, %esi
   1367e:      	movq	%rbx, %rdx
   13681:      	callq	*%rax
   13683:      	addq	$0x20, %r12
   13687:      	movl	$0x4, %eax
   1368c:      	leaq	0x58(%rsp), %rdi
   13691:      	movl	$0x10, %ecx
   13696:      	movl	$0x10, %esi
   1369b:      	movq	%r12, %rdx
   1369e:      	callq	*%rax
   136a0:      	movq	0x28(%rsp), %rbx
   136a5:      	movq	0x48(%rsp), %rax
   136aa:      	movl	0x5c(%rsp), %r15d
   136af:      	subq	%rbx, %rax
   136b2:      	movl	0x50(%rsp), %r12d
   136b7:      	movl	%r15d, %edx
   136ba:      	subl	%r12d, %edx
   136bd:      	movl	$0x0, %ecx
   136c2:      	cmovbl	%ecx, %edx
   136c5:      	addq	0x60(%rsp), %rdx
   136ca:      	xorl	%esi, %esi
   136cc:      	cmpl	%r15d, %r12d
   136cf:      	seta	%sil
   136d3:      	movl	%r15d, %ecx
   136d6:      	cmovbl	%r12d, %ecx
   136da:      	addl	%ecx, %esi
   136dc:      	movl	%r12d, %edi
   136df:      	subl	%esi, %edi
   136e1:      	movl	%edi, 0x50(%rsp)
   136e5:      	subq	%rsi, %rax
   136e8:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   136ee:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   136f4:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   136fa:      	cmpl	%r15d, %r12d
   136fd:      	jbe	0x13703 <generic_rawtp_path+0x8603>
   136ff:      	movb	$0x2f, (%rbx,%rax)
   13703:      	xorl	%edi, %edi
   13705:      	cmpl	%r15d, %r12d
   13708:      	seta	%dil
   1370c:      	movzbl	%cl, %esi
   1370f:      	addq	%rax, %rbx
   13712:      	addq	%rbx, %rdi
   13715:      	movl	$0x4, %eax
   1371a:      	callq	*%rax
   1371c:      	movq	%rbx, 0x48(%rsp)
   13721:      	cmpl	%r15d, %r12d
   13724:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   1372a:      	movq	0x8(%rsp), %r12
   1372f:      	movq	%r12, 0x30(%rsp)
   13734:      	movq	0x38(%rsp), %rdx
   13739:      	movq	0x40(%rsp), %r15
   1373e:      	jmp	0x13791 <generic_rawtp_path+0x8691>
   13740:      	leaq	0x10(%r15), %rdx
   13744:      	movl	$0x4, %eax
   13749:      	movq	%rbp, %rdi
   1374c:      	movl	$0x8, %esi
   13751:      	callq	*%rax
   13753:      	movq	0x40(%rsp), %rax
   13758:      	cmpq	(%rsp), %rax
   1375c:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   13762:      	addq	$0x18, %r15
   13766:      	movl	$0x4, %eax
   1376b:      	leaq	0x30(%rsp), %rdi
   13770:      	movl	$0x8, %esi
   13775:      	movq	%r15, %rdx
   13778:      	callq	*%rax
   1377a:      	movq	(%rsp), %r15
   1377e:      	movq	%r15, 0x40(%rsp)
   13783:      	leaq	0x20(%r15), %rdx
   13787:      	movq	%rdx, 0x38(%rsp)
   1378c:      	movq	0x30(%rsp), %r12
   13791:      	cmpq	0x18(%rsp), %r12
   13796:      	jne	0x137a3 <generic_rawtp_path+0x86a3>
   13798:      	cmpq	0x20(%rsp), %rdx
   1379d:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   137a3:      	movl	$0x4, %eax
   137a8:      	leaq	0x10(%rsp), %rdi
   137ad:      	movl	$0x8, %esi
   137b2:      	callq	*%rax
   137b4:      	cmpq	0x10(%rsp), %r12
   137b9:      	je	0x138b1 <generic_rawtp_path+0x87b1>
   137bf:      	leaq	0x18(%r12), %rbx
   137c4:      	movl	$0x4, %eax
   137c9:      	movq	%rbp, %rdi
   137cc:      	movl	$0x8, %esi
   137d1:      	movq	%rbx, %rdx
   137d4:      	callq	*%rax
   137d6:      	cmpq	%r12, (%rsp)
   137da:      	je	0x138b1 <generic_rawtp_path+0x87b1>
   137e0:      	movl	$0x4, %eax
   137e5:      	leaq	0x8(%rsp), %rdi
   137ea:      	movl	$0x8, %esi
   137ef:      	movq	%rbx, %rdx
   137f2:      	callq	*%rax
   137f4:      	addq	$0x20, %r12
   137f8:      	movl	$0x4, %eax
   137fd:      	leaq	0x58(%rsp), %rdi
   13802:      	movl	$0x10, %ecx
   13807:      	movl	$0x10, %esi
   1380c:      	movq	%r12, %rdx
   1380f:      	callq	*%rax
   13811:      	movq	0x28(%rsp), %rbx
   13816:      	movq	0x48(%rsp), %rax
   1381b:      	movl	0x5c(%rsp), %r15d
   13820:      	subq	%rbx, %rax
   13823:      	movl	0x50(%rsp), %r12d
   13828:      	movl	%r15d, %edx
   1382b:      	subl	%r12d, %edx
   1382e:      	movl	$0x0, %ecx
   13833:      	cmovbl	%ecx, %edx
   13836:      	addq	0x60(%rsp), %rdx
   1383b:      	xorl	%esi, %esi
   1383d:      	cmpl	%r15d, %r12d
   13840:      	seta	%sil
   13844:      	movl	%r15d, %ecx
   13847:      	cmovbl	%r12d, %ecx
   1384b:      	addl	%ecx, %esi
   1384d:      	movl	%r12d, %edi
   13850:      	subl	%esi, %edi
   13852:      	movl	%edi, 0x50(%rsp)
   13856:      	subq	%rsi, %rax
   13859:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   1385f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13865:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   1386b:      	cmpl	%r15d, %r12d
   1386e:      	jbe	0x13874 <generic_rawtp_path+0x8774>
   13870:      	movb	$0x2f, (%rbx,%rax)
   13874:      	xorl	%edi, %edi
   13876:      	cmpl	%r15d, %r12d
   13879:      	seta	%dil
   1387d:      	movzbl	%cl, %esi
   13880:      	addq	%rax, %rbx
   13883:      	addq	%rbx, %rdi
   13886:      	movl	$0x4, %eax
   1388b:      	callq	*%rax
   1388d:      	movq	%rbx, 0x48(%rsp)
   13892:      	cmpl	%r15d, %r12d
   13895:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   1389b:      	movq	0x8(%rsp), %r12
   138a0:      	movq	%r12, 0x30(%rsp)
   138a5:      	movq	0x38(%rsp), %rdx
   138aa:      	movq	0x40(%rsp), %r15
   138af:      	jmp	0x13902 <generic_rawtp_path+0x8802>
   138b1:      	leaq	0x10(%r15), %rdx
   138b5:      	movl	$0x4, %eax
   138ba:      	movq	%rbp, %rdi
   138bd:      	movl	$0x8, %esi
   138c2:      	callq	*%rax
   138c4:      	movq	0x40(%rsp), %rax
   138c9:      	cmpq	(%rsp), %rax
   138cd:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   138d3:      	addq	$0x18, %r15
   138d7:      	movl	$0x4, %eax
   138dc:      	leaq	0x30(%rsp), %rdi
   138e1:      	movl	$0x8, %esi
   138e6:      	movq	%r15, %rdx
   138e9:      	callq	*%rax
   138eb:      	movq	(%rsp), %r15
   138ef:      	movq	%r15, 0x40(%rsp)
   138f4:      	leaq	0x20(%r15), %rdx
   138f8:      	movq	%rdx, 0x38(%rsp)
   138fd:      	movq	0x30(%rsp), %r12
   13902:      	cmpq	0x18(%rsp), %r12
   13907:      	jne	0x13914 <generic_rawtp_path+0x8814>
   13909:      	cmpq	0x20(%rsp), %rdx
   1390e:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   13914:      	movl	$0x4, %eax
   13919:      	leaq	0x10(%rsp), %rdi
   1391e:      	movl	$0x8, %esi
   13923:      	callq	*%rax
   13925:      	cmpq	0x10(%rsp), %r12
   1392a:      	je	0x13a22 <generic_rawtp_path+0x8922>
   13930:      	leaq	0x18(%r12), %rbx
   13935:      	movl	$0x4, %eax
   1393a:      	movq	%rbp, %rdi
   1393d:      	movl	$0x8, %esi
   13942:      	movq	%rbx, %rdx
   13945:      	callq	*%rax
   13947:      	cmpq	%r12, (%rsp)
   1394b:      	je	0x13a22 <generic_rawtp_path+0x8922>
   13951:      	movl	$0x4, %eax
   13956:      	leaq	0x8(%rsp), %rdi
   1395b:      	movl	$0x8, %esi
   13960:      	movq	%rbx, %rdx
   13963:      	callq	*%rax
   13965:      	addq	$0x20, %r12
   13969:      	movl	$0x4, %eax
   1396e:      	leaq	0x58(%rsp), %rdi
   13973:      	movl	$0x10, %ecx
   13978:      	movl	$0x10, %esi
   1397d:      	movq	%r12, %rdx
   13980:      	callq	*%rax
   13982:      	movq	0x28(%rsp), %rbx
   13987:      	movq	0x48(%rsp), %rax
   1398c:      	movl	0x5c(%rsp), %r15d
   13991:      	subq	%rbx, %rax
   13994:      	movl	0x50(%rsp), %r12d
   13999:      	movl	%r15d, %edx
   1399c:      	subl	%r12d, %edx
   1399f:      	movl	$0x0, %ecx
   139a4:      	cmovbl	%ecx, %edx
   139a7:      	addq	0x60(%rsp), %rdx
   139ac:      	xorl	%esi, %esi
   139ae:      	cmpl	%r15d, %r12d
   139b1:      	seta	%sil
   139b5:      	movl	%r15d, %ecx
   139b8:      	cmovbl	%r12d, %ecx
   139bc:      	addl	%ecx, %esi
   139be:      	movl	%r12d, %edi
   139c1:      	subl	%esi, %edi
   139c3:      	movl	%edi, 0x50(%rsp)
   139c7:      	subq	%rsi, %rax
   139ca:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   139d0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   139d6:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   139dc:      	cmpl	%r15d, %r12d
   139df:      	jbe	0x139e5 <generic_rawtp_path+0x88e5>
   139e1:      	movb	$0x2f, (%rbx,%rax)
   139e5:      	xorl	%edi, %edi
   139e7:      	cmpl	%r15d, %r12d
   139ea:      	seta	%dil
   139ee:      	movzbl	%cl, %esi
   139f1:      	addq	%rax, %rbx
   139f4:      	addq	%rbx, %rdi
   139f7:      	movl	$0x4, %eax
   139fc:      	callq	*%rax
   139fe:      	movq	%rbx, 0x48(%rsp)
   13a03:      	cmpl	%r15d, %r12d
   13a06:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   13a0c:      	movq	0x8(%rsp), %r12
   13a11:      	movq	%r12, 0x30(%rsp)
   13a16:      	movq	0x38(%rsp), %rdx
   13a1b:      	movq	0x40(%rsp), %r15
   13a20:      	jmp	0x13a73 <generic_rawtp_path+0x8973>
   13a22:      	leaq	0x10(%r15), %rdx
   13a26:      	movl	$0x4, %eax
   13a2b:      	movq	%rbp, %rdi
   13a2e:      	movl	$0x8, %esi
   13a33:      	callq	*%rax
   13a35:      	movq	0x40(%rsp), %rax
   13a3a:      	cmpq	(%rsp), %rax
   13a3e:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   13a44:      	addq	$0x18, %r15
   13a48:      	movl	$0x4, %eax
   13a4d:      	leaq	0x30(%rsp), %rdi
   13a52:      	movl	$0x8, %esi
   13a57:      	movq	%r15, %rdx
   13a5a:      	callq	*%rax
   13a5c:      	movq	(%rsp), %r15
   13a60:      	movq	%r15, 0x40(%rsp)
   13a65:      	leaq	0x20(%r15), %rdx
   13a69:      	movq	%rdx, 0x38(%rsp)
   13a6e:      	movq	0x30(%rsp), %r12
   13a73:      	cmpq	0x18(%rsp), %r12
   13a78:      	jne	0x13a85 <generic_rawtp_path+0x8985>
   13a7a:      	cmpq	0x20(%rsp), %rdx
   13a7f:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   13a85:      	movl	$0x4, %eax
   13a8a:      	leaq	0x10(%rsp), %rdi
   13a8f:      	movl	$0x8, %esi
   13a94:      	callq	*%rax
   13a96:      	cmpq	0x10(%rsp), %r12
   13a9b:      	je	0x13b93 <generic_rawtp_path+0x8a93>
   13aa1:      	leaq	0x18(%r12), %rbx
   13aa6:      	movl	$0x4, %eax
   13aab:      	movq	%rbp, %rdi
   13aae:      	movl	$0x8, %esi
   13ab3:      	movq	%rbx, %rdx
   13ab6:      	callq	*%rax
   13ab8:      	cmpq	%r12, (%rsp)
   13abc:      	je	0x13b93 <generic_rawtp_path+0x8a93>
   13ac2:      	movl	$0x4, %eax
   13ac7:      	leaq	0x8(%rsp), %rdi
   13acc:      	movl	$0x8, %esi
   13ad1:      	movq	%rbx, %rdx
   13ad4:      	callq	*%rax
   13ad6:      	addq	$0x20, %r12
   13ada:      	movl	$0x4, %eax
   13adf:      	leaq	0x58(%rsp), %rdi
   13ae4:      	movl	$0x10, %ecx
   13ae9:      	movl	$0x10, %esi
   13aee:      	movq	%r12, %rdx
   13af1:      	callq	*%rax
   13af3:      	movq	0x28(%rsp), %rbx
   13af8:      	movq	0x48(%rsp), %rax
   13afd:      	movl	0x5c(%rsp), %r15d
   13b02:      	subq	%rbx, %rax
   13b05:      	movl	0x50(%rsp), %r12d
   13b0a:      	movl	%r15d, %edx
   13b0d:      	subl	%r12d, %edx
   13b10:      	movl	$0x0, %ecx
   13b15:      	cmovbl	%ecx, %edx
   13b18:      	addq	0x60(%rsp), %rdx
   13b1d:      	xorl	%esi, %esi
   13b1f:      	cmpl	%r15d, %r12d
   13b22:      	seta	%sil
   13b26:      	movl	%r15d, %ecx
   13b29:      	cmovbl	%r12d, %ecx
   13b2d:      	addl	%ecx, %esi
   13b2f:      	movl	%r12d, %edi
   13b32:      	subl	%esi, %edi
   13b34:      	movl	%edi, 0x50(%rsp)
   13b38:      	subq	%rsi, %rax
   13b3b:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   13b41:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13b47:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   13b4d:      	cmpl	%r15d, %r12d
   13b50:      	jbe	0x13b56 <generic_rawtp_path+0x8a56>
   13b52:      	movb	$0x2f, (%rbx,%rax)
   13b56:      	xorl	%edi, %edi
   13b58:      	cmpl	%r15d, %r12d
   13b5b:      	seta	%dil
   13b5f:      	movzbl	%cl, %esi
   13b62:      	addq	%rax, %rbx
   13b65:      	addq	%rbx, %rdi
   13b68:      	movl	$0x4, %eax
   13b6d:      	callq	*%rax
   13b6f:      	movq	%rbx, 0x48(%rsp)
   13b74:      	cmpl	%r15d, %r12d
   13b77:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   13b7d:      	movq	0x8(%rsp), %r12
   13b82:      	movq	%r12, 0x30(%rsp)
   13b87:      	movq	0x38(%rsp), %rdx
   13b8c:      	movq	0x40(%rsp), %r15
   13b91:      	jmp	0x13be4 <generic_rawtp_path+0x8ae4>
   13b93:      	leaq	0x10(%r15), %rdx
   13b97:      	movl	$0x4, %eax
   13b9c:      	movq	%rbp, %rdi
   13b9f:      	movl	$0x8, %esi
   13ba4:      	callq	*%rax
   13ba6:      	movq	0x40(%rsp), %rax
   13bab:      	cmpq	(%rsp), %rax
   13baf:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   13bb5:      	addq	$0x18, %r15
   13bb9:      	movl	$0x4, %eax
   13bbe:      	leaq	0x30(%rsp), %rdi
   13bc3:      	movl	$0x8, %esi
   13bc8:      	movq	%r15, %rdx
   13bcb:      	callq	*%rax
   13bcd:      	movq	(%rsp), %r15
   13bd1:      	movq	%r15, 0x40(%rsp)
   13bd6:      	leaq	0x20(%r15), %rdx
   13bda:      	movq	%rdx, 0x38(%rsp)
   13bdf:      	movq	0x30(%rsp), %r12
   13be4:      	cmpq	0x18(%rsp), %r12
   13be9:      	jne	0x13bf6 <generic_rawtp_path+0x8af6>
   13beb:      	cmpq	0x20(%rsp), %rdx
   13bf0:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   13bf6:      	movl	$0x4, %eax
   13bfb:      	leaq	0x10(%rsp), %rdi
   13c00:      	movl	$0x8, %esi
   13c05:      	callq	*%rax
   13c07:      	cmpq	0x10(%rsp), %r12
   13c0c:      	je	0x13d04 <generic_rawtp_path+0x8c04>
   13c12:      	leaq	0x18(%r12), %rbx
   13c17:      	movl	$0x4, %eax
   13c1c:      	movq	%rbp, %rdi
   13c1f:      	movl	$0x8, %esi
   13c24:      	movq	%rbx, %rdx
   13c27:      	callq	*%rax
   13c29:      	cmpq	%r12, (%rsp)
   13c2d:      	je	0x13d04 <generic_rawtp_path+0x8c04>
   13c33:      	movl	$0x4, %eax
   13c38:      	leaq	0x8(%rsp), %rdi
   13c3d:      	movl	$0x8, %esi
   13c42:      	movq	%rbx, %rdx
   13c45:      	callq	*%rax
   13c47:      	addq	$0x20, %r12
   13c4b:      	movl	$0x4, %eax
   13c50:      	leaq	0x58(%rsp), %rdi
   13c55:      	movl	$0x10, %ecx
   13c5a:      	movl	$0x10, %esi
   13c5f:      	movq	%r12, %rdx
   13c62:      	callq	*%rax
   13c64:      	movq	0x28(%rsp), %rbx
   13c69:      	movq	0x48(%rsp), %rax
   13c6e:      	movl	0x5c(%rsp), %r15d
   13c73:      	subq	%rbx, %rax
   13c76:      	movl	0x50(%rsp), %r12d
   13c7b:      	movl	%r15d, %edx
   13c7e:      	subl	%r12d, %edx
   13c81:      	movl	$0x0, %ecx
   13c86:      	cmovbl	%ecx, %edx
   13c89:      	addq	0x60(%rsp), %rdx
   13c8e:      	xorl	%esi, %esi
   13c90:      	cmpl	%r15d, %r12d
   13c93:      	seta	%sil
   13c97:      	movl	%r15d, %ecx
   13c9a:      	cmovbl	%r12d, %ecx
   13c9e:      	addl	%ecx, %esi
   13ca0:      	movl	%r12d, %edi
   13ca3:      	subl	%esi, %edi
   13ca5:      	movl	%edi, 0x50(%rsp)
   13ca9:      	subq	%rsi, %rax
   13cac:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   13cb2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13cb8:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   13cbe:      	cmpl	%r15d, %r12d
   13cc1:      	jbe	0x13cc7 <generic_rawtp_path+0x8bc7>
   13cc3:      	movb	$0x2f, (%rbx,%rax)
   13cc7:      	xorl	%edi, %edi
   13cc9:      	cmpl	%r15d, %r12d
   13ccc:      	seta	%dil
   13cd0:      	movzbl	%cl, %esi
   13cd3:      	addq	%rax, %rbx
   13cd6:      	addq	%rbx, %rdi
   13cd9:      	movl	$0x4, %eax
   13cde:      	callq	*%rax
   13ce0:      	movq	%rbx, 0x48(%rsp)
   13ce5:      	cmpl	%r15d, %r12d
   13ce8:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   13cee:      	movq	0x8(%rsp), %r12
   13cf3:      	movq	%r12, 0x30(%rsp)
   13cf8:      	movq	0x38(%rsp), %rdx
   13cfd:      	movq	0x40(%rsp), %r15
   13d02:      	jmp	0x13d55 <generic_rawtp_path+0x8c55>
   13d04:      	leaq	0x10(%r15), %rdx
   13d08:      	movl	$0x4, %eax
   13d0d:      	movq	%rbp, %rdi
   13d10:      	movl	$0x8, %esi
   13d15:      	callq	*%rax
   13d17:      	movq	0x40(%rsp), %rax
   13d1c:      	cmpq	(%rsp), %rax
   13d20:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   13d26:      	addq	$0x18, %r15
   13d2a:      	movl	$0x4, %eax
   13d2f:      	leaq	0x30(%rsp), %rdi
   13d34:      	movl	$0x8, %esi
   13d39:      	movq	%r15, %rdx
   13d3c:      	callq	*%rax
   13d3e:      	movq	(%rsp), %r15
   13d42:      	movq	%r15, 0x40(%rsp)
   13d47:      	leaq	0x20(%r15), %rdx
   13d4b:      	movq	%rdx, 0x38(%rsp)
   13d50:      	movq	0x30(%rsp), %r12
   13d55:      	cmpq	0x18(%rsp), %r12
   13d5a:      	jne	0x13d67 <generic_rawtp_path+0x8c67>
   13d5c:      	cmpq	0x20(%rsp), %rdx
   13d61:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   13d67:      	movl	$0x4, %eax
   13d6c:      	leaq	0x10(%rsp), %rdi
   13d71:      	movl	$0x8, %esi
   13d76:      	callq	*%rax
   13d78:      	cmpq	0x10(%rsp), %r12
   13d7d:      	je	0x13e75 <generic_rawtp_path+0x8d75>
   13d83:      	leaq	0x18(%r12), %rbx
   13d88:      	movl	$0x4, %eax
   13d8d:      	movq	%rbp, %rdi
   13d90:      	movl	$0x8, %esi
   13d95:      	movq	%rbx, %rdx
   13d98:      	callq	*%rax
   13d9a:      	cmpq	%r12, (%rsp)
   13d9e:      	je	0x13e75 <generic_rawtp_path+0x8d75>
   13da4:      	movl	$0x4, %eax
   13da9:      	leaq	0x8(%rsp), %rdi
   13dae:      	movl	$0x8, %esi
   13db3:      	movq	%rbx, %rdx
   13db6:      	callq	*%rax
   13db8:      	addq	$0x20, %r12
   13dbc:      	movl	$0x4, %eax
   13dc1:      	leaq	0x58(%rsp), %rdi
   13dc6:      	movl	$0x10, %ecx
   13dcb:      	movl	$0x10, %esi
   13dd0:      	movq	%r12, %rdx
   13dd3:      	callq	*%rax
   13dd5:      	movq	0x28(%rsp), %rbx
   13dda:      	movq	0x48(%rsp), %rax
   13ddf:      	movl	0x5c(%rsp), %r15d
   13de4:      	subq	%rbx, %rax
   13de7:      	movl	0x50(%rsp), %r12d
   13dec:      	movl	%r15d, %edx
   13def:      	subl	%r12d, %edx
   13df2:      	movl	$0x0, %ecx
   13df7:      	cmovbl	%ecx, %edx
   13dfa:      	addq	0x60(%rsp), %rdx
   13dff:      	xorl	%esi, %esi
   13e01:      	cmpl	%r15d, %r12d
   13e04:      	seta	%sil
   13e08:      	movl	%r15d, %ecx
   13e0b:      	cmovbl	%r12d, %ecx
   13e0f:      	addl	%ecx, %esi
   13e11:      	movl	%r12d, %edi
   13e14:      	subl	%esi, %edi
   13e16:      	movl	%edi, 0x50(%rsp)
   13e1a:      	subq	%rsi, %rax
   13e1d:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   13e23:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13e29:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   13e2f:      	cmpl	%r15d, %r12d
   13e32:      	jbe	0x13e38 <generic_rawtp_path+0x8d38>
   13e34:      	movb	$0x2f, (%rbx,%rax)
   13e38:      	xorl	%edi, %edi
   13e3a:      	cmpl	%r15d, %r12d
   13e3d:      	seta	%dil
   13e41:      	movzbl	%cl, %esi
   13e44:      	addq	%rax, %rbx
   13e47:      	addq	%rbx, %rdi
   13e4a:      	movl	$0x4, %eax
   13e4f:      	callq	*%rax
   13e51:      	movq	%rbx, 0x48(%rsp)
   13e56:      	cmpl	%r15d, %r12d
   13e59:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   13e5f:      	movq	0x8(%rsp), %r12
   13e64:      	movq	%r12, 0x30(%rsp)
   13e69:      	movq	0x38(%rsp), %rdx
   13e6e:      	movq	0x40(%rsp), %r15
   13e73:      	jmp	0x13ec6 <generic_rawtp_path+0x8dc6>
   13e75:      	leaq	0x10(%r15), %rdx
   13e79:      	movl	$0x4, %eax
   13e7e:      	movq	%rbp, %rdi
   13e81:      	movl	$0x8, %esi
   13e86:      	callq	*%rax
   13e88:      	movq	0x40(%rsp), %rax
   13e8d:      	cmpq	(%rsp), %rax
   13e91:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   13e97:      	addq	$0x18, %r15
   13e9b:      	movl	$0x4, %eax
   13ea0:      	leaq	0x30(%rsp), %rdi
   13ea5:      	movl	$0x8, %esi
   13eaa:      	movq	%r15, %rdx
   13ead:      	callq	*%rax
   13eaf:      	movq	(%rsp), %r15
   13eb3:      	movq	%r15, 0x40(%rsp)
   13eb8:      	leaq	0x20(%r15), %rdx
   13ebc:      	movq	%rdx, 0x38(%rsp)
   13ec1:      	movq	0x30(%rsp), %r12
   13ec6:      	cmpq	0x18(%rsp), %r12
   13ecb:      	jne	0x13ed8 <generic_rawtp_path+0x8dd8>
   13ecd:      	cmpq	0x20(%rsp), %rdx
   13ed2:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   13ed8:      	movl	$0x4, %eax
   13edd:      	leaq	0x10(%rsp), %rdi
   13ee2:      	movl	$0x8, %esi
   13ee7:      	callq	*%rax
   13ee9:      	cmpq	0x10(%rsp), %r12
   13eee:      	je	0x13fe6 <generic_rawtp_path+0x8ee6>
   13ef4:      	leaq	0x18(%r12), %rbx
   13ef9:      	movl	$0x4, %eax
   13efe:      	movq	%rbp, %rdi
   13f01:      	movl	$0x8, %esi
   13f06:      	movq	%rbx, %rdx
   13f09:      	callq	*%rax
   13f0b:      	cmpq	%r12, (%rsp)
   13f0f:      	je	0x13fe6 <generic_rawtp_path+0x8ee6>
   13f15:      	movl	$0x4, %eax
   13f1a:      	leaq	0x8(%rsp), %rdi
   13f1f:      	movl	$0x8, %esi
   13f24:      	movq	%rbx, %rdx
   13f27:      	callq	*%rax
   13f29:      	addq	$0x20, %r12
   13f2d:      	movl	$0x4, %eax
   13f32:      	leaq	0x58(%rsp), %rdi
   13f37:      	movl	$0x10, %ecx
   13f3c:      	movl	$0x10, %esi
   13f41:      	movq	%r12, %rdx
   13f44:      	callq	*%rax
   13f46:      	movq	0x28(%rsp), %rbx
   13f4b:      	movq	0x48(%rsp), %rax
   13f50:      	movl	0x5c(%rsp), %r15d
   13f55:      	subq	%rbx, %rax
   13f58:      	movl	0x50(%rsp), %r12d
   13f5d:      	movl	%r15d, %edx
   13f60:      	subl	%r12d, %edx
   13f63:      	movl	$0x0, %ecx
   13f68:      	cmovbl	%ecx, %edx
   13f6b:      	addq	0x60(%rsp), %rdx
   13f70:      	xorl	%esi, %esi
   13f72:      	cmpl	%r15d, %r12d
   13f75:      	seta	%sil
   13f79:      	movl	%r15d, %ecx
   13f7c:      	cmovbl	%r12d, %ecx
   13f80:      	addl	%ecx, %esi
   13f82:      	movl	%r12d, %edi
   13f85:      	subl	%esi, %edi
   13f87:      	movl	%edi, 0x50(%rsp)
   13f8b:      	subq	%rsi, %rax
   13f8e:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   13f94:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13f9a:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   13fa0:      	cmpl	%r15d, %r12d
   13fa3:      	jbe	0x13fa9 <generic_rawtp_path+0x8ea9>
   13fa5:      	movb	$0x2f, (%rbx,%rax)
   13fa9:      	xorl	%edi, %edi
   13fab:      	cmpl	%r15d, %r12d
   13fae:      	seta	%dil
   13fb2:      	movzbl	%cl, %esi
   13fb5:      	addq	%rax, %rbx
   13fb8:      	addq	%rbx, %rdi
   13fbb:      	movl	$0x4, %eax
   13fc0:      	callq	*%rax
   13fc2:      	movq	%rbx, 0x48(%rsp)
   13fc7:      	cmpl	%r15d, %r12d
   13fca:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   13fd0:      	movq	0x8(%rsp), %r12
   13fd5:      	movq	%r12, 0x30(%rsp)
   13fda:      	movq	0x38(%rsp), %rdx
   13fdf:      	movq	0x40(%rsp), %r15
   13fe4:      	jmp	0x14037 <generic_rawtp_path+0x8f37>
   13fe6:      	leaq	0x10(%r15), %rdx
   13fea:      	movl	$0x4, %eax
   13fef:      	movq	%rbp, %rdi
   13ff2:      	movl	$0x8, %esi
   13ff7:      	callq	*%rax
   13ff9:      	movq	0x40(%rsp), %rax
   13ffe:      	cmpq	(%rsp), %rax
   14002:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   14008:      	addq	$0x18, %r15
   1400c:      	movl	$0x4, %eax
   14011:      	leaq	0x30(%rsp), %rdi
   14016:      	movl	$0x8, %esi
   1401b:      	movq	%r15, %rdx
   1401e:      	callq	*%rax
   14020:      	movq	(%rsp), %r15
   14024:      	movq	%r15, 0x40(%rsp)
   14029:      	leaq	0x20(%r15), %rdx
   1402d:      	movq	%rdx, 0x38(%rsp)
   14032:      	movq	0x30(%rsp), %r12
   14037:      	cmpq	0x18(%rsp), %r12
   1403c:      	jne	0x14049 <generic_rawtp_path+0x8f49>
   1403e:      	cmpq	0x20(%rsp), %rdx
   14043:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   14049:      	movl	$0x4, %eax
   1404e:      	leaq	0x10(%rsp), %rdi
   14053:      	movl	$0x8, %esi
   14058:      	callq	*%rax
   1405a:      	cmpq	0x10(%rsp), %r12
   1405f:      	je	0x14157 <generic_rawtp_path+0x9057>
   14065:      	leaq	0x18(%r12), %rbx
   1406a:      	movl	$0x4, %eax
   1406f:      	movq	%rbp, %rdi
   14072:      	movl	$0x8, %esi
   14077:      	movq	%rbx, %rdx
   1407a:      	callq	*%rax
   1407c:      	cmpq	%r12, (%rsp)
   14080:      	je	0x14157 <generic_rawtp_path+0x9057>
   14086:      	movl	$0x4, %eax
   1408b:      	leaq	0x8(%rsp), %rdi
   14090:      	movl	$0x8, %esi
   14095:      	movq	%rbx, %rdx
   14098:      	callq	*%rax
   1409a:      	addq	$0x20, %r12
   1409e:      	movl	$0x4, %eax
   140a3:      	leaq	0x58(%rsp), %rdi
   140a8:      	movl	$0x10, %ecx
   140ad:      	movl	$0x10, %esi
   140b2:      	movq	%r12, %rdx
   140b5:      	callq	*%rax
   140b7:      	movq	0x28(%rsp), %rbx
   140bc:      	movq	0x48(%rsp), %rax
   140c1:      	movl	0x5c(%rsp), %r15d
   140c6:      	subq	%rbx, %rax
   140c9:      	movl	0x50(%rsp), %r12d
   140ce:      	movl	%r15d, %edx
   140d1:      	subl	%r12d, %edx
   140d4:      	movl	$0x0, %ecx
   140d9:      	cmovbl	%ecx, %edx
   140dc:      	addq	0x60(%rsp), %rdx
   140e1:      	xorl	%esi, %esi
   140e3:      	cmpl	%r15d, %r12d
   140e6:      	seta	%sil
   140ea:      	movl	%r15d, %ecx
   140ed:      	cmovbl	%r12d, %ecx
   140f1:      	addl	%ecx, %esi
   140f3:      	movl	%r12d, %edi
   140f6:      	subl	%esi, %edi
   140f8:      	movl	%edi, 0x50(%rsp)
   140fc:      	subq	%rsi, %rax
   140ff:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   14105:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1410b:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   14111:      	cmpl	%r15d, %r12d
   14114:      	jbe	0x1411a <generic_rawtp_path+0x901a>
   14116:      	movb	$0x2f, (%rbx,%rax)
   1411a:      	xorl	%edi, %edi
   1411c:      	cmpl	%r15d, %r12d
   1411f:      	seta	%dil
   14123:      	movzbl	%cl, %esi
   14126:      	addq	%rax, %rbx
   14129:      	addq	%rbx, %rdi
   1412c:      	movl	$0x4, %eax
   14131:      	callq	*%rax
   14133:      	movq	%rbx, 0x48(%rsp)
   14138:      	cmpl	%r15d, %r12d
   1413b:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   14141:      	movq	0x8(%rsp), %r12
   14146:      	movq	%r12, 0x30(%rsp)
   1414b:      	movq	0x38(%rsp), %rdx
   14150:      	movq	0x40(%rsp), %r15
   14155:      	jmp	0x141a8 <generic_rawtp_path+0x90a8>
   14157:      	leaq	0x10(%r15), %rdx
   1415b:      	movl	$0x4, %eax
   14160:      	movq	%rbp, %rdi
   14163:      	movl	$0x8, %esi
   14168:      	callq	*%rax
   1416a:      	movq	0x40(%rsp), %rax
   1416f:      	cmpq	(%rsp), %rax
   14173:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   14179:      	addq	$0x18, %r15
   1417d:      	movl	$0x4, %eax
   14182:      	leaq	0x30(%rsp), %rdi
   14187:      	movl	$0x8, %esi
   1418c:      	movq	%r15, %rdx
   1418f:      	callq	*%rax
   14191:      	movq	(%rsp), %r15
   14195:      	movq	%r15, 0x40(%rsp)
   1419a:      	leaq	0x20(%r15), %rdx
   1419e:      	movq	%rdx, 0x38(%rsp)
   141a3:      	movq	0x30(%rsp), %r12
   141a8:      	cmpq	0x18(%rsp), %r12
   141ad:      	jne	0x141ba <generic_rawtp_path+0x90ba>
   141af:      	cmpq	0x20(%rsp), %rdx
   141b4:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   141ba:      	movl	$0x4, %eax
   141bf:      	leaq	0x10(%rsp), %rdi
   141c4:      	movl	$0x8, %esi
   141c9:      	callq	*%rax
   141cb:      	cmpq	0x10(%rsp), %r12
   141d0:      	je	0x142c8 <generic_rawtp_path+0x91c8>
   141d6:      	leaq	0x18(%r12), %rbx
   141db:      	movl	$0x4, %eax
   141e0:      	movq	%rbp, %rdi
   141e3:      	movl	$0x8, %esi
   141e8:      	movq	%rbx, %rdx
   141eb:      	callq	*%rax
   141ed:      	cmpq	%r12, (%rsp)
   141f1:      	je	0x142c8 <generic_rawtp_path+0x91c8>
   141f7:      	movl	$0x4, %eax
   141fc:      	leaq	0x8(%rsp), %rdi
   14201:      	movl	$0x8, %esi
   14206:      	movq	%rbx, %rdx
   14209:      	callq	*%rax
   1420b:      	addq	$0x20, %r12
   1420f:      	movl	$0x4, %eax
   14214:      	leaq	0x58(%rsp), %rdi
   14219:      	movl	$0x10, %ecx
   1421e:      	movl	$0x10, %esi
   14223:      	movq	%r12, %rdx
   14226:      	callq	*%rax
   14228:      	movq	0x28(%rsp), %rbx
   1422d:      	movq	0x48(%rsp), %rax
   14232:      	movl	0x5c(%rsp), %r15d
   14237:      	subq	%rbx, %rax
   1423a:      	movl	0x50(%rsp), %r12d
   1423f:      	movl	%r15d, %edx
   14242:      	subl	%r12d, %edx
   14245:      	movl	$0x0, %ecx
   1424a:      	cmovbl	%ecx, %edx
   1424d:      	addq	0x60(%rsp), %rdx
   14252:      	xorl	%esi, %esi
   14254:      	cmpl	%r15d, %r12d
   14257:      	seta	%sil
   1425b:      	movl	%r15d, %ecx
   1425e:      	cmovbl	%r12d, %ecx
   14262:      	addl	%ecx, %esi
   14264:      	movl	%r12d, %edi
   14267:      	subl	%esi, %edi
   14269:      	movl	%edi, 0x50(%rsp)
   1426d:      	subq	%rsi, %rax
   14270:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   14276:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1427c:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   14282:      	cmpl	%r15d, %r12d
   14285:      	jbe	0x1428b <generic_rawtp_path+0x918b>
   14287:      	movb	$0x2f, (%rbx,%rax)
   1428b:      	xorl	%edi, %edi
   1428d:      	cmpl	%r15d, %r12d
   14290:      	seta	%dil
   14294:      	movzbl	%cl, %esi
   14297:      	addq	%rax, %rbx
   1429a:      	addq	%rbx, %rdi
   1429d:      	movl	$0x4, %eax
   142a2:      	callq	*%rax
   142a4:      	movq	%rbx, 0x48(%rsp)
   142a9:      	cmpl	%r15d, %r12d
   142ac:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   142b2:      	movq	0x8(%rsp), %r12
   142b7:      	movq	%r12, 0x30(%rsp)
   142bc:      	movq	0x38(%rsp), %rdx
   142c1:      	movq	0x40(%rsp), %r15
   142c6:      	jmp	0x14319 <generic_rawtp_path+0x9219>
   142c8:      	leaq	0x10(%r15), %rdx
   142cc:      	movl	$0x4, %eax
   142d1:      	movq	%rbp, %rdi
   142d4:      	movl	$0x8, %esi
   142d9:      	callq	*%rax
   142db:      	movq	0x40(%rsp), %rax
   142e0:      	cmpq	(%rsp), %rax
   142e4:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   142ea:      	addq	$0x18, %r15
   142ee:      	movl	$0x4, %eax
   142f3:      	leaq	0x30(%rsp), %rdi
   142f8:      	movl	$0x8, %esi
   142fd:      	movq	%r15, %rdx
   14300:      	callq	*%rax
   14302:      	movq	(%rsp), %r15
   14306:      	movq	%r15, 0x40(%rsp)
   1430b:      	leaq	0x20(%r15), %rdx
   1430f:      	movq	%rdx, 0x38(%rsp)
   14314:      	movq	0x30(%rsp), %r12
   14319:      	cmpq	0x18(%rsp), %r12
   1431e:      	jne	0x1432b <generic_rawtp_path+0x922b>
   14320:      	cmpq	0x20(%rsp), %rdx
   14325:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   1432b:      	movl	$0x4, %eax
   14330:      	leaq	0x10(%rsp), %rdi
   14335:      	movl	$0x8, %esi
   1433a:      	callq	*%rax
   1433c:      	cmpq	0x10(%rsp), %r12
   14341:      	je	0x14439 <generic_rawtp_path+0x9339>
   14347:      	leaq	0x18(%r12), %rbx
   1434c:      	movl	$0x4, %eax
   14351:      	movq	%rbp, %rdi
   14354:      	movl	$0x8, %esi
   14359:      	movq	%rbx, %rdx
   1435c:      	callq	*%rax
   1435e:      	cmpq	%r12, (%rsp)
   14362:      	je	0x14439 <generic_rawtp_path+0x9339>
   14368:      	movl	$0x4, %eax
   1436d:      	leaq	0x8(%rsp), %rdi
   14372:      	movl	$0x8, %esi
   14377:      	movq	%rbx, %rdx
   1437a:      	callq	*%rax
   1437c:      	addq	$0x20, %r12
   14380:      	movl	$0x4, %eax
   14385:      	leaq	0x58(%rsp), %rdi
   1438a:      	movl	$0x10, %ecx
   1438f:      	movl	$0x10, %esi
   14394:      	movq	%r12, %rdx
   14397:      	callq	*%rax
   14399:      	movq	0x28(%rsp), %rbx
   1439e:      	movq	0x48(%rsp), %rax
   143a3:      	movl	0x5c(%rsp), %r15d
   143a8:      	subq	%rbx, %rax
   143ab:      	movl	0x50(%rsp), %r12d
   143b0:      	movl	%r15d, %edx
   143b3:      	subl	%r12d, %edx
   143b6:      	movl	$0x0, %ecx
   143bb:      	cmovbl	%ecx, %edx
   143be:      	addq	0x60(%rsp), %rdx
   143c3:      	xorl	%esi, %esi
   143c5:      	cmpl	%r15d, %r12d
   143c8:      	seta	%sil
   143cc:      	movl	%r15d, %ecx
   143cf:      	cmovbl	%r12d, %ecx
   143d3:      	addl	%ecx, %esi
   143d5:      	movl	%r12d, %edi
   143d8:      	subl	%esi, %edi
   143da:      	movl	%edi, 0x50(%rsp)
   143de:      	subq	%rsi, %rax
   143e1:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   143e7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   143ed:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   143f3:      	cmpl	%r15d, %r12d
   143f6:      	jbe	0x143fc <generic_rawtp_path+0x92fc>
   143f8:      	movb	$0x2f, (%rbx,%rax)
   143fc:      	xorl	%edi, %edi
   143fe:      	cmpl	%r15d, %r12d
   14401:      	seta	%dil
   14405:      	movzbl	%cl, %esi
   14408:      	addq	%rax, %rbx
   1440b:      	addq	%rbx, %rdi
   1440e:      	movl	$0x4, %eax
   14413:      	callq	*%rax
   14415:      	movq	%rbx, 0x48(%rsp)
   1441a:      	cmpl	%r15d, %r12d
   1441d:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   14423:      	movq	0x8(%rsp), %r12
   14428:      	movq	%r12, 0x30(%rsp)
   1442d:      	movq	0x38(%rsp), %rdx
   14432:      	movq	0x40(%rsp), %r15
   14437:      	jmp	0x1448a <generic_rawtp_path+0x938a>
   14439:      	leaq	0x10(%r15), %rdx
   1443d:      	movl	$0x4, %eax
   14442:      	movq	%rbp, %rdi
   14445:      	movl	$0x8, %esi
   1444a:      	callq	*%rax
   1444c:      	movq	0x40(%rsp), %rax
   14451:      	cmpq	(%rsp), %rax
   14455:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   1445b:      	addq	$0x18, %r15
   1445f:      	movl	$0x4, %eax
   14464:      	leaq	0x30(%rsp), %rdi
   14469:      	movl	$0x8, %esi
   1446e:      	movq	%r15, %rdx
   14471:      	callq	*%rax
   14473:      	movq	(%rsp), %r15
   14477:      	movq	%r15, 0x40(%rsp)
   1447c:      	leaq	0x20(%r15), %rdx
   14480:      	movq	%rdx, 0x38(%rsp)
   14485:      	movq	0x30(%rsp), %r12
   1448a:      	cmpq	0x18(%rsp), %r12
   1448f:      	jne	0x1449c <generic_rawtp_path+0x939c>
   14491:      	cmpq	0x20(%rsp), %rdx
   14496:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   1449c:      	movl	$0x4, %eax
   144a1:      	leaq	0x10(%rsp), %rdi
   144a6:      	movl	$0x8, %esi
   144ab:      	callq	*%rax
   144ad:      	cmpq	0x10(%rsp), %r12
   144b2:      	je	0x145aa <generic_rawtp_path+0x94aa>
   144b8:      	leaq	0x18(%r12), %rbx
   144bd:      	movl	$0x4, %eax
   144c2:      	movq	%rbp, %rdi
   144c5:      	movl	$0x8, %esi
   144ca:      	movq	%rbx, %rdx
   144cd:      	callq	*%rax
   144cf:      	cmpq	%r12, (%rsp)
   144d3:      	je	0x145aa <generic_rawtp_path+0x94aa>
   144d9:      	movl	$0x4, %eax
   144de:      	leaq	0x8(%rsp), %rdi
   144e3:      	movl	$0x8, %esi
   144e8:      	movq	%rbx, %rdx
   144eb:      	callq	*%rax
   144ed:      	addq	$0x20, %r12
   144f1:      	movl	$0x4, %eax
   144f6:      	leaq	0x58(%rsp), %rdi
   144fb:      	movl	$0x10, %ecx
   14500:      	movl	$0x10, %esi
   14505:      	movq	%r12, %rdx
   14508:      	callq	*%rax
   1450a:      	movq	0x28(%rsp), %rbx
   1450f:      	movq	0x48(%rsp), %rax
   14514:      	movl	0x5c(%rsp), %r15d
   14519:      	subq	%rbx, %rax
   1451c:      	movl	0x50(%rsp), %r12d
   14521:      	movl	%r15d, %edx
   14524:      	subl	%r12d, %edx
   14527:      	movl	$0x0, %ecx
   1452c:      	cmovbl	%ecx, %edx
   1452f:      	addq	0x60(%rsp), %rdx
   14534:      	xorl	%esi, %esi
   14536:      	cmpl	%r15d, %r12d
   14539:      	seta	%sil
   1453d:      	movl	%r15d, %ecx
   14540:      	cmovbl	%r12d, %ecx
   14544:      	addl	%ecx, %esi
   14546:      	movl	%r12d, %edi
   14549:      	subl	%esi, %edi
   1454b:      	movl	%edi, 0x50(%rsp)
   1454f:      	subq	%rsi, %rax
   14552:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   14558:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1455e:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   14564:      	cmpl	%r15d, %r12d
   14567:      	jbe	0x1456d <generic_rawtp_path+0x946d>
   14569:      	movb	$0x2f, (%rbx,%rax)
   1456d:      	xorl	%edi, %edi
   1456f:      	cmpl	%r15d, %r12d
   14572:      	seta	%dil
   14576:      	movzbl	%cl, %esi
   14579:      	addq	%rax, %rbx
   1457c:      	addq	%rbx, %rdi
   1457f:      	movl	$0x4, %eax
   14584:      	callq	*%rax
   14586:      	movq	%rbx, 0x48(%rsp)
   1458b:      	cmpl	%r15d, %r12d
   1458e:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   14594:      	movq	0x8(%rsp), %r12
   14599:      	movq	%r12, 0x30(%rsp)
   1459e:      	movq	0x38(%rsp), %rdx
   145a3:      	movq	0x40(%rsp), %r15
   145a8:      	jmp	0x145fb <generic_rawtp_path+0x94fb>
   145aa:      	leaq	0x10(%r15), %rdx
   145ae:      	movl	$0x4, %eax
   145b3:      	movq	%rbp, %rdi
   145b6:      	movl	$0x8, %esi
   145bb:      	callq	*%rax
   145bd:      	movq	0x40(%rsp), %rax
   145c2:      	cmpq	(%rsp), %rax
   145c6:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   145cc:      	addq	$0x18, %r15
   145d0:      	movl	$0x4, %eax
   145d5:      	leaq	0x30(%rsp), %rdi
   145da:      	movl	$0x8, %esi
   145df:      	movq	%r15, %rdx
   145e2:      	callq	*%rax
   145e4:      	movq	(%rsp), %r15
   145e8:      	movq	%r15, 0x40(%rsp)
   145ed:      	leaq	0x20(%r15), %rdx
   145f1:      	movq	%rdx, 0x38(%rsp)
   145f6:      	movq	0x30(%rsp), %r12
   145fb:      	cmpq	0x18(%rsp), %r12
   14600:      	jne	0x1460d <generic_rawtp_path+0x950d>
   14602:      	cmpq	0x20(%rsp), %rdx
   14607:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   1460d:      	movl	$0x4, %eax
   14612:      	leaq	0x10(%rsp), %rdi
   14617:      	movl	$0x8, %esi
   1461c:      	callq	*%rax
   1461e:      	cmpq	0x10(%rsp), %r12
   14623:      	je	0x1471b <generic_rawtp_path+0x961b>
   14629:      	leaq	0x18(%r12), %rbx
   1462e:      	movl	$0x4, %eax
   14633:      	movq	%rbp, %rdi
   14636:      	movl	$0x8, %esi
   1463b:      	movq	%rbx, %rdx
   1463e:      	callq	*%rax
   14640:      	cmpq	%r12, (%rsp)
   14644:      	je	0x1471b <generic_rawtp_path+0x961b>
   1464a:      	movl	$0x4, %eax
   1464f:      	leaq	0x8(%rsp), %rdi
   14654:      	movl	$0x8, %esi
   14659:      	movq	%rbx, %rdx
   1465c:      	callq	*%rax
   1465e:      	addq	$0x20, %r12
   14662:      	movl	$0x4, %eax
   14667:      	leaq	0x58(%rsp), %rdi
   1466c:      	movl	$0x10, %ecx
   14671:      	movl	$0x10, %esi
   14676:      	movq	%r12, %rdx
   14679:      	callq	*%rax
   1467b:      	movq	0x28(%rsp), %rbx
   14680:      	movq	0x48(%rsp), %rax
   14685:      	movl	0x5c(%rsp), %r15d
   1468a:      	subq	%rbx, %rax
   1468d:      	movl	0x50(%rsp), %r12d
   14692:      	movl	%r15d, %edx
   14695:      	subl	%r12d, %edx
   14698:      	movl	$0x0, %ecx
   1469d:      	cmovbl	%ecx, %edx
   146a0:      	addq	0x60(%rsp), %rdx
   146a5:      	xorl	%esi, %esi
   146a7:      	cmpl	%r15d, %r12d
   146aa:      	seta	%sil
   146ae:      	movl	%r15d, %ecx
   146b1:      	cmovbl	%r12d, %ecx
   146b5:      	addl	%ecx, %esi
   146b7:      	movl	%r12d, %edi
   146ba:      	subl	%esi, %edi
   146bc:      	movl	%edi, 0x50(%rsp)
   146c0:      	subq	%rsi, %rax
   146c3:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   146c9:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   146cf:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   146d5:      	cmpl	%r15d, %r12d
   146d8:      	jbe	0x146de <generic_rawtp_path+0x95de>
   146da:      	movb	$0x2f, (%rbx,%rax)
   146de:      	xorl	%edi, %edi
   146e0:      	cmpl	%r15d, %r12d
   146e3:      	seta	%dil
   146e7:      	movzbl	%cl, %esi
   146ea:      	addq	%rax, %rbx
   146ed:      	addq	%rbx, %rdi
   146f0:      	movl	$0x4, %eax
   146f5:      	callq	*%rax
   146f7:      	movq	%rbx, 0x48(%rsp)
   146fc:      	cmpl	%r15d, %r12d
   146ff:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   14705:      	movq	0x8(%rsp), %r12
   1470a:      	movq	%r12, 0x30(%rsp)
   1470f:      	movq	0x38(%rsp), %rdx
   14714:      	movq	0x40(%rsp), %r15
   14719:      	jmp	0x1476c <generic_rawtp_path+0x966c>
   1471b:      	leaq	0x10(%r15), %rdx
   1471f:      	movl	$0x4, %eax
   14724:      	movq	%rbp, %rdi
   14727:      	movl	$0x8, %esi
   1472c:      	callq	*%rax
   1472e:      	movq	0x40(%rsp), %rax
   14733:      	cmpq	(%rsp), %rax
   14737:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   1473d:      	addq	$0x18, %r15
   14741:      	movl	$0x4, %eax
   14746:      	leaq	0x30(%rsp), %rdi
   1474b:      	movl	$0x8, %esi
   14750:      	movq	%r15, %rdx
   14753:      	callq	*%rax
   14755:      	movq	(%rsp), %r15
   14759:      	movq	%r15, 0x40(%rsp)
   1475e:      	leaq	0x20(%r15), %rdx
   14762:      	movq	%rdx, 0x38(%rsp)
   14767:      	movq	0x30(%rsp), %r12
   1476c:      	cmpq	0x18(%rsp), %r12
   14771:      	jne	0x1477e <generic_rawtp_path+0x967e>
   14773:      	cmpq	0x20(%rsp), %rdx
   14778:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   1477e:      	movl	$0x4, %eax
   14783:      	leaq	0x10(%rsp), %rdi
   14788:      	movl	$0x8, %esi
   1478d:      	callq	*%rax
   1478f:      	cmpq	0x10(%rsp), %r12
   14794:      	je	0x1488c <generic_rawtp_path+0x978c>
   1479a:      	leaq	0x18(%r12), %rbx
   1479f:      	movl	$0x4, %eax
   147a4:      	movq	%rbp, %rdi
   147a7:      	movl	$0x8, %esi
   147ac:      	movq	%rbx, %rdx
   147af:      	callq	*%rax
   147b1:      	cmpq	%r12, (%rsp)
   147b5:      	je	0x1488c <generic_rawtp_path+0x978c>
   147bb:      	movl	$0x4, %eax
   147c0:      	leaq	0x8(%rsp), %rdi
   147c5:      	movl	$0x8, %esi
   147ca:      	movq	%rbx, %rdx
   147cd:      	callq	*%rax
   147cf:      	addq	$0x20, %r12
   147d3:      	movl	$0x4, %eax
   147d8:      	leaq	0x58(%rsp), %rdi
   147dd:      	movl	$0x10, %ecx
   147e2:      	movl	$0x10, %esi
   147e7:      	movq	%r12, %rdx
   147ea:      	callq	*%rax
   147ec:      	movq	0x28(%rsp), %rbx
   147f1:      	movq	0x48(%rsp), %rax
   147f6:      	movl	0x5c(%rsp), %r15d
   147fb:      	subq	%rbx, %rax
   147fe:      	movl	0x50(%rsp), %r12d
   14803:      	movl	%r15d, %edx
   14806:      	subl	%r12d, %edx
   14809:      	movl	$0x0, %ecx
   1480e:      	cmovbl	%ecx, %edx
   14811:      	addq	0x60(%rsp), %rdx
   14816:      	xorl	%esi, %esi
   14818:      	cmpl	%r15d, %r12d
   1481b:      	seta	%sil
   1481f:      	movl	%r15d, %ecx
   14822:      	cmovbl	%r12d, %ecx
   14826:      	addl	%ecx, %esi
   14828:      	movl	%r12d, %edi
   1482b:      	subl	%esi, %edi
   1482d:      	movl	%edi, 0x50(%rsp)
   14831:      	subq	%rsi, %rax
   14834:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   1483a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14840:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   14846:      	cmpl	%r15d, %r12d
   14849:      	jbe	0x1484f <generic_rawtp_path+0x974f>
   1484b:      	movb	$0x2f, (%rbx,%rax)
   1484f:      	xorl	%edi, %edi
   14851:      	cmpl	%r15d, %r12d
   14854:      	seta	%dil
   14858:      	movzbl	%cl, %esi
   1485b:      	addq	%rax, %rbx
   1485e:      	addq	%rbx, %rdi
   14861:      	movl	$0x4, %eax
   14866:      	callq	*%rax
   14868:      	movq	%rbx, 0x48(%rsp)
   1486d:      	cmpl	%r15d, %r12d
   14870:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   14876:      	movq	0x8(%rsp), %r12
   1487b:      	movq	%r12, 0x30(%rsp)
   14880:      	movq	0x38(%rsp), %rdx
   14885:      	movq	0x40(%rsp), %r15
   1488a:      	jmp	0x148dd <generic_rawtp_path+0x97dd>
   1488c:      	leaq	0x10(%r15), %rdx
   14890:      	movl	$0x4, %eax
   14895:      	movq	%rbp, %rdi
   14898:      	movl	$0x8, %esi
   1489d:      	callq	*%rax
   1489f:      	movq	0x40(%rsp), %rax
   148a4:      	cmpq	(%rsp), %rax
   148a8:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   148ae:      	addq	$0x18, %r15
   148b2:      	movl	$0x4, %eax
   148b7:      	leaq	0x30(%rsp), %rdi
   148bc:      	movl	$0x8, %esi
   148c1:      	movq	%r15, %rdx
   148c4:      	callq	*%rax
   148c6:      	movq	(%rsp), %r15
   148ca:      	movq	%r15, 0x40(%rsp)
   148cf:      	leaq	0x20(%r15), %rdx
   148d3:      	movq	%rdx, 0x38(%rsp)
   148d8:      	movq	0x30(%rsp), %r12
   148dd:      	cmpq	0x18(%rsp), %r12
   148e2:      	jne	0x148ef <generic_rawtp_path+0x97ef>
   148e4:      	cmpq	0x20(%rsp), %rdx
   148e9:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   148ef:      	movl	$0x4, %eax
   148f4:      	leaq	0x10(%rsp), %rdi
   148f9:      	movl	$0x8, %esi
   148fe:      	callq	*%rax
   14900:      	cmpq	0x10(%rsp), %r12
   14905:      	je	0x149fd <generic_rawtp_path+0x98fd>
   1490b:      	leaq	0x18(%r12), %rbx
   14910:      	movl	$0x4, %eax
   14915:      	movq	%rbp, %rdi
   14918:      	movl	$0x8, %esi
   1491d:      	movq	%rbx, %rdx
   14920:      	callq	*%rax
   14922:      	cmpq	%r12, (%rsp)
   14926:      	je	0x149fd <generic_rawtp_path+0x98fd>
   1492c:      	movl	$0x4, %eax
   14931:      	leaq	0x8(%rsp), %rdi
   14936:      	movl	$0x8, %esi
   1493b:      	movq	%rbx, %rdx
   1493e:      	callq	*%rax
   14940:      	addq	$0x20, %r12
   14944:      	movl	$0x4, %eax
   14949:      	leaq	0x58(%rsp), %rdi
   1494e:      	movl	$0x10, %ecx
   14953:      	movl	$0x10, %esi
   14958:      	movq	%r12, %rdx
   1495b:      	callq	*%rax
   1495d:      	movq	0x28(%rsp), %rbx
   14962:      	movq	0x48(%rsp), %rax
   14967:      	movl	0x5c(%rsp), %r15d
   1496c:      	subq	%rbx, %rax
   1496f:      	movl	0x50(%rsp), %r12d
   14974:      	movl	%r15d, %edx
   14977:      	subl	%r12d, %edx
   1497a:      	movl	$0x0, %ecx
   1497f:      	cmovbl	%ecx, %edx
   14982:      	addq	0x60(%rsp), %rdx
   14987:      	xorl	%esi, %esi
   14989:      	cmpl	%r15d, %r12d
   1498c:      	seta	%sil
   14990:      	movl	%r15d, %ecx
   14993:      	cmovbl	%r12d, %ecx
   14997:      	addl	%ecx, %esi
   14999:      	movl	%r12d, %edi
   1499c:      	subl	%esi, %edi
   1499e:      	movl	%edi, 0x50(%rsp)
   149a2:      	subq	%rsi, %rax
   149a5:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   149ab:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   149b1:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   149b7:      	cmpl	%r15d, %r12d
   149ba:      	jbe	0x149c0 <generic_rawtp_path+0x98c0>
   149bc:      	movb	$0x2f, (%rbx,%rax)
   149c0:      	xorl	%edi, %edi
   149c2:      	cmpl	%r15d, %r12d
   149c5:      	seta	%dil
   149c9:      	movzbl	%cl, %esi
   149cc:      	addq	%rax, %rbx
   149cf:      	addq	%rbx, %rdi
   149d2:      	movl	$0x4, %eax
   149d7:      	callq	*%rax
   149d9:      	movq	%rbx, 0x48(%rsp)
   149de:      	cmpl	%r15d, %r12d
   149e1:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   149e7:      	movq	0x8(%rsp), %r12
   149ec:      	movq	%r12, 0x30(%rsp)
   149f1:      	movq	0x38(%rsp), %rdx
   149f6:      	movq	0x40(%rsp), %r15
   149fb:      	jmp	0x14a4e <generic_rawtp_path+0x994e>
   149fd:      	leaq	0x10(%r15), %rdx
   14a01:      	movl	$0x4, %eax
   14a06:      	movq	%rbp, %rdi
   14a09:      	movl	$0x8, %esi
   14a0e:      	callq	*%rax
   14a10:      	movq	0x40(%rsp), %rax
   14a15:      	cmpq	(%rsp), %rax
   14a19:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   14a1f:      	addq	$0x18, %r15
   14a23:      	movl	$0x4, %eax
   14a28:      	leaq	0x30(%rsp), %rdi
   14a2d:      	movl	$0x8, %esi
   14a32:      	movq	%r15, %rdx
   14a35:      	callq	*%rax
   14a37:      	movq	(%rsp), %r15
   14a3b:      	movq	%r15, 0x40(%rsp)
   14a40:      	leaq	0x20(%r15), %rdx
   14a44:      	movq	%rdx, 0x38(%rsp)
   14a49:      	movq	0x30(%rsp), %r12
   14a4e:      	cmpq	0x18(%rsp), %r12
   14a53:      	jne	0x14a60 <generic_rawtp_path+0x9960>
   14a55:      	cmpq	0x20(%rsp), %rdx
   14a5a:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   14a60:      	movl	$0x4, %eax
   14a65:      	leaq	0x10(%rsp), %rdi
   14a6a:      	movl	$0x8, %esi
   14a6f:      	callq	*%rax
   14a71:      	cmpq	0x10(%rsp), %r12
   14a76:      	je	0x14b6e <generic_rawtp_path+0x9a6e>
   14a7c:      	leaq	0x18(%r12), %rbx
   14a81:      	movl	$0x4, %eax
   14a86:      	movq	%rbp, %rdi
   14a89:      	movl	$0x8, %esi
   14a8e:      	movq	%rbx, %rdx
   14a91:      	callq	*%rax
   14a93:      	cmpq	%r12, (%rsp)
   14a97:      	je	0x14b6e <generic_rawtp_path+0x9a6e>
   14a9d:      	movl	$0x4, %eax
   14aa2:      	leaq	0x8(%rsp), %rdi
   14aa7:      	movl	$0x8, %esi
   14aac:      	movq	%rbx, %rdx
   14aaf:      	callq	*%rax
   14ab1:      	addq	$0x20, %r12
   14ab5:      	movl	$0x4, %eax
   14aba:      	leaq	0x58(%rsp), %rdi
   14abf:      	movl	$0x10, %ecx
   14ac4:      	movl	$0x10, %esi
   14ac9:      	movq	%r12, %rdx
   14acc:      	callq	*%rax
   14ace:      	movq	0x28(%rsp), %rbx
   14ad3:      	movq	0x48(%rsp), %rax
   14ad8:      	movl	0x5c(%rsp), %r15d
   14add:      	subq	%rbx, %rax
   14ae0:      	movl	0x50(%rsp), %r12d
   14ae5:      	movl	%r15d, %edx
   14ae8:      	subl	%r12d, %edx
   14aeb:      	movl	$0x0, %ecx
   14af0:      	cmovbl	%ecx, %edx
   14af3:      	addq	0x60(%rsp), %rdx
   14af8:      	xorl	%esi, %esi
   14afa:      	cmpl	%r15d, %r12d
   14afd:      	seta	%sil
   14b01:      	movl	%r15d, %ecx
   14b04:      	cmovbl	%r12d, %ecx
   14b08:      	addl	%ecx, %esi
   14b0a:      	movl	%r12d, %edi
   14b0d:      	subl	%esi, %edi
   14b0f:      	movl	%edi, 0x50(%rsp)
   14b13:      	subq	%rsi, %rax
   14b16:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   14b1c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14b22:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   14b28:      	cmpl	%r15d, %r12d
   14b2b:      	jbe	0x14b31 <generic_rawtp_path+0x9a31>
   14b2d:      	movb	$0x2f, (%rbx,%rax)
   14b31:      	xorl	%edi, %edi
   14b33:      	cmpl	%r15d, %r12d
   14b36:      	seta	%dil
   14b3a:      	movzbl	%cl, %esi
   14b3d:      	addq	%rax, %rbx
   14b40:      	addq	%rbx, %rdi
   14b43:      	movl	$0x4, %eax
   14b48:      	callq	*%rax
   14b4a:      	movq	%rbx, 0x48(%rsp)
   14b4f:      	cmpl	%r15d, %r12d
   14b52:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   14b58:      	movq	0x8(%rsp), %r12
   14b5d:      	movq	%r12, 0x30(%rsp)
   14b62:      	movq	0x38(%rsp), %rdx
   14b67:      	movq	0x40(%rsp), %r15
   14b6c:      	jmp	0x14bbf <generic_rawtp_path+0x9abf>
   14b6e:      	leaq	0x10(%r15), %rdx
   14b72:      	movl	$0x4, %eax
   14b77:      	movq	%rbp, %rdi
   14b7a:      	movl	$0x8, %esi
   14b7f:      	callq	*%rax
   14b81:      	movq	0x40(%rsp), %rax
   14b86:      	cmpq	(%rsp), %rax
   14b8a:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   14b90:      	addq	$0x18, %r15
   14b94:      	movl	$0x4, %eax
   14b99:      	leaq	0x30(%rsp), %rdi
   14b9e:      	movl	$0x8, %esi
   14ba3:      	movq	%r15, %rdx
   14ba6:      	callq	*%rax
   14ba8:      	movq	(%rsp), %r15
   14bac:      	movq	%r15, 0x40(%rsp)
   14bb1:      	leaq	0x20(%r15), %rdx
   14bb5:      	movq	%rdx, 0x38(%rsp)
   14bba:      	movq	0x30(%rsp), %r12
   14bbf:      	cmpq	0x18(%rsp), %r12
   14bc4:      	jne	0x14bd1 <generic_rawtp_path+0x9ad1>
   14bc6:      	cmpq	0x20(%rsp), %rdx
   14bcb:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   14bd1:      	movl	$0x4, %eax
   14bd6:      	leaq	0x10(%rsp), %rdi
   14bdb:      	movl	$0x8, %esi
   14be0:      	callq	*%rax
   14be2:      	cmpq	0x10(%rsp), %r12
   14be7:      	je	0x14cdf <generic_rawtp_path+0x9bdf>
   14bed:      	leaq	0x18(%r12), %rbx
   14bf2:      	movl	$0x4, %eax
   14bf7:      	movq	%rbp, %rdi
   14bfa:      	movl	$0x8, %esi
   14bff:      	movq	%rbx, %rdx
   14c02:      	callq	*%rax
   14c04:      	cmpq	%r12, (%rsp)
   14c08:      	je	0x14cdf <generic_rawtp_path+0x9bdf>
   14c0e:      	movl	$0x4, %eax
   14c13:      	leaq	0x8(%rsp), %rdi
   14c18:      	movl	$0x8, %esi
   14c1d:      	movq	%rbx, %rdx
   14c20:      	callq	*%rax
   14c22:      	addq	$0x20, %r12
   14c26:      	movl	$0x4, %eax
   14c2b:      	leaq	0x58(%rsp), %rdi
   14c30:      	movl	$0x10, %ecx
   14c35:      	movl	$0x10, %esi
   14c3a:      	movq	%r12, %rdx
   14c3d:      	callq	*%rax
   14c3f:      	movq	0x28(%rsp), %rbx
   14c44:      	movq	0x48(%rsp), %rax
   14c49:      	movl	0x5c(%rsp), %r15d
   14c4e:      	subq	%rbx, %rax
   14c51:      	movl	0x50(%rsp), %r12d
   14c56:      	movl	%r15d, %edx
   14c59:      	subl	%r12d, %edx
   14c5c:      	movl	$0x0, %ecx
   14c61:      	cmovbl	%ecx, %edx
   14c64:      	addq	0x60(%rsp), %rdx
   14c69:      	xorl	%esi, %esi
   14c6b:      	cmpl	%r15d, %r12d
   14c6e:      	seta	%sil
   14c72:      	movl	%r15d, %ecx
   14c75:      	cmovbl	%r12d, %ecx
   14c79:      	addl	%ecx, %esi
   14c7b:      	movl	%r12d, %edi
   14c7e:      	subl	%esi, %edi
   14c80:      	movl	%edi, 0x50(%rsp)
   14c84:      	subq	%rsi, %rax
   14c87:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   14c8d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14c93:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   14c99:      	cmpl	%r15d, %r12d
   14c9c:      	jbe	0x14ca2 <generic_rawtp_path+0x9ba2>
   14c9e:      	movb	$0x2f, (%rbx,%rax)
   14ca2:      	xorl	%edi, %edi
   14ca4:      	cmpl	%r15d, %r12d
   14ca7:      	seta	%dil
   14cab:      	movzbl	%cl, %esi
   14cae:      	addq	%rax, %rbx
   14cb1:      	addq	%rbx, %rdi
   14cb4:      	movl	$0x4, %eax
   14cb9:      	callq	*%rax
   14cbb:      	movq	%rbx, 0x48(%rsp)
   14cc0:      	cmpl	%r15d, %r12d
   14cc3:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   14cc9:      	movq	0x8(%rsp), %r12
   14cce:      	movq	%r12, 0x30(%rsp)
   14cd3:      	movq	0x38(%rsp), %rdx
   14cd8:      	movq	0x40(%rsp), %r15
   14cdd:      	jmp	0x14d30 <generic_rawtp_path+0x9c30>
   14cdf:      	leaq	0x10(%r15), %rdx
   14ce3:      	movl	$0x4, %eax
   14ce8:      	movq	%rbp, %rdi
   14ceb:      	movl	$0x8, %esi
   14cf0:      	callq	*%rax
   14cf2:      	movq	0x40(%rsp), %rax
   14cf7:      	cmpq	(%rsp), %rax
   14cfb:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   14d01:      	addq	$0x18, %r15
   14d05:      	movl	$0x4, %eax
   14d0a:      	leaq	0x30(%rsp), %rdi
   14d0f:      	movl	$0x8, %esi
   14d14:      	movq	%r15, %rdx
   14d17:      	callq	*%rax
   14d19:      	movq	(%rsp), %r15
   14d1d:      	movq	%r15, 0x40(%rsp)
   14d22:      	leaq	0x20(%r15), %rdx
   14d26:      	movq	%rdx, 0x38(%rsp)
   14d2b:      	movq	0x30(%rsp), %r12
   14d30:      	cmpq	0x18(%rsp), %r12
   14d35:      	jne	0x14d42 <generic_rawtp_path+0x9c42>
   14d37:      	cmpq	0x20(%rsp), %rdx
   14d3c:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   14d42:      	movl	$0x4, %eax
   14d47:      	leaq	0x10(%rsp), %rdi
   14d4c:      	movl	$0x8, %esi
   14d51:      	callq	*%rax
   14d53:      	cmpq	0x10(%rsp), %r12
   14d58:      	je	0x14e50 <generic_rawtp_path+0x9d50>
   14d5e:      	leaq	0x18(%r12), %rbx
   14d63:      	movl	$0x4, %eax
   14d68:      	movq	%rbp, %rdi
   14d6b:      	movl	$0x8, %esi
   14d70:      	movq	%rbx, %rdx
   14d73:      	callq	*%rax
   14d75:      	cmpq	%r12, (%rsp)
   14d79:      	je	0x14e50 <generic_rawtp_path+0x9d50>
   14d7f:      	movl	$0x4, %eax
   14d84:      	leaq	0x8(%rsp), %rdi
   14d89:      	movl	$0x8, %esi
   14d8e:      	movq	%rbx, %rdx
   14d91:      	callq	*%rax
   14d93:      	addq	$0x20, %r12
   14d97:      	movl	$0x4, %eax
   14d9c:      	leaq	0x58(%rsp), %rdi
   14da1:      	movl	$0x10, %ecx
   14da6:      	movl	$0x10, %esi
   14dab:      	movq	%r12, %rdx
   14dae:      	callq	*%rax
   14db0:      	movq	0x28(%rsp), %rbx
   14db5:      	movq	0x48(%rsp), %rax
   14dba:      	movl	0x5c(%rsp), %r15d
   14dbf:      	subq	%rbx, %rax
   14dc2:      	movl	0x50(%rsp), %r12d
   14dc7:      	movl	%r15d, %edx
   14dca:      	subl	%r12d, %edx
   14dcd:      	movl	$0x0, %ecx
   14dd2:      	cmovbl	%ecx, %edx
   14dd5:      	addq	0x60(%rsp), %rdx
   14dda:      	xorl	%esi, %esi
   14ddc:      	cmpl	%r15d, %r12d
   14ddf:      	seta	%sil
   14de3:      	movl	%r15d, %ecx
   14de6:      	cmovbl	%r12d, %ecx
   14dea:      	addl	%ecx, %esi
   14dec:      	movl	%r12d, %edi
   14def:      	subl	%esi, %edi
   14df1:      	movl	%edi, 0x50(%rsp)
   14df5:      	subq	%rsi, %rax
   14df8:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   14dfe:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14e04:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   14e0a:      	cmpl	%r15d, %r12d
   14e0d:      	jbe	0x14e13 <generic_rawtp_path+0x9d13>
   14e0f:      	movb	$0x2f, (%rbx,%rax)
   14e13:      	xorl	%edi, %edi
   14e15:      	cmpl	%r15d, %r12d
   14e18:      	seta	%dil
   14e1c:      	movzbl	%cl, %esi
   14e1f:      	addq	%rax, %rbx
   14e22:      	addq	%rbx, %rdi
   14e25:      	movl	$0x4, %eax
   14e2a:      	callq	*%rax
   14e2c:      	movq	%rbx, 0x48(%rsp)
   14e31:      	cmpl	%r15d, %r12d
   14e34:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   14e3a:      	movq	0x8(%rsp), %r12
   14e3f:      	movq	%r12, 0x30(%rsp)
   14e44:      	movq	0x38(%rsp), %rdx
   14e49:      	movq	0x40(%rsp), %r15
   14e4e:      	jmp	0x14ea1 <generic_rawtp_path+0x9da1>
   14e50:      	leaq	0x10(%r15), %rdx
   14e54:      	movl	$0x4, %eax
   14e59:      	movq	%rbp, %rdi
   14e5c:      	movl	$0x8, %esi
   14e61:      	callq	*%rax
   14e63:      	movq	0x40(%rsp), %rax
   14e68:      	cmpq	(%rsp), %rax
   14e6c:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   14e72:      	addq	$0x18, %r15
   14e76:      	movl	$0x4, %eax
   14e7b:      	leaq	0x30(%rsp), %rdi
   14e80:      	movl	$0x8, %esi
   14e85:      	movq	%r15, %rdx
   14e88:      	callq	*%rax
   14e8a:      	movq	(%rsp), %r15
   14e8e:      	movq	%r15, 0x40(%rsp)
   14e93:      	leaq	0x20(%r15), %rdx
   14e97:      	movq	%rdx, 0x38(%rsp)
   14e9c:      	movq	0x30(%rsp), %r12
   14ea1:      	cmpq	0x18(%rsp), %r12
   14ea6:      	jne	0x14eb3 <generic_rawtp_path+0x9db3>
   14ea8:      	cmpq	0x20(%rsp), %rdx
   14ead:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   14eb3:      	movl	$0x4, %eax
   14eb8:      	leaq	0x10(%rsp), %rdi
   14ebd:      	movl	$0x8, %esi
   14ec2:      	callq	*%rax
   14ec4:      	cmpq	0x10(%rsp), %r12
   14ec9:      	je	0x14fc1 <generic_rawtp_path+0x9ec1>
   14ecf:      	leaq	0x18(%r12), %rbx
   14ed4:      	movl	$0x4, %eax
   14ed9:      	movq	%rbp, %rdi
   14edc:      	movl	$0x8, %esi
   14ee1:      	movq	%rbx, %rdx
   14ee4:      	callq	*%rax
   14ee6:      	cmpq	%r12, (%rsp)
   14eea:      	je	0x14fc1 <generic_rawtp_path+0x9ec1>
   14ef0:      	movl	$0x4, %eax
   14ef5:      	leaq	0x8(%rsp), %rdi
   14efa:      	movl	$0x8, %esi
   14eff:      	movq	%rbx, %rdx
   14f02:      	callq	*%rax
   14f04:      	addq	$0x20, %r12
   14f08:      	movl	$0x4, %eax
   14f0d:      	leaq	0x58(%rsp), %rdi
   14f12:      	movl	$0x10, %ecx
   14f17:      	movl	$0x10, %esi
   14f1c:      	movq	%r12, %rdx
   14f1f:      	callq	*%rax
   14f21:      	movq	0x28(%rsp), %rbx
   14f26:      	movq	0x48(%rsp), %rax
   14f2b:      	movl	0x5c(%rsp), %r15d
   14f30:      	subq	%rbx, %rax
   14f33:      	movl	0x50(%rsp), %r12d
   14f38:      	movl	%r15d, %edx
   14f3b:      	subl	%r12d, %edx
   14f3e:      	movl	$0x0, %ecx
   14f43:      	cmovbl	%ecx, %edx
   14f46:      	addq	0x60(%rsp), %rdx
   14f4b:      	xorl	%esi, %esi
   14f4d:      	cmpl	%r15d, %r12d
   14f50:      	seta	%sil
   14f54:      	movl	%r15d, %ecx
   14f57:      	cmovbl	%r12d, %ecx
   14f5b:      	addl	%ecx, %esi
   14f5d:      	movl	%r12d, %edi
   14f60:      	subl	%esi, %edi
   14f62:      	movl	%edi, 0x50(%rsp)
   14f66:      	subq	%rsi, %rax
   14f69:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   14f6f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14f75:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   14f7b:      	cmpl	%r15d, %r12d
   14f7e:      	jbe	0x14f84 <generic_rawtp_path+0x9e84>
   14f80:      	movb	$0x2f, (%rbx,%rax)
   14f84:      	xorl	%edi, %edi
   14f86:      	cmpl	%r15d, %r12d
   14f89:      	seta	%dil
   14f8d:      	movzbl	%cl, %esi
   14f90:      	addq	%rax, %rbx
   14f93:      	addq	%rbx, %rdi
   14f96:      	movl	$0x4, %eax
   14f9b:      	callq	*%rax
   14f9d:      	movq	%rbx, 0x48(%rsp)
   14fa2:      	cmpl	%r15d, %r12d
   14fa5:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   14fab:      	movq	0x8(%rsp), %r12
   14fb0:      	movq	%r12, 0x30(%rsp)
   14fb5:      	movq	0x38(%rsp), %rdx
   14fba:      	movq	0x40(%rsp), %r15
   14fbf:      	jmp	0x15012 <generic_rawtp_path+0x9f12>
   14fc1:      	leaq	0x10(%r15), %rdx
   14fc5:      	movl	$0x4, %eax
   14fca:      	movq	%rbp, %rdi
   14fcd:      	movl	$0x8, %esi
   14fd2:      	callq	*%rax
   14fd4:      	movq	0x40(%rsp), %rax
   14fd9:      	cmpq	(%rsp), %rax
   14fdd:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   14fe3:      	addq	$0x18, %r15
   14fe7:      	movl	$0x4, %eax
   14fec:      	leaq	0x30(%rsp), %rdi
   14ff1:      	movl	$0x8, %esi
   14ff6:      	movq	%r15, %rdx
   14ff9:      	callq	*%rax
   14ffb:      	movq	(%rsp), %r15
   14fff:      	movq	%r15, 0x40(%rsp)
   15004:      	leaq	0x20(%r15), %rdx
   15008:      	movq	%rdx, 0x38(%rsp)
   1500d:      	movq	0x30(%rsp), %r12
   15012:      	cmpq	0x18(%rsp), %r12
   15017:      	jne	0x15024 <generic_rawtp_path+0x9f24>
   15019:      	cmpq	0x20(%rsp), %rdx
   1501e:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   15024:      	movl	$0x4, %eax
   15029:      	leaq	0x10(%rsp), %rdi
   1502e:      	movl	$0x8, %esi
   15033:      	callq	*%rax
   15035:      	cmpq	0x10(%rsp), %r12
   1503a:      	je	0x15132 <generic_rawtp_path+0xa032>
   15040:      	leaq	0x18(%r12), %rbx
   15045:      	movl	$0x4, %eax
   1504a:      	movq	%rbp, %rdi
   1504d:      	movl	$0x8, %esi
   15052:      	movq	%rbx, %rdx
   15055:      	callq	*%rax
   15057:      	cmpq	%r12, (%rsp)
   1505b:      	je	0x15132 <generic_rawtp_path+0xa032>
   15061:      	movl	$0x4, %eax
   15066:      	leaq	0x8(%rsp), %rdi
   1506b:      	movl	$0x8, %esi
   15070:      	movq	%rbx, %rdx
   15073:      	callq	*%rax
   15075:      	addq	$0x20, %r12
   15079:      	movl	$0x4, %eax
   1507e:      	leaq	0x58(%rsp), %rdi
   15083:      	movl	$0x10, %ecx
   15088:      	movl	$0x10, %esi
   1508d:      	movq	%r12, %rdx
   15090:      	callq	*%rax
   15092:      	movq	0x28(%rsp), %rbx
   15097:      	movq	0x48(%rsp), %rax
   1509c:      	movl	0x5c(%rsp), %r15d
   150a1:      	subq	%rbx, %rax
   150a4:      	movl	0x50(%rsp), %r12d
   150a9:      	movl	%r15d, %edx
   150ac:      	subl	%r12d, %edx
   150af:      	movl	$0x0, %ecx
   150b4:      	cmovbl	%ecx, %edx
   150b7:      	addq	0x60(%rsp), %rdx
   150bc:      	xorl	%esi, %esi
   150be:      	cmpl	%r15d, %r12d
   150c1:      	seta	%sil
   150c5:      	movl	%r15d, %ecx
   150c8:      	cmovbl	%r12d, %ecx
   150cc:      	addl	%ecx, %esi
   150ce:      	movl	%r12d, %edi
   150d1:      	subl	%esi, %edi
   150d3:      	movl	%edi, 0x50(%rsp)
   150d7:      	subq	%rsi, %rax
   150da:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   150e0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   150e6:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   150ec:      	cmpl	%r15d, %r12d
   150ef:      	jbe	0x150f5 <generic_rawtp_path+0x9ff5>
   150f1:      	movb	$0x2f, (%rbx,%rax)
   150f5:      	xorl	%edi, %edi
   150f7:      	cmpl	%r15d, %r12d
   150fa:      	seta	%dil
   150fe:      	movzbl	%cl, %esi
   15101:      	addq	%rax, %rbx
   15104:      	addq	%rbx, %rdi
   15107:      	movl	$0x4, %eax
   1510c:      	callq	*%rax
   1510e:      	movq	%rbx, 0x48(%rsp)
   15113:      	cmpl	%r15d, %r12d
   15116:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   1511c:      	movq	0x8(%rsp), %r12
   15121:      	movq	%r12, 0x30(%rsp)
   15126:      	movq	0x38(%rsp), %rdx
   1512b:      	movq	0x40(%rsp), %r15
   15130:      	jmp	0x15183 <generic_rawtp_path+0xa083>
   15132:      	leaq	0x10(%r15), %rdx
   15136:      	movl	$0x4, %eax
   1513b:      	movq	%rbp, %rdi
   1513e:      	movl	$0x8, %esi
   15143:      	callq	*%rax
   15145:      	movq	0x40(%rsp), %rax
   1514a:      	cmpq	(%rsp), %rax
   1514e:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   15154:      	addq	$0x18, %r15
   15158:      	movl	$0x4, %eax
   1515d:      	leaq	0x30(%rsp), %rdi
   15162:      	movl	$0x8, %esi
   15167:      	movq	%r15, %rdx
   1516a:      	callq	*%rax
   1516c:      	movq	(%rsp), %r15
   15170:      	movq	%r15, 0x40(%rsp)
   15175:      	leaq	0x20(%r15), %rdx
   15179:      	movq	%rdx, 0x38(%rsp)
   1517e:      	movq	0x30(%rsp), %r12
   15183:      	cmpq	0x18(%rsp), %r12
   15188:      	jne	0x15195 <generic_rawtp_path+0xa095>
   1518a:      	cmpq	0x20(%rsp), %rdx
   1518f:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   15195:      	movl	$0x4, %eax
   1519a:      	leaq	0x10(%rsp), %rdi
   1519f:      	movl	$0x8, %esi
   151a4:      	callq	*%rax
   151a6:      	cmpq	0x10(%rsp), %r12
   151ab:      	je	0x152a3 <generic_rawtp_path+0xa1a3>
   151b1:      	leaq	0x18(%r12), %rbx
   151b6:      	movl	$0x4, %eax
   151bb:      	movq	%rbp, %rdi
   151be:      	movl	$0x8, %esi
   151c3:      	movq	%rbx, %rdx
   151c6:      	callq	*%rax
   151c8:      	cmpq	%r12, (%rsp)
   151cc:      	je	0x152a3 <generic_rawtp_path+0xa1a3>
   151d2:      	movl	$0x4, %eax
   151d7:      	leaq	0x8(%rsp), %rdi
   151dc:      	movl	$0x8, %esi
   151e1:      	movq	%rbx, %rdx
   151e4:      	callq	*%rax
   151e6:      	addq	$0x20, %r12
   151ea:      	movl	$0x4, %eax
   151ef:      	leaq	0x58(%rsp), %rdi
   151f4:      	movl	$0x10, %ecx
   151f9:      	movl	$0x10, %esi
   151fe:      	movq	%r12, %rdx
   15201:      	callq	*%rax
   15203:      	movq	0x28(%rsp), %rbx
   15208:      	movq	0x48(%rsp), %rax
   1520d:      	movl	0x5c(%rsp), %r15d
   15212:      	subq	%rbx, %rax
   15215:      	movl	0x50(%rsp), %r12d
   1521a:      	movl	%r15d, %edx
   1521d:      	subl	%r12d, %edx
   15220:      	movl	$0x0, %ecx
   15225:      	cmovbl	%ecx, %edx
   15228:      	addq	0x60(%rsp), %rdx
   1522d:      	xorl	%esi, %esi
   1522f:      	cmpl	%r15d, %r12d
   15232:      	seta	%sil
   15236:      	movl	%r15d, %ecx
   15239:      	cmovbl	%r12d, %ecx
   1523d:      	addl	%ecx, %esi
   1523f:      	movl	%r12d, %edi
   15242:      	subl	%esi, %edi
   15244:      	movl	%edi, 0x50(%rsp)
   15248:      	subq	%rsi, %rax
   1524b:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   15251:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15257:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   1525d:      	cmpl	%r15d, %r12d
   15260:      	jbe	0x15266 <generic_rawtp_path+0xa166>
   15262:      	movb	$0x2f, (%rbx,%rax)
   15266:      	xorl	%edi, %edi
   15268:      	cmpl	%r15d, %r12d
   1526b:      	seta	%dil
   1526f:      	movzbl	%cl, %esi
   15272:      	addq	%rax, %rbx
   15275:      	addq	%rbx, %rdi
   15278:      	movl	$0x4, %eax
   1527d:      	callq	*%rax
   1527f:      	movq	%rbx, 0x48(%rsp)
   15284:      	cmpl	%r15d, %r12d
   15287:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   1528d:      	movq	0x8(%rsp), %r12
   15292:      	movq	%r12, 0x30(%rsp)
   15297:      	movq	0x38(%rsp), %rdx
   1529c:      	movq	0x40(%rsp), %r15
   152a1:      	jmp	0x152f4 <generic_rawtp_path+0xa1f4>
   152a3:      	leaq	0x10(%r15), %rdx
   152a7:      	movl	$0x4, %eax
   152ac:      	movq	%rbp, %rdi
   152af:      	movl	$0x8, %esi
   152b4:      	callq	*%rax
   152b6:      	movq	0x40(%rsp), %rax
   152bb:      	cmpq	(%rsp), %rax
   152bf:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   152c5:      	addq	$0x18, %r15
   152c9:      	movl	$0x4, %eax
   152ce:      	leaq	0x30(%rsp), %rdi
   152d3:      	movl	$0x8, %esi
   152d8:      	movq	%r15, %rdx
   152db:      	callq	*%rax
   152dd:      	movq	(%rsp), %r15
   152e1:      	movq	%r15, 0x40(%rsp)
   152e6:      	leaq	0x20(%r15), %rdx
   152ea:      	movq	%rdx, 0x38(%rsp)
   152ef:      	movq	0x30(%rsp), %r12
   152f4:      	cmpq	0x18(%rsp), %r12
   152f9:      	jne	0x15306 <generic_rawtp_path+0xa206>
   152fb:      	cmpq	0x20(%rsp), %rdx
   15300:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   15306:      	movl	$0x4, %eax
   1530b:      	leaq	0x10(%rsp), %rdi
   15310:      	movl	$0x8, %esi
   15315:      	callq	*%rax
   15317:      	cmpq	0x10(%rsp), %r12
   1531c:      	je	0x15414 <generic_rawtp_path+0xa314>
   15322:      	leaq	0x18(%r12), %rbx
   15327:      	movl	$0x4, %eax
   1532c:      	movq	%rbp, %rdi
   1532f:      	movl	$0x8, %esi
   15334:      	movq	%rbx, %rdx
   15337:      	callq	*%rax
   15339:      	cmpq	%r12, (%rsp)
   1533d:      	je	0x15414 <generic_rawtp_path+0xa314>
   15343:      	movl	$0x4, %eax
   15348:      	leaq	0x8(%rsp), %rdi
   1534d:      	movl	$0x8, %esi
   15352:      	movq	%rbx, %rdx
   15355:      	callq	*%rax
   15357:      	addq	$0x20, %r12
   1535b:      	movl	$0x4, %eax
   15360:      	leaq	0x58(%rsp), %rdi
   15365:      	movl	$0x10, %ecx
   1536a:      	movl	$0x10, %esi
   1536f:      	movq	%r12, %rdx
   15372:      	callq	*%rax
   15374:      	movq	0x28(%rsp), %rbx
   15379:      	movq	0x48(%rsp), %rax
   1537e:      	movl	0x5c(%rsp), %r15d
   15383:      	subq	%rbx, %rax
   15386:      	movl	0x50(%rsp), %r12d
   1538b:      	movl	%r15d, %edx
   1538e:      	subl	%r12d, %edx
   15391:      	movl	$0x0, %ecx
   15396:      	cmovbl	%ecx, %edx
   15399:      	addq	0x60(%rsp), %rdx
   1539e:      	xorl	%esi, %esi
   153a0:      	cmpl	%r15d, %r12d
   153a3:      	seta	%sil
   153a7:      	movl	%r15d, %ecx
   153aa:      	cmovbl	%r12d, %ecx
   153ae:      	addl	%ecx, %esi
   153b0:      	movl	%r12d, %edi
   153b3:      	subl	%esi, %edi
   153b5:      	movl	%edi, 0x50(%rsp)
   153b9:      	subq	%rsi, %rax
   153bc:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   153c2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   153c8:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   153ce:      	cmpl	%r15d, %r12d
   153d1:      	jbe	0x153d7 <generic_rawtp_path+0xa2d7>
   153d3:      	movb	$0x2f, (%rbx,%rax)
   153d7:      	xorl	%edi, %edi
   153d9:      	cmpl	%r15d, %r12d
   153dc:      	seta	%dil
   153e0:      	movzbl	%cl, %esi
   153e3:      	addq	%rax, %rbx
   153e6:      	addq	%rbx, %rdi
   153e9:      	movl	$0x4, %eax
   153ee:      	callq	*%rax
   153f0:      	movq	%rbx, 0x48(%rsp)
   153f5:      	cmpl	%r15d, %r12d
   153f8:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   153fe:      	movq	0x8(%rsp), %r12
   15403:      	movq	%r12, 0x30(%rsp)
   15408:      	movq	0x38(%rsp), %rdx
   1540d:      	movq	0x40(%rsp), %r15
   15412:      	jmp	0x15465 <generic_rawtp_path+0xa365>
   15414:      	leaq	0x10(%r15), %rdx
   15418:      	movl	$0x4, %eax
   1541d:      	movq	%rbp, %rdi
   15420:      	movl	$0x8, %esi
   15425:      	callq	*%rax
   15427:      	movq	0x40(%rsp), %rax
   1542c:      	cmpq	(%rsp), %rax
   15430:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   15436:      	addq	$0x18, %r15
   1543a:      	movl	$0x4, %eax
   1543f:      	leaq	0x30(%rsp), %rdi
   15444:      	movl	$0x8, %esi
   15449:      	movq	%r15, %rdx
   1544c:      	callq	*%rax
   1544e:      	movq	(%rsp), %r15
   15452:      	movq	%r15, 0x40(%rsp)
   15457:      	leaq	0x20(%r15), %rdx
   1545b:      	movq	%rdx, 0x38(%rsp)
   15460:      	movq	0x30(%rsp), %r12
   15465:      	cmpq	0x18(%rsp), %r12
   1546a:      	jne	0x15477 <generic_rawtp_path+0xa377>
   1546c:      	cmpq	0x20(%rsp), %rdx
   15471:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   15477:      	movl	$0x4, %eax
   1547c:      	leaq	0x10(%rsp), %rdi
   15481:      	movl	$0x8, %esi
   15486:      	callq	*%rax
   15488:      	cmpq	0x10(%rsp), %r12
   1548d:      	je	0x15585 <generic_rawtp_path+0xa485>
   15493:      	leaq	0x18(%r12), %rbx
   15498:      	movl	$0x4, %eax
   1549d:      	movq	%rbp, %rdi
   154a0:      	movl	$0x8, %esi
   154a5:      	movq	%rbx, %rdx
   154a8:      	callq	*%rax
   154aa:      	cmpq	%r12, (%rsp)
   154ae:      	je	0x15585 <generic_rawtp_path+0xa485>
   154b4:      	movl	$0x4, %eax
   154b9:      	leaq	0x8(%rsp), %rdi
   154be:      	movl	$0x8, %esi
   154c3:      	movq	%rbx, %rdx
   154c6:      	callq	*%rax
   154c8:      	addq	$0x20, %r12
   154cc:      	movl	$0x4, %eax
   154d1:      	leaq	0x58(%rsp), %rdi
   154d6:      	movl	$0x10, %ecx
   154db:      	movl	$0x10, %esi
   154e0:      	movq	%r12, %rdx
   154e3:      	callq	*%rax
   154e5:      	movq	0x28(%rsp), %rbx
   154ea:      	movq	0x48(%rsp), %rax
   154ef:      	movl	0x5c(%rsp), %r15d
   154f4:      	subq	%rbx, %rax
   154f7:      	movl	0x50(%rsp), %r12d
   154fc:      	movl	%r15d, %edx
   154ff:      	subl	%r12d, %edx
   15502:      	movl	$0x0, %ecx
   15507:      	cmovbl	%ecx, %edx
   1550a:      	addq	0x60(%rsp), %rdx
   1550f:      	xorl	%esi, %esi
   15511:      	cmpl	%r15d, %r12d
   15514:      	seta	%sil
   15518:      	movl	%r15d, %ecx
   1551b:      	cmovbl	%r12d, %ecx
   1551f:      	addl	%ecx, %esi
   15521:      	movl	%r12d, %edi
   15524:      	subl	%esi, %edi
   15526:      	movl	%edi, 0x50(%rsp)
   1552a:      	subq	%rsi, %rax
   1552d:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   15533:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15539:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   1553f:      	cmpl	%r15d, %r12d
   15542:      	jbe	0x15548 <generic_rawtp_path+0xa448>
   15544:      	movb	$0x2f, (%rbx,%rax)
   15548:      	xorl	%edi, %edi
   1554a:      	cmpl	%r15d, %r12d
   1554d:      	seta	%dil
   15551:      	movzbl	%cl, %esi
   15554:      	addq	%rax, %rbx
   15557:      	addq	%rbx, %rdi
   1555a:      	movl	$0x4, %eax
   1555f:      	callq	*%rax
   15561:      	movq	%rbx, 0x48(%rsp)
   15566:      	cmpl	%r15d, %r12d
   15569:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   1556f:      	movq	0x8(%rsp), %r12
   15574:      	movq	%r12, 0x30(%rsp)
   15579:      	movq	0x38(%rsp), %rdx
   1557e:      	movq	0x40(%rsp), %r15
   15583:      	jmp	0x155d6 <generic_rawtp_path+0xa4d6>
   15585:      	leaq	0x10(%r15), %rdx
   15589:      	movl	$0x4, %eax
   1558e:      	movq	%rbp, %rdi
   15591:      	movl	$0x8, %esi
   15596:      	callq	*%rax
   15598:      	movq	0x40(%rsp), %rax
   1559d:      	cmpq	(%rsp), %rax
   155a1:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   155a7:      	addq	$0x18, %r15
   155ab:      	movl	$0x4, %eax
   155b0:      	leaq	0x30(%rsp), %rdi
   155b5:      	movl	$0x8, %esi
   155ba:      	movq	%r15, %rdx
   155bd:      	callq	*%rax
   155bf:      	movq	(%rsp), %r15
   155c3:      	movq	%r15, 0x40(%rsp)
   155c8:      	leaq	0x20(%r15), %rdx
   155cc:      	movq	%rdx, 0x38(%rsp)
   155d1:      	movq	0x30(%rsp), %r12
   155d6:      	cmpq	0x18(%rsp), %r12
   155db:      	jne	0x155e8 <generic_rawtp_path+0xa4e8>
   155dd:      	cmpq	0x20(%rsp), %rdx
   155e2:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   155e8:      	movl	$0x4, %eax
   155ed:      	leaq	0x10(%rsp), %rdi
   155f2:      	movl	$0x8, %esi
   155f7:      	callq	*%rax
   155f9:      	cmpq	0x10(%rsp), %r12
   155fe:      	je	0x156f6 <generic_rawtp_path+0xa5f6>
   15604:      	leaq	0x18(%r12), %rbx
   15609:      	movl	$0x4, %eax
   1560e:      	movq	%rbp, %rdi
   15611:      	movl	$0x8, %esi
   15616:      	movq	%rbx, %rdx
   15619:      	callq	*%rax
   1561b:      	cmpq	%r12, (%rsp)
   1561f:      	je	0x156f6 <generic_rawtp_path+0xa5f6>
   15625:      	movl	$0x4, %eax
   1562a:      	leaq	0x8(%rsp), %rdi
   1562f:      	movl	$0x8, %esi
   15634:      	movq	%rbx, %rdx
   15637:      	callq	*%rax
   15639:      	addq	$0x20, %r12
   1563d:      	movl	$0x4, %eax
   15642:      	leaq	0x58(%rsp), %rdi
   15647:      	movl	$0x10, %ecx
   1564c:      	movl	$0x10, %esi
   15651:      	movq	%r12, %rdx
   15654:      	callq	*%rax
   15656:      	movq	0x28(%rsp), %rbx
   1565b:      	movq	0x48(%rsp), %rax
   15660:      	movl	0x5c(%rsp), %r15d
   15665:      	subq	%rbx, %rax
   15668:      	movl	0x50(%rsp), %r12d
   1566d:      	movl	%r15d, %edx
   15670:      	subl	%r12d, %edx
   15673:      	movl	$0x0, %ecx
   15678:      	cmovbl	%ecx, %edx
   1567b:      	addq	0x60(%rsp), %rdx
   15680:      	xorl	%esi, %esi
   15682:      	cmpl	%r15d, %r12d
   15685:      	seta	%sil
   15689:      	movl	%r15d, %ecx
   1568c:      	cmovbl	%r12d, %ecx
   15690:      	addl	%ecx, %esi
   15692:      	movl	%r12d, %edi
   15695:      	subl	%esi, %edi
   15697:      	movl	%edi, 0x50(%rsp)
   1569b:      	subq	%rsi, %rax
   1569e:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   156a4:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   156aa:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   156b0:      	cmpl	%r15d, %r12d
   156b3:      	jbe	0x156b9 <generic_rawtp_path+0xa5b9>
   156b5:      	movb	$0x2f, (%rbx,%rax)
   156b9:      	xorl	%edi, %edi
   156bb:      	cmpl	%r15d, %r12d
   156be:      	seta	%dil
   156c2:      	movzbl	%cl, %esi
   156c5:      	addq	%rax, %rbx
   156c8:      	addq	%rbx, %rdi
   156cb:      	movl	$0x4, %eax
   156d0:      	callq	*%rax
   156d2:      	movq	%rbx, 0x48(%rsp)
   156d7:      	cmpl	%r15d, %r12d
   156da:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   156e0:      	movq	0x8(%rsp), %r12
   156e5:      	movq	%r12, 0x30(%rsp)
   156ea:      	movq	0x38(%rsp), %rdx
   156ef:      	movq	0x40(%rsp), %r15
   156f4:      	jmp	0x15747 <generic_rawtp_path+0xa647>
   156f6:      	leaq	0x10(%r15), %rdx
   156fa:      	movl	$0x4, %eax
   156ff:      	movq	%rbp, %rdi
   15702:      	movl	$0x8, %esi
   15707:      	callq	*%rax
   15709:      	movq	0x40(%rsp), %rax
   1570e:      	cmpq	(%rsp), %rax
   15712:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   15718:      	addq	$0x18, %r15
   1571c:      	movl	$0x4, %eax
   15721:      	leaq	0x30(%rsp), %rdi
   15726:      	movl	$0x8, %esi
   1572b:      	movq	%r15, %rdx
   1572e:      	callq	*%rax
   15730:      	movq	(%rsp), %r15
   15734:      	movq	%r15, 0x40(%rsp)
   15739:      	leaq	0x20(%r15), %rdx
   1573d:      	movq	%rdx, 0x38(%rsp)
   15742:      	movq	0x30(%rsp), %r12
   15747:      	cmpq	0x18(%rsp), %r12
   1574c:      	jne	0x15759 <generic_rawtp_path+0xa659>
   1574e:      	cmpq	0x20(%rsp), %rdx
   15753:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   15759:      	movl	$0x4, %eax
   1575e:      	leaq	0x10(%rsp), %rdi
   15763:      	movl	$0x8, %esi
   15768:      	callq	*%rax
   1576a:      	cmpq	0x10(%rsp), %r12
   1576f:      	je	0x15867 <generic_rawtp_path+0xa767>
   15775:      	leaq	0x18(%r12), %rbx
   1577a:      	movl	$0x4, %eax
   1577f:      	movq	%rbp, %rdi
   15782:      	movl	$0x8, %esi
   15787:      	movq	%rbx, %rdx
   1578a:      	callq	*%rax
   1578c:      	cmpq	%r12, (%rsp)
   15790:      	je	0x15867 <generic_rawtp_path+0xa767>
   15796:      	movl	$0x4, %eax
   1579b:      	leaq	0x8(%rsp), %rdi
   157a0:      	movl	$0x8, %esi
   157a5:      	movq	%rbx, %rdx
   157a8:      	callq	*%rax
   157aa:      	addq	$0x20, %r12
   157ae:      	movl	$0x4, %eax
   157b3:      	leaq	0x58(%rsp), %rdi
   157b8:      	movl	$0x10, %ecx
   157bd:      	movl	$0x10, %esi
   157c2:      	movq	%r12, %rdx
   157c5:      	callq	*%rax
   157c7:      	movq	0x28(%rsp), %rbx
   157cc:      	movq	0x48(%rsp), %rax
   157d1:      	movl	0x5c(%rsp), %r15d
   157d6:      	subq	%rbx, %rax
   157d9:      	movl	0x50(%rsp), %r12d
   157de:      	movl	%r15d, %edx
   157e1:      	subl	%r12d, %edx
   157e4:      	movl	$0x0, %ecx
   157e9:      	cmovbl	%ecx, %edx
   157ec:      	addq	0x60(%rsp), %rdx
   157f1:      	xorl	%esi, %esi
   157f3:      	cmpl	%r15d, %r12d
   157f6:      	seta	%sil
   157fa:      	movl	%r15d, %ecx
   157fd:      	cmovbl	%r12d, %ecx
   15801:      	addl	%ecx, %esi
   15803:      	movl	%r12d, %edi
   15806:      	subl	%esi, %edi
   15808:      	movl	%edi, 0x50(%rsp)
   1580c:      	subq	%rsi, %rax
   1580f:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   15815:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1581b:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   15821:      	cmpl	%r15d, %r12d
   15824:      	jbe	0x1582a <generic_rawtp_path+0xa72a>
   15826:      	movb	$0x2f, (%rbx,%rax)
   1582a:      	xorl	%edi, %edi
   1582c:      	cmpl	%r15d, %r12d
   1582f:      	seta	%dil
   15833:      	movzbl	%cl, %esi
   15836:      	addq	%rax, %rbx
   15839:      	addq	%rbx, %rdi
   1583c:      	movl	$0x4, %eax
   15841:      	callq	*%rax
   15843:      	movq	%rbx, 0x48(%rsp)
   15848:      	cmpl	%r15d, %r12d
   1584b:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   15851:      	movq	0x8(%rsp), %r12
   15856:      	movq	%r12, 0x30(%rsp)
   1585b:      	movq	0x38(%rsp), %rdx
   15860:      	movq	0x40(%rsp), %r15
   15865:      	jmp	0x158b8 <generic_rawtp_path+0xa7b8>
   15867:      	leaq	0x10(%r15), %rdx
   1586b:      	movl	$0x4, %eax
   15870:      	movq	%rbp, %rdi
   15873:      	movl	$0x8, %esi
   15878:      	callq	*%rax
   1587a:      	movq	0x40(%rsp), %rax
   1587f:      	cmpq	(%rsp), %rax
   15883:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   15889:      	addq	$0x18, %r15
   1588d:      	movl	$0x4, %eax
   15892:      	leaq	0x30(%rsp), %rdi
   15897:      	movl	$0x8, %esi
   1589c:      	movq	%r15, %rdx
   1589f:      	callq	*%rax
   158a1:      	movq	(%rsp), %r15
   158a5:      	movq	%r15, 0x40(%rsp)
   158aa:      	leaq	0x20(%r15), %rdx
   158ae:      	movq	%rdx, 0x38(%rsp)
   158b3:      	movq	0x30(%rsp), %r12
   158b8:      	cmpq	0x18(%rsp), %r12
   158bd:      	jne	0x158ca <generic_rawtp_path+0xa7ca>
   158bf:      	cmpq	0x20(%rsp), %rdx
   158c4:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   158ca:      	movl	$0x4, %eax
   158cf:      	leaq	0x10(%rsp), %rdi
   158d4:      	movl	$0x8, %esi
   158d9:      	callq	*%rax
   158db:      	cmpq	0x10(%rsp), %r12
   158e0:      	je	0x159d8 <generic_rawtp_path+0xa8d8>
   158e6:      	leaq	0x18(%r12), %rbx
   158eb:      	movl	$0x4, %eax
   158f0:      	movq	%rbp, %rdi
   158f3:      	movl	$0x8, %esi
   158f8:      	movq	%rbx, %rdx
   158fb:      	callq	*%rax
   158fd:      	cmpq	%r12, (%rsp)
   15901:      	je	0x159d8 <generic_rawtp_path+0xa8d8>
   15907:      	movl	$0x4, %eax
   1590c:      	leaq	0x8(%rsp), %rdi
   15911:      	movl	$0x8, %esi
   15916:      	movq	%rbx, %rdx
   15919:      	callq	*%rax
   1591b:      	addq	$0x20, %r12
   1591f:      	movl	$0x4, %eax
   15924:      	leaq	0x58(%rsp), %rdi
   15929:      	movl	$0x10, %ecx
   1592e:      	movl	$0x10, %esi
   15933:      	movq	%r12, %rdx
   15936:      	callq	*%rax
   15938:      	movq	0x28(%rsp), %rbx
   1593d:      	movq	0x48(%rsp), %rax
   15942:      	movl	0x5c(%rsp), %r15d
   15947:      	subq	%rbx, %rax
   1594a:      	movl	0x50(%rsp), %r12d
   1594f:      	movl	%r15d, %edx
   15952:      	subl	%r12d, %edx
   15955:      	movl	$0x0, %ecx
   1595a:      	cmovbl	%ecx, %edx
   1595d:      	addq	0x60(%rsp), %rdx
   15962:      	xorl	%esi, %esi
   15964:      	cmpl	%r15d, %r12d
   15967:      	seta	%sil
   1596b:      	movl	%r15d, %ecx
   1596e:      	cmovbl	%r12d, %ecx
   15972:      	addl	%ecx, %esi
   15974:      	movl	%r12d, %edi
   15977:      	subl	%esi, %edi
   15979:      	movl	%edi, 0x50(%rsp)
   1597d:      	subq	%rsi, %rax
   15980:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   15986:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1598c:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   15992:      	cmpl	%r15d, %r12d
   15995:      	jbe	0x1599b <generic_rawtp_path+0xa89b>
   15997:      	movb	$0x2f, (%rbx,%rax)
   1599b:      	xorl	%edi, %edi
   1599d:      	cmpl	%r15d, %r12d
   159a0:      	seta	%dil
   159a4:      	movzbl	%cl, %esi
   159a7:      	addq	%rax, %rbx
   159aa:      	addq	%rbx, %rdi
   159ad:      	movl	$0x4, %eax
   159b2:      	callq	*%rax
   159b4:      	movq	%rbx, 0x48(%rsp)
   159b9:      	cmpl	%r15d, %r12d
   159bc:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   159c2:      	movq	0x8(%rsp), %r12
   159c7:      	movq	%r12, 0x30(%rsp)
   159cc:      	movq	0x38(%rsp), %rdx
   159d1:      	movq	0x40(%rsp), %r15
   159d6:      	jmp	0x15a29 <generic_rawtp_path+0xa929>
   159d8:      	leaq	0x10(%r15), %rdx
   159dc:      	movl	$0x4, %eax
   159e1:      	movq	%rbp, %rdi
   159e4:      	movl	$0x8, %esi
   159e9:      	callq	*%rax
   159eb:      	movq	0x40(%rsp), %rax
   159f0:      	cmpq	(%rsp), %rax
   159f4:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   159fa:      	addq	$0x18, %r15
   159fe:      	movl	$0x4, %eax
   15a03:      	leaq	0x30(%rsp), %rdi
   15a08:      	movl	$0x8, %esi
   15a0d:      	movq	%r15, %rdx
   15a10:      	callq	*%rax
   15a12:      	movq	(%rsp), %r15
   15a16:      	movq	%r15, 0x40(%rsp)
   15a1b:      	leaq	0x20(%r15), %rdx
   15a1f:      	movq	%rdx, 0x38(%rsp)
   15a24:      	movq	0x30(%rsp), %r12
   15a29:      	cmpq	0x18(%rsp), %r12
   15a2e:      	jne	0x15a3b <generic_rawtp_path+0xa93b>
   15a30:      	cmpq	0x20(%rsp), %rdx
   15a35:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   15a3b:      	movl	$0x4, %eax
   15a40:      	leaq	0x10(%rsp), %rdi
   15a45:      	movl	$0x8, %esi
   15a4a:      	callq	*%rax
   15a4c:      	cmpq	0x10(%rsp), %r12
   15a51:      	je	0x15b49 <generic_rawtp_path+0xaa49>
   15a57:      	leaq	0x18(%r12), %rbx
   15a5c:      	movl	$0x4, %eax
   15a61:      	movq	%rbp, %rdi
   15a64:      	movl	$0x8, %esi
   15a69:      	movq	%rbx, %rdx
   15a6c:      	callq	*%rax
   15a6e:      	cmpq	%r12, (%rsp)
   15a72:      	je	0x15b49 <generic_rawtp_path+0xaa49>
   15a78:      	movl	$0x4, %eax
   15a7d:      	leaq	0x8(%rsp), %rdi
   15a82:      	movl	$0x8, %esi
   15a87:      	movq	%rbx, %rdx
   15a8a:      	callq	*%rax
   15a8c:      	addq	$0x20, %r12
   15a90:      	movl	$0x4, %eax
   15a95:      	leaq	0x58(%rsp), %rdi
   15a9a:      	movl	$0x10, %ecx
   15a9f:      	movl	$0x10, %esi
   15aa4:      	movq	%r12, %rdx
   15aa7:      	callq	*%rax
   15aa9:      	movq	0x28(%rsp), %rbx
   15aae:      	movq	0x48(%rsp), %rax
   15ab3:      	movl	0x5c(%rsp), %r15d
   15ab8:      	subq	%rbx, %rax
   15abb:      	movl	0x50(%rsp), %r12d
   15ac0:      	movl	%r15d, %edx
   15ac3:      	subl	%r12d, %edx
   15ac6:      	movl	$0x0, %ecx
   15acb:      	cmovbl	%ecx, %edx
   15ace:      	addq	0x60(%rsp), %rdx
   15ad3:      	xorl	%esi, %esi
   15ad5:      	cmpl	%r15d, %r12d
   15ad8:      	seta	%sil
   15adc:      	movl	%r15d, %ecx
   15adf:      	cmovbl	%r12d, %ecx
   15ae3:      	addl	%ecx, %esi
   15ae5:      	movl	%r12d, %edi
   15ae8:      	subl	%esi, %edi
   15aea:      	movl	%edi, 0x50(%rsp)
   15aee:      	subq	%rsi, %rax
   15af1:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   15af7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15afd:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   15b03:      	cmpl	%r15d, %r12d
   15b06:      	jbe	0x15b0c <generic_rawtp_path+0xaa0c>
   15b08:      	movb	$0x2f, (%rbx,%rax)
   15b0c:      	xorl	%edi, %edi
   15b0e:      	cmpl	%r15d, %r12d
   15b11:      	seta	%dil
   15b15:      	movzbl	%cl, %esi
   15b18:      	addq	%rax, %rbx
   15b1b:      	addq	%rbx, %rdi
   15b1e:      	movl	$0x4, %eax
   15b23:      	callq	*%rax
   15b25:      	movq	%rbx, 0x48(%rsp)
   15b2a:      	cmpl	%r15d, %r12d
   15b2d:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   15b33:      	movq	0x8(%rsp), %r12
   15b38:      	movq	%r12, 0x30(%rsp)
   15b3d:      	movq	0x38(%rsp), %rdx
   15b42:      	movq	0x40(%rsp), %r15
   15b47:      	jmp	0x15b9a <generic_rawtp_path+0xaa9a>
   15b49:      	leaq	0x10(%r15), %rdx
   15b4d:      	movl	$0x4, %eax
   15b52:      	movq	%rbp, %rdi
   15b55:      	movl	$0x8, %esi
   15b5a:      	callq	*%rax
   15b5c:      	movq	0x40(%rsp), %rax
   15b61:      	cmpq	(%rsp), %rax
   15b65:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   15b6b:      	addq	$0x18, %r15
   15b6f:      	movl	$0x4, %eax
   15b74:      	leaq	0x30(%rsp), %rdi
   15b79:      	movl	$0x8, %esi
   15b7e:      	movq	%r15, %rdx
   15b81:      	callq	*%rax
   15b83:      	movq	(%rsp), %r15
   15b87:      	movq	%r15, 0x40(%rsp)
   15b8c:      	leaq	0x20(%r15), %rdx
   15b90:      	movq	%rdx, 0x38(%rsp)
   15b95:      	movq	0x30(%rsp), %r12
   15b9a:      	cmpq	0x18(%rsp), %r12
   15b9f:      	jne	0x15bac <generic_rawtp_path+0xaaac>
   15ba1:      	cmpq	0x20(%rsp), %rdx
   15ba6:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   15bac:      	movl	$0x4, %eax
   15bb1:      	leaq	0x10(%rsp), %rdi
   15bb6:      	movl	$0x8, %esi
   15bbb:      	callq	*%rax
   15bbd:      	cmpq	0x10(%rsp), %r12
   15bc2:      	je	0x15cba <generic_rawtp_path+0xabba>
   15bc8:      	leaq	0x18(%r12), %rbx
   15bcd:      	movl	$0x4, %eax
   15bd2:      	movq	%rbp, %rdi
   15bd5:      	movl	$0x8, %esi
   15bda:      	movq	%rbx, %rdx
   15bdd:      	callq	*%rax
   15bdf:      	cmpq	%r12, (%rsp)
   15be3:      	je	0x15cba <generic_rawtp_path+0xabba>
   15be9:      	movl	$0x4, %eax
   15bee:      	leaq	0x8(%rsp), %rdi
   15bf3:      	movl	$0x8, %esi
   15bf8:      	movq	%rbx, %rdx
   15bfb:      	callq	*%rax
   15bfd:      	addq	$0x20, %r12
   15c01:      	movl	$0x4, %eax
   15c06:      	leaq	0x58(%rsp), %rdi
   15c0b:      	movl	$0x10, %ecx
   15c10:      	movl	$0x10, %esi
   15c15:      	movq	%r12, %rdx
   15c18:      	callq	*%rax
   15c1a:      	movq	0x28(%rsp), %rbx
   15c1f:      	movq	0x48(%rsp), %rax
   15c24:      	movl	0x5c(%rsp), %r15d
   15c29:      	subq	%rbx, %rax
   15c2c:      	movl	0x50(%rsp), %r12d
   15c31:      	movl	%r15d, %edx
   15c34:      	subl	%r12d, %edx
   15c37:      	movl	$0x0, %ecx
   15c3c:      	cmovbl	%ecx, %edx
   15c3f:      	addq	0x60(%rsp), %rdx
   15c44:      	xorl	%esi, %esi
   15c46:      	cmpl	%r15d, %r12d
   15c49:      	seta	%sil
   15c4d:      	movl	%r15d, %ecx
   15c50:      	cmovbl	%r12d, %ecx
   15c54:      	addl	%ecx, %esi
   15c56:      	movl	%r12d, %edi
   15c59:      	subl	%esi, %edi
   15c5b:      	movl	%edi, 0x50(%rsp)
   15c5f:      	subq	%rsi, %rax
   15c62:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   15c68:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15c6e:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   15c74:      	cmpl	%r15d, %r12d
   15c77:      	jbe	0x15c7d <generic_rawtp_path+0xab7d>
   15c79:      	movb	$0x2f, (%rbx,%rax)
   15c7d:      	xorl	%edi, %edi
   15c7f:      	cmpl	%r15d, %r12d
   15c82:      	seta	%dil
   15c86:      	movzbl	%cl, %esi
   15c89:      	addq	%rax, %rbx
   15c8c:      	addq	%rbx, %rdi
   15c8f:      	movl	$0x4, %eax
   15c94:      	callq	*%rax
   15c96:      	movq	%rbx, 0x48(%rsp)
   15c9b:      	cmpl	%r15d, %r12d
   15c9e:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   15ca4:      	movq	0x8(%rsp), %r12
   15ca9:      	movq	%r12, 0x30(%rsp)
   15cae:      	movq	0x38(%rsp), %rdx
   15cb3:      	movq	0x40(%rsp), %r15
   15cb8:      	jmp	0x15d0b <generic_rawtp_path+0xac0b>
   15cba:      	leaq	0x10(%r15), %rdx
   15cbe:      	movl	$0x4, %eax
   15cc3:      	movq	%rbp, %rdi
   15cc6:      	movl	$0x8, %esi
   15ccb:      	callq	*%rax
   15ccd:      	movq	0x40(%rsp), %rax
   15cd2:      	cmpq	(%rsp), %rax
   15cd6:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   15cdc:      	addq	$0x18, %r15
   15ce0:      	movl	$0x4, %eax
   15ce5:      	leaq	0x30(%rsp), %rdi
   15cea:      	movl	$0x8, %esi
   15cef:      	movq	%r15, %rdx
   15cf2:      	callq	*%rax
   15cf4:      	movq	(%rsp), %r15
   15cf8:      	movq	%r15, 0x40(%rsp)
   15cfd:      	leaq	0x20(%r15), %rdx
   15d01:      	movq	%rdx, 0x38(%rsp)
   15d06:      	movq	0x30(%rsp), %r12
   15d0b:      	cmpq	0x18(%rsp), %r12
   15d10:      	jne	0x15d1d <generic_rawtp_path+0xac1d>
   15d12:      	cmpq	0x20(%rsp), %rdx
   15d17:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   15d1d:      	movl	$0x4, %eax
   15d22:      	leaq	0x10(%rsp), %rdi
   15d27:      	movl	$0x8, %esi
   15d2c:      	callq	*%rax
   15d2e:      	cmpq	0x10(%rsp), %r12
   15d33:      	je	0x15e2b <generic_rawtp_path+0xad2b>
   15d39:      	leaq	0x18(%r12), %rbx
   15d3e:      	movl	$0x4, %eax
   15d43:      	movq	%rbp, %rdi
   15d46:      	movl	$0x8, %esi
   15d4b:      	movq	%rbx, %rdx
   15d4e:      	callq	*%rax
   15d50:      	cmpq	%r12, (%rsp)
   15d54:      	je	0x15e2b <generic_rawtp_path+0xad2b>
   15d5a:      	movl	$0x4, %eax
   15d5f:      	leaq	0x8(%rsp), %rdi
   15d64:      	movl	$0x8, %esi
   15d69:      	movq	%rbx, %rdx
   15d6c:      	callq	*%rax
   15d6e:      	addq	$0x20, %r12
   15d72:      	movl	$0x4, %eax
   15d77:      	leaq	0x58(%rsp), %rdi
   15d7c:      	movl	$0x10, %ecx
   15d81:      	movl	$0x10, %esi
   15d86:      	movq	%r12, %rdx
   15d89:      	callq	*%rax
   15d8b:      	movq	0x28(%rsp), %rbx
   15d90:      	movq	0x48(%rsp), %rax
   15d95:      	movl	0x5c(%rsp), %r15d
   15d9a:      	subq	%rbx, %rax
   15d9d:      	movl	0x50(%rsp), %r12d
   15da2:      	movl	%r15d, %edx
   15da5:      	subl	%r12d, %edx
   15da8:      	movl	$0x0, %ecx
   15dad:      	cmovbl	%ecx, %edx
   15db0:      	addq	0x60(%rsp), %rdx
   15db5:      	xorl	%esi, %esi
   15db7:      	cmpl	%r15d, %r12d
   15dba:      	seta	%sil
   15dbe:      	movl	%r15d, %ecx
   15dc1:      	cmovbl	%r12d, %ecx
   15dc5:      	addl	%ecx, %esi
   15dc7:      	movl	%r12d, %edi
   15dca:      	subl	%esi, %edi
   15dcc:      	movl	%edi, 0x50(%rsp)
   15dd0:      	subq	%rsi, %rax
   15dd3:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   15dd9:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15ddf:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   15de5:      	cmpl	%r15d, %r12d
   15de8:      	jbe	0x15dee <generic_rawtp_path+0xacee>
   15dea:      	movb	$0x2f, (%rbx,%rax)
   15dee:      	xorl	%edi, %edi
   15df0:      	cmpl	%r15d, %r12d
   15df3:      	seta	%dil
   15df7:      	movzbl	%cl, %esi
   15dfa:      	addq	%rax, %rbx
   15dfd:      	addq	%rbx, %rdi
   15e00:      	movl	$0x4, %eax
   15e05:      	callq	*%rax
   15e07:      	movq	%rbx, 0x48(%rsp)
   15e0c:      	cmpl	%r15d, %r12d
   15e0f:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   15e15:      	movq	0x8(%rsp), %r12
   15e1a:      	movq	%r12, 0x30(%rsp)
   15e1f:      	movq	0x38(%rsp), %rdx
   15e24:      	movq	0x40(%rsp), %r15
   15e29:      	jmp	0x15e7c <generic_rawtp_path+0xad7c>
   15e2b:      	leaq	0x10(%r15), %rdx
   15e2f:      	movl	$0x4, %eax
   15e34:      	movq	%rbp, %rdi
   15e37:      	movl	$0x8, %esi
   15e3c:      	callq	*%rax
   15e3e:      	movq	0x40(%rsp), %rax
   15e43:      	cmpq	(%rsp), %rax
   15e47:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   15e4d:      	addq	$0x18, %r15
   15e51:      	movl	$0x4, %eax
   15e56:      	leaq	0x30(%rsp), %rdi
   15e5b:      	movl	$0x8, %esi
   15e60:      	movq	%r15, %rdx
   15e63:      	callq	*%rax
   15e65:      	movq	(%rsp), %r15
   15e69:      	movq	%r15, 0x40(%rsp)
   15e6e:      	leaq	0x20(%r15), %rdx
   15e72:      	movq	%rdx, 0x38(%rsp)
   15e77:      	movq	0x30(%rsp), %r12
   15e7c:      	cmpq	0x18(%rsp), %r12
   15e81:      	jne	0x15e8e <generic_rawtp_path+0xad8e>
   15e83:      	cmpq	0x20(%rsp), %rdx
   15e88:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   15e8e:      	movl	$0x4, %eax
   15e93:      	leaq	0x10(%rsp), %rdi
   15e98:      	movl	$0x8, %esi
   15e9d:      	callq	*%rax
   15e9f:      	cmpq	0x10(%rsp), %r12
   15ea4:      	je	0x15f9c <generic_rawtp_path+0xae9c>
   15eaa:      	leaq	0x18(%r12), %rbx
   15eaf:      	movl	$0x4, %eax
   15eb4:      	movq	%rbp, %rdi
   15eb7:      	movl	$0x8, %esi
   15ebc:      	movq	%rbx, %rdx
   15ebf:      	callq	*%rax
   15ec1:      	cmpq	%r12, (%rsp)
   15ec5:      	je	0x15f9c <generic_rawtp_path+0xae9c>
   15ecb:      	movl	$0x4, %eax
   15ed0:      	leaq	0x8(%rsp), %rdi
   15ed5:      	movl	$0x8, %esi
   15eda:      	movq	%rbx, %rdx
   15edd:      	callq	*%rax
   15edf:      	addq	$0x20, %r12
   15ee3:      	movl	$0x4, %eax
   15ee8:      	leaq	0x58(%rsp), %rdi
   15eed:      	movl	$0x10, %ecx
   15ef2:      	movl	$0x10, %esi
   15ef7:      	movq	%r12, %rdx
   15efa:      	callq	*%rax
   15efc:      	movq	0x28(%rsp), %rbx
   15f01:      	movq	0x48(%rsp), %rax
   15f06:      	movl	0x5c(%rsp), %r15d
   15f0b:      	subq	%rbx, %rax
   15f0e:      	movl	0x50(%rsp), %r12d
   15f13:      	movl	%r15d, %edx
   15f16:      	subl	%r12d, %edx
   15f19:      	movl	$0x0, %ecx
   15f1e:      	cmovbl	%ecx, %edx
   15f21:      	addq	0x60(%rsp), %rdx
   15f26:      	xorl	%esi, %esi
   15f28:      	cmpl	%r15d, %r12d
   15f2b:      	seta	%sil
   15f2f:      	movl	%r15d, %ecx
   15f32:      	cmovbl	%r12d, %ecx
   15f36:      	addl	%ecx, %esi
   15f38:      	movl	%r12d, %edi
   15f3b:      	subl	%esi, %edi
   15f3d:      	movl	%edi, 0x50(%rsp)
   15f41:      	subq	%rsi, %rax
   15f44:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   15f4a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15f50:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   15f56:      	cmpl	%r15d, %r12d
   15f59:      	jbe	0x15f5f <generic_rawtp_path+0xae5f>
   15f5b:      	movb	$0x2f, (%rbx,%rax)
   15f5f:      	xorl	%edi, %edi
   15f61:      	cmpl	%r15d, %r12d
   15f64:      	seta	%dil
   15f68:      	movzbl	%cl, %esi
   15f6b:      	addq	%rax, %rbx
   15f6e:      	addq	%rbx, %rdi
   15f71:      	movl	$0x4, %eax
   15f76:      	callq	*%rax
   15f78:      	movq	%rbx, 0x48(%rsp)
   15f7d:      	cmpl	%r15d, %r12d
   15f80:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   15f86:      	movq	0x8(%rsp), %r12
   15f8b:      	movq	%r12, 0x30(%rsp)
   15f90:      	movq	0x38(%rsp), %rdx
   15f95:      	movq	0x40(%rsp), %r15
   15f9a:      	jmp	0x15fed <generic_rawtp_path+0xaeed>
   15f9c:      	leaq	0x10(%r15), %rdx
   15fa0:      	movl	$0x4, %eax
   15fa5:      	movq	%rbp, %rdi
   15fa8:      	movl	$0x8, %esi
   15fad:      	callq	*%rax
   15faf:      	movq	0x40(%rsp), %rax
   15fb4:      	cmpq	(%rsp), %rax
   15fb8:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   15fbe:      	addq	$0x18, %r15
   15fc2:      	movl	$0x4, %eax
   15fc7:      	leaq	0x30(%rsp), %rdi
   15fcc:      	movl	$0x8, %esi
   15fd1:      	movq	%r15, %rdx
   15fd4:      	callq	*%rax
   15fd6:      	movq	(%rsp), %r15
   15fda:      	movq	%r15, 0x40(%rsp)
   15fdf:      	leaq	0x20(%r15), %rdx
   15fe3:      	movq	%rdx, 0x38(%rsp)
   15fe8:      	movq	0x30(%rsp), %r12
   15fed:      	cmpq	0x18(%rsp), %r12
   15ff2:      	jne	0x15fff <generic_rawtp_path+0xaeff>
   15ff4:      	cmpq	0x20(%rsp), %rdx
   15ff9:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   15fff:      	movl	$0x4, %eax
   16004:      	leaq	0x10(%rsp), %rdi
   16009:      	movl	$0x8, %esi
   1600e:      	callq	*%rax
   16010:      	cmpq	0x10(%rsp), %r12
   16015:      	je	0x1610d <generic_rawtp_path+0xb00d>
   1601b:      	leaq	0x18(%r12), %rbx
   16020:      	movl	$0x4, %eax
   16025:      	movq	%rbp, %rdi
   16028:      	movl	$0x8, %esi
   1602d:      	movq	%rbx, %rdx
   16030:      	callq	*%rax
   16032:      	cmpq	%r12, (%rsp)
   16036:      	je	0x1610d <generic_rawtp_path+0xb00d>
   1603c:      	movl	$0x4, %eax
   16041:      	leaq	0x8(%rsp), %rdi
   16046:      	movl	$0x8, %esi
   1604b:      	movq	%rbx, %rdx
   1604e:      	callq	*%rax
   16050:      	addq	$0x20, %r12
   16054:      	movl	$0x4, %eax
   16059:      	leaq	0x58(%rsp), %rdi
   1605e:      	movl	$0x10, %ecx
   16063:      	movl	$0x10, %esi
   16068:      	movq	%r12, %rdx
   1606b:      	callq	*%rax
   1606d:      	movq	0x28(%rsp), %rbx
   16072:      	movq	0x48(%rsp), %rax
   16077:      	movl	0x5c(%rsp), %r15d
   1607c:      	subq	%rbx, %rax
   1607f:      	movl	0x50(%rsp), %r12d
   16084:      	movl	%r15d, %edx
   16087:      	subl	%r12d, %edx
   1608a:      	movl	$0x0, %ecx
   1608f:      	cmovbl	%ecx, %edx
   16092:      	addq	0x60(%rsp), %rdx
   16097:      	xorl	%esi, %esi
   16099:      	cmpl	%r15d, %r12d
   1609c:      	seta	%sil
   160a0:      	movl	%r15d, %ecx
   160a3:      	cmovbl	%r12d, %ecx
   160a7:      	addl	%ecx, %esi
   160a9:      	movl	%r12d, %edi
   160ac:      	subl	%esi, %edi
   160ae:      	movl	%edi, 0x50(%rsp)
   160b2:      	subq	%rsi, %rax
   160b5:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   160bb:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   160c1:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   160c7:      	cmpl	%r15d, %r12d
   160ca:      	jbe	0x160d0 <generic_rawtp_path+0xafd0>
   160cc:      	movb	$0x2f, (%rbx,%rax)
   160d0:      	xorl	%edi, %edi
   160d2:      	cmpl	%r15d, %r12d
   160d5:      	seta	%dil
   160d9:      	movzbl	%cl, %esi
   160dc:      	addq	%rax, %rbx
   160df:      	addq	%rbx, %rdi
   160e2:      	movl	$0x4, %eax
   160e7:      	callq	*%rax
   160e9:      	movq	%rbx, 0x48(%rsp)
   160ee:      	cmpl	%r15d, %r12d
   160f1:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   160f7:      	movq	0x8(%rsp), %r12
   160fc:      	movq	%r12, 0x30(%rsp)
   16101:      	movq	0x38(%rsp), %rdx
   16106:      	movq	0x40(%rsp), %r15
   1610b:      	jmp	0x1615e <generic_rawtp_path+0xb05e>
   1610d:      	leaq	0x10(%r15), %rdx
   16111:      	movl	$0x4, %eax
   16116:      	movq	%rbp, %rdi
   16119:      	movl	$0x8, %esi
   1611e:      	callq	*%rax
   16120:      	movq	0x40(%rsp), %rax
   16125:      	cmpq	(%rsp), %rax
   16129:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   1612f:      	addq	$0x18, %r15
   16133:      	movl	$0x4, %eax
   16138:      	leaq	0x30(%rsp), %rdi
   1613d:      	movl	$0x8, %esi
   16142:      	movq	%r15, %rdx
   16145:      	callq	*%rax
   16147:      	movq	(%rsp), %r15
   1614b:      	movq	%r15, 0x40(%rsp)
   16150:      	leaq	0x20(%r15), %rdx
   16154:      	movq	%rdx, 0x38(%rsp)
   16159:      	movq	0x30(%rsp), %r12
   1615e:      	cmpq	0x18(%rsp), %r12
   16163:      	jne	0x16170 <generic_rawtp_path+0xb070>
   16165:      	cmpq	0x20(%rsp), %rdx
   1616a:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   16170:      	movl	$0x4, %eax
   16175:      	leaq	0x10(%rsp), %rdi
   1617a:      	movl	$0x8, %esi
   1617f:      	callq	*%rax
   16181:      	cmpq	0x10(%rsp), %r12
   16186:      	je	0x1627e <generic_rawtp_path+0xb17e>
   1618c:      	leaq	0x18(%r12), %rbx
   16191:      	movl	$0x4, %eax
   16196:      	movq	%rbp, %rdi
   16199:      	movl	$0x8, %esi
   1619e:      	movq	%rbx, %rdx
   161a1:      	callq	*%rax
   161a3:      	cmpq	%r12, (%rsp)
   161a7:      	je	0x1627e <generic_rawtp_path+0xb17e>
   161ad:      	movl	$0x4, %eax
   161b2:      	leaq	0x8(%rsp), %rdi
   161b7:      	movl	$0x8, %esi
   161bc:      	movq	%rbx, %rdx
   161bf:      	callq	*%rax
   161c1:      	addq	$0x20, %r12
   161c5:      	movl	$0x4, %eax
   161ca:      	leaq	0x58(%rsp), %rdi
   161cf:      	movl	$0x10, %ecx
   161d4:      	movl	$0x10, %esi
   161d9:      	movq	%r12, %rdx
   161dc:      	callq	*%rax
   161de:      	movq	0x28(%rsp), %rbx
   161e3:      	movq	0x48(%rsp), %rax
   161e8:      	movl	0x5c(%rsp), %r15d
   161ed:      	subq	%rbx, %rax
   161f0:      	movl	0x50(%rsp), %r12d
   161f5:      	movl	%r15d, %edx
   161f8:      	subl	%r12d, %edx
   161fb:      	movl	$0x0, %ecx
   16200:      	cmovbl	%ecx, %edx
   16203:      	addq	0x60(%rsp), %rdx
   16208:      	xorl	%esi, %esi
   1620a:      	cmpl	%r15d, %r12d
   1620d:      	seta	%sil
   16211:      	movl	%r15d, %ecx
   16214:      	cmovbl	%r12d, %ecx
   16218:      	addl	%ecx, %esi
   1621a:      	movl	%r12d, %edi
   1621d:      	subl	%esi, %edi
   1621f:      	movl	%edi, 0x50(%rsp)
   16223:      	subq	%rsi, %rax
   16226:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   1622c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   16232:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   16238:      	cmpl	%r15d, %r12d
   1623b:      	jbe	0x16241 <generic_rawtp_path+0xb141>
   1623d:      	movb	$0x2f, (%rbx,%rax)
   16241:      	xorl	%edi, %edi
   16243:      	cmpl	%r15d, %r12d
   16246:      	seta	%dil
   1624a:      	movzbl	%cl, %esi
   1624d:      	addq	%rax, %rbx
   16250:      	addq	%rbx, %rdi
   16253:      	movl	$0x4, %eax
   16258:      	callq	*%rax
   1625a:      	movq	%rbx, 0x48(%rsp)
   1625f:      	cmpl	%r15d, %r12d
   16262:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   16268:      	movq	0x8(%rsp), %r12
   1626d:      	movq	%r12, 0x30(%rsp)
   16272:      	movq	0x38(%rsp), %rdx
   16277:      	movq	0x40(%rsp), %r15
   1627c:      	jmp	0x162cf <generic_rawtp_path+0xb1cf>
   1627e:      	leaq	0x10(%r15), %rdx
   16282:      	movl	$0x4, %eax
   16287:      	movq	%rbp, %rdi
   1628a:      	movl	$0x8, %esi
   1628f:      	callq	*%rax
   16291:      	movq	0x40(%rsp), %rax
   16296:      	cmpq	(%rsp), %rax
   1629a:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   162a0:      	addq	$0x18, %r15
   162a4:      	movl	$0x4, %eax
   162a9:      	leaq	0x30(%rsp), %rdi
   162ae:      	movl	$0x8, %esi
   162b3:      	movq	%r15, %rdx
   162b6:      	callq	*%rax
   162b8:      	movq	(%rsp), %r15
   162bc:      	movq	%r15, 0x40(%rsp)
   162c1:      	leaq	0x20(%r15), %rdx
   162c5:      	movq	%rdx, 0x38(%rsp)
   162ca:      	movq	0x30(%rsp), %r12
   162cf:      	cmpq	0x18(%rsp), %r12
   162d4:      	jne	0x162e1 <generic_rawtp_path+0xb1e1>
   162d6:      	cmpq	0x20(%rsp), %rdx
   162db:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   162e1:      	movl	$0x4, %eax
   162e6:      	leaq	0x10(%rsp), %rdi
   162eb:      	movl	$0x8, %esi
   162f0:      	callq	*%rax
   162f2:      	cmpq	0x10(%rsp), %r12
   162f7:      	je	0x163ef <generic_rawtp_path+0xb2ef>
   162fd:      	leaq	0x18(%r12), %rbx
   16302:      	movl	$0x4, %eax
   16307:      	movq	%rbp, %rdi
   1630a:      	movl	$0x8, %esi
   1630f:      	movq	%rbx, %rdx
   16312:      	callq	*%rax
   16314:      	cmpq	%r12, (%rsp)
   16318:      	je	0x163ef <generic_rawtp_path+0xb2ef>
   1631e:      	movl	$0x4, %eax
   16323:      	leaq	0x8(%rsp), %rdi
   16328:      	movl	$0x8, %esi
   1632d:      	movq	%rbx, %rdx
   16330:      	callq	*%rax
   16332:      	addq	$0x20, %r12
   16336:      	movl	$0x4, %eax
   1633b:      	leaq	0x58(%rsp), %rdi
   16340:      	movl	$0x10, %ecx
   16345:      	movl	$0x10, %esi
   1634a:      	movq	%r12, %rdx
   1634d:      	callq	*%rax
   1634f:      	movq	0x28(%rsp), %rbx
   16354:      	movq	0x48(%rsp), %rax
   16359:      	movl	0x5c(%rsp), %r15d
   1635e:      	subq	%rbx, %rax
   16361:      	movl	0x50(%rsp), %r12d
   16366:      	movl	%r15d, %edx
   16369:      	subl	%r12d, %edx
   1636c:      	movl	$0x0, %ecx
   16371:      	cmovbl	%ecx, %edx
   16374:      	addq	0x60(%rsp), %rdx
   16379:      	xorl	%esi, %esi
   1637b:      	cmpl	%r15d, %r12d
   1637e:      	seta	%sil
   16382:      	movl	%r15d, %ecx
   16385:      	cmovbl	%r12d, %ecx
   16389:      	addl	%ecx, %esi
   1638b:      	movl	%r12d, %edi
   1638e:      	subl	%esi, %edi
   16390:      	movl	%edi, 0x50(%rsp)
   16394:      	subq	%rsi, %rax
   16397:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   1639d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   163a3:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   163a9:      	cmpl	%r15d, %r12d
   163ac:      	jbe	0x163b2 <generic_rawtp_path+0xb2b2>
   163ae:      	movb	$0x2f, (%rbx,%rax)
   163b2:      	xorl	%edi, %edi
   163b4:      	cmpl	%r15d, %r12d
   163b7:      	seta	%dil
   163bb:      	movzbl	%cl, %esi
   163be:      	addq	%rax, %rbx
   163c1:      	addq	%rbx, %rdi
   163c4:      	movl	$0x4, %eax
   163c9:      	callq	*%rax
   163cb:      	movq	%rbx, 0x48(%rsp)
   163d0:      	cmpl	%r15d, %r12d
   163d3:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   163d9:      	movq	0x8(%rsp), %r12
   163de:      	movq	%r12, 0x30(%rsp)
   163e3:      	movq	0x38(%rsp), %rdx
   163e8:      	movq	0x40(%rsp), %r15
   163ed:      	jmp	0x16440 <generic_rawtp_path+0xb340>
   163ef:      	leaq	0x10(%r15), %rdx
   163f3:      	movl	$0x4, %eax
   163f8:      	movq	%rbp, %rdi
   163fb:      	movl	$0x8, %esi
   16400:      	callq	*%rax
   16402:      	movq	0x40(%rsp), %rax
   16407:      	cmpq	(%rsp), %rax
   1640b:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   16411:      	addq	$0x18, %r15
   16415:      	movl	$0x4, %eax
   1641a:      	leaq	0x30(%rsp), %rdi
   1641f:      	movl	$0x8, %esi
   16424:      	movq	%r15, %rdx
   16427:      	callq	*%rax
   16429:      	movq	(%rsp), %r15
   1642d:      	movq	%r15, 0x40(%rsp)
   16432:      	leaq	0x20(%r15), %rdx
   16436:      	movq	%rdx, 0x38(%rsp)
   1643b:      	movq	0x30(%rsp), %r12
   16440:      	cmpq	0x18(%rsp), %r12
   16445:      	jne	0x16452 <generic_rawtp_path+0xb352>
   16447:      	cmpq	0x20(%rsp), %rdx
   1644c:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   16452:      	movl	$0x4, %eax
   16457:      	leaq	0x10(%rsp), %rdi
   1645c:      	movl	$0x8, %esi
   16461:      	callq	*%rax
   16463:      	cmpq	0x10(%rsp), %r12
   16468:      	je	0x16560 <generic_rawtp_path+0xb460>
   1646e:      	leaq	0x18(%r12), %rbx
   16473:      	movl	$0x4, %eax
   16478:      	movq	%rbp, %rdi
   1647b:      	movl	$0x8, %esi
   16480:      	movq	%rbx, %rdx
   16483:      	callq	*%rax
   16485:      	cmpq	%r12, (%rsp)
   16489:      	je	0x16560 <generic_rawtp_path+0xb460>
   1648f:      	movl	$0x4, %eax
   16494:      	leaq	0x8(%rsp), %rdi
   16499:      	movl	$0x8, %esi
   1649e:      	movq	%rbx, %rdx
   164a1:      	callq	*%rax
   164a3:      	addq	$0x20, %r12
   164a7:      	movl	$0x4, %eax
   164ac:      	leaq	0x58(%rsp), %rdi
   164b1:      	movl	$0x10, %ecx
   164b6:      	movl	$0x10, %esi
   164bb:      	movq	%r12, %rdx
   164be:      	callq	*%rax
   164c0:      	movq	0x28(%rsp), %rbx
   164c5:      	movq	0x48(%rsp), %rax
   164ca:      	movl	0x5c(%rsp), %r15d
   164cf:      	subq	%rbx, %rax
   164d2:      	movl	0x50(%rsp), %r12d
   164d7:      	movl	%r15d, %edx
   164da:      	subl	%r12d, %edx
   164dd:      	movl	$0x0, %ecx
   164e2:      	cmovbl	%ecx, %edx
   164e5:      	addq	0x60(%rsp), %rdx
   164ea:      	xorl	%esi, %esi
   164ec:      	cmpl	%r15d, %r12d
   164ef:      	seta	%sil
   164f3:      	movl	%r15d, %ecx
   164f6:      	cmovbl	%r12d, %ecx
   164fa:      	addl	%ecx, %esi
   164fc:      	movl	%r12d, %edi
   164ff:      	subl	%esi, %edi
   16501:      	movl	%edi, 0x50(%rsp)
   16505:      	subq	%rsi, %rax
   16508:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   1650e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   16514:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   1651a:      	cmpl	%r15d, %r12d
   1651d:      	jbe	0x16523 <generic_rawtp_path+0xb423>
   1651f:      	movb	$0x2f, (%rbx,%rax)
   16523:      	xorl	%edi, %edi
   16525:      	cmpl	%r15d, %r12d
   16528:      	seta	%dil
   1652c:      	movzbl	%cl, %esi
   1652f:      	addq	%rax, %rbx
   16532:      	addq	%rbx, %rdi
   16535:      	movl	$0x4, %eax
   1653a:      	callq	*%rax
   1653c:      	movq	%rbx, 0x48(%rsp)
   16541:      	cmpl	%r15d, %r12d
   16544:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   1654a:      	movq	0x8(%rsp), %r12
   1654f:      	movq	%r12, 0x30(%rsp)
   16554:      	movq	0x38(%rsp), %rdx
   16559:      	movq	0x40(%rsp), %r15
   1655e:      	jmp	0x165b1 <generic_rawtp_path+0xb4b1>
   16560:      	leaq	0x10(%r15), %rdx
   16564:      	movl	$0x4, %eax
   16569:      	movq	%rbp, %rdi
   1656c:      	movl	$0x8, %esi
   16571:      	callq	*%rax
   16573:      	movq	0x40(%rsp), %rax
   16578:      	cmpq	(%rsp), %rax
   1657c:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   16582:      	addq	$0x18, %r15
   16586:      	movl	$0x4, %eax
   1658b:      	leaq	0x30(%rsp), %rdi
   16590:      	movl	$0x8, %esi
   16595:      	movq	%r15, %rdx
   16598:      	callq	*%rax
   1659a:      	movq	(%rsp), %r15
   1659e:      	movq	%r15, 0x40(%rsp)
   165a3:      	leaq	0x20(%r15), %rdx
   165a7:      	movq	%rdx, 0x38(%rsp)
   165ac:      	movq	0x30(%rsp), %r12
   165b1:      	cmpq	0x18(%rsp), %r12
   165b6:      	jne	0x165c3 <generic_rawtp_path+0xb4c3>
   165b8:      	cmpq	0x20(%rsp), %rdx
   165bd:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   165c3:      	movl	$0x4, %eax
   165c8:      	leaq	0x10(%rsp), %rdi
   165cd:      	movl	$0x8, %esi
   165d2:      	callq	*%rax
   165d4:      	cmpq	0x10(%rsp), %r12
   165d9:      	je	0x166d1 <generic_rawtp_path+0xb5d1>
   165df:      	leaq	0x18(%r12), %rbx
   165e4:      	movl	$0x4, %eax
   165e9:      	movq	%rbp, %rdi
   165ec:      	movl	$0x8, %esi
   165f1:      	movq	%rbx, %rdx
   165f4:      	callq	*%rax
   165f6:      	cmpq	%r12, (%rsp)
   165fa:      	je	0x166d1 <generic_rawtp_path+0xb5d1>
   16600:      	movl	$0x4, %eax
   16605:      	leaq	0x8(%rsp), %rdi
   1660a:      	movl	$0x8, %esi
   1660f:      	movq	%rbx, %rdx
   16612:      	callq	*%rax
   16614:      	addq	$0x20, %r12
   16618:      	movl	$0x4, %eax
   1661d:      	leaq	0x58(%rsp), %rdi
   16622:      	movl	$0x10, %ecx
   16627:      	movl	$0x10, %esi
   1662c:      	movq	%r12, %rdx
   1662f:      	callq	*%rax
   16631:      	movq	0x28(%rsp), %rbx
   16636:      	movq	0x48(%rsp), %rax
   1663b:      	movl	0x5c(%rsp), %r15d
   16640:      	subq	%rbx, %rax
   16643:      	movl	0x50(%rsp), %r12d
   16648:      	movl	%r15d, %edx
   1664b:      	subl	%r12d, %edx
   1664e:      	movl	$0x0, %ecx
   16653:      	cmovbl	%ecx, %edx
   16656:      	addq	0x60(%rsp), %rdx
   1665b:      	xorl	%esi, %esi
   1665d:      	cmpl	%r15d, %r12d
   16660:      	seta	%sil
   16664:      	movl	%r15d, %ecx
   16667:      	cmovbl	%r12d, %ecx
   1666b:      	addl	%ecx, %esi
   1666d:      	movl	%r12d, %edi
   16670:      	subl	%esi, %edi
   16672:      	movl	%edi, 0x50(%rsp)
   16676:      	subq	%rsi, %rax
   16679:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   1667f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   16685:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   1668b:      	cmpl	%r15d, %r12d
   1668e:      	jbe	0x16694 <generic_rawtp_path+0xb594>
   16690:      	movb	$0x2f, (%rbx,%rax)
   16694:      	xorl	%edi, %edi
   16696:      	cmpl	%r15d, %r12d
   16699:      	seta	%dil
   1669d:      	movzbl	%cl, %esi
   166a0:      	addq	%rax, %rbx
   166a3:      	addq	%rbx, %rdi
   166a6:      	movl	$0x4, %eax
   166ab:      	callq	*%rax
   166ad:      	movq	%rbx, 0x48(%rsp)
   166b2:      	cmpl	%r15d, %r12d
   166b5:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   166bb:      	movq	0x8(%rsp), %r12
   166c0:      	movq	%r12, 0x30(%rsp)
   166c5:      	movq	0x38(%rsp), %rdx
   166ca:      	movq	0x40(%rsp), %r15
   166cf:      	jmp	0x16722 <generic_rawtp_path+0xb622>
   166d1:      	leaq	0x10(%r15), %rdx
   166d5:      	movl	$0x4, %eax
   166da:      	movq	%rbp, %rdi
   166dd:      	movl	$0x8, %esi
   166e2:      	callq	*%rax
   166e4:      	movq	0x40(%rsp), %rax
   166e9:      	cmpq	(%rsp), %rax
   166ed:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   166f3:      	addq	$0x18, %r15
   166f7:      	movl	$0x4, %eax
   166fc:      	leaq	0x30(%rsp), %rdi
   16701:      	movl	$0x8, %esi
   16706:      	movq	%r15, %rdx
   16709:      	callq	*%rax
   1670b:      	movq	(%rsp), %r15
   1670f:      	movq	%r15, 0x40(%rsp)
   16714:      	leaq	0x20(%r15), %rdx
   16718:      	movq	%rdx, 0x38(%rsp)
   1671d:      	movq	0x30(%rsp), %r12
   16722:      	cmpq	0x18(%rsp), %r12
   16727:      	jne	0x16734 <generic_rawtp_path+0xb634>
   16729:      	cmpq	0x20(%rsp), %rdx
   1672e:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   16734:      	movl	$0x4, %eax
   16739:      	leaq	0x10(%rsp), %rdi
   1673e:      	movl	$0x8, %esi
   16743:      	callq	*%rax
   16745:      	cmpq	0x10(%rsp), %r12
   1674a:      	je	0x16842 <generic_rawtp_path+0xb742>
   16750:      	leaq	0x18(%r12), %rbx
   16755:      	movl	$0x4, %eax
   1675a:      	movq	%rbp, %rdi
   1675d:      	movl	$0x8, %esi
   16762:      	movq	%rbx, %rdx
   16765:      	callq	*%rax
   16767:      	cmpq	%r12, (%rsp)
   1676b:      	je	0x16842 <generic_rawtp_path+0xb742>
   16771:      	movl	$0x4, %eax
   16776:      	leaq	0x8(%rsp), %rdi
   1677b:      	movl	$0x8, %esi
   16780:      	movq	%rbx, %rdx
   16783:      	callq	*%rax
   16785:      	addq	$0x20, %r12
   16789:      	movl	$0x4, %eax
   1678e:      	leaq	0x58(%rsp), %rdi
   16793:      	movl	$0x10, %ecx
   16798:      	movl	$0x10, %esi
   1679d:      	movq	%r12, %rdx
   167a0:      	callq	*%rax
   167a2:      	movq	0x28(%rsp), %rbx
   167a7:      	movq	0x48(%rsp), %rax
   167ac:      	movl	0x5c(%rsp), %r15d
   167b1:      	subq	%rbx, %rax
   167b4:      	movl	0x50(%rsp), %r12d
   167b9:      	movl	%r15d, %edx
   167bc:      	subl	%r12d, %edx
   167bf:      	movl	$0x0, %ecx
   167c4:      	cmovbl	%ecx, %edx
   167c7:      	addq	0x60(%rsp), %rdx
   167cc:      	xorl	%esi, %esi
   167ce:      	cmpl	%r15d, %r12d
   167d1:      	seta	%sil
   167d5:      	movl	%r15d, %ecx
   167d8:      	cmovbl	%r12d, %ecx
   167dc:      	addl	%ecx, %esi
   167de:      	movl	%r12d, %edi
   167e1:      	subl	%esi, %edi
   167e3:      	movl	%edi, 0x50(%rsp)
   167e7:      	subq	%rsi, %rax
   167ea:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   167f0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   167f6:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   167fc:      	cmpl	%r15d, %r12d
   167ff:      	jbe	0x16805 <generic_rawtp_path+0xb705>
   16801:      	movb	$0x2f, (%rbx,%rax)
   16805:      	xorl	%edi, %edi
   16807:      	cmpl	%r15d, %r12d
   1680a:      	seta	%dil
   1680e:      	movzbl	%cl, %esi
   16811:      	addq	%rax, %rbx
   16814:      	addq	%rbx, %rdi
   16817:      	movl	$0x4, %eax
   1681c:      	callq	*%rax
   1681e:      	movq	%rbx, 0x48(%rsp)
   16823:      	cmpl	%r15d, %r12d
   16826:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   1682c:      	movq	0x8(%rsp), %r12
   16831:      	movq	%r12, 0x30(%rsp)
   16836:      	movq	0x38(%rsp), %rdx
   1683b:      	movq	0x40(%rsp), %r15
   16840:      	jmp	0x16893 <generic_rawtp_path+0xb793>
   16842:      	leaq	0x10(%r15), %rdx
   16846:      	movl	$0x4, %eax
   1684b:      	movq	%rbp, %rdi
   1684e:      	movl	$0x8, %esi
   16853:      	callq	*%rax
   16855:      	movq	0x40(%rsp), %rax
   1685a:      	cmpq	(%rsp), %rax
   1685e:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   16864:      	addq	$0x18, %r15
   16868:      	movl	$0x4, %eax
   1686d:      	leaq	0x30(%rsp), %rdi
   16872:      	movl	$0x8, %esi
   16877:      	movq	%r15, %rdx
   1687a:      	callq	*%rax
   1687c:      	movq	(%rsp), %r15
   16880:      	movq	%r15, 0x40(%rsp)
   16885:      	leaq	0x20(%r15), %rdx
   16889:      	movq	%rdx, 0x38(%rsp)
   1688e:      	movq	0x30(%rsp), %r12
   16893:      	cmpq	0x18(%rsp), %r12
   16898:      	jne	0x168a5 <generic_rawtp_path+0xb7a5>
   1689a:      	cmpq	0x20(%rsp), %rdx
   1689f:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   168a5:      	movl	$0x4, %eax
   168aa:      	leaq	0x10(%rsp), %rdi
   168af:      	movl	$0x8, %esi
   168b4:      	callq	*%rax
   168b6:      	cmpq	0x10(%rsp), %r12
   168bb:      	je	0x169b3 <generic_rawtp_path+0xb8b3>
   168c1:      	leaq	0x18(%r12), %rbx
   168c6:      	movl	$0x4, %eax
   168cb:      	movq	%rbp, %rdi
   168ce:      	movl	$0x8, %esi
   168d3:      	movq	%rbx, %rdx
   168d6:      	callq	*%rax
   168d8:      	cmpq	%r12, (%rsp)
   168dc:      	je	0x169b3 <generic_rawtp_path+0xb8b3>
   168e2:      	movl	$0x4, %eax
   168e7:      	leaq	0x8(%rsp), %rdi
   168ec:      	movl	$0x8, %esi
   168f1:      	movq	%rbx, %rdx
   168f4:      	callq	*%rax
   168f6:      	addq	$0x20, %r12
   168fa:      	movl	$0x4, %eax
   168ff:      	leaq	0x58(%rsp), %rdi
   16904:      	movl	$0x10, %ecx
   16909:      	movl	$0x10, %esi
   1690e:      	movq	%r12, %rdx
   16911:      	callq	*%rax
   16913:      	movq	0x28(%rsp), %rbx
   16918:      	movq	0x48(%rsp), %rax
   1691d:      	movl	0x5c(%rsp), %r15d
   16922:      	subq	%rbx, %rax
   16925:      	movl	0x50(%rsp), %r12d
   1692a:      	movl	%r15d, %edx
   1692d:      	subl	%r12d, %edx
   16930:      	movl	$0x0, %ecx
   16935:      	cmovbl	%ecx, %edx
   16938:      	addq	0x60(%rsp), %rdx
   1693d:      	xorl	%esi, %esi
   1693f:      	cmpl	%r15d, %r12d
   16942:      	seta	%sil
   16946:      	movl	%r15d, %ecx
   16949:      	cmovbl	%r12d, %ecx
   1694d:      	addl	%ecx, %esi
   1694f:      	movl	%r12d, %edi
   16952:      	subl	%esi, %edi
   16954:      	movl	%edi, 0x50(%rsp)
   16958:      	subq	%rsi, %rax
   1695b:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   16961:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   16967:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   1696d:      	cmpl	%r15d, %r12d
   16970:      	jbe	0x16976 <generic_rawtp_path+0xb876>
   16972:      	movb	$0x2f, (%rbx,%rax)
   16976:      	xorl	%edi, %edi
   16978:      	cmpl	%r15d, %r12d
   1697b:      	seta	%dil
   1697f:      	movzbl	%cl, %esi
   16982:      	addq	%rax, %rbx
   16985:      	addq	%rbx, %rdi
   16988:      	movl	$0x4, %eax
   1698d:      	callq	*%rax
   1698f:      	movq	%rbx, 0x48(%rsp)
   16994:      	cmpl	%r15d, %r12d
   16997:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   1699d:      	movq	0x8(%rsp), %r12
   169a2:      	movq	%r12, 0x30(%rsp)
   169a7:      	movq	0x38(%rsp), %rdx
   169ac:      	movq	0x40(%rsp), %r15
   169b1:      	jmp	0x16a04 <generic_rawtp_path+0xb904>
   169b3:      	leaq	0x10(%r15), %rdx
   169b7:      	movl	$0x4, %eax
   169bc:      	movq	%rbp, %rdi
   169bf:      	movl	$0x8, %esi
   169c4:      	callq	*%rax
   169c6:      	movq	0x40(%rsp), %rax
   169cb:      	cmpq	(%rsp), %rax
   169cf:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   169d5:      	addq	$0x18, %r15
   169d9:      	movl	$0x4, %eax
   169de:      	leaq	0x30(%rsp), %rdi
   169e3:      	movl	$0x8, %esi
   169e8:      	movq	%r15, %rdx
   169eb:      	callq	*%rax
   169ed:      	movq	(%rsp), %r15
   169f1:      	movq	%r15, 0x40(%rsp)
   169f6:      	leaq	0x20(%r15), %rdx
   169fa:      	movq	%rdx, 0x38(%rsp)
   169ff:      	movq	0x30(%rsp), %r12
   16a04:      	cmpq	0x18(%rsp), %r12
   16a09:      	jne	0x16a16 <generic_rawtp_path+0xb916>
   16a0b:      	cmpq	0x20(%rsp), %rdx
   16a10:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   16a16:      	movl	$0x4, %eax
   16a1b:      	leaq	0x10(%rsp), %rdi
   16a20:      	movl	$0x8, %esi
   16a25:      	callq	*%rax
   16a27:      	cmpq	0x10(%rsp), %r12
   16a2c:      	je	0x16b16 <generic_rawtp_path+0xba16>
   16a32:      	leaq	0x18(%r12), %rbx
   16a37:      	movl	$0x4, %eax
   16a3c:      	movq	%rbp, %rdi
   16a3f:      	movl	$0x8, %esi
   16a44:      	movq	%rbx, %rdx
   16a47:      	callq	*%rax
   16a49:      	cmpq	%r12, (%rsp)
   16a4d:      	je	0x16b16 <generic_rawtp_path+0xba16>
   16a53:      	movl	$0x4, %eax
   16a58:      	leaq	0x8(%rsp), %rdi
   16a5d:      	movl	$0x8, %esi
   16a62:      	movq	%rbx, %rdx
   16a65:      	callq	*%rax
   16a67:      	addq	$0x20, %r12
   16a6b:      	movl	$0x4, %eax
   16a70:      	leaq	0x58(%rsp), %rdi
   16a75:      	movl	$0x10, %ecx
   16a7a:      	movl	$0x10, %esi
   16a7f:      	movq	%r12, %rdx
   16a82:      	callq	*%rax
   16a84:      	movq	0x28(%rsp), %rbx
   16a89:      	movq	0x48(%rsp), %rax
   16a8e:      	movl	0x5c(%rsp), %r15d
   16a93:      	subq	%rbx, %rax
   16a96:      	movl	0x50(%rsp), %r12d
   16a9b:      	movl	%r15d, %edx
   16a9e:      	subl	%r12d, %edx
   16aa1:      	movl	$0x0, %ecx
   16aa6:      	cmovbl	%ecx, %edx
   16aa9:      	addq	0x60(%rsp), %rdx
   16aae:      	xorl	%esi, %esi
   16ab0:      	cmpl	%r15d, %r12d
   16ab3:      	seta	%sil
   16ab7:      	movl	%r15d, %ecx
   16aba:      	cmovbl	%r12d, %ecx
   16abe:      	addl	%ecx, %esi
   16ac0:      	movl	%r12d, %edi
   16ac3:      	subl	%esi, %edi
   16ac5:      	movl	%edi, 0x50(%rsp)
   16ac9:      	subq	%rsi, %rax
   16acc:      	jb	0x16b72 <generic_rawtp_path+0xba72>
   16ad2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   16ad8:      	ja	0x16b72 <generic_rawtp_path+0xba72>
   16ade:      	cmpl	%r15d, %r12d
   16ae1:      	jbe	0x16ae7 <generic_rawtp_path+0xb9e7>
   16ae3:      	movb	$0x2f, (%rbx,%rax)
   16ae7:      	xorl	%edi, %edi
   16ae9:      	cmpl	%r15d, %r12d
   16aec:      	seta	%dil
   16af0:      	movzbl	%cl, %esi
   16af3:      	addq	%rax, %rbx
   16af6:      	addq	%rbx, %rdi
   16af9:      	movl	$0x4, %eax
   16afe:      	callq	*%rax
   16b00:      	movq	%rbx, 0x48(%rsp)
   16b05:      	cmpl	%r15d, %r12d
   16b08:      	jbe	0x16b72 <generic_rawtp_path+0xba72>
   16b0a:      	movq	0x8(%rsp), %rax
   16b0f:      	movq	%rax, 0x30(%rsp)
   16b14:      	jmp	0x16b5e <generic_rawtp_path+0xba5e>
   16b16:      	leaq	0x10(%r15), %rdx
   16b1a:      	movl	$0x4, %eax
   16b1f:      	movq	%rbp, %rdi
   16b22:      	movl	$0x8, %esi
   16b27:      	callq	*%rax
   16b29:      	movq	0x40(%rsp), %rax
   16b2e:      	cmpq	(%rsp), %rax
   16b32:      	je	0x16b6d <generic_rawtp_path+0xba6d>
   16b34:      	addq	$0x18, %r15
   16b38:      	movl	$0x4, %eax
   16b3d:      	leaq	0x30(%rsp), %rdi
   16b42:      	movl	$0x8, %esi
   16b47:      	movq	%r15, %rdx
   16b4a:      	callq	*%rax
   16b4c:      	movq	(%rsp), %rax
   16b50:      	movq	%rax, 0x40(%rsp)
   16b55:      	addq	$0x20, %rax
   16b59:      	movq	%rax, 0x38(%rsp)
   16b5e:      	movl	0x6c(%rsp), %eax
   16b62:      	addl	$-0x80, %eax
   16b65:      	jne	0xb2a3 <generic_rawtp_path+0x1a3>
   16b6b:      	jmp	0x16b72 <generic_rawtp_path+0xba72>
   16b6d:      	movb	$0x1, 0x54(%rsp)
   16b72:      	movl	0x6428(%r14), %eax
   16b79:      	incl	%eax
   16b7b:      	movl	%eax, 0x6428(%r14)
   16b82:      	movl	0x48(%rsp), %ecx
   16b86:      	subl	0x80(%rsp), %ecx
   16b8d:      	movl	%ecx, 0x6424(%r14)
   16b94:      	cmpb	$0x0, 0x54(%rsp)
   16b99:      	jne	0x16be1 <generic_rawtp_path+0xbae1>
   16b9b:      	cmpl	$0x8, %eax
   16b9e:      	je	0x16be1 <generic_rawtp_path+0xbae1>
   16ba0:      	movq	0x30(%rsp), %rax
   16ba5:      	movq	%rax, 0x6458(%r14)
   16bac:      	movq	0x38(%rsp), %rax
   16bb1:      	movq	%rax, 0x6460(%r14)
   16bb8:      	movq	0x40(%rsp), %rax
   16bbd:      	movq	%rax, 0x6468(%r14)
   16bc4:      	movq	(%rip), %rcx            # 0x16bcb <generic_rawtp_path+0xbacb>
   16bcb:      	movl	$0x6, %edx
   16bd0:      	movl	$0xc, %eax
   16bd5:      	movq	0x78(%rsp), %rdi
   16bda:      	movl	$0x6, %edx
   16bdf:      	jmp	0x16bfc <generic_rawtp_path+0xbafc>
   16be1:      	movq	(%rip), %rcx            # 0x16be8 <generic_rawtp_path+0xbae8>
   16be8:      	movl	$0x1, %edx
   16bed:      	movl	$0xc, %eax
   16bf2:      	movq	0x78(%rsp), %rdi
   16bf7:      	movl	$0x1, %edx
   16bfc:      	movq	(%rip), %rsi            # 0x16c03 <generic_rawtp_path+0xbb03>
   16c03:      	jmp	0x16f77 <generic_rawtp_path+0xbe77>
   16c08:      	movl	$0x1, (%rsp)
   16c0f:      	movq	(%rip), %rdi            # 0x16c16 <generic_rawtp_path+0xbb16>
   16c16:      	xorl	%ecx, %ecx
   16c18:      	leaq	0x18(%rsp), %rsi
   16c1d:      	movq	%rsp, %rdx
   16c20:      	movl	$0x2, %eax
   16c25:      	xorl	%ecx, %ecx
   16c27:      	callq	*%rax
   16c29:      	movq	0x58(%rsp), %r12
   16c2e:      	leaq	0x10(%r12), %rdx
   16c33:      	leaq	0x18(%rsp), %rdi
   16c38:      	movl	$0x8, %ecx
   16c3d:      	movl	$0x4, %eax
   16c42:      	leaq	0xfff(%r15), %rbx
   16c49:      	movl	$0x8, %esi
   16c4e:      	callq	*%rax
   16c50:      	cmpq	$0x0, 0x18(%rsp)
   16c56:      	jne	0x16c9f <generic_rawtp_path+0xbb9f>
   16c58:      	leaq	0x18(%r12), %rdx
   16c5d:      	leaq	0x18(%rsp), %rdi
   16c62:      	movl	$0x8, %ecx
   16c67:      	movl	$0x4, %eax
   16c6c:      	movl	$0x8, %esi
   16c71:      	callq	*%rax
   16c73:      	cmpq	%r12, 0x18(%rsp)
   16c78:      	je	0x16c9f <generic_rawtp_path+0xbb9f>
   16c7a:      	movq	%r15, %rbx
   16c7d:      	addq	$0xff5, %rbx            # imm = 0xFF5
   16c84:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
   16c8e:      	movq	%rax, 0xff5(%r15)
   16c95:      	movw	$0x2964, 0xffd(%r15)    # imm = 0x2964
   16c9f:      	movl	$0x23, %eax
   16ca4:      	callq	*%rax
   16ca6:      	leaq	0xd50(%rax), %rdx
   16cad:      	movq	%rsp, %rdi
   16cb0:      	movl	$0x8, %ecx
   16cb5:      	movl	$0x4, %eax
   16cba:      	movl	$0x8, %esi
   16cbf:      	callq	*%rax
   16cc1:      	testq	%rax, %rax
   16cc4:      	je	0x16d23 <generic_rawtp_path+0xbc23>
   16cc6:      	negl	%eax
   16cc8:      	movw	%ax, 0x18(%rsp)
   16ccd:      	movw	$0x6, 0x1a(%rsp)
   16cd4:      	movabsq	$0x400000033, %rax      # imm = 0x400000033
   16cde:      	movq	%rax, 0x1c(%rsp)
   16ce3:      	movq	(%rip), %rdi            # 0x16cea <generic_rawtp_path+0xbbea>
   16cea:      	leaq	0x18(%rsp), %rsi
   16cef:      	movl	$0x1, %eax
   16cf4:      	callq	*%rax
   16cf6:      	testq	%rax, %rax
   16cf9:      	je	0x16cff <generic_rawtp_path+0xbbff>
   16cfb:      	incl	(%rax)
   16cfd:      	jmp	0x16d23 <generic_rawtp_path+0xbc23>
   16cff:      	movl	$0x1, 0x8(%rsp)
   16d07:      	movq	(%rip), %rdi            # 0x16d0e <generic_rawtp_path+0xbc0e>
   16d0e:      	xorl	%ecx, %ecx
   16d10:      	leaq	0x18(%rsp), %rsi
   16d15:      	leaq	0x8(%rsp), %rdx
   16d1a:      	movl	$0x2, %eax
   16d1f:      	xorl	%ecx, %ecx
   16d21:      	callq	*%rax
   16d23:      	movq	(%rsp), %rdx
   16d27:      	leaq	0x18(%rdx), %r13
   16d2b:      	movq	0x6440(%r14), %r12
   16d32:      	leaq	0x6448(%r14), %rdi
   16d39:      	addq	$0x20, %rdx
   16d3d:      	movl	$0x8, %ecx
   16d42:      	movl	$0x4, %eax
   16d47:      	movl	$0x8, %esi
   16d4c:      	callq	*%rax
   16d4e:      	testq	%rax, %rax
   16d51:      	je	0x16db0 <generic_rawtp_path+0xbcb0>
   16d53:      	negl	%eax
   16d55:      	movw	%ax, 0x18(%rsp)
   16d5a:      	movw	$0x6, 0x1a(%rsp)
   16d61:      	movabsq	$0x400000038, %rax      # imm = 0x400000038
   16d6b:      	movq	%rax, 0x1c(%rsp)
   16d70:      	movq	(%rip), %rdi            # 0x16d77 <generic_rawtp_path+0xbc77>
   16d77:      	leaq	0x18(%rsp), %rsi
   16d7c:      	movl	$0x1, %eax
   16d81:      	callq	*%rax
   16d83:      	testq	%rax, %rax
   16d86:      	je	0x16d8c <generic_rawtp_path+0xbc8c>
   16d88:      	incl	(%rax)
   16d8a:      	jmp	0x16db0 <generic_rawtp_path+0xbcb0>
   16d8c:      	movl	$0x1, 0x8(%rsp)
   16d94:      	movq	(%rip), %rdi            # 0x16d9b <generic_rawtp_path+0xbc9b>
   16d9b:      	xorl	%ecx, %ecx
   16d9d:      	leaq	0x18(%rsp), %rsi
   16da2:      	leaq	0x8(%rsp), %rdx
   16da7:      	movl	$0x2, %eax
   16dac:      	xorl	%ecx, %ecx
   16dae:      	callq	*%rax
   16db0:      	leaq	0x6450(%r14), %rdi
   16db7:      	movl	$0x8, %ecx
   16dbc:      	movl	$0x4, %eax
   16dc1:      	movl	$0x8, %esi
   16dc6:      	movq	%r13, %rdx
   16dc9:      	callq	*%rax
   16dcb:      	testq	%rax, %rax
   16dce:      	je	0x16e2d <generic_rawtp_path+0xbd2d>
   16dd0:      	negl	%eax
   16dd2:      	movw	%ax, 0x18(%rsp)
   16dd7:      	movw	$0x6, 0x1a(%rsp)
   16dde:      	movabsq	$0x400000039, %rax      # imm = 0x400000039
   16de8:      	movq	%rax, 0x1c(%rsp)
   16ded:      	movq	(%rip), %rdi            # 0x16df4 <generic_rawtp_path+0xbcf4>
   16df4:      	leaq	0x18(%rsp), %rsi
   16df9:      	movl	$0x1, %eax
   16dfe:      	callq	*%rax
   16e00:      	testq	%rax, %rax
   16e03:      	je	0x16e09 <generic_rawtp_path+0xbd09>
   16e05:      	incl	(%rax)
   16e07:      	jmp	0x16e2d <generic_rawtp_path+0xbd2d>
   16e09:      	movl	$0x1, 0x8(%rsp)
   16e11:      	movq	(%rip), %rdi            # 0x16e18 <generic_rawtp_path+0xbd18>
   16e18:      	xorl	%ecx, %ecx
   16e1a:      	leaq	0x18(%rsp), %rsi
   16e1f:      	leaq	0x8(%rsp), %rdx
   16e24:      	movl	$0x2, %eax
   16e29:      	xorl	%ecx, %ecx
   16e2b:      	callq	*%rax
   16e2d:      	leaq	0x6458(%r14), %rdi
   16e34:      	leaq	0x8(%r12), %rdx
   16e39:      	movl	$0x8, %ecx
   16e3e:      	movl	$0x4, %eax
   16e43:      	movl	$0x8, %esi
   16e48:      	callq	*%rax
   16e4a:      	testq	%rax, %rax
   16e4d:      	je	0x16eac <generic_rawtp_path+0xbdac>
   16e4f:      	negl	%eax
   16e51:      	movw	%ax, 0x18(%rsp)
   16e56:      	movw	$0x6, 0x1a(%rsp)
   16e5d:      	movabsq	$0x40000003a, %rax      # imm = 0x40000003A
   16e67:      	movq	%rax, 0x1c(%rsp)
   16e6c:      	movq	(%rip), %rdi            # 0x16e73 <generic_rawtp_path+0xbd73>
   16e73:      	leaq	0x18(%rsp), %rsi
   16e78:      	movl	$0x1, %eax
   16e7d:      	callq	*%rax
   16e7f:      	testq	%rax, %rax
   16e82:      	je	0x16e88 <generic_rawtp_path+0xbd88>
   16e84:      	incl	(%rax)
   16e86:      	jmp	0x16eac <generic_rawtp_path+0xbdac>
   16e88:      	movl	$0x1, 0x8(%rsp)
   16e90:      	movq	(%rip), %rdi            # 0x16e97 <generic_rawtp_path+0xbd97>
   16e97:      	xorl	%ecx, %ecx
   16e99:      	leaq	0x18(%rsp), %rsi
   16e9e:      	leaq	0x8(%rsp), %rdx
   16ea3:      	movl	$0x2, %eax
   16ea8:      	xorl	%ecx, %ecx
   16eaa:      	callq	*%rax
   16eac:      	movq	%r14, %rdi
   16eaf:      	addq	$0x6460, %rdi           # imm = 0x6460
   16eb6:      	movl	$0x8, %ecx
   16ebb:      	movl	$0x4, %eax
   16ec0:      	movl	$0x8, %esi
   16ec5:      	movq	%r12, %rdx
   16ec8:      	callq	*%rax
   16eca:      	testq	%rax, %rax
   16ecd:      	je	0x16f2c <generic_rawtp_path+0xbe2c>
   16ecf:      	negl	%eax
   16ed1:      	movw	%ax, 0x18(%rsp)
   16ed6:      	movw	$0x6, 0x1a(%rsp)
   16edd:      	movabsq	$0x40000003b, %rax      # imm = 0x40000003B
   16ee7:      	movq	%rax, 0x1c(%rsp)
   16eec:      	movq	(%rip), %rdi            # 0x16ef3 <generic_rawtp_path+0xbdf3>
   16ef3:      	leaq	0x18(%rsp), %rsi
   16ef8:      	movl	$0x1, %eax
   16efd:      	callq	*%rax
   16eff:      	testq	%rax, %rax
   16f02:      	je	0x16f08 <generic_rawtp_path+0xbe08>
   16f04:      	incl	(%rax)
   16f06:      	jmp	0x16f2c <generic_rawtp_path+0xbe2c>
   16f08:      	movl	$0x1, 0x8(%rsp)
   16f10:      	movq	(%rip), %rdi            # 0x16f17 <generic_rawtp_path+0xbe17>
   16f17:      	xorl	%ecx, %ecx
   16f19:      	leaq	0x18(%rsp), %rsi
   16f1e:      	leaq	0x8(%rsp), %rdx
   16f23:      	movl	$0x2, %eax
   16f28:      	xorl	%ecx, %ecx
   16f2a:      	callq	*%rax
   16f2c:      	movq	0x6460(%r14), %rax
   16f33:      	addq	$-0x20, %rax
   16f37:      	movq	%rax, 0x6468(%r14)
   16f3e:      	movl	$0x0, 0x6428(%r14)
   16f49:      	subl	%r15d, %ebx
   16f4c:      	movl	%ebx, 0x6424(%r14)
   16f53:      	movl	$0x1, 0x6420(%r14)
   16f5e:      	movq	(%rip), %rsi            # 0x16f65 <generic_rawtp_path+0xbe65>
   16f65:      	movl	$0x6, %ecx
   16f6a:      	movl	$0xc, %eax
   16f6f:      	movq	%rbp, %rdi
   16f72:      	movl	$0x6, %edx
   16f77:      	callq	*%rax
   16f79:      	xorl	%eax, %eax
   16f7b:      	addq	$0x88, %rsp
   16f82:      	popq	%rbx
   16f83:      	popq	%r12
   16f85:      	popq	%r13
   16f87:      	popq	%r14
   16f89:      	popq	%r15
   16f8b:      	popq	%rbp
   16f8c:      	retq

Disassembly of section raw_tp/generic_tracepoint:

0000000000000000 <generic_rawtp_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x88, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x38(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <generic_rawtp_event+0x23>
      23:      	leaq	0x38(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x62d <generic_rawtp_event+0x62d>
      38:      	movq	%rax, %r14
      3b:      	leaq	0x5ef8(%rax), %rsi
      42:      	movl	$0x0, 0x5ef8(%rax)
      4c:      	movq	(%rip), %rdi            # 0x53 <generic_rawtp_event+0x53>
      53:      	movl	$0x1, %eax
      58:      	callq	*%rax
      5a:      	testq	%rax, %rax
      5d:      	je	0x62d <generic_rawtp_event+0x62d>
      63:      	movl	0x64(%rax), %ecx
      66:      	movl	%ecx, 0x14(%rsp)
      6a:      	testl	%ecx, %ecx
      6c:      	je	0x23b <generic_rawtp_event+0x23b>
      72:      	movq	%rax, %r12
      75:      	movq	(%rip), %rdi            # 0x7c <generic_rawtp_event+0x7c>
      7c:      	leaq	0x14(%rsp), %rsi
      81:      	movl	$0x1, %eax
      86:      	callq	*%rax
      88:      	testq	%rax, %rax
      8b:      	je	0x62d <generic_rawtp_event+0x62d>
      91:      	movq	%rax, %r15
      94:      	movl	$0x0, 0x3c(%rsp)
      9c:      	movq	(%rip), %rdi            # 0xa3 <generic_rawtp_event+0xa3>
      a3:      	leaq	0x3c(%rsp), %rsi
      a8:      	movl	$0x1, %eax
      ad:      	callq	*%rax
      af:      	testq	%rax, %rax
      b2:      	je	0xd8 <generic_rawtp_event+0xd8>
      b4:      	cmpq	$0x63677270, 0x20(%rax) # imm = 0x63677270
      bc:      	jne	0xdc <generic_rawtp_event+0xdc>
      be:      	movl	$0x50, %eax
      c3:      	callq	*%rax
      c5:      	movq	%rax, 0x8(%rsp)
      ca:      	testq	%rax, %rax
      cd:      	jne	0x1f6 <generic_rawtp_event+0x1f6>
      d3:      	jmp	0x62d <generic_rawtp_event+0x62d>
      d8:      	xorl	%ebp, %ebp
      da:      	jmp	0xdf <generic_rawtp_event+0xdf>
      dc:      	movl	0x10(%rax), %ebp
      df:      	movl	$0x23, %eax
      e4:      	callq	*%rax
      e6:      	movq	$0x0, 0x20(%rsp)
      ef:      	leaq	0xf90(%rax), %rdx
      f6:      	leaq	0x28(%rsp), %rdi
      fb:      	movl	$0x8, %ecx
     100:      	movl	$0x71, %eax
     105:      	movl	$0x8, %esi
     10a:      	callq	*%rax
     10c:      	movq	0x28(%rsp), %rax
     111:      	testq	%rax, %rax
     114:      	je	0x62d <generic_rawtp_event+0x62d>
     11a:      	cmpl	$0xb, %ebp
     11d:      	ja	0x62d <generic_rawtp_event+0x62d>
     123:      	movl	%ebp, %edx
     125:      	leaq	(%rax,%rdx,8), %rcx
     129:      	leaq	0x40(%rsp), %rdi
     12e:      	movl	$0x8, %esi
     133:      	movl	$0x71, %eax
     138:      	shlq	$0x3, %rdx
     13c:      	addq	0x28(%rsp), %rdx
     141:      	movl	$0x8, %esi
     146:      	callq	*%rax
     148:      	movq	0x40(%rsp), %rcx
     14d:      	testq	%rcx, %rcx
     150:      	je	0x62d <generic_rawtp_event+0x62d>
     156:      	leaq	0x20(%rsp), %rdi
     15b:      	movl	$0x8, %edx
     160:      	movl	$0x71, %eax
     165:      	movq	0x40(%rsp), %rdx
     16a:      	movl	$0x8, %esi
     16f:      	callq	*%rax
     171:      	movq	0x20(%rsp), %rdx
     176:      	testq	%rdx, %rdx
     179:      	je	0x62d <generic_rawtp_event+0x62d>
     17f:      	movq	$0x0, 0x40(%rsp)
     188:      	addq	$0x100, %rdx            # imm = 0x100
     18f:      	leaq	0x40(%rsp), %rdi
     194:      	movl	$0x8, %ecx
     199:      	movl	$0x71, %eax
     19e:      	movl	$0x8, %esi
     1a3:      	callq	*%rax
     1a5:      	movq	0x40(%rsp), %rdx
     1aa:      	movq	$0x0, 0x40(%rsp)
     1b3:      	testq	%rdx, %rdx
     1b6:      	je	0x1e6 <generic_rawtp_event+0x1e6>
     1b8:      	addq	$0x60, %rdx
     1bc:      	leaq	0x40(%rsp), %rdi
     1c1:      	movl	$0x8, %ecx
     1c6:      	movl	$0x71, %eax
     1cb:      	movl	$0x8, %esi
     1d0:      	callq	*%rax
     1d2:      	movq	0x40(%rsp), %rax
     1d7:      	movq	%rax, 0x8(%rsp)
     1dc:      	testq	%rax, %rax
     1df:      	jne	0x1f6 <generic_rawtp_event+0x1f6>
     1e1:      	jmp	0x62d <generic_rawtp_event+0x62d>
     1e6:      	xorl	%eax, %eax
     1e8:      	movq	%rax, 0x8(%rsp)
     1ed:      	testq	%rax, %rax
     1f0:      	je	0x62d <generic_rawtp_event+0x62d>
     1f6:      	movq	%rax, 0x40(%rsp)
     1fb:      	movq	(%rip), %rdi            # 0x202 <generic_rawtp_event+0x202>
     202:      	leaq	0x40(%rsp), %rsi
     207:      	movl	$0x1, %eax
     20c:      	callq	*%rax
     20e:      	testq	%rax, %rax
     211:      	je	0x220 <generic_rawtp_event+0x220>
     213:      	movq	(%rax), %rax
     216:      	testq	%rax, %rax
     219:      	je	0x220 <generic_rawtp_event+0x220>
     21b:      	movq	%rax, 0x8(%rsp)
     220:      	leaq	0x8(%rsp), %rsi
     225:      	movl	$0x1, %eax
     22a:      	movq	%r15, %rdi
     22d:      	callq	*%rax
     22f:      	testq	%rax, %rax
     232:      	movq	%r12, %rax
     235:      	je	0x641 <generic_rawtp_event+0x641>
     23b:      	movl	(%rax), %eax
     23d:      	movq	%rax, 0x60(%r14)
     241:      	movq	$0x0, 0x68(%r14)
     249:      	movq	$0x0, 0x5efc(%r14)
     254:      	movl	$0x0, 0x6420(%r14)
     25f:      	movq	$0x0, 0x5eb8(%r14)
     26a:      	movq	$0x0, 0x5ec0(%r14)
     275:      	movq	$0x0, 0x5ec8(%r14)
     280:      	movq	$0x0, 0x5ed0(%r14)
     28b:      	movq	$0x0, 0x5ed8(%r14)
     296:      	movb	$0x0, 0x5ee0(%r14)
     29e:      	movl	$0x23, %eax
     2a3:      	callq	*%rax
     2a5:      	movq	%rax, %r15
     2a8:      	leaq	0xd70(%rax), %rdx
     2af:      	leaq	0x20(%rsp), %rdi
     2b4:      	movl	$0x8, %ecx
     2b9:      	movl	$0x4, %eax
     2be:      	leaq	0x20(%r14), %r12
     2c2:      	movl	$0x4, %r13d
     2c8:      	movl	$0x8, %esi
     2cd:      	callq	*%rax
     2cf:      	movq	0x20(%rsp), %rcx
     2d4:      	leaq	0x40(%rsp), %rdi
     2d9:      	movl	$0x48, %edx
     2de:      	movl	$0x4, %eax
     2e3:      	movq	0x20(%rsp), %rdx
     2e8:      	movl	$0x48, %esi
     2ed:      	callq	*%rax
     2ef:      	movl	$0x218, %edx            # imm = 0x218
     2f4:      	movq	0x48(%rsp), %rcx
     2f9:      	addq	%rdx, %rcx
     2fc:      	movl	$0x4, %esi
     301:      	movl	$0x4, %eax
     306:      	addq	0x48(%rsp), %rdx
     30b:      	movq	%r12, %rdi
     30e:      	movl	$0x4, %esi
     313:      	callq	*%rax
     315:      	leaq	0x24(%r14), %rdi
     319:      	movl	$0x4d8, %edx            # imm = 0x4D8
     31e:      	movq	0x50(%rsp), %rcx
     323:      	addq	%rdx, %rcx
     326:      	movl	$0x4, %esi
     32b:      	movl	$0x4, %eax
     330:      	addq	0x50(%rsp), %rdx
     335:      	movl	$0x4, %esi
     33a:      	callq	*%rax
     33c:      	leaq	0x28(%r14), %rdi
     340:      	movq	0x58(%rsp), %rcx
     345:      	addq	$0x58, %rcx
     349:      	movl	$0x4, %edx
     34e:      	movl	$0x4, %eax
     353:      	movq	0x58(%rsp), %rdx
     358:      	addq	$0x58, %rdx
     35c:      	movl	$0x4, %esi
     361:      	callq	*%rax
     363:      	movq	$0x0, 0x8(%rsp)
     36c:      	leaq	0xb58(%r15), %rdx
     373:      	leaq	0x8(%rsp), %rdi
     378:      	movl	$0x8, %ecx
     37d:      	movl	$0x4, %eax
     382:      	movl	$0x8, %esi
     387:      	callq	*%rax
     389:      	movq	0x8(%rsp), %rcx
     38e:      	testq	%rcx, %rcx
     391:      	je	0x427 <generic_rawtp_event+0x427>
     397:      	movl	$0x0, 0x18(%rsp)
     39f:      	addq	$0x4, %rcx
     3a3:      	leaq	0x18(%rsp), %rdi
     3a8:      	movl	$0x4, %eax
     3ad:      	movq	0x8(%rsp), %rdx
     3b2:      	addq	$0x4, %rdx
     3b6:      	movl	$0x4, %esi
     3bb:      	callq	*%rax
     3bd:      	movq	0x8(%rsp), %rax
     3c2:      	movslq	0x18(%rsp), %rcx
     3c7:      	shlq	$0x4, %rcx
     3cb:      	addq	%rax, %rcx
     3ce:      	addq	$0x80, %rcx
     3d5:      	leaq	0x28(%rsp), %rdi
     3da:      	movl	$0x10, %edx
     3df:      	movl	$0x4, %eax
     3e4:      	movq	0x8(%rsp), %rcx
     3e9:      	movslq	0x18(%rsp), %rdx
     3ee:      	shlq	$0x4, %rdx
     3f2:      	addq	%rcx, %rdx
     3f5:      	addq	$0x80, %rdx
     3fc:      	movl	$0x10, %esi
     401:      	callq	*%rax
     403:      	leaq	0x2c(%r14), %rdi
     407:      	movl	$0x158, %edx            # imm = 0x158
     40c:      	movq	0x30(%rsp), %rcx
     411:      	addq	%rdx, %rcx
     414:      	movl	$0x4, %eax
     419:      	addq	0x30(%rsp), %rdx
     41e:      	movl	$0x4, %esi
     423:      	callq	*%rax
     425:      	jmp	0x42f <generic_rawtp_event+0x42f>
     427:      	movl	$0x0, 0x2c(%r14)
     42f:      	leaq	0x30(%r14), %rdi
     433:      	movl	$0x158, %r12d           # imm = 0x158
     439:      	movq	0x60(%rsp), %rcx
     43e:      	addq	%r12, %rcx
     441:      	movl	$0x4, %edx
     446:      	movl	$0x4, %eax
     44b:      	movq	0x60(%rsp), %rdx
     450:      	addq	%r12, %rdx
     453:      	movl	$0x4, %esi
     458:      	callq	*%rax
     45a:      	leaq	0x34(%r14), %rdi
     45e:      	movl	$0x118, %edx            # imm = 0x118
     463:      	movq	0x68(%rsp), %rcx
     468:      	addq	%rdx, %rcx
     46b:      	movl	$0x4, %esi
     470:      	movl	$0x4, %eax
     475:      	addq	0x68(%rsp), %rdx
     47a:      	movl	$0x4, %esi
     47f:      	callq	*%rax
     481:      	leaq	0x38(%r14), %rdi
     485:      	movl	$0x98, %r13d
     48b:      	movq	0x70(%rsp), %rcx
     490:      	addq	%r13, %rcx
     493:      	movl	$0x4, %edx
     498:      	movl	$0x4, %eax
     49d:      	movq	0x70(%rsp), %rdx
     4a2:      	addq	%r13, %rdx
     4a5:      	movl	$0x4, %esi
     4aa:      	callq	*%rax
     4ac:      	leaq	0x3c(%r14), %rdi
     4b0:      	movq	0x78(%rsp), %rcx
     4b5:      	addq	%r13, %rcx
     4b8:      	movl	$0x4, %edx
     4bd:      	movl	$0x4, %eax
     4c2:      	addq	0x78(%rsp), %r13
     4c7:      	movl	$0x4, %esi
     4cc:      	movq	%r13, %rdx
     4cf:      	callq	*%rax
     4d1:      	leaq	0x40(%r14), %rdi
     4d5:      	movq	0x80(%rsp), %rcx
     4dd:      	addq	$0x58, %rcx
     4e1:      	movl	$0x4, %edx
     4e6:      	movl	$0x4, %eax
     4eb:      	movq	0x80(%rsp), %rdx
     4f3:      	addq	$0x58, %rdx
     4f7:      	movl	$0x4, %esi
     4fc:      	callq	*%rax
     4fe:      	movq	$0x0, 0x28(%rsp)
     507:      	movq	$0x0, 0x8(%rsp)
     510:      	addq	$0xd00, %r15            # imm = 0xD00
     517:      	leaq	0x28(%rsp), %rdi
     51c:      	movl	$0x8, %ecx
     521:      	movl	$0x4, %eax
     526:      	movl	$0x8, %esi
     52b:      	movq	%r15, %rdx
     52e:      	callq	*%rax
     530:      	movl	$0x90, %edx
     535:      	movq	0x28(%rsp), %rcx
     53a:      	addq	%rdx, %rcx
     53d:      	leaq	0x8(%rsp), %rdi
     542:      	movl	$0x8, %esi
     547:      	movl	$0x4, %eax
     54c:      	addq	0x28(%rsp), %rdx
     551:      	movl	$0x8, %esi
     556:      	callq	*%rax
     558:      	leaq	0x44(%r14), %rdi
     55c:      	movq	0x8(%rsp), %rcx
     561:      	addq	%r12, %rcx
     564:      	movl	$0x4, %edx
     569:      	movl	$0x4, %eax
     56e:      	addq	0x8(%rsp), %r12
     573:      	movl	$0x4, %esi
     578:      	movq	%r12, %rdx
     57b:      	callq	*%rax
     57d:      	leaq	0x48(%r14), %r12
     581:      	leaq	0x40(%rsp), %rdi
     586:      	movl	$0x8, %ecx
     58b:      	movl	$0x4, %eax
     590:      	movl	$0x8, %esi
     595:      	movq	%r15, %rdx
     598:      	callq	*%rax
     59a:      	movq	0x40(%rsp), %r15
     59f:      	leaq	0x50(%r14), %rdi
     5a3:      	leaq	0x40(%r15), %rdx
     5a7:      	movl	$0x8, %ecx
     5ac:      	movl	$0x4, %eax
     5b1:      	movl	$0x8, %esi
     5b6:      	callq	*%rax
     5b8:      	movq	%r14, %rdi
     5bb:      	addq	$0x58, %rdi
     5bf:      	leaq	0x30(%r15), %rdx
     5c3:      	movl	$0x8, %ecx
     5c8:      	movl	$0x4, %eax
     5cd:      	movl	$0x8, %esi
     5d2:      	callq	*%rax
     5d4:      	addq	$0x38, %r15
     5d8:      	movl	$0x8, %ecx
     5dd:      	movl	$0x4, %eax
     5e2:      	movq	%r12, %rdi
     5e5:      	movl	$0x8, %esi
     5ea:      	movq	%r15, %rdx
     5ed:      	callq	*%rax
     5ef:      	movb	$0x0, 0x5f08(%r14)
     5f7:      	movb	$0x0, 0x1(%r14)
     5fc:      	movq	$0x0, 0x5ee8(%r14)
     607:      	movq	$0x0, 0x5ef0(%r14)
     612:      	movq	(%rip), %rsi            # 0x619 <generic_rawtp_event+0x619>
     619:      	movl	$0x2, %ecx
     61e:      	movl	$0xc, %eax
     623:      	movq	%rbx, %rdi
     626:      	movl	$0x2, %edx
     62b:      	callq	*%rax
     62d:      	xorl	%eax, %eax
     62f:      	addq	$0x88, %rsp
     636:      	popq	%rbx
     637:      	popq	%r12
     639:      	popq	%r13
     63b:      	popq	%r14
     63d:      	popq	%r15
     63f:      	popq	%rbp
     640:      	retq
     641:      	movq	$-0x1, 0x18(%rsp)
     64a:      	leaq	0x18(%rsp), %rsi
     64f:      	movl	$0x1, %eax
     654:      	movq	%r15, %rdi
     657:      	callq	*%rax
     659:      	testq	%rax, %rax
     65c:      	je	0x62d <generic_rawtp_event+0x62d>
     65e:      	movl	$0x1, 0x14(%rsp)
     666:      	movq	(%rip), %rdi            # 0x66d <generic_rawtp_event+0x66d>
     66d:      	leaq	0x14(%rsp), %rsi
     672:      	movl	$0x1, %eax
     677:      	callq	*%rax
     679:      	testq	%rax, %rax
     67c:      	je	0x62d <generic_rawtp_event+0x62d>
     67e:      	movq	%rax, %rdi
     681:      	leaq	0x8(%rsp), %rsi
     686:      	movl	$0x1, %eax
     68b:      	callq	*%rax
     68d:      	testq	%rax, %rax
     690:      	movq	%r12, %rax
     693:      	jne	0x62d <generic_rawtp_event+0x62d>
     695:      	jmp	0x23b <generic_rawtp_event+0x23b>
