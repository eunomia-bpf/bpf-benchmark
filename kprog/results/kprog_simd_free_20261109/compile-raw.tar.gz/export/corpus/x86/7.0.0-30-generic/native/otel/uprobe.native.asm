
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/otel/uprobe.native.o:	file format elf64-x86-64

Disassembly of section uprobe/generic:

0000000000000000 <uprobe__generic>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xf8, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0xe, %eax
      19:      	callq	*%rax
      1b:      	movq	%rax, %r12
      1e:      	xorl	%eax, %eax
      20:      	testl	%r12d, %r12d
      23:      	je	0x94e <uprobe__generic+0x94e>
      29:      	movq	%r12, %r15
      2c:      	shrq	$0x20, %r15
      30:      	testl	%r15d, %r15d
      33:      	je	0x94e <uprobe__generic+0x94e>
      39:      	movl	$0x5, %eax
      3e:      	callq	*%rax
      40:      	movq	%rax, %r13
      43:      	movq	(%rip), %rbp            # 0x4a <uprobe__generic+0x4a>
      4a:      	cmpl	$0x0, (%rbp)
      4e:      	jne	0x749 <uprobe__generic+0x749>
      54:      	movl	$0x0, 0x10(%rsp)
      5c:      	movq	(%rip), %rdi            # 0x63 <uprobe__generic+0x63>
      63:      	leaq	0x10(%rsp), %rsi
      68:      	movl	$0x1, %eax
      6d:      	callq	*%rax
      6f:      	movq	%rax, %r14
      72:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
      77:      	testq	%r14, %r14
      7a:      	je	0x94e <uprobe__generic+0x94e>
      80:      	movq	$0x0, 0xf00(%r14)
      8b:      	movb	$0x0, 0xf30(%r14)
      93:      	movq	$0x0, 0xed0(%r14)
      9e:      	movq	$0x0, 0xed8(%r14)
      a9:      	movq	$0x0, 0xee0(%r14)
      b4:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
      b9:      	movq	%rax, 0xf28(%r14)
      c0:      	movl	$0x0, 0x1380(%r14)
      cb:      	movw	$0x100, 0x1384(%r14)    # imm = 0x100
      d5:      	movq	$0x0, 0xf38(%r14)
      e0:      	movq	$0x0, 0xf40(%r14)
      eb:      	movq	$0x0, 0xf58(%r14)
      f6:      	movq	$0x0, 0xf60(%r14)
     101:      	movq	$0x0, 0xf68(%r14)
     10c:      	movq	$0x0, 0xf70(%r14)
     117:      	movq	$0x0, 0xf78(%r14)
     122:      	movq	%rax, 0x2bc(%r14)
     129:      	leaq	0x20(%r14), %rdi
     12d:      	movl	$0x29c, %edx            # imm = 0x29C
     132:      	xorl	%esi, %esi
     134:      	callq	0x139 <uprobe__generic+0x139>
     139:      	movl	$0x3, 0x2c4(%r14)
     144:      	movl	%r15d, (%r14)
     147:      	movl	%r12d, 0x4(%r14)
     14b:      	movq	%r13, 0x8(%r14)
     14f:      	movq	$0x0, 0x2c8(%r14)
     15a:      	leaq	0x10(%r14), %rdi
     15e:      	movl	$0x10, %eax
     163:      	movl	$0x10, %ecx
     168:      	movl	$0x10, %esi
     16d:      	callq	*%rcx
     16f:      	testl	%eax, %eax
     171:      	jns	0x1a8 <uprobe__generic+0x1a8>
     173:      	movl	$0x34, 0xc0(%rsp)
     17e:      	movq	(%rip), %rdi            # 0x185 <uprobe__generic+0x185>
     185:      	leaq	0xc0(%rsp), %rsi
     18d:      	movl	$0x1, %eax
     192:      	callq	*%rax
     194:      	testq	%rax, %rax
     197:      	je	0x19e <uprobe__generic+0x19e>
     199:      	incq	(%rax)
     19c:      	jmp	0x1a8 <uprobe__generic+0x1a8>
     19e:      	cmpl	$0x0, (%rbp)
     1a2:      	jne	0xb9e <uprobe__generic+0xb9e>
     1a8:      	movq	(%rip), %rsi            # 0x1af <uprobe__generic+0x1af>
     1af:      	movl	$0x400, %eax            # imm = 0x400
     1b4:      	movl	$0x1b, %ecx
     1b9:      	movl	$0x400, %edx            # imm = 0x400
     1be:      	movq	%rbx, %rdi
     1c1:      	callq	*%rcx
     1c3:      	movl	%eax, 0x2bc(%r14)
     1ca:      	cmpl	$0x0, (%rbp)
     1ce:      	jne	0x793 <uprobe__generic+0x793>
     1d4:      	cmpq	$0x2b, 0xa0(%rbx)
     1dc:      	jne	0x7ed <uprobe__generic+0x7ed>
     1e2:      	cmpq	$0x23, 0x88(%rbx)
     1ea:      	jne	0x1f7 <uprobe__generic+0x1f7>
     1ec:      	movl	$0xfb1, %r12d           # imm = 0xFB1
     1f2:      	jmp	0x885 <uprobe__generic+0x885>
     1f7:      	movq	0x80(%rbx), %rax
     1fe:      	movq	%rax, 0xed0(%r14)
     205:      	movq	0x98(%rbx), %rax
     20c:      	movq	%rax, 0xed8(%r14)
     213:      	movq	0x20(%rbx), %rax
     217:      	movq	%rax, 0xee0(%r14)
     21e:      	movq	0x50(%rbx), %rax
     222:      	movq	%rax, 0xee8(%r14)
     229:      	movq	0x40(%rbx), %rax
     22d:      	movq	%rax, 0xef0(%r14)
     234:      	movq	0x30(%rbx), %rax
     238:      	movq	%rax, 0xef8(%r14)
     23f:      	movq	0x10(%rbx), %rax
     243:      	movq	%rax, 0xf00(%r14)
     24a:      	movq	(%rbx), %rax
     24d:      	movq	%rax, 0xf08(%r14)
     254:      	movb	$0x0, 0xf30(%r14)
     25c:      	cmpl	$0x0, (%rbp)
     260:      	jne	0x9ff <uprobe__generic+0x9ff>
     266:      	movl	$0x60, 0x10(%rsp)
     26e:      	movbel	%r15d, 0x14(%rsp)
     275:      	movq	$0x0, 0x18(%rsp)
     27e:      	movq	(%rip), %rdi            # 0x285 <uprobe__generic+0x285>
     285:      	leaq	0x10(%rsp), %rsi
     28a:      	movl	$0x1, %eax
     28f:      	callq	*%rax
     291:      	testq	%rax, %rax
     294:      	je	0x2e3 <uprobe__generic+0x2e3>
     296:      	movq	%r14, %rax
     299:      	addq	$0xed0, %rax            # imm = 0xED0
     29f:      	movq	(%rax), %r12
     2a2:      	movl	(%rbp), %eax
     2a5:      	testq	%r12, %r12
     2a8:      	je	0x3a6 <uprobe__generic+0x3a6>
     2ae:      	testl	%eax, %eax
     2b0:      	jne	0xc1c <uprobe__generic+0xc1c>
     2b6:      	movq	%r12, %rax
     2b9:      	shrq	$0x38, %rax
     2bd:      	je	0xcae <uprobe__generic+0xcae>
     2c3:      	cmpl	$0x0, (%rbp)
     2c7:      	jne	0xfb6 <uprobe__generic+0xfb6>
     2cd:      	movl	$0xb, 0xf28(%r14)
     2d8:      	movl	$0xfab, %r12d           # imm = 0xFAB
     2de:      	jmp	0x885 <uprobe__generic+0x885>
     2e3:      	movq	%r12, 0xb8(%rsp)
     2eb:      	movl	%r15d, 0x4(%rsp)
     2f0:      	movq	(%rip), %rdi            # 0x2f7 <uprobe__generic+0x2f7>
     2f7:      	leaq	0x4(%rsp), %rsi
     2fc:      	movl	$0x1, %eax
     301:      	callq	*%rax
     303:      	movq	%rax, %r14
     306:      	movl	$0x5, %eax
     30b:      	callq	*%rax
     30d:      	testq	%r14, %r14
     310:      	je	0x3c4 <uprobe__generic+0x3c4>
     316:      	movq	(%r14), %rcx
     319:      	movq	%rcx, %rsi
     31c:      	andq	$-0x20, %rsi
     320:      	movq	%rax, %rdx
     323:      	subq	%rsi, %rdx
     326:      	movl	%ecx, %esi
     328:      	andb	$0xf, %sil
     32c:      	movl	$0x5f5e100, %edi        # imm = 0x5F5E100
     331:      	shlxq	%rsi, %rdi, %rsi
     336:      	cmpq	%rsi, %rdx
     339:      	jae	0x3c9 <uprobe__generic+0x3c9>
     33f:      	cmpl	$0x0, (%rbp)
     343:      	je	0x742 <uprobe__generic+0x742>
     349:      	movabsq	$0xa74736166206f, %rax  # imm = 0xA74736166206F
     353:      	movq	%rax, 0x28(%rsp)
     358:      	movabsq	$0x6f74203a64657469, %rax # imm = 0x6F74203A64657469
     362:      	movq	%rax, 0x20(%rsp)
     367:      	movabsq	$0x6d696c20746e6576, %rax # imm = 0x6D696C20746E6576
     371:      	movq	%rax, 0x18(%rsp)
     376:      	movabsq	$0x6520642520444950, %rax # imm = 0x6520642520444950
     380:      	movq	%rax, 0x10(%rsp)
     385:      	leaq	0x10(%rsp), %rdi
     38a:      	movl	$0x20, %eax
     38f:      	movl	$0x6, %ecx
     394:      	movl	0x4(%rsp), %edx
     398:      	movl	$0x20, %esi
     39d:      	xorl	%eax, %eax
     39f:      	callq	*%rcx
     3a1:      	jmp	0x742 <uprobe__generic+0x742>
     3a6:      	testl	%eax, %eax
     3a8:      	jne	0xf3a <uprobe__generic+0xf3a>
     3ae:      	movl	$0x1, 0xf28(%r14)
     3b9:      	movl	$0xfad, %r12d           # imm = 0xFAD
     3bf:      	jmp	0x885 <uprobe__generic+0x885>
     3c4:      	xorl	%r12d, %r12d
     3c7:      	jmp	0x3fd <uprobe__generic+0x3fd>
     3c9:      	movl	%ecx, %r12d
     3cc:      	andb	$0x10, %r12b
     3d0:      	movl	$0xffffffff, %edi       # imm = 0xFFFFFFFF
     3d5:      	addq	%rdi, %rsi
     3d8:      	addq	$0x2a05f201, %rsi       # imm = 0x2A05F201
     3df:      	cmpq	%rsi, %rdx
     3e2:      	jae	0x3fd <uprobe__generic+0x3fd>
     3e4:      	andl	$0xf, %ecx
     3e7:      	xorl	%edx, %edx
     3e9:      	testb	%r12b, %r12b
     3ec:      	sete	%dl
     3ef:      	leal	0x4(,%rdx,4), %edx
     3f6:      	cmpl	%edx, %ecx
     3f8:      	adcb	$0x0, %cl
     3fb:      	jmp	0x3ff <uprobe__generic+0x3ff>
     3fd:      	xorl	%ecx, %ecx
     3ff:      	cmpl	$0x0, (%rbp)
     403:      	movzbl	%cl, %r14d
     407:      	jne	0xed2 <uprobe__generic+0xed2>
     40d:      	andq	$-0x20, %rax
     411:      	movzbl	%r12b, %ecx
     415:      	orq	%rax, %rcx
     418:      	orq	%rcx, %r14
     41b:      	movq	%r14, 0xc0(%rsp)
     423:      	movq	(%rip), %rdi            # 0x42a <uprobe__generic+0x42a>
     42a:      	xorl	%eax, %eax
     42c:      	leaq	0x4(%rsp), %rsi
     431:      	leaq	0xc0(%rsp), %rdx
     439:      	movl	$0x2, %r8d
     43f:      	xorl	%ecx, %ecx
     441:      	callq	*%r8
     444:      	testl	%eax, %eax
     446:      	je	0x47c <uprobe__generic+0x47c>
     448:      	cmpl	$0x0, (%rbp)
     44c:      	jne	0x1019 <uprobe__generic+0x1019>
     452:      	movl	$0x3d, 0xc(%rsp)
     45a:      	movq	(%rip), %rdi            # 0x461 <uprobe__generic+0x461>
     461:      	leaq	0xc(%rsp), %rsi
     466:      	movl	$0x1, %eax
     46b:      	callq	*%rax
     46d:      	testq	%rax, %rax
     470:      	je	0x4e6 <uprobe__generic+0x4e6>
     472:      	incq	(%rax)
     475:      	xorl	%eax, %eax
     477:      	jmp	0x94e <uprobe__generic+0x94e>
     47c:      	movb	$0x1, 0xb(%rsp)
     481:      	movq	(%rip), %rdi            # 0x488 <uprobe__generic+0x488>
     488:      	xorl	%eax, %eax
     48a:      	leaq	0xb8(%rsp), %rsi
     492:      	leaq	0xb(%rsp), %rdx
     497:      	movl	$0x2, %r8d
     49d:      	xorl	%ecx, %ecx
     49f:      	callq	*%r8
     4a2:      	testl	%eax, %eax
     4a4:      	je	0x56b <uprobe__generic+0x56b>
     4aa:      	cmpl	$0x0, (%rbp)
     4ae:      	jne	0x11e5 <uprobe__generic+0x11e5>
     4b4:      	movl	$0x3e, 0xc0(%rsp)
     4bf:      	movq	(%rip), %rdi            # 0x4c6 <uprobe__generic+0x4c6>
     4c6:      	leaq	0xc0(%rsp), %rsi
     4ce:      	movl	$0x1, %eax
     4d3:      	callq	*%rax
     4d5:      	testq	%rax, %rax
     4d8:      	je	0x5d6 <uprobe__generic+0x5d6>
     4de:      	incq	(%rax)
     4e1:      	jmp	0x742 <uprobe__generic+0x742>
     4e6:      	cmpl	$0x0, (%rbp)
     4ea:      	je	0x742 <uprobe__generic+0x742>
     4f0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     4fa:      	movq	%rax, 0x36(%rsp)
     4ff:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     509:      	movq	%rax, 0x30(%rsp)
     50e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     518:      	movq	%rax, 0x28(%rsp)
     51d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     527:      	movq	%rax, 0x20(%rsp)
     52c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     536:      	movq	%rax, 0x18(%rsp)
     53b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     545:      	movq	%rax, 0x10(%rsp)
     54a:      	leaq	0x10(%rsp), %rdi
     54f:      	movl	$0x2e, %eax
     554:      	movl	$0x6, %ecx
     559:      	movl	0xc(%rsp), %edx
     55d:      	movl	$0x2e, %esi
     562:      	xorl	%eax, %eax
     564:      	callq	*%rcx
     566:      	jmp	0x742 <uprobe__generic+0x742>
     56b:      	movl	$0x1, 0xc(%rsp)
     573:      	movb	$0x1, 0x4(%rsp)
     578:      	movq	(%rip), %rdi            # 0x57f <uprobe__generic+0x57f>
     57f:      	leaq	0xc(%rsp), %rsi
     584:      	leaq	0x4(%rsp), %rdx
     589:      	movl	$0x1, %eax
     58e:      	movl	$0x2, %r8d
     594:      	movl	$0x1, %ecx
     599:      	callq	*%r8
     59c:      	testl	%eax, %eax
     59e:      	js	0x660 <uprobe__generic+0x660>
     5a4:      	movl	$0x42, 0xc0(%rsp)
     5af:      	movq	(%rip), %rdi            # 0x5b6 <uprobe__generic+0x5b6>
     5b6:      	leaq	0xc0(%rsp), %rsi
     5be:      	movl	$0x1, %eax
     5c3:      	callq	*%rax
     5c5:      	testq	%rax, %rax
     5c8:      	je	0x6bb <uprobe__generic+0x6bb>
     5ce:      	incq	(%rax)
     5d1:      	jmp	0x6c5 <uprobe__generic+0x6c5>
     5d6:      	cmpl	$0x0, (%rbp)
     5da:      	je	0x742 <uprobe__generic+0x742>
     5e0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     5ea:      	movq	%rax, 0x36(%rsp)
     5ef:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     5f9:      	movq	%rax, 0x30(%rsp)
     5fe:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     608:      	movq	%rax, 0x28(%rsp)
     60d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     617:      	movq	%rax, 0x20(%rsp)
     61c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     626:      	movq	%rax, 0x18(%rsp)
     62b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     635:      	movq	%rax, 0x10(%rsp)
     63a:      	leaq	0x10(%rsp), %rdi
     63f:      	movl	$0x2e, %eax
     644:      	movl	$0x6, %ecx
     649:      	movl	0xc0(%rsp), %edx
     650:      	movl	$0x2e, %esi
     655:      	xorl	%eax, %eax
     657:      	callq	*%rcx
     659:      	xorl	%eax, %eax
     65b:      	jmp	0x94e <uprobe__generic+0x94e>
     660:      	cmpl	$0x0, (%rbp)
     664:      	je	0x70e <uprobe__generic+0x70e>
     66a:      	movabsq	$0xa64657469626968, %rax # imm = 0xA64657469626968
     674:      	movq	%rax, 0x20(%rsp)
     679:      	movabsq	$0x6e69206425206570, %rax # imm = 0x6E69206425206570
     683:      	movq	%rax, 0x18(%rsp)
     688:      	movabsq	$0x797420746e657645, %rax # imm = 0x797420746E657645
     692:      	movq	%rax, 0x10(%rsp)
     697:      	movb	$0x0, 0x28(%rsp)
     69c:      	leaq	0x10(%rsp), %rdi
     6a1:      	movl	$0x19, %eax
     6a6:      	movl	$0x6, %ecx
     6ab:      	movl	$0x19, %esi
     6b0:      	movl	$0x1, %edx
     6b5:      	xorl	%eax, %eax
     6b7:      	callq	*%rcx
     6b9:      	jmp	0x70e <uprobe__generic+0x70e>
     6bb:      	cmpl	$0x0, (%rbp)
     6bf:      	jne	0x1415 <uprobe__generic+0x1415>
     6c5:      	movl	$0x1, 0xc0(%rsp)
     6d0:      	movq	(%rip), %rsi            # 0x6d7 <uprobe__generic+0x6d7>
     6d7:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     6dc:      	leaq	0xc0(%rsp), %rcx
     6e4:      	movl	$0x4, %edx
     6e9:      	movl	$0x19, %r9d
     6ef:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     6f4:      	movq	%rbx, %rdi
     6f7:      	movl	$0x4, %r8d
     6fd:      	callq	*%r9
     700:      	testl	%eax, %eax
     702:      	jns	0x70e <uprobe__generic+0x70e>
     704:      	cmpl	$0x0, (%rbp)
     708:      	jne	0x1386 <uprobe__generic+0x1386>
     70e:      	movl	$0x3f, 0xc0(%rsp)
     719:      	movq	(%rip), %rdi            # 0x720 <uprobe__generic+0x720>
     720:      	leaq	0xc0(%rsp), %rsi
     728:      	movl	$0x1, %eax
     72d:      	callq	*%rax
     72f:      	testq	%rax, %rax
     732:      	jne	0x472 <uprobe__generic+0x472>
     738:      	cmpl	$0x0, (%rbp)
     73c:      	jne	0x1308 <uprobe__generic+0x1308>
     742:      	xorl	%eax, %eax
     744:      	jmp	0x94e <uprobe__generic+0x94e>
     749:      	movabsq	$0xa64726f636572, %rax  # imm = 0xA64726F636572
     753:      	movq	%rax, 0x1e(%rsp)
     758:      	movabsq	$0x6572205550432067, %rax # imm = 0x6572205550432067
     762:      	movq	%rax, 0x18(%rsp)
     767:      	movabsq	$0x6e69747465736552, %rax # imm = 0x6E69747465736552
     771:      	movq	%rax, 0x10(%rsp)
     776:      	leaq	0x10(%rsp), %rdi
     77b:      	movl	$0x16, %eax
     780:      	movl	$0x6, %ecx
     785:      	movl	$0x16, %esi
     78a:      	xorl	%eax, %eax
     78c:      	callq	*%rcx
     78e:      	jmp	0x54 <uprobe__generic+0x54>
     793:      	movabsq	$0xa6425203d2064, %rax  # imm = 0xA6425203D2064
     79d:      	movq	%rax, 0x1e(%rsp)
     7a2:      	movabsq	$0x206469206b636174, %rax # imm = 0x206469206B636174
     7ac:      	movq	%rax, 0x18(%rsp)
     7b1:      	movabsq	$0x73206c656e72656b, %rax # imm = 0x73206C656E72656B
     7bb:      	movq	%rax, 0x10(%rsp)
     7c0:      	leaq	0x10(%rsp), %rdi
     7c5:      	movl	$0x16, %eax
     7ca:      	movl	$0x6, %ecx
     7cf:      	movl	0x2bc(%r14), %edx
     7d6:      	movl	$0x16, %esi
     7db:      	xorl	%eax, %eax
     7dd:      	callq	*%rcx
     7df:      	cmpq	$0x2b, 0xa0(%rbx)
     7e7:      	je	0x1e2 <uprobe__generic+0x1e2>
     7ed:      	movl	$0x23, %eax
     7f2:      	callq	*%rax
     7f4:      	movq	(%rip), %rcx            # 0x7fb <uprobe__generic+0x7fb>
     7fb:      	movl	(%rcx), %edx
     7fd:      	addq	%rax, %rdx
     800:      	leaq	0x10(%rsp), %rdi
     805:      	movl	$0x8, %eax
     80a:      	movl	$0x71, %ecx
     80f:      	movl	$0x8, %esi
     814:      	callq	*%rcx
     816:      	testq	%rax, %rax
     819:      	jne	0x84a <uprobe__generic+0x84a>
     81b:      	movq	(%rip), %rax            # 0x822 <uprobe__generic+0x822>
     822:      	movl	(%rax), %edx
     824:      	addq	0x10(%rsp), %rdx
     829:      	je	0x84a <uprobe__generic+0x84a>
     82b:      	leaq	0x10(%rsp), %rdi
     830:      	movl	$0xa8, %eax
     835:      	movl	$0x71, %ecx
     83a:      	movl	$0xa8, %esi
     83f:      	callq	*%rcx
     841:      	testq	%rax, %rax
     844:      	je	0x960 <uprobe__generic+0x960>
     84a:      	movl	$0x52, 0xb8(%rsp)
     855:      	movq	(%rip), %rdi            # 0x85c <uprobe__generic+0x85c>
     85c:      	leaq	0xb8(%rsp), %rsi
     864:      	movl	$0x1, %eax
     869:      	callq	*%rax
     86b:      	testq	%rax, %rax
     86e:      	je	0x875 <uprobe__generic+0x875>
     870:      	incq	(%rax)
     873:      	jmp	0x87f <uprobe__generic+0x87f>
     875:      	cmpl	$0x0, (%rbp)
     879:      	jne	0xb0b <uprobe__generic+0xb0b>
     87f:      	movl	$0xfa9, %r12d           # imm = 0xFA9
     885:      	xorl	%r15d, %r15d
     888:      	movl	%r12d, 0xf2c(%r14)
     88f:      	movl	$0x0, 0x10(%rsp)
     897:      	movq	(%rip), %rdi            # 0x89e <uprobe__generic+0x89e>
     89e:      	leaq	0x10(%rsp), %rsi
     8a3:      	movl	$0x1, %eax
     8a8:      	callq	*%rax
     8aa:      	testq	%rax, %rax
     8ad:      	je	0x8f6 <uprobe__generic+0x8f6>
     8af:      	movzbl	0x1384(%rax), %ecx
     8b6:      	movl	%r15d, %edx
     8b9:      	cmpb	$0x1d, %cl
     8bc:      	jb	0x91d <uprobe__generic+0x91d>
     8be:      	movq	%rax, %r14
     8c1:      	movl	$0x5, 0xf2c(%rax)
     8cb:      	movl	$0x44, 0xc0(%rsp)
     8d6:      	movq	(%rip), %rdi            # 0x8dd <uprobe__generic+0x8dd>
     8dd:      	leaq	0xc0(%rsp), %rsi
     8e5:      	movl	$0x1, %eax
     8ea:      	callq	*%rax
     8ec:      	testq	%rax, %rax
     8ef:      	je	0x906 <uprobe__generic+0x906>
     8f1:      	incq	(%rax)
     8f4:      	jmp	0x910 <uprobe__generic+0x910>
     8f6:      	movq	(%rip), %rcx            # 0x8fd <uprobe__generic+0x8fd>
     8fd:      	xorl	%edx, %edx
     8ff:      	movl	$0xc, %eax
     904:      	jmp	0x933 <uprobe__generic+0x933>
     906:      	cmpl	$0x0, (%rbp)
     90a:      	jne	0xe54 <uprobe__generic+0xe54>
     910:      	movq	%r14, %rax
     913:      	movzbl	0x1384(%r14), %ecx
     91b:      	xorl	%edx, %edx
     91d:      	incb	%cl
     91f:      	movb	%cl, 0x1384(%rax)
     925:      	movl	%edx, %ecx
     927:      	movq	(%rip), %rsi            # 0x92e <uprobe__generic+0x92e>
     92e:      	movl	$0xc, %eax
     933:      	movq	(%rip), %rsi            # 0x93a <uprobe__generic+0x93a>
     93a:      	movq	%rbx, %rdi
     93d:      	callq	*%rax
     93f:      	cmpl	$0x0, (%rbp)
     943:      	jne	0xa89 <uprobe__generic+0xa89>
     949:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
     94e:      	addq	$0xf8, %rsp
     955:      	popq	%rbx
     956:      	popq	%r12
     958:      	popq	%r13
     95a:      	popq	%r14
     95c:      	popq	%r15
     95e:      	popq	%rbp
     95f:      	retq
     960:      	cmpq	$0x2b, 0xb0(%rsp)
     969:      	jne	0xa7e <uprobe__generic+0xa7e>
     96f:      	cmpq	$0x23, 0x98(%rsp)
     978:      	je	0x1ec <uprobe__generic+0x1ec>
     97e:      	movq	0x90(%rsp), %rax
     986:      	movq	%rax, 0xed0(%r14)
     98d:      	movq	0xa8(%rsp), %rax
     995:      	movq	%rax, 0xed8(%r14)
     99c:      	movq	0x30(%rsp), %rax
     9a1:      	movq	%rax, 0xee0(%r14)
     9a8:      	movq	0x60(%rsp), %rax
     9ad:      	movq	%rax, 0xee8(%r14)
     9b4:      	movq	0x50(%rsp), %rax
     9b9:      	movq	%rax, 0xef0(%r14)
     9c0:      	movq	0x40(%rsp), %rax
     9c5:      	movq	%rax, 0xef8(%r14)
     9cc:      	movq	0x20(%rsp), %rax
     9d1:      	movq	%rax, 0xf00(%r14)
     9d8:      	movq	0x10(%rsp), %rax
     9dd:      	movq	%rax, 0xf08(%r14)
     9e4:      	cmpq	$-0x1, 0x88(%rsp)
     9ed:      	setne	0xf30(%r14)
     9f5:      	cmpl	$0x0, (%rbp)
     9f9:      	je	0x266 <uprobe__generic+0x266>
     9ff:      	movabsq	$0xa786c6c25203a, %rax  # imm = 0xA786C6C25203A
     a09:      	movq	%rax, 0x2f(%rsp)
     a0e:      	movabsq	$0x3a706620786c6c25, %rax # imm = 0x3A706620786C6C25
     a18:      	movq	%rax, 0x28(%rsp)
     a1d:      	movabsq	$0x203a707320786c6c, %rax # imm = 0x203A707320786C6C
     a27:      	movq	%rax, 0x20(%rsp)
     a2c:      	movabsq	$0x25203a6370203a73, %rax # imm = 0x25203A6370203A73
     a36:      	movq	%rax, 0x18(%rsp)
     a3b:      	movabsq	$0x6765722064616552, %rax # imm = 0x6765722064616552
     a45:      	movq	%rax, 0x10(%rsp)
     a4a:      	leaq	0x10(%rsp), %rdi
     a4f:      	movl	$0x27, %eax
     a54:      	movl	$0x6, %r9d
     a5a:      	movq	0xed0(%r14), %rdx
     a61:      	movq	0xed8(%r14), %rcx
     a68:      	movq	0xee0(%r14), %r8
     a6f:      	movl	$0x27, %esi
     a74:      	xorl	%eax, %eax
     a76:      	callq	*%r9
     a79:      	jmp	0x266 <uprobe__generic+0x266>
     a7e:      	xorl	%r15d, %r15d
     a81:      	xorl	%r12d, %r12d
     a84:      	jmp	0x888 <uprobe__generic+0x888>
     a89:      	movabsq	$0x746e655f72656361, %rax # imm = 0x746E655F72656361
     a93:      	movq	%rax, 0x38(%rsp)
     a98:      	movabsq	$0x72745f6576697461, %rax # imm = 0x72745F6576697461
     aa2:      	movq	%rax, 0x30(%rsp)
     aa7:      	movabsq	$0x6e206e6920642520, %rax # imm = 0x6E206E6920642520
     ab1:      	movq	%rax, 0x28(%rsp)
     ab6:      	movabsq	$0x726f662064656c69, %rax # imm = 0x726F662064656C69
     ac0:      	movq	%rax, 0x20(%rsp)
     ac5:      	movabsq	$0x6166206c6c616320, %rax # imm = 0x6166206C6C616320
     acf:      	movq	%rax, 0x18(%rsp)
     ad4:      	movabsq	$0x6c6961745f667062, %rax # imm = 0x6C6961745F667062
     ade:      	movq	%rax, 0x10(%rsp)
     ae3:      	movl	$0xa7972, 0x40(%rsp)    # imm = 0xA7972
     aeb:      	leaq	0x10(%rsp), %rdi
     af0:      	movl	$0x34, %eax
     af5:      	movl	$0x6, %ecx
     afa:      	movl	$0x34, %esi
     aff:      	movl	%r15d, %edx
     b02:      	xorl	%eax, %eax
     b04:      	callq	*%rcx
     b06:      	jmp	0x949 <uprobe__generic+0x949>
     b0b:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     b15:      	movq	%rax, 0xe6(%rsp)
     b1d:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     b27:      	movq	%rax, 0xe0(%rsp)
     b2f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     b39:      	movq	%rax, 0xd8(%rsp)
     b41:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     b4b:      	movq	%rax, 0xd0(%rsp)
     b53:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     b5d:      	movq	%rax, 0xc8(%rsp)
     b65:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     b6f:      	movq	%rax, 0xc0(%rsp)
     b77:      	leaq	0xc0(%rsp), %rdi
     b7f:      	movl	$0x2e, %eax
     b84:      	movl	$0x6, %ecx
     b89:      	movl	0xb8(%rsp), %edx
     b90:      	movl	$0x2e, %esi
     b95:      	xorl	%eax, %eax
     b97:      	callq	*%rcx
     b99:      	jmp	0x87f <uprobe__generic+0x87f>
     b9e:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     ba8:      	movq	%rax, 0x36(%rsp)
     bad:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     bb7:      	movq	%rax, 0x30(%rsp)
     bbc:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     bc6:      	movq	%rax, 0x28(%rsp)
     bcb:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     bd5:      	movq	%rax, 0x20(%rsp)
     bda:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     be4:      	movq	%rax, 0x18(%rsp)
     be9:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     bf3:      	movq	%rax, 0x10(%rsp)
     bf8:      	leaq	0x10(%rsp), %rdi
     bfd:      	movl	$0x2e, %eax
     c02:      	movl	$0x6, %ecx
     c07:      	movl	0xc0(%rsp), %edx
     c0e:      	movl	$0x2e, %esi
     c13:      	xorl	%eax, %eax
     c15:      	callq	*%rcx
     c17:      	jmp	0x1a8 <uprobe__generic+0x1a8>
     c1c:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
     c26:      	movq	%rax, 0x38(%rsp)
     c2b:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
     c35:      	movq	%rax, 0x30(%rsp)
     c3a:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
     c44:      	movq	%rax, 0x28(%rsp)
     c49:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
     c53:      	movq	%rax, 0x20(%rsp)
     c58:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
     c62:      	movq	%rax, 0x18(%rsp)
     c67:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
     c71:      	movq	%rax, 0x10(%rsp)
     c76:      	movb	$0x0, 0x40(%rsp)
     c7b:      	leaq	0x10(%rsp), %rdi
     c80:      	movl	$0x31, %eax
     c85:      	movl	$0x6, %ecx
     c8a:      	movl	0x2c0(%r14), %edx
     c91:      	movl	$0x31, %esi
     c96:      	xorl	%eax, %eax
     c98:      	callq	*%rcx
     c9a:      	movq	0xed0(%r14), %r12
     ca1:      	movq	%r12, %rax
     ca4:      	shrq	$0x38, %rax
     ca8:      	jne	0x2c3 <uprobe__generic+0x2c3>
     cae:      	cmpq	$0xfff, %r12            # imm = 0xFFF
     cb5:      	ja	0xcd7 <uprobe__generic+0xcd7>
     cb7:      	cmpl	$0x0, (%rbp)
     cbb:      	jne	0x107a <uprobe__generic+0x107a>
     cc1:      	movl	$0x31, 0xf28(%r14)
     ccc:      	movl	$0xfae, %r12d           # imm = 0xFAE
     cd2:      	jmp	0x885 <uprobe__generic+0x885>
     cd7:      	movl	(%r14), %eax
     cda:      	movl	$0x60, 0xc0(%rsp)
     ce5:      	movbel	%eax, 0xc4(%rsp)
     cee:      	movbeq	%r12, 0xc8(%rsp)
     cf8:      	movq	(%rip), %rdi            # 0xcff <uprobe__generic+0xcff>
     cff:      	leaq	0xc0(%rsp), %rsi
     d07:      	movl	$0x1, %eax
     d0c:      	callq	*%rax
     d0e:      	testq	%rax, %rax
     d11:      	je	0xe34 <uprobe__generic+0xe34>
     d17:      	movabsq	$0xffffffffffffff, %rcx # imm = 0xFFFFFFFFFFFFFF
     d21:      	movq	0x8(%rax), %r15
     d25:      	andq	%r15, %rcx
     d28:      	movq	%rcx, 0xf20(%r14)
     d2f:      	movq	(%rax), %rax
     d32:      	movq	%rax, 0xf10(%r14)
     d39:      	shrq	$0x38, %r15
     d3d:      	movq	%r12, %rax
     d40:      	subq	%rcx, %rax
     d43:      	movq	%rax, 0xf18(%r14)
     d4a:      	cmpl	$0x0, (%rbp)
     d4e:      	jne	0x10d6 <uprobe__generic+0x10d6>
     d54:      	xorl	%r12d, %r12d
     d57:      	cmpl	$0x1, %r15d
     d5b:      	jne	0x888 <uprobe__generic+0x888>
     d61:      	movq	0xf10(%r14), %rax
     d68:      	movq	%rax, 0xc0(%rsp)
     d70:      	movq	0xf18(%r14), %r13
     d77:      	movq	(%rip), %rdi            # 0xd7e <uprobe__generic+0xd7e>
     d7e:      	leaq	0xc0(%rsp), %rsi
     d86:      	movl	$0x1, %eax
     d8b:      	callq	*%rax
     d8d:      	movl	$0x1, %r15d
     d93:      	testq	%rax, %rax
     d96:      	je	0x888 <uprobe__generic+0x888>
     d9c:      	cmpq	%r13, (%rax)
     d9f:      	ja	0xda7 <uprobe__generic+0xda7>
     da1:      	cmpq	%r13, 0x8(%rax)
     da5:      	jae	0xdbb <uprobe__generic+0xdbb>
     da7:      	cmpq	%r13, 0x10(%rax)
     dab:      	ja	0x888 <uprobe__generic+0x888>
     db1:      	cmpq	%r13, 0x18(%rax)
     db5:      	jb	0x888 <uprobe__generic+0x888>
     dbb:      	cmpl	$0x0, (%rbp)
     dbf:      	jne	0x1493 <uprobe__generic+0x1493>
     dc5:      	movl	0x1380(%r14), %ecx
     dcc:      	movl	0x20(%rax), %edx
     dcf:      	btl	%edx, %ecx
     dd2:      	jae	0x1506 <uprobe__generic+0x1506>
     dd8:      	cmpl	$0x0, (%rbp)
     ddc:      	je	0x888 <uprobe__generic+0x888>
     de2:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
     dec:      	movq	%rax, 0x20(%rsp)
     df1:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
     dfb:      	movq	%rax, 0x18(%rsp)
     e00:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
     e0a:      	movq	%rax, 0x10(%rsp)
     e0f:      	movl	$0xa656e, 0x27(%rsp)    # imm = 0xA656E
     e17:      	leaq	0x10(%rsp), %rdi
     e1c:      	movl	$0x1b, %eax
     e21:      	movl	$0x6, %ecx
     e26:      	movl	$0x1b, %esi
     e2b:      	xorl	%eax, %eax
     e2d:      	callq	*%rcx
     e2f:      	jmp	0x888 <uprobe__generic+0x888>
     e34:      	cmpl	$0x0, (%rbp)
     e38:      	jne	0x127a <uprobe__generic+0x127a>
     e3e:      	movl	$0xc, 0xf28(%r14)
     e49:      	movl	$0xfac, %r12d           # imm = 0xFAC
     e4f:      	jmp	0x885 <uprobe__generic+0x885>
     e54:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     e5e:      	movq	%rax, 0x36(%rsp)
     e63:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     e6d:      	movq	%rax, 0x30(%rsp)
     e72:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     e7c:      	movq	%rax, 0x28(%rsp)
     e81:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     e8b:      	movq	%rax, 0x20(%rsp)
     e90:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     e9a:      	movq	%rax, 0x18(%rsp)
     e9f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     ea9:      	movq	%rax, 0x10(%rsp)
     eae:      	leaq	0x10(%rsp), %rdi
     eb3:      	movl	$0x2e, %eax
     eb8:      	movl	$0x6, %ecx
     ebd:      	movl	0xc0(%rsp), %edx
     ec4:      	movl	$0x2e, %esi
     ec9:      	xorl	%eax, %eax
     ecb:      	callq	*%rcx
     ecd:      	jmp	0x910 <uprobe__generic+0x910>
     ed2:      	movabsq	$0xa64253d74706d, %rcx  # imm = 0xA64253D74706D
     edc:      	movq	%rcx, 0x27(%rsp)
     ee1:      	movabsq	$0x6d65747461202c64, %rcx # imm = 0x6D65747461202C64
     eeb:      	movq	%rcx, 0x20(%rsp)
     ef0:      	movabsq	$0x6e657320746e6576, %rcx # imm = 0x6E657320746E6576
     efa:      	movq	%rcx, 0x18(%rsp)
     eff:      	movabsq	$0x6520642520444950, %rcx # imm = 0x6520642520444950
     f09:      	movq	%rcx, 0x10(%rsp)
     f0e:      	leaq	0x10(%rsp), %rdi
     f13:      	movl	$0x1f, %ecx
     f18:      	movl	$0x6, %r8d
     f1e:      	movl	0x4(%rsp), %edx
     f22:      	movl	$0x1f, %esi
     f27:      	movl	%r14d, %ecx
     f2a:      	movq	%rax, %r13
     f2d:      	xorl	%eax, %eax
     f2f:      	callq	*%r8
     f32:      	movq	%r13, %rax
     f35:      	jmp	0x40d <uprobe__generic+0x40d>
     f3a:      	movabsq	$0xa2930203d3d2043, %rax # imm = 0xA2930203D3D2043
     f44:      	movq	%rax, 0x38(%rsp)
     f49:      	movabsq	$0x5028206572756c69, %rax # imm = 0x5028206572756C69
     f53:      	movq	%rax, 0x30(%rsp)
     f58:      	movabsq	$0x616620646e69776e, %rax # imm = 0x616620646E69776E
     f62:      	movq	%rax, 0x28(%rsp)
     f67:      	movabsq	$0x75206f7420657564, %rax # imm = 0x75206F7420657564
     f71:      	movq	%rax, 0x20(%rsp)
     f76:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
     f80:      	movq	%rax, 0x18(%rsp)
     f85:      	movabsq	$0x676e6970706f7453, %rax # imm = 0x676E6970706F7453
     f8f:      	movq	%rax, 0x10(%rsp)
     f94:      	movb	$0x0, 0x40(%rsp)
     f99:      	leaq	0x10(%rsp), %rdi
     f9e:      	movl	$0x31, %eax
     fa3:      	movl	$0x6, %ecx
     fa8:      	movl	$0x31, %esi
     fad:      	xorl	%eax, %eax
     faf:      	callq	*%rcx
     fb1:      	jmp	0x3ae <uprobe__generic+0x3ae>
     fb6:      	movabsq	$0x7373657264646120, %rax # imm = 0x7373657264646120
     fc0:      	movq	%rax, 0x28(%rsp)
     fc5:      	movabsq	$0x6c656e72656b2061, %rax # imm = 0x6C656E72656B2061
     fcf:      	movq	%rax, 0x20(%rsp)
     fd4:      	movabsq	$0x20736920786c2520, %rax # imm = 0x20736920786C2520
     fde:      	movq	%rax, 0x18(%rsp)
     fe3:      	movabsq	$0x65756c6176204350, %rax # imm = 0x65756C6176204350
     fed:      	movq	%rax, 0x10(%rsp)
     ff2:      	movw	$0xa, 0x30(%rsp)
     ff9:      	leaq	0x10(%rsp), %rdi
     ffe:      	movl	$0x22, %eax
    1003:      	movl	$0x6, %ecx
    1008:      	movl	$0x22, %esi
    100d:      	movq	%r12, %rdx
    1010:      	xorl	%eax, %eax
    1012:      	callq	*%rcx
    1014:      	jmp	0x2cd <uprobe__generic+0x2cd>
    1019:      	movabsq	$0xa6425203a6425, %rcx  # imm = 0xA6425203A6425
    1023:      	movq	%rcx, 0x25(%rsp)
    1028:      	movabsq	$0x3a64252044495020, %rcx # imm = 0x3A64252044495020
    1032:      	movq	%rcx, 0x20(%rsp)
    1037:      	movabsq	$0x74726f706572206f, %rcx # imm = 0x74726F706572206F
    1041:      	movq	%rcx, 0x18(%rsp)
    1046:      	movabsq	$0x742064656c696146, %rcx # imm = 0x742064656C696146
    1050:      	movq	%rcx, 0x10(%rsp)
    1055:      	leaq	0x10(%rsp), %rdi
    105a:      	movl	$0x1d, %ecx
    105f:      	movl	$0x6, %r8d
    1065:      	movl	0x4(%rsp), %edx
    1069:      	movl	$0x1d, %esi
    106e:      	movl	%eax, %ecx
    1070:      	xorl	%eax, %eax
    1072:      	callq	*%r8
    1075:      	jmp	0x452 <uprobe__generic+0x452>
    107a:      	movabsq	$0xa676e69726f6e, %rax  # imm = 0xA676E69726F6E
    1084:      	movq	%rax, 0x26(%rsp)
    1089:      	movabsq	$0x6f6e6769202c786c, %rax # imm = 0x6F6E6769202C786C
    1093:      	movq	%rax, 0x20(%rsp)
    1098:      	movabsq	$0x252065756c617620, %rax # imm = 0x252065756C617620
    10a2:      	movq	%rax, 0x18(%rsp)
    10a7:      	movabsq	$0x6370206c6c616d73, %rax # imm = 0x6370206C6C616D73
    10b1:      	movq	%rax, 0x10(%rsp)
    10b6:      	leaq	0x10(%rsp), %rdi
    10bb:      	movl	$0x1e, %eax
    10c0:      	movl	$0x6, %ecx
    10c5:      	movl	$0x1e, %esi
    10ca:      	movq	%r12, %rdx
    10cd:      	xorl	%eax, %eax
    10cf:      	callq	*%rcx
    10d1:      	jmp	0xcc1 <uprobe__generic+0xcc1>
    10d6:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    10e0:      	movq	%rax, 0x38(%rsp)
    10e5:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    10ef:      	movq	%rax, 0x30(%rsp)
    10f4:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    10fe:      	movq	%rax, 0x28(%rsp)
    1103:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    110d:      	movq	%rax, 0x20(%rsp)
    1112:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    111c:      	movq	%rax, 0x18(%rsp)
    1121:      	movabsq	$0x6365732074786554, %r13 # imm = 0x6365732074786554
    112b:      	movq	%r13, 0x10(%rsp)
    1130:      	movw	$0xa, 0x40(%rsp)
    1137:      	leaq	0x10(%rsp), %rdi
    113c:      	movl	$0x32, %eax
    1141:      	movl	$0x6, %r9d
    1147:      	movq	0xf10(%r14), %rcx
    114e:      	movl	$0x32, %esi
    1153:      	movq	%r12, %rdx
    1156:      	movl	%r15d, %r8d
    1159:      	xorl	%eax, %eax
    115b:      	callq	*%r9
    115e:      	cmpl	$0x0, (%rbp)
    1162:      	je	0xd54 <uprobe__generic+0xd54>
    1168:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    1172:      	movq	%rax, 0x37(%rsp)
    1177:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    1181:      	movq	%rax, 0x30(%rsp)
    1186:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    1190:      	movq	%rax, 0x28(%rsp)
    1195:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    119f:      	movq	%rax, 0x20(%rsp)
    11a4:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    11ae:      	movq	%rax, 0x18(%rsp)
    11b3:      	movq	%r13, 0x10(%rsp)
    11b8:      	leaq	0x10(%rsp), %rdi
    11bd:      	movl	$0x2f, %eax
    11c2:      	movl	$0x6, %r8d
    11c8:      	movq	0xf18(%r14), %rcx
    11cf:      	movq	0xf20(%r14), %rdx
    11d6:      	movl	$0x2f, %esi
    11db:      	xorl	%eax, %eax
    11dd:      	callq	*%r8
    11e0:      	jmp	0xd54 <uprobe__generic+0xd54>
    11e5:      	movl	0xb8(%rsp), %ecx
    11ec:      	movabsq	$0xa6425203a6425, %rdx  # imm = 0xA6425203A6425
    11f6:      	movq	%rdx, 0x3d(%rsp)
    11fb:      	movabsq	$0x3a6425203a444954, %rdx # imm = 0x3A6425203A444954
    1205:      	movq	%rdx, 0x38(%rsp)
    120a:      	movabsq	$0x2064252044495020, %rdx # imm = 0x2064252044495020
    1214:      	movq	%rdx, 0x30(%rsp)
    1219:      	movabsq	$0x687469772073746e, %rdx # imm = 0x687469772073746E
    1223:      	movq	%rdx, 0x28(%rsp)
    1228:      	movabsq	$0x6576655f64697020, %rdx # imm = 0x6576655F64697020
    1232:      	movq	%rdx, 0x20(%rsp)
    1237:      	movabsq	$0x657461647075206f, %rdx # imm = 0x657461647075206F
    1241:      	movq	%rdx, 0x18(%rsp)
    1246:      	movabsq	$0x742064656c696146, %rdx # imm = 0x742064656C696146
    1250:      	movq	%rdx, 0x10(%rsp)
    1255:      	leaq	0x10(%rsp), %rdi
    125a:      	movl	$0x35, %edx
    125f:      	movl	$0x6, %r9d
    1265:      	movl	$0x35, %esi
    126a:      	movl	%r15d, %edx
    126d:      	movl	%eax, %r8d
    1270:      	xorl	%eax, %eax
    1272:      	callq	*%r9
    1275:      	jmp	0x4b4 <uprobe__generic+0x4b4>
    127a:      	movabsq	$0xa786c2578302043, %rax # imm = 0xA786C2578302043
    1284:      	movq	%rax, 0x40(%rsp)
    1289:      	movabsq	$0x5020726f6620676e, %rax # imm = 0x5020726F6620676E
    1293:      	movq	%rax, 0x38(%rsp)
    1298:      	movabsq	$0x697070616d207972, %rax # imm = 0x697070616D207972
    12a2:      	movq	%rax, 0x30(%rsp)
    12a7:      	movabsq	$0x6f6d656d206c6176, %rax # imm = 0x6F6D656D206C6176
    12b1:      	movq	%rax, 0x28(%rsp)
    12b6:      	movabsq	$0x7265746e69207075, %rax # imm = 0x7265746E69207075
    12c0:      	movq	%rax, 0x20(%rsp)
    12c5:      	movabsq	$0x206b6f6f6c206f74, %rax # imm = 0x206B6F6F6C206F74
    12cf:      	movq	%rax, 0x18(%rsp)
    12d4:      	movabsq	$0x206572756c696146, %rax # imm = 0x206572756C696146
    12de:      	movq	%rax, 0x10(%rsp)
    12e3:      	movb	$0x0, 0x48(%rsp)
    12e8:      	leaq	0x10(%rsp), %rdi
    12ed:      	movl	$0x39, %eax
    12f2:      	movl	$0x6, %ecx
    12f7:      	movl	$0x39, %esi
    12fc:      	movq	%r12, %rdx
    12ff:      	xorl	%eax, %eax
    1301:      	callq	*%rcx
    1303:      	jmp	0xe3e <uprobe__generic+0xe3e>
    1308:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1312:      	movq	%rax, 0x36(%rsp)
    1317:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1321:      	movq	%rax, 0x30(%rsp)
    1326:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1330:      	movq	%rax, 0x28(%rsp)
    1335:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    133f:      	movq	%rax, 0x20(%rsp)
    1344:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    134e:      	movq	%rax, 0x18(%rsp)
    1353:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    135d:      	movq	%rax, 0x10(%rsp)
    1362:      	leaq	0x10(%rsp), %rdi
    1367:      	movl	$0x2e, %eax
    136c:      	movl	$0x6, %ecx
    1371:      	movl	0xc0(%rsp), %edx
    1378:      	movl	$0x2e, %esi
    137d:      	xorl	%eax, %eax
    137f:      	callq	*%rcx
    1381:      	jmp	0x742 <uprobe__generic+0x742>
    1386:      	movabsq	$0xa642520726f72, %rcx  # imm = 0xA642520726F72
    1390:      	movq	%rcx, 0x3e(%rsp)
    1395:      	movabsq	$0x6f727265203a6425, %rcx # imm = 0x6F727265203A6425
    139f:      	movq	%rcx, 0x38(%rsp)
    13a4:      	movabsq	$0x20746e6576652064, %rcx # imm = 0x20746E6576652064
    13ae:      	movq	%rcx, 0x30(%rsp)
    13b3:      	movabsq	$0x6e6573206f742064, %rcx # imm = 0x6E6573206F742064
    13bd:      	movq	%rcx, 0x28(%rsp)
    13c2:      	movabsq	$0x656c696166207265, %rcx # imm = 0x656C696166207265
    13cc:      	movq	%rcx, 0x20(%rsp)
    13d1:      	movabsq	$0x67676972745f646e, %rcx # imm = 0x67676972745F646E
    13db:      	movq	%rcx, 0x18(%rsp)
    13e0:      	movabsq	$0x65735f746e657665, %rcx # imm = 0x65735F746E657665
    13ea:      	movq	%rcx, 0x10(%rsp)
    13ef:      	leaq	0x10(%rsp), %rdi
    13f4:      	movl	$0x36, %ecx
    13f9:      	movl	$0x6, %r8d
    13ff:      	movl	$0x36, %esi
    1404:      	movl	$0x1, %edx
    1409:      	movl	%eax, %ecx
    140b:      	xorl	%eax, %eax
    140d:      	callq	*%r8
    1410:      	jmp	0x70e <uprobe__generic+0x70e>
    1415:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    141f:      	movq	%rax, 0x36(%rsp)
    1424:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    142e:      	movq	%rax, 0x30(%rsp)
    1433:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    143d:      	movq	%rax, 0x28(%rsp)
    1442:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    144c:      	movq	%rax, 0x20(%rsp)
    1451:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    145b:      	movq	%rax, 0x18(%rsp)
    1460:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    146a:      	movq	%rax, 0x10(%rsp)
    146f:      	leaq	0x10(%rsp), %rdi
    1474:      	movl	$0x2e, %eax
    1479:      	movl	$0x6, %ecx
    147e:      	movl	0xc0(%rsp), %edx
    1485:      	movl	$0x2e, %esi
    148a:      	xorl	%eax, %eax
    148c:      	callq	*%rcx
    148e:      	jmp	0x6c5 <uprobe__generic+0x6c5>
    1493:      	movabsq	$0xa642520686374, %rcx  # imm = 0xA642520686374
    149d:      	movq	%rcx, 0x26(%rsp)
    14a2:      	movabsq	$0x6374616d20737465, %rcx # imm = 0x6374616D20737465
    14ac:      	movq	%rcx, 0x20(%rsp)
    14b1:      	movabsq	$0x7366666f5f726574, %rcx # imm = 0x7366666F5F726574
    14bb:      	movq	%rcx, 0x18(%rsp)
    14c0:      	movabsq	$0x6572707265746e69, %rcx # imm = 0x6572707265746E69
    14ca:      	movq	%rcx, 0x10(%rsp)
    14cf:      	leaq	0x10(%rsp), %rdi
    14d4:      	movl	$0x1e, %ecx
    14d9:      	movl	$0x6, %r8d
    14df:      	movzwl	0x20(%rax), %edx
    14e3:      	movl	$0x1e, %esi
    14e8:      	movq	%rax, %r13
    14eb:      	xorl	%eax, %eax
    14ed:      	callq	*%r8
    14f0:      	movq	%r13, %rax
    14f3:      	movl	0x1380(%r14), %ecx
    14fa:      	movl	0x20(%rax), %edx
    14fd:      	btl	%edx, %ecx
    1500:      	jb	0xdd8 <uprobe__generic+0xdd8>
    1506:      	movq	%rax, %r15
    1509:      	movl	$0x0, 0xb8(%rsp)
    1514:      	movq	(%rip), %rdi            # 0x151b <uprobe__generic+0x151b>
    151b:      	leaq	0xb8(%rsp), %rsi
    1523:      	movl	$0x1, %eax
    1528:      	callq	*%rax
    152a:      	testq	%rax, %rax
    152d:      	je	0x1537 <uprobe__generic+0x1537>
    152f:      	incq	(%rax)
    1532:      	movq	%r15, %rax
    1535:      	jmp	0x1540 <uprobe__generic+0x1540>
    1537:      	cmpl	$0x0, (%rbp)
    153b:      	movq	%r15, %rax
    153e:      	jne	0x154a <uprobe__generic+0x154a>
    1540:      	movzwl	0x20(%rax), %r15d
    1545:      	jmp	0x888 <uprobe__generic+0x888>
    154a:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1554:      	movq	%rax, 0x36(%rsp)
    1559:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1563:      	movq	%rax, 0x30(%rsp)
    1568:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1572:      	movq	%rax, 0x28(%rsp)
    1577:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1581:      	movq	%rax, 0x20(%rsp)
    1586:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1590:      	movq	%rax, 0x18(%rsp)
    1595:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    159f:      	movq	%rax, 0x10(%rsp)
    15a4:      	leaq	0x10(%rsp), %rdi
    15a9:      	movl	$0x2e, %eax
    15ae:      	movl	$0x6, %ecx
    15b3:      	movl	0xb8(%rsp), %edx
    15ba:      	movl	$0x2e, %esi
    15bf:      	xorl	%eax, %eax
    15c1:      	callq	*%rcx
    15c3:      	jmp	0x1532 <uprobe__generic+0x1532>
