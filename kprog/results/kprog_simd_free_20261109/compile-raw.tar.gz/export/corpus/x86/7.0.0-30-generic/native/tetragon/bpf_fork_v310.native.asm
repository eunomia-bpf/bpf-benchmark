
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_fork_v310.native.o:	file format elf64-x86-64

Disassembly of section kprobe/wake_up_new_task:

0000000000000000 <event_wake_up_new_task>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x88, %rsp
      11:      	movq	0x70(%rdi), %r14
      15:      	testq	%r14, %r14
      18:      	je	0x8ed <event_wake_up_new_task+0x8ed>
      1e:      	movq	%rdi, %rbx
      21:      	leaq	0xaf4(%r14), %rdx
      28:      	leaq	0x30(%rsp), %rdi
      2d:      	movl	$0x4, %ecx
      32:      	movl	$0x4, %eax
      37:      	movl	$0x4, %esi
      3c:      	callq	*%rax
      3e:      	movl	0x30(%rsp), %ebp
      42:      	movq	%r14, 0x30(%rsp)
      47:      	leaq	0xb00(%r14), %rcx
      4e:      	leaq	0x30(%rsp), %rdi
      53:      	movl	$0x8, %edx
      58:      	movl	$0x71, %eax
      5d:      	movl	$0xb00, %edx            # imm = 0xB00
      62:      	addq	0x30(%rsp), %rdx
      67:      	movl	$0x8, %esi
      6c:      	callq	*%rax
      6e:      	movq	0x30(%rsp), %rcx
      73:      	testq	%rcx, %rcx
      76:      	je	0x8ed <event_wake_up_new_task+0x8ed>
      7c:      	addq	$0xaf4, %rcx            # imm = 0xAF4
      83:      	leaq	0x8(%rsp), %rdi
      88:      	movl	$0x4, %edx
      8d:      	movl	$0x71, %eax
      92:      	movl	$0xaf4, %edx            # imm = 0xAF4
      97:      	addq	0x30(%rsp), %rdx
      9c:      	movl	$0x4, %esi
      a1:      	callq	*%rax
      a3:      	movl	0x8(%rsp), %eax
      a7:      	movl	%eax, 0x10(%rsp)
      ab:      	movq	(%rip), %rdi            # 0xb2 <event_wake_up_new_task+0xb2>
      b2:      	leaq	0x10(%rsp), %rsi
      b7:      	movl	$0x1, %eax
      bc:      	callq	*%rax
      be:      	testq	%rax, %rax
      c1:      	je	0xd1 <event_wake_up_new_task+0xd1>
      c3:      	movq	%rax, %r15
      c6:      	cmpq	$0x0, 0x8(%rax)
      cb:      	jne	0x276 <event_wake_up_new_task+0x276>
      d1:      	movl	$0xb00, %edx            # imm = 0xB00
      d6:      	movq	0x30(%rsp), %rcx
      db:      	addq	%rdx, %rcx
      de:      	leaq	0x30(%rsp), %rdi
      e3:      	movl	$0x8, %esi
      e8:      	movl	$0x71, %eax
      ed:      	addq	0x30(%rsp), %rdx
      f2:      	movl	$0x8, %esi
      f7:      	callq	*%rax
      f9:      	movq	0x30(%rsp), %rcx
      fe:      	testq	%rcx, %rcx
     101:      	je	0x8ed <event_wake_up_new_task+0x8ed>
     107:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     10e:      	leaq	0x8(%rsp), %rdi
     113:      	movl	$0x4, %edx
     118:      	movl	$0x71, %eax
     11d:      	movl	$0xaf4, %edx            # imm = 0xAF4
     122:      	addq	0x30(%rsp), %rdx
     127:      	movl	$0x4, %esi
     12c:      	callq	*%rax
     12e:      	movl	0x8(%rsp), %eax
     132:      	movl	%eax, 0x10(%rsp)
     136:      	movq	(%rip), %rdi            # 0x13d <event_wake_up_new_task+0x13d>
     13d:      	leaq	0x10(%rsp), %rsi
     142:      	movl	$0x1, %eax
     147:      	callq	*%rax
     149:      	testq	%rax, %rax
     14c:      	je	0x15c <event_wake_up_new_task+0x15c>
     14e:      	movq	%rax, %r15
     151:      	cmpq	$0x0, 0x8(%rax)
     156:      	jne	0x276 <event_wake_up_new_task+0x276>
     15c:      	movl	$0xb00, %edx            # imm = 0xB00
     161:      	movq	0x30(%rsp), %rcx
     166:      	addq	%rdx, %rcx
     169:      	leaq	0x30(%rsp), %rdi
     16e:      	movl	$0x8, %esi
     173:      	movl	$0x71, %eax
     178:      	addq	0x30(%rsp), %rdx
     17d:      	movl	$0x8, %esi
     182:      	callq	*%rax
     184:      	movq	0x30(%rsp), %rcx
     189:      	testq	%rcx, %rcx
     18c:      	je	0x8ed <event_wake_up_new_task+0x8ed>
     192:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     199:      	leaq	0x8(%rsp), %rdi
     19e:      	movl	$0x4, %edx
     1a3:      	movl	$0x71, %eax
     1a8:      	movl	$0xaf4, %edx            # imm = 0xAF4
     1ad:      	addq	0x30(%rsp), %rdx
     1b2:      	movl	$0x4, %esi
     1b7:      	callq	*%rax
     1b9:      	movl	0x8(%rsp), %eax
     1bd:      	movl	%eax, 0x10(%rsp)
     1c1:      	movq	(%rip), %rdi            # 0x1c8 <event_wake_up_new_task+0x1c8>
     1c8:      	leaq	0x10(%rsp), %rsi
     1cd:      	movl	$0x1, %eax
     1d2:      	callq	*%rax
     1d4:      	testq	%rax, %rax
     1d7:      	je	0x1e7 <event_wake_up_new_task+0x1e7>
     1d9:      	movq	%rax, %r15
     1dc:      	cmpq	$0x0, 0x8(%rax)
     1e1:      	jne	0x276 <event_wake_up_new_task+0x276>
     1e7:      	movl	$0xb00, %edx            # imm = 0xB00
     1ec:      	movq	0x30(%rsp), %rcx
     1f1:      	addq	%rdx, %rcx
     1f4:      	leaq	0x30(%rsp), %rdi
     1f9:      	movl	$0x8, %esi
     1fe:      	movl	$0x71, %eax
     203:      	addq	0x30(%rsp), %rdx
     208:      	movl	$0x8, %esi
     20d:      	callq	*%rax
     20f:      	movq	0x30(%rsp), %rcx
     214:      	testq	%rcx, %rcx
     217:      	je	0x8ed <event_wake_up_new_task+0x8ed>
     21d:      	addq	$0xaf4, %rcx            # imm = 0xAF4
     224:      	leaq	0x8(%rsp), %rdi
     229:      	movl	$0x4, %edx
     22e:      	movl	$0x71, %eax
     233:      	movl	$0xaf4, %edx            # imm = 0xAF4
     238:      	addq	0x30(%rsp), %rdx
     23d:      	movl	$0x4, %esi
     242:      	callq	*%rax
     244:      	movl	0x8(%rsp), %eax
     248:      	movl	%eax, 0x10(%rsp)
     24c:      	movq	(%rip), %rdi            # 0x253 <event_wake_up_new_task+0x253>
     253:      	leaq	0x10(%rsp), %rsi
     258:      	movl	$0x1, %eax
     25d:      	callq	*%rax
     25f:      	testq	%rax, %rax
     262:      	je	0x8ed <event_wake_up_new_task+0x8ed>
     268:      	movq	%rax, %r15
     26b:      	cmpq	$0x0, 0x8(%rax)
     270:      	je	0x8ed <event_wake_up_new_task+0x8ed>
     276:      	movl	%ebp, 0x10(%rsp)
     27a:      	movq	(%rip), %rdi            # 0x281 <event_wake_up_new_task+0x281>
     281:      	leaq	0x10(%rsp), %rsi
     286:      	movl	$0x1, %eax
     28b:      	callq	*%rax
     28d:      	testq	%rax, %rax
     290:      	je	0x57e <event_wake_up_new_task+0x57e>
     296:      	movq	%rax, %r12
     299:      	cmpq	$0x0, 0x8(%r12)
     29f:      	jne	0x8ed <event_wake_up_new_task+0x8ed>
     2a5:      	movl	$0x1, 0x20(%r12)
     2ae:      	movl	%ebp, (%r12)
     2b2:      	movl	$0x5, %eax
     2b7:      	callq	*%rax
     2b9:      	movq	%rax, 0x8(%r12)
     2be:      	leaq	0x60(%r14), %rdx
     2c2:      	leaq	0x10(%rsp), %rdi
     2c7:      	movl	$0x8, %ecx
     2cc:      	movl	$0x71, %eax
     2d1:      	movl	$0x8, %esi
     2d6:      	callq	*%rax
     2d8:      	movq	0x10(%rsp), %rcx
     2dd:      	xorl	%ebp, %ebp
     2df:      	testq	%rcx, %rcx
     2e2:      	je	0x351 <event_wake_up_new_task+0x351>
     2e4:      	addq	$0x4, %rcx
     2e8:      	leaq	0x8(%rsp), %rdi
     2ed:      	movl	$0x4, %edx
     2f2:      	movl	$0x71, %eax
     2f7:      	movq	0x10(%rsp), %rdx
     2fc:      	addq	$0x4, %rdx
     300:      	movl	$0x4, %esi
     305:      	callq	*%rax
     307:      	movl	0x8(%rsp), %eax
     30b:      	testl	%eax, %eax
     30d:      	je	0x351 <event_wake_up_new_task+0x351>
     30f:      	movq	0x10(%rsp), %rcx
     314:      	shll	$0x4, %eax
     317:      	addq	%rax, %rcx
     31a:      	addq	$0x80, %rcx
     321:      	leaq	0x30(%rsp), %rdi
     326:      	movl	$0x10, %edx
     32b:      	movl	$0x71, %eax
     330:      	movq	0x10(%rsp), %rcx
     335:      	movl	0x8(%rsp), %edx
     339:      	shll	$0x4, %edx
     33c:      	addq	%rcx, %rdx
     33f:      	addq	$0x80, %rdx
     346:      	movl	$0x10, %esi
     34b:      	callq	*%rax
     34d:      	movl	0x30(%rsp), %ebp
     351:      	movl	%ebp, 0x24(%r12)
     356:      	leaq	0x68(%r12), %rdi
     35b:      	leaq	0x68(%r15), %rsi
     35f:      	movl	$0x318, %edx            # imm = 0x318
     364:      	callq	0x369 <event_wake_up_new_task+0x369>
     369:      	movq	(%r15), %rax
     36c:      	movq	0x8(%r15), %rcx
     370:      	movq	%rax, 0x10(%r12)
     375:      	movq	%rcx, 0x18(%r12)
     37a:      	leaq	0xd00(%r14), %rdx
     381:      	leaq	0x30(%rsp), %rdi
     386:      	movl	$0x8, %ecx
     38b:      	movl	$0x4, %eax
     390:      	leaq	0x50(%r12), %rbp
     395:      	movl	$0x8, %esi
     39a:      	movq	%rdx, 0x80(%rsp)
     3a2:      	callq	*%rax
     3a4:      	movq	0x30(%rsp), %r13
     3a9:      	leaq	0x58(%r12), %rdi
     3ae:      	leaq	0x40(%r13), %rdx
     3b2:      	movl	$0x8, %ecx
     3b7:      	movl	$0x4, %eax
     3bc:      	movl	$0x8, %esi
     3c1:      	callq	*%rax
     3c3:      	leaq	0x60(%r12), %rdi
     3c8:      	leaq	0x30(%r13), %rdx
     3cc:      	movl	$0x8, %ecx
     3d1:      	movl	$0x4, %eax
     3d6:      	movl	$0x8, %esi
     3db:      	callq	*%rax
     3dd:      	addq	$0x38, %r13
     3e1:      	movl	$0x8, %ecx
     3e6:      	movl	$0x4, %eax
     3eb:      	movq	%rbp, %rdi
     3ee:      	movl	$0x8, %esi
     3f3:      	movq	%r13, %rdx
     3f6:      	callq	*%rax
     3f8:      	leaq	0x28(%r12), %rbp
     3fd:      	leaq	0xd70(%r14), %rdx
     404:      	leaq	0x8(%rsp), %rdi
     409:      	movl	$0x8, %ecx
     40e:      	movl	$0x4, %eax
     413:      	movl	$0x8, %esi
     418:      	callq	*%rax
     41a:      	movq	0x8(%rsp), %rcx
     41f:      	leaq	0x30(%rsp), %rdi
     424:      	movl	$0x48, %edx
     429:      	movl	$0x4, %eax
     42e:      	movq	0x8(%rsp), %rdx
     433:      	movl	$0x48, %esi
     438:      	callq	*%rax
     43a:      	movl	$0x218, %edx            # imm = 0x218
     43f:      	movq	0x38(%rsp), %rcx
     444:      	addq	%rdx, %rcx
     447:      	movl	$0x4, %esi
     44c:      	movl	$0x4, %eax
     451:      	addq	0x38(%rsp), %rdx
     456:      	movq	%rbp, %rdi
     459:      	movl	$0x4, %esi
     45e:      	callq	*%rax
     460:      	leaq	0x2c(%r12), %rdi
     465:      	movl	$0x4d8, %edx            # imm = 0x4D8
     46a:      	movq	0x40(%rsp), %rcx
     46f:      	addq	%rdx, %rcx
     472:      	movl	$0x4, %esi
     477:      	movl	$0x4, %eax
     47c:      	addq	0x40(%rsp), %rdx
     481:      	movl	$0x4, %esi
     486:      	callq	*%rax
     488:      	leaq	0x30(%r12), %rdi
     48d:      	movq	0x48(%rsp), %rcx
     492:      	addq	$0x58, %rcx
     496:      	movl	$0x4, %edx
     49b:      	movl	$0x4, %eax
     4a0:      	movq	0x48(%rsp), %rdx
     4a5:      	addq	$0x58, %rdx
     4a9:      	movl	$0x4, %esi
     4ae:      	callq	*%rax
     4b0:      	movq	$0x0, 0x20(%rsp)
     4b9:      	leaq	0xb58(%r14), %rdx
     4c0:      	leaq	0x20(%rsp), %rdi
     4c5:      	movl	$0x8, %ecx
     4ca:      	movl	$0x4, %eax
     4cf:      	movl	$0x8, %esi
     4d4:      	callq	*%rax
     4d6:      	movq	0x20(%rsp), %rcx
     4db:      	testq	%rcx, %rcx
     4de:      	je	0x61e <event_wake_up_new_task+0x61e>
     4e4:      	movl	$0x0, 0x2c(%rsp)
     4ec:      	addq	$0x4, %rcx
     4f0:      	leaq	0x2c(%rsp), %rdi
     4f5:      	movl	$0x4, %eax
     4fa:      	movl	$0x4, %r13d
     500:      	movq	0x20(%rsp), %rdx
     505:      	addq	$0x4, %rdx
     509:      	movl	$0x4, %esi
     50e:      	callq	*%rax
     510:      	movq	0x20(%rsp), %rax
     515:      	movslq	0x2c(%rsp), %rcx
     51a:      	shlq	$0x4, %rcx
     51e:      	addq	%rax, %rcx
     521:      	addq	$0x80, %rcx
     528:      	leaq	0x10(%rsp), %rdi
     52d:      	movl	$0x10, %edx
     532:      	movl	$0x4, %eax
     537:      	movq	0x20(%rsp), %rcx
     53c:      	movslq	0x2c(%rsp), %rdx
     541:      	shlq	$0x4, %rdx
     545:      	addq	%rcx, %rdx
     548:      	addq	$0x80, %rdx
     54f:      	movl	$0x10, %esi
     554:      	callq	*%rax
     556:      	leaq	0x34(%r12), %rdi
     55b:      	movl	$0x158, %edx            # imm = 0x158
     560:      	movq	0x18(%rsp), %rcx
     565:      	addq	%rdx, %rcx
     568:      	movl	$0x4, %eax
     56d:      	addq	0x18(%rsp), %rdx
     572:      	movl	$0x4, %esi
     577:      	callq	*%rax
     579:      	jmp	0x627 <event_wake_up_new_task+0x627>
     57e:      	movl	$0x0, 0x8(%rsp)
     586:      	movq	(%rip), %rdi            # 0x58d <event_wake_up_new_task+0x58d>
     58d:      	leaq	0x8(%rsp), %rsi
     592:      	movl	$0x1, %eax
     597:      	callq	*%rax
     599:      	testq	%rax, %rax
     59c:      	je	0x8ed <event_wake_up_new_task+0x8ed>
     5a2:      	xorl	%r13d, %r13d
     5a5:      	movl	$0x380, %edx            # imm = 0x380
     5aa:      	movq	%rax, %rdi
     5ad:      	xorl	%esi, %esi
     5af:      	movq	%rax, %r12
     5b2:      	callq	0x5b7 <event_wake_up_new_task+0x5b7>
     5b7:      	movq	(%rip), %rdi            # 0x5be <event_wake_up_new_task+0x5be>
     5be:      	leaq	0x10(%rsp), %rsi
     5c3:      	movl	$0x2, %eax
     5c8:      	movq	%r12, %rdx
     5cb:      	xorl	%ecx, %ecx
     5cd:      	callq	*%rax
     5cf:      	testl	%eax, %eax
     5d1:      	je	0x880 <event_wake_up_new_task+0x880>
     5d7:      	movl	$0x1, 0x30(%rsp)
     5df:      	movq	(%rip), %rdi            # 0x5e6 <event_wake_up_new_task+0x5e6>
     5e6:      	leaq	0x30(%rsp), %rsi
     5eb:      	movl	$0x1, %eax
     5f0:      	callq	*%rax
     5f2:      	testq	%rax, %rax
     5f5:      	je	0x5fa <event_wake_up_new_task+0x5fa>
     5f7:      	incq	(%rax)
     5fa:      	movq	(%rip), %rdi            # 0x601 <event_wake_up_new_task+0x601>
     601:      	leaq	0x10(%rsp), %rsi
     606:      	movl	$0x1, %eax
     60b:      	callq	*%rax
     60d:      	movq	%rax, %r12
     610:      	testq	%rax, %rax
     613:      	jne	0x299 <event_wake_up_new_task+0x299>
     619:      	jmp	0x8ed <event_wake_up_new_task+0x8ed>
     61e:      	movl	$0x0, 0x34(%r12)
     627:      	leaq	0x38(%r12), %rdi
     62c:      	movl	$0x158, %ebp            # imm = 0x158
     631:      	movq	0x50(%rsp), %rcx
     636:      	addq	%rbp, %rcx
     639:      	movl	$0x4, %edx
     63e:      	movl	$0x4, %eax
     643:      	leaq	0x10(%r12), %rcx
     648:      	movq	%rcx, 0x78(%rsp)
     64d:      	movq	0x50(%rsp), %rdx
     652:      	addq	%rbp, %rdx
     655:      	movl	$0x4, %esi
     65a:      	callq	*%rax
     65c:      	leaq	0x3c(%r12), %rdi
     661:      	movl	$0x118, %edx            # imm = 0x118
     666:      	movq	0x58(%rsp), %rcx
     66b:      	addq	%rdx, %rcx
     66e:      	movl	$0x4, %esi
     673:      	movl	$0x4, %eax
     678:      	addq	0x58(%rsp), %rdx
     67d:      	movl	$0x4, %esi
     682:      	callq	*%rax
     684:      	leaq	0x40(%r12), %rdi
     689:      	movl	$0x98, %r13d
     68f:      	movq	0x60(%rsp), %rcx
     694:      	addq	%r13, %rcx
     697:      	movl	$0x4, %edx
     69c:      	movl	$0x4, %eax
     6a1:      	movq	0x60(%rsp), %rdx
     6a6:      	addq	%r13, %rdx
     6a9:      	movl	$0x4, %esi
     6ae:      	callq	*%rax
     6b0:      	leaq	0x44(%r12), %rdi
     6b5:      	movq	0x68(%rsp), %rcx
     6ba:      	addq	%r13, %rcx
     6bd:      	movl	$0x4, %edx
     6c2:      	movl	$0x4, %eax
     6c7:      	addq	0x68(%rsp), %r13
     6cc:      	movl	$0x4, %esi
     6d1:      	movq	%r13, %rdx
     6d4:      	callq	*%rax
     6d6:      	leaq	0x48(%r12), %rdi
     6db:      	movq	0x70(%rsp), %rcx
     6e0:      	addq	$0x58, %rcx
     6e4:      	movl	$0x4, %edx
     6e9:      	movl	$0x4, %eax
     6ee:      	movq	0x70(%rsp), %rdx
     6f3:      	addq	$0x58, %rdx
     6f7:      	movl	$0x4, %esi
     6fc:      	callq	*%rax
     6fe:      	movq	$0x0, 0x10(%rsp)
     707:      	movq	$0x0, 0x20(%rsp)
     710:      	leaq	0x10(%rsp), %rdi
     715:      	movl	$0x8, %ecx
     71a:      	movl	$0x4, %eax
     71f:      	movq	0x80(%rsp), %rdx
     727:      	movl	$0x8, %esi
     72c:      	callq	*%rax
     72e:      	movl	$0x90, %edx
     733:      	movq	0x10(%rsp), %rcx
     738:      	addq	%rdx, %rcx
     73b:      	leaq	0x20(%rsp), %rdi
     740:      	movl	$0x8, %esi
     745:      	movl	$0x4, %eax
     74a:      	addq	0x10(%rsp), %rdx
     74f:      	movl	$0x8, %esi
     754:      	callq	*%rax
     756:      	leaq	0x4c(%r12), %rdi
     75b:      	movq	0x20(%rsp), %rcx
     760:      	addq	%rbp, %rcx
     763:      	movl	$0x4, %edx
     768:      	movl	$0x4, %eax
     76d:      	addq	0x20(%rsp), %rbp
     772:      	movl	$0x4, %esi
     777:      	movq	%rbp, %rdx
     77a:      	callq	*%rax
     77c:      	testb	$0x2, 0x23(%r15)
     781:      	jne	0x78b <event_wake_up_new_task+0x78b>
     783:      	cmpl	$0x1, 0x24(%r12)
     789:      	jne	0x791 <event_wake_up_new_task+0x791>
     78b:      	orb	$0x2, 0x23(%r12)
     791:      	movb	$0x17, 0x30(%rsp)
     796:      	movl	$0x38, 0x34(%rsp)
     79e:      	movq	0x8(%r12), %rax
     7a3:      	movq	%rax, 0x38(%rsp)
     7a8:      	movq	0x78(%rsp), %rcx
     7ad:      	movq	(%rcx), %rax
     7b0:      	movq	0x8(%rcx), %rcx
     7b4:      	movq	%rax, 0x40(%rsp)
     7b9:      	movq	%rcx, 0x48(%rsp)
     7be:      	movl	(%r12), %eax
     7c2:      	movl	%eax, 0x50(%rsp)
     7c6:      	addq	$0xaf0, %r14            # imm = 0xAF0
     7cd:      	leaq	0x10(%rsp), %rdi
     7d2:      	movl	$0x4, %ecx
     7d7:      	movl	$0x4, %eax
     7dc:      	movl	$0x4, %esi
     7e1:      	movq	%r14, %rdx
     7e4:      	callq	*%rax
     7e6:      	movl	0x10(%rsp), %eax
     7ea:      	movl	%eax, 0x54(%rsp)
     7ee:      	movq	0x8(%r12), %rax
     7f3:      	movq	%rax, 0x60(%rsp)
     7f8:      	movl	0x24(%r12), %eax
     7fd:      	movl	%eax, 0x58(%rsp)
     801:      	movl	0x20(%r12), %eax
     806:      	movl	%eax, 0x5c(%rsp)
     80a:      	movq	(%rip), %rsi            # 0x811 <event_wake_up_new_task+0x811>
     811:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     816:      	leaq	0x30(%rsp), %rcx
     81b:      	movl	$0x38, %edi
     820:      	movl	$0x19, %eax
     825:      	movl	$0x38, %r8d
     82b:      	movq	%rbx, %rdi
     82e:      	callq	*%rax
     830:      	testq	%rax, %rax
     833:      	jns	0x8ed <event_wake_up_new_task+0x8ed>
     839:      	movq	%rax, %rbx
     83c:      	movl	$0x0, 0x10(%rsp)
     844:      	movq	(%rip), %rdi            # 0x84b <event_wake_up_new_task+0x84b>
     84b:      	leaq	0x10(%rsp), %rsi
     850:      	movl	$0x1, %eax
     855:      	callq	*%rax
     857:      	testq	%rax, %rax
     85a:      	je	0x8ed <event_wake_up_new_task+0x8ed>
     860:      	cmpq	$-0xc, %rbx
     864:      	jg	0x8a9 <event_wake_up_new_task+0x8a9>
     866:      	cmpq	$-0x1c, %rbx
     86a:      	je	0x8c3 <event_wake_up_new_task+0x8c3>
     86c:      	cmpq	$-0x16, %rbx
     870:      	je	0x8db <event_wake_up_new_task+0x8db>
     872:      	cmpq	$-0x10, %rbx
     876:      	jne	0x8d3 <event_wake_up_new_task+0x8d3>
     878:      	addq	$0x520, %rax            # imm = 0x520
     87e:      	jmp	0x8e9 <event_wake_up_new_task+0x8e9>
     880:      	movl	$0x0, 0x30(%rsp)
     888:      	movq	(%rip), %rdi            # 0x88f <event_wake_up_new_task+0x88f>
     88f:      	leaq	0x30(%rsp), %rsi
     894:      	movl	$0x1, %eax
     899:      	callq	*%rax
     89b:      	testq	%rax, %rax
     89e:      	jne	0x5f7 <event_wake_up_new_task+0x5f7>
     8a4:      	jmp	0x5fa <event_wake_up_new_task+0x5fa>
     8a9:      	cmpq	$-0xb, %rbx
     8ad:      	je	0x8cb <event_wake_up_new_task+0x8cb>
     8af:      	cmpq	$-0x7, %rbx
     8b3:      	je	0x8e3 <event_wake_up_new_task+0x8e3>
     8b5:      	cmpq	$-0x2, %rbx
     8b9:      	jne	0x8d3 <event_wake_up_new_task+0x8d3>
     8bb:      	addq	$0x510, %rax            # imm = 0x510
     8c1:      	jmp	0x8e9 <event_wake_up_new_task+0x8e9>
     8c3:      	addq	$0x530, %rax            # imm = 0x530
     8c9:      	jmp	0x8e9 <event_wake_up_new_task+0x8e9>
     8cb:      	addq	$0x538, %rax            # imm = 0x538
     8d1:      	jmp	0x8e9 <event_wake_up_new_task+0x8e9>
     8d3:      	addq	$0x508, %rax            # imm = 0x508
     8d9:      	jmp	0x8e9 <event_wake_up_new_task+0x8e9>
     8db:      	addq	$0x528, %rax            # imm = 0x528
     8e1:      	jmp	0x8e9 <event_wake_up_new_task+0x8e9>
     8e3:      	addq	$0x518, %rax            # imm = 0x518
     8e9:      	lock
     8ea:      	incq	(%rax)
     8ed:      	xorl	%eax, %eax
     8ef:      	addq	$0x88, %rsp
     8f6:      	popq	%rbx
     8f7:      	popq	%r12
     8f9:      	popq	%r13
     8fb:      	popq	%r14
     8fd:      	popq	%r15
     8ff:      	popq	%rbp
     900:      	retq
