
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_generic_fentry_v53.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
       5:      	testq	%rdx, %rdx
       8:      	je	0x74 <native_bpf_strncasestr+0x74>
       a:      	pushq	%rbx
       b:      	xorl	%ecx, %ecx
       d:      	jmp	0x1b <native_bpf_strncasestr+0x1b>
       f:      	nop
      10:      	incq	%rcx
      13:      	incq	%rdi
      16:      	cmpq	%rdx, %rcx
      19:      	je	0x73 <native_bpf_strncasestr+0x73>
      1b:      	xorl	%r8d, %r8d
      1e:      	nop
      20:      	leaq	(%rcx,%r8), %r9
      24:      	cmpq	%rdx, %r9
      27:      	jae	0x10 <native_bpf_strncasestr+0x10>
      29:      	movsbl	(%rsi,%r8), %r9d
      2e:      	testl	%r9d, %r9d
      31:      	je	0x71 <native_bpf_strncasestr+0x71>
      33:      	movsbl	(%rdi,%r8), %r10d
      38:      	leal	-0x41(%r10), %r11d
      3c:      	movl	%r10d, %ebx
      3f:      	orl	$0x20, %ebx
      42:      	cmpl	$0x1a, %r11d
      46:      	cmovael	%r10d, %ebx
      4a:      	leal	-0x41(%r9), %r10d
      4e:      	movl	%r9d, %r11d
      51:      	orl	$0x20, %r11d
      55:      	cmpl	$0x1a, %r10d
      59:      	cmovael	%r9d, %r11d
      5d:      	cmpl	%r11d, %ebx
      60:      	jne	0x10 <native_bpf_strncasestr+0x10>
      62:      	leaq	0x1(%r8), %r9
      66:      	cmpq	$0x63, %r8
      6a:      	movq	%r9, %r8
      6d:      	jb	0x20 <native_bpf_strncasestr+0x20>
      6f:      	jmp	0x10 <native_bpf_strncasestr+0x10>
      71:      	movl	%ecx, %eax
      73:      	popq	%rbx
      74:      	retq

Disassembly of section fentry/generic_fentry_tail:

0000000000000000 <generic_fentry_setup_event>:
       0:      	pushq	%r15
       2:      	pushq	%r14
       4:      	pushq	%r12
       6:      	pushq	%rbx
       7:      	subq	$0x48, %rsp
       b:      	movq	%rdi, %rbx
       e:      	movl	$0x0, 0x24(%rsp)
      16:      	movq	(%rip), %rdi            # 0x1d <generic_fentry_setup_event+0x1d>
      1d:      	leaq	0x24(%rsp), %rsi
      22:      	movl	$0x1, %eax
      27:      	callq	*%rax
      29:      	testq	%rax, %rax
      2c:      	je	0x394 <generic_fentry_setup_event+0x394>
      32:      	movq	%rax, %r14
      35:      	leaq	0x5ef8(%rax), %rsi
      3c:      	movq	(%rip), %rdi            # 0x43 <generic_fentry_setup_event+0x43>
      43:      	movl	$0x1, %eax
      48:      	callq	*%rax
      4a:      	testq	%rax, %rax
      4d:      	je	0x394 <generic_fentry_setup_event+0x394>
      53:      	movq	%rax, %r15
      56:      	cmpl	$0x0, 0x54(%rax)
      5a:      	je	0x143 <generic_fentry_setup_event+0x143>
      60:      	leaq	0x8(%rsp), %rdi
      65:      	movl	$0x8, %ecx
      6a:      	movl	$0x4, %eax
      6f:      	movl	$0x8, %esi
      74:      	movq	%rbx, %rdx
      77:      	callq	*%rax
      79:      	movq	0x8(%rsp), %r12
      7e:      	testq	%r12, %r12
      81:      	je	0x394 <generic_fentry_setup_event+0x394>
      87:      	leaq	0x70(%r12), %rdx
      8c:      	leaq	0x8(%rsp), %rdi
      91:      	movl	$0x8, %ecx
      96:      	movl	$0x4, %eax
      9b:      	movl	$0x8, %esi
      a0:      	callq	*%rax
      a2:      	movq	0x8(%rsp), %rax
      a7:      	movq	%rax, 0x5e50(%r14)
      ae:      	leaq	0x68(%r12), %rdx
      b3:      	leaq	0x8(%rsp), %rdi
      b8:      	movl	$0x8, %ecx
      bd:      	movl	$0x4, %eax
      c2:      	movl	$0x8, %esi
      c7:      	callq	*%rax
      c9:      	movq	0x8(%rsp), %rax
      ce:      	movq	%rax, 0x5e58(%r14)
      d5:      	leaq	0x60(%r12), %rdx
      da:      	leaq	0x8(%rsp), %rdi
      df:      	movl	$0x8, %ecx
      e4:      	movl	$0x4, %eax
      e9:      	movl	$0x8, %esi
      ee:      	callq	*%rax
      f0:      	movq	0x8(%rsp), %rax
      f5:      	movq	%rax, 0x5e60(%r14)
      fc:      	leaq	0x38(%r12), %rdx
     101:      	leaq	0x8(%rsp), %rdi
     106:      	movl	$0x8, %ecx
     10b:      	movl	$0x4, %eax
     110:      	movl	$0x8, %esi
     115:      	callq	*%rax
     117:      	movq	0x8(%rsp), %rax
     11c:      	movq	%rax, 0x5e68(%r14)
     123:      	addq	$0x48, %r12
     127:      	leaq	0x8(%rsp), %rdi
     12c:      	movl	$0x8, %ecx
     131:      	movl	$0x4, %eax
     136:      	movl	$0x8, %esi
     13b:      	movq	%r12, %rdx
     13e:      	jmp	0x1f2 <generic_fentry_setup_event+0x1f2>
     143:      	leaq	0x8(%rsp), %rdi
     148:      	movl	$0x8, %ecx
     14d:      	movl	$0x4, %eax
     152:      	movl	$0x8, %esi
     157:      	movq	%rbx, %rdx
     15a:      	callq	*%rax
     15c:      	movq	0x8(%rsp), %rax
     161:      	movq	%rax, 0x5e50(%r14)
     168:      	leaq	0x8(%rbx), %rdx
     16c:      	leaq	0x8(%rsp), %rdi
     171:      	movl	$0x8, %ecx
     176:      	movl	$0x4, %eax
     17b:      	movl	$0x8, %esi
     180:      	callq	*%rax
     182:      	movq	0x8(%rsp), %rax
     187:      	movq	%rax, 0x5e58(%r14)
     18e:      	leaq	0x10(%rbx), %rdx
     192:      	leaq	0x8(%rsp), %rdi
     197:      	movl	$0x8, %ecx
     19c:      	movl	$0x4, %eax
     1a1:      	movl	$0x8, %esi
     1a6:      	callq	*%rax
     1a8:      	movq	0x8(%rsp), %rax
     1ad:      	movq	%rax, 0x5e60(%r14)
     1b4:      	leaq	0x18(%rbx), %rdx
     1b8:      	leaq	0x8(%rsp), %rdi
     1bd:      	movl	$0x8, %ecx
     1c2:      	movl	$0x4, %eax
     1c7:      	movl	$0x8, %esi
     1cc:      	callq	*%rax
     1ce:      	movq	0x8(%rsp), %rax
     1d3:      	movq	%rax, 0x5e68(%r14)
     1da:      	leaq	0x20(%rbx), %rdx
     1de:      	leaq	0x8(%rsp), %rdi
     1e3:      	movl	$0x8, %ecx
     1e8:      	movl	$0x4, %eax
     1ed:      	movl	$0x8, %esi
     1f2:      	callq	*%rax
     1f4:      	movq	0x8(%rsp), %rax
     1f9:      	movq	%rax, 0x5e70(%r14)
     200:      	movb	$0xd, (%r14)
     204:      	movw	$0x0, 0x2(%r14)
     20b:      	movl	$0x0, 0x4(%r14)
     213:      	movl	$0x7d, %eax
     218:      	callq	*%rax
     21a:      	movq	%rax, 0x8(%r14)
     21e:      	movq	$0x0, 0x70(%r14)
     226:      	movl	$0x0, 0x14(%r14)
     22e:      	movl	$0xe, %eax
     233:      	callq	*%rax
     235:      	movl	%eax, 0x7c(%r14)
     239:      	movl	$0xe, %eax
     23e:      	callq	*%rax
     240:      	cmpq	$-0x16, %rax
     244:      	jne	0x265 <generic_fentry_setup_event+0x265>
     246:      	leaq	0x20(%rbx), %rdx
     24a:      	leaq	0x8(%rsp), %rdi
     24f:      	movl	$0x8, %ecx
     254:      	movl	$0x4, %eax
     259:      	movl	$0x8, %esi
     25e:      	callq	*%rax
     260:      	movq	0x8(%rsp), %rax
     265:      	movq	%rax, 0x68(%r14)
     269:      	cmpl	$0x0, 0x5c(%r15)
     26e:      	jle	0x31b <generic_fentry_setup_event+0x31b>
     274:      	movq	0x8(%r14), %rcx
     278:      	movq	0x60(%r14), %rdx
     27c:      	movq	%rcx, 0x8(%rsp)
     281:      	movq	$0x1, 0x10(%rsp)
     28a:      	movq	$0x0, 0x18(%rsp)
     293:      	movq	%rdx, 0x38(%rsp)
     298:      	movq	%rax, 0x40(%rsp)
     29d:      	movq	(%rip), %rdi            # 0x2a4 <generic_fentry_setup_event+0x2a4>
     2a4:      	xorl	%ecx, %ecx
     2a6:      	leaq	0x38(%rsp), %rsi
     2ab:      	leaq	0x8(%rsp), %rdx
     2b0:      	movl	$0x2, %eax
     2b5:      	xorl	%ecx, %ecx
     2b7:      	callq	*%rax
     2b9:      	testq	%rax, %rax
     2bc:      	je	0x31b <generic_fentry_setup_event+0x31b>
     2be:      	negl	%eax
     2c0:      	movw	%ax, 0x2c(%rsp)
     2c5:      	movw	$0x5, 0x2e(%rsp)
     2cc:      	movabsq	$0x200000046, %rax      # imm = 0x200000046
     2d6:      	movq	%rax, 0x30(%rsp)
     2db:      	movq	(%rip), %rdi            # 0x2e2 <generic_fentry_setup_event+0x2e2>
     2e2:      	leaq	0x2c(%rsp), %rsi
     2e7:      	movl	$0x1, %eax
     2ec:      	callq	*%rax
     2ee:      	testq	%rax, %rax
     2f1:      	je	0x2f7 <generic_fentry_setup_event+0x2f7>
     2f3:      	incl	(%rax)
     2f5:      	jmp	0x31b <generic_fentry_setup_event+0x31b>
     2f7:      	movl	$0x1, 0x28(%rsp)
     2ff:      	movq	(%rip), %rdi            # 0x306 <generic_fentry_setup_event+0x306>
     306:      	xorl	%ecx, %ecx
     308:      	leaq	0x2c(%rsp), %rsi
     30d:      	leaq	0x28(%rsp), %rdx
     312:      	movl	$0x2, %eax
     317:      	xorl	%ecx, %ecx
     319:      	callq	*%rax
     31b:      	movl	$0x0, 0x8(%rsp)
     323:      	movq	(%rip), %rdi            # 0x32a <generic_fentry_setup_event+0x32a>
     32a:      	leaq	0x8(%rsp), %rsi
     32f:      	movl	$0x1, %eax
     334:      	callq	*%rax
     336:      	testq	%rax, %rax
     339:      	je	0x35e <generic_fentry_setup_event+0x35e>
     33b:      	movq	%rax, %rsi
     33e:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     345:      	movq	(%rip), %rdi            # 0x34c <generic_fentry_setup_event+0x34c>
     34c:      	movl	$0x1, %eax
     351:      	callq	*%rax
     353:      	testq	%rax, %rax
     356:      	je	0x35e <generic_fentry_setup_event+0x35e>
     358:      	cmpl	$-0x1, 0x40(%rax)
     35c:      	jne	0x379 <generic_fentry_setup_event+0x379>
     35e:      	movq	(%rip), %rsi            # 0x365 <generic_fentry_setup_event+0x365>
     365:      	movl	$0x3, %ecx
     36a:      	movl	$0xc, %eax
     36f:      	movq	%rbx, %rdi
     372:      	movl	$0x3, %edx
     377:      	callq	*%rax
     379:      	movq	(%rip), %rsi            # 0x380 <generic_fentry_setup_event+0x380>
     380:      	movl	$0x1, %ecx
     385:      	movl	$0xc, %eax
     38a:      	movq	%rbx, %rdi
     38d:      	movl	$0x1, %edx
     392:      	callq	*%rax
     394:      	xorl	%eax, %eax
     396:      	addq	$0x48, %rsp
     39a:      	popq	%rbx
     39b:      	popq	%r12
     39d:      	popq	%r14
     39f:      	popq	%r15
     3a1:      	retq
     3a2:      	nopw	%cs:(%rax,%rax)

00000000000003b0 <generic_fentry_process_event>:
     3b0:      	pushq	%rbp
     3b1:      	pushq	%r15
     3b3:      	pushq	%r14
     3b5:      	pushq	%r13
     3b7:      	pushq	%r12
     3b9:      	pushq	%rbx
     3ba:      	subq	$0x108, %rsp            # imm = 0x108
     3c1:      	movq	%rdi, %rbx
     3c4:      	movl	$0x0, 0xf4(%rsp)
     3cf:      	movq	(%rip), %rdi            # 0x3d6 <generic_fentry_process_event+0x26>
     3d6:      	leaq	0xf4(%rsp), %rsi
     3de:      	movl	$0x1, %eax
     3e3:      	callq	*%rax
     3e5:      	testq	%rax, %rax
     3e8:      	je	0xbec <generic_fentry_process_event+0x83c>
     3ee:      	movq	%rax, %r14
     3f1:      	movl	0x5efc(%rax), %r12d
     3f8:      	movl	0x4(%rax), %r13d
     3fc:      	cmpq	$0x2327, %r13           # imm = 0x2327
     403:      	ja	0xb4d <generic_fentry_process_event+0x79d>
     409:      	movl	$0x0, 0xf8(%rsp)
     414:      	movq	(%rip), %rdi            # 0x41b <generic_fentry_process_event+0x6b>
     41b:      	leaq	0xf8(%rsp), %rsi
     423:      	movl	$0x1, %eax
     428:      	callq	*%rax
     42a:      	testq	%rax, %rax
     42d:      	je	0xb4d <generic_fentry_process_event+0x79d>
     433:      	movq	%rax, %r15
     436:      	leaq	0x5ef8(%rax), %rsi
     43d:      	movq	(%rip), %rdi            # 0x444 <generic_fentry_process_event+0x94>
     444:      	movl	$0x1, %eax
     449:      	callq	*%rax
     44b:      	cmpl	$0x4, %r12d
     44f:      	jg	0xb4d <generic_fentry_process_event+0x79d>
     455:      	testq	%rax, %rax
     458:      	je	0xb4d <generic_fentry_process_event+0x79d>
     45e:      	movq	%r13, 0xb8(%rsp)
     466:      	movq	%r12, 0x100(%rsp)
     46e:      	movl	%r12d, %edx
     471:      	andl	$0x7, %edx
     474:      	movl	%edx, %ecx
     476:      	movl	0x4(%rax,%rcx,4), %r13d
     47b:      	movslq	0x18(%rax,%rcx,4), %r12
     480:      	movl	%r12d, %esi
     483:      	movl	$0x0, 0x5ea0(%r15,%rcx,4)
     48f:      	testl	$0x100, %r12d           # imm = 0x100
     496:      	movq	%rdx, 0x20(%rsp)
     49b:      	jne	0x4b9 <generic_fentry_process_event+0x109>
     49d:      	testb	%r12b, %r12b
     4a0:      	js	0x4c7 <generic_fentry_process_event+0x117>
     4a2:      	testb	$0x40, %sil
     4a6:      	jne	0x4d4 <generic_fentry_process_event+0x124>
     4a8:      	movl	0x40(%rax,%rdx,4), %ecx
     4ac:      	andl	$0x7, %ecx
     4af:      	movq	0x5e50(%r15,%rcx,8), %rcx
     4b7:      	jmp	0x505 <generic_fentry_process_event+0x155>
     4b9:      	movq	$0x0, 0x10(%rsp)
     4c2:      	jmp	0x8ba <generic_fentry_process_event+0x50a>
     4c7:      	movq	$0x0, 0x10(%rsp)
     4d0:      	xorl	%ecx, %ecx
     4d2:      	jmp	0x50a <generic_fentry_process_event+0x15a>
     4d4:      	movq	%rax, 0x18(%rsp)
     4d9:      	movl	$0x23, %eax
     4de:      	movq	%r14, %rbp
     4e1:      	movq	%r13, %r14
     4e4:      	movq	%r12, %r13
     4e7:      	movq	%rsi, %r12
     4ea:      	callq	*%rax
     4ec:      	movq	%r12, %rsi
     4ef:      	movq	%r13, %r12
     4f2:      	movq	%r14, %r13
     4f5:      	movq	%rbp, %r14
     4f8:      	movq	0x20(%rsp), %rdx
     4fd:      	movq	%rax, %rcx
     500:      	movq	0x18(%rsp), %rax
     505:      	movq	%rcx, 0x10(%rsp)
     50a:      	cmpl	$0x4, %edx
     50d:      	ja	0x8ba <generic_fentry_process_event+0x50a>
     513:      	leaq	(%rdx,%rdx,4), %rdx
     517:      	shll	$0x4, %edx
     51a:      	cmpw	$0x0, 0x76(%rax,%rdx)
     520:      	je	0x8ba <generic_fentry_process_event+0x50a>
     526:      	addq	%rax, %rdx
     529:      	addq	$0x70, %rdx
     52d:      	movl	(%rdx), %eax
     52f:      	addq	%rax, %rcx
     532:      	movq	%rcx, 0x10(%rsp)
     537:      	cmpw	$0x0, 0x4(%rdx)
     53c:      	movq	%r12, 0x30(%rsp)
     541:      	je	0x581 <generic_fentry_process_event+0x1d1>
     543:      	leaq	0x10(%rsp), %rdi
     548:      	movq	%rdx, %r12
     54b:      	movl	$0x8, %edx
     550:      	movl	$0x4, %eax
     555:      	movq	0x10(%rsp), %rdx
     55a:      	movq	%rsi, %rbp
     55d:      	movl	$0x8, %esi
     562:      	callq	*%rax
     564:      	movq	%r12, %rdx
     567:      	movq	0x30(%rsp), %r12
     56c:      	movq	%rbp, %rsi
     56f:      	movq	0x20(%rsp), %rcx
     574:      	movl	$0x1, %ebp
     579:      	testl	%eax, %eax
     57b:      	js	0x8b2 <generic_fentry_process_event+0x502>
     581:      	cmpw	$0x0, 0xe(%rdx)
     586:      	je	0x8ba <generic_fentry_process_event+0x50a>
     58c:      	movl	0x8(%rdx), %ecx
     58f:      	addq	0x10(%rsp), %rcx
     594:      	movq	%rcx, 0x10(%rsp)
     599:      	cmpw	$0x0, 0xc(%rdx)
     59e:      	je	0x5de <generic_fentry_process_event+0x22e>
     5a0:      	leaq	0x10(%rsp), %rdi
     5a5:      	movq	%rdx, %r12
     5a8:      	movl	$0x8, %edx
     5ad:      	movl	$0x4, %eax
     5b2:      	movq	0x10(%rsp), %rdx
     5b7:      	movq	%rsi, %rbp
     5ba:      	movl	$0x8, %esi
     5bf:      	callq	*%rax
     5c1:      	movq	%r12, %rdx
     5c4:      	movq	0x30(%rsp), %r12
     5c9:      	movq	%rbp, %rsi
     5cc:      	movq	0x20(%rsp), %rcx
     5d1:      	movl	$0x2, %ebp
     5d6:      	testl	%eax, %eax
     5d8:      	js	0x8b2 <generic_fentry_process_event+0x502>
     5de:      	cmpw	$0x0, 0x16(%rdx)
     5e3:      	je	0x8ba <generic_fentry_process_event+0x50a>
     5e9:      	movl	0x10(%rdx), %ecx
     5ec:      	addq	0x10(%rsp), %rcx
     5f1:      	movq	%rcx, 0x10(%rsp)
     5f6:      	cmpw	$0x0, 0x14(%rdx)
     5fb:      	je	0x63b <generic_fentry_process_event+0x28b>
     5fd:      	leaq	0x10(%rsp), %rdi
     602:      	movq	%rdx, %r12
     605:      	movl	$0x8, %edx
     60a:      	movl	$0x4, %eax
     60f:      	movq	0x10(%rsp), %rdx
     614:      	movq	%rsi, %rbp
     617:      	movl	$0x8, %esi
     61c:      	callq	*%rax
     61e:      	movq	%r12, %rdx
     621:      	movq	0x30(%rsp), %r12
     626:      	movq	%rbp, %rsi
     629:      	movq	0x20(%rsp), %rcx
     62e:      	movl	$0x3, %ebp
     633:      	testl	%eax, %eax
     635:      	js	0x8b2 <generic_fentry_process_event+0x502>
     63b:      	cmpw	$0x0, 0x1e(%rdx)
     640:      	je	0x8ba <generic_fentry_process_event+0x50a>
     646:      	movl	0x18(%rdx), %ecx
     649:      	addq	0x10(%rsp), %rcx
     64e:      	movq	%rcx, 0x10(%rsp)
     653:      	cmpw	$0x0, 0x1c(%rdx)
     658:      	je	0x698 <generic_fentry_process_event+0x2e8>
     65a:      	leaq	0x10(%rsp), %rdi
     65f:      	movq	%rdx, %r12
     662:      	movl	$0x8, %edx
     667:      	movl	$0x4, %eax
     66c:      	movq	0x10(%rsp), %rdx
     671:      	movq	%rsi, %rbp
     674:      	movl	$0x8, %esi
     679:      	callq	*%rax
     67b:      	movq	%r12, %rdx
     67e:      	movq	0x30(%rsp), %r12
     683:      	movq	%rbp, %rsi
     686:      	movq	0x20(%rsp), %rcx
     68b:      	movl	$0x4, %ebp
     690:      	testl	%eax, %eax
     692:      	js	0x8b2 <generic_fentry_process_event+0x502>
     698:      	cmpw	$0x0, 0x26(%rdx)
     69d:      	je	0x8ba <generic_fentry_process_event+0x50a>
     6a3:      	movl	0x20(%rdx), %ecx
     6a6:      	addq	0x10(%rsp), %rcx
     6ab:      	movq	%rcx, 0x10(%rsp)
     6b0:      	cmpw	$0x0, 0x24(%rdx)
     6b5:      	je	0x6f5 <generic_fentry_process_event+0x345>
     6b7:      	leaq	0x10(%rsp), %rdi
     6bc:      	movq	%rdx, %r12
     6bf:      	movl	$0x8, %edx
     6c4:      	movl	$0x4, %eax
     6c9:      	movq	0x10(%rsp), %rdx
     6ce:      	movq	%rsi, %rbp
     6d1:      	movl	$0x8, %esi
     6d6:      	callq	*%rax
     6d8:      	movq	%r12, %rdx
     6db:      	movq	0x30(%rsp), %r12
     6e0:      	movq	%rbp, %rsi
     6e3:      	movq	0x20(%rsp), %rcx
     6e8:      	movl	$0x5, %ebp
     6ed:      	testl	%eax, %eax
     6ef:      	js	0x8b2 <generic_fentry_process_event+0x502>
     6f5:      	cmpw	$0x0, 0x2e(%rdx)
     6fa:      	je	0x8ba <generic_fentry_process_event+0x50a>
     700:      	movl	0x28(%rdx), %ecx
     703:      	addq	0x10(%rsp), %rcx
     708:      	movq	%rcx, 0x10(%rsp)
     70d:      	cmpw	$0x0, 0x2c(%rdx)
     712:      	je	0x752 <generic_fentry_process_event+0x3a2>
     714:      	leaq	0x10(%rsp), %rdi
     719:      	movq	%rdx, %r12
     71c:      	movl	$0x8, %edx
     721:      	movl	$0x4, %eax
     726:      	movq	0x10(%rsp), %rdx
     72b:      	movq	%rsi, %rbp
     72e:      	movl	$0x8, %esi
     733:      	callq	*%rax
     735:      	movq	%r12, %rdx
     738:      	movq	0x30(%rsp), %r12
     73d:      	movq	%rbp, %rsi
     740:      	movq	0x20(%rsp), %rcx
     745:      	movl	$0x6, %ebp
     74a:      	testl	%eax, %eax
     74c:      	js	0x8b2 <generic_fentry_process_event+0x502>
     752:      	cmpw	$0x0, 0x36(%rdx)
     757:      	je	0x8ba <generic_fentry_process_event+0x50a>
     75d:      	movl	0x30(%rdx), %ecx
     760:      	addq	0x10(%rsp), %rcx
     765:      	movq	%rcx, 0x10(%rsp)
     76a:      	cmpw	$0x0, 0x34(%rdx)
     76f:      	je	0x7af <generic_fentry_process_event+0x3ff>
     771:      	leaq	0x10(%rsp), %rdi
     776:      	movq	%rdx, %r12
     779:      	movl	$0x8, %edx
     77e:      	movl	$0x4, %eax
     783:      	movq	0x10(%rsp), %rdx
     788:      	movq	%rsi, %rbp
     78b:      	movl	$0x8, %esi
     790:      	callq	*%rax
     792:      	movq	%r12, %rdx
     795:      	movq	0x30(%rsp), %r12
     79a:      	movq	%rbp, %rsi
     79d:      	movq	0x20(%rsp), %rcx
     7a2:      	movl	$0x7, %ebp
     7a7:      	testl	%eax, %eax
     7a9:      	js	0x8b2 <generic_fentry_process_event+0x502>
     7af:      	cmpw	$0x0, 0x3e(%rdx)
     7b4:      	je	0x8ba <generic_fentry_process_event+0x50a>
     7ba:      	movl	0x38(%rdx), %ecx
     7bd:      	addq	0x10(%rsp), %rcx
     7c2:      	movq	%rcx, 0x10(%rsp)
     7c7:      	cmpw	$0x0, 0x3c(%rdx)
     7cc:      	je	0x80f <generic_fentry_process_event+0x45f>
     7ce:      	leaq	0x10(%rsp), %rdi
     7d3:      	movq	%rdx, 0x18(%rsp)
     7d8:      	movl	$0x8, %edx
     7dd:      	movl	$0x4, %eax
     7e2:      	movq	0x10(%rsp), %rdx
     7e7:      	movl	$0x8, %ebp
     7ec:      	movq	%rsi, 0x58(%rsp)
     7f1:      	movl	$0x8, %esi
     7f6:      	callq	*%rax
     7f8:      	movq	0x18(%rsp), %rdx
     7fd:      	movq	0x58(%rsp), %rsi
     802:      	movq	0x20(%rsp), %rcx
     807:      	testl	%eax, %eax
     809:      	js	0x8b2 <generic_fentry_process_event+0x502>
     80f:      	cmpw	$0x0, 0x46(%rdx)
     814:      	je	0x8ba <generic_fentry_process_event+0x50a>
     81a:      	movl	0x40(%rdx), %ecx
     81d:      	addq	0x10(%rsp), %rcx
     822:      	movq	%rcx, 0x10(%rsp)
     827:      	cmpw	$0x0, 0x44(%rdx)
     82c:      	je	0x868 <generic_fentry_process_event+0x4b8>
     82e:      	leaq	0x10(%rsp), %rdi
     833:      	movq	%rdx, %r12
     836:      	movl	$0x8, %edx
     83b:      	movl	$0x4, %eax
     840:      	movq	0x10(%rsp), %rdx
     845:      	movq	%rsi, %rbp
     848:      	movl	$0x8, %esi
     84d:      	callq	*%rax
     84f:      	movq	%r12, %rdx
     852:      	movq	0x30(%rsp), %r12
     857:      	movq	%rbp, %rsi
     85a:      	movq	0x20(%rsp), %rcx
     85f:      	movl	$0x9, %ebp
     864:      	testl	%eax, %eax
     866:      	js	0x8b2 <generic_fentry_process_event+0x502>
     868:      	cmpw	$0x0, 0x4e(%rdx)
     86d:      	je	0x8ba <generic_fentry_process_event+0x50a>
     86f:      	movl	0x48(%rdx), %ecx
     872:      	addq	0x10(%rsp), %rcx
     877:      	movq	%rcx, 0x10(%rsp)
     87c:      	cmpw	$0x0, 0x4c(%rdx)
     881:      	je	0x8ba <generic_fentry_process_event+0x50a>
     883:      	leaq	0x10(%rsp), %rdi
     888:      	movl	$0x8, %edx
     88d:      	movl	$0x4, %eax
     892:      	movq	0x10(%rsp), %rdx
     897:      	movq	%rsi, %rbp
     89a:      	movl	$0x8, %esi
     89f:      	callq	*%rax
     8a1:      	movq	%rbp, %rsi
     8a4:      	movq	0x20(%rsp), %rcx
     8a9:      	movl	$0xa, %ebp
     8ae:      	testl	%eax, %eax
     8b0:      	jns	0x8ba <generic_fentry_process_event+0x50a>
     8b2:      	movl	%ebp, 0x5ea0(%r15,%rcx,4)
     8ba:      	movl	%r13d, %ebp
     8bd:      	cmpl	$0x2a, %r13d
     8c1:      	ja	0xab7 <generic_fentry_process_event+0x707>
     8c7:      	movabsq	$0x42001018000, %rax    # imm = 0x42001018000
     8d1:      	btq	%rbp, %rax
     8d5:      	jae	0xab7 <generic_fentry_process_event+0x707>
     8db:      	movq	0x10(%rsp), %rbp
     8e0:      	movl	$0x0, 0x50(%rsp)
     8e8:      	movq	(%rip), %rdi            # 0x8ef <generic_fentry_process_event+0x53f>
     8ef:      	leaq	0x50(%rsp), %rsi
     8f4:      	movl	$0x1, %eax
     8f9:      	callq	*%rax
     8fb:      	testq	%rax, %rax
     8fe:      	je	0xb35 <generic_fentry_process_event+0x785>
     904:      	movq	%rax, %r12
     907:      	cmpl	$0x0, 0x6420(%rax)
     90e:      	je	0xa5f <generic_fentry_process_event+0x6af>
     914:      	movl	$0x0, 0x6420(%r12)
     920:      	movq	(%rip), %rdi            # 0x927 <generic_fentry_process_event+0x577>
     927:      	leaq	0x50(%rsp), %rsi
     92c:      	movl	$0x1, %eax
     931:      	callq	*%rax
     933:      	testq	%rax, %rax
     936:      	je	0xb35 <generic_fentry_process_event+0x785>
     93c:      	movq	%rax, %rdx
     93f:      	movq	0x20(%rsp), %rcx
     944:      	movl	0x5ea0(%r12,%rcx,4), %eax
     94c:      	movq	0xb8(%rsp), %r13
     954:      	movl	%eax, 0x90(%r12,%r13)
     95c:      	movq	%r13, %rbp
     95f:      	addq	$0x4, %rbp
     963:      	movq	%rbp, 0x5e78(%r12,%rcx,8)
     96b:      	movl	$0x4, %esi
     970:      	testl	%eax, %eax
     972:      	jne	0xb3f <generic_fentry_process_event+0x78f>
     978:      	movq	%r12, %r15
     97b:      	addq	$0x90, %r15
     982:      	movl	0x6424(%r12), %eax
     98a:      	movq	%rbx, 0x8(%rsp)
     98f:      	movl	$0xfff, %ebx            # imm = 0xFFF
     994:      	subl	%eax, %ebx
     996:      	andl	$0xfff, %eax            # imm = 0xFFF
     99b:      	addq	%rax, %rdx
     99e:      	movq	0x6440(%r12), %r13
     9a6:      	leaq	(%r15,%rbp), %rdi
     9aa:      	addq	$0x4, %rdi
     9ae:      	andl	$0xfff, %ebx            # imm = 0xFFF
     9b4:      	movl	$0x4, %eax
     9b9:      	addq	%rbp, %r15
     9bc:      	movl	%ebx, %esi
     9be:      	callq	*%rax
     9c0:      	movl	%ebx, 0x90(%r12,%rbp)
     9c8:      	addq	$0x8, %r13
     9cc:      	leaq	0x78(%rsp), %rdi
     9d1:      	movl	$0x8, %ecx
     9d6:      	movl	$0x4, %eax
     9db:      	movl	$0x8, %esi
     9e0:      	movq	%r13, %rdx
     9e3:      	movq	0xb8(%rsp), %r13
     9eb:      	callq	*%rax
     9ed:      	movq	0x78(%rsp), %rcx
     9f2:      	addq	$0x30, %rcx
     9f6:      	leaq	0x68(%rsp), %rdi
     9fb:      	movl	$0x8, %edx
     a00:      	movl	$0x4, %eax
     a05:      	movq	0x78(%rsp), %rdx
     a0a:      	addq	$0x30, %rdx
     a0e:      	movl	$0x8, %esi
     a13:      	callq	*%rax
     a15:      	movq	0x68(%rsp), %rcx
     a1a:      	leaq	0xc0(%rsp), %rdi
     a22:      	movl	$0x2, %edx
     a27:      	movl	$0x4, %eax
     a2c:      	movq	0x68(%rsp), %rdx
     a31:      	movl	$0x2, %esi
     a36:      	callq	*%rax
     a38:      	movq	%rbx, %rsi
     a3b:      	movq	0x8(%rsp), %rbx
     a40:      	movl	$0x0, 0x4(%rsi,%r15)
     a49:      	movzwl	0xc0(%rsp), %eax
     a51:      	movw	%ax, 0x8(%rsi,%r15)
     a57:      	addl	$0xe, %esi
     a5a:      	jmp	0xb3f <generic_fentry_process_event+0x78f>
     a5f:      	movq	%rbp, 0x78(%rsp)
     a64:      	movq	$0x0, 0x68(%rsp)
     a6d:      	cmpl	$0x17, %r13d
     a71:      	jle	0xb18 <generic_fentry_process_event+0x768>
     a77:      	cmpl	$0x18, %r13d
     a7b:      	je	0xc7f <generic_fentry_process_event+0x8cf>
     a81:      	cmpl	$0x25, %r13d
     a85:      	je	0xce1 <generic_fentry_process_event+0x931>
     a8b:      	cmpl	$0x2a, %r13d
     a8f:      	jne	0xb35 <generic_fentry_process_event+0x785>
     a95:      	movq	%r12, %rax
     a98:      	addq	$0x6430, %rax           # imm = 0x6430
     a9e:      	movq	$0x0, 0x6430(%r12)
     aaa:      	movq	%rbp, 0x6438(%r12)
     ab2:      	jmp	0xd14 <generic_fentry_process_event+0x964>
     ab7:      	movq	0x10(%rsp), %rax
     abc:      	movq	%rax, 0x18(%rsp)
     ac1:      	cmpl	$0x15, %r13d
     ac5:      	jg	0xc00 <generic_fentry_process_event+0x850>
     acb:      	movl	$0x1fe, %r15d           # imm = 0x1FE
     ad1:      	cmpl	$0x9, %r13d
     ad5:      	jle	0xc4f <generic_fentry_process_event+0x89f>
     adb:      	cmpl	$0x10, %r13d
     adf:      	jle	0xd79 <generic_fentry_process_event+0x9c9>
     ae5:      	cmpl	$0x12, %r13d
     ae9:      	jle	0xdea <generic_fentry_process_event+0xa3a>
     aef:      	cmpl	$0x13, %r13d
     af3:      	je	0xe07 <generic_fentry_process_event+0xa57>
     af9:      	cmpl	$0x14, %r13d
     afd:      	je	0xe2b <generic_fentry_process_event+0xa7b>
     b03:      	cmpl	$0x15, %r13d
     b07:      	jne	0xe39 <generic_fentry_process_event+0xa89>
     b0d:      	movl	$0x20, %r15d
     b13:      	jmp	0xe3c <generic_fentry_process_event+0xa8c>
     b18:      	cmpl	$0xf, %r13d
     b1c:      	je	0xd1e <generic_fentry_process_event+0x96e>
     b22:      	cmpl	$0x10, %r13d
     b26:      	jne	0xb35 <generic_fentry_process_event+0x785>
     b28:      	leaq	0xc0(%rsp), %r15
     b30:      	jmp	0xcad <generic_fentry_process_event+0x8fd>
     b35:      	xorl	%esi, %esi
     b37:      	movq	0xb8(%rsp), %r13
     b3f:      	addl	%r13d, %esi
     b42:      	movl	%esi, %r13d
     b45:      	movq	0x100(%rsp), %r12
     b4d:      	movl	%r13d, 0x4(%r14)
     b51:      	cmpl	$0x3, %r12d
     b55:      	jg	0xbc6 <generic_fentry_process_event+0x816>
     b57:      	movl	$0x0, 0x78(%rsp)
     b5f:      	movq	(%rip), %rdi            # 0xb66 <generic_fentry_process_event+0x7b6>
     b66:      	leaq	0x78(%rsp), %rsi
     b6b:      	movl	$0x1, %eax
     b70:      	callq	*%rax
     b72:      	testq	%rax, %rax
     b75:      	je	0xbc6 <generic_fentry_process_event+0x816>
     b77:      	movq	%rax, %rsi
     b7a:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     b81:      	movq	(%rip), %rdi            # 0xb88 <generic_fentry_process_event+0x7d8>
     b88:      	movl	$0x1, %eax
     b8d:      	callq	*%rax
     b8f:      	testq	%rax, %rax
     b92:      	je	0xbc6 <generic_fentry_process_event+0x816>
     b94:      	incl	%r12d
     b97:      	movl	%r12d, %ecx
     b9a:      	andl	$0x7, %ecx
     b9d:      	cmpl	$-0x1, 0x40(%rax,%rcx,4)
     ba2:      	je	0xbc6 <generic_fentry_process_event+0x816>
     ba4:      	movl	%r12d, 0x5efc(%r14)
     bab:      	movq	(%rip), %rsi            # 0xbb2 <generic_fentry_process_event+0x802>
     bb2:      	movl	$0x1, %ecx
     bb7:      	movl	$0xc, %eax
     bbc:      	movq	%rbx, %rdi
     bbf:      	movl	$0x1, %edx
     bc4:      	callq	*%rax
     bc6:      	movl	$0x0, 0x5efc(%r14)
     bd1:      	movq	(%rip), %rsi            # 0xbd8 <generic_fentry_process_event+0x828>
     bd8:      	movl	$0x3, %ecx
     bdd:      	movl	$0xc, %eax
     be2:      	movq	%rbx, %rdi
     be5:      	movl	$0x3, %edx
     bea:      	callq	*%rax
     bec:      	xorl	%eax, %eax
     bee:      	addq	$0x108, %rsp            # imm = 0x108
     bf5:      	popq	%rbx
     bf6:      	popq	%r12
     bf8:      	popq	%r13
     bfa:      	popq	%r14
     bfc:      	popq	%r15
     bfe:      	popq	%rbp
     bff:      	retq
     c00:      	cmpl	$0x20, %r13d
     c04:      	jg	0xc33 <generic_fentry_process_event+0x883>
     c06:      	cmpl	$0x1a, %r13d
     c0a:      	jg	0xd9b <generic_fentry_process_event+0x9eb>
     c10:      	cmpl	$0x16, %r13d
     c14:      	je	0xde2 <generic_fentry_process_event+0xa32>
     c1a:      	cmpl	$0x17, %r13d
     c1e:      	je	0xd90 <generic_fentry_process_event+0x9e0>
     c24:      	cmpl	$0x1a, %r13d
     c28:      	je	0xe1b <generic_fentry_process_event+0xa6b>
     c2e:      	jmp	0xe39 <generic_fentry_process_event+0xa89>
     c33:      	cmpl	$0x26, %r13d
     c37:      	jg	0xdb3 <generic_fentry_process_event+0xa03>
     c3d:      	leal	-0x21(%r13), %eax
     c41:      	cmpl	$0x4, %eax
     c44:      	jb	0xd90 <generic_fentry_process_event+0x9e0>
     c4a:      	jmp	0xe39 <generic_fentry_process_event+0xa89>
     c4f:      	cmpl	$0x4, %r13d
     c53:      	jg	0xdc7 <generic_fentry_process_event+0xa17>
     c59:      	leal	-0x2(%r13), %eax
     c5d:      	cmpl	$0x2, %eax
     c60:      	jb	0xda8 <generic_fentry_process_event+0x9f8>
     c66:      	cmpl	$0x1, %r13d
     c6a:      	je	0xda8 <generic_fentry_process_event+0x9f8>
     c70:      	cmpl	$0x4, %r13d
     c74:      	je	0xd90 <generic_fentry_process_event+0x9e0>
     c7a:      	jmp	0xe39 <generic_fentry_process_event+0xa89>
     c7f:      	leaq	0xc0(%rsp), %r15
     c87:      	movl	$0x8, %ecx
     c8c:      	movl	$0x4, %eax
     c91:      	movq	0x78(%rsp), %rdx
     c96:      	movq	%r15, %rdi
     c99:      	movl	$0x8, %esi
     c9e:      	callq	*%rax
     ca0:      	movq	0xc0(%rsp), %rax
     ca8:      	movq	%rax, 0x78(%rsp)
     cad:      	movq	0xb8(%rsp), %r13
     cb5:      	leaq	0x78(%rsp), %rdx
     cba:      	movl	$0x8, %ecx
     cbf:      	movl	$0x4, %eax
     cc4:      	leaq	0xc0(%rsp), %rdi
     ccc:      	movl	$0x8, %esi
     cd1:      	callq	*%rax
     cd3:      	movq	0xc0(%rsp), %rax
     cdb:      	addq	$0x40, %rax
     cdf:      	jmp	0xd4f <generic_fentry_process_event+0x99f>
     ce1:      	addq	$0x40, %rbp
     ce5:      	movq	%rbp, 0x78(%rsp)
     cea:      	leaq	0xc0(%rsp), %rdi
     cf2:      	movl	$0x8, %ecx
     cf7:      	movl	$0x4, %eax
     cfc:      	movq	0x78(%rsp), %rdx
     d01:      	movl	$0x8, %esi
     d06:      	callq	*%rax
     d08:      	movq	0xc0(%rsp), %rax
     d10:      	addq	$0x40, %rax
     d14:      	movq	0xb8(%rsp), %r13
     d1c:      	jmp	0xd4f <generic_fentry_process_event+0x99f>
     d1e:      	leaq	0x68(%rsp), %rdi
     d23:      	leaq	0x78(%rsp), %rdx
     d28:      	movl	$0x8, %ecx
     d2d:      	movl	$0x4, %eax
     d32:      	movl	$0x8, %esi
     d37:      	callq	*%rax
     d39:      	movq	0x68(%rsp), %rax
     d3e:      	testq	%rax, %rax
     d41:      	movq	0xb8(%rsp), %r13
     d49:      	je	0xddb <generic_fentry_process_event+0xa2b>
     d4f:      	movq	%rax, 0x6440(%r12)
     d57:      	movq	(%rip), %rsi            # 0xd5e <generic_fentry_process_event+0x9ae>
     d5e:      	movl	$0x6, %ecx
     d63:      	movl	$0xc, %eax
     d68:      	movq	%rbx, %rdi
     d6b:      	movl	$0x6, %edx
     d70:      	callq	*%rax
     d72:      	xorl	%esi, %esi
     d74:      	jmp	0xb3f <generic_fentry_process_event+0x78f>
     d79:      	leal	-0xa(%r13), %eax
     d7d:      	cmpl	$0x2, %eax
     d80:      	jb	0xd90 <generic_fentry_process_event+0x9e0>
     d82:      	leal	-0xc(%r13), %eax
     d86:      	cmpl	$0x2, %eax
     d89:      	jb	0xda8 <generic_fentry_process_event+0x9f8>
     d8b:      	jmp	0xe39 <generic_fentry_process_event+0xa89>
     d90:      	movl	$0x8, %r15d
     d96:      	jmp	0xe3c <generic_fentry_process_event+0xa8c>
     d9b:      	leal	-0x1d(%r13), %eax
     d9f:      	cmpl	$0x4, %eax
     da2:      	jae	0xe33 <generic_fentry_process_event+0xa83>
     da8:      	movl	$0x4, %r15d
     dae:      	jmp	0xe3c <generic_fentry_process_event+0xa8c>
     db3:      	cmpl	$0x28, %r13d
     db7:      	jg	0xdfb <generic_fentry_process_event+0xa4b>
     db9:      	cmpl	$0x27, %r13d
     dbd:      	je	0xde2 <generic_fentry_process_event+0xa32>
     dbf:      	cmpl	$0x28, %r13d
     dc3:      	je	0xe07 <generic_fentry_process_event+0xa57>
     dc5:      	jmp	0xe39 <generic_fentry_process_event+0xa89>
     dc7:      	cmpl	$0x6, %r13d
     dcb:      	jg	0xe0f <generic_fentry_process_event+0xa5f>
     dcd:      	cmpl	$0x5, %r13d
     dd1:      	je	0xe23 <generic_fentry_process_event+0xa73>
     dd3:      	cmpl	$0x6, %r13d
     dd7:      	je	0xe3c <generic_fentry_process_event+0xa8c>
     dd9:      	jmp	0xe39 <generic_fentry_process_event+0xa89>
     ddb:      	xorl	%esi, %esi
     ddd:      	jmp	0xb3f <generic_fentry_process_event+0x78f>
     de2:      	movl	$0x10, %r15d
     de8:      	jmp	0xe3c <generic_fentry_process_event+0xa8c>
     dea:      	cmpl	$0x11, %r13d
     dee:      	je	0xe3c <generic_fentry_process_event+0xa8c>
     df0:      	movq	%r12, %r15
     df3:      	cmpl	$0x12, %r13d
     df7:      	je	0xe3c <generic_fentry_process_event+0xa8c>
     df9:      	jmp	0xe39 <generic_fentry_process_event+0xa89>
     dfb:      	cmpl	$0x29, %r13d
     dff:      	je	0xe23 <generic_fentry_process_event+0xa73>
     e01:      	cmpl	$0x2b, %r13d
     e05:      	jne	0xe39 <generic_fentry_process_event+0xa89>
     e07:      	movl	$0x18, %r15d
     e0d:      	jmp	0xe3c <generic_fentry_process_event+0xa8c>
     e0f:      	cmpl	$0x7, %r13d
     e13:      	je	0xe23 <generic_fentry_process_event+0xa73>
     e15:      	cmpl	$0x8, %r13d
     e19:      	jne	0xe39 <generic_fentry_process_event+0xa89>
     e1b:      	movl	$0x50, %r15d
     e21:      	jmp	0xe3c <generic_fentry_process_event+0xa8c>
     e23:      	movl	$0x40, %r15d
     e29:      	jmp	0xe3c <generic_fentry_process_event+0xa8c>
     e2b:      	movl	$0x98, %r15d
     e31:      	jmp	0xe3c <generic_fentry_process_event+0xa8c>
     e33:      	cmpl	$0x1b, %r13d
     e37:      	je	0xe1b <generic_fentry_process_event+0xa6b>
     e39:      	xorl	%r15d, %r15d
     e3c:      	movq	%rsi, 0x58(%rsp)
     e41:      	movl	$0x0, 0xfc(%rsp)
     e4c:      	movq	(%rip), %rdi            # 0xe53 <generic_fentry_process_event+0xaa3>
     e53:      	leaq	0xfc(%rsp), %rsi
     e5b:      	movl	$0x1, %eax
     e60:      	callq	*%rax
     e62:      	xorl	%esi, %esi
     e64:      	testq	%rax, %rax
     e67:      	je	0xb37 <generic_fentry_process_event+0x787>
     e6d:      	movl	$0x3ffb, %ecx           # imm = 0x3FFB
     e72:      	subq	%r15, %rcx
     e75:      	cmpq	0xb8(%rsp), %rcx
     e7d:      	jbe	0xb37 <generic_fentry_process_event+0x787>
     e83:      	movq	0x20(%rsp), %rsi
     e88:      	movl	0x5ea0(%rax,%rsi,4), %ecx
     e8f:      	movq	0xb8(%rsp), %rdx
     e97:      	movl	%ecx, 0x90(%rax,%rdx)
     e9e:      	leaq	0x4(%rdx), %rdi
     ea2:      	movq	%rdi, 0x5e78(%rax,%rsi,8)
     eaa:      	movl	$0x4, %esi
     eaf:      	testl	%ecx, %ecx
     eb1:      	jne	0xb37 <generic_fentry_process_event+0x787>
     eb7:      	movq	%rax, %r15
     eba:      	addq	$0x90, %r15
     ec1:      	addq	%rdi, %r15
     ec4:      	movq	0x18(%rsp), %rdx
     ec9:      	movq	%rdx, 0x78(%rsp)
     ece:      	movq	$0x0, 0x68(%rsp)
     ed7:      	cmpl	$0x17, %r13d
     edb:      	movq	%rax, 0x40(%rsp)
     ee0:      	jle	0xf1d <generic_fentry_process_event+0xb6d>
     ee2:      	cmpl	$0x18, %r13d
     ee6:      	je	0xf38 <generic_fentry_process_event+0xb88>
     ee8:      	cmpl	$0x25, %r13d
     eec:      	je	0xf76 <generic_fentry_process_event+0xbc6>
     ef2:      	cmpl	$0x2a, %r13d
     ef6:      	jne	0x159a <generic_fentry_process_event+0x11ea>
     efc:      	movq	$0x0, 0xc0(%rsp)
     f08:      	movq	%rdx, 0xc8(%rsp)
     f10:      	leaq	0xc0(%rsp), %rax
     f18:      	jmp	0xfa3 <generic_fentry_process_event+0xbf3>
     f1d:      	cmpl	$0xf, %r13d
     f21:      	je	0x14cc <generic_fentry_process_event+0x111c>
     f27:      	cmpl	$0x10, %r13d
     f2b:      	jne	0x159a <generic_fentry_process_event+0x11ea>
     f31:      	leaq	0x50(%rsp), %r12
     f36:      	jmp	0xf60 <generic_fentry_process_event+0xbb0>
     f38:      	leaq	0x50(%rsp), %r12
     f3d:      	movl	$0x8, %ecx
     f42:      	movl	$0x4, %eax
     f47:      	movq	0x78(%rsp), %rdx
     f4c:      	movq	%r12, %rdi
     f4f:      	movl	$0x8, %esi
     f54:      	callq	*%rax
     f56:      	movq	0x50(%rsp), %rax
     f5b:      	movq	%rax, 0x78(%rsp)
     f60:      	leaq	0x78(%rsp), %rdx
     f65:      	movl	$0x8, %ecx
     f6a:      	movl	$0x4, %eax
     f6f:      	leaq	0x50(%rsp), %rdi
     f74:      	jmp	0xf93 <generic_fentry_process_event+0xbe3>
     f76:      	addq	$0x40, %rdx
     f7a:      	movq	%rdx, 0x78(%rsp)
     f7f:      	leaq	0x50(%rsp), %rdi
     f84:      	movl	$0x8, %ecx
     f89:      	movl	$0x4, %eax
     f8e:      	movq	0x78(%rsp), %rdx
     f93:      	movl	$0x8, %esi
     f98:      	callq	*%rax
     f9a:      	movq	0x50(%rsp), %rax
     f9f:      	addq	$0x40, %rax
     fa3:      	movq	%rax, 0x48(%rsp)
     fa8:      	movl	$0x0, 0xe4(%rsp)
     fb3:      	movq	(%rip), %rdi            # 0xfba <generic_fentry_process_event+0xc0a>
     fba:      	leaq	0xe4(%rsp), %rsi
     fc2:      	movl	$0x1, %eax
     fc7:      	callq	*%rax
     fc9:      	testq	%rax, %rax
     fcc:      	je	0x13e1 <generic_fentry_process_event+0x1031>
     fd2:      	movq	%rax, %r12
     fd5:      	movq	%r15, 0x38(%rsp)
     fda:      	addq	$0x1000, %rax           # imm = 0x1000
     fe0:      	movq	%rax, 0x18(%rsp)
     fe5:      	movl	$0x23, %eax
     fea:      	callq	*%rax
     fec:      	leaq	0xd50(%rax), %rdx
     ff3:      	leaq	0xd8(%rsp), %rdi
     ffb:      	movl	$0x8, %ecx
    1000:      	movl	$0x4, %eax
    1005:      	movl	$0x8, %esi
    100a:      	callq	*%rax
    100c:      	movq	0xd8(%rsp), %rbp
    1014:      	movq	0x48(%rsp), %rax
    1019:      	leaq	0x8(%rax), %rdx
    101d:      	leaq	0xe8(%rsp), %rdi
    1025:      	movl	$0x8, %ecx
    102a:      	movl	$0x4, %eax
    102f:      	leaq	0x18(%rbp), %rcx
    1033:      	movq	%rcx, 0x30(%rsp)
    1038:      	movl	$0x8, %esi
    103d:      	movq	%rdx, 0x58(%rsp)
    1042:      	callq	*%rax
    1044:      	movq	0xe8(%rsp), %r13
    104c:      	leaq	0x10(%r13), %rdx
    1050:      	leaq	0x78(%rsp), %rdi
    1055:      	movl	$0x8, %ecx
    105a:      	movl	$0x4, %eax
    105f:      	movl	$0x8, %esi
    1064:      	callq	*%rax
    1066:      	cmpq	$0x0, 0x78(%rsp)
    106c:      	movl	$0x1000, %r15d          # imm = 0x1000
    1072:      	je	0x107b <generic_fentry_process_event+0xccb>
    1074:      	movq	0x18(%rsp), %rcx
    1079:      	jmp	0x10ce <generic_fentry_process_event+0xd1e>
    107b:      	leaq	0x18(%r13), %rdx
    107f:      	leaq	0x78(%rsp), %rdi
    1084:      	movl	$0x8, %ecx
    1089:      	movl	$0x4, %eax
    108e:      	movl	$0x8, %esi
    1093:      	callq	*%rax
    1095:      	cmpq	%r13, 0x78(%rsp)
    109a:      	movq	0x18(%rsp), %rcx
    109f:      	je	0x10ce <generic_fentry_process_event+0xd1e>
    10a1:      	movq	%r12, %rcx
    10a4:      	addq	$0xff6, %rcx            # imm = 0xFF6
    10ab:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    10b5:      	movq	%rax, 0xff6(%r12)
    10bd:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
    10c8:      	movl	$0xff6, %r15d           # imm = 0xFF6
    10ce:      	movq	$0x0, 0x80(%rsp)
    10da:      	movq	$0x0, 0x78(%rsp)
    10e3:      	movq	%r12, 0x88(%rsp)
    10eb:      	movq	$0x0, 0x90(%rsp)
    10f7:      	movq	$0x0, 0x98(%rsp)
    1103:      	movq	$0x0, 0xa0(%rsp)
    110f:      	movq	%rcx, 0x18(%rsp)
    1114:      	movq	%rcx, 0xa8(%rsp)
    111c:      	movl	%r15d, 0xb0(%rsp)
    1124:      	movb	$0x0, 0xb4(%rsp)
    112c:      	addq	$0x20, %rbp
    1130:      	leaq	0x78(%rsp), %rdi
    1135:      	movl	$0x8, %ecx
    113a:      	movl	$0x4, %eax
    113f:      	leaq	0x80(%rsp), %r12
    1147:      	leaq	0x90(%rsp), %r15
    114f:      	leaq	0x98(%rsp), %r13
    1157:      	movl	$0x8, %esi
    115c:      	movq	%rbp, %rdx
    115f:      	callq	*%rax
    1161:      	movl	$0x8, %ecx
    1166:      	movl	$0x4, %eax
    116b:      	movq	0x30(%rsp), %rdx
    1170:      	movq	%r12, %rdi
    1173:      	movl	$0x8, %esi
    1178:      	callq	*%rax
    117a:      	movl	$0x8, %ecx
    117f:      	movl	$0x4, %eax
    1184:      	movq	0x58(%rsp), %rdx
    1189:      	movq	%r15, %rdi
    118c:      	movl	$0x8, %esi
    1191:      	callq	*%rax
    1193:      	movl	$0x8, %ecx
    1198:      	movl	$0x4, %eax
    119d:      	movq	0x48(%rsp), %rdx
    11a2:      	movq	%r13, %rdi
    11a5:      	movl	$0x8, %esi
    11aa:      	callq	*%rax
    11ac:      	movq	0x98(%rsp), %rax
    11b4:      	addq	$-0x20, %rax
    11b8:      	movq	%rax, 0xa0(%rsp)
    11c0:      	movl	$0x80, %eax
    11c5:      	movl	$0x8, %r15d
    11cb:      	movq	0x90(%rsp), %r13
    11d3:      	movq	0x98(%rsp), %rdx
    11db:      	movq	0xa0(%rsp), %r12
    11e3:      	cmpq	0x78(%rsp), %r13
    11e8:      	jne	0x11f8 <generic_fentry_process_event+0xe48>
    11ea:      	cmpq	0x80(%rsp), %rdx
    11f2:      	je	0x1390 <generic_fentry_process_event+0xfe0>
    11f8:      	movl	%eax, 0x30(%rsp)
    11fc:      	movl	$0x4, %eax
    1201:      	leaq	0xd0(%rsp), %rdi
    1209:      	movl	$0x8, %esi
    120e:      	callq	*%rax
    1210:      	cmpq	0xd0(%rsp), %r13
    1218:      	je	0x1324 <generic_fentry_process_event+0xf74>
    121e:      	leaq	0x18(%r13), %rbp
    1222:      	movl	$0x4, %eax
    1227:      	leaq	0x50(%rsp), %rdi
    122c:      	movl	$0x8, %esi
    1231:      	movq	%rbp, %rdx
    1234:      	callq	*%rax
    1236:      	cmpq	%r13, 0x50(%rsp)
    123b:      	je	0x1324 <generic_fentry_process_event+0xf74>
    1241:      	movl	$0x4, %eax
    1246:      	leaq	0x60(%rsp), %rdi
    124b:      	movl	$0x8, %esi
    1250:      	movq	%rbp, %rdx
    1253:      	callq	*%rax
    1255:      	addq	$0x20, %r13
    1259:      	movl	$0x4, %eax
    125e:      	leaq	0x68(%rsp), %rdi
    1263:      	movl	$0x10, %ecx
    1268:      	movl	$0x10, %esi
    126d:      	movq	%r13, %rdx
    1270:      	callq	*%rax
    1272:      	movq	0x88(%rsp), %r12
    127a:      	movq	0xa8(%rsp), %rax
    1282:      	movl	0x6c(%rsp), %ebp
    1286:      	subq	%r12, %rax
    1289:      	movl	0xb0(%rsp), %r13d
    1291:      	movl	%ebp, %edx
    1293:      	subl	%r13d, %edx
    1296:      	movl	$0x0, %ecx
    129b:      	cmovbl	%ecx, %edx
    129e:      	addq	0x70(%rsp), %rdx
    12a3:      	xorl	%esi, %esi
    12a5:      	cmpl	%ebp, %r13d
    12a8:      	seta	%sil
    12ac:      	movl	%ebp, %ecx
    12ae:      	cmovbl	%r13d, %ecx
    12b2:      	addl	%ecx, %esi
    12b4:      	movl	%r13d, %edi
    12b7:      	subl	%esi, %edi
    12b9:      	movl	%edi, 0xb0(%rsp)
    12c0:      	subq	%rsi, %rax
    12c3:      	jb	0x1398 <generic_fentry_process_event+0xfe8>
    12c9:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    12cf:      	ja	0x1398 <generic_fentry_process_event+0xfe8>
    12d5:      	cmpl	%ebp, %r13d
    12d8:      	jbe	0x12df <generic_fentry_process_event+0xf2f>
    12da:      	movb	$0x2f, (%r12,%rax)
    12df:      	xorl	%edi, %edi
    12e1:      	cmpl	%ebp, %r13d
    12e4:      	seta	%dil
    12e8:      	movzbl	%cl, %esi
    12eb:      	addq	%rax, %r12
    12ee:      	addq	%r12, %rdi
    12f1:      	movl	$0x4, %eax
    12f6:      	callq	*%rax
    12f8:      	movq	%r12, 0xa8(%rsp)
    1300:      	cmpl	%ebp, %r13d
    1303:      	jbe	0x1398 <generic_fentry_process_event+0xfe8>
    1309:      	movq	0x60(%rsp), %rax
    130e:      	movq	%rax, 0x90(%rsp)
    1316:      	movl	0x30(%rsp), %eax
    131a:      	decl	%eax
    131c:      	jne	0x11cb <generic_fentry_process_event+0xe1b>
    1322:      	jmp	0x1398 <generic_fentry_process_event+0xfe8>
    1324:      	leaq	0x10(%r12), %rdx
    1329:      	movl	$0x4, %eax
    132e:      	leaq	0x50(%rsp), %rdi
    1333:      	movl	$0x8, %esi
    1338:      	callq	*%rax
    133a:      	movq	0xa0(%rsp), %rax
    1342:      	cmpq	0x50(%rsp), %rax
    1347:      	movl	$0x8, %ecx
    134c:      	je	0x1390 <generic_fentry_process_event+0xfe0>
    134e:      	addq	$0x18, %r12
    1352:      	movl	$0x4, %eax
    1357:      	leaq	0x90(%rsp), %rdi
    135f:      	movl	$0x8, %esi
    1364:      	movq	%r12, %rdx
    1367:      	callq	*%rax
    1369:      	movq	0x50(%rsp), %rax
    136e:      	movq	%rax, 0xa0(%rsp)
    1376:      	addq	$0x20, %rax
    137a:      	movq	%rax, 0x98(%rsp)
    1382:      	movl	0x30(%rsp), %eax
    1386:      	decl	%eax
    1388:      	jne	0x11cb <generic_fentry_process_event+0xe1b>
    138e:      	jmp	0x1398 <generic_fentry_process_event+0xfe8>
    1390:      	movb	$0x1, 0xb4(%rsp)
    1398:      	movq	0xa8(%rsp), %rax
    13a0:      	movq	0x18(%rsp), %rdx
    13a5:      	cmpq	%rdx, %rax
    13a8:      	je	0x13e9 <generic_fentry_process_event+0x1039>
    13aa:      	xorl	%ebp, %ebp
    13ac:      	cmpb	$0x0, 0xb4(%rsp)
    13b4:      	sete	%cl
    13b7:      	movl	0xb0(%rsp), %edx
    13be:      	movl	$0x1000, %r12d          # imm = 0x1000
    13c4:      	subl	%edx, %r12d
    13c7:      	testl	%edx, %edx
    13c9:      	cmovlel	%edx, %r12d
    13cd:      	testq	%rax, %rax
    13d0:      	movq	0x38(%rsp), %r15
    13d5:      	je	0x13e1 <generic_fentry_process_event+0x1031>
    13d7:      	movb	%cl, %bpl
    13da:      	addl	%ebp, %ebp
    13dc:      	movq	%rax, %rdx
    13df:      	jmp	0x13f3 <generic_fentry_process_event+0x1043>
    13e1:      	xorl	%r12d, %r12d
    13e4:      	jmp	0x1496 <generic_fentry_process_event+0x10e6>
    13e9:      	xorl	%r12d, %r12d
    13ec:      	xorl	%ebp, %ebp
    13ee:      	movq	0x38(%rsp), %r15
    13f3:      	leaq	0x4(%r15), %rdi
    13f7:      	andl	$0xfff, %r12d           # imm = 0xFFF
    13fe:      	movl	$0x4, %eax
    1403:      	movl	%r12d, %esi
    1406:      	callq	*%rax
    1408:      	movl	%r12d, (%r15)
    140b:      	leaq	0x78(%rsp), %rdi
    1410:      	movl	$0x8, %ecx
    1415:      	movl	$0x4, %eax
    141a:      	movq	0x58(%rsp), %rdx
    141f:      	movl	$0x8, %esi
    1424:      	callq	*%rax
    1426:      	movq	0x78(%rsp), %rcx
    142b:      	addq	$0x30, %rcx
    142f:      	leaq	0x68(%rsp), %rdi
    1434:      	movl	$0x8, %edx
    1439:      	movl	$0x4, %eax
    143e:      	movq	0x78(%rsp), %rdx
    1443:      	addq	$0x30, %rdx
    1447:      	movl	$0x8, %esi
    144c:      	callq	*%rax
    144e:      	movq	0x68(%rsp), %rcx
    1453:      	leaq	0x50(%rsp), %rdi
    1458:      	movl	$0x2, %edx
    145d:      	movl	$0x4, %eax
    1462:      	movq	0x68(%rsp), %rdx
    1467:      	movl	$0x2, %esi
    146c:      	callq	*%rax
    146e:      	movl	%ebp, 0x4(%r15,%r12)
    1473:      	movzwl	0x50(%rsp), %eax
    1478:      	movw	%ax, 0x8(%r15,%r12)
    147e:      	addl	$0xa, %r12d
    1482:      	movq	0x40(%rsp), %rax
    1487:      	movq	0x20(%rsp), %rcx
    148c:      	movl	$0x4, %esi
    1491:      	testl	%r12d, %r12d
    1494:      	js	0x14a9 <generic_fentry_process_event+0x10f9>
    1496:      	andl	$0x7fffffff, %r12d      # imm = 0x7FFFFFFF
    149d:      	addq	$0x4, %r12
    14a1:      	movq	%r12, %rsi
    14a4:      	jmp	0xb37 <generic_fentry_process_event+0x787>
    14a9:      	movl	$0xffffffff, 0x5ea0(%rax,%rcx,4) # imm = 0xFFFFFFFF
    14b4:      	movq	0xb8(%rsp), %rcx
    14bc:      	movl	$0xffffffff, 0x90(%rax,%rcx) # imm = 0xFFFFFFFF
    14c7:      	jmp	0xb37 <generic_fentry_process_event+0x787>
    14cc:      	movq	%rdi, 0x38(%rsp)
    14d1:      	leaq	0x68(%rsp), %rdi
    14d6:      	leaq	0x78(%rsp), %rdx
    14db:      	movl	$0x8, %ecx
    14e0:      	movl	$0x4, %eax
    14e5:      	movl	$0x8, %esi
    14ea:      	callq	*%rax
    14ec:      	movq	0x68(%rsp), %rax
    14f1:      	movq	%rax, 0x48(%rsp)
    14f6:      	testq	%rax, %rax
    14f9:      	jne	0xfa8 <generic_fentry_process_event+0xbf8>
    14ff:      	movl	$0x0, 0xe8(%rsp)
    150a:      	movq	(%rip), %rdi            # 0x1511 <generic_fentry_process_event+0x1161>
    1511:      	leaq	0xe8(%rsp), %rsi
    1519:      	movl	$0x1, %eax
    151e:      	callq	*%rax
    1520:      	xorl	%ebp, %ebp
    1522:      	testq	%rax, %rax
    1525:      	je	0x3a3a <generic_fentry_process_event+0x368a>
    152b:      	cmpl	$0x19, %r13d
    152f:      	movq	%rbx, 0x8(%rsp)
    1534:      	movq	%r14, 0x28(%rsp)
    1539:      	movq	%rax, 0x48(%rsp)
    153e:      	jg	0x18b0 <generic_fentry_process_event+0x1500>
    1544:      	movq	%r13, %rax
    1547:      	cmpl	$0x12, %r13d
    154b:      	jle	0x18f1 <generic_fentry_process_event+0x1541>
    1551:      	cmpl	$0x14, %r13d
    1555:      	jle	0x1d80 <generic_fentry_process_event+0x19d0>
    155b:      	cmpl	$0x15, %eax
    155e:      	je	0x25ed <generic_fentry_process_event+0x223d>
    1564:      	cmpl	$0x16, %eax
    1567:      	je	0x2566 <generic_fentry_process_event+0x21b6>
    156d:      	cmpl	$0x17, %eax
    1570:      	movq	0x8(%rsp), %rbx
    1575:      	movq	0x28(%rsp), %r14
    157a:      	jne	0x3a3a <generic_fentry_process_event+0x368a>
    1580:      	movl	$0x0, 0x4(%r15)
    1588:      	movq	0x18(%rsp), %rax
    158d:      	movl	%eax, (%r15)
    1590:      	movl	$0x8, %ebp
    1595:      	jmp	0x3a3a <generic_fentry_process_event+0x368a>
    159a:      	movq	%rdi, 0x38(%rsp)
    159f:      	cmpl	$0x28, %r13d
    15a3:      	ja	0x14ff <generic_fentry_process_event+0x114f>
    15a9:      	movabsq	$0x1c1f2027cf2, %rax    # imm = 0x1C1F2027CF2
    15b3:      	btq	%rbp, %rax
    15b7:      	jae	0x14ff <generic_fentry_process_event+0x114f>
    15bd:      	movq	%rdx, 0x60(%rsp)
    15c2:      	movl	$0x0, 0xe8(%rsp)
    15cd:      	movq	(%rip), %rdi            # 0x15d4 <generic_fentry_process_event+0x1224>
    15d4:      	leaq	0xe8(%rsp), %rsi
    15dc:      	movl	$0x1, %eax
    15e1:      	callq	*%rax
    15e3:      	testq	%rax, %rax
    15e6:      	je	0x1779 <generic_fentry_process_event+0x13c9>
    15ec:      	movq	%r15, %rbp
    15ef:      	cmpl	$0x10, %r13d
    15f3:      	jg	0x1781 <generic_fentry_process_event+0x13d1>
    15f9:      	cmpl	$0x9, %r13d
    15fd:      	jg	0x17b5 <generic_fentry_process_event+0x1405>
    1603:      	movq	%r14, 0x28(%rsp)
    1608:      	movq	%rbx, 0x8(%rsp)
    160d:      	cmpl	$0x4, %r13d
    1611:      	jle	0x195f <generic_fentry_process_event+0x15af>
    1617:      	cmpl	$0x5, %r13d
    161b:      	je	0x2065 <generic_fentry_process_event+0x1cb5>
    1621:      	movq	%rax, %r15
    1624:      	movq	%r13, %rax
    1627:      	cmpl	$0x6, %eax
    162a:      	je	0x1836 <generic_fentry_process_event+0x1486>
    1630:      	cmpl	$0x7, %eax
    1633:      	movq	0x40(%rsp), %rax
    1638:      	movq	0x20(%rsp), %rcx
    163d:      	movl	$0x4, %esi
    1642:      	movq	0x8(%rsp), %rbx
    1647:      	movl	$0x0, %r12d
    164d:      	movq	0x28(%rsp), %r14
    1652:      	jne	0x1491 <generic_fentry_process_event+0x10e1>
    1658:      	movq	0x60(%rsp), %r12
    165d:      	movq	%rbp, %rbx
    1660:      	movq	%r12, 0x28(%rbp)
    1664:      	leaq	0x26(%rbp), %rdi
    1668:      	leaq	0x10(%r12), %rdx
    166d:      	movl	$0x2, %ecx
    1672:      	movl	$0x4, %eax
    1677:      	movl	$0x2, %esi
    167c:      	callq	*%rax
    167e:      	leaq	0x3a(%rbp), %rdi
    1682:      	leaq	0x12(%r12), %rdx
    1687:      	movl	$0x1, %ecx
    168c:      	movl	$0x4, %eax
    1691:      	movl	$0x1, %esi
    1696:      	callq	*%rax
    1698:      	leaq	0x38(%rbp), %rdi
    169c:      	leaq	0x226(%r12), %rdx
    16a4:      	movl	$0x2, %ecx
    16a9:      	movl	$0x4, %eax
    16ae:      	movl	$0x2, %esi
    16b3:      	callq	*%rax
    16b5:      	leaq	0x24(%rbp), %rdi
    16b9:      	leaq	0x224(%r12), %rdx
    16c1:      	movl	$0x2, %ecx
    16c6:      	movl	$0x4, %eax
    16cb:      	movl	$0x2, %esi
    16d0:      	callq	*%rax
    16d2:      	leaq	0x30(%rbp), %rdi
    16d6:      	leaq	0x21c(%r12), %rdx
    16de:      	movl	$0x4, %ecx
    16e3:      	movl	$0x4, %eax
    16e8:      	movl	$0x4, %esi
    16ed:      	callq	*%rax
    16ef:      	leaq	0x34(%rbp), %rdi
    16f3:      	leaq	0x218(%r12), %rdx
    16fb:      	movl	$0x4, %ecx
    1700:      	movl	$0x4, %eax
    1705:      	movl	$0x4, %esi
    170a:      	callq	*%rax
    170c:      	leaq	0x10(%rbp), %r13
    1710:      	movq	$0x0, (%rbp)
    1718:      	movq	$0x0, 0x8(%rbp)
    1720:      	movq	$0x0, 0x10(%rbp)
    1728:      	movq	$0x0, 0x18(%rbp)
    1730:      	movzwl	0x26(%rbp), %eax
    1734:      	cmpl	$0xa, %eax
    1737:      	je	0x28c4 <generic_fentry_process_event+0x2514>
    173d:      	cmpl	$0x2, %eax
    1740:      	jne	0x28f6 <generic_fentry_process_event+0x2546>
    1746:      	leaq	0x4(%r12), %rdx
    174b:      	movl	$0x4, %ecx
    1750:      	movl	$0x4, %eax
    1755:      	movq	%rbp, %rdi
    1758:      	movl	$0x4, %esi
    175d:      	callq	*%rax
    175f:      	movl	$0x4, %ecx
    1764:      	movl	$0x4, %eax
    1769:      	movq	%r13, %rdi
    176c:      	movl	$0x4, %esi
    1771:      	movq	%r12, %rdx
    1774:      	jmp	0x28f4 <generic_fentry_process_event+0x2544>
    1779:      	xorl	%r12d, %r12d
    177c:      	jmp	0x1482 <generic_fentry_process_event+0x10d2>
    1781:      	cmpl	$0x1e, %r13d
    1785:      	jg	0x186d <generic_fentry_process_event+0x14bd>
    178b:      	cmpl	$0x1c, %r13d
    178f:      	jg	0x19e7 <generic_fentry_process_event+0x1637>
    1795:      	movq	%rax, %r15
    1798:      	movq	%r13, %rax
    179b:      	cmpl	$0x11, %eax
    179e:      	je	0x2217 <generic_fentry_process_event+0x1e67>
    17a4:      	cmpl	$0x19, %eax
    17a7:      	je	0x1e55 <generic_fentry_process_event+0x1aa5>
    17ad:      	cmpl	$0x1c, %eax
    17b0:      	jmp	0x1975 <generic_fentry_process_event+0x15c5>
    17b5:      	leal	-0xa(%r13), %eax
    17b9:      	cmpl	$0x2, %eax
    17bc:      	jb	0x1990 <generic_fentry_process_event+0x15e0>
    17c2:      	leal	-0xc(%r13), %eax
    17c6:      	cmpl	$0x2, %eax
    17c9:      	jb	0x19c3 <generic_fentry_process_event+0x1613>
    17cf:      	movq	%r13, %rcx
    17d2:      	cmpl	$0xe, %ecx
    17d5:      	movq	0x40(%rsp), %rax
    17da:      	movq	0x20(%rsp), %rcx
    17df:      	movl	$0x4, %esi
    17e4:      	movl	$0x0, %r12d
    17ea:      	jne	0x1491 <generic_fentry_process_event+0x10e1>
    17f0:      	movq	%r14, 0x28(%rsp)
    17f5:      	movq	%rbx, 0x8(%rsp)
    17fa:      	leaq	0x78(%rsp), %rdi
    17ff:      	leaq	0x60(%rsp), %r12
    1804:      	movl	$0x8, %ecx
    1809:      	movl	$0x4, %eax
    180e:      	movl	$0x8, %esi
    1813:      	movq	%r12, %rdx
    1816:      	callq	*%rax
    1818:      	movq	0x78(%rsp), %rcx
    181d:      	movl	$0x8, %edx
    1822:      	movl	$0x4, %eax
    1827:      	movq	0x78(%rsp), %rdx
    182c:      	movq	%r12, %rdi
    182f:      	movl	$0x8, %esi
    1834:      	callq	*%rax
    1836:      	movq	0x60(%rsp), %rdx
    183b:      	leaq	0x4(%rbp), %rdi
    183f:      	movl	$0x1ff, %ecx            # imm = 0x1FF
    1844:      	movl	$0x2d, %eax
    1849:      	movl	$0x1ff, %esi            # imm = 0x1FF
    184e:      	callq	*%rax
    1850:      	movq	%rax, %r12
    1853:      	testq	%rax, %rax
    1856:      	js	0x3ddf <generic_fentry_process_event+0x3a2f>
    185c:      	leal	-0x1(%r12), %eax
    1861:      	movl	%eax, (%rbp)
    1864:      	addq	$0x3, %r12
    1868:      	jmp	0x3ddf <generic_fentry_process_event+0x3a2f>
    186d:      	movq	%r14, %r15
    1870:      	movq	%rbx, 0x8(%rsp)
    1875:      	cmpl	$0x26, %r13d
    1879:      	jg	0x1a0b <generic_fentry_process_event+0x165b>
    187f:      	leal	-0x1f(%r13), %eax
    1883:      	cmpl	$0x2, %eax
    1886:      	jae	0x1cf6 <generic_fentry_process_event+0x1946>
    188c:      	leaq	0x60(%rsp), %rdx
    1891:      	movl	$0x4, %r12d
    1897:      	movl	$0x1, %ecx
    189c:      	movl	$0x4, %eax
    18a1:      	movq	%rbp, %rdi
    18a4:      	movl	$0x1, %esi
    18a9:      	callq	*%rax
    18ab:      	jmp	0x2abe <generic_fentry_process_event+0x270e>
    18b0:      	movq	%r15, 0x38(%rsp)
    18b5:      	cmpl	$0x20, %r13d
    18b9:      	jle	0x1c32 <generic_fentry_process_event+0x1882>
    18bf:      	leal	-0x21(%r13), %eax
    18c3:      	cmpl	$0x4, %eax
    18c6:      	jae	0x1acb <generic_fentry_process_event+0x171b>
    18cc:      	movl	$0x8, %ebp
    18d1:      	movl	$0x8, %ecx
    18d6:      	movl	$0x4, %eax
    18db:      	movq	0x38(%rsp), %rdi
    18e0:      	movq	0x18(%rsp), %rdx
    18e5:      	movl	$0x8, %esi
    18ea:      	callq	*%rax
    18ec:      	jmp	0x3a30 <generic_fentry_process_event+0x3680>
    18f1:      	cmpl	$0x7, %r13d
    18f5:      	jg	0x1d43 <generic_fentry_process_event+0x1993>
    18fb:      	cmpl	$0x2, %eax
    18fe:      	je	0x2315 <generic_fentry_process_event+0x1f65>
    1904:      	cmpl	$0x3, %eax
    1907:      	movq	0x8(%rsp), %rbx
    190c:      	movq	0x28(%rsp), %r14
    1911:      	jne	0x3a3a <generic_fentry_process_event+0x368a>
    1917:      	movq	0x48(%rsp), %rax
    191c:      	leaq	0x90(%rax), %r13
    1923:      	andl	$0xf, %r12d
    1927:      	movq	%r12, %rax
    192a:      	cmpl	$0x2, %r12d
    192e:      	jle	0x2a53 <generic_fentry_process_event+0x26a3>
    1934:      	cmpl	$0x3, %eax
    1937:      	je	0x2d13 <generic_fentry_process_event+0x2963>
    193d:      	cmpl	$0x4, %eax
    1940:      	je	0x2d20 <generic_fentry_process_event+0x2970>
    1946:      	cmpl	$0x5, %eax
    1949:      	jne	0x3113 <generic_fentry_process_event+0x2d63>
    194f:      	movq	0x48(%rsp), %rax
    1954:      	addq	$0x5e70, %rax           # imm = 0x5E70
    195a:      	jmp	0x2d38 <generic_fentry_process_event+0x2988>
    195f:      	cmpl	$0x1, %r13d
    1963:      	movq	0x8(%rsp), %rbx
    1968:      	movq	0x28(%rsp), %r14
    196d:      	je	0x19c3 <generic_fentry_process_event+0x1613>
    196f:      	movq	%r13, %rax
    1972:      	cmpl	$0x4, %eax
    1975:      	movq	0x40(%rsp), %rax
    197a:      	movq	0x20(%rsp), %rcx
    197f:      	movl	$0x4, %esi
    1984:      	movl	$0x0, %r12d
    198a:      	jne	0x1491 <generic_fentry_process_event+0x10e1>
    1990:      	movl	$0x8, %r12d
    1996:      	leaq	0x60(%rsp), %rdx
    199b:      	movl	$0x8, %ecx
    19a0:      	movl	$0x4, %eax
    19a5:      	movq	%rbp, %rdi
    19a8:      	movl	$0x8, %esi
    19ad:      	callq	*%rax
    19af:      	movl	$0x4, %esi
    19b4:      	movq	0x20(%rsp), %rcx
    19b9:      	movq	0x40(%rsp), %rax
    19be:      	jmp	0x1491 <generic_fentry_process_event+0x10e1>
    19c3:      	leaq	0x60(%rsp), %rdx
    19c8:      	movl	$0x4, %r12d
    19ce:      	movl	$0x4, %ecx
    19d3:      	movl	$0x4, %eax
    19d8:      	movq	%rbp, %rdi
    19db:      	movl	$0x4, %esi
    19e0:      	callq	*%rax
    19e2:      	jmp	0x1482 <generic_fentry_process_event+0x10d2>
    19e7:      	leaq	0x60(%rsp), %rdx
    19ec:      	movl	$0x4, %r12d
    19f2:      	movl	$0x2, %ecx
    19f7:      	movl	$0x4, %eax
    19fc:      	movq	%rbp, %rdi
    19ff:      	movl	$0x2, %esi
    1a04:      	callq	*%rax
    1a06:      	jmp	0x1482 <generic_fentry_process_event+0x10d2>
    1a0b:      	cmpl	$0x27, %r13d
    1a0f:      	je	0x22d9 <generic_fentry_process_event+0x1f29>
    1a15:      	movq	%r13, %rax
    1a18:      	cmpl	$0x28, %eax
    1a1b:      	movq	0x40(%rsp), %rax
    1a20:      	movq	0x20(%rsp), %rcx
    1a25:      	movl	$0x4, %esi
    1a2a:      	movq	0x8(%rsp), %rbx
    1a2f:      	movl	$0x0, %r12d
    1a35:      	movq	%r15, %r14
    1a38:      	jne	0x1491 <generic_fentry_process_event+0x10e1>
    1a3e:      	movq	0x60(%rsp), %r12
    1a43:      	movq	%rbp, %rdi
    1a46:      	movq	$0x0, 0x10(%rbp)
    1a4e:      	movq	$0x0, 0x8(%rbp)
    1a56:      	movq	$0x0, (%rbp)
    1a5e:      	movl	$0x2, %ecx
    1a63:      	movl	$0x4, %eax
    1a68:      	movl	$0x2, %esi
    1a6d:      	movq	%r12, %rdx
    1a70:      	callq	*%rax
    1a72:      	testq	%rax, %rax
    1a75:      	js	0x2ab8 <generic_fentry_process_event+0x2708>
    1a7b:      	movzwl	(%rbp), %eax
    1a7f:      	cmpl	$0xa, %eax
    1a82:      	je	0x2a75 <generic_fentry_process_event+0x26c5>
    1a88:      	cmpl	$0x2, %eax
    1a8b:      	jne	0x2aae <generic_fentry_process_event+0x26fe>
    1a91:      	leaq	0x4(%r12), %rdx
    1a96:      	leaq	0x78(%rsp), %rdi
    1a9b:      	movl	$0x4, %ecx
    1aa0:      	movl	$0x4, %eax
    1aa5:      	movl	$0x4, %esi
    1aaa:      	callq	*%rax
    1aac:      	movl	0x78(%rsp), %eax
    1ab0:      	movq	%rax, 0x8(%rbp)
    1ab4:      	leaq	0x2(%rbp), %rdi
    1ab8:      	addq	$0x2, %r12
    1abc:      	movl	$0x2, %ecx
    1ac1:      	movl	$0x4, %eax
    1ac6:      	jmp	0x2aa4 <generic_fentry_process_event+0x26f4>
    1acb:      	movq	%r13, %rcx
    1ace:      	cmpl	$0x2b, %ecx
    1ad1:      	je	0x26dc <generic_fentry_process_event+0x232c>
    1ad7:      	cmpl	$0x29, %ecx
    1ada:      	movq	0x8(%rsp), %rbx
    1adf:      	movq	0x28(%rsp), %r14
    1ae4:      	jne	0x3a3a <generic_fentry_process_event+0x368a>
    1aea:      	movq	0x18(%rsp), %rdx
    1aef:      	addq	$0x18, %rdx
    1af3:      	leaq	0x78(%rsp), %rdi
    1af8:      	movl	$0x4, %ebx
    1afd:      	movl	$0x8, %ecx
    1b02:      	movl	$0x4, %eax
    1b07:      	movl	$0x8, %esi
    1b0c:      	callq	*%rax
    1b0e:      	movq	0x78(%rsp), %r12
    1b13:      	testq	%r12, %r12
    1b16:      	je	0x2ccb <generic_fentry_process_event+0x291b>
    1b1c:      	movq	0x38(%rsp), %r15
    1b21:      	movq	%r12, 0x28(%r15)
    1b25:      	leaq	0x26(%r15), %rdi
    1b29:      	leaq	0x10(%r12), %rdx
    1b2e:      	movl	$0x2, %ecx
    1b33:      	movl	$0x4, %eax
    1b38:      	movl	$0x2, %esi
    1b3d:      	callq	*%rax
    1b3f:      	leaq	0x3a(%r15), %rdi
    1b43:      	leaq	0x12(%r12), %rdx
    1b48:      	movl	$0x1, %ecx
    1b4d:      	movl	$0x4, %eax
    1b52:      	movl	$0x1, %esi
    1b57:      	callq	*%rax
    1b59:      	leaq	0x38(%r15), %rdi
    1b5d:      	leaq	0x226(%r12), %rdx
    1b65:      	movl	$0x2, %ecx
    1b6a:      	movl	$0x4, %eax
    1b6f:      	movl	$0x2, %esi
    1b74:      	callq	*%rax
    1b76:      	leaq	0x24(%r15), %rdi
    1b7a:      	leaq	0x224(%r12), %rdx
    1b82:      	movl	$0x2, %ecx
    1b87:      	movl	$0x4, %eax
    1b8c:      	movl	$0x2, %esi
    1b91:      	callq	*%rax
    1b93:      	leaq	0x30(%r15), %rdi
    1b97:      	leaq	0x21c(%r12), %rdx
    1b9f:      	movl	$0x4, %eax
    1ba4:      	movl	$0x4, %esi
    1ba9:      	callq	*%rax
    1bab:      	leaq	0x34(%r15), %rdi
    1baf:      	leaq	0x218(%r12), %rdx
    1bb7:      	movl	$0x4, %eax
    1bbc:      	movl	$0x4, %esi
    1bc1:      	callq	*%rax
    1bc3:      	leaq	0x10(%r15), %r13
    1bc7:      	movq	$0x0, (%r15)
    1bce:      	movq	$0x0, 0x8(%r15)
    1bd6:      	movq	$0x0, 0x10(%r15)
    1bde:      	movq	$0x0, 0x18(%r15)
    1be6:      	movzwl	0x26(%r15), %eax
    1beb:      	cmpl	$0xa, %eax
    1bee:      	je	0x2c4f <generic_fentry_process_event+0x289f>
    1bf4:      	cmpl	$0x2, %eax
    1bf7:      	jne	0x2c83 <generic_fentry_process_event+0x28d3>
    1bfd:      	leaq	0x4(%r12), %rdx
    1c02:      	movl	$0x4, %ecx
    1c07:      	movl	$0x4, %eax
    1c0c:      	movq	0x38(%rsp), %rdi
    1c11:      	movl	$0x4, %esi
    1c16:      	callq	*%rax
    1c18:      	movl	$0x4, %ecx
    1c1d:      	movl	$0x4, %eax
    1c22:      	movq	%r13, %rdi
    1c25:      	movl	$0x4, %esi
    1c2a:      	movq	%r12, %rdx
    1c2d:      	jmp	0x2c81 <generic_fentry_process_event+0x28d1>
    1c32:      	cmpl	$0x1a, %r13d
    1c36:      	je	0x2778 <generic_fentry_process_event+0x23c8>
    1c3c:      	movq	%r13, %rax
    1c3f:      	cmpl	$0x1b, %eax
    1c42:      	movq	0x8(%rsp), %rbx
    1c47:      	movq	0x28(%rsp), %r14
    1c4c:      	jne	0x3a3a <generic_fentry_process_event+0x368a>
    1c52:      	movq	0x38(%rsp), %rax
    1c57:      	movq	$0x0, 0x48(%rax)
    1c5f:      	movq	$0x0, 0x40(%rax)
    1c67:      	movq	$0x0, 0x38(%rax)
    1c6f:      	movq	$0x0, 0x30(%rax)
    1c77:      	movq	$0x0, 0x28(%rax)
    1c7f:      	movq	$0x0, 0x20(%rax)
    1c87:      	movq	$0x0, 0x18(%rax)
    1c8f:      	movq	$0x0, 0x10(%rax)
    1c97:      	movq	$0x0, 0x8(%rax)
    1c9f:      	movq	$0x0, (%rax)
    1ca6:      	leaq	0x10(%rax), %rdi
    1caa:      	movq	0x18(%rsp), %rax
    1caf:      	leaq	0x18(%rax), %rdx
    1cb3:      	movl	$0x3f, %ecx
    1cb8:      	movl	$0x2d, %eax
    1cbd:      	movl	$0x3f, %esi
    1cc2:      	callq	*%rax
    1cc4:      	testq	%rax, %rax
    1cc7:      	js	0x27f0 <generic_fentry_process_event+0x2440>
    1ccd:      	movq	0x38(%rsp), %rdi
    1cd2:      	addq	$0x8, %rdi
    1cd6:      	movq	0x18(%rsp), %rdx
    1cdb:      	addq	$0x348, %rdx            # imm = 0x348
    1ce2:      	movl	$0x8, %ecx
    1ce7:      	movl	$0x4, %eax
    1cec:      	movl	$0x8, %esi
    1cf1:      	jmp	0x255a <generic_fentry_process_event+0x21aa>
    1cf6:      	movq	%r13, %rcx
    1cf9:      	cmpl	$0x26, %ecx
    1cfc:      	movq	0x40(%rsp), %rax
    1d01:      	movq	0x20(%rsp), %rcx
    1d06:      	movl	$0x4, %esi
    1d0b:      	movq	0x8(%rsp), %rbx
    1d10:      	movl	$0x0, %r12d
    1d16:      	movq	%r15, %r14
    1d19:      	jne	0x1491 <generic_fentry_process_event+0x10e1>
    1d1f:      	movq	0x60(%rsp), %rsi
    1d24:      	movzwl	%si, %edx
    1d27:      	addq	%rbx, %rdx
    1d2a:      	shrl	$0x10, %esi
    1d2d:      	andl	$0xfff, %esi            # imm = 0xFFF
    1d33:      	leaq	0x4(%rbp), %rdi
    1d37:      	incl	%esi
    1d39:      	movl	$0x2d, %eax
    1d3e:      	jmp	0x22f6 <generic_fentry_process_event+0x1f46>
    1d43:      	cmpl	$0x8, %eax
    1d46:      	je	0x2381 <generic_fentry_process_event+0x1fd1>
    1d4c:      	cmpl	$0x12, %eax
    1d4f:      	movq	0x8(%rsp), %rbx
    1d54:      	movq	0x28(%rsp), %r14
    1d59:      	jne	0x3a3a <generic_fentry_process_event+0x368a>
    1d5f:      	movq	0x58(%rsp), %rbp
    1d64:      	andl	$0x3ff, %ebp            # imm = 0x3FF
    1d6a:      	movl	$0x4, %eax
    1d6f:      	movq	0x18(%rsp), %rdx
    1d74:      	movq	%r15, %rdi
    1d77:      	movl	%ebp, %esi
    1d79:      	callq	*%rax
    1d7b:      	jmp	0x3a3a <generic_fentry_process_event+0x368a>
    1d80:      	cmpl	$0x13, %eax
    1d83:      	je	0x2682 <generic_fentry_process_event+0x22d2>
    1d89:      	cmpl	$0x14, %eax
    1d8c:      	movq	0x8(%rsp), %rbx
    1d91:      	movq	0x28(%rsp), %r14
    1d96:      	jne	0x3a3a <generic_fentry_process_event+0x368a>
    1d9c:      	movq	$0x0, 0x78(%rsp)
    1da5:      	movq	0x18(%rsp), %r13
    1daa:      	leaq	0x110(%r13), %rdx
    1db1:      	leaq	0x78(%rsp), %rdi
    1db6:      	movl	$0x8, %ecx
    1dbb:      	movl	$0x4, %eax
    1dc0:      	leaq	0xd8(%r13), %r12
    1dc7:      	movl	$0x8, %esi
    1dcc:      	callq	*%rax
    1dce:      	movq	0x78(%rsp), %rcx
    1dd3:      	movl	$0x80, %edx
    1dd8:      	movl	$0x2d, %eax
    1ddd:      	movq	0x78(%rsp), %rdx
    1de2:      	movq	%r15, %rdi
    1de5:      	movl	$0x80, %esi
    1dea:      	callq	*%rax
    1dec:      	leaq	0x90(%r15), %rdi
    1df3:      	movl	$0x4, %ecx
    1df8:      	movl	$0x4, %eax
    1dfd:      	movl	$0x4, %esi
    1e02:      	movq	%r12, %rdx
    1e05:      	callq	*%rax
    1e07:      	leaq	0x80(%r15), %rdi
    1e0e:      	leaq	0xe0(%r13), %rdx
    1e15:      	movl	$0x8, %ecx
    1e1a:      	movl	$0x4, %eax
    1e1f:      	movl	$0x8, %esi
    1e24:      	callq	*%rax
    1e26:      	addq	$0x88, %r15
    1e2d:      	addq	$0x118, %r13            # imm = 0x118
    1e34:      	movl	$0x8, %ecx
    1e39:      	movl	$0x4, %eax
    1e3e:      	movq	%r15, %rdi
    1e41:      	movl	$0x8, %esi
    1e46:      	movq	%r13, %rdx
    1e49:      	callq	*%rax
    1e4b:      	movl	$0x98, %ebp
    1e50:      	jmp	0x3a3a <generic_fentry_process_event+0x368a>
    1e55:      	movq	0x60(%rsp), %r13
    1e5a:      	leaq	0xd8(%rsp), %rdi
    1e62:      	movl	$0x1, %ecx
    1e67:      	movl	$0x4, %eax
    1e6c:      	movl	$0x1, %esi
    1e71:      	movq	%r13, %rdx
    1e74:      	callq	*%rax
    1e76:      	cmpb	$0x1, 0xd8(%rsp)
    1e7e:      	jne	0x27f7 <generic_fentry_process_event+0x2447>
    1e84:      	addq	$0x10, %r13
    1e88:      	leaq	0x68(%rsp), %rdi
    1e8d:      	movl	$0x8, %ebp
    1e92:      	movl	$0x8, %ecx
    1e97:      	movl	$0x4, %eax
    1e9c:      	movl	$0x8, %esi
    1ea1:      	movq	%r13, %rdx
    1ea4:      	callq	*%rax
    1ea6:      	movq	0x68(%rsp), %rdx
    1eab:      	leaq	0xc0(%rsp), %rdi
    1eb3:      	movl	$0x8, %ecx
    1eb8:      	movl	$0x4, %eax
    1ebd:      	movl	$0x8, %esi
    1ec2:      	callq	*%rax
    1ec4:      	movq	0x68(%rsp), %rdx
    1ec9:      	addq	$0x8, %rdx
    1ecd:      	leaq	0x50(%rsp), %rdi
    1ed2:      	movl	$0x8, %ecx
    1ed7:      	movl	$0x4, %eax
    1edc:      	movl	$0x8, %esi
    1ee1:      	callq	*%rax
    1ee3:      	movq	0xc0(%rsp), %rax
    1eeb:      	movq	%rax, 0x48(%rsp)
    1ef0:      	movq	0x50(%rsp), %rax
    1ef5:      	movq	%rax, 0x18(%rsp)
    1efa:      	movq	0x38(%rsp), %rax
    1eff:      	addq	%r15, %rax
    1f02:      	addq	$0x90, %rax
    1f08:      	movq	%rax, 0x58(%rsp)
    1f0d:      	testb	$0x20, %r12b
    1f11:      	je	0x2bbc <generic_fentry_process_event+0x280c>
    1f17:      	cmpq	$0x1000, 0x18(%rsp)     # imm = 0x1000
    1f20:      	jb	0x2b93 <generic_fentry_process_event+0x27e3>
    1f26:      	movq	0x58(%rsp), %rax
    1f2b:      	movl	$0x1, (%rax)
    1f31:      	movl	$0x0, 0xd0(%rsp)
    1f3c:      	movq	(%rip), %rdi            # 0x1f43 <generic_fentry_process_event+0x1b93>
    1f43:      	leaq	0xd0(%rsp), %rsi
    1f4b:      	movl	$0x1, %eax
    1f50:      	callq	*%rax
    1f52:      	movq	%rax, 0x30(%rsp)
    1f57:      	testq	%rax, %rax
    1f5a:      	je	0x32d0 <generic_fentry_process_event+0x2f20>
    1f60:      	movq	0x30(%rsp), %r12
    1f65:      	movl	$0x18, (%r12)
    1f6d:      	movl	$0xe, %eax
    1f72:      	callq	*%rax
    1f74:      	leaq	0x10(%r12), %r15
    1f79:      	movq	%rax, 0x10(%r12)
    1f7e:      	cmpq	$-0x16, %rax
    1f82:      	jne	0x1fa6 <generic_fentry_process_event+0x1bf6>
    1f84:      	leaq	0x20(%rbx), %rdx
    1f88:      	leaq	0x78(%rsp), %rdi
    1f8d:      	movl	$0x8, %ecx
    1f92:      	movl	$0x4, %eax
    1f97:      	movl	$0x8, %esi
    1f9c:      	callq	*%rax
    1f9e:      	movq	0x78(%rsp), %rax
    1fa3:      	movq	%rax, (%r15)
    1fa6:      	movl	$0x7d, %eax
    1fab:      	callq	*%rax
    1fad:      	movq	0x30(%rsp), %rbp
    1fb2:      	movq	%rax, 0x18(%rbp)
    1fb6:      	movq	(%r15), %rax
    1fb9:      	movq	0x8(%r15), %rcx
    1fbd:      	movq	0x58(%rsp), %rdx
    1fc2:      	movq	%rax, 0x14(%rdx)
    1fc6:      	movq	%rcx, 0x1c(%rdx)
    1fca:      	addq	$0x20, %rbp
    1fce:      	movl	$0xa, %r15d
    1fd4:      	xorl	%r12d, %r12d
    1fd7:      	movq	0x18(%rsp), %r13
    1fdc:      	subq	%r12, %r13
    1fdf:      	js	0x34df <generic_fentry_process_event+0x312f>
    1fe5:      	movq	0x48(%rsp), %rax
    1fea:      	leaq	(%r12,%rax), %rdx
    1fee:      	cmpq	$0x7fe0, %r13           # imm = 0x7FE0
    1ff5:      	movl	$0x7fe0, %eax           # imm = 0x7FE0
    1ffa:      	cmovaeq	%rax, %r13
    1ffe:      	movl	$0x4, %eax
    2003:      	movq	%rbp, %rdi
    2006:      	movl	%r13d, %esi
    2009:      	callq	*%rax
    200b:      	testl	%eax, %eax
    200d:      	js	0x2036 <generic_fentry_process_event+0x1c86>
    200f:      	leal	0x20(%r13), %r8d
    2013:      	movq	0x30(%rsp), %rcx
    2018:      	movl	%r8d, 0x4(%rcx)
    201c:      	movl	$0x19, %eax
    2021:      	movq	%rbx, %rdi
    2024:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    2029:      	movq	(%rip), %rsi            # 0x2030 <generic_fentry_process_event+0x1c80>
    2030:      	callq	*%rax
    2032:      	testl	%eax, %eax
    2034:      	jns	0x2039 <generic_fentry_process_event+0x1c89>
    2036:      	movslq	%eax, %r13
    2039:      	testl	%r13d, %r13d
    203c:      	js	0x34e8 <generic_fentry_process_event+0x3138>
    2042:      	andl	$0x7fffffff, %r13d      # imm = 0x7FFFFFFF
    2049:      	addq	%r13, %r12
    204c:      	cmpq	0x18(%rsp), %r12
    2051:      	je	0x3542 <generic_fentry_process_event+0x3192>
    2057:      	decl	%r15d
    205a:      	jne	0x1fd7 <generic_fentry_process_event+0x1c27>
    2060:      	jmp	0x38a3 <generic_fentry_process_event+0x34f3>
    2065:      	movq	0x60(%rsp), %r13
    206a:      	movq	%rbp, %rbx
    206d:      	leaq	0x28(%rbp), %rdi
    2071:      	leaq	0x98(%r13), %rdx
    2078:      	movl	$0x4, %ecx
    207d:      	movl	$0x4, %eax
    2082:      	movl	$0x4, %esi
    2087:      	callq	*%rax
    2089:      	leaq	0x2c(%rbp), %rdi
    208d:      	leaq	0x70(%r13), %rdx
    2091:      	movl	$0x4, %ecx
    2096:      	movl	$0x4, %eax
    209b:      	movl	$0x4, %esi
    20a0:      	callq	*%rax
    20a2:      	leaq	0x30(%rbp), %rdi
    20a6:      	leaq	0x90(%r13), %rdx
    20ad:      	movl	$0x4, %ecx
    20b2:      	movl	$0x4, %eax
    20b7:      	movl	$0x4, %esi
    20bc:      	callq	*%rax
    20be:      	leaq	0x34(%rbp), %rdi
    20c2:      	leaq	0xa8(%r13), %rdx
    20c9:      	movl	$0x4, %ecx
    20ce:      	movl	$0x4, %eax
    20d3:      	movl	$0x4, %esi
    20d8:      	callq	*%rax
    20da:      	movq	$0x0, 0x78(%rsp)
    20e3:      	leaq	0xc8(%r13), %rdx
    20ea:      	leaq	0x78(%rsp), %rdi
    20ef:      	movl	$0x8, %ecx
    20f4:      	movl	$0x4, %eax
    20f9:      	movl	$0x8, %esi
    20fe:      	callq	*%rax
    2100:      	leaq	0xb8(%r13), %rdx
    2107:      	leaq	0x50(%rsp), %rdi
    210c:      	movl	$0x2, %ecx
    2111:      	movl	$0x4, %eax
    2116:      	movl	$0x2, %esi
    211b:      	callq	*%rax
    211d:      	movzwl	0x50(%rsp), %r12d
    2123:      	addq	0x78(%rsp), %r12
    2128:      	leaq	0xe4(%rsp), %rdi
    2130:      	movl	$0x1, %ecx
    2135:      	movl	$0x4, %eax
    213a:      	movl	$0x1, %esi
    213f:      	movq	%r12, %rdx
    2142:      	callq	*%rax
    2144:      	movzbl	0xe4(%rsp), %eax
    214c:      	shrl	$0x4, %eax
    214f:      	cmpl	$0x6, %eax
    2152:      	je	0x281f <generic_fentry_process_event+0x246f>
    2158:      	cmpl	$0x4, %eax
    215b:      	jne	0x3dd9 <generic_fentry_process_event+0x3a29>
    2161:      	leaq	0x9(%r12), %rdx
    2166:      	leaq	0xd8(%rsp), %rdi
    216e:      	movl	$0x1, %ecx
    2173:      	movl	$0x4, %eax
    2178:      	movl	$0x1, %esi
    217d:      	callq	*%rax
    217f:      	movzbl	0xd8(%rsp), %eax
    2187:      	movq	%rbp, %rdi
    218a:      	movw	%ax, 0x24(%rbp)
    218e:      	movw	$0x2, 0x26(%rbp)
    2194:      	leaq	0xc(%r12), %rdx
    2199:      	movq	$0x0, (%rbp)
    21a1:      	movq	$0x0, 0x8(%rbp)
    21a9:      	movq	$0x0, 0x10(%rbp)
    21b1:      	movq	$0x0, 0x18(%rbp)
    21b9:      	movl	$0x4, %ecx
    21be:      	movl	$0x4, %eax
    21c3:      	leaq	0x10(%rbp), %rbx
    21c7:      	movl	$0x4, %esi
    21cc:      	callq	*%rax
    21ce:      	addq	$0x10, %r12
    21d2:      	movl	$0x4, %ecx
    21d7:      	movl	$0x4, %eax
    21dc:      	movq	%rbx, %rdi
    21df:      	movl	$0x4, %esi
    21e4:      	movq	%r12, %rdx
    21e7:      	callq	*%rax
    21e9:      	leaq	0xb6(%r13), %rdx
    21f0:      	leaq	0xd0(%rsp), %rdi
    21f8:      	movl	$0x2, %ecx
    21fd:      	movl	$0x4, %eax
    2202:      	movl	$0x2, %esi
    2207:      	callq	*%rax
    2209:      	movzbl	0xd8(%rsp), %r12d
    2212:      	jmp	0x3c8a <generic_fentry_process_event+0x38da>
    2217:      	movq	$0x0, 0x80(%rsp)
    2223:      	movl	$0xe, %eax
    2228:      	callq	*%rax
    222a:      	shrq	$0x20, %rax
    222e:      	movq	%rax, 0x78(%rsp)
    2233:      	leaq	0x68(%rsp), %rdi
    2238:      	leaq	0x60(%rsp), %rdx
    223d:      	movl	$0x4, %ecx
    2242:      	movl	$0x4, %eax
    2247:      	movl	$0x4, %esi
    224c:      	callq	*%rax
    224e:      	movl	0x68(%rsp), %eax
    2252:      	movl	%eax, 0x80(%rsp)
    2259:      	movq	(%rip), %rdi            # 0x2260 <generic_fentry_process_event+0x1eb0>
    2260:      	leaq	0x78(%rsp), %rsi
    2265:      	movl	$0x1, %eax
    226a:      	callq	*%rax
    226c:      	testq	%rax, %rax
    226f:      	je	0x2813 <generic_fentry_process_event+0x2463>
    2275:      	movq	%rax, %r13
    2278:      	movl	(%rax), %r15d
    227b:      	leaq	0x68(%rsp), %rdx
    2280:      	movl	$0x4, %eax
    2285:      	movq	%rbp, %r12
    2288:      	movl	$0x4, %ebp
    228d:      	movq	%r12, %rdi
    2290:      	movl	$0x4, %esi
    2295:      	callq	*%rax
    2297:      	andl	$0xfff, %r15d           # imm = 0xFFF
    229e:      	leaq	0x4(%r12), %rdi
    22a3:      	leaq	0x4(%r15), %rsi
    22a7:      	movl	$0x4, %eax
    22ac:      	movq	%r13, %rdx
    22af:      	callq	*%rax
    22b1:      	leaq	(%r12,%r15), %rdi
    22b5:      	addq	$0x8, %rdi
    22b9:      	leaq	(%r15,%r13), %rdx
    22bd:      	addq	$0x4, %rdx
    22c1:      	movl	$0x4, %eax
    22c6:      	movl	$0x4, %esi
    22cb:      	callq	*%rax
    22cd:      	addq	$0xc, %r15
    22d1:      	movq	%r15, %r12
    22d4:      	jmp	0x1482 <generic_fentry_process_event+0x10d2>
    22d9:      	movl	$0x120, %edx            # imm = 0x120
    22de:      	addq	0x60(%rsp), %rdx
    22e3:      	leaq	0x4(%rbp), %rdi
    22e7:      	movl	$0x11, %ecx
    22ec:      	movl	$0x2d, %eax
    22f1:      	movl	$0x11, %esi
    22f6:      	callq	*%rax
    22f8:      	movq	%rax, %r12
    22fb:      	testq	%rax, %rax
    22fe:      	js	0x2abe <generic_fentry_process_event+0x270e>
    2304:      	leal	-0x1(%r12), %eax
    2309:      	movl	%eax, (%rbp)
    230c:      	addq	$0x3, %r12
    2310:      	jmp	0x2abe <generic_fentry_process_event+0x270e>
    2315:      	movq	0x38(%rsp), %rax
    231a:      	movq	0x48(%rsp), %rcx
    231f:      	leaq	(%rcx,%rax), %rbx
    2323:      	addq	$0x90, %rbx
    232a:      	movq	$0x0, 0x60(%rsp)
    2333:      	testb	$0x10, %r12b
    2337:      	jne	0x297c <generic_fentry_process_event+0x25cc>
    233d:      	movl	%r12d, %r15d
    2340:      	movq	0x58(%rsp), %rdx
    2345:      	andl	$0xf, %edx
    2348:      	xorl	%eax, %eax
    234a:      	movq	%rdx, %rcx
    234d:      	cmpl	$0x2, %edx
    2350:      	jle	0x2c2d <generic_fentry_process_event+0x287d>
    2356:      	cmpl	$0x3, %ecx
    2359:      	je	0x32db <generic_fentry_process_event+0x2f2b>
    235f:      	cmpl	$0x4, %ecx
    2362:      	je	0x32e8 <generic_fentry_process_event+0x2f38>
    2368:      	cmpl	$0x5, %ecx
    236b:      	jne	0x3303 <generic_fentry_process_event+0x2f53>
    2371:      	movq	0x48(%rsp), %rax
    2376:      	addq	$0x5e70, %rax           # imm = 0x5E70
    237c:      	jmp	0x3300 <generic_fentry_process_event+0x2f50>
    2381:      	movq	%r15, %rbx
    2384:      	leaq	0x28(%r15), %r13
    2388:      	leaq	0x40(%r15), %r12
    238c:      	movq	0x18(%rsp), %r15
    2391:      	leaq	0x8(%r15), %rdx
    2395:      	movl	$0x4, %ecx
    239a:      	movl	$0x4, %eax
    239f:      	movq	%rbx, %rdi
    23a2:      	movl	$0x4, %esi
    23a7:      	callq	*%rax
    23a9:      	leaq	0x4(%rbx), %rdi
    23ad:      	leaq	0xc(%r15), %rdx
    23b1:      	movl	$0x4, %ecx
    23b6:      	movl	$0x4, %eax
    23bb:      	movl	$0x4, %esi
    23c0:      	callq	*%rax
    23c2:      	leaq	0x10(%rbx), %rdi
    23c6:      	leaq	0x18(%r15), %rdx
    23ca:      	movl	$0x4, %ecx
    23cf:      	movl	$0x4, %eax
    23d4:      	movl	$0x4, %esi
    23d9:      	callq	*%rax
    23db:      	leaq	0x14(%rbx), %rdi
    23df:      	leaq	0x1c(%r15), %rdx
    23e3:      	movl	$0x4, %ecx
    23e8:      	movl	$0x4, %eax
    23ed:      	movl	$0x4, %esi
    23f2:      	callq	*%rax
    23f4:      	leaq	0x8(%rbx), %rdi
    23f8:      	leaq	0x10(%r15), %rdx
    23fc:      	movl	$0x4, %ecx
    2401:      	movl	$0x4, %eax
    2406:      	movl	$0x4, %esi
    240b:      	callq	*%rax
    240d:      	leaq	0xc(%rbx), %rdi
    2411:      	leaq	0x14(%r15), %rdx
    2415:      	movl	$0x4, %ecx
    241a:      	movl	$0x4, %eax
    241f:      	movl	$0x4, %esi
    2424:      	callq	*%rax
    2426:      	leaq	0x18(%rbx), %rdi
    242a:      	leaq	0x20(%r15), %rdx
    242e:      	movl	$0x4, %ecx
    2433:      	movl	$0x4, %eax
    2438:      	movl	$0x4, %esi
    243d:      	callq	*%rax
    243f:      	leaq	0x1c(%rbx), %rdi
    2443:      	leaq	0x24(%r15), %rdx
    2447:      	movl	$0x4, %ecx
    244c:      	movl	$0x4, %eax
    2451:      	movl	$0x4, %esi
    2456:      	callq	*%rax
    2458:      	movl	$0x0, 0x24(%rbx)
    245f:      	leaq	0x20(%rbx), %rdi
    2463:      	leaq	0x28(%r15), %rdx
    2467:      	movl	$0x4, %ecx
    246c:      	movl	$0x4, %eax
    2471:      	movl	$0x4, %esi
    2476:      	callq	*%rax
    2478:      	leaq	0x30(%rbx), %rdi
    247c:      	leaq	0x40(%r15), %rdx
    2480:      	movl	$0x8, %ecx
    2485:      	movl	$0x4, %eax
    248a:      	movl	$0x8, %esi
    248f:      	callq	*%rax
    2491:      	leaq	0x38(%rbx), %rdi
    2495:      	leaq	0x30(%r15), %rdx
    2499:      	movl	$0x8, %ecx
    249e:      	movl	$0x4, %eax
    24a3:      	movl	$0x8, %esi
    24a8:      	callq	*%rax
    24aa:      	leaq	0x38(%r15), %rdx
    24ae:      	movl	$0x8, %ecx
    24b3:      	movl	$0x4, %eax
    24b8:      	movq	%r13, %rdi
    24bb:      	movl	$0x8, %esi
    24c0:      	callq	*%rax
    24c2:      	addq	$0x90, %r15
    24c9:      	leaq	0x78(%rsp), %rdi
    24ce:      	movl	$0x8, %ecx
    24d3:      	movl	$0x4, %eax
    24d8:      	movl	$0x8, %esi
    24dd:      	movq	%r15, %rdx
    24e0:      	callq	*%rax
    24e2:      	movq	0x78(%rsp), %r13
    24e7:      	leaq	0xc8(%r13), %rdx
    24ee:      	movl	$0x4, %ecx
    24f3:      	movl	$0x4, %eax
    24f8:      	movq	%r12, %rdi
    24fb:      	movl	$0x4, %esi
    2500:      	callq	*%rax
    2502:      	leaq	0x44(%rbx), %rdi
    2506:      	leaq	0xcc(%r13), %rdx
    250d:      	movl	$0x4, %ecx
    2512:      	movl	$0x4, %eax
    2517:      	movl	$0x4, %esi
    251c:      	callq	*%rax
    251e:      	leaq	0x48(%rbx), %rdi
    2522:      	leaq	0xd0(%r13), %rdx
    2529:      	movl	$0x4, %ecx
    252e:      	movl	$0x4, %eax
    2533:      	movl	$0x4, %esi
    2538:      	callq	*%rax
    253a:      	addq	$0x4c, %rbx
    253e:      	addq	$0x158, %r13            # imm = 0x158
    2545:      	movl	$0x4, %ecx
    254a:      	movl	$0x4, %eax
    254f:      	movq	%rbx, %rdi
    2552:      	movl	$0x4, %esi
    2557:      	movq	%r13, %rdx
    255a:      	callq	*%rax
    255c:      	movl	$0x50, %ebp
    2561:      	jmp	0x3a30 <generic_fentry_process_event+0x3680>
    2566:      	movq	0x18(%rsp), %r12
    256b:      	leaq	0xc8(%r12), %rdx
    2573:      	movl	$0x4, %ecx
    2578:      	movl	$0x4, %eax
    257d:      	movq	%r15, %rdi
    2580:      	movl	$0x4, %esi
    2585:      	callq	*%rax
    2587:      	leaq	0x4(%r15), %rdi
    258b:      	leaq	0xcc(%r12), %rdx
    2593:      	movl	$0x4, %ecx
    2598:      	movl	$0x4, %eax
    259d:      	movl	$0x4, %esi
    25a2:      	callq	*%rax
    25a4:      	leaq	0x8(%r15), %rdi
    25a8:      	leaq	0xd0(%r12), %rdx
    25b0:      	movl	$0x4, %ecx
    25b5:      	movl	$0x4, %eax
    25ba:      	movl	$0x4, %esi
    25bf:      	callq	*%rax
    25c1:      	addq	$0xc, %r15
    25c5:      	addq	$0x158, %r12            # imm = 0x158
    25cc:      	movl	$0x4, %ecx
    25d1:      	movl	$0x4, %eax
    25d6:      	movq	%r15, %rdi
    25d9:      	movl	$0x4, %esi
    25de:      	movq	%r12, %rdx
    25e1:      	callq	*%rax
    25e3:      	movl	$0x10, %ebp
    25e8:      	jmp	0x3a30 <generic_fentry_process_event+0x3680>
    25ed:      	movq	0x18(%rsp), %r12
    25f2:      	leaq	0x38(%r12), %rdx
    25f7:      	movl	$0x4, %ecx
    25fc:      	movl	$0x4, %eax
    2601:      	movq	%r15, %rdi
    2604:      	movl	$0x4, %esi
    2609:      	callq	*%rax
    260b:      	leaq	0x4(%r15), %rdi
    260f:      	leaq	0x3c(%r12), %rdx
    2614:      	movl	$0x4, %ecx
    2619:      	movl	$0x4, %eax
    261e:      	movl	$0x4, %esi
    2623:      	callq	*%rax
    2625:      	leaq	0x8(%r15), %rdi
    2629:      	leaq	0x40(%r12), %rdx
    262e:      	movl	$0x4, %ecx
    2633:      	movl	$0x4, %eax
    2638:      	movl	$0x4, %esi
    263d:      	callq	*%rax
    263f:      	leaq	0xc(%r15), %rdi
    2643:      	leaq	0x44(%r12), %rdx
    2648:      	movl	$0x4, %ecx
    264d:      	movl	$0x4, %eax
    2652:      	movl	$0x4, %esi
    2657:      	callq	*%rax
    2659:      	addq	$0x10, %r15
    265d:      	subq	$-0x80, %r12
    2661:      	movl	$0x10, %ecx
    2666:      	movl	$0x4, %eax
    266b:      	movq	%r15, %rdi
    266e:      	movl	$0x10, %esi
    2673:      	movq	%r12, %rdx
    2676:      	callq	*%rax
    2678:      	movl	$0x20, %ebp
    267d:      	jmp	0x3a30 <generic_fentry_process_event+0x3680>
    2682:      	movl	$0x4, %ecx
    2687:      	movl	$0x4, %eax
    268c:      	movq	%r15, %rbx
    268f:      	movq	0x18(%rsp), %r15
    2694:      	movq	%rbx, %rdi
    2697:      	movl	$0x4, %esi
    269c:      	movq	%r15, %rdx
    269f:      	callq	*%rax
    26a1:      	leaq	0x4(%rbx), %rdi
    26a5:      	leaq	0x4(%r15), %rdx
    26a9:      	movl	$0x4, %ecx
    26ae:      	movl	$0x4, %eax
    26b3:      	movl	$0x4, %esi
    26b8:      	callq	*%rax
    26ba:      	addq	$0x8, %rbx
    26be:      	addq	$0x30, %r15
    26c2:      	movl	$0x10, %ecx
    26c7:      	movl	$0x4, %eax
    26cc:      	movq	%rbx, %rdi
    26cf:      	movl	$0x10, %esi
    26d4:      	movq	%r15, %rdx
    26d7:      	jmp	0x276c <generic_fentry_process_event+0x23bc>
    26dc:      	movq	0x18(%rsp), %r15
    26e1:      	leaq	0x4(%r15), %rdx
    26e5:      	leaq	0x78(%rsp), %rdi
    26ea:      	movl	$0x4, %ecx
    26ef:      	movl	$0x4, %eax
    26f4:      	movl	$0x4, %esi
    26f9:      	callq	*%rax
    26fb:      	movl	0x78(%rsp), %eax
    26ff:      	movq	0x38(%rsp), %rbx
    2704:      	movl	%eax, (%rbx)
    2706:      	leaq	0xc(%r15), %rdx
    270a:      	leaq	0x78(%rsp), %rdi
    270f:      	movl	$0x4, %ecx
    2714:      	movl	$0x4, %eax
    2719:      	movl	$0x4, %esi
    271e:      	callq	*%rax
    2720:      	movl	0x78(%rsp), %eax
    2724:      	movl	%eax, 0x4(%rbx)
    2727:      	addq	$0x50, %r15
    272b:      	leaq	0x78(%rsp), %rdi
    2730:      	movl	$0x8, %ecx
    2735:      	movl	$0x2d, %eax
    273a:      	movl	$0x8, %esi
    273f:      	movq	%r15, %rdx
    2742:      	callq	*%rax
    2744:      	addq	$0x8, %rbx
    2748:      	movl	$0x3f8, %edx            # imm = 0x3F8
    274d:      	movq	0x78(%rsp), %rcx
    2752:      	addq	%rdx, %rcx
    2755:      	movl	$0x10, %esi
    275a:      	movl	$0x2d, %eax
    275f:      	addq	0x78(%rsp), %rdx
    2764:      	movq	%rbx, %rdi
    2767:      	movl	$0x10, %esi
    276c:      	callq	*%rax
    276e:      	movl	$0x18, %ebp
    2773:      	jmp	0x3a30 <generic_fentry_process_event+0x3680>
    2778:      	movq	0x38(%rsp), %rax
    277d:      	movq	$0x0, 0x48(%rax)
    2785:      	movq	$0x0, 0x40(%rax)
    278d:      	movq	$0x0, 0x38(%rax)
    2795:      	movq	$0x0, 0x30(%rax)
    279d:      	movq	$0x0, 0x28(%rax)
    27a5:      	movq	$0x0, 0x20(%rax)
    27ad:      	movq	$0x0, 0x18(%rax)
    27b5:      	movq	$0x0, 0x10(%rax)
    27bd:      	movq	$0x0, 0x8(%rax)
    27c5:      	movq	$0x0, (%rax)
    27cc:      	leaq	0x78(%rsp), %rdi
    27d1:      	movl	$0x8, %ecx
    27d6:      	movl	$0x4, %eax
    27db:      	movq	0x18(%rsp), %rdx
    27e0:      	movl	$0x8, %esi
    27e5:      	callq	*%rax
    27e7:      	testq	%rax, %rax
    27ea:      	je	0x2ada <generic_fentry_process_event+0x272a>
    27f0:      	xorl	%ebp, %ebp
    27f2:      	jmp	0x3a30 <generic_fentry_process_event+0x3680>
    27f7:      	movq	0x38(%rsp), %rax
    27fc:      	movq	$0x0, 0x90(%r15,%rax)
    2808:      	movl	$0x8, %r12d
    280e:      	jmp	0x1482 <generic_fentry_process_event+0x10d2>
    2813:      	movq	$-0x1, %r12
    281a:      	jmp	0x1482 <generic_fentry_process_event+0x10d2>
    281f:      	movq	0x78(%rsp), %rcx
    2824:      	movl	$0x0, 0x68(%rsp)
    282c:      	movzwl	0x50(%rsp), %r15d
    2832:      	movq	(%rip), %rdi            # 0x2839 <generic_fentry_process_event+0x2489>
    2839:      	leaq	0x68(%rsp), %rsi
    283e:      	movl	$0x1, %eax
    2843:      	movq	%rcx, 0x30(%rsp)
    2848:      	leaq	(%rcx,%r15), %r14
    284c:      	callq	*%rax
    284e:      	testq	%rax, %rax
    2851:      	je	0x3c3a <generic_fentry_process_event+0x388a>
    2857:      	movq	%rax, %rbx
    285a:      	movw	%r15w, (%rax)
    285e:      	movb	$-0x1, 0x5(%rax)
    2862:      	movb	$0x0, 0x7(%rax)
    2866:      	movq	%rax, %r15
    2869:      	addq	$0x6, %r15
    286d:      	leaq	0x6(%r14), %rdx
    2871:      	movl	$0x1, %ecx
    2876:      	movl	$0x4, %eax
    287b:      	movq	%r15, %rdi
    287e:      	movl	$0x1, %esi
    2883:      	callq	*%rax
    2885:      	testq	%rax, %rax
    2888:      	js	0x3c3a <generic_fentry_process_event+0x388a>
    288e:      	movzbl	0x5(%rbx), %eax
    2892:      	cmpl	$0x32, %eax
    2895:      	jg	0x3218 <generic_fentry_process_event+0x2e68>
    289b:      	testl	%eax, %eax
    289d:      	je	0x32c0 <generic_fentry_process_event+0x2f10>
    28a3:      	cmpl	$0x2b, %eax
    28a6:      	je	0x32c0 <generic_fentry_process_event+0x2f10>
    28ac:      	cmpl	$0x2c, %eax
    28af:      	jne	0x361c <generic_fentry_process_event+0x326c>
    28b5:      	movw	$0x8, 0x2(%rbx)
    28bb:      	movw	$0x8, %ax
    28bf:      	jmp	0x355b <generic_fentry_process_event+0x31ab>
    28c4:      	leaq	0x48(%r12), %rdx
    28c9:      	movl	$0x10, %ecx
    28ce:      	movl	$0x4, %eax
    28d3:      	movq	%rbp, %rdi
    28d6:      	movl	$0x10, %esi
    28db:      	callq	*%rax
    28dd:      	leaq	0x38(%r12), %rdx
    28e2:      	movl	$0x10, %ecx
    28e7:      	movl	$0x4, %eax
    28ec:      	movq	%r13, %rdi
    28ef:      	movl	$0x10, %esi
    28f4:      	callq	*%rax
    28f6:      	leaq	0x20(%rbp), %rdi
    28fa:      	leaq	0xc(%r12), %r13
    28ff:      	addq	$0xe, %r12
    2903:      	movl	$0x2, %ecx
    2908:      	movl	$0x4, %eax
    290d:      	movl	$0x2, %esi
    2912:      	movq	%r12, %rdx
    2915:      	callq	*%rax
    2917:      	leaq	0x22(%rbp), %rdi
    291b:      	movl	$0x2, %ecx
    2920:      	movl	$0x4, %eax
    2925:      	movl	$0x2, %esi
    292a:      	movq	%r13, %rdx
    292d:      	callq	*%rax
    292f:      	movzwl	0x22(%rbp), %eax
    2933:      	movbew	%ax, 0x22(%rbp)
    2939:      	movq	0x60(%rsp), %rax
    293e:      	movq	%rax, 0x78(%rsp)
    2943:      	movq	(%rip), %rdi            # 0x294a <generic_fentry_process_event+0x259a>
    294a:      	leaq	0x78(%rsp), %rsi
    294f:      	movl	$0x1, %eax
    2954:      	callq	*%rax
    2956:      	testq	%rax, %rax
    2959:      	je	0x3dd9 <generic_fentry_process_event+0x3a29>
    295f:      	movl	(%rax), %ecx
    2961:      	movq	%r15, %rbp
    2964:      	movl	%ecx, 0x10(%r15)
    2968:      	movq	0x8(%rax), %rcx
    296c:      	movq	%rcx, 0x18(%r15)
    2970:      	movl	0x4(%rax), %eax
    2973:      	movl	%eax, 0x7c(%r15)
    2977:      	jmp	0x3dd9 <generic_fentry_process_event+0x3a29>
    297c:      	movl	$0xe, %eax
    2981:      	callq	*%rax
    2983:      	cmpq	$-0x16, %rax
    2987:      	jne	0x29ad <generic_fentry_process_event+0x25fd>
    2989:      	movq	0x8(%rsp), %rax
    298e:      	leaq	0x20(%rax), %rdx
    2992:      	leaq	0x78(%rsp), %rdi
    2997:      	movl	$0x8, %ecx
    299c:      	movl	$0x4, %eax
    29a1:      	movl	$0x8, %esi
    29a6:      	callq	*%rax
    29a8:      	movq	0x78(%rsp), %rax
    29ad:      	movq	0x48(%rsp), %rdx
    29b2:      	movq	0x8(%rdx), %rcx
    29b6:      	movq	0x60(%rdx), %rdx
    29ba:      	movq	%rcx, 0x78(%rsp)
    29bf:      	movq	0x18(%rsp), %rcx
    29c4:      	movq	%rcx, 0x80(%rsp)
    29cc:      	movq	$0x0, 0x88(%rsp)
    29d8:      	movq	%rdx, 0x68(%rsp)
    29dd:      	movq	%rax, 0x70(%rsp)
    29e2:      	movq	(%rip), %rdi            # 0x29e9 <generic_fentry_process_event+0x2639>
    29e9:      	xorl	%ecx, %ecx
    29eb:      	leaq	0x68(%rsp), %rsi
    29f0:      	leaq	0x78(%rsp), %rdx
    29f5:      	movl	$0x2, %eax
    29fa:      	xorl	%ecx, %ecx
    29fc:      	callq	*%rax
    29fe:      	testq	%rax, %rax
    2a01:      	je	0x3271 <generic_fentry_process_event+0x2ec1>
    2a07:      	negl	%eax
    2a09:      	movw	%ax, 0xc0(%rsp)
    2a11:      	movw	$0x5, 0xc2(%rsp)
    2a1b:      	movabsq	$0x200000046, %rax      # imm = 0x200000046
    2a25:      	movq	%rax, 0xc4(%rsp)
    2a2d:      	movq	(%rip), %rdi            # 0x2a34 <generic_fentry_process_event+0x2684>
    2a34:      	leaq	0xc0(%rsp), %rsi
    2a3c:      	movl	$0x1, %eax
    2a41:      	callq	*%rax
    2a43:      	testq	%rax, %rax
    2a46:      	je	0x3244 <generic_fentry_process_event+0x2e94>
    2a4c:      	incl	(%rax)
    2a4e:      	jmp	0x3271 <generic_fentry_process_event+0x2ec1>
    2a53:      	cmpl	$0x1, %eax
    2a56:      	je	0x2d2d <generic_fentry_process_event+0x297d>
    2a5c:      	cmpl	$0x2, %eax
    2a5f:      	jne	0x3113 <generic_fentry_process_event+0x2d63>
    2a65:      	movq	0x48(%rsp), %rax
    2a6a:      	addq	$0x5e58, %rax           # imm = 0x5E58
    2a70:      	jmp	0x2d38 <generic_fentry_process_event+0x2988>
    2a75:      	movq	%rbp, %rbx
    2a78:      	leaq	0x8(%rbp), %rdi
    2a7c:      	leaq	0x8(%r12), %rdx
    2a81:      	movl	$0x10, %ecx
    2a86:      	movl	$0x4, %eax
    2a8b:      	movl	$0x10, %esi
    2a90:      	callq	*%rax
    2a92:      	leaq	0x2(%rbp), %rdi
    2a96:      	addq	$0x2, %r12
    2a9a:      	movl	$0x2, %ecx
    2a9f:      	movl	$0x4, %eax
    2aa4:      	movl	$0x2, %esi
    2aa9:      	movq	%r12, %rdx
    2aac:      	callq	*%rax
    2aae:      	movzwl	0x2(%rbp), %eax
    2ab2:      	movbew	%ax, 0x2(%rbp)
    2ab8:      	movl	$0x18, %r12d
    2abe:      	movq	0x40(%rsp), %rax
    2ac3:      	movq	0x20(%rsp), %rcx
    2ac8:      	movl	$0x4, %esi
    2acd:      	movq	0x8(%rsp), %rbx
    2ad2:      	movq	%r15, %r14
    2ad5:      	jmp	0x1491 <generic_fentry_process_event+0x10e1>
    2ada:      	movq	0x38(%rsp), %rax
    2adf:      	leaq	0x10(%rax), %rdi
    2ae3:      	movq	0x78(%rsp), %rcx
    2ae8:      	movl	$0x3f, %edx
    2aed:      	movl	$0x2d, %eax
    2af2:      	movq	0x78(%rsp), %rdx
    2af7:      	movl	$0x3f, %esi
    2afc:      	callq	*%rax
    2afe:      	testq	%rax, %rax
    2b01:      	js	0x27f0 <generic_fentry_process_event+0x2440>
    2b07:      	movq	0x18(%rsp), %rbx
    2b0c:      	leaq	0x8(%rbx), %rdx
    2b10:      	leaq	0x68(%rsp), %rdi
    2b15:      	movl	$0x8, %ecx
    2b1a:      	movl	$0x4, %eax
    2b1f:      	movl	$0x8, %esi
    2b24:      	callq	*%rax
    2b26:      	movq	0x38(%rsp), %rax
    2b2b:      	leaq	0x8(%rax), %rdi
    2b2f:      	movl	$0x348, %edx            # imm = 0x348
    2b34:      	movq	0x68(%rsp), %rcx
    2b39:      	addq	%rdx, %rcx
    2b3c:      	movl	$0x8, %esi
    2b41:      	movl	$0x4, %eax
    2b46:      	addq	0x68(%rsp), %rdx
    2b4b:      	movl	$0x8, %esi
    2b50:      	callq	*%rax
    2b52:      	addq	$0x58, %rbx
    2b56:      	leaq	0x68(%rsp), %rdi
    2b5b:      	movl	$0x4, %ecx
    2b60:      	movl	$0x4, %eax
    2b65:      	movl	$0x4, %esi
    2b6a:      	movq	%rbx, %rdx
    2b6d:      	callq	*%rax
    2b6f:      	movl	$0x50, %ebp
    2b74:      	testq	%rax, %rax
    2b77:      	jne	0x3a30 <generic_fentry_process_event+0x3680>
    2b7d:      	xorl	%eax, %eax
    2b7f:      	cmpl	$0x0, 0x68(%rsp)
    2b84:      	setne	%al
    2b87:      	movq	0x38(%rsp), %rcx
    2b8c:      	movl	%eax, (%rcx)
    2b8e:      	jmp	0x3a30 <generic_fentry_process_event+0x3680>
    2b93:      	addq	$0x90, %r15
    2b9a:      	movq	0xb8(%rsp), %rax
    2ba2:      	movl	$0x0, 0x4(%r15,%rax)
    2bab:      	addq	%r15, %rax
    2bae:      	addq	$0x8, %rax
    2bb2:      	movq	%rax, 0x58(%rsp)
    2bb7:      	movl	$0xc, %ebp
    2bbc:      	movq	0x18(%rsp), %rax
    2bc1:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    2bc7:      	movl	$0xfff, %r13d           # imm = 0xFFF
    2bcd:      	cmovbq	%rax, %r13
    2bd1:      	movq	0x58(%rsp), %rax
    2bd6:      	leaq	0x8(%rax), %rdi
    2bda:      	movl	$0x4, %eax
    2bdf:      	movq	0x48(%rsp), %rdx
    2be4:      	movl	%r13d, %esi
    2be7:      	callq	*%rax
    2be9:      	testl	%eax, %eax
    2beb:      	js	0x2c08 <generic_fentry_process_event+0x2858>
    2bed:      	movq	0x58(%rsp), %rax
    2bf2:      	movq	0x18(%rsp), %rcx
    2bf7:      	movl	%ecx, (%rax)
    2bf9:      	movl	%r13d, 0x4(%rax)
    2bfd:      	addq	%r13, %rbp
    2c00:      	movq	%rbp, %r12
    2c03:      	jmp	0x1482 <generic_fentry_process_event+0x10d2>
    2c08:      	movq	0x58(%rsp), %rax
    2c0d:      	movl	$0xfffffffe, (%rax)     # imm = 0xFFFFFFFE
    2c13:      	movq	0x40(%rsp), %rax
    2c18:      	movq	0x20(%rsp), %rcx
    2c1d:      	movl	$0x4, %esi
    2c22:      	movl	$0x4, %r12d
    2c28:      	jmp	0x1491 <generic_fentry_process_event+0x10e1>
    2c2d:      	cmpl	$0x1, %ecx
    2c30:      	je	0x32f5 <generic_fentry_process_event+0x2f45>
    2c36:      	cmpl	$0x2, %ecx
    2c39:      	jne	0x3303 <generic_fentry_process_event+0x2f53>
    2c3f:      	movq	0x48(%rsp), %rax
    2c44:      	addq	$0x5e58, %rax           # imm = 0x5E58
    2c4a:      	jmp	0x3300 <generic_fentry_process_event+0x2f50>
    2c4f:      	leaq	0x48(%r12), %rdx
    2c54:      	movl	$0x10, %ecx
    2c59:      	movl	$0x4, %eax
    2c5e:      	movq	0x38(%rsp), %rdi
    2c63:      	movl	$0x10, %esi
    2c68:      	callq	*%rax
    2c6a:      	leaq	0x38(%r12), %rdx
    2c6f:      	movl	$0x10, %ecx
    2c74:      	movl	$0x4, %eax
    2c79:      	movq	%r13, %rdi
    2c7c:      	movl	$0x10, %esi
    2c81:      	callq	*%rax
    2c83:      	movq	0x38(%rsp), %rbx
    2c88:      	leaq	0x20(%rbx), %rdi
    2c8c:      	leaq	0xc(%r12), %r13
    2c91:      	addq	$0xe, %r12
    2c95:      	movl	$0x2, %ecx
    2c9a:      	movl	$0x4, %eax
    2c9f:      	movl	$0x2, %esi
    2ca4:      	movq	%r12, %rdx
    2ca7:      	callq	*%rax
    2ca9:      	leaq	0x22(%rbx), %rdi
    2cad:      	movl	$0x2, %ecx
    2cb2:      	movl	$0x4, %eax
    2cb7:      	movl	$0x2, %esi
    2cbc:      	movq	%r13, %rdx
    2cbf:      	callq	*%rax
    2cc1:      	movzwl	0x22(%rbx), %eax
    2cc5:      	movbew	%ax, 0x22(%rbx)
    2ccb:      	movq	0x38(%rsp), %rax
    2cd0:      	movq	0x28(%rax), %rax
    2cd4:      	movq	%rax, 0x78(%rsp)
    2cd9:      	movq	(%rip), %rdi            # 0x2ce0 <generic_fentry_process_event+0x2930>
    2ce0:      	leaq	0x78(%rsp), %rsi
    2ce5:      	movl	$0x1, %eax
    2cea:      	callq	*%rax
    2cec:      	testq	%rax, %rax
    2cef:      	je	0x2d09 <generic_fentry_process_event+0x2959>
    2cf1:      	movl	(%rax), %ecx
    2cf3:      	movq	0x48(%rsp), %rdx
    2cf8:      	movl	%ecx, 0x10(%rdx)
    2cfb:      	movq	0x8(%rax), %rcx
    2cff:      	movq	%rcx, 0x18(%rdx)
    2d03:      	movl	0x4(%rax), %eax
    2d06:      	movl	%eax, 0x7c(%rdx)
    2d09:      	movl	$0x40, %ebp
    2d0e:      	jmp	0x3a30 <generic_fentry_process_event+0x3680>
    2d13:      	movq	0x48(%rsp), %rax
    2d18:      	addq	$0x5e60, %rax           # imm = 0x5E60
    2d1e:      	jmp	0x2d38 <generic_fentry_process_event+0x2988>
    2d20:      	movq	0x48(%rsp), %rax
    2d25:      	addq	$0x5e68, %rax           # imm = 0x5E68
    2d2b:      	jmp	0x2d38 <generic_fentry_process_event+0x2988>
    2d2d:      	movq	0x48(%rsp), %rax
    2d32:      	addq	$0x5e50, %rax           # imm = 0x5E50
    2d38:      	movq	(%rax), %r12
    2d3b:      	testb	$0x10, 0x58(%rsp)
    2d40:      	jne	0x3127 <generic_fentry_process_event+0x2d77>
    2d46:      	testq	%r12, %r12
    2d49:      	je	0x31fa <generic_fentry_process_event+0x2e4a>
    2d4f:      	leaq	0x78(%rsp), %rdi
    2d54:      	movl	$0x4, %ebp
    2d59:      	movl	$0x10, %ecx
    2d5e:      	movl	$0x4, %eax
    2d63:      	movq	0x18(%rsp), %rdx
    2d68:      	movl	$0x10, %esi
    2d6d:      	callq	*%rax
    2d6f:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2d74:      	testl	%eax, %eax
    2d76:      	js	0x3104 <generic_fentry_process_event+0x2d54>
    2d7c:      	movq	0x80(%rsp), %r14
    2d84:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2d89:      	cmpq	$0xffe, %r14            # imm = 0xFFE
    2d90:      	ja	0x3104 <generic_fentry_process_event+0x2d54>
    2d96:      	movq	0xb8(%rsp), %rax
    2d9e:      	leaq	0xc(%rax), %r15
    2da2:      	leaq	(%r15,%r13), %rdi
    2da6:      	movq	0x78(%rsp), %rcx
    2dab:      	movl	$0x4, %eax
    2db0:      	movq	0x78(%rsp), %rdx
    2db5:      	movl	%r14d, %esi
    2db8:      	callq	*%rax
    2dba:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2dbf:      	testl	%eax, %eax
    2dc1:      	js	0x3104 <generic_fentry_process_event+0x2d54>
    2dc7:      	cmpq	$0x1, %r12
    2dcb:      	je	0x31fd <generic_fentry_process_event+0x2e4d>
    2dd1:      	movq	0x18(%rsp), %rax
    2dd6:      	leaq	0x10(%rax), %rdx
    2dda:      	leaq	0x78(%rsp), %rdi
    2ddf:      	movl	$0x4, %ebp
    2de4:      	movl	$0x10, %ecx
    2de9:      	movl	$0x4, %eax
    2dee:      	movl	$0x10, %esi
    2df3:      	callq	*%rax
    2df5:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2dfa:      	testl	%eax, %eax
    2dfc:      	js	0x3104 <generic_fentry_process_event+0x2d54>
    2e02:      	movq	0x80(%rsp), %rbx
    2e0a:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2e0f:      	cmpq	$0xffe, %rbx            # imm = 0xFFE
    2e16:      	ja	0x3104 <generic_fentry_process_event+0x2d54>
    2e1c:      	addq	%r14, %r15
    2e1f:      	leaq	(%r15,%r13), %rdi
    2e23:      	movq	0x78(%rsp), %rcx
    2e28:      	movl	$0x4, %eax
    2e2d:      	movq	0x78(%rsp), %rdx
    2e32:      	movl	%ebx, %esi
    2e34:      	callq	*%rax
    2e36:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2e3b:      	testl	%eax, %eax
    2e3d:      	js	0x3104 <generic_fentry_process_event+0x2d54>
    2e43:      	addq	%rbx, %r14
    2e46:      	cmpq	$0x3, %r12
    2e4a:      	jb	0x31fd <generic_fentry_process_event+0x2e4d>
    2e50:      	movq	0x18(%rsp), %rax
    2e55:      	leaq	0x20(%rax), %rdx
    2e59:      	leaq	0x78(%rsp), %rdi
    2e5e:      	movl	$0x4, %ebp
    2e63:      	movl	$0x10, %ecx
    2e68:      	movl	$0x4, %eax
    2e6d:      	movl	$0x10, %esi
    2e72:      	callq	*%rax
    2e74:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2e79:      	testl	%eax, %eax
    2e7b:      	js	0x3104 <generic_fentry_process_event+0x2d54>
    2e81:      	movq	0x80(%rsp), %rax
    2e89:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2e8e:      	movq	%rax, 0x30(%rsp)
    2e93:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2e99:      	ja	0x3104 <generic_fentry_process_event+0x2d54>
    2e9f:      	addq	%r15, %rbx
    2ea2:      	movl	%ebx, %edi
    2ea4:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2eaa:      	addq	%r13, %rdi
    2ead:      	movq	0x78(%rsp), %rcx
    2eb2:      	movl	$0x4, %eax
    2eb7:      	movq	0x30(%rsp), %rsi
    2ebc:      	movq	0x78(%rsp), %rdx
    2ec1:      	callq	*%rax
    2ec3:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2ec8:      	testl	%eax, %eax
    2eca:      	js	0x3104 <generic_fentry_process_event+0x2d54>
    2ed0:      	addq	0x30(%rsp), %r14
    2ed5:      	cmpq	$0x3, %r12
    2ed9:      	je	0x31fd <generic_fentry_process_event+0x2e4d>
    2edf:      	movq	0x18(%rsp), %rax
    2ee4:      	leaq	0x30(%rax), %rdx
    2ee8:      	leaq	0x78(%rsp), %rdi
    2eed:      	movl	$0x4, %ebp
    2ef2:      	movl	$0x10, %ecx
    2ef7:      	movl	$0x4, %eax
    2efc:      	movl	$0x10, %esi
    2f01:      	callq	*%rax
    2f03:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2f08:      	testl	%eax, %eax
    2f0a:      	js	0x3104 <generic_fentry_process_event+0x2d54>
    2f10:      	movq	0x80(%rsp), %rax
    2f18:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2f1d:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2f23:      	ja	0x3104 <generic_fentry_process_event+0x2d54>
    2f29:      	movq	%rax, %r15
    2f2c:      	movq	0x30(%rsp), %rdi
    2f31:      	addq	%rbx, %rdi
    2f34:      	movq	%rdi, %rbx
    2f37:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2f3d:      	addq	%r13, %rdi
    2f40:      	movq	0x78(%rsp), %rcx
    2f45:      	movl	$0x4, %eax
    2f4a:      	movq	%r15, %rsi
    2f4d:      	movq	0x78(%rsp), %rdx
    2f52:      	callq	*%rax
    2f54:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2f59:      	testl	%eax, %eax
    2f5b:      	js	0x3104 <generic_fentry_process_event+0x2d54>
    2f61:      	addq	%r15, %r14
    2f64:      	cmpq	$0x5, %r12
    2f68:      	jb	0x31fd <generic_fentry_process_event+0x2e4d>
    2f6e:      	movq	0x18(%rsp), %rax
    2f73:      	leaq	0x40(%rax), %rdx
    2f77:      	leaq	0x78(%rsp), %rdi
    2f7c:      	movl	$0x4, %ebp
    2f81:      	movl	$0x10, %ecx
    2f86:      	movl	$0x4, %eax
    2f8b:      	movl	$0x10, %esi
    2f90:      	callq	*%rax
    2f92:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2f97:      	testl	%eax, %eax
    2f99:      	js	0x3104 <generic_fentry_process_event+0x2d54>
    2f9f:      	movq	0x80(%rsp), %rax
    2fa7:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2fac:      	movq	%rax, 0x30(%rsp)
    2fb1:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2fb7:      	ja	0x3104 <generic_fentry_process_event+0x2d54>
    2fbd:      	movq	%r15, %rdi
    2fc0:      	addq	%rbx, %rdi
    2fc3:      	movq	%rdi, %r15
    2fc6:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2fcc:      	addq	%r13, %rdi
    2fcf:      	movq	0x78(%rsp), %rcx
    2fd4:      	movl	$0x4, %eax
    2fd9:      	movq	0x30(%rsp), %rsi
    2fde:      	movq	0x78(%rsp), %rdx
    2fe3:      	callq	*%rax
    2fe5:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2fea:      	testl	%eax, %eax
    2fec:      	js	0x3104 <generic_fentry_process_event+0x2d54>
    2ff2:      	addq	0x30(%rsp), %r14
    2ff7:      	cmpq	$0x5, %r12
    2ffb:      	je	0x31fd <generic_fentry_process_event+0x2e4d>
    3001:      	movq	0x18(%rsp), %rax
    3006:      	leaq	0x50(%rax), %rdx
    300a:      	leaq	0x78(%rsp), %rdi
    300f:      	movl	$0x4, %ebp
    3014:      	movl	$0x10, %ecx
    3019:      	movl	$0x4, %eax
    301e:      	movl	$0x10, %esi
    3023:      	callq	*%rax
    3025:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    302a:      	testl	%eax, %eax
    302c:      	js	0x3104 <generic_fentry_process_event+0x2d54>
    3032:      	movq	0x80(%rsp), %rbx
    303a:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    303f:      	cmpq	$0xffe, %rbx            # imm = 0xFFE
    3046:      	ja	0x3104 <generic_fentry_process_event+0x2d54>
    304c:      	movq	0x30(%rsp), %rdi
    3051:      	addq	%r15, %rdi
    3054:      	movq	%rdi, %r15
    3057:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    305d:      	addq	%r13, %rdi
    3060:      	movq	0x78(%rsp), %rcx
    3065:      	movl	$0x4, %eax
    306a:      	movq	0x78(%rsp), %rdx
    306f:      	movl	%ebx, %esi
    3071:      	callq	*%rax
    3073:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3078:      	testl	%eax, %eax
    307a:      	js	0x3104 <generic_fentry_process_event+0x2d54>
    3080:      	addq	%rbx, %r14
    3083:      	cmpq	$0x7, %r12
    3087:      	jb	0x31fd <generic_fentry_process_event+0x2e4d>
    308d:      	movq	0x18(%rsp), %rdx
    3092:      	addq	$0x60, %rdx
    3096:      	leaq	0x78(%rsp), %rdi
    309b:      	movl	$0x4, %ebp
    30a0:      	movl	$0x10, %ecx
    30a5:      	movl	$0x4, %eax
    30aa:      	movl	$0x10, %esi
    30af:      	callq	*%rax
    30b1:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    30b6:      	testl	%eax, %eax
    30b8:      	js	0x3104 <generic_fentry_process_event+0x2d54>
    30ba:      	movq	0x80(%rsp), %r12
    30c2:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    30c7:      	cmpq	$0xffe, %r12            # imm = 0xFFE
    30ce:      	ja	0x3104 <generic_fentry_process_event+0x2d54>
    30d0:      	addq	%r15, %rbx
    30d3:      	andl	$0x3fff, %ebx           # imm = 0x3FFF
    30d9:      	addq	%r13, %rbx
    30dc:      	movq	0x78(%rsp), %rcx
    30e1:      	movl	$0x4, %eax
    30e6:      	movq	0x78(%rsp), %rdx
    30eb:      	movq	%rbx, %rdi
    30ee:      	movl	%r12d, %esi
    30f1:      	callq	*%rax
    30f3:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    30f8:      	testl	%eax, %eax
    30fa:      	js	0x3104 <generic_fentry_process_event+0x2d54>
    30fc:      	addq	%r12, %r14
    30ff:      	jmp	0x31fd <generic_fentry_process_event+0x2e4d>
    3104:      	movq	0x38(%rsp), %rax
    3109:      	movl	%ecx, (%r13,%rax)
    310e:      	jmp	0x3a30 <generic_fentry_process_event+0x3680>
    3113:      	xorl	%r12d, %r12d
    3116:      	movl	$0x0, %r14d
    311c:      	testb	$0x10, 0x58(%rsp)
    3121:      	je	0x31fd <generic_fentry_process_event+0x2e4d>
    3127:      	movl	$0xe, %eax
    312c:      	callq	*%rax
    312e:      	cmpq	$-0x16, %rax
    3132:      	jne	0x3158 <generic_fentry_process_event+0x2da8>
    3134:      	movq	0x8(%rsp), %rax
    3139:      	leaq	0x20(%rax), %rdx
    313d:      	leaq	0x78(%rsp), %rdi
    3142:      	movl	$0x8, %ecx
    3147:      	movl	$0x4, %eax
    314c:      	movl	$0x8, %esi
    3151:      	callq	*%rax
    3153:      	movq	0x78(%rsp), %rax
    3158:      	movq	0x48(%rsp), %rdx
    315d:      	movq	0x8(%rdx), %rcx
    3161:      	movq	0x60(%rdx), %rdx
    3165:      	movq	%rcx, 0x78(%rsp)
    316a:      	movq	0x18(%rsp), %rcx
    316f:      	movq	%rcx, 0x80(%rsp)
    3177:      	movq	%r12, 0x88(%rsp)
    317f:      	movq	%rdx, 0x68(%rsp)
    3184:      	movq	%rax, 0x70(%rsp)
    3189:      	movq	(%rip), %rdi            # 0x3190 <generic_fentry_process_event+0x2de0>
    3190:      	xorl	%ecx, %ecx
    3192:      	leaq	0x68(%rsp), %rsi
    3197:      	leaq	0x78(%rsp), %rdx
    319c:      	movl	$0x2, %eax
    31a1:      	xorl	%ecx, %ecx
    31a3:      	callq	*%rax
    31a5:      	testq	%rax, %rax
    31a8:      	je	0x32a8 <generic_fentry_process_event+0x2ef8>
    31ae:      	negl	%eax
    31b0:      	movw	%ax, 0xc0(%rsp)
    31b8:      	movw	$0x5, 0xc2(%rsp)
    31c2:      	movabsq	$0x200000057, %rax      # imm = 0x200000057
    31cc:      	movq	%rax, 0xc4(%rsp)
    31d4:      	movq	(%rip), %rdi            # 0x31db <generic_fentry_process_event+0x2e2b>
    31db:      	leaq	0xc0(%rsp), %rsi
    31e3:      	movl	$0x1, %eax
    31e8:      	callq	*%rax
    31ea:      	testq	%rax, %rax
    31ed:      	je	0x3281 <generic_fentry_process_event+0x2ed1>
    31f3:      	incl	(%rax)
    31f5:      	jmp	0x32a8 <generic_fentry_process_event+0x2ef8>
    31fa:      	xorl	%r14d, %r14d
    31fd:      	movq	0x38(%rsp), %rax
    3202:      	movl	%r14d, (%r13,%rax)
    3207:      	movl	%r14d, 0x4(%r13,%rax)
    320c:      	addq	$0x8, %r14
    3210:      	movq	%r14, %rbp
    3213:      	jmp	0x3a30 <generic_fentry_process_event+0x3680>
    3218:      	cmpl	$0x33, %eax
    321b:      	je	0x354c <generic_fentry_process_event+0x319c>
    3221:      	cmpl	$0x3c, %eax
    3224:      	je	0x32c0 <generic_fentry_process_event+0x2f10>
    322a:      	cmpl	$0xff, %eax
    322f:      	jne	0x361c <generic_fentry_process_event+0x326c>
    3235:      	movw	$0x28, 0x2(%rbx)
    323b:      	movw	$0x28, %ax
    323f:      	jmp	0x355b <generic_fentry_process_event+0x31ab>
    3244:      	movl	$0x1, 0xd0(%rsp)
    324f:      	movq	(%rip), %rdi            # 0x3256 <generic_fentry_process_event+0x2ea6>
    3256:      	xorl	%ecx, %ecx
    3258:      	leaq	0xc0(%rsp), %rsi
    3260:      	leaq	0xd0(%rsp), %rdx
    3268:      	movl	$0x2, %eax
    326d:      	xorl	%ecx, %ecx
    326f:      	callq	*%rax
    3271:      	movl	$0xfffffffc, (%rbx)     # imm = 0xFFFFFFFC
    3277:      	movl	$0x4, %ebp
    327c:      	jmp	0x3a30 <generic_fentry_process_event+0x3680>
    3281:      	movl	$0x1, 0x50(%rsp)
    3289:      	movq	(%rip), %rdi            # 0x3290 <generic_fentry_process_event+0x2ee0>
    3290:      	xorl	%ecx, %ecx
    3292:      	leaq	0xc0(%rsp), %rsi
    329a:      	leaq	0x50(%rsp), %rdx
    329f:      	movl	$0x2, %eax
    32a4:      	xorl	%ecx, %ecx
    32a6:      	callq	*%rax
    32a8:      	movq	0x38(%rsp), %rax
    32ad:      	movl	$0xfffffffc, (%r13,%rax) # imm = 0xFFFFFFFC
    32b6:      	movl	$0x4, %ebp
    32bb:      	jmp	0x3a30 <generic_fentry_process_event+0x3680>
    32c0:      	movzbl	0x7(%rbx), %eax
    32c4:      	leal	0x8(,%rax,8), %eax
    32cb:      	jmp	0x3557 <generic_fentry_process_event+0x31a7>
    32d0:      	movl	$0x4, %r12d
    32d6:      	jmp	0x1482 <generic_fentry_process_event+0x10d2>
    32db:      	movq	0x48(%rsp), %rax
    32e0:      	addq	$0x5e60, %rax           # imm = 0x5E60
    32e6:      	jmp	0x3300 <generic_fentry_process_event+0x2f50>
    32e8:      	movq	0x48(%rsp), %rax
    32ed:      	addq	$0x5e68, %rax           # imm = 0x5E68
    32f3:      	jmp	0x3300 <generic_fentry_process_event+0x2f50>
    32f5:      	movq	0x48(%rsp), %rax
    32fa:      	addq	$0x5e50, %rax           # imm = 0x5E50
    3300:      	movq	(%rax), %rax
    3303:      	movq	%rax, 0x50(%rsp)
    3308:      	leaq	0x60(%rsp), %rdi
    330d:      	leaq	0x50(%rsp), %rdx
    3312:      	movl	$0x8, %ecx
    3317:      	movl	$0x4, %eax
    331c:      	movl	$0x8, %ebp
    3321:      	movl	$0x8, %esi
    3326:      	callq	*%rax
    3328:      	movq	0x60(%rsp), %r14
    332d:      	testb	$0x20, %r15b
    3331:      	je	0x3498 <generic_fentry_process_event+0x30e8>
    3337:      	cmpq	$0x1000, %r14           # imm = 0x1000
    333e:      	jb	0x346f <generic_fentry_process_event+0x30bf>
    3344:      	movl	$0x1, (%rbx)
    334a:      	movl	$0x0, 0x68(%rsp)
    3352:      	movq	(%rip), %rdi            # 0x3359 <generic_fentry_process_event+0x2fa9>
    3359:      	leaq	0x68(%rsp), %rsi
    335e:      	movl	$0x1, %eax
    3363:      	callq	*%rax
    3365:      	movq	%rax, 0x30(%rsp)
    336a:      	testq	%rax, %rax
    336d:      	je	0x34d5 <generic_fentry_process_event+0x3125>
    3373:      	movq	0x30(%rsp), %r12
    3378:      	movl	$0x18, (%r12)
    3380:      	movl	$0xe, %eax
    3385:      	callq	*%rax
    3387:      	leaq	0x10(%r12), %r15
    338c:      	movq	%rax, 0x10(%r12)
    3391:      	cmpq	$-0x16, %rax
    3395:      	jne	0x33be <generic_fentry_process_event+0x300e>
    3397:      	movq	0x8(%rsp), %rax
    339c:      	leaq	0x20(%rax), %rdx
    33a0:      	leaq	0x78(%rsp), %rdi
    33a5:      	movl	$0x8, %ecx
    33aa:      	movl	$0x4, %eax
    33af:      	movl	$0x8, %esi
    33b4:      	callq	*%rax
    33b6:      	movq	0x78(%rsp), %rax
    33bb:      	movq	%rax, (%r15)
    33be:      	movl	$0x7d, %eax
    33c3:      	callq	*%rax
    33c5:      	movq	0x30(%rsp), %r13
    33ca:      	movq	%rax, 0x18(%r13)
    33ce:      	movq	(%r15), %rax
    33d1:      	movq	0x8(%r15), %rcx
    33d5:      	movq	%rax, 0x14(%rbx)
    33d9:      	movq	%rcx, 0x1c(%rbx)
    33dd:      	addq	$0x20, %r13
    33e1:      	movl	$0xa, %r15d
    33e7:      	xorl	%r12d, %r12d
    33ea:      	movq	%r14, %rbp
    33ed:      	subq	%r12, %rbp
    33f0:      	js	0x364e <generic_fentry_process_event+0x329e>
    33f6:      	movq	0x18(%rsp), %rax
    33fb:      	leaq	(%r12,%rax), %rdx
    33ff:      	cmpq	$0x7fe0, %rbp           # imm = 0x7FE0
    3406:      	movl	$0x7fe0, %eax           # imm = 0x7FE0
    340b:      	cmovaeq	%rax, %rbp
    340f:      	movl	$0x4, %eax
    3414:      	movq	%r13, %rdi
    3417:      	movl	%ebp, %esi
    3419:      	callq	*%rax
    341b:      	testl	%eax, %eax
    341d:      	js	0x3448 <generic_fentry_process_event+0x3098>
    341f:      	leal	0x20(%rbp), %r8d
    3423:      	movq	0x30(%rsp), %rcx
    3428:      	movl	%r8d, 0x4(%rcx)
    342c:      	movl	$0x19, %eax
    3431:      	movq	0x8(%rsp), %rdi
    3436:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    343b:      	movq	(%rip), %rsi            # 0x3442 <generic_fentry_process_event+0x3092>
    3442:      	callq	*%rax
    3444:      	testl	%eax, %eax
    3446:      	jns	0x344b <generic_fentry_process_event+0x309b>
    3448:      	movslq	%eax, %rbp
    344b:      	testl	%ebp, %ebp
    344d:      	js	0x3657 <generic_fentry_process_event+0x32a7>
    3453:      	andl	$0x7fffffff, %ebp       # imm = 0x7FFFFFFF
    3459:      	addq	%rbp, %r12
    345c:      	cmpq	%r14, %r12
    345f:      	je	0x36b1 <generic_fentry_process_event+0x3301>
    3465:      	decl	%r15d
    3468:      	jne	0x33ea <generic_fentry_process_event+0x303a>
    346a:      	jmp	0x39f6 <generic_fentry_process_event+0x3646>
    346f:      	movq	0x48(%rsp), %rcx
    3474:      	addq	$0x90, %rcx
    347b:      	movq	0xb8(%rsp), %rax
    3483:      	movl	$0x0, 0x4(%rcx,%rax)
    348b:      	leaq	(%rcx,%rax), %rbx
    348f:      	addq	$0x8, %rbx
    3493:      	movl	$0xc, %ebp
    3498:      	cmpq	$0xfff, %r14            # imm = 0xFFF
    349f:      	movl	$0xfff, %r13d           # imm = 0xFFF
    34a5:      	cmovbq	%r14, %r13
    34a9:      	leaq	0x8(%rbx), %rdi
    34ad:      	movl	$0x4, %eax
    34b2:      	movq	0x18(%rsp), %rdx
    34b7:      	movl	%r13d, %esi
    34ba:      	callq	*%rax
    34bc:      	testl	%eax, %eax
    34be:      	js	0x34cf <generic_fentry_process_event+0x311f>
    34c0:      	movl	%r14d, (%rbx)
    34c3:      	movl	%r13d, 0x4(%rbx)
    34c7:      	addq	%r13, %rbp
    34ca:      	jmp	0x3a30 <generic_fentry_process_event+0x3680>
    34cf:      	movl	$0xfffffffe, (%rbx)     # imm = 0xFFFFFFFE
    34d5:      	movl	$0x4, %ebp
    34da:      	jmp	0x3a30 <generic_fentry_process_event+0x3680>
    34df:      	movq	$-0x1, %r12
    34e6:      	jmp	0x34eb <generic_fentry_process_event+0x313b>
    34e8:      	movq	%r13, %r12
    34eb:      	movl	$0x0, 0x78(%rsp)
    34f3:      	movq	(%rip), %rdi            # 0x34fa <generic_fentry_process_event+0x314a>
    34fa:      	leaq	0x78(%rsp), %rsi
    34ff:      	movl	$0x1, %eax
    3504:      	callq	*%rax
    3506:      	testq	%rax, %rax
    3509:      	je	0x38a3 <generic_fentry_process_event+0x34f3>
    350f:      	cmpq	$-0xc, %r12
    3513:      	jg	0x3625 <generic_fentry_process_event+0x3275>
    3519:      	cmpq	$-0x1c, %r12
    351d:      	je	0x3879 <generic_fentry_process_event+0x34c9>
    3523:      	cmpq	$-0x16, %r12
    3527:      	je	0x3891 <generic_fentry_process_event+0x34e1>
    352d:      	cmpq	$-0x10, %r12
    3531:      	jne	0x3889 <generic_fentry_process_event+0x34d9>
    3537:      	addq	$0x558, %rax            # imm = 0x558
    353d:      	jmp	0x389f <generic_fentry_process_event+0x34ef>
    3542:      	movq	0x18(%rsp), %r12
    3547:      	jmp	0x38a3 <generic_fentry_process_event+0x34f3>
    354c:      	movzbl	0x7(%rbx), %eax
    3550:      	leal	0x8(,%rax,4), %eax
    3557:      	movw	%ax, 0x2(%rbx)
    355b:      	addw	(%rbx), %ax
    355e:      	movw	%ax, (%rbx)
    3561:      	movzbl	0x6(%rbx), %r12d
    3566:      	cmpq	$0x3c, %r12
    356a:      	ja	0x3dfd <generic_fentry_process_event+0x3a4d>
    3570:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    357a:      	btq	%r12, %rcx
    357e:      	jae	0x3dfd <generic_fentry_process_event+0x3a4d>
    3584:      	movb	%r12b, 0x5(%rbx)
    3588:      	movzwl	%ax, %ecx
    358b:      	movq	0x30(%rsp), %rsi
    3590:      	addq	%rsi, %rcx
    3593:      	movl	$0x2, %edx
    3598:      	movl	$0x4, %eax
    359d:      	movzwl	(%rbx), %edx
    35a0:      	addq	%rsi, %rdx
    35a3:      	movq	%r15, %rdi
    35a6:      	movl	$0x2, %esi
    35ab:      	callq	*%rax
    35ad:      	testq	%rax, %rax
    35b0:      	js	0x3c3a <generic_fentry_process_event+0x388a>
    35b6:      	movzbl	0x5(%rbx), %eax
    35ba:      	cmpl	$0x32, %eax
    35bd:      	jg	0x35e0 <generic_fentry_process_event+0x3230>
    35bf:      	testl	%eax, %eax
    35c1:      	je	0x3608 <generic_fentry_process_event+0x3258>
    35c3:      	cmpl	$0x2b, %eax
    35c6:      	je	0x3608 <generic_fentry_process_event+0x3258>
    35c8:      	cmpl	$0x2c, %eax
    35cb:      	jne	0x36ca <generic_fentry_process_event+0x331a>
    35d1:      	movw	$0x8, 0x2(%rbx)
    35d7:      	movw	$0x8, %ax
    35db:      	jmp	0x36ce <generic_fentry_process_event+0x331e>
    35e0:      	cmpl	$0x33, %eax
    35e3:      	je	0x36b9 <generic_fentry_process_event+0x3309>
    35e9:      	cmpl	$0x3c, %eax
    35ec:      	je	0x3608 <generic_fentry_process_event+0x3258>
    35ee:      	cmpl	$0xff, %eax
    35f3:      	jne	0x36ca <generic_fentry_process_event+0x331a>
    35f9:      	movw	$0x28, 0x2(%rbx)
    35ff:      	movw	$0x28, %ax
    3603:      	jmp	0x36ce <generic_fentry_process_event+0x331e>
    3608:      	movzbl	0x7(%rbx), %eax
    360c:      	leal	0x8(,%rax,8), %eax
    3613:      	movw	%ax, 0x2(%rbx)
    3617:      	jmp	0x36ce <generic_fentry_process_event+0x331e>
    361c:      	movzwl	0x2(%rbx), %eax
    3620:      	jmp	0x355b <generic_fentry_process_event+0x31ab>
    3625:      	cmpq	$-0xb, %r12
    3629:      	je	0x3881 <generic_fentry_process_event+0x34d1>
    362f:      	cmpq	$-0x7, %r12
    3633:      	je	0x3899 <generic_fentry_process_event+0x34e9>
    3639:      	cmpq	$-0x2, %r12
    363d:      	jne	0x3889 <generic_fentry_process_event+0x34d9>
    3643:      	addq	$0x548, %rax            # imm = 0x548
    3649:      	jmp	0x389f <generic_fentry_process_event+0x34ef>
    364e:      	movq	$-0x1, %r12
    3655:      	jmp	0x365a <generic_fentry_process_event+0x32aa>
    3657:      	movq	%rbp, %r12
    365a:      	movl	$0x0, 0x78(%rsp)
    3662:      	movq	(%rip), %rdi            # 0x3669 <generic_fentry_process_event+0x32b9>
    3669:      	leaq	0x78(%rsp), %rsi
    366e:      	movl	$0x1, %eax
    3673:      	callq	*%rax
    3675:      	testq	%rax, %rax
    3678:      	je	0x39f6 <generic_fentry_process_event+0x3646>
    367e:      	cmpq	$-0xc, %r12
    3682:      	jg	0x377a <generic_fentry_process_event+0x33ca>
    3688:      	cmpq	$-0x1c, %r12
    368c:      	je	0x39cc <generic_fentry_process_event+0x361c>
    3692:      	cmpq	$-0x16, %r12
    3696:      	je	0x39dc <generic_fentry_process_event+0x362c>
    369c:      	cmpq	$-0x10, %r12
    36a0:      	jne	0x39ec <generic_fentry_process_event+0x363c>
    36a6:      	addq	$0x558, %rax            # imm = 0x558
    36ac:      	jmp	0x39f2 <generic_fentry_process_event+0x3642>
    36b1:      	movq	%r14, %r12
    36b4:      	jmp	0x39f6 <generic_fentry_process_event+0x3646>
    36b9:      	movzbl	0x7(%rbx), %eax
    36bd:      	leal	0x8(,%rax,4), %eax
    36c4:      	movw	%ax, 0x2(%rbx)
    36c8:      	jmp	0x36ce <generic_fentry_process_event+0x331e>
    36ca:      	movzwl	0x2(%rbx), %eax
    36ce:      	addw	(%rbx), %ax
    36d1:      	movw	%ax, (%rbx)
    36d4:      	movzbl	0x6(%rbx), %r12d
    36d9:      	cmpq	$0x3c, %r12
    36dd:      	ja	0x3dfd <generic_fentry_process_event+0x3a4d>
    36e3:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    36ed:      	btq	%r12, %rcx
    36f1:      	jae	0x3dfd <generic_fentry_process_event+0x3a4d>
    36f7:      	movb	%r12b, 0x5(%rbx)
    36fb:      	movzwl	%ax, %ecx
    36fe:      	movq	0x30(%rsp), %rsi
    3703:      	addq	%rsi, %rcx
    3706:      	movl	$0x2, %edx
    370b:      	movl	$0x4, %eax
    3710:      	movzwl	(%rbx), %edx
    3713:      	addq	%rsi, %rdx
    3716:      	movq	%r15, %rdi
    3719:      	movl	$0x2, %esi
    371e:      	callq	*%rax
    3720:      	testq	%rax, %rax
    3723:      	js	0x3c3a <generic_fentry_process_event+0x388a>
    3729:      	movzbl	0x5(%rbx), %eax
    372d:      	cmpl	$0x32, %eax
    3730:      	jg	0x374c <generic_fentry_process_event+0x339c>
    3732:      	testl	%eax, %eax
    3734:      	je	0x3769 <generic_fentry_process_event+0x33b9>
    3736:      	cmpl	$0x2b, %eax
    3739:      	je	0x3769 <generic_fentry_process_event+0x33b9>
    373b:      	cmpl	$0x2c, %eax
    373e:      	jne	0x37b4 <generic_fentry_process_event+0x3404>
    3740:      	movw	$0x8, 0x2(%rbx)
    3746:      	movw	$0x8, %ax
    374a:      	jmp	0x37b8 <generic_fentry_process_event+0x3408>
    374c:      	cmpl	$0x33, %eax
    374f:      	je	0x37a3 <generic_fentry_process_event+0x33f3>
    3751:      	cmpl	$0x3c, %eax
    3754:      	je	0x3769 <generic_fentry_process_event+0x33b9>
    3756:      	cmpl	$0xff, %eax
    375b:      	jne	0x37b4 <generic_fentry_process_event+0x3404>
    375d:      	movw	$0x28, 0x2(%rbx)
    3763:      	movw	$0x28, %ax
    3767:      	jmp	0x37b8 <generic_fentry_process_event+0x3408>
    3769:      	movzbl	0x7(%rbx), %eax
    376d:      	leal	0x8(,%rax,8), %eax
    3774:      	movw	%ax, 0x2(%rbx)
    3778:      	jmp	0x37b8 <generic_fentry_process_event+0x3408>
    377a:      	cmpq	$-0xb, %r12
    377e:      	je	0x39d4 <generic_fentry_process_event+0x3624>
    3784:      	cmpq	$-0x7, %r12
    3788:      	je	0x39e4 <generic_fentry_process_event+0x3634>
    378e:      	cmpq	$-0x2, %r12
    3792:      	jne	0x39ec <generic_fentry_process_event+0x363c>
    3798:      	addq	$0x548, %rax            # imm = 0x548
    379e:      	jmp	0x39f2 <generic_fentry_process_event+0x3642>
    37a3:      	movzbl	0x7(%rbx), %eax
    37a7:      	leal	0x8(,%rax,4), %eax
    37ae:      	movw	%ax, 0x2(%rbx)
    37b2:      	jmp	0x37b8 <generic_fentry_process_event+0x3408>
    37b4:      	movzwl	0x2(%rbx), %eax
    37b8:      	addw	(%rbx), %ax
    37bb:      	movw	%ax, (%rbx)
    37be:      	movzbl	0x6(%rbx), %r12d
    37c3:      	cmpq	$0x3c, %r12
    37c7:      	ja	0x3dfd <generic_fentry_process_event+0x3a4d>
    37cd:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    37d7:      	btq	%r12, %rcx
    37db:      	jae	0x3dfd <generic_fentry_process_event+0x3a4d>
    37e1:      	movb	%r12b, 0x5(%rbx)
    37e5:      	movzwl	%ax, %ecx
    37e8:      	movq	0x30(%rsp), %rsi
    37ed:      	addq	%rsi, %rcx
    37f0:      	movl	$0x2, %edx
    37f5:      	movl	$0x4, %eax
    37fa:      	movzwl	(%rbx), %edx
    37fd:      	addq	%rsi, %rdx
    3800:      	movq	%r15, %rdi
    3803:      	movl	$0x2, %esi
    3808:      	callq	*%rax
    380a:      	testq	%rax, %rax
    380d:      	js	0x3c3a <generic_fentry_process_event+0x388a>
    3813:      	movzbl	0x5(%rbx), %eax
    3817:      	cmpl	$0x32, %eax
    381a:      	jg	0x383d <generic_fentry_process_event+0x348d>
    381c:      	testl	%eax, %eax
    381e:      	je	0x3865 <generic_fentry_process_event+0x34b5>
    3820:      	cmpl	$0x2b, %eax
    3823:      	je	0x3865 <generic_fentry_process_event+0x34b5>
    3825:      	cmpl	$0x2c, %eax
    3828:      	jne	0x3907 <generic_fentry_process_event+0x3557>
    382e:      	movw	$0x8, 0x2(%rbx)
    3834:      	movw	$0x8, %ax
    3838:      	jmp	0x390b <generic_fentry_process_event+0x355b>
    383d:      	cmpl	$0x33, %eax
    3840:      	je	0x38f6 <generic_fentry_process_event+0x3546>
    3846:      	cmpl	$0x3c, %eax
    3849:      	je	0x3865 <generic_fentry_process_event+0x34b5>
    384b:      	cmpl	$0xff, %eax
    3850:      	jne	0x3907 <generic_fentry_process_event+0x3557>
    3856:      	movw	$0x28, 0x2(%rbx)
    385c:      	movw	$0x28, %ax
    3860:      	jmp	0x390b <generic_fentry_process_event+0x355b>
    3865:      	movzbl	0x7(%rbx), %eax
    3869:      	leal	0x8(,%rax,8), %eax
    3870:      	movw	%ax, 0x2(%rbx)
    3874:      	jmp	0x390b <generic_fentry_process_event+0x355b>
    3879:      	addq	$0x568, %rax            # imm = 0x568
    387f:      	jmp	0x389f <generic_fentry_process_event+0x34ef>
    3881:      	addq	$0x570, %rax            # imm = 0x570
    3887:      	jmp	0x389f <generic_fentry_process_event+0x34ef>
    3889:      	addq	$0x540, %rax            # imm = 0x540
    388f:      	jmp	0x389f <generic_fentry_process_event+0x34ef>
    3891:      	addq	$0x560, %rax            # imm = 0x560
    3897:      	jmp	0x389f <generic_fentry_process_event+0x34ef>
    3899:      	addq	$0x550, %rax            # imm = 0x550
    389f:      	lock
    38a0:      	incq	(%rax)
    38a3:      	testl	%r12d, %r12d
    38a6:      	js	0x38ca <generic_fentry_process_event+0x351a>
    38a8:      	movq	0x58(%rsp), %rax
    38ad:      	movq	$0x0, 0x4(%rax)
    38b5:      	movq	0x18(%rsp), %rdx
    38ba:      	movl	%edx, %ecx
    38bc:      	subl	%r12d, %ecx
    38bf:      	xorl	%eax, %eax
    38c1:      	cmpq	$-0x1, %rdx
    38c5:      	cmovnel	%ecx, %eax
    38c8:      	jmp	0x38df <generic_fentry_process_event+0x352f>
    38ca:      	movq	0x58(%rsp), %rax
    38cf:      	movl	%r12d, 0x4(%rax)
    38d3:      	movl	$0x0, 0x8(%rax)
    38da:      	xorl	%eax, %eax
    38dc:      	xorl	%r12d, %r12d
    38df:      	movq	0x58(%rsp), %rcx
    38e4:      	movl	%eax, 0xc(%rcx)
    38e7:      	movl	%r12d, 0x10(%rcx)
    38eb:      	movl	$0x24, %r12d
    38f1:      	jmp	0x1482 <generic_fentry_process_event+0x10d2>
    38f6:      	movzbl	0x7(%rbx), %eax
    38fa:      	leal	0x8(,%rax,4), %eax
    3901:      	movw	%ax, 0x2(%rbx)
    3905:      	jmp	0x390b <generic_fentry_process_event+0x355b>
    3907:      	movzwl	0x2(%rbx), %eax
    390b:      	addw	(%rbx), %ax
    390e:      	movw	%ax, (%rbx)
    3911:      	movzbl	0x6(%rbx), %r12d
    3916:      	cmpq	$0x3c, %r12
    391a:      	ja	0x3dfd <generic_fentry_process_event+0x3a4d>
    3920:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    392a:      	btq	%r12, %rcx
    392e:      	jae	0x3dfd <generic_fentry_process_event+0x3a4d>
    3934:      	movb	%r12b, 0x5(%rbx)
    3938:      	movzwl	%ax, %ecx
    393b:      	movq	0x30(%rsp), %rsi
    3940:      	addq	%rsi, %rcx
    3943:      	movl	$0x2, %edx
    3948:      	movl	$0x4, %eax
    394d:      	movzwl	(%rbx), %edx
    3950:      	addq	%rsi, %rdx
    3953:      	movq	%r15, %rdi
    3956:      	movl	$0x2, %esi
    395b:      	callq	*%rax
    395d:      	testq	%rax, %rax
    3960:      	js	0x3c3a <generic_fentry_process_event+0x388a>
    3966:      	movzbl	0x5(%rbx), %eax
    396a:      	cmpl	$0x32, %eax
    396d:      	jg	0x3990 <generic_fentry_process_event+0x35e0>
    396f:      	testl	%eax, %eax
    3971:      	je	0x39b8 <generic_fentry_process_event+0x3608>
    3973:      	cmpl	$0x2b, %eax
    3976:      	je	0x39b8 <generic_fentry_process_event+0x3608>
    3978:      	cmpl	$0x2c, %eax
    397b:      	jne	0x3a62 <generic_fentry_process_event+0x36b2>
    3981:      	movw	$0x8, 0x2(%rbx)
    3987:      	movw	$0x8, %ax
    398b:      	jmp	0x3a66 <generic_fentry_process_event+0x36b6>
    3990:      	cmpl	$0x33, %eax
    3993:      	je	0x3a51 <generic_fentry_process_event+0x36a1>
    3999:      	cmpl	$0x3c, %eax
    399c:      	je	0x39b8 <generic_fentry_process_event+0x3608>
    399e:      	cmpl	$0xff, %eax
    39a3:      	jne	0x3a62 <generic_fentry_process_event+0x36b2>
    39a9:      	movw	$0x28, 0x2(%rbx)
    39af:      	movw	$0x28, %ax
    39b3:      	jmp	0x3a66 <generic_fentry_process_event+0x36b6>
    39b8:      	movzbl	0x7(%rbx), %eax
    39bc:      	leal	0x8(,%rax,8), %eax
    39c3:      	movw	%ax, 0x2(%rbx)
    39c7:      	jmp	0x3a66 <generic_fentry_process_event+0x36b6>
    39cc:      	addq	$0x568, %rax            # imm = 0x568
    39d2:      	jmp	0x39f2 <generic_fentry_process_event+0x3642>
    39d4:      	addq	$0x570, %rax            # imm = 0x570
    39da:      	jmp	0x39f2 <generic_fentry_process_event+0x3642>
    39dc:      	addq	$0x560, %rax            # imm = 0x560
    39e2:      	jmp	0x39f2 <generic_fentry_process_event+0x3642>
    39e4:      	addq	$0x550, %rax            # imm = 0x550
    39ea:      	jmp	0x39f2 <generic_fentry_process_event+0x3642>
    39ec:      	addq	$0x540, %rax            # imm = 0x540
    39f2:      	lock
    39f3:      	incq	(%rax)
    39f6:      	testl	%r12d, %r12d
    39f9:      	js	0x3a14 <generic_fentry_process_event+0x3664>
    39fb:      	movq	$0x0, 0x4(%rbx)
    3a03:      	movl	%r14d, %ecx
    3a06:      	subl	%r12d, %ecx
    3a09:      	xorl	%eax, %eax
    3a0b:      	cmpq	$-0x1, %r14
    3a0f:      	cmovnel	%ecx, %eax
    3a12:      	jmp	0x3a24 <generic_fentry_process_event+0x3674>
    3a14:      	movl	%r12d, 0x4(%rbx)
    3a18:      	movl	$0x0, 0x8(%rbx)
    3a1f:      	xorl	%eax, %eax
    3a21:      	xorl	%r12d, %r12d
    3a24:      	movl	%eax, 0xc(%rbx)
    3a27:      	movl	%r12d, 0x10(%rbx)
    3a2b:      	movl	$0x24, %ebp
    3a30:      	movq	0x8(%rsp), %rbx
    3a35:      	movq	0x28(%rsp), %r14
    3a3a:      	movq	0x40(%rsp), %rax
    3a3f:      	movq	0x20(%rsp), %rcx
    3a44:      	movl	$0x4, %esi
    3a49:      	movq	%rbp, %r12
    3a4c:      	jmp	0x1491 <generic_fentry_process_event+0x10e1>
    3a51:      	movzbl	0x7(%rbx), %eax
    3a55:      	leal	0x8(,%rax,4), %eax
    3a5c:      	movw	%ax, 0x2(%rbx)
    3a60:      	jmp	0x3a66 <generic_fentry_process_event+0x36b6>
    3a62:      	movzwl	0x2(%rbx), %eax
    3a66:      	addw	(%rbx), %ax
    3a69:      	movw	%ax, (%rbx)
    3a6c:      	movzbl	0x6(%rbx), %r12d
    3a71:      	cmpq	$0x3c, %r12
    3a75:      	ja	0x3dfd <generic_fentry_process_event+0x3a4d>
    3a7b:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3a85:      	btq	%r12, %rcx
    3a89:      	jae	0x3dfd <generic_fentry_process_event+0x3a4d>
    3a8f:      	movb	%r12b, 0x5(%rbx)
    3a93:      	movzwl	%ax, %ecx
    3a96:      	movq	0x30(%rsp), %rsi
    3a9b:      	addq	%rsi, %rcx
    3a9e:      	movl	$0x2, %edx
    3aa3:      	movl	$0x4, %eax
    3aa8:      	movzwl	(%rbx), %edx
    3aab:      	addq	%rsi, %rdx
    3aae:      	movq	%r15, %rdi
    3ab1:      	movl	$0x2, %esi
    3ab6:      	callq	*%rax
    3ab8:      	testq	%rax, %rax
    3abb:      	js	0x3c3a <generic_fentry_process_event+0x388a>
    3ac1:      	movzbl	0x5(%rbx), %eax
    3ac5:      	cmpl	$0x32, %eax
    3ac8:      	jg	0x3ae4 <generic_fentry_process_event+0x3734>
    3aca:      	testl	%eax, %eax
    3acc:      	je	0x3b01 <generic_fentry_process_event+0x3751>
    3ace:      	cmpl	$0x2b, %eax
    3ad1:      	je	0x3b01 <generic_fentry_process_event+0x3751>
    3ad3:      	cmpl	$0x2c, %eax
    3ad6:      	jne	0x3b23 <generic_fentry_process_event+0x3773>
    3ad8:      	movw	$0x8, 0x2(%rbx)
    3ade:      	movw	$0x8, %ax
    3ae2:      	jmp	0x3b27 <generic_fentry_process_event+0x3777>
    3ae4:      	cmpl	$0x33, %eax
    3ae7:      	je	0x3b12 <generic_fentry_process_event+0x3762>
    3ae9:      	cmpl	$0x3c, %eax
    3aec:      	je	0x3b01 <generic_fentry_process_event+0x3751>
    3aee:      	cmpl	$0xff, %eax
    3af3:      	jne	0x3b23 <generic_fentry_process_event+0x3773>
    3af5:      	movw	$0x28, 0x2(%rbx)
    3afb:      	movw	$0x28, %ax
    3aff:      	jmp	0x3b27 <generic_fentry_process_event+0x3777>
    3b01:      	movzbl	0x7(%rbx), %eax
    3b05:      	leal	0x8(,%rax,8), %eax
    3b0c:      	movw	%ax, 0x2(%rbx)
    3b10:      	jmp	0x3b27 <generic_fentry_process_event+0x3777>
    3b12:      	movzbl	0x7(%rbx), %eax
    3b16:      	leal	0x8(,%rax,4), %eax
    3b1d:      	movw	%ax, 0x2(%rbx)
    3b21:      	jmp	0x3b27 <generic_fentry_process_event+0x3777>
    3b23:      	movzwl	0x2(%rbx), %eax
    3b27:      	addw	(%rbx), %ax
    3b2a:      	movw	%ax, (%rbx)
    3b2d:      	movzbl	0x6(%rbx), %r12d
    3b32:      	cmpq	$0x3c, %r12
    3b36:      	ja	0x3dfd <generic_fentry_process_event+0x3a4d>
    3b3c:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3b46:      	btq	%r12, %rcx
    3b4a:      	jae	0x3dfd <generic_fentry_process_event+0x3a4d>
    3b50:      	movb	%r12b, 0x5(%rbx)
    3b54:      	movzwl	%ax, %ecx
    3b57:      	movq	0x30(%rsp), %rsi
    3b5c:      	addq	%rsi, %rcx
    3b5f:      	movl	$0x2, %edx
    3b64:      	movl	$0x4, %eax
    3b69:      	movzwl	(%rbx), %edx
    3b6c:      	addq	%rsi, %rdx
    3b6f:      	movq	%r15, %rdi
    3b72:      	movl	$0x2, %esi
    3b77:      	callq	*%rax
    3b79:      	testq	%rax, %rax
    3b7c:      	js	0x3c3a <generic_fentry_process_event+0x388a>
    3b82:      	movzbl	0x5(%rbx), %eax
    3b86:      	cmpl	$0x32, %eax
    3b89:      	jg	0x3ba5 <generic_fentry_process_event+0x37f5>
    3b8b:      	testl	%eax, %eax
    3b8d:      	je	0x3bc2 <generic_fentry_process_event+0x3812>
    3b8f:      	cmpl	$0x2b, %eax
    3b92:      	je	0x3bc2 <generic_fentry_process_event+0x3812>
    3b94:      	cmpl	$0x2c, %eax
    3b97:      	jne	0x3be4 <generic_fentry_process_event+0x3834>
    3b99:      	movw	$0x8, 0x2(%rbx)
    3b9f:      	movw	$0x8, %ax
    3ba3:      	jmp	0x3be8 <generic_fentry_process_event+0x3838>
    3ba5:      	cmpl	$0x33, %eax
    3ba8:      	je	0x3bd3 <generic_fentry_process_event+0x3823>
    3baa:      	cmpl	$0x3c, %eax
    3bad:      	je	0x3bc2 <generic_fentry_process_event+0x3812>
    3baf:      	cmpl	$0xff, %eax
    3bb4:      	jne	0x3be4 <generic_fentry_process_event+0x3834>
    3bb6:      	movw	$0x28, 0x2(%rbx)
    3bbc:      	movw	$0x28, %ax
    3bc0:      	jmp	0x3be8 <generic_fentry_process_event+0x3838>
    3bc2:      	movzbl	0x7(%rbx), %eax
    3bc6:      	leal	0x8(,%rax,8), %eax
    3bcd:      	movw	%ax, 0x2(%rbx)
    3bd1:      	jmp	0x3be8 <generic_fentry_process_event+0x3838>
    3bd3:      	movzbl	0x7(%rbx), %eax
    3bd7:      	leal	0x8(,%rax,4), %eax
    3bde:      	movw	%ax, 0x2(%rbx)
    3be2:      	jmp	0x3be8 <generic_fentry_process_event+0x3838>
    3be4:      	movzwl	0x2(%rbx), %eax
    3be8:      	addw	(%rbx), %ax
    3beb:      	movw	%ax, (%rbx)
    3bee:      	movzbl	0x6(%rbx), %r12d
    3bf3:      	cmpq	$0x3c, %r12
    3bf7:      	ja	0x3dfd <generic_fentry_process_event+0x3a4d>
    3bfd:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3c07:      	btq	%r12, %rcx
    3c0b:      	jae	0x3dfd <generic_fentry_process_event+0x3a4d>
    3c11:      	movb	%r12b, 0x5(%rbx)
    3c15:      	movzwl	%ax, %ecx
    3c18:      	movq	0x30(%rsp), %rsi
    3c1d:      	addq	%rsi, %rcx
    3c20:      	movl	$0x2, %edx
    3c25:      	movl	$0x4, %eax
    3c2a:      	movzwl	(%rbx), %edx
    3c2d:      	addq	%rsi, %rdx
    3c30:      	movq	%r15, %rdi
    3c33:      	movl	$0x2, %esi
    3c38:      	callq	*%rax
    3c3a:      	xorl	%r12d, %r12d
    3c3d:      	movb	%r12b, 0xd8(%rsp)
    3c45:      	movzbl	%r12b, %eax
    3c49:      	movq	%rbp, %rbx
    3c4c:      	movw	%ax, 0x24(%rbp)
    3c50:      	movw	$0xa, 0x26(%rbp)
    3c56:      	leaq	0x8(%r14), %rdx
    3c5a:      	movl	$0x10, %ecx
    3c5f:      	movl	$0x4, %eax
    3c64:      	movq	%rbp, %rdi
    3c67:      	movl	$0x10, %esi
    3c6c:      	callq	*%rax
    3c6e:      	leaq	0x10(%rbp), %rdi
    3c72:      	addq	$0x18, %r14
    3c76:      	movl	$0x10, %ecx
    3c7b:      	movl	$0x4, %eax
    3c80:      	movl	$0x10, %esi
    3c85:      	movq	%r14, %rdx
    3c88:      	callq	*%rax
    3c8a:      	cmpb	$0x11, %r12b
    3c8e:      	je	0x3cdf <generic_fentry_process_event+0x392f>
    3c90:      	movzbl	%r12b, %eax
    3c94:      	cmpl	$0x6, %eax
    3c97:      	jne	0x3d28 <generic_fentry_process_event+0x3978>
    3c9d:      	movq	0x78(%rsp), %r15
    3ca2:      	movzwl	0xd0(%rsp), %r12d
    3cab:      	leaq	(%r15,%r12), %rdx
    3caf:      	movq	%rbp, %rbx
    3cb2:      	leaq	0x20(%rbp), %rdi
    3cb6:      	movl	$0x2, %ecx
    3cbb:      	movl	$0x4, %eax
    3cc0:      	movl	$0x2, %esi
    3cc5:      	callq	*%rax
    3cc7:      	leaq	0x22(%rbp), %rdi
    3ccb:      	leaq	(%r15,%r12), %rdx
    3ccf:      	addq	$0x2, %rdx
    3cd3:      	movl	$0x2, %ecx
    3cd8:      	movl	$0x4, %eax
    3cdd:      	jmp	0x3d1f <generic_fentry_process_event+0x396f>
    3cdf:      	movq	0x78(%rsp), %r15
    3ce4:      	movzwl	0xd0(%rsp), %r12d
    3ced:      	leaq	(%r15,%r12), %rdx
    3cf1:      	movq	%rbp, %rbx
    3cf4:      	leaq	0x20(%rbp), %rdi
    3cf8:      	movl	$0x2, %ecx
    3cfd:      	movl	$0x4, %eax
    3d02:      	movl	$0x2, %esi
    3d07:      	callq	*%rax
    3d09:      	leaq	0x22(%rbp), %rdi
    3d0d:      	leaq	(%r15,%r12), %rdx
    3d11:      	addq	$0x2, %rdx
    3d15:      	movl	$0x2, %ecx
    3d1a:      	movl	$0x4, %eax
    3d1f:      	movl	$0x2, %esi
    3d24:      	callq	*%rax
    3d26:      	jmp	0x3d2f <generic_fentry_process_event+0x397f>
    3d28:      	movl	$0x0, 0x20(%rbp)
    3d2f:      	movzwl	0x20(%rbp), %eax
    3d33:      	movzwl	0x22(%rbp), %ecx
    3d37:      	movbew	%ax, 0x20(%rbp)
    3d3d:      	movbew	%cx, 0x22(%rbp)
    3d43:      	addq	$0xe0, %r13
    3d4a:      	leaq	0x68(%rsp), %rdi
    3d4f:      	movl	$0x8, %ecx
    3d54:      	movl	$0x4, %eax
    3d59:      	movl	$0x4, %r15d
    3d5f:      	movl	$0x8, %esi
    3d64:      	movq	%r13, %rdx
    3d67:      	callq	*%rax
    3d69:      	movq	0x68(%rsp), %rcx
    3d6e:      	testq	%rcx, %rcx
    3d71:      	je	0x3dd9 <generic_fentry_process_event+0x3a29>
    3d73:      	addq	$0x5, %rcx
    3d77:      	leaq	0xc0(%rsp), %rdi
    3d7f:      	movl	$0x8, %edx
    3d84:      	movl	$0x4, %eax
    3d89:      	movq	0x68(%rsp), %rdx
    3d8e:      	addq	$0x5, %rdx
    3d92:      	movl	$0x8, %esi
    3d97:      	callq	*%rax
    3d99:      	movq	0x68(%rsp), %r12
    3d9e:      	movq	0xc0(%rsp), %r13
    3da6:      	leaq	0x38(%rbp), %rdi
    3daa:      	leaq	(%r12,%r13,8), %rdx
    3dae:      	addq	$0x44, %rdx
    3db2:      	movl	$0x4, %eax
    3db7:      	movl	$0x4, %esi
    3dbc:      	callq	*%rax
    3dbe:      	addq	$0x3c, %rbp
    3dc2:      	leaq	(%r12,%r13,8), %rdx
    3dc6:      	addq	$0x45, %rdx
    3dca:      	movl	$0x4, %eax
    3dcf:      	movq	%rbp, %rdi
    3dd2:      	movl	$0x4, %esi
    3dd7:      	callq	*%rax
    3dd9:      	movl	$0x40, %r12d
    3ddf:      	movq	0x40(%rsp), %rax
    3de4:      	movq	0x20(%rsp), %rcx
    3de9:      	movl	$0x4, %esi
    3dee:      	movq	0x8(%rsp), %rbx
    3df3:      	movq	0x28(%rsp), %r14
    3df8:      	jmp	0x1491 <generic_fentry_process_event+0x10e1>
    3dfd:      	movw	%ax, 0xd0(%rsp)
    3e05:      	jmp	0x3c3d <generic_fentry_process_event+0x388d>
    3e0a:      	nopw	(%rax,%rax)

0000000000003e10 <generic_fentry_process_filter>:
    3e10:      	pushq	%rbp
    3e11:      	pushq	%r15
    3e13:      	pushq	%r14
    3e15:      	pushq	%r13
    3e17:      	pushq	%r12
    3e19:      	pushq	%rbx
    3e1a:      	subq	$0xf8, %rsp
    3e21:      	movq	%rdi, %rbp
    3e24:      	movl	$0x0, 0xc8(%rsp)
    3e2f:      	movq	(%rip), %rdi            # 0x3e36 <generic_fentry_process_filter+0x26>
    3e36:      	leaq	0xc8(%rsp), %rsi
    3e3e:      	movl	$0x1, %eax
    3e43:      	callq	*%rax
    3e45:      	testq	%rax, %rax
    3e48:      	je	0x60c6 <generic_fentry_process_filter+0x22b6>
    3e4e:      	movq	%rax, %r12
    3e51:      	movl	$0x23, %eax
    3e56:      	callq	*%rax
    3e58:      	movq	%rax, %rcx
    3e5b:      	movq	%rax, 0x50(%rsp)
    3e60:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3e67:      	leaq	0x48(%rsp), %rdi
    3e6c:      	movl	$0x4, %edx
    3e71:      	movl	$0x71, %eax
    3e76:      	movl	$0xaf4, %edx            # imm = 0xAF4
    3e7b:      	addq	0x50(%rsp), %rdx
    3e80:      	movl	$0x4, %esi
    3e85:      	callq	*%rax
    3e87:      	movl	0x48(%rsp), %eax
    3e8b:      	movl	%eax, 0x38(%rsp)
    3e8f:      	movq	(%rip), %rdi            # 0x3e96 <generic_fentry_process_filter+0x86>
    3e96:      	leaq	0x38(%rsp), %rsi
    3e9b:      	movl	$0x1, %eax
    3ea0:      	callq	*%rax
    3ea2:      	testq	%rax, %rax
    3ea5:      	movq	%r12, 0x30(%rsp)
    3eaa:      	je	0x3eba <generic_fentry_process_filter+0xaa>
    3eac:      	movq	%rax, %r14
    3eaf:      	cmpq	$0x0, 0x8(%rax)
    3eb4:      	jne	0x4cd2 <generic_fentry_process_filter+0xec2>
    3eba:      	movl	$0xb00, %edx            # imm = 0xB00
    3ebf:      	movq	0x50(%rsp), %rcx
    3ec4:      	addq	%rdx, %rcx
    3ec7:      	leaq	0x50(%rsp), %rdi
    3ecc:      	movl	$0x8, %esi
    3ed1:      	movl	$0x71, %eax
    3ed6:      	addq	0x50(%rsp), %rdx
    3edb:      	movl	$0x8, %esi
    3ee0:      	callq	*%rax
    3ee2:      	movq	0x50(%rsp), %rcx
    3ee7:      	testq	%rcx, %rcx
    3eea:      	je	0x407f <generic_fentry_process_filter+0x26f>
    3ef0:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3ef7:      	leaq	0x48(%rsp), %rdi
    3efc:      	movl	$0x4, %edx
    3f01:      	movl	$0x71, %eax
    3f06:      	movl	$0xaf4, %edx            # imm = 0xAF4
    3f0b:      	addq	0x50(%rsp), %rdx
    3f10:      	movl	$0x4, %esi
    3f15:      	callq	*%rax
    3f17:      	movl	0x48(%rsp), %eax
    3f1b:      	movl	%eax, 0x38(%rsp)
    3f1f:      	movq	(%rip), %rdi            # 0x3f26 <generic_fentry_process_filter+0x116>
    3f26:      	leaq	0x38(%rsp), %rsi
    3f2b:      	movl	$0x1, %eax
    3f30:      	callq	*%rax
    3f32:      	testq	%rax, %rax
    3f35:      	je	0x3f45 <generic_fentry_process_filter+0x135>
    3f37:      	movq	%rax, %r14
    3f3a:      	cmpq	$0x0, 0x8(%rax)
    3f3f:      	jne	0x4cd2 <generic_fentry_process_filter+0xec2>
    3f45:      	movl	$0xb00, %edx            # imm = 0xB00
    3f4a:      	movq	0x50(%rsp), %rcx
    3f4f:      	addq	%rdx, %rcx
    3f52:      	leaq	0x50(%rsp), %rdi
    3f57:      	movl	$0x8, %esi
    3f5c:      	movl	$0x71, %eax
    3f61:      	addq	0x50(%rsp), %rdx
    3f66:      	movl	$0x8, %esi
    3f6b:      	callq	*%rax
    3f6d:      	movq	0x50(%rsp), %rcx
    3f72:      	testq	%rcx, %rcx
    3f75:      	je	0x407f <generic_fentry_process_filter+0x26f>
    3f7b:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3f82:      	leaq	0x48(%rsp), %rdi
    3f87:      	movl	$0x4, %edx
    3f8c:      	movl	$0x71, %eax
    3f91:      	movl	$0xaf4, %edx            # imm = 0xAF4
    3f96:      	addq	0x50(%rsp), %rdx
    3f9b:      	movl	$0x4, %esi
    3fa0:      	callq	*%rax
    3fa2:      	movl	0x48(%rsp), %eax
    3fa6:      	movl	%eax, 0x38(%rsp)
    3faa:      	movq	(%rip), %rdi            # 0x3fb1 <generic_fentry_process_filter+0x1a1>
    3fb1:      	leaq	0x38(%rsp), %rsi
    3fb6:      	movl	$0x1, %eax
    3fbb:      	callq	*%rax
    3fbd:      	testq	%rax, %rax
    3fc0:      	je	0x3fd0 <generic_fentry_process_filter+0x1c0>
    3fc2:      	movq	%rax, %r14
    3fc5:      	cmpq	$0x0, 0x8(%rax)
    3fca:      	jne	0x4cd2 <generic_fentry_process_filter+0xec2>
    3fd0:      	movl	$0xb00, %edx            # imm = 0xB00
    3fd5:      	movq	0x50(%rsp), %rcx
    3fda:      	addq	%rdx, %rcx
    3fdd:      	leaq	0x50(%rsp), %rdi
    3fe2:      	movl	$0x8, %esi
    3fe7:      	movl	$0x71, %eax
    3fec:      	addq	0x50(%rsp), %rdx
    3ff1:      	movl	$0x8, %esi
    3ff6:      	callq	*%rax
    3ff8:      	movq	0x50(%rsp), %rcx
    3ffd:      	testq	%rcx, %rcx
    4000:      	je	0x407f <generic_fentry_process_filter+0x26f>
    4002:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    4009:      	leaq	0x48(%rsp), %rdi
    400e:      	movl	$0x4, %edx
    4013:      	movl	$0x71, %eax
    4018:      	movl	$0xaf4, %edx            # imm = 0xAF4
    401d:      	addq	0x50(%rsp), %rdx
    4022:      	movl	$0x4, %esi
    4027:      	callq	*%rax
    4029:      	movl	0x48(%rsp), %eax
    402d:      	movl	%eax, 0x38(%rsp)
    4031:      	movq	(%rip), %rdi            # 0x4038 <generic_fentry_process_filter+0x228>
    4038:      	leaq	0x38(%rsp), %rsi
    403d:      	movl	$0x1, %eax
    4042:      	callq	*%rax
    4044:      	testq	%rax, %rax
    4047:      	je	0x4057 <generic_fentry_process_filter+0x247>
    4049:      	movq	%rax, %r14
    404c:      	cmpq	$0x0, 0x8(%rax)
    4051:      	jne	0x4cd2 <generic_fentry_process_filter+0xec2>
    4057:      	movl	$0xb00, %edx            # imm = 0xB00
    405c:      	movq	0x50(%rsp), %rcx
    4061:      	addq	%rdx, %rcx
    4064:      	leaq	0x50(%rsp), %rdi
    4069:      	movl	$0x8, %esi
    406e:      	movl	$0x71, %eax
    4073:      	addq	0x50(%rsp), %rdx
    4078:      	movl	$0x8, %esi
    407d:      	callq	*%rax
    407f:      	movl	$0x23, %eax
    4084:      	callq	*%rax
    4086:      	movq	%rax, %r13
    4089:      	leaq	0xaf4(%rax), %rdx
    4090:      	leaq	0x50(%rsp), %rdi
    4095:      	movl	$0x4, %ecx
    409a:      	movl	$0x4, %eax
    409f:      	movl	$0x4, %r14d
    40a5:      	movl	$0x4, %esi
    40aa:      	callq	*%rax
    40ac:      	movl	0x50(%rsp), %eax
    40b0:      	movl	%eax, 0x5f10(%r12)
    40b8:      	movl	$0x7d, %eax
    40bd:      	callq	*%rax
    40bf:      	movq	%rax, 0x5f18(%r12)
    40c7:      	movl	$0x0, 0x5f20(%r12)
    40d3:      	movq	$0x0, 0x5f28(%r12)
    40df:      	movl	$0x0, 0x5f30(%r12)
    40eb:      	leaq	0x60(%r13), %rdx
    40ef:      	leaq	0x38(%rsp), %rdi
    40f4:      	movl	$0x8, %ecx
    40f9:      	movl	$0x71, %eax
    40fe:      	movl	$0x8, %esi
    4103:      	callq	*%rax
    4105:      	movq	0x38(%rsp), %rcx
    410a:      	xorl	%ebx, %ebx
    410c:      	testq	%rcx, %rcx
    410f:      	je	0x417e <generic_fentry_process_filter+0x36e>
    4111:      	addq	$0x4, %rcx
    4115:      	leaq	0x48(%rsp), %rdi
    411a:      	movl	$0x4, %edx
    411f:      	movl	$0x71, %eax
    4124:      	movq	0x38(%rsp), %rdx
    4129:      	addq	$0x4, %rdx
    412d:      	movl	$0x4, %esi
    4132:      	callq	*%rax
    4134:      	movl	0x48(%rsp), %eax
    4138:      	testl	%eax, %eax
    413a:      	je	0x417e <generic_fentry_process_filter+0x36e>
    413c:      	movq	0x38(%rsp), %rcx
    4141:      	shll	$0x4, %eax
    4144:      	addq	%rax, %rcx
    4147:      	addq	$0x80, %rcx
    414e:      	leaq	0x50(%rsp), %rdi
    4153:      	movl	$0x10, %edx
    4158:      	movl	$0x71, %eax
    415d:      	movq	0x38(%rsp), %rcx
    4162:      	movl	0x48(%rsp), %edx
    4166:      	shll	$0x4, %edx
    4169:      	addq	%rcx, %rdx
    416c:      	addq	$0x80, %rdx
    4173:      	movl	$0x10, %esi
    4178:      	callq	*%rax
    417a:      	movl	0x50(%rsp), %ebx
    417e:      	movl	%ebx, 0x5f34(%r12)
    4186:      	leaq	0xd00(%r13), %r15
    418d:      	leaq	0x50(%rsp), %rdi
    4192:      	movl	$0x8, %ecx
    4197:      	movl	$0x4, %eax
    419c:      	leaq	0x5f60(%r12), %rbx
    41a4:      	movl	$0x8, %esi
    41a9:      	movq	%r15, %rdx
    41ac:      	callq	*%rax
    41ae:      	movq	0x50(%rsp), %r12
    41b3:      	movq	0x30(%rsp), %rax
    41b8:      	leaq	0x5f68(%rax), %rdi
    41bf:      	leaq	0x40(%r12), %rdx
    41c4:      	movl	$0x8, %ecx
    41c9:      	movl	$0x4, %eax
    41ce:      	movl	$0x8, %esi
    41d3:      	callq	*%rax
    41d5:      	movq	0x30(%rsp), %rax
    41da:      	leaq	0x5f70(%rax), %rdi
    41e1:      	leaq	0x30(%r12), %rdx
    41e6:      	movl	$0x8, %ecx
    41eb:      	movl	$0x4, %eax
    41f0:      	movl	$0x8, %esi
    41f5:      	callq	*%rax
    41f7:      	addq	$0x38, %r12
    41fb:      	movl	$0x8, %ecx
    4200:      	movl	$0x4, %eax
    4205:      	movq	%rbx, %rdi
    4208:      	movl	$0x8, %esi
    420d:      	movq	%r12, %rdx
    4210:      	movq	0x30(%rsp), %r12
    4215:      	callq	*%rax
    4217:      	leaq	0x5f38(%r12), %rbx
    421f:      	leaq	0xd70(%r13), %rdx
    4226:      	leaq	0x48(%rsp), %rdi
    422b:      	movl	$0x8, %ecx
    4230:      	movl	$0x4, %eax
    4235:      	movl	$0x8, %esi
    423a:      	callq	*%rax
    423c:      	movq	0x48(%rsp), %rcx
    4241:      	leaq	0x50(%rsp), %rdi
    4246:      	movl	$0x48, %edx
    424b:      	movl	$0x4, %eax
    4250:      	movq	0x48(%rsp), %rdx
    4255:      	movl	$0x48, %esi
    425a:      	callq	*%rax
    425c:      	movl	$0x218, %edx            # imm = 0x218
    4261:      	movq	0x58(%rsp), %rcx
    4266:      	addq	%rdx, %rcx
    4269:      	movl	$0x4, %eax
    426e:      	addq	0x58(%rsp), %rdx
    4273:      	movq	%rbx, %rdi
    4276:      	movl	$0x4, %esi
    427b:      	callq	*%rax
    427d:      	leaq	0x5f3c(%r12), %rdi
    4285:      	movl	$0x4d8, %edx            # imm = 0x4D8
    428a:      	movq	0x60(%rsp), %rcx
    428f:      	addq	%rdx, %rcx
    4292:      	movl	$0x4, %eax
    4297:      	addq	0x60(%rsp), %rdx
    429c:      	movl	$0x4, %esi
    42a1:      	callq	*%rax
    42a3:      	leaq	0x5f40(%r12), %rdi
    42ab:      	movq	0x68(%rsp), %rcx
    42b0:      	addq	$0x58, %rcx
    42b4:      	movl	$0x4, %eax
    42b9:      	movq	0x68(%rsp), %rdx
    42be:      	addq	$0x58, %rdx
    42c2:      	movl	$0x4, %esi
    42c7:      	callq	*%rax
    42c9:      	movq	$0x0, 0xa0(%rsp)
    42d5:      	leaq	0xb58(%r13), %rdx
    42dc:      	leaq	0xa0(%rsp), %rdi
    42e4:      	movl	$0x8, %ecx
    42e9:      	movl	$0x4, %eax
    42ee:      	movl	$0x8, %esi
    42f3:      	callq	*%rax
    42f5:      	movq	0xa0(%rsp), %rcx
    42fd:      	testq	%rcx, %rcx
    4300:      	je	0x43b9 <generic_fentry_process_filter+0x5a9>
    4306:      	movl	$0x0, 0xc0(%rsp)
    4311:      	addq	$0x4, %rcx
    4315:      	leaq	0xc0(%rsp), %rdi
    431d:      	movl	$0x4, %edx
    4322:      	movl	$0x4, %eax
    4327:      	movq	0xa0(%rsp), %rdx
    432f:      	addq	$0x4, %rdx
    4333:      	movl	$0x4, %esi
    4338:      	callq	*%rax
    433a:      	movq	0xa0(%rsp), %rax
    4342:      	movslq	0xc0(%rsp), %rcx
    434a:      	shlq	$0x4, %rcx
    434e:      	addq	%rax, %rcx
    4351:      	addq	$0x80, %rcx
    4358:      	leaq	0x38(%rsp), %rdi
    435d:      	movl	$0x10, %edx
    4362:      	movl	$0x4, %eax
    4367:      	movq	0xa0(%rsp), %rcx
    436f:      	movslq	0xc0(%rsp), %rdx
    4377:      	shlq	$0x4, %rdx
    437b:      	addq	%rcx, %rdx
    437e:      	addq	$0x80, %rdx
    4385:      	movl	$0x10, %esi
    438a:      	callq	*%rax
    438c:      	leaq	0x5f44(%r12), %rdi
    4394:      	movl	$0x158, %edx            # imm = 0x158
    4399:      	movq	0x40(%rsp), %rcx
    439e:      	addq	%rdx, %rcx
    43a1:      	movl	$0x4, %esi
    43a6:      	movl	$0x4, %eax
    43ab:      	addq	0x40(%rsp), %rdx
    43b0:      	movl	$0x4, %esi
    43b5:      	callq	*%rax
    43b7:      	jmp	0x43c5 <generic_fentry_process_filter+0x5b5>
    43b9:      	movl	$0x0, 0x5f44(%r12)
    43c5:      	movq	%rbp, 0xb0(%rsp)
    43cd:      	leaq	0x5f48(%r12), %rdi
    43d5:      	movl	$0x158, %ebx            # imm = 0x158
    43da:      	movq	0x70(%rsp), %rcx
    43df:      	addq	%rbx, %rcx
    43e2:      	movl	$0x4, %edx
    43e7:      	movl	$0x4, %eax
    43ec:      	movq	0x70(%rsp), %rdx
    43f1:      	addq	%rbx, %rdx
    43f4:      	movl	$0x4, %esi
    43f9:      	callq	*%rax
    43fb:      	leaq	0x5f4c(%r12), %rdi
    4403:      	movl	$0x118, %edx            # imm = 0x118
    4408:      	movq	0x78(%rsp), %rcx
    440d:      	addq	%rdx, %rcx
    4410:      	movl	$0x4, %esi
    4415:      	movl	$0x4, %eax
    441a:      	addq	0x78(%rsp), %rdx
    441f:      	movl	$0x4, %esi
    4424:      	callq	*%rax
    4426:      	leaq	0x5f50(%r12), %rdi
    442e:      	movl	$0x98, %r12d
    4434:      	movq	0x80(%rsp), %rcx
    443c:      	addq	%r12, %rcx
    443f:      	movl	$0x4, %edx
    4444:      	movl	$0x4, %eax
    4449:      	movq	0x80(%rsp), %rdx
    4451:      	addq	%r12, %rdx
    4454:      	movl	$0x4, %esi
    4459:      	callq	*%rax
    445b:      	movq	0x30(%rsp), %rax
    4460:      	leaq	0x5f54(%rax), %rdi
    4467:      	movq	0x88(%rsp), %rcx
    446f:      	addq	%r12, %rcx
    4472:      	movl	$0x4, %edx
    4477:      	movl	$0x4, %eax
    447c:      	addq	0x88(%rsp), %r12
    4484:      	movl	$0x4, %esi
    4489:      	movq	%r12, %rdx
    448c:      	movq	0x30(%rsp), %r12
    4491:      	callq	*%rax
    4493:      	leaq	0x5f58(%r12), %rdi
    449b:      	movq	0x90(%rsp), %rcx
    44a3:      	addq	$0x58, %rcx
    44a7:      	movl	$0x4, %edx
    44ac:      	movl	$0x4, %eax
    44b1:      	movq	0x90(%rsp), %rdx
    44b9:      	addq	$0x58, %rdx
    44bd:      	movl	$0x4, %esi
    44c2:      	callq	*%rax
    44c4:      	movq	$0x0, 0x38(%rsp)
    44cd:      	movq	$0x0, 0xa0(%rsp)
    44d9:      	leaq	0x38(%rsp), %rdi
    44de:      	movl	$0x8, %ecx
    44e3:      	movl	$0x4, %eax
    44e8:      	movl	$0x8, %esi
    44ed:      	movq	%r15, %rdx
    44f0:      	callq	*%rax
    44f2:      	movl	$0x90, %edx
    44f7:      	movq	0x38(%rsp), %rcx
    44fc:      	addq	%rdx, %rcx
    44ff:      	leaq	0xa0(%rsp), %rdi
    4507:      	movl	$0x8, %esi
    450c:      	movl	$0x4, %eax
    4511:      	addq	0x38(%rsp), %rdx
    4516:      	movl	$0x8, %esi
    451b:      	callq	*%rax
    451d:      	leaq	0x5f5c(%r12), %rdi
    4525:      	movq	0xa0(%rsp), %rcx
    452d:      	addq	%rbx, %rcx
    4530:      	movl	$0x4, %edx
    4535:      	movl	$0x4, %eax
    453a:      	addq	0xa0(%rsp), %rbx
    4542:      	movl	$0x4, %esi
    4547:      	movq	%rbx, %rdx
    454a:      	callq	*%rax
    454c:      	cmpl	$0x1, 0x5f34(%r12)
    4555:      	jne	0x4560 <generic_fentry_process_filter+0x750>
    4557:      	orb	$0x2, 0x5f33(%r12)
    4560:      	leaq	0x5f78(%r12), %rdi
    4568:      	movl	$0x308, %edx            # imm = 0x308
    456d:      	movq	%rdi, 0xa8(%rsp)
    4575:      	xorl	%esi, %esi
    4577:      	callq	0x457c <generic_fentry_process_filter+0x76c>
    457c:      	leaq	0x6290(%r12), %rax
    4584:      	movq	%rax, 0x8(%rsp)
    4589:      	addq	$0xa78, %r13            # imm = 0xA78
    4590:      	leaq	0x38(%rsp), %rdi
    4595:      	movl	$0x8, %ecx
    459a:      	movl	$0x4, %eax
    459f:      	movl	$0x8, %esi
    45a4:      	movq	%r13, %rdx
    45a7:      	callq	*%rax
    45a9:      	movl	$0x5f8, %edx            # imm = 0x5F8
    45ae:      	movq	0x38(%rsp), %rcx
    45b3:      	addq	%rdx, %rcx
    45b6:      	leaq	0x50(%rsp), %rdi
    45bb:      	movl	$0x8, %esi
    45c0:      	movl	$0x4, %eax
    45c5:      	addq	0x38(%rsp), %rdx
    45ca:      	movl	$0x8, %esi
    45cf:      	callq	*%rax
    45d1:      	movq	0x50(%rsp), %rbx
    45d6:      	movl	$0x0, 0xcc(%rsp)
    45e1:      	movq	(%rip), %rdi            # 0x45e8 <generic_fentry_process_filter+0x7d8>
    45e8:      	leaq	0xcc(%rsp), %rsi
    45f0:      	movl	$0x1, %eax
    45f5:      	callq	*%rax
    45f7:      	testq	%rax, %rax
    45fa:      	je	0x493c <generic_fentry_process_filter+0xb2c>
    4600:      	movq	%rax, %r15
    4603:      	movl	$0x1000, 0x6410(%r12)   # imm = 0x1000
    460f:      	leaq	0x1000(%rax), %r13
    4616:      	movl	$0x23, %eax
    461b:      	callq	*%rax
    461d:      	leaq	0xd50(%rax), %rdx
    4624:      	leaq	0xe8(%rsp), %rdi
    462c:      	movl	$0x8, %ecx
    4631:      	movl	$0x4, %eax
    4636:      	movl	$0x8, %esi
    463b:      	callq	*%rax
    463d:      	movq	0xe8(%rsp), %r12
    4645:      	leaq	0x48(%rbx), %rbp
    4649:      	leaq	0xf0(%rsp), %rdi
    4651:      	movl	$0x8, %ecx
    4656:      	movl	$0x4, %eax
    465b:      	movl	$0x8, %esi
    4660:      	movq	%rbp, %rdx
    4663:      	callq	*%rax
    4665:      	movq	0xf0(%rsp), %r14
    466d:      	leaq	0x10(%r14), %rdx
    4671:      	leaq	0x50(%rsp), %rdi
    4676:      	movl	$0x8, %ecx
    467b:      	movl	$0x4, %eax
    4680:      	movl	$0x8, %esi
    4685:      	callq	*%rax
    4687:      	cmpq	$0x0, 0x50(%rsp)
    468d:      	je	0x49c6 <generic_fentry_process_filter+0xbb6>
    4693:      	movq	%rbp, 0xb8(%rsp)
    469b:      	movq	$0x0, 0x58(%rsp)
    46a4:      	movq	$0x0, 0x50(%rsp)
    46ad:      	movq	%r15, 0x60(%rsp)
    46b2:      	movq	$0x0, 0x68(%rsp)
    46bb:      	movq	$0x0, 0x70(%rsp)
    46c4:      	movq	$0x0, 0x78(%rsp)
    46cd:      	movq	%r13, 0x28(%rsp)
    46d2:      	movq	%r13, 0x80(%rsp)
    46da:      	movq	0x30(%rsp), %rax
    46df:      	movl	0x6410(%rax), %eax
    46e5:      	movl	%eax, 0x88(%rsp)
    46ec:      	leaq	0x18(%r12), %r15
    46f1:      	movb	$0x0, 0x8c(%rsp)
    46f9:      	addq	$0x20, %r12
    46fd:      	leaq	0x50(%rsp), %rdi
    4702:      	movl	$0x8, %r14d
    4708:      	movl	$0x4, %eax
    470d:      	addq	$0x40, %rbx
    4711:      	leaq	0x58(%rsp), %r13
    4716:      	leaq	0x68(%rsp), %rbp
    471b:      	movl	$0x8, %esi
    4720:      	movq	%r12, %rdx
    4723:      	callq	*%rax
    4725:      	movl	$0x8, %ecx
    472a:      	movl	$0x4, %eax
    472f:      	movq	%r13, %rdi
    4732:      	movl	$0x8, %esi
    4737:      	movq	%r15, %rdx
    473a:      	callq	*%rax
    473c:      	movl	$0x8, %ecx
    4741:      	movl	$0x4, %eax
    4746:      	movq	0xb8(%rsp), %rdx
    474e:      	movq	%rbp, %rdi
    4751:      	movl	$0x8, %esi
    4756:      	callq	*%rax
    4758:      	movl	$0x8, %ecx
    475d:      	movl	$0x4, %eax
    4762:      	leaq	0x70(%rsp), %rdi
    4767:      	movl	$0x8, %esi
    476c:      	movq	%rbx, %rdx
    476f:      	callq	*%rax
    4771:      	movq	0x70(%rsp), %rax
    4776:      	addq	$-0x20, %rax
    477a:      	movq	%rax, 0x78(%rsp)
    477f:      	movl	$0x80, %ebp
    4784:      	leaq	0x48(%rsp), %rbx
    4789:      	nopl	(%rax)
    4790:      	movq	0x68(%rsp), %r15
    4795:      	movq	0x70(%rsp), %rdx
    479a:      	movq	0x78(%rsp), %r12
    479f:      	cmpq	0x50(%rsp), %r15
    47a4:      	jne	0x47b1 <generic_fentry_process_filter+0x9a1>
    47a6:      	cmpq	0x58(%rsp), %rdx
    47ab:      	je	0x4a25 <generic_fentry_process_filter+0xc15>
    47b1:      	movl	$0x4, %eax
    47b6:      	leaq	0xc0(%rsp), %rdi
    47be:      	movl	$0x8, %esi
    47c3:      	callq	*%rax
    47c5:      	cmpq	0xc0(%rsp), %r15
    47cd:      	je	0x48e0 <generic_fentry_process_filter+0xad0>
    47d3:      	leaq	0x18(%r15), %r13
    47d7:      	movl	$0x4, %eax
    47dc:      	movq	%rbx, %rdi
    47df:      	movl	$0x8, %esi
    47e4:      	movq	%r13, %rdx
    47e7:      	callq	*%rax
    47e9:      	cmpq	%r15, 0x48(%rsp)
    47ee:      	je	0x48e0 <generic_fentry_process_filter+0xad0>
    47f4:      	movl	$0x4, %eax
    47f9:      	leaq	0xa0(%rsp), %rdi
    4801:      	movl	$0x8, %esi
    4806:      	movq	%r13, %rdx
    4809:      	callq	*%rax
    480b:      	addq	$0x20, %r15
    480f:      	movl	$0x4, %eax
    4814:      	leaq	0x38(%rsp), %rdi
    4819:      	movl	$0x10, %ecx
    481e:      	movl	$0x10, %esi
    4823:      	movq	%r15, %rdx
    4826:      	callq	*%rax
    4828:      	movq	0x60(%rsp), %r15
    482d:      	movq	0x80(%rsp), %rax
    4835:      	movl	0x3c(%rsp), %r12d
    483a:      	subq	%r15, %rax
    483d:      	movl	0x88(%rsp), %r13d
    4845:      	movl	%r12d, %edx
    4848:      	subl	%r13d, %edx
    484b:      	movl	$0x0, %ecx
    4850:      	cmovbl	%ecx, %edx
    4853:      	addq	0x40(%rsp), %rdx
    4858:      	xorl	%esi, %esi
    485a:      	cmpl	%r12d, %r13d
    485d:      	seta	%sil
    4861:      	movl	%r12d, %ecx
    4864:      	cmovbl	%r13d, %ecx
    4868:      	addl	%ecx, %esi
    486a:      	movl	%r13d, %edi
    486d:      	subl	%esi, %edi
    486f:      	movl	%edi, 0x88(%rsp)
    4876:      	subq	%rsi, %rax
    4879:      	jb	0x4a2d <generic_fentry_process_filter+0xc1d>
    487f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    4885:      	ja	0x4a2d <generic_fentry_process_filter+0xc1d>
    488b:      	cmpl	%r12d, %r13d
    488e:      	jbe	0x4895 <generic_fentry_process_filter+0xa85>
    4890:      	movb	$0x2f, (%r15,%rax)
    4895:      	xorl	%edi, %edi
    4897:      	cmpl	%r12d, %r13d
    489a:      	seta	%dil
    489e:      	movzbl	%cl, %esi
    48a1:      	addq	%rax, %r15
    48a4:      	addq	%r15, %rdi
    48a7:      	movl	$0x4, %eax
    48ac:      	callq	*%rax
    48ae:      	movq	%r15, 0x80(%rsp)
    48b6:      	cmpl	%r12d, %r13d
    48b9:      	jbe	0x4a2d <generic_fentry_process_filter+0xc1d>
    48bf:      	movq	0xa0(%rsp), %rax
    48c7:      	movq	%rax, 0x68(%rsp)
    48cc:      	decl	%ebp
    48ce:      	jne	0x4790 <generic_fentry_process_filter+0x980>
    48d4:      	jmp	0x4a2d <generic_fentry_process_filter+0xc1d>
    48d9:      	nopl	(%rax)
    48e0:      	leaq	0x10(%r12), %rdx
    48e5:      	movl	$0x4, %eax
    48ea:      	movq	%rbx, %rdi
    48ed:      	movl	$0x8, %esi
    48f2:      	callq	*%rax
    48f4:      	movq	0x78(%rsp), %rax
    48f9:      	cmpq	0x48(%rsp), %rax
    48fe:      	je	0x4b5c <generic_fentry_process_filter+0xd4c>
    4904:      	addq	$0x18, %r12
    4908:      	movl	$0x4, %eax
    490d:      	leaq	0x68(%rsp), %rdi
    4912:      	movl	$0x8, %esi
    4917:      	movq	%r12, %rdx
    491a:      	callq	*%rax
    491c:      	movq	0x48(%rsp), %rax
    4921:      	movq	%rax, 0x78(%rsp)
    4926:      	addq	$0x20, %rax
    492a:      	movq	%rax, 0x70(%rsp)
    492f:      	decl	%ebp
    4931:      	jne	0x4790 <generic_fentry_process_filter+0x980>
    4937:      	jmp	0x4a2d <generic_fentry_process_filter+0xc1d>
    493c:      	movq	0xb0(%rsp), %rbp
    4944:      	movl	0x6410(%r12), %eax
    494c:      	leal	-0x101(%rax), %ecx
    4952:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    4958:      	jbe	0x4cb6 <generic_fentry_process_filter+0xea6>
    495e:      	movzbl	%al, %ebx
    4961:      	leaq	0x5f80(%r12), %rdi
    4969:      	movl	$0x4, %eax
    496e:      	movq	0x8(%rsp), %rdx
    4973:      	movl	%ebx, %esi
    4975:      	callq	*%rax
    4977:      	movq	%rax, %r15
    497a:      	testq	%rax, %rax
    497d:      	je	0x4abd <generic_fentry_process_filter+0xcad>
    4983:      	movl	%r15d, %eax
    4986:      	negl	%eax
    4988:      	movw	%ax, 0x50(%rsp)
    498d:      	movw	$0xf, 0x52(%rsp)
    4994:      	movabsq	$0x400000164, %rax      # imm = 0x400000164
    499e:      	movq	%rax, 0x54(%rsp)
    49a3:      	movq	(%rip), %rdi            # 0x49aa <generic_fentry_process_filter+0xb9a>
    49aa:      	leaq	0x50(%rsp), %rsi
    49af:      	movl	$0x1, %eax
    49b4:      	callq	*%rax
    49b6:      	testq	%rax, %rax
    49b9:      	je	0x4a99 <generic_fentry_process_filter+0xc89>
    49bf:      	incl	(%rax)
    49c1:      	jmp	0x4abd <generic_fentry_process_filter+0xcad>
    49c6:      	leaq	0x18(%r14), %rdx
    49ca:      	leaq	0x50(%rsp), %rdi
    49cf:      	movl	$0x8, %ecx
    49d4:      	movl	$0x4, %eax
    49d9:      	movl	$0x8, %esi
    49de:      	callq	*%rax
    49e0:      	cmpq	%r14, 0x50(%rsp)
    49e5:      	je	0x4693 <generic_fentry_process_filter+0x883>
    49eb:      	movq	0x30(%rsp), %rdx
    49f0:      	movl	0x6410(%rdx), %ecx
    49f6:      	leal	-0xa(%rcx), %eax
    49f9:      	movl	%eax, 0x6410(%rdx)
    49ff:      	cmpl	$0x9, %ecx
    4a02:      	jg	0x51f9 <generic_fentry_process_filter+0x13e9>
    4a08:      	movl	$0xffffffdc, 0x6414(%rdx) # imm = 0xFFFFFFDC
    4a12:      	movq	%r13, %rbx
    4a15:      	movq	0xb0(%rsp), %rbp
    4a1d:      	movq	%rdx, %r12
    4a20:      	jmp	0x4ba4 <generic_fentry_process_filter+0xd94>
    4a25:      	movb	$0x1, 0x8c(%rsp)
    4a2d:      	movq	0x80(%rsp), %rbx
    4a35:      	movq	0x28(%rsp), %rcx
    4a3a:      	cmpq	%rcx, %rbx
    4a3d:      	je	0x4b7a <generic_fentry_process_filter+0xd6a>
    4a43:      	xorl	%ecx, %ecx
    4a45:      	cmpb	$0x0, 0x8c(%rsp)
    4a4d:      	sete	%cl
    4a50:      	addl	%ecx, %ecx
    4a52:      	movl	0x88(%rsp), %eax
    4a59:      	movq	0x30(%rsp), %r12
    4a5e:      	movl	%eax, 0x6410(%r12)
    4a66:      	movl	%ecx, 0x6414(%r12)
    4a6e:      	testl	%eax, %eax
    4a70:      	movq	0xb0(%rsp), %rbp
    4a78:      	jle	0x4a8b <generic_fentry_process_filter+0xc7b>
    4a7a:      	movl	$0x1000, %ecx           # imm = 0x1000
    4a7f:      	subl	%eax, %ecx
    4a81:      	movl	%ecx, 0x6410(%r12)
    4a89:      	movl	%ecx, %eax
    4a8b:      	testq	%rbx, %rbx
    4a8e:      	jne	0x4ba4 <generic_fentry_process_filter+0xd94>
    4a94:      	jmp	0x4c9c <generic_fentry_process_filter+0xe8c>
    4a99:      	movl	$0x1, 0x38(%rsp)
    4aa1:      	movq	(%rip), %rdi            # 0x4aa8 <generic_fentry_process_filter+0xc98>
    4aa8:      	xorl	%ecx, %ecx
    4aaa:      	leaq	0x50(%rsp), %rsi
    4aaf:      	leaq	0x38(%rsp), %rdx
    4ab4:      	movl	$0x2, %eax
    4ab9:      	xorl	%ecx, %ecx
    4abb:      	callq	*%rax
    4abd:      	testl	%r15d, %r15d
    4ac0:      	cmovel	%ebx, %r15d
    4ac4:      	movl	%r15d, 0x5f78(%r12)
    4acc:      	cmpl	$0x7f, %ebx
    4acf:      	movl	$0x7f, %esi
    4ad4:      	cmovbl	%ebx, %esi
    4ad7:      	leaq	0x6080(%r12), %rdi
    4adf:      	leaq	0x6390(%r12), %rdx
    4ae7:      	movl	$0x4, %eax
    4aec:      	callq	*%rax
    4aee:      	testq	%rax, %rax
    4af1:      	je	0x4cc4 <generic_fentry_process_filter+0xeb4>
    4af7:      	negl	%eax
    4af9:      	movw	%ax, 0x50(%rsp)
    4afe:      	movw	$0xf, 0x52(%rsp)
    4b05:      	movabsq	$0x40000016a, %rax      # imm = 0x40000016A
    4b0f:      	movq	%rax, 0x54(%rsp)
    4b14:      	movq	(%rip), %rdi            # 0x4b1b <generic_fentry_process_filter+0xd0b>
    4b1b:      	leaq	0x50(%rsp), %rsi
    4b20:      	movl	$0x1, %eax
    4b25:      	callq	*%rax
    4b27:      	testq	%rax, %rax
    4b2a:      	je	0x4b33 <generic_fentry_process_filter+0xd23>
    4b2c:      	incl	(%rax)
    4b2e:      	jmp	0x4cc4 <generic_fentry_process_filter+0xeb4>
    4b33:      	movl	$0x1, 0x38(%rsp)
    4b3b:      	movq	(%rip), %rdi            # 0x4b42 <generic_fentry_process_filter+0xd32>
    4b42:      	xorl	%ecx, %ecx
    4b44:      	leaq	0x50(%rsp), %rsi
    4b49:      	leaq	0x38(%rsp), %rdx
    4b4e:      	movl	$0x2, %eax
    4b53:      	xorl	%ecx, %ecx
    4b55:      	callq	*%rax
    4b57:      	jmp	0x4cc4 <generic_fentry_process_filter+0xeb4>
    4b5c:      	movb	$0x1, 0x8c(%rsp)
    4b64:      	movq	0x80(%rsp), %rbx
    4b6c:      	movq	0x28(%rsp), %rcx
    4b71:      	cmpq	%rcx, %rbx
    4b74:      	jne	0x4a43 <generic_fentry_process_filter+0xc33>
    4b7a:      	movq	0x30(%rsp), %r12
    4b7f:      	movl	$0x0, 0x6410(%r12)
    4b8b:      	movl	$0x0, 0x6414(%r12)
    4b97:      	xorl	%eax, %eax
    4b99:      	movq	%rcx, %rbx
    4b9c:      	movq	0xb0(%rsp), %rbp
    4ba4:      	xorl	%ecx, %ecx
    4ba6:      	movl	%eax, %r14d
    4ba9:      	subl	$0x7f, %r14d
    4bad:      	movl	$0x7f, %r15d
    4bb3:      	cmovbl	%eax, %r15d
    4bb7:      	cmovbl	%ecx, %r14d
    4bbb:      	cmpl	$0xff, %eax
    4bc0:      	movl	$0xff, %ecx
    4bc5:      	cmovbl	%eax, %ecx
    4bc8:      	movzbl	%cl, %esi
    4bcb:      	movl	%esi, 0x6410(%r12)
    4bd3:      	movl	$0x4, %eax
    4bd8:      	movq	0x8(%rsp), %rdi
    4bdd:      	movq	%rbx, %rdx
    4be0:      	callq	*%rax
    4be2:      	testq	%rax, %rax
    4be5:      	je	0x4c44 <generic_fentry_process_filter+0xe34>
    4be7:      	negl	%eax
    4be9:      	movw	%ax, 0x50(%rsp)
    4bee:      	movw	$0x8, 0x52(%rsp)
    4bf5:      	movabsq	$0x4000002de, %rax      # imm = 0x4000002DE
    4bff:      	movq	%rax, 0x54(%rsp)
    4c04:      	movq	(%rip), %rdi            # 0x4c0b <generic_fentry_process_filter+0xdfb>
    4c0b:      	leaq	0x50(%rsp), %rsi
    4c10:      	movl	$0x1, %eax
    4c15:      	callq	*%rax
    4c17:      	testq	%rax, %rax
    4c1a:      	je	0x4c20 <generic_fentry_process_filter+0xe10>
    4c1c:      	incl	(%rax)
    4c1e:      	jmp	0x4c44 <generic_fentry_process_filter+0xe34>
    4c20:      	movl	$0x1, 0x38(%rsp)
    4c28:      	movq	(%rip), %rdi            # 0x4c2f <generic_fentry_process_filter+0xe1f>
    4c2f:      	xorl	%ecx, %ecx
    4c31:      	leaq	0x50(%rsp), %rsi
    4c36:      	leaq	0x38(%rsp), %rdx
    4c3b:      	movl	$0x2, %eax
    4c40:      	xorl	%ecx, %ecx
    4c42:      	callq	*%rax
    4c44:      	leaq	0x6390(%r12), %rdi
    4c4c:      	addq	%r14, %rbx
    4c4f:      	movl	$0x4, %eax
    4c54:      	movl	%r15d, %esi
    4c57:      	movq	%rbx, %rdx
    4c5a:      	callq	*%rax
    4c5c:      	testq	%rax, %rax
    4c5f:      	je	0x4c9c <generic_fentry_process_filter+0xe8c>
    4c61:      	negl	%eax
    4c63:      	movw	%ax, 0x50(%rsp)
    4c68:      	movw	$0x8, 0x52(%rsp)
    4c6f:      	movabsq	$0x4000002e0, %rax      # imm = 0x4000002E0
    4c79:      	movq	%rax, 0x54(%rsp)
    4c7e:      	movq	(%rip), %rdi            # 0x4c85 <generic_fentry_process_filter+0xe75>
    4c85:      	leaq	0x50(%rsp), %rsi
    4c8a:      	movl	$0x1, %eax
    4c8f:      	callq	*%rax
    4c91:      	testq	%rax, %rax
    4c94:      	je	0x51b6 <generic_fentry_process_filter+0x13a6>
    4c9a:      	incl	(%rax)
    4c9c:      	movl	0x6410(%r12), %eax
    4ca4:      	leal	-0x101(%rax), %ecx
    4caa:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    4cb0:      	ja	0x495e <generic_fentry_process_filter+0xb4e>
    4cb6:      	movq	0xa8(%rsp), %rax
    4cbe:      	movl	$0xffffffff, (%rax)     # imm = 0xFFFFFFFF
    4cc4:      	leaq	0x5f10(%r12), %r14
    4ccc:      	orb	$0x10, 0x1(%r12)
    4cd2:      	leaq	0x5ef8(%r12), %rsi
    4cda:      	movq	(%rip), %rdi            # 0x4ce1 <generic_fentry_process_filter+0xed1>
    4ce1:      	movl	$0x1, %eax
    4ce6:      	callq	*%rax
    4ce8:      	testq	%rax, %rax
    4ceb:      	je	0x60c6 <generic_fentry_process_filter+0x22b6>
    4cf1:      	movq	0x5eb8(%r12), %rbx
    4cf9:      	cmpq	$0x6, %rbx
    4cfd:      	jae	0x4f3a <generic_fentry_process_filter+0x112a>
    4d03:      	movslq	(%rax), %rcx
    4d06:      	testq	%rcx, %rcx
    4d09:      	je	0x4f5f <generic_fentry_process_filter+0x114f>
    4d0f:      	cmpq	%rcx, %rbx
    4d12:      	jae	0x4f3a <generic_fentry_process_filter+0x112a>
    4d18:      	movq	%rax, 0x8(%rsp)
    4d1d:      	movq	%rcx, 0xb8(%rsp)
    4d25:      	movq	%rbp, 0xb0(%rsp)
    4d2d:      	movl	%ebx, 0x50(%rsp)
    4d31:      	movl	$0x0, 0x38(%rsp)
    4d39:      	movq	(%rip), %rdi            # 0x4d40 <generic_fentry_process_filter+0xf30>
    4d40:      	leaq	0x50(%rsp), %rsi
    4d45:      	movl	$0x1, %eax
    4d4a:      	callq	*%rax
    4d4c:      	testq	%rax, %rax
    4d4f:      	movq	%r14, 0x28(%rsp)
    4d54:      	je	0x4f7e <generic_fentry_process_filter+0x116e>
    4d5a:      	movq	%rax, %r13
    4d5d:      	movl	(%rax), %eax
    4d5f:      	testl	%eax, %eax
    4d61:      	je	0x4f7e <generic_fentry_process_filter+0x116e>
    4d67:      	cmpl	$0x0, 0x68(%r14)
    4d6c:      	js	0x606c <generic_fentry_process_filter+0x225c>
    4d72:      	cmpl	$0x1b, %eax
    4d75:      	ja	0x606c <generic_fentry_process_filter+0x225c>
    4d7b:      	movl	$0x60, %ecx
    4d80:      	btl	%eax, %ecx
    4d83:      	jb	0x53c8 <generic_fentry_process_filter+0x15b8>
    4d89:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    4d8e:      	btl	%eax, %ecx
    4d91:      	jb	0x5338 <generic_fentry_process_filter+0x1528>
    4d97:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    4d9c:      	btl	%eax, %ecx
    4d9f:      	jae	0x606c <generic_fentry_process_filter+0x225c>
    4da5:      	movq	%r13, %rsi
    4da8:      	addq	$0x4, %rsi
    4dac:      	movq	(%rip), %rdi            # 0x4db3 <generic_fentry_process_filter+0xfa3>
    4db3:      	movl	$0x1, %eax
    4db8:      	callq	*%rax
    4dba:      	testq	%rax, %rax
    4dbd:      	je	0x606c <generic_fentry_process_filter+0x225c>
    4dc3:      	movq	%rax, %r15
    4dc6:      	movq	0x28(%rsp), %rax
    4dcb:      	movl	0x68(%rax), %eax
    4dce:      	cmpl	$0x7f, %eax
    4dd1:      	movl	$0x7f, %r14d
    4dd7:      	cmovll	%eax, %r14d
    4ddb:      	movq	(%rip), %rdi            # 0x4de2 <generic_fentry_process_filter+0xfd2>
    4de2:      	leaq	0x38(%rsp), %rsi
    4de7:      	movl	$0x1, %eax
    4dec:      	callq	*%rax
    4dee:      	testq	%rax, %rax
    4df1:      	je	0x606c <generic_fentry_process_filter+0x225c>
    4df7:      	movq	%rax, %rbp
    4dfa:      	leal	(,%r14,8), %eax
    4e02:      	movl	%eax, (%rbp)
    4e05:      	movq	0x28(%rsp), %rax
    4e0a:      	cmpl	$0x0, 0x6c(%rax)
    4e0e:      	jne	0x4f01 <generic_fentry_process_filter+0x10f1>
    4e14:      	movq	%r15, 0xa8(%rsp)
    4e1c:      	movq	0x28(%rsp), %r15
    4e21:      	movl	0x68(%r15), %ecx
    4e25:      	movl	%ecx, %eax
    4e27:      	subl	%r14d, %eax
    4e2a:      	movl	%r14d, %edx
    4e2d:      	andl	$0x7f, %edx
    4e30:      	addl	%edx, %eax
    4e32:      	addl	%ecx, %edx
    4e34:      	movl	%r14d, %ecx
    4e37:      	notl	%ecx
    4e39:      	addl	%edx, %ecx
    4e3b:      	subl	%r14d, %edx
    4e3e:      	leal	-0x4(%rdx), %esi
    4e41:      	leaq	0x1f3(%r15), %rdi
    4e48:      	leal	-0x3(%rdx), %r8d
    4e4c:      	addl	$-0x2, %edx
    4e4f:      	movq	$-0x3, %r9
    4e56:      	leal	(%rcx,%r9), %r10d
    4e5a:      	addl	$0x3, %r10d
    4e5e:      	andl	$0x7f, %r10d
    4e62:      	movzbl	0x170(%r15,%r10), %r10d
    4e6b:      	movb	%r10b, -0x3(%rdi)
    4e6f:      	leaq	(%rax,%r9), %r10
    4e73:      	cmpq	$-0x2, %r10
    4e77:      	je	0x4ef1 <generic_fentry_process_filter+0x10e1>
    4e79:      	leal	(%rdx,%r9), %r11d
    4e7d:      	addl	$0x3, %r11d
    4e81:      	andl	$0x7f, %r11d
    4e85:      	movzbl	0x170(%r15,%r11), %r11d
    4e8e:      	movb	%r11b, -0x2(%rdi)
    4e92:      	cmpq	$-0x1, %r10
    4e96:      	je	0x4ef1 <generic_fentry_process_filter+0x10e1>
    4e98:      	leal	(%r8,%r9), %r10d
    4e9c:      	addl	$0x3, %r10d
    4ea0:      	andl	$0x7f, %r10d
    4ea4:      	movzbl	0x170(%r15,%r10), %r10d
    4ead:      	movb	%r10b, -0x1(%rdi)
    4eb1:      	movq	%rax, %r10
    4eb4:      	addq	%r9, %r10
    4eb7:      	je	0x4ef1 <generic_fentry_process_filter+0x10e1>
    4eb9:      	cmpq	$-0x7f, %r9
    4ebd:      	je	0x4ef1 <generic_fentry_process_filter+0x10e1>
    4ebf:      	leal	(%rsi,%r9), %r10d
    4ec3:      	addl	$0x3, %r10d
    4ec7:      	andl	$0x7f, %r10d
    4ecb:      	movzbl	0x170(%r15,%r10), %r10d
    4ed4:      	movb	%r10b, (%rdi)
    4ed7:      	addq	$0x4, %rdi
    4edb:      	leaq	(%rax,%r9), %r10
    4edf:      	addq	$-0x4, %r10
    4ee3:      	addq	$-0x4, %r9
    4ee7:      	cmpq	$-0x3, %r10
    4eeb:      	jne	0x4e56 <generic_fentry_process_filter+0x1046>
    4ef1:      	movl	$0x1, 0x6c(%r15)
    4ef9:      	movq	0xa8(%rsp), %r15
    4f01:      	cmpl	$0x7f, %r14d
    4f05:      	ja	0x4f2d <generic_fentry_process_filter+0x111d>
    4f07:      	movslq	%r14d, %rsi
    4f0a:      	movq	%rbp, %rdi
    4f0d:      	addq	$0x4, %rdi
    4f11:      	movq	0x28(%rsp), %rax
    4f16:      	leaq	0x1f0(%rax), %rdx
    4f1d:      	movl	$0x4, %eax
    4f22:      	callq	*%rax
    4f24:      	testq	%rax, %rax
    4f27:      	js	0x606c <generic_fentry_process_filter+0x225c>
    4f2d:      	movl	$0x1, %eax
    4f32:      	movq	%r15, %rdi
    4f35:      	jmp	0x53c3 <generic_fentry_process_filter+0x15b3>
    4f3a:      	movl	(%r14), %eax
    4f3d:      	movl	%eax, 0x10(%r12)
    4f42:      	movq	0x8(%r14), %rax
    4f46:      	movq	%rax, 0x18(%r12)
    4f4b:      	cmpb	$0x0, 0x5ec0(%r12)
    4f54:      	jne	0x60b1 <generic_fentry_process_filter+0x22a1>
    4f5a:      	jmp	0x60c6 <generic_fentry_process_filter+0x22b6>
    4f5f:      	movb	$0x1, 0x5ec0(%r12)
    4f68:      	movl	(%r14), %eax
    4f6b:      	movl	%eax, 0x10(%r12)
    4f70:      	movq	0x8(%r14), %rax
    4f74:      	movq	%rax, 0x18(%r12)
    4f79:      	jmp	0x60b1 <generic_fentry_process_filter+0x22a1>
    4f7e:      	movq	0x8(%rsp), %r10
    4f83:      	movq	(%rip), %rax            # 0x4f8a <generic_fentry_process_filter+0x117a>
    4f8a:      	cmpb	$0x0, (%rax)
    4f8d:      	je	0x5230 <generic_fentry_process_filter+0x1420>
    4f93:      	movq	(%rip), %rdi            # 0x4f9a <generic_fentry_process_filter+0x118a>
    4f9a:      	movl	$0x1, %eax
    4f9f:      	movq	0x28(%rsp), %rsi
    4fa4:      	callq	*%rax
    4fa6:      	movq	0x8(%rsp), %r10
    4fab:      	testq	%rax, %rax
    4fae:      	je	0x5230 <generic_fentry_process_filter+0x1420>
    4fb4:      	movq	%rax, %rbp
    4fb7:      	leal	0x5(%rbx), %eax
    4fba:      	movl	%eax, 0x50(%rsp)
    4fbe:      	movl	$0x0, 0x38(%rsp)
    4fc6:      	movq	(%rip), %rdi            # 0x4fcd <generic_fentry_process_filter+0x11bd>
    4fcd:      	leaq	0x50(%rsp), %rsi
    4fd2:      	movl	$0x1, %eax
    4fd7:      	callq	*%rax
    4fd9:      	testq	%rax, %rax
    4fdc:      	je	0x522b <generic_fentry_process_filter+0x141b>
    4fe2:      	movq	%rax, %r13
    4fe5:      	movl	(%rax), %eax
    4fe7:      	testl	%eax, %eax
    4fe9:      	je	0x522b <generic_fentry_process_filter+0x141b>
    4fef:      	cmpl	$0x0, (%rbp)
    4ff3:      	js	0x606c <generic_fentry_process_filter+0x225c>
    4ff9:      	cmpl	$0x1b, %eax
    4ffc:      	ja	0x606c <generic_fentry_process_filter+0x225c>
    5002:      	movl	$0x60, %ecx
    5007:      	btl	%eax, %ecx
    500a:      	jb	0x54e6 <generic_fentry_process_filter+0x16d6>
    5010:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    5015:      	btl	%eax, %ecx
    5018:      	jb	0x5458 <generic_fentry_process_filter+0x1648>
    501e:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    5023:      	btl	%eax, %ecx
    5026:      	jae	0x606c <generic_fentry_process_filter+0x225c>
    502c:      	movq	%r13, %rsi
    502f:      	addq	$0x4, %rsi
    5033:      	movq	(%rip), %rdi            # 0x503a <generic_fentry_process_filter+0x122a>
    503a:      	movl	$0x1, %eax
    503f:      	callq	*%rax
    5041:      	testq	%rax, %rax
    5044:      	je	0x606c <generic_fentry_process_filter+0x225c>
    504a:      	movq	%rax, %r15
    504d:      	movl	(%rbp), %eax
    5050:      	cmpl	$0x7f, %eax
    5053:      	movl	$0x7f, %r14d
    5059:      	cmovll	%eax, %r14d
    505d:      	movq	(%rip), %rdi            # 0x5064 <generic_fentry_process_filter+0x1254>
    5064:      	leaq	0x38(%rsp), %rsi
    5069:      	movl	$0x1, %eax
    506e:      	callq	*%rax
    5070:      	testq	%rax, %rax
    5073:      	je	0x606c <generic_fentry_process_filter+0x225c>
    5079:      	movq	%rax, %rcx
    507c:      	leal	(,%r14,8), %eax
    5084:      	movl	%eax, (%rcx)
    5086:      	cmpl	$0x0, 0x4(%rbp)
    508a:      	jne	0x5176 <generic_fentry_process_filter+0x1366>
    5090:      	movq	%rcx, 0xa8(%rsp)
    5098:      	movl	(%rbp), %ecx
    509b:      	movl	%ecx, %eax
    509d:      	subl	%r14d, %eax
    50a0:      	movl	%r14d, %edx
    50a3:      	andl	$0x7f, %edx
    50a6:      	addl	%edx, %eax
    50a8:      	addl	%ecx, %edx
    50aa:      	movl	%r14d, %ecx
    50ad:      	notl	%ecx
    50af:      	addl	%edx, %ecx
    50b1:      	subl	%r14d, %edx
    50b4:      	leal	-0x4(%rdx), %esi
    50b7:      	leaq	0x18b(%rbp), %rdi
    50be:      	leal	-0x3(%rdx), %r8d
    50c2:      	addl	$-0x2, %edx
    50c5:      	movq	$-0x3, %r9
    50cc:      	leal	(%rcx,%r9), %r10d
    50d0:      	addl	$0x3, %r10d
    50d4:      	andl	$0x7f, %r10d
    50d8:      	movzbl	0x108(%rbp,%r10), %r10d
    50e1:      	movb	%r10b, -0x3(%rdi)
    50e5:      	leaq	(%rax,%r9), %r10
    50e9:      	cmpq	$-0x2, %r10
    50ed:      	je	0x5167 <generic_fentry_process_filter+0x1357>
    50ef:      	leal	(%rdx,%r9), %r11d
    50f3:      	addl	$0x3, %r11d
    50f7:      	andl	$0x7f, %r11d
    50fb:      	movzbl	0x108(%rbp,%r11), %r11d
    5104:      	movb	%r11b, -0x2(%rdi)
    5108:      	cmpq	$-0x1, %r10
    510c:      	je	0x5167 <generic_fentry_process_filter+0x1357>
    510e:      	leal	(%r8,%r9), %r10d
    5112:      	addl	$0x3, %r10d
    5116:      	andl	$0x7f, %r10d
    511a:      	movzbl	0x108(%rbp,%r10), %r10d
    5123:      	movb	%r10b, -0x1(%rdi)
    5127:      	movq	%rax, %r10
    512a:      	addq	%r9, %r10
    512d:      	je	0x5167 <generic_fentry_process_filter+0x1357>
    512f:      	cmpq	$-0x7f, %r9
    5133:      	je	0x5167 <generic_fentry_process_filter+0x1357>
    5135:      	leal	(%rsi,%r9), %r10d
    5139:      	addl	$0x3, %r10d
    513d:      	andl	$0x7f, %r10d
    5141:      	movzbl	0x108(%rbp,%r10), %r10d
    514a:      	movb	%r10b, (%rdi)
    514d:      	addq	$0x4, %rdi
    5151:      	leaq	(%rax,%r9), %r10
    5155:      	addq	$-0x4, %r10
    5159:      	addq	$-0x4, %r9
    515d:      	cmpq	$-0x3, %r10
    5161:      	jne	0x50cc <generic_fentry_process_filter+0x12bc>
    5167:      	movl	$0x1, 0x4(%rbp)
    516e:      	movq	0xa8(%rsp), %rcx
    5176:      	cmpl	$0x7f, %r14d
    517a:      	ja	0x51a6 <generic_fentry_process_filter+0x1396>
    517c:      	movslq	%r14d, %rsi
    517f:      	movq	%rcx, %rdi
    5182:      	addq	$0x4, %rdi
    5186:      	addq	$0x188, %rbp            # imm = 0x188
    518d:      	movl	$0x4, %eax
    5192:      	movq	%rbp, %rdx
    5195:      	movq	%rcx, %r14
    5198:      	callq	*%rax
    519a:      	movq	%r14, %rcx
    519d:      	testq	%rax, %rax
    51a0:      	js	0x606c <generic_fentry_process_filter+0x225c>
    51a6:      	movl	$0x1, %eax
    51ab:      	movq	%r15, %rdi
    51ae:      	movq	%rcx, %rsi
    51b1:      	jmp	0x5546 <generic_fentry_process_filter+0x1736>
    51b6:      	movl	$0x1, 0x38(%rsp)
    51be:      	movq	(%rip), %rdi            # 0x51c5 <generic_fentry_process_filter+0x13b5>
    51c5:      	xorl	%ecx, %ecx
    51c7:      	leaq	0x50(%rsp), %rsi
    51cc:      	leaq	0x38(%rsp), %rdx
    51d1:      	movl	$0x2, %eax
    51d6:      	xorl	%ecx, %ecx
    51d8:      	callq	*%rax
    51da:      	movl	0x6410(%r12), %eax
    51e2:      	leal	-0x101(%rax), %ecx
    51e8:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    51ee:      	jbe	0x4cb6 <generic_fentry_process_filter+0xea6>
    51f4:      	jmp	0x495e <generic_fentry_process_filter+0xb4e>
    51f9:      	movq	%rbp, 0xb8(%rsp)
    5201:      	movq	%r15, %r13
    5204:      	addq	$0xff6, %r13            # imm = 0xFF6
    520b:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    5215:      	movq	%rax, 0xff6(%r15)
    521c:      	movw	$0x2964, 0xffe(%r15)    # imm = 0x2964
    5226:      	jmp	0x469b <generic_fentry_process_filter+0x88b>
    522b:      	movq	0x8(%rsp), %r10
    5230:      	movl	%ebx, %eax
    5232:      	leaq	0x4(,%rax,4), %rcx
    523a:      	movl	0x4(%r10,%rax,4), %eax
    523f:      	leal	(%rax,%rcx), %edx
    5242:      	andl	$0x3ff, %edx            # imm = 0x3FF
    5248:      	addl	%eax, %ecx
    524a:      	addl	$0x4, %ecx
    524d:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5253:      	leaq	0x8(%rdx), %rbp
    5257:      	cmpl	$0x5, (%rcx,%r10)
    525c:      	jb	0x532e <generic_fentry_process_filter+0x151e>
    5262:      	movq	%rdx, 0xd8(%rsp)
    526a:      	movl	(%rbp,%r10), %edi
    526f:      	movl	0x4(%rbp,%r10), %r8d
    5274:      	movl	0x8(%rbp,%r10), %edx
    5279:      	movq	$0x0, 0x58(%rsp)
    5282:      	movq	$0x0, 0x50(%rsp)
    528b:      	cmpl	$0x4, %edx
    528e:      	movl	$0x4, %ecx
    5293:      	cmovbl	%edx, %ecx
    5296:      	cmpl	$0x6, %edi
    5299:      	jne	0x52af <generic_fentry_process_filter+0x149f>
    529b:      	movabsq	$0x100000001, %rsi      # imm = 0x100000001
    52a5:      	movq	%rsi, 0x50(%rsp)
    52aa:      	movq	%rsi, 0x58(%rsp)
    52af:      	testl	%edx, %edx
    52b1:      	movq	0x28(%rsp), %r14
    52b6:      	je	0x5a32 <generic_fentry_process_filter+0x1c22>
    52bc:      	leaq	0x24(%r14), %rdx
    52c0:      	testb	$0x1, %r8b
    52c4:      	movq	%rdx, 0xe0(%rsp)
    52cc:      	movq	%rdx, %r9
    52cf:      	cmoveq	%r14, %r9
    52d3:      	leaq	0x10(%r14), %rdx
    52d7:      	movq	%rdx, 0xd0(%rsp)
    52df:      	leal	(%rax,%rbx,4), %r11d
    52e3:      	addl	$0x4, %r11d
    52e7:      	andl	$0x3ff, %r11d           # imm = 0x3FF
    52ee:      	addq	$0x14, %r11
    52f2:      	decq	%rcx
    52f5:      	cmpq	$0x3, %rcx
    52f9:      	movl	$0x3, %eax
    52fe:      	cmovbq	%rcx, %rax
    5302:      	movl	%eax, %eax
    5304:      	leaq	0x4(,%rax,4), %rax
    530c:      	movq	%rax, 0xa8(%rsp)
    5314:      	xorl	%ebx, %ebx
    5316:      	movl	%edi, 0x4(%rsp)
    531a:      	movq	%r8, 0x20(%rsp)
    531f:      	movq	%r9, 0x18(%rsp)
    5324:      	movq	%r11, 0x10(%rsp)
    5329:      	jmp	0x55cc <generic_fentry_process_filter+0x17bc>
    532e:      	movl	$0x1, %eax
    5333:      	jmp	0x5a73 <generic_fentry_process_filter+0x1c63>
    5338:      	movq	%r13, %rsi
    533b:      	addq	$0x4, %rsi
    533f:      	movq	(%rip), %rdi            # 0x5346 <generic_fentry_process_filter+0x1536>
    5346:      	movl	$0x1, %eax
    534b:      	callq	*%rax
    534d:      	testq	%rax, %rax
    5350:      	je	0x606c <generic_fentry_process_filter+0x225c>
    5356:      	movq	%rax, %r14
    5359:      	movq	(%rip), %rdi            # 0x5360 <generic_fentry_process_filter+0x1550>
    5360:      	leaq	0x38(%rsp), %rsi
    5365:      	movl	$0x1, %eax
    536a:      	callq	*%rax
    536c:      	testq	%rax, %rax
    536f:      	je	0x606c <generic_fentry_process_filter+0x225c>
    5375:      	movq	%rax, %rbp
    5378:      	movl	$0x104, %edx            # imm = 0x104
    537d:      	movq	%rax, %rdi
    5380:      	xorl	%esi, %esi
    5382:      	callq	0x5387 <generic_fentry_process_filter+0x1577>
    5387:      	movq	0x28(%rsp), %rsi
    538c:      	movl	0x68(%rsi), %eax
    538f:      	leal	(,%rax,8), %ecx
    5396:      	movl	%ecx, (%rbp)
    5399:      	movq	%rbp, %rdi
    539c:      	addq	$0x4, %rdi
    53a0:      	movzbl	%al, %ecx
    53a3:      	leaq	0x70(%rsi), %rdx
    53a7:      	movl	$0x4, %eax
    53ac:      	movzbl	0x68(%rsi), %esi
    53b0:      	callq	*%rax
    53b2:      	testq	%rax, %rax
    53b5:      	js	0x606c <generic_fentry_process_filter+0x225c>
    53bb:      	movl	$0x1, %eax
    53c0:      	movq	%r14, %rdi
    53c3:      	movq	%rbp, %rsi
    53c6:      	jmp	0x5421 <generic_fentry_process_filter+0x1611>
    53c8:      	movl	0x8(%r13), %eax
    53cc:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    53d1:      	cmpq	%rcx, %rax
    53d4:      	movq	0x28(%rsp), %rcx
    53d9:      	je	0x53f4 <generic_fentry_process_filter+0x15e4>
    53db:      	movq	0x370(%rcx), %rcx
    53e2:      	btq	%rax, %rcx
    53e6:      	jae	0x53f4 <generic_fentry_process_filter+0x15e4>
    53e8:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    53f2:      	jmp	0x5423 <generic_fentry_process_filter+0x1613>
    53f4:      	movq	(%rip), %rdi            # 0x53fb <generic_fentry_process_filter+0x15eb>
    53fb:      	leaq	0x50(%rsp), %rsi
    5400:      	movl	$0x1, %eax
    5405:      	callq	*%rax
    5407:      	testq	%rax, %rax
    540a:      	je	0x606c <generic_fentry_process_filter+0x225c>
    5410:      	movq	%rax, %rdi
    5413:      	movq	0x28(%rsp), %rax
    5418:      	leaq	0x70(%rax), %rsi
    541c:      	movl	$0x1, %eax
    5421:      	callq	*%rax
    5423:      	movl	(%r13), %ecx
    5427:      	cmpq	$0x25, %rcx
    542b:      	movq	0x8(%rsp), %r10
    5430:      	ja	0x550d <generic_fentry_process_filter+0x16fd>
    5436:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    5440:      	btq	%rcx, %rdx
    5444:      	jae	0x550d <generic_fentry_process_filter+0x16fd>
    544a:      	testq	%rax, %rax
    544d:      	jne	0x606c <generic_fentry_process_filter+0x225c>
    5453:      	jmp	0x4f83 <generic_fentry_process_filter+0x1173>
    5458:      	movq	%r13, %rsi
    545b:      	addq	$0x4, %rsi
    545f:      	movq	(%rip), %rdi            # 0x5466 <generic_fentry_process_filter+0x1656>
    5466:      	movl	$0x1, %eax
    546b:      	callq	*%rax
    546d:      	testq	%rax, %rax
    5470:      	je	0x606c <generic_fentry_process_filter+0x225c>
    5476:      	movq	%rax, %r14
    5479:      	movq	(%rip), %rdi            # 0x5480 <generic_fentry_process_filter+0x1670>
    5480:      	leaq	0x38(%rsp), %rsi
    5485:      	movl	$0x1, %eax
    548a:      	callq	*%rax
    548c:      	testq	%rax, %rax
    548f:      	je	0x606c <generic_fentry_process_filter+0x225c>
    5495:      	movq	%rax, %r15
    5498:      	movl	$0x104, %edx            # imm = 0x104
    549d:      	movq	%rax, %rdi
    54a0:      	xorl	%esi, %esi
    54a2:      	callq	0x54a7 <generic_fentry_process_filter+0x1697>
    54a7:      	movl	(%rbp), %eax
    54aa:      	leal	(,%rax,8), %ecx
    54b1:      	movl	%ecx, (%r15)
    54b4:      	movq	%r15, %rdi
    54b7:      	addq	$0x4, %rdi
    54bb:      	movzbl	%al, %ecx
    54be:      	movq	%rbp, %rdx
    54c1:      	addq	$0x8, %rdx
    54c5:      	movl	$0x4, %eax
    54ca:      	movzbl	(%rbp), %esi
    54ce:      	callq	*%rax
    54d0:      	testq	%rax, %rax
    54d3:      	js	0x606c <generic_fentry_process_filter+0x225c>
    54d9:      	movl	$0x1, %eax
    54de:      	movq	%r14, %rdi
    54e1:      	movq	%r15, %rsi
    54e4:      	jmp	0x5546 <generic_fentry_process_filter+0x1736>
    54e6:      	movl	0x8(%r13), %eax
    54ea:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    54ef:      	cmpq	%rcx, %rax
    54f2:      	je	0x551b <generic_fentry_process_filter+0x170b>
    54f4:      	movq	0x308(%rbp), %rcx
    54fb:      	btq	%rax, %rcx
    54ff:      	jae	0x551b <generic_fentry_process_filter+0x170b>
    5501:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    550b:      	jmp	0x5548 <generic_fentry_process_filter+0x1738>
    550d:      	testq	%rax, %rax
    5510:      	jne	0x4f83 <generic_fentry_process_filter+0x1173>
    5516:      	jmp	0x606c <generic_fentry_process_filter+0x225c>
    551b:      	movq	(%rip), %rdi            # 0x5522 <generic_fentry_process_filter+0x1712>
    5522:      	leaq	0x50(%rsp), %rsi
    5527:      	movl	$0x1, %eax
    552c:      	callq	*%rax
    552e:      	testq	%rax, %rax
    5531:      	je	0x606c <generic_fentry_process_filter+0x225c>
    5537:      	movq	%rax, %rdi
    553a:      	addq	$0x8, %rbp
    553e:      	movl	$0x1, %eax
    5543:      	movq	%rbp, %rsi
    5546:      	callq	*%rax
    5548:      	movl	(%r13), %ecx
    554c:      	cmpq	$0x25, %rcx
    5550:      	movq	0x8(%rsp), %r10
    5555:      	ja	0x5575 <generic_fentry_process_filter+0x1765>
    5557:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    5561:      	btq	%rcx, %rdx
    5565:      	jae	0x5575 <generic_fentry_process_filter+0x1765>
    5567:      	testq	%rax, %rax
    556a:      	jne	0x606c <generic_fentry_process_filter+0x225c>
    5570:      	jmp	0x5230 <generic_fentry_process_filter+0x1420>
    5575:      	testq	%rax, %rax
    5578:      	jne	0x5230 <generic_fentry_process_filter+0x1420>
    557e:      	jmp	0x606c <generic_fentry_process_filter+0x225c>
    5583:      	movq	0x30(%rsp), %r12
    5588:      	movq	0x28(%rsp), %r14
    558d:      	movq	0x8(%rsp), %r10
    5592:      	movl	0x4(%rsp), %edi
    5596:      	movq	0x20(%rsp), %r8
    559b:      	movq	0x18(%rsp), %r9
    55a0:      	movq	0x10(%rsp), %r11
    55a5:      	cmpl	$0x6, %edi
    55a8:      	setne	%al
    55ab:      	xorb	$0x1, %r13b
    55af:      	orb	%al, %r13b
    55b2:      	movzbl	%r13b, %eax
    55b6:      	movl	%eax, 0x50(%rsp,%rbx)
    55ba:      	addq	$0x4, %rbx
    55be:      	cmpq	%rbx, 0xa8(%rsp)
    55c6:      	je	0x5a32 <generic_fentry_process_filter+0x1c22>
    55cc:      	leaq	(%r11,%rbx), %rax
    55d0:      	movl	(%r9), %ecx
    55d3:      	cmpq	$0x3e8, %rax            # imm = 0x3E8
    55d9:      	jbe	0x5801 <generic_fentry_process_filter+0x19f1>
    55df:      	xorl	%r15d, %r15d
    55e2:      	testb	$0x2, %r8b
    55e6:      	je	0x581e <generic_fentry_process_filter+0x1a0e>
    55ec:      	testb	$0x1, %r8b
    55f0:      	jne	0x583e <generic_fentry_process_filter+0x1a2e>
    55f6:      	movl	(%r14), %eax
    55f9:      	movb	$0x1, %r13b
    55fc:      	cmpq	%rax, %r15
    55ff:      	je	0x55a5 <generic_fentry_process_filter+0x1795>
    5601:      	movl	0x10(%r14), %eax
    5605:      	cmpq	%rax, %r15
    5608:      	je	0x55a5 <generic_fentry_process_filter+0x1795>
    560a:      	movl	$0x1, %eax
    560f:      	movq	0xd0(%rsp), %rsi
    5617:      	movq	(%rip), %rdi            # 0x561e <generic_fentry_process_filter+0x180e>
    561e:      	callq	*%rax
    5620:      	testq	%rax, %rax
    5623:      	je	0x5a01 <generic_fentry_process_filter+0x1bf1>
    5629:      	movq	%rax, %rsi
    562c:      	movl	(%rax), %eax
    562e:      	cmpq	%rax, %r15
    5631:      	je	0x558d <generic_fentry_process_filter+0x177d>
    5637:      	movl	0x10(%rsi), %eax
    563a:      	cmpq	%rax, %r15
    563d:      	je	0x558d <generic_fentry_process_filter+0x177d>
    5643:      	addq	$0x10, %rsi
    5647:      	movl	$0x1, %eax
    564c:      	movq	(%rip), %rdi            # 0x5653 <generic_fentry_process_filter+0x1843>
    5653:      	callq	*%rax
    5655:      	testq	%rax, %rax
    5658:      	je	0x5a01 <generic_fentry_process_filter+0x1bf1>
    565e:      	movq	%rax, %rsi
    5661:      	movl	(%rax), %eax
    5663:      	cmpq	%rax, %r15
    5666:      	je	0x558d <generic_fentry_process_filter+0x177d>
    566c:      	movl	0x10(%rsi), %eax
    566f:      	cmpq	%rax, %r15
    5672:      	je	0x558d <generic_fentry_process_filter+0x177d>
    5678:      	addq	$0x10, %rsi
    567c:      	movl	$0x1, %eax
    5681:      	movq	(%rip), %rdi            # 0x5688 <generic_fentry_process_filter+0x1878>
    5688:      	callq	*%rax
    568a:      	testq	%rax, %rax
    568d:      	je	0x5a01 <generic_fentry_process_filter+0x1bf1>
    5693:      	movq	%rax, %rsi
    5696:      	movl	(%rax), %eax
    5698:      	cmpq	%rax, %r15
    569b:      	je	0x558d <generic_fentry_process_filter+0x177d>
    56a1:      	movl	0x10(%rsi), %eax
    56a4:      	cmpq	%rax, %r15
    56a7:      	je	0x558d <generic_fentry_process_filter+0x177d>
    56ad:      	addq	$0x10, %rsi
    56b1:      	movl	$0x1, %eax
    56b6:      	movq	(%rip), %rdi            # 0x56bd <generic_fentry_process_filter+0x18ad>
    56bd:      	callq	*%rax
    56bf:      	testq	%rax, %rax
    56c2:      	je	0x5a01 <generic_fentry_process_filter+0x1bf1>
    56c8:      	movq	%rax, %rsi
    56cb:      	movl	(%rax), %eax
    56cd:      	cmpq	%rax, %r15
    56d0:      	je	0x558d <generic_fentry_process_filter+0x177d>
    56d6:      	movl	0x10(%rsi), %eax
    56d9:      	cmpq	%rax, %r15
    56dc:      	je	0x558d <generic_fentry_process_filter+0x177d>
    56e2:      	addq	$0x10, %rsi
    56e6:      	movl	$0x1, %eax
    56eb:      	movq	(%rip), %rdi            # 0x56f2 <generic_fentry_process_filter+0x18e2>
    56f2:      	callq	*%rax
    56f4:      	testq	%rax, %rax
    56f7:      	je	0x5a01 <generic_fentry_process_filter+0x1bf1>
    56fd:      	movq	%rax, %rsi
    5700:      	movl	(%rax), %eax
    5702:      	cmpq	%rax, %r15
    5705:      	je	0x558d <generic_fentry_process_filter+0x177d>
    570b:      	movl	0x10(%rsi), %eax
    570e:      	cmpq	%rax, %r15
    5711:      	je	0x558d <generic_fentry_process_filter+0x177d>
    5717:      	addq	$0x10, %rsi
    571b:      	movl	$0x1, %eax
    5720:      	movq	(%rip), %rdi            # 0x5727 <generic_fentry_process_filter+0x1917>
    5727:      	callq	*%rax
    5729:      	testq	%rax, %rax
    572c:      	je	0x5a01 <generic_fentry_process_filter+0x1bf1>
    5732:      	movq	%rax, %rsi
    5735:      	movl	(%rax), %eax
    5737:      	cmpq	%rax, %r15
    573a:      	je	0x5583 <generic_fentry_process_filter+0x1773>
    5740:      	movl	0x10(%rsi), %eax
    5743:      	cmpq	%rax, %r15
    5746:      	je	0x5583 <generic_fentry_process_filter+0x1773>
    574c:      	addq	$0x10, %rsi
    5750:      	movl	$0x1, %eax
    5755:      	movq	(%rip), %rdi            # 0x575c <generic_fentry_process_filter+0x194c>
    575c:      	callq	*%rax
    575e:      	testq	%rax, %rax
    5761:      	movq	0x30(%rsp), %r12
    5766:      	movq	0x28(%rsp), %r14
    576b:      	je	0x5a01 <generic_fentry_process_filter+0x1bf1>
    5771:      	movq	%rax, %rsi
    5774:      	movl	(%rax), %eax
    5776:      	cmpq	%rax, %r15
    5779:      	je	0x5583 <generic_fentry_process_filter+0x1773>
    577f:      	movl	0x10(%rsi), %eax
    5782:      	cmpq	%rax, %r15
    5785:      	je	0x5583 <generic_fentry_process_filter+0x1773>
    578b:      	addq	$0x10, %rsi
    578f:      	movl	$0x1, %eax
    5794:      	movq	(%rip), %rdi            # 0x579b <generic_fentry_process_filter+0x198b>
    579b:      	callq	*%rax
    579d:      	testq	%rax, %rax
    57a0:      	movq	0x30(%rsp), %r12
    57a5:      	movq	0x28(%rsp), %r14
    57aa:      	je	0x5a01 <generic_fentry_process_filter+0x1bf1>
    57b0:      	movq	%rax, %rsi
    57b3:      	movl	(%rax), %eax
    57b5:      	cmpq	%rax, %r15
    57b8:      	je	0x5583 <generic_fentry_process_filter+0x1773>
    57be:      	movl	0x10(%rsi), %eax
    57c1:      	cmpq	%rax, %r15
    57c4:      	movq	0x30(%rsp), %r12
    57c9:      	movq	0x28(%rsp), %r14
    57ce:      	movq	0x8(%rsp), %r10
    57d3:      	movl	0x4(%rsp), %edi
    57d7:      	movq	0x20(%rsp), %r8
    57dc:      	movq	0x18(%rsp), %r9
    57e1:      	movq	0x10(%rsp), %r11
    57e6:      	je	0x55a5 <generic_fentry_process_filter+0x1795>
    57ec:      	addq	$0x10, %rsi
    57f0:      	movl	$0x1, %eax
    57f5:      	movq	(%rip), %rcx            # 0x57fc <generic_fentry_process_filter+0x19ec>
    57fc:      	jmp	0x59ee <generic_fentry_process_filter+0x1bde>
    5801:      	movl	$0x4, %esi
    5806:      	xorl	%edx, %edx
    5808:      	divq	%rsi
    580b:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5810:      	movl	(%r10,%rax,4), %r15d
    5814:      	testb	$0x2, %r8b
    5818:      	jne	0x55ec <generic_fentry_process_filter+0x17dc>
    581e:      	cmpl	$0x5, %edi
    5821:      	jne	0x582c <generic_fentry_process_filter+0x1a1c>
    5823:      	cmpq	%rcx, %r15
    5826:      	jne	0x5a2a <generic_fentry_process_filter+0x1c1a>
    582c:      	cmpq	%rcx, %r15
    582f:      	setne	%al
    5832:      	cmpl	$0x6, %edi
    5835:      	setne	%r13b
    5839:      	jmp	0x55af <generic_fentry_process_filter+0x179f>
    583e:      	movq	0xe0(%rsp), %rax
    5846:      	movl	(%rax), %eax
    5848:      	testq	%rax, %rax
    584b:      	je	0x5a2a <generic_fentry_process_filter+0x1c1a>
    5851:      	movb	$0x1, %r13b
    5854:      	testq	%r15, %r15
    5857:      	je	0x55a5 <generic_fentry_process_filter+0x1795>
    585d:      	cmpq	%rax, %r15
    5860:      	je	0x55a5 <generic_fentry_process_filter+0x1795>
    5866:      	movl	$0x1, %eax
    586b:      	movq	0xd0(%rsp), %rsi
    5873:      	movq	(%rip), %rdi            # 0x587a <generic_fentry_process_filter+0x1a6a>
    587a:      	callq	*%rax
    587c:      	testq	%rax, %rax
    587f:      	je	0x5a01 <generic_fentry_process_filter+0x1bf1>
    5885:      	movq	%rax, %rsi
    5888:      	movl	0x24(%rax), %eax
    588b:      	cmpq	%rax, %r15
    588e:      	je	0x558d <generic_fentry_process_filter+0x177d>
    5894:      	addq	$0x10, %rsi
    5898:      	movl	$0x1, %eax
    589d:      	movq	(%rip), %rdi            # 0x58a4 <generic_fentry_process_filter+0x1a94>
    58a4:      	callq	*%rax
    58a6:      	testq	%rax, %rax
    58a9:      	je	0x5a01 <generic_fentry_process_filter+0x1bf1>
    58af:      	movq	%rax, %rsi
    58b2:      	movl	0x24(%rax), %eax
    58b5:      	cmpq	%rax, %r15
    58b8:      	je	0x558d <generic_fentry_process_filter+0x177d>
    58be:      	addq	$0x10, %rsi
    58c2:      	movl	$0x1, %eax
    58c7:      	movq	(%rip), %rdi            # 0x58ce <generic_fentry_process_filter+0x1abe>
    58ce:      	callq	*%rax
    58d0:      	testq	%rax, %rax
    58d3:      	je	0x5a01 <generic_fentry_process_filter+0x1bf1>
    58d9:      	movq	%rax, %rsi
    58dc:      	movl	0x24(%rax), %eax
    58df:      	cmpq	%rax, %r15
    58e2:      	je	0x558d <generic_fentry_process_filter+0x177d>
    58e8:      	addq	$0x10, %rsi
    58ec:      	movl	$0x1, %eax
    58f1:      	movq	(%rip), %rdi            # 0x58f8 <generic_fentry_process_filter+0x1ae8>
    58f8:      	callq	*%rax
    58fa:      	testq	%rax, %rax
    58fd:      	je	0x5a01 <generic_fentry_process_filter+0x1bf1>
    5903:      	movq	%rax, %rsi
    5906:      	movl	0x24(%rax), %eax
    5909:      	cmpq	%rax, %r15
    590c:      	je	0x558d <generic_fentry_process_filter+0x177d>
    5912:      	addq	$0x10, %rsi
    5916:      	movl	$0x1, %eax
    591b:      	movq	(%rip), %rdi            # 0x5922 <generic_fentry_process_filter+0x1b12>
    5922:      	callq	*%rax
    5924:      	testq	%rax, %rax
    5927:      	je	0x5a01 <generic_fentry_process_filter+0x1bf1>
    592d:      	movq	%rax, %rsi
    5930:      	movl	0x24(%rax), %eax
    5933:      	cmpq	%rax, %r15
    5936:      	je	0x558d <generic_fentry_process_filter+0x177d>
    593c:      	addq	$0x10, %rsi
    5940:      	movl	$0x1, %eax
    5945:      	movq	(%rip), %rdi            # 0x594c <generic_fentry_process_filter+0x1b3c>
    594c:      	callq	*%rax
    594e:      	testq	%rax, %rax
    5951:      	je	0x5a01 <generic_fentry_process_filter+0x1bf1>
    5957:      	movq	%rax, %rsi
    595a:      	movl	0x24(%rax), %eax
    595d:      	cmpq	%rax, %r15
    5960:      	je	0x5583 <generic_fentry_process_filter+0x1773>
    5966:      	addq	$0x10, %rsi
    596a:      	movl	$0x1, %eax
    596f:      	movq	(%rip), %rdi            # 0x5976 <generic_fentry_process_filter+0x1b66>
    5976:      	callq	*%rax
    5978:      	testq	%rax, %rax
    597b:      	movq	0x30(%rsp), %r12
    5980:      	movq	0x28(%rsp), %r14
    5985:      	je	0x5a01 <generic_fentry_process_filter+0x1bf1>
    5987:      	movq	%rax, %rsi
    598a:      	movl	0x24(%rax), %eax
    598d:      	cmpq	%rax, %r15
    5990:      	je	0x5583 <generic_fentry_process_filter+0x1773>
    5996:      	addq	$0x10, %rsi
    599a:      	movl	$0x1, %eax
    599f:      	movq	(%rip), %rdi            # 0x59a6 <generic_fentry_process_filter+0x1b96>
    59a6:      	callq	*%rax
    59a8:      	testq	%rax, %rax
    59ab:      	movq	0x30(%rsp), %r12
    59b0:      	movq	0x28(%rsp), %r14
    59b5:      	je	0x5a01 <generic_fentry_process_filter+0x1bf1>
    59b7:      	movq	%rax, %rsi
    59ba:      	movl	0x24(%rax), %eax
    59bd:      	cmpq	%rax, %r15
    59c0:      	movq	0x8(%rsp), %r10
    59c5:      	movl	0x4(%rsp), %edi
    59c9:      	movq	0x20(%rsp), %r8
    59ce:      	movq	0x18(%rsp), %r9
    59d3:      	movq	0x10(%rsp), %r11
    59d8:      	je	0x55a5 <generic_fentry_process_filter+0x1795>
    59de:      	addq	$0x10, %rsi
    59e2:      	movl	$0x1, %eax
    59e7:      	movq	(%rip), %rcx            # 0x59ee <generic_fentry_process_filter+0x1bde>
    59ee:      	movq	(%rip), %rdi            # 0x59f5 <generic_fentry_process_filter+0x1be5>
    59f5:      	callq	*%rax
    59f7:      	movq	0x30(%rsp), %r12
    59fc:      	movq	0x28(%rsp), %r14
    5a01:      	xorl	%r13d, %r13d
    5a04:      	movl	0x4(%rsp), %edi
    5a08:      	cmpl	$0x5, %edi
    5a0b:      	movq	0x8(%rsp), %r10
    5a10:      	movq	0x20(%rsp), %r8
    5a15:      	movq	0x18(%rsp), %r9
    5a1a:      	movq	0x10(%rsp), %r11
    5a1f:      	jne	0x55a5 <generic_fentry_process_filter+0x1795>
    5a25:      	jmp	0x55b2 <generic_fentry_process_filter+0x17a2>
    5a2a:      	xorl	%r13d, %r13d
    5a2d:      	jmp	0x55b2 <generic_fentry_process_filter+0x17a2>
    5a32:      	movl	0x50(%rsp), %esi
    5a36:      	movl	0x54(%rsp), %ecx
    5a3a:      	movl	0x58(%rsp), %eax
    5a3e:      	movl	0x5c(%rsp), %edx
    5a42:      	cmpl	$0x6, %edi
    5a45:      	jne	0x5a4f <generic_fentry_process_filter+0x1c3f>
    5a47:      	andl	%esi, %ecx
    5a49:      	andl	%edx, %eax
    5a4b:      	andl	%ecx, %eax
    5a4d:      	jmp	0x5a55 <generic_fentry_process_filter+0x1c45>
    5a4f:      	orl	%esi, %ecx
    5a51:      	orl	%edx, %eax
    5a53:      	orl	%ecx, %eax
    5a55:      	testl	%eax, %eax
    5a57:      	movq	0xd8(%rsp), %rdx
    5a5f:      	je	0x606c <generic_fentry_process_filter+0x225c>
    5a65:      	addl	$0x14, %edx
    5a68:      	movl	0x8(%r10,%rbp), %ecx
    5a6d:      	andl	$0x7, %ecx
    5a70:      	leal	(%rdx,%rcx,4), %ebp
    5a73:      	movl	%ebp, %ecx
    5a75:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5a7b:      	movl	(%rcx,%r10), %ecx
    5a7f:      	addl	$0x4, %ebp
    5a82:      	addl	$-0x4, %ecx
    5a85:      	xorl	%esi, %esi
    5a87:      	movl	$0x4, %r8d
    5a8d:      	jmp	0x5a9f <generic_fentry_process_filter+0x1c8f>
    5a8f:      	nop
    5a90:      	xorl	%ecx, %ecx
    5a92:      	incq	%rsi
    5a95:      	cmpq	$0xa, %rsi
    5a99:      	je	0x5c28 <generic_fentry_process_filter+0x1e18>
    5a9f:      	testl	%ecx, %ecx
    5aa1:      	je	0x5a90 <generic_fentry_process_filter+0x1c80>
    5aa3:      	movl	%ebp, %r9d
    5aa6:      	andl	$0x3ff, %r9d            # imm = 0x3FF
    5aad:      	movl	(%r9,%r10), %r11d
    5ab1:      	movq	%r10, %rax
    5ab4:      	movl	0x4(%r9,%r10), %r10d
    5ab9:      	movl	0x8(%r9,%rax), %edx
    5abe:      	movq	$0x0, 0x58(%rsp)
    5ac7:      	movq	$0x0, 0x50(%rsp)
    5ad0:      	cmpl	$0x4, %edx
    5ad3:      	movl	$0x4, %eax
    5ad8:      	cmovbl	%edx, %eax
    5adb:      	cmpl	$0x6, %r10d
    5adf:      	jne	0x5af5 <generic_fentry_process_filter+0x1ce5>
    5ae1:      	movabsq	$0x100000001, %rdi      # imm = 0x100000001
    5aeb:      	movq	%rdi, 0x50(%rsp)
    5af0:      	movq	%rdi, 0x58(%rsp)
    5af5:      	addl	$0xc, %ebp
    5af8:      	testl	%edx, %edx
    5afa:      	je	0x5bd0 <generic_fentry_process_filter+0x1dc0>
    5b00:      	andl	$0xf, %r11d
    5b04:      	decq	%rax
    5b07:      	cmpq	$0x3, %rax
    5b0b:      	movl	$0x3, %edx
    5b10:      	cmovaeq	%rdx, %rax
    5b14:      	leaq	0x4(,%rax,4), %rbx
    5b1c:      	movl	%ebp, %r14d
    5b1f:      	cmpl	$0x9, %r11d
    5b23:      	jbe	0x5b5a <generic_fentry_process_filter+0x1d4a>
    5b25:      	xorl	%r11d, %r11d
    5b28:      	jmp	0x5b46 <generic_fentry_process_filter+0x1d36>
    5b2a:      	nopw	(%rax,%rax)
    5b30:      	movl	$0x0, 0x50(%rsp,%r11)
    5b39:      	addq	$0x4, %r11
    5b3d:      	cmpq	%r11, %rbx
    5b40:      	je	0x5bd0 <generic_fentry_process_filter+0x1dc0>
    5b46:      	leaq	(%r14,%r11), %rax
    5b4a:      	cmpl	$0x3e8, %eax            # imm = 0x3E8
    5b4f:      	ja	0x5b30 <generic_fentry_process_filter+0x1d20>
    5b51:      	movl	%eax, %eax
    5b53:      	xorl	%edx, %edx
    5b55:      	divq	%r8
    5b58:      	jmp	0x5b30 <generic_fentry_process_filter+0x1d20>
    5b5a:      	xorl	%r15d, %r15d
    5b5d:      	jmp	0x5ba1 <generic_fentry_process_filter+0x1d91>
    5b5f:      	nop
    5b60:      	cmpl	$0x5, %r10d
    5b64:      	setne	%dl
    5b67:      	movl	%r10d, %r13d
    5b6a:      	xorl	$0x6, %r13d
    5b6e:      	movq	0x30(%rsp), %rax
    5b73:      	movl	0x20(%rax,%r11,4), %edi
    5b78:      	movl	%r12d, %eax
    5b7b:      	xorl	%edi, %eax
    5b7d:      	cmpl	%edi, %r12d
    5b80:      	sete	%dil
    5b84:      	orb	%dl, %dil
    5b87:      	orl	%r13d, %eax
    5b8a:      	setne	%al
    5b8d:      	andb	%dil, %al
    5b90:      	movzbl	%al, %eax
    5b93:      	movl	%eax, 0x50(%rsp,%r15)
    5b98:      	addq	$0x4, %r15
    5b9c:      	cmpq	%r15, %rbx
    5b9f:      	je	0x5bd0 <generic_fentry_process_filter+0x1dc0>
    5ba1:      	leaq	(%r14,%r15), %rdx
    5ba5:      	xorl	%r12d, %r12d
    5ba8:      	cmpl	$0x3e8, %edx            # imm = 0x3E8
    5bae:      	ja	0x5b60 <generic_fentry_process_filter+0x1d50>
    5bb0:      	movl	%edx, %eax
    5bb2:      	xorl	%edx, %edx
    5bb4:      	divq	%r8
    5bb7:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5bbc:      	movq	0x8(%rsp), %rdx
    5bc1:      	movl	(%rdx,%rax,4), %r12d
    5bc5:      	jmp	0x5b60 <generic_fentry_process_filter+0x1d50>
    5bc7:      	nopw	(%rax,%rax)
    5bd0:      	movl	0x50(%rsp), %ebx
    5bd4:      	movl	0x54(%rsp), %edx
    5bd8:      	movl	0x58(%rsp), %eax
    5bdc:      	movl	0x5c(%rsp), %r11d
    5be1:      	cmpl	$0x6, %r10d
    5be5:      	jne	0x5bf0 <generic_fentry_process_filter+0x1de0>
    5be7:      	andl	%ebx, %edx
    5be9:      	andl	%r11d, %eax
    5bec:      	andl	%edx, %eax
    5bee:      	jmp	0x5bf7 <generic_fentry_process_filter+0x1de7>
    5bf0:      	orl	%ebx, %edx
    5bf2:      	orl	%r11d, %eax
    5bf5:      	orl	%edx, %eax
    5bf7:      	movq	0x30(%rsp), %r12
    5bfc:      	movq	0x8(%rsp), %r10
    5c01:      	testl	%eax, %eax
    5c03:      	je	0x606c <generic_fentry_process_filter+0x225c>
    5c09:      	movl	0x8(%r10,%r9), %edx
    5c0e:      	shll	$0x2, %edx
    5c11:      	subl	%edx, %ecx
    5c13:      	andl	$0x1c, %edx
    5c16:      	addl	%edx, %ebp
    5c18:      	addl	$-0xc, %ecx
    5c1b:      	incq	%rsi
    5c1e:      	cmpq	$0xa, %rsi
    5c22:      	jne	0x5a9f <generic_fentry_process_filter+0x1c8f>
    5c28:      	movl	%ebp, %ecx
    5c2a:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5c30:      	leal	0x4(%rbp), %ebx
    5c33:      	cmpl	$0x4, (%rcx,%r10)
    5c38:      	je	0x5c93 <generic_fentry_process_filter+0x1e83>
    5c3a:      	andl	$0x3ff, %ebx            # imm = 0x3FF
    5c40:      	movl	(%rbx,%r10), %ecx
    5c44:      	movl	0x4(%rbx,%r10), %edx
    5c49:      	movl	0x8(%rbx,%r10), %edi
    5c4e:      	movq	0xc(%rbx,%r10), %rax
    5c53:      	testl	%edi, %edi
    5c55:      	je	0x5c67 <generic_fentry_process_filter+0x1e57>
    5c57:      	xorl	%esi, %esi
    5c59:      	cmpl	$0x2, %ecx
    5c5c:      	ja	0x5c8a <generic_fentry_process_filter+0x1e7a>
    5c5e:      	cmpl	%edi, 0x44(%r12)
    5c63:      	jne	0x5c70 <generic_fentry_process_filter+0x1e60>
    5c65:      	jmp	0x5c8a <generic_fentry_process_filter+0x1e7a>
    5c67:      	cmpl	$0x2, %ecx
    5c6a:      	jbe	0x5c70 <generic_fentry_process_filter+0x1e60>
    5c6c:      	xorl	%esi, %esi
    5c6e:      	jmp	0x5c8a <generic_fentry_process_filter+0x1e7a>
    5c70:      	andq	0x48(%r12,%rcx,8), %rax
    5c75:      	cmpl	$0x5, %edx
    5c78:      	jne	0x5c83 <generic_fentry_process_filter+0x1e73>
    5c7a:      	testq	%rax, %rax
    5c7d:      	setne	%sil
    5c81:      	jmp	0x5c8a <generic_fentry_process_filter+0x1e7a>
    5c83:      	testq	%rax, %rax
    5c86:      	sete	%sil
    5c8a:      	addl	$0x18, %ebp
    5c8d:      	movzbl	%sil, %eax
    5c91:      	movl	%ebp, %ebx
    5c93:      	testl	%eax, %eax
    5c95:      	je	0x606c <generic_fentry_process_filter+0x225c>
    5c9b:      	movl	%ebx, %ecx
    5c9d:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5ca3:      	leal	0x4(%rbx), %eax
    5ca6:      	cmpl	$0x4, (%rcx,%r10)
    5cab:      	je	0x5f7f <generic_fentry_process_filter+0x216f>
    5cb1:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5cb6:      	movl	(%rax,%r10), %r14d
    5cba:      	movl	0x4(%rax,%r10), %ebp
    5cbf:      	movl	$0xe, %eax
    5cc4:      	callq	*%rax
    5cc6:      	shrq	$0x20, %rax
    5cca:      	movl	%eax, 0x50(%rsp)
    5cce:      	movq	(%rip), %rdi            # 0x5cd5 <generic_fentry_process_filter+0x1ec5>
    5cd5:      	leaq	0x50(%rsp), %rsi
    5cda:      	movl	$0x1, %eax
    5cdf:      	callq	*%rax
    5ce1:      	movq	0x8(%rsp), %r10
    5ce6:      	testq	%rax, %rax
    5ce9:      	je	0x606c <generic_fentry_process_filter+0x225c>
    5cef:      	cmpl	$0x5, %r14d
    5cf3:      	je	0x5d22 <generic_fentry_process_filter+0x1f12>
    5cf5:      	cmpl	$0x6, %r14d
    5cf9:      	jne	0x606c <generic_fentry_process_filter+0x225c>
    5cff:      	movq	%r12, %rcx
    5d02:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    5d09:      	testb	$0x1, %bpl
    5d0d:      	jne	0x5d4c <generic_fentry_process_filter+0x1f3c>
    5d0f:      	movl	0x28(%rax), %edx
    5d12:      	testl	%edx, %edx
    5d14:      	je	0x5d45 <generic_fentry_process_filter+0x1f35>
    5d16:      	cmpl	0x20(%r12), %edx
    5d1b:      	je	0x5d4c <generic_fentry_process_filter+0x1f3c>
    5d1d:      	jmp	0x5f73 <generic_fentry_process_filter+0x2163>
    5d22:      	movq	%r12, %rcx
    5d25:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    5d2c:      	testb	$0x1, %bpl
    5d30:      	je	0x5d6c <generic_fentry_process_filter+0x1f5c>
    5d32:      	movl	0x28(%rax), %edx
    5d35:      	testl	%edx, %edx
    5d37:      	je	0x5d65 <generic_fentry_process_filter+0x1f55>
    5d39:      	cmpl	0x20(%r12), %edx
    5d3e:      	je	0x5d6c <generic_fentry_process_filter+0x1f5c>
    5d40:      	jmp	0x5f73 <generic_fentry_process_filter+0x2163>
    5d45:      	movq	$0x1, (%rcx)
    5d4c:      	testb	$0x2, %bpl
    5d50:      	jne	0x5d8c <generic_fentry_process_filter+0x1f7c>
    5d52:      	movl	0x2c(%rax), %edx
    5d55:      	testl	%edx, %edx
    5d57:      	je	0x5d85 <generic_fentry_process_filter+0x1f75>
    5d59:      	cmpl	0x24(%r12), %edx
    5d5e:      	je	0x5d8c <generic_fentry_process_filter+0x1f7c>
    5d60:      	jmp	0x5f73 <generic_fentry_process_filter+0x2163>
    5d65:      	movq	$0x1, (%rcx)
    5d6c:      	testb	$0x2, %bpl
    5d70:      	je	0x5dac <generic_fentry_process_filter+0x1f9c>
    5d72:      	movl	0x2c(%rax), %edx
    5d75:      	testl	%edx, %edx
    5d77:      	je	0x5da5 <generic_fentry_process_filter+0x1f95>
    5d79:      	cmpl	0x24(%r12), %edx
    5d7e:      	je	0x5dac <generic_fentry_process_filter+0x1f9c>
    5d80:      	jmp	0x5f73 <generic_fentry_process_filter+0x2163>
    5d85:      	movq	$0x1, (%rcx)
    5d8c:      	testb	$0x4, %bpl
    5d90:      	jne	0x5dcc <generic_fentry_process_filter+0x1fbc>
    5d92:      	movl	0x30(%rax), %edx
    5d95:      	testl	%edx, %edx
    5d97:      	je	0x5dc5 <generic_fentry_process_filter+0x1fb5>
    5d99:      	cmpl	0x28(%r12), %edx
    5d9e:      	je	0x5dcc <generic_fentry_process_filter+0x1fbc>
    5da0:      	jmp	0x5f73 <generic_fentry_process_filter+0x2163>
    5da5:      	movq	$0x1, (%rcx)
    5dac:      	testb	$0x4, %bpl
    5db0:      	je	0x5dec <generic_fentry_process_filter+0x1fdc>
    5db2:      	movl	0x30(%rax), %edx
    5db5:      	testl	%edx, %edx
    5db7:      	je	0x5de5 <generic_fentry_process_filter+0x1fd5>
    5db9:      	cmpl	0x28(%r12), %edx
    5dbe:      	je	0x5dec <generic_fentry_process_filter+0x1fdc>
    5dc0:      	jmp	0x5f73 <generic_fentry_process_filter+0x2163>
    5dc5:      	movq	$0x1, (%rcx)
    5dcc:      	testb	$0x8, %bpl
    5dd0:      	jne	0x5e0c <generic_fentry_process_filter+0x1ffc>
    5dd2:      	movl	0x34(%rax), %edx
    5dd5:      	testl	%edx, %edx
    5dd7:      	je	0x5e05 <generic_fentry_process_filter+0x1ff5>
    5dd9:      	cmpl	0x2c(%r12), %edx
    5dde:      	je	0x5e0c <generic_fentry_process_filter+0x1ffc>
    5de0:      	jmp	0x5f73 <generic_fentry_process_filter+0x2163>
    5de5:      	movq	$0x1, (%rcx)
    5dec:      	testb	$0x8, %bpl
    5df0:      	je	0x5e2c <generic_fentry_process_filter+0x201c>
    5df2:      	movl	0x34(%rax), %edx
    5df5:      	testl	%edx, %edx
    5df7:      	je	0x5e25 <generic_fentry_process_filter+0x2015>
    5df9:      	cmpl	0x2c(%r12), %edx
    5dfe:      	je	0x5e2c <generic_fentry_process_filter+0x201c>
    5e00:      	jmp	0x5f73 <generic_fentry_process_filter+0x2163>
    5e05:      	movq	$0x1, (%rcx)
    5e0c:      	testb	$0x10, %bpl
    5e10:      	jne	0x5e4c <generic_fentry_process_filter+0x203c>
    5e12:      	movl	0x38(%rax), %edx
    5e15:      	testl	%edx, %edx
    5e17:      	je	0x5e45 <generic_fentry_process_filter+0x2035>
    5e19:      	cmpl	0x30(%r12), %edx
    5e1e:      	je	0x5e4c <generic_fentry_process_filter+0x203c>
    5e20:      	jmp	0x5f73 <generic_fentry_process_filter+0x2163>
    5e25:      	movq	$0x1, (%rcx)
    5e2c:      	testb	$0x10, %bpl
    5e30:      	je	0x5e6c <generic_fentry_process_filter+0x205c>
    5e32:      	movl	0x38(%rax), %edx
    5e35:      	testl	%edx, %edx
    5e37:      	je	0x5e65 <generic_fentry_process_filter+0x2055>
    5e39:      	cmpl	0x30(%r12), %edx
    5e3e:      	je	0x5e6c <generic_fentry_process_filter+0x205c>
    5e40:      	jmp	0x5f73 <generic_fentry_process_filter+0x2163>
    5e45:      	movq	$0x1, (%rcx)
    5e4c:      	testb	$0x20, %bpl
    5e50:      	jne	0x5e8c <generic_fentry_process_filter+0x207c>
    5e52:      	movl	0x3c(%rax), %edx
    5e55:      	testl	%edx, %edx
    5e57:      	je	0x5e85 <generic_fentry_process_filter+0x2075>
    5e59:      	cmpl	0x34(%r12), %edx
    5e5e:      	je	0x5e8c <generic_fentry_process_filter+0x207c>
    5e60:      	jmp	0x5f73 <generic_fentry_process_filter+0x2163>
    5e65:      	movq	$0x1, (%rcx)
    5e6c:      	testb	$0x20, %bpl
    5e70:      	je	0x5eac <generic_fentry_process_filter+0x209c>
    5e72:      	movl	0x3c(%rax), %edx
    5e75:      	testl	%edx, %edx
    5e77:      	je	0x5ea5 <generic_fentry_process_filter+0x2095>
    5e79:      	cmpl	0x34(%r12), %edx
    5e7e:      	je	0x5eac <generic_fentry_process_filter+0x209c>
    5e80:      	jmp	0x5f73 <generic_fentry_process_filter+0x2163>
    5e85:      	movq	$0x1, (%rcx)
    5e8c:      	testb	$0x40, %bpl
    5e90:      	jne	0x5ecc <generic_fentry_process_filter+0x20bc>
    5e92:      	movl	0x40(%rax), %edx
    5e95:      	testl	%edx, %edx
    5e97:      	je	0x5ec5 <generic_fentry_process_filter+0x20b5>
    5e99:      	cmpl	0x38(%r12), %edx
    5e9e:      	je	0x5ecc <generic_fentry_process_filter+0x20bc>
    5ea0:      	jmp	0x5f73 <generic_fentry_process_filter+0x2163>
    5ea5:      	movq	$0x1, (%rcx)
    5eac:      	testb	$0x40, %bpl
    5eb0:      	je	0x5eeb <generic_fentry_process_filter+0x20db>
    5eb2:      	movl	0x40(%rax), %edx
    5eb5:      	testl	%edx, %edx
    5eb7:      	je	0x5ee4 <generic_fentry_process_filter+0x20d4>
    5eb9:      	cmpl	0x38(%r12), %edx
    5ebe:      	je	0x5eeb <generic_fentry_process_filter+0x20db>
    5ec0:      	jmp	0x5f73 <generic_fentry_process_filter+0x2163>
    5ec5:      	movq	$0x1, (%rcx)
    5ecc:      	testb	%bpl, %bpl
    5ecf:      	js	0x5f07 <generic_fentry_process_filter+0x20f7>
    5ed1:      	movl	0x44(%rax), %edx
    5ed4:      	testl	%edx, %edx
    5ed6:      	je	0x5f00 <generic_fentry_process_filter+0x20f0>
    5ed8:      	cmpl	0x3c(%r12), %edx
    5edd:      	je	0x5f07 <generic_fentry_process_filter+0x20f7>
    5edf:      	jmp	0x5f73 <generic_fentry_process_filter+0x2163>
    5ee4:      	movq	$0x1, (%rcx)
    5eeb:      	testb	%bpl, %bpl
    5eee:      	jns	0x5f26 <generic_fentry_process_filter+0x2116>
    5ef0:      	movl	0x44(%rax), %edx
    5ef3:      	testl	%edx, %edx
    5ef5:      	je	0x5f1f <generic_fentry_process_filter+0x210f>
    5ef7:      	cmpl	0x3c(%r12), %edx
    5efc:      	je	0x5f26 <generic_fentry_process_filter+0x2116>
    5efe:      	jmp	0x5f73 <generic_fentry_process_filter+0x2163>
    5f00:      	movq	$0x1, (%rcx)
    5f07:      	testl	$0x100, %ebp            # imm = 0x100
    5f0d:      	jne	0x5f51 <generic_fentry_process_filter+0x2141>
    5f0f:      	movl	0x48(%rax), %edx
    5f12:      	testl	%edx, %edx
    5f14:      	je	0x5f4a <generic_fentry_process_filter+0x213a>
    5f16:      	cmpl	0x40(%r12), %edx
    5f1b:      	je	0x5f51 <generic_fentry_process_filter+0x2141>
    5f1d:      	jmp	0x5f73 <generic_fentry_process_filter+0x2163>
    5f1f:      	movq	$0x1, (%rcx)
    5f26:      	testl	$0x100, %ebp            # imm = 0x100
    5f2c:      	je	0x6052 <generic_fentry_process_filter+0x2242>
    5f32:      	movl	0x48(%rax), %edx
    5f35:      	testl	%edx, %edx
    5f37:      	je	0x604b <generic_fentry_process_filter+0x223b>
    5f3d:      	cmpl	0x40(%r12), %edx
    5f42:      	je	0x6052 <generic_fentry_process_filter+0x2242>
    5f48:      	jmp	0x5f73 <generic_fentry_process_filter+0x2163>
    5f4a:      	movq	$0x1, (%rcx)
    5f51:      	testl	$0x200, %ebp            # imm = 0x200
    5f57:      	jne	0x606c <generic_fentry_process_filter+0x225c>
    5f5d:      	movl	0x4c(%rax), %eax
    5f60:      	testl	%eax, %eax
    5f62:      	je	0x6065 <generic_fentry_process_filter+0x2255>
    5f68:      	cmpl	0x44(%r12), %eax
    5f6d:      	je	0x606c <generic_fentry_process_filter+0x225c>
    5f73:      	addl	$0xc, %ebx
    5f76:      	movq	$0x1, (%rcx)
    5f7d:      	movl	%ebx, %eax
    5f7f:      	movl	%eax, %ecx
    5f81:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5f87:      	cmpl	$0x4, (%rcx,%r10)
    5f8c:      	jne	0x5fb9 <generic_fentry_process_filter+0x21a9>
    5f8e:      	movq	0x5eb8(%r12), %rax
    5f96:      	andl	$0x1f, %eax
    5f99:      	movb	$0x1, 0x5ec1(%r12,%rax)
    5fa2:      	movb	$0x1, 0x5ee0(%r12)
    5fab:      	movb	$0x1, 0x5ec0(%r12)
    5fb4:      	jmp	0x606c <generic_fentry_process_filter+0x225c>
    5fb9:      	addl	$0x4, %eax
    5fbc:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5fc1:      	movl	(%rax,%r10), %r14d
    5fc5:      	movl	0x4(%rax,%r10), %ebx
    5fca:      	movl	0x8(%rax,%r10), %ebp
    5fcf:      	movq	0xc(%rax,%r10), %r15
    5fd4:      	movl	$0xe, %eax
    5fd9:      	callq	*%rax
    5fdb:      	shrq	$0x20, %rax
    5fdf:      	movl	%eax, 0x50(%rsp)
    5fe3:      	movq	(%rip), %rdi            # 0x5fea <generic_fentry_process_filter+0x21da>
    5fea:      	leaq	0x50(%rsp), %rsi
    5fef:      	movl	$0x1, %eax
    5ff4:      	callq	*%rax
    5ff6:      	testq	%rax, %rax
    5ff9:      	je	0x606c <generic_fentry_process_filter+0x225c>
    5ffb:      	testl	%ebp, %ebp
    5ffd:      	je	0x600e <generic_fentry_process_filter+0x21fe>
    5fff:      	cmpl	$0x2, %r14d
    6003:      	ja	0x606c <generic_fentry_process_filter+0x225c>
    6005:      	cmpl	%ebp, 0x44(%r12)
    600a:      	jne	0x6014 <generic_fentry_process_filter+0x2204>
    600c:      	jmp	0x606c <generic_fentry_process_filter+0x225c>
    600e:      	cmpl	$0x2, %r14d
    6012:      	ja	0x606c <generic_fentry_process_filter+0x225c>
    6014:      	movq	0x50(%rax,%r14,8), %rax
    6019:      	movq	0x48(%r12,%r14,8), %rcx
    601e:      	movq	%rcx, %rdx
    6021:      	xorq	%rax, %rdx
    6024:      	testq	%r15, %rdx
    6027:      	je	0x6030 <generic_fentry_process_filter+0x2220>
    6029:      	cmpl	$0x5, %ebx
    602c:      	jne	0x606c <generic_fentry_process_filter+0x225c>
    602e:      	jmp	0x603a <generic_fentry_process_filter+0x222a>
    6030:      	cmpq	%rcx, %rax
    6033:      	je	0x606c <generic_fentry_process_filter+0x225c>
    6035:      	cmpl	$0x6, %ebx
    6038:      	jne	0x606c <generic_fentry_process_filter+0x225c>
    603a:      	movq	$0x1, 0x5ef0(%r12)
    6046:      	jmp	0x5f8e <generic_fentry_process_filter+0x217e>
    604b:      	movq	$0x1, (%rcx)
    6052:      	testl	$0x200, %ebp            # imm = 0x200
    6058:      	je	0x606c <generic_fentry_process_filter+0x225c>
    605a:      	movl	0x4c(%rax), %eax
    605d:      	testl	%eax, %eax
    605f:      	jne	0x5f68 <generic_fentry_process_filter+0x2158>
    6065:      	movq	$0x1, (%rcx)
    606c:      	movq	0x5eb8(%r12), %rax
    6074:      	incq	%rax
    6077:      	movq	%rax, 0x5eb8(%r12)
    607f:      	cmpq	0xb8(%rsp), %rax
    6087:      	jbe	0x60da <generic_fentry_process_filter+0x22ca>
    6089:      	movq	0x28(%rsp), %rcx
    608e:      	movl	(%rcx), %eax
    6090:      	movl	%eax, 0x10(%r12)
    6095:      	movq	0x8(%rcx), %rax
    6099:      	movq	%rax, 0x18(%r12)
    609e:      	cmpb	$0x0, 0x5ec0(%r12)
    60a7:      	movq	0xb0(%rsp), %rbp
    60af:      	je	0x60c6 <generic_fentry_process_filter+0x22b6>
    60b1:      	movq	(%rip), %rsi            # 0x60b8 <generic_fentry_process_filter+0x22a8>
    60b8:      	xorl	%ecx, %ecx
    60ba:      	movl	$0xc, %eax
    60bf:      	movq	%rbp, %rdi
    60c2:      	xorl	%edx, %edx
    60c4:      	callq	*%rax
    60c6:      	xorl	%eax, %eax
    60c8:      	addq	$0xf8, %rsp
    60cf:      	popq	%rbx
    60d0:      	popq	%r12
    60d2:      	popq	%r13
    60d4:      	popq	%r14
    60d6:      	popq	%r15
    60d8:      	popq	%rbp
    60d9:      	retq
    60da:      	movq	(%rip), %rsi            # 0x60e1 <generic_fentry_process_filter+0x22d1>
    60e1:      	movl	$0x2, %ecx
    60e6:      	movl	$0xc, %eax
    60eb:      	movq	0xb0(%rsp), %rdi
    60f3:      	movl	$0x2, %edx
    60f8:      	jmp	0x60c4 <generic_fentry_process_filter+0x22b4>
    60fa:      	nopw	(%rax,%rax)

0000000000006100 <generic_fentry_filter_arg>:
    6100:      	pushq	%rbp
    6101:      	pushq	%r15
    6103:      	pushq	%r14
    6105:      	pushq	%r13
    6107:      	pushq	%r12
    6109:      	pushq	%rbx
    610a:      	subq	$0xc8, %rsp
    6111:      	movq	%rdi, %r13
    6114:      	movl	$0x0, 0xb4(%rsp)
    611f:      	movq	(%rip), %rdi            # 0x6126 <generic_fentry_filter_arg+0x26>
    6126:      	leaq	0xb4(%rsp), %rsi
    612e:      	movl	$0x1, %eax
    6133:      	callq	*%rax
    6135:      	testq	%rax, %rax
    6138:      	je	0x62d3 <generic_fentry_filter_arg+0x1d3>
    613e:      	movq	%rax, %r14
    6141:      	movl	0x5f00(%rax), %ebx
    6147:      	leaq	0x5ef8(%rax), %rsi
    614e:      	movq	(%rip), %rdi            # 0x6155 <generic_fentry_filter_arg+0x55>
    6155:      	movl	$0x1, %eax
    615a:      	callq	*%rax
    615c:      	testq	%rax, %rax
    615f:      	je	0x62b8 <generic_fentry_filter_arg+0x1b8>
    6165:      	cmpb	$0x0, 0x5ee0(%r14)
    616d:      	je	0x62b8 <generic_fentry_filter_arg+0x1b8>
    6173:      	movq	%rax, %r15
    6176:      	movl	%ebx, %eax
    6178:      	andl	$0x7, %eax
    617b:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
    6184:      	je	0x620d <generic_fentry_filter_arg+0x10d>
    618a:      	movl	%eax, %eax
    618c:      	movl	0x4(%r15,%rax,4), %ecx
    6191:      	leaq	(%rcx,%rax,4), %rdx
    6195:      	addq	$0x4, %rdx
    6199:      	leaq	(%rcx,%rax,4), %rax
    619d:      	addq	$0x8, %rax
    61a1:      	andl	$0x3ff, %eax            # imm = 0x3FF
    61a6:      	movl	(%rax,%r15), %eax
    61aa:      	addq	%rdx, %rax
    61ad:      	addq	$0x4, %rax
    61b1:      	movl	%eax, %ecx
    61b3:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    61b9:      	movl	(%rcx,%r15), %ecx
    61bd:      	addq	%rax, %rcx
    61c0:      	movl	%ecx, %eax
    61c2:      	andl	$0x3ff, %eax            # imm = 0x3FF
    61c7:      	movl	(%rax,%r15), %eax
    61cb:      	addq	%rcx, %rax
    61ce:      	movl	%eax, %ecx
    61d0:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    61d6:      	movl	(%rcx,%r15), %ecx
    61da:      	addq	%rax, %rcx
    61dd:      	movl	%ecx, %eax
    61df:      	andl	$0x3ff, %eax            # imm = 0x3FF
    61e4:      	movl	(%rax,%r15), %r9d
    61e8:      	addq	%rcx, %r9
    61eb:      	movl	%r9d, %edi
    61ee:      	andl	$0x3ff, %edi            # imm = 0x3FF
    61f4:      	cmpl	$0x19, (%r15,%rdi)
    61f9:      	jae	0x6259 <generic_fentry_filter_arg+0x159>
    61fb:      	cmpq	$0x1, %rdi
    61ff:      	je	0x62b8 <generic_fentry_filter_arg+0x1b8>
    6205:      	testl	%edi, %edi
    6207:      	jne	0x6296 <generic_fentry_filter_arg+0x196>
    620d:      	cmpl	$0x1, %ebx
    6210:      	jg	0x622e <generic_fentry_filter_arg+0x12e>
    6212:      	cmpl	$-0x1, %ebx
    6215:      	je	0x62e7 <generic_fentry_filter_arg+0x1e7>
    621b:      	testl	%ebx, %ebx
    621d:      	je	0x62f3 <generic_fentry_filter_arg+0x1f3>
    6223:      	cmpl	$0x1, %ebx
    6226:      	je	0x6302 <generic_fentry_filter_arg+0x202>
    622c:      	jmp	0x6249 <generic_fentry_filter_arg+0x149>
    622e:      	cmpl	$0x2, %ebx
    6231:      	je	0x6311 <generic_fentry_filter_arg+0x211>
    6237:      	cmpl	$0x3, %ebx
    623a:      	je	0x6320 <generic_fentry_filter_arg+0x220>
    6240:      	cmpl	$0x4, %ebx
    6243:      	je	0x632f <generic_fentry_filter_arg+0x22f>
    6249:      	cmpl	$0x4, %ebx
    624c:      	jg	0x6360 <generic_fentry_filter_arg+0x260>
    6252:      	incl	%ebx
    6254:      	jmp	0x633e <generic_fentry_filter_arg+0x23e>
    6259:      	leaq	(%r15,%rdi), %rax
    625d:      	movq	%rax, 0xc0(%rsp)
    6265:      	xorl	%r11d, %r11d
    6268:      	leaq	0x80(%rsp), %rax
    6270:      	movq	%rax, 0x38(%rsp)
    6275:      	movq	%rbx, 0xb8(%rsp)
    627d:      	movq	%rdi, 0x10(%rsp)
    6282:      	movq	%r9, 0x18(%rsp)
    6287:      	movq	%r15, 0x68(%rsp)
    628c:      	movq	%r13, 0x78(%rsp)
    6291:      	jmp	0x63d5 <generic_fentry_filter_arg+0x2d5>
    6296:      	movl	%edi, 0x5f04(%r14)
    629d:      	movq	(%rip), %rsi            # 0x62a4 <generic_fentry_filter_arg+0x1a4>
    62a4:      	movl	$0x4, %ecx
    62a9:      	movl	$0xc, %eax
    62ae:      	movq	%r13, %rdi
    62b1:      	movl	$0x4, %edx
    62b6:      	callq	*%rax
    62b8:      	movq	(%rip), %rsi            # 0x62bf <generic_fentry_filter_arg+0x1bf>
    62bf:      	movl	$0x5, %ecx
    62c4:      	movl	$0xc, %eax
    62c9:      	movq	%r13, %rdi
    62cc:      	movl	$0x5, %edx
    62d1:      	callq	*%rax
    62d3:      	xorl	%eax, %eax
    62d5:      	addq	$0xc8, %rsp
    62dc:      	popq	%rbx
    62dd:      	popq	%r12
    62df:      	popq	%r13
    62e1:      	popq	%r14
    62e3:      	popq	%r15
    62e5:      	popq	%rbp
    62e6:      	retq
    62e7:      	xorl	%ebx, %ebx
    62e9:      	cmpb	$0x0, 0x5ec1(%r14)
    62f1:      	jne	0x633e <generic_fentry_filter_arg+0x23e>
    62f3:      	movl	$0x1, %ebx
    62f8:      	cmpb	$0x0, 0x5ec2(%r14)
    6300:      	jne	0x633e <generic_fentry_filter_arg+0x23e>
    6302:      	movl	$0x2, %ebx
    6307:      	cmpb	$0x0, 0x5ec3(%r14)
    630f:      	jne	0x633e <generic_fentry_filter_arg+0x23e>
    6311:      	movl	$0x3, %ebx
    6316:      	cmpb	$0x0, 0x5ec4(%r14)
    631e:      	jne	0x633e <generic_fentry_filter_arg+0x23e>
    6320:      	movl	$0x4, %ebx
    6325:      	cmpb	$0x0, 0x5ec5(%r14)
    632d:      	jne	0x633e <generic_fentry_filter_arg+0x23e>
    632f:      	movl	$0x5, %ebx
    6334:      	cmpb	$0x0, 0x5ec6(%r14)
    633c:      	je	0x6360 <generic_fentry_filter_arg+0x260>
    633e:      	movl	%ebx, 0x5f00(%r14)
    6345:      	movq	(%rip), %rsi            # 0x634c <generic_fentry_filter_arg+0x24c>
    634c:      	movl	$0x3, %ecx
    6351:      	movl	$0xc, %eax
    6356:      	movq	%r13, %rdi
    6359:      	movl	$0x3, %edx
    635e:      	callq	*%rax
    6360:      	movq	0x60(%r14), %rbx
    6364:      	movl	$0xe, %eax
    6369:      	callq	*%rax
    636b:      	movq	%rbx, 0x40(%rsp)
    6370:      	movq	%rax, 0x48(%rsp)
    6375:      	movq	(%rip), %rdi            # 0x637c <generic_fentry_filter_arg+0x27c>
    637c:      	leaq	0x40(%rsp), %rsi
    6381:      	movl	$0x1, %eax
    6386:      	callq	*%rax
    6388:      	testq	%rax, %rax
    638b:      	je	0x62d3 <generic_fentry_filter_arg+0x1d3>
    6391:      	movq	(%rip), %rdi            # 0x6398 <generic_fentry_filter_arg+0x298>
    6398:      	leaq	0x40(%rsp), %rsi
    639d:      	movl	$0x3, %eax
    63a2:      	callq	*%rax
    63a4:      	jmp	0x62d3 <generic_fentry_filter_arg+0x1d3>
    63a9:      	testq	%rax, %rax
    63ac:      	setne	%cl
    63af:      	movzbl	%cl, %ebx
    63b2:      	movq	0x78(%rsp), %r13
    63b7:      	testq	%rbx, %rbx
    63ba:      	movq	0xb8(%rsp), %rbx
    63c2:      	je	0x620d <generic_fentry_filter_arg+0x10d>
    63c8:      	incq	%r11
    63cb:      	cmpq	$0x5, %r11
    63cf:      	je	0x61fb <generic_fentry_filter_arg+0xfb>
    63d5:      	movq	0xc0(%rsp), %rax
    63dd:      	movl	0x4(%rax,%r11,4), %r12d
    63e2:      	testl	$0x3ff, %r12d           # imm = 0x3FF
    63e9:      	je	0x61fb <generic_fentry_filter_arg+0xfb>
    63ef:      	addl	%r9d, %r12d
    63f2:      	andl	$0x3ff, %r12d           # imm = 0x3FF
    63f9:      	movl	0x4(%r15,%r12), %eax
    63fe:      	cmpl	$0x23, %eax
    6401:      	je	0x620d <generic_fentry_filter_arg+0x10d>
    6407:      	addq	%r15, %r12
    640a:      	movl	(%r12), %ecx
    640e:      	cmpq	$0x4, %rcx
    6412:      	ja	0x620d <generic_fentry_filter_arg+0x10d>
    6418:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    6421:      	jne	0x620d <generic_fentry_filter_arg+0x10d>
    6427:      	movq	0x5e78(%r14,%rcx,8), %rcx
    642f:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    6435:      	leaq	(%r14,%rcx), %rsi
    6439:      	addq	$0x90, %rsi
    6440:      	movl	0xc(%r12), %ecx
    6445:      	cmpl	$0x10, %ecx
    6448:      	jle	0x64a4 <generic_fentry_filter_arg+0x3a4>
    644a:      	leal	-0x1c(%rcx), %edx
    644d:      	cmpl	$0x9, %edx
    6450:      	jb	0x65ce <generic_fentry_filter_arg+0x4ce>
    6456:      	movq	%rsi, %r8
    6459:      	cmpl	$0x2a, %ecx
    645c:      	ja	0x68f3 <generic_fentry_filter_arg+0x7f3>
    6462:      	movl	%ecx, %edx
    6464:      	movabsq	$0xc000000000, %rsi     # imm = 0xC000000000
    646e:      	btq	%rdx, %rsi
    6472:      	jb	0x64cc <generic_fentry_filter_arg+0x3cc>
    6474:      	movabsq	$0x30000000000, %rsi    # imm = 0x30000000000
    647e:      	btq	%rdx, %rsi
    6482:      	jb	0x652b <generic_fentry_filter_arg+0x42b>
    6488:      	movabsq	$0x42000000000, %rsi    # imm = 0x42000000000
    6492:      	btq	%rdx, %rsi
    6496:      	jae	0x68f3 <generic_fentry_filter_arg+0x7f3>
    649c:      	movq	%r8, %rsi
    649f:      	jmp	0x6903 <generic_fentry_filter_arg+0x803>
    64a4:      	cmpl	$0x6, %ecx
    64a7:      	jg	0x6507 <generic_fentry_filter_arg+0x407>
    64a9:      	cmpl	$0x3, %ecx
    64ac:      	jle	0x6583 <generic_fentry_filter_arg+0x483>
    64b2:      	cmpl	$0x4, %ecx
    64b5:      	je	0x65ce <generic_fentry_filter_arg+0x4ce>
    64bb:      	movq	%rsi, %r8
    64be:      	cmpl	$0x5, %ecx
    64c1:      	je	0x652b <generic_fentry_filter_arg+0x42b>
    64c3:      	cmpl	$0x6, %ecx
    64c6:      	jne	0x63c8 <generic_fentry_filter_arg+0x2c8>
    64cc:      	movq	%r8, %rsi
    64cf:      	movl	(%r8), %ebp
    64d2:      	addq	$0x4, %rsi
    64d6:      	cmpl	$0x19, %eax
    64d9:      	jg	0x6787 <generic_fentry_filter_arg+0x687>
    64df:      	leal	-0x3(%rax), %ecx
    64e2:      	cmpl	$0x2, %ecx
    64e5:      	jb	0x70e0 <generic_fentry_filter_arg+0xfe0>
    64eb:      	cmpl	$0x8, %eax
    64ee:      	je	0x7037 <generic_fentry_filter_arg+0xf37>
    64f4:      	movl	$0x0, %ebx
    64f9:      	cmpl	$0x9, %eax
    64fc:      	je	0x67a7 <generic_fentry_filter_arg+0x6a7>
    6502:      	jmp	0x90c7 <generic_fentry_filter_arg+0x2fc7>
    6507:      	leal	-0xa(%rcx), %edx
    650a:      	cmpl	$0x4, %edx
    650d:      	jb	0x65ce <generic_fentry_filter_arg+0x4ce>
    6513:      	leal	-0xf(%rcx), %edx
    6516:      	cmpl	$0x2, %edx
    6519:      	jb	0x6903 <generic_fentry_filter_arg+0x803>
    651f:      	movq	%rsi, %r8
    6522:      	cmpl	$0x7, %ecx
    6525:      	jne	0x63c8 <generic_fentry_filter_arg+0x2c8>
    652b:      	movq	$0x0, 0x60(%rsp)
    6534:      	movq	$0x0, 0x58(%rsp)
    653d:      	movq	$0x0, 0x50(%rsp)
    6546:      	movq	$0x0, 0x48(%rsp)
    654f:      	movq	$0x0, 0x40(%rsp)
    6558:      	cmpl	$0x27, %ecx
    655b:      	jg	0x66fc <generic_fentry_filter_arg+0x5fc>
    6561:      	cmpl	$0x5, %ecx
    6564:      	movq	%r8, %rsi
    6567:      	je	0x6e84 <generic_fentry_filter_arg+0xd84>
    656d:      	movq	%rsi, %rdx
    6570:      	movl	$0x0, %ebx
    6575:      	cmpl	$0x7, %ecx
    6578:      	je	0x6e86 <generic_fentry_filter_arg+0xd86>
    657e:      	jmp	0x63b2 <generic_fentry_filter_arg+0x2b2>
    6583:      	cmpl	$0x1, %ecx
    6586:      	je	0x65ce <generic_fentry_filter_arg+0x4ce>
    6588:      	cmpl	$0x2, %ecx
    658b:      	jne	0x63c8 <generic_fentry_filter_arg+0x2c8>
    6591:      	movl	0x4(%rsi), %ebp
    6594:      	addq	$0x8, %rsi
    6598:      	cmpl	$0x19, %eax
    659b:      	jg	0x7164 <generic_fentry_filter_arg+0x1064>
    65a1:      	leal	-0x3(%rax), %ecx
    65a4:      	cmpl	$0x2, %ecx
    65a7:      	jb	0x79ec <generic_fentry_filter_arg+0x18ec>
    65ad:      	movq	%rsi, 0x8(%rsp)
    65b2:      	cmpl	$0x8, %eax
    65b5:      	je	0x794c <generic_fentry_filter_arg+0x184c>
    65bb:      	movl	$0x0, %ebx
    65c0:      	cmpl	$0x9, %eax
    65c3:      	je	0x7189 <generic_fentry_filter_arg+0x1089>
    65c9:      	jmp	0x9395 <generic_fentry_filter_arg+0x3295>
    65ce:      	movq	%rsi, 0x8(%rsp)
    65d3:      	cmpl	$0xb, %ecx
    65d6:      	jle	0x6667 <generic_fentry_filter_arg+0x567>
    65dc:      	cmpl	$0x24, %ecx
    65df:      	ja	0x66ae <generic_fentry_filter_arg+0x5ae>
    65e5:      	movl	%ecx, %edx
    65e7:      	movabsq	$0x1e00000000, %rsi     # imm = 0x1E00000000
    65f1:      	btq	%rdx, %rsi
    65f5:      	jb	0x6682 <generic_fentry_filter_arg+0x582>
    65fb:      	movl	$0x60000000, %esi       # imm = 0x60000000
    6600:      	btq	%rdx, %rsi
    6604:      	jb	0x6a59 <generic_fentry_filter_arg+0x959>
    660a:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    6614:      	btq	%rdx, %rsi
    6618:      	jae	0x66ae <generic_fentry_filter_arg+0x5ae>
    661e:      	cmpl	$0x20, %eax
    6621:      	ja	0x620d <generic_fentry_filter_arg+0x10d>
    6627:      	movl	%eax, %ecx
    6629:      	movl	$0x101e, %edx           # imm = 0x101E
    662e:      	btq	%rcx, %rdx
    6632:      	jae	0x72df <generic_fentry_filter_arg+0x11df>
    6638:      	movl	0x10(%r12), %ecx
    663d:      	cmpl	$0x2, %eax
    6640:      	jle	0x77ec <generic_fentry_filter_arg+0x16ec>
    6646:      	leal	-0x3(%rax), %edx
    6649:      	cmpl	$0x2, %edx
    664c:      	movq	0x8(%rsp), %rdx
    6651:      	jae	0x7e1f <generic_fentry_filter_arg+0x1d1f>
    6657:      	movzbl	(%rdx), %edx
    665a:      	cmpl	%edx, %ecx
    665c:      	jne	0x813d <generic_fentry_filter_arg+0x203d>
    6662:      	jmp	0x9321 <generic_fentry_filter_arg+0x3221>
    6667:      	leal	-0xa(%rcx), %edx
    666a:      	cmpl	$0x2, %edx
    666d:      	jb	0x6af3 <generic_fentry_filter_arg+0x9f3>
    6673:      	cmpl	$0x1, %ecx
    6676:      	je	0x66ba <generic_fentry_filter_arg+0x5ba>
    6678:      	cmpl	$0x4, %ecx
    667b:      	je	0x66ba <generic_fentry_filter_arg+0x5ba>
    667d:      	jmp	0x63c8 <generic_fentry_filter_arg+0x2c8>
    6682:      	cmpl	$0x9, %eax
    6685:      	jle	0x6aa2 <generic_fentry_filter_arg+0x9a2>
    668b:      	cmpl	$0x1d, %eax
    668e:      	jg	0x6f09 <generic_fentry_filter_arg+0xe09>
    6694:      	leal	-0xa(%rax), %edx
    6697:      	cmpl	$0x2, %edx
    669a:      	jb	0x6b89 <generic_fentry_filter_arg+0xa89>
    66a0:      	cmpl	$0xc, %eax
    66a3:      	je	0x6b09 <generic_fentry_filter_arg+0xa09>
    66a9:      	jmp	0x620d <generic_fentry_filter_arg+0x10d>
    66ae:      	leal	-0xc(%rcx), %edx
    66b1:      	cmpl	$0x2, %edx
    66b4:      	jae	0x6aea <generic_fentry_filter_arg+0x9ea>
    66ba:      	cmpl	$0x20, %eax
    66bd:      	ja	0x620d <generic_fentry_filter_arg+0x10d>
    66c3:      	movl	%eax, %edx
    66c5:      	movl	$0x101e, %esi           # imm = 0x101E
    66ca:      	btq	%rdx, %rsi
    66ce:      	jae	0x671e <generic_fentry_filter_arg+0x61e>
    66d0:      	movl	0x10(%r12), %edx
    66d5:      	cmpl	$0x2, %eax
    66d8:      	jle	0x6aaf <generic_fentry_filter_arg+0x9af>
    66de:      	leal	-0x3(%rax), %esi
    66e1:      	cmpl	$0x2, %esi
    66e4:      	jae	0x72c4 <generic_fentry_filter_arg+0x11c4>
    66ea:      	movq	0x8(%rsp), %rsi
    66ef:      	cmpl	%edx, (%rsi)
    66f1:      	jne	0x83c1 <generic_fentry_filter_arg+0x22c1>
    66f7:      	jmp	0x9321 <generic_fentry_filter_arg+0x3221>
    66fc:      	cmpl	$0x28, %ecx
    66ff:      	movq	%r8, %rsi
    6702:      	je	0x6e5c <generic_fentry_filter_arg+0xd5c>
    6708:      	movq	%rsi, %rdx
    670b:      	movl	$0x0, %ebx
    6710:      	cmpl	$0x29, %ecx
    6713:      	je	0x6e86 <generic_fentry_filter_arg+0xd86>
    6719:      	jmp	0x63b2 <generic_fentry_filter_arg+0x2b2>
    671e:      	movl	$0xc00, %esi            # imm = 0xC00
    6723:      	btq	%rdx, %rsi
    6727:      	jb	0x6df6 <generic_fentry_filter_arg+0xcf6>
    672d:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    6737:      	btq	%rdx, %rsi
    673b:      	jae	0x620d <generic_fentry_filter_arg+0x10d>
    6741:      	cmpl	$0x1f, %eax
    6744:      	jne	0x7431 <generic_fentry_filter_arg+0x1331>
    674a:      	movl	0x10(%r12), %esi
    674f:      	movl	0x14(%r12), %edx
    6754:      	cmpl	$0xc, %ecx
    6757:      	ja	0x81e4 <generic_fentry_filter_arg+0x20e4>
    675d:      	movl	$0x1402, %eax           # imm = 0x1402
    6762:      	btl	%ecx, %eax
    6765:      	jae	0x81e4 <generic_fentry_filter_arg+0x20e4>
    676b:      	movq	0x8(%rsp), %rax
    6770:      	movl	(%rax), %eax
    6772:      	cmpl	%eax, %esi
    6774:      	jg	0x81f7 <generic_fentry_filter_arg+0x20f7>
    677a:      	cmpl	%edx, %eax
    677c:      	jle	0x63c8 <generic_fentry_filter_arg+0x2c8>
    6782:      	jmp	0x81f7 <generic_fentry_filter_arg+0x20f7>
    6787:      	cmpl	$0x20, %eax
    678a:      	jg	0x6f55 <generic_fentry_filter_arg+0xe55>
    6790:      	cmpl	$0x1a, %eax
    6793:      	je	0x7037 <generic_fentry_filter_arg+0xf37>
    6799:      	movl	$0x0, %ebx
    679e:      	cmpl	$0x1b, %eax
    67a1:      	jne	0x90c7 <generic_fentry_filter_arg+0x2fc7>
    67a7:      	movq	%rsi, 0x8(%rsp)
    67ac:      	movq	%r11, 0x20(%rsp)
    67b1:      	movl	0x10(%r12), %eax
    67b6:      	movl	%eax, 0x40(%rsp)
    67ba:      	movl	$0x0, 0x80(%rsp)
    67c5:      	movl	$0x1, %eax
    67ca:      	leaq	0x40(%rsp), %rsi
    67cf:      	movq	(%rip), %rdi            # 0x67d6 <generic_fentry_filter_arg+0x6d6>
    67d6:      	callq	*%rax
    67d8:      	testl	%ebp, %ebp
    67da:      	je	0x90b6 <generic_fentry_filter_arg+0x2fb6>
    67e0:      	movl	$0x0, %ebx
    67e5:      	testq	%rax, %rax
    67e8:      	je	0x90b8 <generic_fentry_filter_arg+0x2fb8>
    67ee:      	movq	%rax, 0x28(%rsp)
    67f3:      	movl	$0x1, %eax
    67f8:      	movq	0x38(%rsp), %rsi
    67fd:      	movq	(%rip), %rdi            # 0x6804 <generic_fentry_filter_arg+0x704>
    6804:      	callq	*%rax
    6806:      	testq	%rax, %rax
    6809:      	je	0x90b6 <generic_fentry_filter_arg+0x2fb6>
    680f:      	movq	%rax, %rdi
    6812:      	cmpl	$0x7f, %ebp
    6815:      	movl	$0x7f, %eax
    681a:      	cmovbl	%ebp, %eax
    681d:      	shll	$0x3, %eax
    6820:      	movl	%eax, (%rdi)
    6822:      	movq	%rbp, %rax
    6825:      	negq	%rax
    6828:      	movl	$0x3, %ecx
    682d:      	subq	%rbp, %rcx
    6830:      	leal	-0x4(%rbp), %edx
    6833:      	movq	%rdi, 0x70(%rsp)
    6838:      	addq	$0x7, %rdi
    683c:      	movl	$0x2, %r8d
    6842:      	subq	%rbp, %r8
    6845:      	leal	-0x3(%rbp), %r9d
    6849:      	movl	$0x1, %r10d
    684f:      	subq	%rbp, %r10
    6852:      	leal	-0x2(%rbp), %r11d
    6856:      	decl	%ebp
    6858:      	xorl	%ebx, %ebx
    685a:      	movq	0x8(%rsp), %rsi
    685f:      	leal	(%rbx,%rbp), %r13d
    6863:      	andl	$0xfff, %r13d           # imm = 0xFFF
    686a:      	movzbl	(%rsi,%r13), %r13d
    686f:      	movb	%r13b, -0x3(%rdi)
    6873:      	cmpq	%rbx, %r10
    6876:      	je	0x68d0 <generic_fentry_filter_arg+0x7d0>
    6878:      	leal	(%r11,%rbx), %r13d
    687c:      	andl	$0xfff, %r13d           # imm = 0xFFF
    6883:      	movzbl	(%rsi,%r13), %r13d
    6888:      	movb	%r13b, -0x2(%rdi)
    688c:      	cmpq	%rbx, %r8
    688f:      	je	0x68d0 <generic_fentry_filter_arg+0x7d0>
    6891:      	leal	(%r9,%rbx), %r13d
    6895:      	andl	$0xfff, %r13d           # imm = 0xFFF
    689c:      	movzbl	(%rsi,%r13), %r13d
    68a1:      	movb	%r13b, -0x1(%rdi)
    68a5:      	cmpq	%rbx, %rcx
    68a8:      	je	0x68d0 <generic_fentry_filter_arg+0x7d0>
    68aa:      	cmpq	$-0x7c, %rbx
    68ae:      	je	0x68d0 <generic_fentry_filter_arg+0x7d0>
    68b0:      	leal	(%rdx,%rbx), %r13d
    68b4:      	andl	$0xfff, %r13d           # imm = 0xFFF
    68bb:      	movzbl	(%rsi,%r13), %r13d
    68c0:      	movb	%r13b, (%rdi)
    68c3:      	addq	$-0x4, %rbx
    68c7:      	addq	$0x4, %rdi
    68cb:      	cmpq	%rbx, %rax
    68ce:      	jne	0x685f <generic_fentry_filter_arg+0x75f>
    68d0:      	movl	$0x1, %eax
    68d5:      	movq	0x28(%rsp), %rdi
    68da:      	movq	0x70(%rsp), %rsi
    68df:      	callq	*%rax
    68e1:      	xorl	%ebx, %ebx
    68e3:      	testq	%rax, %rax
    68e6:      	setne	%bl
    68e9:      	movq	0x78(%rsp), %r13
    68ee:      	jmp	0x90b8 <generic_fentry_filter_arg+0x2fb8>
    68f3:      	cmpl	$0x11, %ecx
    68f6:      	jne	0x63c8 <generic_fentry_filter_arg+0x2c8>
    68fc:      	movq	%r8, %rsi
    68ff:      	addq	$0x4, %rsi
    6903:      	movq	%rsi, 0x8(%rsp)
    6908:      	movl	(%rsi), %ebp
    690a:      	movl	%eax, %ecx
    690c:      	andl	$-0x2, %ecx
    690f:      	cmpl	$0x24, %ecx
    6912:      	je	0x691c <generic_fentry_filter_arg+0x81c>
    6914:      	testl	%ebp, %ebp
    6916:      	je	0x620d <generic_fentry_filter_arg+0x10d>
    691c:      	cmpl	$0x25, %eax
    691f:      	movq	0x8(%rsp), %rsi
    6924:      	ja	0x6a24 <generic_fentry_filter_arg+0x924>
    692a:      	movl	%eax, %ecx
    692c:      	movl	$0x4000100, %edx        # imm = 0x4000100
    6931:      	btq	%rcx, %rdx
    6935:      	jb	0x6d4e <generic_fentry_filter_arg+0xc4e>
    693b:      	movl	$0x8000200, %edx        # imm = 0x8000200
    6940:      	btq	%rcx, %rdx
    6944:      	jb	0x6c03 <generic_fentry_filter_arg+0xb03>
    694a:      	movabsq	$0x3000000000, %rdx     # imm = 0x3000000000
    6954:      	btq	%rcx, %rdx
    6958:      	jae	0x6a24 <generic_fentry_filter_arg+0x924>
    695e:      	movw	$0x0, 0x40(%rsp)
    6965:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
    696b:      	ja	0x6a43 <generic_fentry_filter_arg+0x943>
    6971:      	movq	%r11, 0x20(%rsp)
    6976:      	leaq	(%rsi,%rbp), %rcx
    697a:      	addq	$0x8, %rcx
    697e:      	movl	$0x4, %eax
    6983:      	leaq	0x40(%rsp), %rdi
    6988:      	movl	$0x2, %edx
    698d:      	movl	(%rsi), %ecx
    698f:      	leaq	(%rsi,%rcx), %rdx
    6993:      	addq	$0x8, %rdx
    6997:      	movl	$0x2, %esi
    699c:      	callq	*%rax
    699e:      	movl	0x10(%r12), %ecx
    69a3:      	testl	%ecx, %ecx
    69a5:      	je	0x8ed9 <generic_fentry_filter_arg+0x2dd9>
    69ab:      	movzwl	0x40(%rsp), %eax
    69b0:      	andl	$0xf000, %eax           # imm = 0xF000
    69b5:      	movl	$0x1, %ebx
    69ba:      	cmpl	%eax, %ecx
    69bc:      	je	0x8edb <generic_fentry_filter_arg+0x2ddb>
    69c2:      	movl	0x8(%r12), %ecx
    69c7:      	cmpl	$0xd, %ecx
    69ca:      	movq	0x10(%rsp), %rdi
    69cf:      	movq	0x18(%rsp), %r9
    69d4:      	movq	0x20(%rsp), %r11
    69d9:      	jb	0x6a43 <generic_fentry_filter_arg+0x943>
    69db:      	movl	0x14(%r12), %edx
    69e0:      	testl	%edx, %edx
    69e2:      	je	0x6a43 <generic_fentry_filter_arg+0x943>
    69e4:      	cmpl	%eax, %edx
    69e6:      	je	0x8eea <generic_fentry_filter_arg+0x2dea>
    69ec:      	cmpl	$0x11, %ecx
    69ef:      	jb	0x6a43 <generic_fentry_filter_arg+0x943>
    69f1:      	movl	0x18(%r12), %edx
    69f6:      	testl	%edx, %edx
    69f8:      	je	0x6a43 <generic_fentry_filter_arg+0x943>
    69fa:      	cmpl	%eax, %edx
    69fc:      	je	0x8eea <generic_fentry_filter_arg+0x2dea>
    6a02:      	cmpl	$0x15, %ecx
    6a05:      	jb	0x9404 <generic_fentry_filter_arg+0x3304>
    6a0b:      	movl	0x1c(%r12), %ecx
    6a10:      	testl	%ecx, %ecx
    6a12:      	je	0x9404 <generic_fentry_filter_arg+0x3304>
    6a18:      	xorl	%ebx, %ebx
    6a1a:      	cmpl	%eax, %ecx
    6a1c:      	sete	%bl
    6a1f:      	jmp	0x9406 <generic_fentry_filter_arg+0x3306>
    6a24:      	addl	$-0x3, %eax
    6a27:      	cmpl	$0x2, %eax
    6a2a:      	jae	0x6a43 <generic_fentry_filter_arg+0x943>
    6a2c:      	movl	$0x0, 0x80(%rsp)
    6a37:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
    6a3d:      	jbe	0x73db <generic_fentry_filter_arg+0x12db>
    6a43:      	xorl	%ebx, %ebx
    6a45:      	movl	0x4(%r12), %eax
    6a4a:      	cmpq	$0x25, %rax
    6a4e:      	jbe	0x8ef9 <generic_fentry_filter_arg+0x2df9>
    6a54:      	jmp	0x63b7 <generic_fentry_filter_arg+0x2b7>
    6a59:      	cmpl	$0x20, %eax
    6a5c:      	ja	0x620d <generic_fentry_filter_arg+0x10d>
    6a62:      	movl	%eax, %ecx
    6a64:      	movl	$0x101e, %edx           # imm = 0x101E
    6a69:      	btq	%rcx, %rdx
    6a6d:      	jae	0x7315 <generic_fentry_filter_arg+0x1215>
    6a73:      	movl	0x10(%r12), %ecx
    6a78:      	cmpl	$0x2, %eax
    6a7b:      	jle	0x7813 <generic_fentry_filter_arg+0x1713>
    6a81:      	leal	-0x3(%rax), %edx
    6a84:      	cmpl	$0x2, %edx
    6a87:      	movq	0x8(%rsp), %rdx
    6a8c:      	jae	0x7e3d <generic_fentry_filter_arg+0x1d3d>
    6a92:      	movzwl	(%rdx), %edx
    6a95:      	cmpl	%edx, %ecx
    6a97:      	jne	0x818a <generic_fentry_filter_arg+0x208a>
    6a9d:      	jmp	0x9321 <generic_fentry_filter_arg+0x3221>
    6aa2:      	leal	-0x1(%rax), %edx
    6aa5:      	cmpl	$0x4, %edx
    6aa8:      	jb	0x6b09 <generic_fentry_filter_arg+0xa09>
    6aaa:      	jmp	0x620d <generic_fentry_filter_arg+0x10d>
    6aaf:      	cmpl	$0x1, %eax
    6ab2:      	je	0x759f <generic_fentry_filter_arg+0x149f>
    6ab8:      	cmpl	$0x2, %eax
    6abb:      	jne	0x83c1 <generic_fentry_filter_arg+0x22c1>
    6ac1:      	cmpl	$0xc, %ecx
    6ac4:      	ja	0x83b4 <generic_fentry_filter_arg+0x22b4>
    6aca:      	movl	$0x1402, %esi           # imm = 0x1402
    6acf:      	btl	%ecx, %esi
    6ad2:      	jae	0x83b4 <generic_fentry_filter_arg+0x22b4>
    6ad8:      	movq	0x8(%rsp), %rsi
    6add:      	cmpl	%edx, (%rsi)
    6adf:      	jl	0x63c8 <generic_fentry_filter_arg+0x2c8>
    6ae5:      	jmp	0x83c1 <generic_fentry_filter_arg+0x22c1>
    6aea:      	cmpl	$0x1c, %ecx
    6aed:      	jne	0x63c8 <generic_fentry_filter_arg+0x2c8>
    6af3:      	cmpl	$0x20, %eax
    6af6:      	ja	0x620d <generic_fentry_filter_arg+0x10d>
    6afc:      	movl	%eax, %edx
    6afe:      	movl	$0x101e, %esi           # imm = 0x101E
    6b03:      	btq	%rdx, %rsi
    6b07:      	jae	0x6b32 <generic_fentry_filter_arg+0xa32>
    6b09:      	movq	0x10(%r12), %rdx
    6b0e:      	cmpl	$0x2, %eax
    6b11:      	jle	0x6b56 <generic_fentry_filter_arg+0xa56>
    6b13:      	leal	-0x3(%rax), %esi
    6b16:      	cmpl	$0x2, %esi
    6b19:      	jae	0x6e40 <generic_fentry_filter_arg+0xd40>
    6b1f:      	movq	0x8(%rsp), %rsi
    6b24:      	cmpq	%rdx, (%rsi)
    6b27:      	jne	0x7d93 <generic_fentry_filter_arg+0x1c93>
    6b2d:      	jmp	0x9321 <generic_fentry_filter_arg+0x3221>
    6b32:      	movl	$0xc00, %esi            # imm = 0xC00
    6b37:      	btq	%rdx, %rsi
    6b3b:      	jb	0x6b89 <generic_fentry_filter_arg+0xa89>
    6b3d:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    6b47:      	btq	%rdx, %rsi
    6b4b:      	jb	0x6f15 <generic_fentry_filter_arg+0xe15>
    6b51:      	jmp	0x620d <generic_fentry_filter_arg+0x10d>
    6b56:      	cmpl	$0x1, %eax
    6b59:      	je	0x73ba <generic_fentry_filter_arg+0x12ba>
    6b5f:      	cmpl	$0x2, %eax
    6b62:      	jne	0x7d93 <generic_fentry_filter_arg+0x1c93>
    6b68:      	cmpl	$0xc, %ecx
    6b6b:      	je	0x6b76 <generic_fentry_filter_arg+0xa76>
    6b6d:      	cmpl	$0xa, %ecx
    6b70:      	jne	0x7d85 <generic_fentry_filter_arg+0x1c85>
    6b76:      	movq	0x8(%rsp), %rsi
    6b7b:      	cmpq	%rdx, (%rsi)
    6b7e:      	jl	0x63c8 <generic_fentry_filter_arg+0x2c8>
    6b84:      	jmp	0x7d93 <generic_fentry_filter_arg+0x1c93>
    6b89:      	movq	%r11, %rbp
    6b8c:      	movzbl	0x10(%r12), %eax
    6b92:      	movl	%eax, 0x80(%rsp)
    6b99:      	movl	$0x1, %eax
    6b9e:      	movq	0x38(%rsp), %rsi
    6ba3:      	movq	(%rip), %rdi            # 0x6baa <generic_fentry_filter_arg+0xaaa>
    6baa:      	callq	*%rax
    6bac:      	testq	%rax, %rax
    6baf:      	je	0x78fb <generic_fentry_filter_arg+0x17fb>
    6bb5:      	movq	%rax, %rdi
    6bb8:      	movq	0x8(%rsp), %rax
    6bbd:      	movq	(%rax), %rax
    6bc0:      	movq	%rax, 0x40(%rsp)
    6bc5:      	movl	$0x1, %eax
    6bca:      	leaq	0x40(%rsp), %rsi
    6bcf:      	callq	*%rax
    6bd1:      	movl	0x4(%r12), %ecx
    6bd6:      	cmpl	$0xb, %ecx
    6bd9:      	je	0x7927 <generic_fentry_filter_arg+0x1827>
    6bdf:      	cmpl	$0xa, %ecx
    6be2:      	movq	0x10(%rsp), %rdi
    6be7:      	movq	0x18(%rsp), %r9
    6bec:      	movq	%rbp, %r11
    6bef:      	jne	0x7942 <generic_fentry_filter_arg+0x1842>
    6bf5:      	testq	%rax, %rax
    6bf8:      	setne	%al
    6bfb:      	movzbl	%al, %ebx
    6bfe:      	jmp	0x63b7 <generic_fentry_filter_arg+0x2b7>
    6c03:      	movq	%r11, 0x20(%rsp)
    6c08:      	movl	0x10(%r12), %eax
    6c0d:      	movl	%eax, 0x40(%rsp)
    6c11:      	movl	$0x0, 0x80(%rsp)
    6c1c:      	movl	$0x1, %eax
    6c21:      	leaq	0x40(%rsp), %rsi
    6c26:      	movq	(%rip), %rdi            # 0x6c2d <generic_fentry_filter_arg+0xb2d>
    6c2d:      	callq	*%rax
    6c2f:      	testl	%ebp, %ebp
    6c31:      	je	0x8ed9 <generic_fentry_filter_arg+0x2dd9>
    6c37:      	movl	$0x0, %ebx
    6c3c:      	testq	%rax, %rax
    6c3f:      	je	0x8edb <generic_fentry_filter_arg+0x2ddb>
    6c45:      	movq	%rax, 0x28(%rsp)
    6c4a:      	movl	$0x1, %eax
    6c4f:      	movq	0x38(%rsp), %rsi
    6c54:      	movq	(%rip), %rdi            # 0x6c5b <generic_fentry_filter_arg+0xb5b>
    6c5b:      	callq	*%rax
    6c5d:      	testq	%rax, %rax
    6c60:      	je	0x8ed9 <generic_fentry_filter_arg+0x2dd9>
    6c66:      	movq	%rax, %rdi
    6c69:      	cmpl	$0x7f, %ebp
    6c6c:      	movl	$0x7f, %eax
    6c71:      	cmovbl	%ebp, %eax
    6c74:      	shll	$0x3, %eax
    6c77:      	movl	%eax, (%rdi)
    6c79:      	movq	%rbp, %rax
    6c7c:      	negq	%rax
    6c7f:      	movl	$0x3, %ecx
    6c84:      	subq	%rbp, %rcx
    6c87:      	leal	-0x4(%rbp), %edx
    6c8a:      	movq	%rdi, 0x70(%rsp)
    6c8f:      	addq	$0x7, %rdi
    6c93:      	movl	$0x2, %r8d
    6c99:      	subq	%rbp, %r8
    6c9c:      	leal	-0x3(%rbp), %r9d
    6ca0:      	movl	$0x1, %r10d
    6ca6:      	subq	%rbp, %r10
    6ca9:      	leal	-0x2(%rbp), %r11d
    6cad:      	decl	%ebp
    6caf:      	xorl	%ebx, %ebx
    6cb1:      	movq	0x8(%rsp), %rsi
    6cb6:      	leal	(%rbx,%rbp), %r13d
    6cba:      	andl	$0xfff, %r13d           # imm = 0xFFF
    6cc1:      	movzbl	0x4(%rsi,%r13), %r13d
    6cc7:      	movb	%r13b, -0x3(%rdi)
    6ccb:      	cmpq	%rbx, %r10
    6cce:      	je	0x6d2b <generic_fentry_filter_arg+0xc2b>
    6cd0:      	leal	(%r11,%rbx), %r13d
    6cd4:      	andl	$0xfff, %r13d           # imm = 0xFFF
    6cdb:      	movzbl	0x4(%rsi,%r13), %r13d
    6ce1:      	movb	%r13b, -0x2(%rdi)
    6ce5:      	cmpq	%rbx, %r8
    6ce8:      	je	0x6d2b <generic_fentry_filter_arg+0xc2b>
    6cea:      	leal	(%r9,%rbx), %r13d
    6cee:      	andl	$0xfff, %r13d           # imm = 0xFFF
    6cf5:      	movzbl	0x4(%rsi,%r13), %r13d
    6cfb:      	movb	%r13b, -0x1(%rdi)
    6cff:      	cmpq	%rbx, %rcx
    6d02:      	je	0x6d2b <generic_fentry_filter_arg+0xc2b>
    6d04:      	cmpq	$-0x7c, %rbx
    6d08:      	je	0x6d2b <generic_fentry_filter_arg+0xc2b>
    6d0a:      	leal	(%rdx,%rbx), %r13d
    6d0e:      	andl	$0xfff, %r13d           # imm = 0xFFF
    6d15:      	movzbl	0x4(%rsi,%r13), %r13d
    6d1b:      	movb	%r13b, (%rdi)
    6d1e:      	addq	$-0x4, %rbx
    6d22:      	addq	$0x4, %rdi
    6d26:      	cmpq	%rbx, %rax
    6d29:      	jne	0x6cb6 <generic_fentry_filter_arg+0xbb6>
    6d2b:      	movl	$0x1, %eax
    6d30:      	movq	0x28(%rsp), %rdi
    6d35:      	movq	0x70(%rsp), %rsi
    6d3a:      	callq	*%rax
    6d3c:      	xorl	%ebx, %ebx
    6d3e:      	testq	%rax, %rax
    6d41:      	setne	%bl
    6d44:      	movq	0x78(%rsp), %r13
    6d49:      	jmp	0x8edb <generic_fentry_filter_arg+0x2ddb>
    6d4e:      	movq	%r11, 0x20(%rsp)
    6d53:      	movl	0x10(%r12), %eax
    6d58:      	movl	%eax, 0x40(%rsp)
    6d5c:      	movl	$0x0, 0x80(%rsp)
    6d67:      	movl	$0x1, %eax
    6d6c:      	leaq	0x40(%rsp), %rsi
    6d71:      	movq	(%rip), %rdi            # 0x6d78 <generic_fentry_filter_arg+0xc78>
    6d78:      	callq	*%rax
    6d7a:      	testl	%ebp, %ebp
    6d7c:      	je	0x8ed9 <generic_fentry_filter_arg+0x2dd9>
    6d82:      	movl	$0x0, %ebx
    6d87:      	testq	%rax, %rax
    6d8a:      	je	0x8edb <generic_fentry_filter_arg+0x2ddb>
    6d90:      	movq	%rax, 0x28(%rsp)
    6d95:      	movl	$0x1, %eax
    6d9a:      	movq	0x38(%rsp), %rsi
    6d9f:      	movq	(%rip), %rdi            # 0x6da6 <generic_fentry_filter_arg+0xca6>
    6da6:      	callq	*%rax
    6da8:      	testq	%rax, %rax
    6dab:      	je	0x8ed9 <generic_fentry_filter_arg+0x2dd9>
    6db1:      	movq	%rax, %rbx
    6db4:      	movq	0x8(%rsp), %rdx
    6db9:      	addq	$0x4, %rdx
    6dbd:      	cmpl	$0xff, %ebp
    6dc3:      	movl	$0xff, %eax
    6dc8:      	cmovael	%eax, %ebp
    6dcb:      	leal	(,%rbp,8), %eax
    6dd2:      	movl	%eax, (%rbx)
    6dd4:      	movq	%rbx, %rdi
    6dd7:      	addq	$0x4, %rdi
    6ddb:      	movl	$0x4, %eax
    6de0:      	movl	%ebp, %esi
    6de2:      	callq	*%rax
    6de4:      	movl	$0x1, %eax
    6de9:      	movq	0x28(%rsp), %rdi
    6dee:      	movq	%rbx, %rsi
    6df1:      	jmp	0x8ecd <generic_fentry_filter_arg+0x2dcd>
    6df6:      	movq	%r11, %rbp
    6df9:      	movzbl	0x10(%r12), %eax
    6dff:      	movl	%eax, 0x80(%rsp)
    6e06:      	movl	$0x1, %eax
    6e0b:      	movq	0x38(%rsp), %rsi
    6e10:      	movq	(%rip), %rdi            # 0x6e17 <generic_fentry_filter_arg+0xd17>
    6e17:      	callq	*%rax
    6e19:      	testq	%rax, %rax
    6e1c:      	je	0x78fb <generic_fentry_filter_arg+0x17fb>
    6e22:      	movq	%rax, %rdi
    6e25:      	movq	0x8(%rsp), %rax
    6e2a:      	movl	(%rax), %eax
    6e2c:      	movq	%rax, 0x40(%rsp)
    6e31:      	movl	$0x1, %eax
    6e36:      	leaq	0x40(%rsp), %rsi
    6e3b:      	jmp	0x78c4 <generic_fentry_filter_arg+0x17c4>
    6e40:      	cmpl	$0xc, %eax
    6e43:      	jne	0x7d93 <generic_fentry_filter_arg+0x1c93>
    6e49:      	movq	0x8(%rsp), %rsi
    6e4e:      	testq	%rdx, (%rsi)
    6e51:      	jne	0x63c8 <generic_fentry_filter_arg+0x2c8>
    6e57:      	jmp	0x7d93 <generic_fentry_filter_arg+0x1c93>
    6e5c:      	movzwl	(%rsi), %edx
    6e5f:      	movw	%dx, 0x66(%rsp)
    6e64:      	movzwl	0x2(%rsi), %edx
    6e68:      	movw	%dx, 0x60(%rsp)
    6e6d:      	movq	0x8(%rsi), %rdx
    6e71:      	movq	%rdx, 0x40(%rsp)
    6e76:      	movq	0x10(%rsi), %rdx
    6e7a:      	movq	%rdx, 0x48(%rsp)
    6e7f:      	leaq	0x40(%rsp), %rsi
    6e84:      	xorl	%edx, %edx
    6e86:      	cmpl	$0x13, %eax
    6e89:      	jle	0x6eb2 <generic_fentry_filter_arg+0xdb2>
    6e8b:      	cmpl	$0x17, %eax
    6e8e:      	jg	0x6ee4 <generic_fentry_filter_arg+0xde4>
    6e90:      	leal	-0x14(%rax), %ecx
    6e93:      	cmpl	$0x2, %ecx
    6e96:      	jb	0x7483 <generic_fentry_filter_arg+0x1383>
    6e9c:      	leal	-0x16(%rax), %ecx
    6e9f:      	movl	$0x0, %ebx
    6ea4:      	cmpl	$0x2, %ecx
    6ea7:      	jb	0x747c <generic_fentry_filter_arg+0x137c>
    6ead:      	jmp	0x63b2 <generic_fentry_filter_arg+0x2b2>
    6eb2:      	cmpl	$0xf, %eax
    6eb5:      	jle	0x713f <generic_fentry_filter_arg+0x103f>
    6ebb:      	cmpl	$0x11, %eax
    6ebe:      	jg	0x7469 <generic_fentry_filter_arg+0x1369>
    6ec4:      	cmpl	$0x10, %eax
    6ec7:      	je	0x747c <generic_fentry_filter_arg+0x137c>
    6ecd:      	movl	$0x0, %ebx
    6ed2:      	cmpl	$0x11, %eax
    6ed5:      	jne	0x63b2 <generic_fentry_filter_arg+0x2b2>
    6edb:      	movzwl	0x24(%rsi), %ebx
    6edf:      	jmp	0x7cee <generic_fentry_filter_arg+0x1bee>
    6ee4:      	cmpl	$0x1b, %eax
    6ee7:      	jg	0x74bc <generic_fentry_filter_arg+0x13bc>
    6eed:      	cmpl	$0x18, %eax
    6ef0:      	je	0x74f6 <generic_fentry_filter_arg+0x13f6>
    6ef6:      	movl	$0x0, %ebx
    6efb:      	cmpl	$0x19, %eax
    6efe:      	je	0x74ec <generic_fentry_filter_arg+0x13ec>
    6f04:      	jmp	0x63b2 <generic_fentry_filter_arg+0x2b2>
    6f09:      	leal	-0x1f(%rax), %edx
    6f0c:      	cmpl	$0x2, %edx
    6f0f:      	jae	0x7a1e <generic_fentry_filter_arg+0x191e>
    6f15:      	cmpl	$0x1f, %eax
    6f18:      	jne	0x710d <generic_fentry_filter_arg+0x100d>
    6f1e:      	movq	0x10(%r12), %rsi
    6f23:      	movq	0x18(%r12), %rdx
    6f28:      	cmpl	$0xa, %ecx
    6f2b:      	je	0x6f36 <generic_fentry_filter_arg+0xe36>
    6f2d:      	cmpl	$0xc, %ecx
    6f30:      	jne	0x7c41 <generic_fentry_filter_arg+0x1b41>
    6f36:      	movq	0x8(%rsp), %rax
    6f3b:      	movq	(%rax), %rax
    6f3e:      	cmpq	%rax, %rsi
    6f41:      	jg	0x7c57 <generic_fentry_filter_arg+0x1b57>
    6f47:      	cmpq	%rdx, %rax
    6f4a:      	jle	0x63c8 <generic_fentry_filter_arg+0x2c8>
    6f50:      	jmp	0x7c57 <generic_fentry_filter_arg+0x1b57>
    6f55:      	cmpl	$0x21, %eax
    6f58:      	je	0x75c8 <generic_fentry_filter_arg+0x14c8>
    6f5e:      	movl	$0x0, %ebx
    6f63:      	cmpl	$0x22, %eax
    6f66:      	jne	0x90c7 <generic_fentry_filter_arg+0x2fc7>
    6f6c:      	movq	%rsi, 0x8(%rsp)
    6f71:      	xorl	%ebx, %ebx
    6f73:      	xorl	%r13d, %r13d
    6f76:      	movq	%r11, %r15
    6f79:      	movl	0x10(%r12,%rbx,4), %eax
    6f7e:      	movl	%eax, 0x40(%rsp)
    6f82:      	movl	$0x1, %eax
    6f87:      	leaq	0x40(%rsp), %rsi
    6f8c:      	movq	(%rip), %rdi            # 0x6f93 <generic_fentry_filter_arg+0xe93>
    6f93:      	callq	*%rax
    6f95:      	testq	%rax, %rax
    6f98:      	je	0x8493 <generic_fentry_filter_arg+0x2393>
    6f9e:      	testl	%ebp, %ebp
    6fa0:      	movq	%r15, %r11
    6fa3:      	movq	0x68(%rsp), %r15
    6fa8:      	je	0x7014 <generic_fentry_filter_arg+0xf14>
    6faa:      	movq	0x8(%rsp), %rdx
    6faf:      	xorl	%ecx, %ecx
    6fb1:      	jmp	0x6fbe <generic_fentry_filter_arg+0xebe>
    6fb3:      	incq	%rcx
    6fb6:      	incq	%rdx
    6fb9:      	cmpq	%rbp, %rcx
    6fbc:      	je	0x7014 <generic_fentry_filter_arg+0xf14>
    6fbe:      	xorl	%esi, %esi
    6fc0:      	leaq	(%rcx,%rsi), %rdi
    6fc4:      	cmpq	%rbp, %rdi
    6fc7:      	jae	0x6fb3 <generic_fentry_filter_arg+0xeb3>
    6fc9:      	movsbl	(%rax,%rsi), %edi
    6fcd:      	testl	%edi, %edi
    6fcf:      	je	0x700c <generic_fentry_filter_arg+0xf0c>
    6fd1:      	movsbl	(%rdx,%rsi), %r9d
    6fd6:      	leal	-0x41(%r9), %r10d
    6fda:      	movl	%r9d, %r8d
    6fdd:      	orl	$0x20, %r8d
    6fe1:      	cmpl	$0x1a, %r10d
    6fe5:      	cmovael	%r9d, %r8d
    6fe9:      	leal	-0x41(%rdi), %r10d
    6fed:      	movl	%edi, %r9d
    6ff0:      	orl	$0x20, %r9d
    6ff4:      	cmpl	$0x1a, %r10d
    6ff8:      	cmovael	%edi, %r9d
    6ffc:      	cmpq	$0x62, %rsi
    7000:      	ja	0x6fb3 <generic_fentry_filter_arg+0xeb3>
    7002:      	incq	%rsi
    7005:      	cmpl	%r9d, %r8d
    7008:      	je	0x6fc0 <generic_fentry_filter_arg+0xec0>
    700a:      	jmp	0x6fb3 <generic_fentry_filter_arg+0xeb3>
    700c:      	testl	%ecx, %ecx
    700e:      	jns	0x8788 <generic_fentry_filter_arg+0x2688>
    7014:      	leal	0xc(%r13), %eax
    7018:      	cmpl	0x8(%r12), %eax
    701d:      	jae	0x7030 <generic_fentry_filter_arg+0xf30>
    701f:      	addl	$0x4, %r13d
    7023:      	incq	%rbx
    7026:      	cmpq	$0x64, %rbx
    702a:      	jne	0x6f76 <generic_fentry_filter_arg+0xe76>
    7030:      	xorl	%ebx, %ebx
    7032:      	jmp	0x878d <generic_fentry_filter_arg+0x268d>
    7037:      	movq	%rsi, 0x8(%rsp)
    703c:      	movq	%r11, 0x20(%rsp)
    7041:      	movl	0x10(%r12), %eax
    7046:      	movl	%eax, 0x40(%rsp)
    704a:      	movl	$0x0, 0x80(%rsp)
    7055:      	movl	$0x1, %eax
    705a:      	leaq	0x40(%rsp), %rsi
    705f:      	movq	(%rip), %rdi            # 0x7066 <generic_fentry_filter_arg+0xf66>
    7066:      	callq	*%rax
    7068:      	testl	%ebp, %ebp
    706a:      	je	0x90b6 <generic_fentry_filter_arg+0x2fb6>
    7070:      	movl	$0x0, %ebx
    7075:      	testq	%rax, %rax
    7078:      	je	0x90b8 <generic_fentry_filter_arg+0x2fb8>
    707e:      	movq	%rax, 0x28(%rsp)
    7083:      	movl	$0x1, %eax
    7088:      	movq	0x38(%rsp), %rsi
    708d:      	movq	(%rip), %rdi            # 0x7094 <generic_fentry_filter_arg+0xf94>
    7094:      	callq	*%rax
    7096:      	testq	%rax, %rax
    7099:      	je	0x90b6 <generic_fentry_filter_arg+0x2fb6>
    709f:      	cmpl	$0xff, %ebp
    70a5:      	movl	$0xff, %ecx
    70aa:      	cmovael	%ecx, %ebp
    70ad:      	leal	(,%rbp,8), %ecx
    70b4:      	movl	%ecx, (%rax)
    70b6:      	movq	%rax, %rdi
    70b9:      	addq	$0x4, %rdi
    70bd:      	movq	%rax, %rbx
    70c0:      	movl	$0x4, %eax
    70c5:      	movq	0x8(%rsp), %rdx
    70ca:      	movl	%ebp, %esi
    70cc:      	callq	*%rax
    70ce:      	movl	$0x1, %eax
    70d3:      	movq	0x28(%rsp), %rdi
    70d8:      	movq	%rbx, %rsi
    70db:      	jmp	0x90aa <generic_fentry_filter_arg+0x2faa>
    70e0:      	movl	$0x0, 0x80(%rsp)
    70eb:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
    70f1:      	jbe	0x7682 <generic_fentry_filter_arg+0x1582>
    70f7:      	xorl	%ebx, %ebx
    70f9:      	movl	0x4(%r12), %eax
    70fe:      	cmpq	$0x25, %rax
    7102:      	jbe	0x90d6 <generic_fentry_filter_arg+0x2fd6>
    7108:      	jmp	0x63b7 <generic_fentry_filter_arg+0x2b7>
    710d:      	movq	0x10(%r12), %rsi
    7112:      	movq	0x18(%r12), %rax
    7117:      	cmpl	$0xc, %ecx
    711a:      	je	0x7125 <generic_fentry_filter_arg+0x1025>
    711c:      	cmpl	$0xa, %ecx
    711f:      	jne	0x7c99 <generic_fentry_filter_arg+0x1b99>
    7125:      	movq	0x8(%rsp), %rdx
    712a:      	movq	(%rdx), %rdx
    712d:      	cmpq	%rdx, %rsi
    7130:      	setle	%sil
    7134:      	cmpq	%rax, %rdx
    7137:      	setle	%al
    713a:      	jmp	0x7cae <generic_fentry_filter_arg+0x1bae>
    713f:      	cmpl	$0xd, %eax
    7142:      	je	0x74f6 <generic_fentry_filter_arg+0x13f6>
    7148:      	cmpl	$0xe, %eax
    714b:      	je	0x74ec <generic_fentry_filter_arg+0x13ec>
    7151:      	movl	$0x0, %ebx
    7156:      	cmpl	$0xf, %eax
    7159:      	je	0x7483 <generic_fentry_filter_arg+0x1383>
    715f:      	jmp	0x63b2 <generic_fentry_filter_arg+0x2b2>
    7164:      	cmpl	$0x20, %eax
    7167:      	movq	%rsi, 0x8(%rsp)
    716c:      	jg	0x7758 <generic_fentry_filter_arg+0x1658>
    7172:      	cmpl	$0x1a, %eax
    7175:      	je	0x794c <generic_fentry_filter_arg+0x184c>
    717b:      	movl	$0x0, %ebx
    7180:      	cmpl	$0x1b, %eax
    7183:      	jne	0x9395 <generic_fentry_filter_arg+0x3295>
    7189:      	movq	%r11, 0x20(%rsp)
    718e:      	movl	0x10(%r12), %eax
    7193:      	movl	%eax, 0x40(%rsp)
    7197:      	movl	$0x0, 0x80(%rsp)
    71a2:      	movl	$0x1, %eax
    71a7:      	leaq	0x40(%rsp), %rsi
    71ac:      	movq	(%rip), %rdi            # 0x71b3 <generic_fentry_filter_arg+0x10b3>
    71b3:      	callq	*%rax
    71b5:      	testl	%ebp, %ebp
    71b7:      	je	0x9384 <generic_fentry_filter_arg+0x3284>
    71bd:      	movq	%rax, %r13
    71c0:      	movl	$0x0, %ebx
    71c5:      	testq	%rax, %rax
    71c8:      	je	0x9386 <generic_fentry_filter_arg+0x3286>
    71ce:      	movl	$0x1, %eax
    71d3:      	movq	0x38(%rsp), %rsi
    71d8:      	movq	(%rip), %rdi            # 0x71df <generic_fentry_filter_arg+0x10df>
    71df:      	callq	*%rax
    71e1:      	testq	%rax, %rax
    71e4:      	je	0x9384 <generic_fentry_filter_arg+0x3284>
    71ea:      	movq	%rax, %rdi
    71ed:      	movq	%r13, 0x28(%rsp)
    71f2:      	cmpl	$0x7f, %ebp
    71f5:      	movl	$0x7f, %eax
    71fa:      	cmovbl	%ebp, %eax
    71fd:      	shll	$0x3, %eax
    7200:      	movl	%eax, (%rdi)
    7202:      	movq	%rbp, %rax
    7205:      	negq	%rax
    7208:      	movl	$0x3, %ecx
    720d:      	subq	%rbp, %rcx
    7210:      	leal	-0x4(%rbp), %edx
    7213:      	movq	%rdi, 0x70(%rsp)
    7218:      	addq	$0x7, %rdi
    721c:      	movl	$0x2, %r8d
    7222:      	subq	%rbp, %r8
    7225:      	leal	-0x3(%rbp), %r9d
    7229:      	movl	$0x1, %r10d
    722f:      	subq	%rbp, %r10
    7232:      	leal	-0x2(%rbp), %r11d
    7236:      	decl	%ebp
    7238:      	xorl	%ebx, %ebx
    723a:      	movq	0x8(%rsp), %rsi
    723f:      	leal	(%rbx,%rbp), %r13d
    7243:      	andl	$0xfff, %r13d           # imm = 0xFFF
    724a:      	movzbl	(%rsi,%r13), %r13d
    724f:      	movb	%r13b, -0x3(%rdi)
    7253:      	cmpq	%rbx, %r10
    7256:      	je	0x72b0 <generic_fentry_filter_arg+0x11b0>
    7258:      	leal	(%r11,%rbx), %r13d
    725c:      	andl	$0xfff, %r13d           # imm = 0xFFF
    7263:      	movzbl	(%rsi,%r13), %r13d
    7268:      	movb	%r13b, -0x2(%rdi)
    726c:      	cmpq	%rbx, %r8
    726f:      	je	0x72b0 <generic_fentry_filter_arg+0x11b0>
    7271:      	leal	(%r9,%rbx), %r13d
    7275:      	andl	$0xfff, %r13d           # imm = 0xFFF
    727c:      	movzbl	(%rsi,%r13), %r13d
    7281:      	movb	%r13b, -0x1(%rdi)
    7285:      	cmpq	%rbx, %rcx
    7288:      	je	0x72b0 <generic_fentry_filter_arg+0x11b0>
    728a:      	cmpq	$-0x7c, %rbx
    728e:      	je	0x72b0 <generic_fentry_filter_arg+0x11b0>
    7290:      	leal	(%rdx,%rbx), %r13d
    7294:      	andl	$0xfff, %r13d           # imm = 0xFFF
    729b:      	movzbl	(%rsi,%r13), %r13d
    72a0:      	movb	%r13b, (%rdi)
    72a3:      	addq	$-0x4, %rbx
    72a7:      	addq	$0x4, %rdi
    72ab:      	cmpq	%rbx, %rax
    72ae:      	jne	0x723f <generic_fentry_filter_arg+0x113f>
    72b0:      	movl	$0x1, %eax
    72b5:      	movq	0x28(%rsp), %rdi
    72ba:      	movq	0x70(%rsp), %rsi
    72bf:      	jmp	0x9378 <generic_fentry_filter_arg+0x3278>
    72c4:      	cmpl	$0xc, %eax
    72c7:      	jne	0x83c1 <generic_fentry_filter_arg+0x22c1>
    72cd:      	movq	0x8(%rsp), %rsi
    72d2:      	testl	%edx, (%rsi)
    72d4:      	jne	0x63c8 <generic_fentry_filter_arg+0x2c8>
    72da:      	jmp	0x83c1 <generic_fentry_filter_arg+0x22c1>
    72df:      	movl	$0xc00, %edx            # imm = 0xC00
    72e4:      	btq	%rcx, %rdx
    72e8:      	jb	0x783a <generic_fentry_filter_arg+0x173a>
    72ee:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    72f8:      	btq	%rcx, %rdx
    72fc:      	jae	0x620d <generic_fentry_filter_arg+0x10d>
    7302:      	cmpl	$0x1f, %eax
    7305:      	jne	0x7f94 <generic_fentry_filter_arg+0x1e94>
    730b:      	movq	0x8(%rsp), %rax
    7310:      	movzbl	(%rax), %eax
    7313:      	jmp	0x7349 <generic_fentry_filter_arg+0x1249>
    7315:      	movl	$0xc00, %edx            # imm = 0xC00
    731a:      	btq	%rcx, %rdx
    731e:      	jb	0x7882 <generic_fentry_filter_arg+0x1782>
    7324:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    732e:      	btq	%rcx, %rdx
    7332:      	jae	0x620d <generic_fentry_filter_arg+0x10d>
    7338:      	cmpl	$0x1f, %eax
    733b:      	jne	0x7fa3 <generic_fentry_filter_arg+0x1ea3>
    7341:      	movq	0x8(%rsp), %rax
    7346:      	movzwl	(%rax), %eax
    7349:      	cmpl	%eax, 0x10(%r12)
    734e:      	ja	0x735b <generic_fentry_filter_arg+0x125b>
    7350:      	cmpl	%eax, 0x14(%r12)
    7355:      	jae	0x63c8 <generic_fentry_filter_arg+0x2c8>
    735b:      	movl	0x8(%r12), %ecx
    7360:      	cmpl	$0x11, %ecx
    7363:      	jb	0x620d <generic_fentry_filter_arg+0x10d>
    7369:      	cmpl	%eax, 0x18(%r12)
    736e:      	ja	0x737b <generic_fentry_filter_arg+0x127b>
    7370:      	cmpl	%eax, 0x1c(%r12)
    7375:      	jae	0x63c8 <generic_fentry_filter_arg+0x2c8>
    737b:      	cmpl	$0x19, %ecx
    737e:      	jb	0x620d <generic_fentry_filter_arg+0x10d>
    7384:      	cmpl	%eax, 0x20(%r12)
    7389:      	ja	0x7396 <generic_fentry_filter_arg+0x1296>
    738b:      	cmpl	%eax, 0x24(%r12)
    7390:      	jae	0x63c8 <generic_fentry_filter_arg+0x2c8>
    7396:      	cmpl	$0x21, %ecx
    7399:      	jb	0x620d <generic_fentry_filter_arg+0x10d>
    739f:      	cmpl	%eax, 0x28(%r12)
    73a4:      	ja	0x620d <generic_fentry_filter_arg+0x10d>
    73aa:      	cmpl	%eax, 0x2c(%r12)
    73af:      	jae	0x63c8 <generic_fentry_filter_arg+0x2c8>
    73b5:      	jmp	0x620d <generic_fentry_filter_arg+0x10d>
    73ba:      	cmpl	$0xc, %ecx
    73bd:      	je	0x73c8 <generic_fentry_filter_arg+0x12c8>
    73bf:      	cmpl	$0xa, %ecx
    73c2:      	jne	0x7d75 <generic_fentry_filter_arg+0x1c75>
    73c8:      	movq	0x8(%rsp), %rsi
    73cd:      	cmpq	%rdx, (%rsi)
    73d0:      	jg	0x63c8 <generic_fentry_filter_arg+0x2c8>
    73d6:      	jmp	0x7d93 <generic_fentry_filter_arg+0x1c93>
    73db:      	movzwl	%bp, %eax
    73de:      	cmpl	$0x90, %eax
    73e3:      	movq	%r11, 0x20(%rsp)
    73e8:      	ja	0x7a8f <generic_fentry_filter_arg+0x198f>
    73ee:      	testw	%bp, %bp
    73f1:      	je	0x7403 <generic_fentry_filter_arg+0x1303>
    73f3:      	movl	%ebp, %eax
    73f5:      	movl	$0x18, %ecx
    73fa:      	cltd
    73fb:      	idivl	%ecx
    73fd:      	movl	%ebp, %esi
    73ff:      	testl	%edx, %edx
    7401:      	je	0x7425 <generic_fentry_filter_arg+0x1325>
    7403:      	movl	%ebp, %eax
    7405:      	movl	$0x18, %ecx
    740a:      	cltd
    740b:      	idivl	%ecx
    740d:      	shll	$0x3, %eax
    7410:      	leal	(%rax,%rax,2), %eax
    7413:      	addl	$0x18, %eax
    7416:      	movzwl	%ax, %esi
    7419:      	cmpl	$0x90, %esi
    741f:      	ja	0x7aa3 <generic_fentry_filter_arg+0x19a3>
    7425:      	movl	%esi, %eax
    7427:      	cltd
    7428:      	idivl	%ecx
    742a:      	decl	%eax
    742c:      	jmp	0x7ab4 <generic_fentry_filter_arg+0x19b4>
    7431:      	movl	0x10(%r12), %esi
    7436:      	movl	0x14(%r12), %eax
    743b:      	cmpl	$0xc, %ecx
    743e:      	ja	0x8242 <generic_fentry_filter_arg+0x2142>
    7444:      	movl	$0x1402, %edx           # imm = 0x1402
    7449:      	btl	%ecx, %edx
    744c:      	jae	0x8242 <generic_fentry_filter_arg+0x2142>
    7452:      	movq	0x8(%rsp), %rdx
    7457:      	movl	(%rdx), %edx
    7459:      	cmpl	%edx, %esi
    745b:      	setle	%sil
    745f:      	cmpl	%eax, %edx
    7461:      	setle	%al
    7464:      	jmp	0x8254 <generic_fentry_filter_arg+0x2154>
    7469:      	cmpl	$0x12, %eax
    746c:      	je	0x7483 <generic_fentry_filter_arg+0x1383>
    746e:      	movl	$0x0, %ebx
    7473:      	cmpl	$0x13, %eax
    7476:      	jne	0x63b2 <generic_fentry_filter_arg+0x2b2>
    747c:      	movzwl	0x22(%rsi), %r13d
    7481:      	jmp	0x7488 <generic_fentry_filter_arg+0x1388>
    7483:      	movzwl	0x20(%rsi), %r13d
    7488:      	xorl	%edx, %edx
    748a:      	xorl	%ebp, %ebp
    748c:      	xorl	%r8d, %r8d
    748f:      	xorl	%ebx, %ebx
    7491:      	cmpl	$0x11, %eax
    7494:      	jg	0x750e <generic_fentry_filter_arg+0x140e>
    7496:      	leal	-0xd(%rax), %ecx
    7499:      	cmpl	$0x2, %ecx
    749c:      	jb	0x7541 <generic_fentry_filter_arg+0x1441>
    74a2:      	leal	-0xf(%rax), %ecx
    74a5:      	cmpl	$0x2, %ecx
    74a8:      	jb	0x76e4 <generic_fentry_filter_arg+0x15e4>
    74ae:      	cmpl	$0x11, %eax
    74b1:      	je	0x7cee <generic_fentry_filter_arg+0x1bee>
    74b7:      	jmp	0x63b2 <generic_fentry_filter_arg+0x2b2>
    74bc:      	cmpl	$0x1c, %eax
    74bf:      	je	0x7cea <generic_fentry_filter_arg+0x1bea>
    74c5:      	movl	$0x0, %ebx
    74ca:      	cmpl	$0x1d, %eax
    74cd:      	jne	0x63b2 <generic_fentry_filter_arg+0x2b2>
    74d3:      	cmpl	$0x7, %ecx
    74d6:      	jne	0x8332 <generic_fentry_filter_arg+0x2232>
    74dc:      	testq	%rdx, %rdx
    74df:      	jne	0x833e <generic_fentry_filter_arg+0x223e>
    74e5:      	xorl	%ebx, %ebx
    74e7:      	jmp	0x8350 <generic_fentry_filter_arg+0x2250>
    74ec:      	movq	0x10(%rsi), %rdx
    74f0:      	movq	0x18(%rsi), %r8
    74f4:      	jmp	0x74fd <generic_fentry_filter_arg+0x13fd>
    74f6:      	movq	(%rsi), %rdx
    74f9:      	movq	0x8(%rsi), %r8
    74fd:      	movq	%rdx, %rbp
    7500:      	shrq	$0x20, %rbp
    7504:      	xorl	%r13d, %r13d
    7507:      	xorl	%ebx, %ebx
    7509:      	cmpl	$0x11, %eax
    750c:      	jle	0x7496 <generic_fentry_filter_arg+0x1396>
    750e:      	cmpl	$0x19, %eax
    7511:      	ja	0x76d8 <generic_fentry_filter_arg+0x15d8>
    7517:      	movl	$0x500000, %ecx         # imm = 0x500000
    751c:      	btl	%eax, %ecx
    751f:      	jb	0x7a69 <generic_fentry_filter_arg+0x1969>
    7525:      	movl	$0xa00000, %ecx         # imm = 0xA00000
    752a:      	btl	%eax, %ecx
    752d:      	jb	0x7a7c <generic_fentry_filter_arg+0x197c>
    7533:      	movl	$0x3000000, %ecx        # imm = 0x3000000
    7538:      	btl	%eax, %ecx
    753b:      	jae	0x76d8 <generic_fentry_filter_arg+0x15d8>
    7541:      	movzwl	0x26(%rsi), %eax
    7545:      	cmpl	$0xa, %eax
    7548:      	je	0x7b96 <generic_fentry_filter_arg+0x1a96>
    754e:      	cmpl	$0x2, %eax
    7551:      	jne	0x7c37 <generic_fentry_filter_arg+0x1b37>
    7557:      	movq	%rdx, %r13
    755a:      	movq	%r11, 0x20(%rsp)
    755f:      	movl	0x10(%r12), %eax
    7564:      	movl	%eax, 0x34(%rsp)
    7568:      	movl	$0x1, %eax
    756d:      	leaq	0x34(%rsp), %rsi
    7572:      	movq	(%rip), %rdi            # 0x7579 <generic_fentry_filter_arg+0x1479>
    7579:      	callq	*%rax
    757b:      	testq	%rax, %rax
    757e:      	je	0x7e5b <generic_fentry_filter_arg+0x1d5b>
    7584:      	movq	%rax, %rdi
    7587:      	movl	$0x20, 0x80(%rsp)
    7592:      	movl	%r13d, 0x84(%rsp)
    759a:      	jmp	0x7bf5 <generic_fentry_filter_arg+0x1af5>
    759f:      	cmpl	$0xc, %ecx
    75a2:      	ja	0x83a5 <generic_fentry_filter_arg+0x22a5>
    75a8:      	movl	$0x1402, %esi           # imm = 0x1402
    75ad:      	btl	%ecx, %esi
    75b0:      	jae	0x83a5 <generic_fentry_filter_arg+0x22a5>
    75b6:      	movq	0x8(%rsp), %rsi
    75bb:      	cmpl	%edx, (%rsi)
    75bd:      	jg	0x63c8 <generic_fentry_filter_arg+0x2c8>
    75c3:      	jmp	0x83c1 <generic_fentry_filter_arg+0x22c1>
    75c8:      	movq	%rsi, 0x8(%rsp)
    75cd:      	xorl	%ebx, %ebx
    75cf:      	xorl	%r13d, %r13d
    75d2:      	movq	%r11, %r15
    75d5:      	movl	0x10(%r12,%rbx,4), %eax
    75da:      	movl	%eax, 0x40(%rsp)
    75de:      	movl	$0x1, %eax
    75e3:      	leaq	0x40(%rsp), %rsi
    75e8:      	movq	(%rip), %rdi            # 0x75ef <generic_fentry_filter_arg+0x14ef>
    75ef:      	callq	*%rax
    75f1:      	testq	%rax, %rax
    75f4:      	je	0x847f <generic_fentry_filter_arg+0x237f>
    75fa:      	testl	%ebp, %ebp
    75fc:      	movq	0x18(%rsp), %r9
    7601:      	movq	%r15, %r11
    7604:      	movq	0x68(%rsp), %r15
    7609:      	je	0x765f <generic_fentry_filter_arg+0x155f>
    760b:      	movq	0x8(%rsp), %rdx
    7610:      	xorl	%ecx, %ecx
    7612:      	jmp	0x761f <generic_fentry_filter_arg+0x151f>
    7614:      	incq	%rcx
    7617:      	incq	%rdx
    761a:      	cmpq	%rbp, %rcx
    761d:      	je	0x765f <generic_fentry_filter_arg+0x155f>
    761f:      	xorl	%esi, %esi
    7621:      	nopw	%cs:(%rax,%rax)
    7630:      	leaq	(%rcx,%rsi), %rdi
    7634:      	cmpq	%rbp, %rdi
    7637:      	jae	0x7614 <generic_fentry_filter_arg+0x1514>
    7639:      	movzbl	(%rax,%rsi), %edi
    763d:      	testb	%dil, %dil
    7640:      	je	0x7657 <generic_fentry_filter_arg+0x1557>
    7642:      	cmpq	$0x62, %rsi
    7646:      	ja	0x7614 <generic_fentry_filter_arg+0x1514>
    7648:      	leaq	0x1(%rsi), %r8
    764c:      	cmpb	%dil, (%rdx,%rsi)
    7650:      	movq	%r8, %rsi
    7653:      	je	0x7630 <generic_fentry_filter_arg+0x1530>
    7655:      	jmp	0x7614 <generic_fentry_filter_arg+0x1514>
    7657:      	testl	%ecx, %ecx
    7659:      	jns	0x8765 <generic_fentry_filter_arg+0x2665>
    765f:      	leal	0xc(%r13), %eax
    7663:      	cmpl	0x8(%r12), %eax
    7668:      	jae	0x767b <generic_fentry_filter_arg+0x157b>
    766a:      	addl	$0x4, %r13d
    766e:      	incq	%rbx
    7671:      	cmpq	$0x64, %rbx
    7675:      	jne	0x75d2 <generic_fentry_filter_arg+0x14d2>
    767b:      	xorl	%ebx, %ebx
    767d:      	jmp	0x876a <generic_fentry_filter_arg+0x266a>
    7682:      	movzwl	%bp, %eax
    7685:      	cmpl	$0x90, %eax
    768a:      	movq	%r11, 0x20(%rsp)
    768f:      	ja	0x7e6b <generic_fentry_filter_arg+0x1d6b>
    7695:      	testw	%bp, %bp
    7698:      	je	0x76aa <generic_fentry_filter_arg+0x15aa>
    769a:      	movl	%ebp, %eax
    769c:      	movl	$0x18, %ecx
    76a1:      	cltd
    76a2:      	idivl	%ecx
    76a4:      	movl	%ebp, %edi
    76a6:      	testl	%edx, %edx
    76a8:      	je	0x76cc <generic_fentry_filter_arg+0x15cc>
    76aa:      	movl	%ebp, %eax
    76ac:      	movl	$0x18, %ecx
    76b1:      	cltd
    76b2:      	idivl	%ecx
    76b4:      	shll	$0x3, %eax
    76b7:      	leal	(%rax,%rax,2), %eax
    76ba:      	addl	$0x18, %eax
    76bd:      	movzwl	%ax, %edi
    76c0:      	cmpl	$0x90, %edi
    76c6:      	ja	0x7e7f <generic_fentry_filter_arg+0x1d7f>
    76cc:      	movl	%edi, %eax
    76ce:      	cltd
    76cf:      	idivl	%ecx
    76d1:      	decl	%eax
    76d3:      	jmp	0x7e90 <generic_fentry_filter_arg+0x1d90>
    76d8:      	addl	$-0x12, %eax
    76db:      	cmpl	$0x2, %eax
    76de:      	jae	0x63b2 <generic_fentry_filter_arg+0x2b2>
    76e4:      	movq	%r11, %rbp
    76e7:      	movzbl	0x10(%r12), %eax
    76ed:      	movl	%eax, 0x34(%rsp)
    76f1:      	movl	$0x1, %eax
    76f6:      	movq	(%rip), %rdi            # 0x76fd <generic_fentry_filter_arg+0x15fd>
    76fd:      	leaq	0x34(%rsp), %rsi
    7702:      	callq	*%rax
    7704:      	testq	%rax, %rax
    7707:      	je	0x7a0a <generic_fentry_filter_arg+0x190a>
    770d:      	movq	%rax, %rdi
    7710:      	movzwl	%r13w, %eax
    7714:      	movq	%rax, 0x80(%rsp)
    771c:      	movl	$0x1, %eax
    7721:      	movq	0x38(%rsp), %rsi
    7726:      	callq	*%rax
    7728:      	movl	0x4(%r12), %edx
    772d:      	xorl	%ecx, %ecx
    772f:      	cmpl	$0x1d, %edx
    7732:      	ja	0x8da9 <generic_fentry_filter_arg+0x2ca9>
    7738:      	movl	$0x30038400, %esi       # imm = 0x30038400
    773d:      	btl	%edx, %esi
    7740:      	movq	0x10(%rsp), %rdi
    7745:      	movq	0x18(%rsp), %r9
    774a:      	movq	%rbp, %r11
    774d:      	jb	0x63a9 <generic_fentry_filter_arg+0x2a9>
    7753:      	jmp	0x7d5c <generic_fentry_filter_arg+0x1c5c>
    7758:      	cmpl	$0x21, %eax
    775b:      	je	0x8028 <generic_fentry_filter_arg+0x1f28>
    7761:      	movl	$0x0, %ebx
    7766:      	cmpl	$0x22, %eax
    7769:      	jne	0x9395 <generic_fentry_filter_arg+0x3295>
    776f:      	movl	$0x10, %r13d
    7775:      	movq	%r11, %r15
    7778:      	movl	(%r12,%r13), %eax
    777c:      	movl	%eax, 0x40(%rsp)
    7780:      	movl	$0x1, %eax
    7785:      	leaq	0x40(%rsp), %rsi
    778a:      	movq	(%rip), %rdi            # 0x7791 <generic_fentry_filter_arg+0x1691>
    7791:      	callq	*%rax
    7793:      	testq	%rax, %rax
    7796:      	je	0x8a92 <generic_fentry_filter_arg+0x2992>
    779c:      	movq	0x8(%rsp), %rdi
    77a1:      	movq	%rax, %rsi
    77a4:      	movq	%rbp, %rdx
    77a7:      	callq	0x77ac <generic_fentry_filter_arg+0x16ac>
    77ac:      	testl	%eax, %eax
    77ae:      	jns	0x8a96 <generic_fentry_filter_arg+0x2996>
    77b4:      	addq	$0x4, %r13
    77b8:      	leal	-0x8(%r13), %eax
    77bc:      	cmpl	0x8(%r12), %eax
    77c1:      	movq	0x10(%rsp), %rdi
    77c6:      	movq	0x18(%rsp), %r9
    77cb:      	movq	%r15, %r11
    77ce:      	jae	0x8b42 <generic_fentry_filter_arg+0x2a42>
    77d4:      	movl	$0x0, %ebx
    77d9:      	cmpq	$0x1a0, %r13            # imm = 0x1A0
    77e0:      	movq	0x68(%rsp), %r15
    77e5:      	jne	0x7775 <generic_fentry_filter_arg+0x1675>
    77e7:      	jmp	0x9395 <generic_fentry_filter_arg+0x3295>
    77ec:      	cmpl	$0x1, %eax
    77ef:      	je	0x812d <generic_fentry_filter_arg+0x202d>
    77f5:      	cmpl	$0x2, %eax
    77f8:      	jne	0x813d <generic_fentry_filter_arg+0x203d>
    77fe:      	movq	0x8(%rsp), %rdx
    7803:      	movzbl	(%rdx), %edx
    7806:      	cmpl	%edx, %ecx
    7808:      	ja	0x63c8 <generic_fentry_filter_arg+0x2c8>
    780e:      	jmp	0x813d <generic_fentry_filter_arg+0x203d>
    7813:      	cmpl	$0x1, %eax
    7816:      	je	0x817a <generic_fentry_filter_arg+0x207a>
    781c:      	cmpl	$0x2, %eax
    781f:      	jne	0x818a <generic_fentry_filter_arg+0x208a>
    7825:      	movq	0x8(%rsp), %rdx
    782a:      	movzwl	(%rdx), %edx
    782d:      	cmpl	%edx, %ecx
    782f:      	ja	0x63c8 <generic_fentry_filter_arg+0x2c8>
    7835:      	jmp	0x818a <generic_fentry_filter_arg+0x208a>
    783a:      	movq	%r11, %rbp
    783d:      	movzbl	0x10(%r12), %eax
    7843:      	movl	%eax, 0x80(%rsp)
    784a:      	movl	$0x1, %eax
    784f:      	movq	0x38(%rsp), %rsi
    7854:      	movq	(%rip), %rdi            # 0x785b <generic_fentry_filter_arg+0x175b>
    785b:      	callq	*%rax
    785d:      	testq	%rax, %rax
    7860:      	je	0x78fb <generic_fentry_filter_arg+0x17fb>
    7866:      	movq	%rax, %rdi
    7869:      	movq	0x8(%rsp), %rax
    786e:      	movzbl	(%rax), %eax
    7871:      	movq	%rax, 0x40(%rsp)
    7876:      	movl	$0x1, %eax
    787b:      	leaq	0x40(%rsp), %rsi
    7880:      	jmp	0x78c4 <generic_fentry_filter_arg+0x17c4>
    7882:      	movq	%r11, %rbp
    7885:      	movzbl	0x10(%r12), %eax
    788b:      	movl	%eax, 0x80(%rsp)
    7892:      	movl	$0x1, %eax
    7897:      	movq	0x38(%rsp), %rsi
    789c:      	movq	(%rip), %rdi            # 0x78a3 <generic_fentry_filter_arg+0x17a3>
    78a3:      	callq	*%rax
    78a5:      	testq	%rax, %rax
    78a8:      	je	0x78fb <generic_fentry_filter_arg+0x17fb>
    78aa:      	movq	%rax, %rdi
    78ad:      	movq	0x8(%rsp), %rax
    78b2:      	movzwl	(%rax), %eax
    78b5:      	movq	%rax, 0x40(%rsp)
    78ba:      	movl	$0x1, %eax
    78bf:      	leaq	0x40(%rsp), %rsi
    78c4:      	callq	*%rax
    78c6:      	movl	0x4(%r12), %edx
    78cb:      	xorl	%ecx, %ecx
    78cd:      	cmpl	$0x1d, %edx
    78d0:      	ja	0x89f3 <generic_fentry_filter_arg+0x28f3>
    78d6:      	movl	$0x30038400, %esi       # imm = 0x30038400
    78db:      	btl	%edx, %esi
    78de:      	movq	0x10(%rsp), %rdi
    78e3:      	movq	0x18(%rsp), %r9
    78e8:      	movq	%rbp, %r11
    78eb:      	jae	0x790f <generic_fentry_filter_arg+0x180f>
    78ed:      	testq	%rax, %rax
    78f0:      	setne	%cl
    78f3:      	movzbl	%cl, %ebx
    78f6:      	jmp	0x63b7 <generic_fentry_filter_arg+0x2b7>
    78fb:      	xorl	%ebx, %ebx
    78fd:      	movq	0x10(%rsp), %rdi
    7902:      	movq	0x18(%rsp), %r9
    7907:      	movq	%rbp, %r11
    790a:      	jmp	0x63b7 <generic_fentry_filter_arg+0x2b7>
    790f:      	movl	$0xc0800, %esi          # imm = 0xC0800
    7914:      	btl	%edx, %esi
    7917:      	jae	0x791f <generic_fentry_filter_arg+0x181f>
    7919:      	testq	%rax, %rax
    791c:      	sete	%cl
    791f:      	movzbl	%cl, %ebx
    7922:      	jmp	0x63b7 <generic_fentry_filter_arg+0x2b7>
    7927:      	testq	%rax, %rax
    792a:      	sete	%al
    792d:      	movq	0x10(%rsp), %rdi
    7932:      	movq	0x18(%rsp), %r9
    7937:      	movq	%rbp, %r11
    793a:      	movzbl	%al, %ebx
    793d:      	jmp	0x63b7 <generic_fentry_filter_arg+0x2b7>
    7942:      	xorl	%eax, %eax
    7944:      	movzbl	%al, %ebx
    7947:      	jmp	0x63b7 <generic_fentry_filter_arg+0x2b7>
    794c:      	movq	%r11, 0x20(%rsp)
    7951:      	movl	0x10(%r12), %eax
    7956:      	movl	%eax, 0x40(%rsp)
    795a:      	movl	$0x0, 0x80(%rsp)
    7965:      	movl	$0x1, %eax
    796a:      	leaq	0x40(%rsp), %rsi
    796f:      	movq	(%rip), %rdi            # 0x7976 <generic_fentry_filter_arg+0x1876>
    7976:      	callq	*%rax
    7978:      	testl	%ebp, %ebp
    797a:      	je	0x9384 <generic_fentry_filter_arg+0x3284>
    7980:      	movq	%rax, %r13
    7983:      	movl	$0x0, %ebx
    7988:      	testq	%rax, %rax
    798b:      	je	0x9386 <generic_fentry_filter_arg+0x3286>
    7991:      	movl	$0x1, %eax
    7996:      	movq	0x38(%rsp), %rsi
    799b:      	movq	(%rip), %rdi            # 0x79a2 <generic_fentry_filter_arg+0x18a2>
    79a2:      	callq	*%rax
    79a4:      	testq	%rax, %rax
    79a7:      	je	0x9384 <generic_fentry_filter_arg+0x3284>
    79ad:      	cmpl	$0xff, %ebp
    79b3:      	movl	$0xff, %ecx
    79b8:      	cmovael	%ecx, %ebp
    79bb:      	leal	(,%rbp,8), %ecx
    79c2:      	movl	%ecx, (%rax)
    79c4:      	movq	%rax, %rdi
    79c7:      	addq	$0x4, %rdi
    79cb:      	movq	%rax, %rbx
    79ce:      	movl	$0x4, %eax
    79d3:      	movq	0x8(%rsp), %rdx
    79d8:      	movl	%ebp, %esi
    79da:      	callq	*%rax
    79dc:      	movl	$0x1, %eax
    79e1:      	movq	%r13, %rdi
    79e4:      	movq	%rbx, %rsi
    79e7:      	jmp	0x9378 <generic_fentry_filter_arg+0x3278>
    79ec:      	movl	$0x0, 0x80(%rsp)
    79f7:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
    79fd:      	jbe	0x80d7 <generic_fentry_filter_arg+0x1fd7>
    7a03:      	xorl	%ebx, %ebx
    7a05:      	jmp	0x9395 <generic_fentry_filter_arg+0x3295>
    7a0a:      	xorl	%ebx, %ebx
    7a0c:      	movq	0x10(%rsp), %rdi
    7a11:      	movq	0x18(%rsp), %r9
    7a16:      	movq	%rbp, %r11
    7a19:      	jmp	0x63b2 <generic_fentry_filter_arg+0x2b2>
    7a1e:      	cmpl	$0x1e, %eax
    7a21:      	jne	0x620d <generic_fentry_filter_arg+0x10d>
    7a27:      	movl	0x10(%r12), %eax
    7a2c:      	andl	$0x7, %eax
    7a2f:      	movl	%eax, %ecx
    7a31:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    7a3a:      	jne	0x620d <generic_fentry_filter_arg+0x10d>
    7a40:      	movq	0x8(%rsp), %rcx
    7a45:      	movq	(%rcx), %rcx
    7a48:      	movq	0x5e78(%r14,%rax,8), %rax
    7a50:      	andl	$0x7ff, %eax            # imm = 0x7FF
    7a55:      	xorl	%ebx, %ebx
    7a57:      	andnq	0x90(%r14,%rax), %rcx, %rax
    7a61:      	setne	%bl
    7a64:      	jmp	0x63b7 <generic_fentry_filter_arg+0x2b7>
    7a69:      	movzwl	%r13w, %eax
    7a6d:      	xorl	%ebx, %ebx
    7a6f:      	cmpl	$0x400, %eax            # imm = 0x400
    7a74:      	setb	%bl
    7a77:      	jmp	0x63b2 <generic_fentry_filter_arg+0x2b2>
    7a7c:      	movzwl	%r13w, %eax
    7a80:      	xorl	%ebx, %ebx
    7a82:      	cmpl	$0x400, %eax            # imm = 0x400
    7a87:      	setae	%bl
    7a8a:      	jmp	0x63b2 <generic_fentry_filter_arg+0x2b2>
    7a8f:      	cmpl	$0x101, %eax            # imm = 0x101
    7a94:      	movl	$0x100, %esi            # imm = 0x100
    7a99:      	movl	$0x1fe, %eax            # imm = 0x1FE
    7a9e:      	cmovael	%eax, %esi
    7aa1:      	movl	%esi, %eax
    7aa3:      	movzwl	%ax, %ecx
    7aa6:      	xorl	%eax, %eax
    7aa8:      	cmpl	$0x100, %ecx            # imm = 0x100
    7aae:      	sete	%al
    7ab1:      	xorl	$0x7, %eax
    7ab4:      	movl	%eax, %ecx
    7ab6:      	andl	$0xf, %ecx
    7ab9:      	movl	0x10(%r12,%rcx,4), %ecx
    7abe:      	cmpl	$-0x1, %ecx
    7ac1:      	je	0x8ed9 <generic_fentry_filter_arg+0x2dd9>
    7ac7:      	movl	%ecx, 0xa0(%rsp)
    7ace:      	movq	%rsi, 0x98(%rsp)
    7ad6:      	movl	%eax, 0x70(%rsp)
    7ada:      	movl	$0x1, %eax
    7adf:      	movq	(%rip), %rdi            # 0x7ae6 <generic_fentry_filter_arg+0x19e6>
    7ae6:      	movq	0x38(%rsp), %rbx
    7aeb:      	movq	%rbx, %rsi
    7aee:      	callq	*%rax
    7af0:      	movq	%rax, 0x28(%rsp)
    7af5:      	movl	$0x1, %eax
    7afa:      	movq	(%rip), %rdi            # 0x7b01 <generic_fentry_filter_arg+0x1a01>
    7b01:      	movq	%rbx, %rsi
    7b04:      	callq	*%rax
    7b06:      	cmpq	$0x0, 0x28(%rsp)
    7b0c:      	je	0x8ed9 <generic_fentry_filter_arg+0x2dd9>
    7b12:      	movl	$0x0, %ebx
    7b17:      	testq	%rax, %rax
    7b1a:      	movq	0x10(%rsp), %rdi
    7b1f:      	movq	0x18(%rsp), %r9
    7b24:      	movq	0x20(%rsp), %r11
    7b29:      	je	0x8eea <generic_fentry_filter_arg+0x2dea>
    7b2f:      	movq	%rax, 0xa8(%rsp)
    7b37:      	movq	0x8(%rsp), %rdx
    7b3c:      	addq	$0x4, %rdx
    7b40:      	movl	0x70(%rsp), %ebx
    7b44:      	cmpl	$0x5, %ebx
    7b47:      	jg	0x84f0 <generic_fentry_filter_arg+0x23f0>
    7b4d:      	movq	0x28(%rsp), %rax
    7b52:      	movb	%bpl, (%rax)
    7b55:      	leaq	0x1(%rax), %rdi
    7b59:      	movl	$0x4, %eax
    7b5e:      	movl	%ebp, %esi
    7b60:      	callq	*%rax
    7b62:      	movq	0x98(%rsp), %rsi
    7b6a:      	subl	%ebp, %esi
    7b6c:      	jbe	0x8533 <generic_fentry_filter_arg+0x2433>
    7b72:      	movq	0x28(%rsp), %rax
    7b77:      	leaq	(%rax,%rbp), %rdi
    7b7b:      	incq	%rdi
    7b7e:      	andl	$0xfff, %esi            # imm = 0xFFF
    7b84:      	movl	$0x4, %eax
    7b89:      	movq	0xa8(%rsp), %rdx
    7b91:      	jmp	0x8531 <generic_fentry_filter_arg+0x2431>
    7b96:      	movq	%r8, %rbx
    7b99:      	movq	%rdx, %r13
    7b9c:      	movq	%r11, 0x20(%rsp)
    7ba1:      	movl	0x14(%r12), %eax
    7ba6:      	movl	%eax, 0x34(%rsp)
    7baa:      	movl	$0x1, %eax
    7baf:      	movq	(%rip), %rdi            # 0x7bb6 <generic_fentry_filter_arg+0x1ab6>
    7bb6:      	leaq	0x34(%rsp), %rsi
    7bbb:      	callq	*%rax
    7bbd:      	testq	%rax, %rax
    7bc0:      	je	0x7e5b <generic_fentry_filter_arg+0x1d5b>
    7bc6:      	movq	%rax, %rdi
    7bc9:      	movl	$0x80, 0x80(%rsp)
    7bd4:      	movl	%r13d, 0x84(%rsp)
    7bdc:      	movl	%ebp, 0x88(%rsp)
    7be3:      	movl	%ebx, 0x8c(%rsp)
    7bea:      	shrq	$0x20, %rbx
    7bee:      	movl	%ebx, 0x90(%rsp)
    7bf5:      	movl	$0x1, %eax
    7bfa:      	movq	0x38(%rsp), %rsi
    7bff:      	callq	*%rax
    7c01:      	movl	0x4(%r12), %ecx
    7c06:      	leal	-0x18(%rcx), %edx
    7c09:      	cmpl	$0x2, %edx
    7c0c:      	jb	0x81c7 <generic_fentry_filter_arg+0x20c7>
    7c12:      	addl	$-0xd, %ecx
    7c15:      	cmpl	$0x1, %ecx
    7c18:      	movq	0x10(%rsp), %rdi
    7c1d:      	movq	0x18(%rsp), %r9
    7c22:      	movq	0x20(%rsp), %r11
    7c27:      	ja	0x7c37 <generic_fentry_filter_arg+0x1b37>
    7c29:      	testq	%rax, %rax
    7c2c:      	setne	%al
    7c2f:      	movzbl	%al, %ebx
    7c32:      	jmp	0x63b2 <generic_fentry_filter_arg+0x2b2>
    7c37:      	xorl	%eax, %eax
    7c39:      	movzbl	%al, %ebx
    7c3c:      	jmp	0x63b2 <generic_fentry_filter_arg+0x2b2>
    7c41:      	movq	0x8(%rsp), %rax
    7c46:      	movq	(%rax), %rax
    7c49:      	cmpq	%rax, %rsi
    7c4c:      	ja	0x7c57 <generic_fentry_filter_arg+0x1b57>
    7c4e:      	cmpq	%rdx, %rax
    7c51:      	jbe	0x63c8 <generic_fentry_filter_arg+0x2c8>
    7c57:      	movl	0x8(%r12), %edx
    7c5c:      	cmpl	$0x19, %edx
    7c5f:      	jb	0x620d <generic_fentry_filter_arg+0x10d>
    7c65:      	movq	0x20(%r12), %rdi
    7c6a:      	movq	0x28(%r12), %rsi
    7c6f:      	cmpl	$0xc, %ecx
    7c72:      	je	0x7c7d <generic_fentry_filter_arg+0x1b7d>
    7c74:      	cmpl	$0xa, %ecx
    7c77:      	jne	0x82e2 <generic_fentry_filter_arg+0x21e2>
    7c7d:      	cmpq	%rax, %rdi
    7c80:      	movq	0x10(%rsp), %rdi
    7c85:      	jg	0x82f5 <generic_fentry_filter_arg+0x21f5>
    7c8b:      	cmpq	%rsi, %rax
    7c8e:      	jle	0x63c8 <generic_fentry_filter_arg+0x2c8>
    7c94:      	jmp	0x82f5 <generic_fentry_filter_arg+0x21f5>
    7c99:      	movq	0x8(%rsp), %rdx
    7c9e:      	movq	(%rdx), %rdx
    7ca1:      	cmpq	%rdx, %rsi
    7ca4:      	setbe	%sil
    7ca8:      	cmpq	%rax, %rdx
    7cab:      	setbe	%al
    7cae:      	andb	%sil, %al
    7cb1:      	movl	0x8(%r12), %esi
    7cb6:      	cmpl	$0x19, %esi
    7cb9:      	jb	0x8f29 <generic_fentry_filter_arg+0x2e29>
    7cbf:      	movq	0x20(%r12), %r8
    7cc4:      	movq	0x28(%r12), %rdi
    7cc9:      	cmpl	$0xc, %ecx
    7ccc:      	je	0x7cd7 <generic_fentry_filter_arg+0x1bd7>
    7cce:      	cmpl	$0xa, %ecx
    7cd1:      	jne	0x829a <generic_fentry_filter_arg+0x219a>
    7cd7:      	cmpq	%rdx, %r8
    7cda:      	setle	%r8b
    7cde:      	cmpq	%rdi, %rdx
    7ce1:      	setle	%dil
    7ce5:      	jmp	0x82a8 <generic_fentry_filter_arg+0x21a8>
    7cea:      	movzwl	0x26(%rsi), %ebx
    7cee:      	movq	%r11, %r13
    7cf1:      	movzbl	0x10(%r12), %eax
    7cf7:      	movl	%eax, 0x34(%rsp)
    7cfb:      	movl	$0x1, %eax
    7d00:      	movq	(%rip), %rdi            # 0x7d07 <generic_fentry_filter_arg+0x1c07>
    7d07:      	leaq	0x34(%rsp), %rsi
    7d0c:      	callq	*%rax
    7d0e:      	testq	%rax, %rax
    7d11:      	je	0x8391 <generic_fentry_filter_arg+0x2291>
    7d17:      	movq	%rax, %rdi
    7d1a:      	movzwl	%bx, %eax
    7d1d:      	movq	%rax, 0x80(%rsp)
    7d25:      	movl	$0x1, %eax
    7d2a:      	movq	0x38(%rsp), %rsi
    7d2f:      	callq	*%rax
    7d31:      	movl	0x4(%r12), %edx
    7d36:      	xorl	%ecx, %ecx
    7d38:      	cmpl	$0x1d, %edx
    7d3b:      	ja	0x8d3a <generic_fentry_filter_arg+0x2c3a>
    7d41:      	movl	$0x30038400, %esi       # imm = 0x30038400
    7d46:      	btl	%edx, %esi
    7d49:      	movq	0x10(%rsp), %rdi
    7d4e:      	movq	0x18(%rsp), %r9
    7d53:      	movq	%r13, %r11
    7d56:      	jb	0x63a9 <generic_fentry_filter_arg+0x2a9>
    7d5c:      	movl	$0xc0800, %esi          # imm = 0xC0800
    7d61:      	btl	%edx, %esi
    7d64:      	jae	0x63af <generic_fentry_filter_arg+0x2af>
    7d6a:      	testq	%rax, %rax
    7d6d:      	sete	%cl
    7d70:      	jmp	0x63af <generic_fentry_filter_arg+0x2af>
    7d75:      	movq	0x8(%rsp), %rsi
    7d7a:      	cmpq	%rdx, (%rsi)
    7d7d:      	ja	0x63c8 <generic_fentry_filter_arg+0x2c8>
    7d83:      	jmp	0x7d93 <generic_fentry_filter_arg+0x1c93>
    7d85:      	movq	0x8(%rsp), %rsi
    7d8a:      	cmpq	%rdx, (%rsi)
    7d8d:      	jb	0x63c8 <generic_fentry_filter_arg+0x2c8>
    7d93:      	movl	0x8(%r12), %edx
    7d98:      	cmpl	$0x11, %edx
    7d9b:      	jb	0x944a <generic_fentry_filter_arg+0x334a>
    7da1:      	movq	0x18(%r12), %rsi
    7da6:      	cmpl	$0x2, %eax
    7da9:      	jle	0x7dcb <generic_fentry_filter_arg+0x1ccb>
    7dab:      	leal	-0x3(%rax), %edi
    7dae:      	cmpl	$0x2, %edi
    7db1:      	jae	0x7dfe <generic_fentry_filter_arg+0x1cfe>
    7db3:      	movq	0x8(%rsp), %rdi
    7db8:      	cmpq	%rsi, (%rdi)
    7dbb:      	movq	0x10(%rsp), %rdi
    7dc0:      	jne	0x8930 <generic_fentry_filter_arg+0x2830>
    7dc6:      	jmp	0x9321 <generic_fentry_filter_arg+0x3221>
    7dcb:      	cmpl	$0x1, %eax
    7dce:      	je	0x7f73 <generic_fentry_filter_arg+0x1e73>
    7dd4:      	cmpl	$0x2, %eax
    7dd7:      	jne	0x8930 <generic_fentry_filter_arg+0x2830>
    7ddd:      	cmpl	$0xc, %ecx
    7de0:      	je	0x7deb <generic_fentry_filter_arg+0x1ceb>
    7de2:      	cmpl	$0xa, %ecx
    7de5:      	jne	0x8922 <generic_fentry_filter_arg+0x2822>
    7deb:      	movq	0x8(%rsp), %r8
    7df0:      	cmpq	%rsi, (%r8)
    7df3:      	jl	0x63c8 <generic_fentry_filter_arg+0x2c8>
    7df9:      	jmp	0x8930 <generic_fentry_filter_arg+0x2830>
    7dfe:      	cmpl	$0xc, %eax
    7e01:      	movq	0x10(%rsp), %rdi
    7e06:      	jne	0x8930 <generic_fentry_filter_arg+0x2830>
    7e0c:      	movq	0x8(%rsp), %r8
    7e11:      	testq	%rsi, (%r8)
    7e14:      	jne	0x63c8 <generic_fentry_filter_arg+0x2c8>
    7e1a:      	jmp	0x8930 <generic_fentry_filter_arg+0x2830>
    7e1f:      	cmpl	$0xc, %eax
    7e22:      	jne	0x813d <generic_fentry_filter_arg+0x203d>
    7e28:      	movq	0x8(%rsp), %rdx
    7e2d:      	movzbl	(%rdx), %edx
    7e30:      	testl	%edx, %ecx
    7e32:      	jne	0x63c8 <generic_fentry_filter_arg+0x2c8>
    7e38:      	jmp	0x813d <generic_fentry_filter_arg+0x203d>
    7e3d:      	cmpl	$0xc, %eax
    7e40:      	jne	0x818a <generic_fentry_filter_arg+0x208a>
    7e46:      	movq	0x8(%rsp), %rdx
    7e4b:      	movzwl	(%rdx), %edx
    7e4e:      	testl	%edx, %ecx
    7e50:      	jne	0x63c8 <generic_fentry_filter_arg+0x2c8>
    7e56:      	jmp	0x818a <generic_fentry_filter_arg+0x208a>
    7e5b:      	movl	0x4(%r12), %eax
    7e60:      	andl	$-0x2, %eax
    7e63:      	cmpl	$0x18, %eax
    7e66:      	jmp	0x81ca <generic_fentry_filter_arg+0x20ca>
    7e6b:      	cmpl	$0x101, %eax            # imm = 0x101
    7e70:      	movl	$0x100, %edi            # imm = 0x100
    7e75:      	movl	$0x1fe, %eax            # imm = 0x1FE
    7e7a:      	cmovael	%eax, %edi
    7e7d:      	movl	%edi, %eax
    7e7f:      	movzwl	%ax, %ecx
    7e82:      	xorl	%eax, %eax
    7e84:      	cmpl	$0x100, %ecx            # imm = 0x100
    7e8a:      	sete	%al
    7e8d:      	xorl	$0x7, %eax
    7e90:      	movl	%eax, %ecx
    7e92:      	andl	$0xf, %ecx
    7e95:      	movl	0x10(%r12,%rcx,4), %ecx
    7e9a:      	cmpl	$-0x1, %ecx
    7e9d:      	je	0x90b6 <generic_fentry_filter_arg+0x2fb6>
    7ea3:      	movl	%ecx, 0xa0(%rsp)
    7eaa:      	movq	%rdi, 0x98(%rsp)
    7eb2:      	movl	%eax, 0x70(%rsp)
    7eb6:      	movq	%rsi, 0x8(%rsp)
    7ebb:      	movl	$0x1, %eax
    7ec0:      	movq	(%rip), %rdi            # 0x7ec7 <generic_fentry_filter_arg+0x1dc7>
    7ec7:      	movq	0x38(%rsp), %rbx
    7ecc:      	movq	%rbx, %rsi
    7ecf:      	callq	*%rax
    7ed1:      	movq	%rax, 0x28(%rsp)
    7ed6:      	movl	$0x1, %eax
    7edb:      	movq	(%rip), %rdi            # 0x7ee2 <generic_fentry_filter_arg+0x1de2>
    7ee2:      	movq	%rbx, %rsi
    7ee5:      	callq	*%rax
    7ee7:      	cmpq	$0x0, 0x28(%rsp)
    7eed:      	je	0x90b6 <generic_fentry_filter_arg+0x2fb6>
    7ef3:      	movl	$0x0, %ebx
    7ef8:      	testq	%rax, %rax
    7efb:      	movq	0x10(%rsp), %rdi
    7f00:      	movq	0x18(%rsp), %r9
    7f05:      	movq	0x20(%rsp), %r11
    7f0a:      	je	0x90c7 <generic_fentry_filter_arg+0x2fc7>
    7f10:      	movq	%rax, 0xa8(%rsp)
    7f18:      	movl	0x70(%rsp), %ebx
    7f1c:      	cmpl	$0x5, %ebx
    7f1f:      	jg	0x87fa <generic_fentry_filter_arg+0x26fa>
    7f25:      	movq	0x28(%rsp), %rax
    7f2a:      	movb	%bpl, (%rax)
    7f2d:      	leaq	0x1(%rax), %rdi
    7f31:      	movl	$0x4, %eax
    7f36:      	movq	0x8(%rsp), %rdx
    7f3b:      	movl	%ebp, %esi
    7f3d:      	callq	*%rax
    7f3f:      	movq	0x98(%rsp), %rsi
    7f47:      	subl	%ebp, %esi
    7f49:      	jbe	0x8842 <generic_fentry_filter_arg+0x2742>
    7f4f:      	movq	0x28(%rsp), %rax
    7f54:      	leaq	(%rax,%rbp), %rdi
    7f58:      	incq	%rdi
    7f5b:      	andl	$0xfff, %esi            # imm = 0xFFF
    7f61:      	movl	$0x4, %eax
    7f66:      	movq	0xa8(%rsp), %rdx
    7f6e:      	jmp	0x8840 <generic_fentry_filter_arg+0x2740>
    7f73:      	cmpl	$0xc, %ecx
    7f76:      	je	0x7f81 <generic_fentry_filter_arg+0x1e81>
    7f78:      	cmpl	$0xa, %ecx
    7f7b:      	jne	0x8912 <generic_fentry_filter_arg+0x2812>
    7f81:      	movq	0x8(%rsp), %r8
    7f86:      	cmpq	%rsi, (%r8)
    7f89:      	jg	0x63c8 <generic_fentry_filter_arg+0x2c8>
    7f8f:      	jmp	0x8930 <generic_fentry_filter_arg+0x2830>
    7f94:      	movl	0x8(%r12), %edx
    7f99:      	movq	0x8(%rsp), %rax
    7f9e:      	movzbl	(%rax), %ecx
    7fa1:      	jmp	0x7fb0 <generic_fentry_filter_arg+0x1eb0>
    7fa3:      	movl	0x8(%r12), %edx
    7fa8:      	movq	0x8(%rsp), %rax
    7fad:      	movzwl	(%rax), %ecx
    7fb0:      	cmpl	%ecx, 0x10(%r12)
    7fb5:      	setbe	%sil
    7fb9:      	cmpl	%ecx, 0x14(%r12)
    7fbe:      	setae	%al
    7fc1:      	andb	%sil, %al
    7fc4:      	cmpl	$0x11, %edx
    7fc7:      	jb	0x8f29 <generic_fentry_filter_arg+0x2e29>
    7fcd:      	cmpl	%ecx, 0x18(%r12)
    7fd2:      	setbe	%sil
    7fd6:      	cmpl	%ecx, 0x1c(%r12)
    7fdb:      	setae	%dil
    7fdf:      	andb	%sil, %dil
    7fe2:      	orb	%dil, %al
    7fe5:      	cmpl	$0x19, %edx
    7fe8:      	jb	0x8f24 <generic_fentry_filter_arg+0x2e24>
    7fee:      	cmpl	%ecx, 0x20(%r12)
    7ff3:      	setbe	%sil
    7ff7:      	cmpl	%ecx, 0x24(%r12)
    7ffc:      	setae	%dil
    8000:      	andb	%sil, %dil
    8003:      	orb	%dil, %al
    8006:      	cmpl	$0x21, %edx
    8009:      	jb	0x8f24 <generic_fentry_filter_arg+0x2e24>
    800f:      	cmpl	%ecx, 0x28(%r12)
    8014:      	setbe	%dl
    8017:      	cmpl	%ecx, 0x2c(%r12)
    801c:      	setae	%cl
    801f:      	andb	%dl, %cl
    8021:      	orb	%cl, %al
    8023:      	jmp	0x8f24 <generic_fentry_filter_arg+0x2e24>
    8028:      	xorl	%ebx, %ebx
    802a:      	xorl	%r13d, %r13d
    802d:      	movq	%r11, %r15
    8030:      	movl	0x10(%r12,%rbx,4), %eax
    8035:      	movl	%eax, 0x40(%rsp)
    8039:      	movl	$0x1, %eax
    803e:      	leaq	0x40(%rsp), %rsi
    8043:      	movq	(%rip), %rdi            # 0x804a <generic_fentry_filter_arg+0x1f4a>
    804a:      	callq	*%rax
    804c:      	testq	%rax, %rax
    804f:      	je	0x8a29 <generic_fentry_filter_arg+0x2929>
    8055:      	testl	%ebp, %ebp
    8057:      	movq	0x18(%rsp), %r9
    805c:      	movq	%r15, %r11
    805f:      	movq	0x68(%rsp), %r15
    8064:      	je	0x80af <generic_fentry_filter_arg+0x1faf>
    8066:      	movq	0x8(%rsp), %rdx
    806b:      	xorl	%ecx, %ecx
    806d:      	jmp	0x807a <generic_fentry_filter_arg+0x1f7a>
    806f:      	incq	%rcx
    8072:      	incq	%rdx
    8075:      	cmpq	%rbp, %rcx
    8078:      	je	0x80af <generic_fentry_filter_arg+0x1faf>
    807a:      	xorl	%esi, %esi
    807c:      	nopl	(%rax)
    8080:      	leaq	(%rcx,%rsi), %rdi
    8084:      	cmpq	%rbp, %rdi
    8087:      	jae	0x806f <generic_fentry_filter_arg+0x1f6f>
    8089:      	movzbl	(%rax,%rsi), %edi
    808d:      	testb	%dil, %dil
    8090:      	je	0x80a7 <generic_fentry_filter_arg+0x1fa7>
    8092:      	cmpq	$0x62, %rsi
    8096:      	ja	0x806f <generic_fentry_filter_arg+0x1f6f>
    8098:      	leaq	0x1(%rsi), %r8
    809c:      	cmpb	%dil, (%rdx,%rsi)
    80a0:      	movq	%r8, %rsi
    80a3:      	je	0x8080 <generic_fentry_filter_arg+0x1f80>
    80a5:      	jmp	0x806f <generic_fentry_filter_arg+0x1f6f>
    80a7:      	testl	%ecx, %ecx
    80a9:      	jns	0x8d9a <generic_fentry_filter_arg+0x2c9a>
    80af:      	leal	0xc(%r13), %eax
    80b3:      	cmpl	0x8(%r12), %eax
    80b8:      	jae	0x80cb <generic_fentry_filter_arg+0x1fcb>
    80ba:      	addl	$0x4, %r13d
    80be:      	incq	%rbx
    80c1:      	cmpq	$0x64, %rbx
    80c5:      	jne	0x802d <generic_fentry_filter_arg+0x1f2d>
    80cb:      	xorl	%ebx, %ebx
    80cd:      	movq	0x10(%rsp), %rdi
    80d2:      	jmp	0x9395 <generic_fentry_filter_arg+0x3295>
    80d7:      	movzwl	%bp, %eax
    80da:      	cmpl	$0x90, %eax
    80df:      	movq	%r11, 0x20(%rsp)
    80e4:      	ja	0x85c2 <generic_fentry_filter_arg+0x24c2>
    80ea:      	testw	%bp, %bp
    80ed:      	je	0x80ff <generic_fentry_filter_arg+0x1fff>
    80ef:      	movl	%ebp, %eax
    80f1:      	movl	$0x18, %ecx
    80f6:      	cltd
    80f7:      	idivl	%ecx
    80f9:      	movl	%ebp, %edi
    80fb:      	testl	%edx, %edx
    80fd:      	je	0x8121 <generic_fentry_filter_arg+0x2021>
    80ff:      	movl	%ebp, %eax
    8101:      	movl	$0x18, %ecx
    8106:      	cltd
    8107:      	idivl	%ecx
    8109:      	shll	$0x3, %eax
    810c:      	leal	(%rax,%rax,2), %eax
    810f:      	addl	$0x18, %eax
    8112:      	movzwl	%ax, %edi
    8115:      	cmpl	$0x90, %edi
    811b:      	ja	0x85d6 <generic_fentry_filter_arg+0x24d6>
    8121:      	movl	%edi, %eax
    8123:      	cltd
    8124:      	idivl	%ecx
    8126:      	decl	%eax
    8128:      	jmp	0x85e7 <generic_fentry_filter_arg+0x24e7>
    812d:      	movq	0x8(%rsp), %rdx
    8132:      	movzbl	(%rdx), %edx
    8135:      	cmpl	%edx, %ecx
    8137:      	jb	0x63c8 <generic_fentry_filter_arg+0x2c8>
    813d:      	movl	0x8(%r12), %ecx
    8142:      	cmpl	$0xd, %ecx
    8145:      	jb	0x944a <generic_fentry_filter_arg+0x334a>
    814b:      	movl	0x14(%r12), %edx
    8150:      	cmpl	$0x2, %eax
    8153:      	jle	0x84a2 <generic_fentry_filter_arg+0x23a2>
    8159:      	leal	-0x3(%rax), %esi
    815c:      	cmpl	$0x2, %esi
    815f:      	jae	0x89b7 <generic_fentry_filter_arg+0x28b7>
    8165:      	movq	0x8(%rsp), %rsi
    816a:      	movzbl	(%rsi), %esi
    816d:      	cmpl	%esi, %edx
    816f:      	jne	0x8ac2 <generic_fentry_filter_arg+0x29c2>
    8175:      	jmp	0x9321 <generic_fentry_filter_arg+0x3221>
    817a:      	movq	0x8(%rsp), %rdx
    817f:      	movzwl	(%rdx), %edx
    8182:      	cmpl	%edx, %ecx
    8184:      	jb	0x63c8 <generic_fentry_filter_arg+0x2c8>
    818a:      	movl	0x8(%r12), %ecx
    818f:      	cmpl	$0xd, %ecx
    8192:      	jb	0x944a <generic_fentry_filter_arg+0x334a>
    8198:      	movl	0x14(%r12), %edx
    819d:      	cmpl	$0x2, %eax
    81a0:      	jle	0x84c9 <generic_fentry_filter_arg+0x23c9>
    81a6:      	leal	-0x3(%rax), %esi
    81a9:      	cmpl	$0x2, %esi
    81ac:      	jae	0x89d5 <generic_fentry_filter_arg+0x28d5>
    81b2:      	movq	0x8(%rsp), %rsi
    81b7:      	movzwl	(%rsi), %esi
    81ba:      	cmpl	%esi, %edx
    81bc:      	jne	0x8b0a <generic_fentry_filter_arg+0x2a0a>
    81c2:      	jmp	0x9321 <generic_fentry_filter_arg+0x3221>
    81c7:      	testq	%rax, %rax
    81ca:      	sete	%al
    81cd:      	movq	0x10(%rsp), %rdi
    81d2:      	movq	0x18(%rsp), %r9
    81d7:      	movq	0x20(%rsp), %r11
    81dc:      	movzbl	%al, %ebx
    81df:      	jmp	0x63b2 <generic_fentry_filter_arg+0x2b2>
    81e4:      	movq	0x8(%rsp), %rax
    81e9:      	movl	(%rax), %eax
    81eb:      	cmpl	%eax, %esi
    81ed:      	ja	0x81f7 <generic_fentry_filter_arg+0x20f7>
    81ef:      	cmpl	%edx, %eax
    81f1:      	jbe	0x63c8 <generic_fentry_filter_arg+0x2c8>
    81f7:      	movl	0x8(%r12), %edx
    81fc:      	cmpl	$0x11, %edx
    81ff:      	jb	0x620d <generic_fentry_filter_arg+0x10d>
    8205:      	movl	0x18(%r12), %edi
    820a:      	movl	0x1c(%r12), %esi
    820f:      	cmpl	$0xc, %ecx
    8212:      	ja	0x870e <generic_fentry_filter_arg+0x260e>
    8218:      	movl	$0x1402, %r8d           # imm = 0x1402
    821e:      	btl	%ecx, %r8d
    8222:      	jae	0x870e <generic_fentry_filter_arg+0x260e>
    8228:      	cmpl	%eax, %edi
    822a:      	movq	0x10(%rsp), %rdi
    822f:      	jg	0x871f <generic_fentry_filter_arg+0x261f>
    8235:      	cmpl	%esi, %eax
    8237:      	jle	0x63c8 <generic_fentry_filter_arg+0x2c8>
    823d:      	jmp	0x871f <generic_fentry_filter_arg+0x261f>
    8242:      	movq	0x8(%rsp), %rdx
    8247:      	movl	(%rdx), %edx
    8249:      	cmpl	%edx, %esi
    824b:      	setbe	%sil
    824f:      	cmpl	%eax, %edx
    8251:      	setbe	%al
    8254:      	andb	%sil, %al
    8257:      	movl	0x8(%r12), %esi
    825c:      	cmpl	$0x11, %esi
    825f:      	jb	0x8f29 <generic_fentry_filter_arg+0x2e29>
    8265:      	movl	0x18(%r12), %r8d
    826a:      	movl	0x1c(%r12), %edi
    826f:      	cmpl	$0xc, %ecx
    8272:      	ja	0x86bd <generic_fentry_filter_arg+0x25bd>
    8278:      	movl	$0x1402, %r10d          # imm = 0x1402
    827e:      	btl	%ecx, %r10d
    8282:      	jae	0x86bd <generic_fentry_filter_arg+0x25bd>
    8288:      	cmpl	%edx, %r8d
    828b:      	setle	%r8b
    828f:      	cmpl	%edi, %edx
    8291:      	setle	%dil
    8295:      	jmp	0x86ca <generic_fentry_filter_arg+0x25ca>
    829a:      	cmpq	%rdx, %r8
    829d:      	setbe	%r8b
    82a1:      	cmpq	%rdi, %rdx
    82a4:      	setbe	%dil
    82a8:      	andb	%r8b, %dil
    82ab:      	orb	%dil, %al
    82ae:      	cmpl	$0x29, %esi
    82b1:      	jb	0x8f24 <generic_fentry_filter_arg+0x2e24>
    82b7:      	movq	0x30(%r12), %r8
    82bc:      	movq	0x38(%r12), %rdi
    82c1:      	cmpl	$0xc, %ecx
    82c4:      	je	0x82cf <generic_fentry_filter_arg+0x21cf>
    82c6:      	cmpl	$0xa, %ecx
    82c9:      	jne	0x87b0 <generic_fentry_filter_arg+0x26b0>
    82cf:      	cmpq	%rdx, %r8
    82d2:      	setle	%r8b
    82d6:      	cmpq	%rdi, %rdx
    82d9:      	setle	%dil
    82dd:      	jmp	0x87be <generic_fentry_filter_arg+0x26be>
    82e2:      	cmpq	%rax, %rdi
    82e5:      	movq	0x10(%rsp), %rdi
    82ea:      	ja	0x82f5 <generic_fentry_filter_arg+0x21f5>
    82ec:      	cmpq	%rsi, %rax
    82ef:      	jbe	0x63c8 <generic_fentry_filter_arg+0x2c8>
    82f5:      	cmpl	$0x29, %edx
    82f8:      	jb	0x620d <generic_fentry_filter_arg+0x10d>
    82fe:      	movq	0x30(%r12), %rdi
    8303:      	movq	0x38(%r12), %rsi
    8308:      	cmpl	$0xc, %ecx
    830b:      	je	0x8316 <generic_fentry_filter_arg+0x2216>
    830d:      	cmpl	$0xa, %ecx
    8310:      	jne	0x88c7 <generic_fentry_filter_arg+0x27c7>
    8316:      	cmpq	%rax, %rdi
    8319:      	movq	0x10(%rsp), %rdi
    831e:      	jg	0x88da <generic_fentry_filter_arg+0x27da>
    8324:      	cmpq	%rsi, %rax
    8327:      	jle	0x63c8 <generic_fentry_filter_arg+0x2c8>
    832d:      	jmp	0x88da <generic_fentry_filter_arg+0x27da>
    8332:      	xorl	%ebx, %ebx
    8334:      	cmpl	$0x29, %ecx
    8337:      	jne	0x8342 <generic_fentry_filter_arg+0x2242>
    8339:      	testq	%rdx, %rdx
    833c:      	je	0x8342 <generic_fentry_filter_arg+0x2242>
    833e:      	movzbl	0x3a(%rdx), %ebx
    8342:      	cmpl	$0x29, %ecx
    8345:      	je	0x8350 <generic_fentry_filter_arg+0x2250>
    8347:      	cmpl	$0x7, %ecx
    834a:      	jne	0x87f3 <generic_fentry_filter_arg+0x26f3>
    8350:      	movq	%r11, %r13
    8353:      	movzbl	0x10(%r12), %eax
    8359:      	movl	%eax, 0x34(%rsp)
    835d:      	movl	$0x1, %eax
    8362:      	movq	(%rip), %rdi            # 0x8369 <generic_fentry_filter_arg+0x2269>
    8369:      	leaq	0x34(%rsp), %rsi
    836e:      	callq	*%rax
    8370:      	testq	%rax, %rax
    8373:      	je	0x8391 <generic_fentry_filter_arg+0x2291>
    8375:      	movq	%rax, %rdi
    8378:      	movl	%ebx, %eax
    837a:      	movq	%rax, 0x80(%rsp)
    8382:      	movl	$0x1, %eax
    8387:      	movq	0x38(%rsp), %rsi
    838c:      	jmp	0x7d2f <generic_fentry_filter_arg+0x1c2f>
    8391:      	xorl	%ebx, %ebx
    8393:      	movq	0x10(%rsp), %rdi
    8398:      	movq	0x18(%rsp), %r9
    839d:      	movq	%r13, %r11
    83a0:      	jmp	0x63b2 <generic_fentry_filter_arg+0x2b2>
    83a5:      	movq	0x8(%rsp), %rsi
    83aa:      	cmpl	%edx, (%rsi)
    83ac:      	ja	0x63c8 <generic_fentry_filter_arg+0x2c8>
    83b2:      	jmp	0x83c1 <generic_fentry_filter_arg+0x22c1>
    83b4:      	movq	0x8(%rsp), %rsi
    83b9:      	cmpl	%edx, (%rsi)
    83bb:      	jb	0x63c8 <generic_fentry_filter_arg+0x2c8>
    83c1:      	movl	0x8(%r12), %edx
    83c6:      	cmpl	$0xd, %edx
    83c9:      	jb	0x944a <generic_fentry_filter_arg+0x334a>
    83cf:      	movl	0x14(%r12), %esi
    83d4:      	cmpl	$0x2, %eax
    83d7:      	jle	0x83f8 <generic_fentry_filter_arg+0x22f8>
    83d9:      	leal	-0x3(%rax), %edi
    83dc:      	cmpl	$0x2, %edi
    83df:      	jae	0x8432 <generic_fentry_filter_arg+0x2332>
    83e1:      	movq	0x8(%rsp), %rdi
    83e6:      	cmpl	%esi, (%rdi)
    83e8:      	movq	0x10(%rsp), %rdi
    83ed:      	jne	0x8c0c <generic_fentry_filter_arg+0x2b0c>
    83f3:      	jmp	0x9321 <generic_fentry_filter_arg+0x3221>
    83f8:      	cmpl	$0x1, %eax
    83fb:      	je	0x8453 <generic_fentry_filter_arg+0x2353>
    83fd:      	cmpl	$0x2, %eax
    8400:      	jne	0x8c0c <generic_fentry_filter_arg+0x2b0c>
    8406:      	cmpl	$0xc, %ecx
    8409:      	ja	0x8bfe <generic_fentry_filter_arg+0x2afe>
    840f:      	movl	$0x1402, %r8d           # imm = 0x1402
    8415:      	btl	%ecx, %r8d
    8419:      	jae	0x8bfe <generic_fentry_filter_arg+0x2afe>
    841f:      	movq	0x8(%rsp), %r8
    8424:      	cmpl	%esi, (%r8)
    8427:      	jl	0x63c8 <generic_fentry_filter_arg+0x2c8>
    842d:      	jmp	0x8c0c <generic_fentry_filter_arg+0x2b0c>
    8432:      	cmpl	$0xc, %eax
    8435:      	movq	0x10(%rsp), %rdi
    843a:      	jne	0x8c0c <generic_fentry_filter_arg+0x2b0c>
    8440:      	movq	0x8(%rsp), %r8
    8445:      	testl	%esi, (%r8)
    8448:      	jne	0x63c8 <generic_fentry_filter_arg+0x2c8>
    844e:      	jmp	0x8c0c <generic_fentry_filter_arg+0x2b0c>
    8453:      	cmpl	$0xc, %ecx
    8456:      	ja	0x8bee <generic_fentry_filter_arg+0x2aee>
    845c:      	movl	$0x1402, %r8d           # imm = 0x1402
    8462:      	btl	%ecx, %r8d
    8466:      	jae	0x8bee <generic_fentry_filter_arg+0x2aee>
    846c:      	movq	0x8(%rsp), %r8
    8471:      	cmpl	%esi, (%r8)
    8474:      	jg	0x63c8 <generic_fentry_filter_arg+0x2c8>
    847a:      	jmp	0x8c0c <generic_fentry_filter_arg+0x2b0c>
    847f:      	xorl	%ebx, %ebx
    8481:      	movq	0x18(%rsp), %r9
    8486:      	movq	%r15, %r11
    8489:      	movq	0x68(%rsp), %r15
    848e:      	jmp	0x876a <generic_fentry_filter_arg+0x266a>
    8493:      	xorl	%ebx, %ebx
    8495:      	movq	%r15, %r11
    8498:      	movq	0x68(%rsp), %r15
    849d:      	jmp	0x878d <generic_fentry_filter_arg+0x268d>
    84a2:      	cmpl	$0x1, %eax
    84a5:      	je	0x8ab2 <generic_fentry_filter_arg+0x29b2>
    84ab:      	cmpl	$0x2, %eax
    84ae:      	jne	0x8ac2 <generic_fentry_filter_arg+0x29c2>
    84b4:      	movq	0x8(%rsp), %rsi
    84b9:      	movzbl	(%rsi), %esi
    84bc:      	cmpl	%esi, %edx
    84be:      	ja	0x63c8 <generic_fentry_filter_arg+0x2c8>
    84c4:      	jmp	0x8ac2 <generic_fentry_filter_arg+0x29c2>
    84c9:      	cmpl	$0x1, %eax
    84cc:      	je	0x8afa <generic_fentry_filter_arg+0x29fa>
    84d2:      	cmpl	$0x2, %eax
    84d5:      	jne	0x8b0a <generic_fentry_filter_arg+0x2a0a>
    84db:      	movq	0x8(%rsp), %rsi
    84e0:      	movzwl	(%rsi), %esi
    84e3:      	cmpl	%esi, %edx
    84e5:      	ja	0x63c8 <generic_fentry_filter_arg+0x2c8>
    84eb:      	jmp	0x8b0a <generic_fentry_filter_arg+0x2a0a>
    84f0:      	movq	0x28(%rsp), %rax
    84f5:      	movw	%bp, (%rax)
    84f8:      	leaq	0x2(%rax), %rdi
    84fc:      	movl	$0x4, %eax
    8501:      	movl	%ebp, %esi
    8503:      	callq	*%rax
    8505:      	movq	0x98(%rsp), %rsi
    850d:      	subl	%ebp, %esi
    850f:      	jbe	0x8533 <generic_fentry_filter_arg+0x2433>
    8511:      	movq	0x28(%rsp), %rax
    8516:      	leaq	(%rax,%rbp), %rdi
    851a:      	addq	$0x2, %rdi
    851e:      	andl	$0xfff, %esi            # imm = 0xFFF
    8524:      	movl	$0x4, %eax
    8529:      	movq	0xa8(%rsp), %rdx
    8531:      	callq	*%rax
    8533:      	movl	0xa0(%rsp), %eax
    853a:      	movl	%eax, 0x40(%rsp)
    853e:      	cmpl	$0x3, %ebx
    8541:      	jg	0x8582 <generic_fentry_filter_arg+0x2482>
    8543:      	cmpl	$0x1, %ebx
    8546:      	movq	0x10(%rsp), %rdi
    854b:      	movq	0x18(%rsp), %r9
    8550:      	movq	0x20(%rsp), %r11
    8555:      	jg	0x8a42 <generic_fentry_filter_arg+0x2942>
    855b:      	testl	%ebx, %ebx
    855d:      	je	0x8e6f <generic_fentry_filter_arg+0x2d6f>
    8563:      	cmpl	$0x1, %ebx
    8566:      	jne	0x6a43 <generic_fentry_filter_arg+0x943>
    856c:      	movl	$0x1, %eax
    8571:      	leaq	0x40(%rsp), %rsi
    8576:      	movq	(%rip), %rdi            # 0x857d <generic_fentry_filter_arg+0x247d>
    857d:      	jmp	0x8eb9 <generic_fentry_filter_arg+0x2db9>
    8582:      	cmpl	$0x5, %ebx
    8585:      	movq	0x10(%rsp), %rdi
    858a:      	movq	0x18(%rsp), %r9
    858f:      	movq	0x20(%rsp), %r11
    8594:      	jg	0x8a6a <generic_fentry_filter_arg+0x296a>
    859a:      	cmpl	$0x4, %ebx
    859d:      	je	0x8e82 <generic_fentry_filter_arg+0x2d82>
    85a3:      	cmpl	$0x5, %ebx
    85a6:      	jne	0x6a43 <generic_fentry_filter_arg+0x943>
    85ac:      	movl	$0x1, %eax
    85b1:      	leaq	0x40(%rsp), %rsi
    85b6:      	movq	(%rip), %rdi            # 0x85bd <generic_fentry_filter_arg+0x24bd>
    85bd:      	jmp	0x8eb9 <generic_fentry_filter_arg+0x2db9>
    85c2:      	cmpl	$0x101, %eax            # imm = 0x101
    85c7:      	movl	$0x100, %edi            # imm = 0x100
    85cc:      	movl	$0x1fe, %eax            # imm = 0x1FE
    85d1:      	cmovael	%eax, %edi
    85d4:      	movl	%edi, %eax
    85d6:      	movzwl	%ax, %ecx
    85d9:      	xorl	%eax, %eax
    85db:      	cmpl	$0x100, %ecx            # imm = 0x100
    85e1:      	sete	%al
    85e4:      	xorl	$0x7, %eax
    85e7:      	movl	%eax, %ecx
    85e9:      	andl	$0xf, %ecx
    85ec:      	movl	0x10(%r12,%rcx,4), %ecx
    85f1:      	cmpl	$-0x1, %ecx
    85f4:      	je	0x9384 <generic_fentry_filter_arg+0x3284>
    85fa:      	movl	%ecx, 0x98(%rsp)
    8601:      	movq	%rdi, 0xa0(%rsp)
    8609:      	movl	%eax, 0x70(%rsp)
    860d:      	movq	%rsi, 0x8(%rsp)
    8612:      	movl	$0x1, %eax
    8617:      	movq	(%rip), %rdi            # 0x861e <generic_fentry_filter_arg+0x251e>
    861e:      	movq	0x38(%rsp), %rbx
    8623:      	movq	%rbx, %rsi
    8626:      	callq	*%rax
    8628:      	movq	%rax, 0x28(%rsp)
    862d:      	movl	$0x1, %eax
    8632:      	movq	(%rip), %rdi            # 0x8639 <generic_fentry_filter_arg+0x2539>
    8639:      	movq	%rbx, %rsi
    863c:      	callq	*%rax
    863e:      	cmpq	$0x0, 0x28(%rsp)
    8644:      	je	0x9384 <generic_fentry_filter_arg+0x3284>
    864a:      	movl	$0x0, %ebx
    864f:      	testq	%rax, %rax
    8652:      	movq	0x10(%rsp), %rdi
    8657:      	movq	0x18(%rsp), %r9
    865c:      	movq	0x20(%rsp), %r11
    8661:      	je	0x9395 <generic_fentry_filter_arg+0x3295>
    8667:      	movq	%rax, %r13
    866a:      	movl	0x70(%rsp), %ebx
    866e:      	cmpl	$0x5, %ebx
    8671:      	jg	0x8dbb <generic_fentry_filter_arg+0x2cbb>
    8677:      	movq	0x28(%rsp), %rax
    867c:      	movb	%bpl, (%rax)
    867f:      	leaq	0x1(%rax), %rdi
    8683:      	movl	$0x4, %eax
    8688:      	movq	0x8(%rsp), %rdx
    868d:      	movl	%ebp, %esi
    868f:      	callq	*%rax
    8691:      	movq	0xa0(%rsp), %rsi
    8699:      	subl	%ebp, %esi
    869b:      	jbe	0x8dfe <generic_fentry_filter_arg+0x2cfe>
    86a1:      	movq	0x28(%rsp), %rax
    86a6:      	leaq	(%rax,%rbp), %rdi
    86aa:      	incq	%rdi
    86ad:      	andl	$0xfff, %esi            # imm = 0xFFF
    86b3:      	movl	$0x4, %eax
    86b8:      	jmp	0x8df9 <generic_fentry_filter_arg+0x2cf9>
    86bd:      	cmpl	%edx, %r8d
    86c0:      	setbe	%r8b
    86c4:      	cmpl	%edi, %edx
    86c6:      	setbe	%dil
    86ca:      	andb	%r8b, %dil
    86cd:      	orb	%dil, %al
    86d0:      	cmpl	$0x19, %esi
    86d3:      	jb	0x8f24 <generic_fentry_filter_arg+0x2e24>
    86d9:      	movl	0x20(%r12), %r8d
    86de:      	movl	0x24(%r12), %edi
    86e3:      	cmpl	$0xc, %ecx
    86e6:      	ja	0x8b4e <generic_fentry_filter_arg+0x2a4e>
    86ec:      	movl	$0x1402, %r10d          # imm = 0x1402
    86f2:      	btl	%ecx, %r10d
    86f6:      	jae	0x8b4e <generic_fentry_filter_arg+0x2a4e>
    86fc:      	cmpl	%edx, %r8d
    86ff:      	setle	%r8b
    8703:      	cmpl	%edi, %edx
    8705:      	setle	%dil
    8709:      	jmp	0x8b5b <generic_fentry_filter_arg+0x2a5b>
    870e:      	cmpl	%eax, %edi
    8710:      	movq	0x10(%rsp), %rdi
    8715:      	ja	0x871f <generic_fentry_filter_arg+0x261f>
    8717:      	cmpl	%esi, %eax
    8719:      	jbe	0x63c8 <generic_fentry_filter_arg+0x2c8>
    871f:      	cmpl	$0x19, %edx
    8722:      	jb	0x620d <generic_fentry_filter_arg+0x10d>
    8728:      	movl	0x20(%r12), %edi
    872d:      	movl	0x24(%r12), %esi
    8732:      	cmpl	$0xc, %ecx
    8735:      	ja	0x8b9c <generic_fentry_filter_arg+0x2a9c>
    873b:      	movl	$0x1402, %r8d           # imm = 0x1402
    8741:      	btl	%ecx, %r8d
    8745:      	jae	0x8b9c <generic_fentry_filter_arg+0x2a9c>
    874b:      	cmpl	%eax, %edi
    874d:      	movq	0x10(%rsp), %rdi
    8752:      	jg	0x8bad <generic_fentry_filter_arg+0x2aad>
    8758:      	cmpl	%esi, %eax
    875a:      	jle	0x63c8 <generic_fentry_filter_arg+0x2c8>
    8760:      	jmp	0x8bad <generic_fentry_filter_arg+0x2aad>
    8765:      	movl	$0x1, %ebx
    876a:      	movq	0x78(%rsp), %r13
    876f:      	movq	0x10(%rsp), %rdi
    8774:      	movl	0x4(%r12), %eax
    8779:      	cmpq	$0x25, %rax
    877d:      	jbe	0x90d6 <generic_fentry_filter_arg+0x2fd6>
    8783:      	jmp	0x63b7 <generic_fentry_filter_arg+0x2b7>
    8788:      	movl	$0x1, %ebx
    878d:      	movq	0x78(%rsp), %r13
    8792:      	movq	0x10(%rsp), %rdi
    8797:      	movq	0x18(%rsp), %r9
    879c:      	movl	0x4(%r12), %eax
    87a1:      	cmpq	$0x25, %rax
    87a5:      	jbe	0x90d6 <generic_fentry_filter_arg+0x2fd6>
    87ab:      	jmp	0x63b7 <generic_fentry_filter_arg+0x2b7>
    87b0:      	cmpq	%rdx, %r8
    87b3:      	setbe	%r8b
    87b7:      	cmpq	%rdi, %rdx
    87ba:      	setbe	%dil
    87be:      	andb	%r8b, %dil
    87c1:      	orb	%dil, %al
    87c4:      	cmpl	$0x39, %esi
    87c7:      	jb	0x8f24 <generic_fentry_filter_arg+0x2e24>
    87cd:      	movq	0x40(%r12), %rdi
    87d2:      	movq	0x48(%r12), %rsi
    87d7:      	cmpl	$0xc, %ecx
    87da:      	je	0x87e5 <generic_fentry_filter_arg+0x26e5>
    87dc:      	cmpl	$0xa, %ecx
    87df:      	jne	0x8cc5 <generic_fentry_filter_arg+0x2bc5>
    87e5:      	cmpq	%rdx, %rdi
    87e8:      	setle	%cl
    87eb:      	cmpq	%rsi, %rdx
    87ee:      	jmp	0x8b94 <generic_fentry_filter_arg+0x2a94>
    87f3:      	xorl	%ebx, %ebx
    87f5:      	jmp	0x63b2 <generic_fentry_filter_arg+0x2b2>
    87fa:      	movq	0x28(%rsp), %rax
    87ff:      	movw	%bp, (%rax)
    8802:      	leaq	0x2(%rax), %rdi
    8806:      	movl	$0x4, %eax
    880b:      	movq	0x8(%rsp), %rdx
    8810:      	movl	%ebp, %esi
    8812:      	callq	*%rax
    8814:      	movq	0x98(%rsp), %rsi
    881c:      	subl	%ebp, %esi
    881e:      	jbe	0x8842 <generic_fentry_filter_arg+0x2742>
    8820:      	movq	0x28(%rsp), %rax
    8825:      	leaq	(%rax,%rbp), %rdi
    8829:      	addq	$0x2, %rdi
    882d:      	andl	$0xfff, %esi            # imm = 0xFFF
    8833:      	movl	$0x4, %eax
    8838:      	movq	0xa8(%rsp), %rdx
    8840:      	callq	*%rax
    8842:      	movl	0xa0(%rsp), %eax
    8849:      	movl	%eax, 0x40(%rsp)
    884d:      	cmpl	$0x3, %ebx
    8850:      	jg	0x888c <generic_fentry_filter_arg+0x278c>
    8852:      	cmpl	$0x1, %ebx
    8855:      	movq	0x18(%rsp), %r9
    885a:      	movq	0x20(%rsp), %r11
    885f:      	jg	0x8cd3 <generic_fentry_filter_arg+0x2bd3>
    8865:      	testl	%ebx, %ebx
    8867:      	je	0x904c <generic_fentry_filter_arg+0x2f4c>
    886d:      	cmpl	$0x1, %ebx
    8870:      	jne	0x90ef <generic_fentry_filter_arg+0x2fef>
    8876:      	movl	$0x1, %eax
    887b:      	leaq	0x40(%rsp), %rsi
    8880:      	movq	(%rip), %rdi            # 0x8887 <generic_fentry_filter_arg+0x2787>
    8887:      	jmp	0x9096 <generic_fentry_filter_arg+0x2f96>
    888c:      	cmpl	$0x5, %ebx
    888f:      	movq	0x18(%rsp), %r9
    8894:      	movq	0x20(%rsp), %r11
    8899:      	jg	0x8cfb <generic_fentry_filter_arg+0x2bfb>
    889f:      	cmpl	$0x4, %ebx
    88a2:      	je	0x905f <generic_fentry_filter_arg+0x2f5f>
    88a8:      	cmpl	$0x5, %ebx
    88ab:      	jne	0x90ef <generic_fentry_filter_arg+0x2fef>
    88b1:      	movl	$0x1, %eax
    88b6:      	leaq	0x40(%rsp), %rsi
    88bb:      	movq	(%rip), %rdi            # 0x88c2 <generic_fentry_filter_arg+0x27c2>
    88c2:      	jmp	0x9096 <generic_fentry_filter_arg+0x2f96>
    88c7:      	cmpq	%rax, %rdi
    88ca:      	movq	0x10(%rsp), %rdi
    88cf:      	ja	0x88da <generic_fentry_filter_arg+0x27da>
    88d1:      	cmpq	%rsi, %rax
    88d4:      	jbe	0x63c8 <generic_fentry_filter_arg+0x2c8>
    88da:      	cmpl	$0x39, %edx
    88dd:      	jb	0x620d <generic_fentry_filter_arg+0x10d>
    88e3:      	movq	0x40(%r12), %rsi
    88e8:      	movq	0x48(%r12), %rdx
    88ed:      	cmpl	$0xc, %ecx
    88f0:      	je	0x88fb <generic_fentry_filter_arg+0x27fb>
    88f2:      	cmpl	$0xa, %ecx
    88f5:      	jne	0x8d23 <generic_fentry_filter_arg+0x2c23>
    88fb:      	cmpq	%rax, %rsi
    88fe:      	jg	0x620d <generic_fentry_filter_arg+0x10d>
    8904:      	cmpq	%rdx, %rax
    8907:      	jle	0x63c8 <generic_fentry_filter_arg+0x2c8>
    890d:      	jmp	0x620d <generic_fentry_filter_arg+0x10d>
    8912:      	movq	0x8(%rsp), %r8
    8917:      	cmpq	%rsi, (%r8)
    891a:      	ja	0x63c8 <generic_fentry_filter_arg+0x2c8>
    8920:      	jmp	0x8930 <generic_fentry_filter_arg+0x2830>
    8922:      	movq	0x8(%rsp), %r8
    8927:      	cmpq	%rsi, (%r8)
    892a:      	jb	0x63c8 <generic_fentry_filter_arg+0x2c8>
    8930:      	cmpl	$0x19, %edx
    8933:      	jb	0x944a <generic_fentry_filter_arg+0x334a>
    8939:      	movq	0x20(%r12), %rsi
    893e:      	cmpl	$0x2, %eax
    8941:      	jle	0x8963 <generic_fentry_filter_arg+0x2863>
    8943:      	leal	-0x3(%rax), %edi
    8946:      	cmpl	$0x2, %edi
    8949:      	jae	0x8996 <generic_fentry_filter_arg+0x2896>
    894b:      	movq	0x8(%rsp), %rdi
    8950:      	cmpq	%rsi, (%rdi)
    8953:      	movq	0x10(%rsp), %rdi
    8958:      	jne	0x8f54 <generic_fentry_filter_arg+0x2e54>
    895e:      	jmp	0x9321 <generic_fentry_filter_arg+0x3221>
    8963:      	cmpl	$0x1, %eax
    8966:      	je	0x8a08 <generic_fentry_filter_arg+0x2908>
    896c:      	cmpl	$0x2, %eax
    896f:      	jne	0x8f54 <generic_fentry_filter_arg+0x2e54>
    8975:      	cmpl	$0xc, %ecx
    8978:      	je	0x8983 <generic_fentry_filter_arg+0x2883>
    897a:      	cmpl	$0xa, %ecx
    897d:      	jne	0x8f46 <generic_fentry_filter_arg+0x2e46>
    8983:      	movq	0x8(%rsp), %r8
    8988:      	cmpq	%rsi, (%r8)
    898b:      	jl	0x63c8 <generic_fentry_filter_arg+0x2c8>
    8991:      	jmp	0x8f54 <generic_fentry_filter_arg+0x2e54>
    8996:      	cmpl	$0xc, %eax
    8999:      	movq	0x10(%rsp), %rdi
    899e:      	jne	0x8f54 <generic_fentry_filter_arg+0x2e54>
    89a4:      	movq	0x8(%rsp), %r8
    89a9:      	testq	%rsi, (%r8)
    89ac:      	jne	0x63c8 <generic_fentry_filter_arg+0x2c8>
    89b2:      	jmp	0x8f54 <generic_fentry_filter_arg+0x2e54>
    89b7:      	cmpl	$0xc, %eax
    89ba:      	jne	0x8ac2 <generic_fentry_filter_arg+0x29c2>
    89c0:      	movq	0x8(%rsp), %rsi
    89c5:      	movzbl	(%rsi), %esi
    89c8:      	testl	%esi, %edx
    89ca:      	jne	0x63c8 <generic_fentry_filter_arg+0x2c8>
    89d0:      	jmp	0x8ac2 <generic_fentry_filter_arg+0x29c2>
    89d5:      	cmpl	$0xc, %eax
    89d8:      	jne	0x8b0a <generic_fentry_filter_arg+0x2a0a>
    89de:      	movq	0x8(%rsp), %rsi
    89e3:      	movzwl	(%rsi), %esi
    89e6:      	testl	%esi, %edx
    89e8:      	jne	0x63c8 <generic_fentry_filter_arg+0x2c8>
    89ee:      	jmp	0x8b0a <generic_fentry_filter_arg+0x2a0a>
    89f3:      	movq	0x10(%rsp), %rdi
    89f8:      	movq	0x18(%rsp), %r9
    89fd:      	movq	%rbp, %r11
    8a00:      	movzbl	%cl, %ebx
    8a03:      	jmp	0x63b7 <generic_fentry_filter_arg+0x2b7>
    8a08:      	cmpl	$0xc, %ecx
    8a0b:      	je	0x8a16 <generic_fentry_filter_arg+0x2916>
    8a0d:      	cmpl	$0xa, %ecx
    8a10:      	jne	0x8f36 <generic_fentry_filter_arg+0x2e36>
    8a16:      	movq	0x8(%rsp), %r8
    8a1b:      	cmpq	%rsi, (%r8)
    8a1e:      	jg	0x63c8 <generic_fentry_filter_arg+0x2c8>
    8a24:      	jmp	0x8f54 <generic_fentry_filter_arg+0x2e54>
    8a29:      	xorl	%ebx, %ebx
    8a2b:      	movq	0x18(%rsp), %r9
    8a30:      	movq	%r15, %r11
    8a33:      	movq	0x68(%rsp), %r15
    8a38:      	movq	0x10(%rsp), %rdi
    8a3d:      	jmp	0x9395 <generic_fentry_filter_arg+0x3295>
    8a42:      	cmpl	$0x2, %ebx
    8a45:      	je	0x8e95 <generic_fentry_filter_arg+0x2d95>
    8a4b:      	cmpl	$0x3, %ebx
    8a4e:      	jne	0x6a43 <generic_fentry_filter_arg+0x943>
    8a54:      	movl	$0x1, %eax
    8a59:      	leaq	0x40(%rsp), %rsi
    8a5e:      	movq	(%rip), %rdi            # 0x8a65 <generic_fentry_filter_arg+0x2965>
    8a65:      	jmp	0x8eb9 <generic_fentry_filter_arg+0x2db9>
    8a6a:      	cmpl	$0x6, %ebx
    8a6d:      	je	0x8ea8 <generic_fentry_filter_arg+0x2da8>
    8a73:      	cmpl	$0x7, %ebx
    8a76:      	jne	0x6a43 <generic_fentry_filter_arg+0x943>
    8a7c:      	movl	$0x1, %eax
    8a81:      	leaq	0x40(%rsp), %rsi
    8a86:      	movq	(%rip), %rdi            # 0x8a8d <generic_fentry_filter_arg+0x298d>
    8a8d:      	jmp	0x8eb9 <generic_fentry_filter_arg+0x2db9>
    8a92:      	xorl	%ebx, %ebx
    8a94:      	jmp	0x8a9b <generic_fentry_filter_arg+0x299b>
    8a96:      	movl	$0x1, %ebx
    8a9b:      	movq	0x10(%rsp), %rdi
    8aa0:      	movq	0x18(%rsp), %r9
    8aa5:      	movq	%r15, %r11
    8aa8:      	movq	0x68(%rsp), %r15
    8aad:      	jmp	0x9395 <generic_fentry_filter_arg+0x3295>
    8ab2:      	movq	0x8(%rsp), %rsi
    8ab7:      	movzbl	(%rsi), %esi
    8aba:      	cmpl	%esi, %edx
    8abc:      	jb	0x63c8 <generic_fentry_filter_arg+0x2c8>
    8ac2:      	cmpl	$0x11, %ecx
    8ac5:      	jb	0x944a <generic_fentry_filter_arg+0x334a>
    8acb:      	movl	0x18(%r12), %edx
    8ad0:      	cmpl	$0x2, %eax
    8ad3:      	jle	0x8d4c <generic_fentry_filter_arg+0x2c4c>
    8ad9:      	leal	-0x3(%rax), %esi
    8adc:      	cmpl	$0x2, %esi
    8adf:      	jae	0x8fda <generic_fentry_filter_arg+0x2eda>
    8ae5:      	movq	0x8(%rsp), %rsi
    8aea:      	movzbl	(%rsi), %esi
    8aed:      	cmpl	%esi, %edx
    8aef:      	jne	0x915c <generic_fentry_filter_arg+0x305c>
    8af5:      	jmp	0x9321 <generic_fentry_filter_arg+0x3221>
    8afa:      	movq	0x8(%rsp), %rsi
    8aff:      	movzwl	(%rsi), %esi
    8b02:      	cmpl	%esi, %edx
    8b04:      	jb	0x63c8 <generic_fentry_filter_arg+0x2c8>
    8b0a:      	cmpl	$0x11, %ecx
    8b0d:      	jb	0x944a <generic_fentry_filter_arg+0x334a>
    8b13:      	movl	0x18(%r12), %edx
    8b18:      	cmpl	$0x2, %eax
    8b1b:      	jle	0x8d73 <generic_fentry_filter_arg+0x2c73>
    8b21:      	leal	-0x3(%rax), %esi
    8b24:      	cmpl	$0x2, %esi
    8b27:      	jae	0x8ff8 <generic_fentry_filter_arg+0x2ef8>
    8b2d:      	movq	0x8(%rsp), %rsi
    8b32:      	movzwl	(%rsi), %esi
    8b35:      	cmpl	%esi, %edx
    8b37:      	jne	0x91ab <generic_fentry_filter_arg+0x30ab>
    8b3d:      	jmp	0x9321 <generic_fentry_filter_arg+0x3221>
    8b42:      	xorl	%ebx, %ebx
    8b44:      	movq	0x68(%rsp), %r15
    8b49:      	jmp	0x9395 <generic_fentry_filter_arg+0x3295>
    8b4e:      	cmpl	%edx, %r8d
    8b51:      	setbe	%r8b
    8b55:      	cmpl	%edi, %edx
    8b57:      	setbe	%dil
    8b5b:      	andb	%r8b, %dil
    8b5e:      	orb	%dil, %al
    8b61:      	cmpl	$0x21, %esi
    8b64:      	jb	0x8f24 <generic_fentry_filter_arg+0x2e24>
    8b6a:      	movl	0x28(%r12), %edi
    8b6f:      	movl	0x2c(%r12), %esi
    8b74:      	cmpl	$0xc, %ecx
    8b77:      	ja	0x8f16 <generic_fentry_filter_arg+0x2e16>
    8b7d:      	movl	$0x1402, %r8d           # imm = 0x1402
    8b83:      	btl	%ecx, %r8d
    8b87:      	jae	0x8f16 <generic_fentry_filter_arg+0x2e16>
    8b8d:      	cmpl	%edx, %edi
    8b8f:      	setle	%cl
    8b92:      	cmpl	%esi, %edx
    8b94:      	setle	%dl
    8b97:      	jmp	0x8f20 <generic_fentry_filter_arg+0x2e20>
    8b9c:      	cmpl	%eax, %edi
    8b9e:      	movq	0x10(%rsp), %rdi
    8ba3:      	ja	0x8bad <generic_fentry_filter_arg+0x2aad>
    8ba5:      	cmpl	%esi, %eax
    8ba7:      	jbe	0x63c8 <generic_fentry_filter_arg+0x2c8>
    8bad:      	cmpl	$0x21, %edx
    8bb0:      	jb	0x620d <generic_fentry_filter_arg+0x10d>
    8bb6:      	movl	0x28(%r12), %esi
    8bbb:      	movl	0x2c(%r12), %edx
    8bc0:      	cmpl	$0xc, %ecx
    8bc3:      	ja	0x9016 <generic_fentry_filter_arg+0x2f16>
    8bc9:      	movl	$0x1402, %r8d           # imm = 0x1402
    8bcf:      	btl	%ecx, %r8d
    8bd3:      	jae	0x9016 <generic_fentry_filter_arg+0x2f16>
    8bd9:      	cmpl	%eax, %esi
    8bdb:      	jg	0x620d <generic_fentry_filter_arg+0x10d>
    8be1:      	cmpl	%edx, %eax
    8be3:      	jle	0x63c8 <generic_fentry_filter_arg+0x2c8>
    8be9:      	jmp	0x620d <generic_fentry_filter_arg+0x10d>
    8bee:      	movq	0x8(%rsp), %r8
    8bf3:      	cmpl	%esi, (%r8)
    8bf6:      	ja	0x63c8 <generic_fentry_filter_arg+0x2c8>
    8bfc:      	jmp	0x8c0c <generic_fentry_filter_arg+0x2b0c>
    8bfe:      	movq	0x8(%rsp), %r8
    8c03:      	cmpl	%esi, (%r8)
    8c06:      	jb	0x63c8 <generic_fentry_filter_arg+0x2c8>
    8c0c:      	cmpl	$0x11, %edx
    8c0f:      	jb	0x944a <generic_fentry_filter_arg+0x334a>
    8c15:      	movl	0x18(%r12), %esi
    8c1a:      	cmpl	$0x2, %eax
    8c1d:      	jle	0x8c3e <generic_fentry_filter_arg+0x2b3e>
    8c1f:      	leal	-0x3(%rax), %edi
    8c22:      	cmpl	$0x2, %edi
    8c25:      	jae	0x8c78 <generic_fentry_filter_arg+0x2b78>
    8c27:      	movq	0x8(%rsp), %rdi
    8c2c:      	cmpl	%esi, (%rdi)
    8c2e:      	movq	0x10(%rsp), %rdi
    8c33:      	jne	0x9213 <generic_fentry_filter_arg+0x3113>
    8c39:      	jmp	0x9321 <generic_fentry_filter_arg+0x3221>
    8c3e:      	cmpl	$0x1, %eax
    8c41:      	je	0x8c99 <generic_fentry_filter_arg+0x2b99>
    8c43:      	cmpl	$0x2, %eax
    8c46:      	jne	0x9213 <generic_fentry_filter_arg+0x3113>
    8c4c:      	cmpl	$0xc, %ecx
    8c4f:      	ja	0x9205 <generic_fentry_filter_arg+0x3105>
    8c55:      	movl	$0x1402, %r8d           # imm = 0x1402
    8c5b:      	btl	%ecx, %r8d
    8c5f:      	jae	0x9205 <generic_fentry_filter_arg+0x3105>
    8c65:      	movq	0x8(%rsp), %r8
    8c6a:      	cmpl	%esi, (%r8)
    8c6d:      	jl	0x63c8 <generic_fentry_filter_arg+0x2c8>
    8c73:      	jmp	0x9213 <generic_fentry_filter_arg+0x3113>
    8c78:      	cmpl	$0xc, %eax
    8c7b:      	movq	0x10(%rsp), %rdi
    8c80:      	jne	0x9213 <generic_fentry_filter_arg+0x3113>
    8c86:      	movq	0x8(%rsp), %r8
    8c8b:      	testl	%esi, (%r8)
    8c8e:      	jne	0x63c8 <generic_fentry_filter_arg+0x2c8>
    8c94:      	jmp	0x9213 <generic_fentry_filter_arg+0x3113>
    8c99:      	cmpl	$0xc, %ecx
    8c9c:      	ja	0x91f5 <generic_fentry_filter_arg+0x30f5>
    8ca2:      	movl	$0x1402, %r8d           # imm = 0x1402
    8ca8:      	btl	%ecx, %r8d
    8cac:      	jae	0x91f5 <generic_fentry_filter_arg+0x30f5>
    8cb2:      	movq	0x8(%rsp), %r8
    8cb7:      	cmpl	%esi, (%r8)
    8cba:      	jg	0x63c8 <generic_fentry_filter_arg+0x2c8>
    8cc0:      	jmp	0x9213 <generic_fentry_filter_arg+0x3113>
    8cc5:      	cmpq	%rdx, %rdi
    8cc8:      	setbe	%cl
    8ccb:      	cmpq	%rsi, %rdx
    8cce:      	jmp	0x8f1d <generic_fentry_filter_arg+0x2e1d>
    8cd3:      	cmpl	$0x2, %ebx
    8cd6:      	je	0x9072 <generic_fentry_filter_arg+0x2f72>
    8cdc:      	cmpl	$0x3, %ebx
    8cdf:      	jne	0x90ef <generic_fentry_filter_arg+0x2fef>
    8ce5:      	movl	$0x1, %eax
    8cea:      	leaq	0x40(%rsp), %rsi
    8cef:      	movq	(%rip), %rdi            # 0x8cf6 <generic_fentry_filter_arg+0x2bf6>
    8cf6:      	jmp	0x9096 <generic_fentry_filter_arg+0x2f96>
    8cfb:      	cmpl	$0x6, %ebx
    8cfe:      	je	0x9085 <generic_fentry_filter_arg+0x2f85>
    8d04:      	cmpl	$0x7, %ebx
    8d07:      	jne	0x90ef <generic_fentry_filter_arg+0x2fef>
    8d0d:      	movl	$0x1, %eax
    8d12:      	leaq	0x40(%rsp), %rsi
    8d17:      	movq	(%rip), %rdi            # 0x8d1e <generic_fentry_filter_arg+0x2c1e>
    8d1e:      	jmp	0x9096 <generic_fentry_filter_arg+0x2f96>
    8d23:      	cmpq	%rax, %rsi
    8d26:      	ja	0x620d <generic_fentry_filter_arg+0x10d>
    8d2c:      	cmpq	%rdx, %rax
    8d2f:      	jbe	0x63c8 <generic_fentry_filter_arg+0x2c8>
    8d35:      	jmp	0x620d <generic_fentry_filter_arg+0x10d>
    8d3a:      	movq	0x10(%rsp), %rdi
    8d3f:      	movq	0x18(%rsp), %r9
    8d44:      	movq	%r13, %r11
    8d47:      	jmp	0x63af <generic_fentry_filter_arg+0x2af>
    8d4c:      	cmpl	$0x1, %eax
    8d4f:      	je	0x914c <generic_fentry_filter_arg+0x304c>
    8d55:      	cmpl	$0x2, %eax
    8d58:      	jne	0x915c <generic_fentry_filter_arg+0x305c>
    8d5e:      	movq	0x8(%rsp), %rsi
    8d63:      	movzbl	(%rsi), %esi
    8d66:      	cmpl	%esi, %edx
    8d68:      	ja	0x63c8 <generic_fentry_filter_arg+0x2c8>
    8d6e:      	jmp	0x915c <generic_fentry_filter_arg+0x305c>
    8d73:      	cmpl	$0x1, %eax
    8d76:      	je	0x919b <generic_fentry_filter_arg+0x309b>
    8d7c:      	cmpl	$0x2, %eax
    8d7f:      	jne	0x91ab <generic_fentry_filter_arg+0x30ab>
    8d85:      	movq	0x8(%rsp), %rsi
    8d8a:      	movzwl	(%rsi), %esi
    8d8d:      	cmpl	%esi, %edx
    8d8f:      	ja	0x63c8 <generic_fentry_filter_arg+0x2c8>
    8d95:      	jmp	0x91ab <generic_fentry_filter_arg+0x30ab>
    8d9a:      	movl	$0x1, %ebx
    8d9f:      	movq	0x10(%rsp), %rdi
    8da4:      	jmp	0x9395 <generic_fentry_filter_arg+0x3295>
    8da9:      	movq	0x10(%rsp), %rdi
    8dae:      	movq	0x18(%rsp), %r9
    8db3:      	movq	%rbp, %r11
    8db6:      	jmp	0x63af <generic_fentry_filter_arg+0x2af>
    8dbb:      	movq	0x28(%rsp), %rax
    8dc0:      	movw	%bp, (%rax)
    8dc3:      	leaq	0x2(%rax), %rdi
    8dc7:      	movl	$0x4, %eax
    8dcc:      	movq	0x8(%rsp), %rdx
    8dd1:      	movl	%ebp, %esi
    8dd3:      	callq	*%rax
    8dd5:      	movq	0xa0(%rsp), %rsi
    8ddd:      	subl	%ebp, %esi
    8ddf:      	jbe	0x8dfe <generic_fentry_filter_arg+0x2cfe>
    8de1:      	movq	0x28(%rsp), %rax
    8de6:      	leaq	(%rax,%rbp), %rdi
    8dea:      	addq	$0x2, %rdi
    8dee:      	andl	$0xfff, %esi            # imm = 0xFFF
    8df4:      	movl	$0x4, %eax
    8df9:      	movq	%r13, %rdx
    8dfc:      	callq	*%rax
    8dfe:      	movl	0x98(%rsp), %eax
    8e05:      	movl	%eax, 0x40(%rsp)
    8e09:      	cmpl	$0x3, %ebx
    8e0c:      	jg	0x8e3e <generic_fentry_filter_arg+0x2d3e>
    8e0e:      	cmpl	$0x1, %ebx
    8e11:      	leaq	0x40(%rsp), %rsi
    8e16:      	jg	0x9106 <generic_fentry_filter_arg+0x3006>
    8e1c:      	testl	%ebx, %ebx
    8e1e:      	je	0x932e <generic_fentry_filter_arg+0x322e>
    8e24:      	cmpl	$0x1, %ebx
    8e27:      	jne	0x9384 <generic_fentry_filter_arg+0x3284>
    8e2d:      	movl	$0x1, %eax
    8e32:      	movq	(%rip), %rdi            # 0x8e39 <generic_fentry_filter_arg+0x2d39>
    8e39:      	jmp	0x9364 <generic_fentry_filter_arg+0x3264>
    8e3e:      	cmpl	$0x5, %ebx
    8e41:      	leaq	0x40(%rsp), %rsi
    8e46:      	jg	0x9129 <generic_fentry_filter_arg+0x3029>
    8e4c:      	cmpl	$0x4, %ebx
    8e4f:      	je	0x933c <generic_fentry_filter_arg+0x323c>
    8e55:      	cmpl	$0x5, %ebx
    8e58:      	jne	0x9384 <generic_fentry_filter_arg+0x3284>
    8e5e:      	movl	$0x1, %eax
    8e63:      	movq	(%rip), %rdi            # 0x8e6a <generic_fentry_filter_arg+0x2d6a>
    8e6a:      	jmp	0x9364 <generic_fentry_filter_arg+0x3264>
    8e6f:      	movl	$0x1, %eax
    8e74:      	movq	(%rip), %rdi            # 0x8e7b <generic_fentry_filter_arg+0x2d7b>
    8e7b:      	leaq	0x40(%rsp), %rsi
    8e80:      	jmp	0x8eb9 <generic_fentry_filter_arg+0x2db9>
    8e82:      	movl	$0x1, %eax
    8e87:      	leaq	0x40(%rsp), %rsi
    8e8c:      	movq	(%rip), %rdi            # 0x8e93 <generic_fentry_filter_arg+0x2d93>
    8e93:      	jmp	0x8eb9 <generic_fentry_filter_arg+0x2db9>
    8e95:      	movl	$0x1, %eax
    8e9a:      	leaq	0x40(%rsp), %rsi
    8e9f:      	movq	(%rip), %rdi            # 0x8ea6 <generic_fentry_filter_arg+0x2da6>
    8ea6:      	jmp	0x8eb9 <generic_fentry_filter_arg+0x2db9>
    8ea8:      	movl	$0x1, %eax
    8ead:      	leaq	0x40(%rsp), %rsi
    8eb2:      	movq	(%rip), %rdi            # 0x8eb9 <generic_fentry_filter_arg+0x2db9>
    8eb9:      	callq	*%rax
    8ebb:      	testq	%rax, %rax
    8ebe:      	je	0x8ed9 <generic_fentry_filter_arg+0x2dd9>
    8ec0:      	movq	%rax, %rdi
    8ec3:      	movl	$0x1, %eax
    8ec8:      	movq	0x28(%rsp), %rsi
    8ecd:      	callq	*%rax
    8ecf:      	xorl	%ebx, %ebx
    8ed1:      	testq	%rax, %rax
    8ed4:      	setne	%bl
    8ed7:      	jmp	0x8edb <generic_fentry_filter_arg+0x2ddb>
    8ed9:      	xorl	%ebx, %ebx
    8edb:      	movq	0x10(%rsp), %rdi
    8ee0:      	movq	0x18(%rsp), %r9
    8ee5:      	movq	0x20(%rsp), %r11
    8eea:      	movl	0x4(%r12), %eax
    8eef:      	cmpq	$0x25, %rax
    8ef3:      	ja	0x63b7 <generic_fentry_filter_arg+0x2b7>
    8ef9:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    8f03:      	btq	%rax, %rcx
    8f07:      	jae	0x63b7 <generic_fentry_filter_arg+0x2b7>
    8f0d:      	xorq	$0x1, %rbx
    8f11:      	jmp	0x63b7 <generic_fentry_filter_arg+0x2b7>
    8f16:      	cmpl	%edx, %edi
    8f18:      	setbe	%cl
    8f1b:      	cmpl	%esi, %edx
    8f1d:      	setbe	%dl
    8f20:      	andb	%cl, %dl
    8f22:      	orb	%dl, %al
    8f24:      	movq	0x10(%rsp), %rdi
    8f29:      	testb	%al, %al
    8f2b:      	je	0x63c8 <generic_fentry_filter_arg+0x2c8>
    8f31:      	jmp	0x620d <generic_fentry_filter_arg+0x10d>
    8f36:      	movq	0x8(%rsp), %r8
    8f3b:      	cmpq	%rsi, (%r8)
    8f3e:      	ja	0x63c8 <generic_fentry_filter_arg+0x2c8>
    8f44:      	jmp	0x8f54 <generic_fentry_filter_arg+0x2e54>
    8f46:      	movq	0x8(%rsp), %r8
    8f4b:      	cmpq	%rsi, (%r8)
    8f4e:      	jb	0x63c8 <generic_fentry_filter_arg+0x2c8>
    8f54:      	cmpl	$0x21, %edx
    8f57:      	jb	0x944a <generic_fentry_filter_arg+0x334a>
    8f5d:      	movq	0x28(%r12), %rdx
    8f62:      	cmpl	$0x2, %eax
    8f65:      	jle	0x8f94 <generic_fentry_filter_arg+0x2e94>
    8f67:      	leal	-0x3(%rax), %ecx
    8f6a:      	cmpl	$0x2, %ecx
    8f6d:      	jb	0x8fc7 <generic_fentry_filter_arg+0x2ec7>
    8f6f:      	cmpl	$0x6, %eax
    8f72:      	je	0x63c8 <generic_fentry_filter_arg+0x2c8>
    8f78:      	cmpl	$0xc, %eax
    8f7b:      	jne	0x620d <generic_fentry_filter_arg+0x10d>
    8f81:      	movq	0x8(%rsp), %rcx
    8f86:      	testq	%rdx, (%rcx)
    8f89:      	jne	0x63c8 <generic_fentry_filter_arg+0x2c8>
    8f8f:      	jmp	0x944a <generic_fentry_filter_arg+0x334a>
    8f94:      	cmpl	$0x1, %eax
    8f97:      	je	0x902b <generic_fentry_filter_arg+0x2f2b>
    8f9d:      	cmpl	$0x2, %eax
    8fa0:      	jne	0x620d <generic_fentry_filter_arg+0x10d>
    8fa6:      	cmpl	$0xc, %ecx
    8fa9:      	je	0x8fb4 <generic_fentry_filter_arg+0x2eb4>
    8fab:      	cmpl	$0xa, %ecx
    8fae:      	jne	0x93cd <generic_fentry_filter_arg+0x32cd>
    8fb4:      	movq	0x8(%rsp), %rcx
    8fb9:      	cmpq	%rdx, (%rcx)
    8fbc:      	jl	0x63c8 <generic_fentry_filter_arg+0x2c8>
    8fc2:      	jmp	0x944a <generic_fentry_filter_arg+0x334a>
    8fc7:      	movq	0x8(%rsp), %rcx
    8fcc:      	cmpq	%rdx, (%rcx)
    8fcf:      	je	0x9321 <generic_fentry_filter_arg+0x3221>
    8fd5:      	jmp	0x944a <generic_fentry_filter_arg+0x334a>
    8fda:      	cmpl	$0xc, %eax
    8fdd:      	jne	0x915c <generic_fentry_filter_arg+0x305c>
    8fe3:      	movq	0x8(%rsp), %rsi
    8fe8:      	movzbl	(%rsi), %esi
    8feb:      	testl	%esi, %edx
    8fed:      	jne	0x63c8 <generic_fentry_filter_arg+0x2c8>
    8ff3:      	jmp	0x915c <generic_fentry_filter_arg+0x305c>
    8ff8:      	cmpl	$0xc, %eax
    8ffb:      	jne	0x91ab <generic_fentry_filter_arg+0x30ab>
    9001:      	movq	0x8(%rsp), %rsi
    9006:      	movzwl	(%rsi), %esi
    9009:      	testl	%esi, %edx
    900b:      	jne	0x63c8 <generic_fentry_filter_arg+0x2c8>
    9011:      	jmp	0x91ab <generic_fentry_filter_arg+0x30ab>
    9016:      	cmpl	%eax, %esi
    9018:      	ja	0x620d <generic_fentry_filter_arg+0x10d>
    901e:      	cmpl	%edx, %eax
    9020:      	jbe	0x63c8 <generic_fentry_filter_arg+0x2c8>
    9026:      	jmp	0x620d <generic_fentry_filter_arg+0x10d>
    902b:      	cmpl	$0xc, %ecx
    902e:      	movq	0x8(%rsp), %rsi
    9033:      	je	0x903e <generic_fentry_filter_arg+0x2f3e>
    9035:      	cmpl	$0xa, %ecx
    9038:      	jne	0x93dd <generic_fentry_filter_arg+0x32dd>
    903e:      	cmpq	%rdx, (%rsi)
    9041:      	jg	0x63c8 <generic_fentry_filter_arg+0x2c8>
    9047:      	jmp	0x944a <generic_fentry_filter_arg+0x334a>
    904c:      	movl	$0x1, %eax
    9051:      	movq	(%rip), %rdi            # 0x9058 <generic_fentry_filter_arg+0x2f58>
    9058:      	leaq	0x40(%rsp), %rsi
    905d:      	jmp	0x9096 <generic_fentry_filter_arg+0x2f96>
    905f:      	movl	$0x1, %eax
    9064:      	leaq	0x40(%rsp), %rsi
    9069:      	movq	(%rip), %rdi            # 0x9070 <generic_fentry_filter_arg+0x2f70>
    9070:      	jmp	0x9096 <generic_fentry_filter_arg+0x2f96>
    9072:      	movl	$0x1, %eax
    9077:      	leaq	0x40(%rsp), %rsi
    907c:      	movq	(%rip), %rdi            # 0x9083 <generic_fentry_filter_arg+0x2f83>
    9083:      	jmp	0x9096 <generic_fentry_filter_arg+0x2f96>
    9085:      	movl	$0x1, %eax
    908a:      	leaq	0x40(%rsp), %rsi
    908f:      	movq	(%rip), %rdi            # 0x9096 <generic_fentry_filter_arg+0x2f96>
    9096:      	callq	*%rax
    9098:      	testq	%rax, %rax
    909b:      	je	0x90b6 <generic_fentry_filter_arg+0x2fb6>
    909d:      	movq	%rax, %rdi
    90a0:      	movl	$0x1, %eax
    90a5:      	movq	0x28(%rsp), %rsi
    90aa:      	callq	*%rax
    90ac:      	xorl	%ebx, %ebx
    90ae:      	testq	%rax, %rax
    90b1:      	setne	%bl
    90b4:      	jmp	0x90b8 <generic_fentry_filter_arg+0x2fb8>
    90b6:      	xorl	%ebx, %ebx
    90b8:      	movq	0x10(%rsp), %rdi
    90bd:      	movq	0x18(%rsp), %r9
    90c2:      	movq	0x20(%rsp), %r11
    90c7:      	movl	0x4(%r12), %eax
    90cc:      	cmpq	$0x25, %rax
    90d0:      	ja	0x63b7 <generic_fentry_filter_arg+0x2b7>
    90d6:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    90e0:      	btq	%rax, %rcx
    90e4:      	jb	0x93bd <generic_fentry_filter_arg+0x32bd>
    90ea:      	jmp	0x63b7 <generic_fentry_filter_arg+0x2b7>
    90ef:      	xorl	%ebx, %ebx
    90f1:      	movq	0x10(%rsp), %rdi
    90f6:      	movl	0x4(%r12), %eax
    90fb:      	cmpq	$0x25, %rax
    90ff:      	jbe	0x90d6 <generic_fentry_filter_arg+0x2fd6>
    9101:      	jmp	0x63b7 <generic_fentry_filter_arg+0x2b7>
    9106:      	cmpl	$0x2, %ebx
    9109:      	je	0x934a <generic_fentry_filter_arg+0x324a>
    910f:      	cmpl	$0x3, %ebx
    9112:      	jne	0x9384 <generic_fentry_filter_arg+0x3284>
    9118:      	movl	$0x1, %eax
    911d:      	movq	(%rip), %rdi            # 0x9124 <generic_fentry_filter_arg+0x3024>
    9124:      	jmp	0x9364 <generic_fentry_filter_arg+0x3264>
    9129:      	cmpl	$0x6, %ebx
    912c:      	je	0x9358 <generic_fentry_filter_arg+0x3258>
    9132:      	cmpl	$0x7, %ebx
    9135:      	jne	0x9384 <generic_fentry_filter_arg+0x3284>
    913b:      	movl	$0x1, %eax
    9140:      	movq	(%rip), %rdi            # 0x9147 <generic_fentry_filter_arg+0x3047>
    9147:      	jmp	0x9364 <generic_fentry_filter_arg+0x3264>
    914c:      	movq	0x8(%rsp), %rsi
    9151:      	movzbl	(%rsi), %esi
    9154:      	cmpl	%esi, %edx
    9156:      	jb	0x63c8 <generic_fentry_filter_arg+0x2c8>
    915c:      	cmpl	$0x15, %ecx
    915f:      	jb	0x944a <generic_fentry_filter_arg+0x334a>
    9165:      	movl	0x1c(%r12), %ecx
    916a:      	cmpl	$0x2, %eax
    916d:      	jle	0x92c4 <generic_fentry_filter_arg+0x31c4>
    9173:      	leal	-0x3(%rax), %edx
    9176:      	cmpl	$0x2, %edx
    9179:      	jb	0x9307 <generic_fentry_filter_arg+0x3207>
    917f:      	cmpl	$0x6, %eax
    9182:      	je	0x63c8 <generic_fentry_filter_arg+0x2c8>
    9188:      	cmpl	$0xc, %eax
    918b:      	jne	0x620d <generic_fentry_filter_arg+0x10d>
    9191:      	movq	0x8(%rsp), %rdx
    9196:      	movzbl	(%rdx), %edx
    9199:      	jmp	0x91e8 <generic_fentry_filter_arg+0x30e8>
    919b:      	movq	0x8(%rsp), %rsi
    91a0:      	movzwl	(%rsi), %esi
    91a3:      	cmpl	%esi, %edx
    91a5:      	jb	0x63c8 <generic_fentry_filter_arg+0x2c8>
    91ab:      	cmpl	$0x15, %ecx
    91ae:      	jb	0x944a <generic_fentry_filter_arg+0x334a>
    91b4:      	movl	0x1c(%r12), %ecx
    91b9:      	cmpl	$0x2, %eax
    91bc:      	jle	0x92e0 <generic_fentry_filter_arg+0x31e0>
    91c2:      	leal	-0x3(%rax), %edx
    91c5:      	cmpl	$0x2, %edx
    91c8:      	jb	0x9311 <generic_fentry_filter_arg+0x3211>
    91ce:      	cmpl	$0x6, %eax
    91d1:      	je	0x63c8 <generic_fentry_filter_arg+0x2c8>
    91d7:      	cmpl	$0xc, %eax
    91da:      	jne	0x620d <generic_fentry_filter_arg+0x10d>
    91e0:      	movq	0x8(%rsp), %rdx
    91e5:      	movzwl	(%rdx), %edx
    91e8:      	testl	%edx, %ecx
    91ea:      	jne	0x63c8 <generic_fentry_filter_arg+0x2c8>
    91f0:      	jmp	0x944a <generic_fentry_filter_arg+0x334a>
    91f5:      	movq	0x8(%rsp), %r8
    91fa:      	cmpl	%esi, (%r8)
    91fd:      	ja	0x63c8 <generic_fentry_filter_arg+0x2c8>
    9203:      	jmp	0x9213 <generic_fentry_filter_arg+0x3113>
    9205:      	movq	0x8(%rsp), %r8
    920a:      	cmpl	%esi, (%r8)
    920d:      	jb	0x63c8 <generic_fentry_filter_arg+0x2c8>
    9213:      	cmpl	$0x15, %edx
    9216:      	jb	0x944a <generic_fentry_filter_arg+0x334a>
    921c:      	movl	0x1c(%r12), %edx
    9221:      	cmpl	$0x2, %eax
    9224:      	jle	0x9252 <generic_fentry_filter_arg+0x3152>
    9226:      	leal	-0x3(%rax), %ecx
    9229:      	cmpl	$0x2, %ecx
    922c:      	jb	0x9289 <generic_fentry_filter_arg+0x3189>
    922e:      	cmpl	$0x6, %eax
    9231:      	je	0x63c8 <generic_fentry_filter_arg+0x2c8>
    9237:      	cmpl	$0xc, %eax
    923a:      	jne	0x620d <generic_fentry_filter_arg+0x10d>
    9240:      	movq	0x8(%rsp), %rcx
    9245:      	testl	%edx, (%rcx)
    9247:      	jne	0x63c8 <generic_fentry_filter_arg+0x2c8>
    924d:      	jmp	0x944a <generic_fentry_filter_arg+0x334a>
    9252:      	cmpl	$0x1, %eax
    9255:      	je	0x929b <generic_fentry_filter_arg+0x319b>
    9257:      	cmpl	$0x2, %eax
    925a:      	jne	0x620d <generic_fentry_filter_arg+0x10d>
    9260:      	cmpl	$0xc, %ecx
    9263:      	ja	0x942e <generic_fentry_filter_arg+0x332e>
    9269:      	movl	$0x1402, %esi           # imm = 0x1402
    926e:      	btl	%ecx, %esi
    9271:      	jae	0x942e <generic_fentry_filter_arg+0x332e>
    9277:      	movq	0x8(%rsp), %rcx
    927c:      	cmpl	%edx, (%rcx)
    927e:      	jl	0x63c8 <generic_fentry_filter_arg+0x2c8>
    9284:      	jmp	0x944a <generic_fentry_filter_arg+0x334a>
    9289:      	movq	0x8(%rsp), %rcx
    928e:      	cmpl	%edx, (%rcx)
    9290:      	je	0x9321 <generic_fentry_filter_arg+0x3221>
    9296:      	jmp	0x944a <generic_fentry_filter_arg+0x334a>
    929b:      	cmpl	$0xc, %ecx
    929e:      	ja	0x943d <generic_fentry_filter_arg+0x333d>
    92a4:      	movl	$0x1402, %esi           # imm = 0x1402
    92a9:      	btl	%ecx, %esi
    92ac:      	jae	0x943d <generic_fentry_filter_arg+0x333d>
    92b2:      	movq	0x8(%rsp), %rcx
    92b7:      	cmpl	%edx, (%rcx)
    92b9:      	jg	0x63c8 <generic_fentry_filter_arg+0x2c8>
    92bf:      	jmp	0x944a <generic_fentry_filter_arg+0x334a>
    92c4:      	cmpl	$0x1, %eax
    92c7:      	je	0x93e8 <generic_fentry_filter_arg+0x32e8>
    92cd:      	cmpl	$0x2, %eax
    92d0:      	jne	0x620d <generic_fentry_filter_arg+0x10d>
    92d6:      	movq	0x8(%rsp), %rdx
    92db:      	movzbl	(%rdx), %edx
    92de:      	jmp	0x92fa <generic_fentry_filter_arg+0x31fa>
    92e0:      	cmpl	$0x1, %eax
    92e3:      	je	0x93f2 <generic_fentry_filter_arg+0x32f2>
    92e9:      	cmpl	$0x2, %eax
    92ec:      	jne	0x620d <generic_fentry_filter_arg+0x10d>
    92f2:      	movq	0x8(%rsp), %rdx
    92f7:      	movzwl	(%rdx), %edx
    92fa:      	cmpl	%edx, %ecx
    92fc:      	ja	0x63c8 <generic_fentry_filter_arg+0x2c8>
    9302:      	jmp	0x944a <generic_fentry_filter_arg+0x334a>
    9307:      	movq	0x8(%rsp), %rdx
    930c:      	movzbl	(%rdx), %edx
    930f:      	jmp	0x9319 <generic_fentry_filter_arg+0x3219>
    9311:      	movq	0x8(%rsp), %rdx
    9316:      	movzwl	(%rdx), %edx
    9319:      	cmpl	%edx, %ecx
    931b:      	jne	0x944a <generic_fentry_filter_arg+0x334a>
    9321:      	xorl	%ebx, %ebx
    9323:      	cmpl	$0x3, %eax
    9326:      	sete	%bl
    9329:      	jmp	0x63b7 <generic_fentry_filter_arg+0x2b7>
    932e:      	movl	$0x1, %eax
    9333:      	movq	(%rip), %rdi            # 0x933a <generic_fentry_filter_arg+0x323a>
    933a:      	jmp	0x9364 <generic_fentry_filter_arg+0x3264>
    933c:      	movl	$0x1, %eax
    9341:      	movq	(%rip), %rdi            # 0x9348 <generic_fentry_filter_arg+0x3248>
    9348:      	jmp	0x9364 <generic_fentry_filter_arg+0x3264>
    934a:      	movl	$0x1, %eax
    934f:      	movq	(%rip), %rdi            # 0x9356 <generic_fentry_filter_arg+0x3256>
    9356:      	jmp	0x9364 <generic_fentry_filter_arg+0x3264>
    9358:      	movl	$0x1, %eax
    935d:      	movq	(%rip), %rdi            # 0x9364 <generic_fentry_filter_arg+0x3264>
    9364:      	callq	*%rax
    9366:      	testq	%rax, %rax
    9369:      	je	0x9384 <generic_fentry_filter_arg+0x3284>
    936b:      	movq	%rax, %rdi
    936e:      	movl	$0x1, %eax
    9373:      	movq	0x28(%rsp), %rsi
    9378:      	callq	*%rax
    937a:      	xorl	%ebx, %ebx
    937c:      	testq	%rax, %rax
    937f:      	setne	%bl
    9382:      	jmp	0x9386 <generic_fentry_filter_arg+0x3286>
    9384:      	xorl	%ebx, %ebx
    9386:      	movq	0x10(%rsp), %rdi
    938b:      	movq	0x18(%rsp), %r9
    9390:      	movq	0x20(%rsp), %r11
    9395:      	movl	0x4(%r12), %eax
    939a:      	cmpq	$0x25, %rax
    939e:      	ja	0x63b2 <generic_fentry_filter_arg+0x2b2>
    93a4:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    93ae:      	btq	%rax, %rcx
    93b2:      	movq	0x78(%rsp), %r13
    93b7:      	jae	0x63b7 <generic_fentry_filter_arg+0x2b7>
    93bd:      	xorl	%eax, %eax
    93bf:      	testq	%rbx, %rbx
    93c2:      	sete	%al
    93c5:      	movq	%rax, %rbx
    93c8:      	jmp	0x63b7 <generic_fentry_filter_arg+0x2b7>
    93cd:      	movq	0x8(%rsp), %rcx
    93d2:      	cmpq	%rdx, (%rcx)
    93d5:      	jb	0x63c8 <generic_fentry_filter_arg+0x2c8>
    93db:      	jmp	0x944a <generic_fentry_filter_arg+0x334a>
    93dd:      	cmpq	%rdx, (%rsi)
    93e0:      	ja	0x63c8 <generic_fentry_filter_arg+0x2c8>
    93e6:      	jmp	0x944a <generic_fentry_filter_arg+0x334a>
    93e8:      	movq	0x8(%rsp), %rdx
    93ed:      	movzbl	(%rdx), %edx
    93f0:      	jmp	0x93fa <generic_fentry_filter_arg+0x32fa>
    93f2:      	movq	0x8(%rsp), %rdx
    93f7:      	movzwl	(%rdx), %edx
    93fa:      	cmpl	%edx, %ecx
    93fc:      	jb	0x63c8 <generic_fentry_filter_arg+0x2c8>
    9402:      	jmp	0x944a <generic_fentry_filter_arg+0x334a>
    9404:      	xorl	%ebx, %ebx
    9406:      	movq	0x10(%rsp), %rdi
    940b:      	movq	0x18(%rsp), %r9
    9410:      	movq	0x20(%rsp), %r11
    9415:      	movq	0x68(%rsp), %r15
    941a:      	movl	0x4(%r12), %eax
    941f:      	cmpq	$0x25, %rax
    9423:      	jbe	0x8ef9 <generic_fentry_filter_arg+0x2df9>
    9429:      	jmp	0x63b7 <generic_fentry_filter_arg+0x2b7>
    942e:      	movq	0x8(%rsp), %rcx
    9433:      	cmpl	%edx, (%rcx)
    9435:      	jb	0x63c8 <generic_fentry_filter_arg+0x2c8>
    943b:      	jmp	0x944a <generic_fentry_filter_arg+0x334a>
    943d:      	movq	0x8(%rsp), %rcx
    9442:      	cmpl	%edx, (%rcx)
    9444:      	ja	0x63c8 <generic_fentry_filter_arg+0x2c8>
    944a:      	orl	$0x2, %eax
    944d:      	cmpl	$0x6, %eax
    9450:      	je	0x63c8 <generic_fentry_filter_arg+0x2c8>
    9456:      	jmp	0x620d <generic_fentry_filter_arg+0x10d>
    945b:      	nopl	(%rax,%rax)

0000000000009460 <generic_fentry_actions>:
    9460:      	pushq	%rbp
    9461:      	pushq	%r15
    9463:      	pushq	%r14
    9465:      	pushq	%r13
    9467:      	pushq	%r12
    9469:      	pushq	%rbx
    946a:      	subq	$0xa8, %rsp
    9471:      	movq	%rdi, 0x80(%rsp)
    9479:      	movl	$0x0, 0x88(%rsp)
    9484:      	movq	(%rip), %rdi            # 0x948b <generic_fentry_actions+0x2b>
    948b:      	leaq	0x88(%rsp), %rsi
    9493:      	movl	$0x1, %eax
    9498:      	callq	*%rax
    949a:      	testq	%rax, %rax
    949d:      	je	0x9f88 <generic_fentry_actions+0xb28>
    94a3:      	movq	%rax, %rsi
    94a6:      	movl	0x5f04(%rax), %ebx
    94ac:      	cmpl	$0x2, %ebx
    94af:      	jl	0x9f88 <generic_fentry_actions+0xb28>
    94b5:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    94bc:      	movq	(%rip), %rdi            # 0x94c3 <generic_fentry_actions+0x63>
    94c3:      	movl	$0x1, %eax
    94c8:      	callq	*%rax
    94ca:      	testq	%rax, %rax
    94cd:      	je	0x9f88 <generic_fentry_actions+0xb28>
    94d3:      	movq	%rax, %r14
    94d6:      	movl	%ebx, %eax
    94d8:      	andl	$0x7ff, %eax            # imm = 0x7FF
    94dd:      	addl	(%r14,%rax), %ebx
    94e1:      	movl	$0x0, 0x8c(%rsp)
    94ec:      	movq	(%rip), %rdi            # 0x94f3 <generic_fentry_actions+0x93>
    94f3:      	leaq	0x8c(%rsp), %rsi
    94fb:      	movl	$0x1, %eax
    9500:      	andl	$0x7ff, %ebx            # imm = 0x7FF
    9506:      	callq	*%rax
    9508:      	testq	%rax, %rax
    950b:      	je	0x9532 <generic_fentry_actions+0xd2>
    950d:      	cmpb	$0x0, (%rax)
    9510:      	sete	0x17(%rsp)
    9515:      	je	0x954d <generic_fentry_actions+0xed>
    9517:      	movl	$0x5, %eax
    951c:      	movq	%rax, 0x78(%rsp)
    9521:      	movl	$0x9, %eax
    9526:      	movq	%rax, 0x70(%rsp)
    952b:      	movl	$0x7, %eax
    9530:      	jmp	0x9566 <generic_fentry_actions+0x106>
    9532:      	movl	$0x4, %eax
    9537:      	movq	%rax, 0x78(%rsp)
    953c:      	movl	$0x8, %eax
    9541:      	movq	%rax, 0x70(%rsp)
    9546:      	movb	$0x1, 0x17(%rsp)
    954b:      	jmp	0x9561 <generic_fentry_actions+0x101>
    954d:      	movl	$0x4, %eax
    9552:      	movq	%rax, 0x78(%rsp)
    9557:      	movl	$0x8, %eax
    955c:      	movq	%rax, 0x70(%rsp)
    9561:      	movl	$0x6, %eax
    9566:      	movq	%rax, 0x68(%rsp)
    956b:      	addq	%rbx, %r14
    956e:      	movb	$0x1, %al
    9570:      	movl	%eax, 0x44(%rsp)
    9574:      	movq	(%rip), %rbp            # 0x957b <generic_fentry_actions+0x11b>
    957b:      	xorl	%r12d, %r12d
    957e:      	xorl	%r15d, %r15d
    9581:      	jmp	0x95aa <generic_fentry_actions+0x14a>
    9583:      	incl	%r15d
    9586:      	movl	0x4(%r14,%r15,4), %eax
    958b:      	movl	%eax, 0x78(%rdx)
    958e:      	nop
    9590:      	movq	%r13, 0x70(%rdx)
    9594:      	incl	%r15d
    9597:      	movl	%r15d, %ebx
    959a:      	incl	%r12d
    959d:      	movl	%ebx, %r15d
    95a0:      	cmpl	$0x3, %r12d
    95a4:      	je	0x9f61 <generic_fentry_actions+0xb01>
    95aa:      	leal	0x4(,%r15,4), %eax
    95b2:      	cmpl	(%r14), %eax
    95b5:      	jae	0x9f61 <generic_fentry_actions+0xb01>
    95bb:      	movl	%r15d, %eax
    95be:      	movslq	0x4(%r14,%rax,4), %r13
    95c3:      	movl	$0x0, 0x90(%rsp)
    95ce:      	movl	$0x1, %eax
    95d3:      	leaq	0x90(%rsp), %rsi
    95db:      	movq	%rbp, %rdi
    95de:      	callq	*%rax
    95e0:      	xorl	%ebx, %ebx
    95e2:      	testq	%rax, %rax
    95e5:      	je	0x959a <generic_fentry_actions+0x13a>
    95e7:      	movq	%rax, %rdx
    95ea:      	cmpl	$0x7, %r13d
    95ee:      	jg	0x9620 <generic_fentry_actions+0x1c0>
    95f0:      	cmpl	$0x3, %r13d
    95f4:      	jg	0x9676 <generic_fentry_actions+0x216>
    95fa:      	cmpl	$0x1, %r13d
    95fe:      	jg	0x97c7 <generic_fentry_actions+0x367>
    9604:      	testl	%r13d, %r13d
    9607:      	je	0x99d7 <generic_fentry_actions+0x577>
    960d:      	cmpl	$0x1, %r13d
    9611:      	je	0x97e0 <generic_fentry_actions+0x380>
    9617:      	jmp	0x9590 <generic_fentry_actions+0x130>
    961c:      	nopl	(%rax)
    9620:      	cmpl	$0xb, %r13d
    9624:      	jg	0x9790 <generic_fentry_actions+0x330>
    962a:      	leal	-0xa(%r13), %eax
    962e:      	cmpl	$0x2, %eax
    9631:      	jb	0x986f <generic_fentry_actions+0x40f>
    9637:      	cmpl	$0x8, %r13d
    963b:      	je	0x9931 <generic_fentry_actions+0x4d1>
    9641:      	cmpl	$0x9, %r13d
    9645:      	jne	0x9590 <generic_fentry_actions+0x130>
    964b:      	movq	%r13, 0x8(%rsp)
    9650:      	movq	%r14, %rax
    9653:      	movq	%rbp, %r13
    9656:      	incl	%r15d
    9659:      	movl	0x4(%r14,%r15,4), %eax
    965e:      	movq	%rdx, %rbp
    9661:      	movl	$0x3, %ebx
    9666:      	cmpb	$0x0, 0x17(%rsp)
    966b:      	jne	0x9ab3 <generic_fentry_actions+0x653>
    9671:      	jmp	0x9ad8 <generic_fentry_actions+0x678>
    9676:      	leal	-0x6(%r13), %eax
    967a:      	cmpl	$0x2, %eax
    967d:      	jb	0x9583 <generic_fentry_actions+0x123>
    9683:      	cmpl	$0x4, %r13d
    9687:      	je	0x993e <generic_fentry_actions+0x4de>
    968d:      	cmpl	$0x5, %r13d
    9691:      	jne	0x9590 <generic_fentry_actions+0x130>
    9697:      	leal	0x1(%r15), %eax
    969b:      	movl	0x4(%r14,%rax,4), %eax
    96a0:      	addl	$0x2, %r15d
    96a4:      	movl	0x4(%r14,%r15,4), %ebx
    96a9:      	movq	$0x0, 0x20(%rsp)
    96b2:      	movq	$0x0, 0x18(%rsp)
    96bb:      	andl	$0x7, %eax
    96be:      	cmpl	$0x4, %eax
    96c1:      	ja	0x9590 <generic_fentry_actions+0x130>
    96c7:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    96cf:      	jne	0x9590 <generic_fentry_actions+0x130>
    96d5:      	movq	0x5e78(%rdx,%rax,8), %rax
    96dd:      	andl	$0x7ff, %eax            # imm = 0x7FF
    96e2:      	movl	0x90(%rdx,%rax), %eax
    96e9:      	movl	%eax, 0x20(%rsp)
    96ed:      	movl	$0xe, %eax
    96f2:      	movq	%rdx, 0x8(%rsp)
    96f7:      	callq	*%rax
    96f9:      	shrq	$0x20, %rax
    96fd:      	movq	%rax, 0x18(%rsp)
    9702:      	movl	$0x1, %eax
    9707:      	leaq	0x18(%rsp), %rsi
    970c:      	movq	(%rip), %rdi            # 0x9713 <generic_fentry_actions+0x2b3>
    9713:      	callq	*%rax
    9715:      	movq	0x8(%rsp), %rdx
    971a:      	testq	%rax, %rax
    971d:      	je	0x9590 <generic_fentry_actions+0x130>
    9723:      	andl	$0x7, %ebx
    9726:      	cmpl	$0x4, %ebx
    9729:      	ja	0x9590 <generic_fentry_actions+0x130>
    972f:      	cmpl	$0x0, 0x5ea0(%rdx,%rbx,4)
    9737:      	jne	0x9590 <generic_fentry_actions+0x130>
    973d:      	movq	0x5e78(%rdx,%rbx,8), %rcx
    9745:      	movl	$0x0, 0x24(%rsp)
    974d:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    9753:      	movl	0x90(%rdx,%rcx), %ecx
    975a:      	movl	%ecx, 0x20(%rsp)
    975e:      	movq	%rax, %rbx
    9761:      	movl	$0xe, %eax
    9766:      	callq	*%rax
    9768:      	shrq	$0x20, %rax
    976c:      	movq	%rax, 0x18(%rsp)
    9771:      	movl	$0x2, %eax
    9776:      	xorl	%ecx, %ecx
    9778:      	leaq	0x18(%rsp), %rsi
    977d:      	movq	(%rip), %rdi            # 0x9784 <generic_fentry_actions+0x324>
    9784:      	movq	%rbx, %rdx
    9787:      	xorl	%ecx, %ecx
    9789:      	callq	*%rax
    978b:      	jmp	0x99cd <generic_fentry_actions+0x56d>
    9790:      	cmpl	$0xc, %r13d
    9794:      	je	0x9ac4 <generic_fentry_actions+0x664>
    979a:      	cmpl	$0xd, %r13d
    979e:      	je	0x9956 <generic_fentry_actions+0x4f6>
    97a4:      	cmpl	$0xe, %r13d
    97a8:      	jne	0x9590 <generic_fentry_actions+0x130>
    97ae:      	movq	%r13, 0x8(%rsp)
    97b3:      	movq	%rbp, %r13
    97b6:      	movq	%rdx, %rbp
    97b9:      	addl	$0x2, %r15d
    97bd:      	movq	0x70(%rsp), %rbx
    97c2:      	jmp	0x9ad8 <generic_fentry_actions+0x678>
    97c7:      	movl	$0x9, %eax
    97cc:      	cmpl	$0x2, %r13d
    97d0:      	je	0x9a9c <generic_fentry_actions+0x63c>
    97d6:      	cmpl	$0x3, %r13d
    97da:      	jne	0x9590 <generic_fentry_actions+0x130>
    97e0:      	movq	%rdx, 0x8(%rsp)
    97e5:      	leal	0x1(%r15), %eax
    97e9:      	movq	%r14, %rcx
    97ec:      	movl	0x4(%r14,%rax,4), %r14d
    97f1:      	addl	$0x2, %r15d
    97f5:      	movq	%rcx, %rbp
    97f8:      	movl	0x4(%rcx,%r15,4), %eax
    97fd:      	movq	%rax, 0x38(%rsp)
    9802:      	movq	$0x0, 0x20(%rsp)
    980b:      	movq	$0x0, 0x18(%rsp)
    9814:      	movl	$0x0, 0x28(%rsp)
    981c:      	movl	$0x1, %eax
    9821:      	leaq	0x28(%rsp), %rsi
    9826:      	movq	(%rip), %rdi            # 0x982d <generic_fentry_actions+0x3cd>
    982d:      	callq	*%rax
    982f:      	xorl	%ecx, %ecx
    9831:      	testq	%rax, %rax
    9834:      	je	0x9c68 <generic_fentry_actions+0x808>
    983a:      	andl	$0x7, %r14d
    983e:      	cmpl	$0x4, %r14d
    9842:      	movq	0x8(%rsp), %rdx
    9847:      	ja	0x9858 <generic_fentry_actions+0x3f8>
    9849:      	cmpl	$0x0, 0x5ea0(%rdx,%r14,4)
    9852:      	je	0x9b0d <generic_fentry_actions+0x6ad>
    9858:      	movq	%rbp, %r14
    985b:      	movq	(%rip), %rbp            # 0x9862 <generic_fentry_actions+0x402>
    9862:      	testl	%ecx, %ecx
    9864:      	jne	0x959a <generic_fentry_actions+0x13a>
    986a:      	jmp	0x9590 <generic_fentry_actions+0x130>
    986f:      	incl	%r15d
    9872:      	movl	0x4(%r14,%r15,4), %eax
    9877:      	andl	$0x7, %eax
    987a:      	xorl	%ecx, %ecx
    987c:      	cmpl	$0x4, %eax
    987f:      	ja	0x9c77 <generic_fentry_actions+0x817>
    9885:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    988d:      	jne	0x9c77 <generic_fentry_actions+0x817>
    9893:      	movq	0x5e78(%rdx,%rax,8), %rax
    989b:      	andl	$0x7ff, %eax            # imm = 0x7FF
    98a0:      	movq	0xb8(%rdx,%rax), %rax
    98a8:      	movq	%rax, 0x28(%rsp)
    98ad:      	testq	%rax, %rax
    98b0:      	je	0x9c77 <generic_fentry_actions+0x817>
    98b6:      	movq	%rdx, 0x8(%rsp)
    98bb:      	cmpl	$0xa, %r13d
    98bf:      	jne	0x9c84 <generic_fentry_actions+0x824>
    98c5:      	movl	$0xe, %eax
    98ca:      	callq	*%rax
    98cc:      	movq	%rax, 0x38(%rsp)
    98d1:      	shrq	$0x20, %rax
    98d5:      	movl	%eax, 0x18(%rsp)
    98d9:      	movl	$0x1, %eax
    98de:      	leaq	0x18(%rsp), %rsi
    98e3:      	movq	(%rip), %rdi            # 0x98ea <generic_fentry_actions+0x48a>
    98ea:      	callq	*%rax
    98ec:      	xorl	%ecx, %ecx
    98ee:      	testq	%rax, %rax
    98f1:      	movq	0x8(%rsp), %rdx
    98f6:      	je	0x9c77 <generic_fentry_actions+0x817>
    98fc:      	movl	(%rax), %ecx
    98fe:      	movl	%ecx, 0x18(%rsp)
    9902:      	movq	0x38(%rsp), %rcx
    9907:      	movl	%ecx, 0x1c(%rsp)
    990b:      	movq	0x8(%rax), %rax
    990f:      	movq	%rax, 0x20(%rsp)
    9914:      	xorl	%ecx, %ecx
    9916:      	movl	$0x2, %eax
    991b:      	leaq	0x28(%rsp), %rsi
    9920:      	leaq	0x18(%rsp), %rdx
    9925:      	movq	(%rip), %rdi            # 0x992c <generic_fentry_actions+0x4cc>
    992c:      	jmp	0x9bd0 <generic_fentry_actions+0x770>
    9931:      	movl	$0x0, 0x44(%rsp)
    9939:      	jmp	0x9590 <generic_fentry_actions+0x130>
    993e:      	movq	%r13, 0x8(%rsp)
    9943:      	movq	%rbp, %r13
    9946:      	movq	%rdx, %rbp
    9949:      	incl	%r15d
    994c:      	movq	0x78(%rsp), %rbx
    9951:      	jmp	0x9ad8 <generic_fentry_actions+0x678>
    9956:      	movq	%rdx, 0x8(%rsp)
    995b:      	movl	$0xe, %eax
    9960:      	callq	*%rax
    9962:      	movq	%rax, 0x50(%rsp)
    9967:      	movl	$0x1, %eax
    996c:      	leaq	0x50(%rsp), %rsi
    9971:      	movq	(%rip), %rdi            # 0x9978 <generic_fentry_actions+0x518>
    9978:      	callq	*%rax
    997a:      	testq	%rax, %rax
    997d:      	je	0x99cd <generic_fentry_actions+0x56d>
    997f:      	movq	0x4(%rax), %rax
    9983:      	movq	%rax, 0x28(%rsp)
    9988:      	movl	$0x2, 0x30(%rsp)
    9990:      	movl	$0x1, %eax
    9995:      	leaq	0x28(%rsp), %rsi
    999a:      	movq	(%rip), %rbx            # 0x99a1 <generic_fentry_actions+0x541>
    99a1:      	movq	%rbx, %rdi
    99a4:      	callq	*%rax
    99a6:      	movl	$0x1, 0x5c(%rsp)
    99ae:      	testq	%rax, %rax
    99b1:      	je	0x9be8 <generic_fentry_actions+0x788>
    99b7:      	lock
    99b8:      	incl	(%rax)
    99ba:      	movl	$0x3, %eax
    99bf:      	leaq	0x50(%rsp), %rsi
    99c4:      	movq	(%rip), %rdi            # 0x99cb <generic_fentry_actions+0x56b>
    99cb:      	callq	*%rax
    99cd:      	movq	0x8(%rsp), %rdx
    99d2:      	jmp	0x9590 <generic_fentry_actions+0x130>
    99d7:      	movq	%rdx, 0x8(%rsp)
    99dc:      	leal	0x1(%r15), %eax
    99e0:      	movl	0x4(%r14,%rax,4), %ebx
    99e5:      	leal	0x2(%r15), %eax
    99e9:      	movl	0x4(%r14,%rax,4), %eax
    99ee:      	movl	%eax, 0x60(%rsp)
    99f2:      	movl	$0x7d, %eax
    99f7:      	callq	*%rax
    99f9:      	movq	%rax, 0x18(%rsp)
    99fe:      	movl	$0x0, 0x50(%rsp)
    9a06:      	movq	%rbx, 0xa0(%rsp)
    9a0e:      	testq	%rbx, %rbx
    9a11:      	je	0x9e88 <generic_fentry_actions+0xa28>
    9a17:      	movl	$0x1, %eax
    9a1c:      	movq	(%rip), %rdi            # 0x9a23 <generic_fentry_actions+0x5c3>
    9a23:      	leaq	0x50(%rsp), %rsi
    9a28:      	callq	*%rax
    9a2a:      	testq	%rax, %rax
    9a2d:      	je	0x9e88 <generic_fentry_actions+0xa28>
    9a33:      	movq	%rax, 0x48(%rsp)
    9a38:      	movq	%rax, %rbx
    9a3b:      	movl	$0x1, %eax
    9a40:      	leaq	0x50(%rsp), %rsi
    9a45:      	movq	(%rip), %rdi            # 0x9a4c <generic_fentry_actions+0x5ec>
    9a4c:      	callq	*%rax
    9a4e:      	movq	%rax, %rdx
    9a51:      	movq	0x8(%rsp), %rcx
    9a56:      	movq	0x60(%rcx), %rax
    9a5a:      	movq	%rax, (%rbx)
    9a5d:      	movq	0x70(%rcx), %rax
    9a61:      	movq	%rax, 0x8(%rbx)
    9a65:      	xorl	%eax, %eax
    9a67:      	movq	%rax, 0x38(%rsp)
    9a6c:      	movl	$0x0, %eax
    9a71:      	movl	0x60(%rsp), %esi
    9a75:      	cmpl	$0x2, %esi
    9a78:      	je	0x9caf <generic_fentry_actions+0x84f>
    9a7e:      	cmpl	$0x1, %esi
    9a81:      	je	0x9cac <generic_fentry_actions+0x84c>
    9a87:      	testl	%esi, %esi
    9a89:      	jne	0x9e88 <generic_fentry_actions+0xa28>
    9a8f:      	movq	0x8(%rsp), %rax
    9a94:      	movl	0x7c(%rax), %eax
    9a97:      	jmp	0x9caf <generic_fentry_actions+0x84f>
    9a9c:      	movq	%r13, 0x8(%rsp)
    9aa1:      	movq	%rbp, %r13
    9aa4:      	movq	%rdx, %rbp
    9aa7:      	movl	$0x3, %ebx
    9aac:      	cmpb	$0x0, 0x17(%rsp)
    9ab1:      	je	0x9ad8 <generic_fentry_actions+0x678>
    9ab3:      	movslq	%eax, %rdi
    9ab6:      	movl	$0x6d, %eax
    9abb:      	callq	*%rax
    9abd:      	movl	$0x2, %ebx
    9ac2:      	jmp	0x9ad8 <generic_fentry_actions+0x678>
    9ac4:      	movq	%r13, 0x8(%rsp)
    9ac9:      	movq	%rbp, %r13
    9acc:      	movq	%rdx, %rbp
    9acf:      	addl	$0x3, %r15d
    9ad3:      	movq	0x68(%rsp), %rbx
    9ad8:      	movl	$0x0, 0x18(%rsp)
    9ae0:      	movl	$0x1, %eax
    9ae5:      	leaq	0x18(%rsp), %rsi
    9aea:      	movq	(%rip), %rdi            # 0x9af1 <generic_fentry_actions+0x691>
    9af1:      	callq	*%rax
    9af3:      	testq	%rax, %rax
    9af6:      	je	0x9afd <generic_fentry_actions+0x69d>
    9af8:      	lock
    9af9:      	incq	(%rax,%rbx,8)
    9afd:      	movq	%rbp, %rdx
    9b00:      	movq	%r13, %rbp
    9b03:      	movq	0x8(%rsp), %r13
    9b08:      	jmp	0x9590 <generic_fentry_actions+0x130>
    9b0d:      	movq	%rax, 0x48(%rsp)
    9b12:      	movq	0x5e78(%rdx,%r14,8), %rax
    9b1a:      	movl	$0x0, 0x24(%rsp)
    9b22:      	andl	$0x7ff, %eax            # imm = 0x7FF
    9b27:      	movl	0x90(%rdx,%rax), %eax
    9b2e:      	movl	%eax, 0x20(%rsp)
    9b32:      	movl	$0xe, %eax
    9b37:      	callq	*%rax
    9b39:      	shrq	$0x20, %rax
    9b3d:      	movq	%rax, 0x18(%rsp)
    9b42:      	cmpl	$0x1, %r13d
    9b46:      	jne	0x9c52 <generic_fentry_actions+0x7f2>
    9b4c:      	movq	0x38(%rsp), %rax
    9b51:      	andl	$0x7, %eax
    9b54:      	cmpl	$0x4, %eax
    9b57:      	movq	%rbp, %r14
    9b5a:      	movl	$0x0, %ecx
    9b5f:      	ja	0x9c6b <generic_fentry_actions+0x80b>
    9b65:      	movq	0x8(%rsp), %rdx
    9b6a:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    9b72:      	movq	(%rip), %rbp            # 0x9b79 <generic_fentry_actions+0x719>
    9b79:      	jne	0x9c77 <generic_fentry_actions+0x817>
    9b7f:      	movq	0x5e78(%rdx,%rax,8), %rax
    9b87:      	andl	$0x7ff, %eax            # imm = 0x7FF
    9b8c:      	addq	%rax, %rdx
    9b8f:      	addq	$0x90, %rdx
    9b96:      	movq	0x8(%rsp), %rcx
    9b9b:      	movl	0x90(%rcx,%rax), %esi
    9ba2:      	andl	$0xfff, %esi            # imm = 0xFFF
    9ba8:      	addq	$0x8, %rsi
    9bac:      	movl	$0x4, %eax
    9bb1:      	movq	0x48(%rsp), %rdi
    9bb6:      	callq	*%rax
    9bb8:      	xorl	%ecx, %ecx
    9bba:      	movl	$0x2, %eax
    9bbf:      	leaq	0x18(%rsp), %rsi
    9bc4:      	movq	(%rip), %rdi            # 0x9bcb <generic_fentry_actions+0x76b>
    9bcb:      	movq	0x48(%rsp), %rdx
    9bd0:      	xorl	%ecx, %ecx
    9bd2:      	callq	*%rax
    9bd4:      	xorl	%ecx, %ecx
    9bd6:      	movq	0x8(%rsp), %rdx
    9bdb:      	testl	%ecx, %ecx
    9bdd:      	jne	0x959a <generic_fentry_actions+0x13a>
    9be3:      	jmp	0x9590 <generic_fentry_actions+0x130>
    9be8:      	movl	$0x2, %eax
    9bed:      	movl	$0x1, %ecx
    9bf2:      	leaq	0x5c(%rsp), %rdx
    9bf7:      	leaq	0x28(%rsp), %rsi
    9bfc:      	movq	%rbx, %rdi
    9bff:      	callq	*%rax
    9c01:      	testq	%rax, %rax
    9c04:      	je	0x99ba <generic_fentry_actions+0x55a>
    9c0a:      	movq	%rax, 0x38(%rsp)
    9c0f:      	negl	%eax
    9c11:      	movw	%ax, 0x18(%rsp)
    9c16:      	movw	$0x3, 0x1a(%rsp)
    9c1d:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    9c27:      	movq	%rax, 0x1c(%rsp)
    9c2c:      	movl	$0x1, %eax
    9c31:      	leaq	0x18(%rsp), %rsi
    9c36:      	movq	(%rip), %rbx            # 0x9c3d <generic_fentry_actions+0x7dd>
    9c3d:      	movq	%rbx, %rdi
    9c40:      	callq	*%rax
    9c42:      	testq	%rax, %rax
    9c45:      	je	0x9f08 <generic_fentry_actions+0xaa8>
    9c4b:      	incl	(%rax)
    9c4d:      	jmp	0x9f2e <generic_fentry_actions+0xace>
    9c52:      	movl	$0x3, %eax
    9c57:      	leaq	0x18(%rsp), %rsi
    9c5c:      	movq	(%rip), %rdi            # 0x9c63 <generic_fentry_actions+0x803>
    9c63:      	callq	*%rax
    9c65:      	movq	%rax, %rcx
    9c68:      	movq	%rbp, %r14
    9c6b:      	movq	(%rip), %rbp            # 0x9c72 <generic_fentry_actions+0x812>
    9c72:      	movq	0x8(%rsp), %rdx
    9c77:      	testl	%ecx, %ecx
    9c79:      	jne	0x959a <generic_fentry_actions+0x13a>
    9c7f:      	jmp	0x9590 <generic_fentry_actions+0x130>
    9c84:      	movl	$0x3, %eax
    9c89:      	leaq	0x28(%rsp), %rsi
    9c8e:      	movq	(%rip), %rdi            # 0x9c95 <generic_fentry_actions+0x835>
    9c95:      	callq	*%rax
    9c97:      	movq	%rax, %rcx
    9c9a:      	movq	0x8(%rsp), %rdx
    9c9f:      	testl	%ecx, %ecx
    9ca1:      	jne	0x959a <generic_fentry_actions+0x13a>
    9ca7:      	jmp	0x9590 <generic_fentry_actions+0x130>
    9cac:      	movl	0x10(%rcx), %eax
    9caf:      	movq	%r14, 0x60(%rsp)
    9cb4:      	movl	%eax, %eax
    9cb6:      	movq	%rbx, 0x98(%rsp)
    9cbe:      	movq	%rax, 0x10(%rbx)
    9cc2:      	movq	0x48(%rsp), %rdi
    9cc7:      	addq	$0x18, %rdi
    9ccb:      	movl	$0x4, %eax
    9cd0:      	movl	$0xc8, %ecx
    9cd5:      	movq	%rdi, 0x48(%rsp)
    9cda:      	movl	$0xc8, %esi
    9cdf:      	callq	*%rax
    9ce1:      	xorl	%r14d, %r14d
    9ce4:      	leaq	0x28(%rsp), %rbx
    9ce9:      	jmp	0x9d03 <generic_fentry_actions+0x8a3>
    9ceb:      	nopl	(%rax,%rax)
    9cf0:      	leaq	0x28(%rsp), %rbx
    9cf5:      	addq	$0x4, %r14
    9cf9:      	cmpq	$0x14, %r14
    9cfd:      	je	0x9e2b <generic_fentry_actions+0x9cb>
    9d03:      	movl	$0x0, 0x28(%rsp)
    9d0b:      	movl	$0x1, %eax
    9d10:      	movq	%rbp, %rdi
    9d13:      	movq	%rbx, %rsi
    9d16:      	callq	*%rax
    9d18:      	testq	%rax, %rax
    9d1b:      	je	0x9e2b <generic_fentry_actions+0x9cb>
    9d21:      	movq	%rax, %rsi
    9d24:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    9d2b:      	movl	$0x1, %eax
    9d30:      	movq	(%rip), %rdi            # 0x9d37 <generic_fentry_actions+0x8d7>
    9d37:      	callq	*%rax
    9d39:      	testq	%rax, %rax
    9d3c:      	je	0x9e2b <generic_fentry_actions+0x9cb>
    9d42:      	cmpl	$-0x1, 0x40(%rax,%r14)
    9d48:      	movq	0x8(%rsp), %rdx
    9d4d:      	je	0x9e2b <generic_fentry_actions+0x9cb>
    9d53:      	movq	0x5e78(%rdx,%r14,2), %rax
    9d5b:      	movl	0x4(%rdx), %ecx
    9d5e:      	cmpq	%rcx, %rax
    9d61:      	jge	0x9e2b <generic_fentry_actions+0x9cb>
    9d67:      	cmpq	$0x10, %r14
    9d6b:      	je	0x9dd2 <generic_fentry_actions+0x972>
    9d6d:      	movl	$0x0, 0x28(%rsp)
    9d75:      	movl	$0x1, %eax
    9d7a:      	movq	%rbp, %rdi
    9d7d:      	movq	%rbx, %rsi
    9d80:      	callq	*%rax
    9d82:      	testq	%rax, %rax
    9d85:      	je	0x9dc5 <generic_fentry_actions+0x965>
    9d87:      	movq	%rax, %rsi
    9d8a:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    9d91:      	movl	$0x1, %eax
    9d96:      	movq	(%rip), %rdi            # 0x9d9d <generic_fentry_actions+0x93d>
    9d9d:      	callq	*%rax
    9d9f:      	testq	%rax, %rax
    9da2:      	je	0x9dc5 <generic_fentry_actions+0x965>
    9da4:      	cmpl	$-0x1, 0x44(%rax,%r14)
    9daa:      	movq	0x8(%rsp), %rdx
    9daf:      	movq	0x5e78(%rdx,%r14,2), %rax
    9db7:      	je	0x9dd2 <generic_fentry_actions+0x972>
    9db9:      	movl	0x5e80(%rdx,%r14,2), %ebx
    9dc1:      	subl	%eax, %ebx
    9dc3:      	jmp	0x9dda <generic_fentry_actions+0x97a>
    9dc5:      	movq	0x8(%rsp), %rdx
    9dca:      	movq	0x5e78(%rdx,%r14,2), %rax
    9dd2:      	movl	0x4(%rdx), %ebx
    9dd5:      	subl	%eax, %ebx
    9dd7:      	addl	$0x4, %ebx
    9dda:      	testl	%ebx, %ebx
    9ddc:      	jle	0x9cf0 <generic_fentry_actions+0x890>
    9de2:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    9de7:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    9dec:      	cmpl	$0x28, %ebx
    9def:      	movl	$0x28, %ecx
    9df4:      	cmovgel	%ecx, %ebx
    9df7:      	movzbl	0x38(%rsp), %ebp
    9dfc:      	movq	0x48(%rsp), %rcx
    9e01:      	leaq	(%rcx,%rbp), %rdi
    9e05:      	addq	%rax, %rdx
    9e08:      	addq	$0x90, %rdx
    9e0f:      	movl	$0x4, %eax
    9e14:      	movl	%ebx, %esi
    9e16:      	callq	*%rax
    9e18:      	addl	%ebp, %ebx
    9e1a:      	movq	(%rip), %rbp            # 0x9e21 <generic_fentry_actions+0x9c1>
    9e21:      	movq	%rbx, 0x38(%rsp)
    9e26:      	jmp	0x9cf0 <generic_fentry_actions+0x890>
    9e2b:      	movl	$0x1, %eax
    9e30:      	movq	(%rip), %rdi            # 0x9e37 <generic_fentry_actions+0x9d7>
    9e37:      	movq	0x98(%rsp), %rbx
    9e3f:      	movq	%rbx, %rsi
    9e42:      	callq	*%rax
    9e44:      	testq	%rax, %rax
    9e47:      	movq	0x60(%rsp), %r14
    9e4c:      	je	0x9e6e <generic_fentry_actions+0xa0e>
    9e4e:      	imulq	$-0xf4240, 0xa0(%rsp), %rcx # imm = 0xFFF0BDC0
    9e5a:      	addq	0x18(%rsp), %rcx
    9e5f:      	cmpq	%rcx, (%rax)
    9e62:      	jbe	0x9e6e <generic_fentry_actions+0xa0e>
    9e64:      	movl	$0x0, 0x44(%rsp)
    9e6c:      	jmp	0x9e88 <generic_fentry_actions+0xa28>
    9e6e:      	movl	$0x2, %eax
    9e73:      	xorl	%ecx, %ecx
    9e75:      	movq	(%rip), %rdi            # 0x9e7c <generic_fentry_actions+0xa1c>
    9e7c:      	leaq	0x18(%rsp), %rdx
    9e81:      	movq	%rbx, %rsi
    9e84:      	xorl	%ecx, %ecx
    9e86:      	callq	*%rax
    9e88:      	leal	0x3(%r15), %eax
    9e8c:      	cmpl	$0x0, 0x4(%r14,%rax,4)
    9e92:      	movq	0x8(%rsp), %rdx
    9e97:      	je	0x9ec3 <generic_fentry_actions+0xa63>
    9e99:      	orb	$0x2, 0x1(%rdx)
    9e9d:      	movl	$0x1b, %eax
    9ea2:      	movq	0x80(%rsp), %rdi
    9eaa:      	xorl	%ecx, %ecx
    9eac:      	movq	(%rip), %rsi            # 0x9eb3 <generic_fentry_actions+0xa53>
    9eb3:      	xorl	%edx, %edx
    9eb5:      	callq	*%rax
    9eb7:      	movq	0x8(%rsp), %rdx
    9ebc:      	movq	%rax, 0x80(%rdx)
    9ec3:      	addl	$0x4, %r15d
    9ec7:      	cmpl	$0x0, 0x4(%r14,%r15,4)
    9ecd:      	je	0x9590 <generic_fentry_actions+0x130>
    9ed3:      	orb	$0x4, 0x1(%rdx)
    9ed7:      	movl	$0x1b, %eax
    9edc:      	movq	0x80(%rsp), %rdi
    9ee4:      	movq	(%rip), %rsi            # 0x9eeb <generic_fentry_actions+0xa8b>
    9eeb:      	movl	$0x100, %ecx            # imm = 0x100
    9ef0:      	movl	$0x100, %edx            # imm = 0x100
    9ef5:      	callq	*%rax
    9ef7:      	movq	0x8(%rsp), %rdx
    9efc:      	movq	%rax, 0x88(%rdx)
    9f03:      	jmp	0x9590 <generic_fentry_actions+0x130>
    9f08:      	movl	$0x1, 0x94(%rsp)
    9f13:      	movl	$0x2, %eax
    9f18:      	xorl	%ecx, %ecx
    9f1a:      	leaq	0x94(%rsp), %rdx
    9f22:      	leaq	0x18(%rsp), %rsi
    9f27:      	movq	%rbx, %rdi
    9f2a:      	xorl	%ecx, %ecx
    9f2c:      	callq	*%rax
    9f2e:      	cmpl	$0x0, 0x38(%rsp)
    9f33:      	je	0x99ba <generic_fentry_actions+0x55a>
    9f39:      	movl	$0x1, %eax
    9f3e:      	leaq	0x28(%rsp), %rsi
    9f43:      	movq	(%rip), %rdi            # 0x9f4a <generic_fentry_actions+0xaea>
    9f4a:      	callq	*%rax
    9f4c:      	testq	%rax, %rax
    9f4f:      	je	0x99ba <generic_fentry_actions+0x55a>
    9f55:      	movl	0x5c(%rsp), %ecx
    9f59:      	lock
    9f5a:      	addl	%ecx, (%rax)
    9f5c:      	jmp	0x99ba <generic_fentry_actions+0x55a>
    9f61:      	cmpb	$0x0, 0x44(%rsp)
    9f66:      	je	0x9f88 <generic_fentry_actions+0xb28>
    9f68:      	movq	(%rip), %rsi            # 0x9f6f <generic_fentry_actions+0xb0f>
    9f6f:      	movl	$0x5, %ecx
    9f74:      	movl	$0xc, %eax
    9f79:      	movq	0x80(%rsp), %rdi
    9f81:      	movl	$0x5, %edx
    9f86:      	callq	*%rax
    9f88:      	xorl	%eax, %eax
    9f8a:      	addq	$0xa8, %rsp
    9f91:      	popq	%rbx
    9f92:      	popq	%r12
    9f94:      	popq	%r13
    9f96:      	popq	%r14
    9f98:      	popq	%r15
    9f9a:      	popq	%rbp
    9f9b:      	retq
    9f9c:      	nopl	(%rax)

0000000000009fa0 <generic_fentry_output>:
    9fa0:      	pushq	%rbp
    9fa1:      	pushq	%r15
    9fa3:      	pushq	%r14
    9fa5:      	pushq	%r13
    9fa7:      	pushq	%r12
    9fa9:      	pushq	%rbx
    9faa:      	subq	$0x78, %rsp
    9fae:      	movq	%rdi, %rbx
    9fb1:      	movl	$0x0, 0x14(%rsp)
    9fb9:      	movq	(%rip), %rdi            # 0x9fc0 <generic_fentry_output+0x20>
    9fc0:      	leaq	0x14(%rsp), %rsi
    9fc5:      	movl	$0x1, %eax
    9fca:      	callq	*%rax
    9fcc:      	testq	%rax, %rax
    9fcf:      	je	0xa4aa <generic_fentry_output+0x50a>
    9fd5:      	movq	%rax, %r14
    9fd8:      	cmpq	$0x0, 0x5ee8(%rax)
    9fe0:      	je	0xa2f4 <generic_fentry_output+0x354>
    9fe6:      	movl	$0xe, %eax
    9feb:      	callq	*%rax
    9fed:      	movq	%rax, %r15
    9ff0:      	shrq	$0x20, %r15
    9ff4:      	movl	$0x23, %eax
    9ff9:      	callq	*%rax
    9ffb:      	movq	%rax, %r12
    9ffe:      	movl	%r15d, 0x28(%rsp)
    a003:      	movq	(%rip), %rdi            # 0xa00a <generic_fentry_output+0x6a>
    a00a:      	leaq	0x28(%rsp), %rsi
    a00f:      	movl	$0x1, %eax
    a014:      	callq	*%rax
    a016:      	testq	%rax, %rax
    a019:      	je	0xa2f4 <generic_fentry_output+0x354>
    a01f:      	movq	%rax, %r15
    a022:      	leaq	0xd70(%r12), %rdx
    a02a:      	leaq	0x70(%rsp), %rdi
    a02f:      	movl	$0x8, %ecx
    a034:      	movl	$0x4, %eax
    a039:      	leaq	0x28(%r15), %r13
    a03d:      	movl	$0x4, %ebp
    a042:      	movl	$0x8, %esi
    a047:      	callq	*%rax
    a049:      	movq	0x70(%rsp), %rcx
    a04e:      	leaq	0x28(%rsp), %rdi
    a053:      	movl	$0x48, %edx
    a058:      	movl	$0x4, %eax
    a05d:      	movq	0x70(%rsp), %rdx
    a062:      	movl	$0x48, %esi
    a067:      	callq	*%rax
    a069:      	movl	$0x218, %edx            # imm = 0x218
    a06e:      	movq	0x30(%rsp), %rcx
    a073:      	addq	%rdx, %rcx
    a076:      	movl	$0x4, %esi
    a07b:      	movl	$0x4, %eax
    a080:      	addq	0x30(%rsp), %rdx
    a085:      	movq	%r13, %rdi
    a088:      	movl	$0x4, %esi
    a08d:      	callq	*%rax
    a08f:      	leaq	0x2c(%r15), %rdi
    a093:      	movl	$0x4d8, %edx            # imm = 0x4D8
    a098:      	movq	0x38(%rsp), %rcx
    a09d:      	addq	%rdx, %rcx
    a0a0:      	movl	$0x4, %esi
    a0a5:      	movl	$0x4, %eax
    a0aa:      	addq	0x38(%rsp), %rdx
    a0af:      	movl	$0x4, %esi
    a0b4:      	callq	*%rax
    a0b6:      	leaq	0x30(%r15), %rdi
    a0ba:      	movq	0x40(%rsp), %rcx
    a0bf:      	addq	$0x58, %rcx
    a0c3:      	movl	$0x4, %edx
    a0c8:      	movl	$0x4, %eax
    a0cd:      	movq	0x40(%rsp), %rdx
    a0d2:      	addq	$0x58, %rdx
    a0d6:      	movl	$0x4, %esi
    a0db:      	callq	*%rax
    a0dd:      	movq	$0x0, 0x8(%rsp)
    a0e6:      	leaq	0xb58(%r12), %rdx
    a0ee:      	leaq	0x8(%rsp), %rdi
    a0f3:      	movl	$0x8, %ecx
    a0f8:      	movl	$0x4, %eax
    a0fd:      	movl	$0x8, %esi
    a102:      	callq	*%rax
    a104:      	movq	0x8(%rsp), %rcx
    a109:      	testq	%rcx, %rcx
    a10c:      	je	0xa1a2 <generic_fentry_output+0x202>
    a112:      	movl	$0x0, 0x10(%rsp)
    a11a:      	addq	$0x4, %rcx
    a11e:      	leaq	0x10(%rsp), %rdi
    a123:      	movl	$0x4, %eax
    a128:      	movq	0x8(%rsp), %rdx
    a12d:      	addq	$0x4, %rdx
    a131:      	movl	$0x4, %esi
    a136:      	callq	*%rax
    a138:      	movq	0x8(%rsp), %rax
    a13d:      	movslq	0x10(%rsp), %rcx
    a142:      	shlq	$0x4, %rcx
    a146:      	addq	%rax, %rcx
    a149:      	addq	$0x80, %rcx
    a150:      	leaq	0x18(%rsp), %rdi
    a155:      	movl	$0x10, %edx
    a15a:      	movl	$0x4, %eax
    a15f:      	movq	0x8(%rsp), %rcx
    a164:      	movslq	0x10(%rsp), %rdx
    a169:      	shlq	$0x4, %rdx
    a16d:      	addq	%rcx, %rdx
    a170:      	addq	$0x80, %rdx
    a177:      	movl	$0x10, %esi
    a17c:      	callq	*%rax
    a17e:      	leaq	0x34(%r15), %rdi
    a182:      	movl	$0x158, %edx            # imm = 0x158
    a187:      	movq	0x20(%rsp), %rcx
    a18c:      	addq	%rdx, %rcx
    a18f:      	movl	$0x4, %eax
    a194:      	addq	0x20(%rsp), %rdx
    a199:      	movl	$0x4, %esi
    a19e:      	callq	*%rax
    a1a0:      	jmp	0xa1aa <generic_fentry_output+0x20a>
    a1a2:      	movl	$0x0, 0x34(%r15)
    a1aa:      	leaq	0x38(%r15), %rdi
    a1ae:      	movl	$0x158, %r13d           # imm = 0x158
    a1b4:      	movq	0x48(%rsp), %rcx
    a1b9:      	addq	%r13, %rcx
    a1bc:      	movl	$0x4, %edx
    a1c1:      	movl	$0x4, %eax
    a1c6:      	movq	0x48(%rsp), %rdx
    a1cb:      	addq	%r13, %rdx
    a1ce:      	movl	$0x4, %esi
    a1d3:      	callq	*%rax
    a1d5:      	leaq	0x3c(%r15), %rdi
    a1d9:      	movl	$0x118, %edx            # imm = 0x118
    a1de:      	movq	0x50(%rsp), %rcx
    a1e3:      	addq	%rdx, %rcx
    a1e6:      	movl	$0x4, %esi
    a1eb:      	movl	$0x4, %eax
    a1f0:      	addq	0x50(%rsp), %rdx
    a1f5:      	movl	$0x4, %esi
    a1fa:      	callq	*%rax
    a1fc:      	leaq	0x40(%r15), %rdi
    a200:      	movl	$0x98, %ebp
    a205:      	movq	0x58(%rsp), %rcx
    a20a:      	addq	%rbp, %rcx
    a20d:      	movl	$0x4, %edx
    a212:      	movl	$0x4, %eax
    a217:      	movq	0x58(%rsp), %rdx
    a21c:      	addq	%rbp, %rdx
    a21f:      	movl	$0x4, %esi
    a224:      	callq	*%rax
    a226:      	leaq	0x44(%r15), %rdi
    a22a:      	movq	0x60(%rsp), %rcx
    a22f:      	addq	%rbp, %rcx
    a232:      	movl	$0x4, %edx
    a237:      	movl	$0x4, %eax
    a23c:      	addq	0x60(%rsp), %rbp
    a241:      	movl	$0x4, %esi
    a246:      	movq	%rbp, %rdx
    a249:      	callq	*%rax
    a24b:      	leaq	0x48(%r15), %rdi
    a24f:      	movq	0x68(%rsp), %rcx
    a254:      	addq	$0x58, %rcx
    a258:      	movl	$0x4, %edx
    a25d:      	movl	$0x4, %eax
    a262:      	movq	0x68(%rsp), %rdx
    a267:      	addq	$0x58, %rdx
    a26b:      	movl	$0x4, %esi
    a270:      	callq	*%rax
    a272:      	movq	$0x0, 0x18(%rsp)
    a27b:      	movq	$0x0, 0x8(%rsp)
    a284:      	addq	$0xd00, %r12            # imm = 0xD00
    a28b:      	leaq	0x18(%rsp), %rdi
    a290:      	movl	$0x8, %ecx
    a295:      	movl	$0x4, %eax
    a29a:      	movl	$0x8, %esi
    a29f:      	movq	%r12, %rdx
    a2a2:      	callq	*%rax
    a2a4:      	movl	$0x90, %edx
    a2a9:      	movq	0x18(%rsp), %rcx
    a2ae:      	addq	%rdx, %rcx
    a2b1:      	leaq	0x8(%rsp), %rdi
    a2b6:      	movl	$0x8, %esi
    a2bb:      	movl	$0x4, %eax
    a2c0:      	addq	0x18(%rsp), %rdx
    a2c5:      	movl	$0x8, %esi
    a2ca:      	callq	*%rax
    a2cc:      	addq	$0x4c, %r15
    a2d0:      	movq	0x8(%rsp), %rcx
    a2d5:      	addq	%r13, %rcx
    a2d8:      	movl	$0x4, %edx
    a2dd:      	movl	$0x4, %eax
    a2e2:      	addq	0x8(%rsp), %r13
    a2e7:      	movq	%r15, %rdi
    a2ea:      	movl	$0x4, %esi
    a2ef:      	movq	%r13, %rdx
    a2f2:      	callq	*%rax
    a2f4:      	cmpq	$0x0, 0x5ef0(%r14)
    a2fc:      	je	0xa3b5 <generic_fentry_output+0x415>
    a302:      	movl	$0xe, %eax
    a307:      	callq	*%rax
    a309:      	movq	%rax, %r15
    a30c:      	shrq	$0x20, %r15
    a310:      	movl	$0x23, %eax
    a315:      	callq	*%rax
    a317:      	movq	%rax, %r12
    a31a:      	movl	%r15d, 0x28(%rsp)
    a31f:      	movq	(%rip), %rdi            # 0xa326 <generic_fentry_output+0x386>
    a326:      	leaq	0x28(%rsp), %rsi
    a32b:      	movl	$0x1, %eax
    a330:      	callq	*%rax
    a332:      	testq	%rax, %rax
    a335:      	je	0xa3b5 <generic_fentry_output+0x415>
    a337:      	leaq	0x50(%rax), %r15
    a33b:      	addq	$0xd00, %r12            # imm = 0xD00
    a342:      	leaq	0x28(%rsp), %rdi
    a347:      	movl	$0x8, %ecx
    a34c:      	movq	%rax, %r13
    a34f:      	movl	$0x4, %eax
    a354:      	movl	$0x8, %esi
    a359:      	movq	%r12, %rdx
    a35c:      	callq	*%rax
    a35e:      	movq	0x28(%rsp), %r12
    a363:      	leaq	0x58(%r13), %rdi
    a367:      	leaq	0x40(%r12), %rdx
    a36c:      	movl	$0x8, %ecx
    a371:      	movl	$0x4, %eax
    a376:      	movl	$0x8, %esi
    a37b:      	callq	*%rax
    a37d:      	addq	$0x60, %r13
    a381:      	leaq	0x30(%r12), %rdx
    a386:      	movl	$0x8, %ecx
    a38b:      	movl	$0x4, %eax
    a390:      	movq	%r13, %rdi
    a393:      	movl	$0x8, %esi
    a398:      	callq	*%rax
    a39a:      	addq	$0x38, %r12
    a39e:      	movl	$0x8, %ecx
    a3a3:      	movl	$0x4, %eax
    a3a8:      	movq	%r15, %rdi
    a3ab:      	movl	$0x8, %esi
    a3b0:      	movq	%r12, %rdx
    a3b3:      	callq	*%rax
    a3b5:      	movl	$0x90, %eax
    a3ba:      	addl	0x4(%r14), %eax
    a3be:      	andl	$0x7fff, %eax           # imm = 0x7FFF
    a3c3:      	cmpl	$0x2328, %eax           # imm = 0x2328
    a3c8:      	movl	$0x2328, %r8d           # imm = 0x2328
    a3ce:      	cmovbl	%eax, %r8d
    a3d2:      	movq	(%rip), %rsi            # 0xa3d9 <generic_fentry_output+0x439>
    a3d9:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    a3de:      	movl	$0x19, %eax
    a3e3:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    a3e8:      	movq	%rbx, %rdi
    a3eb:      	movq	%r14, %rcx
    a3ee:      	callq	*%rax
    a3f0:      	testq	%rax, %rax
    a3f3:      	js	0xa423 <generic_fentry_output+0x483>
    a3f5:      	movl	$0x0, 0x28(%rsp)
    a3fd:      	movq	(%rip), %rdi            # 0xa404 <generic_fentry_output+0x464>
    a404:      	leaq	0x28(%rsp), %rsi
    a409:      	movl	$0x1, %eax
    a40e:      	callq	*%rax
    a410:      	testq	%rax, %rax
    a413:      	je	0xa4aa <generic_fentry_output+0x50a>
    a419:      	lock
    a41a:      	incq	0x8(%rax)
    a41e:      	jmp	0xa4aa <generic_fentry_output+0x50a>
    a423:      	movq	%rax, %rbx
    a426:      	movl	$0x0, 0x28(%rsp)
    a42e:      	movq	(%rip), %rdi            # 0xa435 <generic_fentry_output+0x495>
    a435:      	leaq	0x28(%rsp), %rsi
    a43a:      	movl	$0x1, %eax
    a43f:      	callq	*%rax
    a441:      	testq	%rax, %rax
    a444:      	je	0xa4aa <generic_fentry_output+0x50a>
    a446:      	cmpq	$-0xc, %rbx
    a44a:      	jg	0xa466 <generic_fentry_output+0x4c6>
    a44c:      	cmpq	$-0x1c, %rbx
    a450:      	je	0xa480 <generic_fentry_output+0x4e0>
    a452:      	cmpq	$-0x16, %rbx
    a456:      	je	0xa498 <generic_fentry_output+0x4f8>
    a458:      	cmpq	$-0x10, %rbx
    a45c:      	jne	0xa490 <generic_fentry_output+0x4f0>
    a45e:      	addq	$0x2f0, %rax            # imm = 0x2F0
    a464:      	jmp	0xa4a6 <generic_fentry_output+0x506>
    a466:      	cmpq	$-0xb, %rbx
    a46a:      	je	0xa488 <generic_fentry_output+0x4e8>
    a46c:      	cmpq	$-0x7, %rbx
    a470:      	je	0xa4a0 <generic_fentry_output+0x500>
    a472:      	cmpq	$-0x2, %rbx
    a476:      	jne	0xa490 <generic_fentry_output+0x4f0>
    a478:      	addq	$0x2e0, %rax            # imm = 0x2E0
    a47e:      	jmp	0xa4a6 <generic_fentry_output+0x506>
    a480:      	addq	$0x300, %rax            # imm = 0x300
    a486:      	jmp	0xa4a6 <generic_fentry_output+0x506>
    a488:      	addq	$0x308, %rax            # imm = 0x308
    a48e:      	jmp	0xa4a6 <generic_fentry_output+0x506>
    a490:      	addq	$0x2d8, %rax            # imm = 0x2D8
    a496:      	jmp	0xa4a6 <generic_fentry_output+0x506>
    a498:      	addq	$0x2f8, %rax            # imm = 0x2F8
    a49e:      	jmp	0xa4a6 <generic_fentry_output+0x506>
    a4a0:      	addq	$0x2e8, %rax            # imm = 0x2E8
    a4a6:      	lock
    a4a7:      	incq	(%rax)
    a4aa:      	xorl	%eax, %eax
    a4ac:      	addq	$0x78, %rsp
    a4b0:      	popq	%rbx
    a4b1:      	popq	%r12
    a4b3:      	popq	%r13
    a4b5:      	popq	%r14
    a4b7:      	popq	%r15
    a4b9:      	popq	%rbp
    a4ba:      	retq
    a4bb:      	nopl	(%rax,%rax)

000000000000a4c0 <generic_fentry_path>:
    a4c0:      	pushq	%rbp
    a4c1:      	pushq	%r15
    a4c3:      	pushq	%r14
    a4c5:      	pushq	%r13
    a4c7:      	pushq	%r12
    a4c9:      	pushq	%rbx
    a4ca:      	subq	$0x88, %rsp
    a4d1:      	movq	%rdi, %rbp
    a4d4:      	movl	$0x0, 0x70(%rsp)
    a4dc:      	movq	(%rip), %rdi            # 0xa4e3 <generic_fentry_path+0x23>
    a4e3:      	leaq	0x70(%rsp), %rsi
    a4e8:      	movl	$0x1, %eax
    a4ed:      	callq	*%rax
    a4ef:      	testq	%rax, %rax
    a4f2:      	je	0x16339 <generic_fentry_path+0xbe79>
    a4f8:      	movq	%rax, %r14
    a4fb:      	movl	0x6420(%rax), %eax
    a501:      	cmpl	$0x1, %eax
    a504:      	je	0xa5a6 <generic_fentry_path+0xe6>
    a50a:      	testl	%eax, %eax
    a50c:      	jne	0x16339 <generic_fentry_path+0xbe79>
    a512:      	movq	0x6440(%r14), %r12
    a519:      	movl	$0x0, 0x10(%rsp)
    a521:      	movq	(%rip), %rdi            # 0xa528 <generic_fentry_path+0x68>
    a528:      	leaq	0x10(%rsp), %rsi
    a52d:      	movl	$0x1, %eax
    a532:      	callq	*%rax
    a534:      	testq	%rax, %rax
    a537:      	je	0x16339 <generic_fentry_path+0xbe79>
    a53d:      	movq	%rax, %r15
    a540:      	addq	$0x8, %r12
    a544:      	leaq	0x58(%rsp), %rdi
    a549:      	movl	$0x8, %ecx
    a54e:      	movl	$0x4, %eax
    a553:      	movl	$0x8, %esi
    a558:      	movq	%r12, %rdx
    a55b:      	callq	*%rax
    a55d:      	testq	%rax, %rax
    a560:      	je	0x15fe9 <generic_fentry_path+0xbb29>
    a566:      	negl	%eax
    a568:      	movw	%ax, 0x18(%rsp)
    a56d:      	movw	$0x6, 0x1a(%rsp)
    a574:      	movabsq	$0x40000002c, %rax      # imm = 0x40000002C
    a57e:      	movq	%rax, 0x1c(%rsp)
    a583:      	movq	(%rip), %rdi            # 0xa58a <generic_fentry_path+0xca>
    a58a:      	leaq	0x18(%rsp), %rsi
    a58f:      	movl	$0x1, %eax
    a594:      	callq	*%rax
    a596:      	testq	%rax, %rax
    a599:      	je	0x15fc8 <generic_fentry_path+0xbb08>
    a59f:      	incl	(%rax)
    a5a1:      	jmp	0x15fe9 <generic_fentry_path+0xbb29>
    a5a6:      	movq	0x6448(%r14), %rax
    a5ad:      	movq	%rax, 0x18(%rsp)
    a5b2:      	movq	0x6450(%r14), %rax
    a5b9:      	movq	%rax, 0x20(%rsp)
    a5be:      	movq	$0x0, 0x28(%rsp)
    a5c7:      	movq	0x6458(%r14), %rax
    a5ce:      	movq	%rax, 0x30(%rsp)
    a5d3:      	movq	0x6460(%r14), %rax
    a5da:      	movq	%rax, 0x38(%rsp)
    a5df:      	movq	0x6468(%r14), %rax
    a5e6:      	movq	%rax, 0x40(%rsp)
    a5eb:      	movq	$0x0, 0x48(%rsp)
    a5f4:      	movl	$0x0, 0x50(%rsp)
    a5fc:      	movb	$0x0, 0x54(%rsp)
    a601:      	movl	$0x0, 0x74(%rsp)
    a609:      	movq	(%rip), %rdi            # 0xa610 <generic_fentry_path+0x150>
    a610:      	leaq	0x74(%rsp), %rsi
    a615:      	movl	$0x1, %eax
    a61a:      	callq	*%rax
    a61c:      	testq	%rax, %rax
    a61f:      	je	0x16339 <generic_fentry_path+0xbe79>
    a625:      	movq	%rbp, 0x78(%rsp)
    a62a:      	movq	%rax, 0x28(%rsp)
    a62f:      	movl	0x6424(%r14), %edx
    a636:      	movl	%edx, %ecx
    a638:      	andl	$0xfff, %ecx            # imm = 0xFFF
    a63e:      	movq	%rax, %rsi
    a641:      	movq	%rax, 0x80(%rsp)
    a649:      	addq	%rax, %rcx
    a64c:      	movq	%rcx, 0x48(%rsp)
    a651:      	movl	%edx, 0x50(%rsp)
    a655:      	movl	$0x200, %eax            # imm = 0x200
    a65a:      	movl	$0x8, %r13d
    a660:      	movq	%rsp, %rbp
    a663:      	movl	%eax, 0x6c(%rsp)
    a667:      	movq	0x30(%rsp), %r12
    a66c:      	movq	0x38(%rsp), %rdx
    a671:      	movq	0x40(%rsp), %r15
    a676:      	cmpq	0x18(%rsp), %r12
    a67b:      	jne	0xa688 <generic_fentry_path+0x1c8>
    a67d:      	cmpq	0x20(%rsp), %rdx
    a682:      	je	0x15f2d <generic_fentry_path+0xba6d>
    a688:      	movl	$0x4, %eax
    a68d:      	leaq	0x10(%rsp), %rdi
    a692:      	movl	$0x8, %esi
    a697:      	callq	*%rax
    a699:      	cmpq	0x10(%rsp), %r12
    a69e:      	je	0xa79d <generic_fentry_path+0x2dd>
    a6a4:      	leaq	0x18(%r12), %rbx
    a6a9:      	movl	$0x4, %eax
    a6ae:      	movq	%rbp, %rdi
    a6b1:      	movl	$0x8, %esi
    a6b6:      	movq	%rbx, %rdx
    a6b9:      	callq	*%rax
    a6bb:      	cmpq	%r12, (%rsp)
    a6bf:      	je	0xa79d <generic_fentry_path+0x2dd>
    a6c5:      	movl	$0x4, %eax
    a6ca:      	leaq	0x8(%rsp), %rdi
    a6cf:      	movl	$0x8, %esi
    a6d4:      	movq	%rbx, %rdx
    a6d7:      	callq	*%rax
    a6d9:      	addq	$0x20, %r12
    a6dd:      	movl	$0x4, %eax
    a6e2:      	leaq	0x58(%rsp), %rdi
    a6e7:      	movl	$0x10, %ecx
    a6ec:      	movl	$0x10, %esi
    a6f1:      	movq	%r12, %rdx
    a6f4:      	callq	*%rax
    a6f6:      	movq	0x28(%rsp), %rbx
    a6fb:      	movq	0x48(%rsp), %rax
    a700:      	movl	0x5c(%rsp), %r15d
    a705:      	subq	%rbx, %rax
    a708:      	movl	0x50(%rsp), %r12d
    a70d:      	movl	%r15d, %edx
    a710:      	subl	%r12d, %edx
    a713:      	movl	$0x0, %ecx
    a718:      	cmovbl	%ecx, %edx
    a71b:      	addq	0x60(%rsp), %rdx
    a720:      	xorl	%esi, %esi
    a722:      	cmpl	%r15d, %r12d
    a725:      	seta	%sil
    a729:      	movl	%r15d, %ecx
    a72c:      	cmovbl	%r12d, %ecx
    a730:      	addl	%ecx, %esi
    a732:      	movl	%r12d, %edi
    a735:      	subl	%esi, %edi
    a737:      	movl	%edi, 0x50(%rsp)
    a73b:      	subq	%rsi, %rax
    a73e:      	jb	0x15f32 <generic_fentry_path+0xba72>
    a744:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    a74a:      	ja	0x15f32 <generic_fentry_path+0xba72>
    a750:      	cmpl	%r15d, %r12d
    a753:      	jbe	0xa759 <generic_fentry_path+0x299>
    a755:      	movb	$0x2f, (%rbx,%rax)
    a759:      	xorl	%edi, %edi
    a75b:      	cmpl	%r15d, %r12d
    a75e:      	seta	%dil
    a762:      	movzbl	%cl, %esi
    a765:      	addq	%rax, %rbx
    a768:      	addq	%rbx, %rdi
    a76b:      	movl	$0x4, %eax
    a770:      	callq	*%rax
    a772:      	movq	%rbx, 0x48(%rsp)
    a777:      	cmpl	%r15d, %r12d
    a77a:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    a780:      	movq	0x8(%rsp), %r12
    a785:      	movq	%r12, 0x30(%rsp)
    a78a:      	movq	0x38(%rsp), %rdx
    a78f:      	movq	0x40(%rsp), %r15
    a794:      	cmpq	0x18(%rsp), %r12
    a799:      	je	0xa7f5 <generic_fentry_path+0x335>
    a79b:      	jmp	0xa800 <generic_fentry_path+0x340>
    a79d:      	leaq	0x10(%r15), %rdx
    a7a1:      	movl	$0x4, %eax
    a7a6:      	movq	%rbp, %rdi
    a7a9:      	movl	$0x8, %esi
    a7ae:      	callq	*%rax
    a7b0:      	movq	0x40(%rsp), %rax
    a7b5:      	cmpq	(%rsp), %rax
    a7b9:      	je	0x15f2d <generic_fentry_path+0xba6d>
    a7bf:      	addq	$0x18, %r15
    a7c3:      	movl	$0x4, %eax
    a7c8:      	leaq	0x30(%rsp), %rdi
    a7cd:      	movl	$0x8, %esi
    a7d2:      	movq	%r15, %rdx
    a7d5:      	callq	*%rax
    a7d7:      	movq	(%rsp), %r15
    a7db:      	movq	%r15, 0x40(%rsp)
    a7e0:      	leaq	0x20(%r15), %rdx
    a7e4:      	movq	%rdx, 0x38(%rsp)
    a7e9:      	movq	0x30(%rsp), %r12
    a7ee:      	cmpq	0x18(%rsp), %r12
    a7f3:      	jne	0xa800 <generic_fentry_path+0x340>
    a7f5:      	cmpq	0x20(%rsp), %rdx
    a7fa:      	je	0x15f2d <generic_fentry_path+0xba6d>
    a800:      	movl	$0x4, %eax
    a805:      	leaq	0x10(%rsp), %rdi
    a80a:      	movl	$0x8, %esi
    a80f:      	callq	*%rax
    a811:      	cmpq	0x10(%rsp), %r12
    a816:      	je	0xa915 <generic_fentry_path+0x455>
    a81c:      	leaq	0x18(%r12), %rbx
    a821:      	movl	$0x4, %eax
    a826:      	movq	%rbp, %rdi
    a829:      	movl	$0x8, %esi
    a82e:      	movq	%rbx, %rdx
    a831:      	callq	*%rax
    a833:      	cmpq	%r12, (%rsp)
    a837:      	je	0xa915 <generic_fentry_path+0x455>
    a83d:      	movl	$0x4, %eax
    a842:      	leaq	0x8(%rsp), %rdi
    a847:      	movl	$0x8, %esi
    a84c:      	movq	%rbx, %rdx
    a84f:      	callq	*%rax
    a851:      	addq	$0x20, %r12
    a855:      	movl	$0x4, %eax
    a85a:      	leaq	0x58(%rsp), %rdi
    a85f:      	movl	$0x10, %ecx
    a864:      	movl	$0x10, %esi
    a869:      	movq	%r12, %rdx
    a86c:      	callq	*%rax
    a86e:      	movq	0x28(%rsp), %rbx
    a873:      	movq	0x48(%rsp), %rax
    a878:      	movl	0x5c(%rsp), %r15d
    a87d:      	subq	%rbx, %rax
    a880:      	movl	0x50(%rsp), %r12d
    a885:      	movl	%r15d, %edx
    a888:      	subl	%r12d, %edx
    a88b:      	movl	$0x0, %ecx
    a890:      	cmovbl	%ecx, %edx
    a893:      	addq	0x60(%rsp), %rdx
    a898:      	xorl	%esi, %esi
    a89a:      	cmpl	%r15d, %r12d
    a89d:      	seta	%sil
    a8a1:      	movl	%r15d, %ecx
    a8a4:      	cmovbl	%r12d, %ecx
    a8a8:      	addl	%ecx, %esi
    a8aa:      	movl	%r12d, %edi
    a8ad:      	subl	%esi, %edi
    a8af:      	movl	%edi, 0x50(%rsp)
    a8b3:      	subq	%rsi, %rax
    a8b6:      	jb	0x15f32 <generic_fentry_path+0xba72>
    a8bc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    a8c2:      	ja	0x15f32 <generic_fentry_path+0xba72>
    a8c8:      	cmpl	%r15d, %r12d
    a8cb:      	jbe	0xa8d1 <generic_fentry_path+0x411>
    a8cd:      	movb	$0x2f, (%rbx,%rax)
    a8d1:      	xorl	%edi, %edi
    a8d3:      	cmpl	%r15d, %r12d
    a8d6:      	seta	%dil
    a8da:      	movzbl	%cl, %esi
    a8dd:      	addq	%rax, %rbx
    a8e0:      	addq	%rbx, %rdi
    a8e3:      	movl	$0x4, %eax
    a8e8:      	callq	*%rax
    a8ea:      	movq	%rbx, 0x48(%rsp)
    a8ef:      	cmpl	%r15d, %r12d
    a8f2:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    a8f8:      	movq	0x8(%rsp), %r12
    a8fd:      	movq	%r12, 0x30(%rsp)
    a902:      	movq	0x38(%rsp), %rdx
    a907:      	movq	0x40(%rsp), %r15
    a90c:      	cmpq	0x18(%rsp), %r12
    a911:      	je	0xa96d <generic_fentry_path+0x4ad>
    a913:      	jmp	0xa978 <generic_fentry_path+0x4b8>
    a915:      	leaq	0x10(%r15), %rdx
    a919:      	movl	$0x4, %eax
    a91e:      	movq	%rbp, %rdi
    a921:      	movl	$0x8, %esi
    a926:      	callq	*%rax
    a928:      	movq	0x40(%rsp), %rax
    a92d:      	cmpq	(%rsp), %rax
    a931:      	je	0x15f2d <generic_fentry_path+0xba6d>
    a937:      	addq	$0x18, %r15
    a93b:      	movl	$0x4, %eax
    a940:      	leaq	0x30(%rsp), %rdi
    a945:      	movl	$0x8, %esi
    a94a:      	movq	%r15, %rdx
    a94d:      	callq	*%rax
    a94f:      	movq	(%rsp), %r15
    a953:      	movq	%r15, 0x40(%rsp)
    a958:      	leaq	0x20(%r15), %rdx
    a95c:      	movq	%rdx, 0x38(%rsp)
    a961:      	movq	0x30(%rsp), %r12
    a966:      	cmpq	0x18(%rsp), %r12
    a96b:      	jne	0xa978 <generic_fentry_path+0x4b8>
    a96d:      	cmpq	0x20(%rsp), %rdx
    a972:      	je	0x15f2d <generic_fentry_path+0xba6d>
    a978:      	movl	$0x4, %eax
    a97d:      	leaq	0x10(%rsp), %rdi
    a982:      	movl	$0x8, %esi
    a987:      	callq	*%rax
    a989:      	cmpq	0x10(%rsp), %r12
    a98e:      	je	0xaa8d <generic_fentry_path+0x5cd>
    a994:      	leaq	0x18(%r12), %rbx
    a999:      	movl	$0x4, %eax
    a99e:      	movq	%rbp, %rdi
    a9a1:      	movl	$0x8, %esi
    a9a6:      	movq	%rbx, %rdx
    a9a9:      	callq	*%rax
    a9ab:      	cmpq	%r12, (%rsp)
    a9af:      	je	0xaa8d <generic_fentry_path+0x5cd>
    a9b5:      	movl	$0x4, %eax
    a9ba:      	leaq	0x8(%rsp), %rdi
    a9bf:      	movl	$0x8, %esi
    a9c4:      	movq	%rbx, %rdx
    a9c7:      	callq	*%rax
    a9c9:      	addq	$0x20, %r12
    a9cd:      	movl	$0x4, %eax
    a9d2:      	leaq	0x58(%rsp), %rdi
    a9d7:      	movl	$0x10, %ecx
    a9dc:      	movl	$0x10, %esi
    a9e1:      	movq	%r12, %rdx
    a9e4:      	callq	*%rax
    a9e6:      	movq	0x28(%rsp), %rbx
    a9eb:      	movq	0x48(%rsp), %rax
    a9f0:      	movl	0x5c(%rsp), %r15d
    a9f5:      	subq	%rbx, %rax
    a9f8:      	movl	0x50(%rsp), %r12d
    a9fd:      	movl	%r15d, %edx
    aa00:      	subl	%r12d, %edx
    aa03:      	movl	$0x0, %ecx
    aa08:      	cmovbl	%ecx, %edx
    aa0b:      	addq	0x60(%rsp), %rdx
    aa10:      	xorl	%esi, %esi
    aa12:      	cmpl	%r15d, %r12d
    aa15:      	seta	%sil
    aa19:      	movl	%r15d, %ecx
    aa1c:      	cmovbl	%r12d, %ecx
    aa20:      	addl	%ecx, %esi
    aa22:      	movl	%r12d, %edi
    aa25:      	subl	%esi, %edi
    aa27:      	movl	%edi, 0x50(%rsp)
    aa2b:      	subq	%rsi, %rax
    aa2e:      	jb	0x15f32 <generic_fentry_path+0xba72>
    aa34:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    aa3a:      	ja	0x15f32 <generic_fentry_path+0xba72>
    aa40:      	cmpl	%r15d, %r12d
    aa43:      	jbe	0xaa49 <generic_fentry_path+0x589>
    aa45:      	movb	$0x2f, (%rbx,%rax)
    aa49:      	xorl	%edi, %edi
    aa4b:      	cmpl	%r15d, %r12d
    aa4e:      	seta	%dil
    aa52:      	movzbl	%cl, %esi
    aa55:      	addq	%rax, %rbx
    aa58:      	addq	%rbx, %rdi
    aa5b:      	movl	$0x4, %eax
    aa60:      	callq	*%rax
    aa62:      	movq	%rbx, 0x48(%rsp)
    aa67:      	cmpl	%r15d, %r12d
    aa6a:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    aa70:      	movq	0x8(%rsp), %r12
    aa75:      	movq	%r12, 0x30(%rsp)
    aa7a:      	movq	0x38(%rsp), %rdx
    aa7f:      	movq	0x40(%rsp), %r15
    aa84:      	cmpq	0x18(%rsp), %r12
    aa89:      	je	0xaae5 <generic_fentry_path+0x625>
    aa8b:      	jmp	0xaaf0 <generic_fentry_path+0x630>
    aa8d:      	leaq	0x10(%r15), %rdx
    aa91:      	movl	$0x4, %eax
    aa96:      	movq	%rbp, %rdi
    aa99:      	movl	$0x8, %esi
    aa9e:      	callq	*%rax
    aaa0:      	movq	0x40(%rsp), %rax
    aaa5:      	cmpq	(%rsp), %rax
    aaa9:      	je	0x15f2d <generic_fentry_path+0xba6d>
    aaaf:      	addq	$0x18, %r15
    aab3:      	movl	$0x4, %eax
    aab8:      	leaq	0x30(%rsp), %rdi
    aabd:      	movl	$0x8, %esi
    aac2:      	movq	%r15, %rdx
    aac5:      	callq	*%rax
    aac7:      	movq	(%rsp), %r15
    aacb:      	movq	%r15, 0x40(%rsp)
    aad0:      	leaq	0x20(%r15), %rdx
    aad4:      	movq	%rdx, 0x38(%rsp)
    aad9:      	movq	0x30(%rsp), %r12
    aade:      	cmpq	0x18(%rsp), %r12
    aae3:      	jne	0xaaf0 <generic_fentry_path+0x630>
    aae5:      	cmpq	0x20(%rsp), %rdx
    aaea:      	je	0x15f2d <generic_fentry_path+0xba6d>
    aaf0:      	movl	$0x4, %eax
    aaf5:      	leaq	0x10(%rsp), %rdi
    aafa:      	movl	$0x8, %esi
    aaff:      	callq	*%rax
    ab01:      	cmpq	0x10(%rsp), %r12
    ab06:      	je	0xac05 <generic_fentry_path+0x745>
    ab0c:      	leaq	0x18(%r12), %rbx
    ab11:      	movl	$0x4, %eax
    ab16:      	movq	%rbp, %rdi
    ab19:      	movl	$0x8, %esi
    ab1e:      	movq	%rbx, %rdx
    ab21:      	callq	*%rax
    ab23:      	cmpq	%r12, (%rsp)
    ab27:      	je	0xac05 <generic_fentry_path+0x745>
    ab2d:      	movl	$0x4, %eax
    ab32:      	leaq	0x8(%rsp), %rdi
    ab37:      	movl	$0x8, %esi
    ab3c:      	movq	%rbx, %rdx
    ab3f:      	callq	*%rax
    ab41:      	addq	$0x20, %r12
    ab45:      	movl	$0x4, %eax
    ab4a:      	leaq	0x58(%rsp), %rdi
    ab4f:      	movl	$0x10, %ecx
    ab54:      	movl	$0x10, %esi
    ab59:      	movq	%r12, %rdx
    ab5c:      	callq	*%rax
    ab5e:      	movq	0x28(%rsp), %rbx
    ab63:      	movq	0x48(%rsp), %rax
    ab68:      	movl	0x5c(%rsp), %r15d
    ab6d:      	subq	%rbx, %rax
    ab70:      	movl	0x50(%rsp), %r12d
    ab75:      	movl	%r15d, %edx
    ab78:      	subl	%r12d, %edx
    ab7b:      	movl	$0x0, %ecx
    ab80:      	cmovbl	%ecx, %edx
    ab83:      	addq	0x60(%rsp), %rdx
    ab88:      	xorl	%esi, %esi
    ab8a:      	cmpl	%r15d, %r12d
    ab8d:      	seta	%sil
    ab91:      	movl	%r15d, %ecx
    ab94:      	cmovbl	%r12d, %ecx
    ab98:      	addl	%ecx, %esi
    ab9a:      	movl	%r12d, %edi
    ab9d:      	subl	%esi, %edi
    ab9f:      	movl	%edi, 0x50(%rsp)
    aba3:      	subq	%rsi, %rax
    aba6:      	jb	0x15f32 <generic_fentry_path+0xba72>
    abac:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    abb2:      	ja	0x15f32 <generic_fentry_path+0xba72>
    abb8:      	cmpl	%r15d, %r12d
    abbb:      	jbe	0xabc1 <generic_fentry_path+0x701>
    abbd:      	movb	$0x2f, (%rbx,%rax)
    abc1:      	xorl	%edi, %edi
    abc3:      	cmpl	%r15d, %r12d
    abc6:      	seta	%dil
    abca:      	movzbl	%cl, %esi
    abcd:      	addq	%rax, %rbx
    abd0:      	addq	%rbx, %rdi
    abd3:      	movl	$0x4, %eax
    abd8:      	callq	*%rax
    abda:      	movq	%rbx, 0x48(%rsp)
    abdf:      	cmpl	%r15d, %r12d
    abe2:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    abe8:      	movq	0x8(%rsp), %r12
    abed:      	movq	%r12, 0x30(%rsp)
    abf2:      	movq	0x38(%rsp), %rdx
    abf7:      	movq	0x40(%rsp), %r15
    abfc:      	cmpq	0x18(%rsp), %r12
    ac01:      	je	0xac5d <generic_fentry_path+0x79d>
    ac03:      	jmp	0xac68 <generic_fentry_path+0x7a8>
    ac05:      	leaq	0x10(%r15), %rdx
    ac09:      	movl	$0x4, %eax
    ac0e:      	movq	%rbp, %rdi
    ac11:      	movl	$0x8, %esi
    ac16:      	callq	*%rax
    ac18:      	movq	0x40(%rsp), %rax
    ac1d:      	cmpq	(%rsp), %rax
    ac21:      	je	0x15f2d <generic_fentry_path+0xba6d>
    ac27:      	addq	$0x18, %r15
    ac2b:      	movl	$0x4, %eax
    ac30:      	leaq	0x30(%rsp), %rdi
    ac35:      	movl	$0x8, %esi
    ac3a:      	movq	%r15, %rdx
    ac3d:      	callq	*%rax
    ac3f:      	movq	(%rsp), %r15
    ac43:      	movq	%r15, 0x40(%rsp)
    ac48:      	leaq	0x20(%r15), %rdx
    ac4c:      	movq	%rdx, 0x38(%rsp)
    ac51:      	movq	0x30(%rsp), %r12
    ac56:      	cmpq	0x18(%rsp), %r12
    ac5b:      	jne	0xac68 <generic_fentry_path+0x7a8>
    ac5d:      	cmpq	0x20(%rsp), %rdx
    ac62:      	je	0x15f2d <generic_fentry_path+0xba6d>
    ac68:      	movl	$0x4, %eax
    ac6d:      	leaq	0x10(%rsp), %rdi
    ac72:      	movl	$0x8, %esi
    ac77:      	callq	*%rax
    ac79:      	cmpq	0x10(%rsp), %r12
    ac7e:      	je	0xad7d <generic_fentry_path+0x8bd>
    ac84:      	leaq	0x18(%r12), %rbx
    ac89:      	movl	$0x4, %eax
    ac8e:      	movq	%rbp, %rdi
    ac91:      	movl	$0x8, %esi
    ac96:      	movq	%rbx, %rdx
    ac99:      	callq	*%rax
    ac9b:      	cmpq	%r12, (%rsp)
    ac9f:      	je	0xad7d <generic_fentry_path+0x8bd>
    aca5:      	movl	$0x4, %eax
    acaa:      	leaq	0x8(%rsp), %rdi
    acaf:      	movl	$0x8, %esi
    acb4:      	movq	%rbx, %rdx
    acb7:      	callq	*%rax
    acb9:      	addq	$0x20, %r12
    acbd:      	movl	$0x4, %eax
    acc2:      	leaq	0x58(%rsp), %rdi
    acc7:      	movl	$0x10, %ecx
    accc:      	movl	$0x10, %esi
    acd1:      	movq	%r12, %rdx
    acd4:      	callq	*%rax
    acd6:      	movq	0x28(%rsp), %rbx
    acdb:      	movq	0x48(%rsp), %rax
    ace0:      	movl	0x5c(%rsp), %r15d
    ace5:      	subq	%rbx, %rax
    ace8:      	movl	0x50(%rsp), %r12d
    aced:      	movl	%r15d, %edx
    acf0:      	subl	%r12d, %edx
    acf3:      	movl	$0x0, %ecx
    acf8:      	cmovbl	%ecx, %edx
    acfb:      	addq	0x60(%rsp), %rdx
    ad00:      	xorl	%esi, %esi
    ad02:      	cmpl	%r15d, %r12d
    ad05:      	seta	%sil
    ad09:      	movl	%r15d, %ecx
    ad0c:      	cmovbl	%r12d, %ecx
    ad10:      	addl	%ecx, %esi
    ad12:      	movl	%r12d, %edi
    ad15:      	subl	%esi, %edi
    ad17:      	movl	%edi, 0x50(%rsp)
    ad1b:      	subq	%rsi, %rax
    ad1e:      	jb	0x15f32 <generic_fentry_path+0xba72>
    ad24:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ad2a:      	ja	0x15f32 <generic_fentry_path+0xba72>
    ad30:      	cmpl	%r15d, %r12d
    ad33:      	jbe	0xad39 <generic_fentry_path+0x879>
    ad35:      	movb	$0x2f, (%rbx,%rax)
    ad39:      	xorl	%edi, %edi
    ad3b:      	cmpl	%r15d, %r12d
    ad3e:      	seta	%dil
    ad42:      	movzbl	%cl, %esi
    ad45:      	addq	%rax, %rbx
    ad48:      	addq	%rbx, %rdi
    ad4b:      	movl	$0x4, %eax
    ad50:      	callq	*%rax
    ad52:      	movq	%rbx, 0x48(%rsp)
    ad57:      	cmpl	%r15d, %r12d
    ad5a:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    ad60:      	movq	0x8(%rsp), %r12
    ad65:      	movq	%r12, 0x30(%rsp)
    ad6a:      	movq	0x38(%rsp), %rdx
    ad6f:      	movq	0x40(%rsp), %r15
    ad74:      	cmpq	0x18(%rsp), %r12
    ad79:      	je	0xadd5 <generic_fentry_path+0x915>
    ad7b:      	jmp	0xade0 <generic_fentry_path+0x920>
    ad7d:      	leaq	0x10(%r15), %rdx
    ad81:      	movl	$0x4, %eax
    ad86:      	movq	%rbp, %rdi
    ad89:      	movl	$0x8, %esi
    ad8e:      	callq	*%rax
    ad90:      	movq	0x40(%rsp), %rax
    ad95:      	cmpq	(%rsp), %rax
    ad99:      	je	0x15f2d <generic_fentry_path+0xba6d>
    ad9f:      	addq	$0x18, %r15
    ada3:      	movl	$0x4, %eax
    ada8:      	leaq	0x30(%rsp), %rdi
    adad:      	movl	$0x8, %esi
    adb2:      	movq	%r15, %rdx
    adb5:      	callq	*%rax
    adb7:      	movq	(%rsp), %r15
    adbb:      	movq	%r15, 0x40(%rsp)
    adc0:      	leaq	0x20(%r15), %rdx
    adc4:      	movq	%rdx, 0x38(%rsp)
    adc9:      	movq	0x30(%rsp), %r12
    adce:      	cmpq	0x18(%rsp), %r12
    add3:      	jne	0xade0 <generic_fentry_path+0x920>
    add5:      	cmpq	0x20(%rsp), %rdx
    adda:      	je	0x15f2d <generic_fentry_path+0xba6d>
    ade0:      	movl	$0x4, %eax
    ade5:      	leaq	0x10(%rsp), %rdi
    adea:      	movl	$0x8, %esi
    adef:      	callq	*%rax
    adf1:      	cmpq	0x10(%rsp), %r12
    adf6:      	je	0xaef5 <generic_fentry_path+0xa35>
    adfc:      	leaq	0x18(%r12), %rbx
    ae01:      	movl	$0x4, %eax
    ae06:      	movq	%rbp, %rdi
    ae09:      	movl	$0x8, %esi
    ae0e:      	movq	%rbx, %rdx
    ae11:      	callq	*%rax
    ae13:      	cmpq	%r12, (%rsp)
    ae17:      	je	0xaef5 <generic_fentry_path+0xa35>
    ae1d:      	movl	$0x4, %eax
    ae22:      	leaq	0x8(%rsp), %rdi
    ae27:      	movl	$0x8, %esi
    ae2c:      	movq	%rbx, %rdx
    ae2f:      	callq	*%rax
    ae31:      	addq	$0x20, %r12
    ae35:      	movl	$0x4, %eax
    ae3a:      	leaq	0x58(%rsp), %rdi
    ae3f:      	movl	$0x10, %ecx
    ae44:      	movl	$0x10, %esi
    ae49:      	movq	%r12, %rdx
    ae4c:      	callq	*%rax
    ae4e:      	movq	0x28(%rsp), %rbx
    ae53:      	movq	0x48(%rsp), %rax
    ae58:      	movl	0x5c(%rsp), %r15d
    ae5d:      	subq	%rbx, %rax
    ae60:      	movl	0x50(%rsp), %r12d
    ae65:      	movl	%r15d, %edx
    ae68:      	subl	%r12d, %edx
    ae6b:      	movl	$0x0, %ecx
    ae70:      	cmovbl	%ecx, %edx
    ae73:      	addq	0x60(%rsp), %rdx
    ae78:      	xorl	%esi, %esi
    ae7a:      	cmpl	%r15d, %r12d
    ae7d:      	seta	%sil
    ae81:      	movl	%r15d, %ecx
    ae84:      	cmovbl	%r12d, %ecx
    ae88:      	addl	%ecx, %esi
    ae8a:      	movl	%r12d, %edi
    ae8d:      	subl	%esi, %edi
    ae8f:      	movl	%edi, 0x50(%rsp)
    ae93:      	subq	%rsi, %rax
    ae96:      	jb	0x15f32 <generic_fentry_path+0xba72>
    ae9c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    aea2:      	ja	0x15f32 <generic_fentry_path+0xba72>
    aea8:      	cmpl	%r15d, %r12d
    aeab:      	jbe	0xaeb1 <generic_fentry_path+0x9f1>
    aead:      	movb	$0x2f, (%rbx,%rax)
    aeb1:      	xorl	%edi, %edi
    aeb3:      	cmpl	%r15d, %r12d
    aeb6:      	seta	%dil
    aeba:      	movzbl	%cl, %esi
    aebd:      	addq	%rax, %rbx
    aec0:      	addq	%rbx, %rdi
    aec3:      	movl	$0x4, %eax
    aec8:      	callq	*%rax
    aeca:      	movq	%rbx, 0x48(%rsp)
    aecf:      	cmpl	%r15d, %r12d
    aed2:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    aed8:      	movq	0x8(%rsp), %r12
    aedd:      	movq	%r12, 0x30(%rsp)
    aee2:      	movq	0x38(%rsp), %rdx
    aee7:      	movq	0x40(%rsp), %r15
    aeec:      	cmpq	0x18(%rsp), %r12
    aef1:      	je	0xaf4d <generic_fentry_path+0xa8d>
    aef3:      	jmp	0xaf58 <generic_fentry_path+0xa98>
    aef5:      	leaq	0x10(%r15), %rdx
    aef9:      	movl	$0x4, %eax
    aefe:      	movq	%rbp, %rdi
    af01:      	movl	$0x8, %esi
    af06:      	callq	*%rax
    af08:      	movq	0x40(%rsp), %rax
    af0d:      	cmpq	(%rsp), %rax
    af11:      	je	0x15f2d <generic_fentry_path+0xba6d>
    af17:      	addq	$0x18, %r15
    af1b:      	movl	$0x4, %eax
    af20:      	leaq	0x30(%rsp), %rdi
    af25:      	movl	$0x8, %esi
    af2a:      	movq	%r15, %rdx
    af2d:      	callq	*%rax
    af2f:      	movq	(%rsp), %r15
    af33:      	movq	%r15, 0x40(%rsp)
    af38:      	leaq	0x20(%r15), %rdx
    af3c:      	movq	%rdx, 0x38(%rsp)
    af41:      	movq	0x30(%rsp), %r12
    af46:      	cmpq	0x18(%rsp), %r12
    af4b:      	jne	0xaf58 <generic_fentry_path+0xa98>
    af4d:      	cmpq	0x20(%rsp), %rdx
    af52:      	je	0x15f2d <generic_fentry_path+0xba6d>
    af58:      	movl	$0x4, %eax
    af5d:      	leaq	0x10(%rsp), %rdi
    af62:      	movl	$0x8, %esi
    af67:      	callq	*%rax
    af69:      	cmpq	0x10(%rsp), %r12
    af6e:      	je	0xb06d <generic_fentry_path+0xbad>
    af74:      	leaq	0x18(%r12), %rbx
    af79:      	movl	$0x4, %eax
    af7e:      	movq	%rbp, %rdi
    af81:      	movl	$0x8, %esi
    af86:      	movq	%rbx, %rdx
    af89:      	callq	*%rax
    af8b:      	cmpq	%r12, (%rsp)
    af8f:      	je	0xb06d <generic_fentry_path+0xbad>
    af95:      	movl	$0x4, %eax
    af9a:      	leaq	0x8(%rsp), %rdi
    af9f:      	movl	$0x8, %esi
    afa4:      	movq	%rbx, %rdx
    afa7:      	callq	*%rax
    afa9:      	addq	$0x20, %r12
    afad:      	movl	$0x4, %eax
    afb2:      	leaq	0x58(%rsp), %rdi
    afb7:      	movl	$0x10, %ecx
    afbc:      	movl	$0x10, %esi
    afc1:      	movq	%r12, %rdx
    afc4:      	callq	*%rax
    afc6:      	movq	0x28(%rsp), %rbx
    afcb:      	movq	0x48(%rsp), %rax
    afd0:      	movl	0x5c(%rsp), %r15d
    afd5:      	subq	%rbx, %rax
    afd8:      	movl	0x50(%rsp), %r12d
    afdd:      	movl	%r15d, %edx
    afe0:      	subl	%r12d, %edx
    afe3:      	movl	$0x0, %ecx
    afe8:      	cmovbl	%ecx, %edx
    afeb:      	addq	0x60(%rsp), %rdx
    aff0:      	xorl	%esi, %esi
    aff2:      	cmpl	%r15d, %r12d
    aff5:      	seta	%sil
    aff9:      	movl	%r15d, %ecx
    affc:      	cmovbl	%r12d, %ecx
    b000:      	addl	%ecx, %esi
    b002:      	movl	%r12d, %edi
    b005:      	subl	%esi, %edi
    b007:      	movl	%edi, 0x50(%rsp)
    b00b:      	subq	%rsi, %rax
    b00e:      	jb	0x15f32 <generic_fentry_path+0xba72>
    b014:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b01a:      	ja	0x15f32 <generic_fentry_path+0xba72>
    b020:      	cmpl	%r15d, %r12d
    b023:      	jbe	0xb029 <generic_fentry_path+0xb69>
    b025:      	movb	$0x2f, (%rbx,%rax)
    b029:      	xorl	%edi, %edi
    b02b:      	cmpl	%r15d, %r12d
    b02e:      	seta	%dil
    b032:      	movzbl	%cl, %esi
    b035:      	addq	%rax, %rbx
    b038:      	addq	%rbx, %rdi
    b03b:      	movl	$0x4, %eax
    b040:      	callq	*%rax
    b042:      	movq	%rbx, 0x48(%rsp)
    b047:      	cmpl	%r15d, %r12d
    b04a:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    b050:      	movq	0x8(%rsp), %r12
    b055:      	movq	%r12, 0x30(%rsp)
    b05a:      	movq	0x38(%rsp), %rdx
    b05f:      	movq	0x40(%rsp), %r15
    b064:      	cmpq	0x18(%rsp), %r12
    b069:      	je	0xb0c5 <generic_fentry_path+0xc05>
    b06b:      	jmp	0xb0d0 <generic_fentry_path+0xc10>
    b06d:      	leaq	0x10(%r15), %rdx
    b071:      	movl	$0x4, %eax
    b076:      	movq	%rbp, %rdi
    b079:      	movl	$0x8, %esi
    b07e:      	callq	*%rax
    b080:      	movq	0x40(%rsp), %rax
    b085:      	cmpq	(%rsp), %rax
    b089:      	je	0x15f2d <generic_fentry_path+0xba6d>
    b08f:      	addq	$0x18, %r15
    b093:      	movl	$0x4, %eax
    b098:      	leaq	0x30(%rsp), %rdi
    b09d:      	movl	$0x8, %esi
    b0a2:      	movq	%r15, %rdx
    b0a5:      	callq	*%rax
    b0a7:      	movq	(%rsp), %r15
    b0ab:      	movq	%r15, 0x40(%rsp)
    b0b0:      	leaq	0x20(%r15), %rdx
    b0b4:      	movq	%rdx, 0x38(%rsp)
    b0b9:      	movq	0x30(%rsp), %r12
    b0be:      	cmpq	0x18(%rsp), %r12
    b0c3:      	jne	0xb0d0 <generic_fentry_path+0xc10>
    b0c5:      	cmpq	0x20(%rsp), %rdx
    b0ca:      	je	0x15f2d <generic_fentry_path+0xba6d>
    b0d0:      	movl	$0x4, %eax
    b0d5:      	leaq	0x10(%rsp), %rdi
    b0da:      	movl	$0x8, %esi
    b0df:      	callq	*%rax
    b0e1:      	cmpq	0x10(%rsp), %r12
    b0e6:      	je	0xb1e5 <generic_fentry_path+0xd25>
    b0ec:      	leaq	0x18(%r12), %rbx
    b0f1:      	movl	$0x4, %eax
    b0f6:      	movq	%rbp, %rdi
    b0f9:      	movl	$0x8, %esi
    b0fe:      	movq	%rbx, %rdx
    b101:      	callq	*%rax
    b103:      	cmpq	%r12, (%rsp)
    b107:      	je	0xb1e5 <generic_fentry_path+0xd25>
    b10d:      	movl	$0x4, %eax
    b112:      	leaq	0x8(%rsp), %rdi
    b117:      	movl	$0x8, %esi
    b11c:      	movq	%rbx, %rdx
    b11f:      	callq	*%rax
    b121:      	addq	$0x20, %r12
    b125:      	movl	$0x4, %eax
    b12a:      	leaq	0x58(%rsp), %rdi
    b12f:      	movl	$0x10, %ecx
    b134:      	movl	$0x10, %esi
    b139:      	movq	%r12, %rdx
    b13c:      	callq	*%rax
    b13e:      	movq	0x28(%rsp), %rbx
    b143:      	movq	0x48(%rsp), %rax
    b148:      	movl	0x5c(%rsp), %r15d
    b14d:      	subq	%rbx, %rax
    b150:      	movl	0x50(%rsp), %r12d
    b155:      	movl	%r15d, %edx
    b158:      	subl	%r12d, %edx
    b15b:      	movl	$0x0, %ecx
    b160:      	cmovbl	%ecx, %edx
    b163:      	addq	0x60(%rsp), %rdx
    b168:      	xorl	%esi, %esi
    b16a:      	cmpl	%r15d, %r12d
    b16d:      	seta	%sil
    b171:      	movl	%r15d, %ecx
    b174:      	cmovbl	%r12d, %ecx
    b178:      	addl	%ecx, %esi
    b17a:      	movl	%r12d, %edi
    b17d:      	subl	%esi, %edi
    b17f:      	movl	%edi, 0x50(%rsp)
    b183:      	subq	%rsi, %rax
    b186:      	jb	0x15f32 <generic_fentry_path+0xba72>
    b18c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b192:      	ja	0x15f32 <generic_fentry_path+0xba72>
    b198:      	cmpl	%r15d, %r12d
    b19b:      	jbe	0xb1a1 <generic_fentry_path+0xce1>
    b19d:      	movb	$0x2f, (%rbx,%rax)
    b1a1:      	xorl	%edi, %edi
    b1a3:      	cmpl	%r15d, %r12d
    b1a6:      	seta	%dil
    b1aa:      	movzbl	%cl, %esi
    b1ad:      	addq	%rax, %rbx
    b1b0:      	addq	%rbx, %rdi
    b1b3:      	movl	$0x4, %eax
    b1b8:      	callq	*%rax
    b1ba:      	movq	%rbx, 0x48(%rsp)
    b1bf:      	cmpl	%r15d, %r12d
    b1c2:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    b1c8:      	movq	0x8(%rsp), %r12
    b1cd:      	movq	%r12, 0x30(%rsp)
    b1d2:      	movq	0x38(%rsp), %rdx
    b1d7:      	movq	0x40(%rsp), %r15
    b1dc:      	cmpq	0x18(%rsp), %r12
    b1e1:      	je	0xb23d <generic_fentry_path+0xd7d>
    b1e3:      	jmp	0xb248 <generic_fentry_path+0xd88>
    b1e5:      	leaq	0x10(%r15), %rdx
    b1e9:      	movl	$0x4, %eax
    b1ee:      	movq	%rbp, %rdi
    b1f1:      	movl	$0x8, %esi
    b1f6:      	callq	*%rax
    b1f8:      	movq	0x40(%rsp), %rax
    b1fd:      	cmpq	(%rsp), %rax
    b201:      	je	0x15f2d <generic_fentry_path+0xba6d>
    b207:      	addq	$0x18, %r15
    b20b:      	movl	$0x4, %eax
    b210:      	leaq	0x30(%rsp), %rdi
    b215:      	movl	$0x8, %esi
    b21a:      	movq	%r15, %rdx
    b21d:      	callq	*%rax
    b21f:      	movq	(%rsp), %r15
    b223:      	movq	%r15, 0x40(%rsp)
    b228:      	leaq	0x20(%r15), %rdx
    b22c:      	movq	%rdx, 0x38(%rsp)
    b231:      	movq	0x30(%rsp), %r12
    b236:      	cmpq	0x18(%rsp), %r12
    b23b:      	jne	0xb248 <generic_fentry_path+0xd88>
    b23d:      	cmpq	0x20(%rsp), %rdx
    b242:      	je	0x15f2d <generic_fentry_path+0xba6d>
    b248:      	movl	$0x4, %eax
    b24d:      	leaq	0x10(%rsp), %rdi
    b252:      	movl	$0x8, %esi
    b257:      	callq	*%rax
    b259:      	cmpq	0x10(%rsp), %r12
    b25e:      	je	0xb35d <generic_fentry_path+0xe9d>
    b264:      	leaq	0x18(%r12), %rbx
    b269:      	movl	$0x4, %eax
    b26e:      	movq	%rbp, %rdi
    b271:      	movl	$0x8, %esi
    b276:      	movq	%rbx, %rdx
    b279:      	callq	*%rax
    b27b:      	cmpq	%r12, (%rsp)
    b27f:      	je	0xb35d <generic_fentry_path+0xe9d>
    b285:      	movl	$0x4, %eax
    b28a:      	leaq	0x8(%rsp), %rdi
    b28f:      	movl	$0x8, %esi
    b294:      	movq	%rbx, %rdx
    b297:      	callq	*%rax
    b299:      	addq	$0x20, %r12
    b29d:      	movl	$0x4, %eax
    b2a2:      	leaq	0x58(%rsp), %rdi
    b2a7:      	movl	$0x10, %ecx
    b2ac:      	movl	$0x10, %esi
    b2b1:      	movq	%r12, %rdx
    b2b4:      	callq	*%rax
    b2b6:      	movq	0x28(%rsp), %rbx
    b2bb:      	movq	0x48(%rsp), %rax
    b2c0:      	movl	0x5c(%rsp), %r15d
    b2c5:      	subq	%rbx, %rax
    b2c8:      	movl	0x50(%rsp), %r12d
    b2cd:      	movl	%r15d, %edx
    b2d0:      	subl	%r12d, %edx
    b2d3:      	movl	$0x0, %ecx
    b2d8:      	cmovbl	%ecx, %edx
    b2db:      	addq	0x60(%rsp), %rdx
    b2e0:      	xorl	%esi, %esi
    b2e2:      	cmpl	%r15d, %r12d
    b2e5:      	seta	%sil
    b2e9:      	movl	%r15d, %ecx
    b2ec:      	cmovbl	%r12d, %ecx
    b2f0:      	addl	%ecx, %esi
    b2f2:      	movl	%r12d, %edi
    b2f5:      	subl	%esi, %edi
    b2f7:      	movl	%edi, 0x50(%rsp)
    b2fb:      	subq	%rsi, %rax
    b2fe:      	jb	0x15f32 <generic_fentry_path+0xba72>
    b304:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b30a:      	ja	0x15f32 <generic_fentry_path+0xba72>
    b310:      	cmpl	%r15d, %r12d
    b313:      	jbe	0xb319 <generic_fentry_path+0xe59>
    b315:      	movb	$0x2f, (%rbx,%rax)
    b319:      	xorl	%edi, %edi
    b31b:      	cmpl	%r15d, %r12d
    b31e:      	seta	%dil
    b322:      	movzbl	%cl, %esi
    b325:      	addq	%rax, %rbx
    b328:      	addq	%rbx, %rdi
    b32b:      	movl	$0x4, %eax
    b330:      	callq	*%rax
    b332:      	movq	%rbx, 0x48(%rsp)
    b337:      	cmpl	%r15d, %r12d
    b33a:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    b340:      	movq	0x8(%rsp), %r12
    b345:      	movq	%r12, 0x30(%rsp)
    b34a:      	movq	0x38(%rsp), %rdx
    b34f:      	movq	0x40(%rsp), %r15
    b354:      	cmpq	0x18(%rsp), %r12
    b359:      	je	0xb3b5 <generic_fentry_path+0xef5>
    b35b:      	jmp	0xb3c0 <generic_fentry_path+0xf00>
    b35d:      	leaq	0x10(%r15), %rdx
    b361:      	movl	$0x4, %eax
    b366:      	movq	%rbp, %rdi
    b369:      	movl	$0x8, %esi
    b36e:      	callq	*%rax
    b370:      	movq	0x40(%rsp), %rax
    b375:      	cmpq	(%rsp), %rax
    b379:      	je	0x15f2d <generic_fentry_path+0xba6d>
    b37f:      	addq	$0x18, %r15
    b383:      	movl	$0x4, %eax
    b388:      	leaq	0x30(%rsp), %rdi
    b38d:      	movl	$0x8, %esi
    b392:      	movq	%r15, %rdx
    b395:      	callq	*%rax
    b397:      	movq	(%rsp), %r15
    b39b:      	movq	%r15, 0x40(%rsp)
    b3a0:      	leaq	0x20(%r15), %rdx
    b3a4:      	movq	%rdx, 0x38(%rsp)
    b3a9:      	movq	0x30(%rsp), %r12
    b3ae:      	cmpq	0x18(%rsp), %r12
    b3b3:      	jne	0xb3c0 <generic_fentry_path+0xf00>
    b3b5:      	cmpq	0x20(%rsp), %rdx
    b3ba:      	je	0x15f2d <generic_fentry_path+0xba6d>
    b3c0:      	movl	$0x4, %eax
    b3c5:      	leaq	0x10(%rsp), %rdi
    b3ca:      	movl	$0x8, %esi
    b3cf:      	callq	*%rax
    b3d1:      	cmpq	0x10(%rsp), %r12
    b3d6:      	je	0xb4ce <generic_fentry_path+0x100e>
    b3dc:      	leaq	0x18(%r12), %rbx
    b3e1:      	movl	$0x4, %eax
    b3e6:      	movq	%rbp, %rdi
    b3e9:      	movl	$0x8, %esi
    b3ee:      	movq	%rbx, %rdx
    b3f1:      	callq	*%rax
    b3f3:      	cmpq	%r12, (%rsp)
    b3f7:      	je	0xb4ce <generic_fentry_path+0x100e>
    b3fd:      	movl	$0x4, %eax
    b402:      	leaq	0x8(%rsp), %rdi
    b407:      	movl	$0x8, %esi
    b40c:      	movq	%rbx, %rdx
    b40f:      	callq	*%rax
    b411:      	addq	$0x20, %r12
    b415:      	movl	$0x4, %eax
    b41a:      	leaq	0x58(%rsp), %rdi
    b41f:      	movl	$0x10, %ecx
    b424:      	movl	$0x10, %esi
    b429:      	movq	%r12, %rdx
    b42c:      	callq	*%rax
    b42e:      	movq	0x28(%rsp), %rbx
    b433:      	movq	0x48(%rsp), %rax
    b438:      	movl	0x5c(%rsp), %r15d
    b43d:      	subq	%rbx, %rax
    b440:      	movl	0x50(%rsp), %r12d
    b445:      	movl	%r15d, %edx
    b448:      	subl	%r12d, %edx
    b44b:      	movl	$0x0, %ecx
    b450:      	cmovbl	%ecx, %edx
    b453:      	addq	0x60(%rsp), %rdx
    b458:      	xorl	%esi, %esi
    b45a:      	cmpl	%r15d, %r12d
    b45d:      	seta	%sil
    b461:      	movl	%r15d, %ecx
    b464:      	cmovbl	%r12d, %ecx
    b468:      	addl	%ecx, %esi
    b46a:      	movl	%r12d, %edi
    b46d:      	subl	%esi, %edi
    b46f:      	movl	%edi, 0x50(%rsp)
    b473:      	subq	%rsi, %rax
    b476:      	jb	0x15f32 <generic_fentry_path+0xba72>
    b47c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b482:      	ja	0x15f32 <generic_fentry_path+0xba72>
    b488:      	cmpl	%r15d, %r12d
    b48b:      	jbe	0xb491 <generic_fentry_path+0xfd1>
    b48d:      	movb	$0x2f, (%rbx,%rax)
    b491:      	xorl	%edi, %edi
    b493:      	cmpl	%r15d, %r12d
    b496:      	seta	%dil
    b49a:      	movzbl	%cl, %esi
    b49d:      	addq	%rax, %rbx
    b4a0:      	addq	%rbx, %rdi
    b4a3:      	movl	$0x4, %eax
    b4a8:      	callq	*%rax
    b4aa:      	movq	%rbx, 0x48(%rsp)
    b4af:      	cmpl	%r15d, %r12d
    b4b2:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    b4b8:      	movq	0x8(%rsp), %r12
    b4bd:      	movq	%r12, 0x30(%rsp)
    b4c2:      	movq	0x38(%rsp), %rdx
    b4c7:      	movq	0x40(%rsp), %r15
    b4cc:      	jmp	0xb51f <generic_fentry_path+0x105f>
    b4ce:      	leaq	0x10(%r15), %rdx
    b4d2:      	movl	$0x4, %eax
    b4d7:      	movq	%rbp, %rdi
    b4da:      	movl	$0x8, %esi
    b4df:      	callq	*%rax
    b4e1:      	movq	0x40(%rsp), %rax
    b4e6:      	cmpq	(%rsp), %rax
    b4ea:      	je	0x15f2d <generic_fentry_path+0xba6d>
    b4f0:      	addq	$0x18, %r15
    b4f4:      	movl	$0x4, %eax
    b4f9:      	leaq	0x30(%rsp), %rdi
    b4fe:      	movl	$0x8, %esi
    b503:      	movq	%r15, %rdx
    b506:      	callq	*%rax
    b508:      	movq	(%rsp), %r15
    b50c:      	movq	%r15, 0x40(%rsp)
    b511:      	leaq	0x20(%r15), %rdx
    b515:      	movq	%rdx, 0x38(%rsp)
    b51a:      	movq	0x30(%rsp), %r12
    b51f:      	cmpq	0x18(%rsp), %r12
    b524:      	jne	0xb531 <generic_fentry_path+0x1071>
    b526:      	cmpq	0x20(%rsp), %rdx
    b52b:      	je	0x15f2d <generic_fentry_path+0xba6d>
    b531:      	movl	$0x4, %eax
    b536:      	leaq	0x10(%rsp), %rdi
    b53b:      	movl	$0x8, %esi
    b540:      	callq	*%rax
    b542:      	cmpq	0x10(%rsp), %r12
    b547:      	je	0xb63f <generic_fentry_path+0x117f>
    b54d:      	leaq	0x18(%r12), %rbx
    b552:      	movl	$0x4, %eax
    b557:      	movq	%rbp, %rdi
    b55a:      	movl	$0x8, %esi
    b55f:      	movq	%rbx, %rdx
    b562:      	callq	*%rax
    b564:      	cmpq	%r12, (%rsp)
    b568:      	je	0xb63f <generic_fentry_path+0x117f>
    b56e:      	movl	$0x4, %eax
    b573:      	leaq	0x8(%rsp), %rdi
    b578:      	movl	$0x8, %esi
    b57d:      	movq	%rbx, %rdx
    b580:      	callq	*%rax
    b582:      	addq	$0x20, %r12
    b586:      	movl	$0x4, %eax
    b58b:      	leaq	0x58(%rsp), %rdi
    b590:      	movl	$0x10, %ecx
    b595:      	movl	$0x10, %esi
    b59a:      	movq	%r12, %rdx
    b59d:      	callq	*%rax
    b59f:      	movq	0x28(%rsp), %rbx
    b5a4:      	movq	0x48(%rsp), %rax
    b5a9:      	movl	0x5c(%rsp), %r15d
    b5ae:      	subq	%rbx, %rax
    b5b1:      	movl	0x50(%rsp), %r12d
    b5b6:      	movl	%r15d, %edx
    b5b9:      	subl	%r12d, %edx
    b5bc:      	movl	$0x0, %ecx
    b5c1:      	cmovbl	%ecx, %edx
    b5c4:      	addq	0x60(%rsp), %rdx
    b5c9:      	xorl	%esi, %esi
    b5cb:      	cmpl	%r15d, %r12d
    b5ce:      	seta	%sil
    b5d2:      	movl	%r15d, %ecx
    b5d5:      	cmovbl	%r12d, %ecx
    b5d9:      	addl	%ecx, %esi
    b5db:      	movl	%r12d, %edi
    b5de:      	subl	%esi, %edi
    b5e0:      	movl	%edi, 0x50(%rsp)
    b5e4:      	subq	%rsi, %rax
    b5e7:      	jb	0x15f32 <generic_fentry_path+0xba72>
    b5ed:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b5f3:      	ja	0x15f32 <generic_fentry_path+0xba72>
    b5f9:      	cmpl	%r15d, %r12d
    b5fc:      	jbe	0xb602 <generic_fentry_path+0x1142>
    b5fe:      	movb	$0x2f, (%rbx,%rax)
    b602:      	xorl	%edi, %edi
    b604:      	cmpl	%r15d, %r12d
    b607:      	seta	%dil
    b60b:      	movzbl	%cl, %esi
    b60e:      	addq	%rax, %rbx
    b611:      	addq	%rbx, %rdi
    b614:      	movl	$0x4, %eax
    b619:      	callq	*%rax
    b61b:      	movq	%rbx, 0x48(%rsp)
    b620:      	cmpl	%r15d, %r12d
    b623:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    b629:      	movq	0x8(%rsp), %r12
    b62e:      	movq	%r12, 0x30(%rsp)
    b633:      	movq	0x38(%rsp), %rdx
    b638:      	movq	0x40(%rsp), %r15
    b63d:      	jmp	0xb690 <generic_fentry_path+0x11d0>
    b63f:      	leaq	0x10(%r15), %rdx
    b643:      	movl	$0x4, %eax
    b648:      	movq	%rbp, %rdi
    b64b:      	movl	$0x8, %esi
    b650:      	callq	*%rax
    b652:      	movq	0x40(%rsp), %rax
    b657:      	cmpq	(%rsp), %rax
    b65b:      	je	0x15f2d <generic_fentry_path+0xba6d>
    b661:      	addq	$0x18, %r15
    b665:      	movl	$0x4, %eax
    b66a:      	leaq	0x30(%rsp), %rdi
    b66f:      	movl	$0x8, %esi
    b674:      	movq	%r15, %rdx
    b677:      	callq	*%rax
    b679:      	movq	(%rsp), %r15
    b67d:      	movq	%r15, 0x40(%rsp)
    b682:      	leaq	0x20(%r15), %rdx
    b686:      	movq	%rdx, 0x38(%rsp)
    b68b:      	movq	0x30(%rsp), %r12
    b690:      	cmpq	0x18(%rsp), %r12
    b695:      	jne	0xb6a2 <generic_fentry_path+0x11e2>
    b697:      	cmpq	0x20(%rsp), %rdx
    b69c:      	je	0x15f2d <generic_fentry_path+0xba6d>
    b6a2:      	movl	$0x4, %eax
    b6a7:      	leaq	0x10(%rsp), %rdi
    b6ac:      	movl	$0x8, %esi
    b6b1:      	callq	*%rax
    b6b3:      	cmpq	0x10(%rsp), %r12
    b6b8:      	je	0xb7b0 <generic_fentry_path+0x12f0>
    b6be:      	leaq	0x18(%r12), %rbx
    b6c3:      	movl	$0x4, %eax
    b6c8:      	movq	%rbp, %rdi
    b6cb:      	movl	$0x8, %esi
    b6d0:      	movq	%rbx, %rdx
    b6d3:      	callq	*%rax
    b6d5:      	cmpq	%r12, (%rsp)
    b6d9:      	je	0xb7b0 <generic_fentry_path+0x12f0>
    b6df:      	movl	$0x4, %eax
    b6e4:      	leaq	0x8(%rsp), %rdi
    b6e9:      	movl	$0x8, %esi
    b6ee:      	movq	%rbx, %rdx
    b6f1:      	callq	*%rax
    b6f3:      	addq	$0x20, %r12
    b6f7:      	movl	$0x4, %eax
    b6fc:      	leaq	0x58(%rsp), %rdi
    b701:      	movl	$0x10, %ecx
    b706:      	movl	$0x10, %esi
    b70b:      	movq	%r12, %rdx
    b70e:      	callq	*%rax
    b710:      	movq	0x28(%rsp), %rbx
    b715:      	movq	0x48(%rsp), %rax
    b71a:      	movl	0x5c(%rsp), %r15d
    b71f:      	subq	%rbx, %rax
    b722:      	movl	0x50(%rsp), %r12d
    b727:      	movl	%r15d, %edx
    b72a:      	subl	%r12d, %edx
    b72d:      	movl	$0x0, %ecx
    b732:      	cmovbl	%ecx, %edx
    b735:      	addq	0x60(%rsp), %rdx
    b73a:      	xorl	%esi, %esi
    b73c:      	cmpl	%r15d, %r12d
    b73f:      	seta	%sil
    b743:      	movl	%r15d, %ecx
    b746:      	cmovbl	%r12d, %ecx
    b74a:      	addl	%ecx, %esi
    b74c:      	movl	%r12d, %edi
    b74f:      	subl	%esi, %edi
    b751:      	movl	%edi, 0x50(%rsp)
    b755:      	subq	%rsi, %rax
    b758:      	jb	0x15f32 <generic_fentry_path+0xba72>
    b75e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b764:      	ja	0x15f32 <generic_fentry_path+0xba72>
    b76a:      	cmpl	%r15d, %r12d
    b76d:      	jbe	0xb773 <generic_fentry_path+0x12b3>
    b76f:      	movb	$0x2f, (%rbx,%rax)
    b773:      	xorl	%edi, %edi
    b775:      	cmpl	%r15d, %r12d
    b778:      	seta	%dil
    b77c:      	movzbl	%cl, %esi
    b77f:      	addq	%rax, %rbx
    b782:      	addq	%rbx, %rdi
    b785:      	movl	$0x4, %eax
    b78a:      	callq	*%rax
    b78c:      	movq	%rbx, 0x48(%rsp)
    b791:      	cmpl	%r15d, %r12d
    b794:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    b79a:      	movq	0x8(%rsp), %r12
    b79f:      	movq	%r12, 0x30(%rsp)
    b7a4:      	movq	0x38(%rsp), %rdx
    b7a9:      	movq	0x40(%rsp), %r15
    b7ae:      	jmp	0xb801 <generic_fentry_path+0x1341>
    b7b0:      	leaq	0x10(%r15), %rdx
    b7b4:      	movl	$0x4, %eax
    b7b9:      	movq	%rbp, %rdi
    b7bc:      	movl	$0x8, %esi
    b7c1:      	callq	*%rax
    b7c3:      	movq	0x40(%rsp), %rax
    b7c8:      	cmpq	(%rsp), %rax
    b7cc:      	je	0x15f2d <generic_fentry_path+0xba6d>
    b7d2:      	addq	$0x18, %r15
    b7d6:      	movl	$0x4, %eax
    b7db:      	leaq	0x30(%rsp), %rdi
    b7e0:      	movl	$0x8, %esi
    b7e5:      	movq	%r15, %rdx
    b7e8:      	callq	*%rax
    b7ea:      	movq	(%rsp), %r15
    b7ee:      	movq	%r15, 0x40(%rsp)
    b7f3:      	leaq	0x20(%r15), %rdx
    b7f7:      	movq	%rdx, 0x38(%rsp)
    b7fc:      	movq	0x30(%rsp), %r12
    b801:      	cmpq	0x18(%rsp), %r12
    b806:      	jne	0xb813 <generic_fentry_path+0x1353>
    b808:      	cmpq	0x20(%rsp), %rdx
    b80d:      	je	0x15f2d <generic_fentry_path+0xba6d>
    b813:      	movl	$0x4, %eax
    b818:      	leaq	0x10(%rsp), %rdi
    b81d:      	movl	$0x8, %esi
    b822:      	callq	*%rax
    b824:      	cmpq	0x10(%rsp), %r12
    b829:      	je	0xb921 <generic_fentry_path+0x1461>
    b82f:      	leaq	0x18(%r12), %rbx
    b834:      	movl	$0x4, %eax
    b839:      	movq	%rbp, %rdi
    b83c:      	movl	$0x8, %esi
    b841:      	movq	%rbx, %rdx
    b844:      	callq	*%rax
    b846:      	cmpq	%r12, (%rsp)
    b84a:      	je	0xb921 <generic_fentry_path+0x1461>
    b850:      	movl	$0x4, %eax
    b855:      	leaq	0x8(%rsp), %rdi
    b85a:      	movl	$0x8, %esi
    b85f:      	movq	%rbx, %rdx
    b862:      	callq	*%rax
    b864:      	addq	$0x20, %r12
    b868:      	movl	$0x4, %eax
    b86d:      	leaq	0x58(%rsp), %rdi
    b872:      	movl	$0x10, %ecx
    b877:      	movl	$0x10, %esi
    b87c:      	movq	%r12, %rdx
    b87f:      	callq	*%rax
    b881:      	movq	0x28(%rsp), %rbx
    b886:      	movq	0x48(%rsp), %rax
    b88b:      	movl	0x5c(%rsp), %r15d
    b890:      	subq	%rbx, %rax
    b893:      	movl	0x50(%rsp), %r12d
    b898:      	movl	%r15d, %edx
    b89b:      	subl	%r12d, %edx
    b89e:      	movl	$0x0, %ecx
    b8a3:      	cmovbl	%ecx, %edx
    b8a6:      	addq	0x60(%rsp), %rdx
    b8ab:      	xorl	%esi, %esi
    b8ad:      	cmpl	%r15d, %r12d
    b8b0:      	seta	%sil
    b8b4:      	movl	%r15d, %ecx
    b8b7:      	cmovbl	%r12d, %ecx
    b8bb:      	addl	%ecx, %esi
    b8bd:      	movl	%r12d, %edi
    b8c0:      	subl	%esi, %edi
    b8c2:      	movl	%edi, 0x50(%rsp)
    b8c6:      	subq	%rsi, %rax
    b8c9:      	jb	0x15f32 <generic_fentry_path+0xba72>
    b8cf:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b8d5:      	ja	0x15f32 <generic_fentry_path+0xba72>
    b8db:      	cmpl	%r15d, %r12d
    b8de:      	jbe	0xb8e4 <generic_fentry_path+0x1424>
    b8e0:      	movb	$0x2f, (%rbx,%rax)
    b8e4:      	xorl	%edi, %edi
    b8e6:      	cmpl	%r15d, %r12d
    b8e9:      	seta	%dil
    b8ed:      	movzbl	%cl, %esi
    b8f0:      	addq	%rax, %rbx
    b8f3:      	addq	%rbx, %rdi
    b8f6:      	movl	$0x4, %eax
    b8fb:      	callq	*%rax
    b8fd:      	movq	%rbx, 0x48(%rsp)
    b902:      	cmpl	%r15d, %r12d
    b905:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    b90b:      	movq	0x8(%rsp), %r12
    b910:      	movq	%r12, 0x30(%rsp)
    b915:      	movq	0x38(%rsp), %rdx
    b91a:      	movq	0x40(%rsp), %r15
    b91f:      	jmp	0xb972 <generic_fentry_path+0x14b2>
    b921:      	leaq	0x10(%r15), %rdx
    b925:      	movl	$0x4, %eax
    b92a:      	movq	%rbp, %rdi
    b92d:      	movl	$0x8, %esi
    b932:      	callq	*%rax
    b934:      	movq	0x40(%rsp), %rax
    b939:      	cmpq	(%rsp), %rax
    b93d:      	je	0x15f2d <generic_fentry_path+0xba6d>
    b943:      	addq	$0x18, %r15
    b947:      	movl	$0x4, %eax
    b94c:      	leaq	0x30(%rsp), %rdi
    b951:      	movl	$0x8, %esi
    b956:      	movq	%r15, %rdx
    b959:      	callq	*%rax
    b95b:      	movq	(%rsp), %r15
    b95f:      	movq	%r15, 0x40(%rsp)
    b964:      	leaq	0x20(%r15), %rdx
    b968:      	movq	%rdx, 0x38(%rsp)
    b96d:      	movq	0x30(%rsp), %r12
    b972:      	cmpq	0x18(%rsp), %r12
    b977:      	jne	0xb984 <generic_fentry_path+0x14c4>
    b979:      	cmpq	0x20(%rsp), %rdx
    b97e:      	je	0x15f2d <generic_fentry_path+0xba6d>
    b984:      	movl	$0x4, %eax
    b989:      	leaq	0x10(%rsp), %rdi
    b98e:      	movl	$0x8, %esi
    b993:      	callq	*%rax
    b995:      	cmpq	0x10(%rsp), %r12
    b99a:      	je	0xba92 <generic_fentry_path+0x15d2>
    b9a0:      	leaq	0x18(%r12), %rbx
    b9a5:      	movl	$0x4, %eax
    b9aa:      	movq	%rbp, %rdi
    b9ad:      	movl	$0x8, %esi
    b9b2:      	movq	%rbx, %rdx
    b9b5:      	callq	*%rax
    b9b7:      	cmpq	%r12, (%rsp)
    b9bb:      	je	0xba92 <generic_fentry_path+0x15d2>
    b9c1:      	movl	$0x4, %eax
    b9c6:      	leaq	0x8(%rsp), %rdi
    b9cb:      	movl	$0x8, %esi
    b9d0:      	movq	%rbx, %rdx
    b9d3:      	callq	*%rax
    b9d5:      	addq	$0x20, %r12
    b9d9:      	movl	$0x4, %eax
    b9de:      	leaq	0x58(%rsp), %rdi
    b9e3:      	movl	$0x10, %ecx
    b9e8:      	movl	$0x10, %esi
    b9ed:      	movq	%r12, %rdx
    b9f0:      	callq	*%rax
    b9f2:      	movq	0x28(%rsp), %rbx
    b9f7:      	movq	0x48(%rsp), %rax
    b9fc:      	movl	0x5c(%rsp), %r15d
    ba01:      	subq	%rbx, %rax
    ba04:      	movl	0x50(%rsp), %r12d
    ba09:      	movl	%r15d, %edx
    ba0c:      	subl	%r12d, %edx
    ba0f:      	movl	$0x0, %ecx
    ba14:      	cmovbl	%ecx, %edx
    ba17:      	addq	0x60(%rsp), %rdx
    ba1c:      	xorl	%esi, %esi
    ba1e:      	cmpl	%r15d, %r12d
    ba21:      	seta	%sil
    ba25:      	movl	%r15d, %ecx
    ba28:      	cmovbl	%r12d, %ecx
    ba2c:      	addl	%ecx, %esi
    ba2e:      	movl	%r12d, %edi
    ba31:      	subl	%esi, %edi
    ba33:      	movl	%edi, 0x50(%rsp)
    ba37:      	subq	%rsi, %rax
    ba3a:      	jb	0x15f32 <generic_fentry_path+0xba72>
    ba40:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ba46:      	ja	0x15f32 <generic_fentry_path+0xba72>
    ba4c:      	cmpl	%r15d, %r12d
    ba4f:      	jbe	0xba55 <generic_fentry_path+0x1595>
    ba51:      	movb	$0x2f, (%rbx,%rax)
    ba55:      	xorl	%edi, %edi
    ba57:      	cmpl	%r15d, %r12d
    ba5a:      	seta	%dil
    ba5e:      	movzbl	%cl, %esi
    ba61:      	addq	%rax, %rbx
    ba64:      	addq	%rbx, %rdi
    ba67:      	movl	$0x4, %eax
    ba6c:      	callq	*%rax
    ba6e:      	movq	%rbx, 0x48(%rsp)
    ba73:      	cmpl	%r15d, %r12d
    ba76:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    ba7c:      	movq	0x8(%rsp), %r12
    ba81:      	movq	%r12, 0x30(%rsp)
    ba86:      	movq	0x38(%rsp), %rdx
    ba8b:      	movq	0x40(%rsp), %r15
    ba90:      	jmp	0xbae3 <generic_fentry_path+0x1623>
    ba92:      	leaq	0x10(%r15), %rdx
    ba96:      	movl	$0x4, %eax
    ba9b:      	movq	%rbp, %rdi
    ba9e:      	movl	$0x8, %esi
    baa3:      	callq	*%rax
    baa5:      	movq	0x40(%rsp), %rax
    baaa:      	cmpq	(%rsp), %rax
    baae:      	je	0x15f2d <generic_fentry_path+0xba6d>
    bab4:      	addq	$0x18, %r15
    bab8:      	movl	$0x4, %eax
    babd:      	leaq	0x30(%rsp), %rdi
    bac2:      	movl	$0x8, %esi
    bac7:      	movq	%r15, %rdx
    baca:      	callq	*%rax
    bacc:      	movq	(%rsp), %r15
    bad0:      	movq	%r15, 0x40(%rsp)
    bad5:      	leaq	0x20(%r15), %rdx
    bad9:      	movq	%rdx, 0x38(%rsp)
    bade:      	movq	0x30(%rsp), %r12
    bae3:      	cmpq	0x18(%rsp), %r12
    bae8:      	jne	0xbaf5 <generic_fentry_path+0x1635>
    baea:      	cmpq	0x20(%rsp), %rdx
    baef:      	je	0x15f2d <generic_fentry_path+0xba6d>
    baf5:      	movl	$0x4, %eax
    bafa:      	leaq	0x10(%rsp), %rdi
    baff:      	movl	$0x8, %esi
    bb04:      	callq	*%rax
    bb06:      	cmpq	0x10(%rsp), %r12
    bb0b:      	je	0xbc03 <generic_fentry_path+0x1743>
    bb11:      	leaq	0x18(%r12), %rbx
    bb16:      	movl	$0x4, %eax
    bb1b:      	movq	%rbp, %rdi
    bb1e:      	movl	$0x8, %esi
    bb23:      	movq	%rbx, %rdx
    bb26:      	callq	*%rax
    bb28:      	cmpq	%r12, (%rsp)
    bb2c:      	je	0xbc03 <generic_fentry_path+0x1743>
    bb32:      	movl	$0x4, %eax
    bb37:      	leaq	0x8(%rsp), %rdi
    bb3c:      	movl	$0x8, %esi
    bb41:      	movq	%rbx, %rdx
    bb44:      	callq	*%rax
    bb46:      	addq	$0x20, %r12
    bb4a:      	movl	$0x4, %eax
    bb4f:      	leaq	0x58(%rsp), %rdi
    bb54:      	movl	$0x10, %ecx
    bb59:      	movl	$0x10, %esi
    bb5e:      	movq	%r12, %rdx
    bb61:      	callq	*%rax
    bb63:      	movq	0x28(%rsp), %rbx
    bb68:      	movq	0x48(%rsp), %rax
    bb6d:      	movl	0x5c(%rsp), %r15d
    bb72:      	subq	%rbx, %rax
    bb75:      	movl	0x50(%rsp), %r12d
    bb7a:      	movl	%r15d, %edx
    bb7d:      	subl	%r12d, %edx
    bb80:      	movl	$0x0, %ecx
    bb85:      	cmovbl	%ecx, %edx
    bb88:      	addq	0x60(%rsp), %rdx
    bb8d:      	xorl	%esi, %esi
    bb8f:      	cmpl	%r15d, %r12d
    bb92:      	seta	%sil
    bb96:      	movl	%r15d, %ecx
    bb99:      	cmovbl	%r12d, %ecx
    bb9d:      	addl	%ecx, %esi
    bb9f:      	movl	%r12d, %edi
    bba2:      	subl	%esi, %edi
    bba4:      	movl	%edi, 0x50(%rsp)
    bba8:      	subq	%rsi, %rax
    bbab:      	jb	0x15f32 <generic_fentry_path+0xba72>
    bbb1:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    bbb7:      	ja	0x15f32 <generic_fentry_path+0xba72>
    bbbd:      	cmpl	%r15d, %r12d
    bbc0:      	jbe	0xbbc6 <generic_fentry_path+0x1706>
    bbc2:      	movb	$0x2f, (%rbx,%rax)
    bbc6:      	xorl	%edi, %edi
    bbc8:      	cmpl	%r15d, %r12d
    bbcb:      	seta	%dil
    bbcf:      	movzbl	%cl, %esi
    bbd2:      	addq	%rax, %rbx
    bbd5:      	addq	%rbx, %rdi
    bbd8:      	movl	$0x4, %eax
    bbdd:      	callq	*%rax
    bbdf:      	movq	%rbx, 0x48(%rsp)
    bbe4:      	cmpl	%r15d, %r12d
    bbe7:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    bbed:      	movq	0x8(%rsp), %r12
    bbf2:      	movq	%r12, 0x30(%rsp)
    bbf7:      	movq	0x38(%rsp), %rdx
    bbfc:      	movq	0x40(%rsp), %r15
    bc01:      	jmp	0xbc54 <generic_fentry_path+0x1794>
    bc03:      	leaq	0x10(%r15), %rdx
    bc07:      	movl	$0x4, %eax
    bc0c:      	movq	%rbp, %rdi
    bc0f:      	movl	$0x8, %esi
    bc14:      	callq	*%rax
    bc16:      	movq	0x40(%rsp), %rax
    bc1b:      	cmpq	(%rsp), %rax
    bc1f:      	je	0x15f2d <generic_fentry_path+0xba6d>
    bc25:      	addq	$0x18, %r15
    bc29:      	movl	$0x4, %eax
    bc2e:      	leaq	0x30(%rsp), %rdi
    bc33:      	movl	$0x8, %esi
    bc38:      	movq	%r15, %rdx
    bc3b:      	callq	*%rax
    bc3d:      	movq	(%rsp), %r15
    bc41:      	movq	%r15, 0x40(%rsp)
    bc46:      	leaq	0x20(%r15), %rdx
    bc4a:      	movq	%rdx, 0x38(%rsp)
    bc4f:      	movq	0x30(%rsp), %r12
    bc54:      	cmpq	0x18(%rsp), %r12
    bc59:      	jne	0xbc66 <generic_fentry_path+0x17a6>
    bc5b:      	cmpq	0x20(%rsp), %rdx
    bc60:      	je	0x15f2d <generic_fentry_path+0xba6d>
    bc66:      	movl	$0x4, %eax
    bc6b:      	leaq	0x10(%rsp), %rdi
    bc70:      	movl	$0x8, %esi
    bc75:      	callq	*%rax
    bc77:      	cmpq	0x10(%rsp), %r12
    bc7c:      	je	0xbd74 <generic_fentry_path+0x18b4>
    bc82:      	leaq	0x18(%r12), %rbx
    bc87:      	movl	$0x4, %eax
    bc8c:      	movq	%rbp, %rdi
    bc8f:      	movl	$0x8, %esi
    bc94:      	movq	%rbx, %rdx
    bc97:      	callq	*%rax
    bc99:      	cmpq	%r12, (%rsp)
    bc9d:      	je	0xbd74 <generic_fentry_path+0x18b4>
    bca3:      	movl	$0x4, %eax
    bca8:      	leaq	0x8(%rsp), %rdi
    bcad:      	movl	$0x8, %esi
    bcb2:      	movq	%rbx, %rdx
    bcb5:      	callq	*%rax
    bcb7:      	addq	$0x20, %r12
    bcbb:      	movl	$0x4, %eax
    bcc0:      	leaq	0x58(%rsp), %rdi
    bcc5:      	movl	$0x10, %ecx
    bcca:      	movl	$0x10, %esi
    bccf:      	movq	%r12, %rdx
    bcd2:      	callq	*%rax
    bcd4:      	movq	0x28(%rsp), %rbx
    bcd9:      	movq	0x48(%rsp), %rax
    bcde:      	movl	0x5c(%rsp), %r15d
    bce3:      	subq	%rbx, %rax
    bce6:      	movl	0x50(%rsp), %r12d
    bceb:      	movl	%r15d, %edx
    bcee:      	subl	%r12d, %edx
    bcf1:      	movl	$0x0, %ecx
    bcf6:      	cmovbl	%ecx, %edx
    bcf9:      	addq	0x60(%rsp), %rdx
    bcfe:      	xorl	%esi, %esi
    bd00:      	cmpl	%r15d, %r12d
    bd03:      	seta	%sil
    bd07:      	movl	%r15d, %ecx
    bd0a:      	cmovbl	%r12d, %ecx
    bd0e:      	addl	%ecx, %esi
    bd10:      	movl	%r12d, %edi
    bd13:      	subl	%esi, %edi
    bd15:      	movl	%edi, 0x50(%rsp)
    bd19:      	subq	%rsi, %rax
    bd1c:      	jb	0x15f32 <generic_fentry_path+0xba72>
    bd22:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    bd28:      	ja	0x15f32 <generic_fentry_path+0xba72>
    bd2e:      	cmpl	%r15d, %r12d
    bd31:      	jbe	0xbd37 <generic_fentry_path+0x1877>
    bd33:      	movb	$0x2f, (%rbx,%rax)
    bd37:      	xorl	%edi, %edi
    bd39:      	cmpl	%r15d, %r12d
    bd3c:      	seta	%dil
    bd40:      	movzbl	%cl, %esi
    bd43:      	addq	%rax, %rbx
    bd46:      	addq	%rbx, %rdi
    bd49:      	movl	$0x4, %eax
    bd4e:      	callq	*%rax
    bd50:      	movq	%rbx, 0x48(%rsp)
    bd55:      	cmpl	%r15d, %r12d
    bd58:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    bd5e:      	movq	0x8(%rsp), %r12
    bd63:      	movq	%r12, 0x30(%rsp)
    bd68:      	movq	0x38(%rsp), %rdx
    bd6d:      	movq	0x40(%rsp), %r15
    bd72:      	jmp	0xbdc5 <generic_fentry_path+0x1905>
    bd74:      	leaq	0x10(%r15), %rdx
    bd78:      	movl	$0x4, %eax
    bd7d:      	movq	%rbp, %rdi
    bd80:      	movl	$0x8, %esi
    bd85:      	callq	*%rax
    bd87:      	movq	0x40(%rsp), %rax
    bd8c:      	cmpq	(%rsp), %rax
    bd90:      	je	0x15f2d <generic_fentry_path+0xba6d>
    bd96:      	addq	$0x18, %r15
    bd9a:      	movl	$0x4, %eax
    bd9f:      	leaq	0x30(%rsp), %rdi
    bda4:      	movl	$0x8, %esi
    bda9:      	movq	%r15, %rdx
    bdac:      	callq	*%rax
    bdae:      	movq	(%rsp), %r15
    bdb2:      	movq	%r15, 0x40(%rsp)
    bdb7:      	leaq	0x20(%r15), %rdx
    bdbb:      	movq	%rdx, 0x38(%rsp)
    bdc0:      	movq	0x30(%rsp), %r12
    bdc5:      	cmpq	0x18(%rsp), %r12
    bdca:      	jne	0xbdd7 <generic_fentry_path+0x1917>
    bdcc:      	cmpq	0x20(%rsp), %rdx
    bdd1:      	je	0x15f2d <generic_fentry_path+0xba6d>
    bdd7:      	movl	$0x4, %eax
    bddc:      	leaq	0x10(%rsp), %rdi
    bde1:      	movl	$0x8, %esi
    bde6:      	callq	*%rax
    bde8:      	cmpq	0x10(%rsp), %r12
    bded:      	je	0xbee5 <generic_fentry_path+0x1a25>
    bdf3:      	leaq	0x18(%r12), %rbx
    bdf8:      	movl	$0x4, %eax
    bdfd:      	movq	%rbp, %rdi
    be00:      	movl	$0x8, %esi
    be05:      	movq	%rbx, %rdx
    be08:      	callq	*%rax
    be0a:      	cmpq	%r12, (%rsp)
    be0e:      	je	0xbee5 <generic_fentry_path+0x1a25>
    be14:      	movl	$0x4, %eax
    be19:      	leaq	0x8(%rsp), %rdi
    be1e:      	movl	$0x8, %esi
    be23:      	movq	%rbx, %rdx
    be26:      	callq	*%rax
    be28:      	addq	$0x20, %r12
    be2c:      	movl	$0x4, %eax
    be31:      	leaq	0x58(%rsp), %rdi
    be36:      	movl	$0x10, %ecx
    be3b:      	movl	$0x10, %esi
    be40:      	movq	%r12, %rdx
    be43:      	callq	*%rax
    be45:      	movq	0x28(%rsp), %rbx
    be4a:      	movq	0x48(%rsp), %rax
    be4f:      	movl	0x5c(%rsp), %r15d
    be54:      	subq	%rbx, %rax
    be57:      	movl	0x50(%rsp), %r12d
    be5c:      	movl	%r15d, %edx
    be5f:      	subl	%r12d, %edx
    be62:      	movl	$0x0, %ecx
    be67:      	cmovbl	%ecx, %edx
    be6a:      	addq	0x60(%rsp), %rdx
    be6f:      	xorl	%esi, %esi
    be71:      	cmpl	%r15d, %r12d
    be74:      	seta	%sil
    be78:      	movl	%r15d, %ecx
    be7b:      	cmovbl	%r12d, %ecx
    be7f:      	addl	%ecx, %esi
    be81:      	movl	%r12d, %edi
    be84:      	subl	%esi, %edi
    be86:      	movl	%edi, 0x50(%rsp)
    be8a:      	subq	%rsi, %rax
    be8d:      	jb	0x15f32 <generic_fentry_path+0xba72>
    be93:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    be99:      	ja	0x15f32 <generic_fentry_path+0xba72>
    be9f:      	cmpl	%r15d, %r12d
    bea2:      	jbe	0xbea8 <generic_fentry_path+0x19e8>
    bea4:      	movb	$0x2f, (%rbx,%rax)
    bea8:      	xorl	%edi, %edi
    beaa:      	cmpl	%r15d, %r12d
    bead:      	seta	%dil
    beb1:      	movzbl	%cl, %esi
    beb4:      	addq	%rax, %rbx
    beb7:      	addq	%rbx, %rdi
    beba:      	movl	$0x4, %eax
    bebf:      	callq	*%rax
    bec1:      	movq	%rbx, 0x48(%rsp)
    bec6:      	cmpl	%r15d, %r12d
    bec9:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    becf:      	movq	0x8(%rsp), %r12
    bed4:      	movq	%r12, 0x30(%rsp)
    bed9:      	movq	0x38(%rsp), %rdx
    bede:      	movq	0x40(%rsp), %r15
    bee3:      	jmp	0xbf36 <generic_fentry_path+0x1a76>
    bee5:      	leaq	0x10(%r15), %rdx
    bee9:      	movl	$0x4, %eax
    beee:      	movq	%rbp, %rdi
    bef1:      	movl	$0x8, %esi
    bef6:      	callq	*%rax
    bef8:      	movq	0x40(%rsp), %rax
    befd:      	cmpq	(%rsp), %rax
    bf01:      	je	0x15f2d <generic_fentry_path+0xba6d>
    bf07:      	addq	$0x18, %r15
    bf0b:      	movl	$0x4, %eax
    bf10:      	leaq	0x30(%rsp), %rdi
    bf15:      	movl	$0x8, %esi
    bf1a:      	movq	%r15, %rdx
    bf1d:      	callq	*%rax
    bf1f:      	movq	(%rsp), %r15
    bf23:      	movq	%r15, 0x40(%rsp)
    bf28:      	leaq	0x20(%r15), %rdx
    bf2c:      	movq	%rdx, 0x38(%rsp)
    bf31:      	movq	0x30(%rsp), %r12
    bf36:      	cmpq	0x18(%rsp), %r12
    bf3b:      	jne	0xbf48 <generic_fentry_path+0x1a88>
    bf3d:      	cmpq	0x20(%rsp), %rdx
    bf42:      	je	0x15f2d <generic_fentry_path+0xba6d>
    bf48:      	movl	$0x4, %eax
    bf4d:      	leaq	0x10(%rsp), %rdi
    bf52:      	movl	$0x8, %esi
    bf57:      	callq	*%rax
    bf59:      	cmpq	0x10(%rsp), %r12
    bf5e:      	je	0xc056 <generic_fentry_path+0x1b96>
    bf64:      	leaq	0x18(%r12), %rbx
    bf69:      	movl	$0x4, %eax
    bf6e:      	movq	%rbp, %rdi
    bf71:      	movl	$0x8, %esi
    bf76:      	movq	%rbx, %rdx
    bf79:      	callq	*%rax
    bf7b:      	cmpq	%r12, (%rsp)
    bf7f:      	je	0xc056 <generic_fentry_path+0x1b96>
    bf85:      	movl	$0x4, %eax
    bf8a:      	leaq	0x8(%rsp), %rdi
    bf8f:      	movl	$0x8, %esi
    bf94:      	movq	%rbx, %rdx
    bf97:      	callq	*%rax
    bf99:      	addq	$0x20, %r12
    bf9d:      	movl	$0x4, %eax
    bfa2:      	leaq	0x58(%rsp), %rdi
    bfa7:      	movl	$0x10, %ecx
    bfac:      	movl	$0x10, %esi
    bfb1:      	movq	%r12, %rdx
    bfb4:      	callq	*%rax
    bfb6:      	movq	0x28(%rsp), %rbx
    bfbb:      	movq	0x48(%rsp), %rax
    bfc0:      	movl	0x5c(%rsp), %r15d
    bfc5:      	subq	%rbx, %rax
    bfc8:      	movl	0x50(%rsp), %r12d
    bfcd:      	movl	%r15d, %edx
    bfd0:      	subl	%r12d, %edx
    bfd3:      	movl	$0x0, %ecx
    bfd8:      	cmovbl	%ecx, %edx
    bfdb:      	addq	0x60(%rsp), %rdx
    bfe0:      	xorl	%esi, %esi
    bfe2:      	cmpl	%r15d, %r12d
    bfe5:      	seta	%sil
    bfe9:      	movl	%r15d, %ecx
    bfec:      	cmovbl	%r12d, %ecx
    bff0:      	addl	%ecx, %esi
    bff2:      	movl	%r12d, %edi
    bff5:      	subl	%esi, %edi
    bff7:      	movl	%edi, 0x50(%rsp)
    bffb:      	subq	%rsi, %rax
    bffe:      	jb	0x15f32 <generic_fentry_path+0xba72>
    c004:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c00a:      	ja	0x15f32 <generic_fentry_path+0xba72>
    c010:      	cmpl	%r15d, %r12d
    c013:      	jbe	0xc019 <generic_fentry_path+0x1b59>
    c015:      	movb	$0x2f, (%rbx,%rax)
    c019:      	xorl	%edi, %edi
    c01b:      	cmpl	%r15d, %r12d
    c01e:      	seta	%dil
    c022:      	movzbl	%cl, %esi
    c025:      	addq	%rax, %rbx
    c028:      	addq	%rbx, %rdi
    c02b:      	movl	$0x4, %eax
    c030:      	callq	*%rax
    c032:      	movq	%rbx, 0x48(%rsp)
    c037:      	cmpl	%r15d, %r12d
    c03a:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    c040:      	movq	0x8(%rsp), %r12
    c045:      	movq	%r12, 0x30(%rsp)
    c04a:      	movq	0x38(%rsp), %rdx
    c04f:      	movq	0x40(%rsp), %r15
    c054:      	jmp	0xc0a7 <generic_fentry_path+0x1be7>
    c056:      	leaq	0x10(%r15), %rdx
    c05a:      	movl	$0x4, %eax
    c05f:      	movq	%rbp, %rdi
    c062:      	movl	$0x8, %esi
    c067:      	callq	*%rax
    c069:      	movq	0x40(%rsp), %rax
    c06e:      	cmpq	(%rsp), %rax
    c072:      	je	0x15f2d <generic_fentry_path+0xba6d>
    c078:      	addq	$0x18, %r15
    c07c:      	movl	$0x4, %eax
    c081:      	leaq	0x30(%rsp), %rdi
    c086:      	movl	$0x8, %esi
    c08b:      	movq	%r15, %rdx
    c08e:      	callq	*%rax
    c090:      	movq	(%rsp), %r15
    c094:      	movq	%r15, 0x40(%rsp)
    c099:      	leaq	0x20(%r15), %rdx
    c09d:      	movq	%rdx, 0x38(%rsp)
    c0a2:      	movq	0x30(%rsp), %r12
    c0a7:      	cmpq	0x18(%rsp), %r12
    c0ac:      	jne	0xc0b9 <generic_fentry_path+0x1bf9>
    c0ae:      	cmpq	0x20(%rsp), %rdx
    c0b3:      	je	0x15f2d <generic_fentry_path+0xba6d>
    c0b9:      	movl	$0x4, %eax
    c0be:      	leaq	0x10(%rsp), %rdi
    c0c3:      	movl	$0x8, %esi
    c0c8:      	callq	*%rax
    c0ca:      	cmpq	0x10(%rsp), %r12
    c0cf:      	je	0xc1c7 <generic_fentry_path+0x1d07>
    c0d5:      	leaq	0x18(%r12), %rbx
    c0da:      	movl	$0x4, %eax
    c0df:      	movq	%rbp, %rdi
    c0e2:      	movl	$0x8, %esi
    c0e7:      	movq	%rbx, %rdx
    c0ea:      	callq	*%rax
    c0ec:      	cmpq	%r12, (%rsp)
    c0f0:      	je	0xc1c7 <generic_fentry_path+0x1d07>
    c0f6:      	movl	$0x4, %eax
    c0fb:      	leaq	0x8(%rsp), %rdi
    c100:      	movl	$0x8, %esi
    c105:      	movq	%rbx, %rdx
    c108:      	callq	*%rax
    c10a:      	addq	$0x20, %r12
    c10e:      	movl	$0x4, %eax
    c113:      	leaq	0x58(%rsp), %rdi
    c118:      	movl	$0x10, %ecx
    c11d:      	movl	$0x10, %esi
    c122:      	movq	%r12, %rdx
    c125:      	callq	*%rax
    c127:      	movq	0x28(%rsp), %rbx
    c12c:      	movq	0x48(%rsp), %rax
    c131:      	movl	0x5c(%rsp), %r15d
    c136:      	subq	%rbx, %rax
    c139:      	movl	0x50(%rsp), %r12d
    c13e:      	movl	%r15d, %edx
    c141:      	subl	%r12d, %edx
    c144:      	movl	$0x0, %ecx
    c149:      	cmovbl	%ecx, %edx
    c14c:      	addq	0x60(%rsp), %rdx
    c151:      	xorl	%esi, %esi
    c153:      	cmpl	%r15d, %r12d
    c156:      	seta	%sil
    c15a:      	movl	%r15d, %ecx
    c15d:      	cmovbl	%r12d, %ecx
    c161:      	addl	%ecx, %esi
    c163:      	movl	%r12d, %edi
    c166:      	subl	%esi, %edi
    c168:      	movl	%edi, 0x50(%rsp)
    c16c:      	subq	%rsi, %rax
    c16f:      	jb	0x15f32 <generic_fentry_path+0xba72>
    c175:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c17b:      	ja	0x15f32 <generic_fentry_path+0xba72>
    c181:      	cmpl	%r15d, %r12d
    c184:      	jbe	0xc18a <generic_fentry_path+0x1cca>
    c186:      	movb	$0x2f, (%rbx,%rax)
    c18a:      	xorl	%edi, %edi
    c18c:      	cmpl	%r15d, %r12d
    c18f:      	seta	%dil
    c193:      	movzbl	%cl, %esi
    c196:      	addq	%rax, %rbx
    c199:      	addq	%rbx, %rdi
    c19c:      	movl	$0x4, %eax
    c1a1:      	callq	*%rax
    c1a3:      	movq	%rbx, 0x48(%rsp)
    c1a8:      	cmpl	%r15d, %r12d
    c1ab:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    c1b1:      	movq	0x8(%rsp), %r12
    c1b6:      	movq	%r12, 0x30(%rsp)
    c1bb:      	movq	0x38(%rsp), %rdx
    c1c0:      	movq	0x40(%rsp), %r15
    c1c5:      	jmp	0xc218 <generic_fentry_path+0x1d58>
    c1c7:      	leaq	0x10(%r15), %rdx
    c1cb:      	movl	$0x4, %eax
    c1d0:      	movq	%rbp, %rdi
    c1d3:      	movl	$0x8, %esi
    c1d8:      	callq	*%rax
    c1da:      	movq	0x40(%rsp), %rax
    c1df:      	cmpq	(%rsp), %rax
    c1e3:      	je	0x15f2d <generic_fentry_path+0xba6d>
    c1e9:      	addq	$0x18, %r15
    c1ed:      	movl	$0x4, %eax
    c1f2:      	leaq	0x30(%rsp), %rdi
    c1f7:      	movl	$0x8, %esi
    c1fc:      	movq	%r15, %rdx
    c1ff:      	callq	*%rax
    c201:      	movq	(%rsp), %r15
    c205:      	movq	%r15, 0x40(%rsp)
    c20a:      	leaq	0x20(%r15), %rdx
    c20e:      	movq	%rdx, 0x38(%rsp)
    c213:      	movq	0x30(%rsp), %r12
    c218:      	cmpq	0x18(%rsp), %r12
    c21d:      	jne	0xc22a <generic_fentry_path+0x1d6a>
    c21f:      	cmpq	0x20(%rsp), %rdx
    c224:      	je	0x15f2d <generic_fentry_path+0xba6d>
    c22a:      	movl	$0x4, %eax
    c22f:      	leaq	0x10(%rsp), %rdi
    c234:      	movl	$0x8, %esi
    c239:      	callq	*%rax
    c23b:      	cmpq	0x10(%rsp), %r12
    c240:      	je	0xc338 <generic_fentry_path+0x1e78>
    c246:      	leaq	0x18(%r12), %rbx
    c24b:      	movl	$0x4, %eax
    c250:      	movq	%rbp, %rdi
    c253:      	movl	$0x8, %esi
    c258:      	movq	%rbx, %rdx
    c25b:      	callq	*%rax
    c25d:      	cmpq	%r12, (%rsp)
    c261:      	je	0xc338 <generic_fentry_path+0x1e78>
    c267:      	movl	$0x4, %eax
    c26c:      	leaq	0x8(%rsp), %rdi
    c271:      	movl	$0x8, %esi
    c276:      	movq	%rbx, %rdx
    c279:      	callq	*%rax
    c27b:      	addq	$0x20, %r12
    c27f:      	movl	$0x4, %eax
    c284:      	leaq	0x58(%rsp), %rdi
    c289:      	movl	$0x10, %ecx
    c28e:      	movl	$0x10, %esi
    c293:      	movq	%r12, %rdx
    c296:      	callq	*%rax
    c298:      	movq	0x28(%rsp), %rbx
    c29d:      	movq	0x48(%rsp), %rax
    c2a2:      	movl	0x5c(%rsp), %r15d
    c2a7:      	subq	%rbx, %rax
    c2aa:      	movl	0x50(%rsp), %r12d
    c2af:      	movl	%r15d, %edx
    c2b2:      	subl	%r12d, %edx
    c2b5:      	movl	$0x0, %ecx
    c2ba:      	cmovbl	%ecx, %edx
    c2bd:      	addq	0x60(%rsp), %rdx
    c2c2:      	xorl	%esi, %esi
    c2c4:      	cmpl	%r15d, %r12d
    c2c7:      	seta	%sil
    c2cb:      	movl	%r15d, %ecx
    c2ce:      	cmovbl	%r12d, %ecx
    c2d2:      	addl	%ecx, %esi
    c2d4:      	movl	%r12d, %edi
    c2d7:      	subl	%esi, %edi
    c2d9:      	movl	%edi, 0x50(%rsp)
    c2dd:      	subq	%rsi, %rax
    c2e0:      	jb	0x15f32 <generic_fentry_path+0xba72>
    c2e6:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c2ec:      	ja	0x15f32 <generic_fentry_path+0xba72>
    c2f2:      	cmpl	%r15d, %r12d
    c2f5:      	jbe	0xc2fb <generic_fentry_path+0x1e3b>
    c2f7:      	movb	$0x2f, (%rbx,%rax)
    c2fb:      	xorl	%edi, %edi
    c2fd:      	cmpl	%r15d, %r12d
    c300:      	seta	%dil
    c304:      	movzbl	%cl, %esi
    c307:      	addq	%rax, %rbx
    c30a:      	addq	%rbx, %rdi
    c30d:      	movl	$0x4, %eax
    c312:      	callq	*%rax
    c314:      	movq	%rbx, 0x48(%rsp)
    c319:      	cmpl	%r15d, %r12d
    c31c:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    c322:      	movq	0x8(%rsp), %r12
    c327:      	movq	%r12, 0x30(%rsp)
    c32c:      	movq	0x38(%rsp), %rdx
    c331:      	movq	0x40(%rsp), %r15
    c336:      	jmp	0xc389 <generic_fentry_path+0x1ec9>
    c338:      	leaq	0x10(%r15), %rdx
    c33c:      	movl	$0x4, %eax
    c341:      	movq	%rbp, %rdi
    c344:      	movl	$0x8, %esi
    c349:      	callq	*%rax
    c34b:      	movq	0x40(%rsp), %rax
    c350:      	cmpq	(%rsp), %rax
    c354:      	je	0x15f2d <generic_fentry_path+0xba6d>
    c35a:      	addq	$0x18, %r15
    c35e:      	movl	$0x4, %eax
    c363:      	leaq	0x30(%rsp), %rdi
    c368:      	movl	$0x8, %esi
    c36d:      	movq	%r15, %rdx
    c370:      	callq	*%rax
    c372:      	movq	(%rsp), %r15
    c376:      	movq	%r15, 0x40(%rsp)
    c37b:      	leaq	0x20(%r15), %rdx
    c37f:      	movq	%rdx, 0x38(%rsp)
    c384:      	movq	0x30(%rsp), %r12
    c389:      	cmpq	0x18(%rsp), %r12
    c38e:      	jne	0xc39b <generic_fentry_path+0x1edb>
    c390:      	cmpq	0x20(%rsp), %rdx
    c395:      	je	0x15f2d <generic_fentry_path+0xba6d>
    c39b:      	movl	$0x4, %eax
    c3a0:      	leaq	0x10(%rsp), %rdi
    c3a5:      	movl	$0x8, %esi
    c3aa:      	callq	*%rax
    c3ac:      	cmpq	0x10(%rsp), %r12
    c3b1:      	je	0xc4a9 <generic_fentry_path+0x1fe9>
    c3b7:      	leaq	0x18(%r12), %rbx
    c3bc:      	movl	$0x4, %eax
    c3c1:      	movq	%rbp, %rdi
    c3c4:      	movl	$0x8, %esi
    c3c9:      	movq	%rbx, %rdx
    c3cc:      	callq	*%rax
    c3ce:      	cmpq	%r12, (%rsp)
    c3d2:      	je	0xc4a9 <generic_fentry_path+0x1fe9>
    c3d8:      	movl	$0x4, %eax
    c3dd:      	leaq	0x8(%rsp), %rdi
    c3e2:      	movl	$0x8, %esi
    c3e7:      	movq	%rbx, %rdx
    c3ea:      	callq	*%rax
    c3ec:      	addq	$0x20, %r12
    c3f0:      	movl	$0x4, %eax
    c3f5:      	leaq	0x58(%rsp), %rdi
    c3fa:      	movl	$0x10, %ecx
    c3ff:      	movl	$0x10, %esi
    c404:      	movq	%r12, %rdx
    c407:      	callq	*%rax
    c409:      	movq	0x28(%rsp), %rbx
    c40e:      	movq	0x48(%rsp), %rax
    c413:      	movl	0x5c(%rsp), %r15d
    c418:      	subq	%rbx, %rax
    c41b:      	movl	0x50(%rsp), %r12d
    c420:      	movl	%r15d, %edx
    c423:      	subl	%r12d, %edx
    c426:      	movl	$0x0, %ecx
    c42b:      	cmovbl	%ecx, %edx
    c42e:      	addq	0x60(%rsp), %rdx
    c433:      	xorl	%esi, %esi
    c435:      	cmpl	%r15d, %r12d
    c438:      	seta	%sil
    c43c:      	movl	%r15d, %ecx
    c43f:      	cmovbl	%r12d, %ecx
    c443:      	addl	%ecx, %esi
    c445:      	movl	%r12d, %edi
    c448:      	subl	%esi, %edi
    c44a:      	movl	%edi, 0x50(%rsp)
    c44e:      	subq	%rsi, %rax
    c451:      	jb	0x15f32 <generic_fentry_path+0xba72>
    c457:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c45d:      	ja	0x15f32 <generic_fentry_path+0xba72>
    c463:      	cmpl	%r15d, %r12d
    c466:      	jbe	0xc46c <generic_fentry_path+0x1fac>
    c468:      	movb	$0x2f, (%rbx,%rax)
    c46c:      	xorl	%edi, %edi
    c46e:      	cmpl	%r15d, %r12d
    c471:      	seta	%dil
    c475:      	movzbl	%cl, %esi
    c478:      	addq	%rax, %rbx
    c47b:      	addq	%rbx, %rdi
    c47e:      	movl	$0x4, %eax
    c483:      	callq	*%rax
    c485:      	movq	%rbx, 0x48(%rsp)
    c48a:      	cmpl	%r15d, %r12d
    c48d:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    c493:      	movq	0x8(%rsp), %r12
    c498:      	movq	%r12, 0x30(%rsp)
    c49d:      	movq	0x38(%rsp), %rdx
    c4a2:      	movq	0x40(%rsp), %r15
    c4a7:      	jmp	0xc4fa <generic_fentry_path+0x203a>
    c4a9:      	leaq	0x10(%r15), %rdx
    c4ad:      	movl	$0x4, %eax
    c4b2:      	movq	%rbp, %rdi
    c4b5:      	movl	$0x8, %esi
    c4ba:      	callq	*%rax
    c4bc:      	movq	0x40(%rsp), %rax
    c4c1:      	cmpq	(%rsp), %rax
    c4c5:      	je	0x15f2d <generic_fentry_path+0xba6d>
    c4cb:      	addq	$0x18, %r15
    c4cf:      	movl	$0x4, %eax
    c4d4:      	leaq	0x30(%rsp), %rdi
    c4d9:      	movl	$0x8, %esi
    c4de:      	movq	%r15, %rdx
    c4e1:      	callq	*%rax
    c4e3:      	movq	(%rsp), %r15
    c4e7:      	movq	%r15, 0x40(%rsp)
    c4ec:      	leaq	0x20(%r15), %rdx
    c4f0:      	movq	%rdx, 0x38(%rsp)
    c4f5:      	movq	0x30(%rsp), %r12
    c4fa:      	cmpq	0x18(%rsp), %r12
    c4ff:      	jne	0xc50c <generic_fentry_path+0x204c>
    c501:      	cmpq	0x20(%rsp), %rdx
    c506:      	je	0x15f2d <generic_fentry_path+0xba6d>
    c50c:      	movl	$0x4, %eax
    c511:      	leaq	0x10(%rsp), %rdi
    c516:      	movl	$0x8, %esi
    c51b:      	callq	*%rax
    c51d:      	cmpq	0x10(%rsp), %r12
    c522:      	je	0xc61a <generic_fentry_path+0x215a>
    c528:      	leaq	0x18(%r12), %rbx
    c52d:      	movl	$0x4, %eax
    c532:      	movq	%rbp, %rdi
    c535:      	movl	$0x8, %esi
    c53a:      	movq	%rbx, %rdx
    c53d:      	callq	*%rax
    c53f:      	cmpq	%r12, (%rsp)
    c543:      	je	0xc61a <generic_fentry_path+0x215a>
    c549:      	movl	$0x4, %eax
    c54e:      	leaq	0x8(%rsp), %rdi
    c553:      	movl	$0x8, %esi
    c558:      	movq	%rbx, %rdx
    c55b:      	callq	*%rax
    c55d:      	addq	$0x20, %r12
    c561:      	movl	$0x4, %eax
    c566:      	leaq	0x58(%rsp), %rdi
    c56b:      	movl	$0x10, %ecx
    c570:      	movl	$0x10, %esi
    c575:      	movq	%r12, %rdx
    c578:      	callq	*%rax
    c57a:      	movq	0x28(%rsp), %rbx
    c57f:      	movq	0x48(%rsp), %rax
    c584:      	movl	0x5c(%rsp), %r15d
    c589:      	subq	%rbx, %rax
    c58c:      	movl	0x50(%rsp), %r12d
    c591:      	movl	%r15d, %edx
    c594:      	subl	%r12d, %edx
    c597:      	movl	$0x0, %ecx
    c59c:      	cmovbl	%ecx, %edx
    c59f:      	addq	0x60(%rsp), %rdx
    c5a4:      	xorl	%esi, %esi
    c5a6:      	cmpl	%r15d, %r12d
    c5a9:      	seta	%sil
    c5ad:      	movl	%r15d, %ecx
    c5b0:      	cmovbl	%r12d, %ecx
    c5b4:      	addl	%ecx, %esi
    c5b6:      	movl	%r12d, %edi
    c5b9:      	subl	%esi, %edi
    c5bb:      	movl	%edi, 0x50(%rsp)
    c5bf:      	subq	%rsi, %rax
    c5c2:      	jb	0x15f32 <generic_fentry_path+0xba72>
    c5c8:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c5ce:      	ja	0x15f32 <generic_fentry_path+0xba72>
    c5d4:      	cmpl	%r15d, %r12d
    c5d7:      	jbe	0xc5dd <generic_fentry_path+0x211d>
    c5d9:      	movb	$0x2f, (%rbx,%rax)
    c5dd:      	xorl	%edi, %edi
    c5df:      	cmpl	%r15d, %r12d
    c5e2:      	seta	%dil
    c5e6:      	movzbl	%cl, %esi
    c5e9:      	addq	%rax, %rbx
    c5ec:      	addq	%rbx, %rdi
    c5ef:      	movl	$0x4, %eax
    c5f4:      	callq	*%rax
    c5f6:      	movq	%rbx, 0x48(%rsp)
    c5fb:      	cmpl	%r15d, %r12d
    c5fe:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    c604:      	movq	0x8(%rsp), %r12
    c609:      	movq	%r12, 0x30(%rsp)
    c60e:      	movq	0x38(%rsp), %rdx
    c613:      	movq	0x40(%rsp), %r15
    c618:      	jmp	0xc66b <generic_fentry_path+0x21ab>
    c61a:      	leaq	0x10(%r15), %rdx
    c61e:      	movl	$0x4, %eax
    c623:      	movq	%rbp, %rdi
    c626:      	movl	$0x8, %esi
    c62b:      	callq	*%rax
    c62d:      	movq	0x40(%rsp), %rax
    c632:      	cmpq	(%rsp), %rax
    c636:      	je	0x15f2d <generic_fentry_path+0xba6d>
    c63c:      	addq	$0x18, %r15
    c640:      	movl	$0x4, %eax
    c645:      	leaq	0x30(%rsp), %rdi
    c64a:      	movl	$0x8, %esi
    c64f:      	movq	%r15, %rdx
    c652:      	callq	*%rax
    c654:      	movq	(%rsp), %r15
    c658:      	movq	%r15, 0x40(%rsp)
    c65d:      	leaq	0x20(%r15), %rdx
    c661:      	movq	%rdx, 0x38(%rsp)
    c666:      	movq	0x30(%rsp), %r12
    c66b:      	cmpq	0x18(%rsp), %r12
    c670:      	jne	0xc67d <generic_fentry_path+0x21bd>
    c672:      	cmpq	0x20(%rsp), %rdx
    c677:      	je	0x15f2d <generic_fentry_path+0xba6d>
    c67d:      	movl	$0x4, %eax
    c682:      	leaq	0x10(%rsp), %rdi
    c687:      	movl	$0x8, %esi
    c68c:      	callq	*%rax
    c68e:      	cmpq	0x10(%rsp), %r12
    c693:      	je	0xc78b <generic_fentry_path+0x22cb>
    c699:      	leaq	0x18(%r12), %rbx
    c69e:      	movl	$0x4, %eax
    c6a3:      	movq	%rbp, %rdi
    c6a6:      	movl	$0x8, %esi
    c6ab:      	movq	%rbx, %rdx
    c6ae:      	callq	*%rax
    c6b0:      	cmpq	%r12, (%rsp)
    c6b4:      	je	0xc78b <generic_fentry_path+0x22cb>
    c6ba:      	movl	$0x4, %eax
    c6bf:      	leaq	0x8(%rsp), %rdi
    c6c4:      	movl	$0x8, %esi
    c6c9:      	movq	%rbx, %rdx
    c6cc:      	callq	*%rax
    c6ce:      	addq	$0x20, %r12
    c6d2:      	movl	$0x4, %eax
    c6d7:      	leaq	0x58(%rsp), %rdi
    c6dc:      	movl	$0x10, %ecx
    c6e1:      	movl	$0x10, %esi
    c6e6:      	movq	%r12, %rdx
    c6e9:      	callq	*%rax
    c6eb:      	movq	0x28(%rsp), %rbx
    c6f0:      	movq	0x48(%rsp), %rax
    c6f5:      	movl	0x5c(%rsp), %r15d
    c6fa:      	subq	%rbx, %rax
    c6fd:      	movl	0x50(%rsp), %r12d
    c702:      	movl	%r15d, %edx
    c705:      	subl	%r12d, %edx
    c708:      	movl	$0x0, %ecx
    c70d:      	cmovbl	%ecx, %edx
    c710:      	addq	0x60(%rsp), %rdx
    c715:      	xorl	%esi, %esi
    c717:      	cmpl	%r15d, %r12d
    c71a:      	seta	%sil
    c71e:      	movl	%r15d, %ecx
    c721:      	cmovbl	%r12d, %ecx
    c725:      	addl	%ecx, %esi
    c727:      	movl	%r12d, %edi
    c72a:      	subl	%esi, %edi
    c72c:      	movl	%edi, 0x50(%rsp)
    c730:      	subq	%rsi, %rax
    c733:      	jb	0x15f32 <generic_fentry_path+0xba72>
    c739:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c73f:      	ja	0x15f32 <generic_fentry_path+0xba72>
    c745:      	cmpl	%r15d, %r12d
    c748:      	jbe	0xc74e <generic_fentry_path+0x228e>
    c74a:      	movb	$0x2f, (%rbx,%rax)
    c74e:      	xorl	%edi, %edi
    c750:      	cmpl	%r15d, %r12d
    c753:      	seta	%dil
    c757:      	movzbl	%cl, %esi
    c75a:      	addq	%rax, %rbx
    c75d:      	addq	%rbx, %rdi
    c760:      	movl	$0x4, %eax
    c765:      	callq	*%rax
    c767:      	movq	%rbx, 0x48(%rsp)
    c76c:      	cmpl	%r15d, %r12d
    c76f:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    c775:      	movq	0x8(%rsp), %r12
    c77a:      	movq	%r12, 0x30(%rsp)
    c77f:      	movq	0x38(%rsp), %rdx
    c784:      	movq	0x40(%rsp), %r15
    c789:      	jmp	0xc7dc <generic_fentry_path+0x231c>
    c78b:      	leaq	0x10(%r15), %rdx
    c78f:      	movl	$0x4, %eax
    c794:      	movq	%rbp, %rdi
    c797:      	movl	$0x8, %esi
    c79c:      	callq	*%rax
    c79e:      	movq	0x40(%rsp), %rax
    c7a3:      	cmpq	(%rsp), %rax
    c7a7:      	je	0x15f2d <generic_fentry_path+0xba6d>
    c7ad:      	addq	$0x18, %r15
    c7b1:      	movl	$0x4, %eax
    c7b6:      	leaq	0x30(%rsp), %rdi
    c7bb:      	movl	$0x8, %esi
    c7c0:      	movq	%r15, %rdx
    c7c3:      	callq	*%rax
    c7c5:      	movq	(%rsp), %r15
    c7c9:      	movq	%r15, 0x40(%rsp)
    c7ce:      	leaq	0x20(%r15), %rdx
    c7d2:      	movq	%rdx, 0x38(%rsp)
    c7d7:      	movq	0x30(%rsp), %r12
    c7dc:      	cmpq	0x18(%rsp), %r12
    c7e1:      	jne	0xc7ee <generic_fentry_path+0x232e>
    c7e3:      	cmpq	0x20(%rsp), %rdx
    c7e8:      	je	0x15f2d <generic_fentry_path+0xba6d>
    c7ee:      	movl	$0x4, %eax
    c7f3:      	leaq	0x10(%rsp), %rdi
    c7f8:      	movl	$0x8, %esi
    c7fd:      	callq	*%rax
    c7ff:      	cmpq	0x10(%rsp), %r12
    c804:      	je	0xc8fc <generic_fentry_path+0x243c>
    c80a:      	leaq	0x18(%r12), %rbx
    c80f:      	movl	$0x4, %eax
    c814:      	movq	%rbp, %rdi
    c817:      	movl	$0x8, %esi
    c81c:      	movq	%rbx, %rdx
    c81f:      	callq	*%rax
    c821:      	cmpq	%r12, (%rsp)
    c825:      	je	0xc8fc <generic_fentry_path+0x243c>
    c82b:      	movl	$0x4, %eax
    c830:      	leaq	0x8(%rsp), %rdi
    c835:      	movl	$0x8, %esi
    c83a:      	movq	%rbx, %rdx
    c83d:      	callq	*%rax
    c83f:      	addq	$0x20, %r12
    c843:      	movl	$0x4, %eax
    c848:      	leaq	0x58(%rsp), %rdi
    c84d:      	movl	$0x10, %ecx
    c852:      	movl	$0x10, %esi
    c857:      	movq	%r12, %rdx
    c85a:      	callq	*%rax
    c85c:      	movq	0x28(%rsp), %rbx
    c861:      	movq	0x48(%rsp), %rax
    c866:      	movl	0x5c(%rsp), %r15d
    c86b:      	subq	%rbx, %rax
    c86e:      	movl	0x50(%rsp), %r12d
    c873:      	movl	%r15d, %edx
    c876:      	subl	%r12d, %edx
    c879:      	movl	$0x0, %ecx
    c87e:      	cmovbl	%ecx, %edx
    c881:      	addq	0x60(%rsp), %rdx
    c886:      	xorl	%esi, %esi
    c888:      	cmpl	%r15d, %r12d
    c88b:      	seta	%sil
    c88f:      	movl	%r15d, %ecx
    c892:      	cmovbl	%r12d, %ecx
    c896:      	addl	%ecx, %esi
    c898:      	movl	%r12d, %edi
    c89b:      	subl	%esi, %edi
    c89d:      	movl	%edi, 0x50(%rsp)
    c8a1:      	subq	%rsi, %rax
    c8a4:      	jb	0x15f32 <generic_fentry_path+0xba72>
    c8aa:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c8b0:      	ja	0x15f32 <generic_fentry_path+0xba72>
    c8b6:      	cmpl	%r15d, %r12d
    c8b9:      	jbe	0xc8bf <generic_fentry_path+0x23ff>
    c8bb:      	movb	$0x2f, (%rbx,%rax)
    c8bf:      	xorl	%edi, %edi
    c8c1:      	cmpl	%r15d, %r12d
    c8c4:      	seta	%dil
    c8c8:      	movzbl	%cl, %esi
    c8cb:      	addq	%rax, %rbx
    c8ce:      	addq	%rbx, %rdi
    c8d1:      	movl	$0x4, %eax
    c8d6:      	callq	*%rax
    c8d8:      	movq	%rbx, 0x48(%rsp)
    c8dd:      	cmpl	%r15d, %r12d
    c8e0:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    c8e6:      	movq	0x8(%rsp), %r12
    c8eb:      	movq	%r12, 0x30(%rsp)
    c8f0:      	movq	0x38(%rsp), %rdx
    c8f5:      	movq	0x40(%rsp), %r15
    c8fa:      	jmp	0xc94d <generic_fentry_path+0x248d>
    c8fc:      	leaq	0x10(%r15), %rdx
    c900:      	movl	$0x4, %eax
    c905:      	movq	%rbp, %rdi
    c908:      	movl	$0x8, %esi
    c90d:      	callq	*%rax
    c90f:      	movq	0x40(%rsp), %rax
    c914:      	cmpq	(%rsp), %rax
    c918:      	je	0x15f2d <generic_fentry_path+0xba6d>
    c91e:      	addq	$0x18, %r15
    c922:      	movl	$0x4, %eax
    c927:      	leaq	0x30(%rsp), %rdi
    c92c:      	movl	$0x8, %esi
    c931:      	movq	%r15, %rdx
    c934:      	callq	*%rax
    c936:      	movq	(%rsp), %r15
    c93a:      	movq	%r15, 0x40(%rsp)
    c93f:      	leaq	0x20(%r15), %rdx
    c943:      	movq	%rdx, 0x38(%rsp)
    c948:      	movq	0x30(%rsp), %r12
    c94d:      	cmpq	0x18(%rsp), %r12
    c952:      	jne	0xc95f <generic_fentry_path+0x249f>
    c954:      	cmpq	0x20(%rsp), %rdx
    c959:      	je	0x15f2d <generic_fentry_path+0xba6d>
    c95f:      	movl	$0x4, %eax
    c964:      	leaq	0x10(%rsp), %rdi
    c969:      	movl	$0x8, %esi
    c96e:      	callq	*%rax
    c970:      	cmpq	0x10(%rsp), %r12
    c975:      	je	0xca6d <generic_fentry_path+0x25ad>
    c97b:      	leaq	0x18(%r12), %rbx
    c980:      	movl	$0x4, %eax
    c985:      	movq	%rbp, %rdi
    c988:      	movl	$0x8, %esi
    c98d:      	movq	%rbx, %rdx
    c990:      	callq	*%rax
    c992:      	cmpq	%r12, (%rsp)
    c996:      	je	0xca6d <generic_fentry_path+0x25ad>
    c99c:      	movl	$0x4, %eax
    c9a1:      	leaq	0x8(%rsp), %rdi
    c9a6:      	movl	$0x8, %esi
    c9ab:      	movq	%rbx, %rdx
    c9ae:      	callq	*%rax
    c9b0:      	addq	$0x20, %r12
    c9b4:      	movl	$0x4, %eax
    c9b9:      	leaq	0x58(%rsp), %rdi
    c9be:      	movl	$0x10, %ecx
    c9c3:      	movl	$0x10, %esi
    c9c8:      	movq	%r12, %rdx
    c9cb:      	callq	*%rax
    c9cd:      	movq	0x28(%rsp), %rbx
    c9d2:      	movq	0x48(%rsp), %rax
    c9d7:      	movl	0x5c(%rsp), %r15d
    c9dc:      	subq	%rbx, %rax
    c9df:      	movl	0x50(%rsp), %r12d
    c9e4:      	movl	%r15d, %edx
    c9e7:      	subl	%r12d, %edx
    c9ea:      	movl	$0x0, %ecx
    c9ef:      	cmovbl	%ecx, %edx
    c9f2:      	addq	0x60(%rsp), %rdx
    c9f7:      	xorl	%esi, %esi
    c9f9:      	cmpl	%r15d, %r12d
    c9fc:      	seta	%sil
    ca00:      	movl	%r15d, %ecx
    ca03:      	cmovbl	%r12d, %ecx
    ca07:      	addl	%ecx, %esi
    ca09:      	movl	%r12d, %edi
    ca0c:      	subl	%esi, %edi
    ca0e:      	movl	%edi, 0x50(%rsp)
    ca12:      	subq	%rsi, %rax
    ca15:      	jb	0x15f32 <generic_fentry_path+0xba72>
    ca1b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ca21:      	ja	0x15f32 <generic_fentry_path+0xba72>
    ca27:      	cmpl	%r15d, %r12d
    ca2a:      	jbe	0xca30 <generic_fentry_path+0x2570>
    ca2c:      	movb	$0x2f, (%rbx,%rax)
    ca30:      	xorl	%edi, %edi
    ca32:      	cmpl	%r15d, %r12d
    ca35:      	seta	%dil
    ca39:      	movzbl	%cl, %esi
    ca3c:      	addq	%rax, %rbx
    ca3f:      	addq	%rbx, %rdi
    ca42:      	movl	$0x4, %eax
    ca47:      	callq	*%rax
    ca49:      	movq	%rbx, 0x48(%rsp)
    ca4e:      	cmpl	%r15d, %r12d
    ca51:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    ca57:      	movq	0x8(%rsp), %r12
    ca5c:      	movq	%r12, 0x30(%rsp)
    ca61:      	movq	0x38(%rsp), %rdx
    ca66:      	movq	0x40(%rsp), %r15
    ca6b:      	jmp	0xcabe <generic_fentry_path+0x25fe>
    ca6d:      	leaq	0x10(%r15), %rdx
    ca71:      	movl	$0x4, %eax
    ca76:      	movq	%rbp, %rdi
    ca79:      	movl	$0x8, %esi
    ca7e:      	callq	*%rax
    ca80:      	movq	0x40(%rsp), %rax
    ca85:      	cmpq	(%rsp), %rax
    ca89:      	je	0x15f2d <generic_fentry_path+0xba6d>
    ca8f:      	addq	$0x18, %r15
    ca93:      	movl	$0x4, %eax
    ca98:      	leaq	0x30(%rsp), %rdi
    ca9d:      	movl	$0x8, %esi
    caa2:      	movq	%r15, %rdx
    caa5:      	callq	*%rax
    caa7:      	movq	(%rsp), %r15
    caab:      	movq	%r15, 0x40(%rsp)
    cab0:      	leaq	0x20(%r15), %rdx
    cab4:      	movq	%rdx, 0x38(%rsp)
    cab9:      	movq	0x30(%rsp), %r12
    cabe:      	cmpq	0x18(%rsp), %r12
    cac3:      	jne	0xcad0 <generic_fentry_path+0x2610>
    cac5:      	cmpq	0x20(%rsp), %rdx
    caca:      	je	0x15f2d <generic_fentry_path+0xba6d>
    cad0:      	movl	$0x4, %eax
    cad5:      	leaq	0x10(%rsp), %rdi
    cada:      	movl	$0x8, %esi
    cadf:      	callq	*%rax
    cae1:      	cmpq	0x10(%rsp), %r12
    cae6:      	je	0xcbde <generic_fentry_path+0x271e>
    caec:      	leaq	0x18(%r12), %rbx
    caf1:      	movl	$0x4, %eax
    caf6:      	movq	%rbp, %rdi
    caf9:      	movl	$0x8, %esi
    cafe:      	movq	%rbx, %rdx
    cb01:      	callq	*%rax
    cb03:      	cmpq	%r12, (%rsp)
    cb07:      	je	0xcbde <generic_fentry_path+0x271e>
    cb0d:      	movl	$0x4, %eax
    cb12:      	leaq	0x8(%rsp), %rdi
    cb17:      	movl	$0x8, %esi
    cb1c:      	movq	%rbx, %rdx
    cb1f:      	callq	*%rax
    cb21:      	addq	$0x20, %r12
    cb25:      	movl	$0x4, %eax
    cb2a:      	leaq	0x58(%rsp), %rdi
    cb2f:      	movl	$0x10, %ecx
    cb34:      	movl	$0x10, %esi
    cb39:      	movq	%r12, %rdx
    cb3c:      	callq	*%rax
    cb3e:      	movq	0x28(%rsp), %rbx
    cb43:      	movq	0x48(%rsp), %rax
    cb48:      	movl	0x5c(%rsp), %r15d
    cb4d:      	subq	%rbx, %rax
    cb50:      	movl	0x50(%rsp), %r12d
    cb55:      	movl	%r15d, %edx
    cb58:      	subl	%r12d, %edx
    cb5b:      	movl	$0x0, %ecx
    cb60:      	cmovbl	%ecx, %edx
    cb63:      	addq	0x60(%rsp), %rdx
    cb68:      	xorl	%esi, %esi
    cb6a:      	cmpl	%r15d, %r12d
    cb6d:      	seta	%sil
    cb71:      	movl	%r15d, %ecx
    cb74:      	cmovbl	%r12d, %ecx
    cb78:      	addl	%ecx, %esi
    cb7a:      	movl	%r12d, %edi
    cb7d:      	subl	%esi, %edi
    cb7f:      	movl	%edi, 0x50(%rsp)
    cb83:      	subq	%rsi, %rax
    cb86:      	jb	0x15f32 <generic_fentry_path+0xba72>
    cb8c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    cb92:      	ja	0x15f32 <generic_fentry_path+0xba72>
    cb98:      	cmpl	%r15d, %r12d
    cb9b:      	jbe	0xcba1 <generic_fentry_path+0x26e1>
    cb9d:      	movb	$0x2f, (%rbx,%rax)
    cba1:      	xorl	%edi, %edi
    cba3:      	cmpl	%r15d, %r12d
    cba6:      	seta	%dil
    cbaa:      	movzbl	%cl, %esi
    cbad:      	addq	%rax, %rbx
    cbb0:      	addq	%rbx, %rdi
    cbb3:      	movl	$0x4, %eax
    cbb8:      	callq	*%rax
    cbba:      	movq	%rbx, 0x48(%rsp)
    cbbf:      	cmpl	%r15d, %r12d
    cbc2:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    cbc8:      	movq	0x8(%rsp), %r12
    cbcd:      	movq	%r12, 0x30(%rsp)
    cbd2:      	movq	0x38(%rsp), %rdx
    cbd7:      	movq	0x40(%rsp), %r15
    cbdc:      	jmp	0xcc2f <generic_fentry_path+0x276f>
    cbde:      	leaq	0x10(%r15), %rdx
    cbe2:      	movl	$0x4, %eax
    cbe7:      	movq	%rbp, %rdi
    cbea:      	movl	$0x8, %esi
    cbef:      	callq	*%rax
    cbf1:      	movq	0x40(%rsp), %rax
    cbf6:      	cmpq	(%rsp), %rax
    cbfa:      	je	0x15f2d <generic_fentry_path+0xba6d>
    cc00:      	addq	$0x18, %r15
    cc04:      	movl	$0x4, %eax
    cc09:      	leaq	0x30(%rsp), %rdi
    cc0e:      	movl	$0x8, %esi
    cc13:      	movq	%r15, %rdx
    cc16:      	callq	*%rax
    cc18:      	movq	(%rsp), %r15
    cc1c:      	movq	%r15, 0x40(%rsp)
    cc21:      	leaq	0x20(%r15), %rdx
    cc25:      	movq	%rdx, 0x38(%rsp)
    cc2a:      	movq	0x30(%rsp), %r12
    cc2f:      	cmpq	0x18(%rsp), %r12
    cc34:      	jne	0xcc41 <generic_fentry_path+0x2781>
    cc36:      	cmpq	0x20(%rsp), %rdx
    cc3b:      	je	0x15f2d <generic_fentry_path+0xba6d>
    cc41:      	movl	$0x4, %eax
    cc46:      	leaq	0x10(%rsp), %rdi
    cc4b:      	movl	$0x8, %esi
    cc50:      	callq	*%rax
    cc52:      	cmpq	0x10(%rsp), %r12
    cc57:      	je	0xcd4f <generic_fentry_path+0x288f>
    cc5d:      	leaq	0x18(%r12), %rbx
    cc62:      	movl	$0x4, %eax
    cc67:      	movq	%rbp, %rdi
    cc6a:      	movl	$0x8, %esi
    cc6f:      	movq	%rbx, %rdx
    cc72:      	callq	*%rax
    cc74:      	cmpq	%r12, (%rsp)
    cc78:      	je	0xcd4f <generic_fentry_path+0x288f>
    cc7e:      	movl	$0x4, %eax
    cc83:      	leaq	0x8(%rsp), %rdi
    cc88:      	movl	$0x8, %esi
    cc8d:      	movq	%rbx, %rdx
    cc90:      	callq	*%rax
    cc92:      	addq	$0x20, %r12
    cc96:      	movl	$0x4, %eax
    cc9b:      	leaq	0x58(%rsp), %rdi
    cca0:      	movl	$0x10, %ecx
    cca5:      	movl	$0x10, %esi
    ccaa:      	movq	%r12, %rdx
    ccad:      	callq	*%rax
    ccaf:      	movq	0x28(%rsp), %rbx
    ccb4:      	movq	0x48(%rsp), %rax
    ccb9:      	movl	0x5c(%rsp), %r15d
    ccbe:      	subq	%rbx, %rax
    ccc1:      	movl	0x50(%rsp), %r12d
    ccc6:      	movl	%r15d, %edx
    ccc9:      	subl	%r12d, %edx
    cccc:      	movl	$0x0, %ecx
    ccd1:      	cmovbl	%ecx, %edx
    ccd4:      	addq	0x60(%rsp), %rdx
    ccd9:      	xorl	%esi, %esi
    ccdb:      	cmpl	%r15d, %r12d
    ccde:      	seta	%sil
    cce2:      	movl	%r15d, %ecx
    cce5:      	cmovbl	%r12d, %ecx
    cce9:      	addl	%ecx, %esi
    cceb:      	movl	%r12d, %edi
    ccee:      	subl	%esi, %edi
    ccf0:      	movl	%edi, 0x50(%rsp)
    ccf4:      	subq	%rsi, %rax
    ccf7:      	jb	0x15f32 <generic_fentry_path+0xba72>
    ccfd:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    cd03:      	ja	0x15f32 <generic_fentry_path+0xba72>
    cd09:      	cmpl	%r15d, %r12d
    cd0c:      	jbe	0xcd12 <generic_fentry_path+0x2852>
    cd0e:      	movb	$0x2f, (%rbx,%rax)
    cd12:      	xorl	%edi, %edi
    cd14:      	cmpl	%r15d, %r12d
    cd17:      	seta	%dil
    cd1b:      	movzbl	%cl, %esi
    cd1e:      	addq	%rax, %rbx
    cd21:      	addq	%rbx, %rdi
    cd24:      	movl	$0x4, %eax
    cd29:      	callq	*%rax
    cd2b:      	movq	%rbx, 0x48(%rsp)
    cd30:      	cmpl	%r15d, %r12d
    cd33:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    cd39:      	movq	0x8(%rsp), %r12
    cd3e:      	movq	%r12, 0x30(%rsp)
    cd43:      	movq	0x38(%rsp), %rdx
    cd48:      	movq	0x40(%rsp), %r15
    cd4d:      	jmp	0xcda0 <generic_fentry_path+0x28e0>
    cd4f:      	leaq	0x10(%r15), %rdx
    cd53:      	movl	$0x4, %eax
    cd58:      	movq	%rbp, %rdi
    cd5b:      	movl	$0x8, %esi
    cd60:      	callq	*%rax
    cd62:      	movq	0x40(%rsp), %rax
    cd67:      	cmpq	(%rsp), %rax
    cd6b:      	je	0x15f2d <generic_fentry_path+0xba6d>
    cd71:      	addq	$0x18, %r15
    cd75:      	movl	$0x4, %eax
    cd7a:      	leaq	0x30(%rsp), %rdi
    cd7f:      	movl	$0x8, %esi
    cd84:      	movq	%r15, %rdx
    cd87:      	callq	*%rax
    cd89:      	movq	(%rsp), %r15
    cd8d:      	movq	%r15, 0x40(%rsp)
    cd92:      	leaq	0x20(%r15), %rdx
    cd96:      	movq	%rdx, 0x38(%rsp)
    cd9b:      	movq	0x30(%rsp), %r12
    cda0:      	cmpq	0x18(%rsp), %r12
    cda5:      	jne	0xcdb2 <generic_fentry_path+0x28f2>
    cda7:      	cmpq	0x20(%rsp), %rdx
    cdac:      	je	0x15f2d <generic_fentry_path+0xba6d>
    cdb2:      	movl	$0x4, %eax
    cdb7:      	leaq	0x10(%rsp), %rdi
    cdbc:      	movl	$0x8, %esi
    cdc1:      	callq	*%rax
    cdc3:      	cmpq	0x10(%rsp), %r12
    cdc8:      	je	0xcec0 <generic_fentry_path+0x2a00>
    cdce:      	leaq	0x18(%r12), %rbx
    cdd3:      	movl	$0x4, %eax
    cdd8:      	movq	%rbp, %rdi
    cddb:      	movl	$0x8, %esi
    cde0:      	movq	%rbx, %rdx
    cde3:      	callq	*%rax
    cde5:      	cmpq	%r12, (%rsp)
    cde9:      	je	0xcec0 <generic_fentry_path+0x2a00>
    cdef:      	movl	$0x4, %eax
    cdf4:      	leaq	0x8(%rsp), %rdi
    cdf9:      	movl	$0x8, %esi
    cdfe:      	movq	%rbx, %rdx
    ce01:      	callq	*%rax
    ce03:      	addq	$0x20, %r12
    ce07:      	movl	$0x4, %eax
    ce0c:      	leaq	0x58(%rsp), %rdi
    ce11:      	movl	$0x10, %ecx
    ce16:      	movl	$0x10, %esi
    ce1b:      	movq	%r12, %rdx
    ce1e:      	callq	*%rax
    ce20:      	movq	0x28(%rsp), %rbx
    ce25:      	movq	0x48(%rsp), %rax
    ce2a:      	movl	0x5c(%rsp), %r15d
    ce2f:      	subq	%rbx, %rax
    ce32:      	movl	0x50(%rsp), %r12d
    ce37:      	movl	%r15d, %edx
    ce3a:      	subl	%r12d, %edx
    ce3d:      	movl	$0x0, %ecx
    ce42:      	cmovbl	%ecx, %edx
    ce45:      	addq	0x60(%rsp), %rdx
    ce4a:      	xorl	%esi, %esi
    ce4c:      	cmpl	%r15d, %r12d
    ce4f:      	seta	%sil
    ce53:      	movl	%r15d, %ecx
    ce56:      	cmovbl	%r12d, %ecx
    ce5a:      	addl	%ecx, %esi
    ce5c:      	movl	%r12d, %edi
    ce5f:      	subl	%esi, %edi
    ce61:      	movl	%edi, 0x50(%rsp)
    ce65:      	subq	%rsi, %rax
    ce68:      	jb	0x15f32 <generic_fentry_path+0xba72>
    ce6e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ce74:      	ja	0x15f32 <generic_fentry_path+0xba72>
    ce7a:      	cmpl	%r15d, %r12d
    ce7d:      	jbe	0xce83 <generic_fentry_path+0x29c3>
    ce7f:      	movb	$0x2f, (%rbx,%rax)
    ce83:      	xorl	%edi, %edi
    ce85:      	cmpl	%r15d, %r12d
    ce88:      	seta	%dil
    ce8c:      	movzbl	%cl, %esi
    ce8f:      	addq	%rax, %rbx
    ce92:      	addq	%rbx, %rdi
    ce95:      	movl	$0x4, %eax
    ce9a:      	callq	*%rax
    ce9c:      	movq	%rbx, 0x48(%rsp)
    cea1:      	cmpl	%r15d, %r12d
    cea4:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    ceaa:      	movq	0x8(%rsp), %r12
    ceaf:      	movq	%r12, 0x30(%rsp)
    ceb4:      	movq	0x38(%rsp), %rdx
    ceb9:      	movq	0x40(%rsp), %r15
    cebe:      	jmp	0xcf11 <generic_fentry_path+0x2a51>
    cec0:      	leaq	0x10(%r15), %rdx
    cec4:      	movl	$0x4, %eax
    cec9:      	movq	%rbp, %rdi
    cecc:      	movl	$0x8, %esi
    ced1:      	callq	*%rax
    ced3:      	movq	0x40(%rsp), %rax
    ced8:      	cmpq	(%rsp), %rax
    cedc:      	je	0x15f2d <generic_fentry_path+0xba6d>
    cee2:      	addq	$0x18, %r15
    cee6:      	movl	$0x4, %eax
    ceeb:      	leaq	0x30(%rsp), %rdi
    cef0:      	movl	$0x8, %esi
    cef5:      	movq	%r15, %rdx
    cef8:      	callq	*%rax
    cefa:      	movq	(%rsp), %r15
    cefe:      	movq	%r15, 0x40(%rsp)
    cf03:      	leaq	0x20(%r15), %rdx
    cf07:      	movq	%rdx, 0x38(%rsp)
    cf0c:      	movq	0x30(%rsp), %r12
    cf11:      	cmpq	0x18(%rsp), %r12
    cf16:      	jne	0xcf23 <generic_fentry_path+0x2a63>
    cf18:      	cmpq	0x20(%rsp), %rdx
    cf1d:      	je	0x15f2d <generic_fentry_path+0xba6d>
    cf23:      	movl	$0x4, %eax
    cf28:      	leaq	0x10(%rsp), %rdi
    cf2d:      	movl	$0x8, %esi
    cf32:      	callq	*%rax
    cf34:      	cmpq	0x10(%rsp), %r12
    cf39:      	je	0xd031 <generic_fentry_path+0x2b71>
    cf3f:      	leaq	0x18(%r12), %rbx
    cf44:      	movl	$0x4, %eax
    cf49:      	movq	%rbp, %rdi
    cf4c:      	movl	$0x8, %esi
    cf51:      	movq	%rbx, %rdx
    cf54:      	callq	*%rax
    cf56:      	cmpq	%r12, (%rsp)
    cf5a:      	je	0xd031 <generic_fentry_path+0x2b71>
    cf60:      	movl	$0x4, %eax
    cf65:      	leaq	0x8(%rsp), %rdi
    cf6a:      	movl	$0x8, %esi
    cf6f:      	movq	%rbx, %rdx
    cf72:      	callq	*%rax
    cf74:      	addq	$0x20, %r12
    cf78:      	movl	$0x4, %eax
    cf7d:      	leaq	0x58(%rsp), %rdi
    cf82:      	movl	$0x10, %ecx
    cf87:      	movl	$0x10, %esi
    cf8c:      	movq	%r12, %rdx
    cf8f:      	callq	*%rax
    cf91:      	movq	0x28(%rsp), %rbx
    cf96:      	movq	0x48(%rsp), %rax
    cf9b:      	movl	0x5c(%rsp), %r15d
    cfa0:      	subq	%rbx, %rax
    cfa3:      	movl	0x50(%rsp), %r12d
    cfa8:      	movl	%r15d, %edx
    cfab:      	subl	%r12d, %edx
    cfae:      	movl	$0x0, %ecx
    cfb3:      	cmovbl	%ecx, %edx
    cfb6:      	addq	0x60(%rsp), %rdx
    cfbb:      	xorl	%esi, %esi
    cfbd:      	cmpl	%r15d, %r12d
    cfc0:      	seta	%sil
    cfc4:      	movl	%r15d, %ecx
    cfc7:      	cmovbl	%r12d, %ecx
    cfcb:      	addl	%ecx, %esi
    cfcd:      	movl	%r12d, %edi
    cfd0:      	subl	%esi, %edi
    cfd2:      	movl	%edi, 0x50(%rsp)
    cfd6:      	subq	%rsi, %rax
    cfd9:      	jb	0x15f32 <generic_fentry_path+0xba72>
    cfdf:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    cfe5:      	ja	0x15f32 <generic_fentry_path+0xba72>
    cfeb:      	cmpl	%r15d, %r12d
    cfee:      	jbe	0xcff4 <generic_fentry_path+0x2b34>
    cff0:      	movb	$0x2f, (%rbx,%rax)
    cff4:      	xorl	%edi, %edi
    cff6:      	cmpl	%r15d, %r12d
    cff9:      	seta	%dil
    cffd:      	movzbl	%cl, %esi
    d000:      	addq	%rax, %rbx
    d003:      	addq	%rbx, %rdi
    d006:      	movl	$0x4, %eax
    d00b:      	callq	*%rax
    d00d:      	movq	%rbx, 0x48(%rsp)
    d012:      	cmpl	%r15d, %r12d
    d015:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    d01b:      	movq	0x8(%rsp), %r12
    d020:      	movq	%r12, 0x30(%rsp)
    d025:      	movq	0x38(%rsp), %rdx
    d02a:      	movq	0x40(%rsp), %r15
    d02f:      	jmp	0xd082 <generic_fentry_path+0x2bc2>
    d031:      	leaq	0x10(%r15), %rdx
    d035:      	movl	$0x4, %eax
    d03a:      	movq	%rbp, %rdi
    d03d:      	movl	$0x8, %esi
    d042:      	callq	*%rax
    d044:      	movq	0x40(%rsp), %rax
    d049:      	cmpq	(%rsp), %rax
    d04d:      	je	0x15f2d <generic_fentry_path+0xba6d>
    d053:      	addq	$0x18, %r15
    d057:      	movl	$0x4, %eax
    d05c:      	leaq	0x30(%rsp), %rdi
    d061:      	movl	$0x8, %esi
    d066:      	movq	%r15, %rdx
    d069:      	callq	*%rax
    d06b:      	movq	(%rsp), %r15
    d06f:      	movq	%r15, 0x40(%rsp)
    d074:      	leaq	0x20(%r15), %rdx
    d078:      	movq	%rdx, 0x38(%rsp)
    d07d:      	movq	0x30(%rsp), %r12
    d082:      	cmpq	0x18(%rsp), %r12
    d087:      	jne	0xd094 <generic_fentry_path+0x2bd4>
    d089:      	cmpq	0x20(%rsp), %rdx
    d08e:      	je	0x15f2d <generic_fentry_path+0xba6d>
    d094:      	movl	$0x4, %eax
    d099:      	leaq	0x10(%rsp), %rdi
    d09e:      	movl	$0x8, %esi
    d0a3:      	callq	*%rax
    d0a5:      	cmpq	0x10(%rsp), %r12
    d0aa:      	je	0xd1a2 <generic_fentry_path+0x2ce2>
    d0b0:      	leaq	0x18(%r12), %rbx
    d0b5:      	movl	$0x4, %eax
    d0ba:      	movq	%rbp, %rdi
    d0bd:      	movl	$0x8, %esi
    d0c2:      	movq	%rbx, %rdx
    d0c5:      	callq	*%rax
    d0c7:      	cmpq	%r12, (%rsp)
    d0cb:      	je	0xd1a2 <generic_fentry_path+0x2ce2>
    d0d1:      	movl	$0x4, %eax
    d0d6:      	leaq	0x8(%rsp), %rdi
    d0db:      	movl	$0x8, %esi
    d0e0:      	movq	%rbx, %rdx
    d0e3:      	callq	*%rax
    d0e5:      	addq	$0x20, %r12
    d0e9:      	movl	$0x4, %eax
    d0ee:      	leaq	0x58(%rsp), %rdi
    d0f3:      	movl	$0x10, %ecx
    d0f8:      	movl	$0x10, %esi
    d0fd:      	movq	%r12, %rdx
    d100:      	callq	*%rax
    d102:      	movq	0x28(%rsp), %rbx
    d107:      	movq	0x48(%rsp), %rax
    d10c:      	movl	0x5c(%rsp), %r15d
    d111:      	subq	%rbx, %rax
    d114:      	movl	0x50(%rsp), %r12d
    d119:      	movl	%r15d, %edx
    d11c:      	subl	%r12d, %edx
    d11f:      	movl	$0x0, %ecx
    d124:      	cmovbl	%ecx, %edx
    d127:      	addq	0x60(%rsp), %rdx
    d12c:      	xorl	%esi, %esi
    d12e:      	cmpl	%r15d, %r12d
    d131:      	seta	%sil
    d135:      	movl	%r15d, %ecx
    d138:      	cmovbl	%r12d, %ecx
    d13c:      	addl	%ecx, %esi
    d13e:      	movl	%r12d, %edi
    d141:      	subl	%esi, %edi
    d143:      	movl	%edi, 0x50(%rsp)
    d147:      	subq	%rsi, %rax
    d14a:      	jb	0x15f32 <generic_fentry_path+0xba72>
    d150:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d156:      	ja	0x15f32 <generic_fentry_path+0xba72>
    d15c:      	cmpl	%r15d, %r12d
    d15f:      	jbe	0xd165 <generic_fentry_path+0x2ca5>
    d161:      	movb	$0x2f, (%rbx,%rax)
    d165:      	xorl	%edi, %edi
    d167:      	cmpl	%r15d, %r12d
    d16a:      	seta	%dil
    d16e:      	movzbl	%cl, %esi
    d171:      	addq	%rax, %rbx
    d174:      	addq	%rbx, %rdi
    d177:      	movl	$0x4, %eax
    d17c:      	callq	*%rax
    d17e:      	movq	%rbx, 0x48(%rsp)
    d183:      	cmpl	%r15d, %r12d
    d186:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    d18c:      	movq	0x8(%rsp), %r12
    d191:      	movq	%r12, 0x30(%rsp)
    d196:      	movq	0x38(%rsp), %rdx
    d19b:      	movq	0x40(%rsp), %r15
    d1a0:      	jmp	0xd1f3 <generic_fentry_path+0x2d33>
    d1a2:      	leaq	0x10(%r15), %rdx
    d1a6:      	movl	$0x4, %eax
    d1ab:      	movq	%rbp, %rdi
    d1ae:      	movl	$0x8, %esi
    d1b3:      	callq	*%rax
    d1b5:      	movq	0x40(%rsp), %rax
    d1ba:      	cmpq	(%rsp), %rax
    d1be:      	je	0x15f2d <generic_fentry_path+0xba6d>
    d1c4:      	addq	$0x18, %r15
    d1c8:      	movl	$0x4, %eax
    d1cd:      	leaq	0x30(%rsp), %rdi
    d1d2:      	movl	$0x8, %esi
    d1d7:      	movq	%r15, %rdx
    d1da:      	callq	*%rax
    d1dc:      	movq	(%rsp), %r15
    d1e0:      	movq	%r15, 0x40(%rsp)
    d1e5:      	leaq	0x20(%r15), %rdx
    d1e9:      	movq	%rdx, 0x38(%rsp)
    d1ee:      	movq	0x30(%rsp), %r12
    d1f3:      	cmpq	0x18(%rsp), %r12
    d1f8:      	jne	0xd205 <generic_fentry_path+0x2d45>
    d1fa:      	cmpq	0x20(%rsp), %rdx
    d1ff:      	je	0x15f2d <generic_fentry_path+0xba6d>
    d205:      	movl	$0x4, %eax
    d20a:      	leaq	0x10(%rsp), %rdi
    d20f:      	movl	$0x8, %esi
    d214:      	callq	*%rax
    d216:      	cmpq	0x10(%rsp), %r12
    d21b:      	je	0xd313 <generic_fentry_path+0x2e53>
    d221:      	leaq	0x18(%r12), %rbx
    d226:      	movl	$0x4, %eax
    d22b:      	movq	%rbp, %rdi
    d22e:      	movl	$0x8, %esi
    d233:      	movq	%rbx, %rdx
    d236:      	callq	*%rax
    d238:      	cmpq	%r12, (%rsp)
    d23c:      	je	0xd313 <generic_fentry_path+0x2e53>
    d242:      	movl	$0x4, %eax
    d247:      	leaq	0x8(%rsp), %rdi
    d24c:      	movl	$0x8, %esi
    d251:      	movq	%rbx, %rdx
    d254:      	callq	*%rax
    d256:      	addq	$0x20, %r12
    d25a:      	movl	$0x4, %eax
    d25f:      	leaq	0x58(%rsp), %rdi
    d264:      	movl	$0x10, %ecx
    d269:      	movl	$0x10, %esi
    d26e:      	movq	%r12, %rdx
    d271:      	callq	*%rax
    d273:      	movq	0x28(%rsp), %rbx
    d278:      	movq	0x48(%rsp), %rax
    d27d:      	movl	0x5c(%rsp), %r15d
    d282:      	subq	%rbx, %rax
    d285:      	movl	0x50(%rsp), %r12d
    d28a:      	movl	%r15d, %edx
    d28d:      	subl	%r12d, %edx
    d290:      	movl	$0x0, %ecx
    d295:      	cmovbl	%ecx, %edx
    d298:      	addq	0x60(%rsp), %rdx
    d29d:      	xorl	%esi, %esi
    d29f:      	cmpl	%r15d, %r12d
    d2a2:      	seta	%sil
    d2a6:      	movl	%r15d, %ecx
    d2a9:      	cmovbl	%r12d, %ecx
    d2ad:      	addl	%ecx, %esi
    d2af:      	movl	%r12d, %edi
    d2b2:      	subl	%esi, %edi
    d2b4:      	movl	%edi, 0x50(%rsp)
    d2b8:      	subq	%rsi, %rax
    d2bb:      	jb	0x15f32 <generic_fentry_path+0xba72>
    d2c1:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d2c7:      	ja	0x15f32 <generic_fentry_path+0xba72>
    d2cd:      	cmpl	%r15d, %r12d
    d2d0:      	jbe	0xd2d6 <generic_fentry_path+0x2e16>
    d2d2:      	movb	$0x2f, (%rbx,%rax)
    d2d6:      	xorl	%edi, %edi
    d2d8:      	cmpl	%r15d, %r12d
    d2db:      	seta	%dil
    d2df:      	movzbl	%cl, %esi
    d2e2:      	addq	%rax, %rbx
    d2e5:      	addq	%rbx, %rdi
    d2e8:      	movl	$0x4, %eax
    d2ed:      	callq	*%rax
    d2ef:      	movq	%rbx, 0x48(%rsp)
    d2f4:      	cmpl	%r15d, %r12d
    d2f7:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    d2fd:      	movq	0x8(%rsp), %r12
    d302:      	movq	%r12, 0x30(%rsp)
    d307:      	movq	0x38(%rsp), %rdx
    d30c:      	movq	0x40(%rsp), %r15
    d311:      	jmp	0xd364 <generic_fentry_path+0x2ea4>
    d313:      	leaq	0x10(%r15), %rdx
    d317:      	movl	$0x4, %eax
    d31c:      	movq	%rbp, %rdi
    d31f:      	movl	$0x8, %esi
    d324:      	callq	*%rax
    d326:      	movq	0x40(%rsp), %rax
    d32b:      	cmpq	(%rsp), %rax
    d32f:      	je	0x15f2d <generic_fentry_path+0xba6d>
    d335:      	addq	$0x18, %r15
    d339:      	movl	$0x4, %eax
    d33e:      	leaq	0x30(%rsp), %rdi
    d343:      	movl	$0x8, %esi
    d348:      	movq	%r15, %rdx
    d34b:      	callq	*%rax
    d34d:      	movq	(%rsp), %r15
    d351:      	movq	%r15, 0x40(%rsp)
    d356:      	leaq	0x20(%r15), %rdx
    d35a:      	movq	%rdx, 0x38(%rsp)
    d35f:      	movq	0x30(%rsp), %r12
    d364:      	cmpq	0x18(%rsp), %r12
    d369:      	jne	0xd376 <generic_fentry_path+0x2eb6>
    d36b:      	cmpq	0x20(%rsp), %rdx
    d370:      	je	0x15f2d <generic_fentry_path+0xba6d>
    d376:      	movl	$0x4, %eax
    d37b:      	leaq	0x10(%rsp), %rdi
    d380:      	movl	$0x8, %esi
    d385:      	callq	*%rax
    d387:      	cmpq	0x10(%rsp), %r12
    d38c:      	je	0xd484 <generic_fentry_path+0x2fc4>
    d392:      	leaq	0x18(%r12), %rbx
    d397:      	movl	$0x4, %eax
    d39c:      	movq	%rbp, %rdi
    d39f:      	movl	$0x8, %esi
    d3a4:      	movq	%rbx, %rdx
    d3a7:      	callq	*%rax
    d3a9:      	cmpq	%r12, (%rsp)
    d3ad:      	je	0xd484 <generic_fentry_path+0x2fc4>
    d3b3:      	movl	$0x4, %eax
    d3b8:      	leaq	0x8(%rsp), %rdi
    d3bd:      	movl	$0x8, %esi
    d3c2:      	movq	%rbx, %rdx
    d3c5:      	callq	*%rax
    d3c7:      	addq	$0x20, %r12
    d3cb:      	movl	$0x4, %eax
    d3d0:      	leaq	0x58(%rsp), %rdi
    d3d5:      	movl	$0x10, %ecx
    d3da:      	movl	$0x10, %esi
    d3df:      	movq	%r12, %rdx
    d3e2:      	callq	*%rax
    d3e4:      	movq	0x28(%rsp), %rbx
    d3e9:      	movq	0x48(%rsp), %rax
    d3ee:      	movl	0x5c(%rsp), %r15d
    d3f3:      	subq	%rbx, %rax
    d3f6:      	movl	0x50(%rsp), %r12d
    d3fb:      	movl	%r15d, %edx
    d3fe:      	subl	%r12d, %edx
    d401:      	movl	$0x0, %ecx
    d406:      	cmovbl	%ecx, %edx
    d409:      	addq	0x60(%rsp), %rdx
    d40e:      	xorl	%esi, %esi
    d410:      	cmpl	%r15d, %r12d
    d413:      	seta	%sil
    d417:      	movl	%r15d, %ecx
    d41a:      	cmovbl	%r12d, %ecx
    d41e:      	addl	%ecx, %esi
    d420:      	movl	%r12d, %edi
    d423:      	subl	%esi, %edi
    d425:      	movl	%edi, 0x50(%rsp)
    d429:      	subq	%rsi, %rax
    d42c:      	jb	0x15f32 <generic_fentry_path+0xba72>
    d432:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d438:      	ja	0x15f32 <generic_fentry_path+0xba72>
    d43e:      	cmpl	%r15d, %r12d
    d441:      	jbe	0xd447 <generic_fentry_path+0x2f87>
    d443:      	movb	$0x2f, (%rbx,%rax)
    d447:      	xorl	%edi, %edi
    d449:      	cmpl	%r15d, %r12d
    d44c:      	seta	%dil
    d450:      	movzbl	%cl, %esi
    d453:      	addq	%rax, %rbx
    d456:      	addq	%rbx, %rdi
    d459:      	movl	$0x4, %eax
    d45e:      	callq	*%rax
    d460:      	movq	%rbx, 0x48(%rsp)
    d465:      	cmpl	%r15d, %r12d
    d468:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    d46e:      	movq	0x8(%rsp), %r12
    d473:      	movq	%r12, 0x30(%rsp)
    d478:      	movq	0x38(%rsp), %rdx
    d47d:      	movq	0x40(%rsp), %r15
    d482:      	jmp	0xd4d5 <generic_fentry_path+0x3015>
    d484:      	leaq	0x10(%r15), %rdx
    d488:      	movl	$0x4, %eax
    d48d:      	movq	%rbp, %rdi
    d490:      	movl	$0x8, %esi
    d495:      	callq	*%rax
    d497:      	movq	0x40(%rsp), %rax
    d49c:      	cmpq	(%rsp), %rax
    d4a0:      	je	0x15f2d <generic_fentry_path+0xba6d>
    d4a6:      	addq	$0x18, %r15
    d4aa:      	movl	$0x4, %eax
    d4af:      	leaq	0x30(%rsp), %rdi
    d4b4:      	movl	$0x8, %esi
    d4b9:      	movq	%r15, %rdx
    d4bc:      	callq	*%rax
    d4be:      	movq	(%rsp), %r15
    d4c2:      	movq	%r15, 0x40(%rsp)
    d4c7:      	leaq	0x20(%r15), %rdx
    d4cb:      	movq	%rdx, 0x38(%rsp)
    d4d0:      	movq	0x30(%rsp), %r12
    d4d5:      	cmpq	0x18(%rsp), %r12
    d4da:      	jne	0xd4e7 <generic_fentry_path+0x3027>
    d4dc:      	cmpq	0x20(%rsp), %rdx
    d4e1:      	je	0x15f2d <generic_fentry_path+0xba6d>
    d4e7:      	movl	$0x4, %eax
    d4ec:      	leaq	0x10(%rsp), %rdi
    d4f1:      	movl	$0x8, %esi
    d4f6:      	callq	*%rax
    d4f8:      	cmpq	0x10(%rsp), %r12
    d4fd:      	je	0xd5f5 <generic_fentry_path+0x3135>
    d503:      	leaq	0x18(%r12), %rbx
    d508:      	movl	$0x4, %eax
    d50d:      	movq	%rbp, %rdi
    d510:      	movl	$0x8, %esi
    d515:      	movq	%rbx, %rdx
    d518:      	callq	*%rax
    d51a:      	cmpq	%r12, (%rsp)
    d51e:      	je	0xd5f5 <generic_fentry_path+0x3135>
    d524:      	movl	$0x4, %eax
    d529:      	leaq	0x8(%rsp), %rdi
    d52e:      	movl	$0x8, %esi
    d533:      	movq	%rbx, %rdx
    d536:      	callq	*%rax
    d538:      	addq	$0x20, %r12
    d53c:      	movl	$0x4, %eax
    d541:      	leaq	0x58(%rsp), %rdi
    d546:      	movl	$0x10, %ecx
    d54b:      	movl	$0x10, %esi
    d550:      	movq	%r12, %rdx
    d553:      	callq	*%rax
    d555:      	movq	0x28(%rsp), %rbx
    d55a:      	movq	0x48(%rsp), %rax
    d55f:      	movl	0x5c(%rsp), %r15d
    d564:      	subq	%rbx, %rax
    d567:      	movl	0x50(%rsp), %r12d
    d56c:      	movl	%r15d, %edx
    d56f:      	subl	%r12d, %edx
    d572:      	movl	$0x0, %ecx
    d577:      	cmovbl	%ecx, %edx
    d57a:      	addq	0x60(%rsp), %rdx
    d57f:      	xorl	%esi, %esi
    d581:      	cmpl	%r15d, %r12d
    d584:      	seta	%sil
    d588:      	movl	%r15d, %ecx
    d58b:      	cmovbl	%r12d, %ecx
    d58f:      	addl	%ecx, %esi
    d591:      	movl	%r12d, %edi
    d594:      	subl	%esi, %edi
    d596:      	movl	%edi, 0x50(%rsp)
    d59a:      	subq	%rsi, %rax
    d59d:      	jb	0x15f32 <generic_fentry_path+0xba72>
    d5a3:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d5a9:      	ja	0x15f32 <generic_fentry_path+0xba72>
    d5af:      	cmpl	%r15d, %r12d
    d5b2:      	jbe	0xd5b8 <generic_fentry_path+0x30f8>
    d5b4:      	movb	$0x2f, (%rbx,%rax)
    d5b8:      	xorl	%edi, %edi
    d5ba:      	cmpl	%r15d, %r12d
    d5bd:      	seta	%dil
    d5c1:      	movzbl	%cl, %esi
    d5c4:      	addq	%rax, %rbx
    d5c7:      	addq	%rbx, %rdi
    d5ca:      	movl	$0x4, %eax
    d5cf:      	callq	*%rax
    d5d1:      	movq	%rbx, 0x48(%rsp)
    d5d6:      	cmpl	%r15d, %r12d
    d5d9:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    d5df:      	movq	0x8(%rsp), %r12
    d5e4:      	movq	%r12, 0x30(%rsp)
    d5e9:      	movq	0x38(%rsp), %rdx
    d5ee:      	movq	0x40(%rsp), %r15
    d5f3:      	jmp	0xd646 <generic_fentry_path+0x3186>
    d5f5:      	leaq	0x10(%r15), %rdx
    d5f9:      	movl	$0x4, %eax
    d5fe:      	movq	%rbp, %rdi
    d601:      	movl	$0x8, %esi
    d606:      	callq	*%rax
    d608:      	movq	0x40(%rsp), %rax
    d60d:      	cmpq	(%rsp), %rax
    d611:      	je	0x15f2d <generic_fentry_path+0xba6d>
    d617:      	addq	$0x18, %r15
    d61b:      	movl	$0x4, %eax
    d620:      	leaq	0x30(%rsp), %rdi
    d625:      	movl	$0x8, %esi
    d62a:      	movq	%r15, %rdx
    d62d:      	callq	*%rax
    d62f:      	movq	(%rsp), %r15
    d633:      	movq	%r15, 0x40(%rsp)
    d638:      	leaq	0x20(%r15), %rdx
    d63c:      	movq	%rdx, 0x38(%rsp)
    d641:      	movq	0x30(%rsp), %r12
    d646:      	cmpq	0x18(%rsp), %r12
    d64b:      	jne	0xd658 <generic_fentry_path+0x3198>
    d64d:      	cmpq	0x20(%rsp), %rdx
    d652:      	je	0x15f2d <generic_fentry_path+0xba6d>
    d658:      	movl	$0x4, %eax
    d65d:      	leaq	0x10(%rsp), %rdi
    d662:      	movl	$0x8, %esi
    d667:      	callq	*%rax
    d669:      	cmpq	0x10(%rsp), %r12
    d66e:      	je	0xd766 <generic_fentry_path+0x32a6>
    d674:      	leaq	0x18(%r12), %rbx
    d679:      	movl	$0x4, %eax
    d67e:      	movq	%rbp, %rdi
    d681:      	movl	$0x8, %esi
    d686:      	movq	%rbx, %rdx
    d689:      	callq	*%rax
    d68b:      	cmpq	%r12, (%rsp)
    d68f:      	je	0xd766 <generic_fentry_path+0x32a6>
    d695:      	movl	$0x4, %eax
    d69a:      	leaq	0x8(%rsp), %rdi
    d69f:      	movl	$0x8, %esi
    d6a4:      	movq	%rbx, %rdx
    d6a7:      	callq	*%rax
    d6a9:      	addq	$0x20, %r12
    d6ad:      	movl	$0x4, %eax
    d6b2:      	leaq	0x58(%rsp), %rdi
    d6b7:      	movl	$0x10, %ecx
    d6bc:      	movl	$0x10, %esi
    d6c1:      	movq	%r12, %rdx
    d6c4:      	callq	*%rax
    d6c6:      	movq	0x28(%rsp), %rbx
    d6cb:      	movq	0x48(%rsp), %rax
    d6d0:      	movl	0x5c(%rsp), %r15d
    d6d5:      	subq	%rbx, %rax
    d6d8:      	movl	0x50(%rsp), %r12d
    d6dd:      	movl	%r15d, %edx
    d6e0:      	subl	%r12d, %edx
    d6e3:      	movl	$0x0, %ecx
    d6e8:      	cmovbl	%ecx, %edx
    d6eb:      	addq	0x60(%rsp), %rdx
    d6f0:      	xorl	%esi, %esi
    d6f2:      	cmpl	%r15d, %r12d
    d6f5:      	seta	%sil
    d6f9:      	movl	%r15d, %ecx
    d6fc:      	cmovbl	%r12d, %ecx
    d700:      	addl	%ecx, %esi
    d702:      	movl	%r12d, %edi
    d705:      	subl	%esi, %edi
    d707:      	movl	%edi, 0x50(%rsp)
    d70b:      	subq	%rsi, %rax
    d70e:      	jb	0x15f32 <generic_fentry_path+0xba72>
    d714:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d71a:      	ja	0x15f32 <generic_fentry_path+0xba72>
    d720:      	cmpl	%r15d, %r12d
    d723:      	jbe	0xd729 <generic_fentry_path+0x3269>
    d725:      	movb	$0x2f, (%rbx,%rax)
    d729:      	xorl	%edi, %edi
    d72b:      	cmpl	%r15d, %r12d
    d72e:      	seta	%dil
    d732:      	movzbl	%cl, %esi
    d735:      	addq	%rax, %rbx
    d738:      	addq	%rbx, %rdi
    d73b:      	movl	$0x4, %eax
    d740:      	callq	*%rax
    d742:      	movq	%rbx, 0x48(%rsp)
    d747:      	cmpl	%r15d, %r12d
    d74a:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    d750:      	movq	0x8(%rsp), %r12
    d755:      	movq	%r12, 0x30(%rsp)
    d75a:      	movq	0x38(%rsp), %rdx
    d75f:      	movq	0x40(%rsp), %r15
    d764:      	jmp	0xd7b7 <generic_fentry_path+0x32f7>
    d766:      	leaq	0x10(%r15), %rdx
    d76a:      	movl	$0x4, %eax
    d76f:      	movq	%rbp, %rdi
    d772:      	movl	$0x8, %esi
    d777:      	callq	*%rax
    d779:      	movq	0x40(%rsp), %rax
    d77e:      	cmpq	(%rsp), %rax
    d782:      	je	0x15f2d <generic_fentry_path+0xba6d>
    d788:      	addq	$0x18, %r15
    d78c:      	movl	$0x4, %eax
    d791:      	leaq	0x30(%rsp), %rdi
    d796:      	movl	$0x8, %esi
    d79b:      	movq	%r15, %rdx
    d79e:      	callq	*%rax
    d7a0:      	movq	(%rsp), %r15
    d7a4:      	movq	%r15, 0x40(%rsp)
    d7a9:      	leaq	0x20(%r15), %rdx
    d7ad:      	movq	%rdx, 0x38(%rsp)
    d7b2:      	movq	0x30(%rsp), %r12
    d7b7:      	cmpq	0x18(%rsp), %r12
    d7bc:      	jne	0xd7c9 <generic_fentry_path+0x3309>
    d7be:      	cmpq	0x20(%rsp), %rdx
    d7c3:      	je	0x15f2d <generic_fentry_path+0xba6d>
    d7c9:      	movl	$0x4, %eax
    d7ce:      	leaq	0x10(%rsp), %rdi
    d7d3:      	movl	$0x8, %esi
    d7d8:      	callq	*%rax
    d7da:      	cmpq	0x10(%rsp), %r12
    d7df:      	je	0xd8d7 <generic_fentry_path+0x3417>
    d7e5:      	leaq	0x18(%r12), %rbx
    d7ea:      	movl	$0x4, %eax
    d7ef:      	movq	%rbp, %rdi
    d7f2:      	movl	$0x8, %esi
    d7f7:      	movq	%rbx, %rdx
    d7fa:      	callq	*%rax
    d7fc:      	cmpq	%r12, (%rsp)
    d800:      	je	0xd8d7 <generic_fentry_path+0x3417>
    d806:      	movl	$0x4, %eax
    d80b:      	leaq	0x8(%rsp), %rdi
    d810:      	movl	$0x8, %esi
    d815:      	movq	%rbx, %rdx
    d818:      	callq	*%rax
    d81a:      	addq	$0x20, %r12
    d81e:      	movl	$0x4, %eax
    d823:      	leaq	0x58(%rsp), %rdi
    d828:      	movl	$0x10, %ecx
    d82d:      	movl	$0x10, %esi
    d832:      	movq	%r12, %rdx
    d835:      	callq	*%rax
    d837:      	movq	0x28(%rsp), %rbx
    d83c:      	movq	0x48(%rsp), %rax
    d841:      	movl	0x5c(%rsp), %r15d
    d846:      	subq	%rbx, %rax
    d849:      	movl	0x50(%rsp), %r12d
    d84e:      	movl	%r15d, %edx
    d851:      	subl	%r12d, %edx
    d854:      	movl	$0x0, %ecx
    d859:      	cmovbl	%ecx, %edx
    d85c:      	addq	0x60(%rsp), %rdx
    d861:      	xorl	%esi, %esi
    d863:      	cmpl	%r15d, %r12d
    d866:      	seta	%sil
    d86a:      	movl	%r15d, %ecx
    d86d:      	cmovbl	%r12d, %ecx
    d871:      	addl	%ecx, %esi
    d873:      	movl	%r12d, %edi
    d876:      	subl	%esi, %edi
    d878:      	movl	%edi, 0x50(%rsp)
    d87c:      	subq	%rsi, %rax
    d87f:      	jb	0x15f32 <generic_fentry_path+0xba72>
    d885:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d88b:      	ja	0x15f32 <generic_fentry_path+0xba72>
    d891:      	cmpl	%r15d, %r12d
    d894:      	jbe	0xd89a <generic_fentry_path+0x33da>
    d896:      	movb	$0x2f, (%rbx,%rax)
    d89a:      	xorl	%edi, %edi
    d89c:      	cmpl	%r15d, %r12d
    d89f:      	seta	%dil
    d8a3:      	movzbl	%cl, %esi
    d8a6:      	addq	%rax, %rbx
    d8a9:      	addq	%rbx, %rdi
    d8ac:      	movl	$0x4, %eax
    d8b1:      	callq	*%rax
    d8b3:      	movq	%rbx, 0x48(%rsp)
    d8b8:      	cmpl	%r15d, %r12d
    d8bb:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    d8c1:      	movq	0x8(%rsp), %r12
    d8c6:      	movq	%r12, 0x30(%rsp)
    d8cb:      	movq	0x38(%rsp), %rdx
    d8d0:      	movq	0x40(%rsp), %r15
    d8d5:      	jmp	0xd928 <generic_fentry_path+0x3468>
    d8d7:      	leaq	0x10(%r15), %rdx
    d8db:      	movl	$0x4, %eax
    d8e0:      	movq	%rbp, %rdi
    d8e3:      	movl	$0x8, %esi
    d8e8:      	callq	*%rax
    d8ea:      	movq	0x40(%rsp), %rax
    d8ef:      	cmpq	(%rsp), %rax
    d8f3:      	je	0x15f2d <generic_fentry_path+0xba6d>
    d8f9:      	addq	$0x18, %r15
    d8fd:      	movl	$0x4, %eax
    d902:      	leaq	0x30(%rsp), %rdi
    d907:      	movl	$0x8, %esi
    d90c:      	movq	%r15, %rdx
    d90f:      	callq	*%rax
    d911:      	movq	(%rsp), %r15
    d915:      	movq	%r15, 0x40(%rsp)
    d91a:      	leaq	0x20(%r15), %rdx
    d91e:      	movq	%rdx, 0x38(%rsp)
    d923:      	movq	0x30(%rsp), %r12
    d928:      	cmpq	0x18(%rsp), %r12
    d92d:      	jne	0xd93a <generic_fentry_path+0x347a>
    d92f:      	cmpq	0x20(%rsp), %rdx
    d934:      	je	0x15f2d <generic_fentry_path+0xba6d>
    d93a:      	movl	$0x4, %eax
    d93f:      	leaq	0x10(%rsp), %rdi
    d944:      	movl	$0x8, %esi
    d949:      	callq	*%rax
    d94b:      	cmpq	0x10(%rsp), %r12
    d950:      	je	0xda48 <generic_fentry_path+0x3588>
    d956:      	leaq	0x18(%r12), %rbx
    d95b:      	movl	$0x4, %eax
    d960:      	movq	%rbp, %rdi
    d963:      	movl	$0x8, %esi
    d968:      	movq	%rbx, %rdx
    d96b:      	callq	*%rax
    d96d:      	cmpq	%r12, (%rsp)
    d971:      	je	0xda48 <generic_fentry_path+0x3588>
    d977:      	movl	$0x4, %eax
    d97c:      	leaq	0x8(%rsp), %rdi
    d981:      	movl	$0x8, %esi
    d986:      	movq	%rbx, %rdx
    d989:      	callq	*%rax
    d98b:      	addq	$0x20, %r12
    d98f:      	movl	$0x4, %eax
    d994:      	leaq	0x58(%rsp), %rdi
    d999:      	movl	$0x10, %ecx
    d99e:      	movl	$0x10, %esi
    d9a3:      	movq	%r12, %rdx
    d9a6:      	callq	*%rax
    d9a8:      	movq	0x28(%rsp), %rbx
    d9ad:      	movq	0x48(%rsp), %rax
    d9b2:      	movl	0x5c(%rsp), %r15d
    d9b7:      	subq	%rbx, %rax
    d9ba:      	movl	0x50(%rsp), %r12d
    d9bf:      	movl	%r15d, %edx
    d9c2:      	subl	%r12d, %edx
    d9c5:      	movl	$0x0, %ecx
    d9ca:      	cmovbl	%ecx, %edx
    d9cd:      	addq	0x60(%rsp), %rdx
    d9d2:      	xorl	%esi, %esi
    d9d4:      	cmpl	%r15d, %r12d
    d9d7:      	seta	%sil
    d9db:      	movl	%r15d, %ecx
    d9de:      	cmovbl	%r12d, %ecx
    d9e2:      	addl	%ecx, %esi
    d9e4:      	movl	%r12d, %edi
    d9e7:      	subl	%esi, %edi
    d9e9:      	movl	%edi, 0x50(%rsp)
    d9ed:      	subq	%rsi, %rax
    d9f0:      	jb	0x15f32 <generic_fentry_path+0xba72>
    d9f6:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d9fc:      	ja	0x15f32 <generic_fentry_path+0xba72>
    da02:      	cmpl	%r15d, %r12d
    da05:      	jbe	0xda0b <generic_fentry_path+0x354b>
    da07:      	movb	$0x2f, (%rbx,%rax)
    da0b:      	xorl	%edi, %edi
    da0d:      	cmpl	%r15d, %r12d
    da10:      	seta	%dil
    da14:      	movzbl	%cl, %esi
    da17:      	addq	%rax, %rbx
    da1a:      	addq	%rbx, %rdi
    da1d:      	movl	$0x4, %eax
    da22:      	callq	*%rax
    da24:      	movq	%rbx, 0x48(%rsp)
    da29:      	cmpl	%r15d, %r12d
    da2c:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    da32:      	movq	0x8(%rsp), %r12
    da37:      	movq	%r12, 0x30(%rsp)
    da3c:      	movq	0x38(%rsp), %rdx
    da41:      	movq	0x40(%rsp), %r15
    da46:      	jmp	0xda99 <generic_fentry_path+0x35d9>
    da48:      	leaq	0x10(%r15), %rdx
    da4c:      	movl	$0x4, %eax
    da51:      	movq	%rbp, %rdi
    da54:      	movl	$0x8, %esi
    da59:      	callq	*%rax
    da5b:      	movq	0x40(%rsp), %rax
    da60:      	cmpq	(%rsp), %rax
    da64:      	je	0x15f2d <generic_fentry_path+0xba6d>
    da6a:      	addq	$0x18, %r15
    da6e:      	movl	$0x4, %eax
    da73:      	leaq	0x30(%rsp), %rdi
    da78:      	movl	$0x8, %esi
    da7d:      	movq	%r15, %rdx
    da80:      	callq	*%rax
    da82:      	movq	(%rsp), %r15
    da86:      	movq	%r15, 0x40(%rsp)
    da8b:      	leaq	0x20(%r15), %rdx
    da8f:      	movq	%rdx, 0x38(%rsp)
    da94:      	movq	0x30(%rsp), %r12
    da99:      	cmpq	0x18(%rsp), %r12
    da9e:      	jne	0xdaab <generic_fentry_path+0x35eb>
    daa0:      	cmpq	0x20(%rsp), %rdx
    daa5:      	je	0x15f2d <generic_fentry_path+0xba6d>
    daab:      	movl	$0x4, %eax
    dab0:      	leaq	0x10(%rsp), %rdi
    dab5:      	movl	$0x8, %esi
    daba:      	callq	*%rax
    dabc:      	cmpq	0x10(%rsp), %r12
    dac1:      	je	0xdbb9 <generic_fentry_path+0x36f9>
    dac7:      	leaq	0x18(%r12), %rbx
    dacc:      	movl	$0x4, %eax
    dad1:      	movq	%rbp, %rdi
    dad4:      	movl	$0x8, %esi
    dad9:      	movq	%rbx, %rdx
    dadc:      	callq	*%rax
    dade:      	cmpq	%r12, (%rsp)
    dae2:      	je	0xdbb9 <generic_fentry_path+0x36f9>
    dae8:      	movl	$0x4, %eax
    daed:      	leaq	0x8(%rsp), %rdi
    daf2:      	movl	$0x8, %esi
    daf7:      	movq	%rbx, %rdx
    dafa:      	callq	*%rax
    dafc:      	addq	$0x20, %r12
    db00:      	movl	$0x4, %eax
    db05:      	leaq	0x58(%rsp), %rdi
    db0a:      	movl	$0x10, %ecx
    db0f:      	movl	$0x10, %esi
    db14:      	movq	%r12, %rdx
    db17:      	callq	*%rax
    db19:      	movq	0x28(%rsp), %rbx
    db1e:      	movq	0x48(%rsp), %rax
    db23:      	movl	0x5c(%rsp), %r15d
    db28:      	subq	%rbx, %rax
    db2b:      	movl	0x50(%rsp), %r12d
    db30:      	movl	%r15d, %edx
    db33:      	subl	%r12d, %edx
    db36:      	movl	$0x0, %ecx
    db3b:      	cmovbl	%ecx, %edx
    db3e:      	addq	0x60(%rsp), %rdx
    db43:      	xorl	%esi, %esi
    db45:      	cmpl	%r15d, %r12d
    db48:      	seta	%sil
    db4c:      	movl	%r15d, %ecx
    db4f:      	cmovbl	%r12d, %ecx
    db53:      	addl	%ecx, %esi
    db55:      	movl	%r12d, %edi
    db58:      	subl	%esi, %edi
    db5a:      	movl	%edi, 0x50(%rsp)
    db5e:      	subq	%rsi, %rax
    db61:      	jb	0x15f32 <generic_fentry_path+0xba72>
    db67:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    db6d:      	ja	0x15f32 <generic_fentry_path+0xba72>
    db73:      	cmpl	%r15d, %r12d
    db76:      	jbe	0xdb7c <generic_fentry_path+0x36bc>
    db78:      	movb	$0x2f, (%rbx,%rax)
    db7c:      	xorl	%edi, %edi
    db7e:      	cmpl	%r15d, %r12d
    db81:      	seta	%dil
    db85:      	movzbl	%cl, %esi
    db88:      	addq	%rax, %rbx
    db8b:      	addq	%rbx, %rdi
    db8e:      	movl	$0x4, %eax
    db93:      	callq	*%rax
    db95:      	movq	%rbx, 0x48(%rsp)
    db9a:      	cmpl	%r15d, %r12d
    db9d:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    dba3:      	movq	0x8(%rsp), %r12
    dba8:      	movq	%r12, 0x30(%rsp)
    dbad:      	movq	0x38(%rsp), %rdx
    dbb2:      	movq	0x40(%rsp), %r15
    dbb7:      	jmp	0xdc0a <generic_fentry_path+0x374a>
    dbb9:      	leaq	0x10(%r15), %rdx
    dbbd:      	movl	$0x4, %eax
    dbc2:      	movq	%rbp, %rdi
    dbc5:      	movl	$0x8, %esi
    dbca:      	callq	*%rax
    dbcc:      	movq	0x40(%rsp), %rax
    dbd1:      	cmpq	(%rsp), %rax
    dbd5:      	je	0x15f2d <generic_fentry_path+0xba6d>
    dbdb:      	addq	$0x18, %r15
    dbdf:      	movl	$0x4, %eax
    dbe4:      	leaq	0x30(%rsp), %rdi
    dbe9:      	movl	$0x8, %esi
    dbee:      	movq	%r15, %rdx
    dbf1:      	callq	*%rax
    dbf3:      	movq	(%rsp), %r15
    dbf7:      	movq	%r15, 0x40(%rsp)
    dbfc:      	leaq	0x20(%r15), %rdx
    dc00:      	movq	%rdx, 0x38(%rsp)
    dc05:      	movq	0x30(%rsp), %r12
    dc0a:      	cmpq	0x18(%rsp), %r12
    dc0f:      	jne	0xdc1c <generic_fentry_path+0x375c>
    dc11:      	cmpq	0x20(%rsp), %rdx
    dc16:      	je	0x15f2d <generic_fentry_path+0xba6d>
    dc1c:      	movl	$0x4, %eax
    dc21:      	leaq	0x10(%rsp), %rdi
    dc26:      	movl	$0x8, %esi
    dc2b:      	callq	*%rax
    dc2d:      	cmpq	0x10(%rsp), %r12
    dc32:      	je	0xdd2a <generic_fentry_path+0x386a>
    dc38:      	leaq	0x18(%r12), %rbx
    dc3d:      	movl	$0x4, %eax
    dc42:      	movq	%rbp, %rdi
    dc45:      	movl	$0x8, %esi
    dc4a:      	movq	%rbx, %rdx
    dc4d:      	callq	*%rax
    dc4f:      	cmpq	%r12, (%rsp)
    dc53:      	je	0xdd2a <generic_fentry_path+0x386a>
    dc59:      	movl	$0x4, %eax
    dc5e:      	leaq	0x8(%rsp), %rdi
    dc63:      	movl	$0x8, %esi
    dc68:      	movq	%rbx, %rdx
    dc6b:      	callq	*%rax
    dc6d:      	addq	$0x20, %r12
    dc71:      	movl	$0x4, %eax
    dc76:      	leaq	0x58(%rsp), %rdi
    dc7b:      	movl	$0x10, %ecx
    dc80:      	movl	$0x10, %esi
    dc85:      	movq	%r12, %rdx
    dc88:      	callq	*%rax
    dc8a:      	movq	0x28(%rsp), %rbx
    dc8f:      	movq	0x48(%rsp), %rax
    dc94:      	movl	0x5c(%rsp), %r15d
    dc99:      	subq	%rbx, %rax
    dc9c:      	movl	0x50(%rsp), %r12d
    dca1:      	movl	%r15d, %edx
    dca4:      	subl	%r12d, %edx
    dca7:      	movl	$0x0, %ecx
    dcac:      	cmovbl	%ecx, %edx
    dcaf:      	addq	0x60(%rsp), %rdx
    dcb4:      	xorl	%esi, %esi
    dcb6:      	cmpl	%r15d, %r12d
    dcb9:      	seta	%sil
    dcbd:      	movl	%r15d, %ecx
    dcc0:      	cmovbl	%r12d, %ecx
    dcc4:      	addl	%ecx, %esi
    dcc6:      	movl	%r12d, %edi
    dcc9:      	subl	%esi, %edi
    dccb:      	movl	%edi, 0x50(%rsp)
    dccf:      	subq	%rsi, %rax
    dcd2:      	jb	0x15f32 <generic_fentry_path+0xba72>
    dcd8:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    dcde:      	ja	0x15f32 <generic_fentry_path+0xba72>
    dce4:      	cmpl	%r15d, %r12d
    dce7:      	jbe	0xdced <generic_fentry_path+0x382d>
    dce9:      	movb	$0x2f, (%rbx,%rax)
    dced:      	xorl	%edi, %edi
    dcef:      	cmpl	%r15d, %r12d
    dcf2:      	seta	%dil
    dcf6:      	movzbl	%cl, %esi
    dcf9:      	addq	%rax, %rbx
    dcfc:      	addq	%rbx, %rdi
    dcff:      	movl	$0x4, %eax
    dd04:      	callq	*%rax
    dd06:      	movq	%rbx, 0x48(%rsp)
    dd0b:      	cmpl	%r15d, %r12d
    dd0e:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    dd14:      	movq	0x8(%rsp), %r12
    dd19:      	movq	%r12, 0x30(%rsp)
    dd1e:      	movq	0x38(%rsp), %rdx
    dd23:      	movq	0x40(%rsp), %r15
    dd28:      	jmp	0xdd7b <generic_fentry_path+0x38bb>
    dd2a:      	leaq	0x10(%r15), %rdx
    dd2e:      	movl	$0x4, %eax
    dd33:      	movq	%rbp, %rdi
    dd36:      	movl	$0x8, %esi
    dd3b:      	callq	*%rax
    dd3d:      	movq	0x40(%rsp), %rax
    dd42:      	cmpq	(%rsp), %rax
    dd46:      	je	0x15f2d <generic_fentry_path+0xba6d>
    dd4c:      	addq	$0x18, %r15
    dd50:      	movl	$0x4, %eax
    dd55:      	leaq	0x30(%rsp), %rdi
    dd5a:      	movl	$0x8, %esi
    dd5f:      	movq	%r15, %rdx
    dd62:      	callq	*%rax
    dd64:      	movq	(%rsp), %r15
    dd68:      	movq	%r15, 0x40(%rsp)
    dd6d:      	leaq	0x20(%r15), %rdx
    dd71:      	movq	%rdx, 0x38(%rsp)
    dd76:      	movq	0x30(%rsp), %r12
    dd7b:      	cmpq	0x18(%rsp), %r12
    dd80:      	jne	0xdd8d <generic_fentry_path+0x38cd>
    dd82:      	cmpq	0x20(%rsp), %rdx
    dd87:      	je	0x15f2d <generic_fentry_path+0xba6d>
    dd8d:      	movl	$0x4, %eax
    dd92:      	leaq	0x10(%rsp), %rdi
    dd97:      	movl	$0x8, %esi
    dd9c:      	callq	*%rax
    dd9e:      	cmpq	0x10(%rsp), %r12
    dda3:      	je	0xde9b <generic_fentry_path+0x39db>
    dda9:      	leaq	0x18(%r12), %rbx
    ddae:      	movl	$0x4, %eax
    ddb3:      	movq	%rbp, %rdi
    ddb6:      	movl	$0x8, %esi
    ddbb:      	movq	%rbx, %rdx
    ddbe:      	callq	*%rax
    ddc0:      	cmpq	%r12, (%rsp)
    ddc4:      	je	0xde9b <generic_fentry_path+0x39db>
    ddca:      	movl	$0x4, %eax
    ddcf:      	leaq	0x8(%rsp), %rdi
    ddd4:      	movl	$0x8, %esi
    ddd9:      	movq	%rbx, %rdx
    dddc:      	callq	*%rax
    ddde:      	addq	$0x20, %r12
    dde2:      	movl	$0x4, %eax
    dde7:      	leaq	0x58(%rsp), %rdi
    ddec:      	movl	$0x10, %ecx
    ddf1:      	movl	$0x10, %esi
    ddf6:      	movq	%r12, %rdx
    ddf9:      	callq	*%rax
    ddfb:      	movq	0x28(%rsp), %rbx
    de00:      	movq	0x48(%rsp), %rax
    de05:      	movl	0x5c(%rsp), %r15d
    de0a:      	subq	%rbx, %rax
    de0d:      	movl	0x50(%rsp), %r12d
    de12:      	movl	%r15d, %edx
    de15:      	subl	%r12d, %edx
    de18:      	movl	$0x0, %ecx
    de1d:      	cmovbl	%ecx, %edx
    de20:      	addq	0x60(%rsp), %rdx
    de25:      	xorl	%esi, %esi
    de27:      	cmpl	%r15d, %r12d
    de2a:      	seta	%sil
    de2e:      	movl	%r15d, %ecx
    de31:      	cmovbl	%r12d, %ecx
    de35:      	addl	%ecx, %esi
    de37:      	movl	%r12d, %edi
    de3a:      	subl	%esi, %edi
    de3c:      	movl	%edi, 0x50(%rsp)
    de40:      	subq	%rsi, %rax
    de43:      	jb	0x15f32 <generic_fentry_path+0xba72>
    de49:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    de4f:      	ja	0x15f32 <generic_fentry_path+0xba72>
    de55:      	cmpl	%r15d, %r12d
    de58:      	jbe	0xde5e <generic_fentry_path+0x399e>
    de5a:      	movb	$0x2f, (%rbx,%rax)
    de5e:      	xorl	%edi, %edi
    de60:      	cmpl	%r15d, %r12d
    de63:      	seta	%dil
    de67:      	movzbl	%cl, %esi
    de6a:      	addq	%rax, %rbx
    de6d:      	addq	%rbx, %rdi
    de70:      	movl	$0x4, %eax
    de75:      	callq	*%rax
    de77:      	movq	%rbx, 0x48(%rsp)
    de7c:      	cmpl	%r15d, %r12d
    de7f:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    de85:      	movq	0x8(%rsp), %r12
    de8a:      	movq	%r12, 0x30(%rsp)
    de8f:      	movq	0x38(%rsp), %rdx
    de94:      	movq	0x40(%rsp), %r15
    de99:      	jmp	0xdeec <generic_fentry_path+0x3a2c>
    de9b:      	leaq	0x10(%r15), %rdx
    de9f:      	movl	$0x4, %eax
    dea4:      	movq	%rbp, %rdi
    dea7:      	movl	$0x8, %esi
    deac:      	callq	*%rax
    deae:      	movq	0x40(%rsp), %rax
    deb3:      	cmpq	(%rsp), %rax
    deb7:      	je	0x15f2d <generic_fentry_path+0xba6d>
    debd:      	addq	$0x18, %r15
    dec1:      	movl	$0x4, %eax
    dec6:      	leaq	0x30(%rsp), %rdi
    decb:      	movl	$0x8, %esi
    ded0:      	movq	%r15, %rdx
    ded3:      	callq	*%rax
    ded5:      	movq	(%rsp), %r15
    ded9:      	movq	%r15, 0x40(%rsp)
    dede:      	leaq	0x20(%r15), %rdx
    dee2:      	movq	%rdx, 0x38(%rsp)
    dee7:      	movq	0x30(%rsp), %r12
    deec:      	cmpq	0x18(%rsp), %r12
    def1:      	jne	0xdefe <generic_fentry_path+0x3a3e>
    def3:      	cmpq	0x20(%rsp), %rdx
    def8:      	je	0x15f2d <generic_fentry_path+0xba6d>
    defe:      	movl	$0x4, %eax
    df03:      	leaq	0x10(%rsp), %rdi
    df08:      	movl	$0x8, %esi
    df0d:      	callq	*%rax
    df0f:      	cmpq	0x10(%rsp), %r12
    df14:      	je	0xe00c <generic_fentry_path+0x3b4c>
    df1a:      	leaq	0x18(%r12), %rbx
    df1f:      	movl	$0x4, %eax
    df24:      	movq	%rbp, %rdi
    df27:      	movl	$0x8, %esi
    df2c:      	movq	%rbx, %rdx
    df2f:      	callq	*%rax
    df31:      	cmpq	%r12, (%rsp)
    df35:      	je	0xe00c <generic_fentry_path+0x3b4c>
    df3b:      	movl	$0x4, %eax
    df40:      	leaq	0x8(%rsp), %rdi
    df45:      	movl	$0x8, %esi
    df4a:      	movq	%rbx, %rdx
    df4d:      	callq	*%rax
    df4f:      	addq	$0x20, %r12
    df53:      	movl	$0x4, %eax
    df58:      	leaq	0x58(%rsp), %rdi
    df5d:      	movl	$0x10, %ecx
    df62:      	movl	$0x10, %esi
    df67:      	movq	%r12, %rdx
    df6a:      	callq	*%rax
    df6c:      	movq	0x28(%rsp), %rbx
    df71:      	movq	0x48(%rsp), %rax
    df76:      	movl	0x5c(%rsp), %r15d
    df7b:      	subq	%rbx, %rax
    df7e:      	movl	0x50(%rsp), %r12d
    df83:      	movl	%r15d, %edx
    df86:      	subl	%r12d, %edx
    df89:      	movl	$0x0, %ecx
    df8e:      	cmovbl	%ecx, %edx
    df91:      	addq	0x60(%rsp), %rdx
    df96:      	xorl	%esi, %esi
    df98:      	cmpl	%r15d, %r12d
    df9b:      	seta	%sil
    df9f:      	movl	%r15d, %ecx
    dfa2:      	cmovbl	%r12d, %ecx
    dfa6:      	addl	%ecx, %esi
    dfa8:      	movl	%r12d, %edi
    dfab:      	subl	%esi, %edi
    dfad:      	movl	%edi, 0x50(%rsp)
    dfb1:      	subq	%rsi, %rax
    dfb4:      	jb	0x15f32 <generic_fentry_path+0xba72>
    dfba:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    dfc0:      	ja	0x15f32 <generic_fentry_path+0xba72>
    dfc6:      	cmpl	%r15d, %r12d
    dfc9:      	jbe	0xdfcf <generic_fentry_path+0x3b0f>
    dfcb:      	movb	$0x2f, (%rbx,%rax)
    dfcf:      	xorl	%edi, %edi
    dfd1:      	cmpl	%r15d, %r12d
    dfd4:      	seta	%dil
    dfd8:      	movzbl	%cl, %esi
    dfdb:      	addq	%rax, %rbx
    dfde:      	addq	%rbx, %rdi
    dfe1:      	movl	$0x4, %eax
    dfe6:      	callq	*%rax
    dfe8:      	movq	%rbx, 0x48(%rsp)
    dfed:      	cmpl	%r15d, %r12d
    dff0:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    dff6:      	movq	0x8(%rsp), %r12
    dffb:      	movq	%r12, 0x30(%rsp)
    e000:      	movq	0x38(%rsp), %rdx
    e005:      	movq	0x40(%rsp), %r15
    e00a:      	jmp	0xe05d <generic_fentry_path+0x3b9d>
    e00c:      	leaq	0x10(%r15), %rdx
    e010:      	movl	$0x4, %eax
    e015:      	movq	%rbp, %rdi
    e018:      	movl	$0x8, %esi
    e01d:      	callq	*%rax
    e01f:      	movq	0x40(%rsp), %rax
    e024:      	cmpq	(%rsp), %rax
    e028:      	je	0x15f2d <generic_fentry_path+0xba6d>
    e02e:      	addq	$0x18, %r15
    e032:      	movl	$0x4, %eax
    e037:      	leaq	0x30(%rsp), %rdi
    e03c:      	movl	$0x8, %esi
    e041:      	movq	%r15, %rdx
    e044:      	callq	*%rax
    e046:      	movq	(%rsp), %r15
    e04a:      	movq	%r15, 0x40(%rsp)
    e04f:      	leaq	0x20(%r15), %rdx
    e053:      	movq	%rdx, 0x38(%rsp)
    e058:      	movq	0x30(%rsp), %r12
    e05d:      	cmpq	0x18(%rsp), %r12
    e062:      	jne	0xe06f <generic_fentry_path+0x3baf>
    e064:      	cmpq	0x20(%rsp), %rdx
    e069:      	je	0x15f2d <generic_fentry_path+0xba6d>
    e06f:      	movl	$0x4, %eax
    e074:      	leaq	0x10(%rsp), %rdi
    e079:      	movl	$0x8, %esi
    e07e:      	callq	*%rax
    e080:      	cmpq	0x10(%rsp), %r12
    e085:      	je	0xe17d <generic_fentry_path+0x3cbd>
    e08b:      	leaq	0x18(%r12), %rbx
    e090:      	movl	$0x4, %eax
    e095:      	movq	%rbp, %rdi
    e098:      	movl	$0x8, %esi
    e09d:      	movq	%rbx, %rdx
    e0a0:      	callq	*%rax
    e0a2:      	cmpq	%r12, (%rsp)
    e0a6:      	je	0xe17d <generic_fentry_path+0x3cbd>
    e0ac:      	movl	$0x4, %eax
    e0b1:      	leaq	0x8(%rsp), %rdi
    e0b6:      	movl	$0x8, %esi
    e0bb:      	movq	%rbx, %rdx
    e0be:      	callq	*%rax
    e0c0:      	addq	$0x20, %r12
    e0c4:      	movl	$0x4, %eax
    e0c9:      	leaq	0x58(%rsp), %rdi
    e0ce:      	movl	$0x10, %ecx
    e0d3:      	movl	$0x10, %esi
    e0d8:      	movq	%r12, %rdx
    e0db:      	callq	*%rax
    e0dd:      	movq	0x28(%rsp), %rbx
    e0e2:      	movq	0x48(%rsp), %rax
    e0e7:      	movl	0x5c(%rsp), %r15d
    e0ec:      	subq	%rbx, %rax
    e0ef:      	movl	0x50(%rsp), %r12d
    e0f4:      	movl	%r15d, %edx
    e0f7:      	subl	%r12d, %edx
    e0fa:      	movl	$0x0, %ecx
    e0ff:      	cmovbl	%ecx, %edx
    e102:      	addq	0x60(%rsp), %rdx
    e107:      	xorl	%esi, %esi
    e109:      	cmpl	%r15d, %r12d
    e10c:      	seta	%sil
    e110:      	movl	%r15d, %ecx
    e113:      	cmovbl	%r12d, %ecx
    e117:      	addl	%ecx, %esi
    e119:      	movl	%r12d, %edi
    e11c:      	subl	%esi, %edi
    e11e:      	movl	%edi, 0x50(%rsp)
    e122:      	subq	%rsi, %rax
    e125:      	jb	0x15f32 <generic_fentry_path+0xba72>
    e12b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e131:      	ja	0x15f32 <generic_fentry_path+0xba72>
    e137:      	cmpl	%r15d, %r12d
    e13a:      	jbe	0xe140 <generic_fentry_path+0x3c80>
    e13c:      	movb	$0x2f, (%rbx,%rax)
    e140:      	xorl	%edi, %edi
    e142:      	cmpl	%r15d, %r12d
    e145:      	seta	%dil
    e149:      	movzbl	%cl, %esi
    e14c:      	addq	%rax, %rbx
    e14f:      	addq	%rbx, %rdi
    e152:      	movl	$0x4, %eax
    e157:      	callq	*%rax
    e159:      	movq	%rbx, 0x48(%rsp)
    e15e:      	cmpl	%r15d, %r12d
    e161:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    e167:      	movq	0x8(%rsp), %r12
    e16c:      	movq	%r12, 0x30(%rsp)
    e171:      	movq	0x38(%rsp), %rdx
    e176:      	movq	0x40(%rsp), %r15
    e17b:      	jmp	0xe1ce <generic_fentry_path+0x3d0e>
    e17d:      	leaq	0x10(%r15), %rdx
    e181:      	movl	$0x4, %eax
    e186:      	movq	%rbp, %rdi
    e189:      	movl	$0x8, %esi
    e18e:      	callq	*%rax
    e190:      	movq	0x40(%rsp), %rax
    e195:      	cmpq	(%rsp), %rax
    e199:      	je	0x15f2d <generic_fentry_path+0xba6d>
    e19f:      	addq	$0x18, %r15
    e1a3:      	movl	$0x4, %eax
    e1a8:      	leaq	0x30(%rsp), %rdi
    e1ad:      	movl	$0x8, %esi
    e1b2:      	movq	%r15, %rdx
    e1b5:      	callq	*%rax
    e1b7:      	movq	(%rsp), %r15
    e1bb:      	movq	%r15, 0x40(%rsp)
    e1c0:      	leaq	0x20(%r15), %rdx
    e1c4:      	movq	%rdx, 0x38(%rsp)
    e1c9:      	movq	0x30(%rsp), %r12
    e1ce:      	cmpq	0x18(%rsp), %r12
    e1d3:      	jne	0xe1e0 <generic_fentry_path+0x3d20>
    e1d5:      	cmpq	0x20(%rsp), %rdx
    e1da:      	je	0x15f2d <generic_fentry_path+0xba6d>
    e1e0:      	movl	$0x4, %eax
    e1e5:      	leaq	0x10(%rsp), %rdi
    e1ea:      	movl	$0x8, %esi
    e1ef:      	callq	*%rax
    e1f1:      	cmpq	0x10(%rsp), %r12
    e1f6:      	je	0xe2ee <generic_fentry_path+0x3e2e>
    e1fc:      	leaq	0x18(%r12), %rbx
    e201:      	movl	$0x4, %eax
    e206:      	movq	%rbp, %rdi
    e209:      	movl	$0x8, %esi
    e20e:      	movq	%rbx, %rdx
    e211:      	callq	*%rax
    e213:      	cmpq	%r12, (%rsp)
    e217:      	je	0xe2ee <generic_fentry_path+0x3e2e>
    e21d:      	movl	$0x4, %eax
    e222:      	leaq	0x8(%rsp), %rdi
    e227:      	movl	$0x8, %esi
    e22c:      	movq	%rbx, %rdx
    e22f:      	callq	*%rax
    e231:      	addq	$0x20, %r12
    e235:      	movl	$0x4, %eax
    e23a:      	leaq	0x58(%rsp), %rdi
    e23f:      	movl	$0x10, %ecx
    e244:      	movl	$0x10, %esi
    e249:      	movq	%r12, %rdx
    e24c:      	callq	*%rax
    e24e:      	movq	0x28(%rsp), %rbx
    e253:      	movq	0x48(%rsp), %rax
    e258:      	movl	0x5c(%rsp), %r15d
    e25d:      	subq	%rbx, %rax
    e260:      	movl	0x50(%rsp), %r12d
    e265:      	movl	%r15d, %edx
    e268:      	subl	%r12d, %edx
    e26b:      	movl	$0x0, %ecx
    e270:      	cmovbl	%ecx, %edx
    e273:      	addq	0x60(%rsp), %rdx
    e278:      	xorl	%esi, %esi
    e27a:      	cmpl	%r15d, %r12d
    e27d:      	seta	%sil
    e281:      	movl	%r15d, %ecx
    e284:      	cmovbl	%r12d, %ecx
    e288:      	addl	%ecx, %esi
    e28a:      	movl	%r12d, %edi
    e28d:      	subl	%esi, %edi
    e28f:      	movl	%edi, 0x50(%rsp)
    e293:      	subq	%rsi, %rax
    e296:      	jb	0x15f32 <generic_fentry_path+0xba72>
    e29c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e2a2:      	ja	0x15f32 <generic_fentry_path+0xba72>
    e2a8:      	cmpl	%r15d, %r12d
    e2ab:      	jbe	0xe2b1 <generic_fentry_path+0x3df1>
    e2ad:      	movb	$0x2f, (%rbx,%rax)
    e2b1:      	xorl	%edi, %edi
    e2b3:      	cmpl	%r15d, %r12d
    e2b6:      	seta	%dil
    e2ba:      	movzbl	%cl, %esi
    e2bd:      	addq	%rax, %rbx
    e2c0:      	addq	%rbx, %rdi
    e2c3:      	movl	$0x4, %eax
    e2c8:      	callq	*%rax
    e2ca:      	movq	%rbx, 0x48(%rsp)
    e2cf:      	cmpl	%r15d, %r12d
    e2d2:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    e2d8:      	movq	0x8(%rsp), %r12
    e2dd:      	movq	%r12, 0x30(%rsp)
    e2e2:      	movq	0x38(%rsp), %rdx
    e2e7:      	movq	0x40(%rsp), %r15
    e2ec:      	jmp	0xe33f <generic_fentry_path+0x3e7f>
    e2ee:      	leaq	0x10(%r15), %rdx
    e2f2:      	movl	$0x4, %eax
    e2f7:      	movq	%rbp, %rdi
    e2fa:      	movl	$0x8, %esi
    e2ff:      	callq	*%rax
    e301:      	movq	0x40(%rsp), %rax
    e306:      	cmpq	(%rsp), %rax
    e30a:      	je	0x15f2d <generic_fentry_path+0xba6d>
    e310:      	addq	$0x18, %r15
    e314:      	movl	$0x4, %eax
    e319:      	leaq	0x30(%rsp), %rdi
    e31e:      	movl	$0x8, %esi
    e323:      	movq	%r15, %rdx
    e326:      	callq	*%rax
    e328:      	movq	(%rsp), %r15
    e32c:      	movq	%r15, 0x40(%rsp)
    e331:      	leaq	0x20(%r15), %rdx
    e335:      	movq	%rdx, 0x38(%rsp)
    e33a:      	movq	0x30(%rsp), %r12
    e33f:      	cmpq	0x18(%rsp), %r12
    e344:      	jne	0xe351 <generic_fentry_path+0x3e91>
    e346:      	cmpq	0x20(%rsp), %rdx
    e34b:      	je	0x15f2d <generic_fentry_path+0xba6d>
    e351:      	movl	$0x4, %eax
    e356:      	leaq	0x10(%rsp), %rdi
    e35b:      	movl	$0x8, %esi
    e360:      	callq	*%rax
    e362:      	cmpq	0x10(%rsp), %r12
    e367:      	je	0xe45f <generic_fentry_path+0x3f9f>
    e36d:      	leaq	0x18(%r12), %rbx
    e372:      	movl	$0x4, %eax
    e377:      	movq	%rbp, %rdi
    e37a:      	movl	$0x8, %esi
    e37f:      	movq	%rbx, %rdx
    e382:      	callq	*%rax
    e384:      	cmpq	%r12, (%rsp)
    e388:      	je	0xe45f <generic_fentry_path+0x3f9f>
    e38e:      	movl	$0x4, %eax
    e393:      	leaq	0x8(%rsp), %rdi
    e398:      	movl	$0x8, %esi
    e39d:      	movq	%rbx, %rdx
    e3a0:      	callq	*%rax
    e3a2:      	addq	$0x20, %r12
    e3a6:      	movl	$0x4, %eax
    e3ab:      	leaq	0x58(%rsp), %rdi
    e3b0:      	movl	$0x10, %ecx
    e3b5:      	movl	$0x10, %esi
    e3ba:      	movq	%r12, %rdx
    e3bd:      	callq	*%rax
    e3bf:      	movq	0x28(%rsp), %rbx
    e3c4:      	movq	0x48(%rsp), %rax
    e3c9:      	movl	0x5c(%rsp), %r15d
    e3ce:      	subq	%rbx, %rax
    e3d1:      	movl	0x50(%rsp), %r12d
    e3d6:      	movl	%r15d, %edx
    e3d9:      	subl	%r12d, %edx
    e3dc:      	movl	$0x0, %ecx
    e3e1:      	cmovbl	%ecx, %edx
    e3e4:      	addq	0x60(%rsp), %rdx
    e3e9:      	xorl	%esi, %esi
    e3eb:      	cmpl	%r15d, %r12d
    e3ee:      	seta	%sil
    e3f2:      	movl	%r15d, %ecx
    e3f5:      	cmovbl	%r12d, %ecx
    e3f9:      	addl	%ecx, %esi
    e3fb:      	movl	%r12d, %edi
    e3fe:      	subl	%esi, %edi
    e400:      	movl	%edi, 0x50(%rsp)
    e404:      	subq	%rsi, %rax
    e407:      	jb	0x15f32 <generic_fentry_path+0xba72>
    e40d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e413:      	ja	0x15f32 <generic_fentry_path+0xba72>
    e419:      	cmpl	%r15d, %r12d
    e41c:      	jbe	0xe422 <generic_fentry_path+0x3f62>
    e41e:      	movb	$0x2f, (%rbx,%rax)
    e422:      	xorl	%edi, %edi
    e424:      	cmpl	%r15d, %r12d
    e427:      	seta	%dil
    e42b:      	movzbl	%cl, %esi
    e42e:      	addq	%rax, %rbx
    e431:      	addq	%rbx, %rdi
    e434:      	movl	$0x4, %eax
    e439:      	callq	*%rax
    e43b:      	movq	%rbx, 0x48(%rsp)
    e440:      	cmpl	%r15d, %r12d
    e443:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    e449:      	movq	0x8(%rsp), %r12
    e44e:      	movq	%r12, 0x30(%rsp)
    e453:      	movq	0x38(%rsp), %rdx
    e458:      	movq	0x40(%rsp), %r15
    e45d:      	jmp	0xe4b0 <generic_fentry_path+0x3ff0>
    e45f:      	leaq	0x10(%r15), %rdx
    e463:      	movl	$0x4, %eax
    e468:      	movq	%rbp, %rdi
    e46b:      	movl	$0x8, %esi
    e470:      	callq	*%rax
    e472:      	movq	0x40(%rsp), %rax
    e477:      	cmpq	(%rsp), %rax
    e47b:      	je	0x15f2d <generic_fentry_path+0xba6d>
    e481:      	addq	$0x18, %r15
    e485:      	movl	$0x4, %eax
    e48a:      	leaq	0x30(%rsp), %rdi
    e48f:      	movl	$0x8, %esi
    e494:      	movq	%r15, %rdx
    e497:      	callq	*%rax
    e499:      	movq	(%rsp), %r15
    e49d:      	movq	%r15, 0x40(%rsp)
    e4a2:      	leaq	0x20(%r15), %rdx
    e4a6:      	movq	%rdx, 0x38(%rsp)
    e4ab:      	movq	0x30(%rsp), %r12
    e4b0:      	cmpq	0x18(%rsp), %r12
    e4b5:      	jne	0xe4c2 <generic_fentry_path+0x4002>
    e4b7:      	cmpq	0x20(%rsp), %rdx
    e4bc:      	je	0x15f2d <generic_fentry_path+0xba6d>
    e4c2:      	movl	$0x4, %eax
    e4c7:      	leaq	0x10(%rsp), %rdi
    e4cc:      	movl	$0x8, %esi
    e4d1:      	callq	*%rax
    e4d3:      	cmpq	0x10(%rsp), %r12
    e4d8:      	je	0xe5d0 <generic_fentry_path+0x4110>
    e4de:      	leaq	0x18(%r12), %rbx
    e4e3:      	movl	$0x4, %eax
    e4e8:      	movq	%rbp, %rdi
    e4eb:      	movl	$0x8, %esi
    e4f0:      	movq	%rbx, %rdx
    e4f3:      	callq	*%rax
    e4f5:      	cmpq	%r12, (%rsp)
    e4f9:      	je	0xe5d0 <generic_fentry_path+0x4110>
    e4ff:      	movl	$0x4, %eax
    e504:      	leaq	0x8(%rsp), %rdi
    e509:      	movl	$0x8, %esi
    e50e:      	movq	%rbx, %rdx
    e511:      	callq	*%rax
    e513:      	addq	$0x20, %r12
    e517:      	movl	$0x4, %eax
    e51c:      	leaq	0x58(%rsp), %rdi
    e521:      	movl	$0x10, %ecx
    e526:      	movl	$0x10, %esi
    e52b:      	movq	%r12, %rdx
    e52e:      	callq	*%rax
    e530:      	movq	0x28(%rsp), %rbx
    e535:      	movq	0x48(%rsp), %rax
    e53a:      	movl	0x5c(%rsp), %r15d
    e53f:      	subq	%rbx, %rax
    e542:      	movl	0x50(%rsp), %r12d
    e547:      	movl	%r15d, %edx
    e54a:      	subl	%r12d, %edx
    e54d:      	movl	$0x0, %ecx
    e552:      	cmovbl	%ecx, %edx
    e555:      	addq	0x60(%rsp), %rdx
    e55a:      	xorl	%esi, %esi
    e55c:      	cmpl	%r15d, %r12d
    e55f:      	seta	%sil
    e563:      	movl	%r15d, %ecx
    e566:      	cmovbl	%r12d, %ecx
    e56a:      	addl	%ecx, %esi
    e56c:      	movl	%r12d, %edi
    e56f:      	subl	%esi, %edi
    e571:      	movl	%edi, 0x50(%rsp)
    e575:      	subq	%rsi, %rax
    e578:      	jb	0x15f32 <generic_fentry_path+0xba72>
    e57e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e584:      	ja	0x15f32 <generic_fentry_path+0xba72>
    e58a:      	cmpl	%r15d, %r12d
    e58d:      	jbe	0xe593 <generic_fentry_path+0x40d3>
    e58f:      	movb	$0x2f, (%rbx,%rax)
    e593:      	xorl	%edi, %edi
    e595:      	cmpl	%r15d, %r12d
    e598:      	seta	%dil
    e59c:      	movzbl	%cl, %esi
    e59f:      	addq	%rax, %rbx
    e5a2:      	addq	%rbx, %rdi
    e5a5:      	movl	$0x4, %eax
    e5aa:      	callq	*%rax
    e5ac:      	movq	%rbx, 0x48(%rsp)
    e5b1:      	cmpl	%r15d, %r12d
    e5b4:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    e5ba:      	movq	0x8(%rsp), %r12
    e5bf:      	movq	%r12, 0x30(%rsp)
    e5c4:      	movq	0x38(%rsp), %rdx
    e5c9:      	movq	0x40(%rsp), %r15
    e5ce:      	jmp	0xe621 <generic_fentry_path+0x4161>
    e5d0:      	leaq	0x10(%r15), %rdx
    e5d4:      	movl	$0x4, %eax
    e5d9:      	movq	%rbp, %rdi
    e5dc:      	movl	$0x8, %esi
    e5e1:      	callq	*%rax
    e5e3:      	movq	0x40(%rsp), %rax
    e5e8:      	cmpq	(%rsp), %rax
    e5ec:      	je	0x15f2d <generic_fentry_path+0xba6d>
    e5f2:      	addq	$0x18, %r15
    e5f6:      	movl	$0x4, %eax
    e5fb:      	leaq	0x30(%rsp), %rdi
    e600:      	movl	$0x8, %esi
    e605:      	movq	%r15, %rdx
    e608:      	callq	*%rax
    e60a:      	movq	(%rsp), %r15
    e60e:      	movq	%r15, 0x40(%rsp)
    e613:      	leaq	0x20(%r15), %rdx
    e617:      	movq	%rdx, 0x38(%rsp)
    e61c:      	movq	0x30(%rsp), %r12
    e621:      	cmpq	0x18(%rsp), %r12
    e626:      	jne	0xe633 <generic_fentry_path+0x4173>
    e628:      	cmpq	0x20(%rsp), %rdx
    e62d:      	je	0x15f2d <generic_fentry_path+0xba6d>
    e633:      	movl	$0x4, %eax
    e638:      	leaq	0x10(%rsp), %rdi
    e63d:      	movl	$0x8, %esi
    e642:      	callq	*%rax
    e644:      	cmpq	0x10(%rsp), %r12
    e649:      	je	0xe741 <generic_fentry_path+0x4281>
    e64f:      	leaq	0x18(%r12), %rbx
    e654:      	movl	$0x4, %eax
    e659:      	movq	%rbp, %rdi
    e65c:      	movl	$0x8, %esi
    e661:      	movq	%rbx, %rdx
    e664:      	callq	*%rax
    e666:      	cmpq	%r12, (%rsp)
    e66a:      	je	0xe741 <generic_fentry_path+0x4281>
    e670:      	movl	$0x4, %eax
    e675:      	leaq	0x8(%rsp), %rdi
    e67a:      	movl	$0x8, %esi
    e67f:      	movq	%rbx, %rdx
    e682:      	callq	*%rax
    e684:      	addq	$0x20, %r12
    e688:      	movl	$0x4, %eax
    e68d:      	leaq	0x58(%rsp), %rdi
    e692:      	movl	$0x10, %ecx
    e697:      	movl	$0x10, %esi
    e69c:      	movq	%r12, %rdx
    e69f:      	callq	*%rax
    e6a1:      	movq	0x28(%rsp), %rbx
    e6a6:      	movq	0x48(%rsp), %rax
    e6ab:      	movl	0x5c(%rsp), %r15d
    e6b0:      	subq	%rbx, %rax
    e6b3:      	movl	0x50(%rsp), %r12d
    e6b8:      	movl	%r15d, %edx
    e6bb:      	subl	%r12d, %edx
    e6be:      	movl	$0x0, %ecx
    e6c3:      	cmovbl	%ecx, %edx
    e6c6:      	addq	0x60(%rsp), %rdx
    e6cb:      	xorl	%esi, %esi
    e6cd:      	cmpl	%r15d, %r12d
    e6d0:      	seta	%sil
    e6d4:      	movl	%r15d, %ecx
    e6d7:      	cmovbl	%r12d, %ecx
    e6db:      	addl	%ecx, %esi
    e6dd:      	movl	%r12d, %edi
    e6e0:      	subl	%esi, %edi
    e6e2:      	movl	%edi, 0x50(%rsp)
    e6e6:      	subq	%rsi, %rax
    e6e9:      	jb	0x15f32 <generic_fentry_path+0xba72>
    e6ef:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e6f5:      	ja	0x15f32 <generic_fentry_path+0xba72>
    e6fb:      	cmpl	%r15d, %r12d
    e6fe:      	jbe	0xe704 <generic_fentry_path+0x4244>
    e700:      	movb	$0x2f, (%rbx,%rax)
    e704:      	xorl	%edi, %edi
    e706:      	cmpl	%r15d, %r12d
    e709:      	seta	%dil
    e70d:      	movzbl	%cl, %esi
    e710:      	addq	%rax, %rbx
    e713:      	addq	%rbx, %rdi
    e716:      	movl	$0x4, %eax
    e71b:      	callq	*%rax
    e71d:      	movq	%rbx, 0x48(%rsp)
    e722:      	cmpl	%r15d, %r12d
    e725:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    e72b:      	movq	0x8(%rsp), %r12
    e730:      	movq	%r12, 0x30(%rsp)
    e735:      	movq	0x38(%rsp), %rdx
    e73a:      	movq	0x40(%rsp), %r15
    e73f:      	jmp	0xe792 <generic_fentry_path+0x42d2>
    e741:      	leaq	0x10(%r15), %rdx
    e745:      	movl	$0x4, %eax
    e74a:      	movq	%rbp, %rdi
    e74d:      	movl	$0x8, %esi
    e752:      	callq	*%rax
    e754:      	movq	0x40(%rsp), %rax
    e759:      	cmpq	(%rsp), %rax
    e75d:      	je	0x15f2d <generic_fentry_path+0xba6d>
    e763:      	addq	$0x18, %r15
    e767:      	movl	$0x4, %eax
    e76c:      	leaq	0x30(%rsp), %rdi
    e771:      	movl	$0x8, %esi
    e776:      	movq	%r15, %rdx
    e779:      	callq	*%rax
    e77b:      	movq	(%rsp), %r15
    e77f:      	movq	%r15, 0x40(%rsp)
    e784:      	leaq	0x20(%r15), %rdx
    e788:      	movq	%rdx, 0x38(%rsp)
    e78d:      	movq	0x30(%rsp), %r12
    e792:      	cmpq	0x18(%rsp), %r12
    e797:      	jne	0xe7a4 <generic_fentry_path+0x42e4>
    e799:      	cmpq	0x20(%rsp), %rdx
    e79e:      	je	0x15f2d <generic_fentry_path+0xba6d>
    e7a4:      	movl	$0x4, %eax
    e7a9:      	leaq	0x10(%rsp), %rdi
    e7ae:      	movl	$0x8, %esi
    e7b3:      	callq	*%rax
    e7b5:      	cmpq	0x10(%rsp), %r12
    e7ba:      	je	0xe8b2 <generic_fentry_path+0x43f2>
    e7c0:      	leaq	0x18(%r12), %rbx
    e7c5:      	movl	$0x4, %eax
    e7ca:      	movq	%rbp, %rdi
    e7cd:      	movl	$0x8, %esi
    e7d2:      	movq	%rbx, %rdx
    e7d5:      	callq	*%rax
    e7d7:      	cmpq	%r12, (%rsp)
    e7db:      	je	0xe8b2 <generic_fentry_path+0x43f2>
    e7e1:      	movl	$0x4, %eax
    e7e6:      	leaq	0x8(%rsp), %rdi
    e7eb:      	movl	$0x8, %esi
    e7f0:      	movq	%rbx, %rdx
    e7f3:      	callq	*%rax
    e7f5:      	addq	$0x20, %r12
    e7f9:      	movl	$0x4, %eax
    e7fe:      	leaq	0x58(%rsp), %rdi
    e803:      	movl	$0x10, %ecx
    e808:      	movl	$0x10, %esi
    e80d:      	movq	%r12, %rdx
    e810:      	callq	*%rax
    e812:      	movq	0x28(%rsp), %rbx
    e817:      	movq	0x48(%rsp), %rax
    e81c:      	movl	0x5c(%rsp), %r15d
    e821:      	subq	%rbx, %rax
    e824:      	movl	0x50(%rsp), %r12d
    e829:      	movl	%r15d, %edx
    e82c:      	subl	%r12d, %edx
    e82f:      	movl	$0x0, %ecx
    e834:      	cmovbl	%ecx, %edx
    e837:      	addq	0x60(%rsp), %rdx
    e83c:      	xorl	%esi, %esi
    e83e:      	cmpl	%r15d, %r12d
    e841:      	seta	%sil
    e845:      	movl	%r15d, %ecx
    e848:      	cmovbl	%r12d, %ecx
    e84c:      	addl	%ecx, %esi
    e84e:      	movl	%r12d, %edi
    e851:      	subl	%esi, %edi
    e853:      	movl	%edi, 0x50(%rsp)
    e857:      	subq	%rsi, %rax
    e85a:      	jb	0x15f32 <generic_fentry_path+0xba72>
    e860:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e866:      	ja	0x15f32 <generic_fentry_path+0xba72>
    e86c:      	cmpl	%r15d, %r12d
    e86f:      	jbe	0xe875 <generic_fentry_path+0x43b5>
    e871:      	movb	$0x2f, (%rbx,%rax)
    e875:      	xorl	%edi, %edi
    e877:      	cmpl	%r15d, %r12d
    e87a:      	seta	%dil
    e87e:      	movzbl	%cl, %esi
    e881:      	addq	%rax, %rbx
    e884:      	addq	%rbx, %rdi
    e887:      	movl	$0x4, %eax
    e88c:      	callq	*%rax
    e88e:      	movq	%rbx, 0x48(%rsp)
    e893:      	cmpl	%r15d, %r12d
    e896:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    e89c:      	movq	0x8(%rsp), %r12
    e8a1:      	movq	%r12, 0x30(%rsp)
    e8a6:      	movq	0x38(%rsp), %rdx
    e8ab:      	movq	0x40(%rsp), %r15
    e8b0:      	jmp	0xe903 <generic_fentry_path+0x4443>
    e8b2:      	leaq	0x10(%r15), %rdx
    e8b6:      	movl	$0x4, %eax
    e8bb:      	movq	%rbp, %rdi
    e8be:      	movl	$0x8, %esi
    e8c3:      	callq	*%rax
    e8c5:      	movq	0x40(%rsp), %rax
    e8ca:      	cmpq	(%rsp), %rax
    e8ce:      	je	0x15f2d <generic_fentry_path+0xba6d>
    e8d4:      	addq	$0x18, %r15
    e8d8:      	movl	$0x4, %eax
    e8dd:      	leaq	0x30(%rsp), %rdi
    e8e2:      	movl	$0x8, %esi
    e8e7:      	movq	%r15, %rdx
    e8ea:      	callq	*%rax
    e8ec:      	movq	(%rsp), %r15
    e8f0:      	movq	%r15, 0x40(%rsp)
    e8f5:      	leaq	0x20(%r15), %rdx
    e8f9:      	movq	%rdx, 0x38(%rsp)
    e8fe:      	movq	0x30(%rsp), %r12
    e903:      	cmpq	0x18(%rsp), %r12
    e908:      	jne	0xe915 <generic_fentry_path+0x4455>
    e90a:      	cmpq	0x20(%rsp), %rdx
    e90f:      	je	0x15f2d <generic_fentry_path+0xba6d>
    e915:      	movl	$0x4, %eax
    e91a:      	leaq	0x10(%rsp), %rdi
    e91f:      	movl	$0x8, %esi
    e924:      	callq	*%rax
    e926:      	cmpq	0x10(%rsp), %r12
    e92b:      	je	0xea23 <generic_fentry_path+0x4563>
    e931:      	leaq	0x18(%r12), %rbx
    e936:      	movl	$0x4, %eax
    e93b:      	movq	%rbp, %rdi
    e93e:      	movl	$0x8, %esi
    e943:      	movq	%rbx, %rdx
    e946:      	callq	*%rax
    e948:      	cmpq	%r12, (%rsp)
    e94c:      	je	0xea23 <generic_fentry_path+0x4563>
    e952:      	movl	$0x4, %eax
    e957:      	leaq	0x8(%rsp), %rdi
    e95c:      	movl	$0x8, %esi
    e961:      	movq	%rbx, %rdx
    e964:      	callq	*%rax
    e966:      	addq	$0x20, %r12
    e96a:      	movl	$0x4, %eax
    e96f:      	leaq	0x58(%rsp), %rdi
    e974:      	movl	$0x10, %ecx
    e979:      	movl	$0x10, %esi
    e97e:      	movq	%r12, %rdx
    e981:      	callq	*%rax
    e983:      	movq	0x28(%rsp), %rbx
    e988:      	movq	0x48(%rsp), %rax
    e98d:      	movl	0x5c(%rsp), %r15d
    e992:      	subq	%rbx, %rax
    e995:      	movl	0x50(%rsp), %r12d
    e99a:      	movl	%r15d, %edx
    e99d:      	subl	%r12d, %edx
    e9a0:      	movl	$0x0, %ecx
    e9a5:      	cmovbl	%ecx, %edx
    e9a8:      	addq	0x60(%rsp), %rdx
    e9ad:      	xorl	%esi, %esi
    e9af:      	cmpl	%r15d, %r12d
    e9b2:      	seta	%sil
    e9b6:      	movl	%r15d, %ecx
    e9b9:      	cmovbl	%r12d, %ecx
    e9bd:      	addl	%ecx, %esi
    e9bf:      	movl	%r12d, %edi
    e9c2:      	subl	%esi, %edi
    e9c4:      	movl	%edi, 0x50(%rsp)
    e9c8:      	subq	%rsi, %rax
    e9cb:      	jb	0x15f32 <generic_fentry_path+0xba72>
    e9d1:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e9d7:      	ja	0x15f32 <generic_fentry_path+0xba72>
    e9dd:      	cmpl	%r15d, %r12d
    e9e0:      	jbe	0xe9e6 <generic_fentry_path+0x4526>
    e9e2:      	movb	$0x2f, (%rbx,%rax)
    e9e6:      	xorl	%edi, %edi
    e9e8:      	cmpl	%r15d, %r12d
    e9eb:      	seta	%dil
    e9ef:      	movzbl	%cl, %esi
    e9f2:      	addq	%rax, %rbx
    e9f5:      	addq	%rbx, %rdi
    e9f8:      	movl	$0x4, %eax
    e9fd:      	callq	*%rax
    e9ff:      	movq	%rbx, 0x48(%rsp)
    ea04:      	cmpl	%r15d, %r12d
    ea07:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    ea0d:      	movq	0x8(%rsp), %r12
    ea12:      	movq	%r12, 0x30(%rsp)
    ea17:      	movq	0x38(%rsp), %rdx
    ea1c:      	movq	0x40(%rsp), %r15
    ea21:      	jmp	0xea74 <generic_fentry_path+0x45b4>
    ea23:      	leaq	0x10(%r15), %rdx
    ea27:      	movl	$0x4, %eax
    ea2c:      	movq	%rbp, %rdi
    ea2f:      	movl	$0x8, %esi
    ea34:      	callq	*%rax
    ea36:      	movq	0x40(%rsp), %rax
    ea3b:      	cmpq	(%rsp), %rax
    ea3f:      	je	0x15f2d <generic_fentry_path+0xba6d>
    ea45:      	addq	$0x18, %r15
    ea49:      	movl	$0x4, %eax
    ea4e:      	leaq	0x30(%rsp), %rdi
    ea53:      	movl	$0x8, %esi
    ea58:      	movq	%r15, %rdx
    ea5b:      	callq	*%rax
    ea5d:      	movq	(%rsp), %r15
    ea61:      	movq	%r15, 0x40(%rsp)
    ea66:      	leaq	0x20(%r15), %rdx
    ea6a:      	movq	%rdx, 0x38(%rsp)
    ea6f:      	movq	0x30(%rsp), %r12
    ea74:      	cmpq	0x18(%rsp), %r12
    ea79:      	jne	0xea86 <generic_fentry_path+0x45c6>
    ea7b:      	cmpq	0x20(%rsp), %rdx
    ea80:      	je	0x15f2d <generic_fentry_path+0xba6d>
    ea86:      	movl	$0x4, %eax
    ea8b:      	leaq	0x10(%rsp), %rdi
    ea90:      	movl	$0x8, %esi
    ea95:      	callq	*%rax
    ea97:      	cmpq	0x10(%rsp), %r12
    ea9c:      	je	0xeb94 <generic_fentry_path+0x46d4>
    eaa2:      	leaq	0x18(%r12), %rbx
    eaa7:      	movl	$0x4, %eax
    eaac:      	movq	%rbp, %rdi
    eaaf:      	movl	$0x8, %esi
    eab4:      	movq	%rbx, %rdx
    eab7:      	callq	*%rax
    eab9:      	cmpq	%r12, (%rsp)
    eabd:      	je	0xeb94 <generic_fentry_path+0x46d4>
    eac3:      	movl	$0x4, %eax
    eac8:      	leaq	0x8(%rsp), %rdi
    eacd:      	movl	$0x8, %esi
    ead2:      	movq	%rbx, %rdx
    ead5:      	callq	*%rax
    ead7:      	addq	$0x20, %r12
    eadb:      	movl	$0x4, %eax
    eae0:      	leaq	0x58(%rsp), %rdi
    eae5:      	movl	$0x10, %ecx
    eaea:      	movl	$0x10, %esi
    eaef:      	movq	%r12, %rdx
    eaf2:      	callq	*%rax
    eaf4:      	movq	0x28(%rsp), %rbx
    eaf9:      	movq	0x48(%rsp), %rax
    eafe:      	movl	0x5c(%rsp), %r15d
    eb03:      	subq	%rbx, %rax
    eb06:      	movl	0x50(%rsp), %r12d
    eb0b:      	movl	%r15d, %edx
    eb0e:      	subl	%r12d, %edx
    eb11:      	movl	$0x0, %ecx
    eb16:      	cmovbl	%ecx, %edx
    eb19:      	addq	0x60(%rsp), %rdx
    eb1e:      	xorl	%esi, %esi
    eb20:      	cmpl	%r15d, %r12d
    eb23:      	seta	%sil
    eb27:      	movl	%r15d, %ecx
    eb2a:      	cmovbl	%r12d, %ecx
    eb2e:      	addl	%ecx, %esi
    eb30:      	movl	%r12d, %edi
    eb33:      	subl	%esi, %edi
    eb35:      	movl	%edi, 0x50(%rsp)
    eb39:      	subq	%rsi, %rax
    eb3c:      	jb	0x15f32 <generic_fentry_path+0xba72>
    eb42:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    eb48:      	ja	0x15f32 <generic_fentry_path+0xba72>
    eb4e:      	cmpl	%r15d, %r12d
    eb51:      	jbe	0xeb57 <generic_fentry_path+0x4697>
    eb53:      	movb	$0x2f, (%rbx,%rax)
    eb57:      	xorl	%edi, %edi
    eb59:      	cmpl	%r15d, %r12d
    eb5c:      	seta	%dil
    eb60:      	movzbl	%cl, %esi
    eb63:      	addq	%rax, %rbx
    eb66:      	addq	%rbx, %rdi
    eb69:      	movl	$0x4, %eax
    eb6e:      	callq	*%rax
    eb70:      	movq	%rbx, 0x48(%rsp)
    eb75:      	cmpl	%r15d, %r12d
    eb78:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    eb7e:      	movq	0x8(%rsp), %r12
    eb83:      	movq	%r12, 0x30(%rsp)
    eb88:      	movq	0x38(%rsp), %rdx
    eb8d:      	movq	0x40(%rsp), %r15
    eb92:      	jmp	0xebe5 <generic_fentry_path+0x4725>
    eb94:      	leaq	0x10(%r15), %rdx
    eb98:      	movl	$0x4, %eax
    eb9d:      	movq	%rbp, %rdi
    eba0:      	movl	$0x8, %esi
    eba5:      	callq	*%rax
    eba7:      	movq	0x40(%rsp), %rax
    ebac:      	cmpq	(%rsp), %rax
    ebb0:      	je	0x15f2d <generic_fentry_path+0xba6d>
    ebb6:      	addq	$0x18, %r15
    ebba:      	movl	$0x4, %eax
    ebbf:      	leaq	0x30(%rsp), %rdi
    ebc4:      	movl	$0x8, %esi
    ebc9:      	movq	%r15, %rdx
    ebcc:      	callq	*%rax
    ebce:      	movq	(%rsp), %r15
    ebd2:      	movq	%r15, 0x40(%rsp)
    ebd7:      	leaq	0x20(%r15), %rdx
    ebdb:      	movq	%rdx, 0x38(%rsp)
    ebe0:      	movq	0x30(%rsp), %r12
    ebe5:      	cmpq	0x18(%rsp), %r12
    ebea:      	jne	0xebf7 <generic_fentry_path+0x4737>
    ebec:      	cmpq	0x20(%rsp), %rdx
    ebf1:      	je	0x15f2d <generic_fentry_path+0xba6d>
    ebf7:      	movl	$0x4, %eax
    ebfc:      	leaq	0x10(%rsp), %rdi
    ec01:      	movl	$0x8, %esi
    ec06:      	callq	*%rax
    ec08:      	cmpq	0x10(%rsp), %r12
    ec0d:      	je	0xed05 <generic_fentry_path+0x4845>
    ec13:      	leaq	0x18(%r12), %rbx
    ec18:      	movl	$0x4, %eax
    ec1d:      	movq	%rbp, %rdi
    ec20:      	movl	$0x8, %esi
    ec25:      	movq	%rbx, %rdx
    ec28:      	callq	*%rax
    ec2a:      	cmpq	%r12, (%rsp)
    ec2e:      	je	0xed05 <generic_fentry_path+0x4845>
    ec34:      	movl	$0x4, %eax
    ec39:      	leaq	0x8(%rsp), %rdi
    ec3e:      	movl	$0x8, %esi
    ec43:      	movq	%rbx, %rdx
    ec46:      	callq	*%rax
    ec48:      	addq	$0x20, %r12
    ec4c:      	movl	$0x4, %eax
    ec51:      	leaq	0x58(%rsp), %rdi
    ec56:      	movl	$0x10, %ecx
    ec5b:      	movl	$0x10, %esi
    ec60:      	movq	%r12, %rdx
    ec63:      	callq	*%rax
    ec65:      	movq	0x28(%rsp), %rbx
    ec6a:      	movq	0x48(%rsp), %rax
    ec6f:      	movl	0x5c(%rsp), %r15d
    ec74:      	subq	%rbx, %rax
    ec77:      	movl	0x50(%rsp), %r12d
    ec7c:      	movl	%r15d, %edx
    ec7f:      	subl	%r12d, %edx
    ec82:      	movl	$0x0, %ecx
    ec87:      	cmovbl	%ecx, %edx
    ec8a:      	addq	0x60(%rsp), %rdx
    ec8f:      	xorl	%esi, %esi
    ec91:      	cmpl	%r15d, %r12d
    ec94:      	seta	%sil
    ec98:      	movl	%r15d, %ecx
    ec9b:      	cmovbl	%r12d, %ecx
    ec9f:      	addl	%ecx, %esi
    eca1:      	movl	%r12d, %edi
    eca4:      	subl	%esi, %edi
    eca6:      	movl	%edi, 0x50(%rsp)
    ecaa:      	subq	%rsi, %rax
    ecad:      	jb	0x15f32 <generic_fentry_path+0xba72>
    ecb3:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ecb9:      	ja	0x15f32 <generic_fentry_path+0xba72>
    ecbf:      	cmpl	%r15d, %r12d
    ecc2:      	jbe	0xecc8 <generic_fentry_path+0x4808>
    ecc4:      	movb	$0x2f, (%rbx,%rax)
    ecc8:      	xorl	%edi, %edi
    ecca:      	cmpl	%r15d, %r12d
    eccd:      	seta	%dil
    ecd1:      	movzbl	%cl, %esi
    ecd4:      	addq	%rax, %rbx
    ecd7:      	addq	%rbx, %rdi
    ecda:      	movl	$0x4, %eax
    ecdf:      	callq	*%rax
    ece1:      	movq	%rbx, 0x48(%rsp)
    ece6:      	cmpl	%r15d, %r12d
    ece9:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    ecef:      	movq	0x8(%rsp), %r12
    ecf4:      	movq	%r12, 0x30(%rsp)
    ecf9:      	movq	0x38(%rsp), %rdx
    ecfe:      	movq	0x40(%rsp), %r15
    ed03:      	jmp	0xed56 <generic_fentry_path+0x4896>
    ed05:      	leaq	0x10(%r15), %rdx
    ed09:      	movl	$0x4, %eax
    ed0e:      	movq	%rbp, %rdi
    ed11:      	movl	$0x8, %esi
    ed16:      	callq	*%rax
    ed18:      	movq	0x40(%rsp), %rax
    ed1d:      	cmpq	(%rsp), %rax
    ed21:      	je	0x15f2d <generic_fentry_path+0xba6d>
    ed27:      	addq	$0x18, %r15
    ed2b:      	movl	$0x4, %eax
    ed30:      	leaq	0x30(%rsp), %rdi
    ed35:      	movl	$0x8, %esi
    ed3a:      	movq	%r15, %rdx
    ed3d:      	callq	*%rax
    ed3f:      	movq	(%rsp), %r15
    ed43:      	movq	%r15, 0x40(%rsp)
    ed48:      	leaq	0x20(%r15), %rdx
    ed4c:      	movq	%rdx, 0x38(%rsp)
    ed51:      	movq	0x30(%rsp), %r12
    ed56:      	cmpq	0x18(%rsp), %r12
    ed5b:      	jne	0xed68 <generic_fentry_path+0x48a8>
    ed5d:      	cmpq	0x20(%rsp), %rdx
    ed62:      	je	0x15f2d <generic_fentry_path+0xba6d>
    ed68:      	movl	$0x4, %eax
    ed6d:      	leaq	0x10(%rsp), %rdi
    ed72:      	movl	$0x8, %esi
    ed77:      	callq	*%rax
    ed79:      	cmpq	0x10(%rsp), %r12
    ed7e:      	je	0xee76 <generic_fentry_path+0x49b6>
    ed84:      	leaq	0x18(%r12), %rbx
    ed89:      	movl	$0x4, %eax
    ed8e:      	movq	%rbp, %rdi
    ed91:      	movl	$0x8, %esi
    ed96:      	movq	%rbx, %rdx
    ed99:      	callq	*%rax
    ed9b:      	cmpq	%r12, (%rsp)
    ed9f:      	je	0xee76 <generic_fentry_path+0x49b6>
    eda5:      	movl	$0x4, %eax
    edaa:      	leaq	0x8(%rsp), %rdi
    edaf:      	movl	$0x8, %esi
    edb4:      	movq	%rbx, %rdx
    edb7:      	callq	*%rax
    edb9:      	addq	$0x20, %r12
    edbd:      	movl	$0x4, %eax
    edc2:      	leaq	0x58(%rsp), %rdi
    edc7:      	movl	$0x10, %ecx
    edcc:      	movl	$0x10, %esi
    edd1:      	movq	%r12, %rdx
    edd4:      	callq	*%rax
    edd6:      	movq	0x28(%rsp), %rbx
    eddb:      	movq	0x48(%rsp), %rax
    ede0:      	movl	0x5c(%rsp), %r15d
    ede5:      	subq	%rbx, %rax
    ede8:      	movl	0x50(%rsp), %r12d
    eded:      	movl	%r15d, %edx
    edf0:      	subl	%r12d, %edx
    edf3:      	movl	$0x0, %ecx
    edf8:      	cmovbl	%ecx, %edx
    edfb:      	addq	0x60(%rsp), %rdx
    ee00:      	xorl	%esi, %esi
    ee02:      	cmpl	%r15d, %r12d
    ee05:      	seta	%sil
    ee09:      	movl	%r15d, %ecx
    ee0c:      	cmovbl	%r12d, %ecx
    ee10:      	addl	%ecx, %esi
    ee12:      	movl	%r12d, %edi
    ee15:      	subl	%esi, %edi
    ee17:      	movl	%edi, 0x50(%rsp)
    ee1b:      	subq	%rsi, %rax
    ee1e:      	jb	0x15f32 <generic_fentry_path+0xba72>
    ee24:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ee2a:      	ja	0x15f32 <generic_fentry_path+0xba72>
    ee30:      	cmpl	%r15d, %r12d
    ee33:      	jbe	0xee39 <generic_fentry_path+0x4979>
    ee35:      	movb	$0x2f, (%rbx,%rax)
    ee39:      	xorl	%edi, %edi
    ee3b:      	cmpl	%r15d, %r12d
    ee3e:      	seta	%dil
    ee42:      	movzbl	%cl, %esi
    ee45:      	addq	%rax, %rbx
    ee48:      	addq	%rbx, %rdi
    ee4b:      	movl	$0x4, %eax
    ee50:      	callq	*%rax
    ee52:      	movq	%rbx, 0x48(%rsp)
    ee57:      	cmpl	%r15d, %r12d
    ee5a:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    ee60:      	movq	0x8(%rsp), %r12
    ee65:      	movq	%r12, 0x30(%rsp)
    ee6a:      	movq	0x38(%rsp), %rdx
    ee6f:      	movq	0x40(%rsp), %r15
    ee74:      	jmp	0xeec7 <generic_fentry_path+0x4a07>
    ee76:      	leaq	0x10(%r15), %rdx
    ee7a:      	movl	$0x4, %eax
    ee7f:      	movq	%rbp, %rdi
    ee82:      	movl	$0x8, %esi
    ee87:      	callq	*%rax
    ee89:      	movq	0x40(%rsp), %rax
    ee8e:      	cmpq	(%rsp), %rax
    ee92:      	je	0x15f2d <generic_fentry_path+0xba6d>
    ee98:      	addq	$0x18, %r15
    ee9c:      	movl	$0x4, %eax
    eea1:      	leaq	0x30(%rsp), %rdi
    eea6:      	movl	$0x8, %esi
    eeab:      	movq	%r15, %rdx
    eeae:      	callq	*%rax
    eeb0:      	movq	(%rsp), %r15
    eeb4:      	movq	%r15, 0x40(%rsp)
    eeb9:      	leaq	0x20(%r15), %rdx
    eebd:      	movq	%rdx, 0x38(%rsp)
    eec2:      	movq	0x30(%rsp), %r12
    eec7:      	cmpq	0x18(%rsp), %r12
    eecc:      	jne	0xeed9 <generic_fentry_path+0x4a19>
    eece:      	cmpq	0x20(%rsp), %rdx
    eed3:      	je	0x15f2d <generic_fentry_path+0xba6d>
    eed9:      	movl	$0x4, %eax
    eede:      	leaq	0x10(%rsp), %rdi
    eee3:      	movl	$0x8, %esi
    eee8:      	callq	*%rax
    eeea:      	cmpq	0x10(%rsp), %r12
    eeef:      	je	0xefe7 <generic_fentry_path+0x4b27>
    eef5:      	leaq	0x18(%r12), %rbx
    eefa:      	movl	$0x4, %eax
    eeff:      	movq	%rbp, %rdi
    ef02:      	movl	$0x8, %esi
    ef07:      	movq	%rbx, %rdx
    ef0a:      	callq	*%rax
    ef0c:      	cmpq	%r12, (%rsp)
    ef10:      	je	0xefe7 <generic_fentry_path+0x4b27>
    ef16:      	movl	$0x4, %eax
    ef1b:      	leaq	0x8(%rsp), %rdi
    ef20:      	movl	$0x8, %esi
    ef25:      	movq	%rbx, %rdx
    ef28:      	callq	*%rax
    ef2a:      	addq	$0x20, %r12
    ef2e:      	movl	$0x4, %eax
    ef33:      	leaq	0x58(%rsp), %rdi
    ef38:      	movl	$0x10, %ecx
    ef3d:      	movl	$0x10, %esi
    ef42:      	movq	%r12, %rdx
    ef45:      	callq	*%rax
    ef47:      	movq	0x28(%rsp), %rbx
    ef4c:      	movq	0x48(%rsp), %rax
    ef51:      	movl	0x5c(%rsp), %r15d
    ef56:      	subq	%rbx, %rax
    ef59:      	movl	0x50(%rsp), %r12d
    ef5e:      	movl	%r15d, %edx
    ef61:      	subl	%r12d, %edx
    ef64:      	movl	$0x0, %ecx
    ef69:      	cmovbl	%ecx, %edx
    ef6c:      	addq	0x60(%rsp), %rdx
    ef71:      	xorl	%esi, %esi
    ef73:      	cmpl	%r15d, %r12d
    ef76:      	seta	%sil
    ef7a:      	movl	%r15d, %ecx
    ef7d:      	cmovbl	%r12d, %ecx
    ef81:      	addl	%ecx, %esi
    ef83:      	movl	%r12d, %edi
    ef86:      	subl	%esi, %edi
    ef88:      	movl	%edi, 0x50(%rsp)
    ef8c:      	subq	%rsi, %rax
    ef8f:      	jb	0x15f32 <generic_fentry_path+0xba72>
    ef95:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ef9b:      	ja	0x15f32 <generic_fentry_path+0xba72>
    efa1:      	cmpl	%r15d, %r12d
    efa4:      	jbe	0xefaa <generic_fentry_path+0x4aea>
    efa6:      	movb	$0x2f, (%rbx,%rax)
    efaa:      	xorl	%edi, %edi
    efac:      	cmpl	%r15d, %r12d
    efaf:      	seta	%dil
    efb3:      	movzbl	%cl, %esi
    efb6:      	addq	%rax, %rbx
    efb9:      	addq	%rbx, %rdi
    efbc:      	movl	$0x4, %eax
    efc1:      	callq	*%rax
    efc3:      	movq	%rbx, 0x48(%rsp)
    efc8:      	cmpl	%r15d, %r12d
    efcb:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    efd1:      	movq	0x8(%rsp), %r12
    efd6:      	movq	%r12, 0x30(%rsp)
    efdb:      	movq	0x38(%rsp), %rdx
    efe0:      	movq	0x40(%rsp), %r15
    efe5:      	jmp	0xf038 <generic_fentry_path+0x4b78>
    efe7:      	leaq	0x10(%r15), %rdx
    efeb:      	movl	$0x4, %eax
    eff0:      	movq	%rbp, %rdi
    eff3:      	movl	$0x8, %esi
    eff8:      	callq	*%rax
    effa:      	movq	0x40(%rsp), %rax
    efff:      	cmpq	(%rsp), %rax
    f003:      	je	0x15f2d <generic_fentry_path+0xba6d>
    f009:      	addq	$0x18, %r15
    f00d:      	movl	$0x4, %eax
    f012:      	leaq	0x30(%rsp), %rdi
    f017:      	movl	$0x8, %esi
    f01c:      	movq	%r15, %rdx
    f01f:      	callq	*%rax
    f021:      	movq	(%rsp), %r15
    f025:      	movq	%r15, 0x40(%rsp)
    f02a:      	leaq	0x20(%r15), %rdx
    f02e:      	movq	%rdx, 0x38(%rsp)
    f033:      	movq	0x30(%rsp), %r12
    f038:      	cmpq	0x18(%rsp), %r12
    f03d:      	jne	0xf04a <generic_fentry_path+0x4b8a>
    f03f:      	cmpq	0x20(%rsp), %rdx
    f044:      	je	0x15f2d <generic_fentry_path+0xba6d>
    f04a:      	movl	$0x4, %eax
    f04f:      	leaq	0x10(%rsp), %rdi
    f054:      	movl	$0x8, %esi
    f059:      	callq	*%rax
    f05b:      	cmpq	0x10(%rsp), %r12
    f060:      	je	0xf158 <generic_fentry_path+0x4c98>
    f066:      	leaq	0x18(%r12), %rbx
    f06b:      	movl	$0x4, %eax
    f070:      	movq	%rbp, %rdi
    f073:      	movl	$0x8, %esi
    f078:      	movq	%rbx, %rdx
    f07b:      	callq	*%rax
    f07d:      	cmpq	%r12, (%rsp)
    f081:      	je	0xf158 <generic_fentry_path+0x4c98>
    f087:      	movl	$0x4, %eax
    f08c:      	leaq	0x8(%rsp), %rdi
    f091:      	movl	$0x8, %esi
    f096:      	movq	%rbx, %rdx
    f099:      	callq	*%rax
    f09b:      	addq	$0x20, %r12
    f09f:      	movl	$0x4, %eax
    f0a4:      	leaq	0x58(%rsp), %rdi
    f0a9:      	movl	$0x10, %ecx
    f0ae:      	movl	$0x10, %esi
    f0b3:      	movq	%r12, %rdx
    f0b6:      	callq	*%rax
    f0b8:      	movq	0x28(%rsp), %rbx
    f0bd:      	movq	0x48(%rsp), %rax
    f0c2:      	movl	0x5c(%rsp), %r15d
    f0c7:      	subq	%rbx, %rax
    f0ca:      	movl	0x50(%rsp), %r12d
    f0cf:      	movl	%r15d, %edx
    f0d2:      	subl	%r12d, %edx
    f0d5:      	movl	$0x0, %ecx
    f0da:      	cmovbl	%ecx, %edx
    f0dd:      	addq	0x60(%rsp), %rdx
    f0e2:      	xorl	%esi, %esi
    f0e4:      	cmpl	%r15d, %r12d
    f0e7:      	seta	%sil
    f0eb:      	movl	%r15d, %ecx
    f0ee:      	cmovbl	%r12d, %ecx
    f0f2:      	addl	%ecx, %esi
    f0f4:      	movl	%r12d, %edi
    f0f7:      	subl	%esi, %edi
    f0f9:      	movl	%edi, 0x50(%rsp)
    f0fd:      	subq	%rsi, %rax
    f100:      	jb	0x15f32 <generic_fentry_path+0xba72>
    f106:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f10c:      	ja	0x15f32 <generic_fentry_path+0xba72>
    f112:      	cmpl	%r15d, %r12d
    f115:      	jbe	0xf11b <generic_fentry_path+0x4c5b>
    f117:      	movb	$0x2f, (%rbx,%rax)
    f11b:      	xorl	%edi, %edi
    f11d:      	cmpl	%r15d, %r12d
    f120:      	seta	%dil
    f124:      	movzbl	%cl, %esi
    f127:      	addq	%rax, %rbx
    f12a:      	addq	%rbx, %rdi
    f12d:      	movl	$0x4, %eax
    f132:      	callq	*%rax
    f134:      	movq	%rbx, 0x48(%rsp)
    f139:      	cmpl	%r15d, %r12d
    f13c:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    f142:      	movq	0x8(%rsp), %r12
    f147:      	movq	%r12, 0x30(%rsp)
    f14c:      	movq	0x38(%rsp), %rdx
    f151:      	movq	0x40(%rsp), %r15
    f156:      	jmp	0xf1a9 <generic_fentry_path+0x4ce9>
    f158:      	leaq	0x10(%r15), %rdx
    f15c:      	movl	$0x4, %eax
    f161:      	movq	%rbp, %rdi
    f164:      	movl	$0x8, %esi
    f169:      	callq	*%rax
    f16b:      	movq	0x40(%rsp), %rax
    f170:      	cmpq	(%rsp), %rax
    f174:      	je	0x15f2d <generic_fentry_path+0xba6d>
    f17a:      	addq	$0x18, %r15
    f17e:      	movl	$0x4, %eax
    f183:      	leaq	0x30(%rsp), %rdi
    f188:      	movl	$0x8, %esi
    f18d:      	movq	%r15, %rdx
    f190:      	callq	*%rax
    f192:      	movq	(%rsp), %r15
    f196:      	movq	%r15, 0x40(%rsp)
    f19b:      	leaq	0x20(%r15), %rdx
    f19f:      	movq	%rdx, 0x38(%rsp)
    f1a4:      	movq	0x30(%rsp), %r12
    f1a9:      	cmpq	0x18(%rsp), %r12
    f1ae:      	jne	0xf1bb <generic_fentry_path+0x4cfb>
    f1b0:      	cmpq	0x20(%rsp), %rdx
    f1b5:      	je	0x15f2d <generic_fentry_path+0xba6d>
    f1bb:      	movl	$0x4, %eax
    f1c0:      	leaq	0x10(%rsp), %rdi
    f1c5:      	movl	$0x8, %esi
    f1ca:      	callq	*%rax
    f1cc:      	cmpq	0x10(%rsp), %r12
    f1d1:      	je	0xf2c9 <generic_fentry_path+0x4e09>
    f1d7:      	leaq	0x18(%r12), %rbx
    f1dc:      	movl	$0x4, %eax
    f1e1:      	movq	%rbp, %rdi
    f1e4:      	movl	$0x8, %esi
    f1e9:      	movq	%rbx, %rdx
    f1ec:      	callq	*%rax
    f1ee:      	cmpq	%r12, (%rsp)
    f1f2:      	je	0xf2c9 <generic_fentry_path+0x4e09>
    f1f8:      	movl	$0x4, %eax
    f1fd:      	leaq	0x8(%rsp), %rdi
    f202:      	movl	$0x8, %esi
    f207:      	movq	%rbx, %rdx
    f20a:      	callq	*%rax
    f20c:      	addq	$0x20, %r12
    f210:      	movl	$0x4, %eax
    f215:      	leaq	0x58(%rsp), %rdi
    f21a:      	movl	$0x10, %ecx
    f21f:      	movl	$0x10, %esi
    f224:      	movq	%r12, %rdx
    f227:      	callq	*%rax
    f229:      	movq	0x28(%rsp), %rbx
    f22e:      	movq	0x48(%rsp), %rax
    f233:      	movl	0x5c(%rsp), %r15d
    f238:      	subq	%rbx, %rax
    f23b:      	movl	0x50(%rsp), %r12d
    f240:      	movl	%r15d, %edx
    f243:      	subl	%r12d, %edx
    f246:      	movl	$0x0, %ecx
    f24b:      	cmovbl	%ecx, %edx
    f24e:      	addq	0x60(%rsp), %rdx
    f253:      	xorl	%esi, %esi
    f255:      	cmpl	%r15d, %r12d
    f258:      	seta	%sil
    f25c:      	movl	%r15d, %ecx
    f25f:      	cmovbl	%r12d, %ecx
    f263:      	addl	%ecx, %esi
    f265:      	movl	%r12d, %edi
    f268:      	subl	%esi, %edi
    f26a:      	movl	%edi, 0x50(%rsp)
    f26e:      	subq	%rsi, %rax
    f271:      	jb	0x15f32 <generic_fentry_path+0xba72>
    f277:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f27d:      	ja	0x15f32 <generic_fentry_path+0xba72>
    f283:      	cmpl	%r15d, %r12d
    f286:      	jbe	0xf28c <generic_fentry_path+0x4dcc>
    f288:      	movb	$0x2f, (%rbx,%rax)
    f28c:      	xorl	%edi, %edi
    f28e:      	cmpl	%r15d, %r12d
    f291:      	seta	%dil
    f295:      	movzbl	%cl, %esi
    f298:      	addq	%rax, %rbx
    f29b:      	addq	%rbx, %rdi
    f29e:      	movl	$0x4, %eax
    f2a3:      	callq	*%rax
    f2a5:      	movq	%rbx, 0x48(%rsp)
    f2aa:      	cmpl	%r15d, %r12d
    f2ad:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    f2b3:      	movq	0x8(%rsp), %r12
    f2b8:      	movq	%r12, 0x30(%rsp)
    f2bd:      	movq	0x38(%rsp), %rdx
    f2c2:      	movq	0x40(%rsp), %r15
    f2c7:      	jmp	0xf31a <generic_fentry_path+0x4e5a>
    f2c9:      	leaq	0x10(%r15), %rdx
    f2cd:      	movl	$0x4, %eax
    f2d2:      	movq	%rbp, %rdi
    f2d5:      	movl	$0x8, %esi
    f2da:      	callq	*%rax
    f2dc:      	movq	0x40(%rsp), %rax
    f2e1:      	cmpq	(%rsp), %rax
    f2e5:      	je	0x15f2d <generic_fentry_path+0xba6d>
    f2eb:      	addq	$0x18, %r15
    f2ef:      	movl	$0x4, %eax
    f2f4:      	leaq	0x30(%rsp), %rdi
    f2f9:      	movl	$0x8, %esi
    f2fe:      	movq	%r15, %rdx
    f301:      	callq	*%rax
    f303:      	movq	(%rsp), %r15
    f307:      	movq	%r15, 0x40(%rsp)
    f30c:      	leaq	0x20(%r15), %rdx
    f310:      	movq	%rdx, 0x38(%rsp)
    f315:      	movq	0x30(%rsp), %r12
    f31a:      	cmpq	0x18(%rsp), %r12
    f31f:      	jne	0xf32c <generic_fentry_path+0x4e6c>
    f321:      	cmpq	0x20(%rsp), %rdx
    f326:      	je	0x15f2d <generic_fentry_path+0xba6d>
    f32c:      	movl	$0x4, %eax
    f331:      	leaq	0x10(%rsp), %rdi
    f336:      	movl	$0x8, %esi
    f33b:      	callq	*%rax
    f33d:      	cmpq	0x10(%rsp), %r12
    f342:      	je	0xf43a <generic_fentry_path+0x4f7a>
    f348:      	leaq	0x18(%r12), %rbx
    f34d:      	movl	$0x4, %eax
    f352:      	movq	%rbp, %rdi
    f355:      	movl	$0x8, %esi
    f35a:      	movq	%rbx, %rdx
    f35d:      	callq	*%rax
    f35f:      	cmpq	%r12, (%rsp)
    f363:      	je	0xf43a <generic_fentry_path+0x4f7a>
    f369:      	movl	$0x4, %eax
    f36e:      	leaq	0x8(%rsp), %rdi
    f373:      	movl	$0x8, %esi
    f378:      	movq	%rbx, %rdx
    f37b:      	callq	*%rax
    f37d:      	addq	$0x20, %r12
    f381:      	movl	$0x4, %eax
    f386:      	leaq	0x58(%rsp), %rdi
    f38b:      	movl	$0x10, %ecx
    f390:      	movl	$0x10, %esi
    f395:      	movq	%r12, %rdx
    f398:      	callq	*%rax
    f39a:      	movq	0x28(%rsp), %rbx
    f39f:      	movq	0x48(%rsp), %rax
    f3a4:      	movl	0x5c(%rsp), %r15d
    f3a9:      	subq	%rbx, %rax
    f3ac:      	movl	0x50(%rsp), %r12d
    f3b1:      	movl	%r15d, %edx
    f3b4:      	subl	%r12d, %edx
    f3b7:      	movl	$0x0, %ecx
    f3bc:      	cmovbl	%ecx, %edx
    f3bf:      	addq	0x60(%rsp), %rdx
    f3c4:      	xorl	%esi, %esi
    f3c6:      	cmpl	%r15d, %r12d
    f3c9:      	seta	%sil
    f3cd:      	movl	%r15d, %ecx
    f3d0:      	cmovbl	%r12d, %ecx
    f3d4:      	addl	%ecx, %esi
    f3d6:      	movl	%r12d, %edi
    f3d9:      	subl	%esi, %edi
    f3db:      	movl	%edi, 0x50(%rsp)
    f3df:      	subq	%rsi, %rax
    f3e2:      	jb	0x15f32 <generic_fentry_path+0xba72>
    f3e8:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f3ee:      	ja	0x15f32 <generic_fentry_path+0xba72>
    f3f4:      	cmpl	%r15d, %r12d
    f3f7:      	jbe	0xf3fd <generic_fentry_path+0x4f3d>
    f3f9:      	movb	$0x2f, (%rbx,%rax)
    f3fd:      	xorl	%edi, %edi
    f3ff:      	cmpl	%r15d, %r12d
    f402:      	seta	%dil
    f406:      	movzbl	%cl, %esi
    f409:      	addq	%rax, %rbx
    f40c:      	addq	%rbx, %rdi
    f40f:      	movl	$0x4, %eax
    f414:      	callq	*%rax
    f416:      	movq	%rbx, 0x48(%rsp)
    f41b:      	cmpl	%r15d, %r12d
    f41e:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    f424:      	movq	0x8(%rsp), %r12
    f429:      	movq	%r12, 0x30(%rsp)
    f42e:      	movq	0x38(%rsp), %rdx
    f433:      	movq	0x40(%rsp), %r15
    f438:      	jmp	0xf48b <generic_fentry_path+0x4fcb>
    f43a:      	leaq	0x10(%r15), %rdx
    f43e:      	movl	$0x4, %eax
    f443:      	movq	%rbp, %rdi
    f446:      	movl	$0x8, %esi
    f44b:      	callq	*%rax
    f44d:      	movq	0x40(%rsp), %rax
    f452:      	cmpq	(%rsp), %rax
    f456:      	je	0x15f2d <generic_fentry_path+0xba6d>
    f45c:      	addq	$0x18, %r15
    f460:      	movl	$0x4, %eax
    f465:      	leaq	0x30(%rsp), %rdi
    f46a:      	movl	$0x8, %esi
    f46f:      	movq	%r15, %rdx
    f472:      	callq	*%rax
    f474:      	movq	(%rsp), %r15
    f478:      	movq	%r15, 0x40(%rsp)
    f47d:      	leaq	0x20(%r15), %rdx
    f481:      	movq	%rdx, 0x38(%rsp)
    f486:      	movq	0x30(%rsp), %r12
    f48b:      	cmpq	0x18(%rsp), %r12
    f490:      	jne	0xf49d <generic_fentry_path+0x4fdd>
    f492:      	cmpq	0x20(%rsp), %rdx
    f497:      	je	0x15f2d <generic_fentry_path+0xba6d>
    f49d:      	movl	$0x4, %eax
    f4a2:      	leaq	0x10(%rsp), %rdi
    f4a7:      	movl	$0x8, %esi
    f4ac:      	callq	*%rax
    f4ae:      	cmpq	0x10(%rsp), %r12
    f4b3:      	je	0xf5ab <generic_fentry_path+0x50eb>
    f4b9:      	leaq	0x18(%r12), %rbx
    f4be:      	movl	$0x4, %eax
    f4c3:      	movq	%rbp, %rdi
    f4c6:      	movl	$0x8, %esi
    f4cb:      	movq	%rbx, %rdx
    f4ce:      	callq	*%rax
    f4d0:      	cmpq	%r12, (%rsp)
    f4d4:      	je	0xf5ab <generic_fentry_path+0x50eb>
    f4da:      	movl	$0x4, %eax
    f4df:      	leaq	0x8(%rsp), %rdi
    f4e4:      	movl	$0x8, %esi
    f4e9:      	movq	%rbx, %rdx
    f4ec:      	callq	*%rax
    f4ee:      	addq	$0x20, %r12
    f4f2:      	movl	$0x4, %eax
    f4f7:      	leaq	0x58(%rsp), %rdi
    f4fc:      	movl	$0x10, %ecx
    f501:      	movl	$0x10, %esi
    f506:      	movq	%r12, %rdx
    f509:      	callq	*%rax
    f50b:      	movq	0x28(%rsp), %rbx
    f510:      	movq	0x48(%rsp), %rax
    f515:      	movl	0x5c(%rsp), %r15d
    f51a:      	subq	%rbx, %rax
    f51d:      	movl	0x50(%rsp), %r12d
    f522:      	movl	%r15d, %edx
    f525:      	subl	%r12d, %edx
    f528:      	movl	$0x0, %ecx
    f52d:      	cmovbl	%ecx, %edx
    f530:      	addq	0x60(%rsp), %rdx
    f535:      	xorl	%esi, %esi
    f537:      	cmpl	%r15d, %r12d
    f53a:      	seta	%sil
    f53e:      	movl	%r15d, %ecx
    f541:      	cmovbl	%r12d, %ecx
    f545:      	addl	%ecx, %esi
    f547:      	movl	%r12d, %edi
    f54a:      	subl	%esi, %edi
    f54c:      	movl	%edi, 0x50(%rsp)
    f550:      	subq	%rsi, %rax
    f553:      	jb	0x15f32 <generic_fentry_path+0xba72>
    f559:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f55f:      	ja	0x15f32 <generic_fentry_path+0xba72>
    f565:      	cmpl	%r15d, %r12d
    f568:      	jbe	0xf56e <generic_fentry_path+0x50ae>
    f56a:      	movb	$0x2f, (%rbx,%rax)
    f56e:      	xorl	%edi, %edi
    f570:      	cmpl	%r15d, %r12d
    f573:      	seta	%dil
    f577:      	movzbl	%cl, %esi
    f57a:      	addq	%rax, %rbx
    f57d:      	addq	%rbx, %rdi
    f580:      	movl	$0x4, %eax
    f585:      	callq	*%rax
    f587:      	movq	%rbx, 0x48(%rsp)
    f58c:      	cmpl	%r15d, %r12d
    f58f:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    f595:      	movq	0x8(%rsp), %r12
    f59a:      	movq	%r12, 0x30(%rsp)
    f59f:      	movq	0x38(%rsp), %rdx
    f5a4:      	movq	0x40(%rsp), %r15
    f5a9:      	jmp	0xf5fc <generic_fentry_path+0x513c>
    f5ab:      	leaq	0x10(%r15), %rdx
    f5af:      	movl	$0x4, %eax
    f5b4:      	movq	%rbp, %rdi
    f5b7:      	movl	$0x8, %esi
    f5bc:      	callq	*%rax
    f5be:      	movq	0x40(%rsp), %rax
    f5c3:      	cmpq	(%rsp), %rax
    f5c7:      	je	0x15f2d <generic_fentry_path+0xba6d>
    f5cd:      	addq	$0x18, %r15
    f5d1:      	movl	$0x4, %eax
    f5d6:      	leaq	0x30(%rsp), %rdi
    f5db:      	movl	$0x8, %esi
    f5e0:      	movq	%r15, %rdx
    f5e3:      	callq	*%rax
    f5e5:      	movq	(%rsp), %r15
    f5e9:      	movq	%r15, 0x40(%rsp)
    f5ee:      	leaq	0x20(%r15), %rdx
    f5f2:      	movq	%rdx, 0x38(%rsp)
    f5f7:      	movq	0x30(%rsp), %r12
    f5fc:      	cmpq	0x18(%rsp), %r12
    f601:      	jne	0xf60e <generic_fentry_path+0x514e>
    f603:      	cmpq	0x20(%rsp), %rdx
    f608:      	je	0x15f2d <generic_fentry_path+0xba6d>
    f60e:      	movl	$0x4, %eax
    f613:      	leaq	0x10(%rsp), %rdi
    f618:      	movl	$0x8, %esi
    f61d:      	callq	*%rax
    f61f:      	cmpq	0x10(%rsp), %r12
    f624:      	je	0xf71c <generic_fentry_path+0x525c>
    f62a:      	leaq	0x18(%r12), %rbx
    f62f:      	movl	$0x4, %eax
    f634:      	movq	%rbp, %rdi
    f637:      	movl	$0x8, %esi
    f63c:      	movq	%rbx, %rdx
    f63f:      	callq	*%rax
    f641:      	cmpq	%r12, (%rsp)
    f645:      	je	0xf71c <generic_fentry_path+0x525c>
    f64b:      	movl	$0x4, %eax
    f650:      	leaq	0x8(%rsp), %rdi
    f655:      	movl	$0x8, %esi
    f65a:      	movq	%rbx, %rdx
    f65d:      	callq	*%rax
    f65f:      	addq	$0x20, %r12
    f663:      	movl	$0x4, %eax
    f668:      	leaq	0x58(%rsp), %rdi
    f66d:      	movl	$0x10, %ecx
    f672:      	movl	$0x10, %esi
    f677:      	movq	%r12, %rdx
    f67a:      	callq	*%rax
    f67c:      	movq	0x28(%rsp), %rbx
    f681:      	movq	0x48(%rsp), %rax
    f686:      	movl	0x5c(%rsp), %r15d
    f68b:      	subq	%rbx, %rax
    f68e:      	movl	0x50(%rsp), %r12d
    f693:      	movl	%r15d, %edx
    f696:      	subl	%r12d, %edx
    f699:      	movl	$0x0, %ecx
    f69e:      	cmovbl	%ecx, %edx
    f6a1:      	addq	0x60(%rsp), %rdx
    f6a6:      	xorl	%esi, %esi
    f6a8:      	cmpl	%r15d, %r12d
    f6ab:      	seta	%sil
    f6af:      	movl	%r15d, %ecx
    f6b2:      	cmovbl	%r12d, %ecx
    f6b6:      	addl	%ecx, %esi
    f6b8:      	movl	%r12d, %edi
    f6bb:      	subl	%esi, %edi
    f6bd:      	movl	%edi, 0x50(%rsp)
    f6c1:      	subq	%rsi, %rax
    f6c4:      	jb	0x15f32 <generic_fentry_path+0xba72>
    f6ca:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f6d0:      	ja	0x15f32 <generic_fentry_path+0xba72>
    f6d6:      	cmpl	%r15d, %r12d
    f6d9:      	jbe	0xf6df <generic_fentry_path+0x521f>
    f6db:      	movb	$0x2f, (%rbx,%rax)
    f6df:      	xorl	%edi, %edi
    f6e1:      	cmpl	%r15d, %r12d
    f6e4:      	seta	%dil
    f6e8:      	movzbl	%cl, %esi
    f6eb:      	addq	%rax, %rbx
    f6ee:      	addq	%rbx, %rdi
    f6f1:      	movl	$0x4, %eax
    f6f6:      	callq	*%rax
    f6f8:      	movq	%rbx, 0x48(%rsp)
    f6fd:      	cmpl	%r15d, %r12d
    f700:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    f706:      	movq	0x8(%rsp), %r12
    f70b:      	movq	%r12, 0x30(%rsp)
    f710:      	movq	0x38(%rsp), %rdx
    f715:      	movq	0x40(%rsp), %r15
    f71a:      	jmp	0xf76d <generic_fentry_path+0x52ad>
    f71c:      	leaq	0x10(%r15), %rdx
    f720:      	movl	$0x4, %eax
    f725:      	movq	%rbp, %rdi
    f728:      	movl	$0x8, %esi
    f72d:      	callq	*%rax
    f72f:      	movq	0x40(%rsp), %rax
    f734:      	cmpq	(%rsp), %rax
    f738:      	je	0x15f2d <generic_fentry_path+0xba6d>
    f73e:      	addq	$0x18, %r15
    f742:      	movl	$0x4, %eax
    f747:      	leaq	0x30(%rsp), %rdi
    f74c:      	movl	$0x8, %esi
    f751:      	movq	%r15, %rdx
    f754:      	callq	*%rax
    f756:      	movq	(%rsp), %r15
    f75a:      	movq	%r15, 0x40(%rsp)
    f75f:      	leaq	0x20(%r15), %rdx
    f763:      	movq	%rdx, 0x38(%rsp)
    f768:      	movq	0x30(%rsp), %r12
    f76d:      	cmpq	0x18(%rsp), %r12
    f772:      	jne	0xf77f <generic_fentry_path+0x52bf>
    f774:      	cmpq	0x20(%rsp), %rdx
    f779:      	je	0x15f2d <generic_fentry_path+0xba6d>
    f77f:      	movl	$0x4, %eax
    f784:      	leaq	0x10(%rsp), %rdi
    f789:      	movl	$0x8, %esi
    f78e:      	callq	*%rax
    f790:      	cmpq	0x10(%rsp), %r12
    f795:      	je	0xf88d <generic_fentry_path+0x53cd>
    f79b:      	leaq	0x18(%r12), %rbx
    f7a0:      	movl	$0x4, %eax
    f7a5:      	movq	%rbp, %rdi
    f7a8:      	movl	$0x8, %esi
    f7ad:      	movq	%rbx, %rdx
    f7b0:      	callq	*%rax
    f7b2:      	cmpq	%r12, (%rsp)
    f7b6:      	je	0xf88d <generic_fentry_path+0x53cd>
    f7bc:      	movl	$0x4, %eax
    f7c1:      	leaq	0x8(%rsp), %rdi
    f7c6:      	movl	$0x8, %esi
    f7cb:      	movq	%rbx, %rdx
    f7ce:      	callq	*%rax
    f7d0:      	addq	$0x20, %r12
    f7d4:      	movl	$0x4, %eax
    f7d9:      	leaq	0x58(%rsp), %rdi
    f7de:      	movl	$0x10, %ecx
    f7e3:      	movl	$0x10, %esi
    f7e8:      	movq	%r12, %rdx
    f7eb:      	callq	*%rax
    f7ed:      	movq	0x28(%rsp), %rbx
    f7f2:      	movq	0x48(%rsp), %rax
    f7f7:      	movl	0x5c(%rsp), %r15d
    f7fc:      	subq	%rbx, %rax
    f7ff:      	movl	0x50(%rsp), %r12d
    f804:      	movl	%r15d, %edx
    f807:      	subl	%r12d, %edx
    f80a:      	movl	$0x0, %ecx
    f80f:      	cmovbl	%ecx, %edx
    f812:      	addq	0x60(%rsp), %rdx
    f817:      	xorl	%esi, %esi
    f819:      	cmpl	%r15d, %r12d
    f81c:      	seta	%sil
    f820:      	movl	%r15d, %ecx
    f823:      	cmovbl	%r12d, %ecx
    f827:      	addl	%ecx, %esi
    f829:      	movl	%r12d, %edi
    f82c:      	subl	%esi, %edi
    f82e:      	movl	%edi, 0x50(%rsp)
    f832:      	subq	%rsi, %rax
    f835:      	jb	0x15f32 <generic_fentry_path+0xba72>
    f83b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f841:      	ja	0x15f32 <generic_fentry_path+0xba72>
    f847:      	cmpl	%r15d, %r12d
    f84a:      	jbe	0xf850 <generic_fentry_path+0x5390>
    f84c:      	movb	$0x2f, (%rbx,%rax)
    f850:      	xorl	%edi, %edi
    f852:      	cmpl	%r15d, %r12d
    f855:      	seta	%dil
    f859:      	movzbl	%cl, %esi
    f85c:      	addq	%rax, %rbx
    f85f:      	addq	%rbx, %rdi
    f862:      	movl	$0x4, %eax
    f867:      	callq	*%rax
    f869:      	movq	%rbx, 0x48(%rsp)
    f86e:      	cmpl	%r15d, %r12d
    f871:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    f877:      	movq	0x8(%rsp), %r12
    f87c:      	movq	%r12, 0x30(%rsp)
    f881:      	movq	0x38(%rsp), %rdx
    f886:      	movq	0x40(%rsp), %r15
    f88b:      	jmp	0xf8de <generic_fentry_path+0x541e>
    f88d:      	leaq	0x10(%r15), %rdx
    f891:      	movl	$0x4, %eax
    f896:      	movq	%rbp, %rdi
    f899:      	movl	$0x8, %esi
    f89e:      	callq	*%rax
    f8a0:      	movq	0x40(%rsp), %rax
    f8a5:      	cmpq	(%rsp), %rax
    f8a9:      	je	0x15f2d <generic_fentry_path+0xba6d>
    f8af:      	addq	$0x18, %r15
    f8b3:      	movl	$0x4, %eax
    f8b8:      	leaq	0x30(%rsp), %rdi
    f8bd:      	movl	$0x8, %esi
    f8c2:      	movq	%r15, %rdx
    f8c5:      	callq	*%rax
    f8c7:      	movq	(%rsp), %r15
    f8cb:      	movq	%r15, 0x40(%rsp)
    f8d0:      	leaq	0x20(%r15), %rdx
    f8d4:      	movq	%rdx, 0x38(%rsp)
    f8d9:      	movq	0x30(%rsp), %r12
    f8de:      	cmpq	0x18(%rsp), %r12
    f8e3:      	jne	0xf8f0 <generic_fentry_path+0x5430>
    f8e5:      	cmpq	0x20(%rsp), %rdx
    f8ea:      	je	0x15f2d <generic_fentry_path+0xba6d>
    f8f0:      	movl	$0x4, %eax
    f8f5:      	leaq	0x10(%rsp), %rdi
    f8fa:      	movl	$0x8, %esi
    f8ff:      	callq	*%rax
    f901:      	cmpq	0x10(%rsp), %r12
    f906:      	je	0xf9fe <generic_fentry_path+0x553e>
    f90c:      	leaq	0x18(%r12), %rbx
    f911:      	movl	$0x4, %eax
    f916:      	movq	%rbp, %rdi
    f919:      	movl	$0x8, %esi
    f91e:      	movq	%rbx, %rdx
    f921:      	callq	*%rax
    f923:      	cmpq	%r12, (%rsp)
    f927:      	je	0xf9fe <generic_fentry_path+0x553e>
    f92d:      	movl	$0x4, %eax
    f932:      	leaq	0x8(%rsp), %rdi
    f937:      	movl	$0x8, %esi
    f93c:      	movq	%rbx, %rdx
    f93f:      	callq	*%rax
    f941:      	addq	$0x20, %r12
    f945:      	movl	$0x4, %eax
    f94a:      	leaq	0x58(%rsp), %rdi
    f94f:      	movl	$0x10, %ecx
    f954:      	movl	$0x10, %esi
    f959:      	movq	%r12, %rdx
    f95c:      	callq	*%rax
    f95e:      	movq	0x28(%rsp), %rbx
    f963:      	movq	0x48(%rsp), %rax
    f968:      	movl	0x5c(%rsp), %r15d
    f96d:      	subq	%rbx, %rax
    f970:      	movl	0x50(%rsp), %r12d
    f975:      	movl	%r15d, %edx
    f978:      	subl	%r12d, %edx
    f97b:      	movl	$0x0, %ecx
    f980:      	cmovbl	%ecx, %edx
    f983:      	addq	0x60(%rsp), %rdx
    f988:      	xorl	%esi, %esi
    f98a:      	cmpl	%r15d, %r12d
    f98d:      	seta	%sil
    f991:      	movl	%r15d, %ecx
    f994:      	cmovbl	%r12d, %ecx
    f998:      	addl	%ecx, %esi
    f99a:      	movl	%r12d, %edi
    f99d:      	subl	%esi, %edi
    f99f:      	movl	%edi, 0x50(%rsp)
    f9a3:      	subq	%rsi, %rax
    f9a6:      	jb	0x15f32 <generic_fentry_path+0xba72>
    f9ac:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f9b2:      	ja	0x15f32 <generic_fentry_path+0xba72>
    f9b8:      	cmpl	%r15d, %r12d
    f9bb:      	jbe	0xf9c1 <generic_fentry_path+0x5501>
    f9bd:      	movb	$0x2f, (%rbx,%rax)
    f9c1:      	xorl	%edi, %edi
    f9c3:      	cmpl	%r15d, %r12d
    f9c6:      	seta	%dil
    f9ca:      	movzbl	%cl, %esi
    f9cd:      	addq	%rax, %rbx
    f9d0:      	addq	%rbx, %rdi
    f9d3:      	movl	$0x4, %eax
    f9d8:      	callq	*%rax
    f9da:      	movq	%rbx, 0x48(%rsp)
    f9df:      	cmpl	%r15d, %r12d
    f9e2:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    f9e8:      	movq	0x8(%rsp), %r12
    f9ed:      	movq	%r12, 0x30(%rsp)
    f9f2:      	movq	0x38(%rsp), %rdx
    f9f7:      	movq	0x40(%rsp), %r15
    f9fc:      	jmp	0xfa4f <generic_fentry_path+0x558f>
    f9fe:      	leaq	0x10(%r15), %rdx
    fa02:      	movl	$0x4, %eax
    fa07:      	movq	%rbp, %rdi
    fa0a:      	movl	$0x8, %esi
    fa0f:      	callq	*%rax
    fa11:      	movq	0x40(%rsp), %rax
    fa16:      	cmpq	(%rsp), %rax
    fa1a:      	je	0x15f2d <generic_fentry_path+0xba6d>
    fa20:      	addq	$0x18, %r15
    fa24:      	movl	$0x4, %eax
    fa29:      	leaq	0x30(%rsp), %rdi
    fa2e:      	movl	$0x8, %esi
    fa33:      	movq	%r15, %rdx
    fa36:      	callq	*%rax
    fa38:      	movq	(%rsp), %r15
    fa3c:      	movq	%r15, 0x40(%rsp)
    fa41:      	leaq	0x20(%r15), %rdx
    fa45:      	movq	%rdx, 0x38(%rsp)
    fa4a:      	movq	0x30(%rsp), %r12
    fa4f:      	cmpq	0x18(%rsp), %r12
    fa54:      	jne	0xfa61 <generic_fentry_path+0x55a1>
    fa56:      	cmpq	0x20(%rsp), %rdx
    fa5b:      	je	0x15f2d <generic_fentry_path+0xba6d>
    fa61:      	movl	$0x4, %eax
    fa66:      	leaq	0x10(%rsp), %rdi
    fa6b:      	movl	$0x8, %esi
    fa70:      	callq	*%rax
    fa72:      	cmpq	0x10(%rsp), %r12
    fa77:      	je	0xfb6f <generic_fentry_path+0x56af>
    fa7d:      	leaq	0x18(%r12), %rbx
    fa82:      	movl	$0x4, %eax
    fa87:      	movq	%rbp, %rdi
    fa8a:      	movl	$0x8, %esi
    fa8f:      	movq	%rbx, %rdx
    fa92:      	callq	*%rax
    fa94:      	cmpq	%r12, (%rsp)
    fa98:      	je	0xfb6f <generic_fentry_path+0x56af>
    fa9e:      	movl	$0x4, %eax
    faa3:      	leaq	0x8(%rsp), %rdi
    faa8:      	movl	$0x8, %esi
    faad:      	movq	%rbx, %rdx
    fab0:      	callq	*%rax
    fab2:      	addq	$0x20, %r12
    fab6:      	movl	$0x4, %eax
    fabb:      	leaq	0x58(%rsp), %rdi
    fac0:      	movl	$0x10, %ecx
    fac5:      	movl	$0x10, %esi
    faca:      	movq	%r12, %rdx
    facd:      	callq	*%rax
    facf:      	movq	0x28(%rsp), %rbx
    fad4:      	movq	0x48(%rsp), %rax
    fad9:      	movl	0x5c(%rsp), %r15d
    fade:      	subq	%rbx, %rax
    fae1:      	movl	0x50(%rsp), %r12d
    fae6:      	movl	%r15d, %edx
    fae9:      	subl	%r12d, %edx
    faec:      	movl	$0x0, %ecx
    faf1:      	cmovbl	%ecx, %edx
    faf4:      	addq	0x60(%rsp), %rdx
    faf9:      	xorl	%esi, %esi
    fafb:      	cmpl	%r15d, %r12d
    fafe:      	seta	%sil
    fb02:      	movl	%r15d, %ecx
    fb05:      	cmovbl	%r12d, %ecx
    fb09:      	addl	%ecx, %esi
    fb0b:      	movl	%r12d, %edi
    fb0e:      	subl	%esi, %edi
    fb10:      	movl	%edi, 0x50(%rsp)
    fb14:      	subq	%rsi, %rax
    fb17:      	jb	0x15f32 <generic_fentry_path+0xba72>
    fb1d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    fb23:      	ja	0x15f32 <generic_fentry_path+0xba72>
    fb29:      	cmpl	%r15d, %r12d
    fb2c:      	jbe	0xfb32 <generic_fentry_path+0x5672>
    fb2e:      	movb	$0x2f, (%rbx,%rax)
    fb32:      	xorl	%edi, %edi
    fb34:      	cmpl	%r15d, %r12d
    fb37:      	seta	%dil
    fb3b:      	movzbl	%cl, %esi
    fb3e:      	addq	%rax, %rbx
    fb41:      	addq	%rbx, %rdi
    fb44:      	movl	$0x4, %eax
    fb49:      	callq	*%rax
    fb4b:      	movq	%rbx, 0x48(%rsp)
    fb50:      	cmpl	%r15d, %r12d
    fb53:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    fb59:      	movq	0x8(%rsp), %r12
    fb5e:      	movq	%r12, 0x30(%rsp)
    fb63:      	movq	0x38(%rsp), %rdx
    fb68:      	movq	0x40(%rsp), %r15
    fb6d:      	jmp	0xfbc0 <generic_fentry_path+0x5700>
    fb6f:      	leaq	0x10(%r15), %rdx
    fb73:      	movl	$0x4, %eax
    fb78:      	movq	%rbp, %rdi
    fb7b:      	movl	$0x8, %esi
    fb80:      	callq	*%rax
    fb82:      	movq	0x40(%rsp), %rax
    fb87:      	cmpq	(%rsp), %rax
    fb8b:      	je	0x15f2d <generic_fentry_path+0xba6d>
    fb91:      	addq	$0x18, %r15
    fb95:      	movl	$0x4, %eax
    fb9a:      	leaq	0x30(%rsp), %rdi
    fb9f:      	movl	$0x8, %esi
    fba4:      	movq	%r15, %rdx
    fba7:      	callq	*%rax
    fba9:      	movq	(%rsp), %r15
    fbad:      	movq	%r15, 0x40(%rsp)
    fbb2:      	leaq	0x20(%r15), %rdx
    fbb6:      	movq	%rdx, 0x38(%rsp)
    fbbb:      	movq	0x30(%rsp), %r12
    fbc0:      	cmpq	0x18(%rsp), %r12
    fbc5:      	jne	0xfbd2 <generic_fentry_path+0x5712>
    fbc7:      	cmpq	0x20(%rsp), %rdx
    fbcc:      	je	0x15f2d <generic_fentry_path+0xba6d>
    fbd2:      	movl	$0x4, %eax
    fbd7:      	leaq	0x10(%rsp), %rdi
    fbdc:      	movl	$0x8, %esi
    fbe1:      	callq	*%rax
    fbe3:      	cmpq	0x10(%rsp), %r12
    fbe8:      	je	0xfce0 <generic_fentry_path+0x5820>
    fbee:      	leaq	0x18(%r12), %rbx
    fbf3:      	movl	$0x4, %eax
    fbf8:      	movq	%rbp, %rdi
    fbfb:      	movl	$0x8, %esi
    fc00:      	movq	%rbx, %rdx
    fc03:      	callq	*%rax
    fc05:      	cmpq	%r12, (%rsp)
    fc09:      	je	0xfce0 <generic_fentry_path+0x5820>
    fc0f:      	movl	$0x4, %eax
    fc14:      	leaq	0x8(%rsp), %rdi
    fc19:      	movl	$0x8, %esi
    fc1e:      	movq	%rbx, %rdx
    fc21:      	callq	*%rax
    fc23:      	addq	$0x20, %r12
    fc27:      	movl	$0x4, %eax
    fc2c:      	leaq	0x58(%rsp), %rdi
    fc31:      	movl	$0x10, %ecx
    fc36:      	movl	$0x10, %esi
    fc3b:      	movq	%r12, %rdx
    fc3e:      	callq	*%rax
    fc40:      	movq	0x28(%rsp), %rbx
    fc45:      	movq	0x48(%rsp), %rax
    fc4a:      	movl	0x5c(%rsp), %r15d
    fc4f:      	subq	%rbx, %rax
    fc52:      	movl	0x50(%rsp), %r12d
    fc57:      	movl	%r15d, %edx
    fc5a:      	subl	%r12d, %edx
    fc5d:      	movl	$0x0, %ecx
    fc62:      	cmovbl	%ecx, %edx
    fc65:      	addq	0x60(%rsp), %rdx
    fc6a:      	xorl	%esi, %esi
    fc6c:      	cmpl	%r15d, %r12d
    fc6f:      	seta	%sil
    fc73:      	movl	%r15d, %ecx
    fc76:      	cmovbl	%r12d, %ecx
    fc7a:      	addl	%ecx, %esi
    fc7c:      	movl	%r12d, %edi
    fc7f:      	subl	%esi, %edi
    fc81:      	movl	%edi, 0x50(%rsp)
    fc85:      	subq	%rsi, %rax
    fc88:      	jb	0x15f32 <generic_fentry_path+0xba72>
    fc8e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    fc94:      	ja	0x15f32 <generic_fentry_path+0xba72>
    fc9a:      	cmpl	%r15d, %r12d
    fc9d:      	jbe	0xfca3 <generic_fentry_path+0x57e3>
    fc9f:      	movb	$0x2f, (%rbx,%rax)
    fca3:      	xorl	%edi, %edi
    fca5:      	cmpl	%r15d, %r12d
    fca8:      	seta	%dil
    fcac:      	movzbl	%cl, %esi
    fcaf:      	addq	%rax, %rbx
    fcb2:      	addq	%rbx, %rdi
    fcb5:      	movl	$0x4, %eax
    fcba:      	callq	*%rax
    fcbc:      	movq	%rbx, 0x48(%rsp)
    fcc1:      	cmpl	%r15d, %r12d
    fcc4:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    fcca:      	movq	0x8(%rsp), %r12
    fccf:      	movq	%r12, 0x30(%rsp)
    fcd4:      	movq	0x38(%rsp), %rdx
    fcd9:      	movq	0x40(%rsp), %r15
    fcde:      	jmp	0xfd31 <generic_fentry_path+0x5871>
    fce0:      	leaq	0x10(%r15), %rdx
    fce4:      	movl	$0x4, %eax
    fce9:      	movq	%rbp, %rdi
    fcec:      	movl	$0x8, %esi
    fcf1:      	callq	*%rax
    fcf3:      	movq	0x40(%rsp), %rax
    fcf8:      	cmpq	(%rsp), %rax
    fcfc:      	je	0x15f2d <generic_fentry_path+0xba6d>
    fd02:      	addq	$0x18, %r15
    fd06:      	movl	$0x4, %eax
    fd0b:      	leaq	0x30(%rsp), %rdi
    fd10:      	movl	$0x8, %esi
    fd15:      	movq	%r15, %rdx
    fd18:      	callq	*%rax
    fd1a:      	movq	(%rsp), %r15
    fd1e:      	movq	%r15, 0x40(%rsp)
    fd23:      	leaq	0x20(%r15), %rdx
    fd27:      	movq	%rdx, 0x38(%rsp)
    fd2c:      	movq	0x30(%rsp), %r12
    fd31:      	cmpq	0x18(%rsp), %r12
    fd36:      	jne	0xfd43 <generic_fentry_path+0x5883>
    fd38:      	cmpq	0x20(%rsp), %rdx
    fd3d:      	je	0x15f2d <generic_fentry_path+0xba6d>
    fd43:      	movl	$0x4, %eax
    fd48:      	leaq	0x10(%rsp), %rdi
    fd4d:      	movl	$0x8, %esi
    fd52:      	callq	*%rax
    fd54:      	cmpq	0x10(%rsp), %r12
    fd59:      	je	0xfe51 <generic_fentry_path+0x5991>
    fd5f:      	leaq	0x18(%r12), %rbx
    fd64:      	movl	$0x4, %eax
    fd69:      	movq	%rbp, %rdi
    fd6c:      	movl	$0x8, %esi
    fd71:      	movq	%rbx, %rdx
    fd74:      	callq	*%rax
    fd76:      	cmpq	%r12, (%rsp)
    fd7a:      	je	0xfe51 <generic_fentry_path+0x5991>
    fd80:      	movl	$0x4, %eax
    fd85:      	leaq	0x8(%rsp), %rdi
    fd8a:      	movl	$0x8, %esi
    fd8f:      	movq	%rbx, %rdx
    fd92:      	callq	*%rax
    fd94:      	addq	$0x20, %r12
    fd98:      	movl	$0x4, %eax
    fd9d:      	leaq	0x58(%rsp), %rdi
    fda2:      	movl	$0x10, %ecx
    fda7:      	movl	$0x10, %esi
    fdac:      	movq	%r12, %rdx
    fdaf:      	callq	*%rax
    fdb1:      	movq	0x28(%rsp), %rbx
    fdb6:      	movq	0x48(%rsp), %rax
    fdbb:      	movl	0x5c(%rsp), %r15d
    fdc0:      	subq	%rbx, %rax
    fdc3:      	movl	0x50(%rsp), %r12d
    fdc8:      	movl	%r15d, %edx
    fdcb:      	subl	%r12d, %edx
    fdce:      	movl	$0x0, %ecx
    fdd3:      	cmovbl	%ecx, %edx
    fdd6:      	addq	0x60(%rsp), %rdx
    fddb:      	xorl	%esi, %esi
    fddd:      	cmpl	%r15d, %r12d
    fde0:      	seta	%sil
    fde4:      	movl	%r15d, %ecx
    fde7:      	cmovbl	%r12d, %ecx
    fdeb:      	addl	%ecx, %esi
    fded:      	movl	%r12d, %edi
    fdf0:      	subl	%esi, %edi
    fdf2:      	movl	%edi, 0x50(%rsp)
    fdf6:      	subq	%rsi, %rax
    fdf9:      	jb	0x15f32 <generic_fentry_path+0xba72>
    fdff:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    fe05:      	ja	0x15f32 <generic_fentry_path+0xba72>
    fe0b:      	cmpl	%r15d, %r12d
    fe0e:      	jbe	0xfe14 <generic_fentry_path+0x5954>
    fe10:      	movb	$0x2f, (%rbx,%rax)
    fe14:      	xorl	%edi, %edi
    fe16:      	cmpl	%r15d, %r12d
    fe19:      	seta	%dil
    fe1d:      	movzbl	%cl, %esi
    fe20:      	addq	%rax, %rbx
    fe23:      	addq	%rbx, %rdi
    fe26:      	movl	$0x4, %eax
    fe2b:      	callq	*%rax
    fe2d:      	movq	%rbx, 0x48(%rsp)
    fe32:      	cmpl	%r15d, %r12d
    fe35:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    fe3b:      	movq	0x8(%rsp), %r12
    fe40:      	movq	%r12, 0x30(%rsp)
    fe45:      	movq	0x38(%rsp), %rdx
    fe4a:      	movq	0x40(%rsp), %r15
    fe4f:      	jmp	0xfea2 <generic_fentry_path+0x59e2>
    fe51:      	leaq	0x10(%r15), %rdx
    fe55:      	movl	$0x4, %eax
    fe5a:      	movq	%rbp, %rdi
    fe5d:      	movl	$0x8, %esi
    fe62:      	callq	*%rax
    fe64:      	movq	0x40(%rsp), %rax
    fe69:      	cmpq	(%rsp), %rax
    fe6d:      	je	0x15f2d <generic_fentry_path+0xba6d>
    fe73:      	addq	$0x18, %r15
    fe77:      	movl	$0x4, %eax
    fe7c:      	leaq	0x30(%rsp), %rdi
    fe81:      	movl	$0x8, %esi
    fe86:      	movq	%r15, %rdx
    fe89:      	callq	*%rax
    fe8b:      	movq	(%rsp), %r15
    fe8f:      	movq	%r15, 0x40(%rsp)
    fe94:      	leaq	0x20(%r15), %rdx
    fe98:      	movq	%rdx, 0x38(%rsp)
    fe9d:      	movq	0x30(%rsp), %r12
    fea2:      	cmpq	0x18(%rsp), %r12
    fea7:      	jne	0xfeb4 <generic_fentry_path+0x59f4>
    fea9:      	cmpq	0x20(%rsp), %rdx
    feae:      	je	0x15f2d <generic_fentry_path+0xba6d>
    feb4:      	movl	$0x4, %eax
    feb9:      	leaq	0x10(%rsp), %rdi
    febe:      	movl	$0x8, %esi
    fec3:      	callq	*%rax
    fec5:      	cmpq	0x10(%rsp), %r12
    feca:      	je	0xffc2 <generic_fentry_path+0x5b02>
    fed0:      	leaq	0x18(%r12), %rbx
    fed5:      	movl	$0x4, %eax
    feda:      	movq	%rbp, %rdi
    fedd:      	movl	$0x8, %esi
    fee2:      	movq	%rbx, %rdx
    fee5:      	callq	*%rax
    fee7:      	cmpq	%r12, (%rsp)
    feeb:      	je	0xffc2 <generic_fentry_path+0x5b02>
    fef1:      	movl	$0x4, %eax
    fef6:      	leaq	0x8(%rsp), %rdi
    fefb:      	movl	$0x8, %esi
    ff00:      	movq	%rbx, %rdx
    ff03:      	callq	*%rax
    ff05:      	addq	$0x20, %r12
    ff09:      	movl	$0x4, %eax
    ff0e:      	leaq	0x58(%rsp), %rdi
    ff13:      	movl	$0x10, %ecx
    ff18:      	movl	$0x10, %esi
    ff1d:      	movq	%r12, %rdx
    ff20:      	callq	*%rax
    ff22:      	movq	0x28(%rsp), %rbx
    ff27:      	movq	0x48(%rsp), %rax
    ff2c:      	movl	0x5c(%rsp), %r15d
    ff31:      	subq	%rbx, %rax
    ff34:      	movl	0x50(%rsp), %r12d
    ff39:      	movl	%r15d, %edx
    ff3c:      	subl	%r12d, %edx
    ff3f:      	movl	$0x0, %ecx
    ff44:      	cmovbl	%ecx, %edx
    ff47:      	addq	0x60(%rsp), %rdx
    ff4c:      	xorl	%esi, %esi
    ff4e:      	cmpl	%r15d, %r12d
    ff51:      	seta	%sil
    ff55:      	movl	%r15d, %ecx
    ff58:      	cmovbl	%r12d, %ecx
    ff5c:      	addl	%ecx, %esi
    ff5e:      	movl	%r12d, %edi
    ff61:      	subl	%esi, %edi
    ff63:      	movl	%edi, 0x50(%rsp)
    ff67:      	subq	%rsi, %rax
    ff6a:      	jb	0x15f32 <generic_fentry_path+0xba72>
    ff70:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ff76:      	ja	0x15f32 <generic_fentry_path+0xba72>
    ff7c:      	cmpl	%r15d, %r12d
    ff7f:      	jbe	0xff85 <generic_fentry_path+0x5ac5>
    ff81:      	movb	$0x2f, (%rbx,%rax)
    ff85:      	xorl	%edi, %edi
    ff87:      	cmpl	%r15d, %r12d
    ff8a:      	seta	%dil
    ff8e:      	movzbl	%cl, %esi
    ff91:      	addq	%rax, %rbx
    ff94:      	addq	%rbx, %rdi
    ff97:      	movl	$0x4, %eax
    ff9c:      	callq	*%rax
    ff9e:      	movq	%rbx, 0x48(%rsp)
    ffa3:      	cmpl	%r15d, %r12d
    ffa6:      	jbe	0x15f32 <generic_fentry_path+0xba72>
    ffac:      	movq	0x8(%rsp), %r12
    ffb1:      	movq	%r12, 0x30(%rsp)
    ffb6:      	movq	0x38(%rsp), %rdx
    ffbb:      	movq	0x40(%rsp), %r15
    ffc0:      	jmp	0x10013 <generic_fentry_path+0x5b53>
    ffc2:      	leaq	0x10(%r15), %rdx
    ffc6:      	movl	$0x4, %eax
    ffcb:      	movq	%rbp, %rdi
    ffce:      	movl	$0x8, %esi
    ffd3:      	callq	*%rax
    ffd5:      	movq	0x40(%rsp), %rax
    ffda:      	cmpq	(%rsp), %rax
    ffde:      	je	0x15f2d <generic_fentry_path+0xba6d>
    ffe4:      	addq	$0x18, %r15
    ffe8:      	movl	$0x4, %eax
    ffed:      	leaq	0x30(%rsp), %rdi
    fff2:      	movl	$0x8, %esi
    fff7:      	movq	%r15, %rdx
    fffa:      	callq	*%rax
    fffc:      	movq	(%rsp), %r15
   10000:      	movq	%r15, 0x40(%rsp)
   10005:      	leaq	0x20(%r15), %rdx
   10009:      	movq	%rdx, 0x38(%rsp)
   1000e:      	movq	0x30(%rsp), %r12
   10013:      	cmpq	0x18(%rsp), %r12
   10018:      	jne	0x10025 <generic_fentry_path+0x5b65>
   1001a:      	cmpq	0x20(%rsp), %rdx
   1001f:      	je	0x15f2d <generic_fentry_path+0xba6d>
   10025:      	movl	$0x4, %eax
   1002a:      	leaq	0x10(%rsp), %rdi
   1002f:      	movl	$0x8, %esi
   10034:      	callq	*%rax
   10036:      	cmpq	0x10(%rsp), %r12
   1003b:      	je	0x10133 <generic_fentry_path+0x5c73>
   10041:      	leaq	0x18(%r12), %rbx
   10046:      	movl	$0x4, %eax
   1004b:      	movq	%rbp, %rdi
   1004e:      	movl	$0x8, %esi
   10053:      	movq	%rbx, %rdx
   10056:      	callq	*%rax
   10058:      	cmpq	%r12, (%rsp)
   1005c:      	je	0x10133 <generic_fentry_path+0x5c73>
   10062:      	movl	$0x4, %eax
   10067:      	leaq	0x8(%rsp), %rdi
   1006c:      	movl	$0x8, %esi
   10071:      	movq	%rbx, %rdx
   10074:      	callq	*%rax
   10076:      	addq	$0x20, %r12
   1007a:      	movl	$0x4, %eax
   1007f:      	leaq	0x58(%rsp), %rdi
   10084:      	movl	$0x10, %ecx
   10089:      	movl	$0x10, %esi
   1008e:      	movq	%r12, %rdx
   10091:      	callq	*%rax
   10093:      	movq	0x28(%rsp), %rbx
   10098:      	movq	0x48(%rsp), %rax
   1009d:      	movl	0x5c(%rsp), %r15d
   100a2:      	subq	%rbx, %rax
   100a5:      	movl	0x50(%rsp), %r12d
   100aa:      	movl	%r15d, %edx
   100ad:      	subl	%r12d, %edx
   100b0:      	movl	$0x0, %ecx
   100b5:      	cmovbl	%ecx, %edx
   100b8:      	addq	0x60(%rsp), %rdx
   100bd:      	xorl	%esi, %esi
   100bf:      	cmpl	%r15d, %r12d
   100c2:      	seta	%sil
   100c6:      	movl	%r15d, %ecx
   100c9:      	cmovbl	%r12d, %ecx
   100cd:      	addl	%ecx, %esi
   100cf:      	movl	%r12d, %edi
   100d2:      	subl	%esi, %edi
   100d4:      	movl	%edi, 0x50(%rsp)
   100d8:      	subq	%rsi, %rax
   100db:      	jb	0x15f32 <generic_fentry_path+0xba72>
   100e1:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   100e7:      	ja	0x15f32 <generic_fentry_path+0xba72>
   100ed:      	cmpl	%r15d, %r12d
   100f0:      	jbe	0x100f6 <generic_fentry_path+0x5c36>
   100f2:      	movb	$0x2f, (%rbx,%rax)
   100f6:      	xorl	%edi, %edi
   100f8:      	cmpl	%r15d, %r12d
   100fb:      	seta	%dil
   100ff:      	movzbl	%cl, %esi
   10102:      	addq	%rax, %rbx
   10105:      	addq	%rbx, %rdi
   10108:      	movl	$0x4, %eax
   1010d:      	callq	*%rax
   1010f:      	movq	%rbx, 0x48(%rsp)
   10114:      	cmpl	%r15d, %r12d
   10117:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   1011d:      	movq	0x8(%rsp), %r12
   10122:      	movq	%r12, 0x30(%rsp)
   10127:      	movq	0x38(%rsp), %rdx
   1012c:      	movq	0x40(%rsp), %r15
   10131:      	jmp	0x10184 <generic_fentry_path+0x5cc4>
   10133:      	leaq	0x10(%r15), %rdx
   10137:      	movl	$0x4, %eax
   1013c:      	movq	%rbp, %rdi
   1013f:      	movl	$0x8, %esi
   10144:      	callq	*%rax
   10146:      	movq	0x40(%rsp), %rax
   1014b:      	cmpq	(%rsp), %rax
   1014f:      	je	0x15f2d <generic_fentry_path+0xba6d>
   10155:      	addq	$0x18, %r15
   10159:      	movl	$0x4, %eax
   1015e:      	leaq	0x30(%rsp), %rdi
   10163:      	movl	$0x8, %esi
   10168:      	movq	%r15, %rdx
   1016b:      	callq	*%rax
   1016d:      	movq	(%rsp), %r15
   10171:      	movq	%r15, 0x40(%rsp)
   10176:      	leaq	0x20(%r15), %rdx
   1017a:      	movq	%rdx, 0x38(%rsp)
   1017f:      	movq	0x30(%rsp), %r12
   10184:      	cmpq	0x18(%rsp), %r12
   10189:      	jne	0x10196 <generic_fentry_path+0x5cd6>
   1018b:      	cmpq	0x20(%rsp), %rdx
   10190:      	je	0x15f2d <generic_fentry_path+0xba6d>
   10196:      	movl	$0x4, %eax
   1019b:      	leaq	0x10(%rsp), %rdi
   101a0:      	movl	$0x8, %esi
   101a5:      	callq	*%rax
   101a7:      	cmpq	0x10(%rsp), %r12
   101ac:      	je	0x102a4 <generic_fentry_path+0x5de4>
   101b2:      	leaq	0x18(%r12), %rbx
   101b7:      	movl	$0x4, %eax
   101bc:      	movq	%rbp, %rdi
   101bf:      	movl	$0x8, %esi
   101c4:      	movq	%rbx, %rdx
   101c7:      	callq	*%rax
   101c9:      	cmpq	%r12, (%rsp)
   101cd:      	je	0x102a4 <generic_fentry_path+0x5de4>
   101d3:      	movl	$0x4, %eax
   101d8:      	leaq	0x8(%rsp), %rdi
   101dd:      	movl	$0x8, %esi
   101e2:      	movq	%rbx, %rdx
   101e5:      	callq	*%rax
   101e7:      	addq	$0x20, %r12
   101eb:      	movl	$0x4, %eax
   101f0:      	leaq	0x58(%rsp), %rdi
   101f5:      	movl	$0x10, %ecx
   101fa:      	movl	$0x10, %esi
   101ff:      	movq	%r12, %rdx
   10202:      	callq	*%rax
   10204:      	movq	0x28(%rsp), %rbx
   10209:      	movq	0x48(%rsp), %rax
   1020e:      	movl	0x5c(%rsp), %r15d
   10213:      	subq	%rbx, %rax
   10216:      	movl	0x50(%rsp), %r12d
   1021b:      	movl	%r15d, %edx
   1021e:      	subl	%r12d, %edx
   10221:      	movl	$0x0, %ecx
   10226:      	cmovbl	%ecx, %edx
   10229:      	addq	0x60(%rsp), %rdx
   1022e:      	xorl	%esi, %esi
   10230:      	cmpl	%r15d, %r12d
   10233:      	seta	%sil
   10237:      	movl	%r15d, %ecx
   1023a:      	cmovbl	%r12d, %ecx
   1023e:      	addl	%ecx, %esi
   10240:      	movl	%r12d, %edi
   10243:      	subl	%esi, %edi
   10245:      	movl	%edi, 0x50(%rsp)
   10249:      	subq	%rsi, %rax
   1024c:      	jb	0x15f32 <generic_fentry_path+0xba72>
   10252:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10258:      	ja	0x15f32 <generic_fentry_path+0xba72>
   1025e:      	cmpl	%r15d, %r12d
   10261:      	jbe	0x10267 <generic_fentry_path+0x5da7>
   10263:      	movb	$0x2f, (%rbx,%rax)
   10267:      	xorl	%edi, %edi
   10269:      	cmpl	%r15d, %r12d
   1026c:      	seta	%dil
   10270:      	movzbl	%cl, %esi
   10273:      	addq	%rax, %rbx
   10276:      	addq	%rbx, %rdi
   10279:      	movl	$0x4, %eax
   1027e:      	callq	*%rax
   10280:      	movq	%rbx, 0x48(%rsp)
   10285:      	cmpl	%r15d, %r12d
   10288:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   1028e:      	movq	0x8(%rsp), %r12
   10293:      	movq	%r12, 0x30(%rsp)
   10298:      	movq	0x38(%rsp), %rdx
   1029d:      	movq	0x40(%rsp), %r15
   102a2:      	jmp	0x102f5 <generic_fentry_path+0x5e35>
   102a4:      	leaq	0x10(%r15), %rdx
   102a8:      	movl	$0x4, %eax
   102ad:      	movq	%rbp, %rdi
   102b0:      	movl	$0x8, %esi
   102b5:      	callq	*%rax
   102b7:      	movq	0x40(%rsp), %rax
   102bc:      	cmpq	(%rsp), %rax
   102c0:      	je	0x15f2d <generic_fentry_path+0xba6d>
   102c6:      	addq	$0x18, %r15
   102ca:      	movl	$0x4, %eax
   102cf:      	leaq	0x30(%rsp), %rdi
   102d4:      	movl	$0x8, %esi
   102d9:      	movq	%r15, %rdx
   102dc:      	callq	*%rax
   102de:      	movq	(%rsp), %r15
   102e2:      	movq	%r15, 0x40(%rsp)
   102e7:      	leaq	0x20(%r15), %rdx
   102eb:      	movq	%rdx, 0x38(%rsp)
   102f0:      	movq	0x30(%rsp), %r12
   102f5:      	cmpq	0x18(%rsp), %r12
   102fa:      	jne	0x10307 <generic_fentry_path+0x5e47>
   102fc:      	cmpq	0x20(%rsp), %rdx
   10301:      	je	0x15f2d <generic_fentry_path+0xba6d>
   10307:      	movl	$0x4, %eax
   1030c:      	leaq	0x10(%rsp), %rdi
   10311:      	movl	$0x8, %esi
   10316:      	callq	*%rax
   10318:      	cmpq	0x10(%rsp), %r12
   1031d:      	je	0x10415 <generic_fentry_path+0x5f55>
   10323:      	leaq	0x18(%r12), %rbx
   10328:      	movl	$0x4, %eax
   1032d:      	movq	%rbp, %rdi
   10330:      	movl	$0x8, %esi
   10335:      	movq	%rbx, %rdx
   10338:      	callq	*%rax
   1033a:      	cmpq	%r12, (%rsp)
   1033e:      	je	0x10415 <generic_fentry_path+0x5f55>
   10344:      	movl	$0x4, %eax
   10349:      	leaq	0x8(%rsp), %rdi
   1034e:      	movl	$0x8, %esi
   10353:      	movq	%rbx, %rdx
   10356:      	callq	*%rax
   10358:      	addq	$0x20, %r12
   1035c:      	movl	$0x4, %eax
   10361:      	leaq	0x58(%rsp), %rdi
   10366:      	movl	$0x10, %ecx
   1036b:      	movl	$0x10, %esi
   10370:      	movq	%r12, %rdx
   10373:      	callq	*%rax
   10375:      	movq	0x28(%rsp), %rbx
   1037a:      	movq	0x48(%rsp), %rax
   1037f:      	movl	0x5c(%rsp), %r15d
   10384:      	subq	%rbx, %rax
   10387:      	movl	0x50(%rsp), %r12d
   1038c:      	movl	%r15d, %edx
   1038f:      	subl	%r12d, %edx
   10392:      	movl	$0x0, %ecx
   10397:      	cmovbl	%ecx, %edx
   1039a:      	addq	0x60(%rsp), %rdx
   1039f:      	xorl	%esi, %esi
   103a1:      	cmpl	%r15d, %r12d
   103a4:      	seta	%sil
   103a8:      	movl	%r15d, %ecx
   103ab:      	cmovbl	%r12d, %ecx
   103af:      	addl	%ecx, %esi
   103b1:      	movl	%r12d, %edi
   103b4:      	subl	%esi, %edi
   103b6:      	movl	%edi, 0x50(%rsp)
   103ba:      	subq	%rsi, %rax
   103bd:      	jb	0x15f32 <generic_fentry_path+0xba72>
   103c3:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   103c9:      	ja	0x15f32 <generic_fentry_path+0xba72>
   103cf:      	cmpl	%r15d, %r12d
   103d2:      	jbe	0x103d8 <generic_fentry_path+0x5f18>
   103d4:      	movb	$0x2f, (%rbx,%rax)
   103d8:      	xorl	%edi, %edi
   103da:      	cmpl	%r15d, %r12d
   103dd:      	seta	%dil
   103e1:      	movzbl	%cl, %esi
   103e4:      	addq	%rax, %rbx
   103e7:      	addq	%rbx, %rdi
   103ea:      	movl	$0x4, %eax
   103ef:      	callq	*%rax
   103f1:      	movq	%rbx, 0x48(%rsp)
   103f6:      	cmpl	%r15d, %r12d
   103f9:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   103ff:      	movq	0x8(%rsp), %r12
   10404:      	movq	%r12, 0x30(%rsp)
   10409:      	movq	0x38(%rsp), %rdx
   1040e:      	movq	0x40(%rsp), %r15
   10413:      	jmp	0x10466 <generic_fentry_path+0x5fa6>
   10415:      	leaq	0x10(%r15), %rdx
   10419:      	movl	$0x4, %eax
   1041e:      	movq	%rbp, %rdi
   10421:      	movl	$0x8, %esi
   10426:      	callq	*%rax
   10428:      	movq	0x40(%rsp), %rax
   1042d:      	cmpq	(%rsp), %rax
   10431:      	je	0x15f2d <generic_fentry_path+0xba6d>
   10437:      	addq	$0x18, %r15
   1043b:      	movl	$0x4, %eax
   10440:      	leaq	0x30(%rsp), %rdi
   10445:      	movl	$0x8, %esi
   1044a:      	movq	%r15, %rdx
   1044d:      	callq	*%rax
   1044f:      	movq	(%rsp), %r15
   10453:      	movq	%r15, 0x40(%rsp)
   10458:      	leaq	0x20(%r15), %rdx
   1045c:      	movq	%rdx, 0x38(%rsp)
   10461:      	movq	0x30(%rsp), %r12
   10466:      	cmpq	0x18(%rsp), %r12
   1046b:      	jne	0x10478 <generic_fentry_path+0x5fb8>
   1046d:      	cmpq	0x20(%rsp), %rdx
   10472:      	je	0x15f2d <generic_fentry_path+0xba6d>
   10478:      	movl	$0x4, %eax
   1047d:      	leaq	0x10(%rsp), %rdi
   10482:      	movl	$0x8, %esi
   10487:      	callq	*%rax
   10489:      	cmpq	0x10(%rsp), %r12
   1048e:      	je	0x10586 <generic_fentry_path+0x60c6>
   10494:      	leaq	0x18(%r12), %rbx
   10499:      	movl	$0x4, %eax
   1049e:      	movq	%rbp, %rdi
   104a1:      	movl	$0x8, %esi
   104a6:      	movq	%rbx, %rdx
   104a9:      	callq	*%rax
   104ab:      	cmpq	%r12, (%rsp)
   104af:      	je	0x10586 <generic_fentry_path+0x60c6>
   104b5:      	movl	$0x4, %eax
   104ba:      	leaq	0x8(%rsp), %rdi
   104bf:      	movl	$0x8, %esi
   104c4:      	movq	%rbx, %rdx
   104c7:      	callq	*%rax
   104c9:      	addq	$0x20, %r12
   104cd:      	movl	$0x4, %eax
   104d2:      	leaq	0x58(%rsp), %rdi
   104d7:      	movl	$0x10, %ecx
   104dc:      	movl	$0x10, %esi
   104e1:      	movq	%r12, %rdx
   104e4:      	callq	*%rax
   104e6:      	movq	0x28(%rsp), %rbx
   104eb:      	movq	0x48(%rsp), %rax
   104f0:      	movl	0x5c(%rsp), %r15d
   104f5:      	subq	%rbx, %rax
   104f8:      	movl	0x50(%rsp), %r12d
   104fd:      	movl	%r15d, %edx
   10500:      	subl	%r12d, %edx
   10503:      	movl	$0x0, %ecx
   10508:      	cmovbl	%ecx, %edx
   1050b:      	addq	0x60(%rsp), %rdx
   10510:      	xorl	%esi, %esi
   10512:      	cmpl	%r15d, %r12d
   10515:      	seta	%sil
   10519:      	movl	%r15d, %ecx
   1051c:      	cmovbl	%r12d, %ecx
   10520:      	addl	%ecx, %esi
   10522:      	movl	%r12d, %edi
   10525:      	subl	%esi, %edi
   10527:      	movl	%edi, 0x50(%rsp)
   1052b:      	subq	%rsi, %rax
   1052e:      	jb	0x15f32 <generic_fentry_path+0xba72>
   10534:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1053a:      	ja	0x15f32 <generic_fentry_path+0xba72>
   10540:      	cmpl	%r15d, %r12d
   10543:      	jbe	0x10549 <generic_fentry_path+0x6089>
   10545:      	movb	$0x2f, (%rbx,%rax)
   10549:      	xorl	%edi, %edi
   1054b:      	cmpl	%r15d, %r12d
   1054e:      	seta	%dil
   10552:      	movzbl	%cl, %esi
   10555:      	addq	%rax, %rbx
   10558:      	addq	%rbx, %rdi
   1055b:      	movl	$0x4, %eax
   10560:      	callq	*%rax
   10562:      	movq	%rbx, 0x48(%rsp)
   10567:      	cmpl	%r15d, %r12d
   1056a:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   10570:      	movq	0x8(%rsp), %r12
   10575:      	movq	%r12, 0x30(%rsp)
   1057a:      	movq	0x38(%rsp), %rdx
   1057f:      	movq	0x40(%rsp), %r15
   10584:      	jmp	0x105d7 <generic_fentry_path+0x6117>
   10586:      	leaq	0x10(%r15), %rdx
   1058a:      	movl	$0x4, %eax
   1058f:      	movq	%rbp, %rdi
   10592:      	movl	$0x8, %esi
   10597:      	callq	*%rax
   10599:      	movq	0x40(%rsp), %rax
   1059e:      	cmpq	(%rsp), %rax
   105a2:      	je	0x15f2d <generic_fentry_path+0xba6d>
   105a8:      	addq	$0x18, %r15
   105ac:      	movl	$0x4, %eax
   105b1:      	leaq	0x30(%rsp), %rdi
   105b6:      	movl	$0x8, %esi
   105bb:      	movq	%r15, %rdx
   105be:      	callq	*%rax
   105c0:      	movq	(%rsp), %r15
   105c4:      	movq	%r15, 0x40(%rsp)
   105c9:      	leaq	0x20(%r15), %rdx
   105cd:      	movq	%rdx, 0x38(%rsp)
   105d2:      	movq	0x30(%rsp), %r12
   105d7:      	cmpq	0x18(%rsp), %r12
   105dc:      	jne	0x105e9 <generic_fentry_path+0x6129>
   105de:      	cmpq	0x20(%rsp), %rdx
   105e3:      	je	0x15f2d <generic_fentry_path+0xba6d>
   105e9:      	movl	$0x4, %eax
   105ee:      	leaq	0x10(%rsp), %rdi
   105f3:      	movl	$0x8, %esi
   105f8:      	callq	*%rax
   105fa:      	cmpq	0x10(%rsp), %r12
   105ff:      	je	0x106f7 <generic_fentry_path+0x6237>
   10605:      	leaq	0x18(%r12), %rbx
   1060a:      	movl	$0x4, %eax
   1060f:      	movq	%rbp, %rdi
   10612:      	movl	$0x8, %esi
   10617:      	movq	%rbx, %rdx
   1061a:      	callq	*%rax
   1061c:      	cmpq	%r12, (%rsp)
   10620:      	je	0x106f7 <generic_fentry_path+0x6237>
   10626:      	movl	$0x4, %eax
   1062b:      	leaq	0x8(%rsp), %rdi
   10630:      	movl	$0x8, %esi
   10635:      	movq	%rbx, %rdx
   10638:      	callq	*%rax
   1063a:      	addq	$0x20, %r12
   1063e:      	movl	$0x4, %eax
   10643:      	leaq	0x58(%rsp), %rdi
   10648:      	movl	$0x10, %ecx
   1064d:      	movl	$0x10, %esi
   10652:      	movq	%r12, %rdx
   10655:      	callq	*%rax
   10657:      	movq	0x28(%rsp), %rbx
   1065c:      	movq	0x48(%rsp), %rax
   10661:      	movl	0x5c(%rsp), %r15d
   10666:      	subq	%rbx, %rax
   10669:      	movl	0x50(%rsp), %r12d
   1066e:      	movl	%r15d, %edx
   10671:      	subl	%r12d, %edx
   10674:      	movl	$0x0, %ecx
   10679:      	cmovbl	%ecx, %edx
   1067c:      	addq	0x60(%rsp), %rdx
   10681:      	xorl	%esi, %esi
   10683:      	cmpl	%r15d, %r12d
   10686:      	seta	%sil
   1068a:      	movl	%r15d, %ecx
   1068d:      	cmovbl	%r12d, %ecx
   10691:      	addl	%ecx, %esi
   10693:      	movl	%r12d, %edi
   10696:      	subl	%esi, %edi
   10698:      	movl	%edi, 0x50(%rsp)
   1069c:      	subq	%rsi, %rax
   1069f:      	jb	0x15f32 <generic_fentry_path+0xba72>
   106a5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   106ab:      	ja	0x15f32 <generic_fentry_path+0xba72>
   106b1:      	cmpl	%r15d, %r12d
   106b4:      	jbe	0x106ba <generic_fentry_path+0x61fa>
   106b6:      	movb	$0x2f, (%rbx,%rax)
   106ba:      	xorl	%edi, %edi
   106bc:      	cmpl	%r15d, %r12d
   106bf:      	seta	%dil
   106c3:      	movzbl	%cl, %esi
   106c6:      	addq	%rax, %rbx
   106c9:      	addq	%rbx, %rdi
   106cc:      	movl	$0x4, %eax
   106d1:      	callq	*%rax
   106d3:      	movq	%rbx, 0x48(%rsp)
   106d8:      	cmpl	%r15d, %r12d
   106db:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   106e1:      	movq	0x8(%rsp), %r12
   106e6:      	movq	%r12, 0x30(%rsp)
   106eb:      	movq	0x38(%rsp), %rdx
   106f0:      	movq	0x40(%rsp), %r15
   106f5:      	jmp	0x10748 <generic_fentry_path+0x6288>
   106f7:      	leaq	0x10(%r15), %rdx
   106fb:      	movl	$0x4, %eax
   10700:      	movq	%rbp, %rdi
   10703:      	movl	$0x8, %esi
   10708:      	callq	*%rax
   1070a:      	movq	0x40(%rsp), %rax
   1070f:      	cmpq	(%rsp), %rax
   10713:      	je	0x15f2d <generic_fentry_path+0xba6d>
   10719:      	addq	$0x18, %r15
   1071d:      	movl	$0x4, %eax
   10722:      	leaq	0x30(%rsp), %rdi
   10727:      	movl	$0x8, %esi
   1072c:      	movq	%r15, %rdx
   1072f:      	callq	*%rax
   10731:      	movq	(%rsp), %r15
   10735:      	movq	%r15, 0x40(%rsp)
   1073a:      	leaq	0x20(%r15), %rdx
   1073e:      	movq	%rdx, 0x38(%rsp)
   10743:      	movq	0x30(%rsp), %r12
   10748:      	cmpq	0x18(%rsp), %r12
   1074d:      	jne	0x1075a <generic_fentry_path+0x629a>
   1074f:      	cmpq	0x20(%rsp), %rdx
   10754:      	je	0x15f2d <generic_fentry_path+0xba6d>
   1075a:      	movl	$0x4, %eax
   1075f:      	leaq	0x10(%rsp), %rdi
   10764:      	movl	$0x8, %esi
   10769:      	callq	*%rax
   1076b:      	cmpq	0x10(%rsp), %r12
   10770:      	je	0x10868 <generic_fentry_path+0x63a8>
   10776:      	leaq	0x18(%r12), %rbx
   1077b:      	movl	$0x4, %eax
   10780:      	movq	%rbp, %rdi
   10783:      	movl	$0x8, %esi
   10788:      	movq	%rbx, %rdx
   1078b:      	callq	*%rax
   1078d:      	cmpq	%r12, (%rsp)
   10791:      	je	0x10868 <generic_fentry_path+0x63a8>
   10797:      	movl	$0x4, %eax
   1079c:      	leaq	0x8(%rsp), %rdi
   107a1:      	movl	$0x8, %esi
   107a6:      	movq	%rbx, %rdx
   107a9:      	callq	*%rax
   107ab:      	addq	$0x20, %r12
   107af:      	movl	$0x4, %eax
   107b4:      	leaq	0x58(%rsp), %rdi
   107b9:      	movl	$0x10, %ecx
   107be:      	movl	$0x10, %esi
   107c3:      	movq	%r12, %rdx
   107c6:      	callq	*%rax
   107c8:      	movq	0x28(%rsp), %rbx
   107cd:      	movq	0x48(%rsp), %rax
   107d2:      	movl	0x5c(%rsp), %r15d
   107d7:      	subq	%rbx, %rax
   107da:      	movl	0x50(%rsp), %r12d
   107df:      	movl	%r15d, %edx
   107e2:      	subl	%r12d, %edx
   107e5:      	movl	$0x0, %ecx
   107ea:      	cmovbl	%ecx, %edx
   107ed:      	addq	0x60(%rsp), %rdx
   107f2:      	xorl	%esi, %esi
   107f4:      	cmpl	%r15d, %r12d
   107f7:      	seta	%sil
   107fb:      	movl	%r15d, %ecx
   107fe:      	cmovbl	%r12d, %ecx
   10802:      	addl	%ecx, %esi
   10804:      	movl	%r12d, %edi
   10807:      	subl	%esi, %edi
   10809:      	movl	%edi, 0x50(%rsp)
   1080d:      	subq	%rsi, %rax
   10810:      	jb	0x15f32 <generic_fentry_path+0xba72>
   10816:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1081c:      	ja	0x15f32 <generic_fentry_path+0xba72>
   10822:      	cmpl	%r15d, %r12d
   10825:      	jbe	0x1082b <generic_fentry_path+0x636b>
   10827:      	movb	$0x2f, (%rbx,%rax)
   1082b:      	xorl	%edi, %edi
   1082d:      	cmpl	%r15d, %r12d
   10830:      	seta	%dil
   10834:      	movzbl	%cl, %esi
   10837:      	addq	%rax, %rbx
   1083a:      	addq	%rbx, %rdi
   1083d:      	movl	$0x4, %eax
   10842:      	callq	*%rax
   10844:      	movq	%rbx, 0x48(%rsp)
   10849:      	cmpl	%r15d, %r12d
   1084c:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   10852:      	movq	0x8(%rsp), %r12
   10857:      	movq	%r12, 0x30(%rsp)
   1085c:      	movq	0x38(%rsp), %rdx
   10861:      	movq	0x40(%rsp), %r15
   10866:      	jmp	0x108b9 <generic_fentry_path+0x63f9>
   10868:      	leaq	0x10(%r15), %rdx
   1086c:      	movl	$0x4, %eax
   10871:      	movq	%rbp, %rdi
   10874:      	movl	$0x8, %esi
   10879:      	callq	*%rax
   1087b:      	movq	0x40(%rsp), %rax
   10880:      	cmpq	(%rsp), %rax
   10884:      	je	0x15f2d <generic_fentry_path+0xba6d>
   1088a:      	addq	$0x18, %r15
   1088e:      	movl	$0x4, %eax
   10893:      	leaq	0x30(%rsp), %rdi
   10898:      	movl	$0x8, %esi
   1089d:      	movq	%r15, %rdx
   108a0:      	callq	*%rax
   108a2:      	movq	(%rsp), %r15
   108a6:      	movq	%r15, 0x40(%rsp)
   108ab:      	leaq	0x20(%r15), %rdx
   108af:      	movq	%rdx, 0x38(%rsp)
   108b4:      	movq	0x30(%rsp), %r12
   108b9:      	cmpq	0x18(%rsp), %r12
   108be:      	jne	0x108cb <generic_fentry_path+0x640b>
   108c0:      	cmpq	0x20(%rsp), %rdx
   108c5:      	je	0x15f2d <generic_fentry_path+0xba6d>
   108cb:      	movl	$0x4, %eax
   108d0:      	leaq	0x10(%rsp), %rdi
   108d5:      	movl	$0x8, %esi
   108da:      	callq	*%rax
   108dc:      	cmpq	0x10(%rsp), %r12
   108e1:      	je	0x109d9 <generic_fentry_path+0x6519>
   108e7:      	leaq	0x18(%r12), %rbx
   108ec:      	movl	$0x4, %eax
   108f1:      	movq	%rbp, %rdi
   108f4:      	movl	$0x8, %esi
   108f9:      	movq	%rbx, %rdx
   108fc:      	callq	*%rax
   108fe:      	cmpq	%r12, (%rsp)
   10902:      	je	0x109d9 <generic_fentry_path+0x6519>
   10908:      	movl	$0x4, %eax
   1090d:      	leaq	0x8(%rsp), %rdi
   10912:      	movl	$0x8, %esi
   10917:      	movq	%rbx, %rdx
   1091a:      	callq	*%rax
   1091c:      	addq	$0x20, %r12
   10920:      	movl	$0x4, %eax
   10925:      	leaq	0x58(%rsp), %rdi
   1092a:      	movl	$0x10, %ecx
   1092f:      	movl	$0x10, %esi
   10934:      	movq	%r12, %rdx
   10937:      	callq	*%rax
   10939:      	movq	0x28(%rsp), %rbx
   1093e:      	movq	0x48(%rsp), %rax
   10943:      	movl	0x5c(%rsp), %r15d
   10948:      	subq	%rbx, %rax
   1094b:      	movl	0x50(%rsp), %r12d
   10950:      	movl	%r15d, %edx
   10953:      	subl	%r12d, %edx
   10956:      	movl	$0x0, %ecx
   1095b:      	cmovbl	%ecx, %edx
   1095e:      	addq	0x60(%rsp), %rdx
   10963:      	xorl	%esi, %esi
   10965:      	cmpl	%r15d, %r12d
   10968:      	seta	%sil
   1096c:      	movl	%r15d, %ecx
   1096f:      	cmovbl	%r12d, %ecx
   10973:      	addl	%ecx, %esi
   10975:      	movl	%r12d, %edi
   10978:      	subl	%esi, %edi
   1097a:      	movl	%edi, 0x50(%rsp)
   1097e:      	subq	%rsi, %rax
   10981:      	jb	0x15f32 <generic_fentry_path+0xba72>
   10987:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1098d:      	ja	0x15f32 <generic_fentry_path+0xba72>
   10993:      	cmpl	%r15d, %r12d
   10996:      	jbe	0x1099c <generic_fentry_path+0x64dc>
   10998:      	movb	$0x2f, (%rbx,%rax)
   1099c:      	xorl	%edi, %edi
   1099e:      	cmpl	%r15d, %r12d
   109a1:      	seta	%dil
   109a5:      	movzbl	%cl, %esi
   109a8:      	addq	%rax, %rbx
   109ab:      	addq	%rbx, %rdi
   109ae:      	movl	$0x4, %eax
   109b3:      	callq	*%rax
   109b5:      	movq	%rbx, 0x48(%rsp)
   109ba:      	cmpl	%r15d, %r12d
   109bd:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   109c3:      	movq	0x8(%rsp), %r12
   109c8:      	movq	%r12, 0x30(%rsp)
   109cd:      	movq	0x38(%rsp), %rdx
   109d2:      	movq	0x40(%rsp), %r15
   109d7:      	jmp	0x10a2a <generic_fentry_path+0x656a>
   109d9:      	leaq	0x10(%r15), %rdx
   109dd:      	movl	$0x4, %eax
   109e2:      	movq	%rbp, %rdi
   109e5:      	movl	$0x8, %esi
   109ea:      	callq	*%rax
   109ec:      	movq	0x40(%rsp), %rax
   109f1:      	cmpq	(%rsp), %rax
   109f5:      	je	0x15f2d <generic_fentry_path+0xba6d>
   109fb:      	addq	$0x18, %r15
   109ff:      	movl	$0x4, %eax
   10a04:      	leaq	0x30(%rsp), %rdi
   10a09:      	movl	$0x8, %esi
   10a0e:      	movq	%r15, %rdx
   10a11:      	callq	*%rax
   10a13:      	movq	(%rsp), %r15
   10a17:      	movq	%r15, 0x40(%rsp)
   10a1c:      	leaq	0x20(%r15), %rdx
   10a20:      	movq	%rdx, 0x38(%rsp)
   10a25:      	movq	0x30(%rsp), %r12
   10a2a:      	cmpq	0x18(%rsp), %r12
   10a2f:      	jne	0x10a3c <generic_fentry_path+0x657c>
   10a31:      	cmpq	0x20(%rsp), %rdx
   10a36:      	je	0x15f2d <generic_fentry_path+0xba6d>
   10a3c:      	movl	$0x4, %eax
   10a41:      	leaq	0x10(%rsp), %rdi
   10a46:      	movl	$0x8, %esi
   10a4b:      	callq	*%rax
   10a4d:      	cmpq	0x10(%rsp), %r12
   10a52:      	je	0x10b4a <generic_fentry_path+0x668a>
   10a58:      	leaq	0x18(%r12), %rbx
   10a5d:      	movl	$0x4, %eax
   10a62:      	movq	%rbp, %rdi
   10a65:      	movl	$0x8, %esi
   10a6a:      	movq	%rbx, %rdx
   10a6d:      	callq	*%rax
   10a6f:      	cmpq	%r12, (%rsp)
   10a73:      	je	0x10b4a <generic_fentry_path+0x668a>
   10a79:      	movl	$0x4, %eax
   10a7e:      	leaq	0x8(%rsp), %rdi
   10a83:      	movl	$0x8, %esi
   10a88:      	movq	%rbx, %rdx
   10a8b:      	callq	*%rax
   10a8d:      	addq	$0x20, %r12
   10a91:      	movl	$0x4, %eax
   10a96:      	leaq	0x58(%rsp), %rdi
   10a9b:      	movl	$0x10, %ecx
   10aa0:      	movl	$0x10, %esi
   10aa5:      	movq	%r12, %rdx
   10aa8:      	callq	*%rax
   10aaa:      	movq	0x28(%rsp), %rbx
   10aaf:      	movq	0x48(%rsp), %rax
   10ab4:      	movl	0x5c(%rsp), %r15d
   10ab9:      	subq	%rbx, %rax
   10abc:      	movl	0x50(%rsp), %r12d
   10ac1:      	movl	%r15d, %edx
   10ac4:      	subl	%r12d, %edx
   10ac7:      	movl	$0x0, %ecx
   10acc:      	cmovbl	%ecx, %edx
   10acf:      	addq	0x60(%rsp), %rdx
   10ad4:      	xorl	%esi, %esi
   10ad6:      	cmpl	%r15d, %r12d
   10ad9:      	seta	%sil
   10add:      	movl	%r15d, %ecx
   10ae0:      	cmovbl	%r12d, %ecx
   10ae4:      	addl	%ecx, %esi
   10ae6:      	movl	%r12d, %edi
   10ae9:      	subl	%esi, %edi
   10aeb:      	movl	%edi, 0x50(%rsp)
   10aef:      	subq	%rsi, %rax
   10af2:      	jb	0x15f32 <generic_fentry_path+0xba72>
   10af8:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10afe:      	ja	0x15f32 <generic_fentry_path+0xba72>
   10b04:      	cmpl	%r15d, %r12d
   10b07:      	jbe	0x10b0d <generic_fentry_path+0x664d>
   10b09:      	movb	$0x2f, (%rbx,%rax)
   10b0d:      	xorl	%edi, %edi
   10b0f:      	cmpl	%r15d, %r12d
   10b12:      	seta	%dil
   10b16:      	movzbl	%cl, %esi
   10b19:      	addq	%rax, %rbx
   10b1c:      	addq	%rbx, %rdi
   10b1f:      	movl	$0x4, %eax
   10b24:      	callq	*%rax
   10b26:      	movq	%rbx, 0x48(%rsp)
   10b2b:      	cmpl	%r15d, %r12d
   10b2e:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   10b34:      	movq	0x8(%rsp), %r12
   10b39:      	movq	%r12, 0x30(%rsp)
   10b3e:      	movq	0x38(%rsp), %rdx
   10b43:      	movq	0x40(%rsp), %r15
   10b48:      	jmp	0x10b9b <generic_fentry_path+0x66db>
   10b4a:      	leaq	0x10(%r15), %rdx
   10b4e:      	movl	$0x4, %eax
   10b53:      	movq	%rbp, %rdi
   10b56:      	movl	$0x8, %esi
   10b5b:      	callq	*%rax
   10b5d:      	movq	0x40(%rsp), %rax
   10b62:      	cmpq	(%rsp), %rax
   10b66:      	je	0x15f2d <generic_fentry_path+0xba6d>
   10b6c:      	addq	$0x18, %r15
   10b70:      	movl	$0x4, %eax
   10b75:      	leaq	0x30(%rsp), %rdi
   10b7a:      	movl	$0x8, %esi
   10b7f:      	movq	%r15, %rdx
   10b82:      	callq	*%rax
   10b84:      	movq	(%rsp), %r15
   10b88:      	movq	%r15, 0x40(%rsp)
   10b8d:      	leaq	0x20(%r15), %rdx
   10b91:      	movq	%rdx, 0x38(%rsp)
   10b96:      	movq	0x30(%rsp), %r12
   10b9b:      	cmpq	0x18(%rsp), %r12
   10ba0:      	jne	0x10bad <generic_fentry_path+0x66ed>
   10ba2:      	cmpq	0x20(%rsp), %rdx
   10ba7:      	je	0x15f2d <generic_fentry_path+0xba6d>
   10bad:      	movl	$0x4, %eax
   10bb2:      	leaq	0x10(%rsp), %rdi
   10bb7:      	movl	$0x8, %esi
   10bbc:      	callq	*%rax
   10bbe:      	cmpq	0x10(%rsp), %r12
   10bc3:      	je	0x10cbb <generic_fentry_path+0x67fb>
   10bc9:      	leaq	0x18(%r12), %rbx
   10bce:      	movl	$0x4, %eax
   10bd3:      	movq	%rbp, %rdi
   10bd6:      	movl	$0x8, %esi
   10bdb:      	movq	%rbx, %rdx
   10bde:      	callq	*%rax
   10be0:      	cmpq	%r12, (%rsp)
   10be4:      	je	0x10cbb <generic_fentry_path+0x67fb>
   10bea:      	movl	$0x4, %eax
   10bef:      	leaq	0x8(%rsp), %rdi
   10bf4:      	movl	$0x8, %esi
   10bf9:      	movq	%rbx, %rdx
   10bfc:      	callq	*%rax
   10bfe:      	addq	$0x20, %r12
   10c02:      	movl	$0x4, %eax
   10c07:      	leaq	0x58(%rsp), %rdi
   10c0c:      	movl	$0x10, %ecx
   10c11:      	movl	$0x10, %esi
   10c16:      	movq	%r12, %rdx
   10c19:      	callq	*%rax
   10c1b:      	movq	0x28(%rsp), %rbx
   10c20:      	movq	0x48(%rsp), %rax
   10c25:      	movl	0x5c(%rsp), %r15d
   10c2a:      	subq	%rbx, %rax
   10c2d:      	movl	0x50(%rsp), %r12d
   10c32:      	movl	%r15d, %edx
   10c35:      	subl	%r12d, %edx
   10c38:      	movl	$0x0, %ecx
   10c3d:      	cmovbl	%ecx, %edx
   10c40:      	addq	0x60(%rsp), %rdx
   10c45:      	xorl	%esi, %esi
   10c47:      	cmpl	%r15d, %r12d
   10c4a:      	seta	%sil
   10c4e:      	movl	%r15d, %ecx
   10c51:      	cmovbl	%r12d, %ecx
   10c55:      	addl	%ecx, %esi
   10c57:      	movl	%r12d, %edi
   10c5a:      	subl	%esi, %edi
   10c5c:      	movl	%edi, 0x50(%rsp)
   10c60:      	subq	%rsi, %rax
   10c63:      	jb	0x15f32 <generic_fentry_path+0xba72>
   10c69:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10c6f:      	ja	0x15f32 <generic_fentry_path+0xba72>
   10c75:      	cmpl	%r15d, %r12d
   10c78:      	jbe	0x10c7e <generic_fentry_path+0x67be>
   10c7a:      	movb	$0x2f, (%rbx,%rax)
   10c7e:      	xorl	%edi, %edi
   10c80:      	cmpl	%r15d, %r12d
   10c83:      	seta	%dil
   10c87:      	movzbl	%cl, %esi
   10c8a:      	addq	%rax, %rbx
   10c8d:      	addq	%rbx, %rdi
   10c90:      	movl	$0x4, %eax
   10c95:      	callq	*%rax
   10c97:      	movq	%rbx, 0x48(%rsp)
   10c9c:      	cmpl	%r15d, %r12d
   10c9f:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   10ca5:      	movq	0x8(%rsp), %r12
   10caa:      	movq	%r12, 0x30(%rsp)
   10caf:      	movq	0x38(%rsp), %rdx
   10cb4:      	movq	0x40(%rsp), %r15
   10cb9:      	jmp	0x10d0c <generic_fentry_path+0x684c>
   10cbb:      	leaq	0x10(%r15), %rdx
   10cbf:      	movl	$0x4, %eax
   10cc4:      	movq	%rbp, %rdi
   10cc7:      	movl	$0x8, %esi
   10ccc:      	callq	*%rax
   10cce:      	movq	0x40(%rsp), %rax
   10cd3:      	cmpq	(%rsp), %rax
   10cd7:      	je	0x15f2d <generic_fentry_path+0xba6d>
   10cdd:      	addq	$0x18, %r15
   10ce1:      	movl	$0x4, %eax
   10ce6:      	leaq	0x30(%rsp), %rdi
   10ceb:      	movl	$0x8, %esi
   10cf0:      	movq	%r15, %rdx
   10cf3:      	callq	*%rax
   10cf5:      	movq	(%rsp), %r15
   10cf9:      	movq	%r15, 0x40(%rsp)
   10cfe:      	leaq	0x20(%r15), %rdx
   10d02:      	movq	%rdx, 0x38(%rsp)
   10d07:      	movq	0x30(%rsp), %r12
   10d0c:      	cmpq	0x18(%rsp), %r12
   10d11:      	jne	0x10d1e <generic_fentry_path+0x685e>
   10d13:      	cmpq	0x20(%rsp), %rdx
   10d18:      	je	0x15f2d <generic_fentry_path+0xba6d>
   10d1e:      	movl	$0x4, %eax
   10d23:      	leaq	0x10(%rsp), %rdi
   10d28:      	movl	$0x8, %esi
   10d2d:      	callq	*%rax
   10d2f:      	cmpq	0x10(%rsp), %r12
   10d34:      	je	0x10e2c <generic_fentry_path+0x696c>
   10d3a:      	leaq	0x18(%r12), %rbx
   10d3f:      	movl	$0x4, %eax
   10d44:      	movq	%rbp, %rdi
   10d47:      	movl	$0x8, %esi
   10d4c:      	movq	%rbx, %rdx
   10d4f:      	callq	*%rax
   10d51:      	cmpq	%r12, (%rsp)
   10d55:      	je	0x10e2c <generic_fentry_path+0x696c>
   10d5b:      	movl	$0x4, %eax
   10d60:      	leaq	0x8(%rsp), %rdi
   10d65:      	movl	$0x8, %esi
   10d6a:      	movq	%rbx, %rdx
   10d6d:      	callq	*%rax
   10d6f:      	addq	$0x20, %r12
   10d73:      	movl	$0x4, %eax
   10d78:      	leaq	0x58(%rsp), %rdi
   10d7d:      	movl	$0x10, %ecx
   10d82:      	movl	$0x10, %esi
   10d87:      	movq	%r12, %rdx
   10d8a:      	callq	*%rax
   10d8c:      	movq	0x28(%rsp), %rbx
   10d91:      	movq	0x48(%rsp), %rax
   10d96:      	movl	0x5c(%rsp), %r15d
   10d9b:      	subq	%rbx, %rax
   10d9e:      	movl	0x50(%rsp), %r12d
   10da3:      	movl	%r15d, %edx
   10da6:      	subl	%r12d, %edx
   10da9:      	movl	$0x0, %ecx
   10dae:      	cmovbl	%ecx, %edx
   10db1:      	addq	0x60(%rsp), %rdx
   10db6:      	xorl	%esi, %esi
   10db8:      	cmpl	%r15d, %r12d
   10dbb:      	seta	%sil
   10dbf:      	movl	%r15d, %ecx
   10dc2:      	cmovbl	%r12d, %ecx
   10dc6:      	addl	%ecx, %esi
   10dc8:      	movl	%r12d, %edi
   10dcb:      	subl	%esi, %edi
   10dcd:      	movl	%edi, 0x50(%rsp)
   10dd1:      	subq	%rsi, %rax
   10dd4:      	jb	0x15f32 <generic_fentry_path+0xba72>
   10dda:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10de0:      	ja	0x15f32 <generic_fentry_path+0xba72>
   10de6:      	cmpl	%r15d, %r12d
   10de9:      	jbe	0x10def <generic_fentry_path+0x692f>
   10deb:      	movb	$0x2f, (%rbx,%rax)
   10def:      	xorl	%edi, %edi
   10df1:      	cmpl	%r15d, %r12d
   10df4:      	seta	%dil
   10df8:      	movzbl	%cl, %esi
   10dfb:      	addq	%rax, %rbx
   10dfe:      	addq	%rbx, %rdi
   10e01:      	movl	$0x4, %eax
   10e06:      	callq	*%rax
   10e08:      	movq	%rbx, 0x48(%rsp)
   10e0d:      	cmpl	%r15d, %r12d
   10e10:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   10e16:      	movq	0x8(%rsp), %r12
   10e1b:      	movq	%r12, 0x30(%rsp)
   10e20:      	movq	0x38(%rsp), %rdx
   10e25:      	movq	0x40(%rsp), %r15
   10e2a:      	jmp	0x10e7d <generic_fentry_path+0x69bd>
   10e2c:      	leaq	0x10(%r15), %rdx
   10e30:      	movl	$0x4, %eax
   10e35:      	movq	%rbp, %rdi
   10e38:      	movl	$0x8, %esi
   10e3d:      	callq	*%rax
   10e3f:      	movq	0x40(%rsp), %rax
   10e44:      	cmpq	(%rsp), %rax
   10e48:      	je	0x15f2d <generic_fentry_path+0xba6d>
   10e4e:      	addq	$0x18, %r15
   10e52:      	movl	$0x4, %eax
   10e57:      	leaq	0x30(%rsp), %rdi
   10e5c:      	movl	$0x8, %esi
   10e61:      	movq	%r15, %rdx
   10e64:      	callq	*%rax
   10e66:      	movq	(%rsp), %r15
   10e6a:      	movq	%r15, 0x40(%rsp)
   10e6f:      	leaq	0x20(%r15), %rdx
   10e73:      	movq	%rdx, 0x38(%rsp)
   10e78:      	movq	0x30(%rsp), %r12
   10e7d:      	cmpq	0x18(%rsp), %r12
   10e82:      	jne	0x10e8f <generic_fentry_path+0x69cf>
   10e84:      	cmpq	0x20(%rsp), %rdx
   10e89:      	je	0x15f2d <generic_fentry_path+0xba6d>
   10e8f:      	movl	$0x4, %eax
   10e94:      	leaq	0x10(%rsp), %rdi
   10e99:      	movl	$0x8, %esi
   10e9e:      	callq	*%rax
   10ea0:      	cmpq	0x10(%rsp), %r12
   10ea5:      	je	0x10f9d <generic_fentry_path+0x6add>
   10eab:      	leaq	0x18(%r12), %rbx
   10eb0:      	movl	$0x4, %eax
   10eb5:      	movq	%rbp, %rdi
   10eb8:      	movl	$0x8, %esi
   10ebd:      	movq	%rbx, %rdx
   10ec0:      	callq	*%rax
   10ec2:      	cmpq	%r12, (%rsp)
   10ec6:      	je	0x10f9d <generic_fentry_path+0x6add>
   10ecc:      	movl	$0x4, %eax
   10ed1:      	leaq	0x8(%rsp), %rdi
   10ed6:      	movl	$0x8, %esi
   10edb:      	movq	%rbx, %rdx
   10ede:      	callq	*%rax
   10ee0:      	addq	$0x20, %r12
   10ee4:      	movl	$0x4, %eax
   10ee9:      	leaq	0x58(%rsp), %rdi
   10eee:      	movl	$0x10, %ecx
   10ef3:      	movl	$0x10, %esi
   10ef8:      	movq	%r12, %rdx
   10efb:      	callq	*%rax
   10efd:      	movq	0x28(%rsp), %rbx
   10f02:      	movq	0x48(%rsp), %rax
   10f07:      	movl	0x5c(%rsp), %r15d
   10f0c:      	subq	%rbx, %rax
   10f0f:      	movl	0x50(%rsp), %r12d
   10f14:      	movl	%r15d, %edx
   10f17:      	subl	%r12d, %edx
   10f1a:      	movl	$0x0, %ecx
   10f1f:      	cmovbl	%ecx, %edx
   10f22:      	addq	0x60(%rsp), %rdx
   10f27:      	xorl	%esi, %esi
   10f29:      	cmpl	%r15d, %r12d
   10f2c:      	seta	%sil
   10f30:      	movl	%r15d, %ecx
   10f33:      	cmovbl	%r12d, %ecx
   10f37:      	addl	%ecx, %esi
   10f39:      	movl	%r12d, %edi
   10f3c:      	subl	%esi, %edi
   10f3e:      	movl	%edi, 0x50(%rsp)
   10f42:      	subq	%rsi, %rax
   10f45:      	jb	0x15f32 <generic_fentry_path+0xba72>
   10f4b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10f51:      	ja	0x15f32 <generic_fentry_path+0xba72>
   10f57:      	cmpl	%r15d, %r12d
   10f5a:      	jbe	0x10f60 <generic_fentry_path+0x6aa0>
   10f5c:      	movb	$0x2f, (%rbx,%rax)
   10f60:      	xorl	%edi, %edi
   10f62:      	cmpl	%r15d, %r12d
   10f65:      	seta	%dil
   10f69:      	movzbl	%cl, %esi
   10f6c:      	addq	%rax, %rbx
   10f6f:      	addq	%rbx, %rdi
   10f72:      	movl	$0x4, %eax
   10f77:      	callq	*%rax
   10f79:      	movq	%rbx, 0x48(%rsp)
   10f7e:      	cmpl	%r15d, %r12d
   10f81:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   10f87:      	movq	0x8(%rsp), %r12
   10f8c:      	movq	%r12, 0x30(%rsp)
   10f91:      	movq	0x38(%rsp), %rdx
   10f96:      	movq	0x40(%rsp), %r15
   10f9b:      	jmp	0x10fee <generic_fentry_path+0x6b2e>
   10f9d:      	leaq	0x10(%r15), %rdx
   10fa1:      	movl	$0x4, %eax
   10fa6:      	movq	%rbp, %rdi
   10fa9:      	movl	$0x8, %esi
   10fae:      	callq	*%rax
   10fb0:      	movq	0x40(%rsp), %rax
   10fb5:      	cmpq	(%rsp), %rax
   10fb9:      	je	0x15f2d <generic_fentry_path+0xba6d>
   10fbf:      	addq	$0x18, %r15
   10fc3:      	movl	$0x4, %eax
   10fc8:      	leaq	0x30(%rsp), %rdi
   10fcd:      	movl	$0x8, %esi
   10fd2:      	movq	%r15, %rdx
   10fd5:      	callq	*%rax
   10fd7:      	movq	(%rsp), %r15
   10fdb:      	movq	%r15, 0x40(%rsp)
   10fe0:      	leaq	0x20(%r15), %rdx
   10fe4:      	movq	%rdx, 0x38(%rsp)
   10fe9:      	movq	0x30(%rsp), %r12
   10fee:      	cmpq	0x18(%rsp), %r12
   10ff3:      	jne	0x11000 <generic_fentry_path+0x6b40>
   10ff5:      	cmpq	0x20(%rsp), %rdx
   10ffa:      	je	0x15f2d <generic_fentry_path+0xba6d>
   11000:      	movl	$0x4, %eax
   11005:      	leaq	0x10(%rsp), %rdi
   1100a:      	movl	$0x8, %esi
   1100f:      	callq	*%rax
   11011:      	cmpq	0x10(%rsp), %r12
   11016:      	je	0x1110e <generic_fentry_path+0x6c4e>
   1101c:      	leaq	0x18(%r12), %rbx
   11021:      	movl	$0x4, %eax
   11026:      	movq	%rbp, %rdi
   11029:      	movl	$0x8, %esi
   1102e:      	movq	%rbx, %rdx
   11031:      	callq	*%rax
   11033:      	cmpq	%r12, (%rsp)
   11037:      	je	0x1110e <generic_fentry_path+0x6c4e>
   1103d:      	movl	$0x4, %eax
   11042:      	leaq	0x8(%rsp), %rdi
   11047:      	movl	$0x8, %esi
   1104c:      	movq	%rbx, %rdx
   1104f:      	callq	*%rax
   11051:      	addq	$0x20, %r12
   11055:      	movl	$0x4, %eax
   1105a:      	leaq	0x58(%rsp), %rdi
   1105f:      	movl	$0x10, %ecx
   11064:      	movl	$0x10, %esi
   11069:      	movq	%r12, %rdx
   1106c:      	callq	*%rax
   1106e:      	movq	0x28(%rsp), %rbx
   11073:      	movq	0x48(%rsp), %rax
   11078:      	movl	0x5c(%rsp), %r15d
   1107d:      	subq	%rbx, %rax
   11080:      	movl	0x50(%rsp), %r12d
   11085:      	movl	%r15d, %edx
   11088:      	subl	%r12d, %edx
   1108b:      	movl	$0x0, %ecx
   11090:      	cmovbl	%ecx, %edx
   11093:      	addq	0x60(%rsp), %rdx
   11098:      	xorl	%esi, %esi
   1109a:      	cmpl	%r15d, %r12d
   1109d:      	seta	%sil
   110a1:      	movl	%r15d, %ecx
   110a4:      	cmovbl	%r12d, %ecx
   110a8:      	addl	%ecx, %esi
   110aa:      	movl	%r12d, %edi
   110ad:      	subl	%esi, %edi
   110af:      	movl	%edi, 0x50(%rsp)
   110b3:      	subq	%rsi, %rax
   110b6:      	jb	0x15f32 <generic_fentry_path+0xba72>
   110bc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   110c2:      	ja	0x15f32 <generic_fentry_path+0xba72>
   110c8:      	cmpl	%r15d, %r12d
   110cb:      	jbe	0x110d1 <generic_fentry_path+0x6c11>
   110cd:      	movb	$0x2f, (%rbx,%rax)
   110d1:      	xorl	%edi, %edi
   110d3:      	cmpl	%r15d, %r12d
   110d6:      	seta	%dil
   110da:      	movzbl	%cl, %esi
   110dd:      	addq	%rax, %rbx
   110e0:      	addq	%rbx, %rdi
   110e3:      	movl	$0x4, %eax
   110e8:      	callq	*%rax
   110ea:      	movq	%rbx, 0x48(%rsp)
   110ef:      	cmpl	%r15d, %r12d
   110f2:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   110f8:      	movq	0x8(%rsp), %r12
   110fd:      	movq	%r12, 0x30(%rsp)
   11102:      	movq	0x38(%rsp), %rdx
   11107:      	movq	0x40(%rsp), %r15
   1110c:      	jmp	0x1115f <generic_fentry_path+0x6c9f>
   1110e:      	leaq	0x10(%r15), %rdx
   11112:      	movl	$0x4, %eax
   11117:      	movq	%rbp, %rdi
   1111a:      	movl	$0x8, %esi
   1111f:      	callq	*%rax
   11121:      	movq	0x40(%rsp), %rax
   11126:      	cmpq	(%rsp), %rax
   1112a:      	je	0x15f2d <generic_fentry_path+0xba6d>
   11130:      	addq	$0x18, %r15
   11134:      	movl	$0x4, %eax
   11139:      	leaq	0x30(%rsp), %rdi
   1113e:      	movl	$0x8, %esi
   11143:      	movq	%r15, %rdx
   11146:      	callq	*%rax
   11148:      	movq	(%rsp), %r15
   1114c:      	movq	%r15, 0x40(%rsp)
   11151:      	leaq	0x20(%r15), %rdx
   11155:      	movq	%rdx, 0x38(%rsp)
   1115a:      	movq	0x30(%rsp), %r12
   1115f:      	cmpq	0x18(%rsp), %r12
   11164:      	jne	0x11171 <generic_fentry_path+0x6cb1>
   11166:      	cmpq	0x20(%rsp), %rdx
   1116b:      	je	0x15f2d <generic_fentry_path+0xba6d>
   11171:      	movl	$0x4, %eax
   11176:      	leaq	0x10(%rsp), %rdi
   1117b:      	movl	$0x8, %esi
   11180:      	callq	*%rax
   11182:      	cmpq	0x10(%rsp), %r12
   11187:      	je	0x1127f <generic_fentry_path+0x6dbf>
   1118d:      	leaq	0x18(%r12), %rbx
   11192:      	movl	$0x4, %eax
   11197:      	movq	%rbp, %rdi
   1119a:      	movl	$0x8, %esi
   1119f:      	movq	%rbx, %rdx
   111a2:      	callq	*%rax
   111a4:      	cmpq	%r12, (%rsp)
   111a8:      	je	0x1127f <generic_fentry_path+0x6dbf>
   111ae:      	movl	$0x4, %eax
   111b3:      	leaq	0x8(%rsp), %rdi
   111b8:      	movl	$0x8, %esi
   111bd:      	movq	%rbx, %rdx
   111c0:      	callq	*%rax
   111c2:      	addq	$0x20, %r12
   111c6:      	movl	$0x4, %eax
   111cb:      	leaq	0x58(%rsp), %rdi
   111d0:      	movl	$0x10, %ecx
   111d5:      	movl	$0x10, %esi
   111da:      	movq	%r12, %rdx
   111dd:      	callq	*%rax
   111df:      	movq	0x28(%rsp), %rbx
   111e4:      	movq	0x48(%rsp), %rax
   111e9:      	movl	0x5c(%rsp), %r15d
   111ee:      	subq	%rbx, %rax
   111f1:      	movl	0x50(%rsp), %r12d
   111f6:      	movl	%r15d, %edx
   111f9:      	subl	%r12d, %edx
   111fc:      	movl	$0x0, %ecx
   11201:      	cmovbl	%ecx, %edx
   11204:      	addq	0x60(%rsp), %rdx
   11209:      	xorl	%esi, %esi
   1120b:      	cmpl	%r15d, %r12d
   1120e:      	seta	%sil
   11212:      	movl	%r15d, %ecx
   11215:      	cmovbl	%r12d, %ecx
   11219:      	addl	%ecx, %esi
   1121b:      	movl	%r12d, %edi
   1121e:      	subl	%esi, %edi
   11220:      	movl	%edi, 0x50(%rsp)
   11224:      	subq	%rsi, %rax
   11227:      	jb	0x15f32 <generic_fentry_path+0xba72>
   1122d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11233:      	ja	0x15f32 <generic_fentry_path+0xba72>
   11239:      	cmpl	%r15d, %r12d
   1123c:      	jbe	0x11242 <generic_fentry_path+0x6d82>
   1123e:      	movb	$0x2f, (%rbx,%rax)
   11242:      	xorl	%edi, %edi
   11244:      	cmpl	%r15d, %r12d
   11247:      	seta	%dil
   1124b:      	movzbl	%cl, %esi
   1124e:      	addq	%rax, %rbx
   11251:      	addq	%rbx, %rdi
   11254:      	movl	$0x4, %eax
   11259:      	callq	*%rax
   1125b:      	movq	%rbx, 0x48(%rsp)
   11260:      	cmpl	%r15d, %r12d
   11263:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   11269:      	movq	0x8(%rsp), %r12
   1126e:      	movq	%r12, 0x30(%rsp)
   11273:      	movq	0x38(%rsp), %rdx
   11278:      	movq	0x40(%rsp), %r15
   1127d:      	jmp	0x112d0 <generic_fentry_path+0x6e10>
   1127f:      	leaq	0x10(%r15), %rdx
   11283:      	movl	$0x4, %eax
   11288:      	movq	%rbp, %rdi
   1128b:      	movl	$0x8, %esi
   11290:      	callq	*%rax
   11292:      	movq	0x40(%rsp), %rax
   11297:      	cmpq	(%rsp), %rax
   1129b:      	je	0x15f2d <generic_fentry_path+0xba6d>
   112a1:      	addq	$0x18, %r15
   112a5:      	movl	$0x4, %eax
   112aa:      	leaq	0x30(%rsp), %rdi
   112af:      	movl	$0x8, %esi
   112b4:      	movq	%r15, %rdx
   112b7:      	callq	*%rax
   112b9:      	movq	(%rsp), %r15
   112bd:      	movq	%r15, 0x40(%rsp)
   112c2:      	leaq	0x20(%r15), %rdx
   112c6:      	movq	%rdx, 0x38(%rsp)
   112cb:      	movq	0x30(%rsp), %r12
   112d0:      	cmpq	0x18(%rsp), %r12
   112d5:      	jne	0x112e2 <generic_fentry_path+0x6e22>
   112d7:      	cmpq	0x20(%rsp), %rdx
   112dc:      	je	0x15f2d <generic_fentry_path+0xba6d>
   112e2:      	movl	$0x4, %eax
   112e7:      	leaq	0x10(%rsp), %rdi
   112ec:      	movl	$0x8, %esi
   112f1:      	callq	*%rax
   112f3:      	cmpq	0x10(%rsp), %r12
   112f8:      	je	0x113f0 <generic_fentry_path+0x6f30>
   112fe:      	leaq	0x18(%r12), %rbx
   11303:      	movl	$0x4, %eax
   11308:      	movq	%rbp, %rdi
   1130b:      	movl	$0x8, %esi
   11310:      	movq	%rbx, %rdx
   11313:      	callq	*%rax
   11315:      	cmpq	%r12, (%rsp)
   11319:      	je	0x113f0 <generic_fentry_path+0x6f30>
   1131f:      	movl	$0x4, %eax
   11324:      	leaq	0x8(%rsp), %rdi
   11329:      	movl	$0x8, %esi
   1132e:      	movq	%rbx, %rdx
   11331:      	callq	*%rax
   11333:      	addq	$0x20, %r12
   11337:      	movl	$0x4, %eax
   1133c:      	leaq	0x58(%rsp), %rdi
   11341:      	movl	$0x10, %ecx
   11346:      	movl	$0x10, %esi
   1134b:      	movq	%r12, %rdx
   1134e:      	callq	*%rax
   11350:      	movq	0x28(%rsp), %rbx
   11355:      	movq	0x48(%rsp), %rax
   1135a:      	movl	0x5c(%rsp), %r15d
   1135f:      	subq	%rbx, %rax
   11362:      	movl	0x50(%rsp), %r12d
   11367:      	movl	%r15d, %edx
   1136a:      	subl	%r12d, %edx
   1136d:      	movl	$0x0, %ecx
   11372:      	cmovbl	%ecx, %edx
   11375:      	addq	0x60(%rsp), %rdx
   1137a:      	xorl	%esi, %esi
   1137c:      	cmpl	%r15d, %r12d
   1137f:      	seta	%sil
   11383:      	movl	%r15d, %ecx
   11386:      	cmovbl	%r12d, %ecx
   1138a:      	addl	%ecx, %esi
   1138c:      	movl	%r12d, %edi
   1138f:      	subl	%esi, %edi
   11391:      	movl	%edi, 0x50(%rsp)
   11395:      	subq	%rsi, %rax
   11398:      	jb	0x15f32 <generic_fentry_path+0xba72>
   1139e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   113a4:      	ja	0x15f32 <generic_fentry_path+0xba72>
   113aa:      	cmpl	%r15d, %r12d
   113ad:      	jbe	0x113b3 <generic_fentry_path+0x6ef3>
   113af:      	movb	$0x2f, (%rbx,%rax)
   113b3:      	xorl	%edi, %edi
   113b5:      	cmpl	%r15d, %r12d
   113b8:      	seta	%dil
   113bc:      	movzbl	%cl, %esi
   113bf:      	addq	%rax, %rbx
   113c2:      	addq	%rbx, %rdi
   113c5:      	movl	$0x4, %eax
   113ca:      	callq	*%rax
   113cc:      	movq	%rbx, 0x48(%rsp)
   113d1:      	cmpl	%r15d, %r12d
   113d4:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   113da:      	movq	0x8(%rsp), %r12
   113df:      	movq	%r12, 0x30(%rsp)
   113e4:      	movq	0x38(%rsp), %rdx
   113e9:      	movq	0x40(%rsp), %r15
   113ee:      	jmp	0x11441 <generic_fentry_path+0x6f81>
   113f0:      	leaq	0x10(%r15), %rdx
   113f4:      	movl	$0x4, %eax
   113f9:      	movq	%rbp, %rdi
   113fc:      	movl	$0x8, %esi
   11401:      	callq	*%rax
   11403:      	movq	0x40(%rsp), %rax
   11408:      	cmpq	(%rsp), %rax
   1140c:      	je	0x15f2d <generic_fentry_path+0xba6d>
   11412:      	addq	$0x18, %r15
   11416:      	movl	$0x4, %eax
   1141b:      	leaq	0x30(%rsp), %rdi
   11420:      	movl	$0x8, %esi
   11425:      	movq	%r15, %rdx
   11428:      	callq	*%rax
   1142a:      	movq	(%rsp), %r15
   1142e:      	movq	%r15, 0x40(%rsp)
   11433:      	leaq	0x20(%r15), %rdx
   11437:      	movq	%rdx, 0x38(%rsp)
   1143c:      	movq	0x30(%rsp), %r12
   11441:      	cmpq	0x18(%rsp), %r12
   11446:      	jne	0x11453 <generic_fentry_path+0x6f93>
   11448:      	cmpq	0x20(%rsp), %rdx
   1144d:      	je	0x15f2d <generic_fentry_path+0xba6d>
   11453:      	movl	$0x4, %eax
   11458:      	leaq	0x10(%rsp), %rdi
   1145d:      	movl	$0x8, %esi
   11462:      	callq	*%rax
   11464:      	cmpq	0x10(%rsp), %r12
   11469:      	je	0x11561 <generic_fentry_path+0x70a1>
   1146f:      	leaq	0x18(%r12), %rbx
   11474:      	movl	$0x4, %eax
   11479:      	movq	%rbp, %rdi
   1147c:      	movl	$0x8, %esi
   11481:      	movq	%rbx, %rdx
   11484:      	callq	*%rax
   11486:      	cmpq	%r12, (%rsp)
   1148a:      	je	0x11561 <generic_fentry_path+0x70a1>
   11490:      	movl	$0x4, %eax
   11495:      	leaq	0x8(%rsp), %rdi
   1149a:      	movl	$0x8, %esi
   1149f:      	movq	%rbx, %rdx
   114a2:      	callq	*%rax
   114a4:      	addq	$0x20, %r12
   114a8:      	movl	$0x4, %eax
   114ad:      	leaq	0x58(%rsp), %rdi
   114b2:      	movl	$0x10, %ecx
   114b7:      	movl	$0x10, %esi
   114bc:      	movq	%r12, %rdx
   114bf:      	callq	*%rax
   114c1:      	movq	0x28(%rsp), %rbx
   114c6:      	movq	0x48(%rsp), %rax
   114cb:      	movl	0x5c(%rsp), %r15d
   114d0:      	subq	%rbx, %rax
   114d3:      	movl	0x50(%rsp), %r12d
   114d8:      	movl	%r15d, %edx
   114db:      	subl	%r12d, %edx
   114de:      	movl	$0x0, %ecx
   114e3:      	cmovbl	%ecx, %edx
   114e6:      	addq	0x60(%rsp), %rdx
   114eb:      	xorl	%esi, %esi
   114ed:      	cmpl	%r15d, %r12d
   114f0:      	seta	%sil
   114f4:      	movl	%r15d, %ecx
   114f7:      	cmovbl	%r12d, %ecx
   114fb:      	addl	%ecx, %esi
   114fd:      	movl	%r12d, %edi
   11500:      	subl	%esi, %edi
   11502:      	movl	%edi, 0x50(%rsp)
   11506:      	subq	%rsi, %rax
   11509:      	jb	0x15f32 <generic_fentry_path+0xba72>
   1150f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11515:      	ja	0x15f32 <generic_fentry_path+0xba72>
   1151b:      	cmpl	%r15d, %r12d
   1151e:      	jbe	0x11524 <generic_fentry_path+0x7064>
   11520:      	movb	$0x2f, (%rbx,%rax)
   11524:      	xorl	%edi, %edi
   11526:      	cmpl	%r15d, %r12d
   11529:      	seta	%dil
   1152d:      	movzbl	%cl, %esi
   11530:      	addq	%rax, %rbx
   11533:      	addq	%rbx, %rdi
   11536:      	movl	$0x4, %eax
   1153b:      	callq	*%rax
   1153d:      	movq	%rbx, 0x48(%rsp)
   11542:      	cmpl	%r15d, %r12d
   11545:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   1154b:      	movq	0x8(%rsp), %r12
   11550:      	movq	%r12, 0x30(%rsp)
   11555:      	movq	0x38(%rsp), %rdx
   1155a:      	movq	0x40(%rsp), %r15
   1155f:      	jmp	0x115b2 <generic_fentry_path+0x70f2>
   11561:      	leaq	0x10(%r15), %rdx
   11565:      	movl	$0x4, %eax
   1156a:      	movq	%rbp, %rdi
   1156d:      	movl	$0x8, %esi
   11572:      	callq	*%rax
   11574:      	movq	0x40(%rsp), %rax
   11579:      	cmpq	(%rsp), %rax
   1157d:      	je	0x15f2d <generic_fentry_path+0xba6d>
   11583:      	addq	$0x18, %r15
   11587:      	movl	$0x4, %eax
   1158c:      	leaq	0x30(%rsp), %rdi
   11591:      	movl	$0x8, %esi
   11596:      	movq	%r15, %rdx
   11599:      	callq	*%rax
   1159b:      	movq	(%rsp), %r15
   1159f:      	movq	%r15, 0x40(%rsp)
   115a4:      	leaq	0x20(%r15), %rdx
   115a8:      	movq	%rdx, 0x38(%rsp)
   115ad:      	movq	0x30(%rsp), %r12
   115b2:      	cmpq	0x18(%rsp), %r12
   115b7:      	jne	0x115c4 <generic_fentry_path+0x7104>
   115b9:      	cmpq	0x20(%rsp), %rdx
   115be:      	je	0x15f2d <generic_fentry_path+0xba6d>
   115c4:      	movl	$0x4, %eax
   115c9:      	leaq	0x10(%rsp), %rdi
   115ce:      	movl	$0x8, %esi
   115d3:      	callq	*%rax
   115d5:      	cmpq	0x10(%rsp), %r12
   115da:      	je	0x116d2 <generic_fentry_path+0x7212>
   115e0:      	leaq	0x18(%r12), %rbx
   115e5:      	movl	$0x4, %eax
   115ea:      	movq	%rbp, %rdi
   115ed:      	movl	$0x8, %esi
   115f2:      	movq	%rbx, %rdx
   115f5:      	callq	*%rax
   115f7:      	cmpq	%r12, (%rsp)
   115fb:      	je	0x116d2 <generic_fentry_path+0x7212>
   11601:      	movl	$0x4, %eax
   11606:      	leaq	0x8(%rsp), %rdi
   1160b:      	movl	$0x8, %esi
   11610:      	movq	%rbx, %rdx
   11613:      	callq	*%rax
   11615:      	addq	$0x20, %r12
   11619:      	movl	$0x4, %eax
   1161e:      	leaq	0x58(%rsp), %rdi
   11623:      	movl	$0x10, %ecx
   11628:      	movl	$0x10, %esi
   1162d:      	movq	%r12, %rdx
   11630:      	callq	*%rax
   11632:      	movq	0x28(%rsp), %rbx
   11637:      	movq	0x48(%rsp), %rax
   1163c:      	movl	0x5c(%rsp), %r15d
   11641:      	subq	%rbx, %rax
   11644:      	movl	0x50(%rsp), %r12d
   11649:      	movl	%r15d, %edx
   1164c:      	subl	%r12d, %edx
   1164f:      	movl	$0x0, %ecx
   11654:      	cmovbl	%ecx, %edx
   11657:      	addq	0x60(%rsp), %rdx
   1165c:      	xorl	%esi, %esi
   1165e:      	cmpl	%r15d, %r12d
   11661:      	seta	%sil
   11665:      	movl	%r15d, %ecx
   11668:      	cmovbl	%r12d, %ecx
   1166c:      	addl	%ecx, %esi
   1166e:      	movl	%r12d, %edi
   11671:      	subl	%esi, %edi
   11673:      	movl	%edi, 0x50(%rsp)
   11677:      	subq	%rsi, %rax
   1167a:      	jb	0x15f32 <generic_fentry_path+0xba72>
   11680:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11686:      	ja	0x15f32 <generic_fentry_path+0xba72>
   1168c:      	cmpl	%r15d, %r12d
   1168f:      	jbe	0x11695 <generic_fentry_path+0x71d5>
   11691:      	movb	$0x2f, (%rbx,%rax)
   11695:      	xorl	%edi, %edi
   11697:      	cmpl	%r15d, %r12d
   1169a:      	seta	%dil
   1169e:      	movzbl	%cl, %esi
   116a1:      	addq	%rax, %rbx
   116a4:      	addq	%rbx, %rdi
   116a7:      	movl	$0x4, %eax
   116ac:      	callq	*%rax
   116ae:      	movq	%rbx, 0x48(%rsp)
   116b3:      	cmpl	%r15d, %r12d
   116b6:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   116bc:      	movq	0x8(%rsp), %r12
   116c1:      	movq	%r12, 0x30(%rsp)
   116c6:      	movq	0x38(%rsp), %rdx
   116cb:      	movq	0x40(%rsp), %r15
   116d0:      	jmp	0x11723 <generic_fentry_path+0x7263>
   116d2:      	leaq	0x10(%r15), %rdx
   116d6:      	movl	$0x4, %eax
   116db:      	movq	%rbp, %rdi
   116de:      	movl	$0x8, %esi
   116e3:      	callq	*%rax
   116e5:      	movq	0x40(%rsp), %rax
   116ea:      	cmpq	(%rsp), %rax
   116ee:      	je	0x15f2d <generic_fentry_path+0xba6d>
   116f4:      	addq	$0x18, %r15
   116f8:      	movl	$0x4, %eax
   116fd:      	leaq	0x30(%rsp), %rdi
   11702:      	movl	$0x8, %esi
   11707:      	movq	%r15, %rdx
   1170a:      	callq	*%rax
   1170c:      	movq	(%rsp), %r15
   11710:      	movq	%r15, 0x40(%rsp)
   11715:      	leaq	0x20(%r15), %rdx
   11719:      	movq	%rdx, 0x38(%rsp)
   1171e:      	movq	0x30(%rsp), %r12
   11723:      	cmpq	0x18(%rsp), %r12
   11728:      	jne	0x11735 <generic_fentry_path+0x7275>
   1172a:      	cmpq	0x20(%rsp), %rdx
   1172f:      	je	0x15f2d <generic_fentry_path+0xba6d>
   11735:      	movl	$0x4, %eax
   1173a:      	leaq	0x10(%rsp), %rdi
   1173f:      	movl	$0x8, %esi
   11744:      	callq	*%rax
   11746:      	cmpq	0x10(%rsp), %r12
   1174b:      	je	0x11843 <generic_fentry_path+0x7383>
   11751:      	leaq	0x18(%r12), %rbx
   11756:      	movl	$0x4, %eax
   1175b:      	movq	%rbp, %rdi
   1175e:      	movl	$0x8, %esi
   11763:      	movq	%rbx, %rdx
   11766:      	callq	*%rax
   11768:      	cmpq	%r12, (%rsp)
   1176c:      	je	0x11843 <generic_fentry_path+0x7383>
   11772:      	movl	$0x4, %eax
   11777:      	leaq	0x8(%rsp), %rdi
   1177c:      	movl	$0x8, %esi
   11781:      	movq	%rbx, %rdx
   11784:      	callq	*%rax
   11786:      	addq	$0x20, %r12
   1178a:      	movl	$0x4, %eax
   1178f:      	leaq	0x58(%rsp), %rdi
   11794:      	movl	$0x10, %ecx
   11799:      	movl	$0x10, %esi
   1179e:      	movq	%r12, %rdx
   117a1:      	callq	*%rax
   117a3:      	movq	0x28(%rsp), %rbx
   117a8:      	movq	0x48(%rsp), %rax
   117ad:      	movl	0x5c(%rsp), %r15d
   117b2:      	subq	%rbx, %rax
   117b5:      	movl	0x50(%rsp), %r12d
   117ba:      	movl	%r15d, %edx
   117bd:      	subl	%r12d, %edx
   117c0:      	movl	$0x0, %ecx
   117c5:      	cmovbl	%ecx, %edx
   117c8:      	addq	0x60(%rsp), %rdx
   117cd:      	xorl	%esi, %esi
   117cf:      	cmpl	%r15d, %r12d
   117d2:      	seta	%sil
   117d6:      	movl	%r15d, %ecx
   117d9:      	cmovbl	%r12d, %ecx
   117dd:      	addl	%ecx, %esi
   117df:      	movl	%r12d, %edi
   117e2:      	subl	%esi, %edi
   117e4:      	movl	%edi, 0x50(%rsp)
   117e8:      	subq	%rsi, %rax
   117eb:      	jb	0x15f32 <generic_fentry_path+0xba72>
   117f1:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   117f7:      	ja	0x15f32 <generic_fentry_path+0xba72>
   117fd:      	cmpl	%r15d, %r12d
   11800:      	jbe	0x11806 <generic_fentry_path+0x7346>
   11802:      	movb	$0x2f, (%rbx,%rax)
   11806:      	xorl	%edi, %edi
   11808:      	cmpl	%r15d, %r12d
   1180b:      	seta	%dil
   1180f:      	movzbl	%cl, %esi
   11812:      	addq	%rax, %rbx
   11815:      	addq	%rbx, %rdi
   11818:      	movl	$0x4, %eax
   1181d:      	callq	*%rax
   1181f:      	movq	%rbx, 0x48(%rsp)
   11824:      	cmpl	%r15d, %r12d
   11827:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   1182d:      	movq	0x8(%rsp), %r12
   11832:      	movq	%r12, 0x30(%rsp)
   11837:      	movq	0x38(%rsp), %rdx
   1183c:      	movq	0x40(%rsp), %r15
   11841:      	jmp	0x11894 <generic_fentry_path+0x73d4>
   11843:      	leaq	0x10(%r15), %rdx
   11847:      	movl	$0x4, %eax
   1184c:      	movq	%rbp, %rdi
   1184f:      	movl	$0x8, %esi
   11854:      	callq	*%rax
   11856:      	movq	0x40(%rsp), %rax
   1185b:      	cmpq	(%rsp), %rax
   1185f:      	je	0x15f2d <generic_fentry_path+0xba6d>
   11865:      	addq	$0x18, %r15
   11869:      	movl	$0x4, %eax
   1186e:      	leaq	0x30(%rsp), %rdi
   11873:      	movl	$0x8, %esi
   11878:      	movq	%r15, %rdx
   1187b:      	callq	*%rax
   1187d:      	movq	(%rsp), %r15
   11881:      	movq	%r15, 0x40(%rsp)
   11886:      	leaq	0x20(%r15), %rdx
   1188a:      	movq	%rdx, 0x38(%rsp)
   1188f:      	movq	0x30(%rsp), %r12
   11894:      	cmpq	0x18(%rsp), %r12
   11899:      	jne	0x118a6 <generic_fentry_path+0x73e6>
   1189b:      	cmpq	0x20(%rsp), %rdx
   118a0:      	je	0x15f2d <generic_fentry_path+0xba6d>
   118a6:      	movl	$0x4, %eax
   118ab:      	leaq	0x10(%rsp), %rdi
   118b0:      	movl	$0x8, %esi
   118b5:      	callq	*%rax
   118b7:      	cmpq	0x10(%rsp), %r12
   118bc:      	je	0x119b4 <generic_fentry_path+0x74f4>
   118c2:      	leaq	0x18(%r12), %rbx
   118c7:      	movl	$0x4, %eax
   118cc:      	movq	%rbp, %rdi
   118cf:      	movl	$0x8, %esi
   118d4:      	movq	%rbx, %rdx
   118d7:      	callq	*%rax
   118d9:      	cmpq	%r12, (%rsp)
   118dd:      	je	0x119b4 <generic_fentry_path+0x74f4>
   118e3:      	movl	$0x4, %eax
   118e8:      	leaq	0x8(%rsp), %rdi
   118ed:      	movl	$0x8, %esi
   118f2:      	movq	%rbx, %rdx
   118f5:      	callq	*%rax
   118f7:      	addq	$0x20, %r12
   118fb:      	movl	$0x4, %eax
   11900:      	leaq	0x58(%rsp), %rdi
   11905:      	movl	$0x10, %ecx
   1190a:      	movl	$0x10, %esi
   1190f:      	movq	%r12, %rdx
   11912:      	callq	*%rax
   11914:      	movq	0x28(%rsp), %rbx
   11919:      	movq	0x48(%rsp), %rax
   1191e:      	movl	0x5c(%rsp), %r15d
   11923:      	subq	%rbx, %rax
   11926:      	movl	0x50(%rsp), %r12d
   1192b:      	movl	%r15d, %edx
   1192e:      	subl	%r12d, %edx
   11931:      	movl	$0x0, %ecx
   11936:      	cmovbl	%ecx, %edx
   11939:      	addq	0x60(%rsp), %rdx
   1193e:      	xorl	%esi, %esi
   11940:      	cmpl	%r15d, %r12d
   11943:      	seta	%sil
   11947:      	movl	%r15d, %ecx
   1194a:      	cmovbl	%r12d, %ecx
   1194e:      	addl	%ecx, %esi
   11950:      	movl	%r12d, %edi
   11953:      	subl	%esi, %edi
   11955:      	movl	%edi, 0x50(%rsp)
   11959:      	subq	%rsi, %rax
   1195c:      	jb	0x15f32 <generic_fentry_path+0xba72>
   11962:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11968:      	ja	0x15f32 <generic_fentry_path+0xba72>
   1196e:      	cmpl	%r15d, %r12d
   11971:      	jbe	0x11977 <generic_fentry_path+0x74b7>
   11973:      	movb	$0x2f, (%rbx,%rax)
   11977:      	xorl	%edi, %edi
   11979:      	cmpl	%r15d, %r12d
   1197c:      	seta	%dil
   11980:      	movzbl	%cl, %esi
   11983:      	addq	%rax, %rbx
   11986:      	addq	%rbx, %rdi
   11989:      	movl	$0x4, %eax
   1198e:      	callq	*%rax
   11990:      	movq	%rbx, 0x48(%rsp)
   11995:      	cmpl	%r15d, %r12d
   11998:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   1199e:      	movq	0x8(%rsp), %r12
   119a3:      	movq	%r12, 0x30(%rsp)
   119a8:      	movq	0x38(%rsp), %rdx
   119ad:      	movq	0x40(%rsp), %r15
   119b2:      	jmp	0x11a05 <generic_fentry_path+0x7545>
   119b4:      	leaq	0x10(%r15), %rdx
   119b8:      	movl	$0x4, %eax
   119bd:      	movq	%rbp, %rdi
   119c0:      	movl	$0x8, %esi
   119c5:      	callq	*%rax
   119c7:      	movq	0x40(%rsp), %rax
   119cc:      	cmpq	(%rsp), %rax
   119d0:      	je	0x15f2d <generic_fentry_path+0xba6d>
   119d6:      	addq	$0x18, %r15
   119da:      	movl	$0x4, %eax
   119df:      	leaq	0x30(%rsp), %rdi
   119e4:      	movl	$0x8, %esi
   119e9:      	movq	%r15, %rdx
   119ec:      	callq	*%rax
   119ee:      	movq	(%rsp), %r15
   119f2:      	movq	%r15, 0x40(%rsp)
   119f7:      	leaq	0x20(%r15), %rdx
   119fb:      	movq	%rdx, 0x38(%rsp)
   11a00:      	movq	0x30(%rsp), %r12
   11a05:      	cmpq	0x18(%rsp), %r12
   11a0a:      	jne	0x11a17 <generic_fentry_path+0x7557>
   11a0c:      	cmpq	0x20(%rsp), %rdx
   11a11:      	je	0x15f2d <generic_fentry_path+0xba6d>
   11a17:      	movl	$0x4, %eax
   11a1c:      	leaq	0x10(%rsp), %rdi
   11a21:      	movl	$0x8, %esi
   11a26:      	callq	*%rax
   11a28:      	cmpq	0x10(%rsp), %r12
   11a2d:      	je	0x11b25 <generic_fentry_path+0x7665>
   11a33:      	leaq	0x18(%r12), %rbx
   11a38:      	movl	$0x4, %eax
   11a3d:      	movq	%rbp, %rdi
   11a40:      	movl	$0x8, %esi
   11a45:      	movq	%rbx, %rdx
   11a48:      	callq	*%rax
   11a4a:      	cmpq	%r12, (%rsp)
   11a4e:      	je	0x11b25 <generic_fentry_path+0x7665>
   11a54:      	movl	$0x4, %eax
   11a59:      	leaq	0x8(%rsp), %rdi
   11a5e:      	movl	$0x8, %esi
   11a63:      	movq	%rbx, %rdx
   11a66:      	callq	*%rax
   11a68:      	addq	$0x20, %r12
   11a6c:      	movl	$0x4, %eax
   11a71:      	leaq	0x58(%rsp), %rdi
   11a76:      	movl	$0x10, %ecx
   11a7b:      	movl	$0x10, %esi
   11a80:      	movq	%r12, %rdx
   11a83:      	callq	*%rax
   11a85:      	movq	0x28(%rsp), %rbx
   11a8a:      	movq	0x48(%rsp), %rax
   11a8f:      	movl	0x5c(%rsp), %r15d
   11a94:      	subq	%rbx, %rax
   11a97:      	movl	0x50(%rsp), %r12d
   11a9c:      	movl	%r15d, %edx
   11a9f:      	subl	%r12d, %edx
   11aa2:      	movl	$0x0, %ecx
   11aa7:      	cmovbl	%ecx, %edx
   11aaa:      	addq	0x60(%rsp), %rdx
   11aaf:      	xorl	%esi, %esi
   11ab1:      	cmpl	%r15d, %r12d
   11ab4:      	seta	%sil
   11ab8:      	movl	%r15d, %ecx
   11abb:      	cmovbl	%r12d, %ecx
   11abf:      	addl	%ecx, %esi
   11ac1:      	movl	%r12d, %edi
   11ac4:      	subl	%esi, %edi
   11ac6:      	movl	%edi, 0x50(%rsp)
   11aca:      	subq	%rsi, %rax
   11acd:      	jb	0x15f32 <generic_fentry_path+0xba72>
   11ad3:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11ad9:      	ja	0x15f32 <generic_fentry_path+0xba72>
   11adf:      	cmpl	%r15d, %r12d
   11ae2:      	jbe	0x11ae8 <generic_fentry_path+0x7628>
   11ae4:      	movb	$0x2f, (%rbx,%rax)
   11ae8:      	xorl	%edi, %edi
   11aea:      	cmpl	%r15d, %r12d
   11aed:      	seta	%dil
   11af1:      	movzbl	%cl, %esi
   11af4:      	addq	%rax, %rbx
   11af7:      	addq	%rbx, %rdi
   11afa:      	movl	$0x4, %eax
   11aff:      	callq	*%rax
   11b01:      	movq	%rbx, 0x48(%rsp)
   11b06:      	cmpl	%r15d, %r12d
   11b09:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   11b0f:      	movq	0x8(%rsp), %r12
   11b14:      	movq	%r12, 0x30(%rsp)
   11b19:      	movq	0x38(%rsp), %rdx
   11b1e:      	movq	0x40(%rsp), %r15
   11b23:      	jmp	0x11b76 <generic_fentry_path+0x76b6>
   11b25:      	leaq	0x10(%r15), %rdx
   11b29:      	movl	$0x4, %eax
   11b2e:      	movq	%rbp, %rdi
   11b31:      	movl	$0x8, %esi
   11b36:      	callq	*%rax
   11b38:      	movq	0x40(%rsp), %rax
   11b3d:      	cmpq	(%rsp), %rax
   11b41:      	je	0x15f2d <generic_fentry_path+0xba6d>
   11b47:      	addq	$0x18, %r15
   11b4b:      	movl	$0x4, %eax
   11b50:      	leaq	0x30(%rsp), %rdi
   11b55:      	movl	$0x8, %esi
   11b5a:      	movq	%r15, %rdx
   11b5d:      	callq	*%rax
   11b5f:      	movq	(%rsp), %r15
   11b63:      	movq	%r15, 0x40(%rsp)
   11b68:      	leaq	0x20(%r15), %rdx
   11b6c:      	movq	%rdx, 0x38(%rsp)
   11b71:      	movq	0x30(%rsp), %r12
   11b76:      	cmpq	0x18(%rsp), %r12
   11b7b:      	jne	0x11b88 <generic_fentry_path+0x76c8>
   11b7d:      	cmpq	0x20(%rsp), %rdx
   11b82:      	je	0x15f2d <generic_fentry_path+0xba6d>
   11b88:      	movl	$0x4, %eax
   11b8d:      	leaq	0x10(%rsp), %rdi
   11b92:      	movl	$0x8, %esi
   11b97:      	callq	*%rax
   11b99:      	cmpq	0x10(%rsp), %r12
   11b9e:      	je	0x11c96 <generic_fentry_path+0x77d6>
   11ba4:      	leaq	0x18(%r12), %rbx
   11ba9:      	movl	$0x4, %eax
   11bae:      	movq	%rbp, %rdi
   11bb1:      	movl	$0x8, %esi
   11bb6:      	movq	%rbx, %rdx
   11bb9:      	callq	*%rax
   11bbb:      	cmpq	%r12, (%rsp)
   11bbf:      	je	0x11c96 <generic_fentry_path+0x77d6>
   11bc5:      	movl	$0x4, %eax
   11bca:      	leaq	0x8(%rsp), %rdi
   11bcf:      	movl	$0x8, %esi
   11bd4:      	movq	%rbx, %rdx
   11bd7:      	callq	*%rax
   11bd9:      	addq	$0x20, %r12
   11bdd:      	movl	$0x4, %eax
   11be2:      	leaq	0x58(%rsp), %rdi
   11be7:      	movl	$0x10, %ecx
   11bec:      	movl	$0x10, %esi
   11bf1:      	movq	%r12, %rdx
   11bf4:      	callq	*%rax
   11bf6:      	movq	0x28(%rsp), %rbx
   11bfb:      	movq	0x48(%rsp), %rax
   11c00:      	movl	0x5c(%rsp), %r15d
   11c05:      	subq	%rbx, %rax
   11c08:      	movl	0x50(%rsp), %r12d
   11c0d:      	movl	%r15d, %edx
   11c10:      	subl	%r12d, %edx
   11c13:      	movl	$0x0, %ecx
   11c18:      	cmovbl	%ecx, %edx
   11c1b:      	addq	0x60(%rsp), %rdx
   11c20:      	xorl	%esi, %esi
   11c22:      	cmpl	%r15d, %r12d
   11c25:      	seta	%sil
   11c29:      	movl	%r15d, %ecx
   11c2c:      	cmovbl	%r12d, %ecx
   11c30:      	addl	%ecx, %esi
   11c32:      	movl	%r12d, %edi
   11c35:      	subl	%esi, %edi
   11c37:      	movl	%edi, 0x50(%rsp)
   11c3b:      	subq	%rsi, %rax
   11c3e:      	jb	0x15f32 <generic_fentry_path+0xba72>
   11c44:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11c4a:      	ja	0x15f32 <generic_fentry_path+0xba72>
   11c50:      	cmpl	%r15d, %r12d
   11c53:      	jbe	0x11c59 <generic_fentry_path+0x7799>
   11c55:      	movb	$0x2f, (%rbx,%rax)
   11c59:      	xorl	%edi, %edi
   11c5b:      	cmpl	%r15d, %r12d
   11c5e:      	seta	%dil
   11c62:      	movzbl	%cl, %esi
   11c65:      	addq	%rax, %rbx
   11c68:      	addq	%rbx, %rdi
   11c6b:      	movl	$0x4, %eax
   11c70:      	callq	*%rax
   11c72:      	movq	%rbx, 0x48(%rsp)
   11c77:      	cmpl	%r15d, %r12d
   11c7a:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   11c80:      	movq	0x8(%rsp), %r12
   11c85:      	movq	%r12, 0x30(%rsp)
   11c8a:      	movq	0x38(%rsp), %rdx
   11c8f:      	movq	0x40(%rsp), %r15
   11c94:      	jmp	0x11ce7 <generic_fentry_path+0x7827>
   11c96:      	leaq	0x10(%r15), %rdx
   11c9a:      	movl	$0x4, %eax
   11c9f:      	movq	%rbp, %rdi
   11ca2:      	movl	$0x8, %esi
   11ca7:      	callq	*%rax
   11ca9:      	movq	0x40(%rsp), %rax
   11cae:      	cmpq	(%rsp), %rax
   11cb2:      	je	0x15f2d <generic_fentry_path+0xba6d>
   11cb8:      	addq	$0x18, %r15
   11cbc:      	movl	$0x4, %eax
   11cc1:      	leaq	0x30(%rsp), %rdi
   11cc6:      	movl	$0x8, %esi
   11ccb:      	movq	%r15, %rdx
   11cce:      	callq	*%rax
   11cd0:      	movq	(%rsp), %r15
   11cd4:      	movq	%r15, 0x40(%rsp)
   11cd9:      	leaq	0x20(%r15), %rdx
   11cdd:      	movq	%rdx, 0x38(%rsp)
   11ce2:      	movq	0x30(%rsp), %r12
   11ce7:      	cmpq	0x18(%rsp), %r12
   11cec:      	jne	0x11cf9 <generic_fentry_path+0x7839>
   11cee:      	cmpq	0x20(%rsp), %rdx
   11cf3:      	je	0x15f2d <generic_fentry_path+0xba6d>
   11cf9:      	movl	$0x4, %eax
   11cfe:      	leaq	0x10(%rsp), %rdi
   11d03:      	movl	$0x8, %esi
   11d08:      	callq	*%rax
   11d0a:      	cmpq	0x10(%rsp), %r12
   11d0f:      	je	0x11e07 <generic_fentry_path+0x7947>
   11d15:      	leaq	0x18(%r12), %rbx
   11d1a:      	movl	$0x4, %eax
   11d1f:      	movq	%rbp, %rdi
   11d22:      	movl	$0x8, %esi
   11d27:      	movq	%rbx, %rdx
   11d2a:      	callq	*%rax
   11d2c:      	cmpq	%r12, (%rsp)
   11d30:      	je	0x11e07 <generic_fentry_path+0x7947>
   11d36:      	movl	$0x4, %eax
   11d3b:      	leaq	0x8(%rsp), %rdi
   11d40:      	movl	$0x8, %esi
   11d45:      	movq	%rbx, %rdx
   11d48:      	callq	*%rax
   11d4a:      	addq	$0x20, %r12
   11d4e:      	movl	$0x4, %eax
   11d53:      	leaq	0x58(%rsp), %rdi
   11d58:      	movl	$0x10, %ecx
   11d5d:      	movl	$0x10, %esi
   11d62:      	movq	%r12, %rdx
   11d65:      	callq	*%rax
   11d67:      	movq	0x28(%rsp), %rbx
   11d6c:      	movq	0x48(%rsp), %rax
   11d71:      	movl	0x5c(%rsp), %r15d
   11d76:      	subq	%rbx, %rax
   11d79:      	movl	0x50(%rsp), %r12d
   11d7e:      	movl	%r15d, %edx
   11d81:      	subl	%r12d, %edx
   11d84:      	movl	$0x0, %ecx
   11d89:      	cmovbl	%ecx, %edx
   11d8c:      	addq	0x60(%rsp), %rdx
   11d91:      	xorl	%esi, %esi
   11d93:      	cmpl	%r15d, %r12d
   11d96:      	seta	%sil
   11d9a:      	movl	%r15d, %ecx
   11d9d:      	cmovbl	%r12d, %ecx
   11da1:      	addl	%ecx, %esi
   11da3:      	movl	%r12d, %edi
   11da6:      	subl	%esi, %edi
   11da8:      	movl	%edi, 0x50(%rsp)
   11dac:      	subq	%rsi, %rax
   11daf:      	jb	0x15f32 <generic_fentry_path+0xba72>
   11db5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11dbb:      	ja	0x15f32 <generic_fentry_path+0xba72>
   11dc1:      	cmpl	%r15d, %r12d
   11dc4:      	jbe	0x11dca <generic_fentry_path+0x790a>
   11dc6:      	movb	$0x2f, (%rbx,%rax)
   11dca:      	xorl	%edi, %edi
   11dcc:      	cmpl	%r15d, %r12d
   11dcf:      	seta	%dil
   11dd3:      	movzbl	%cl, %esi
   11dd6:      	addq	%rax, %rbx
   11dd9:      	addq	%rbx, %rdi
   11ddc:      	movl	$0x4, %eax
   11de1:      	callq	*%rax
   11de3:      	movq	%rbx, 0x48(%rsp)
   11de8:      	cmpl	%r15d, %r12d
   11deb:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   11df1:      	movq	0x8(%rsp), %r12
   11df6:      	movq	%r12, 0x30(%rsp)
   11dfb:      	movq	0x38(%rsp), %rdx
   11e00:      	movq	0x40(%rsp), %r15
   11e05:      	jmp	0x11e58 <generic_fentry_path+0x7998>
   11e07:      	leaq	0x10(%r15), %rdx
   11e0b:      	movl	$0x4, %eax
   11e10:      	movq	%rbp, %rdi
   11e13:      	movl	$0x8, %esi
   11e18:      	callq	*%rax
   11e1a:      	movq	0x40(%rsp), %rax
   11e1f:      	cmpq	(%rsp), %rax
   11e23:      	je	0x15f2d <generic_fentry_path+0xba6d>
   11e29:      	addq	$0x18, %r15
   11e2d:      	movl	$0x4, %eax
   11e32:      	leaq	0x30(%rsp), %rdi
   11e37:      	movl	$0x8, %esi
   11e3c:      	movq	%r15, %rdx
   11e3f:      	callq	*%rax
   11e41:      	movq	(%rsp), %r15
   11e45:      	movq	%r15, 0x40(%rsp)
   11e4a:      	leaq	0x20(%r15), %rdx
   11e4e:      	movq	%rdx, 0x38(%rsp)
   11e53:      	movq	0x30(%rsp), %r12
   11e58:      	cmpq	0x18(%rsp), %r12
   11e5d:      	jne	0x11e6a <generic_fentry_path+0x79aa>
   11e5f:      	cmpq	0x20(%rsp), %rdx
   11e64:      	je	0x15f2d <generic_fentry_path+0xba6d>
   11e6a:      	movl	$0x4, %eax
   11e6f:      	leaq	0x10(%rsp), %rdi
   11e74:      	movl	$0x8, %esi
   11e79:      	callq	*%rax
   11e7b:      	cmpq	0x10(%rsp), %r12
   11e80:      	je	0x11f78 <generic_fentry_path+0x7ab8>
   11e86:      	leaq	0x18(%r12), %rbx
   11e8b:      	movl	$0x4, %eax
   11e90:      	movq	%rbp, %rdi
   11e93:      	movl	$0x8, %esi
   11e98:      	movq	%rbx, %rdx
   11e9b:      	callq	*%rax
   11e9d:      	cmpq	%r12, (%rsp)
   11ea1:      	je	0x11f78 <generic_fentry_path+0x7ab8>
   11ea7:      	movl	$0x4, %eax
   11eac:      	leaq	0x8(%rsp), %rdi
   11eb1:      	movl	$0x8, %esi
   11eb6:      	movq	%rbx, %rdx
   11eb9:      	callq	*%rax
   11ebb:      	addq	$0x20, %r12
   11ebf:      	movl	$0x4, %eax
   11ec4:      	leaq	0x58(%rsp), %rdi
   11ec9:      	movl	$0x10, %ecx
   11ece:      	movl	$0x10, %esi
   11ed3:      	movq	%r12, %rdx
   11ed6:      	callq	*%rax
   11ed8:      	movq	0x28(%rsp), %rbx
   11edd:      	movq	0x48(%rsp), %rax
   11ee2:      	movl	0x5c(%rsp), %r15d
   11ee7:      	subq	%rbx, %rax
   11eea:      	movl	0x50(%rsp), %r12d
   11eef:      	movl	%r15d, %edx
   11ef2:      	subl	%r12d, %edx
   11ef5:      	movl	$0x0, %ecx
   11efa:      	cmovbl	%ecx, %edx
   11efd:      	addq	0x60(%rsp), %rdx
   11f02:      	xorl	%esi, %esi
   11f04:      	cmpl	%r15d, %r12d
   11f07:      	seta	%sil
   11f0b:      	movl	%r15d, %ecx
   11f0e:      	cmovbl	%r12d, %ecx
   11f12:      	addl	%ecx, %esi
   11f14:      	movl	%r12d, %edi
   11f17:      	subl	%esi, %edi
   11f19:      	movl	%edi, 0x50(%rsp)
   11f1d:      	subq	%rsi, %rax
   11f20:      	jb	0x15f32 <generic_fentry_path+0xba72>
   11f26:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11f2c:      	ja	0x15f32 <generic_fentry_path+0xba72>
   11f32:      	cmpl	%r15d, %r12d
   11f35:      	jbe	0x11f3b <generic_fentry_path+0x7a7b>
   11f37:      	movb	$0x2f, (%rbx,%rax)
   11f3b:      	xorl	%edi, %edi
   11f3d:      	cmpl	%r15d, %r12d
   11f40:      	seta	%dil
   11f44:      	movzbl	%cl, %esi
   11f47:      	addq	%rax, %rbx
   11f4a:      	addq	%rbx, %rdi
   11f4d:      	movl	$0x4, %eax
   11f52:      	callq	*%rax
   11f54:      	movq	%rbx, 0x48(%rsp)
   11f59:      	cmpl	%r15d, %r12d
   11f5c:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   11f62:      	movq	0x8(%rsp), %r12
   11f67:      	movq	%r12, 0x30(%rsp)
   11f6c:      	movq	0x38(%rsp), %rdx
   11f71:      	movq	0x40(%rsp), %r15
   11f76:      	jmp	0x11fc9 <generic_fentry_path+0x7b09>
   11f78:      	leaq	0x10(%r15), %rdx
   11f7c:      	movl	$0x4, %eax
   11f81:      	movq	%rbp, %rdi
   11f84:      	movl	$0x8, %esi
   11f89:      	callq	*%rax
   11f8b:      	movq	0x40(%rsp), %rax
   11f90:      	cmpq	(%rsp), %rax
   11f94:      	je	0x15f2d <generic_fentry_path+0xba6d>
   11f9a:      	addq	$0x18, %r15
   11f9e:      	movl	$0x4, %eax
   11fa3:      	leaq	0x30(%rsp), %rdi
   11fa8:      	movl	$0x8, %esi
   11fad:      	movq	%r15, %rdx
   11fb0:      	callq	*%rax
   11fb2:      	movq	(%rsp), %r15
   11fb6:      	movq	%r15, 0x40(%rsp)
   11fbb:      	leaq	0x20(%r15), %rdx
   11fbf:      	movq	%rdx, 0x38(%rsp)
   11fc4:      	movq	0x30(%rsp), %r12
   11fc9:      	cmpq	0x18(%rsp), %r12
   11fce:      	jne	0x11fdb <generic_fentry_path+0x7b1b>
   11fd0:      	cmpq	0x20(%rsp), %rdx
   11fd5:      	je	0x15f2d <generic_fentry_path+0xba6d>
   11fdb:      	movl	$0x4, %eax
   11fe0:      	leaq	0x10(%rsp), %rdi
   11fe5:      	movl	$0x8, %esi
   11fea:      	callq	*%rax
   11fec:      	cmpq	0x10(%rsp), %r12
   11ff1:      	je	0x120e9 <generic_fentry_path+0x7c29>
   11ff7:      	leaq	0x18(%r12), %rbx
   11ffc:      	movl	$0x4, %eax
   12001:      	movq	%rbp, %rdi
   12004:      	movl	$0x8, %esi
   12009:      	movq	%rbx, %rdx
   1200c:      	callq	*%rax
   1200e:      	cmpq	%r12, (%rsp)
   12012:      	je	0x120e9 <generic_fentry_path+0x7c29>
   12018:      	movl	$0x4, %eax
   1201d:      	leaq	0x8(%rsp), %rdi
   12022:      	movl	$0x8, %esi
   12027:      	movq	%rbx, %rdx
   1202a:      	callq	*%rax
   1202c:      	addq	$0x20, %r12
   12030:      	movl	$0x4, %eax
   12035:      	leaq	0x58(%rsp), %rdi
   1203a:      	movl	$0x10, %ecx
   1203f:      	movl	$0x10, %esi
   12044:      	movq	%r12, %rdx
   12047:      	callq	*%rax
   12049:      	movq	0x28(%rsp), %rbx
   1204e:      	movq	0x48(%rsp), %rax
   12053:      	movl	0x5c(%rsp), %r15d
   12058:      	subq	%rbx, %rax
   1205b:      	movl	0x50(%rsp), %r12d
   12060:      	movl	%r15d, %edx
   12063:      	subl	%r12d, %edx
   12066:      	movl	$0x0, %ecx
   1206b:      	cmovbl	%ecx, %edx
   1206e:      	addq	0x60(%rsp), %rdx
   12073:      	xorl	%esi, %esi
   12075:      	cmpl	%r15d, %r12d
   12078:      	seta	%sil
   1207c:      	movl	%r15d, %ecx
   1207f:      	cmovbl	%r12d, %ecx
   12083:      	addl	%ecx, %esi
   12085:      	movl	%r12d, %edi
   12088:      	subl	%esi, %edi
   1208a:      	movl	%edi, 0x50(%rsp)
   1208e:      	subq	%rsi, %rax
   12091:      	jb	0x15f32 <generic_fentry_path+0xba72>
   12097:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1209d:      	ja	0x15f32 <generic_fentry_path+0xba72>
   120a3:      	cmpl	%r15d, %r12d
   120a6:      	jbe	0x120ac <generic_fentry_path+0x7bec>
   120a8:      	movb	$0x2f, (%rbx,%rax)
   120ac:      	xorl	%edi, %edi
   120ae:      	cmpl	%r15d, %r12d
   120b1:      	seta	%dil
   120b5:      	movzbl	%cl, %esi
   120b8:      	addq	%rax, %rbx
   120bb:      	addq	%rbx, %rdi
   120be:      	movl	$0x4, %eax
   120c3:      	callq	*%rax
   120c5:      	movq	%rbx, 0x48(%rsp)
   120ca:      	cmpl	%r15d, %r12d
   120cd:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   120d3:      	movq	0x8(%rsp), %r12
   120d8:      	movq	%r12, 0x30(%rsp)
   120dd:      	movq	0x38(%rsp), %rdx
   120e2:      	movq	0x40(%rsp), %r15
   120e7:      	jmp	0x1213a <generic_fentry_path+0x7c7a>
   120e9:      	leaq	0x10(%r15), %rdx
   120ed:      	movl	$0x4, %eax
   120f2:      	movq	%rbp, %rdi
   120f5:      	movl	$0x8, %esi
   120fa:      	callq	*%rax
   120fc:      	movq	0x40(%rsp), %rax
   12101:      	cmpq	(%rsp), %rax
   12105:      	je	0x15f2d <generic_fentry_path+0xba6d>
   1210b:      	addq	$0x18, %r15
   1210f:      	movl	$0x4, %eax
   12114:      	leaq	0x30(%rsp), %rdi
   12119:      	movl	$0x8, %esi
   1211e:      	movq	%r15, %rdx
   12121:      	callq	*%rax
   12123:      	movq	(%rsp), %r15
   12127:      	movq	%r15, 0x40(%rsp)
   1212c:      	leaq	0x20(%r15), %rdx
   12130:      	movq	%rdx, 0x38(%rsp)
   12135:      	movq	0x30(%rsp), %r12
   1213a:      	cmpq	0x18(%rsp), %r12
   1213f:      	jne	0x1214c <generic_fentry_path+0x7c8c>
   12141:      	cmpq	0x20(%rsp), %rdx
   12146:      	je	0x15f2d <generic_fentry_path+0xba6d>
   1214c:      	movl	$0x4, %eax
   12151:      	leaq	0x10(%rsp), %rdi
   12156:      	movl	$0x8, %esi
   1215b:      	callq	*%rax
   1215d:      	cmpq	0x10(%rsp), %r12
   12162:      	je	0x1225a <generic_fentry_path+0x7d9a>
   12168:      	leaq	0x18(%r12), %rbx
   1216d:      	movl	$0x4, %eax
   12172:      	movq	%rbp, %rdi
   12175:      	movl	$0x8, %esi
   1217a:      	movq	%rbx, %rdx
   1217d:      	callq	*%rax
   1217f:      	cmpq	%r12, (%rsp)
   12183:      	je	0x1225a <generic_fentry_path+0x7d9a>
   12189:      	movl	$0x4, %eax
   1218e:      	leaq	0x8(%rsp), %rdi
   12193:      	movl	$0x8, %esi
   12198:      	movq	%rbx, %rdx
   1219b:      	callq	*%rax
   1219d:      	addq	$0x20, %r12
   121a1:      	movl	$0x4, %eax
   121a6:      	leaq	0x58(%rsp), %rdi
   121ab:      	movl	$0x10, %ecx
   121b0:      	movl	$0x10, %esi
   121b5:      	movq	%r12, %rdx
   121b8:      	callq	*%rax
   121ba:      	movq	0x28(%rsp), %rbx
   121bf:      	movq	0x48(%rsp), %rax
   121c4:      	movl	0x5c(%rsp), %r15d
   121c9:      	subq	%rbx, %rax
   121cc:      	movl	0x50(%rsp), %r12d
   121d1:      	movl	%r15d, %edx
   121d4:      	subl	%r12d, %edx
   121d7:      	movl	$0x0, %ecx
   121dc:      	cmovbl	%ecx, %edx
   121df:      	addq	0x60(%rsp), %rdx
   121e4:      	xorl	%esi, %esi
   121e6:      	cmpl	%r15d, %r12d
   121e9:      	seta	%sil
   121ed:      	movl	%r15d, %ecx
   121f0:      	cmovbl	%r12d, %ecx
   121f4:      	addl	%ecx, %esi
   121f6:      	movl	%r12d, %edi
   121f9:      	subl	%esi, %edi
   121fb:      	movl	%edi, 0x50(%rsp)
   121ff:      	subq	%rsi, %rax
   12202:      	jb	0x15f32 <generic_fentry_path+0xba72>
   12208:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1220e:      	ja	0x15f32 <generic_fentry_path+0xba72>
   12214:      	cmpl	%r15d, %r12d
   12217:      	jbe	0x1221d <generic_fentry_path+0x7d5d>
   12219:      	movb	$0x2f, (%rbx,%rax)
   1221d:      	xorl	%edi, %edi
   1221f:      	cmpl	%r15d, %r12d
   12222:      	seta	%dil
   12226:      	movzbl	%cl, %esi
   12229:      	addq	%rax, %rbx
   1222c:      	addq	%rbx, %rdi
   1222f:      	movl	$0x4, %eax
   12234:      	callq	*%rax
   12236:      	movq	%rbx, 0x48(%rsp)
   1223b:      	cmpl	%r15d, %r12d
   1223e:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   12244:      	movq	0x8(%rsp), %r12
   12249:      	movq	%r12, 0x30(%rsp)
   1224e:      	movq	0x38(%rsp), %rdx
   12253:      	movq	0x40(%rsp), %r15
   12258:      	jmp	0x122ab <generic_fentry_path+0x7deb>
   1225a:      	leaq	0x10(%r15), %rdx
   1225e:      	movl	$0x4, %eax
   12263:      	movq	%rbp, %rdi
   12266:      	movl	$0x8, %esi
   1226b:      	callq	*%rax
   1226d:      	movq	0x40(%rsp), %rax
   12272:      	cmpq	(%rsp), %rax
   12276:      	je	0x15f2d <generic_fentry_path+0xba6d>
   1227c:      	addq	$0x18, %r15
   12280:      	movl	$0x4, %eax
   12285:      	leaq	0x30(%rsp), %rdi
   1228a:      	movl	$0x8, %esi
   1228f:      	movq	%r15, %rdx
   12292:      	callq	*%rax
   12294:      	movq	(%rsp), %r15
   12298:      	movq	%r15, 0x40(%rsp)
   1229d:      	leaq	0x20(%r15), %rdx
   122a1:      	movq	%rdx, 0x38(%rsp)
   122a6:      	movq	0x30(%rsp), %r12
   122ab:      	cmpq	0x18(%rsp), %r12
   122b0:      	jne	0x122bd <generic_fentry_path+0x7dfd>
   122b2:      	cmpq	0x20(%rsp), %rdx
   122b7:      	je	0x15f2d <generic_fentry_path+0xba6d>
   122bd:      	movl	$0x4, %eax
   122c2:      	leaq	0x10(%rsp), %rdi
   122c7:      	movl	$0x8, %esi
   122cc:      	callq	*%rax
   122ce:      	cmpq	0x10(%rsp), %r12
   122d3:      	je	0x123cb <generic_fentry_path+0x7f0b>
   122d9:      	leaq	0x18(%r12), %rbx
   122de:      	movl	$0x4, %eax
   122e3:      	movq	%rbp, %rdi
   122e6:      	movl	$0x8, %esi
   122eb:      	movq	%rbx, %rdx
   122ee:      	callq	*%rax
   122f0:      	cmpq	%r12, (%rsp)
   122f4:      	je	0x123cb <generic_fentry_path+0x7f0b>
   122fa:      	movl	$0x4, %eax
   122ff:      	leaq	0x8(%rsp), %rdi
   12304:      	movl	$0x8, %esi
   12309:      	movq	%rbx, %rdx
   1230c:      	callq	*%rax
   1230e:      	addq	$0x20, %r12
   12312:      	movl	$0x4, %eax
   12317:      	leaq	0x58(%rsp), %rdi
   1231c:      	movl	$0x10, %ecx
   12321:      	movl	$0x10, %esi
   12326:      	movq	%r12, %rdx
   12329:      	callq	*%rax
   1232b:      	movq	0x28(%rsp), %rbx
   12330:      	movq	0x48(%rsp), %rax
   12335:      	movl	0x5c(%rsp), %r15d
   1233a:      	subq	%rbx, %rax
   1233d:      	movl	0x50(%rsp), %r12d
   12342:      	movl	%r15d, %edx
   12345:      	subl	%r12d, %edx
   12348:      	movl	$0x0, %ecx
   1234d:      	cmovbl	%ecx, %edx
   12350:      	addq	0x60(%rsp), %rdx
   12355:      	xorl	%esi, %esi
   12357:      	cmpl	%r15d, %r12d
   1235a:      	seta	%sil
   1235e:      	movl	%r15d, %ecx
   12361:      	cmovbl	%r12d, %ecx
   12365:      	addl	%ecx, %esi
   12367:      	movl	%r12d, %edi
   1236a:      	subl	%esi, %edi
   1236c:      	movl	%edi, 0x50(%rsp)
   12370:      	subq	%rsi, %rax
   12373:      	jb	0x15f32 <generic_fentry_path+0xba72>
   12379:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1237f:      	ja	0x15f32 <generic_fentry_path+0xba72>
   12385:      	cmpl	%r15d, %r12d
   12388:      	jbe	0x1238e <generic_fentry_path+0x7ece>
   1238a:      	movb	$0x2f, (%rbx,%rax)
   1238e:      	xorl	%edi, %edi
   12390:      	cmpl	%r15d, %r12d
   12393:      	seta	%dil
   12397:      	movzbl	%cl, %esi
   1239a:      	addq	%rax, %rbx
   1239d:      	addq	%rbx, %rdi
   123a0:      	movl	$0x4, %eax
   123a5:      	callq	*%rax
   123a7:      	movq	%rbx, 0x48(%rsp)
   123ac:      	cmpl	%r15d, %r12d
   123af:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   123b5:      	movq	0x8(%rsp), %r12
   123ba:      	movq	%r12, 0x30(%rsp)
   123bf:      	movq	0x38(%rsp), %rdx
   123c4:      	movq	0x40(%rsp), %r15
   123c9:      	jmp	0x1241c <generic_fentry_path+0x7f5c>
   123cb:      	leaq	0x10(%r15), %rdx
   123cf:      	movl	$0x4, %eax
   123d4:      	movq	%rbp, %rdi
   123d7:      	movl	$0x8, %esi
   123dc:      	callq	*%rax
   123de:      	movq	0x40(%rsp), %rax
   123e3:      	cmpq	(%rsp), %rax
   123e7:      	je	0x15f2d <generic_fentry_path+0xba6d>
   123ed:      	addq	$0x18, %r15
   123f1:      	movl	$0x4, %eax
   123f6:      	leaq	0x30(%rsp), %rdi
   123fb:      	movl	$0x8, %esi
   12400:      	movq	%r15, %rdx
   12403:      	callq	*%rax
   12405:      	movq	(%rsp), %r15
   12409:      	movq	%r15, 0x40(%rsp)
   1240e:      	leaq	0x20(%r15), %rdx
   12412:      	movq	%rdx, 0x38(%rsp)
   12417:      	movq	0x30(%rsp), %r12
   1241c:      	cmpq	0x18(%rsp), %r12
   12421:      	jne	0x1242e <generic_fentry_path+0x7f6e>
   12423:      	cmpq	0x20(%rsp), %rdx
   12428:      	je	0x15f2d <generic_fentry_path+0xba6d>
   1242e:      	movl	$0x4, %eax
   12433:      	leaq	0x10(%rsp), %rdi
   12438:      	movl	$0x8, %esi
   1243d:      	callq	*%rax
   1243f:      	cmpq	0x10(%rsp), %r12
   12444:      	je	0x1253c <generic_fentry_path+0x807c>
   1244a:      	leaq	0x18(%r12), %rbx
   1244f:      	movl	$0x4, %eax
   12454:      	movq	%rbp, %rdi
   12457:      	movl	$0x8, %esi
   1245c:      	movq	%rbx, %rdx
   1245f:      	callq	*%rax
   12461:      	cmpq	%r12, (%rsp)
   12465:      	je	0x1253c <generic_fentry_path+0x807c>
   1246b:      	movl	$0x4, %eax
   12470:      	leaq	0x8(%rsp), %rdi
   12475:      	movl	$0x8, %esi
   1247a:      	movq	%rbx, %rdx
   1247d:      	callq	*%rax
   1247f:      	addq	$0x20, %r12
   12483:      	movl	$0x4, %eax
   12488:      	leaq	0x58(%rsp), %rdi
   1248d:      	movl	$0x10, %ecx
   12492:      	movl	$0x10, %esi
   12497:      	movq	%r12, %rdx
   1249a:      	callq	*%rax
   1249c:      	movq	0x28(%rsp), %rbx
   124a1:      	movq	0x48(%rsp), %rax
   124a6:      	movl	0x5c(%rsp), %r15d
   124ab:      	subq	%rbx, %rax
   124ae:      	movl	0x50(%rsp), %r12d
   124b3:      	movl	%r15d, %edx
   124b6:      	subl	%r12d, %edx
   124b9:      	movl	$0x0, %ecx
   124be:      	cmovbl	%ecx, %edx
   124c1:      	addq	0x60(%rsp), %rdx
   124c6:      	xorl	%esi, %esi
   124c8:      	cmpl	%r15d, %r12d
   124cb:      	seta	%sil
   124cf:      	movl	%r15d, %ecx
   124d2:      	cmovbl	%r12d, %ecx
   124d6:      	addl	%ecx, %esi
   124d8:      	movl	%r12d, %edi
   124db:      	subl	%esi, %edi
   124dd:      	movl	%edi, 0x50(%rsp)
   124e1:      	subq	%rsi, %rax
   124e4:      	jb	0x15f32 <generic_fentry_path+0xba72>
   124ea:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   124f0:      	ja	0x15f32 <generic_fentry_path+0xba72>
   124f6:      	cmpl	%r15d, %r12d
   124f9:      	jbe	0x124ff <generic_fentry_path+0x803f>
   124fb:      	movb	$0x2f, (%rbx,%rax)
   124ff:      	xorl	%edi, %edi
   12501:      	cmpl	%r15d, %r12d
   12504:      	seta	%dil
   12508:      	movzbl	%cl, %esi
   1250b:      	addq	%rax, %rbx
   1250e:      	addq	%rbx, %rdi
   12511:      	movl	$0x4, %eax
   12516:      	callq	*%rax
   12518:      	movq	%rbx, 0x48(%rsp)
   1251d:      	cmpl	%r15d, %r12d
   12520:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   12526:      	movq	0x8(%rsp), %r12
   1252b:      	movq	%r12, 0x30(%rsp)
   12530:      	movq	0x38(%rsp), %rdx
   12535:      	movq	0x40(%rsp), %r15
   1253a:      	jmp	0x1258d <generic_fentry_path+0x80cd>
   1253c:      	leaq	0x10(%r15), %rdx
   12540:      	movl	$0x4, %eax
   12545:      	movq	%rbp, %rdi
   12548:      	movl	$0x8, %esi
   1254d:      	callq	*%rax
   1254f:      	movq	0x40(%rsp), %rax
   12554:      	cmpq	(%rsp), %rax
   12558:      	je	0x15f2d <generic_fentry_path+0xba6d>
   1255e:      	addq	$0x18, %r15
   12562:      	movl	$0x4, %eax
   12567:      	leaq	0x30(%rsp), %rdi
   1256c:      	movl	$0x8, %esi
   12571:      	movq	%r15, %rdx
   12574:      	callq	*%rax
   12576:      	movq	(%rsp), %r15
   1257a:      	movq	%r15, 0x40(%rsp)
   1257f:      	leaq	0x20(%r15), %rdx
   12583:      	movq	%rdx, 0x38(%rsp)
   12588:      	movq	0x30(%rsp), %r12
   1258d:      	cmpq	0x18(%rsp), %r12
   12592:      	jne	0x1259f <generic_fentry_path+0x80df>
   12594:      	cmpq	0x20(%rsp), %rdx
   12599:      	je	0x15f2d <generic_fentry_path+0xba6d>
   1259f:      	movl	$0x4, %eax
   125a4:      	leaq	0x10(%rsp), %rdi
   125a9:      	movl	$0x8, %esi
   125ae:      	callq	*%rax
   125b0:      	cmpq	0x10(%rsp), %r12
   125b5:      	je	0x126ad <generic_fentry_path+0x81ed>
   125bb:      	leaq	0x18(%r12), %rbx
   125c0:      	movl	$0x4, %eax
   125c5:      	movq	%rbp, %rdi
   125c8:      	movl	$0x8, %esi
   125cd:      	movq	%rbx, %rdx
   125d0:      	callq	*%rax
   125d2:      	cmpq	%r12, (%rsp)
   125d6:      	je	0x126ad <generic_fentry_path+0x81ed>
   125dc:      	movl	$0x4, %eax
   125e1:      	leaq	0x8(%rsp), %rdi
   125e6:      	movl	$0x8, %esi
   125eb:      	movq	%rbx, %rdx
   125ee:      	callq	*%rax
   125f0:      	addq	$0x20, %r12
   125f4:      	movl	$0x4, %eax
   125f9:      	leaq	0x58(%rsp), %rdi
   125fe:      	movl	$0x10, %ecx
   12603:      	movl	$0x10, %esi
   12608:      	movq	%r12, %rdx
   1260b:      	callq	*%rax
   1260d:      	movq	0x28(%rsp), %rbx
   12612:      	movq	0x48(%rsp), %rax
   12617:      	movl	0x5c(%rsp), %r15d
   1261c:      	subq	%rbx, %rax
   1261f:      	movl	0x50(%rsp), %r12d
   12624:      	movl	%r15d, %edx
   12627:      	subl	%r12d, %edx
   1262a:      	movl	$0x0, %ecx
   1262f:      	cmovbl	%ecx, %edx
   12632:      	addq	0x60(%rsp), %rdx
   12637:      	xorl	%esi, %esi
   12639:      	cmpl	%r15d, %r12d
   1263c:      	seta	%sil
   12640:      	movl	%r15d, %ecx
   12643:      	cmovbl	%r12d, %ecx
   12647:      	addl	%ecx, %esi
   12649:      	movl	%r12d, %edi
   1264c:      	subl	%esi, %edi
   1264e:      	movl	%edi, 0x50(%rsp)
   12652:      	subq	%rsi, %rax
   12655:      	jb	0x15f32 <generic_fentry_path+0xba72>
   1265b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12661:      	ja	0x15f32 <generic_fentry_path+0xba72>
   12667:      	cmpl	%r15d, %r12d
   1266a:      	jbe	0x12670 <generic_fentry_path+0x81b0>
   1266c:      	movb	$0x2f, (%rbx,%rax)
   12670:      	xorl	%edi, %edi
   12672:      	cmpl	%r15d, %r12d
   12675:      	seta	%dil
   12679:      	movzbl	%cl, %esi
   1267c:      	addq	%rax, %rbx
   1267f:      	addq	%rbx, %rdi
   12682:      	movl	$0x4, %eax
   12687:      	callq	*%rax
   12689:      	movq	%rbx, 0x48(%rsp)
   1268e:      	cmpl	%r15d, %r12d
   12691:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   12697:      	movq	0x8(%rsp), %r12
   1269c:      	movq	%r12, 0x30(%rsp)
   126a1:      	movq	0x38(%rsp), %rdx
   126a6:      	movq	0x40(%rsp), %r15
   126ab:      	jmp	0x126fe <generic_fentry_path+0x823e>
   126ad:      	leaq	0x10(%r15), %rdx
   126b1:      	movl	$0x4, %eax
   126b6:      	movq	%rbp, %rdi
   126b9:      	movl	$0x8, %esi
   126be:      	callq	*%rax
   126c0:      	movq	0x40(%rsp), %rax
   126c5:      	cmpq	(%rsp), %rax
   126c9:      	je	0x15f2d <generic_fentry_path+0xba6d>
   126cf:      	addq	$0x18, %r15
   126d3:      	movl	$0x4, %eax
   126d8:      	leaq	0x30(%rsp), %rdi
   126dd:      	movl	$0x8, %esi
   126e2:      	movq	%r15, %rdx
   126e5:      	callq	*%rax
   126e7:      	movq	(%rsp), %r15
   126eb:      	movq	%r15, 0x40(%rsp)
   126f0:      	leaq	0x20(%r15), %rdx
   126f4:      	movq	%rdx, 0x38(%rsp)
   126f9:      	movq	0x30(%rsp), %r12
   126fe:      	cmpq	0x18(%rsp), %r12
   12703:      	jne	0x12710 <generic_fentry_path+0x8250>
   12705:      	cmpq	0x20(%rsp), %rdx
   1270a:      	je	0x15f2d <generic_fentry_path+0xba6d>
   12710:      	movl	$0x4, %eax
   12715:      	leaq	0x10(%rsp), %rdi
   1271a:      	movl	$0x8, %esi
   1271f:      	callq	*%rax
   12721:      	cmpq	0x10(%rsp), %r12
   12726:      	je	0x1281e <generic_fentry_path+0x835e>
   1272c:      	leaq	0x18(%r12), %rbx
   12731:      	movl	$0x4, %eax
   12736:      	movq	%rbp, %rdi
   12739:      	movl	$0x8, %esi
   1273e:      	movq	%rbx, %rdx
   12741:      	callq	*%rax
   12743:      	cmpq	%r12, (%rsp)
   12747:      	je	0x1281e <generic_fentry_path+0x835e>
   1274d:      	movl	$0x4, %eax
   12752:      	leaq	0x8(%rsp), %rdi
   12757:      	movl	$0x8, %esi
   1275c:      	movq	%rbx, %rdx
   1275f:      	callq	*%rax
   12761:      	addq	$0x20, %r12
   12765:      	movl	$0x4, %eax
   1276a:      	leaq	0x58(%rsp), %rdi
   1276f:      	movl	$0x10, %ecx
   12774:      	movl	$0x10, %esi
   12779:      	movq	%r12, %rdx
   1277c:      	callq	*%rax
   1277e:      	movq	0x28(%rsp), %rbx
   12783:      	movq	0x48(%rsp), %rax
   12788:      	movl	0x5c(%rsp), %r15d
   1278d:      	subq	%rbx, %rax
   12790:      	movl	0x50(%rsp), %r12d
   12795:      	movl	%r15d, %edx
   12798:      	subl	%r12d, %edx
   1279b:      	movl	$0x0, %ecx
   127a0:      	cmovbl	%ecx, %edx
   127a3:      	addq	0x60(%rsp), %rdx
   127a8:      	xorl	%esi, %esi
   127aa:      	cmpl	%r15d, %r12d
   127ad:      	seta	%sil
   127b1:      	movl	%r15d, %ecx
   127b4:      	cmovbl	%r12d, %ecx
   127b8:      	addl	%ecx, %esi
   127ba:      	movl	%r12d, %edi
   127bd:      	subl	%esi, %edi
   127bf:      	movl	%edi, 0x50(%rsp)
   127c3:      	subq	%rsi, %rax
   127c6:      	jb	0x15f32 <generic_fentry_path+0xba72>
   127cc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   127d2:      	ja	0x15f32 <generic_fentry_path+0xba72>
   127d8:      	cmpl	%r15d, %r12d
   127db:      	jbe	0x127e1 <generic_fentry_path+0x8321>
   127dd:      	movb	$0x2f, (%rbx,%rax)
   127e1:      	xorl	%edi, %edi
   127e3:      	cmpl	%r15d, %r12d
   127e6:      	seta	%dil
   127ea:      	movzbl	%cl, %esi
   127ed:      	addq	%rax, %rbx
   127f0:      	addq	%rbx, %rdi
   127f3:      	movl	$0x4, %eax
   127f8:      	callq	*%rax
   127fa:      	movq	%rbx, 0x48(%rsp)
   127ff:      	cmpl	%r15d, %r12d
   12802:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   12808:      	movq	0x8(%rsp), %r12
   1280d:      	movq	%r12, 0x30(%rsp)
   12812:      	movq	0x38(%rsp), %rdx
   12817:      	movq	0x40(%rsp), %r15
   1281c:      	jmp	0x1286f <generic_fentry_path+0x83af>
   1281e:      	leaq	0x10(%r15), %rdx
   12822:      	movl	$0x4, %eax
   12827:      	movq	%rbp, %rdi
   1282a:      	movl	$0x8, %esi
   1282f:      	callq	*%rax
   12831:      	movq	0x40(%rsp), %rax
   12836:      	cmpq	(%rsp), %rax
   1283a:      	je	0x15f2d <generic_fentry_path+0xba6d>
   12840:      	addq	$0x18, %r15
   12844:      	movl	$0x4, %eax
   12849:      	leaq	0x30(%rsp), %rdi
   1284e:      	movl	$0x8, %esi
   12853:      	movq	%r15, %rdx
   12856:      	callq	*%rax
   12858:      	movq	(%rsp), %r15
   1285c:      	movq	%r15, 0x40(%rsp)
   12861:      	leaq	0x20(%r15), %rdx
   12865:      	movq	%rdx, 0x38(%rsp)
   1286a:      	movq	0x30(%rsp), %r12
   1286f:      	cmpq	0x18(%rsp), %r12
   12874:      	jne	0x12881 <generic_fentry_path+0x83c1>
   12876:      	cmpq	0x20(%rsp), %rdx
   1287b:      	je	0x15f2d <generic_fentry_path+0xba6d>
   12881:      	movl	$0x4, %eax
   12886:      	leaq	0x10(%rsp), %rdi
   1288b:      	movl	$0x8, %esi
   12890:      	callq	*%rax
   12892:      	cmpq	0x10(%rsp), %r12
   12897:      	je	0x1298f <generic_fentry_path+0x84cf>
   1289d:      	leaq	0x18(%r12), %rbx
   128a2:      	movl	$0x4, %eax
   128a7:      	movq	%rbp, %rdi
   128aa:      	movl	$0x8, %esi
   128af:      	movq	%rbx, %rdx
   128b2:      	callq	*%rax
   128b4:      	cmpq	%r12, (%rsp)
   128b8:      	je	0x1298f <generic_fentry_path+0x84cf>
   128be:      	movl	$0x4, %eax
   128c3:      	leaq	0x8(%rsp), %rdi
   128c8:      	movl	$0x8, %esi
   128cd:      	movq	%rbx, %rdx
   128d0:      	callq	*%rax
   128d2:      	addq	$0x20, %r12
   128d6:      	movl	$0x4, %eax
   128db:      	leaq	0x58(%rsp), %rdi
   128e0:      	movl	$0x10, %ecx
   128e5:      	movl	$0x10, %esi
   128ea:      	movq	%r12, %rdx
   128ed:      	callq	*%rax
   128ef:      	movq	0x28(%rsp), %rbx
   128f4:      	movq	0x48(%rsp), %rax
   128f9:      	movl	0x5c(%rsp), %r15d
   128fe:      	subq	%rbx, %rax
   12901:      	movl	0x50(%rsp), %r12d
   12906:      	movl	%r15d, %edx
   12909:      	subl	%r12d, %edx
   1290c:      	movl	$0x0, %ecx
   12911:      	cmovbl	%ecx, %edx
   12914:      	addq	0x60(%rsp), %rdx
   12919:      	xorl	%esi, %esi
   1291b:      	cmpl	%r15d, %r12d
   1291e:      	seta	%sil
   12922:      	movl	%r15d, %ecx
   12925:      	cmovbl	%r12d, %ecx
   12929:      	addl	%ecx, %esi
   1292b:      	movl	%r12d, %edi
   1292e:      	subl	%esi, %edi
   12930:      	movl	%edi, 0x50(%rsp)
   12934:      	subq	%rsi, %rax
   12937:      	jb	0x15f32 <generic_fentry_path+0xba72>
   1293d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12943:      	ja	0x15f32 <generic_fentry_path+0xba72>
   12949:      	cmpl	%r15d, %r12d
   1294c:      	jbe	0x12952 <generic_fentry_path+0x8492>
   1294e:      	movb	$0x2f, (%rbx,%rax)
   12952:      	xorl	%edi, %edi
   12954:      	cmpl	%r15d, %r12d
   12957:      	seta	%dil
   1295b:      	movzbl	%cl, %esi
   1295e:      	addq	%rax, %rbx
   12961:      	addq	%rbx, %rdi
   12964:      	movl	$0x4, %eax
   12969:      	callq	*%rax
   1296b:      	movq	%rbx, 0x48(%rsp)
   12970:      	cmpl	%r15d, %r12d
   12973:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   12979:      	movq	0x8(%rsp), %r12
   1297e:      	movq	%r12, 0x30(%rsp)
   12983:      	movq	0x38(%rsp), %rdx
   12988:      	movq	0x40(%rsp), %r15
   1298d:      	jmp	0x129e0 <generic_fentry_path+0x8520>
   1298f:      	leaq	0x10(%r15), %rdx
   12993:      	movl	$0x4, %eax
   12998:      	movq	%rbp, %rdi
   1299b:      	movl	$0x8, %esi
   129a0:      	callq	*%rax
   129a2:      	movq	0x40(%rsp), %rax
   129a7:      	cmpq	(%rsp), %rax
   129ab:      	je	0x15f2d <generic_fentry_path+0xba6d>
   129b1:      	addq	$0x18, %r15
   129b5:      	movl	$0x4, %eax
   129ba:      	leaq	0x30(%rsp), %rdi
   129bf:      	movl	$0x8, %esi
   129c4:      	movq	%r15, %rdx
   129c7:      	callq	*%rax
   129c9:      	movq	(%rsp), %r15
   129cd:      	movq	%r15, 0x40(%rsp)
   129d2:      	leaq	0x20(%r15), %rdx
   129d6:      	movq	%rdx, 0x38(%rsp)
   129db:      	movq	0x30(%rsp), %r12
   129e0:      	cmpq	0x18(%rsp), %r12
   129e5:      	jne	0x129f2 <generic_fentry_path+0x8532>
   129e7:      	cmpq	0x20(%rsp), %rdx
   129ec:      	je	0x15f2d <generic_fentry_path+0xba6d>
   129f2:      	movl	$0x4, %eax
   129f7:      	leaq	0x10(%rsp), %rdi
   129fc:      	movl	$0x8, %esi
   12a01:      	callq	*%rax
   12a03:      	cmpq	0x10(%rsp), %r12
   12a08:      	je	0x12b00 <generic_fentry_path+0x8640>
   12a0e:      	leaq	0x18(%r12), %rbx
   12a13:      	movl	$0x4, %eax
   12a18:      	movq	%rbp, %rdi
   12a1b:      	movl	$0x8, %esi
   12a20:      	movq	%rbx, %rdx
   12a23:      	callq	*%rax
   12a25:      	cmpq	%r12, (%rsp)
   12a29:      	je	0x12b00 <generic_fentry_path+0x8640>
   12a2f:      	movl	$0x4, %eax
   12a34:      	leaq	0x8(%rsp), %rdi
   12a39:      	movl	$0x8, %esi
   12a3e:      	movq	%rbx, %rdx
   12a41:      	callq	*%rax
   12a43:      	addq	$0x20, %r12
   12a47:      	movl	$0x4, %eax
   12a4c:      	leaq	0x58(%rsp), %rdi
   12a51:      	movl	$0x10, %ecx
   12a56:      	movl	$0x10, %esi
   12a5b:      	movq	%r12, %rdx
   12a5e:      	callq	*%rax
   12a60:      	movq	0x28(%rsp), %rbx
   12a65:      	movq	0x48(%rsp), %rax
   12a6a:      	movl	0x5c(%rsp), %r15d
   12a6f:      	subq	%rbx, %rax
   12a72:      	movl	0x50(%rsp), %r12d
   12a77:      	movl	%r15d, %edx
   12a7a:      	subl	%r12d, %edx
   12a7d:      	movl	$0x0, %ecx
   12a82:      	cmovbl	%ecx, %edx
   12a85:      	addq	0x60(%rsp), %rdx
   12a8a:      	xorl	%esi, %esi
   12a8c:      	cmpl	%r15d, %r12d
   12a8f:      	seta	%sil
   12a93:      	movl	%r15d, %ecx
   12a96:      	cmovbl	%r12d, %ecx
   12a9a:      	addl	%ecx, %esi
   12a9c:      	movl	%r12d, %edi
   12a9f:      	subl	%esi, %edi
   12aa1:      	movl	%edi, 0x50(%rsp)
   12aa5:      	subq	%rsi, %rax
   12aa8:      	jb	0x15f32 <generic_fentry_path+0xba72>
   12aae:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12ab4:      	ja	0x15f32 <generic_fentry_path+0xba72>
   12aba:      	cmpl	%r15d, %r12d
   12abd:      	jbe	0x12ac3 <generic_fentry_path+0x8603>
   12abf:      	movb	$0x2f, (%rbx,%rax)
   12ac3:      	xorl	%edi, %edi
   12ac5:      	cmpl	%r15d, %r12d
   12ac8:      	seta	%dil
   12acc:      	movzbl	%cl, %esi
   12acf:      	addq	%rax, %rbx
   12ad2:      	addq	%rbx, %rdi
   12ad5:      	movl	$0x4, %eax
   12ada:      	callq	*%rax
   12adc:      	movq	%rbx, 0x48(%rsp)
   12ae1:      	cmpl	%r15d, %r12d
   12ae4:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   12aea:      	movq	0x8(%rsp), %r12
   12aef:      	movq	%r12, 0x30(%rsp)
   12af4:      	movq	0x38(%rsp), %rdx
   12af9:      	movq	0x40(%rsp), %r15
   12afe:      	jmp	0x12b51 <generic_fentry_path+0x8691>
   12b00:      	leaq	0x10(%r15), %rdx
   12b04:      	movl	$0x4, %eax
   12b09:      	movq	%rbp, %rdi
   12b0c:      	movl	$0x8, %esi
   12b11:      	callq	*%rax
   12b13:      	movq	0x40(%rsp), %rax
   12b18:      	cmpq	(%rsp), %rax
   12b1c:      	je	0x15f2d <generic_fentry_path+0xba6d>
   12b22:      	addq	$0x18, %r15
   12b26:      	movl	$0x4, %eax
   12b2b:      	leaq	0x30(%rsp), %rdi
   12b30:      	movl	$0x8, %esi
   12b35:      	movq	%r15, %rdx
   12b38:      	callq	*%rax
   12b3a:      	movq	(%rsp), %r15
   12b3e:      	movq	%r15, 0x40(%rsp)
   12b43:      	leaq	0x20(%r15), %rdx
   12b47:      	movq	%rdx, 0x38(%rsp)
   12b4c:      	movq	0x30(%rsp), %r12
   12b51:      	cmpq	0x18(%rsp), %r12
   12b56:      	jne	0x12b63 <generic_fentry_path+0x86a3>
   12b58:      	cmpq	0x20(%rsp), %rdx
   12b5d:      	je	0x15f2d <generic_fentry_path+0xba6d>
   12b63:      	movl	$0x4, %eax
   12b68:      	leaq	0x10(%rsp), %rdi
   12b6d:      	movl	$0x8, %esi
   12b72:      	callq	*%rax
   12b74:      	cmpq	0x10(%rsp), %r12
   12b79:      	je	0x12c71 <generic_fentry_path+0x87b1>
   12b7f:      	leaq	0x18(%r12), %rbx
   12b84:      	movl	$0x4, %eax
   12b89:      	movq	%rbp, %rdi
   12b8c:      	movl	$0x8, %esi
   12b91:      	movq	%rbx, %rdx
   12b94:      	callq	*%rax
   12b96:      	cmpq	%r12, (%rsp)
   12b9a:      	je	0x12c71 <generic_fentry_path+0x87b1>
   12ba0:      	movl	$0x4, %eax
   12ba5:      	leaq	0x8(%rsp), %rdi
   12baa:      	movl	$0x8, %esi
   12baf:      	movq	%rbx, %rdx
   12bb2:      	callq	*%rax
   12bb4:      	addq	$0x20, %r12
   12bb8:      	movl	$0x4, %eax
   12bbd:      	leaq	0x58(%rsp), %rdi
   12bc2:      	movl	$0x10, %ecx
   12bc7:      	movl	$0x10, %esi
   12bcc:      	movq	%r12, %rdx
   12bcf:      	callq	*%rax
   12bd1:      	movq	0x28(%rsp), %rbx
   12bd6:      	movq	0x48(%rsp), %rax
   12bdb:      	movl	0x5c(%rsp), %r15d
   12be0:      	subq	%rbx, %rax
   12be3:      	movl	0x50(%rsp), %r12d
   12be8:      	movl	%r15d, %edx
   12beb:      	subl	%r12d, %edx
   12bee:      	movl	$0x0, %ecx
   12bf3:      	cmovbl	%ecx, %edx
   12bf6:      	addq	0x60(%rsp), %rdx
   12bfb:      	xorl	%esi, %esi
   12bfd:      	cmpl	%r15d, %r12d
   12c00:      	seta	%sil
   12c04:      	movl	%r15d, %ecx
   12c07:      	cmovbl	%r12d, %ecx
   12c0b:      	addl	%ecx, %esi
   12c0d:      	movl	%r12d, %edi
   12c10:      	subl	%esi, %edi
   12c12:      	movl	%edi, 0x50(%rsp)
   12c16:      	subq	%rsi, %rax
   12c19:      	jb	0x15f32 <generic_fentry_path+0xba72>
   12c1f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12c25:      	ja	0x15f32 <generic_fentry_path+0xba72>
   12c2b:      	cmpl	%r15d, %r12d
   12c2e:      	jbe	0x12c34 <generic_fentry_path+0x8774>
   12c30:      	movb	$0x2f, (%rbx,%rax)
   12c34:      	xorl	%edi, %edi
   12c36:      	cmpl	%r15d, %r12d
   12c39:      	seta	%dil
   12c3d:      	movzbl	%cl, %esi
   12c40:      	addq	%rax, %rbx
   12c43:      	addq	%rbx, %rdi
   12c46:      	movl	$0x4, %eax
   12c4b:      	callq	*%rax
   12c4d:      	movq	%rbx, 0x48(%rsp)
   12c52:      	cmpl	%r15d, %r12d
   12c55:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   12c5b:      	movq	0x8(%rsp), %r12
   12c60:      	movq	%r12, 0x30(%rsp)
   12c65:      	movq	0x38(%rsp), %rdx
   12c6a:      	movq	0x40(%rsp), %r15
   12c6f:      	jmp	0x12cc2 <generic_fentry_path+0x8802>
   12c71:      	leaq	0x10(%r15), %rdx
   12c75:      	movl	$0x4, %eax
   12c7a:      	movq	%rbp, %rdi
   12c7d:      	movl	$0x8, %esi
   12c82:      	callq	*%rax
   12c84:      	movq	0x40(%rsp), %rax
   12c89:      	cmpq	(%rsp), %rax
   12c8d:      	je	0x15f2d <generic_fentry_path+0xba6d>
   12c93:      	addq	$0x18, %r15
   12c97:      	movl	$0x4, %eax
   12c9c:      	leaq	0x30(%rsp), %rdi
   12ca1:      	movl	$0x8, %esi
   12ca6:      	movq	%r15, %rdx
   12ca9:      	callq	*%rax
   12cab:      	movq	(%rsp), %r15
   12caf:      	movq	%r15, 0x40(%rsp)
   12cb4:      	leaq	0x20(%r15), %rdx
   12cb8:      	movq	%rdx, 0x38(%rsp)
   12cbd:      	movq	0x30(%rsp), %r12
   12cc2:      	cmpq	0x18(%rsp), %r12
   12cc7:      	jne	0x12cd4 <generic_fentry_path+0x8814>
   12cc9:      	cmpq	0x20(%rsp), %rdx
   12cce:      	je	0x15f2d <generic_fentry_path+0xba6d>
   12cd4:      	movl	$0x4, %eax
   12cd9:      	leaq	0x10(%rsp), %rdi
   12cde:      	movl	$0x8, %esi
   12ce3:      	callq	*%rax
   12ce5:      	cmpq	0x10(%rsp), %r12
   12cea:      	je	0x12de2 <generic_fentry_path+0x8922>
   12cf0:      	leaq	0x18(%r12), %rbx
   12cf5:      	movl	$0x4, %eax
   12cfa:      	movq	%rbp, %rdi
   12cfd:      	movl	$0x8, %esi
   12d02:      	movq	%rbx, %rdx
   12d05:      	callq	*%rax
   12d07:      	cmpq	%r12, (%rsp)
   12d0b:      	je	0x12de2 <generic_fentry_path+0x8922>
   12d11:      	movl	$0x4, %eax
   12d16:      	leaq	0x8(%rsp), %rdi
   12d1b:      	movl	$0x8, %esi
   12d20:      	movq	%rbx, %rdx
   12d23:      	callq	*%rax
   12d25:      	addq	$0x20, %r12
   12d29:      	movl	$0x4, %eax
   12d2e:      	leaq	0x58(%rsp), %rdi
   12d33:      	movl	$0x10, %ecx
   12d38:      	movl	$0x10, %esi
   12d3d:      	movq	%r12, %rdx
   12d40:      	callq	*%rax
   12d42:      	movq	0x28(%rsp), %rbx
   12d47:      	movq	0x48(%rsp), %rax
   12d4c:      	movl	0x5c(%rsp), %r15d
   12d51:      	subq	%rbx, %rax
   12d54:      	movl	0x50(%rsp), %r12d
   12d59:      	movl	%r15d, %edx
   12d5c:      	subl	%r12d, %edx
   12d5f:      	movl	$0x0, %ecx
   12d64:      	cmovbl	%ecx, %edx
   12d67:      	addq	0x60(%rsp), %rdx
   12d6c:      	xorl	%esi, %esi
   12d6e:      	cmpl	%r15d, %r12d
   12d71:      	seta	%sil
   12d75:      	movl	%r15d, %ecx
   12d78:      	cmovbl	%r12d, %ecx
   12d7c:      	addl	%ecx, %esi
   12d7e:      	movl	%r12d, %edi
   12d81:      	subl	%esi, %edi
   12d83:      	movl	%edi, 0x50(%rsp)
   12d87:      	subq	%rsi, %rax
   12d8a:      	jb	0x15f32 <generic_fentry_path+0xba72>
   12d90:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12d96:      	ja	0x15f32 <generic_fentry_path+0xba72>
   12d9c:      	cmpl	%r15d, %r12d
   12d9f:      	jbe	0x12da5 <generic_fentry_path+0x88e5>
   12da1:      	movb	$0x2f, (%rbx,%rax)
   12da5:      	xorl	%edi, %edi
   12da7:      	cmpl	%r15d, %r12d
   12daa:      	seta	%dil
   12dae:      	movzbl	%cl, %esi
   12db1:      	addq	%rax, %rbx
   12db4:      	addq	%rbx, %rdi
   12db7:      	movl	$0x4, %eax
   12dbc:      	callq	*%rax
   12dbe:      	movq	%rbx, 0x48(%rsp)
   12dc3:      	cmpl	%r15d, %r12d
   12dc6:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   12dcc:      	movq	0x8(%rsp), %r12
   12dd1:      	movq	%r12, 0x30(%rsp)
   12dd6:      	movq	0x38(%rsp), %rdx
   12ddb:      	movq	0x40(%rsp), %r15
   12de0:      	jmp	0x12e33 <generic_fentry_path+0x8973>
   12de2:      	leaq	0x10(%r15), %rdx
   12de6:      	movl	$0x4, %eax
   12deb:      	movq	%rbp, %rdi
   12dee:      	movl	$0x8, %esi
   12df3:      	callq	*%rax
   12df5:      	movq	0x40(%rsp), %rax
   12dfa:      	cmpq	(%rsp), %rax
   12dfe:      	je	0x15f2d <generic_fentry_path+0xba6d>
   12e04:      	addq	$0x18, %r15
   12e08:      	movl	$0x4, %eax
   12e0d:      	leaq	0x30(%rsp), %rdi
   12e12:      	movl	$0x8, %esi
   12e17:      	movq	%r15, %rdx
   12e1a:      	callq	*%rax
   12e1c:      	movq	(%rsp), %r15
   12e20:      	movq	%r15, 0x40(%rsp)
   12e25:      	leaq	0x20(%r15), %rdx
   12e29:      	movq	%rdx, 0x38(%rsp)
   12e2e:      	movq	0x30(%rsp), %r12
   12e33:      	cmpq	0x18(%rsp), %r12
   12e38:      	jne	0x12e45 <generic_fentry_path+0x8985>
   12e3a:      	cmpq	0x20(%rsp), %rdx
   12e3f:      	je	0x15f2d <generic_fentry_path+0xba6d>
   12e45:      	movl	$0x4, %eax
   12e4a:      	leaq	0x10(%rsp), %rdi
   12e4f:      	movl	$0x8, %esi
   12e54:      	callq	*%rax
   12e56:      	cmpq	0x10(%rsp), %r12
   12e5b:      	je	0x12f53 <generic_fentry_path+0x8a93>
   12e61:      	leaq	0x18(%r12), %rbx
   12e66:      	movl	$0x4, %eax
   12e6b:      	movq	%rbp, %rdi
   12e6e:      	movl	$0x8, %esi
   12e73:      	movq	%rbx, %rdx
   12e76:      	callq	*%rax
   12e78:      	cmpq	%r12, (%rsp)
   12e7c:      	je	0x12f53 <generic_fentry_path+0x8a93>
   12e82:      	movl	$0x4, %eax
   12e87:      	leaq	0x8(%rsp), %rdi
   12e8c:      	movl	$0x8, %esi
   12e91:      	movq	%rbx, %rdx
   12e94:      	callq	*%rax
   12e96:      	addq	$0x20, %r12
   12e9a:      	movl	$0x4, %eax
   12e9f:      	leaq	0x58(%rsp), %rdi
   12ea4:      	movl	$0x10, %ecx
   12ea9:      	movl	$0x10, %esi
   12eae:      	movq	%r12, %rdx
   12eb1:      	callq	*%rax
   12eb3:      	movq	0x28(%rsp), %rbx
   12eb8:      	movq	0x48(%rsp), %rax
   12ebd:      	movl	0x5c(%rsp), %r15d
   12ec2:      	subq	%rbx, %rax
   12ec5:      	movl	0x50(%rsp), %r12d
   12eca:      	movl	%r15d, %edx
   12ecd:      	subl	%r12d, %edx
   12ed0:      	movl	$0x0, %ecx
   12ed5:      	cmovbl	%ecx, %edx
   12ed8:      	addq	0x60(%rsp), %rdx
   12edd:      	xorl	%esi, %esi
   12edf:      	cmpl	%r15d, %r12d
   12ee2:      	seta	%sil
   12ee6:      	movl	%r15d, %ecx
   12ee9:      	cmovbl	%r12d, %ecx
   12eed:      	addl	%ecx, %esi
   12eef:      	movl	%r12d, %edi
   12ef2:      	subl	%esi, %edi
   12ef4:      	movl	%edi, 0x50(%rsp)
   12ef8:      	subq	%rsi, %rax
   12efb:      	jb	0x15f32 <generic_fentry_path+0xba72>
   12f01:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12f07:      	ja	0x15f32 <generic_fentry_path+0xba72>
   12f0d:      	cmpl	%r15d, %r12d
   12f10:      	jbe	0x12f16 <generic_fentry_path+0x8a56>
   12f12:      	movb	$0x2f, (%rbx,%rax)
   12f16:      	xorl	%edi, %edi
   12f18:      	cmpl	%r15d, %r12d
   12f1b:      	seta	%dil
   12f1f:      	movzbl	%cl, %esi
   12f22:      	addq	%rax, %rbx
   12f25:      	addq	%rbx, %rdi
   12f28:      	movl	$0x4, %eax
   12f2d:      	callq	*%rax
   12f2f:      	movq	%rbx, 0x48(%rsp)
   12f34:      	cmpl	%r15d, %r12d
   12f37:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   12f3d:      	movq	0x8(%rsp), %r12
   12f42:      	movq	%r12, 0x30(%rsp)
   12f47:      	movq	0x38(%rsp), %rdx
   12f4c:      	movq	0x40(%rsp), %r15
   12f51:      	jmp	0x12fa4 <generic_fentry_path+0x8ae4>
   12f53:      	leaq	0x10(%r15), %rdx
   12f57:      	movl	$0x4, %eax
   12f5c:      	movq	%rbp, %rdi
   12f5f:      	movl	$0x8, %esi
   12f64:      	callq	*%rax
   12f66:      	movq	0x40(%rsp), %rax
   12f6b:      	cmpq	(%rsp), %rax
   12f6f:      	je	0x15f2d <generic_fentry_path+0xba6d>
   12f75:      	addq	$0x18, %r15
   12f79:      	movl	$0x4, %eax
   12f7e:      	leaq	0x30(%rsp), %rdi
   12f83:      	movl	$0x8, %esi
   12f88:      	movq	%r15, %rdx
   12f8b:      	callq	*%rax
   12f8d:      	movq	(%rsp), %r15
   12f91:      	movq	%r15, 0x40(%rsp)
   12f96:      	leaq	0x20(%r15), %rdx
   12f9a:      	movq	%rdx, 0x38(%rsp)
   12f9f:      	movq	0x30(%rsp), %r12
   12fa4:      	cmpq	0x18(%rsp), %r12
   12fa9:      	jne	0x12fb6 <generic_fentry_path+0x8af6>
   12fab:      	cmpq	0x20(%rsp), %rdx
   12fb0:      	je	0x15f2d <generic_fentry_path+0xba6d>
   12fb6:      	movl	$0x4, %eax
   12fbb:      	leaq	0x10(%rsp), %rdi
   12fc0:      	movl	$0x8, %esi
   12fc5:      	callq	*%rax
   12fc7:      	cmpq	0x10(%rsp), %r12
   12fcc:      	je	0x130c4 <generic_fentry_path+0x8c04>
   12fd2:      	leaq	0x18(%r12), %rbx
   12fd7:      	movl	$0x4, %eax
   12fdc:      	movq	%rbp, %rdi
   12fdf:      	movl	$0x8, %esi
   12fe4:      	movq	%rbx, %rdx
   12fe7:      	callq	*%rax
   12fe9:      	cmpq	%r12, (%rsp)
   12fed:      	je	0x130c4 <generic_fentry_path+0x8c04>
   12ff3:      	movl	$0x4, %eax
   12ff8:      	leaq	0x8(%rsp), %rdi
   12ffd:      	movl	$0x8, %esi
   13002:      	movq	%rbx, %rdx
   13005:      	callq	*%rax
   13007:      	addq	$0x20, %r12
   1300b:      	movl	$0x4, %eax
   13010:      	leaq	0x58(%rsp), %rdi
   13015:      	movl	$0x10, %ecx
   1301a:      	movl	$0x10, %esi
   1301f:      	movq	%r12, %rdx
   13022:      	callq	*%rax
   13024:      	movq	0x28(%rsp), %rbx
   13029:      	movq	0x48(%rsp), %rax
   1302e:      	movl	0x5c(%rsp), %r15d
   13033:      	subq	%rbx, %rax
   13036:      	movl	0x50(%rsp), %r12d
   1303b:      	movl	%r15d, %edx
   1303e:      	subl	%r12d, %edx
   13041:      	movl	$0x0, %ecx
   13046:      	cmovbl	%ecx, %edx
   13049:      	addq	0x60(%rsp), %rdx
   1304e:      	xorl	%esi, %esi
   13050:      	cmpl	%r15d, %r12d
   13053:      	seta	%sil
   13057:      	movl	%r15d, %ecx
   1305a:      	cmovbl	%r12d, %ecx
   1305e:      	addl	%ecx, %esi
   13060:      	movl	%r12d, %edi
   13063:      	subl	%esi, %edi
   13065:      	movl	%edi, 0x50(%rsp)
   13069:      	subq	%rsi, %rax
   1306c:      	jb	0x15f32 <generic_fentry_path+0xba72>
   13072:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13078:      	ja	0x15f32 <generic_fentry_path+0xba72>
   1307e:      	cmpl	%r15d, %r12d
   13081:      	jbe	0x13087 <generic_fentry_path+0x8bc7>
   13083:      	movb	$0x2f, (%rbx,%rax)
   13087:      	xorl	%edi, %edi
   13089:      	cmpl	%r15d, %r12d
   1308c:      	seta	%dil
   13090:      	movzbl	%cl, %esi
   13093:      	addq	%rax, %rbx
   13096:      	addq	%rbx, %rdi
   13099:      	movl	$0x4, %eax
   1309e:      	callq	*%rax
   130a0:      	movq	%rbx, 0x48(%rsp)
   130a5:      	cmpl	%r15d, %r12d
   130a8:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   130ae:      	movq	0x8(%rsp), %r12
   130b3:      	movq	%r12, 0x30(%rsp)
   130b8:      	movq	0x38(%rsp), %rdx
   130bd:      	movq	0x40(%rsp), %r15
   130c2:      	jmp	0x13115 <generic_fentry_path+0x8c55>
   130c4:      	leaq	0x10(%r15), %rdx
   130c8:      	movl	$0x4, %eax
   130cd:      	movq	%rbp, %rdi
   130d0:      	movl	$0x8, %esi
   130d5:      	callq	*%rax
   130d7:      	movq	0x40(%rsp), %rax
   130dc:      	cmpq	(%rsp), %rax
   130e0:      	je	0x15f2d <generic_fentry_path+0xba6d>
   130e6:      	addq	$0x18, %r15
   130ea:      	movl	$0x4, %eax
   130ef:      	leaq	0x30(%rsp), %rdi
   130f4:      	movl	$0x8, %esi
   130f9:      	movq	%r15, %rdx
   130fc:      	callq	*%rax
   130fe:      	movq	(%rsp), %r15
   13102:      	movq	%r15, 0x40(%rsp)
   13107:      	leaq	0x20(%r15), %rdx
   1310b:      	movq	%rdx, 0x38(%rsp)
   13110:      	movq	0x30(%rsp), %r12
   13115:      	cmpq	0x18(%rsp), %r12
   1311a:      	jne	0x13127 <generic_fentry_path+0x8c67>
   1311c:      	cmpq	0x20(%rsp), %rdx
   13121:      	je	0x15f2d <generic_fentry_path+0xba6d>
   13127:      	movl	$0x4, %eax
   1312c:      	leaq	0x10(%rsp), %rdi
   13131:      	movl	$0x8, %esi
   13136:      	callq	*%rax
   13138:      	cmpq	0x10(%rsp), %r12
   1313d:      	je	0x13235 <generic_fentry_path+0x8d75>
   13143:      	leaq	0x18(%r12), %rbx
   13148:      	movl	$0x4, %eax
   1314d:      	movq	%rbp, %rdi
   13150:      	movl	$0x8, %esi
   13155:      	movq	%rbx, %rdx
   13158:      	callq	*%rax
   1315a:      	cmpq	%r12, (%rsp)
   1315e:      	je	0x13235 <generic_fentry_path+0x8d75>
   13164:      	movl	$0x4, %eax
   13169:      	leaq	0x8(%rsp), %rdi
   1316e:      	movl	$0x8, %esi
   13173:      	movq	%rbx, %rdx
   13176:      	callq	*%rax
   13178:      	addq	$0x20, %r12
   1317c:      	movl	$0x4, %eax
   13181:      	leaq	0x58(%rsp), %rdi
   13186:      	movl	$0x10, %ecx
   1318b:      	movl	$0x10, %esi
   13190:      	movq	%r12, %rdx
   13193:      	callq	*%rax
   13195:      	movq	0x28(%rsp), %rbx
   1319a:      	movq	0x48(%rsp), %rax
   1319f:      	movl	0x5c(%rsp), %r15d
   131a4:      	subq	%rbx, %rax
   131a7:      	movl	0x50(%rsp), %r12d
   131ac:      	movl	%r15d, %edx
   131af:      	subl	%r12d, %edx
   131b2:      	movl	$0x0, %ecx
   131b7:      	cmovbl	%ecx, %edx
   131ba:      	addq	0x60(%rsp), %rdx
   131bf:      	xorl	%esi, %esi
   131c1:      	cmpl	%r15d, %r12d
   131c4:      	seta	%sil
   131c8:      	movl	%r15d, %ecx
   131cb:      	cmovbl	%r12d, %ecx
   131cf:      	addl	%ecx, %esi
   131d1:      	movl	%r12d, %edi
   131d4:      	subl	%esi, %edi
   131d6:      	movl	%edi, 0x50(%rsp)
   131da:      	subq	%rsi, %rax
   131dd:      	jb	0x15f32 <generic_fentry_path+0xba72>
   131e3:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   131e9:      	ja	0x15f32 <generic_fentry_path+0xba72>
   131ef:      	cmpl	%r15d, %r12d
   131f2:      	jbe	0x131f8 <generic_fentry_path+0x8d38>
   131f4:      	movb	$0x2f, (%rbx,%rax)
   131f8:      	xorl	%edi, %edi
   131fa:      	cmpl	%r15d, %r12d
   131fd:      	seta	%dil
   13201:      	movzbl	%cl, %esi
   13204:      	addq	%rax, %rbx
   13207:      	addq	%rbx, %rdi
   1320a:      	movl	$0x4, %eax
   1320f:      	callq	*%rax
   13211:      	movq	%rbx, 0x48(%rsp)
   13216:      	cmpl	%r15d, %r12d
   13219:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   1321f:      	movq	0x8(%rsp), %r12
   13224:      	movq	%r12, 0x30(%rsp)
   13229:      	movq	0x38(%rsp), %rdx
   1322e:      	movq	0x40(%rsp), %r15
   13233:      	jmp	0x13286 <generic_fentry_path+0x8dc6>
   13235:      	leaq	0x10(%r15), %rdx
   13239:      	movl	$0x4, %eax
   1323e:      	movq	%rbp, %rdi
   13241:      	movl	$0x8, %esi
   13246:      	callq	*%rax
   13248:      	movq	0x40(%rsp), %rax
   1324d:      	cmpq	(%rsp), %rax
   13251:      	je	0x15f2d <generic_fentry_path+0xba6d>
   13257:      	addq	$0x18, %r15
   1325b:      	movl	$0x4, %eax
   13260:      	leaq	0x30(%rsp), %rdi
   13265:      	movl	$0x8, %esi
   1326a:      	movq	%r15, %rdx
   1326d:      	callq	*%rax
   1326f:      	movq	(%rsp), %r15
   13273:      	movq	%r15, 0x40(%rsp)
   13278:      	leaq	0x20(%r15), %rdx
   1327c:      	movq	%rdx, 0x38(%rsp)
   13281:      	movq	0x30(%rsp), %r12
   13286:      	cmpq	0x18(%rsp), %r12
   1328b:      	jne	0x13298 <generic_fentry_path+0x8dd8>
   1328d:      	cmpq	0x20(%rsp), %rdx
   13292:      	je	0x15f2d <generic_fentry_path+0xba6d>
   13298:      	movl	$0x4, %eax
   1329d:      	leaq	0x10(%rsp), %rdi
   132a2:      	movl	$0x8, %esi
   132a7:      	callq	*%rax
   132a9:      	cmpq	0x10(%rsp), %r12
   132ae:      	je	0x133a6 <generic_fentry_path+0x8ee6>
   132b4:      	leaq	0x18(%r12), %rbx
   132b9:      	movl	$0x4, %eax
   132be:      	movq	%rbp, %rdi
   132c1:      	movl	$0x8, %esi
   132c6:      	movq	%rbx, %rdx
   132c9:      	callq	*%rax
   132cb:      	cmpq	%r12, (%rsp)
   132cf:      	je	0x133a6 <generic_fentry_path+0x8ee6>
   132d5:      	movl	$0x4, %eax
   132da:      	leaq	0x8(%rsp), %rdi
   132df:      	movl	$0x8, %esi
   132e4:      	movq	%rbx, %rdx
   132e7:      	callq	*%rax
   132e9:      	addq	$0x20, %r12
   132ed:      	movl	$0x4, %eax
   132f2:      	leaq	0x58(%rsp), %rdi
   132f7:      	movl	$0x10, %ecx
   132fc:      	movl	$0x10, %esi
   13301:      	movq	%r12, %rdx
   13304:      	callq	*%rax
   13306:      	movq	0x28(%rsp), %rbx
   1330b:      	movq	0x48(%rsp), %rax
   13310:      	movl	0x5c(%rsp), %r15d
   13315:      	subq	%rbx, %rax
   13318:      	movl	0x50(%rsp), %r12d
   1331d:      	movl	%r15d, %edx
   13320:      	subl	%r12d, %edx
   13323:      	movl	$0x0, %ecx
   13328:      	cmovbl	%ecx, %edx
   1332b:      	addq	0x60(%rsp), %rdx
   13330:      	xorl	%esi, %esi
   13332:      	cmpl	%r15d, %r12d
   13335:      	seta	%sil
   13339:      	movl	%r15d, %ecx
   1333c:      	cmovbl	%r12d, %ecx
   13340:      	addl	%ecx, %esi
   13342:      	movl	%r12d, %edi
   13345:      	subl	%esi, %edi
   13347:      	movl	%edi, 0x50(%rsp)
   1334b:      	subq	%rsi, %rax
   1334e:      	jb	0x15f32 <generic_fentry_path+0xba72>
   13354:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1335a:      	ja	0x15f32 <generic_fentry_path+0xba72>
   13360:      	cmpl	%r15d, %r12d
   13363:      	jbe	0x13369 <generic_fentry_path+0x8ea9>
   13365:      	movb	$0x2f, (%rbx,%rax)
   13369:      	xorl	%edi, %edi
   1336b:      	cmpl	%r15d, %r12d
   1336e:      	seta	%dil
   13372:      	movzbl	%cl, %esi
   13375:      	addq	%rax, %rbx
   13378:      	addq	%rbx, %rdi
   1337b:      	movl	$0x4, %eax
   13380:      	callq	*%rax
   13382:      	movq	%rbx, 0x48(%rsp)
   13387:      	cmpl	%r15d, %r12d
   1338a:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   13390:      	movq	0x8(%rsp), %r12
   13395:      	movq	%r12, 0x30(%rsp)
   1339a:      	movq	0x38(%rsp), %rdx
   1339f:      	movq	0x40(%rsp), %r15
   133a4:      	jmp	0x133f7 <generic_fentry_path+0x8f37>
   133a6:      	leaq	0x10(%r15), %rdx
   133aa:      	movl	$0x4, %eax
   133af:      	movq	%rbp, %rdi
   133b2:      	movl	$0x8, %esi
   133b7:      	callq	*%rax
   133b9:      	movq	0x40(%rsp), %rax
   133be:      	cmpq	(%rsp), %rax
   133c2:      	je	0x15f2d <generic_fentry_path+0xba6d>
   133c8:      	addq	$0x18, %r15
   133cc:      	movl	$0x4, %eax
   133d1:      	leaq	0x30(%rsp), %rdi
   133d6:      	movl	$0x8, %esi
   133db:      	movq	%r15, %rdx
   133de:      	callq	*%rax
   133e0:      	movq	(%rsp), %r15
   133e4:      	movq	%r15, 0x40(%rsp)
   133e9:      	leaq	0x20(%r15), %rdx
   133ed:      	movq	%rdx, 0x38(%rsp)
   133f2:      	movq	0x30(%rsp), %r12
   133f7:      	cmpq	0x18(%rsp), %r12
   133fc:      	jne	0x13409 <generic_fentry_path+0x8f49>
   133fe:      	cmpq	0x20(%rsp), %rdx
   13403:      	je	0x15f2d <generic_fentry_path+0xba6d>
   13409:      	movl	$0x4, %eax
   1340e:      	leaq	0x10(%rsp), %rdi
   13413:      	movl	$0x8, %esi
   13418:      	callq	*%rax
   1341a:      	cmpq	0x10(%rsp), %r12
   1341f:      	je	0x13517 <generic_fentry_path+0x9057>
   13425:      	leaq	0x18(%r12), %rbx
   1342a:      	movl	$0x4, %eax
   1342f:      	movq	%rbp, %rdi
   13432:      	movl	$0x8, %esi
   13437:      	movq	%rbx, %rdx
   1343a:      	callq	*%rax
   1343c:      	cmpq	%r12, (%rsp)
   13440:      	je	0x13517 <generic_fentry_path+0x9057>
   13446:      	movl	$0x4, %eax
   1344b:      	leaq	0x8(%rsp), %rdi
   13450:      	movl	$0x8, %esi
   13455:      	movq	%rbx, %rdx
   13458:      	callq	*%rax
   1345a:      	addq	$0x20, %r12
   1345e:      	movl	$0x4, %eax
   13463:      	leaq	0x58(%rsp), %rdi
   13468:      	movl	$0x10, %ecx
   1346d:      	movl	$0x10, %esi
   13472:      	movq	%r12, %rdx
   13475:      	callq	*%rax
   13477:      	movq	0x28(%rsp), %rbx
   1347c:      	movq	0x48(%rsp), %rax
   13481:      	movl	0x5c(%rsp), %r15d
   13486:      	subq	%rbx, %rax
   13489:      	movl	0x50(%rsp), %r12d
   1348e:      	movl	%r15d, %edx
   13491:      	subl	%r12d, %edx
   13494:      	movl	$0x0, %ecx
   13499:      	cmovbl	%ecx, %edx
   1349c:      	addq	0x60(%rsp), %rdx
   134a1:      	xorl	%esi, %esi
   134a3:      	cmpl	%r15d, %r12d
   134a6:      	seta	%sil
   134aa:      	movl	%r15d, %ecx
   134ad:      	cmovbl	%r12d, %ecx
   134b1:      	addl	%ecx, %esi
   134b3:      	movl	%r12d, %edi
   134b6:      	subl	%esi, %edi
   134b8:      	movl	%edi, 0x50(%rsp)
   134bc:      	subq	%rsi, %rax
   134bf:      	jb	0x15f32 <generic_fentry_path+0xba72>
   134c5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   134cb:      	ja	0x15f32 <generic_fentry_path+0xba72>
   134d1:      	cmpl	%r15d, %r12d
   134d4:      	jbe	0x134da <generic_fentry_path+0x901a>
   134d6:      	movb	$0x2f, (%rbx,%rax)
   134da:      	xorl	%edi, %edi
   134dc:      	cmpl	%r15d, %r12d
   134df:      	seta	%dil
   134e3:      	movzbl	%cl, %esi
   134e6:      	addq	%rax, %rbx
   134e9:      	addq	%rbx, %rdi
   134ec:      	movl	$0x4, %eax
   134f1:      	callq	*%rax
   134f3:      	movq	%rbx, 0x48(%rsp)
   134f8:      	cmpl	%r15d, %r12d
   134fb:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   13501:      	movq	0x8(%rsp), %r12
   13506:      	movq	%r12, 0x30(%rsp)
   1350b:      	movq	0x38(%rsp), %rdx
   13510:      	movq	0x40(%rsp), %r15
   13515:      	jmp	0x13568 <generic_fentry_path+0x90a8>
   13517:      	leaq	0x10(%r15), %rdx
   1351b:      	movl	$0x4, %eax
   13520:      	movq	%rbp, %rdi
   13523:      	movl	$0x8, %esi
   13528:      	callq	*%rax
   1352a:      	movq	0x40(%rsp), %rax
   1352f:      	cmpq	(%rsp), %rax
   13533:      	je	0x15f2d <generic_fentry_path+0xba6d>
   13539:      	addq	$0x18, %r15
   1353d:      	movl	$0x4, %eax
   13542:      	leaq	0x30(%rsp), %rdi
   13547:      	movl	$0x8, %esi
   1354c:      	movq	%r15, %rdx
   1354f:      	callq	*%rax
   13551:      	movq	(%rsp), %r15
   13555:      	movq	%r15, 0x40(%rsp)
   1355a:      	leaq	0x20(%r15), %rdx
   1355e:      	movq	%rdx, 0x38(%rsp)
   13563:      	movq	0x30(%rsp), %r12
   13568:      	cmpq	0x18(%rsp), %r12
   1356d:      	jne	0x1357a <generic_fentry_path+0x90ba>
   1356f:      	cmpq	0x20(%rsp), %rdx
   13574:      	je	0x15f2d <generic_fentry_path+0xba6d>
   1357a:      	movl	$0x4, %eax
   1357f:      	leaq	0x10(%rsp), %rdi
   13584:      	movl	$0x8, %esi
   13589:      	callq	*%rax
   1358b:      	cmpq	0x10(%rsp), %r12
   13590:      	je	0x13688 <generic_fentry_path+0x91c8>
   13596:      	leaq	0x18(%r12), %rbx
   1359b:      	movl	$0x4, %eax
   135a0:      	movq	%rbp, %rdi
   135a3:      	movl	$0x8, %esi
   135a8:      	movq	%rbx, %rdx
   135ab:      	callq	*%rax
   135ad:      	cmpq	%r12, (%rsp)
   135b1:      	je	0x13688 <generic_fentry_path+0x91c8>
   135b7:      	movl	$0x4, %eax
   135bc:      	leaq	0x8(%rsp), %rdi
   135c1:      	movl	$0x8, %esi
   135c6:      	movq	%rbx, %rdx
   135c9:      	callq	*%rax
   135cb:      	addq	$0x20, %r12
   135cf:      	movl	$0x4, %eax
   135d4:      	leaq	0x58(%rsp), %rdi
   135d9:      	movl	$0x10, %ecx
   135de:      	movl	$0x10, %esi
   135e3:      	movq	%r12, %rdx
   135e6:      	callq	*%rax
   135e8:      	movq	0x28(%rsp), %rbx
   135ed:      	movq	0x48(%rsp), %rax
   135f2:      	movl	0x5c(%rsp), %r15d
   135f7:      	subq	%rbx, %rax
   135fa:      	movl	0x50(%rsp), %r12d
   135ff:      	movl	%r15d, %edx
   13602:      	subl	%r12d, %edx
   13605:      	movl	$0x0, %ecx
   1360a:      	cmovbl	%ecx, %edx
   1360d:      	addq	0x60(%rsp), %rdx
   13612:      	xorl	%esi, %esi
   13614:      	cmpl	%r15d, %r12d
   13617:      	seta	%sil
   1361b:      	movl	%r15d, %ecx
   1361e:      	cmovbl	%r12d, %ecx
   13622:      	addl	%ecx, %esi
   13624:      	movl	%r12d, %edi
   13627:      	subl	%esi, %edi
   13629:      	movl	%edi, 0x50(%rsp)
   1362d:      	subq	%rsi, %rax
   13630:      	jb	0x15f32 <generic_fentry_path+0xba72>
   13636:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1363c:      	ja	0x15f32 <generic_fentry_path+0xba72>
   13642:      	cmpl	%r15d, %r12d
   13645:      	jbe	0x1364b <generic_fentry_path+0x918b>
   13647:      	movb	$0x2f, (%rbx,%rax)
   1364b:      	xorl	%edi, %edi
   1364d:      	cmpl	%r15d, %r12d
   13650:      	seta	%dil
   13654:      	movzbl	%cl, %esi
   13657:      	addq	%rax, %rbx
   1365a:      	addq	%rbx, %rdi
   1365d:      	movl	$0x4, %eax
   13662:      	callq	*%rax
   13664:      	movq	%rbx, 0x48(%rsp)
   13669:      	cmpl	%r15d, %r12d
   1366c:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   13672:      	movq	0x8(%rsp), %r12
   13677:      	movq	%r12, 0x30(%rsp)
   1367c:      	movq	0x38(%rsp), %rdx
   13681:      	movq	0x40(%rsp), %r15
   13686:      	jmp	0x136d9 <generic_fentry_path+0x9219>
   13688:      	leaq	0x10(%r15), %rdx
   1368c:      	movl	$0x4, %eax
   13691:      	movq	%rbp, %rdi
   13694:      	movl	$0x8, %esi
   13699:      	callq	*%rax
   1369b:      	movq	0x40(%rsp), %rax
   136a0:      	cmpq	(%rsp), %rax
   136a4:      	je	0x15f2d <generic_fentry_path+0xba6d>
   136aa:      	addq	$0x18, %r15
   136ae:      	movl	$0x4, %eax
   136b3:      	leaq	0x30(%rsp), %rdi
   136b8:      	movl	$0x8, %esi
   136bd:      	movq	%r15, %rdx
   136c0:      	callq	*%rax
   136c2:      	movq	(%rsp), %r15
   136c6:      	movq	%r15, 0x40(%rsp)
   136cb:      	leaq	0x20(%r15), %rdx
   136cf:      	movq	%rdx, 0x38(%rsp)
   136d4:      	movq	0x30(%rsp), %r12
   136d9:      	cmpq	0x18(%rsp), %r12
   136de:      	jne	0x136eb <generic_fentry_path+0x922b>
   136e0:      	cmpq	0x20(%rsp), %rdx
   136e5:      	je	0x15f2d <generic_fentry_path+0xba6d>
   136eb:      	movl	$0x4, %eax
   136f0:      	leaq	0x10(%rsp), %rdi
   136f5:      	movl	$0x8, %esi
   136fa:      	callq	*%rax
   136fc:      	cmpq	0x10(%rsp), %r12
   13701:      	je	0x137f9 <generic_fentry_path+0x9339>
   13707:      	leaq	0x18(%r12), %rbx
   1370c:      	movl	$0x4, %eax
   13711:      	movq	%rbp, %rdi
   13714:      	movl	$0x8, %esi
   13719:      	movq	%rbx, %rdx
   1371c:      	callq	*%rax
   1371e:      	cmpq	%r12, (%rsp)
   13722:      	je	0x137f9 <generic_fentry_path+0x9339>
   13728:      	movl	$0x4, %eax
   1372d:      	leaq	0x8(%rsp), %rdi
   13732:      	movl	$0x8, %esi
   13737:      	movq	%rbx, %rdx
   1373a:      	callq	*%rax
   1373c:      	addq	$0x20, %r12
   13740:      	movl	$0x4, %eax
   13745:      	leaq	0x58(%rsp), %rdi
   1374a:      	movl	$0x10, %ecx
   1374f:      	movl	$0x10, %esi
   13754:      	movq	%r12, %rdx
   13757:      	callq	*%rax
   13759:      	movq	0x28(%rsp), %rbx
   1375e:      	movq	0x48(%rsp), %rax
   13763:      	movl	0x5c(%rsp), %r15d
   13768:      	subq	%rbx, %rax
   1376b:      	movl	0x50(%rsp), %r12d
   13770:      	movl	%r15d, %edx
   13773:      	subl	%r12d, %edx
   13776:      	movl	$0x0, %ecx
   1377b:      	cmovbl	%ecx, %edx
   1377e:      	addq	0x60(%rsp), %rdx
   13783:      	xorl	%esi, %esi
   13785:      	cmpl	%r15d, %r12d
   13788:      	seta	%sil
   1378c:      	movl	%r15d, %ecx
   1378f:      	cmovbl	%r12d, %ecx
   13793:      	addl	%ecx, %esi
   13795:      	movl	%r12d, %edi
   13798:      	subl	%esi, %edi
   1379a:      	movl	%edi, 0x50(%rsp)
   1379e:      	subq	%rsi, %rax
   137a1:      	jb	0x15f32 <generic_fentry_path+0xba72>
   137a7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   137ad:      	ja	0x15f32 <generic_fentry_path+0xba72>
   137b3:      	cmpl	%r15d, %r12d
   137b6:      	jbe	0x137bc <generic_fentry_path+0x92fc>
   137b8:      	movb	$0x2f, (%rbx,%rax)
   137bc:      	xorl	%edi, %edi
   137be:      	cmpl	%r15d, %r12d
   137c1:      	seta	%dil
   137c5:      	movzbl	%cl, %esi
   137c8:      	addq	%rax, %rbx
   137cb:      	addq	%rbx, %rdi
   137ce:      	movl	$0x4, %eax
   137d3:      	callq	*%rax
   137d5:      	movq	%rbx, 0x48(%rsp)
   137da:      	cmpl	%r15d, %r12d
   137dd:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   137e3:      	movq	0x8(%rsp), %r12
   137e8:      	movq	%r12, 0x30(%rsp)
   137ed:      	movq	0x38(%rsp), %rdx
   137f2:      	movq	0x40(%rsp), %r15
   137f7:      	jmp	0x1384a <generic_fentry_path+0x938a>
   137f9:      	leaq	0x10(%r15), %rdx
   137fd:      	movl	$0x4, %eax
   13802:      	movq	%rbp, %rdi
   13805:      	movl	$0x8, %esi
   1380a:      	callq	*%rax
   1380c:      	movq	0x40(%rsp), %rax
   13811:      	cmpq	(%rsp), %rax
   13815:      	je	0x15f2d <generic_fentry_path+0xba6d>
   1381b:      	addq	$0x18, %r15
   1381f:      	movl	$0x4, %eax
   13824:      	leaq	0x30(%rsp), %rdi
   13829:      	movl	$0x8, %esi
   1382e:      	movq	%r15, %rdx
   13831:      	callq	*%rax
   13833:      	movq	(%rsp), %r15
   13837:      	movq	%r15, 0x40(%rsp)
   1383c:      	leaq	0x20(%r15), %rdx
   13840:      	movq	%rdx, 0x38(%rsp)
   13845:      	movq	0x30(%rsp), %r12
   1384a:      	cmpq	0x18(%rsp), %r12
   1384f:      	jne	0x1385c <generic_fentry_path+0x939c>
   13851:      	cmpq	0x20(%rsp), %rdx
   13856:      	je	0x15f2d <generic_fentry_path+0xba6d>
   1385c:      	movl	$0x4, %eax
   13861:      	leaq	0x10(%rsp), %rdi
   13866:      	movl	$0x8, %esi
   1386b:      	callq	*%rax
   1386d:      	cmpq	0x10(%rsp), %r12
   13872:      	je	0x1396a <generic_fentry_path+0x94aa>
   13878:      	leaq	0x18(%r12), %rbx
   1387d:      	movl	$0x4, %eax
   13882:      	movq	%rbp, %rdi
   13885:      	movl	$0x8, %esi
   1388a:      	movq	%rbx, %rdx
   1388d:      	callq	*%rax
   1388f:      	cmpq	%r12, (%rsp)
   13893:      	je	0x1396a <generic_fentry_path+0x94aa>
   13899:      	movl	$0x4, %eax
   1389e:      	leaq	0x8(%rsp), %rdi
   138a3:      	movl	$0x8, %esi
   138a8:      	movq	%rbx, %rdx
   138ab:      	callq	*%rax
   138ad:      	addq	$0x20, %r12
   138b1:      	movl	$0x4, %eax
   138b6:      	leaq	0x58(%rsp), %rdi
   138bb:      	movl	$0x10, %ecx
   138c0:      	movl	$0x10, %esi
   138c5:      	movq	%r12, %rdx
   138c8:      	callq	*%rax
   138ca:      	movq	0x28(%rsp), %rbx
   138cf:      	movq	0x48(%rsp), %rax
   138d4:      	movl	0x5c(%rsp), %r15d
   138d9:      	subq	%rbx, %rax
   138dc:      	movl	0x50(%rsp), %r12d
   138e1:      	movl	%r15d, %edx
   138e4:      	subl	%r12d, %edx
   138e7:      	movl	$0x0, %ecx
   138ec:      	cmovbl	%ecx, %edx
   138ef:      	addq	0x60(%rsp), %rdx
   138f4:      	xorl	%esi, %esi
   138f6:      	cmpl	%r15d, %r12d
   138f9:      	seta	%sil
   138fd:      	movl	%r15d, %ecx
   13900:      	cmovbl	%r12d, %ecx
   13904:      	addl	%ecx, %esi
   13906:      	movl	%r12d, %edi
   13909:      	subl	%esi, %edi
   1390b:      	movl	%edi, 0x50(%rsp)
   1390f:      	subq	%rsi, %rax
   13912:      	jb	0x15f32 <generic_fentry_path+0xba72>
   13918:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1391e:      	ja	0x15f32 <generic_fentry_path+0xba72>
   13924:      	cmpl	%r15d, %r12d
   13927:      	jbe	0x1392d <generic_fentry_path+0x946d>
   13929:      	movb	$0x2f, (%rbx,%rax)
   1392d:      	xorl	%edi, %edi
   1392f:      	cmpl	%r15d, %r12d
   13932:      	seta	%dil
   13936:      	movzbl	%cl, %esi
   13939:      	addq	%rax, %rbx
   1393c:      	addq	%rbx, %rdi
   1393f:      	movl	$0x4, %eax
   13944:      	callq	*%rax
   13946:      	movq	%rbx, 0x48(%rsp)
   1394b:      	cmpl	%r15d, %r12d
   1394e:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   13954:      	movq	0x8(%rsp), %r12
   13959:      	movq	%r12, 0x30(%rsp)
   1395e:      	movq	0x38(%rsp), %rdx
   13963:      	movq	0x40(%rsp), %r15
   13968:      	jmp	0x139bb <generic_fentry_path+0x94fb>
   1396a:      	leaq	0x10(%r15), %rdx
   1396e:      	movl	$0x4, %eax
   13973:      	movq	%rbp, %rdi
   13976:      	movl	$0x8, %esi
   1397b:      	callq	*%rax
   1397d:      	movq	0x40(%rsp), %rax
   13982:      	cmpq	(%rsp), %rax
   13986:      	je	0x15f2d <generic_fentry_path+0xba6d>
   1398c:      	addq	$0x18, %r15
   13990:      	movl	$0x4, %eax
   13995:      	leaq	0x30(%rsp), %rdi
   1399a:      	movl	$0x8, %esi
   1399f:      	movq	%r15, %rdx
   139a2:      	callq	*%rax
   139a4:      	movq	(%rsp), %r15
   139a8:      	movq	%r15, 0x40(%rsp)
   139ad:      	leaq	0x20(%r15), %rdx
   139b1:      	movq	%rdx, 0x38(%rsp)
   139b6:      	movq	0x30(%rsp), %r12
   139bb:      	cmpq	0x18(%rsp), %r12
   139c0:      	jne	0x139cd <generic_fentry_path+0x950d>
   139c2:      	cmpq	0x20(%rsp), %rdx
   139c7:      	je	0x15f2d <generic_fentry_path+0xba6d>
   139cd:      	movl	$0x4, %eax
   139d2:      	leaq	0x10(%rsp), %rdi
   139d7:      	movl	$0x8, %esi
   139dc:      	callq	*%rax
   139de:      	cmpq	0x10(%rsp), %r12
   139e3:      	je	0x13adb <generic_fentry_path+0x961b>
   139e9:      	leaq	0x18(%r12), %rbx
   139ee:      	movl	$0x4, %eax
   139f3:      	movq	%rbp, %rdi
   139f6:      	movl	$0x8, %esi
   139fb:      	movq	%rbx, %rdx
   139fe:      	callq	*%rax
   13a00:      	cmpq	%r12, (%rsp)
   13a04:      	je	0x13adb <generic_fentry_path+0x961b>
   13a0a:      	movl	$0x4, %eax
   13a0f:      	leaq	0x8(%rsp), %rdi
   13a14:      	movl	$0x8, %esi
   13a19:      	movq	%rbx, %rdx
   13a1c:      	callq	*%rax
   13a1e:      	addq	$0x20, %r12
   13a22:      	movl	$0x4, %eax
   13a27:      	leaq	0x58(%rsp), %rdi
   13a2c:      	movl	$0x10, %ecx
   13a31:      	movl	$0x10, %esi
   13a36:      	movq	%r12, %rdx
   13a39:      	callq	*%rax
   13a3b:      	movq	0x28(%rsp), %rbx
   13a40:      	movq	0x48(%rsp), %rax
   13a45:      	movl	0x5c(%rsp), %r15d
   13a4a:      	subq	%rbx, %rax
   13a4d:      	movl	0x50(%rsp), %r12d
   13a52:      	movl	%r15d, %edx
   13a55:      	subl	%r12d, %edx
   13a58:      	movl	$0x0, %ecx
   13a5d:      	cmovbl	%ecx, %edx
   13a60:      	addq	0x60(%rsp), %rdx
   13a65:      	xorl	%esi, %esi
   13a67:      	cmpl	%r15d, %r12d
   13a6a:      	seta	%sil
   13a6e:      	movl	%r15d, %ecx
   13a71:      	cmovbl	%r12d, %ecx
   13a75:      	addl	%ecx, %esi
   13a77:      	movl	%r12d, %edi
   13a7a:      	subl	%esi, %edi
   13a7c:      	movl	%edi, 0x50(%rsp)
   13a80:      	subq	%rsi, %rax
   13a83:      	jb	0x15f32 <generic_fentry_path+0xba72>
   13a89:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13a8f:      	ja	0x15f32 <generic_fentry_path+0xba72>
   13a95:      	cmpl	%r15d, %r12d
   13a98:      	jbe	0x13a9e <generic_fentry_path+0x95de>
   13a9a:      	movb	$0x2f, (%rbx,%rax)
   13a9e:      	xorl	%edi, %edi
   13aa0:      	cmpl	%r15d, %r12d
   13aa3:      	seta	%dil
   13aa7:      	movzbl	%cl, %esi
   13aaa:      	addq	%rax, %rbx
   13aad:      	addq	%rbx, %rdi
   13ab0:      	movl	$0x4, %eax
   13ab5:      	callq	*%rax
   13ab7:      	movq	%rbx, 0x48(%rsp)
   13abc:      	cmpl	%r15d, %r12d
   13abf:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   13ac5:      	movq	0x8(%rsp), %r12
   13aca:      	movq	%r12, 0x30(%rsp)
   13acf:      	movq	0x38(%rsp), %rdx
   13ad4:      	movq	0x40(%rsp), %r15
   13ad9:      	jmp	0x13b2c <generic_fentry_path+0x966c>
   13adb:      	leaq	0x10(%r15), %rdx
   13adf:      	movl	$0x4, %eax
   13ae4:      	movq	%rbp, %rdi
   13ae7:      	movl	$0x8, %esi
   13aec:      	callq	*%rax
   13aee:      	movq	0x40(%rsp), %rax
   13af3:      	cmpq	(%rsp), %rax
   13af7:      	je	0x15f2d <generic_fentry_path+0xba6d>
   13afd:      	addq	$0x18, %r15
   13b01:      	movl	$0x4, %eax
   13b06:      	leaq	0x30(%rsp), %rdi
   13b0b:      	movl	$0x8, %esi
   13b10:      	movq	%r15, %rdx
   13b13:      	callq	*%rax
   13b15:      	movq	(%rsp), %r15
   13b19:      	movq	%r15, 0x40(%rsp)
   13b1e:      	leaq	0x20(%r15), %rdx
   13b22:      	movq	%rdx, 0x38(%rsp)
   13b27:      	movq	0x30(%rsp), %r12
   13b2c:      	cmpq	0x18(%rsp), %r12
   13b31:      	jne	0x13b3e <generic_fentry_path+0x967e>
   13b33:      	cmpq	0x20(%rsp), %rdx
   13b38:      	je	0x15f2d <generic_fentry_path+0xba6d>
   13b3e:      	movl	$0x4, %eax
   13b43:      	leaq	0x10(%rsp), %rdi
   13b48:      	movl	$0x8, %esi
   13b4d:      	callq	*%rax
   13b4f:      	cmpq	0x10(%rsp), %r12
   13b54:      	je	0x13c4c <generic_fentry_path+0x978c>
   13b5a:      	leaq	0x18(%r12), %rbx
   13b5f:      	movl	$0x4, %eax
   13b64:      	movq	%rbp, %rdi
   13b67:      	movl	$0x8, %esi
   13b6c:      	movq	%rbx, %rdx
   13b6f:      	callq	*%rax
   13b71:      	cmpq	%r12, (%rsp)
   13b75:      	je	0x13c4c <generic_fentry_path+0x978c>
   13b7b:      	movl	$0x4, %eax
   13b80:      	leaq	0x8(%rsp), %rdi
   13b85:      	movl	$0x8, %esi
   13b8a:      	movq	%rbx, %rdx
   13b8d:      	callq	*%rax
   13b8f:      	addq	$0x20, %r12
   13b93:      	movl	$0x4, %eax
   13b98:      	leaq	0x58(%rsp), %rdi
   13b9d:      	movl	$0x10, %ecx
   13ba2:      	movl	$0x10, %esi
   13ba7:      	movq	%r12, %rdx
   13baa:      	callq	*%rax
   13bac:      	movq	0x28(%rsp), %rbx
   13bb1:      	movq	0x48(%rsp), %rax
   13bb6:      	movl	0x5c(%rsp), %r15d
   13bbb:      	subq	%rbx, %rax
   13bbe:      	movl	0x50(%rsp), %r12d
   13bc3:      	movl	%r15d, %edx
   13bc6:      	subl	%r12d, %edx
   13bc9:      	movl	$0x0, %ecx
   13bce:      	cmovbl	%ecx, %edx
   13bd1:      	addq	0x60(%rsp), %rdx
   13bd6:      	xorl	%esi, %esi
   13bd8:      	cmpl	%r15d, %r12d
   13bdb:      	seta	%sil
   13bdf:      	movl	%r15d, %ecx
   13be2:      	cmovbl	%r12d, %ecx
   13be6:      	addl	%ecx, %esi
   13be8:      	movl	%r12d, %edi
   13beb:      	subl	%esi, %edi
   13bed:      	movl	%edi, 0x50(%rsp)
   13bf1:      	subq	%rsi, %rax
   13bf4:      	jb	0x15f32 <generic_fentry_path+0xba72>
   13bfa:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13c00:      	ja	0x15f32 <generic_fentry_path+0xba72>
   13c06:      	cmpl	%r15d, %r12d
   13c09:      	jbe	0x13c0f <generic_fentry_path+0x974f>
   13c0b:      	movb	$0x2f, (%rbx,%rax)
   13c0f:      	xorl	%edi, %edi
   13c11:      	cmpl	%r15d, %r12d
   13c14:      	seta	%dil
   13c18:      	movzbl	%cl, %esi
   13c1b:      	addq	%rax, %rbx
   13c1e:      	addq	%rbx, %rdi
   13c21:      	movl	$0x4, %eax
   13c26:      	callq	*%rax
   13c28:      	movq	%rbx, 0x48(%rsp)
   13c2d:      	cmpl	%r15d, %r12d
   13c30:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   13c36:      	movq	0x8(%rsp), %r12
   13c3b:      	movq	%r12, 0x30(%rsp)
   13c40:      	movq	0x38(%rsp), %rdx
   13c45:      	movq	0x40(%rsp), %r15
   13c4a:      	jmp	0x13c9d <generic_fentry_path+0x97dd>
   13c4c:      	leaq	0x10(%r15), %rdx
   13c50:      	movl	$0x4, %eax
   13c55:      	movq	%rbp, %rdi
   13c58:      	movl	$0x8, %esi
   13c5d:      	callq	*%rax
   13c5f:      	movq	0x40(%rsp), %rax
   13c64:      	cmpq	(%rsp), %rax
   13c68:      	je	0x15f2d <generic_fentry_path+0xba6d>
   13c6e:      	addq	$0x18, %r15
   13c72:      	movl	$0x4, %eax
   13c77:      	leaq	0x30(%rsp), %rdi
   13c7c:      	movl	$0x8, %esi
   13c81:      	movq	%r15, %rdx
   13c84:      	callq	*%rax
   13c86:      	movq	(%rsp), %r15
   13c8a:      	movq	%r15, 0x40(%rsp)
   13c8f:      	leaq	0x20(%r15), %rdx
   13c93:      	movq	%rdx, 0x38(%rsp)
   13c98:      	movq	0x30(%rsp), %r12
   13c9d:      	cmpq	0x18(%rsp), %r12
   13ca2:      	jne	0x13caf <generic_fentry_path+0x97ef>
   13ca4:      	cmpq	0x20(%rsp), %rdx
   13ca9:      	je	0x15f2d <generic_fentry_path+0xba6d>
   13caf:      	movl	$0x4, %eax
   13cb4:      	leaq	0x10(%rsp), %rdi
   13cb9:      	movl	$0x8, %esi
   13cbe:      	callq	*%rax
   13cc0:      	cmpq	0x10(%rsp), %r12
   13cc5:      	je	0x13dbd <generic_fentry_path+0x98fd>
   13ccb:      	leaq	0x18(%r12), %rbx
   13cd0:      	movl	$0x4, %eax
   13cd5:      	movq	%rbp, %rdi
   13cd8:      	movl	$0x8, %esi
   13cdd:      	movq	%rbx, %rdx
   13ce0:      	callq	*%rax
   13ce2:      	cmpq	%r12, (%rsp)
   13ce6:      	je	0x13dbd <generic_fentry_path+0x98fd>
   13cec:      	movl	$0x4, %eax
   13cf1:      	leaq	0x8(%rsp), %rdi
   13cf6:      	movl	$0x8, %esi
   13cfb:      	movq	%rbx, %rdx
   13cfe:      	callq	*%rax
   13d00:      	addq	$0x20, %r12
   13d04:      	movl	$0x4, %eax
   13d09:      	leaq	0x58(%rsp), %rdi
   13d0e:      	movl	$0x10, %ecx
   13d13:      	movl	$0x10, %esi
   13d18:      	movq	%r12, %rdx
   13d1b:      	callq	*%rax
   13d1d:      	movq	0x28(%rsp), %rbx
   13d22:      	movq	0x48(%rsp), %rax
   13d27:      	movl	0x5c(%rsp), %r15d
   13d2c:      	subq	%rbx, %rax
   13d2f:      	movl	0x50(%rsp), %r12d
   13d34:      	movl	%r15d, %edx
   13d37:      	subl	%r12d, %edx
   13d3a:      	movl	$0x0, %ecx
   13d3f:      	cmovbl	%ecx, %edx
   13d42:      	addq	0x60(%rsp), %rdx
   13d47:      	xorl	%esi, %esi
   13d49:      	cmpl	%r15d, %r12d
   13d4c:      	seta	%sil
   13d50:      	movl	%r15d, %ecx
   13d53:      	cmovbl	%r12d, %ecx
   13d57:      	addl	%ecx, %esi
   13d59:      	movl	%r12d, %edi
   13d5c:      	subl	%esi, %edi
   13d5e:      	movl	%edi, 0x50(%rsp)
   13d62:      	subq	%rsi, %rax
   13d65:      	jb	0x15f32 <generic_fentry_path+0xba72>
   13d6b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13d71:      	ja	0x15f32 <generic_fentry_path+0xba72>
   13d77:      	cmpl	%r15d, %r12d
   13d7a:      	jbe	0x13d80 <generic_fentry_path+0x98c0>
   13d7c:      	movb	$0x2f, (%rbx,%rax)
   13d80:      	xorl	%edi, %edi
   13d82:      	cmpl	%r15d, %r12d
   13d85:      	seta	%dil
   13d89:      	movzbl	%cl, %esi
   13d8c:      	addq	%rax, %rbx
   13d8f:      	addq	%rbx, %rdi
   13d92:      	movl	$0x4, %eax
   13d97:      	callq	*%rax
   13d99:      	movq	%rbx, 0x48(%rsp)
   13d9e:      	cmpl	%r15d, %r12d
   13da1:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   13da7:      	movq	0x8(%rsp), %r12
   13dac:      	movq	%r12, 0x30(%rsp)
   13db1:      	movq	0x38(%rsp), %rdx
   13db6:      	movq	0x40(%rsp), %r15
   13dbb:      	jmp	0x13e0e <generic_fentry_path+0x994e>
   13dbd:      	leaq	0x10(%r15), %rdx
   13dc1:      	movl	$0x4, %eax
   13dc6:      	movq	%rbp, %rdi
   13dc9:      	movl	$0x8, %esi
   13dce:      	callq	*%rax
   13dd0:      	movq	0x40(%rsp), %rax
   13dd5:      	cmpq	(%rsp), %rax
   13dd9:      	je	0x15f2d <generic_fentry_path+0xba6d>
   13ddf:      	addq	$0x18, %r15
   13de3:      	movl	$0x4, %eax
   13de8:      	leaq	0x30(%rsp), %rdi
   13ded:      	movl	$0x8, %esi
   13df2:      	movq	%r15, %rdx
   13df5:      	callq	*%rax
   13df7:      	movq	(%rsp), %r15
   13dfb:      	movq	%r15, 0x40(%rsp)
   13e00:      	leaq	0x20(%r15), %rdx
   13e04:      	movq	%rdx, 0x38(%rsp)
   13e09:      	movq	0x30(%rsp), %r12
   13e0e:      	cmpq	0x18(%rsp), %r12
   13e13:      	jne	0x13e20 <generic_fentry_path+0x9960>
   13e15:      	cmpq	0x20(%rsp), %rdx
   13e1a:      	je	0x15f2d <generic_fentry_path+0xba6d>
   13e20:      	movl	$0x4, %eax
   13e25:      	leaq	0x10(%rsp), %rdi
   13e2a:      	movl	$0x8, %esi
   13e2f:      	callq	*%rax
   13e31:      	cmpq	0x10(%rsp), %r12
   13e36:      	je	0x13f2e <generic_fentry_path+0x9a6e>
   13e3c:      	leaq	0x18(%r12), %rbx
   13e41:      	movl	$0x4, %eax
   13e46:      	movq	%rbp, %rdi
   13e49:      	movl	$0x8, %esi
   13e4e:      	movq	%rbx, %rdx
   13e51:      	callq	*%rax
   13e53:      	cmpq	%r12, (%rsp)
   13e57:      	je	0x13f2e <generic_fentry_path+0x9a6e>
   13e5d:      	movl	$0x4, %eax
   13e62:      	leaq	0x8(%rsp), %rdi
   13e67:      	movl	$0x8, %esi
   13e6c:      	movq	%rbx, %rdx
   13e6f:      	callq	*%rax
   13e71:      	addq	$0x20, %r12
   13e75:      	movl	$0x4, %eax
   13e7a:      	leaq	0x58(%rsp), %rdi
   13e7f:      	movl	$0x10, %ecx
   13e84:      	movl	$0x10, %esi
   13e89:      	movq	%r12, %rdx
   13e8c:      	callq	*%rax
   13e8e:      	movq	0x28(%rsp), %rbx
   13e93:      	movq	0x48(%rsp), %rax
   13e98:      	movl	0x5c(%rsp), %r15d
   13e9d:      	subq	%rbx, %rax
   13ea0:      	movl	0x50(%rsp), %r12d
   13ea5:      	movl	%r15d, %edx
   13ea8:      	subl	%r12d, %edx
   13eab:      	movl	$0x0, %ecx
   13eb0:      	cmovbl	%ecx, %edx
   13eb3:      	addq	0x60(%rsp), %rdx
   13eb8:      	xorl	%esi, %esi
   13eba:      	cmpl	%r15d, %r12d
   13ebd:      	seta	%sil
   13ec1:      	movl	%r15d, %ecx
   13ec4:      	cmovbl	%r12d, %ecx
   13ec8:      	addl	%ecx, %esi
   13eca:      	movl	%r12d, %edi
   13ecd:      	subl	%esi, %edi
   13ecf:      	movl	%edi, 0x50(%rsp)
   13ed3:      	subq	%rsi, %rax
   13ed6:      	jb	0x15f32 <generic_fentry_path+0xba72>
   13edc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13ee2:      	ja	0x15f32 <generic_fentry_path+0xba72>
   13ee8:      	cmpl	%r15d, %r12d
   13eeb:      	jbe	0x13ef1 <generic_fentry_path+0x9a31>
   13eed:      	movb	$0x2f, (%rbx,%rax)
   13ef1:      	xorl	%edi, %edi
   13ef3:      	cmpl	%r15d, %r12d
   13ef6:      	seta	%dil
   13efa:      	movzbl	%cl, %esi
   13efd:      	addq	%rax, %rbx
   13f00:      	addq	%rbx, %rdi
   13f03:      	movl	$0x4, %eax
   13f08:      	callq	*%rax
   13f0a:      	movq	%rbx, 0x48(%rsp)
   13f0f:      	cmpl	%r15d, %r12d
   13f12:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   13f18:      	movq	0x8(%rsp), %r12
   13f1d:      	movq	%r12, 0x30(%rsp)
   13f22:      	movq	0x38(%rsp), %rdx
   13f27:      	movq	0x40(%rsp), %r15
   13f2c:      	jmp	0x13f7f <generic_fentry_path+0x9abf>
   13f2e:      	leaq	0x10(%r15), %rdx
   13f32:      	movl	$0x4, %eax
   13f37:      	movq	%rbp, %rdi
   13f3a:      	movl	$0x8, %esi
   13f3f:      	callq	*%rax
   13f41:      	movq	0x40(%rsp), %rax
   13f46:      	cmpq	(%rsp), %rax
   13f4a:      	je	0x15f2d <generic_fentry_path+0xba6d>
   13f50:      	addq	$0x18, %r15
   13f54:      	movl	$0x4, %eax
   13f59:      	leaq	0x30(%rsp), %rdi
   13f5e:      	movl	$0x8, %esi
   13f63:      	movq	%r15, %rdx
   13f66:      	callq	*%rax
   13f68:      	movq	(%rsp), %r15
   13f6c:      	movq	%r15, 0x40(%rsp)
   13f71:      	leaq	0x20(%r15), %rdx
   13f75:      	movq	%rdx, 0x38(%rsp)
   13f7a:      	movq	0x30(%rsp), %r12
   13f7f:      	cmpq	0x18(%rsp), %r12
   13f84:      	jne	0x13f91 <generic_fentry_path+0x9ad1>
   13f86:      	cmpq	0x20(%rsp), %rdx
   13f8b:      	je	0x15f2d <generic_fentry_path+0xba6d>
   13f91:      	movl	$0x4, %eax
   13f96:      	leaq	0x10(%rsp), %rdi
   13f9b:      	movl	$0x8, %esi
   13fa0:      	callq	*%rax
   13fa2:      	cmpq	0x10(%rsp), %r12
   13fa7:      	je	0x1409f <generic_fentry_path+0x9bdf>
   13fad:      	leaq	0x18(%r12), %rbx
   13fb2:      	movl	$0x4, %eax
   13fb7:      	movq	%rbp, %rdi
   13fba:      	movl	$0x8, %esi
   13fbf:      	movq	%rbx, %rdx
   13fc2:      	callq	*%rax
   13fc4:      	cmpq	%r12, (%rsp)
   13fc8:      	je	0x1409f <generic_fentry_path+0x9bdf>
   13fce:      	movl	$0x4, %eax
   13fd3:      	leaq	0x8(%rsp), %rdi
   13fd8:      	movl	$0x8, %esi
   13fdd:      	movq	%rbx, %rdx
   13fe0:      	callq	*%rax
   13fe2:      	addq	$0x20, %r12
   13fe6:      	movl	$0x4, %eax
   13feb:      	leaq	0x58(%rsp), %rdi
   13ff0:      	movl	$0x10, %ecx
   13ff5:      	movl	$0x10, %esi
   13ffa:      	movq	%r12, %rdx
   13ffd:      	callq	*%rax
   13fff:      	movq	0x28(%rsp), %rbx
   14004:      	movq	0x48(%rsp), %rax
   14009:      	movl	0x5c(%rsp), %r15d
   1400e:      	subq	%rbx, %rax
   14011:      	movl	0x50(%rsp), %r12d
   14016:      	movl	%r15d, %edx
   14019:      	subl	%r12d, %edx
   1401c:      	movl	$0x0, %ecx
   14021:      	cmovbl	%ecx, %edx
   14024:      	addq	0x60(%rsp), %rdx
   14029:      	xorl	%esi, %esi
   1402b:      	cmpl	%r15d, %r12d
   1402e:      	seta	%sil
   14032:      	movl	%r15d, %ecx
   14035:      	cmovbl	%r12d, %ecx
   14039:      	addl	%ecx, %esi
   1403b:      	movl	%r12d, %edi
   1403e:      	subl	%esi, %edi
   14040:      	movl	%edi, 0x50(%rsp)
   14044:      	subq	%rsi, %rax
   14047:      	jb	0x15f32 <generic_fentry_path+0xba72>
   1404d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14053:      	ja	0x15f32 <generic_fentry_path+0xba72>
   14059:      	cmpl	%r15d, %r12d
   1405c:      	jbe	0x14062 <generic_fentry_path+0x9ba2>
   1405e:      	movb	$0x2f, (%rbx,%rax)
   14062:      	xorl	%edi, %edi
   14064:      	cmpl	%r15d, %r12d
   14067:      	seta	%dil
   1406b:      	movzbl	%cl, %esi
   1406e:      	addq	%rax, %rbx
   14071:      	addq	%rbx, %rdi
   14074:      	movl	$0x4, %eax
   14079:      	callq	*%rax
   1407b:      	movq	%rbx, 0x48(%rsp)
   14080:      	cmpl	%r15d, %r12d
   14083:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   14089:      	movq	0x8(%rsp), %r12
   1408e:      	movq	%r12, 0x30(%rsp)
   14093:      	movq	0x38(%rsp), %rdx
   14098:      	movq	0x40(%rsp), %r15
   1409d:      	jmp	0x140f0 <generic_fentry_path+0x9c30>
   1409f:      	leaq	0x10(%r15), %rdx
   140a3:      	movl	$0x4, %eax
   140a8:      	movq	%rbp, %rdi
   140ab:      	movl	$0x8, %esi
   140b0:      	callq	*%rax
   140b2:      	movq	0x40(%rsp), %rax
   140b7:      	cmpq	(%rsp), %rax
   140bb:      	je	0x15f2d <generic_fentry_path+0xba6d>
   140c1:      	addq	$0x18, %r15
   140c5:      	movl	$0x4, %eax
   140ca:      	leaq	0x30(%rsp), %rdi
   140cf:      	movl	$0x8, %esi
   140d4:      	movq	%r15, %rdx
   140d7:      	callq	*%rax
   140d9:      	movq	(%rsp), %r15
   140dd:      	movq	%r15, 0x40(%rsp)
   140e2:      	leaq	0x20(%r15), %rdx
   140e6:      	movq	%rdx, 0x38(%rsp)
   140eb:      	movq	0x30(%rsp), %r12
   140f0:      	cmpq	0x18(%rsp), %r12
   140f5:      	jne	0x14102 <generic_fentry_path+0x9c42>
   140f7:      	cmpq	0x20(%rsp), %rdx
   140fc:      	je	0x15f2d <generic_fentry_path+0xba6d>
   14102:      	movl	$0x4, %eax
   14107:      	leaq	0x10(%rsp), %rdi
   1410c:      	movl	$0x8, %esi
   14111:      	callq	*%rax
   14113:      	cmpq	0x10(%rsp), %r12
   14118:      	je	0x14210 <generic_fentry_path+0x9d50>
   1411e:      	leaq	0x18(%r12), %rbx
   14123:      	movl	$0x4, %eax
   14128:      	movq	%rbp, %rdi
   1412b:      	movl	$0x8, %esi
   14130:      	movq	%rbx, %rdx
   14133:      	callq	*%rax
   14135:      	cmpq	%r12, (%rsp)
   14139:      	je	0x14210 <generic_fentry_path+0x9d50>
   1413f:      	movl	$0x4, %eax
   14144:      	leaq	0x8(%rsp), %rdi
   14149:      	movl	$0x8, %esi
   1414e:      	movq	%rbx, %rdx
   14151:      	callq	*%rax
   14153:      	addq	$0x20, %r12
   14157:      	movl	$0x4, %eax
   1415c:      	leaq	0x58(%rsp), %rdi
   14161:      	movl	$0x10, %ecx
   14166:      	movl	$0x10, %esi
   1416b:      	movq	%r12, %rdx
   1416e:      	callq	*%rax
   14170:      	movq	0x28(%rsp), %rbx
   14175:      	movq	0x48(%rsp), %rax
   1417a:      	movl	0x5c(%rsp), %r15d
   1417f:      	subq	%rbx, %rax
   14182:      	movl	0x50(%rsp), %r12d
   14187:      	movl	%r15d, %edx
   1418a:      	subl	%r12d, %edx
   1418d:      	movl	$0x0, %ecx
   14192:      	cmovbl	%ecx, %edx
   14195:      	addq	0x60(%rsp), %rdx
   1419a:      	xorl	%esi, %esi
   1419c:      	cmpl	%r15d, %r12d
   1419f:      	seta	%sil
   141a3:      	movl	%r15d, %ecx
   141a6:      	cmovbl	%r12d, %ecx
   141aa:      	addl	%ecx, %esi
   141ac:      	movl	%r12d, %edi
   141af:      	subl	%esi, %edi
   141b1:      	movl	%edi, 0x50(%rsp)
   141b5:      	subq	%rsi, %rax
   141b8:      	jb	0x15f32 <generic_fentry_path+0xba72>
   141be:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   141c4:      	ja	0x15f32 <generic_fentry_path+0xba72>
   141ca:      	cmpl	%r15d, %r12d
   141cd:      	jbe	0x141d3 <generic_fentry_path+0x9d13>
   141cf:      	movb	$0x2f, (%rbx,%rax)
   141d3:      	xorl	%edi, %edi
   141d5:      	cmpl	%r15d, %r12d
   141d8:      	seta	%dil
   141dc:      	movzbl	%cl, %esi
   141df:      	addq	%rax, %rbx
   141e2:      	addq	%rbx, %rdi
   141e5:      	movl	$0x4, %eax
   141ea:      	callq	*%rax
   141ec:      	movq	%rbx, 0x48(%rsp)
   141f1:      	cmpl	%r15d, %r12d
   141f4:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   141fa:      	movq	0x8(%rsp), %r12
   141ff:      	movq	%r12, 0x30(%rsp)
   14204:      	movq	0x38(%rsp), %rdx
   14209:      	movq	0x40(%rsp), %r15
   1420e:      	jmp	0x14261 <generic_fentry_path+0x9da1>
   14210:      	leaq	0x10(%r15), %rdx
   14214:      	movl	$0x4, %eax
   14219:      	movq	%rbp, %rdi
   1421c:      	movl	$0x8, %esi
   14221:      	callq	*%rax
   14223:      	movq	0x40(%rsp), %rax
   14228:      	cmpq	(%rsp), %rax
   1422c:      	je	0x15f2d <generic_fentry_path+0xba6d>
   14232:      	addq	$0x18, %r15
   14236:      	movl	$0x4, %eax
   1423b:      	leaq	0x30(%rsp), %rdi
   14240:      	movl	$0x8, %esi
   14245:      	movq	%r15, %rdx
   14248:      	callq	*%rax
   1424a:      	movq	(%rsp), %r15
   1424e:      	movq	%r15, 0x40(%rsp)
   14253:      	leaq	0x20(%r15), %rdx
   14257:      	movq	%rdx, 0x38(%rsp)
   1425c:      	movq	0x30(%rsp), %r12
   14261:      	cmpq	0x18(%rsp), %r12
   14266:      	jne	0x14273 <generic_fentry_path+0x9db3>
   14268:      	cmpq	0x20(%rsp), %rdx
   1426d:      	je	0x15f2d <generic_fentry_path+0xba6d>
   14273:      	movl	$0x4, %eax
   14278:      	leaq	0x10(%rsp), %rdi
   1427d:      	movl	$0x8, %esi
   14282:      	callq	*%rax
   14284:      	cmpq	0x10(%rsp), %r12
   14289:      	je	0x14381 <generic_fentry_path+0x9ec1>
   1428f:      	leaq	0x18(%r12), %rbx
   14294:      	movl	$0x4, %eax
   14299:      	movq	%rbp, %rdi
   1429c:      	movl	$0x8, %esi
   142a1:      	movq	%rbx, %rdx
   142a4:      	callq	*%rax
   142a6:      	cmpq	%r12, (%rsp)
   142aa:      	je	0x14381 <generic_fentry_path+0x9ec1>
   142b0:      	movl	$0x4, %eax
   142b5:      	leaq	0x8(%rsp), %rdi
   142ba:      	movl	$0x8, %esi
   142bf:      	movq	%rbx, %rdx
   142c2:      	callq	*%rax
   142c4:      	addq	$0x20, %r12
   142c8:      	movl	$0x4, %eax
   142cd:      	leaq	0x58(%rsp), %rdi
   142d2:      	movl	$0x10, %ecx
   142d7:      	movl	$0x10, %esi
   142dc:      	movq	%r12, %rdx
   142df:      	callq	*%rax
   142e1:      	movq	0x28(%rsp), %rbx
   142e6:      	movq	0x48(%rsp), %rax
   142eb:      	movl	0x5c(%rsp), %r15d
   142f0:      	subq	%rbx, %rax
   142f3:      	movl	0x50(%rsp), %r12d
   142f8:      	movl	%r15d, %edx
   142fb:      	subl	%r12d, %edx
   142fe:      	movl	$0x0, %ecx
   14303:      	cmovbl	%ecx, %edx
   14306:      	addq	0x60(%rsp), %rdx
   1430b:      	xorl	%esi, %esi
   1430d:      	cmpl	%r15d, %r12d
   14310:      	seta	%sil
   14314:      	movl	%r15d, %ecx
   14317:      	cmovbl	%r12d, %ecx
   1431b:      	addl	%ecx, %esi
   1431d:      	movl	%r12d, %edi
   14320:      	subl	%esi, %edi
   14322:      	movl	%edi, 0x50(%rsp)
   14326:      	subq	%rsi, %rax
   14329:      	jb	0x15f32 <generic_fentry_path+0xba72>
   1432f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14335:      	ja	0x15f32 <generic_fentry_path+0xba72>
   1433b:      	cmpl	%r15d, %r12d
   1433e:      	jbe	0x14344 <generic_fentry_path+0x9e84>
   14340:      	movb	$0x2f, (%rbx,%rax)
   14344:      	xorl	%edi, %edi
   14346:      	cmpl	%r15d, %r12d
   14349:      	seta	%dil
   1434d:      	movzbl	%cl, %esi
   14350:      	addq	%rax, %rbx
   14353:      	addq	%rbx, %rdi
   14356:      	movl	$0x4, %eax
   1435b:      	callq	*%rax
   1435d:      	movq	%rbx, 0x48(%rsp)
   14362:      	cmpl	%r15d, %r12d
   14365:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   1436b:      	movq	0x8(%rsp), %r12
   14370:      	movq	%r12, 0x30(%rsp)
   14375:      	movq	0x38(%rsp), %rdx
   1437a:      	movq	0x40(%rsp), %r15
   1437f:      	jmp	0x143d2 <generic_fentry_path+0x9f12>
   14381:      	leaq	0x10(%r15), %rdx
   14385:      	movl	$0x4, %eax
   1438a:      	movq	%rbp, %rdi
   1438d:      	movl	$0x8, %esi
   14392:      	callq	*%rax
   14394:      	movq	0x40(%rsp), %rax
   14399:      	cmpq	(%rsp), %rax
   1439d:      	je	0x15f2d <generic_fentry_path+0xba6d>
   143a3:      	addq	$0x18, %r15
   143a7:      	movl	$0x4, %eax
   143ac:      	leaq	0x30(%rsp), %rdi
   143b1:      	movl	$0x8, %esi
   143b6:      	movq	%r15, %rdx
   143b9:      	callq	*%rax
   143bb:      	movq	(%rsp), %r15
   143bf:      	movq	%r15, 0x40(%rsp)
   143c4:      	leaq	0x20(%r15), %rdx
   143c8:      	movq	%rdx, 0x38(%rsp)
   143cd:      	movq	0x30(%rsp), %r12
   143d2:      	cmpq	0x18(%rsp), %r12
   143d7:      	jne	0x143e4 <generic_fentry_path+0x9f24>
   143d9:      	cmpq	0x20(%rsp), %rdx
   143de:      	je	0x15f2d <generic_fentry_path+0xba6d>
   143e4:      	movl	$0x4, %eax
   143e9:      	leaq	0x10(%rsp), %rdi
   143ee:      	movl	$0x8, %esi
   143f3:      	callq	*%rax
   143f5:      	cmpq	0x10(%rsp), %r12
   143fa:      	je	0x144f2 <generic_fentry_path+0xa032>
   14400:      	leaq	0x18(%r12), %rbx
   14405:      	movl	$0x4, %eax
   1440a:      	movq	%rbp, %rdi
   1440d:      	movl	$0x8, %esi
   14412:      	movq	%rbx, %rdx
   14415:      	callq	*%rax
   14417:      	cmpq	%r12, (%rsp)
   1441b:      	je	0x144f2 <generic_fentry_path+0xa032>
   14421:      	movl	$0x4, %eax
   14426:      	leaq	0x8(%rsp), %rdi
   1442b:      	movl	$0x8, %esi
   14430:      	movq	%rbx, %rdx
   14433:      	callq	*%rax
   14435:      	addq	$0x20, %r12
   14439:      	movl	$0x4, %eax
   1443e:      	leaq	0x58(%rsp), %rdi
   14443:      	movl	$0x10, %ecx
   14448:      	movl	$0x10, %esi
   1444d:      	movq	%r12, %rdx
   14450:      	callq	*%rax
   14452:      	movq	0x28(%rsp), %rbx
   14457:      	movq	0x48(%rsp), %rax
   1445c:      	movl	0x5c(%rsp), %r15d
   14461:      	subq	%rbx, %rax
   14464:      	movl	0x50(%rsp), %r12d
   14469:      	movl	%r15d, %edx
   1446c:      	subl	%r12d, %edx
   1446f:      	movl	$0x0, %ecx
   14474:      	cmovbl	%ecx, %edx
   14477:      	addq	0x60(%rsp), %rdx
   1447c:      	xorl	%esi, %esi
   1447e:      	cmpl	%r15d, %r12d
   14481:      	seta	%sil
   14485:      	movl	%r15d, %ecx
   14488:      	cmovbl	%r12d, %ecx
   1448c:      	addl	%ecx, %esi
   1448e:      	movl	%r12d, %edi
   14491:      	subl	%esi, %edi
   14493:      	movl	%edi, 0x50(%rsp)
   14497:      	subq	%rsi, %rax
   1449a:      	jb	0x15f32 <generic_fentry_path+0xba72>
   144a0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   144a6:      	ja	0x15f32 <generic_fentry_path+0xba72>
   144ac:      	cmpl	%r15d, %r12d
   144af:      	jbe	0x144b5 <generic_fentry_path+0x9ff5>
   144b1:      	movb	$0x2f, (%rbx,%rax)
   144b5:      	xorl	%edi, %edi
   144b7:      	cmpl	%r15d, %r12d
   144ba:      	seta	%dil
   144be:      	movzbl	%cl, %esi
   144c1:      	addq	%rax, %rbx
   144c4:      	addq	%rbx, %rdi
   144c7:      	movl	$0x4, %eax
   144cc:      	callq	*%rax
   144ce:      	movq	%rbx, 0x48(%rsp)
   144d3:      	cmpl	%r15d, %r12d
   144d6:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   144dc:      	movq	0x8(%rsp), %r12
   144e1:      	movq	%r12, 0x30(%rsp)
   144e6:      	movq	0x38(%rsp), %rdx
   144eb:      	movq	0x40(%rsp), %r15
   144f0:      	jmp	0x14543 <generic_fentry_path+0xa083>
   144f2:      	leaq	0x10(%r15), %rdx
   144f6:      	movl	$0x4, %eax
   144fb:      	movq	%rbp, %rdi
   144fe:      	movl	$0x8, %esi
   14503:      	callq	*%rax
   14505:      	movq	0x40(%rsp), %rax
   1450a:      	cmpq	(%rsp), %rax
   1450e:      	je	0x15f2d <generic_fentry_path+0xba6d>
   14514:      	addq	$0x18, %r15
   14518:      	movl	$0x4, %eax
   1451d:      	leaq	0x30(%rsp), %rdi
   14522:      	movl	$0x8, %esi
   14527:      	movq	%r15, %rdx
   1452a:      	callq	*%rax
   1452c:      	movq	(%rsp), %r15
   14530:      	movq	%r15, 0x40(%rsp)
   14535:      	leaq	0x20(%r15), %rdx
   14539:      	movq	%rdx, 0x38(%rsp)
   1453e:      	movq	0x30(%rsp), %r12
   14543:      	cmpq	0x18(%rsp), %r12
   14548:      	jne	0x14555 <generic_fentry_path+0xa095>
   1454a:      	cmpq	0x20(%rsp), %rdx
   1454f:      	je	0x15f2d <generic_fentry_path+0xba6d>
   14555:      	movl	$0x4, %eax
   1455a:      	leaq	0x10(%rsp), %rdi
   1455f:      	movl	$0x8, %esi
   14564:      	callq	*%rax
   14566:      	cmpq	0x10(%rsp), %r12
   1456b:      	je	0x14663 <generic_fentry_path+0xa1a3>
   14571:      	leaq	0x18(%r12), %rbx
   14576:      	movl	$0x4, %eax
   1457b:      	movq	%rbp, %rdi
   1457e:      	movl	$0x8, %esi
   14583:      	movq	%rbx, %rdx
   14586:      	callq	*%rax
   14588:      	cmpq	%r12, (%rsp)
   1458c:      	je	0x14663 <generic_fentry_path+0xa1a3>
   14592:      	movl	$0x4, %eax
   14597:      	leaq	0x8(%rsp), %rdi
   1459c:      	movl	$0x8, %esi
   145a1:      	movq	%rbx, %rdx
   145a4:      	callq	*%rax
   145a6:      	addq	$0x20, %r12
   145aa:      	movl	$0x4, %eax
   145af:      	leaq	0x58(%rsp), %rdi
   145b4:      	movl	$0x10, %ecx
   145b9:      	movl	$0x10, %esi
   145be:      	movq	%r12, %rdx
   145c1:      	callq	*%rax
   145c3:      	movq	0x28(%rsp), %rbx
   145c8:      	movq	0x48(%rsp), %rax
   145cd:      	movl	0x5c(%rsp), %r15d
   145d2:      	subq	%rbx, %rax
   145d5:      	movl	0x50(%rsp), %r12d
   145da:      	movl	%r15d, %edx
   145dd:      	subl	%r12d, %edx
   145e0:      	movl	$0x0, %ecx
   145e5:      	cmovbl	%ecx, %edx
   145e8:      	addq	0x60(%rsp), %rdx
   145ed:      	xorl	%esi, %esi
   145ef:      	cmpl	%r15d, %r12d
   145f2:      	seta	%sil
   145f6:      	movl	%r15d, %ecx
   145f9:      	cmovbl	%r12d, %ecx
   145fd:      	addl	%ecx, %esi
   145ff:      	movl	%r12d, %edi
   14602:      	subl	%esi, %edi
   14604:      	movl	%edi, 0x50(%rsp)
   14608:      	subq	%rsi, %rax
   1460b:      	jb	0x15f32 <generic_fentry_path+0xba72>
   14611:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14617:      	ja	0x15f32 <generic_fentry_path+0xba72>
   1461d:      	cmpl	%r15d, %r12d
   14620:      	jbe	0x14626 <generic_fentry_path+0xa166>
   14622:      	movb	$0x2f, (%rbx,%rax)
   14626:      	xorl	%edi, %edi
   14628:      	cmpl	%r15d, %r12d
   1462b:      	seta	%dil
   1462f:      	movzbl	%cl, %esi
   14632:      	addq	%rax, %rbx
   14635:      	addq	%rbx, %rdi
   14638:      	movl	$0x4, %eax
   1463d:      	callq	*%rax
   1463f:      	movq	%rbx, 0x48(%rsp)
   14644:      	cmpl	%r15d, %r12d
   14647:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   1464d:      	movq	0x8(%rsp), %r12
   14652:      	movq	%r12, 0x30(%rsp)
   14657:      	movq	0x38(%rsp), %rdx
   1465c:      	movq	0x40(%rsp), %r15
   14661:      	jmp	0x146b4 <generic_fentry_path+0xa1f4>
   14663:      	leaq	0x10(%r15), %rdx
   14667:      	movl	$0x4, %eax
   1466c:      	movq	%rbp, %rdi
   1466f:      	movl	$0x8, %esi
   14674:      	callq	*%rax
   14676:      	movq	0x40(%rsp), %rax
   1467b:      	cmpq	(%rsp), %rax
   1467f:      	je	0x15f2d <generic_fentry_path+0xba6d>
   14685:      	addq	$0x18, %r15
   14689:      	movl	$0x4, %eax
   1468e:      	leaq	0x30(%rsp), %rdi
   14693:      	movl	$0x8, %esi
   14698:      	movq	%r15, %rdx
   1469b:      	callq	*%rax
   1469d:      	movq	(%rsp), %r15
   146a1:      	movq	%r15, 0x40(%rsp)
   146a6:      	leaq	0x20(%r15), %rdx
   146aa:      	movq	%rdx, 0x38(%rsp)
   146af:      	movq	0x30(%rsp), %r12
   146b4:      	cmpq	0x18(%rsp), %r12
   146b9:      	jne	0x146c6 <generic_fentry_path+0xa206>
   146bb:      	cmpq	0x20(%rsp), %rdx
   146c0:      	je	0x15f2d <generic_fentry_path+0xba6d>
   146c6:      	movl	$0x4, %eax
   146cb:      	leaq	0x10(%rsp), %rdi
   146d0:      	movl	$0x8, %esi
   146d5:      	callq	*%rax
   146d7:      	cmpq	0x10(%rsp), %r12
   146dc:      	je	0x147d4 <generic_fentry_path+0xa314>
   146e2:      	leaq	0x18(%r12), %rbx
   146e7:      	movl	$0x4, %eax
   146ec:      	movq	%rbp, %rdi
   146ef:      	movl	$0x8, %esi
   146f4:      	movq	%rbx, %rdx
   146f7:      	callq	*%rax
   146f9:      	cmpq	%r12, (%rsp)
   146fd:      	je	0x147d4 <generic_fentry_path+0xa314>
   14703:      	movl	$0x4, %eax
   14708:      	leaq	0x8(%rsp), %rdi
   1470d:      	movl	$0x8, %esi
   14712:      	movq	%rbx, %rdx
   14715:      	callq	*%rax
   14717:      	addq	$0x20, %r12
   1471b:      	movl	$0x4, %eax
   14720:      	leaq	0x58(%rsp), %rdi
   14725:      	movl	$0x10, %ecx
   1472a:      	movl	$0x10, %esi
   1472f:      	movq	%r12, %rdx
   14732:      	callq	*%rax
   14734:      	movq	0x28(%rsp), %rbx
   14739:      	movq	0x48(%rsp), %rax
   1473e:      	movl	0x5c(%rsp), %r15d
   14743:      	subq	%rbx, %rax
   14746:      	movl	0x50(%rsp), %r12d
   1474b:      	movl	%r15d, %edx
   1474e:      	subl	%r12d, %edx
   14751:      	movl	$0x0, %ecx
   14756:      	cmovbl	%ecx, %edx
   14759:      	addq	0x60(%rsp), %rdx
   1475e:      	xorl	%esi, %esi
   14760:      	cmpl	%r15d, %r12d
   14763:      	seta	%sil
   14767:      	movl	%r15d, %ecx
   1476a:      	cmovbl	%r12d, %ecx
   1476e:      	addl	%ecx, %esi
   14770:      	movl	%r12d, %edi
   14773:      	subl	%esi, %edi
   14775:      	movl	%edi, 0x50(%rsp)
   14779:      	subq	%rsi, %rax
   1477c:      	jb	0x15f32 <generic_fentry_path+0xba72>
   14782:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14788:      	ja	0x15f32 <generic_fentry_path+0xba72>
   1478e:      	cmpl	%r15d, %r12d
   14791:      	jbe	0x14797 <generic_fentry_path+0xa2d7>
   14793:      	movb	$0x2f, (%rbx,%rax)
   14797:      	xorl	%edi, %edi
   14799:      	cmpl	%r15d, %r12d
   1479c:      	seta	%dil
   147a0:      	movzbl	%cl, %esi
   147a3:      	addq	%rax, %rbx
   147a6:      	addq	%rbx, %rdi
   147a9:      	movl	$0x4, %eax
   147ae:      	callq	*%rax
   147b0:      	movq	%rbx, 0x48(%rsp)
   147b5:      	cmpl	%r15d, %r12d
   147b8:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   147be:      	movq	0x8(%rsp), %r12
   147c3:      	movq	%r12, 0x30(%rsp)
   147c8:      	movq	0x38(%rsp), %rdx
   147cd:      	movq	0x40(%rsp), %r15
   147d2:      	jmp	0x14825 <generic_fentry_path+0xa365>
   147d4:      	leaq	0x10(%r15), %rdx
   147d8:      	movl	$0x4, %eax
   147dd:      	movq	%rbp, %rdi
   147e0:      	movl	$0x8, %esi
   147e5:      	callq	*%rax
   147e7:      	movq	0x40(%rsp), %rax
   147ec:      	cmpq	(%rsp), %rax
   147f0:      	je	0x15f2d <generic_fentry_path+0xba6d>
   147f6:      	addq	$0x18, %r15
   147fa:      	movl	$0x4, %eax
   147ff:      	leaq	0x30(%rsp), %rdi
   14804:      	movl	$0x8, %esi
   14809:      	movq	%r15, %rdx
   1480c:      	callq	*%rax
   1480e:      	movq	(%rsp), %r15
   14812:      	movq	%r15, 0x40(%rsp)
   14817:      	leaq	0x20(%r15), %rdx
   1481b:      	movq	%rdx, 0x38(%rsp)
   14820:      	movq	0x30(%rsp), %r12
   14825:      	cmpq	0x18(%rsp), %r12
   1482a:      	jne	0x14837 <generic_fentry_path+0xa377>
   1482c:      	cmpq	0x20(%rsp), %rdx
   14831:      	je	0x15f2d <generic_fentry_path+0xba6d>
   14837:      	movl	$0x4, %eax
   1483c:      	leaq	0x10(%rsp), %rdi
   14841:      	movl	$0x8, %esi
   14846:      	callq	*%rax
   14848:      	cmpq	0x10(%rsp), %r12
   1484d:      	je	0x14945 <generic_fentry_path+0xa485>
   14853:      	leaq	0x18(%r12), %rbx
   14858:      	movl	$0x4, %eax
   1485d:      	movq	%rbp, %rdi
   14860:      	movl	$0x8, %esi
   14865:      	movq	%rbx, %rdx
   14868:      	callq	*%rax
   1486a:      	cmpq	%r12, (%rsp)
   1486e:      	je	0x14945 <generic_fentry_path+0xa485>
   14874:      	movl	$0x4, %eax
   14879:      	leaq	0x8(%rsp), %rdi
   1487e:      	movl	$0x8, %esi
   14883:      	movq	%rbx, %rdx
   14886:      	callq	*%rax
   14888:      	addq	$0x20, %r12
   1488c:      	movl	$0x4, %eax
   14891:      	leaq	0x58(%rsp), %rdi
   14896:      	movl	$0x10, %ecx
   1489b:      	movl	$0x10, %esi
   148a0:      	movq	%r12, %rdx
   148a3:      	callq	*%rax
   148a5:      	movq	0x28(%rsp), %rbx
   148aa:      	movq	0x48(%rsp), %rax
   148af:      	movl	0x5c(%rsp), %r15d
   148b4:      	subq	%rbx, %rax
   148b7:      	movl	0x50(%rsp), %r12d
   148bc:      	movl	%r15d, %edx
   148bf:      	subl	%r12d, %edx
   148c2:      	movl	$0x0, %ecx
   148c7:      	cmovbl	%ecx, %edx
   148ca:      	addq	0x60(%rsp), %rdx
   148cf:      	xorl	%esi, %esi
   148d1:      	cmpl	%r15d, %r12d
   148d4:      	seta	%sil
   148d8:      	movl	%r15d, %ecx
   148db:      	cmovbl	%r12d, %ecx
   148df:      	addl	%ecx, %esi
   148e1:      	movl	%r12d, %edi
   148e4:      	subl	%esi, %edi
   148e6:      	movl	%edi, 0x50(%rsp)
   148ea:      	subq	%rsi, %rax
   148ed:      	jb	0x15f32 <generic_fentry_path+0xba72>
   148f3:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   148f9:      	ja	0x15f32 <generic_fentry_path+0xba72>
   148ff:      	cmpl	%r15d, %r12d
   14902:      	jbe	0x14908 <generic_fentry_path+0xa448>
   14904:      	movb	$0x2f, (%rbx,%rax)
   14908:      	xorl	%edi, %edi
   1490a:      	cmpl	%r15d, %r12d
   1490d:      	seta	%dil
   14911:      	movzbl	%cl, %esi
   14914:      	addq	%rax, %rbx
   14917:      	addq	%rbx, %rdi
   1491a:      	movl	$0x4, %eax
   1491f:      	callq	*%rax
   14921:      	movq	%rbx, 0x48(%rsp)
   14926:      	cmpl	%r15d, %r12d
   14929:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   1492f:      	movq	0x8(%rsp), %r12
   14934:      	movq	%r12, 0x30(%rsp)
   14939:      	movq	0x38(%rsp), %rdx
   1493e:      	movq	0x40(%rsp), %r15
   14943:      	jmp	0x14996 <generic_fentry_path+0xa4d6>
   14945:      	leaq	0x10(%r15), %rdx
   14949:      	movl	$0x4, %eax
   1494e:      	movq	%rbp, %rdi
   14951:      	movl	$0x8, %esi
   14956:      	callq	*%rax
   14958:      	movq	0x40(%rsp), %rax
   1495d:      	cmpq	(%rsp), %rax
   14961:      	je	0x15f2d <generic_fentry_path+0xba6d>
   14967:      	addq	$0x18, %r15
   1496b:      	movl	$0x4, %eax
   14970:      	leaq	0x30(%rsp), %rdi
   14975:      	movl	$0x8, %esi
   1497a:      	movq	%r15, %rdx
   1497d:      	callq	*%rax
   1497f:      	movq	(%rsp), %r15
   14983:      	movq	%r15, 0x40(%rsp)
   14988:      	leaq	0x20(%r15), %rdx
   1498c:      	movq	%rdx, 0x38(%rsp)
   14991:      	movq	0x30(%rsp), %r12
   14996:      	cmpq	0x18(%rsp), %r12
   1499b:      	jne	0x149a8 <generic_fentry_path+0xa4e8>
   1499d:      	cmpq	0x20(%rsp), %rdx
   149a2:      	je	0x15f2d <generic_fentry_path+0xba6d>
   149a8:      	movl	$0x4, %eax
   149ad:      	leaq	0x10(%rsp), %rdi
   149b2:      	movl	$0x8, %esi
   149b7:      	callq	*%rax
   149b9:      	cmpq	0x10(%rsp), %r12
   149be:      	je	0x14ab6 <generic_fentry_path+0xa5f6>
   149c4:      	leaq	0x18(%r12), %rbx
   149c9:      	movl	$0x4, %eax
   149ce:      	movq	%rbp, %rdi
   149d1:      	movl	$0x8, %esi
   149d6:      	movq	%rbx, %rdx
   149d9:      	callq	*%rax
   149db:      	cmpq	%r12, (%rsp)
   149df:      	je	0x14ab6 <generic_fentry_path+0xa5f6>
   149e5:      	movl	$0x4, %eax
   149ea:      	leaq	0x8(%rsp), %rdi
   149ef:      	movl	$0x8, %esi
   149f4:      	movq	%rbx, %rdx
   149f7:      	callq	*%rax
   149f9:      	addq	$0x20, %r12
   149fd:      	movl	$0x4, %eax
   14a02:      	leaq	0x58(%rsp), %rdi
   14a07:      	movl	$0x10, %ecx
   14a0c:      	movl	$0x10, %esi
   14a11:      	movq	%r12, %rdx
   14a14:      	callq	*%rax
   14a16:      	movq	0x28(%rsp), %rbx
   14a1b:      	movq	0x48(%rsp), %rax
   14a20:      	movl	0x5c(%rsp), %r15d
   14a25:      	subq	%rbx, %rax
   14a28:      	movl	0x50(%rsp), %r12d
   14a2d:      	movl	%r15d, %edx
   14a30:      	subl	%r12d, %edx
   14a33:      	movl	$0x0, %ecx
   14a38:      	cmovbl	%ecx, %edx
   14a3b:      	addq	0x60(%rsp), %rdx
   14a40:      	xorl	%esi, %esi
   14a42:      	cmpl	%r15d, %r12d
   14a45:      	seta	%sil
   14a49:      	movl	%r15d, %ecx
   14a4c:      	cmovbl	%r12d, %ecx
   14a50:      	addl	%ecx, %esi
   14a52:      	movl	%r12d, %edi
   14a55:      	subl	%esi, %edi
   14a57:      	movl	%edi, 0x50(%rsp)
   14a5b:      	subq	%rsi, %rax
   14a5e:      	jb	0x15f32 <generic_fentry_path+0xba72>
   14a64:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14a6a:      	ja	0x15f32 <generic_fentry_path+0xba72>
   14a70:      	cmpl	%r15d, %r12d
   14a73:      	jbe	0x14a79 <generic_fentry_path+0xa5b9>
   14a75:      	movb	$0x2f, (%rbx,%rax)
   14a79:      	xorl	%edi, %edi
   14a7b:      	cmpl	%r15d, %r12d
   14a7e:      	seta	%dil
   14a82:      	movzbl	%cl, %esi
   14a85:      	addq	%rax, %rbx
   14a88:      	addq	%rbx, %rdi
   14a8b:      	movl	$0x4, %eax
   14a90:      	callq	*%rax
   14a92:      	movq	%rbx, 0x48(%rsp)
   14a97:      	cmpl	%r15d, %r12d
   14a9a:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   14aa0:      	movq	0x8(%rsp), %r12
   14aa5:      	movq	%r12, 0x30(%rsp)
   14aaa:      	movq	0x38(%rsp), %rdx
   14aaf:      	movq	0x40(%rsp), %r15
   14ab4:      	jmp	0x14b07 <generic_fentry_path+0xa647>
   14ab6:      	leaq	0x10(%r15), %rdx
   14aba:      	movl	$0x4, %eax
   14abf:      	movq	%rbp, %rdi
   14ac2:      	movl	$0x8, %esi
   14ac7:      	callq	*%rax
   14ac9:      	movq	0x40(%rsp), %rax
   14ace:      	cmpq	(%rsp), %rax
   14ad2:      	je	0x15f2d <generic_fentry_path+0xba6d>
   14ad8:      	addq	$0x18, %r15
   14adc:      	movl	$0x4, %eax
   14ae1:      	leaq	0x30(%rsp), %rdi
   14ae6:      	movl	$0x8, %esi
   14aeb:      	movq	%r15, %rdx
   14aee:      	callq	*%rax
   14af0:      	movq	(%rsp), %r15
   14af4:      	movq	%r15, 0x40(%rsp)
   14af9:      	leaq	0x20(%r15), %rdx
   14afd:      	movq	%rdx, 0x38(%rsp)
   14b02:      	movq	0x30(%rsp), %r12
   14b07:      	cmpq	0x18(%rsp), %r12
   14b0c:      	jne	0x14b19 <generic_fentry_path+0xa659>
   14b0e:      	cmpq	0x20(%rsp), %rdx
   14b13:      	je	0x15f2d <generic_fentry_path+0xba6d>
   14b19:      	movl	$0x4, %eax
   14b1e:      	leaq	0x10(%rsp), %rdi
   14b23:      	movl	$0x8, %esi
   14b28:      	callq	*%rax
   14b2a:      	cmpq	0x10(%rsp), %r12
   14b2f:      	je	0x14c27 <generic_fentry_path+0xa767>
   14b35:      	leaq	0x18(%r12), %rbx
   14b3a:      	movl	$0x4, %eax
   14b3f:      	movq	%rbp, %rdi
   14b42:      	movl	$0x8, %esi
   14b47:      	movq	%rbx, %rdx
   14b4a:      	callq	*%rax
   14b4c:      	cmpq	%r12, (%rsp)
   14b50:      	je	0x14c27 <generic_fentry_path+0xa767>
   14b56:      	movl	$0x4, %eax
   14b5b:      	leaq	0x8(%rsp), %rdi
   14b60:      	movl	$0x8, %esi
   14b65:      	movq	%rbx, %rdx
   14b68:      	callq	*%rax
   14b6a:      	addq	$0x20, %r12
   14b6e:      	movl	$0x4, %eax
   14b73:      	leaq	0x58(%rsp), %rdi
   14b78:      	movl	$0x10, %ecx
   14b7d:      	movl	$0x10, %esi
   14b82:      	movq	%r12, %rdx
   14b85:      	callq	*%rax
   14b87:      	movq	0x28(%rsp), %rbx
   14b8c:      	movq	0x48(%rsp), %rax
   14b91:      	movl	0x5c(%rsp), %r15d
   14b96:      	subq	%rbx, %rax
   14b99:      	movl	0x50(%rsp), %r12d
   14b9e:      	movl	%r15d, %edx
   14ba1:      	subl	%r12d, %edx
   14ba4:      	movl	$0x0, %ecx
   14ba9:      	cmovbl	%ecx, %edx
   14bac:      	addq	0x60(%rsp), %rdx
   14bb1:      	xorl	%esi, %esi
   14bb3:      	cmpl	%r15d, %r12d
   14bb6:      	seta	%sil
   14bba:      	movl	%r15d, %ecx
   14bbd:      	cmovbl	%r12d, %ecx
   14bc1:      	addl	%ecx, %esi
   14bc3:      	movl	%r12d, %edi
   14bc6:      	subl	%esi, %edi
   14bc8:      	movl	%edi, 0x50(%rsp)
   14bcc:      	subq	%rsi, %rax
   14bcf:      	jb	0x15f32 <generic_fentry_path+0xba72>
   14bd5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14bdb:      	ja	0x15f32 <generic_fentry_path+0xba72>
   14be1:      	cmpl	%r15d, %r12d
   14be4:      	jbe	0x14bea <generic_fentry_path+0xa72a>
   14be6:      	movb	$0x2f, (%rbx,%rax)
   14bea:      	xorl	%edi, %edi
   14bec:      	cmpl	%r15d, %r12d
   14bef:      	seta	%dil
   14bf3:      	movzbl	%cl, %esi
   14bf6:      	addq	%rax, %rbx
   14bf9:      	addq	%rbx, %rdi
   14bfc:      	movl	$0x4, %eax
   14c01:      	callq	*%rax
   14c03:      	movq	%rbx, 0x48(%rsp)
   14c08:      	cmpl	%r15d, %r12d
   14c0b:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   14c11:      	movq	0x8(%rsp), %r12
   14c16:      	movq	%r12, 0x30(%rsp)
   14c1b:      	movq	0x38(%rsp), %rdx
   14c20:      	movq	0x40(%rsp), %r15
   14c25:      	jmp	0x14c78 <generic_fentry_path+0xa7b8>
   14c27:      	leaq	0x10(%r15), %rdx
   14c2b:      	movl	$0x4, %eax
   14c30:      	movq	%rbp, %rdi
   14c33:      	movl	$0x8, %esi
   14c38:      	callq	*%rax
   14c3a:      	movq	0x40(%rsp), %rax
   14c3f:      	cmpq	(%rsp), %rax
   14c43:      	je	0x15f2d <generic_fentry_path+0xba6d>
   14c49:      	addq	$0x18, %r15
   14c4d:      	movl	$0x4, %eax
   14c52:      	leaq	0x30(%rsp), %rdi
   14c57:      	movl	$0x8, %esi
   14c5c:      	movq	%r15, %rdx
   14c5f:      	callq	*%rax
   14c61:      	movq	(%rsp), %r15
   14c65:      	movq	%r15, 0x40(%rsp)
   14c6a:      	leaq	0x20(%r15), %rdx
   14c6e:      	movq	%rdx, 0x38(%rsp)
   14c73:      	movq	0x30(%rsp), %r12
   14c78:      	cmpq	0x18(%rsp), %r12
   14c7d:      	jne	0x14c8a <generic_fentry_path+0xa7ca>
   14c7f:      	cmpq	0x20(%rsp), %rdx
   14c84:      	je	0x15f2d <generic_fentry_path+0xba6d>
   14c8a:      	movl	$0x4, %eax
   14c8f:      	leaq	0x10(%rsp), %rdi
   14c94:      	movl	$0x8, %esi
   14c99:      	callq	*%rax
   14c9b:      	cmpq	0x10(%rsp), %r12
   14ca0:      	je	0x14d98 <generic_fentry_path+0xa8d8>
   14ca6:      	leaq	0x18(%r12), %rbx
   14cab:      	movl	$0x4, %eax
   14cb0:      	movq	%rbp, %rdi
   14cb3:      	movl	$0x8, %esi
   14cb8:      	movq	%rbx, %rdx
   14cbb:      	callq	*%rax
   14cbd:      	cmpq	%r12, (%rsp)
   14cc1:      	je	0x14d98 <generic_fentry_path+0xa8d8>
   14cc7:      	movl	$0x4, %eax
   14ccc:      	leaq	0x8(%rsp), %rdi
   14cd1:      	movl	$0x8, %esi
   14cd6:      	movq	%rbx, %rdx
   14cd9:      	callq	*%rax
   14cdb:      	addq	$0x20, %r12
   14cdf:      	movl	$0x4, %eax
   14ce4:      	leaq	0x58(%rsp), %rdi
   14ce9:      	movl	$0x10, %ecx
   14cee:      	movl	$0x10, %esi
   14cf3:      	movq	%r12, %rdx
   14cf6:      	callq	*%rax
   14cf8:      	movq	0x28(%rsp), %rbx
   14cfd:      	movq	0x48(%rsp), %rax
   14d02:      	movl	0x5c(%rsp), %r15d
   14d07:      	subq	%rbx, %rax
   14d0a:      	movl	0x50(%rsp), %r12d
   14d0f:      	movl	%r15d, %edx
   14d12:      	subl	%r12d, %edx
   14d15:      	movl	$0x0, %ecx
   14d1a:      	cmovbl	%ecx, %edx
   14d1d:      	addq	0x60(%rsp), %rdx
   14d22:      	xorl	%esi, %esi
   14d24:      	cmpl	%r15d, %r12d
   14d27:      	seta	%sil
   14d2b:      	movl	%r15d, %ecx
   14d2e:      	cmovbl	%r12d, %ecx
   14d32:      	addl	%ecx, %esi
   14d34:      	movl	%r12d, %edi
   14d37:      	subl	%esi, %edi
   14d39:      	movl	%edi, 0x50(%rsp)
   14d3d:      	subq	%rsi, %rax
   14d40:      	jb	0x15f32 <generic_fentry_path+0xba72>
   14d46:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14d4c:      	ja	0x15f32 <generic_fentry_path+0xba72>
   14d52:      	cmpl	%r15d, %r12d
   14d55:      	jbe	0x14d5b <generic_fentry_path+0xa89b>
   14d57:      	movb	$0x2f, (%rbx,%rax)
   14d5b:      	xorl	%edi, %edi
   14d5d:      	cmpl	%r15d, %r12d
   14d60:      	seta	%dil
   14d64:      	movzbl	%cl, %esi
   14d67:      	addq	%rax, %rbx
   14d6a:      	addq	%rbx, %rdi
   14d6d:      	movl	$0x4, %eax
   14d72:      	callq	*%rax
   14d74:      	movq	%rbx, 0x48(%rsp)
   14d79:      	cmpl	%r15d, %r12d
   14d7c:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   14d82:      	movq	0x8(%rsp), %r12
   14d87:      	movq	%r12, 0x30(%rsp)
   14d8c:      	movq	0x38(%rsp), %rdx
   14d91:      	movq	0x40(%rsp), %r15
   14d96:      	jmp	0x14de9 <generic_fentry_path+0xa929>
   14d98:      	leaq	0x10(%r15), %rdx
   14d9c:      	movl	$0x4, %eax
   14da1:      	movq	%rbp, %rdi
   14da4:      	movl	$0x8, %esi
   14da9:      	callq	*%rax
   14dab:      	movq	0x40(%rsp), %rax
   14db0:      	cmpq	(%rsp), %rax
   14db4:      	je	0x15f2d <generic_fentry_path+0xba6d>
   14dba:      	addq	$0x18, %r15
   14dbe:      	movl	$0x4, %eax
   14dc3:      	leaq	0x30(%rsp), %rdi
   14dc8:      	movl	$0x8, %esi
   14dcd:      	movq	%r15, %rdx
   14dd0:      	callq	*%rax
   14dd2:      	movq	(%rsp), %r15
   14dd6:      	movq	%r15, 0x40(%rsp)
   14ddb:      	leaq	0x20(%r15), %rdx
   14ddf:      	movq	%rdx, 0x38(%rsp)
   14de4:      	movq	0x30(%rsp), %r12
   14de9:      	cmpq	0x18(%rsp), %r12
   14dee:      	jne	0x14dfb <generic_fentry_path+0xa93b>
   14df0:      	cmpq	0x20(%rsp), %rdx
   14df5:      	je	0x15f2d <generic_fentry_path+0xba6d>
   14dfb:      	movl	$0x4, %eax
   14e00:      	leaq	0x10(%rsp), %rdi
   14e05:      	movl	$0x8, %esi
   14e0a:      	callq	*%rax
   14e0c:      	cmpq	0x10(%rsp), %r12
   14e11:      	je	0x14f09 <generic_fentry_path+0xaa49>
   14e17:      	leaq	0x18(%r12), %rbx
   14e1c:      	movl	$0x4, %eax
   14e21:      	movq	%rbp, %rdi
   14e24:      	movl	$0x8, %esi
   14e29:      	movq	%rbx, %rdx
   14e2c:      	callq	*%rax
   14e2e:      	cmpq	%r12, (%rsp)
   14e32:      	je	0x14f09 <generic_fentry_path+0xaa49>
   14e38:      	movl	$0x4, %eax
   14e3d:      	leaq	0x8(%rsp), %rdi
   14e42:      	movl	$0x8, %esi
   14e47:      	movq	%rbx, %rdx
   14e4a:      	callq	*%rax
   14e4c:      	addq	$0x20, %r12
   14e50:      	movl	$0x4, %eax
   14e55:      	leaq	0x58(%rsp), %rdi
   14e5a:      	movl	$0x10, %ecx
   14e5f:      	movl	$0x10, %esi
   14e64:      	movq	%r12, %rdx
   14e67:      	callq	*%rax
   14e69:      	movq	0x28(%rsp), %rbx
   14e6e:      	movq	0x48(%rsp), %rax
   14e73:      	movl	0x5c(%rsp), %r15d
   14e78:      	subq	%rbx, %rax
   14e7b:      	movl	0x50(%rsp), %r12d
   14e80:      	movl	%r15d, %edx
   14e83:      	subl	%r12d, %edx
   14e86:      	movl	$0x0, %ecx
   14e8b:      	cmovbl	%ecx, %edx
   14e8e:      	addq	0x60(%rsp), %rdx
   14e93:      	xorl	%esi, %esi
   14e95:      	cmpl	%r15d, %r12d
   14e98:      	seta	%sil
   14e9c:      	movl	%r15d, %ecx
   14e9f:      	cmovbl	%r12d, %ecx
   14ea3:      	addl	%ecx, %esi
   14ea5:      	movl	%r12d, %edi
   14ea8:      	subl	%esi, %edi
   14eaa:      	movl	%edi, 0x50(%rsp)
   14eae:      	subq	%rsi, %rax
   14eb1:      	jb	0x15f32 <generic_fentry_path+0xba72>
   14eb7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14ebd:      	ja	0x15f32 <generic_fentry_path+0xba72>
   14ec3:      	cmpl	%r15d, %r12d
   14ec6:      	jbe	0x14ecc <generic_fentry_path+0xaa0c>
   14ec8:      	movb	$0x2f, (%rbx,%rax)
   14ecc:      	xorl	%edi, %edi
   14ece:      	cmpl	%r15d, %r12d
   14ed1:      	seta	%dil
   14ed5:      	movzbl	%cl, %esi
   14ed8:      	addq	%rax, %rbx
   14edb:      	addq	%rbx, %rdi
   14ede:      	movl	$0x4, %eax
   14ee3:      	callq	*%rax
   14ee5:      	movq	%rbx, 0x48(%rsp)
   14eea:      	cmpl	%r15d, %r12d
   14eed:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   14ef3:      	movq	0x8(%rsp), %r12
   14ef8:      	movq	%r12, 0x30(%rsp)
   14efd:      	movq	0x38(%rsp), %rdx
   14f02:      	movq	0x40(%rsp), %r15
   14f07:      	jmp	0x14f5a <generic_fentry_path+0xaa9a>
   14f09:      	leaq	0x10(%r15), %rdx
   14f0d:      	movl	$0x4, %eax
   14f12:      	movq	%rbp, %rdi
   14f15:      	movl	$0x8, %esi
   14f1a:      	callq	*%rax
   14f1c:      	movq	0x40(%rsp), %rax
   14f21:      	cmpq	(%rsp), %rax
   14f25:      	je	0x15f2d <generic_fentry_path+0xba6d>
   14f2b:      	addq	$0x18, %r15
   14f2f:      	movl	$0x4, %eax
   14f34:      	leaq	0x30(%rsp), %rdi
   14f39:      	movl	$0x8, %esi
   14f3e:      	movq	%r15, %rdx
   14f41:      	callq	*%rax
   14f43:      	movq	(%rsp), %r15
   14f47:      	movq	%r15, 0x40(%rsp)
   14f4c:      	leaq	0x20(%r15), %rdx
   14f50:      	movq	%rdx, 0x38(%rsp)
   14f55:      	movq	0x30(%rsp), %r12
   14f5a:      	cmpq	0x18(%rsp), %r12
   14f5f:      	jne	0x14f6c <generic_fentry_path+0xaaac>
   14f61:      	cmpq	0x20(%rsp), %rdx
   14f66:      	je	0x15f2d <generic_fentry_path+0xba6d>
   14f6c:      	movl	$0x4, %eax
   14f71:      	leaq	0x10(%rsp), %rdi
   14f76:      	movl	$0x8, %esi
   14f7b:      	callq	*%rax
   14f7d:      	cmpq	0x10(%rsp), %r12
   14f82:      	je	0x1507a <generic_fentry_path+0xabba>
   14f88:      	leaq	0x18(%r12), %rbx
   14f8d:      	movl	$0x4, %eax
   14f92:      	movq	%rbp, %rdi
   14f95:      	movl	$0x8, %esi
   14f9a:      	movq	%rbx, %rdx
   14f9d:      	callq	*%rax
   14f9f:      	cmpq	%r12, (%rsp)
   14fa3:      	je	0x1507a <generic_fentry_path+0xabba>
   14fa9:      	movl	$0x4, %eax
   14fae:      	leaq	0x8(%rsp), %rdi
   14fb3:      	movl	$0x8, %esi
   14fb8:      	movq	%rbx, %rdx
   14fbb:      	callq	*%rax
   14fbd:      	addq	$0x20, %r12
   14fc1:      	movl	$0x4, %eax
   14fc6:      	leaq	0x58(%rsp), %rdi
   14fcb:      	movl	$0x10, %ecx
   14fd0:      	movl	$0x10, %esi
   14fd5:      	movq	%r12, %rdx
   14fd8:      	callq	*%rax
   14fda:      	movq	0x28(%rsp), %rbx
   14fdf:      	movq	0x48(%rsp), %rax
   14fe4:      	movl	0x5c(%rsp), %r15d
   14fe9:      	subq	%rbx, %rax
   14fec:      	movl	0x50(%rsp), %r12d
   14ff1:      	movl	%r15d, %edx
   14ff4:      	subl	%r12d, %edx
   14ff7:      	movl	$0x0, %ecx
   14ffc:      	cmovbl	%ecx, %edx
   14fff:      	addq	0x60(%rsp), %rdx
   15004:      	xorl	%esi, %esi
   15006:      	cmpl	%r15d, %r12d
   15009:      	seta	%sil
   1500d:      	movl	%r15d, %ecx
   15010:      	cmovbl	%r12d, %ecx
   15014:      	addl	%ecx, %esi
   15016:      	movl	%r12d, %edi
   15019:      	subl	%esi, %edi
   1501b:      	movl	%edi, 0x50(%rsp)
   1501f:      	subq	%rsi, %rax
   15022:      	jb	0x15f32 <generic_fentry_path+0xba72>
   15028:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1502e:      	ja	0x15f32 <generic_fentry_path+0xba72>
   15034:      	cmpl	%r15d, %r12d
   15037:      	jbe	0x1503d <generic_fentry_path+0xab7d>
   15039:      	movb	$0x2f, (%rbx,%rax)
   1503d:      	xorl	%edi, %edi
   1503f:      	cmpl	%r15d, %r12d
   15042:      	seta	%dil
   15046:      	movzbl	%cl, %esi
   15049:      	addq	%rax, %rbx
   1504c:      	addq	%rbx, %rdi
   1504f:      	movl	$0x4, %eax
   15054:      	callq	*%rax
   15056:      	movq	%rbx, 0x48(%rsp)
   1505b:      	cmpl	%r15d, %r12d
   1505e:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   15064:      	movq	0x8(%rsp), %r12
   15069:      	movq	%r12, 0x30(%rsp)
   1506e:      	movq	0x38(%rsp), %rdx
   15073:      	movq	0x40(%rsp), %r15
   15078:      	jmp	0x150cb <generic_fentry_path+0xac0b>
   1507a:      	leaq	0x10(%r15), %rdx
   1507e:      	movl	$0x4, %eax
   15083:      	movq	%rbp, %rdi
   15086:      	movl	$0x8, %esi
   1508b:      	callq	*%rax
   1508d:      	movq	0x40(%rsp), %rax
   15092:      	cmpq	(%rsp), %rax
   15096:      	je	0x15f2d <generic_fentry_path+0xba6d>
   1509c:      	addq	$0x18, %r15
   150a0:      	movl	$0x4, %eax
   150a5:      	leaq	0x30(%rsp), %rdi
   150aa:      	movl	$0x8, %esi
   150af:      	movq	%r15, %rdx
   150b2:      	callq	*%rax
   150b4:      	movq	(%rsp), %r15
   150b8:      	movq	%r15, 0x40(%rsp)
   150bd:      	leaq	0x20(%r15), %rdx
   150c1:      	movq	%rdx, 0x38(%rsp)
   150c6:      	movq	0x30(%rsp), %r12
   150cb:      	cmpq	0x18(%rsp), %r12
   150d0:      	jne	0x150dd <generic_fentry_path+0xac1d>
   150d2:      	cmpq	0x20(%rsp), %rdx
   150d7:      	je	0x15f2d <generic_fentry_path+0xba6d>
   150dd:      	movl	$0x4, %eax
   150e2:      	leaq	0x10(%rsp), %rdi
   150e7:      	movl	$0x8, %esi
   150ec:      	callq	*%rax
   150ee:      	cmpq	0x10(%rsp), %r12
   150f3:      	je	0x151eb <generic_fentry_path+0xad2b>
   150f9:      	leaq	0x18(%r12), %rbx
   150fe:      	movl	$0x4, %eax
   15103:      	movq	%rbp, %rdi
   15106:      	movl	$0x8, %esi
   1510b:      	movq	%rbx, %rdx
   1510e:      	callq	*%rax
   15110:      	cmpq	%r12, (%rsp)
   15114:      	je	0x151eb <generic_fentry_path+0xad2b>
   1511a:      	movl	$0x4, %eax
   1511f:      	leaq	0x8(%rsp), %rdi
   15124:      	movl	$0x8, %esi
   15129:      	movq	%rbx, %rdx
   1512c:      	callq	*%rax
   1512e:      	addq	$0x20, %r12
   15132:      	movl	$0x4, %eax
   15137:      	leaq	0x58(%rsp), %rdi
   1513c:      	movl	$0x10, %ecx
   15141:      	movl	$0x10, %esi
   15146:      	movq	%r12, %rdx
   15149:      	callq	*%rax
   1514b:      	movq	0x28(%rsp), %rbx
   15150:      	movq	0x48(%rsp), %rax
   15155:      	movl	0x5c(%rsp), %r15d
   1515a:      	subq	%rbx, %rax
   1515d:      	movl	0x50(%rsp), %r12d
   15162:      	movl	%r15d, %edx
   15165:      	subl	%r12d, %edx
   15168:      	movl	$0x0, %ecx
   1516d:      	cmovbl	%ecx, %edx
   15170:      	addq	0x60(%rsp), %rdx
   15175:      	xorl	%esi, %esi
   15177:      	cmpl	%r15d, %r12d
   1517a:      	seta	%sil
   1517e:      	movl	%r15d, %ecx
   15181:      	cmovbl	%r12d, %ecx
   15185:      	addl	%ecx, %esi
   15187:      	movl	%r12d, %edi
   1518a:      	subl	%esi, %edi
   1518c:      	movl	%edi, 0x50(%rsp)
   15190:      	subq	%rsi, %rax
   15193:      	jb	0x15f32 <generic_fentry_path+0xba72>
   15199:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1519f:      	ja	0x15f32 <generic_fentry_path+0xba72>
   151a5:      	cmpl	%r15d, %r12d
   151a8:      	jbe	0x151ae <generic_fentry_path+0xacee>
   151aa:      	movb	$0x2f, (%rbx,%rax)
   151ae:      	xorl	%edi, %edi
   151b0:      	cmpl	%r15d, %r12d
   151b3:      	seta	%dil
   151b7:      	movzbl	%cl, %esi
   151ba:      	addq	%rax, %rbx
   151bd:      	addq	%rbx, %rdi
   151c0:      	movl	$0x4, %eax
   151c5:      	callq	*%rax
   151c7:      	movq	%rbx, 0x48(%rsp)
   151cc:      	cmpl	%r15d, %r12d
   151cf:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   151d5:      	movq	0x8(%rsp), %r12
   151da:      	movq	%r12, 0x30(%rsp)
   151df:      	movq	0x38(%rsp), %rdx
   151e4:      	movq	0x40(%rsp), %r15
   151e9:      	jmp	0x1523c <generic_fentry_path+0xad7c>
   151eb:      	leaq	0x10(%r15), %rdx
   151ef:      	movl	$0x4, %eax
   151f4:      	movq	%rbp, %rdi
   151f7:      	movl	$0x8, %esi
   151fc:      	callq	*%rax
   151fe:      	movq	0x40(%rsp), %rax
   15203:      	cmpq	(%rsp), %rax
   15207:      	je	0x15f2d <generic_fentry_path+0xba6d>
   1520d:      	addq	$0x18, %r15
   15211:      	movl	$0x4, %eax
   15216:      	leaq	0x30(%rsp), %rdi
   1521b:      	movl	$0x8, %esi
   15220:      	movq	%r15, %rdx
   15223:      	callq	*%rax
   15225:      	movq	(%rsp), %r15
   15229:      	movq	%r15, 0x40(%rsp)
   1522e:      	leaq	0x20(%r15), %rdx
   15232:      	movq	%rdx, 0x38(%rsp)
   15237:      	movq	0x30(%rsp), %r12
   1523c:      	cmpq	0x18(%rsp), %r12
   15241:      	jne	0x1524e <generic_fentry_path+0xad8e>
   15243:      	cmpq	0x20(%rsp), %rdx
   15248:      	je	0x15f2d <generic_fentry_path+0xba6d>
   1524e:      	movl	$0x4, %eax
   15253:      	leaq	0x10(%rsp), %rdi
   15258:      	movl	$0x8, %esi
   1525d:      	callq	*%rax
   1525f:      	cmpq	0x10(%rsp), %r12
   15264:      	je	0x1535c <generic_fentry_path+0xae9c>
   1526a:      	leaq	0x18(%r12), %rbx
   1526f:      	movl	$0x4, %eax
   15274:      	movq	%rbp, %rdi
   15277:      	movl	$0x8, %esi
   1527c:      	movq	%rbx, %rdx
   1527f:      	callq	*%rax
   15281:      	cmpq	%r12, (%rsp)
   15285:      	je	0x1535c <generic_fentry_path+0xae9c>
   1528b:      	movl	$0x4, %eax
   15290:      	leaq	0x8(%rsp), %rdi
   15295:      	movl	$0x8, %esi
   1529a:      	movq	%rbx, %rdx
   1529d:      	callq	*%rax
   1529f:      	addq	$0x20, %r12
   152a3:      	movl	$0x4, %eax
   152a8:      	leaq	0x58(%rsp), %rdi
   152ad:      	movl	$0x10, %ecx
   152b2:      	movl	$0x10, %esi
   152b7:      	movq	%r12, %rdx
   152ba:      	callq	*%rax
   152bc:      	movq	0x28(%rsp), %rbx
   152c1:      	movq	0x48(%rsp), %rax
   152c6:      	movl	0x5c(%rsp), %r15d
   152cb:      	subq	%rbx, %rax
   152ce:      	movl	0x50(%rsp), %r12d
   152d3:      	movl	%r15d, %edx
   152d6:      	subl	%r12d, %edx
   152d9:      	movl	$0x0, %ecx
   152de:      	cmovbl	%ecx, %edx
   152e1:      	addq	0x60(%rsp), %rdx
   152e6:      	xorl	%esi, %esi
   152e8:      	cmpl	%r15d, %r12d
   152eb:      	seta	%sil
   152ef:      	movl	%r15d, %ecx
   152f2:      	cmovbl	%r12d, %ecx
   152f6:      	addl	%ecx, %esi
   152f8:      	movl	%r12d, %edi
   152fb:      	subl	%esi, %edi
   152fd:      	movl	%edi, 0x50(%rsp)
   15301:      	subq	%rsi, %rax
   15304:      	jb	0x15f32 <generic_fentry_path+0xba72>
   1530a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15310:      	ja	0x15f32 <generic_fentry_path+0xba72>
   15316:      	cmpl	%r15d, %r12d
   15319:      	jbe	0x1531f <generic_fentry_path+0xae5f>
   1531b:      	movb	$0x2f, (%rbx,%rax)
   1531f:      	xorl	%edi, %edi
   15321:      	cmpl	%r15d, %r12d
   15324:      	seta	%dil
   15328:      	movzbl	%cl, %esi
   1532b:      	addq	%rax, %rbx
   1532e:      	addq	%rbx, %rdi
   15331:      	movl	$0x4, %eax
   15336:      	callq	*%rax
   15338:      	movq	%rbx, 0x48(%rsp)
   1533d:      	cmpl	%r15d, %r12d
   15340:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   15346:      	movq	0x8(%rsp), %r12
   1534b:      	movq	%r12, 0x30(%rsp)
   15350:      	movq	0x38(%rsp), %rdx
   15355:      	movq	0x40(%rsp), %r15
   1535a:      	jmp	0x153ad <generic_fentry_path+0xaeed>
   1535c:      	leaq	0x10(%r15), %rdx
   15360:      	movl	$0x4, %eax
   15365:      	movq	%rbp, %rdi
   15368:      	movl	$0x8, %esi
   1536d:      	callq	*%rax
   1536f:      	movq	0x40(%rsp), %rax
   15374:      	cmpq	(%rsp), %rax
   15378:      	je	0x15f2d <generic_fentry_path+0xba6d>
   1537e:      	addq	$0x18, %r15
   15382:      	movl	$0x4, %eax
   15387:      	leaq	0x30(%rsp), %rdi
   1538c:      	movl	$0x8, %esi
   15391:      	movq	%r15, %rdx
   15394:      	callq	*%rax
   15396:      	movq	(%rsp), %r15
   1539a:      	movq	%r15, 0x40(%rsp)
   1539f:      	leaq	0x20(%r15), %rdx
   153a3:      	movq	%rdx, 0x38(%rsp)
   153a8:      	movq	0x30(%rsp), %r12
   153ad:      	cmpq	0x18(%rsp), %r12
   153b2:      	jne	0x153bf <generic_fentry_path+0xaeff>
   153b4:      	cmpq	0x20(%rsp), %rdx
   153b9:      	je	0x15f2d <generic_fentry_path+0xba6d>
   153bf:      	movl	$0x4, %eax
   153c4:      	leaq	0x10(%rsp), %rdi
   153c9:      	movl	$0x8, %esi
   153ce:      	callq	*%rax
   153d0:      	cmpq	0x10(%rsp), %r12
   153d5:      	je	0x154cd <generic_fentry_path+0xb00d>
   153db:      	leaq	0x18(%r12), %rbx
   153e0:      	movl	$0x4, %eax
   153e5:      	movq	%rbp, %rdi
   153e8:      	movl	$0x8, %esi
   153ed:      	movq	%rbx, %rdx
   153f0:      	callq	*%rax
   153f2:      	cmpq	%r12, (%rsp)
   153f6:      	je	0x154cd <generic_fentry_path+0xb00d>
   153fc:      	movl	$0x4, %eax
   15401:      	leaq	0x8(%rsp), %rdi
   15406:      	movl	$0x8, %esi
   1540b:      	movq	%rbx, %rdx
   1540e:      	callq	*%rax
   15410:      	addq	$0x20, %r12
   15414:      	movl	$0x4, %eax
   15419:      	leaq	0x58(%rsp), %rdi
   1541e:      	movl	$0x10, %ecx
   15423:      	movl	$0x10, %esi
   15428:      	movq	%r12, %rdx
   1542b:      	callq	*%rax
   1542d:      	movq	0x28(%rsp), %rbx
   15432:      	movq	0x48(%rsp), %rax
   15437:      	movl	0x5c(%rsp), %r15d
   1543c:      	subq	%rbx, %rax
   1543f:      	movl	0x50(%rsp), %r12d
   15444:      	movl	%r15d, %edx
   15447:      	subl	%r12d, %edx
   1544a:      	movl	$0x0, %ecx
   1544f:      	cmovbl	%ecx, %edx
   15452:      	addq	0x60(%rsp), %rdx
   15457:      	xorl	%esi, %esi
   15459:      	cmpl	%r15d, %r12d
   1545c:      	seta	%sil
   15460:      	movl	%r15d, %ecx
   15463:      	cmovbl	%r12d, %ecx
   15467:      	addl	%ecx, %esi
   15469:      	movl	%r12d, %edi
   1546c:      	subl	%esi, %edi
   1546e:      	movl	%edi, 0x50(%rsp)
   15472:      	subq	%rsi, %rax
   15475:      	jb	0x15f32 <generic_fentry_path+0xba72>
   1547b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15481:      	ja	0x15f32 <generic_fentry_path+0xba72>
   15487:      	cmpl	%r15d, %r12d
   1548a:      	jbe	0x15490 <generic_fentry_path+0xafd0>
   1548c:      	movb	$0x2f, (%rbx,%rax)
   15490:      	xorl	%edi, %edi
   15492:      	cmpl	%r15d, %r12d
   15495:      	seta	%dil
   15499:      	movzbl	%cl, %esi
   1549c:      	addq	%rax, %rbx
   1549f:      	addq	%rbx, %rdi
   154a2:      	movl	$0x4, %eax
   154a7:      	callq	*%rax
   154a9:      	movq	%rbx, 0x48(%rsp)
   154ae:      	cmpl	%r15d, %r12d
   154b1:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   154b7:      	movq	0x8(%rsp), %r12
   154bc:      	movq	%r12, 0x30(%rsp)
   154c1:      	movq	0x38(%rsp), %rdx
   154c6:      	movq	0x40(%rsp), %r15
   154cb:      	jmp	0x1551e <generic_fentry_path+0xb05e>
   154cd:      	leaq	0x10(%r15), %rdx
   154d1:      	movl	$0x4, %eax
   154d6:      	movq	%rbp, %rdi
   154d9:      	movl	$0x8, %esi
   154de:      	callq	*%rax
   154e0:      	movq	0x40(%rsp), %rax
   154e5:      	cmpq	(%rsp), %rax
   154e9:      	je	0x15f2d <generic_fentry_path+0xba6d>
   154ef:      	addq	$0x18, %r15
   154f3:      	movl	$0x4, %eax
   154f8:      	leaq	0x30(%rsp), %rdi
   154fd:      	movl	$0x8, %esi
   15502:      	movq	%r15, %rdx
   15505:      	callq	*%rax
   15507:      	movq	(%rsp), %r15
   1550b:      	movq	%r15, 0x40(%rsp)
   15510:      	leaq	0x20(%r15), %rdx
   15514:      	movq	%rdx, 0x38(%rsp)
   15519:      	movq	0x30(%rsp), %r12
   1551e:      	cmpq	0x18(%rsp), %r12
   15523:      	jne	0x15530 <generic_fentry_path+0xb070>
   15525:      	cmpq	0x20(%rsp), %rdx
   1552a:      	je	0x15f2d <generic_fentry_path+0xba6d>
   15530:      	movl	$0x4, %eax
   15535:      	leaq	0x10(%rsp), %rdi
   1553a:      	movl	$0x8, %esi
   1553f:      	callq	*%rax
   15541:      	cmpq	0x10(%rsp), %r12
   15546:      	je	0x1563e <generic_fentry_path+0xb17e>
   1554c:      	leaq	0x18(%r12), %rbx
   15551:      	movl	$0x4, %eax
   15556:      	movq	%rbp, %rdi
   15559:      	movl	$0x8, %esi
   1555e:      	movq	%rbx, %rdx
   15561:      	callq	*%rax
   15563:      	cmpq	%r12, (%rsp)
   15567:      	je	0x1563e <generic_fentry_path+0xb17e>
   1556d:      	movl	$0x4, %eax
   15572:      	leaq	0x8(%rsp), %rdi
   15577:      	movl	$0x8, %esi
   1557c:      	movq	%rbx, %rdx
   1557f:      	callq	*%rax
   15581:      	addq	$0x20, %r12
   15585:      	movl	$0x4, %eax
   1558a:      	leaq	0x58(%rsp), %rdi
   1558f:      	movl	$0x10, %ecx
   15594:      	movl	$0x10, %esi
   15599:      	movq	%r12, %rdx
   1559c:      	callq	*%rax
   1559e:      	movq	0x28(%rsp), %rbx
   155a3:      	movq	0x48(%rsp), %rax
   155a8:      	movl	0x5c(%rsp), %r15d
   155ad:      	subq	%rbx, %rax
   155b0:      	movl	0x50(%rsp), %r12d
   155b5:      	movl	%r15d, %edx
   155b8:      	subl	%r12d, %edx
   155bb:      	movl	$0x0, %ecx
   155c0:      	cmovbl	%ecx, %edx
   155c3:      	addq	0x60(%rsp), %rdx
   155c8:      	xorl	%esi, %esi
   155ca:      	cmpl	%r15d, %r12d
   155cd:      	seta	%sil
   155d1:      	movl	%r15d, %ecx
   155d4:      	cmovbl	%r12d, %ecx
   155d8:      	addl	%ecx, %esi
   155da:      	movl	%r12d, %edi
   155dd:      	subl	%esi, %edi
   155df:      	movl	%edi, 0x50(%rsp)
   155e3:      	subq	%rsi, %rax
   155e6:      	jb	0x15f32 <generic_fentry_path+0xba72>
   155ec:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   155f2:      	ja	0x15f32 <generic_fentry_path+0xba72>
   155f8:      	cmpl	%r15d, %r12d
   155fb:      	jbe	0x15601 <generic_fentry_path+0xb141>
   155fd:      	movb	$0x2f, (%rbx,%rax)
   15601:      	xorl	%edi, %edi
   15603:      	cmpl	%r15d, %r12d
   15606:      	seta	%dil
   1560a:      	movzbl	%cl, %esi
   1560d:      	addq	%rax, %rbx
   15610:      	addq	%rbx, %rdi
   15613:      	movl	$0x4, %eax
   15618:      	callq	*%rax
   1561a:      	movq	%rbx, 0x48(%rsp)
   1561f:      	cmpl	%r15d, %r12d
   15622:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   15628:      	movq	0x8(%rsp), %r12
   1562d:      	movq	%r12, 0x30(%rsp)
   15632:      	movq	0x38(%rsp), %rdx
   15637:      	movq	0x40(%rsp), %r15
   1563c:      	jmp	0x1568f <generic_fentry_path+0xb1cf>
   1563e:      	leaq	0x10(%r15), %rdx
   15642:      	movl	$0x4, %eax
   15647:      	movq	%rbp, %rdi
   1564a:      	movl	$0x8, %esi
   1564f:      	callq	*%rax
   15651:      	movq	0x40(%rsp), %rax
   15656:      	cmpq	(%rsp), %rax
   1565a:      	je	0x15f2d <generic_fentry_path+0xba6d>
   15660:      	addq	$0x18, %r15
   15664:      	movl	$0x4, %eax
   15669:      	leaq	0x30(%rsp), %rdi
   1566e:      	movl	$0x8, %esi
   15673:      	movq	%r15, %rdx
   15676:      	callq	*%rax
   15678:      	movq	(%rsp), %r15
   1567c:      	movq	%r15, 0x40(%rsp)
   15681:      	leaq	0x20(%r15), %rdx
   15685:      	movq	%rdx, 0x38(%rsp)
   1568a:      	movq	0x30(%rsp), %r12
   1568f:      	cmpq	0x18(%rsp), %r12
   15694:      	jne	0x156a1 <generic_fentry_path+0xb1e1>
   15696:      	cmpq	0x20(%rsp), %rdx
   1569b:      	je	0x15f2d <generic_fentry_path+0xba6d>
   156a1:      	movl	$0x4, %eax
   156a6:      	leaq	0x10(%rsp), %rdi
   156ab:      	movl	$0x8, %esi
   156b0:      	callq	*%rax
   156b2:      	cmpq	0x10(%rsp), %r12
   156b7:      	je	0x157af <generic_fentry_path+0xb2ef>
   156bd:      	leaq	0x18(%r12), %rbx
   156c2:      	movl	$0x4, %eax
   156c7:      	movq	%rbp, %rdi
   156ca:      	movl	$0x8, %esi
   156cf:      	movq	%rbx, %rdx
   156d2:      	callq	*%rax
   156d4:      	cmpq	%r12, (%rsp)
   156d8:      	je	0x157af <generic_fentry_path+0xb2ef>
   156de:      	movl	$0x4, %eax
   156e3:      	leaq	0x8(%rsp), %rdi
   156e8:      	movl	$0x8, %esi
   156ed:      	movq	%rbx, %rdx
   156f0:      	callq	*%rax
   156f2:      	addq	$0x20, %r12
   156f6:      	movl	$0x4, %eax
   156fb:      	leaq	0x58(%rsp), %rdi
   15700:      	movl	$0x10, %ecx
   15705:      	movl	$0x10, %esi
   1570a:      	movq	%r12, %rdx
   1570d:      	callq	*%rax
   1570f:      	movq	0x28(%rsp), %rbx
   15714:      	movq	0x48(%rsp), %rax
   15719:      	movl	0x5c(%rsp), %r15d
   1571e:      	subq	%rbx, %rax
   15721:      	movl	0x50(%rsp), %r12d
   15726:      	movl	%r15d, %edx
   15729:      	subl	%r12d, %edx
   1572c:      	movl	$0x0, %ecx
   15731:      	cmovbl	%ecx, %edx
   15734:      	addq	0x60(%rsp), %rdx
   15739:      	xorl	%esi, %esi
   1573b:      	cmpl	%r15d, %r12d
   1573e:      	seta	%sil
   15742:      	movl	%r15d, %ecx
   15745:      	cmovbl	%r12d, %ecx
   15749:      	addl	%ecx, %esi
   1574b:      	movl	%r12d, %edi
   1574e:      	subl	%esi, %edi
   15750:      	movl	%edi, 0x50(%rsp)
   15754:      	subq	%rsi, %rax
   15757:      	jb	0x15f32 <generic_fentry_path+0xba72>
   1575d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15763:      	ja	0x15f32 <generic_fentry_path+0xba72>
   15769:      	cmpl	%r15d, %r12d
   1576c:      	jbe	0x15772 <generic_fentry_path+0xb2b2>
   1576e:      	movb	$0x2f, (%rbx,%rax)
   15772:      	xorl	%edi, %edi
   15774:      	cmpl	%r15d, %r12d
   15777:      	seta	%dil
   1577b:      	movzbl	%cl, %esi
   1577e:      	addq	%rax, %rbx
   15781:      	addq	%rbx, %rdi
   15784:      	movl	$0x4, %eax
   15789:      	callq	*%rax
   1578b:      	movq	%rbx, 0x48(%rsp)
   15790:      	cmpl	%r15d, %r12d
   15793:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   15799:      	movq	0x8(%rsp), %r12
   1579e:      	movq	%r12, 0x30(%rsp)
   157a3:      	movq	0x38(%rsp), %rdx
   157a8:      	movq	0x40(%rsp), %r15
   157ad:      	jmp	0x15800 <generic_fentry_path+0xb340>
   157af:      	leaq	0x10(%r15), %rdx
   157b3:      	movl	$0x4, %eax
   157b8:      	movq	%rbp, %rdi
   157bb:      	movl	$0x8, %esi
   157c0:      	callq	*%rax
   157c2:      	movq	0x40(%rsp), %rax
   157c7:      	cmpq	(%rsp), %rax
   157cb:      	je	0x15f2d <generic_fentry_path+0xba6d>
   157d1:      	addq	$0x18, %r15
   157d5:      	movl	$0x4, %eax
   157da:      	leaq	0x30(%rsp), %rdi
   157df:      	movl	$0x8, %esi
   157e4:      	movq	%r15, %rdx
   157e7:      	callq	*%rax
   157e9:      	movq	(%rsp), %r15
   157ed:      	movq	%r15, 0x40(%rsp)
   157f2:      	leaq	0x20(%r15), %rdx
   157f6:      	movq	%rdx, 0x38(%rsp)
   157fb:      	movq	0x30(%rsp), %r12
   15800:      	cmpq	0x18(%rsp), %r12
   15805:      	jne	0x15812 <generic_fentry_path+0xb352>
   15807:      	cmpq	0x20(%rsp), %rdx
   1580c:      	je	0x15f2d <generic_fentry_path+0xba6d>
   15812:      	movl	$0x4, %eax
   15817:      	leaq	0x10(%rsp), %rdi
   1581c:      	movl	$0x8, %esi
   15821:      	callq	*%rax
   15823:      	cmpq	0x10(%rsp), %r12
   15828:      	je	0x15920 <generic_fentry_path+0xb460>
   1582e:      	leaq	0x18(%r12), %rbx
   15833:      	movl	$0x4, %eax
   15838:      	movq	%rbp, %rdi
   1583b:      	movl	$0x8, %esi
   15840:      	movq	%rbx, %rdx
   15843:      	callq	*%rax
   15845:      	cmpq	%r12, (%rsp)
   15849:      	je	0x15920 <generic_fentry_path+0xb460>
   1584f:      	movl	$0x4, %eax
   15854:      	leaq	0x8(%rsp), %rdi
   15859:      	movl	$0x8, %esi
   1585e:      	movq	%rbx, %rdx
   15861:      	callq	*%rax
   15863:      	addq	$0x20, %r12
   15867:      	movl	$0x4, %eax
   1586c:      	leaq	0x58(%rsp), %rdi
   15871:      	movl	$0x10, %ecx
   15876:      	movl	$0x10, %esi
   1587b:      	movq	%r12, %rdx
   1587e:      	callq	*%rax
   15880:      	movq	0x28(%rsp), %rbx
   15885:      	movq	0x48(%rsp), %rax
   1588a:      	movl	0x5c(%rsp), %r15d
   1588f:      	subq	%rbx, %rax
   15892:      	movl	0x50(%rsp), %r12d
   15897:      	movl	%r15d, %edx
   1589a:      	subl	%r12d, %edx
   1589d:      	movl	$0x0, %ecx
   158a2:      	cmovbl	%ecx, %edx
   158a5:      	addq	0x60(%rsp), %rdx
   158aa:      	xorl	%esi, %esi
   158ac:      	cmpl	%r15d, %r12d
   158af:      	seta	%sil
   158b3:      	movl	%r15d, %ecx
   158b6:      	cmovbl	%r12d, %ecx
   158ba:      	addl	%ecx, %esi
   158bc:      	movl	%r12d, %edi
   158bf:      	subl	%esi, %edi
   158c1:      	movl	%edi, 0x50(%rsp)
   158c5:      	subq	%rsi, %rax
   158c8:      	jb	0x15f32 <generic_fentry_path+0xba72>
   158ce:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   158d4:      	ja	0x15f32 <generic_fentry_path+0xba72>
   158da:      	cmpl	%r15d, %r12d
   158dd:      	jbe	0x158e3 <generic_fentry_path+0xb423>
   158df:      	movb	$0x2f, (%rbx,%rax)
   158e3:      	xorl	%edi, %edi
   158e5:      	cmpl	%r15d, %r12d
   158e8:      	seta	%dil
   158ec:      	movzbl	%cl, %esi
   158ef:      	addq	%rax, %rbx
   158f2:      	addq	%rbx, %rdi
   158f5:      	movl	$0x4, %eax
   158fa:      	callq	*%rax
   158fc:      	movq	%rbx, 0x48(%rsp)
   15901:      	cmpl	%r15d, %r12d
   15904:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   1590a:      	movq	0x8(%rsp), %r12
   1590f:      	movq	%r12, 0x30(%rsp)
   15914:      	movq	0x38(%rsp), %rdx
   15919:      	movq	0x40(%rsp), %r15
   1591e:      	jmp	0x15971 <generic_fentry_path+0xb4b1>
   15920:      	leaq	0x10(%r15), %rdx
   15924:      	movl	$0x4, %eax
   15929:      	movq	%rbp, %rdi
   1592c:      	movl	$0x8, %esi
   15931:      	callq	*%rax
   15933:      	movq	0x40(%rsp), %rax
   15938:      	cmpq	(%rsp), %rax
   1593c:      	je	0x15f2d <generic_fentry_path+0xba6d>
   15942:      	addq	$0x18, %r15
   15946:      	movl	$0x4, %eax
   1594b:      	leaq	0x30(%rsp), %rdi
   15950:      	movl	$0x8, %esi
   15955:      	movq	%r15, %rdx
   15958:      	callq	*%rax
   1595a:      	movq	(%rsp), %r15
   1595e:      	movq	%r15, 0x40(%rsp)
   15963:      	leaq	0x20(%r15), %rdx
   15967:      	movq	%rdx, 0x38(%rsp)
   1596c:      	movq	0x30(%rsp), %r12
   15971:      	cmpq	0x18(%rsp), %r12
   15976:      	jne	0x15983 <generic_fentry_path+0xb4c3>
   15978:      	cmpq	0x20(%rsp), %rdx
   1597d:      	je	0x15f2d <generic_fentry_path+0xba6d>
   15983:      	movl	$0x4, %eax
   15988:      	leaq	0x10(%rsp), %rdi
   1598d:      	movl	$0x8, %esi
   15992:      	callq	*%rax
   15994:      	cmpq	0x10(%rsp), %r12
   15999:      	je	0x15a91 <generic_fentry_path+0xb5d1>
   1599f:      	leaq	0x18(%r12), %rbx
   159a4:      	movl	$0x4, %eax
   159a9:      	movq	%rbp, %rdi
   159ac:      	movl	$0x8, %esi
   159b1:      	movq	%rbx, %rdx
   159b4:      	callq	*%rax
   159b6:      	cmpq	%r12, (%rsp)
   159ba:      	je	0x15a91 <generic_fentry_path+0xb5d1>
   159c0:      	movl	$0x4, %eax
   159c5:      	leaq	0x8(%rsp), %rdi
   159ca:      	movl	$0x8, %esi
   159cf:      	movq	%rbx, %rdx
   159d2:      	callq	*%rax
   159d4:      	addq	$0x20, %r12
   159d8:      	movl	$0x4, %eax
   159dd:      	leaq	0x58(%rsp), %rdi
   159e2:      	movl	$0x10, %ecx
   159e7:      	movl	$0x10, %esi
   159ec:      	movq	%r12, %rdx
   159ef:      	callq	*%rax
   159f1:      	movq	0x28(%rsp), %rbx
   159f6:      	movq	0x48(%rsp), %rax
   159fb:      	movl	0x5c(%rsp), %r15d
   15a00:      	subq	%rbx, %rax
   15a03:      	movl	0x50(%rsp), %r12d
   15a08:      	movl	%r15d, %edx
   15a0b:      	subl	%r12d, %edx
   15a0e:      	movl	$0x0, %ecx
   15a13:      	cmovbl	%ecx, %edx
   15a16:      	addq	0x60(%rsp), %rdx
   15a1b:      	xorl	%esi, %esi
   15a1d:      	cmpl	%r15d, %r12d
   15a20:      	seta	%sil
   15a24:      	movl	%r15d, %ecx
   15a27:      	cmovbl	%r12d, %ecx
   15a2b:      	addl	%ecx, %esi
   15a2d:      	movl	%r12d, %edi
   15a30:      	subl	%esi, %edi
   15a32:      	movl	%edi, 0x50(%rsp)
   15a36:      	subq	%rsi, %rax
   15a39:      	jb	0x15f32 <generic_fentry_path+0xba72>
   15a3f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15a45:      	ja	0x15f32 <generic_fentry_path+0xba72>
   15a4b:      	cmpl	%r15d, %r12d
   15a4e:      	jbe	0x15a54 <generic_fentry_path+0xb594>
   15a50:      	movb	$0x2f, (%rbx,%rax)
   15a54:      	xorl	%edi, %edi
   15a56:      	cmpl	%r15d, %r12d
   15a59:      	seta	%dil
   15a5d:      	movzbl	%cl, %esi
   15a60:      	addq	%rax, %rbx
   15a63:      	addq	%rbx, %rdi
   15a66:      	movl	$0x4, %eax
   15a6b:      	callq	*%rax
   15a6d:      	movq	%rbx, 0x48(%rsp)
   15a72:      	cmpl	%r15d, %r12d
   15a75:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   15a7b:      	movq	0x8(%rsp), %r12
   15a80:      	movq	%r12, 0x30(%rsp)
   15a85:      	movq	0x38(%rsp), %rdx
   15a8a:      	movq	0x40(%rsp), %r15
   15a8f:      	jmp	0x15ae2 <generic_fentry_path+0xb622>
   15a91:      	leaq	0x10(%r15), %rdx
   15a95:      	movl	$0x4, %eax
   15a9a:      	movq	%rbp, %rdi
   15a9d:      	movl	$0x8, %esi
   15aa2:      	callq	*%rax
   15aa4:      	movq	0x40(%rsp), %rax
   15aa9:      	cmpq	(%rsp), %rax
   15aad:      	je	0x15f2d <generic_fentry_path+0xba6d>
   15ab3:      	addq	$0x18, %r15
   15ab7:      	movl	$0x4, %eax
   15abc:      	leaq	0x30(%rsp), %rdi
   15ac1:      	movl	$0x8, %esi
   15ac6:      	movq	%r15, %rdx
   15ac9:      	callq	*%rax
   15acb:      	movq	(%rsp), %r15
   15acf:      	movq	%r15, 0x40(%rsp)
   15ad4:      	leaq	0x20(%r15), %rdx
   15ad8:      	movq	%rdx, 0x38(%rsp)
   15add:      	movq	0x30(%rsp), %r12
   15ae2:      	cmpq	0x18(%rsp), %r12
   15ae7:      	jne	0x15af4 <generic_fentry_path+0xb634>
   15ae9:      	cmpq	0x20(%rsp), %rdx
   15aee:      	je	0x15f2d <generic_fentry_path+0xba6d>
   15af4:      	movl	$0x4, %eax
   15af9:      	leaq	0x10(%rsp), %rdi
   15afe:      	movl	$0x8, %esi
   15b03:      	callq	*%rax
   15b05:      	cmpq	0x10(%rsp), %r12
   15b0a:      	je	0x15c02 <generic_fentry_path+0xb742>
   15b10:      	leaq	0x18(%r12), %rbx
   15b15:      	movl	$0x4, %eax
   15b1a:      	movq	%rbp, %rdi
   15b1d:      	movl	$0x8, %esi
   15b22:      	movq	%rbx, %rdx
   15b25:      	callq	*%rax
   15b27:      	cmpq	%r12, (%rsp)
   15b2b:      	je	0x15c02 <generic_fentry_path+0xb742>
   15b31:      	movl	$0x4, %eax
   15b36:      	leaq	0x8(%rsp), %rdi
   15b3b:      	movl	$0x8, %esi
   15b40:      	movq	%rbx, %rdx
   15b43:      	callq	*%rax
   15b45:      	addq	$0x20, %r12
   15b49:      	movl	$0x4, %eax
   15b4e:      	leaq	0x58(%rsp), %rdi
   15b53:      	movl	$0x10, %ecx
   15b58:      	movl	$0x10, %esi
   15b5d:      	movq	%r12, %rdx
   15b60:      	callq	*%rax
   15b62:      	movq	0x28(%rsp), %rbx
   15b67:      	movq	0x48(%rsp), %rax
   15b6c:      	movl	0x5c(%rsp), %r15d
   15b71:      	subq	%rbx, %rax
   15b74:      	movl	0x50(%rsp), %r12d
   15b79:      	movl	%r15d, %edx
   15b7c:      	subl	%r12d, %edx
   15b7f:      	movl	$0x0, %ecx
   15b84:      	cmovbl	%ecx, %edx
   15b87:      	addq	0x60(%rsp), %rdx
   15b8c:      	xorl	%esi, %esi
   15b8e:      	cmpl	%r15d, %r12d
   15b91:      	seta	%sil
   15b95:      	movl	%r15d, %ecx
   15b98:      	cmovbl	%r12d, %ecx
   15b9c:      	addl	%ecx, %esi
   15b9e:      	movl	%r12d, %edi
   15ba1:      	subl	%esi, %edi
   15ba3:      	movl	%edi, 0x50(%rsp)
   15ba7:      	subq	%rsi, %rax
   15baa:      	jb	0x15f32 <generic_fentry_path+0xba72>
   15bb0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15bb6:      	ja	0x15f32 <generic_fentry_path+0xba72>
   15bbc:      	cmpl	%r15d, %r12d
   15bbf:      	jbe	0x15bc5 <generic_fentry_path+0xb705>
   15bc1:      	movb	$0x2f, (%rbx,%rax)
   15bc5:      	xorl	%edi, %edi
   15bc7:      	cmpl	%r15d, %r12d
   15bca:      	seta	%dil
   15bce:      	movzbl	%cl, %esi
   15bd1:      	addq	%rax, %rbx
   15bd4:      	addq	%rbx, %rdi
   15bd7:      	movl	$0x4, %eax
   15bdc:      	callq	*%rax
   15bde:      	movq	%rbx, 0x48(%rsp)
   15be3:      	cmpl	%r15d, %r12d
   15be6:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   15bec:      	movq	0x8(%rsp), %r12
   15bf1:      	movq	%r12, 0x30(%rsp)
   15bf6:      	movq	0x38(%rsp), %rdx
   15bfb:      	movq	0x40(%rsp), %r15
   15c00:      	jmp	0x15c53 <generic_fentry_path+0xb793>
   15c02:      	leaq	0x10(%r15), %rdx
   15c06:      	movl	$0x4, %eax
   15c0b:      	movq	%rbp, %rdi
   15c0e:      	movl	$0x8, %esi
   15c13:      	callq	*%rax
   15c15:      	movq	0x40(%rsp), %rax
   15c1a:      	cmpq	(%rsp), %rax
   15c1e:      	je	0x15f2d <generic_fentry_path+0xba6d>
   15c24:      	addq	$0x18, %r15
   15c28:      	movl	$0x4, %eax
   15c2d:      	leaq	0x30(%rsp), %rdi
   15c32:      	movl	$0x8, %esi
   15c37:      	movq	%r15, %rdx
   15c3a:      	callq	*%rax
   15c3c:      	movq	(%rsp), %r15
   15c40:      	movq	%r15, 0x40(%rsp)
   15c45:      	leaq	0x20(%r15), %rdx
   15c49:      	movq	%rdx, 0x38(%rsp)
   15c4e:      	movq	0x30(%rsp), %r12
   15c53:      	cmpq	0x18(%rsp), %r12
   15c58:      	jne	0x15c65 <generic_fentry_path+0xb7a5>
   15c5a:      	cmpq	0x20(%rsp), %rdx
   15c5f:      	je	0x15f2d <generic_fentry_path+0xba6d>
   15c65:      	movl	$0x4, %eax
   15c6a:      	leaq	0x10(%rsp), %rdi
   15c6f:      	movl	$0x8, %esi
   15c74:      	callq	*%rax
   15c76:      	cmpq	0x10(%rsp), %r12
   15c7b:      	je	0x15d73 <generic_fentry_path+0xb8b3>
   15c81:      	leaq	0x18(%r12), %rbx
   15c86:      	movl	$0x4, %eax
   15c8b:      	movq	%rbp, %rdi
   15c8e:      	movl	$0x8, %esi
   15c93:      	movq	%rbx, %rdx
   15c96:      	callq	*%rax
   15c98:      	cmpq	%r12, (%rsp)
   15c9c:      	je	0x15d73 <generic_fentry_path+0xb8b3>
   15ca2:      	movl	$0x4, %eax
   15ca7:      	leaq	0x8(%rsp), %rdi
   15cac:      	movl	$0x8, %esi
   15cb1:      	movq	%rbx, %rdx
   15cb4:      	callq	*%rax
   15cb6:      	addq	$0x20, %r12
   15cba:      	movl	$0x4, %eax
   15cbf:      	leaq	0x58(%rsp), %rdi
   15cc4:      	movl	$0x10, %ecx
   15cc9:      	movl	$0x10, %esi
   15cce:      	movq	%r12, %rdx
   15cd1:      	callq	*%rax
   15cd3:      	movq	0x28(%rsp), %rbx
   15cd8:      	movq	0x48(%rsp), %rax
   15cdd:      	movl	0x5c(%rsp), %r15d
   15ce2:      	subq	%rbx, %rax
   15ce5:      	movl	0x50(%rsp), %r12d
   15cea:      	movl	%r15d, %edx
   15ced:      	subl	%r12d, %edx
   15cf0:      	movl	$0x0, %ecx
   15cf5:      	cmovbl	%ecx, %edx
   15cf8:      	addq	0x60(%rsp), %rdx
   15cfd:      	xorl	%esi, %esi
   15cff:      	cmpl	%r15d, %r12d
   15d02:      	seta	%sil
   15d06:      	movl	%r15d, %ecx
   15d09:      	cmovbl	%r12d, %ecx
   15d0d:      	addl	%ecx, %esi
   15d0f:      	movl	%r12d, %edi
   15d12:      	subl	%esi, %edi
   15d14:      	movl	%edi, 0x50(%rsp)
   15d18:      	subq	%rsi, %rax
   15d1b:      	jb	0x15f32 <generic_fentry_path+0xba72>
   15d21:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15d27:      	ja	0x15f32 <generic_fentry_path+0xba72>
   15d2d:      	cmpl	%r15d, %r12d
   15d30:      	jbe	0x15d36 <generic_fentry_path+0xb876>
   15d32:      	movb	$0x2f, (%rbx,%rax)
   15d36:      	xorl	%edi, %edi
   15d38:      	cmpl	%r15d, %r12d
   15d3b:      	seta	%dil
   15d3f:      	movzbl	%cl, %esi
   15d42:      	addq	%rax, %rbx
   15d45:      	addq	%rbx, %rdi
   15d48:      	movl	$0x4, %eax
   15d4d:      	callq	*%rax
   15d4f:      	movq	%rbx, 0x48(%rsp)
   15d54:      	cmpl	%r15d, %r12d
   15d57:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   15d5d:      	movq	0x8(%rsp), %r12
   15d62:      	movq	%r12, 0x30(%rsp)
   15d67:      	movq	0x38(%rsp), %rdx
   15d6c:      	movq	0x40(%rsp), %r15
   15d71:      	jmp	0x15dc4 <generic_fentry_path+0xb904>
   15d73:      	leaq	0x10(%r15), %rdx
   15d77:      	movl	$0x4, %eax
   15d7c:      	movq	%rbp, %rdi
   15d7f:      	movl	$0x8, %esi
   15d84:      	callq	*%rax
   15d86:      	movq	0x40(%rsp), %rax
   15d8b:      	cmpq	(%rsp), %rax
   15d8f:      	je	0x15f2d <generic_fentry_path+0xba6d>
   15d95:      	addq	$0x18, %r15
   15d99:      	movl	$0x4, %eax
   15d9e:      	leaq	0x30(%rsp), %rdi
   15da3:      	movl	$0x8, %esi
   15da8:      	movq	%r15, %rdx
   15dab:      	callq	*%rax
   15dad:      	movq	(%rsp), %r15
   15db1:      	movq	%r15, 0x40(%rsp)
   15db6:      	leaq	0x20(%r15), %rdx
   15dba:      	movq	%rdx, 0x38(%rsp)
   15dbf:      	movq	0x30(%rsp), %r12
   15dc4:      	cmpq	0x18(%rsp), %r12
   15dc9:      	jne	0x15dd6 <generic_fentry_path+0xb916>
   15dcb:      	cmpq	0x20(%rsp), %rdx
   15dd0:      	je	0x15f2d <generic_fentry_path+0xba6d>
   15dd6:      	movl	$0x4, %eax
   15ddb:      	leaq	0x10(%rsp), %rdi
   15de0:      	movl	$0x8, %esi
   15de5:      	callq	*%rax
   15de7:      	cmpq	0x10(%rsp), %r12
   15dec:      	je	0x15ed6 <generic_fentry_path+0xba16>
   15df2:      	leaq	0x18(%r12), %rbx
   15df7:      	movl	$0x4, %eax
   15dfc:      	movq	%rbp, %rdi
   15dff:      	movl	$0x8, %esi
   15e04:      	movq	%rbx, %rdx
   15e07:      	callq	*%rax
   15e09:      	cmpq	%r12, (%rsp)
   15e0d:      	je	0x15ed6 <generic_fentry_path+0xba16>
   15e13:      	movl	$0x4, %eax
   15e18:      	leaq	0x8(%rsp), %rdi
   15e1d:      	movl	$0x8, %esi
   15e22:      	movq	%rbx, %rdx
   15e25:      	callq	*%rax
   15e27:      	addq	$0x20, %r12
   15e2b:      	movl	$0x4, %eax
   15e30:      	leaq	0x58(%rsp), %rdi
   15e35:      	movl	$0x10, %ecx
   15e3a:      	movl	$0x10, %esi
   15e3f:      	movq	%r12, %rdx
   15e42:      	callq	*%rax
   15e44:      	movq	0x28(%rsp), %rbx
   15e49:      	movq	0x48(%rsp), %rax
   15e4e:      	movl	0x5c(%rsp), %r15d
   15e53:      	subq	%rbx, %rax
   15e56:      	movl	0x50(%rsp), %r12d
   15e5b:      	movl	%r15d, %edx
   15e5e:      	subl	%r12d, %edx
   15e61:      	movl	$0x0, %ecx
   15e66:      	cmovbl	%ecx, %edx
   15e69:      	addq	0x60(%rsp), %rdx
   15e6e:      	xorl	%esi, %esi
   15e70:      	cmpl	%r15d, %r12d
   15e73:      	seta	%sil
   15e77:      	movl	%r15d, %ecx
   15e7a:      	cmovbl	%r12d, %ecx
   15e7e:      	addl	%ecx, %esi
   15e80:      	movl	%r12d, %edi
   15e83:      	subl	%esi, %edi
   15e85:      	movl	%edi, 0x50(%rsp)
   15e89:      	subq	%rsi, %rax
   15e8c:      	jb	0x15f32 <generic_fentry_path+0xba72>
   15e92:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15e98:      	ja	0x15f32 <generic_fentry_path+0xba72>
   15e9e:      	cmpl	%r15d, %r12d
   15ea1:      	jbe	0x15ea7 <generic_fentry_path+0xb9e7>
   15ea3:      	movb	$0x2f, (%rbx,%rax)
   15ea7:      	xorl	%edi, %edi
   15ea9:      	cmpl	%r15d, %r12d
   15eac:      	seta	%dil
   15eb0:      	movzbl	%cl, %esi
   15eb3:      	addq	%rax, %rbx
   15eb6:      	addq	%rbx, %rdi
   15eb9:      	movl	$0x4, %eax
   15ebe:      	callq	*%rax
   15ec0:      	movq	%rbx, 0x48(%rsp)
   15ec5:      	cmpl	%r15d, %r12d
   15ec8:      	jbe	0x15f32 <generic_fentry_path+0xba72>
   15eca:      	movq	0x8(%rsp), %rax
   15ecf:      	movq	%rax, 0x30(%rsp)
   15ed4:      	jmp	0x15f1e <generic_fentry_path+0xba5e>
   15ed6:      	leaq	0x10(%r15), %rdx
   15eda:      	movl	$0x4, %eax
   15edf:      	movq	%rbp, %rdi
   15ee2:      	movl	$0x8, %esi
   15ee7:      	callq	*%rax
   15ee9:      	movq	0x40(%rsp), %rax
   15eee:      	cmpq	(%rsp), %rax
   15ef2:      	je	0x15f2d <generic_fentry_path+0xba6d>
   15ef4:      	addq	$0x18, %r15
   15ef8:      	movl	$0x4, %eax
   15efd:      	leaq	0x30(%rsp), %rdi
   15f02:      	movl	$0x8, %esi
   15f07:      	movq	%r15, %rdx
   15f0a:      	callq	*%rax
   15f0c:      	movq	(%rsp), %rax
   15f10:      	movq	%rax, 0x40(%rsp)
   15f15:      	addq	$0x20, %rax
   15f19:      	movq	%rax, 0x38(%rsp)
   15f1e:      	movl	0x6c(%rsp), %eax
   15f22:      	addl	$-0x80, %eax
   15f25:      	jne	0xa663 <generic_fentry_path+0x1a3>
   15f2b:      	jmp	0x15f32 <generic_fentry_path+0xba72>
   15f2d:      	movb	$0x1, 0x54(%rsp)
   15f32:      	movl	0x6428(%r14), %eax
   15f39:      	incl	%eax
   15f3b:      	movl	%eax, 0x6428(%r14)
   15f42:      	movl	0x48(%rsp), %ecx
   15f46:      	subl	0x80(%rsp), %ecx
   15f4d:      	movl	%ecx, 0x6424(%r14)
   15f54:      	cmpb	$0x0, 0x54(%rsp)
   15f59:      	jne	0x15fa1 <generic_fentry_path+0xbae1>
   15f5b:      	cmpl	$0x8, %eax
   15f5e:      	je	0x15fa1 <generic_fentry_path+0xbae1>
   15f60:      	movq	0x30(%rsp), %rax
   15f65:      	movq	%rax, 0x6458(%r14)
   15f6c:      	movq	0x38(%rsp), %rax
   15f71:      	movq	%rax, 0x6460(%r14)
   15f78:      	movq	0x40(%rsp), %rax
   15f7d:      	movq	%rax, 0x6468(%r14)
   15f84:      	movq	(%rip), %rcx            # 0x15f8b <generic_fentry_path+0xbacb>
   15f8b:      	movl	$0x6, %edx
   15f90:      	movl	$0xc, %eax
   15f95:      	movq	0x78(%rsp), %rdi
   15f9a:      	movl	$0x6, %edx
   15f9f:      	jmp	0x15fbc <generic_fentry_path+0xbafc>
   15fa1:      	movq	(%rip), %rcx            # 0x15fa8 <generic_fentry_path+0xbae8>
   15fa8:      	movl	$0x1, %edx
   15fad:      	movl	$0xc, %eax
   15fb2:      	movq	0x78(%rsp), %rdi
   15fb7:      	movl	$0x1, %edx
   15fbc:      	movq	(%rip), %rsi            # 0x15fc3 <generic_fentry_path+0xbb03>
   15fc3:      	jmp	0x16337 <generic_fentry_path+0xbe77>
   15fc8:      	movl	$0x1, (%rsp)
   15fcf:      	movq	(%rip), %rdi            # 0x15fd6 <generic_fentry_path+0xbb16>
   15fd6:      	xorl	%ecx, %ecx
   15fd8:      	leaq	0x18(%rsp), %rsi
   15fdd:      	movq	%rsp, %rdx
   15fe0:      	movl	$0x2, %eax
   15fe5:      	xorl	%ecx, %ecx
   15fe7:      	callq	*%rax
   15fe9:      	movq	0x58(%rsp), %r12
   15fee:      	leaq	0x10(%r12), %rdx
   15ff3:      	leaq	0x18(%rsp), %rdi
   15ff8:      	movl	$0x8, %ecx
   15ffd:      	movl	$0x4, %eax
   16002:      	leaq	0xfff(%r15), %rbx
   16009:      	movl	$0x8, %esi
   1600e:      	callq	*%rax
   16010:      	cmpq	$0x0, 0x18(%rsp)
   16016:      	jne	0x1605f <generic_fentry_path+0xbb9f>
   16018:      	leaq	0x18(%r12), %rdx
   1601d:      	leaq	0x18(%rsp), %rdi
   16022:      	movl	$0x8, %ecx
   16027:      	movl	$0x4, %eax
   1602c:      	movl	$0x8, %esi
   16031:      	callq	*%rax
   16033:      	cmpq	%r12, 0x18(%rsp)
   16038:      	je	0x1605f <generic_fentry_path+0xbb9f>
   1603a:      	movq	%r15, %rbx
   1603d:      	addq	$0xff5, %rbx            # imm = 0xFF5
   16044:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
   1604e:      	movq	%rax, 0xff5(%r15)
   16055:      	movw	$0x2964, 0xffd(%r15)    # imm = 0x2964
   1605f:      	movl	$0x23, %eax
   16064:      	callq	*%rax
   16066:      	leaq	0xd50(%rax), %rdx
   1606d:      	movq	%rsp, %rdi
   16070:      	movl	$0x8, %ecx
   16075:      	movl	$0x4, %eax
   1607a:      	movl	$0x8, %esi
   1607f:      	callq	*%rax
   16081:      	testq	%rax, %rax
   16084:      	je	0x160e3 <generic_fentry_path+0xbc23>
   16086:      	negl	%eax
   16088:      	movw	%ax, 0x18(%rsp)
   1608d:      	movw	$0x6, 0x1a(%rsp)
   16094:      	movabsq	$0x400000033, %rax      # imm = 0x400000033
   1609e:      	movq	%rax, 0x1c(%rsp)
   160a3:      	movq	(%rip), %rdi            # 0x160aa <generic_fentry_path+0xbbea>
   160aa:      	leaq	0x18(%rsp), %rsi
   160af:      	movl	$0x1, %eax
   160b4:      	callq	*%rax
   160b6:      	testq	%rax, %rax
   160b9:      	je	0x160bf <generic_fentry_path+0xbbff>
   160bb:      	incl	(%rax)
   160bd:      	jmp	0x160e3 <generic_fentry_path+0xbc23>
   160bf:      	movl	$0x1, 0x8(%rsp)
   160c7:      	movq	(%rip), %rdi            # 0x160ce <generic_fentry_path+0xbc0e>
   160ce:      	xorl	%ecx, %ecx
   160d0:      	leaq	0x18(%rsp), %rsi
   160d5:      	leaq	0x8(%rsp), %rdx
   160da:      	movl	$0x2, %eax
   160df:      	xorl	%ecx, %ecx
   160e1:      	callq	*%rax
   160e3:      	movq	(%rsp), %rdx
   160e7:      	leaq	0x18(%rdx), %r13
   160eb:      	movq	0x6440(%r14), %r12
   160f2:      	leaq	0x6448(%r14), %rdi
   160f9:      	addq	$0x20, %rdx
   160fd:      	movl	$0x8, %ecx
   16102:      	movl	$0x4, %eax
   16107:      	movl	$0x8, %esi
   1610c:      	callq	*%rax
   1610e:      	testq	%rax, %rax
   16111:      	je	0x16170 <generic_fentry_path+0xbcb0>
   16113:      	negl	%eax
   16115:      	movw	%ax, 0x18(%rsp)
   1611a:      	movw	$0x6, 0x1a(%rsp)
   16121:      	movabsq	$0x400000038, %rax      # imm = 0x400000038
   1612b:      	movq	%rax, 0x1c(%rsp)
   16130:      	movq	(%rip), %rdi            # 0x16137 <generic_fentry_path+0xbc77>
   16137:      	leaq	0x18(%rsp), %rsi
   1613c:      	movl	$0x1, %eax
   16141:      	callq	*%rax
   16143:      	testq	%rax, %rax
   16146:      	je	0x1614c <generic_fentry_path+0xbc8c>
   16148:      	incl	(%rax)
   1614a:      	jmp	0x16170 <generic_fentry_path+0xbcb0>
   1614c:      	movl	$0x1, 0x8(%rsp)
   16154:      	movq	(%rip), %rdi            # 0x1615b <generic_fentry_path+0xbc9b>
   1615b:      	xorl	%ecx, %ecx
   1615d:      	leaq	0x18(%rsp), %rsi
   16162:      	leaq	0x8(%rsp), %rdx
   16167:      	movl	$0x2, %eax
   1616c:      	xorl	%ecx, %ecx
   1616e:      	callq	*%rax
   16170:      	leaq	0x6450(%r14), %rdi
   16177:      	movl	$0x8, %ecx
   1617c:      	movl	$0x4, %eax
   16181:      	movl	$0x8, %esi
   16186:      	movq	%r13, %rdx
   16189:      	callq	*%rax
   1618b:      	testq	%rax, %rax
   1618e:      	je	0x161ed <generic_fentry_path+0xbd2d>
   16190:      	negl	%eax
   16192:      	movw	%ax, 0x18(%rsp)
   16197:      	movw	$0x6, 0x1a(%rsp)
   1619e:      	movabsq	$0x400000039, %rax      # imm = 0x400000039
   161a8:      	movq	%rax, 0x1c(%rsp)
   161ad:      	movq	(%rip), %rdi            # 0x161b4 <generic_fentry_path+0xbcf4>
   161b4:      	leaq	0x18(%rsp), %rsi
   161b9:      	movl	$0x1, %eax
   161be:      	callq	*%rax
   161c0:      	testq	%rax, %rax
   161c3:      	je	0x161c9 <generic_fentry_path+0xbd09>
   161c5:      	incl	(%rax)
   161c7:      	jmp	0x161ed <generic_fentry_path+0xbd2d>
   161c9:      	movl	$0x1, 0x8(%rsp)
   161d1:      	movq	(%rip), %rdi            # 0x161d8 <generic_fentry_path+0xbd18>
   161d8:      	xorl	%ecx, %ecx
   161da:      	leaq	0x18(%rsp), %rsi
   161df:      	leaq	0x8(%rsp), %rdx
   161e4:      	movl	$0x2, %eax
   161e9:      	xorl	%ecx, %ecx
   161eb:      	callq	*%rax
   161ed:      	leaq	0x6458(%r14), %rdi
   161f4:      	leaq	0x8(%r12), %rdx
   161f9:      	movl	$0x8, %ecx
   161fe:      	movl	$0x4, %eax
   16203:      	movl	$0x8, %esi
   16208:      	callq	*%rax
   1620a:      	testq	%rax, %rax
   1620d:      	je	0x1626c <generic_fentry_path+0xbdac>
   1620f:      	negl	%eax
   16211:      	movw	%ax, 0x18(%rsp)
   16216:      	movw	$0x6, 0x1a(%rsp)
   1621d:      	movabsq	$0x40000003a, %rax      # imm = 0x40000003A
   16227:      	movq	%rax, 0x1c(%rsp)
   1622c:      	movq	(%rip), %rdi            # 0x16233 <generic_fentry_path+0xbd73>
   16233:      	leaq	0x18(%rsp), %rsi
   16238:      	movl	$0x1, %eax
   1623d:      	callq	*%rax
   1623f:      	testq	%rax, %rax
   16242:      	je	0x16248 <generic_fentry_path+0xbd88>
   16244:      	incl	(%rax)
   16246:      	jmp	0x1626c <generic_fentry_path+0xbdac>
   16248:      	movl	$0x1, 0x8(%rsp)
   16250:      	movq	(%rip), %rdi            # 0x16257 <generic_fentry_path+0xbd97>
   16257:      	xorl	%ecx, %ecx
   16259:      	leaq	0x18(%rsp), %rsi
   1625e:      	leaq	0x8(%rsp), %rdx
   16263:      	movl	$0x2, %eax
   16268:      	xorl	%ecx, %ecx
   1626a:      	callq	*%rax
   1626c:      	movq	%r14, %rdi
   1626f:      	addq	$0x6460, %rdi           # imm = 0x6460
   16276:      	movl	$0x8, %ecx
   1627b:      	movl	$0x4, %eax
   16280:      	movl	$0x8, %esi
   16285:      	movq	%r12, %rdx
   16288:      	callq	*%rax
   1628a:      	testq	%rax, %rax
   1628d:      	je	0x162ec <generic_fentry_path+0xbe2c>
   1628f:      	negl	%eax
   16291:      	movw	%ax, 0x18(%rsp)
   16296:      	movw	$0x6, 0x1a(%rsp)
   1629d:      	movabsq	$0x40000003b, %rax      # imm = 0x40000003B
   162a7:      	movq	%rax, 0x1c(%rsp)
   162ac:      	movq	(%rip), %rdi            # 0x162b3 <generic_fentry_path+0xbdf3>
   162b3:      	leaq	0x18(%rsp), %rsi
   162b8:      	movl	$0x1, %eax
   162bd:      	callq	*%rax
   162bf:      	testq	%rax, %rax
   162c2:      	je	0x162c8 <generic_fentry_path+0xbe08>
   162c4:      	incl	(%rax)
   162c6:      	jmp	0x162ec <generic_fentry_path+0xbe2c>
   162c8:      	movl	$0x1, 0x8(%rsp)
   162d0:      	movq	(%rip), %rdi            # 0x162d7 <generic_fentry_path+0xbe17>
   162d7:      	xorl	%ecx, %ecx
   162d9:      	leaq	0x18(%rsp), %rsi
   162de:      	leaq	0x8(%rsp), %rdx
   162e3:      	movl	$0x2, %eax
   162e8:      	xorl	%ecx, %ecx
   162ea:      	callq	*%rax
   162ec:      	movq	0x6460(%r14), %rax
   162f3:      	addq	$-0x20, %rax
   162f7:      	movq	%rax, 0x6468(%r14)
   162fe:      	movl	$0x0, 0x6428(%r14)
   16309:      	subl	%r15d, %ebx
   1630c:      	movl	%ebx, 0x6424(%r14)
   16313:      	movl	$0x1, 0x6420(%r14)
   1631e:      	movq	(%rip), %rsi            # 0x16325 <generic_fentry_path+0xbe65>
   16325:      	movl	$0x6, %ecx
   1632a:      	movl	$0xc, %eax
   1632f:      	movq	%rbp, %rdi
   16332:      	movl	$0x6, %edx
   16337:      	callq	*%rax
   16339:      	xorl	%eax, %eax
   1633b:      	addq	$0x88, %rsp
   16342:      	popq	%rbx
   16343:      	popq	%r12
   16345:      	popq	%r13
   16347:      	popq	%r14
   16349:      	popq	%r15
   1634b:      	popq	%rbp
   1634c:      	retq

Disassembly of section fentry/generic_fentry:

0000000000000000 <generic_fentry_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x88, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x38(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <generic_fentry_event+0x23>
      23:      	leaq	0x38(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x62d <generic_fentry_event+0x62d>
      38:      	movq	%rax, %r14
      3b:      	leaq	0x5ef8(%rax), %rsi
      42:      	movl	$0x0, 0x5ef8(%rax)
      4c:      	movq	(%rip), %rdi            # 0x53 <generic_fentry_event+0x53>
      53:      	movl	$0x1, %eax
      58:      	callq	*%rax
      5a:      	testq	%rax, %rax
      5d:      	je	0x62d <generic_fentry_event+0x62d>
      63:      	movl	0x64(%rax), %ecx
      66:      	movl	%ecx, 0x14(%rsp)
      6a:      	testl	%ecx, %ecx
      6c:      	je	0x23b <generic_fentry_event+0x23b>
      72:      	movq	%rax, %r12
      75:      	movq	(%rip), %rdi            # 0x7c <generic_fentry_event+0x7c>
      7c:      	leaq	0x14(%rsp), %rsi
      81:      	movl	$0x1, %eax
      86:      	callq	*%rax
      88:      	testq	%rax, %rax
      8b:      	je	0x62d <generic_fentry_event+0x62d>
      91:      	movq	%rax, %r15
      94:      	movl	$0x0, 0x3c(%rsp)
      9c:      	movq	(%rip), %rdi            # 0xa3 <generic_fentry_event+0xa3>
      a3:      	leaq	0x3c(%rsp), %rsi
      a8:      	movl	$0x1, %eax
      ad:      	callq	*%rax
      af:      	testq	%rax, %rax
      b2:      	je	0xd8 <generic_fentry_event+0xd8>
      b4:      	cmpq	$0x63677270, 0x20(%rax) # imm = 0x63677270
      bc:      	jne	0xdc <generic_fentry_event+0xdc>
      be:      	movl	$0x50, %eax
      c3:      	callq	*%rax
      c5:      	movq	%rax, 0x8(%rsp)
      ca:      	testq	%rax, %rax
      cd:      	jne	0x1f6 <generic_fentry_event+0x1f6>
      d3:      	jmp	0x62d <generic_fentry_event+0x62d>
      d8:      	xorl	%ebp, %ebp
      da:      	jmp	0xdf <generic_fentry_event+0xdf>
      dc:      	movl	0x10(%rax), %ebp
      df:      	movl	$0x23, %eax
      e4:      	callq	*%rax
      e6:      	movq	$0x0, 0x20(%rsp)
      ef:      	leaq	0xf90(%rax), %rdx
      f6:      	leaq	0x28(%rsp), %rdi
      fb:      	movl	$0x8, %ecx
     100:      	movl	$0x71, %eax
     105:      	movl	$0x8, %esi
     10a:      	callq	*%rax
     10c:      	movq	0x28(%rsp), %rax
     111:      	testq	%rax, %rax
     114:      	je	0x62d <generic_fentry_event+0x62d>
     11a:      	cmpl	$0xb, %ebp
     11d:      	ja	0x62d <generic_fentry_event+0x62d>
     123:      	movl	%ebp, %edx
     125:      	leaq	(%rax,%rdx,8), %rcx
     129:      	leaq	0x40(%rsp), %rdi
     12e:      	movl	$0x8, %esi
     133:      	movl	$0x71, %eax
     138:      	shlq	$0x3, %rdx
     13c:      	addq	0x28(%rsp), %rdx
     141:      	movl	$0x8, %esi
     146:      	callq	*%rax
     148:      	movq	0x40(%rsp), %rcx
     14d:      	testq	%rcx, %rcx
     150:      	je	0x62d <generic_fentry_event+0x62d>
     156:      	leaq	0x20(%rsp), %rdi
     15b:      	movl	$0x8, %edx
     160:      	movl	$0x71, %eax
     165:      	movq	0x40(%rsp), %rdx
     16a:      	movl	$0x8, %esi
     16f:      	callq	*%rax
     171:      	movq	0x20(%rsp), %rdx
     176:      	testq	%rdx, %rdx
     179:      	je	0x62d <generic_fentry_event+0x62d>
     17f:      	movq	$0x0, 0x40(%rsp)
     188:      	addq	$0x100, %rdx            # imm = 0x100
     18f:      	leaq	0x40(%rsp), %rdi
     194:      	movl	$0x8, %ecx
     199:      	movl	$0x71, %eax
     19e:      	movl	$0x8, %esi
     1a3:      	callq	*%rax
     1a5:      	movq	0x40(%rsp), %rdx
     1aa:      	movq	$0x0, 0x40(%rsp)
     1b3:      	testq	%rdx, %rdx
     1b6:      	je	0x1e6 <generic_fentry_event+0x1e6>
     1b8:      	addq	$0x60, %rdx
     1bc:      	leaq	0x40(%rsp), %rdi
     1c1:      	movl	$0x8, %ecx
     1c6:      	movl	$0x71, %eax
     1cb:      	movl	$0x8, %esi
     1d0:      	callq	*%rax
     1d2:      	movq	0x40(%rsp), %rax
     1d7:      	movq	%rax, 0x8(%rsp)
     1dc:      	testq	%rax, %rax
     1df:      	jne	0x1f6 <generic_fentry_event+0x1f6>
     1e1:      	jmp	0x62d <generic_fentry_event+0x62d>
     1e6:      	xorl	%eax, %eax
     1e8:      	movq	%rax, 0x8(%rsp)
     1ed:      	testq	%rax, %rax
     1f0:      	je	0x62d <generic_fentry_event+0x62d>
     1f6:      	movq	%rax, 0x40(%rsp)
     1fb:      	movq	(%rip), %rdi            # 0x202 <generic_fentry_event+0x202>
     202:      	leaq	0x40(%rsp), %rsi
     207:      	movl	$0x1, %eax
     20c:      	callq	*%rax
     20e:      	testq	%rax, %rax
     211:      	je	0x220 <generic_fentry_event+0x220>
     213:      	movq	(%rax), %rax
     216:      	testq	%rax, %rax
     219:      	je	0x220 <generic_fentry_event+0x220>
     21b:      	movq	%rax, 0x8(%rsp)
     220:      	leaq	0x8(%rsp), %rsi
     225:      	movl	$0x1, %eax
     22a:      	movq	%r15, %rdi
     22d:      	callq	*%rax
     22f:      	testq	%rax, %rax
     232:      	movq	%r12, %rax
     235:      	je	0x641 <generic_fentry_event+0x641>
     23b:      	movl	(%rax), %eax
     23d:      	movq	%rax, 0x60(%r14)
     241:      	movq	$0x0, 0x68(%r14)
     249:      	movq	$0x0, 0x5efc(%r14)
     254:      	movl	$0x0, 0x6420(%r14)
     25f:      	movq	$0x0, 0x5eb8(%r14)
     26a:      	movq	$0x0, 0x5ec0(%r14)
     275:      	movq	$0x0, 0x5ec8(%r14)
     280:      	movq	$0x0, 0x5ed0(%r14)
     28b:      	movq	$0x0, 0x5ed8(%r14)
     296:      	movb	$0x0, 0x5ee0(%r14)
     29e:      	movl	$0x23, %eax
     2a3:      	callq	*%rax
     2a5:      	movq	%rax, %r15
     2a8:      	leaq	0xd70(%rax), %rdx
     2af:      	leaq	0x20(%rsp), %rdi
     2b4:      	movl	$0x8, %ecx
     2b9:      	movl	$0x4, %eax
     2be:      	leaq	0x20(%r14), %r12
     2c2:      	movl	$0x4, %r13d
     2c8:      	movl	$0x8, %esi
     2cd:      	callq	*%rax
     2cf:      	movq	0x20(%rsp), %rcx
     2d4:      	leaq	0x40(%rsp), %rdi
     2d9:      	movl	$0x48, %edx
     2de:      	movl	$0x4, %eax
     2e3:      	movq	0x20(%rsp), %rdx
     2e8:      	movl	$0x48, %esi
     2ed:      	callq	*%rax
     2ef:      	movl	$0x218, %edx            # imm = 0x218
     2f4:      	movq	0x48(%rsp), %rcx
     2f9:      	addq	%rdx, %rcx
     2fc:      	movl	$0x4, %esi
     301:      	movl	$0x4, %eax
     306:      	addq	0x48(%rsp), %rdx
     30b:      	movq	%r12, %rdi
     30e:      	movl	$0x4, %esi
     313:      	callq	*%rax
     315:      	leaq	0x24(%r14), %rdi
     319:      	movl	$0x4d8, %edx            # imm = 0x4D8
     31e:      	movq	0x50(%rsp), %rcx
     323:      	addq	%rdx, %rcx
     326:      	movl	$0x4, %esi
     32b:      	movl	$0x4, %eax
     330:      	addq	0x50(%rsp), %rdx
     335:      	movl	$0x4, %esi
     33a:      	callq	*%rax
     33c:      	leaq	0x28(%r14), %rdi
     340:      	movq	0x58(%rsp), %rcx
     345:      	addq	$0x58, %rcx
     349:      	movl	$0x4, %edx
     34e:      	movl	$0x4, %eax
     353:      	movq	0x58(%rsp), %rdx
     358:      	addq	$0x58, %rdx
     35c:      	movl	$0x4, %esi
     361:      	callq	*%rax
     363:      	movq	$0x0, 0x8(%rsp)
     36c:      	leaq	0xb58(%r15), %rdx
     373:      	leaq	0x8(%rsp), %rdi
     378:      	movl	$0x8, %ecx
     37d:      	movl	$0x4, %eax
     382:      	movl	$0x8, %esi
     387:      	callq	*%rax
     389:      	movq	0x8(%rsp), %rcx
     38e:      	testq	%rcx, %rcx
     391:      	je	0x427 <generic_fentry_event+0x427>
     397:      	movl	$0x0, 0x18(%rsp)
     39f:      	addq	$0x4, %rcx
     3a3:      	leaq	0x18(%rsp), %rdi
     3a8:      	movl	$0x4, %eax
     3ad:      	movq	0x8(%rsp), %rdx
     3b2:      	addq	$0x4, %rdx
     3b6:      	movl	$0x4, %esi
     3bb:      	callq	*%rax
     3bd:      	movq	0x8(%rsp), %rax
     3c2:      	movslq	0x18(%rsp), %rcx
     3c7:      	shlq	$0x4, %rcx
     3cb:      	addq	%rax, %rcx
     3ce:      	addq	$0x80, %rcx
     3d5:      	leaq	0x28(%rsp), %rdi
     3da:      	movl	$0x10, %edx
     3df:      	movl	$0x4, %eax
     3e4:      	movq	0x8(%rsp), %rcx
     3e9:      	movslq	0x18(%rsp), %rdx
     3ee:      	shlq	$0x4, %rdx
     3f2:      	addq	%rcx, %rdx
     3f5:      	addq	$0x80, %rdx
     3fc:      	movl	$0x10, %esi
     401:      	callq	*%rax
     403:      	leaq	0x2c(%r14), %rdi
     407:      	movl	$0x158, %edx            # imm = 0x158
     40c:      	movq	0x30(%rsp), %rcx
     411:      	addq	%rdx, %rcx
     414:      	movl	$0x4, %eax
     419:      	addq	0x30(%rsp), %rdx
     41e:      	movl	$0x4, %esi
     423:      	callq	*%rax
     425:      	jmp	0x42f <generic_fentry_event+0x42f>
     427:      	movl	$0x0, 0x2c(%r14)
     42f:      	leaq	0x30(%r14), %rdi
     433:      	movl	$0x158, %r12d           # imm = 0x158
     439:      	movq	0x60(%rsp), %rcx
     43e:      	addq	%r12, %rcx
     441:      	movl	$0x4, %edx
     446:      	movl	$0x4, %eax
     44b:      	movq	0x60(%rsp), %rdx
     450:      	addq	%r12, %rdx
     453:      	movl	$0x4, %esi
     458:      	callq	*%rax
     45a:      	leaq	0x34(%r14), %rdi
     45e:      	movl	$0x118, %edx            # imm = 0x118
     463:      	movq	0x68(%rsp), %rcx
     468:      	addq	%rdx, %rcx
     46b:      	movl	$0x4, %esi
     470:      	movl	$0x4, %eax
     475:      	addq	0x68(%rsp), %rdx
     47a:      	movl	$0x4, %esi
     47f:      	callq	*%rax
     481:      	leaq	0x38(%r14), %rdi
     485:      	movl	$0x98, %r13d
     48b:      	movq	0x70(%rsp), %rcx
     490:      	addq	%r13, %rcx
     493:      	movl	$0x4, %edx
     498:      	movl	$0x4, %eax
     49d:      	movq	0x70(%rsp), %rdx
     4a2:      	addq	%r13, %rdx
     4a5:      	movl	$0x4, %esi
     4aa:      	callq	*%rax
     4ac:      	leaq	0x3c(%r14), %rdi
     4b0:      	movq	0x78(%rsp), %rcx
     4b5:      	addq	%r13, %rcx
     4b8:      	movl	$0x4, %edx
     4bd:      	movl	$0x4, %eax
     4c2:      	addq	0x78(%rsp), %r13
     4c7:      	movl	$0x4, %esi
     4cc:      	movq	%r13, %rdx
     4cf:      	callq	*%rax
     4d1:      	leaq	0x40(%r14), %rdi
     4d5:      	movq	0x80(%rsp), %rcx
     4dd:      	addq	$0x58, %rcx
     4e1:      	movl	$0x4, %edx
     4e6:      	movl	$0x4, %eax
     4eb:      	movq	0x80(%rsp), %rdx
     4f3:      	addq	$0x58, %rdx
     4f7:      	movl	$0x4, %esi
     4fc:      	callq	*%rax
     4fe:      	movq	$0x0, 0x28(%rsp)
     507:      	movq	$0x0, 0x8(%rsp)
     510:      	addq	$0xd00, %r15            # imm = 0xD00
     517:      	leaq	0x28(%rsp), %rdi
     51c:      	movl	$0x8, %ecx
     521:      	movl	$0x4, %eax
     526:      	movl	$0x8, %esi
     52b:      	movq	%r15, %rdx
     52e:      	callq	*%rax
     530:      	movl	$0x90, %edx
     535:      	movq	0x28(%rsp), %rcx
     53a:      	addq	%rdx, %rcx
     53d:      	leaq	0x8(%rsp), %rdi
     542:      	movl	$0x8, %esi
     547:      	movl	$0x4, %eax
     54c:      	addq	0x28(%rsp), %rdx
     551:      	movl	$0x8, %esi
     556:      	callq	*%rax
     558:      	leaq	0x44(%r14), %rdi
     55c:      	movq	0x8(%rsp), %rcx
     561:      	addq	%r12, %rcx
     564:      	movl	$0x4, %edx
     569:      	movl	$0x4, %eax
     56e:      	addq	0x8(%rsp), %r12
     573:      	movl	$0x4, %esi
     578:      	movq	%r12, %rdx
     57b:      	callq	*%rax
     57d:      	leaq	0x48(%r14), %r12
     581:      	leaq	0x40(%rsp), %rdi
     586:      	movl	$0x8, %ecx
     58b:      	movl	$0x4, %eax
     590:      	movl	$0x8, %esi
     595:      	movq	%r15, %rdx
     598:      	callq	*%rax
     59a:      	movq	0x40(%rsp), %r15
     59f:      	leaq	0x50(%r14), %rdi
     5a3:      	leaq	0x40(%r15), %rdx
     5a7:      	movl	$0x8, %ecx
     5ac:      	movl	$0x4, %eax
     5b1:      	movl	$0x8, %esi
     5b6:      	callq	*%rax
     5b8:      	movq	%r14, %rdi
     5bb:      	addq	$0x58, %rdi
     5bf:      	leaq	0x30(%r15), %rdx
     5c3:      	movl	$0x8, %ecx
     5c8:      	movl	$0x4, %eax
     5cd:      	movl	$0x8, %esi
     5d2:      	callq	*%rax
     5d4:      	addq	$0x38, %r15
     5d8:      	movl	$0x8, %ecx
     5dd:      	movl	$0x4, %eax
     5e2:      	movq	%r12, %rdi
     5e5:      	movl	$0x8, %esi
     5ea:      	movq	%r15, %rdx
     5ed:      	callq	*%rax
     5ef:      	movb	$0x0, 0x5f08(%r14)
     5f7:      	movb	$0x0, 0x1(%r14)
     5fc:      	movq	$0x0, 0x5ee8(%r14)
     607:      	movq	$0x0, 0x5ef0(%r14)
     612:      	movq	(%rip), %rsi            # 0x619 <generic_fentry_event+0x619>
     619:      	movl	$0x2, %ecx
     61e:      	movl	$0xc, %eax
     623:      	movq	%rbx, %rdi
     626:      	movl	$0x2, %edx
     62b:      	callq	*%rax
     62d:      	xorl	%eax, %eax
     62f:      	addq	$0x88, %rsp
     636:      	popq	%rbx
     637:      	popq	%r12
     639:      	popq	%r13
     63b:      	popq	%r14
     63d:      	popq	%r15
     63f:      	popq	%rbp
     640:      	retq
     641:      	movq	$-0x1, 0x18(%rsp)
     64a:      	leaq	0x18(%rsp), %rsi
     64f:      	movl	$0x1, %eax
     654:      	movq	%r15, %rdi
     657:      	callq	*%rax
     659:      	testq	%rax, %rax
     65c:      	je	0x62d <generic_fentry_event+0x62d>
     65e:      	movl	$0x1, 0x14(%rsp)
     666:      	movq	(%rip), %rdi            # 0x66d <generic_fentry_event+0x66d>
     66d:      	leaq	0x14(%rsp), %rsi
     672:      	movl	$0x1, %eax
     677:      	callq	*%rax
     679:      	testq	%rax, %rax
     67c:      	je	0x62d <generic_fentry_event+0x62d>
     67e:      	movq	%rax, %rdi
     681:      	leaq	0x8(%rsp), %rsi
     686:      	movl	$0x1, %eax
     68b:      	callq	*%rax
     68d:      	testq	%rax, %rax
     690:      	movq	%r12, %rax
     693:      	jne	0x62d <generic_fentry_event+0x62d>
     695:      	jmp	0x23b <generic_fentry_event+0x23b>
