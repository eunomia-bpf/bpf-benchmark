
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_cgroup_release_v511.native.o:	file format elf64-x86-64

Disassembly of section raw_tracepoint/cgroup_release:

0000000000000000 <tg_tp_cgrp_release>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x38, %rsp
       e:      	movl	$0x0, 0x30(%rsp)
      16:      	movq	(%rdi), %rbx
      19:      	movq	$0x0, 0x8(%rsp)
      22:      	testq	%rbx, %rbx
      25:      	je	0x414 <tg_tp_cgrp_release+0x414>
      2b:      	movq	%rdi, %r12
      2e:      	leaq	0x100(%rbx), %rdx
      35:      	leaq	0x8(%rsp), %rdi
      3a:      	movl	$0x8, %ecx
      3f:      	movl	$0x71, %eax
      44:      	movl	$0x8, %esi
      49:      	callq	*%rax
      4b:      	movq	0x8(%rsp), %rdx
      50:      	movq	$0x0, 0x8(%rsp)
      59:      	testq	%rdx, %rdx
      5c:      	je	0x414 <tg_tp_cgrp_release+0x414>
      62:      	addq	$0x60, %rdx
      66:      	leaq	0x8(%rsp), %rdi
      6b:      	movl	$0x8, %ecx
      70:      	movl	$0x71, %eax
      75:      	movl	$0x8, %esi
      7a:      	callq	*%rax
      7c:      	movq	0x8(%rsp), %rax
      81:      	movq	%rax, 0x28(%rsp)
      86:      	testq	%rax, %rax
      89:      	je	0x414 <tg_tp_cgrp_release+0x414>
      8f:      	movq	(%rip), %rdi            # 0x96 <tg_tp_cgrp_release+0x96>
      96:      	leaq	0x28(%rsp), %rsi
      9b:      	movl	$0x1, %eax
      a0:      	callq	*%rax
      a2:      	testq	%rax, %rax
      a5:      	je	0x31a <tg_tp_cgrp_release+0x31a>
      ab:      	movq	%rax, %r13
      ae:      	movq	(%rip), %rdi            # 0xb5 <tg_tp_cgrp_release+0xb5>
      b5:      	leaq	0x28(%rsp), %rsi
      ba:      	movl	$0x3, %eax
      bf:      	callq	*%rax
      c1:      	movq	(%rip), %rdi            # 0xc8 <tg_tp_cgrp_release+0xc8>
      c8:      	leaq	0x30(%rsp), %rsi
      cd:      	movl	$0x1, %eax
      d2:      	callq	*%rax
      d4:      	testq	%rax, %rax
      d7:      	je	0x414 <tg_tp_cgrp_release+0x414>
      dd:      	cmpl	$0x6, (%rax)
      e0:      	jne	0x414 <tg_tp_cgrp_release+0x414>
      e6:      	movq	0x28(%rsp), %rbp
      eb:      	movl	$0x0, 0x34(%rsp)
      f3:      	movq	(%rip), %rdi            # 0xfa <tg_tp_cgrp_release+0xfa>
      fa:      	leaq	0x34(%rsp), %rsi
      ff:      	movl	$0x1, %eax
     104:      	callq	*%rax
     106:      	testq	%rax, %rax
     109:      	je	0x414 <tg_tp_cgrp_release+0x414>
     10f:      	movq	%rax, %rbx
     112:      	movb	$0x19, (%rax)
     115:      	movl	$0x10d8, 0x4(%rax)      # imm = 0x10D8
     11c:      	movq	0x8(%r12), %r14
     121:      	movl	$0xe, %eax
     126:      	callq	*%rax
     128:      	movq	%rax, %r15
     12b:      	shrq	$0x20, %r15
     12f:      	movl	%r15d, 0x8(%rsp)
     134:      	movq	(%rip), %rdi            # 0x13b <tg_tp_cgrp_release+0x13b>
     13b:      	leaq	0x8(%rsp), %rsi
     140:      	movl	$0x1, %eax
     145:      	callq	*%rax
     147:      	testq	%rax, %rax
     14a:      	je	0x172 <tg_tp_cgrp_release+0x172>
     14c:      	movq	0x8(%rax), %rcx
     150:      	movq	%rcx, 0x8(%rbx)
     154:      	movq	0x10(%rax), %rcx
     158:      	movq	0x18(%rax), %rdx
     15c:      	movq	%rcx, 0x10(%rbx)
     160:      	movq	%rdx, 0x18(%rbx)
     164:      	movl	0x20(%rax), %ecx
     167:      	movl	%ecx, 0x2c(%rbx)
     16a:      	movq	0x8(%rax), %rax
     16e:      	movq	%rax, 0x30(%rbx)
     172:      	movl	$0x3, 0x20(%rbx)
     179:      	movl	%r15d, 0x24(%rbx)
     17d:      	movl	$0x23, %eax
     182:      	callq	*%rax
     184:      	leaq	0x60(%rax), %rdx
     188:      	leaq	0x18(%rsp), %rdi
     18d:      	movl	$0x8, %ecx
     192:      	movl	$0x71, %eax
     197:      	movl	$0x8, %esi
     19c:      	callq	*%rax
     19e:      	movq	0x18(%rsp), %rcx
     1a3:      	xorl	%r15d, %r15d
     1a6:      	testq	%rcx, %rcx
     1a9:      	je	0x219 <tg_tp_cgrp_release+0x219>
     1ab:      	addq	$0x4, %rcx
     1af:      	leaq	0x24(%rsp), %rdi
     1b4:      	movl	$0x4, %edx
     1b9:      	movl	$0x71, %eax
     1be:      	movq	0x18(%rsp), %rdx
     1c3:      	addq	$0x4, %rdx
     1c7:      	movl	$0x4, %esi
     1cc:      	callq	*%rax
     1ce:      	movl	0x24(%rsp), %eax
     1d2:      	testl	%eax, %eax
     1d4:      	je	0x219 <tg_tp_cgrp_release+0x219>
     1d6:      	movq	0x18(%rsp), %rcx
     1db:      	shll	$0x4, %eax
     1de:      	addq	%rax, %rcx
     1e1:      	addq	$0x80, %rcx
     1e8:      	leaq	0x8(%rsp), %rdi
     1ed:      	movl	$0x10, %edx
     1f2:      	movl	$0x71, %eax
     1f7:      	movq	0x18(%rsp), %rcx
     1fc:      	movl	0x24(%rsp), %edx
     200:      	shll	$0x4, %edx
     203:      	addq	%rcx, %rdx
     206:      	addq	$0x80, %rdx
     20d:      	movl	$0x10, %esi
     212:      	callq	*%rax
     214:      	movl	0x8(%rsp), %r15d
     219:      	movl	%r15d, 0x28(%rbx)
     21d:      	movq	%rbp, 0x40(%rbx)
     221:      	movq	%rbp, 0x38(%rbx)
     225:      	movq	%r13, %rsi
     228:      	movl	(%r13), %eax
     22c:      	movl	%eax, 0x48(%rbx)
     22f:      	movl	0x8(%r13), %eax
     233:      	movl	%eax, 0x50(%rbx)
     236:      	movl	0x4(%r13), %eax
     23a:      	movl	%eax, 0x4c(%rbx)
     23d:      	leaq	0x58(%rbx), %rdi
     241:      	addq	$0x10, %rsi
     245:      	movl	$0x20, %ecx
     24a:      	rep		movsl	(%rsi), %es:(%rdi)
     24c:      	movq	%rbx, %rdi
     24f:      	addq	$0xd8, %rdi
     256:      	movl	$0xfff, %ecx            # imm = 0xFFF
     25b:      	movl	$0x2d, %eax
     260:      	movl	$0xfff, %esi            # imm = 0xFFF
     265:      	movq	%r14, %rdx
     268:      	callq	*%rax
     26a:      	movl	$0x0, 0x18(%rsp)
     272:      	movq	(%rip), %rdi            # 0x279 <tg_tp_cgrp_release+0x279>
     279:      	leaq	0x18(%rsp), %rsi
     27e:      	movl	$0x1, %eax
     283:      	callq	*%rax
     285:      	testq	%rax, %rax
     288:      	je	0x425 <tg_tp_cgrp_release+0x425>
     28e:      	cmpb	$0x0, 0x28(%rax)
     292:      	je	0x425 <tg_tp_cgrp_release+0x425>
     298:      	movq	(%rip), %rsi            # 0x29f <tg_tp_cgrp_release+0x29f>
     29f:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     2a4:      	movl	$0x10d8, %edx           # imm = 0x10D8
     2a9:      	movl	$0x19, %eax
     2ae:      	movq	%r12, %rdi
     2b1:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     2b6:      	movl	$0x10d8, %r8d           # imm = 0x10D8
     2bc:      	movq	%rbx, %rcx
     2bf:      	callq	*%rax
     2c1:      	testq	%rax, %rax
     2c4:      	jns	0x414 <tg_tp_cgrp_release+0x414>
     2ca:      	movq	%rax, %rbx
     2cd:      	movl	$0x0, 0x8(%rsp)
     2d5:      	movq	(%rip), %rdi            # 0x2dc <tg_tp_cgrp_release+0x2dc>
     2dc:      	leaq	0x8(%rsp), %rsi
     2e1:      	movl	$0x1, %eax
     2e6:      	callq	*%rax
     2e8:      	testq	%rax, %rax
     2eb:      	je	0x414 <tg_tp_cgrp_release+0x414>
     2f1:      	cmpq	$-0xc, %rbx
     2f5:      	jg	0x4a5 <tg_tp_cgrp_release+0x4a5>
     2fb:      	cmpq	$-0x1c, %rbx
     2ff:      	je	0x4bf <tg_tp_cgrp_release+0x4bf>
     305:      	cmpq	$-0x16, %rbx
     309:      	jne	0x47d <tg_tp_cgrp_release+0x47d>
     30f:      	addq	$0x598, %rax            # imm = 0x598
     315:      	jmp	0x4d5 <tg_tp_cgrp_release+0x4d5>
     31a:      	movl	$0x0, 0x24(%rsp)
     322:      	movl	$0x0, 0x8(%rsp)
     32a:      	leaq	0xd8(%rbx), %rdx
     331:      	leaq	0x8(%rsp), %rdi
     336:      	movl	$0x4, %ecx
     33b:      	movl	$0x71, %eax
     340:      	movl	$0x4, %esi
     345:      	callq	*%rax
     347:      	movl	0x8(%rsp), %ebp
     34b:      	addq	$0x2e8, %rbx            # imm = 0x2E8
     352:      	leaq	0x8(%rsp), %rdi
     357:      	movl	$0x8, %ecx
     35c:      	movl	$0x4, %eax
     361:      	movl	$0x8, %esi
     366:      	movq	%rbx, %rdx
     369:      	callq	*%rax
     36b:      	movq	0x8(%rsp), %rcx
     370:      	addq	$0xc, %rcx
     374:      	leaq	0x18(%rsp), %rdi
     379:      	movl	$0x4, %edx
     37e:      	movl	$0x4, %eax
     383:      	movq	0x8(%rsp), %rdx
     388:      	addq	$0xc, %rdx
     38c:      	movl	$0x4, %esi
     391:      	callq	*%rax
     393:      	movl	0x18(%rsp), %ebx
     397:      	movq	(%rip), %rdi            # 0x39e <tg_tp_cgrp_release+0x39e>
     39e:      	leaq	0x24(%rsp), %rsi
     3a3:      	movl	$0x1, %eax
     3a8:      	callq	*%rax
     3aa:      	testq	%rax, %rax
     3ad:      	je	0x414 <tg_tp_cgrp_release+0x414>
     3af:      	movl	0x14(%rax), %ecx
     3b2:      	testl	%ecx, %ecx
     3b4:      	je	0x414 <tg_tp_cgrp_release+0x414>
     3b6:      	cmpl	%ebx, 0xc(%rax)
     3b9:      	jne	0x414 <tg_tp_cgrp_release+0x414>
     3bb:      	testl	%ebp, %ebp
     3bd:      	je	0x414 <tg_tp_cgrp_release+0x414>
     3bf:      	cmpl	%ecx, %ebp
     3c1:      	ja	0x414 <tg_tp_cgrp_release+0x414>
     3c3:      	movl	$0xc0002, 0x8(%rsp)     # imm = 0xC0002
     3cb:      	movq	$0x27, 0xc(%rsp)
     3d4:      	movq	(%rip), %rdi            # 0x3db <tg_tp_cgrp_release+0x3db>
     3db:      	leaq	0x8(%rsp), %rsi
     3e0:      	movl	$0x1, %eax
     3e5:      	callq	*%rax
     3e7:      	testq	%rax, %rax
     3ea:      	je	0x3f0 <tg_tp_cgrp_release+0x3f0>
     3ec:      	incl	(%rax)
     3ee:      	jmp	0x414 <tg_tp_cgrp_release+0x414>
     3f0:      	movl	$0x1, 0x18(%rsp)
     3f8:      	movq	(%rip), %rdi            # 0x3ff <tg_tp_cgrp_release+0x3ff>
     3ff:      	xorl	%ecx, %ecx
     401:      	leaq	0x8(%rsp), %rsi
     406:      	leaq	0x18(%rsp), %rdx
     40b:      	movl	$0x2, %eax
     410:      	xorl	%ecx, %ecx
     412:      	callq	*%rax
     414:      	xorl	%eax, %eax
     416:      	addq	$0x38, %rsp
     41a:      	popq	%rbx
     41b:      	popq	%r12
     41d:      	popq	%r13
     41f:      	popq	%r14
     421:      	popq	%r15
     423:      	popq	%rbp
     424:      	retq
     425:      	movq	(%rip), %rdi            # 0x42c <tg_tp_cgrp_release+0x42c>
     42c:      	xorl	%ecx, %ecx
     42e:      	movl	$0x10d8, %edx           # imm = 0x10D8
     433:      	movl	$0x82, %eax
     438:      	movq	%rbx, %rsi
     43b:      	xorl	%ecx, %ecx
     43d:      	callq	*%rax
     43f:      	testq	%rax, %rax
     442:      	jns	0x414 <tg_tp_cgrp_release+0x414>
     444:      	movq	%rax, %rbx
     447:      	movl	$0x0, 0x8(%rsp)
     44f:      	movq	(%rip), %rdi            # 0x456 <tg_tp_cgrp_release+0x456>
     456:      	leaq	0x8(%rsp), %rsi
     45b:      	movl	$0x1, %eax
     460:      	callq	*%rax
     462:      	testq	%rax, %rax
     465:      	je	0x414 <tg_tp_cgrp_release+0x414>
     467:      	cmpq	$-0xc, %rbx
     46b:      	jg	0x48b <tg_tp_cgrp_release+0x48b>
     46d:      	cmpq	$-0x1c, %rbx
     471:      	je	0x4bf <tg_tp_cgrp_release+0x4bf>
     473:      	cmpq	$-0x16, %rbx
     477:      	je	0x30f <tg_tp_cgrp_release+0x30f>
     47d:      	cmpq	$-0x10, %rbx
     481:      	jne	0x4b7 <tg_tp_cgrp_release+0x4b7>
     483:      	addq	$0x590, %rax            # imm = 0x590
     489:      	jmp	0x4d5 <tg_tp_cgrp_release+0x4d5>
     48b:      	cmpq	$-0xb, %rbx
     48f:      	je	0x4c7 <tg_tp_cgrp_release+0x4c7>
     491:      	cmpq	$-0x7, %rbx
     495:      	je	0x4cf <tg_tp_cgrp_release+0x4cf>
     497:      	cmpq	$-0x2, %rbx
     49b:      	jne	0x4b7 <tg_tp_cgrp_release+0x4b7>
     49d:      	addq	$0x580, %rax            # imm = 0x580
     4a3:      	jmp	0x4d5 <tg_tp_cgrp_release+0x4d5>
     4a5:      	cmpq	$-0xb, %rbx
     4a9:      	je	0x4c7 <tg_tp_cgrp_release+0x4c7>
     4ab:      	cmpq	$-0x7, %rbx
     4af:      	je	0x4cf <tg_tp_cgrp_release+0x4cf>
     4b1:      	cmpq	$-0x2, %rbx
     4b5:      	je	0x49d <tg_tp_cgrp_release+0x49d>
     4b7:      	addq	$0x578, %rax            # imm = 0x578
     4bd:      	jmp	0x4d5 <tg_tp_cgrp_release+0x4d5>
     4bf:      	addq	$0x5a0, %rax            # imm = 0x5A0
     4c5:      	jmp	0x4d5 <tg_tp_cgrp_release+0x4d5>
     4c7:      	addq	$0x5a8, %rax            # imm = 0x5A8
     4cd:      	jmp	0x4d5 <tg_tp_cgrp_release+0x4d5>
     4cf:      	addq	$0x588, %rax            # imm = 0x588
     4d5:      	lock
     4d6:      	incq	(%rax)
     4d9:      	jmp	0x414 <tg_tp_cgrp_release+0x414>
