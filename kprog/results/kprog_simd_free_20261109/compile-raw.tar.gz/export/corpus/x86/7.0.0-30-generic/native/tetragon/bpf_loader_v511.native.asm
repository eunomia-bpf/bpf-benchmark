
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_loader_v511.native.o:	file format elf64-x86-64

Disassembly of section kprobe/perf_event_mmap_output:

0000000000000000 <loader_kprobe>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r12
       7:      	pushq	%rbx
       8:      	subq	$0x20, %rsp
       c:      	movq	%rdi, %r14
       f:      	movl	$0x0, 0x18(%rsp)
      17:      	movq	(%rip), %rdi            # 0x1e <loader_kprobe+0x1e>
      1e:      	leaq	0x18(%rsp), %rcx
      23:      	movl	$0x1, %eax
      28:      	movl	$0x0, 0x14(%rsp)
      30:      	leaq	0x14(%rsp), %rsi
      35:      	callq	*%rax
      37:      	testq	%rax, %rax
      3a:      	je	0x32f <loader_kprobe+0x32f>
      40:      	movq	%rax, %rbx
      43:      	leaq	0x70(%r14), %rdx
      47:      	movq	%rsp, %rdi
      4a:      	movl	$0x8, %ecx
      4f:      	movl	$0x4, %eax
      54:      	movl	$0x8, %esi
      59:      	callq	*%rax
      5b:      	movq	(%rsp), %r12
      5f:      	movq	0x1040(%rbx), %rax
      66:      	testq	%rax, %rax
      69:      	je	0x76 <loader_kprobe+0x76>
      6b:      	cmpq	%r12, %rax
      6e:      	jne	0x32f <loader_kprobe+0x32f>
      74:      	jmp	0xda <loader_kprobe+0xda>
      76:      	movl	$0x0, 0x10(%rsp)
      7e:      	movq	(%rip), %rdi            # 0x85 <loader_kprobe+0x85>
      85:      	leaq	0x10(%rsp), %rcx
      8a:      	movl	$0x1, %eax
      8f:      	movl	$0x0, 0xc(%rsp)
      97:      	leaq	0xc(%rsp), %rsi
      9c:      	callq	*%rax
      9e:      	testq	%rax, %rax
      a1:      	je	0x32f <loader_kprobe+0x32f>
      a7:      	movq	%rax, %r15
      aa:      	leaq	0x3f0(%r12), %rdx
      b2:      	movq	%rsp, %rdi
      b5:      	movl	$0x8, %ecx
      ba:      	movl	$0x4, %eax
      bf:      	movl	$0x8, %esi
      c4:      	callq	*%rax
      c6:      	movq	(%rsp), %rax
      ca:      	cmpq	%rax, (%r15)
      cd:      	jne	0x32f <loader_kprobe+0x32f>
      d3:      	movq	%r12, 0x1040(%rbx)
      da:      	movl	$0x23, %eax
      df:      	callq	*%rax
      e1:      	leaq	0xaf4(%rax), %rdx
      e8:      	movq	%rsp, %rdi
      eb:      	movl	$0x4, %ecx
      f0:      	movl	$0x4, %eax
      f5:      	movl	$0x4, %r12d
      fb:      	movl	$0x4, %esi
     100:      	callq	*%rax
     102:      	movl	(%rsp), %ebp
     105:      	movl	%ebp, (%rsp)
     108:      	movq	(%rip), %rdi            # 0x10f <loader_kprobe+0x10f>
     10f:      	movq	%rsp, %rsi
     112:      	movl	$0x1, %eax
     117:      	callq	*%rax
     119:      	testq	%rax, %rax
     11c:      	je	0x32f <loader_kprobe+0x32f>
     122:      	movl	(%rax), %ecx
     124:      	movl	%ecx, 0x10(%rbx)
     127:      	movq	0x8(%rax), %rax
     12b:      	movq	%rax, 0x18(%rbx)
     12f:      	leaq	0x68(%r14), %rdx
     133:      	movq	%rsp, %rdi
     136:      	movl	$0x8, %ecx
     13b:      	movl	$0x4, %eax
     140:      	movl	$0x8, %esi
     145:      	callq	*%rax
     147:      	movq	(%rsp), %r15
     14b:      	leaq	0x4c(%r15), %rdx
     14f:      	movq	%rsp, %rdi
     152:      	movl	$0x4, %eax
     157:      	movl	$0x4, %esi
     15c:      	callq	*%rax
     15e:      	movl	(%rsp), %eax
     161:      	movl	%eax, 0x24(%rbx)
     164:      	testl	%eax, %eax
     166:      	je	0x32f <loader_kprobe+0x32f>
     16c:      	leaq	0x2c(%rbx), %rdi
     170:      	leaq	0x38(%r15), %rdx
     174:      	movl	$0x14, %ecx
     179:      	movl	$0x4, %eax
     17e:      	movl	$0x14, %esi
     183:      	callq	*%rax
     185:      	addq	$0x8, %r15
     189:      	movq	%rsp, %rdi
     18c:      	movl	$0x8, %ecx
     191:      	movl	$0x4, %eax
     196:      	movl	$0x8, %esi
     19b:      	movq	%r15, %rdx
     19e:      	callq	*%rax
     1a0:      	movq	(%rsp), %rdx
     1a4:      	movq	%rbx, %rdi
     1a7:      	addq	$0x40, %rdi
     1ab:      	movl	$0x1000, %ecx           # imm = 0x1000
     1b0:      	movl	$0x2d, %eax
     1b5:      	movl	$0x1000, %esi           # imm = 0x1000
     1ba:      	callq	*%rax
     1bc:      	movl	%eax, 0x28(%rbx)
     1bf:      	movl	%ebp, 0x20(%rbx)
     1c2:      	movl	$0x1040, 0x4(%rbx)      # imm = 0x1040
     1c9:      	movl	$0x7d, %eax
     1ce:      	callq	*%rax
     1d0:      	movq	%rax, 0x8(%rbx)
     1d4:      	movw	$0x1a, (%rbx)
     1d9:      	movl	$0x0, 0x1c(%rsp)
     1e1:      	movq	(%rip), %rdi            # 0x1e8 <loader_kprobe+0x1e8>
     1e8:      	leaq	0x1c(%rsp), %rsi
     1ed:      	movl	$0x1, %eax
     1f2:      	callq	*%rax
     1f4:      	testq	%rax, %rax
     1f7:      	je	0x27e <loader_kprobe+0x27e>
     1fd:      	cmpb	$0x0, 0x28(%rax)
     201:      	je	0x27e <loader_kprobe+0x27e>
     203:      	movq	(%rip), %rsi            # 0x20a <loader_kprobe+0x20a>
     20a:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     20f:      	movl	$0x1040, %edx           # imm = 0x1040
     214:      	movl	$0x19, %eax
     219:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     21e:      	movl	$0x1040, %r8d           # imm = 0x1040
     224:      	movq	%r14, %rdi
     227:      	movq	%rbx, %rcx
     22a:      	callq	*%rax
     22c:      	testq	%rax, %rax
     22f:      	jns	0x32f <loader_kprobe+0x32f>
     235:      	movq	%rax, %rbx
     238:      	movl	$0x0, (%rsp)
     23f:      	movq	(%rip), %rdi            # 0x246 <loader_kprobe+0x246>
     246:      	movq	%rsp, %rsi
     249:      	movl	$0x1, %eax
     24e:      	callq	*%rax
     250:      	testq	%rax, %rax
     253:      	je	0x32f <loader_kprobe+0x32f>
     259:      	cmpq	$-0xc, %rbx
     25d:      	jg	0x2fb <loader_kprobe+0x2fb>
     263:      	cmpq	$-0x1c, %rbx
     267:      	je	0x315 <loader_kprobe+0x315>
     26d:      	cmpq	$-0x16, %rbx
     271:      	jne	0x2d3 <loader_kprobe+0x2d3>
     273:      	addq	$0x5d0, %rax            # imm = 0x5D0
     279:      	jmp	0x32b <loader_kprobe+0x32b>
     27e:      	movq	(%rip), %rdi            # 0x285 <loader_kprobe+0x285>
     285:      	xorl	%ecx, %ecx
     287:      	movl	$0x1040, %edx           # imm = 0x1040
     28c:      	movl	$0x82, %eax
     291:      	movq	%rbx, %rsi
     294:      	xorl	%ecx, %ecx
     296:      	callq	*%rax
     298:      	testq	%rax, %rax
     29b:      	jns	0x32f <loader_kprobe+0x32f>
     2a1:      	movq	%rax, %rbx
     2a4:      	movl	$0x0, (%rsp)
     2ab:      	movq	(%rip), %rdi            # 0x2b2 <loader_kprobe+0x2b2>
     2b2:      	movq	%rsp, %rsi
     2b5:      	movl	$0x1, %eax
     2ba:      	callq	*%rax
     2bc:      	testq	%rax, %rax
     2bf:      	je	0x32f <loader_kprobe+0x32f>
     2c1:      	cmpq	$-0xc, %rbx
     2c5:      	jg	0x2e1 <loader_kprobe+0x2e1>
     2c7:      	cmpq	$-0x1c, %rbx
     2cb:      	je	0x315 <loader_kprobe+0x315>
     2cd:      	cmpq	$-0x16, %rbx
     2d1:      	je	0x273 <loader_kprobe+0x273>
     2d3:      	cmpq	$-0x10, %rbx
     2d7:      	jne	0x30d <loader_kprobe+0x30d>
     2d9:      	addq	$0x5c8, %rax            # imm = 0x5C8
     2df:      	jmp	0x32b <loader_kprobe+0x32b>
     2e1:      	cmpq	$-0xb, %rbx
     2e5:      	je	0x31d <loader_kprobe+0x31d>
     2e7:      	cmpq	$-0x7, %rbx
     2eb:      	je	0x325 <loader_kprobe+0x325>
     2ed:      	cmpq	$-0x2, %rbx
     2f1:      	jne	0x30d <loader_kprobe+0x30d>
     2f3:      	addq	$0x5b8, %rax            # imm = 0x5B8
     2f9:      	jmp	0x32b <loader_kprobe+0x32b>
     2fb:      	cmpq	$-0xb, %rbx
     2ff:      	je	0x31d <loader_kprobe+0x31d>
     301:      	cmpq	$-0x7, %rbx
     305:      	je	0x325 <loader_kprobe+0x325>
     307:      	cmpq	$-0x2, %rbx
     30b:      	je	0x2f3 <loader_kprobe+0x2f3>
     30d:      	addq	$0x5b0, %rax            # imm = 0x5B0
     313:      	jmp	0x32b <loader_kprobe+0x32b>
     315:      	addq	$0x5d8, %rax            # imm = 0x5D8
     31b:      	jmp	0x32b <loader_kprobe+0x32b>
     31d:      	addq	$0x5e0, %rax            # imm = 0x5E0
     323:      	jmp	0x32b <loader_kprobe+0x32b>
     325:      	addq	$0x5c0, %rax            # imm = 0x5C0
     32b:      	lock
     32c:      	incq	(%rax)
     32f:      	xorl	%eax, %eax
     331:      	addq	$0x20, %rsp
     335:      	popq	%rbx
     336:      	popq	%r12
     338:      	popq	%r14
     33a:      	popq	%r15
     33c:      	popq	%rbp
     33d:      	retq
