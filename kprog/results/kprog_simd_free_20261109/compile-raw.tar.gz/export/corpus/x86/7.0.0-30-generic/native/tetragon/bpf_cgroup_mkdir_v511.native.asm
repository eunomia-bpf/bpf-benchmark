
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_cgroup_mkdir_v511.native.o:	file format elf64-x86-64

Disassembly of section raw_tracepoint/cgroup_mkdir:

0000000000000000 <tg_tp_cgrp_mkdir>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x38, %rsp
       e:      	movq	%rdi, %rbx
      11:      	movl	$0x0, 0x28(%rsp)
      19:      	movq	(%rip), %rdi            # 0x20 <tg_tp_cgrp_mkdir+0x20>
      20:      	leaq	0x28(%rsp), %rsi
      25:      	movl	$0x1, %eax
      2a:      	callq	*%rax
      2c:      	testq	%rax, %rax
      2f:      	je	0x2f2 <tg_tp_cgrp_mkdir+0x2f2>
      35:      	movq	%rax, %r14
      38:      	cmpl	$0x0, 0x14(%rax)
      3c:      	je	0x2f2 <tg_tp_cgrp_mkdir+0x2f2>
      42:      	movq	(%rbx), %r12
      45:      	leaq	0x2e8(%r12), %r15
      4d:      	leaq	0x8(%rsp), %rdi
      52:      	movl	$0x8, %ecx
      57:      	movl	$0x4, %eax
      5c:      	movl	$0x8, %esi
      61:      	movq	%r15, %rdx
      64:      	callq	*%rax
      66:      	movq	0x8(%rsp), %rcx
      6b:      	addq	$0xc, %rcx
      6f:      	leaq	0x18(%rsp), %rdi
      74:      	movl	$0x4, %edx
      79:      	movl	$0x4, %eax
      7e:      	movq	0x8(%rsp), %rdx
      83:      	addq	$0xc, %rdx
      87:      	movl	$0x4, %esi
      8c:      	callq	*%rax
      8e:      	movl	0x18(%rsp), %eax
      92:      	cmpl	%eax, 0xc(%r14)
      96:      	jne	0x2f2 <tg_tp_cgrp_mkdir+0x2f2>
      9c:      	movl	$0x0, 0x8(%rsp)
      a4:      	leaq	0xd8(%r12), %r13
      ac:      	leaq	0x8(%rsp), %rdi
      b1:      	movl	$0x4, %ecx
      b6:      	movl	$0x71, %eax
      bb:      	movl	$0x4, %esi
      c0:      	movq	%r13, %rdx
      c3:      	callq	*%rax
      c5:      	movl	0x8(%rsp), %ebp
      c9:      	testl	%ebp, %ebp
      cb:      	je	0x2f2 <tg_tp_cgrp_mkdir+0x2f2>
      d1:      	movq	$0x0, 0x8(%rsp)
      da:      	testq	%r12, %r12
      dd:      	je	0x2f2 <tg_tp_cgrp_mkdir+0x2f2>
      e3:      	addq	$0x100, %r12            # imm = 0x100
      ea:      	leaq	0x8(%rsp), %rdi
      ef:      	movl	$0x8, %ecx
      f4:      	movl	$0x71, %eax
      f9:      	movl	$0x8, %esi
      fe:      	movq	%r12, %rdx
     101:      	callq	*%rax
     103:      	movq	0x8(%rsp), %rdx
     108:      	movq	$0x0, 0x8(%rsp)
     111:      	testq	%rdx, %rdx
     114:      	je	0x2f2 <tg_tp_cgrp_mkdir+0x2f2>
     11a:      	addq	$0x60, %rdx
     11e:      	leaq	0x8(%rsp), %rdi
     123:      	movl	$0x8, %ecx
     128:      	movl	$0x71, %eax
     12d:      	movl	$0x8, %esi
     132:      	callq	*%rax
     134:      	movq	0x8(%rsp), %rax
     139:      	movq	%rax, 0x30(%rsp)
     13e:      	testq	%rax, %rax
     141:      	je	0x2f2 <tg_tp_cgrp_mkdir+0x2f2>
     147:      	cmpl	0x14(%r14), %ebp
     14b:      	ja	0x2f2 <tg_tp_cgrp_mkdir+0x2f2>
     151:      	leaq	0x8(%rsp), %rdi
     156:      	movl	$0x8, %ecx
     15b:      	movl	$0x4, %eax
     160:      	movl	$0x8, %esi
     165:      	movq	%r15, %rdx
     168:      	callq	*%rax
     16a:      	movq	0x8(%rsp), %rcx
     16f:      	addq	$0xc, %rcx
     173:      	leaq	0x18(%rsp), %rdi
     178:      	movl	$0x4, %edx
     17d:      	movl	$0x4, %eax
     182:      	movq	0x8(%rsp), %rdx
     187:      	addq	$0xc, %rdx
     18b:      	movl	$0x4, %esi
     190:      	callq	*%rax
     192:      	movl	0x18(%rsp), %ebp
     196:      	movl	$0x0, 0x8(%rsp)
     19e:      	leaq	0x8(%rsp), %rdi
     1a3:      	movl	$0x4, %ecx
     1a8:      	movl	$0x71, %eax
     1ad:      	movl	$0x4, %esi
     1b2:      	movq	%r13, %rdx
     1b5:      	callq	*%rax
     1b7:      	movl	0x8(%rsp), %r13d
     1bc:      	movl	$0x0, 0x8(%rsp)
     1c4:      	movq	(%rip), %rdi            # 0x1cb <tg_tp_cgrp_mkdir+0x1cb>
     1cb:      	leaq	0x8(%rsp), %rsi
     1d0:      	movl	$0x1, %eax
     1d5:      	callq	*%rax
     1d7:      	testq	%rax, %rax
     1da:      	je	0x2f2 <tg_tp_cgrp_mkdir+0x2f2>
     1e0:      	movq	%rax, %r15
     1e3:      	leaq	0xc(%rax), %rdi
     1e7:      	movl	$0x84, %edx
     1ec:      	xorl	%esi, %esi
     1ee:      	callq	0x1f3 <tg_tp_cgrp_mkdir+0x1f3>
     1f3:      	movl	$0x1, (%r15)
     1fa:      	movl	%ebp, 0x4(%r15)
     1fe:      	movl	%r13d, 0x8(%r15)
     202:      	movq	$0x0, 0x8(%rsp)
     20b:      	leaq	0x8(%rsp), %rdi
     210:      	movl	$0x8, %ecx
     215:      	movl	$0x71, %eax
     21a:      	movl	$0x8, %esi
     21f:      	movq	%r12, %rdx
     222:      	callq	*%rax
     224:      	movq	0x8(%rsp), %rdx
     229:      	movq	$0x0, 0x8(%rsp)
     232:      	testq	%rdx, %rdx
     235:      	je	0x270 <tg_tp_cgrp_mkdir+0x270>
     237:      	addq	$0x10, %rdx
     23b:      	leaq	0x8(%rsp), %rdi
     240:      	movl	$0x8, %ecx
     245:      	movl	$0x71, %eax
     24a:      	movl	$0x8, %esi
     24f:      	callq	*%rax
     251:      	movq	0x8(%rsp), %rdx
     256:      	testq	%rdx, %rdx
     259:      	je	0x270 <tg_tp_cgrp_mkdir+0x270>
     25b:      	leaq	0x10(%r15), %rdi
     25f:      	movl	$0x7f, %ecx
     264:      	movl	$0x2d, %eax
     269:      	movl	$0x7f, %esi
     26e:      	callq	*%rax
     270:      	movq	(%rip), %rdi            # 0x277 <tg_tp_cgrp_mkdir+0x277>
     277:      	xorl	%ecx, %ecx
     279:      	leaq	0x30(%rsp), %rsi
     27e:      	movl	$0x2, %eax
     283:      	movq	%r15, %rdx
     286:      	xorl	%ecx, %ecx
     288:      	callq	*%rax
     28a:      	testq	%rax, %rax
     28d:      	je	0x2ec <tg_tp_cgrp_mkdir+0x2ec>
     28f:      	negl	%eax
     291:      	movw	%ax, 0x8(%rsp)
     296:      	movw	$0x2, 0xa(%rsp)
     29d:      	movabsq	$0x200000047, %rax      # imm = 0x200000047
     2a7:      	movq	%rax, 0xc(%rsp)
     2ac:      	movq	(%rip), %rdi            # 0x2b3 <tg_tp_cgrp_mkdir+0x2b3>
     2b3:      	leaq	0x8(%rsp), %rsi
     2b8:      	movl	$0x1, %eax
     2bd:      	callq	*%rax
     2bf:      	testq	%rax, %rax
     2c2:      	je	0x2c8 <tg_tp_cgrp_mkdir+0x2c8>
     2c4:      	incl	(%rax)
     2c6:      	jmp	0x2ec <tg_tp_cgrp_mkdir+0x2ec>
     2c8:      	movl	$0x1, 0x18(%rsp)
     2d0:      	movq	(%rip), %rdi            # 0x2d7 <tg_tp_cgrp_mkdir+0x2d7>
     2d7:      	xorl	%ecx, %ecx
     2d9:      	leaq	0x8(%rsp), %rsi
     2de:      	leaq	0x18(%rsp), %rdx
     2e3:      	movl	$0x2, %eax
     2e8:      	xorl	%ecx, %ecx
     2ea:      	callq	*%rax
     2ec:      	cmpl	$0x6, (%r14)
     2f0:      	je	0x303 <tg_tp_cgrp_mkdir+0x303>
     2f2:      	xorl	%eax, %eax
     2f4:      	addq	$0x38, %rsp
     2f8:      	popq	%rbx
     2f9:      	popq	%r12
     2fb:      	popq	%r13
     2fd:      	popq	%r14
     2ff:      	popq	%r15
     301:      	popq	%rbp
     302:      	retq
     303:      	movq	0x30(%rsp), %rbp
     308:      	movl	$0x0, 0x2c(%rsp)
     310:      	movq	(%rip), %rdi            # 0x317 <tg_tp_cgrp_mkdir+0x317>
     317:      	leaq	0x2c(%rsp), %rsi
     31c:      	movl	$0x1, %eax
     321:      	callq	*%rax
     323:      	testq	%rax, %rax
     326:      	je	0x2f2 <tg_tp_cgrp_mkdir+0x2f2>
     328:      	movq	%rax, %r14
     32b:      	movb	$0x19, (%rax)
     32e:      	movl	$0x10d8, 0x4(%rax)      # imm = 0x10D8
     335:      	movq	0x8(%rbx), %r12
     339:      	movl	$0xe, %eax
     33e:      	callq	*%rax
     340:      	movq	%rax, %r13
     343:      	shrq	$0x20, %r13
     347:      	movl	%r13d, 0x8(%rsp)
     34c:      	movq	(%rip), %rdi            # 0x353 <tg_tp_cgrp_mkdir+0x353>
     353:      	leaq	0x8(%rsp), %rsi
     358:      	movl	$0x1, %eax
     35d:      	callq	*%rax
     35f:      	testq	%rax, %rax
     362:      	je	0x38b <tg_tp_cgrp_mkdir+0x38b>
     364:      	movq	0x8(%rax), %rcx
     368:      	movq	%rcx, 0x8(%r14)
     36c:      	movq	0x10(%rax), %rcx
     370:      	movq	0x18(%rax), %rdx
     374:      	movq	%rcx, 0x10(%r14)
     378:      	movq	%rdx, 0x18(%r14)
     37c:      	movl	0x20(%rax), %ecx
     37f:      	movl	%ecx, 0x2c(%r14)
     383:      	movq	0x8(%rax), %rax
     387:      	movq	%rax, 0x30(%r14)
     38b:      	movl	$0x1, 0x20(%r14)
     393:      	movl	%r13d, 0x24(%r14)
     397:      	movl	$0x23, %eax
     39c:      	callq	*%rax
     39e:      	leaq	0x60(%rax), %rdx
     3a2:      	leaq	0x18(%rsp), %rdi
     3a7:      	movl	$0x8, %ecx
     3ac:      	movl	$0x71, %eax
     3b1:      	movl	$0x8, %esi
     3b6:      	callq	*%rax
     3b8:      	movq	0x18(%rsp), %rcx
     3bd:      	xorl	%r13d, %r13d
     3c0:      	testq	%rcx, %rcx
     3c3:      	je	0x433 <tg_tp_cgrp_mkdir+0x433>
     3c5:      	addq	$0x4, %rcx
     3c9:      	leaq	0x24(%rsp), %rdi
     3ce:      	movl	$0x4, %edx
     3d3:      	movl	$0x71, %eax
     3d8:      	movq	0x18(%rsp), %rdx
     3dd:      	addq	$0x4, %rdx
     3e1:      	movl	$0x4, %esi
     3e6:      	callq	*%rax
     3e8:      	movl	0x24(%rsp), %eax
     3ec:      	testl	%eax, %eax
     3ee:      	je	0x433 <tg_tp_cgrp_mkdir+0x433>
     3f0:      	movq	0x18(%rsp), %rcx
     3f5:      	shll	$0x4, %eax
     3f8:      	addq	%rax, %rcx
     3fb:      	addq	$0x80, %rcx
     402:      	leaq	0x8(%rsp), %rdi
     407:      	movl	$0x10, %edx
     40c:      	movl	$0x71, %eax
     411:      	movq	0x18(%rsp), %rcx
     416:      	movl	0x24(%rsp), %edx
     41a:      	shll	$0x4, %edx
     41d:      	addq	%rcx, %rdx
     420:      	addq	$0x80, %rdx
     427:      	movl	$0x10, %esi
     42c:      	callq	*%rax
     42e:      	movl	0x8(%rsp), %r13d
     433:      	movl	%r13d, 0x28(%r14)
     437:      	movq	%rbp, 0x40(%r14)
     43b:      	movq	%rbp, 0x38(%r14)
     43f:      	movl	(%r15), %eax
     442:      	movl	%eax, 0x48(%r14)
     446:      	movl	0x8(%r15), %eax
     44a:      	movl	%eax, 0x50(%r14)
     44e:      	movl	0x4(%r15), %eax
     452:      	movl	%eax, 0x4c(%r14)
     456:      	leaq	0x58(%r14), %rdi
     45a:      	addq	$0x10, %r15
     45e:      	movl	$0x20, %ecx
     463:      	movq	%r15, %rsi
     466:      	rep		movsl	(%rsi), %es:(%rdi)
     468:      	movq	%r14, %rdi
     46b:      	addq	$0xd8, %rdi
     472:      	movl	$0xfff, %ecx            # imm = 0xFFF
     477:      	movl	$0x2d, %eax
     47c:      	movl	$0xfff, %esi            # imm = 0xFFF
     481:      	movq	%r12, %rdx
     484:      	callq	*%rax
     486:      	movl	$0x0, 0x18(%rsp)
     48e:      	movq	(%rip), %rdi            # 0x495 <tg_tp_cgrp_mkdir+0x495>
     495:      	leaq	0x18(%rsp), %rsi
     49a:      	movl	$0x1, %eax
     49f:      	callq	*%rax
     4a1:      	testq	%rax, %rax
     4a4:      	je	0x52e <tg_tp_cgrp_mkdir+0x52e>
     4aa:      	cmpb	$0x0, 0x28(%rax)
     4ae:      	je	0x52e <tg_tp_cgrp_mkdir+0x52e>
     4b0:      	movq	(%rip), %rsi            # 0x4b7 <tg_tp_cgrp_mkdir+0x4b7>
     4b7:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     4bc:      	movl	$0x10d8, %edx           # imm = 0x10D8
     4c1:      	movl	$0x19, %eax
     4c6:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     4cb:      	movl	$0x10d8, %r8d           # imm = 0x10D8
     4d1:      	movq	%rbx, %rdi
     4d4:      	movq	%r14, %rcx
     4d7:      	callq	*%rax
     4d9:      	testq	%rax, %rax
     4dc:      	jns	0x2f2 <tg_tp_cgrp_mkdir+0x2f2>
     4e2:      	movq	%rax, %rbx
     4e5:      	movl	$0x0, 0x8(%rsp)
     4ed:      	movq	(%rip), %rdi            # 0x4f4 <tg_tp_cgrp_mkdir+0x4f4>
     4f4:      	leaq	0x8(%rsp), %rsi
     4f9:      	movl	$0x1, %eax
     4fe:      	callq	*%rax
     500:      	testq	%rax, %rax
     503:      	je	0x2f2 <tg_tp_cgrp_mkdir+0x2f2>
     509:      	cmpq	$-0xc, %rbx
     50d:      	jg	0x5b2 <tg_tp_cgrp_mkdir+0x5b2>
     513:      	cmpq	$-0x1c, %rbx
     517:      	je	0x5cc <tg_tp_cgrp_mkdir+0x5cc>
     51d:      	cmpq	$-0x16, %rbx
     521:      	jne	0x58a <tg_tp_cgrp_mkdir+0x58a>
     523:      	addq	$0x598, %rax            # imm = 0x598
     529:      	jmp	0x5e2 <tg_tp_cgrp_mkdir+0x5e2>
     52e:      	movq	(%rip), %rdi            # 0x535 <tg_tp_cgrp_mkdir+0x535>
     535:      	xorl	%ecx, %ecx
     537:      	movl	$0x10d8, %edx           # imm = 0x10D8
     53c:      	movl	$0x82, %eax
     541:      	movq	%r14, %rsi
     544:      	xorl	%ecx, %ecx
     546:      	callq	*%rax
     548:      	testq	%rax, %rax
     54b:      	jns	0x2f2 <tg_tp_cgrp_mkdir+0x2f2>
     551:      	movq	%rax, %rbx
     554:      	movl	$0x0, 0x8(%rsp)
     55c:      	movq	(%rip), %rdi            # 0x563 <tg_tp_cgrp_mkdir+0x563>
     563:      	leaq	0x8(%rsp), %rsi
     568:      	movl	$0x1, %eax
     56d:      	callq	*%rax
     56f:      	testq	%rax, %rax
     572:      	je	0x2f2 <tg_tp_cgrp_mkdir+0x2f2>
     578:      	cmpq	$-0xc, %rbx
     57c:      	jg	0x598 <tg_tp_cgrp_mkdir+0x598>
     57e:      	cmpq	$-0x1c, %rbx
     582:      	je	0x5cc <tg_tp_cgrp_mkdir+0x5cc>
     584:      	cmpq	$-0x16, %rbx
     588:      	je	0x523 <tg_tp_cgrp_mkdir+0x523>
     58a:      	cmpq	$-0x10, %rbx
     58e:      	jne	0x5c4 <tg_tp_cgrp_mkdir+0x5c4>
     590:      	addq	$0x590, %rax            # imm = 0x590
     596:      	jmp	0x5e2 <tg_tp_cgrp_mkdir+0x5e2>
     598:      	cmpq	$-0xb, %rbx
     59c:      	je	0x5d4 <tg_tp_cgrp_mkdir+0x5d4>
     59e:      	cmpq	$-0x7, %rbx
     5a2:      	je	0x5dc <tg_tp_cgrp_mkdir+0x5dc>
     5a4:      	cmpq	$-0x2, %rbx
     5a8:      	jne	0x5c4 <tg_tp_cgrp_mkdir+0x5c4>
     5aa:      	addq	$0x580, %rax            # imm = 0x580
     5b0:      	jmp	0x5e2 <tg_tp_cgrp_mkdir+0x5e2>
     5b2:      	cmpq	$-0xb, %rbx
     5b6:      	je	0x5d4 <tg_tp_cgrp_mkdir+0x5d4>
     5b8:      	cmpq	$-0x7, %rbx
     5bc:      	je	0x5dc <tg_tp_cgrp_mkdir+0x5dc>
     5be:      	cmpq	$-0x2, %rbx
     5c2:      	je	0x5aa <tg_tp_cgrp_mkdir+0x5aa>
     5c4:      	addq	$0x578, %rax            # imm = 0x578
     5ca:      	jmp	0x5e2 <tg_tp_cgrp_mkdir+0x5e2>
     5cc:      	addq	$0x5a0, %rax            # imm = 0x5A0
     5d2:      	jmp	0x5e2 <tg_tp_cgrp_mkdir+0x5e2>
     5d4:      	addq	$0x5a8, %rax            # imm = 0x5A8
     5da:      	jmp	0x5e2 <tg_tp_cgrp_mkdir+0x5e2>
     5dc:      	addq	$0x588, %rax            # imm = 0x588
     5e2:      	lock
     5e3:      	incq	(%rax)
     5e6:      	jmp	0x2f2 <tg_tp_cgrp_mkdir+0x2f2>
