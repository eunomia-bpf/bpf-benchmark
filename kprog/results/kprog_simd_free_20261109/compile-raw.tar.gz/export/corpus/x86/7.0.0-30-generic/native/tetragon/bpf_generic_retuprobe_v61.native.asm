
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_generic_retuprobe_v61.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <filter_64ty>:
       0:      	pushq	%rax
       1:      	movl	0x4(%rdi), %ecx
       4:      	xorl	%eax, %eax
       6:      	cmpq	$0x20, %rcx
       a:      	ja	0x45 <filter_64ty+0x45>
       c:      	movl	$0x101e, %edx           # imm = 0x101E
      11:      	btq	%rcx, %rdx
      15:      	jae	0x1e <filter_64ty+0x1e>
      17:      	callq	0x140 <filter_64ty_selector_val>
      1c:      	popq	%rcx
      1d:      	retq
      1e:      	movl	$0xc00, %edx            # imm = 0xC00
      23:      	btq	%rcx, %rdx
      27:      	jb	0x40 <filter_64ty+0x40>
      29:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
      33:      	btq	%rcx, %rdx
      37:      	jae	0x45 <filter_64ty+0x45>
      39:      	callq	0x400 <filter_64ty_range>
      3e:      	popq	%rcx
      3f:      	retq
      40:      	callq	0x380 <filter_64ty_map>
      45:      	popq	%rcx
      46:      	retq
      47:      	nopw	(%rax,%rax)

0000000000000050 <filter_32ty>:
      50:      	pushq	%rax
      51:      	movl	0x4(%rdi), %ecx
      54:      	xorl	%eax, %eax
      56:      	cmpq	$0x20, %rcx
      5a:      	ja	0x95 <filter_32ty+0x45>
      5c:      	movl	$0x101e, %edx           # imm = 0x101E
      61:      	btq	%rcx, %rdx
      65:      	jae	0x6e <filter_32ty+0x1e>
      67:      	callq	0x5e0 <filter_32ty_selector_val>
      6c:      	popq	%rcx
      6d:      	retq
      6e:      	movl	$0xc00, %edx            # imm = 0xC00
      73:      	btq	%rcx, %rdx
      77:      	jb	0x90 <filter_32ty+0x40>
      79:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
      83:      	btq	%rcx, %rdx
      87:      	jae	0x95 <filter_32ty+0x45>
      89:      	callq	0x890 <filter_32ty_range>
      8e:      	popq	%rcx
      8f:      	retq
      90:      	callq	0x800 <filter_32ty_map>
      95:      	popq	%rcx
      96:      	retq
      97:      	nopw	(%rax,%rax)

00000000000000a0 <filter_16ty>:
      a0:      	pushq	%rax
      a1:      	movl	0x4(%rdi), %ecx
      a4:      	xorl	%eax, %eax
      a6:      	cmpq	$0x20, %rcx
      aa:      	ja	0xe5 <filter_16ty+0x45>
      ac:      	movl	$0x101e, %edx           # imm = 0x101E
      b1:      	btq	%rcx, %rdx
      b5:      	jae	0xbe <filter_16ty+0x1e>
      b7:      	callq	0xa50 <filter_16ty_selector_val>
      bc:      	popq	%rcx
      bd:      	retq
      be:      	movl	$0xc00, %edx            # imm = 0xC00
      c3:      	btq	%rcx, %rdx
      c7:      	jb	0xe0 <filter_16ty+0x40>
      c9:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
      d3:      	btq	%rcx, %rdx
      d7:      	jae	0xe5 <filter_16ty+0x45>
      d9:      	callq	0xd00 <filter_16ty_range>
      de:      	popq	%rcx
      df:      	retq
      e0:      	callq	0xc70 <filter_16ty_map>
      e5:      	popq	%rcx
      e6:      	retq
      e7:      	nopw	(%rax,%rax)

00000000000000f0 <filter_8ty>:
      f0:      	pushq	%rax
      f1:      	movl	0x4(%rdi), %ecx
      f4:      	xorl	%eax, %eax
      f6:      	cmpq	$0x20, %rcx
      fa:      	ja	0x135 <filter_8ty+0x45>
      fc:      	movl	$0x101e, %edx           # imm = 0x101E
     101:      	btq	%rcx, %rdx
     105:      	jae	0x10e <filter_8ty+0x1e>
     107:      	callq	0xec0 <filter_8ty_selector_val>
     10c:      	popq	%rcx
     10d:      	retq
     10e:      	movl	$0xc00, %edx            # imm = 0xC00
     113:      	btq	%rcx, %rdx
     117:      	jb	0x130 <filter_8ty+0x40>
     119:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
     123:      	btq	%rcx, %rdx
     127:      	jae	0x135 <filter_8ty+0x45>
     129:      	callq	0x1170 <filter_8ty_range>
     12e:      	popq	%rcx
     12f:      	retq
     130:      	callq	0x10e0 <filter_8ty_map>
     135:      	popq	%rcx
     136:      	retq
     137:      	nopw	(%rax,%rax)

0000000000000140 <filter_64ty_selector_val>:
     140:      	movl	0x4(%rdi), %ecx
     143:      	movl	$0x1, %eax
     148:      	cmpq	$0x25, %rcx
     14c:      	ja	0x1c4 <filter_64ty_selector_val+0x84>
     14e:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     158:      	btq	%rcx, %rdx
     15c:      	jae	0x15f <filter_64ty_selector_val+0x1f>
     15e:      	retq
     15f:      	movl	$0x18, %edx
     164:      	btq	%rcx, %rdx
     168:      	jae	0x180 <filter_64ty_selector_val+0x40>
     16a:      	movq	(%rsi), %rdx
     16d:      	cmpq	0x10(%rdi), %rdx
     171:      	jne	0x2a2 <filter_64ty_selector_val+0x162>
     177:      	xorl	%eax, %eax
     179:      	cmpl	$0x3, %ecx
     17c:      	sete	%al
     17f:      	retq
     180:      	cmpq	$0xc, %rcx
     184:      	jne	0x1c4 <filter_64ty_selector_val+0x84>
     186:      	movq	(%rsi), %rcx
     189:      	testq	%rcx, 0x10(%rdi)
     18d:      	jne	0x15e <filter_64ty_selector_val+0x1e>
     18f:      	movl	0x8(%rdi), %edx
     192:      	cmpl	$0x11, %edx
     195:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     19b:      	testq	%rcx, 0x18(%rdi)
     19f:      	jne	0x15e <filter_64ty_selector_val+0x1e>
     1a1:      	cmpl	$0x19, %edx
     1a4:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     1aa:      	testq	%rcx, 0x20(%rdi)
     1ae:      	jne	0x15e <filter_64ty_selector_val+0x1e>
     1b0:      	cmpl	$0x21, %edx
     1b3:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     1b9:      	testq	%rcx, 0x28(%rdi)
     1bd:      	jne	0x15e <filter_64ty_selector_val+0x1e>
     1bf:      	jmp	0x36f <filter_64ty_selector_val+0x22f>
     1c4:      	cmpl	$0x1, %ecx
     1c7:      	je	0x23a <filter_64ty_selector_val+0xfa>
     1c9:      	cmpl	$0x2, %ecx
     1cc:      	jne	0x36f <filter_64ty_selector_val+0x22f>
     1d2:      	movl	0xc(%rdi), %ecx
     1d5:      	cmpl	$0xc, %ecx
     1d8:      	ja	0x332 <filter_64ty_selector_val+0x1f2>
     1de:      	movl	$0x1402, %edx           # imm = 0x1402
     1e3:      	btl	%ecx, %edx
     1e6:      	jae	0x332 <filter_64ty_selector_val+0x1f2>
     1ec:      	movq	(%rsi), %rcx
     1ef:      	cmpq	0x10(%rdi), %rcx
     1f3:      	jl	0x15e <filter_64ty_selector_val+0x1e>
     1f9:      	movl	0x8(%rdi), %edx
     1fc:      	cmpl	$0x11, %edx
     1ff:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     205:      	cmpq	0x18(%rdi), %rcx
     209:      	jl	0x15e <filter_64ty_selector_val+0x1e>
     20f:      	cmpl	$0x19, %edx
     212:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     218:      	cmpq	0x20(%rdi), %rcx
     21c:      	jl	0x15e <filter_64ty_selector_val+0x1e>
     222:      	cmpl	$0x21, %edx
     225:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     22b:      	cmpq	0x28(%rdi), %rcx
     22f:      	jl	0x15e <filter_64ty_selector_val+0x1e>
     235:      	jmp	0x36f <filter_64ty_selector_val+0x22f>
     23a:      	movl	0xc(%rdi), %ecx
     23d:      	cmpl	$0xc, %ecx
     240:      	ja	0x2f3 <filter_64ty_selector_val+0x1b3>
     246:      	movl	$0x1402, %edx           # imm = 0x1402
     24b:      	btl	%ecx, %edx
     24e:      	jae	0x2f3 <filter_64ty_selector_val+0x1b3>
     254:      	movq	(%rsi), %rcx
     257:      	cmpq	0x10(%rdi), %rcx
     25b:      	jg	0x15e <filter_64ty_selector_val+0x1e>
     261:      	movl	0x8(%rdi), %edx
     264:      	cmpl	$0x11, %edx
     267:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     26d:      	cmpq	0x18(%rdi), %rcx
     271:      	jg	0x15e <filter_64ty_selector_val+0x1e>
     277:      	cmpl	$0x19, %edx
     27a:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     280:      	cmpq	0x20(%rdi), %rcx
     284:      	jg	0x15e <filter_64ty_selector_val+0x1e>
     28a:      	cmpl	$0x21, %edx
     28d:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     293:      	cmpq	0x28(%rdi), %rcx
     297:      	jg	0x15e <filter_64ty_selector_val+0x1e>
     29d:      	jmp	0x36f <filter_64ty_selector_val+0x22f>
     2a2:      	movl	0x8(%rdi), %esi
     2a5:      	cmpl	$0x11, %esi
     2a8:      	jb	0x2d2 <filter_64ty_selector_val+0x192>
     2aa:      	cmpq	0x18(%rdi), %rdx
     2ae:      	je	0x177 <filter_64ty_selector_val+0x37>
     2b4:      	cmpl	$0x19, %esi
     2b7:      	jb	0x2d2 <filter_64ty_selector_val+0x192>
     2b9:      	cmpq	0x20(%rdi), %rdx
     2bd:      	je	0x177 <filter_64ty_selector_val+0x37>
     2c3:      	cmpl	$0x21, %esi
     2c6:      	jb	0x2d2 <filter_64ty_selector_val+0x192>
     2c8:      	cmpq	0x28(%rdi), %rdx
     2cc:      	je	0x177 <filter_64ty_selector_val+0x37>
     2d2:      	cmpl	$0x25, %ecx
     2d5:      	ja	0x36f <filter_64ty_selector_val+0x22f>
     2db:      	movl	%ecx, %ecx
     2dd:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     2e7:      	btq	%rcx, %rdx
     2eb:      	jb	0x15e <filter_64ty_selector_val+0x1e>
     2f1:      	jmp	0x36f <filter_64ty_selector_val+0x22f>
     2f3:      	movq	(%rsi), %rcx
     2f6:      	cmpq	0x10(%rdi), %rcx
     2fa:      	ja	0x15e <filter_64ty_selector_val+0x1e>
     300:      	movl	0x8(%rdi), %edx
     303:      	cmpl	$0x11, %edx
     306:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     308:      	cmpq	0x18(%rdi), %rcx
     30c:      	ja	0x15e <filter_64ty_selector_val+0x1e>
     312:      	cmpl	$0x19, %edx
     315:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     317:      	cmpq	0x20(%rdi), %rcx
     31b:      	ja	0x15e <filter_64ty_selector_val+0x1e>
     321:      	cmpl	$0x21, %edx
     324:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     326:      	cmpq	0x28(%rdi), %rcx
     32a:      	ja	0x15e <filter_64ty_selector_val+0x1e>
     330:      	jmp	0x36f <filter_64ty_selector_val+0x22f>
     332:      	movq	(%rsi), %rcx
     335:      	cmpq	0x10(%rdi), %rcx
     339:      	jb	0x15e <filter_64ty_selector_val+0x1e>
     33f:      	movl	0x8(%rdi), %edx
     342:      	cmpl	$0x11, %edx
     345:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     347:      	cmpq	0x18(%rdi), %rcx
     34b:      	jb	0x15e <filter_64ty_selector_val+0x1e>
     351:      	cmpl	$0x19, %edx
     354:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     356:      	cmpq	0x20(%rdi), %rcx
     35a:      	jb	0x15e <filter_64ty_selector_val+0x1e>
     360:      	cmpl	$0x21, %edx
     363:      	jb	0x36f <filter_64ty_selector_val+0x22f>
     365:      	cmpq	0x28(%rdi), %rcx
     369:      	jb	0x15e <filter_64ty_selector_val+0x1e>
     36f:      	xorl	%eax, %eax
     371:      	retq
     372:      	nopw	%cs:(%rax,%rax)

0000000000000380 <filter_64ty_map>:
     380:      	pushq	%r14
     382:      	pushq	%rbx
     383:      	subq	$0x18, %rsp
     387:      	movq	%rsi, %r14
     38a:      	movq	%rdi, %rbx
     38d:      	movzbl	0x10(%rdi), %eax
     391:      	movl	%eax, 0xc(%rsp)
     395:      	movq	(%rip), %rdi            # 0x39c <filter_64ty_map+0x1c>
     39c:      	leaq	0xc(%rsp), %rsi
     3a1:      	movl	$0x1, %eax
     3a6:      	callq	*%rax
     3a8:      	testq	%rax, %rax
     3ab:      	je	0x3d9 <filter_64ty_map+0x59>
     3ad:      	movq	%rax, %rdi
     3b0:      	movq	(%r14), %rax
     3b3:      	movq	%rax, 0x10(%rsp)
     3b8:      	leaq	0x10(%rsp), %rsi
     3bd:      	movl	$0x1, %eax
     3c2:      	callq	*%rax
     3c4:      	movl	0x4(%rbx), %ecx
     3c7:      	cmpl	$0xb, %ecx
     3ca:      	je	0x3e3 <filter_64ty_map+0x63>
     3cc:      	cmpl	$0xa, %ecx
     3cf:      	jne	0x3eb <filter_64ty_map+0x6b>
     3d1:      	testq	%rax, %rax
     3d4:      	setne	%al
     3d7:      	jmp	0x3ed <filter_64ty_map+0x6d>
     3d9:      	xorl	%eax, %eax
     3db:      	addq	$0x18, %rsp
     3df:      	popq	%rbx
     3e0:      	popq	%r14
     3e2:      	retq
     3e3:      	testq	%rax, %rax
     3e6:      	sete	%al
     3e9:      	jmp	0x3ed <filter_64ty_map+0x6d>
     3eb:      	xorl	%eax, %eax
     3ed:      	movzbl	%al, %eax
     3f0:      	addq	$0x18, %rsp
     3f4:      	popq	%rbx
     3f5:      	popq	%r14
     3f7:      	retq
     3f8:      	nopl	(%rax,%rax)

0000000000000400 <filter_64ty_range>:
     400:      	movl	0x4(%rdi), %ecx
     403:      	movl	0xc(%rdi), %eax
     406:      	cmpl	$0xc, %eax
     409:      	ja	0x500 <filter_64ty_range+0x100>
     40f:      	movl	$0x1402, %edx           # imm = 0x1402
     414:      	btl	%eax, %edx
     417:      	jae	0x500 <filter_64ty_range+0x100>
     41d:      	movq	(%rsi), %rsi
     420:      	cmpl	$0x1f, %ecx
     423:      	jne	0x493 <filter_64ty_range+0x93>
     425:      	movl	$0x1, %eax
     42a:      	cmpq	%rsi, 0x10(%rdi)
     42e:      	jg	0x43a <filter_64ty_range+0x3a>
     430:      	cmpq	0x18(%rdi), %rsi
     434:      	jle	0x519 <filter_64ty_range+0x119>
     43a:      	movl	0x8(%rdi), %edx
     43d:      	cmpl	$0x19, %edx
     440:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     446:      	cmpq	%rsi, 0x20(%rdi)
     44a:      	jg	0x456 <filter_64ty_range+0x56>
     44c:      	cmpq	0x28(%rdi), %rsi
     450:      	jle	0x519 <filter_64ty_range+0x119>
     456:      	cmpl	$0x29, %edx
     459:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     45f:      	cmpq	%rsi, 0x30(%rdi)
     463:      	jg	0x46f <filter_64ty_range+0x6f>
     465:      	cmpq	0x38(%rdi), %rsi
     469:      	jle	0x519 <filter_64ty_range+0x119>
     46f:      	cmpl	$0x39, %edx
     472:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     478:      	xorl	%edx, %edx
     47a:      	cmpq	%rsi, 0x40(%rdi)
     47e:      	jg	0x5c9 <filter_64ty_range+0x1c9>
     484:      	cmpq	0x48(%rdi), %rsi
     488:      	jle	0x519 <filter_64ty_range+0x119>
     48e:      	jmp	0x5c9 <filter_64ty_range+0x1c9>
     493:      	movl	0x8(%rdi), %eax
     496:      	cmpq	%rsi, 0x10(%rdi)
     49a:      	setle	%r8b
     49e:      	cmpq	0x18(%rdi), %rsi
     4a2:      	setle	%dl
     4a5:      	andb	%r8b, %dl
     4a8:      	cmpl	$0x19, %eax
     4ab:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     4b1:      	cmpq	%rsi, 0x20(%rdi)
     4b5:      	setle	%r8b
     4b9:      	cmpq	0x28(%rdi), %rsi
     4bd:      	setle	%r9b
     4c1:      	andb	%r8b, %r9b
     4c4:      	orb	%r9b, %dl
     4c7:      	cmpl	$0x29, %eax
     4ca:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     4d0:      	cmpq	%rsi, 0x30(%rdi)
     4d4:      	setle	%r8b
     4d8:      	cmpq	0x38(%rdi), %rsi
     4dc:      	setle	%r9b
     4e0:      	andb	%r8b, %r9b
     4e3:      	orb	%r9b, %dl
     4e6:      	cmpl	$0x39, %eax
     4e9:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     4ef:      	cmpq	%rsi, 0x40(%rdi)
     4f3:      	setle	%al
     4f6:      	cmpq	0x48(%rdi), %rsi
     4fa:      	setle	%sil
     4fe:      	jmp	0x57d <filter_64ty_range+0x17d>
     500:      	movq	(%rsi), %rsi
     503:      	cmpl	$0x1f, %ecx
     506:      	jne	0x51a <filter_64ty_range+0x11a>
     508:      	movl	$0x1, %eax
     50d:      	cmpq	%rsi, 0x10(%rdi)
     511:      	ja	0x585 <filter_64ty_range+0x185>
     513:      	cmpq	0x18(%rdi), %rsi
     517:      	ja	0x585 <filter_64ty_range+0x185>
     519:      	retq
     51a:      	movl	0x8(%rdi), %eax
     51d:      	cmpq	%rsi, 0x10(%rdi)
     521:      	setbe	%r8b
     525:      	cmpq	0x18(%rdi), %rsi
     529:      	setbe	%dl
     52c:      	andb	%r8b, %dl
     52f:      	cmpl	$0x19, %eax
     532:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     538:      	cmpq	%rsi, 0x20(%rdi)
     53c:      	setbe	%r8b
     540:      	cmpq	0x28(%rdi), %rsi
     544:      	setbe	%r9b
     548:      	andb	%r8b, %r9b
     54b:      	orb	%r9b, %dl
     54e:      	cmpl	$0x29, %eax
     551:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     553:      	cmpq	%rsi, 0x30(%rdi)
     557:      	setbe	%r8b
     55b:      	cmpq	0x38(%rdi), %rsi
     55f:      	setbe	%r9b
     563:      	andb	%r8b, %r9b
     566:      	orb	%r9b, %dl
     569:      	cmpl	$0x39, %eax
     56c:      	jb	0x5c9 <filter_64ty_range+0x1c9>
     56e:      	cmpq	%rsi, 0x40(%rdi)
     572:      	setbe	%al
     575:      	cmpq	0x48(%rdi), %rsi
     579:      	setbe	%sil
     57d:      	andb	%al, %sil
     580:      	orb	%sil, %dl
     583:      	jmp	0x5c9 <filter_64ty_range+0x1c9>
     585:      	movl	0x8(%rdi), %edx
     588:      	cmpl	$0x19, %edx
     58b:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     58d:      	cmpq	%rsi, 0x20(%rdi)
     591:      	ja	0x599 <filter_64ty_range+0x199>
     593:      	cmpq	0x28(%rdi), %rsi
     597:      	jbe	0x519 <filter_64ty_range+0x119>
     599:      	cmpl	$0x29, %edx
     59c:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     59e:      	cmpq	%rsi, 0x30(%rdi)
     5a2:      	ja	0x5ae <filter_64ty_range+0x1ae>
     5a4:      	cmpq	0x38(%rdi), %rsi
     5a8:      	jbe	0x519 <filter_64ty_range+0x119>
     5ae:      	cmpl	$0x39, %edx
     5b1:      	jb	0x5c7 <filter_64ty_range+0x1c7>
     5b3:      	xorl	%edx, %edx
     5b5:      	cmpq	%rsi, 0x40(%rdi)
     5b9:      	ja	0x5c9 <filter_64ty_range+0x1c9>
     5bb:      	cmpq	0x48(%rdi), %rsi
     5bf:      	jbe	0x519 <filter_64ty_range+0x119>
     5c5:      	jmp	0x5c9 <filter_64ty_range+0x1c9>
     5c7:      	xorl	%edx, %edx
     5c9:      	cmpl	$0x20, %ecx
     5cc:      	sete	%al
     5cf:      	xorb	$0x1, %dl
     5d2:      	andb	%al, %dl
     5d4:      	movzbl	%dl, %eax
     5d7:      	retq
     5d8:      	nopl	(%rax,%rax)

00000000000005e0 <filter_32ty_selector_val>:
     5e0:      	movl	0x4(%rdi), %ecx
     5e3:      	movl	$0x1, %eax
     5e8:      	cmpq	$0x25, %rcx
     5ec:      	ja	0x65d <filter_32ty_selector_val+0x7d>
     5ee:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     5f8:      	btq	%rcx, %rdx
     5fc:      	jae	0x5ff <filter_32ty_selector_val+0x1f>
     5fe:      	retq
     5ff:      	movl	$0x18, %edx
     604:      	btq	%rcx, %rdx
     608:      	jae	0x61e <filter_32ty_selector_val+0x3e>
     60a:      	movl	(%rsi), %edx
     60c:      	cmpl	0x10(%rdi), %edx
     60f:      	jne	0x731 <filter_32ty_selector_val+0x151>
     615:      	xorl	%eax, %eax
     617:      	cmpl	$0x3, %ecx
     61a:      	sete	%al
     61d:      	retq
     61e:      	cmpq	$0xc, %rcx
     622:      	jne	0x65d <filter_32ty_selector_val+0x7d>
     624:      	movl	(%rsi), %ecx
     626:      	testl	%ecx, 0x10(%rdi)
     629:      	jne	0x5fe <filter_32ty_selector_val+0x1e>
     62b:      	movl	0x8(%rdi), %edx
     62e:      	cmpl	$0xd, %edx
     631:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     637:      	testl	%ecx, 0x14(%rdi)
     63a:      	jne	0x5fe <filter_32ty_selector_val+0x1e>
     63c:      	cmpl	$0x11, %edx
     63f:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     645:      	testl	%ecx, 0x18(%rdi)
     648:      	jne	0x5fe <filter_32ty_selector_val+0x1e>
     64a:      	cmpl	$0x15, %edx
     64d:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     653:      	testl	%ecx, 0x1c(%rdi)
     656:      	jne	0x5fe <filter_32ty_selector_val+0x1e>
     658:      	jmp	0x7f1 <filter_32ty_selector_val+0x211>
     65d:      	cmpl	$0x1, %ecx
     660:      	je	0x6ce <filter_32ty_selector_val+0xee>
     662:      	cmpl	$0x2, %ecx
     665:      	jne	0x7f1 <filter_32ty_selector_val+0x211>
     66b:      	movl	0xc(%rdi), %ecx
     66e:      	cmpl	$0xc, %ecx
     671:      	ja	0x7b9 <filter_32ty_selector_val+0x1d9>
     677:      	movl	$0x1402, %edx           # imm = 0x1402
     67c:      	btl	%ecx, %edx
     67f:      	jae	0x7b9 <filter_32ty_selector_val+0x1d9>
     685:      	movl	(%rsi), %ecx
     687:      	cmpl	0x10(%rdi), %ecx
     68a:      	jl	0x5fe <filter_32ty_selector_val+0x1e>
     690:      	movl	0x8(%rdi), %edx
     693:      	cmpl	$0xd, %edx
     696:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     69c:      	cmpl	0x14(%rdi), %ecx
     69f:      	jl	0x5fe <filter_32ty_selector_val+0x1e>
     6a5:      	cmpl	$0x11, %edx
     6a8:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     6ae:      	cmpl	0x18(%rdi), %ecx
     6b1:      	jl	0x5fe <filter_32ty_selector_val+0x1e>
     6b7:      	cmpl	$0x15, %edx
     6ba:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     6c0:      	cmpl	0x1c(%rdi), %ecx
     6c3:      	jl	0x5fe <filter_32ty_selector_val+0x1e>
     6c9:      	jmp	0x7f1 <filter_32ty_selector_val+0x211>
     6ce:      	movl	0xc(%rdi), %ecx
     6d1:      	cmpl	$0xc, %ecx
     6d4:      	ja	0x77f <filter_32ty_selector_val+0x19f>
     6da:      	movl	$0x1402, %edx           # imm = 0x1402
     6df:      	btl	%ecx, %edx
     6e2:      	jae	0x77f <filter_32ty_selector_val+0x19f>
     6e8:      	movl	(%rsi), %ecx
     6ea:      	cmpl	0x10(%rdi), %ecx
     6ed:      	jg	0x5fe <filter_32ty_selector_val+0x1e>
     6f3:      	movl	0x8(%rdi), %edx
     6f6:      	cmpl	$0xd, %edx
     6f9:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     6ff:      	cmpl	0x14(%rdi), %ecx
     702:      	jg	0x5fe <filter_32ty_selector_val+0x1e>
     708:      	cmpl	$0x11, %edx
     70b:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     711:      	cmpl	0x18(%rdi), %ecx
     714:      	jg	0x5fe <filter_32ty_selector_val+0x1e>
     71a:      	cmpl	$0x15, %edx
     71d:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     723:      	cmpl	0x1c(%rdi), %ecx
     726:      	jg	0x5fe <filter_32ty_selector_val+0x1e>
     72c:      	jmp	0x7f1 <filter_32ty_selector_val+0x211>
     731:      	movl	0x8(%rdi), %esi
     734:      	cmpl	$0xd, %esi
     737:      	jb	0x75e <filter_32ty_selector_val+0x17e>
     739:      	cmpl	0x14(%rdi), %edx
     73c:      	je	0x615 <filter_32ty_selector_val+0x35>
     742:      	cmpl	$0x11, %esi
     745:      	jb	0x75e <filter_32ty_selector_val+0x17e>
     747:      	cmpl	0x18(%rdi), %edx
     74a:      	je	0x615 <filter_32ty_selector_val+0x35>
     750:      	cmpl	$0x15, %esi
     753:      	jb	0x75e <filter_32ty_selector_val+0x17e>
     755:      	cmpl	0x1c(%rdi), %edx
     758:      	je	0x615 <filter_32ty_selector_val+0x35>
     75e:      	cmpl	$0x25, %ecx
     761:      	ja	0x7f1 <filter_32ty_selector_val+0x211>
     767:      	movl	%ecx, %ecx
     769:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     773:      	btq	%rcx, %rdx
     777:      	jb	0x5fe <filter_32ty_selector_val+0x1e>
     77d:      	jmp	0x7f1 <filter_32ty_selector_val+0x211>
     77f:      	movl	(%rsi), %ecx
     781:      	cmpl	0x10(%rdi), %ecx
     784:      	ja	0x5fe <filter_32ty_selector_val+0x1e>
     78a:      	movl	0x8(%rdi), %edx
     78d:      	cmpl	$0xd, %edx
     790:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     792:      	cmpl	0x14(%rdi), %ecx
     795:      	ja	0x5fe <filter_32ty_selector_val+0x1e>
     79b:      	cmpl	$0x11, %edx
     79e:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     7a0:      	cmpl	0x18(%rdi), %ecx
     7a3:      	ja	0x5fe <filter_32ty_selector_val+0x1e>
     7a9:      	cmpl	$0x15, %edx
     7ac:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     7ae:      	cmpl	0x1c(%rdi), %ecx
     7b1:      	ja	0x5fe <filter_32ty_selector_val+0x1e>
     7b7:      	jmp	0x7f1 <filter_32ty_selector_val+0x211>
     7b9:      	movl	(%rsi), %ecx
     7bb:      	cmpl	0x10(%rdi), %ecx
     7be:      	jb	0x5fe <filter_32ty_selector_val+0x1e>
     7c4:      	movl	0x8(%rdi), %edx
     7c7:      	cmpl	$0xd, %edx
     7ca:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     7cc:      	cmpl	0x14(%rdi), %ecx
     7cf:      	jb	0x5fe <filter_32ty_selector_val+0x1e>
     7d5:      	cmpl	$0x11, %edx
     7d8:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     7da:      	cmpl	0x18(%rdi), %ecx
     7dd:      	jb	0x5fe <filter_32ty_selector_val+0x1e>
     7e3:      	cmpl	$0x15, %edx
     7e6:      	jb	0x7f1 <filter_32ty_selector_val+0x211>
     7e8:      	cmpl	0x1c(%rdi), %ecx
     7eb:      	jb	0x5fe <filter_32ty_selector_val+0x1e>
     7f1:      	xorl	%eax, %eax
     7f3:      	retq
     7f4:      	nopw	%cs:(%rax,%rax)

0000000000000800 <filter_32ty_map>:
     800:      	pushq	%r14
     802:      	pushq	%rbx
     803:      	subq	$0x18, %rsp
     807:      	movq	%rsi, %r14
     80a:      	movq	%rdi, %rbx
     80d:      	movzbl	0x10(%rdi), %eax
     811:      	movl	%eax, 0xc(%rsp)
     815:      	movq	(%rip), %rdi            # 0x81c <filter_32ty_map+0x1c>
     81c:      	leaq	0xc(%rsp), %rsi
     821:      	movl	$0x1, %eax
     826:      	callq	*%rax
     828:      	testq	%rax, %rax
     82b:      	je	0x860 <filter_32ty_map+0x60>
     82d:      	movq	%rax, %rdi
     830:      	movl	(%r14), %eax
     833:      	movq	%rax, 0x10(%rsp)
     838:      	leaq	0x10(%rsp), %rsi
     83d:      	movl	$0x1, %eax
     842:      	callq	*%rax
     844:      	movl	0x4(%rbx), %edx
     847:      	xorl	%ecx, %ecx
     849:      	cmpl	$0x1d, %edx
     84c:      	ja	0x87a <filter_32ty_map+0x7a>
     84e:      	movl	$0x30038400, %esi       # imm = 0x30038400
     853:      	btl	%edx, %esi
     856:      	jae	0x86a <filter_32ty_map+0x6a>
     858:      	testq	%rax, %rax
     85b:      	setne	%cl
     85e:      	jmp	0x87a <filter_32ty_map+0x7a>
     860:      	xorl	%eax, %eax
     862:      	addq	$0x18, %rsp
     866:      	popq	%rbx
     867:      	popq	%r14
     869:      	retq
     86a:      	movl	$0xc0800, %esi          # imm = 0xC0800
     86f:      	btl	%edx, %esi
     872:      	jae	0x87a <filter_32ty_map+0x7a>
     874:      	testq	%rax, %rax
     877:      	sete	%cl
     87a:      	movzbl	%cl, %eax
     87d:      	addq	$0x18, %rsp
     881:      	popq	%rbx
     882:      	popq	%r14
     884:      	retq
     885:      	nopw	%cs:(%rax,%rax)

0000000000000890 <filter_32ty_range>:
     890:      	movl	0x4(%rdi), %ecx
     893:      	movl	0xc(%rdi), %eax
     896:      	cmpl	$0xc, %eax
     899:      	ja	0x97f <filter_32ty_range+0xef>
     89f:      	movl	$0x1402, %edx           # imm = 0x1402
     8a4:      	btl	%eax, %edx
     8a7:      	jae	0x97f <filter_32ty_range+0xef>
     8ad:      	movl	(%rsi), %esi
     8af:      	cmpl	$0x1f, %ecx
     8b2:      	jne	0x91a <filter_32ty_range+0x8a>
     8b4:      	movl	$0x1, %eax
     8b9:      	cmpl	%esi, 0x10(%rdi)
     8bc:      	jg	0x8c7 <filter_32ty_range+0x37>
     8be:      	cmpl	0x14(%rdi), %esi
     8c1:      	jle	0x995 <filter_32ty_range+0x105>
     8c7:      	movl	0x8(%rdi), %edx
     8ca:      	cmpl	$0x11, %edx
     8cd:      	jb	0xa35 <filter_32ty_range+0x1a5>
     8d3:      	cmpl	%esi, 0x18(%rdi)
     8d6:      	jg	0x8e1 <filter_32ty_range+0x51>
     8d8:      	cmpl	0x1c(%rdi), %esi
     8db:      	jle	0x995 <filter_32ty_range+0x105>
     8e1:      	cmpl	$0x19, %edx
     8e4:      	jb	0xa35 <filter_32ty_range+0x1a5>
     8ea:      	cmpl	%esi, 0x20(%rdi)
     8ed:      	jg	0x8f8 <filter_32ty_range+0x68>
     8ef:      	cmpl	0x24(%rdi), %esi
     8f2:      	jle	0x995 <filter_32ty_range+0x105>
     8f8:      	cmpl	$0x21, %edx
     8fb:      	jb	0xa35 <filter_32ty_range+0x1a5>
     901:      	xorl	%edx, %edx
     903:      	cmpl	%esi, 0x28(%rdi)
     906:      	jg	0xa37 <filter_32ty_range+0x1a7>
     90c:      	cmpl	0x2c(%rdi), %esi
     90f:      	jle	0x995 <filter_32ty_range+0x105>
     915:      	jmp	0xa37 <filter_32ty_range+0x1a7>
     91a:      	movl	0x8(%rdi), %eax
     91d:      	cmpl	%esi, 0x10(%rdi)
     920:      	setle	%r8b
     924:      	cmpl	0x14(%rdi), %esi
     927:      	setle	%dl
     92a:      	andb	%r8b, %dl
     92d:      	cmpl	$0x11, %eax
     930:      	jb	0xa37 <filter_32ty_range+0x1a7>
     936:      	cmpl	%esi, 0x18(%rdi)
     939:      	setle	%r8b
     93d:      	cmpl	0x1c(%rdi), %esi
     940:      	setle	%r9b
     944:      	andb	%r8b, %r9b
     947:      	orb	%r9b, %dl
     94a:      	cmpl	$0x19, %eax
     94d:      	jb	0xa37 <filter_32ty_range+0x1a7>
     953:      	cmpl	%esi, 0x20(%rdi)
     956:      	setle	%r8b
     95a:      	cmpl	0x24(%rdi), %esi
     95d:      	setle	%r9b
     961:      	andb	%r8b, %r9b
     964:      	orb	%r9b, %dl
     967:      	cmpl	$0x21, %eax
     96a:      	jb	0xa37 <filter_32ty_range+0x1a7>
     970:      	cmpl	%esi, 0x28(%rdi)
     973:      	setle	%al
     976:      	cmpl	0x2c(%rdi), %esi
     979:      	setle	%sil
     97d:      	jmp	0x9f1 <filter_32ty_range+0x161>
     97f:      	movl	(%rsi), %esi
     981:      	cmpl	$0x1f, %ecx
     984:      	jne	0x996 <filter_32ty_range+0x106>
     986:      	movl	$0x1, %eax
     98b:      	cmpl	%esi, 0x10(%rdi)
     98e:      	ja	0x9f9 <filter_32ty_range+0x169>
     990:      	cmpl	0x14(%rdi), %esi
     993:      	ja	0x9f9 <filter_32ty_range+0x169>
     995:      	retq
     996:      	movl	0x8(%rdi), %eax
     999:      	cmpl	%esi, 0x10(%rdi)
     99c:      	setbe	%r8b
     9a0:      	cmpl	0x14(%rdi), %esi
     9a3:      	setbe	%dl
     9a6:      	andb	%r8b, %dl
     9a9:      	cmpl	$0x11, %eax
     9ac:      	jb	0xa37 <filter_32ty_range+0x1a7>
     9b2:      	cmpl	%esi, 0x18(%rdi)
     9b5:      	setbe	%r8b
     9b9:      	cmpl	0x1c(%rdi), %esi
     9bc:      	setbe	%r9b
     9c0:      	andb	%r8b, %r9b
     9c3:      	orb	%r9b, %dl
     9c6:      	cmpl	$0x19, %eax
     9c9:      	jb	0xa37 <filter_32ty_range+0x1a7>
     9cb:      	cmpl	%esi, 0x20(%rdi)
     9ce:      	setbe	%r8b
     9d2:      	cmpl	0x24(%rdi), %esi
     9d5:      	setbe	%r9b
     9d9:      	andb	%r8b, %r9b
     9dc:      	orb	%r9b, %dl
     9df:      	cmpl	$0x21, %eax
     9e2:      	jb	0xa37 <filter_32ty_range+0x1a7>
     9e4:      	cmpl	%esi, 0x28(%rdi)
     9e7:      	setbe	%al
     9ea:      	cmpl	0x2c(%rdi), %esi
     9ed:      	setbe	%sil
     9f1:      	andb	%al, %sil
     9f4:      	orb	%sil, %dl
     9f7:      	jmp	0xa37 <filter_32ty_range+0x1a7>
     9f9:      	movl	0x8(%rdi), %edx
     9fc:      	cmpl	$0x11, %edx
     9ff:      	jb	0xa35 <filter_32ty_range+0x1a5>
     a01:      	cmpl	%esi, 0x18(%rdi)
     a04:      	ja	0xa0b <filter_32ty_range+0x17b>
     a06:      	cmpl	0x1c(%rdi), %esi
     a09:      	jbe	0x995 <filter_32ty_range+0x105>
     a0b:      	cmpl	$0x19, %edx
     a0e:      	jb	0xa35 <filter_32ty_range+0x1a5>
     a10:      	cmpl	%esi, 0x20(%rdi)
     a13:      	ja	0xa1e <filter_32ty_range+0x18e>
     a15:      	cmpl	0x24(%rdi), %esi
     a18:      	jbe	0x995 <filter_32ty_range+0x105>
     a1e:      	cmpl	$0x21, %edx
     a21:      	jb	0xa35 <filter_32ty_range+0x1a5>
     a23:      	xorl	%edx, %edx
     a25:      	cmpl	%esi, 0x28(%rdi)
     a28:      	ja	0xa37 <filter_32ty_range+0x1a7>
     a2a:      	cmpl	0x2c(%rdi), %esi
     a2d:      	jbe	0x995 <filter_32ty_range+0x105>
     a33:      	jmp	0xa37 <filter_32ty_range+0x1a7>
     a35:      	xorl	%edx, %edx
     a37:      	cmpl	$0x20, %ecx
     a3a:      	sete	%al
     a3d:      	xorb	$0x1, %dl
     a40:      	andb	%al, %dl
     a42:      	movzbl	%dl, %eax
     a45:      	retq
     a46:      	nopw	%cs:(%rax,%rax)

0000000000000a50 <filter_16ty_selector_val>:
     a50:      	movl	0x4(%rdi), %ecx
     a53:      	movl	$0x1, %eax
     a58:      	cmpq	$0x25, %rcx
     a5c:      	ja	0xacf <filter_16ty_selector_val+0x7f>
     a5e:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     a68:      	btq	%rcx, %rdx
     a6c:      	jae	0xa6f <filter_16ty_selector_val+0x1f>
     a6e:      	retq
     a6f:      	movl	$0x18, %edx
     a74:      	btq	%rcx, %rdx
     a78:      	jae	0xa8f <filter_16ty_selector_val+0x3f>
     a7a:      	movzwl	(%rsi), %edx
     a7d:      	cmpl	%edx, 0x10(%rdi)
     a80:      	jne	0xba5 <filter_16ty_selector_val+0x155>
     a86:      	xorl	%eax, %eax
     a88:      	cmpl	$0x3, %ecx
     a8b:      	sete	%al
     a8e:      	retq
     a8f:      	cmpq	$0xc, %rcx
     a93:      	jne	0xacf <filter_16ty_selector_val+0x7f>
     a95:      	movzwl	(%rsi), %ecx
     a98:      	testl	%ecx, 0x10(%rdi)
     a9b:      	jne	0xa6e <filter_16ty_selector_val+0x1e>
     a9d:      	movl	0x8(%rdi), %edx
     aa0:      	cmpl	$0xd, %edx
     aa3:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     aa9:      	testl	%ecx, 0x14(%rdi)
     aac:      	jne	0xa6e <filter_16ty_selector_val+0x1e>
     aae:      	cmpl	$0x11, %edx
     ab1:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     ab7:      	testl	%ecx, 0x18(%rdi)
     aba:      	jne	0xa6e <filter_16ty_selector_val+0x1e>
     abc:      	cmpl	$0x15, %edx
     abf:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     ac5:      	testl	%ecx, 0x1c(%rdi)
     ac8:      	jne	0xa6e <filter_16ty_selector_val+0x1e>
     aca:      	jmp	0xc67 <filter_16ty_selector_val+0x217>
     acf:      	cmpl	$0x1, %ecx
     ad2:      	je	0xb41 <filter_16ty_selector_val+0xf1>
     ad4:      	cmpl	$0x2, %ecx
     ad7:      	jne	0xc67 <filter_16ty_selector_val+0x217>
     add:      	movl	0xc(%rdi), %ecx
     ae0:      	cmpl	$0xc, %ecx
     ae3:      	ja	0xc2e <filter_16ty_selector_val+0x1de>
     ae9:      	movl	$0x1402, %edx           # imm = 0x1402
     aee:      	btl	%ecx, %edx
     af1:      	jae	0xc2e <filter_16ty_selector_val+0x1de>
     af7:      	movswl	(%rsi), %ecx
     afa:      	cmpl	%ecx, 0x10(%rdi)
     afd:      	jg	0xa6e <filter_16ty_selector_val+0x1e>
     b03:      	movl	0x8(%rdi), %edx
     b06:      	cmpl	$0xd, %edx
     b09:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b0f:      	cmpl	%ecx, 0x14(%rdi)
     b12:      	jg	0xa6e <filter_16ty_selector_val+0x1e>
     b18:      	cmpl	$0x11, %edx
     b1b:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b21:      	cmpl	%ecx, 0x18(%rdi)
     b24:      	jg	0xa6e <filter_16ty_selector_val+0x1e>
     b2a:      	cmpl	$0x15, %edx
     b2d:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b33:      	cmpl	%ecx, 0x1c(%rdi)
     b36:      	jg	0xa6e <filter_16ty_selector_val+0x1e>
     b3c:      	jmp	0xc67 <filter_16ty_selector_val+0x217>
     b41:      	movl	0xc(%rdi), %ecx
     b44:      	cmpl	$0xc, %ecx
     b47:      	ja	0xbf3 <filter_16ty_selector_val+0x1a3>
     b4d:      	movl	$0x1402, %edx           # imm = 0x1402
     b52:      	btl	%ecx, %edx
     b55:      	jae	0xbf3 <filter_16ty_selector_val+0x1a3>
     b5b:      	movswl	(%rsi), %ecx
     b5e:      	cmpl	%ecx, 0x10(%rdi)
     b61:      	jl	0xa6e <filter_16ty_selector_val+0x1e>
     b67:      	movl	0x8(%rdi), %edx
     b6a:      	cmpl	$0xd, %edx
     b6d:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b73:      	cmpl	%ecx, 0x14(%rdi)
     b76:      	jl	0xa6e <filter_16ty_selector_val+0x1e>
     b7c:      	cmpl	$0x11, %edx
     b7f:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b85:      	cmpl	%ecx, 0x18(%rdi)
     b88:      	jl	0xa6e <filter_16ty_selector_val+0x1e>
     b8e:      	cmpl	$0x15, %edx
     b91:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     b97:      	cmpl	%ecx, 0x1c(%rdi)
     b9a:      	jl	0xa6e <filter_16ty_selector_val+0x1e>
     ba0:      	jmp	0xc67 <filter_16ty_selector_val+0x217>
     ba5:      	movl	0x8(%rdi), %esi
     ba8:      	cmpl	$0xd, %esi
     bab:      	jb	0xbd2 <filter_16ty_selector_val+0x182>
     bad:      	cmpl	%edx, 0x14(%rdi)
     bb0:      	je	0xa86 <filter_16ty_selector_val+0x36>
     bb6:      	cmpl	$0x11, %esi
     bb9:      	jb	0xbd2 <filter_16ty_selector_val+0x182>
     bbb:      	cmpl	%edx, 0x18(%rdi)
     bbe:      	je	0xa86 <filter_16ty_selector_val+0x36>
     bc4:      	cmpl	$0x15, %esi
     bc7:      	jb	0xbd2 <filter_16ty_selector_val+0x182>
     bc9:      	cmpl	%edx, 0x1c(%rdi)
     bcc:      	je	0xa86 <filter_16ty_selector_val+0x36>
     bd2:      	cmpl	$0x25, %ecx
     bd5:      	ja	0xc67 <filter_16ty_selector_val+0x217>
     bdb:      	movl	%ecx, %ecx
     bdd:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
     be7:      	btq	%rcx, %rdx
     beb:      	jb	0xa6e <filter_16ty_selector_val+0x1e>
     bf1:      	jmp	0xc67 <filter_16ty_selector_val+0x217>
     bf3:      	movzwl	(%rsi), %ecx
     bf6:      	cmpl	%ecx, 0x10(%rdi)
     bf9:      	jb	0xa6e <filter_16ty_selector_val+0x1e>
     bff:      	movl	0x8(%rdi), %edx
     c02:      	cmpl	$0xd, %edx
     c05:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c07:      	cmpl	%ecx, 0x14(%rdi)
     c0a:      	jb	0xa6e <filter_16ty_selector_val+0x1e>
     c10:      	cmpl	$0x11, %edx
     c13:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c15:      	cmpl	%ecx, 0x18(%rdi)
     c18:      	jb	0xa6e <filter_16ty_selector_val+0x1e>
     c1e:      	cmpl	$0x15, %edx
     c21:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c23:      	cmpl	%ecx, 0x1c(%rdi)
     c26:      	jb	0xa6e <filter_16ty_selector_val+0x1e>
     c2c:      	jmp	0xc67 <filter_16ty_selector_val+0x217>
     c2e:      	movzwl	(%rsi), %ecx
     c31:      	cmpl	%ecx, 0x10(%rdi)
     c34:      	ja	0xa6e <filter_16ty_selector_val+0x1e>
     c3a:      	movl	0x8(%rdi), %edx
     c3d:      	cmpl	$0xd, %edx
     c40:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c42:      	cmpl	%ecx, 0x14(%rdi)
     c45:      	ja	0xa6e <filter_16ty_selector_val+0x1e>
     c4b:      	cmpl	$0x11, %edx
     c4e:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c50:      	cmpl	%ecx, 0x18(%rdi)
     c53:      	ja	0xa6e <filter_16ty_selector_val+0x1e>
     c59:      	cmpl	$0x15, %edx
     c5c:      	jb	0xc67 <filter_16ty_selector_val+0x217>
     c5e:      	cmpl	%ecx, 0x1c(%rdi)
     c61:      	ja	0xa6e <filter_16ty_selector_val+0x1e>
     c67:      	xorl	%eax, %eax
     c69:      	retq
     c6a:      	nopw	(%rax,%rax)

0000000000000c70 <filter_16ty_map>:
     c70:      	pushq	%r14
     c72:      	pushq	%rbx
     c73:      	subq	$0x18, %rsp
     c77:      	movq	%rsi, %r14
     c7a:      	movq	%rdi, %rbx
     c7d:      	movzbl	0x10(%rdi), %eax
     c81:      	movl	%eax, 0xc(%rsp)
     c85:      	movq	(%rip), %rdi            # 0xc8c <filter_16ty_map+0x1c>
     c8c:      	leaq	0xc(%rsp), %rsi
     c91:      	movl	$0x1, %eax
     c96:      	callq	*%rax
     c98:      	testq	%rax, %rax
     c9b:      	je	0xcd1 <filter_16ty_map+0x61>
     c9d:      	movq	%rax, %rdi
     ca0:      	movzwl	(%r14), %eax
     ca4:      	movq	%rax, 0x10(%rsp)
     ca9:      	leaq	0x10(%rsp), %rsi
     cae:      	movl	$0x1, %eax
     cb3:      	callq	*%rax
     cb5:      	movl	0x4(%rbx), %edx
     cb8:      	xorl	%ecx, %ecx
     cba:      	cmpl	$0x1d, %edx
     cbd:      	ja	0xceb <filter_16ty_map+0x7b>
     cbf:      	movl	$0x30038400, %esi       # imm = 0x30038400
     cc4:      	btl	%edx, %esi
     cc7:      	jae	0xcdb <filter_16ty_map+0x6b>
     cc9:      	testq	%rax, %rax
     ccc:      	setne	%cl
     ccf:      	jmp	0xceb <filter_16ty_map+0x7b>
     cd1:      	xorl	%eax, %eax
     cd3:      	addq	$0x18, %rsp
     cd7:      	popq	%rbx
     cd8:      	popq	%r14
     cda:      	retq
     cdb:      	movl	$0xc0800, %esi          # imm = 0xC0800
     ce0:      	btl	%edx, %esi
     ce3:      	jae	0xceb <filter_16ty_map+0x7b>
     ce5:      	testq	%rax, %rax
     ce8:      	sete	%cl
     ceb:      	movzbl	%cl, %eax
     cee:      	addq	$0x18, %rsp
     cf2:      	popq	%rbx
     cf3:      	popq	%r14
     cf5:      	retq
     cf6:      	nopw	%cs:(%rax,%rax)

0000000000000d00 <filter_16ty_range>:
     d00:      	movl	0x4(%rdi), %ecx
     d03:      	movl	0xc(%rdi), %eax
     d06:      	cmpl	$0xc, %eax
     d09:      	ja	0xdf0 <filter_16ty_range+0xf0>
     d0f:      	movl	$0x1402, %edx           # imm = 0x1402
     d14:      	btl	%eax, %edx
     d17:      	jae	0xdf0 <filter_16ty_range+0xf0>
     d1d:      	movswl	(%rsi), %esi
     d20:      	cmpl	$0x1f, %ecx
     d23:      	jne	0xd8b <filter_16ty_range+0x8b>
     d25:      	movl	$0x1, %eax
     d2a:      	cmpl	%esi, 0x10(%rdi)
     d2d:      	jg	0xd38 <filter_16ty_range+0x38>
     d2f:      	cmpl	%esi, 0x14(%rdi)
     d32:      	jge	0xe07 <filter_16ty_range+0x107>
     d38:      	movl	0x8(%rdi), %edx
     d3b:      	cmpl	$0x11, %edx
     d3e:      	jb	0xea7 <filter_16ty_range+0x1a7>
     d44:      	cmpl	%esi, 0x18(%rdi)
     d47:      	jg	0xd52 <filter_16ty_range+0x52>
     d49:      	cmpl	%esi, 0x1c(%rdi)
     d4c:      	jge	0xe07 <filter_16ty_range+0x107>
     d52:      	cmpl	$0x19, %edx
     d55:      	jb	0xea7 <filter_16ty_range+0x1a7>
     d5b:      	cmpl	%esi, 0x20(%rdi)
     d5e:      	jg	0xd69 <filter_16ty_range+0x69>
     d60:      	cmpl	%esi, 0x24(%rdi)
     d63:      	jge	0xe07 <filter_16ty_range+0x107>
     d69:      	cmpl	$0x21, %edx
     d6c:      	jb	0xea7 <filter_16ty_range+0x1a7>
     d72:      	xorl	%edx, %edx
     d74:      	cmpl	%esi, 0x28(%rdi)
     d77:      	jg	0xea9 <filter_16ty_range+0x1a9>
     d7d:      	cmpl	%esi, 0x2c(%rdi)
     d80:      	jge	0xe07 <filter_16ty_range+0x107>
     d86:      	jmp	0xea9 <filter_16ty_range+0x1a9>
     d8b:      	movl	0x8(%rdi), %eax
     d8e:      	cmpl	%esi, 0x10(%rdi)
     d91:      	setle	%r8b
     d95:      	cmpl	%esi, 0x14(%rdi)
     d98:      	setge	%dl
     d9b:      	andb	%r8b, %dl
     d9e:      	cmpl	$0x11, %eax
     da1:      	jb	0xea9 <filter_16ty_range+0x1a9>
     da7:      	cmpl	%esi, 0x18(%rdi)
     daa:      	setle	%r8b
     dae:      	cmpl	%esi, 0x1c(%rdi)
     db1:      	setge	%r9b
     db5:      	andb	%r8b, %r9b
     db8:      	orb	%r9b, %dl
     dbb:      	cmpl	$0x19, %eax
     dbe:      	jb	0xea9 <filter_16ty_range+0x1a9>
     dc4:      	cmpl	%esi, 0x20(%rdi)
     dc7:      	setle	%r8b
     dcb:      	cmpl	%esi, 0x24(%rdi)
     dce:      	setge	%r9b
     dd2:      	andb	%r8b, %r9b
     dd5:      	orb	%r9b, %dl
     dd8:      	cmpl	$0x21, %eax
     ddb:      	jb	0xea9 <filter_16ty_range+0x1a9>
     de1:      	cmpl	%esi, 0x28(%rdi)
     de4:      	setle	%al
     de7:      	cmpl	%esi, 0x2c(%rdi)
     dea:      	setge	%sil
     dee:      	jmp	0xe63 <filter_16ty_range+0x163>
     df0:      	movzwl	(%rsi), %esi
     df3:      	cmpl	$0x1f, %ecx
     df6:      	jne	0xe08 <filter_16ty_range+0x108>
     df8:      	movl	$0x1, %eax
     dfd:      	cmpl	%esi, 0x10(%rdi)
     e00:      	ja	0xe6b <filter_16ty_range+0x16b>
     e02:      	cmpl	%esi, 0x14(%rdi)
     e05:      	jb	0xe6b <filter_16ty_range+0x16b>
     e07:      	retq
     e08:      	movl	0x8(%rdi), %eax
     e0b:      	cmpl	%esi, 0x10(%rdi)
     e0e:      	setbe	%r8b
     e12:      	cmpl	%esi, 0x14(%rdi)
     e15:      	setae	%dl
     e18:      	andb	%r8b, %dl
     e1b:      	cmpl	$0x11, %eax
     e1e:      	jb	0xea9 <filter_16ty_range+0x1a9>
     e24:      	cmpl	%esi, 0x18(%rdi)
     e27:      	setbe	%r8b
     e2b:      	cmpl	%esi, 0x1c(%rdi)
     e2e:      	setae	%r9b
     e32:      	andb	%r8b, %r9b
     e35:      	orb	%r9b, %dl
     e38:      	cmpl	$0x19, %eax
     e3b:      	jb	0xea9 <filter_16ty_range+0x1a9>
     e3d:      	cmpl	%esi, 0x20(%rdi)
     e40:      	setbe	%r8b
     e44:      	cmpl	%esi, 0x24(%rdi)
     e47:      	setae	%r9b
     e4b:      	andb	%r8b, %r9b
     e4e:      	orb	%r9b, %dl
     e51:      	cmpl	$0x21, %eax
     e54:      	jb	0xea9 <filter_16ty_range+0x1a9>
     e56:      	cmpl	%esi, 0x28(%rdi)
     e59:      	setbe	%al
     e5c:      	cmpl	%esi, 0x2c(%rdi)
     e5f:      	setae	%sil
     e63:      	andb	%al, %sil
     e66:      	orb	%sil, %dl
     e69:      	jmp	0xea9 <filter_16ty_range+0x1a9>
     e6b:      	movl	0x8(%rdi), %edx
     e6e:      	cmpl	$0x11, %edx
     e71:      	jb	0xea7 <filter_16ty_range+0x1a7>
     e73:      	cmpl	%esi, 0x18(%rdi)
     e76:      	ja	0xe7d <filter_16ty_range+0x17d>
     e78:      	cmpl	%esi, 0x1c(%rdi)
     e7b:      	jae	0xe07 <filter_16ty_range+0x107>
     e7d:      	cmpl	$0x19, %edx
     e80:      	jb	0xea7 <filter_16ty_range+0x1a7>
     e82:      	cmpl	%esi, 0x20(%rdi)
     e85:      	ja	0xe90 <filter_16ty_range+0x190>
     e87:      	cmpl	%esi, 0x24(%rdi)
     e8a:      	jae	0xe07 <filter_16ty_range+0x107>
     e90:      	cmpl	$0x21, %edx
     e93:      	jb	0xea7 <filter_16ty_range+0x1a7>
     e95:      	xorl	%edx, %edx
     e97:      	cmpl	%esi, 0x28(%rdi)
     e9a:      	ja	0xea9 <filter_16ty_range+0x1a9>
     e9c:      	cmpl	%esi, 0x2c(%rdi)
     e9f:      	jae	0xe07 <filter_16ty_range+0x107>
     ea5:      	jmp	0xea9 <filter_16ty_range+0x1a9>
     ea7:      	xorl	%edx, %edx
     ea9:      	cmpl	$0x20, %ecx
     eac:      	sete	%al
     eaf:      	xorb	$0x1, %dl
     eb2:      	andb	%al, %dl
     eb4:      	movzbl	%dl, %eax
     eb7:      	retq
     eb8:      	nopl	(%rax,%rax)

0000000000000ec0 <filter_8ty_selector_val>:
     ec0:      	movl	0x4(%rdi), %ecx
     ec3:      	movl	$0x1, %eax
     ec8:      	cmpq	$0x25, %rcx
     ecc:      	ja	0xf3f <filter_8ty_selector_val+0x7f>
     ece:      	movabsq	$0x200c000040, %rdx     # imm = 0x200C000040
     ed8:      	btq	%rcx, %rdx
     edc:      	jae	0xedf <filter_8ty_selector_val+0x1f>
     ede:      	retq
     edf:      	movl	$0x18, %edx
     ee4:      	btq	%rcx, %rdx
     ee8:      	jae	0xeff <filter_8ty_selector_val+0x3f>
     eea:      	movzbl	(%rsi), %edx
     eed:      	cmpl	%edx, 0x10(%rdi)
     ef0:      	jne	0x1015 <filter_8ty_selector_val+0x155>
     ef6:      	xorl	%eax, %eax
     ef8:      	cmpl	$0x3, %ecx
     efb:      	sete	%al
     efe:      	retq
     eff:      	cmpq	$0xc, %rcx
     f03:      	jne	0xf3f <filter_8ty_selector_val+0x7f>
     f05:      	movzbl	(%rsi), %ecx
     f08:      	testl	%ecx, 0x10(%rdi)
     f0b:      	jne	0xede <filter_8ty_selector_val+0x1e>
     f0d:      	movl	0x8(%rdi), %edx
     f10:      	cmpl	$0xd, %edx
     f13:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     f19:      	testl	%ecx, 0x14(%rdi)
     f1c:      	jne	0xede <filter_8ty_selector_val+0x1e>
     f1e:      	cmpl	$0x11, %edx
     f21:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     f27:      	testl	%ecx, 0x18(%rdi)
     f2a:      	jne	0xede <filter_8ty_selector_val+0x1e>
     f2c:      	cmpl	$0x15, %edx
     f2f:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     f35:      	testl	%ecx, 0x1c(%rdi)
     f38:      	jne	0xede <filter_8ty_selector_val+0x1e>
     f3a:      	jmp	0x10d7 <filter_8ty_selector_val+0x217>
     f3f:      	cmpl	$0x1, %ecx
     f42:      	je	0xfb1 <filter_8ty_selector_val+0xf1>
     f44:      	cmpl	$0x2, %ecx
     f47:      	jne	0x10d7 <filter_8ty_selector_val+0x217>
     f4d:      	movl	0xc(%rdi), %ecx
     f50:      	cmpl	$0xc, %ecx
     f53:      	ja	0x109e <filter_8ty_selector_val+0x1de>
     f59:      	movl	$0x1402, %edx           # imm = 0x1402
     f5e:      	btl	%ecx, %edx
     f61:      	jae	0x109e <filter_8ty_selector_val+0x1de>
     f67:      	movsbl	(%rsi), %ecx
     f6a:      	cmpl	%ecx, 0x10(%rdi)
     f6d:      	jg	0xede <filter_8ty_selector_val+0x1e>
     f73:      	movl	0x8(%rdi), %edx
     f76:      	cmpl	$0xd, %edx
     f79:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     f7f:      	cmpl	%ecx, 0x14(%rdi)
     f82:      	jg	0xede <filter_8ty_selector_val+0x1e>
     f88:      	cmpl	$0x11, %edx
     f8b:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     f91:      	cmpl	%ecx, 0x18(%rdi)
     f94:      	jg	0xede <filter_8ty_selector_val+0x1e>
     f9a:      	cmpl	$0x15, %edx
     f9d:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     fa3:      	cmpl	%ecx, 0x1c(%rdi)
     fa6:      	jg	0xede <filter_8ty_selector_val+0x1e>
     fac:      	jmp	0x10d7 <filter_8ty_selector_val+0x217>
     fb1:      	movl	0xc(%rdi), %ecx
     fb4:      	cmpl	$0xc, %ecx
     fb7:      	ja	0x1063 <filter_8ty_selector_val+0x1a3>
     fbd:      	movl	$0x1402, %edx           # imm = 0x1402
     fc2:      	btl	%ecx, %edx
     fc5:      	jae	0x1063 <filter_8ty_selector_val+0x1a3>
     fcb:      	movsbl	(%rsi), %ecx
     fce:      	cmpl	%ecx, 0x10(%rdi)
     fd1:      	jl	0xede <filter_8ty_selector_val+0x1e>
     fd7:      	movl	0x8(%rdi), %edx
     fda:      	cmpl	$0xd, %edx
     fdd:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     fe3:      	cmpl	%ecx, 0x14(%rdi)
     fe6:      	jl	0xede <filter_8ty_selector_val+0x1e>
     fec:      	cmpl	$0x11, %edx
     fef:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
     ff5:      	cmpl	%ecx, 0x18(%rdi)
     ff8:      	jl	0xede <filter_8ty_selector_val+0x1e>
     ffe:      	cmpl	$0x15, %edx
    1001:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    1007:      	cmpl	%ecx, 0x1c(%rdi)
    100a:      	jl	0xede <filter_8ty_selector_val+0x1e>
    1010:      	jmp	0x10d7 <filter_8ty_selector_val+0x217>
    1015:      	movl	0x8(%rdi), %esi
    1018:      	cmpl	$0xd, %esi
    101b:      	jb	0x1042 <filter_8ty_selector_val+0x182>
    101d:      	cmpl	%edx, 0x14(%rdi)
    1020:      	je	0xef6 <filter_8ty_selector_val+0x36>
    1026:      	cmpl	$0x11, %esi
    1029:      	jb	0x1042 <filter_8ty_selector_val+0x182>
    102b:      	cmpl	%edx, 0x18(%rdi)
    102e:      	je	0xef6 <filter_8ty_selector_val+0x36>
    1034:      	cmpl	$0x15, %esi
    1037:      	jb	0x1042 <filter_8ty_selector_val+0x182>
    1039:      	cmpl	%edx, 0x1c(%rdi)
    103c:      	je	0xef6 <filter_8ty_selector_val+0x36>
    1042:      	cmpl	$0x25, %ecx
    1045:      	ja	0x10d7 <filter_8ty_selector_val+0x217>
    104b:      	movl	%ecx, %ecx
    104d:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1057:      	btq	%rcx, %rdx
    105b:      	jb	0xede <filter_8ty_selector_val+0x1e>
    1061:      	jmp	0x10d7 <filter_8ty_selector_val+0x217>
    1063:      	movzbl	(%rsi), %ecx
    1066:      	cmpl	%ecx, 0x10(%rdi)
    1069:      	jb	0xede <filter_8ty_selector_val+0x1e>
    106f:      	movl	0x8(%rdi), %edx
    1072:      	cmpl	$0xd, %edx
    1075:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    1077:      	cmpl	%ecx, 0x14(%rdi)
    107a:      	jb	0xede <filter_8ty_selector_val+0x1e>
    1080:      	cmpl	$0x11, %edx
    1083:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    1085:      	cmpl	%ecx, 0x18(%rdi)
    1088:      	jb	0xede <filter_8ty_selector_val+0x1e>
    108e:      	cmpl	$0x15, %edx
    1091:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    1093:      	cmpl	%ecx, 0x1c(%rdi)
    1096:      	jb	0xede <filter_8ty_selector_val+0x1e>
    109c:      	jmp	0x10d7 <filter_8ty_selector_val+0x217>
    109e:      	movzbl	(%rsi), %ecx
    10a1:      	cmpl	%ecx, 0x10(%rdi)
    10a4:      	ja	0xede <filter_8ty_selector_val+0x1e>
    10aa:      	movl	0x8(%rdi), %edx
    10ad:      	cmpl	$0xd, %edx
    10b0:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    10b2:      	cmpl	%ecx, 0x14(%rdi)
    10b5:      	ja	0xede <filter_8ty_selector_val+0x1e>
    10bb:      	cmpl	$0x11, %edx
    10be:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    10c0:      	cmpl	%ecx, 0x18(%rdi)
    10c3:      	ja	0xede <filter_8ty_selector_val+0x1e>
    10c9:      	cmpl	$0x15, %edx
    10cc:      	jb	0x10d7 <filter_8ty_selector_val+0x217>
    10ce:      	cmpl	%ecx, 0x1c(%rdi)
    10d1:      	ja	0xede <filter_8ty_selector_val+0x1e>
    10d7:      	xorl	%eax, %eax
    10d9:      	retq
    10da:      	nopw	(%rax,%rax)

00000000000010e0 <filter_8ty_map>:
    10e0:      	pushq	%r14
    10e2:      	pushq	%rbx
    10e3:      	subq	$0x18, %rsp
    10e7:      	movq	%rsi, %r14
    10ea:      	movq	%rdi, %rbx
    10ed:      	movzbl	0x10(%rdi), %eax
    10f1:      	movl	%eax, 0xc(%rsp)
    10f5:      	movq	(%rip), %rdi            # 0x10fc <filter_8ty_map+0x1c>
    10fc:      	leaq	0xc(%rsp), %rsi
    1101:      	movl	$0x1, %eax
    1106:      	callq	*%rax
    1108:      	testq	%rax, %rax
    110b:      	je	0x1141 <filter_8ty_map+0x61>
    110d:      	movq	%rax, %rdi
    1110:      	movzbl	(%r14), %eax
    1114:      	movq	%rax, 0x10(%rsp)
    1119:      	leaq	0x10(%rsp), %rsi
    111e:      	movl	$0x1, %eax
    1123:      	callq	*%rax
    1125:      	movl	0x4(%rbx), %edx
    1128:      	xorl	%ecx, %ecx
    112a:      	cmpl	$0x1d, %edx
    112d:      	ja	0x115b <filter_8ty_map+0x7b>
    112f:      	movl	$0x30038400, %esi       # imm = 0x30038400
    1134:      	btl	%edx, %esi
    1137:      	jae	0x114b <filter_8ty_map+0x6b>
    1139:      	testq	%rax, %rax
    113c:      	setne	%cl
    113f:      	jmp	0x115b <filter_8ty_map+0x7b>
    1141:      	xorl	%eax, %eax
    1143:      	addq	$0x18, %rsp
    1147:      	popq	%rbx
    1148:      	popq	%r14
    114a:      	retq
    114b:      	movl	$0xc0800, %esi          # imm = 0xC0800
    1150:      	btl	%edx, %esi
    1153:      	jae	0x115b <filter_8ty_map+0x7b>
    1155:      	testq	%rax, %rax
    1158:      	sete	%cl
    115b:      	movzbl	%cl, %eax
    115e:      	addq	$0x18, %rsp
    1162:      	popq	%rbx
    1163:      	popq	%r14
    1165:      	retq
    1166:      	nopw	%cs:(%rax,%rax)

0000000000001170 <filter_8ty_range>:
    1170:      	movl	0x4(%rdi), %ecx
    1173:      	movl	0xc(%rdi), %eax
    1176:      	cmpl	$0xc, %eax
    1179:      	ja	0x1260 <filter_8ty_range+0xf0>
    117f:      	movl	$0x1402, %edx           # imm = 0x1402
    1184:      	btl	%eax, %edx
    1187:      	jae	0x1260 <filter_8ty_range+0xf0>
    118d:      	movsbl	(%rsi), %esi
    1190:      	cmpl	$0x1f, %ecx
    1193:      	jne	0x11fb <filter_8ty_range+0x8b>
    1195:      	movl	$0x1, %eax
    119a:      	cmpl	%esi, 0x10(%rdi)
    119d:      	jg	0x11a8 <filter_8ty_range+0x38>
    119f:      	cmpl	%esi, 0x14(%rdi)
    11a2:      	jge	0x1277 <filter_8ty_range+0x107>
    11a8:      	movl	0x8(%rdi), %edx
    11ab:      	cmpl	$0x11, %edx
    11ae:      	jb	0x1317 <filter_8ty_range+0x1a7>
    11b4:      	cmpl	%esi, 0x18(%rdi)
    11b7:      	jg	0x11c2 <filter_8ty_range+0x52>
    11b9:      	cmpl	%esi, 0x1c(%rdi)
    11bc:      	jge	0x1277 <filter_8ty_range+0x107>
    11c2:      	cmpl	$0x19, %edx
    11c5:      	jb	0x1317 <filter_8ty_range+0x1a7>
    11cb:      	cmpl	%esi, 0x20(%rdi)
    11ce:      	jg	0x11d9 <filter_8ty_range+0x69>
    11d0:      	cmpl	%esi, 0x24(%rdi)
    11d3:      	jge	0x1277 <filter_8ty_range+0x107>
    11d9:      	cmpl	$0x21, %edx
    11dc:      	jb	0x1317 <filter_8ty_range+0x1a7>
    11e2:      	xorl	%edx, %edx
    11e4:      	cmpl	%esi, 0x28(%rdi)
    11e7:      	jg	0x1319 <filter_8ty_range+0x1a9>
    11ed:      	cmpl	%esi, 0x2c(%rdi)
    11f0:      	jge	0x1277 <filter_8ty_range+0x107>
    11f6:      	jmp	0x1319 <filter_8ty_range+0x1a9>
    11fb:      	movl	0x8(%rdi), %eax
    11fe:      	cmpl	%esi, 0x10(%rdi)
    1201:      	setle	%r8b
    1205:      	cmpl	%esi, 0x14(%rdi)
    1208:      	setge	%dl
    120b:      	andb	%r8b, %dl
    120e:      	cmpl	$0x11, %eax
    1211:      	jb	0x1319 <filter_8ty_range+0x1a9>
    1217:      	cmpl	%esi, 0x18(%rdi)
    121a:      	setle	%r8b
    121e:      	cmpl	%esi, 0x1c(%rdi)
    1221:      	setge	%r9b
    1225:      	andb	%r8b, %r9b
    1228:      	orb	%r9b, %dl
    122b:      	cmpl	$0x19, %eax
    122e:      	jb	0x1319 <filter_8ty_range+0x1a9>
    1234:      	cmpl	%esi, 0x20(%rdi)
    1237:      	setle	%r8b
    123b:      	cmpl	%esi, 0x24(%rdi)
    123e:      	setge	%r9b
    1242:      	andb	%r8b, %r9b
    1245:      	orb	%r9b, %dl
    1248:      	cmpl	$0x21, %eax
    124b:      	jb	0x1319 <filter_8ty_range+0x1a9>
    1251:      	cmpl	%esi, 0x28(%rdi)
    1254:      	setle	%al
    1257:      	cmpl	%esi, 0x2c(%rdi)
    125a:      	setge	%sil
    125e:      	jmp	0x12d3 <filter_8ty_range+0x163>
    1260:      	movzbl	(%rsi), %esi
    1263:      	cmpl	$0x1f, %ecx
    1266:      	jne	0x1278 <filter_8ty_range+0x108>
    1268:      	movl	$0x1, %eax
    126d:      	cmpl	%esi, 0x10(%rdi)
    1270:      	ja	0x12db <filter_8ty_range+0x16b>
    1272:      	cmpl	%esi, 0x14(%rdi)
    1275:      	jb	0x12db <filter_8ty_range+0x16b>
    1277:      	retq
    1278:      	movl	0x8(%rdi), %eax
    127b:      	cmpl	%esi, 0x10(%rdi)
    127e:      	setbe	%r8b
    1282:      	cmpl	%esi, 0x14(%rdi)
    1285:      	setae	%dl
    1288:      	andb	%r8b, %dl
    128b:      	cmpl	$0x11, %eax
    128e:      	jb	0x1319 <filter_8ty_range+0x1a9>
    1294:      	cmpl	%esi, 0x18(%rdi)
    1297:      	setbe	%r8b
    129b:      	cmpl	%esi, 0x1c(%rdi)
    129e:      	setae	%r9b
    12a2:      	andb	%r8b, %r9b
    12a5:      	orb	%r9b, %dl
    12a8:      	cmpl	$0x19, %eax
    12ab:      	jb	0x1319 <filter_8ty_range+0x1a9>
    12ad:      	cmpl	%esi, 0x20(%rdi)
    12b0:      	setbe	%r8b
    12b4:      	cmpl	%esi, 0x24(%rdi)
    12b7:      	setae	%r9b
    12bb:      	andb	%r8b, %r9b
    12be:      	orb	%r9b, %dl
    12c1:      	cmpl	$0x21, %eax
    12c4:      	jb	0x1319 <filter_8ty_range+0x1a9>
    12c6:      	cmpl	%esi, 0x28(%rdi)
    12c9:      	setbe	%al
    12cc:      	cmpl	%esi, 0x2c(%rdi)
    12cf:      	setae	%sil
    12d3:      	andb	%al, %sil
    12d6:      	orb	%sil, %dl
    12d9:      	jmp	0x1319 <filter_8ty_range+0x1a9>
    12db:      	movl	0x8(%rdi), %edx
    12de:      	cmpl	$0x11, %edx
    12e1:      	jb	0x1317 <filter_8ty_range+0x1a7>
    12e3:      	cmpl	%esi, 0x18(%rdi)
    12e6:      	ja	0x12ed <filter_8ty_range+0x17d>
    12e8:      	cmpl	%esi, 0x1c(%rdi)
    12eb:      	jae	0x1277 <filter_8ty_range+0x107>
    12ed:      	cmpl	$0x19, %edx
    12f0:      	jb	0x1317 <filter_8ty_range+0x1a7>
    12f2:      	cmpl	%esi, 0x20(%rdi)
    12f5:      	ja	0x1300 <filter_8ty_range+0x190>
    12f7:      	cmpl	%esi, 0x24(%rdi)
    12fa:      	jae	0x1277 <filter_8ty_range+0x107>
    1300:      	cmpl	$0x21, %edx
    1303:      	jb	0x1317 <filter_8ty_range+0x1a7>
    1305:      	xorl	%edx, %edx
    1307:      	cmpl	%esi, 0x28(%rdi)
    130a:      	ja	0x1319 <filter_8ty_range+0x1a9>
    130c:      	cmpl	%esi, 0x2c(%rdi)
    130f:      	jae	0x1277 <filter_8ty_range+0x107>
    1315:      	jmp	0x1319 <filter_8ty_range+0x1a9>
    1317:      	xorl	%edx, %edx
    1319:      	cmpl	$0x20, %ecx
    131c:      	sete	%al
    131f:      	xorb	$0x1, %dl
    1322:      	andb	%al, %dl
    1324:      	movzbl	%dl, %eax
    1327:      	retq
    1328:      	nopl	(%rax,%rax)

0000000000001330 <filter_file_buf>:
    1330:      	pushq	%rbx
    1331:      	movq	%rdi, %rbx
    1334:      	movl	(%rsi), %edx
    1336:      	movl	0x4(%rdi), %ecx
    1339:      	testl	%edx, %edx
    133b:      	jne	0x134b <filter_file_buf+0x1b>
    133d:      	movl	%ecx, %eax
    133f:      	andl	$-0x2, %eax
    1342:      	cmpl	$0x24, %eax
    1345:      	je	0x134b <filter_file_buf+0x1b>
    1347:      	xorl	%eax, %eax
    1349:      	popq	%rbx
    134a:      	retq
    134b:      	cmpl	$0x25, %ecx
    134e:      	ja	0x138a <filter_file_buf+0x5a>
    1350:      	movl	%ecx, %eax
    1352:      	movl	$0x4000100, %edi        # imm = 0x4000100
    1357:      	btq	%rax, %rdi
    135b:      	jb	0x13be <filter_file_buf+0x8e>
    135d:      	movl	$0x8000200, %edi        # imm = 0x8000200
    1362:      	btq	%rax, %rdi
    1366:      	jb	0x13a8 <filter_file_buf+0x78>
    1368:      	movabsq	$0x3000000000, %rdi     # imm = 0x3000000000
    1372:      	btq	%rax, %rdi
    1376:      	jae	0x138a <filter_file_buf+0x5a>
    1378:      	movq	%rbx, %rdi
    137b:      	callq	0x1e20 <filter_file_type>
    1380:      	movl	0x4(%rbx), %ecx
    1383:      	cmpl	$0x25, %ecx
    1386:      	jbe	0x13db <filter_file_buf+0xab>
    1388:      	jmp	0x13f1 <filter_file_buf+0xc1>
    138a:      	leal	-0x3(%rcx), %eax
    138d:      	cmpl	$0x2, %eax
    1390:      	jae	0x13d4 <filter_file_buf+0xa4>
    1392:      	addq	$0x4, %rsi
    1396:      	movq	%rbx, %rdi
    1399:      	callq	0x18b0 <filter_char_buf_equal>
    139e:      	movl	0x4(%rbx), %ecx
    13a1:      	cmpl	$0x25, %ecx
    13a4:      	jbe	0x13db <filter_file_buf+0xab>
    13a6:      	jmp	0x13f1 <filter_file_buf+0xc1>
    13a8:      	addq	$0x4, %rsi
    13ac:      	movl	0x10(%rbx), %edi
    13af:      	callq	0x1cd0 <filter_char_buf_postfix>
    13b4:      	movl	0x4(%rbx), %ecx
    13b7:      	cmpl	$0x25, %ecx
    13ba:      	jbe	0x13db <filter_file_buf+0xab>
    13bc:      	jmp	0x13f1 <filter_file_buf+0xc1>
    13be:      	addq	$0x4, %rsi
    13c2:      	movl	0x10(%rbx), %edi
    13c5:      	callq	0x1c30 <filter_char_buf_prefix>
    13ca:      	movl	0x4(%rbx), %ecx
    13cd:      	cmpl	$0x25, %ecx
    13d0:      	jbe	0x13db <filter_file_buf+0xab>
    13d2:      	jmp	0x13f1 <filter_file_buf+0xc1>
    13d4:      	xorl	%eax, %eax
    13d6:      	cmpl	$0x25, %ecx
    13d9:      	ja	0x13f1 <filter_file_buf+0xc1>
    13db:      	movl	%ecx, %ecx
    13dd:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    13e7:      	btq	%rcx, %rdx
    13eb:      	jae	0x13f1 <filter_file_buf+0xc1>
    13ed:      	xorq	$0x1, %rax
    13f1:      	popq	%rbx
    13f2:      	retq
    13f3:      	nopw	%cs:(%rax,%rax)

0000000000001400 <filter_char_buf>:
    1400:      	pushq	%rbx
    1401:      	movq	%rsi, %rax
    1404:      	movq	%rdi, %rbx
    1407:      	movslq	%edx, %rcx
    140a:      	movl	-0x4(%rsi,%rcx), %edx
    140e:      	movl	%ecx, %esi
    1410:      	addq	%rax, %rsi
    1413:      	movl	0x4(%rdi), %ecx
    1416:      	xorl	%eax, %eax
    1418:      	cmpl	$0x19, %ecx
    141b:      	jg	0x1431 <filter_char_buf+0x31>
    141d:      	leal	-0x3(%rcx), %edi
    1420:      	cmpl	$0x2, %edi
    1423:      	jb	0x1468 <filter_char_buf+0x68>
    1425:      	cmpl	$0x8, %ecx
    1428:      	je	0x145e <filter_char_buf+0x5e>
    142a:      	cmpl	$0x9, %ecx
    142d:      	je	0x1440 <filter_char_buf+0x40>
    142f:      	jmp	0x147f <filter_char_buf+0x7f>
    1431:      	cmpl	$0x20, %ecx
    1434:      	jg	0x144a <filter_char_buf+0x4a>
    1436:      	cmpl	$0x1a, %ecx
    1439:      	je	0x145e <filter_char_buf+0x5e>
    143b:      	cmpl	$0x1b, %ecx
    143e:      	jne	0x147f <filter_char_buf+0x7f>
    1440:      	movl	0x10(%rbx), %edi
    1443:      	callq	0x1cd0 <filter_char_buf_postfix>
    1448:      	jmp	0x147c <filter_char_buf+0x7c>
    144a:      	cmpl	$0x21, %ecx
    144d:      	je	0x1472 <filter_char_buf+0x72>
    144f:      	cmpl	$0x22, %ecx
    1452:      	jne	0x147f <filter_char_buf+0x7f>
    1454:      	movq	%rbx, %rdi
    1457:      	movl	$0x1, %ecx
    145c:      	jmp	0x1477 <filter_char_buf+0x77>
    145e:      	movl	0x10(%rbx), %edi
    1461:      	callq	0x1c30 <filter_char_buf_prefix>
    1466:      	jmp	0x147c <filter_char_buf+0x7c>
    1468:      	movq	%rbx, %rdi
    146b:      	callq	0x18b0 <filter_char_buf_equal>
    1470:      	jmp	0x147c <filter_char_buf+0x7c>
    1472:      	movq	%rbx, %rdi
    1475:      	xorl	%ecx, %ecx
    1477:      	callq	0x1ed0 <filter_char_substring>
    147c:      	movl	0x4(%rbx), %ecx
    147f:      	cmpl	$0x25, %ecx
    1482:      	ja	0x14a1 <filter_char_buf+0xa1>
    1484:      	movl	%ecx, %ecx
    1486:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1490:      	btq	%rcx, %rdx
    1494:      	jae	0x14a1 <filter_char_buf+0xa1>
    1496:      	xorl	%ecx, %ecx
    1498:      	testq	%rax, %rax
    149b:      	sete	%cl
    149e:      	movq	%rcx, %rax
    14a1:      	popq	%rbx
    14a2:      	retq
    14a3:      	nopw	%cs:(%rax,%rax)

00000000000014b0 <filter_inet>:
    14b0:      	pushq	%r15
    14b2:      	pushq	%r14
    14b4:      	pushq	%r12
    14b6:      	pushq	%rbx
    14b7:      	subq	$0x48, %rsp
    14bb:      	movq	$0x0, 0x40(%rsp)
    14c4:      	movq	$0x0, 0x38(%rsp)
    14cd:      	movq	$0x0, 0x30(%rsp)
    14d6:      	movq	$0x0, 0x28(%rsp)
    14df:      	movq	$0x0, 0x20(%rsp)
    14e8:      	movl	$0x0, (%rsp)
    14ef:      	movl	$0x0, 0x4(%rsp)
    14f7:      	movl	0xc(%rdi), %edx
    14fa:      	xorl	%eax, %eax
    14fc:      	cmpl	$0x27, %edx
    14ff:      	jg	0x1517 <filter_inet+0x67>
    1501:      	cmpl	$0x5, %edx
    1504:      	je	0x159c <filter_inet+0xec>
    150a:      	movq	%rsi, %r8
    150d:      	cmpl	$0x7, %edx
    1510:      	je	0x1528 <filter_inet+0x78>
    1512:      	jmp	0x17ad <filter_inet+0x2fd>
    1517:      	cmpl	$0x28, %edx
    151a:      	je	0x1574 <filter_inet+0xc4>
    151c:      	movq	%rsi, %r8
    151f:      	cmpl	$0x29, %edx
    1522:      	jne	0x17ad <filter_inet+0x2fd>
    1528:      	movl	0x4(%rdi), %ecx
    152b:      	xorl	%eax, %eax
    152d:      	cmpl	$0x13, %ecx
    1530:      	jle	0x15a9 <filter_inet+0xf9>
    1532:      	cmpl	$0x17, %ecx
    1535:      	jg	0x1554 <filter_inet+0xa4>
    1537:      	leal	-0x14(%rcx), %edx
    153a:      	cmpl	$0x2, %edx
    153d:      	jb	0x15fa <filter_inet+0x14a>
    1543:      	leal	-0x16(%rcx), %edx
    1546:      	cmpl	$0x2, %edx
    1549:      	jb	0x15f4 <filter_inet+0x144>
    154f:      	jmp	0x17ad <filter_inet+0x2fd>
    1554:      	cmpl	$0x1b, %ecx
    1557:      	jg	0x1637 <filter_inet+0x187>
    155d:      	cmpl	$0x18, %ecx
    1560:      	je	0x166a <filter_inet+0x1ba>
    1566:      	cmpl	$0x19, %ecx
    1569:      	je	0x1660 <filter_inet+0x1b0>
    156f:      	jmp	0x17ad <filter_inet+0x2fd>
    1574:      	movzwl	(%rsi), %eax
    1577:      	movw	%ax, 0x46(%rsp)
    157c:      	movzwl	0x2(%rsi), %eax
    1580:      	movw	%ax, 0x40(%rsp)
    1585:      	movq	0x8(%rsi), %rax
    1589:      	movq	%rax, 0x20(%rsp)
    158e:      	movq	0x10(%rsi), %rax
    1592:      	movq	%rax, 0x28(%rsp)
    1597:      	leaq	0x20(%rsp), %rsi
    159c:      	xorl	%r8d, %r8d
    159f:      	movl	0x4(%rdi), %ecx
    15a2:      	xorl	%eax, %eax
    15a4:      	cmpl	$0x13, %ecx
    15a7:      	jg	0x1532 <filter_inet+0x82>
    15a9:      	cmpl	$0xf, %ecx
    15ac:      	jle	0x15ca <filter_inet+0x11a>
    15ae:      	cmpl	$0x11, %ecx
    15b1:      	jg	0x15e6 <filter_inet+0x136>
    15b3:      	cmpl	$0x10, %ecx
    15b6:      	je	0x15f4 <filter_inet+0x144>
    15b8:      	cmpl	$0x11, %ecx
    15bb:      	jne	0x17ad <filter_inet+0x2fd>
    15c1:      	movzwl	0x24(%rsi), %eax
    15c5:      	jmp	0x17a2 <filter_inet+0x2f2>
    15ca:      	cmpl	$0xd, %ecx
    15cd:      	je	0x166a <filter_inet+0x1ba>
    15d3:      	cmpl	$0xe, %ecx
    15d6:      	je	0x1660 <filter_inet+0x1b0>
    15dc:      	cmpl	$0xf, %ecx
    15df:      	je	0x15fa <filter_inet+0x14a>
    15e1:      	jmp	0x17ad <filter_inet+0x2fd>
    15e6:      	cmpl	$0x12, %ecx
    15e9:      	je	0x15fa <filter_inet+0x14a>
    15eb:      	cmpl	$0x13, %ecx
    15ee:      	jne	0x17ad <filter_inet+0x2fd>
    15f4:      	movzwl	0x22(%rsi), %edx
    15f8:      	jmp	0x15fe <filter_inet+0x14e>
    15fa:      	movzwl	0x20(%rsi), %edx
    15fe:      	movl	%edx, 0x4(%rsp)
    1602:      	xorl	%ebx, %ebx
    1604:      	xorl	%r15d, %r15d
    1607:      	xorl	%r14d, %r14d
    160a:      	xorl	%eax, %eax
    160c:      	cmpl	$0x11, %ecx
    160f:      	jg	0x1681 <filter_inet+0x1d1>
    1611:      	leal	-0xd(%rcx), %edx
    1614:      	cmpl	$0x2, %edx
    1617:      	jb	0x16a8 <filter_inet+0x1f8>
    161d:      	leal	-0xf(%rcx), %edx
    1620:      	cmpl	$0x2, %edx
    1623:      	jb	0x16fd <filter_inet+0x24d>
    1629:      	cmpl	$0x11, %ecx
    162c:      	je	0x17a5 <filter_inet+0x2f5>
    1632:      	jmp	0x17ad <filter_inet+0x2fd>
    1637:      	cmpl	$0x1c, %ecx
    163a:      	je	0x179e <filter_inet+0x2ee>
    1640:      	cmpl	$0x1d, %ecx
    1643:      	jne	0x17ad <filter_inet+0x2fd>
    1649:      	cmpl	$0x7, %edx
    164c:      	jne	0x17d1 <filter_inet+0x321>
    1652:      	testq	%r8, %r8
    1655:      	jne	0x17db <filter_inet+0x32b>
    165b:      	jmp	0x17a5 <filter_inet+0x2f5>
    1660:      	movq	0x10(%rsi), %rbx
    1664:      	movq	0x18(%rsi), %r14
    1668:      	jmp	0x1671 <filter_inet+0x1c1>
    166a:      	movq	(%rsi), %rbx
    166d:      	movq	0x8(%rsi), %r14
    1671:      	movq	%rbx, %r15
    1674:      	shrq	$0x20, %r15
    1678:      	xorl	%edx, %edx
    167a:      	xorl	%eax, %eax
    167c:      	cmpl	$0x11, %ecx
    167f:      	jle	0x1611 <filter_inet+0x161>
    1681:      	cmpl	$0x19, %ecx
    1684:      	ja	0x16f1 <filter_inet+0x241>
    1686:      	movl	$0x500000, %r8d         # imm = 0x500000
    168c:      	btl	%ecx, %r8d
    1690:      	jb	0x1707 <filter_inet+0x257>
    1692:      	movl	$0xa00000, %r8d         # imm = 0xA00000
    1698:      	btl	%ecx, %r8d
    169c:      	jb	0x1717 <filter_inet+0x267>
    169e:      	movl	$0x3000000, %edx        # imm = 0x3000000
    16a3:      	btl	%ecx, %edx
    16a6:      	jae	0x16f1 <filter_inet+0x241>
    16a8:      	movzwl	0x26(%rsi), %eax
    16ac:      	cmpl	$0xa, %eax
    16af:      	je	0x1727 <filter_inet+0x277>
    16b1:      	cmpl	$0x2, %eax
    16b4:      	jne	0x1797 <filter_inet+0x2e7>
    16ba:      	movq	%rdi, %r12
    16bd:      	movl	0x10(%rdi), %eax
    16c0:      	movl	%eax, 0x8(%rsp)
    16c4:      	movq	(%rip), %rdi            # 0x16cb <filter_inet+0x21b>
    16cb:      	leaq	0x8(%rsp), %rsi
    16d0:      	movl	$0x1, %eax
    16d5:      	callq	*%rax
    16d7:      	testq	%rax, %rax
    16da:      	je	0x17b9 <filter_inet+0x309>
    16e0:      	movq	%rax, %rdi
    16e3:      	movl	$0x20, 0xc(%rsp)
    16eb:      	movl	%ebx, 0x10(%rsp)
    16ef:      	jmp	0x176b <filter_inet+0x2bb>
    16f1:      	addl	$-0x12, %ecx
    16f4:      	cmpl	$0x2, %ecx
    16f7:      	jae	0x17ad <filter_inet+0x2fd>
    16fd:      	leaq	0x4(%rsp), %rsi
    1702:      	jmp	0x17a8 <filter_inet+0x2f8>
    1707:      	xorl	%eax, %eax
    1709:      	cmpl	$0x400, %edx            # imm = 0x400
    170f:      	setb	%al
    1712:      	jmp	0x17ad <filter_inet+0x2fd>
    1717:      	xorl	%eax, %eax
    1719:      	cmpl	$0x400, %edx            # imm = 0x400
    171f:      	setae	%al
    1722:      	jmp	0x17ad <filter_inet+0x2fd>
    1727:      	movq	%rdi, %r12
    172a:      	movl	0x14(%rdi), %eax
    172d:      	movl	%eax, 0x8(%rsp)
    1731:      	movq	(%rip), %rdi            # 0x1738 <filter_inet+0x288>
    1738:      	leaq	0x8(%rsp), %rsi
    173d:      	movl	$0x1, %eax
    1742:      	callq	*%rax
    1744:      	testq	%rax, %rax
    1747:      	je	0x17b9 <filter_inet+0x309>
    1749:      	movq	%rax, %rdi
    174c:      	movl	$0x80, 0xc(%rsp)
    1754:      	movl	%ebx, 0x10(%rsp)
    1758:      	movl	%r15d, 0x14(%rsp)
    175d:      	movl	%r14d, 0x18(%rsp)
    1762:      	shrq	$0x20, %r14
    1766:      	movl	%r14d, 0x1c(%rsp)
    176b:      	leaq	0xc(%rsp), %rsi
    1770:      	movl	$0x1, %eax
    1775:      	callq	*%rax
    1777:      	movl	0x4(%r12), %ecx
    177c:      	leal	-0x18(%rcx), %edx
    177f:      	cmpl	$0x2, %edx
    1782:      	jb	0x17c6 <filter_inet+0x316>
    1784:      	addl	$-0xd, %ecx
    1787:      	cmpl	$0x1, %ecx
    178a:      	ja	0x1797 <filter_inet+0x2e7>
    178c:      	testq	%rax, %rax
    178f:      	setne	%al
    1792:      	movzbl	%al, %eax
    1795:      	jmp	0x17ad <filter_inet+0x2fd>
    1797:      	xorl	%eax, %eax
    1799:      	movzbl	%al, %eax
    179c:      	jmp	0x17ad <filter_inet+0x2fd>
    179e:      	movzwl	0x26(%rsi), %eax
    17a2:      	movl	%eax, (%rsp)
    17a5:      	movq	%rsp, %rsi
    17a8:      	callq	0x800 <filter_32ty_map>
    17ad:      	addq	$0x48, %rsp
    17b1:      	popq	%rbx
    17b2:      	popq	%r12
    17b4:      	popq	%r14
    17b6:      	popq	%r15
    17b8:      	retq
    17b9:      	movl	0x4(%r12), %eax
    17be:      	andl	$-0x2, %eax
    17c1:      	cmpl	$0x18, %eax
    17c4:      	jmp	0x17c9 <filter_inet+0x319>
    17c6:      	testq	%rax, %rax
    17c9:      	sete	%al
    17cc:      	movzbl	%al, %eax
    17cf:      	jmp	0x17ad <filter_inet+0x2fd>
    17d1:      	cmpl	$0x29, %edx
    17d4:      	jne	0x17e3 <filter_inet+0x333>
    17d6:      	testq	%r8, %r8
    17d9:      	je	0x17e3 <filter_inet+0x333>
    17db:      	movzbl	0x3a(%r8), %eax
    17e0:      	movl	%eax, (%rsp)
    17e3:      	cmpl	$0x29, %edx
    17e6:      	je	0x17a5 <filter_inet+0x2f5>
    17e8:      	cmpl	$0x7, %edx
    17eb:      	je	0x17a5 <filter_inet+0x2f5>
    17ed:      	xorl	%eax, %eax
    17ef:      	jmp	0x17ad <filter_inet+0x2fd>
    17f1:      	nopw	%cs:(%rax,%rax)

0000000000001800 <filter_sockaddr_un>:
    1800:      	pushq	%rbx
    1801:      	subq	$0x10, %rsp
    1805:      	movq	%rsi, %rcx
    1808:      	addq	$0x4, %rsi
    180c:      	movzbl	0x3(%rcx), %edx
    1810:      	movl	0x4(%rdi), %r8d
    1814:      	xorl	%eax, %eax
    1816:      	cmpl	$0x19, %r8d
    181a:      	jg	0x1850 <filter_sockaddr_un+0x50>
    181c:      	leal	-0x3(%r8), %ecx
    1820:      	cmpl	$0x2, %ecx
    1823:      	jae	0x185e <filter_sockaddr_un+0x5e>
    1825:      	movq	%rdi, %rbx
    1828:      	callq	0x18b0 <filter_char_buf_equal>
    182d:      	movl	0x4(%rbx), %ecx
    1830:      	cmpq	$0x25, %rcx
    1834:      	ja	0x184a <filter_sockaddr_un+0x4a>
    1836:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1840:      	btq	%rcx, %rdx
    1844:      	jae	0x184a <filter_sockaddr_un+0x4a>
    1846:      	xorq	$0x1, %rax
    184a:      	addq	$0x10, %rsp
    184e:      	popq	%rbx
    184f:      	retq
    1850:      	cmpl	$0x1c, %r8d
    1854:      	je	0x1894 <filter_sockaddr_un+0x94>
    1856:      	cmpl	$0x1a, %r8d
    185a:      	je	0x1864 <filter_sockaddr_un+0x64>
    185c:      	jmp	0x184a <filter_sockaddr_un+0x4a>
    185e:      	cmpl	$0x8, %r8d
    1862:      	jne	0x184a <filter_sockaddr_un+0x4a>
    1864:      	movl	0x10(%rdi), %eax
    1867:      	movq	%rdi, %rbx
    186a:      	movl	%eax, %edi
    186c:      	callq	0x1c30 <filter_char_buf_prefix>
    1871:      	movl	0x4(%rbx), %ecx
    1874:      	cmpq	$0x25, %rcx
    1878:      	ja	0x184a <filter_sockaddr_un+0x4a>
    187a:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    1884:      	btq	%rcx, %rdx
    1888:      	jae	0x184a <filter_sockaddr_un+0x4a>
    188a:      	xorq	$0x1, %rax
    188e:      	addq	$0x10, %rsp
    1892:      	popq	%rbx
    1893:      	retq
    1894:      	movzwl	(%rcx), %eax
    1897:      	movl	%eax, 0xc(%rsp)
    189b:      	leaq	0xc(%rsp), %rsi
    18a0:      	callq	0x800 <filter_32ty_map>
    18a5:      	addq	$0x10, %rsp
    18a9:      	popq	%rbx
    18aa:      	retq
    18ab:      	nopl	(%rax,%rax)

00000000000018b0 <filter_char_buf_equal>:
    18b0:      	pushq	%rbp
    18b1:      	pushq	%r15
    18b3:      	pushq	%r14
    18b5:      	pushq	%r13
    18b7:      	pushq	%r12
    18b9:      	pushq	%rbx
    18ba:      	subq	$0x28, %rsp
    18be:      	movl	$0x0, 0x14(%rsp)
    18c6:      	cmpl	$0x1000, %edx           # imm = 0x1000
    18cc:      	ja	0x1c1e <filter_char_buf_equal+0x36e>
    18d2:      	movl	%edx, %ebp
    18d4:      	movzwl	%bp, %eax
    18d7:      	cmpl	$0x90, %eax
    18dc:      	ja	0x1925 <filter_char_buf_equal+0x75>
    18de:      	testw	%bp, %bp
    18e1:      	je	0x18f4 <filter_char_buf_equal+0x44>
    18e3:      	movl	$0x18, %ecx
    18e8:      	movl	%ebp, %eax
    18ea:      	cltd
    18eb:      	idivl	%ecx
    18ed:      	movl	%ebp, %r14d
    18f0:      	testl	%edx, %edx
    18f2:      	je	0x1914 <filter_char_buf_equal+0x64>
    18f4:      	movl	$0x18, %ecx
    18f9:      	movl	%ebp, %eax
    18fb:      	cltd
    18fc:      	idivl	%ecx
    18fe:      	shll	$0x3, %eax
    1901:      	leal	(%rax,%rax,2), %eax
    1904:      	addl	$0x18, %eax
    1907:      	movzwl	%ax, %r14d
    190b:      	cmpl	$0x90, %r14d
    1912:      	ja	0x1963 <filter_char_buf_equal+0xb3>
    1914:      	movl	%r14d, %eax
    1917:      	cltd
    1918:      	idivl	%ecx
    191a:      	movl	%eax, %r15d
    191d:      	decl	%r15d
    1920:      	jmp	0x19ae <filter_char_buf_equal+0xfe>
    1925:      	movl	$0x100, %r14d           # imm = 0x100
    192b:      	cmpl	$0x101, %eax            # imm = 0x101
    1930:      	jb	0x1963 <filter_char_buf_equal+0xb3>
    1932:      	movl	$0x200, %r14d           # imm = 0x200
    1938:      	cmpl	$0x201, %eax            # imm = 0x201
    193d:      	jb	0x1963 <filter_char_buf_equal+0xb3>
    193f:      	movl	$0x400, %r14d           # imm = 0x400
    1945:      	cmpl	$0x401, %eax            # imm = 0x401
    194a:      	jb	0x1963 <filter_char_buf_equal+0xb3>
    194c:      	xorl	%r14d, %r14d
    194f:      	cmpl	$0x801, %eax            # imm = 0x801
    1954:      	setae	%r14b
    1958:      	shll	$0xb, %r14d
    195c:      	addl	$0x800, %r14d           # imm = 0x800
    1963:      	leal	-0x100(%r14), %eax
    196a:      	rorxl	$0x8, %eax, %eax
    1970:      	cmpl	$0x2, %eax
    1973:      	jg	0x1986 <filter_char_buf_equal+0xd6>
    1975:      	testl	%eax, %eax
    1977:      	je	0x19a0 <filter_char_buf_equal+0xf0>
    1979:      	cmpl	$0x1, %eax
    197c:      	jne	0x1998 <filter_char_buf_equal+0xe8>
    197e:      	movl	$0x7, %r15d
    1984:      	jmp	0x19ae <filter_char_buf_equal+0xfe>
    1986:      	cmpl	$0x3, %eax
    1989:      	je	0x19a8 <filter_char_buf_equal+0xf8>
    198b:      	cmpl	$0x7, %eax
    198e:      	jne	0x1998 <filter_char_buf_equal+0xe8>
    1990:      	movl	$0x9, %r15d
    1996:      	jmp	0x19ae <filter_char_buf_equal+0xfe>
    1998:      	movl	$0xa, %r15d
    199e:      	jmp	0x19ae <filter_char_buf_equal+0xfe>
    19a0:      	movl	$0x6, %r15d
    19a6:      	jmp	0x19ae <filter_char_buf_equal+0xfe>
    19a8:      	movl	$0x8, %r15d
    19ae:      	movl	%r15d, %eax
    19b1:      	andl	$0xf, %eax
    19b4:      	movl	0x10(%rdi,%rax,4), %r13d
    19b9:      	cmpl	$-0x1, %r13d
    19bd:      	je	0x1c1e <filter_char_buf_equal+0x36e>
    19c3:      	movq	%rsi, 0x20(%rsp)
    19c8:      	movq	(%rip), %rdi            # 0x19cf <filter_char_buf_equal+0x11f>
    19cf:      	leaq	0x14(%rsp), %r12
    19d4:      	movl	$0x1, %eax
    19d9:      	movq	%r12, %rsi
    19dc:      	callq	*%rax
    19de:      	movq	%rax, %rbx
    19e1:      	movq	(%rip), %rdi            # 0x19e8 <filter_char_buf_equal+0x138>
    19e8:      	movl	$0x1, %eax
    19ed:      	movq	%r12, %rsi
    19f0:      	callq	*%rax
    19f2:      	movq	%rax, %rcx
    19f5:      	xorl	%eax, %eax
    19f7:      	movq	%rbx, 0x8(%rsp)
    19fc:      	testq	%rbx, %rbx
    19ff:      	je	0x1c20 <filter_char_buf_equal+0x370>
    1a05:      	testq	%rcx, %rcx
    1a08:      	je	0x1c20 <filter_char_buf_equal+0x370>
    1a0e:      	movq	%rcx, 0x18(%rsp)
    1a13:      	cmpl	$0x5, %r15d
    1a17:      	jg	0x1a5a <filter_char_buf_equal+0x1aa>
    1a19:      	movq	0x8(%rsp), %rax
    1a1e:      	movb	%bpl, (%rax)
    1a21:      	leaq	0x1(%rax), %rdi
    1a25:      	movl	%ebp, %r12d
    1a28:      	movl	$0x4, %eax
    1a2d:      	movq	0x20(%rsp), %rdx
    1a32:      	movl	%ebp, %esi
    1a34:      	callq	*%rax
    1a36:      	subl	%ebp, %r14d
    1a39:      	jbe	0x1a9f <filter_char_buf_equal+0x1ef>
    1a3b:      	movq	0x8(%rsp), %rax
    1a40:      	leaq	(%rax,%r12), %rdi
    1a44:      	incq	%rdi
    1a47:      	andl	$0xfff, %r14d           # imm = 0xFFF
    1a4e:      	movl	$0x4, %eax
    1a53:      	movq	0x18(%rsp), %rdx
    1a58:      	jmp	0x1a9a <filter_char_buf_equal+0x1ea>
    1a5a:      	movq	0x8(%rsp), %rax
    1a5f:      	movw	%bp, (%rax)
    1a62:      	leaq	0x2(%rax), %rdi
    1a66:      	movl	%ebp, %r12d
    1a69:      	movl	$0x4, %eax
    1a6e:      	movq	0x20(%rsp), %rdx
    1a73:      	movl	%ebp, %esi
    1a75:      	callq	*%rax
    1a77:      	subl	%ebp, %r14d
    1a7a:      	jbe	0x1a9f <filter_char_buf_equal+0x1ef>
    1a7c:      	movq	0x8(%rsp), %rax
    1a81:      	leaq	(%rax,%r12), %rdi
    1a85:      	addq	$0x2, %rdi
    1a89:      	andl	$0xfff, %r14d           # imm = 0xFFF
    1a90:      	movl	$0x4, %eax
    1a95:      	movq	0x18(%rsp), %rdx
    1a9a:      	movl	%r14d, %esi
    1a9d:      	callq	*%rax
    1a9f:      	movl	%r13d, 0x4(%rsp)
    1aa4:      	cmpl	$0x4, %r15d
    1aa8:      	jle	0x1ae4 <filter_char_buf_equal+0x234>
    1aaa:      	cmpl	$0x7, %r15d
    1aae:      	jg	0x1b1e <filter_char_buf_equal+0x26e>
    1ab0:      	cmpl	$0x5, %r15d
    1ab4:      	je	0x1bd2 <filter_char_buf_equal+0x322>
    1aba:      	cmpl	$0x6, %r15d
    1abe:      	je	0x1b99 <filter_char_buf_equal+0x2e9>
    1ac4:      	cmpl	$0x7, %r15d
    1ac8:      	jne	0x1c1e <filter_char_buf_equal+0x36e>
    1ace:      	movq	(%rip), %rdi            # 0x1ad5 <filter_char_buf_equal+0x225>
    1ad5:      	leaq	0x4(%rsp), %rcx
    1ada:      	movl	$0x1, %eax
    1adf:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1ae4:      	cmpl	$0x1, %r15d
    1ae8:      	jle	0x1b4e <filter_char_buf_equal+0x29e>
    1aea:      	cmpl	$0x2, %r15d
    1aee:      	je	0x1bbf <filter_char_buf_equal+0x30f>
    1af4:      	cmpl	$0x3, %r15d
    1af8:      	je	0x1b86 <filter_char_buf_equal+0x2d6>
    1afe:      	cmpl	$0x4, %r15d
    1b02:      	jne	0x1c1e <filter_char_buf_equal+0x36e>
    1b08:      	movq	(%rip), %rdi            # 0x1b0f <filter_char_buf_equal+0x25f>
    1b0f:      	leaq	0x4(%rsp), %rcx
    1b14:      	movl	$0x1, %eax
    1b19:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1b1e:      	cmpl	$0x8, %r15d
    1b22:      	je	0x1be5 <filter_char_buf_equal+0x335>
    1b28:      	cmpl	$0x9, %r15d
    1b2c:      	je	0x1bac <filter_char_buf_equal+0x2fc>
    1b2e:      	cmpl	$0xa, %r15d
    1b32:      	jne	0x1c1e <filter_char_buf_equal+0x36e>
    1b38:      	movq	(%rip), %rdi            # 0x1b3f <filter_char_buf_equal+0x28f>
    1b3f:      	leaq	0x4(%rsp), %rcx
    1b44:      	movl	$0x1, %eax
    1b49:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1b4e:      	testl	%r15d, %r15d
    1b51:      	je	0x1b73 <filter_char_buf_equal+0x2c3>
    1b53:      	cmpl	$0x1, %r15d
    1b57:      	jne	0x1c1e <filter_char_buf_equal+0x36e>
    1b5d:      	movq	(%rip), %rdi            # 0x1b64 <filter_char_buf_equal+0x2b4>
    1b64:      	leaq	0x4(%rsp), %rcx
    1b69:      	movl	$0x1, %eax
    1b6e:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1b73:      	movq	(%rip), %rdi            # 0x1b7a <filter_char_buf_equal+0x2ca>
    1b7a:      	leaq	0x4(%rsp), %rcx
    1b7f:      	movl	$0x1, %eax
    1b84:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1b86:      	movq	(%rip), %rdi            # 0x1b8d <filter_char_buf_equal+0x2dd>
    1b8d:      	leaq	0x4(%rsp), %rcx
    1b92:      	movl	$0x1, %eax
    1b97:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1b99:      	movq	(%rip), %rdi            # 0x1ba0 <filter_char_buf_equal+0x2f0>
    1ba0:      	leaq	0x4(%rsp), %rcx
    1ba5:      	movl	$0x1, %eax
    1baa:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1bac:      	movq	(%rip), %rdi            # 0x1bb3 <filter_char_buf_equal+0x303>
    1bb3:      	leaq	0x4(%rsp), %rcx
    1bb8:      	movl	$0x1, %eax
    1bbd:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1bbf:      	movq	(%rip), %rdi            # 0x1bc6 <filter_char_buf_equal+0x316>
    1bc6:      	leaq	0x4(%rsp), %rcx
    1bcb:      	movl	$0x1, %eax
    1bd0:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1bd2:      	movq	(%rip), %rdi            # 0x1bd9 <filter_char_buf_equal+0x329>
    1bd9:      	leaq	0x4(%rsp), %rcx
    1bde:      	movl	$0x1, %eax
    1be3:      	jmp	0x1bf6 <filter_char_buf_equal+0x346>
    1be5:      	movq	(%rip), %rdi            # 0x1bec <filter_char_buf_equal+0x33c>
    1bec:      	leaq	0x4(%rsp), %rcx
    1bf1:      	movl	$0x1, %eax
    1bf6:      	leaq	0x4(%rsp), %rsi
    1bfb:      	callq	*%rax
    1bfd:      	testq	%rax, %rax
    1c00:      	je	0x1c1e <filter_char_buf_equal+0x36e>
    1c02:      	movq	%rax, %rdi
    1c05:      	movl	$0x1, %eax
    1c0a:      	movq	0x8(%rsp), %rsi
    1c0f:      	callq	*%rax
    1c11:      	movq	%rax, %rcx
    1c14:      	xorl	%eax, %eax
    1c16:      	testq	%rcx, %rcx
    1c19:      	setne	%al
    1c1c:      	jmp	0x1c20 <filter_char_buf_equal+0x370>
    1c1e:      	xorl	%eax, %eax
    1c20:      	addq	$0x28, %rsp
    1c24:      	popq	%rbx
    1c25:      	popq	%r12
    1c27:      	popq	%r13
    1c29:      	popq	%r14
    1c2b:      	popq	%r15
    1c2d:      	popq	%rbp
    1c2e:      	retq
    1c2f:      	nop

0000000000001c30 <filter_char_buf_prefix>:
    1c30:      	pushq	%rbp
    1c31:      	pushq	%r15
    1c33:      	pushq	%r14
    1c35:      	pushq	%rbx
    1c36:      	pushq	%rax
    1c37:      	movl	%edx, %ebp
    1c39:      	movq	%rsi, %rbx
    1c3c:      	movl	%edi, 0x4(%rsp)
    1c40:      	movl	$0x0, (%rsp)
    1c47:      	movq	(%rip), %rdi            # 0x1c4e <filter_char_buf_prefix+0x1e>
    1c4e:      	leaq	0x4(%rsp), %rsi
    1c53:      	movl	$0x1, %eax
    1c58:      	callq	*%rax
    1c5a:      	movq	%rax, %r14
    1c5d:      	xorl	%eax, %eax
    1c5f:      	testl	%ebp, %ebp
    1c61:      	je	0x1cc5 <filter_char_buf_prefix+0x95>
    1c63:      	testq	%r14, %r14
    1c66:      	je	0x1cc5 <filter_char_buf_prefix+0x95>
    1c68:      	movq	(%rip), %rdi            # 0x1c6f <filter_char_buf_prefix+0x3f>
    1c6f:      	movq	%rsp, %rsi
    1c72:      	movl	$0x1, %eax
    1c77:      	callq	*%rax
    1c79:      	testq	%rax, %rax
    1c7c:      	je	0x1cc3 <filter_char_buf_prefix+0x93>
    1c7e:      	cmpl	$0xff, %ebp
    1c84:      	movl	$0xff, %esi
    1c89:      	cmovbl	%ebp, %esi
    1c8c:      	leal	(,%rsi,8), %ecx
    1c93:      	movl	%ecx, (%rax)
    1c95:      	movq	%rax, %rdi
    1c98:      	addq	$0x4, %rdi
    1c9c:      	movq	%rax, %r15
    1c9f:      	movl	$0x4, %eax
    1ca4:      	movq	%rbx, %rdx
    1ca7:      	callq	*%rax
    1ca9:      	movl	$0x1, %eax
    1cae:      	movq	%r14, %rdi
    1cb1:      	movq	%r15, %rsi
    1cb4:      	callq	*%rax
    1cb6:      	movq	%rax, %rcx
    1cb9:      	xorl	%eax, %eax
    1cbb:      	testq	%rcx, %rcx
    1cbe:      	setne	%al
    1cc1:      	jmp	0x1cc5 <filter_char_buf_prefix+0x95>
    1cc3:      	xorl	%eax, %eax
    1cc5:      	addq	$0x8, %rsp
    1cc9:      	popq	%rbx
    1cca:      	popq	%r14
    1ccc:      	popq	%r15
    1cce:      	popq	%rbp
    1ccf:      	retq

0000000000001cd0 <filter_char_buf_postfix>:
    1cd0:      	pushq	%r15
    1cd2:      	pushq	%r14
    1cd4:      	pushq	%rbx
    1cd5:      	subq	$0x10, %rsp
    1cd9:      	movl	%edx, %ebx
    1cdb:      	movq	%rsi, %r14
    1cde:      	movl	%edi, 0xc(%rsp)
    1ce2:      	movl	$0x0, 0x8(%rsp)
    1cea:      	movq	(%rip), %rdi            # 0x1cf1 <filter_char_buf_postfix+0x21>
    1cf1:      	leaq	0xc(%rsp), %rsi
    1cf6:      	movl	$0x1, %eax
    1cfb:      	callq	*%rax
    1cfd:      	movq	%rax, %r15
    1d00:      	xorl	%eax, %eax
    1d02:      	testl	%ebx, %ebx
    1d04:      	je	0x1e10 <filter_char_buf_postfix+0x140>
    1d0a:      	testq	%r15, %r15
    1d0d:      	je	0x1e10 <filter_char_buf_postfix+0x140>
    1d13:      	movq	(%rip), %rdi            # 0x1d1a <filter_char_buf_postfix+0x4a>
    1d1a:      	leaq	0x8(%rsp), %rsi
    1d1f:      	movl	$0x1, %eax
    1d24:      	callq	*%rax
    1d26:      	testq	%rax, %rax
    1d29:      	je	0x1e0e <filter_char_buf_postfix+0x13e>
    1d2f:      	movq	%rax, %rsi
    1d32:      	cmpl	$0x7f, %ebx
    1d35:      	movl	$0x7f, %eax
    1d3a:      	cmovbl	%ebx, %eax
    1d3d:      	shll	$0x3, %eax
    1d40:      	movl	%eax, (%rsi)
    1d42:      	movl	%ebx, %eax
    1d44:      	leal	-0x4(%rbx), %ecx
    1d47:      	movq	%rsi, %rdx
    1d4a:      	addq	$0x7, %rdx
    1d4e:      	leal	-0x3(%rbx), %edi
    1d51:      	leal	-0x2(%rbx), %r8d
    1d55:      	decl	%ebx
    1d57:      	movq	$-0x3, %r9
    1d5e:      	nop
    1d60:      	leal	(%rbx,%r9), %r10d
    1d64:      	addl	$0x3, %r10d
    1d68:      	andl	$0xfff, %r10d           # imm = 0xFFF
    1d6f:      	movzbl	(%r14,%r10), %r10d
    1d74:      	movb	%r10b, -0x3(%rdx)
    1d78:      	leaq	(%rax,%r9), %r10
    1d7c:      	cmpq	$-0x2, %r10
    1d80:      	je	0x1df7 <filter_char_buf_postfix+0x127>
    1d82:      	leal	(%r8,%r9), %r11d
    1d86:      	addl	$0x3, %r11d
    1d8a:      	andl	$0xfff, %r11d           # imm = 0xFFF
    1d91:      	movzbl	(%r14,%r11), %r11d
    1d96:      	movb	%r11b, -0x2(%rdx)
    1d9a:      	cmpq	$-0x1, %r10
    1d9e:      	je	0x1df7 <filter_char_buf_postfix+0x127>
    1da0:      	leal	(%rdi,%r9), %r10d
    1da4:      	addl	$0x3, %r10d
    1da8:      	andl	$0xfff, %r10d           # imm = 0xFFF
    1daf:      	movzbl	(%r14,%r10), %r10d
    1db4:      	movb	%r10b, -0x1(%rdx)
    1db8:      	movq	%rax, %r10
    1dbb:      	addq	%r9, %r10
    1dbe:      	je	0x1df7 <filter_char_buf_postfix+0x127>
    1dc0:      	cmpq	$-0x7f, %r9
    1dc4:      	je	0x1df7 <filter_char_buf_postfix+0x127>
    1dc6:      	leal	(%rcx,%r9), %r10d
    1dca:      	addl	$0x3, %r10d
    1dce:      	andl	$0xfff, %r10d           # imm = 0xFFF
    1dd5:      	movzbl	(%r14,%r10), %r10d
    1dda:      	movb	%r10b, (%rdx)
    1ddd:      	addq	$0x4, %rdx
    1de1:      	leaq	(%rax,%r9), %r10
    1de5:      	addq	$-0x4, %r10
    1de9:      	addq	$-0x4, %r9
    1ded:      	cmpq	$-0x3, %r10
    1df1:      	jne	0x1d60 <filter_char_buf_postfix+0x90>
    1df7:      	movl	$0x1, %eax
    1dfc:      	movq	%r15, %rdi
    1dff:      	callq	*%rax
    1e01:      	movq	%rax, %rcx
    1e04:      	xorl	%eax, %eax
    1e06:      	testq	%rcx, %rcx
    1e09:      	setne	%al
    1e0c:      	jmp	0x1e10 <filter_char_buf_postfix+0x140>
    1e0e:      	xorl	%eax, %eax
    1e10:      	addq	$0x10, %rsp
    1e14:      	popq	%rbx
    1e15:      	popq	%r14
    1e17:      	popq	%r15
    1e19:      	retq
    1e1a:      	nopw	(%rax,%rax)

0000000000001e20 <filter_file_type>:
    1e20:      	pushq	%rbx
    1e21:      	subq	$0x10, %rsp
    1e25:      	movw	$0x0, 0xe(%rsp)
    1e2c:      	movl	(%rsi), %eax
    1e2e:      	cmpq	$0x1000, %rax           # imm = 0x1000
    1e34:      	ja	0x1ebc <filter_file_type+0x9c>
    1e3a:      	movq	%rdi, %rbx
    1e3d:      	leaq	(%rsi,%rax), %rcx
    1e41:      	addq	$0x8, %rcx
    1e45:      	leaq	0xe(%rsp), %rdi
    1e4a:      	movl	$0x2, %edx
    1e4f:      	movl	$0x4, %eax
    1e54:      	movl	(%rsi), %ecx
    1e56:      	leaq	(%rsi,%rcx), %rdx
    1e5a:      	addq	$0x8, %rdx
    1e5e:      	movl	$0x2, %esi
    1e63:      	callq	*%rax
    1e65:      	movl	0x10(%rbx), %edx
    1e68:      	testl	%edx, %edx
    1e6a:      	je	0x1ebc <filter_file_type+0x9c>
    1e6c:      	movzwl	0xe(%rsp), %ecx
    1e71:      	andl	$0xf000, %ecx           # imm = 0xF000
    1e77:      	movl	$0x1, %eax
    1e7c:      	cmpl	%ecx, %edx
    1e7e:      	je	0x1ebe <filter_file_type+0x9e>
    1e80:      	movl	0x8(%rbx), %edx
    1e83:      	cmpl	$0xc, %edx
    1e86:      	jbe	0x1ebc <filter_file_type+0x9c>
    1e88:      	movl	0x14(%rbx), %esi
    1e8b:      	testl	%esi, %esi
    1e8d:      	je	0x1ebc <filter_file_type+0x9c>
    1e8f:      	cmpl	%ecx, %esi
    1e91:      	je	0x1ebe <filter_file_type+0x9e>
    1e93:      	cmpl	$0x11, %edx
    1e96:      	jb	0x1ebc <filter_file_type+0x9c>
    1e98:      	movl	0x18(%rbx), %esi
    1e9b:      	testl	%esi, %esi
    1e9d:      	je	0x1ebc <filter_file_type+0x9c>
    1e9f:      	cmpl	%ecx, %esi
    1ea1:      	je	0x1ebe <filter_file_type+0x9e>
    1ea3:      	cmpl	$0x15, %edx
    1ea6:      	jb	0x1ebc <filter_file_type+0x9c>
    1ea8:      	movl	0x1c(%rbx), %edx
    1eab:      	testl	%edx, %edx
    1ead:      	je	0x1ebc <filter_file_type+0x9c>
    1eaf:      	xorl	%eax, %eax
    1eb1:      	cmpl	%ecx, %edx
    1eb3:      	sete	%al
    1eb6:      	addq	$0x10, %rsp
    1eba:      	popq	%rbx
    1ebb:      	retq
    1ebc:      	xorl	%eax, %eax
    1ebe:      	addq	$0x10, %rsp
    1ec2:      	popq	%rbx
    1ec3:      	retq
    1ec4:      	nopw	%cs:(%rax,%rax)

0000000000001ed0 <filter_char_substring>:
    1ed0:      	pushq	%rbp
    1ed1:      	pushq	%r15
    1ed3:      	pushq	%r14
    1ed5:      	pushq	%r13
    1ed7:      	pushq	%r12
    1ed9:      	pushq	%rbx
    1eda:      	pushq	%rax
    1edb:      	movq	%rsi, %r15
    1ede:      	movq	%rdi, %r14
    1ee1:      	movl	%edx, %ebp
    1ee3:      	testl	%ecx, %ecx
    1ee5:      	je	0x1fbd <filter_char_substring+0xed>
    1eeb:      	testl	%edx, %edx
    1eed:      	je	0x206d <filter_char_substring+0x19d>
    1ef3:      	leaq	0x4(%rsp), %r13
    1ef8:      	xorl	%ebx, %ebx
    1efa:      	xorl	%r12d, %r12d
    1efd:      	nopl	(%rax)
    1f00:      	movl	0x10(%r14,%rbx,4), %eax
    1f05:      	movl	%eax, 0x4(%rsp)
    1f09:      	movl	$0x1, %eax
    1f0e:      	movq	(%rip), %rdi            # 0x1f15 <filter_char_substring+0x45>
    1f15:      	movq	%r13, %rsi
    1f18:      	callq	*%rax
    1f1a:      	testq	%rax, %rax
    1f1d:      	je	0x2100 <filter_char_substring+0x230>
    1f23:      	movq	%r15, %rdx
    1f26:      	xorl	%ecx, %ecx
    1f28:      	jmp	0x1f3b <filter_char_substring+0x6b>
    1f2a:      	nopw	(%rax,%rax)
    1f30:      	incq	%rcx
    1f33:      	incq	%rdx
    1f36:      	cmpq	%rbp, %rcx
    1f39:      	je	0x1f98 <filter_char_substring+0xc8>
    1f3b:      	xorl	%esi, %esi
    1f3d:      	nopl	(%rax)
    1f40:      	leaq	(%rcx,%rsi), %rdi
    1f44:      	cmpq	%rbp, %rdi
    1f47:      	jae	0x1f30 <filter_char_substring+0x60>
    1f49:      	movsbl	(%rax,%rsi), %edi
    1f4d:      	testl	%edi, %edi
    1f4f:      	je	0x1f90 <filter_char_substring+0xc0>
    1f51:      	movsbl	(%rdx,%rsi), %r9d
    1f56:      	leal	-0x41(%r9), %r10d
    1f5a:      	movl	%r9d, %r8d
    1f5d:      	orl	$0x20, %r8d
    1f61:      	cmpl	$0x1a, %r10d
    1f65:      	cmovael	%r9d, %r8d
    1f69:      	leal	-0x41(%rdi), %r10d
    1f6d:      	movl	%edi, %r9d
    1f70:      	orl	$0x20, %r9d
    1f74:      	cmpl	$0x1a, %r10d
    1f78:      	cmovael	%edi, %r9d
    1f7c:      	cmpq	$0x62, %rsi
    1f80:      	ja	0x1f30 <filter_char_substring+0x60>
    1f82:      	incq	%rsi
    1f85:      	cmpl	%r9d, %r8d
    1f88:      	je	0x1f40 <filter_char_substring+0x70>
    1f8a:      	jmp	0x1f30 <filter_char_substring+0x60>
    1f8c:      	nopl	(%rax)
    1f90:      	testl	%ecx, %ecx
    1f92:      	jns	0x2111 <filter_char_substring+0x241>
    1f98:      	leal	0xc(%r12), %eax
    1f9d:      	cmpl	0x8(%r14), %eax
    1fa1:      	jae	0x2100 <filter_char_substring+0x230>
    1fa7:      	addl	$0x4, %r12d
    1fab:      	incq	%rbx
    1fae:      	cmpq	$0x64, %rbx
    1fb2:      	jne	0x1f00 <filter_char_substring+0x30>
    1fb8:      	jmp	0x2100 <filter_char_substring+0x230>
    1fbd:      	testl	%edx, %edx
    1fbf:      	je	0x20b2 <filter_char_substring+0x1e2>
    1fc5:      	leaq	0x4(%rsp), %r13
    1fca:      	xorl	%ebx, %ebx
    1fcc:      	xorl	%r12d, %r12d
    1fcf:      	nop
    1fd0:      	movl	0x10(%r14,%rbx,4), %eax
    1fd5:      	movl	%eax, 0x4(%rsp)
    1fd9:      	movl	$0x1, %eax
    1fde:      	movq	(%rip), %rdi            # 0x1fe5 <filter_char_substring+0x115>
    1fe5:      	movq	%r13, %rsi
    1fe8:      	callq	*%rax
    1fea:      	testq	%rax, %rax
    1fed:      	je	0x2100 <filter_char_substring+0x230>
    1ff3:      	movq	%r15, %rdx
    1ff6:      	xorl	%ecx, %ecx
    1ff8:      	jmp	0x200b <filter_char_substring+0x13b>
    1ffa:      	nopw	(%rax,%rax)
    2000:      	incq	%rcx
    2003:      	incq	%rdx
    2006:      	cmpq	%rbp, %rcx
    2009:      	je	0x2048 <filter_char_substring+0x178>
    200b:      	xorl	%esi, %esi
    200d:      	nopl	(%rax)
    2010:      	leaq	(%rcx,%rsi), %rdi
    2014:      	cmpq	%rbp, %rdi
    2017:      	jae	0x2000 <filter_char_substring+0x130>
    2019:      	movzbl	(%rax,%rsi), %edi
    201d:      	testb	%dil, %dil
    2020:      	je	0x2040 <filter_char_substring+0x170>
    2022:      	cmpq	$0x62, %rsi
    2026:      	ja	0x2000 <filter_char_substring+0x130>
    2028:      	leaq	0x1(%rsi), %r8
    202c:      	cmpb	%dil, (%rdx,%rsi)
    2030:      	movq	%r8, %rsi
    2033:      	je	0x2010 <filter_char_substring+0x140>
    2035:      	jmp	0x2000 <filter_char_substring+0x130>
    2037:      	nopw	(%rax,%rax)
    2040:      	testl	%ecx, %ecx
    2042:      	jns	0x2111 <filter_char_substring+0x241>
    2048:      	leal	0xc(%r12), %eax
    204d:      	cmpl	0x8(%r14), %eax
    2051:      	jae	0x2100 <filter_char_substring+0x230>
    2057:      	addl	$0x4, %r12d
    205b:      	incq	%rbx
    205e:      	cmpq	$0x64, %rbx
    2062:      	jne	0x1fd0 <filter_char_substring+0x100>
    2068:      	jmp	0x2100 <filter_char_substring+0x230>
    206d:      	movl	$0x10, %ebx
    2072:      	movq	(%rip), %r15            # 0x2079 <filter_char_substring+0x1a9>
    2079:      	leaq	0x4(%rsp), %r12
    207e:      	nop
    2080:      	movl	(%r14,%rbx), %eax
    2084:      	movl	%eax, 0x4(%rsp)
    2088:      	movl	$0x1, %eax
    208d:      	movq	%r15, %rdi
    2090:      	movq	%r12, %rsi
    2093:      	callq	*%rax
    2095:      	testq	%rax, %rax
    2098:      	je	0x2100 <filter_char_substring+0x230>
    209a:      	addq	$0x4, %rbx
    209e:      	leal	-0x8(%rbx), %eax
    20a1:      	cmpl	0x8(%r14), %eax
    20a5:      	jae	0x2100 <filter_char_substring+0x230>
    20a7:      	cmpq	$0x1a0, %rbx            # imm = 0x1A0
    20ae:      	jne	0x2080 <filter_char_substring+0x1b0>
    20b0:      	jmp	0x2100 <filter_char_substring+0x230>
    20b2:      	movl	$0x10, %ebx
    20b7:      	movq	(%rip), %r15            # 0x20be <filter_char_substring+0x1ee>
    20be:      	leaq	0x4(%rsp), %r12
    20c3:      	nopw	%cs:(%rax,%rax)
    20d0:      	movl	(%r14,%rbx), %eax
    20d4:      	movl	%eax, 0x4(%rsp)
    20d8:      	movl	$0x1, %eax
    20dd:      	movq	%r15, %rdi
    20e0:      	movq	%r12, %rsi
    20e3:      	callq	*%rax
    20e5:      	testq	%rax, %rax
    20e8:      	je	0x2100 <filter_char_substring+0x230>
    20ea:      	addq	$0x4, %rbx
    20ee:      	leal	-0x8(%rbx), %eax
    20f1:      	cmpl	0x8(%r14), %eax
    20f5:      	jae	0x2100 <filter_char_substring+0x230>
    20f7:      	cmpq	$0x1a0, %rbx            # imm = 0x1A0
    20fe:      	jne	0x20d0 <filter_char_substring+0x200>
    2100:      	xorl	%eax, %eax
    2102:      	addq	$0x8, %rsp
    2106:      	popq	%rbx
    2107:      	popq	%r12
    2109:      	popq	%r13
    210b:      	popq	%r14
    210d:      	popq	%r15
    210f:      	popq	%rbp
    2110:      	retq
    2111:      	movl	$0x1, %eax
    2116:      	jmp	0x2102 <filter_char_substring+0x232>
    2118:      	nopl	(%rax,%rax)

0000000000002120 <do_action>:
    2120:      	pushq	%rbp
    2121:      	pushq	%r15
    2123:      	pushq	%r14
    2125:      	pushq	%r13
    2127:      	pushq	%r12
    2129:      	pushq	%rbx
    212a:      	subq	$0x78, %rsp
    212e:      	movl	%r8d, %ebp
    2131:      	movq	%rcx, 0x38(%rsp)
    2136:      	movq	%rdx, %r15
    2139:      	movl	%esi, %ebx
    213b:      	movq	%rdi, %r14
    213e:      	movl	%esi, %eax
    2140:      	movslq	0x4(%rdx,%rax,4), %r12
    2145:      	movl	$0x0, 0x50(%rsp)
    214d:      	movq	(%rip), %rdi            # 0x2154 <do_action+0x34>
    2154:      	leaq	0x50(%rsp), %rsi
    2159:      	movl	$0x1, %eax
    215e:      	callq	*%rax
    2160:      	movq	%rax, %r13
    2163:      	xorl	%eax, %eax
    2165:      	testq	%r13, %r13
    2168:      	je	0x2980 <do_action+0x860>
    216e:      	cmpl	$0x7, %r12d
    2172:      	jg	0x219c <do_action+0x7c>
    2174:      	cmpl	$0x3, %r12d
    2178:      	jg	0x21d4 <do_action+0xb4>
    217a:      	cmpl	$0x1, %r12d
    217e:      	jg	0x2307 <do_action+0x1e7>
    2184:      	testl	%r12d, %r12d
    2187:      	je	0x25ac <do_action+0x48c>
    218d:      	cmpl	$0x1, %r12d
    2191:      	je	0x2320 <do_action+0x200>
    2197:      	jmp	0x2978 <do_action+0x858>
    219c:      	cmpl	$0xb, %r12d
    21a0:      	jg	0x22d9 <do_action+0x1b9>
    21a6:      	leal	-0xa(%r12), %ecx
    21ab:      	cmpl	$0x2, %ecx
    21ae:      	jb	0x242b <do_action+0x30b>
    21b4:      	cmpl	$0x8, %r12d
    21b8:      	je	0x2518 <do_action+0x3f8>
    21be:      	cmpl	$0x9, %r12d
    21c2:      	jne	0x2978 <do_action+0x858>
    21c8:      	incl	%ebx
    21ca:      	movl	0x4(%r15,%rbx,4), %eax
    21cf:      	jmp	0x24e4 <do_action+0x3c4>
    21d4:      	leal	-0x6(%r12), %eax
    21d9:      	cmpl	$0x2, %eax
    21dc:      	jb	0x2508 <do_action+0x3e8>
    21e2:      	cmpl	$0x4, %r12d
    21e6:      	je	0x2525 <do_action+0x405>
    21ec:      	cmpl	$0x5, %r12d
    21f0:      	jne	0x2978 <do_action+0x858>
    21f6:      	leal	0x1(%rbx), %eax
    21f9:      	movl	0x4(%r15,%rax,4), %eax
    21fe:      	addl	$0x2, %ebx
    2201:      	andl	$0x7, %eax
    2204:      	cmpl	$0x4, %eax
    2207:      	ja	0x2978 <do_action+0x858>
    220d:      	cmpl	$0x0, 0x5ea0(%r13,%rax,4)
    2216:      	jne	0x2978 <do_action+0x858>
    221c:      	movl	0x4(%r15,%rbx,4), %r14d
    2221:      	movq	0x5e78(%r13,%rax,8), %rax
    2229:      	movl	$0x0, 0xc(%rsp)
    2231:      	andl	$0x7ff, %eax            # imm = 0x7FF
    2236:      	movl	0x90(%r13,%rax), %eax
    223e:      	movl	%eax, 0x8(%rsp)
    2242:      	movl	$0xe, %eax
    2247:      	callq	*%rax
    2249:      	shrq	$0x20, %rax
    224d:      	movq	%rax, (%rsp)
    2251:      	movq	(%rip), %rdi            # 0x2258 <do_action+0x138>
    2258:      	movq	%rsp, %rsi
    225b:      	movl	$0x1, %eax
    2260:      	callq	*%rax
    2262:      	testq	%rax, %rax
    2265:      	je	0x2978 <do_action+0x858>
    226b:      	andl	$0x7, %r14d
    226f:      	cmpl	$0x4, %r14d
    2273:      	ja	0x2978 <do_action+0x858>
    2279:      	cmpl	$0x0, 0x5ea0(%r13,%r14,4)
    2282:      	jne	0x2978 <do_action+0x858>
    2288:      	movq	0x5e78(%r13,%r14,8), %rcx
    2290:      	movl	$0x0, 0xc(%rsp)
    2298:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    229e:      	movl	0x90(%r13,%rcx), %ecx
    22a6:      	movl	%ecx, 0x8(%rsp)
    22aa:      	movq	%rax, %r15
    22ad:      	movl	$0xe, %eax
    22b2:      	callq	*%rax
    22b4:      	shrq	$0x20, %rax
    22b8:      	movq	%rax, (%rsp)
    22bc:      	movq	(%rip), %rdi            # 0x22c3 <do_action+0x1a3>
    22c3:      	xorl	%ecx, %ecx
    22c5:      	movq	%rsp, %rsi
    22c8:      	movl	$0x2, %eax
    22cd:      	movq	%r15, %rdx
    22d0:      	xorl	%ecx, %ecx
    22d2:      	callq	*%rax
    22d4:      	jmp	0x2978 <do_action+0x858>
    22d9:      	cmpl	$0xc, %r12d
    22dd:      	je	0x2668 <do_action+0x548>
    22e3:      	cmpl	$0xd, %r12d
    22e7:      	je	0x2534 <do_action+0x414>
    22ed:      	cmpl	$0xe, %r12d
    22f1:      	jne	0x2978 <do_action+0x858>
    22f7:      	addl	$0x2, %ebx
    22fa:      	movzbl	%bpl, %r14d
    22fe:      	xorq	$0x9, %r14
    2302:      	jmp	0x2673 <do_action+0x553>
    2307:      	movl	$0x9, %eax
    230c:      	cmpl	$0x2, %r12d
    2310:      	je	0x24e4 <do_action+0x3c4>
    2316:      	cmpl	$0x3, %r12d
    231a:      	jne	0x2978 <do_action+0x858>
    2320:      	leal	0x1(%rbx), %eax
    2323:      	movl	0x4(%r15,%rax,4), %ebp
    2328:      	addl	$0x2, %ebx
    232b:      	movl	0x4(%r15,%rbx,4), %r14d
    2330:      	movl	$0x0, 0x10(%rsp)
    2338:      	movq	(%rip), %rdi            # 0x233f <do_action+0x21f>
    233f:      	leaq	0x10(%rsp), %rsi
    2344:      	movl	$0x1, %eax
    2349:      	callq	*%rax
    234b:      	xorl	%r15d, %r15d
    234e:      	testq	%rax, %rax
    2351:      	je	0x272b <do_action+0x60b>
    2357:      	movq	%rax, 0x38(%rsp)
    235c:      	andl	$0x7, %ebp
    235f:      	cmpl	$0x4, %ebp
    2362:      	movl	$0x0, %eax
    2367:      	ja	0x272d <do_action+0x60d>
    236d:      	cmpl	$0x0, 0x5ea0(%r13,%rbp,4)
    2376:      	jne	0x272d <do_action+0x60d>
    237c:      	movq	0x5e78(%r13,%rbp,8), %rax
    2384:      	movl	$0x0, 0xc(%rsp)
    238c:      	andl	$0x7ff, %eax            # imm = 0x7FF
    2391:      	movl	0x90(%r13,%rax), %eax
    2399:      	movl	%eax, 0x8(%rsp)
    239d:      	movl	$0xe, %eax
    23a2:      	callq	*%rax
    23a4:      	shrq	$0x20, %rax
    23a8:      	movq	%rax, (%rsp)
    23ac:      	cmpl	$0x1, %r12d
    23b0:      	jne	0x2704 <do_action+0x5e4>
    23b6:      	andl	$0x7, %r14d
    23ba:      	cmpl	$0x4, %r14d
    23be:      	ja	0x272b <do_action+0x60b>
    23c4:      	cmpl	$0x0, 0x5ea0(%r13,%r14,4)
    23cd:      	movl	$0x0, %eax
    23d2:      	jne	0x272d <do_action+0x60d>
    23d8:      	movq	0x5e78(%r13,%r14,8), %rax
    23e0:      	andl	$0x7ff, %eax            # imm = 0x7FF
    23e5:      	leaq	(%rax,%r13), %rdx
    23e9:      	addq	$0x90, %rdx
    23f0:      	movl	0x90(%r13,%rax), %esi
    23f8:      	andl	$0xfff, %esi            # imm = 0xFFF
    23fe:      	addq	$0x8, %rsi
    2402:      	movl	$0x4, %eax
    2407:      	movq	0x38(%rsp), %r14
    240c:      	movq	%r14, %rdi
    240f:      	callq	*%rax
    2411:      	movq	(%rip), %rdi            # 0x2418 <do_action+0x2f8>
    2418:      	xorl	%r15d, %r15d
    241b:      	movq	%rsp, %rsi
    241e:      	movl	$0x2, %eax
    2423:      	movq	%r14, %rdx
    2426:      	jmp	0x24db <do_action+0x3bb>
    242b:      	incl	%ebx
    242d:      	movl	0x4(%r15,%rbx,4), %ecx
    2432:      	andl	$0x7, %ecx
    2435:      	xorl	%r15d, %r15d
    2438:      	cmpl	$0x4, %ecx
    243b:      	ja	0x272d <do_action+0x60d>
    2441:      	cmpl	$0x0, 0x5ea0(%r13,%rcx,4)
    244a:      	jne	0x272d <do_action+0x60d>
    2450:      	movq	0x5e78(%r13,%rcx,8), %rcx
    2458:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    245e:      	movq	0xb8(%r13,%rcx), %rcx
    2466:      	movq	%rcx, 0x10(%rsp)
    246b:      	testq	%rcx, %rcx
    246e:      	je	0x272d <do_action+0x60d>
    2474:      	cmpl	$0xa, %r12d
    2478:      	jne	0x2715 <do_action+0x5f5>
    247e:      	movl	$0xe, %eax
    2483:      	callq	*%rax
    2485:      	movq	%rax, %r14
    2488:      	shrq	$0x20, %rax
    248c:      	movl	%eax, (%rsp)
    248f:      	movq	(%rip), %rdi            # 0x2496 <do_action+0x376>
    2496:      	movq	%rsp, %rsi
    2499:      	movl	$0x1, %eax
    249e:      	callq	*%rax
    24a0:      	movq	%rax, %rcx
    24a3:      	testq	%rax, %rax
    24a6:      	movl	$0x0, %eax
    24ab:      	je	0x272d <do_action+0x60d>
    24b1:      	movl	(%rcx), %eax
    24b3:      	movl	%eax, (%rsp)
    24b6:      	movl	%r14d, 0x4(%rsp)
    24bb:      	movq	0x8(%rcx), %rax
    24bf:      	movq	%rax, 0x8(%rsp)
    24c4:      	movq	(%rip), %rdi            # 0x24cb <do_action+0x3ab>
    24cb:      	xorl	%r15d, %r15d
    24ce:      	leaq	0x10(%rsp), %rsi
    24d3:      	movq	%rsp, %rdx
    24d6:      	movl	$0x2, %eax
    24db:      	xorl	%ecx, %ecx
    24dd:      	callq	*%rax
    24df:      	jmp	0x272b <do_action+0x60b>
    24e4:      	movl	$0x3, %r14d
    24ea:      	testb	%bpl, %bpl
    24ed:      	je	0x2673 <do_action+0x553>
    24f3:      	movslq	%eax, %rdi
    24f6:      	movl	$0x6d, %eax
    24fb:      	callq	*%rax
    24fd:      	movl	$0x2, %r14d
    2503:      	jmp	0x2673 <do_action+0x553>
    2508:      	incl	%ebx
    250a:      	movl	0x4(%r15,%rbx,4), %eax
    250f:      	movl	%eax, 0x78(%r13)
    2513:      	jmp	0x2978 <do_action+0x858>
    2518:      	movq	0x38(%rsp), %rax
    251d:      	movb	$0x0, (%rax)
    2520:      	jmp	0x2978 <do_action+0x858>
    2525:      	incl	%ebx
    2527:      	movzbl	%bpl, %r14d
    252b:      	xorq	$0x5, %r14
    252f:      	jmp	0x2673 <do_action+0x553>
    2534:      	movl	$0xe, %eax
    2539:      	callq	*%rax
    253b:      	movq	%rax, 0x20(%rsp)
    2540:      	movq	(%rip), %rdi            # 0x2547 <do_action+0x427>
    2547:      	leaq	0x20(%rsp), %rsi
    254c:      	movl	$0x1, %eax
    2551:      	callq	*%rax
    2553:      	testq	%rax, %rax
    2556:      	je	0x2978 <do_action+0x858>
    255c:      	movq	0x4(%rax), %rax
    2560:      	movq	%rax, 0x10(%rsp)
    2565:      	movl	$0x2, 0x18(%rsp)
    256d:      	movq	(%rip), %rdi            # 0x2574 <do_action+0x454>
    2574:      	leaq	0x10(%rsp), %rsi
    2579:      	movl	$0x1, %eax
    257e:      	callq	*%rax
    2580:      	movl	$0x1, 0x2c(%rsp)
    2588:      	testq	%rax, %rax
    258b:      	je	0x269e <do_action+0x57e>
    2591:      	lock
    2592:      	incl	(%rax)
    2594:      	movq	(%rip), %rdi            # 0x259b <do_action+0x47b>
    259b:      	leaq	0x20(%rsp), %rsi
    25a0:      	movl	$0x3, %eax
    25a5:      	callq	*%rax
    25a7:      	jmp	0x2978 <do_action+0x858>
    25ac:      	leal	0x1(%rbx), %eax
    25af:      	movl	0x4(%r15,%rax,4), %ebp
    25b4:      	leal	0x2(%rbx), %eax
    25b7:      	movl	0x4(%r15,%rax,4), %eax
    25bc:      	movl	%eax, 0x30(%rsp)
    25c0:      	movl	$0x7d, %eax
    25c5:      	callq	*%rax
    25c7:      	movq	%rax, 0x68(%rsp)
    25cc:      	movq	%rax, (%rsp)
    25d0:      	movl	$0x0, 0x20(%rsp)
    25d8:      	movq	%rbp, 0x70(%rsp)
    25dd:      	testq	%rbp, %rbp
    25e0:      	je	0x290a <do_action+0x7ea>
    25e6:      	movq	(%rip), %rdi            # 0x25ed <do_action+0x4cd>
    25ed:      	leaq	0x20(%rsp), %rsi
    25f2:      	movl	$0x1, %eax
    25f7:      	callq	*%rax
    25f9:      	testq	%rax, %rax
    25fc:      	je	0x290a <do_action+0x7ea>
    2602:      	movq	%rax, 0x48(%rsp)
    2607:      	movq	%rax, %rbp
    260a:      	movq	(%rip), %rdi            # 0x2611 <do_action+0x4f1>
    2611:      	leaq	0x20(%rsp), %rsi
    2616:      	movl	$0x1, %eax
    261b:      	callq	*%rax
    261d:      	movq	%rax, %rdx
    2620:      	movq	0x60(%r13), %rax
    2624:      	movq	%rax, (%rbp)
    2628:      	movq	0x70(%r13), %rax
    262c:      	movq	%rbp, 0x40(%rsp)
    2631:      	movq	%rax, 0x8(%rbp)
    2635:      	xorl	%eax, %eax
    2637:      	movq	%rax, 0x60(%rsp)
    263c:      	movl	$0x0, %eax
    2641:      	movl	0x30(%rsp), %ecx
    2645:      	cmpl	$0x2, %ecx
    2648:      	je	0x273f <do_action+0x61f>
    264e:      	cmpl	$0x1, %ecx
    2651:      	je	0x273b <do_action+0x61b>
    2657:      	testl	%ecx, %ecx
    2659:      	jne	0x290a <do_action+0x7ea>
    265f:      	movl	0x7c(%r13), %eax
    2663:      	jmp	0x273f <do_action+0x61f>
    2668:      	addl	$0x3, %ebx
    266b:      	movzbl	%bpl, %r14d
    266f:      	xorq	$0x7, %r14
    2673:      	movl	$0x0, (%rsp)
    267a:      	movq	(%rip), %rdi            # 0x2681 <do_action+0x561>
    2681:      	movq	%rsp, %rsi
    2684:      	movl	$0x1, %eax
    2689:      	callq	*%rax
    268b:      	testq	%rax, %rax
    268e:      	je	0x2978 <do_action+0x858>
    2694:      	lock
    2695:      	incq	(%rax,%r14,8)
    2699:      	jmp	0x2978 <do_action+0x858>
    269e:      	movq	(%rip), %rdi            # 0x26a5 <do_action+0x585>
    26a5:      	leaq	0x10(%rsp), %rsi
    26aa:      	leaq	0x2c(%rsp), %rdx
    26af:      	movl	$0x1, %ecx
    26b4:      	movl	$0x2, %eax
    26b9:      	callq	*%rax
    26bb:      	testq	%rax, %rax
    26be:      	je	0x2594 <do_action+0x474>
    26c4:      	movq	%rax, %r15
    26c7:      	negl	%eax
    26c9:      	movw	%ax, (%rsp)
    26cd:      	movw	$0x3, 0x2(%rsp)
    26d4:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    26de:      	movq	%rax, 0x4(%rsp)
    26e3:      	movq	(%rip), %rdi            # 0x26ea <do_action+0x5ca>
    26ea:      	movq	%rsp, %rsi
    26ed:      	movl	$0x1, %eax
    26f2:      	callq	*%rax
    26f4:      	testq	%rax, %rax
    26f7:      	je	0x298f <do_action+0x86f>
    26fd:      	incl	(%rax)
    26ff:      	jmp	0x29b1 <do_action+0x891>
    2704:      	movq	(%rip), %rdi            # 0x270b <do_action+0x5eb>
    270b:      	movq	%rsp, %rsi
    270e:      	movl	$0x3, %eax
    2713:      	jmp	0x2726 <do_action+0x606>
    2715:      	movq	(%rip), %rdi            # 0x271c <do_action+0x5fc>
    271c:      	leaq	0x10(%rsp), %rsi
    2721:      	movl	$0x3, %eax
    2726:      	callq	*%rax
    2728:      	movq	%rax, %r15
    272b:      	xorl	%eax, %eax
    272d:      	testl	%r15d, %r15d
    2730:      	jne	0x2980 <do_action+0x860>
    2736:      	jmp	0x2978 <do_action+0x858>
    273b:      	movl	0x10(%r13), %eax
    273f:      	movq	%r14, 0x30(%rsp)
    2744:      	movl	%eax, %eax
    2746:      	movq	0x40(%rsp), %rcx
    274b:      	movq	%rax, 0x10(%rcx)
    274f:      	movq	0x48(%rsp), %rdi
    2754:      	addq	$0x18, %rdi
    2758:      	movl	$0xc8, %ecx
    275d:      	movl	$0x4, %eax
    2762:      	movq	%rdi, 0x48(%rsp)
    2767:      	movl	$0xc8, %esi
    276c:      	callq	*%rax
    276e:      	xorl	%r14d, %r14d
    2771:      	movq	%r13, 0x58(%rsp)
    2776:      	jmp	0x2786 <do_action+0x666>
    2778:      	addq	$0x4, %r14
    277c:      	cmpq	$0x14, %r14
    2780:      	je	0x28b3 <do_action+0x793>
    2786:      	movl	$0x0, 0x10(%rsp)
    278e:      	movl	$0x1, %eax
    2793:      	movq	(%rip), %rdi            # 0x279a <do_action+0x67a>
    279a:      	leaq	0x10(%rsp), %rsi
    279f:      	callq	*%rax
    27a1:      	testq	%rax, %rax
    27a4:      	je	0x28b3 <do_action+0x793>
    27aa:      	movq	%rax, %rsi
    27ad:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    27b4:      	movl	$0x1, %eax
    27b9:      	movq	(%rip), %rdi            # 0x27c0 <do_action+0x6a0>
    27c0:      	callq	*%rax
    27c2:      	testq	%rax, %rax
    27c5:      	je	0x28b3 <do_action+0x793>
    27cb:      	cmpl	$-0x1, 0x40(%rax,%r14)
    27d1:      	je	0x28b3 <do_action+0x793>
    27d7:      	movq	0x5e78(%r13,%r14,2), %rax
    27df:      	movl	0x4(%r13), %ecx
    27e3:      	cmpq	%rcx, %rax
    27e6:      	jge	0x28b3 <do_action+0x793>
    27ec:      	cmpq	$0x10, %r14
    27f0:      	je	0x2853 <do_action+0x733>
    27f2:      	movl	$0x0, 0x10(%rsp)
    27fa:      	movl	$0x1, %eax
    27ff:      	movq	(%rip), %rdi            # 0x2806 <do_action+0x6e6>
    2806:      	leaq	0x10(%rsp), %rsi
    280b:      	callq	*%rax
    280d:      	testq	%rax, %rax
    2810:      	je	0x284b <do_action+0x72b>
    2812:      	movq	%rax, %rsi
    2815:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    281c:      	movl	$0x1, %eax
    2821:      	movq	(%rip), %rdi            # 0x2828 <do_action+0x708>
    2828:      	callq	*%rax
    282a:      	testq	%rax, %rax
    282d:      	je	0x284b <do_action+0x72b>
    282f:      	cmpl	$-0x1, 0x44(%rax,%r14)
    2835:      	movq	0x5e78(%r13,%r14,2), %rax
    283d:      	je	0x2853 <do_action+0x733>
    283f:      	movl	0x5e80(%r13,%r14,2), %ebp
    2847:      	subl	%eax, %ebp
    2849:      	jmp	0x285c <do_action+0x73c>
    284b:      	movq	0x5e78(%r13,%r14,2), %rax
    2853:      	movl	0x4(%r13), %ebp
    2857:      	subl	%eax, %ebp
    2859:      	addl	$0x4, %ebp
    285c:      	testl	%ebp, %ebp
    285e:      	jle	0x2778 <do_action+0x658>
    2864:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    2869:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    286e:      	cmpl	$0x28, %ebp
    2871:      	movl	$0x28, %ecx
    2876:      	cmovgel	%ecx, %ebp
    2879:      	movzbl	0x60(%rsp), %r13d
    287f:      	movq	0x48(%rsp), %rcx
    2884:      	leaq	(%rcx,%r13), %rdi
    2888:      	movq	0x58(%rsp), %rcx
    288d:      	leaq	(%rcx,%rax), %rdx
    2891:      	addq	$0x90, %rdx
    2898:      	movl	$0x4, %eax
    289d:      	movl	%ebp, %esi
    289f:      	callq	*%rax
    28a1:      	addl	%r13d, %ebp
    28a4:      	movq	0x58(%rsp), %r13
    28a9:      	movq	%rbp, 0x60(%rsp)
    28ae:      	jmp	0x2778 <do_action+0x658>
    28b3:      	movq	(%rip), %rdi            # 0x28ba <do_action+0x79a>
    28ba:      	movl	$0x1, %eax
    28bf:      	movq	0x40(%rsp), %rsi
    28c4:      	callq	*%rax
    28c6:      	testq	%rax, %rax
    28c9:      	je	0x28eb <do_action+0x7cb>
    28cb:      	imulq	$-0xf4240, 0x70(%rsp), %rcx # imm = 0xFFF0BDC0
    28d4:      	movq	0x68(%rsp), %rdx
    28d9:      	addq	%rcx, %rdx
    28dc:      	cmpq	%rdx, (%rax)
    28df:      	jbe	0x28eb <do_action+0x7cb>
    28e1:      	movq	0x38(%rsp), %rax
    28e6:      	movb	$0x0, (%rax)
    28e9:      	jmp	0x2905 <do_action+0x7e5>
    28eb:      	movq	(%rip), %rdi            # 0x28f2 <do_action+0x7d2>
    28f2:      	xorl	%ecx, %ecx
    28f4:      	movq	%rsp, %rdx
    28f7:      	movl	$0x2, %eax
    28fc:      	movq	0x40(%rsp), %rsi
    2901:      	xorl	%ecx, %ecx
    2903:      	callq	*%rax
    2905:      	movq	0x30(%rsp), %r14
    290a:      	leal	0x3(%rbx), %eax
    290d:      	cmpl	$0x0, 0x4(%r15,%rax,4)
    2913:      	je	0x2936 <do_action+0x816>
    2915:      	orb	$0x2, 0x1(%r13)
    291a:      	movq	(%rip), %rsi            # 0x2921 <do_action+0x801>
    2921:      	xorl	%ecx, %ecx
    2923:      	movl	$0x1b, %eax
    2928:      	movq	%r14, %rdi
    292b:      	xorl	%edx, %edx
    292d:      	callq	*%rax
    292f:      	movq	%rax, 0x80(%r13)
    2936:      	leal	0x4(%rbx), %eax
    2939:      	cmpl	$0x0, 0x4(%r15,%rax,4)
    293f:      	je	0x2968 <do_action+0x848>
    2941:      	orb	$0x4, 0x1(%r13)
    2946:      	movq	(%rip), %rsi            # 0x294d <do_action+0x82d>
    294d:      	movl	$0x100, %ecx            # imm = 0x100
    2952:      	movl	$0x1b, %eax
    2957:      	movl	$0x100, %edx            # imm = 0x100
    295c:      	movq	%r14, %rdi
    295f:      	callq	*%rax
    2961:      	movq	%rax, 0x88(%r13)
    2968:      	addl	$0x5, %ebx
    296b:      	cmpl	$0x0, 0x4(%r15,%rbx,4)
    2971:      	je	0x2978 <do_action+0x858>
    2973:      	orb	$0x8, 0x1(%r13)
    2978:      	movq	%r12, 0x70(%r13)
    297c:      	incl	%ebx
    297e:      	movl	%ebx, %eax
    2980:      	addq	$0x78, %rsp
    2984:      	popq	%rbx
    2985:      	popq	%r12
    2987:      	popq	%r13
    2989:      	popq	%r14
    298b:      	popq	%r15
    298d:      	popq	%rbp
    298e:      	retq
    298f:      	movl	$0x1, 0x54(%rsp)
    2997:      	movq	(%rip), %rdi            # 0x299e <do_action+0x87e>
    299e:      	xorl	%ecx, %ecx
    29a0:      	movq	%rsp, %rsi
    29a3:      	leaq	0x54(%rsp), %rdx
    29a8:      	movl	$0x2, %eax
    29ad:      	xorl	%ecx, %ecx
    29af:      	callq	*%rax
    29b1:      	testl	%r15d, %r15d
    29b4:      	je	0x2594 <do_action+0x474>
    29ba:      	movq	(%rip), %rdi            # 0x29c1 <do_action+0x8a1>
    29c1:      	leaq	0x10(%rsp), %rsi
    29c6:      	movl	$0x1, %eax
    29cb:      	callq	*%rax
    29cd:      	testq	%rax, %rax
    29d0:      	je	0x2594 <do_action+0x474>
    29d6:      	movl	0x2c(%rsp), %ecx
    29da:      	lock
    29db:      	addl	%ecx, (%rax)
    29dd:      	jmp	0x2594 <do_action+0x474>

Disassembly of section uprobe:

0000000000000000 <generic_retuprobe_filter_arg>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x28, %rsp
       e:      	movq	%rdi, %rbx
      11:      	movl	$0x0, 0x4(%rsp)
      19:      	movq	(%rip), %rdi            # 0x20 <generic_retuprobe_filter_arg+0x20>
      20:      	leaq	0x4(%rsp), %rsi
      25:      	movl	$0x1, %eax
      2a:      	callq	*%rax
      2c:      	testq	%rax, %rax
      2f:      	je	0x398 <generic_retuprobe_filter_arg+0x398>
      35:      	movq	%rax, %r14
      38:      	movl	0x5f00(%rax), %r12d
      3f:      	leaq	0x5ef8(%rax), %rsi
      46:      	movq	(%rip), %rdi            # 0x4d <generic_retuprobe_filter_arg+0x4d>
      4d:      	movl	$0x1, %eax
      52:      	callq	*%rax
      54:      	testq	%rax, %rax
      57:      	je	0x37d <generic_retuprobe_filter_arg+0x37d>
      5d:      	cmpb	$0x0, 0x5ee0(%r14)
      65:      	je	0x37d <generic_retuprobe_filter_arg+0x37d>
      6b:      	movq	%rax, %r15
      6e:      	movl	%r12d, %eax
      71:      	andl	$0x7, %eax
      74:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
      7d:      	je	0xb7 <generic_retuprobe_filter_arg+0xb7>
      7f:      	movl	%eax, %eax
      81:      	movl	0x4(%r15,%rax,4), %ecx
      86:      	leaq	(%rcx,%rax,4), %r13
      8a:      	addq	$0x8, %r13
      8e:      	movq	%r13, %rax
      91:      	movq	%r13, 0x10(%rsp)
      96:      	andl	$0x3ff, %r13d           # imm = 0x3FF
      9d:      	cmpl	$0x19, (%r15,%r13)
      a2:      	jae	0x10c <generic_retuprobe_filter_arg+0x10c>
      a4:      	cmpq	$0x1, %r13
      a8:      	je	0x37d <generic_retuprobe_filter_arg+0x37d>
      ae:      	testl	%r13d, %r13d
      b1:      	jne	0x35b <generic_retuprobe_filter_arg+0x35b>
      b7:      	cmpl	$0x1, %r12d
      bb:      	jg	0xdc <generic_retuprobe_filter_arg+0xdc>
      bd:      	cmpl	$-0x1, %r12d
      c1:      	je	0x3a9 <generic_retuprobe_filter_arg+0x3a9>
      c7:      	testl	%r12d, %r12d
      ca:      	je	0x3b6 <generic_retuprobe_filter_arg+0x3b6>
      d0:      	cmpl	$0x1, %r12d
      d4:      	je	0x3c6 <generic_retuprobe_filter_arg+0x3c6>
      da:      	jmp	0xfa <generic_retuprobe_filter_arg+0xfa>
      dc:      	cmpl	$0x2, %r12d
      e0:      	je	0x3d6 <generic_retuprobe_filter_arg+0x3d6>
      e6:      	cmpl	$0x3, %r12d
      ea:      	je	0x3e6 <generic_retuprobe_filter_arg+0x3e6>
      f0:      	cmpl	$0x4, %r12d
      f4:      	je	0x3f6 <generic_retuprobe_filter_arg+0x3f6>
      fa:      	cmpl	$0x4, %r12d
      fe:      	jg	0x428 <generic_retuprobe_filter_arg+0x428>
     104:      	incl	%r12d
     107:      	jmp	0x406 <generic_retuprobe_filter_arg+0x406>
     10c:      	leaq	(%r15,%r13), %rax
     110:      	movq	%rax, 0x8(%rsp)
     115:      	movl	$0x1, %ebp
     11a:      	nopw	(%rax,%rax)
     120:      	movq	0x8(%rsp), %rax
     125:      	movl	(%rax,%rbp,4), %edi
     128:      	testl	$0x3ff, %edi            # imm = 0x3FF
     12e:      	je	0xa4 <generic_retuprobe_filter_arg+0xa4>
     134:      	addl	0x10(%rsp), %edi
     138:      	andl	$0x3ff, %edi            # imm = 0x3FF
     13e:      	movl	0x4(%r15,%rdi), %ecx
     143:      	cmpl	$0x23, %ecx
     146:      	je	0xb7 <generic_retuprobe_filter_arg+0xb7>
     14c:      	addq	%r15, %rdi
     14f:      	movl	(%rdi), %eax
     151:      	cmpq	$0x4, %rax
     155:      	ja	0xb7 <generic_retuprobe_filter_arg+0xb7>
     15b:      	cmpl	$0x0, 0x5ea0(%r14,%rax,4)
     164:      	jne	0xb7 <generic_retuprobe_filter_arg+0xb7>
     16a:      	movq	0x5e78(%r14,%rax,8), %rax
     172:      	andl	$0x7ff, %eax            # imm = 0x7FF
     177:      	leaq	(%r14,%rax), %rsi
     17b:      	addq	$0x90, %rsi
     182:      	movl	0xc(%rdi), %eax
     185:      	cmpl	$0x1b, %eax
     188:      	jle	0x1a9 <generic_retuprobe_filter_arg+0x1a9>
     18a:      	cmpl	$0x25, %eax
     18d:      	jg	0x1d9 <generic_retuprobe_filter_arg+0x1d9>
     18f:      	leal	-0x1c(%rax), %edx
     192:      	cmpl	$0x9, %edx
     195:      	jb	0x21f <generic_retuprobe_filter_arg+0x21f>
     19b:      	cmpl	$0x25, %eax
     19e:      	je	0x302 <generic_retuprobe_filter_arg+0x302>
     1a4:      	jmp	0x349 <generic_retuprobe_filter_arg+0x349>
     1a9:      	cmpl	$0x9, %eax
     1ac:      	jle	0x1ff <generic_retuprobe_filter_arg+0x1ff>
     1ae:      	leal	-0xa(%rax), %edx
     1b1:      	cmpl	$0x4, %edx
     1b4:      	jb	0x21f <generic_retuprobe_filter_arg+0x21f>
     1b6:      	leal	-0xf(%rax), %ecx
     1b9:      	cmpl	$0x2, %ecx
     1bc:      	jb	0x302 <generic_retuprobe_filter_arg+0x302>
     1c2:      	cmpl	$0x11, %eax
     1c5:      	jne	0x349 <generic_retuprobe_filter_arg+0x349>
     1cb:      	addq	$0x4, %rsi
     1cf:      	callq	0x1d4 <generic_retuprobe_filter_arg+0x1d4>
     1d4:      	jmp	0x340 <generic_retuprobe_filter_arg+0x340>
     1d9:      	cmpl	$0x29, %eax
     1dc:      	jg	0x2f1 <generic_retuprobe_filter_arg+0x2f1>
     1e2:      	leal	-0x26(%rax), %ecx
     1e5:      	cmpl	$0x2, %ecx
     1e8:      	jb	0x2ac <generic_retuprobe_filter_arg+0x2ac>
     1ee:      	addl	$-0x28, %eax
     1f1:      	cmpl	$0x2, %eax
     1f4:      	jb	0x2a2 <generic_retuprobe_filter_arg+0x2a2>
     1fa:      	jmp	0x349 <generic_retuprobe_filter_arg+0x349>
     1ff:      	cmpl	$0x4, %eax
     202:      	jg	0x28f <generic_retuprobe_filter_arg+0x28f>
     208:      	cmpl	$0x1, %eax
     20b:      	je	0x21f <generic_retuprobe_filter_arg+0x21f>
     20d:      	cmpl	$0x2, %eax
     210:      	je	0x31f <generic_retuprobe_filter_arg+0x31f>
     216:      	cmpl	$0x4, %eax
     219:      	jne	0x349 <generic_retuprobe_filter_arg+0x349>
     21f:      	cmpl	$0xb, %eax
     222:      	jle	0x26c <generic_retuprobe_filter_arg+0x26c>
     224:      	cmpl	$0x24, %eax
     227:      	ja	0x309 <generic_retuprobe_filter_arg+0x309>
     22d:      	movl	%eax, %edx
     22f:      	movabsq	$0x1e00000000, %r8      # imm = 0x1E00000000
     239:      	btq	%rdx, %r8
     23d:      	jb	0x2b3 <generic_retuprobe_filter_arg+0x2b3>
     23f:      	movl	$0x60000000, %ecx       # imm = 0x60000000
     244:      	btq	%rdx, %rcx
     248:      	jb	0x318 <generic_retuprobe_filter_arg+0x318>
     24e:      	movabsq	$0x180000000, %rcx      # imm = 0x180000000
     258:      	btq	%rdx, %rcx
     25c:      	jae	0x309 <generic_retuprobe_filter_arg+0x309>
     262:      	callq	0x267 <generic_retuprobe_filter_arg+0x267>
     267:      	jmp	0x340 <generic_retuprobe_filter_arg+0x340>
     26c:      	leal	-0xa(%rax), %ecx
     26f:      	cmpl	$0x2, %ecx
     272:      	jb	0x330 <generic_retuprobe_filter_arg+0x330>
     278:      	cmpl	$0x1, %eax
     27b:      	je	0x311 <generic_retuprobe_filter_arg+0x311>
     281:      	cmpl	$0x4, %eax
     284:      	je	0x311 <generic_retuprobe_filter_arg+0x311>
     28a:      	jmp	0x349 <generic_retuprobe_filter_arg+0x349>
     28f:      	cmpl	$0x5, %eax
     292:      	je	0x2a2 <generic_retuprobe_filter_arg+0x2a2>
     294:      	cmpl	$0x6, %eax
     297:      	je	0x2ac <generic_retuprobe_filter_arg+0x2ac>
     299:      	cmpl	$0x7, %eax
     29c:      	jne	0x349 <generic_retuprobe_filter_arg+0x349>
     2a2:      	callq	0x2a7 <generic_retuprobe_filter_arg+0x2a7>
     2a7:      	jmp	0x340 <generic_retuprobe_filter_arg+0x340>
     2ac:      	movl	$0x4, %edx
     2b1:      	jmp	0x324 <generic_retuprobe_filter_arg+0x324>
     2b3:      	cmpl	$0x1e, %ecx
     2b6:      	jne	0x330 <generic_retuprobe_filter_arg+0x330>
     2b8:      	movl	0x10(%rdi), %eax
     2bb:      	andl	$0x7, %eax
     2be:      	movl	%eax, %ecx
     2c0:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
     2c9:      	jne	0xb7 <generic_retuprobe_filter_arg+0xb7>
     2cf:      	movq	(%rsi), %rcx
     2d2:      	movq	0x5e78(%r14,%rax,8), %rdx
     2da:      	andl	$0x7ff, %edx            # imm = 0x7FF
     2e0:      	xorl	%eax, %eax
     2e2:      	andnq	0x90(%r14,%rdx), %rcx, %rcx
     2ec:      	setne	%al
     2ef:      	jmp	0x340 <generic_retuprobe_filter_arg+0x340>
     2f1:      	cmpl	$0x2a, %eax
     2f4:      	je	0x302 <generic_retuprobe_filter_arg+0x302>
     2f6:      	cmpl	$0x2c, %eax
     2f9:      	jne	0x349 <generic_retuprobe_filter_arg+0x349>
     2fb:      	callq	0x300 <generic_retuprobe_filter_arg+0x300>
     300:      	jmp	0x340 <generic_retuprobe_filter_arg+0x340>
     302:      	callq	0x307 <generic_retuprobe_filter_arg+0x307>
     307:      	jmp	0x340 <generic_retuprobe_filter_arg+0x340>
     309:      	leal	-0xc(%rax), %ecx
     30c:      	cmpl	$0x2, %ecx
     30f:      	jae	0x32b <generic_retuprobe_filter_arg+0x32b>
     311:      	callq	0x316 <generic_retuprobe_filter_arg+0x316>
     316:      	jmp	0x340 <generic_retuprobe_filter_arg+0x340>
     318:      	callq	0x31d <generic_retuprobe_filter_arg+0x31d>
     31d:      	jmp	0x340 <generic_retuprobe_filter_arg+0x340>
     31f:      	movl	$0x8, %edx
     324:      	callq	0x329 <generic_retuprobe_filter_arg+0x329>
     329:      	jmp	0x340 <generic_retuprobe_filter_arg+0x340>
     32b:      	cmpl	$0x1c, %eax
     32e:      	jne	0x349 <generic_retuprobe_filter_arg+0x349>
     330:      	callq	0x335 <generic_retuprobe_filter_arg+0x335>
     335:      	nopw	%cs:(%rax,%rax)
     340:      	testq	%rax, %rax
     343:      	je	0xb7 <generic_retuprobe_filter_arg+0xb7>
     349:      	incq	%rbp
     34c:      	cmpq	$0x6, %rbp
     350:      	jne	0x120 <generic_retuprobe_filter_arg+0x120>
     356:      	jmp	0xa4 <generic_retuprobe_filter_arg+0xa4>
     35b:      	movl	%r13d, 0x5f04(%r14)
     362:      	movq	(%rip), %rsi            # 0x369 <generic_retuprobe_filter_arg+0x369>
     369:      	movl	$0x4, %ecx
     36e:      	movl	$0xc, %eax
     373:      	movq	%rbx, %rdi
     376:      	movl	$0x4, %edx
     37b:      	callq	*%rax
     37d:      	movq	(%rip), %rsi            # 0x384 <generic_retuprobe_filter_arg+0x384>
     384:      	movl	$0x5, %ecx
     389:      	movl	$0xc, %eax
     38e:      	movq	%rbx, %rdi
     391:      	movl	$0x5, %edx
     396:      	callq	*%rax
     398:      	xorl	%eax, %eax
     39a:      	addq	$0x28, %rsp
     39e:      	popq	%rbx
     39f:      	popq	%r12
     3a1:      	popq	%r13
     3a3:      	popq	%r14
     3a5:      	popq	%r15
     3a7:      	popq	%rbp
     3a8:      	retq
     3a9:      	xorl	%r12d, %r12d
     3ac:      	cmpb	$0x0, 0x5ec1(%r14)
     3b4:      	jne	0x406 <generic_retuprobe_filter_arg+0x406>
     3b6:      	movl	$0x1, %r12d
     3bc:      	cmpb	$0x0, 0x5ec2(%r14)
     3c4:      	jne	0x406 <generic_retuprobe_filter_arg+0x406>
     3c6:      	movl	$0x2, %r12d
     3cc:      	cmpb	$0x0, 0x5ec3(%r14)
     3d4:      	jne	0x406 <generic_retuprobe_filter_arg+0x406>
     3d6:      	movl	$0x3, %r12d
     3dc:      	cmpb	$0x0, 0x5ec4(%r14)
     3e4:      	jne	0x406 <generic_retuprobe_filter_arg+0x406>
     3e6:      	movl	$0x4, %r12d
     3ec:      	cmpb	$0x0, 0x5ec5(%r14)
     3f4:      	jne	0x406 <generic_retuprobe_filter_arg+0x406>
     3f6:      	movl	$0x5, %r12d
     3fc:      	cmpb	$0x0, 0x5ec6(%r14)
     404:      	je	0x428 <generic_retuprobe_filter_arg+0x428>
     406:      	movl	%r12d, 0x5f00(%r14)
     40d:      	movq	(%rip), %rsi            # 0x414 <generic_retuprobe_filter_arg+0x414>
     414:      	movl	$0x3, %ecx
     419:      	movl	$0xc, %eax
     41e:      	movq	%rbx, %rdi
     421:      	movl	$0x3, %edx
     426:      	callq	*%rax
     428:      	movq	0x60(%r14), %rbx
     42c:      	movl	$0xe, %eax
     431:      	callq	*%rax
     433:      	movq	%rbx, 0x18(%rsp)
     438:      	movq	%rax, 0x20(%rsp)
     43d:      	movq	(%rip), %rdi            # 0x444 <generic_retuprobe_filter_arg+0x444>
     444:      	leaq	0x18(%rsp), %rsi
     449:      	movl	$0x1, %eax
     44e:      	callq	*%rax
     450:      	testq	%rax, %rax
     453:      	je	0x398 <generic_retuprobe_filter_arg+0x398>
     459:      	movq	(%rip), %rdi            # 0x460 <generic_retuprobe_filter_arg+0x460>
     460:      	leaq	0x18(%rsp), %rsi
     465:      	movl	$0x3, %eax
     46a:      	callq	*%rax
     46c:      	jmp	0x398 <generic_retuprobe_filter_arg+0x398>
     471:      	nopw	%cs:(%rax,%rax)

0000000000000480 <generic_retuprobe_actions>:
     480:      	pushq	%rbp
     481:      	pushq	%r14
     483:      	pushq	%rbx
     484:      	subq	$0x10, %rsp
     488:      	movq	%rdi, %rbx
     48b:      	movl	$0x0, 0x8(%rsp)
     493:      	movq	(%rip), %rdi            # 0x49a <generic_retuprobe_actions+0x1a>
     49a:      	leaq	0x8(%rsp), %rsi
     49f:      	movl	$0x1, %eax
     4a4:      	callq	*%rax
     4a6:      	testq	%rax, %rax
     4a9:      	je	0x5b2 <generic_retuprobe_actions+0x132>
     4af:      	movq	%rax, %rsi
     4b2:      	movl	0x5f04(%rax), %r14d
     4b9:      	cmpl	$0x2, %r14d
     4bd:      	jl	0x5b2 <generic_retuprobe_actions+0x132>
     4c3:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     4ca:      	movq	(%rip), %rdi            # 0x4d1 <generic_retuprobe_actions+0x51>
     4d1:      	movl	$0x1, %eax
     4d6:      	callq	*%rax
     4d8:      	testq	%rax, %rax
     4db:      	je	0x5b2 <generic_retuprobe_actions+0x132>
     4e1:      	movl	%r14d, %ecx
     4e4:      	andl	$0x7ff, %ecx            # imm = 0x7FF
     4ea:      	addl	(%rax,%rcx), %r14d
     4ee:      	movb	$0x1, 0x7(%rsp)
     4f3:      	movl	$0x0, 0xc(%rsp)
     4fb:      	movq	(%rip), %rdi            # 0x502 <generic_retuprobe_actions+0x82>
     502:      	leaq	0xc(%rsp), %rsi
     507:      	movq	%rax, %rcx
     50a:      	movl	$0x1, %eax
     50f:      	andl	$0x7ff, %r14d           # imm = 0x7FF
     516:      	addq	%rcx, %r14
     519:      	callq	*%rax
     51b:      	testq	%rax, %rax
     51e:      	je	0x52e <generic_retuprobe_actions+0xae>
     520:      	cmpb	$0x0, (%rax)
     523:      	sete	%al
     526:      	cmpl	$0x5, (%r14)
     52a:      	jae	0x536 <generic_retuprobe_actions+0xb6>
     52c:      	jmp	0x590 <generic_retuprobe_actions+0x110>
     52e:      	movb	$0x1, %al
     530:      	cmpl	$0x5, (%r14)
     534:      	jb	0x590 <generic_retuprobe_actions+0x110>
     536:      	movzbl	%al, %ebp
     539:      	leaq	0x7(%rsp), %rcx
     53e:      	movq	%rbx, %rdi
     541:      	xorl	%esi, %esi
     543:      	movq	%r14, %rdx
     546:      	movl	%ebp, %r8d
     549:      	callq	0x54e <generic_retuprobe_actions+0xce>
     54e:      	leal	0x4(,%rax,4), %ecx
     555:      	cmpl	(%r14), %ecx
     558:      	jae	0x590 <generic_retuprobe_actions+0x110>
     55a:      	leaq	0x7(%rsp), %rcx
     55f:      	movq	%rbx, %rdi
     562:      	movl	%eax, %esi
     564:      	movq	%r14, %rdx
     567:      	movl	%ebp, %r8d
     56a:      	callq	0x56f <generic_retuprobe_actions+0xef>
     56f:      	leal	0x4(,%rax,4), %ecx
     576:      	cmpl	(%r14), %ecx
     579:      	jae	0x590 <generic_retuprobe_actions+0x110>
     57b:      	leaq	0x7(%rsp), %rcx
     580:      	movq	%rbx, %rdi
     583:      	movl	%eax, %esi
     585:      	movq	%r14, %rdx
     588:      	movl	%ebp, %r8d
     58b:      	callq	0x590 <generic_retuprobe_actions+0x110>
     590:      	cmpb	$0x0, 0x7(%rsp)
     595:      	je	0x5b2 <generic_retuprobe_actions+0x132>
     597:      	movq	(%rip), %rsi            # 0x59e <generic_retuprobe_actions+0x11e>
     59e:      	movl	$0x5, %ecx
     5a3:      	movl	$0xc, %eax
     5a8:      	movq	%rbx, %rdi
     5ab:      	movl	$0x5, %edx
     5b0:      	callq	*%rax
     5b2:      	xorl	%eax, %eax
     5b4:      	addq	$0x10, %rsp
     5b8:      	popq	%rbx
     5b9:      	popq	%r14
     5bb:      	popq	%rbp
     5bc:      	retq
     5bd:      	nopl	(%rax)

00000000000005c0 <generic_retuprobe_output>:
     5c0:      	pushq	%r15
     5c2:      	pushq	%r14
     5c4:      	pushq	%rbx
     5c5:      	subq	$0x10, %rsp
     5c9:      	movq	%rdi, %r14
     5cc:      	movl	$0x0, 0x8(%rsp)
     5d4:      	movq	(%rip), %rdi            # 0x5db <generic_retuprobe_output+0x1b>
     5db:      	leaq	0x8(%rsp), %rsi
     5e0:      	movl	$0x1, %eax
     5e5:      	callq	*%rax
     5e7:      	testq	%rax, %rax
     5ea:      	je	0x6c3 <generic_retuprobe_output+0x103>
     5f0:      	movq	%rax, %rbx
     5f3:      	movl	$0x90, %eax
     5f8:      	addl	0x4(%rbx), %eax
     5fb:      	andl	$0x7fff, %eax           # imm = 0x7FFF
     600:      	cmpl	$0x2328, %eax           # imm = 0x2328
     605:      	movl	$0x2328, %r15d          # imm = 0x2328
     60b:      	cmovbl	%eax, %r15d
     60f:      	movl	$0x0, 0xc(%rsp)
     617:      	movq	(%rip), %rdi            # 0x61e <generic_retuprobe_output+0x5e>
     61e:      	leaq	0xc(%rsp), %rsi
     623:      	movl	$0x1, %eax
     628:      	callq	*%rax
     62a:      	testq	%rax, %rax
     62d:      	je	0x681 <generic_retuprobe_output+0xc1>
     62f:      	cmpb	$0x0, 0x28(%rax)
     633:      	je	0x681 <generic_retuprobe_output+0xc1>
     635:      	movq	(%rip), %rsi            # 0x63c <generic_retuprobe_output+0x7c>
     63c:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     641:      	movl	$0x19, %eax
     646:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     64b:      	movq	%r14, %rdi
     64e:      	movq	%rbx, %rcx
     651:      	movq	%r15, %r8
     654:      	callq	*%rax
     656:      	testq	%rax, %rax
     659:      	js	0x71e <generic_retuprobe_output+0x15e>
     65f:      	movl	$0x0, 0x4(%rsp)
     667:      	movq	(%rip), %rdi            # 0x66e <generic_retuprobe_output+0xae>
     66e:      	leaq	0x4(%rsp), %rsi
     673:      	movl	$0x1, %eax
     678:      	callq	*%rax
     67a:      	testq	%rax, %rax
     67d:      	jne	0x6be <generic_retuprobe_output+0xfe>
     67f:      	jmp	0x6c3 <generic_retuprobe_output+0x103>
     681:      	movq	(%rip), %rdi            # 0x688 <generic_retuprobe_output+0xc8>
     688:      	xorl	%ecx, %ecx
     68a:      	movl	$0x82, %eax
     68f:      	movq	%rbx, %rsi
     692:      	movq	%r15, %rdx
     695:      	xorl	%ecx, %ecx
     697:      	callq	*%rax
     699:      	testq	%rax, %rax
     69c:      	js	0x6cf <generic_retuprobe_output+0x10f>
     69e:      	movl	$0x0, 0x4(%rsp)
     6a6:      	movq	(%rip), %rdi            # 0x6ad <generic_retuprobe_output+0xed>
     6ad:      	leaq	0x4(%rsp), %rsi
     6b2:      	movl	$0x1, %eax
     6b7:      	callq	*%rax
     6b9:      	testq	%rax, %rax
     6bc:      	je	0x6c3 <generic_retuprobe_output+0x103>
     6be:      	lock
     6bf:      	incq	0x8(%rax)
     6c3:      	xorl	%eax, %eax
     6c5:      	addq	$0x10, %rsp
     6c9:      	popq	%rbx
     6ca:      	popq	%r14
     6cc:      	popq	%r15
     6ce:      	retq
     6cf:      	movq	%rax, %rbx
     6d2:      	movl	$0x0, 0x4(%rsp)
     6da:      	movq	(%rip), %rdi            # 0x6e1 <generic_retuprobe_output+0x121>
     6e1:      	leaq	0x4(%rsp), %rsi
     6e6:      	movl	$0x1, %eax
     6eb:      	callq	*%rax
     6ed:      	testq	%rax, %rax
     6f0:      	je	0x6c3 <generic_retuprobe_output+0x103>
     6f2:      	cmpq	$-0xc, %rbx
     6f6:      	jg	0x762 <generic_retuprobe_output+0x1a2>
     6f8:      	cmpq	$-0x1c, %rbx
     6fc:      	je	0x7a4 <generic_retuprobe_output+0x1e4>
     702:      	cmpq	$-0x16, %rbx
     706:      	je	0x753 <generic_retuprobe_output+0x193>
     708:      	cmpq	$-0x10, %rbx
     70c:      	jne	0x795 <generic_retuprobe_output+0x1d5>
     712:      	addq	$0x360, %rax            # imm = 0x360
     718:      	lock
     719:      	incq	(%rax)
     71c:      	jmp	0x6c3 <generic_retuprobe_output+0x103>
     71e:      	movq	%rax, %rbx
     721:      	movl	$0x0, 0x4(%rsp)
     729:      	movq	(%rip), %rdi            # 0x730 <generic_retuprobe_output+0x170>
     730:      	leaq	0x4(%rsp), %rsi
     735:      	movl	$0x1, %eax
     73a:      	callq	*%rax
     73c:      	testq	%rax, %rax
     73f:      	je	0x6c3 <generic_retuprobe_output+0x103>
     741:      	cmpq	$-0xc, %rbx
     745:      	jg	0x783 <generic_retuprobe_output+0x1c3>
     747:      	cmpq	$-0x1c, %rbx
     74b:      	je	0x7a4 <generic_retuprobe_output+0x1e4>
     74d:      	cmpq	$-0x16, %rbx
     751:      	jne	0x708 <generic_retuprobe_output+0x148>
     753:      	addq	$0x368, %rax            # imm = 0x368
     759:      	lock
     75a:      	incq	(%rax)
     75d:      	jmp	0x6c3 <generic_retuprobe_output+0x103>
     762:      	cmpq	$-0xb, %rbx
     766:      	je	0x7b3 <generic_retuprobe_output+0x1f3>
     768:      	cmpq	$-0x7, %rbx
     76c:      	je	0x7c2 <generic_retuprobe_output+0x202>
     76e:      	cmpq	$-0x2, %rbx
     772:      	jne	0x795 <generic_retuprobe_output+0x1d5>
     774:      	addq	$0x350, %rax            # imm = 0x350
     77a:      	lock
     77b:      	incq	(%rax)
     77e:      	jmp	0x6c3 <generic_retuprobe_output+0x103>
     783:      	cmpq	$-0xb, %rbx
     787:      	je	0x7b3 <generic_retuprobe_output+0x1f3>
     789:      	cmpq	$-0x7, %rbx
     78d:      	je	0x7c2 <generic_retuprobe_output+0x202>
     78f:      	cmpq	$-0x2, %rbx
     793:      	je	0x774 <generic_retuprobe_output+0x1b4>
     795:      	addq	$0x348, %rax            # imm = 0x348
     79b:      	lock
     79c:      	incq	(%rax)
     79f:      	jmp	0x6c3 <generic_retuprobe_output+0x103>
     7a4:      	addq	$0x370, %rax            # imm = 0x370
     7aa:      	lock
     7ab:      	incq	(%rax)
     7ae:      	jmp	0x6c3 <generic_retuprobe_output+0x103>
     7b3:      	addq	$0x378, %rax            # imm = 0x378
     7b9:      	lock
     7ba:      	incq	(%rax)
     7bd:      	jmp	0x6c3 <generic_retuprobe_output+0x103>
     7c2:      	addq	$0x358, %rax            # imm = 0x358
     7c8:      	lock
     7c9:      	incq	(%rax)
     7cc:      	jmp	0x6c3 <generic_retuprobe_output+0x103>

Disassembly of section uprobe/generic_retuprobe:

0000000000000000 <generic_retuprobe_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xf8, %rsp
      11:      	movq	%rdi, %r13
      14:      	movq	0x50(%rdi), %r14
      18:      	movl	$0x0, 0xf0(%rsp)
      23:      	movq	(%rip), %rdi            # 0x2a <generic_retuprobe_event+0x2a>
      2a:      	leaq	0xf0(%rsp), %rsi
      32:      	movl	$0x1, %eax
      37:      	callq	*%rax
      39:      	xorl	%ebp, %ebp
      3b:      	testq	%rax, %rax
      3e:      	je	0x31e6 <generic_retuprobe_event+0x31e6>
      44:      	movq	%rax, %r15
      47:      	movq	%rax, %rbx
      4a:      	leaq	0x5ef8(%rax), %rsi
      51:      	movl	$0x0, 0x5ef8(%r15)
      5c:      	movq	(%rip), %rdi            # 0x63 <generic_retuprobe_event+0x63>
      63:      	movl	$0x1, %eax
      68:      	callq	*%rax
      6a:      	testq	%rax, %rax
      6d:      	je	0x31e6 <generic_retuprobe_event+0x31e6>
      73:      	movq	%rax, %r12
      76:      	movl	(%rax), %eax
      78:      	movq	%rax, 0x60(%rbx)
      7c:      	movl	$0xe, %eax
      81:      	callq	*%rax
      83:      	cmpq	$-0x16, %rax
      87:      	jne	0xa8 <generic_retuprobe_event+0xa8>
      89:      	leaq	0x20(%r13), %rdx
      8d:      	leaq	0x38(%rsp), %rdi
      92:      	movl	$0x8, %ecx
      97:      	movl	$0x4, %eax
      9c:      	movl	$0x8, %esi
      a1:      	callq	*%rax
      a3:      	movq	0x38(%rsp), %rax
      a8:      	movq	%rax, 0x68(%rbx)
      ac:      	movl	$0xe, %eax
      b1:      	callq	*%rax
      b3:      	movl	%eax, 0x7c(%rbx)
      b6:      	movq	0x60(%rbx), %rax
      ba:      	movq	0x68(%rbx), %rcx
      be:      	movq	%rax, 0x38(%rsp)
      c3:      	movq	%rcx, 0x40(%rsp)
      c8:      	movq	(%rip), %rdi            # 0xcf <generic_retuprobe_event+0xcf>
      cf:      	leaq	0x38(%rsp), %rsi
      d4:      	movl	$0x1, %eax
      d9:      	callq	*%rax
      db:      	testq	%rax, %rax
      de:      	je	0x31e6 <generic_retuprobe_event+0x31e6>
      e4:      	movq	%r14, 0x8(%rsp)
      e9:      	movq	(%rax), %r14
      ec:      	movq	0x8(%rax), %rbp
      f0:      	movq	0x10(%rax), %rax
      f4:      	movq	%rax, 0xb8(%rsp)
      fc:      	movq	(%rip), %rdi            # 0x103 <generic_retuprobe_event+0x103>
     103:      	leaq	0x38(%rsp), %rsi
     108:      	movl	$0x3, %eax
     10d:      	callq	*%rax
     10f:      	movq	%r14, 0x90(%rbx)
     116:      	movl	0x58(%r12), %eax
     11b:      	movl	0x5c(%r12), %r14d
     120:      	testl	%r14d, %r14d
     123:      	je	0x193 <generic_retuprobe_event+0x193>
     125:      	movl	%eax, 0x28(%rsp)
     129:      	movl	$0x0, 0x5ea0(%rbx)
     133:      	movl	$0x0, 0xf4(%rsp)
     13e:      	movq	(%rip), %rdi            # 0x145 <generic_retuprobe_event+0x145>
     145:      	leaq	0xf4(%rsp), %rsi
     14d:      	movl	$0x1, %eax
     152:      	callq	*%rax
     154:      	testq	%rax, %rax
     157:      	je	0x296 <generic_retuprobe_event+0x296>
     15d:      	movq	%rax, %rcx
     160:      	movl	0x5ea0(%rax), %eax
     166:      	movl	%eax, 0x98(%rcx)
     16c:      	movq	$0xc, 0x5e78(%rcx)
     177:      	testl	%eax, %eax
     179:      	je	0x2a7 <generic_retuprobe_event+0x2a7>
     17f:      	movq	0x8(%rsp), %r8
     184:      	movl	$0x4, %r14d
     18a:      	movl	0x28(%rsp), %eax
     18e:      	jmp	0x2eae <generic_retuprobe_event+0x2eae>
     193:      	movl	$0x8, %r14d
     199:      	movq	0x8(%rsp), %r8
     19e:      	addq	$0x90, %r15
     1a5:      	cmpl	$0x3, %eax
     1a8:      	jne	0x2ec9 <generic_retuprobe_event+0x2ec9>
     1ae:      	movq	%r14, %rax
     1b1:      	movl	$0x0, (%r15,%r14)
     1b9:      	leaq	0x4(%r14), %rax
     1bd:      	cmpq	$0x0, 0xb8(%rsp)
     1c6:      	movq	%r13, 0xc8(%rsp)
     1ce:      	movq	%r12, 0xa8(%rsp)
     1d6:      	je	0x318 <generic_retuprobe_event+0x318>
     1dc:      	movq	%rax, 0x28(%rsp)
     1e1:      	leaq	0x38(%rsp), %rdi
     1e6:      	movl	$0x4, %r12d
     1ec:      	movl	$0x10, %ecx
     1f1:      	movl	$0x4, %eax
     1f6:      	movl	$0x10, %esi
     1fb:      	movq	%rbp, %rdx
     1fe:      	callq	*%rax
     200:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     205:      	testl	%eax, %eax
     207:      	js	0xbbd <generic_retuprobe_event+0xbbd>
     20d:      	movq	%rbp, 0x88(%rsp)
     215:      	movq	0x40(%rsp), %r13
     21a:      	movq	0x8(%rsp), %rax
     21f:      	cmpq	%rax, %r13
     222:      	movq	%rax, %rbp
     225:      	cmovbq	%r13, %rbp
     229:      	testq	%rax, %rax
     22c:      	cmovneq	%rbp, %r13
     230:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
     235:      	cmpq	$0xffe, %r13            # imm = 0xFFE
     23c:      	ja	0xbbd <generic_retuprobe_event+0xbbd>
     242:      	addq	$0xc, %r14
     246:      	movq	%r14, 0x20(%rsp)
     24b:      	leaq	(%r15,%r14), %rdi
     24f:      	movq	0x38(%rsp), %rcx
     254:      	movl	$0x4, %eax
     259:      	movq	0x38(%rsp), %rdx
     25e:      	movl	%r13d, %esi
     261:      	callq	*%rax
     263:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     268:      	testl	%eax, %eax
     26a:      	js	0xbbd <generic_retuprobe_event+0xbbd>
     270:      	movq	0x8(%rsp), %rax
     275:      	testq	%rax, %rax
     278:      	je	0xaf2 <generic_retuprobe_event+0xaf2>
     27e:      	subq	%rbp, %rax
     281:      	movq	%rax, 0x8(%rsp)
     286:      	movq	0x28(%rsp), %rax
     28b:      	jne	0xafe <generic_retuprobe_event+0xafe>
     291:      	jmp	0x31a <generic_retuprobe_event+0x31a>
     296:      	xorl	%r14d, %r14d
     299:      	movq	0x8(%rsp), %r8
     29e:      	movl	0x28(%rsp), %eax
     2a2:      	jmp	0x2eae <generic_retuprobe_event+0x2eae>
     2a7:      	leaq	0x9c(%rcx), %rdx
     2ae:      	movq	0x8(%rsp), %rax
     2b3:      	movq	%rax, 0x38(%rsp)
     2b8:      	movq	$0x0, 0x78(%rsp)
     2c1:      	cmpl	$0x17, %r14d
     2c5:      	movq	%rcx, (%rsp)
     2c9:      	movq	%r15, 0x20(%rsp)
     2ce:      	movq	%r13, 0xc8(%rsp)
     2d6:      	jle	0x32f <generic_retuprobe_event+0x32f>
     2d8:      	cmpl	$0x18, %r14d
     2dc:      	je	0x34a <generic_retuprobe_event+0x34a>
     2de:      	cmpl	$0x25, %r14d
     2e2:      	je	0x38d <generic_retuprobe_event+0x38d>
     2e8:      	cmpl	$0x2a, %r14d
     2ec:      	jne	0xa2f <generic_retuprobe_event+0xa2f>
     2f2:      	movq	$0x0, 0x90(%rsp)
     2fe:      	movq	0x8(%rsp), %rax
     303:      	movq	%rax, 0x98(%rsp)
     30b:      	leaq	0x90(%rsp), %rax
     313:      	jmp	0x3bf <generic_retuprobe_event+0x3bf>
     318:      	xorl	%ebp, %ebp
     31a:      	movl	%ebp, (%r15,%rax)
     31e:      	movl	%ebp, 0x4(%r15,%rax)
     323:      	addq	$0x8, %rbp
     327:      	movq	%rbp, %r12
     32a:      	jmp	0xbc6 <generic_retuprobe_event+0xbc6>
     32f:      	cmpl	$0xf, %r14d
     333:      	je	0x966 <generic_retuprobe_event+0x966>
     339:      	cmpl	$0x10, %r14d
     33d:      	jne	0xa2f <generic_retuprobe_event+0xa2f>
     343:      	leaq	0x18(%rsp), %r14
     348:      	jmp	0x377 <generic_retuprobe_event+0x377>
     34a:      	leaq	0x18(%rsp), %r14
     34f:      	movl	$0x8, %ecx
     354:      	movl	$0x4, %eax
     359:      	movq	0x8(%rsp), %rdx
     35e:      	movq	0x38(%rsp), %rdx
     363:      	movq	%r14, %rdi
     366:      	movl	$0x8, %esi
     36b:      	callq	*%rax
     36d:      	movq	0x18(%rsp), %rax
     372:      	movq	%rax, 0x38(%rsp)
     377:      	leaq	0x38(%rsp), %rdx
     37c:      	movl	$0x8, %ecx
     381:      	movl	$0x4, %eax
     386:      	leaq	0x18(%rsp), %rdi
     38b:      	jmp	0x3af <generic_retuprobe_event+0x3af>
     38d:      	movq	0x8(%rsp), %rax
     392:      	leaq	0x40(%rax), %rcx
     396:      	movq	%rcx, 0x38(%rsp)
     39b:      	leaq	0x18(%rsp), %rdi
     3a0:      	movl	$0x8, %edx
     3a5:      	movl	$0x4, %eax
     3aa:      	movq	0x38(%rsp), %rdx
     3af:      	movl	$0x8, %esi
     3b4:      	callq	*%rax
     3b6:      	movq	0x18(%rsp), %rax
     3bb:      	addq	$0x40, %rax
     3bf:      	movq	%rax, 0xa0(%rsp)
     3c7:      	movl	$0x0, 0xc4(%rsp)
     3d2:      	movq	(%rip), %rdi            # 0x3d9 <generic_retuprobe_event+0x3d9>
     3d9:      	leaq	0xc4(%rsp), %rsi
     3e1:      	movl	$0x1, %eax
     3e6:      	callq	*%rax
     3e8:      	testq	%rax, %rax
     3eb:      	je	0x4ac <generic_retuprobe_event+0x4ac>
     3f1:      	movq	%rax, %r13
     3f4:      	movq	%rbp, 0x88(%rsp)
     3fc:      	movq	%r12, 0xa8(%rsp)
     404:      	addq	$0x1000, %rax           # imm = 0x1000
     40a:      	movq	%rax, 0x10(%rsp)
     40f:      	movl	$0x23, %eax
     414:      	callq	*%rax
     416:      	leaq	0xd50(%rax), %rdx
     41d:      	leaq	0xd0(%rsp), %rdi
     425:      	movl	$0x8, %ecx
     42a:      	movl	$0x4, %eax
     42f:      	movl	$0x8, %esi
     434:      	callq	*%rax
     436:      	movq	0xd0(%rsp), %r12
     43e:      	movq	0xa0(%rsp), %rax
     446:      	leaq	0x8(%rax), %rdx
     44a:      	leaq	0xd8(%rsp), %rdi
     452:      	movl	$0x8, %ecx
     457:      	movl	$0x4, %eax
     45c:      	leaq	0x18(%r12), %rcx
     461:      	movq	%rcx, 0xe8(%rsp)
     469:      	movl	$0x8, %esi
     46e:      	movq	%rdx, 0x30(%rsp)
     473:      	callq	*%rax
     475:      	movq	0xd8(%rsp), %rbp
     47d:      	leaq	0x10(%rbp), %rdx
     481:      	leaq	0x38(%rsp), %rdi
     486:      	movl	$0x8, %ecx
     48b:      	movl	$0x4, %eax
     490:      	movl	$0x8, %esi
     495:      	callq	*%rax
     497:      	cmpq	$0x0, 0x38(%rsp)
     49d:      	movl	$0x1000, %r14d          # imm = 0x1000
     4a3:      	je	0x4b9 <generic_retuprobe_event+0x4b9>
     4a5:      	movq	0x10(%rsp), %rcx
     4aa:      	jmp	0x50a <generic_retuprobe_event+0x50a>
     4ac:      	xorl	%r13d, %r13d
     4af:      	movq	0x8(%rsp), %r8
     4b4:      	jmp	0xd10 <generic_retuprobe_event+0xd10>
     4b9:      	leaq	0x18(%rbp), %rdx
     4bd:      	leaq	0x38(%rsp), %rdi
     4c2:      	movl	$0x8, %ecx
     4c7:      	movl	$0x4, %eax
     4cc:      	movl	$0x8, %esi
     4d1:      	callq	*%rax
     4d3:      	cmpq	%rbp, 0x38(%rsp)
     4d8:      	movq	0x10(%rsp), %rcx
     4dd:      	je	0x50a <generic_retuprobe_event+0x50a>
     4df:      	movq	%r13, %rcx
     4e2:      	addq	$0xff6, %rcx            # imm = 0xFF6
     4e9:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
     4f3:      	movq	%rax, 0xff6(%r13)
     4fa:      	movw	$0x2964, 0xffe(%r13)    # imm = 0x2964
     504:      	movl	$0xff6, %r14d           # imm = 0xFF6
     50a:      	movq	$0x0, 0x40(%rsp)
     513:      	movq	$0x0, 0x38(%rsp)
     51c:      	movq	%r13, 0x48(%rsp)
     521:      	movq	$0x0, 0x50(%rsp)
     52a:      	movq	$0x0, 0x58(%rsp)
     533:      	movq	$0x0, 0x60(%rsp)
     53c:      	movq	%rcx, 0x10(%rsp)
     541:      	movq	%rcx, 0x68(%rsp)
     546:      	movl	%r14d, 0x70(%rsp)
     54b:      	movb	$0x0, 0x74(%rsp)
     550:      	addq	$0x20, %r12
     554:      	leaq	0x38(%rsp), %rdi
     559:      	movl	$0x8, %ecx
     55e:      	movl	$0x4, %eax
     563:      	leaq	0x40(%rsp), %r13
     568:      	leaq	0x50(%rsp), %rbp
     56d:      	leaq	0x58(%rsp), %r14
     572:      	movl	$0x8, %esi
     577:      	movq	%r12, %rdx
     57a:      	callq	*%rax
     57c:      	movl	$0x8, %ecx
     581:      	movl	$0x4, %eax
     586:      	movq	0xe8(%rsp), %rdx
     58e:      	movq	%r13, %rdi
     591:      	movl	$0x8, %esi
     596:      	callq	*%rax
     598:      	movl	$0x8, %ecx
     59d:      	movl	$0x4, %eax
     5a2:      	movq	0x30(%rsp), %rdx
     5a7:      	movq	%rbp, %rdi
     5aa:      	movl	$0x8, %esi
     5af:      	callq	*%rax
     5b1:      	movl	$0x8, %ecx
     5b6:      	movl	$0x4, %eax
     5bb:      	movq	0xa0(%rsp), %rdx
     5c3:      	movq	%r14, %rdi
     5c6:      	movl	$0x8, %esi
     5cb:      	callq	*%rax
     5cd:      	movq	0x58(%rsp), %rax
     5d2:      	addq	$-0x20, %rax
     5d6:      	movq	%rax, 0x60(%rsp)
     5db:      	movq	(%rip), %rax            # 0x5e2 <generic_retuprobe_event+0x5e2>
     5e2:      	cmpb	$0x0, (%rax)
     5e5:      	je	0x7af <generic_retuprobe_event+0x7af>
     5eb:      	movl	$0x800, %r13d           # imm = 0x800
     5f1:      	movl	$0x8, %ebp
     5f6:      	movq	0x50(%rsp), %r14
     5fb:      	movq	0x58(%rsp), %rdx
     600:      	movq	0x60(%rsp), %r12
     605:      	cmpq	0x38(%rsp), %r14
     60a:      	jne	0x617 <generic_retuprobe_event+0x617>
     60c:      	cmpq	0x40(%rsp), %rdx
     611:      	je	0xae8 <generic_retuprobe_event+0xae8>
     617:      	movl	$0x4, %eax
     61c:      	leaq	0xb0(%rsp), %rdi
     624:      	movl	$0x8, %esi
     629:      	callq	*%rax
     62b:      	cmpq	0xb0(%rsp), %r14
     633:      	movl	$0x8, %r15d
     639:      	je	0x746 <generic_retuprobe_event+0x746>
     63f:      	leaq	0x18(%r14), %rbp
     643:      	movl	$0x4, %eax
     648:      	leaq	0x18(%rsp), %rdi
     64d:      	movl	$0x8, %esi
     652:      	movq	%rbp, %rdx
     655:      	callq	*%rax
     657:      	cmpq	%r14, 0x18(%rsp)
     65c:      	je	0x746 <generic_retuprobe_event+0x746>
     662:      	movl	$0x4, %eax
     667:      	leaq	0xe0(%rsp), %rdi
     66f:      	movl	$0x8, %esi
     674:      	movq	%rbp, %rdx
     677:      	callq	*%rax
     679:      	addq	$0x20, %r14
     67d:      	movl	$0x4, %eax
     682:      	leaq	0x78(%rsp), %rdi
     687:      	movl	$0x10, %ecx
     68c:      	movl	$0x10, %esi
     691:      	movq	%r14, %rdx
     694:      	callq	*%rax
     696:      	movq	0x48(%rsp), %r14
     69b:      	movq	0x68(%rsp), %rax
     6a0:      	movl	0x7c(%rsp), %ebp
     6a4:      	subq	%r14, %rax
     6a7:      	movl	0x70(%rsp), %r12d
     6ac:      	movl	%ebp, %edx
     6ae:      	subl	%r12d, %edx
     6b1:      	movl	$0x0, %ecx
     6b6:      	cmovbl	%ecx, %edx
     6b9:      	addq	0x80(%rsp), %rdx
     6c1:      	xorl	%esi, %esi
     6c3:      	cmpl	%ebp, %r12d
     6c6:      	seta	%sil
     6ca:      	movl	%ebp, %ecx
     6cc:      	cmovbl	%r12d, %ecx
     6d0:      	addl	%ecx, %esi
     6d2:      	movl	%r12d, %edi
     6d5:      	subl	%esi, %edi
     6d7:      	movl	%edi, 0x70(%rsp)
     6db:      	subq	%rsi, %rax
     6de:      	movq	0x20(%rsp), %r15
     6e3:      	jb	0xbf6 <generic_retuprobe_event+0xbf6>
     6e9:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     6ef:      	ja	0xbf6 <generic_retuprobe_event+0xbf6>
     6f5:      	cmpl	%ebp, %r12d
     6f8:      	jbe	0x6ff <generic_retuprobe_event+0x6ff>
     6fa:      	movb	$0x2f, (%r14,%rax)
     6ff:      	xorl	%edi, %edi
     701:      	cmpl	%ebp, %r12d
     704:      	seta	%dil
     708:      	movzbl	%cl, %esi
     70b:      	addq	%rax, %r14
     70e:      	addq	%r14, %rdi
     711:      	movl	$0x4, %eax
     716:      	callq	*%rax
     718:      	movq	%r14, 0x68(%rsp)
     71d:      	cmpl	%ebp, %r12d
     720:      	jbe	0xbf6 <generic_retuprobe_event+0xbf6>
     726:      	movq	0xe0(%rsp), %rax
     72e:      	movq	%rax, 0x50(%rsp)
     733:      	movl	$0x8, %ebp
     738:      	decl	%r13d
     73b:      	jne	0x5f6 <generic_retuprobe_event+0x5f6>
     741:      	jmp	0xbf6 <generic_retuprobe_event+0xbf6>
     746:      	leaq	0x10(%r12), %rdx
     74b:      	movl	$0x4, %eax
     750:      	leaq	0x18(%rsp), %rdi
     755:      	movl	$0x8, %esi
     75a:      	callq	*%rax
     75c:      	movq	0x60(%rsp), %rax
     761:      	cmpq	0x18(%rsp), %rax
     766:      	movl	$0x8, %ebp
     76b:      	je	0xbec <generic_retuprobe_event+0xbec>
     771:      	addq	$0x18, %r12
     775:      	movl	$0x4, %eax
     77a:      	leaq	0x50(%rsp), %rdi
     77f:      	movl	$0x8, %esi
     784:      	movq	%r12, %rdx
     787:      	callq	*%rax
     789:      	movq	0x18(%rsp), %rax
     78e:      	movq	%rax, 0x60(%rsp)
     793:      	addq	$0x20, %rax
     797:      	movq	%rax, 0x58(%rsp)
     79c:      	movq	0x20(%rsp), %r15
     7a1:      	decl	%r13d
     7a4:      	jne	0x5f6 <generic_retuprobe_event+0x5f6>
     7aa:      	jmp	0xbf6 <generic_retuprobe_event+0xbf6>
     7af:      	movl	$0x800, %r13d           # imm = 0x800
     7b5:      	movl	$0x8, %ebp
     7ba:      	jmp	0x7c5 <generic_retuprobe_event+0x7c5>
     7bc:      	decl	%r13d
     7bf:      	je	0xbf6 <generic_retuprobe_event+0xbf6>
     7c5:      	movq	0x50(%rsp), %r14
     7ca:      	movq	0x58(%rsp), %rdx
     7cf:      	movq	0x60(%rsp), %r12
     7d4:      	cmpq	0x38(%rsp), %r14
     7d9:      	jne	0x7e6 <generic_retuprobe_event+0x7e6>
     7db:      	cmpq	0x40(%rsp), %rdx
     7e0:      	je	0xae8 <generic_retuprobe_event+0xae8>
     7e6:      	movl	$0x4, %eax
     7eb:      	leaq	0xb0(%rsp), %rdi
     7f3:      	movl	$0x8, %esi
     7f8:      	callq	*%rax
     7fa:      	cmpq	0xb0(%rsp), %r14
     802:      	movl	$0x8, %ecx
     807:      	je	0x90b <generic_retuprobe_event+0x90b>
     80d:      	leaq	0x18(%r14), %rbp
     811:      	movl	$0x4, %eax
     816:      	leaq	0x18(%rsp), %rdi
     81b:      	movl	$0x8, %esi
     820:      	movq	%rbp, %rdx
     823:      	callq	*%rax
     825:      	movl	$0x8, %ecx
     82a:      	cmpq	%r14, 0x18(%rsp)
     82f:      	je	0x90b <generic_retuprobe_event+0x90b>
     835:      	movl	$0x4, %eax
     83a:      	leaq	0xe0(%rsp), %rdi
     842:      	movl	$0x8, %esi
     847:      	movq	%rbp, %rdx
     84a:      	callq	*%rax
     84c:      	addq	$0x20, %r14
     850:      	movl	$0x4, %eax
     855:      	leaq	0x78(%rsp), %rdi
     85a:      	movl	$0x10, %ecx
     85f:      	movl	$0x10, %esi
     864:      	movq	%r14, %rdx
     867:      	callq	*%rax
     869:      	movq	0x48(%rsp), %r14
     86e:      	movq	0x68(%rsp), %rax
     873:      	movl	0x7c(%rsp), %ebp
     877:      	subq	%r14, %rax
     87a:      	movl	0x70(%rsp), %r12d
     87f:      	movl	%ebp, %edx
     881:      	subl	%r12d, %edx
     884:      	movl	$0x0, %ecx
     889:      	cmovbl	%ecx, %edx
     88c:      	addq	0x80(%rsp), %rdx
     894:      	xorl	%esi, %esi
     896:      	cmpl	%ebp, %r12d
     899:      	seta	%sil
     89d:      	movl	%ebp, %ecx
     89f:      	cmovbl	%r12d, %ecx
     8a3:      	addl	%ecx, %esi
     8a5:      	movl	%r12d, %edi
     8a8:      	subl	%esi, %edi
     8aa:      	movl	%edi, 0x70(%rsp)
     8ae:      	subq	%rsi, %rax
     8b1:      	jb	0xbf6 <generic_retuprobe_event+0xbf6>
     8b7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     8bd:      	ja	0xbf6 <generic_retuprobe_event+0xbf6>
     8c3:      	cmpl	%ebp, %r12d
     8c6:      	jbe	0x8cd <generic_retuprobe_event+0x8cd>
     8c8:      	movb	$0x2f, (%r14,%rax)
     8cd:      	xorl	%edi, %edi
     8cf:      	cmpl	%ebp, %r12d
     8d2:      	seta	%dil
     8d6:      	movzbl	%cl, %esi
     8d9:      	addq	%rax, %r14
     8dc:      	addq	%r14, %rdi
     8df:      	movl	$0x4, %eax
     8e4:      	callq	*%rax
     8e6:      	movq	%r14, 0x68(%rsp)
     8eb:      	cmpl	%ebp, %r12d
     8ee:      	jbe	0xbf6 <generic_retuprobe_event+0xbf6>
     8f4:      	movq	0xe0(%rsp), %rax
     8fc:      	movq	%rax, 0x50(%rsp)
     901:      	movl	$0x8, %ebp
     906:      	jmp	0x7bc <generic_retuprobe_event+0x7bc>
     90b:      	leaq	0x10(%r12), %rdx
     910:      	movl	$0x4, %eax
     915:      	leaq	0x18(%rsp), %rdi
     91a:      	movl	$0x8, %esi
     91f:      	callq	*%rax
     921:      	movq	0x60(%rsp), %rax
     926:      	cmpq	0x18(%rsp), %rax
     92b:      	movl	$0x8, %ebp
     930:      	je	0xae8 <generic_retuprobe_event+0xae8>
     936:      	addq	$0x18, %r12
     93a:      	movl	$0x4, %eax
     93f:      	leaq	0x50(%rsp), %rdi
     944:      	movl	$0x8, %esi
     949:      	movq	%r12, %rdx
     94c:      	callq	*%rax
     94e:      	movq	0x18(%rsp), %rax
     953:      	movq	%rax, 0x60(%rsp)
     958:      	addq	$0x20, %rax
     95c:      	movq	%rax, 0x58(%rsp)
     961:      	jmp	0x7bc <generic_retuprobe_event+0x7bc>
     966:      	movq	%rdx, 0x30(%rsp)
     96b:      	leaq	0x78(%rsp), %rdi
     970:      	leaq	0x38(%rsp), %rdx
     975:      	movl	$0x8, %ecx
     97a:      	movl	$0x4, %eax
     97f:      	movl	$0x8, %esi
     984:      	callq	*%rax
     986:      	movq	0x78(%rsp), %rax
     98b:      	movq	%rax, 0xa0(%rsp)
     993:      	testq	%rax, %rax
     996:      	jne	0x3c7 <generic_retuprobe_event+0x3c7>
     99c:      	movl	$0x0, 0x90(%rsp)
     9a7:      	movq	(%rip), %rdi            # 0x9ae <generic_retuprobe_event+0x9ae>
     9ae:      	leaq	0x90(%rsp), %rsi
     9b6:      	movl	$0x1, %eax
     9bb:      	callq	*%rax
     9bd:      	xorl	%r13d, %r13d
     9c0:      	testq	%rax, %rax
     9c3:      	je	0xe9a <generic_retuprobe_event+0xe9a>
     9c9:      	cmpl	$0x19, %r14d
     9cd:      	movq	(%rsp), %rcx
     9d1:      	jg	0xf60 <generic_retuprobe_event+0xf60>
     9d7:      	cmpl	$0x12, %r14d
     9db:      	movq	0x30(%rsp), %rdi
     9e0:      	jle	0x10c0 <generic_retuprobe_event+0x10c0>
     9e6:      	cmpl	$0x14, %r14d
     9ea:      	jle	0x1403 <generic_retuprobe_event+0x1403>
     9f0:      	cmpl	$0x15, %r14d
     9f4:      	je	0x1e47 <generic_retuprobe_event+0x1e47>
     9fa:      	cmpl	$0x16, %r14d
     9fe:      	je	0x1daf <generic_retuprobe_event+0x1daf>
     a04:      	cmpl	$0x17, %r14d
     a08:      	movq	0x8(%rsp), %r8
     a0d:      	jne	0x2e6b <generic_retuprobe_event+0x2e6b>
     a13:      	movl	$0x0, 0xa0(%rcx)
     a1d:      	movl	%r8d, 0x9c(%rcx)
     a24:      	movl	$0x8, %r13d
     a2a:      	jmp	0x2e6b <generic_retuprobe_event+0x2e6b>
     a2f:      	movq	%rdx, 0x30(%rsp)
     a34:      	cmpl	$0x2c, %r14d
     a38:      	ja	0x99c <generic_retuprobe_event+0x99c>
     a3e:      	movl	%r14d, %eax
     a41:      	movabsq	$0x11c1f2027cf2, %rcx   # imm = 0x11C1F2027CF2
     a4b:      	btq	%rax, %rcx
     a4f:      	jae	0x99c <generic_retuprobe_event+0x99c>
     a55:      	movq	0x8(%rsp), %rax
     a5a:      	movq	%rax, 0x18(%rsp)
     a5f:      	movl	$0x0, 0xe0(%rsp)
     a6a:      	movq	(%rip), %rdi            # 0xa71 <generic_retuprobe_event+0xa71>
     a71:      	leaq	0xe0(%rsp), %rsi
     a79:      	movl	$0x1, %eax
     a7e:      	callq	*%rax
     a80:      	testq	%rax, %rax
     a83:      	movq	%rbp, 0x88(%rsp)
     a8b:      	je	0xbe1 <generic_retuprobe_event+0xbe1>
     a91:      	xorl	%r13d, %r13d
     a94:      	cmpl	$0x10, %r14d
     a98:      	jle	0xd19 <generic_retuprobe_event+0xd19>
     a9e:      	cmpl	$0x1e, %r14d
     aa2:      	movq	0x30(%rsp), %rdi
     aa7:      	movq	%r12, %rbp
     aaa:      	jle	0xea4 <generic_retuprobe_event+0xea4>
     ab0:      	cmpl	$0x26, %r14d
     ab4:      	jg	0xf9e <generic_retuprobe_event+0xf9e>
     aba:      	leal	-0x1f(%r14), %eax
     abe:      	cmpl	$0x2, %eax
     ac1:      	jae	0x14eb <generic_retuprobe_event+0x14eb>
     ac7:      	leaq	0x18(%rsp), %rdx
     acc:      	movl	$0x4, %r13d
     ad2:      	movl	$0x1, %ecx
     ad7:      	movl	$0x4, %eax
     adc:      	movl	$0x1, %esi
     ae1:      	callq	*%rax
     ae3:      	jmp	0x2e57 <generic_retuprobe_event+0x2e57>
     ae8:      	movb	$0x1, 0x74(%rsp)
     aed:      	jmp	0xbf6 <generic_retuprobe_event+0xbf6>
     af2:      	xorl	%eax, %eax
     af4:      	movq	%rax, 0x8(%rsp)
     af9:      	movq	0x28(%rsp), %rax
     afe:      	cmpq	$0x1, 0xb8(%rsp)
     b07:      	jne	0xb11 <generic_retuprobe_event+0xb11>
     b09:      	movq	%r13, %rbp
     b0c:      	jmp	0x31a <generic_retuprobe_event+0x31a>
     b11:      	movq	0x88(%rsp), %rax
     b19:      	leaq	0x10(%rax), %rdx
     b1d:      	leaq	0x38(%rsp), %rdi
     b22:      	movl	$0x4, %r12d
     b28:      	movl	$0x10, %ecx
     b2d:      	movl	$0x4, %eax
     b32:      	movl	$0x10, %esi
     b37:      	callq	*%rax
     b39:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     b3e:      	testl	%eax, %eax
     b40:      	js	0xbbd <generic_retuprobe_event+0xbbd>
     b42:      	movq	0x40(%rsp), %r14
     b47:      	movq	0x8(%rsp), %rax
     b4c:      	cmpq	%rax, %r14
     b4f:      	movq	%rax, %rbp
     b52:      	cmovbq	%r14, %rbp
     b56:      	testq	%rax, %rax
     b59:      	cmovneq	%rbp, %r14
     b5d:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
     b62:      	cmpq	$0xffe, %r14            # imm = 0xFFE
     b69:      	ja	0xbbd <generic_retuprobe_event+0xbbd>
     b6b:      	movq	0x20(%rsp), %rax
     b70:      	addq	%r13, %rax
     b73:      	movq	%rax, 0x20(%rsp)
     b78:      	leaq	(%r15,%rax), %rdi
     b7c:      	movq	0x38(%rsp), %rcx
     b81:      	movl	$0x4, %eax
     b86:      	movq	0x38(%rsp), %rdx
     b8b:      	movl	%r14d, %esi
     b8e:      	callq	*%rax
     b90:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     b95:      	testl	%eax, %eax
     b97:      	js	0xbbd <generic_retuprobe_event+0xbbd>
     b99:      	addq	%r14, %r13
     b9c:      	movq	0x8(%rsp), %rax
     ba1:      	testq	%rax, %rax
     ba4:      	je	0x19a5 <generic_retuprobe_event+0x19a5>
     baa:      	subq	%rbp, %rax
     bad:      	movq	%rax, 0x8(%rsp)
     bb2:      	jne	0x19ac <generic_retuprobe_event+0x19ac>
     bb8:      	jmp	0x1a7c <generic_retuprobe_event+0x1a7c>
     bbd:      	movq	0x28(%rsp), %rax
     bc2:      	movl	%ecx, (%r15,%rax)
     bc6:      	addq	%rax, %r12
     bc9:      	movq	%r12, %rbp
     bcc:      	movq	0xc8(%rsp), %r13
     bd4:      	movq	0xa8(%rsp), %r12
     bdc:      	jmp	0x2f4d <generic_retuprobe_event+0x2f4d>
     be1:      	movq	%r12, %rbp
     be4:      	xorl	%r13d, %r13d
     be7:      	jmp	0x2e57 <generic_retuprobe_event+0x2e57>
     bec:      	movb	$0x1, 0x74(%rsp)
     bf1:      	movq	0x20(%rsp), %r15
     bf6:      	movq	0x68(%rsp), %rax
     bfb:      	movq	0x10(%rsp), %rdx
     c00:      	xorl	%ebp, %ebp
     c02:      	cmpq	%rdx, %rax
     c05:      	je	0xc42 <generic_retuprobe_event+0xc42>
     c07:      	cmpb	$0x0, 0x74(%rsp)
     c0c:      	sete	%cl
     c0f:      	movl	0x70(%rsp), %edx
     c13:      	movl	$0x1000, %r13d          # imm = 0x1000
     c19:      	subl	%edx, %r13d
     c1c:      	testl	%edx, %edx
     c1e:      	cmovlel	%edx, %r13d
     c22:      	testq	%rax, %rax
     c25:      	movq	0xa8(%rsp), %r12
     c2d:      	movq	0x8(%rsp), %r8
     c32:      	je	0xd05 <generic_retuprobe_event+0xd05>
     c38:      	movb	%cl, %bpl
     c3b:      	addl	%ebp, %ebp
     c3d:      	movq	%rax, %rdx
     c40:      	jmp	0xc4d <generic_retuprobe_event+0xc4d>
     c42:      	xorl	%r13d, %r13d
     c45:      	movq	0xa8(%rsp), %r12
     c4d:      	movq	(%rsp), %r14
     c51:      	movq	%r14, %rdi
     c54:      	addq	$0xa0, %rdi
     c5b:      	andl	$0xfff, %r13d           # imm = 0xFFF
     c62:      	movl	$0x4, %eax
     c67:      	movl	%r13d, %esi
     c6a:      	callq	*%rax
     c6c:      	movl	%r13d, 0x9c(%r14)
     c73:      	leaq	0x38(%rsp), %rdi
     c78:      	movl	$0x8, %ecx
     c7d:      	movl	$0x4, %eax
     c82:      	movq	0x30(%rsp), %rdx
     c87:      	movl	$0x8, %esi
     c8c:      	callq	*%rax
     c8e:      	movq	0x38(%rsp), %rcx
     c93:      	addq	$0x30, %rcx
     c97:      	leaq	0x78(%rsp), %rdi
     c9c:      	movl	$0x8, %edx
     ca1:      	movl	$0x4, %eax
     ca6:      	movq	0x38(%rsp), %rdx
     cab:      	addq	$0x30, %rdx
     caf:      	movl	$0x8, %esi
     cb4:      	callq	*%rax
     cb6:      	movq	0x78(%rsp), %rcx
     cbb:      	leaq	0x18(%rsp), %rdi
     cc0:      	movl	$0x2, %edx
     cc5:      	movl	$0x4, %eax
     cca:      	movq	0x78(%rsp), %rdx
     ccf:      	movl	$0x2, %esi
     cd4:      	callq	*%rax
     cd6:      	movq	%r14, %rcx
     cd9:      	movl	%ebp, 0xa0(%r14,%r13)
     ce1:      	movzwl	0x18(%rsp), %eax
     ce6:      	movw	%ax, 0xa4(%r14,%r13)
     cef:      	addl	$0xa, %r13d
     cf3:      	movq	0x88(%rsp), %rbp
     cfb:      	movq	0x8(%rsp), %r8
     d00:      	jmp	0x2e6b <generic_retuprobe_event+0x2e6b>
     d05:      	xorl	%r13d, %r13d
     d08:      	movq	0x88(%rsp), %rbp
     d10:      	movl	0x28(%rsp), %eax
     d14:      	jmp	0x2e74 <generic_retuprobe_event+0x2e74>
     d19:      	movq	%r12, %rbp
     d1c:      	cmpl	$0x9, %r14d
     d20:      	movq	0x30(%rsp), %rdi
     d25:      	jg	0xed5 <generic_retuprobe_event+0xed5>
     d2b:      	cmpl	$0x4, %r14d
     d2f:      	movq	(%rsp), %rcx
     d33:      	jle	0x111a <generic_retuprobe_event+0x111a>
     d39:      	cmpl	$0x5, %r14d
     d3d:      	je	0x16f1 <generic_retuprobe_event+0x16f1>
     d43:      	cmpl	$0x6, %r14d
     d47:      	je	0xf3d <generic_retuprobe_event+0xf3d>
     d4d:      	movq	%rax, 0x10(%rsp)
     d52:      	cmpl	$0x7, %r14d
     d56:      	jne	0x2e5b <generic_retuprobe_event+0x2e5b>
     d5c:      	movq	0x18(%rsp), %r13
     d61:      	movq	%r13, 0xc4(%rcx)
     d68:      	leaq	0xc2(%rcx), %rdi
     d6f:      	leaq	0x10(%r13), %rdx
     d73:      	movq	%rcx, %r12
     d76:      	movl	$0x2, %ecx
     d7b:      	movl	$0x4, %eax
     d80:      	movl	$0x2, %esi
     d85:      	callq	*%rax
     d87:      	leaq	0xd6(%r12), %rdi
     d8f:      	leaq	0x12(%r13), %rdx
     d93:      	movl	$0x1, %ecx
     d98:      	movl	$0x4, %eax
     d9d:      	movl	$0x1, %esi
     da2:      	callq	*%rax
     da4:      	leaq	0xd4(%r12), %rdi
     dac:      	leaq	0x226(%r13), %rdx
     db3:      	movl	$0x2, %ecx
     db8:      	movl	$0x4, %eax
     dbd:      	movl	$0x2, %esi
     dc2:      	callq	*%rax
     dc4:      	leaq	0xc0(%r12), %rdi
     dcc:      	leaq	0x224(%r13), %rdx
     dd3:      	movl	$0x2, %ecx
     dd8:      	movl	$0x4, %eax
     ddd:      	movl	$0x2, %esi
     de2:      	callq	*%rax
     de4:      	leaq	0xcc(%r12), %rdi
     dec:      	leaq	0x21c(%r13), %rdx
     df3:      	movl	$0x4, %ecx
     df8:      	movl	$0x4, %eax
     dfd:      	movl	$0x4, %esi
     e02:      	callq	*%rax
     e04:      	leaq	0xd0(%r12), %rdi
     e0c:      	leaq	0x218(%r13), %rdx
     e13:      	movl	$0x4, %ecx
     e18:      	movl	$0x4, %eax
     e1d:      	movl	$0x4, %esi
     e22:      	callq	*%rax
     e24:      	movq	0x30(%rsp), %rdi
     e29:      	leaq	0xac(%r12), %r14
     e31:      	movq	$0x0, (%rdi)
     e38:      	movq	$0x0, 0x8(%rdi)
     e40:      	movq	$0x0, 0x10(%rdi)
     e48:      	movq	$0x0, 0x18(%rdi)
     e50:      	movzwl	0xc2(%r12), %eax
     e59:      	cmpl	$0xa, %eax
     e5c:      	je	0x21f3 <generic_retuprobe_event+0x21f3>
     e62:      	cmpl	$0x2, %eax
     e65:      	jne	0x2220 <generic_retuprobe_event+0x2220>
     e6b:      	leaq	0x4(%r13), %rdx
     e6f:      	movl	$0x4, %ecx
     e74:      	movl	$0x4, %eax
     e79:      	movl	$0x4, %esi
     e7e:      	callq	*%rax
     e80:      	movl	$0x4, %ecx
     e85:      	movl	$0x4, %eax
     e8a:      	movq	%r14, %rdi
     e8d:      	movl	$0x4, %esi
     e92:      	movq	%r13, %rdx
     e95:      	jmp	0x221e <generic_retuprobe_event+0x221e>
     e9a:      	movq	0x8(%rsp), %r8
     e9f:      	jmp	0x13fa <generic_retuprobe_event+0x13fa>
     ea4:      	cmpl	$0x1c, %r14d
     ea8:      	jg	0x10f9 <generic_retuprobe_event+0x10f9>
     eae:      	cmpl	$0x11, %r14d
     eb2:      	je	0x1528 <generic_retuprobe_event+0x1528>
     eb8:      	cmpl	$0x19, %r14d
     ebc:      	je	0x15f7 <generic_retuprobe_event+0x15f7>
     ec2:      	cmpl	$0x1c, %r14d
     ec6:      	movq	(%rsp), %rcx
     eca:      	je	0x112a <generic_retuprobe_event+0x112a>
     ed0:      	jmp	0x2e5b <generic_retuprobe_event+0x2e5b>
     ed5:      	leal	-0xa(%r14), %eax
     ed9:      	cmpl	$0x2, %eax
     edc:      	movq	(%rsp), %rcx
     ee0:      	jb	0x112a <generic_retuprobe_event+0x112a>
     ee6:      	leal	-0xc(%r14), %eax
     eea:      	cmpl	$0x2, %eax
     eed:      	jb	0x114b <generic_retuprobe_event+0x114b>
     ef3:      	cmpl	$0xe, %r14d
     ef7:      	jne	0x2e5b <generic_retuprobe_event+0x2e5b>
     efd:      	leaq	0x38(%rsp), %rdi
     f02:      	leaq	0x18(%rsp), %r14
     f07:      	movl	$0x8, %ecx
     f0c:      	movl	$0x4, %eax
     f11:      	movl	$0x8, %esi
     f16:      	movq	%r14, %rdx
     f19:      	callq	*%rax
     f1b:      	movq	0x38(%rsp), %rcx
     f20:      	movl	$0x8, %edx
     f25:      	movl	$0x4, %eax
     f2a:      	movq	0x38(%rsp), %rdx
     f2f:      	movq	%r14, %rdi
     f32:      	movl	$0x8, %esi
     f37:      	callq	*%rax
     f39:      	movq	(%rsp), %rcx
     f3d:      	movq	0x18(%rsp), %rdx
     f42:      	movq	%rcx, %rdi
     f45:      	addq	$0xa0, %rdi
     f4c:      	movl	$0x1001, %ecx           # imm = 0x1001
     f51:      	movl	$0x2d, %eax
     f56:      	movl	$0x1001, %esi           # imm = 0x1001
     f5b:      	jmp	0x18e9 <generic_retuprobe_event+0x18e9>
     f60:      	cmpl	$0x20, %r14d
     f64:      	movq	0x30(%rsp), %rdi
     f69:      	jle	0x1303 <generic_retuprobe_event+0x1303>
     f6f:      	leal	-0x21(%r14), %ecx
     f73:      	cmpl	$0x4, %ecx
     f76:      	jae	0x116c <generic_retuprobe_event+0x116c>
     f7c:      	movl	$0x8, %r13d
     f82:      	movl	$0x8, %ecx
     f87:      	movl	$0x4, %eax
     f8c:      	movq	0x8(%rsp), %r14
     f91:      	movl	$0x8, %esi
     f96:      	movq	%r14, %rdx
     f99:      	jmp	0x13f5 <generic_retuprobe_event+0x13f5>
     f9e:      	cmpl	$0x27, %r14d
     fa2:      	je	0x18c5 <generic_retuprobe_event+0x18c5>
     fa8:      	cmpl	$0x28, %r14d
     fac:      	je	0x190b <generic_retuprobe_event+0x190b>
     fb2:      	cmpl	$0x2c, %r14d
     fb6:      	movq	(%rsp), %rcx
     fba:      	jne	0x2e5b <generic_retuprobe_event+0x2e5b>
     fc0:      	movq	0x18(%rsp), %r12
     fc5:      	movb	$0x0, 0x38(%rsp)
     fca:      	movq	$0x0, 0x68(%rdi)
     fd2:      	movq	$0x0, 0x60(%rdi)
     fda:      	movq	$0x0, 0x58(%rdi)
     fe2:      	movq	$0x0, 0x50(%rdi)
     fea:      	movq	$0x0, 0x48(%rdi)
     ff2:      	movq	$0x0, 0x40(%rdi)
     ffa:      	movq	$0x0, 0x38(%rdi)
    1002:      	movq	$0x0, 0x30(%rdi)
    100a:      	movq	$0x0, 0x28(%rdi)
    1012:      	movq	$0x0, 0x20(%rdi)
    101a:      	movq	$0x0, 0x18(%rdi)
    1022:      	movq	$0x0, 0x10(%rdi)
    102a:      	movq	$0x0, 0x8(%rdi)
    1032:      	movq	$0x0, (%rdi)
    1039:      	movl	$0x2, %ecx
    103e:      	movl	$0x4, %eax
    1043:      	movl	$0x2, %esi
    1048:      	movq	%r12, %rdx
    104b:      	callq	*%rax
    104d:      	testq	%rax, %rax
    1050:      	js	0x246e <generic_retuprobe_event+0x246e>
    1056:      	leaq	0x2(%r12), %r14
    105b:      	leaq	0x38(%rsp), %rdi
    1060:      	movl	$0x1, %ecx
    1065:      	movl	$0x4, %eax
    106a:      	movl	$0x1, %esi
    106f:      	movq	%r14, %rdx
    1072:      	callq	*%rax
    1074:      	testq	%rax, %rax
    1077:      	js	0x246e <generic_retuprobe_event+0x246e>
    107d:      	movq	(%rsp), %rax
    1081:      	movq	%rax, %rdi
    1084:      	addq	$0xa0, %rdi
    108b:      	cmpb	$0x0, 0x38(%rsp)
    1090:      	sete	0x9e(%rax)
    1097:      	je	0x2443 <generic_retuprobe_event+0x2443>
    109d:      	movl	$0x6c, %ecx
    10a2:      	movl	$0x2d, %eax
    10a7:      	movl	$0x6c, %esi
    10ac:      	movq	%r14, %rdx
    10af:      	callq	*%rax
    10b1:      	testl	%eax, %eax
    10b3:      	js	0x246e <generic_retuprobe_event+0x246e>
    10b9:      	decb	%al
    10bb:      	jmp	0x2464 <generic_retuprobe_event+0x2464>
    10c0:      	cmpl	$0x7, %r14d
    10c4:      	jg	0x13cc <generic_retuprobe_event+0x13cc>
    10ca:      	cmpl	$0x2, %r14d
    10ce:      	je	0x1a9c <generic_retuprobe_event+0x1a9c>
    10d4:      	cmpl	$0x3, %r14d
    10d8:      	movq	0x8(%rsp), %r8
    10dd:      	jne	0x2e6b <generic_retuprobe_event+0x2e6b>
    10e3:      	movq	$0x0, 0x9c(%rax)
    10ee:      	movl	$0x8, %r13d
    10f4:      	jmp	0x2e6b <generic_retuprobe_event+0x2e6b>
    10f9:      	leaq	0x18(%rsp), %rdx
    10fe:      	movl	$0x4, %r13d
    1104:      	movl	$0x2, %ecx
    1109:      	movl	$0x4, %eax
    110e:      	movl	$0x2, %esi
    1113:      	callq	*%rax
    1115:      	jmp	0x2e57 <generic_retuprobe_event+0x2e57>
    111a:      	cmpl	$0x1, %r14d
    111e:      	je	0x114b <generic_retuprobe_event+0x114b>
    1120:      	cmpl	$0x4, %r14d
    1124:      	jne	0x2e5b <generic_retuprobe_event+0x2e5b>
    112a:      	movl	$0x8, %r13d
    1130:      	leaq	0x18(%rsp), %rdx
    1135:      	movl	$0x8, %ecx
    113a:      	movl	$0x4, %eax
    113f:      	movl	$0x8, %esi
    1144:      	callq	*%rax
    1146:      	jmp	0x2e57 <generic_retuprobe_event+0x2e57>
    114b:      	leaq	0x18(%rsp), %rdx
    1150:      	movl	$0x4, %r13d
    1156:      	movl	$0x4, %ecx
    115b:      	movl	$0x4, %eax
    1160:      	movl	$0x4, %esi
    1165:      	callq	*%rax
    1167:      	jmp	0x2e57 <generic_retuprobe_event+0x2e57>
    116c:      	cmpl	$0x2b, %r14d
    1170:      	je	0x1f61 <generic_retuprobe_event+0x1f61>
    1176:      	cmpl	$0x29, %r14d
    117a:      	movq	0x8(%rsp), %r8
    117f:      	movq	(%rsp), %rcx
    1183:      	jne	0x2e6b <generic_retuprobe_event+0x2e6b>
    1189:      	movq	%rdi, 0x30(%rsp)
    118e:      	movq	%rbp, 0x88(%rsp)
    1196:      	movq	%r12, %rbp
    1199:      	movq	%rax, 0x10(%rsp)
    119e:      	leaq	0x18(%r8), %rdx
    11a2:      	leaq	0x38(%rsp), %rdi
    11a7:      	movl	$0x4, %r14d
    11ad:      	movl	$0x8, %ecx
    11b2:      	movl	$0x4, %eax
    11b7:      	movl	$0x8, %esi
    11bc:      	callq	*%rax
    11be:      	movq	0x38(%rsp), %r13
    11c3:      	testq	%r13, %r13
    11c6:      	je	0x2505 <generic_retuprobe_event+0x2505>
    11cc:      	movq	(%rsp), %r12
    11d0:      	movq	%r13, 0xc4(%r12)
    11d8:      	leaq	0xc2(%r12), %rdi
    11e0:      	leaq	0x10(%r13), %rdx
    11e4:      	movl	$0x2, %ecx
    11e9:      	movl	$0x4, %eax
    11ee:      	movl	$0x2, %esi
    11f3:      	callq	*%rax
    11f5:      	leaq	0xd6(%r12), %rdi
    11fd:      	leaq	0x12(%r13), %rdx
    1201:      	movl	$0x1, %ecx
    1206:      	movl	$0x4, %eax
    120b:      	movl	$0x1, %esi
    1210:      	callq	*%rax
    1212:      	leaq	0xd4(%r12), %rdi
    121a:      	leaq	0x226(%r13), %rdx
    1221:      	movl	$0x2, %ecx
    1226:      	movl	$0x4, %eax
    122b:      	movl	$0x2, %esi
    1230:      	callq	*%rax
    1232:      	leaq	0xc0(%r12), %rdi
    123a:      	leaq	0x224(%r13), %rdx
    1241:      	movl	$0x2, %ecx
    1246:      	movl	$0x4, %eax
    124b:      	movl	$0x2, %esi
    1250:      	callq	*%rax
    1252:      	leaq	0xcc(%r12), %rdi
    125a:      	leaq	0x21c(%r13), %rdx
    1261:      	movl	$0x4, %eax
    1266:      	movl	$0x4, %esi
    126b:      	callq	*%rax
    126d:      	leaq	0xd0(%r12), %rdi
    1275:      	leaq	0x218(%r13), %rdx
    127c:      	movl	$0x4, %eax
    1281:      	movl	$0x4, %esi
    1286:      	callq	*%rax
    1288:      	leaq	0xac(%r12), %r14
    1290:      	movq	0x30(%rsp), %rax
    1295:      	movq	$0x0, (%rax)
    129c:      	movq	$0x0, 0x8(%rax)
    12a4:      	movq	$0x0, 0x10(%rax)
    12ac:      	movq	$0x0, 0x18(%rax)
    12b4:      	movzwl	0xc2(%r12), %eax
    12bd:      	cmpl	$0xa, %eax
    12c0:      	je	0x2479 <generic_retuprobe_event+0x2479>
    12c6:      	cmpl	$0x2, %eax
    12c9:      	jne	0x24ab <generic_retuprobe_event+0x24ab>
    12cf:      	leaq	0x4(%r13), %rdx
    12d3:      	movl	$0x4, %ecx
    12d8:      	movl	$0x4, %eax
    12dd:      	movq	0x30(%rsp), %rdi
    12e2:      	movl	$0x4, %esi
    12e7:      	callq	*%rax
    12e9:      	movl	$0x4, %ecx
    12ee:      	movl	$0x4, %eax
    12f3:      	movq	%r14, %rdi
    12f6:      	movl	$0x4, %esi
    12fb:      	movq	%r13, %rdx
    12fe:      	jmp	0x24a9 <generic_retuprobe_event+0x24a9>
    1303:      	cmpl	$0x1a, %r14d
    1307:      	je	0x200c <generic_retuprobe_event+0x200c>
    130d:      	cmpl	$0x1b, %r14d
    1311:      	movq	0x8(%rsp), %r8
    1316:      	jne	0x2e6b <generic_retuprobe_event+0x2e6b>
    131c:      	movq	$0x0, 0x48(%rdi)
    1324:      	movq	$0x0, 0x40(%rdi)
    132c:      	movq	$0x0, 0x38(%rdi)
    1334:      	movq	$0x0, 0x30(%rdi)
    133c:      	movq	$0x0, 0x28(%rdi)
    1344:      	movq	$0x0, 0x20(%rdi)
    134c:      	movq	$0x0, 0x18(%rdi)
    1354:      	movq	$0x0, 0x10(%rdi)
    135c:      	movq	$0x0, 0x8(%rdi)
    1364:      	movq	$0x0, (%rdi)
    136b:      	leaq	0xac(%rcx), %rdi
    1372:      	leaq	0x18(%r8), %rdx
    1376:      	movl	$0x3f, %ecx
    137b:      	movl	$0x2d, %eax
    1380:      	movl	$0x3f, %esi
    1385:      	callq	*%rax
    1387:      	testq	%rax, %rax
    138a:      	js	0x23fe <generic_retuprobe_event+0x23fe>
    1390:      	movq	(%rsp), %r14
    1394:      	movq	%r14, %rdi
    1397:      	addq	$0xa4, %rdi
    139e:      	movq	0x8(%rsp), %r13
    13a3:      	leaq	0x348(%r13), %rdx
    13aa:      	movl	$0x8, %ecx
    13af:      	movl	$0x4, %eax
    13b4:      	movl	$0x8, %esi
    13b9:      	callq	*%rax
    13bb:      	movq	%r13, %r8
    13be:      	movq	%r14, %rcx
    13c1:      	movl	$0x50, %r13d
    13c7:      	jmp	0x2e6b <generic_retuprobe_event+0x2e6b>
    13cc:      	cmpl	$0x8, %r14d
    13d0:      	je	0x1b59 <generic_retuprobe_event+0x1b59>
    13d6:      	cmpl	$0x12, %r14d
    13da:      	movq	0x8(%rsp), %r8
    13df:      	jne	0x2e6b <generic_retuprobe_event+0x2e6b>
    13e5:      	xorl	%r13d, %r13d
    13e8:      	movl	$0x4, %eax
    13ed:      	xorl	%esi, %esi
    13ef:      	movq	%r8, %rdx
    13f2:      	movq	%r8, %r14
    13f5:      	callq	*%rax
    13f7:      	movq	%r14, %r8
    13fa:      	movq	(%rsp), %rcx
    13fe:      	jmp	0x2e6b <generic_retuprobe_event+0x2e6b>
    1403:      	cmpl	$0x13, %r14d
    1407:      	je	0x1ef6 <generic_retuprobe_event+0x1ef6>
    140d:      	cmpl	$0x14, %r14d
    1411:      	movq	0x8(%rsp), %r8
    1416:      	jne	0x2e6b <generic_retuprobe_event+0x2e6b>
    141c:      	movq	$0x0, 0x38(%rsp)
    1425:      	leaq	0x110(%r8), %rdx
    142c:      	movq	%rdi, %r13
    142f:      	leaq	0x38(%rsp), %rdi
    1434:      	movl	$0x8, %ecx
    1439:      	movl	$0x4, %eax
    143e:      	movq	0x8(%rsp), %rcx
    1443:      	leaq	0xd8(%rcx), %r14
    144a:      	movl	$0x8, %esi
    144f:      	callq	*%rax
    1451:      	movq	0x38(%rsp), %rcx
    1456:      	movl	$0x80, %edx
    145b:      	movl	$0x2d, %eax
    1460:      	movq	0x38(%rsp), %rdx
    1465:      	movq	%r13, %rdi
    1468:      	movl	$0x80, %esi
    146d:      	callq	*%rax
    146f:      	movq	(%rsp), %rax
    1473:      	leaq	0x12c(%rax), %rdi
    147a:      	movl	$0x4, %ecx
    147f:      	movl	$0x4, %eax
    1484:      	movl	$0x4, %esi
    1489:      	movq	%r14, %rdx
    148c:      	movq	0x8(%rsp), %r14
    1491:      	callq	*%rax
    1493:      	movq	(%rsp), %rax
    1497:      	leaq	0x11c(%rax), %rdi
    149e:      	leaq	0xe0(%r14), %rdx
    14a5:      	movl	$0x8, %ecx
    14aa:      	movl	$0x4, %eax
    14af:      	movl	$0x8, %esi
    14b4:      	callq	*%rax
    14b6:      	movq	(%rsp), %rdi
    14ba:      	addq	$0x124, %rdi            # imm = 0x124
    14c1:      	leaq	0x118(%r14), %rdx
    14c8:      	movl	$0x8, %ecx
    14cd:      	movl	$0x4, %eax
    14d2:      	movl	$0x8, %esi
    14d7:      	callq	*%rax
    14d9:      	movq	%r14, %r8
    14dc:      	movq	(%rsp), %rcx
    14e0:      	movl	$0x98, %r13d
    14e6:      	jmp	0x2e6b <generic_retuprobe_event+0x2e6b>
    14eb:      	cmpl	$0x26, %r14d
    14ef:      	movq	(%rsp), %rcx
    14f3:      	jne	0x2e5b <generic_retuprobe_event+0x2e5b>
    14f9:      	movq	0x18(%rsp), %rsi
    14fe:      	movzwl	%si, %edx
    1501:      	addq	0xc8(%rsp), %rdx
    1509:      	shrl	$0x10, %esi
    150c:      	andl	$0xfff, %esi            # imm = 0xFFF
    1512:      	movq	%rcx, %rdi
    1515:      	addq	$0xa0, %rdi
    151c:      	incl	%esi
    151e:      	movl	$0x2d, %eax
    1523:      	jmp	0x18e9 <generic_retuprobe_event+0x18e9>
    1528:      	movq	$0x0, 0x40(%rsp)
    1531:      	movq	$0x0, 0x38(%rsp)
    153a:      	movl	$0xe, %eax
    153f:      	callq	*%rax
    1541:      	shrq	$0x20, %rax
    1545:      	movq	%rax, 0x38(%rsp)
    154a:      	leaq	0x78(%rsp), %rdi
    154f:      	leaq	0x18(%rsp), %rdx
    1554:      	movl	$0x4, %ecx
    1559:      	movl	$0x4, %eax
    155e:      	movl	$0x4, %esi
    1563:      	callq	*%rax
    1565:      	movl	0x78(%rsp), %eax
    1569:      	movl	%eax, 0x40(%rsp)
    156d:      	movq	(%rip), %rdi            # 0x1574 <generic_retuprobe_event+0x1574>
    1574:      	leaq	0x38(%rsp), %rsi
    1579:      	movl	$0x1, %eax
    157e:      	callq	*%rax
    1580:      	testq	%rax, %rax
    1583:      	je	0x2091 <generic_retuprobe_event+0x2091>
    1589:      	movl	(%rax), %r13d
    158c:      	leaq	0x78(%rsp), %rdx
    1591:      	movq	%rax, %r14
    1594:      	movl	$0x4, %eax
    1599:      	movq	0x30(%rsp), %r12
    159e:      	movl	$0x4, %ecx
    15a3:      	movq	%r12, %rdi
    15a6:      	movl	$0x4, %esi
    15ab:      	callq	*%rax
    15ad:      	andl	$0xfff, %r13d           # imm = 0xFFF
    15b4:      	movq	(%rsp), %rdi
    15b8:      	addq	$0xa0, %rdi
    15bf:      	leaq	0x4(%r13), %rsi
    15c3:      	movl	$0x4, %eax
    15c8:      	movq	%r14, %rdx
    15cb:      	callq	*%rax
    15cd:      	leaq	(%r12,%r13), %rdi
    15d1:      	addq	$0x8, %rdi
    15d5:      	leaq	(%r14,%r13), %rdx
    15d9:      	addq	$0x4, %rdx
    15dd:      	movl	$0x4, %eax
    15e2:      	movl	$0x4, %ecx
    15e7:      	movl	$0x4, %esi
    15ec:      	callq	*%rax
    15ee:      	addq	$0xc, %r13
    15f2:      	jmp	0x2e57 <generic_retuprobe_event+0x2e57>
    15f7:      	movq	%rax, 0x10(%rsp)
    15fc:      	movq	0x18(%rsp), %r14
    1601:      	leaq	0xb0(%rsp), %rdi
    1609:      	movl	$0x1, %ecx
    160e:      	movl	$0x4, %eax
    1613:      	movl	$0x1, %esi
    1618:      	movq	%r14, %rdx
    161b:      	callq	*%rax
    161d:      	movzbl	0xb0(%rsp), %eax
    1625:      	testl	%eax, %eax
    1627:      	je	0x209d <generic_retuprobe_event+0x209d>
    162d:      	cmpl	$0x1, %eax
    1630:      	jne	0x22c2 <generic_retuprobe_event+0x22c2>
    1636:      	addq	$0x10, %r14
    163a:      	leaq	0x38(%rsp), %rdi
    163f:      	movl	$0x4, %r13d
    1645:      	movl	$0x8, %ecx
    164a:      	movl	$0x4, %eax
    164f:      	movl	$0x8, %esi
    1654:      	movq	%r14, %rdx
    1657:      	callq	*%rax
    1659:      	movq	0x38(%rsp), %rdx
    165e:      	leaq	0x78(%rsp), %rdi
    1663:      	movl	$0x8, %ecx
    1668:      	movl	$0x4, %eax
    166d:      	movl	$0x8, %esi
    1672:      	callq	*%rax
    1674:      	movq	0x38(%rsp), %rdx
    1679:      	addq	$0x8, %rdx
    167d:      	leaq	0x90(%rsp), %rdi
    1685:      	movl	$0x8, %ecx
    168a:      	movl	$0x4, %eax
    168f:      	movl	$0x8, %esi
    1694:      	callq	*%rax
    1696:      	movq	0x78(%rsp), %rdx
    169b:      	movq	0x90(%rsp), %r12
    16a3:      	cmpq	$0xfff, %r12            # imm = 0xFFF
    16aa:      	movl	$0xfff, %r14d           # imm = 0xFFF
    16b0:      	cmovbq	%r12, %r14
    16b4:      	movq	0x10(%rsp), %rdi
    16b9:      	addq	$0xa4, %rdi
    16c0:      	movl	$0x4, %eax
    16c5:      	movl	%r14d, %esi
    16c8:      	callq	*%rax
    16ca:      	testl	%eax, %eax
    16cc:      	js	0x240f <generic_retuprobe_event+0x240f>
    16d2:      	movq	0x10(%rsp), %rax
    16d7:      	movl	%r12d, 0x9c(%rax)
    16de:      	movl	%r14d, 0xa0(%rax)
    16e5:      	addq	$0x8, %r14
    16e9:      	movq	%r14, %r13
    16ec:      	jmp	0x2435 <generic_retuprobe_event+0x2435>
    16f1:      	movq	0x18(%rsp), %r13
    16f6:      	leaq	0xc4(%rcx), %rdi
    16fd:      	leaq	0x98(%r13), %rdx
    1704:      	movq	%rcx, %r14
    1707:      	movl	$0x4, %ecx
    170c:      	movl	$0x4, %eax
    1711:      	movl	$0x4, %esi
    1716:      	callq	*%rax
    1718:      	leaq	0xc8(%r14), %rdi
    171f:      	leaq	0x70(%r13), %rdx
    1723:      	movl	$0x4, %ecx
    1728:      	movl	$0x4, %eax
    172d:      	movl	$0x4, %esi
    1732:      	callq	*%rax
    1734:      	leaq	0xcc(%r14), %rdi
    173b:      	leaq	0x90(%r13), %rdx
    1742:      	movl	$0x4, %ecx
    1747:      	movl	$0x4, %eax
    174c:      	movl	$0x4, %esi
    1751:      	callq	*%rax
    1753:      	leaq	0xd0(%r14), %rdi
    175a:      	leaq	0xa8(%r13), %rdx
    1761:      	movl	$0x4, %ecx
    1766:      	movl	$0x4, %eax
    176b:      	movl	$0x4, %esi
    1770:      	callq	*%rax
    1772:      	movq	$0x0, 0x38(%rsp)
    177b:      	leaq	0xc8(%r13), %rdx
    1782:      	leaq	0x38(%rsp), %rdi
    1787:      	movl	$0x8, %ecx
    178c:      	movl	$0x4, %eax
    1791:      	movl	$0x8, %esi
    1796:      	callq	*%rax
    1798:      	leaq	0xb8(%r13), %rdx
    179f:      	leaq	0xb0(%rsp), %rdi
    17a7:      	movl	$0x2, %ecx
    17ac:      	movl	$0x4, %eax
    17b1:      	movl	$0x2, %esi
    17b6:      	callq	*%rax
    17b8:      	movzwl	0xb0(%rsp), %r12d
    17c1:      	addq	0x38(%rsp), %r12
    17c6:      	leaq	0xc4(%rsp), %rdi
    17ce:      	movl	$0x1, %ecx
    17d3:      	movl	$0x4, %eax
    17d8:      	movl	$0x1, %esi
    17dd:      	movq	%r12, %rdx
    17e0:      	callq	*%rax
    17e2:      	movzbl	0xc4(%rsp), %eax
    17ea:      	shrl	$0x4, %eax
    17ed:      	cmpl	$0x6, %eax
    17f0:      	je	0x2131 <generic_retuprobe_event+0x2131>
    17f6:      	cmpl	$0x4, %eax
    17f9:      	jne	0x2e51 <generic_retuprobe_event+0x2e51>
    17ff:      	movq	%rbx, 0x10(%rsp)
    1804:      	leaq	0x9(%r12), %rdx
    1809:      	leaq	0xd0(%rsp), %rdi
    1811:      	movl	$0x1, %ecx
    1816:      	movl	$0x4, %eax
    181b:      	movl	$0x1, %esi
    1820:      	callq	*%rax
    1822:      	movzbl	0xd0(%rsp), %eax
    182a:      	movq	(%rsp), %rsi
    182e:      	movw	%ax, 0xc0(%rsi)
    1835:      	movw	$0x2, 0xc2(%rsi)
    183e:      	leaq	0xc(%r12), %rdx
    1843:      	movq	0x30(%rsp), %rdi
    1848:      	movq	$0x0, (%rdi)
    184f:      	movq	$0x0, 0x8(%rdi)
    1857:      	movq	$0x0, 0x10(%rdi)
    185f:      	movq	$0x0, 0x18(%rdi)
    1867:      	movl	$0x4, %ecx
    186c:      	movl	$0x4, %eax
    1871:      	leaq	0xac(%rsi), %r14
    1878:      	movl	$0x4, %esi
    187d:      	callq	*%rax
    187f:      	addq	$0x10, %r12
    1883:      	movl	$0x4, %ecx
    1888:      	movl	$0x4, %eax
    188d:      	movq	%r14, %rdi
    1890:      	movl	$0x4, %esi
    1895:      	movq	%r12, %rdx
    1898:      	callq	*%rax
    189a:      	movq	%r13, 0xa0(%rsp)
    18a2:      	leaq	0xb6(%r13), %rdx
    18a9:      	leaq	0xd8(%rsp), %rdi
    18b1:      	movl	$0x2, %ecx
    18b6:      	movl	$0x4, %eax
    18bb:      	movl	$0x2, %esi
    18c0:      	jmp	0x2cbf <generic_retuprobe_event+0x2cbf>
    18c5:      	movl	$0x120, %edx            # imm = 0x120
    18ca:      	addq	0x18(%rsp), %rdx
    18cf:      	movq	(%rsp), %rdi
    18d3:      	addq	$0xa0, %rdi
    18da:      	movl	$0x11, %ecx
    18df:      	movl	$0x2d, %eax
    18e4:      	movl	$0x11, %esi
    18e9:      	callq	*%rax
    18eb:      	movq	%rax, %r13
    18ee:      	testq	%rax, %rax
    18f1:      	js	0x2e57 <generic_retuprobe_event+0x2e57>
    18f7:      	leal	-0x1(%r13), %eax
    18fb:      	movq	0x30(%rsp), %rcx
    1900:      	movl	%eax, (%rcx)
    1902:      	addq	$0x3, %r13
    1906:      	jmp	0x2e57 <generic_retuprobe_event+0x2e57>
    190b:      	movq	0x18(%rsp), %r12
    1910:      	movq	$0x0, 0x10(%rdi)
    1918:      	movq	$0x0, 0x8(%rdi)
    1920:      	movq	$0x0, (%rdi)
    1927:      	movl	$0x2, %ecx
    192c:      	movl	$0x4, %eax
    1931:      	movq	%rdi, %r14
    1934:      	movl	$0x2, %esi
    1939:      	movq	%r12, %rdx
    193c:      	callq	*%rax
    193e:      	testq	%rax, %rax
    1941:      	movq	(%rsp), %rcx
    1945:      	js	0x2338 <generic_retuprobe_event+0x2338>
    194b:      	movzwl	(%r14), %eax
    194f:      	cmpl	$0xa, %eax
    1952:      	je	0x22dd <generic_retuprobe_event+0x22dd>
    1958:      	cmpl	$0x2, %eax
    195b:      	jne	0x231f <generic_retuprobe_event+0x231f>
    1961:      	leaq	0x4(%r12), %rdx
    1966:      	leaq	0x38(%rsp), %rdi
    196b:      	movl	$0x4, %ecx
    1970:      	movl	$0x4, %eax
    1975:      	movl	$0x4, %esi
    197a:      	callq	*%rax
    197c:      	movl	0x38(%rsp), %eax
    1980:      	movq	(%rsp), %rdi
    1984:      	movq	%rax, 0xa4(%rdi)
    198b:      	addq	$0x9e, %rdi
    1992:      	addq	$0x2, %r12
    1996:      	movl	$0x2, %ecx
    199b:      	movl	$0x4, %eax
    19a0:      	jmp	0x2315 <generic_retuprobe_event+0x2315>
    19a5:      	xorl	%eax, %eax
    19a7:      	movq	%rax, 0x8(%rsp)
    19ac:      	cmpq	$0x3, 0xb8(%rsp)
    19b5:      	jb	0x1a7c <generic_retuprobe_event+0x1a7c>
    19bb:      	movq	%r14, %rbp
    19be:      	movq	%rbx, 0x10(%rsp)
    19c3:      	movq	0x88(%rsp), %rax
    19cb:      	leaq	0x20(%rax), %rdx
    19cf:      	leaq	0x38(%rsp), %rdi
    19d4:      	movl	$0x4, %r12d
    19da:      	movl	$0x10, %ecx
    19df:      	movl	$0x4, %eax
    19e4:      	movl	$0x10, %esi
    19e9:      	callq	*%rax
    19eb:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    19f0:      	testl	%eax, %eax
    19f2:      	js	0x1a89 <generic_retuprobe_event+0x1a89>
    19f8:      	movq	0x40(%rsp), %r14
    19fd:      	movq	0x8(%rsp), %rax
    1a02:      	cmpq	%rax, %r14
    1a05:      	movq	%rax, %rcx
    1a08:      	cmovbq	%r14, %rcx
    1a0c:      	testq	%rax, %rax
    1a0f:      	movq	%rcx, %rbx
    1a12:      	cmovneq	%rcx, %r14
    1a16:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    1a1b:      	cmpq	$0xffe, %r14            # imm = 0xFFE
    1a22:      	ja	0x1a89 <generic_retuprobe_event+0x1a89>
    1a24:      	addq	0x20(%rsp), %rbp
    1a29:      	movq	%rbp, (%rsp)
    1a2d:      	movl	%ebp, %edi
    1a2f:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    1a35:      	addq	%r15, %rdi
    1a38:      	movq	0x38(%rsp), %rcx
    1a3d:      	movl	$0x4, %eax
    1a42:      	movq	0x38(%rsp), %rdx
    1a47:      	movl	%r14d, %esi
    1a4a:      	callq	*%rax
    1a4c:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1a51:      	testl	%eax, %eax
    1a53:      	js	0x1a89 <generic_retuprobe_event+0x1a89>
    1a55:      	movq	%r15, 0x20(%rsp)
    1a5a:      	movq	%r14, %r15
    1a5d:      	addq	%r14, %r13
    1a60:      	cmpq	$0x0, 0x8(%rsp)
    1a66:      	je	0x25a8 <generic_retuprobe_event+0x25a8>
    1a6c:      	subq	%rbx, 0x8(%rsp)
    1a71:      	jne	0x25af <generic_retuprobe_event+0x25af>
    1a77:      	jmp	0x25ba <generic_retuprobe_event+0x25ba>
    1a7c:      	movq	%r13, %rbp
    1a7f:      	movq	0x28(%rsp), %rax
    1a84:      	jmp	0x31a <generic_retuprobe_event+0x31a>
    1a89:      	movq	0x28(%rsp), %rax
    1a8e:      	movl	%ecx, (%r15,%rax)
    1a92:      	movq	0x10(%rsp), %rbx
    1a97:      	jmp	0xbc6 <generic_retuprobe_event+0xbc6>
    1a9c:      	movq	%rbp, 0x88(%rsp)
    1aa4:      	movq	%r12, 0xa8(%rsp)
    1aac:      	movq	$0x0, 0x78(%rsp)
    1ab5:      	movq	$0x0, 0x38(%rsp)
    1abe:      	leaq	0x78(%rsp), %rdi
    1ac3:      	leaq	0x38(%rsp), %rdx
    1ac8:      	movl	$0x8, %ecx
    1acd:      	movq	%rax, %r12
    1ad0:      	movl	$0x4, %eax
    1ad5:      	movl	$0x4, %r13d
    1adb:      	movl	$0x8, %esi
    1ae0:      	callq	*%rax
    1ae2:      	movq	0x78(%rsp), %rbp
    1ae7:      	cmpq	$0xfff, %rbp            # imm = 0xFFF
    1aee:      	movl	$0xfff, %r14d           # imm = 0xFFF
    1af4:      	cmovbq	%rbp, %r14
    1af8:      	movq	%r12, 0x10(%rsp)
    1afd:      	addq	$0xa4, %r12
    1b04:      	movl	$0x4, %eax
    1b09:      	movq	0x8(%rsp), %rdx
    1b0e:      	movq	%r12, %rdi
    1b11:      	movl	%r14d, %esi
    1b14:      	callq	*%rax
    1b16:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1b1b:      	testl	%eax, %eax
    1b1d:      	js	0x1b34 <generic_retuprobe_event+0x1b34>
    1b1f:      	movq	0x10(%rsp), %rax
    1b24:      	movl	%r14d, 0xa0(%rax)
    1b2b:      	addq	$0x8, %r14
    1b2f:      	movl	%ebp, %ecx
    1b31:      	movq	%r14, %r13
    1b34:      	movq	0x10(%rsp), %rax
    1b39:      	movl	%ecx, 0x9c(%rax)
    1b3f:      	movq	0xa8(%rsp), %r12
    1b47:      	movq	0x8(%rsp), %r8
    1b4c:      	movq	0x88(%rsp), %rbp
    1b54:      	jmp	0x13fa <generic_retuprobe_event+0x13fa>
    1b59:      	movq	%rbp, %r14
    1b5c:      	leaq	0xc4(%rcx), %rbp
    1b63:      	leaq	0xdc(%rcx), %rax
    1b6a:      	movq	%rax, 0x10(%rsp)
    1b6f:      	movq	0x8(%rsp), %r13
    1b74:      	leaq	0x8(%r13), %rdx
    1b78:      	movl	$0x4, %ecx
    1b7d:      	movl	$0x4, %eax
    1b82:      	movl	$0x4, %esi
    1b87:      	callq	*%rax
    1b89:      	movq	(%rsp), %rax
    1b8d:      	leaq	0xa0(%rax), %rdi
    1b94:      	leaq	0xc(%r13), %rdx
    1b98:      	movl	$0x4, %ecx
    1b9d:      	movl	$0x4, %eax
    1ba2:      	movl	$0x4, %esi
    1ba7:      	callq	*%rax
    1ba9:      	movq	(%rsp), %rax
    1bad:      	leaq	0xac(%rax), %rdi
    1bb4:      	leaq	0x18(%r13), %rdx
    1bb8:      	movl	$0x4, %ecx
    1bbd:      	movl	$0x4, %eax
    1bc2:      	movl	$0x4, %esi
    1bc7:      	callq	*%rax
    1bc9:      	movq	(%rsp), %rax
    1bcd:      	leaq	0xb0(%rax), %rdi
    1bd4:      	leaq	0x1c(%r13), %rdx
    1bd8:      	movl	$0x4, %ecx
    1bdd:      	movl	$0x4, %eax
    1be2:      	movl	$0x4, %esi
    1be7:      	callq	*%rax
    1be9:      	movq	(%rsp), %rax
    1bed:      	leaq	0xa4(%rax), %rdi
    1bf4:      	leaq	0x10(%r13), %rdx
    1bf8:      	movl	$0x4, %ecx
    1bfd:      	movl	$0x4, %eax
    1c02:      	movl	$0x4, %esi
    1c07:      	callq	*%rax
    1c09:      	movq	(%rsp), %rax
    1c0d:      	leaq	0xa8(%rax), %rdi
    1c14:      	leaq	0x14(%r13), %rdx
    1c18:      	movl	$0x4, %ecx
    1c1d:      	movl	$0x4, %eax
    1c22:      	movl	$0x4, %esi
    1c27:      	callq	*%rax
    1c29:      	movq	(%rsp), %rax
    1c2d:      	leaq	0xb4(%rax), %rdi
    1c34:      	leaq	0x20(%r13), %rdx
    1c38:      	movl	$0x4, %ecx
    1c3d:      	movl	$0x4, %eax
    1c42:      	movl	$0x4, %esi
    1c47:      	callq	*%rax
    1c49:      	movq	(%rsp), %rax
    1c4d:      	leaq	0xb8(%rax), %rdi
    1c54:      	leaq	0x24(%r13), %rdx
    1c58:      	movl	$0x4, %ecx
    1c5d:      	movl	$0x4, %eax
    1c62:      	movl	$0x4, %esi
    1c67:      	callq	*%rax
    1c69:      	movq	(%rsp), %rax
    1c6d:      	movl	$0x0, 0xc0(%rax)
    1c77:      	movq	(%rsp), %rax
    1c7b:      	leaq	0xbc(%rax), %rdi
    1c82:      	leaq	0x28(%r13), %rdx
    1c86:      	movl	$0x4, %ecx
    1c8b:      	movl	$0x4, %eax
    1c90:      	movl	$0x4, %esi
    1c95:      	callq	*%rax
    1c97:      	movq	(%rsp), %rax
    1c9b:      	leaq	0xcc(%rax), %rdi
    1ca2:      	leaq	0x40(%r13), %rdx
    1ca6:      	movl	$0x8, %ecx
    1cab:      	movl	$0x4, %eax
    1cb0:      	movl	$0x8, %esi
    1cb5:      	callq	*%rax
    1cb7:      	movq	(%rsp), %rax
    1cbb:      	leaq	0xd4(%rax), %rdi
    1cc2:      	leaq	0x30(%r13), %rdx
    1cc6:      	movl	$0x8, %ecx
    1ccb:      	movl	$0x4, %eax
    1cd0:      	movl	$0x8, %esi
    1cd5:      	callq	*%rax
    1cd7:      	leaq	0x38(%r13), %rdx
    1cdb:      	movl	$0x8, %ecx
    1ce0:      	movl	$0x4, %eax
    1ce5:      	movq	%rbp, %rdi
    1ce8:      	movq	%r14, %rbp
    1ceb:      	movl	$0x8, %esi
    1cf0:      	callq	*%rax
    1cf2:      	leaq	0x90(%r13), %rdx
    1cf9:      	leaq	0x38(%rsp), %rdi
    1cfe:      	movl	$0x8, %ecx
    1d03:      	movl	$0x4, %eax
    1d08:      	movl	$0x8, %esi
    1d0d:      	callq	*%rax
    1d0f:      	movq	0x38(%rsp), %r14
    1d14:      	leaq	0xc8(%r14), %rdx
    1d1b:      	movl	$0x4, %ecx
    1d20:      	movl	$0x4, %eax
    1d25:      	movq	0x10(%rsp), %rdi
    1d2a:      	movl	$0x4, %esi
    1d2f:      	callq	*%rax
    1d31:      	movq	(%rsp), %rax
    1d35:      	leaq	0xe0(%rax), %rdi
    1d3c:      	leaq	0xcc(%r14), %rdx
    1d43:      	movl	$0x4, %ecx
    1d48:      	movl	$0x4, %eax
    1d4d:      	movl	$0x4, %esi
    1d52:      	callq	*%rax
    1d54:      	movq	(%rsp), %rax
    1d58:      	leaq	0xe4(%rax), %rdi
    1d5f:      	leaq	0xd0(%r14), %rdx
    1d66:      	movl	$0x4, %ecx
    1d6b:      	movl	$0x4, %eax
    1d70:      	movl	$0x4, %esi
    1d75:      	callq	*%rax
    1d77:      	movq	(%rsp), %rdi
    1d7b:      	addq	$0xe8, %rdi
    1d82:      	addq	$0x158, %r14            # imm = 0x158
    1d89:      	movl	$0x4, %ecx
    1d8e:      	movl	$0x4, %eax
    1d93:      	movl	$0x4, %esi
    1d98:      	movq	%r14, %rdx
    1d9b:      	callq	*%rax
    1d9d:      	movq	%r13, %r8
    1da0:      	movq	(%rsp), %rcx
    1da4:      	movl	$0x50, %r13d
    1daa:      	jmp	0x2e6b <generic_retuprobe_event+0x2e6b>
    1daf:      	movq	0x8(%rsp), %r14
    1db4:      	leaq	0xc8(%r14), %rdx
    1dbb:      	movl	$0x4, %ecx
    1dc0:      	movl	$0x4, %eax
    1dc5:      	movl	$0x4, %esi
    1dca:      	callq	*%rax
    1dcc:      	movq	(%rsp), %rax
    1dd0:      	leaq	0xa0(%rax), %rdi
    1dd7:      	leaq	0xcc(%r14), %rdx
    1dde:      	movl	$0x4, %ecx
    1de3:      	movl	$0x4, %eax
    1de8:      	movl	$0x4, %esi
    1ded:      	callq	*%rax
    1def:      	movq	(%rsp), %rax
    1df3:      	leaq	0xa4(%rax), %rdi
    1dfa:      	leaq	0xd0(%r14), %rdx
    1e01:      	movl	$0x4, %ecx
    1e06:      	movl	$0x4, %eax
    1e0b:      	movl	$0x4, %esi
    1e10:      	callq	*%rax
    1e12:      	movq	(%rsp), %rdi
    1e16:      	addq	$0xa8, %rdi
    1e1d:      	leaq	0x158(%r14), %rdx
    1e24:      	movl	$0x4, %ecx
    1e29:      	movl	$0x4, %eax
    1e2e:      	movl	$0x4, %esi
    1e33:      	callq	*%rax
    1e35:      	movq	%r14, %r8
    1e38:      	movq	(%rsp), %rcx
    1e3c:      	movl	$0x10, %r13d
    1e42:      	jmp	0x2e6b <generic_retuprobe_event+0x2e6b>
    1e47:      	movq	0x8(%rsp), %r14
    1e4c:      	leaq	0x38(%r14), %rdx
    1e50:      	movl	$0x4, %ecx
    1e55:      	movl	$0x4, %eax
    1e5a:      	movl	$0x4, %esi
    1e5f:      	callq	*%rax
    1e61:      	movq	(%rsp), %rax
    1e65:      	leaq	0xa0(%rax), %rdi
    1e6c:      	leaq	0x3c(%r14), %rdx
    1e70:      	movl	$0x4, %ecx
    1e75:      	movl	$0x4, %eax
    1e7a:      	movl	$0x4, %esi
    1e7f:      	callq	*%rax
    1e81:      	movq	(%rsp), %rax
    1e85:      	leaq	0xa4(%rax), %rdi
    1e8c:      	leaq	0x40(%r14), %rdx
    1e90:      	movl	$0x4, %ecx
    1e95:      	movl	$0x4, %eax
    1e9a:      	movl	$0x4, %esi
    1e9f:      	callq	*%rax
    1ea1:      	movq	(%rsp), %rax
    1ea5:      	leaq	0xa8(%rax), %rdi
    1eac:      	leaq	0x44(%r14), %rdx
    1eb0:      	movl	$0x4, %ecx
    1eb5:      	movl	$0x4, %eax
    1eba:      	movl	$0x4, %esi
    1ebf:      	callq	*%rax
    1ec1:      	movq	(%rsp), %rdi
    1ec5:      	addq	$0xac, %rdi
    1ecc:      	leaq	0x80(%r14), %rdx
    1ed3:      	movl	$0x10, %ecx
    1ed8:      	movl	$0x4, %eax
    1edd:      	movl	$0x10, %esi
    1ee2:      	callq	*%rax
    1ee4:      	movq	%r14, %r8
    1ee7:      	movq	(%rsp), %rcx
    1eeb:      	movl	$0x20, %r13d
    1ef1:      	jmp	0x2e6b <generic_retuprobe_event+0x2e6b>
    1ef6:      	movl	$0x4, %ecx
    1efb:      	movl	$0x4, %eax
    1f00:      	movq	0x8(%rsp), %r14
    1f05:      	movl	$0x4, %esi
    1f0a:      	movq	%r14, %rdx
    1f0d:      	callq	*%rax
    1f0f:      	movq	(%rsp), %rax
    1f13:      	leaq	0xa0(%rax), %rdi
    1f1a:      	leaq	0x4(%r14), %rdx
    1f1e:      	movl	$0x4, %ecx
    1f23:      	movl	$0x4, %eax
    1f28:      	movl	$0x4, %esi
    1f2d:      	callq	*%rax
    1f2f:      	movq	(%rsp), %rdi
    1f33:      	addq	$0xa4, %rdi
    1f3a:      	leaq	0x30(%r14), %rdx
    1f3e:      	movl	$0x10, %ecx
    1f43:      	movl	$0x4, %eax
    1f48:      	movl	$0x10, %esi
    1f4d:      	callq	*%rax
    1f4f:      	movq	%r14, %r8
    1f52:      	movq	(%rsp), %rcx
    1f56:      	movl	$0x18, %r13d
    1f5c:      	jmp	0x2e6b <generic_retuprobe_event+0x2e6b>
    1f61:      	movq	0x8(%rsp), %r13
    1f66:      	leaq	0x4(%r13), %rdx
    1f6a:      	leaq	0x38(%rsp), %rdi
    1f6f:      	movl	$0x4, %ecx
    1f74:      	movl	$0x4, %eax
    1f79:      	movl	$0x4, %esi
    1f7e:      	callq	*%rax
    1f80:      	movl	0x38(%rsp), %eax
    1f84:      	movq	(%rsp), %r14
    1f88:      	movl	%eax, 0x9c(%r14)
    1f8f:      	leaq	0xc(%r13), %rdx
    1f93:      	leaq	0x38(%rsp), %rdi
    1f98:      	movl	$0x4, %ecx
    1f9d:      	movl	$0x4, %eax
    1fa2:      	movl	$0x4, %esi
    1fa7:      	callq	*%rax
    1fa9:      	movl	0x38(%rsp), %eax
    1fad:      	movl	%eax, 0xa0(%r14)
    1fb4:      	leaq	0x50(%r13), %rdx
    1fb8:      	leaq	0x38(%rsp), %rdi
    1fbd:      	movl	$0x8, %ecx
    1fc2:      	movl	$0x2d, %eax
    1fc7:      	movl	$0x8, %esi
    1fcc:      	callq	*%rax
    1fce:      	movq	%r14, %rdi
    1fd1:      	addq	$0xa4, %rdi
    1fd8:      	movl	$0x3f8, %edx            # imm = 0x3F8
    1fdd:      	movq	0x38(%rsp), %rcx
    1fe2:      	addq	%rdx, %rcx
    1fe5:      	movl	$0x10, %esi
    1fea:      	movl	$0x2d, %eax
    1fef:      	addq	0x38(%rsp), %rdx
    1ff4:      	movl	$0x10, %esi
    1ff9:      	callq	*%rax
    1ffb:      	movq	%r13, %r8
    1ffe:      	movq	%r14, %rcx
    2001:      	movl	$0x18, %r13d
    2007:      	jmp	0x2e6b <generic_retuprobe_event+0x2e6b>
    200c:      	movq	$0x0, 0x48(%rdi)
    2014:      	movq	$0x0, 0x40(%rdi)
    201c:      	movq	$0x0, 0x38(%rdi)
    2024:      	movq	$0x0, 0x30(%rdi)
    202c:      	movq	$0x0, 0x28(%rdi)
    2034:      	movq	$0x0, 0x20(%rdi)
    203c:      	movq	$0x0, 0x18(%rdi)
    2044:      	movq	$0x0, 0x10(%rdi)
    204c:      	movq	$0x0, 0x8(%rdi)
    2054:      	movq	%rdi, 0x30(%rsp)
    2059:      	movq	$0x0, (%rdi)
    2060:      	leaq	0x38(%rsp), %rdi
    2065:      	movl	$0x8, %ecx
    206a:      	movl	$0x4, %eax
    206f:      	movq	0x8(%rsp), %rdx
    2074:      	movl	$0x8, %esi
    2079:      	callq	*%rax
    207b:      	testq	%rax, %rax
    207e:      	je	0x2343 <generic_retuprobe_event+0x2343>
    2084:      	xorl	%r13d, %r13d
    2087:      	movq	0x8(%rsp), %r8
    208c:      	jmp	0x2560 <generic_retuprobe_event+0x2560>
    2091:      	movq	$-0x1, %r13
    2098:      	jmp	0x2e57 <generic_retuprobe_event+0x2e57>
    209d:      	leaq	0x10(%r14), %rdx
    20a1:      	leaq	0x78(%rsp), %rdi
    20a6:      	movl	$0x8, %ecx
    20ab:      	movl	$0x4, %eax
    20b0:      	movl	$0x8, %esi
    20b5:      	callq	*%rax
    20b7:      	addq	$0x18, %r14
    20bb:      	leaq	0x90(%rsp), %rdi
    20c3:      	movl	$0x8, %ecx
    20c8:      	movl	$0x4, %eax
    20cd:      	movl	$0x8, %esi
    20d2:      	movq	%r14, %rdx
    20d5:      	callq	*%rax
    20d7:      	movq	0x78(%rsp), %rdx
    20dc:      	movq	0x90(%rsp), %r14
    20e4:      	cmpq	$0xfff, %r14            # imm = 0xFFF
    20eb:      	movl	$0xfff, %r13d           # imm = 0xFFF
    20f1:      	cmovbq	%r14, %r13
    20f5:      	movq	0x10(%rsp), %rdi
    20fa:      	addq	$0xa4, %rdi
    2101:      	movl	$0x4, %eax
    2106:      	movl	%r13d, %esi
    2109:      	callq	*%rax
    210b:      	testl	%eax, %eax
    210d:      	js	0x2420 <generic_retuprobe_event+0x2420>
    2113:      	movq	0x10(%rsp), %r12
    2118:      	movl	%r14d, 0x9c(%r12)
    2120:      	movl	%r13d, 0xa0(%r12)
    2128:      	addq	$0x8, %r13
    212c:      	jmp	0x2435 <generic_retuprobe_event+0x2435>
    2131:      	movq	%r13, 0xa0(%rsp)
    2139:      	movq	%rbx, 0x10(%rsp)
    213e:      	movq	0x38(%rsp), %r14
    2143:      	movl	$0x0, 0x78(%rsp)
    214b:      	movzwl	0xb0(%rsp), %r12d
    2154:      	movq	(%rip), %rdi            # 0x215b <generic_retuprobe_event+0x215b>
    215b:      	leaq	0x78(%rsp), %rsi
    2160:      	movl	$0x1, %eax
    2165:      	leaq	(%r14,%r12), %rcx
    2169:      	movq	%rcx, 0xe8(%rsp)
    2171:      	callq	*%rax
    2173:      	testq	%rax, %rax
    2176:      	je	0x2c60 <generic_retuprobe_event+0x2c60>
    217c:      	movq	%rax, %r13
    217f:      	movw	%r12w, (%rax)
    2183:      	movb	$-0x1, 0x5(%rax)
    2187:      	movb	$0x0, 0x7(%rax)
    218b:      	movq	%rax, %rbx
    218e:      	addq	$0x6, %rbx
    2192:      	movq	0xe8(%rsp), %rax
    219a:      	leaq	0x6(%rax), %rdx
    219e:      	movl	$0x1, %ecx
    21a3:      	movl	$0x4, %eax
    21a8:      	movq	%rbx, %rdi
    21ab:      	movl	$0x1, %esi
    21b0:      	callq	*%rax
    21b2:      	testq	%rax, %rax
    21b5:      	js	0x2c60 <generic_retuprobe_event+0x2c60>
    21bb:      	movzbl	0x5(%r13), %eax
    21c0:      	cmpl	$0x32, %eax
    21c3:      	jg	0x256e <generic_retuprobe_event+0x256e>
    21c9:      	testl	%eax, %eax
    21cb:      	je	0x2597 <generic_retuprobe_event+0x2597>
    21d1:      	cmpl	$0x2b, %eax
    21d4:      	je	0x2597 <generic_retuprobe_event+0x2597>
    21da:      	cmpl	$0x2c, %eax
    21dd:      	jne	0x274e <generic_retuprobe_event+0x274e>
    21e3:      	movw	$0x8, 0x2(%r13)
    21ea:      	movw	$0x8, %ax
    21ee:      	jmp	0x269c <generic_retuprobe_event+0x269c>
    21f3:      	leaq	0x48(%r13), %rdx
    21f7:      	movl	$0x10, %ecx
    21fc:      	movl	$0x4, %eax
    2201:      	movl	$0x10, %esi
    2206:      	callq	*%rax
    2208:      	leaq	0x38(%r13), %rdx
    220c:      	movl	$0x10, %ecx
    2211:      	movl	$0x4, %eax
    2216:      	movq	%r14, %rdi
    2219:      	movl	$0x10, %esi
    221e:      	callq	*%rax
    2220:      	movq	(%rsp), %r12
    2224:      	leaq	0xbc(%r12), %rdi
    222c:      	leaq	0xc(%r13), %r14
    2230:      	addq	$0xe, %r13
    2234:      	movl	$0x2, %ecx
    2239:      	movl	$0x4, %eax
    223e:      	movl	$0x2, %esi
    2243:      	movq	%r13, %rdx
    2246:      	callq	*%rax
    2248:      	movq	%r12, %rdi
    224b:      	addq	$0xbe, %rdi
    2252:      	movl	$0x2, %ecx
    2257:      	movl	$0x4, %eax
    225c:      	movl	$0x2, %esi
    2261:      	movq	%r14, %rdx
    2264:      	callq	*%rax
    2266:      	movzwl	0xbe(%r12), %eax
    226f:      	movbew	%ax, 0xbe(%r12)
    227a:      	movq	0x18(%rsp), %rax
    227f:      	movq	%rax, 0x38(%rsp)
    2284:      	movq	(%rip), %rdi            # 0x228b <generic_retuprobe_event+0x228b>
    228b:      	leaq	0x38(%rsp), %rsi
    2290:      	movl	$0x1, %eax
    2295:      	callq	*%rax
    2297:      	testq	%rax, %rax
    229a:      	je	0x2e51 <generic_retuprobe_event+0x2e51>
    22a0:      	movl	(%rax), %ecx
    22a2:      	movq	0x10(%rsp), %r12
    22a7:      	movl	%ecx, 0x10(%r12)
    22ac:      	movq	0x8(%rax), %rcx
    22b0:      	movq	%rcx, 0x18(%r12)
    22b5:      	movl	0x4(%rax), %eax
    22b8:      	movl	%eax, 0x7c(%r12)
    22bd:      	jmp	0x2e51 <generic_retuprobe_event+0x2e51>
    22c2:      	movq	0x10(%rsp), %rax
    22c7:      	movq	$0x0, 0x9c(%rax)
    22d2:      	movl	$0x8, %r13d
    22d8:      	jmp	0x2e57 <generic_retuprobe_event+0x2e57>
    22dd:      	leaq	0xa4(%rcx), %rdi
    22e4:      	leaq	0x8(%r12), %rdx
    22e9:      	movq	%rcx, %r14
    22ec:      	movl	$0x10, %ecx
    22f1:      	movl	$0x4, %eax
    22f6:      	movl	$0x10, %esi
    22fb:      	callq	*%rax
    22fd:      	movq	%r14, %rdi
    2300:      	addq	$0x9e, %rdi
    2307:      	addq	$0x2, %r12
    230b:      	movl	$0x2, %ecx
    2310:      	movl	$0x4, %eax
    2315:      	movl	$0x2, %esi
    231a:      	movq	%r12, %rdx
    231d:      	callq	*%rax
    231f:      	movq	(%rsp), %rcx
    2323:      	movzwl	0x9e(%rcx), %eax
    232a:      	movbew	%ax, 0x9e(%rcx)
    2333:      	movq	0x20(%rsp), %r15
    2338:      	movl	$0x18, %r13d
    233e:      	jmp	0x2e5b <generic_retuprobe_event+0x2e5b>
    2343:      	movq	(%rsp), %rax
    2347:      	leaq	0xac(%rax), %rdi
    234e:      	movq	0x38(%rsp), %rcx
    2353:      	movl	$0x3f, %edx
    2358:      	movl	$0x2d, %eax
    235d:      	movq	0x38(%rsp), %rdx
    2362:      	movl	$0x3f, %esi
    2367:      	callq	*%rax
    2369:      	testq	%rax, %rax
    236c:      	js	0x2084 <generic_retuprobe_event+0x2084>
    2372:      	movq	0x8(%rsp), %r14
    2377:      	leaq	0x8(%r14), %rdx
    237b:      	leaq	0x78(%rsp), %rdi
    2380:      	movl	$0x8, %ecx
    2385:      	movl	$0x4, %eax
    238a:      	movl	$0x8, %esi
    238f:      	callq	*%rax
    2391:      	movq	(%rsp), %rdi
    2395:      	addq	$0xa4, %rdi
    239c:      	movl	$0x348, %edx            # imm = 0x348
    23a1:      	movq	0x78(%rsp), %rcx
    23a6:      	addq	%rdx, %rcx
    23a9:      	movl	$0x8, %esi
    23ae:      	movl	$0x4, %eax
    23b3:      	addq	0x78(%rsp), %rdx
    23b8:      	movl	$0x8, %esi
    23bd:      	callq	*%rax
    23bf:      	leaq	0x58(%r14), %rdx
    23c3:      	leaq	0x78(%rsp), %rdi
    23c8:      	movl	$0x4, %ecx
    23cd:      	movl	$0x4, %eax
    23d2:      	movl	$0x4, %esi
    23d7:      	callq	*%rax
    23d9:      	movl	$0x50, %r13d
    23df:      	testq	%rax, %rax
    23e2:      	jne	0x2087 <generic_retuprobe_event+0x2087>
    23e8:      	xorl	%eax, %eax
    23ea:      	cmpl	$0x0, 0x78(%rsp)
    23ef:      	setne	%al
    23f2:      	movq	0x30(%rsp), %rcx
    23f7:      	movl	%eax, (%rcx)
    23f9:      	jmp	0x2087 <generic_retuprobe_event+0x2087>
    23fe:      	xorl	%r13d, %r13d
    2401:      	movq	(%rsp), %rcx
    2405:      	movq	0x8(%rsp), %r8
    240a:      	jmp	0x2e6b <generic_retuprobe_event+0x2e6b>
    240f:      	movq	0x10(%rsp), %rax
    2414:      	movl	$0xfffffffe, 0x9c(%rax) # imm = 0xFFFFFFFE
    241e:      	jmp	0x2435 <generic_retuprobe_event+0x2435>
    2420:      	movq	0x10(%rsp), %rax
    2425:      	movl	$0xfffffffe, 0x9c(%rax) # imm = 0xFFFFFFFE
    242f:      	movl	$0x4, %r13d
    2435:      	movq	(%rsp), %rcx
    2439:      	movq	0x20(%rsp), %r15
    243e:      	jmp	0x2e5b <generic_retuprobe_event+0x2e5b>
    2443:      	addq	$0x3, %r12
    2447:      	movl	$0x6b, %ecx
    244c:      	movl	$0x71, %eax
    2451:      	movl	$0x6b, %esi
    2456:      	movq	%r12, %rdx
    2459:      	callq	*%rax
    245b:      	movq	%rax, %rcx
    245e:      	movb	$0x6b, %al
    2460:      	testl	%ecx, %ecx
    2462:      	js	0x246e <generic_retuprobe_event+0x246e>
    2464:      	movq	(%rsp), %rcx
    2468:      	movb	%al, 0x9f(%rcx)
    246e:      	movl	$0x70, %r13d
    2474:      	jmp	0x2e57 <generic_retuprobe_event+0x2e57>
    2479:      	leaq	0x48(%r13), %rdx
    247d:      	movl	$0x10, %ecx
    2482:      	movl	$0x4, %eax
    2487:      	movq	0x30(%rsp), %rdi
    248c:      	movl	$0x10, %esi
    2491:      	callq	*%rax
    2493:      	leaq	0x38(%r13), %rdx
    2497:      	movl	$0x10, %ecx
    249c:      	movl	$0x4, %eax
    24a1:      	movq	%r14, %rdi
    24a4:      	movl	$0x10, %esi
    24a9:      	callq	*%rax
    24ab:      	movq	(%rsp), %r12
    24af:      	leaq	0xbc(%r12), %rdi
    24b7:      	leaq	0xc(%r13), %r14
    24bb:      	addq	$0xe, %r13
    24bf:      	movl	$0x2, %ecx
    24c4:      	movl	$0x4, %eax
    24c9:      	movl	$0x2, %esi
    24ce:      	movq	%r13, %rdx
    24d1:      	callq	*%rax
    24d3:      	movq	%r12, %rdi
    24d6:      	addq	$0xbe, %rdi
    24dd:      	movl	$0x2, %ecx
    24e2:      	movl	$0x4, %eax
    24e7:      	movl	$0x2, %esi
    24ec:      	movq	%r14, %rdx
    24ef:      	callq	*%rax
    24f1:      	movzwl	0xbe(%r12), %eax
    24fa:      	movbew	%ax, 0xbe(%r12)
    2505:      	movq	(%rsp), %rax
    2509:      	movq	0xc4(%rax), %rax
    2510:      	movq	%rax, 0x38(%rsp)
    2515:      	movq	(%rip), %rdi            # 0x251c <generic_retuprobe_event+0x251c>
    251c:      	leaq	0x38(%rsp), %rsi
    2521:      	movl	$0x1, %eax
    2526:      	callq	*%rax
    2528:      	testq	%rax, %rax
    252b:      	je	0x254a <generic_retuprobe_event+0x254a>
    252d:      	movl	(%rax), %ecx
    252f:      	movq	0x10(%rsp), %r12
    2534:      	movl	%ecx, 0x10(%r12)
    2539:      	movq	0x8(%rax), %rcx
    253d:      	movq	%rcx, 0x18(%r12)
    2542:      	movl	0x4(%rax), %eax
    2545:      	movl	%eax, 0x7c(%r12)
    254a:      	movl	$0x40, %r13d
    2550:      	movq	%rbp, %r12
    2553:      	movq	0x8(%rsp), %r8
    2558:      	movq	0x88(%rsp), %rbp
    2560:      	movq	(%rsp), %rcx
    2564:      	movq	0x20(%rsp), %r15
    2569:      	jmp	0x2e6b <generic_retuprobe_event+0x2e6b>
    256e:      	cmpl	$0x33, %eax
    2571:      	je	0x268b <generic_retuprobe_event+0x268b>
    2577:      	cmpl	$0x3c, %eax
    257a:      	je	0x2597 <generic_retuprobe_event+0x2597>
    257c:      	cmpl	$0xff, %eax
    2581:      	jne	0x274e <generic_retuprobe_event+0x274e>
    2587:      	movw	$0x28, 0x2(%r13)
    258e:      	movw	$0x28, %ax
    2592:      	jmp	0x269c <generic_retuprobe_event+0x269c>
    2597:      	movzbl	0x7(%r13), %eax
    259c:      	leal	0x8(,%rax,8), %eax
    25a3:      	jmp	0x2697 <generic_retuprobe_event+0x2697>
    25a8:      	xorl	%eax, %eax
    25aa:      	movq	%rax, 0x8(%rsp)
    25af:      	cmpq	$0x3, 0xb8(%rsp)
    25b8:      	jne	0x25d1 <generic_retuprobe_event+0x25d1>
    25ba:      	movq	%r13, %rbp
    25bd:      	movq	0x10(%rsp), %rbx
    25c2:      	movq	0x28(%rsp), %rax
    25c7:      	movq	0x20(%rsp), %r15
    25cc:      	jmp	0x31a <generic_retuprobe_event+0x31a>
    25d1:      	movq	0x88(%rsp), %rax
    25d9:      	leaq	0x30(%rax), %rdx
    25dd:      	leaq	0x38(%rsp), %rdi
    25e2:      	movl	$0x4, %r12d
    25e8:      	movl	$0x10, %ecx
    25ed:      	movl	$0x4, %eax
    25f2:      	movl	$0x10, %esi
    25f7:      	callq	*%rax
    25f9:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    25fe:      	testl	%eax, %eax
    2600:      	js	0x3372 <generic_retuprobe_event+0x3372>
    2606:      	movq	0x40(%rsp), %rdx
    260b:      	movq	0x8(%rsp), %rax
    2610:      	cmpq	%rax, %rdx
    2613:      	movq	%rax, %rbx
    2616:      	cmovbq	%rdx, %rbx
    261a:      	testq	%rax, %rax
    261d:      	cmovneq	%rbx, %rdx
    2621:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2626:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    262d:      	ja	0x3372 <generic_retuprobe_event+0x3372>
    2633:      	movq	%rdx, %r14
    2636:      	movq	%r15, %rdi
    2639:      	addq	(%rsp), %rdi
    263d:      	movq	%rdi, %r15
    2640:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2646:      	addq	0x20(%rsp), %rdi
    264b:      	movq	0x38(%rsp), %rcx
    2650:      	movl	$0x4, %eax
    2655:      	movq	%rdx, %rsi
    2658:      	movq	0x38(%rsp), %rdx
    265d:      	callq	*%rax
    265f:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2664:      	testl	%eax, %eax
    2666:      	js	0x3372 <generic_retuprobe_event+0x3372>
    266c:      	addq	%r14, %r13
    266f:      	cmpq	$0x0, 0x8(%rsp)
    2675:      	je	0x29ad <generic_retuprobe_event+0x29ad>
    267b:      	subq	%rbx, 0x8(%rsp)
    2680:      	jne	0x29b4 <generic_retuprobe_event+0x29b4>
    2686:      	jmp	0x25ba <generic_retuprobe_event+0x25ba>
    268b:      	movzbl	0x7(%r13), %eax
    2690:      	leal	0x8(,%rax,4), %eax
    2697:      	movw	%ax, 0x2(%r13)
    269c:      	addw	(%r13), %ax
    26a1:      	movw	%ax, (%r13)
    26a6:      	movzbl	0x6(%r13), %ecx
    26ab:      	cmpq	$0x3c, %rcx
    26af:      	ja	0x31fa <generic_retuprobe_event+0x31fa>
    26b5:      	movabsq	$0x1008180000000001, %r12 # imm = 0x1008180000000001
    26bf:      	btq	%rcx, %r12
    26c3:      	jae	0x31fa <generic_retuprobe_event+0x31fa>
    26c9:      	movb	%cl, 0x5(%r13)
    26cd:      	movzwl	%ax, %ecx
    26d0:      	addq	%r14, %rcx
    26d3:      	movl	$0x2, %edx
    26d8:      	movl	$0x4, %eax
    26dd:      	movzwl	(%r13), %edx
    26e2:      	addq	%r14, %rdx
    26e5:      	movq	%rbx, %rdi
    26e8:      	movl	$0x2, %esi
    26ed:      	callq	*%rax
    26ef:      	testq	%rax, %rax
    26f2:      	js	0x2c60 <generic_retuprobe_event+0x2c60>
    26f8:      	movzbl	0x5(%r13), %eax
    26fd:      	cmpl	$0x32, %eax
    2700:      	jg	0x271d <generic_retuprobe_event+0x271d>
    2702:      	testl	%eax, %eax
    2704:      	je	0x273b <generic_retuprobe_event+0x273b>
    2706:      	cmpl	$0x2b, %eax
    2709:      	je	0x273b <generic_retuprobe_event+0x273b>
    270b:      	cmpl	$0x2c, %eax
    270e:      	jne	0x276b <generic_retuprobe_event+0x276b>
    2710:      	movw	$0x8, 0x2(%r13)
    2717:      	movw	$0x8, %ax
    271b:      	jmp	0x2770 <generic_retuprobe_event+0x2770>
    271d:      	cmpl	$0x33, %eax
    2720:      	je	0x2758 <generic_retuprobe_event+0x2758>
    2722:      	cmpl	$0x3c, %eax
    2725:      	je	0x273b <generic_retuprobe_event+0x273b>
    2727:      	cmpl	$0xff, %eax
    272c:      	jne	0x276b <generic_retuprobe_event+0x276b>
    272e:      	movw	$0x28, 0x2(%r13)
    2735:      	movw	$0x28, %ax
    2739:      	jmp	0x2770 <generic_retuprobe_event+0x2770>
    273b:      	movzbl	0x7(%r13), %eax
    2740:      	leal	0x8(,%rax,8), %eax
    2747:      	movw	%ax, 0x2(%r13)
    274c:      	jmp	0x2770 <generic_retuprobe_event+0x2770>
    274e:      	movzwl	0x2(%r13), %eax
    2753:      	jmp	0x269c <generic_retuprobe_event+0x269c>
    2758:      	movzbl	0x7(%r13), %eax
    275d:      	leal	0x8(,%rax,4), %eax
    2764:      	movw	%ax, 0x2(%r13)
    2769:      	jmp	0x2770 <generic_retuprobe_event+0x2770>
    276b:      	movzwl	0x2(%r13), %eax
    2770:      	addw	(%r13), %ax
    2775:      	movw	%ax, (%r13)
    277a:      	movzbl	0x6(%r13), %ecx
    277f:      	cmpq	$0x3c, %rcx
    2783:      	ja	0x31fa <generic_retuprobe_event+0x31fa>
    2789:      	btq	%rcx, %r12
    278d:      	jae	0x31fa <generic_retuprobe_event+0x31fa>
    2793:      	movb	%cl, 0x5(%r13)
    2797:      	movzwl	%ax, %ecx
    279a:      	addq	%r14, %rcx
    279d:      	movl	$0x2, %edx
    27a2:      	movl	$0x4, %eax
    27a7:      	movzwl	(%r13), %edx
    27ac:      	addq	%r14, %rdx
    27af:      	movq	%rbx, %rdi
    27b2:      	movl	$0x2, %esi
    27b7:      	callq	*%rax
    27b9:      	testq	%rax, %rax
    27bc:      	js	0x2c60 <generic_retuprobe_event+0x2c60>
    27c2:      	movzbl	0x5(%r13), %eax
    27c7:      	cmpl	$0x32, %eax
    27ca:      	jg	0x27e7 <generic_retuprobe_event+0x27e7>
    27cc:      	testl	%eax, %eax
    27ce:      	je	0x2805 <generic_retuprobe_event+0x2805>
    27d0:      	cmpl	$0x2b, %eax
    27d3:      	je	0x2805 <generic_retuprobe_event+0x2805>
    27d5:      	cmpl	$0x2c, %eax
    27d8:      	jne	0x282b <generic_retuprobe_event+0x282b>
    27da:      	movw	$0x8, 0x2(%r13)
    27e1:      	movw	$0x8, %ax
    27e5:      	jmp	0x2830 <generic_retuprobe_event+0x2830>
    27e7:      	cmpl	$0x33, %eax
    27ea:      	je	0x2818 <generic_retuprobe_event+0x2818>
    27ec:      	cmpl	$0x3c, %eax
    27ef:      	je	0x2805 <generic_retuprobe_event+0x2805>
    27f1:      	cmpl	$0xff, %eax
    27f6:      	jne	0x282b <generic_retuprobe_event+0x282b>
    27f8:      	movw	$0x28, 0x2(%r13)
    27ff:      	movw	$0x28, %ax
    2803:      	jmp	0x2830 <generic_retuprobe_event+0x2830>
    2805:      	movzbl	0x7(%r13), %eax
    280a:      	leal	0x8(,%rax,8), %eax
    2811:      	movw	%ax, 0x2(%r13)
    2816:      	jmp	0x2830 <generic_retuprobe_event+0x2830>
    2818:      	movzbl	0x7(%r13), %eax
    281d:      	leal	0x8(,%rax,4), %eax
    2824:      	movw	%ax, 0x2(%r13)
    2829:      	jmp	0x2830 <generic_retuprobe_event+0x2830>
    282b:      	movzwl	0x2(%r13), %eax
    2830:      	addw	(%r13), %ax
    2835:      	movw	%ax, (%r13)
    283a:      	movzbl	0x6(%r13), %ecx
    283f:      	cmpq	$0x3c, %rcx
    2843:      	ja	0x31fa <generic_retuprobe_event+0x31fa>
    2849:      	btq	%rcx, %r12
    284d:      	jae	0x31fa <generic_retuprobe_event+0x31fa>
    2853:      	movb	%cl, 0x5(%r13)
    2857:      	movzwl	%ax, %ecx
    285a:      	addq	%r14, %rcx
    285d:      	movl	$0x2, %edx
    2862:      	movl	$0x4, %eax
    2867:      	movzwl	(%r13), %edx
    286c:      	addq	%r14, %rdx
    286f:      	movq	%rbx, %rdi
    2872:      	movl	$0x2, %esi
    2877:      	callq	*%rax
    2879:      	testq	%rax, %rax
    287c:      	js	0x2c60 <generic_retuprobe_event+0x2c60>
    2882:      	movzbl	0x5(%r13), %eax
    2887:      	cmpl	$0x32, %eax
    288a:      	jg	0x28a7 <generic_retuprobe_event+0x28a7>
    288c:      	testl	%eax, %eax
    288e:      	je	0x28c5 <generic_retuprobe_event+0x28c5>
    2890:      	cmpl	$0x2b, %eax
    2893:      	je	0x28c5 <generic_retuprobe_event+0x28c5>
    2895:      	cmpl	$0x2c, %eax
    2898:      	jne	0x28eb <generic_retuprobe_event+0x28eb>
    289a:      	movw	$0x8, 0x2(%r13)
    28a1:      	movw	$0x8, %ax
    28a5:      	jmp	0x28f0 <generic_retuprobe_event+0x28f0>
    28a7:      	cmpl	$0x33, %eax
    28aa:      	je	0x28d8 <generic_retuprobe_event+0x28d8>
    28ac:      	cmpl	$0x3c, %eax
    28af:      	je	0x28c5 <generic_retuprobe_event+0x28c5>
    28b1:      	cmpl	$0xff, %eax
    28b6:      	jne	0x28eb <generic_retuprobe_event+0x28eb>
    28b8:      	movw	$0x28, 0x2(%r13)
    28bf:      	movw	$0x28, %ax
    28c3:      	jmp	0x28f0 <generic_retuprobe_event+0x28f0>
    28c5:      	movzbl	0x7(%r13), %eax
    28ca:      	leal	0x8(,%rax,8), %eax
    28d1:      	movw	%ax, 0x2(%r13)
    28d6:      	jmp	0x28f0 <generic_retuprobe_event+0x28f0>
    28d8:      	movzbl	0x7(%r13), %eax
    28dd:      	leal	0x8(,%rax,4), %eax
    28e4:      	movw	%ax, 0x2(%r13)
    28e9:      	jmp	0x28f0 <generic_retuprobe_event+0x28f0>
    28eb:      	movzwl	0x2(%r13), %eax
    28f0:      	addw	(%r13), %ax
    28f5:      	movw	%ax, (%r13)
    28fa:      	movzbl	0x6(%r13), %ecx
    28ff:      	cmpq	$0x3c, %rcx
    2903:      	ja	0x31fa <generic_retuprobe_event+0x31fa>
    2909:      	btq	%rcx, %r12
    290d:      	jae	0x31fa <generic_retuprobe_event+0x31fa>
    2913:      	movb	%cl, 0x5(%r13)
    2917:      	movzwl	%ax, %ecx
    291a:      	addq	%r14, %rcx
    291d:      	movl	$0x2, %edx
    2922:      	movl	$0x4, %eax
    2927:      	movzwl	(%r13), %edx
    292c:      	addq	%r14, %rdx
    292f:      	movq	%rbx, %rdi
    2932:      	movl	$0x2, %esi
    2937:      	callq	*%rax
    2939:      	testq	%rax, %rax
    293c:      	js	0x2c60 <generic_retuprobe_event+0x2c60>
    2942:      	movzbl	0x5(%r13), %eax
    2947:      	cmpl	$0x32, %eax
    294a:      	jg	0x296e <generic_retuprobe_event+0x296e>
    294c:      	testl	%eax, %eax
    294e:      	je	0x2997 <generic_retuprobe_event+0x2997>
    2950:      	cmpl	$0x2b, %eax
    2953:      	je	0x2997 <generic_retuprobe_event+0x2997>
    2955:      	cmpl	$0x2c, %eax
    2958:      	jne	0x2a92 <generic_retuprobe_event+0x2a92>
    295e:      	movw	$0x8, 0x2(%r13)
    2965:      	movw	$0x8, %ax
    2969:      	jmp	0x2a97 <generic_retuprobe_event+0x2a97>
    296e:      	cmpl	$0x33, %eax
    2971:      	je	0x2a7f <generic_retuprobe_event+0x2a7f>
    2977:      	cmpl	$0x3c, %eax
    297a:      	je	0x2997 <generic_retuprobe_event+0x2997>
    297c:      	cmpl	$0xff, %eax
    2981:      	jne	0x2a92 <generic_retuprobe_event+0x2a92>
    2987:      	movw	$0x28, 0x2(%r13)
    298e:      	movw	$0x28, %ax
    2992:      	jmp	0x2a97 <generic_retuprobe_event+0x2a97>
    2997:      	movzbl	0x7(%r13), %eax
    299c:      	leal	0x8(,%rax,8), %eax
    29a3:      	movw	%ax, 0x2(%r13)
    29a8:      	jmp	0x2a97 <generic_retuprobe_event+0x2a97>
    29ad:      	xorl	%eax, %eax
    29af:      	movq	%rax, 0x8(%rsp)
    29b4:      	cmpq	$0x5, 0xb8(%rsp)
    29bd:      	jb	0x25ba <generic_retuprobe_event+0x25ba>
    29c3:      	movq	0x88(%rsp), %rax
    29cb:      	leaq	0x40(%rax), %rdx
    29cf:      	leaq	0x38(%rsp), %rdi
    29d4:      	movl	$0x4, %r12d
    29da:      	movl	$0x10, %ecx
    29df:      	movl	$0x4, %eax
    29e4:      	movl	$0x10, %esi
    29e9:      	callq	*%rax
    29eb:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    29f0:      	testl	%eax, %eax
    29f2:      	js	0x3372 <generic_retuprobe_event+0x3372>
    29f8:      	movq	0x40(%rsp), %rdx
    29fd:      	movq	0x8(%rsp), %rax
    2a02:      	cmpq	%rax, %rdx
    2a05:      	movq	%rax, %rbx
    2a08:      	cmovbq	%rdx, %rbx
    2a0c:      	testq	%rax, %rax
    2a0f:      	cmovneq	%rbx, %rdx
    2a13:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2a18:      	movq	%rdx, (%rsp)
    2a1c:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    2a23:      	ja	0x3372 <generic_retuprobe_event+0x3372>
    2a29:      	movq	%r14, %rdi
    2a2c:      	addq	%r15, %rdi
    2a2f:      	movq	%rdi, %r14
    2a32:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2a38:      	addq	0x20(%rsp), %rdi
    2a3d:      	movq	0x38(%rsp), %rcx
    2a42:      	movl	$0x4, %eax
    2a47:      	movq	(%rsp), %rsi
    2a4b:      	movq	0x38(%rsp), %rdx
    2a50:      	callq	*%rax
    2a52:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2a57:      	testl	%eax, %eax
    2a59:      	js	0x3372 <generic_retuprobe_event+0x3372>
    2a5f:      	addq	(%rsp), %r13
    2a63:      	cmpq	$0x0, 0x8(%rsp)
    2a69:      	je	0x3207 <generic_retuprobe_event+0x3207>
    2a6f:      	subq	%rbx, 0x8(%rsp)
    2a74:      	jne	0x320e <generic_retuprobe_event+0x320e>
    2a7a:      	jmp	0x25ba <generic_retuprobe_event+0x25ba>
    2a7f:      	movzbl	0x7(%r13), %eax
    2a84:      	leal	0x8(,%rax,4), %eax
    2a8b:      	movw	%ax, 0x2(%r13)
    2a90:      	jmp	0x2a97 <generic_retuprobe_event+0x2a97>
    2a92:      	movzwl	0x2(%r13), %eax
    2a97:      	addw	(%r13), %ax
    2a9c:      	movw	%ax, (%r13)
    2aa1:      	movzbl	0x6(%r13), %ecx
    2aa6:      	cmpq	$0x3c, %rcx
    2aaa:      	ja	0x31fa <generic_retuprobe_event+0x31fa>
    2ab0:      	btq	%rcx, %r12
    2ab4:      	jae	0x31fa <generic_retuprobe_event+0x31fa>
    2aba:      	movb	%cl, 0x5(%r13)
    2abe:      	movzwl	%ax, %ecx
    2ac1:      	addq	%r14, %rcx
    2ac4:      	movl	$0x2, %edx
    2ac9:      	movl	$0x4, %eax
    2ace:      	movzwl	(%r13), %edx
    2ad3:      	addq	%r14, %rdx
    2ad6:      	movq	%rbx, %rdi
    2ad9:      	movl	$0x2, %esi
    2ade:      	callq	*%rax
    2ae0:      	testq	%rax, %rax
    2ae3:      	js	0x2c60 <generic_retuprobe_event+0x2c60>
    2ae9:      	movzbl	0x5(%r13), %eax
    2aee:      	cmpl	$0x32, %eax
    2af1:      	jg	0x2b0e <generic_retuprobe_event+0x2b0e>
    2af3:      	testl	%eax, %eax
    2af5:      	je	0x2b2c <generic_retuprobe_event+0x2b2c>
    2af7:      	cmpl	$0x2b, %eax
    2afa:      	je	0x2b2c <generic_retuprobe_event+0x2b2c>
    2afc:      	cmpl	$0x2c, %eax
    2aff:      	jne	0x2b52 <generic_retuprobe_event+0x2b52>
    2b01:      	movw	$0x8, 0x2(%r13)
    2b08:      	movw	$0x8, %ax
    2b0c:      	jmp	0x2b57 <generic_retuprobe_event+0x2b57>
    2b0e:      	cmpl	$0x33, %eax
    2b11:      	je	0x2b3f <generic_retuprobe_event+0x2b3f>
    2b13:      	cmpl	$0x3c, %eax
    2b16:      	je	0x2b2c <generic_retuprobe_event+0x2b2c>
    2b18:      	cmpl	$0xff, %eax
    2b1d:      	jne	0x2b52 <generic_retuprobe_event+0x2b52>
    2b1f:      	movw	$0x28, 0x2(%r13)
    2b26:      	movw	$0x28, %ax
    2b2a:      	jmp	0x2b57 <generic_retuprobe_event+0x2b57>
    2b2c:      	movzbl	0x7(%r13), %eax
    2b31:      	leal	0x8(,%rax,8), %eax
    2b38:      	movw	%ax, 0x2(%r13)
    2b3d:      	jmp	0x2b57 <generic_retuprobe_event+0x2b57>
    2b3f:      	movzbl	0x7(%r13), %eax
    2b44:      	leal	0x8(,%rax,4), %eax
    2b4b:      	movw	%ax, 0x2(%r13)
    2b50:      	jmp	0x2b57 <generic_retuprobe_event+0x2b57>
    2b52:      	movzwl	0x2(%r13), %eax
    2b57:      	addw	(%r13), %ax
    2b5c:      	movw	%ax, (%r13)
    2b61:      	movzbl	0x6(%r13), %ecx
    2b66:      	cmpq	$0x3c, %rcx
    2b6a:      	ja	0x31fa <generic_retuprobe_event+0x31fa>
    2b70:      	btq	%rcx, %r12
    2b74:      	jae	0x31fa <generic_retuprobe_event+0x31fa>
    2b7a:      	movb	%cl, 0x5(%r13)
    2b7e:      	movzwl	%ax, %ecx
    2b81:      	addq	%r14, %rcx
    2b84:      	movl	$0x2, %edx
    2b89:      	movl	$0x4, %eax
    2b8e:      	movzwl	(%r13), %edx
    2b93:      	addq	%r14, %rdx
    2b96:      	movq	%rbx, %rdi
    2b99:      	movl	$0x2, %esi
    2b9e:      	callq	*%rax
    2ba0:      	testq	%rax, %rax
    2ba3:      	js	0x2c60 <generic_retuprobe_event+0x2c60>
    2ba9:      	movzbl	0x5(%r13), %eax
    2bae:      	cmpl	$0x32, %eax
    2bb1:      	jg	0x2bce <generic_retuprobe_event+0x2bce>
    2bb3:      	testl	%eax, %eax
    2bb5:      	je	0x2bec <generic_retuprobe_event+0x2bec>
    2bb7:      	cmpl	$0x2b, %eax
    2bba:      	je	0x2bec <generic_retuprobe_event+0x2bec>
    2bbc:      	cmpl	$0x2c, %eax
    2bbf:      	jne	0x2c12 <generic_retuprobe_event+0x2c12>
    2bc1:      	movw	$0x8, 0x2(%r13)
    2bc8:      	movw	$0x8, %ax
    2bcc:      	jmp	0x2c17 <generic_retuprobe_event+0x2c17>
    2bce:      	cmpl	$0x33, %eax
    2bd1:      	je	0x2bff <generic_retuprobe_event+0x2bff>
    2bd3:      	cmpl	$0x3c, %eax
    2bd6:      	je	0x2bec <generic_retuprobe_event+0x2bec>
    2bd8:      	cmpl	$0xff, %eax
    2bdd:      	jne	0x2c12 <generic_retuprobe_event+0x2c12>
    2bdf:      	movw	$0x28, 0x2(%r13)
    2be6:      	movw	$0x28, %ax
    2bea:      	jmp	0x2c17 <generic_retuprobe_event+0x2c17>
    2bec:      	movzbl	0x7(%r13), %eax
    2bf1:      	leal	0x8(,%rax,8), %eax
    2bf8:      	movw	%ax, 0x2(%r13)
    2bfd:      	jmp	0x2c17 <generic_retuprobe_event+0x2c17>
    2bff:      	movzbl	0x7(%r13), %eax
    2c04:      	leal	0x8(,%rax,4), %eax
    2c0b:      	movw	%ax, 0x2(%r13)
    2c10:      	jmp	0x2c17 <generic_retuprobe_event+0x2c17>
    2c12:      	movzwl	0x2(%r13), %eax
    2c17:      	addw	(%r13), %ax
    2c1c:      	movw	%ax, (%r13)
    2c21:      	movzbl	0x6(%r13), %ecx
    2c26:      	cmpq	$0x3c, %rcx
    2c2a:      	ja	0x31fa <generic_retuprobe_event+0x31fa>
    2c30:      	btq	%rcx, %r12
    2c34:      	jae	0x31fa <generic_retuprobe_event+0x31fa>
    2c3a:      	movb	%cl, 0x5(%r13)
    2c3e:      	movzwl	%ax, %ecx
    2c41:      	addq	%r14, %rcx
    2c44:      	movl	$0x2, %edx
    2c49:      	movl	$0x4, %eax
    2c4e:      	movzwl	(%r13), %edx
    2c53:      	addq	%r14, %rdx
    2c56:      	movq	%rbx, %rdi
    2c59:      	movl	$0x2, %esi
    2c5e:      	callq	*%rax
    2c60:      	xorl	%ecx, %ecx
    2c62:      	movb	%cl, 0xd0(%rsp)
    2c69:      	movzbl	%cl, %eax
    2c6c:      	movq	(%rsp), %rbx
    2c70:      	movw	%ax, 0xc0(%rbx)
    2c77:      	movw	$0xa, 0xc2(%rbx)
    2c80:      	movq	0xe8(%rsp), %r14
    2c88:      	leaq	0x8(%r14), %rdx
    2c8c:      	movl	$0x10, %ecx
    2c91:      	movl	$0x4, %eax
    2c96:      	movq	0x30(%rsp), %rdi
    2c9b:      	movl	$0x10, %esi
    2ca0:      	callq	*%rax
    2ca2:      	leaq	0xac(%rbx), %rdi
    2ca9:      	addq	$0x18, %r14
    2cad:      	movl	$0x10, %ecx
    2cb2:      	movl	$0x4, %eax
    2cb7:      	movl	$0x10, %esi
    2cbc:      	movq	%r14, %rdx
    2cbf:      	callq	*%rax
    2cc1:      	movzbl	0xd0(%rsp), %eax
    2cc9:      	cmpl	$0x11, %eax
    2ccc:      	je	0x2d20 <generic_retuprobe_event+0x2d20>
    2cce:      	cmpl	$0x6, %eax
    2cd1:      	jne	0x2d70 <generic_retuprobe_event+0x2d70>
    2cd7:      	movq	0x38(%rsp), %r14
    2cdc:      	movzwl	0xd8(%rsp), %r12d
    2ce5:      	leaq	(%r14,%r12), %rdx
    2ce9:      	movq	(%rsp), %r13
    2ced:      	leaq	0xbc(%r13), %rdi
    2cf4:      	movl	$0x2, %ecx
    2cf9:      	movl	$0x4, %eax
    2cfe:      	movl	$0x2, %esi
    2d03:      	callq	*%rax
    2d05:      	leaq	0xbe(%r13), %rdi
    2d0c:      	leaq	(%r14,%r12), %rdx
    2d10:      	addq	$0x2, %rdx
    2d14:      	movl	$0x2, %ecx
    2d19:      	movl	$0x4, %eax
    2d1e:      	jmp	0x2d67 <generic_retuprobe_event+0x2d67>
    2d20:      	movq	0x38(%rsp), %r14
    2d25:      	movzwl	0xd8(%rsp), %r12d
    2d2e:      	leaq	(%r14,%r12), %rdx
    2d32:      	movq	(%rsp), %r13
    2d36:      	leaq	0xbc(%r13), %rdi
    2d3d:      	movl	$0x2, %ecx
    2d42:      	movl	$0x4, %eax
    2d47:      	movl	$0x2, %esi
    2d4c:      	callq	*%rax
    2d4e:      	leaq	0xbe(%r13), %rdi
    2d55:      	leaq	(%r14,%r12), %rdx
    2d59:      	addq	$0x2, %rdx
    2d5d:      	movl	$0x2, %ecx
    2d62:      	movl	$0x4, %eax
    2d67:      	movl	$0x2, %esi
    2d6c:      	callq	*%rax
    2d6e:      	jmp	0x2d7f <generic_retuprobe_event+0x2d7f>
    2d70:      	movq	(%rsp), %r13
    2d74:      	movl	$0x0, 0xbc(%r13)
    2d7f:      	movzwl	0xbc(%r13), %eax
    2d87:      	movzwl	0xbe(%r13), %ecx
    2d8f:      	movbew	%ax, 0xbc(%r13)
    2d99:      	movbew	%cx, 0xbe(%r13)
    2da3:      	movq	0xa0(%rsp), %rdx
    2dab:      	addq	$0xe0, %rdx
    2db2:      	leaq	0x78(%rsp), %rdi
    2db7:      	movl	$0x8, %ecx
    2dbc:      	movl	$0x4, %eax
    2dc1:      	movl	$0x4, %ebx
    2dc6:      	movl	$0x8, %esi
    2dcb:      	callq	*%rax
    2dcd:      	movq	0x78(%rsp), %rcx
    2dd2:      	testq	%rcx, %rcx
    2dd5:      	je	0x2e47 <generic_retuprobe_event+0x2e47>
    2dd7:      	addq	$0x5, %rcx
    2ddb:      	leaq	0x90(%rsp), %rdi
    2de3:      	movl	$0x8, %edx
    2de8:      	movl	$0x4, %eax
    2ded:      	movq	0x78(%rsp), %rdx
    2df2:      	addq	$0x5, %rdx
    2df6:      	movl	$0x8, %esi
    2dfb:      	callq	*%rax
    2dfd:      	movq	0x78(%rsp), %r12
    2e02:      	movq	0x90(%rsp), %r13
    2e0a:      	movq	(%rsp), %r14
    2e0e:      	leaq	0xd4(%r14), %rdi
    2e15:      	leaq	(%r12,%r13,8), %rdx
    2e19:      	addq	$0x44, %rdx
    2e1d:      	movl	$0x4, %eax
    2e22:      	movl	$0x4, %esi
    2e27:      	callq	*%rax
    2e29:      	addq	$0xd8, %r14
    2e30:      	leaq	(%r12,%r13,8), %rdx
    2e34:      	addq	$0x45, %rdx
    2e38:      	movl	$0x4, %eax
    2e3d:      	movq	%r14, %rdi
    2e40:      	movl	$0x4, %esi
    2e45:      	callq	*%rax
    2e47:      	movq	0x10(%rsp), %rbx
    2e4c:      	movq	0x20(%rsp), %r15
    2e51:      	movl	$0x40, %r13d
    2e57:      	movq	(%rsp), %rcx
    2e5b:      	movq	%rbp, %r12
    2e5e:      	movq	0x8(%rsp), %r8
    2e63:      	movq	0x88(%rsp), %rbp
    2e6b:      	testl	%r13d, %r13d
    2e6e:      	movl	0x28(%rsp), %eax
    2e72:      	js	0x2e8c <generic_retuprobe_event+0x2e8c>
    2e74:      	andl	$0x7fffffff, %r13d      # imm = 0x7FFFFFFF
    2e7b:      	addq	$0x4, %r13
    2e7f:      	movq	%r13, %r14
    2e82:      	movq	0xc8(%rsp), %r13
    2e8a:      	jmp	0x2eae <generic_retuprobe_event+0x2eae>
    2e8c:      	movl	$0xffffffff, 0x5ea0(%rcx) # imm = 0xFFFFFFFF
    2e96:      	movl	$0xffffffff, 0x98(%rcx) # imm = 0xFFFFFFFF
    2ea0:      	movq	0xc8(%rsp), %r13
    2ea8:      	movl	$0x4, %r14d
    2eae:      	addl	$0x8, %r14d
    2eb2:      	andl	$0x1fff, %r14d          # imm = 0x1FFF
    2eb9:      	addq	$0x90, %r15
    2ec0:      	cmpl	$0x3, %eax
    2ec3:      	je	0x1ae <generic_retuprobe_event+0x1ae>
    2ec9:      	cmpl	$0x2, %eax
    2ecc:      	jne	0x2f4a <generic_retuprobe_event+0x2f4a>
    2ece:      	movq	%rbx, 0x10(%rsp)
    2ed3:      	movq	%rbp, %rdx
    2ed6:      	movq	%r12, 0xa8(%rsp)
    2ede:      	movq	%r14, %rcx
    2ee1:      	movl	$0x0, (%r15,%r14)
    2ee9:      	cmpq	$0xfff, %r8             # imm = 0xFFF
    2ef0:      	movq	%r8, %rbx
    2ef3:      	movl	$0xfff, %r14d           # imm = 0xFFF
    2ef9:      	cmovbq	%r8, %r14
    2efd:      	leaq	(%r15,%rcx), %rdi
    2f01:      	addq	$0xc, %rdi
    2f05:      	movl	$0x4, %eax
    2f0a:      	leaq	0x4(%rcx), %r12
    2f0e:      	addq	%rcx, %r15
    2f11:      	addq	$0x4, %r15
    2f15:      	movl	$0x4, %ebp
    2f1a:      	movl	%r14d, %esi
    2f1d:      	callq	*%rax
    2f1f:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2f24:      	testl	%eax, %eax
    2f26:      	js	0x2f35 <generic_retuprobe_event+0x2f35>
    2f28:      	movl	%r14d, 0x4(%r15)
    2f2c:      	addq	$0x8, %r14
    2f30:      	movl	%ebx, %ecx
    2f32:      	movq	%r14, %rbp
    2f35:      	addq	%r12, %rbp
    2f38:      	movl	%ecx, (%r15)
    2f3b:      	movq	0xa8(%rsp), %r12
    2f43:      	movq	0x10(%rsp), %rbx
    2f48:      	jmp	0x2f4d <generic_retuprobe_event+0x2f4d>
    2f4a:      	movq	%r14, %rbp
    2f4d:      	movl	$0x23, %eax
    2f52:      	callq	*%rax
    2f54:      	movq	%rax, %rcx
    2f57:      	movq	%rax, 0x38(%rsp)
    2f5c:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    2f63:      	leaq	0x90(%rsp), %rdi
    2f6b:      	movl	$0x4, %edx
    2f70:      	movl	$0x71, %eax
    2f75:      	movl	$0xaf4, %edx            # imm = 0xAF4
    2f7a:      	addq	0x38(%rsp), %rdx
    2f7f:      	movl	$0x4, %esi
    2f84:      	callq	*%rax
    2f86:      	movl	0x90(%rsp), %eax
    2f8d:      	movl	%eax, 0x78(%rsp)
    2f91:      	movq	(%rip), %rdi            # 0x2f98 <generic_retuprobe_event+0x2f98>
    2f98:      	leaq	0x78(%rsp), %rsi
    2f9d:      	movl	$0x1, %eax
    2fa2:      	callq	*%rax
    2fa4:      	testq	%rax, %rax
    2fa7:      	je	0x2fb7 <generic_retuprobe_event+0x2fb7>
    2fa9:      	movq	%rax, %r15
    2fac:      	cmpq	$0x0, 0x8(%rax)
    2fb1:      	jne	0x318d <generic_retuprobe_event+0x318d>
    2fb7:      	movl	$0xb00, %edx            # imm = 0xB00
    2fbc:      	movq	0x38(%rsp), %rcx
    2fc1:      	addq	%rdx, %rcx
    2fc4:      	leaq	0x38(%rsp), %rdi
    2fc9:      	movl	$0x8, %esi
    2fce:      	movl	$0x71, %eax
    2fd3:      	addq	0x38(%rsp), %rdx
    2fd8:      	movl	$0x8, %esi
    2fdd:      	callq	*%rax
    2fdf:      	movq	0x38(%rsp), %rcx
    2fe4:      	testq	%rcx, %rcx
    2fe7:      	je	0x318a <generic_retuprobe_event+0x318a>
    2fed:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    2ff4:      	leaq	0x90(%rsp), %rdi
    2ffc:      	movl	$0x4, %edx
    3001:      	movl	$0x71, %eax
    3006:      	movl	$0xaf4, %edx            # imm = 0xAF4
    300b:      	addq	0x38(%rsp), %rdx
    3010:      	movl	$0x4, %esi
    3015:      	callq	*%rax
    3017:      	movl	0x90(%rsp), %eax
    301e:      	movl	%eax, 0x78(%rsp)
    3022:      	movq	(%rip), %rdi            # 0x3029 <generic_retuprobe_event+0x3029>
    3029:      	leaq	0x78(%rsp), %rsi
    302e:      	movl	$0x1, %eax
    3033:      	callq	*%rax
    3035:      	testq	%rax, %rax
    3038:      	je	0x3048 <generic_retuprobe_event+0x3048>
    303a:      	movq	%rax, %r15
    303d:      	cmpq	$0x0, 0x8(%rax)
    3042:      	jne	0x318d <generic_retuprobe_event+0x318d>
    3048:      	movl	$0xb00, %edx            # imm = 0xB00
    304d:      	movq	0x38(%rsp), %rcx
    3052:      	addq	%rdx, %rcx
    3055:      	leaq	0x38(%rsp), %rdi
    305a:      	movl	$0x8, %esi
    305f:      	movl	$0x71, %eax
    3064:      	addq	0x38(%rsp), %rdx
    3069:      	movl	$0x8, %esi
    306e:      	callq	*%rax
    3070:      	movq	0x38(%rsp), %rcx
    3075:      	testq	%rcx, %rcx
    3078:      	je	0x318a <generic_retuprobe_event+0x318a>
    307e:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3085:      	leaq	0x90(%rsp), %rdi
    308d:      	movl	$0x4, %edx
    3092:      	movl	$0x71, %eax
    3097:      	movl	$0xaf4, %edx            # imm = 0xAF4
    309c:      	addq	0x38(%rsp), %rdx
    30a1:      	movl	$0x4, %esi
    30a6:      	callq	*%rax
    30a8:      	movl	0x90(%rsp), %eax
    30af:      	movl	%eax, 0x78(%rsp)
    30b3:      	movq	(%rip), %rdi            # 0x30ba <generic_retuprobe_event+0x30ba>
    30ba:      	leaq	0x78(%rsp), %rsi
    30bf:      	movl	$0x1, %eax
    30c4:      	callq	*%rax
    30c6:      	testq	%rax, %rax
    30c9:      	je	0x30d9 <generic_retuprobe_event+0x30d9>
    30cb:      	movq	%rax, %r15
    30ce:      	cmpq	$0x0, 0x8(%rax)
    30d3:      	jne	0x318d <generic_retuprobe_event+0x318d>
    30d9:      	movl	$0xb00, %edx            # imm = 0xB00
    30de:      	movq	0x38(%rsp), %rcx
    30e3:      	addq	%rdx, %rcx
    30e6:      	leaq	0x38(%rsp), %rdi
    30eb:      	movl	$0x8, %esi
    30f0:      	movl	$0x71, %eax
    30f5:      	addq	0x38(%rsp), %rdx
    30fa:      	movl	$0x8, %esi
    30ff:      	callq	*%rax
    3101:      	movq	0x38(%rsp), %rcx
    3106:      	testq	%rcx, %rcx
    3109:      	je	0x318a <generic_retuprobe_event+0x318a>
    310b:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    3112:      	leaq	0x90(%rsp), %rdi
    311a:      	movl	$0x4, %edx
    311f:      	movl	$0x71, %eax
    3124:      	movl	$0xaf4, %edx            # imm = 0xAF4
    3129:      	addq	0x38(%rsp), %rdx
    312e:      	movl	$0x4, %esi
    3133:      	callq	*%rax
    3135:      	movl	0x90(%rsp), %eax
    313c:      	movl	%eax, 0x78(%rsp)
    3140:      	movq	(%rip), %rdi            # 0x3147 <generic_retuprobe_event+0x3147>
    3147:      	leaq	0x78(%rsp), %rsi
    314c:      	movl	$0x1, %eax
    3151:      	callq	*%rax
    3153:      	testq	%rax, %rax
    3156:      	je	0x3162 <generic_retuprobe_event+0x3162>
    3158:      	movq	%rax, %r15
    315b:      	cmpq	$0x0, 0x8(%rax)
    3160:      	jne	0x318d <generic_retuprobe_event+0x318d>
    3162:      	movl	$0xb00, %edx            # imm = 0xB00
    3167:      	movq	0x38(%rsp), %rcx
    316c:      	addq	%rdx, %rcx
    316f:      	leaq	0x38(%rsp), %rdi
    3174:      	movl	$0x8, %esi
    3179:      	movl	$0x71, %eax
    317e:      	addq	0x38(%rsp), %rdx
    3183:      	movl	$0x8, %esi
    3188:      	callq	*%rax
    318a:      	xorl	%r15d, %r15d
    318d:      	movl	$0x10f, (%rbx)          # imm = 0x10F
    3193:      	movl	%ebp, 0x4(%rbx)
    3196:      	movl	$0x7d, %eax
    319b:      	callq	*%rax
    319d:      	movq	%rax, 0x8(%rbx)
    31a1:      	testq	%r15, %r15
    31a4:      	je	0x31b4 <generic_retuprobe_event+0x31b4>
    31a6:      	movl	(%r15), %eax
    31a9:      	movl	%eax, 0x10(%rbx)
    31ac:      	movq	0x8(%r15), %rax
    31b0:      	movq	%rax, 0x18(%rbx)
    31b4:      	movl	$0x0, 0x14(%rbx)
    31bb:      	movl	(%r12), %eax
    31bf:      	movq	%rax, 0x60(%rbx)
    31c3:      	movl	%ebp, 0x4(%rbx)
    31c6:      	movq	(%rip), %rsi            # 0x31cd <generic_retuprobe_event+0x31cd>
    31cd:      	movl	$0x3, %ecx
    31d2:      	movl	$0xc, %eax
    31d7:      	movq	%r13, %rdi
    31da:      	movl	$0x3, %edx
    31df:      	callq	*%rax
    31e1:      	movl	$0x1, %ebp
    31e6:      	movl	%ebp, %eax
    31e8:      	addq	$0xf8, %rsp
    31ef:      	popq	%rbx
    31f0:      	popq	%r12
    31f2:      	popq	%r13
    31f4:      	popq	%r14
    31f6:      	popq	%r15
    31f8:      	popq	%rbp
    31f9:      	retq
    31fa:      	movw	%ax, 0xd8(%rsp)
    3202:      	jmp	0x2c62 <generic_retuprobe_event+0x2c62>
    3207:      	xorl	%eax, %eax
    3209:      	movq	%rax, 0x8(%rsp)
    320e:      	cmpq	$0x5, 0xb8(%rsp)
    3217:      	je	0x25ba <generic_retuprobe_event+0x25ba>
    321d:      	movq	0x88(%rsp), %rax
    3225:      	leaq	0x50(%rax), %rdx
    3229:      	leaq	0x38(%rsp), %rdi
    322e:      	movl	$0x4, %r12d
    3234:      	movl	$0x10, %ecx
    3239:      	movl	$0x4, %eax
    323e:      	movl	$0x10, %esi
    3243:      	callq	*%rax
    3245:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    324a:      	testl	%eax, %eax
    324c:      	js	0x3372 <generic_retuprobe_event+0x3372>
    3252:      	movq	0x40(%rsp), %r15
    3257:      	movq	0x8(%rsp), %rax
    325c:      	cmpq	%rax, %r15
    325f:      	movq	%rax, %rbx
    3262:      	cmovbq	%r15, %rbx
    3266:      	testq	%rax, %rax
    3269:      	cmovneq	%rbx, %r15
    326d:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    3272:      	cmpq	$0xffe, %r15            # imm = 0xFFE
    3279:      	ja	0x3372 <generic_retuprobe_event+0x3372>
    327f:      	movq	(%rsp), %rdi
    3283:      	addq	%r14, %rdi
    3286:      	movq	%rdi, %r14
    3289:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    328f:      	addq	0x20(%rsp), %rdi
    3294:      	movq	0x38(%rsp), %rcx
    3299:      	movl	$0x4, %eax
    329e:      	movq	0x38(%rsp), %rdx
    32a3:      	movl	%r15d, %esi
    32a6:      	callq	*%rax
    32a8:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    32ad:      	testl	%eax, %eax
    32af:      	js	0x3372 <generic_retuprobe_event+0x3372>
    32b5:      	addq	%r15, %r13
    32b8:      	cmpq	$0x0, 0x8(%rsp)
    32be:      	je	0x32cc <generic_retuprobe_event+0x32cc>
    32c0:      	subq	%rbx, 0x8(%rsp)
    32c5:      	jne	0x32d3 <generic_retuprobe_event+0x32d3>
    32c7:      	jmp	0x25ba <generic_retuprobe_event+0x25ba>
    32cc:      	xorl	%eax, %eax
    32ce:      	movq	%rax, 0x8(%rsp)
    32d3:      	cmpq	$0x7, 0xb8(%rsp)
    32dc:      	jb	0x25ba <generic_retuprobe_event+0x25ba>
    32e2:      	movq	0x88(%rsp), %rdx
    32ea:      	addq	$0x60, %rdx
    32ee:      	leaq	0x38(%rsp), %rdi
    32f3:      	movl	$0x4, %r12d
    32f9:      	movl	$0x10, %ecx
    32fe:      	movl	$0x4, %eax
    3303:      	movl	$0x10, %esi
    3308:      	callq	*%rax
    330a:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    330f:      	testl	%eax, %eax
    3311:      	js	0x3372 <generic_retuprobe_event+0x3372>
    3313:      	movq	0x40(%rsp), %rax
    3318:      	movq	0x8(%rsp), %rcx
    331d:      	cmpq	%rcx, %rax
    3320:      	movq	%rcx, %rbp
    3323:      	cmovbq	%rax, %rbp
    3327:      	testq	%rcx, %rcx
    332a:      	cmoveq	%rax, %rbp
    332e:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    3333:      	cmpq	$0xffe, %rbp            # imm = 0xFFE
    333a:      	ja	0x3372 <generic_retuprobe_event+0x3372>
    333c:      	addq	%r14, %r15
    333f:      	andl	$0x3fff, %r15d          # imm = 0x3FFF
    3346:      	addq	0x20(%rsp), %r15
    334b:      	movq	0x38(%rsp), %rcx
    3350:      	movl	$0x4, %eax
    3355:      	movq	0x38(%rsp), %rdx
    335a:      	movq	%r15, %rdi
    335d:      	movl	%ebp, %esi
    335f:      	callq	*%rax
    3361:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3366:      	testl	%eax, %eax
    3368:      	js	0x3372 <generic_retuprobe_event+0x3372>
    336a:      	addq	%r13, %rbp
    336d:      	jmp	0x25bd <generic_retuprobe_event+0x25bd>
    3372:      	movq	0x28(%rsp), %rax
    3377:      	movq	0x20(%rsp), %rdx
    337c:      	movl	%ecx, (%rdx,%rax)
    337f:      	movq	0x10(%rsp), %rbx
    3384:      	jmp	0xbc6 <generic_retuprobe_event+0xbc6>
