
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_generic_retkprobe_v511.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
       5:      	testq	%rdx, %rdx
       8:      	je	0x74 <native_bpf_strncasestr+0x74>
       a:      	pushq	%rbx
       b:      	xorl	%ecx, %ecx
       d:      	jmp	0x1b <native_bpf_strncasestr+0x1b>
       f:      	nop
      10:      	incq	%rcx
      13:      	incq	%rdi
      16:      	cmpq	%rdx, %rcx
      19:      	je	0x73 <native_bpf_strncasestr+0x73>
      1b:      	xorl	%r8d, %r8d
      1e:      	nop
      20:      	leaq	(%rcx,%r8), %r9
      24:      	cmpq	%rdx, %r9
      27:      	jae	0x10 <native_bpf_strncasestr+0x10>
      29:      	movsbl	(%rsi,%r8), %r9d
      2e:      	testl	%r9d, %r9d
      31:      	je	0x71 <native_bpf_strncasestr+0x71>
      33:      	movsbl	(%rdi,%r8), %r10d
      38:      	leal	-0x41(%r10), %r11d
      3c:      	movl	%r10d, %ebx
      3f:      	orl	$0x20, %ebx
      42:      	cmpl	$0x1a, %r11d
      46:      	cmovael	%r10d, %ebx
      4a:      	leal	-0x41(%r9), %r10d
      4e:      	movl	%r9d, %r11d
      51:      	orl	$0x20, %r11d
      55:      	cmpl	$0x1a, %r10d
      59:      	cmovael	%r9d, %r11d
      5d:      	cmpl	%r11d, %ebx
      60:      	jne	0x10 <native_bpf_strncasestr+0x10>
      62:      	leaq	0x1(%r8), %r9
      66:      	cmpq	$0x63, %r8
      6a:      	movq	%r9, %r8
      6d:      	jb	0x20 <native_bpf_strncasestr+0x20>
      6f:      	jmp	0x10 <native_bpf_strncasestr+0x10>
      71:      	movl	%ecx, %eax
      73:      	popq	%rbx
      74:      	retq

Disassembly of section kprobe:

0000000000000000 <generic_retkprobe_filter_arg>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xb8, %rsp
      11:      	movq	%rdi, %r13
      14:      	movl	$0x0, 0x94(%rsp)
      1f:      	movq	(%rip), %rdi            # 0x26 <generic_retkprobe_filter_arg+0x26>
      26:      	leaq	0x94(%rsp), %rsi
      2e:      	movl	$0x1, %eax
      33:      	callq	*%rax
      35:      	testq	%rax, %rax
      38:      	je	0x179 <generic_retkprobe_filter_arg+0x179>
      3e:      	movq	%rax, %r14
      41:      	movl	0x5f00(%rax), %ebx
      47:      	leaq	0x5ef8(%rax), %rsi
      4e:      	movq	(%rip), %rdi            # 0x55 <generic_retkprobe_filter_arg+0x55>
      55:      	movl	$0x1, %eax
      5a:      	callq	*%rax
      5c:      	testq	%rax, %rax
      5f:      	je	0x15e <generic_retkprobe_filter_arg+0x15e>
      65:      	cmpb	$0x0, 0x5ee0(%r14)
      6d:      	je	0x15e <generic_retkprobe_filter_arg+0x15e>
      73:      	movq	%rax, %rdi
      76:      	movl	%ebx, %eax
      78:      	andl	$0x7, %eax
      7b:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
      84:      	je	0xb8 <generic_retkprobe_filter_arg+0xb8>
      86:      	movl	%eax, %eax
      88:      	movl	0x4(%rdi,%rax,4), %ecx
      8c:      	leaq	(%rcx,%rax,4), %r11
      90:      	addq	$0x8, %r11
      94:      	movl	%r11d, %r9d
      97:      	andl	$0x3ff, %r9d            # imm = 0x3FF
      9e:      	cmpl	$0x19, (%rdi,%r9)
      a3:      	jae	0x104 <generic_retkprobe_filter_arg+0x104>
      a5:      	cmpq	$0x1, %r9
      a9:      	je	0x15e <generic_retkprobe_filter_arg+0x15e>
      af:      	testl	%r9d, %r9d
      b2:      	jne	0x13c <generic_retkprobe_filter_arg+0x13c>
      b8:      	cmpl	$0x1, %ebx
      bb:      	jg	0xd9 <generic_retkprobe_filter_arg+0xd9>
      bd:      	cmpl	$-0x1, %ebx
      c0:      	je	0x18d <generic_retkprobe_filter_arg+0x18d>
      c6:      	testl	%ebx, %ebx
      c8:      	je	0x199 <generic_retkprobe_filter_arg+0x199>
      ce:      	cmpl	$0x1, %ebx
      d1:      	je	0x1a8 <generic_retkprobe_filter_arg+0x1a8>
      d7:      	jmp	0xf4 <generic_retkprobe_filter_arg+0xf4>
      d9:      	cmpl	$0x2, %ebx
      dc:      	je	0x1b7 <generic_retkprobe_filter_arg+0x1b7>
      e2:      	cmpl	$0x3, %ebx
      e5:      	je	0x1c6 <generic_retkprobe_filter_arg+0x1c6>
      eb:      	cmpl	$0x4, %ebx
      ee:      	je	0x1d5 <generic_retkprobe_filter_arg+0x1d5>
      f4:      	cmpl	$0x4, %ebx
      f7:      	jg	0x206 <generic_retkprobe_filter_arg+0x206>
      fd:      	incl	%ebx
      ff:      	jmp	0x1e4 <generic_retkprobe_filter_arg+0x1e4>
     104:      	leaq	(%rdi,%r9), %rax
     108:      	movq	%rax, 0xa8(%rsp)
     110:      	xorl	%ecx, %ecx
     112:      	leaq	0x70(%rsp), %rax
     117:      	movq	%rax, 0x20(%rsp)
     11c:      	movq	%r13, 0x28(%rsp)
     121:      	movq	%rbx, 0xa0(%rsp)
     129:      	movq	%rdi, (%rsp)
     12d:      	movq	%r9, 0x8(%rsp)
     132:      	movq	%r11, 0x10(%rsp)
     137:      	jmp	0x286 <generic_retkprobe_filter_arg+0x286>
     13c:      	movl	%r9d, 0x5f04(%r14)
     143:      	movq	(%rip), %rsi            # 0x14a <generic_retkprobe_filter_arg+0x14a>
     14a:      	movl	$0x4, %ecx
     14f:      	movl	$0xc, %eax
     154:      	movq	%r13, %rdi
     157:      	movl	$0x4, %edx
     15c:      	callq	*%rax
     15e:      	movq	(%rip), %rsi            # 0x165 <generic_retkprobe_filter_arg+0x165>
     165:      	movl	$0x5, %ecx
     16a:      	movl	$0xc, %eax
     16f:      	movq	%r13, %rdi
     172:      	movl	$0x5, %edx
     177:      	callq	*%rax
     179:      	xorl	%eax, %eax
     17b:      	addq	$0xb8, %rsp
     182:      	popq	%rbx
     183:      	popq	%r12
     185:      	popq	%r13
     187:      	popq	%r14
     189:      	popq	%r15
     18b:      	popq	%rbp
     18c:      	retq
     18d:      	xorl	%ebx, %ebx
     18f:      	cmpb	$0x0, 0x5ec1(%r14)
     197:      	jne	0x1e4 <generic_retkprobe_filter_arg+0x1e4>
     199:      	movl	$0x1, %ebx
     19e:      	cmpb	$0x0, 0x5ec2(%r14)
     1a6:      	jne	0x1e4 <generic_retkprobe_filter_arg+0x1e4>
     1a8:      	movl	$0x2, %ebx
     1ad:      	cmpb	$0x0, 0x5ec3(%r14)
     1b5:      	jne	0x1e4 <generic_retkprobe_filter_arg+0x1e4>
     1b7:      	movl	$0x3, %ebx
     1bc:      	cmpb	$0x0, 0x5ec4(%r14)
     1c4:      	jne	0x1e4 <generic_retkprobe_filter_arg+0x1e4>
     1c6:      	movl	$0x4, %ebx
     1cb:      	cmpb	$0x0, 0x5ec5(%r14)
     1d3:      	jne	0x1e4 <generic_retkprobe_filter_arg+0x1e4>
     1d5:      	movl	$0x5, %ebx
     1da:      	cmpb	$0x0, 0x5ec6(%r14)
     1e2:      	je	0x206 <generic_retkprobe_filter_arg+0x206>
     1e4:      	movl	%ebx, 0x5f00(%r14)
     1eb:      	movq	(%rip), %rsi            # 0x1f2 <generic_retkprobe_filter_arg+0x1f2>
     1f2:      	movl	$0x3, %ecx
     1f7:      	movl	$0xc, %eax
     1fc:      	movq	%r13, %rdi
     1ff:      	movl	$0x3, %edx
     204:      	callq	*%rax
     206:      	movq	0x60(%r14), %rbx
     20a:      	movl	$0xe, %eax
     20f:      	callq	*%rax
     211:      	movq	%rbx, 0x38(%rsp)
     216:      	movq	%rax, 0x40(%rsp)
     21b:      	movq	(%rip), %rdi            # 0x222 <generic_retkprobe_filter_arg+0x222>
     222:      	leaq	0x38(%rsp), %rsi
     227:      	movl	$0x1, %eax
     22c:      	callq	*%rax
     22e:      	testq	%rax, %rax
     231:      	je	0x179 <generic_retkprobe_filter_arg+0x179>
     237:      	movq	(%rip), %rdi            # 0x23e <generic_retkprobe_filter_arg+0x23e>
     23e:      	leaq	0x38(%rsp), %rsi
     243:      	movl	$0x3, %eax
     248:      	callq	*%rax
     24a:      	jmp	0x179 <generic_retkprobe_filter_arg+0x179>
     24f:      	xorl	%ebx, %ebx
     251:      	cmpl	$0x3, %eax
     254:      	sete	%bl
     257:      	nopw	(%rax,%rax)
     260:      	testq	%rbx, %rbx
     263:      	movq	0xa0(%rsp), %rbx
     26b:      	je	0xb8 <generic_retkprobe_filter_arg+0xb8>
     271:      	movq	0xb0(%rsp), %rcx
     279:      	incq	%rcx
     27c:      	cmpq	$0x5, %rcx
     280:      	je	0xa5 <generic_retkprobe_filter_arg+0xa5>
     286:      	movq	0xa8(%rsp), %rax
     28e:      	movl	0x4(%rax,%rcx,4), %r12d
     293:      	testl	$0x3ff, %r12d           # imm = 0x3FF
     29a:      	je	0xa5 <generic_retkprobe_filter_arg+0xa5>
     2a0:      	movq	%rcx, 0xb0(%rsp)
     2a8:      	addl	%r11d, %r12d
     2ab:      	andl	$0x3ff, %r12d           # imm = 0x3FF
     2b2:      	movl	0x4(%rdi,%r12), %eax
     2b7:      	cmpl	$0x23, %eax
     2ba:      	je	0xb8 <generic_retkprobe_filter_arg+0xb8>
     2c0:      	addq	%rdi, %r12
     2c3:      	movl	(%r12), %ecx
     2c7:      	cmpq	$0x4, %rcx
     2cb:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
     2d1:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
     2da:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
     2e0:      	movq	0x5e78(%r14,%rcx,8), %rcx
     2e8:      	andl	$0x7ff, %ecx            # imm = 0x7FF
     2ee:      	leaq	(%r14,%rcx), %r15
     2f2:      	addq	$0x90, %r15
     2f9:      	movl	0xc(%r12), %ecx
     2fe:      	cmpl	$0x1b, %ecx
     301:      	jle	0x31e <generic_retkprobe_filter_arg+0x31e>
     303:      	cmpl	$0x25, %ecx
     306:      	jg	0x349 <generic_retkprobe_filter_arg+0x349>
     308:      	leal	-0x1c(%rcx), %edx
     30b:      	cmpl	$0x9, %edx
     30e:      	jb	0x38f <generic_retkprobe_filter_arg+0x38f>
     310:      	cmpl	$0x25, %ecx
     313:      	je	0x5a9 <generic_retkprobe_filter_arg+0x5a9>
     319:      	jmp	0x271 <generic_retkprobe_filter_arg+0x271>
     31e:      	cmpl	$0x9, %ecx
     321:      	jle	0x36f <generic_retkprobe_filter_arg+0x36f>
     323:      	leal	-0xa(%rcx), %edx
     326:      	cmpl	$0x4, %edx
     329:      	jb	0x38f <generic_retkprobe_filter_arg+0x38f>
     32b:      	leal	-0xf(%rcx), %edx
     32e:      	cmpl	$0x2, %edx
     331:      	jb	0x5a9 <generic_retkprobe_filter_arg+0x5a9>
     337:      	cmpl	$0x11, %ecx
     33a:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
     340:      	addq	$0x4, %r15
     344:      	jmp	0x5a9 <generic_retkprobe_filter_arg+0x5a9>
     349:      	cmpl	$0x29, %ecx
     34c:      	jg	0x513 <generic_retkprobe_filter_arg+0x513>
     352:      	leal	-0x26(%rcx), %edx
     355:      	cmpl	$0x2, %edx
     358:      	jb	0x4aa <generic_retkprobe_filter_arg+0x4aa>
     35e:      	leal	-0x28(%rcx), %edx
     361:      	cmpl	$0x2, %edx
     364:      	jb	0x455 <generic_retkprobe_filter_arg+0x455>
     36a:      	jmp	0x271 <generic_retkprobe_filter_arg+0x271>
     36f:      	cmpl	$0x4, %ecx
     372:      	jg	0x442 <generic_retkprobe_filter_arg+0x442>
     378:      	cmpl	$0x1, %ecx
     37b:      	je	0x38f <generic_retkprobe_filter_arg+0x38f>
     37d:      	cmpl	$0x2, %ecx
     380:      	je	0xb43 <generic_retkprobe_filter_arg+0xb43>
     386:      	cmpl	$0x4, %ecx
     389:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
     38f:      	cmpl	$0xb, %ecx
     392:      	jle	0x41f <generic_retkprobe_filter_arg+0x41f>
     398:      	cmpl	$0x24, %ecx
     39b:      	ja	0x6cc <generic_retkprobe_filter_arg+0x6cc>
     3a1:      	movl	%ecx, %edx
     3a3:      	movabsq	$0x1e00000000, %rsi     # imm = 0x1E00000000
     3ad:      	btq	%rdx, %rsi
     3b1:      	jb	0x4e7 <generic_retkprobe_filter_arg+0x4e7>
     3b7:      	movl	$0x60000000, %esi       # imm = 0x60000000
     3bc:      	btq	%rdx, %rsi
     3c0:      	jb	0x918 <generic_retkprobe_filter_arg+0x918>
     3c6:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
     3d0:      	btq	%rdx, %rsi
     3d4:      	jae	0x6cc <generic_retkprobe_filter_arg+0x6cc>
     3da:      	cmpl	$0x20, %eax
     3dd:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
     3e3:      	movl	%eax, %ecx
     3e5:      	movl	$0x101e, %edx           # imm = 0x101E
     3ea:      	btq	%rcx, %rdx
     3ee:      	jae	0x1001 <generic_retkprobe_filter_arg+0x1001>
     3f4:      	movl	0x10(%r12), %ecx
     3f9:      	cmpl	$0x2, %eax
     3fc:      	jle	0x15ba <generic_retkprobe_filter_arg+0x15ba>
     402:      	leal	-0x3(%rax), %edx
     405:      	cmpl	$0x2, %edx
     408:      	jae	0x1d33 <generic_retkprobe_filter_arg+0x1d33>
     40e:      	movzbl	(%r15), %edx
     412:      	cmpl	%edx, %ecx
     414:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
     41a:      	jmp	0x1e74 <generic_retkprobe_filter_arg+0x1e74>
     41f:      	leal	-0xa(%rcx), %edx
     422:      	cmpl	$0x2, %edx
     425:      	jb	0xbbf <generic_retkprobe_filter_arg+0xbbf>
     42b:      	cmpl	$0x1, %ecx
     42e:      	je	0x6d8 <generic_retkprobe_filter_arg+0x6d8>
     434:      	cmpl	$0x4, %ecx
     437:      	je	0x6d8 <generic_retkprobe_filter_arg+0x6d8>
     43d:      	jmp	0x271 <generic_retkprobe_filter_arg+0x271>
     442:      	cmpl	$0x5, %ecx
     445:      	je	0x455 <generic_retkprobe_filter_arg+0x455>
     447:      	cmpl	$0x6, %ecx
     44a:      	je	0x4aa <generic_retkprobe_filter_arg+0x4aa>
     44c:      	cmpl	$0x7, %ecx
     44f:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
     455:      	movq	$0x0, 0x58(%rsp)
     45e:      	movq	$0x0, 0x50(%rsp)
     467:      	movq	$0x0, 0x48(%rsp)
     470:      	movq	$0x0, 0x40(%rsp)
     479:      	movq	$0x0, 0x38(%rsp)
     482:      	cmpl	$0x27, %ecx
     485:      	jg	0x716 <generic_retkprobe_filter_arg+0x716>
     48b:      	cmpl	$0x5, %ecx
     48e:      	je	0xd25 <generic_retkprobe_filter_arg+0xd25>
     494:      	movq	%r15, %rdx
     497:      	movl	$0x0, %ebx
     49c:      	cmpl	$0x7, %ecx
     49f:      	je	0xd27 <generic_retkprobe_filter_arg+0xd27>
     4a5:      	jmp	0x1bc9 <generic_retkprobe_filter_arg+0x1bc9>
     4aa:      	movl	(%r15), %ebp
     4ad:      	addq	$0x4, %r15
     4b1:      	movq	%r15, 0x18(%rsp)
     4b6:      	cmpl	$0x19, %eax
     4b9:      	jg	0x79a <generic_retkprobe_filter_arg+0x79a>
     4bf:      	leal	-0x3(%rax), %ecx
     4c2:      	cmpl	$0x2, %ecx
     4c5:      	jb	0xf7d <generic_retkprobe_filter_arg+0xf7d>
     4cb:      	cmpl	$0x8, %eax
     4ce:      	je	0xee5 <generic_retkprobe_filter_arg+0xee5>
     4d4:      	movl	$0x0, %ebx
     4d9:      	cmpl	$0x9, %eax
     4dc:      	je	0x7ba <generic_retkprobe_filter_arg+0x7ba>
     4e2:      	jmp	0x3351 <generic_retkprobe_filter_arg+0x3351>
     4e7:      	cmpl	$0x9, %eax
     4ea:      	jle	0xb32 <generic_retkprobe_filter_arg+0xb32>
     4f0:      	cmpl	$0x1d, %eax
     4f3:      	jg	0xe9e <generic_retkprobe_filter_arg+0xe9e>
     4f9:      	leal	-0xa(%rax), %edx
     4fc:      	cmpl	$0x2, %edx
     4ff:      	jb	0xc4b <generic_retkprobe_filter_arg+0xc4b>
     505:      	cmpl	$0xc, %eax
     508:      	je	0xbd5 <generic_retkprobe_filter_arg+0xbd5>
     50e:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
     513:      	cmpl	$0x2a, %ecx
     516:      	je	0x5a9 <generic_retkprobe_filter_arg+0x5a9>
     51c:      	cmpl	$0x2c, %ecx
     51f:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
     525:      	movq	%r15, %rcx
     528:      	leaq	0x4(%r15), %r8
     52c:      	movzbl	0x3(%r15), %ebp
     531:      	movzbl	%bpl, %esi
     535:      	cmpl	$0x19, %eax
     538:      	jg	0x12bf <generic_retkprobe_filter_arg+0x12bf>
     53e:      	leal	-0x3(%rax), %ecx
     541:      	cmpl	$0x2, %ecx
     544:      	jae	0x18b9 <generic_retkprobe_filter_arg+0x18b9>
     54a:      	movl	$0x0, 0x70(%rsp)
     552:      	movl	$0x100, %r13d           # imm = 0x100
     558:      	cmpb	$-0x70, %bpl
     55c:      	ja	0x1589 <generic_retkprobe_filter_arg+0x1589>
     562:      	testb	%bpl, %bpl
     565:      	je	0x578 <generic_retkprobe_filter_arg+0x578>
     567:      	movl	%esi, %eax
     569:      	movl	$0x18, %ecx
     56e:      	cltd
     56f:      	idivl	%ecx
     571:      	movl	%esi, %r13d
     574:      	testl	%edx, %edx
     576:      	je	0x59c <generic_retkprobe_filter_arg+0x59c>
     578:      	movl	%esi, %eax
     57a:      	movl	$0x18, %ecx
     57f:      	cltd
     580:      	idivl	%ecx
     582:      	shll	$0x3, %eax
     585:      	leal	(%rax,%rax,2), %eax
     588:      	addl	$0x18, %eax
     58b:      	movzwl	%ax, %r13d
     58f:      	cmpl	$0x90, %r13d
     596:      	ja	0x1589 <generic_retkprobe_filter_arg+0x1589>
     59c:      	movl	%r13d, %eax
     59f:      	cltd
     5a0:      	idivl	%ecx
     5a2:      	decl	%eax
     5a4:      	jmp	0x2479 <generic_retkprobe_filter_arg+0x2479>
     5a9:      	movl	(%r15), %ebp
     5ac:      	movl	%eax, %ecx
     5ae:      	andl	$-0x2, %ecx
     5b1:      	cmpl	$0x24, %ecx
     5b4:      	je	0x5be <generic_retkprobe_filter_arg+0x5be>
     5b6:      	testl	%ebp, %ebp
     5b8:      	je	0xb8 <generic_retkprobe_filter_arg+0xb8>
     5be:      	cmpl	$0x25, %eax
     5c1:      	ja	0x8f5 <generic_retkprobe_filter_arg+0x8f5>
     5c7:      	movl	%eax, %ecx
     5c9:      	movl	$0x4000100, %edx        # imm = 0x4000100
     5ce:      	btq	%rcx, %rdx
     5d2:      	jb	0xa94 <generic_retkprobe_filter_arg+0xa94>
     5d8:      	movl	$0x8000200, %edx        # imm = 0x8000200
     5dd:      	btq	%rcx, %rdx
     5e1:      	jb	0x95d <generic_retkprobe_filter_arg+0x95d>
     5e7:      	movabsq	$0x3000000000, %rdx     # imm = 0x3000000000
     5f1:      	btq	%rcx, %rdx
     5f5:      	jae	0x8f5 <generic_retkprobe_filter_arg+0x8f5>
     5fb:      	movw	$0x0, 0x38(%rsp)
     602:      	cmpl	$0x1000, %ebp           # imm = 0x1000
     608:      	ja	0x911 <generic_retkprobe_filter_arg+0x911>
     60e:      	leaq	(%r15,%rbp), %rcx
     612:      	addq	$0x8, %rcx
     616:      	movl	$0x4, %eax
     61b:      	leaq	0x38(%rsp), %rdi
     620:      	movl	$0x2, %edx
     625:      	movl	(%r15), %ecx
     628:      	leaq	(%r15,%rcx), %rdx
     62c:      	addq	$0x8, %rdx
     630:      	movl	$0x2, %esi
     635:      	callq	*%rax
     637:      	movl	0x10(%r12), %ecx
     63c:      	testl	%ecx, %ecx
     63e:      	je	0x3153 <generic_retkprobe_filter_arg+0x3153>
     644:      	movzwl	0x38(%rsp), %eax
     649:      	andl	$0xf000, %eax           # imm = 0xF000
     64e:      	movl	$0x1, %ebx
     653:      	cmpl	%eax, %ecx
     655:      	je	0x3155 <generic_retkprobe_filter_arg+0x3155>
     65b:      	movl	0x8(%r12), %ecx
     660:      	cmpl	$0xd, %ecx
     663:      	movq	(%rsp), %rdi
     667:      	movq	0x8(%rsp), %r9
     66c:      	movq	0x10(%rsp), %r11
     671:      	jb	0x911 <generic_retkprobe_filter_arg+0x911>
     677:      	movl	0x14(%r12), %edx
     67c:      	testl	%edx, %edx
     67e:      	je	0x911 <generic_retkprobe_filter_arg+0x911>
     684:      	cmpl	%eax, %edx
     686:      	je	0x3163 <generic_retkprobe_filter_arg+0x3163>
     68c:      	cmpl	$0x11, %ecx
     68f:      	jb	0x911 <generic_retkprobe_filter_arg+0x911>
     695:      	movl	0x18(%r12), %edx
     69a:      	testl	%edx, %edx
     69c:      	je	0x911 <generic_retkprobe_filter_arg+0x911>
     6a2:      	cmpl	%eax, %edx
     6a4:      	je	0x3163 <generic_retkprobe_filter_arg+0x3163>
     6aa:      	cmpl	$0x15, %ecx
     6ad:      	jb	0x3678 <generic_retkprobe_filter_arg+0x3678>
     6b3:      	movl	0x1c(%r12), %ecx
     6b8:      	testl	%ecx, %ecx
     6ba:      	je	0x3678 <generic_retkprobe_filter_arg+0x3678>
     6c0:      	xorl	%ebx, %ebx
     6c2:      	cmpl	%eax, %ecx
     6c4:      	sete	%bl
     6c7:      	jmp	0xa8a <generic_retkprobe_filter_arg+0xa8a>
     6cc:      	leal	-0xc(%rcx), %edx
     6cf:      	cmpl	$0x2, %edx
     6d2:      	jae	0xbb6 <generic_retkprobe_filter_arg+0xbb6>
     6d8:      	cmpl	$0x20, %eax
     6db:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
     6e1:      	movl	%eax, %edx
     6e3:      	movl	$0x101e, %esi           # imm = 0x101E
     6e8:      	btq	%rdx, %rsi
     6ec:      	jae	0x735 <generic_retkprobe_filter_arg+0x735>
     6ee:      	movl	0x10(%r12), %edx
     6f3:      	cmpl	$0x2, %eax
     6f6:      	jle	0xb7f <generic_retkprobe_filter_arg+0xb7f>
     6fc:      	leal	-0x3(%rax), %esi
     6ff:      	cmpl	$0x2, %esi
     702:      	jae	0xfea <generic_retkprobe_filter_arg+0xfea>
     708:      	cmpl	%edx, (%r15)
     70b:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
     711:      	jmp	0x21da <generic_retkprobe_filter_arg+0x21da>
     716:      	cmpl	$0x28, %ecx
     719:      	je	0xcfb <generic_retkprobe_filter_arg+0xcfb>
     71f:      	movq	%r15, %rdx
     722:      	movl	$0x0, %ebx
     727:      	cmpl	$0x29, %ecx
     72a:      	je	0xd27 <generic_retkprobe_filter_arg+0xd27>
     730:      	jmp	0x1bc9 <generic_retkprobe_filter_arg+0x1bc9>
     735:      	movl	$0xc00, %esi            # imm = 0xC00
     73a:      	btq	%rdx, %rsi
     73e:      	jb	0xcbb <generic_retkprobe_filter_arg+0xcbb>
     744:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
     74e:      	btq	%rdx, %rsi
     752:      	jae	0xb8 <generic_retkprobe_filter_arg+0xb8>
     758:      	cmpl	$0x1f, %eax
     75b:      	jne	0x128b <generic_retkprobe_filter_arg+0x128b>
     761:      	movl	0x10(%r12), %esi
     766:      	movl	0x14(%r12), %edx
     76b:      	cmpl	$0xc, %ecx
     76e:      	ja	0x1ef2 <generic_retkprobe_filter_arg+0x1ef2>
     774:      	movl	$0x1402, %eax           # imm = 0x1402
     779:      	btl	%ecx, %eax
     77c:      	jae	0x1ef2 <generic_retkprobe_filter_arg+0x1ef2>
     782:      	movl	(%r15), %eax
     785:      	cmpl	%eax, %esi
     787:      	jg	0x1f01 <generic_retkprobe_filter_arg+0x1f01>
     78d:      	cmpl	%edx, %eax
     78f:      	jle	0x271 <generic_retkprobe_filter_arg+0x271>
     795:      	jmp	0x1f01 <generic_retkprobe_filter_arg+0x1f01>
     79a:      	cmpl	$0x20, %eax
     79d:      	jg	0xdab <generic_retkprobe_filter_arg+0xdab>
     7a3:      	cmpl	$0x1a, %eax
     7a6:      	je	0xee5 <generic_retkprobe_filter_arg+0xee5>
     7ac:      	movl	$0x0, %ebx
     7b1:      	cmpl	$0x1b, %eax
     7b4:      	jne	0x3351 <generic_retkprobe_filter_arg+0x3351>
     7ba:      	movl	0x10(%r12), %eax
     7bf:      	movl	%eax, 0x38(%rsp)
     7c3:      	movl	$0x0, 0x70(%rsp)
     7cb:      	movl	$0x1, %eax
     7d0:      	leaq	0x38(%rsp), %rsi
     7d5:      	movq	(%rip), %rdi            # 0x7dc <generic_retkprobe_filter_arg+0x7dc>
     7dc:      	callq	*%rax
     7de:      	testl	%ebp, %ebp
     7e0:      	je	0x3341 <generic_retkprobe_filter_arg+0x3341>
     7e6:      	movq	%rax, %r15
     7e9:      	movl	$0x0, %ebx
     7ee:      	testq	%rax, %rax
     7f1:      	je	0x3343 <generic_retkprobe_filter_arg+0x3343>
     7f7:      	movl	$0x1, %eax
     7fc:      	movq	0x20(%rsp), %rsi
     801:      	movq	(%rip), %rdi            # 0x808 <generic_retkprobe_filter_arg+0x808>
     808:      	callq	*%rax
     80a:      	testq	%rax, %rax
     80d:      	je	0x3341 <generic_retkprobe_filter_arg+0x3341>
     813:      	movq	%rax, %rsi
     816:      	movq	%r15, 0x60(%rsp)
     81b:      	cmpl	$0x7f, %ebp
     81e:      	movl	$0x7f, %eax
     823:      	cmovbl	%ebp, %eax
     826:      	shll	$0x3, %eax
     829:      	movl	%eax, (%rsi)
     82b:      	movq	%rbp, %rax
     82e:      	negq	%rax
     831:      	movl	$0x3, %ecx
     836:      	subq	%rbp, %rcx
     839:      	leal	-0x4(%rbp), %edx
     83c:      	movq	%rsi, %rdi
     83f:      	addq	$0x7, %rdi
     843:      	movl	$0x2, %r8d
     849:      	subq	%rbp, %r8
     84c:      	leal	-0x3(%rbp), %r9d
     850:      	movl	$0x1, %r10d
     856:      	subq	%rbp, %r10
     859:      	leal	-0x2(%rbp), %r11d
     85d:      	decl	%ebp
     85f:      	xorl	%ebx, %ebx
     861:      	movq	0x18(%rsp), %r15
     866:      	leal	(%rbx,%rbp), %r13d
     86a:      	andl	$0xfff, %r13d           # imm = 0xFFF
     871:      	movzbl	(%r15,%r13), %r13d
     876:      	movb	%r13b, -0x3(%rdi)
     87a:      	cmpq	%rbx, %r10
     87d:      	je	0x8d7 <generic_retkprobe_filter_arg+0x8d7>
     87f:      	leal	(%r11,%rbx), %r13d
     883:      	andl	$0xfff, %r13d           # imm = 0xFFF
     88a:      	movzbl	(%r15,%r13), %r13d
     88f:      	movb	%r13b, -0x2(%rdi)
     893:      	cmpq	%rbx, %r8
     896:      	je	0x8d7 <generic_retkprobe_filter_arg+0x8d7>
     898:      	leal	(%r9,%rbx), %r13d
     89c:      	andl	$0xfff, %r13d           # imm = 0xFFF
     8a3:      	movzbl	(%r15,%r13), %r13d
     8a8:      	movb	%r13b, -0x1(%rdi)
     8ac:      	cmpq	%rbx, %rcx
     8af:      	je	0x8d7 <generic_retkprobe_filter_arg+0x8d7>
     8b1:      	cmpq	$-0x7c, %rbx
     8b5:      	je	0x8d7 <generic_retkprobe_filter_arg+0x8d7>
     8b7:      	leal	(%rdx,%rbx), %r13d
     8bb:      	andl	$0xfff, %r13d           # imm = 0xFFF
     8c2:      	movzbl	(%r15,%r13), %r13d
     8c7:      	movb	%r13b, (%rdi)
     8ca:      	addq	$-0x4, %rbx
     8ce:      	addq	$0x4, %rdi
     8d2:      	cmpq	%rbx, %rax
     8d5:      	jne	0x866 <generic_retkprobe_filter_arg+0x866>
     8d7:      	movl	$0x1, %eax
     8dc:      	movq	0x60(%rsp), %rdi
     8e1:      	callq	*%rax
     8e3:      	xorl	%ebx, %ebx
     8e5:      	testq	%rax, %rax
     8e8:      	setne	%bl
     8eb:      	movq	0x28(%rsp), %r13
     8f0:      	jmp	0x3343 <generic_retkprobe_filter_arg+0x3343>
     8f5:      	addl	$-0x3, %eax
     8f8:      	cmpl	$0x2, %eax
     8fb:      	jae	0x911 <generic_retkprobe_filter_arg+0x911>
     8fd:      	movl	$0x0, 0x70(%rsp)
     905:      	cmpl	$0x1000, %ebp           # imm = 0x1000
     90b:      	jbe	0x10f0 <generic_retkprobe_filter_arg+0x10f0>
     911:      	xorl	%ebx, %ebx
     913:      	jmp	0x3163 <generic_retkprobe_filter_arg+0x3163>
     918:      	cmpl	$0x20, %eax
     91b:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
     921:      	movl	%eax, %ecx
     923:      	movl	$0x101e, %edx           # imm = 0x101E
     928:      	btq	%rcx, %rdx
     92c:      	jae	0x1033 <generic_retkprobe_filter_arg+0x1033>
     932:      	movl	0x10(%r12), %ecx
     937:      	cmpl	$0x2, %eax
     93a:      	jle	0x15dd <generic_retkprobe_filter_arg+0x15dd>
     940:      	leal	-0x3(%rax), %edx
     943:      	cmpl	$0x2, %edx
     946:      	jae	0x1d4d <generic_retkprobe_filter_arg+0x1d4d>
     94c:      	movzwl	(%r15), %edx
     950:      	cmpl	%edx, %ecx
     952:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
     958:      	jmp	0x1eb9 <generic_retkprobe_filter_arg+0x1eb9>
     95d:      	movl	0x10(%r12), %eax
     962:      	movl	%eax, 0x38(%rsp)
     966:      	movl	$0x0, 0x70(%rsp)
     96e:      	movl	$0x1, %eax
     973:      	leaq	0x38(%rsp), %rsi
     978:      	movq	(%rip), %rdi            # 0x97f <generic_retkprobe_filter_arg+0x97f>
     97f:      	callq	*%rax
     981:      	testl	%ebp, %ebp
     983:      	je	0x3153 <generic_retkprobe_filter_arg+0x3153>
     989:      	movl	$0x0, %ebx
     98e:      	testq	%rax, %rax
     991:      	je	0x3155 <generic_retkprobe_filter_arg+0x3155>
     997:      	movq	%rax, 0x18(%rsp)
     99c:      	movl	$0x1, %eax
     9a1:      	movq	0x20(%rsp), %rsi
     9a6:      	movq	(%rip), %rdi            # 0x9ad <generic_retkprobe_filter_arg+0x9ad>
     9ad:      	callq	*%rax
     9af:      	testq	%rax, %rax
     9b2:      	je	0x3153 <generic_retkprobe_filter_arg+0x3153>
     9b8:      	movq	%rax, %rsi
     9bb:      	cmpl	$0x7f, %ebp
     9be:      	movl	$0x7f, %eax
     9c3:      	cmovbl	%ebp, %eax
     9c6:      	shll	$0x3, %eax
     9c9:      	movl	%eax, (%rsi)
     9cb:      	movq	%rbp, %rax
     9ce:      	negq	%rax
     9d1:      	movl	$0x3, %ecx
     9d6:      	subq	%rbp, %rcx
     9d9:      	leal	-0x4(%rbp), %edx
     9dc:      	movq	%rsi, %rdi
     9df:      	addq	$0x7, %rdi
     9e3:      	movl	$0x2, %r8d
     9e9:      	subq	%rbp, %r8
     9ec:      	leal	-0x3(%rbp), %r9d
     9f0:      	movl	$0x1, %r10d
     9f6:      	subq	%rbp, %r10
     9f9:      	leal	-0x2(%rbp), %r11d
     9fd:      	decl	%ebp
     9ff:      	xorl	%ebx, %ebx
     a01:      	leal	(%rbx,%rbp), %r13d
     a05:      	andl	$0xfff, %r13d           # imm = 0xFFF
     a0c:      	movzbl	0x4(%r15,%r13), %r13d
     a12:      	movb	%r13b, -0x3(%rdi)
     a16:      	cmpq	%rbx, %r10
     a19:      	je	0xa76 <generic_retkprobe_filter_arg+0xa76>
     a1b:      	leal	(%r11,%rbx), %r13d
     a1f:      	andl	$0xfff, %r13d           # imm = 0xFFF
     a26:      	movzbl	0x4(%r15,%r13), %r13d
     a2c:      	movb	%r13b, -0x2(%rdi)
     a30:      	cmpq	%rbx, %r8
     a33:      	je	0xa76 <generic_retkprobe_filter_arg+0xa76>
     a35:      	leal	(%r9,%rbx), %r13d
     a39:      	andl	$0xfff, %r13d           # imm = 0xFFF
     a40:      	movzbl	0x4(%r15,%r13), %r13d
     a46:      	movb	%r13b, -0x1(%rdi)
     a4a:      	cmpq	%rbx, %rcx
     a4d:      	je	0xa76 <generic_retkprobe_filter_arg+0xa76>
     a4f:      	cmpq	$-0x7c, %rbx
     a53:      	je	0xa76 <generic_retkprobe_filter_arg+0xa76>
     a55:      	leal	(%rdx,%rbx), %r13d
     a59:      	andl	$0xfff, %r13d           # imm = 0xFFF
     a60:      	movzbl	0x4(%r15,%r13), %r13d
     a66:      	movb	%r13b, (%rdi)
     a69:      	addq	$-0x4, %rbx
     a6d:      	addq	$0x4, %rdi
     a71:      	cmpq	%rbx, %rax
     a74:      	jne	0xa01 <generic_retkprobe_filter_arg+0xa01>
     a76:      	movl	$0x1, %eax
     a7b:      	movq	0x18(%rsp), %rdi
     a80:      	callq	*%rax
     a82:      	xorl	%ebx, %ebx
     a84:      	testq	%rax, %rax
     a87:      	setne	%bl
     a8a:      	movq	0x28(%rsp), %r13
     a8f:      	jmp	0x3155 <generic_retkprobe_filter_arg+0x3155>
     a94:      	movl	0x10(%r12), %eax
     a99:      	movl	%eax, 0x38(%rsp)
     a9d:      	movl	$0x0, 0x70(%rsp)
     aa5:      	movl	$0x1, %eax
     aaa:      	leaq	0x38(%rsp), %rsi
     aaf:      	movq	(%rip), %rdi            # 0xab6 <generic_retkprobe_filter_arg+0xab6>
     ab6:      	callq	*%rax
     ab8:      	testl	%ebp, %ebp
     aba:      	je	0x3153 <generic_retkprobe_filter_arg+0x3153>
     ac0:      	movl	$0x0, %ebx
     ac5:      	testq	%rax, %rax
     ac8:      	je	0x3155 <generic_retkprobe_filter_arg+0x3155>
     ace:      	movq	%rax, 0x18(%rsp)
     ad3:      	movl	$0x1, %eax
     ad8:      	movq	0x20(%rsp), %rsi
     add:      	movq	(%rip), %rdi            # 0xae4 <generic_retkprobe_filter_arg+0xae4>
     ae4:      	callq	*%rax
     ae6:      	testq	%rax, %rax
     ae9:      	je	0x3153 <generic_retkprobe_filter_arg+0x3153>
     aef:      	movq	%rax, %rbx
     af2:      	addq	$0x4, %r15
     af6:      	cmpl	$0xff, %ebp
     afc:      	movl	$0xff, %eax
     b01:      	cmovael	%eax, %ebp
     b04:      	leal	(,%rbp,8), %eax
     b0b:      	movl	%eax, (%rbx)
     b0d:      	movq	%rbx, %rdi
     b10:      	addq	$0x4, %rdi
     b14:      	movl	$0x4, %eax
     b19:      	movl	%ebp, %esi
     b1b:      	movq	%r15, %rdx
     b1e:      	callq	*%rax
     b20:      	movl	$0x1, %eax
     b25:      	movq	0x18(%rsp), %rdi
     b2a:      	movq	%rbx, %rsi
     b2d:      	jmp	0x3147 <generic_retkprobe_filter_arg+0x3147>
     b32:      	leal	-0x1(%rax), %edx
     b35:      	cmpl	$0x4, %edx
     b38:      	jb	0xbd5 <generic_retkprobe_filter_arg+0xbd5>
     b3e:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
     b43:      	movq	%r15, %r13
     b46:      	movl	0x4(%r15), %ebp
     b4a:      	addq	$0x8, %r13
     b4e:      	cmpl	$0x19, %eax
     b51:      	jg	0x1141 <generic_retkprobe_filter_arg+0x1141>
     b57:      	leal	-0x3(%rax), %ecx
     b5a:      	cmpl	$0x2, %ecx
     b5d:      	jb	0x1a8b <generic_retkprobe_filter_arg+0x1a8b>
     b63:      	cmpl	$0x8, %eax
     b66:      	je	0x19f5 <generic_retkprobe_filter_arg+0x19f5>
     b6c:      	movl	$0x0, %ebx
     b71:      	cmpl	$0x9, %eax
     b74:      	je	0x1161 <generic_retkprobe_filter_arg+0x1161>
     b7a:      	jmp	0x3640 <generic_retkprobe_filter_arg+0x3640>
     b7f:      	cmpl	$0x1, %eax
     b82:      	je	0x1414 <generic_retkprobe_filter_arg+0x1414>
     b88:      	cmpl	$0x2, %eax
     b8b:      	jne	0x21da <generic_retkprobe_filter_arg+0x21da>
     b91:      	cmpl	$0xc, %ecx
     b94:      	ja	0x21d1 <generic_retkprobe_filter_arg+0x21d1>
     b9a:      	movl	$0x1402, %esi           # imm = 0x1402
     b9f:      	btl	%ecx, %esi
     ba2:      	jae	0x21d1 <generic_retkprobe_filter_arg+0x21d1>
     ba8:      	cmpl	%edx, (%r15)
     bab:      	jl	0x271 <generic_retkprobe_filter_arg+0x271>
     bb1:      	jmp	0x21da <generic_retkprobe_filter_arg+0x21da>
     bb6:      	cmpl	$0x1c, %ecx
     bb9:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
     bbf:      	cmpl	$0x20, %eax
     bc2:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
     bc8:      	movl	%eax, %edx
     bca:      	movl	$0x101e, %esi           # imm = 0x101E
     bcf:      	btq	%rdx, %rsi
     bd3:      	jae	0xbf9 <generic_retkprobe_filter_arg+0xbf9>
     bd5:      	movq	0x10(%r12), %rdx
     bda:      	cmpl	$0x2, %eax
     bdd:      	jle	0xc1d <generic_retkprobe_filter_arg+0xc1d>
     bdf:      	leal	-0x3(%rax), %esi
     be2:      	cmpl	$0x2, %esi
     be5:      	jae	0xe87 <generic_retkprobe_filter_arg+0xe87>
     beb:      	cmpq	%rdx, (%r15)
     bee:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
     bf4:      	jmp	0x1cb8 <generic_retkprobe_filter_arg+0x1cb8>
     bf9:      	movl	$0xc00, %esi            # imm = 0xC00
     bfe:      	btq	%rdx, %rsi
     c02:      	jb	0xc4b <generic_retkprobe_filter_arg+0xc4b>
     c04:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
     c0e:      	btq	%rdx, %rsi
     c12:      	jb	0xeaa <generic_retkprobe_filter_arg+0xeaa>
     c18:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
     c1d:      	cmpl	$0x1, %eax
     c20:      	je	0x10d4 <generic_retkprobe_filter_arg+0x10d4>
     c26:      	cmpl	$0x2, %eax
     c29:      	jne	0x1cb8 <generic_retkprobe_filter_arg+0x1cb8>
     c2f:      	cmpl	$0xc, %ecx
     c32:      	je	0xc3d <generic_retkprobe_filter_arg+0xc3d>
     c34:      	cmpl	$0xa, %ecx
     c37:      	jne	0x1caf <generic_retkprobe_filter_arg+0x1caf>
     c3d:      	cmpq	%rdx, (%r15)
     c40:      	jl	0x271 <generic_retkprobe_filter_arg+0x271>
     c46:      	jmp	0x1cb8 <generic_retkprobe_filter_arg+0x1cb8>
     c4b:      	movzbl	0x10(%r12), %eax
     c51:      	movl	%eax, 0x70(%rsp)
     c55:      	movl	$0x1, %eax
     c5a:      	movq	0x20(%rsp), %rsi
     c5f:      	movq	(%rip), %rdi            # 0xc66 <generic_retkprobe_filter_arg+0xc66>
     c66:      	callq	*%rax
     c68:      	testq	%rax, %rax
     c6b:      	je	0x19c8 <generic_retkprobe_filter_arg+0x19c8>
     c71:      	movq	%rax, %rdi
     c74:      	movq	(%r15), %rax
     c77:      	movq	%rax, 0x38(%rsp)
     c7c:      	movl	$0x1, %eax
     c81:      	leaq	0x38(%rsp), %rsi
     c86:      	callq	*%rax
     c88:      	movl	0x4(%r12), %ecx
     c8d:      	cmpl	$0xb, %ecx
     c90:      	je	0x16b2 <generic_retkprobe_filter_arg+0x16b2>
     c96:      	cmpl	$0xa, %ecx
     c99:      	movq	(%rsp), %rdi
     c9d:      	movq	0x8(%rsp), %r9
     ca2:      	movq	0x10(%rsp), %r11
     ca7:      	jne	0x16ce <generic_retkprobe_filter_arg+0x16ce>
     cad:      	testq	%rax, %rax
     cb0:      	setne	%al
     cb3:      	movzbl	%al, %ebx
     cb6:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
     cbb:      	movzbl	0x10(%r12), %eax
     cc1:      	movl	%eax, 0x70(%rsp)
     cc5:      	movl	$0x1, %eax
     cca:      	movq	0x20(%rsp), %rsi
     ccf:      	movq	(%rip), %rdi            # 0xcd6 <generic_retkprobe_filter_arg+0xcd6>
     cd6:      	callq	*%rax
     cd8:      	testq	%rax, %rax
     cdb:      	je	0x19c8 <generic_retkprobe_filter_arg+0x19c8>
     ce1:      	movq	%rax, %rdi
     ce4:      	movl	(%r15), %eax
     ce7:      	movq	%rax, 0x38(%rsp)
     cec:      	movl	$0x1, %eax
     cf1:      	leaq	0x38(%rsp), %rsi
     cf6:      	jmp	0x1996 <generic_retkprobe_filter_arg+0x1996>
     cfb:      	movzwl	(%r15), %edx
     cff:      	movw	%dx, 0x5e(%rsp)
     d04:      	movzwl	0x2(%r15), %edx
     d09:      	movw	%dx, 0x58(%rsp)
     d0e:      	movq	0x8(%r15), %rdx
     d12:      	movq	%rdx, 0x38(%rsp)
     d17:      	movq	0x10(%r15), %rdx
     d1b:      	movq	%rdx, 0x40(%rsp)
     d20:      	leaq	0x38(%rsp), %r15
     d25:      	xorl	%edx, %edx
     d27:      	cmpl	$0x13, %eax
     d2a:      	jle	0xd53 <generic_retkprobe_filter_arg+0xd53>
     d2c:      	cmpl	$0x17, %eax
     d2f:      	jg	0xd86 <generic_retkprobe_filter_arg+0xd86>
     d31:      	leal	-0x14(%rax), %ecx
     d34:      	cmpl	$0x2, %ecx
     d37:      	jb	0x12fb <generic_retkprobe_filter_arg+0x12fb>
     d3d:      	leal	-0x16(%rax), %ecx
     d40:      	movl	$0x0, %ebx
     d45:      	cmpl	$0x2, %ecx
     d48:      	jb	0x12f1 <generic_retkprobe_filter_arg+0x12f1>
     d4e:      	jmp	0x1bc9 <generic_retkprobe_filter_arg+0x1bc9>
     d53:      	cmpl	$0xf, %eax
     d56:      	jle	0xf98 <generic_retkprobe_filter_arg+0xf98>
     d5c:      	cmpl	$0x11, %eax
     d5f:      	jg	0x12de <generic_retkprobe_filter_arg+0x12de>
     d65:      	cmpl	$0x10, %eax
     d68:      	je	0x12f1 <generic_retkprobe_filter_arg+0x12f1>
     d6e:      	movl	$0x0, %ebx
     d73:      	cmpl	$0x11, %eax
     d76:      	jne	0x1bc9 <generic_retkprobe_filter_arg+0x1bc9>
     d7c:      	movzwl	0x24(%r15), %ebx
     d81:      	jmp	0x1b49 <generic_retkprobe_filter_arg+0x1b49>
     d86:      	cmpl	$0x1b, %eax
     d89:      	jg	0x1337 <generic_retkprobe_filter_arg+0x1337>
     d8f:      	cmpl	$0x18, %eax
     d92:      	je	0x1374 <generic_retkprobe_filter_arg+0x1374>
     d98:      	movl	$0x0, %ebx
     d9d:      	cmpl	$0x19, %eax
     da0:      	je	0x1367 <generic_retkprobe_filter_arg+0x1367>
     da6:      	jmp	0x1bc9 <generic_retkprobe_filter_arg+0x1bc9>
     dab:      	cmpl	$0x21, %eax
     dae:      	je	0x1439 <generic_retkprobe_filter_arg+0x1439>
     db4:      	movl	$0x0, %ebx
     db9:      	cmpl	$0x22, %eax
     dbc:      	jne	0x3351 <generic_retkprobe_filter_arg+0x3351>
     dc2:      	xorl	%ebx, %ebx
     dc4:      	xorl	%r13d, %r13d
     dc7:      	movl	0x10(%r12,%rbx,4), %eax
     dcc:      	movl	%eax, 0x38(%rsp)
     dd0:      	movl	$0x1, %eax
     dd5:      	leaq	0x38(%rsp), %rsi
     dda:      	movq	(%rip), %rdi            # 0xde1 <generic_retkprobe_filter_arg+0xde1>
     de1:      	callq	*%rax
     de3:      	testq	%rax, %rax
     de6:      	je	0x216c <generic_retkprobe_filter_arg+0x216c>
     dec:      	testl	%ebp, %ebp
     dee:      	movq	0x10(%rsp), %r11
     df3:      	je	0xe64 <generic_retkprobe_filter_arg+0xe64>
     df5:      	movq	0x18(%rsp), %rdx
     dfa:      	xorl	%ecx, %ecx
     dfc:      	jmp	0xe09 <generic_retkprobe_filter_arg+0xe09>
     dfe:      	incq	%rcx
     e01:      	incq	%rdx
     e04:      	cmpq	%rbp, %rcx
     e07:      	je	0xe64 <generic_retkprobe_filter_arg+0xe64>
     e09:      	xorl	%esi, %esi
     e0b:      	nopl	(%rax,%rax)
     e10:      	leaq	(%rcx,%rsi), %rdi
     e14:      	cmpq	%rbp, %rdi
     e17:      	jae	0xdfe <generic_retkprobe_filter_arg+0xdfe>
     e19:      	movsbl	(%rax,%rsi), %edi
     e1d:      	testl	%edi, %edi
     e1f:      	je	0xe5c <generic_retkprobe_filter_arg+0xe5c>
     e21:      	movsbl	(%rdx,%rsi), %r9d
     e26:      	leal	-0x41(%r9), %r10d
     e2a:      	movl	%r9d, %r8d
     e2d:      	orl	$0x20, %r8d
     e31:      	cmpl	$0x1a, %r10d
     e35:      	cmovael	%r9d, %r8d
     e39:      	leal	-0x41(%rdi), %r10d
     e3d:      	movl	%edi, %r9d
     e40:      	orl	$0x20, %r9d
     e44:      	cmpl	$0x1a, %r10d
     e48:      	cmovael	%edi, %r9d
     e4c:      	cmpq	$0x62, %rsi
     e50:      	ja	0xdfe <generic_retkprobe_filter_arg+0xdfe>
     e52:      	incq	%rsi
     e55:      	cmpl	%r9d, %r8d
     e58:      	je	0xe10 <generic_retkprobe_filter_arg+0xe10>
     e5a:      	jmp	0xdfe <generic_retkprobe_filter_arg+0xdfe>
     e5c:      	testl	%ecx, %ecx
     e5e:      	jns	0x261e <generic_retkprobe_filter_arg+0x261e>
     e64:      	leal	0xc(%r13), %eax
     e68:      	cmpl	0x8(%r12), %eax
     e6d:      	jae	0xe80 <generic_retkprobe_filter_arg+0xe80>
     e6f:      	addl	$0x4, %r13d
     e73:      	incq	%rbx
     e76:      	cmpq	$0x64, %rbx
     e7a:      	jne	0xdc7 <generic_retkprobe_filter_arg+0xdc7>
     e80:      	xorl	%ebx, %ebx
     e82:      	jmp	0x2623 <generic_retkprobe_filter_arg+0x2623>
     e87:      	cmpl	$0xc, %eax
     e8a:      	jne	0x1cb8 <generic_retkprobe_filter_arg+0x1cb8>
     e90:      	testq	%rdx, (%r15)
     e93:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
     e99:      	jmp	0x1cb8 <generic_retkprobe_filter_arg+0x1cb8>
     e9e:      	leal	-0x1f(%rax), %edx
     ea1:      	cmpl	$0x2, %edx
     ea4:      	jae	0x17e1 <generic_retkprobe_filter_arg+0x17e1>
     eaa:      	cmpl	$0x1f, %eax
     ead:      	jne	0xfbd <generic_retkprobe_filter_arg+0xfbd>
     eb3:      	movq	0x10(%r12), %rsi
     eb8:      	movq	0x18(%r12), %rdx
     ebd:      	cmpl	$0xa, %ecx
     ec0:      	je	0xecb <generic_retkprobe_filter_arg+0xecb>
     ec2:      	cmpl	$0xc, %ecx
     ec5:      	jne	0x1aa6 <generic_retkprobe_filter_arg+0x1aa6>
     ecb:      	movq	(%r15), %rax
     ece:      	cmpq	%rax, %rsi
     ed1:      	jg	0x1ab7 <generic_retkprobe_filter_arg+0x1ab7>
     ed7:      	cmpq	%rdx, %rax
     eda:      	jle	0x271 <generic_retkprobe_filter_arg+0x271>
     ee0:      	jmp	0x1ab7 <generic_retkprobe_filter_arg+0x1ab7>
     ee5:      	movl	0x10(%r12), %eax
     eea:      	movl	%eax, 0x38(%rsp)
     eee:      	movl	$0x0, 0x70(%rsp)
     ef6:      	movl	$0x1, %eax
     efb:      	leaq	0x38(%rsp), %rsi
     f00:      	movq	(%rip), %rdi            # 0xf07 <generic_retkprobe_filter_arg+0xf07>
     f07:      	callq	*%rax
     f09:      	testl	%ebp, %ebp
     f0b:      	je	0x3341 <generic_retkprobe_filter_arg+0x3341>
     f11:      	movq	%rax, %r15
     f14:      	movl	$0x0, %ebx
     f19:      	testq	%rax, %rax
     f1c:      	je	0x3343 <generic_retkprobe_filter_arg+0x3343>
     f22:      	movl	$0x1, %eax
     f27:      	movq	0x20(%rsp), %rsi
     f2c:      	movq	(%rip), %rdi            # 0xf33 <generic_retkprobe_filter_arg+0xf33>
     f33:      	callq	*%rax
     f35:      	testq	%rax, %rax
     f38:      	je	0x3341 <generic_retkprobe_filter_arg+0x3341>
     f3e:      	cmpl	$0xff, %ebp
     f44:      	movl	$0xff, %ecx
     f49:      	cmovael	%ecx, %ebp
     f4c:      	leal	(,%rbp,8), %ecx
     f53:      	movl	%ecx, (%rax)
     f55:      	movq	%rax, %rdi
     f58:      	addq	$0x4, %rdi
     f5c:      	movq	%rax, %rbx
     f5f:      	movl	$0x4, %eax
     f64:      	movq	0x18(%rsp), %rdx
     f69:      	movl	%ebp, %esi
     f6b:      	callq	*%rax
     f6d:      	movl	$0x1, %eax
     f72:      	movq	%r15, %rdi
     f75:      	movq	%rbx, %rsi
     f78:      	jmp	0x3335 <generic_retkprobe_filter_arg+0x3335>
     f7d:      	movl	$0x0, 0x70(%rsp)
     f85:      	cmpl	$0x1000, %ebp           # imm = 0x1000
     f8b:      	jbe	0x14eb <generic_retkprobe_filter_arg+0x14eb>
     f91:      	xorl	%ebx, %ebx
     f93:      	jmp	0x3351 <generic_retkprobe_filter_arg+0x3351>
     f98:      	cmpl	$0xd, %eax
     f9b:      	je	0x1374 <generic_retkprobe_filter_arg+0x1374>
     fa1:      	cmpl	$0xe, %eax
     fa4:      	je	0x1367 <generic_retkprobe_filter_arg+0x1367>
     faa:      	movl	$0x0, %ebx
     faf:      	cmpl	$0xf, %eax
     fb2:      	je	0x12fb <generic_retkprobe_filter_arg+0x12fb>
     fb8:      	jmp	0x1bc9 <generic_retkprobe_filter_arg+0x1bc9>
     fbd:      	movq	0x10(%r12), %rsi
     fc2:      	movq	0x18(%r12), %rax
     fc7:      	cmpl	$0xc, %ecx
     fca:      	je	0xfd5 <generic_retkprobe_filter_arg+0xfd5>
     fcc:      	cmpl	$0xa, %ecx
     fcf:      	jne	0x1af8 <generic_retkprobe_filter_arg+0x1af8>
     fd5:      	movq	(%r15), %rdx
     fd8:      	cmpq	%rdx, %rsi
     fdb:      	setle	%sil
     fdf:      	cmpq	%rax, %rdx
     fe2:      	setle	%al
     fe5:      	jmp	0x1b08 <generic_retkprobe_filter_arg+0x1b08>
     fea:      	cmpl	$0xc, %eax
     fed:      	jne	0x21da <generic_retkprobe_filter_arg+0x21da>
     ff3:      	testl	%edx, (%r15)
     ff6:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
     ffc:      	jmp	0x21da <generic_retkprobe_filter_arg+0x21da>
    1001:      	movl	$0xc00, %edx            # imm = 0xC00
    1006:      	btq	%rcx, %rdx
    100a:      	jb	0x1600 <generic_retkprobe_filter_arg+0x1600>
    1010:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    101a:      	btq	%rcx, %rdx
    101e:      	jae	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1024:      	cmpl	$0x1f, %eax
    1027:      	jne	0x1d9f <generic_retkprobe_filter_arg+0x1d9f>
    102d:      	movzbl	(%r15), %eax
    1031:      	jmp	0x1063 <generic_retkprobe_filter_arg+0x1063>
    1033:      	movl	$0xc00, %edx            # imm = 0xC00
    1038:      	btq	%rcx, %rdx
    103c:      	jb	0x1641 <generic_retkprobe_filter_arg+0x1641>
    1042:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    104c:      	btq	%rcx, %rdx
    1050:      	jae	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1056:      	cmpl	$0x1f, %eax
    1059:      	jne	0x1daa <generic_retkprobe_filter_arg+0x1daa>
    105f:      	movzwl	(%r15), %eax
    1063:      	cmpl	%eax, 0x10(%r12)
    1068:      	ja	0x1075 <generic_retkprobe_filter_arg+0x1075>
    106a:      	cmpl	%eax, 0x14(%r12)
    106f:      	jae	0x271 <generic_retkprobe_filter_arg+0x271>
    1075:      	movl	0x8(%r12), %ecx
    107a:      	cmpl	$0x11, %ecx
    107d:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1083:      	cmpl	%eax, 0x18(%r12)
    1088:      	ja	0x1095 <generic_retkprobe_filter_arg+0x1095>
    108a:      	cmpl	%eax, 0x1c(%r12)
    108f:      	jae	0x271 <generic_retkprobe_filter_arg+0x271>
    1095:      	cmpl	$0x19, %ecx
    1098:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    109e:      	cmpl	%eax, 0x20(%r12)
    10a3:      	ja	0x10b0 <generic_retkprobe_filter_arg+0x10b0>
    10a5:      	cmpl	%eax, 0x24(%r12)
    10aa:      	jae	0x271 <generic_retkprobe_filter_arg+0x271>
    10b0:      	cmpl	$0x21, %ecx
    10b3:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    10b9:      	cmpl	%eax, 0x28(%r12)
    10be:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
    10c4:      	cmpl	%eax, 0x2c(%r12)
    10c9:      	jae	0x271 <generic_retkprobe_filter_arg+0x271>
    10cf:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    10d4:      	cmpl	$0xc, %ecx
    10d7:      	je	0x10e2 <generic_retkprobe_filter_arg+0x10e2>
    10d9:      	cmpl	$0xa, %ecx
    10dc:      	jne	0x1ca4 <generic_retkprobe_filter_arg+0x1ca4>
    10e2:      	cmpq	%rdx, (%r15)
    10e5:      	jg	0x271 <generic_retkprobe_filter_arg+0x271>
    10eb:      	jmp	0x1cb8 <generic_retkprobe_filter_arg+0x1cb8>
    10f0:      	movzwl	%bp, %eax
    10f3:      	cmpl	$0x90, %eax
    10f8:      	ja	0x16d8 <generic_retkprobe_filter_arg+0x16d8>
    10fe:      	testw	%bp, %bp
    1101:      	je	0x1113 <generic_retkprobe_filter_arg+0x1113>
    1103:      	movl	%ebp, %eax
    1105:      	movl	$0x18, %ecx
    110a:      	cltd
    110b:      	idivl	%ecx
    110d:      	movl	%ebp, %esi
    110f:      	testl	%edx, %edx
    1111:      	je	0x1135 <generic_retkprobe_filter_arg+0x1135>
    1113:      	movl	%ebp, %eax
    1115:      	movl	$0x18, %ecx
    111a:      	cltd
    111b:      	idivl	%ecx
    111d:      	shll	$0x3, %eax
    1120:      	leal	(%rax,%rax,2), %eax
    1123:      	addl	$0x18, %eax
    1126:      	movzwl	%ax, %esi
    1129:      	cmpl	$0x90, %esi
    112f:      	ja	0x1710 <generic_retkprobe_filter_arg+0x1710>
    1135:      	movl	%esi, %eax
    1137:      	cltd
    1138:      	idivl	%ecx
    113a:      	decl	%eax
    113c:      	jmp	0x22dc <generic_retkprobe_filter_arg+0x22dc>
    1141:      	cmpl	$0x20, %eax
    1144:      	jg	0x1827 <generic_retkprobe_filter_arg+0x1827>
    114a:      	cmpl	$0x1a, %eax
    114d:      	je	0x19f5 <generic_retkprobe_filter_arg+0x19f5>
    1153:      	movl	$0x0, %ebx
    1158:      	cmpl	$0x1b, %eax
    115b:      	jne	0x3640 <generic_retkprobe_filter_arg+0x3640>
    1161:      	movl	0x10(%r12), %eax
    1166:      	movl	%eax, 0x38(%rsp)
    116a:      	movl	$0x0, 0x70(%rsp)
    1172:      	movl	$0x1, %eax
    1177:      	leaq	0x38(%rsp), %rsi
    117c:      	movq	(%rip), %rdi            # 0x1183 <generic_retkprobe_filter_arg+0x1183>
    1183:      	callq	*%rax
    1185:      	testl	%ebp, %ebp
    1187:      	je	0x3630 <generic_retkprobe_filter_arg+0x3630>
    118d:      	movq	%rax, %r15
    1190:      	movl	$0x0, %ebx
    1195:      	testq	%rax, %rax
    1198:      	je	0x3632 <generic_retkprobe_filter_arg+0x3632>
    119e:      	movl	$0x1, %eax
    11a3:      	movq	0x20(%rsp), %rsi
    11a8:      	movq	(%rip), %rdi            # 0x11af <generic_retkprobe_filter_arg+0x11af>
    11af:      	callq	*%rax
    11b1:      	testq	%rax, %rax
    11b4:      	je	0x3630 <generic_retkprobe_filter_arg+0x3630>
    11ba:      	movq	%rax, %rsi
    11bd:      	movq	%r15, 0x18(%rsp)
    11c2:      	cmpl	$0x7f, %ebp
    11c5:      	movl	$0x7f, %eax
    11ca:      	cmovbl	%ebp, %eax
    11cd:      	shll	$0x3, %eax
    11d0:      	movl	%eax, (%rsi)
    11d2:      	movq	%rbp, %rax
    11d5:      	negq	%rax
    11d8:      	movl	$0x3, %ecx
    11dd:      	subq	%rbp, %rcx
    11e0:      	leal	-0x4(%rbp), %edx
    11e3:      	movq	%rsi, %rdi
    11e6:      	addq	$0x7, %rdi
    11ea:      	movl	$0x2, %r8d
    11f0:      	subq	%rbp, %r8
    11f3:      	leal	-0x3(%rbp), %r9d
    11f7:      	movl	$0x1, %r10d
    11fd:      	subq	%rbp, %r10
    1200:      	leal	-0x2(%rbp), %r11d
    1204:      	decl	%ebp
    1206:      	xorl	%ebx, %ebx
    1208:      	movq	%r13, %r15
    120b:      	leal	(%rbx,%rbp), %r13d
    120f:      	andl	$0xfff, %r13d           # imm = 0xFFF
    1216:      	movzbl	(%r15,%r13), %r13d
    121b:      	movb	%r13b, -0x3(%rdi)
    121f:      	cmpq	%rbx, %r10
    1222:      	je	0x127c <generic_retkprobe_filter_arg+0x127c>
    1224:      	leal	(%r11,%rbx), %r13d
    1228:      	andl	$0xfff, %r13d           # imm = 0xFFF
    122f:      	movzbl	(%r15,%r13), %r13d
    1234:      	movb	%r13b, -0x2(%rdi)
    1238:      	cmpq	%rbx, %r8
    123b:      	je	0x127c <generic_retkprobe_filter_arg+0x127c>
    123d:      	leal	(%r9,%rbx), %r13d
    1241:      	andl	$0xfff, %r13d           # imm = 0xFFF
    1248:      	movzbl	(%r15,%r13), %r13d
    124d:      	movb	%r13b, -0x1(%rdi)
    1251:      	cmpq	%rbx, %rcx
    1254:      	je	0x127c <generic_retkprobe_filter_arg+0x127c>
    1256:      	cmpq	$-0x7c, %rbx
    125a:      	je	0x127c <generic_retkprobe_filter_arg+0x127c>
    125c:      	leal	(%rdx,%rbx), %r13d
    1260:      	andl	$0xfff, %r13d           # imm = 0xFFF
    1267:      	movzbl	(%r15,%r13), %r13d
    126c:      	movb	%r13b, (%rdi)
    126f:      	addq	$-0x4, %rbx
    1273:      	addq	$0x4, %rdi
    1277:      	cmpq	%rbx, %rax
    127a:      	jne	0x120b <generic_retkprobe_filter_arg+0x120b>
    127c:      	movl	$0x1, %eax
    1281:      	movq	0x18(%rsp), %rdi
    1286:      	jmp	0x3624 <generic_retkprobe_filter_arg+0x3624>
    128b:      	movl	0x10(%r12), %esi
    1290:      	movl	0x14(%r12), %eax
    1295:      	cmpl	$0xc, %ecx
    1298:      	ja	0x1f4b <generic_retkprobe_filter_arg+0x1f4b>
    129e:      	movl	$0x1402, %edx           # imm = 0x1402
    12a3:      	btl	%ecx, %edx
    12a6:      	jae	0x1f4b <generic_retkprobe_filter_arg+0x1f4b>
    12ac:      	movl	(%r15), %edx
    12af:      	cmpl	%edx, %esi
    12b1:      	setle	%sil
    12b5:      	cmpl	%eax, %edx
    12b7:      	setle	%al
    12ba:      	jmp	0x1f59 <generic_retkprobe_filter_arg+0x1f59>
    12bf:      	cmpl	$0x1c, %eax
    12c2:      	je	0x195e <generic_retkprobe_filter_arg+0x195e>
    12c8:      	movq	%r8, 0x18(%rsp)
    12cd:      	movq	%rsi, %r15
    12d0:      	cmpl	$0x1a, %eax
    12d3:      	je	0x18ca <generic_retkprobe_filter_arg+0x18ca>
    12d9:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    12de:      	cmpl	$0x12, %eax
    12e1:      	je	0x12fb <generic_retkprobe_filter_arg+0x12fb>
    12e3:      	movl	$0x0, %ebx
    12e8:      	cmpl	$0x13, %eax
    12eb:      	jne	0x1bc9 <generic_retkprobe_filter_arg+0x1bc9>
    12f1:      	movq	%r15, %rdx
    12f4:      	movzwl	0x22(%r15), %r13d
    12f9:      	jmp	0x1303 <generic_retkprobe_filter_arg+0x1303>
    12fb:      	movq	%r15, %rdx
    12fe:      	movzwl	0x20(%r15), %r13d
    1303:      	xorl	%esi, %esi
    1305:      	xorl	%ebp, %ebp
    1307:      	xorl	%r15d, %r15d
    130a:      	xorl	%ebx, %ebx
    130c:      	cmpl	$0x11, %eax
    130f:      	jg	0x138f <generic_retkprobe_filter_arg+0x138f>
    1311:      	leal	-0xd(%rax), %ecx
    1314:      	cmpl	$0x2, %ecx
    1317:      	jb	0x13c2 <generic_retkprobe_filter_arg+0x13c2>
    131d:      	leal	-0xf(%rax), %ecx
    1320:      	cmpl	$0x2, %ecx
    1323:      	jb	0x1548 <generic_retkprobe_filter_arg+0x1548>
    1329:      	cmpl	$0x11, %eax
    132c:      	je	0x1b49 <generic_retkprobe_filter_arg+0x1b49>
    1332:      	jmp	0x1bc9 <generic_retkprobe_filter_arg+0x1bc9>
    1337:      	cmpl	$0x1c, %eax
    133a:      	je	0x1b44 <generic_retkprobe_filter_arg+0x1b44>
    1340:      	movl	$0x0, %ebx
    1345:      	cmpl	$0x1d, %eax
    1348:      	jne	0x1bc9 <generic_retkprobe_filter_arg+0x1bc9>
    134e:      	cmpl	$0x7, %ecx
    1351:      	jne	0x20df <generic_retkprobe_filter_arg+0x20df>
    1357:      	testq	%rdx, %rdx
    135a:      	jne	0x20eb <generic_retkprobe_filter_arg+0x20eb>
    1360:      	xorl	%ebx, %ebx
    1362:      	jmp	0x20fd <generic_retkprobe_filter_arg+0x20fd>
    1367:      	movq	0x10(%r15), %rsi
    136b:      	movq	%r15, %rdx
    136e:      	movq	0x18(%r15), %r15
    1372:      	jmp	0x137e <generic_retkprobe_filter_arg+0x137e>
    1374:      	movq	(%r15), %rsi
    1377:      	movq	%r15, %rdx
    137a:      	movq	0x8(%r15), %r15
    137e:      	movq	%rsi, %rbp
    1381:      	shrq	$0x20, %rbp
    1385:      	xorl	%r13d, %r13d
    1388:      	xorl	%ebx, %ebx
    138a:      	cmpl	$0x11, %eax
    138d:      	jle	0x1311 <generic_retkprobe_filter_arg+0x1311>
    138f:      	cmpl	$0x19, %eax
    1392:      	ja	0x153c <generic_retkprobe_filter_arg+0x153c>
    1398:      	movl	$0x500000, %ecx         # imm = 0x500000
    139d:      	btl	%eax, %ecx
    13a0:      	jb	0x1682 <generic_retkprobe_filter_arg+0x1682>
    13a6:      	movl	$0xa00000, %ecx         # imm = 0xA00000
    13ab:      	btl	%eax, %ecx
    13ae:      	jb	0x169a <generic_retkprobe_filter_arg+0x169a>
    13b4:      	movl	$0x3000000, %ecx        # imm = 0x3000000
    13b9:      	btl	%eax, %ecx
    13bc:      	jae	0x153c <generic_retkprobe_filter_arg+0x153c>
    13c2:      	movzwl	0x26(%rdx), %eax
    13c6:      	cmpl	$0xa, %eax
    13c9:      	je	0x1740 <generic_retkprobe_filter_arg+0x1740>
    13cf:      	cmpl	$0x2, %eax
    13d2:      	jne	0x17d2 <generic_retkprobe_filter_arg+0x17d2>
    13d8:      	movq	%rsi, %rbx
    13db:      	movl	0x10(%r12), %eax
    13e0:      	movl	%eax, 0x34(%rsp)
    13e4:      	movl	$0x1, %eax
    13e9:      	leaq	0x34(%rsp), %rsi
    13ee:      	movq	(%rip), %rdi            # 0x13f5 <generic_retkprobe_filter_arg+0x13f5>
    13f5:      	callq	*%rax
    13f7:      	testq	%rax, %rax
    13fa:      	je	0x1c10 <generic_retkprobe_filter_arg+0x1c10>
    1400:      	movq	%rax, %rdi
    1403:      	movl	$0x20, 0x70(%rsp)
    140b:      	movl	%ebx, 0x74(%rsp)
    140f:      	jmp	0x178c <generic_retkprobe_filter_arg+0x178c>
    1414:      	cmpl	$0xc, %ecx
    1417:      	ja	0x21c6 <generic_retkprobe_filter_arg+0x21c6>
    141d:      	movl	$0x1402, %esi           # imm = 0x1402
    1422:      	btl	%ecx, %esi
    1425:      	jae	0x21c6 <generic_retkprobe_filter_arg+0x21c6>
    142b:      	cmpl	%edx, (%r15)
    142e:      	jg	0x271 <generic_retkprobe_filter_arg+0x271>
    1434:      	jmp	0x21da <generic_retkprobe_filter_arg+0x21da>
    1439:      	xorl	%ebx, %ebx
    143b:      	xorl	%r13d, %r13d
    143e:      	movl	0x10(%r12,%rbx,4), %eax
    1443:      	movl	%eax, 0x38(%rsp)
    1447:      	movl	$0x1, %eax
    144c:      	leaq	0x38(%rsp), %rsi
    1451:      	movq	(%rip), %rdi            # 0x1458 <generic_retkprobe_filter_arg+0x1458>
    1458:      	callq	*%rax
    145a:      	testq	%rax, %rax
    145d:      	je	0x2152 <generic_retkprobe_filter_arg+0x2152>
    1463:      	testl	%ebp, %ebp
    1465:      	movq	0x8(%rsp), %r9
    146a:      	movq	0x10(%rsp), %r11
    146f:      	je	0x14bf <generic_retkprobe_filter_arg+0x14bf>
    1471:      	movq	0x18(%rsp), %rdx
    1476:      	xorl	%ecx, %ecx
    1478:      	jmp	0x1485 <generic_retkprobe_filter_arg+0x1485>
    147a:      	incq	%rcx
    147d:      	incq	%rdx
    1480:      	cmpq	%rbp, %rcx
    1483:      	je	0x14bf <generic_retkprobe_filter_arg+0x14bf>
    1485:      	xorl	%esi, %esi
    1487:      	nopw	(%rax,%rax)
    1490:      	leaq	(%rcx,%rsi), %rdi
    1494:      	cmpq	%rbp, %rdi
    1497:      	jae	0x147a <generic_retkprobe_filter_arg+0x147a>
    1499:      	movzbl	(%rax,%rsi), %edi
    149d:      	testb	%dil, %dil
    14a0:      	je	0x14b7 <generic_retkprobe_filter_arg+0x14b7>
    14a2:      	cmpq	$0x62, %rsi
    14a6:      	ja	0x147a <generic_retkprobe_filter_arg+0x147a>
    14a8:      	leaq	0x1(%rsi), %r8
    14ac:      	cmpb	%dil, (%rdx,%rsi)
    14b0:      	movq	%r8, %rsi
    14b3:      	je	0x1490 <generic_retkprobe_filter_arg+0x1490>
    14b5:      	jmp	0x147a <generic_retkprobe_filter_arg+0x147a>
    14b7:      	testl	%ecx, %ecx
    14b9:      	jns	0x260b <generic_retkprobe_filter_arg+0x260b>
    14bf:      	leal	0xc(%r13), %eax
    14c3:      	cmpl	0x8(%r12), %eax
    14c8:      	jae	0x14db <generic_retkprobe_filter_arg+0x14db>
    14ca:      	addl	$0x4, %r13d
    14ce:      	incq	%rbx
    14d1:      	cmpq	$0x64, %rbx
    14d5:      	jne	0x143e <generic_retkprobe_filter_arg+0x143e>
    14db:      	xorl	%ebx, %ebx
    14dd:      	movq	0x28(%rsp), %r13
    14e2:      	movq	(%rsp), %rdi
    14e6:      	jmp	0x3351 <generic_retkprobe_filter_arg+0x3351>
    14eb:      	movzwl	%bp, %eax
    14ee:      	cmpl	$0x90, %eax
    14f3:      	ja	0x1c3c <generic_retkprobe_filter_arg+0x1c3c>
    14f9:      	testw	%bp, %bp
    14fc:      	je	0x150e <generic_retkprobe_filter_arg+0x150e>
    14fe:      	movl	%ebp, %eax
    1500:      	movl	$0x18, %ecx
    1505:      	cltd
    1506:      	idivl	%ecx
    1508:      	movl	%ebp, %esi
    150a:      	testl	%edx, %edx
    150c:      	je	0x1530 <generic_retkprobe_filter_arg+0x1530>
    150e:      	movl	%ebp, %eax
    1510:      	movl	$0x18, %ecx
    1515:      	cltd
    1516:      	idivl	%ecx
    1518:      	shll	$0x3, %eax
    151b:      	leal	(%rax,%rax,2), %eax
    151e:      	addl	$0x18, %eax
    1521:      	movzwl	%ax, %esi
    1524:      	cmpl	$0x90, %esi
    152a:      	ja	0x1c74 <generic_retkprobe_filter_arg+0x1c74>
    1530:      	movl	%esi, %eax
    1532:      	cltd
    1533:      	idivl	%ecx
    1535:      	decl	%eax
    1537:      	jmp	0x288d <generic_retkprobe_filter_arg+0x288d>
    153c:      	addl	$-0x12, %eax
    153f:      	cmpl	$0x2, %eax
    1542:      	jae	0x1bc9 <generic_retkprobe_filter_arg+0x1bc9>
    1548:      	movzbl	0x10(%r12), %eax
    154e:      	movl	%eax, 0x34(%rsp)
    1552:      	movl	$0x1, %eax
    1557:      	movq	(%rip), %rdi            # 0x155e <generic_retkprobe_filter_arg+0x155e>
    155e:      	leaq	0x34(%rsp), %rsi
    1563:      	callq	*%rax
    1565:      	testq	%rax, %rax
    1568:      	je	0x2138 <generic_retkprobe_filter_arg+0x2138>
    156e:      	movq	%rax, %rdi
    1571:      	movzwl	%r13w, %eax
    1575:      	movq	%rax, 0x70(%rsp)
    157a:      	movl	$0x1, %eax
    157f:      	movq	0x20(%rsp), %rsi
    1584:      	jmp	0x1b84 <generic_retkprobe_filter_arg+0x1b84>
    1589:      	leal	-0x100(%r13), %eax
    1590:      	rorxl	$0x8, %eax, %eax
    1596:      	cmpl	$0x2, %eax
    1599:      	jg	0x1d67 <generic_retkprobe_filter_arg+0x1d67>
    159f:      	testl	%eax, %eax
    15a1:      	je	0x246d <generic_retkprobe_filter_arg+0x246d>
    15a7:      	cmpl	$0x1, %eax
    15aa:      	jne	0x2466 <generic_retkprobe_filter_arg+0x2466>
    15b0:      	movl	$0x7, %eax
    15b5:      	jmp	0x2479 <generic_retkprobe_filter_arg+0x2479>
    15ba:      	cmpl	$0x1, %eax
    15bd:      	je	0x1e68 <generic_retkprobe_filter_arg+0x1e68>
    15c3:      	cmpl	$0x2, %eax
    15c6:      	jne	0x1e74 <generic_retkprobe_filter_arg+0x1e74>
    15cc:      	movzbl	(%r15), %edx
    15d0:      	cmpl	%edx, %ecx
    15d2:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    15d8:      	jmp	0x1e74 <generic_retkprobe_filter_arg+0x1e74>
    15dd:      	cmpl	$0x1, %eax
    15e0:      	je	0x1ead <generic_retkprobe_filter_arg+0x1ead>
    15e6:      	cmpl	$0x2, %eax
    15e9:      	jne	0x1eb9 <generic_retkprobe_filter_arg+0x1eb9>
    15ef:      	movzwl	(%r15), %edx
    15f3:      	cmpl	%edx, %ecx
    15f5:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    15fb:      	jmp	0x1eb9 <generic_retkprobe_filter_arg+0x1eb9>
    1600:      	movzbl	0x10(%r12), %eax
    1606:      	movl	%eax, 0x70(%rsp)
    160a:      	movl	$0x1, %eax
    160f:      	movq	0x20(%rsp), %rsi
    1614:      	movq	(%rip), %rdi            # 0x161b <generic_retkprobe_filter_arg+0x161b>
    161b:      	callq	*%rax
    161d:      	testq	%rax, %rax
    1620:      	je	0x19c8 <generic_retkprobe_filter_arg+0x19c8>
    1626:      	movq	%rax, %rdi
    1629:      	movzbl	(%r15), %eax
    162d:      	movq	%rax, 0x38(%rsp)
    1632:      	movl	$0x1, %eax
    1637:      	leaq	0x38(%rsp), %rsi
    163c:      	jmp	0x1996 <generic_retkprobe_filter_arg+0x1996>
    1641:      	movzbl	0x10(%r12), %eax
    1647:      	movl	%eax, 0x70(%rsp)
    164b:      	movl	$0x1, %eax
    1650:      	movq	0x20(%rsp), %rsi
    1655:      	movq	(%rip), %rdi            # 0x165c <generic_retkprobe_filter_arg+0x165c>
    165c:      	callq	*%rax
    165e:      	testq	%rax, %rax
    1661:      	je	0x19c8 <generic_retkprobe_filter_arg+0x19c8>
    1667:      	movq	%rax, %rdi
    166a:      	movzwl	(%r15), %eax
    166e:      	movq	%rax, 0x38(%rsp)
    1673:      	movl	$0x1, %eax
    1678:      	leaq	0x38(%rsp), %rsi
    167d:      	jmp	0x1996 <generic_retkprobe_filter_arg+0x1996>
    1682:      	movzwl	%r13w, %eax
    1686:      	xorl	%ebx, %ebx
    1688:      	cmpl	$0x400, %eax            # imm = 0x400
    168d:      	setb	%bl
    1690:      	movq	0x28(%rsp), %r13
    1695:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    169a:      	movzwl	%r13w, %eax
    169e:      	xorl	%ebx, %ebx
    16a0:      	cmpl	$0x400, %eax            # imm = 0x400
    16a5:      	setae	%bl
    16a8:      	movq	0x28(%rsp), %r13
    16ad:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    16b2:      	testq	%rax, %rax
    16b5:      	sete	%al
    16b8:      	movq	(%rsp), %rdi
    16bc:      	movq	0x8(%rsp), %r9
    16c1:      	movq	0x10(%rsp), %r11
    16c6:      	movzbl	%al, %ebx
    16c9:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    16ce:      	xorl	%eax, %eax
    16d0:      	movzbl	%al, %ebx
    16d3:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    16d8:      	movl	$0x100, %esi            # imm = 0x100
    16dd:      	cmpl	$0x101, %eax            # imm = 0x101
    16e2:      	jb	0x1710 <generic_retkprobe_filter_arg+0x1710>
    16e4:      	movl	$0x200, %esi            # imm = 0x200
    16e9:      	cmpl	$0x201, %eax            # imm = 0x201
    16ee:      	jb	0x1710 <generic_retkprobe_filter_arg+0x1710>
    16f0:      	movl	$0x400, %esi            # imm = 0x400
    16f5:      	cmpl	$0x401, %eax            # imm = 0x401
    16fa:      	jb	0x1710 <generic_retkprobe_filter_arg+0x1710>
    16fc:      	xorl	%esi, %esi
    16fe:      	cmpl	$0x801, %eax            # imm = 0x801
    1703:      	setae	%sil
    1707:      	shll	$0xb, %esi
    170a:      	addl	$0x800, %esi            # imm = 0x800
    1710:      	leal	-0x100(%rsi), %eax
    1716:      	rorxl	$0x8, %eax, %eax
    171c:      	cmpl	$0x2, %eax
    171f:      	jg	0x1c20 <generic_retkprobe_filter_arg+0x1c20>
    1725:      	testl	%eax, %eax
    1727:      	je	0x22d0 <generic_retkprobe_filter_arg+0x22d0>
    172d:      	cmpl	$0x1, %eax
    1730:      	jne	0x22c9 <generic_retkprobe_filter_arg+0x22c9>
    1736:      	movl	$0x7, %eax
    173b:      	jmp	0x22dc <generic_retkprobe_filter_arg+0x22dc>
    1740:      	movq	%rsi, %rbx
    1743:      	movl	0x14(%r12), %eax
    1748:      	movl	%eax, 0x34(%rsp)
    174c:      	movl	$0x1, %eax
    1751:      	movq	(%rip), %rdi            # 0x1758 <generic_retkprobe_filter_arg+0x1758>
    1758:      	leaq	0x34(%rsp), %rsi
    175d:      	callq	*%rax
    175f:      	testq	%rax, %rax
    1762:      	je	0x1c10 <generic_retkprobe_filter_arg+0x1c10>
    1768:      	movq	%rax, %rdi
    176b:      	movl	$0x80, 0x70(%rsp)
    1773:      	movl	%ebx, 0x74(%rsp)
    1777:      	movl	%ebp, 0x78(%rsp)
    177b:      	movl	%r15d, 0x7c(%rsp)
    1780:      	shrq	$0x20, %r15
    1784:      	movl	%r15d, 0x80(%rsp)
    178c:      	movl	$0x1, %eax
    1791:      	movq	0x20(%rsp), %rsi
    1796:      	callq	*%rax
    1798:      	movl	0x4(%r12), %ecx
    179d:      	leal	-0x18(%rcx), %edx
    17a0:      	cmpl	$0x2, %edx
    17a3:      	jb	0x1e2b <generic_retkprobe_filter_arg+0x1e2b>
    17a9:      	addl	$-0xd, %ecx
    17ac:      	cmpl	$0x1, %ecx
    17af:      	movq	(%rsp), %rdi
    17b3:      	movq	0x8(%rsp), %r9
    17b8:      	movq	0x10(%rsp), %r11
    17bd:      	ja	0x17d2 <generic_retkprobe_filter_arg+0x17d2>
    17bf:      	testq	%rax, %rax
    17c2:      	setne	%al
    17c5:      	movzbl	%al, %ebx
    17c8:      	movq	0x28(%rsp), %r13
    17cd:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    17d2:      	xorl	%eax, %eax
    17d4:      	movzbl	%al, %ebx
    17d7:      	movq	0x28(%rsp), %r13
    17dc:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    17e1:      	cmpl	$0x1e, %eax
    17e4:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    17ea:      	movl	0x10(%r12), %eax
    17ef:      	andl	$0x7, %eax
    17f2:      	movl	%eax, %ecx
    17f4:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    17fd:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1803:      	movq	(%r15), %rcx
    1806:      	movq	0x5e78(%r14,%rax,8), %rax
    180e:      	andl	$0x7ff, %eax            # imm = 0x7FF
    1813:      	xorl	%ebx, %ebx
    1815:      	andnq	0x90(%r14,%rax), %rcx, %rax
    181f:      	setne	%bl
    1822:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    1827:      	movq	%r13, 0x18(%rsp)
    182c:      	cmpl	$0x21, %eax
    182f:      	je	0x1f9f <generic_retkprobe_filter_arg+0x1f9f>
    1835:      	movl	$0x0, %ebx
    183a:      	cmpl	$0x22, %eax
    183d:      	jne	0x3640 <generic_retkprobe_filter_arg+0x3640>
    1843:      	movl	$0x10, %r13d
    1849:      	movl	(%r12,%r13), %eax
    184d:      	movl	%eax, 0x38(%rsp)
    1851:      	movl	$0x1, %eax
    1856:      	leaq	0x38(%rsp), %rsi
    185b:      	movq	(%rip), %rdi            # 0x1862 <generic_retkprobe_filter_arg+0x1862>
    1862:      	callq	*%rax
    1864:      	testq	%rax, %rax
    1867:      	je	0x3630 <generic_retkprobe_filter_arg+0x3630>
    186d:      	movq	0x18(%rsp), %rdi
    1872:      	movq	%rax, %rsi
    1875:      	movq	%rbp, %rdx
    1878:      	callq	0x187d <generic_retkprobe_filter_arg+0x187d>
    187d:      	testl	%eax, %eax
    187f:      	jns	0x2c4c <generic_retkprobe_filter_arg+0x2c4c>
    1885:      	addq	$0x4, %r13
    1889:      	leal	-0x8(%r13), %eax
    188d:      	cmpl	0x8(%r12), %eax
    1892:      	movq	(%rsp), %rdi
    1896:      	movq	0x8(%rsp), %r9
    189b:      	movq	0x10(%rsp), %r11
    18a0:      	jae	0x1a9f <generic_retkprobe_filter_arg+0x1a9f>
    18a6:      	movl	$0x0, %ebx
    18ab:      	cmpq	$0x1a0, %r13            # imm = 0x1A0
    18b2:      	jne	0x1849 <generic_retkprobe_filter_arg+0x1849>
    18b4:      	jmp	0x3640 <generic_retkprobe_filter_arg+0x3640>
    18b9:      	movq	%r8, 0x18(%rsp)
    18be:      	movq	%rsi, %r15
    18c1:      	cmpl	$0x8, %eax
    18c4:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    18ca:      	movl	0x10(%r12), %eax
    18cf:      	movl	%eax, 0x38(%rsp)
    18d3:      	movl	$0x0, 0x70(%rsp)
    18db:      	movl	$0x1, %eax
    18e0:      	leaq	0x38(%rsp), %rsi
    18e5:      	movq	(%rip), %rdi            # 0x18ec <generic_retkprobe_filter_arg+0x18ec>
    18ec:      	callq	*%rax
    18ee:      	testb	%bpl, %bpl
    18f1:      	je	0x1bd3 <generic_retkprobe_filter_arg+0x1bd3>
    18f7:      	movq	%rax, %r13
    18fa:      	movl	$0x0, %ebx
    18ff:      	testq	%rax, %rax
    1902:      	je	0x1bd5 <generic_retkprobe_filter_arg+0x1bd5>
    1908:      	movl	$0x1, %eax
    190d:      	movq	0x20(%rsp), %rsi
    1912:      	movq	(%rip), %rdi            # 0x1919 <generic_retkprobe_filter_arg+0x1919>
    1919:      	callq	*%rax
    191b:      	testq	%rax, %rax
    191e:      	je	0x1bd3 <generic_retkprobe_filter_arg+0x1bd3>
    1924:      	movq	%r15, %rsi
    1927:      	movl	%esi, %ecx
    1929:      	shll	$0x3, %ecx
    192c:      	movl	%ecx, (%rax)
    192e:      	movq	%rax, %rdi
    1931:      	addq	$0x4, %rdi
    1935:      	movq	%rax, %rbx
    1938:      	movl	$0x4, %eax
    193d:      	movq	0x18(%rsp), %rdx
    1942:      	callq	*%rax
    1944:      	movl	$0x1, %eax
    1949:      	movq	%r13, %rdi
    194c:      	movq	%rbx, %rsi
    194f:      	callq	*%rax
    1951:      	xorl	%ebx, %ebx
    1953:      	testq	%rax, %rax
    1956:      	setne	%bl
    1959:      	jmp	0x1bd5 <generic_retkprobe_filter_arg+0x1bd5>
    195e:      	movzwl	(%r15), %ebx
    1962:      	movzbl	0x10(%r12), %eax
    1968:      	movl	%eax, 0x70(%rsp)
    196c:      	movl	$0x1, %eax
    1971:      	movq	0x20(%rsp), %rsi
    1976:      	movq	(%rip), %rdi            # 0x197d <generic_retkprobe_filter_arg+0x197d>
    197d:      	callq	*%rax
    197f:      	testq	%rax, %rax
    1982:      	je	0x19c8 <generic_retkprobe_filter_arg+0x19c8>
    1984:      	movq	%rax, %rdi
    1987:      	movq	%rbx, 0x38(%rsp)
    198c:      	movl	$0x1, %eax
    1991:      	leaq	0x38(%rsp), %rsi
    1996:      	callq	*%rax
    1998:      	movl	0x4(%r12), %edx
    199d:      	xorl	%ecx, %ecx
    199f:      	cmpl	$0x1d, %edx
    19a2:      	ja	0x2793 <generic_retkprobe_filter_arg+0x2793>
    19a8:      	movl	$0x30038400, %esi       # imm = 0x30038400
    19ad:      	btl	%edx, %esi
    19b0:      	movq	(%rsp), %rdi
    19b4:      	movq	0x8(%rsp), %r9
    19b9:      	movq	0x10(%rsp), %r11
    19be:      	jae	0x19dd <generic_retkprobe_filter_arg+0x19dd>
    19c0:      	testq	%rax, %rax
    19c3:      	setne	%cl
    19c6:      	jmp	0x19ed <generic_retkprobe_filter_arg+0x19ed>
    19c8:      	xorl	%ebx, %ebx
    19ca:      	movq	(%rsp), %rdi
    19ce:      	movq	0x8(%rsp), %r9
    19d3:      	movq	0x10(%rsp), %r11
    19d8:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    19dd:      	movl	$0xc0800, %esi          # imm = 0xC0800
    19e2:      	btl	%edx, %esi
    19e5:      	jae	0x19ed <generic_retkprobe_filter_arg+0x19ed>
    19e7:      	testq	%rax, %rax
    19ea:      	sete	%cl
    19ed:      	movzbl	%cl, %ebx
    19f0:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    19f5:      	movl	0x10(%r12), %eax
    19fa:      	movl	%eax, 0x38(%rsp)
    19fe:      	movl	$0x0, 0x70(%rsp)
    1a06:      	movl	$0x1, %eax
    1a0b:      	leaq	0x38(%rsp), %rsi
    1a10:      	movq	(%rip), %rdi            # 0x1a17 <generic_retkprobe_filter_arg+0x1a17>
    1a17:      	callq	*%rax
    1a19:      	testl	%ebp, %ebp
    1a1b:      	je	0x3630 <generic_retkprobe_filter_arg+0x3630>
    1a21:      	movq	%rax, %r15
    1a24:      	movl	$0x0, %ebx
    1a29:      	testq	%rax, %rax
    1a2c:      	je	0x3632 <generic_retkprobe_filter_arg+0x3632>
    1a32:      	movl	$0x1, %eax
    1a37:      	movq	0x20(%rsp), %rsi
    1a3c:      	movq	(%rip), %rdi            # 0x1a43 <generic_retkprobe_filter_arg+0x1a43>
    1a43:      	callq	*%rax
    1a45:      	testq	%rax, %rax
    1a48:      	je	0x3630 <generic_retkprobe_filter_arg+0x3630>
    1a4e:      	cmpl	$0xff, %ebp
    1a54:      	movl	$0xff, %ecx
    1a59:      	cmovael	%ecx, %ebp
    1a5c:      	leal	(,%rbp,8), %ecx
    1a63:      	movl	%ecx, (%rax)
    1a65:      	movq	%rax, %rdi
    1a68:      	addq	$0x4, %rdi
    1a6c:      	movq	%rax, %rbx
    1a6f:      	movl	$0x4, %eax
    1a74:      	movl	%ebp, %esi
    1a76:      	movq	%r13, %rdx
    1a79:      	callq	*%rax
    1a7b:      	movl	$0x1, %eax
    1a80:      	movq	%r15, %rdi
    1a83:      	movq	%rbx, %rsi
    1a86:      	jmp	0x3624 <generic_retkprobe_filter_arg+0x3624>
    1a8b:      	movl	$0x0, 0x70(%rsp)
    1a93:      	cmpl	$0x1000, %ebp           # imm = 0x1000
    1a99:      	jbe	0x2046 <generic_retkprobe_filter_arg+0x2046>
    1a9f:      	xorl	%ebx, %ebx
    1aa1:      	jmp	0x3640 <generic_retkprobe_filter_arg+0x3640>
    1aa6:      	movq	(%r15), %rax
    1aa9:      	cmpq	%rax, %rsi
    1aac:      	ja	0x1ab7 <generic_retkprobe_filter_arg+0x1ab7>
    1aae:      	cmpq	%rdx, %rax
    1ab1:      	jbe	0x271 <generic_retkprobe_filter_arg+0x271>
    1ab7:      	movl	0x8(%r12), %edx
    1abc:      	cmpl	$0x19, %edx
    1abf:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1ac5:      	movq	0x20(%r12), %rdi
    1aca:      	movq	0x28(%r12), %rsi
    1acf:      	cmpl	$0xc, %ecx
    1ad2:      	je	0x1add <generic_retkprobe_filter_arg+0x1add>
    1ad4:      	cmpl	$0xa, %ecx
    1ad7:      	jne	0x2178 <generic_retkprobe_filter_arg+0x2178>
    1add:      	cmpq	%rax, %rdi
    1ae0:      	movq	(%rsp), %rdi
    1ae4:      	jg	0x218a <generic_retkprobe_filter_arg+0x218a>
    1aea:      	cmpq	%rsi, %rax
    1aed:      	jle	0x271 <generic_retkprobe_filter_arg+0x271>
    1af3:      	jmp	0x218a <generic_retkprobe_filter_arg+0x218a>
    1af8:      	movq	(%r15), %rdx
    1afb:      	cmpq	%rdx, %rsi
    1afe:      	setbe	%sil
    1b02:      	cmpq	%rax, %rdx
    1b05:      	setbe	%al
    1b08:      	andb	%sil, %al
    1b0b:      	movl	0x8(%r12), %esi
    1b10:      	cmpl	$0x19, %esi
    1b13:      	jb	0x2fe6 <generic_retkprobe_filter_arg+0x2fe6>
    1b19:      	movq	0x20(%r12), %r8
    1b1e:      	movq	0x28(%r12), %rdi
    1b23:      	cmpl	$0xc, %ecx
    1b26:      	je	0x1b31 <generic_retkprobe_filter_arg+0x1b31>
    1b28:      	cmpl	$0xa, %ecx
    1b2b:      	jne	0x2097 <generic_retkprobe_filter_arg+0x2097>
    1b31:      	cmpq	%rdx, %r8
    1b34:      	setle	%r8b
    1b38:      	cmpq	%rdi, %rdx
    1b3b:      	setle	%dil
    1b3f:      	jmp	0x20a5 <generic_retkprobe_filter_arg+0x20a5>
    1b44:      	movzwl	0x26(%r15), %ebx
    1b49:      	movzbl	0x10(%r12), %eax
    1b4f:      	movl	%eax, 0x34(%rsp)
    1b53:      	movl	$0x1, %eax
    1b58:      	movq	(%rip), %rdi            # 0x1b5f <generic_retkprobe_filter_arg+0x1b5f>
    1b5f:      	leaq	0x34(%rsp), %rsi
    1b64:      	callq	*%rax
    1b66:      	testq	%rax, %rax
    1b69:      	je	0x2138 <generic_retkprobe_filter_arg+0x2138>
    1b6f:      	movq	%rax, %rdi
    1b72:      	movzwl	%bx, %eax
    1b75:      	movq	%rax, 0x70(%rsp)
    1b7a:      	movl	$0x1, %eax
    1b7f:      	movq	0x20(%rsp), %rsi
    1b84:      	callq	*%rax
    1b86:      	movl	0x4(%r12), %edx
    1b8b:      	xorl	%ecx, %ecx
    1b8d:      	cmpl	$0x1d, %edx
    1b90:      	ja	0x2a26 <generic_retkprobe_filter_arg+0x2a26>
    1b96:      	movl	$0x30038400, %esi       # imm = 0x30038400
    1b9b:      	btl	%edx, %esi
    1b9e:      	movq	(%rsp), %rdi
    1ba2:      	movq	0x8(%rsp), %r9
    1ba7:      	movq	0x10(%rsp), %r11
    1bac:      	jae	0x1bb6 <generic_retkprobe_filter_arg+0x1bb6>
    1bae:      	testq	%rax, %rax
    1bb1:      	setne	%cl
    1bb4:      	jmp	0x1bc6 <generic_retkprobe_filter_arg+0x1bc6>
    1bb6:      	movl	$0xc0800, %esi          # imm = 0xC0800
    1bbb:      	btl	%edx, %esi
    1bbe:      	jae	0x1bc6 <generic_retkprobe_filter_arg+0x1bc6>
    1bc0:      	testq	%rax, %rax
    1bc3:      	sete	%cl
    1bc6:      	movzbl	%cl, %ebx
    1bc9:      	movq	0x28(%rsp), %r13
    1bce:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    1bd3:      	xorl	%ebx, %ebx
    1bd5:      	movl	0x4(%r12), %eax
    1bda:      	cmpq	$0x25, %rax
    1bde:      	ja	0x2aeb <generic_retkprobe_filter_arg+0x2aeb>
    1be4:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    1bee:      	btq	%rax, %rcx
    1bf2:      	movq	0x28(%rsp), %r13
    1bf7:      	movq	(%rsp), %rdi
    1bfb:      	movq	0x8(%rsp), %r9
    1c00:      	movq	0x10(%rsp), %r11
    1c05:      	jb	0x3186 <generic_retkprobe_filter_arg+0x3186>
    1c0b:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    1c10:      	movl	0x4(%r12), %eax
    1c15:      	andl	$-0x2, %eax
    1c18:      	cmpl	$0x18, %eax
    1c1b:      	jmp	0x1e2e <generic_retkprobe_filter_arg+0x1e2e>
    1c20:      	cmpl	$0x3, %eax
    1c23:      	je	0x22d7 <generic_retkprobe_filter_arg+0x22d7>
    1c29:      	cmpl	$0x7, %eax
    1c2c:      	jne	0x22c9 <generic_retkprobe_filter_arg+0x22c9>
    1c32:      	movl	$0x9, %eax
    1c37:      	jmp	0x22dc <generic_retkprobe_filter_arg+0x22dc>
    1c3c:      	movl	$0x100, %esi            # imm = 0x100
    1c41:      	cmpl	$0x101, %eax            # imm = 0x101
    1c46:      	jb	0x1c74 <generic_retkprobe_filter_arg+0x1c74>
    1c48:      	movl	$0x200, %esi            # imm = 0x200
    1c4d:      	cmpl	$0x201, %eax            # imm = 0x201
    1c52:      	jb	0x1c74 <generic_retkprobe_filter_arg+0x1c74>
    1c54:      	movl	$0x400, %esi            # imm = 0x400
    1c59:      	cmpl	$0x401, %eax            # imm = 0x401
    1c5e:      	jb	0x1c74 <generic_retkprobe_filter_arg+0x1c74>
    1c60:      	xorl	%esi, %esi
    1c62:      	cmpl	$0x801, %eax            # imm = 0x801
    1c67:      	setae	%sil
    1c6b:      	shll	$0xb, %esi
    1c6e:      	addl	$0x800, %esi            # imm = 0x800
    1c74:      	leal	-0x100(%rsi), %eax
    1c7a:      	rorxl	$0x8, %eax, %eax
    1c80:      	cmpl	$0x2, %eax
    1c83:      	jg	0x1e4c <generic_retkprobe_filter_arg+0x1e4c>
    1c89:      	testl	%eax, %eax
    1c8b:      	je	0x2881 <generic_retkprobe_filter_arg+0x2881>
    1c91:      	cmpl	$0x1, %eax
    1c94:      	jne	0x287a <generic_retkprobe_filter_arg+0x287a>
    1c9a:      	movl	$0x7, %eax
    1c9f:      	jmp	0x288d <generic_retkprobe_filter_arg+0x288d>
    1ca4:      	cmpq	%rdx, (%r15)
    1ca7:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    1cad:      	jmp	0x1cb8 <generic_retkprobe_filter_arg+0x1cb8>
    1caf:      	cmpq	%rdx, (%r15)
    1cb2:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    1cb8:      	movl	0x8(%r12), %edx
    1cbd:      	cmpl	$0x11, %edx
    1cc0:      	jb	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    1cc6:      	movq	0x18(%r12), %rsi
    1ccb:      	cmpl	$0x2, %eax
    1cce:      	jle	0x1cea <generic_retkprobe_filter_arg+0x1cea>
    1cd0:      	leal	-0x3(%rax), %edi
    1cd3:      	cmpl	$0x2, %edi
    1cd6:      	jae	0x1d18 <generic_retkprobe_filter_arg+0x1d18>
    1cd8:      	cmpq	%rsi, (%r15)
    1cdb:      	movq	(%rsp), %rdi
    1cdf:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
    1ce5:      	jmp	0x2804 <generic_retkprobe_filter_arg+0x2804>
    1cea:      	cmpl	$0x1, %eax
    1ced:      	je	0x1d83 <generic_retkprobe_filter_arg+0x1d83>
    1cf3:      	cmpl	$0x2, %eax
    1cf6:      	jne	0x2804 <generic_retkprobe_filter_arg+0x2804>
    1cfc:      	cmpl	$0xc, %ecx
    1cff:      	je	0x1d0a <generic_retkprobe_filter_arg+0x1d0a>
    1d01:      	cmpl	$0xa, %ecx
    1d04:      	jne	0x27fb <generic_retkprobe_filter_arg+0x27fb>
    1d0a:      	cmpq	%rsi, (%r15)
    1d0d:      	jl	0x271 <generic_retkprobe_filter_arg+0x271>
    1d13:      	jmp	0x2804 <generic_retkprobe_filter_arg+0x2804>
    1d18:      	cmpl	$0xc, %eax
    1d1b:      	movq	(%rsp), %rdi
    1d1f:      	jne	0x2804 <generic_retkprobe_filter_arg+0x2804>
    1d25:      	testq	%rsi, (%r15)
    1d28:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
    1d2e:      	jmp	0x2804 <generic_retkprobe_filter_arg+0x2804>
    1d33:      	cmpl	$0xc, %eax
    1d36:      	jne	0x1e74 <generic_retkprobe_filter_arg+0x1e74>
    1d3c:      	movzbl	(%r15), %edx
    1d40:      	testl	%edx, %ecx
    1d42:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
    1d48:      	jmp	0x1e74 <generic_retkprobe_filter_arg+0x1e74>
    1d4d:      	cmpl	$0xc, %eax
    1d50:      	jne	0x1eb9 <generic_retkprobe_filter_arg+0x1eb9>
    1d56:      	movzwl	(%r15), %edx
    1d5a:      	testl	%edx, %ecx
    1d5c:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
    1d62:      	jmp	0x1eb9 <generic_retkprobe_filter_arg+0x1eb9>
    1d67:      	cmpl	$0x3, %eax
    1d6a:      	je	0x2474 <generic_retkprobe_filter_arg+0x2474>
    1d70:      	cmpl	$0x7, %eax
    1d73:      	jne	0x2466 <generic_retkprobe_filter_arg+0x2466>
    1d79:      	movl	$0x9, %eax
    1d7e:      	jmp	0x2479 <generic_retkprobe_filter_arg+0x2479>
    1d83:      	cmpl	$0xc, %ecx
    1d86:      	je	0x1d91 <generic_retkprobe_filter_arg+0x1d91>
    1d88:      	cmpl	$0xa, %ecx
    1d8b:      	jne	0x27f0 <generic_retkprobe_filter_arg+0x27f0>
    1d91:      	cmpq	%rsi, (%r15)
    1d94:      	jg	0x271 <generic_retkprobe_filter_arg+0x271>
    1d9a:      	jmp	0x2804 <generic_retkprobe_filter_arg+0x2804>
    1d9f:      	movl	0x8(%r12), %edx
    1da4:      	movzbl	(%r15), %ecx
    1da8:      	jmp	0x1db3 <generic_retkprobe_filter_arg+0x1db3>
    1daa:      	movl	0x8(%r12), %edx
    1daf:      	movzwl	(%r15), %ecx
    1db3:      	cmpl	%ecx, 0x10(%r12)
    1db8:      	setbe	%sil
    1dbc:      	cmpl	%ecx, 0x14(%r12)
    1dc1:      	setae	%al
    1dc4:      	andb	%sil, %al
    1dc7:      	cmpl	$0x11, %edx
    1dca:      	jb	0x2fe6 <generic_retkprobe_filter_arg+0x2fe6>
    1dd0:      	cmpl	%ecx, 0x18(%r12)
    1dd5:      	setbe	%sil
    1dd9:      	cmpl	%ecx, 0x1c(%r12)
    1dde:      	setae	%dil
    1de2:      	andb	%sil, %dil
    1de5:      	orb	%dil, %al
    1de8:      	cmpl	$0x19, %edx
    1deb:      	jb	0x2fe2 <generic_retkprobe_filter_arg+0x2fe2>
    1df1:      	cmpl	%ecx, 0x20(%r12)
    1df6:      	setbe	%sil
    1dfa:      	cmpl	%ecx, 0x24(%r12)
    1dff:      	setae	%dil
    1e03:      	andb	%sil, %dil
    1e06:      	orb	%dil, %al
    1e09:      	cmpl	$0x21, %edx
    1e0c:      	jb	0x2fe2 <generic_retkprobe_filter_arg+0x2fe2>
    1e12:      	cmpl	%ecx, 0x28(%r12)
    1e17:      	setbe	%dl
    1e1a:      	cmpl	%ecx, 0x2c(%r12)
    1e1f:      	setae	%cl
    1e22:      	andb	%dl, %cl
    1e24:      	orb	%cl, %al
    1e26:      	jmp	0x2fe2 <generic_retkprobe_filter_arg+0x2fe2>
    1e2b:      	testq	%rax, %rax
    1e2e:      	sete	%al
    1e31:      	movq	(%rsp), %rdi
    1e35:      	movq	0x8(%rsp), %r9
    1e3a:      	movq	0x10(%rsp), %r11
    1e3f:      	movzbl	%al, %ebx
    1e42:      	movq	0x28(%rsp), %r13
    1e47:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    1e4c:      	cmpl	$0x3, %eax
    1e4f:      	je	0x2888 <generic_retkprobe_filter_arg+0x2888>
    1e55:      	cmpl	$0x7, %eax
    1e58:      	jne	0x287a <generic_retkprobe_filter_arg+0x287a>
    1e5e:      	movl	$0x9, %eax
    1e63:      	jmp	0x288d <generic_retkprobe_filter_arg+0x288d>
    1e68:      	movzbl	(%r15), %edx
    1e6c:      	cmpl	%edx, %ecx
    1e6e:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    1e74:      	movl	0x8(%r12), %ecx
    1e79:      	cmpl	$0xd, %ecx
    1e7c:      	jb	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    1e82:      	movl	0x14(%r12), %edx
    1e87:      	cmpl	$0x2, %eax
    1e8a:      	jle	0x2283 <generic_retkprobe_filter_arg+0x2283>
    1e90:      	leal	-0x3(%rax), %esi
    1e93:      	cmpl	$0x2, %esi
    1e96:      	jae	0x2a39 <generic_retkprobe_filter_arg+0x2a39>
    1e9c:      	movzbl	(%r15), %esi
    1ea0:      	cmpl	%esi, %edx
    1ea2:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
    1ea8:      	jmp	0x2b1d <generic_retkprobe_filter_arg+0x2b1d>
    1ead:      	movzwl	(%r15), %edx
    1eb1:      	cmpl	%edx, %ecx
    1eb3:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    1eb9:      	movl	0x8(%r12), %ecx
    1ebe:      	cmpl	$0xd, %ecx
    1ec1:      	jb	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    1ec7:      	movl	0x14(%r12), %edx
    1ecc:      	cmpl	$0x2, %eax
    1ecf:      	jle	0x22a6 <generic_retkprobe_filter_arg+0x22a6>
    1ed5:      	leal	-0x3(%rax), %esi
    1ed8:      	cmpl	$0x2, %esi
    1edb:      	jae	0x2a53 <generic_retkprobe_filter_arg+0x2a53>
    1ee1:      	movzwl	(%r15), %esi
    1ee5:      	cmpl	%esi, %edx
    1ee7:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
    1eed:      	jmp	0x2b5d <generic_retkprobe_filter_arg+0x2b5d>
    1ef2:      	movl	(%r15), %eax
    1ef5:      	cmpl	%eax, %esi
    1ef7:      	ja	0x1f01 <generic_retkprobe_filter_arg+0x1f01>
    1ef9:      	cmpl	%edx, %eax
    1efb:      	jbe	0x271 <generic_retkprobe_filter_arg+0x271>
    1f01:      	movl	0x8(%r12), %edx
    1f06:      	cmpl	$0x11, %edx
    1f09:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    1f0f:      	movl	0x18(%r12), %edi
    1f14:      	movl	0x1c(%r12), %esi
    1f19:      	cmpl	$0xc, %ecx
    1f1c:      	ja	0x2693 <generic_retkprobe_filter_arg+0x2693>
    1f22:      	movl	$0x1402, %r8d           # imm = 0x1402
    1f28:      	btl	%ecx, %r8d
    1f2c:      	jae	0x2693 <generic_retkprobe_filter_arg+0x2693>
    1f32:      	cmpl	%eax, %edi
    1f34:      	movq	(%rsp), %rdi
    1f38:      	jg	0x26a3 <generic_retkprobe_filter_arg+0x26a3>
    1f3e:      	cmpl	%esi, %eax
    1f40:      	jle	0x271 <generic_retkprobe_filter_arg+0x271>
    1f46:      	jmp	0x26a3 <generic_retkprobe_filter_arg+0x26a3>
    1f4b:      	movl	(%r15), %edx
    1f4e:      	cmpl	%edx, %esi
    1f50:      	setbe	%sil
    1f54:      	cmpl	%eax, %edx
    1f56:      	setbe	%al
    1f59:      	andb	%sil, %al
    1f5c:      	movl	0x8(%r12), %esi
    1f61:      	cmpl	$0x11, %esi
    1f64:      	jb	0x2fe6 <generic_retkprobe_filter_arg+0x2fe6>
    1f6a:      	movl	0x18(%r12), %r8d
    1f6f:      	movl	0x1c(%r12), %edi
    1f74:      	cmpl	$0xc, %ecx
    1f77:      	ja	0x2636 <generic_retkprobe_filter_arg+0x2636>
    1f7d:      	movl	$0x1402, %r10d          # imm = 0x1402
    1f83:      	btl	%ecx, %r10d
    1f87:      	jae	0x2636 <generic_retkprobe_filter_arg+0x2636>
    1f8d:      	cmpl	%edx, %r8d
    1f90:      	setle	%r8b
    1f94:      	cmpl	%edi, %edx
    1f96:      	setle	%dil
    1f9a:      	jmp	0x2643 <generic_retkprobe_filter_arg+0x2643>
    1f9f:      	xorl	%ebx, %ebx
    1fa1:      	xorl	%r13d, %r13d
    1fa4:      	movl	0x10(%r12,%rbx,4), %eax
    1fa9:      	movl	%eax, 0x38(%rsp)
    1fad:      	movl	$0x1, %eax
    1fb2:      	leaq	0x38(%rsp), %rsi
    1fb7:      	movq	(%rip), %rdi            # 0x1fbe <generic_retkprobe_filter_arg+0x1fbe>
    1fbe:      	callq	*%rax
    1fc0:      	testq	%rax, %rax
    1fc3:      	je	0x2b91 <generic_retkprobe_filter_arg+0x2b91>
    1fc9:      	testl	%ebp, %ebp
    1fcb:      	movq	0x8(%rsp), %r9
    1fd0:      	movq	0x10(%rsp), %r11
    1fd5:      	je	0x201f <generic_retkprobe_filter_arg+0x201f>
    1fd7:      	movq	0x18(%rsp), %rdx
    1fdc:      	xorl	%ecx, %ecx
    1fde:      	jmp	0x1feb <generic_retkprobe_filter_arg+0x1feb>
    1fe0:      	incq	%rcx
    1fe3:      	incq	%rdx
    1fe6:      	cmpq	%rbp, %rcx
    1fe9:      	je	0x201f <generic_retkprobe_filter_arg+0x201f>
    1feb:      	xorl	%esi, %esi
    1fed:      	nopl	(%rax)
    1ff0:      	leaq	(%rcx,%rsi), %rdi
    1ff4:      	cmpq	%rbp, %rdi
    1ff7:      	jae	0x1fe0 <generic_retkprobe_filter_arg+0x1fe0>
    1ff9:      	movzbl	(%rax,%rsi), %edi
    1ffd:      	testb	%dil, %dil
    2000:      	je	0x2017 <generic_retkprobe_filter_arg+0x2017>
    2002:      	cmpq	$0x62, %rsi
    2006:      	ja	0x1fe0 <generic_retkprobe_filter_arg+0x1fe0>
    2008:      	leaq	0x1(%rsi), %r8
    200c:      	cmpb	%dil, (%rdx,%rsi)
    2010:      	movq	%r8, %rsi
    2013:      	je	0x1ff0 <generic_retkprobe_filter_arg+0x1ff0>
    2015:      	jmp	0x1fe0 <generic_retkprobe_filter_arg+0x1fe0>
    2017:      	testl	%ecx, %ecx
    2019:      	jns	0x2e31 <generic_retkprobe_filter_arg+0x2e31>
    201f:      	leal	0xc(%r13), %eax
    2023:      	cmpl	0x8(%r12), %eax
    2028:      	jae	0x203b <generic_retkprobe_filter_arg+0x203b>
    202a:      	addl	$0x4, %r13d
    202e:      	incq	%rbx
    2031:      	cmpq	$0x64, %rbx
    2035:      	jne	0x1fa4 <generic_retkprobe_filter_arg+0x1fa4>
    203b:      	xorl	%ebx, %ebx
    203d:      	movq	(%rsp), %rdi
    2041:      	jmp	0x3640 <generic_retkprobe_filter_arg+0x3640>
    2046:      	movzwl	%bp, %eax
    2049:      	cmpl	$0x90, %eax
    204e:      	ja	0x26e8 <generic_retkprobe_filter_arg+0x26e8>
    2054:      	testw	%bp, %bp
    2057:      	je	0x2069 <generic_retkprobe_filter_arg+0x2069>
    2059:      	movl	%ebp, %eax
    205b:      	movl	$0x18, %ecx
    2060:      	cltd
    2061:      	idivl	%ecx
    2063:      	movl	%ebp, %esi
    2065:      	testl	%edx, %edx
    2067:      	je	0x208b <generic_retkprobe_filter_arg+0x208b>
    2069:      	movl	%ebp, %eax
    206b:      	movl	$0x18, %ecx
    2070:      	cltd
    2071:      	idivl	%ecx
    2073:      	shll	$0x3, %eax
    2076:      	leal	(%rax,%rax,2), %eax
    2079:      	addl	$0x18, %eax
    207c:      	movzwl	%ax, %esi
    207f:      	cmpl	$0x90, %esi
    2085:      	ja	0x2720 <generic_retkprobe_filter_arg+0x2720>
    208b:      	movl	%esi, %eax
    208d:      	cltd
    208e:      	idivl	%ecx
    2090:      	decl	%eax
    2092:      	jmp	0x2e52 <generic_retkprobe_filter_arg+0x2e52>
    2097:      	cmpq	%rdx, %r8
    209a:      	setbe	%r8b
    209e:      	cmpq	%rdi, %rdx
    20a1:      	setbe	%dil
    20a5:      	andb	%r8b, %dil
    20a8:      	orb	%dil, %al
    20ab:      	cmpl	$0x29, %esi
    20ae:      	jb	0x2fe2 <generic_retkprobe_filter_arg+0x2fe2>
    20b4:      	movq	0x30(%r12), %r8
    20b9:      	movq	0x38(%r12), %rdi
    20be:      	cmpl	$0xc, %ecx
    20c1:      	je	0x20cc <generic_retkprobe_filter_arg+0x20cc>
    20c3:      	cmpl	$0xa, %ecx
    20c6:      	jne	0x2750 <generic_retkprobe_filter_arg+0x2750>
    20cc:      	cmpq	%rdx, %r8
    20cf:      	setle	%r8b
    20d3:      	cmpq	%rdi, %rdx
    20d6:      	setle	%dil
    20da:      	jmp	0x275e <generic_retkprobe_filter_arg+0x275e>
    20df:      	xorl	%ebx, %ebx
    20e1:      	cmpl	$0x29, %ecx
    20e4:      	jne	0x20ef <generic_retkprobe_filter_arg+0x20ef>
    20e6:      	testq	%rdx, %rdx
    20e9:      	je	0x20ef <generic_retkprobe_filter_arg+0x20ef>
    20eb:      	movzbl	0x3a(%rdx), %ebx
    20ef:      	cmpl	$0x29, %ecx
    20f2:      	je	0x20fd <generic_retkprobe_filter_arg+0x20fd>
    20f4:      	cmpl	$0x7, %ecx
    20f7:      	jne	0x2687 <generic_retkprobe_filter_arg+0x2687>
    20fd:      	movzbl	0x10(%r12), %eax
    2103:      	movl	%eax, 0x34(%rsp)
    2107:      	movl	$0x1, %eax
    210c:      	movq	(%rip), %rdi            # 0x2113 <generic_retkprobe_filter_arg+0x2113>
    2113:      	leaq	0x34(%rsp), %rsi
    2118:      	callq	*%rax
    211a:      	testq	%rax, %rax
    211d:      	je	0x2138 <generic_retkprobe_filter_arg+0x2138>
    211f:      	movq	%rax, %rdi
    2122:      	movl	%ebx, %eax
    2124:      	movq	%rax, 0x70(%rsp)
    2129:      	movl	$0x1, %eax
    212e:      	movq	0x20(%rsp), %rsi
    2133:      	jmp	0x1b84 <generic_retkprobe_filter_arg+0x1b84>
    2138:      	xorl	%ebx, %ebx
    213a:      	movq	(%rsp), %rdi
    213e:      	movq	0x8(%rsp), %r9
    2143:      	movq	0x10(%rsp), %r11
    2148:      	movq	0x28(%rsp), %r13
    214d:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    2152:      	xorl	%ebx, %ebx
    2154:      	movq	0x28(%rsp), %r13
    2159:      	movq	0x8(%rsp), %r9
    215e:      	movq	0x10(%rsp), %r11
    2163:      	movq	(%rsp), %rdi
    2167:      	jmp	0x3351 <generic_retkprobe_filter_arg+0x3351>
    216c:      	xorl	%ebx, %ebx
    216e:      	movq	0x10(%rsp), %r11
    2173:      	jmp	0x2623 <generic_retkprobe_filter_arg+0x2623>
    2178:      	cmpq	%rax, %rdi
    217b:      	movq	(%rsp), %rdi
    217f:      	ja	0x218a <generic_retkprobe_filter_arg+0x218a>
    2181:      	cmpq	%rsi, %rax
    2184:      	jbe	0x271 <generic_retkprobe_filter_arg+0x271>
    218a:      	cmpl	$0x29, %edx
    218d:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2193:      	movq	0x30(%r12), %rdi
    2198:      	movq	0x38(%r12), %rsi
    219d:      	cmpl	$0xc, %ecx
    21a0:      	je	0x21ab <generic_retkprobe_filter_arg+0x21ab>
    21a2:      	cmpl	$0xa, %ecx
    21a5:      	jne	0x27a6 <generic_retkprobe_filter_arg+0x27a6>
    21ab:      	cmpq	%rax, %rdi
    21ae:      	movq	(%rsp), %rdi
    21b2:      	jg	0x27b8 <generic_retkprobe_filter_arg+0x27b8>
    21b8:      	cmpq	%rsi, %rax
    21bb:      	jle	0x271 <generic_retkprobe_filter_arg+0x271>
    21c1:      	jmp	0x27b8 <generic_retkprobe_filter_arg+0x27b8>
    21c6:      	cmpl	%edx, (%r15)
    21c9:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    21cf:      	jmp	0x21da <generic_retkprobe_filter_arg+0x21da>
    21d1:      	cmpl	%edx, (%r15)
    21d4:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    21da:      	movl	0x8(%r12), %edx
    21df:      	cmpl	$0xd, %edx
    21e2:      	jb	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    21e8:      	movl	0x14(%r12), %esi
    21ed:      	cmpl	$0x2, %eax
    21f0:      	jle	0x220c <generic_retkprobe_filter_arg+0x220c>
    21f2:      	leal	-0x3(%rax), %edi
    21f5:      	cmpl	$0x2, %edi
    21f8:      	jae	0x2241 <generic_retkprobe_filter_arg+0x2241>
    21fa:      	cmpl	%esi, (%r15)
    21fd:      	movq	(%rsp), %rdi
    2201:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
    2207:      	jmp	0x2cbb <generic_retkprobe_filter_arg+0x2cbb>
    220c:      	cmpl	$0x1, %eax
    220f:      	je	0x225c <generic_retkprobe_filter_arg+0x225c>
    2211:      	cmpl	$0x2, %eax
    2214:      	jne	0x2cbb <generic_retkprobe_filter_arg+0x2cbb>
    221a:      	cmpl	$0xc, %ecx
    221d:      	ja	0x2cb2 <generic_retkprobe_filter_arg+0x2cb2>
    2223:      	movl	$0x1402, %r8d           # imm = 0x1402
    2229:      	btl	%ecx, %r8d
    222d:      	jae	0x2cb2 <generic_retkprobe_filter_arg+0x2cb2>
    2233:      	cmpl	%esi, (%r15)
    2236:      	jl	0x271 <generic_retkprobe_filter_arg+0x271>
    223c:      	jmp	0x2cbb <generic_retkprobe_filter_arg+0x2cbb>
    2241:      	cmpl	$0xc, %eax
    2244:      	movq	(%rsp), %rdi
    2248:      	jne	0x2cbb <generic_retkprobe_filter_arg+0x2cbb>
    224e:      	testl	%esi, (%r15)
    2251:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
    2257:      	jmp	0x2cbb <generic_retkprobe_filter_arg+0x2cbb>
    225c:      	cmpl	$0xc, %ecx
    225f:      	ja	0x2ca7 <generic_retkprobe_filter_arg+0x2ca7>
    2265:      	movl	$0x1402, %r8d           # imm = 0x1402
    226b:      	btl	%ecx, %r8d
    226f:      	jae	0x2ca7 <generic_retkprobe_filter_arg+0x2ca7>
    2275:      	cmpl	%esi, (%r15)
    2278:      	jg	0x271 <generic_retkprobe_filter_arg+0x271>
    227e:      	jmp	0x2cbb <generic_retkprobe_filter_arg+0x2cbb>
    2283:      	cmpl	$0x1, %eax
    2286:      	je	0x2b11 <generic_retkprobe_filter_arg+0x2b11>
    228c:      	cmpl	$0x2, %eax
    228f:      	jne	0x2b1d <generic_retkprobe_filter_arg+0x2b1d>
    2295:      	movzbl	(%r15), %esi
    2299:      	cmpl	%esi, %edx
    229b:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    22a1:      	jmp	0x2b1d <generic_retkprobe_filter_arg+0x2b1d>
    22a6:      	cmpl	$0x1, %eax
    22a9:      	je	0x2b51 <generic_retkprobe_filter_arg+0x2b51>
    22af:      	cmpl	$0x2, %eax
    22b2:      	jne	0x2b5d <generic_retkprobe_filter_arg+0x2b5d>
    22b8:      	movzwl	(%r15), %esi
    22bc:      	cmpl	%esi, %edx
    22be:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    22c4:      	jmp	0x2b5d <generic_retkprobe_filter_arg+0x2b5d>
    22c9:      	movl	$0xa, %eax
    22ce:      	jmp	0x22dc <generic_retkprobe_filter_arg+0x22dc>
    22d0:      	movl	$0x6, %eax
    22d5:      	jmp	0x22dc <generic_retkprobe_filter_arg+0x22dc>
    22d7:      	movl	$0x8, %eax
    22dc:      	movl	%eax, %ecx
    22de:      	andl	$0xf, %ecx
    22e1:      	movl	0x10(%r12,%rcx,4), %ecx
    22e6:      	cmpl	$-0x1, %ecx
    22e9:      	je	0x3153 <generic_retkprobe_filter_arg+0x3153>
    22ef:      	movl	%ecx, 0x6c(%rsp)
    22f3:      	movl	%eax, 0x18(%rsp)
    22f7:      	movq	%rsi, 0x88(%rsp)
    22ff:      	movl	$0x1, %eax
    2304:      	movq	(%rip), %rdi            # 0x230b <generic_retkprobe_filter_arg+0x230b>
    230b:      	movq	0x20(%rsp), %rbx
    2310:      	movq	%rbx, %rsi
    2313:      	callq	*%rax
    2315:      	movq	%rax, 0x60(%rsp)
    231a:      	movl	$0x1, %eax
    231f:      	movq	(%rip), %rdi            # 0x2326 <generic_retkprobe_filter_arg+0x2326>
    2326:      	movq	%rbx, %rsi
    2329:      	callq	*%rax
    232b:      	movq	0x60(%rsp), %rdx
    2330:      	testq	%rdx, %rdx
    2333:      	je	0x3153 <generic_retkprobe_filter_arg+0x3153>
    2339:      	movl	$0x0, %ebx
    233e:      	testq	%rax, %rax
    2341:      	movq	(%rsp), %rdi
    2345:      	movq	0x8(%rsp), %r9
    234a:      	movq	0x10(%rsp), %r11
    234f:      	je	0x3163 <generic_retkprobe_filter_arg+0x3163>
    2355:      	movq	%rdx, %rcx
    2358:      	movq	%rax, %rbx
    235b:      	movq	%r15, %rdx
    235e:      	addq	$0x4, %rdx
    2362:      	cmpl	$0x5, 0x18(%rsp)
    2367:      	jg	0x239c <generic_retkprobe_filter_arg+0x239c>
    2369:      	movq	%rcx, %r15
    236c:      	movb	%bpl, (%rcx)
    236f:      	leaq	0x1(%rcx), %rdi
    2373:      	movl	$0x4, %eax
    2378:      	movl	%ebp, %esi
    237a:      	callq	*%rax
    237c:      	movq	0x88(%rsp), %rsi
    2384:      	subl	%ebp, %esi
    2386:      	jbe	0x23d3 <generic_retkprobe_filter_arg+0x23d3>
    2388:      	leaq	(%r15,%rbp), %rdi
    238c:      	incq	%rdi
    238f:      	andl	$0xfff, %esi            # imm = 0xFFF
    2395:      	movl	$0x4, %eax
    239a:      	jmp	0x23ce <generic_retkprobe_filter_arg+0x23ce>
    239c:      	movq	%rcx, %r15
    239f:      	movw	%bp, (%rcx)
    23a2:      	leaq	0x2(%rcx), %rdi
    23a6:      	movl	$0x4, %eax
    23ab:      	movl	%ebp, %esi
    23ad:      	callq	*%rax
    23af:      	movq	0x88(%rsp), %rsi
    23b7:      	subl	%ebp, %esi
    23b9:      	jbe	0x23d3 <generic_retkprobe_filter_arg+0x23d3>
    23bb:      	leaq	(%r15,%rbp), %rdi
    23bf:      	addq	$0x2, %rdi
    23c3:      	andl	$0xfff, %esi            # imm = 0xFFF
    23c9:      	movl	$0x4, %eax
    23ce:      	movq	%rbx, %rdx
    23d1:      	callq	*%rax
    23d3:      	movl	0x6c(%rsp), %eax
    23d7:      	movl	%eax, 0x38(%rsp)
    23db:      	movl	0x18(%rsp), %eax
    23df:      	cmpl	$0x4, %eax
    23e2:      	movq	(%rsp), %rdi
    23e6:      	movq	0x8(%rsp), %r9
    23eb:      	movq	0x10(%rsp), %r11
    23f0:      	jle	0x242c <generic_retkprobe_filter_arg+0x242c>
    23f2:      	cmpl	$0x7, %eax
    23f5:      	jg	0x2a6d <generic_retkprobe_filter_arg+0x2a6d>
    23fb:      	cmpl	$0x5, %eax
    23fe:      	je	0x3111 <generic_retkprobe_filter_arg+0x3111>
    2404:      	cmpl	$0x6, %eax
    2407:      	je	0x30d8 <generic_retkprobe_filter_arg+0x30d8>
    240d:      	cmpl	$0x7, %eax
    2410:      	jne	0x911 <generic_retkprobe_filter_arg+0x911>
    2416:      	movl	$0x1, %eax
    241b:      	leaq	0x38(%rsp), %rsi
    2420:      	movq	(%rip), %rdi            # 0x2427 <generic_retkprobe_filter_arg+0x2427>
    2427:      	jmp	0x3135 <generic_retkprobe_filter_arg+0x3135>
    242c:      	cmpl	$0x1, %eax
    242f:      	jle	0x2ba6 <generic_retkprobe_filter_arg+0x2ba6>
    2435:      	cmpl	$0x2, %eax
    2438:      	je	0x30fe <generic_retkprobe_filter_arg+0x30fe>
    243e:      	cmpl	$0x3, %eax
    2441:      	je	0x30c5 <generic_retkprobe_filter_arg+0x30c5>
    2447:      	cmpl	$0x4, %eax
    244a:      	jne	0x911 <generic_retkprobe_filter_arg+0x911>
    2450:      	movl	$0x1, %eax
    2455:      	leaq	0x38(%rsp), %rsi
    245a:      	movq	(%rip), %rdi            # 0x2461 <generic_retkprobe_filter_arg+0x2461>
    2461:      	jmp	0x3135 <generic_retkprobe_filter_arg+0x3135>
    2466:      	movl	$0xa, %eax
    246b:      	jmp	0x2479 <generic_retkprobe_filter_arg+0x2479>
    246d:      	movl	$0x6, %eax
    2472:      	jmp	0x2479 <generic_retkprobe_filter_arg+0x2479>
    2474:      	movl	$0x8, %eax
    2479:      	movl	%eax, %ecx
    247b:      	andl	$0xf, %ecx
    247e:      	movl	0x10(%r12,%rcx,4), %ecx
    2483:      	cmpl	$-0x1, %ecx
    2486:      	je	0x2d90 <generic_retkprobe_filter_arg+0x2d90>
    248c:      	movl	%ecx, 0x6c(%rsp)
    2490:      	movl	%eax, 0x60(%rsp)
    2494:      	movq	%r8, 0x18(%rsp)
    2499:      	movq	%rsi, 0x88(%rsp)
    24a1:      	movl	$0x1, %eax
    24a6:      	movq	(%rip), %rdi            # 0x24ad <generic_retkprobe_filter_arg+0x24ad>
    24ad:      	movq	0x20(%rsp), %rbx
    24b2:      	movq	%rbx, %rsi
    24b5:      	callq	*%rax
    24b7:      	movq	%rax, %r15
    24ba:      	movl	$0x1, %eax
    24bf:      	movq	(%rip), %rdi            # 0x24c6 <generic_retkprobe_filter_arg+0x24c6>
    24c6:      	movq	%rbx, %rsi
    24c9:      	callq	*%rax
    24cb:      	testq	%r15, %r15
    24ce:      	je	0x3261 <generic_retkprobe_filter_arg+0x3261>
    24d4:      	movl	$0x0, %ebx
    24d9:      	testq	%rax, %rax
    24dc:      	movq	(%rsp), %rdi
    24e0:      	movq	0x8(%rsp), %r9
    24e5:      	movq	0x10(%rsp), %r11
    24ea:      	je	0x3271 <generic_retkprobe_filter_arg+0x3271>
    24f0:      	movq	%r15, %rcx
    24f3:      	movq	%rax, %r15
    24f6:      	cmpl	$0x5, 0x60(%rsp)
    24fb:      	jg	0x2537 <generic_retkprobe_filter_arg+0x2537>
    24fd:      	movb	%bpl, (%rcx)
    2500:      	movq	%rcx, %rbp
    2503:      	leaq	0x1(%rcx), %rdi
    2507:      	movl	$0x4, %eax
    250c:      	movq	0x88(%rsp), %rbx
    2514:      	movq	0x18(%rsp), %rdx
    2519:      	movl	%ebx, %esi
    251b:      	callq	*%rax
    251d:      	subl	%ebx, %r13d
    2520:      	jbe	0x2578 <generic_retkprobe_filter_arg+0x2578>
    2522:      	leaq	(%rbx,%rbp), %rdi
    2526:      	incq	%rdi
    2529:      	andl	$0xfff, %r13d           # imm = 0xFFF
    2530:      	movl	$0x4, %eax
    2535:      	jmp	0x2570 <generic_retkprobe_filter_arg+0x2570>
    2537:      	movq	0x88(%rsp), %rbx
    253f:      	movq	%rcx, %rbp
    2542:      	movw	%bx, (%rcx)
    2545:      	leaq	0x2(%rcx), %rdi
    2549:      	movl	$0x4, %eax
    254e:      	movq	0x18(%rsp), %rdx
    2553:      	movl	%ebx, %esi
    2555:      	callq	*%rax
    2557:      	subl	%ebx, %r13d
    255a:      	jbe	0x2578 <generic_retkprobe_filter_arg+0x2578>
    255c:      	leaq	(%rbx,%rbp), %rdi
    2560:      	addq	$0x2, %rdi
    2564:      	andl	$0xfff, %r13d           # imm = 0xFFF
    256b:      	movl	$0x4, %eax
    2570:      	movl	%r13d, %esi
    2573:      	movq	%r15, %rdx
    2576:      	callq	*%rax
    2578:      	movl	0x6c(%rsp), %eax
    257c:      	movl	%eax, 0x38(%rsp)
    2580:      	movl	0x60(%rsp), %eax
    2584:      	cmpl	$0x4, %eax
    2587:      	movq	(%rsp), %rdi
    258b:      	movq	0x8(%rsp), %r9
    2590:      	movq	0x10(%rsp), %r11
    2595:      	jle	0x25d1 <generic_retkprobe_filter_arg+0x25d1>
    2597:      	cmpl	$0x7, %eax
    259a:      	jg	0x2aba <generic_retkprobe_filter_arg+0x2aba>
    25a0:      	cmpl	$0x5, %eax
    25a3:      	je	0x321f <generic_retkprobe_filter_arg+0x321f>
    25a9:      	cmpl	$0x6, %eax
    25ac:      	je	0x31e6 <generic_retkprobe_filter_arg+0x31e6>
    25b2:      	cmpl	$0x7, %eax
    25b5:      	jne	0x2d90 <generic_retkprobe_filter_arg+0x2d90>
    25bb:      	movl	$0x1, %eax
    25c0:      	leaq	0x38(%rsp), %rsi
    25c5:      	movq	(%rip), %rdi            # 0x25cc <generic_retkprobe_filter_arg+0x25cc>
    25cc:      	jmp	0x3243 <generic_retkprobe_filter_arg+0x3243>
    25d1:      	cmpl	$0x1, %eax
    25d4:      	jle	0x2d6d <generic_retkprobe_filter_arg+0x2d6d>
    25da:      	cmpl	$0x2, %eax
    25dd:      	je	0x320c <generic_retkprobe_filter_arg+0x320c>
    25e3:      	cmpl	$0x3, %eax
    25e6:      	je	0x31d3 <generic_retkprobe_filter_arg+0x31d3>
    25ec:      	cmpl	$0x4, %eax
    25ef:      	jne	0x2d90 <generic_retkprobe_filter_arg+0x2d90>
    25f5:      	movl	$0x1, %eax
    25fa:      	leaq	0x38(%rsp), %rsi
    25ff:      	movq	(%rip), %rdi            # 0x2606 <generic_retkprobe_filter_arg+0x2606>
    2606:      	jmp	0x3243 <generic_retkprobe_filter_arg+0x3243>
    260b:      	movl	$0x1, %ebx
    2610:      	movq	0x28(%rsp), %r13
    2615:      	movq	(%rsp), %rdi
    2619:      	jmp	0x3351 <generic_retkprobe_filter_arg+0x3351>
    261e:      	movl	$0x1, %ebx
    2623:      	movq	0x28(%rsp), %r13
    2628:      	movq	(%rsp), %rdi
    262c:      	movq	0x8(%rsp), %r9
    2631:      	jmp	0x3351 <generic_retkprobe_filter_arg+0x3351>
    2636:      	cmpl	%edx, %r8d
    2639:      	setbe	%r8b
    263d:      	cmpl	%edi, %edx
    263f:      	setbe	%dil
    2643:      	andb	%r8b, %dil
    2646:      	orb	%dil, %al
    2649:      	cmpl	$0x19, %esi
    264c:      	jb	0x2fe2 <generic_retkprobe_filter_arg+0x2fe2>
    2652:      	movl	0x20(%r12), %r8d
    2657:      	movl	0x24(%r12), %edi
    265c:      	cmpl	$0xc, %ecx
    265f:      	ja	0x2bfe <generic_retkprobe_filter_arg+0x2bfe>
    2665:      	movl	$0x1402, %r10d          # imm = 0x1402
    266b:      	btl	%ecx, %r10d
    266f:      	jae	0x2bfe <generic_retkprobe_filter_arg+0x2bfe>
    2675:      	cmpl	%edx, %r8d
    2678:      	setle	%r8b
    267c:      	cmpl	%edi, %edx
    267e:      	setle	%dil
    2682:      	jmp	0x2c0b <generic_retkprobe_filter_arg+0x2c0b>
    2687:      	xorl	%ebx, %ebx
    2689:      	movq	0x28(%rsp), %r13
    268e:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    2693:      	cmpl	%eax, %edi
    2695:      	movq	(%rsp), %rdi
    2699:      	ja	0x26a3 <generic_retkprobe_filter_arg+0x26a3>
    269b:      	cmpl	%esi, %eax
    269d:      	jbe	0x271 <generic_retkprobe_filter_arg+0x271>
    26a3:      	cmpl	$0x19, %edx
    26a6:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    26ac:      	movl	0x20(%r12), %edi
    26b1:      	movl	0x24(%r12), %esi
    26b6:      	cmpl	$0xc, %ecx
    26b9:      	ja	0x2c56 <generic_retkprobe_filter_arg+0x2c56>
    26bf:      	movl	$0x1402, %r8d           # imm = 0x1402
    26c5:      	btl	%ecx, %r8d
    26c9:      	jae	0x2c56 <generic_retkprobe_filter_arg+0x2c56>
    26cf:      	cmpl	%eax, %edi
    26d1:      	movq	(%rsp), %rdi
    26d5:      	jg	0x2c66 <generic_retkprobe_filter_arg+0x2c66>
    26db:      	cmpl	%esi, %eax
    26dd:      	jle	0x271 <generic_retkprobe_filter_arg+0x271>
    26e3:      	jmp	0x2c66 <generic_retkprobe_filter_arg+0x2c66>
    26e8:      	movl	$0x100, %esi            # imm = 0x100
    26ed:      	cmpl	$0x101, %eax            # imm = 0x101
    26f2:      	jb	0x2720 <generic_retkprobe_filter_arg+0x2720>
    26f4:      	movl	$0x200, %esi            # imm = 0x200
    26f9:      	cmpl	$0x201, %eax            # imm = 0x201
    26fe:      	jb	0x2720 <generic_retkprobe_filter_arg+0x2720>
    2700:      	movl	$0x400, %esi            # imm = 0x400
    2705:      	cmpl	$0x401, %eax            # imm = 0x401
    270a:      	jb	0x2720 <generic_retkprobe_filter_arg+0x2720>
    270c:      	xorl	%esi, %esi
    270e:      	cmpl	$0x801, %eax            # imm = 0x801
    2713:      	setae	%sil
    2717:      	shll	$0xb, %esi
    271a:      	addl	$0x800, %esi            # imm = 0x800
    2720:      	leal	-0x100(%rsi), %eax
    2726:      	rorxl	$0x8, %eax, %eax
    272c:      	cmpl	$0x2, %eax
    272f:      	jg	0x2af5 <generic_retkprobe_filter_arg+0x2af5>
    2735:      	testl	%eax, %eax
    2737:      	je	0x2e46 <generic_retkprobe_filter_arg+0x2e46>
    273d:      	cmpl	$0x1, %eax
    2740:      	jne	0x2e3f <generic_retkprobe_filter_arg+0x2e3f>
    2746:      	movl	$0x7, %eax
    274b:      	jmp	0x2e52 <generic_retkprobe_filter_arg+0x2e52>
    2750:      	cmpq	%rdx, %r8
    2753:      	setbe	%r8b
    2757:      	cmpq	%rdi, %rdx
    275a:      	setbe	%dil
    275e:      	andb	%r8b, %dil
    2761:      	orb	%dil, %al
    2764:      	cmpl	$0x39, %esi
    2767:      	jb	0x2fe2 <generic_retkprobe_filter_arg+0x2fe2>
    276d:      	movq	0x40(%r12), %rdi
    2772:      	movq	0x48(%r12), %rsi
    2777:      	cmpl	$0xc, %ecx
    277a:      	je	0x2785 <generic_retkprobe_filter_arg+0x2785>
    277c:      	cmpl	$0xa, %ecx
    277f:      	jne	0x2d5f <generic_retkprobe_filter_arg+0x2d5f>
    2785:      	cmpq	%rdx, %rdi
    2788:      	setle	%cl
    278b:      	cmpq	%rsi, %rdx
    278e:      	jmp	0x2c44 <generic_retkprobe_filter_arg+0x2c44>
    2793:      	movq	(%rsp), %rdi
    2797:      	movq	0x8(%rsp), %r9
    279c:      	movq	0x10(%rsp), %r11
    27a1:      	jmp	0x19ed <generic_retkprobe_filter_arg+0x19ed>
    27a6:      	cmpq	%rax, %rdi
    27a9:      	movq	(%rsp), %rdi
    27ad:      	ja	0x27b8 <generic_retkprobe_filter_arg+0x27b8>
    27af:      	cmpq	%rsi, %rax
    27b2:      	jbe	0x271 <generic_retkprobe_filter_arg+0x271>
    27b8:      	cmpl	$0x39, %edx
    27bb:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    27c1:      	movq	0x40(%r12), %rsi
    27c6:      	movq	0x48(%r12), %rdx
    27cb:      	cmpl	$0xc, %ecx
    27ce:      	je	0x27d9 <generic_retkprobe_filter_arg+0x27d9>
    27d0:      	cmpl	$0xa, %ecx
    27d3:      	jne	0x2da6 <generic_retkprobe_filter_arg+0x2da6>
    27d9:      	cmpq	%rax, %rsi
    27dc:      	jg	0xb8 <generic_retkprobe_filter_arg+0xb8>
    27e2:      	cmpq	%rdx, %rax
    27e5:      	jle	0x271 <generic_retkprobe_filter_arg+0x271>
    27eb:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    27f0:      	cmpq	%rsi, (%r15)
    27f3:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    27f9:      	jmp	0x2804 <generic_retkprobe_filter_arg+0x2804>
    27fb:      	cmpq	%rsi, (%r15)
    27fe:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    2804:      	cmpl	$0x19, %edx
    2807:      	jb	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    280d:      	movq	0x20(%r12), %rsi
    2812:      	cmpl	$0x2, %eax
    2815:      	jle	0x2831 <generic_retkprobe_filter_arg+0x2831>
    2817:      	leal	-0x3(%rax), %edi
    281a:      	cmpl	$0x2, %edi
    281d:      	jae	0x285f <generic_retkprobe_filter_arg+0x285f>
    281f:      	cmpq	%rsi, (%r15)
    2822:      	movq	(%rsp), %rdi
    2826:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
    282c:      	jmp	0x3007 <generic_retkprobe_filter_arg+0x3007>
    2831:      	cmpl	$0x1, %eax
    2834:      	je	0x2a9e <generic_retkprobe_filter_arg+0x2a9e>
    283a:      	cmpl	$0x2, %eax
    283d:      	jne	0x3007 <generic_retkprobe_filter_arg+0x3007>
    2843:      	cmpl	$0xc, %ecx
    2846:      	je	0x2851 <generic_retkprobe_filter_arg+0x2851>
    2848:      	cmpl	$0xa, %ecx
    284b:      	jne	0x2ffe <generic_retkprobe_filter_arg+0x2ffe>
    2851:      	cmpq	%rsi, (%r15)
    2854:      	jl	0x271 <generic_retkprobe_filter_arg+0x271>
    285a:      	jmp	0x3007 <generic_retkprobe_filter_arg+0x3007>
    285f:      	cmpl	$0xc, %eax
    2862:      	movq	(%rsp), %rdi
    2866:      	jne	0x3007 <generic_retkprobe_filter_arg+0x3007>
    286c:      	testq	%rsi, (%r15)
    286f:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
    2875:      	jmp	0x3007 <generic_retkprobe_filter_arg+0x3007>
    287a:      	movl	$0xa, %eax
    287f:      	jmp	0x288d <generic_retkprobe_filter_arg+0x288d>
    2881:      	movl	$0x6, %eax
    2886:      	jmp	0x288d <generic_retkprobe_filter_arg+0x288d>
    2888:      	movl	$0x8, %eax
    288d:      	movl	%eax, %ecx
    288f:      	andl	$0xf, %ecx
    2892:      	movl	0x10(%r12,%rcx,4), %ecx
    2897:      	cmpl	$-0x1, %ecx
    289a:      	je	0x2e26 <generic_retkprobe_filter_arg+0x2e26>
    28a0:      	movl	%ecx, 0x6c(%rsp)
    28a4:      	movl	%eax, 0x88(%rsp)
    28ab:      	movq	%rsi, 0x98(%rsp)
    28b3:      	movl	$0x1, %eax
    28b8:      	movq	(%rip), %rdi            # 0x28bf <generic_retkprobe_filter_arg+0x28bf>
    28bf:      	movq	0x20(%rsp), %rbx
    28c4:      	movq	%rbx, %rsi
    28c7:      	callq	*%rax
    28c9:      	movq	%rax, %r15
    28cc:      	movl	$0x1, %eax
    28d1:      	movq	(%rip), %rdi            # 0x28d8 <generic_retkprobe_filter_arg+0x28d8>
    28d8:      	movq	%rbx, %rsi
    28db:      	callq	*%rax
    28dd:      	movq	%r15, 0x60(%rsp)
    28e2:      	testq	%r15, %r15
    28e5:      	je	0x3341 <generic_retkprobe_filter_arg+0x3341>
    28eb:      	movl	$0x0, %ebx
    28f0:      	testq	%rax, %rax
    28f3:      	movq	(%rsp), %rdi
    28f7:      	movq	0x8(%rsp), %r9
    28fc:      	movq	0x10(%rsp), %r11
    2901:      	je	0x3351 <generic_retkprobe_filter_arg+0x3351>
    2907:      	movq	%rax, %r15
    290a:      	movl	0x88(%rsp), %ebx
    2911:      	cmpl	$0x5, %ebx
    2914:      	jg	0x2958 <generic_retkprobe_filter_arg+0x2958>
    2916:      	movq	0x60(%rsp), %rax
    291b:      	movb	%bpl, (%rax)
    291e:      	leaq	0x1(%rax), %rdi
    2922:      	movl	$0x4, %eax
    2927:      	movq	0x18(%rsp), %rdx
    292c:      	movl	%ebp, %esi
    292e:      	callq	*%rax
    2930:      	movq	0x98(%rsp), %rsi
    2938:      	subl	%ebp, %esi
    293a:      	jbe	0x299b <generic_retkprobe_filter_arg+0x299b>
    293c:      	movq	0x60(%rsp), %rax
    2941:      	leaq	(%rax,%rbp), %rdi
    2945:      	incq	%rdi
    2948:      	andl	$0xfff, %esi            # imm = 0xFFF
    294e:      	movl	$0x4, %eax
    2953:      	movq	%r15, %rdx
    2956:      	jmp	0x2999 <generic_retkprobe_filter_arg+0x2999>
    2958:      	movq	0x60(%rsp), %rax
    295d:      	movw	%bp, (%rax)
    2960:      	leaq	0x2(%rax), %rdi
    2964:      	movl	$0x4, %eax
    2969:      	movq	0x18(%rsp), %rdx
    296e:      	movl	%ebp, %esi
    2970:      	callq	*%rax
    2972:      	movq	0x98(%rsp), %rsi
    297a:      	subl	%ebp, %esi
    297c:      	jbe	0x299b <generic_retkprobe_filter_arg+0x299b>
    297e:      	movq	0x60(%rsp), %rax
    2983:      	leaq	(%rax,%rbp), %rdi
    2987:      	addq	$0x2, %rdi
    298b:      	andl	$0xfff, %esi            # imm = 0xFFF
    2991:      	movl	$0x4, %eax
    2996:      	movq	%r15, %rdx
    2999:      	callq	*%rax
    299b:      	movl	0x6c(%rsp), %eax
    299f:      	movl	%eax, 0x38(%rsp)
    29a3:      	cmpl	$0x4, %ebx
    29a6:      	movq	0x8(%rsp), %r9
    29ab:      	movq	0x10(%rsp), %r11
    29b0:      	jle	0x29ec <generic_retkprobe_filter_arg+0x29ec>
    29b2:      	cmpl	$0x7, %ebx
    29b5:      	jg	0x2bcd <generic_retkprobe_filter_arg+0x2bcd>
    29bb:      	cmpl	$0x5, %ebx
    29be:      	je	0x32fd <generic_retkprobe_filter_arg+0x32fd>
    29c4:      	cmpl	$0x6, %ebx
    29c7:      	je	0x32c4 <generic_retkprobe_filter_arg+0x32c4>
    29cd:      	cmpl	$0x7, %ebx
    29d0:      	jne	0x2e26 <generic_retkprobe_filter_arg+0x2e26>
    29d6:      	movl	$0x1, %eax
    29db:      	leaq	0x38(%rsp), %rsi
    29e0:      	movq	(%rip), %rdi            # 0x29e7 <generic_retkprobe_filter_arg+0x29e7>
    29e7:      	jmp	0x3321 <generic_retkprobe_filter_arg+0x3321>
    29ec:      	cmpl	$0x1, %ebx
    29ef:      	jle	0x2e03 <generic_retkprobe_filter_arg+0x2e03>
    29f5:      	cmpl	$0x2, %ebx
    29f8:      	je	0x32ea <generic_retkprobe_filter_arg+0x32ea>
    29fe:      	cmpl	$0x3, %ebx
    2a01:      	je	0x32b1 <generic_retkprobe_filter_arg+0x32b1>
    2a07:      	cmpl	$0x4, %ebx
    2a0a:      	jne	0x2e26 <generic_retkprobe_filter_arg+0x2e26>
    2a10:      	movl	$0x1, %eax
    2a15:      	leaq	0x38(%rsp), %rsi
    2a1a:      	movq	(%rip), %rdi            # 0x2a21 <generic_retkprobe_filter_arg+0x2a21>
    2a21:      	jmp	0x3321 <generic_retkprobe_filter_arg+0x3321>
    2a26:      	movq	(%rsp), %rdi
    2a2a:      	movq	0x8(%rsp), %r9
    2a2f:      	movq	0x10(%rsp), %r11
    2a34:      	jmp	0x1bc6 <generic_retkprobe_filter_arg+0x1bc6>
    2a39:      	cmpl	$0xc, %eax
    2a3c:      	jne	0x2b1d <generic_retkprobe_filter_arg+0x2b1d>
    2a42:      	movzbl	(%r15), %esi
    2a46:      	testl	%esi, %edx
    2a48:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
    2a4e:      	jmp	0x2b1d <generic_retkprobe_filter_arg+0x2b1d>
    2a53:      	cmpl	$0xc, %eax
    2a56:      	jne	0x2b5d <generic_retkprobe_filter_arg+0x2b5d>
    2a5c:      	movzwl	(%r15), %esi
    2a60:      	testl	%esi, %edx
    2a62:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
    2a68:      	jmp	0x2b5d <generic_retkprobe_filter_arg+0x2b5d>
    2a6d:      	cmpl	$0x8, %eax
    2a70:      	je	0x3124 <generic_retkprobe_filter_arg+0x3124>
    2a76:      	cmpl	$0x9, %eax
    2a79:      	je	0x30eb <generic_retkprobe_filter_arg+0x30eb>
    2a7f:      	cmpl	$0xa, %eax
    2a82:      	jne	0x911 <generic_retkprobe_filter_arg+0x911>
    2a88:      	movl	$0x1, %eax
    2a8d:      	leaq	0x38(%rsp), %rsi
    2a92:      	movq	(%rip), %rdi            # 0x2a99 <generic_retkprobe_filter_arg+0x2a99>
    2a99:      	jmp	0x3135 <generic_retkprobe_filter_arg+0x3135>
    2a9e:      	cmpl	$0xc, %ecx
    2aa1:      	je	0x2aac <generic_retkprobe_filter_arg+0x2aac>
    2aa3:      	cmpl	$0xa, %ecx
    2aa6:      	jne	0x2ff3 <generic_retkprobe_filter_arg+0x2ff3>
    2aac:      	cmpq	%rsi, (%r15)
    2aaf:      	jg	0x271 <generic_retkprobe_filter_arg+0x271>
    2ab5:      	jmp	0x3007 <generic_retkprobe_filter_arg+0x3007>
    2aba:      	cmpl	$0x8, %eax
    2abd:      	je	0x3232 <generic_retkprobe_filter_arg+0x3232>
    2ac3:      	cmpl	$0x9, %eax
    2ac6:      	je	0x31f9 <generic_retkprobe_filter_arg+0x31f9>
    2acc:      	cmpl	$0xa, %eax
    2acf:      	jne	0x2d90 <generic_retkprobe_filter_arg+0x2d90>
    2ad5:      	movl	$0x1, %eax
    2ada:      	leaq	0x38(%rsp), %rsi
    2adf:      	movq	(%rip), %rdi            # 0x2ae6 <generic_retkprobe_filter_arg+0x2ae6>
    2ae6:      	jmp	0x3243 <generic_retkprobe_filter_arg+0x3243>
    2aeb:      	movq	0x28(%rsp), %r13
    2af0:      	jmp	0x19ca <generic_retkprobe_filter_arg+0x19ca>
    2af5:      	cmpl	$0x3, %eax
    2af8:      	je	0x2e4d <generic_retkprobe_filter_arg+0x2e4d>
    2afe:      	cmpl	$0x7, %eax
    2b01:      	jne	0x2e3f <generic_retkprobe_filter_arg+0x2e3f>
    2b07:      	movl	$0x9, %eax
    2b0c:      	jmp	0x2e52 <generic_retkprobe_filter_arg+0x2e52>
    2b11:      	movzbl	(%r15), %esi
    2b15:      	cmpl	%esi, %edx
    2b17:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    2b1d:      	cmpl	$0x11, %ecx
    2b20:      	jb	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    2b26:      	movl	0x18(%r12), %edx
    2b2b:      	cmpl	$0x2, %eax
    2b2e:      	jle	0x2dbd <generic_retkprobe_filter_arg+0x2dbd>
    2b34:      	leal	-0x3(%rax), %esi
    2b37:      	cmpl	$0x2, %esi
    2b3a:      	jae	0x307e <generic_retkprobe_filter_arg+0x307e>
    2b40:      	movzbl	(%r15), %esi
    2b44:      	cmpl	%esi, %edx
    2b46:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
    2b4c:      	jmp	0x3385 <generic_retkprobe_filter_arg+0x3385>
    2b51:      	movzwl	(%r15), %esi
    2b55:      	cmpl	%esi, %edx
    2b57:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    2b5d:      	cmpl	$0x11, %ecx
    2b60:      	jb	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    2b66:      	movl	0x18(%r12), %edx
    2b6b:      	cmpl	$0x2, %eax
    2b6e:      	jle	0x2de0 <generic_retkprobe_filter_arg+0x2de0>
    2b74:      	leal	-0x3(%rax), %esi
    2b77:      	cmpl	$0x2, %esi
    2b7a:      	jae	0x3098 <generic_retkprobe_filter_arg+0x3098>
    2b80:      	movzwl	(%r15), %esi
    2b84:      	cmpl	%esi, %edx
    2b86:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
    2b8c:      	jmp	0x33cc <generic_retkprobe_filter_arg+0x33cc>
    2b91:      	xorl	%ebx, %ebx
    2b93:      	movq	0x8(%rsp), %r9
    2b98:      	movq	0x10(%rsp), %r11
    2b9d:      	movq	(%rsp), %rdi
    2ba1:      	jmp	0x3640 <generic_retkprobe_filter_arg+0x3640>
    2ba6:      	testl	%eax, %eax
    2ba8:      	je	0x30b2 <generic_retkprobe_filter_arg+0x30b2>
    2bae:      	cmpl	$0x1, %eax
    2bb1:      	jne	0x911 <generic_retkprobe_filter_arg+0x911>
    2bb7:      	movl	$0x1, %eax
    2bbc:      	leaq	0x38(%rsp), %rsi
    2bc1:      	movq	(%rip), %rdi            # 0x2bc8 <generic_retkprobe_filter_arg+0x2bc8>
    2bc8:      	jmp	0x3135 <generic_retkprobe_filter_arg+0x3135>
    2bcd:      	cmpl	$0x8, %ebx
    2bd0:      	je	0x3310 <generic_retkprobe_filter_arg+0x3310>
    2bd6:      	cmpl	$0x9, %ebx
    2bd9:      	je	0x32d7 <generic_retkprobe_filter_arg+0x32d7>
    2bdf:      	cmpl	$0xa, %ebx
    2be2:      	jne	0x2e26 <generic_retkprobe_filter_arg+0x2e26>
    2be8:      	movl	$0x1, %eax
    2bed:      	leaq	0x38(%rsp), %rsi
    2bf2:      	movq	(%rip), %rdi            # 0x2bf9 <generic_retkprobe_filter_arg+0x2bf9>
    2bf9:      	jmp	0x3321 <generic_retkprobe_filter_arg+0x3321>
    2bfe:      	cmpl	%edx, %r8d
    2c01:      	setbe	%r8b
    2c05:      	cmpl	%edi, %edx
    2c07:      	setbe	%dil
    2c0b:      	andb	%r8b, %dil
    2c0e:      	orb	%dil, %al
    2c11:      	cmpl	$0x21, %esi
    2c14:      	jb	0x2fe2 <generic_retkprobe_filter_arg+0x2fe2>
    2c1a:      	movl	0x28(%r12), %edi
    2c1f:      	movl	0x2c(%r12), %esi
    2c24:      	cmpl	$0xc, %ecx
    2c27:      	ja	0x2fd4 <generic_retkprobe_filter_arg+0x2fd4>
    2c2d:      	movl	$0x1402, %r8d           # imm = 0x1402
    2c33:      	btl	%ecx, %r8d
    2c37:      	jae	0x2fd4 <generic_retkprobe_filter_arg+0x2fd4>
    2c3d:      	cmpl	%edx, %edi
    2c3f:      	setle	%cl
    2c42:      	cmpl	%esi, %edx
    2c44:      	setle	%dl
    2c47:      	jmp	0x2fde <generic_retkprobe_filter_arg+0x2fde>
    2c4c:      	movl	$0x1, %ebx
    2c51:      	jmp	0x3632 <generic_retkprobe_filter_arg+0x3632>
    2c56:      	cmpl	%eax, %edi
    2c58:      	movq	(%rsp), %rdi
    2c5c:      	ja	0x2c66 <generic_retkprobe_filter_arg+0x2c66>
    2c5e:      	cmpl	%esi, %eax
    2c60:      	jbe	0x271 <generic_retkprobe_filter_arg+0x271>
    2c66:      	cmpl	$0x21, %edx
    2c69:      	jb	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2c6f:      	movl	0x28(%r12), %esi
    2c74:      	movl	0x2c(%r12), %edx
    2c79:      	cmpl	$0xc, %ecx
    2c7c:      	ja	0x318f <generic_retkprobe_filter_arg+0x318f>
    2c82:      	movl	$0x1402, %r8d           # imm = 0x1402
    2c88:      	btl	%ecx, %r8d
    2c8c:      	jae	0x318f <generic_retkprobe_filter_arg+0x318f>
    2c92:      	cmpl	%eax, %esi
    2c94:      	jg	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2c9a:      	cmpl	%edx, %eax
    2c9c:      	jle	0x271 <generic_retkprobe_filter_arg+0x271>
    2ca2:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2ca7:      	cmpl	%esi, (%r15)
    2caa:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    2cb0:      	jmp	0x2cbb <generic_retkprobe_filter_arg+0x2cbb>
    2cb2:      	cmpl	%esi, (%r15)
    2cb5:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    2cbb:      	cmpl	$0x11, %edx
    2cbe:      	jb	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    2cc4:      	movl	0x18(%r12), %esi
    2cc9:      	cmpl	$0x2, %eax
    2ccc:      	jle	0x2ce8 <generic_retkprobe_filter_arg+0x2ce8>
    2cce:      	leal	-0x3(%rax), %edi
    2cd1:      	cmpl	$0x2, %edi
    2cd4:      	jae	0x2d1d <generic_retkprobe_filter_arg+0x2d1d>
    2cd6:      	cmpl	%esi, (%r15)
    2cd9:      	movq	(%rsp), %rdi
    2cdd:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
    2ce3:      	jmp	0x3457 <generic_retkprobe_filter_arg+0x3457>
    2ce8:      	cmpl	$0x1, %eax
    2ceb:      	je	0x2d38 <generic_retkprobe_filter_arg+0x2d38>
    2ced:      	cmpl	$0x2, %eax
    2cf0:      	jne	0x3457 <generic_retkprobe_filter_arg+0x3457>
    2cf6:      	cmpl	$0xc, %ecx
    2cf9:      	ja	0x344e <generic_retkprobe_filter_arg+0x344e>
    2cff:      	movl	$0x1402, %r8d           # imm = 0x1402
    2d05:      	btl	%ecx, %r8d
    2d09:      	jae	0x344e <generic_retkprobe_filter_arg+0x344e>
    2d0f:      	cmpl	%esi, (%r15)
    2d12:      	jl	0x271 <generic_retkprobe_filter_arg+0x271>
    2d18:      	jmp	0x3457 <generic_retkprobe_filter_arg+0x3457>
    2d1d:      	cmpl	$0xc, %eax
    2d20:      	movq	(%rsp), %rdi
    2d24:      	jne	0x3457 <generic_retkprobe_filter_arg+0x3457>
    2d2a:      	testl	%esi, (%r15)
    2d2d:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
    2d33:      	jmp	0x3457 <generic_retkprobe_filter_arg+0x3457>
    2d38:      	cmpl	$0xc, %ecx
    2d3b:      	ja	0x3443 <generic_retkprobe_filter_arg+0x3443>
    2d41:      	movl	$0x1402, %r8d           # imm = 0x1402
    2d47:      	btl	%ecx, %r8d
    2d4b:      	jae	0x3443 <generic_retkprobe_filter_arg+0x3443>
    2d51:      	cmpl	%esi, (%r15)
    2d54:      	jg	0x271 <generic_retkprobe_filter_arg+0x271>
    2d5a:      	jmp	0x3457 <generic_retkprobe_filter_arg+0x3457>
    2d5f:      	cmpq	%rdx, %rdi
    2d62:      	setbe	%cl
    2d65:      	cmpq	%rsi, %rdx
    2d68:      	jmp	0x2fdb <generic_retkprobe_filter_arg+0x2fdb>
    2d6d:      	testl	%eax, %eax
    2d6f:      	je	0x31c0 <generic_retkprobe_filter_arg+0x31c0>
    2d75:      	cmpl	$0x1, %eax
    2d78:      	jne	0x2d90 <generic_retkprobe_filter_arg+0x2d90>
    2d7a:      	movl	$0x1, %eax
    2d7f:      	leaq	0x38(%rsp), %rsi
    2d84:      	movq	(%rip), %rdi            # 0x2d8b <generic_retkprobe_filter_arg+0x2d8b>
    2d8b:      	jmp	0x3243 <generic_retkprobe_filter_arg+0x3243>
    2d90:      	xorl	%ebx, %ebx
    2d92:      	movl	0x4(%r12), %eax
    2d97:      	cmpq	$0x25, %rax
    2d9b:      	jbe	0x3280 <generic_retkprobe_filter_arg+0x3280>
    2da1:      	jmp	0x1bc9 <generic_retkprobe_filter_arg+0x1bc9>
    2da6:      	cmpq	%rax, %rsi
    2da9:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2daf:      	cmpq	%rdx, %rax
    2db2:      	jbe	0x271 <generic_retkprobe_filter_arg+0x271>
    2db8:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2dbd:      	cmpl	$0x1, %eax
    2dc0:      	je	0x3379 <generic_retkprobe_filter_arg+0x3379>
    2dc6:      	cmpl	$0x2, %eax
    2dc9:      	jne	0x3385 <generic_retkprobe_filter_arg+0x3385>
    2dcf:      	movzbl	(%r15), %esi
    2dd3:      	cmpl	%esi, %edx
    2dd5:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    2ddb:      	jmp	0x3385 <generic_retkprobe_filter_arg+0x3385>
    2de0:      	cmpl	$0x1, %eax
    2de3:      	je	0x33c0 <generic_retkprobe_filter_arg+0x33c0>
    2de9:      	cmpl	$0x2, %eax
    2dec:      	jne	0x33cc <generic_retkprobe_filter_arg+0x33cc>
    2df2:      	movzwl	(%r15), %esi
    2df6:      	cmpl	%esi, %edx
    2df8:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    2dfe:      	jmp	0x33cc <generic_retkprobe_filter_arg+0x33cc>
    2e03:      	testl	%ebx, %ebx
    2e05:      	je	0x329e <generic_retkprobe_filter_arg+0x329e>
    2e0b:      	cmpl	$0x1, %ebx
    2e0e:      	jne	0x2e26 <generic_retkprobe_filter_arg+0x2e26>
    2e10:      	movl	$0x1, %eax
    2e15:      	leaq	0x38(%rsp), %rsi
    2e1a:      	movq	(%rip), %rdi            # 0x2e21 <generic_retkprobe_filter_arg+0x2e21>
    2e21:      	jmp	0x3321 <generic_retkprobe_filter_arg+0x3321>
    2e26:      	xorl	%ebx, %ebx
    2e28:      	movq	(%rsp), %rdi
    2e2c:      	jmp	0x3351 <generic_retkprobe_filter_arg+0x3351>
    2e31:      	movl	$0x1, %ebx
    2e36:      	movq	(%rsp), %rdi
    2e3a:      	jmp	0x3640 <generic_retkprobe_filter_arg+0x3640>
    2e3f:      	movl	$0xa, %eax
    2e44:      	jmp	0x2e52 <generic_retkprobe_filter_arg+0x2e52>
    2e46:      	movl	$0x6, %eax
    2e4b:      	jmp	0x2e52 <generic_retkprobe_filter_arg+0x2e52>
    2e4d:      	movl	$0x8, %eax
    2e52:      	movl	%eax, %ecx
    2e54:      	andl	$0xf, %ecx
    2e57:      	movl	0x10(%r12,%rcx,4), %ecx
    2e5c:      	cmpl	$-0x1, %ecx
    2e5f:      	je	0x3630 <generic_retkprobe_filter_arg+0x3630>
    2e65:      	movl	%ecx, 0x6c(%rsp)
    2e69:      	movl	%eax, 0x88(%rsp)
    2e70:      	movq	%rsi, 0x60(%rsp)
    2e75:      	movl	$0x1, %eax
    2e7a:      	movq	(%rip), %rdi            # 0x2e81 <generic_retkprobe_filter_arg+0x2e81>
    2e81:      	movq	0x20(%rsp), %rbx
    2e86:      	movq	%rbx, %rsi
    2e89:      	callq	*%rax
    2e8b:      	movq	%rax, %r15
    2e8e:      	movl	$0x1, %eax
    2e93:      	movq	(%rip), %rdi            # 0x2e9a <generic_retkprobe_filter_arg+0x2e9a>
    2e9a:      	movq	%rbx, %rsi
    2e9d:      	callq	*%rax
    2e9f:      	movq	%r15, 0x18(%rsp)
    2ea4:      	testq	%r15, %r15
    2ea7:      	je	0x3630 <generic_retkprobe_filter_arg+0x3630>
    2ead:      	movl	$0x0, %ebx
    2eb2:      	testq	%rax, %rax
    2eb5:      	movq	(%rsp), %rdi
    2eb9:      	movq	0x8(%rsp), %r9
    2ebe:      	movq	0x10(%rsp), %r11
    2ec3:      	je	0x3640 <generic_retkprobe_filter_arg+0x3640>
    2ec9:      	movq	%rax, %r15
    2ecc:      	movl	0x88(%rsp), %ebx
    2ed3:      	cmpl	$0x5, %ebx
    2ed6:      	jg	0x2f15 <generic_retkprobe_filter_arg+0x2f15>
    2ed8:      	movq	0x18(%rsp), %rax
    2edd:      	movb	%bpl, (%rax)
    2ee0:      	leaq	0x1(%rax), %rdi
    2ee4:      	movl	$0x4, %eax
    2ee9:      	movl	%ebp, %esi
    2eeb:      	movq	%r13, %rdx
    2eee:      	callq	*%rax
    2ef0:      	movq	0x60(%rsp), %rsi
    2ef5:      	subl	%ebp, %esi
    2ef7:      	jbe	0x2f53 <generic_retkprobe_filter_arg+0x2f53>
    2ef9:      	movq	0x18(%rsp), %rax
    2efe:      	leaq	(%rax,%rbp), %rdi
    2f02:      	incq	%rdi
    2f05:      	andl	$0xfff, %esi            # imm = 0xFFF
    2f0b:      	movl	$0x4, %eax
    2f10:      	movq	%r15, %rdx
    2f13:      	jmp	0x2f51 <generic_retkprobe_filter_arg+0x2f51>
    2f15:      	movq	0x18(%rsp), %rax
    2f1a:      	movw	%bp, (%rax)
    2f1d:      	leaq	0x2(%rax), %rdi
    2f21:      	movl	$0x4, %eax
    2f26:      	movl	%ebp, %esi
    2f28:      	movq	%r13, %rdx
    2f2b:      	callq	*%rax
    2f2d:      	movq	0x60(%rsp), %rsi
    2f32:      	subl	%ebp, %esi
    2f34:      	jbe	0x2f53 <generic_retkprobe_filter_arg+0x2f53>
    2f36:      	movq	0x18(%rsp), %rax
    2f3b:      	leaq	(%rax,%rbp), %rdi
    2f3f:      	addq	$0x2, %rdi
    2f43:      	andl	$0xfff, %esi            # imm = 0xFFF
    2f49:      	movl	$0x4, %eax
    2f4e:      	movq	%r15, %rdx
    2f51:      	callq	*%rax
    2f53:      	movl	0x6c(%rsp), %eax
    2f57:      	movl	%eax, 0x38(%rsp)
    2f5b:      	cmpl	$0x4, %ebx
    2f5e:      	jle	0x2f9a <generic_retkprobe_filter_arg+0x2f9a>
    2f60:      	cmpl	$0x7, %ebx
    2f63:      	jg	0x3412 <generic_retkprobe_filter_arg+0x3412>
    2f69:      	cmpl	$0x5, %ebx
    2f6c:      	je	0x35ec <generic_retkprobe_filter_arg+0x35ec>
    2f72:      	cmpl	$0x6, %ebx
    2f75:      	je	0x35b3 <generic_retkprobe_filter_arg+0x35b3>
    2f7b:      	cmpl	$0x7, %ebx
    2f7e:      	jne	0x3630 <generic_retkprobe_filter_arg+0x3630>
    2f84:      	movl	$0x1, %eax
    2f89:      	leaq	0x38(%rsp), %rsi
    2f8e:      	movq	(%rip), %rdi            # 0x2f95 <generic_retkprobe_filter_arg+0x2f95>
    2f95:      	jmp	0x3610 <generic_retkprobe_filter_arg+0x3610>
    2f9a:      	cmpl	$0x1, %ebx
    2f9d:      	jle	0x34f8 <generic_retkprobe_filter_arg+0x34f8>
    2fa3:      	cmpl	$0x2, %ebx
    2fa6:      	je	0x35d9 <generic_retkprobe_filter_arg+0x35d9>
    2fac:      	cmpl	$0x3, %ebx
    2faf:      	je	0x35a0 <generic_retkprobe_filter_arg+0x35a0>
    2fb5:      	cmpl	$0x4, %ebx
    2fb8:      	jne	0x3630 <generic_retkprobe_filter_arg+0x3630>
    2fbe:      	movl	$0x1, %eax
    2fc3:      	leaq	0x38(%rsp), %rsi
    2fc8:      	movq	(%rip), %rdi            # 0x2fcf <generic_retkprobe_filter_arg+0x2fcf>
    2fcf:      	jmp	0x3610 <generic_retkprobe_filter_arg+0x3610>
    2fd4:      	cmpl	%edx, %edi
    2fd6:      	setbe	%cl
    2fd9:      	cmpl	%esi, %edx
    2fdb:      	setbe	%dl
    2fde:      	andb	%cl, %dl
    2fe0:      	orb	%dl, %al
    2fe2:      	movq	(%rsp), %rdi
    2fe6:      	testb	%al, %al
    2fe8:      	je	0x271 <generic_retkprobe_filter_arg+0x271>
    2fee:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    2ff3:      	cmpq	%rsi, (%r15)
    2ff6:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    2ffc:      	jmp	0x3007 <generic_retkprobe_filter_arg+0x3007>
    2ffe:      	cmpq	%rsi, (%r15)
    3001:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    3007:      	cmpl	$0x21, %edx
    300a:      	jb	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    3010:      	movq	0x28(%r12), %rdx
    3015:      	cmpl	$0x2, %eax
    3018:      	jle	0x3042 <generic_retkprobe_filter_arg+0x3042>
    301a:      	leal	-0x3(%rax), %ecx
    301d:      	cmpl	$0x2, %ecx
    3020:      	jb	0x3070 <generic_retkprobe_filter_arg+0x3070>
    3022:      	cmpl	$0x6, %eax
    3025:      	je	0x271 <generic_retkprobe_filter_arg+0x271>
    302b:      	cmpl	$0xc, %eax
    302e:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    3034:      	testq	%rdx, (%r15)
    3037:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
    303d:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    3042:      	cmpl	$0x1, %eax
    3045:      	je	0x31a4 <generic_retkprobe_filter_arg+0x31a4>
    304b:      	cmpl	$0x2, %eax
    304e:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    3054:      	cmpl	$0xc, %ecx
    3057:      	je	0x3062 <generic_retkprobe_filter_arg+0x3062>
    3059:      	cmpl	$0xa, %ecx
    305c:      	jne	0x3571 <generic_retkprobe_filter_arg+0x3571>
    3062:      	cmpq	%rdx, (%r15)
    3065:      	jl	0x271 <generic_retkprobe_filter_arg+0x271>
    306b:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    3070:      	cmpq	%rdx, (%r15)
    3073:      	jne	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    3079:      	jmp	0x24f <generic_retkprobe_filter_arg+0x24f>
    307e:      	cmpl	$0xc, %eax
    3081:      	jne	0x3385 <generic_retkprobe_filter_arg+0x3385>
    3087:      	movzbl	(%r15), %esi
    308b:      	testl	%esi, %edx
    308d:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
    3093:      	jmp	0x3385 <generic_retkprobe_filter_arg+0x3385>
    3098:      	cmpl	$0xc, %eax
    309b:      	jne	0x33cc <generic_retkprobe_filter_arg+0x33cc>
    30a1:      	movzwl	(%r15), %esi
    30a5:      	testl	%esi, %edx
    30a7:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
    30ad:      	jmp	0x33cc <generic_retkprobe_filter_arg+0x33cc>
    30b2:      	movl	$0x1, %eax
    30b7:      	movq	(%rip), %rdi            # 0x30be <generic_retkprobe_filter_arg+0x30be>
    30be:      	leaq	0x38(%rsp), %rsi
    30c3:      	jmp	0x3135 <generic_retkprobe_filter_arg+0x3135>
    30c5:      	movl	$0x1, %eax
    30ca:      	leaq	0x38(%rsp), %rsi
    30cf:      	movq	(%rip), %rdi            # 0x30d6 <generic_retkprobe_filter_arg+0x30d6>
    30d6:      	jmp	0x3135 <generic_retkprobe_filter_arg+0x3135>
    30d8:      	movl	$0x1, %eax
    30dd:      	leaq	0x38(%rsp), %rsi
    30e2:      	movq	(%rip), %rdi            # 0x30e9 <generic_retkprobe_filter_arg+0x30e9>
    30e9:      	jmp	0x3135 <generic_retkprobe_filter_arg+0x3135>
    30eb:      	movl	$0x1, %eax
    30f0:      	leaq	0x38(%rsp), %rsi
    30f5:      	movq	(%rip), %rdi            # 0x30fc <generic_retkprobe_filter_arg+0x30fc>
    30fc:      	jmp	0x3135 <generic_retkprobe_filter_arg+0x3135>
    30fe:      	movl	$0x1, %eax
    3103:      	leaq	0x38(%rsp), %rsi
    3108:      	movq	(%rip), %rdi            # 0x310f <generic_retkprobe_filter_arg+0x310f>
    310f:      	jmp	0x3135 <generic_retkprobe_filter_arg+0x3135>
    3111:      	movl	$0x1, %eax
    3116:      	leaq	0x38(%rsp), %rsi
    311b:      	movq	(%rip), %rdi            # 0x3122 <generic_retkprobe_filter_arg+0x3122>
    3122:      	jmp	0x3135 <generic_retkprobe_filter_arg+0x3135>
    3124:      	movl	$0x1, %eax
    3129:      	leaq	0x38(%rsp), %rsi
    312e:      	movq	(%rip), %rdi            # 0x3135 <generic_retkprobe_filter_arg+0x3135>
    3135:      	callq	*%rax
    3137:      	testq	%rax, %rax
    313a:      	je	0x3153 <generic_retkprobe_filter_arg+0x3153>
    313c:      	movq	%rax, %rdi
    313f:      	movl	$0x1, %eax
    3144:      	movq	%r15, %rsi
    3147:      	callq	*%rax
    3149:      	xorl	%ebx, %ebx
    314b:      	testq	%rax, %rax
    314e:      	setne	%bl
    3151:      	jmp	0x3155 <generic_retkprobe_filter_arg+0x3155>
    3153:      	xorl	%ebx, %ebx
    3155:      	movq	(%rsp), %rdi
    3159:      	movq	0x8(%rsp), %r9
    315e:      	movq	0x10(%rsp), %r11
    3163:      	movl	0x4(%r12), %eax
    3168:      	cmpq	$0x25, %rax
    316c:      	ja	0x260 <generic_retkprobe_filter_arg+0x260>
    3172:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    317c:      	btq	%rax, %rcx
    3180:      	jae	0x260 <generic_retkprobe_filter_arg+0x260>
    3186:      	xorq	$0x1, %rbx
    318a:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    318f:      	cmpl	%eax, %esi
    3191:      	ja	0xb8 <generic_retkprobe_filter_arg+0xb8>
    3197:      	cmpl	%edx, %eax
    3199:      	jbe	0x271 <generic_retkprobe_filter_arg+0x271>
    319f:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    31a4:      	cmpl	$0xc, %ecx
    31a7:      	je	0x31b2 <generic_retkprobe_filter_arg+0x31b2>
    31a9:      	cmpl	$0xa, %ecx
    31ac:      	jne	0x357f <generic_retkprobe_filter_arg+0x357f>
    31b2:      	cmpq	%rdx, (%r15)
    31b5:      	jg	0x271 <generic_retkprobe_filter_arg+0x271>
    31bb:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    31c0:      	movl	$0x1, %eax
    31c5:      	movq	(%rip), %rdi            # 0x31cc <generic_retkprobe_filter_arg+0x31cc>
    31cc:      	leaq	0x38(%rsp), %rsi
    31d1:      	jmp	0x3243 <generic_retkprobe_filter_arg+0x3243>
    31d3:      	movl	$0x1, %eax
    31d8:      	leaq	0x38(%rsp), %rsi
    31dd:      	movq	(%rip), %rdi            # 0x31e4 <generic_retkprobe_filter_arg+0x31e4>
    31e4:      	jmp	0x3243 <generic_retkprobe_filter_arg+0x3243>
    31e6:      	movl	$0x1, %eax
    31eb:      	leaq	0x38(%rsp), %rsi
    31f0:      	movq	(%rip), %rdi            # 0x31f7 <generic_retkprobe_filter_arg+0x31f7>
    31f7:      	jmp	0x3243 <generic_retkprobe_filter_arg+0x3243>
    31f9:      	movl	$0x1, %eax
    31fe:      	leaq	0x38(%rsp), %rsi
    3203:      	movq	(%rip), %rdi            # 0x320a <generic_retkprobe_filter_arg+0x320a>
    320a:      	jmp	0x3243 <generic_retkprobe_filter_arg+0x3243>
    320c:      	movl	$0x1, %eax
    3211:      	leaq	0x38(%rsp), %rsi
    3216:      	movq	(%rip), %rdi            # 0x321d <generic_retkprobe_filter_arg+0x321d>
    321d:      	jmp	0x3243 <generic_retkprobe_filter_arg+0x3243>
    321f:      	movl	$0x1, %eax
    3224:      	leaq	0x38(%rsp), %rsi
    3229:      	movq	(%rip), %rdi            # 0x3230 <generic_retkprobe_filter_arg+0x3230>
    3230:      	jmp	0x3243 <generic_retkprobe_filter_arg+0x3243>
    3232:      	movl	$0x1, %eax
    3237:      	leaq	0x38(%rsp), %rsi
    323c:      	movq	(%rip), %rdi            # 0x3243 <generic_retkprobe_filter_arg+0x3243>
    3243:      	callq	*%rax
    3245:      	testq	%rax, %rax
    3248:      	je	0x3261 <generic_retkprobe_filter_arg+0x3261>
    324a:      	movq	%rax, %rdi
    324d:      	movl	$0x1, %eax
    3252:      	movq	%rbp, %rsi
    3255:      	callq	*%rax
    3257:      	xorl	%ebx, %ebx
    3259:      	testq	%rax, %rax
    325c:      	setne	%bl
    325f:      	jmp	0x3263 <generic_retkprobe_filter_arg+0x3263>
    3261:      	xorl	%ebx, %ebx
    3263:      	movq	(%rsp), %rdi
    3267:      	movq	0x8(%rsp), %r9
    326c:      	movq	0x10(%rsp), %r11
    3271:      	movl	0x4(%r12), %eax
    3276:      	cmpq	$0x25, %rax
    327a:      	ja	0x1bc9 <generic_retkprobe_filter_arg+0x1bc9>
    3280:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    328a:      	btq	%rax, %rcx
    328e:      	movq	0x28(%rsp), %r13
    3293:      	jb	0x3186 <generic_retkprobe_filter_arg+0x3186>
    3299:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    329e:      	movl	$0x1, %eax
    32a3:      	movq	(%rip), %rdi            # 0x32aa <generic_retkprobe_filter_arg+0x32aa>
    32aa:      	leaq	0x38(%rsp), %rsi
    32af:      	jmp	0x3321 <generic_retkprobe_filter_arg+0x3321>
    32b1:      	movl	$0x1, %eax
    32b6:      	leaq	0x38(%rsp), %rsi
    32bb:      	movq	(%rip), %rdi            # 0x32c2 <generic_retkprobe_filter_arg+0x32c2>
    32c2:      	jmp	0x3321 <generic_retkprobe_filter_arg+0x3321>
    32c4:      	movl	$0x1, %eax
    32c9:      	leaq	0x38(%rsp), %rsi
    32ce:      	movq	(%rip), %rdi            # 0x32d5 <generic_retkprobe_filter_arg+0x32d5>
    32d5:      	jmp	0x3321 <generic_retkprobe_filter_arg+0x3321>
    32d7:      	movl	$0x1, %eax
    32dc:      	leaq	0x38(%rsp), %rsi
    32e1:      	movq	(%rip), %rdi            # 0x32e8 <generic_retkprobe_filter_arg+0x32e8>
    32e8:      	jmp	0x3321 <generic_retkprobe_filter_arg+0x3321>
    32ea:      	movl	$0x1, %eax
    32ef:      	leaq	0x38(%rsp), %rsi
    32f4:      	movq	(%rip), %rdi            # 0x32fb <generic_retkprobe_filter_arg+0x32fb>
    32fb:      	jmp	0x3321 <generic_retkprobe_filter_arg+0x3321>
    32fd:      	movl	$0x1, %eax
    3302:      	leaq	0x38(%rsp), %rsi
    3307:      	movq	(%rip), %rdi            # 0x330e <generic_retkprobe_filter_arg+0x330e>
    330e:      	jmp	0x3321 <generic_retkprobe_filter_arg+0x3321>
    3310:      	movl	$0x1, %eax
    3315:      	leaq	0x38(%rsp), %rsi
    331a:      	movq	(%rip), %rdi            # 0x3321 <generic_retkprobe_filter_arg+0x3321>
    3321:      	callq	*%rax
    3323:      	testq	%rax, %rax
    3326:      	je	0x3341 <generic_retkprobe_filter_arg+0x3341>
    3328:      	movq	%rax, %rdi
    332b:      	movl	$0x1, %eax
    3330:      	movq	0x60(%rsp), %rsi
    3335:      	callq	*%rax
    3337:      	xorl	%ebx, %ebx
    3339:      	testq	%rax, %rax
    333c:      	setne	%bl
    333f:      	jmp	0x3343 <generic_retkprobe_filter_arg+0x3343>
    3341:      	xorl	%ebx, %ebx
    3343:      	movq	(%rsp), %rdi
    3347:      	movq	0x8(%rsp), %r9
    334c:      	movq	0x10(%rsp), %r11
    3351:      	movl	0x4(%r12), %eax
    3356:      	cmpq	$0x25, %rax
    335a:      	ja	0x260 <generic_retkprobe_filter_arg+0x260>
    3360:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    336a:      	btq	%rax, %rcx
    336e:      	jb	0x3668 <generic_retkprobe_filter_arg+0x3668>
    3374:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    3379:      	movzbl	(%r15), %esi
    337d:      	cmpl	%esi, %edx
    337f:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    3385:      	cmpl	$0x15, %ecx
    3388:      	jb	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    338e:      	movl	0x1c(%r12), %ecx
    3393:      	cmpl	$0x2, %eax
    3396:      	jle	0x351f <generic_retkprobe_filter_arg+0x351f>
    339c:      	leal	-0x3(%rax), %edx
    339f:      	cmpl	$0x2, %edx
    33a2:      	jb	0x355a <generic_retkprobe_filter_arg+0x355a>
    33a8:      	cmpl	$0x6, %eax
    33ab:      	je	0x271 <generic_retkprobe_filter_arg+0x271>
    33b1:      	cmpl	$0xc, %eax
    33b4:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    33ba:      	movzbl	(%r15), %edx
    33be:      	jmp	0x3405 <generic_retkprobe_filter_arg+0x3405>
    33c0:      	movzwl	(%r15), %esi
    33c4:      	cmpl	%esi, %edx
    33c6:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    33cc:      	cmpl	$0x15, %ecx
    33cf:      	jb	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    33d5:      	movl	0x1c(%r12), %ecx
    33da:      	cmpl	$0x2, %eax
    33dd:      	jle	0x3537 <generic_retkprobe_filter_arg+0x3537>
    33e3:      	leal	-0x3(%rax), %edx
    33e6:      	cmpl	$0x2, %edx
    33e9:      	jb	0x3560 <generic_retkprobe_filter_arg+0x3560>
    33ef:      	cmpl	$0x6, %eax
    33f2:      	je	0x271 <generic_retkprobe_filter_arg+0x271>
    33f8:      	cmpl	$0xc, %eax
    33fb:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    3401:      	movzwl	(%r15), %edx
    3405:      	testl	%edx, %ecx
    3407:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
    340d:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    3412:      	cmpl	$0x8, %ebx
    3415:      	je	0x35ff <generic_retkprobe_filter_arg+0x35ff>
    341b:      	cmpl	$0x9, %ebx
    341e:      	je	0x35c6 <generic_retkprobe_filter_arg+0x35c6>
    3424:      	cmpl	$0xa, %ebx
    3427:      	jne	0x3630 <generic_retkprobe_filter_arg+0x3630>
    342d:      	movl	$0x1, %eax
    3432:      	leaq	0x38(%rsp), %rsi
    3437:      	movq	(%rip), %rdi            # 0x343e <generic_retkprobe_filter_arg+0x343e>
    343e:      	jmp	0x3610 <generic_retkprobe_filter_arg+0x3610>
    3443:      	cmpl	%esi, (%r15)
    3446:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    344c:      	jmp	0x3457 <generic_retkprobe_filter_arg+0x3457>
    344e:      	cmpl	%esi, (%r15)
    3451:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    3457:      	cmpl	$0x15, %edx
    345a:      	jb	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    3460:      	movl	0x1c(%r12), %edx
    3465:      	cmpl	$0x2, %eax
    3468:      	jle	0x3492 <generic_retkprobe_filter_arg+0x3492>
    346a:      	leal	-0x3(%rax), %ecx
    346d:      	cmpl	$0x2, %ecx
    3470:      	jb	0x34c5 <generic_retkprobe_filter_arg+0x34c5>
    3472:      	cmpl	$0x6, %eax
    3475:      	je	0x271 <generic_retkprobe_filter_arg+0x271>
    347b:      	cmpl	$0xc, %eax
    347e:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    3484:      	testl	%edx, (%r15)
    3487:      	jne	0x271 <generic_retkprobe_filter_arg+0x271>
    348d:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    3492:      	cmpl	$0x1, %eax
    3495:      	je	0x34d3 <generic_retkprobe_filter_arg+0x34d3>
    3497:      	cmpl	$0x2, %eax
    349a:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    34a0:      	cmpl	$0xc, %ecx
    34a3:      	ja	0x3693 <generic_retkprobe_filter_arg+0x3693>
    34a9:      	movl	$0x1402, %esi           # imm = 0x1402
    34ae:      	btl	%ecx, %esi
    34b1:      	jae	0x3693 <generic_retkprobe_filter_arg+0x3693>
    34b7:      	cmpl	%edx, (%r15)
    34ba:      	jl	0x271 <generic_retkprobe_filter_arg+0x271>
    34c0:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    34c5:      	cmpl	%edx, (%r15)
    34c8:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
    34ce:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    34d3:      	cmpl	$0xc, %ecx
    34d6:      	ja	0x369e <generic_retkprobe_filter_arg+0x369e>
    34dc:      	movl	$0x1402, %esi           # imm = 0x1402
    34e1:      	btl	%ecx, %esi
    34e4:      	jae	0x369e <generic_retkprobe_filter_arg+0x369e>
    34ea:      	cmpl	%edx, (%r15)
    34ed:      	jg	0x271 <generic_retkprobe_filter_arg+0x271>
    34f3:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    34f8:      	testl	%ebx, %ebx
    34fa:      	je	0x358d <generic_retkprobe_filter_arg+0x358d>
    3500:      	cmpl	$0x1, %ebx
    3503:      	jne	0x3630 <generic_retkprobe_filter_arg+0x3630>
    3509:      	movl	$0x1, %eax
    350e:      	leaq	0x38(%rsp), %rsi
    3513:      	movq	(%rip), %rdi            # 0x351a <generic_retkprobe_filter_arg+0x351a>
    351a:      	jmp	0x3610 <generic_retkprobe_filter_arg+0x3610>
    351f:      	cmpl	$0x1, %eax
    3522:      	je	0x367f <generic_retkprobe_filter_arg+0x367f>
    3528:      	cmpl	$0x2, %eax
    352b:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    3531:      	movzbl	(%r15), %edx
    3535:      	jmp	0x354d <generic_retkprobe_filter_arg+0x354d>
    3537:      	cmpl	$0x1, %eax
    353a:      	je	0x3685 <generic_retkprobe_filter_arg+0x3685>
    3540:      	cmpl	$0x2, %eax
    3543:      	jne	0xb8 <generic_retkprobe_filter_arg+0xb8>
    3549:      	movzwl	(%r15), %edx
    354d:      	cmpl	%edx, %ecx
    354f:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    3555:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    355a:      	movzbl	(%r15), %edx
    355e:      	jmp	0x3564 <generic_retkprobe_filter_arg+0x3564>
    3560:      	movzwl	(%r15), %edx
    3564:      	cmpl	%edx, %ecx
    3566:      	je	0x24f <generic_retkprobe_filter_arg+0x24f>
    356c:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    3571:      	cmpq	%rdx, (%r15)
    3574:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    357a:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    357f:      	cmpq	%rdx, (%r15)
    3582:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    3588:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    358d:      	movl	$0x1, %eax
    3592:      	movq	(%rip), %rdi            # 0x3599 <generic_retkprobe_filter_arg+0x3599>
    3599:      	leaq	0x38(%rsp), %rsi
    359e:      	jmp	0x3610 <generic_retkprobe_filter_arg+0x3610>
    35a0:      	movl	$0x1, %eax
    35a5:      	leaq	0x38(%rsp), %rsi
    35aa:      	movq	(%rip), %rdi            # 0x35b1 <generic_retkprobe_filter_arg+0x35b1>
    35b1:      	jmp	0x3610 <generic_retkprobe_filter_arg+0x3610>
    35b3:      	movl	$0x1, %eax
    35b8:      	leaq	0x38(%rsp), %rsi
    35bd:      	movq	(%rip), %rdi            # 0x35c4 <generic_retkprobe_filter_arg+0x35c4>
    35c4:      	jmp	0x3610 <generic_retkprobe_filter_arg+0x3610>
    35c6:      	movl	$0x1, %eax
    35cb:      	leaq	0x38(%rsp), %rsi
    35d0:      	movq	(%rip), %rdi            # 0x35d7 <generic_retkprobe_filter_arg+0x35d7>
    35d7:      	jmp	0x3610 <generic_retkprobe_filter_arg+0x3610>
    35d9:      	movl	$0x1, %eax
    35de:      	leaq	0x38(%rsp), %rsi
    35e3:      	movq	(%rip), %rdi            # 0x35ea <generic_retkprobe_filter_arg+0x35ea>
    35ea:      	jmp	0x3610 <generic_retkprobe_filter_arg+0x3610>
    35ec:      	movl	$0x1, %eax
    35f1:      	leaq	0x38(%rsp), %rsi
    35f6:      	movq	(%rip), %rdi            # 0x35fd <generic_retkprobe_filter_arg+0x35fd>
    35fd:      	jmp	0x3610 <generic_retkprobe_filter_arg+0x3610>
    35ff:      	movl	$0x1, %eax
    3604:      	leaq	0x38(%rsp), %rsi
    3609:      	movq	(%rip), %rdi            # 0x3610 <generic_retkprobe_filter_arg+0x3610>
    3610:      	callq	*%rax
    3612:      	testq	%rax, %rax
    3615:      	je	0x3630 <generic_retkprobe_filter_arg+0x3630>
    3617:      	movq	%rax, %rdi
    361a:      	movl	$0x1, %eax
    361f:      	movq	0x18(%rsp), %rsi
    3624:      	callq	*%rax
    3626:      	xorl	%ebx, %ebx
    3628:      	testq	%rax, %rax
    362b:      	setne	%bl
    362e:      	jmp	0x3632 <generic_retkprobe_filter_arg+0x3632>
    3630:      	xorl	%ebx, %ebx
    3632:      	movq	(%rsp), %rdi
    3636:      	movq	0x8(%rsp), %r9
    363b:      	movq	0x10(%rsp), %r11
    3640:      	movl	0x4(%r12), %eax
    3645:      	cmpq	$0x25, %rax
    3649:      	ja	0x1bc9 <generic_retkprobe_filter_arg+0x1bc9>
    364f:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    3659:      	btq	%rax, %rcx
    365d:      	movq	0x28(%rsp), %r13
    3662:      	jae	0x260 <generic_retkprobe_filter_arg+0x260>
    3668:      	xorl	%eax, %eax
    366a:      	testq	%rbx, %rbx
    366d:      	sete	%al
    3670:      	movq	%rax, %rbx
    3673:      	jmp	0x260 <generic_retkprobe_filter_arg+0x260>
    3678:      	xorl	%ebx, %ebx
    367a:      	jmp	0xa8a <generic_retkprobe_filter_arg+0xa8a>
    367f:      	movzbl	(%r15), %edx
    3683:      	jmp	0x3689 <generic_retkprobe_filter_arg+0x3689>
    3685:      	movzwl	(%r15), %edx
    3689:      	cmpl	%edx, %ecx
    368b:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    3691:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    3693:      	cmpl	%edx, (%r15)
    3696:      	jb	0x271 <generic_retkprobe_filter_arg+0x271>
    369c:      	jmp	0x36a7 <generic_retkprobe_filter_arg+0x36a7>
    369e:      	cmpl	%edx, (%r15)
    36a1:      	ja	0x271 <generic_retkprobe_filter_arg+0x271>
    36a7:      	orl	$0x2, %eax
    36aa:      	cmpl	$0x6, %eax
    36ad:      	je	0x271 <generic_retkprobe_filter_arg+0x271>
    36b3:      	jmp	0xb8 <generic_retkprobe_filter_arg+0xb8>
    36b8:      	nopl	(%rax,%rax)

00000000000036c0 <generic_retkprobe_actions>:
    36c0:      	pushq	%rbp
    36c1:      	pushq	%r15
    36c3:      	pushq	%r14
    36c5:      	pushq	%r13
    36c7:      	pushq	%r12
    36c9:      	pushq	%rbx
    36ca:      	subq	$0xa8, %rsp
    36d1:      	movq	%rdi, 0x80(%rsp)
    36d9:      	movl	$0x0, 0x88(%rsp)
    36e4:      	movq	(%rip), %rdi            # 0x36eb <generic_retkprobe_actions+0x2b>
    36eb:      	leaq	0x88(%rsp), %rsi
    36f3:      	movl	$0x1, %eax
    36f8:      	callq	*%rax
    36fa:      	testq	%rax, %rax
    36fd:      	je	0x41f8 <generic_retkprobe_actions+0xb38>
    3703:      	movq	%rax, %rsi
    3706:      	movl	0x5f04(%rax), %ebx
    370c:      	cmpl	$0x2, %ebx
    370f:      	jl	0x41f8 <generic_retkprobe_actions+0xb38>
    3715:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    371c:      	movq	(%rip), %rdi            # 0x3723 <generic_retkprobe_actions+0x63>
    3723:      	movl	$0x1, %eax
    3728:      	callq	*%rax
    372a:      	testq	%rax, %rax
    372d:      	je	0x41f8 <generic_retkprobe_actions+0xb38>
    3733:      	movq	%rax, %r14
    3736:      	movl	%ebx, %eax
    3738:      	andl	$0x7ff, %eax            # imm = 0x7FF
    373d:      	addl	(%r14,%rax), %ebx
    3741:      	movl	$0x0, 0x8c(%rsp)
    374c:      	movq	(%rip), %rdi            # 0x3753 <generic_retkprobe_actions+0x93>
    3753:      	leaq	0x8c(%rsp), %rsi
    375b:      	movl	$0x1, %eax
    3760:      	andl	$0x7ff, %ebx            # imm = 0x7FF
    3766:      	callq	*%rax
    3768:      	testq	%rax, %rax
    376b:      	je	0x3792 <generic_retkprobe_actions+0xd2>
    376d:      	cmpb	$0x0, (%rax)
    3770:      	sete	0x17(%rsp)
    3775:      	je	0x37ad <generic_retkprobe_actions+0xed>
    3777:      	movl	$0x5, %eax
    377c:      	movq	%rax, 0x78(%rsp)
    3781:      	movl	$0x9, %eax
    3786:      	movq	%rax, 0x70(%rsp)
    378b:      	movl	$0x7, %eax
    3790:      	jmp	0x37c6 <generic_retkprobe_actions+0x106>
    3792:      	movl	$0x4, %eax
    3797:      	movq	%rax, 0x78(%rsp)
    379c:      	movl	$0x8, %eax
    37a1:      	movq	%rax, 0x70(%rsp)
    37a6:      	movb	$0x1, 0x17(%rsp)
    37ab:      	jmp	0x37c1 <generic_retkprobe_actions+0x101>
    37ad:      	movl	$0x4, %eax
    37b2:      	movq	%rax, 0x78(%rsp)
    37b7:      	movl	$0x8, %eax
    37bc:      	movq	%rax, 0x70(%rsp)
    37c1:      	movl	$0x6, %eax
    37c6:      	movq	%rax, 0x68(%rsp)
    37cb:      	addq	%rbx, %r14
    37ce:      	movb	$0x1, %al
    37d0:      	movl	%eax, 0x44(%rsp)
    37d4:      	movq	(%rip), %rbp            # 0x37db <generic_retkprobe_actions+0x11b>
    37db:      	xorl	%r12d, %r12d
    37de:      	xorl	%r15d, %r15d
    37e1:      	jmp	0x380a <generic_retkprobe_actions+0x14a>
    37e3:      	incl	%r15d
    37e6:      	movl	0x4(%r14,%r15,4), %eax
    37eb:      	movl	%eax, 0x78(%rdx)
    37ee:      	nop
    37f0:      	movq	%r13, 0x70(%rdx)
    37f4:      	incl	%r15d
    37f7:      	movl	%r15d, %ebx
    37fa:      	incl	%r12d
    37fd:      	movl	%ebx, %r15d
    3800:      	cmpl	$0x3, %r12d
    3804:      	je	0x41d1 <generic_retkprobe_actions+0xb11>
    380a:      	leal	0x4(,%r15,4), %eax
    3812:      	cmpl	(%r14), %eax
    3815:      	jae	0x41d1 <generic_retkprobe_actions+0xb11>
    381b:      	movl	%r15d, %eax
    381e:      	movslq	0x4(%r14,%rax,4), %r13
    3823:      	movl	$0x0, 0x90(%rsp)
    382e:      	movl	$0x1, %eax
    3833:      	leaq	0x90(%rsp), %rsi
    383b:      	movq	%rbp, %rdi
    383e:      	callq	*%rax
    3840:      	xorl	%ebx, %ebx
    3842:      	testq	%rax, %rax
    3845:      	je	0x37fa <generic_retkprobe_actions+0x13a>
    3847:      	movq	%rax, %rdx
    384a:      	cmpl	$0x7, %r13d
    384e:      	jg	0x3880 <generic_retkprobe_actions+0x1c0>
    3850:      	cmpl	$0x3, %r13d
    3854:      	jg	0x38d6 <generic_retkprobe_actions+0x216>
    385a:      	cmpl	$0x1, %r13d
    385e:      	jg	0x3a27 <generic_retkprobe_actions+0x367>
    3864:      	testl	%r13d, %r13d
    3867:      	je	0x3c37 <generic_retkprobe_actions+0x577>
    386d:      	cmpl	$0x1, %r13d
    3871:      	je	0x3a40 <generic_retkprobe_actions+0x380>
    3877:      	jmp	0x37f0 <generic_retkprobe_actions+0x130>
    387c:      	nopl	(%rax)
    3880:      	cmpl	$0xb, %r13d
    3884:      	jg	0x39f0 <generic_retkprobe_actions+0x330>
    388a:      	leal	-0xa(%r13), %eax
    388e:      	cmpl	$0x2, %eax
    3891:      	jb	0x3acf <generic_retkprobe_actions+0x40f>
    3897:      	cmpl	$0x8, %r13d
    389b:      	je	0x3b91 <generic_retkprobe_actions+0x4d1>
    38a1:      	cmpl	$0x9, %r13d
    38a5:      	jne	0x37f0 <generic_retkprobe_actions+0x130>
    38ab:      	movq	%r13, 0x8(%rsp)
    38b0:      	movq	%r14, %rax
    38b3:      	movq	%rbp, %r13
    38b6:      	incl	%r15d
    38b9:      	movl	0x4(%r14,%r15,4), %eax
    38be:      	movq	%rdx, %rbp
    38c1:      	movl	$0x3, %ebx
    38c6:      	cmpb	$0x0, 0x17(%rsp)
    38cb:      	jne	0x3d13 <generic_retkprobe_actions+0x653>
    38d1:      	jmp	0x3d38 <generic_retkprobe_actions+0x678>
    38d6:      	leal	-0x6(%r13), %eax
    38da:      	cmpl	$0x2, %eax
    38dd:      	jb	0x37e3 <generic_retkprobe_actions+0x123>
    38e3:      	cmpl	$0x4, %r13d
    38e7:      	je	0x3b9e <generic_retkprobe_actions+0x4de>
    38ed:      	cmpl	$0x5, %r13d
    38f1:      	jne	0x37f0 <generic_retkprobe_actions+0x130>
    38f7:      	leal	0x1(%r15), %eax
    38fb:      	movl	0x4(%r14,%rax,4), %eax
    3900:      	addl	$0x2, %r15d
    3904:      	movl	0x4(%r14,%r15,4), %ebx
    3909:      	movq	$0x0, 0x20(%rsp)
    3912:      	movq	$0x0, 0x18(%rsp)
    391b:      	andl	$0x7, %eax
    391e:      	cmpl	$0x4, %eax
    3921:      	ja	0x37f0 <generic_retkprobe_actions+0x130>
    3927:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    392f:      	jne	0x37f0 <generic_retkprobe_actions+0x130>
    3935:      	movq	0x5e78(%rdx,%rax,8), %rax
    393d:      	andl	$0x7ff, %eax            # imm = 0x7FF
    3942:      	movl	0x90(%rdx,%rax), %eax
    3949:      	movl	%eax, 0x20(%rsp)
    394d:      	movl	$0xe, %eax
    3952:      	movq	%rdx, 0x8(%rsp)
    3957:      	callq	*%rax
    3959:      	shrq	$0x20, %rax
    395d:      	movq	%rax, 0x18(%rsp)
    3962:      	movl	$0x1, %eax
    3967:      	leaq	0x18(%rsp), %rsi
    396c:      	movq	(%rip), %rdi            # 0x3973 <generic_retkprobe_actions+0x2b3>
    3973:      	callq	*%rax
    3975:      	movq	0x8(%rsp), %rdx
    397a:      	testq	%rax, %rax
    397d:      	je	0x37f0 <generic_retkprobe_actions+0x130>
    3983:      	andl	$0x7, %ebx
    3986:      	cmpl	$0x4, %ebx
    3989:      	ja	0x37f0 <generic_retkprobe_actions+0x130>
    398f:      	cmpl	$0x0, 0x5ea0(%rdx,%rbx,4)
    3997:      	jne	0x37f0 <generic_retkprobe_actions+0x130>
    399d:      	movq	0x5e78(%rdx,%rbx,8), %rcx
    39a5:      	movl	$0x0, 0x24(%rsp)
    39ad:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    39b3:      	movl	0x90(%rdx,%rcx), %ecx
    39ba:      	movl	%ecx, 0x20(%rsp)
    39be:      	movq	%rax, %rbx
    39c1:      	movl	$0xe, %eax
    39c6:      	callq	*%rax
    39c8:      	shrq	$0x20, %rax
    39cc:      	movq	%rax, 0x18(%rsp)
    39d1:      	movl	$0x2, %eax
    39d6:      	xorl	%ecx, %ecx
    39d8:      	leaq	0x18(%rsp), %rsi
    39dd:      	movq	(%rip), %rdi            # 0x39e4 <generic_retkprobe_actions+0x324>
    39e4:      	movq	%rbx, %rdx
    39e7:      	xorl	%ecx, %ecx
    39e9:      	callq	*%rax
    39eb:      	jmp	0x3c2d <generic_retkprobe_actions+0x56d>
    39f0:      	cmpl	$0xc, %r13d
    39f4:      	je	0x3d24 <generic_retkprobe_actions+0x664>
    39fa:      	cmpl	$0xd, %r13d
    39fe:      	je	0x3bb6 <generic_retkprobe_actions+0x4f6>
    3a04:      	cmpl	$0xe, %r13d
    3a08:      	jne	0x37f0 <generic_retkprobe_actions+0x130>
    3a0e:      	movq	%r13, 0x8(%rsp)
    3a13:      	movq	%rbp, %r13
    3a16:      	movq	%rdx, %rbp
    3a19:      	addl	$0x2, %r15d
    3a1d:      	movq	0x70(%rsp), %rbx
    3a22:      	jmp	0x3d38 <generic_retkprobe_actions+0x678>
    3a27:      	movl	$0x9, %eax
    3a2c:      	cmpl	$0x2, %r13d
    3a30:      	je	0x3cfc <generic_retkprobe_actions+0x63c>
    3a36:      	cmpl	$0x3, %r13d
    3a3a:      	jne	0x37f0 <generic_retkprobe_actions+0x130>
    3a40:      	movq	%rdx, 0x8(%rsp)
    3a45:      	leal	0x1(%r15), %eax
    3a49:      	movq	%r14, %rcx
    3a4c:      	movl	0x4(%r14,%rax,4), %r14d
    3a51:      	addl	$0x2, %r15d
    3a55:      	movq	%rcx, %rbp
    3a58:      	movl	0x4(%rcx,%r15,4), %eax
    3a5d:      	movq	%rax, 0x38(%rsp)
    3a62:      	movq	$0x0, 0x20(%rsp)
    3a6b:      	movq	$0x0, 0x18(%rsp)
    3a74:      	movl	$0x0, 0x28(%rsp)
    3a7c:      	movl	$0x1, %eax
    3a81:      	leaq	0x28(%rsp), %rsi
    3a86:      	movq	(%rip), %rdi            # 0x3a8d <generic_retkprobe_actions+0x3cd>
    3a8d:      	callq	*%rax
    3a8f:      	xorl	%ecx, %ecx
    3a91:      	testq	%rax, %rax
    3a94:      	je	0x3ec8 <generic_retkprobe_actions+0x808>
    3a9a:      	andl	$0x7, %r14d
    3a9e:      	cmpl	$0x4, %r14d
    3aa2:      	movq	0x8(%rsp), %rdx
    3aa7:      	ja	0x3ab8 <generic_retkprobe_actions+0x3f8>
    3aa9:      	cmpl	$0x0, 0x5ea0(%rdx,%r14,4)
    3ab2:      	je	0x3d6d <generic_retkprobe_actions+0x6ad>
    3ab8:      	movq	%rbp, %r14
    3abb:      	movq	(%rip), %rbp            # 0x3ac2 <generic_retkprobe_actions+0x402>
    3ac2:      	testl	%ecx, %ecx
    3ac4:      	jne	0x37fa <generic_retkprobe_actions+0x13a>
    3aca:      	jmp	0x37f0 <generic_retkprobe_actions+0x130>
    3acf:      	incl	%r15d
    3ad2:      	movl	0x4(%r14,%r15,4), %eax
    3ad7:      	andl	$0x7, %eax
    3ada:      	xorl	%ecx, %ecx
    3adc:      	cmpl	$0x4, %eax
    3adf:      	ja	0x3ed7 <generic_retkprobe_actions+0x817>
    3ae5:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    3aed:      	jne	0x3ed7 <generic_retkprobe_actions+0x817>
    3af3:      	movq	0x5e78(%rdx,%rax,8), %rax
    3afb:      	andl	$0x7ff, %eax            # imm = 0x7FF
    3b00:      	movq	0xb8(%rdx,%rax), %rax
    3b08:      	movq	%rax, 0x28(%rsp)
    3b0d:      	testq	%rax, %rax
    3b10:      	je	0x3ed7 <generic_retkprobe_actions+0x817>
    3b16:      	movq	%rdx, 0x8(%rsp)
    3b1b:      	cmpl	$0xa, %r13d
    3b1f:      	jne	0x3ee4 <generic_retkprobe_actions+0x824>
    3b25:      	movl	$0xe, %eax
    3b2a:      	callq	*%rax
    3b2c:      	movq	%rax, 0x38(%rsp)
    3b31:      	shrq	$0x20, %rax
    3b35:      	movl	%eax, 0x18(%rsp)
    3b39:      	movl	$0x1, %eax
    3b3e:      	leaq	0x18(%rsp), %rsi
    3b43:      	movq	(%rip), %rdi            # 0x3b4a <generic_retkprobe_actions+0x48a>
    3b4a:      	callq	*%rax
    3b4c:      	xorl	%ecx, %ecx
    3b4e:      	testq	%rax, %rax
    3b51:      	movq	0x8(%rsp), %rdx
    3b56:      	je	0x3ed7 <generic_retkprobe_actions+0x817>
    3b5c:      	movl	(%rax), %ecx
    3b5e:      	movl	%ecx, 0x18(%rsp)
    3b62:      	movq	0x38(%rsp), %rcx
    3b67:      	movl	%ecx, 0x1c(%rsp)
    3b6b:      	movq	0x8(%rax), %rax
    3b6f:      	movq	%rax, 0x20(%rsp)
    3b74:      	xorl	%ecx, %ecx
    3b76:      	movl	$0x2, %eax
    3b7b:      	leaq	0x28(%rsp), %rsi
    3b80:      	leaq	0x18(%rsp), %rdx
    3b85:      	movq	(%rip), %rdi            # 0x3b8c <generic_retkprobe_actions+0x4cc>
    3b8c:      	jmp	0x3e30 <generic_retkprobe_actions+0x770>
    3b91:      	movl	$0x0, 0x44(%rsp)
    3b99:      	jmp	0x37f0 <generic_retkprobe_actions+0x130>
    3b9e:      	movq	%r13, 0x8(%rsp)
    3ba3:      	movq	%rbp, %r13
    3ba6:      	movq	%rdx, %rbp
    3ba9:      	incl	%r15d
    3bac:      	movq	0x78(%rsp), %rbx
    3bb1:      	jmp	0x3d38 <generic_retkprobe_actions+0x678>
    3bb6:      	movq	%rdx, 0x8(%rsp)
    3bbb:      	movl	$0xe, %eax
    3bc0:      	callq	*%rax
    3bc2:      	movq	%rax, 0x50(%rsp)
    3bc7:      	movl	$0x1, %eax
    3bcc:      	leaq	0x50(%rsp), %rsi
    3bd1:      	movq	(%rip), %rdi            # 0x3bd8 <generic_retkprobe_actions+0x518>
    3bd8:      	callq	*%rax
    3bda:      	testq	%rax, %rax
    3bdd:      	je	0x3c2d <generic_retkprobe_actions+0x56d>
    3bdf:      	movq	0x4(%rax), %rax
    3be3:      	movq	%rax, 0x28(%rsp)
    3be8:      	movl	$0x2, 0x30(%rsp)
    3bf0:      	movl	$0x1, %eax
    3bf5:      	leaq	0x28(%rsp), %rsi
    3bfa:      	movq	(%rip), %rbx            # 0x3c01 <generic_retkprobe_actions+0x541>
    3c01:      	movq	%rbx, %rdi
    3c04:      	callq	*%rax
    3c06:      	movl	$0x1, 0x5c(%rsp)
    3c0e:      	testq	%rax, %rax
    3c11:      	je	0x3e48 <generic_retkprobe_actions+0x788>
    3c17:      	lock
    3c18:      	incl	(%rax)
    3c1a:      	movl	$0x3, %eax
    3c1f:      	leaq	0x50(%rsp), %rsi
    3c24:      	movq	(%rip), %rdi            # 0x3c2b <generic_retkprobe_actions+0x56b>
    3c2b:      	callq	*%rax
    3c2d:      	movq	0x8(%rsp), %rdx
    3c32:      	jmp	0x37f0 <generic_retkprobe_actions+0x130>
    3c37:      	movq	%rdx, 0x8(%rsp)
    3c3c:      	leal	0x1(%r15), %eax
    3c40:      	movl	0x4(%r14,%rax,4), %ebx
    3c45:      	leal	0x2(%r15), %eax
    3c49:      	movl	0x4(%r14,%rax,4), %eax
    3c4e:      	movl	%eax, 0x60(%rsp)
    3c52:      	movl	$0x7d, %eax
    3c57:      	callq	*%rax
    3c59:      	movq	%rax, 0x18(%rsp)
    3c5e:      	movl	$0x0, 0x50(%rsp)
    3c66:      	movq	%rbx, 0xa0(%rsp)
    3c6e:      	testq	%rbx, %rbx
    3c71:      	je	0x40e8 <generic_retkprobe_actions+0xa28>
    3c77:      	movl	$0x1, %eax
    3c7c:      	movq	(%rip), %rdi            # 0x3c83 <generic_retkprobe_actions+0x5c3>
    3c83:      	leaq	0x50(%rsp), %rsi
    3c88:      	callq	*%rax
    3c8a:      	testq	%rax, %rax
    3c8d:      	je	0x40e8 <generic_retkprobe_actions+0xa28>
    3c93:      	movq	%rax, 0x48(%rsp)
    3c98:      	movq	%rax, %rbx
    3c9b:      	movl	$0x1, %eax
    3ca0:      	leaq	0x50(%rsp), %rsi
    3ca5:      	movq	(%rip), %rdi            # 0x3cac <generic_retkprobe_actions+0x5ec>
    3cac:      	callq	*%rax
    3cae:      	movq	%rax, %rdx
    3cb1:      	movq	0x8(%rsp), %rcx
    3cb6:      	movq	0x60(%rcx), %rax
    3cba:      	movq	%rax, (%rbx)
    3cbd:      	movq	0x70(%rcx), %rax
    3cc1:      	movq	%rax, 0x8(%rbx)
    3cc5:      	xorl	%eax, %eax
    3cc7:      	movq	%rax, 0x38(%rsp)
    3ccc:      	movl	$0x0, %eax
    3cd1:      	movl	0x60(%rsp), %esi
    3cd5:      	cmpl	$0x2, %esi
    3cd8:      	je	0x3f0f <generic_retkprobe_actions+0x84f>
    3cde:      	cmpl	$0x1, %esi
    3ce1:      	je	0x3f0c <generic_retkprobe_actions+0x84c>
    3ce7:      	testl	%esi, %esi
    3ce9:      	jne	0x40e8 <generic_retkprobe_actions+0xa28>
    3cef:      	movq	0x8(%rsp), %rax
    3cf4:      	movl	0x7c(%rax), %eax
    3cf7:      	jmp	0x3f0f <generic_retkprobe_actions+0x84f>
    3cfc:      	movq	%r13, 0x8(%rsp)
    3d01:      	movq	%rbp, %r13
    3d04:      	movq	%rdx, %rbp
    3d07:      	movl	$0x3, %ebx
    3d0c:      	cmpb	$0x0, 0x17(%rsp)
    3d11:      	je	0x3d38 <generic_retkprobe_actions+0x678>
    3d13:      	movslq	%eax, %rdi
    3d16:      	movl	$0x6d, %eax
    3d1b:      	callq	*%rax
    3d1d:      	movl	$0x2, %ebx
    3d22:      	jmp	0x3d38 <generic_retkprobe_actions+0x678>
    3d24:      	movq	%r13, 0x8(%rsp)
    3d29:      	movq	%rbp, %r13
    3d2c:      	movq	%rdx, %rbp
    3d2f:      	addl	$0x3, %r15d
    3d33:      	movq	0x68(%rsp), %rbx
    3d38:      	movl	$0x0, 0x18(%rsp)
    3d40:      	movl	$0x1, %eax
    3d45:      	leaq	0x18(%rsp), %rsi
    3d4a:      	movq	(%rip), %rdi            # 0x3d51 <generic_retkprobe_actions+0x691>
    3d51:      	callq	*%rax
    3d53:      	testq	%rax, %rax
    3d56:      	je	0x3d5d <generic_retkprobe_actions+0x69d>
    3d58:      	lock
    3d59:      	incq	(%rax,%rbx,8)
    3d5d:      	movq	%rbp, %rdx
    3d60:      	movq	%r13, %rbp
    3d63:      	movq	0x8(%rsp), %r13
    3d68:      	jmp	0x37f0 <generic_retkprobe_actions+0x130>
    3d6d:      	movq	%rax, 0x48(%rsp)
    3d72:      	movq	0x5e78(%rdx,%r14,8), %rax
    3d7a:      	movl	$0x0, 0x24(%rsp)
    3d82:      	andl	$0x7ff, %eax            # imm = 0x7FF
    3d87:      	movl	0x90(%rdx,%rax), %eax
    3d8e:      	movl	%eax, 0x20(%rsp)
    3d92:      	movl	$0xe, %eax
    3d97:      	callq	*%rax
    3d99:      	shrq	$0x20, %rax
    3d9d:      	movq	%rax, 0x18(%rsp)
    3da2:      	cmpl	$0x1, %r13d
    3da6:      	jne	0x3eb2 <generic_retkprobe_actions+0x7f2>
    3dac:      	movq	0x38(%rsp), %rax
    3db1:      	andl	$0x7, %eax
    3db4:      	cmpl	$0x4, %eax
    3db7:      	movq	%rbp, %r14
    3dba:      	movl	$0x0, %ecx
    3dbf:      	ja	0x3ecb <generic_retkprobe_actions+0x80b>
    3dc5:      	movq	0x8(%rsp), %rdx
    3dca:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    3dd2:      	movq	(%rip), %rbp            # 0x3dd9 <generic_retkprobe_actions+0x719>
    3dd9:      	jne	0x3ed7 <generic_retkprobe_actions+0x817>
    3ddf:      	movq	0x5e78(%rdx,%rax,8), %rax
    3de7:      	andl	$0x7ff, %eax            # imm = 0x7FF
    3dec:      	addq	%rax, %rdx
    3def:      	addq	$0x90, %rdx
    3df6:      	movq	0x8(%rsp), %rcx
    3dfb:      	movl	0x90(%rcx,%rax), %esi
    3e02:      	andl	$0xfff, %esi            # imm = 0xFFF
    3e08:      	addq	$0x8, %rsi
    3e0c:      	movl	$0x4, %eax
    3e11:      	movq	0x48(%rsp), %rdi
    3e16:      	callq	*%rax
    3e18:      	xorl	%ecx, %ecx
    3e1a:      	movl	$0x2, %eax
    3e1f:      	leaq	0x18(%rsp), %rsi
    3e24:      	movq	(%rip), %rdi            # 0x3e2b <generic_retkprobe_actions+0x76b>
    3e2b:      	movq	0x48(%rsp), %rdx
    3e30:      	xorl	%ecx, %ecx
    3e32:      	callq	*%rax
    3e34:      	xorl	%ecx, %ecx
    3e36:      	movq	0x8(%rsp), %rdx
    3e3b:      	testl	%ecx, %ecx
    3e3d:      	jne	0x37fa <generic_retkprobe_actions+0x13a>
    3e43:      	jmp	0x37f0 <generic_retkprobe_actions+0x130>
    3e48:      	movl	$0x2, %eax
    3e4d:      	movl	$0x1, %ecx
    3e52:      	leaq	0x5c(%rsp), %rdx
    3e57:      	leaq	0x28(%rsp), %rsi
    3e5c:      	movq	%rbx, %rdi
    3e5f:      	callq	*%rax
    3e61:      	testq	%rax, %rax
    3e64:      	je	0x3c1a <generic_retkprobe_actions+0x55a>
    3e6a:      	movq	%rax, 0x38(%rsp)
    3e6f:      	negl	%eax
    3e71:      	movw	%ax, 0x18(%rsp)
    3e76:      	movw	$0x3, 0x1a(%rsp)
    3e7d:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    3e87:      	movq	%rax, 0x1c(%rsp)
    3e8c:      	movl	$0x1, %eax
    3e91:      	leaq	0x18(%rsp), %rsi
    3e96:      	movq	(%rip), %rbx            # 0x3e9d <generic_retkprobe_actions+0x7dd>
    3e9d:      	movq	%rbx, %rdi
    3ea0:      	callq	*%rax
    3ea2:      	testq	%rax, %rax
    3ea5:      	je	0x4178 <generic_retkprobe_actions+0xab8>
    3eab:      	incl	(%rax)
    3ead:      	jmp	0x419e <generic_retkprobe_actions+0xade>
    3eb2:      	movl	$0x3, %eax
    3eb7:      	leaq	0x18(%rsp), %rsi
    3ebc:      	movq	(%rip), %rdi            # 0x3ec3 <generic_retkprobe_actions+0x803>
    3ec3:      	callq	*%rax
    3ec5:      	movq	%rax, %rcx
    3ec8:      	movq	%rbp, %r14
    3ecb:      	movq	(%rip), %rbp            # 0x3ed2 <generic_retkprobe_actions+0x812>
    3ed2:      	movq	0x8(%rsp), %rdx
    3ed7:      	testl	%ecx, %ecx
    3ed9:      	jne	0x37fa <generic_retkprobe_actions+0x13a>
    3edf:      	jmp	0x37f0 <generic_retkprobe_actions+0x130>
    3ee4:      	movl	$0x3, %eax
    3ee9:      	leaq	0x28(%rsp), %rsi
    3eee:      	movq	(%rip), %rdi            # 0x3ef5 <generic_retkprobe_actions+0x835>
    3ef5:      	callq	*%rax
    3ef7:      	movq	%rax, %rcx
    3efa:      	movq	0x8(%rsp), %rdx
    3eff:      	testl	%ecx, %ecx
    3f01:      	jne	0x37fa <generic_retkprobe_actions+0x13a>
    3f07:      	jmp	0x37f0 <generic_retkprobe_actions+0x130>
    3f0c:      	movl	0x10(%rcx), %eax
    3f0f:      	movq	%r14, 0x60(%rsp)
    3f14:      	movl	%eax, %eax
    3f16:      	movq	%rbx, 0x98(%rsp)
    3f1e:      	movq	%rax, 0x10(%rbx)
    3f22:      	movq	0x48(%rsp), %rdi
    3f27:      	addq	$0x18, %rdi
    3f2b:      	movl	$0x4, %eax
    3f30:      	movl	$0xc8, %ecx
    3f35:      	movq	%rdi, 0x48(%rsp)
    3f3a:      	movl	$0xc8, %esi
    3f3f:      	callq	*%rax
    3f41:      	xorl	%r14d, %r14d
    3f44:      	leaq	0x28(%rsp), %rbx
    3f49:      	jmp	0x3f63 <generic_retkprobe_actions+0x8a3>
    3f4b:      	nopl	(%rax,%rax)
    3f50:      	leaq	0x28(%rsp), %rbx
    3f55:      	addq	$0x4, %r14
    3f59:      	cmpq	$0x14, %r14
    3f5d:      	je	0x408b <generic_retkprobe_actions+0x9cb>
    3f63:      	movl	$0x0, 0x28(%rsp)
    3f6b:      	movl	$0x1, %eax
    3f70:      	movq	%rbp, %rdi
    3f73:      	movq	%rbx, %rsi
    3f76:      	callq	*%rax
    3f78:      	testq	%rax, %rax
    3f7b:      	je	0x408b <generic_retkprobe_actions+0x9cb>
    3f81:      	movq	%rax, %rsi
    3f84:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    3f8b:      	movl	$0x1, %eax
    3f90:      	movq	(%rip), %rdi            # 0x3f97 <generic_retkprobe_actions+0x8d7>
    3f97:      	callq	*%rax
    3f99:      	testq	%rax, %rax
    3f9c:      	je	0x408b <generic_retkprobe_actions+0x9cb>
    3fa2:      	cmpl	$-0x1, 0x40(%rax,%r14)
    3fa8:      	movq	0x8(%rsp), %rdx
    3fad:      	je	0x408b <generic_retkprobe_actions+0x9cb>
    3fb3:      	movq	0x5e78(%rdx,%r14,2), %rax
    3fbb:      	movl	0x4(%rdx), %ecx
    3fbe:      	cmpq	%rcx, %rax
    3fc1:      	jge	0x408b <generic_retkprobe_actions+0x9cb>
    3fc7:      	cmpq	$0x10, %r14
    3fcb:      	je	0x4032 <generic_retkprobe_actions+0x972>
    3fcd:      	movl	$0x0, 0x28(%rsp)
    3fd5:      	movl	$0x1, %eax
    3fda:      	movq	%rbp, %rdi
    3fdd:      	movq	%rbx, %rsi
    3fe0:      	callq	*%rax
    3fe2:      	testq	%rax, %rax
    3fe5:      	je	0x4025 <generic_retkprobe_actions+0x965>
    3fe7:      	movq	%rax, %rsi
    3fea:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    3ff1:      	movl	$0x1, %eax
    3ff6:      	movq	(%rip), %rdi            # 0x3ffd <generic_retkprobe_actions+0x93d>
    3ffd:      	callq	*%rax
    3fff:      	testq	%rax, %rax
    4002:      	je	0x4025 <generic_retkprobe_actions+0x965>
    4004:      	cmpl	$-0x1, 0x44(%rax,%r14)
    400a:      	movq	0x8(%rsp), %rdx
    400f:      	movq	0x5e78(%rdx,%r14,2), %rax
    4017:      	je	0x4032 <generic_retkprobe_actions+0x972>
    4019:      	movl	0x5e80(%rdx,%r14,2), %ebx
    4021:      	subl	%eax, %ebx
    4023:      	jmp	0x403a <generic_retkprobe_actions+0x97a>
    4025:      	movq	0x8(%rsp), %rdx
    402a:      	movq	0x5e78(%rdx,%r14,2), %rax
    4032:      	movl	0x4(%rdx), %ebx
    4035:      	subl	%eax, %ebx
    4037:      	addl	$0x4, %ebx
    403a:      	testl	%ebx, %ebx
    403c:      	jle	0x3f50 <generic_retkprobe_actions+0x890>
    4042:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    4047:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    404c:      	cmpl	$0x28, %ebx
    404f:      	movl	$0x28, %ecx
    4054:      	cmovgel	%ecx, %ebx
    4057:      	movzbl	0x38(%rsp), %ebp
    405c:      	movq	0x48(%rsp), %rcx
    4061:      	leaq	(%rcx,%rbp), %rdi
    4065:      	addq	%rax, %rdx
    4068:      	addq	$0x90, %rdx
    406f:      	movl	$0x4, %eax
    4074:      	movl	%ebx, %esi
    4076:      	callq	*%rax
    4078:      	addl	%ebp, %ebx
    407a:      	movq	(%rip), %rbp            # 0x4081 <generic_retkprobe_actions+0x9c1>
    4081:      	movq	%rbx, 0x38(%rsp)
    4086:      	jmp	0x3f50 <generic_retkprobe_actions+0x890>
    408b:      	movl	$0x1, %eax
    4090:      	movq	(%rip), %rdi            # 0x4097 <generic_retkprobe_actions+0x9d7>
    4097:      	movq	0x98(%rsp), %rbx
    409f:      	movq	%rbx, %rsi
    40a2:      	callq	*%rax
    40a4:      	testq	%rax, %rax
    40a7:      	movq	0x60(%rsp), %r14
    40ac:      	je	0x40ce <generic_retkprobe_actions+0xa0e>
    40ae:      	imulq	$-0xf4240, 0xa0(%rsp), %rcx # imm = 0xFFF0BDC0
    40ba:      	addq	0x18(%rsp), %rcx
    40bf:      	cmpq	%rcx, (%rax)
    40c2:      	jbe	0x40ce <generic_retkprobe_actions+0xa0e>
    40c4:      	movl	$0x0, 0x44(%rsp)
    40cc:      	jmp	0x40e8 <generic_retkprobe_actions+0xa28>
    40ce:      	movl	$0x2, %eax
    40d3:      	xorl	%ecx, %ecx
    40d5:      	movq	(%rip), %rdi            # 0x40dc <generic_retkprobe_actions+0xa1c>
    40dc:      	leaq	0x18(%rsp), %rdx
    40e1:      	movq	%rbx, %rsi
    40e4:      	xorl	%ecx, %ecx
    40e6:      	callq	*%rax
    40e8:      	leal	0x3(%r15), %eax
    40ec:      	cmpl	$0x0, 0x4(%r14,%rax,4)
    40f2:      	movq	0x8(%rsp), %rdx
    40f7:      	je	0x4123 <generic_retkprobe_actions+0xa63>
    40f9:      	orb	$0x2, 0x1(%rdx)
    40fd:      	movl	$0x1b, %eax
    4102:      	movq	0x80(%rsp), %rdi
    410a:      	xorl	%ecx, %ecx
    410c:      	movq	(%rip), %rsi            # 0x4113 <generic_retkprobe_actions+0xa53>
    4113:      	xorl	%edx, %edx
    4115:      	callq	*%rax
    4117:      	movq	0x8(%rsp), %rdx
    411c:      	movq	%rax, 0x80(%rdx)
    4123:      	leal	0x4(%r15), %eax
    4127:      	cmpl	$0x0, 0x4(%r14,%rax,4)
    412d:      	je	0x415f <generic_retkprobe_actions+0xa9f>
    412f:      	orb	$0x4, 0x1(%rdx)
    4133:      	movl	$0x1b, %eax
    4138:      	movq	0x80(%rsp), %rdi
    4140:      	movq	(%rip), %rsi            # 0x4147 <generic_retkprobe_actions+0xa87>
    4147:      	movl	$0x100, %ecx            # imm = 0x100
    414c:      	movl	$0x100, %edx            # imm = 0x100
    4151:      	callq	*%rax
    4153:      	movq	0x8(%rsp), %rdx
    4158:      	movq	%rax, 0x88(%rdx)
    415f:      	addl	$0x5, %r15d
    4163:      	cmpl	$0x0, 0x4(%r14,%r15,4)
    4169:      	je	0x37f0 <generic_retkprobe_actions+0x130>
    416f:      	orb	$0x8, 0x1(%rdx)
    4173:      	jmp	0x37f0 <generic_retkprobe_actions+0x130>
    4178:      	movl	$0x1, 0x94(%rsp)
    4183:      	movl	$0x2, %eax
    4188:      	xorl	%ecx, %ecx
    418a:      	leaq	0x94(%rsp), %rdx
    4192:      	leaq	0x18(%rsp), %rsi
    4197:      	movq	%rbx, %rdi
    419a:      	xorl	%ecx, %ecx
    419c:      	callq	*%rax
    419e:      	cmpl	$0x0, 0x38(%rsp)
    41a3:      	je	0x3c1a <generic_retkprobe_actions+0x55a>
    41a9:      	movl	$0x1, %eax
    41ae:      	leaq	0x28(%rsp), %rsi
    41b3:      	movq	(%rip), %rdi            # 0x41ba <generic_retkprobe_actions+0xafa>
    41ba:      	callq	*%rax
    41bc:      	testq	%rax, %rax
    41bf:      	je	0x3c1a <generic_retkprobe_actions+0x55a>
    41c5:      	movl	0x5c(%rsp), %ecx
    41c9:      	lock
    41ca:      	addl	%ecx, (%rax)
    41cc:      	jmp	0x3c1a <generic_retkprobe_actions+0x55a>
    41d1:      	cmpb	$0x0, 0x44(%rsp)
    41d6:      	je	0x41f8 <generic_retkprobe_actions+0xb38>
    41d8:      	movq	(%rip), %rsi            # 0x41df <generic_retkprobe_actions+0xb1f>
    41df:      	movl	$0x5, %ecx
    41e4:      	movl	$0xc, %eax
    41e9:      	movq	0x80(%rsp), %rdi
    41f1:      	movl	$0x5, %edx
    41f6:      	callq	*%rax
    41f8:      	xorl	%eax, %eax
    41fa:      	addq	$0xa8, %rsp
    4201:      	popq	%rbx
    4202:      	popq	%r12
    4204:      	popq	%r13
    4206:      	popq	%r14
    4208:      	popq	%r15
    420a:      	popq	%rbp
    420b:      	retq
    420c:      	nopl	(%rax)

0000000000004210 <generic_retkprobe_output>:
    4210:      	pushq	%r15
    4212:      	pushq	%r14
    4214:      	pushq	%rbx
    4215:      	subq	$0x10, %rsp
    4219:      	movq	%rdi, %r14
    421c:      	movl	$0x0, 0x8(%rsp)
    4224:      	movq	(%rip), %rdi            # 0x422b <generic_retkprobe_output+0x1b>
    422b:      	leaq	0x8(%rsp), %rsi
    4230:      	movl	$0x1, %eax
    4235:      	callq	*%rax
    4237:      	testq	%rax, %rax
    423a:      	je	0x4313 <generic_retkprobe_output+0x103>
    4240:      	movq	%rax, %rbx
    4243:      	movl	$0x90, %eax
    4248:      	addl	0x4(%rbx), %eax
    424b:      	andl	$0x7fff, %eax           # imm = 0x7FFF
    4250:      	cmpl	$0x2328, %eax           # imm = 0x2328
    4255:      	movl	$0x2328, %r15d          # imm = 0x2328
    425b:      	cmovbl	%eax, %r15d
    425f:      	movl	$0x0, 0xc(%rsp)
    4267:      	movq	(%rip), %rdi            # 0x426e <generic_retkprobe_output+0x5e>
    426e:      	leaq	0xc(%rsp), %rsi
    4273:      	movl	$0x1, %eax
    4278:      	callq	*%rax
    427a:      	testq	%rax, %rax
    427d:      	je	0x42d1 <generic_retkprobe_output+0xc1>
    427f:      	cmpb	$0x0, 0x28(%rax)
    4283:      	je	0x42d1 <generic_retkprobe_output+0xc1>
    4285:      	movq	(%rip), %rsi            # 0x428c <generic_retkprobe_output+0x7c>
    428c:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    4291:      	movl	$0x19, %eax
    4296:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    429b:      	movq	%r14, %rdi
    429e:      	movq	%rbx, %rcx
    42a1:      	movq	%r15, %r8
    42a4:      	callq	*%rax
    42a6:      	testq	%rax, %rax
    42a9:      	js	0x436e <generic_retkprobe_output+0x15e>
    42af:      	movl	$0x0, 0x4(%rsp)
    42b7:      	movq	(%rip), %rdi            # 0x42be <generic_retkprobe_output+0xae>
    42be:      	leaq	0x4(%rsp), %rsi
    42c3:      	movl	$0x1, %eax
    42c8:      	callq	*%rax
    42ca:      	testq	%rax, %rax
    42cd:      	jne	0x430e <generic_retkprobe_output+0xfe>
    42cf:      	jmp	0x4313 <generic_retkprobe_output+0x103>
    42d1:      	movq	(%rip), %rdi            # 0x42d8 <generic_retkprobe_output+0xc8>
    42d8:      	xorl	%ecx, %ecx
    42da:      	movl	$0x82, %eax
    42df:      	movq	%rbx, %rsi
    42e2:      	movq	%r15, %rdx
    42e5:      	xorl	%ecx, %ecx
    42e7:      	callq	*%rax
    42e9:      	testq	%rax, %rax
    42ec:      	js	0x431f <generic_retkprobe_output+0x10f>
    42ee:      	movl	$0x0, 0x4(%rsp)
    42f6:      	movq	(%rip), %rdi            # 0x42fd <generic_retkprobe_output+0xed>
    42fd:      	leaq	0x4(%rsp), %rsi
    4302:      	movl	$0x1, %eax
    4307:      	callq	*%rax
    4309:      	testq	%rax, %rax
    430c:      	je	0x4313 <generic_retkprobe_output+0x103>
    430e:      	lock
    430f:      	incq	0x8(%rax)
    4313:      	xorl	%eax, %eax
    4315:      	addq	$0x10, %rsp
    4319:      	popq	%rbx
    431a:      	popq	%r14
    431c:      	popq	%r15
    431e:      	retq
    431f:      	movq	%rax, %rbx
    4322:      	movl	$0x0, 0x4(%rsp)
    432a:      	movq	(%rip), %rdi            # 0x4331 <generic_retkprobe_output+0x121>
    4331:      	leaq	0x4(%rsp), %rsi
    4336:      	movl	$0x1, %eax
    433b:      	callq	*%rax
    433d:      	testq	%rax, %rax
    4340:      	je	0x4313 <generic_retkprobe_output+0x103>
    4342:      	cmpq	$-0xc, %rbx
    4346:      	jg	0x43b2 <generic_retkprobe_output+0x1a2>
    4348:      	cmpq	$-0x1c, %rbx
    434c:      	je	0x43f4 <generic_retkprobe_output+0x1e4>
    4352:      	cmpq	$-0x16, %rbx
    4356:      	je	0x43a3 <generic_retkprobe_output+0x193>
    4358:      	cmpq	$-0x10, %rbx
    435c:      	jne	0x43e5 <generic_retkprobe_output+0x1d5>
    4362:      	addq	$0x2f0, %rax            # imm = 0x2F0
    4368:      	lock
    4369:      	incq	(%rax)
    436c:      	jmp	0x4313 <generic_retkprobe_output+0x103>
    436e:      	movq	%rax, %rbx
    4371:      	movl	$0x0, 0x4(%rsp)
    4379:      	movq	(%rip), %rdi            # 0x4380 <generic_retkprobe_output+0x170>
    4380:      	leaq	0x4(%rsp), %rsi
    4385:      	movl	$0x1, %eax
    438a:      	callq	*%rax
    438c:      	testq	%rax, %rax
    438f:      	je	0x4313 <generic_retkprobe_output+0x103>
    4391:      	cmpq	$-0xc, %rbx
    4395:      	jg	0x43d3 <generic_retkprobe_output+0x1c3>
    4397:      	cmpq	$-0x1c, %rbx
    439b:      	je	0x43f4 <generic_retkprobe_output+0x1e4>
    439d:      	cmpq	$-0x16, %rbx
    43a1:      	jne	0x4358 <generic_retkprobe_output+0x148>
    43a3:      	addq	$0x2f8, %rax            # imm = 0x2F8
    43a9:      	lock
    43aa:      	incq	(%rax)
    43ad:      	jmp	0x4313 <generic_retkprobe_output+0x103>
    43b2:      	cmpq	$-0xb, %rbx
    43b6:      	je	0x4403 <generic_retkprobe_output+0x1f3>
    43b8:      	cmpq	$-0x7, %rbx
    43bc:      	je	0x4412 <generic_retkprobe_output+0x202>
    43be:      	cmpq	$-0x2, %rbx
    43c2:      	jne	0x43e5 <generic_retkprobe_output+0x1d5>
    43c4:      	addq	$0x2e0, %rax            # imm = 0x2E0
    43ca:      	lock
    43cb:      	incq	(%rax)
    43ce:      	jmp	0x4313 <generic_retkprobe_output+0x103>
    43d3:      	cmpq	$-0xb, %rbx
    43d7:      	je	0x4403 <generic_retkprobe_output+0x1f3>
    43d9:      	cmpq	$-0x7, %rbx
    43dd:      	je	0x4412 <generic_retkprobe_output+0x202>
    43df:      	cmpq	$-0x2, %rbx
    43e3:      	je	0x43c4 <generic_retkprobe_output+0x1b4>
    43e5:      	addq	$0x2d8, %rax            # imm = 0x2D8
    43eb:      	lock
    43ec:      	incq	(%rax)
    43ef:      	jmp	0x4313 <generic_retkprobe_output+0x103>
    43f4:      	addq	$0x300, %rax            # imm = 0x300
    43fa:      	lock
    43fb:      	incq	(%rax)
    43fe:      	jmp	0x4313 <generic_retkprobe_output+0x103>
    4403:      	addq	$0x308, %rax            # imm = 0x308
    4409:      	lock
    440a:      	incq	(%rax)
    440d:      	jmp	0x4313 <generic_retkprobe_output+0x103>
    4412:      	addq	$0x2e8, %rax            # imm = 0x2E8
    4418:      	lock
    4419:      	incq	(%rax)
    441c:      	jmp	0x4313 <generic_retkprobe_output+0x103>

Disassembly of section kprobe/generic_retkprobe:

0000000000000000 <generic_retkprobe_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xf8, %rsp
      11:      	movq	%rdi, %r12
      14:      	movq	0x50(%rdi), %rax
      18:      	movq	%rax, 0xc0(%rsp)
      20:      	movl	$0x0, 0xe0(%rsp)
      2b:      	movq	(%rip), %rdi            # 0x32 <generic_retkprobe_event+0x32>
      32:      	leaq	0xe0(%rsp), %rsi
      3a:      	movl	$0x1, %eax
      3f:      	callq	*%rax
      41:      	xorl	%ebp, %ebp
      43:      	testq	%rax, %rax
      46:      	je	0x1dc9 <generic_retkprobe_event+0x1dc9>
      4c:      	movq	%rax, %r15
      4f:      	movq	%rax, %rbx
      52:      	leaq	0x5ef8(%rax), %rsi
      59:      	movl	$0x0, 0x5ef8(%r15)
      64:      	movq	(%rip), %rdi            # 0x6b <generic_retkprobe_event+0x6b>
      6b:      	movl	$0x1, %eax
      70:      	callq	*%rax
      72:      	testq	%rax, %rax
      75:      	je	0x1dc9 <generic_retkprobe_event+0x1dc9>
      7b:      	movq	%rax, %r13
      7e:      	movl	(%rax), %eax
      80:      	movq	%rax, 0x60(%rbx)
      84:      	movl	$0xe, %eax
      89:      	callq	*%rax
      8b:      	cmpq	$-0x16, %rax
      8f:      	jne	0xb1 <generic_retkprobe_event+0xb1>
      91:      	leaq	0x20(%r12), %rdx
      96:      	leaq	0x30(%rsp), %rdi
      9b:      	movl	$0x8, %ecx
      a0:      	movl	$0x4, %eax
      a5:      	movl	$0x8, %esi
      aa:      	callq	*%rax
      ac:      	movq	0x30(%rsp), %rax
      b1:      	movq	%rax, 0x68(%rbx)
      b5:      	movl	$0xe, %eax
      ba:      	callq	*%rax
      bc:      	movl	%eax, 0x7c(%rbx)
      bf:      	movq	0x60(%rbx), %rax
      c3:      	movq	0x68(%rbx), %rcx
      c7:      	movq	%rax, 0x30(%rsp)
      cc:      	movq	%rcx, 0x38(%rsp)
      d1:      	movq	(%rip), %rdi            # 0xd8 <generic_retkprobe_event+0xd8>
      d8:      	leaq	0x30(%rsp), %rsi
      dd:      	movl	$0x1, %eax
      e2:      	callq	*%rax
      e4:      	testq	%rax, %rax
      e7:      	je	0x1dc9 <generic_retkprobe_event+0x1dc9>
      ed:      	movq	(%rax), %r14
      f0:      	movq	0x8(%rax), %rcx
      f4:      	movq	%rcx, 0x90(%rsp)
      fc:      	movq	0x10(%rax), %rax
     100:      	movq	%rax, 0x88(%rsp)
     108:      	movq	(%rip), %rdi            # 0x10f <generic_retkprobe_event+0x10f>
     10f:      	leaq	0x30(%rsp), %rsi
     114:      	movl	$0x3, %eax
     119:      	callq	*%rax
     11b:      	movq	%r14, 0x90(%rbx)
     122:      	movl	0x58(%r13), %eax
     126:      	movl	0x5c(%r13), %r14d
     12a:      	testl	%r14d, %r14d
     12d:      	movq	%r13, 0x20(%rsp)
     132:      	je	0x1f1 <generic_retkprobe_event+0x1f1>
     138:      	movl	%eax, 0x28(%rsp)
     13c:      	movl	$0x0, 0x5ea0(%rbx)
     146:      	movq	0xc0(%rsp), %rbp
     14e:      	movl	$0x0, 0xe4(%rsp)
     159:      	movq	(%rip), %rdi            # 0x160 <generic_retkprobe_event+0x160>
     160:      	leaq	0xe4(%rsp), %rsi
     168:      	movl	$0x1, %eax
     16d:      	callq	*%rax
     16f:      	testq	%rax, %rax
     172:      	je	0x2e4 <generic_retkprobe_event+0x2e4>
     178:      	movl	0x5ea0(%rax), %ecx
     17e:      	movl	%ecx, 0x98(%rax)
     184:      	movq	$0xc, 0x5e78(%rax)
     18f:      	testl	%ecx, %ecx
     191:      	je	0x3b8 <generic_retkprobe_event+0x3b8>
     197:      	movl	$0x4, %ebp
     19c:      	addq	$0x8, %rbp
     1a0:      	movl	0x60(%r13), %eax
     1a4:      	cmpl	$0xb, %eax
     1a7:      	je	0x2f7 <generic_retkprobe_event+0x2f7>
     1ad:      	cmpl	$0xa, %eax
     1b0:      	jne	0x30d <generic_retkprobe_event+0x30d>
     1b6:      	movl	0x10(%rbx), %eax
     1b9:      	movl	%eax, 0x30(%rsp)
     1bd:      	movl	0x7c(%rbx), %eax
     1c0:      	movl	%eax, 0x34(%rsp)
     1c4:      	movq	0x18(%rbx), %rax
     1c8:      	movq	%rax, 0x38(%rsp)
     1cd:      	movq	(%rip), %rdi            # 0x1d4 <generic_retkprobe_event+0x1d4>
     1d4:      	xorl	%ecx, %ecx
     1d6:      	leaq	0xc0(%rsp), %rsi
     1de:      	leaq	0x30(%rsp), %rdx
     1e3:      	movl	$0x2, %eax
     1e8:      	xorl	%ecx, %ecx
     1ea:      	callq	*%rax
     1ec:      	jmp	0x30d <generic_retkprobe_event+0x30d>
     1f1:      	movl	$0x8, %ebp
     1f6:      	addq	$0x90, %r15
     1fd:      	cmpl	$0x3, %eax
     200:      	jne	0x327 <generic_retkprobe_event+0x327>
     206:      	movl	$0x0, (%r15,%rbp)
     20e:      	leaq	0x4(%rbp), %r14
     212:      	cmpq	$0x0, 0x88(%rsp)
     21b:      	movq	%r12, 0xb8(%rsp)
     223:      	je	0x41f <generic_retkprobe_event+0x41f>
     229:      	movq	%r14, 0x28(%rsp)
     22e:      	movq	0xc0(%rsp), %r14
     236:      	leaq	0x30(%rsp), %rdi
     23b:      	movl	$0x4, %r12d
     241:      	movl	$0x10, %ecx
     246:      	movl	$0x4, %eax
     24b:      	movq	0x90(%rsp), %rdx
     253:      	movl	$0x10, %esi
     258:      	callq	*%rax
     25a:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     25f:      	testl	%eax, %eax
     261:      	js	0x1b14 <generic_retkprobe_event+0x1b14>
     267:      	movq	0x38(%rsp), %rsi
     26c:      	cmpq	%r14, %rsi
     26f:      	movq	%r14, %rax
     272:      	movq	%r14, %r13
     275:      	cmovbq	%rsi, %r13
     279:      	testq	%r14, %r14
     27c:      	cmovneq	%r13, %rsi
     280:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
     285:      	cmpq	$0xffe, %rsi            # imm = 0xFFE
     28c:      	ja	0x1b14 <generic_retkprobe_event+0x1b14>
     292:      	addq	$0xc, %rbp
     296:      	movq	%rbp, 0x18(%rsp)
     29b:      	leaq	(%r15,%rbp), %rdi
     29f:      	movq	0x30(%rsp), %rcx
     2a4:      	movl	$0x4, %eax
     2a9:      	movq	0x30(%rsp), %rdx
     2ae:      	movq	%rsi, %rbp
     2b1:      	callq	*%rax
     2b3:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     2b8:      	testl	%eax, %eax
     2ba:      	js	0x1b14 <generic_retkprobe_event+0x1b14>
     2c0:      	movq	%rbp, %rdx
     2c3:      	testq	%r14, %r14
     2c6:      	je	0xcea <generic_retkprobe_event+0xcea>
     2cc:      	subq	%r13, %r14
     2cf:      	movq	%r14, 0x8(%rsp)
     2d4:      	movq	0x28(%rsp), %r14
     2d9:      	jne	0xcf6 <generic_retkprobe_event+0xcf6>
     2df:      	jmp	0x422 <generic_retkprobe_event+0x422>
     2e4:      	xorl	%ebp, %ebp
     2e6:      	addq	$0x8, %rbp
     2ea:      	movl	0x60(%r13), %eax
     2ee:      	cmpl	$0xb, %eax
     2f1:      	jne	0x1ad <generic_retkprobe_event+0x1ad>
     2f7:      	movq	(%rip), %rdi            # 0x2fe <generic_retkprobe_event+0x2fe>
     2fe:      	leaq	0xc0(%rsp), %rsi
     306:      	movl	$0x3, %eax
     30b:      	callq	*%rax
     30d:      	andl	$0x1fff, %ebp           # imm = 0x1FFF
     313:      	movl	0x28(%rsp), %eax
     317:      	addq	$0x90, %r15
     31e:      	cmpl	$0x3, %eax
     321:      	je	0x206 <generic_retkprobe_event+0x206>
     327:      	cmpl	$0x2, %eax
     32a:      	jne	0x1b30 <generic_retkprobe_event+0x1b30>
     330:      	movq	%rbx, 0x88(%rsp)
     338:      	movq	%r12, %rbx
     33b:      	movl	$0x0, (%r15,%rbp)
     343:      	movq	0xc0(%rsp), %r14
     34b:      	cmpq	$0xfff, %r14            # imm = 0xFFF
     352:      	movl	$0xfff, %r12d           # imm = 0xFFF
     358:      	cmovbq	%r14, %r12
     35c:      	leaq	(%r15,%rbp), %rdi
     360:      	addq	$0xc, %rdi
     364:      	movl	$0x4, %eax
     369:      	movq	0x90(%rsp), %rdx
     371:      	leaq	0x4(%rbp), %r13
     375:      	addq	%rbp, %r15
     378:      	addq	$0x4, %r15
     37c:      	movl	$0x4, %ebp
     381:      	movl	%r12d, %esi
     384:      	callq	*%rax
     386:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     38b:      	testl	%eax, %eax
     38d:      	js	0x39d <generic_retkprobe_event+0x39d>
     38f:      	movl	%r12d, 0x4(%r15)
     393:      	addq	$0x8, %r12
     397:      	movl	%r14d, %ecx
     39a:      	movq	%r12, %rbp
     39d:      	addq	%r13, %rbp
     3a0:      	movl	%ecx, (%r15)
     3a3:      	movq	%rbx, %r12
     3a6:      	movq	0x20(%rsp), %r13
     3ab:      	movq	0x88(%rsp), %rbx
     3b3:      	jmp	0x1b30 <generic_retkprobe_event+0x1b30>
     3b8:      	leaq	0x9c(%rax), %r13
     3bf:      	movq	%rbp, 0x30(%rsp)
     3c4:      	movq	$0x0, 0x70(%rsp)
     3cd:      	cmpl	$0x17, %r14d
     3d1:      	movq	%rax, (%rsp)
     3d5:      	movq	%r15, 0x18(%rsp)
     3da:      	movq	%r12, 0xb8(%rsp)
     3e2:      	jle	0x437 <generic_retkprobe_event+0x437>
     3e4:      	cmpl	$0x18, %r14d
     3e8:      	je	0x452 <generic_retkprobe_event+0x452>
     3ea:      	cmpl	$0x25, %r14d
     3ee:      	je	0x490 <generic_retkprobe_event+0x490>
     3f4:      	cmpl	$0x2a, %r14d
     3f8:      	jne	0xb33 <generic_retkprobe_event+0xb33>
     3fe:      	movq	$0x0, 0xa0(%rsp)
     40a:      	movq	%rbp, 0xa8(%rsp)
     412:      	leaq	0xa0(%rsp), %rax
     41a:      	jmp	0x4bd <generic_retkprobe_event+0x4bd>
     41f:      	xorl	%r13d, %r13d
     422:      	movl	%r13d, (%r15,%r14)
     426:      	movl	%r13d, 0x4(%r15,%r14)
     42b:      	addq	$0x8, %r13
     42f:      	movq	%r13, %r12
     432:      	jmp	0x1b1d <generic_retkprobe_event+0x1b1d>
     437:      	cmpl	$0xf, %r14d
     43b:      	je	0xa70 <generic_retkprobe_event+0xa70>
     441:      	cmpl	$0x10, %r14d
     445:      	jne	0xb33 <generic_retkprobe_event+0xb33>
     44b:      	leaq	0x10(%rsp), %r12
     450:      	jmp	0x47a <generic_retkprobe_event+0x47a>
     452:      	leaq	0x10(%rsp), %r12
     457:      	movl	$0x8, %ecx
     45c:      	movl	$0x4, %eax
     461:      	movq	0x30(%rsp), %rdx
     466:      	movq	%r12, %rdi
     469:      	movl	$0x8, %esi
     46e:      	callq	*%rax
     470:      	movq	0x10(%rsp), %rax
     475:      	movq	%rax, 0x30(%rsp)
     47a:      	leaq	0x30(%rsp), %rdx
     47f:      	movl	$0x8, %ecx
     484:      	movl	$0x4, %eax
     489:      	leaq	0x10(%rsp), %rdi
     48e:      	jmp	0x4ad <generic_retkprobe_event+0x4ad>
     490:      	addq	$0x40, %rbp
     494:      	movq	%rbp, 0x30(%rsp)
     499:      	leaq	0x10(%rsp), %rdi
     49e:      	movl	$0x8, %ecx
     4a3:      	movl	$0x4, %eax
     4a8:      	movq	0x30(%rsp), %rdx
     4ad:      	movl	$0x8, %esi
     4b2:      	callq	*%rax
     4b4:      	movq	0x10(%rsp), %rax
     4b9:      	addq	$0x40, %rax
     4bd:      	movq	%rax, 0x80(%rsp)
     4c5:      	movl	$0x0, 0xb4(%rsp)
     4d0:      	movq	(%rip), %rdi            # 0x4d7 <generic_retkprobe_event+0x4d7>
     4d7:      	leaq	0xb4(%rsp), %rsi
     4df:      	movl	$0x1, %eax
     4e4:      	callq	*%rax
     4e6:      	testq	%rax, %rax
     4e9:      	je	0x59c <generic_retkprobe_event+0x59c>
     4ef:      	movq	%rax, %r12
     4f2:      	addq	$0x1000, %rax           # imm = 0x1000
     4f8:      	movq	%rax, 0x8(%rsp)
     4fd:      	movl	$0x23, %eax
     502:      	callq	*%rax
     504:      	leaq	0xd50(%rax), %rdx
     50b:      	leaq	0xc8(%rsp), %rdi
     513:      	movl	$0x8, %ecx
     518:      	movl	$0x4, %eax
     51d:      	movl	$0x8, %esi
     522:      	callq	*%rax
     524:      	movq	0xc8(%rsp), %rbp
     52c:      	movq	0x80(%rsp), %rax
     534:      	leaq	0x8(%rax), %rdx
     538:      	leaq	0xd0(%rsp), %rdi
     540:      	movl	$0x8, %ecx
     545:      	movl	$0x4, %eax
     54a:      	leaq	0x18(%rbp), %rcx
     54e:      	movq	%rcx, 0xf0(%rsp)
     556:      	movl	$0x8, %esi
     55b:      	movq	%rdx, 0xe8(%rsp)
     563:      	callq	*%rax
     565:      	movq	0xd0(%rsp), %r13
     56d:      	leaq	0x10(%r13), %rdx
     571:      	leaq	0x30(%rsp), %rdi
     576:      	movl	$0x8, %ecx
     57b:      	movl	$0x4, %eax
     580:      	movl	$0x8, %esi
     585:      	callq	*%rax
     587:      	cmpq	$0x0, 0x30(%rsp)
     58d:      	movl	$0x1000, %r14d          # imm = 0x1000
     593:      	je	0x5a9 <generic_retkprobe_event+0x5a9>
     595:      	movq	0x8(%rsp), %rcx
     59a:      	jmp	0x5fc <generic_retkprobe_event+0x5fc>
     59c:      	xorl	%r12d, %r12d
     59f:      	movq	0x20(%rsp), %r13
     5a4:      	jmp	0x148f <generic_retkprobe_event+0x148f>
     5a9:      	leaq	0x18(%r13), %rdx
     5ad:      	leaq	0x30(%rsp), %rdi
     5b2:      	movl	$0x8, %ecx
     5b7:      	movl	$0x4, %eax
     5bc:      	movl	$0x8, %esi
     5c1:      	callq	*%rax
     5c3:      	cmpq	%r13, 0x30(%rsp)
     5c8:      	movq	0x8(%rsp), %rcx
     5cd:      	je	0x5fc <generic_retkprobe_event+0x5fc>
     5cf:      	movq	%r12, %rcx
     5d2:      	addq	$0xff6, %rcx            # imm = 0xFF6
     5d9:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
     5e3:      	movq	%rax, 0xff6(%r12)
     5eb:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
     5f6:      	movl	$0xff6, %r14d           # imm = 0xFF6
     5fc:      	movq	$0x0, 0x38(%rsp)
     605:      	movq	$0x0, 0x30(%rsp)
     60e:      	movq	%r12, 0x40(%rsp)
     613:      	movq	$0x0, 0x48(%rsp)
     61c:      	movq	$0x0, 0x50(%rsp)
     625:      	movq	$0x0, 0x58(%rsp)
     62e:      	movq	%rcx, 0x8(%rsp)
     633:      	movq	%rcx, 0x60(%rsp)
     638:      	movl	%r14d, 0x68(%rsp)
     63d:      	movb	$0x0, 0x6c(%rsp)
     642:      	addq	$0x20, %rbp
     646:      	leaq	0x30(%rsp), %rdi
     64b:      	movl	$0x8, %ecx
     650:      	movl	$0x4, %eax
     655:      	leaq	0x38(%rsp), %r14
     65a:      	leaq	0x48(%rsp), %r13
     65f:      	leaq	0x50(%rsp), %r12
     664:      	movl	$0x8, %esi
     669:      	movq	%rbp, %rdx
     66c:      	callq	*%rax
     66e:      	movl	$0x8, %ecx
     673:      	movl	$0x4, %eax
     678:      	movq	0xf0(%rsp), %rdx
     680:      	movq	%r14, %rdi
     683:      	movl	$0x8, %esi
     688:      	callq	*%rax
     68a:      	movl	$0x8, %ecx
     68f:      	movl	$0x4, %eax
     694:      	movq	0xe8(%rsp), %rdx
     69c:      	movq	%r13, %rdi
     69f:      	movl	$0x8, %esi
     6a4:      	callq	*%rax
     6a6:      	movl	$0x8, %ecx
     6ab:      	movl	$0x4, %eax
     6b0:      	movq	0x80(%rsp), %rdx
     6b8:      	movq	%r12, %rdi
     6bb:      	movl	$0x8, %esi
     6c0:      	callq	*%rax
     6c2:      	movq	0x50(%rsp), %rax
     6c7:      	addq	$-0x20, %rax
     6cb:      	movq	%rax, 0x58(%rsp)
     6d0:      	movq	(%rip), %rax            # 0x6d7 <generic_retkprobe_event+0x6d7>
     6d7:      	cmpb	$0x0, (%rax)
     6da:      	je	0x8ae <generic_retkprobe_event+0x8ae>
     6e0:      	movl	$0x80, %ebp
     6e5:      	movl	$0x8, %r14d
     6eb:      	movq	0x48(%rsp), %r13
     6f0:      	movq	0x50(%rsp), %rdx
     6f5:      	movq	0x58(%rsp), %r12
     6fa:      	cmpq	0x30(%rsp), %r13
     6ff:      	jne	0x70c <generic_retkprobe_event+0x70c>
     701:      	cmpq	0x38(%rsp), %rdx
     706:      	je	0xbdb <generic_retkprobe_event+0xbdb>
     70c:      	movl	$0x4, %eax
     711:      	leaq	0x98(%rsp), %rdi
     719:      	movl	$0x8, %esi
     71e:      	callq	*%rax
     720:      	cmpq	0x98(%rsp), %r13
     728:      	movl	$0x8, %r15d
     72e:      	je	0x840 <generic_retkprobe_event+0x840>
     734:      	leaq	0x18(%r13), %r14
     738:      	movl	$0x4, %eax
     73d:      	leaq	0x10(%rsp), %rdi
     742:      	movl	$0x8, %esi
     747:      	movq	%r14, %rdx
     74a:      	callq	*%rax
     74c:      	cmpq	%r13, 0x10(%rsp)
     751:      	je	0x840 <generic_retkprobe_event+0x840>
     757:      	movl	$0x4, %eax
     75c:      	leaq	0xd8(%rsp), %rdi
     764:      	movl	$0x8, %esi
     769:      	movq	%r14, %rdx
     76c:      	callq	*%rax
     76e:      	addq	$0x20, %r13
     772:      	movl	$0x4, %eax
     777:      	leaq	0x70(%rsp), %rdi
     77c:      	movl	$0x10, %ecx
     781:      	movl	$0x10, %esi
     786:      	movq	%r13, %rdx
     789:      	callq	*%rax
     78b:      	movq	0x40(%rsp), %r14
     790:      	movq	0x60(%rsp), %rax
     795:      	movl	0x74(%rsp), %r12d
     79a:      	subq	%r14, %rax
     79d:      	movl	0x68(%rsp), %r13d
     7a2:      	movl	%r12d, %edx
     7a5:      	subl	%r13d, %edx
     7a8:      	movl	$0x0, %ecx
     7ad:      	cmovbl	%ecx, %edx
     7b0:      	addq	0x78(%rsp), %rdx
     7b5:      	xorl	%esi, %esi
     7b7:      	cmpl	%r12d, %r13d
     7ba:      	seta	%sil
     7be:      	movl	%r12d, %ecx
     7c1:      	cmovbl	%r13d, %ecx
     7c5:      	addl	%ecx, %esi
     7c7:      	movl	%r13d, %edi
     7ca:      	subl	%esi, %edi
     7cc:      	movl	%edi, 0x68(%rsp)
     7d0:      	subq	%rsi, %rax
     7d3:      	movq	0x18(%rsp), %r15
     7d8:      	jb	0xbe0 <generic_retkprobe_event+0xbe0>
     7de:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     7e4:      	ja	0xbe0 <generic_retkprobe_event+0xbe0>
     7ea:      	cmpl	%r12d, %r13d
     7ed:      	jbe	0x7f4 <generic_retkprobe_event+0x7f4>
     7ef:      	movb	$0x2f, (%r14,%rax)
     7f4:      	xorl	%edi, %edi
     7f6:      	cmpl	%r12d, %r13d
     7f9:      	seta	%dil
     7fd:      	movzbl	%cl, %esi
     800:      	addq	%rax, %r14
     803:      	addq	%r14, %rdi
     806:      	movl	$0x4, %eax
     80b:      	callq	*%rax
     80d:      	movq	%r14, 0x60(%rsp)
     812:      	cmpl	%r12d, %r13d
     815:      	jbe	0xbe0 <generic_retkprobe_event+0xbe0>
     81b:      	movq	0xd8(%rsp), %rax
     823:      	movq	%rax, 0x48(%rsp)
     828:      	movq	0x20(%rsp), %r13
     82d:      	movl	$0x8, %r14d
     833:      	decl	%ebp
     835:      	jne	0x6eb <generic_retkprobe_event+0x6eb>
     83b:      	jmp	0xbe5 <generic_retkprobe_event+0xbe5>
     840:      	leaq	0x10(%r12), %rdx
     845:      	movl	$0x4, %eax
     84a:      	leaq	0x10(%rsp), %rdi
     84f:      	movl	$0x8, %esi
     854:      	callq	*%rax
     856:      	movq	0x58(%rsp), %rax
     85b:      	cmpq	0x10(%rsp), %rax
     860:      	movl	$0x8, %r14d
     866:      	je	0xdc5 <generic_retkprobe_event+0xdc5>
     86c:      	addq	$0x18, %r12
     870:      	movl	$0x4, %eax
     875:      	leaq	0x48(%rsp), %rdi
     87a:      	movl	$0x8, %esi
     87f:      	movq	%r12, %rdx
     882:      	callq	*%rax
     884:      	movq	0x10(%rsp), %rax
     889:      	movq	%rax, 0x58(%rsp)
     88e:      	addq	$0x20, %rax
     892:      	movq	%rax, 0x50(%rsp)
     897:      	movq	0x20(%rsp), %r13
     89c:      	movq	0x18(%rsp), %r15
     8a1:      	decl	%ebp
     8a3:      	jne	0x6eb <generic_retkprobe_event+0x6eb>
     8a9:      	jmp	0xbe5 <generic_retkprobe_event+0xbe5>
     8ae:      	movl	$0x80, %ebp
     8b3:      	movl	$0x8, %r14d
     8b9:      	jmp	0x8c3 <generic_retkprobe_event+0x8c3>
     8bb:      	decl	%ebp
     8bd:      	je	0xbe5 <generic_retkprobe_event+0xbe5>
     8c3:      	movq	0x48(%rsp), %r13
     8c8:      	movq	0x50(%rsp), %rdx
     8cd:      	movq	0x58(%rsp), %r12
     8d2:      	cmpq	0x30(%rsp), %r13
     8d7:      	jne	0x8e4 <generic_retkprobe_event+0x8e4>
     8d9:      	cmpq	0x38(%rsp), %rdx
     8de:      	je	0xbdb <generic_retkprobe_event+0xbdb>
     8e4:      	movl	$0x4, %eax
     8e9:      	leaq	0x98(%rsp), %rdi
     8f1:      	movl	$0x8, %esi
     8f6:      	callq	*%rax
     8f8:      	cmpq	0x98(%rsp), %r13
     900:      	movl	$0x8, %ecx
     905:      	je	0xa0f <generic_retkprobe_event+0xa0f>
     90b:      	leaq	0x18(%r13), %r14
     90f:      	movl	$0x4, %eax
     914:      	leaq	0x10(%rsp), %rdi
     919:      	movl	$0x8, %esi
     91e:      	movq	%r14, %rdx
     921:      	callq	*%rax
     923:      	movl	$0x8, %ecx
     928:      	cmpq	%r13, 0x10(%rsp)
     92d:      	je	0xa0f <generic_retkprobe_event+0xa0f>
     933:      	movl	$0x4, %eax
     938:      	leaq	0xd8(%rsp), %rdi
     940:      	movl	$0x8, %esi
     945:      	movq	%r14, %rdx
     948:      	callq	*%rax
     94a:      	addq	$0x20, %r13
     94e:      	movl	$0x4, %eax
     953:      	leaq	0x70(%rsp), %rdi
     958:      	movl	$0x10, %ecx
     95d:      	movl	$0x10, %esi
     962:      	movq	%r13, %rdx
     965:      	callq	*%rax
     967:      	movq	0x40(%rsp), %r14
     96c:      	movq	0x60(%rsp), %rax
     971:      	movl	0x74(%rsp), %r12d
     976:      	subq	%r14, %rax
     979:      	movl	0x68(%rsp), %r13d
     97e:      	movl	%r12d, %edx
     981:      	subl	%r13d, %edx
     984:      	movl	$0x0, %ecx
     989:      	cmovbl	%ecx, %edx
     98c:      	addq	0x78(%rsp), %rdx
     991:      	xorl	%esi, %esi
     993:      	cmpl	%r12d, %r13d
     996:      	seta	%sil
     99a:      	movl	%r12d, %ecx
     99d:      	cmovbl	%r13d, %ecx
     9a1:      	addl	%ecx, %esi
     9a3:      	movl	%r13d, %edi
     9a6:      	subl	%esi, %edi
     9a8:      	movl	%edi, 0x68(%rsp)
     9ac:      	subq	%rsi, %rax
     9af:      	jb	0xbe0 <generic_retkprobe_event+0xbe0>
     9b5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     9bb:      	ja	0xbe0 <generic_retkprobe_event+0xbe0>
     9c1:      	cmpl	%r12d, %r13d
     9c4:      	jbe	0x9cb <generic_retkprobe_event+0x9cb>
     9c6:      	movb	$0x2f, (%r14,%rax)
     9cb:      	xorl	%edi, %edi
     9cd:      	cmpl	%r12d, %r13d
     9d0:      	seta	%dil
     9d4:      	movzbl	%cl, %esi
     9d7:      	addq	%rax, %r14
     9da:      	addq	%r14, %rdi
     9dd:      	movl	$0x4, %eax
     9e2:      	callq	*%rax
     9e4:      	movq	%r14, 0x60(%rsp)
     9e9:      	cmpl	%r12d, %r13d
     9ec:      	jbe	0xbe0 <generic_retkprobe_event+0xbe0>
     9f2:      	movq	0xd8(%rsp), %rax
     9fa:      	movq	%rax, 0x48(%rsp)
     9ff:      	movq	0x20(%rsp), %r13
     a04:      	movl	$0x8, %r14d
     a0a:      	jmp	0x8bb <generic_retkprobe_event+0x8bb>
     a0f:      	leaq	0x10(%r12), %rdx
     a14:      	movl	$0x4, %eax
     a19:      	leaq	0x10(%rsp), %rdi
     a1e:      	movl	$0x8, %esi
     a23:      	callq	*%rax
     a25:      	movq	0x58(%rsp), %rax
     a2a:      	cmpq	0x10(%rsp), %rax
     a2f:      	movl	$0x8, %r14d
     a35:      	je	0xbdb <generic_retkprobe_event+0xbdb>
     a3b:      	addq	$0x18, %r12
     a3f:      	movl	$0x4, %eax
     a44:      	leaq	0x48(%rsp), %rdi
     a49:      	movl	$0x8, %esi
     a4e:      	movq	%r12, %rdx
     a51:      	callq	*%rax
     a53:      	movq	0x10(%rsp), %rax
     a58:      	movq	%rax, 0x58(%rsp)
     a5d:      	addq	$0x20, %rax
     a61:      	movq	%rax, 0x50(%rsp)
     a66:      	movq	0x20(%rsp), %r13
     a6b:      	jmp	0x8bb <generic_retkprobe_event+0x8bb>
     a70:      	leaq	0x70(%rsp), %rdi
     a75:      	leaq	0x30(%rsp), %rdx
     a7a:      	movl	$0x8, %ecx
     a7f:      	movl	$0x4, %eax
     a84:      	movl	$0x8, %esi
     a89:      	callq	*%rax
     a8b:      	movq	0x70(%rsp), %rax
     a90:      	movq	%rax, 0x80(%rsp)
     a98:      	testq	%rax, %rax
     a9b:      	jne	0x4c5 <generic_retkprobe_event+0x4c5>
     aa1:      	movl	$0x0, 0xa0(%rsp)
     aac:      	movq	(%rip), %rdi            # 0xab3 <generic_retkprobe_event+0xab3>
     ab3:      	leaq	0xa0(%rsp), %rsi
     abb:      	movl	$0x1, %eax
     ac0:      	callq	*%rax
     ac2:      	testq	%rax, %rax
     ac5:      	je	0xcdd <generic_retkprobe_event+0xcdd>
     acb:      	movq	%r13, 0x8(%rsp)
     ad0:      	xorl	%r12d, %r12d
     ad3:      	cmpl	$0x19, %r14d
     ad7:      	movq	0x20(%rsp), %r13
     adc:      	movq	(%rsp), %rcx
     ae0:      	jg	0x1015 <generic_retkprobe_event+0x1015>
     ae6:      	cmpl	$0x12, %r14d
     aea:      	jle	0x1171 <generic_retkprobe_event+0x1171>
     af0:      	cmpl	$0x14, %r14d
     af4:      	jle	0x14d1 <generic_retkprobe_event+0x14d1>
     afa:      	cmpl	$0x15, %r14d
     afe:      	je	0x217d <generic_retkprobe_event+0x217d>
     b04:      	cmpl	$0x16, %r14d
     b08:      	je	0x20e5 <generic_retkprobe_event+0x20e5>
     b0e:      	cmpl	$0x17, %r14d
     b12:      	jne	0x1485 <generic_retkprobe_event+0x1485>
     b18:      	movl	$0x0, 0xa0(%rcx)
     b22:      	movl	%ebp, 0x9c(%rcx)
     b28:      	movl	$0x8, %r12d
     b2e:      	jmp	0x1485 <generic_retkprobe_event+0x1485>
     b33:      	cmpl	$0x2c, %r14d
     b37:      	ja	0xaa1 <generic_retkprobe_event+0xaa1>
     b3d:      	movl	%r14d, %eax
     b40:      	movabsq	$0x11c1f2027cf2, %rcx   # imm = 0x11C1F2027CF2
     b4a:      	btq	%rax, %rcx
     b4e:      	jae	0xaa1 <generic_retkprobe_event+0xaa1>
     b54:      	movq	%rbp, 0x10(%rsp)
     b59:      	movl	$0x0, 0xd8(%rsp)
     b64:      	movq	(%rip), %rdi            # 0xb6b <generic_retkprobe_event+0xb6b>
     b6b:      	leaq	0xd8(%rsp), %rsi
     b73:      	movl	$0x1, %eax
     b78:      	callq	*%rax
     b7a:      	testq	%rax, %rax
     b7d:      	je	0xcdd <generic_retkprobe_event+0xcdd>
     b83:      	movq	%r13, %rbp
     b86:      	xorl	%r12d, %r12d
     b89:      	cmpl	$0x10, %r14d
     b8d:      	jle	0xdd9 <generic_retkprobe_event+0xdd9>
     b93:      	cmpl	$0x1e, %r14d
     b97:      	movq	0x20(%rsp), %r13
     b9c:      	jle	0xf59 <generic_retkprobe_event+0xf59>
     ba2:      	cmpl	$0x26, %r14d
     ba6:      	jg	0x104b <generic_retkprobe_event+0x104b>
     bac:      	leal	-0x1f(%r14), %eax
     bb0:      	cmpl	$0x2, %eax
     bb3:      	jae	0x15a5 <generic_retkprobe_event+0x15a5>
     bb9:      	leaq	0x10(%rsp), %rdx
     bbe:      	movl	$0x4, %r12d
     bc4:      	movl	$0x1, %ecx
     bc9:      	movl	$0x4, %eax
     bce:      	movq	%rbp, %rdi
     bd1:      	movl	$0x1, %esi
     bd6:      	jmp	0x147f <generic_retkprobe_event+0x147f>
     bdb:      	movb	$0x1, 0x6c(%rsp)
     be0:      	movq	0x20(%rsp), %r13
     be5:      	movq	0x60(%rsp), %rax
     bea:      	movq	0x8(%rsp), %rdx
     bef:      	xorl	%ebp, %ebp
     bf1:      	cmpq	%rdx, %rax
     bf4:      	je	0xc24 <generic_retkprobe_event+0xc24>
     bf6:      	cmpb	$0x0, 0x6c(%rsp)
     bfb:      	sete	%cl
     bfe:      	movl	0x68(%rsp), %edx
     c02:      	movl	$0x1000, %r12d          # imm = 0x1000
     c08:      	subl	%edx, %r12d
     c0b:      	testl	%edx, %edx
     c0d:      	cmovlel	%edx, %r12d
     c11:      	testq	%rax, %rax
     c14:      	je	0xcd5 <generic_retkprobe_event+0xcd5>
     c1a:      	movb	%cl, %bpl
     c1d:      	addl	%ebp, %ebp
     c1f:      	movq	%rax, %rdx
     c22:      	jmp	0xc27 <generic_retkprobe_event+0xc27>
     c24:      	xorl	%r12d, %r12d
     c27:      	movq	(%rsp), %r14
     c2b:      	movq	%r14, %rdi
     c2e:      	addq	$0xa0, %rdi
     c35:      	andl	$0xfff, %r12d           # imm = 0xFFF
     c3c:      	movl	$0x4, %eax
     c41:      	movl	%r12d, %esi
     c44:      	callq	*%rax
     c46:      	movl	%r12d, 0x9c(%r14)
     c4d:      	leaq	0x30(%rsp), %rdi
     c52:      	movl	$0x8, %ecx
     c57:      	movl	$0x4, %eax
     c5c:      	movq	0xe8(%rsp), %rdx
     c64:      	movl	$0x8, %esi
     c69:      	callq	*%rax
     c6b:      	movq	0x30(%rsp), %rcx
     c70:      	addq	$0x30, %rcx
     c74:      	leaq	0x70(%rsp), %rdi
     c79:      	movl	$0x8, %edx
     c7e:      	movl	$0x4, %eax
     c83:      	movq	0x30(%rsp), %rdx
     c88:      	addq	$0x30, %rdx
     c8c:      	movl	$0x8, %esi
     c91:      	callq	*%rax
     c93:      	movq	0x70(%rsp), %rcx
     c98:      	leaq	0x10(%rsp), %rdi
     c9d:      	movl	$0x2, %edx
     ca2:      	movl	$0x4, %eax
     ca7:      	movq	0x70(%rsp), %rdx
     cac:      	movl	$0x2, %esi
     cb1:      	callq	*%rax
     cb3:      	movq	%r14, %rcx
     cb6:      	movl	%ebp, 0xa0(%r14,%r12)
     cbe:      	movzwl	0x10(%rsp), %eax
     cc3:      	movw	%ax, 0xa4(%r14,%r12)
     ccc:      	addl	$0xa, %r12d
     cd0:      	jmp	0x1485 <generic_retkprobe_event+0x1485>
     cd5:      	xorl	%r12d, %r12d
     cd8:      	jmp	0x148f <generic_retkprobe_event+0x148f>
     cdd:      	xorl	%r12d, %r12d
     ce0:      	movq	0x20(%rsp), %r13
     ce5:      	jmp	0x1481 <generic_retkprobe_event+0x1481>
     cea:      	xorl	%eax, %eax
     cec:      	movq	%rax, 0x8(%rsp)
     cf1:      	movq	0x28(%rsp), %r14
     cf6:      	cmpq	$0x1, 0x88(%rsp)
     cff:      	jne	0xd09 <generic_retkprobe_event+0xd09>
     d01:      	movq	%rdx, %r13
     d04:      	jmp	0x422 <generic_retkprobe_event+0x422>
     d09:      	movq	0x90(%rsp), %rax
     d11:      	leaq	0x10(%rax), %rdx
     d15:      	leaq	0x30(%rsp), %rdi
     d1a:      	movl	$0x4, %r12d
     d20:      	movl	$0x10, %ecx
     d25:      	movl	$0x4, %eax
     d2a:      	movl	$0x10, %esi
     d2f:      	callq	*%rax
     d31:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     d36:      	testl	%eax, %eax
     d38:      	js	0x1b19 <generic_retkprobe_event+0x1b19>
     d3e:      	movq	0x38(%rsp), %rsi
     d43:      	movq	0x8(%rsp), %rax
     d48:      	cmpq	%rax, %rsi
     d4b:      	movq	%rax, %r13
     d4e:      	cmovbq	%rsi, %r13
     d52:      	testq	%rax, %rax
     d55:      	cmovneq	%r13, %rsi
     d59:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
     d5e:      	cmpq	$0xffe, %rsi            # imm = 0xFFE
     d65:      	ja	0x1b19 <generic_retkprobe_event+0x1b19>
     d6b:      	movq	0x18(%rsp), %rax
     d70:      	addq	%rbp, %rax
     d73:      	movq	%rax, 0x18(%rsp)
     d78:      	leaq	(%r15,%rax), %rdi
     d7c:      	movq	0x30(%rsp), %rcx
     d81:      	movl	$0x4, %eax
     d86:      	movq	0x30(%rsp), %rdx
     d8b:      	movq	%rsi, (%rsp)
     d8f:      	movq	(%rsp), %rsi
     d93:      	callq	*%rax
     d95:      	movq	(%rsp), %rdx
     d99:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     d9e:      	testl	%eax, %eax
     da0:      	js	0x1b19 <generic_retkprobe_event+0x1b19>
     da6:      	addq	%rdx, %rbp
     da9:      	movq	0x8(%rsp), %r14
     dae:      	testq	%r14, %r14
     db1:      	je	0x1a44 <generic_retkprobe_event+0x1a44>
     db7:      	subq	%r13, %r14
     dba:      	jne	0x1a47 <generic_retkprobe_event+0x1a47>
     dc0:      	jmp	0x1ddd <generic_retkprobe_event+0x1ddd>
     dc5:      	movb	$0x1, 0x6c(%rsp)
     dca:      	movq	0x20(%rsp), %r13
     dcf:      	movq	0x18(%rsp), %r15
     dd4:      	jmp	0xbe5 <generic_retkprobe_event+0xbe5>
     dd9:      	cmpl	$0x9, %r14d
     ddd:      	movq	0x20(%rsp), %r13
     de2:      	jg	0xf8a <generic_retkprobe_event+0xf8a>
     de8:      	cmpl	$0x4, %r14d
     dec:      	movq	(%rsp), %rcx
     df0:      	jle	0x11c7 <generic_retkprobe_event+0x11c7>
     df6:      	cmpl	$0x5, %r14d
     dfa:      	je	0x1790 <generic_retkprobe_event+0x1790>
     e00:      	cmpl	$0x6, %r14d
     e04:      	je	0xff2 <generic_retkprobe_event+0xff2>
     e0a:      	movq	%rax, 0x18(%rsp)
     e0f:      	cmpl	$0x7, %r14d
     e13:      	jne	0x1485 <generic_retkprobe_event+0x1485>
     e19:      	movq	0x10(%rsp), %r12
     e1e:      	movq	%r12, 0xc4(%rcx)
     e25:      	leaq	0xc2(%rcx), %rdi
     e2c:      	leaq	0x10(%r12), %rdx
     e31:      	movq	%rcx, %r14
     e34:      	movl	$0x2, %ecx
     e39:      	movl	$0x4, %eax
     e3e:      	movl	$0x2, %esi
     e43:      	callq	*%rax
     e45:      	leaq	0xd6(%r14), %rdi
     e4c:      	leaq	0x12(%r12), %rdx
     e51:      	movl	$0x1, %ecx
     e56:      	movl	$0x4, %eax
     e5b:      	movl	$0x1, %esi
     e60:      	callq	*%rax
     e62:      	leaq	0xd4(%r14), %rdi
     e69:      	leaq	0x226(%r12), %rdx
     e71:      	movl	$0x2, %ecx
     e76:      	movl	$0x4, %eax
     e7b:      	movl	$0x2, %esi
     e80:      	callq	*%rax
     e82:      	leaq	0xc0(%r14), %rdi
     e89:      	leaq	0x224(%r12), %rdx
     e91:      	movl	$0x2, %ecx
     e96:      	movl	$0x4, %eax
     e9b:      	movl	$0x2, %esi
     ea0:      	callq	*%rax
     ea2:      	leaq	0xcc(%r14), %rdi
     ea9:      	leaq	0x21c(%r12), %rdx
     eb1:      	movl	$0x4, %ecx
     eb6:      	movl	$0x4, %eax
     ebb:      	movl	$0x4, %esi
     ec0:      	callq	*%rax
     ec2:      	leaq	0xd0(%r14), %rdi
     ec9:      	leaq	0x218(%r12), %rdx
     ed1:      	movl	$0x4, %ecx
     ed6:      	movl	$0x4, %eax
     edb:      	movl	$0x4, %esi
     ee0:      	callq	*%rax
     ee2:      	leaq	0xac(%r14), %r13
     ee9:      	movq	%rbp, %rax
     eec:      	movq	$0x0, (%rbp)
     ef4:      	movq	$0x0, 0x8(%rbp)
     efc:      	movq	$0x0, 0x10(%rbp)
     f04:      	movq	$0x0, 0x18(%rbp)
     f0c:      	movzwl	0xc2(%r14), %eax
     f14:      	cmpl	$0xa, %eax
     f17:      	je	0x248c <generic_retkprobe_event+0x248c>
     f1d:      	cmpl	$0x2, %eax
     f20:      	jne	0x24be <generic_retkprobe_event+0x24be>
     f26:      	leaq	0x4(%r12), %rdx
     f2b:      	movl	$0x4, %ecx
     f30:      	movl	$0x4, %eax
     f35:      	movq	%rbp, %rdi
     f38:      	movl	$0x4, %esi
     f3d:      	callq	*%rax
     f3f:      	movl	$0x4, %ecx
     f44:      	movl	$0x4, %eax
     f49:      	movq	%r13, %rdi
     f4c:      	movl	$0x4, %esi
     f51:      	movq	%r12, %rdx
     f54:      	jmp	0x24bc <generic_retkprobe_event+0x24bc>
     f59:      	cmpl	$0x1c, %r14d
     f5d:      	jg	0x11a5 <generic_retkprobe_event+0x11a5>
     f63:      	cmpl	$0x11, %r14d
     f67:      	je	0x15e2 <generic_retkprobe_event+0x15e2>
     f6d:      	cmpl	$0x19, %r14d
     f71:      	je	0x16ae <generic_retkprobe_event+0x16ae>
     f77:      	cmpl	$0x1c, %r14d
     f7b:      	movq	(%rsp), %rcx
     f7f:      	je	0x11d7 <generic_retkprobe_event+0x11d7>
     f85:      	jmp	0x1485 <generic_retkprobe_event+0x1485>
     f8a:      	leal	-0xa(%r14), %eax
     f8e:      	cmpl	$0x2, %eax
     f91:      	movq	(%rsp), %rcx
     f95:      	jb	0x11d7 <generic_retkprobe_event+0x11d7>
     f9b:      	leal	-0xc(%r14), %eax
     f9f:      	cmpl	$0x2, %eax
     fa2:      	jb	0x11f9 <generic_retkprobe_event+0x11f9>
     fa8:      	cmpl	$0xe, %r14d
     fac:      	jne	0x1485 <generic_retkprobe_event+0x1485>
     fb2:      	leaq	0x30(%rsp), %rdi
     fb7:      	leaq	0x10(%rsp), %r14
     fbc:      	movl	$0x8, %ecx
     fc1:      	movl	$0x4, %eax
     fc6:      	movl	$0x8, %esi
     fcb:      	movq	%r14, %rdx
     fce:      	callq	*%rax
     fd0:      	movq	0x30(%rsp), %rcx
     fd5:      	movl	$0x8, %edx
     fda:      	movl	$0x4, %eax
     fdf:      	movq	0x30(%rsp), %rdx
     fe4:      	movq	%r14, %rdi
     fe7:      	movl	$0x8, %esi
     fec:      	callq	*%rax
     fee:      	movq	(%rsp), %rcx
     ff2:      	movq	0x10(%rsp), %rdx
     ff7:      	movq	%rcx, %rdi
     ffa:      	addq	$0xa0, %rdi
    1001:      	movl	$0x1001, %ecx           # imm = 0x1001
    1006:      	movl	$0x2d, %eax
    100b:      	movl	$0x1001, %esi           # imm = 0x1001
    1010:      	jmp	0x198a <generic_retkprobe_event+0x198a>
    1015:      	cmpl	$0x20, %r14d
    1019:      	jle	0x139c <generic_retkprobe_event+0x139c>
    101f:      	leal	-0x21(%r14), %edx
    1023:      	cmpl	$0x4, %edx
    1026:      	jae	0x121b <generic_retkprobe_event+0x121b>
    102c:      	movl	$0x8, %r12d
    1032:      	movl	$0x8, %ecx
    1037:      	movl	$0x4, %eax
    103c:      	movq	0x8(%rsp), %rdi
    1041:      	movl	$0x8, %esi
    1046:      	jmp	0x147c <generic_retkprobe_event+0x147c>
    104b:      	cmpl	$0x27, %r14d
    104f:      	je	0x1966 <generic_retkprobe_event+0x1966>
    1055:      	cmpl	$0x28, %r14d
    1059:      	je	0x19a9 <generic_retkprobe_event+0x19a9>
    105f:      	cmpl	$0x2c, %r14d
    1063:      	movq	(%rsp), %rcx
    1067:      	jne	0x1485 <generic_retkprobe_event+0x1485>
    106d:      	movq	0x10(%rsp), %r12
    1072:      	movb	$0x0, 0x30(%rsp)
    1077:      	movq	$0x0, 0x68(%rbp)
    107f:      	movq	$0x0, 0x60(%rbp)
    1087:      	movq	$0x0, 0x58(%rbp)
    108f:      	movq	$0x0, 0x50(%rbp)
    1097:      	movq	$0x0, 0x48(%rbp)
    109f:      	movq	$0x0, 0x40(%rbp)
    10a7:      	movq	$0x0, 0x38(%rbp)
    10af:      	movq	$0x0, 0x30(%rbp)
    10b7:      	movq	$0x0, 0x28(%rbp)
    10bf:      	movq	$0x0, 0x20(%rbp)
    10c7:      	movq	$0x0, 0x18(%rbp)
    10cf:      	movq	$0x0, 0x10(%rbp)
    10d7:      	movq	$0x0, 0x8(%rbp)
    10df:      	movq	$0x0, (%rbp)
    10e7:      	movl	$0x2, %ecx
    10ec:      	movl	$0x4, %eax
    10f1:      	movq	%rbp, %rdi
    10f4:      	movl	$0x2, %esi
    10f9:      	movq	%r12, %rdx
    10fc:      	callq	*%rax
    10fe:      	testq	%rax, %rax
    1101:      	js	0x26d2 <generic_retkprobe_event+0x26d2>
    1107:      	leaq	0x2(%r12), %r13
    110c:      	leaq	0x30(%rsp), %rdi
    1111:      	movl	$0x1, %ecx
    1116:      	movl	$0x4, %eax
    111b:      	movl	$0x1, %esi
    1120:      	movq	%r13, %rdx
    1123:      	callq	*%rax
    1125:      	testq	%rax, %rax
    1128:      	js	0x26d2 <generic_retkprobe_event+0x26d2>
    112e:      	movq	(%rsp), %rax
    1132:      	movq	%rax, %rdi
    1135:      	addq	$0xa0, %rdi
    113c:      	cmpb	$0x0, 0x30(%rsp)
    1141:      	sete	0x9e(%rax)
    1148:      	je	0x26a7 <generic_retkprobe_event+0x26a7>
    114e:      	movl	$0x6c, %ecx
    1153:      	movl	$0x2d, %eax
    1158:      	movl	$0x6c, %esi
    115d:      	movq	%r13, %rdx
    1160:      	callq	*%rax
    1162:      	testl	%eax, %eax
    1164:      	js	0x26d2 <generic_retkprobe_event+0x26d2>
    116a:      	decb	%al
    116c:      	jmp	0x26c8 <generic_retkprobe_event+0x26c8>
    1171:      	cmpl	$0x7, %r14d
    1175:      	jg	0x145d <generic_retkprobe_event+0x145d>
    117b:      	cmpl	$0x2, %r14d
    117f:      	je	0x1dea <generic_retkprobe_event+0x1dea>
    1185:      	cmpl	$0x3, %r14d
    1189:      	jne	0x1485 <generic_retkprobe_event+0x1485>
    118f:      	movq	$0x0, 0x9c(%rax)
    119a:      	movl	$0x8, %r12d
    11a0:      	jmp	0x1485 <generic_retkprobe_event+0x1485>
    11a5:      	leaq	0x10(%rsp), %rdx
    11aa:      	movl	$0x4, %r12d
    11b0:      	movl	$0x2, %ecx
    11b5:      	movl	$0x4, %eax
    11ba:      	movq	%rbp, %rdi
    11bd:      	movl	$0x2, %esi
    11c2:      	jmp	0x147f <generic_retkprobe_event+0x147f>
    11c7:      	cmpl	$0x1, %r14d
    11cb:      	je	0x11f9 <generic_retkprobe_event+0x11f9>
    11cd:      	cmpl	$0x4, %r14d
    11d1:      	jne	0x1485 <generic_retkprobe_event+0x1485>
    11d7:      	movl	$0x8, %r12d
    11dd:      	leaq	0x10(%rsp), %rdx
    11e2:      	movl	$0x8, %ecx
    11e7:      	movl	$0x4, %eax
    11ec:      	movq	%rbp, %rdi
    11ef:      	movl	$0x8, %esi
    11f4:      	jmp	0x147f <generic_retkprobe_event+0x147f>
    11f9:      	leaq	0x10(%rsp), %rdx
    11fe:      	movl	$0x4, %r12d
    1204:      	movl	$0x4, %ecx
    1209:      	movl	$0x4, %eax
    120e:      	movq	%rbp, %rdi
    1211:      	movl	$0x4, %esi
    1216:      	jmp	0x147f <generic_retkprobe_event+0x147f>
    121b:      	cmpl	$0x2b, %r14d
    121f:      	je	0x2288 <generic_retkprobe_event+0x2288>
    1225:      	cmpl	$0x29, %r14d
    1229:      	jne	0x1485 <generic_retkprobe_event+0x1485>
    122f:      	movq	%rax, 0x80(%rsp)
    1237:      	addq	$0x18, %rbp
    123b:      	leaq	0x30(%rsp), %rdi
    1240:      	movl	$0x4, %r14d
    1246:      	movl	$0x8, %ecx
    124b:      	movl	$0x4, %eax
    1250:      	movl	$0x8, %esi
    1255:      	movq	%rbp, %rdx
    1258:      	callq	*%rax
    125a:      	movq	0x30(%rsp), %r12
    125f:      	testq	%r12, %r12
    1262:      	je	0x276e <generic_retkprobe_event+0x276e>
    1268:      	movq	(%rsp), %rbp
    126c:      	movq	%r12, 0xc4(%rbp)
    1273:      	leaq	0xc2(%rbp), %rdi
    127a:      	leaq	0x10(%r12), %rdx
    127f:      	movl	$0x2, %ecx
    1284:      	movl	$0x4, %eax
    1289:      	movl	$0x2, %esi
    128e:      	callq	*%rax
    1290:      	leaq	0xd6(%rbp), %rdi
    1297:      	leaq	0x12(%r12), %rdx
    129c:      	movl	$0x1, %ecx
    12a1:      	movl	$0x4, %eax
    12a6:      	movl	$0x1, %esi
    12ab:      	callq	*%rax
    12ad:      	leaq	0xd4(%rbp), %rdi
    12b4:      	leaq	0x226(%r12), %rdx
    12bc:      	movl	$0x2, %ecx
    12c1:      	movl	$0x4, %eax
    12c6:      	movl	$0x2, %esi
    12cb:      	callq	*%rax
    12cd:      	leaq	0xc0(%rbp), %rdi
    12d4:      	leaq	0x224(%r12), %rdx
    12dc:      	movl	$0x2, %ecx
    12e1:      	movl	$0x4, %eax
    12e6:      	movl	$0x2, %esi
    12eb:      	callq	*%rax
    12ed:      	leaq	0xcc(%rbp), %rdi
    12f4:      	leaq	0x21c(%r12), %rdx
    12fc:      	movl	$0x4, %eax
    1301:      	movl	$0x4, %esi
    1306:      	callq	*%rax
    1308:      	leaq	0xd0(%rbp), %rdi
    130f:      	leaq	0x218(%r12), %rdx
    1317:      	movl	$0x4, %eax
    131c:      	movl	$0x4, %esi
    1321:      	callq	*%rax
    1323:      	leaq	0xac(%rbp), %r13
    132a:      	movq	0x8(%rsp), %rax
    132f:      	movq	$0x0, (%rax)
    1336:      	movq	$0x0, 0x8(%rax)
    133e:      	movq	$0x0, 0x10(%rax)
    1346:      	movq	$0x0, 0x18(%rax)
    134e:      	movzwl	0xc2(%rbp), %eax
    1355:      	cmpl	$0xa, %eax
    1358:      	je	0x26e2 <generic_retkprobe_event+0x26e2>
    135e:      	cmpl	$0x2, %eax
    1361:      	jne	0x2716 <generic_retkprobe_event+0x2716>
    1367:      	leaq	0x4(%r12), %rdx
    136c:      	movl	$0x4, %ecx
    1371:      	movl	$0x4, %eax
    1376:      	movq	0x8(%rsp), %rdi
    137b:      	movl	$0x4, %esi
    1380:      	callq	*%rax
    1382:      	movl	$0x4, %ecx
    1387:      	movl	$0x4, %eax
    138c:      	movq	%r13, %rdi
    138f:      	movl	$0x4, %esi
    1394:      	movq	%r12, %rdx
    1397:      	jmp	0x2714 <generic_retkprobe_event+0x2714>
    139c:      	cmpl	$0x1a, %r14d
    13a0:      	je	0x2332 <generic_retkprobe_event+0x2332>
    13a6:      	cmpl	$0x1b, %r14d
    13aa:      	jne	0x1485 <generic_retkprobe_event+0x1485>
    13b0:      	movq	0x8(%rsp), %rax
    13b5:      	movq	$0x0, 0x48(%rax)
    13bd:      	movq	$0x0, 0x40(%rax)
    13c5:      	movq	$0x0, 0x38(%rax)
    13cd:      	movq	$0x0, 0x30(%rax)
    13d5:      	movq	$0x0, 0x28(%rax)
    13dd:      	movq	$0x0, 0x20(%rax)
    13e5:      	movq	$0x0, 0x18(%rax)
    13ed:      	movq	$0x0, 0x10(%rax)
    13f5:      	movq	$0x0, 0x8(%rax)
    13fd:      	movq	$0x0, (%rax)
    1404:      	leaq	0xac(%rcx), %rdi
    140b:      	leaq	0x18(%rbp), %rdx
    140f:      	movl	$0x3f, %ecx
    1414:      	movl	$0x2d, %eax
    1419:      	movl	$0x3f, %esi
    141e:      	callq	*%rax
    1420:      	testq	%rax, %rax
    1423:      	js	0x269f <generic_retkprobe_event+0x269f>
    1429:      	movq	(%rsp), %r14
    142d:      	movq	%r14, %rdi
    1430:      	addq	$0xa4, %rdi
    1437:      	addq	$0x348, %rbp            # imm = 0x348
    143e:      	movl	$0x8, %ecx
    1443:      	movl	$0x4, %eax
    1448:      	movl	$0x8, %esi
    144d:      	movq	%rbp, %rdx
    1450:      	callq	*%rax
    1452:      	movq	%r14, %rcx
    1455:      	movl	$0x50, %r12d
    145b:      	jmp	0x1485 <generic_retkprobe_event+0x1485>
    145d:      	cmpl	$0x8, %r14d
    1461:      	je	0x1e97 <generic_retkprobe_event+0x1e97>
    1467:      	cmpl	$0x12, %r14d
    146b:      	jne	0x1485 <generic_retkprobe_event+0x1485>
    146d:      	xorl	%r12d, %r12d
    1470:      	movl	$0x4, %eax
    1475:      	movq	0x8(%rsp), %rdi
    147a:      	xorl	%esi, %esi
    147c:      	movq	%rbp, %rdx
    147f:      	callq	*%rax
    1481:      	movq	(%rsp), %rcx
    1485:      	testl	%r12d, %r12d
    1488:      	movl	$0x4, %ebp
    148d:      	js	0x149f <generic_retkprobe_event+0x149f>
    148f:      	andl	$0x7fffffff, %r12d      # imm = 0x7FFFFFFF
    1496:      	addq	$0x4, %r12
    149a:      	movq	%r12, %rbp
    149d:      	jmp	0x14b3 <generic_retkprobe_event+0x14b3>
    149f:      	movl	$0xffffffff, 0x5ea0(%rcx) # imm = 0xFFFFFFFF
    14a9:      	movl	$0xffffffff, 0x98(%rcx) # imm = 0xFFFFFFFF
    14b3:      	movq	0xb8(%rsp), %r12
    14bb:      	addq	$0x8, %rbp
    14bf:      	movl	0x60(%r13), %eax
    14c3:      	cmpl	$0xb, %eax
    14c6:      	jne	0x1ad <generic_retkprobe_event+0x1ad>
    14cc:      	jmp	0x2f7 <generic_retkprobe_event+0x2f7>
    14d1:      	cmpl	$0x13, %r14d
    14d5:      	je	0x2229 <generic_retkprobe_event+0x2229>
    14db:      	cmpl	$0x14, %r14d
    14df:      	jne	0x1485 <generic_retkprobe_event+0x1485>
    14e1:      	movq	$0x0, 0x30(%rsp)
    14ea:      	leaq	0x110(%rbp), %rdx
    14f1:      	leaq	0x30(%rsp), %rdi
    14f6:      	movl	$0x8, %ecx
    14fb:      	movl	$0x4, %eax
    1500:      	leaq	0xd8(%rbp), %r12
    1507:      	movl	$0x8, %esi
    150c:      	callq	*%rax
    150e:      	movq	0x30(%rsp), %rcx
    1513:      	movl	$0x80, %edx
    1518:      	movl	$0x2d, %eax
    151d:      	movq	0x8(%rsp), %rdi
    1522:      	movq	0x30(%rsp), %rdx
    1527:      	movl	$0x80, %esi
    152c:      	callq	*%rax
    152e:      	movq	(%rsp), %rax
    1532:      	leaq	0x12c(%rax), %rdi
    1539:      	movl	$0x4, %ecx
    153e:      	movl	$0x4, %eax
    1543:      	movl	$0x4, %esi
    1548:      	movq	%r12, %rdx
    154b:      	callq	*%rax
    154d:      	movq	(%rsp), %rax
    1551:      	leaq	0x11c(%rax), %rdi
    1558:      	leaq	0xe0(%rbp), %rdx
    155f:      	movl	$0x8, %ecx
    1564:      	movl	$0x4, %eax
    1569:      	movl	$0x8, %esi
    156e:      	callq	*%rax
    1570:      	movq	(%rsp), %rdi
    1574:      	addq	$0x124, %rdi            # imm = 0x124
    157b:      	addq	$0x118, %rbp            # imm = 0x118
    1582:      	movl	$0x8, %ecx
    1587:      	movl	$0x4, %eax
    158c:      	movl	$0x8, %esi
    1591:      	movq	%rbp, %rdx
    1594:      	callq	*%rax
    1596:      	movq	(%rsp), %rcx
    159a:      	movl	$0x98, %r12d
    15a0:      	jmp	0x1485 <generic_retkprobe_event+0x1485>
    15a5:      	cmpl	$0x26, %r14d
    15a9:      	movq	(%rsp), %rcx
    15ad:      	jne	0x1485 <generic_retkprobe_event+0x1485>
    15b3:      	movq	0x10(%rsp), %rsi
    15b8:      	movzwl	%si, %edx
    15bb:      	addq	0xb8(%rsp), %rdx
    15c3:      	shrl	$0x10, %esi
    15c6:      	andl	$0xfff, %esi            # imm = 0xFFF
    15cc:      	movq	%rcx, %rdi
    15cf:      	addq	$0xa0, %rdi
    15d6:      	incl	%esi
    15d8:      	movl	$0x2d, %eax
    15dd:      	jmp	0x198a <generic_retkprobe_event+0x198a>
    15e2:      	movq	$0x0, 0x38(%rsp)
    15eb:      	movq	$0x0, 0x30(%rsp)
    15f4:      	movl	$0xe, %eax
    15f9:      	callq	*%rax
    15fb:      	shrq	$0x20, %rax
    15ff:      	movq	%rax, 0x30(%rsp)
    1604:      	leaq	0x70(%rsp), %rdi
    1609:      	leaq	0x10(%rsp), %rdx
    160e:      	movl	$0x4, %ecx
    1613:      	movl	$0x4, %eax
    1618:      	movl	$0x4, %r14d
    161e:      	movl	$0x4, %esi
    1623:      	callq	*%rax
    1625:      	movl	0x70(%rsp), %eax
    1629:      	movl	%eax, 0x38(%rsp)
    162d:      	movq	(%rip), %rdi            # 0x1634 <generic_retkprobe_event+0x1634>
    1634:      	leaq	0x30(%rsp), %rsi
    1639:      	movl	$0x1, %eax
    163e:      	callq	*%rax
    1640:      	testq	%rax, %rax
    1643:      	je	0x23c6 <generic_retkprobe_event+0x23c6>
    1649:      	movl	(%rax), %r12d
    164c:      	leaq	0x70(%rsp), %rdx
    1651:      	movq	%rax, %r13
    1654:      	movl	$0x4, %eax
    1659:      	movq	%rbp, %rdi
    165c:      	movl	$0x4, %esi
    1661:      	callq	*%rax
    1663:      	andl	$0xfff, %r12d           # imm = 0xFFF
    166a:      	movq	(%rsp), %rdi
    166e:      	addq	$0xa0, %rdi
    1675:      	leaq	0x4(%r12), %rsi
    167a:      	movl	$0x4, %eax
    167f:      	movq	%r13, %rdx
    1682:      	callq	*%rax
    1684:      	leaq	(%r12,%rbp), %rdi
    1688:      	addq	$0x8, %rdi
    168c:      	leaq	(%r12,%r13), %rdx
    1690:      	addq	$0x4, %rdx
    1694:      	movl	$0x4, %eax
    1699:      	movl	$0x4, %esi
    169e:      	callq	*%rax
    16a0:      	addq	$0xc, %r12
    16a4:      	movq	0x20(%rsp), %r13
    16a9:      	jmp	0x1481 <generic_retkprobe_event+0x1481>
    16ae:      	movq	%rax, %r14
    16b1:      	movq	0x10(%rsp), %r12
    16b6:      	leaq	0x98(%rsp), %rdi
    16be:      	movl	$0x1, %ecx
    16c3:      	movl	$0x4, %eax
    16c8:      	movl	$0x1, %esi
    16cd:      	movq	%r12, %rdx
    16d0:      	callq	*%rax
    16d2:      	cmpb	$0x1, 0x98(%rsp)
    16da:      	jne	0x23b0 <generic_retkprobe_event+0x23b0>
    16e0:      	addq	$0x10, %r12
    16e4:      	leaq	0x30(%rsp), %rdi
    16e9:      	movl	$0x8, %ecx
    16ee:      	movl	$0x4, %eax
    16f3:      	movl	$0x8, %esi
    16f8:      	movq	%r12, %rdx
    16fb:      	callq	*%rax
    16fd:      	movq	0x30(%rsp), %rdx
    1702:      	leaq	0x70(%rsp), %rdi
    1707:      	movl	$0x8, %ecx
    170c:      	movl	$0x4, %eax
    1711:      	movl	$0x8, %esi
    1716:      	callq	*%rax
    1718:      	movq	0x30(%rsp), %rdx
    171d:      	addq	$0x8, %rdx
    1721:      	leaq	0xa0(%rsp), %rdi
    1729:      	movl	$0x8, %ecx
    172e:      	movl	$0x4, %eax
    1733:      	movl	$0x8, %esi
    1738:      	callq	*%rax
    173a:      	movq	0x70(%rsp), %rdx
    173f:      	movq	0xa0(%rsp), %r13
    1747:      	cmpq	$0xfff, %r13            # imm = 0xFFF
    174e:      	movl	$0xfff, %r12d           # imm = 0xFFF
    1754:      	cmovbq	%r13, %r12
    1758:      	movq	%r14, %rdi
    175b:      	addq	$0xa4, %rdi
    1762:      	movl	$0x4, %eax
    1767:      	movl	%r12d, %esi
    176a:      	callq	*%rax
    176c:      	testl	%eax, %eax
    176e:      	js	0x2560 <generic_retkprobe_event+0x2560>
    1774:      	movl	%r13d, 0x9c(%r14)
    177b:      	movl	%r12d, 0xa0(%r14)
    1782:      	addq	$0x8, %r12
    1786:      	movq	0x20(%rsp), %r13
    178b:      	jmp	0x1481 <generic_retkprobe_event+0x1481>
    1790:      	movq	0x10(%rsp), %r12
    1795:      	leaq	0xc4(%rcx), %rdi
    179c:      	leaq	0x98(%r12), %rdx
    17a4:      	movq	%rcx, %r14
    17a7:      	movl	$0x4, %ecx
    17ac:      	movl	$0x4, %eax
    17b1:      	movl	$0x4, %esi
    17b6:      	callq	*%rax
    17b8:      	leaq	0xc8(%r14), %rdi
    17bf:      	leaq	0x70(%r12), %rdx
    17c4:      	movl	$0x4, %ecx
    17c9:      	movl	$0x4, %eax
    17ce:      	movl	$0x4, %esi
    17d3:      	callq	*%rax
    17d5:      	leaq	0xcc(%r14), %rdi
    17dc:      	leaq	0x90(%r12), %rdx
    17e4:      	movl	$0x4, %ecx
    17e9:      	movl	$0x4, %eax
    17ee:      	movl	$0x4, %esi
    17f3:      	callq	*%rax
    17f5:      	leaq	0xd0(%r14), %rdi
    17fc:      	leaq	0xa8(%r12), %rdx
    1804:      	movl	$0x4, %ecx
    1809:      	movl	$0x4, %eax
    180e:      	movl	$0x4, %esi
    1813:      	callq	*%rax
    1815:      	movq	$0x0, 0x30(%rsp)
    181e:      	leaq	0xc8(%r12), %rdx
    1826:      	leaq	0x30(%rsp), %rdi
    182b:      	movl	$0x8, %ecx
    1830:      	movl	$0x4, %eax
    1835:      	movl	$0x8, %esi
    183a:      	callq	*%rax
    183c:      	movq	%r12, 0x8(%rsp)
    1841:      	leaq	0xb8(%r12), %rdx
    1849:      	leaq	0x98(%rsp), %rdi
    1851:      	movl	$0x2, %ecx
    1856:      	movl	$0x4, %eax
    185b:      	movl	$0x2, %esi
    1860:      	callq	*%rax
    1862:      	movzwl	0x98(%rsp), %r12d
    186b:      	addq	0x30(%rsp), %r12
    1870:      	leaq	0xb4(%rsp), %rdi
    1878:      	movl	$0x1, %ecx
    187d:      	movl	$0x4, %eax
    1882:      	movl	$0x1, %esi
    1887:      	movq	%r12, %rdx
    188a:      	callq	*%rax
    188c:      	movzbl	0xb4(%rsp), %eax
    1894:      	shrl	$0x4, %eax
    1897:      	cmpl	$0x6, %eax
    189a:      	je	0x23d7 <generic_retkprobe_event+0x23d7>
    18a0:      	cmpl	$0x4, %eax
    18a3:      	jne	0x30e3 <generic_retkprobe_event+0x30e3>
    18a9:      	leaq	0x9(%r12), %rdx
    18ae:      	leaq	0xc8(%rsp), %rdi
    18b6:      	movl	$0x1, %ecx
    18bb:      	movl	$0x4, %eax
    18c0:      	movl	$0x1, %esi
    18c5:      	callq	*%rax
    18c7:      	movzbl	0xc8(%rsp), %eax
    18cf:      	movq	(%rsp), %rsi
    18d3:      	movw	%ax, 0xc0(%rsi)
    18da:      	movw	$0x2, 0xc2(%rsi)
    18e3:      	leaq	0xc(%r12), %rdx
    18e8:      	movq	$0x0, (%rbp)
    18f0:      	movq	$0x0, 0x8(%rbp)
    18f8:      	movq	$0x0, 0x10(%rbp)
    1900:      	movq	$0x0, 0x18(%rbp)
    1908:      	movl	$0x4, %ecx
    190d:      	movl	$0x4, %eax
    1912:      	leaq	0xac(%rsi), %r14
    1919:      	movq	%rbp, %rdi
    191c:      	movl	$0x4, %esi
    1921:      	callq	*%rax
    1923:      	addq	$0x10, %r12
    1927:      	movl	$0x4, %ecx
    192c:      	movl	$0x4, %eax
    1931:      	movq	%r14, %rdi
    1934:      	movl	$0x4, %esi
    1939:      	movq	%r12, %rdx
    193c:      	callq	*%rax
    193e:      	movq	0x8(%rsp), %rax
    1943:      	leaq	0xb6(%rax), %rdx
    194a:      	leaq	0xd0(%rsp), %rdi
    1952:      	movl	$0x2, %ecx
    1957:      	movl	$0x4, %eax
    195c:      	movl	$0x2, %esi
    1961:      	jmp	0x2f53 <generic_retkprobe_event+0x2f53>
    1966:      	movl	$0x120, %edx            # imm = 0x120
    196b:      	addq	0x10(%rsp), %rdx
    1970:      	movq	(%rsp), %rdi
    1974:      	addq	$0xa0, %rdi
    197b:      	movl	$0x11, %ecx
    1980:      	movl	$0x2d, %eax
    1985:      	movl	$0x11, %esi
    198a:      	callq	*%rax
    198c:      	movq	%rax, %r12
    198f:      	testq	%rax, %rax
    1992:      	js	0x1481 <generic_retkprobe_event+0x1481>
    1998:      	leal	-0x1(%r12), %eax
    199d:      	movl	%eax, (%rbp)
    19a0:      	addq	$0x3, %r12
    19a4:      	jmp	0x1481 <generic_retkprobe_event+0x1481>
    19a9:      	movq	0x10(%rsp), %r12
    19ae:      	movq	$0x0, 0x10(%rbp)
    19b6:      	movq	$0x0, 0x8(%rbp)
    19be:      	movq	$0x0, (%rbp)
    19c6:      	movl	$0x2, %ecx
    19cb:      	movl	$0x4, %eax
    19d0:      	movq	%rbp, %rdi
    19d3:      	movl	$0x2, %esi
    19d8:      	movq	%r12, %rdx
    19db:      	callq	*%rax
    19dd:      	testq	%rax, %rax
    19e0:      	movq	(%rsp), %rcx
    19e4:      	js	0x25db <generic_retkprobe_event+0x25db>
    19ea:      	movzwl	(%rbp), %eax
    19ee:      	cmpl	$0xa, %eax
    19f1:      	je	0x257b <generic_retkprobe_event+0x257b>
    19f7:      	cmpl	$0x2, %eax
    19fa:      	jne	0x25bd <generic_retkprobe_event+0x25bd>
    1a00:      	leaq	0x4(%r12), %rdx
    1a05:      	leaq	0x30(%rsp), %rdi
    1a0a:      	movl	$0x4, %ecx
    1a0f:      	movl	$0x4, %eax
    1a14:      	movl	$0x4, %esi
    1a19:      	callq	*%rax
    1a1b:      	movl	0x30(%rsp), %eax
    1a1f:      	movq	(%rsp), %rdi
    1a23:      	movq	%rax, 0xa4(%rdi)
    1a2a:      	addq	$0x9e, %rdi
    1a31:      	addq	$0x2, %r12
    1a35:      	movl	$0x2, %ecx
    1a3a:      	movl	$0x4, %eax
    1a3f:      	jmp	0x25b3 <generic_retkprobe_event+0x25b3>
    1a44:      	xorl	%r14d, %r14d
    1a47:      	cmpq	$0x3, 0x88(%rsp)
    1a50:      	jb	0x1ddd <generic_retkprobe_event+0x1ddd>
    1a56:      	movq	0x90(%rsp), %rax
    1a5e:      	leaq	0x20(%rax), %rdx
    1a62:      	leaq	0x30(%rsp), %rdi
    1a67:      	movl	$0x4, %r12d
    1a6d:      	movl	$0x10, %ecx
    1a72:      	movl	$0x4, %eax
    1a77:      	movl	$0x10, %esi
    1a7c:      	callq	*%rax
    1a7e:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1a83:      	testl	%eax, %eax
    1a85:      	js	0x1b14 <generic_retkprobe_event+0x1b14>
    1a8b:      	movq	0x38(%rsp), %rax
    1a90:      	cmpq	%r14, %rax
    1a93:      	movq	%r14, %rcx
    1a96:      	cmovbq	%rax, %rcx
    1a9a:      	movq	%r14, 0x8(%rsp)
    1a9f:      	testq	%r14, %r14
    1aa2:      	movq	%rax, %r14
    1aa5:      	movq	%rcx, %r13
    1aa8:      	cmovneq	%rcx, %r14
    1aac:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    1ab1:      	cmpq	$0xffe, %r14            # imm = 0xFFE
    1ab8:      	ja	0x1b14 <generic_retkprobe_event+0x1b14>
    1aba:      	movq	(%rsp), %rdi
    1abe:      	addq	0x18(%rsp), %rdi
    1ac3:      	movq	%rdi, (%rsp)
    1ac7:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    1acd:      	addq	%r15, %rdi
    1ad0:      	movq	0x30(%rsp), %rcx
    1ad5:      	movl	$0x4, %eax
    1ada:      	movq	0x30(%rsp), %rdx
    1adf:      	movl	%r14d, %esi
    1ae2:      	callq	*%rax
    1ae4:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1ae9:      	testl	%eax, %eax
    1aeb:      	js	0x1b14 <generic_retkprobe_event+0x1b14>
    1aed:      	movq	%r15, 0x18(%rsp)
    1af2:      	movq	%r14, %r15
    1af5:      	addq	%r14, %rbp
    1af8:      	cmpq	$0x0, 0x8(%rsp)
    1afe:      	je	0x2804 <generic_retkprobe_event+0x2804>
    1b04:      	subq	%r13, 0x8(%rsp)
    1b09:      	jne	0x280b <generic_retkprobe_event+0x280b>
    1b0f:      	jmp	0x2816 <generic_retkprobe_event+0x2816>
    1b14:      	movq	0x28(%rsp), %r14
    1b19:      	movl	%ecx, (%r15,%r14)
    1b1d:      	addq	%r14, %r12
    1b20:      	movq	%r12, %rbp
    1b23:      	movq	0xb8(%rsp), %r12
    1b2b:      	movq	0x20(%rsp), %r13
    1b30:      	movl	$0x23, %eax
    1b35:      	callq	*%rax
    1b37:      	movq	%rax, %rcx
    1b3a:      	movq	%rax, 0x30(%rsp)
    1b3f:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    1b46:      	leaq	0xa0(%rsp), %rdi
    1b4e:      	movl	$0x4, %edx
    1b53:      	movl	$0x71, %eax
    1b58:      	movl	$0xaf4, %edx            # imm = 0xAF4
    1b5d:      	addq	0x30(%rsp), %rdx
    1b62:      	movl	$0x4, %esi
    1b67:      	callq	*%rax
    1b69:      	movl	0xa0(%rsp), %eax
    1b70:      	movl	%eax, 0x70(%rsp)
    1b74:      	movq	(%rip), %rdi            # 0x1b7b <generic_retkprobe_event+0x1b7b>
    1b7b:      	leaq	0x70(%rsp), %rsi
    1b80:      	movl	$0x1, %eax
    1b85:      	callq	*%rax
    1b87:      	testq	%rax, %rax
    1b8a:      	je	0x1b9a <generic_retkprobe_event+0x1b9a>
    1b8c:      	movq	%rax, %r15
    1b8f:      	cmpq	$0x0, 0x8(%rax)
    1b94:      	jne	0x1d70 <generic_retkprobe_event+0x1d70>
    1b9a:      	movl	$0xb00, %edx            # imm = 0xB00
    1b9f:      	movq	0x30(%rsp), %rcx
    1ba4:      	addq	%rdx, %rcx
    1ba7:      	leaq	0x30(%rsp), %rdi
    1bac:      	movl	$0x8, %esi
    1bb1:      	movl	$0x71, %eax
    1bb6:      	addq	0x30(%rsp), %rdx
    1bbb:      	movl	$0x8, %esi
    1bc0:      	callq	*%rax
    1bc2:      	movq	0x30(%rsp), %rcx
    1bc7:      	testq	%rcx, %rcx
    1bca:      	je	0x1d6d <generic_retkprobe_event+0x1d6d>
    1bd0:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    1bd7:      	leaq	0xa0(%rsp), %rdi
    1bdf:      	movl	$0x4, %edx
    1be4:      	movl	$0x71, %eax
    1be9:      	movl	$0xaf4, %edx            # imm = 0xAF4
    1bee:      	addq	0x30(%rsp), %rdx
    1bf3:      	movl	$0x4, %esi
    1bf8:      	callq	*%rax
    1bfa:      	movl	0xa0(%rsp), %eax
    1c01:      	movl	%eax, 0x70(%rsp)
    1c05:      	movq	(%rip), %rdi            # 0x1c0c <generic_retkprobe_event+0x1c0c>
    1c0c:      	leaq	0x70(%rsp), %rsi
    1c11:      	movl	$0x1, %eax
    1c16:      	callq	*%rax
    1c18:      	testq	%rax, %rax
    1c1b:      	je	0x1c2b <generic_retkprobe_event+0x1c2b>
    1c1d:      	movq	%rax, %r15
    1c20:      	cmpq	$0x0, 0x8(%rax)
    1c25:      	jne	0x1d70 <generic_retkprobe_event+0x1d70>
    1c2b:      	movl	$0xb00, %edx            # imm = 0xB00
    1c30:      	movq	0x30(%rsp), %rcx
    1c35:      	addq	%rdx, %rcx
    1c38:      	leaq	0x30(%rsp), %rdi
    1c3d:      	movl	$0x8, %esi
    1c42:      	movl	$0x71, %eax
    1c47:      	addq	0x30(%rsp), %rdx
    1c4c:      	movl	$0x8, %esi
    1c51:      	callq	*%rax
    1c53:      	movq	0x30(%rsp), %rcx
    1c58:      	testq	%rcx, %rcx
    1c5b:      	je	0x1d6d <generic_retkprobe_event+0x1d6d>
    1c61:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    1c68:      	leaq	0xa0(%rsp), %rdi
    1c70:      	movl	$0x4, %edx
    1c75:      	movl	$0x71, %eax
    1c7a:      	movl	$0xaf4, %edx            # imm = 0xAF4
    1c7f:      	addq	0x30(%rsp), %rdx
    1c84:      	movl	$0x4, %esi
    1c89:      	callq	*%rax
    1c8b:      	movl	0xa0(%rsp), %eax
    1c92:      	movl	%eax, 0x70(%rsp)
    1c96:      	movq	(%rip), %rdi            # 0x1c9d <generic_retkprobe_event+0x1c9d>
    1c9d:      	leaq	0x70(%rsp), %rsi
    1ca2:      	movl	$0x1, %eax
    1ca7:      	callq	*%rax
    1ca9:      	testq	%rax, %rax
    1cac:      	je	0x1cbc <generic_retkprobe_event+0x1cbc>
    1cae:      	movq	%rax, %r15
    1cb1:      	cmpq	$0x0, 0x8(%rax)
    1cb6:      	jne	0x1d70 <generic_retkprobe_event+0x1d70>
    1cbc:      	movl	$0xb00, %edx            # imm = 0xB00
    1cc1:      	movq	0x30(%rsp), %rcx
    1cc6:      	addq	%rdx, %rcx
    1cc9:      	leaq	0x30(%rsp), %rdi
    1cce:      	movl	$0x8, %esi
    1cd3:      	movl	$0x71, %eax
    1cd8:      	addq	0x30(%rsp), %rdx
    1cdd:      	movl	$0x8, %esi
    1ce2:      	callq	*%rax
    1ce4:      	movq	0x30(%rsp), %rcx
    1ce9:      	testq	%rcx, %rcx
    1cec:      	je	0x1d6d <generic_retkprobe_event+0x1d6d>
    1cee:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    1cf5:      	leaq	0xa0(%rsp), %rdi
    1cfd:      	movl	$0x4, %edx
    1d02:      	movl	$0x71, %eax
    1d07:      	movl	$0xaf4, %edx            # imm = 0xAF4
    1d0c:      	addq	0x30(%rsp), %rdx
    1d11:      	movl	$0x4, %esi
    1d16:      	callq	*%rax
    1d18:      	movl	0xa0(%rsp), %eax
    1d1f:      	movl	%eax, 0x70(%rsp)
    1d23:      	movq	(%rip), %rdi            # 0x1d2a <generic_retkprobe_event+0x1d2a>
    1d2a:      	leaq	0x70(%rsp), %rsi
    1d2f:      	movl	$0x1, %eax
    1d34:      	callq	*%rax
    1d36:      	testq	%rax, %rax
    1d39:      	je	0x1d45 <generic_retkprobe_event+0x1d45>
    1d3b:      	movq	%rax, %r15
    1d3e:      	cmpq	$0x0, 0x8(%rax)
    1d43:      	jne	0x1d70 <generic_retkprobe_event+0x1d70>
    1d45:      	movl	$0xb00, %edx            # imm = 0xB00
    1d4a:      	movq	0x30(%rsp), %rcx
    1d4f:      	addq	%rdx, %rcx
    1d52:      	leaq	0x30(%rsp), %rdi
    1d57:      	movl	$0x8, %esi
    1d5c:      	movl	$0x71, %eax
    1d61:      	addq	0x30(%rsp), %rdx
    1d66:      	movl	$0x8, %esi
    1d6b:      	callq	*%rax
    1d6d:      	xorl	%r15d, %r15d
    1d70:      	movl	$0x10d, (%rbx)          # imm = 0x10D
    1d76:      	movl	%ebp, 0x4(%rbx)
    1d79:      	movl	$0x7d, %eax
    1d7e:      	callq	*%rax
    1d80:      	movq	%rax, 0x8(%rbx)
    1d84:      	testq	%r15, %r15
    1d87:      	je	0x1d97 <generic_retkprobe_event+0x1d97>
    1d89:      	movl	(%r15), %eax
    1d8c:      	movl	%eax, 0x10(%rbx)
    1d8f:      	movq	0x8(%r15), %rax
    1d93:      	movq	%rax, 0x18(%rbx)
    1d97:      	movl	$0x0, 0x14(%rbx)
    1d9e:      	movl	(%r13), %eax
    1da2:      	movq	%rax, 0x60(%rbx)
    1da6:      	movl	%ebp, 0x4(%rbx)
    1da9:      	movq	(%rip), %rsi            # 0x1db0 <generic_retkprobe_event+0x1db0>
    1db0:      	movl	$0x3, %ecx
    1db5:      	movl	$0xc, %eax
    1dba:      	movq	%r12, %rdi
    1dbd:      	movl	$0x3, %edx
    1dc2:      	callq	*%rax
    1dc4:      	movl	$0x1, %ebp
    1dc9:      	movl	%ebp, %eax
    1dcb:      	addq	$0xf8, %rsp
    1dd2:      	popq	%rbx
    1dd3:      	popq	%r12
    1dd5:      	popq	%r13
    1dd7:      	popq	%r14
    1dd9:      	popq	%r15
    1ddb:      	popq	%rbp
    1ddc:      	retq
    1ddd:      	movq	%rbp, %r13
    1de0:      	movq	0x28(%rsp), %r14
    1de5:      	jmp	0x422 <generic_retkprobe_event+0x422>
    1dea:      	movq	$0x0, 0x70(%rsp)
    1df3:      	movq	$0x0, 0x30(%rsp)
    1dfc:      	movq	%rax, %r14
    1dff:      	leaq	0x70(%rsp), %rdi
    1e04:      	leaq	0x30(%rsp), %rdx
    1e09:      	movl	$0x8, %ecx
    1e0e:      	movl	$0x4, %eax
    1e13:      	movl	$0x4, %r12d
    1e19:      	movl	$0x8, %esi
    1e1e:      	callq	*%rax
    1e20:      	movq	0x70(%rsp), %rax
    1e25:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    1e2b:      	movl	$0xfff, %r13d           # imm = 0xFFF
    1e31:      	movq	%rax, 0x18(%rsp)
    1e36:      	cmovbq	%rax, %r13
    1e3a:      	movq	%r14, 0x80(%rsp)
    1e42:      	addq	$0xa4, %r14
    1e49:      	movl	$0x4, %eax
    1e4e:      	movq	%r14, %rdi
    1e51:      	movl	%r13d, %esi
    1e54:      	movq	%rbp, %rdx
    1e57:      	callq	*%rax
    1e59:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1e5e:      	testl	%eax, %eax
    1e60:      	js	0x1e7f <generic_retkprobe_event+0x1e7f>
    1e62:      	movq	0x80(%rsp), %rax
    1e6a:      	movl	%r13d, 0xa0(%rax)
    1e71:      	addq	$0x8, %r13
    1e75:      	movq	0x18(%rsp), %rax
    1e7a:      	movl	%eax, %ecx
    1e7c:      	movq	%r13, %r12
    1e7f:      	movq	0x80(%rsp), %rax
    1e87:      	movl	%ecx, 0x9c(%rax)
    1e8d:      	movq	0x20(%rsp), %r13
    1e92:      	jmp	0x1481 <generic_retkprobe_event+0x1481>
    1e97:      	leaq	0xc4(%rcx), %r13
    1e9e:      	leaq	0xdc(%rcx), %r12
    1ea5:      	leaq	0x8(%rbp), %rdx
    1ea9:      	movl	$0x4, %ecx
    1eae:      	movl	$0x4, %eax
    1eb3:      	movq	0x8(%rsp), %rdi
    1eb8:      	movl	$0x4, %esi
    1ebd:      	callq	*%rax
    1ebf:      	movq	(%rsp), %rax
    1ec3:      	leaq	0xa0(%rax), %rdi
    1eca:      	leaq	0xc(%rbp), %rdx
    1ece:      	movl	$0x4, %ecx
    1ed3:      	movl	$0x4, %eax
    1ed8:      	movl	$0x4, %esi
    1edd:      	callq	*%rax
    1edf:      	movq	(%rsp), %rax
    1ee3:      	leaq	0xac(%rax), %rdi
    1eea:      	leaq	0x18(%rbp), %rdx
    1eee:      	movl	$0x4, %ecx
    1ef3:      	movl	$0x4, %eax
    1ef8:      	movl	$0x4, %esi
    1efd:      	callq	*%rax
    1eff:      	movq	(%rsp), %rax
    1f03:      	leaq	0xb0(%rax), %rdi
    1f0a:      	leaq	0x1c(%rbp), %rdx
    1f0e:      	movl	$0x4, %ecx
    1f13:      	movl	$0x4, %eax
    1f18:      	movl	$0x4, %esi
    1f1d:      	callq	*%rax
    1f1f:      	movq	(%rsp), %rax
    1f23:      	leaq	0xa4(%rax), %rdi
    1f2a:      	leaq	0x10(%rbp), %rdx
    1f2e:      	movl	$0x4, %ecx
    1f33:      	movl	$0x4, %eax
    1f38:      	movl	$0x4, %esi
    1f3d:      	callq	*%rax
    1f3f:      	movq	(%rsp), %rax
    1f43:      	leaq	0xa8(%rax), %rdi
    1f4a:      	leaq	0x14(%rbp), %rdx
    1f4e:      	movl	$0x4, %ecx
    1f53:      	movl	$0x4, %eax
    1f58:      	movl	$0x4, %esi
    1f5d:      	callq	*%rax
    1f5f:      	movq	(%rsp), %rax
    1f63:      	leaq	0xb4(%rax), %rdi
    1f6a:      	leaq	0x20(%rbp), %rdx
    1f6e:      	movl	$0x4, %ecx
    1f73:      	movl	$0x4, %eax
    1f78:      	movl	$0x4, %esi
    1f7d:      	callq	*%rax
    1f7f:      	movq	(%rsp), %rax
    1f83:      	leaq	0xb8(%rax), %rdi
    1f8a:      	leaq	0x24(%rbp), %rdx
    1f8e:      	movl	$0x4, %ecx
    1f93:      	movl	$0x4, %eax
    1f98:      	movl	$0x4, %esi
    1f9d:      	callq	*%rax
    1f9f:      	movq	(%rsp), %rax
    1fa3:      	movl	$0x0, 0xc0(%rax)
    1fad:      	movq	(%rsp), %rax
    1fb1:      	leaq	0xbc(%rax), %rdi
    1fb8:      	leaq	0x28(%rbp), %rdx
    1fbc:      	movl	$0x4, %ecx
    1fc1:      	movl	$0x4, %eax
    1fc6:      	movl	$0x4, %esi
    1fcb:      	callq	*%rax
    1fcd:      	movq	(%rsp), %rax
    1fd1:      	leaq	0xcc(%rax), %rdi
    1fd8:      	leaq	0x40(%rbp), %rdx
    1fdc:      	movl	$0x8, %ecx
    1fe1:      	movl	$0x4, %eax
    1fe6:      	movl	$0x8, %esi
    1feb:      	callq	*%rax
    1fed:      	movq	(%rsp), %rax
    1ff1:      	leaq	0xd4(%rax), %rdi
    1ff8:      	leaq	0x30(%rbp), %rdx
    1ffc:      	movl	$0x8, %ecx
    2001:      	movl	$0x4, %eax
    2006:      	movl	$0x8, %esi
    200b:      	callq	*%rax
    200d:      	leaq	0x38(%rbp), %rdx
    2011:      	movl	$0x8, %ecx
    2016:      	movl	$0x4, %eax
    201b:      	movq	%r13, %rdi
    201e:      	movl	$0x8, %esi
    2023:      	callq	*%rax
    2025:      	addq	$0x90, %rbp
    202c:      	leaq	0x30(%rsp), %rdi
    2031:      	movl	$0x8, %ecx
    2036:      	movl	$0x4, %eax
    203b:      	movl	$0x8, %esi
    2040:      	movq	%rbp, %rdx
    2043:      	callq	*%rax
    2045:      	movq	0x30(%rsp), %r13
    204a:      	leaq	0xc8(%r13), %rdx
    2051:      	movl	$0x4, %ecx
    2056:      	movl	$0x4, %eax
    205b:      	movq	%r12, %rdi
    205e:      	movl	$0x4, %esi
    2063:      	callq	*%rax
    2065:      	movq	(%rsp), %rax
    2069:      	leaq	0xe0(%rax), %rdi
    2070:      	leaq	0xcc(%r13), %rdx
    2077:      	movl	$0x4, %ecx
    207c:      	movl	$0x4, %eax
    2081:      	movl	$0x4, %esi
    2086:      	callq	*%rax
    2088:      	movq	(%rsp), %rax
    208c:      	leaq	0xe4(%rax), %rdi
    2093:      	leaq	0xd0(%r13), %rdx
    209a:      	movl	$0x4, %ecx
    209f:      	movl	$0x4, %eax
    20a4:      	movl	$0x4, %esi
    20a9:      	callq	*%rax
    20ab:      	movq	(%rsp), %rdi
    20af:      	addq	$0xe8, %rdi
    20b6:      	addq	$0x158, %r13            # imm = 0x158
    20bd:      	movl	$0x4, %ecx
    20c2:      	movl	$0x4, %eax
    20c7:      	movl	$0x4, %esi
    20cc:      	movq	%r13, %rdx
    20cf:      	movq	0x20(%rsp), %r13
    20d4:      	callq	*%rax
    20d6:      	movq	(%rsp), %rcx
    20da:      	movl	$0x50, %r12d
    20e0:      	jmp	0x1485 <generic_retkprobe_event+0x1485>
    20e5:      	leaq	0xc8(%rbp), %rdx
    20ec:      	movl	$0x4, %ecx
    20f1:      	movl	$0x4, %eax
    20f6:      	movq	0x8(%rsp), %rdi
    20fb:      	movl	$0x4, %esi
    2100:      	callq	*%rax
    2102:      	movq	(%rsp), %rax
    2106:      	leaq	0xa0(%rax), %rdi
    210d:      	leaq	0xcc(%rbp), %rdx
    2114:      	movl	$0x4, %ecx
    2119:      	movl	$0x4, %eax
    211e:      	movl	$0x4, %esi
    2123:      	callq	*%rax
    2125:      	movq	(%rsp), %rax
    2129:      	leaq	0xa4(%rax), %rdi
    2130:      	leaq	0xd0(%rbp), %rdx
    2137:      	movl	$0x4, %ecx
    213c:      	movl	$0x4, %eax
    2141:      	movl	$0x4, %esi
    2146:      	callq	*%rax
    2148:      	movq	(%rsp), %rdi
    214c:      	addq	$0xa8, %rdi
    2153:      	addq	$0x158, %rbp            # imm = 0x158
    215a:      	movl	$0x4, %ecx
    215f:      	movl	$0x4, %eax
    2164:      	movl	$0x4, %esi
    2169:      	movq	%rbp, %rdx
    216c:      	callq	*%rax
    216e:      	movq	(%rsp), %rcx
    2172:      	movl	$0x10, %r12d
    2178:      	jmp	0x1485 <generic_retkprobe_event+0x1485>
    217d:      	leaq	0x38(%rbp), %rdx
    2181:      	movl	$0x4, %ecx
    2186:      	movl	$0x4, %eax
    218b:      	movq	0x8(%rsp), %rdi
    2190:      	movl	$0x4, %esi
    2195:      	callq	*%rax
    2197:      	movq	(%rsp), %rax
    219b:      	leaq	0xa0(%rax), %rdi
    21a2:      	leaq	0x3c(%rbp), %rdx
    21a6:      	movl	$0x4, %ecx
    21ab:      	movl	$0x4, %eax
    21b0:      	movl	$0x4, %esi
    21b5:      	callq	*%rax
    21b7:      	movq	(%rsp), %rax
    21bb:      	leaq	0xa4(%rax), %rdi
    21c2:      	leaq	0x40(%rbp), %rdx
    21c6:      	movl	$0x4, %ecx
    21cb:      	movl	$0x4, %eax
    21d0:      	movl	$0x4, %esi
    21d5:      	callq	*%rax
    21d7:      	movq	(%rsp), %rax
    21db:      	leaq	0xa8(%rax), %rdi
    21e2:      	leaq	0x44(%rbp), %rdx
    21e6:      	movl	$0x4, %ecx
    21eb:      	movl	$0x4, %eax
    21f0:      	movl	$0x4, %esi
    21f5:      	callq	*%rax
    21f7:      	movq	(%rsp), %rdi
    21fb:      	addq	$0xac, %rdi
    2202:      	subq	$-0x80, %rbp
    2206:      	movl	$0x10, %ecx
    220b:      	movl	$0x4, %eax
    2210:      	movl	$0x10, %esi
    2215:      	movq	%rbp, %rdx
    2218:      	callq	*%rax
    221a:      	movq	(%rsp), %rcx
    221e:      	movl	$0x20, %r12d
    2224:      	jmp	0x1485 <generic_retkprobe_event+0x1485>
    2229:      	movl	$0x4, %ecx
    222e:      	movl	$0x4, %eax
    2233:      	movq	0x8(%rsp), %rdi
    2238:      	movl	$0x4, %esi
    223d:      	movq	%rbp, %rdx
    2240:      	callq	*%rax
    2242:      	movq	(%rsp), %rax
    2246:      	leaq	0xa0(%rax), %rdi
    224d:      	leaq	0x4(%rbp), %rdx
    2251:      	movl	$0x4, %ecx
    2256:      	movl	$0x4, %eax
    225b:      	movl	$0x4, %esi
    2260:      	callq	*%rax
    2262:      	movq	(%rsp), %rdi
    2266:      	addq	$0xa4, %rdi
    226d:      	addq	$0x30, %rbp
    2271:      	movl	$0x10, %ecx
    2276:      	movl	$0x4, %eax
    227b:      	movl	$0x10, %esi
    2280:      	movq	%rbp, %rdx
    2283:      	jmp	0x2321 <generic_retkprobe_event+0x2321>
    2288:      	leaq	0x4(%rbp), %rdx
    228c:      	leaq	0x30(%rsp), %rdi
    2291:      	movl	$0x4, %ecx
    2296:      	movl	$0x4, %eax
    229b:      	movl	$0x4, %esi
    22a0:      	callq	*%rax
    22a2:      	movl	0x30(%rsp), %eax
    22a6:      	movq	(%rsp), %rcx
    22aa:      	movl	%eax, 0x9c(%rcx)
    22b0:      	leaq	0xc(%rbp), %rdx
    22b4:      	leaq	0x30(%rsp), %rdi
    22b9:      	movl	$0x4, %ecx
    22be:      	movl	$0x4, %eax
    22c3:      	movl	$0x4, %esi
    22c8:      	callq	*%rax
    22ca:      	movl	0x30(%rsp), %eax
    22ce:      	movq	(%rsp), %rcx
    22d2:      	movl	%eax, 0xa0(%rcx)
    22d8:      	addq	$0x50, %rbp
    22dc:      	leaq	0x30(%rsp), %rdi
    22e1:      	movl	$0x8, %ecx
    22e6:      	movl	$0x2d, %eax
    22eb:      	movl	$0x8, %esi
    22f0:      	movq	%rbp, %rdx
    22f3:      	callq	*%rax
    22f5:      	movq	(%rsp), %rdi
    22f9:      	addq	$0xa4, %rdi
    2300:      	movl	$0x3f8, %edx            # imm = 0x3F8
    2305:      	movq	0x30(%rsp), %rcx
    230a:      	addq	%rdx, %rcx
    230d:      	movl	$0x10, %esi
    2312:      	movl	$0x2d, %eax
    2317:      	addq	0x30(%rsp), %rdx
    231c:      	movl	$0x10, %esi
    2321:      	callq	*%rax
    2323:      	movq	(%rsp), %rcx
    2327:      	movl	$0x18, %r12d
    232d:      	jmp	0x1485 <generic_retkprobe_event+0x1485>
    2332:      	movq	0x8(%rsp), %rax
    2337:      	movq	$0x0, 0x48(%rax)
    233f:      	movq	$0x0, 0x40(%rax)
    2347:      	movq	$0x0, 0x38(%rax)
    234f:      	movq	$0x0, 0x30(%rax)
    2357:      	movq	$0x0, 0x28(%rax)
    235f:      	movq	$0x0, 0x20(%rax)
    2367:      	movq	$0x0, 0x18(%rax)
    236f:      	movq	$0x0, 0x10(%rax)
    2377:      	movq	$0x0, 0x8(%rax)
    237f:      	movq	$0x0, (%rax)
    2386:      	leaq	0x30(%rsp), %rdi
    238b:      	movl	$0x8, %ecx
    2390:      	movl	$0x4, %eax
    2395:      	movl	$0x8, %esi
    239a:      	movq	%rbp, %rdx
    239d:      	callq	*%rax
    239f:      	testq	%rax, %rax
    23a2:      	je	0x25e6 <generic_retkprobe_event+0x25e6>
    23a8:      	xorl	%r12d, %r12d
    23ab:      	jmp	0x27b7 <generic_retkprobe_event+0x27b7>
    23b0:      	movq	$0x0, 0x9c(%r14)
    23bb:      	movl	$0x8, %r12d
    23c1:      	jmp	0x1481 <generic_retkprobe_event+0x1481>
    23c6:      	movq	$-0x1, %r12
    23cd:      	movq	0x20(%rsp), %r13
    23d2:      	jmp	0x1481 <generic_retkprobe_event+0x1481>
    23d7:      	movq	0x30(%rsp), %r14
    23dc:      	movl	$0x0, 0x70(%rsp)
    23e4:      	movzwl	0x98(%rsp), %r12d
    23ed:      	movq	(%rip), %rdi            # 0x23f4 <generic_retkprobe_event+0x23f4>
    23f4:      	leaq	0x70(%rsp), %rsi
    23f9:      	movl	$0x1, %eax
    23fe:      	leaq	(%r14,%r12), %rcx
    2402:      	movq	%rcx, 0x80(%rsp)
    240a:      	callq	*%rax
    240c:      	testq	%rax, %rax
    240f:      	je	0x2ef3 <generic_retkprobe_event+0x2ef3>
    2415:      	movq	%rax, %r13
    2418:      	movw	%r12w, (%rax)
    241c:      	movb	$-0x1, 0x5(%rax)
    2420:      	movb	$0x0, 0x7(%rax)
    2424:      	movq	%rax, %rdi
    2427:      	addq	$0x6, %rdi
    242b:      	movq	0x80(%rsp), %rax
    2433:      	leaq	0x6(%rax), %rdx
    2437:      	movl	$0x1, %ecx
    243c:      	movl	$0x4, %eax
    2441:      	movq	%rdi, %r12
    2444:      	movl	$0x1, %esi
    2449:      	callq	*%rax
    244b:      	testq	%rax, %rax
    244e:      	js	0x2ef3 <generic_retkprobe_event+0x2ef3>
    2454:      	movzbl	0x5(%r13), %eax
    2459:      	cmpl	$0x32, %eax
    245c:      	jg	0x27ca <generic_retkprobe_event+0x27ca>
    2462:      	testl	%eax, %eax
    2464:      	je	0x27f3 <generic_retkprobe_event+0x27f3>
    246a:      	cmpl	$0x2b, %eax
    246d:      	je	0x27f3 <generic_retkprobe_event+0x27f3>
    2473:      	cmpl	$0x2c, %eax
    2476:      	jne	0x29a5 <generic_retkprobe_event+0x29a5>
    247c:      	movw	$0x8, 0x2(%r13)
    2483:      	movw	$0x8, %ax
    2487:      	jmp	0x28f3 <generic_retkprobe_event+0x28f3>
    248c:      	leaq	0x48(%r12), %rdx
    2491:      	movl	$0x10, %ecx
    2496:      	movl	$0x4, %eax
    249b:      	movq	%rbp, %rdi
    249e:      	movl	$0x10, %esi
    24a3:      	callq	*%rax
    24a5:      	leaq	0x38(%r12), %rdx
    24aa:      	movl	$0x10, %ecx
    24af:      	movl	$0x4, %eax
    24b4:      	movq	%r13, %rdi
    24b7:      	movl	$0x10, %esi
    24bc:      	callq	*%rax
    24be:      	movq	(%rsp), %r13
    24c2:      	leaq	0xbc(%r13), %rdi
    24c9:      	leaq	0xc(%r12), %r14
    24ce:      	addq	$0xe, %r12
    24d2:      	movl	$0x2, %ecx
    24d7:      	movl	$0x4, %eax
    24dc:      	movl	$0x2, %esi
    24e1:      	movq	%r12, %rdx
    24e4:      	callq	*%rax
    24e6:      	movq	%r13, %rdi
    24e9:      	addq	$0xbe, %rdi
    24f0:      	movl	$0x2, %ecx
    24f5:      	movl	$0x4, %eax
    24fa:      	movl	$0x2, %esi
    24ff:      	movq	%r14, %rdx
    2502:      	callq	*%rax
    2504:      	movzwl	0xbe(%r13), %eax
    250c:      	movbew	%ax, 0xbe(%r13)
    2516:      	movq	0x10(%rsp), %rax
    251b:      	movq	%rax, 0x30(%rsp)
    2520:      	movq	(%rip), %rdi            # 0x2527 <generic_retkprobe_event+0x2527>
    2527:      	leaq	0x30(%rsp), %rsi
    252c:      	movl	$0x1, %eax
    2531:      	callq	*%rax
    2533:      	testq	%rax, %rax
    2536:      	je	0x2550 <generic_retkprobe_event+0x2550>
    2538:      	movl	(%rax), %ecx
    253a:      	movq	0x18(%rsp), %rbp
    253f:      	movl	%ecx, 0x10(%rbp)
    2542:      	movq	0x8(%rax), %rcx
    2546:      	movq	%rcx, 0x18(%rbp)
    254a:      	movl	0x4(%rax), %eax
    254d:      	movl	%eax, 0x7c(%rbp)
    2550:      	movl	$0x40, %r12d
    2556:      	movq	0x20(%rsp), %r13
    255b:      	jmp	0x1481 <generic_retkprobe_event+0x1481>
    2560:      	movl	$0xfffffffe, 0x9c(%r14) # imm = 0xFFFFFFFE
    256b:      	movl	$0x4, %r12d
    2571:      	movq	0x20(%rsp), %r13
    2576:      	jmp	0x1481 <generic_retkprobe_event+0x1481>
    257b:      	leaq	0xa4(%rcx), %rdi
    2582:      	leaq	0x8(%r12), %rdx
    2587:      	movq	%rcx, %r14
    258a:      	movl	$0x10, %ecx
    258f:      	movl	$0x4, %eax
    2594:      	movl	$0x10, %esi
    2599:      	callq	*%rax
    259b:      	movq	%r14, %rdi
    259e:      	addq	$0x9e, %rdi
    25a5:      	addq	$0x2, %r12
    25a9:      	movl	$0x2, %ecx
    25ae:      	movl	$0x4, %eax
    25b3:      	movl	$0x2, %esi
    25b8:      	movq	%r12, %rdx
    25bb:      	callq	*%rax
    25bd:      	movq	(%rsp), %rcx
    25c1:      	movzwl	0x9e(%rcx), %eax
    25c8:      	movbew	%ax, 0x9e(%rcx)
    25d1:      	movq	0x20(%rsp), %r13
    25d6:      	movq	0x18(%rsp), %r15
    25db:      	movl	$0x18, %r12d
    25e1:      	jmp	0x1485 <generic_retkprobe_event+0x1485>
    25e6:      	movq	(%rsp), %rax
    25ea:      	leaq	0xac(%rax), %rdi
    25f1:      	movq	0x30(%rsp), %rcx
    25f6:      	movl	$0x3f, %edx
    25fb:      	movl	$0x2d, %eax
    2600:      	movq	0x30(%rsp), %rdx
    2605:      	movl	$0x3f, %esi
    260a:      	callq	*%rax
    260c:      	testq	%rax, %rax
    260f:      	js	0x23a8 <generic_retkprobe_event+0x23a8>
    2615:      	leaq	0x8(%rbp), %rdx
    2619:      	leaq	0x70(%rsp), %rdi
    261e:      	movl	$0x8, %ecx
    2623:      	movl	$0x4, %eax
    2628:      	movl	$0x8, %esi
    262d:      	callq	*%rax
    262f:      	movq	(%rsp), %rdi
    2633:      	addq	$0xa4, %rdi
    263a:      	movl	$0x348, %edx            # imm = 0x348
    263f:      	movq	0x70(%rsp), %rcx
    2644:      	addq	%rdx, %rcx
    2647:      	movl	$0x8, %esi
    264c:      	movl	$0x4, %eax
    2651:      	addq	0x70(%rsp), %rdx
    2656:      	movl	$0x8, %esi
    265b:      	callq	*%rax
    265d:      	addq	$0x58, %rbp
    2661:      	leaq	0x70(%rsp), %rdi
    2666:      	movl	$0x4, %ecx
    266b:      	movl	$0x4, %eax
    2670:      	movl	$0x4, %esi
    2675:      	movq	%rbp, %rdx
    2678:      	callq	*%rax
    267a:      	movl	$0x50, %r12d
    2680:      	testq	%rax, %rax
    2683:      	jne	0x27b7 <generic_retkprobe_event+0x27b7>
    2689:      	xorl	%eax, %eax
    268b:      	cmpl	$0x0, 0x70(%rsp)
    2690:      	setne	%al
    2693:      	movq	0x8(%rsp), %rcx
    2698:      	movl	%eax, (%rcx)
    269a:      	jmp	0x27b7 <generic_retkprobe_event+0x27b7>
    269f:      	xorl	%r12d, %r12d
    26a2:      	jmp	0x1481 <generic_retkprobe_event+0x1481>
    26a7:      	addq	$0x3, %r12
    26ab:      	movl	$0x6b, %ecx
    26b0:      	movl	$0x71, %eax
    26b5:      	movl	$0x6b, %esi
    26ba:      	movq	%r12, %rdx
    26bd:      	callq	*%rax
    26bf:      	movq	%rax, %rcx
    26c2:      	movb	$0x6b, %al
    26c4:      	testl	%ecx, %ecx
    26c6:      	js	0x26d2 <generic_retkprobe_event+0x26d2>
    26c8:      	movq	(%rsp), %rcx
    26cc:      	movb	%al, 0x9f(%rcx)
    26d2:      	movl	$0x70, %r12d
    26d8:      	movq	0x20(%rsp), %r13
    26dd:      	jmp	0x1481 <generic_retkprobe_event+0x1481>
    26e2:      	leaq	0x48(%r12), %rdx
    26e7:      	movl	$0x10, %ecx
    26ec:      	movl	$0x4, %eax
    26f1:      	movq	0x8(%rsp), %rdi
    26f6:      	movl	$0x10, %esi
    26fb:      	callq	*%rax
    26fd:      	leaq	0x38(%r12), %rdx
    2702:      	movl	$0x10, %ecx
    2707:      	movl	$0x4, %eax
    270c:      	movq	%r13, %rdi
    270f:      	movl	$0x10, %esi
    2714:      	callq	*%rax
    2716:      	movq	(%rsp), %r13
    271a:      	leaq	0xbc(%r13), %rdi
    2721:      	leaq	0xc(%r12), %r14
    2726:      	addq	$0xe, %r12
    272a:      	movl	$0x2, %ecx
    272f:      	movl	$0x4, %eax
    2734:      	movl	$0x2, %esi
    2739:      	movq	%r12, %rdx
    273c:      	callq	*%rax
    273e:      	movq	%r13, %rdi
    2741:      	addq	$0xbe, %rdi
    2748:      	movl	$0x2, %ecx
    274d:      	movl	$0x4, %eax
    2752:      	movl	$0x2, %esi
    2757:      	movq	%r14, %rdx
    275a:      	callq	*%rax
    275c:      	movzwl	0xbe(%r13), %eax
    2764:      	movbew	%ax, 0xbe(%r13)
    276e:      	movq	(%rsp), %rax
    2772:      	movq	0xc4(%rax), %rax
    2779:      	movq	%rax, 0x30(%rsp)
    277e:      	movq	(%rip), %rdi            # 0x2785 <generic_retkprobe_event+0x2785>
    2785:      	leaq	0x30(%rsp), %rsi
    278a:      	movl	$0x1, %eax
    278f:      	callq	*%rax
    2791:      	testq	%rax, %rax
    2794:      	je	0x27b1 <generic_retkprobe_event+0x27b1>
    2796:      	movl	(%rax), %ecx
    2798:      	movq	0x80(%rsp), %rdx
    27a0:      	movl	%ecx, 0x10(%rdx)
    27a3:      	movq	0x8(%rax), %rcx
    27a7:      	movq	%rcx, 0x18(%rdx)
    27ab:      	movl	0x4(%rax), %eax
    27ae:      	movl	%eax, 0x7c(%rdx)
    27b1:      	movl	$0x40, %r12d
    27b7:      	movq	0x20(%rsp), %r13
    27bc:      	movq	(%rsp), %rcx
    27c0:      	movq	0x18(%rsp), %r15
    27c5:      	jmp	0x1485 <generic_retkprobe_event+0x1485>
    27ca:      	cmpl	$0x33, %eax
    27cd:      	je	0x28e2 <generic_retkprobe_event+0x28e2>
    27d3:      	cmpl	$0x3c, %eax
    27d6:      	je	0x27f3 <generic_retkprobe_event+0x27f3>
    27d8:      	cmpl	$0xff, %eax
    27dd:      	jne	0x29a5 <generic_retkprobe_event+0x29a5>
    27e3:      	movw	$0x28, 0x2(%r13)
    27ea:      	movw	$0x28, %ax
    27ee:      	jmp	0x28f3 <generic_retkprobe_event+0x28f3>
    27f3:      	movzbl	0x7(%r13), %eax
    27f8:      	leal	0x8(,%rax,8), %eax
    27ff:      	jmp	0x28ee <generic_retkprobe_event+0x28ee>
    2804:      	xorl	%eax, %eax
    2806:      	movq	%rax, 0x8(%rsp)
    280b:      	cmpq	$0x3, 0x88(%rsp)
    2814:      	jne	0x2828 <generic_retkprobe_event+0x2828>
    2816:      	movq	%rbp, %r13
    2819:      	movq	0x28(%rsp), %r14
    281e:      	movq	0x18(%rsp), %r15
    2823:      	jmp	0x422 <generic_retkprobe_event+0x422>
    2828:      	movq	0x90(%rsp), %rax
    2830:      	leaq	0x30(%rax), %rdx
    2834:      	leaq	0x30(%rsp), %rdi
    2839:      	movl	$0x4, %r12d
    283f:      	movl	$0x10, %ecx
    2844:      	movl	$0x4, %eax
    2849:      	movl	$0x10, %esi
    284e:      	callq	*%rax
    2850:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2855:      	testl	%eax, %eax
    2857:      	js	0x3267 <generic_retkprobe_event+0x3267>
    285d:      	movq	0x38(%rsp), %rdx
    2862:      	movq	0x8(%rsp), %rax
    2867:      	cmpq	%rax, %rdx
    286a:      	movq	%rax, %r13
    286d:      	cmovbq	%rdx, %r13
    2871:      	testq	%rax, %rax
    2874:      	cmovneq	%r13, %rdx
    2878:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    287d:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    2884:      	ja	0x3267 <generic_retkprobe_event+0x3267>
    288a:      	movq	%rdx, %r14
    288d:      	movq	%r15, %rdi
    2890:      	addq	(%rsp), %rdi
    2894:      	movq	%rdi, %r15
    2897:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    289d:      	addq	0x18(%rsp), %rdi
    28a2:      	movq	0x30(%rsp), %rcx
    28a7:      	movl	$0x4, %eax
    28ac:      	movq	%rdx, %rsi
    28af:      	movq	0x30(%rsp), %rdx
    28b4:      	callq	*%rax
    28b6:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    28bb:      	testl	%eax, %eax
    28bd:      	js	0x3267 <generic_retkprobe_event+0x3267>
    28c3:      	addq	%r14, %rbp
    28c6:      	cmpq	$0x0, 0x8(%rsp)
    28cc:      	je	0x2c22 <generic_retkprobe_event+0x2c22>
    28d2:      	subq	%r13, 0x8(%rsp)
    28d7:      	jne	0x2c29 <generic_retkprobe_event+0x2c29>
    28dd:      	jmp	0x2816 <generic_retkprobe_event+0x2816>
    28e2:      	movzbl	0x7(%r13), %eax
    28e7:      	leal	0x8(,%rax,4), %eax
    28ee:      	movw	%ax, 0x2(%r13)
    28f3:      	addw	(%r13), %ax
    28f8:      	movw	%ax, (%r13)
    28fd:      	movzbl	0x6(%r13), %ecx
    2902:      	cmpq	$0x3c, %rcx
    2906:      	ja	0x30ee <generic_retkprobe_event+0x30ee>
    290c:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2916:      	btq	%rcx, %rdx
    291a:      	jae	0x30ee <generic_retkprobe_event+0x30ee>
    2920:      	movb	%cl, 0x5(%r13)
    2924:      	movzwl	%ax, %ecx
    2927:      	addq	%r14, %rcx
    292a:      	movl	$0x2, %edx
    292f:      	movl	$0x4, %eax
    2934:      	movq	%r12, %rdi
    2937:      	movzwl	(%r13), %edx
    293c:      	addq	%r14, %rdx
    293f:      	movl	$0x2, %esi
    2944:      	callq	*%rax
    2946:      	testq	%rax, %rax
    2949:      	js	0x2ef3 <generic_retkprobe_event+0x2ef3>
    294f:      	movzbl	0x5(%r13), %eax
    2954:      	cmpl	$0x32, %eax
    2957:      	jg	0x2974 <generic_retkprobe_event+0x2974>
    2959:      	testl	%eax, %eax
    295b:      	je	0x2992 <generic_retkprobe_event+0x2992>
    295d:      	cmpl	$0x2b, %eax
    2960:      	je	0x2992 <generic_retkprobe_event+0x2992>
    2962:      	cmpl	$0x2c, %eax
    2965:      	jne	0x29c2 <generic_retkprobe_event+0x29c2>
    2967:      	movw	$0x8, 0x2(%r13)
    296e:      	movw	$0x8, %ax
    2972:      	jmp	0x29c7 <generic_retkprobe_event+0x29c7>
    2974:      	cmpl	$0x33, %eax
    2977:      	je	0x29af <generic_retkprobe_event+0x29af>
    2979:      	cmpl	$0x3c, %eax
    297c:      	je	0x2992 <generic_retkprobe_event+0x2992>
    297e:      	cmpl	$0xff, %eax
    2983:      	jne	0x29c2 <generic_retkprobe_event+0x29c2>
    2985:      	movw	$0x28, 0x2(%r13)
    298c:      	movw	$0x28, %ax
    2990:      	jmp	0x29c7 <generic_retkprobe_event+0x29c7>
    2992:      	movzbl	0x7(%r13), %eax
    2997:      	leal	0x8(,%rax,8), %eax
    299e:      	movw	%ax, 0x2(%r13)
    29a3:      	jmp	0x29c7 <generic_retkprobe_event+0x29c7>
    29a5:      	movzwl	0x2(%r13), %eax
    29aa:      	jmp	0x28f3 <generic_retkprobe_event+0x28f3>
    29af:      	movzbl	0x7(%r13), %eax
    29b4:      	leal	0x8(,%rax,4), %eax
    29bb:      	movw	%ax, 0x2(%r13)
    29c0:      	jmp	0x29c7 <generic_retkprobe_event+0x29c7>
    29c2:      	movzwl	0x2(%r13), %eax
    29c7:      	addw	(%r13), %ax
    29cc:      	movw	%ax, (%r13)
    29d1:      	movzbl	0x6(%r13), %ecx
    29d6:      	cmpq	$0x3c, %rcx
    29da:      	ja	0x30ee <generic_retkprobe_event+0x30ee>
    29e0:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    29ea:      	btq	%rcx, %rdx
    29ee:      	jae	0x30ee <generic_retkprobe_event+0x30ee>
    29f4:      	movb	%cl, 0x5(%r13)
    29f8:      	movzwl	%ax, %ecx
    29fb:      	addq	%r14, %rcx
    29fe:      	movl	$0x2, %edx
    2a03:      	movl	$0x4, %eax
    2a08:      	movq	%r12, %rdi
    2a0b:      	movzwl	(%r13), %edx
    2a10:      	addq	%r14, %rdx
    2a13:      	movl	$0x2, %esi
    2a18:      	callq	*%rax
    2a1a:      	testq	%rax, %rax
    2a1d:      	js	0x2ef3 <generic_retkprobe_event+0x2ef3>
    2a23:      	movzbl	0x5(%r13), %eax
    2a28:      	cmpl	$0x32, %eax
    2a2b:      	jg	0x2a48 <generic_retkprobe_event+0x2a48>
    2a2d:      	testl	%eax, %eax
    2a2f:      	je	0x2a66 <generic_retkprobe_event+0x2a66>
    2a31:      	cmpl	$0x2b, %eax
    2a34:      	je	0x2a66 <generic_retkprobe_event+0x2a66>
    2a36:      	cmpl	$0x2c, %eax
    2a39:      	jne	0x2a8c <generic_retkprobe_event+0x2a8c>
    2a3b:      	movw	$0x8, 0x2(%r13)
    2a42:      	movw	$0x8, %ax
    2a46:      	jmp	0x2a91 <generic_retkprobe_event+0x2a91>
    2a48:      	cmpl	$0x33, %eax
    2a4b:      	je	0x2a79 <generic_retkprobe_event+0x2a79>
    2a4d:      	cmpl	$0x3c, %eax
    2a50:      	je	0x2a66 <generic_retkprobe_event+0x2a66>
    2a52:      	cmpl	$0xff, %eax
    2a57:      	jne	0x2a8c <generic_retkprobe_event+0x2a8c>
    2a59:      	movw	$0x28, 0x2(%r13)
    2a60:      	movw	$0x28, %ax
    2a64:      	jmp	0x2a91 <generic_retkprobe_event+0x2a91>
    2a66:      	movzbl	0x7(%r13), %eax
    2a6b:      	leal	0x8(,%rax,8), %eax
    2a72:      	movw	%ax, 0x2(%r13)
    2a77:      	jmp	0x2a91 <generic_retkprobe_event+0x2a91>
    2a79:      	movzbl	0x7(%r13), %eax
    2a7e:      	leal	0x8(,%rax,4), %eax
    2a85:      	movw	%ax, 0x2(%r13)
    2a8a:      	jmp	0x2a91 <generic_retkprobe_event+0x2a91>
    2a8c:      	movzwl	0x2(%r13), %eax
    2a91:      	addw	(%r13), %ax
    2a96:      	movw	%ax, (%r13)
    2a9b:      	movzbl	0x6(%r13), %ecx
    2aa0:      	cmpq	$0x3c, %rcx
    2aa4:      	ja	0x30ee <generic_retkprobe_event+0x30ee>
    2aaa:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2ab4:      	btq	%rcx, %rdx
    2ab8:      	jae	0x30ee <generic_retkprobe_event+0x30ee>
    2abe:      	movb	%cl, 0x5(%r13)
    2ac2:      	movzwl	%ax, %ecx
    2ac5:      	addq	%r14, %rcx
    2ac8:      	movl	$0x2, %edx
    2acd:      	movl	$0x4, %eax
    2ad2:      	movq	%r12, %rdi
    2ad5:      	movzwl	(%r13), %edx
    2ada:      	addq	%r14, %rdx
    2add:      	movl	$0x2, %esi
    2ae2:      	callq	*%rax
    2ae4:      	testq	%rax, %rax
    2ae7:      	js	0x2ef3 <generic_retkprobe_event+0x2ef3>
    2aed:      	movzbl	0x5(%r13), %eax
    2af2:      	cmpl	$0x32, %eax
    2af5:      	jg	0x2b12 <generic_retkprobe_event+0x2b12>
    2af7:      	testl	%eax, %eax
    2af9:      	je	0x2b30 <generic_retkprobe_event+0x2b30>
    2afb:      	cmpl	$0x2b, %eax
    2afe:      	je	0x2b30 <generic_retkprobe_event+0x2b30>
    2b00:      	cmpl	$0x2c, %eax
    2b03:      	jne	0x2b56 <generic_retkprobe_event+0x2b56>
    2b05:      	movw	$0x8, 0x2(%r13)
    2b0c:      	movw	$0x8, %ax
    2b10:      	jmp	0x2b5b <generic_retkprobe_event+0x2b5b>
    2b12:      	cmpl	$0x33, %eax
    2b15:      	je	0x2b43 <generic_retkprobe_event+0x2b43>
    2b17:      	cmpl	$0x3c, %eax
    2b1a:      	je	0x2b30 <generic_retkprobe_event+0x2b30>
    2b1c:      	cmpl	$0xff, %eax
    2b21:      	jne	0x2b56 <generic_retkprobe_event+0x2b56>
    2b23:      	movw	$0x28, 0x2(%r13)
    2b2a:      	movw	$0x28, %ax
    2b2e:      	jmp	0x2b5b <generic_retkprobe_event+0x2b5b>
    2b30:      	movzbl	0x7(%r13), %eax
    2b35:      	leal	0x8(,%rax,8), %eax
    2b3c:      	movw	%ax, 0x2(%r13)
    2b41:      	jmp	0x2b5b <generic_retkprobe_event+0x2b5b>
    2b43:      	movzbl	0x7(%r13), %eax
    2b48:      	leal	0x8(,%rax,4), %eax
    2b4f:      	movw	%ax, 0x2(%r13)
    2b54:      	jmp	0x2b5b <generic_retkprobe_event+0x2b5b>
    2b56:      	movzwl	0x2(%r13), %eax
    2b5b:      	addw	(%r13), %ax
    2b60:      	movw	%ax, (%r13)
    2b65:      	movzbl	0x6(%r13), %ecx
    2b6a:      	cmpq	$0x3c, %rcx
    2b6e:      	ja	0x30ee <generic_retkprobe_event+0x30ee>
    2b74:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2b7e:      	btq	%rcx, %rdx
    2b82:      	jae	0x30ee <generic_retkprobe_event+0x30ee>
    2b88:      	movb	%cl, 0x5(%r13)
    2b8c:      	movzwl	%ax, %ecx
    2b8f:      	addq	%r14, %rcx
    2b92:      	movl	$0x2, %edx
    2b97:      	movl	$0x4, %eax
    2b9c:      	movq	%r12, %rdi
    2b9f:      	movzwl	(%r13), %edx
    2ba4:      	addq	%r14, %rdx
    2ba7:      	movl	$0x2, %esi
    2bac:      	callq	*%rax
    2bae:      	testq	%rax, %rax
    2bb1:      	js	0x2ef3 <generic_retkprobe_event+0x2ef3>
    2bb7:      	movzbl	0x5(%r13), %eax
    2bbc:      	cmpl	$0x32, %eax
    2bbf:      	jg	0x2be3 <generic_retkprobe_event+0x2be3>
    2bc1:      	testl	%eax, %eax
    2bc3:      	je	0x2c0c <generic_retkprobe_event+0x2c0c>
    2bc5:      	cmpl	$0x2b, %eax
    2bc8:      	je	0x2c0c <generic_retkprobe_event+0x2c0c>
    2bca:      	cmpl	$0x2c, %eax
    2bcd:      	jne	0x2d07 <generic_retkprobe_event+0x2d07>
    2bd3:      	movw	$0x8, 0x2(%r13)
    2bda:      	movw	$0x8, %ax
    2bde:      	jmp	0x2d0c <generic_retkprobe_event+0x2d0c>
    2be3:      	cmpl	$0x33, %eax
    2be6:      	je	0x2cf4 <generic_retkprobe_event+0x2cf4>
    2bec:      	cmpl	$0x3c, %eax
    2bef:      	je	0x2c0c <generic_retkprobe_event+0x2c0c>
    2bf1:      	cmpl	$0xff, %eax
    2bf6:      	jne	0x2d07 <generic_retkprobe_event+0x2d07>
    2bfc:      	movw	$0x28, 0x2(%r13)
    2c03:      	movw	$0x28, %ax
    2c07:      	jmp	0x2d0c <generic_retkprobe_event+0x2d0c>
    2c0c:      	movzbl	0x7(%r13), %eax
    2c11:      	leal	0x8(,%rax,8), %eax
    2c18:      	movw	%ax, 0x2(%r13)
    2c1d:      	jmp	0x2d0c <generic_retkprobe_event+0x2d0c>
    2c22:      	xorl	%eax, %eax
    2c24:      	movq	%rax, 0x8(%rsp)
    2c29:      	cmpq	$0x5, 0x88(%rsp)
    2c32:      	jb	0x2816 <generic_retkprobe_event+0x2816>
    2c38:      	movq	0x90(%rsp), %rax
    2c40:      	leaq	0x40(%rax), %rdx
    2c44:      	leaq	0x30(%rsp), %rdi
    2c49:      	movl	$0x4, %r12d
    2c4f:      	movl	$0x10, %ecx
    2c54:      	movl	$0x4, %eax
    2c59:      	movl	$0x10, %esi
    2c5e:      	callq	*%rax
    2c60:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2c65:      	testl	%eax, %eax
    2c67:      	js	0x3267 <generic_retkprobe_event+0x3267>
    2c6d:      	movq	0x38(%rsp), %rdx
    2c72:      	movq	0x8(%rsp), %rax
    2c77:      	cmpq	%rax, %rdx
    2c7a:      	movq	%rax, %r13
    2c7d:      	cmovbq	%rdx, %r13
    2c81:      	testq	%rax, %rax
    2c84:      	cmovneq	%r13, %rdx
    2c88:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2c8d:      	movq	%rdx, (%rsp)
    2c91:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    2c98:      	ja	0x3267 <generic_retkprobe_event+0x3267>
    2c9e:      	movq	%r14, %rdi
    2ca1:      	addq	%r15, %rdi
    2ca4:      	movq	%rdi, %r14
    2ca7:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2cad:      	addq	0x18(%rsp), %rdi
    2cb2:      	movq	0x30(%rsp), %rcx
    2cb7:      	movl	$0x4, %eax
    2cbc:      	movq	(%rsp), %rsi
    2cc0:      	movq	0x30(%rsp), %rdx
    2cc5:      	callq	*%rax
    2cc7:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2ccc:      	testl	%eax, %eax
    2cce:      	js	0x3267 <generic_retkprobe_event+0x3267>
    2cd4:      	addq	(%rsp), %rbp
    2cd8:      	cmpq	$0x0, 0x8(%rsp)
    2cde:      	je	0x30fb <generic_retkprobe_event+0x30fb>
    2ce4:      	subq	%r13, 0x8(%rsp)
    2ce9:      	jne	0x3102 <generic_retkprobe_event+0x3102>
    2cef:      	jmp	0x2816 <generic_retkprobe_event+0x2816>
    2cf4:      	movzbl	0x7(%r13), %eax
    2cf9:      	leal	0x8(,%rax,4), %eax
    2d00:      	movw	%ax, 0x2(%r13)
    2d05:      	jmp	0x2d0c <generic_retkprobe_event+0x2d0c>
    2d07:      	movzwl	0x2(%r13), %eax
    2d0c:      	addw	(%r13), %ax
    2d11:      	movw	%ax, (%r13)
    2d16:      	movzbl	0x6(%r13), %ecx
    2d1b:      	cmpq	$0x3c, %rcx
    2d1f:      	ja	0x30ee <generic_retkprobe_event+0x30ee>
    2d25:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2d2f:      	btq	%rcx, %rdx
    2d33:      	jae	0x30ee <generic_retkprobe_event+0x30ee>
    2d39:      	movb	%cl, 0x5(%r13)
    2d3d:      	movzwl	%ax, %ecx
    2d40:      	addq	%r14, %rcx
    2d43:      	movl	$0x2, %edx
    2d48:      	movl	$0x4, %eax
    2d4d:      	movq	%r12, %rdi
    2d50:      	movzwl	(%r13), %edx
    2d55:      	addq	%r14, %rdx
    2d58:      	movl	$0x2, %esi
    2d5d:      	callq	*%rax
    2d5f:      	testq	%rax, %rax
    2d62:      	js	0x2ef3 <generic_retkprobe_event+0x2ef3>
    2d68:      	movzbl	0x5(%r13), %eax
    2d6d:      	cmpl	$0x32, %eax
    2d70:      	jg	0x2d8d <generic_retkprobe_event+0x2d8d>
    2d72:      	testl	%eax, %eax
    2d74:      	je	0x2dab <generic_retkprobe_event+0x2dab>
    2d76:      	cmpl	$0x2b, %eax
    2d79:      	je	0x2dab <generic_retkprobe_event+0x2dab>
    2d7b:      	cmpl	$0x2c, %eax
    2d7e:      	jne	0x2dd1 <generic_retkprobe_event+0x2dd1>
    2d80:      	movw	$0x8, 0x2(%r13)
    2d87:      	movw	$0x8, %ax
    2d8b:      	jmp	0x2dd6 <generic_retkprobe_event+0x2dd6>
    2d8d:      	cmpl	$0x33, %eax
    2d90:      	je	0x2dbe <generic_retkprobe_event+0x2dbe>
    2d92:      	cmpl	$0x3c, %eax
    2d95:      	je	0x2dab <generic_retkprobe_event+0x2dab>
    2d97:      	cmpl	$0xff, %eax
    2d9c:      	jne	0x2dd1 <generic_retkprobe_event+0x2dd1>
    2d9e:      	movw	$0x28, 0x2(%r13)
    2da5:      	movw	$0x28, %ax
    2da9:      	jmp	0x2dd6 <generic_retkprobe_event+0x2dd6>
    2dab:      	movzbl	0x7(%r13), %eax
    2db0:      	leal	0x8(,%rax,8), %eax
    2db7:      	movw	%ax, 0x2(%r13)
    2dbc:      	jmp	0x2dd6 <generic_retkprobe_event+0x2dd6>
    2dbe:      	movzbl	0x7(%r13), %eax
    2dc3:      	leal	0x8(,%rax,4), %eax
    2dca:      	movw	%ax, 0x2(%r13)
    2dcf:      	jmp	0x2dd6 <generic_retkprobe_event+0x2dd6>
    2dd1:      	movzwl	0x2(%r13), %eax
    2dd6:      	addw	(%r13), %ax
    2ddb:      	movw	%ax, (%r13)
    2de0:      	movzbl	0x6(%r13), %ecx
    2de5:      	cmpq	$0x3c, %rcx
    2de9:      	ja	0x30ee <generic_retkprobe_event+0x30ee>
    2def:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2df9:      	btq	%rcx, %rdx
    2dfd:      	jae	0x30ee <generic_retkprobe_event+0x30ee>
    2e03:      	movb	%cl, 0x5(%r13)
    2e07:      	movzwl	%ax, %ecx
    2e0a:      	addq	%r14, %rcx
    2e0d:      	movl	$0x2, %edx
    2e12:      	movl	$0x4, %eax
    2e17:      	movq	%r12, %rdi
    2e1a:      	movzwl	(%r13), %edx
    2e1f:      	addq	%r14, %rdx
    2e22:      	movl	$0x2, %esi
    2e27:      	callq	*%rax
    2e29:      	testq	%rax, %rax
    2e2c:      	js	0x2ef3 <generic_retkprobe_event+0x2ef3>
    2e32:      	movzbl	0x5(%r13), %eax
    2e37:      	cmpl	$0x32, %eax
    2e3a:      	jg	0x2e57 <generic_retkprobe_event+0x2e57>
    2e3c:      	testl	%eax, %eax
    2e3e:      	je	0x2e75 <generic_retkprobe_event+0x2e75>
    2e40:      	cmpl	$0x2b, %eax
    2e43:      	je	0x2e75 <generic_retkprobe_event+0x2e75>
    2e45:      	cmpl	$0x2c, %eax
    2e48:      	jne	0x2e9b <generic_retkprobe_event+0x2e9b>
    2e4a:      	movw	$0x8, 0x2(%r13)
    2e51:      	movw	$0x8, %ax
    2e55:      	jmp	0x2ea0 <generic_retkprobe_event+0x2ea0>
    2e57:      	cmpl	$0x33, %eax
    2e5a:      	je	0x2e88 <generic_retkprobe_event+0x2e88>
    2e5c:      	cmpl	$0x3c, %eax
    2e5f:      	je	0x2e75 <generic_retkprobe_event+0x2e75>
    2e61:      	cmpl	$0xff, %eax
    2e66:      	jne	0x2e9b <generic_retkprobe_event+0x2e9b>
    2e68:      	movw	$0x28, 0x2(%r13)
    2e6f:      	movw	$0x28, %ax
    2e73:      	jmp	0x2ea0 <generic_retkprobe_event+0x2ea0>
    2e75:      	movzbl	0x7(%r13), %eax
    2e7a:      	leal	0x8(,%rax,8), %eax
    2e81:      	movw	%ax, 0x2(%r13)
    2e86:      	jmp	0x2ea0 <generic_retkprobe_event+0x2ea0>
    2e88:      	movzbl	0x7(%r13), %eax
    2e8d:      	leal	0x8(,%rax,4), %eax
    2e94:      	movw	%ax, 0x2(%r13)
    2e99:      	jmp	0x2ea0 <generic_retkprobe_event+0x2ea0>
    2e9b:      	movzwl	0x2(%r13), %eax
    2ea0:      	addw	(%r13), %ax
    2ea5:      	movw	%ax, (%r13)
    2eaa:      	movzbl	0x6(%r13), %ecx
    2eaf:      	cmpq	$0x3c, %rcx
    2eb3:      	ja	0x30ee <generic_retkprobe_event+0x30ee>
    2eb9:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2ec3:      	btq	%rcx, %rdx
    2ec7:      	jae	0x30ee <generic_retkprobe_event+0x30ee>
    2ecd:      	movb	%cl, 0x5(%r13)
    2ed1:      	movzwl	%ax, %ecx
    2ed4:      	addq	%r14, %rcx
    2ed7:      	movl	$0x2, %edx
    2edc:      	movl	$0x4, %eax
    2ee1:      	movzwl	(%r13), %edx
    2ee6:      	addq	%r14, %rdx
    2ee9:      	movq	%r12, %rdi
    2eec:      	movl	$0x2, %esi
    2ef1:      	callq	*%rax
    2ef3:      	xorl	%ecx, %ecx
    2ef5:      	movb	%cl, 0xc8(%rsp)
    2efc:      	movzbl	%cl, %eax
    2eff:      	movq	(%rsp), %r14
    2f03:      	movw	%ax, 0xc0(%r14)
    2f0b:      	movw	$0xa, 0xc2(%r14)
    2f15:      	movq	0x80(%rsp), %r12
    2f1d:      	leaq	0x8(%r12), %rdx
    2f22:      	movl	$0x10, %ecx
    2f27:      	movl	$0x4, %eax
    2f2c:      	movq	%rbp, %rdi
    2f2f:      	movl	$0x10, %esi
    2f34:      	callq	*%rax
    2f36:      	leaq	0xac(%r14), %rdi
    2f3d:      	addq	$0x18, %r12
    2f41:      	movl	$0x10, %ecx
    2f46:      	movl	$0x4, %eax
    2f4b:      	movl	$0x10, %esi
    2f50:      	movq	%r12, %rdx
    2f53:      	callq	*%rax
    2f55:      	movzbl	0xc8(%rsp), %eax
    2f5d:      	cmpl	$0x11, %eax
    2f60:      	je	0x2fb4 <generic_retkprobe_event+0x2fb4>
    2f62:      	cmpl	$0x6, %eax
    2f65:      	jne	0x3004 <generic_retkprobe_event+0x3004>
    2f6b:      	movq	0x30(%rsp), %r14
    2f70:      	movzwl	0xd0(%rsp), %r12d
    2f79:      	leaq	(%r14,%r12), %rdx
    2f7d:      	movq	(%rsp), %r13
    2f81:      	leaq	0xbc(%r13), %rdi
    2f88:      	movl	$0x2, %ecx
    2f8d:      	movl	$0x4, %eax
    2f92:      	movl	$0x2, %esi
    2f97:      	callq	*%rax
    2f99:      	leaq	0xbe(%r13), %rdi
    2fa0:      	leaq	(%r14,%r12), %rdx
    2fa4:      	addq	$0x2, %rdx
    2fa8:      	movl	$0x2, %ecx
    2fad:      	movl	$0x4, %eax
    2fb2:      	jmp	0x2ffb <generic_retkprobe_event+0x2ffb>
    2fb4:      	movq	0x30(%rsp), %r14
    2fb9:      	movzwl	0xd0(%rsp), %r12d
    2fc2:      	leaq	(%r14,%r12), %rdx
    2fc6:      	movq	(%rsp), %r13
    2fca:      	leaq	0xbc(%r13), %rdi
    2fd1:      	movl	$0x2, %ecx
    2fd6:      	movl	$0x4, %eax
    2fdb:      	movl	$0x2, %esi
    2fe0:      	callq	*%rax
    2fe2:      	leaq	0xbe(%r13), %rdi
    2fe9:      	leaq	(%r14,%r12), %rdx
    2fed:      	addq	$0x2, %rdx
    2ff1:      	movl	$0x2, %ecx
    2ff6:      	movl	$0x4, %eax
    2ffb:      	movl	$0x2, %esi
    3000:      	callq	*%rax
    3002:      	jmp	0x3013 <generic_retkprobe_event+0x3013>
    3004:      	movq	(%rsp), %r13
    3008:      	movl	$0x0, 0xbc(%r13)
    3013:      	movzwl	0xbc(%r13), %eax
    301b:      	movzwl	0xbe(%r13), %ecx
    3023:      	movbew	%ax, 0xbc(%r13)
    302d:      	movbew	%cx, 0xbe(%r13)
    3037:      	movq	0x8(%rsp), %rdx
    303c:      	addq	$0xe0, %rdx
    3043:      	leaq	0x70(%rsp), %rdi
    3048:      	movl	$0x8, %ecx
    304d:      	movl	$0x4, %eax
    3052:      	movl	$0x4, %r14d
    3058:      	movl	$0x8, %esi
    305d:      	callq	*%rax
    305f:      	movq	0x70(%rsp), %rcx
    3064:      	testq	%rcx, %rcx
    3067:      	je	0x30d9 <generic_retkprobe_event+0x30d9>
    3069:      	addq	$0x5, %rcx
    306d:      	leaq	0xa0(%rsp), %rdi
    3075:      	movl	$0x8, %edx
    307a:      	movl	$0x4, %eax
    307f:      	movq	0x70(%rsp), %rdx
    3084:      	addq	$0x5, %rdx
    3088:      	movl	$0x8, %esi
    308d:      	callq	*%rax
    308f:      	movq	0x70(%rsp), %r12
    3094:      	movq	0xa0(%rsp), %r13
    309c:      	movq	(%rsp), %rbp
    30a0:      	leaq	0xd4(%rbp), %rdi
    30a7:      	leaq	(%r12,%r13,8), %rdx
    30ab:      	addq	$0x44, %rdx
    30af:      	movl	$0x4, %eax
    30b4:      	movl	$0x4, %esi
    30b9:      	callq	*%rax
    30bb:      	movq	%rbp, %rdi
    30be:      	addq	$0xd8, %rdi
    30c5:      	leaq	(%r12,%r13,8), %rdx
    30c9:      	addq	$0x45, %rdx
    30cd:      	movl	$0x4, %eax
    30d2:      	movl	$0x4, %esi
    30d7:      	callq	*%rax
    30d9:      	movq	0x20(%rsp), %r13
    30de:      	movq	0x18(%rsp), %r15
    30e3:      	movl	$0x40, %r12d
    30e9:      	jmp	0x1481 <generic_retkprobe_event+0x1481>
    30ee:      	movw	%ax, 0xd0(%rsp)
    30f6:      	jmp	0x2ef5 <generic_retkprobe_event+0x2ef5>
    30fb:      	xorl	%eax, %eax
    30fd:      	movq	%rax, 0x8(%rsp)
    3102:      	cmpq	$0x5, 0x88(%rsp)
    310b:      	je	0x2816 <generic_retkprobe_event+0x2816>
    3111:      	movq	0x90(%rsp), %rax
    3119:      	leaq	0x50(%rax), %rdx
    311d:      	leaq	0x30(%rsp), %rdi
    3122:      	movl	$0x4, %r12d
    3128:      	movl	$0x10, %ecx
    312d:      	movl	$0x4, %eax
    3132:      	movl	$0x10, %esi
    3137:      	callq	*%rax
    3139:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    313e:      	testl	%eax, %eax
    3140:      	js	0x3267 <generic_retkprobe_event+0x3267>
    3146:      	movq	0x38(%rsp), %r15
    314b:      	movq	0x8(%rsp), %rax
    3150:      	cmpq	%rax, %r15
    3153:      	movq	%rax, %r13
    3156:      	cmovbq	%r15, %r13
    315a:      	testq	%rax, %rax
    315d:      	cmovneq	%r13, %r15
    3161:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    3166:      	cmpq	$0xffe, %r15            # imm = 0xFFE
    316d:      	ja	0x3267 <generic_retkprobe_event+0x3267>
    3173:      	movq	(%rsp), %rdi
    3177:      	addq	%r14, %rdi
    317a:      	movq	%rdi, %r14
    317d:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    3183:      	addq	0x18(%rsp), %rdi
    3188:      	movq	0x30(%rsp), %rcx
    318d:      	movl	$0x4, %eax
    3192:      	movq	0x30(%rsp), %rdx
    3197:      	movl	%r15d, %esi
    319a:      	callq	*%rax
    319c:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    31a1:      	testl	%eax, %eax
    31a3:      	js	0x3267 <generic_retkprobe_event+0x3267>
    31a9:      	addq	%r15, %rbp
    31ac:      	cmpq	$0x0, 0x8(%rsp)
    31b2:      	je	0x31c0 <generic_retkprobe_event+0x31c0>
    31b4:      	subq	%r13, 0x8(%rsp)
    31b9:      	jne	0x31c7 <generic_retkprobe_event+0x31c7>
    31bb:      	jmp	0x2816 <generic_retkprobe_event+0x2816>
    31c0:      	xorl	%eax, %eax
    31c2:      	movq	%rax, 0x8(%rsp)
    31c7:      	cmpq	$0x7, 0x88(%rsp)
    31d0:      	jb	0x2816 <generic_retkprobe_event+0x2816>
    31d6:      	movq	0x90(%rsp), %rdx
    31de:      	addq	$0x60, %rdx
    31e2:      	leaq	0x30(%rsp), %rdi
    31e7:      	movl	$0x4, %r12d
    31ed:      	movl	$0x10, %ecx
    31f2:      	movl	$0x4, %eax
    31f7:      	movl	$0x10, %esi
    31fc:      	callq	*%rax
    31fe:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3203:      	testl	%eax, %eax
    3205:      	js	0x3267 <generic_retkprobe_event+0x3267>
    3207:      	movq	0x38(%rsp), %rax
    320c:      	movq	0x8(%rsp), %rcx
    3211:      	cmpq	%rcx, %rax
    3214:      	movq	%rcx, %r13
    3217:      	cmovbq	%rax, %r13
    321b:      	testq	%rcx, %rcx
    321e:      	cmoveq	%rax, %r13
    3222:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    3227:      	cmpq	$0xffe, %r13            # imm = 0xFFE
    322e:      	ja	0x3267 <generic_retkprobe_event+0x3267>
    3230:      	addq	%r14, %r15
    3233:      	andl	$0x3fff, %r15d          # imm = 0x3FFF
    323a:      	addq	0x18(%rsp), %r15
    323f:      	movq	0x30(%rsp), %rcx
    3244:      	movl	$0x4, %eax
    3249:      	movq	0x30(%rsp), %rdx
    324e:      	movq	%r15, %rdi
    3251:      	movl	%r13d, %esi
    3254:      	callq	*%rax
    3256:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    325b:      	testl	%eax, %eax
    325d:      	js	0x3267 <generic_retkprobe_event+0x3267>
    325f:      	addq	%rbp, %r13
    3262:      	jmp	0x2819 <generic_retkprobe_event+0x2819>
    3267:      	movq	0x28(%rsp), %r14
    326c:      	movq	0x18(%rsp), %rax
    3271:      	movl	%ecx, (%rax,%r14)
    3275:      	jmp	0x1b1d <generic_retkprobe_event+0x1b1d>
