
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/otel/system_config.native.o:	file format elf64-x86-64

Disassembly of section tracepoint/syscalls/sys_enter_bpf:

0000000000000000 <read_kernel_memory>:
       0:      	pushq	%r15
       2:      	pushq	%r14
       4:      	pushq	%rbx
       5:      	subq	$0x30, %rsp
       9:      	movl	$0x0, 0xc(%rsp)
      11:      	movq	(%rip), %rdi            # 0x18 <read_kernel_memory+0x18>
      18:      	leaq	0xc(%rsp), %rsi
      1d:      	movl	$0x1, %eax
      22:      	callq	*%rax
      24:      	xorl	%ebx, %ebx
      26:      	testq	%rax, %rax
      29:      	je	0x80 <read_kernel_memory+0x80>
      2b:      	movq	%rax, %r14
      2e:      	movl	0x8(%rax), %r15d
      32:      	movl	$0xe, %eax
      37:      	callq	*%rax
      39:      	shrq	$0x20, %rax
      3d:      	cmpq	%r15, %rax
      40:      	jne	0x80 <read_kernel_memory+0x80>
      42:      	movl	$0x0, 0x8(%r14)
      4a:      	movq	%r14, %rdi
      4d:      	addq	$0xc, %rdi
      51:      	movq	(%r14), %rax
      54:      	movl	$0x80, %ecx
      59:      	movl	$0x71, %r8d
      5f:      	movq	(%r14), %rdx
      62:      	movl	$0x80, %esi
      67:      	callq	*%r8
      6a:      	testq	%rax, %rax
      6d:      	je	0x80 <read_kernel_memory+0x80>
      6f:      	movq	(%rip), %rax            # 0x76 <read_kernel_memory+0x76>
      76:      	movl	$0xffffffff, %ebx       # imm = 0xFFFFFFFF
      7b:      	cmpl	$0x0, (%rax)
      7e:      	jne	0x8c <read_kernel_memory+0x8c>
      80:      	movl	%ebx, %eax
      82:      	addq	$0x30, %rsp
      86:      	popq	%rbx
      87:      	popq	%r14
      89:      	popq	%r15
      8b:      	retq
      8c:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
      96:      	movq	%rax, 0x28(%rsp)
      9b:      	movabsq	$0x6d6f72662065646f, %rax # imm = 0x6D6F72662065646F
      a5:      	movq	%rax, 0x20(%rsp)
      aa:      	movabsq	$0x632064616572206f, %rax # imm = 0x632064616572206F
      b4:      	movq	%rax, 0x18(%rsp)
      b9:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
      c3:      	movq	%rax, 0x10(%rsp)
      c8:      	leaq	0x10(%rsp), %rdi
      cd:      	movl	$0x20, %eax
      d2:      	movl	$0x6, %ecx
      d7:      	movq	(%r14), %rdx
      da:      	movl	$0x20, %esi
      df:      	xorl	%eax, %eax
      e1:      	callq	*%rcx
      e3:      	jmp	0x80 <read_kernel_memory+0x80>

Disassembly of section raw_tracepoint/sys_enter:

0000000000000000 <read_task_struct>:
       0:      	pushq	%r15
       2:      	pushq	%r14
       4:      	pushq	%r12
       6:      	pushq	%rbx
       7:      	subq	$0x38, %rsp
       b:      	movq	(%rdi), %r12
       e:      	movl	$0x0, 0xc(%rsp)
      16:      	movq	(%rip), %rdi            # 0x1d <read_task_struct+0x1d>
      1d:      	leaq	0xc(%rsp), %rsi
      22:      	movl	$0x1, %eax
      27:      	callq	*%rax
      29:      	xorl	%ebx, %ebx
      2b:      	testq	%rax, %rax
      2e:      	je	0x90 <read_task_struct+0x90>
      30:      	movq	%rax, %r15
      33:      	movl	0x8(%rax), %r14d
      37:      	movl	$0xe, %eax
      3c:      	callq	*%rax
      3e:      	shrq	$0x20, %rax
      42:      	cmpq	%r14, %rax
      45:      	jne	0x90 <read_task_struct+0x90>
      47:      	movl	$0x0, 0x8(%r15)
      4f:      	movl	$0x23, %eax
      54:      	callq	*%rax
      56:      	movq	%rax, %r14
      59:      	addq	(%r15), %r14
      5c:      	movq	%r12, (%r15)
      5f:      	addq	$0xc, %r15
      63:      	movl	$0x80, %eax
      68:      	movl	$0x71, %ecx
      6d:      	movq	%r15, %rdi
      70:      	movl	$0x80, %esi
      75:      	movq	%r14, %rdx
      78:      	callq	*%rcx
      7a:      	testq	%rax, %rax
      7d:      	je	0x90 <read_task_struct+0x90>
      7f:      	movq	(%rip), %rax            # 0x86 <read_task_struct+0x86>
      86:      	movl	$0xffffffff, %ebx       # imm = 0xFFFFFFFF
      8b:      	cmpl	$0x0, (%rax)
      8e:      	jne	0x9e <read_task_struct+0x9e>
      90:      	movl	%ebx, %eax
      92:      	addq	$0x38, %rsp
      96:      	popq	%rbx
      97:      	popq	%r12
      99:      	popq	%r14
      9b:      	popq	%r15
      9d:      	retq
      9e:      	movabsq	$0xa786c25783020, %rax  # imm = 0xA786C25783020
      a8:      	movq	%rax, 0x2f(%rsp)
      ad:      	movabsq	$0x206d6f7266207463, %rax # imm = 0x206D6F7266207463
      b7:      	movq	%rax, 0x28(%rsp)
      bc:      	movabsq	$0x757274735f6b7361, %rax # imm = 0x757274735F6B7361
      c6:      	movq	%rax, 0x20(%rsp)
      cb:      	movabsq	$0x742064616572206f, %rax # imm = 0x742064616572206F
      d5:      	movq	%rax, 0x18(%rsp)
      da:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
      e4:      	movq	%rax, 0x10(%rsp)
      e9:      	leaq	0x10(%rsp), %rdi
      ee:      	movl	$0x27, %eax
      f3:      	movl	$0x6, %ecx
      f8:      	movl	$0x27, %esi
      fd:      	movq	%r14, %rdx
     100:      	xorl	%eax, %eax
     102:      	callq	*%rcx
     104:      	jmp	0x90 <read_task_struct+0x90>
