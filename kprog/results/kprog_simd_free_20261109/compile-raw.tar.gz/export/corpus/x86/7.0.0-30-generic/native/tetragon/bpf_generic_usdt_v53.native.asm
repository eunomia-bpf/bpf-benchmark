
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_generic_usdt_v53.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
       5:      	testq	%rdx, %rdx
       8:      	je	0x74 <native_bpf_strncasestr+0x74>
       a:      	pushq	%rbx
       b:      	xorl	%ecx, %ecx
       d:      	jmp	0x1b <native_bpf_strncasestr+0x1b>
       f:      	nop
      10:      	incq	%rcx
      13:      	incq	%rdi
      16:      	cmpq	%rdx, %rcx
      19:      	je	0x73 <native_bpf_strncasestr+0x73>
      1b:      	xorl	%r8d, %r8d
      1e:      	nop
      20:      	leaq	(%rcx,%r8), %r9
      24:      	cmpq	%rdx, %r9
      27:      	jae	0x10 <native_bpf_strncasestr+0x10>
      29:      	movsbl	(%rsi,%r8), %r9d
      2e:      	testl	%r9d, %r9d
      31:      	je	0x71 <native_bpf_strncasestr+0x71>
      33:      	movsbl	(%rdi,%r8), %r10d
      38:      	leal	-0x41(%r10), %r11d
      3c:      	movl	%r10d, %ebx
      3f:      	orl	$0x20, %ebx
      42:      	cmpl	$0x1a, %r11d
      46:      	cmovael	%r10d, %ebx
      4a:      	leal	-0x41(%r9), %r10d
      4e:      	movl	%r9d, %r11d
      51:      	orl	$0x20, %r11d
      55:      	cmpl	$0x1a, %r10d
      59:      	cmovael	%r9d, %r11d
      5d:      	cmpl	%r11d, %ebx
      60:      	jne	0x10 <native_bpf_strncasestr+0x10>
      62:      	leaq	0x1(%r8), %r9
      66:      	cmpq	$0x63, %r8
      6a:      	movq	%r9, %r8
      6d:      	jb	0x20 <native_bpf_strncasestr+0x20>
      6f:      	jmp	0x10 <native_bpf_strncasestr+0x10>
      71:      	movl	%ecx, %eax
      73:      	popq	%rbx
      74:      	retq

Disassembly of section uprobe:

0000000000000000 <generic_usdt_setup_event>:
       0:      	pushq	%r15
       2:      	pushq	%r14
       4:      	pushq	%rbx
       5:      	subq	$0x20, %rsp
       9:      	movq	%rdi, %rbx
       c:      	movl	$0x0, 0x1c(%rsp)
      14:      	movq	(%rip), %rdi            # 0x1b <generic_usdt_setup_event+0x1b>
      1b:      	leaq	0x1c(%rsp), %rsi
      20:      	movl	$0x1, %eax
      25:      	callq	*%rax
      27:      	testq	%rax, %rax
      2a:      	je	0x9c6 <generic_usdt_setup_event+0x9c6>
      30:      	movq	%rax, %r14
      33:      	leaq	0x5ef8(%rax), %rsi
      3a:      	movq	(%rip), %rdi            # 0x41 <generic_usdt_setup_event+0x41>
      41:      	movl	$0x1, %eax
      46:      	callq	*%rax
      48:      	testq	%rax, %rax
      4b:      	je	0x9c6 <generic_usdt_setup_event+0x9c6>
      51:      	movq	%rax, %r15
      54:      	movb	$0x1c, (%r14)
      58:      	movw	$0x0, 0x2(%r14)
      5f:      	movl	$0x0, 0x4(%r14)
      67:      	movl	$0x7d, %eax
      6c:      	callq	*%rax
      6e:      	movq	%rax, 0x8(%r14)
      72:      	movq	$0x0, 0x70(%r14)
      7a:      	movl	$0x0, 0x14(%r14)
      82:      	movl	$0xe, %eax
      87:      	callq	*%rax
      89:      	movl	%eax, 0x7c(%r14)
      8d:      	movzbl	0x211(%r15), %ecx
      95:      	xorl	%eax, %eax
      97:      	cmpl	$0x2, %ecx
      9a:      	jg	0xe3 <generic_usdt_setup_event+0xe3>
      9c:      	cmpl	$0x1, %ecx
      9f:      	je	0x1ad <generic_usdt_setup_event+0x1ad>
      a5:      	cmpl	$0x2, %ecx
      a8:      	jne	0x242 <generic_usdt_setup_event+0x242>
      ae:      	movl	0x208(%r15), %edx
      b5:      	andl	$0xfff, %edx            # imm = 0xFFF
      bb:      	addq	%rbx, %rdx
      be:      	leaq	0x8(%rsp), %rdi
      c3:      	movl	$0x8, %ecx
      c8:      	movl	$0x71, %eax
      cd:      	movl	$0x8, %esi
      d2:      	callq	*%rax
      d4:      	testl	%eax, %eax
      d6:      	je	0x1b9 <generic_usdt_setup_event+0x1b9>
      dc:      	xorl	%eax, %eax
      de:      	jmp	0x242 <generic_usdt_setup_event+0x242>
      e3:      	cmpl	$0x3, %ecx
      e6:      	je	0x1e0 <generic_usdt_setup_event+0x1e0>
      ec:      	cmpl	$0x4, %ecx
      ef:      	jne	0x242 <generic_usdt_setup_event+0x242>
      f5:      	movl	0x208(%r15), %edx
      fc:      	andl	$0xfff, %edx            # imm = 0xFFF
     102:      	addq	%rbx, %rdx
     105:      	leaq	0x8(%rsp), %rdi
     10a:      	movl	$0x8, %ecx
     10f:      	movl	$0x71, %eax
     114:      	movl	$0x8, %esi
     119:      	callq	*%rax
     11b:      	testl	%eax, %eax
     11d:      	jne	0x240 <generic_usdt_setup_event+0x240>
     123:      	movl	0x20c(%r15), %edx
     12a:      	andl	$0xfff, %edx            # imm = 0xFFF
     130:      	addq	%rbx, %rdx
     133:      	leaq	0x10(%rsp), %rdi
     138:      	movl	$0x8, %ecx
     13d:      	movl	$0x71, %eax
     142:      	movl	$0x8, %esi
     147:      	callq	*%rax
     149:      	testl	%eax, %eax
     14b:      	jne	0x240 <generic_usdt_setup_event+0x240>
     151:      	movzbl	0x213(%r15), %eax
     159:      	shlxq	%rax, 0x10(%rsp), %rax
     160:      	movq	0x200(%r15), %rcx
     167:      	addq	0x8(%rsp), %rcx
     16c:      	addq	%rax, %rcx
     16f:      	leaq	0x8(%rsp), %rdi
     174:      	movl	$0x8, %edx
     179:      	movl	$0x70, %eax
     17e:      	movzbl	0x213(%r15), %ecx
     186:      	shlxq	%rcx, 0x10(%rsp), %rcx
     18d:      	movq	0x200(%r15), %rdx
     194:      	addq	0x8(%rsp), %rdx
     199:      	addq	%rcx, %rdx
     19c:      	movl	$0x8, %esi
     1a1:      	callq	*%rax
     1a3:      	testl	%eax, %eax
     1a5:      	jne	0x240 <generic_usdt_setup_event+0x240>
     1ab:      	jmp	0x1b9 <generic_usdt_setup_event+0x1b9>
     1ad:      	movq	0x200(%r15), %rax
     1b4:      	movq	%rax, 0x8(%rsp)
     1b9:      	movzbl	0x210(%r15), %eax
     1c1:      	shlxq	%rax, 0x8(%rsp), %rcx
     1c8:      	cmpb	$0x0, 0x212(%r15)
     1d0:      	shrxq	%rax, %rcx, %rdx
     1d5:      	sarxq	%rax, %rcx, %rax
     1da:      	cmoveq	%rdx, %rax
     1de:      	jmp	0x242 <generic_usdt_setup_event+0x242>
     1e0:      	movl	0x208(%r15), %edx
     1e7:      	andl	$0xfff, %edx            # imm = 0xFFF
     1ed:      	addq	%rbx, %rdx
     1f0:      	leaq	0x8(%rsp), %rdi
     1f5:      	movl	$0x8, %ecx
     1fa:      	movl	$0x71, %eax
     1ff:      	movl	$0x8, %esi
     204:      	callq	*%rax
     206:      	testl	%eax, %eax
     208:      	jne	0x240 <generic_usdt_setup_event+0x240>
     20a:      	movq	0x8(%rsp), %rcx
     20f:      	addq	0x200(%r15), %rcx
     216:      	leaq	0x8(%rsp), %rdi
     21b:      	movl	$0x8, %edx
     220:      	movl	$0x70, %eax
     225:      	movq	0x8(%rsp), %rdx
     22a:      	addq	0x200(%r15), %rdx
     231:      	movl	$0x8, %esi
     236:      	callq	*%rax
     238:      	testl	%eax, %eax
     23a:      	je	0x1b9 <generic_usdt_setup_event+0x1b9>
     240:      	cltq
     242:      	movq	%rax, 0x5e50(%r14)
     249:      	movzbl	0x229(%r15), %ecx
     251:      	xorl	%eax, %eax
     253:      	cmpl	$0x2, %ecx
     256:      	jg	0x29f <generic_usdt_setup_event+0x29f>
     258:      	cmpl	$0x1, %ecx
     25b:      	je	0x369 <generic_usdt_setup_event+0x369>
     261:      	cmpl	$0x2, %ecx
     264:      	jne	0x403 <generic_usdt_setup_event+0x403>
     26a:      	movl	0x220(%r15), %edx
     271:      	andl	$0xfff, %edx            # imm = 0xFFF
     277:      	addq	%rbx, %rdx
     27a:      	leaq	0x8(%rsp), %rdi
     27f:      	movl	$0x8, %ecx
     284:      	movl	$0x71, %eax
     289:      	movl	$0x8, %esi
     28e:      	callq	*%rax
     290:      	testl	%eax, %eax
     292:      	je	0x375 <generic_usdt_setup_event+0x375>
     298:      	xorl	%eax, %eax
     29a:      	jmp	0x403 <generic_usdt_setup_event+0x403>
     29f:      	cmpl	$0x3, %ecx
     2a2:      	je	0x3a1 <generic_usdt_setup_event+0x3a1>
     2a8:      	cmpl	$0x4, %ecx
     2ab:      	jne	0x403 <generic_usdt_setup_event+0x403>
     2b1:      	movl	0x220(%r15), %edx
     2b8:      	andl	$0xfff, %edx            # imm = 0xFFF
     2be:      	addq	%rbx, %rdx
     2c1:      	leaq	0x8(%rsp), %rdi
     2c6:      	movl	$0x8, %ecx
     2cb:      	movl	$0x71, %eax
     2d0:      	movl	$0x8, %esi
     2d5:      	callq	*%rax
     2d7:      	testl	%eax, %eax
     2d9:      	jne	0x401 <generic_usdt_setup_event+0x401>
     2df:      	movl	0x224(%r15), %edx
     2e6:      	andl	$0xfff, %edx            # imm = 0xFFF
     2ec:      	addq	%rbx, %rdx
     2ef:      	leaq	0x10(%rsp), %rdi
     2f4:      	movl	$0x8, %ecx
     2f9:      	movl	$0x71, %eax
     2fe:      	movl	$0x8, %esi
     303:      	callq	*%rax
     305:      	testl	%eax, %eax
     307:      	jne	0x401 <generic_usdt_setup_event+0x401>
     30d:      	movzbl	0x22b(%r15), %eax
     315:      	shlxq	%rax, 0x10(%rsp), %rax
     31c:      	movq	0x218(%r15), %rcx
     323:      	addq	0x8(%rsp), %rcx
     328:      	addq	%rax, %rcx
     32b:      	leaq	0x8(%rsp), %rdi
     330:      	movl	$0x8, %edx
     335:      	movl	$0x70, %eax
     33a:      	movzbl	0x22b(%r15), %ecx
     342:      	shlxq	%rcx, 0x10(%rsp), %rcx
     349:      	movq	0x218(%r15), %rdx
     350:      	addq	0x8(%rsp), %rdx
     355:      	addq	%rcx, %rdx
     358:      	movl	$0x8, %esi
     35d:      	callq	*%rax
     35f:      	testl	%eax, %eax
     361:      	jne	0x401 <generic_usdt_setup_event+0x401>
     367:      	jmp	0x375 <generic_usdt_setup_event+0x375>
     369:      	movq	0x218(%r15), %rax
     370:      	movq	%rax, 0x8(%rsp)
     375:      	movzbl	0x228(%r15), %eax
     37d:      	shlxq	%rax, 0x8(%rsp), %rcx
     384:      	movq	%rcx, 0x8(%rsp)
     389:      	cmpb	$0x0, 0x22a(%r15)
     391:      	shrxq	%rax, %rcx, %rdx
     396:      	sarxq	%rax, %rcx, %rax
     39b:      	cmoveq	%rdx, %rax
     39f:      	jmp	0x403 <generic_usdt_setup_event+0x403>
     3a1:      	movl	0x220(%r15), %edx
     3a8:      	andl	$0xfff, %edx            # imm = 0xFFF
     3ae:      	addq	%rbx, %rdx
     3b1:      	leaq	0x8(%rsp), %rdi
     3b6:      	movl	$0x8, %ecx
     3bb:      	movl	$0x71, %eax
     3c0:      	movl	$0x8, %esi
     3c5:      	callq	*%rax
     3c7:      	testl	%eax, %eax
     3c9:      	jne	0x401 <generic_usdt_setup_event+0x401>
     3cb:      	movq	0x8(%rsp), %rcx
     3d0:      	addq	0x218(%r15), %rcx
     3d7:      	leaq	0x8(%rsp), %rdi
     3dc:      	movl	$0x8, %edx
     3e1:      	movl	$0x70, %eax
     3e6:      	movq	0x8(%rsp), %rdx
     3eb:      	addq	0x218(%r15), %rdx
     3f2:      	movl	$0x8, %esi
     3f7:      	callq	*%rax
     3f9:      	testl	%eax, %eax
     3fb:      	je	0x375 <generic_usdt_setup_event+0x375>
     401:      	cltq
     403:      	movq	%rax, 0x5e58(%r14)
     40a:      	movzbl	0x241(%r15), %ecx
     412:      	xorl	%eax, %eax
     414:      	cmpl	$0x2, %ecx
     417:      	jg	0x460 <generic_usdt_setup_event+0x460>
     419:      	cmpl	$0x1, %ecx
     41c:      	je	0x52a <generic_usdt_setup_event+0x52a>
     422:      	cmpl	$0x2, %ecx
     425:      	jne	0x5c4 <generic_usdt_setup_event+0x5c4>
     42b:      	movl	0x238(%r15), %edx
     432:      	andl	$0xfff, %edx            # imm = 0xFFF
     438:      	addq	%rbx, %rdx
     43b:      	leaq	0x8(%rsp), %rdi
     440:      	movl	$0x8, %ecx
     445:      	movl	$0x71, %eax
     44a:      	movl	$0x8, %esi
     44f:      	callq	*%rax
     451:      	testl	%eax, %eax
     453:      	je	0x536 <generic_usdt_setup_event+0x536>
     459:      	xorl	%eax, %eax
     45b:      	jmp	0x5c4 <generic_usdt_setup_event+0x5c4>
     460:      	cmpl	$0x3, %ecx
     463:      	je	0x562 <generic_usdt_setup_event+0x562>
     469:      	cmpl	$0x4, %ecx
     46c:      	jne	0x5c4 <generic_usdt_setup_event+0x5c4>
     472:      	movl	0x238(%r15), %edx
     479:      	andl	$0xfff, %edx            # imm = 0xFFF
     47f:      	addq	%rbx, %rdx
     482:      	leaq	0x8(%rsp), %rdi
     487:      	movl	$0x8, %ecx
     48c:      	movl	$0x71, %eax
     491:      	movl	$0x8, %esi
     496:      	callq	*%rax
     498:      	testl	%eax, %eax
     49a:      	jne	0x5c2 <generic_usdt_setup_event+0x5c2>
     4a0:      	movl	0x23c(%r15), %edx
     4a7:      	andl	$0xfff, %edx            # imm = 0xFFF
     4ad:      	addq	%rbx, %rdx
     4b0:      	leaq	0x10(%rsp), %rdi
     4b5:      	movl	$0x8, %ecx
     4ba:      	movl	$0x71, %eax
     4bf:      	movl	$0x8, %esi
     4c4:      	callq	*%rax
     4c6:      	testl	%eax, %eax
     4c8:      	jne	0x5c2 <generic_usdt_setup_event+0x5c2>
     4ce:      	movzbl	0x243(%r15), %eax
     4d6:      	shlxq	%rax, 0x10(%rsp), %rax
     4dd:      	movq	0x230(%r15), %rcx
     4e4:      	addq	0x8(%rsp), %rcx
     4e9:      	addq	%rax, %rcx
     4ec:      	leaq	0x8(%rsp), %rdi
     4f1:      	movl	$0x8, %edx
     4f6:      	movl	$0x70, %eax
     4fb:      	movzbl	0x243(%r15), %ecx
     503:      	shlxq	%rcx, 0x10(%rsp), %rcx
     50a:      	movq	0x230(%r15), %rdx
     511:      	addq	0x8(%rsp), %rdx
     516:      	addq	%rcx, %rdx
     519:      	movl	$0x8, %esi
     51e:      	callq	*%rax
     520:      	testl	%eax, %eax
     522:      	jne	0x5c2 <generic_usdt_setup_event+0x5c2>
     528:      	jmp	0x536 <generic_usdt_setup_event+0x536>
     52a:      	movq	0x230(%r15), %rax
     531:      	movq	%rax, 0x8(%rsp)
     536:      	movzbl	0x240(%r15), %eax
     53e:      	shlxq	%rax, 0x8(%rsp), %rcx
     545:      	movq	%rcx, 0x8(%rsp)
     54a:      	cmpb	$0x0, 0x242(%r15)
     552:      	shrxq	%rax, %rcx, %rdx
     557:      	sarxq	%rax, %rcx, %rax
     55c:      	cmoveq	%rdx, %rax
     560:      	jmp	0x5c4 <generic_usdt_setup_event+0x5c4>
     562:      	movl	0x238(%r15), %edx
     569:      	andl	$0xfff, %edx            # imm = 0xFFF
     56f:      	addq	%rbx, %rdx
     572:      	leaq	0x8(%rsp), %rdi
     577:      	movl	$0x8, %ecx
     57c:      	movl	$0x71, %eax
     581:      	movl	$0x8, %esi
     586:      	callq	*%rax
     588:      	testl	%eax, %eax
     58a:      	jne	0x5c2 <generic_usdt_setup_event+0x5c2>
     58c:      	movq	0x8(%rsp), %rcx
     591:      	addq	0x230(%r15), %rcx
     598:      	leaq	0x8(%rsp), %rdi
     59d:      	movl	$0x8, %edx
     5a2:      	movl	$0x70, %eax
     5a7:      	movq	0x8(%rsp), %rdx
     5ac:      	addq	0x230(%r15), %rdx
     5b3:      	movl	$0x8, %esi
     5b8:      	callq	*%rax
     5ba:      	testl	%eax, %eax
     5bc:      	je	0x536 <generic_usdt_setup_event+0x536>
     5c2:      	cltq
     5c4:      	movq	%rax, 0x5e60(%r14)
     5cb:      	movzbl	0x259(%r15), %ecx
     5d3:      	xorl	%eax, %eax
     5d5:      	cmpl	$0x2, %ecx
     5d8:      	jg	0x621 <generic_usdt_setup_event+0x621>
     5da:      	cmpl	$0x1, %ecx
     5dd:      	je	0x6eb <generic_usdt_setup_event+0x6eb>
     5e3:      	cmpl	$0x2, %ecx
     5e6:      	jne	0x785 <generic_usdt_setup_event+0x785>
     5ec:      	movl	0x250(%r15), %edx
     5f3:      	andl	$0xfff, %edx            # imm = 0xFFF
     5f9:      	addq	%rbx, %rdx
     5fc:      	leaq	0x8(%rsp), %rdi
     601:      	movl	$0x8, %ecx
     606:      	movl	$0x71, %eax
     60b:      	movl	$0x8, %esi
     610:      	callq	*%rax
     612:      	testl	%eax, %eax
     614:      	je	0x6f7 <generic_usdt_setup_event+0x6f7>
     61a:      	xorl	%eax, %eax
     61c:      	jmp	0x785 <generic_usdt_setup_event+0x785>
     621:      	cmpl	$0x3, %ecx
     624:      	je	0x723 <generic_usdt_setup_event+0x723>
     62a:      	cmpl	$0x4, %ecx
     62d:      	jne	0x785 <generic_usdt_setup_event+0x785>
     633:      	movl	0x250(%r15), %edx
     63a:      	andl	$0xfff, %edx            # imm = 0xFFF
     640:      	addq	%rbx, %rdx
     643:      	leaq	0x8(%rsp), %rdi
     648:      	movl	$0x8, %ecx
     64d:      	movl	$0x71, %eax
     652:      	movl	$0x8, %esi
     657:      	callq	*%rax
     659:      	testl	%eax, %eax
     65b:      	jne	0x783 <generic_usdt_setup_event+0x783>
     661:      	movl	0x254(%r15), %edx
     668:      	andl	$0xfff, %edx            # imm = 0xFFF
     66e:      	addq	%rbx, %rdx
     671:      	leaq	0x10(%rsp), %rdi
     676:      	movl	$0x8, %ecx
     67b:      	movl	$0x71, %eax
     680:      	movl	$0x8, %esi
     685:      	callq	*%rax
     687:      	testl	%eax, %eax
     689:      	jne	0x783 <generic_usdt_setup_event+0x783>
     68f:      	movzbl	0x25b(%r15), %eax
     697:      	shlxq	%rax, 0x10(%rsp), %rax
     69e:      	movq	0x248(%r15), %rcx
     6a5:      	addq	0x8(%rsp), %rcx
     6aa:      	addq	%rax, %rcx
     6ad:      	leaq	0x8(%rsp), %rdi
     6b2:      	movl	$0x8, %edx
     6b7:      	movl	$0x70, %eax
     6bc:      	movzbl	0x25b(%r15), %ecx
     6c4:      	shlxq	%rcx, 0x10(%rsp), %rcx
     6cb:      	movq	0x248(%r15), %rdx
     6d2:      	addq	0x8(%rsp), %rdx
     6d7:      	addq	%rcx, %rdx
     6da:      	movl	$0x8, %esi
     6df:      	callq	*%rax
     6e1:      	testl	%eax, %eax
     6e3:      	jne	0x783 <generic_usdt_setup_event+0x783>
     6e9:      	jmp	0x6f7 <generic_usdt_setup_event+0x6f7>
     6eb:      	movq	0x248(%r15), %rax
     6f2:      	movq	%rax, 0x8(%rsp)
     6f7:      	movzbl	0x258(%r15), %eax
     6ff:      	shlxq	%rax, 0x8(%rsp), %rcx
     706:      	movq	%rcx, 0x8(%rsp)
     70b:      	cmpb	$0x0, 0x25a(%r15)
     713:      	shrxq	%rax, %rcx, %rdx
     718:      	sarxq	%rax, %rcx, %rax
     71d:      	cmoveq	%rdx, %rax
     721:      	jmp	0x785 <generic_usdt_setup_event+0x785>
     723:      	movl	0x250(%r15), %edx
     72a:      	andl	$0xfff, %edx            # imm = 0xFFF
     730:      	addq	%rbx, %rdx
     733:      	leaq	0x8(%rsp), %rdi
     738:      	movl	$0x8, %ecx
     73d:      	movl	$0x71, %eax
     742:      	movl	$0x8, %esi
     747:      	callq	*%rax
     749:      	testl	%eax, %eax
     74b:      	jne	0x783 <generic_usdt_setup_event+0x783>
     74d:      	movq	0x8(%rsp), %rcx
     752:      	addq	0x248(%r15), %rcx
     759:      	leaq	0x8(%rsp), %rdi
     75e:      	movl	$0x8, %edx
     763:      	movl	$0x70, %eax
     768:      	movq	0x8(%rsp), %rdx
     76d:      	addq	0x248(%r15), %rdx
     774:      	movl	$0x8, %esi
     779:      	callq	*%rax
     77b:      	testl	%eax, %eax
     77d:      	je	0x6f7 <generic_usdt_setup_event+0x6f7>
     783:      	cltq
     785:      	movq	%rax, 0x5e68(%r14)
     78c:      	movzbl	0x271(%r15), %ecx
     794:      	xorl	%eax, %eax
     796:      	cmpl	$0x2, %ecx
     799:      	jg	0x7e2 <generic_usdt_setup_event+0x7e2>
     79b:      	cmpl	$0x1, %ecx
     79e:      	je	0x8ac <generic_usdt_setup_event+0x8ac>
     7a4:      	cmpl	$0x2, %ecx
     7a7:      	jne	0x946 <generic_usdt_setup_event+0x946>
     7ad:      	movl	0x268(%r15), %edx
     7b4:      	andl	$0xfff, %edx            # imm = 0xFFF
     7ba:      	addq	%rbx, %rdx
     7bd:      	leaq	0x8(%rsp), %rdi
     7c2:      	movl	$0x8, %ecx
     7c7:      	movl	$0x71, %eax
     7cc:      	movl	$0x8, %esi
     7d1:      	callq	*%rax
     7d3:      	testl	%eax, %eax
     7d5:      	je	0x8b8 <generic_usdt_setup_event+0x8b8>
     7db:      	xorl	%eax, %eax
     7dd:      	jmp	0x946 <generic_usdt_setup_event+0x946>
     7e2:      	cmpl	$0x3, %ecx
     7e5:      	je	0x8e4 <generic_usdt_setup_event+0x8e4>
     7eb:      	cmpl	$0x4, %ecx
     7ee:      	jne	0x946 <generic_usdt_setup_event+0x946>
     7f4:      	movl	0x268(%r15), %edx
     7fb:      	andl	$0xfff, %edx            # imm = 0xFFF
     801:      	addq	%rbx, %rdx
     804:      	leaq	0x8(%rsp), %rdi
     809:      	movl	$0x8, %ecx
     80e:      	movl	$0x71, %eax
     813:      	movl	$0x8, %esi
     818:      	callq	*%rax
     81a:      	testl	%eax, %eax
     81c:      	jne	0x944 <generic_usdt_setup_event+0x944>
     822:      	movl	0x26c(%r15), %edx
     829:      	andl	$0xfff, %edx            # imm = 0xFFF
     82f:      	addq	%rbx, %rdx
     832:      	leaq	0x10(%rsp), %rdi
     837:      	movl	$0x8, %ecx
     83c:      	movl	$0x71, %eax
     841:      	movl	$0x8, %esi
     846:      	callq	*%rax
     848:      	testl	%eax, %eax
     84a:      	jne	0x944 <generic_usdt_setup_event+0x944>
     850:      	movzbl	0x273(%r15), %eax
     858:      	shlxq	%rax, 0x10(%rsp), %rax
     85f:      	movq	0x260(%r15), %rcx
     866:      	addq	0x8(%rsp), %rcx
     86b:      	addq	%rax, %rcx
     86e:      	leaq	0x8(%rsp), %rdi
     873:      	movl	$0x8, %edx
     878:      	movl	$0x70, %eax
     87d:      	movzbl	0x273(%r15), %ecx
     885:      	shlxq	%rcx, 0x10(%rsp), %rcx
     88c:      	movq	0x260(%r15), %rdx
     893:      	addq	0x8(%rsp), %rdx
     898:      	addq	%rcx, %rdx
     89b:      	movl	$0x8, %esi
     8a0:      	callq	*%rax
     8a2:      	testl	%eax, %eax
     8a4:      	jne	0x944 <generic_usdt_setup_event+0x944>
     8aa:      	jmp	0x8b8 <generic_usdt_setup_event+0x8b8>
     8ac:      	movq	0x260(%r15), %rax
     8b3:      	movq	%rax, 0x8(%rsp)
     8b8:      	movzbl	0x270(%r15), %eax
     8c0:      	shlxq	%rax, 0x8(%rsp), %rcx
     8c7:      	movq	%rcx, 0x8(%rsp)
     8cc:      	cmpb	$0x0, 0x272(%r15)
     8d4:      	shrxq	%rax, %rcx, %rdx
     8d9:      	sarxq	%rax, %rcx, %rax
     8de:      	cmoveq	%rdx, %rax
     8e2:      	jmp	0x946 <generic_usdt_setup_event+0x946>
     8e4:      	movl	0x268(%r15), %edx
     8eb:      	andl	$0xfff, %edx            # imm = 0xFFF
     8f1:      	addq	%rbx, %rdx
     8f4:      	leaq	0x8(%rsp), %rdi
     8f9:      	movl	$0x8, %ecx
     8fe:      	movl	$0x71, %eax
     903:      	movl	$0x8, %esi
     908:      	callq	*%rax
     90a:      	testl	%eax, %eax
     90c:      	jne	0x944 <generic_usdt_setup_event+0x944>
     90e:      	movq	0x8(%rsp), %rcx
     913:      	addq	0x260(%r15), %rcx
     91a:      	leaq	0x8(%rsp), %rdi
     91f:      	movl	$0x8, %edx
     924:      	movl	$0x70, %eax
     929:      	movq	0x8(%rsp), %rdx
     92e:      	addq	0x260(%r15), %rdx
     935:      	movl	$0x8, %esi
     93a:      	callq	*%rax
     93c:      	testl	%eax, %eax
     93e:      	je	0x8b8 <generic_usdt_setup_event+0x8b8>
     944:      	cltq
     946:      	movq	%rax, 0x5e70(%r14)
     94d:      	movl	$0x0, 0x8(%rsp)
     955:      	movq	(%rip), %rdi            # 0x95c <generic_usdt_setup_event+0x95c>
     95c:      	leaq	0x8(%rsp), %rsi
     961:      	movl	$0x1, %eax
     966:      	callq	*%rax
     968:      	testq	%rax, %rax
     96b:      	je	0x990 <generic_usdt_setup_event+0x990>
     96d:      	movq	%rax, %rsi
     970:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
     977:      	movq	(%rip), %rdi            # 0x97e <generic_usdt_setup_event+0x97e>
     97e:      	movl	$0x1, %eax
     983:      	callq	*%rax
     985:      	testq	%rax, %rax
     988:      	je	0x990 <generic_usdt_setup_event+0x990>
     98a:      	cmpl	$-0x1, 0x40(%rax)
     98e:      	jne	0x9ab <generic_usdt_setup_event+0x9ab>
     990:      	movq	(%rip), %rsi            # 0x997 <generic_usdt_setup_event+0x997>
     997:      	movl	$0x3, %ecx
     99c:      	movl	$0xc, %eax
     9a1:      	movq	%rbx, %rdi
     9a4:      	movl	$0x3, %edx
     9a9:      	callq	*%rax
     9ab:      	movq	(%rip), %rsi            # 0x9b2 <generic_usdt_setup_event+0x9b2>
     9b2:      	movl	$0x1, %ecx
     9b7:      	movl	$0xc, %eax
     9bc:      	movq	%rbx, %rdi
     9bf:      	movl	$0x1, %edx
     9c4:      	callq	*%rax
     9c6:      	xorl	%eax, %eax
     9c8:      	addq	$0x20, %rsp
     9cc:      	popq	%rbx
     9cd:      	popq	%r14
     9cf:      	popq	%r15
     9d1:      	retq
     9d2:      	nopw	%cs:(%rax,%rax)

00000000000009e0 <generic_usdt_process_event>:
     9e0:      	pushq	%rbp
     9e1:      	pushq	%r15
     9e3:      	pushq	%r14
     9e5:      	pushq	%r13
     9e7:      	pushq	%r12
     9e9:      	pushq	%rbx
     9ea:      	subq	$0x108, %rsp            # imm = 0x108
     9f1:      	movq	%rdi, %r12
     9f4:      	movl	$0x0, 0xec(%rsp)
     9ff:      	movq	(%rip), %rdi            # 0xa06 <generic_usdt_process_event+0x26>
     a06:      	leaq	0xec(%rsp), %rsi
     a0e:      	movl	$0x1, %eax
     a13:      	callq	*%rax
     a15:      	testq	%rax, %rax
     a18:      	je	0x2cb8 <generic_usdt_process_event+0x22d8>
     a1e:      	movq	%rax, %r14
     a21:      	movl	0x5efc(%rax), %ebp
     a27:      	movl	0x4(%rax), %r13d
     a2b:      	cmpq	$0x2327, %r13           # imm = 0x2327
     a32:      	ja	0x1079 <generic_usdt_process_event+0x699>
     a38:      	movl	$0x0, 0xf0(%rsp)
     a43:      	movq	(%rip), %rdi            # 0xa4a <generic_usdt_process_event+0x6a>
     a4a:      	leaq	0xf0(%rsp), %rsi
     a52:      	movl	$0x1, %eax
     a57:      	callq	*%rax
     a59:      	testq	%rax, %rax
     a5c:      	je	0x1079 <generic_usdt_process_event+0x699>
     a62:      	movq	%rax, %r15
     a65:      	leaq	0x5ef8(%rax), %rsi
     a6c:      	movq	(%rip), %rdi            # 0xa73 <generic_usdt_process_event+0x93>
     a73:      	movl	$0x1, %eax
     a78:      	callq	*%rax
     a7a:      	cmpl	$0x4, %ebp
     a7d:      	jg	0x1079 <generic_usdt_process_event+0x699>
     a83:      	testq	%rax, %rax
     a86:      	je	0x1079 <generic_usdt_process_event+0x699>
     a8c:      	movq	%r12, 0xa8(%rsp)
     a94:      	movq	%rbp, 0x30(%rsp)
     a99:      	movl	%ebp, %ebx
     a9b:      	andl	$0x7, %ebx
     a9e:      	movl	%ebx, %ecx
     aa0:      	movl	0x4(%rax,%rcx,4), %r12d
     aa5:      	movslq	0x18(%rax,%rcx,4), %rdx
     aaa:      	movl	$0x0, 0x5ea0(%r15,%rcx,4)
     ab6:      	movq	0x5e50(%r15,%rcx,8), %rcx
     abe:      	movq	%rcx, 0x10(%rsp)
     ac3:      	movq	%rdx, 0x8(%rsp)
     ac8:      	testl	$0x100, %edx            # imm = 0x100
     ace:      	movq	%r13, 0xc0(%rsp)
     ad6:      	jne	0xde6 <generic_usdt_process_event+0x406>
     adc:      	movq	%rbx, %rbp
     adf:      	cmpl	$0x4, %ebx
     ae2:      	ja	0xe52 <generic_usdt_process_event+0x472>
     ae8:      	leaq	(,%rbp,4), %rdx
     af0:      	addq	%rbp, %rdx
     af3:      	shll	$0x4, %edx
     af6:      	cmpw	$0x0, 0x76(%rax,%rdx)
     afc:      	je	0xe52 <generic_usdt_process_event+0x472>
     b02:      	leaq	(%rax,%rdx), %r13
     b06:      	addq	$0x70, %r13
     b0a:      	movl	(%r13), %eax
     b0e:      	addq	%rax, %rcx
     b11:      	movq	%rcx, 0x10(%rsp)
     b16:      	cmpw	$0x0, 0x4(%r13)
     b1c:      	je	0xb46 <generic_usdt_process_event+0x166>
     b1e:      	leaq	0x10(%rsp), %rdi
     b23:      	movl	$0x8, %edx
     b28:      	movl	$0x4, %eax
     b2d:      	movq	0x10(%rsp), %rdx
     b32:      	movl	$0x8, %esi
     b37:      	callq	*%rax
     b39:      	movl	$0x1, %ebx
     b3e:      	testl	%eax, %eax
     b40:      	js	0xddc <generic_usdt_process_event+0x3fc>
     b46:      	cmpw	$0x0, 0xe(%r13)
     b4c:      	je	0xe52 <generic_usdt_process_event+0x472>
     b52:      	movl	0x8(%r13), %ecx
     b56:      	addq	0x10(%rsp), %rcx
     b5b:      	movq	%rcx, 0x10(%rsp)
     b60:      	cmpw	$0x0, 0xc(%r13)
     b66:      	je	0xb90 <generic_usdt_process_event+0x1b0>
     b68:      	leaq	0x10(%rsp), %rdi
     b6d:      	movl	$0x8, %edx
     b72:      	movl	$0x4, %eax
     b77:      	movq	0x10(%rsp), %rdx
     b7c:      	movl	$0x8, %esi
     b81:      	callq	*%rax
     b83:      	movl	$0x2, %ebx
     b88:      	testl	%eax, %eax
     b8a:      	js	0xddc <generic_usdt_process_event+0x3fc>
     b90:      	cmpw	$0x0, 0x16(%r13)
     b96:      	je	0xe52 <generic_usdt_process_event+0x472>
     b9c:      	movl	0x10(%r13), %ecx
     ba0:      	addq	0x10(%rsp), %rcx
     ba5:      	movq	%rcx, 0x10(%rsp)
     baa:      	cmpw	$0x0, 0x14(%r13)
     bb0:      	je	0xbda <generic_usdt_process_event+0x1fa>
     bb2:      	leaq	0x10(%rsp), %rdi
     bb7:      	movl	$0x8, %edx
     bbc:      	movl	$0x4, %eax
     bc1:      	movq	0x10(%rsp), %rdx
     bc6:      	movl	$0x8, %esi
     bcb:      	callq	*%rax
     bcd:      	movl	$0x3, %ebx
     bd2:      	testl	%eax, %eax
     bd4:      	js	0xddc <generic_usdt_process_event+0x3fc>
     bda:      	cmpw	$0x0, 0x1e(%r13)
     be0:      	je	0xe52 <generic_usdt_process_event+0x472>
     be6:      	movl	0x18(%r13), %ecx
     bea:      	addq	0x10(%rsp), %rcx
     bef:      	movq	%rcx, 0x10(%rsp)
     bf4:      	cmpw	$0x0, 0x1c(%r13)
     bfa:      	je	0xc24 <generic_usdt_process_event+0x244>
     bfc:      	leaq	0x10(%rsp), %rdi
     c01:      	movl	$0x8, %edx
     c06:      	movl	$0x4, %eax
     c0b:      	movq	0x10(%rsp), %rdx
     c10:      	movl	$0x8, %esi
     c15:      	callq	*%rax
     c17:      	movl	$0x4, %ebx
     c1c:      	testl	%eax, %eax
     c1e:      	js	0xddc <generic_usdt_process_event+0x3fc>
     c24:      	cmpw	$0x0, 0x26(%r13)
     c2a:      	je	0xe52 <generic_usdt_process_event+0x472>
     c30:      	movl	0x20(%r13), %ecx
     c34:      	addq	0x10(%rsp), %rcx
     c39:      	movq	%rcx, 0x10(%rsp)
     c3e:      	cmpw	$0x0, 0x24(%r13)
     c44:      	je	0xc6e <generic_usdt_process_event+0x28e>
     c46:      	leaq	0x10(%rsp), %rdi
     c4b:      	movl	$0x8, %edx
     c50:      	movl	$0x4, %eax
     c55:      	movq	0x10(%rsp), %rdx
     c5a:      	movl	$0x8, %esi
     c5f:      	callq	*%rax
     c61:      	movl	$0x5, %ebx
     c66:      	testl	%eax, %eax
     c68:      	js	0xddc <generic_usdt_process_event+0x3fc>
     c6e:      	cmpw	$0x0, 0x2e(%r13)
     c74:      	je	0xe52 <generic_usdt_process_event+0x472>
     c7a:      	movl	0x28(%r13), %ecx
     c7e:      	addq	0x10(%rsp), %rcx
     c83:      	movq	%rcx, 0x10(%rsp)
     c88:      	cmpw	$0x0, 0x2c(%r13)
     c8e:      	je	0xcb8 <generic_usdt_process_event+0x2d8>
     c90:      	leaq	0x10(%rsp), %rdi
     c95:      	movl	$0x8, %edx
     c9a:      	movl	$0x4, %eax
     c9f:      	movq	0x10(%rsp), %rdx
     ca4:      	movl	$0x8, %esi
     ca9:      	callq	*%rax
     cab:      	movl	$0x6, %ebx
     cb0:      	testl	%eax, %eax
     cb2:      	js	0xddc <generic_usdt_process_event+0x3fc>
     cb8:      	cmpw	$0x0, 0x36(%r13)
     cbe:      	je	0xe52 <generic_usdt_process_event+0x472>
     cc4:      	movl	0x30(%r13), %ecx
     cc8:      	addq	0x10(%rsp), %rcx
     ccd:      	movq	%rcx, 0x10(%rsp)
     cd2:      	cmpw	$0x0, 0x34(%r13)
     cd8:      	je	0xd02 <generic_usdt_process_event+0x322>
     cda:      	leaq	0x10(%rsp), %rdi
     cdf:      	movl	$0x8, %edx
     ce4:      	movl	$0x4, %eax
     ce9:      	movq	0x10(%rsp), %rdx
     cee:      	movl	$0x8, %esi
     cf3:      	callq	*%rax
     cf5:      	movl	$0x7, %ebx
     cfa:      	testl	%eax, %eax
     cfc:      	js	0xddc <generic_usdt_process_event+0x3fc>
     d02:      	cmpw	$0x0, 0x3e(%r13)
     d08:      	je	0xe52 <generic_usdt_process_event+0x472>
     d0e:      	movl	0x38(%r13), %ecx
     d12:      	addq	0x10(%rsp), %rcx
     d17:      	movq	%rcx, 0x10(%rsp)
     d1c:      	cmpw	$0x0, 0x3c(%r13)
     d22:      	je	0xd4c <generic_usdt_process_event+0x36c>
     d24:      	leaq	0x10(%rsp), %rdi
     d29:      	movl	$0x8, %edx
     d2e:      	movl	$0x4, %eax
     d33:      	movq	0x10(%rsp), %rdx
     d38:      	movl	$0x8, %ebx
     d3d:      	movl	$0x8, %esi
     d42:      	callq	*%rax
     d44:      	testl	%eax, %eax
     d46:      	js	0xddc <generic_usdt_process_event+0x3fc>
     d4c:      	cmpw	$0x0, 0x46(%r13)
     d52:      	je	0xe52 <generic_usdt_process_event+0x472>
     d58:      	movl	0x40(%r13), %ecx
     d5c:      	addq	0x10(%rsp), %rcx
     d61:      	movq	%rcx, 0x10(%rsp)
     d66:      	cmpw	$0x0, 0x44(%r13)
     d6c:      	je	0xd92 <generic_usdt_process_event+0x3b2>
     d6e:      	leaq	0x10(%rsp), %rdi
     d73:      	movl	$0x8, %edx
     d78:      	movl	$0x4, %eax
     d7d:      	movq	0x10(%rsp), %rdx
     d82:      	movl	$0x8, %esi
     d87:      	callq	*%rax
     d89:      	movl	$0x9, %ebx
     d8e:      	testl	%eax, %eax
     d90:      	js	0xddc <generic_usdt_process_event+0x3fc>
     d92:      	cmpw	$0x0, 0x4e(%r13)
     d98:      	je	0xe52 <generic_usdt_process_event+0x472>
     d9e:      	movl	0x48(%r13), %ecx
     da2:      	addq	0x10(%rsp), %rcx
     da7:      	movq	%rcx, 0x10(%rsp)
     dac:      	cmpw	$0x0, 0x4c(%r13)
     db2:      	je	0xe52 <generic_usdt_process_event+0x472>
     db8:      	leaq	0x10(%rsp), %rdi
     dbd:      	movl	$0x8, %edx
     dc2:      	movl	$0x4, %eax
     dc7:      	movq	0x10(%rsp), %rdx
     dcc:      	movl	$0x8, %esi
     dd1:      	callq	*%rax
     dd3:      	movl	$0xa, %ebx
     dd8:      	testl	%eax, %eax
     dda:      	jns	0xe52 <generic_usdt_process_event+0x472>
     ddc:      	movl	%ebx, 0x5ea0(%r15,%rbp,4)
     de4:      	jmp	0xe52 <generic_usdt_process_event+0x472>
     de6:      	movq	$0x0, 0x60(%rsp)
     def:      	movl	$0xe, %eax
     df4:      	callq	*%rax
     df6:      	movq	%rax, 0x50(%rsp)
     dfb:      	movq	(%rip), %rdi            # 0xe02 <generic_usdt_process_event+0x422>
     e02:      	leaq	0x50(%rsp), %rsi
     e07:      	movl	$0x1, %eax
     e0c:      	callq	*%rax
     e0e:      	testq	%rax, %rax
     e11:      	je	0xe45 <generic_usdt_process_event+0x465>
     e13:      	movl	(%rax), %ecx
     e15:      	movl	%ecx, 0x5ea0(%r15,%rbx,4)
     e1d:      	cmpl	$0x6, %r12d
     e21:      	jne	0xe45 <generic_usdt_process_event+0x465>
     e23:      	addq	$0x4, %rax
     e27:      	movq	%rax, 0x60(%rsp)
     e2c:      	leaq	0x60(%rsp), %rdi
     e31:      	movl	$0x8, %ecx
     e36:      	movl	$0x4, %eax
     e3b:      	movl	$0x8, %esi
     e40:      	movq	%rdi, %rdx
     e43:      	callq	*%rax
     e45:      	movq	%rbx, %rbp
     e48:      	movq	0x60(%rsp), %rax
     e4d:      	movq	%rax, 0x10(%rsp)
     e52:      	movl	$0x1fe, %ebx            # imm = 0x1FE
     e57:      	movq	0x10(%rsp), %r15
     e5c:      	cmpl	$0x15, %r12d
     e60:      	jg	0xea1 <generic_usdt_process_event+0x4c1>
     e62:      	cmpl	$0xb, %r12d
     e66:      	movq	0xc0(%rsp), %r13
     e6e:      	jg	0xed6 <generic_usdt_process_event+0x4f6>
     e70:      	cmpl	$0x5, %r12d
     e74:      	jg	0xf2e <generic_usdt_process_event+0x54e>
     e7a:      	cmpl	$0x3, %r12d
     e7e:      	jg	0xfb5 <generic_usdt_process_event+0x5d5>
     e84:      	leal	-0x2(%r12), %eax
     e89:      	cmpl	$0x2, %eax
     e8c:      	jb	0xf9b <generic_usdt_process_event+0x5bb>
     e92:      	cmpl	$0x1, %r12d
     e96:      	je	0xf9b <generic_usdt_process_event+0x5bb>
     e9c:      	jmp	0xffd <generic_usdt_process_event+0x61d>
     ea1:      	cmpl	$0x20, %r12d
     ea5:      	movq	0xc0(%rsp), %r13
     ead:      	jle	0xf01 <generic_usdt_process_event+0x521>
     eaf:      	cmpl	$0x26, %r12d
     eb3:      	jg	0xf57 <generic_usdt_process_event+0x577>
     eb9:      	leal	-0x21(%r12), %eax
     ebe:      	cmpl	$0x4, %eax
     ec1:      	jb	0xfc8 <generic_usdt_process_event+0x5e8>
     ec7:      	cmpl	$0x25, %r12d
     ecb:      	je	0xfff <generic_usdt_process_event+0x61f>
     ed1:      	jmp	0xffd <generic_usdt_process_event+0x61d>
     ed6:      	cmpl	$0x11, %r12d
     eda:      	jg	0xf78 <generic_usdt_process_event+0x598>
     ee0:      	leal	-0xf(%r12), %eax
     ee5:      	cmpl	$0x3, %eax
     ee8:      	jb	0xfff <generic_usdt_process_event+0x61f>
     eee:      	leal	-0xc(%r12), %eax
     ef3:      	cmpl	$0x2, %eax
     ef6:      	jb	0xf9b <generic_usdt_process_event+0x5bb>
     efc:      	jmp	0xffd <generic_usdt_process_event+0x61d>
     f01:      	cmpl	$0x1a, %r12d
     f05:      	jg	0xf91 <generic_usdt_process_event+0x5b1>
     f0b:      	cmpl	$0x16, %r12d
     f0f:      	je	0xfe2 <generic_usdt_process_event+0x602>
     f15:      	cmpl	$0x17, %r12d
     f19:      	je	0xfc8 <generic_usdt_process_event+0x5e8>
     f1f:      	cmpl	$0x1a, %r12d
     f23:      	je	0xff6 <generic_usdt_process_event+0x616>
     f29:      	jmp	0xffd <generic_usdt_process_event+0x61d>
     f2e:      	cmpl	$0x9, %r12d
     f32:      	jg	0xfc8 <generic_usdt_process_event+0x5e8>
     f38:      	cmpl	$0x6, %r12d
     f3c:      	je	0xfff <generic_usdt_process_event+0x61f>
     f42:      	cmpl	$0x7, %r12d
     f46:      	je	0xfc1 <generic_usdt_process_event+0x5e1>
     f48:      	cmpl	$0x8, %r12d
     f4c:      	je	0xff6 <generic_usdt_process_event+0x616>
     f52:      	jmp	0xffd <generic_usdt_process_event+0x61d>
     f57:      	cmpl	$0x28, %r12d
     f5b:      	jle	0xfcf <generic_usdt_process_event+0x5ef>
     f5d:      	cmpl	$0x29, %r12d
     f61:      	je	0xfc1 <generic_usdt_process_event+0x5e1>
     f63:      	cmpl	$0x2a, %r12d
     f67:      	je	0xfff <generic_usdt_process_event+0x61f>
     f6d:      	cmpl	$0x2b, %r12d
     f71:      	je	0xfdb <generic_usdt_process_event+0x5fb>
     f73:      	jmp	0xffd <generic_usdt_process_event+0x61d>
     f78:      	cmpl	$0x13, %r12d
     f7c:      	jg	0xfa2 <generic_usdt_process_event+0x5c2>
     f7e:      	movq	0x8(%rsp), %rbx
     f83:      	cmpl	$0x12, %r12d
     f87:      	je	0xfff <generic_usdt_process_event+0x61f>
     f89:      	cmpl	$0x13, %r12d
     f8d:      	je	0xfdb <generic_usdt_process_event+0x5fb>
     f8f:      	jmp	0xffd <generic_usdt_process_event+0x61d>
     f91:      	leal	-0x1d(%r12), %eax
     f96:      	cmpl	$0x4, %eax
     f99:      	jae	0xff0 <generic_usdt_process_event+0x610>
     f9b:      	movl	$0x4, %ebx
     fa0:      	jmp	0xfff <generic_usdt_process_event+0x61f>
     fa2:      	cmpl	$0x14, %r12d
     fa6:      	je	0xfe9 <generic_usdt_process_event+0x609>
     fa8:      	cmpl	$0x15, %r12d
     fac:      	jne	0xffd <generic_usdt_process_event+0x61d>
     fae:      	movl	$0x20, %ebx
     fb3:      	jmp	0xfff <generic_usdt_process_event+0x61f>
     fb5:      	cmpl	$0x4, %r12d
     fb9:      	je	0xfc8 <generic_usdt_process_event+0x5e8>
     fbb:      	cmpl	$0x5, %r12d
     fbf:      	jne	0xffd <generic_usdt_process_event+0x61d>
     fc1:      	movl	$0x40, %ebx
     fc6:      	jmp	0xfff <generic_usdt_process_event+0x61f>
     fc8:      	movl	$0x8, %ebx
     fcd:      	jmp	0xfff <generic_usdt_process_event+0x61f>
     fcf:      	cmpl	$0x27, %r12d
     fd3:      	je	0xfe2 <generic_usdt_process_event+0x602>
     fd5:      	cmpl	$0x28, %r12d
     fd9:      	jne	0xffd <generic_usdt_process_event+0x61d>
     fdb:      	movl	$0x18, %ebx
     fe0:      	jmp	0xfff <generic_usdt_process_event+0x61f>
     fe2:      	movl	$0x10, %ebx
     fe7:      	jmp	0xfff <generic_usdt_process_event+0x61f>
     fe9:      	movl	$0x98, %ebx
     fee:      	jmp	0xfff <generic_usdt_process_event+0x61f>
     ff0:      	cmpl	$0x1b, %r12d
     ff4:      	jne	0xffd <generic_usdt_process_event+0x61d>
     ff6:      	movl	$0x50, %ebx
     ffb:      	jmp	0xfff <generic_usdt_process_event+0x61f>
     ffd:      	xorl	%ebx, %ebx
     fff:      	movl	$0x0, 0xf4(%rsp)
    100a:      	movq	(%rip), %rdi            # 0x1011 <generic_usdt_process_event+0x631>
    1011:      	leaq	0xf4(%rsp), %rsi
    1019:      	movl	$0x1, %eax
    101e:      	callq	*%rax
    1020:      	testq	%rax, %rax
    1023:      	je	0x106c <generic_usdt_process_event+0x68c>
    1025:      	movl	$0x3ffb, %ecx           # imm = 0x3FFB
    102a:      	subq	%rbx, %rcx
    102d:      	cmpq	%r13, %rcx
    1030:      	jbe	0x106c <generic_usdt_process_event+0x68c>
    1032:      	movl	0x5ea0(%rax,%rbp,4), %ecx
    1039:      	movl	%ecx, 0x90(%rax,%r13)
    1041:      	leaq	0x4(%r13), %rsi
    1045:      	movq	%rsi, 0x5e78(%rax,%rbp,8)
    104d:      	movl	$0x4, %edx
    1052:      	testl	%ecx, %ecx
    1054:      	je	0x1104 <generic_usdt_process_event+0x724>
    105a:      	movq	0xa8(%rsp), %r12
    1062:      	movq	0x30(%rsp), %rbp
    1067:      	jmp	0x2c7f <generic_usdt_process_event+0x229f>
    106c:      	movq	0xa8(%rsp), %r12
    1074:      	movq	0x30(%rsp), %rbp
    1079:      	movl	%r13d, 0x4(%r14)
    107d:      	cmpl	$0x3, %ebp
    1080:      	jg	0x2c92 <generic_usdt_process_event+0x22b2>
    1086:      	movl	$0x0, 0x60(%rsp)
    108e:      	movq	(%rip), %rdi            # 0x1095 <generic_usdt_process_event+0x6b5>
    1095:      	leaq	0x60(%rsp), %rsi
    109a:      	movl	$0x1, %eax
    109f:      	callq	*%rax
    10a1:      	testq	%rax, %rax
    10a4:      	je	0x2c92 <generic_usdt_process_event+0x22b2>
    10aa:      	movq	%rax, %rsi
    10ad:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    10b4:      	movq	(%rip), %rdi            # 0x10bb <generic_usdt_process_event+0x6db>
    10bb:      	movl	$0x1, %eax
    10c0:      	callq	*%rax
    10c2:      	testq	%rax, %rax
    10c5:      	je	0x2c92 <generic_usdt_process_event+0x22b2>
    10cb:      	incl	%ebp
    10cd:      	movl	%ebp, %ecx
    10cf:      	andl	$0x7, %ecx
    10d2:      	cmpl	$-0x1, 0x40(%rax,%rcx,4)
    10d7:      	je	0x2c92 <generic_usdt_process_event+0x22b2>
    10dd:      	movl	%ebp, 0x5efc(%r14)
    10e4:      	movq	(%rip), %rsi            # 0x10eb <generic_usdt_process_event+0x70b>
    10eb:      	movl	$0x1, %ecx
    10f0:      	movl	$0xc, %eax
    10f5:      	movq	%r12, %rdi
    10f8:      	movl	$0x1, %edx
    10fd:      	callq	*%rax
    10ff:      	jmp	0x2c92 <generic_usdt_process_event+0x22b2>
    1104:      	movq	%rax, %rbx
    1107:      	addq	$0x90, %rbx
    110e:      	addq	%rsi, %rbx
    1111:      	movq	%r15, 0x60(%rsp)
    1116:      	movq	$0x0, 0x50(%rsp)
    111f:      	cmpl	$0x17, %r12d
    1123:      	movq	%rax, (%rsp)
    1127:      	jle	0x1164 <generic_usdt_process_event+0x784>
    1129:      	cmpl	$0x18, %r12d
    112d:      	je	0x117f <generic_usdt_process_event+0x79f>
    112f:      	cmpl	$0x25, %r12d
    1133:      	je	0x11c0 <generic_usdt_process_event+0x7e0>
    1139:      	cmpl	$0x2a, %r12d
    113d:      	jne	0x1773 <generic_usdt_process_event+0xd93>
    1143:      	movq	$0x0, 0xf8(%rsp)
    114f:      	movq	%r15, 0x100(%rsp)
    1157:      	leaq	0xf8(%rsp), %r15
    115f:      	jmp	0x11ed <generic_usdt_process_event+0x80d>
    1164:      	cmpl	$0xf, %r12d
    1168:      	je	0x16b2 <generic_usdt_process_event+0xcd2>
    116e:      	cmpl	$0x10, %r12d
    1172:      	jne	0x1773 <generic_usdt_process_event+0xd93>
    1178:      	leaq	0x40(%rsp), %r15
    117d:      	jmp	0x11aa <generic_usdt_process_event+0x7ca>
    117f:      	movq	%r15, %rdx
    1182:      	leaq	0x40(%rsp), %r15
    1187:      	movl	$0x8, %ecx
    118c:      	movl	$0x4, %eax
    1191:      	movq	0x60(%rsp), %rdx
    1196:      	movq	%r15, %rdi
    1199:      	movl	$0x8, %esi
    119e:      	callq	*%rax
    11a0:      	movq	0x40(%rsp), %rax
    11a5:      	movq	%rax, 0x60(%rsp)
    11aa:      	leaq	0x60(%rsp), %rdx
    11af:      	movl	$0x8, %ecx
    11b4:      	movl	$0x4, %eax
    11b9:      	leaq	0x40(%rsp), %rdi
    11be:      	jmp	0x11dd <generic_usdt_process_event+0x7fd>
    11c0:      	addq	$0x40, %r15
    11c4:      	movq	%r15, 0x60(%rsp)
    11c9:      	leaq	0x40(%rsp), %rdi
    11ce:      	movl	$0x8, %ecx
    11d3:      	movl	$0x4, %eax
    11d8:      	movq	0x60(%rsp), %rdx
    11dd:      	movl	$0x8, %esi
    11e2:      	callq	*%rax
    11e4:      	movq	0x40(%rsp), %r15
    11e9:      	addq	$0x40, %r15
    11ed:      	movl	$0x0, 0xa0(%rsp)
    11f8:      	movq	(%rip), %rdi            # 0x11ff <generic_usdt_process_event+0x81f>
    11ff:      	leaq	0xa0(%rsp), %rsi
    1207:      	movl	$0x1, %eax
    120c:      	callq	*%rax
    120e:      	testq	%rax, %rax
    1211:      	je	0x12c2 <generic_usdt_process_event+0x8e2>
    1217:      	movq	%rax, %r12
    121a:      	movq	%rbx, 0x20(%rsp)
    121f:      	movq	%rbp, 0xe0(%rsp)
    1227:      	addq	$0x1000, %rax           # imm = 0x1000
    122d:      	movq	%rax, 0x8(%rsp)
    1232:      	movl	$0x23, %eax
    1237:      	callq	*%rax
    1239:      	leaq	0xd50(%rax), %rdx
    1240:      	leaq	0xd0(%rsp), %rdi
    1248:      	movl	$0x8, %ecx
    124d:      	movl	$0x4, %eax
    1252:      	movl	$0x8, %esi
    1257:      	callq	*%rax
    1259:      	movq	0xd0(%rsp), %rbp
    1261:      	leaq	0x8(%r15), %rdx
    1265:      	leaq	0xb8(%rsp), %rdi
    126d:      	movl	$0x8, %ecx
    1272:      	movl	$0x4, %eax
    1277:      	leaq	0x18(%rbp), %rcx
    127b:      	movq	%rcx, 0x18(%rsp)
    1280:      	movl	$0x8, %esi
    1285:      	movq	%rdx, 0x28(%rsp)
    128a:      	callq	*%rax
    128c:      	movq	0xb8(%rsp), %r13
    1294:      	leaq	0x10(%r13), %rdx
    1298:      	leaq	0x60(%rsp), %rdi
    129d:      	movl	$0x8, %ecx
    12a2:      	movl	$0x4, %eax
    12a7:      	movl	$0x8, %esi
    12ac:      	callq	*%rax
    12ae:      	cmpq	$0x0, 0x60(%rsp)
    12b4:      	movl	$0x1000, %ebx           # imm = 0x1000
    12b9:      	je	0x12d7 <generic_usdt_process_event+0x8f7>
    12bb:      	movq	0x8(%rsp), %rcx
    12c0:      	jmp	0x1329 <generic_usdt_process_event+0x949>
    12c2:      	xorl	%r13d, %r13d
    12c5:      	movq	0xa8(%rsp), %r12
    12cd:      	movq	0x30(%rsp), %rbp
    12d2:      	jmp	0x2c48 <generic_usdt_process_event+0x2268>
    12d7:      	leaq	0x18(%r13), %rdx
    12db:      	leaq	0x60(%rsp), %rdi
    12e0:      	movl	$0x8, %ecx
    12e5:      	movl	$0x4, %eax
    12ea:      	movl	$0x8, %esi
    12ef:      	callq	*%rax
    12f1:      	cmpq	%r13, 0x60(%rsp)
    12f6:      	movq	0x8(%rsp), %rcx
    12fb:      	je	0x1329 <generic_usdt_process_event+0x949>
    12fd:      	movq	%r12, %rcx
    1300:      	addq	$0xff6, %rcx            # imm = 0xFF6
    1307:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    1311:      	movq	%rax, 0xff6(%r12)
    1319:      	movw	$0x2964, 0xffe(%r12)    # imm = 0x2964
    1324:      	movl	$0xff6, %ebx            # imm = 0xFF6
    1329:      	movq	$0x0, 0x68(%rsp)
    1332:      	movq	$0x0, 0x60(%rsp)
    133b:      	movq	%r12, 0x70(%rsp)
    1340:      	movq	$0x0, 0x78(%rsp)
    1349:      	movq	$0x0, 0x80(%rsp)
    1355:      	movq	$0x0, 0x88(%rsp)
    1361:      	movq	%rcx, 0x8(%rsp)
    1366:      	movq	%rcx, 0x90(%rsp)
    136e:      	movl	%ebx, 0x98(%rsp)
    1375:      	movb	$0x0, 0x9c(%rsp)
    137d:      	addq	$0x20, %rbp
    1381:      	leaq	0x60(%rsp), %rdi
    1386:      	movl	$0x8, %ebx
    138b:      	movl	$0x4, %eax
    1390:      	leaq	0x68(%rsp), %r13
    1395:      	leaq	0x78(%rsp), %r12
    139a:      	movl	$0x8, %esi
    139f:      	movq	%rbp, %rdx
    13a2:      	callq	*%rax
    13a4:      	movl	$0x8, %ecx
    13a9:      	movl	$0x4, %eax
    13ae:      	movq	0x18(%rsp), %rdx
    13b3:      	movq	%r13, %rdi
    13b6:      	movl	$0x8, %esi
    13bb:      	callq	*%rax
    13bd:      	movl	$0x8, %ecx
    13c2:      	movl	$0x4, %eax
    13c7:      	movq	0x28(%rsp), %rdx
    13cc:      	movq	%r12, %rdi
    13cf:      	movl	$0x8, %esi
    13d4:      	callq	*%rax
    13d6:      	movl	$0x8, %ecx
    13db:      	movl	$0x4, %eax
    13e0:      	leaq	0x80(%rsp), %rdi
    13e8:      	movl	$0x8, %esi
    13ed:      	movq	%r15, %rdx
    13f0:      	callq	*%rax
    13f2:      	movq	0x80(%rsp), %rax
    13fa:      	addq	$-0x20, %rax
    13fe:      	movq	%rax, 0x88(%rsp)
    1406:      	movl	$0x80, %ebp
    140b:      	movq	0x78(%rsp), %r13
    1410:      	movq	0x80(%rsp), %rdx
    1418:      	movq	0x88(%rsp), %r12
    1420:      	cmpq	0x60(%rsp), %r13
    1425:      	jne	0x1432 <generic_usdt_process_event+0xa52>
    1427:      	cmpq	0x68(%rsp), %rdx
    142c:      	je	0x15af <generic_usdt_process_event+0xbcf>
    1432:      	movl	$0x4, %eax
    1437:      	leaq	0x38(%rsp), %rdi
    143c:      	movl	$0x8, %esi
    1441:      	callq	*%rax
    1443:      	cmpq	0x38(%rsp), %r13
    1448:      	je	0x154f <generic_usdt_process_event+0xb6f>
    144e:      	leaq	0x18(%r13), %r15
    1452:      	movl	$0x4, %eax
    1457:      	leaq	0x40(%rsp), %rdi
    145c:      	movl	$0x8, %esi
    1461:      	movq	%r15, %rdx
    1464:      	callq	*%rax
    1466:      	cmpq	%r13, 0x40(%rsp)
    146b:      	je	0x154f <generic_usdt_process_event+0xb6f>
    1471:      	movl	$0x4, %eax
    1476:      	leaq	0xb0(%rsp), %rdi
    147e:      	movl	$0x8, %esi
    1483:      	movq	%r15, %rdx
    1486:      	callq	*%rax
    1488:      	addq	$0x20, %r13
    148c:      	movl	$0x4, %eax
    1491:      	leaq	0x50(%rsp), %rdi
    1496:      	movl	$0x10, %ecx
    149b:      	movl	$0x10, %esi
    14a0:      	movq	%r13, %rdx
    14a3:      	callq	*%rax
    14a5:      	movq	0x70(%rsp), %r15
    14aa:      	movq	0x90(%rsp), %rax
    14b2:      	movl	0x54(%rsp), %r12d
    14b7:      	subq	%r15, %rax
    14ba:      	movl	0x98(%rsp), %r13d
    14c2:      	movl	%r12d, %edx
    14c5:      	subl	%r13d, %edx
    14c8:      	movl	$0x0, %ecx
    14cd:      	cmovbl	%ecx, %edx
    14d0:      	addq	0x58(%rsp), %rdx
    14d5:      	xorl	%esi, %esi
    14d7:      	cmpl	%r12d, %r13d
    14da:      	seta	%sil
    14de:      	movl	%r12d, %ecx
    14e1:      	cmovbl	%r13d, %ecx
    14e5:      	addl	%ecx, %esi
    14e7:      	movl	%r13d, %edi
    14ea:      	subl	%esi, %edi
    14ec:      	movl	%edi, 0x98(%rsp)
    14f3:      	subq	%rsi, %rax
    14f6:      	jb	0x15b7 <generic_usdt_process_event+0xbd7>
    14fc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    1502:      	ja	0x15b7 <generic_usdt_process_event+0xbd7>
    1508:      	cmpl	%r12d, %r13d
    150b:      	jbe	0x1512 <generic_usdt_process_event+0xb32>
    150d:      	movb	$0x2f, (%r15,%rax)
    1512:      	xorl	%edi, %edi
    1514:      	cmpl	%r12d, %r13d
    1517:      	seta	%dil
    151b:      	movzbl	%cl, %esi
    151e:      	addq	%rax, %r15
    1521:      	addq	%r15, %rdi
    1524:      	movl	$0x4, %eax
    1529:      	callq	*%rax
    152b:      	movq	%r15, 0x90(%rsp)
    1533:      	cmpl	%r12d, %r13d
    1536:      	jbe	0x15b7 <generic_usdt_process_event+0xbd7>
    1538:      	movq	0xb0(%rsp), %rax
    1540:      	movq	%rax, 0x78(%rsp)
    1545:      	decl	%ebp
    1547:      	jne	0x140b <generic_usdt_process_event+0xa2b>
    154d:      	jmp	0x15b7 <generic_usdt_process_event+0xbd7>
    154f:      	leaq	0x10(%r12), %rdx
    1554:      	movl	$0x4, %eax
    1559:      	leaq	0x40(%rsp), %rdi
    155e:      	movl	$0x8, %esi
    1563:      	callq	*%rax
    1565:      	movq	0x88(%rsp), %rax
    156d:      	cmpq	0x40(%rsp), %rax
    1572:      	je	0x15af <generic_usdt_process_event+0xbcf>
    1574:      	addq	$0x18, %r12
    1578:      	movl	$0x4, %eax
    157d:      	leaq	0x78(%rsp), %rdi
    1582:      	movl	$0x8, %esi
    1587:      	movq	%r12, %rdx
    158a:      	callq	*%rax
    158c:      	movq	0x40(%rsp), %rax
    1591:      	movq	%rax, 0x88(%rsp)
    1599:      	addq	$0x20, %rax
    159d:      	movq	%rax, 0x80(%rsp)
    15a5:      	decl	%ebp
    15a7:      	jne	0x140b <generic_usdt_process_event+0xa2b>
    15ad:      	jmp	0x15b7 <generic_usdt_process_event+0xbd7>
    15af:      	movb	$0x1, 0x9c(%rsp)
    15b7:      	movq	0x90(%rsp), %rax
    15bf:      	movq	0x8(%rsp), %rdx
    15c4:      	cmpq	%rdx, %rax
    15c7:      	movq	0xa8(%rsp), %r12
    15cf:      	je	0x160b <generic_usdt_process_event+0xc2b>
    15d1:      	xorl	%ebx, %ebx
    15d3:      	cmpb	$0x0, 0x9c(%rsp)
    15db:      	sete	%cl
    15de:      	movl	0x98(%rsp), %edx
    15e5:      	movl	$0x1000, %r13d          # imm = 0x1000
    15eb:      	subl	%edx, %r13d
    15ee:      	testl	%edx, %edx
    15f0:      	cmovlel	%edx, %r13d
    15f4:      	testq	%rax, %rax
    15f7:      	movq	0x30(%rsp), %rbp
    15fc:      	je	0x1944 <generic_usdt_process_event+0xf64>
    1602:      	movb	%cl, %bl
    1604:      	addl	%ebx, %ebx
    1606:      	movq	%rax, %rdx
    1609:      	jmp	0x1615 <generic_usdt_process_event+0xc35>
    160b:      	xorl	%r13d, %r13d
    160e:      	xorl	%ebx, %ebx
    1610:      	movq	0x30(%rsp), %rbp
    1615:      	movq	0x20(%rsp), %r15
    161a:      	leaq	0x4(%r15), %rdi
    161e:      	andl	$0xfff, %r13d           # imm = 0xFFF
    1625:      	movl	$0x4, %eax
    162a:      	movl	%r13d, %esi
    162d:      	callq	*%rax
    162f:      	movl	%r13d, (%r15)
    1632:      	leaq	0x60(%rsp), %rdi
    1637:      	movl	$0x8, %ecx
    163c:      	movl	$0x4, %eax
    1641:      	movq	0x28(%rsp), %rdx
    1646:      	movl	$0x8, %esi
    164b:      	callq	*%rax
    164d:      	movq	0x60(%rsp), %rcx
    1652:      	addq	$0x30, %rcx
    1656:      	leaq	0x50(%rsp), %rdi
    165b:      	movl	$0x8, %edx
    1660:      	movl	$0x4, %eax
    1665:      	movq	0x60(%rsp), %rdx
    166a:      	addq	$0x30, %rdx
    166e:      	movl	$0x8, %esi
    1673:      	callq	*%rax
    1675:      	movq	0x50(%rsp), %rcx
    167a:      	leaq	0x40(%rsp), %rdi
    167f:      	movl	$0x2, %edx
    1684:      	movl	$0x4, %eax
    1689:      	movq	0x50(%rsp), %rdx
    168e:      	movl	$0x2, %esi
    1693:      	callq	*%rax
    1695:      	movl	%ebx, 0x4(%r15,%r13)
    169a:      	movzwl	0x40(%rsp), %eax
    169f:      	movw	%ax, 0x8(%r15,%r13)
    16a5:      	addl	$0xa, %r13d
    16a9:      	movq	(%rsp), %rcx
    16ad:      	jmp	0x2c36 <generic_usdt_process_event+0x2256>
    16b2:      	movq	%rsi, 0x18(%rsp)
    16b7:      	movq	%r15, 0x28(%rsp)
    16bc:      	leaq	0x50(%rsp), %rdi
    16c1:      	leaq	0x60(%rsp), %rdx
    16c6:      	movl	$0x8, %ecx
    16cb:      	movl	$0x4, %eax
    16d0:      	movl	$0x8, %esi
    16d5:      	callq	*%rax
    16d7:      	movq	0x50(%rsp), %r15
    16dc:      	testq	%r15, %r15
    16df:      	jne	0x11ed <generic_usdt_process_event+0x80d>
    16e5:      	movl	$0x0, 0xd0(%rsp)
    16f0:      	movq	(%rip), %rdi            # 0x16f7 <generic_usdt_process_event+0xd17>
    16f7:      	leaq	0xd0(%rsp), %rsi
    16ff:      	movl	$0x1, %eax
    1704:      	callq	*%rax
    1706:      	testq	%rax, %rax
    1709:      	movq	%rbp, 0xe0(%rsp)
    1711:      	je	0x2954 <generic_usdt_process_event+0x1f74>
    1717:      	xorl	%r13d, %r13d
    171a:      	cmpl	$0x19, %r12d
    171e:      	jg	0x1a66 <generic_usdt_process_event+0x1086>
    1724:      	cmpl	$0x12, %r12d
    1728:      	jle	0x1aa2 <generic_usdt_process_event+0x10c2>
    172e:      	cmpl	$0x14, %r12d
    1732:      	jle	0x1ee1 <generic_usdt_process_event+0x1501>
    1738:      	cmpl	$0x15, %r12d
    173c:      	je	0x2764 <generic_usdt_process_event+0x1d84>
    1742:      	cmpl	$0x16, %r12d
    1746:      	je	0x26df <generic_usdt_process_event+0x1cff>
    174c:      	cmpl	$0x17, %r12d
    1750:      	movq	(%rsp), %rcx
    1754:      	jne	0x295b <generic_usdt_process_event+0x1f7b>
    175a:      	movl	$0x0, 0x4(%rbx)
    1761:      	movq	0x28(%rsp), %rax
    1766:      	movl	%eax, (%rbx)
    1768:      	movl	$0x8, %r13d
    176e:      	jmp	0x295b <generic_usdt_process_event+0x1f7b>
    1773:      	movq	%rsi, 0x18(%rsp)
    1778:      	movq	%r15, 0x28(%rsp)
    177d:      	cmpl	$0x28, %r12d
    1781:      	ja	0x16e5 <generic_usdt_process_event+0xd05>
    1787:      	movl	%r12d, %eax
    178a:      	movabsq	$0x1c1f2027cf2, %rcx    # imm = 0x1C1F2027CF2
    1794:      	btq	%rax, %rcx
    1798:      	jae	0x16e5 <generic_usdt_process_event+0xd05>
    179e:      	movq	0x28(%rsp), %rax
    17a3:      	movq	%rax, 0x38(%rsp)
    17a8:      	movl	$0x0, 0xd0(%rsp)
    17b3:      	movq	(%rip), %rdi            # 0x17ba <generic_usdt_process_event+0xdda>
    17ba:      	leaq	0xd0(%rsp), %rsi
    17c2:      	movl	$0x1, %eax
    17c7:      	callq	*%rax
    17c9:      	testq	%rax, %rax
    17cc:      	movq	%rbp, 0xe0(%rsp)
    17d4:      	je	0x194c <generic_usdt_process_event+0xf6c>
    17da:      	xorl	%r13d, %r13d
    17dd:      	cmpl	$0x10, %r12d
    17e1:      	movq	(%rsp), %rcx
    17e5:      	jg	0x1965 <generic_usdt_process_event+0xf85>
    17eb:      	cmpl	$0x9, %r12d
    17ef:      	jg	0x19a1 <generic_usdt_process_event+0xfc1>
    17f5:      	cmpl	$0x4, %r12d
    17f9:      	movq	0x30(%rsp), %rbp
    17fe:      	jle	0x1b14 <generic_usdt_process_event+0x1134>
    1804:      	cmpl	$0x5, %r12d
    1808:      	je	0x21d6 <generic_usdt_process_event+0x17f6>
    180e:      	cmpl	$0x6, %r12d
    1812:      	je	0x1a08 <generic_usdt_process_event+0x1028>
    1818:      	movq	%rax, 0x8(%rsp)
    181d:      	cmpl	$0x7, %r12d
    1821:      	movq	(%rsp), %rcx
    1825:      	jne	0x2c2e <generic_usdt_process_event+0x224e>
    182b:      	movq	0x38(%rsp), %r15
    1830:      	movq	%rbx, %r13
    1833:      	movq	%r15, 0x28(%rbx)
    1837:      	leaq	0x26(%rbx), %rdi
    183b:      	leaq	0x10(%r15), %rdx
    183f:      	movl	$0x2, %ecx
    1844:      	movl	$0x4, %eax
    1849:      	movl	$0x2, %esi
    184e:      	callq	*%rax
    1850:      	leaq	0x3a(%rbx), %rdi
    1854:      	leaq	0x12(%r15), %rdx
    1858:      	movl	$0x1, %ecx
    185d:      	movl	$0x4, %eax
    1862:      	movl	$0x1, %esi
    1867:      	callq	*%rax
    1869:      	leaq	0x38(%rbx), %rdi
    186d:      	leaq	0x226(%r15), %rdx
    1874:      	movl	$0x2, %ecx
    1879:      	movl	$0x4, %eax
    187e:      	movl	$0x2, %esi
    1883:      	callq	*%rax
    1885:      	leaq	0x24(%rbx), %rdi
    1889:      	leaq	0x224(%r15), %rdx
    1890:      	movl	$0x2, %ecx
    1895:      	movl	$0x4, %eax
    189a:      	movl	$0x2, %esi
    189f:      	callq	*%rax
    18a1:      	leaq	0x30(%rbx), %rdi
    18a5:      	leaq	0x21c(%r15), %rdx
    18ac:      	movl	$0x4, %ecx
    18b1:      	movl	$0x4, %eax
    18b6:      	movl	$0x4, %esi
    18bb:      	callq	*%rax
    18bd:      	leaq	0x34(%rbx), %rdi
    18c1:      	leaq	0x218(%r15), %rdx
    18c8:      	movl	$0x4, %ecx
    18cd:      	movl	$0x4, %eax
    18d2:      	movl	$0x4, %esi
    18d7:      	callq	*%rax
    18d9:      	leaq	0x10(%rbx), %r12
    18dd:      	movq	$0x0, (%rbx)
    18e4:      	movq	$0x0, 0x8(%rbx)
    18ec:      	movq	$0x0, 0x10(%rbx)
    18f4:      	movq	$0x0, 0x18(%rbx)
    18fc:      	movzwl	0x26(%rbx), %eax
    1900:      	cmpl	$0xa, %eax
    1903:      	je	0x2a38 <generic_usdt_process_event+0x2058>
    1909:      	cmpl	$0x2, %eax
    190c:      	jne	0x2a68 <generic_usdt_process_event+0x2088>
    1912:      	leaq	0x4(%r15), %rdx
    1916:      	movl	$0x4, %ecx
    191b:      	movl	$0x4, %eax
    1920:      	movq	%rbx, %rdi
    1923:      	movl	$0x4, %esi
    1928:      	callq	*%rax
    192a:      	movl	$0x4, %ecx
    192f:      	movl	$0x4, %eax
    1934:      	movq	%r12, %rdi
    1937:      	movl	$0x4, %esi
    193c:      	movq	%r15, %rdx
    193f:      	jmp	0x2a66 <generic_usdt_process_event+0x2086>
    1944:      	xorl	%r13d, %r13d
    1947:      	jmp	0x2c48 <generic_usdt_process_event+0x2268>
    194c:      	xorl	%r13d, %r13d
    194f:      	movq	(%rsp), %rcx
    1953:      	movq	0x30(%rsp), %rbp
    1958:      	movq	0xa8(%rsp), %r12
    1960:      	jmp	0x2c36 <generic_usdt_process_event+0x2256>
    1965:      	cmpl	$0x1e, %r12d
    1969:      	jg	0x1a25 <generic_usdt_process_event+0x1045>
    196f:      	cmpl	$0x1c, %r12d
    1973:      	jg	0x1b6c <generic_usdt_process_event+0x118c>
    1979:      	cmpl	$0x11, %r12d
    197d:      	je	0x2395 <generic_usdt_process_event+0x19b5>
    1983:      	cmpl	$0x19, %r12d
    1987:      	je	0x1fbf <generic_usdt_process_event+0x15df>
    198d:      	cmpl	$0x1c, %r12d
    1991:      	movq	0x30(%rsp), %rbp
    1996:      	je	0x1b24 <generic_usdt_process_event+0x1144>
    199c:      	jmp	0x2c2e <generic_usdt_process_event+0x224e>
    19a1:      	leal	-0xa(%r12), %eax
    19a6:      	cmpl	$0x2, %eax
    19a9:      	movq	0x30(%rsp), %rbp
    19ae:      	jb	0x1b24 <generic_usdt_process_event+0x1144>
    19b4:      	leal	-0xc(%r12), %eax
    19b9:      	cmpl	$0x2, %eax
    19bc:      	jb	0x1b48 <generic_usdt_process_event+0x1168>
    19c2:      	cmpl	$0xe, %r12d
    19c6:      	jne	0x2c2e <generic_usdt_process_event+0x224e>
    19cc:      	leaq	0x60(%rsp), %rdi
    19d1:      	leaq	0x38(%rsp), %r15
    19d6:      	movl	$0x8, %ecx
    19db:      	movl	$0x4, %eax
    19e0:      	movl	$0x8, %esi
    19e5:      	movq	%r15, %rdx
    19e8:      	callq	*%rax
    19ea:      	movq	0x60(%rsp), %rcx
    19ef:      	movl	$0x8, %edx
    19f4:      	movl	$0x4, %eax
    19f9:      	movq	0x60(%rsp), %rdx
    19fe:      	movq	%r15, %rdi
    1a01:      	movl	$0x8, %esi
    1a06:      	callq	*%rax
    1a08:      	movq	0x38(%rsp), %rdx
    1a0d:      	leaq	0x4(%rbx), %rdi
    1a11:      	movl	$0x1ff, %ecx            # imm = 0x1FF
    1a16:      	movl	$0x2d, %eax
    1a1b:      	movl	$0x1ff, %esi            # imm = 0x1FF
    1a20:      	jmp	0x1e85 <generic_usdt_process_event+0x14a5>
    1a25:      	cmpl	$0x26, %r12d
    1a29:      	jg	0x1b90 <generic_usdt_process_event+0x11b0>
    1a2f:      	leal	-0x1f(%r12), %eax
    1a34:      	cmpl	$0x2, %eax
    1a37:      	movq	0x30(%rsp), %rbp
    1a3c:      	jae	0x1e57 <generic_usdt_process_event+0x1477>
    1a42:      	leaq	0x38(%rsp), %rdx
    1a47:      	movl	$0x4, %r13d
    1a4d:      	movl	$0x1, %ecx
    1a52:      	movl	$0x4, %eax
    1a57:      	movq	%rbx, %rdi
    1a5a:      	movl	$0x1, %esi
    1a5f:      	callq	*%rax
    1a61:      	jmp	0x2c2a <generic_usdt_process_event+0x224a>
    1a66:      	cmpl	$0x20, %r12d
    1a6a:      	movq	0x28(%rsp), %rdx
    1a6f:      	jle	0x1d95 <generic_usdt_process_event+0x13b5>
    1a75:      	leal	-0x21(%r12), %ecx
    1a7a:      	cmpl	$0x4, %ecx
    1a7d:      	jae	0x1c42 <generic_usdt_process_event+0x1262>
    1a83:      	movl	$0x8, %r13d
    1a89:      	movl	$0x8, %ecx
    1a8e:      	movl	$0x4, %eax
    1a93:      	movq	%rbx, %rdi
    1a96:      	movl	$0x8, %esi
    1a9b:      	callq	*%rax
    1a9d:      	jmp	0x2957 <generic_usdt_process_event+0x1f77>
    1aa2:      	movl	0x8(%rsp), %r15d
    1aa7:      	cmpl	$0x7, %r12d
    1aab:      	jg	0x1ea2 <generic_usdt_process_event+0x14c2>
    1ab1:      	cmpl	$0x2, %r12d
    1ab5:      	je	0x2484 <generic_usdt_process_event+0x1aa4>
    1abb:      	cmpl	$0x3, %r12d
    1abf:      	movq	(%rsp), %rcx
    1ac3:      	jne	0x295b <generic_usdt_process_event+0x1f7b>
    1ac9:      	movq	%rax, %rbx
    1acc:      	addq	$0x90, %rax
    1ad2:      	movq	%rax, 0x20(%rsp)
    1ad7:      	movq	0x8(%rsp), %rcx
    1adc:      	andl	$0xf, %ecx
    1adf:      	movq	%rcx, %rax
    1ae2:      	cmpl	$0x2, %ecx
    1ae5:      	jle	0x2bb6 <generic_usdt_process_event+0x21d6>
    1aeb:      	cmpl	$0x3, %eax
    1aee:      	je	0x2edf <generic_usdt_process_event+0x24ff>
    1af4:      	cmpl	$0x4, %eax
    1af7:      	je	0x2eea <generic_usdt_process_event+0x250a>
    1afd:      	cmpl	$0x5, %eax
    1b00:      	jne	0x330c <generic_usdt_process_event+0x292c>
    1b06:      	movq	%rbx, %rax
    1b09:      	addq	$0x5e70, %rax           # imm = 0x5E70
    1b0f:      	jmp	0x2efe <generic_usdt_process_event+0x251e>
    1b14:      	cmpl	$0x1, %r12d
    1b18:      	je	0x1b48 <generic_usdt_process_event+0x1168>
    1b1a:      	cmpl	$0x4, %r12d
    1b1e:      	jne	0x2c2e <generic_usdt_process_event+0x224e>
    1b24:      	movl	$0x8, %r13d
    1b2a:      	leaq	0x38(%rsp), %rdx
    1b2f:      	movl	$0x8, %ecx
    1b34:      	movl	$0x4, %eax
    1b39:      	movq	%rbx, %rdi
    1b3c:      	movl	$0x8, %esi
    1b41:      	callq	*%rax
    1b43:      	jmp	0x2c2a <generic_usdt_process_event+0x224a>
    1b48:      	leaq	0x38(%rsp), %rdx
    1b4d:      	movl	$0x4, %r13d
    1b53:      	movl	$0x4, %ecx
    1b58:      	movl	$0x4, %eax
    1b5d:      	movq	%rbx, %rdi
    1b60:      	movl	$0x4, %esi
    1b65:      	callq	*%rax
    1b67:      	jmp	0x2c2a <generic_usdt_process_event+0x224a>
    1b6c:      	leaq	0x38(%rsp), %rdx
    1b71:      	movl	$0x4, %r13d
    1b77:      	movl	$0x2, %ecx
    1b7c:      	movl	$0x4, %eax
    1b81:      	movq	%rbx, %rdi
    1b84:      	movl	$0x2, %esi
    1b89:      	callq	*%rax
    1b8b:      	jmp	0x194f <generic_usdt_process_event+0xf6f>
    1b90:      	cmpl	$0x27, %r12d
    1b94:      	je	0x244a <generic_usdt_process_event+0x1a6a>
    1b9a:      	movq	%rbx, 0x20(%rsp)
    1b9f:      	cmpl	$0x28, %r12d
    1ba3:      	movq	0x30(%rsp), %rbp
    1ba8:      	jne	0x2c2e <generic_usdt_process_event+0x224e>
    1bae:      	movq	0x38(%rsp), %r15
    1bb3:      	movq	0x20(%rsp), %rbx
    1bb8:      	movq	$0x0, 0x10(%rbx)
    1bc0:      	movq	$0x0, 0x8(%rbx)
    1bc8:      	movq	$0x0, (%rbx)
    1bcf:      	movl	$0x2, %ecx
    1bd4:      	movl	$0x4, %eax
    1bd9:      	movq	%rbx, %rdi
    1bdc:      	movl	$0x2, %esi
    1be1:      	movq	%r15, %rdx
    1be4:      	callq	*%rax
    1be6:      	testq	%rax, %rax
    1be9:      	js	0x2c24 <generic_usdt_process_event+0x2244>
    1bef:      	movzwl	(%rbx), %eax
    1bf2:      	cmpl	$0xa, %eax
    1bf5:      	je	0x2bd6 <generic_usdt_process_event+0x21f6>
    1bfb:      	cmpl	$0x2, %eax
    1bfe:      	jne	0x2c10 <generic_usdt_process_event+0x2230>
    1c04:      	leaq	0x4(%r15), %rdx
    1c08:      	leaq	0x60(%rsp), %rdi
    1c0d:      	movl	$0x4, %ecx
    1c12:      	movl	$0x4, %eax
    1c17:      	movl	$0x4, %esi
    1c1c:      	callq	*%rax
    1c1e:      	movl	0x60(%rsp), %eax
    1c22:      	movq	0x20(%rsp), %rcx
    1c27:      	movq	%rax, 0x8(%rcx)
    1c2b:      	leaq	0x2(%rcx), %rdi
    1c2f:      	addq	$0x2, %r15
    1c33:      	movl	$0x2, %ecx
    1c38:      	movl	$0x4, %eax
    1c3d:      	jmp	0x2c06 <generic_usdt_process_event+0x2226>
    1c42:      	cmpl	$0x2b, %r12d
    1c46:      	je	0x284d <generic_usdt_process_event+0x1e6d>
    1c4c:      	cmpl	$0x29, %r12d
    1c50:      	movq	(%rsp), %rcx
    1c54:      	jne	0x295b <generic_usdt_process_event+0x1f7b>
    1c5a:      	movq	%rax, %rbp
    1c5d:      	addq	$0x18, %rdx
    1c61:      	leaq	0x60(%rsp), %rdi
    1c66:      	movl	$0x4, %r12d
    1c6c:      	movl	$0x8, %ecx
    1c71:      	movl	$0x4, %eax
    1c76:      	movl	$0x8, %esi
    1c7b:      	callq	*%rax
    1c7d:      	movq	0x60(%rsp), %r15
    1c82:      	testq	%r15, %r15
    1c85:      	je	0x2ea0 <generic_usdt_process_event+0x24c0>
    1c8b:      	movq	%rbx, %r13
    1c8e:      	movq	%r15, 0x28(%rbx)
    1c92:      	leaq	0x26(%rbx), %rdi
    1c96:      	leaq	0x10(%r15), %rdx
    1c9a:      	movl	$0x2, %ecx
    1c9f:      	movl	$0x4, %eax
    1ca4:      	movl	$0x2, %esi
    1ca9:      	callq	*%rax
    1cab:      	leaq	0x3a(%rbx), %rdi
    1caf:      	leaq	0x12(%r15), %rdx
    1cb3:      	movl	$0x1, %ecx
    1cb8:      	movl	$0x4, %eax
    1cbd:      	movl	$0x1, %esi
    1cc2:      	callq	*%rax
    1cc4:      	leaq	0x38(%rbx), %rdi
    1cc8:      	leaq	0x226(%r15), %rdx
    1ccf:      	movl	$0x2, %ecx
    1cd4:      	movl	$0x4, %eax
    1cd9:      	movl	$0x2, %esi
    1cde:      	callq	*%rax
    1ce0:      	leaq	0x24(%rbx), %rdi
    1ce4:      	leaq	0x224(%r15), %rdx
    1ceb:      	movl	$0x2, %ecx
    1cf0:      	movl	$0x4, %eax
    1cf5:      	movl	$0x2, %esi
    1cfa:      	callq	*%rax
    1cfc:      	leaq	0x30(%rbx), %rdi
    1d00:      	leaq	0x21c(%r15), %rdx
    1d07:      	movl	$0x4, %eax
    1d0c:      	movl	$0x4, %esi
    1d11:      	callq	*%rax
    1d13:      	leaq	0x34(%rbx), %rdi
    1d17:      	leaq	0x218(%r15), %rdx
    1d1e:      	movl	$0x4, %eax
    1d23:      	movl	$0x4, %esi
    1d28:      	callq	*%rax
    1d2a:      	leaq	0x10(%rbx), %r12
    1d2e:      	movq	$0x0, (%rbx)
    1d35:      	movq	$0x0, 0x8(%rbx)
    1d3d:      	movq	$0x0, 0x10(%rbx)
    1d45:      	movq	$0x0, 0x18(%rbx)
    1d4d:      	movzwl	0x26(%rbx), %eax
    1d51:      	cmpl	$0xa, %eax
    1d54:      	je	0x2e2b <generic_usdt_process_event+0x244b>
    1d5a:      	cmpl	$0x2, %eax
    1d5d:      	jne	0x2e5b <generic_usdt_process_event+0x247b>
    1d63:      	leaq	0x4(%r15), %rdx
    1d67:      	movl	$0x4, %ecx
    1d6c:      	movl	$0x4, %eax
    1d71:      	movq	%rbx, %rdi
    1d74:      	movl	$0x4, %esi
    1d79:      	callq	*%rax
    1d7b:      	movl	$0x4, %ecx
    1d80:      	movl	$0x4, %eax
    1d85:      	movq	%r12, %rdi
    1d88:      	movl	$0x4, %esi
    1d8d:      	movq	%r15, %rdx
    1d90:      	jmp	0x2e59 <generic_usdt_process_event+0x2479>
    1d95:      	movq	%rdx, %rbp
    1d98:      	cmpl	$0x1a, %r12d
    1d9c:      	je	0x28e0 <generic_usdt_process_event+0x1f00>
    1da2:      	cmpl	$0x1b, %r12d
    1da6:      	movq	(%rsp), %rcx
    1daa:      	jne	0x295b <generic_usdt_process_event+0x1f7b>
    1db0:      	movq	%rbx, %r15
    1db3:      	movq	%rcx, %rbx
    1db6:      	movq	$0x0, 0x48(%r15)
    1dbe:      	movq	$0x0, 0x40(%r15)
    1dc6:      	movq	$0x0, 0x38(%r15)
    1dce:      	movq	$0x0, 0x30(%r15)
    1dd6:      	movq	$0x0, 0x28(%r15)
    1dde:      	movq	$0x0, 0x20(%r15)
    1de6:      	movq	$0x0, 0x18(%r15)
    1dee:      	movq	$0x0, 0x10(%r15)
    1df6:      	movq	$0x0, 0x8(%r15)
    1dfe:      	movq	$0x0, (%r15)
    1e05:      	leaq	0x10(%r15), %rdi
    1e09:      	leaq	0x18(%rbp), %rdx
    1e0d:      	movl	$0x3f, %ecx
    1e12:      	movl	$0x2d, %eax
    1e17:      	movl	$0x3f, %esi
    1e1c:      	callq	*%rax
    1e1e:      	testq	%rax, %rax
    1e21:      	js	0x2d76 <generic_usdt_process_event+0x2396>
    1e27:      	movq	%r15, %rdi
    1e2a:      	addq	$0x8, %rdi
    1e2e:      	movq	%rbp, %rdx
    1e31:      	addq	$0x348, %rdx            # imm = 0x348
    1e38:      	movl	$0x8, %ecx
    1e3d:      	movl	$0x4, %eax
    1e42:      	movl	$0x8, %esi
    1e47:      	callq	*%rax
    1e49:      	movl	$0x50, %r13d
    1e4f:      	movq	%rbx, %rcx
    1e52:      	jmp	0x295b <generic_usdt_process_event+0x1f7b>
    1e57:      	cmpl	$0x26, %r12d
    1e5b:      	jne	0x2c2e <generic_usdt_process_event+0x224e>
    1e61:      	movq	0x38(%rsp), %rsi
    1e66:      	movzwl	%si, %edx
    1e69:      	addq	0xa8(%rsp), %rdx
    1e71:      	shrl	$0x10, %esi
    1e74:      	andl	$0xfff, %esi            # imm = 0xFFF
    1e7a:      	leaq	0x4(%rbx), %rdi
    1e7e:      	incl	%esi
    1e80:      	movl	$0x2d, %eax
    1e85:      	callq	*%rax
    1e87:      	movq	%rax, %r13
    1e8a:      	testq	%rax, %rax
    1e8d:      	js	0x2c2a <generic_usdt_process_event+0x224a>
    1e93:      	leal	-0x1(%r13), %eax
    1e97:      	movl	%eax, (%rbx)
    1e99:      	addq	$0x3, %r13
    1e9d:      	jmp	0x2c2a <generic_usdt_process_event+0x224a>
    1ea2:      	cmpl	$0x8, %r12d
    1ea6:      	je	0x24ed <generic_usdt_process_event+0x1b0d>
    1eac:      	cmpl	$0x12, %r12d
    1eb0:      	movq	(%rsp), %rcx
    1eb4:      	jne	0x295b <generic_usdt_process_event+0x1f7b>
    1eba:      	movq	%rbx, %rdi
    1ebd:      	andl	$0x3ff, %r15d           # imm = 0x3FF
    1ec4:      	movq	%rcx, %rbx
    1ec7:      	movl	$0x4, %eax
    1ecc:      	movq	0x28(%rsp), %rdx
    1ed1:      	movl	%r15d, %esi
    1ed4:      	callq	*%rax
    1ed6:      	movq	%rbx, %rcx
    1ed9:      	movq	%r15, %r13
    1edc:      	jmp	0x295b <generic_usdt_process_event+0x1f7b>
    1ee1:      	cmpl	$0x13, %r12d
    1ee5:      	je	0x27f6 <generic_usdt_process_event+0x1e16>
    1eeb:      	cmpl	$0x14, %r12d
    1eef:      	movq	(%rsp), %rcx
    1ef3:      	jne	0x295b <generic_usdt_process_event+0x1f7b>
    1ef9:      	movq	%rbx, %rbp
    1efc:      	movq	$0x0, 0x60(%rsp)
    1f05:      	movq	0x28(%rsp), %r13
    1f0a:      	leaq	0x110(%r13), %rdx
    1f11:      	leaq	0x60(%rsp), %rdi
    1f16:      	movl	$0x8, %esi
    1f1b:      	movq	%rcx, %rbx
    1f1e:      	movl	$0x4, %eax
    1f23:      	leaq	0xd8(%r13), %r15
    1f2a:      	movl	$0x8, %esi
    1f2f:      	callq	*%rax
    1f31:      	movq	0x60(%rsp), %rcx
    1f36:      	movl	$0x80, %edx
    1f3b:      	movl	$0x2d, %eax
    1f40:      	movq	%rbp, %r12
    1f43:      	movq	0x60(%rsp), %rdx
    1f48:      	movq	%rbp, %rdi
    1f4b:      	movl	$0x80, %esi
    1f50:      	callq	*%rax
    1f52:      	leaq	0x90(%rbp), %rdi
    1f59:      	movl	$0x4, %ecx
    1f5e:      	movl	$0x4, %eax
    1f63:      	movl	$0x4, %esi
    1f68:      	movq	%r15, %rdx
    1f6b:      	callq	*%rax
    1f6d:      	leaq	0x80(%rbp), %rdi
    1f74:      	leaq	0xe0(%r13), %rdx
    1f7b:      	movl	$0x8, %ecx
    1f80:      	movl	$0x4, %eax
    1f85:      	movl	$0x8, %esi
    1f8a:      	callq	*%rax
    1f8c:      	addq	$0x88, %r12
    1f93:      	addq	$0x118, %r13            # imm = 0x118
    1f9a:      	movl	$0x8, %ecx
    1f9f:      	movl	$0x4, %eax
    1fa4:      	movq	%r12, %rdi
    1fa7:      	movl	$0x8, %esi
    1fac:      	movq	%r13, %rdx
    1faf:      	callq	*%rax
    1fb1:      	movq	%rbx, %rcx
    1fb4:      	movl	$0x98, %r13d
    1fba:      	jmp	0x295b <generic_usdt_process_event+0x1f7b>
    1fbf:      	movq	%rax, %rbp
    1fc2:      	movq	0x38(%rsp), %r15
    1fc7:      	leaq	0xa0(%rsp), %rdi
    1fcf:      	movl	$0x1, %ecx
    1fd4:      	movl	$0x4, %eax
    1fd9:      	movl	$0x1, %esi
    1fde:      	movq	%r15, %rdx
    1fe1:      	callq	*%rax
    1fe3:      	cmpb	$0x1, 0xa0(%rsp)
    1feb:      	jne	0x296d <generic_usdt_process_event+0x1f8d>
    1ff1:      	addq	$0x10, %r15
    1ff5:      	leaq	0x50(%rsp), %rdi
    1ffa:      	movl	$0x8, %ebx
    1fff:      	movl	$0x8, %ecx
    2004:      	movl	$0x4, %eax
    2009:      	movl	$0x8, %esi
    200e:      	movq	%r15, %rdx
    2011:      	callq	*%rax
    2013:      	movq	0x50(%rsp), %rdx
    2018:      	leaq	0x40(%rsp), %rdi
    201d:      	movl	$0x8, %ecx
    2022:      	movl	$0x4, %eax
    2027:      	movl	$0x8, %esi
    202c:      	callq	*%rax
    202e:      	movq	0x50(%rsp), %rdx
    2033:      	addq	$0x8, %rdx
    2037:      	leaq	0xb0(%rsp), %rdi
    203f:      	movl	$0x8, %ecx
    2044:      	movl	$0x4, %eax
    2049:      	movl	$0x8, %esi
    204e:      	callq	*%rax
    2050:      	movq	0x40(%rsp), %rax
    2055:      	movq	%rax, 0x20(%rsp)
    205a:      	movq	0xb0(%rsp), %rax
    2062:      	movq	%rax, 0x28(%rsp)
    2067:      	movq	0x18(%rsp), %rax
    206c:      	addq	%rbp, %rax
    206f:      	addq	$0x90, %rax
    2075:      	movq	%rax, 0x18(%rsp)
    207a:      	testb	$0x20, 0x8(%rsp)
    207f:      	je	0x2da9 <generic_usdt_process_event+0x23c9>
    2085:      	cmpq	$0x1000, 0x28(%rsp)     # imm = 0x1000
    208e:      	jb	0x2d81 <generic_usdt_process_event+0x23a1>
    2094:      	movq	0x18(%rsp), %rax
    2099:      	movl	$0x1, (%rax)
    209f:      	movl	$0x0, 0xb8(%rsp)
    20aa:      	movq	(%rip), %rdi            # 0x20b1 <generic_usdt_process_event+0x16d1>
    20b1:      	leaq	0xb8(%rsp), %rsi
    20b9:      	movl	$0x1, %eax
    20be:      	callq	*%rax
    20c0:      	testq	%rax, %rax
    20c3:      	je	0x34be <generic_usdt_process_event+0x2ade>
    20c9:      	movq	%rax, %r12
    20cc:      	movl	$0x18, (%rax)
    20d2:      	movl	$0xe, %eax
    20d7:      	callq	*%rax
    20d9:      	leaq	0x10(%r12), %rbx
    20de:      	movq	%rax, 0x10(%r12)
    20e3:      	cmpq	$-0x16, %rax
    20e7:      	jne	0x2113 <generic_usdt_process_event+0x1733>
    20e9:      	movq	0xa8(%rsp), %rax
    20f1:      	leaq	0x20(%rax), %rdx
    20f5:      	leaq	0x60(%rsp), %rdi
    20fa:      	movl	$0x8, %ecx
    20ff:      	movl	$0x4, %eax
    2104:      	movl	$0x8, %esi
    2109:      	callq	*%rax
    210b:      	movq	0x60(%rsp), %rax
    2110:      	movq	%rax, (%rbx)
    2113:      	movl	$0x7d, %eax
    2118:      	callq	*%rax
    211a:      	movq	%rax, 0x18(%r12)
    211f:      	movq	(%rbx), %rax
    2122:      	movq	0x8(%rbx), %rcx
    2126:      	movq	0x18(%rsp), %rdx
    212b:      	movq	%rax, 0x14(%rdx)
    212f:      	movq	%rcx, 0x1c(%rdx)
    2133:      	movq	%r12, %r13
    2136:      	addq	$0x20, %r13
    213a:      	movl	$0xa, %r15d
    2140:      	xorl	%ebx, %ebx
    2142:      	movq	0x28(%rsp), %rbp
    2147:      	subq	%rbx, %rbp
    214a:      	js	0x36f4 <generic_usdt_process_event+0x2d14>
    2150:      	movq	0x20(%rsp), %rax
    2155:      	leaq	(%rbx,%rax), %rdx
    2159:      	cmpq	$0x7fe0, %rbp           # imm = 0x7FE0
    2160:      	movl	$0x7fe0, %eax           # imm = 0x7FE0
    2165:      	cmovaeq	%rax, %rbp
    2169:      	movl	$0x4, %eax
    216e:      	movq	%r13, %rdi
    2171:      	movl	%ebp, %esi
    2173:      	callq	*%rax
    2175:      	testl	%eax, %eax
    2177:      	js	0x21a9 <generic_usdt_process_event+0x17c9>
    2179:      	leal	0x20(%rbp), %r8d
    217d:      	movl	%r8d, 0x4(%r12)
    2182:      	movl	$0x19, %eax
    2187:      	movq	0xa8(%rsp), %rdi
    218f:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    2194:      	movq	(%rip), %rsi            # 0x219b <generic_usdt_process_event+0x17bb>
    219b:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    21a0:      	movq	%r12, %rcx
    21a3:      	callq	*%rax
    21a5:      	testl	%eax, %eax
    21a7:      	jns	0x21ac <generic_usdt_process_event+0x17cc>
    21a9:      	movslq	%eax, %rbp
    21ac:      	testl	%ebp, %ebp
    21ae:      	js	0x36fd <generic_usdt_process_event+0x2d1d>
    21b4:      	andl	$0x7fffffff, %ebp       # imm = 0x7FFFFFFF
    21ba:      	addq	%rbp, %rbx
    21bd:      	cmpq	0x28(%rsp), %rbx
    21c2:      	je	0x3757 <generic_usdt_process_event+0x2d77>
    21c8:      	decl	%r15d
    21cb:      	jne	0x2142 <generic_usdt_process_event+0x1762>
    21d1:      	jmp	0x3ab4 <generic_usdt_process_event+0x30d4>
    21d6:      	movq	0x38(%rsp), %r12
    21db:      	leaq	0x28(%rbx), %rdi
    21df:      	leaq	0x98(%r12), %rdx
    21e7:      	movl	$0x4, %ecx
    21ec:      	movl	$0x4, %eax
    21f1:      	movl	$0x4, %esi
    21f6:      	callq	*%rax
    21f8:      	leaq	0x2c(%rbx), %rdi
    21fc:      	leaq	0x70(%r12), %rdx
    2201:      	movl	$0x4, %ecx
    2206:      	movl	$0x4, %eax
    220b:      	movl	$0x4, %esi
    2210:      	callq	*%rax
    2212:      	leaq	0x30(%rbx), %rdi
    2216:      	leaq	0x90(%r12), %rdx
    221e:      	movl	$0x4, %ecx
    2223:      	movl	$0x4, %eax
    2228:      	movl	$0x4, %esi
    222d:      	callq	*%rax
    222f:      	movq	%rbx, 0x20(%rsp)
    2234:      	leaq	0x34(%rbx), %rdi
    2238:      	leaq	0xa8(%r12), %rdx
    2240:      	movl	$0x4, %ecx
    2245:      	movl	$0x4, %eax
    224a:      	movl	$0x4, %esi
    224f:      	callq	*%rax
    2251:      	movq	$0x0, 0x60(%rsp)
    225a:      	leaq	0xc8(%r12), %rdx
    2262:      	leaq	0x60(%rsp), %rdi
    2267:      	movl	$0x8, %ecx
    226c:      	movl	$0x4, %eax
    2271:      	movl	$0x8, %esi
    2276:      	callq	*%rax
    2278:      	leaq	0xb8(%r12), %rdx
    2280:      	leaq	0xb0(%rsp), %rdi
    2288:      	movl	$0x2, %ecx
    228d:      	movl	$0x4, %eax
    2292:      	movl	$0x2, %esi
    2297:      	callq	*%rax
    2299:      	movzwl	0xb0(%rsp), %r15d
    22a2:      	addq	0x60(%rsp), %r15
    22a7:      	leaq	0xa7(%rsp), %rdi
    22af:      	movl	$0x1, %ecx
    22b4:      	movl	$0x4, %eax
    22b9:      	movl	$0x1, %esi
    22be:      	movq	%r15, %rdx
    22c1:      	callq	*%rax
    22c3:      	movzbl	0xa7(%rsp), %eax
    22cb:      	shrl	$0x4, %eax
    22ce:      	cmpl	$0x6, %eax
    22d1:      	je	0x2995 <generic_usdt_process_event+0x1fb5>
    22d7:      	cmpl	$0x4, %eax
    22da:      	jne	0x3fdb <generic_usdt_process_event+0x35fb>
    22e0:      	leaq	0x9(%r15), %rdx
    22e4:      	leaq	0xa0(%rsp), %rdi
    22ec:      	movl	$0x1, %ecx
    22f1:      	movl	$0x4, %eax
    22f6:      	movl	$0x1, %esi
    22fb:      	callq	*%rax
    22fd:      	movzbl	0xa0(%rsp), %eax
    2305:      	movq	0x20(%rsp), %rdi
    230a:      	movw	%ax, 0x24(%rdi)
    230e:      	movw	$0x2, 0x26(%rdi)
    2314:      	leaq	0xc(%r15), %rdx
    2318:      	movq	$0x0, (%rdi)
    231f:      	movq	$0x0, 0x8(%rdi)
    2327:      	movq	$0x0, 0x10(%rdi)
    232f:      	movq	$0x0, 0x18(%rdi)
    2337:      	movl	$0x4, %ecx
    233c:      	movl	$0x4, %eax
    2341:      	leaq	0x10(%rdi), %r13
    2345:      	movl	$0x4, %esi
    234a:      	callq	*%rax
    234c:      	addq	$0x10, %r15
    2350:      	movl	$0x4, %ecx
    2355:      	movl	$0x4, %eax
    235a:      	movq	%r13, %rdi
    235d:      	movl	$0x4, %esi
    2362:      	movq	%r15, %rdx
    2365:      	callq	*%rax
    2367:      	leaq	0xb6(%r12), %rdx
    236f:      	leaq	0xb8(%rsp), %rdi
    2377:      	movl	$0x2, %ecx
    237c:      	movl	$0x4, %eax
    2381:      	movl	$0x2, %esi
    2386:      	callq	*%rax
    2388:      	movzbl	0xa0(%rsp), %ebx
    2390:      	jmp	0x3e82 <generic_usdt_process_event+0x34a2>
    2395:      	movq	$0x0, 0x68(%rsp)
    239e:      	movl	$0xe, %eax
    23a3:      	callq	*%rax
    23a5:      	shrq	$0x20, %rax
    23a9:      	movq	%rax, 0x60(%rsp)
    23ae:      	leaq	0x50(%rsp), %rdi
    23b3:      	leaq	0x38(%rsp), %rdx
    23b8:      	movl	$0x4, %ecx
    23bd:      	movl	$0x4, %eax
    23c2:      	movl	$0x4, %ebp
    23c7:      	movl	$0x4, %esi
    23cc:      	callq	*%rax
    23ce:      	movl	0x50(%rsp), %eax
    23d2:      	movl	%eax, 0x68(%rsp)
    23d6:      	movq	(%rip), %rdi            # 0x23dd <generic_usdt_process_event+0x19fd>
    23dd:      	leaq	0x60(%rsp), %rsi
    23e2:      	movl	$0x1, %eax
    23e7:      	callq	*%rax
    23e9:      	testq	%rax, %rax
    23ec:      	je	0x2989 <generic_usdt_process_event+0x1fa9>
    23f2:      	movl	(%rax), %r13d
    23f5:      	leaq	0x50(%rsp), %rdx
    23fa:      	movq	%rax, %r15
    23fd:      	movl	$0x4, %eax
    2402:      	movq	%rbx, %rdi
    2405:      	movl	$0x4, %esi
    240a:      	callq	*%rax
    240c:      	andl	$0xfff, %r13d           # imm = 0xFFF
    2413:      	leaq	0x4(%rbx), %rdi
    2417:      	leaq	0x4(%r13), %rsi
    241b:      	movl	$0x4, %eax
    2420:      	movq	%r15, %rdx
    2423:      	callq	*%rax
    2425:      	leaq	(%rbx,%r13), %rdi
    2429:      	addq	$0x8, %rdi
    242d:      	leaq	(%r15,%r13), %rdx
    2431:      	addq	$0x4, %rdx
    2435:      	movl	$0x4, %eax
    243a:      	movl	$0x4, %esi
    243f:      	callq	*%rax
    2441:      	addq	$0xc, %r13
    2445:      	jmp	0x194f <generic_usdt_process_event+0xf6f>
    244a:      	movl	$0x120, %edx            # imm = 0x120
    244f:      	addq	0x38(%rsp), %rdx
    2454:      	leaq	0x4(%rbx), %rdi
    2458:      	movl	$0x11, %ecx
    245d:      	movl	$0x2d, %eax
    2462:      	movl	$0x11, %esi
    2467:      	callq	*%rax
    2469:      	movq	%rax, %r13
    246c:      	testq	%rax, %rax
    246f:      	js	0x194f <generic_usdt_process_event+0xf6f>
    2475:      	leal	-0x1(%r13), %eax
    2479:      	movl	%eax, (%rbx)
    247b:      	addq	$0x3, %r13
    247f:      	jmp	0x194f <generic_usdt_process_event+0xf6f>
    2484:      	movq	%rax, %rbx
    2487:      	movq	0x18(%rsp), %rcx
    248c:      	addq	%rcx, %rax
    248f:      	addq	$0x90, %rax
    2495:      	movq	%rax, 0x18(%rsp)
    249a:      	movq	$0x0, 0x38(%rsp)
    24a3:      	testb	$0x10, 0x8(%rsp)
    24a8:      	jne	0x2af3 <generic_usdt_process_event+0x2113>
    24ae:      	movl	0x8(%rsp), %r12d
    24b3:      	andl	$0xf, %r15d
    24b7:      	xorl	%eax, %eax
    24b9:      	cmpl	$0x2, %r15d
    24bd:      	jle	0x2e0b <generic_usdt_process_event+0x242b>
    24c3:      	cmpl	$0x3, %r15d
    24c7:      	je	0x34c9 <generic_usdt_process_event+0x2ae9>
    24cd:      	cmpl	$0x4, %r15d
    24d1:      	je	0x34d2 <generic_usdt_process_event+0x2af2>
    24d7:      	cmpl	$0x5, %r15d
    24db:      	jne	0x34e5 <generic_usdt_process_event+0x2b05>
    24e1:      	leaq	0x5e70(%rbx), %rax
    24e8:      	jmp	0x34e2 <generic_usdt_process_event+0x2b02>
    24ed:      	leaq	0x28(%rbx), %r13
    24f1:      	leaq	0x40(%rbx), %r15
    24f5:      	movq	0x28(%rsp), %r12
    24fa:      	leaq	0x8(%r12), %rdx
    24ff:      	movl	$0x4, %ecx
    2504:      	movl	$0x4, %eax
    2509:      	movq	%rbx, %rdi
    250c:      	movl	$0x4, %esi
    2511:      	callq	*%rax
    2513:      	leaq	0x4(%rbx), %rdi
    2517:      	leaq	0xc(%r12), %rdx
    251c:      	movl	$0x4, %ecx
    2521:      	movl	$0x4, %eax
    2526:      	movl	$0x4, %esi
    252b:      	callq	*%rax
    252d:      	leaq	0x10(%rbx), %rdi
    2531:      	leaq	0x18(%r12), %rdx
    2536:      	movl	$0x4, %ecx
    253b:      	movl	$0x4, %eax
    2540:      	movl	$0x4, %esi
    2545:      	callq	*%rax
    2547:      	leaq	0x14(%rbx), %rdi
    254b:      	leaq	0x1c(%r12), %rdx
    2550:      	movl	$0x4, %ecx
    2555:      	movl	$0x4, %eax
    255a:      	movl	$0x4, %esi
    255f:      	callq	*%rax
    2561:      	leaq	0x8(%rbx), %rdi
    2565:      	leaq	0x10(%r12), %rdx
    256a:      	movl	$0x4, %ecx
    256f:      	movl	$0x4, %eax
    2574:      	movl	$0x4, %esi
    2579:      	callq	*%rax
    257b:      	leaq	0xc(%rbx), %rdi
    257f:      	leaq	0x14(%r12), %rdx
    2584:      	movl	$0x4, %ecx
    2589:      	movl	$0x4, %eax
    258e:      	movl	$0x4, %esi
    2593:      	callq	*%rax
    2595:      	leaq	0x18(%rbx), %rdi
    2599:      	leaq	0x20(%r12), %rdx
    259e:      	movl	$0x4, %ecx
    25a3:      	movl	$0x4, %eax
    25a8:      	movl	$0x4, %esi
    25ad:      	callq	*%rax
    25af:      	leaq	0x1c(%rbx), %rdi
    25b3:      	leaq	0x24(%r12), %rdx
    25b8:      	movl	$0x4, %ecx
    25bd:      	movl	$0x4, %eax
    25c2:      	movl	$0x4, %esi
    25c7:      	callq	*%rax
    25c9:      	movl	$0x0, 0x24(%rbx)
    25d0:      	leaq	0x20(%rbx), %rdi
    25d4:      	leaq	0x28(%r12), %rdx
    25d9:      	movl	$0x4, %ecx
    25de:      	movl	$0x4, %eax
    25e3:      	movl	$0x4, %esi
    25e8:      	callq	*%rax
    25ea:      	leaq	0x30(%rbx), %rdi
    25ee:      	leaq	0x40(%r12), %rdx
    25f3:      	movl	$0x8, %ecx
    25f8:      	movl	$0x4, %eax
    25fd:      	movl	$0x8, %esi
    2602:      	callq	*%rax
    2604:      	leaq	0x38(%rbx), %rdi
    2608:      	leaq	0x30(%r12), %rdx
    260d:      	movl	$0x8, %ecx
    2612:      	movl	$0x4, %eax
    2617:      	movl	$0x8, %esi
    261c:      	callq	*%rax
    261e:      	leaq	0x38(%r12), %rdx
    2623:      	movl	$0x8, %ecx
    2628:      	movl	$0x4, %eax
    262d:      	movq	%r13, %rdi
    2630:      	movl	$0x8, %esi
    2635:      	callq	*%rax
    2637:      	addq	$0x90, %r12
    263e:      	leaq	0x60(%rsp), %rdi
    2643:      	movl	$0x8, %ecx
    2648:      	movl	$0x4, %eax
    264d:      	movl	$0x8, %esi
    2652:      	movq	%r12, %rdx
    2655:      	callq	*%rax
    2657:      	movq	0x60(%rsp), %r12
    265c:      	leaq	0xc8(%r12), %rdx
    2664:      	movl	$0x4, %ecx
    2669:      	movl	$0x4, %eax
    266e:      	movq	%r15, %rdi
    2671:      	movl	$0x4, %esi
    2676:      	callq	*%rax
    2678:      	leaq	0x44(%rbx), %rdi
    267c:      	leaq	0xcc(%r12), %rdx
    2684:      	movl	$0x4, %ecx
    2689:      	movl	$0x4, %eax
    268e:      	movl	$0x4, %esi
    2693:      	callq	*%rax
    2695:      	leaq	0x48(%rbx), %rdi
    2699:      	leaq	0xd0(%r12), %rdx
    26a1:      	movl	$0x4, %ecx
    26a6:      	movl	$0x4, %eax
    26ab:      	movl	$0x4, %esi
    26b0:      	callq	*%rax
    26b2:      	addq	$0x4c, %rbx
    26b6:      	addq	$0x158, %r12            # imm = 0x158
    26bd:      	movl	$0x4, %ecx
    26c2:      	movl	$0x4, %eax
    26c7:      	movq	%rbx, %rdi
    26ca:      	movl	$0x4, %esi
    26cf:      	movq	%r12, %rdx
    26d2:      	callq	*%rax
    26d4:      	movl	$0x50, %r13d
    26da:      	jmp	0x2957 <generic_usdt_process_event+0x1f77>
    26df:      	movq	0x28(%rsp), %r15
    26e4:      	leaq	0xc8(%r15), %rdx
    26eb:      	movl	$0x4, %ecx
    26f0:      	movl	$0x4, %eax
    26f5:      	movq	%rbx, %rdi
    26f8:      	movl	$0x4, %esi
    26fd:      	callq	*%rax
    26ff:      	leaq	0x4(%rbx), %rdi
    2703:      	leaq	0xcc(%r15), %rdx
    270a:      	movl	$0x4, %ecx
    270f:      	movl	$0x4, %eax
    2714:      	movl	$0x4, %esi
    2719:      	callq	*%rax
    271b:      	leaq	0x8(%rbx), %rdi
    271f:      	leaq	0xd0(%r15), %rdx
    2726:      	movl	$0x4, %ecx
    272b:      	movl	$0x4, %eax
    2730:      	movl	$0x4, %esi
    2735:      	callq	*%rax
    2737:      	addq	$0xc, %rbx
    273b:      	addq	$0x158, %r15            # imm = 0x158
    2742:      	movl	$0x4, %ecx
    2747:      	movl	$0x4, %eax
    274c:      	movq	%rbx, %rdi
    274f:      	movl	$0x4, %esi
    2754:      	movq	%r15, %rdx
    2757:      	callq	*%rax
    2759:      	movl	$0x10, %r13d
    275f:      	jmp	0x2957 <generic_usdt_process_event+0x1f77>
    2764:      	movq	0x28(%rsp), %r15
    2769:      	leaq	0x38(%r15), %rdx
    276d:      	movl	$0x4, %ecx
    2772:      	movl	$0x4, %eax
    2777:      	movq	%rbx, %rdi
    277a:      	movl	$0x4, %esi
    277f:      	callq	*%rax
    2781:      	leaq	0x4(%rbx), %rdi
    2785:      	leaq	0x3c(%r15), %rdx
    2789:      	movl	$0x4, %ecx
    278e:      	movl	$0x4, %eax
    2793:      	movl	$0x4, %esi
    2798:      	callq	*%rax
    279a:      	leaq	0x8(%rbx), %rdi
    279e:      	leaq	0x40(%r15), %rdx
    27a2:      	movl	$0x4, %ecx
    27a7:      	movl	$0x4, %eax
    27ac:      	movl	$0x4, %esi
    27b1:      	callq	*%rax
    27b3:      	leaq	0xc(%rbx), %rdi
    27b7:      	leaq	0x44(%r15), %rdx
    27bb:      	movl	$0x4, %ecx
    27c0:      	movl	$0x4, %eax
    27c5:      	movl	$0x4, %esi
    27ca:      	callq	*%rax
    27cc:      	addq	$0x10, %rbx
    27d0:      	subq	$-0x80, %r15
    27d4:      	movl	$0x10, %ecx
    27d9:      	movl	$0x4, %eax
    27de:      	movq	%rbx, %rdi
    27e1:      	movl	$0x10, %esi
    27e6:      	movq	%r15, %rdx
    27e9:      	callq	*%rax
    27eb:      	movl	$0x20, %r13d
    27f1:      	jmp	0x2957 <generic_usdt_process_event+0x1f77>
    27f6:      	movl	$0x4, %ecx
    27fb:      	movl	$0x4, %eax
    2800:      	movq	0x28(%rsp), %r15
    2805:      	movq	%rbx, %rdi
    2808:      	movl	$0x4, %esi
    280d:      	movq	%r15, %rdx
    2810:      	callq	*%rax
    2812:      	leaq	0x4(%rbx), %rdi
    2816:      	leaq	0x4(%r15), %rdx
    281a:      	movl	$0x4, %ecx
    281f:      	movl	$0x4, %eax
    2824:      	movl	$0x4, %esi
    2829:      	callq	*%rax
    282b:      	addq	$0x8, %rbx
    282f:      	addq	$0x30, %r15
    2833:      	movl	$0x10, %ecx
    2838:      	movl	$0x4, %eax
    283d:      	movq	%rbx, %rdi
    2840:      	movl	$0x10, %esi
    2845:      	movq	%r15, %rdx
    2848:      	jmp	0x28d6 <generic_usdt_process_event+0x1ef6>
    284d:      	movq	%rdx, %r15
    2850:      	addq	$0x4, %rdx
    2854:      	leaq	0x60(%rsp), %rdi
    2859:      	movl	$0x4, %ecx
    285e:      	movl	$0x4, %eax
    2863:      	movl	$0x4, %esi
    2868:      	callq	*%rax
    286a:      	movl	0x60(%rsp), %eax
    286e:      	movl	%eax, (%rbx)
    2870:      	leaq	0xc(%r15), %rdx
    2874:      	leaq	0x60(%rsp), %rdi
    2879:      	movl	$0x4, %ecx
    287e:      	movl	$0x4, %eax
    2883:      	movl	$0x4, %esi
    2888:      	callq	*%rax
    288a:      	movl	0x60(%rsp), %eax
    288e:      	movl	%eax, 0x4(%rbx)
    2891:      	addq	$0x50, %r15
    2895:      	leaq	0x60(%rsp), %rdi
    289a:      	movl	$0x8, %ecx
    289f:      	movl	$0x2d, %eax
    28a4:      	movl	$0x8, %esi
    28a9:      	movq	%r15, %rdx
    28ac:      	callq	*%rax
    28ae:      	addq	$0x8, %rbx
    28b2:      	movl	$0x3f8, %edx            # imm = 0x3F8
    28b7:      	movq	0x60(%rsp), %rcx
    28bc:      	addq	%rdx, %rcx
    28bf:      	movl	$0x10, %esi
    28c4:      	movl	$0x2d, %eax
    28c9:      	addq	0x60(%rsp), %rdx
    28ce:      	movq	%rbx, %rdi
    28d1:      	movl	$0x10, %esi
    28d6:      	callq	*%rax
    28d8:      	movl	$0x18, %r13d
    28de:      	jmp	0x2957 <generic_usdt_process_event+0x1f77>
    28e0:      	movq	$0x0, 0x48(%rbx)
    28e8:      	movq	$0x0, 0x40(%rbx)
    28f0:      	movq	$0x0, 0x38(%rbx)
    28f8:      	movq	$0x0, 0x30(%rbx)
    2900:      	movq	$0x0, 0x28(%rbx)
    2908:      	movq	$0x0, 0x20(%rbx)
    2910:      	movq	$0x0, 0x18(%rbx)
    2918:      	movq	$0x0, 0x10(%rbx)
    2920:      	movq	$0x0, 0x8(%rbx)
    2928:      	movq	%rbx, %r15
    292b:      	movq	$0x0, (%rbx)
    2932:      	leaq	0x60(%rsp), %rdi
    2937:      	movl	$0x8, %ecx
    293c:      	movl	$0x4, %eax
    2941:      	movq	%rbp, %rdx
    2944:      	movl	$0x8, %esi
    2949:      	callq	*%rax
    294b:      	testq	%rax, %rax
    294e:      	je	0x2ccc <generic_usdt_process_event+0x22ec>
    2954:      	xorl	%r13d, %r13d
    2957:      	movq	(%rsp), %rcx
    295b:      	movq	0xa8(%rsp), %r12
    2963:      	movq	0x30(%rsp), %rbp
    2968:      	jmp	0x2c36 <generic_usdt_process_event+0x2256>
    296d:      	movq	0x18(%rsp), %rax
    2972:      	movq	$0x0, 0x90(%rbp,%rax)
    297e:      	movl	$0x8, %r13d
    2984:      	jmp	0x194f <generic_usdt_process_event+0xf6f>
    2989:      	movq	$-0x1, %r13
    2990:      	jmp	0x194f <generic_usdt_process_event+0xf6f>
    2995:      	movq	0x60(%rsp), %r15
    299a:      	movl	$0x0, 0x50(%rsp)
    29a2:      	movzwl	0xb0(%rsp), %ebx
    29aa:      	movq	(%rip), %rdi            # 0x29b1 <generic_usdt_process_event+0x1fd1>
    29b1:      	leaq	0x50(%rsp), %rsi
    29b6:      	movl	$0x1, %eax
    29bb:      	leaq	(%r15,%rbx), %r13
    29bf:      	callq	*%rax
    29c1:      	testq	%rax, %rax
    29c4:      	je	0x3e31 <generic_usdt_process_event+0x3451>
    29ca:      	movq	%rax, %rbp
    29cd:      	movw	%bx, (%rax)
    29d0:      	movb	$-0x1, 0x5(%rax)
    29d4:      	movb	$0x0, 0x7(%rax)
    29d8:      	movq	%rax, %rdi
    29db:      	addq	$0x6, %rdi
    29df:      	leaq	0x6(%r13), %rdx
    29e3:      	movl	$0x1, %ecx
    29e8:      	movl	$0x4, %eax
    29ed:      	movq	%rdi, 0x8(%rsp)
    29f2:      	movl	$0x1, %esi
    29f7:      	callq	*%rax
    29f9:      	testq	%rax, %rax
    29fc:      	js	0x3e31 <generic_usdt_process_event+0x3451>
    2a02:      	movzbl	0x5(%rbp), %eax
    2a06:      	cmpl	$0x32, %eax
    2a09:      	jg	0x33fc <generic_usdt_process_event+0x2a1c>
    2a0f:      	testl	%eax, %eax
    2a11:      	je	0x34ae <generic_usdt_process_event+0x2ace>
    2a17:      	cmpl	$0x2b, %eax
    2a1a:      	je	0x34ae <generic_usdt_process_event+0x2ace>
    2a20:      	cmpl	$0x2c, %eax
    2a23:      	jne	0x382f <generic_usdt_process_event+0x2e4f>
    2a29:      	movw	$0x8, 0x2(%rbp)
    2a2f:      	movw	$0x8, %ax
    2a33:      	jmp	0x3770 <generic_usdt_process_event+0x2d90>
    2a38:      	leaq	0x48(%r15), %rdx
    2a3c:      	movl	$0x10, %ecx
    2a41:      	movl	$0x4, %eax
    2a46:      	movq	%rbx, %rdi
    2a49:      	movl	$0x10, %esi
    2a4e:      	callq	*%rax
    2a50:      	leaq	0x38(%r15), %rdx
    2a54:      	movl	$0x10, %ecx
    2a59:      	movl	$0x4, %eax
    2a5e:      	movq	%r12, %rdi
    2a61:      	movl	$0x10, %esi
    2a66:      	callq	*%rax
    2a68:      	leaq	0x20(%rbx), %rdi
    2a6c:      	leaq	0xc(%r15), %r12
    2a70:      	addq	$0xe, %r15
    2a74:      	movl	$0x2, %ecx
    2a79:      	movl	$0x4, %eax
    2a7e:      	movl	$0x2, %esi
    2a83:      	movq	%r15, %rdx
    2a86:      	callq	*%rax
    2a88:      	leaq	0x22(%rbx), %rdi
    2a8c:      	movl	$0x2, %ecx
    2a91:      	movl	$0x4, %eax
    2a96:      	movl	$0x2, %esi
    2a9b:      	movq	%r12, %rdx
    2a9e:      	callq	*%rax
    2aa0:      	movzwl	0x22(%rbx), %eax
    2aa4:      	movbew	%ax, 0x22(%rbx)
    2aaa:      	movq	0x38(%rsp), %rax
    2aaf:      	movq	%rax, 0x60(%rsp)
    2ab4:      	movq	(%rip), %rdi            # 0x2abb <generic_usdt_process_event+0x20db>
    2abb:      	leaq	0x60(%rsp), %rsi
    2ac0:      	movl	$0x1, %eax
    2ac5:      	callq	*%rax
    2ac7:      	testq	%rax, %rax
    2aca:      	je	0x3fdb <generic_usdt_process_event+0x35fb>
    2ad0:      	movl	(%rax), %ecx
    2ad2:      	movq	0x8(%rsp), %rbx
    2ad7:      	movl	%ecx, 0x10(%rbx)
    2ada:      	movq	0x8(%rax), %rcx
    2ade:      	movq	%rcx, 0x18(%rbx)
    2ae2:      	movl	0x4(%rax), %eax
    2ae5:      	movl	%eax, 0x7c(%rbx)
    2ae8:      	movl	$0x40, %r13d
    2aee:      	jmp	0x194f <generic_usdt_process_event+0xf6f>
    2af3:      	movl	$0xe, %eax
    2af8:      	callq	*%rax
    2afa:      	cmpq	$-0x16, %rax
    2afe:      	jne	0x2b27 <generic_usdt_process_event+0x2147>
    2b00:      	movq	0xa8(%rsp), %rax
    2b08:      	leaq	0x20(%rax), %rdx
    2b0c:      	leaq	0x60(%rsp), %rdi
    2b11:      	movl	$0x8, %ecx
    2b16:      	movl	$0x4, %eax
    2b1b:      	movl	$0x8, %esi
    2b20:      	callq	*%rax
    2b22:      	movq	0x60(%rsp), %rax
    2b27:      	movq	0x8(%rbx), %rcx
    2b2b:      	movq	0x60(%rbx), %rdx
    2b2f:      	movq	%rcx, 0x60(%rsp)
    2b34:      	movq	0x28(%rsp), %rcx
    2b39:      	movq	%rcx, 0x68(%rsp)
    2b3e:      	movq	$0x0, 0x70(%rsp)
    2b47:      	movq	%rdx, 0x50(%rsp)
    2b4c:      	movq	%rax, 0x58(%rsp)
    2b51:      	movq	(%rip), %rdi            # 0x2b58 <generic_usdt_process_event+0x2178>
    2b58:      	xorl	%ecx, %ecx
    2b5a:      	leaq	0x50(%rsp), %rsi
    2b5f:      	leaq	0x60(%rsp), %rdx
    2b64:      	movl	$0x2, %eax
    2b69:      	xorl	%ecx, %ecx
    2b6b:      	callq	*%rax
    2b6d:      	testq	%rax, %rax
    2b70:      	je	0x3452 <generic_usdt_process_event+0x2a72>
    2b76:      	negl	%eax
    2b78:      	movw	%ax, 0x40(%rsp)
    2b7d:      	movw	$0x5, 0x42(%rsp)
    2b84:      	movabsq	$0x200000046, %rax      # imm = 0x200000046
    2b8e:      	movq	%rax, 0x44(%rsp)
    2b93:      	movq	(%rip), %rdi            # 0x2b9a <generic_usdt_process_event+0x21ba>
    2b9a:      	leaq	0x40(%rsp), %rsi
    2b9f:      	movl	$0x1, %eax
    2ba4:      	callq	*%rax
    2ba6:      	testq	%rax, %rax
    2ba9:      	je	0x3428 <generic_usdt_process_event+0x2a48>
    2baf:      	incl	(%rax)
    2bb1:      	jmp	0x3452 <generic_usdt_process_event+0x2a72>
    2bb6:      	cmpl	$0x1, %eax
    2bb9:      	je	0x2ef5 <generic_usdt_process_event+0x2515>
    2bbf:      	cmpl	$0x2, %eax
    2bc2:      	jne	0x330c <generic_usdt_process_event+0x292c>
    2bc8:      	movq	%rbx, %rax
    2bcb:      	addq	$0x5e58, %rax           # imm = 0x5E58
    2bd1:      	jmp	0x2efe <generic_usdt_process_event+0x251e>
    2bd6:      	movq	0x20(%rsp), %rbx
    2bdb:      	leaq	0x8(%rbx), %rdi
    2bdf:      	leaq	0x8(%r15), %rdx
    2be3:      	movl	$0x10, %ecx
    2be8:      	movl	$0x4, %eax
    2bed:      	movl	$0x10, %esi
    2bf2:      	callq	*%rax
    2bf4:      	leaq	0x2(%rbx), %rdi
    2bf8:      	addq	$0x2, %r15
    2bfc:      	movl	$0x2, %ecx
    2c01:      	movl	$0x4, %eax
    2c06:      	movl	$0x2, %esi
    2c0b:      	movq	%r15, %rdx
    2c0e:      	callq	*%rax
    2c10:      	movq	0x20(%rsp), %rcx
    2c15:      	movzwl	0x2(%rcx), %eax
    2c19:      	movbew	%ax, 0x2(%rcx)
    2c1f:      	movq	0x30(%rsp), %rbp
    2c24:      	movl	$0x18, %r13d
    2c2a:      	movq	(%rsp), %rcx
    2c2e:      	movq	0xa8(%rsp), %r12
    2c36:      	testl	%r13d, %r13d
    2c39:      	movq	0xe0(%rsp), %rax
    2c41:      	movl	$0x4, %edx
    2c46:      	js	0x2c60 <generic_usdt_process_event+0x2280>
    2c48:      	andl	$0x7fffffff, %r13d      # imm = 0x7FFFFFFF
    2c4f:      	addl	$0x4, %r13d
    2c53:      	movl	%r13d, %edx
    2c56:      	movq	0xc0(%rsp), %r13
    2c5e:      	jmp	0x2c7f <generic_usdt_process_event+0x229f>
    2c60:      	movl	$0xffffffff, 0x5ea0(%rcx,%rax,4) # imm = 0xFFFFFFFF
    2c6b:      	movq	0xc0(%rsp), %r13
    2c73:      	movl	$0xffffffff, 0x90(%rcx,%r13) # imm = 0xFFFFFFFF
    2c7f:      	addl	%r13d, %edx
    2c82:      	movl	%edx, %r13d
    2c85:      	movl	%r13d, 0x4(%r14)
    2c89:      	cmpl	$0x3, %ebp
    2c8c:      	jle	0x1086 <generic_usdt_process_event+0x6a6>
    2c92:      	movl	$0x0, 0x5efc(%r14)
    2c9d:      	movq	(%rip), %rsi            # 0x2ca4 <generic_usdt_process_event+0x22c4>
    2ca4:      	movl	$0x3, %ecx
    2ca9:      	movl	$0xc, %eax
    2cae:      	movq	%r12, %rdi
    2cb1:      	movl	$0x3, %edx
    2cb6:      	callq	*%rax
    2cb8:      	xorl	%eax, %eax
    2cba:      	addq	$0x108, %rsp            # imm = 0x108
    2cc1:      	popq	%rbx
    2cc2:      	popq	%r12
    2cc4:      	popq	%r13
    2cc6:      	popq	%r14
    2cc8:      	popq	%r15
    2cca:      	popq	%rbp
    2ccb:      	retq
    2ccc:      	leaq	0x10(%r15), %rdi
    2cd0:      	movq	0x60(%rsp), %rcx
    2cd5:      	movl	$0x3f, %edx
    2cda:      	movl	$0x2d, %eax
    2cdf:      	movq	0x60(%rsp), %rdx
    2ce4:      	movl	$0x3f, %esi
    2ce9:      	callq	*%rax
    2ceb:      	testq	%rax, %rax
    2cee:      	js	0x2954 <generic_usdt_process_event+0x1f74>
    2cf4:      	movq	%rbp, %rbx
    2cf7:      	leaq	0x8(%rbp), %rdx
    2cfb:      	leaq	0x50(%rsp), %rdi
    2d00:      	movl	$0x8, %ecx
    2d05:      	movl	$0x4, %eax
    2d0a:      	movl	$0x8, %esi
    2d0f:      	callq	*%rax
    2d11:      	leaq	0x8(%r15), %rdi
    2d15:      	movl	$0x348, %edx            # imm = 0x348
    2d1a:      	movq	0x50(%rsp), %rcx
    2d1f:      	addq	%rdx, %rcx
    2d22:      	movl	$0x8, %esi
    2d27:      	movl	$0x4, %eax
    2d2c:      	addq	0x50(%rsp), %rdx
    2d31:      	movl	$0x8, %esi
    2d36:      	callq	*%rax
    2d38:      	addq	$0x58, %rbx
    2d3c:      	leaq	0x50(%rsp), %rdi
    2d41:      	movl	$0x4, %ecx
    2d46:      	movl	$0x4, %eax
    2d4b:      	movl	$0x4, %esi
    2d50:      	movq	%rbx, %rdx
    2d53:      	callq	*%rax
    2d55:      	movl	$0x50, %r13d
    2d5b:      	testq	%rax, %rax
    2d5e:      	jne	0x2957 <generic_usdt_process_event+0x1f77>
    2d64:      	xorl	%eax, %eax
    2d66:      	cmpl	$0x0, 0x50(%rsp)
    2d6b:      	setne	%al
    2d6e:      	movl	%eax, (%r15)
    2d71:      	jmp	0x2957 <generic_usdt_process_event+0x1f77>
    2d76:      	xorl	%r13d, %r13d
    2d79:      	movq	%rbx, %rcx
    2d7c:      	jmp	0x295b <generic_usdt_process_event+0x1f7b>
    2d81:      	addq	$0x90, %rbp
    2d88:      	movq	0xc0(%rsp), %rax
    2d90:      	movl	$0x0, 0x4(%rbp,%rax)
    2d98:      	addq	%rbp, %rax
    2d9b:      	addq	$0x8, %rax
    2d9f:      	movq	%rax, 0x18(%rsp)
    2da4:      	movl	$0xc, %ebx
    2da9:      	movq	0x28(%rsp), %rax
    2dae:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    2db4:      	movl	$0xfff, %r12d           # imm = 0xFFF
    2dba:      	cmovbq	%rax, %r12
    2dbe:      	movq	0x18(%rsp), %rax
    2dc3:      	leaq	0x8(%rax), %rdi
    2dc7:      	movl	$0x4, %eax
    2dcc:      	movq	0x20(%rsp), %rdx
    2dd1:      	movl	$0x4, %r13d
    2dd7:      	movl	%r12d, %esi
    2dda:      	callq	*%rax
    2ddc:      	testl	%eax, %eax
    2dde:      	js	0x2dfb <generic_usdt_process_event+0x241b>
    2de0:      	movq	0x18(%rsp), %rax
    2de5:      	movq	0x28(%rsp), %rcx
    2dea:      	movl	%ecx, (%rax)
    2dec:      	movl	%r12d, 0x4(%rax)
    2df0:      	addq	%r12, %rbx
    2df3:      	movq	%rbx, %r13
    2df6:      	jmp	0x194f <generic_usdt_process_event+0xf6f>
    2dfb:      	movq	0x18(%rsp), %rax
    2e00:      	movl	$0xfffffffe, (%rax)     # imm = 0xFFFFFFFE
    2e06:      	jmp	0x194f <generic_usdt_process_event+0xf6f>
    2e0b:      	cmpl	$0x1, %r15d
    2e0f:      	je	0x34db <generic_usdt_process_event+0x2afb>
    2e15:      	cmpl	$0x2, %r15d
    2e19:      	jne	0x34e5 <generic_usdt_process_event+0x2b05>
    2e1f:      	leaq	0x5e58(%rbx), %rax
    2e26:      	jmp	0x34e2 <generic_usdt_process_event+0x2b02>
    2e2b:      	leaq	0x48(%r15), %rdx
    2e2f:      	movl	$0x10, %ecx
    2e34:      	movl	$0x4, %eax
    2e39:      	movq	%rbx, %rdi
    2e3c:      	movl	$0x10, %esi
    2e41:      	callq	*%rax
    2e43:      	leaq	0x38(%r15), %rdx
    2e47:      	movl	$0x10, %ecx
    2e4c:      	movl	$0x4, %eax
    2e51:      	movq	%r12, %rdi
    2e54:      	movl	$0x10, %esi
    2e59:      	callq	*%rax
    2e5b:      	movq	%rbx, %r13
    2e5e:      	leaq	0x20(%rbx), %rdi
    2e62:      	leaq	0xc(%r15), %r12
    2e66:      	addq	$0xe, %r15
    2e6a:      	movl	$0x2, %ecx
    2e6f:      	movl	$0x4, %eax
    2e74:      	movl	$0x2, %esi
    2e79:      	movq	%r15, %rdx
    2e7c:      	callq	*%rax
    2e7e:      	leaq	0x22(%rbx), %rdi
    2e82:      	movl	$0x2, %ecx
    2e87:      	movl	$0x4, %eax
    2e8c:      	movl	$0x2, %esi
    2e91:      	movq	%r12, %rdx
    2e94:      	callq	*%rax
    2e96:      	movzwl	0x22(%rbx), %eax
    2e9a:      	movbew	%ax, 0x22(%rbx)
    2ea0:      	movq	0x28(%rbx), %rax
    2ea4:      	movq	%rax, 0x60(%rsp)
    2ea9:      	movq	(%rip), %rdi            # 0x2eb0 <generic_usdt_process_event+0x24d0>
    2eb0:      	leaq	0x60(%rsp), %rsi
    2eb5:      	movl	$0x1, %eax
    2eba:      	callq	*%rax
    2ebc:      	testq	%rax, %rax
    2ebf:      	je	0x2ed4 <generic_usdt_process_event+0x24f4>
    2ec1:      	movl	(%rax), %ecx
    2ec3:      	movl	%ecx, 0x10(%rbp)
    2ec6:      	movq	0x8(%rax), %rcx
    2eca:      	movq	%rcx, 0x18(%rbp)
    2ece:      	movl	0x4(%rax), %eax
    2ed1:      	movl	%eax, 0x7c(%rbp)
    2ed4:      	movl	$0x40, %r13d
    2eda:      	jmp	0x2957 <generic_usdt_process_event+0x1f77>
    2edf:      	movq	%rbx, %rax
    2ee2:      	addq	$0x5e60, %rax           # imm = 0x5E60
    2ee8:      	jmp	0x2efe <generic_usdt_process_event+0x251e>
    2eea:      	movq	%rbx, %rax
    2eed:      	addq	$0x5e68, %rax           # imm = 0x5E68
    2ef3:      	jmp	0x2efe <generic_usdt_process_event+0x251e>
    2ef5:      	movq	%rbx, %rax
    2ef8:      	addq	$0x5e50, %rax           # imm = 0x5E50
    2efe:      	movq	(%rax), %r12
    2f01:      	testb	$0x10, %r15b
    2f05:      	jne	0x331e <generic_usdt_process_event+0x293e>
    2f0b:      	testq	%r12, %r12
    2f0e:      	je	0x33dd <generic_usdt_process_event+0x29fd>
    2f14:      	leaq	0x60(%rsp), %rdi
    2f19:      	movl	$0x4, %r13d
    2f1f:      	movl	$0x10, %ecx
    2f24:      	movl	$0x4, %eax
    2f29:      	movq	0x28(%rsp), %rdx
    2f2e:      	movl	$0x10, %esi
    2f33:      	movq	%rdx, %r15
    2f36:      	callq	*%rax
    2f38:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2f3d:      	testl	%eax, %eax
    2f3f:      	js	0x32fa <generic_usdt_process_event+0x291a>
    2f45:      	movq	0x68(%rsp), %rbp
    2f4a:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2f4f:      	cmpq	$0xffe, %rbp            # imm = 0xFFE
    2f56:      	ja	0x32fa <generic_usdt_process_event+0x291a>
    2f5c:      	movq	0xc0(%rsp), %rax
    2f64:      	leaq	0xc(%rax), %rbx
    2f68:      	movq	0x20(%rsp), %rax
    2f6d:      	leaq	(%rax,%rbx), %rdi
    2f71:      	movq	0x60(%rsp), %rcx
    2f76:      	movl	$0x4, %eax
    2f7b:      	movq	0x60(%rsp), %rdx
    2f80:      	movl	%ebp, %esi
    2f82:      	callq	*%rax
    2f84:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2f89:      	testl	%eax, %eax
    2f8b:      	js	0x32fa <generic_usdt_process_event+0x291a>
    2f91:      	cmpq	$0x1, %r12
    2f95:      	je	0x33df <generic_usdt_process_event+0x29ff>
    2f9b:      	leaq	0x10(%r15), %rdx
    2f9f:      	leaq	0x60(%rsp), %rdi
    2fa4:      	movl	$0x4, %r13d
    2faa:      	movl	$0x10, %ecx
    2faf:      	movl	$0x4, %eax
    2fb4:      	movl	$0x10, %esi
    2fb9:      	callq	*%rax
    2fbb:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2fc0:      	testl	%eax, %eax
    2fc2:      	js	0x32fa <generic_usdt_process_event+0x291a>
    2fc8:      	movq	0x68(%rsp), %rax
    2fcd:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2fd2:      	movq	%rax, 0x8(%rsp)
    2fd7:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    2fdd:      	ja	0x32fa <generic_usdt_process_event+0x291a>
    2fe3:      	addq	%rbp, %rbx
    2fe6:      	movq	0x20(%rsp), %rax
    2feb:      	leaq	(%rax,%rbx), %rdi
    2fef:      	movq	0x60(%rsp), %rcx
    2ff4:      	movl	$0x4, %eax
    2ff9:      	movq	0x8(%rsp), %rsi
    2ffe:      	movq	0x60(%rsp), %rdx
    3003:      	callq	*%rax
    3005:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    300a:      	testl	%eax, %eax
    300c:      	js	0x32fa <generic_usdt_process_event+0x291a>
    3012:      	addq	0x8(%rsp), %rbp
    3017:      	cmpq	$0x3, %r12
    301b:      	jb	0x33df <generic_usdt_process_event+0x29ff>
    3021:      	leaq	0x20(%r15), %rdx
    3025:      	leaq	0x60(%rsp), %rdi
    302a:      	movl	$0x4, %r13d
    3030:      	movl	$0x10, %ecx
    3035:      	movl	$0x4, %eax
    303a:      	movl	$0x10, %esi
    303f:      	callq	*%rax
    3041:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3046:      	testl	%eax, %eax
    3048:      	js	0x32fa <generic_usdt_process_event+0x291a>
    304e:      	movq	0x68(%rsp), %rax
    3053:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    3058:      	movq	%rax, 0xc8(%rsp)
    3060:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    3066:      	ja	0x32fa <generic_usdt_process_event+0x291a>
    306c:      	movq	0x8(%rsp), %rdi
    3071:      	addq	%rbx, %rdi
    3074:      	movq	%rdi, %rbx
    3077:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    307d:      	addq	0x20(%rsp), %rdi
    3082:      	movq	0x60(%rsp), %rcx
    3087:      	movl	$0x4, %eax
    308c:      	movq	0xc8(%rsp), %rsi
    3094:      	movq	0x60(%rsp), %rdx
    3099:      	callq	*%rax
    309b:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    30a0:      	testl	%eax, %eax
    30a2:      	js	0x32fa <generic_usdt_process_event+0x291a>
    30a8:      	addq	0xc8(%rsp), %rbp
    30b0:      	cmpq	$0x3, %r12
    30b4:      	je	0x33df <generic_usdt_process_event+0x29ff>
    30ba:      	leaq	0x30(%r15), %rdx
    30be:      	leaq	0x60(%rsp), %rdi
    30c3:      	movl	$0x4, %r13d
    30c9:      	movl	$0x10, %ecx
    30ce:      	movl	$0x4, %eax
    30d3:      	movl	$0x10, %esi
    30d8:      	callq	*%rax
    30da:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    30df:      	testl	%eax, %eax
    30e1:      	js	0x32fa <generic_usdt_process_event+0x291a>
    30e7:      	movq	0x68(%rsp), %rax
    30ec:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    30f1:      	movq	%rax, 0x8(%rsp)
    30f6:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    30fc:      	ja	0x32fa <generic_usdt_process_event+0x291a>
    3102:      	movq	0xc8(%rsp), %rdi
    310a:      	addq	%rbx, %rdi
    310d:      	movq	%rdi, 0xc8(%rsp)
    3115:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    311b:      	addq	0x20(%rsp), %rdi
    3120:      	movq	0x60(%rsp), %rcx
    3125:      	movl	$0x4, %eax
    312a:      	movq	0x8(%rsp), %rsi
    312f:      	movq	0x60(%rsp), %rdx
    3134:      	callq	*%rax
    3136:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    313b:      	testl	%eax, %eax
    313d:      	js	0x32fa <generic_usdt_process_event+0x291a>
    3143:      	addq	0x8(%rsp), %rbp
    3148:      	cmpq	$0x5, %r12
    314c:      	jb	0x33df <generic_usdt_process_event+0x29ff>
    3152:      	leaq	0x40(%r15), %rdx
    3156:      	leaq	0x60(%rsp), %rdi
    315b:      	movl	$0x4, %r13d
    3161:      	movl	$0x10, %ecx
    3166:      	movl	$0x4, %eax
    316b:      	movl	$0x10, %esi
    3170:      	callq	*%rax
    3172:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3177:      	testl	%eax, %eax
    3179:      	js	0x32fa <generic_usdt_process_event+0x291a>
    317f:      	movq	0x68(%rsp), %rax
    3184:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    3189:      	movq	%rax, 0xd8(%rsp)
    3191:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    3197:      	ja	0x32fa <generic_usdt_process_event+0x291a>
    319d:      	movq	0x8(%rsp), %rdi
    31a2:      	addq	0xc8(%rsp), %rdi
    31aa:      	movq	%rdi, %rbx
    31ad:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    31b3:      	addq	0x20(%rsp), %rdi
    31b8:      	movq	0x60(%rsp), %rcx
    31bd:      	movl	$0x4, %eax
    31c2:      	movq	0xd8(%rsp), %rsi
    31ca:      	movq	0x60(%rsp), %rdx
    31cf:      	callq	*%rax
    31d1:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    31d6:      	testl	%eax, %eax
    31d8:      	js	0x32fa <generic_usdt_process_event+0x291a>
    31de:      	addq	0xd8(%rsp), %rbp
    31e6:      	cmpq	$0x5, %r12
    31ea:      	je	0x33df <generic_usdt_process_event+0x29ff>
    31f0:      	leaq	0x50(%r15), %rdx
    31f4:      	leaq	0x60(%rsp), %rdi
    31f9:      	movl	$0x4, %r13d
    31ff:      	movl	$0x10, %ecx
    3204:      	movl	$0x4, %eax
    3209:      	movl	$0x10, %esi
    320e:      	callq	*%rax
    3210:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3215:      	testl	%eax, %eax
    3217:      	js	0x32fa <generic_usdt_process_event+0x291a>
    321d:      	movq	0x68(%rsp), %rax
    3222:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    3227:      	movq	%rax, 0x8(%rsp)
    322c:      	cmpq	$0xffe, %rax            # imm = 0xFFE
    3232:      	ja	0x32fa <generic_usdt_process_event+0x291a>
    3238:      	movq	0xd8(%rsp), %rdi
    3240:      	addq	%rbx, %rdi
    3243:      	movq	%rdi, %rbx
    3246:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    324c:      	addq	0x20(%rsp), %rdi
    3251:      	movq	0x60(%rsp), %rcx
    3256:      	movl	$0x4, %eax
    325b:      	movq	0x8(%rsp), %rsi
    3260:      	movq	0x60(%rsp), %rdx
    3265:      	callq	*%rax
    3267:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    326c:      	testl	%eax, %eax
    326e:      	js	0x32fa <generic_usdt_process_event+0x291a>
    3274:      	addq	0x8(%rsp), %rbp
    3279:      	cmpq	$0x7, %r12
    327d:      	jb	0x33df <generic_usdt_process_event+0x29ff>
    3283:      	addq	$0x60, %r15
    3287:      	leaq	0x60(%rsp), %rdi
    328c:      	movl	$0x4, %r13d
    3292:      	movl	$0x10, %ecx
    3297:      	movl	$0x4, %eax
    329c:      	movl	$0x10, %esi
    32a1:      	movq	%r15, %rdx
    32a4:      	callq	*%rax
    32a6:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    32ab:      	testl	%eax, %eax
    32ad:      	js	0x32fa <generic_usdt_process_event+0x291a>
    32af:      	movq	0x68(%rsp), %r15
    32b4:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    32b9:      	cmpq	$0xffe, %r15            # imm = 0xFFE
    32c0:      	ja	0x32fa <generic_usdt_process_event+0x291a>
    32c2:      	movq	0x8(%rsp), %rdi
    32c7:      	addq	%rbx, %rdi
    32ca:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    32d0:      	addq	0x20(%rsp), %rdi
    32d5:      	movq	0x60(%rsp), %rcx
    32da:      	movl	$0x4, %eax
    32df:      	movq	0x60(%rsp), %rdx
    32e4:      	movl	%r15d, %esi
    32e7:      	callq	*%rax
    32e9:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    32ee:      	testl	%eax, %eax
    32f0:      	js	0x32fa <generic_usdt_process_event+0x291a>
    32f2:      	addq	%r15, %rbp
    32f5:      	jmp	0x33df <generic_usdt_process_event+0x29ff>
    32fa:      	movq	0x18(%rsp), %rax
    32ff:      	movq	0x20(%rsp), %rdx
    3304:      	movl	%ecx, (%rdx,%rax)
    3307:      	jmp	0x2957 <generic_usdt_process_event+0x1f77>
    330c:      	xorl	%r12d, %r12d
    330f:      	movl	$0x0, %ebp
    3314:      	testb	$0x10, %r15b
    3318:      	je	0x33df <generic_usdt_process_event+0x29ff>
    331e:      	movl	$0xe, %eax
    3323:      	callq	*%rax
    3325:      	cmpq	$-0x16, %rax
    3329:      	jne	0x3352 <generic_usdt_process_event+0x2972>
    332b:      	movq	0xa8(%rsp), %rax
    3333:      	leaq	0x20(%rax), %rdx
    3337:      	leaq	0x60(%rsp), %rdi
    333c:      	movl	$0x8, %ecx
    3341:      	movl	$0x4, %eax
    3346:      	movl	$0x8, %esi
    334b:      	callq	*%rax
    334d:      	movq	0x60(%rsp), %rax
    3352:      	movq	0x8(%rbx), %rcx
    3356:      	movq	0x60(%rbx), %rdx
    335a:      	movq	%rcx, 0x60(%rsp)
    335f:      	movq	0x28(%rsp), %rcx
    3364:      	movq	%rcx, 0x68(%rsp)
    3369:      	movq	%r12, 0x70(%rsp)
    336e:      	movq	%rdx, 0x50(%rsp)
    3373:      	movq	%rax, 0x58(%rsp)
    3378:      	movq	(%rip), %rdi            # 0x337f <generic_usdt_process_event+0x299f>
    337f:      	xorl	%ecx, %ecx
    3381:      	leaq	0x50(%rsp), %rsi
    3386:      	leaq	0x60(%rsp), %rdx
    338b:      	movl	$0x2, %eax
    3390:      	xorl	%ecx, %ecx
    3392:      	callq	*%rax
    3394:      	testq	%rax, %rax
    3397:      	je	0x3492 <generic_usdt_process_event+0x2ab2>
    339d:      	negl	%eax
    339f:      	movw	%ax, 0x40(%rsp)
    33a4:      	movw	$0x5, 0x42(%rsp)
    33ab:      	movabsq	$0x200000057, %rax      # imm = 0x200000057
    33b5:      	movq	%rax, 0x44(%rsp)
    33ba:      	movq	(%rip), %rdi            # 0x33c1 <generic_usdt_process_event+0x29e1>
    33c1:      	leaq	0x40(%rsp), %rsi
    33c6:      	movl	$0x1, %eax
    33cb:      	callq	*%rax
    33cd:      	testq	%rax, %rax
    33d0:      	je	0x3468 <generic_usdt_process_event+0x2a88>
    33d6:      	incl	(%rax)
    33d8:      	jmp	0x3492 <generic_usdt_process_event+0x2ab2>
    33dd:      	xorl	%ebp, %ebp
    33df:      	movq	0x18(%rsp), %rax
    33e4:      	movq	0x20(%rsp), %rcx
    33e9:      	movl	%ebp, (%rcx,%rax)
    33ec:      	movl	%ebp, 0x4(%rcx,%rax)
    33f0:      	addq	$0x8, %rbp
    33f4:      	movq	%rbp, %r13
    33f7:      	jmp	0x2957 <generic_usdt_process_event+0x1f77>
    33fc:      	cmpl	$0x33, %eax
    33ff:      	je	0x3761 <generic_usdt_process_event+0x2d81>
    3405:      	cmpl	$0x3c, %eax
    3408:      	je	0x34ae <generic_usdt_process_event+0x2ace>
    340e:      	cmpl	$0xff, %eax
    3413:      	jne	0x382f <generic_usdt_process_event+0x2e4f>
    3419:      	movw	$0x28, 0x2(%rbp)
    341f:      	movw	$0x28, %ax
    3423:      	jmp	0x3770 <generic_usdt_process_event+0x2d90>
    3428:      	movl	$0x1, 0xb8(%rsp)
    3433:      	movq	(%rip), %rdi            # 0x343a <generic_usdt_process_event+0x2a5a>
    343a:      	xorl	%ecx, %ecx
    343c:      	leaq	0x40(%rsp), %rsi
    3441:      	leaq	0xb8(%rsp), %rdx
    3449:      	movl	$0x2, %eax
    344e:      	xorl	%ecx, %ecx
    3450:      	callq	*%rax
    3452:      	movq	0x18(%rsp), %rax
    3457:      	movl	$0xfffffffc, (%rax)     # imm = 0xFFFFFFFC
    345d:      	movl	$0x4, %r13d
    3463:      	jmp	0x2957 <generic_usdt_process_event+0x1f77>
    3468:      	movl	$0x1, 0xb0(%rsp)
    3473:      	movq	(%rip), %rdi            # 0x347a <generic_usdt_process_event+0x2a9a>
    347a:      	xorl	%ecx, %ecx
    347c:      	leaq	0x40(%rsp), %rsi
    3481:      	leaq	0xb0(%rsp), %rdx
    3489:      	movl	$0x2, %eax
    348e:      	xorl	%ecx, %ecx
    3490:      	callq	*%rax
    3492:      	movq	0x18(%rsp), %rax
    3497:      	movq	0x20(%rsp), %rcx
    349c:      	movl	$0xfffffffc, (%rcx,%rax) # imm = 0xFFFFFFFC
    34a3:      	movl	$0x4, %r13d
    34a9:      	jmp	0x2957 <generic_usdt_process_event+0x1f77>
    34ae:      	movzbl	0x7(%rbp), %eax
    34b2:      	leal	0x8(,%rax,8), %eax
    34b9:      	jmp	0x376c <generic_usdt_process_event+0x2d8c>
    34be:      	movl	$0x4, %r13d
    34c4:      	jmp	0x194f <generic_usdt_process_event+0xf6f>
    34c9:      	leaq	0x5e60(%rbx), %rax
    34d0:      	jmp	0x34e2 <generic_usdt_process_event+0x2b02>
    34d2:      	leaq	0x5e68(%rbx), %rax
    34d9:      	jmp	0x34e2 <generic_usdt_process_event+0x2b02>
    34db:      	leaq	0x5e50(%rbx), %rax
    34e2:      	movq	(%rax), %rax
    34e5:      	movq	%rax, 0xb0(%rsp)
    34ed:      	leaq	0x38(%rsp), %rdi
    34f2:      	leaq	0xb0(%rsp), %rdx
    34fa:      	movl	$0x8, %ecx
    34ff:      	movl	$0x4, %eax
    3504:      	movl	$0x8, %r13d
    350a:      	movl	$0x8, %esi
    350f:      	callq	*%rax
    3511:      	movq	0x38(%rsp), %rax
    3516:      	movq	%rax, 0x8(%rsp)
    351b:      	testb	$0x20, %r12b
    351f:      	je	0x3695 <generic_usdt_process_event+0x2cb5>
    3525:      	cmpq	$0x1000, 0x8(%rsp)      # imm = 0x1000
    352e:      	jb	0x366c <generic_usdt_process_event+0x2c8c>
    3534:      	movq	0x18(%rsp), %rax
    3539:      	movl	$0x1, (%rax)
    353f:      	movl	$0x0, 0x50(%rsp)
    3547:      	movq	(%rip), %rdi            # 0x354e <generic_usdt_process_event+0x2b6e>
    354e:      	leaq	0x50(%rsp), %rsi
    3553:      	movl	$0x1, %eax
    3558:      	callq	*%rax
    355a:      	testq	%rax, %rax
    355d:      	je	0x36e9 <generic_usdt_process_event+0x2d09>
    3563:      	movq	%rax, %r15
    3566:      	movl	$0x18, (%rax)
    356c:      	movl	$0xe, %eax
    3571:      	callq	*%rax
    3573:      	leaq	0x10(%r15), %rbx
    3577:      	movq	%rax, 0x10(%r15)
    357b:      	cmpq	$-0x16, %rax
    357f:      	jne	0x35ab <generic_usdt_process_event+0x2bcb>
    3581:      	movq	0xa8(%rsp), %rax
    3589:      	leaq	0x20(%rax), %rdx
    358d:      	leaq	0x60(%rsp), %rdi
    3592:      	movl	$0x8, %ecx
    3597:      	movl	$0x4, %eax
    359c:      	movl	$0x8, %esi
    35a1:      	callq	*%rax
    35a3:      	movq	0x60(%rsp), %rax
    35a8:      	movq	%rax, (%rbx)
    35ab:      	movl	$0x7d, %eax
    35b0:      	callq	*%rax
    35b2:      	movq	%rax, 0x18(%r15)
    35b6:      	movq	(%rbx), %rax
    35b9:      	movq	0x8(%rbx), %rcx
    35bd:      	movq	0x18(%rsp), %rdx
    35c2:      	movq	%rax, 0x14(%rdx)
    35c6:      	movq	%rcx, 0x1c(%rdx)
    35ca:      	movq	%r15, %r13
    35cd:      	addq	$0x20, %r13
    35d1:      	movl	$0xa, %r12d
    35d7:      	xorl	%ebx, %ebx
    35d9:      	movq	0x8(%rsp), %rbp
    35de:      	subq	%rbx, %rbp
    35e1:      	js	0x3861 <generic_usdt_process_event+0x2e81>
    35e7:      	movq	0x28(%rsp), %rax
    35ec:      	leaq	(%rbx,%rax), %rdx
    35f0:      	cmpq	$0x7fe0, %rbp           # imm = 0x7FE0
    35f7:      	movl	$0x7fe0, %eax           # imm = 0x7FE0
    35fc:      	cmovaeq	%rax, %rbp
    3600:      	movl	$0x4, %eax
    3605:      	movq	%r13, %rdi
    3608:      	movl	%ebp, %esi
    360a:      	callq	*%rax
    360c:      	testl	%eax, %eax
    360e:      	js	0x363f <generic_usdt_process_event+0x2c5f>
    3610:      	leal	0x20(%rbp), %r8d
    3614:      	movl	%r8d, 0x4(%r15)
    3618:      	movl	$0x19, %eax
    361d:      	movq	0xa8(%rsp), %rdi
    3625:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    362a:      	movq	(%rip), %rsi            # 0x3631 <generic_usdt_process_event+0x2c51>
    3631:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    3636:      	movq	%r15, %rcx
    3639:      	callq	*%rax
    363b:      	testl	%eax, %eax
    363d:      	jns	0x3642 <generic_usdt_process_event+0x2c62>
    363f:      	movslq	%eax, %rbp
    3642:      	testl	%ebp, %ebp
    3644:      	js	0x386a <generic_usdt_process_event+0x2e8a>
    364a:      	andl	$0x7fffffff, %ebp       # imm = 0x7FFFFFFF
    3650:      	addq	%rbp, %rbx
    3653:      	cmpq	0x8(%rsp), %rbx
    3658:      	je	0x38c4 <generic_usdt_process_event+0x2ee4>
    365e:      	decl	%r12d
    3661:      	jne	0x35d9 <generic_usdt_process_event+0x2bf9>
    3667:      	jmp	0x3c00 <generic_usdt_process_event+0x3220>
    366c:      	addq	$0x90, %rbx
    3673:      	movq	0xc0(%rsp), %rax
    367b:      	movl	$0x0, 0x4(%rbx,%rax)
    3683:      	addq	%rbx, %rax
    3686:      	addq	$0x8, %rax
    368a:      	movq	%rax, 0x18(%rsp)
    368f:      	movl	$0xc, %r13d
    3695:      	movq	0x8(%rsp), %rax
    369a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    36a0:      	movl	$0xfff, %r15d           # imm = 0xFFF
    36a6:      	cmovbq	%rax, %r15
    36aa:      	movq	0x18(%rsp), %rax
    36af:      	leaq	0x8(%rax), %rdi
    36b3:      	movl	$0x4, %eax
    36b8:      	movq	0x28(%rsp), %rdx
    36bd:      	movl	%r15d, %esi
    36c0:      	callq	*%rax
    36c2:      	testl	%eax, %eax
    36c4:      	js	0x36de <generic_usdt_process_event+0x2cfe>
    36c6:      	movq	0x18(%rsp), %rax
    36cb:      	movq	0x8(%rsp), %rcx
    36d0:      	movl	%ecx, (%rax)
    36d2:      	movl	%r15d, 0x4(%rax)
    36d6:      	addq	%r15, %r13
    36d9:      	jmp	0x2957 <generic_usdt_process_event+0x1f77>
    36de:      	movq	0x18(%rsp), %rax
    36e3:      	movl	$0xfffffffe, (%rax)     # imm = 0xFFFFFFFE
    36e9:      	movl	$0x4, %r13d
    36ef:      	jmp	0x2957 <generic_usdt_process_event+0x1f77>
    36f4:      	movq	$-0x1, %rbx
    36fb:      	jmp	0x3700 <generic_usdt_process_event+0x2d20>
    36fd:      	movq	%rbp, %rbx
    3700:      	movl	$0x0, 0x60(%rsp)
    3708:      	movq	(%rip), %rdi            # 0x370f <generic_usdt_process_event+0x2d2f>
    370f:      	leaq	0x60(%rsp), %rsi
    3714:      	movl	$0x1, %eax
    3719:      	callq	*%rax
    371b:      	testq	%rax, %rax
    371e:      	je	0x3ab4 <generic_usdt_process_event+0x30d4>
    3724:      	cmpq	$-0xc, %rbx
    3728:      	jg	0x3838 <generic_usdt_process_event+0x2e58>
    372e:      	cmpq	$-0x1c, %rbx
    3732:      	je	0x3a8a <generic_usdt_process_event+0x30aa>
    3738:      	cmpq	$-0x16, %rbx
    373c:      	je	0x3aa2 <generic_usdt_process_event+0x30c2>
    3742:      	cmpq	$-0x10, %rbx
    3746:      	jne	0x3a9a <generic_usdt_process_event+0x30ba>
    374c:      	addq	$0x558, %rax            # imm = 0x558
    3752:      	jmp	0x3ab0 <generic_usdt_process_event+0x30d0>
    3757:      	movq	0x28(%rsp), %rbx
    375c:      	jmp	0x3ab4 <generic_usdt_process_event+0x30d4>
    3761:      	movzbl	0x7(%rbp), %eax
    3765:      	leal	0x8(,%rax,4), %eax
    376c:      	movw	%ax, 0x2(%rbp)
    3770:      	addw	(%rbp), %ax
    3774:      	movw	%ax, (%rbp)
    3778:      	movzbl	0x6(%rbp), %ebx
    377c:      	cmpq	$0x3c, %rbx
    3780:      	ja	0x3fe6 <generic_usdt_process_event+0x3606>
    3786:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3790:      	btq	%rbx, %rcx
    3794:      	jae	0x3fe6 <generic_usdt_process_event+0x3606>
    379a:      	movb	%bl, 0x5(%rbp)
    379d:      	movzwl	%ax, %ecx
    37a0:      	addq	%r15, %rcx
    37a3:      	movl	$0x2, %edx
    37a8:      	movl	$0x4, %eax
    37ad:      	movq	0x8(%rsp), %rdi
    37b2:      	movzwl	(%rbp), %edx
    37b6:      	addq	%r15, %rdx
    37b9:      	movl	$0x2, %esi
    37be:      	callq	*%rax
    37c0:      	testq	%rax, %rax
    37c3:      	js	0x3e31 <generic_usdt_process_event+0x3451>
    37c9:      	movzbl	0x5(%rbp), %eax
    37cd:      	cmpl	$0x32, %eax
    37d0:      	jg	0x37f3 <generic_usdt_process_event+0x2e13>
    37d2:      	testl	%eax, %eax
    37d4:      	je	0x381b <generic_usdt_process_event+0x2e3b>
    37d6:      	cmpl	$0x2b, %eax
    37d9:      	je	0x381b <generic_usdt_process_event+0x2e3b>
    37db:      	cmpl	$0x2c, %eax
    37de:      	jne	0x38df <generic_usdt_process_event+0x2eff>
    37e4:      	movw	$0x8, 0x2(%rbp)
    37ea:      	movw	$0x8, %ax
    37ee:      	jmp	0x38e3 <generic_usdt_process_event+0x2f03>
    37f3:      	cmpl	$0x33, %eax
    37f6:      	je	0x38ce <generic_usdt_process_event+0x2eee>
    37fc:      	cmpl	$0x3c, %eax
    37ff:      	je	0x381b <generic_usdt_process_event+0x2e3b>
    3801:      	cmpl	$0xff, %eax
    3806:      	jne	0x38df <generic_usdt_process_event+0x2eff>
    380c:      	movw	$0x28, 0x2(%rbp)
    3812:      	movw	$0x28, %ax
    3816:      	jmp	0x38e3 <generic_usdt_process_event+0x2f03>
    381b:      	movzbl	0x7(%rbp), %eax
    381f:      	leal	0x8(,%rax,8), %eax
    3826:      	movw	%ax, 0x2(%rbp)
    382a:      	jmp	0x38e3 <generic_usdt_process_event+0x2f03>
    382f:      	movzwl	0x2(%rbp), %eax
    3833:      	jmp	0x3770 <generic_usdt_process_event+0x2d90>
    3838:      	cmpq	$-0xb, %rbx
    383c:      	je	0x3a92 <generic_usdt_process_event+0x30b2>
    3842:      	cmpq	$-0x7, %rbx
    3846:      	je	0x3aaa <generic_usdt_process_event+0x30ca>
    384c:      	cmpq	$-0x2, %rbx
    3850:      	jne	0x3a9a <generic_usdt_process_event+0x30ba>
    3856:      	addq	$0x548, %rax            # imm = 0x548
    385c:      	jmp	0x3ab0 <generic_usdt_process_event+0x30d0>
    3861:      	movq	$-0x1, %rbx
    3868:      	jmp	0x386d <generic_usdt_process_event+0x2e8d>
    386a:      	movq	%rbp, %rbx
    386d:      	movl	$0x0, 0x60(%rsp)
    3875:      	movq	(%rip), %rdi            # 0x387c <generic_usdt_process_event+0x2e9c>
    387c:      	leaq	0x60(%rsp), %rsi
    3881:      	movl	$0x1, %eax
    3886:      	callq	*%rax
    3888:      	testq	%rax, %rax
    388b:      	je	0x3c00 <generic_usdt_process_event+0x3220>
    3891:      	cmpq	$-0xc, %rbx
    3895:      	jg	0x398d <generic_usdt_process_event+0x2fad>
    389b:      	cmpq	$-0x1c, %rbx
    389f:      	je	0x3bd6 <generic_usdt_process_event+0x31f6>
    38a5:      	cmpq	$-0x16, %rbx
    38a9:      	je	0x3bee <generic_usdt_process_event+0x320e>
    38af:      	cmpq	$-0x10, %rbx
    38b3:      	jne	0x3be6 <generic_usdt_process_event+0x3206>
    38b9:      	addq	$0x558, %rax            # imm = 0x558
    38bf:      	jmp	0x3bfc <generic_usdt_process_event+0x321c>
    38c4:      	movq	0x8(%rsp), %rbx
    38c9:      	jmp	0x3c00 <generic_usdt_process_event+0x3220>
    38ce:      	movzbl	0x7(%rbp), %eax
    38d2:      	leal	0x8(,%rax,4), %eax
    38d9:      	movw	%ax, 0x2(%rbp)
    38dd:      	jmp	0x38e3 <generic_usdt_process_event+0x2f03>
    38df:      	movzwl	0x2(%rbp), %eax
    38e3:      	addw	(%rbp), %ax
    38e7:      	movw	%ax, (%rbp)
    38eb:      	movzbl	0x6(%rbp), %ebx
    38ef:      	cmpq	$0x3c, %rbx
    38f3:      	ja	0x3fe6 <generic_usdt_process_event+0x3606>
    38f9:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3903:      	btq	%rbx, %rcx
    3907:      	jae	0x3fe6 <generic_usdt_process_event+0x3606>
    390d:      	movb	%bl, 0x5(%rbp)
    3910:      	movzwl	%ax, %ecx
    3913:      	addq	%r15, %rcx
    3916:      	movl	$0x2, %edx
    391b:      	movl	$0x4, %eax
    3920:      	movq	0x8(%rsp), %rdi
    3925:      	movzwl	(%rbp), %edx
    3929:      	addq	%r15, %rdx
    392c:      	movl	$0x2, %esi
    3931:      	callq	*%rax
    3933:      	testq	%rax, %rax
    3936:      	js	0x3e31 <generic_usdt_process_event+0x3451>
    393c:      	movzbl	0x5(%rbp), %eax
    3940:      	cmpl	$0x32, %eax
    3943:      	jg	0x395f <generic_usdt_process_event+0x2f7f>
    3945:      	testl	%eax, %eax
    3947:      	je	0x397c <generic_usdt_process_event+0x2f9c>
    3949:      	cmpl	$0x2b, %eax
    394c:      	je	0x397c <generic_usdt_process_event+0x2f9c>
    394e:      	cmpl	$0x2c, %eax
    3951:      	jne	0x39c7 <generic_usdt_process_event+0x2fe7>
    3953:      	movw	$0x8, 0x2(%rbp)
    3959:      	movw	$0x8, %ax
    395d:      	jmp	0x39cb <generic_usdt_process_event+0x2feb>
    395f:      	cmpl	$0x33, %eax
    3962:      	je	0x39b6 <generic_usdt_process_event+0x2fd6>
    3964:      	cmpl	$0x3c, %eax
    3967:      	je	0x397c <generic_usdt_process_event+0x2f9c>
    3969:      	cmpl	$0xff, %eax
    396e:      	jne	0x39c7 <generic_usdt_process_event+0x2fe7>
    3970:      	movw	$0x28, 0x2(%rbp)
    3976:      	movw	$0x28, %ax
    397a:      	jmp	0x39cb <generic_usdt_process_event+0x2feb>
    397c:      	movzbl	0x7(%rbp), %eax
    3980:      	leal	0x8(,%rax,8), %eax
    3987:      	movw	%ax, 0x2(%rbp)
    398b:      	jmp	0x39cb <generic_usdt_process_event+0x2feb>
    398d:      	cmpq	$-0xb, %rbx
    3991:      	je	0x3bde <generic_usdt_process_event+0x31fe>
    3997:      	cmpq	$-0x7, %rbx
    399b:      	je	0x3bf6 <generic_usdt_process_event+0x3216>
    39a1:      	cmpq	$-0x2, %rbx
    39a5:      	jne	0x3be6 <generic_usdt_process_event+0x3206>
    39ab:      	addq	$0x548, %rax            # imm = 0x548
    39b1:      	jmp	0x3bfc <generic_usdt_process_event+0x321c>
    39b6:      	movzbl	0x7(%rbp), %eax
    39ba:      	leal	0x8(,%rax,4), %eax
    39c1:      	movw	%ax, 0x2(%rbp)
    39c5:      	jmp	0x39cb <generic_usdt_process_event+0x2feb>
    39c7:      	movzwl	0x2(%rbp), %eax
    39cb:      	addw	(%rbp), %ax
    39cf:      	movw	%ax, (%rbp)
    39d3:      	movzbl	0x6(%rbp), %ebx
    39d7:      	cmpq	$0x3c, %rbx
    39db:      	ja	0x3fe6 <generic_usdt_process_event+0x3606>
    39e1:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    39eb:      	btq	%rbx, %rcx
    39ef:      	jae	0x3fe6 <generic_usdt_process_event+0x3606>
    39f5:      	movb	%bl, 0x5(%rbp)
    39f8:      	movzwl	%ax, %ecx
    39fb:      	addq	%r15, %rcx
    39fe:      	movl	$0x2, %edx
    3a03:      	movl	$0x4, %eax
    3a08:      	movq	0x8(%rsp), %rdi
    3a0d:      	movzwl	(%rbp), %edx
    3a11:      	addq	%r15, %rdx
    3a14:      	movl	$0x2, %esi
    3a19:      	callq	*%rax
    3a1b:      	testq	%rax, %rax
    3a1e:      	js	0x3e31 <generic_usdt_process_event+0x3451>
    3a24:      	movzbl	0x5(%rbp), %eax
    3a28:      	cmpl	$0x32, %eax
    3a2b:      	jg	0x3a4e <generic_usdt_process_event+0x306e>
    3a2d:      	testl	%eax, %eax
    3a2f:      	je	0x3a76 <generic_usdt_process_event+0x3096>
    3a31:      	cmpl	$0x2b, %eax
    3a34:      	je	0x3a76 <generic_usdt_process_event+0x3096>
    3a36:      	cmpl	$0x2c, %eax
    3a39:      	jne	0x3b13 <generic_usdt_process_event+0x3133>
    3a3f:      	movw	$0x8, 0x2(%rbp)
    3a45:      	movw	$0x8, %ax
    3a49:      	jmp	0x3b17 <generic_usdt_process_event+0x3137>
    3a4e:      	cmpl	$0x33, %eax
    3a51:      	je	0x3b02 <generic_usdt_process_event+0x3122>
    3a57:      	cmpl	$0x3c, %eax
    3a5a:      	je	0x3a76 <generic_usdt_process_event+0x3096>
    3a5c:      	cmpl	$0xff, %eax
    3a61:      	jne	0x3b13 <generic_usdt_process_event+0x3133>
    3a67:      	movw	$0x28, 0x2(%rbp)
    3a6d:      	movw	$0x28, %ax
    3a71:      	jmp	0x3b17 <generic_usdt_process_event+0x3137>
    3a76:      	movzbl	0x7(%rbp), %eax
    3a7a:      	leal	0x8(,%rax,8), %eax
    3a81:      	movw	%ax, 0x2(%rbp)
    3a85:      	jmp	0x3b17 <generic_usdt_process_event+0x3137>
    3a8a:      	addq	$0x568, %rax            # imm = 0x568
    3a90:      	jmp	0x3ab0 <generic_usdt_process_event+0x30d0>
    3a92:      	addq	$0x570, %rax            # imm = 0x570
    3a98:      	jmp	0x3ab0 <generic_usdt_process_event+0x30d0>
    3a9a:      	addq	$0x540, %rax            # imm = 0x540
    3aa0:      	jmp	0x3ab0 <generic_usdt_process_event+0x30d0>
    3aa2:      	addq	$0x560, %rax            # imm = 0x560
    3aa8:      	jmp	0x3ab0 <generic_usdt_process_event+0x30d0>
    3aaa:      	addq	$0x550, %rax            # imm = 0x550
    3ab0:      	lock
    3ab1:      	incq	(%rax)
    3ab4:      	testl	%ebx, %ebx
    3ab6:      	js	0x3ad9 <generic_usdt_process_event+0x30f9>
    3ab8:      	movq	0x18(%rsp), %rax
    3abd:      	movq	$0x0, 0x4(%rax)
    3ac5:      	movq	0x28(%rsp), %rdx
    3aca:      	movl	%edx, %ecx
    3acc:      	subl	%ebx, %ecx
    3ace:      	xorl	%eax, %eax
    3ad0:      	cmpq	$-0x1, %rdx
    3ad4:      	cmovnel	%ecx, %eax
    3ad7:      	jmp	0x3aec <generic_usdt_process_event+0x310c>
    3ad9:      	movq	0x18(%rsp), %rax
    3ade:      	movl	%ebx, 0x4(%rax)
    3ae1:      	movl	$0x0, 0x8(%rax)
    3ae8:      	xorl	%eax, %eax
    3aea:      	xorl	%ebx, %ebx
    3aec:      	movq	0x18(%rsp), %rcx
    3af1:      	movl	%eax, 0xc(%rcx)
    3af4:      	movl	%ebx, 0x10(%rcx)
    3af7:      	movl	$0x24, %r13d
    3afd:      	jmp	0x194f <generic_usdt_process_event+0xf6f>
    3b02:      	movzbl	0x7(%rbp), %eax
    3b06:      	leal	0x8(,%rax,4), %eax
    3b0d:      	movw	%ax, 0x2(%rbp)
    3b11:      	jmp	0x3b17 <generic_usdt_process_event+0x3137>
    3b13:      	movzwl	0x2(%rbp), %eax
    3b17:      	addw	(%rbp), %ax
    3b1b:      	movw	%ax, (%rbp)
    3b1f:      	movzbl	0x6(%rbp), %ebx
    3b23:      	cmpq	$0x3c, %rbx
    3b27:      	ja	0x3fe6 <generic_usdt_process_event+0x3606>
    3b2d:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3b37:      	btq	%rbx, %rcx
    3b3b:      	jae	0x3fe6 <generic_usdt_process_event+0x3606>
    3b41:      	movb	%bl, 0x5(%rbp)
    3b44:      	movzwl	%ax, %ecx
    3b47:      	addq	%r15, %rcx
    3b4a:      	movl	$0x2, %edx
    3b4f:      	movl	$0x4, %eax
    3b54:      	movq	0x8(%rsp), %rdi
    3b59:      	movzwl	(%rbp), %edx
    3b5d:      	addq	%r15, %rdx
    3b60:      	movl	$0x2, %esi
    3b65:      	callq	*%rax
    3b67:      	testq	%rax, %rax
    3b6a:      	js	0x3e31 <generic_usdt_process_event+0x3451>
    3b70:      	movzbl	0x5(%rbp), %eax
    3b74:      	cmpl	$0x32, %eax
    3b77:      	jg	0x3b9a <generic_usdt_process_event+0x31ba>
    3b79:      	testl	%eax, %eax
    3b7b:      	je	0x3bc2 <generic_usdt_process_event+0x31e2>
    3b7d:      	cmpl	$0x2b, %eax
    3b80:      	je	0x3bc2 <generic_usdt_process_event+0x31e2>
    3b82:      	cmpl	$0x2c, %eax
    3b85:      	jne	0x3c5f <generic_usdt_process_event+0x327f>
    3b8b:      	movw	$0x8, 0x2(%rbp)
    3b91:      	movw	$0x8, %ax
    3b95:      	jmp	0x3c63 <generic_usdt_process_event+0x3283>
    3b9a:      	cmpl	$0x33, %eax
    3b9d:      	je	0x3c4e <generic_usdt_process_event+0x326e>
    3ba3:      	cmpl	$0x3c, %eax
    3ba6:      	je	0x3bc2 <generic_usdt_process_event+0x31e2>
    3ba8:      	cmpl	$0xff, %eax
    3bad:      	jne	0x3c5f <generic_usdt_process_event+0x327f>
    3bb3:      	movw	$0x28, 0x2(%rbp)
    3bb9:      	movw	$0x28, %ax
    3bbd:      	jmp	0x3c63 <generic_usdt_process_event+0x3283>
    3bc2:      	movzbl	0x7(%rbp), %eax
    3bc6:      	leal	0x8(,%rax,8), %eax
    3bcd:      	movw	%ax, 0x2(%rbp)
    3bd1:      	jmp	0x3c63 <generic_usdt_process_event+0x3283>
    3bd6:      	addq	$0x568, %rax            # imm = 0x568
    3bdc:      	jmp	0x3bfc <generic_usdt_process_event+0x321c>
    3bde:      	addq	$0x570, %rax            # imm = 0x570
    3be4:      	jmp	0x3bfc <generic_usdt_process_event+0x321c>
    3be6:      	addq	$0x540, %rax            # imm = 0x540
    3bec:      	jmp	0x3bfc <generic_usdt_process_event+0x321c>
    3bee:      	addq	$0x560, %rax            # imm = 0x560
    3bf4:      	jmp	0x3bfc <generic_usdt_process_event+0x321c>
    3bf6:      	addq	$0x550, %rax            # imm = 0x550
    3bfc:      	lock
    3bfd:      	incq	(%rax)
    3c00:      	testl	%ebx, %ebx
    3c02:      	js	0x3c25 <generic_usdt_process_event+0x3245>
    3c04:      	movq	0x18(%rsp), %rax
    3c09:      	movq	$0x0, 0x4(%rax)
    3c11:      	movq	0x8(%rsp), %rdx
    3c16:      	movl	%edx, %ecx
    3c18:      	subl	%ebx, %ecx
    3c1a:      	xorl	%eax, %eax
    3c1c:      	cmpq	$-0x1, %rdx
    3c20:      	cmovnel	%ecx, %eax
    3c23:      	jmp	0x3c38 <generic_usdt_process_event+0x3258>
    3c25:      	movq	0x18(%rsp), %rax
    3c2a:      	movl	%ebx, 0x4(%rax)
    3c2d:      	movl	$0x0, 0x8(%rax)
    3c34:      	xorl	%eax, %eax
    3c36:      	xorl	%ebx, %ebx
    3c38:      	movq	0x18(%rsp), %rcx
    3c3d:      	movl	%eax, 0xc(%rcx)
    3c40:      	movl	%ebx, 0x10(%rcx)
    3c43:      	movl	$0x24, %r13d
    3c49:      	jmp	0x2957 <generic_usdt_process_event+0x1f77>
    3c4e:      	movzbl	0x7(%rbp), %eax
    3c52:      	leal	0x8(,%rax,4), %eax
    3c59:      	movw	%ax, 0x2(%rbp)
    3c5d:      	jmp	0x3c63 <generic_usdt_process_event+0x3283>
    3c5f:      	movzwl	0x2(%rbp), %eax
    3c63:      	addw	(%rbp), %ax
    3c67:      	movw	%ax, (%rbp)
    3c6b:      	movzbl	0x6(%rbp), %ebx
    3c6f:      	cmpq	$0x3c, %rbx
    3c73:      	ja	0x3fe6 <generic_usdt_process_event+0x3606>
    3c79:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3c83:      	btq	%rbx, %rcx
    3c87:      	jae	0x3fe6 <generic_usdt_process_event+0x3606>
    3c8d:      	movb	%bl, 0x5(%rbp)
    3c90:      	movzwl	%ax, %ecx
    3c93:      	addq	%r15, %rcx
    3c96:      	movl	$0x2, %edx
    3c9b:      	movl	$0x4, %eax
    3ca0:      	movq	0x8(%rsp), %rdi
    3ca5:      	movzwl	(%rbp), %edx
    3ca9:      	addq	%r15, %rdx
    3cac:      	movl	$0x2, %esi
    3cb1:      	callq	*%rax
    3cb3:      	testq	%rax, %rax
    3cb6:      	js	0x3e31 <generic_usdt_process_event+0x3451>
    3cbc:      	movzbl	0x5(%rbp), %eax
    3cc0:      	cmpl	$0x32, %eax
    3cc3:      	jg	0x3cdf <generic_usdt_process_event+0x32ff>
    3cc5:      	testl	%eax, %eax
    3cc7:      	je	0x3cfc <generic_usdt_process_event+0x331c>
    3cc9:      	cmpl	$0x2b, %eax
    3ccc:      	je	0x3cfc <generic_usdt_process_event+0x331c>
    3cce:      	cmpl	$0x2c, %eax
    3cd1:      	jne	0x3d1e <generic_usdt_process_event+0x333e>
    3cd3:      	movw	$0x8, 0x2(%rbp)
    3cd9:      	movw	$0x8, %ax
    3cdd:      	jmp	0x3d22 <generic_usdt_process_event+0x3342>
    3cdf:      	cmpl	$0x33, %eax
    3ce2:      	je	0x3d0d <generic_usdt_process_event+0x332d>
    3ce4:      	cmpl	$0x3c, %eax
    3ce7:      	je	0x3cfc <generic_usdt_process_event+0x331c>
    3ce9:      	cmpl	$0xff, %eax
    3cee:      	jne	0x3d1e <generic_usdt_process_event+0x333e>
    3cf0:      	movw	$0x28, 0x2(%rbp)
    3cf6:      	movw	$0x28, %ax
    3cfa:      	jmp	0x3d22 <generic_usdt_process_event+0x3342>
    3cfc:      	movzbl	0x7(%rbp), %eax
    3d00:      	leal	0x8(,%rax,8), %eax
    3d07:      	movw	%ax, 0x2(%rbp)
    3d0b:      	jmp	0x3d22 <generic_usdt_process_event+0x3342>
    3d0d:      	movzbl	0x7(%rbp), %eax
    3d11:      	leal	0x8(,%rax,4), %eax
    3d18:      	movw	%ax, 0x2(%rbp)
    3d1c:      	jmp	0x3d22 <generic_usdt_process_event+0x3342>
    3d1e:      	movzwl	0x2(%rbp), %eax
    3d22:      	addw	(%rbp), %ax
    3d26:      	movw	%ax, (%rbp)
    3d2a:      	movzbl	0x6(%rbp), %ebx
    3d2e:      	cmpq	$0x3c, %rbx
    3d32:      	ja	0x3fe6 <generic_usdt_process_event+0x3606>
    3d38:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3d42:      	btq	%rbx, %rcx
    3d46:      	jae	0x3fe6 <generic_usdt_process_event+0x3606>
    3d4c:      	movb	%bl, 0x5(%rbp)
    3d4f:      	movzwl	%ax, %ecx
    3d52:      	addq	%r15, %rcx
    3d55:      	movl	$0x2, %edx
    3d5a:      	movl	$0x4, %eax
    3d5f:      	movq	0x8(%rsp), %rdi
    3d64:      	movzwl	(%rbp), %edx
    3d68:      	addq	%r15, %rdx
    3d6b:      	movl	$0x2, %esi
    3d70:      	callq	*%rax
    3d72:      	testq	%rax, %rax
    3d75:      	js	0x3e31 <generic_usdt_process_event+0x3451>
    3d7b:      	movzbl	0x5(%rbp), %eax
    3d7f:      	cmpl	$0x32, %eax
    3d82:      	jg	0x3d9e <generic_usdt_process_event+0x33be>
    3d84:      	testl	%eax, %eax
    3d86:      	je	0x3dbb <generic_usdt_process_event+0x33db>
    3d88:      	cmpl	$0x2b, %eax
    3d8b:      	je	0x3dbb <generic_usdt_process_event+0x33db>
    3d8d:      	cmpl	$0x2c, %eax
    3d90:      	jne	0x3ddd <generic_usdt_process_event+0x33fd>
    3d92:      	movw	$0x8, 0x2(%rbp)
    3d98:      	movw	$0x8, %ax
    3d9c:      	jmp	0x3de1 <generic_usdt_process_event+0x3401>
    3d9e:      	cmpl	$0x33, %eax
    3da1:      	je	0x3dcc <generic_usdt_process_event+0x33ec>
    3da3:      	cmpl	$0x3c, %eax
    3da6:      	je	0x3dbb <generic_usdt_process_event+0x33db>
    3da8:      	cmpl	$0xff, %eax
    3dad:      	jne	0x3ddd <generic_usdt_process_event+0x33fd>
    3daf:      	movw	$0x28, 0x2(%rbp)
    3db5:      	movw	$0x28, %ax
    3db9:      	jmp	0x3de1 <generic_usdt_process_event+0x3401>
    3dbb:      	movzbl	0x7(%rbp), %eax
    3dbf:      	leal	0x8(,%rax,8), %eax
    3dc6:      	movw	%ax, 0x2(%rbp)
    3dca:      	jmp	0x3de1 <generic_usdt_process_event+0x3401>
    3dcc:      	movzbl	0x7(%rbp), %eax
    3dd0:      	leal	0x8(,%rax,4), %eax
    3dd7:      	movw	%ax, 0x2(%rbp)
    3ddb:      	jmp	0x3de1 <generic_usdt_process_event+0x3401>
    3ddd:      	movzwl	0x2(%rbp), %eax
    3de1:      	addw	(%rbp), %ax
    3de5:      	movw	%ax, (%rbp)
    3de9:      	movzbl	0x6(%rbp), %ebx
    3ded:      	cmpq	$0x3c, %rbx
    3df1:      	ja	0x3fe6 <generic_usdt_process_event+0x3606>
    3df7:      	movabsq	$0x1008180000000001, %rcx # imm = 0x1008180000000001
    3e01:      	btq	%rbx, %rcx
    3e05:      	jae	0x3fe6 <generic_usdt_process_event+0x3606>
    3e0b:      	movb	%bl, 0x5(%rbp)
    3e0e:      	movzwl	%ax, %ecx
    3e11:      	addq	%r15, %rcx
    3e14:      	movl	$0x2, %edx
    3e19:      	movl	$0x4, %eax
    3e1e:      	movq	0x8(%rsp), %rdi
    3e23:      	movzwl	(%rbp), %edx
    3e27:      	addq	%r15, %rdx
    3e2a:      	movl	$0x2, %esi
    3e2f:      	callq	*%rax
    3e31:      	xorl	%ebx, %ebx
    3e33:      	movb	%bl, 0xa0(%rsp)
    3e3a:      	movzbl	%bl, %eax
    3e3d:      	movq	0x20(%rsp), %r15
    3e42:      	movw	%ax, 0x24(%r15)
    3e47:      	movw	$0xa, 0x26(%r15)
    3e4e:      	leaq	0x8(%r13), %rdx
    3e52:      	movl	$0x10, %ecx
    3e57:      	movl	$0x4, %eax
    3e5c:      	movq	%r15, %rdi
    3e5f:      	movl	$0x10, %esi
    3e64:      	callq	*%rax
    3e66:      	leaq	0x10(%r15), %rdi
    3e6a:      	addq	$0x18, %r13
    3e6e:      	movl	$0x10, %ecx
    3e73:      	movl	$0x4, %eax
    3e78:      	movl	$0x10, %esi
    3e7d:      	movq	%r13, %rdx
    3e80:      	callq	*%rax
    3e82:      	cmpb	$0x11, %bl
    3e85:      	je	0x3ed7 <generic_usdt_process_event+0x34f7>
    3e87:      	movzbl	%bl, %eax
    3e8a:      	cmpl	$0x6, %eax
    3e8d:      	jne	0x3f22 <generic_usdt_process_event+0x3542>
    3e93:      	movq	0x60(%rsp), %rbx
    3e98:      	movzwl	0xb8(%rsp), %r15d
    3ea1:      	leaq	(%rbx,%r15), %rdx
    3ea5:      	movq	0x20(%rsp), %r13
    3eaa:      	leaq	0x20(%r13), %rdi
    3eae:      	movl	$0x2, %ecx
    3eb3:      	movl	$0x4, %eax
    3eb8:      	movl	$0x2, %esi
    3ebd:      	callq	*%rax
    3ebf:      	leaq	0x22(%r13), %rdi
    3ec3:      	leaq	(%rbx,%r15), %rdx
    3ec7:      	addq	$0x2, %rdx
    3ecb:      	movl	$0x2, %ecx
    3ed0:      	movl	$0x4, %eax
    3ed5:      	jmp	0x3f19 <generic_usdt_process_event+0x3539>
    3ed7:      	movq	0x60(%rsp), %rbx
    3edc:      	movzwl	0xb8(%rsp), %r15d
    3ee5:      	leaq	(%rbx,%r15), %rdx
    3ee9:      	movq	0x20(%rsp), %r13
    3eee:      	leaq	0x20(%r13), %rdi
    3ef2:      	movl	$0x2, %ecx
    3ef7:      	movl	$0x4, %eax
    3efc:      	movl	$0x2, %esi
    3f01:      	callq	*%rax
    3f03:      	leaq	0x22(%r13), %rdi
    3f07:      	leaq	(%rbx,%r15), %rdx
    3f0b:      	addq	$0x2, %rdx
    3f0f:      	movl	$0x2, %ecx
    3f14:      	movl	$0x4, %eax
    3f19:      	movl	$0x2, %esi
    3f1e:      	callq	*%rax
    3f20:      	jmp	0x3f2e <generic_usdt_process_event+0x354e>
    3f22:      	movq	0x20(%rsp), %rax
    3f27:      	movl	$0x0, 0x20(%rax)
    3f2e:      	movq	0x20(%rsp), %rdx
    3f33:      	movzwl	0x20(%rdx), %eax
    3f37:      	movzwl	0x22(%rdx), %ecx
    3f3b:      	movbew	%ax, 0x20(%rdx)
    3f41:      	movbew	%cx, 0x22(%rdx)
    3f47:      	addq	$0xe0, %r12
    3f4e:      	leaq	0x50(%rsp), %rdi
    3f53:      	movl	$0x8, %ecx
    3f58:      	movl	$0x4, %eax
    3f5d:      	movl	$0x4, %ebx
    3f62:      	movl	$0x8, %esi
    3f67:      	movq	%r12, %rdx
    3f6a:      	callq	*%rax
    3f6c:      	movq	0x50(%rsp), %rcx
    3f71:      	testq	%rcx, %rcx
    3f74:      	je	0x3fdb <generic_usdt_process_event+0x35fb>
    3f76:      	addq	$0x5, %rcx
    3f7a:      	leaq	0x40(%rsp), %rdi
    3f7f:      	movl	$0x8, %edx
    3f84:      	movl	$0x4, %eax
    3f89:      	movq	0x50(%rsp), %rdx
    3f8e:      	addq	$0x5, %rdx
    3f92:      	movl	$0x8, %esi
    3f97:      	callq	*%rax
    3f99:      	movq	0x50(%rsp), %r15
    3f9e:      	movq	0x40(%rsp), %r12
    3fa3:      	movq	0x20(%rsp), %r13
    3fa8:      	leaq	0x38(%r13), %rdi
    3fac:      	leaq	(%r15,%r12,8), %rdx
    3fb0:      	addq	$0x44, %rdx
    3fb4:      	movl	$0x4, %eax
    3fb9:      	movl	$0x4, %esi
    3fbe:      	callq	*%rax
    3fc0:      	addq	$0x3c, %r13
    3fc4:      	leaq	(%r15,%r12,8), %rdx
    3fc8:      	addq	$0x45, %rdx
    3fcc:      	movl	$0x4, %eax
    3fd1:      	movq	%r13, %rdi
    3fd4:      	movl	$0x4, %esi
    3fd9:      	callq	*%rax
    3fdb:      	movl	$0x40, %r13d
    3fe1:      	jmp	0x194f <generic_usdt_process_event+0xf6f>
    3fe6:      	movw	%ax, 0xb8(%rsp)
    3fee:      	jmp	0x3e33 <generic_usdt_process_event+0x3453>
    3ff3:      	nopw	%cs:(%rax,%rax)

0000000000004000 <generic_usdt_process_filter>:
    4000:      	pushq	%rbp
    4001:      	pushq	%r15
    4003:      	pushq	%r14
    4005:      	pushq	%r13
    4007:      	pushq	%r12
    4009:      	pushq	%rbx
    400a:      	subq	$0xf8, %rsp
    4011:      	movq	%rdi, %rbp
    4014:      	movl	$0x0, 0xc8(%rsp)
    401f:      	movq	(%rip), %rdi            # 0x4026 <generic_usdt_process_filter+0x26>
    4026:      	leaq	0xc8(%rsp), %rsi
    402e:      	movl	$0x1, %eax
    4033:      	callq	*%rax
    4035:      	testq	%rax, %rax
    4038:      	je	0x62b6 <generic_usdt_process_filter+0x22b6>
    403e:      	movq	%rax, %r12
    4041:      	movl	$0x23, %eax
    4046:      	callq	*%rax
    4048:      	movq	%rax, %rcx
    404b:      	movq	%rax, 0x50(%rsp)
    4050:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    4057:      	leaq	0x48(%rsp), %rdi
    405c:      	movl	$0x4, %edx
    4061:      	movl	$0x71, %eax
    4066:      	movl	$0xaf4, %edx            # imm = 0xAF4
    406b:      	addq	0x50(%rsp), %rdx
    4070:      	movl	$0x4, %esi
    4075:      	callq	*%rax
    4077:      	movl	0x48(%rsp), %eax
    407b:      	movl	%eax, 0x38(%rsp)
    407f:      	movq	(%rip), %rdi            # 0x4086 <generic_usdt_process_filter+0x86>
    4086:      	leaq	0x38(%rsp), %rsi
    408b:      	movl	$0x1, %eax
    4090:      	callq	*%rax
    4092:      	testq	%rax, %rax
    4095:      	movq	%r12, 0x30(%rsp)
    409a:      	je	0x40aa <generic_usdt_process_filter+0xaa>
    409c:      	movq	%rax, %r14
    409f:      	cmpq	$0x0, 0x8(%rax)
    40a4:      	jne	0x4ec2 <generic_usdt_process_filter+0xec2>
    40aa:      	movl	$0xb00, %edx            # imm = 0xB00
    40af:      	movq	0x50(%rsp), %rcx
    40b4:      	addq	%rdx, %rcx
    40b7:      	leaq	0x50(%rsp), %rdi
    40bc:      	movl	$0x8, %esi
    40c1:      	movl	$0x71, %eax
    40c6:      	addq	0x50(%rsp), %rdx
    40cb:      	movl	$0x8, %esi
    40d0:      	callq	*%rax
    40d2:      	movq	0x50(%rsp), %rcx
    40d7:      	testq	%rcx, %rcx
    40da:      	je	0x426f <generic_usdt_process_filter+0x26f>
    40e0:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    40e7:      	leaq	0x48(%rsp), %rdi
    40ec:      	movl	$0x4, %edx
    40f1:      	movl	$0x71, %eax
    40f6:      	movl	$0xaf4, %edx            # imm = 0xAF4
    40fb:      	addq	0x50(%rsp), %rdx
    4100:      	movl	$0x4, %esi
    4105:      	callq	*%rax
    4107:      	movl	0x48(%rsp), %eax
    410b:      	movl	%eax, 0x38(%rsp)
    410f:      	movq	(%rip), %rdi            # 0x4116 <generic_usdt_process_filter+0x116>
    4116:      	leaq	0x38(%rsp), %rsi
    411b:      	movl	$0x1, %eax
    4120:      	callq	*%rax
    4122:      	testq	%rax, %rax
    4125:      	je	0x4135 <generic_usdt_process_filter+0x135>
    4127:      	movq	%rax, %r14
    412a:      	cmpq	$0x0, 0x8(%rax)
    412f:      	jne	0x4ec2 <generic_usdt_process_filter+0xec2>
    4135:      	movl	$0xb00, %edx            # imm = 0xB00
    413a:      	movq	0x50(%rsp), %rcx
    413f:      	addq	%rdx, %rcx
    4142:      	leaq	0x50(%rsp), %rdi
    4147:      	movl	$0x8, %esi
    414c:      	movl	$0x71, %eax
    4151:      	addq	0x50(%rsp), %rdx
    4156:      	movl	$0x8, %esi
    415b:      	callq	*%rax
    415d:      	movq	0x50(%rsp), %rcx
    4162:      	testq	%rcx, %rcx
    4165:      	je	0x426f <generic_usdt_process_filter+0x26f>
    416b:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    4172:      	leaq	0x48(%rsp), %rdi
    4177:      	movl	$0x4, %edx
    417c:      	movl	$0x71, %eax
    4181:      	movl	$0xaf4, %edx            # imm = 0xAF4
    4186:      	addq	0x50(%rsp), %rdx
    418b:      	movl	$0x4, %esi
    4190:      	callq	*%rax
    4192:      	movl	0x48(%rsp), %eax
    4196:      	movl	%eax, 0x38(%rsp)
    419a:      	movq	(%rip), %rdi            # 0x41a1 <generic_usdt_process_filter+0x1a1>
    41a1:      	leaq	0x38(%rsp), %rsi
    41a6:      	movl	$0x1, %eax
    41ab:      	callq	*%rax
    41ad:      	testq	%rax, %rax
    41b0:      	je	0x41c0 <generic_usdt_process_filter+0x1c0>
    41b2:      	movq	%rax, %r14
    41b5:      	cmpq	$0x0, 0x8(%rax)
    41ba:      	jne	0x4ec2 <generic_usdt_process_filter+0xec2>
    41c0:      	movl	$0xb00, %edx            # imm = 0xB00
    41c5:      	movq	0x50(%rsp), %rcx
    41ca:      	addq	%rdx, %rcx
    41cd:      	leaq	0x50(%rsp), %rdi
    41d2:      	movl	$0x8, %esi
    41d7:      	movl	$0x71, %eax
    41dc:      	addq	0x50(%rsp), %rdx
    41e1:      	movl	$0x8, %esi
    41e6:      	callq	*%rax
    41e8:      	movq	0x50(%rsp), %rcx
    41ed:      	testq	%rcx, %rcx
    41f0:      	je	0x426f <generic_usdt_process_filter+0x26f>
    41f2:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    41f9:      	leaq	0x48(%rsp), %rdi
    41fe:      	movl	$0x4, %edx
    4203:      	movl	$0x71, %eax
    4208:      	movl	$0xaf4, %edx            # imm = 0xAF4
    420d:      	addq	0x50(%rsp), %rdx
    4212:      	movl	$0x4, %esi
    4217:      	callq	*%rax
    4219:      	movl	0x48(%rsp), %eax
    421d:      	movl	%eax, 0x38(%rsp)
    4221:      	movq	(%rip), %rdi            # 0x4228 <generic_usdt_process_filter+0x228>
    4228:      	leaq	0x38(%rsp), %rsi
    422d:      	movl	$0x1, %eax
    4232:      	callq	*%rax
    4234:      	testq	%rax, %rax
    4237:      	je	0x4247 <generic_usdt_process_filter+0x247>
    4239:      	movq	%rax, %r14
    423c:      	cmpq	$0x0, 0x8(%rax)
    4241:      	jne	0x4ec2 <generic_usdt_process_filter+0xec2>
    4247:      	movl	$0xb00, %edx            # imm = 0xB00
    424c:      	movq	0x50(%rsp), %rcx
    4251:      	addq	%rdx, %rcx
    4254:      	leaq	0x50(%rsp), %rdi
    4259:      	movl	$0x8, %esi
    425e:      	movl	$0x71, %eax
    4263:      	addq	0x50(%rsp), %rdx
    4268:      	movl	$0x8, %esi
    426d:      	callq	*%rax
    426f:      	movl	$0x23, %eax
    4274:      	callq	*%rax
    4276:      	movq	%rax, %r13
    4279:      	leaq	0xaf4(%rax), %rdx
    4280:      	leaq	0x50(%rsp), %rdi
    4285:      	movl	$0x4, %ecx
    428a:      	movl	$0x4, %eax
    428f:      	movl	$0x4, %r14d
    4295:      	movl	$0x4, %esi
    429a:      	callq	*%rax
    429c:      	movl	0x50(%rsp), %eax
    42a0:      	movl	%eax, 0x5f10(%r12)
    42a8:      	movl	$0x7d, %eax
    42ad:      	callq	*%rax
    42af:      	movq	%rax, 0x5f18(%r12)
    42b7:      	movl	$0x0, 0x5f20(%r12)
    42c3:      	movq	$0x0, 0x5f28(%r12)
    42cf:      	movl	$0x0, 0x5f30(%r12)
    42db:      	leaq	0x60(%r13), %rdx
    42df:      	leaq	0x38(%rsp), %rdi
    42e4:      	movl	$0x8, %ecx
    42e9:      	movl	$0x71, %eax
    42ee:      	movl	$0x8, %esi
    42f3:      	callq	*%rax
    42f5:      	movq	0x38(%rsp), %rcx
    42fa:      	xorl	%ebx, %ebx
    42fc:      	testq	%rcx, %rcx
    42ff:      	je	0x436e <generic_usdt_process_filter+0x36e>
    4301:      	addq	$0x4, %rcx
    4305:      	leaq	0x48(%rsp), %rdi
    430a:      	movl	$0x4, %edx
    430f:      	movl	$0x71, %eax
    4314:      	movq	0x38(%rsp), %rdx
    4319:      	addq	$0x4, %rdx
    431d:      	movl	$0x4, %esi
    4322:      	callq	*%rax
    4324:      	movl	0x48(%rsp), %eax
    4328:      	testl	%eax, %eax
    432a:      	je	0x436e <generic_usdt_process_filter+0x36e>
    432c:      	movq	0x38(%rsp), %rcx
    4331:      	shll	$0x4, %eax
    4334:      	addq	%rax, %rcx
    4337:      	addq	$0x80, %rcx
    433e:      	leaq	0x50(%rsp), %rdi
    4343:      	movl	$0x10, %edx
    4348:      	movl	$0x71, %eax
    434d:      	movq	0x38(%rsp), %rcx
    4352:      	movl	0x48(%rsp), %edx
    4356:      	shll	$0x4, %edx
    4359:      	addq	%rcx, %rdx
    435c:      	addq	$0x80, %rdx
    4363:      	movl	$0x10, %esi
    4368:      	callq	*%rax
    436a:      	movl	0x50(%rsp), %ebx
    436e:      	movl	%ebx, 0x5f34(%r12)
    4376:      	leaq	0xd00(%r13), %r15
    437d:      	leaq	0x50(%rsp), %rdi
    4382:      	movl	$0x8, %ecx
    4387:      	movl	$0x4, %eax
    438c:      	leaq	0x5f60(%r12), %rbx
    4394:      	movl	$0x8, %esi
    4399:      	movq	%r15, %rdx
    439c:      	callq	*%rax
    439e:      	movq	0x50(%rsp), %r12
    43a3:      	movq	0x30(%rsp), %rax
    43a8:      	leaq	0x5f68(%rax), %rdi
    43af:      	leaq	0x40(%r12), %rdx
    43b4:      	movl	$0x8, %ecx
    43b9:      	movl	$0x4, %eax
    43be:      	movl	$0x8, %esi
    43c3:      	callq	*%rax
    43c5:      	movq	0x30(%rsp), %rax
    43ca:      	leaq	0x5f70(%rax), %rdi
    43d1:      	leaq	0x30(%r12), %rdx
    43d6:      	movl	$0x8, %ecx
    43db:      	movl	$0x4, %eax
    43e0:      	movl	$0x8, %esi
    43e5:      	callq	*%rax
    43e7:      	addq	$0x38, %r12
    43eb:      	movl	$0x8, %ecx
    43f0:      	movl	$0x4, %eax
    43f5:      	movq	%rbx, %rdi
    43f8:      	movl	$0x8, %esi
    43fd:      	movq	%r12, %rdx
    4400:      	movq	0x30(%rsp), %r12
    4405:      	callq	*%rax
    4407:      	leaq	0x5f38(%r12), %rbx
    440f:      	leaq	0xd70(%r13), %rdx
    4416:      	leaq	0x48(%rsp), %rdi
    441b:      	movl	$0x8, %ecx
    4420:      	movl	$0x4, %eax
    4425:      	movl	$0x8, %esi
    442a:      	callq	*%rax
    442c:      	movq	0x48(%rsp), %rcx
    4431:      	leaq	0x50(%rsp), %rdi
    4436:      	movl	$0x48, %edx
    443b:      	movl	$0x4, %eax
    4440:      	movq	0x48(%rsp), %rdx
    4445:      	movl	$0x48, %esi
    444a:      	callq	*%rax
    444c:      	movl	$0x218, %edx            # imm = 0x218
    4451:      	movq	0x58(%rsp), %rcx
    4456:      	addq	%rdx, %rcx
    4459:      	movl	$0x4, %eax
    445e:      	addq	0x58(%rsp), %rdx
    4463:      	movq	%rbx, %rdi
    4466:      	movl	$0x4, %esi
    446b:      	callq	*%rax
    446d:      	leaq	0x5f3c(%r12), %rdi
    4475:      	movl	$0x4d8, %edx            # imm = 0x4D8
    447a:      	movq	0x60(%rsp), %rcx
    447f:      	addq	%rdx, %rcx
    4482:      	movl	$0x4, %eax
    4487:      	addq	0x60(%rsp), %rdx
    448c:      	movl	$0x4, %esi
    4491:      	callq	*%rax
    4493:      	leaq	0x5f40(%r12), %rdi
    449b:      	movq	0x68(%rsp), %rcx
    44a0:      	addq	$0x58, %rcx
    44a4:      	movl	$0x4, %eax
    44a9:      	movq	0x68(%rsp), %rdx
    44ae:      	addq	$0x58, %rdx
    44b2:      	movl	$0x4, %esi
    44b7:      	callq	*%rax
    44b9:      	movq	$0x0, 0xa0(%rsp)
    44c5:      	leaq	0xb58(%r13), %rdx
    44cc:      	leaq	0xa0(%rsp), %rdi
    44d4:      	movl	$0x8, %ecx
    44d9:      	movl	$0x4, %eax
    44de:      	movl	$0x8, %esi
    44e3:      	callq	*%rax
    44e5:      	movq	0xa0(%rsp), %rcx
    44ed:      	testq	%rcx, %rcx
    44f0:      	je	0x45a9 <generic_usdt_process_filter+0x5a9>
    44f6:      	movl	$0x0, 0xc0(%rsp)
    4501:      	addq	$0x4, %rcx
    4505:      	leaq	0xc0(%rsp), %rdi
    450d:      	movl	$0x4, %edx
    4512:      	movl	$0x4, %eax
    4517:      	movq	0xa0(%rsp), %rdx
    451f:      	addq	$0x4, %rdx
    4523:      	movl	$0x4, %esi
    4528:      	callq	*%rax
    452a:      	movq	0xa0(%rsp), %rax
    4532:      	movslq	0xc0(%rsp), %rcx
    453a:      	shlq	$0x4, %rcx
    453e:      	addq	%rax, %rcx
    4541:      	addq	$0x80, %rcx
    4548:      	leaq	0x38(%rsp), %rdi
    454d:      	movl	$0x10, %edx
    4552:      	movl	$0x4, %eax
    4557:      	movq	0xa0(%rsp), %rcx
    455f:      	movslq	0xc0(%rsp), %rdx
    4567:      	shlq	$0x4, %rdx
    456b:      	addq	%rcx, %rdx
    456e:      	addq	$0x80, %rdx
    4575:      	movl	$0x10, %esi
    457a:      	callq	*%rax
    457c:      	leaq	0x5f44(%r12), %rdi
    4584:      	movl	$0x158, %edx            # imm = 0x158
    4589:      	movq	0x40(%rsp), %rcx
    458e:      	addq	%rdx, %rcx
    4591:      	movl	$0x4, %esi
    4596:      	movl	$0x4, %eax
    459b:      	addq	0x40(%rsp), %rdx
    45a0:      	movl	$0x4, %esi
    45a5:      	callq	*%rax
    45a7:      	jmp	0x45b5 <generic_usdt_process_filter+0x5b5>
    45a9:      	movl	$0x0, 0x5f44(%r12)
    45b5:      	movq	%rbp, 0xb0(%rsp)
    45bd:      	leaq	0x5f48(%r12), %rdi
    45c5:      	movl	$0x158, %ebx            # imm = 0x158
    45ca:      	movq	0x70(%rsp), %rcx
    45cf:      	addq	%rbx, %rcx
    45d2:      	movl	$0x4, %edx
    45d7:      	movl	$0x4, %eax
    45dc:      	movq	0x70(%rsp), %rdx
    45e1:      	addq	%rbx, %rdx
    45e4:      	movl	$0x4, %esi
    45e9:      	callq	*%rax
    45eb:      	leaq	0x5f4c(%r12), %rdi
    45f3:      	movl	$0x118, %edx            # imm = 0x118
    45f8:      	movq	0x78(%rsp), %rcx
    45fd:      	addq	%rdx, %rcx
    4600:      	movl	$0x4, %esi
    4605:      	movl	$0x4, %eax
    460a:      	addq	0x78(%rsp), %rdx
    460f:      	movl	$0x4, %esi
    4614:      	callq	*%rax
    4616:      	leaq	0x5f50(%r12), %rdi
    461e:      	movl	$0x98, %r12d
    4624:      	movq	0x80(%rsp), %rcx
    462c:      	addq	%r12, %rcx
    462f:      	movl	$0x4, %edx
    4634:      	movl	$0x4, %eax
    4639:      	movq	0x80(%rsp), %rdx
    4641:      	addq	%r12, %rdx
    4644:      	movl	$0x4, %esi
    4649:      	callq	*%rax
    464b:      	movq	0x30(%rsp), %rax
    4650:      	leaq	0x5f54(%rax), %rdi
    4657:      	movq	0x88(%rsp), %rcx
    465f:      	addq	%r12, %rcx
    4662:      	movl	$0x4, %edx
    4667:      	movl	$0x4, %eax
    466c:      	addq	0x88(%rsp), %r12
    4674:      	movl	$0x4, %esi
    4679:      	movq	%r12, %rdx
    467c:      	movq	0x30(%rsp), %r12
    4681:      	callq	*%rax
    4683:      	leaq	0x5f58(%r12), %rdi
    468b:      	movq	0x90(%rsp), %rcx
    4693:      	addq	$0x58, %rcx
    4697:      	movl	$0x4, %edx
    469c:      	movl	$0x4, %eax
    46a1:      	movq	0x90(%rsp), %rdx
    46a9:      	addq	$0x58, %rdx
    46ad:      	movl	$0x4, %esi
    46b2:      	callq	*%rax
    46b4:      	movq	$0x0, 0x38(%rsp)
    46bd:      	movq	$0x0, 0xa0(%rsp)
    46c9:      	leaq	0x38(%rsp), %rdi
    46ce:      	movl	$0x8, %ecx
    46d3:      	movl	$0x4, %eax
    46d8:      	movl	$0x8, %esi
    46dd:      	movq	%r15, %rdx
    46e0:      	callq	*%rax
    46e2:      	movl	$0x90, %edx
    46e7:      	movq	0x38(%rsp), %rcx
    46ec:      	addq	%rdx, %rcx
    46ef:      	leaq	0xa0(%rsp), %rdi
    46f7:      	movl	$0x8, %esi
    46fc:      	movl	$0x4, %eax
    4701:      	addq	0x38(%rsp), %rdx
    4706:      	movl	$0x8, %esi
    470b:      	callq	*%rax
    470d:      	leaq	0x5f5c(%r12), %rdi
    4715:      	movq	0xa0(%rsp), %rcx
    471d:      	addq	%rbx, %rcx
    4720:      	movl	$0x4, %edx
    4725:      	movl	$0x4, %eax
    472a:      	addq	0xa0(%rsp), %rbx
    4732:      	movl	$0x4, %esi
    4737:      	movq	%rbx, %rdx
    473a:      	callq	*%rax
    473c:      	cmpl	$0x1, 0x5f34(%r12)
    4745:      	jne	0x4750 <generic_usdt_process_filter+0x750>
    4747:      	orb	$0x2, 0x5f33(%r12)
    4750:      	leaq	0x5f78(%r12), %rdi
    4758:      	movl	$0x308, %edx            # imm = 0x308
    475d:      	movq	%rdi, 0xa8(%rsp)
    4765:      	xorl	%esi, %esi
    4767:      	callq	0x476c <generic_usdt_process_filter+0x76c>
    476c:      	leaq	0x6290(%r12), %rax
    4774:      	movq	%rax, 0x8(%rsp)
    4779:      	addq	$0xa78, %r13            # imm = 0xA78
    4780:      	leaq	0x38(%rsp), %rdi
    4785:      	movl	$0x8, %ecx
    478a:      	movl	$0x4, %eax
    478f:      	movl	$0x8, %esi
    4794:      	movq	%r13, %rdx
    4797:      	callq	*%rax
    4799:      	movl	$0x5f8, %edx            # imm = 0x5F8
    479e:      	movq	0x38(%rsp), %rcx
    47a3:      	addq	%rdx, %rcx
    47a6:      	leaq	0x50(%rsp), %rdi
    47ab:      	movl	$0x8, %esi
    47b0:      	movl	$0x4, %eax
    47b5:      	addq	0x38(%rsp), %rdx
    47ba:      	movl	$0x8, %esi
    47bf:      	callq	*%rax
    47c1:      	movq	0x50(%rsp), %rbx
    47c6:      	movl	$0x0, 0xcc(%rsp)
    47d1:      	movq	(%rip), %rdi            # 0x47d8 <generic_usdt_process_filter+0x7d8>
    47d8:      	leaq	0xcc(%rsp), %rsi
    47e0:      	movl	$0x1, %eax
    47e5:      	callq	*%rax
    47e7:      	testq	%rax, %rax
    47ea:      	je	0x4b2c <generic_usdt_process_filter+0xb2c>
    47f0:      	movq	%rax, %r15
    47f3:      	movl	$0x1000, 0x6410(%r12)   # imm = 0x1000
    47ff:      	leaq	0x1000(%rax), %r13
    4806:      	movl	$0x23, %eax
    480b:      	callq	*%rax
    480d:      	leaq	0xd50(%rax), %rdx
    4814:      	leaq	0xe8(%rsp), %rdi
    481c:      	movl	$0x8, %ecx
    4821:      	movl	$0x4, %eax
    4826:      	movl	$0x8, %esi
    482b:      	callq	*%rax
    482d:      	movq	0xe8(%rsp), %r12
    4835:      	leaq	0x48(%rbx), %rbp
    4839:      	leaq	0xf0(%rsp), %rdi
    4841:      	movl	$0x8, %ecx
    4846:      	movl	$0x4, %eax
    484b:      	movl	$0x8, %esi
    4850:      	movq	%rbp, %rdx
    4853:      	callq	*%rax
    4855:      	movq	0xf0(%rsp), %r14
    485d:      	leaq	0x10(%r14), %rdx
    4861:      	leaq	0x50(%rsp), %rdi
    4866:      	movl	$0x8, %ecx
    486b:      	movl	$0x4, %eax
    4870:      	movl	$0x8, %esi
    4875:      	callq	*%rax
    4877:      	cmpq	$0x0, 0x50(%rsp)
    487d:      	je	0x4bb6 <generic_usdt_process_filter+0xbb6>
    4883:      	movq	%rbp, 0xb8(%rsp)
    488b:      	movq	$0x0, 0x58(%rsp)
    4894:      	movq	$0x0, 0x50(%rsp)
    489d:      	movq	%r15, 0x60(%rsp)
    48a2:      	movq	$0x0, 0x68(%rsp)
    48ab:      	movq	$0x0, 0x70(%rsp)
    48b4:      	movq	$0x0, 0x78(%rsp)
    48bd:      	movq	%r13, 0x28(%rsp)
    48c2:      	movq	%r13, 0x80(%rsp)
    48ca:      	movq	0x30(%rsp), %rax
    48cf:      	movl	0x6410(%rax), %eax
    48d5:      	movl	%eax, 0x88(%rsp)
    48dc:      	leaq	0x18(%r12), %r15
    48e1:      	movb	$0x0, 0x8c(%rsp)
    48e9:      	addq	$0x20, %r12
    48ed:      	leaq	0x50(%rsp), %rdi
    48f2:      	movl	$0x8, %r14d
    48f8:      	movl	$0x4, %eax
    48fd:      	addq	$0x40, %rbx
    4901:      	leaq	0x58(%rsp), %r13
    4906:      	leaq	0x68(%rsp), %rbp
    490b:      	movl	$0x8, %esi
    4910:      	movq	%r12, %rdx
    4913:      	callq	*%rax
    4915:      	movl	$0x8, %ecx
    491a:      	movl	$0x4, %eax
    491f:      	movq	%r13, %rdi
    4922:      	movl	$0x8, %esi
    4927:      	movq	%r15, %rdx
    492a:      	callq	*%rax
    492c:      	movl	$0x8, %ecx
    4931:      	movl	$0x4, %eax
    4936:      	movq	0xb8(%rsp), %rdx
    493e:      	movq	%rbp, %rdi
    4941:      	movl	$0x8, %esi
    4946:      	callq	*%rax
    4948:      	movl	$0x8, %ecx
    494d:      	movl	$0x4, %eax
    4952:      	leaq	0x70(%rsp), %rdi
    4957:      	movl	$0x8, %esi
    495c:      	movq	%rbx, %rdx
    495f:      	callq	*%rax
    4961:      	movq	0x70(%rsp), %rax
    4966:      	addq	$-0x20, %rax
    496a:      	movq	%rax, 0x78(%rsp)
    496f:      	movl	$0x80, %ebp
    4974:      	leaq	0x48(%rsp), %rbx
    4979:      	nopl	(%rax)
    4980:      	movq	0x68(%rsp), %r15
    4985:      	movq	0x70(%rsp), %rdx
    498a:      	movq	0x78(%rsp), %r12
    498f:      	cmpq	0x50(%rsp), %r15
    4994:      	jne	0x49a1 <generic_usdt_process_filter+0x9a1>
    4996:      	cmpq	0x58(%rsp), %rdx
    499b:      	je	0x4c15 <generic_usdt_process_filter+0xc15>
    49a1:      	movl	$0x4, %eax
    49a6:      	leaq	0xc0(%rsp), %rdi
    49ae:      	movl	$0x8, %esi
    49b3:      	callq	*%rax
    49b5:      	cmpq	0xc0(%rsp), %r15
    49bd:      	je	0x4ad0 <generic_usdt_process_filter+0xad0>
    49c3:      	leaq	0x18(%r15), %r13
    49c7:      	movl	$0x4, %eax
    49cc:      	movq	%rbx, %rdi
    49cf:      	movl	$0x8, %esi
    49d4:      	movq	%r13, %rdx
    49d7:      	callq	*%rax
    49d9:      	cmpq	%r15, 0x48(%rsp)
    49de:      	je	0x4ad0 <generic_usdt_process_filter+0xad0>
    49e4:      	movl	$0x4, %eax
    49e9:      	leaq	0xa0(%rsp), %rdi
    49f1:      	movl	$0x8, %esi
    49f6:      	movq	%r13, %rdx
    49f9:      	callq	*%rax
    49fb:      	addq	$0x20, %r15
    49ff:      	movl	$0x4, %eax
    4a04:      	leaq	0x38(%rsp), %rdi
    4a09:      	movl	$0x10, %ecx
    4a0e:      	movl	$0x10, %esi
    4a13:      	movq	%r15, %rdx
    4a16:      	callq	*%rax
    4a18:      	movq	0x60(%rsp), %r15
    4a1d:      	movq	0x80(%rsp), %rax
    4a25:      	movl	0x3c(%rsp), %r12d
    4a2a:      	subq	%r15, %rax
    4a2d:      	movl	0x88(%rsp), %r13d
    4a35:      	movl	%r12d, %edx
    4a38:      	subl	%r13d, %edx
    4a3b:      	movl	$0x0, %ecx
    4a40:      	cmovbl	%ecx, %edx
    4a43:      	addq	0x40(%rsp), %rdx
    4a48:      	xorl	%esi, %esi
    4a4a:      	cmpl	%r12d, %r13d
    4a4d:      	seta	%sil
    4a51:      	movl	%r12d, %ecx
    4a54:      	cmovbl	%r13d, %ecx
    4a58:      	addl	%ecx, %esi
    4a5a:      	movl	%r13d, %edi
    4a5d:      	subl	%esi, %edi
    4a5f:      	movl	%edi, 0x88(%rsp)
    4a66:      	subq	%rsi, %rax
    4a69:      	jb	0x4c1d <generic_usdt_process_filter+0xc1d>
    4a6f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    4a75:      	ja	0x4c1d <generic_usdt_process_filter+0xc1d>
    4a7b:      	cmpl	%r12d, %r13d
    4a7e:      	jbe	0x4a85 <generic_usdt_process_filter+0xa85>
    4a80:      	movb	$0x2f, (%r15,%rax)
    4a85:      	xorl	%edi, %edi
    4a87:      	cmpl	%r12d, %r13d
    4a8a:      	seta	%dil
    4a8e:      	movzbl	%cl, %esi
    4a91:      	addq	%rax, %r15
    4a94:      	addq	%r15, %rdi
    4a97:      	movl	$0x4, %eax
    4a9c:      	callq	*%rax
    4a9e:      	movq	%r15, 0x80(%rsp)
    4aa6:      	cmpl	%r12d, %r13d
    4aa9:      	jbe	0x4c1d <generic_usdt_process_filter+0xc1d>
    4aaf:      	movq	0xa0(%rsp), %rax
    4ab7:      	movq	%rax, 0x68(%rsp)
    4abc:      	decl	%ebp
    4abe:      	jne	0x4980 <generic_usdt_process_filter+0x980>
    4ac4:      	jmp	0x4c1d <generic_usdt_process_filter+0xc1d>
    4ac9:      	nopl	(%rax)
    4ad0:      	leaq	0x10(%r12), %rdx
    4ad5:      	movl	$0x4, %eax
    4ada:      	movq	%rbx, %rdi
    4add:      	movl	$0x8, %esi
    4ae2:      	callq	*%rax
    4ae4:      	movq	0x78(%rsp), %rax
    4ae9:      	cmpq	0x48(%rsp), %rax
    4aee:      	je	0x4d4c <generic_usdt_process_filter+0xd4c>
    4af4:      	addq	$0x18, %r12
    4af8:      	movl	$0x4, %eax
    4afd:      	leaq	0x68(%rsp), %rdi
    4b02:      	movl	$0x8, %esi
    4b07:      	movq	%r12, %rdx
    4b0a:      	callq	*%rax
    4b0c:      	movq	0x48(%rsp), %rax
    4b11:      	movq	%rax, 0x78(%rsp)
    4b16:      	addq	$0x20, %rax
    4b1a:      	movq	%rax, 0x70(%rsp)
    4b1f:      	decl	%ebp
    4b21:      	jne	0x4980 <generic_usdt_process_filter+0x980>
    4b27:      	jmp	0x4c1d <generic_usdt_process_filter+0xc1d>
    4b2c:      	movq	0xb0(%rsp), %rbp
    4b34:      	movl	0x6410(%r12), %eax
    4b3c:      	leal	-0x101(%rax), %ecx
    4b42:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    4b48:      	jbe	0x4ea6 <generic_usdt_process_filter+0xea6>
    4b4e:      	movzbl	%al, %ebx
    4b51:      	leaq	0x5f80(%r12), %rdi
    4b59:      	movl	$0x4, %eax
    4b5e:      	movq	0x8(%rsp), %rdx
    4b63:      	movl	%ebx, %esi
    4b65:      	callq	*%rax
    4b67:      	movq	%rax, %r15
    4b6a:      	testq	%rax, %rax
    4b6d:      	je	0x4cad <generic_usdt_process_filter+0xcad>
    4b73:      	movl	%r15d, %eax
    4b76:      	negl	%eax
    4b78:      	movw	%ax, 0x50(%rsp)
    4b7d:      	movw	$0xf, 0x52(%rsp)
    4b84:      	movabsq	$0x400000164, %rax      # imm = 0x400000164
    4b8e:      	movq	%rax, 0x54(%rsp)
    4b93:      	movq	(%rip), %rdi            # 0x4b9a <generic_usdt_process_filter+0xb9a>
    4b9a:      	leaq	0x50(%rsp), %rsi
    4b9f:      	movl	$0x1, %eax
    4ba4:      	callq	*%rax
    4ba6:      	testq	%rax, %rax
    4ba9:      	je	0x4c89 <generic_usdt_process_filter+0xc89>
    4baf:      	incl	(%rax)
    4bb1:      	jmp	0x4cad <generic_usdt_process_filter+0xcad>
    4bb6:      	leaq	0x18(%r14), %rdx
    4bba:      	leaq	0x50(%rsp), %rdi
    4bbf:      	movl	$0x8, %ecx
    4bc4:      	movl	$0x4, %eax
    4bc9:      	movl	$0x8, %esi
    4bce:      	callq	*%rax
    4bd0:      	cmpq	%r14, 0x50(%rsp)
    4bd5:      	je	0x4883 <generic_usdt_process_filter+0x883>
    4bdb:      	movq	0x30(%rsp), %rdx
    4be0:      	movl	0x6410(%rdx), %ecx
    4be6:      	leal	-0xa(%rcx), %eax
    4be9:      	movl	%eax, 0x6410(%rdx)
    4bef:      	cmpl	$0x9, %ecx
    4bf2:      	jg	0x53e9 <generic_usdt_process_filter+0x13e9>
    4bf8:      	movl	$0xffffffdc, 0x6414(%rdx) # imm = 0xFFFFFFDC
    4c02:      	movq	%r13, %rbx
    4c05:      	movq	0xb0(%rsp), %rbp
    4c0d:      	movq	%rdx, %r12
    4c10:      	jmp	0x4d94 <generic_usdt_process_filter+0xd94>
    4c15:      	movb	$0x1, 0x8c(%rsp)
    4c1d:      	movq	0x80(%rsp), %rbx
    4c25:      	movq	0x28(%rsp), %rcx
    4c2a:      	cmpq	%rcx, %rbx
    4c2d:      	je	0x4d6a <generic_usdt_process_filter+0xd6a>
    4c33:      	xorl	%ecx, %ecx
    4c35:      	cmpb	$0x0, 0x8c(%rsp)
    4c3d:      	sete	%cl
    4c40:      	addl	%ecx, %ecx
    4c42:      	movl	0x88(%rsp), %eax
    4c49:      	movq	0x30(%rsp), %r12
    4c4e:      	movl	%eax, 0x6410(%r12)
    4c56:      	movl	%ecx, 0x6414(%r12)
    4c5e:      	testl	%eax, %eax
    4c60:      	movq	0xb0(%rsp), %rbp
    4c68:      	jle	0x4c7b <generic_usdt_process_filter+0xc7b>
    4c6a:      	movl	$0x1000, %ecx           # imm = 0x1000
    4c6f:      	subl	%eax, %ecx
    4c71:      	movl	%ecx, 0x6410(%r12)
    4c79:      	movl	%ecx, %eax
    4c7b:      	testq	%rbx, %rbx
    4c7e:      	jne	0x4d94 <generic_usdt_process_filter+0xd94>
    4c84:      	jmp	0x4e8c <generic_usdt_process_filter+0xe8c>
    4c89:      	movl	$0x1, 0x38(%rsp)
    4c91:      	movq	(%rip), %rdi            # 0x4c98 <generic_usdt_process_filter+0xc98>
    4c98:      	xorl	%ecx, %ecx
    4c9a:      	leaq	0x50(%rsp), %rsi
    4c9f:      	leaq	0x38(%rsp), %rdx
    4ca4:      	movl	$0x2, %eax
    4ca9:      	xorl	%ecx, %ecx
    4cab:      	callq	*%rax
    4cad:      	testl	%r15d, %r15d
    4cb0:      	cmovel	%ebx, %r15d
    4cb4:      	movl	%r15d, 0x5f78(%r12)
    4cbc:      	cmpl	$0x7f, %ebx
    4cbf:      	movl	$0x7f, %esi
    4cc4:      	cmovbl	%ebx, %esi
    4cc7:      	leaq	0x6080(%r12), %rdi
    4ccf:      	leaq	0x6390(%r12), %rdx
    4cd7:      	movl	$0x4, %eax
    4cdc:      	callq	*%rax
    4cde:      	testq	%rax, %rax
    4ce1:      	je	0x4eb4 <generic_usdt_process_filter+0xeb4>
    4ce7:      	negl	%eax
    4ce9:      	movw	%ax, 0x50(%rsp)
    4cee:      	movw	$0xf, 0x52(%rsp)
    4cf5:      	movabsq	$0x40000016a, %rax      # imm = 0x40000016A
    4cff:      	movq	%rax, 0x54(%rsp)
    4d04:      	movq	(%rip), %rdi            # 0x4d0b <generic_usdt_process_filter+0xd0b>
    4d0b:      	leaq	0x50(%rsp), %rsi
    4d10:      	movl	$0x1, %eax
    4d15:      	callq	*%rax
    4d17:      	testq	%rax, %rax
    4d1a:      	je	0x4d23 <generic_usdt_process_filter+0xd23>
    4d1c:      	incl	(%rax)
    4d1e:      	jmp	0x4eb4 <generic_usdt_process_filter+0xeb4>
    4d23:      	movl	$0x1, 0x38(%rsp)
    4d2b:      	movq	(%rip), %rdi            # 0x4d32 <generic_usdt_process_filter+0xd32>
    4d32:      	xorl	%ecx, %ecx
    4d34:      	leaq	0x50(%rsp), %rsi
    4d39:      	leaq	0x38(%rsp), %rdx
    4d3e:      	movl	$0x2, %eax
    4d43:      	xorl	%ecx, %ecx
    4d45:      	callq	*%rax
    4d47:      	jmp	0x4eb4 <generic_usdt_process_filter+0xeb4>
    4d4c:      	movb	$0x1, 0x8c(%rsp)
    4d54:      	movq	0x80(%rsp), %rbx
    4d5c:      	movq	0x28(%rsp), %rcx
    4d61:      	cmpq	%rcx, %rbx
    4d64:      	jne	0x4c33 <generic_usdt_process_filter+0xc33>
    4d6a:      	movq	0x30(%rsp), %r12
    4d6f:      	movl	$0x0, 0x6410(%r12)
    4d7b:      	movl	$0x0, 0x6414(%r12)
    4d87:      	xorl	%eax, %eax
    4d89:      	movq	%rcx, %rbx
    4d8c:      	movq	0xb0(%rsp), %rbp
    4d94:      	xorl	%ecx, %ecx
    4d96:      	movl	%eax, %r14d
    4d99:      	subl	$0x7f, %r14d
    4d9d:      	movl	$0x7f, %r15d
    4da3:      	cmovbl	%eax, %r15d
    4da7:      	cmovbl	%ecx, %r14d
    4dab:      	cmpl	$0xff, %eax
    4db0:      	movl	$0xff, %ecx
    4db5:      	cmovbl	%eax, %ecx
    4db8:      	movzbl	%cl, %esi
    4dbb:      	movl	%esi, 0x6410(%r12)
    4dc3:      	movl	$0x4, %eax
    4dc8:      	movq	0x8(%rsp), %rdi
    4dcd:      	movq	%rbx, %rdx
    4dd0:      	callq	*%rax
    4dd2:      	testq	%rax, %rax
    4dd5:      	je	0x4e34 <generic_usdt_process_filter+0xe34>
    4dd7:      	negl	%eax
    4dd9:      	movw	%ax, 0x50(%rsp)
    4dde:      	movw	$0x8, 0x52(%rsp)
    4de5:      	movabsq	$0x4000002de, %rax      # imm = 0x4000002DE
    4def:      	movq	%rax, 0x54(%rsp)
    4df4:      	movq	(%rip), %rdi            # 0x4dfb <generic_usdt_process_filter+0xdfb>
    4dfb:      	leaq	0x50(%rsp), %rsi
    4e00:      	movl	$0x1, %eax
    4e05:      	callq	*%rax
    4e07:      	testq	%rax, %rax
    4e0a:      	je	0x4e10 <generic_usdt_process_filter+0xe10>
    4e0c:      	incl	(%rax)
    4e0e:      	jmp	0x4e34 <generic_usdt_process_filter+0xe34>
    4e10:      	movl	$0x1, 0x38(%rsp)
    4e18:      	movq	(%rip), %rdi            # 0x4e1f <generic_usdt_process_filter+0xe1f>
    4e1f:      	xorl	%ecx, %ecx
    4e21:      	leaq	0x50(%rsp), %rsi
    4e26:      	leaq	0x38(%rsp), %rdx
    4e2b:      	movl	$0x2, %eax
    4e30:      	xorl	%ecx, %ecx
    4e32:      	callq	*%rax
    4e34:      	leaq	0x6390(%r12), %rdi
    4e3c:      	addq	%r14, %rbx
    4e3f:      	movl	$0x4, %eax
    4e44:      	movl	%r15d, %esi
    4e47:      	movq	%rbx, %rdx
    4e4a:      	callq	*%rax
    4e4c:      	testq	%rax, %rax
    4e4f:      	je	0x4e8c <generic_usdt_process_filter+0xe8c>
    4e51:      	negl	%eax
    4e53:      	movw	%ax, 0x50(%rsp)
    4e58:      	movw	$0x8, 0x52(%rsp)
    4e5f:      	movabsq	$0x4000002e0, %rax      # imm = 0x4000002E0
    4e69:      	movq	%rax, 0x54(%rsp)
    4e6e:      	movq	(%rip), %rdi            # 0x4e75 <generic_usdt_process_filter+0xe75>
    4e75:      	leaq	0x50(%rsp), %rsi
    4e7a:      	movl	$0x1, %eax
    4e7f:      	callq	*%rax
    4e81:      	testq	%rax, %rax
    4e84:      	je	0x53a6 <generic_usdt_process_filter+0x13a6>
    4e8a:      	incl	(%rax)
    4e8c:      	movl	0x6410(%r12), %eax
    4e94:      	leal	-0x101(%rax), %ecx
    4e9a:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    4ea0:      	ja	0x4b4e <generic_usdt_process_filter+0xb4e>
    4ea6:      	movq	0xa8(%rsp), %rax
    4eae:      	movl	$0xffffffff, (%rax)     # imm = 0xFFFFFFFF
    4eb4:      	leaq	0x5f10(%r12), %r14
    4ebc:      	orb	$0x10, 0x1(%r12)
    4ec2:      	leaq	0x5ef8(%r12), %rsi
    4eca:      	movq	(%rip), %rdi            # 0x4ed1 <generic_usdt_process_filter+0xed1>
    4ed1:      	movl	$0x1, %eax
    4ed6:      	callq	*%rax
    4ed8:      	testq	%rax, %rax
    4edb:      	je	0x62b6 <generic_usdt_process_filter+0x22b6>
    4ee1:      	movq	0x5eb8(%r12), %rbx
    4ee9:      	cmpq	$0x6, %rbx
    4eed:      	jae	0x512a <generic_usdt_process_filter+0x112a>
    4ef3:      	movslq	(%rax), %rcx
    4ef6:      	testq	%rcx, %rcx
    4ef9:      	je	0x514f <generic_usdt_process_filter+0x114f>
    4eff:      	cmpq	%rcx, %rbx
    4f02:      	jae	0x512a <generic_usdt_process_filter+0x112a>
    4f08:      	movq	%rax, 0x8(%rsp)
    4f0d:      	movq	%rcx, 0xb8(%rsp)
    4f15:      	movq	%rbp, 0xb0(%rsp)
    4f1d:      	movl	%ebx, 0x50(%rsp)
    4f21:      	movl	$0x0, 0x38(%rsp)
    4f29:      	movq	(%rip), %rdi            # 0x4f30 <generic_usdt_process_filter+0xf30>
    4f30:      	leaq	0x50(%rsp), %rsi
    4f35:      	movl	$0x1, %eax
    4f3a:      	callq	*%rax
    4f3c:      	testq	%rax, %rax
    4f3f:      	movq	%r14, 0x28(%rsp)
    4f44:      	je	0x516e <generic_usdt_process_filter+0x116e>
    4f4a:      	movq	%rax, %r13
    4f4d:      	movl	(%rax), %eax
    4f4f:      	testl	%eax, %eax
    4f51:      	je	0x516e <generic_usdt_process_filter+0x116e>
    4f57:      	cmpl	$0x0, 0x68(%r14)
    4f5c:      	js	0x625c <generic_usdt_process_filter+0x225c>
    4f62:      	cmpl	$0x1b, %eax
    4f65:      	ja	0x625c <generic_usdt_process_filter+0x225c>
    4f6b:      	movl	$0x60, %ecx
    4f70:      	btl	%eax, %ecx
    4f73:      	jb	0x55b8 <generic_usdt_process_filter+0x15b8>
    4f79:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    4f7e:      	btl	%eax, %ecx
    4f81:      	jb	0x5528 <generic_usdt_process_filter+0x1528>
    4f87:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    4f8c:      	btl	%eax, %ecx
    4f8f:      	jae	0x625c <generic_usdt_process_filter+0x225c>
    4f95:      	movq	%r13, %rsi
    4f98:      	addq	$0x4, %rsi
    4f9c:      	movq	(%rip), %rdi            # 0x4fa3 <generic_usdt_process_filter+0xfa3>
    4fa3:      	movl	$0x1, %eax
    4fa8:      	callq	*%rax
    4faa:      	testq	%rax, %rax
    4fad:      	je	0x625c <generic_usdt_process_filter+0x225c>
    4fb3:      	movq	%rax, %r15
    4fb6:      	movq	0x28(%rsp), %rax
    4fbb:      	movl	0x68(%rax), %eax
    4fbe:      	cmpl	$0x7f, %eax
    4fc1:      	movl	$0x7f, %r14d
    4fc7:      	cmovll	%eax, %r14d
    4fcb:      	movq	(%rip), %rdi            # 0x4fd2 <generic_usdt_process_filter+0xfd2>
    4fd2:      	leaq	0x38(%rsp), %rsi
    4fd7:      	movl	$0x1, %eax
    4fdc:      	callq	*%rax
    4fde:      	testq	%rax, %rax
    4fe1:      	je	0x625c <generic_usdt_process_filter+0x225c>
    4fe7:      	movq	%rax, %rbp
    4fea:      	leal	(,%r14,8), %eax
    4ff2:      	movl	%eax, (%rbp)
    4ff5:      	movq	0x28(%rsp), %rax
    4ffa:      	cmpl	$0x0, 0x6c(%rax)
    4ffe:      	jne	0x50f1 <generic_usdt_process_filter+0x10f1>
    5004:      	movq	%r15, 0xa8(%rsp)
    500c:      	movq	0x28(%rsp), %r15
    5011:      	movl	0x68(%r15), %ecx
    5015:      	movl	%ecx, %eax
    5017:      	subl	%r14d, %eax
    501a:      	movl	%r14d, %edx
    501d:      	andl	$0x7f, %edx
    5020:      	addl	%edx, %eax
    5022:      	addl	%ecx, %edx
    5024:      	movl	%r14d, %ecx
    5027:      	notl	%ecx
    5029:      	addl	%edx, %ecx
    502b:      	subl	%r14d, %edx
    502e:      	leal	-0x4(%rdx), %esi
    5031:      	leaq	0x1f3(%r15), %rdi
    5038:      	leal	-0x3(%rdx), %r8d
    503c:      	addl	$-0x2, %edx
    503f:      	movq	$-0x3, %r9
    5046:      	leal	(%rcx,%r9), %r10d
    504a:      	addl	$0x3, %r10d
    504e:      	andl	$0x7f, %r10d
    5052:      	movzbl	0x170(%r15,%r10), %r10d
    505b:      	movb	%r10b, -0x3(%rdi)
    505f:      	leaq	(%rax,%r9), %r10
    5063:      	cmpq	$-0x2, %r10
    5067:      	je	0x50e1 <generic_usdt_process_filter+0x10e1>
    5069:      	leal	(%rdx,%r9), %r11d
    506d:      	addl	$0x3, %r11d
    5071:      	andl	$0x7f, %r11d
    5075:      	movzbl	0x170(%r15,%r11), %r11d
    507e:      	movb	%r11b, -0x2(%rdi)
    5082:      	cmpq	$-0x1, %r10
    5086:      	je	0x50e1 <generic_usdt_process_filter+0x10e1>
    5088:      	leal	(%r8,%r9), %r10d
    508c:      	addl	$0x3, %r10d
    5090:      	andl	$0x7f, %r10d
    5094:      	movzbl	0x170(%r15,%r10), %r10d
    509d:      	movb	%r10b, -0x1(%rdi)
    50a1:      	movq	%rax, %r10
    50a4:      	addq	%r9, %r10
    50a7:      	je	0x50e1 <generic_usdt_process_filter+0x10e1>
    50a9:      	cmpq	$-0x7f, %r9
    50ad:      	je	0x50e1 <generic_usdt_process_filter+0x10e1>
    50af:      	leal	(%rsi,%r9), %r10d
    50b3:      	addl	$0x3, %r10d
    50b7:      	andl	$0x7f, %r10d
    50bb:      	movzbl	0x170(%r15,%r10), %r10d
    50c4:      	movb	%r10b, (%rdi)
    50c7:      	addq	$0x4, %rdi
    50cb:      	leaq	(%rax,%r9), %r10
    50cf:      	addq	$-0x4, %r10
    50d3:      	addq	$-0x4, %r9
    50d7:      	cmpq	$-0x3, %r10
    50db:      	jne	0x5046 <generic_usdt_process_filter+0x1046>
    50e1:      	movl	$0x1, 0x6c(%r15)
    50e9:      	movq	0xa8(%rsp), %r15
    50f1:      	cmpl	$0x7f, %r14d
    50f5:      	ja	0x511d <generic_usdt_process_filter+0x111d>
    50f7:      	movslq	%r14d, %rsi
    50fa:      	movq	%rbp, %rdi
    50fd:      	addq	$0x4, %rdi
    5101:      	movq	0x28(%rsp), %rax
    5106:      	leaq	0x1f0(%rax), %rdx
    510d:      	movl	$0x4, %eax
    5112:      	callq	*%rax
    5114:      	testq	%rax, %rax
    5117:      	js	0x625c <generic_usdt_process_filter+0x225c>
    511d:      	movl	$0x1, %eax
    5122:      	movq	%r15, %rdi
    5125:      	jmp	0x55b3 <generic_usdt_process_filter+0x15b3>
    512a:      	movl	(%r14), %eax
    512d:      	movl	%eax, 0x10(%r12)
    5132:      	movq	0x8(%r14), %rax
    5136:      	movq	%rax, 0x18(%r12)
    513b:      	cmpb	$0x0, 0x5ec0(%r12)
    5144:      	jne	0x62a1 <generic_usdt_process_filter+0x22a1>
    514a:      	jmp	0x62b6 <generic_usdt_process_filter+0x22b6>
    514f:      	movb	$0x1, 0x5ec0(%r12)
    5158:      	movl	(%r14), %eax
    515b:      	movl	%eax, 0x10(%r12)
    5160:      	movq	0x8(%r14), %rax
    5164:      	movq	%rax, 0x18(%r12)
    5169:      	jmp	0x62a1 <generic_usdt_process_filter+0x22a1>
    516e:      	movq	0x8(%rsp), %r10
    5173:      	movq	(%rip), %rax            # 0x517a <generic_usdt_process_filter+0x117a>
    517a:      	cmpb	$0x0, (%rax)
    517d:      	je	0x5420 <generic_usdt_process_filter+0x1420>
    5183:      	movq	(%rip), %rdi            # 0x518a <generic_usdt_process_filter+0x118a>
    518a:      	movl	$0x1, %eax
    518f:      	movq	0x28(%rsp), %rsi
    5194:      	callq	*%rax
    5196:      	movq	0x8(%rsp), %r10
    519b:      	testq	%rax, %rax
    519e:      	je	0x5420 <generic_usdt_process_filter+0x1420>
    51a4:      	movq	%rax, %rbp
    51a7:      	leal	0x5(%rbx), %eax
    51aa:      	movl	%eax, 0x50(%rsp)
    51ae:      	movl	$0x0, 0x38(%rsp)
    51b6:      	movq	(%rip), %rdi            # 0x51bd <generic_usdt_process_filter+0x11bd>
    51bd:      	leaq	0x50(%rsp), %rsi
    51c2:      	movl	$0x1, %eax
    51c7:      	callq	*%rax
    51c9:      	testq	%rax, %rax
    51cc:      	je	0x541b <generic_usdt_process_filter+0x141b>
    51d2:      	movq	%rax, %r13
    51d5:      	movl	(%rax), %eax
    51d7:      	testl	%eax, %eax
    51d9:      	je	0x541b <generic_usdt_process_filter+0x141b>
    51df:      	cmpl	$0x0, (%rbp)
    51e3:      	js	0x625c <generic_usdt_process_filter+0x225c>
    51e9:      	cmpl	$0x1b, %eax
    51ec:      	ja	0x625c <generic_usdt_process_filter+0x225c>
    51f2:      	movl	$0x60, %ecx
    51f7:      	btl	%eax, %ecx
    51fa:      	jb	0x56d6 <generic_usdt_process_filter+0x16d6>
    5200:      	movl	$0x4000100, %ecx        # imm = 0x4000100
    5205:      	btl	%eax, %ecx
    5208:      	jb	0x5648 <generic_usdt_process_filter+0x1648>
    520e:      	movl	$0x8000200, %ecx        # imm = 0x8000200
    5213:      	btl	%eax, %ecx
    5216:      	jae	0x625c <generic_usdt_process_filter+0x225c>
    521c:      	movq	%r13, %rsi
    521f:      	addq	$0x4, %rsi
    5223:      	movq	(%rip), %rdi            # 0x522a <generic_usdt_process_filter+0x122a>
    522a:      	movl	$0x1, %eax
    522f:      	callq	*%rax
    5231:      	testq	%rax, %rax
    5234:      	je	0x625c <generic_usdt_process_filter+0x225c>
    523a:      	movq	%rax, %r15
    523d:      	movl	(%rbp), %eax
    5240:      	cmpl	$0x7f, %eax
    5243:      	movl	$0x7f, %r14d
    5249:      	cmovll	%eax, %r14d
    524d:      	movq	(%rip), %rdi            # 0x5254 <generic_usdt_process_filter+0x1254>
    5254:      	leaq	0x38(%rsp), %rsi
    5259:      	movl	$0x1, %eax
    525e:      	callq	*%rax
    5260:      	testq	%rax, %rax
    5263:      	je	0x625c <generic_usdt_process_filter+0x225c>
    5269:      	movq	%rax, %rcx
    526c:      	leal	(,%r14,8), %eax
    5274:      	movl	%eax, (%rcx)
    5276:      	cmpl	$0x0, 0x4(%rbp)
    527a:      	jne	0x5366 <generic_usdt_process_filter+0x1366>
    5280:      	movq	%rcx, 0xa8(%rsp)
    5288:      	movl	(%rbp), %ecx
    528b:      	movl	%ecx, %eax
    528d:      	subl	%r14d, %eax
    5290:      	movl	%r14d, %edx
    5293:      	andl	$0x7f, %edx
    5296:      	addl	%edx, %eax
    5298:      	addl	%ecx, %edx
    529a:      	movl	%r14d, %ecx
    529d:      	notl	%ecx
    529f:      	addl	%edx, %ecx
    52a1:      	subl	%r14d, %edx
    52a4:      	leal	-0x4(%rdx), %esi
    52a7:      	leaq	0x18b(%rbp), %rdi
    52ae:      	leal	-0x3(%rdx), %r8d
    52b2:      	addl	$-0x2, %edx
    52b5:      	movq	$-0x3, %r9
    52bc:      	leal	(%rcx,%r9), %r10d
    52c0:      	addl	$0x3, %r10d
    52c4:      	andl	$0x7f, %r10d
    52c8:      	movzbl	0x108(%rbp,%r10), %r10d
    52d1:      	movb	%r10b, -0x3(%rdi)
    52d5:      	leaq	(%rax,%r9), %r10
    52d9:      	cmpq	$-0x2, %r10
    52dd:      	je	0x5357 <generic_usdt_process_filter+0x1357>
    52df:      	leal	(%rdx,%r9), %r11d
    52e3:      	addl	$0x3, %r11d
    52e7:      	andl	$0x7f, %r11d
    52eb:      	movzbl	0x108(%rbp,%r11), %r11d
    52f4:      	movb	%r11b, -0x2(%rdi)
    52f8:      	cmpq	$-0x1, %r10
    52fc:      	je	0x5357 <generic_usdt_process_filter+0x1357>
    52fe:      	leal	(%r8,%r9), %r10d
    5302:      	addl	$0x3, %r10d
    5306:      	andl	$0x7f, %r10d
    530a:      	movzbl	0x108(%rbp,%r10), %r10d
    5313:      	movb	%r10b, -0x1(%rdi)
    5317:      	movq	%rax, %r10
    531a:      	addq	%r9, %r10
    531d:      	je	0x5357 <generic_usdt_process_filter+0x1357>
    531f:      	cmpq	$-0x7f, %r9
    5323:      	je	0x5357 <generic_usdt_process_filter+0x1357>
    5325:      	leal	(%rsi,%r9), %r10d
    5329:      	addl	$0x3, %r10d
    532d:      	andl	$0x7f, %r10d
    5331:      	movzbl	0x108(%rbp,%r10), %r10d
    533a:      	movb	%r10b, (%rdi)
    533d:      	addq	$0x4, %rdi
    5341:      	leaq	(%rax,%r9), %r10
    5345:      	addq	$-0x4, %r10
    5349:      	addq	$-0x4, %r9
    534d:      	cmpq	$-0x3, %r10
    5351:      	jne	0x52bc <generic_usdt_process_filter+0x12bc>
    5357:      	movl	$0x1, 0x4(%rbp)
    535e:      	movq	0xa8(%rsp), %rcx
    5366:      	cmpl	$0x7f, %r14d
    536a:      	ja	0x5396 <generic_usdt_process_filter+0x1396>
    536c:      	movslq	%r14d, %rsi
    536f:      	movq	%rcx, %rdi
    5372:      	addq	$0x4, %rdi
    5376:      	addq	$0x188, %rbp            # imm = 0x188
    537d:      	movl	$0x4, %eax
    5382:      	movq	%rbp, %rdx
    5385:      	movq	%rcx, %r14
    5388:      	callq	*%rax
    538a:      	movq	%r14, %rcx
    538d:      	testq	%rax, %rax
    5390:      	js	0x625c <generic_usdt_process_filter+0x225c>
    5396:      	movl	$0x1, %eax
    539b:      	movq	%r15, %rdi
    539e:      	movq	%rcx, %rsi
    53a1:      	jmp	0x5736 <generic_usdt_process_filter+0x1736>
    53a6:      	movl	$0x1, 0x38(%rsp)
    53ae:      	movq	(%rip), %rdi            # 0x53b5 <generic_usdt_process_filter+0x13b5>
    53b5:      	xorl	%ecx, %ecx
    53b7:      	leaq	0x50(%rsp), %rsi
    53bc:      	leaq	0x38(%rsp), %rdx
    53c1:      	movl	$0x2, %eax
    53c6:      	xorl	%ecx, %ecx
    53c8:      	callq	*%rax
    53ca:      	movl	0x6410(%r12), %eax
    53d2:      	leal	-0x101(%rax), %ecx
    53d8:      	cmpl	$0xfffffeff, %ecx       # imm = 0xFFFFFEFF
    53de:      	jbe	0x4ea6 <generic_usdt_process_filter+0xea6>
    53e4:      	jmp	0x4b4e <generic_usdt_process_filter+0xb4e>
    53e9:      	movq	%rbp, 0xb8(%rsp)
    53f1:      	movq	%r15, %r13
    53f4:      	addq	$0xff6, %r13            # imm = 0xFF6
    53fb:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
    5405:      	movq	%rax, 0xff6(%r15)
    540c:      	movw	$0x2964, 0xffe(%r15)    # imm = 0x2964
    5416:      	jmp	0x488b <generic_usdt_process_filter+0x88b>
    541b:      	movq	0x8(%rsp), %r10
    5420:      	movl	%ebx, %eax
    5422:      	leaq	0x4(,%rax,4), %rcx
    542a:      	movl	0x4(%r10,%rax,4), %eax
    542f:      	leal	(%rax,%rcx), %edx
    5432:      	andl	$0x3ff, %edx            # imm = 0x3FF
    5438:      	addl	%eax, %ecx
    543a:      	addl	$0x4, %ecx
    543d:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5443:      	leaq	0x8(%rdx), %rbp
    5447:      	cmpl	$0x5, (%rcx,%r10)
    544c:      	jb	0x551e <generic_usdt_process_filter+0x151e>
    5452:      	movq	%rdx, 0xd8(%rsp)
    545a:      	movl	(%rbp,%r10), %edi
    545f:      	movl	0x4(%rbp,%r10), %r8d
    5464:      	movl	0x8(%rbp,%r10), %edx
    5469:      	movq	$0x0, 0x58(%rsp)
    5472:      	movq	$0x0, 0x50(%rsp)
    547b:      	cmpl	$0x4, %edx
    547e:      	movl	$0x4, %ecx
    5483:      	cmovbl	%edx, %ecx
    5486:      	cmpl	$0x6, %edi
    5489:      	jne	0x549f <generic_usdt_process_filter+0x149f>
    548b:      	movabsq	$0x100000001, %rsi      # imm = 0x100000001
    5495:      	movq	%rsi, 0x50(%rsp)
    549a:      	movq	%rsi, 0x58(%rsp)
    549f:      	testl	%edx, %edx
    54a1:      	movq	0x28(%rsp), %r14
    54a6:      	je	0x5c22 <generic_usdt_process_filter+0x1c22>
    54ac:      	leaq	0x24(%r14), %rdx
    54b0:      	testb	$0x1, %r8b
    54b4:      	movq	%rdx, 0xe0(%rsp)
    54bc:      	movq	%rdx, %r9
    54bf:      	cmoveq	%r14, %r9
    54c3:      	leaq	0x10(%r14), %rdx
    54c7:      	movq	%rdx, 0xd0(%rsp)
    54cf:      	leal	(%rax,%rbx,4), %r11d
    54d3:      	addl	$0x4, %r11d
    54d7:      	andl	$0x3ff, %r11d           # imm = 0x3FF
    54de:      	addq	$0x14, %r11
    54e2:      	decq	%rcx
    54e5:      	cmpq	$0x3, %rcx
    54e9:      	movl	$0x3, %eax
    54ee:      	cmovbq	%rcx, %rax
    54f2:      	movl	%eax, %eax
    54f4:      	leaq	0x4(,%rax,4), %rax
    54fc:      	movq	%rax, 0xa8(%rsp)
    5504:      	xorl	%ebx, %ebx
    5506:      	movl	%edi, 0x4(%rsp)
    550a:      	movq	%r8, 0x20(%rsp)
    550f:      	movq	%r9, 0x18(%rsp)
    5514:      	movq	%r11, 0x10(%rsp)
    5519:      	jmp	0x57bc <generic_usdt_process_filter+0x17bc>
    551e:      	movl	$0x1, %eax
    5523:      	jmp	0x5c63 <generic_usdt_process_filter+0x1c63>
    5528:      	movq	%r13, %rsi
    552b:      	addq	$0x4, %rsi
    552f:      	movq	(%rip), %rdi            # 0x5536 <generic_usdt_process_filter+0x1536>
    5536:      	movl	$0x1, %eax
    553b:      	callq	*%rax
    553d:      	testq	%rax, %rax
    5540:      	je	0x625c <generic_usdt_process_filter+0x225c>
    5546:      	movq	%rax, %r14
    5549:      	movq	(%rip), %rdi            # 0x5550 <generic_usdt_process_filter+0x1550>
    5550:      	leaq	0x38(%rsp), %rsi
    5555:      	movl	$0x1, %eax
    555a:      	callq	*%rax
    555c:      	testq	%rax, %rax
    555f:      	je	0x625c <generic_usdt_process_filter+0x225c>
    5565:      	movq	%rax, %rbp
    5568:      	movl	$0x104, %edx            # imm = 0x104
    556d:      	movq	%rax, %rdi
    5570:      	xorl	%esi, %esi
    5572:      	callq	0x5577 <generic_usdt_process_filter+0x1577>
    5577:      	movq	0x28(%rsp), %rsi
    557c:      	movl	0x68(%rsi), %eax
    557f:      	leal	(,%rax,8), %ecx
    5586:      	movl	%ecx, (%rbp)
    5589:      	movq	%rbp, %rdi
    558c:      	addq	$0x4, %rdi
    5590:      	movzbl	%al, %ecx
    5593:      	leaq	0x70(%rsi), %rdx
    5597:      	movl	$0x4, %eax
    559c:      	movzbl	0x68(%rsi), %esi
    55a0:      	callq	*%rax
    55a2:      	testq	%rax, %rax
    55a5:      	js	0x625c <generic_usdt_process_filter+0x225c>
    55ab:      	movl	$0x1, %eax
    55b0:      	movq	%r14, %rdi
    55b3:      	movq	%rbp, %rsi
    55b6:      	jmp	0x5611 <generic_usdt_process_filter+0x1611>
    55b8:      	movl	0x8(%r13), %eax
    55bc:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    55c1:      	cmpq	%rcx, %rax
    55c4:      	movq	0x28(%rsp), %rcx
    55c9:      	je	0x55e4 <generic_usdt_process_filter+0x15e4>
    55cb:      	movq	0x370(%rcx), %rcx
    55d2:      	btq	%rax, %rcx
    55d6:      	jae	0x55e4 <generic_usdt_process_filter+0x15e4>
    55d8:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    55e2:      	jmp	0x5613 <generic_usdt_process_filter+0x1613>
    55e4:      	movq	(%rip), %rdi            # 0x55eb <generic_usdt_process_filter+0x15eb>
    55eb:      	leaq	0x50(%rsp), %rsi
    55f0:      	movl	$0x1, %eax
    55f5:      	callq	*%rax
    55f7:      	testq	%rax, %rax
    55fa:      	je	0x625c <generic_usdt_process_filter+0x225c>
    5600:      	movq	%rax, %rdi
    5603:      	movq	0x28(%rsp), %rax
    5608:      	leaq	0x70(%rax), %rsi
    560c:      	movl	$0x1, %eax
    5611:      	callq	*%rax
    5613:      	movl	(%r13), %ecx
    5617:      	cmpq	$0x25, %rcx
    561b:      	movq	0x8(%rsp), %r10
    5620:      	ja	0x56fd <generic_usdt_process_filter+0x16fd>
    5626:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    5630:      	btq	%rcx, %rdx
    5634:      	jae	0x56fd <generic_usdt_process_filter+0x16fd>
    563a:      	testq	%rax, %rax
    563d:      	jne	0x625c <generic_usdt_process_filter+0x225c>
    5643:      	jmp	0x5173 <generic_usdt_process_filter+0x1173>
    5648:      	movq	%r13, %rsi
    564b:      	addq	$0x4, %rsi
    564f:      	movq	(%rip), %rdi            # 0x5656 <generic_usdt_process_filter+0x1656>
    5656:      	movl	$0x1, %eax
    565b:      	callq	*%rax
    565d:      	testq	%rax, %rax
    5660:      	je	0x625c <generic_usdt_process_filter+0x225c>
    5666:      	movq	%rax, %r14
    5669:      	movq	(%rip), %rdi            # 0x5670 <generic_usdt_process_filter+0x1670>
    5670:      	leaq	0x38(%rsp), %rsi
    5675:      	movl	$0x1, %eax
    567a:      	callq	*%rax
    567c:      	testq	%rax, %rax
    567f:      	je	0x625c <generic_usdt_process_filter+0x225c>
    5685:      	movq	%rax, %r15
    5688:      	movl	$0x104, %edx            # imm = 0x104
    568d:      	movq	%rax, %rdi
    5690:      	xorl	%esi, %esi
    5692:      	callq	0x5697 <generic_usdt_process_filter+0x1697>
    5697:      	movl	(%rbp), %eax
    569a:      	leal	(,%rax,8), %ecx
    56a1:      	movl	%ecx, (%r15)
    56a4:      	movq	%r15, %rdi
    56a7:      	addq	$0x4, %rdi
    56ab:      	movzbl	%al, %ecx
    56ae:      	movq	%rbp, %rdx
    56b1:      	addq	$0x8, %rdx
    56b5:      	movl	$0x4, %eax
    56ba:      	movzbl	(%rbp), %esi
    56be:      	callq	*%rax
    56c0:      	testq	%rax, %rax
    56c3:      	js	0x625c <generic_usdt_process_filter+0x225c>
    56c9:      	movl	$0x1, %eax
    56ce:      	movq	%r14, %rdi
    56d1:      	movq	%r15, %rsi
    56d4:      	jmp	0x5736 <generic_usdt_process_filter+0x1736>
    56d6:      	movl	0x8(%r13), %eax
    56da:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    56df:      	cmpq	%rcx, %rax
    56e2:      	je	0x570b <generic_usdt_process_filter+0x170b>
    56e4:      	movq	0x308(%rbp), %rcx
    56eb:      	btq	%rax, %rcx
    56ef:      	jae	0x570b <generic_usdt_process_filter+0x170b>
    56f1:      	movabsq	$0xbadc0ffee, %rax      # imm = 0xBADC0FFEE
    56fb:      	jmp	0x5738 <generic_usdt_process_filter+0x1738>
    56fd:      	testq	%rax, %rax
    5700:      	jne	0x5173 <generic_usdt_process_filter+0x1173>
    5706:      	jmp	0x625c <generic_usdt_process_filter+0x225c>
    570b:      	movq	(%rip), %rdi            # 0x5712 <generic_usdt_process_filter+0x1712>
    5712:      	leaq	0x50(%rsp), %rsi
    5717:      	movl	$0x1, %eax
    571c:      	callq	*%rax
    571e:      	testq	%rax, %rax
    5721:      	je	0x625c <generic_usdt_process_filter+0x225c>
    5727:      	movq	%rax, %rdi
    572a:      	addq	$0x8, %rbp
    572e:      	movl	$0x1, %eax
    5733:      	movq	%rbp, %rsi
    5736:      	callq	*%rax
    5738:      	movl	(%r13), %ecx
    573c:      	cmpq	$0x25, %rcx
    5740:      	movq	0x8(%rsp), %r10
    5745:      	ja	0x5765 <generic_usdt_process_filter+0x1765>
    5747:      	movabsq	$0x200c000050, %rdx     # imm = 0x200C000050
    5751:      	btq	%rcx, %rdx
    5755:      	jae	0x5765 <generic_usdt_process_filter+0x1765>
    5757:      	testq	%rax, %rax
    575a:      	jne	0x625c <generic_usdt_process_filter+0x225c>
    5760:      	jmp	0x5420 <generic_usdt_process_filter+0x1420>
    5765:      	testq	%rax, %rax
    5768:      	jne	0x5420 <generic_usdt_process_filter+0x1420>
    576e:      	jmp	0x625c <generic_usdt_process_filter+0x225c>
    5773:      	movq	0x30(%rsp), %r12
    5778:      	movq	0x28(%rsp), %r14
    577d:      	movq	0x8(%rsp), %r10
    5782:      	movl	0x4(%rsp), %edi
    5786:      	movq	0x20(%rsp), %r8
    578b:      	movq	0x18(%rsp), %r9
    5790:      	movq	0x10(%rsp), %r11
    5795:      	cmpl	$0x6, %edi
    5798:      	setne	%al
    579b:      	xorb	$0x1, %r13b
    579f:      	orb	%al, %r13b
    57a2:      	movzbl	%r13b, %eax
    57a6:      	movl	%eax, 0x50(%rsp,%rbx)
    57aa:      	addq	$0x4, %rbx
    57ae:      	cmpq	%rbx, 0xa8(%rsp)
    57b6:      	je	0x5c22 <generic_usdt_process_filter+0x1c22>
    57bc:      	leaq	(%r11,%rbx), %rax
    57c0:      	movl	(%r9), %ecx
    57c3:      	cmpq	$0x3e8, %rax            # imm = 0x3E8
    57c9:      	jbe	0x59f1 <generic_usdt_process_filter+0x19f1>
    57cf:      	xorl	%r15d, %r15d
    57d2:      	testb	$0x2, %r8b
    57d6:      	je	0x5a0e <generic_usdt_process_filter+0x1a0e>
    57dc:      	testb	$0x1, %r8b
    57e0:      	jne	0x5a2e <generic_usdt_process_filter+0x1a2e>
    57e6:      	movl	(%r14), %eax
    57e9:      	movb	$0x1, %r13b
    57ec:      	cmpq	%rax, %r15
    57ef:      	je	0x5795 <generic_usdt_process_filter+0x1795>
    57f1:      	movl	0x10(%r14), %eax
    57f5:      	cmpq	%rax, %r15
    57f8:      	je	0x5795 <generic_usdt_process_filter+0x1795>
    57fa:      	movl	$0x1, %eax
    57ff:      	movq	0xd0(%rsp), %rsi
    5807:      	movq	(%rip), %rdi            # 0x580e <generic_usdt_process_filter+0x180e>
    580e:      	callq	*%rax
    5810:      	testq	%rax, %rax
    5813:      	je	0x5bf1 <generic_usdt_process_filter+0x1bf1>
    5819:      	movq	%rax, %rsi
    581c:      	movl	(%rax), %eax
    581e:      	cmpq	%rax, %r15
    5821:      	je	0x577d <generic_usdt_process_filter+0x177d>
    5827:      	movl	0x10(%rsi), %eax
    582a:      	cmpq	%rax, %r15
    582d:      	je	0x577d <generic_usdt_process_filter+0x177d>
    5833:      	addq	$0x10, %rsi
    5837:      	movl	$0x1, %eax
    583c:      	movq	(%rip), %rdi            # 0x5843 <generic_usdt_process_filter+0x1843>
    5843:      	callq	*%rax
    5845:      	testq	%rax, %rax
    5848:      	je	0x5bf1 <generic_usdt_process_filter+0x1bf1>
    584e:      	movq	%rax, %rsi
    5851:      	movl	(%rax), %eax
    5853:      	cmpq	%rax, %r15
    5856:      	je	0x577d <generic_usdt_process_filter+0x177d>
    585c:      	movl	0x10(%rsi), %eax
    585f:      	cmpq	%rax, %r15
    5862:      	je	0x577d <generic_usdt_process_filter+0x177d>
    5868:      	addq	$0x10, %rsi
    586c:      	movl	$0x1, %eax
    5871:      	movq	(%rip), %rdi            # 0x5878 <generic_usdt_process_filter+0x1878>
    5878:      	callq	*%rax
    587a:      	testq	%rax, %rax
    587d:      	je	0x5bf1 <generic_usdt_process_filter+0x1bf1>
    5883:      	movq	%rax, %rsi
    5886:      	movl	(%rax), %eax
    5888:      	cmpq	%rax, %r15
    588b:      	je	0x577d <generic_usdt_process_filter+0x177d>
    5891:      	movl	0x10(%rsi), %eax
    5894:      	cmpq	%rax, %r15
    5897:      	je	0x577d <generic_usdt_process_filter+0x177d>
    589d:      	addq	$0x10, %rsi
    58a1:      	movl	$0x1, %eax
    58a6:      	movq	(%rip), %rdi            # 0x58ad <generic_usdt_process_filter+0x18ad>
    58ad:      	callq	*%rax
    58af:      	testq	%rax, %rax
    58b2:      	je	0x5bf1 <generic_usdt_process_filter+0x1bf1>
    58b8:      	movq	%rax, %rsi
    58bb:      	movl	(%rax), %eax
    58bd:      	cmpq	%rax, %r15
    58c0:      	je	0x577d <generic_usdt_process_filter+0x177d>
    58c6:      	movl	0x10(%rsi), %eax
    58c9:      	cmpq	%rax, %r15
    58cc:      	je	0x577d <generic_usdt_process_filter+0x177d>
    58d2:      	addq	$0x10, %rsi
    58d6:      	movl	$0x1, %eax
    58db:      	movq	(%rip), %rdi            # 0x58e2 <generic_usdt_process_filter+0x18e2>
    58e2:      	callq	*%rax
    58e4:      	testq	%rax, %rax
    58e7:      	je	0x5bf1 <generic_usdt_process_filter+0x1bf1>
    58ed:      	movq	%rax, %rsi
    58f0:      	movl	(%rax), %eax
    58f2:      	cmpq	%rax, %r15
    58f5:      	je	0x577d <generic_usdt_process_filter+0x177d>
    58fb:      	movl	0x10(%rsi), %eax
    58fe:      	cmpq	%rax, %r15
    5901:      	je	0x577d <generic_usdt_process_filter+0x177d>
    5907:      	addq	$0x10, %rsi
    590b:      	movl	$0x1, %eax
    5910:      	movq	(%rip), %rdi            # 0x5917 <generic_usdt_process_filter+0x1917>
    5917:      	callq	*%rax
    5919:      	testq	%rax, %rax
    591c:      	je	0x5bf1 <generic_usdt_process_filter+0x1bf1>
    5922:      	movq	%rax, %rsi
    5925:      	movl	(%rax), %eax
    5927:      	cmpq	%rax, %r15
    592a:      	je	0x5773 <generic_usdt_process_filter+0x1773>
    5930:      	movl	0x10(%rsi), %eax
    5933:      	cmpq	%rax, %r15
    5936:      	je	0x5773 <generic_usdt_process_filter+0x1773>
    593c:      	addq	$0x10, %rsi
    5940:      	movl	$0x1, %eax
    5945:      	movq	(%rip), %rdi            # 0x594c <generic_usdt_process_filter+0x194c>
    594c:      	callq	*%rax
    594e:      	testq	%rax, %rax
    5951:      	movq	0x30(%rsp), %r12
    5956:      	movq	0x28(%rsp), %r14
    595b:      	je	0x5bf1 <generic_usdt_process_filter+0x1bf1>
    5961:      	movq	%rax, %rsi
    5964:      	movl	(%rax), %eax
    5966:      	cmpq	%rax, %r15
    5969:      	je	0x5773 <generic_usdt_process_filter+0x1773>
    596f:      	movl	0x10(%rsi), %eax
    5972:      	cmpq	%rax, %r15
    5975:      	je	0x5773 <generic_usdt_process_filter+0x1773>
    597b:      	addq	$0x10, %rsi
    597f:      	movl	$0x1, %eax
    5984:      	movq	(%rip), %rdi            # 0x598b <generic_usdt_process_filter+0x198b>
    598b:      	callq	*%rax
    598d:      	testq	%rax, %rax
    5990:      	movq	0x30(%rsp), %r12
    5995:      	movq	0x28(%rsp), %r14
    599a:      	je	0x5bf1 <generic_usdt_process_filter+0x1bf1>
    59a0:      	movq	%rax, %rsi
    59a3:      	movl	(%rax), %eax
    59a5:      	cmpq	%rax, %r15
    59a8:      	je	0x5773 <generic_usdt_process_filter+0x1773>
    59ae:      	movl	0x10(%rsi), %eax
    59b1:      	cmpq	%rax, %r15
    59b4:      	movq	0x30(%rsp), %r12
    59b9:      	movq	0x28(%rsp), %r14
    59be:      	movq	0x8(%rsp), %r10
    59c3:      	movl	0x4(%rsp), %edi
    59c7:      	movq	0x20(%rsp), %r8
    59cc:      	movq	0x18(%rsp), %r9
    59d1:      	movq	0x10(%rsp), %r11
    59d6:      	je	0x5795 <generic_usdt_process_filter+0x1795>
    59dc:      	addq	$0x10, %rsi
    59e0:      	movl	$0x1, %eax
    59e5:      	movq	(%rip), %rcx            # 0x59ec <generic_usdt_process_filter+0x19ec>
    59ec:      	jmp	0x5bde <generic_usdt_process_filter+0x1bde>
    59f1:      	movl	$0x4, %esi
    59f6:      	xorl	%edx, %edx
    59f8:      	divq	%rsi
    59fb:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5a00:      	movl	(%r10,%rax,4), %r15d
    5a04:      	testb	$0x2, %r8b
    5a08:      	jne	0x57dc <generic_usdt_process_filter+0x17dc>
    5a0e:      	cmpl	$0x5, %edi
    5a11:      	jne	0x5a1c <generic_usdt_process_filter+0x1a1c>
    5a13:      	cmpq	%rcx, %r15
    5a16:      	jne	0x5c1a <generic_usdt_process_filter+0x1c1a>
    5a1c:      	cmpq	%rcx, %r15
    5a1f:      	setne	%al
    5a22:      	cmpl	$0x6, %edi
    5a25:      	setne	%r13b
    5a29:      	jmp	0x579f <generic_usdt_process_filter+0x179f>
    5a2e:      	movq	0xe0(%rsp), %rax
    5a36:      	movl	(%rax), %eax
    5a38:      	testq	%rax, %rax
    5a3b:      	je	0x5c1a <generic_usdt_process_filter+0x1c1a>
    5a41:      	movb	$0x1, %r13b
    5a44:      	testq	%r15, %r15
    5a47:      	je	0x5795 <generic_usdt_process_filter+0x1795>
    5a4d:      	cmpq	%rax, %r15
    5a50:      	je	0x5795 <generic_usdt_process_filter+0x1795>
    5a56:      	movl	$0x1, %eax
    5a5b:      	movq	0xd0(%rsp), %rsi
    5a63:      	movq	(%rip), %rdi            # 0x5a6a <generic_usdt_process_filter+0x1a6a>
    5a6a:      	callq	*%rax
    5a6c:      	testq	%rax, %rax
    5a6f:      	je	0x5bf1 <generic_usdt_process_filter+0x1bf1>
    5a75:      	movq	%rax, %rsi
    5a78:      	movl	0x24(%rax), %eax
    5a7b:      	cmpq	%rax, %r15
    5a7e:      	je	0x577d <generic_usdt_process_filter+0x177d>
    5a84:      	addq	$0x10, %rsi
    5a88:      	movl	$0x1, %eax
    5a8d:      	movq	(%rip), %rdi            # 0x5a94 <generic_usdt_process_filter+0x1a94>
    5a94:      	callq	*%rax
    5a96:      	testq	%rax, %rax
    5a99:      	je	0x5bf1 <generic_usdt_process_filter+0x1bf1>
    5a9f:      	movq	%rax, %rsi
    5aa2:      	movl	0x24(%rax), %eax
    5aa5:      	cmpq	%rax, %r15
    5aa8:      	je	0x577d <generic_usdt_process_filter+0x177d>
    5aae:      	addq	$0x10, %rsi
    5ab2:      	movl	$0x1, %eax
    5ab7:      	movq	(%rip), %rdi            # 0x5abe <generic_usdt_process_filter+0x1abe>
    5abe:      	callq	*%rax
    5ac0:      	testq	%rax, %rax
    5ac3:      	je	0x5bf1 <generic_usdt_process_filter+0x1bf1>
    5ac9:      	movq	%rax, %rsi
    5acc:      	movl	0x24(%rax), %eax
    5acf:      	cmpq	%rax, %r15
    5ad2:      	je	0x577d <generic_usdt_process_filter+0x177d>
    5ad8:      	addq	$0x10, %rsi
    5adc:      	movl	$0x1, %eax
    5ae1:      	movq	(%rip), %rdi            # 0x5ae8 <generic_usdt_process_filter+0x1ae8>
    5ae8:      	callq	*%rax
    5aea:      	testq	%rax, %rax
    5aed:      	je	0x5bf1 <generic_usdt_process_filter+0x1bf1>
    5af3:      	movq	%rax, %rsi
    5af6:      	movl	0x24(%rax), %eax
    5af9:      	cmpq	%rax, %r15
    5afc:      	je	0x577d <generic_usdt_process_filter+0x177d>
    5b02:      	addq	$0x10, %rsi
    5b06:      	movl	$0x1, %eax
    5b0b:      	movq	(%rip), %rdi            # 0x5b12 <generic_usdt_process_filter+0x1b12>
    5b12:      	callq	*%rax
    5b14:      	testq	%rax, %rax
    5b17:      	je	0x5bf1 <generic_usdt_process_filter+0x1bf1>
    5b1d:      	movq	%rax, %rsi
    5b20:      	movl	0x24(%rax), %eax
    5b23:      	cmpq	%rax, %r15
    5b26:      	je	0x577d <generic_usdt_process_filter+0x177d>
    5b2c:      	addq	$0x10, %rsi
    5b30:      	movl	$0x1, %eax
    5b35:      	movq	(%rip), %rdi            # 0x5b3c <generic_usdt_process_filter+0x1b3c>
    5b3c:      	callq	*%rax
    5b3e:      	testq	%rax, %rax
    5b41:      	je	0x5bf1 <generic_usdt_process_filter+0x1bf1>
    5b47:      	movq	%rax, %rsi
    5b4a:      	movl	0x24(%rax), %eax
    5b4d:      	cmpq	%rax, %r15
    5b50:      	je	0x5773 <generic_usdt_process_filter+0x1773>
    5b56:      	addq	$0x10, %rsi
    5b5a:      	movl	$0x1, %eax
    5b5f:      	movq	(%rip), %rdi            # 0x5b66 <generic_usdt_process_filter+0x1b66>
    5b66:      	callq	*%rax
    5b68:      	testq	%rax, %rax
    5b6b:      	movq	0x30(%rsp), %r12
    5b70:      	movq	0x28(%rsp), %r14
    5b75:      	je	0x5bf1 <generic_usdt_process_filter+0x1bf1>
    5b77:      	movq	%rax, %rsi
    5b7a:      	movl	0x24(%rax), %eax
    5b7d:      	cmpq	%rax, %r15
    5b80:      	je	0x5773 <generic_usdt_process_filter+0x1773>
    5b86:      	addq	$0x10, %rsi
    5b8a:      	movl	$0x1, %eax
    5b8f:      	movq	(%rip), %rdi            # 0x5b96 <generic_usdt_process_filter+0x1b96>
    5b96:      	callq	*%rax
    5b98:      	testq	%rax, %rax
    5b9b:      	movq	0x30(%rsp), %r12
    5ba0:      	movq	0x28(%rsp), %r14
    5ba5:      	je	0x5bf1 <generic_usdt_process_filter+0x1bf1>
    5ba7:      	movq	%rax, %rsi
    5baa:      	movl	0x24(%rax), %eax
    5bad:      	cmpq	%rax, %r15
    5bb0:      	movq	0x8(%rsp), %r10
    5bb5:      	movl	0x4(%rsp), %edi
    5bb9:      	movq	0x20(%rsp), %r8
    5bbe:      	movq	0x18(%rsp), %r9
    5bc3:      	movq	0x10(%rsp), %r11
    5bc8:      	je	0x5795 <generic_usdt_process_filter+0x1795>
    5bce:      	addq	$0x10, %rsi
    5bd2:      	movl	$0x1, %eax
    5bd7:      	movq	(%rip), %rcx            # 0x5bde <generic_usdt_process_filter+0x1bde>
    5bde:      	movq	(%rip), %rdi            # 0x5be5 <generic_usdt_process_filter+0x1be5>
    5be5:      	callq	*%rax
    5be7:      	movq	0x30(%rsp), %r12
    5bec:      	movq	0x28(%rsp), %r14
    5bf1:      	xorl	%r13d, %r13d
    5bf4:      	movl	0x4(%rsp), %edi
    5bf8:      	cmpl	$0x5, %edi
    5bfb:      	movq	0x8(%rsp), %r10
    5c00:      	movq	0x20(%rsp), %r8
    5c05:      	movq	0x18(%rsp), %r9
    5c0a:      	movq	0x10(%rsp), %r11
    5c0f:      	jne	0x5795 <generic_usdt_process_filter+0x1795>
    5c15:      	jmp	0x57a2 <generic_usdt_process_filter+0x17a2>
    5c1a:      	xorl	%r13d, %r13d
    5c1d:      	jmp	0x57a2 <generic_usdt_process_filter+0x17a2>
    5c22:      	movl	0x50(%rsp), %esi
    5c26:      	movl	0x54(%rsp), %ecx
    5c2a:      	movl	0x58(%rsp), %eax
    5c2e:      	movl	0x5c(%rsp), %edx
    5c32:      	cmpl	$0x6, %edi
    5c35:      	jne	0x5c3f <generic_usdt_process_filter+0x1c3f>
    5c37:      	andl	%esi, %ecx
    5c39:      	andl	%edx, %eax
    5c3b:      	andl	%ecx, %eax
    5c3d:      	jmp	0x5c45 <generic_usdt_process_filter+0x1c45>
    5c3f:      	orl	%esi, %ecx
    5c41:      	orl	%edx, %eax
    5c43:      	orl	%ecx, %eax
    5c45:      	testl	%eax, %eax
    5c47:      	movq	0xd8(%rsp), %rdx
    5c4f:      	je	0x625c <generic_usdt_process_filter+0x225c>
    5c55:      	addl	$0x14, %edx
    5c58:      	movl	0x8(%r10,%rbp), %ecx
    5c5d:      	andl	$0x7, %ecx
    5c60:      	leal	(%rdx,%rcx,4), %ebp
    5c63:      	movl	%ebp, %ecx
    5c65:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5c6b:      	movl	(%rcx,%r10), %ecx
    5c6f:      	addl	$0x4, %ebp
    5c72:      	addl	$-0x4, %ecx
    5c75:      	xorl	%esi, %esi
    5c77:      	movl	$0x4, %r8d
    5c7d:      	jmp	0x5c8f <generic_usdt_process_filter+0x1c8f>
    5c7f:      	nop
    5c80:      	xorl	%ecx, %ecx
    5c82:      	incq	%rsi
    5c85:      	cmpq	$0xa, %rsi
    5c89:      	je	0x5e18 <generic_usdt_process_filter+0x1e18>
    5c8f:      	testl	%ecx, %ecx
    5c91:      	je	0x5c80 <generic_usdt_process_filter+0x1c80>
    5c93:      	movl	%ebp, %r9d
    5c96:      	andl	$0x3ff, %r9d            # imm = 0x3FF
    5c9d:      	movl	(%r9,%r10), %r11d
    5ca1:      	movq	%r10, %rax
    5ca4:      	movl	0x4(%r9,%r10), %r10d
    5ca9:      	movl	0x8(%r9,%rax), %edx
    5cae:      	movq	$0x0, 0x58(%rsp)
    5cb7:      	movq	$0x0, 0x50(%rsp)
    5cc0:      	cmpl	$0x4, %edx
    5cc3:      	movl	$0x4, %eax
    5cc8:      	cmovbl	%edx, %eax
    5ccb:      	cmpl	$0x6, %r10d
    5ccf:      	jne	0x5ce5 <generic_usdt_process_filter+0x1ce5>
    5cd1:      	movabsq	$0x100000001, %rdi      # imm = 0x100000001
    5cdb:      	movq	%rdi, 0x50(%rsp)
    5ce0:      	movq	%rdi, 0x58(%rsp)
    5ce5:      	addl	$0xc, %ebp
    5ce8:      	testl	%edx, %edx
    5cea:      	je	0x5dc0 <generic_usdt_process_filter+0x1dc0>
    5cf0:      	andl	$0xf, %r11d
    5cf4:      	decq	%rax
    5cf7:      	cmpq	$0x3, %rax
    5cfb:      	movl	$0x3, %edx
    5d00:      	cmovaeq	%rdx, %rax
    5d04:      	leaq	0x4(,%rax,4), %rbx
    5d0c:      	movl	%ebp, %r14d
    5d0f:      	cmpl	$0x9, %r11d
    5d13:      	jbe	0x5d4a <generic_usdt_process_filter+0x1d4a>
    5d15:      	xorl	%r11d, %r11d
    5d18:      	jmp	0x5d36 <generic_usdt_process_filter+0x1d36>
    5d1a:      	nopw	(%rax,%rax)
    5d20:      	movl	$0x0, 0x50(%rsp,%r11)
    5d29:      	addq	$0x4, %r11
    5d2d:      	cmpq	%r11, %rbx
    5d30:      	je	0x5dc0 <generic_usdt_process_filter+0x1dc0>
    5d36:      	leaq	(%r14,%r11), %rax
    5d3a:      	cmpl	$0x3e8, %eax            # imm = 0x3E8
    5d3f:      	ja	0x5d20 <generic_usdt_process_filter+0x1d20>
    5d41:      	movl	%eax, %eax
    5d43:      	xorl	%edx, %edx
    5d45:      	divq	%r8
    5d48:      	jmp	0x5d20 <generic_usdt_process_filter+0x1d20>
    5d4a:      	xorl	%r15d, %r15d
    5d4d:      	jmp	0x5d91 <generic_usdt_process_filter+0x1d91>
    5d4f:      	nop
    5d50:      	cmpl	$0x5, %r10d
    5d54:      	setne	%dl
    5d57:      	movl	%r10d, %r13d
    5d5a:      	xorl	$0x6, %r13d
    5d5e:      	movq	0x30(%rsp), %rax
    5d63:      	movl	0x20(%rax,%r11,4), %edi
    5d68:      	movl	%r12d, %eax
    5d6b:      	xorl	%edi, %eax
    5d6d:      	cmpl	%edi, %r12d
    5d70:      	sete	%dil
    5d74:      	orb	%dl, %dil
    5d77:      	orl	%r13d, %eax
    5d7a:      	setne	%al
    5d7d:      	andb	%dil, %al
    5d80:      	movzbl	%al, %eax
    5d83:      	movl	%eax, 0x50(%rsp,%r15)
    5d88:      	addq	$0x4, %r15
    5d8c:      	cmpq	%r15, %rbx
    5d8f:      	je	0x5dc0 <generic_usdt_process_filter+0x1dc0>
    5d91:      	leaq	(%r14,%r15), %rdx
    5d95:      	xorl	%r12d, %r12d
    5d98:      	cmpl	$0x3e8, %edx            # imm = 0x3E8
    5d9e:      	ja	0x5d50 <generic_usdt_process_filter+0x1d50>
    5da0:      	movl	%edx, %eax
    5da2:      	xorl	%edx, %edx
    5da4:      	divq	%r8
    5da7:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5dac:      	movq	0x8(%rsp), %rdx
    5db1:      	movl	(%rdx,%rax,4), %r12d
    5db5:      	jmp	0x5d50 <generic_usdt_process_filter+0x1d50>
    5db7:      	nopw	(%rax,%rax)
    5dc0:      	movl	0x50(%rsp), %ebx
    5dc4:      	movl	0x54(%rsp), %edx
    5dc8:      	movl	0x58(%rsp), %eax
    5dcc:      	movl	0x5c(%rsp), %r11d
    5dd1:      	cmpl	$0x6, %r10d
    5dd5:      	jne	0x5de0 <generic_usdt_process_filter+0x1de0>
    5dd7:      	andl	%ebx, %edx
    5dd9:      	andl	%r11d, %eax
    5ddc:      	andl	%edx, %eax
    5dde:      	jmp	0x5de7 <generic_usdt_process_filter+0x1de7>
    5de0:      	orl	%ebx, %edx
    5de2:      	orl	%r11d, %eax
    5de5:      	orl	%edx, %eax
    5de7:      	movq	0x30(%rsp), %r12
    5dec:      	movq	0x8(%rsp), %r10
    5df1:      	testl	%eax, %eax
    5df3:      	je	0x625c <generic_usdt_process_filter+0x225c>
    5df9:      	movl	0x8(%r10,%r9), %edx
    5dfe:      	shll	$0x2, %edx
    5e01:      	subl	%edx, %ecx
    5e03:      	andl	$0x1c, %edx
    5e06:      	addl	%edx, %ebp
    5e08:      	addl	$-0xc, %ecx
    5e0b:      	incq	%rsi
    5e0e:      	cmpq	$0xa, %rsi
    5e12:      	jne	0x5c8f <generic_usdt_process_filter+0x1c8f>
    5e18:      	movl	%ebp, %ecx
    5e1a:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5e20:      	leal	0x4(%rbp), %ebx
    5e23:      	cmpl	$0x4, (%rcx,%r10)
    5e28:      	je	0x5e83 <generic_usdt_process_filter+0x1e83>
    5e2a:      	andl	$0x3ff, %ebx            # imm = 0x3FF
    5e30:      	movl	(%rbx,%r10), %ecx
    5e34:      	movl	0x4(%rbx,%r10), %edx
    5e39:      	movl	0x8(%rbx,%r10), %edi
    5e3e:      	movq	0xc(%rbx,%r10), %rax
    5e43:      	testl	%edi, %edi
    5e45:      	je	0x5e57 <generic_usdt_process_filter+0x1e57>
    5e47:      	xorl	%esi, %esi
    5e49:      	cmpl	$0x2, %ecx
    5e4c:      	ja	0x5e7a <generic_usdt_process_filter+0x1e7a>
    5e4e:      	cmpl	%edi, 0x44(%r12)
    5e53:      	jne	0x5e60 <generic_usdt_process_filter+0x1e60>
    5e55:      	jmp	0x5e7a <generic_usdt_process_filter+0x1e7a>
    5e57:      	cmpl	$0x2, %ecx
    5e5a:      	jbe	0x5e60 <generic_usdt_process_filter+0x1e60>
    5e5c:      	xorl	%esi, %esi
    5e5e:      	jmp	0x5e7a <generic_usdt_process_filter+0x1e7a>
    5e60:      	andq	0x48(%r12,%rcx,8), %rax
    5e65:      	cmpl	$0x5, %edx
    5e68:      	jne	0x5e73 <generic_usdt_process_filter+0x1e73>
    5e6a:      	testq	%rax, %rax
    5e6d:      	setne	%sil
    5e71:      	jmp	0x5e7a <generic_usdt_process_filter+0x1e7a>
    5e73:      	testq	%rax, %rax
    5e76:      	sete	%sil
    5e7a:      	addl	$0x18, %ebp
    5e7d:      	movzbl	%sil, %eax
    5e81:      	movl	%ebp, %ebx
    5e83:      	testl	%eax, %eax
    5e85:      	je	0x625c <generic_usdt_process_filter+0x225c>
    5e8b:      	movl	%ebx, %ecx
    5e8d:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    5e93:      	leal	0x4(%rbx), %eax
    5e96:      	cmpl	$0x4, (%rcx,%r10)
    5e9b:      	je	0x616f <generic_usdt_process_filter+0x216f>
    5ea1:      	andl	$0x3ff, %eax            # imm = 0x3FF
    5ea6:      	movl	(%rax,%r10), %r14d
    5eaa:      	movl	0x4(%rax,%r10), %ebp
    5eaf:      	movl	$0xe, %eax
    5eb4:      	callq	*%rax
    5eb6:      	shrq	$0x20, %rax
    5eba:      	movl	%eax, 0x50(%rsp)
    5ebe:      	movq	(%rip), %rdi            # 0x5ec5 <generic_usdt_process_filter+0x1ec5>
    5ec5:      	leaq	0x50(%rsp), %rsi
    5eca:      	movl	$0x1, %eax
    5ecf:      	callq	*%rax
    5ed1:      	movq	0x8(%rsp), %r10
    5ed6:      	testq	%rax, %rax
    5ed9:      	je	0x625c <generic_usdt_process_filter+0x225c>
    5edf:      	cmpl	$0x5, %r14d
    5ee3:      	je	0x5f12 <generic_usdt_process_filter+0x1f12>
    5ee5:      	cmpl	$0x6, %r14d
    5ee9:      	jne	0x625c <generic_usdt_process_filter+0x225c>
    5eef:      	movq	%r12, %rcx
    5ef2:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    5ef9:      	testb	$0x1, %bpl
    5efd:      	jne	0x5f3c <generic_usdt_process_filter+0x1f3c>
    5eff:      	movl	0x28(%rax), %edx
    5f02:      	testl	%edx, %edx
    5f04:      	je	0x5f35 <generic_usdt_process_filter+0x1f35>
    5f06:      	cmpl	0x20(%r12), %edx
    5f0b:      	je	0x5f3c <generic_usdt_process_filter+0x1f3c>
    5f0d:      	jmp	0x6163 <generic_usdt_process_filter+0x2163>
    5f12:      	movq	%r12, %rcx
    5f15:      	addq	$0x5ee8, %rcx           # imm = 0x5EE8
    5f1c:      	testb	$0x1, %bpl
    5f20:      	je	0x5f5c <generic_usdt_process_filter+0x1f5c>
    5f22:      	movl	0x28(%rax), %edx
    5f25:      	testl	%edx, %edx
    5f27:      	je	0x5f55 <generic_usdt_process_filter+0x1f55>
    5f29:      	cmpl	0x20(%r12), %edx
    5f2e:      	je	0x5f5c <generic_usdt_process_filter+0x1f5c>
    5f30:      	jmp	0x6163 <generic_usdt_process_filter+0x2163>
    5f35:      	movq	$0x1, (%rcx)
    5f3c:      	testb	$0x2, %bpl
    5f40:      	jne	0x5f7c <generic_usdt_process_filter+0x1f7c>
    5f42:      	movl	0x2c(%rax), %edx
    5f45:      	testl	%edx, %edx
    5f47:      	je	0x5f75 <generic_usdt_process_filter+0x1f75>
    5f49:      	cmpl	0x24(%r12), %edx
    5f4e:      	je	0x5f7c <generic_usdt_process_filter+0x1f7c>
    5f50:      	jmp	0x6163 <generic_usdt_process_filter+0x2163>
    5f55:      	movq	$0x1, (%rcx)
    5f5c:      	testb	$0x2, %bpl
    5f60:      	je	0x5f9c <generic_usdt_process_filter+0x1f9c>
    5f62:      	movl	0x2c(%rax), %edx
    5f65:      	testl	%edx, %edx
    5f67:      	je	0x5f95 <generic_usdt_process_filter+0x1f95>
    5f69:      	cmpl	0x24(%r12), %edx
    5f6e:      	je	0x5f9c <generic_usdt_process_filter+0x1f9c>
    5f70:      	jmp	0x6163 <generic_usdt_process_filter+0x2163>
    5f75:      	movq	$0x1, (%rcx)
    5f7c:      	testb	$0x4, %bpl
    5f80:      	jne	0x5fbc <generic_usdt_process_filter+0x1fbc>
    5f82:      	movl	0x30(%rax), %edx
    5f85:      	testl	%edx, %edx
    5f87:      	je	0x5fb5 <generic_usdt_process_filter+0x1fb5>
    5f89:      	cmpl	0x28(%r12), %edx
    5f8e:      	je	0x5fbc <generic_usdt_process_filter+0x1fbc>
    5f90:      	jmp	0x6163 <generic_usdt_process_filter+0x2163>
    5f95:      	movq	$0x1, (%rcx)
    5f9c:      	testb	$0x4, %bpl
    5fa0:      	je	0x5fdc <generic_usdt_process_filter+0x1fdc>
    5fa2:      	movl	0x30(%rax), %edx
    5fa5:      	testl	%edx, %edx
    5fa7:      	je	0x5fd5 <generic_usdt_process_filter+0x1fd5>
    5fa9:      	cmpl	0x28(%r12), %edx
    5fae:      	je	0x5fdc <generic_usdt_process_filter+0x1fdc>
    5fb0:      	jmp	0x6163 <generic_usdt_process_filter+0x2163>
    5fb5:      	movq	$0x1, (%rcx)
    5fbc:      	testb	$0x8, %bpl
    5fc0:      	jne	0x5ffc <generic_usdt_process_filter+0x1ffc>
    5fc2:      	movl	0x34(%rax), %edx
    5fc5:      	testl	%edx, %edx
    5fc7:      	je	0x5ff5 <generic_usdt_process_filter+0x1ff5>
    5fc9:      	cmpl	0x2c(%r12), %edx
    5fce:      	je	0x5ffc <generic_usdt_process_filter+0x1ffc>
    5fd0:      	jmp	0x6163 <generic_usdt_process_filter+0x2163>
    5fd5:      	movq	$0x1, (%rcx)
    5fdc:      	testb	$0x8, %bpl
    5fe0:      	je	0x601c <generic_usdt_process_filter+0x201c>
    5fe2:      	movl	0x34(%rax), %edx
    5fe5:      	testl	%edx, %edx
    5fe7:      	je	0x6015 <generic_usdt_process_filter+0x2015>
    5fe9:      	cmpl	0x2c(%r12), %edx
    5fee:      	je	0x601c <generic_usdt_process_filter+0x201c>
    5ff0:      	jmp	0x6163 <generic_usdt_process_filter+0x2163>
    5ff5:      	movq	$0x1, (%rcx)
    5ffc:      	testb	$0x10, %bpl
    6000:      	jne	0x603c <generic_usdt_process_filter+0x203c>
    6002:      	movl	0x38(%rax), %edx
    6005:      	testl	%edx, %edx
    6007:      	je	0x6035 <generic_usdt_process_filter+0x2035>
    6009:      	cmpl	0x30(%r12), %edx
    600e:      	je	0x603c <generic_usdt_process_filter+0x203c>
    6010:      	jmp	0x6163 <generic_usdt_process_filter+0x2163>
    6015:      	movq	$0x1, (%rcx)
    601c:      	testb	$0x10, %bpl
    6020:      	je	0x605c <generic_usdt_process_filter+0x205c>
    6022:      	movl	0x38(%rax), %edx
    6025:      	testl	%edx, %edx
    6027:      	je	0x6055 <generic_usdt_process_filter+0x2055>
    6029:      	cmpl	0x30(%r12), %edx
    602e:      	je	0x605c <generic_usdt_process_filter+0x205c>
    6030:      	jmp	0x6163 <generic_usdt_process_filter+0x2163>
    6035:      	movq	$0x1, (%rcx)
    603c:      	testb	$0x20, %bpl
    6040:      	jne	0x607c <generic_usdt_process_filter+0x207c>
    6042:      	movl	0x3c(%rax), %edx
    6045:      	testl	%edx, %edx
    6047:      	je	0x6075 <generic_usdt_process_filter+0x2075>
    6049:      	cmpl	0x34(%r12), %edx
    604e:      	je	0x607c <generic_usdt_process_filter+0x207c>
    6050:      	jmp	0x6163 <generic_usdt_process_filter+0x2163>
    6055:      	movq	$0x1, (%rcx)
    605c:      	testb	$0x20, %bpl
    6060:      	je	0x609c <generic_usdt_process_filter+0x209c>
    6062:      	movl	0x3c(%rax), %edx
    6065:      	testl	%edx, %edx
    6067:      	je	0x6095 <generic_usdt_process_filter+0x2095>
    6069:      	cmpl	0x34(%r12), %edx
    606e:      	je	0x609c <generic_usdt_process_filter+0x209c>
    6070:      	jmp	0x6163 <generic_usdt_process_filter+0x2163>
    6075:      	movq	$0x1, (%rcx)
    607c:      	testb	$0x40, %bpl
    6080:      	jne	0x60bc <generic_usdt_process_filter+0x20bc>
    6082:      	movl	0x40(%rax), %edx
    6085:      	testl	%edx, %edx
    6087:      	je	0x60b5 <generic_usdt_process_filter+0x20b5>
    6089:      	cmpl	0x38(%r12), %edx
    608e:      	je	0x60bc <generic_usdt_process_filter+0x20bc>
    6090:      	jmp	0x6163 <generic_usdt_process_filter+0x2163>
    6095:      	movq	$0x1, (%rcx)
    609c:      	testb	$0x40, %bpl
    60a0:      	je	0x60db <generic_usdt_process_filter+0x20db>
    60a2:      	movl	0x40(%rax), %edx
    60a5:      	testl	%edx, %edx
    60a7:      	je	0x60d4 <generic_usdt_process_filter+0x20d4>
    60a9:      	cmpl	0x38(%r12), %edx
    60ae:      	je	0x60db <generic_usdt_process_filter+0x20db>
    60b0:      	jmp	0x6163 <generic_usdt_process_filter+0x2163>
    60b5:      	movq	$0x1, (%rcx)
    60bc:      	testb	%bpl, %bpl
    60bf:      	js	0x60f7 <generic_usdt_process_filter+0x20f7>
    60c1:      	movl	0x44(%rax), %edx
    60c4:      	testl	%edx, %edx
    60c6:      	je	0x60f0 <generic_usdt_process_filter+0x20f0>
    60c8:      	cmpl	0x3c(%r12), %edx
    60cd:      	je	0x60f7 <generic_usdt_process_filter+0x20f7>
    60cf:      	jmp	0x6163 <generic_usdt_process_filter+0x2163>
    60d4:      	movq	$0x1, (%rcx)
    60db:      	testb	%bpl, %bpl
    60de:      	jns	0x6116 <generic_usdt_process_filter+0x2116>
    60e0:      	movl	0x44(%rax), %edx
    60e3:      	testl	%edx, %edx
    60e5:      	je	0x610f <generic_usdt_process_filter+0x210f>
    60e7:      	cmpl	0x3c(%r12), %edx
    60ec:      	je	0x6116 <generic_usdt_process_filter+0x2116>
    60ee:      	jmp	0x6163 <generic_usdt_process_filter+0x2163>
    60f0:      	movq	$0x1, (%rcx)
    60f7:      	testl	$0x100, %ebp            # imm = 0x100
    60fd:      	jne	0x6141 <generic_usdt_process_filter+0x2141>
    60ff:      	movl	0x48(%rax), %edx
    6102:      	testl	%edx, %edx
    6104:      	je	0x613a <generic_usdt_process_filter+0x213a>
    6106:      	cmpl	0x40(%r12), %edx
    610b:      	je	0x6141 <generic_usdt_process_filter+0x2141>
    610d:      	jmp	0x6163 <generic_usdt_process_filter+0x2163>
    610f:      	movq	$0x1, (%rcx)
    6116:      	testl	$0x100, %ebp            # imm = 0x100
    611c:      	je	0x6242 <generic_usdt_process_filter+0x2242>
    6122:      	movl	0x48(%rax), %edx
    6125:      	testl	%edx, %edx
    6127:      	je	0x623b <generic_usdt_process_filter+0x223b>
    612d:      	cmpl	0x40(%r12), %edx
    6132:      	je	0x6242 <generic_usdt_process_filter+0x2242>
    6138:      	jmp	0x6163 <generic_usdt_process_filter+0x2163>
    613a:      	movq	$0x1, (%rcx)
    6141:      	testl	$0x200, %ebp            # imm = 0x200
    6147:      	jne	0x625c <generic_usdt_process_filter+0x225c>
    614d:      	movl	0x4c(%rax), %eax
    6150:      	testl	%eax, %eax
    6152:      	je	0x6255 <generic_usdt_process_filter+0x2255>
    6158:      	cmpl	0x44(%r12), %eax
    615d:      	je	0x625c <generic_usdt_process_filter+0x225c>
    6163:      	addl	$0xc, %ebx
    6166:      	movq	$0x1, (%rcx)
    616d:      	movl	%ebx, %eax
    616f:      	movl	%eax, %ecx
    6171:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    6177:      	cmpl	$0x4, (%rcx,%r10)
    617c:      	jne	0x61a9 <generic_usdt_process_filter+0x21a9>
    617e:      	movq	0x5eb8(%r12), %rax
    6186:      	andl	$0x1f, %eax
    6189:      	movb	$0x1, 0x5ec1(%r12,%rax)
    6192:      	movb	$0x1, 0x5ee0(%r12)
    619b:      	movb	$0x1, 0x5ec0(%r12)
    61a4:      	jmp	0x625c <generic_usdt_process_filter+0x225c>
    61a9:      	addl	$0x4, %eax
    61ac:      	andl	$0x3ff, %eax            # imm = 0x3FF
    61b1:      	movl	(%rax,%r10), %r14d
    61b5:      	movl	0x4(%rax,%r10), %ebx
    61ba:      	movl	0x8(%rax,%r10), %ebp
    61bf:      	movq	0xc(%rax,%r10), %r15
    61c4:      	movl	$0xe, %eax
    61c9:      	callq	*%rax
    61cb:      	shrq	$0x20, %rax
    61cf:      	movl	%eax, 0x50(%rsp)
    61d3:      	movq	(%rip), %rdi            # 0x61da <generic_usdt_process_filter+0x21da>
    61da:      	leaq	0x50(%rsp), %rsi
    61df:      	movl	$0x1, %eax
    61e4:      	callq	*%rax
    61e6:      	testq	%rax, %rax
    61e9:      	je	0x625c <generic_usdt_process_filter+0x225c>
    61eb:      	testl	%ebp, %ebp
    61ed:      	je	0x61fe <generic_usdt_process_filter+0x21fe>
    61ef:      	cmpl	$0x2, %r14d
    61f3:      	ja	0x625c <generic_usdt_process_filter+0x225c>
    61f5:      	cmpl	%ebp, 0x44(%r12)
    61fa:      	jne	0x6204 <generic_usdt_process_filter+0x2204>
    61fc:      	jmp	0x625c <generic_usdt_process_filter+0x225c>
    61fe:      	cmpl	$0x2, %r14d
    6202:      	ja	0x625c <generic_usdt_process_filter+0x225c>
    6204:      	movq	0x50(%rax,%r14,8), %rax
    6209:      	movq	0x48(%r12,%r14,8), %rcx
    620e:      	movq	%rcx, %rdx
    6211:      	xorq	%rax, %rdx
    6214:      	testq	%r15, %rdx
    6217:      	je	0x6220 <generic_usdt_process_filter+0x2220>
    6219:      	cmpl	$0x5, %ebx
    621c:      	jne	0x625c <generic_usdt_process_filter+0x225c>
    621e:      	jmp	0x622a <generic_usdt_process_filter+0x222a>
    6220:      	cmpq	%rcx, %rax
    6223:      	je	0x625c <generic_usdt_process_filter+0x225c>
    6225:      	cmpl	$0x6, %ebx
    6228:      	jne	0x625c <generic_usdt_process_filter+0x225c>
    622a:      	movq	$0x1, 0x5ef0(%r12)
    6236:      	jmp	0x617e <generic_usdt_process_filter+0x217e>
    623b:      	movq	$0x1, (%rcx)
    6242:      	testl	$0x200, %ebp            # imm = 0x200
    6248:      	je	0x625c <generic_usdt_process_filter+0x225c>
    624a:      	movl	0x4c(%rax), %eax
    624d:      	testl	%eax, %eax
    624f:      	jne	0x6158 <generic_usdt_process_filter+0x2158>
    6255:      	movq	$0x1, (%rcx)
    625c:      	movq	0x5eb8(%r12), %rax
    6264:      	incq	%rax
    6267:      	movq	%rax, 0x5eb8(%r12)
    626f:      	cmpq	0xb8(%rsp), %rax
    6277:      	jbe	0x62ca <generic_usdt_process_filter+0x22ca>
    6279:      	movq	0x28(%rsp), %rcx
    627e:      	movl	(%rcx), %eax
    6280:      	movl	%eax, 0x10(%r12)
    6285:      	movq	0x8(%rcx), %rax
    6289:      	movq	%rax, 0x18(%r12)
    628e:      	cmpb	$0x0, 0x5ec0(%r12)
    6297:      	movq	0xb0(%rsp), %rbp
    629f:      	je	0x62b6 <generic_usdt_process_filter+0x22b6>
    62a1:      	movq	(%rip), %rsi            # 0x62a8 <generic_usdt_process_filter+0x22a8>
    62a8:      	xorl	%ecx, %ecx
    62aa:      	movl	$0xc, %eax
    62af:      	movq	%rbp, %rdi
    62b2:      	xorl	%edx, %edx
    62b4:      	callq	*%rax
    62b6:      	xorl	%eax, %eax
    62b8:      	addq	$0xf8, %rsp
    62bf:      	popq	%rbx
    62c0:      	popq	%r12
    62c2:      	popq	%r13
    62c4:      	popq	%r14
    62c6:      	popq	%r15
    62c8:      	popq	%rbp
    62c9:      	retq
    62ca:      	movq	(%rip), %rsi            # 0x62d1 <generic_usdt_process_filter+0x22d1>
    62d1:      	movl	$0x2, %ecx
    62d6:      	movl	$0xc, %eax
    62db:      	movq	0xb0(%rsp), %rdi
    62e3:      	movl	$0x2, %edx
    62e8:      	jmp	0x62b4 <generic_usdt_process_filter+0x22b4>
    62ea:      	nopw	(%rax,%rax)

00000000000062f0 <generic_usdt_filter_arg>:
    62f0:      	pushq	%rbp
    62f1:      	pushq	%r15
    62f3:      	pushq	%r14
    62f5:      	pushq	%r13
    62f7:      	pushq	%r12
    62f9:      	pushq	%rbx
    62fa:      	subq	$0xc8, %rsp
    6301:      	movq	%rdi, %r13
    6304:      	movl	$0x0, 0xb4(%rsp)
    630f:      	movq	(%rip), %rdi            # 0x6316 <generic_usdt_filter_arg+0x26>
    6316:      	leaq	0xb4(%rsp), %rsi
    631e:      	movl	$0x1, %eax
    6323:      	callq	*%rax
    6325:      	testq	%rax, %rax
    6328:      	je	0x64c3 <generic_usdt_filter_arg+0x1d3>
    632e:      	movq	%rax, %r14
    6331:      	movl	0x5f00(%rax), %ebx
    6337:      	leaq	0x5ef8(%rax), %rsi
    633e:      	movq	(%rip), %rdi            # 0x6345 <generic_usdt_filter_arg+0x55>
    6345:      	movl	$0x1, %eax
    634a:      	callq	*%rax
    634c:      	testq	%rax, %rax
    634f:      	je	0x64a8 <generic_usdt_filter_arg+0x1b8>
    6355:      	cmpb	$0x0, 0x5ee0(%r14)
    635d:      	je	0x64a8 <generic_usdt_filter_arg+0x1b8>
    6363:      	movq	%rax, %r15
    6366:      	movl	%ebx, %eax
    6368:      	andl	$0x7, %eax
    636b:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
    6374:      	je	0x63fd <generic_usdt_filter_arg+0x10d>
    637a:      	movl	%eax, %eax
    637c:      	movl	0x4(%r15,%rax,4), %ecx
    6381:      	leaq	(%rcx,%rax,4), %rdx
    6385:      	addq	$0x4, %rdx
    6389:      	leaq	(%rcx,%rax,4), %rax
    638d:      	addq	$0x8, %rax
    6391:      	andl	$0x3ff, %eax            # imm = 0x3FF
    6396:      	movl	(%rax,%r15), %eax
    639a:      	addq	%rdx, %rax
    639d:      	addq	$0x4, %rax
    63a1:      	movl	%eax, %ecx
    63a3:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    63a9:      	movl	(%rcx,%r15), %ecx
    63ad:      	addq	%rax, %rcx
    63b0:      	movl	%ecx, %eax
    63b2:      	andl	$0x3ff, %eax            # imm = 0x3FF
    63b7:      	movl	(%rax,%r15), %eax
    63bb:      	addq	%rcx, %rax
    63be:      	movl	%eax, %ecx
    63c0:      	andl	$0x3ff, %ecx            # imm = 0x3FF
    63c6:      	movl	(%rcx,%r15), %ecx
    63ca:      	addq	%rax, %rcx
    63cd:      	movl	%ecx, %eax
    63cf:      	andl	$0x3ff, %eax            # imm = 0x3FF
    63d4:      	movl	(%rax,%r15), %r9d
    63d8:      	addq	%rcx, %r9
    63db:      	movl	%r9d, %edi
    63de:      	andl	$0x3ff, %edi            # imm = 0x3FF
    63e4:      	cmpl	$0x19, (%r15,%rdi)
    63e9:      	jae	0x6449 <generic_usdt_filter_arg+0x159>
    63eb:      	cmpq	$0x1, %rdi
    63ef:      	je	0x64a8 <generic_usdt_filter_arg+0x1b8>
    63f5:      	testl	%edi, %edi
    63f7:      	jne	0x6486 <generic_usdt_filter_arg+0x196>
    63fd:      	cmpl	$0x1, %ebx
    6400:      	jg	0x641e <generic_usdt_filter_arg+0x12e>
    6402:      	cmpl	$-0x1, %ebx
    6405:      	je	0x64d7 <generic_usdt_filter_arg+0x1e7>
    640b:      	testl	%ebx, %ebx
    640d:      	je	0x64e3 <generic_usdt_filter_arg+0x1f3>
    6413:      	cmpl	$0x1, %ebx
    6416:      	je	0x64f2 <generic_usdt_filter_arg+0x202>
    641c:      	jmp	0x6439 <generic_usdt_filter_arg+0x149>
    641e:      	cmpl	$0x2, %ebx
    6421:      	je	0x6501 <generic_usdt_filter_arg+0x211>
    6427:      	cmpl	$0x3, %ebx
    642a:      	je	0x6510 <generic_usdt_filter_arg+0x220>
    6430:      	cmpl	$0x4, %ebx
    6433:      	je	0x651f <generic_usdt_filter_arg+0x22f>
    6439:      	cmpl	$0x4, %ebx
    643c:      	jg	0x6550 <generic_usdt_filter_arg+0x260>
    6442:      	incl	%ebx
    6444:      	jmp	0x652e <generic_usdt_filter_arg+0x23e>
    6449:      	leaq	(%r15,%rdi), %rax
    644d:      	movq	%rax, 0xc0(%rsp)
    6455:      	xorl	%r11d, %r11d
    6458:      	leaq	0x80(%rsp), %rax
    6460:      	movq	%rax, 0x38(%rsp)
    6465:      	movq	%rbx, 0xb8(%rsp)
    646d:      	movq	%rdi, 0x10(%rsp)
    6472:      	movq	%r9, 0x18(%rsp)
    6477:      	movq	%r15, 0x68(%rsp)
    647c:      	movq	%r13, 0x78(%rsp)
    6481:      	jmp	0x65c5 <generic_usdt_filter_arg+0x2d5>
    6486:      	movl	%edi, 0x5f04(%r14)
    648d:      	movq	(%rip), %rsi            # 0x6494 <generic_usdt_filter_arg+0x1a4>
    6494:      	movl	$0x4, %ecx
    6499:      	movl	$0xc, %eax
    649e:      	movq	%r13, %rdi
    64a1:      	movl	$0x4, %edx
    64a6:      	callq	*%rax
    64a8:      	movq	(%rip), %rsi            # 0x64af <generic_usdt_filter_arg+0x1bf>
    64af:      	movl	$0x5, %ecx
    64b4:      	movl	$0xc, %eax
    64b9:      	movq	%r13, %rdi
    64bc:      	movl	$0x5, %edx
    64c1:      	callq	*%rax
    64c3:      	xorl	%eax, %eax
    64c5:      	addq	$0xc8, %rsp
    64cc:      	popq	%rbx
    64cd:      	popq	%r12
    64cf:      	popq	%r13
    64d1:      	popq	%r14
    64d3:      	popq	%r15
    64d5:      	popq	%rbp
    64d6:      	retq
    64d7:      	xorl	%ebx, %ebx
    64d9:      	cmpb	$0x0, 0x5ec1(%r14)
    64e1:      	jne	0x652e <generic_usdt_filter_arg+0x23e>
    64e3:      	movl	$0x1, %ebx
    64e8:      	cmpb	$0x0, 0x5ec2(%r14)
    64f0:      	jne	0x652e <generic_usdt_filter_arg+0x23e>
    64f2:      	movl	$0x2, %ebx
    64f7:      	cmpb	$0x0, 0x5ec3(%r14)
    64ff:      	jne	0x652e <generic_usdt_filter_arg+0x23e>
    6501:      	movl	$0x3, %ebx
    6506:      	cmpb	$0x0, 0x5ec4(%r14)
    650e:      	jne	0x652e <generic_usdt_filter_arg+0x23e>
    6510:      	movl	$0x4, %ebx
    6515:      	cmpb	$0x0, 0x5ec5(%r14)
    651d:      	jne	0x652e <generic_usdt_filter_arg+0x23e>
    651f:      	movl	$0x5, %ebx
    6524:      	cmpb	$0x0, 0x5ec6(%r14)
    652c:      	je	0x6550 <generic_usdt_filter_arg+0x260>
    652e:      	movl	%ebx, 0x5f00(%r14)
    6535:      	movq	(%rip), %rsi            # 0x653c <generic_usdt_filter_arg+0x24c>
    653c:      	movl	$0x3, %ecx
    6541:      	movl	$0xc, %eax
    6546:      	movq	%r13, %rdi
    6549:      	movl	$0x3, %edx
    654e:      	callq	*%rax
    6550:      	movq	0x60(%r14), %rbx
    6554:      	movl	$0xe, %eax
    6559:      	callq	*%rax
    655b:      	movq	%rbx, 0x40(%rsp)
    6560:      	movq	%rax, 0x48(%rsp)
    6565:      	movq	(%rip), %rdi            # 0x656c <generic_usdt_filter_arg+0x27c>
    656c:      	leaq	0x40(%rsp), %rsi
    6571:      	movl	$0x1, %eax
    6576:      	callq	*%rax
    6578:      	testq	%rax, %rax
    657b:      	je	0x64c3 <generic_usdt_filter_arg+0x1d3>
    6581:      	movq	(%rip), %rdi            # 0x6588 <generic_usdt_filter_arg+0x298>
    6588:      	leaq	0x40(%rsp), %rsi
    658d:      	movl	$0x3, %eax
    6592:      	callq	*%rax
    6594:      	jmp	0x64c3 <generic_usdt_filter_arg+0x1d3>
    6599:      	testq	%rax, %rax
    659c:      	setne	%cl
    659f:      	movzbl	%cl, %ebx
    65a2:      	movq	0x78(%rsp), %r13
    65a7:      	testq	%rbx, %rbx
    65aa:      	movq	0xb8(%rsp), %rbx
    65b2:      	je	0x63fd <generic_usdt_filter_arg+0x10d>
    65b8:      	incq	%r11
    65bb:      	cmpq	$0x5, %r11
    65bf:      	je	0x63eb <generic_usdt_filter_arg+0xfb>
    65c5:      	movq	0xc0(%rsp), %rax
    65cd:      	movl	0x4(%rax,%r11,4), %r12d
    65d2:      	testl	$0x3ff, %r12d           # imm = 0x3FF
    65d9:      	je	0x63eb <generic_usdt_filter_arg+0xfb>
    65df:      	addl	%r9d, %r12d
    65e2:      	andl	$0x3ff, %r12d           # imm = 0x3FF
    65e9:      	movl	0x4(%r15,%r12), %eax
    65ee:      	cmpl	$0x23, %eax
    65f1:      	je	0x63fd <generic_usdt_filter_arg+0x10d>
    65f7:      	addq	%r15, %r12
    65fa:      	movl	(%r12), %ecx
    65fe:      	cmpq	$0x4, %rcx
    6602:      	ja	0x63fd <generic_usdt_filter_arg+0x10d>
    6608:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    6611:      	jne	0x63fd <generic_usdt_filter_arg+0x10d>
    6617:      	movq	0x5e78(%r14,%rcx,8), %rcx
    661f:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    6625:      	leaq	(%r14,%rcx), %rsi
    6629:      	addq	$0x90, %rsi
    6630:      	movl	0xc(%r12), %ecx
    6635:      	cmpl	$0x10, %ecx
    6638:      	jle	0x6694 <generic_usdt_filter_arg+0x3a4>
    663a:      	leal	-0x1c(%rcx), %edx
    663d:      	cmpl	$0x9, %edx
    6640:      	jb	0x67be <generic_usdt_filter_arg+0x4ce>
    6646:      	movq	%rsi, %r8
    6649:      	cmpl	$0x2a, %ecx
    664c:      	ja	0x6ae3 <generic_usdt_filter_arg+0x7f3>
    6652:      	movl	%ecx, %edx
    6654:      	movabsq	$0xc000000000, %rsi     # imm = 0xC000000000
    665e:      	btq	%rdx, %rsi
    6662:      	jb	0x66bc <generic_usdt_filter_arg+0x3cc>
    6664:      	movabsq	$0x30000000000, %rsi    # imm = 0x30000000000
    666e:      	btq	%rdx, %rsi
    6672:      	jb	0x671b <generic_usdt_filter_arg+0x42b>
    6678:      	movabsq	$0x42000000000, %rsi    # imm = 0x42000000000
    6682:      	btq	%rdx, %rsi
    6686:      	jae	0x6ae3 <generic_usdt_filter_arg+0x7f3>
    668c:      	movq	%r8, %rsi
    668f:      	jmp	0x6af3 <generic_usdt_filter_arg+0x803>
    6694:      	cmpl	$0x6, %ecx
    6697:      	jg	0x66f7 <generic_usdt_filter_arg+0x407>
    6699:      	cmpl	$0x3, %ecx
    669c:      	jle	0x6773 <generic_usdt_filter_arg+0x483>
    66a2:      	cmpl	$0x4, %ecx
    66a5:      	je	0x67be <generic_usdt_filter_arg+0x4ce>
    66ab:      	movq	%rsi, %r8
    66ae:      	cmpl	$0x5, %ecx
    66b1:      	je	0x671b <generic_usdt_filter_arg+0x42b>
    66b3:      	cmpl	$0x6, %ecx
    66b6:      	jne	0x65b8 <generic_usdt_filter_arg+0x2c8>
    66bc:      	movq	%r8, %rsi
    66bf:      	movl	(%r8), %ebp
    66c2:      	addq	$0x4, %rsi
    66c6:      	cmpl	$0x19, %eax
    66c9:      	jg	0x6977 <generic_usdt_filter_arg+0x687>
    66cf:      	leal	-0x3(%rax), %ecx
    66d2:      	cmpl	$0x2, %ecx
    66d5:      	jb	0x72d0 <generic_usdt_filter_arg+0xfe0>
    66db:      	cmpl	$0x8, %eax
    66de:      	je	0x7227 <generic_usdt_filter_arg+0xf37>
    66e4:      	movl	$0x0, %ebx
    66e9:      	cmpl	$0x9, %eax
    66ec:      	je	0x6997 <generic_usdt_filter_arg+0x6a7>
    66f2:      	jmp	0x92b7 <generic_usdt_filter_arg+0x2fc7>
    66f7:      	leal	-0xa(%rcx), %edx
    66fa:      	cmpl	$0x4, %edx
    66fd:      	jb	0x67be <generic_usdt_filter_arg+0x4ce>
    6703:      	leal	-0xf(%rcx), %edx
    6706:      	cmpl	$0x2, %edx
    6709:      	jb	0x6af3 <generic_usdt_filter_arg+0x803>
    670f:      	movq	%rsi, %r8
    6712:      	cmpl	$0x7, %ecx
    6715:      	jne	0x65b8 <generic_usdt_filter_arg+0x2c8>
    671b:      	movq	$0x0, 0x60(%rsp)
    6724:      	movq	$0x0, 0x58(%rsp)
    672d:      	movq	$0x0, 0x50(%rsp)
    6736:      	movq	$0x0, 0x48(%rsp)
    673f:      	movq	$0x0, 0x40(%rsp)
    6748:      	cmpl	$0x27, %ecx
    674b:      	jg	0x68ec <generic_usdt_filter_arg+0x5fc>
    6751:      	cmpl	$0x5, %ecx
    6754:      	movq	%r8, %rsi
    6757:      	je	0x7074 <generic_usdt_filter_arg+0xd84>
    675d:      	movq	%rsi, %rdx
    6760:      	movl	$0x0, %ebx
    6765:      	cmpl	$0x7, %ecx
    6768:      	je	0x7076 <generic_usdt_filter_arg+0xd86>
    676e:      	jmp	0x65a2 <generic_usdt_filter_arg+0x2b2>
    6773:      	cmpl	$0x1, %ecx
    6776:      	je	0x67be <generic_usdt_filter_arg+0x4ce>
    6778:      	cmpl	$0x2, %ecx
    677b:      	jne	0x65b8 <generic_usdt_filter_arg+0x2c8>
    6781:      	movl	0x4(%rsi), %ebp
    6784:      	addq	$0x8, %rsi
    6788:      	cmpl	$0x19, %eax
    678b:      	jg	0x7354 <generic_usdt_filter_arg+0x1064>
    6791:      	leal	-0x3(%rax), %ecx
    6794:      	cmpl	$0x2, %ecx
    6797:      	jb	0x7bdc <generic_usdt_filter_arg+0x18ec>
    679d:      	movq	%rsi, 0x8(%rsp)
    67a2:      	cmpl	$0x8, %eax
    67a5:      	je	0x7b3c <generic_usdt_filter_arg+0x184c>
    67ab:      	movl	$0x0, %ebx
    67b0:      	cmpl	$0x9, %eax
    67b3:      	je	0x7379 <generic_usdt_filter_arg+0x1089>
    67b9:      	jmp	0x9585 <generic_usdt_filter_arg+0x3295>
    67be:      	movq	%rsi, 0x8(%rsp)
    67c3:      	cmpl	$0xb, %ecx
    67c6:      	jle	0x6857 <generic_usdt_filter_arg+0x567>
    67cc:      	cmpl	$0x24, %ecx
    67cf:      	ja	0x689e <generic_usdt_filter_arg+0x5ae>
    67d5:      	movl	%ecx, %edx
    67d7:      	movabsq	$0x1e00000000, %rsi     # imm = 0x1E00000000
    67e1:      	btq	%rdx, %rsi
    67e5:      	jb	0x6872 <generic_usdt_filter_arg+0x582>
    67eb:      	movl	$0x60000000, %esi       # imm = 0x60000000
    67f0:      	btq	%rdx, %rsi
    67f4:      	jb	0x6c49 <generic_usdt_filter_arg+0x959>
    67fa:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    6804:      	btq	%rdx, %rsi
    6808:      	jae	0x689e <generic_usdt_filter_arg+0x5ae>
    680e:      	cmpl	$0x20, %eax
    6811:      	ja	0x63fd <generic_usdt_filter_arg+0x10d>
    6817:      	movl	%eax, %ecx
    6819:      	movl	$0x101e, %edx           # imm = 0x101E
    681e:      	btq	%rcx, %rdx
    6822:      	jae	0x74cf <generic_usdt_filter_arg+0x11df>
    6828:      	movl	0x10(%r12), %ecx
    682d:      	cmpl	$0x2, %eax
    6830:      	jle	0x79dc <generic_usdt_filter_arg+0x16ec>
    6836:      	leal	-0x3(%rax), %edx
    6839:      	cmpl	$0x2, %edx
    683c:      	movq	0x8(%rsp), %rdx
    6841:      	jae	0x800f <generic_usdt_filter_arg+0x1d1f>
    6847:      	movzbl	(%rdx), %edx
    684a:      	cmpl	%edx, %ecx
    684c:      	jne	0x832d <generic_usdt_filter_arg+0x203d>
    6852:      	jmp	0x9511 <generic_usdt_filter_arg+0x3221>
    6857:      	leal	-0xa(%rcx), %edx
    685a:      	cmpl	$0x2, %edx
    685d:      	jb	0x6ce3 <generic_usdt_filter_arg+0x9f3>
    6863:      	cmpl	$0x1, %ecx
    6866:      	je	0x68aa <generic_usdt_filter_arg+0x5ba>
    6868:      	cmpl	$0x4, %ecx
    686b:      	je	0x68aa <generic_usdt_filter_arg+0x5ba>
    686d:      	jmp	0x65b8 <generic_usdt_filter_arg+0x2c8>
    6872:      	cmpl	$0x9, %eax
    6875:      	jle	0x6c92 <generic_usdt_filter_arg+0x9a2>
    687b:      	cmpl	$0x1d, %eax
    687e:      	jg	0x70f9 <generic_usdt_filter_arg+0xe09>
    6884:      	leal	-0xa(%rax), %edx
    6887:      	cmpl	$0x2, %edx
    688a:      	jb	0x6d79 <generic_usdt_filter_arg+0xa89>
    6890:      	cmpl	$0xc, %eax
    6893:      	je	0x6cf9 <generic_usdt_filter_arg+0xa09>
    6899:      	jmp	0x63fd <generic_usdt_filter_arg+0x10d>
    689e:      	leal	-0xc(%rcx), %edx
    68a1:      	cmpl	$0x2, %edx
    68a4:      	jae	0x6cda <generic_usdt_filter_arg+0x9ea>
    68aa:      	cmpl	$0x20, %eax
    68ad:      	ja	0x63fd <generic_usdt_filter_arg+0x10d>
    68b3:      	movl	%eax, %edx
    68b5:      	movl	$0x101e, %esi           # imm = 0x101E
    68ba:      	btq	%rdx, %rsi
    68be:      	jae	0x690e <generic_usdt_filter_arg+0x61e>
    68c0:      	movl	0x10(%r12), %edx
    68c5:      	cmpl	$0x2, %eax
    68c8:      	jle	0x6c9f <generic_usdt_filter_arg+0x9af>
    68ce:      	leal	-0x3(%rax), %esi
    68d1:      	cmpl	$0x2, %esi
    68d4:      	jae	0x74b4 <generic_usdt_filter_arg+0x11c4>
    68da:      	movq	0x8(%rsp), %rsi
    68df:      	cmpl	%edx, (%rsi)
    68e1:      	jne	0x85b1 <generic_usdt_filter_arg+0x22c1>
    68e7:      	jmp	0x9511 <generic_usdt_filter_arg+0x3221>
    68ec:      	cmpl	$0x28, %ecx
    68ef:      	movq	%r8, %rsi
    68f2:      	je	0x704c <generic_usdt_filter_arg+0xd5c>
    68f8:      	movq	%rsi, %rdx
    68fb:      	movl	$0x0, %ebx
    6900:      	cmpl	$0x29, %ecx
    6903:      	je	0x7076 <generic_usdt_filter_arg+0xd86>
    6909:      	jmp	0x65a2 <generic_usdt_filter_arg+0x2b2>
    690e:      	movl	$0xc00, %esi            # imm = 0xC00
    6913:      	btq	%rdx, %rsi
    6917:      	jb	0x6fe6 <generic_usdt_filter_arg+0xcf6>
    691d:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    6927:      	btq	%rdx, %rsi
    692b:      	jae	0x63fd <generic_usdt_filter_arg+0x10d>
    6931:      	cmpl	$0x1f, %eax
    6934:      	jne	0x7621 <generic_usdt_filter_arg+0x1331>
    693a:      	movl	0x10(%r12), %esi
    693f:      	movl	0x14(%r12), %edx
    6944:      	cmpl	$0xc, %ecx
    6947:      	ja	0x83d4 <generic_usdt_filter_arg+0x20e4>
    694d:      	movl	$0x1402, %eax           # imm = 0x1402
    6952:      	btl	%ecx, %eax
    6955:      	jae	0x83d4 <generic_usdt_filter_arg+0x20e4>
    695b:      	movq	0x8(%rsp), %rax
    6960:      	movl	(%rax), %eax
    6962:      	cmpl	%eax, %esi
    6964:      	jg	0x83e7 <generic_usdt_filter_arg+0x20f7>
    696a:      	cmpl	%edx, %eax
    696c:      	jle	0x65b8 <generic_usdt_filter_arg+0x2c8>
    6972:      	jmp	0x83e7 <generic_usdt_filter_arg+0x20f7>
    6977:      	cmpl	$0x20, %eax
    697a:      	jg	0x7145 <generic_usdt_filter_arg+0xe55>
    6980:      	cmpl	$0x1a, %eax
    6983:      	je	0x7227 <generic_usdt_filter_arg+0xf37>
    6989:      	movl	$0x0, %ebx
    698e:      	cmpl	$0x1b, %eax
    6991:      	jne	0x92b7 <generic_usdt_filter_arg+0x2fc7>
    6997:      	movq	%rsi, 0x8(%rsp)
    699c:      	movq	%r11, 0x20(%rsp)
    69a1:      	movl	0x10(%r12), %eax
    69a6:      	movl	%eax, 0x40(%rsp)
    69aa:      	movl	$0x0, 0x80(%rsp)
    69b5:      	movl	$0x1, %eax
    69ba:      	leaq	0x40(%rsp), %rsi
    69bf:      	movq	(%rip), %rdi            # 0x69c6 <generic_usdt_filter_arg+0x6d6>
    69c6:      	callq	*%rax
    69c8:      	testl	%ebp, %ebp
    69ca:      	je	0x92a6 <generic_usdt_filter_arg+0x2fb6>
    69d0:      	movl	$0x0, %ebx
    69d5:      	testq	%rax, %rax
    69d8:      	je	0x92a8 <generic_usdt_filter_arg+0x2fb8>
    69de:      	movq	%rax, 0x28(%rsp)
    69e3:      	movl	$0x1, %eax
    69e8:      	movq	0x38(%rsp), %rsi
    69ed:      	movq	(%rip), %rdi            # 0x69f4 <generic_usdt_filter_arg+0x704>
    69f4:      	callq	*%rax
    69f6:      	testq	%rax, %rax
    69f9:      	je	0x92a6 <generic_usdt_filter_arg+0x2fb6>
    69ff:      	movq	%rax, %rdi
    6a02:      	cmpl	$0x7f, %ebp
    6a05:      	movl	$0x7f, %eax
    6a0a:      	cmovbl	%ebp, %eax
    6a0d:      	shll	$0x3, %eax
    6a10:      	movl	%eax, (%rdi)
    6a12:      	movq	%rbp, %rax
    6a15:      	negq	%rax
    6a18:      	movl	$0x3, %ecx
    6a1d:      	subq	%rbp, %rcx
    6a20:      	leal	-0x4(%rbp), %edx
    6a23:      	movq	%rdi, 0x70(%rsp)
    6a28:      	addq	$0x7, %rdi
    6a2c:      	movl	$0x2, %r8d
    6a32:      	subq	%rbp, %r8
    6a35:      	leal	-0x3(%rbp), %r9d
    6a39:      	movl	$0x1, %r10d
    6a3f:      	subq	%rbp, %r10
    6a42:      	leal	-0x2(%rbp), %r11d
    6a46:      	decl	%ebp
    6a48:      	xorl	%ebx, %ebx
    6a4a:      	movq	0x8(%rsp), %rsi
    6a4f:      	leal	(%rbx,%rbp), %r13d
    6a53:      	andl	$0xfff, %r13d           # imm = 0xFFF
    6a5a:      	movzbl	(%rsi,%r13), %r13d
    6a5f:      	movb	%r13b, -0x3(%rdi)
    6a63:      	cmpq	%rbx, %r10
    6a66:      	je	0x6ac0 <generic_usdt_filter_arg+0x7d0>
    6a68:      	leal	(%r11,%rbx), %r13d
    6a6c:      	andl	$0xfff, %r13d           # imm = 0xFFF
    6a73:      	movzbl	(%rsi,%r13), %r13d
    6a78:      	movb	%r13b, -0x2(%rdi)
    6a7c:      	cmpq	%rbx, %r8
    6a7f:      	je	0x6ac0 <generic_usdt_filter_arg+0x7d0>
    6a81:      	leal	(%r9,%rbx), %r13d
    6a85:      	andl	$0xfff, %r13d           # imm = 0xFFF
    6a8c:      	movzbl	(%rsi,%r13), %r13d
    6a91:      	movb	%r13b, -0x1(%rdi)
    6a95:      	cmpq	%rbx, %rcx
    6a98:      	je	0x6ac0 <generic_usdt_filter_arg+0x7d0>
    6a9a:      	cmpq	$-0x7c, %rbx
    6a9e:      	je	0x6ac0 <generic_usdt_filter_arg+0x7d0>
    6aa0:      	leal	(%rdx,%rbx), %r13d
    6aa4:      	andl	$0xfff, %r13d           # imm = 0xFFF
    6aab:      	movzbl	(%rsi,%r13), %r13d
    6ab0:      	movb	%r13b, (%rdi)
    6ab3:      	addq	$-0x4, %rbx
    6ab7:      	addq	$0x4, %rdi
    6abb:      	cmpq	%rbx, %rax
    6abe:      	jne	0x6a4f <generic_usdt_filter_arg+0x75f>
    6ac0:      	movl	$0x1, %eax
    6ac5:      	movq	0x28(%rsp), %rdi
    6aca:      	movq	0x70(%rsp), %rsi
    6acf:      	callq	*%rax
    6ad1:      	xorl	%ebx, %ebx
    6ad3:      	testq	%rax, %rax
    6ad6:      	setne	%bl
    6ad9:      	movq	0x78(%rsp), %r13
    6ade:      	jmp	0x92a8 <generic_usdt_filter_arg+0x2fb8>
    6ae3:      	cmpl	$0x11, %ecx
    6ae6:      	jne	0x65b8 <generic_usdt_filter_arg+0x2c8>
    6aec:      	movq	%r8, %rsi
    6aef:      	addq	$0x4, %rsi
    6af3:      	movq	%rsi, 0x8(%rsp)
    6af8:      	movl	(%rsi), %ebp
    6afa:      	movl	%eax, %ecx
    6afc:      	andl	$-0x2, %ecx
    6aff:      	cmpl	$0x24, %ecx
    6b02:      	je	0x6b0c <generic_usdt_filter_arg+0x81c>
    6b04:      	testl	%ebp, %ebp
    6b06:      	je	0x63fd <generic_usdt_filter_arg+0x10d>
    6b0c:      	cmpl	$0x25, %eax
    6b0f:      	movq	0x8(%rsp), %rsi
    6b14:      	ja	0x6c14 <generic_usdt_filter_arg+0x924>
    6b1a:      	movl	%eax, %ecx
    6b1c:      	movl	$0x4000100, %edx        # imm = 0x4000100
    6b21:      	btq	%rcx, %rdx
    6b25:      	jb	0x6f3e <generic_usdt_filter_arg+0xc4e>
    6b2b:      	movl	$0x8000200, %edx        # imm = 0x8000200
    6b30:      	btq	%rcx, %rdx
    6b34:      	jb	0x6df3 <generic_usdt_filter_arg+0xb03>
    6b3a:      	movabsq	$0x3000000000, %rdx     # imm = 0x3000000000
    6b44:      	btq	%rcx, %rdx
    6b48:      	jae	0x6c14 <generic_usdt_filter_arg+0x924>
    6b4e:      	movw	$0x0, 0x40(%rsp)
    6b55:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
    6b5b:      	ja	0x6c33 <generic_usdt_filter_arg+0x943>
    6b61:      	movq	%r11, 0x20(%rsp)
    6b66:      	leaq	(%rsi,%rbp), %rcx
    6b6a:      	addq	$0x8, %rcx
    6b6e:      	movl	$0x4, %eax
    6b73:      	leaq	0x40(%rsp), %rdi
    6b78:      	movl	$0x2, %edx
    6b7d:      	movl	(%rsi), %ecx
    6b7f:      	leaq	(%rsi,%rcx), %rdx
    6b83:      	addq	$0x8, %rdx
    6b87:      	movl	$0x2, %esi
    6b8c:      	callq	*%rax
    6b8e:      	movl	0x10(%r12), %ecx
    6b93:      	testl	%ecx, %ecx
    6b95:      	je	0x90c9 <generic_usdt_filter_arg+0x2dd9>
    6b9b:      	movzwl	0x40(%rsp), %eax
    6ba0:      	andl	$0xf000, %eax           # imm = 0xF000
    6ba5:      	movl	$0x1, %ebx
    6baa:      	cmpl	%eax, %ecx
    6bac:      	je	0x90cb <generic_usdt_filter_arg+0x2ddb>
    6bb2:      	movl	0x8(%r12), %ecx
    6bb7:      	cmpl	$0xd, %ecx
    6bba:      	movq	0x10(%rsp), %rdi
    6bbf:      	movq	0x18(%rsp), %r9
    6bc4:      	movq	0x20(%rsp), %r11
    6bc9:      	jb	0x6c33 <generic_usdt_filter_arg+0x943>
    6bcb:      	movl	0x14(%r12), %edx
    6bd0:      	testl	%edx, %edx
    6bd2:      	je	0x6c33 <generic_usdt_filter_arg+0x943>
    6bd4:      	cmpl	%eax, %edx
    6bd6:      	je	0x90da <generic_usdt_filter_arg+0x2dea>
    6bdc:      	cmpl	$0x11, %ecx
    6bdf:      	jb	0x6c33 <generic_usdt_filter_arg+0x943>
    6be1:      	movl	0x18(%r12), %edx
    6be6:      	testl	%edx, %edx
    6be8:      	je	0x6c33 <generic_usdt_filter_arg+0x943>
    6bea:      	cmpl	%eax, %edx
    6bec:      	je	0x90da <generic_usdt_filter_arg+0x2dea>
    6bf2:      	cmpl	$0x15, %ecx
    6bf5:      	jb	0x95f4 <generic_usdt_filter_arg+0x3304>
    6bfb:      	movl	0x1c(%r12), %ecx
    6c00:      	testl	%ecx, %ecx
    6c02:      	je	0x95f4 <generic_usdt_filter_arg+0x3304>
    6c08:      	xorl	%ebx, %ebx
    6c0a:      	cmpl	%eax, %ecx
    6c0c:      	sete	%bl
    6c0f:      	jmp	0x95f6 <generic_usdt_filter_arg+0x3306>
    6c14:      	addl	$-0x3, %eax
    6c17:      	cmpl	$0x2, %eax
    6c1a:      	jae	0x6c33 <generic_usdt_filter_arg+0x943>
    6c1c:      	movl	$0x0, 0x80(%rsp)
    6c27:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
    6c2d:      	jbe	0x75cb <generic_usdt_filter_arg+0x12db>
    6c33:      	xorl	%ebx, %ebx
    6c35:      	movl	0x4(%r12), %eax
    6c3a:      	cmpq	$0x25, %rax
    6c3e:      	jbe	0x90e9 <generic_usdt_filter_arg+0x2df9>
    6c44:      	jmp	0x65a7 <generic_usdt_filter_arg+0x2b7>
    6c49:      	cmpl	$0x20, %eax
    6c4c:      	ja	0x63fd <generic_usdt_filter_arg+0x10d>
    6c52:      	movl	%eax, %ecx
    6c54:      	movl	$0x101e, %edx           # imm = 0x101E
    6c59:      	btq	%rcx, %rdx
    6c5d:      	jae	0x7505 <generic_usdt_filter_arg+0x1215>
    6c63:      	movl	0x10(%r12), %ecx
    6c68:      	cmpl	$0x2, %eax
    6c6b:      	jle	0x7a03 <generic_usdt_filter_arg+0x1713>
    6c71:      	leal	-0x3(%rax), %edx
    6c74:      	cmpl	$0x2, %edx
    6c77:      	movq	0x8(%rsp), %rdx
    6c7c:      	jae	0x802d <generic_usdt_filter_arg+0x1d3d>
    6c82:      	movzwl	(%rdx), %edx
    6c85:      	cmpl	%edx, %ecx
    6c87:      	jne	0x837a <generic_usdt_filter_arg+0x208a>
    6c8d:      	jmp	0x9511 <generic_usdt_filter_arg+0x3221>
    6c92:      	leal	-0x1(%rax), %edx
    6c95:      	cmpl	$0x4, %edx
    6c98:      	jb	0x6cf9 <generic_usdt_filter_arg+0xa09>
    6c9a:      	jmp	0x63fd <generic_usdt_filter_arg+0x10d>
    6c9f:      	cmpl	$0x1, %eax
    6ca2:      	je	0x778f <generic_usdt_filter_arg+0x149f>
    6ca8:      	cmpl	$0x2, %eax
    6cab:      	jne	0x85b1 <generic_usdt_filter_arg+0x22c1>
    6cb1:      	cmpl	$0xc, %ecx
    6cb4:      	ja	0x85a4 <generic_usdt_filter_arg+0x22b4>
    6cba:      	movl	$0x1402, %esi           # imm = 0x1402
    6cbf:      	btl	%ecx, %esi
    6cc2:      	jae	0x85a4 <generic_usdt_filter_arg+0x22b4>
    6cc8:      	movq	0x8(%rsp), %rsi
    6ccd:      	cmpl	%edx, (%rsi)
    6ccf:      	jl	0x65b8 <generic_usdt_filter_arg+0x2c8>
    6cd5:      	jmp	0x85b1 <generic_usdt_filter_arg+0x22c1>
    6cda:      	cmpl	$0x1c, %ecx
    6cdd:      	jne	0x65b8 <generic_usdt_filter_arg+0x2c8>
    6ce3:      	cmpl	$0x20, %eax
    6ce6:      	ja	0x63fd <generic_usdt_filter_arg+0x10d>
    6cec:      	movl	%eax, %edx
    6cee:      	movl	$0x101e, %esi           # imm = 0x101E
    6cf3:      	btq	%rdx, %rsi
    6cf7:      	jae	0x6d22 <generic_usdt_filter_arg+0xa32>
    6cf9:      	movq	0x10(%r12), %rdx
    6cfe:      	cmpl	$0x2, %eax
    6d01:      	jle	0x6d46 <generic_usdt_filter_arg+0xa56>
    6d03:      	leal	-0x3(%rax), %esi
    6d06:      	cmpl	$0x2, %esi
    6d09:      	jae	0x7030 <generic_usdt_filter_arg+0xd40>
    6d0f:      	movq	0x8(%rsp), %rsi
    6d14:      	cmpq	%rdx, (%rsi)
    6d17:      	jne	0x7f83 <generic_usdt_filter_arg+0x1c93>
    6d1d:      	jmp	0x9511 <generic_usdt_filter_arg+0x3221>
    6d22:      	movl	$0xc00, %esi            # imm = 0xC00
    6d27:      	btq	%rdx, %rsi
    6d2b:      	jb	0x6d79 <generic_usdt_filter_arg+0xa89>
    6d2d:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
    6d37:      	btq	%rdx, %rsi
    6d3b:      	jb	0x7105 <generic_usdt_filter_arg+0xe15>
    6d41:      	jmp	0x63fd <generic_usdt_filter_arg+0x10d>
    6d46:      	cmpl	$0x1, %eax
    6d49:      	je	0x75aa <generic_usdt_filter_arg+0x12ba>
    6d4f:      	cmpl	$0x2, %eax
    6d52:      	jne	0x7f83 <generic_usdt_filter_arg+0x1c93>
    6d58:      	cmpl	$0xc, %ecx
    6d5b:      	je	0x6d66 <generic_usdt_filter_arg+0xa76>
    6d5d:      	cmpl	$0xa, %ecx
    6d60:      	jne	0x7f75 <generic_usdt_filter_arg+0x1c85>
    6d66:      	movq	0x8(%rsp), %rsi
    6d6b:      	cmpq	%rdx, (%rsi)
    6d6e:      	jl	0x65b8 <generic_usdt_filter_arg+0x2c8>
    6d74:      	jmp	0x7f83 <generic_usdt_filter_arg+0x1c93>
    6d79:      	movq	%r11, %rbp
    6d7c:      	movzbl	0x10(%r12), %eax
    6d82:      	movl	%eax, 0x80(%rsp)
    6d89:      	movl	$0x1, %eax
    6d8e:      	movq	0x38(%rsp), %rsi
    6d93:      	movq	(%rip), %rdi            # 0x6d9a <generic_usdt_filter_arg+0xaaa>
    6d9a:      	callq	*%rax
    6d9c:      	testq	%rax, %rax
    6d9f:      	je	0x7aeb <generic_usdt_filter_arg+0x17fb>
    6da5:      	movq	%rax, %rdi
    6da8:      	movq	0x8(%rsp), %rax
    6dad:      	movq	(%rax), %rax
    6db0:      	movq	%rax, 0x40(%rsp)
    6db5:      	movl	$0x1, %eax
    6dba:      	leaq	0x40(%rsp), %rsi
    6dbf:      	callq	*%rax
    6dc1:      	movl	0x4(%r12), %ecx
    6dc6:      	cmpl	$0xb, %ecx
    6dc9:      	je	0x7b17 <generic_usdt_filter_arg+0x1827>
    6dcf:      	cmpl	$0xa, %ecx
    6dd2:      	movq	0x10(%rsp), %rdi
    6dd7:      	movq	0x18(%rsp), %r9
    6ddc:      	movq	%rbp, %r11
    6ddf:      	jne	0x7b32 <generic_usdt_filter_arg+0x1842>
    6de5:      	testq	%rax, %rax
    6de8:      	setne	%al
    6deb:      	movzbl	%al, %ebx
    6dee:      	jmp	0x65a7 <generic_usdt_filter_arg+0x2b7>
    6df3:      	movq	%r11, 0x20(%rsp)
    6df8:      	movl	0x10(%r12), %eax
    6dfd:      	movl	%eax, 0x40(%rsp)
    6e01:      	movl	$0x0, 0x80(%rsp)
    6e0c:      	movl	$0x1, %eax
    6e11:      	leaq	0x40(%rsp), %rsi
    6e16:      	movq	(%rip), %rdi            # 0x6e1d <generic_usdt_filter_arg+0xb2d>
    6e1d:      	callq	*%rax
    6e1f:      	testl	%ebp, %ebp
    6e21:      	je	0x90c9 <generic_usdt_filter_arg+0x2dd9>
    6e27:      	movl	$0x0, %ebx
    6e2c:      	testq	%rax, %rax
    6e2f:      	je	0x90cb <generic_usdt_filter_arg+0x2ddb>
    6e35:      	movq	%rax, 0x28(%rsp)
    6e3a:      	movl	$0x1, %eax
    6e3f:      	movq	0x38(%rsp), %rsi
    6e44:      	movq	(%rip), %rdi            # 0x6e4b <generic_usdt_filter_arg+0xb5b>
    6e4b:      	callq	*%rax
    6e4d:      	testq	%rax, %rax
    6e50:      	je	0x90c9 <generic_usdt_filter_arg+0x2dd9>
    6e56:      	movq	%rax, %rdi
    6e59:      	cmpl	$0x7f, %ebp
    6e5c:      	movl	$0x7f, %eax
    6e61:      	cmovbl	%ebp, %eax
    6e64:      	shll	$0x3, %eax
    6e67:      	movl	%eax, (%rdi)
    6e69:      	movq	%rbp, %rax
    6e6c:      	negq	%rax
    6e6f:      	movl	$0x3, %ecx
    6e74:      	subq	%rbp, %rcx
    6e77:      	leal	-0x4(%rbp), %edx
    6e7a:      	movq	%rdi, 0x70(%rsp)
    6e7f:      	addq	$0x7, %rdi
    6e83:      	movl	$0x2, %r8d
    6e89:      	subq	%rbp, %r8
    6e8c:      	leal	-0x3(%rbp), %r9d
    6e90:      	movl	$0x1, %r10d
    6e96:      	subq	%rbp, %r10
    6e99:      	leal	-0x2(%rbp), %r11d
    6e9d:      	decl	%ebp
    6e9f:      	xorl	%ebx, %ebx
    6ea1:      	movq	0x8(%rsp), %rsi
    6ea6:      	leal	(%rbx,%rbp), %r13d
    6eaa:      	andl	$0xfff, %r13d           # imm = 0xFFF
    6eb1:      	movzbl	0x4(%rsi,%r13), %r13d
    6eb7:      	movb	%r13b, -0x3(%rdi)
    6ebb:      	cmpq	%rbx, %r10
    6ebe:      	je	0x6f1b <generic_usdt_filter_arg+0xc2b>
    6ec0:      	leal	(%r11,%rbx), %r13d
    6ec4:      	andl	$0xfff, %r13d           # imm = 0xFFF
    6ecb:      	movzbl	0x4(%rsi,%r13), %r13d
    6ed1:      	movb	%r13b, -0x2(%rdi)
    6ed5:      	cmpq	%rbx, %r8
    6ed8:      	je	0x6f1b <generic_usdt_filter_arg+0xc2b>
    6eda:      	leal	(%r9,%rbx), %r13d
    6ede:      	andl	$0xfff, %r13d           # imm = 0xFFF
    6ee5:      	movzbl	0x4(%rsi,%r13), %r13d
    6eeb:      	movb	%r13b, -0x1(%rdi)
    6eef:      	cmpq	%rbx, %rcx
    6ef2:      	je	0x6f1b <generic_usdt_filter_arg+0xc2b>
    6ef4:      	cmpq	$-0x7c, %rbx
    6ef8:      	je	0x6f1b <generic_usdt_filter_arg+0xc2b>
    6efa:      	leal	(%rdx,%rbx), %r13d
    6efe:      	andl	$0xfff, %r13d           # imm = 0xFFF
    6f05:      	movzbl	0x4(%rsi,%r13), %r13d
    6f0b:      	movb	%r13b, (%rdi)
    6f0e:      	addq	$-0x4, %rbx
    6f12:      	addq	$0x4, %rdi
    6f16:      	cmpq	%rbx, %rax
    6f19:      	jne	0x6ea6 <generic_usdt_filter_arg+0xbb6>
    6f1b:      	movl	$0x1, %eax
    6f20:      	movq	0x28(%rsp), %rdi
    6f25:      	movq	0x70(%rsp), %rsi
    6f2a:      	callq	*%rax
    6f2c:      	xorl	%ebx, %ebx
    6f2e:      	testq	%rax, %rax
    6f31:      	setne	%bl
    6f34:      	movq	0x78(%rsp), %r13
    6f39:      	jmp	0x90cb <generic_usdt_filter_arg+0x2ddb>
    6f3e:      	movq	%r11, 0x20(%rsp)
    6f43:      	movl	0x10(%r12), %eax
    6f48:      	movl	%eax, 0x40(%rsp)
    6f4c:      	movl	$0x0, 0x80(%rsp)
    6f57:      	movl	$0x1, %eax
    6f5c:      	leaq	0x40(%rsp), %rsi
    6f61:      	movq	(%rip), %rdi            # 0x6f68 <generic_usdt_filter_arg+0xc78>
    6f68:      	callq	*%rax
    6f6a:      	testl	%ebp, %ebp
    6f6c:      	je	0x90c9 <generic_usdt_filter_arg+0x2dd9>
    6f72:      	movl	$0x0, %ebx
    6f77:      	testq	%rax, %rax
    6f7a:      	je	0x90cb <generic_usdt_filter_arg+0x2ddb>
    6f80:      	movq	%rax, 0x28(%rsp)
    6f85:      	movl	$0x1, %eax
    6f8a:      	movq	0x38(%rsp), %rsi
    6f8f:      	movq	(%rip), %rdi            # 0x6f96 <generic_usdt_filter_arg+0xca6>
    6f96:      	callq	*%rax
    6f98:      	testq	%rax, %rax
    6f9b:      	je	0x90c9 <generic_usdt_filter_arg+0x2dd9>
    6fa1:      	movq	%rax, %rbx
    6fa4:      	movq	0x8(%rsp), %rdx
    6fa9:      	addq	$0x4, %rdx
    6fad:      	cmpl	$0xff, %ebp
    6fb3:      	movl	$0xff, %eax
    6fb8:      	cmovael	%eax, %ebp
    6fbb:      	leal	(,%rbp,8), %eax
    6fc2:      	movl	%eax, (%rbx)
    6fc4:      	movq	%rbx, %rdi
    6fc7:      	addq	$0x4, %rdi
    6fcb:      	movl	$0x4, %eax
    6fd0:      	movl	%ebp, %esi
    6fd2:      	callq	*%rax
    6fd4:      	movl	$0x1, %eax
    6fd9:      	movq	0x28(%rsp), %rdi
    6fde:      	movq	%rbx, %rsi
    6fe1:      	jmp	0x90bd <generic_usdt_filter_arg+0x2dcd>
    6fe6:      	movq	%r11, %rbp
    6fe9:      	movzbl	0x10(%r12), %eax
    6fef:      	movl	%eax, 0x80(%rsp)
    6ff6:      	movl	$0x1, %eax
    6ffb:      	movq	0x38(%rsp), %rsi
    7000:      	movq	(%rip), %rdi            # 0x7007 <generic_usdt_filter_arg+0xd17>
    7007:      	callq	*%rax
    7009:      	testq	%rax, %rax
    700c:      	je	0x7aeb <generic_usdt_filter_arg+0x17fb>
    7012:      	movq	%rax, %rdi
    7015:      	movq	0x8(%rsp), %rax
    701a:      	movl	(%rax), %eax
    701c:      	movq	%rax, 0x40(%rsp)
    7021:      	movl	$0x1, %eax
    7026:      	leaq	0x40(%rsp), %rsi
    702b:      	jmp	0x7ab4 <generic_usdt_filter_arg+0x17c4>
    7030:      	cmpl	$0xc, %eax
    7033:      	jne	0x7f83 <generic_usdt_filter_arg+0x1c93>
    7039:      	movq	0x8(%rsp), %rsi
    703e:      	testq	%rdx, (%rsi)
    7041:      	jne	0x65b8 <generic_usdt_filter_arg+0x2c8>
    7047:      	jmp	0x7f83 <generic_usdt_filter_arg+0x1c93>
    704c:      	movzwl	(%rsi), %edx
    704f:      	movw	%dx, 0x66(%rsp)
    7054:      	movzwl	0x2(%rsi), %edx
    7058:      	movw	%dx, 0x60(%rsp)
    705d:      	movq	0x8(%rsi), %rdx
    7061:      	movq	%rdx, 0x40(%rsp)
    7066:      	movq	0x10(%rsi), %rdx
    706a:      	movq	%rdx, 0x48(%rsp)
    706f:      	leaq	0x40(%rsp), %rsi
    7074:      	xorl	%edx, %edx
    7076:      	cmpl	$0x13, %eax
    7079:      	jle	0x70a2 <generic_usdt_filter_arg+0xdb2>
    707b:      	cmpl	$0x17, %eax
    707e:      	jg	0x70d4 <generic_usdt_filter_arg+0xde4>
    7080:      	leal	-0x14(%rax), %ecx
    7083:      	cmpl	$0x2, %ecx
    7086:      	jb	0x7673 <generic_usdt_filter_arg+0x1383>
    708c:      	leal	-0x16(%rax), %ecx
    708f:      	movl	$0x0, %ebx
    7094:      	cmpl	$0x2, %ecx
    7097:      	jb	0x766c <generic_usdt_filter_arg+0x137c>
    709d:      	jmp	0x65a2 <generic_usdt_filter_arg+0x2b2>
    70a2:      	cmpl	$0xf, %eax
    70a5:      	jle	0x732f <generic_usdt_filter_arg+0x103f>
    70ab:      	cmpl	$0x11, %eax
    70ae:      	jg	0x7659 <generic_usdt_filter_arg+0x1369>
    70b4:      	cmpl	$0x10, %eax
    70b7:      	je	0x766c <generic_usdt_filter_arg+0x137c>
    70bd:      	movl	$0x0, %ebx
    70c2:      	cmpl	$0x11, %eax
    70c5:      	jne	0x65a2 <generic_usdt_filter_arg+0x2b2>
    70cb:      	movzwl	0x24(%rsi), %ebx
    70cf:      	jmp	0x7ede <generic_usdt_filter_arg+0x1bee>
    70d4:      	cmpl	$0x1b, %eax
    70d7:      	jg	0x76ac <generic_usdt_filter_arg+0x13bc>
    70dd:      	cmpl	$0x18, %eax
    70e0:      	je	0x76e6 <generic_usdt_filter_arg+0x13f6>
    70e6:      	movl	$0x0, %ebx
    70eb:      	cmpl	$0x19, %eax
    70ee:      	je	0x76dc <generic_usdt_filter_arg+0x13ec>
    70f4:      	jmp	0x65a2 <generic_usdt_filter_arg+0x2b2>
    70f9:      	leal	-0x1f(%rax), %edx
    70fc:      	cmpl	$0x2, %edx
    70ff:      	jae	0x7c0e <generic_usdt_filter_arg+0x191e>
    7105:      	cmpl	$0x1f, %eax
    7108:      	jne	0x72fd <generic_usdt_filter_arg+0x100d>
    710e:      	movq	0x10(%r12), %rsi
    7113:      	movq	0x18(%r12), %rdx
    7118:      	cmpl	$0xa, %ecx
    711b:      	je	0x7126 <generic_usdt_filter_arg+0xe36>
    711d:      	cmpl	$0xc, %ecx
    7120:      	jne	0x7e31 <generic_usdt_filter_arg+0x1b41>
    7126:      	movq	0x8(%rsp), %rax
    712b:      	movq	(%rax), %rax
    712e:      	cmpq	%rax, %rsi
    7131:      	jg	0x7e47 <generic_usdt_filter_arg+0x1b57>
    7137:      	cmpq	%rdx, %rax
    713a:      	jle	0x65b8 <generic_usdt_filter_arg+0x2c8>
    7140:      	jmp	0x7e47 <generic_usdt_filter_arg+0x1b57>
    7145:      	cmpl	$0x21, %eax
    7148:      	je	0x77b8 <generic_usdt_filter_arg+0x14c8>
    714e:      	movl	$0x0, %ebx
    7153:      	cmpl	$0x22, %eax
    7156:      	jne	0x92b7 <generic_usdt_filter_arg+0x2fc7>
    715c:      	movq	%rsi, 0x8(%rsp)
    7161:      	xorl	%ebx, %ebx
    7163:      	xorl	%r13d, %r13d
    7166:      	movq	%r11, %r15
    7169:      	movl	0x10(%r12,%rbx,4), %eax
    716e:      	movl	%eax, 0x40(%rsp)
    7172:      	movl	$0x1, %eax
    7177:      	leaq	0x40(%rsp), %rsi
    717c:      	movq	(%rip), %rdi            # 0x7183 <generic_usdt_filter_arg+0xe93>
    7183:      	callq	*%rax
    7185:      	testq	%rax, %rax
    7188:      	je	0x8683 <generic_usdt_filter_arg+0x2393>
    718e:      	testl	%ebp, %ebp
    7190:      	movq	%r15, %r11
    7193:      	movq	0x68(%rsp), %r15
    7198:      	je	0x7204 <generic_usdt_filter_arg+0xf14>
    719a:      	movq	0x8(%rsp), %rdx
    719f:      	xorl	%ecx, %ecx
    71a1:      	jmp	0x71ae <generic_usdt_filter_arg+0xebe>
    71a3:      	incq	%rcx
    71a6:      	incq	%rdx
    71a9:      	cmpq	%rbp, %rcx
    71ac:      	je	0x7204 <generic_usdt_filter_arg+0xf14>
    71ae:      	xorl	%esi, %esi
    71b0:      	leaq	(%rcx,%rsi), %rdi
    71b4:      	cmpq	%rbp, %rdi
    71b7:      	jae	0x71a3 <generic_usdt_filter_arg+0xeb3>
    71b9:      	movsbl	(%rax,%rsi), %edi
    71bd:      	testl	%edi, %edi
    71bf:      	je	0x71fc <generic_usdt_filter_arg+0xf0c>
    71c1:      	movsbl	(%rdx,%rsi), %r9d
    71c6:      	leal	-0x41(%r9), %r10d
    71ca:      	movl	%r9d, %r8d
    71cd:      	orl	$0x20, %r8d
    71d1:      	cmpl	$0x1a, %r10d
    71d5:      	cmovael	%r9d, %r8d
    71d9:      	leal	-0x41(%rdi), %r10d
    71dd:      	movl	%edi, %r9d
    71e0:      	orl	$0x20, %r9d
    71e4:      	cmpl	$0x1a, %r10d
    71e8:      	cmovael	%edi, %r9d
    71ec:      	cmpq	$0x62, %rsi
    71f0:      	ja	0x71a3 <generic_usdt_filter_arg+0xeb3>
    71f2:      	incq	%rsi
    71f5:      	cmpl	%r9d, %r8d
    71f8:      	je	0x71b0 <generic_usdt_filter_arg+0xec0>
    71fa:      	jmp	0x71a3 <generic_usdt_filter_arg+0xeb3>
    71fc:      	testl	%ecx, %ecx
    71fe:      	jns	0x8978 <generic_usdt_filter_arg+0x2688>
    7204:      	leal	0xc(%r13), %eax
    7208:      	cmpl	0x8(%r12), %eax
    720d:      	jae	0x7220 <generic_usdt_filter_arg+0xf30>
    720f:      	addl	$0x4, %r13d
    7213:      	incq	%rbx
    7216:      	cmpq	$0x64, %rbx
    721a:      	jne	0x7166 <generic_usdt_filter_arg+0xe76>
    7220:      	xorl	%ebx, %ebx
    7222:      	jmp	0x897d <generic_usdt_filter_arg+0x268d>
    7227:      	movq	%rsi, 0x8(%rsp)
    722c:      	movq	%r11, 0x20(%rsp)
    7231:      	movl	0x10(%r12), %eax
    7236:      	movl	%eax, 0x40(%rsp)
    723a:      	movl	$0x0, 0x80(%rsp)
    7245:      	movl	$0x1, %eax
    724a:      	leaq	0x40(%rsp), %rsi
    724f:      	movq	(%rip), %rdi            # 0x7256 <generic_usdt_filter_arg+0xf66>
    7256:      	callq	*%rax
    7258:      	testl	%ebp, %ebp
    725a:      	je	0x92a6 <generic_usdt_filter_arg+0x2fb6>
    7260:      	movl	$0x0, %ebx
    7265:      	testq	%rax, %rax
    7268:      	je	0x92a8 <generic_usdt_filter_arg+0x2fb8>
    726e:      	movq	%rax, 0x28(%rsp)
    7273:      	movl	$0x1, %eax
    7278:      	movq	0x38(%rsp), %rsi
    727d:      	movq	(%rip), %rdi            # 0x7284 <generic_usdt_filter_arg+0xf94>
    7284:      	callq	*%rax
    7286:      	testq	%rax, %rax
    7289:      	je	0x92a6 <generic_usdt_filter_arg+0x2fb6>
    728f:      	cmpl	$0xff, %ebp
    7295:      	movl	$0xff, %ecx
    729a:      	cmovael	%ecx, %ebp
    729d:      	leal	(,%rbp,8), %ecx
    72a4:      	movl	%ecx, (%rax)
    72a6:      	movq	%rax, %rdi
    72a9:      	addq	$0x4, %rdi
    72ad:      	movq	%rax, %rbx
    72b0:      	movl	$0x4, %eax
    72b5:      	movq	0x8(%rsp), %rdx
    72ba:      	movl	%ebp, %esi
    72bc:      	callq	*%rax
    72be:      	movl	$0x1, %eax
    72c3:      	movq	0x28(%rsp), %rdi
    72c8:      	movq	%rbx, %rsi
    72cb:      	jmp	0x929a <generic_usdt_filter_arg+0x2faa>
    72d0:      	movl	$0x0, 0x80(%rsp)
    72db:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
    72e1:      	jbe	0x7872 <generic_usdt_filter_arg+0x1582>
    72e7:      	xorl	%ebx, %ebx
    72e9:      	movl	0x4(%r12), %eax
    72ee:      	cmpq	$0x25, %rax
    72f2:      	jbe	0x92c6 <generic_usdt_filter_arg+0x2fd6>
    72f8:      	jmp	0x65a7 <generic_usdt_filter_arg+0x2b7>
    72fd:      	movq	0x10(%r12), %rsi
    7302:      	movq	0x18(%r12), %rax
    7307:      	cmpl	$0xc, %ecx
    730a:      	je	0x7315 <generic_usdt_filter_arg+0x1025>
    730c:      	cmpl	$0xa, %ecx
    730f:      	jne	0x7e89 <generic_usdt_filter_arg+0x1b99>
    7315:      	movq	0x8(%rsp), %rdx
    731a:      	movq	(%rdx), %rdx
    731d:      	cmpq	%rdx, %rsi
    7320:      	setle	%sil
    7324:      	cmpq	%rax, %rdx
    7327:      	setle	%al
    732a:      	jmp	0x7e9e <generic_usdt_filter_arg+0x1bae>
    732f:      	cmpl	$0xd, %eax
    7332:      	je	0x76e6 <generic_usdt_filter_arg+0x13f6>
    7338:      	cmpl	$0xe, %eax
    733b:      	je	0x76dc <generic_usdt_filter_arg+0x13ec>
    7341:      	movl	$0x0, %ebx
    7346:      	cmpl	$0xf, %eax
    7349:      	je	0x7673 <generic_usdt_filter_arg+0x1383>
    734f:      	jmp	0x65a2 <generic_usdt_filter_arg+0x2b2>
    7354:      	cmpl	$0x20, %eax
    7357:      	movq	%rsi, 0x8(%rsp)
    735c:      	jg	0x7948 <generic_usdt_filter_arg+0x1658>
    7362:      	cmpl	$0x1a, %eax
    7365:      	je	0x7b3c <generic_usdt_filter_arg+0x184c>
    736b:      	movl	$0x0, %ebx
    7370:      	cmpl	$0x1b, %eax
    7373:      	jne	0x9585 <generic_usdt_filter_arg+0x3295>
    7379:      	movq	%r11, 0x20(%rsp)
    737e:      	movl	0x10(%r12), %eax
    7383:      	movl	%eax, 0x40(%rsp)
    7387:      	movl	$0x0, 0x80(%rsp)
    7392:      	movl	$0x1, %eax
    7397:      	leaq	0x40(%rsp), %rsi
    739c:      	movq	(%rip), %rdi            # 0x73a3 <generic_usdt_filter_arg+0x10b3>
    73a3:      	callq	*%rax
    73a5:      	testl	%ebp, %ebp
    73a7:      	je	0x9574 <generic_usdt_filter_arg+0x3284>
    73ad:      	movq	%rax, %r13
    73b0:      	movl	$0x0, %ebx
    73b5:      	testq	%rax, %rax
    73b8:      	je	0x9576 <generic_usdt_filter_arg+0x3286>
    73be:      	movl	$0x1, %eax
    73c3:      	movq	0x38(%rsp), %rsi
    73c8:      	movq	(%rip), %rdi            # 0x73cf <generic_usdt_filter_arg+0x10df>
    73cf:      	callq	*%rax
    73d1:      	testq	%rax, %rax
    73d4:      	je	0x9574 <generic_usdt_filter_arg+0x3284>
    73da:      	movq	%rax, %rdi
    73dd:      	movq	%r13, 0x28(%rsp)
    73e2:      	cmpl	$0x7f, %ebp
    73e5:      	movl	$0x7f, %eax
    73ea:      	cmovbl	%ebp, %eax
    73ed:      	shll	$0x3, %eax
    73f0:      	movl	%eax, (%rdi)
    73f2:      	movq	%rbp, %rax
    73f5:      	negq	%rax
    73f8:      	movl	$0x3, %ecx
    73fd:      	subq	%rbp, %rcx
    7400:      	leal	-0x4(%rbp), %edx
    7403:      	movq	%rdi, 0x70(%rsp)
    7408:      	addq	$0x7, %rdi
    740c:      	movl	$0x2, %r8d
    7412:      	subq	%rbp, %r8
    7415:      	leal	-0x3(%rbp), %r9d
    7419:      	movl	$0x1, %r10d
    741f:      	subq	%rbp, %r10
    7422:      	leal	-0x2(%rbp), %r11d
    7426:      	decl	%ebp
    7428:      	xorl	%ebx, %ebx
    742a:      	movq	0x8(%rsp), %rsi
    742f:      	leal	(%rbx,%rbp), %r13d
    7433:      	andl	$0xfff, %r13d           # imm = 0xFFF
    743a:      	movzbl	(%rsi,%r13), %r13d
    743f:      	movb	%r13b, -0x3(%rdi)
    7443:      	cmpq	%rbx, %r10
    7446:      	je	0x74a0 <generic_usdt_filter_arg+0x11b0>
    7448:      	leal	(%r11,%rbx), %r13d
    744c:      	andl	$0xfff, %r13d           # imm = 0xFFF
    7453:      	movzbl	(%rsi,%r13), %r13d
    7458:      	movb	%r13b, -0x2(%rdi)
    745c:      	cmpq	%rbx, %r8
    745f:      	je	0x74a0 <generic_usdt_filter_arg+0x11b0>
    7461:      	leal	(%r9,%rbx), %r13d
    7465:      	andl	$0xfff, %r13d           # imm = 0xFFF
    746c:      	movzbl	(%rsi,%r13), %r13d
    7471:      	movb	%r13b, -0x1(%rdi)
    7475:      	cmpq	%rbx, %rcx
    7478:      	je	0x74a0 <generic_usdt_filter_arg+0x11b0>
    747a:      	cmpq	$-0x7c, %rbx
    747e:      	je	0x74a0 <generic_usdt_filter_arg+0x11b0>
    7480:      	leal	(%rdx,%rbx), %r13d
    7484:      	andl	$0xfff, %r13d           # imm = 0xFFF
    748b:      	movzbl	(%rsi,%r13), %r13d
    7490:      	movb	%r13b, (%rdi)
    7493:      	addq	$-0x4, %rbx
    7497:      	addq	$0x4, %rdi
    749b:      	cmpq	%rbx, %rax
    749e:      	jne	0x742f <generic_usdt_filter_arg+0x113f>
    74a0:      	movl	$0x1, %eax
    74a5:      	movq	0x28(%rsp), %rdi
    74aa:      	movq	0x70(%rsp), %rsi
    74af:      	jmp	0x9568 <generic_usdt_filter_arg+0x3278>
    74b4:      	cmpl	$0xc, %eax
    74b7:      	jne	0x85b1 <generic_usdt_filter_arg+0x22c1>
    74bd:      	movq	0x8(%rsp), %rsi
    74c2:      	testl	%edx, (%rsi)
    74c4:      	jne	0x65b8 <generic_usdt_filter_arg+0x2c8>
    74ca:      	jmp	0x85b1 <generic_usdt_filter_arg+0x22c1>
    74cf:      	movl	$0xc00, %edx            # imm = 0xC00
    74d4:      	btq	%rcx, %rdx
    74d8:      	jb	0x7a2a <generic_usdt_filter_arg+0x173a>
    74de:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    74e8:      	btq	%rcx, %rdx
    74ec:      	jae	0x63fd <generic_usdt_filter_arg+0x10d>
    74f2:      	cmpl	$0x1f, %eax
    74f5:      	jne	0x8184 <generic_usdt_filter_arg+0x1e94>
    74fb:      	movq	0x8(%rsp), %rax
    7500:      	movzbl	(%rax), %eax
    7503:      	jmp	0x7539 <generic_usdt_filter_arg+0x1249>
    7505:      	movl	$0xc00, %edx            # imm = 0xC00
    750a:      	btq	%rcx, %rdx
    750e:      	jb	0x7a72 <generic_usdt_filter_arg+0x1782>
    7514:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    751e:      	btq	%rcx, %rdx
    7522:      	jae	0x63fd <generic_usdt_filter_arg+0x10d>
    7528:      	cmpl	$0x1f, %eax
    752b:      	jne	0x8193 <generic_usdt_filter_arg+0x1ea3>
    7531:      	movq	0x8(%rsp), %rax
    7536:      	movzwl	(%rax), %eax
    7539:      	cmpl	%eax, 0x10(%r12)
    753e:      	ja	0x754b <generic_usdt_filter_arg+0x125b>
    7540:      	cmpl	%eax, 0x14(%r12)
    7545:      	jae	0x65b8 <generic_usdt_filter_arg+0x2c8>
    754b:      	movl	0x8(%r12), %ecx
    7550:      	cmpl	$0x11, %ecx
    7553:      	jb	0x63fd <generic_usdt_filter_arg+0x10d>
    7559:      	cmpl	%eax, 0x18(%r12)
    755e:      	ja	0x756b <generic_usdt_filter_arg+0x127b>
    7560:      	cmpl	%eax, 0x1c(%r12)
    7565:      	jae	0x65b8 <generic_usdt_filter_arg+0x2c8>
    756b:      	cmpl	$0x19, %ecx
    756e:      	jb	0x63fd <generic_usdt_filter_arg+0x10d>
    7574:      	cmpl	%eax, 0x20(%r12)
    7579:      	ja	0x7586 <generic_usdt_filter_arg+0x1296>
    757b:      	cmpl	%eax, 0x24(%r12)
    7580:      	jae	0x65b8 <generic_usdt_filter_arg+0x2c8>
    7586:      	cmpl	$0x21, %ecx
    7589:      	jb	0x63fd <generic_usdt_filter_arg+0x10d>
    758f:      	cmpl	%eax, 0x28(%r12)
    7594:      	ja	0x63fd <generic_usdt_filter_arg+0x10d>
    759a:      	cmpl	%eax, 0x2c(%r12)
    759f:      	jae	0x65b8 <generic_usdt_filter_arg+0x2c8>
    75a5:      	jmp	0x63fd <generic_usdt_filter_arg+0x10d>
    75aa:      	cmpl	$0xc, %ecx
    75ad:      	je	0x75b8 <generic_usdt_filter_arg+0x12c8>
    75af:      	cmpl	$0xa, %ecx
    75b2:      	jne	0x7f65 <generic_usdt_filter_arg+0x1c75>
    75b8:      	movq	0x8(%rsp), %rsi
    75bd:      	cmpq	%rdx, (%rsi)
    75c0:      	jg	0x65b8 <generic_usdt_filter_arg+0x2c8>
    75c6:      	jmp	0x7f83 <generic_usdt_filter_arg+0x1c93>
    75cb:      	movzwl	%bp, %eax
    75ce:      	cmpl	$0x90, %eax
    75d3:      	movq	%r11, 0x20(%rsp)
    75d8:      	ja	0x7c7f <generic_usdt_filter_arg+0x198f>
    75de:      	testw	%bp, %bp
    75e1:      	je	0x75f3 <generic_usdt_filter_arg+0x1303>
    75e3:      	movl	%ebp, %eax
    75e5:      	movl	$0x18, %ecx
    75ea:      	cltd
    75eb:      	idivl	%ecx
    75ed:      	movl	%ebp, %esi
    75ef:      	testl	%edx, %edx
    75f1:      	je	0x7615 <generic_usdt_filter_arg+0x1325>
    75f3:      	movl	%ebp, %eax
    75f5:      	movl	$0x18, %ecx
    75fa:      	cltd
    75fb:      	idivl	%ecx
    75fd:      	shll	$0x3, %eax
    7600:      	leal	(%rax,%rax,2), %eax
    7603:      	addl	$0x18, %eax
    7606:      	movzwl	%ax, %esi
    7609:      	cmpl	$0x90, %esi
    760f:      	ja	0x7c93 <generic_usdt_filter_arg+0x19a3>
    7615:      	movl	%esi, %eax
    7617:      	cltd
    7618:      	idivl	%ecx
    761a:      	decl	%eax
    761c:      	jmp	0x7ca4 <generic_usdt_filter_arg+0x19b4>
    7621:      	movl	0x10(%r12), %esi
    7626:      	movl	0x14(%r12), %eax
    762b:      	cmpl	$0xc, %ecx
    762e:      	ja	0x8432 <generic_usdt_filter_arg+0x2142>
    7634:      	movl	$0x1402, %edx           # imm = 0x1402
    7639:      	btl	%ecx, %edx
    763c:      	jae	0x8432 <generic_usdt_filter_arg+0x2142>
    7642:      	movq	0x8(%rsp), %rdx
    7647:      	movl	(%rdx), %edx
    7649:      	cmpl	%edx, %esi
    764b:      	setle	%sil
    764f:      	cmpl	%eax, %edx
    7651:      	setle	%al
    7654:      	jmp	0x8444 <generic_usdt_filter_arg+0x2154>
    7659:      	cmpl	$0x12, %eax
    765c:      	je	0x7673 <generic_usdt_filter_arg+0x1383>
    765e:      	movl	$0x0, %ebx
    7663:      	cmpl	$0x13, %eax
    7666:      	jne	0x65a2 <generic_usdt_filter_arg+0x2b2>
    766c:      	movzwl	0x22(%rsi), %r13d
    7671:      	jmp	0x7678 <generic_usdt_filter_arg+0x1388>
    7673:      	movzwl	0x20(%rsi), %r13d
    7678:      	xorl	%edx, %edx
    767a:      	xorl	%ebp, %ebp
    767c:      	xorl	%r8d, %r8d
    767f:      	xorl	%ebx, %ebx
    7681:      	cmpl	$0x11, %eax
    7684:      	jg	0x76fe <generic_usdt_filter_arg+0x140e>
    7686:      	leal	-0xd(%rax), %ecx
    7689:      	cmpl	$0x2, %ecx
    768c:      	jb	0x7731 <generic_usdt_filter_arg+0x1441>
    7692:      	leal	-0xf(%rax), %ecx
    7695:      	cmpl	$0x2, %ecx
    7698:      	jb	0x78d4 <generic_usdt_filter_arg+0x15e4>
    769e:      	cmpl	$0x11, %eax
    76a1:      	je	0x7ede <generic_usdt_filter_arg+0x1bee>
    76a7:      	jmp	0x65a2 <generic_usdt_filter_arg+0x2b2>
    76ac:      	cmpl	$0x1c, %eax
    76af:      	je	0x7eda <generic_usdt_filter_arg+0x1bea>
    76b5:      	movl	$0x0, %ebx
    76ba:      	cmpl	$0x1d, %eax
    76bd:      	jne	0x65a2 <generic_usdt_filter_arg+0x2b2>
    76c3:      	cmpl	$0x7, %ecx
    76c6:      	jne	0x8522 <generic_usdt_filter_arg+0x2232>
    76cc:      	testq	%rdx, %rdx
    76cf:      	jne	0x852e <generic_usdt_filter_arg+0x223e>
    76d5:      	xorl	%ebx, %ebx
    76d7:      	jmp	0x8540 <generic_usdt_filter_arg+0x2250>
    76dc:      	movq	0x10(%rsi), %rdx
    76e0:      	movq	0x18(%rsi), %r8
    76e4:      	jmp	0x76ed <generic_usdt_filter_arg+0x13fd>
    76e6:      	movq	(%rsi), %rdx
    76e9:      	movq	0x8(%rsi), %r8
    76ed:      	movq	%rdx, %rbp
    76f0:      	shrq	$0x20, %rbp
    76f4:      	xorl	%r13d, %r13d
    76f7:      	xorl	%ebx, %ebx
    76f9:      	cmpl	$0x11, %eax
    76fc:      	jle	0x7686 <generic_usdt_filter_arg+0x1396>
    76fe:      	cmpl	$0x19, %eax
    7701:      	ja	0x78c8 <generic_usdt_filter_arg+0x15d8>
    7707:      	movl	$0x500000, %ecx         # imm = 0x500000
    770c:      	btl	%eax, %ecx
    770f:      	jb	0x7c59 <generic_usdt_filter_arg+0x1969>
    7715:      	movl	$0xa00000, %ecx         # imm = 0xA00000
    771a:      	btl	%eax, %ecx
    771d:      	jb	0x7c6c <generic_usdt_filter_arg+0x197c>
    7723:      	movl	$0x3000000, %ecx        # imm = 0x3000000
    7728:      	btl	%eax, %ecx
    772b:      	jae	0x78c8 <generic_usdt_filter_arg+0x15d8>
    7731:      	movzwl	0x26(%rsi), %eax
    7735:      	cmpl	$0xa, %eax
    7738:      	je	0x7d86 <generic_usdt_filter_arg+0x1a96>
    773e:      	cmpl	$0x2, %eax
    7741:      	jne	0x7e27 <generic_usdt_filter_arg+0x1b37>
    7747:      	movq	%rdx, %r13
    774a:      	movq	%r11, 0x20(%rsp)
    774f:      	movl	0x10(%r12), %eax
    7754:      	movl	%eax, 0x34(%rsp)
    7758:      	movl	$0x1, %eax
    775d:      	leaq	0x34(%rsp), %rsi
    7762:      	movq	(%rip), %rdi            # 0x7769 <generic_usdt_filter_arg+0x1479>
    7769:      	callq	*%rax
    776b:      	testq	%rax, %rax
    776e:      	je	0x804b <generic_usdt_filter_arg+0x1d5b>
    7774:      	movq	%rax, %rdi
    7777:      	movl	$0x20, 0x80(%rsp)
    7782:      	movl	%r13d, 0x84(%rsp)
    778a:      	jmp	0x7de5 <generic_usdt_filter_arg+0x1af5>
    778f:      	cmpl	$0xc, %ecx
    7792:      	ja	0x8595 <generic_usdt_filter_arg+0x22a5>
    7798:      	movl	$0x1402, %esi           # imm = 0x1402
    779d:      	btl	%ecx, %esi
    77a0:      	jae	0x8595 <generic_usdt_filter_arg+0x22a5>
    77a6:      	movq	0x8(%rsp), %rsi
    77ab:      	cmpl	%edx, (%rsi)
    77ad:      	jg	0x65b8 <generic_usdt_filter_arg+0x2c8>
    77b3:      	jmp	0x85b1 <generic_usdt_filter_arg+0x22c1>
    77b8:      	movq	%rsi, 0x8(%rsp)
    77bd:      	xorl	%ebx, %ebx
    77bf:      	xorl	%r13d, %r13d
    77c2:      	movq	%r11, %r15
    77c5:      	movl	0x10(%r12,%rbx,4), %eax
    77ca:      	movl	%eax, 0x40(%rsp)
    77ce:      	movl	$0x1, %eax
    77d3:      	leaq	0x40(%rsp), %rsi
    77d8:      	movq	(%rip), %rdi            # 0x77df <generic_usdt_filter_arg+0x14ef>
    77df:      	callq	*%rax
    77e1:      	testq	%rax, %rax
    77e4:      	je	0x866f <generic_usdt_filter_arg+0x237f>
    77ea:      	testl	%ebp, %ebp
    77ec:      	movq	0x18(%rsp), %r9
    77f1:      	movq	%r15, %r11
    77f4:      	movq	0x68(%rsp), %r15
    77f9:      	je	0x784f <generic_usdt_filter_arg+0x155f>
    77fb:      	movq	0x8(%rsp), %rdx
    7800:      	xorl	%ecx, %ecx
    7802:      	jmp	0x780f <generic_usdt_filter_arg+0x151f>
    7804:      	incq	%rcx
    7807:      	incq	%rdx
    780a:      	cmpq	%rbp, %rcx
    780d:      	je	0x784f <generic_usdt_filter_arg+0x155f>
    780f:      	xorl	%esi, %esi
    7811:      	nopw	%cs:(%rax,%rax)
    7820:      	leaq	(%rcx,%rsi), %rdi
    7824:      	cmpq	%rbp, %rdi
    7827:      	jae	0x7804 <generic_usdt_filter_arg+0x1514>
    7829:      	movzbl	(%rax,%rsi), %edi
    782d:      	testb	%dil, %dil
    7830:      	je	0x7847 <generic_usdt_filter_arg+0x1557>
    7832:      	cmpq	$0x62, %rsi
    7836:      	ja	0x7804 <generic_usdt_filter_arg+0x1514>
    7838:      	leaq	0x1(%rsi), %r8
    783c:      	cmpb	%dil, (%rdx,%rsi)
    7840:      	movq	%r8, %rsi
    7843:      	je	0x7820 <generic_usdt_filter_arg+0x1530>
    7845:      	jmp	0x7804 <generic_usdt_filter_arg+0x1514>
    7847:      	testl	%ecx, %ecx
    7849:      	jns	0x8955 <generic_usdt_filter_arg+0x2665>
    784f:      	leal	0xc(%r13), %eax
    7853:      	cmpl	0x8(%r12), %eax
    7858:      	jae	0x786b <generic_usdt_filter_arg+0x157b>
    785a:      	addl	$0x4, %r13d
    785e:      	incq	%rbx
    7861:      	cmpq	$0x64, %rbx
    7865:      	jne	0x77c2 <generic_usdt_filter_arg+0x14d2>
    786b:      	xorl	%ebx, %ebx
    786d:      	jmp	0x895a <generic_usdt_filter_arg+0x266a>
    7872:      	movzwl	%bp, %eax
    7875:      	cmpl	$0x90, %eax
    787a:      	movq	%r11, 0x20(%rsp)
    787f:      	ja	0x805b <generic_usdt_filter_arg+0x1d6b>
    7885:      	testw	%bp, %bp
    7888:      	je	0x789a <generic_usdt_filter_arg+0x15aa>
    788a:      	movl	%ebp, %eax
    788c:      	movl	$0x18, %ecx
    7891:      	cltd
    7892:      	idivl	%ecx
    7894:      	movl	%ebp, %edi
    7896:      	testl	%edx, %edx
    7898:      	je	0x78bc <generic_usdt_filter_arg+0x15cc>
    789a:      	movl	%ebp, %eax
    789c:      	movl	$0x18, %ecx
    78a1:      	cltd
    78a2:      	idivl	%ecx
    78a4:      	shll	$0x3, %eax
    78a7:      	leal	(%rax,%rax,2), %eax
    78aa:      	addl	$0x18, %eax
    78ad:      	movzwl	%ax, %edi
    78b0:      	cmpl	$0x90, %edi
    78b6:      	ja	0x806f <generic_usdt_filter_arg+0x1d7f>
    78bc:      	movl	%edi, %eax
    78be:      	cltd
    78bf:      	idivl	%ecx
    78c1:      	decl	%eax
    78c3:      	jmp	0x8080 <generic_usdt_filter_arg+0x1d90>
    78c8:      	addl	$-0x12, %eax
    78cb:      	cmpl	$0x2, %eax
    78ce:      	jae	0x65a2 <generic_usdt_filter_arg+0x2b2>
    78d4:      	movq	%r11, %rbp
    78d7:      	movzbl	0x10(%r12), %eax
    78dd:      	movl	%eax, 0x34(%rsp)
    78e1:      	movl	$0x1, %eax
    78e6:      	movq	(%rip), %rdi            # 0x78ed <generic_usdt_filter_arg+0x15fd>
    78ed:      	leaq	0x34(%rsp), %rsi
    78f2:      	callq	*%rax
    78f4:      	testq	%rax, %rax
    78f7:      	je	0x7bfa <generic_usdt_filter_arg+0x190a>
    78fd:      	movq	%rax, %rdi
    7900:      	movzwl	%r13w, %eax
    7904:      	movq	%rax, 0x80(%rsp)
    790c:      	movl	$0x1, %eax
    7911:      	movq	0x38(%rsp), %rsi
    7916:      	callq	*%rax
    7918:      	movl	0x4(%r12), %edx
    791d:      	xorl	%ecx, %ecx
    791f:      	cmpl	$0x1d, %edx
    7922:      	ja	0x8f99 <generic_usdt_filter_arg+0x2ca9>
    7928:      	movl	$0x30038400, %esi       # imm = 0x30038400
    792d:      	btl	%edx, %esi
    7930:      	movq	0x10(%rsp), %rdi
    7935:      	movq	0x18(%rsp), %r9
    793a:      	movq	%rbp, %r11
    793d:      	jb	0x6599 <generic_usdt_filter_arg+0x2a9>
    7943:      	jmp	0x7f4c <generic_usdt_filter_arg+0x1c5c>
    7948:      	cmpl	$0x21, %eax
    794b:      	je	0x8218 <generic_usdt_filter_arg+0x1f28>
    7951:      	movl	$0x0, %ebx
    7956:      	cmpl	$0x22, %eax
    7959:      	jne	0x9585 <generic_usdt_filter_arg+0x3295>
    795f:      	movl	$0x10, %r13d
    7965:      	movq	%r11, %r15
    7968:      	movl	(%r12,%r13), %eax
    796c:      	movl	%eax, 0x40(%rsp)
    7970:      	movl	$0x1, %eax
    7975:      	leaq	0x40(%rsp), %rsi
    797a:      	movq	(%rip), %rdi            # 0x7981 <generic_usdt_filter_arg+0x1691>
    7981:      	callq	*%rax
    7983:      	testq	%rax, %rax
    7986:      	je	0x8c82 <generic_usdt_filter_arg+0x2992>
    798c:      	movq	0x8(%rsp), %rdi
    7991:      	movq	%rax, %rsi
    7994:      	movq	%rbp, %rdx
    7997:      	callq	0x799c <generic_usdt_filter_arg+0x16ac>
    799c:      	testl	%eax, %eax
    799e:      	jns	0x8c86 <generic_usdt_filter_arg+0x2996>
    79a4:      	addq	$0x4, %r13
    79a8:      	leal	-0x8(%r13), %eax
    79ac:      	cmpl	0x8(%r12), %eax
    79b1:      	movq	0x10(%rsp), %rdi
    79b6:      	movq	0x18(%rsp), %r9
    79bb:      	movq	%r15, %r11
    79be:      	jae	0x8d32 <generic_usdt_filter_arg+0x2a42>
    79c4:      	movl	$0x0, %ebx
    79c9:      	cmpq	$0x1a0, %r13            # imm = 0x1A0
    79d0:      	movq	0x68(%rsp), %r15
    79d5:      	jne	0x7965 <generic_usdt_filter_arg+0x1675>
    79d7:      	jmp	0x9585 <generic_usdt_filter_arg+0x3295>
    79dc:      	cmpl	$0x1, %eax
    79df:      	je	0x831d <generic_usdt_filter_arg+0x202d>
    79e5:      	cmpl	$0x2, %eax
    79e8:      	jne	0x832d <generic_usdt_filter_arg+0x203d>
    79ee:      	movq	0x8(%rsp), %rdx
    79f3:      	movzbl	(%rdx), %edx
    79f6:      	cmpl	%edx, %ecx
    79f8:      	ja	0x65b8 <generic_usdt_filter_arg+0x2c8>
    79fe:      	jmp	0x832d <generic_usdt_filter_arg+0x203d>
    7a03:      	cmpl	$0x1, %eax
    7a06:      	je	0x836a <generic_usdt_filter_arg+0x207a>
    7a0c:      	cmpl	$0x2, %eax
    7a0f:      	jne	0x837a <generic_usdt_filter_arg+0x208a>
    7a15:      	movq	0x8(%rsp), %rdx
    7a1a:      	movzwl	(%rdx), %edx
    7a1d:      	cmpl	%edx, %ecx
    7a1f:      	ja	0x65b8 <generic_usdt_filter_arg+0x2c8>
    7a25:      	jmp	0x837a <generic_usdt_filter_arg+0x208a>
    7a2a:      	movq	%r11, %rbp
    7a2d:      	movzbl	0x10(%r12), %eax
    7a33:      	movl	%eax, 0x80(%rsp)
    7a3a:      	movl	$0x1, %eax
    7a3f:      	movq	0x38(%rsp), %rsi
    7a44:      	movq	(%rip), %rdi            # 0x7a4b <generic_usdt_filter_arg+0x175b>
    7a4b:      	callq	*%rax
    7a4d:      	testq	%rax, %rax
    7a50:      	je	0x7aeb <generic_usdt_filter_arg+0x17fb>
    7a56:      	movq	%rax, %rdi
    7a59:      	movq	0x8(%rsp), %rax
    7a5e:      	movzbl	(%rax), %eax
    7a61:      	movq	%rax, 0x40(%rsp)
    7a66:      	movl	$0x1, %eax
    7a6b:      	leaq	0x40(%rsp), %rsi
    7a70:      	jmp	0x7ab4 <generic_usdt_filter_arg+0x17c4>
    7a72:      	movq	%r11, %rbp
    7a75:      	movzbl	0x10(%r12), %eax
    7a7b:      	movl	%eax, 0x80(%rsp)
    7a82:      	movl	$0x1, %eax
    7a87:      	movq	0x38(%rsp), %rsi
    7a8c:      	movq	(%rip), %rdi            # 0x7a93 <generic_usdt_filter_arg+0x17a3>
    7a93:      	callq	*%rax
    7a95:      	testq	%rax, %rax
    7a98:      	je	0x7aeb <generic_usdt_filter_arg+0x17fb>
    7a9a:      	movq	%rax, %rdi
    7a9d:      	movq	0x8(%rsp), %rax
    7aa2:      	movzwl	(%rax), %eax
    7aa5:      	movq	%rax, 0x40(%rsp)
    7aaa:      	movl	$0x1, %eax
    7aaf:      	leaq	0x40(%rsp), %rsi
    7ab4:      	callq	*%rax
    7ab6:      	movl	0x4(%r12), %edx
    7abb:      	xorl	%ecx, %ecx
    7abd:      	cmpl	$0x1d, %edx
    7ac0:      	ja	0x8be3 <generic_usdt_filter_arg+0x28f3>
    7ac6:      	movl	$0x30038400, %esi       # imm = 0x30038400
    7acb:      	btl	%edx, %esi
    7ace:      	movq	0x10(%rsp), %rdi
    7ad3:      	movq	0x18(%rsp), %r9
    7ad8:      	movq	%rbp, %r11
    7adb:      	jae	0x7aff <generic_usdt_filter_arg+0x180f>
    7add:      	testq	%rax, %rax
    7ae0:      	setne	%cl
    7ae3:      	movzbl	%cl, %ebx
    7ae6:      	jmp	0x65a7 <generic_usdt_filter_arg+0x2b7>
    7aeb:      	xorl	%ebx, %ebx
    7aed:      	movq	0x10(%rsp), %rdi
    7af2:      	movq	0x18(%rsp), %r9
    7af7:      	movq	%rbp, %r11
    7afa:      	jmp	0x65a7 <generic_usdt_filter_arg+0x2b7>
    7aff:      	movl	$0xc0800, %esi          # imm = 0xC0800
    7b04:      	btl	%edx, %esi
    7b07:      	jae	0x7b0f <generic_usdt_filter_arg+0x181f>
    7b09:      	testq	%rax, %rax
    7b0c:      	sete	%cl
    7b0f:      	movzbl	%cl, %ebx
    7b12:      	jmp	0x65a7 <generic_usdt_filter_arg+0x2b7>
    7b17:      	testq	%rax, %rax
    7b1a:      	sete	%al
    7b1d:      	movq	0x10(%rsp), %rdi
    7b22:      	movq	0x18(%rsp), %r9
    7b27:      	movq	%rbp, %r11
    7b2a:      	movzbl	%al, %ebx
    7b2d:      	jmp	0x65a7 <generic_usdt_filter_arg+0x2b7>
    7b32:      	xorl	%eax, %eax
    7b34:      	movzbl	%al, %ebx
    7b37:      	jmp	0x65a7 <generic_usdt_filter_arg+0x2b7>
    7b3c:      	movq	%r11, 0x20(%rsp)
    7b41:      	movl	0x10(%r12), %eax
    7b46:      	movl	%eax, 0x40(%rsp)
    7b4a:      	movl	$0x0, 0x80(%rsp)
    7b55:      	movl	$0x1, %eax
    7b5a:      	leaq	0x40(%rsp), %rsi
    7b5f:      	movq	(%rip), %rdi            # 0x7b66 <generic_usdt_filter_arg+0x1876>
    7b66:      	callq	*%rax
    7b68:      	testl	%ebp, %ebp
    7b6a:      	je	0x9574 <generic_usdt_filter_arg+0x3284>
    7b70:      	movq	%rax, %r13
    7b73:      	movl	$0x0, %ebx
    7b78:      	testq	%rax, %rax
    7b7b:      	je	0x9576 <generic_usdt_filter_arg+0x3286>
    7b81:      	movl	$0x1, %eax
    7b86:      	movq	0x38(%rsp), %rsi
    7b8b:      	movq	(%rip), %rdi            # 0x7b92 <generic_usdt_filter_arg+0x18a2>
    7b92:      	callq	*%rax
    7b94:      	testq	%rax, %rax
    7b97:      	je	0x9574 <generic_usdt_filter_arg+0x3284>
    7b9d:      	cmpl	$0xff, %ebp
    7ba3:      	movl	$0xff, %ecx
    7ba8:      	cmovael	%ecx, %ebp
    7bab:      	leal	(,%rbp,8), %ecx
    7bb2:      	movl	%ecx, (%rax)
    7bb4:      	movq	%rax, %rdi
    7bb7:      	addq	$0x4, %rdi
    7bbb:      	movq	%rax, %rbx
    7bbe:      	movl	$0x4, %eax
    7bc3:      	movq	0x8(%rsp), %rdx
    7bc8:      	movl	%ebp, %esi
    7bca:      	callq	*%rax
    7bcc:      	movl	$0x1, %eax
    7bd1:      	movq	%r13, %rdi
    7bd4:      	movq	%rbx, %rsi
    7bd7:      	jmp	0x9568 <generic_usdt_filter_arg+0x3278>
    7bdc:      	movl	$0x0, 0x80(%rsp)
    7be7:      	cmpl	$0x1fe, %ebp            # imm = 0x1FE
    7bed:      	jbe	0x82c7 <generic_usdt_filter_arg+0x1fd7>
    7bf3:      	xorl	%ebx, %ebx
    7bf5:      	jmp	0x9585 <generic_usdt_filter_arg+0x3295>
    7bfa:      	xorl	%ebx, %ebx
    7bfc:      	movq	0x10(%rsp), %rdi
    7c01:      	movq	0x18(%rsp), %r9
    7c06:      	movq	%rbp, %r11
    7c09:      	jmp	0x65a2 <generic_usdt_filter_arg+0x2b2>
    7c0e:      	cmpl	$0x1e, %eax
    7c11:      	jne	0x63fd <generic_usdt_filter_arg+0x10d>
    7c17:      	movl	0x10(%r12), %eax
    7c1c:      	andl	$0x7, %eax
    7c1f:      	movl	%eax, %ecx
    7c21:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    7c2a:      	jne	0x63fd <generic_usdt_filter_arg+0x10d>
    7c30:      	movq	0x8(%rsp), %rcx
    7c35:      	movq	(%rcx), %rcx
    7c38:      	movq	0x5e78(%r14,%rax,8), %rax
    7c40:      	andl	$0x7ff, %eax            # imm = 0x7FF
    7c45:      	xorl	%ebx, %ebx
    7c47:      	andnq	0x90(%r14,%rax), %rcx, %rax
    7c51:      	setne	%bl
    7c54:      	jmp	0x65a7 <generic_usdt_filter_arg+0x2b7>
    7c59:      	movzwl	%r13w, %eax
    7c5d:      	xorl	%ebx, %ebx
    7c5f:      	cmpl	$0x400, %eax            # imm = 0x400
    7c64:      	setb	%bl
    7c67:      	jmp	0x65a2 <generic_usdt_filter_arg+0x2b2>
    7c6c:      	movzwl	%r13w, %eax
    7c70:      	xorl	%ebx, %ebx
    7c72:      	cmpl	$0x400, %eax            # imm = 0x400
    7c77:      	setae	%bl
    7c7a:      	jmp	0x65a2 <generic_usdt_filter_arg+0x2b2>
    7c7f:      	cmpl	$0x101, %eax            # imm = 0x101
    7c84:      	movl	$0x100, %esi            # imm = 0x100
    7c89:      	movl	$0x1fe, %eax            # imm = 0x1FE
    7c8e:      	cmovael	%eax, %esi
    7c91:      	movl	%esi, %eax
    7c93:      	movzwl	%ax, %ecx
    7c96:      	xorl	%eax, %eax
    7c98:      	cmpl	$0x100, %ecx            # imm = 0x100
    7c9e:      	sete	%al
    7ca1:      	xorl	$0x7, %eax
    7ca4:      	movl	%eax, %ecx
    7ca6:      	andl	$0xf, %ecx
    7ca9:      	movl	0x10(%r12,%rcx,4), %ecx
    7cae:      	cmpl	$-0x1, %ecx
    7cb1:      	je	0x90c9 <generic_usdt_filter_arg+0x2dd9>
    7cb7:      	movl	%ecx, 0xa0(%rsp)
    7cbe:      	movq	%rsi, 0x98(%rsp)
    7cc6:      	movl	%eax, 0x70(%rsp)
    7cca:      	movl	$0x1, %eax
    7ccf:      	movq	(%rip), %rdi            # 0x7cd6 <generic_usdt_filter_arg+0x19e6>
    7cd6:      	movq	0x38(%rsp), %rbx
    7cdb:      	movq	%rbx, %rsi
    7cde:      	callq	*%rax
    7ce0:      	movq	%rax, 0x28(%rsp)
    7ce5:      	movl	$0x1, %eax
    7cea:      	movq	(%rip), %rdi            # 0x7cf1 <generic_usdt_filter_arg+0x1a01>
    7cf1:      	movq	%rbx, %rsi
    7cf4:      	callq	*%rax
    7cf6:      	cmpq	$0x0, 0x28(%rsp)
    7cfc:      	je	0x90c9 <generic_usdt_filter_arg+0x2dd9>
    7d02:      	movl	$0x0, %ebx
    7d07:      	testq	%rax, %rax
    7d0a:      	movq	0x10(%rsp), %rdi
    7d0f:      	movq	0x18(%rsp), %r9
    7d14:      	movq	0x20(%rsp), %r11
    7d19:      	je	0x90da <generic_usdt_filter_arg+0x2dea>
    7d1f:      	movq	%rax, 0xa8(%rsp)
    7d27:      	movq	0x8(%rsp), %rdx
    7d2c:      	addq	$0x4, %rdx
    7d30:      	movl	0x70(%rsp), %ebx
    7d34:      	cmpl	$0x5, %ebx
    7d37:      	jg	0x86e0 <generic_usdt_filter_arg+0x23f0>
    7d3d:      	movq	0x28(%rsp), %rax
    7d42:      	movb	%bpl, (%rax)
    7d45:      	leaq	0x1(%rax), %rdi
    7d49:      	movl	$0x4, %eax
    7d4e:      	movl	%ebp, %esi
    7d50:      	callq	*%rax
    7d52:      	movq	0x98(%rsp), %rsi
    7d5a:      	subl	%ebp, %esi
    7d5c:      	jbe	0x8723 <generic_usdt_filter_arg+0x2433>
    7d62:      	movq	0x28(%rsp), %rax
    7d67:      	leaq	(%rax,%rbp), %rdi
    7d6b:      	incq	%rdi
    7d6e:      	andl	$0xfff, %esi            # imm = 0xFFF
    7d74:      	movl	$0x4, %eax
    7d79:      	movq	0xa8(%rsp), %rdx
    7d81:      	jmp	0x8721 <generic_usdt_filter_arg+0x2431>
    7d86:      	movq	%r8, %rbx
    7d89:      	movq	%rdx, %r13
    7d8c:      	movq	%r11, 0x20(%rsp)
    7d91:      	movl	0x14(%r12), %eax
    7d96:      	movl	%eax, 0x34(%rsp)
    7d9a:      	movl	$0x1, %eax
    7d9f:      	movq	(%rip), %rdi            # 0x7da6 <generic_usdt_filter_arg+0x1ab6>
    7da6:      	leaq	0x34(%rsp), %rsi
    7dab:      	callq	*%rax
    7dad:      	testq	%rax, %rax
    7db0:      	je	0x804b <generic_usdt_filter_arg+0x1d5b>
    7db6:      	movq	%rax, %rdi
    7db9:      	movl	$0x80, 0x80(%rsp)
    7dc4:      	movl	%r13d, 0x84(%rsp)
    7dcc:      	movl	%ebp, 0x88(%rsp)
    7dd3:      	movl	%ebx, 0x8c(%rsp)
    7dda:      	shrq	$0x20, %rbx
    7dde:      	movl	%ebx, 0x90(%rsp)
    7de5:      	movl	$0x1, %eax
    7dea:      	movq	0x38(%rsp), %rsi
    7def:      	callq	*%rax
    7df1:      	movl	0x4(%r12), %ecx
    7df6:      	leal	-0x18(%rcx), %edx
    7df9:      	cmpl	$0x2, %edx
    7dfc:      	jb	0x83b7 <generic_usdt_filter_arg+0x20c7>
    7e02:      	addl	$-0xd, %ecx
    7e05:      	cmpl	$0x1, %ecx
    7e08:      	movq	0x10(%rsp), %rdi
    7e0d:      	movq	0x18(%rsp), %r9
    7e12:      	movq	0x20(%rsp), %r11
    7e17:      	ja	0x7e27 <generic_usdt_filter_arg+0x1b37>
    7e19:      	testq	%rax, %rax
    7e1c:      	setne	%al
    7e1f:      	movzbl	%al, %ebx
    7e22:      	jmp	0x65a2 <generic_usdt_filter_arg+0x2b2>
    7e27:      	xorl	%eax, %eax
    7e29:      	movzbl	%al, %ebx
    7e2c:      	jmp	0x65a2 <generic_usdt_filter_arg+0x2b2>
    7e31:      	movq	0x8(%rsp), %rax
    7e36:      	movq	(%rax), %rax
    7e39:      	cmpq	%rax, %rsi
    7e3c:      	ja	0x7e47 <generic_usdt_filter_arg+0x1b57>
    7e3e:      	cmpq	%rdx, %rax
    7e41:      	jbe	0x65b8 <generic_usdt_filter_arg+0x2c8>
    7e47:      	movl	0x8(%r12), %edx
    7e4c:      	cmpl	$0x19, %edx
    7e4f:      	jb	0x63fd <generic_usdt_filter_arg+0x10d>
    7e55:      	movq	0x20(%r12), %rdi
    7e5a:      	movq	0x28(%r12), %rsi
    7e5f:      	cmpl	$0xc, %ecx
    7e62:      	je	0x7e6d <generic_usdt_filter_arg+0x1b7d>
    7e64:      	cmpl	$0xa, %ecx
    7e67:      	jne	0x84d2 <generic_usdt_filter_arg+0x21e2>
    7e6d:      	cmpq	%rax, %rdi
    7e70:      	movq	0x10(%rsp), %rdi
    7e75:      	jg	0x84e5 <generic_usdt_filter_arg+0x21f5>
    7e7b:      	cmpq	%rsi, %rax
    7e7e:      	jle	0x65b8 <generic_usdt_filter_arg+0x2c8>
    7e84:      	jmp	0x84e5 <generic_usdt_filter_arg+0x21f5>
    7e89:      	movq	0x8(%rsp), %rdx
    7e8e:      	movq	(%rdx), %rdx
    7e91:      	cmpq	%rdx, %rsi
    7e94:      	setbe	%sil
    7e98:      	cmpq	%rax, %rdx
    7e9b:      	setbe	%al
    7e9e:      	andb	%sil, %al
    7ea1:      	movl	0x8(%r12), %esi
    7ea6:      	cmpl	$0x19, %esi
    7ea9:      	jb	0x9119 <generic_usdt_filter_arg+0x2e29>
    7eaf:      	movq	0x20(%r12), %r8
    7eb4:      	movq	0x28(%r12), %rdi
    7eb9:      	cmpl	$0xc, %ecx
    7ebc:      	je	0x7ec7 <generic_usdt_filter_arg+0x1bd7>
    7ebe:      	cmpl	$0xa, %ecx
    7ec1:      	jne	0x848a <generic_usdt_filter_arg+0x219a>
    7ec7:      	cmpq	%rdx, %r8
    7eca:      	setle	%r8b
    7ece:      	cmpq	%rdi, %rdx
    7ed1:      	setle	%dil
    7ed5:      	jmp	0x8498 <generic_usdt_filter_arg+0x21a8>
    7eda:      	movzwl	0x26(%rsi), %ebx
    7ede:      	movq	%r11, %r13
    7ee1:      	movzbl	0x10(%r12), %eax
    7ee7:      	movl	%eax, 0x34(%rsp)
    7eeb:      	movl	$0x1, %eax
    7ef0:      	movq	(%rip), %rdi            # 0x7ef7 <generic_usdt_filter_arg+0x1c07>
    7ef7:      	leaq	0x34(%rsp), %rsi
    7efc:      	callq	*%rax
    7efe:      	testq	%rax, %rax
    7f01:      	je	0x8581 <generic_usdt_filter_arg+0x2291>
    7f07:      	movq	%rax, %rdi
    7f0a:      	movzwl	%bx, %eax
    7f0d:      	movq	%rax, 0x80(%rsp)
    7f15:      	movl	$0x1, %eax
    7f1a:      	movq	0x38(%rsp), %rsi
    7f1f:      	callq	*%rax
    7f21:      	movl	0x4(%r12), %edx
    7f26:      	xorl	%ecx, %ecx
    7f28:      	cmpl	$0x1d, %edx
    7f2b:      	ja	0x8f2a <generic_usdt_filter_arg+0x2c3a>
    7f31:      	movl	$0x30038400, %esi       # imm = 0x30038400
    7f36:      	btl	%edx, %esi
    7f39:      	movq	0x10(%rsp), %rdi
    7f3e:      	movq	0x18(%rsp), %r9
    7f43:      	movq	%r13, %r11
    7f46:      	jb	0x6599 <generic_usdt_filter_arg+0x2a9>
    7f4c:      	movl	$0xc0800, %esi          # imm = 0xC0800
    7f51:      	btl	%edx, %esi
    7f54:      	jae	0x659f <generic_usdt_filter_arg+0x2af>
    7f5a:      	testq	%rax, %rax
    7f5d:      	sete	%cl
    7f60:      	jmp	0x659f <generic_usdt_filter_arg+0x2af>
    7f65:      	movq	0x8(%rsp), %rsi
    7f6a:      	cmpq	%rdx, (%rsi)
    7f6d:      	ja	0x65b8 <generic_usdt_filter_arg+0x2c8>
    7f73:      	jmp	0x7f83 <generic_usdt_filter_arg+0x1c93>
    7f75:      	movq	0x8(%rsp), %rsi
    7f7a:      	cmpq	%rdx, (%rsi)
    7f7d:      	jb	0x65b8 <generic_usdt_filter_arg+0x2c8>
    7f83:      	movl	0x8(%r12), %edx
    7f88:      	cmpl	$0x11, %edx
    7f8b:      	jb	0x963a <generic_usdt_filter_arg+0x334a>
    7f91:      	movq	0x18(%r12), %rsi
    7f96:      	cmpl	$0x2, %eax
    7f99:      	jle	0x7fbb <generic_usdt_filter_arg+0x1ccb>
    7f9b:      	leal	-0x3(%rax), %edi
    7f9e:      	cmpl	$0x2, %edi
    7fa1:      	jae	0x7fee <generic_usdt_filter_arg+0x1cfe>
    7fa3:      	movq	0x8(%rsp), %rdi
    7fa8:      	cmpq	%rsi, (%rdi)
    7fab:      	movq	0x10(%rsp), %rdi
    7fb0:      	jne	0x8b20 <generic_usdt_filter_arg+0x2830>
    7fb6:      	jmp	0x9511 <generic_usdt_filter_arg+0x3221>
    7fbb:      	cmpl	$0x1, %eax
    7fbe:      	je	0x8163 <generic_usdt_filter_arg+0x1e73>
    7fc4:      	cmpl	$0x2, %eax
    7fc7:      	jne	0x8b20 <generic_usdt_filter_arg+0x2830>
    7fcd:      	cmpl	$0xc, %ecx
    7fd0:      	je	0x7fdb <generic_usdt_filter_arg+0x1ceb>
    7fd2:      	cmpl	$0xa, %ecx
    7fd5:      	jne	0x8b12 <generic_usdt_filter_arg+0x2822>
    7fdb:      	movq	0x8(%rsp), %r8
    7fe0:      	cmpq	%rsi, (%r8)
    7fe3:      	jl	0x65b8 <generic_usdt_filter_arg+0x2c8>
    7fe9:      	jmp	0x8b20 <generic_usdt_filter_arg+0x2830>
    7fee:      	cmpl	$0xc, %eax
    7ff1:      	movq	0x10(%rsp), %rdi
    7ff6:      	jne	0x8b20 <generic_usdt_filter_arg+0x2830>
    7ffc:      	movq	0x8(%rsp), %r8
    8001:      	testq	%rsi, (%r8)
    8004:      	jne	0x65b8 <generic_usdt_filter_arg+0x2c8>
    800a:      	jmp	0x8b20 <generic_usdt_filter_arg+0x2830>
    800f:      	cmpl	$0xc, %eax
    8012:      	jne	0x832d <generic_usdt_filter_arg+0x203d>
    8018:      	movq	0x8(%rsp), %rdx
    801d:      	movzbl	(%rdx), %edx
    8020:      	testl	%edx, %ecx
    8022:      	jne	0x65b8 <generic_usdt_filter_arg+0x2c8>
    8028:      	jmp	0x832d <generic_usdt_filter_arg+0x203d>
    802d:      	cmpl	$0xc, %eax
    8030:      	jne	0x837a <generic_usdt_filter_arg+0x208a>
    8036:      	movq	0x8(%rsp), %rdx
    803b:      	movzwl	(%rdx), %edx
    803e:      	testl	%edx, %ecx
    8040:      	jne	0x65b8 <generic_usdt_filter_arg+0x2c8>
    8046:      	jmp	0x837a <generic_usdt_filter_arg+0x208a>
    804b:      	movl	0x4(%r12), %eax
    8050:      	andl	$-0x2, %eax
    8053:      	cmpl	$0x18, %eax
    8056:      	jmp	0x83ba <generic_usdt_filter_arg+0x20ca>
    805b:      	cmpl	$0x101, %eax            # imm = 0x101
    8060:      	movl	$0x100, %edi            # imm = 0x100
    8065:      	movl	$0x1fe, %eax            # imm = 0x1FE
    806a:      	cmovael	%eax, %edi
    806d:      	movl	%edi, %eax
    806f:      	movzwl	%ax, %ecx
    8072:      	xorl	%eax, %eax
    8074:      	cmpl	$0x100, %ecx            # imm = 0x100
    807a:      	sete	%al
    807d:      	xorl	$0x7, %eax
    8080:      	movl	%eax, %ecx
    8082:      	andl	$0xf, %ecx
    8085:      	movl	0x10(%r12,%rcx,4), %ecx
    808a:      	cmpl	$-0x1, %ecx
    808d:      	je	0x92a6 <generic_usdt_filter_arg+0x2fb6>
    8093:      	movl	%ecx, 0xa0(%rsp)
    809a:      	movq	%rdi, 0x98(%rsp)
    80a2:      	movl	%eax, 0x70(%rsp)
    80a6:      	movq	%rsi, 0x8(%rsp)
    80ab:      	movl	$0x1, %eax
    80b0:      	movq	(%rip), %rdi            # 0x80b7 <generic_usdt_filter_arg+0x1dc7>
    80b7:      	movq	0x38(%rsp), %rbx
    80bc:      	movq	%rbx, %rsi
    80bf:      	callq	*%rax
    80c1:      	movq	%rax, 0x28(%rsp)
    80c6:      	movl	$0x1, %eax
    80cb:      	movq	(%rip), %rdi            # 0x80d2 <generic_usdt_filter_arg+0x1de2>
    80d2:      	movq	%rbx, %rsi
    80d5:      	callq	*%rax
    80d7:      	cmpq	$0x0, 0x28(%rsp)
    80dd:      	je	0x92a6 <generic_usdt_filter_arg+0x2fb6>
    80e3:      	movl	$0x0, %ebx
    80e8:      	testq	%rax, %rax
    80eb:      	movq	0x10(%rsp), %rdi
    80f0:      	movq	0x18(%rsp), %r9
    80f5:      	movq	0x20(%rsp), %r11
    80fa:      	je	0x92b7 <generic_usdt_filter_arg+0x2fc7>
    8100:      	movq	%rax, 0xa8(%rsp)
    8108:      	movl	0x70(%rsp), %ebx
    810c:      	cmpl	$0x5, %ebx
    810f:      	jg	0x89ea <generic_usdt_filter_arg+0x26fa>
    8115:      	movq	0x28(%rsp), %rax
    811a:      	movb	%bpl, (%rax)
    811d:      	leaq	0x1(%rax), %rdi
    8121:      	movl	$0x4, %eax
    8126:      	movq	0x8(%rsp), %rdx
    812b:      	movl	%ebp, %esi
    812d:      	callq	*%rax
    812f:      	movq	0x98(%rsp), %rsi
    8137:      	subl	%ebp, %esi
    8139:      	jbe	0x8a32 <generic_usdt_filter_arg+0x2742>
    813f:      	movq	0x28(%rsp), %rax
    8144:      	leaq	(%rax,%rbp), %rdi
    8148:      	incq	%rdi
    814b:      	andl	$0xfff, %esi            # imm = 0xFFF
    8151:      	movl	$0x4, %eax
    8156:      	movq	0xa8(%rsp), %rdx
    815e:      	jmp	0x8a30 <generic_usdt_filter_arg+0x2740>
    8163:      	cmpl	$0xc, %ecx
    8166:      	je	0x8171 <generic_usdt_filter_arg+0x1e81>
    8168:      	cmpl	$0xa, %ecx
    816b:      	jne	0x8b02 <generic_usdt_filter_arg+0x2812>
    8171:      	movq	0x8(%rsp), %r8
    8176:      	cmpq	%rsi, (%r8)
    8179:      	jg	0x65b8 <generic_usdt_filter_arg+0x2c8>
    817f:      	jmp	0x8b20 <generic_usdt_filter_arg+0x2830>
    8184:      	movl	0x8(%r12), %edx
    8189:      	movq	0x8(%rsp), %rax
    818e:      	movzbl	(%rax), %ecx
    8191:      	jmp	0x81a0 <generic_usdt_filter_arg+0x1eb0>
    8193:      	movl	0x8(%r12), %edx
    8198:      	movq	0x8(%rsp), %rax
    819d:      	movzwl	(%rax), %ecx
    81a0:      	cmpl	%ecx, 0x10(%r12)
    81a5:      	setbe	%sil
    81a9:      	cmpl	%ecx, 0x14(%r12)
    81ae:      	setae	%al
    81b1:      	andb	%sil, %al
    81b4:      	cmpl	$0x11, %edx
    81b7:      	jb	0x9119 <generic_usdt_filter_arg+0x2e29>
    81bd:      	cmpl	%ecx, 0x18(%r12)
    81c2:      	setbe	%sil
    81c6:      	cmpl	%ecx, 0x1c(%r12)
    81cb:      	setae	%dil
    81cf:      	andb	%sil, %dil
    81d2:      	orb	%dil, %al
    81d5:      	cmpl	$0x19, %edx
    81d8:      	jb	0x9114 <generic_usdt_filter_arg+0x2e24>
    81de:      	cmpl	%ecx, 0x20(%r12)
    81e3:      	setbe	%sil
    81e7:      	cmpl	%ecx, 0x24(%r12)
    81ec:      	setae	%dil
    81f0:      	andb	%sil, %dil
    81f3:      	orb	%dil, %al
    81f6:      	cmpl	$0x21, %edx
    81f9:      	jb	0x9114 <generic_usdt_filter_arg+0x2e24>
    81ff:      	cmpl	%ecx, 0x28(%r12)
    8204:      	setbe	%dl
    8207:      	cmpl	%ecx, 0x2c(%r12)
    820c:      	setae	%cl
    820f:      	andb	%dl, %cl
    8211:      	orb	%cl, %al
    8213:      	jmp	0x9114 <generic_usdt_filter_arg+0x2e24>
    8218:      	xorl	%ebx, %ebx
    821a:      	xorl	%r13d, %r13d
    821d:      	movq	%r11, %r15
    8220:      	movl	0x10(%r12,%rbx,4), %eax
    8225:      	movl	%eax, 0x40(%rsp)
    8229:      	movl	$0x1, %eax
    822e:      	leaq	0x40(%rsp), %rsi
    8233:      	movq	(%rip), %rdi            # 0x823a <generic_usdt_filter_arg+0x1f4a>
    823a:      	callq	*%rax
    823c:      	testq	%rax, %rax
    823f:      	je	0x8c19 <generic_usdt_filter_arg+0x2929>
    8245:      	testl	%ebp, %ebp
    8247:      	movq	0x18(%rsp), %r9
    824c:      	movq	%r15, %r11
    824f:      	movq	0x68(%rsp), %r15
    8254:      	je	0x829f <generic_usdt_filter_arg+0x1faf>
    8256:      	movq	0x8(%rsp), %rdx
    825b:      	xorl	%ecx, %ecx
    825d:      	jmp	0x826a <generic_usdt_filter_arg+0x1f7a>
    825f:      	incq	%rcx
    8262:      	incq	%rdx
    8265:      	cmpq	%rbp, %rcx
    8268:      	je	0x829f <generic_usdt_filter_arg+0x1faf>
    826a:      	xorl	%esi, %esi
    826c:      	nopl	(%rax)
    8270:      	leaq	(%rcx,%rsi), %rdi
    8274:      	cmpq	%rbp, %rdi
    8277:      	jae	0x825f <generic_usdt_filter_arg+0x1f6f>
    8279:      	movzbl	(%rax,%rsi), %edi
    827d:      	testb	%dil, %dil
    8280:      	je	0x8297 <generic_usdt_filter_arg+0x1fa7>
    8282:      	cmpq	$0x62, %rsi
    8286:      	ja	0x825f <generic_usdt_filter_arg+0x1f6f>
    8288:      	leaq	0x1(%rsi), %r8
    828c:      	cmpb	%dil, (%rdx,%rsi)
    8290:      	movq	%r8, %rsi
    8293:      	je	0x8270 <generic_usdt_filter_arg+0x1f80>
    8295:      	jmp	0x825f <generic_usdt_filter_arg+0x1f6f>
    8297:      	testl	%ecx, %ecx
    8299:      	jns	0x8f8a <generic_usdt_filter_arg+0x2c9a>
    829f:      	leal	0xc(%r13), %eax
    82a3:      	cmpl	0x8(%r12), %eax
    82a8:      	jae	0x82bb <generic_usdt_filter_arg+0x1fcb>
    82aa:      	addl	$0x4, %r13d
    82ae:      	incq	%rbx
    82b1:      	cmpq	$0x64, %rbx
    82b5:      	jne	0x821d <generic_usdt_filter_arg+0x1f2d>
    82bb:      	xorl	%ebx, %ebx
    82bd:      	movq	0x10(%rsp), %rdi
    82c2:      	jmp	0x9585 <generic_usdt_filter_arg+0x3295>
    82c7:      	movzwl	%bp, %eax
    82ca:      	cmpl	$0x90, %eax
    82cf:      	movq	%r11, 0x20(%rsp)
    82d4:      	ja	0x87b2 <generic_usdt_filter_arg+0x24c2>
    82da:      	testw	%bp, %bp
    82dd:      	je	0x82ef <generic_usdt_filter_arg+0x1fff>
    82df:      	movl	%ebp, %eax
    82e1:      	movl	$0x18, %ecx
    82e6:      	cltd
    82e7:      	idivl	%ecx
    82e9:      	movl	%ebp, %edi
    82eb:      	testl	%edx, %edx
    82ed:      	je	0x8311 <generic_usdt_filter_arg+0x2021>
    82ef:      	movl	%ebp, %eax
    82f1:      	movl	$0x18, %ecx
    82f6:      	cltd
    82f7:      	idivl	%ecx
    82f9:      	shll	$0x3, %eax
    82fc:      	leal	(%rax,%rax,2), %eax
    82ff:      	addl	$0x18, %eax
    8302:      	movzwl	%ax, %edi
    8305:      	cmpl	$0x90, %edi
    830b:      	ja	0x87c6 <generic_usdt_filter_arg+0x24d6>
    8311:      	movl	%edi, %eax
    8313:      	cltd
    8314:      	idivl	%ecx
    8316:      	decl	%eax
    8318:      	jmp	0x87d7 <generic_usdt_filter_arg+0x24e7>
    831d:      	movq	0x8(%rsp), %rdx
    8322:      	movzbl	(%rdx), %edx
    8325:      	cmpl	%edx, %ecx
    8327:      	jb	0x65b8 <generic_usdt_filter_arg+0x2c8>
    832d:      	movl	0x8(%r12), %ecx
    8332:      	cmpl	$0xd, %ecx
    8335:      	jb	0x963a <generic_usdt_filter_arg+0x334a>
    833b:      	movl	0x14(%r12), %edx
    8340:      	cmpl	$0x2, %eax
    8343:      	jle	0x8692 <generic_usdt_filter_arg+0x23a2>
    8349:      	leal	-0x3(%rax), %esi
    834c:      	cmpl	$0x2, %esi
    834f:      	jae	0x8ba7 <generic_usdt_filter_arg+0x28b7>
    8355:      	movq	0x8(%rsp), %rsi
    835a:      	movzbl	(%rsi), %esi
    835d:      	cmpl	%esi, %edx
    835f:      	jne	0x8cb2 <generic_usdt_filter_arg+0x29c2>
    8365:      	jmp	0x9511 <generic_usdt_filter_arg+0x3221>
    836a:      	movq	0x8(%rsp), %rdx
    836f:      	movzwl	(%rdx), %edx
    8372:      	cmpl	%edx, %ecx
    8374:      	jb	0x65b8 <generic_usdt_filter_arg+0x2c8>
    837a:      	movl	0x8(%r12), %ecx
    837f:      	cmpl	$0xd, %ecx
    8382:      	jb	0x963a <generic_usdt_filter_arg+0x334a>
    8388:      	movl	0x14(%r12), %edx
    838d:      	cmpl	$0x2, %eax
    8390:      	jle	0x86b9 <generic_usdt_filter_arg+0x23c9>
    8396:      	leal	-0x3(%rax), %esi
    8399:      	cmpl	$0x2, %esi
    839c:      	jae	0x8bc5 <generic_usdt_filter_arg+0x28d5>
    83a2:      	movq	0x8(%rsp), %rsi
    83a7:      	movzwl	(%rsi), %esi
    83aa:      	cmpl	%esi, %edx
    83ac:      	jne	0x8cfa <generic_usdt_filter_arg+0x2a0a>
    83b2:      	jmp	0x9511 <generic_usdt_filter_arg+0x3221>
    83b7:      	testq	%rax, %rax
    83ba:      	sete	%al
    83bd:      	movq	0x10(%rsp), %rdi
    83c2:      	movq	0x18(%rsp), %r9
    83c7:      	movq	0x20(%rsp), %r11
    83cc:      	movzbl	%al, %ebx
    83cf:      	jmp	0x65a2 <generic_usdt_filter_arg+0x2b2>
    83d4:      	movq	0x8(%rsp), %rax
    83d9:      	movl	(%rax), %eax
    83db:      	cmpl	%eax, %esi
    83dd:      	ja	0x83e7 <generic_usdt_filter_arg+0x20f7>
    83df:      	cmpl	%edx, %eax
    83e1:      	jbe	0x65b8 <generic_usdt_filter_arg+0x2c8>
    83e7:      	movl	0x8(%r12), %edx
    83ec:      	cmpl	$0x11, %edx
    83ef:      	jb	0x63fd <generic_usdt_filter_arg+0x10d>
    83f5:      	movl	0x18(%r12), %edi
    83fa:      	movl	0x1c(%r12), %esi
    83ff:      	cmpl	$0xc, %ecx
    8402:      	ja	0x88fe <generic_usdt_filter_arg+0x260e>
    8408:      	movl	$0x1402, %r8d           # imm = 0x1402
    840e:      	btl	%ecx, %r8d
    8412:      	jae	0x88fe <generic_usdt_filter_arg+0x260e>
    8418:      	cmpl	%eax, %edi
    841a:      	movq	0x10(%rsp), %rdi
    841f:      	jg	0x890f <generic_usdt_filter_arg+0x261f>
    8425:      	cmpl	%esi, %eax
    8427:      	jle	0x65b8 <generic_usdt_filter_arg+0x2c8>
    842d:      	jmp	0x890f <generic_usdt_filter_arg+0x261f>
    8432:      	movq	0x8(%rsp), %rdx
    8437:      	movl	(%rdx), %edx
    8439:      	cmpl	%edx, %esi
    843b:      	setbe	%sil
    843f:      	cmpl	%eax, %edx
    8441:      	setbe	%al
    8444:      	andb	%sil, %al
    8447:      	movl	0x8(%r12), %esi
    844c:      	cmpl	$0x11, %esi
    844f:      	jb	0x9119 <generic_usdt_filter_arg+0x2e29>
    8455:      	movl	0x18(%r12), %r8d
    845a:      	movl	0x1c(%r12), %edi
    845f:      	cmpl	$0xc, %ecx
    8462:      	ja	0x88ad <generic_usdt_filter_arg+0x25bd>
    8468:      	movl	$0x1402, %r10d          # imm = 0x1402
    846e:      	btl	%ecx, %r10d
    8472:      	jae	0x88ad <generic_usdt_filter_arg+0x25bd>
    8478:      	cmpl	%edx, %r8d
    847b:      	setle	%r8b
    847f:      	cmpl	%edi, %edx
    8481:      	setle	%dil
    8485:      	jmp	0x88ba <generic_usdt_filter_arg+0x25ca>
    848a:      	cmpq	%rdx, %r8
    848d:      	setbe	%r8b
    8491:      	cmpq	%rdi, %rdx
    8494:      	setbe	%dil
    8498:      	andb	%r8b, %dil
    849b:      	orb	%dil, %al
    849e:      	cmpl	$0x29, %esi
    84a1:      	jb	0x9114 <generic_usdt_filter_arg+0x2e24>
    84a7:      	movq	0x30(%r12), %r8
    84ac:      	movq	0x38(%r12), %rdi
    84b1:      	cmpl	$0xc, %ecx
    84b4:      	je	0x84bf <generic_usdt_filter_arg+0x21cf>
    84b6:      	cmpl	$0xa, %ecx
    84b9:      	jne	0x89a0 <generic_usdt_filter_arg+0x26b0>
    84bf:      	cmpq	%rdx, %r8
    84c2:      	setle	%r8b
    84c6:      	cmpq	%rdi, %rdx
    84c9:      	setle	%dil
    84cd:      	jmp	0x89ae <generic_usdt_filter_arg+0x26be>
    84d2:      	cmpq	%rax, %rdi
    84d5:      	movq	0x10(%rsp), %rdi
    84da:      	ja	0x84e5 <generic_usdt_filter_arg+0x21f5>
    84dc:      	cmpq	%rsi, %rax
    84df:      	jbe	0x65b8 <generic_usdt_filter_arg+0x2c8>
    84e5:      	cmpl	$0x29, %edx
    84e8:      	jb	0x63fd <generic_usdt_filter_arg+0x10d>
    84ee:      	movq	0x30(%r12), %rdi
    84f3:      	movq	0x38(%r12), %rsi
    84f8:      	cmpl	$0xc, %ecx
    84fb:      	je	0x8506 <generic_usdt_filter_arg+0x2216>
    84fd:      	cmpl	$0xa, %ecx
    8500:      	jne	0x8ab7 <generic_usdt_filter_arg+0x27c7>
    8506:      	cmpq	%rax, %rdi
    8509:      	movq	0x10(%rsp), %rdi
    850e:      	jg	0x8aca <generic_usdt_filter_arg+0x27da>
    8514:      	cmpq	%rsi, %rax
    8517:      	jle	0x65b8 <generic_usdt_filter_arg+0x2c8>
    851d:      	jmp	0x8aca <generic_usdt_filter_arg+0x27da>
    8522:      	xorl	%ebx, %ebx
    8524:      	cmpl	$0x29, %ecx
    8527:      	jne	0x8532 <generic_usdt_filter_arg+0x2242>
    8529:      	testq	%rdx, %rdx
    852c:      	je	0x8532 <generic_usdt_filter_arg+0x2242>
    852e:      	movzbl	0x3a(%rdx), %ebx
    8532:      	cmpl	$0x29, %ecx
    8535:      	je	0x8540 <generic_usdt_filter_arg+0x2250>
    8537:      	cmpl	$0x7, %ecx
    853a:      	jne	0x89e3 <generic_usdt_filter_arg+0x26f3>
    8540:      	movq	%r11, %r13
    8543:      	movzbl	0x10(%r12), %eax
    8549:      	movl	%eax, 0x34(%rsp)
    854d:      	movl	$0x1, %eax
    8552:      	movq	(%rip), %rdi            # 0x8559 <generic_usdt_filter_arg+0x2269>
    8559:      	leaq	0x34(%rsp), %rsi
    855e:      	callq	*%rax
    8560:      	testq	%rax, %rax
    8563:      	je	0x8581 <generic_usdt_filter_arg+0x2291>
    8565:      	movq	%rax, %rdi
    8568:      	movl	%ebx, %eax
    856a:      	movq	%rax, 0x80(%rsp)
    8572:      	movl	$0x1, %eax
    8577:      	movq	0x38(%rsp), %rsi
    857c:      	jmp	0x7f1f <generic_usdt_filter_arg+0x1c2f>
    8581:      	xorl	%ebx, %ebx
    8583:      	movq	0x10(%rsp), %rdi
    8588:      	movq	0x18(%rsp), %r9
    858d:      	movq	%r13, %r11
    8590:      	jmp	0x65a2 <generic_usdt_filter_arg+0x2b2>
    8595:      	movq	0x8(%rsp), %rsi
    859a:      	cmpl	%edx, (%rsi)
    859c:      	ja	0x65b8 <generic_usdt_filter_arg+0x2c8>
    85a2:      	jmp	0x85b1 <generic_usdt_filter_arg+0x22c1>
    85a4:      	movq	0x8(%rsp), %rsi
    85a9:      	cmpl	%edx, (%rsi)
    85ab:      	jb	0x65b8 <generic_usdt_filter_arg+0x2c8>
    85b1:      	movl	0x8(%r12), %edx
    85b6:      	cmpl	$0xd, %edx
    85b9:      	jb	0x963a <generic_usdt_filter_arg+0x334a>
    85bf:      	movl	0x14(%r12), %esi
    85c4:      	cmpl	$0x2, %eax
    85c7:      	jle	0x85e8 <generic_usdt_filter_arg+0x22f8>
    85c9:      	leal	-0x3(%rax), %edi
    85cc:      	cmpl	$0x2, %edi
    85cf:      	jae	0x8622 <generic_usdt_filter_arg+0x2332>
    85d1:      	movq	0x8(%rsp), %rdi
    85d6:      	cmpl	%esi, (%rdi)
    85d8:      	movq	0x10(%rsp), %rdi
    85dd:      	jne	0x8dfc <generic_usdt_filter_arg+0x2b0c>
    85e3:      	jmp	0x9511 <generic_usdt_filter_arg+0x3221>
    85e8:      	cmpl	$0x1, %eax
    85eb:      	je	0x8643 <generic_usdt_filter_arg+0x2353>
    85ed:      	cmpl	$0x2, %eax
    85f0:      	jne	0x8dfc <generic_usdt_filter_arg+0x2b0c>
    85f6:      	cmpl	$0xc, %ecx
    85f9:      	ja	0x8dee <generic_usdt_filter_arg+0x2afe>
    85ff:      	movl	$0x1402, %r8d           # imm = 0x1402
    8605:      	btl	%ecx, %r8d
    8609:      	jae	0x8dee <generic_usdt_filter_arg+0x2afe>
    860f:      	movq	0x8(%rsp), %r8
    8614:      	cmpl	%esi, (%r8)
    8617:      	jl	0x65b8 <generic_usdt_filter_arg+0x2c8>
    861d:      	jmp	0x8dfc <generic_usdt_filter_arg+0x2b0c>
    8622:      	cmpl	$0xc, %eax
    8625:      	movq	0x10(%rsp), %rdi
    862a:      	jne	0x8dfc <generic_usdt_filter_arg+0x2b0c>
    8630:      	movq	0x8(%rsp), %r8
    8635:      	testl	%esi, (%r8)
    8638:      	jne	0x65b8 <generic_usdt_filter_arg+0x2c8>
    863e:      	jmp	0x8dfc <generic_usdt_filter_arg+0x2b0c>
    8643:      	cmpl	$0xc, %ecx
    8646:      	ja	0x8dde <generic_usdt_filter_arg+0x2aee>
    864c:      	movl	$0x1402, %r8d           # imm = 0x1402
    8652:      	btl	%ecx, %r8d
    8656:      	jae	0x8dde <generic_usdt_filter_arg+0x2aee>
    865c:      	movq	0x8(%rsp), %r8
    8661:      	cmpl	%esi, (%r8)
    8664:      	jg	0x65b8 <generic_usdt_filter_arg+0x2c8>
    866a:      	jmp	0x8dfc <generic_usdt_filter_arg+0x2b0c>
    866f:      	xorl	%ebx, %ebx
    8671:      	movq	0x18(%rsp), %r9
    8676:      	movq	%r15, %r11
    8679:      	movq	0x68(%rsp), %r15
    867e:      	jmp	0x895a <generic_usdt_filter_arg+0x266a>
    8683:      	xorl	%ebx, %ebx
    8685:      	movq	%r15, %r11
    8688:      	movq	0x68(%rsp), %r15
    868d:      	jmp	0x897d <generic_usdt_filter_arg+0x268d>
    8692:      	cmpl	$0x1, %eax
    8695:      	je	0x8ca2 <generic_usdt_filter_arg+0x29b2>
    869b:      	cmpl	$0x2, %eax
    869e:      	jne	0x8cb2 <generic_usdt_filter_arg+0x29c2>
    86a4:      	movq	0x8(%rsp), %rsi
    86a9:      	movzbl	(%rsi), %esi
    86ac:      	cmpl	%esi, %edx
    86ae:      	ja	0x65b8 <generic_usdt_filter_arg+0x2c8>
    86b4:      	jmp	0x8cb2 <generic_usdt_filter_arg+0x29c2>
    86b9:      	cmpl	$0x1, %eax
    86bc:      	je	0x8cea <generic_usdt_filter_arg+0x29fa>
    86c2:      	cmpl	$0x2, %eax
    86c5:      	jne	0x8cfa <generic_usdt_filter_arg+0x2a0a>
    86cb:      	movq	0x8(%rsp), %rsi
    86d0:      	movzwl	(%rsi), %esi
    86d3:      	cmpl	%esi, %edx
    86d5:      	ja	0x65b8 <generic_usdt_filter_arg+0x2c8>
    86db:      	jmp	0x8cfa <generic_usdt_filter_arg+0x2a0a>
    86e0:      	movq	0x28(%rsp), %rax
    86e5:      	movw	%bp, (%rax)
    86e8:      	leaq	0x2(%rax), %rdi
    86ec:      	movl	$0x4, %eax
    86f1:      	movl	%ebp, %esi
    86f3:      	callq	*%rax
    86f5:      	movq	0x98(%rsp), %rsi
    86fd:      	subl	%ebp, %esi
    86ff:      	jbe	0x8723 <generic_usdt_filter_arg+0x2433>
    8701:      	movq	0x28(%rsp), %rax
    8706:      	leaq	(%rax,%rbp), %rdi
    870a:      	addq	$0x2, %rdi
    870e:      	andl	$0xfff, %esi            # imm = 0xFFF
    8714:      	movl	$0x4, %eax
    8719:      	movq	0xa8(%rsp), %rdx
    8721:      	callq	*%rax
    8723:      	movl	0xa0(%rsp), %eax
    872a:      	movl	%eax, 0x40(%rsp)
    872e:      	cmpl	$0x3, %ebx
    8731:      	jg	0x8772 <generic_usdt_filter_arg+0x2482>
    8733:      	cmpl	$0x1, %ebx
    8736:      	movq	0x10(%rsp), %rdi
    873b:      	movq	0x18(%rsp), %r9
    8740:      	movq	0x20(%rsp), %r11
    8745:      	jg	0x8c32 <generic_usdt_filter_arg+0x2942>
    874b:      	testl	%ebx, %ebx
    874d:      	je	0x905f <generic_usdt_filter_arg+0x2d6f>
    8753:      	cmpl	$0x1, %ebx
    8756:      	jne	0x6c33 <generic_usdt_filter_arg+0x943>
    875c:      	movl	$0x1, %eax
    8761:      	leaq	0x40(%rsp), %rsi
    8766:      	movq	(%rip), %rdi            # 0x876d <generic_usdt_filter_arg+0x247d>
    876d:      	jmp	0x90a9 <generic_usdt_filter_arg+0x2db9>
    8772:      	cmpl	$0x5, %ebx
    8775:      	movq	0x10(%rsp), %rdi
    877a:      	movq	0x18(%rsp), %r9
    877f:      	movq	0x20(%rsp), %r11
    8784:      	jg	0x8c5a <generic_usdt_filter_arg+0x296a>
    878a:      	cmpl	$0x4, %ebx
    878d:      	je	0x9072 <generic_usdt_filter_arg+0x2d82>
    8793:      	cmpl	$0x5, %ebx
    8796:      	jne	0x6c33 <generic_usdt_filter_arg+0x943>
    879c:      	movl	$0x1, %eax
    87a1:      	leaq	0x40(%rsp), %rsi
    87a6:      	movq	(%rip), %rdi            # 0x87ad <generic_usdt_filter_arg+0x24bd>
    87ad:      	jmp	0x90a9 <generic_usdt_filter_arg+0x2db9>
    87b2:      	cmpl	$0x101, %eax            # imm = 0x101
    87b7:      	movl	$0x100, %edi            # imm = 0x100
    87bc:      	movl	$0x1fe, %eax            # imm = 0x1FE
    87c1:      	cmovael	%eax, %edi
    87c4:      	movl	%edi, %eax
    87c6:      	movzwl	%ax, %ecx
    87c9:      	xorl	%eax, %eax
    87cb:      	cmpl	$0x100, %ecx            # imm = 0x100
    87d1:      	sete	%al
    87d4:      	xorl	$0x7, %eax
    87d7:      	movl	%eax, %ecx
    87d9:      	andl	$0xf, %ecx
    87dc:      	movl	0x10(%r12,%rcx,4), %ecx
    87e1:      	cmpl	$-0x1, %ecx
    87e4:      	je	0x9574 <generic_usdt_filter_arg+0x3284>
    87ea:      	movl	%ecx, 0x98(%rsp)
    87f1:      	movq	%rdi, 0xa0(%rsp)
    87f9:      	movl	%eax, 0x70(%rsp)
    87fd:      	movq	%rsi, 0x8(%rsp)
    8802:      	movl	$0x1, %eax
    8807:      	movq	(%rip), %rdi            # 0x880e <generic_usdt_filter_arg+0x251e>
    880e:      	movq	0x38(%rsp), %rbx
    8813:      	movq	%rbx, %rsi
    8816:      	callq	*%rax
    8818:      	movq	%rax, 0x28(%rsp)
    881d:      	movl	$0x1, %eax
    8822:      	movq	(%rip), %rdi            # 0x8829 <generic_usdt_filter_arg+0x2539>
    8829:      	movq	%rbx, %rsi
    882c:      	callq	*%rax
    882e:      	cmpq	$0x0, 0x28(%rsp)
    8834:      	je	0x9574 <generic_usdt_filter_arg+0x3284>
    883a:      	movl	$0x0, %ebx
    883f:      	testq	%rax, %rax
    8842:      	movq	0x10(%rsp), %rdi
    8847:      	movq	0x18(%rsp), %r9
    884c:      	movq	0x20(%rsp), %r11
    8851:      	je	0x9585 <generic_usdt_filter_arg+0x3295>
    8857:      	movq	%rax, %r13
    885a:      	movl	0x70(%rsp), %ebx
    885e:      	cmpl	$0x5, %ebx
    8861:      	jg	0x8fab <generic_usdt_filter_arg+0x2cbb>
    8867:      	movq	0x28(%rsp), %rax
    886c:      	movb	%bpl, (%rax)
    886f:      	leaq	0x1(%rax), %rdi
    8873:      	movl	$0x4, %eax
    8878:      	movq	0x8(%rsp), %rdx
    887d:      	movl	%ebp, %esi
    887f:      	callq	*%rax
    8881:      	movq	0xa0(%rsp), %rsi
    8889:      	subl	%ebp, %esi
    888b:      	jbe	0x8fee <generic_usdt_filter_arg+0x2cfe>
    8891:      	movq	0x28(%rsp), %rax
    8896:      	leaq	(%rax,%rbp), %rdi
    889a:      	incq	%rdi
    889d:      	andl	$0xfff, %esi            # imm = 0xFFF
    88a3:      	movl	$0x4, %eax
    88a8:      	jmp	0x8fe9 <generic_usdt_filter_arg+0x2cf9>
    88ad:      	cmpl	%edx, %r8d
    88b0:      	setbe	%r8b
    88b4:      	cmpl	%edi, %edx
    88b6:      	setbe	%dil
    88ba:      	andb	%r8b, %dil
    88bd:      	orb	%dil, %al
    88c0:      	cmpl	$0x19, %esi
    88c3:      	jb	0x9114 <generic_usdt_filter_arg+0x2e24>
    88c9:      	movl	0x20(%r12), %r8d
    88ce:      	movl	0x24(%r12), %edi
    88d3:      	cmpl	$0xc, %ecx
    88d6:      	ja	0x8d3e <generic_usdt_filter_arg+0x2a4e>
    88dc:      	movl	$0x1402, %r10d          # imm = 0x1402
    88e2:      	btl	%ecx, %r10d
    88e6:      	jae	0x8d3e <generic_usdt_filter_arg+0x2a4e>
    88ec:      	cmpl	%edx, %r8d
    88ef:      	setle	%r8b
    88f3:      	cmpl	%edi, %edx
    88f5:      	setle	%dil
    88f9:      	jmp	0x8d4b <generic_usdt_filter_arg+0x2a5b>
    88fe:      	cmpl	%eax, %edi
    8900:      	movq	0x10(%rsp), %rdi
    8905:      	ja	0x890f <generic_usdt_filter_arg+0x261f>
    8907:      	cmpl	%esi, %eax
    8909:      	jbe	0x65b8 <generic_usdt_filter_arg+0x2c8>
    890f:      	cmpl	$0x19, %edx
    8912:      	jb	0x63fd <generic_usdt_filter_arg+0x10d>
    8918:      	movl	0x20(%r12), %edi
    891d:      	movl	0x24(%r12), %esi
    8922:      	cmpl	$0xc, %ecx
    8925:      	ja	0x8d8c <generic_usdt_filter_arg+0x2a9c>
    892b:      	movl	$0x1402, %r8d           # imm = 0x1402
    8931:      	btl	%ecx, %r8d
    8935:      	jae	0x8d8c <generic_usdt_filter_arg+0x2a9c>
    893b:      	cmpl	%eax, %edi
    893d:      	movq	0x10(%rsp), %rdi
    8942:      	jg	0x8d9d <generic_usdt_filter_arg+0x2aad>
    8948:      	cmpl	%esi, %eax
    894a:      	jle	0x65b8 <generic_usdt_filter_arg+0x2c8>
    8950:      	jmp	0x8d9d <generic_usdt_filter_arg+0x2aad>
    8955:      	movl	$0x1, %ebx
    895a:      	movq	0x78(%rsp), %r13
    895f:      	movq	0x10(%rsp), %rdi
    8964:      	movl	0x4(%r12), %eax
    8969:      	cmpq	$0x25, %rax
    896d:      	jbe	0x92c6 <generic_usdt_filter_arg+0x2fd6>
    8973:      	jmp	0x65a7 <generic_usdt_filter_arg+0x2b7>
    8978:      	movl	$0x1, %ebx
    897d:      	movq	0x78(%rsp), %r13
    8982:      	movq	0x10(%rsp), %rdi
    8987:      	movq	0x18(%rsp), %r9
    898c:      	movl	0x4(%r12), %eax
    8991:      	cmpq	$0x25, %rax
    8995:      	jbe	0x92c6 <generic_usdt_filter_arg+0x2fd6>
    899b:      	jmp	0x65a7 <generic_usdt_filter_arg+0x2b7>
    89a0:      	cmpq	%rdx, %r8
    89a3:      	setbe	%r8b
    89a7:      	cmpq	%rdi, %rdx
    89aa:      	setbe	%dil
    89ae:      	andb	%r8b, %dil
    89b1:      	orb	%dil, %al
    89b4:      	cmpl	$0x39, %esi
    89b7:      	jb	0x9114 <generic_usdt_filter_arg+0x2e24>
    89bd:      	movq	0x40(%r12), %rdi
    89c2:      	movq	0x48(%r12), %rsi
    89c7:      	cmpl	$0xc, %ecx
    89ca:      	je	0x89d5 <generic_usdt_filter_arg+0x26e5>
    89cc:      	cmpl	$0xa, %ecx
    89cf:      	jne	0x8eb5 <generic_usdt_filter_arg+0x2bc5>
    89d5:      	cmpq	%rdx, %rdi
    89d8:      	setle	%cl
    89db:      	cmpq	%rsi, %rdx
    89de:      	jmp	0x8d84 <generic_usdt_filter_arg+0x2a94>
    89e3:      	xorl	%ebx, %ebx
    89e5:      	jmp	0x65a2 <generic_usdt_filter_arg+0x2b2>
    89ea:      	movq	0x28(%rsp), %rax
    89ef:      	movw	%bp, (%rax)
    89f2:      	leaq	0x2(%rax), %rdi
    89f6:      	movl	$0x4, %eax
    89fb:      	movq	0x8(%rsp), %rdx
    8a00:      	movl	%ebp, %esi
    8a02:      	callq	*%rax
    8a04:      	movq	0x98(%rsp), %rsi
    8a0c:      	subl	%ebp, %esi
    8a0e:      	jbe	0x8a32 <generic_usdt_filter_arg+0x2742>
    8a10:      	movq	0x28(%rsp), %rax
    8a15:      	leaq	(%rax,%rbp), %rdi
    8a19:      	addq	$0x2, %rdi
    8a1d:      	andl	$0xfff, %esi            # imm = 0xFFF
    8a23:      	movl	$0x4, %eax
    8a28:      	movq	0xa8(%rsp), %rdx
    8a30:      	callq	*%rax
    8a32:      	movl	0xa0(%rsp), %eax
    8a39:      	movl	%eax, 0x40(%rsp)
    8a3d:      	cmpl	$0x3, %ebx
    8a40:      	jg	0x8a7c <generic_usdt_filter_arg+0x278c>
    8a42:      	cmpl	$0x1, %ebx
    8a45:      	movq	0x18(%rsp), %r9
    8a4a:      	movq	0x20(%rsp), %r11
    8a4f:      	jg	0x8ec3 <generic_usdt_filter_arg+0x2bd3>
    8a55:      	testl	%ebx, %ebx
    8a57:      	je	0x923c <generic_usdt_filter_arg+0x2f4c>
    8a5d:      	cmpl	$0x1, %ebx
    8a60:      	jne	0x92df <generic_usdt_filter_arg+0x2fef>
    8a66:      	movl	$0x1, %eax
    8a6b:      	leaq	0x40(%rsp), %rsi
    8a70:      	movq	(%rip), %rdi            # 0x8a77 <generic_usdt_filter_arg+0x2787>
    8a77:      	jmp	0x9286 <generic_usdt_filter_arg+0x2f96>
    8a7c:      	cmpl	$0x5, %ebx
    8a7f:      	movq	0x18(%rsp), %r9
    8a84:      	movq	0x20(%rsp), %r11
    8a89:      	jg	0x8eeb <generic_usdt_filter_arg+0x2bfb>
    8a8f:      	cmpl	$0x4, %ebx
    8a92:      	je	0x924f <generic_usdt_filter_arg+0x2f5f>
    8a98:      	cmpl	$0x5, %ebx
    8a9b:      	jne	0x92df <generic_usdt_filter_arg+0x2fef>
    8aa1:      	movl	$0x1, %eax
    8aa6:      	leaq	0x40(%rsp), %rsi
    8aab:      	movq	(%rip), %rdi            # 0x8ab2 <generic_usdt_filter_arg+0x27c2>
    8ab2:      	jmp	0x9286 <generic_usdt_filter_arg+0x2f96>
    8ab7:      	cmpq	%rax, %rdi
    8aba:      	movq	0x10(%rsp), %rdi
    8abf:      	ja	0x8aca <generic_usdt_filter_arg+0x27da>
    8ac1:      	cmpq	%rsi, %rax
    8ac4:      	jbe	0x65b8 <generic_usdt_filter_arg+0x2c8>
    8aca:      	cmpl	$0x39, %edx
    8acd:      	jb	0x63fd <generic_usdt_filter_arg+0x10d>
    8ad3:      	movq	0x40(%r12), %rsi
    8ad8:      	movq	0x48(%r12), %rdx
    8add:      	cmpl	$0xc, %ecx
    8ae0:      	je	0x8aeb <generic_usdt_filter_arg+0x27fb>
    8ae2:      	cmpl	$0xa, %ecx
    8ae5:      	jne	0x8f13 <generic_usdt_filter_arg+0x2c23>
    8aeb:      	cmpq	%rax, %rsi
    8aee:      	jg	0x63fd <generic_usdt_filter_arg+0x10d>
    8af4:      	cmpq	%rdx, %rax
    8af7:      	jle	0x65b8 <generic_usdt_filter_arg+0x2c8>
    8afd:      	jmp	0x63fd <generic_usdt_filter_arg+0x10d>
    8b02:      	movq	0x8(%rsp), %r8
    8b07:      	cmpq	%rsi, (%r8)
    8b0a:      	ja	0x65b8 <generic_usdt_filter_arg+0x2c8>
    8b10:      	jmp	0x8b20 <generic_usdt_filter_arg+0x2830>
    8b12:      	movq	0x8(%rsp), %r8
    8b17:      	cmpq	%rsi, (%r8)
    8b1a:      	jb	0x65b8 <generic_usdt_filter_arg+0x2c8>
    8b20:      	cmpl	$0x19, %edx
    8b23:      	jb	0x963a <generic_usdt_filter_arg+0x334a>
    8b29:      	movq	0x20(%r12), %rsi
    8b2e:      	cmpl	$0x2, %eax
    8b31:      	jle	0x8b53 <generic_usdt_filter_arg+0x2863>
    8b33:      	leal	-0x3(%rax), %edi
    8b36:      	cmpl	$0x2, %edi
    8b39:      	jae	0x8b86 <generic_usdt_filter_arg+0x2896>
    8b3b:      	movq	0x8(%rsp), %rdi
    8b40:      	cmpq	%rsi, (%rdi)
    8b43:      	movq	0x10(%rsp), %rdi
    8b48:      	jne	0x9144 <generic_usdt_filter_arg+0x2e54>
    8b4e:      	jmp	0x9511 <generic_usdt_filter_arg+0x3221>
    8b53:      	cmpl	$0x1, %eax
    8b56:      	je	0x8bf8 <generic_usdt_filter_arg+0x2908>
    8b5c:      	cmpl	$0x2, %eax
    8b5f:      	jne	0x9144 <generic_usdt_filter_arg+0x2e54>
    8b65:      	cmpl	$0xc, %ecx
    8b68:      	je	0x8b73 <generic_usdt_filter_arg+0x2883>
    8b6a:      	cmpl	$0xa, %ecx
    8b6d:      	jne	0x9136 <generic_usdt_filter_arg+0x2e46>
    8b73:      	movq	0x8(%rsp), %r8
    8b78:      	cmpq	%rsi, (%r8)
    8b7b:      	jl	0x65b8 <generic_usdt_filter_arg+0x2c8>
    8b81:      	jmp	0x9144 <generic_usdt_filter_arg+0x2e54>
    8b86:      	cmpl	$0xc, %eax
    8b89:      	movq	0x10(%rsp), %rdi
    8b8e:      	jne	0x9144 <generic_usdt_filter_arg+0x2e54>
    8b94:      	movq	0x8(%rsp), %r8
    8b99:      	testq	%rsi, (%r8)
    8b9c:      	jne	0x65b8 <generic_usdt_filter_arg+0x2c8>
    8ba2:      	jmp	0x9144 <generic_usdt_filter_arg+0x2e54>
    8ba7:      	cmpl	$0xc, %eax
    8baa:      	jne	0x8cb2 <generic_usdt_filter_arg+0x29c2>
    8bb0:      	movq	0x8(%rsp), %rsi
    8bb5:      	movzbl	(%rsi), %esi
    8bb8:      	testl	%esi, %edx
    8bba:      	jne	0x65b8 <generic_usdt_filter_arg+0x2c8>
    8bc0:      	jmp	0x8cb2 <generic_usdt_filter_arg+0x29c2>
    8bc5:      	cmpl	$0xc, %eax
    8bc8:      	jne	0x8cfa <generic_usdt_filter_arg+0x2a0a>
    8bce:      	movq	0x8(%rsp), %rsi
    8bd3:      	movzwl	(%rsi), %esi
    8bd6:      	testl	%esi, %edx
    8bd8:      	jne	0x65b8 <generic_usdt_filter_arg+0x2c8>
    8bde:      	jmp	0x8cfa <generic_usdt_filter_arg+0x2a0a>
    8be3:      	movq	0x10(%rsp), %rdi
    8be8:      	movq	0x18(%rsp), %r9
    8bed:      	movq	%rbp, %r11
    8bf0:      	movzbl	%cl, %ebx
    8bf3:      	jmp	0x65a7 <generic_usdt_filter_arg+0x2b7>
    8bf8:      	cmpl	$0xc, %ecx
    8bfb:      	je	0x8c06 <generic_usdt_filter_arg+0x2916>
    8bfd:      	cmpl	$0xa, %ecx
    8c00:      	jne	0x9126 <generic_usdt_filter_arg+0x2e36>
    8c06:      	movq	0x8(%rsp), %r8
    8c0b:      	cmpq	%rsi, (%r8)
    8c0e:      	jg	0x65b8 <generic_usdt_filter_arg+0x2c8>
    8c14:      	jmp	0x9144 <generic_usdt_filter_arg+0x2e54>
    8c19:      	xorl	%ebx, %ebx
    8c1b:      	movq	0x18(%rsp), %r9
    8c20:      	movq	%r15, %r11
    8c23:      	movq	0x68(%rsp), %r15
    8c28:      	movq	0x10(%rsp), %rdi
    8c2d:      	jmp	0x9585 <generic_usdt_filter_arg+0x3295>
    8c32:      	cmpl	$0x2, %ebx
    8c35:      	je	0x9085 <generic_usdt_filter_arg+0x2d95>
    8c3b:      	cmpl	$0x3, %ebx
    8c3e:      	jne	0x6c33 <generic_usdt_filter_arg+0x943>
    8c44:      	movl	$0x1, %eax
    8c49:      	leaq	0x40(%rsp), %rsi
    8c4e:      	movq	(%rip), %rdi            # 0x8c55 <generic_usdt_filter_arg+0x2965>
    8c55:      	jmp	0x90a9 <generic_usdt_filter_arg+0x2db9>
    8c5a:      	cmpl	$0x6, %ebx
    8c5d:      	je	0x9098 <generic_usdt_filter_arg+0x2da8>
    8c63:      	cmpl	$0x7, %ebx
    8c66:      	jne	0x6c33 <generic_usdt_filter_arg+0x943>
    8c6c:      	movl	$0x1, %eax
    8c71:      	leaq	0x40(%rsp), %rsi
    8c76:      	movq	(%rip), %rdi            # 0x8c7d <generic_usdt_filter_arg+0x298d>
    8c7d:      	jmp	0x90a9 <generic_usdt_filter_arg+0x2db9>
    8c82:      	xorl	%ebx, %ebx
    8c84:      	jmp	0x8c8b <generic_usdt_filter_arg+0x299b>
    8c86:      	movl	$0x1, %ebx
    8c8b:      	movq	0x10(%rsp), %rdi
    8c90:      	movq	0x18(%rsp), %r9
    8c95:      	movq	%r15, %r11
    8c98:      	movq	0x68(%rsp), %r15
    8c9d:      	jmp	0x9585 <generic_usdt_filter_arg+0x3295>
    8ca2:      	movq	0x8(%rsp), %rsi
    8ca7:      	movzbl	(%rsi), %esi
    8caa:      	cmpl	%esi, %edx
    8cac:      	jb	0x65b8 <generic_usdt_filter_arg+0x2c8>
    8cb2:      	cmpl	$0x11, %ecx
    8cb5:      	jb	0x963a <generic_usdt_filter_arg+0x334a>
    8cbb:      	movl	0x18(%r12), %edx
    8cc0:      	cmpl	$0x2, %eax
    8cc3:      	jle	0x8f3c <generic_usdt_filter_arg+0x2c4c>
    8cc9:      	leal	-0x3(%rax), %esi
    8ccc:      	cmpl	$0x2, %esi
    8ccf:      	jae	0x91ca <generic_usdt_filter_arg+0x2eda>
    8cd5:      	movq	0x8(%rsp), %rsi
    8cda:      	movzbl	(%rsi), %esi
    8cdd:      	cmpl	%esi, %edx
    8cdf:      	jne	0x934c <generic_usdt_filter_arg+0x305c>
    8ce5:      	jmp	0x9511 <generic_usdt_filter_arg+0x3221>
    8cea:      	movq	0x8(%rsp), %rsi
    8cef:      	movzwl	(%rsi), %esi
    8cf2:      	cmpl	%esi, %edx
    8cf4:      	jb	0x65b8 <generic_usdt_filter_arg+0x2c8>
    8cfa:      	cmpl	$0x11, %ecx
    8cfd:      	jb	0x963a <generic_usdt_filter_arg+0x334a>
    8d03:      	movl	0x18(%r12), %edx
    8d08:      	cmpl	$0x2, %eax
    8d0b:      	jle	0x8f63 <generic_usdt_filter_arg+0x2c73>
    8d11:      	leal	-0x3(%rax), %esi
    8d14:      	cmpl	$0x2, %esi
    8d17:      	jae	0x91e8 <generic_usdt_filter_arg+0x2ef8>
    8d1d:      	movq	0x8(%rsp), %rsi
    8d22:      	movzwl	(%rsi), %esi
    8d25:      	cmpl	%esi, %edx
    8d27:      	jne	0x939b <generic_usdt_filter_arg+0x30ab>
    8d2d:      	jmp	0x9511 <generic_usdt_filter_arg+0x3221>
    8d32:      	xorl	%ebx, %ebx
    8d34:      	movq	0x68(%rsp), %r15
    8d39:      	jmp	0x9585 <generic_usdt_filter_arg+0x3295>
    8d3e:      	cmpl	%edx, %r8d
    8d41:      	setbe	%r8b
    8d45:      	cmpl	%edi, %edx
    8d47:      	setbe	%dil
    8d4b:      	andb	%r8b, %dil
    8d4e:      	orb	%dil, %al
    8d51:      	cmpl	$0x21, %esi
    8d54:      	jb	0x9114 <generic_usdt_filter_arg+0x2e24>
    8d5a:      	movl	0x28(%r12), %edi
    8d5f:      	movl	0x2c(%r12), %esi
    8d64:      	cmpl	$0xc, %ecx
    8d67:      	ja	0x9106 <generic_usdt_filter_arg+0x2e16>
    8d6d:      	movl	$0x1402, %r8d           # imm = 0x1402
    8d73:      	btl	%ecx, %r8d
    8d77:      	jae	0x9106 <generic_usdt_filter_arg+0x2e16>
    8d7d:      	cmpl	%edx, %edi
    8d7f:      	setle	%cl
    8d82:      	cmpl	%esi, %edx
    8d84:      	setle	%dl
    8d87:      	jmp	0x9110 <generic_usdt_filter_arg+0x2e20>
    8d8c:      	cmpl	%eax, %edi
    8d8e:      	movq	0x10(%rsp), %rdi
    8d93:      	ja	0x8d9d <generic_usdt_filter_arg+0x2aad>
    8d95:      	cmpl	%esi, %eax
    8d97:      	jbe	0x65b8 <generic_usdt_filter_arg+0x2c8>
    8d9d:      	cmpl	$0x21, %edx
    8da0:      	jb	0x63fd <generic_usdt_filter_arg+0x10d>
    8da6:      	movl	0x28(%r12), %esi
    8dab:      	movl	0x2c(%r12), %edx
    8db0:      	cmpl	$0xc, %ecx
    8db3:      	ja	0x9206 <generic_usdt_filter_arg+0x2f16>
    8db9:      	movl	$0x1402, %r8d           # imm = 0x1402
    8dbf:      	btl	%ecx, %r8d
    8dc3:      	jae	0x9206 <generic_usdt_filter_arg+0x2f16>
    8dc9:      	cmpl	%eax, %esi
    8dcb:      	jg	0x63fd <generic_usdt_filter_arg+0x10d>
    8dd1:      	cmpl	%edx, %eax
    8dd3:      	jle	0x65b8 <generic_usdt_filter_arg+0x2c8>
    8dd9:      	jmp	0x63fd <generic_usdt_filter_arg+0x10d>
    8dde:      	movq	0x8(%rsp), %r8
    8de3:      	cmpl	%esi, (%r8)
    8de6:      	ja	0x65b8 <generic_usdt_filter_arg+0x2c8>
    8dec:      	jmp	0x8dfc <generic_usdt_filter_arg+0x2b0c>
    8dee:      	movq	0x8(%rsp), %r8
    8df3:      	cmpl	%esi, (%r8)
    8df6:      	jb	0x65b8 <generic_usdt_filter_arg+0x2c8>
    8dfc:      	cmpl	$0x11, %edx
    8dff:      	jb	0x963a <generic_usdt_filter_arg+0x334a>
    8e05:      	movl	0x18(%r12), %esi
    8e0a:      	cmpl	$0x2, %eax
    8e0d:      	jle	0x8e2e <generic_usdt_filter_arg+0x2b3e>
    8e0f:      	leal	-0x3(%rax), %edi
    8e12:      	cmpl	$0x2, %edi
    8e15:      	jae	0x8e68 <generic_usdt_filter_arg+0x2b78>
    8e17:      	movq	0x8(%rsp), %rdi
    8e1c:      	cmpl	%esi, (%rdi)
    8e1e:      	movq	0x10(%rsp), %rdi
    8e23:      	jne	0x9403 <generic_usdt_filter_arg+0x3113>
    8e29:      	jmp	0x9511 <generic_usdt_filter_arg+0x3221>
    8e2e:      	cmpl	$0x1, %eax
    8e31:      	je	0x8e89 <generic_usdt_filter_arg+0x2b99>
    8e33:      	cmpl	$0x2, %eax
    8e36:      	jne	0x9403 <generic_usdt_filter_arg+0x3113>
    8e3c:      	cmpl	$0xc, %ecx
    8e3f:      	ja	0x93f5 <generic_usdt_filter_arg+0x3105>
    8e45:      	movl	$0x1402, %r8d           # imm = 0x1402
    8e4b:      	btl	%ecx, %r8d
    8e4f:      	jae	0x93f5 <generic_usdt_filter_arg+0x3105>
    8e55:      	movq	0x8(%rsp), %r8
    8e5a:      	cmpl	%esi, (%r8)
    8e5d:      	jl	0x65b8 <generic_usdt_filter_arg+0x2c8>
    8e63:      	jmp	0x9403 <generic_usdt_filter_arg+0x3113>
    8e68:      	cmpl	$0xc, %eax
    8e6b:      	movq	0x10(%rsp), %rdi
    8e70:      	jne	0x9403 <generic_usdt_filter_arg+0x3113>
    8e76:      	movq	0x8(%rsp), %r8
    8e7b:      	testl	%esi, (%r8)
    8e7e:      	jne	0x65b8 <generic_usdt_filter_arg+0x2c8>
    8e84:      	jmp	0x9403 <generic_usdt_filter_arg+0x3113>
    8e89:      	cmpl	$0xc, %ecx
    8e8c:      	ja	0x93e5 <generic_usdt_filter_arg+0x30f5>
    8e92:      	movl	$0x1402, %r8d           # imm = 0x1402
    8e98:      	btl	%ecx, %r8d
    8e9c:      	jae	0x93e5 <generic_usdt_filter_arg+0x30f5>
    8ea2:      	movq	0x8(%rsp), %r8
    8ea7:      	cmpl	%esi, (%r8)
    8eaa:      	jg	0x65b8 <generic_usdt_filter_arg+0x2c8>
    8eb0:      	jmp	0x9403 <generic_usdt_filter_arg+0x3113>
    8eb5:      	cmpq	%rdx, %rdi
    8eb8:      	setbe	%cl
    8ebb:      	cmpq	%rsi, %rdx
    8ebe:      	jmp	0x910d <generic_usdt_filter_arg+0x2e1d>
    8ec3:      	cmpl	$0x2, %ebx
    8ec6:      	je	0x9262 <generic_usdt_filter_arg+0x2f72>
    8ecc:      	cmpl	$0x3, %ebx
    8ecf:      	jne	0x92df <generic_usdt_filter_arg+0x2fef>
    8ed5:      	movl	$0x1, %eax
    8eda:      	leaq	0x40(%rsp), %rsi
    8edf:      	movq	(%rip), %rdi            # 0x8ee6 <generic_usdt_filter_arg+0x2bf6>
    8ee6:      	jmp	0x9286 <generic_usdt_filter_arg+0x2f96>
    8eeb:      	cmpl	$0x6, %ebx
    8eee:      	je	0x9275 <generic_usdt_filter_arg+0x2f85>
    8ef4:      	cmpl	$0x7, %ebx
    8ef7:      	jne	0x92df <generic_usdt_filter_arg+0x2fef>
    8efd:      	movl	$0x1, %eax
    8f02:      	leaq	0x40(%rsp), %rsi
    8f07:      	movq	(%rip), %rdi            # 0x8f0e <generic_usdt_filter_arg+0x2c1e>
    8f0e:      	jmp	0x9286 <generic_usdt_filter_arg+0x2f96>
    8f13:      	cmpq	%rax, %rsi
    8f16:      	ja	0x63fd <generic_usdt_filter_arg+0x10d>
    8f1c:      	cmpq	%rdx, %rax
    8f1f:      	jbe	0x65b8 <generic_usdt_filter_arg+0x2c8>
    8f25:      	jmp	0x63fd <generic_usdt_filter_arg+0x10d>
    8f2a:      	movq	0x10(%rsp), %rdi
    8f2f:      	movq	0x18(%rsp), %r9
    8f34:      	movq	%r13, %r11
    8f37:      	jmp	0x659f <generic_usdt_filter_arg+0x2af>
    8f3c:      	cmpl	$0x1, %eax
    8f3f:      	je	0x933c <generic_usdt_filter_arg+0x304c>
    8f45:      	cmpl	$0x2, %eax
    8f48:      	jne	0x934c <generic_usdt_filter_arg+0x305c>
    8f4e:      	movq	0x8(%rsp), %rsi
    8f53:      	movzbl	(%rsi), %esi
    8f56:      	cmpl	%esi, %edx
    8f58:      	ja	0x65b8 <generic_usdt_filter_arg+0x2c8>
    8f5e:      	jmp	0x934c <generic_usdt_filter_arg+0x305c>
    8f63:      	cmpl	$0x1, %eax
    8f66:      	je	0x938b <generic_usdt_filter_arg+0x309b>
    8f6c:      	cmpl	$0x2, %eax
    8f6f:      	jne	0x939b <generic_usdt_filter_arg+0x30ab>
    8f75:      	movq	0x8(%rsp), %rsi
    8f7a:      	movzwl	(%rsi), %esi
    8f7d:      	cmpl	%esi, %edx
    8f7f:      	ja	0x65b8 <generic_usdt_filter_arg+0x2c8>
    8f85:      	jmp	0x939b <generic_usdt_filter_arg+0x30ab>
    8f8a:      	movl	$0x1, %ebx
    8f8f:      	movq	0x10(%rsp), %rdi
    8f94:      	jmp	0x9585 <generic_usdt_filter_arg+0x3295>
    8f99:      	movq	0x10(%rsp), %rdi
    8f9e:      	movq	0x18(%rsp), %r9
    8fa3:      	movq	%rbp, %r11
    8fa6:      	jmp	0x659f <generic_usdt_filter_arg+0x2af>
    8fab:      	movq	0x28(%rsp), %rax
    8fb0:      	movw	%bp, (%rax)
    8fb3:      	leaq	0x2(%rax), %rdi
    8fb7:      	movl	$0x4, %eax
    8fbc:      	movq	0x8(%rsp), %rdx
    8fc1:      	movl	%ebp, %esi
    8fc3:      	callq	*%rax
    8fc5:      	movq	0xa0(%rsp), %rsi
    8fcd:      	subl	%ebp, %esi
    8fcf:      	jbe	0x8fee <generic_usdt_filter_arg+0x2cfe>
    8fd1:      	movq	0x28(%rsp), %rax
    8fd6:      	leaq	(%rax,%rbp), %rdi
    8fda:      	addq	$0x2, %rdi
    8fde:      	andl	$0xfff, %esi            # imm = 0xFFF
    8fe4:      	movl	$0x4, %eax
    8fe9:      	movq	%r13, %rdx
    8fec:      	callq	*%rax
    8fee:      	movl	0x98(%rsp), %eax
    8ff5:      	movl	%eax, 0x40(%rsp)
    8ff9:      	cmpl	$0x3, %ebx
    8ffc:      	jg	0x902e <generic_usdt_filter_arg+0x2d3e>
    8ffe:      	cmpl	$0x1, %ebx
    9001:      	leaq	0x40(%rsp), %rsi
    9006:      	jg	0x92f6 <generic_usdt_filter_arg+0x3006>
    900c:      	testl	%ebx, %ebx
    900e:      	je	0x951e <generic_usdt_filter_arg+0x322e>
    9014:      	cmpl	$0x1, %ebx
    9017:      	jne	0x9574 <generic_usdt_filter_arg+0x3284>
    901d:      	movl	$0x1, %eax
    9022:      	movq	(%rip), %rdi            # 0x9029 <generic_usdt_filter_arg+0x2d39>
    9029:      	jmp	0x9554 <generic_usdt_filter_arg+0x3264>
    902e:      	cmpl	$0x5, %ebx
    9031:      	leaq	0x40(%rsp), %rsi
    9036:      	jg	0x9319 <generic_usdt_filter_arg+0x3029>
    903c:      	cmpl	$0x4, %ebx
    903f:      	je	0x952c <generic_usdt_filter_arg+0x323c>
    9045:      	cmpl	$0x5, %ebx
    9048:      	jne	0x9574 <generic_usdt_filter_arg+0x3284>
    904e:      	movl	$0x1, %eax
    9053:      	movq	(%rip), %rdi            # 0x905a <generic_usdt_filter_arg+0x2d6a>
    905a:      	jmp	0x9554 <generic_usdt_filter_arg+0x3264>
    905f:      	movl	$0x1, %eax
    9064:      	movq	(%rip), %rdi            # 0x906b <generic_usdt_filter_arg+0x2d7b>
    906b:      	leaq	0x40(%rsp), %rsi
    9070:      	jmp	0x90a9 <generic_usdt_filter_arg+0x2db9>
    9072:      	movl	$0x1, %eax
    9077:      	leaq	0x40(%rsp), %rsi
    907c:      	movq	(%rip), %rdi            # 0x9083 <generic_usdt_filter_arg+0x2d93>
    9083:      	jmp	0x90a9 <generic_usdt_filter_arg+0x2db9>
    9085:      	movl	$0x1, %eax
    908a:      	leaq	0x40(%rsp), %rsi
    908f:      	movq	(%rip), %rdi            # 0x9096 <generic_usdt_filter_arg+0x2da6>
    9096:      	jmp	0x90a9 <generic_usdt_filter_arg+0x2db9>
    9098:      	movl	$0x1, %eax
    909d:      	leaq	0x40(%rsp), %rsi
    90a2:      	movq	(%rip), %rdi            # 0x90a9 <generic_usdt_filter_arg+0x2db9>
    90a9:      	callq	*%rax
    90ab:      	testq	%rax, %rax
    90ae:      	je	0x90c9 <generic_usdt_filter_arg+0x2dd9>
    90b0:      	movq	%rax, %rdi
    90b3:      	movl	$0x1, %eax
    90b8:      	movq	0x28(%rsp), %rsi
    90bd:      	callq	*%rax
    90bf:      	xorl	%ebx, %ebx
    90c1:      	testq	%rax, %rax
    90c4:      	setne	%bl
    90c7:      	jmp	0x90cb <generic_usdt_filter_arg+0x2ddb>
    90c9:      	xorl	%ebx, %ebx
    90cb:      	movq	0x10(%rsp), %rdi
    90d0:      	movq	0x18(%rsp), %r9
    90d5:      	movq	0x20(%rsp), %r11
    90da:      	movl	0x4(%r12), %eax
    90df:      	cmpq	$0x25, %rax
    90e3:      	ja	0x65a7 <generic_usdt_filter_arg+0x2b7>
    90e9:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    90f3:      	btq	%rax, %rcx
    90f7:      	jae	0x65a7 <generic_usdt_filter_arg+0x2b7>
    90fd:      	xorq	$0x1, %rbx
    9101:      	jmp	0x65a7 <generic_usdt_filter_arg+0x2b7>
    9106:      	cmpl	%edx, %edi
    9108:      	setbe	%cl
    910b:      	cmpl	%esi, %edx
    910d:      	setbe	%dl
    9110:      	andb	%cl, %dl
    9112:      	orb	%dl, %al
    9114:      	movq	0x10(%rsp), %rdi
    9119:      	testb	%al, %al
    911b:      	je	0x65b8 <generic_usdt_filter_arg+0x2c8>
    9121:      	jmp	0x63fd <generic_usdt_filter_arg+0x10d>
    9126:      	movq	0x8(%rsp), %r8
    912b:      	cmpq	%rsi, (%r8)
    912e:      	ja	0x65b8 <generic_usdt_filter_arg+0x2c8>
    9134:      	jmp	0x9144 <generic_usdt_filter_arg+0x2e54>
    9136:      	movq	0x8(%rsp), %r8
    913b:      	cmpq	%rsi, (%r8)
    913e:      	jb	0x65b8 <generic_usdt_filter_arg+0x2c8>
    9144:      	cmpl	$0x21, %edx
    9147:      	jb	0x963a <generic_usdt_filter_arg+0x334a>
    914d:      	movq	0x28(%r12), %rdx
    9152:      	cmpl	$0x2, %eax
    9155:      	jle	0x9184 <generic_usdt_filter_arg+0x2e94>
    9157:      	leal	-0x3(%rax), %ecx
    915a:      	cmpl	$0x2, %ecx
    915d:      	jb	0x91b7 <generic_usdt_filter_arg+0x2ec7>
    915f:      	cmpl	$0x6, %eax
    9162:      	je	0x65b8 <generic_usdt_filter_arg+0x2c8>
    9168:      	cmpl	$0xc, %eax
    916b:      	jne	0x63fd <generic_usdt_filter_arg+0x10d>
    9171:      	movq	0x8(%rsp), %rcx
    9176:      	testq	%rdx, (%rcx)
    9179:      	jne	0x65b8 <generic_usdt_filter_arg+0x2c8>
    917f:      	jmp	0x963a <generic_usdt_filter_arg+0x334a>
    9184:      	cmpl	$0x1, %eax
    9187:      	je	0x921b <generic_usdt_filter_arg+0x2f2b>
    918d:      	cmpl	$0x2, %eax
    9190:      	jne	0x63fd <generic_usdt_filter_arg+0x10d>
    9196:      	cmpl	$0xc, %ecx
    9199:      	je	0x91a4 <generic_usdt_filter_arg+0x2eb4>
    919b:      	cmpl	$0xa, %ecx
    919e:      	jne	0x95bd <generic_usdt_filter_arg+0x32cd>
    91a4:      	movq	0x8(%rsp), %rcx
    91a9:      	cmpq	%rdx, (%rcx)
    91ac:      	jl	0x65b8 <generic_usdt_filter_arg+0x2c8>
    91b2:      	jmp	0x963a <generic_usdt_filter_arg+0x334a>
    91b7:      	movq	0x8(%rsp), %rcx
    91bc:      	cmpq	%rdx, (%rcx)
    91bf:      	je	0x9511 <generic_usdt_filter_arg+0x3221>
    91c5:      	jmp	0x963a <generic_usdt_filter_arg+0x334a>
    91ca:      	cmpl	$0xc, %eax
    91cd:      	jne	0x934c <generic_usdt_filter_arg+0x305c>
    91d3:      	movq	0x8(%rsp), %rsi
    91d8:      	movzbl	(%rsi), %esi
    91db:      	testl	%esi, %edx
    91dd:      	jne	0x65b8 <generic_usdt_filter_arg+0x2c8>
    91e3:      	jmp	0x934c <generic_usdt_filter_arg+0x305c>
    91e8:      	cmpl	$0xc, %eax
    91eb:      	jne	0x939b <generic_usdt_filter_arg+0x30ab>
    91f1:      	movq	0x8(%rsp), %rsi
    91f6:      	movzwl	(%rsi), %esi
    91f9:      	testl	%esi, %edx
    91fb:      	jne	0x65b8 <generic_usdt_filter_arg+0x2c8>
    9201:      	jmp	0x939b <generic_usdt_filter_arg+0x30ab>
    9206:      	cmpl	%eax, %esi
    9208:      	ja	0x63fd <generic_usdt_filter_arg+0x10d>
    920e:      	cmpl	%edx, %eax
    9210:      	jbe	0x65b8 <generic_usdt_filter_arg+0x2c8>
    9216:      	jmp	0x63fd <generic_usdt_filter_arg+0x10d>
    921b:      	cmpl	$0xc, %ecx
    921e:      	movq	0x8(%rsp), %rsi
    9223:      	je	0x922e <generic_usdt_filter_arg+0x2f3e>
    9225:      	cmpl	$0xa, %ecx
    9228:      	jne	0x95cd <generic_usdt_filter_arg+0x32dd>
    922e:      	cmpq	%rdx, (%rsi)
    9231:      	jg	0x65b8 <generic_usdt_filter_arg+0x2c8>
    9237:      	jmp	0x963a <generic_usdt_filter_arg+0x334a>
    923c:      	movl	$0x1, %eax
    9241:      	movq	(%rip), %rdi            # 0x9248 <generic_usdt_filter_arg+0x2f58>
    9248:      	leaq	0x40(%rsp), %rsi
    924d:      	jmp	0x9286 <generic_usdt_filter_arg+0x2f96>
    924f:      	movl	$0x1, %eax
    9254:      	leaq	0x40(%rsp), %rsi
    9259:      	movq	(%rip), %rdi            # 0x9260 <generic_usdt_filter_arg+0x2f70>
    9260:      	jmp	0x9286 <generic_usdt_filter_arg+0x2f96>
    9262:      	movl	$0x1, %eax
    9267:      	leaq	0x40(%rsp), %rsi
    926c:      	movq	(%rip), %rdi            # 0x9273 <generic_usdt_filter_arg+0x2f83>
    9273:      	jmp	0x9286 <generic_usdt_filter_arg+0x2f96>
    9275:      	movl	$0x1, %eax
    927a:      	leaq	0x40(%rsp), %rsi
    927f:      	movq	(%rip), %rdi            # 0x9286 <generic_usdt_filter_arg+0x2f96>
    9286:      	callq	*%rax
    9288:      	testq	%rax, %rax
    928b:      	je	0x92a6 <generic_usdt_filter_arg+0x2fb6>
    928d:      	movq	%rax, %rdi
    9290:      	movl	$0x1, %eax
    9295:      	movq	0x28(%rsp), %rsi
    929a:      	callq	*%rax
    929c:      	xorl	%ebx, %ebx
    929e:      	testq	%rax, %rax
    92a1:      	setne	%bl
    92a4:      	jmp	0x92a8 <generic_usdt_filter_arg+0x2fb8>
    92a6:      	xorl	%ebx, %ebx
    92a8:      	movq	0x10(%rsp), %rdi
    92ad:      	movq	0x18(%rsp), %r9
    92b2:      	movq	0x20(%rsp), %r11
    92b7:      	movl	0x4(%r12), %eax
    92bc:      	cmpq	$0x25, %rax
    92c0:      	ja	0x65a7 <generic_usdt_filter_arg+0x2b7>
    92c6:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    92d0:      	btq	%rax, %rcx
    92d4:      	jb	0x95ad <generic_usdt_filter_arg+0x32bd>
    92da:      	jmp	0x65a7 <generic_usdt_filter_arg+0x2b7>
    92df:      	xorl	%ebx, %ebx
    92e1:      	movq	0x10(%rsp), %rdi
    92e6:      	movl	0x4(%r12), %eax
    92eb:      	cmpq	$0x25, %rax
    92ef:      	jbe	0x92c6 <generic_usdt_filter_arg+0x2fd6>
    92f1:      	jmp	0x65a7 <generic_usdt_filter_arg+0x2b7>
    92f6:      	cmpl	$0x2, %ebx
    92f9:      	je	0x953a <generic_usdt_filter_arg+0x324a>
    92ff:      	cmpl	$0x3, %ebx
    9302:      	jne	0x9574 <generic_usdt_filter_arg+0x3284>
    9308:      	movl	$0x1, %eax
    930d:      	movq	(%rip), %rdi            # 0x9314 <generic_usdt_filter_arg+0x3024>
    9314:      	jmp	0x9554 <generic_usdt_filter_arg+0x3264>
    9319:      	cmpl	$0x6, %ebx
    931c:      	je	0x9548 <generic_usdt_filter_arg+0x3258>
    9322:      	cmpl	$0x7, %ebx
    9325:      	jne	0x9574 <generic_usdt_filter_arg+0x3284>
    932b:      	movl	$0x1, %eax
    9330:      	movq	(%rip), %rdi            # 0x9337 <generic_usdt_filter_arg+0x3047>
    9337:      	jmp	0x9554 <generic_usdt_filter_arg+0x3264>
    933c:      	movq	0x8(%rsp), %rsi
    9341:      	movzbl	(%rsi), %esi
    9344:      	cmpl	%esi, %edx
    9346:      	jb	0x65b8 <generic_usdt_filter_arg+0x2c8>
    934c:      	cmpl	$0x15, %ecx
    934f:      	jb	0x963a <generic_usdt_filter_arg+0x334a>
    9355:      	movl	0x1c(%r12), %ecx
    935a:      	cmpl	$0x2, %eax
    935d:      	jle	0x94b4 <generic_usdt_filter_arg+0x31c4>
    9363:      	leal	-0x3(%rax), %edx
    9366:      	cmpl	$0x2, %edx
    9369:      	jb	0x94f7 <generic_usdt_filter_arg+0x3207>
    936f:      	cmpl	$0x6, %eax
    9372:      	je	0x65b8 <generic_usdt_filter_arg+0x2c8>
    9378:      	cmpl	$0xc, %eax
    937b:      	jne	0x63fd <generic_usdt_filter_arg+0x10d>
    9381:      	movq	0x8(%rsp), %rdx
    9386:      	movzbl	(%rdx), %edx
    9389:      	jmp	0x93d8 <generic_usdt_filter_arg+0x30e8>
    938b:      	movq	0x8(%rsp), %rsi
    9390:      	movzwl	(%rsi), %esi
    9393:      	cmpl	%esi, %edx
    9395:      	jb	0x65b8 <generic_usdt_filter_arg+0x2c8>
    939b:      	cmpl	$0x15, %ecx
    939e:      	jb	0x963a <generic_usdt_filter_arg+0x334a>
    93a4:      	movl	0x1c(%r12), %ecx
    93a9:      	cmpl	$0x2, %eax
    93ac:      	jle	0x94d0 <generic_usdt_filter_arg+0x31e0>
    93b2:      	leal	-0x3(%rax), %edx
    93b5:      	cmpl	$0x2, %edx
    93b8:      	jb	0x9501 <generic_usdt_filter_arg+0x3211>
    93be:      	cmpl	$0x6, %eax
    93c1:      	je	0x65b8 <generic_usdt_filter_arg+0x2c8>
    93c7:      	cmpl	$0xc, %eax
    93ca:      	jne	0x63fd <generic_usdt_filter_arg+0x10d>
    93d0:      	movq	0x8(%rsp), %rdx
    93d5:      	movzwl	(%rdx), %edx
    93d8:      	testl	%edx, %ecx
    93da:      	jne	0x65b8 <generic_usdt_filter_arg+0x2c8>
    93e0:      	jmp	0x963a <generic_usdt_filter_arg+0x334a>
    93e5:      	movq	0x8(%rsp), %r8
    93ea:      	cmpl	%esi, (%r8)
    93ed:      	ja	0x65b8 <generic_usdt_filter_arg+0x2c8>
    93f3:      	jmp	0x9403 <generic_usdt_filter_arg+0x3113>
    93f5:      	movq	0x8(%rsp), %r8
    93fa:      	cmpl	%esi, (%r8)
    93fd:      	jb	0x65b8 <generic_usdt_filter_arg+0x2c8>
    9403:      	cmpl	$0x15, %edx
    9406:      	jb	0x963a <generic_usdt_filter_arg+0x334a>
    940c:      	movl	0x1c(%r12), %edx
    9411:      	cmpl	$0x2, %eax
    9414:      	jle	0x9442 <generic_usdt_filter_arg+0x3152>
    9416:      	leal	-0x3(%rax), %ecx
    9419:      	cmpl	$0x2, %ecx
    941c:      	jb	0x9479 <generic_usdt_filter_arg+0x3189>
    941e:      	cmpl	$0x6, %eax
    9421:      	je	0x65b8 <generic_usdt_filter_arg+0x2c8>
    9427:      	cmpl	$0xc, %eax
    942a:      	jne	0x63fd <generic_usdt_filter_arg+0x10d>
    9430:      	movq	0x8(%rsp), %rcx
    9435:      	testl	%edx, (%rcx)
    9437:      	jne	0x65b8 <generic_usdt_filter_arg+0x2c8>
    943d:      	jmp	0x963a <generic_usdt_filter_arg+0x334a>
    9442:      	cmpl	$0x1, %eax
    9445:      	je	0x948b <generic_usdt_filter_arg+0x319b>
    9447:      	cmpl	$0x2, %eax
    944a:      	jne	0x63fd <generic_usdt_filter_arg+0x10d>
    9450:      	cmpl	$0xc, %ecx
    9453:      	ja	0x961e <generic_usdt_filter_arg+0x332e>
    9459:      	movl	$0x1402, %esi           # imm = 0x1402
    945e:      	btl	%ecx, %esi
    9461:      	jae	0x961e <generic_usdt_filter_arg+0x332e>
    9467:      	movq	0x8(%rsp), %rcx
    946c:      	cmpl	%edx, (%rcx)
    946e:      	jl	0x65b8 <generic_usdt_filter_arg+0x2c8>
    9474:      	jmp	0x963a <generic_usdt_filter_arg+0x334a>
    9479:      	movq	0x8(%rsp), %rcx
    947e:      	cmpl	%edx, (%rcx)
    9480:      	je	0x9511 <generic_usdt_filter_arg+0x3221>
    9486:      	jmp	0x963a <generic_usdt_filter_arg+0x334a>
    948b:      	cmpl	$0xc, %ecx
    948e:      	ja	0x962d <generic_usdt_filter_arg+0x333d>
    9494:      	movl	$0x1402, %esi           # imm = 0x1402
    9499:      	btl	%ecx, %esi
    949c:      	jae	0x962d <generic_usdt_filter_arg+0x333d>
    94a2:      	movq	0x8(%rsp), %rcx
    94a7:      	cmpl	%edx, (%rcx)
    94a9:      	jg	0x65b8 <generic_usdt_filter_arg+0x2c8>
    94af:      	jmp	0x963a <generic_usdt_filter_arg+0x334a>
    94b4:      	cmpl	$0x1, %eax
    94b7:      	je	0x95d8 <generic_usdt_filter_arg+0x32e8>
    94bd:      	cmpl	$0x2, %eax
    94c0:      	jne	0x63fd <generic_usdt_filter_arg+0x10d>
    94c6:      	movq	0x8(%rsp), %rdx
    94cb:      	movzbl	(%rdx), %edx
    94ce:      	jmp	0x94ea <generic_usdt_filter_arg+0x31fa>
    94d0:      	cmpl	$0x1, %eax
    94d3:      	je	0x95e2 <generic_usdt_filter_arg+0x32f2>
    94d9:      	cmpl	$0x2, %eax
    94dc:      	jne	0x63fd <generic_usdt_filter_arg+0x10d>
    94e2:      	movq	0x8(%rsp), %rdx
    94e7:      	movzwl	(%rdx), %edx
    94ea:      	cmpl	%edx, %ecx
    94ec:      	ja	0x65b8 <generic_usdt_filter_arg+0x2c8>
    94f2:      	jmp	0x963a <generic_usdt_filter_arg+0x334a>
    94f7:      	movq	0x8(%rsp), %rdx
    94fc:      	movzbl	(%rdx), %edx
    94ff:      	jmp	0x9509 <generic_usdt_filter_arg+0x3219>
    9501:      	movq	0x8(%rsp), %rdx
    9506:      	movzwl	(%rdx), %edx
    9509:      	cmpl	%edx, %ecx
    950b:      	jne	0x963a <generic_usdt_filter_arg+0x334a>
    9511:      	xorl	%ebx, %ebx
    9513:      	cmpl	$0x3, %eax
    9516:      	sete	%bl
    9519:      	jmp	0x65a7 <generic_usdt_filter_arg+0x2b7>
    951e:      	movl	$0x1, %eax
    9523:      	movq	(%rip), %rdi            # 0x952a <generic_usdt_filter_arg+0x323a>
    952a:      	jmp	0x9554 <generic_usdt_filter_arg+0x3264>
    952c:      	movl	$0x1, %eax
    9531:      	movq	(%rip), %rdi            # 0x9538 <generic_usdt_filter_arg+0x3248>
    9538:      	jmp	0x9554 <generic_usdt_filter_arg+0x3264>
    953a:      	movl	$0x1, %eax
    953f:      	movq	(%rip), %rdi            # 0x9546 <generic_usdt_filter_arg+0x3256>
    9546:      	jmp	0x9554 <generic_usdt_filter_arg+0x3264>
    9548:      	movl	$0x1, %eax
    954d:      	movq	(%rip), %rdi            # 0x9554 <generic_usdt_filter_arg+0x3264>
    9554:      	callq	*%rax
    9556:      	testq	%rax, %rax
    9559:      	je	0x9574 <generic_usdt_filter_arg+0x3284>
    955b:      	movq	%rax, %rdi
    955e:      	movl	$0x1, %eax
    9563:      	movq	0x28(%rsp), %rsi
    9568:      	callq	*%rax
    956a:      	xorl	%ebx, %ebx
    956c:      	testq	%rax, %rax
    956f:      	setne	%bl
    9572:      	jmp	0x9576 <generic_usdt_filter_arg+0x3286>
    9574:      	xorl	%ebx, %ebx
    9576:      	movq	0x10(%rsp), %rdi
    957b:      	movq	0x18(%rsp), %r9
    9580:      	movq	0x20(%rsp), %r11
    9585:      	movl	0x4(%r12), %eax
    958a:      	cmpq	$0x25, %rax
    958e:      	ja	0x65a2 <generic_usdt_filter_arg+0x2b2>
    9594:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    959e:      	btq	%rax, %rcx
    95a2:      	movq	0x78(%rsp), %r13
    95a7:      	jae	0x65a7 <generic_usdt_filter_arg+0x2b7>
    95ad:      	xorl	%eax, %eax
    95af:      	testq	%rbx, %rbx
    95b2:      	sete	%al
    95b5:      	movq	%rax, %rbx
    95b8:      	jmp	0x65a7 <generic_usdt_filter_arg+0x2b7>
    95bd:      	movq	0x8(%rsp), %rcx
    95c2:      	cmpq	%rdx, (%rcx)
    95c5:      	jb	0x65b8 <generic_usdt_filter_arg+0x2c8>
    95cb:      	jmp	0x963a <generic_usdt_filter_arg+0x334a>
    95cd:      	cmpq	%rdx, (%rsi)
    95d0:      	ja	0x65b8 <generic_usdt_filter_arg+0x2c8>
    95d6:      	jmp	0x963a <generic_usdt_filter_arg+0x334a>
    95d8:      	movq	0x8(%rsp), %rdx
    95dd:      	movzbl	(%rdx), %edx
    95e0:      	jmp	0x95ea <generic_usdt_filter_arg+0x32fa>
    95e2:      	movq	0x8(%rsp), %rdx
    95e7:      	movzwl	(%rdx), %edx
    95ea:      	cmpl	%edx, %ecx
    95ec:      	jb	0x65b8 <generic_usdt_filter_arg+0x2c8>
    95f2:      	jmp	0x963a <generic_usdt_filter_arg+0x334a>
    95f4:      	xorl	%ebx, %ebx
    95f6:      	movq	0x10(%rsp), %rdi
    95fb:      	movq	0x18(%rsp), %r9
    9600:      	movq	0x20(%rsp), %r11
    9605:      	movq	0x68(%rsp), %r15
    960a:      	movl	0x4(%r12), %eax
    960f:      	cmpq	$0x25, %rax
    9613:      	jbe	0x90e9 <generic_usdt_filter_arg+0x2df9>
    9619:      	jmp	0x65a7 <generic_usdt_filter_arg+0x2b7>
    961e:      	movq	0x8(%rsp), %rcx
    9623:      	cmpl	%edx, (%rcx)
    9625:      	jb	0x65b8 <generic_usdt_filter_arg+0x2c8>
    962b:      	jmp	0x963a <generic_usdt_filter_arg+0x334a>
    962d:      	movq	0x8(%rsp), %rcx
    9632:      	cmpl	%edx, (%rcx)
    9634:      	ja	0x65b8 <generic_usdt_filter_arg+0x2c8>
    963a:      	orl	$0x2, %eax
    963d:      	cmpl	$0x6, %eax
    9640:      	je	0x65b8 <generic_usdt_filter_arg+0x2c8>
    9646:      	jmp	0x63fd <generic_usdt_filter_arg+0x10d>
    964b:      	nopl	(%rax,%rax)

0000000000009650 <generic_usdt_actions>:
    9650:      	pushq	%rbp
    9651:      	pushq	%r15
    9653:      	pushq	%r14
    9655:      	pushq	%r13
    9657:      	pushq	%r12
    9659:      	pushq	%rbx
    965a:      	subq	$0x118, %rsp            # imm = 0x118
    9661:      	movq	%rdi, 0x40(%rsp)
    9666:      	movl	$0x0, 0x70(%rsp)
    966e:      	movq	(%rip), %rdi            # 0x9675 <generic_usdt_actions+0x25>
    9675:      	leaq	0x70(%rsp), %rsi
    967a:      	movl	$0x1, %eax
    967f:      	callq	*%rax
    9681:      	testq	%rax, %rax
    9684:      	je	0xa3c0 <generic_usdt_actions+0xd70>
    968a:      	movq	%rax, %rsi
    968d:      	movl	0x5f04(%rax), %ebx
    9693:      	cmpl	$0x2, %ebx
    9696:      	jl	0xa3c0 <generic_usdt_actions+0xd70>
    969c:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    96a3:      	movq	(%rip), %rdi            # 0x96aa <generic_usdt_actions+0x5a>
    96aa:      	movl	$0x1, %eax
    96af:      	callq	*%rax
    96b1:      	testq	%rax, %rax
    96b4:      	je	0xa3c0 <generic_usdt_actions+0xd70>
    96ba:      	movq	%rax, %r14
    96bd:      	movl	%ebx, %eax
    96bf:      	andl	$0x7ff, %eax            # imm = 0x7FF
    96c4:      	addl	(%r14,%rax), %ebx
    96c8:      	movl	$0x0, 0x74(%rsp)
    96d0:      	movq	(%rip), %rdi            # 0x96d7 <generic_usdt_actions+0x87>
    96d7:      	leaq	0x74(%rsp), %rsi
    96dc:      	movl	$0x1, %eax
    96e1:      	andl	$0x7ff, %ebx            # imm = 0x7FF
    96e7:      	callq	*%rax
    96e9:      	testq	%rax, %rax
    96ec:      	je	0x9718 <generic_usdt_actions+0xc8>
    96ee:      	xorl	%ecx, %ecx
    96f0:      	cmpb	$0x0, (%rax)
    96f3:      	sete	%cl
    96f6:      	movq	%rcx, %rax
    96f9:      	xorq	$0x7, %rax
    96fd:      	movq	%rax, 0x88(%rsp)
    9705:      	movq	%rcx, 0x68(%rsp)
    970a:      	xorq	$0x5, %rcx
    970e:      	movq	%rcx, 0x80(%rsp)
    9716:      	jmp	0x9739 <generic_usdt_actions+0xe9>
    9718:      	movl	$0x4, %eax
    971d:      	movq	%rax, 0x80(%rsp)
    9725:      	movb	$0x1, %al
    9727:      	movq	%rax, 0x68(%rsp)
    972c:      	movl	$0x6, %eax
    9731:      	movq	%rax, 0x88(%rsp)
    9739:      	addq	%rbx, %r14
    973c:      	movq	0x40(%rsp), %rcx
    9741:      	leaq	0x8(%rcx), %rax
    9745:      	movq	%rax, 0xd0(%rsp)
    974d:      	leaq	0x10(%rcx), %rax
    9751:      	movq	%rax, 0x108(%rsp)
    9759:      	leaq	0x18(%rcx), %rax
    975d:      	movq	%rax, 0xc8(%rsp)
    9765:      	leaq	0x20(%rcx), %rax
    9769:      	movq	%rax, 0x100(%rsp)
    9771:      	leaq	0x28(%rcx), %rax
    9775:      	movq	%rax, 0xc0(%rsp)
    977d:      	leaq	0x30(%rcx), %rax
    9781:      	movq	%rax, 0xf8(%rsp)
    9789:      	leaq	0x38(%rcx), %rax
    978d:      	movq	%rax, 0xb8(%rsp)
    9795:      	leaq	0x40(%rcx), %rax
    9799:      	movq	%rax, 0xf0(%rsp)
    97a1:      	leaq	0x48(%rcx), %rax
    97a5:      	movq	%rax, 0xb0(%rsp)
    97ad:      	leaq	0x50(%rcx), %rax
    97b1:      	movq	%rax, 0xe8(%rsp)
    97b9:      	leaq	0x58(%rcx), %rax
    97bd:      	movq	%rax, 0xa8(%rsp)
    97c5:      	leaq	0x60(%rcx), %rax
    97c9:      	movq	%rax, 0xe0(%rsp)
    97d1:      	leaq	0x68(%rcx), %rax
    97d5:      	movq	%rax, 0xa0(%rsp)
    97dd:      	leaq	0x70(%rcx), %rax
    97e1:      	movq	%rax, 0x110(%rsp)
    97e9:      	leaq	0x80(%rcx), %rax
    97f0:      	movq	%rax, 0xd8(%rsp)
    97f8:      	leaq	0x98(%rcx), %rax
    97ff:      	movq	%rax, 0x98(%rsp)
    9807:      	movb	$0x1, %al
    9809:      	movl	%eax, 0x3c(%rsp)
    980d:      	xorl	%r15d, %r15d
    9810:      	xorl	%ebp, %ebp
    9812:      	movq	%r14, 0x28(%rsp)
    9817:      	jmp	0x9849 <generic_usdt_actions+0x1f9>
    9819:      	incl	%ebp
    981b:      	movl	0x4(%r14,%rbp,4), %eax
    9820:      	movl	%eax, 0x78(%r13)
    9824:      	nopw	%cs:(%rax,%rax)
    9830:      	movq	%rbx, 0x70(%r13)
    9834:      	incl	%ebp
    9836:      	movl	%ebp, %r12d
    9839:      	incl	%r15d
    983c:      	movl	%r12d, %ebp
    983f:      	cmpl	$0x3, %r15d
    9843:      	je	0xa39c <generic_usdt_actions+0xd4c>
    9849:      	leal	0x4(,%rbp,4), %eax
    9850:      	cmpl	(%r14), %eax
    9853:      	jae	0xa39c <generic_usdt_actions+0xd4c>
    9859:      	movl	%ebp, %eax
    985b:      	movslq	0x4(%r14,%rax,4), %rbx
    9860:      	movl	$0x0, 0x78(%rsp)
    9868:      	movl	$0x1, %eax
    986d:      	movq	(%rip), %rdi            # 0x9874 <generic_usdt_actions+0x224>
    9874:      	leaq	0x78(%rsp), %rsi
    9879:      	callq	*%rax
    987b:      	xorl	%r12d, %r12d
    987e:      	testq	%rax, %rax
    9881:      	je	0x9839 <generic_usdt_actions+0x1e9>
    9883:      	movq	%rax, %r13
    9886:      	cmpl	$0x7, %ebx
    9889:      	jg	0x98b0 <generic_usdt_actions+0x260>
    988b:      	cmpl	$0x3, %ebx
    988e:      	jg	0x98e3 <generic_usdt_actions+0x293>
    9890:      	cmpl	$0x1, %ebx
    9893:      	jg	0x9a3f <generic_usdt_actions+0x3ef>
    9899:      	testl	%ebx, %ebx
    989b:      	je	0x9d1d <generic_usdt_actions+0x6cd>
    98a1:      	cmpl	$0x1, %ebx
    98a4:      	je	0x9a56 <generic_usdt_actions+0x406>
    98aa:      	jmp	0x9830 <generic_usdt_actions+0x1e0>
    98ac:      	nopl	(%rax)
    98b0:      	cmpl	$0xb, %ebx
    98b3:      	jg	0x9944 <generic_usdt_actions+0x2f4>
    98b9:      	leal	-0xa(%rbx), %eax
    98bc:      	cmpl	$0x2, %eax
    98bf:      	jb	0x9b7e <generic_usdt_actions+0x52e>
    98c5:      	cmpl	$0x8, %ebx
    98c8:      	je	0x9c74 <generic_usdt_actions+0x624>
    98ce:      	cmpl	$0x9, %ebx
    98d1:      	jne	0x9830 <generic_usdt_actions+0x1e0>
    98d7:      	incl	%ebp
    98d9:      	movl	0x4(%r14,%rbp,4), %eax
    98de:      	jmp	0x9c43 <generic_usdt_actions+0x5f3>
    98e3:      	leal	-0x6(%rbx), %eax
    98e6:      	cmpl	$0x2, %eax
    98e9:      	jb	0x9819 <generic_usdt_actions+0x1c9>
    98ef:      	cmpl	$0x4, %ebx
    98f2:      	je	0x9c81 <generic_usdt_actions+0x631>
    98f8:      	cmpl	$0x5, %ebx
    98fb:      	jne	0x9830 <generic_usdt_actions+0x1e0>
    9901:      	leal	0x1(%rbp), %eax
    9904:      	movl	0x4(%r14,%rax,4), %eax
    9909:      	addl	$0x2, %ebp
    990c:      	movl	0x4(%r14,%rbp,4), %r14d
    9911:      	movq	$0x0, 0x10(%rsp)
    991a:      	movq	$0x0, 0x8(%rsp)
    9923:      	andl	$0x7, %eax
    9926:      	cmpl	$0x4, %eax
    9929:      	ja	0x993a <generic_usdt_actions+0x2ea>
    992b:      	cmpl	$0x0, 0x5ea0(%r13,%rax,4)
    9934:      	je	0x9e64 <generic_usdt_actions+0x814>
    993a:      	movq	0x28(%rsp), %r14
    993f:      	jmp	0x9830 <generic_usdt_actions+0x1e0>
    9944:      	cmpl	$0xc, %ebx
    9947:      	je	0x9ddd <generic_usdt_actions+0x78d>
    994d:      	cmpl	$0xd, %ebx
    9950:      	je	0x9c95 <generic_usdt_actions+0x645>
    9956:      	cmpl	$0xe, %ebx
    9959:      	jne	0x9830 <generic_usdt_actions+0x1e0>
    995f:      	leal	0x2(%rbp), %eax
    9962:      	movl	$0x9, %r12d
    9968:      	cmpb	$0x0, 0x68(%rsp)
    996d:      	je	0x9df2 <generic_usdt_actions+0x7a2>
    9973:      	movl	%eax, 0x18(%rsp)
    9977:      	movl	%eax, %eax
    9979:      	movl	0x4(%r14,%rax,4), %eax
    997e:      	movl	%eax, 0x20(%rsp)
    9982:      	incl	%ebp
    9984:      	movl	0x4(%r14,%rbp,4), %r14d
    9989:      	movq	%r13, %rsi
    998c:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    9993:      	movl	$0x1, %eax
    9998:      	movq	(%rip), %rdi            # 0x999f <generic_usdt_actions+0x34f>
    999f:      	callq	*%rax
    99a1:      	movl	$0x8, %r12d
    99a7:      	testq	%rax, %rax
    99aa:      	je	0x9f1a <generic_usdt_actions+0x8ca>
    99b0:      	andl	$0x7, %r14d
    99b4:      	leaq	(%r14,%r14,2), %rcx
    99b8:      	cmpb	$0x3, 0x211(%rax,%rcx,8)
    99c0:      	movq	0x28(%rsp), %r14
    99c5:      	leaq	0x8(%rsp), %rsi
    99ca:      	movl	0x18(%rsp), %ebp
    99ce:      	jne	0xa372 <generic_usdt_actions+0xd22>
    99d4:      	rorxl	$0x3, 0x208(%rax,%rcx,8), %edx
    99df:      	cmpl	$0x7, %edx
    99e2:      	jle	0xa1c7 <generic_usdt_actions+0xb77>
    99e8:      	cmpl	$0xb, %edx
    99eb:      	movl	0x20(%rsp), %r8d
    99f0:      	movq	%rsi, %rbp
    99f3:      	jle	0xa25a <generic_usdt_actions+0xc0a>
    99f9:      	cmpl	$0xd, %edx
    99fc:      	jle	0xa31f <generic_usdt_actions+0xccf>
    9a02:      	movq	0x110(%rsp), %rsi
    9a0a:      	cmpl	$0xe, %edx
    9a0d:      	je	0xa33e <generic_usdt_actions+0xcee>
    9a13:      	movq	0xd8(%rsp), %rsi
    9a1b:      	cmpl	$0x10, %edx
    9a1e:      	je	0xa33e <generic_usdt_actions+0xcee>
    9a24:      	movl	$0x0, %edi
    9a29:      	cmpl	$0x13, %edx
    9a2c:      	jne	0xa341 <generic_usdt_actions+0xcf1>
    9a32:      	movq	0x98(%rsp), %rsi
    9a3a:      	jmp	0xa33e <generic_usdt_actions+0xcee>
    9a3f:      	movl	$0x9, %eax
    9a44:      	cmpl	$0x2, %ebx
    9a47:      	je	0x9c43 <generic_usdt_actions+0x5f3>
    9a4d:      	cmpl	$0x3, %ebx
    9a50:      	jne	0x9830 <generic_usdt_actions+0x1e0>
    9a56:      	leal	0x1(%rbp), %eax
    9a59:      	movq	%r14, %rcx
    9a5c:      	movl	0x4(%r14,%rax,4), %r14d
    9a61:      	addl	$0x2, %ebp
    9a64:      	movl	0x4(%rcx,%rbp,4), %eax
    9a68:      	movq	%rax, 0x18(%rsp)
    9a6d:      	movq	$0x0, 0x10(%rsp)
    9a76:      	movq	$0x0, 0x8(%rsp)
    9a7f:      	movl	$0x0, 0x30(%rsp)
    9a87:      	movl	$0x1, %eax
    9a8c:      	leaq	0x30(%rsp), %rsi
    9a91:      	movq	(%rip), %rdi            # 0x9a98 <generic_usdt_actions+0x448>
    9a98:      	callq	*%rax
    9a9a:      	xorl	%ecx, %ecx
    9a9c:      	testq	%rax, %rax
    9a9f:      	je	0x9f43 <generic_usdt_actions+0x8f3>
    9aa5:      	andl	$0x7, %r14d
    9aa9:      	cmpl	$0x4, %r14d
    9aad:      	ja	0x9f43 <generic_usdt_actions+0x8f3>
    9ab3:      	cmpl	$0x0, 0x5ea0(%r13,%r14,4)
    9abc:      	jne	0x9f43 <generic_usdt_actions+0x8f3>
    9ac2:      	movq	%rax, 0x20(%rsp)
    9ac7:      	movq	0x5e78(%r13,%r14,8), %rax
    9acf:      	movl	$0x0, 0x14(%rsp)
    9ad7:      	andl	$0x7ff, %eax            # imm = 0x7FF
    9adc:      	movl	0x90(%r13,%rax), %eax
    9ae4:      	movl	%eax, 0x10(%rsp)
    9ae8:      	movl	$0xe, %eax
    9aed:      	callq	*%rax
    9aef:      	shrq	$0x20, %rax
    9af3:      	movq	%rax, 0x8(%rsp)
    9af8:      	cmpl	$0x1, %ebx
    9afb:      	jne	0x9f2d <generic_usdt_actions+0x8dd>
    9b01:      	movq	0x18(%rsp), %rax
    9b06:      	andl	$0x7, %eax
    9b09:      	cmpl	$0x4, %eax
    9b0c:      	movq	0x28(%rsp), %r14
    9b11:      	movl	$0x0, %ecx
    9b16:      	ja	0x9f48 <generic_usdt_actions+0x8f8>
    9b1c:      	cmpl	$0x0, 0x5ea0(%r13,%rax,4)
    9b25:      	jne	0x9f48 <generic_usdt_actions+0x8f8>
    9b2b:      	movq	0x5e78(%r13,%rax,8), %rax
    9b33:      	andl	$0x7ff, %eax            # imm = 0x7FF
    9b38:      	leaq	(%rax,%r13), %rdx
    9b3c:      	addq	$0x90, %rdx
    9b43:      	movl	0x90(%r13,%rax), %esi
    9b4b:      	andl	$0xfff, %esi            # imm = 0xFFF
    9b51:      	addq	$0x8, %rsi
    9b55:      	movl	$0x4, %eax
    9b5a:      	movq	0x20(%rsp), %rdi
    9b5f:      	callq	*%rax
    9b61:      	xorl	%ecx, %ecx
    9b63:      	movl	$0x2, %eax
    9b68:      	leaq	0x8(%rsp), %rsi
    9b6d:      	movq	(%rip), %rdi            # 0x9b74 <generic_usdt_actions+0x524>
    9b74:      	movq	0x20(%rsp), %rdx
    9b79:      	jmp	0x9c30 <generic_usdt_actions+0x5e0>
    9b7e:      	incl	%ebp
    9b80:      	movl	0x4(%r14,%rbp,4), %eax
    9b85:      	andl	$0x7, %eax
    9b88:      	xorl	%ecx, %ecx
    9b8a:      	cmpl	$0x4, %eax
    9b8d:      	ja	0x9f48 <generic_usdt_actions+0x8f8>
    9b93:      	cmpl	$0x0, 0x5ea0(%r13,%rax,4)
    9b9c:      	jne	0x9f48 <generic_usdt_actions+0x8f8>
    9ba2:      	movq	0x5e78(%r13,%rax,8), %rax
    9baa:      	andl	$0x7ff, %eax            # imm = 0x7FF
    9baf:      	movq	0xb8(%r13,%rax), %rax
    9bb7:      	movq	%rax, 0x30(%rsp)
    9bbc:      	testq	%rax, %rax
    9bbf:      	je	0x9f48 <generic_usdt_actions+0x8f8>
    9bc5:      	cmpl	$0xa, %ebx
    9bc8:      	jne	0x9f55 <generic_usdt_actions+0x905>
    9bce:      	movl	$0xe, %eax
    9bd3:      	callq	*%rax
    9bd5:      	movq	%rax, 0x18(%rsp)
    9bda:      	shrq	$0x20, %rax
    9bde:      	movl	%eax, 0x8(%rsp)
    9be2:      	movl	$0x1, %eax
    9be7:      	leaq	0x8(%rsp), %rsi
    9bec:      	movq	(%rip), %rdi            # 0x9bf3 <generic_usdt_actions+0x5a3>
    9bf3:      	callq	*%rax
    9bf5:      	xorl	%ecx, %ecx
    9bf7:      	testq	%rax, %rax
    9bfa:      	je	0x9f48 <generic_usdt_actions+0x8f8>
    9c00:      	movl	(%rax), %ecx
    9c02:      	movl	%ecx, 0x8(%rsp)
    9c06:      	movq	0x18(%rsp), %rcx
    9c0b:      	movl	%ecx, 0xc(%rsp)
    9c0f:      	movq	0x8(%rax), %rax
    9c13:      	movq	%rax, 0x10(%rsp)
    9c18:      	xorl	%ecx, %ecx
    9c1a:      	movl	$0x2, %eax
    9c1f:      	leaq	0x30(%rsp), %rsi
    9c24:      	leaq	0x8(%rsp), %rdx
    9c29:      	movq	(%rip), %rdi            # 0x9c30 <generic_usdt_actions+0x5e0>
    9c30:      	xorl	%ecx, %ecx
    9c32:      	callq	*%rax
    9c34:      	xorl	%ecx, %ecx
    9c36:      	testl	%ecx, %ecx
    9c38:      	jne	0x9839 <generic_usdt_actions+0x1e9>
    9c3e:      	jmp	0x9830 <generic_usdt_actions+0x1e0>
    9c43:      	movl	$0x3, %r12d
    9c49:      	cmpb	$0x0, 0x68(%rsp)
    9c4e:      	leaq	0x8(%rsp), %rsi
    9c53:      	je	0xa377 <generic_usdt_actions+0xd27>
    9c59:      	movslq	%eax, %rdi
    9c5c:      	movl	$0x6d, %eax
    9c61:      	movq	%rsi, %r12
    9c64:      	callq	*%rax
    9c66:      	movq	%r12, %rsi
    9c69:      	movl	$0x2, %r12d
    9c6f:      	jmp	0xa377 <generic_usdt_actions+0xd27>
    9c74:      	movl	$0x0, 0x3c(%rsp)
    9c7c:      	jmp	0x9830 <generic_usdt_actions+0x1e0>
    9c81:      	incl	%ebp
    9c83:      	movq	0x80(%rsp), %r12
    9c8b:      	leaq	0x8(%rsp), %rsi
    9c90:      	jmp	0xa377 <generic_usdt_actions+0xd27>
    9c95:      	movl	$0xe, %eax
    9c9a:      	callq	*%rax
    9c9c:      	movq	%rax, 0x48(%rsp)
    9ca1:      	movl	$0x1, %eax
    9ca6:      	leaq	0x48(%rsp), %rsi
    9cab:      	movq	(%rip), %rdi            # 0x9cb2 <generic_usdt_actions+0x662>
    9cb2:      	callq	*%rax
    9cb4:      	testq	%rax, %rax
    9cb7:      	je	0x9830 <generic_usdt_actions+0x1e0>
    9cbd:      	movq	%r13, 0x58(%rsp)
    9cc2:      	movq	0x4(%rax), %rax
    9cc6:      	movq	%rax, 0x30(%rsp)
    9ccb:      	movl	$0x2, 0x38(%rsp)
    9cd3:      	movl	$0x1, %eax
    9cd8:      	leaq	0x30(%rsp), %r12
    9cdd:      	movq	(%rip), %r13            # 0x9ce4 <generic_usdt_actions+0x694>
    9ce4:      	movq	%r13, %rdi
    9ce7:      	movq	%r12, %rsi
    9cea:      	callq	*%rax
    9cec:      	movl	$0x1, 0x54(%rsp)
    9cf4:      	testq	%rax, %rax
    9cf7:      	je	0x9dfe <generic_usdt_actions+0x7ae>
    9cfd:      	lock
    9cfe:      	incl	(%rax)
    9d00:      	movl	$0x3, %eax
    9d05:      	leaq	0x48(%rsp), %rsi
    9d0a:      	movq	(%rip), %rdi            # 0x9d11 <generic_usdt_actions+0x6c1>
    9d11:      	callq	*%rax
    9d13:      	movq	0x58(%rsp), %r13
    9d18:      	jmp	0x9830 <generic_usdt_actions+0x1e0>
    9d1d:      	leal	0x1(%rbp), %eax
    9d20:      	movl	0x4(%r14,%rax,4), %r12d
    9d25:      	leal	0x2(%rbp), %eax
    9d28:      	movl	0x4(%r14,%rax,4), %r14d
    9d2d:      	movl	$0x7d, %eax
    9d32:      	callq	*%rax
    9d34:      	movq	%rax, 0x8(%rsp)
    9d39:      	movl	$0x0, 0x48(%rsp)
    9d41:      	movq	%r12, 0x90(%rsp)
    9d49:      	testq	%r12, %r12
    9d4c:      	leaq	0x30(%rsp), %r12
    9d51:      	je	0xa157 <generic_usdt_actions+0xb07>
    9d57:      	movl	$0x1, %eax
    9d5c:      	movq	(%rip), %rdi            # 0x9d63 <generic_usdt_actions+0x713>
    9d63:      	leaq	0x48(%rsp), %rsi
    9d68:      	callq	*%rax
    9d6a:      	testq	%rax, %rax
    9d6d:      	je	0xa157 <generic_usdt_actions+0xb07>
    9d73:      	movq	%rax, 0x18(%rsp)
    9d78:      	movl	%r14d, 0x20(%rsp)
    9d7d:      	movq	0x18(%rsp), %r14
    9d82:      	movl	$0x1, %eax
    9d87:      	leaq	0x48(%rsp), %rsi
    9d8c:      	movq	(%rip), %rdi            # 0x9d93 <generic_usdt_actions+0x743>
    9d93:      	callq	*%rax
    9d95:      	movq	%rax, %rdx
    9d98:      	movq	0x60(%r13), %rax
    9d9c:      	movq	%rax, (%r14)
    9d9f:      	movq	0x70(%r13), %rax
    9da3:      	movq	%r14, 0x60(%rsp)
    9da8:      	movq	%rax, 0x8(%r14)
    9dac:      	movl	0x20(%rsp), %ecx
    9db0:      	movq	0x18(%rsp), %rdi
    9db5:      	movl	$0x0, %eax
    9dba:      	cmpl	$0x2, %ecx
    9dbd:      	je	0x9f7c <generic_usdt_actions+0x92c>
    9dc3:      	cmpl	$0x1, %ecx
    9dc6:      	je	0x9f78 <generic_usdt_actions+0x928>
    9dcc:      	testl	%ecx, %ecx
    9dce:      	jne	0xa157 <generic_usdt_actions+0xb07>
    9dd4:      	movl	0x7c(%r13), %eax
    9dd8:      	jmp	0x9f7c <generic_usdt_actions+0x92c>
    9ddd:      	addl	$0x3, %ebp
    9de0:      	movq	0x88(%rsp), %r12
    9de8:      	leaq	0x8(%rsp), %rsi
    9ded:      	jmp	0xa377 <generic_usdt_actions+0xd27>
    9df2:      	leaq	0x8(%rsp), %rsi
    9df7:      	movl	%eax, %ebp
    9df9:      	jmp	0xa377 <generic_usdt_actions+0xd27>
    9dfe:      	movl	$0x2, %eax
    9e03:      	movl	$0x1, %ecx
    9e08:      	leaq	0x54(%rsp), %rdx
    9e0d:      	movq	%r13, %rdi
    9e10:      	movq	%r12, %rsi
    9e13:      	callq	*%rax
    9e15:      	testq	%rax, %rax
    9e18:      	movq	(%rip), %r13            # 0x9e1f <generic_usdt_actions+0x7cf>
    9e1f:      	je	0x9d00 <generic_usdt_actions+0x6b0>
    9e25:      	movq	%rax, %r12
    9e28:      	negl	%eax
    9e2a:      	movw	%ax, 0x8(%rsp)
    9e2f:      	movw	$0x3, 0xa(%rsp)
    9e36:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    9e40:      	movq	%rax, 0xc(%rsp)
    9e45:      	movl	$0x1, %eax
    9e4a:      	leaq	0x8(%rsp), %rsi
    9e4f:      	movq	%r13, %rdi
    9e52:      	callq	*%rax
    9e54:      	testq	%rax, %rax
    9e57:      	je	0xa209 <generic_usdt_actions+0xbb9>
    9e5d:      	incl	(%rax)
    9e5f:      	jmp	0xa229 <generic_usdt_actions+0xbd9>
    9e64:      	movq	0x5e78(%r13,%rax,8), %rax
    9e6c:      	andl	$0x7ff, %eax            # imm = 0x7FF
    9e71:      	movl	0x90(%r13,%rax), %eax
    9e79:      	movl	%eax, 0x10(%rsp)
    9e7d:      	movl	$0xe, %eax
    9e82:      	callq	*%rax
    9e84:      	shrq	$0x20, %rax
    9e88:      	movq	%rax, 0x8(%rsp)
    9e8d:      	movl	$0x1, %eax
    9e92:      	leaq	0x8(%rsp), %rsi
    9e97:      	movq	(%rip), %rdi            # 0x9e9e <generic_usdt_actions+0x84e>
    9e9e:      	callq	*%rax
    9ea0:      	testq	%rax, %rax
    9ea3:      	je	0x993a <generic_usdt_actions+0x2ea>
    9ea9:      	andl	$0x7, %r14d
    9ead:      	cmpl	$0x4, %r14d
    9eb1:      	ja	0x993a <generic_usdt_actions+0x2ea>
    9eb7:      	cmpl	$0x0, 0x5ea0(%r13,%r14,4)
    9ec0:      	jne	0x993a <generic_usdt_actions+0x2ea>
    9ec6:      	movq	0x5e78(%r13,%r14,8), %rcx
    9ece:      	movl	$0x0, 0x14(%rsp)
    9ed6:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    9edc:      	movl	0x90(%r13,%rcx), %ecx
    9ee4:      	movl	%ecx, 0x10(%rsp)
    9ee8:      	movq	%rax, %r12
    9eeb:      	movl	$0xe, %eax
    9ef0:      	callq	*%rax
    9ef2:      	shrq	$0x20, %rax
    9ef6:      	movq	%rax, 0x8(%rsp)
    9efb:      	movl	$0x2, %eax
    9f00:      	xorl	%ecx, %ecx
    9f02:      	leaq	0x8(%rsp), %rsi
    9f07:      	movq	(%rip), %rdi            # 0x9f0e <generic_usdt_actions+0x8be>
    9f0e:      	movq	%r12, %rdx
    9f11:      	xorl	%ecx, %ecx
    9f13:      	callq	*%rax
    9f15:      	jmp	0x993a <generic_usdt_actions+0x2ea>
    9f1a:      	movq	0x28(%rsp), %r14
    9f1f:      	leaq	0x8(%rsp), %rsi
    9f24:      	movl	0x18(%rsp), %ebp
    9f28:      	jmp	0xa377 <generic_usdt_actions+0xd27>
    9f2d:      	movl	$0x3, %eax
    9f32:      	leaq	0x8(%rsp), %rsi
    9f37:      	movq	(%rip), %rdi            # 0x9f3e <generic_usdt_actions+0x8ee>
    9f3e:      	callq	*%rax
    9f40:      	movq	%rax, %rcx
    9f43:      	movq	0x28(%rsp), %r14
    9f48:      	testl	%ecx, %ecx
    9f4a:      	jne	0x9839 <generic_usdt_actions+0x1e9>
    9f50:      	jmp	0x9830 <generic_usdt_actions+0x1e0>
    9f55:      	movl	$0x3, %eax
    9f5a:      	leaq	0x30(%rsp), %rsi
    9f5f:      	movq	(%rip), %rdi            # 0x9f66 <generic_usdt_actions+0x916>
    9f66:      	callq	*%rax
    9f68:      	movq	%rax, %rcx
    9f6b:      	testl	%ecx, %ecx
    9f6d:      	jne	0x9839 <generic_usdt_actions+0x1e9>
    9f73:      	jmp	0x9830 <generic_usdt_actions+0x1e0>
    9f78:      	movl	0x10(%r13), %eax
    9f7c:      	xorl	%ecx, %ecx
    9f7e:      	movq	%rcx, 0x20(%rsp)
    9f83:      	movl	%eax, %eax
    9f85:      	movq	0x60(%rsp), %rcx
    9f8a:      	movq	%rax, 0x10(%rcx)
    9f8e:      	addq	$0x18, %rdi
    9f92:      	movl	$0x4, %eax
    9f97:      	movl	$0xc8, %ecx
    9f9c:      	movq	%rdi, 0x18(%rsp)
    9fa1:      	movl	$0xc8, %esi
    9fa6:      	callq	*%rax
    9fa8:      	xorl	%r14d, %r14d
    9fab:      	movq	%r13, 0x58(%rsp)
    9fb0:      	jmp	0x9fd3 <generic_usdt_actions+0x983>
    9fb2:      	nopw	%cs:(%rax,%rax)
    9fc0:      	leaq	0x30(%rsp), %r12
    9fc5:      	addq	$0x4, %r14
    9fc9:      	cmpq	$0x14, %r14
    9fcd:      	je	0xa103 <generic_usdt_actions+0xab3>
    9fd3:      	movl	$0x0, 0x30(%rsp)
    9fdb:      	movl	$0x1, %eax
    9fe0:      	movq	(%rip), %rdi            # 0x9fe7 <generic_usdt_actions+0x997>
    9fe7:      	movq	%r12, %rsi
    9fea:      	callq	*%rax
    9fec:      	testq	%rax, %rax
    9fef:      	je	0xa103 <generic_usdt_actions+0xab3>
    9ff5:      	movq	%rax, %rsi
    9ff8:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    9fff:      	movl	$0x1, %eax
    a004:      	movq	(%rip), %rdi            # 0xa00b <generic_usdt_actions+0x9bb>
    a00b:      	callq	*%rax
    a00d:      	testq	%rax, %rax
    a010:      	je	0xa103 <generic_usdt_actions+0xab3>
    a016:      	cmpl	$-0x1, 0x40(%rax,%r14)
    a01c:      	je	0xa103 <generic_usdt_actions+0xab3>
    a022:      	movq	0x5e78(%r13,%r14,2), %rax
    a02a:      	movl	0x4(%r13), %ecx
    a02e:      	cmpq	%rcx, %rax
    a031:      	jge	0xa103 <generic_usdt_actions+0xab3>
    a037:      	cmpq	$0x10, %r14
    a03b:      	je	0xa09d <generic_usdt_actions+0xa4d>
    a03d:      	movl	$0x0, 0x30(%rsp)
    a045:      	movl	$0x1, %eax
    a04a:      	movq	(%rip), %rdi            # 0xa051 <generic_usdt_actions+0xa01>
    a051:      	movq	%r12, %rsi
    a054:      	callq	*%rax
    a056:      	testq	%rax, %rax
    a059:      	je	0xa095 <generic_usdt_actions+0xa45>
    a05b:      	movq	%rax, %rsi
    a05e:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    a065:      	movl	$0x1, %eax
    a06a:      	movq	(%rip), %rdi            # 0xa071 <generic_usdt_actions+0xa21>
    a071:      	callq	*%rax
    a073:      	testq	%rax, %rax
    a076:      	je	0xa095 <generic_usdt_actions+0xa45>
    a078:      	cmpl	$-0x1, 0x44(%rax,%r14)
    a07e:      	movq	0x5e78(%r13,%r14,2), %rax
    a086:      	je	0xa09d <generic_usdt_actions+0xa4d>
    a088:      	movl	0x5e80(%r13,%r14,2), %r12d
    a090:      	subl	%eax, %r12d
    a093:      	jmp	0xa0a8 <generic_usdt_actions+0xa58>
    a095:      	movq	0x5e78(%r13,%r14,2), %rax
    a09d:      	movl	0x4(%r13), %r12d
    a0a1:      	subl	%eax, %r12d
    a0a4:      	addl	$0x4, %r12d
    a0a8:      	testl	%r12d, %r12d
    a0ab:      	jle	0x9fc0 <generic_usdt_actions+0x970>
    a0b1:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    a0b6:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    a0bb:      	cmpl	$0x28, %r12d
    a0bf:      	movl	$0x28, %ecx
    a0c4:      	cmovgel	%ecx, %r12d
    a0c8:      	movzbl	0x20(%rsp), %r13d
    a0ce:      	movq	0x18(%rsp), %rcx
    a0d3:      	leaq	(%rcx,%r13), %rdi
    a0d7:      	movq	0x58(%rsp), %rcx
    a0dc:      	leaq	(%rcx,%rax), %rdx
    a0e0:      	addq	$0x90, %rdx
    a0e7:      	movl	$0x4, %eax
    a0ec:      	movl	%r12d, %esi
    a0ef:      	callq	*%rax
    a0f1:      	addl	%r13d, %r12d
    a0f4:      	movq	0x58(%rsp), %r13
    a0f9:      	movq	%r12, 0x20(%rsp)
    a0fe:      	jmp	0x9fc0 <generic_usdt_actions+0x970>
    a103:      	movl	$0x1, %eax
    a108:      	movq	(%rip), %rdi            # 0xa10f <generic_usdt_actions+0xabf>
    a10f:      	movq	0x60(%rsp), %rsi
    a114:      	callq	*%rax
    a116:      	testq	%rax, %rax
    a119:      	je	0xa13b <generic_usdt_actions+0xaeb>
    a11b:      	imulq	$-0xf4240, 0x90(%rsp), %rcx # imm = 0xFFF0BDC0
    a127:      	addq	0x8(%rsp), %rcx
    a12c:      	cmpq	%rcx, (%rax)
    a12f:      	jbe	0xa13b <generic_usdt_actions+0xaeb>
    a131:      	movl	$0x0, 0x3c(%rsp)
    a139:      	jmp	0xa157 <generic_usdt_actions+0xb07>
    a13b:      	movl	$0x2, %eax
    a140:      	xorl	%ecx, %ecx
    a142:      	movq	(%rip), %rdi            # 0xa149 <generic_usdt_actions+0xaf9>
    a149:      	leaq	0x8(%rsp), %rdx
    a14e:      	movq	0x60(%rsp), %rsi
    a153:      	xorl	%ecx, %ecx
    a155:      	callq	*%rax
    a157:      	leal	0x3(%rbp), %eax
    a15a:      	movq	0x28(%rsp), %r14
    a15f:      	cmpl	$0x0, 0x4(%r14,%rax,4)
    a165:      	je	0xa18a <generic_usdt_actions+0xb3a>
    a167:      	orb	$0x2, 0x1(%r13)
    a16c:      	movl	$0x1b, %eax
    a171:      	xorl	%ecx, %ecx
    a173:      	movq	(%rip), %rsi            # 0xa17a <generic_usdt_actions+0xb2a>
    a17a:      	movq	0x40(%rsp), %rdi
    a17f:      	xorl	%edx, %edx
    a181:      	callq	*%rax
    a183:      	movq	%rax, 0x80(%r13)
    a18a:      	addl	$0x4, %ebp
    a18d:      	cmpl	$0x0, 0x4(%r14,%rbp,4)
    a193:      	je	0x9830 <generic_usdt_actions+0x1e0>
    a199:      	orb	$0x4, 0x1(%r13)
    a19e:      	movl	$0x1b, %eax
    a1a3:      	movq	(%rip), %rsi            # 0xa1aa <generic_usdt_actions+0xb5a>
    a1aa:      	movl	$0x100, %ecx            # imm = 0x100
    a1af:      	movq	0x40(%rsp), %rdi
    a1b4:      	movl	$0x100, %edx            # imm = 0x100
    a1b9:      	callq	*%rax
    a1bb:      	movq	%rax, 0x88(%r13)
    a1c2:      	jmp	0x9830 <generic_usdt_actions+0x1e0>
    a1c7:      	cmpl	$0x3, %edx
    a1ca:      	movl	0x20(%rsp), %r8d
    a1cf:      	movq	%rsi, %rbp
    a1d2:      	jg	0xa28b <generic_usdt_actions+0xc3b>
    a1d8:      	cmpl	$0x1, %edx
    a1db:      	jg	0xa2dd <generic_usdt_actions+0xc8d>
    a1e1:      	movq	0x40(%rsp), %rsi
    a1e6:      	testl	%edx, %edx
    a1e8:      	je	0xa33e <generic_usdt_actions+0xcee>
    a1ee:      	movq	0xd0(%rsp), %rsi
    a1f6:      	movl	$0x0, %edi
    a1fb:      	cmpl	$0x1, %edx
    a1fe:      	je	0xa33e <generic_usdt_actions+0xcee>
    a204:      	jmp	0xa341 <generic_usdt_actions+0xcf1>
    a209:      	movl	$0x1, 0x7c(%rsp)
    a211:      	movl	$0x2, %eax
    a216:      	xorl	%ecx, %ecx
    a218:      	leaq	0x7c(%rsp), %rdx
    a21d:      	leaq	0x8(%rsp), %rsi
    a222:      	movq	%r13, %rdi
    a225:      	xorl	%ecx, %ecx
    a227:      	callq	*%rax
    a229:      	testl	%r12d, %r12d
    a22c:      	je	0x9d00 <generic_usdt_actions+0x6b0>
    a232:      	movl	$0x1, %eax
    a237:      	leaq	0x30(%rsp), %rsi
    a23c:      	movq	(%rip), %rdi            # 0xa243 <generic_usdt_actions+0xbf3>
    a243:      	callq	*%rax
    a245:      	testq	%rax, %rax
    a248:      	je	0x9d00 <generic_usdt_actions+0x6b0>
    a24e:      	movl	0x54(%rsp), %ecx
    a252:      	lock
    a253:      	addl	%ecx, (%rax)
    a255:      	jmp	0x9d00 <generic_usdt_actions+0x6b0>
    a25a:      	cmpl	$0x9, %edx
    a25d:      	jg	0xa2bc <generic_usdt_actions+0xc6c>
    a25f:      	movq	0xf0(%rsp), %rsi
    a267:      	cmpl	$0x8, %edx
    a26a:      	je	0xa33e <generic_usdt_actions+0xcee>
    a270:      	movq	0xb0(%rsp), %rsi
    a278:      	movl	$0x0, %edi
    a27d:      	cmpl	$0x9, %edx
    a280:      	je	0xa33e <generic_usdt_actions+0xcee>
    a286:      	jmp	0xa341 <generic_usdt_actions+0xcf1>
    a28b:      	cmpl	$0x5, %edx
    a28e:      	jg	0xa2fe <generic_usdt_actions+0xcae>
    a290:      	movq	0x100(%rsp), %rsi
    a298:      	cmpl	$0x4, %edx
    a29b:      	je	0xa33e <generic_usdt_actions+0xcee>
    a2a1:      	movq	0xc0(%rsp), %rsi
    a2a9:      	movl	$0x0, %edi
    a2ae:      	cmpl	$0x5, %edx
    a2b1:      	je	0xa33e <generic_usdt_actions+0xcee>
    a2b7:      	jmp	0xa341 <generic_usdt_actions+0xcf1>
    a2bc:      	movq	0xe8(%rsp), %rsi
    a2c4:      	cmpl	$0xa, %edx
    a2c7:      	je	0xa33e <generic_usdt_actions+0xcee>
    a2c9:      	movq	0xa8(%rsp), %rsi
    a2d1:      	movl	$0x0, %edi
    a2d6:      	cmpl	$0xb, %edx
    a2d9:      	je	0xa33e <generic_usdt_actions+0xcee>
    a2db:      	jmp	0xa341 <generic_usdt_actions+0xcf1>
    a2dd:      	movq	0x108(%rsp), %rsi
    a2e5:      	cmpl	$0x2, %edx
    a2e8:      	je	0xa33e <generic_usdt_actions+0xcee>
    a2ea:      	movq	0xc8(%rsp), %rsi
    a2f2:      	movl	$0x0, %edi
    a2f7:      	cmpl	$0x3, %edx
    a2fa:      	je	0xa33e <generic_usdt_actions+0xcee>
    a2fc:      	jmp	0xa341 <generic_usdt_actions+0xcf1>
    a2fe:      	movq	0xf8(%rsp), %rsi
    a306:      	cmpl	$0x6, %edx
    a309:      	je	0xa33e <generic_usdt_actions+0xcee>
    a30b:      	movq	0xb8(%rsp), %rsi
    a313:      	movl	$0x0, %edi
    a318:      	cmpl	$0x7, %edx
    a31b:      	je	0xa33e <generic_usdt_actions+0xcee>
    a31d:      	jmp	0xa341 <generic_usdt_actions+0xcf1>
    a31f:      	movq	0xe0(%rsp), %rsi
    a327:      	cmpl	$0xc, %edx
    a32a:      	je	0xa33e <generic_usdt_actions+0xcee>
    a32c:      	movq	0xa0(%rsp), %rsi
    a334:      	movl	$0x0, %edi
    a339:      	cmpl	$0xd, %edx
    a33c:      	jne	0xa341 <generic_usdt_actions+0xcf1>
    a33e:      	movq	(%rsi), %rdi
    a341:      	leaq	(%rax,%rcx,8), %rax
    a345:      	addq	$0x200, %rax            # imm = 0x200
    a34b:      	addq	(%rax), %rdi
    a34e:      	movl	%r8d, 0x8(%rsp)
    a353:      	movl	$0x24, %eax
    a358:      	movl	$0x4, %ecx
    a35d:      	movq	%rbp, %rsi
    a360:      	movl	$0x4, %edx
    a365:      	callq	*%rax
    a367:      	movq	%rbp, %rsi
    a36a:      	testl	%eax, %eax
    a36c:      	movl	0x18(%rsp), %ebp
    a370:      	je	0xa377 <generic_usdt_actions+0xd27>
    a372:      	orb	$0x20, 0x1(%r13)
    a377:      	movl	$0x0, 0x8(%rsp)
    a37f:      	movl	$0x1, %eax
    a384:      	movq	(%rip), %rdi            # 0xa38b <generic_usdt_actions+0xd3b>
    a38b:      	callq	*%rax
    a38d:      	testq	%rax, %rax
    a390:      	je	0xa397 <generic_usdt_actions+0xd47>
    a392:      	lock
    a393:      	incq	(%rax,%r12,8)
    a397:      	jmp	0x9830 <generic_usdt_actions+0x1e0>
    a39c:      	cmpb	$0x0, 0x3c(%rsp)
    a3a1:      	je	0xa3c0 <generic_usdt_actions+0xd70>
    a3a3:      	movq	(%rip), %rsi            # 0xa3aa <generic_usdt_actions+0xd5a>
    a3aa:      	movl	$0x5, %ecx
    a3af:      	movl	$0xc, %eax
    a3b4:      	movq	0x40(%rsp), %rdi
    a3b9:      	movl	$0x5, %edx
    a3be:      	callq	*%rax
    a3c0:      	xorl	%eax, %eax
    a3c2:      	addq	$0x118, %rsp            # imm = 0x118
    a3c9:      	popq	%rbx
    a3ca:      	popq	%r12
    a3cc:      	popq	%r13
    a3ce:      	popq	%r14
    a3d0:      	popq	%r15
    a3d2:      	popq	%rbp
    a3d3:      	retq
    a3d4:      	nopw	%cs:(%rax,%rax)

000000000000a3e0 <generic_usdt_output>:
    a3e0:      	pushq	%rbp
    a3e1:      	pushq	%r15
    a3e3:      	pushq	%r14
    a3e5:      	pushq	%r13
    a3e7:      	pushq	%r12
    a3e9:      	pushq	%rbx
    a3ea:      	subq	$0x78, %rsp
    a3ee:      	movq	%rdi, %rbx
    a3f1:      	movl	$0x0, 0x14(%rsp)
    a3f9:      	movq	(%rip), %rdi            # 0xa400 <generic_usdt_output+0x20>
    a400:      	leaq	0x14(%rsp), %rsi
    a405:      	movl	$0x1, %eax
    a40a:      	callq	*%rax
    a40c:      	testq	%rax, %rax
    a40f:      	je	0xa8ea <generic_usdt_output+0x50a>
    a415:      	movq	%rax, %r14
    a418:      	cmpq	$0x0, 0x5ee8(%rax)
    a420:      	je	0xa734 <generic_usdt_output+0x354>
    a426:      	movl	$0xe, %eax
    a42b:      	callq	*%rax
    a42d:      	movq	%rax, %r15
    a430:      	shrq	$0x20, %r15
    a434:      	movl	$0x23, %eax
    a439:      	callq	*%rax
    a43b:      	movq	%rax, %r12
    a43e:      	movl	%r15d, 0x28(%rsp)
    a443:      	movq	(%rip), %rdi            # 0xa44a <generic_usdt_output+0x6a>
    a44a:      	leaq	0x28(%rsp), %rsi
    a44f:      	movl	$0x1, %eax
    a454:      	callq	*%rax
    a456:      	testq	%rax, %rax
    a459:      	je	0xa734 <generic_usdt_output+0x354>
    a45f:      	movq	%rax, %r15
    a462:      	leaq	0xd70(%r12), %rdx
    a46a:      	leaq	0x70(%rsp), %rdi
    a46f:      	movl	$0x8, %ecx
    a474:      	movl	$0x4, %eax
    a479:      	leaq	0x28(%r15), %r13
    a47d:      	movl	$0x4, %ebp
    a482:      	movl	$0x8, %esi
    a487:      	callq	*%rax
    a489:      	movq	0x70(%rsp), %rcx
    a48e:      	leaq	0x28(%rsp), %rdi
    a493:      	movl	$0x48, %edx
    a498:      	movl	$0x4, %eax
    a49d:      	movq	0x70(%rsp), %rdx
    a4a2:      	movl	$0x48, %esi
    a4a7:      	callq	*%rax
    a4a9:      	movl	$0x218, %edx            # imm = 0x218
    a4ae:      	movq	0x30(%rsp), %rcx
    a4b3:      	addq	%rdx, %rcx
    a4b6:      	movl	$0x4, %esi
    a4bb:      	movl	$0x4, %eax
    a4c0:      	addq	0x30(%rsp), %rdx
    a4c5:      	movq	%r13, %rdi
    a4c8:      	movl	$0x4, %esi
    a4cd:      	callq	*%rax
    a4cf:      	leaq	0x2c(%r15), %rdi
    a4d3:      	movl	$0x4d8, %edx            # imm = 0x4D8
    a4d8:      	movq	0x38(%rsp), %rcx
    a4dd:      	addq	%rdx, %rcx
    a4e0:      	movl	$0x4, %esi
    a4e5:      	movl	$0x4, %eax
    a4ea:      	addq	0x38(%rsp), %rdx
    a4ef:      	movl	$0x4, %esi
    a4f4:      	callq	*%rax
    a4f6:      	leaq	0x30(%r15), %rdi
    a4fa:      	movq	0x40(%rsp), %rcx
    a4ff:      	addq	$0x58, %rcx
    a503:      	movl	$0x4, %edx
    a508:      	movl	$0x4, %eax
    a50d:      	movq	0x40(%rsp), %rdx
    a512:      	addq	$0x58, %rdx
    a516:      	movl	$0x4, %esi
    a51b:      	callq	*%rax
    a51d:      	movq	$0x0, 0x8(%rsp)
    a526:      	leaq	0xb58(%r12), %rdx
    a52e:      	leaq	0x8(%rsp), %rdi
    a533:      	movl	$0x8, %ecx
    a538:      	movl	$0x4, %eax
    a53d:      	movl	$0x8, %esi
    a542:      	callq	*%rax
    a544:      	movq	0x8(%rsp), %rcx
    a549:      	testq	%rcx, %rcx
    a54c:      	je	0xa5e2 <generic_usdt_output+0x202>
    a552:      	movl	$0x0, 0x10(%rsp)
    a55a:      	addq	$0x4, %rcx
    a55e:      	leaq	0x10(%rsp), %rdi
    a563:      	movl	$0x4, %eax
    a568:      	movq	0x8(%rsp), %rdx
    a56d:      	addq	$0x4, %rdx
    a571:      	movl	$0x4, %esi
    a576:      	callq	*%rax
    a578:      	movq	0x8(%rsp), %rax
    a57d:      	movslq	0x10(%rsp), %rcx
    a582:      	shlq	$0x4, %rcx
    a586:      	addq	%rax, %rcx
    a589:      	addq	$0x80, %rcx
    a590:      	leaq	0x18(%rsp), %rdi
    a595:      	movl	$0x10, %edx
    a59a:      	movl	$0x4, %eax
    a59f:      	movq	0x8(%rsp), %rcx
    a5a4:      	movslq	0x10(%rsp), %rdx
    a5a9:      	shlq	$0x4, %rdx
    a5ad:      	addq	%rcx, %rdx
    a5b0:      	addq	$0x80, %rdx
    a5b7:      	movl	$0x10, %esi
    a5bc:      	callq	*%rax
    a5be:      	leaq	0x34(%r15), %rdi
    a5c2:      	movl	$0x158, %edx            # imm = 0x158
    a5c7:      	movq	0x20(%rsp), %rcx
    a5cc:      	addq	%rdx, %rcx
    a5cf:      	movl	$0x4, %eax
    a5d4:      	addq	0x20(%rsp), %rdx
    a5d9:      	movl	$0x4, %esi
    a5de:      	callq	*%rax
    a5e0:      	jmp	0xa5ea <generic_usdt_output+0x20a>
    a5e2:      	movl	$0x0, 0x34(%r15)
    a5ea:      	leaq	0x38(%r15), %rdi
    a5ee:      	movl	$0x158, %r13d           # imm = 0x158
    a5f4:      	movq	0x48(%rsp), %rcx
    a5f9:      	addq	%r13, %rcx
    a5fc:      	movl	$0x4, %edx
    a601:      	movl	$0x4, %eax
    a606:      	movq	0x48(%rsp), %rdx
    a60b:      	addq	%r13, %rdx
    a60e:      	movl	$0x4, %esi
    a613:      	callq	*%rax
    a615:      	leaq	0x3c(%r15), %rdi
    a619:      	movl	$0x118, %edx            # imm = 0x118
    a61e:      	movq	0x50(%rsp), %rcx
    a623:      	addq	%rdx, %rcx
    a626:      	movl	$0x4, %esi
    a62b:      	movl	$0x4, %eax
    a630:      	addq	0x50(%rsp), %rdx
    a635:      	movl	$0x4, %esi
    a63a:      	callq	*%rax
    a63c:      	leaq	0x40(%r15), %rdi
    a640:      	movl	$0x98, %ebp
    a645:      	movq	0x58(%rsp), %rcx
    a64a:      	addq	%rbp, %rcx
    a64d:      	movl	$0x4, %edx
    a652:      	movl	$0x4, %eax
    a657:      	movq	0x58(%rsp), %rdx
    a65c:      	addq	%rbp, %rdx
    a65f:      	movl	$0x4, %esi
    a664:      	callq	*%rax
    a666:      	leaq	0x44(%r15), %rdi
    a66a:      	movq	0x60(%rsp), %rcx
    a66f:      	addq	%rbp, %rcx
    a672:      	movl	$0x4, %edx
    a677:      	movl	$0x4, %eax
    a67c:      	addq	0x60(%rsp), %rbp
    a681:      	movl	$0x4, %esi
    a686:      	movq	%rbp, %rdx
    a689:      	callq	*%rax
    a68b:      	leaq	0x48(%r15), %rdi
    a68f:      	movq	0x68(%rsp), %rcx
    a694:      	addq	$0x58, %rcx
    a698:      	movl	$0x4, %edx
    a69d:      	movl	$0x4, %eax
    a6a2:      	movq	0x68(%rsp), %rdx
    a6a7:      	addq	$0x58, %rdx
    a6ab:      	movl	$0x4, %esi
    a6b0:      	callq	*%rax
    a6b2:      	movq	$0x0, 0x18(%rsp)
    a6bb:      	movq	$0x0, 0x8(%rsp)
    a6c4:      	addq	$0xd00, %r12            # imm = 0xD00
    a6cb:      	leaq	0x18(%rsp), %rdi
    a6d0:      	movl	$0x8, %ecx
    a6d5:      	movl	$0x4, %eax
    a6da:      	movl	$0x8, %esi
    a6df:      	movq	%r12, %rdx
    a6e2:      	callq	*%rax
    a6e4:      	movl	$0x90, %edx
    a6e9:      	movq	0x18(%rsp), %rcx
    a6ee:      	addq	%rdx, %rcx
    a6f1:      	leaq	0x8(%rsp), %rdi
    a6f6:      	movl	$0x8, %esi
    a6fb:      	movl	$0x4, %eax
    a700:      	addq	0x18(%rsp), %rdx
    a705:      	movl	$0x8, %esi
    a70a:      	callq	*%rax
    a70c:      	addq	$0x4c, %r15
    a710:      	movq	0x8(%rsp), %rcx
    a715:      	addq	%r13, %rcx
    a718:      	movl	$0x4, %edx
    a71d:      	movl	$0x4, %eax
    a722:      	addq	0x8(%rsp), %r13
    a727:      	movq	%r15, %rdi
    a72a:      	movl	$0x4, %esi
    a72f:      	movq	%r13, %rdx
    a732:      	callq	*%rax
    a734:      	cmpq	$0x0, 0x5ef0(%r14)
    a73c:      	je	0xa7f5 <generic_usdt_output+0x415>
    a742:      	movl	$0xe, %eax
    a747:      	callq	*%rax
    a749:      	movq	%rax, %r15
    a74c:      	shrq	$0x20, %r15
    a750:      	movl	$0x23, %eax
    a755:      	callq	*%rax
    a757:      	movq	%rax, %r12
    a75a:      	movl	%r15d, 0x28(%rsp)
    a75f:      	movq	(%rip), %rdi            # 0xa766 <generic_usdt_output+0x386>
    a766:      	leaq	0x28(%rsp), %rsi
    a76b:      	movl	$0x1, %eax
    a770:      	callq	*%rax
    a772:      	testq	%rax, %rax
    a775:      	je	0xa7f5 <generic_usdt_output+0x415>
    a777:      	leaq	0x50(%rax), %r15
    a77b:      	addq	$0xd00, %r12            # imm = 0xD00
    a782:      	leaq	0x28(%rsp), %rdi
    a787:      	movl	$0x8, %ecx
    a78c:      	movq	%rax, %r13
    a78f:      	movl	$0x4, %eax
    a794:      	movl	$0x8, %esi
    a799:      	movq	%r12, %rdx
    a79c:      	callq	*%rax
    a79e:      	movq	0x28(%rsp), %r12
    a7a3:      	leaq	0x58(%r13), %rdi
    a7a7:      	leaq	0x40(%r12), %rdx
    a7ac:      	movl	$0x8, %ecx
    a7b1:      	movl	$0x4, %eax
    a7b6:      	movl	$0x8, %esi
    a7bb:      	callq	*%rax
    a7bd:      	addq	$0x60, %r13
    a7c1:      	leaq	0x30(%r12), %rdx
    a7c6:      	movl	$0x8, %ecx
    a7cb:      	movl	$0x4, %eax
    a7d0:      	movq	%r13, %rdi
    a7d3:      	movl	$0x8, %esi
    a7d8:      	callq	*%rax
    a7da:      	addq	$0x38, %r12
    a7de:      	movl	$0x8, %ecx
    a7e3:      	movl	$0x4, %eax
    a7e8:      	movq	%r15, %rdi
    a7eb:      	movl	$0x8, %esi
    a7f0:      	movq	%r12, %rdx
    a7f3:      	callq	*%rax
    a7f5:      	movl	$0x90, %eax
    a7fa:      	addl	0x4(%r14), %eax
    a7fe:      	andl	$0x7fff, %eax           # imm = 0x7FFF
    a803:      	cmpl	$0x2328, %eax           # imm = 0x2328
    a808:      	movl	$0x2328, %r8d           # imm = 0x2328
    a80e:      	cmovbl	%eax, %r8d
    a812:      	movq	(%rip), %rsi            # 0xa819 <generic_usdt_output+0x439>
    a819:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    a81e:      	movl	$0x19, %eax
    a823:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    a828:      	movq	%rbx, %rdi
    a82b:      	movq	%r14, %rcx
    a82e:      	callq	*%rax
    a830:      	testq	%rax, %rax
    a833:      	js	0xa863 <generic_usdt_output+0x483>
    a835:      	movl	$0x0, 0x28(%rsp)
    a83d:      	movq	(%rip), %rdi            # 0xa844 <generic_usdt_output+0x464>
    a844:      	leaq	0x28(%rsp), %rsi
    a849:      	movl	$0x1, %eax
    a84e:      	callq	*%rax
    a850:      	testq	%rax, %rax
    a853:      	je	0xa8ea <generic_usdt_output+0x50a>
    a859:      	lock
    a85a:      	incq	0x8(%rax)
    a85e:      	jmp	0xa8ea <generic_usdt_output+0x50a>
    a863:      	movq	%rax, %rbx
    a866:      	movl	$0x0, 0x28(%rsp)
    a86e:      	movq	(%rip), %rdi            # 0xa875 <generic_usdt_output+0x495>
    a875:      	leaq	0x28(%rsp), %rsi
    a87a:      	movl	$0x1, %eax
    a87f:      	callq	*%rax
    a881:      	testq	%rax, %rax
    a884:      	je	0xa8ea <generic_usdt_output+0x50a>
    a886:      	cmpq	$-0xc, %rbx
    a88a:      	jg	0xa8a6 <generic_usdt_output+0x4c6>
    a88c:      	cmpq	$-0x1c, %rbx
    a890:      	je	0xa8c0 <generic_usdt_output+0x4e0>
    a892:      	cmpq	$-0x16, %rbx
    a896:      	je	0xa8d8 <generic_usdt_output+0x4f8>
    a898:      	cmpq	$-0x10, %rbx
    a89c:      	jne	0xa8d0 <generic_usdt_output+0x4f0>
    a89e:      	addq	$0x638, %rax            # imm = 0x638
    a8a4:      	jmp	0xa8e6 <generic_usdt_output+0x506>
    a8a6:      	cmpq	$-0xb, %rbx
    a8aa:      	je	0xa8c8 <generic_usdt_output+0x4e8>
    a8ac:      	cmpq	$-0x7, %rbx
    a8b0:      	je	0xa8e0 <generic_usdt_output+0x500>
    a8b2:      	cmpq	$-0x2, %rbx
    a8b6:      	jne	0xa8d0 <generic_usdt_output+0x4f0>
    a8b8:      	addq	$0x628, %rax            # imm = 0x628
    a8be:      	jmp	0xa8e6 <generic_usdt_output+0x506>
    a8c0:      	addq	$0x648, %rax            # imm = 0x648
    a8c6:      	jmp	0xa8e6 <generic_usdt_output+0x506>
    a8c8:      	addq	$0x650, %rax            # imm = 0x650
    a8ce:      	jmp	0xa8e6 <generic_usdt_output+0x506>
    a8d0:      	addq	$0x620, %rax            # imm = 0x620
    a8d6:      	jmp	0xa8e6 <generic_usdt_output+0x506>
    a8d8:      	addq	$0x640, %rax            # imm = 0x640
    a8de:      	jmp	0xa8e6 <generic_usdt_output+0x506>
    a8e0:      	addq	$0x630, %rax            # imm = 0x630
    a8e6:      	lock
    a8e7:      	incq	(%rax)
    a8ea:      	xorl	%eax, %eax
    a8ec:      	addq	$0x78, %rsp
    a8f0:      	popq	%rbx
    a8f1:      	popq	%r12
    a8f3:      	popq	%r13
    a8f5:      	popq	%r14
    a8f7:      	popq	%r15
    a8f9:      	popq	%rbp
    a8fa:      	retq
    a8fb:      	nopl	(%rax,%rax)

000000000000a900 <generic_usdt_path>:
    a900:      	pushq	%rbp
    a901:      	pushq	%r15
    a903:      	pushq	%r14
    a905:      	pushq	%r13
    a907:      	pushq	%r12
    a909:      	pushq	%rbx
    a90a:      	subq	$0x88, %rsp
    a911:      	movq	%rdi, %rbp
    a914:      	movl	$0x0, 0x70(%rsp)
    a91c:      	movq	(%rip), %rdi            # 0xa923 <generic_usdt_path+0x23>
    a923:      	leaq	0x70(%rsp), %rsi
    a928:      	movl	$0x1, %eax
    a92d:      	callq	*%rax
    a92f:      	testq	%rax, %rax
    a932:      	je	0x16779 <generic_usdt_path+0xbe79>
    a938:      	movq	%rax, %r14
    a93b:      	movl	0x6420(%rax), %eax
    a941:      	cmpl	$0x1, %eax
    a944:      	je	0xa9e6 <generic_usdt_path+0xe6>
    a94a:      	testl	%eax, %eax
    a94c:      	jne	0x16779 <generic_usdt_path+0xbe79>
    a952:      	movq	0x6440(%r14), %r12
    a959:      	movl	$0x0, 0x10(%rsp)
    a961:      	movq	(%rip), %rdi            # 0xa968 <generic_usdt_path+0x68>
    a968:      	leaq	0x10(%rsp), %rsi
    a96d:      	movl	$0x1, %eax
    a972:      	callq	*%rax
    a974:      	testq	%rax, %rax
    a977:      	je	0x16779 <generic_usdt_path+0xbe79>
    a97d:      	movq	%rax, %r15
    a980:      	addq	$0x8, %r12
    a984:      	leaq	0x58(%rsp), %rdi
    a989:      	movl	$0x8, %ecx
    a98e:      	movl	$0x4, %eax
    a993:      	movl	$0x8, %esi
    a998:      	movq	%r12, %rdx
    a99b:      	callq	*%rax
    a99d:      	testq	%rax, %rax
    a9a0:      	je	0x16429 <generic_usdt_path+0xbb29>
    a9a6:      	negl	%eax
    a9a8:      	movw	%ax, 0x18(%rsp)
    a9ad:      	movw	$0x6, 0x1a(%rsp)
    a9b4:      	movabsq	$0x40000002c, %rax      # imm = 0x40000002C
    a9be:      	movq	%rax, 0x1c(%rsp)
    a9c3:      	movq	(%rip), %rdi            # 0xa9ca <generic_usdt_path+0xca>
    a9ca:      	leaq	0x18(%rsp), %rsi
    a9cf:      	movl	$0x1, %eax
    a9d4:      	callq	*%rax
    a9d6:      	testq	%rax, %rax
    a9d9:      	je	0x16408 <generic_usdt_path+0xbb08>
    a9df:      	incl	(%rax)
    a9e1:      	jmp	0x16429 <generic_usdt_path+0xbb29>
    a9e6:      	movq	0x6448(%r14), %rax
    a9ed:      	movq	%rax, 0x18(%rsp)
    a9f2:      	movq	0x6450(%r14), %rax
    a9f9:      	movq	%rax, 0x20(%rsp)
    a9fe:      	movq	$0x0, 0x28(%rsp)
    aa07:      	movq	0x6458(%r14), %rax
    aa0e:      	movq	%rax, 0x30(%rsp)
    aa13:      	movq	0x6460(%r14), %rax
    aa1a:      	movq	%rax, 0x38(%rsp)
    aa1f:      	movq	0x6468(%r14), %rax
    aa26:      	movq	%rax, 0x40(%rsp)
    aa2b:      	movq	$0x0, 0x48(%rsp)
    aa34:      	movl	$0x0, 0x50(%rsp)
    aa3c:      	movb	$0x0, 0x54(%rsp)
    aa41:      	movl	$0x0, 0x74(%rsp)
    aa49:      	movq	(%rip), %rdi            # 0xaa50 <generic_usdt_path+0x150>
    aa50:      	leaq	0x74(%rsp), %rsi
    aa55:      	movl	$0x1, %eax
    aa5a:      	callq	*%rax
    aa5c:      	testq	%rax, %rax
    aa5f:      	je	0x16779 <generic_usdt_path+0xbe79>
    aa65:      	movq	%rbp, 0x78(%rsp)
    aa6a:      	movq	%rax, 0x28(%rsp)
    aa6f:      	movl	0x6424(%r14), %edx
    aa76:      	movl	%edx, %ecx
    aa78:      	andl	$0xfff, %ecx            # imm = 0xFFF
    aa7e:      	movq	%rax, %rsi
    aa81:      	movq	%rax, 0x80(%rsp)
    aa89:      	addq	%rax, %rcx
    aa8c:      	movq	%rcx, 0x48(%rsp)
    aa91:      	movl	%edx, 0x50(%rsp)
    aa95:      	movl	$0x200, %eax            # imm = 0x200
    aa9a:      	movl	$0x8, %r13d
    aaa0:      	movq	%rsp, %rbp
    aaa3:      	movl	%eax, 0x6c(%rsp)
    aaa7:      	movq	0x30(%rsp), %r12
    aaac:      	movq	0x38(%rsp), %rdx
    aab1:      	movq	0x40(%rsp), %r15
    aab6:      	cmpq	0x18(%rsp), %r12
    aabb:      	jne	0xaac8 <generic_usdt_path+0x1c8>
    aabd:      	cmpq	0x20(%rsp), %rdx
    aac2:      	je	0x1636d <generic_usdt_path+0xba6d>
    aac8:      	movl	$0x4, %eax
    aacd:      	leaq	0x10(%rsp), %rdi
    aad2:      	movl	$0x8, %esi
    aad7:      	callq	*%rax
    aad9:      	cmpq	0x10(%rsp), %r12
    aade:      	je	0xabdd <generic_usdt_path+0x2dd>
    aae4:      	leaq	0x18(%r12), %rbx
    aae9:      	movl	$0x4, %eax
    aaee:      	movq	%rbp, %rdi
    aaf1:      	movl	$0x8, %esi
    aaf6:      	movq	%rbx, %rdx
    aaf9:      	callq	*%rax
    aafb:      	cmpq	%r12, (%rsp)
    aaff:      	je	0xabdd <generic_usdt_path+0x2dd>
    ab05:      	movl	$0x4, %eax
    ab0a:      	leaq	0x8(%rsp), %rdi
    ab0f:      	movl	$0x8, %esi
    ab14:      	movq	%rbx, %rdx
    ab17:      	callq	*%rax
    ab19:      	addq	$0x20, %r12
    ab1d:      	movl	$0x4, %eax
    ab22:      	leaq	0x58(%rsp), %rdi
    ab27:      	movl	$0x10, %ecx
    ab2c:      	movl	$0x10, %esi
    ab31:      	movq	%r12, %rdx
    ab34:      	callq	*%rax
    ab36:      	movq	0x28(%rsp), %rbx
    ab3b:      	movq	0x48(%rsp), %rax
    ab40:      	movl	0x5c(%rsp), %r15d
    ab45:      	subq	%rbx, %rax
    ab48:      	movl	0x50(%rsp), %r12d
    ab4d:      	movl	%r15d, %edx
    ab50:      	subl	%r12d, %edx
    ab53:      	movl	$0x0, %ecx
    ab58:      	cmovbl	%ecx, %edx
    ab5b:      	addq	0x60(%rsp), %rdx
    ab60:      	xorl	%esi, %esi
    ab62:      	cmpl	%r15d, %r12d
    ab65:      	seta	%sil
    ab69:      	movl	%r15d, %ecx
    ab6c:      	cmovbl	%r12d, %ecx
    ab70:      	addl	%ecx, %esi
    ab72:      	movl	%r12d, %edi
    ab75:      	subl	%esi, %edi
    ab77:      	movl	%edi, 0x50(%rsp)
    ab7b:      	subq	%rsi, %rax
    ab7e:      	jb	0x16372 <generic_usdt_path+0xba72>
    ab84:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ab8a:      	ja	0x16372 <generic_usdt_path+0xba72>
    ab90:      	cmpl	%r15d, %r12d
    ab93:      	jbe	0xab99 <generic_usdt_path+0x299>
    ab95:      	movb	$0x2f, (%rbx,%rax)
    ab99:      	xorl	%edi, %edi
    ab9b:      	cmpl	%r15d, %r12d
    ab9e:      	seta	%dil
    aba2:      	movzbl	%cl, %esi
    aba5:      	addq	%rax, %rbx
    aba8:      	addq	%rbx, %rdi
    abab:      	movl	$0x4, %eax
    abb0:      	callq	*%rax
    abb2:      	movq	%rbx, 0x48(%rsp)
    abb7:      	cmpl	%r15d, %r12d
    abba:      	jbe	0x16372 <generic_usdt_path+0xba72>
    abc0:      	movq	0x8(%rsp), %r12
    abc5:      	movq	%r12, 0x30(%rsp)
    abca:      	movq	0x38(%rsp), %rdx
    abcf:      	movq	0x40(%rsp), %r15
    abd4:      	cmpq	0x18(%rsp), %r12
    abd9:      	je	0xac35 <generic_usdt_path+0x335>
    abdb:      	jmp	0xac40 <generic_usdt_path+0x340>
    abdd:      	leaq	0x10(%r15), %rdx
    abe1:      	movl	$0x4, %eax
    abe6:      	movq	%rbp, %rdi
    abe9:      	movl	$0x8, %esi
    abee:      	callq	*%rax
    abf0:      	movq	0x40(%rsp), %rax
    abf5:      	cmpq	(%rsp), %rax
    abf9:      	je	0x1636d <generic_usdt_path+0xba6d>
    abff:      	addq	$0x18, %r15
    ac03:      	movl	$0x4, %eax
    ac08:      	leaq	0x30(%rsp), %rdi
    ac0d:      	movl	$0x8, %esi
    ac12:      	movq	%r15, %rdx
    ac15:      	callq	*%rax
    ac17:      	movq	(%rsp), %r15
    ac1b:      	movq	%r15, 0x40(%rsp)
    ac20:      	leaq	0x20(%r15), %rdx
    ac24:      	movq	%rdx, 0x38(%rsp)
    ac29:      	movq	0x30(%rsp), %r12
    ac2e:      	cmpq	0x18(%rsp), %r12
    ac33:      	jne	0xac40 <generic_usdt_path+0x340>
    ac35:      	cmpq	0x20(%rsp), %rdx
    ac3a:      	je	0x1636d <generic_usdt_path+0xba6d>
    ac40:      	movl	$0x4, %eax
    ac45:      	leaq	0x10(%rsp), %rdi
    ac4a:      	movl	$0x8, %esi
    ac4f:      	callq	*%rax
    ac51:      	cmpq	0x10(%rsp), %r12
    ac56:      	je	0xad55 <generic_usdt_path+0x455>
    ac5c:      	leaq	0x18(%r12), %rbx
    ac61:      	movl	$0x4, %eax
    ac66:      	movq	%rbp, %rdi
    ac69:      	movl	$0x8, %esi
    ac6e:      	movq	%rbx, %rdx
    ac71:      	callq	*%rax
    ac73:      	cmpq	%r12, (%rsp)
    ac77:      	je	0xad55 <generic_usdt_path+0x455>
    ac7d:      	movl	$0x4, %eax
    ac82:      	leaq	0x8(%rsp), %rdi
    ac87:      	movl	$0x8, %esi
    ac8c:      	movq	%rbx, %rdx
    ac8f:      	callq	*%rax
    ac91:      	addq	$0x20, %r12
    ac95:      	movl	$0x4, %eax
    ac9a:      	leaq	0x58(%rsp), %rdi
    ac9f:      	movl	$0x10, %ecx
    aca4:      	movl	$0x10, %esi
    aca9:      	movq	%r12, %rdx
    acac:      	callq	*%rax
    acae:      	movq	0x28(%rsp), %rbx
    acb3:      	movq	0x48(%rsp), %rax
    acb8:      	movl	0x5c(%rsp), %r15d
    acbd:      	subq	%rbx, %rax
    acc0:      	movl	0x50(%rsp), %r12d
    acc5:      	movl	%r15d, %edx
    acc8:      	subl	%r12d, %edx
    accb:      	movl	$0x0, %ecx
    acd0:      	cmovbl	%ecx, %edx
    acd3:      	addq	0x60(%rsp), %rdx
    acd8:      	xorl	%esi, %esi
    acda:      	cmpl	%r15d, %r12d
    acdd:      	seta	%sil
    ace1:      	movl	%r15d, %ecx
    ace4:      	cmovbl	%r12d, %ecx
    ace8:      	addl	%ecx, %esi
    acea:      	movl	%r12d, %edi
    aced:      	subl	%esi, %edi
    acef:      	movl	%edi, 0x50(%rsp)
    acf3:      	subq	%rsi, %rax
    acf6:      	jb	0x16372 <generic_usdt_path+0xba72>
    acfc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ad02:      	ja	0x16372 <generic_usdt_path+0xba72>
    ad08:      	cmpl	%r15d, %r12d
    ad0b:      	jbe	0xad11 <generic_usdt_path+0x411>
    ad0d:      	movb	$0x2f, (%rbx,%rax)
    ad11:      	xorl	%edi, %edi
    ad13:      	cmpl	%r15d, %r12d
    ad16:      	seta	%dil
    ad1a:      	movzbl	%cl, %esi
    ad1d:      	addq	%rax, %rbx
    ad20:      	addq	%rbx, %rdi
    ad23:      	movl	$0x4, %eax
    ad28:      	callq	*%rax
    ad2a:      	movq	%rbx, 0x48(%rsp)
    ad2f:      	cmpl	%r15d, %r12d
    ad32:      	jbe	0x16372 <generic_usdt_path+0xba72>
    ad38:      	movq	0x8(%rsp), %r12
    ad3d:      	movq	%r12, 0x30(%rsp)
    ad42:      	movq	0x38(%rsp), %rdx
    ad47:      	movq	0x40(%rsp), %r15
    ad4c:      	cmpq	0x18(%rsp), %r12
    ad51:      	je	0xadad <generic_usdt_path+0x4ad>
    ad53:      	jmp	0xadb8 <generic_usdt_path+0x4b8>
    ad55:      	leaq	0x10(%r15), %rdx
    ad59:      	movl	$0x4, %eax
    ad5e:      	movq	%rbp, %rdi
    ad61:      	movl	$0x8, %esi
    ad66:      	callq	*%rax
    ad68:      	movq	0x40(%rsp), %rax
    ad6d:      	cmpq	(%rsp), %rax
    ad71:      	je	0x1636d <generic_usdt_path+0xba6d>
    ad77:      	addq	$0x18, %r15
    ad7b:      	movl	$0x4, %eax
    ad80:      	leaq	0x30(%rsp), %rdi
    ad85:      	movl	$0x8, %esi
    ad8a:      	movq	%r15, %rdx
    ad8d:      	callq	*%rax
    ad8f:      	movq	(%rsp), %r15
    ad93:      	movq	%r15, 0x40(%rsp)
    ad98:      	leaq	0x20(%r15), %rdx
    ad9c:      	movq	%rdx, 0x38(%rsp)
    ada1:      	movq	0x30(%rsp), %r12
    ada6:      	cmpq	0x18(%rsp), %r12
    adab:      	jne	0xadb8 <generic_usdt_path+0x4b8>
    adad:      	cmpq	0x20(%rsp), %rdx
    adb2:      	je	0x1636d <generic_usdt_path+0xba6d>
    adb8:      	movl	$0x4, %eax
    adbd:      	leaq	0x10(%rsp), %rdi
    adc2:      	movl	$0x8, %esi
    adc7:      	callq	*%rax
    adc9:      	cmpq	0x10(%rsp), %r12
    adce:      	je	0xaecd <generic_usdt_path+0x5cd>
    add4:      	leaq	0x18(%r12), %rbx
    add9:      	movl	$0x4, %eax
    adde:      	movq	%rbp, %rdi
    ade1:      	movl	$0x8, %esi
    ade6:      	movq	%rbx, %rdx
    ade9:      	callq	*%rax
    adeb:      	cmpq	%r12, (%rsp)
    adef:      	je	0xaecd <generic_usdt_path+0x5cd>
    adf5:      	movl	$0x4, %eax
    adfa:      	leaq	0x8(%rsp), %rdi
    adff:      	movl	$0x8, %esi
    ae04:      	movq	%rbx, %rdx
    ae07:      	callq	*%rax
    ae09:      	addq	$0x20, %r12
    ae0d:      	movl	$0x4, %eax
    ae12:      	leaq	0x58(%rsp), %rdi
    ae17:      	movl	$0x10, %ecx
    ae1c:      	movl	$0x10, %esi
    ae21:      	movq	%r12, %rdx
    ae24:      	callq	*%rax
    ae26:      	movq	0x28(%rsp), %rbx
    ae2b:      	movq	0x48(%rsp), %rax
    ae30:      	movl	0x5c(%rsp), %r15d
    ae35:      	subq	%rbx, %rax
    ae38:      	movl	0x50(%rsp), %r12d
    ae3d:      	movl	%r15d, %edx
    ae40:      	subl	%r12d, %edx
    ae43:      	movl	$0x0, %ecx
    ae48:      	cmovbl	%ecx, %edx
    ae4b:      	addq	0x60(%rsp), %rdx
    ae50:      	xorl	%esi, %esi
    ae52:      	cmpl	%r15d, %r12d
    ae55:      	seta	%sil
    ae59:      	movl	%r15d, %ecx
    ae5c:      	cmovbl	%r12d, %ecx
    ae60:      	addl	%ecx, %esi
    ae62:      	movl	%r12d, %edi
    ae65:      	subl	%esi, %edi
    ae67:      	movl	%edi, 0x50(%rsp)
    ae6b:      	subq	%rsi, %rax
    ae6e:      	jb	0x16372 <generic_usdt_path+0xba72>
    ae74:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ae7a:      	ja	0x16372 <generic_usdt_path+0xba72>
    ae80:      	cmpl	%r15d, %r12d
    ae83:      	jbe	0xae89 <generic_usdt_path+0x589>
    ae85:      	movb	$0x2f, (%rbx,%rax)
    ae89:      	xorl	%edi, %edi
    ae8b:      	cmpl	%r15d, %r12d
    ae8e:      	seta	%dil
    ae92:      	movzbl	%cl, %esi
    ae95:      	addq	%rax, %rbx
    ae98:      	addq	%rbx, %rdi
    ae9b:      	movl	$0x4, %eax
    aea0:      	callq	*%rax
    aea2:      	movq	%rbx, 0x48(%rsp)
    aea7:      	cmpl	%r15d, %r12d
    aeaa:      	jbe	0x16372 <generic_usdt_path+0xba72>
    aeb0:      	movq	0x8(%rsp), %r12
    aeb5:      	movq	%r12, 0x30(%rsp)
    aeba:      	movq	0x38(%rsp), %rdx
    aebf:      	movq	0x40(%rsp), %r15
    aec4:      	cmpq	0x18(%rsp), %r12
    aec9:      	je	0xaf25 <generic_usdt_path+0x625>
    aecb:      	jmp	0xaf30 <generic_usdt_path+0x630>
    aecd:      	leaq	0x10(%r15), %rdx
    aed1:      	movl	$0x4, %eax
    aed6:      	movq	%rbp, %rdi
    aed9:      	movl	$0x8, %esi
    aede:      	callq	*%rax
    aee0:      	movq	0x40(%rsp), %rax
    aee5:      	cmpq	(%rsp), %rax
    aee9:      	je	0x1636d <generic_usdt_path+0xba6d>
    aeef:      	addq	$0x18, %r15
    aef3:      	movl	$0x4, %eax
    aef8:      	leaq	0x30(%rsp), %rdi
    aefd:      	movl	$0x8, %esi
    af02:      	movq	%r15, %rdx
    af05:      	callq	*%rax
    af07:      	movq	(%rsp), %r15
    af0b:      	movq	%r15, 0x40(%rsp)
    af10:      	leaq	0x20(%r15), %rdx
    af14:      	movq	%rdx, 0x38(%rsp)
    af19:      	movq	0x30(%rsp), %r12
    af1e:      	cmpq	0x18(%rsp), %r12
    af23:      	jne	0xaf30 <generic_usdt_path+0x630>
    af25:      	cmpq	0x20(%rsp), %rdx
    af2a:      	je	0x1636d <generic_usdt_path+0xba6d>
    af30:      	movl	$0x4, %eax
    af35:      	leaq	0x10(%rsp), %rdi
    af3a:      	movl	$0x8, %esi
    af3f:      	callq	*%rax
    af41:      	cmpq	0x10(%rsp), %r12
    af46:      	je	0xb045 <generic_usdt_path+0x745>
    af4c:      	leaq	0x18(%r12), %rbx
    af51:      	movl	$0x4, %eax
    af56:      	movq	%rbp, %rdi
    af59:      	movl	$0x8, %esi
    af5e:      	movq	%rbx, %rdx
    af61:      	callq	*%rax
    af63:      	cmpq	%r12, (%rsp)
    af67:      	je	0xb045 <generic_usdt_path+0x745>
    af6d:      	movl	$0x4, %eax
    af72:      	leaq	0x8(%rsp), %rdi
    af77:      	movl	$0x8, %esi
    af7c:      	movq	%rbx, %rdx
    af7f:      	callq	*%rax
    af81:      	addq	$0x20, %r12
    af85:      	movl	$0x4, %eax
    af8a:      	leaq	0x58(%rsp), %rdi
    af8f:      	movl	$0x10, %ecx
    af94:      	movl	$0x10, %esi
    af99:      	movq	%r12, %rdx
    af9c:      	callq	*%rax
    af9e:      	movq	0x28(%rsp), %rbx
    afa3:      	movq	0x48(%rsp), %rax
    afa8:      	movl	0x5c(%rsp), %r15d
    afad:      	subq	%rbx, %rax
    afb0:      	movl	0x50(%rsp), %r12d
    afb5:      	movl	%r15d, %edx
    afb8:      	subl	%r12d, %edx
    afbb:      	movl	$0x0, %ecx
    afc0:      	cmovbl	%ecx, %edx
    afc3:      	addq	0x60(%rsp), %rdx
    afc8:      	xorl	%esi, %esi
    afca:      	cmpl	%r15d, %r12d
    afcd:      	seta	%sil
    afd1:      	movl	%r15d, %ecx
    afd4:      	cmovbl	%r12d, %ecx
    afd8:      	addl	%ecx, %esi
    afda:      	movl	%r12d, %edi
    afdd:      	subl	%esi, %edi
    afdf:      	movl	%edi, 0x50(%rsp)
    afe3:      	subq	%rsi, %rax
    afe6:      	jb	0x16372 <generic_usdt_path+0xba72>
    afec:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    aff2:      	ja	0x16372 <generic_usdt_path+0xba72>
    aff8:      	cmpl	%r15d, %r12d
    affb:      	jbe	0xb001 <generic_usdt_path+0x701>
    affd:      	movb	$0x2f, (%rbx,%rax)
    b001:      	xorl	%edi, %edi
    b003:      	cmpl	%r15d, %r12d
    b006:      	seta	%dil
    b00a:      	movzbl	%cl, %esi
    b00d:      	addq	%rax, %rbx
    b010:      	addq	%rbx, %rdi
    b013:      	movl	$0x4, %eax
    b018:      	callq	*%rax
    b01a:      	movq	%rbx, 0x48(%rsp)
    b01f:      	cmpl	%r15d, %r12d
    b022:      	jbe	0x16372 <generic_usdt_path+0xba72>
    b028:      	movq	0x8(%rsp), %r12
    b02d:      	movq	%r12, 0x30(%rsp)
    b032:      	movq	0x38(%rsp), %rdx
    b037:      	movq	0x40(%rsp), %r15
    b03c:      	cmpq	0x18(%rsp), %r12
    b041:      	je	0xb09d <generic_usdt_path+0x79d>
    b043:      	jmp	0xb0a8 <generic_usdt_path+0x7a8>
    b045:      	leaq	0x10(%r15), %rdx
    b049:      	movl	$0x4, %eax
    b04e:      	movq	%rbp, %rdi
    b051:      	movl	$0x8, %esi
    b056:      	callq	*%rax
    b058:      	movq	0x40(%rsp), %rax
    b05d:      	cmpq	(%rsp), %rax
    b061:      	je	0x1636d <generic_usdt_path+0xba6d>
    b067:      	addq	$0x18, %r15
    b06b:      	movl	$0x4, %eax
    b070:      	leaq	0x30(%rsp), %rdi
    b075:      	movl	$0x8, %esi
    b07a:      	movq	%r15, %rdx
    b07d:      	callq	*%rax
    b07f:      	movq	(%rsp), %r15
    b083:      	movq	%r15, 0x40(%rsp)
    b088:      	leaq	0x20(%r15), %rdx
    b08c:      	movq	%rdx, 0x38(%rsp)
    b091:      	movq	0x30(%rsp), %r12
    b096:      	cmpq	0x18(%rsp), %r12
    b09b:      	jne	0xb0a8 <generic_usdt_path+0x7a8>
    b09d:      	cmpq	0x20(%rsp), %rdx
    b0a2:      	je	0x1636d <generic_usdt_path+0xba6d>
    b0a8:      	movl	$0x4, %eax
    b0ad:      	leaq	0x10(%rsp), %rdi
    b0b2:      	movl	$0x8, %esi
    b0b7:      	callq	*%rax
    b0b9:      	cmpq	0x10(%rsp), %r12
    b0be:      	je	0xb1bd <generic_usdt_path+0x8bd>
    b0c4:      	leaq	0x18(%r12), %rbx
    b0c9:      	movl	$0x4, %eax
    b0ce:      	movq	%rbp, %rdi
    b0d1:      	movl	$0x8, %esi
    b0d6:      	movq	%rbx, %rdx
    b0d9:      	callq	*%rax
    b0db:      	cmpq	%r12, (%rsp)
    b0df:      	je	0xb1bd <generic_usdt_path+0x8bd>
    b0e5:      	movl	$0x4, %eax
    b0ea:      	leaq	0x8(%rsp), %rdi
    b0ef:      	movl	$0x8, %esi
    b0f4:      	movq	%rbx, %rdx
    b0f7:      	callq	*%rax
    b0f9:      	addq	$0x20, %r12
    b0fd:      	movl	$0x4, %eax
    b102:      	leaq	0x58(%rsp), %rdi
    b107:      	movl	$0x10, %ecx
    b10c:      	movl	$0x10, %esi
    b111:      	movq	%r12, %rdx
    b114:      	callq	*%rax
    b116:      	movq	0x28(%rsp), %rbx
    b11b:      	movq	0x48(%rsp), %rax
    b120:      	movl	0x5c(%rsp), %r15d
    b125:      	subq	%rbx, %rax
    b128:      	movl	0x50(%rsp), %r12d
    b12d:      	movl	%r15d, %edx
    b130:      	subl	%r12d, %edx
    b133:      	movl	$0x0, %ecx
    b138:      	cmovbl	%ecx, %edx
    b13b:      	addq	0x60(%rsp), %rdx
    b140:      	xorl	%esi, %esi
    b142:      	cmpl	%r15d, %r12d
    b145:      	seta	%sil
    b149:      	movl	%r15d, %ecx
    b14c:      	cmovbl	%r12d, %ecx
    b150:      	addl	%ecx, %esi
    b152:      	movl	%r12d, %edi
    b155:      	subl	%esi, %edi
    b157:      	movl	%edi, 0x50(%rsp)
    b15b:      	subq	%rsi, %rax
    b15e:      	jb	0x16372 <generic_usdt_path+0xba72>
    b164:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b16a:      	ja	0x16372 <generic_usdt_path+0xba72>
    b170:      	cmpl	%r15d, %r12d
    b173:      	jbe	0xb179 <generic_usdt_path+0x879>
    b175:      	movb	$0x2f, (%rbx,%rax)
    b179:      	xorl	%edi, %edi
    b17b:      	cmpl	%r15d, %r12d
    b17e:      	seta	%dil
    b182:      	movzbl	%cl, %esi
    b185:      	addq	%rax, %rbx
    b188:      	addq	%rbx, %rdi
    b18b:      	movl	$0x4, %eax
    b190:      	callq	*%rax
    b192:      	movq	%rbx, 0x48(%rsp)
    b197:      	cmpl	%r15d, %r12d
    b19a:      	jbe	0x16372 <generic_usdt_path+0xba72>
    b1a0:      	movq	0x8(%rsp), %r12
    b1a5:      	movq	%r12, 0x30(%rsp)
    b1aa:      	movq	0x38(%rsp), %rdx
    b1af:      	movq	0x40(%rsp), %r15
    b1b4:      	cmpq	0x18(%rsp), %r12
    b1b9:      	je	0xb215 <generic_usdt_path+0x915>
    b1bb:      	jmp	0xb220 <generic_usdt_path+0x920>
    b1bd:      	leaq	0x10(%r15), %rdx
    b1c1:      	movl	$0x4, %eax
    b1c6:      	movq	%rbp, %rdi
    b1c9:      	movl	$0x8, %esi
    b1ce:      	callq	*%rax
    b1d0:      	movq	0x40(%rsp), %rax
    b1d5:      	cmpq	(%rsp), %rax
    b1d9:      	je	0x1636d <generic_usdt_path+0xba6d>
    b1df:      	addq	$0x18, %r15
    b1e3:      	movl	$0x4, %eax
    b1e8:      	leaq	0x30(%rsp), %rdi
    b1ed:      	movl	$0x8, %esi
    b1f2:      	movq	%r15, %rdx
    b1f5:      	callq	*%rax
    b1f7:      	movq	(%rsp), %r15
    b1fb:      	movq	%r15, 0x40(%rsp)
    b200:      	leaq	0x20(%r15), %rdx
    b204:      	movq	%rdx, 0x38(%rsp)
    b209:      	movq	0x30(%rsp), %r12
    b20e:      	cmpq	0x18(%rsp), %r12
    b213:      	jne	0xb220 <generic_usdt_path+0x920>
    b215:      	cmpq	0x20(%rsp), %rdx
    b21a:      	je	0x1636d <generic_usdt_path+0xba6d>
    b220:      	movl	$0x4, %eax
    b225:      	leaq	0x10(%rsp), %rdi
    b22a:      	movl	$0x8, %esi
    b22f:      	callq	*%rax
    b231:      	cmpq	0x10(%rsp), %r12
    b236:      	je	0xb335 <generic_usdt_path+0xa35>
    b23c:      	leaq	0x18(%r12), %rbx
    b241:      	movl	$0x4, %eax
    b246:      	movq	%rbp, %rdi
    b249:      	movl	$0x8, %esi
    b24e:      	movq	%rbx, %rdx
    b251:      	callq	*%rax
    b253:      	cmpq	%r12, (%rsp)
    b257:      	je	0xb335 <generic_usdt_path+0xa35>
    b25d:      	movl	$0x4, %eax
    b262:      	leaq	0x8(%rsp), %rdi
    b267:      	movl	$0x8, %esi
    b26c:      	movq	%rbx, %rdx
    b26f:      	callq	*%rax
    b271:      	addq	$0x20, %r12
    b275:      	movl	$0x4, %eax
    b27a:      	leaq	0x58(%rsp), %rdi
    b27f:      	movl	$0x10, %ecx
    b284:      	movl	$0x10, %esi
    b289:      	movq	%r12, %rdx
    b28c:      	callq	*%rax
    b28e:      	movq	0x28(%rsp), %rbx
    b293:      	movq	0x48(%rsp), %rax
    b298:      	movl	0x5c(%rsp), %r15d
    b29d:      	subq	%rbx, %rax
    b2a0:      	movl	0x50(%rsp), %r12d
    b2a5:      	movl	%r15d, %edx
    b2a8:      	subl	%r12d, %edx
    b2ab:      	movl	$0x0, %ecx
    b2b0:      	cmovbl	%ecx, %edx
    b2b3:      	addq	0x60(%rsp), %rdx
    b2b8:      	xorl	%esi, %esi
    b2ba:      	cmpl	%r15d, %r12d
    b2bd:      	seta	%sil
    b2c1:      	movl	%r15d, %ecx
    b2c4:      	cmovbl	%r12d, %ecx
    b2c8:      	addl	%ecx, %esi
    b2ca:      	movl	%r12d, %edi
    b2cd:      	subl	%esi, %edi
    b2cf:      	movl	%edi, 0x50(%rsp)
    b2d3:      	subq	%rsi, %rax
    b2d6:      	jb	0x16372 <generic_usdt_path+0xba72>
    b2dc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b2e2:      	ja	0x16372 <generic_usdt_path+0xba72>
    b2e8:      	cmpl	%r15d, %r12d
    b2eb:      	jbe	0xb2f1 <generic_usdt_path+0x9f1>
    b2ed:      	movb	$0x2f, (%rbx,%rax)
    b2f1:      	xorl	%edi, %edi
    b2f3:      	cmpl	%r15d, %r12d
    b2f6:      	seta	%dil
    b2fa:      	movzbl	%cl, %esi
    b2fd:      	addq	%rax, %rbx
    b300:      	addq	%rbx, %rdi
    b303:      	movl	$0x4, %eax
    b308:      	callq	*%rax
    b30a:      	movq	%rbx, 0x48(%rsp)
    b30f:      	cmpl	%r15d, %r12d
    b312:      	jbe	0x16372 <generic_usdt_path+0xba72>
    b318:      	movq	0x8(%rsp), %r12
    b31d:      	movq	%r12, 0x30(%rsp)
    b322:      	movq	0x38(%rsp), %rdx
    b327:      	movq	0x40(%rsp), %r15
    b32c:      	cmpq	0x18(%rsp), %r12
    b331:      	je	0xb38d <generic_usdt_path+0xa8d>
    b333:      	jmp	0xb398 <generic_usdt_path+0xa98>
    b335:      	leaq	0x10(%r15), %rdx
    b339:      	movl	$0x4, %eax
    b33e:      	movq	%rbp, %rdi
    b341:      	movl	$0x8, %esi
    b346:      	callq	*%rax
    b348:      	movq	0x40(%rsp), %rax
    b34d:      	cmpq	(%rsp), %rax
    b351:      	je	0x1636d <generic_usdt_path+0xba6d>
    b357:      	addq	$0x18, %r15
    b35b:      	movl	$0x4, %eax
    b360:      	leaq	0x30(%rsp), %rdi
    b365:      	movl	$0x8, %esi
    b36a:      	movq	%r15, %rdx
    b36d:      	callq	*%rax
    b36f:      	movq	(%rsp), %r15
    b373:      	movq	%r15, 0x40(%rsp)
    b378:      	leaq	0x20(%r15), %rdx
    b37c:      	movq	%rdx, 0x38(%rsp)
    b381:      	movq	0x30(%rsp), %r12
    b386:      	cmpq	0x18(%rsp), %r12
    b38b:      	jne	0xb398 <generic_usdt_path+0xa98>
    b38d:      	cmpq	0x20(%rsp), %rdx
    b392:      	je	0x1636d <generic_usdt_path+0xba6d>
    b398:      	movl	$0x4, %eax
    b39d:      	leaq	0x10(%rsp), %rdi
    b3a2:      	movl	$0x8, %esi
    b3a7:      	callq	*%rax
    b3a9:      	cmpq	0x10(%rsp), %r12
    b3ae:      	je	0xb4ad <generic_usdt_path+0xbad>
    b3b4:      	leaq	0x18(%r12), %rbx
    b3b9:      	movl	$0x4, %eax
    b3be:      	movq	%rbp, %rdi
    b3c1:      	movl	$0x8, %esi
    b3c6:      	movq	%rbx, %rdx
    b3c9:      	callq	*%rax
    b3cb:      	cmpq	%r12, (%rsp)
    b3cf:      	je	0xb4ad <generic_usdt_path+0xbad>
    b3d5:      	movl	$0x4, %eax
    b3da:      	leaq	0x8(%rsp), %rdi
    b3df:      	movl	$0x8, %esi
    b3e4:      	movq	%rbx, %rdx
    b3e7:      	callq	*%rax
    b3e9:      	addq	$0x20, %r12
    b3ed:      	movl	$0x4, %eax
    b3f2:      	leaq	0x58(%rsp), %rdi
    b3f7:      	movl	$0x10, %ecx
    b3fc:      	movl	$0x10, %esi
    b401:      	movq	%r12, %rdx
    b404:      	callq	*%rax
    b406:      	movq	0x28(%rsp), %rbx
    b40b:      	movq	0x48(%rsp), %rax
    b410:      	movl	0x5c(%rsp), %r15d
    b415:      	subq	%rbx, %rax
    b418:      	movl	0x50(%rsp), %r12d
    b41d:      	movl	%r15d, %edx
    b420:      	subl	%r12d, %edx
    b423:      	movl	$0x0, %ecx
    b428:      	cmovbl	%ecx, %edx
    b42b:      	addq	0x60(%rsp), %rdx
    b430:      	xorl	%esi, %esi
    b432:      	cmpl	%r15d, %r12d
    b435:      	seta	%sil
    b439:      	movl	%r15d, %ecx
    b43c:      	cmovbl	%r12d, %ecx
    b440:      	addl	%ecx, %esi
    b442:      	movl	%r12d, %edi
    b445:      	subl	%esi, %edi
    b447:      	movl	%edi, 0x50(%rsp)
    b44b:      	subq	%rsi, %rax
    b44e:      	jb	0x16372 <generic_usdt_path+0xba72>
    b454:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b45a:      	ja	0x16372 <generic_usdt_path+0xba72>
    b460:      	cmpl	%r15d, %r12d
    b463:      	jbe	0xb469 <generic_usdt_path+0xb69>
    b465:      	movb	$0x2f, (%rbx,%rax)
    b469:      	xorl	%edi, %edi
    b46b:      	cmpl	%r15d, %r12d
    b46e:      	seta	%dil
    b472:      	movzbl	%cl, %esi
    b475:      	addq	%rax, %rbx
    b478:      	addq	%rbx, %rdi
    b47b:      	movl	$0x4, %eax
    b480:      	callq	*%rax
    b482:      	movq	%rbx, 0x48(%rsp)
    b487:      	cmpl	%r15d, %r12d
    b48a:      	jbe	0x16372 <generic_usdt_path+0xba72>
    b490:      	movq	0x8(%rsp), %r12
    b495:      	movq	%r12, 0x30(%rsp)
    b49a:      	movq	0x38(%rsp), %rdx
    b49f:      	movq	0x40(%rsp), %r15
    b4a4:      	cmpq	0x18(%rsp), %r12
    b4a9:      	je	0xb505 <generic_usdt_path+0xc05>
    b4ab:      	jmp	0xb510 <generic_usdt_path+0xc10>
    b4ad:      	leaq	0x10(%r15), %rdx
    b4b1:      	movl	$0x4, %eax
    b4b6:      	movq	%rbp, %rdi
    b4b9:      	movl	$0x8, %esi
    b4be:      	callq	*%rax
    b4c0:      	movq	0x40(%rsp), %rax
    b4c5:      	cmpq	(%rsp), %rax
    b4c9:      	je	0x1636d <generic_usdt_path+0xba6d>
    b4cf:      	addq	$0x18, %r15
    b4d3:      	movl	$0x4, %eax
    b4d8:      	leaq	0x30(%rsp), %rdi
    b4dd:      	movl	$0x8, %esi
    b4e2:      	movq	%r15, %rdx
    b4e5:      	callq	*%rax
    b4e7:      	movq	(%rsp), %r15
    b4eb:      	movq	%r15, 0x40(%rsp)
    b4f0:      	leaq	0x20(%r15), %rdx
    b4f4:      	movq	%rdx, 0x38(%rsp)
    b4f9:      	movq	0x30(%rsp), %r12
    b4fe:      	cmpq	0x18(%rsp), %r12
    b503:      	jne	0xb510 <generic_usdt_path+0xc10>
    b505:      	cmpq	0x20(%rsp), %rdx
    b50a:      	je	0x1636d <generic_usdt_path+0xba6d>
    b510:      	movl	$0x4, %eax
    b515:      	leaq	0x10(%rsp), %rdi
    b51a:      	movl	$0x8, %esi
    b51f:      	callq	*%rax
    b521:      	cmpq	0x10(%rsp), %r12
    b526:      	je	0xb625 <generic_usdt_path+0xd25>
    b52c:      	leaq	0x18(%r12), %rbx
    b531:      	movl	$0x4, %eax
    b536:      	movq	%rbp, %rdi
    b539:      	movl	$0x8, %esi
    b53e:      	movq	%rbx, %rdx
    b541:      	callq	*%rax
    b543:      	cmpq	%r12, (%rsp)
    b547:      	je	0xb625 <generic_usdt_path+0xd25>
    b54d:      	movl	$0x4, %eax
    b552:      	leaq	0x8(%rsp), %rdi
    b557:      	movl	$0x8, %esi
    b55c:      	movq	%rbx, %rdx
    b55f:      	callq	*%rax
    b561:      	addq	$0x20, %r12
    b565:      	movl	$0x4, %eax
    b56a:      	leaq	0x58(%rsp), %rdi
    b56f:      	movl	$0x10, %ecx
    b574:      	movl	$0x10, %esi
    b579:      	movq	%r12, %rdx
    b57c:      	callq	*%rax
    b57e:      	movq	0x28(%rsp), %rbx
    b583:      	movq	0x48(%rsp), %rax
    b588:      	movl	0x5c(%rsp), %r15d
    b58d:      	subq	%rbx, %rax
    b590:      	movl	0x50(%rsp), %r12d
    b595:      	movl	%r15d, %edx
    b598:      	subl	%r12d, %edx
    b59b:      	movl	$0x0, %ecx
    b5a0:      	cmovbl	%ecx, %edx
    b5a3:      	addq	0x60(%rsp), %rdx
    b5a8:      	xorl	%esi, %esi
    b5aa:      	cmpl	%r15d, %r12d
    b5ad:      	seta	%sil
    b5b1:      	movl	%r15d, %ecx
    b5b4:      	cmovbl	%r12d, %ecx
    b5b8:      	addl	%ecx, %esi
    b5ba:      	movl	%r12d, %edi
    b5bd:      	subl	%esi, %edi
    b5bf:      	movl	%edi, 0x50(%rsp)
    b5c3:      	subq	%rsi, %rax
    b5c6:      	jb	0x16372 <generic_usdt_path+0xba72>
    b5cc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b5d2:      	ja	0x16372 <generic_usdt_path+0xba72>
    b5d8:      	cmpl	%r15d, %r12d
    b5db:      	jbe	0xb5e1 <generic_usdt_path+0xce1>
    b5dd:      	movb	$0x2f, (%rbx,%rax)
    b5e1:      	xorl	%edi, %edi
    b5e3:      	cmpl	%r15d, %r12d
    b5e6:      	seta	%dil
    b5ea:      	movzbl	%cl, %esi
    b5ed:      	addq	%rax, %rbx
    b5f0:      	addq	%rbx, %rdi
    b5f3:      	movl	$0x4, %eax
    b5f8:      	callq	*%rax
    b5fa:      	movq	%rbx, 0x48(%rsp)
    b5ff:      	cmpl	%r15d, %r12d
    b602:      	jbe	0x16372 <generic_usdt_path+0xba72>
    b608:      	movq	0x8(%rsp), %r12
    b60d:      	movq	%r12, 0x30(%rsp)
    b612:      	movq	0x38(%rsp), %rdx
    b617:      	movq	0x40(%rsp), %r15
    b61c:      	cmpq	0x18(%rsp), %r12
    b621:      	je	0xb67d <generic_usdt_path+0xd7d>
    b623:      	jmp	0xb688 <generic_usdt_path+0xd88>
    b625:      	leaq	0x10(%r15), %rdx
    b629:      	movl	$0x4, %eax
    b62e:      	movq	%rbp, %rdi
    b631:      	movl	$0x8, %esi
    b636:      	callq	*%rax
    b638:      	movq	0x40(%rsp), %rax
    b63d:      	cmpq	(%rsp), %rax
    b641:      	je	0x1636d <generic_usdt_path+0xba6d>
    b647:      	addq	$0x18, %r15
    b64b:      	movl	$0x4, %eax
    b650:      	leaq	0x30(%rsp), %rdi
    b655:      	movl	$0x8, %esi
    b65a:      	movq	%r15, %rdx
    b65d:      	callq	*%rax
    b65f:      	movq	(%rsp), %r15
    b663:      	movq	%r15, 0x40(%rsp)
    b668:      	leaq	0x20(%r15), %rdx
    b66c:      	movq	%rdx, 0x38(%rsp)
    b671:      	movq	0x30(%rsp), %r12
    b676:      	cmpq	0x18(%rsp), %r12
    b67b:      	jne	0xb688 <generic_usdt_path+0xd88>
    b67d:      	cmpq	0x20(%rsp), %rdx
    b682:      	je	0x1636d <generic_usdt_path+0xba6d>
    b688:      	movl	$0x4, %eax
    b68d:      	leaq	0x10(%rsp), %rdi
    b692:      	movl	$0x8, %esi
    b697:      	callq	*%rax
    b699:      	cmpq	0x10(%rsp), %r12
    b69e:      	je	0xb79d <generic_usdt_path+0xe9d>
    b6a4:      	leaq	0x18(%r12), %rbx
    b6a9:      	movl	$0x4, %eax
    b6ae:      	movq	%rbp, %rdi
    b6b1:      	movl	$0x8, %esi
    b6b6:      	movq	%rbx, %rdx
    b6b9:      	callq	*%rax
    b6bb:      	cmpq	%r12, (%rsp)
    b6bf:      	je	0xb79d <generic_usdt_path+0xe9d>
    b6c5:      	movl	$0x4, %eax
    b6ca:      	leaq	0x8(%rsp), %rdi
    b6cf:      	movl	$0x8, %esi
    b6d4:      	movq	%rbx, %rdx
    b6d7:      	callq	*%rax
    b6d9:      	addq	$0x20, %r12
    b6dd:      	movl	$0x4, %eax
    b6e2:      	leaq	0x58(%rsp), %rdi
    b6e7:      	movl	$0x10, %ecx
    b6ec:      	movl	$0x10, %esi
    b6f1:      	movq	%r12, %rdx
    b6f4:      	callq	*%rax
    b6f6:      	movq	0x28(%rsp), %rbx
    b6fb:      	movq	0x48(%rsp), %rax
    b700:      	movl	0x5c(%rsp), %r15d
    b705:      	subq	%rbx, %rax
    b708:      	movl	0x50(%rsp), %r12d
    b70d:      	movl	%r15d, %edx
    b710:      	subl	%r12d, %edx
    b713:      	movl	$0x0, %ecx
    b718:      	cmovbl	%ecx, %edx
    b71b:      	addq	0x60(%rsp), %rdx
    b720:      	xorl	%esi, %esi
    b722:      	cmpl	%r15d, %r12d
    b725:      	seta	%sil
    b729:      	movl	%r15d, %ecx
    b72c:      	cmovbl	%r12d, %ecx
    b730:      	addl	%ecx, %esi
    b732:      	movl	%r12d, %edi
    b735:      	subl	%esi, %edi
    b737:      	movl	%edi, 0x50(%rsp)
    b73b:      	subq	%rsi, %rax
    b73e:      	jb	0x16372 <generic_usdt_path+0xba72>
    b744:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b74a:      	ja	0x16372 <generic_usdt_path+0xba72>
    b750:      	cmpl	%r15d, %r12d
    b753:      	jbe	0xb759 <generic_usdt_path+0xe59>
    b755:      	movb	$0x2f, (%rbx,%rax)
    b759:      	xorl	%edi, %edi
    b75b:      	cmpl	%r15d, %r12d
    b75e:      	seta	%dil
    b762:      	movzbl	%cl, %esi
    b765:      	addq	%rax, %rbx
    b768:      	addq	%rbx, %rdi
    b76b:      	movl	$0x4, %eax
    b770:      	callq	*%rax
    b772:      	movq	%rbx, 0x48(%rsp)
    b777:      	cmpl	%r15d, %r12d
    b77a:      	jbe	0x16372 <generic_usdt_path+0xba72>
    b780:      	movq	0x8(%rsp), %r12
    b785:      	movq	%r12, 0x30(%rsp)
    b78a:      	movq	0x38(%rsp), %rdx
    b78f:      	movq	0x40(%rsp), %r15
    b794:      	cmpq	0x18(%rsp), %r12
    b799:      	je	0xb7f5 <generic_usdt_path+0xef5>
    b79b:      	jmp	0xb800 <generic_usdt_path+0xf00>
    b79d:      	leaq	0x10(%r15), %rdx
    b7a1:      	movl	$0x4, %eax
    b7a6:      	movq	%rbp, %rdi
    b7a9:      	movl	$0x8, %esi
    b7ae:      	callq	*%rax
    b7b0:      	movq	0x40(%rsp), %rax
    b7b5:      	cmpq	(%rsp), %rax
    b7b9:      	je	0x1636d <generic_usdt_path+0xba6d>
    b7bf:      	addq	$0x18, %r15
    b7c3:      	movl	$0x4, %eax
    b7c8:      	leaq	0x30(%rsp), %rdi
    b7cd:      	movl	$0x8, %esi
    b7d2:      	movq	%r15, %rdx
    b7d5:      	callq	*%rax
    b7d7:      	movq	(%rsp), %r15
    b7db:      	movq	%r15, 0x40(%rsp)
    b7e0:      	leaq	0x20(%r15), %rdx
    b7e4:      	movq	%rdx, 0x38(%rsp)
    b7e9:      	movq	0x30(%rsp), %r12
    b7ee:      	cmpq	0x18(%rsp), %r12
    b7f3:      	jne	0xb800 <generic_usdt_path+0xf00>
    b7f5:      	cmpq	0x20(%rsp), %rdx
    b7fa:      	je	0x1636d <generic_usdt_path+0xba6d>
    b800:      	movl	$0x4, %eax
    b805:      	leaq	0x10(%rsp), %rdi
    b80a:      	movl	$0x8, %esi
    b80f:      	callq	*%rax
    b811:      	cmpq	0x10(%rsp), %r12
    b816:      	je	0xb90e <generic_usdt_path+0x100e>
    b81c:      	leaq	0x18(%r12), %rbx
    b821:      	movl	$0x4, %eax
    b826:      	movq	%rbp, %rdi
    b829:      	movl	$0x8, %esi
    b82e:      	movq	%rbx, %rdx
    b831:      	callq	*%rax
    b833:      	cmpq	%r12, (%rsp)
    b837:      	je	0xb90e <generic_usdt_path+0x100e>
    b83d:      	movl	$0x4, %eax
    b842:      	leaq	0x8(%rsp), %rdi
    b847:      	movl	$0x8, %esi
    b84c:      	movq	%rbx, %rdx
    b84f:      	callq	*%rax
    b851:      	addq	$0x20, %r12
    b855:      	movl	$0x4, %eax
    b85a:      	leaq	0x58(%rsp), %rdi
    b85f:      	movl	$0x10, %ecx
    b864:      	movl	$0x10, %esi
    b869:      	movq	%r12, %rdx
    b86c:      	callq	*%rax
    b86e:      	movq	0x28(%rsp), %rbx
    b873:      	movq	0x48(%rsp), %rax
    b878:      	movl	0x5c(%rsp), %r15d
    b87d:      	subq	%rbx, %rax
    b880:      	movl	0x50(%rsp), %r12d
    b885:      	movl	%r15d, %edx
    b888:      	subl	%r12d, %edx
    b88b:      	movl	$0x0, %ecx
    b890:      	cmovbl	%ecx, %edx
    b893:      	addq	0x60(%rsp), %rdx
    b898:      	xorl	%esi, %esi
    b89a:      	cmpl	%r15d, %r12d
    b89d:      	seta	%sil
    b8a1:      	movl	%r15d, %ecx
    b8a4:      	cmovbl	%r12d, %ecx
    b8a8:      	addl	%ecx, %esi
    b8aa:      	movl	%r12d, %edi
    b8ad:      	subl	%esi, %edi
    b8af:      	movl	%edi, 0x50(%rsp)
    b8b3:      	subq	%rsi, %rax
    b8b6:      	jb	0x16372 <generic_usdt_path+0xba72>
    b8bc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    b8c2:      	ja	0x16372 <generic_usdt_path+0xba72>
    b8c8:      	cmpl	%r15d, %r12d
    b8cb:      	jbe	0xb8d1 <generic_usdt_path+0xfd1>
    b8cd:      	movb	$0x2f, (%rbx,%rax)
    b8d1:      	xorl	%edi, %edi
    b8d3:      	cmpl	%r15d, %r12d
    b8d6:      	seta	%dil
    b8da:      	movzbl	%cl, %esi
    b8dd:      	addq	%rax, %rbx
    b8e0:      	addq	%rbx, %rdi
    b8e3:      	movl	$0x4, %eax
    b8e8:      	callq	*%rax
    b8ea:      	movq	%rbx, 0x48(%rsp)
    b8ef:      	cmpl	%r15d, %r12d
    b8f2:      	jbe	0x16372 <generic_usdt_path+0xba72>
    b8f8:      	movq	0x8(%rsp), %r12
    b8fd:      	movq	%r12, 0x30(%rsp)
    b902:      	movq	0x38(%rsp), %rdx
    b907:      	movq	0x40(%rsp), %r15
    b90c:      	jmp	0xb95f <generic_usdt_path+0x105f>
    b90e:      	leaq	0x10(%r15), %rdx
    b912:      	movl	$0x4, %eax
    b917:      	movq	%rbp, %rdi
    b91a:      	movl	$0x8, %esi
    b91f:      	callq	*%rax
    b921:      	movq	0x40(%rsp), %rax
    b926:      	cmpq	(%rsp), %rax
    b92a:      	je	0x1636d <generic_usdt_path+0xba6d>
    b930:      	addq	$0x18, %r15
    b934:      	movl	$0x4, %eax
    b939:      	leaq	0x30(%rsp), %rdi
    b93e:      	movl	$0x8, %esi
    b943:      	movq	%r15, %rdx
    b946:      	callq	*%rax
    b948:      	movq	(%rsp), %r15
    b94c:      	movq	%r15, 0x40(%rsp)
    b951:      	leaq	0x20(%r15), %rdx
    b955:      	movq	%rdx, 0x38(%rsp)
    b95a:      	movq	0x30(%rsp), %r12
    b95f:      	cmpq	0x18(%rsp), %r12
    b964:      	jne	0xb971 <generic_usdt_path+0x1071>
    b966:      	cmpq	0x20(%rsp), %rdx
    b96b:      	je	0x1636d <generic_usdt_path+0xba6d>
    b971:      	movl	$0x4, %eax
    b976:      	leaq	0x10(%rsp), %rdi
    b97b:      	movl	$0x8, %esi
    b980:      	callq	*%rax
    b982:      	cmpq	0x10(%rsp), %r12
    b987:      	je	0xba7f <generic_usdt_path+0x117f>
    b98d:      	leaq	0x18(%r12), %rbx
    b992:      	movl	$0x4, %eax
    b997:      	movq	%rbp, %rdi
    b99a:      	movl	$0x8, %esi
    b99f:      	movq	%rbx, %rdx
    b9a2:      	callq	*%rax
    b9a4:      	cmpq	%r12, (%rsp)
    b9a8:      	je	0xba7f <generic_usdt_path+0x117f>
    b9ae:      	movl	$0x4, %eax
    b9b3:      	leaq	0x8(%rsp), %rdi
    b9b8:      	movl	$0x8, %esi
    b9bd:      	movq	%rbx, %rdx
    b9c0:      	callq	*%rax
    b9c2:      	addq	$0x20, %r12
    b9c6:      	movl	$0x4, %eax
    b9cb:      	leaq	0x58(%rsp), %rdi
    b9d0:      	movl	$0x10, %ecx
    b9d5:      	movl	$0x10, %esi
    b9da:      	movq	%r12, %rdx
    b9dd:      	callq	*%rax
    b9df:      	movq	0x28(%rsp), %rbx
    b9e4:      	movq	0x48(%rsp), %rax
    b9e9:      	movl	0x5c(%rsp), %r15d
    b9ee:      	subq	%rbx, %rax
    b9f1:      	movl	0x50(%rsp), %r12d
    b9f6:      	movl	%r15d, %edx
    b9f9:      	subl	%r12d, %edx
    b9fc:      	movl	$0x0, %ecx
    ba01:      	cmovbl	%ecx, %edx
    ba04:      	addq	0x60(%rsp), %rdx
    ba09:      	xorl	%esi, %esi
    ba0b:      	cmpl	%r15d, %r12d
    ba0e:      	seta	%sil
    ba12:      	movl	%r15d, %ecx
    ba15:      	cmovbl	%r12d, %ecx
    ba19:      	addl	%ecx, %esi
    ba1b:      	movl	%r12d, %edi
    ba1e:      	subl	%esi, %edi
    ba20:      	movl	%edi, 0x50(%rsp)
    ba24:      	subq	%rsi, %rax
    ba27:      	jb	0x16372 <generic_usdt_path+0xba72>
    ba2d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ba33:      	ja	0x16372 <generic_usdt_path+0xba72>
    ba39:      	cmpl	%r15d, %r12d
    ba3c:      	jbe	0xba42 <generic_usdt_path+0x1142>
    ba3e:      	movb	$0x2f, (%rbx,%rax)
    ba42:      	xorl	%edi, %edi
    ba44:      	cmpl	%r15d, %r12d
    ba47:      	seta	%dil
    ba4b:      	movzbl	%cl, %esi
    ba4e:      	addq	%rax, %rbx
    ba51:      	addq	%rbx, %rdi
    ba54:      	movl	$0x4, %eax
    ba59:      	callq	*%rax
    ba5b:      	movq	%rbx, 0x48(%rsp)
    ba60:      	cmpl	%r15d, %r12d
    ba63:      	jbe	0x16372 <generic_usdt_path+0xba72>
    ba69:      	movq	0x8(%rsp), %r12
    ba6e:      	movq	%r12, 0x30(%rsp)
    ba73:      	movq	0x38(%rsp), %rdx
    ba78:      	movq	0x40(%rsp), %r15
    ba7d:      	jmp	0xbad0 <generic_usdt_path+0x11d0>
    ba7f:      	leaq	0x10(%r15), %rdx
    ba83:      	movl	$0x4, %eax
    ba88:      	movq	%rbp, %rdi
    ba8b:      	movl	$0x8, %esi
    ba90:      	callq	*%rax
    ba92:      	movq	0x40(%rsp), %rax
    ba97:      	cmpq	(%rsp), %rax
    ba9b:      	je	0x1636d <generic_usdt_path+0xba6d>
    baa1:      	addq	$0x18, %r15
    baa5:      	movl	$0x4, %eax
    baaa:      	leaq	0x30(%rsp), %rdi
    baaf:      	movl	$0x8, %esi
    bab4:      	movq	%r15, %rdx
    bab7:      	callq	*%rax
    bab9:      	movq	(%rsp), %r15
    babd:      	movq	%r15, 0x40(%rsp)
    bac2:      	leaq	0x20(%r15), %rdx
    bac6:      	movq	%rdx, 0x38(%rsp)
    bacb:      	movq	0x30(%rsp), %r12
    bad0:      	cmpq	0x18(%rsp), %r12
    bad5:      	jne	0xbae2 <generic_usdt_path+0x11e2>
    bad7:      	cmpq	0x20(%rsp), %rdx
    badc:      	je	0x1636d <generic_usdt_path+0xba6d>
    bae2:      	movl	$0x4, %eax
    bae7:      	leaq	0x10(%rsp), %rdi
    baec:      	movl	$0x8, %esi
    baf1:      	callq	*%rax
    baf3:      	cmpq	0x10(%rsp), %r12
    baf8:      	je	0xbbf0 <generic_usdt_path+0x12f0>
    bafe:      	leaq	0x18(%r12), %rbx
    bb03:      	movl	$0x4, %eax
    bb08:      	movq	%rbp, %rdi
    bb0b:      	movl	$0x8, %esi
    bb10:      	movq	%rbx, %rdx
    bb13:      	callq	*%rax
    bb15:      	cmpq	%r12, (%rsp)
    bb19:      	je	0xbbf0 <generic_usdt_path+0x12f0>
    bb1f:      	movl	$0x4, %eax
    bb24:      	leaq	0x8(%rsp), %rdi
    bb29:      	movl	$0x8, %esi
    bb2e:      	movq	%rbx, %rdx
    bb31:      	callq	*%rax
    bb33:      	addq	$0x20, %r12
    bb37:      	movl	$0x4, %eax
    bb3c:      	leaq	0x58(%rsp), %rdi
    bb41:      	movl	$0x10, %ecx
    bb46:      	movl	$0x10, %esi
    bb4b:      	movq	%r12, %rdx
    bb4e:      	callq	*%rax
    bb50:      	movq	0x28(%rsp), %rbx
    bb55:      	movq	0x48(%rsp), %rax
    bb5a:      	movl	0x5c(%rsp), %r15d
    bb5f:      	subq	%rbx, %rax
    bb62:      	movl	0x50(%rsp), %r12d
    bb67:      	movl	%r15d, %edx
    bb6a:      	subl	%r12d, %edx
    bb6d:      	movl	$0x0, %ecx
    bb72:      	cmovbl	%ecx, %edx
    bb75:      	addq	0x60(%rsp), %rdx
    bb7a:      	xorl	%esi, %esi
    bb7c:      	cmpl	%r15d, %r12d
    bb7f:      	seta	%sil
    bb83:      	movl	%r15d, %ecx
    bb86:      	cmovbl	%r12d, %ecx
    bb8a:      	addl	%ecx, %esi
    bb8c:      	movl	%r12d, %edi
    bb8f:      	subl	%esi, %edi
    bb91:      	movl	%edi, 0x50(%rsp)
    bb95:      	subq	%rsi, %rax
    bb98:      	jb	0x16372 <generic_usdt_path+0xba72>
    bb9e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    bba4:      	ja	0x16372 <generic_usdt_path+0xba72>
    bbaa:      	cmpl	%r15d, %r12d
    bbad:      	jbe	0xbbb3 <generic_usdt_path+0x12b3>
    bbaf:      	movb	$0x2f, (%rbx,%rax)
    bbb3:      	xorl	%edi, %edi
    bbb5:      	cmpl	%r15d, %r12d
    bbb8:      	seta	%dil
    bbbc:      	movzbl	%cl, %esi
    bbbf:      	addq	%rax, %rbx
    bbc2:      	addq	%rbx, %rdi
    bbc5:      	movl	$0x4, %eax
    bbca:      	callq	*%rax
    bbcc:      	movq	%rbx, 0x48(%rsp)
    bbd1:      	cmpl	%r15d, %r12d
    bbd4:      	jbe	0x16372 <generic_usdt_path+0xba72>
    bbda:      	movq	0x8(%rsp), %r12
    bbdf:      	movq	%r12, 0x30(%rsp)
    bbe4:      	movq	0x38(%rsp), %rdx
    bbe9:      	movq	0x40(%rsp), %r15
    bbee:      	jmp	0xbc41 <generic_usdt_path+0x1341>
    bbf0:      	leaq	0x10(%r15), %rdx
    bbf4:      	movl	$0x4, %eax
    bbf9:      	movq	%rbp, %rdi
    bbfc:      	movl	$0x8, %esi
    bc01:      	callq	*%rax
    bc03:      	movq	0x40(%rsp), %rax
    bc08:      	cmpq	(%rsp), %rax
    bc0c:      	je	0x1636d <generic_usdt_path+0xba6d>
    bc12:      	addq	$0x18, %r15
    bc16:      	movl	$0x4, %eax
    bc1b:      	leaq	0x30(%rsp), %rdi
    bc20:      	movl	$0x8, %esi
    bc25:      	movq	%r15, %rdx
    bc28:      	callq	*%rax
    bc2a:      	movq	(%rsp), %r15
    bc2e:      	movq	%r15, 0x40(%rsp)
    bc33:      	leaq	0x20(%r15), %rdx
    bc37:      	movq	%rdx, 0x38(%rsp)
    bc3c:      	movq	0x30(%rsp), %r12
    bc41:      	cmpq	0x18(%rsp), %r12
    bc46:      	jne	0xbc53 <generic_usdt_path+0x1353>
    bc48:      	cmpq	0x20(%rsp), %rdx
    bc4d:      	je	0x1636d <generic_usdt_path+0xba6d>
    bc53:      	movl	$0x4, %eax
    bc58:      	leaq	0x10(%rsp), %rdi
    bc5d:      	movl	$0x8, %esi
    bc62:      	callq	*%rax
    bc64:      	cmpq	0x10(%rsp), %r12
    bc69:      	je	0xbd61 <generic_usdt_path+0x1461>
    bc6f:      	leaq	0x18(%r12), %rbx
    bc74:      	movl	$0x4, %eax
    bc79:      	movq	%rbp, %rdi
    bc7c:      	movl	$0x8, %esi
    bc81:      	movq	%rbx, %rdx
    bc84:      	callq	*%rax
    bc86:      	cmpq	%r12, (%rsp)
    bc8a:      	je	0xbd61 <generic_usdt_path+0x1461>
    bc90:      	movl	$0x4, %eax
    bc95:      	leaq	0x8(%rsp), %rdi
    bc9a:      	movl	$0x8, %esi
    bc9f:      	movq	%rbx, %rdx
    bca2:      	callq	*%rax
    bca4:      	addq	$0x20, %r12
    bca8:      	movl	$0x4, %eax
    bcad:      	leaq	0x58(%rsp), %rdi
    bcb2:      	movl	$0x10, %ecx
    bcb7:      	movl	$0x10, %esi
    bcbc:      	movq	%r12, %rdx
    bcbf:      	callq	*%rax
    bcc1:      	movq	0x28(%rsp), %rbx
    bcc6:      	movq	0x48(%rsp), %rax
    bccb:      	movl	0x5c(%rsp), %r15d
    bcd0:      	subq	%rbx, %rax
    bcd3:      	movl	0x50(%rsp), %r12d
    bcd8:      	movl	%r15d, %edx
    bcdb:      	subl	%r12d, %edx
    bcde:      	movl	$0x0, %ecx
    bce3:      	cmovbl	%ecx, %edx
    bce6:      	addq	0x60(%rsp), %rdx
    bceb:      	xorl	%esi, %esi
    bced:      	cmpl	%r15d, %r12d
    bcf0:      	seta	%sil
    bcf4:      	movl	%r15d, %ecx
    bcf7:      	cmovbl	%r12d, %ecx
    bcfb:      	addl	%ecx, %esi
    bcfd:      	movl	%r12d, %edi
    bd00:      	subl	%esi, %edi
    bd02:      	movl	%edi, 0x50(%rsp)
    bd06:      	subq	%rsi, %rax
    bd09:      	jb	0x16372 <generic_usdt_path+0xba72>
    bd0f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    bd15:      	ja	0x16372 <generic_usdt_path+0xba72>
    bd1b:      	cmpl	%r15d, %r12d
    bd1e:      	jbe	0xbd24 <generic_usdt_path+0x1424>
    bd20:      	movb	$0x2f, (%rbx,%rax)
    bd24:      	xorl	%edi, %edi
    bd26:      	cmpl	%r15d, %r12d
    bd29:      	seta	%dil
    bd2d:      	movzbl	%cl, %esi
    bd30:      	addq	%rax, %rbx
    bd33:      	addq	%rbx, %rdi
    bd36:      	movl	$0x4, %eax
    bd3b:      	callq	*%rax
    bd3d:      	movq	%rbx, 0x48(%rsp)
    bd42:      	cmpl	%r15d, %r12d
    bd45:      	jbe	0x16372 <generic_usdt_path+0xba72>
    bd4b:      	movq	0x8(%rsp), %r12
    bd50:      	movq	%r12, 0x30(%rsp)
    bd55:      	movq	0x38(%rsp), %rdx
    bd5a:      	movq	0x40(%rsp), %r15
    bd5f:      	jmp	0xbdb2 <generic_usdt_path+0x14b2>
    bd61:      	leaq	0x10(%r15), %rdx
    bd65:      	movl	$0x4, %eax
    bd6a:      	movq	%rbp, %rdi
    bd6d:      	movl	$0x8, %esi
    bd72:      	callq	*%rax
    bd74:      	movq	0x40(%rsp), %rax
    bd79:      	cmpq	(%rsp), %rax
    bd7d:      	je	0x1636d <generic_usdt_path+0xba6d>
    bd83:      	addq	$0x18, %r15
    bd87:      	movl	$0x4, %eax
    bd8c:      	leaq	0x30(%rsp), %rdi
    bd91:      	movl	$0x8, %esi
    bd96:      	movq	%r15, %rdx
    bd99:      	callq	*%rax
    bd9b:      	movq	(%rsp), %r15
    bd9f:      	movq	%r15, 0x40(%rsp)
    bda4:      	leaq	0x20(%r15), %rdx
    bda8:      	movq	%rdx, 0x38(%rsp)
    bdad:      	movq	0x30(%rsp), %r12
    bdb2:      	cmpq	0x18(%rsp), %r12
    bdb7:      	jne	0xbdc4 <generic_usdt_path+0x14c4>
    bdb9:      	cmpq	0x20(%rsp), %rdx
    bdbe:      	je	0x1636d <generic_usdt_path+0xba6d>
    bdc4:      	movl	$0x4, %eax
    bdc9:      	leaq	0x10(%rsp), %rdi
    bdce:      	movl	$0x8, %esi
    bdd3:      	callq	*%rax
    bdd5:      	cmpq	0x10(%rsp), %r12
    bdda:      	je	0xbed2 <generic_usdt_path+0x15d2>
    bde0:      	leaq	0x18(%r12), %rbx
    bde5:      	movl	$0x4, %eax
    bdea:      	movq	%rbp, %rdi
    bded:      	movl	$0x8, %esi
    bdf2:      	movq	%rbx, %rdx
    bdf5:      	callq	*%rax
    bdf7:      	cmpq	%r12, (%rsp)
    bdfb:      	je	0xbed2 <generic_usdt_path+0x15d2>
    be01:      	movl	$0x4, %eax
    be06:      	leaq	0x8(%rsp), %rdi
    be0b:      	movl	$0x8, %esi
    be10:      	movq	%rbx, %rdx
    be13:      	callq	*%rax
    be15:      	addq	$0x20, %r12
    be19:      	movl	$0x4, %eax
    be1e:      	leaq	0x58(%rsp), %rdi
    be23:      	movl	$0x10, %ecx
    be28:      	movl	$0x10, %esi
    be2d:      	movq	%r12, %rdx
    be30:      	callq	*%rax
    be32:      	movq	0x28(%rsp), %rbx
    be37:      	movq	0x48(%rsp), %rax
    be3c:      	movl	0x5c(%rsp), %r15d
    be41:      	subq	%rbx, %rax
    be44:      	movl	0x50(%rsp), %r12d
    be49:      	movl	%r15d, %edx
    be4c:      	subl	%r12d, %edx
    be4f:      	movl	$0x0, %ecx
    be54:      	cmovbl	%ecx, %edx
    be57:      	addq	0x60(%rsp), %rdx
    be5c:      	xorl	%esi, %esi
    be5e:      	cmpl	%r15d, %r12d
    be61:      	seta	%sil
    be65:      	movl	%r15d, %ecx
    be68:      	cmovbl	%r12d, %ecx
    be6c:      	addl	%ecx, %esi
    be6e:      	movl	%r12d, %edi
    be71:      	subl	%esi, %edi
    be73:      	movl	%edi, 0x50(%rsp)
    be77:      	subq	%rsi, %rax
    be7a:      	jb	0x16372 <generic_usdt_path+0xba72>
    be80:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    be86:      	ja	0x16372 <generic_usdt_path+0xba72>
    be8c:      	cmpl	%r15d, %r12d
    be8f:      	jbe	0xbe95 <generic_usdt_path+0x1595>
    be91:      	movb	$0x2f, (%rbx,%rax)
    be95:      	xorl	%edi, %edi
    be97:      	cmpl	%r15d, %r12d
    be9a:      	seta	%dil
    be9e:      	movzbl	%cl, %esi
    bea1:      	addq	%rax, %rbx
    bea4:      	addq	%rbx, %rdi
    bea7:      	movl	$0x4, %eax
    beac:      	callq	*%rax
    beae:      	movq	%rbx, 0x48(%rsp)
    beb3:      	cmpl	%r15d, %r12d
    beb6:      	jbe	0x16372 <generic_usdt_path+0xba72>
    bebc:      	movq	0x8(%rsp), %r12
    bec1:      	movq	%r12, 0x30(%rsp)
    bec6:      	movq	0x38(%rsp), %rdx
    becb:      	movq	0x40(%rsp), %r15
    bed0:      	jmp	0xbf23 <generic_usdt_path+0x1623>
    bed2:      	leaq	0x10(%r15), %rdx
    bed6:      	movl	$0x4, %eax
    bedb:      	movq	%rbp, %rdi
    bede:      	movl	$0x8, %esi
    bee3:      	callq	*%rax
    bee5:      	movq	0x40(%rsp), %rax
    beea:      	cmpq	(%rsp), %rax
    beee:      	je	0x1636d <generic_usdt_path+0xba6d>
    bef4:      	addq	$0x18, %r15
    bef8:      	movl	$0x4, %eax
    befd:      	leaq	0x30(%rsp), %rdi
    bf02:      	movl	$0x8, %esi
    bf07:      	movq	%r15, %rdx
    bf0a:      	callq	*%rax
    bf0c:      	movq	(%rsp), %r15
    bf10:      	movq	%r15, 0x40(%rsp)
    bf15:      	leaq	0x20(%r15), %rdx
    bf19:      	movq	%rdx, 0x38(%rsp)
    bf1e:      	movq	0x30(%rsp), %r12
    bf23:      	cmpq	0x18(%rsp), %r12
    bf28:      	jne	0xbf35 <generic_usdt_path+0x1635>
    bf2a:      	cmpq	0x20(%rsp), %rdx
    bf2f:      	je	0x1636d <generic_usdt_path+0xba6d>
    bf35:      	movl	$0x4, %eax
    bf3a:      	leaq	0x10(%rsp), %rdi
    bf3f:      	movl	$0x8, %esi
    bf44:      	callq	*%rax
    bf46:      	cmpq	0x10(%rsp), %r12
    bf4b:      	je	0xc043 <generic_usdt_path+0x1743>
    bf51:      	leaq	0x18(%r12), %rbx
    bf56:      	movl	$0x4, %eax
    bf5b:      	movq	%rbp, %rdi
    bf5e:      	movl	$0x8, %esi
    bf63:      	movq	%rbx, %rdx
    bf66:      	callq	*%rax
    bf68:      	cmpq	%r12, (%rsp)
    bf6c:      	je	0xc043 <generic_usdt_path+0x1743>
    bf72:      	movl	$0x4, %eax
    bf77:      	leaq	0x8(%rsp), %rdi
    bf7c:      	movl	$0x8, %esi
    bf81:      	movq	%rbx, %rdx
    bf84:      	callq	*%rax
    bf86:      	addq	$0x20, %r12
    bf8a:      	movl	$0x4, %eax
    bf8f:      	leaq	0x58(%rsp), %rdi
    bf94:      	movl	$0x10, %ecx
    bf99:      	movl	$0x10, %esi
    bf9e:      	movq	%r12, %rdx
    bfa1:      	callq	*%rax
    bfa3:      	movq	0x28(%rsp), %rbx
    bfa8:      	movq	0x48(%rsp), %rax
    bfad:      	movl	0x5c(%rsp), %r15d
    bfb2:      	subq	%rbx, %rax
    bfb5:      	movl	0x50(%rsp), %r12d
    bfba:      	movl	%r15d, %edx
    bfbd:      	subl	%r12d, %edx
    bfc0:      	movl	$0x0, %ecx
    bfc5:      	cmovbl	%ecx, %edx
    bfc8:      	addq	0x60(%rsp), %rdx
    bfcd:      	xorl	%esi, %esi
    bfcf:      	cmpl	%r15d, %r12d
    bfd2:      	seta	%sil
    bfd6:      	movl	%r15d, %ecx
    bfd9:      	cmovbl	%r12d, %ecx
    bfdd:      	addl	%ecx, %esi
    bfdf:      	movl	%r12d, %edi
    bfe2:      	subl	%esi, %edi
    bfe4:      	movl	%edi, 0x50(%rsp)
    bfe8:      	subq	%rsi, %rax
    bfeb:      	jb	0x16372 <generic_usdt_path+0xba72>
    bff1:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    bff7:      	ja	0x16372 <generic_usdt_path+0xba72>
    bffd:      	cmpl	%r15d, %r12d
    c000:      	jbe	0xc006 <generic_usdt_path+0x1706>
    c002:      	movb	$0x2f, (%rbx,%rax)
    c006:      	xorl	%edi, %edi
    c008:      	cmpl	%r15d, %r12d
    c00b:      	seta	%dil
    c00f:      	movzbl	%cl, %esi
    c012:      	addq	%rax, %rbx
    c015:      	addq	%rbx, %rdi
    c018:      	movl	$0x4, %eax
    c01d:      	callq	*%rax
    c01f:      	movq	%rbx, 0x48(%rsp)
    c024:      	cmpl	%r15d, %r12d
    c027:      	jbe	0x16372 <generic_usdt_path+0xba72>
    c02d:      	movq	0x8(%rsp), %r12
    c032:      	movq	%r12, 0x30(%rsp)
    c037:      	movq	0x38(%rsp), %rdx
    c03c:      	movq	0x40(%rsp), %r15
    c041:      	jmp	0xc094 <generic_usdt_path+0x1794>
    c043:      	leaq	0x10(%r15), %rdx
    c047:      	movl	$0x4, %eax
    c04c:      	movq	%rbp, %rdi
    c04f:      	movl	$0x8, %esi
    c054:      	callq	*%rax
    c056:      	movq	0x40(%rsp), %rax
    c05b:      	cmpq	(%rsp), %rax
    c05f:      	je	0x1636d <generic_usdt_path+0xba6d>
    c065:      	addq	$0x18, %r15
    c069:      	movl	$0x4, %eax
    c06e:      	leaq	0x30(%rsp), %rdi
    c073:      	movl	$0x8, %esi
    c078:      	movq	%r15, %rdx
    c07b:      	callq	*%rax
    c07d:      	movq	(%rsp), %r15
    c081:      	movq	%r15, 0x40(%rsp)
    c086:      	leaq	0x20(%r15), %rdx
    c08a:      	movq	%rdx, 0x38(%rsp)
    c08f:      	movq	0x30(%rsp), %r12
    c094:      	cmpq	0x18(%rsp), %r12
    c099:      	jne	0xc0a6 <generic_usdt_path+0x17a6>
    c09b:      	cmpq	0x20(%rsp), %rdx
    c0a0:      	je	0x1636d <generic_usdt_path+0xba6d>
    c0a6:      	movl	$0x4, %eax
    c0ab:      	leaq	0x10(%rsp), %rdi
    c0b0:      	movl	$0x8, %esi
    c0b5:      	callq	*%rax
    c0b7:      	cmpq	0x10(%rsp), %r12
    c0bc:      	je	0xc1b4 <generic_usdt_path+0x18b4>
    c0c2:      	leaq	0x18(%r12), %rbx
    c0c7:      	movl	$0x4, %eax
    c0cc:      	movq	%rbp, %rdi
    c0cf:      	movl	$0x8, %esi
    c0d4:      	movq	%rbx, %rdx
    c0d7:      	callq	*%rax
    c0d9:      	cmpq	%r12, (%rsp)
    c0dd:      	je	0xc1b4 <generic_usdt_path+0x18b4>
    c0e3:      	movl	$0x4, %eax
    c0e8:      	leaq	0x8(%rsp), %rdi
    c0ed:      	movl	$0x8, %esi
    c0f2:      	movq	%rbx, %rdx
    c0f5:      	callq	*%rax
    c0f7:      	addq	$0x20, %r12
    c0fb:      	movl	$0x4, %eax
    c100:      	leaq	0x58(%rsp), %rdi
    c105:      	movl	$0x10, %ecx
    c10a:      	movl	$0x10, %esi
    c10f:      	movq	%r12, %rdx
    c112:      	callq	*%rax
    c114:      	movq	0x28(%rsp), %rbx
    c119:      	movq	0x48(%rsp), %rax
    c11e:      	movl	0x5c(%rsp), %r15d
    c123:      	subq	%rbx, %rax
    c126:      	movl	0x50(%rsp), %r12d
    c12b:      	movl	%r15d, %edx
    c12e:      	subl	%r12d, %edx
    c131:      	movl	$0x0, %ecx
    c136:      	cmovbl	%ecx, %edx
    c139:      	addq	0x60(%rsp), %rdx
    c13e:      	xorl	%esi, %esi
    c140:      	cmpl	%r15d, %r12d
    c143:      	seta	%sil
    c147:      	movl	%r15d, %ecx
    c14a:      	cmovbl	%r12d, %ecx
    c14e:      	addl	%ecx, %esi
    c150:      	movl	%r12d, %edi
    c153:      	subl	%esi, %edi
    c155:      	movl	%edi, 0x50(%rsp)
    c159:      	subq	%rsi, %rax
    c15c:      	jb	0x16372 <generic_usdt_path+0xba72>
    c162:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c168:      	ja	0x16372 <generic_usdt_path+0xba72>
    c16e:      	cmpl	%r15d, %r12d
    c171:      	jbe	0xc177 <generic_usdt_path+0x1877>
    c173:      	movb	$0x2f, (%rbx,%rax)
    c177:      	xorl	%edi, %edi
    c179:      	cmpl	%r15d, %r12d
    c17c:      	seta	%dil
    c180:      	movzbl	%cl, %esi
    c183:      	addq	%rax, %rbx
    c186:      	addq	%rbx, %rdi
    c189:      	movl	$0x4, %eax
    c18e:      	callq	*%rax
    c190:      	movq	%rbx, 0x48(%rsp)
    c195:      	cmpl	%r15d, %r12d
    c198:      	jbe	0x16372 <generic_usdt_path+0xba72>
    c19e:      	movq	0x8(%rsp), %r12
    c1a3:      	movq	%r12, 0x30(%rsp)
    c1a8:      	movq	0x38(%rsp), %rdx
    c1ad:      	movq	0x40(%rsp), %r15
    c1b2:      	jmp	0xc205 <generic_usdt_path+0x1905>
    c1b4:      	leaq	0x10(%r15), %rdx
    c1b8:      	movl	$0x4, %eax
    c1bd:      	movq	%rbp, %rdi
    c1c0:      	movl	$0x8, %esi
    c1c5:      	callq	*%rax
    c1c7:      	movq	0x40(%rsp), %rax
    c1cc:      	cmpq	(%rsp), %rax
    c1d0:      	je	0x1636d <generic_usdt_path+0xba6d>
    c1d6:      	addq	$0x18, %r15
    c1da:      	movl	$0x4, %eax
    c1df:      	leaq	0x30(%rsp), %rdi
    c1e4:      	movl	$0x8, %esi
    c1e9:      	movq	%r15, %rdx
    c1ec:      	callq	*%rax
    c1ee:      	movq	(%rsp), %r15
    c1f2:      	movq	%r15, 0x40(%rsp)
    c1f7:      	leaq	0x20(%r15), %rdx
    c1fb:      	movq	%rdx, 0x38(%rsp)
    c200:      	movq	0x30(%rsp), %r12
    c205:      	cmpq	0x18(%rsp), %r12
    c20a:      	jne	0xc217 <generic_usdt_path+0x1917>
    c20c:      	cmpq	0x20(%rsp), %rdx
    c211:      	je	0x1636d <generic_usdt_path+0xba6d>
    c217:      	movl	$0x4, %eax
    c21c:      	leaq	0x10(%rsp), %rdi
    c221:      	movl	$0x8, %esi
    c226:      	callq	*%rax
    c228:      	cmpq	0x10(%rsp), %r12
    c22d:      	je	0xc325 <generic_usdt_path+0x1a25>
    c233:      	leaq	0x18(%r12), %rbx
    c238:      	movl	$0x4, %eax
    c23d:      	movq	%rbp, %rdi
    c240:      	movl	$0x8, %esi
    c245:      	movq	%rbx, %rdx
    c248:      	callq	*%rax
    c24a:      	cmpq	%r12, (%rsp)
    c24e:      	je	0xc325 <generic_usdt_path+0x1a25>
    c254:      	movl	$0x4, %eax
    c259:      	leaq	0x8(%rsp), %rdi
    c25e:      	movl	$0x8, %esi
    c263:      	movq	%rbx, %rdx
    c266:      	callq	*%rax
    c268:      	addq	$0x20, %r12
    c26c:      	movl	$0x4, %eax
    c271:      	leaq	0x58(%rsp), %rdi
    c276:      	movl	$0x10, %ecx
    c27b:      	movl	$0x10, %esi
    c280:      	movq	%r12, %rdx
    c283:      	callq	*%rax
    c285:      	movq	0x28(%rsp), %rbx
    c28a:      	movq	0x48(%rsp), %rax
    c28f:      	movl	0x5c(%rsp), %r15d
    c294:      	subq	%rbx, %rax
    c297:      	movl	0x50(%rsp), %r12d
    c29c:      	movl	%r15d, %edx
    c29f:      	subl	%r12d, %edx
    c2a2:      	movl	$0x0, %ecx
    c2a7:      	cmovbl	%ecx, %edx
    c2aa:      	addq	0x60(%rsp), %rdx
    c2af:      	xorl	%esi, %esi
    c2b1:      	cmpl	%r15d, %r12d
    c2b4:      	seta	%sil
    c2b8:      	movl	%r15d, %ecx
    c2bb:      	cmovbl	%r12d, %ecx
    c2bf:      	addl	%ecx, %esi
    c2c1:      	movl	%r12d, %edi
    c2c4:      	subl	%esi, %edi
    c2c6:      	movl	%edi, 0x50(%rsp)
    c2ca:      	subq	%rsi, %rax
    c2cd:      	jb	0x16372 <generic_usdt_path+0xba72>
    c2d3:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c2d9:      	ja	0x16372 <generic_usdt_path+0xba72>
    c2df:      	cmpl	%r15d, %r12d
    c2e2:      	jbe	0xc2e8 <generic_usdt_path+0x19e8>
    c2e4:      	movb	$0x2f, (%rbx,%rax)
    c2e8:      	xorl	%edi, %edi
    c2ea:      	cmpl	%r15d, %r12d
    c2ed:      	seta	%dil
    c2f1:      	movzbl	%cl, %esi
    c2f4:      	addq	%rax, %rbx
    c2f7:      	addq	%rbx, %rdi
    c2fa:      	movl	$0x4, %eax
    c2ff:      	callq	*%rax
    c301:      	movq	%rbx, 0x48(%rsp)
    c306:      	cmpl	%r15d, %r12d
    c309:      	jbe	0x16372 <generic_usdt_path+0xba72>
    c30f:      	movq	0x8(%rsp), %r12
    c314:      	movq	%r12, 0x30(%rsp)
    c319:      	movq	0x38(%rsp), %rdx
    c31e:      	movq	0x40(%rsp), %r15
    c323:      	jmp	0xc376 <generic_usdt_path+0x1a76>
    c325:      	leaq	0x10(%r15), %rdx
    c329:      	movl	$0x4, %eax
    c32e:      	movq	%rbp, %rdi
    c331:      	movl	$0x8, %esi
    c336:      	callq	*%rax
    c338:      	movq	0x40(%rsp), %rax
    c33d:      	cmpq	(%rsp), %rax
    c341:      	je	0x1636d <generic_usdt_path+0xba6d>
    c347:      	addq	$0x18, %r15
    c34b:      	movl	$0x4, %eax
    c350:      	leaq	0x30(%rsp), %rdi
    c355:      	movl	$0x8, %esi
    c35a:      	movq	%r15, %rdx
    c35d:      	callq	*%rax
    c35f:      	movq	(%rsp), %r15
    c363:      	movq	%r15, 0x40(%rsp)
    c368:      	leaq	0x20(%r15), %rdx
    c36c:      	movq	%rdx, 0x38(%rsp)
    c371:      	movq	0x30(%rsp), %r12
    c376:      	cmpq	0x18(%rsp), %r12
    c37b:      	jne	0xc388 <generic_usdt_path+0x1a88>
    c37d:      	cmpq	0x20(%rsp), %rdx
    c382:      	je	0x1636d <generic_usdt_path+0xba6d>
    c388:      	movl	$0x4, %eax
    c38d:      	leaq	0x10(%rsp), %rdi
    c392:      	movl	$0x8, %esi
    c397:      	callq	*%rax
    c399:      	cmpq	0x10(%rsp), %r12
    c39e:      	je	0xc496 <generic_usdt_path+0x1b96>
    c3a4:      	leaq	0x18(%r12), %rbx
    c3a9:      	movl	$0x4, %eax
    c3ae:      	movq	%rbp, %rdi
    c3b1:      	movl	$0x8, %esi
    c3b6:      	movq	%rbx, %rdx
    c3b9:      	callq	*%rax
    c3bb:      	cmpq	%r12, (%rsp)
    c3bf:      	je	0xc496 <generic_usdt_path+0x1b96>
    c3c5:      	movl	$0x4, %eax
    c3ca:      	leaq	0x8(%rsp), %rdi
    c3cf:      	movl	$0x8, %esi
    c3d4:      	movq	%rbx, %rdx
    c3d7:      	callq	*%rax
    c3d9:      	addq	$0x20, %r12
    c3dd:      	movl	$0x4, %eax
    c3e2:      	leaq	0x58(%rsp), %rdi
    c3e7:      	movl	$0x10, %ecx
    c3ec:      	movl	$0x10, %esi
    c3f1:      	movq	%r12, %rdx
    c3f4:      	callq	*%rax
    c3f6:      	movq	0x28(%rsp), %rbx
    c3fb:      	movq	0x48(%rsp), %rax
    c400:      	movl	0x5c(%rsp), %r15d
    c405:      	subq	%rbx, %rax
    c408:      	movl	0x50(%rsp), %r12d
    c40d:      	movl	%r15d, %edx
    c410:      	subl	%r12d, %edx
    c413:      	movl	$0x0, %ecx
    c418:      	cmovbl	%ecx, %edx
    c41b:      	addq	0x60(%rsp), %rdx
    c420:      	xorl	%esi, %esi
    c422:      	cmpl	%r15d, %r12d
    c425:      	seta	%sil
    c429:      	movl	%r15d, %ecx
    c42c:      	cmovbl	%r12d, %ecx
    c430:      	addl	%ecx, %esi
    c432:      	movl	%r12d, %edi
    c435:      	subl	%esi, %edi
    c437:      	movl	%edi, 0x50(%rsp)
    c43b:      	subq	%rsi, %rax
    c43e:      	jb	0x16372 <generic_usdt_path+0xba72>
    c444:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c44a:      	ja	0x16372 <generic_usdt_path+0xba72>
    c450:      	cmpl	%r15d, %r12d
    c453:      	jbe	0xc459 <generic_usdt_path+0x1b59>
    c455:      	movb	$0x2f, (%rbx,%rax)
    c459:      	xorl	%edi, %edi
    c45b:      	cmpl	%r15d, %r12d
    c45e:      	seta	%dil
    c462:      	movzbl	%cl, %esi
    c465:      	addq	%rax, %rbx
    c468:      	addq	%rbx, %rdi
    c46b:      	movl	$0x4, %eax
    c470:      	callq	*%rax
    c472:      	movq	%rbx, 0x48(%rsp)
    c477:      	cmpl	%r15d, %r12d
    c47a:      	jbe	0x16372 <generic_usdt_path+0xba72>
    c480:      	movq	0x8(%rsp), %r12
    c485:      	movq	%r12, 0x30(%rsp)
    c48a:      	movq	0x38(%rsp), %rdx
    c48f:      	movq	0x40(%rsp), %r15
    c494:      	jmp	0xc4e7 <generic_usdt_path+0x1be7>
    c496:      	leaq	0x10(%r15), %rdx
    c49a:      	movl	$0x4, %eax
    c49f:      	movq	%rbp, %rdi
    c4a2:      	movl	$0x8, %esi
    c4a7:      	callq	*%rax
    c4a9:      	movq	0x40(%rsp), %rax
    c4ae:      	cmpq	(%rsp), %rax
    c4b2:      	je	0x1636d <generic_usdt_path+0xba6d>
    c4b8:      	addq	$0x18, %r15
    c4bc:      	movl	$0x4, %eax
    c4c1:      	leaq	0x30(%rsp), %rdi
    c4c6:      	movl	$0x8, %esi
    c4cb:      	movq	%r15, %rdx
    c4ce:      	callq	*%rax
    c4d0:      	movq	(%rsp), %r15
    c4d4:      	movq	%r15, 0x40(%rsp)
    c4d9:      	leaq	0x20(%r15), %rdx
    c4dd:      	movq	%rdx, 0x38(%rsp)
    c4e2:      	movq	0x30(%rsp), %r12
    c4e7:      	cmpq	0x18(%rsp), %r12
    c4ec:      	jne	0xc4f9 <generic_usdt_path+0x1bf9>
    c4ee:      	cmpq	0x20(%rsp), %rdx
    c4f3:      	je	0x1636d <generic_usdt_path+0xba6d>
    c4f9:      	movl	$0x4, %eax
    c4fe:      	leaq	0x10(%rsp), %rdi
    c503:      	movl	$0x8, %esi
    c508:      	callq	*%rax
    c50a:      	cmpq	0x10(%rsp), %r12
    c50f:      	je	0xc607 <generic_usdt_path+0x1d07>
    c515:      	leaq	0x18(%r12), %rbx
    c51a:      	movl	$0x4, %eax
    c51f:      	movq	%rbp, %rdi
    c522:      	movl	$0x8, %esi
    c527:      	movq	%rbx, %rdx
    c52a:      	callq	*%rax
    c52c:      	cmpq	%r12, (%rsp)
    c530:      	je	0xc607 <generic_usdt_path+0x1d07>
    c536:      	movl	$0x4, %eax
    c53b:      	leaq	0x8(%rsp), %rdi
    c540:      	movl	$0x8, %esi
    c545:      	movq	%rbx, %rdx
    c548:      	callq	*%rax
    c54a:      	addq	$0x20, %r12
    c54e:      	movl	$0x4, %eax
    c553:      	leaq	0x58(%rsp), %rdi
    c558:      	movl	$0x10, %ecx
    c55d:      	movl	$0x10, %esi
    c562:      	movq	%r12, %rdx
    c565:      	callq	*%rax
    c567:      	movq	0x28(%rsp), %rbx
    c56c:      	movq	0x48(%rsp), %rax
    c571:      	movl	0x5c(%rsp), %r15d
    c576:      	subq	%rbx, %rax
    c579:      	movl	0x50(%rsp), %r12d
    c57e:      	movl	%r15d, %edx
    c581:      	subl	%r12d, %edx
    c584:      	movl	$0x0, %ecx
    c589:      	cmovbl	%ecx, %edx
    c58c:      	addq	0x60(%rsp), %rdx
    c591:      	xorl	%esi, %esi
    c593:      	cmpl	%r15d, %r12d
    c596:      	seta	%sil
    c59a:      	movl	%r15d, %ecx
    c59d:      	cmovbl	%r12d, %ecx
    c5a1:      	addl	%ecx, %esi
    c5a3:      	movl	%r12d, %edi
    c5a6:      	subl	%esi, %edi
    c5a8:      	movl	%edi, 0x50(%rsp)
    c5ac:      	subq	%rsi, %rax
    c5af:      	jb	0x16372 <generic_usdt_path+0xba72>
    c5b5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c5bb:      	ja	0x16372 <generic_usdt_path+0xba72>
    c5c1:      	cmpl	%r15d, %r12d
    c5c4:      	jbe	0xc5ca <generic_usdt_path+0x1cca>
    c5c6:      	movb	$0x2f, (%rbx,%rax)
    c5ca:      	xorl	%edi, %edi
    c5cc:      	cmpl	%r15d, %r12d
    c5cf:      	seta	%dil
    c5d3:      	movzbl	%cl, %esi
    c5d6:      	addq	%rax, %rbx
    c5d9:      	addq	%rbx, %rdi
    c5dc:      	movl	$0x4, %eax
    c5e1:      	callq	*%rax
    c5e3:      	movq	%rbx, 0x48(%rsp)
    c5e8:      	cmpl	%r15d, %r12d
    c5eb:      	jbe	0x16372 <generic_usdt_path+0xba72>
    c5f1:      	movq	0x8(%rsp), %r12
    c5f6:      	movq	%r12, 0x30(%rsp)
    c5fb:      	movq	0x38(%rsp), %rdx
    c600:      	movq	0x40(%rsp), %r15
    c605:      	jmp	0xc658 <generic_usdt_path+0x1d58>
    c607:      	leaq	0x10(%r15), %rdx
    c60b:      	movl	$0x4, %eax
    c610:      	movq	%rbp, %rdi
    c613:      	movl	$0x8, %esi
    c618:      	callq	*%rax
    c61a:      	movq	0x40(%rsp), %rax
    c61f:      	cmpq	(%rsp), %rax
    c623:      	je	0x1636d <generic_usdt_path+0xba6d>
    c629:      	addq	$0x18, %r15
    c62d:      	movl	$0x4, %eax
    c632:      	leaq	0x30(%rsp), %rdi
    c637:      	movl	$0x8, %esi
    c63c:      	movq	%r15, %rdx
    c63f:      	callq	*%rax
    c641:      	movq	(%rsp), %r15
    c645:      	movq	%r15, 0x40(%rsp)
    c64a:      	leaq	0x20(%r15), %rdx
    c64e:      	movq	%rdx, 0x38(%rsp)
    c653:      	movq	0x30(%rsp), %r12
    c658:      	cmpq	0x18(%rsp), %r12
    c65d:      	jne	0xc66a <generic_usdt_path+0x1d6a>
    c65f:      	cmpq	0x20(%rsp), %rdx
    c664:      	je	0x1636d <generic_usdt_path+0xba6d>
    c66a:      	movl	$0x4, %eax
    c66f:      	leaq	0x10(%rsp), %rdi
    c674:      	movl	$0x8, %esi
    c679:      	callq	*%rax
    c67b:      	cmpq	0x10(%rsp), %r12
    c680:      	je	0xc778 <generic_usdt_path+0x1e78>
    c686:      	leaq	0x18(%r12), %rbx
    c68b:      	movl	$0x4, %eax
    c690:      	movq	%rbp, %rdi
    c693:      	movl	$0x8, %esi
    c698:      	movq	%rbx, %rdx
    c69b:      	callq	*%rax
    c69d:      	cmpq	%r12, (%rsp)
    c6a1:      	je	0xc778 <generic_usdt_path+0x1e78>
    c6a7:      	movl	$0x4, %eax
    c6ac:      	leaq	0x8(%rsp), %rdi
    c6b1:      	movl	$0x8, %esi
    c6b6:      	movq	%rbx, %rdx
    c6b9:      	callq	*%rax
    c6bb:      	addq	$0x20, %r12
    c6bf:      	movl	$0x4, %eax
    c6c4:      	leaq	0x58(%rsp), %rdi
    c6c9:      	movl	$0x10, %ecx
    c6ce:      	movl	$0x10, %esi
    c6d3:      	movq	%r12, %rdx
    c6d6:      	callq	*%rax
    c6d8:      	movq	0x28(%rsp), %rbx
    c6dd:      	movq	0x48(%rsp), %rax
    c6e2:      	movl	0x5c(%rsp), %r15d
    c6e7:      	subq	%rbx, %rax
    c6ea:      	movl	0x50(%rsp), %r12d
    c6ef:      	movl	%r15d, %edx
    c6f2:      	subl	%r12d, %edx
    c6f5:      	movl	$0x0, %ecx
    c6fa:      	cmovbl	%ecx, %edx
    c6fd:      	addq	0x60(%rsp), %rdx
    c702:      	xorl	%esi, %esi
    c704:      	cmpl	%r15d, %r12d
    c707:      	seta	%sil
    c70b:      	movl	%r15d, %ecx
    c70e:      	cmovbl	%r12d, %ecx
    c712:      	addl	%ecx, %esi
    c714:      	movl	%r12d, %edi
    c717:      	subl	%esi, %edi
    c719:      	movl	%edi, 0x50(%rsp)
    c71d:      	subq	%rsi, %rax
    c720:      	jb	0x16372 <generic_usdt_path+0xba72>
    c726:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c72c:      	ja	0x16372 <generic_usdt_path+0xba72>
    c732:      	cmpl	%r15d, %r12d
    c735:      	jbe	0xc73b <generic_usdt_path+0x1e3b>
    c737:      	movb	$0x2f, (%rbx,%rax)
    c73b:      	xorl	%edi, %edi
    c73d:      	cmpl	%r15d, %r12d
    c740:      	seta	%dil
    c744:      	movzbl	%cl, %esi
    c747:      	addq	%rax, %rbx
    c74a:      	addq	%rbx, %rdi
    c74d:      	movl	$0x4, %eax
    c752:      	callq	*%rax
    c754:      	movq	%rbx, 0x48(%rsp)
    c759:      	cmpl	%r15d, %r12d
    c75c:      	jbe	0x16372 <generic_usdt_path+0xba72>
    c762:      	movq	0x8(%rsp), %r12
    c767:      	movq	%r12, 0x30(%rsp)
    c76c:      	movq	0x38(%rsp), %rdx
    c771:      	movq	0x40(%rsp), %r15
    c776:      	jmp	0xc7c9 <generic_usdt_path+0x1ec9>
    c778:      	leaq	0x10(%r15), %rdx
    c77c:      	movl	$0x4, %eax
    c781:      	movq	%rbp, %rdi
    c784:      	movl	$0x8, %esi
    c789:      	callq	*%rax
    c78b:      	movq	0x40(%rsp), %rax
    c790:      	cmpq	(%rsp), %rax
    c794:      	je	0x1636d <generic_usdt_path+0xba6d>
    c79a:      	addq	$0x18, %r15
    c79e:      	movl	$0x4, %eax
    c7a3:      	leaq	0x30(%rsp), %rdi
    c7a8:      	movl	$0x8, %esi
    c7ad:      	movq	%r15, %rdx
    c7b0:      	callq	*%rax
    c7b2:      	movq	(%rsp), %r15
    c7b6:      	movq	%r15, 0x40(%rsp)
    c7bb:      	leaq	0x20(%r15), %rdx
    c7bf:      	movq	%rdx, 0x38(%rsp)
    c7c4:      	movq	0x30(%rsp), %r12
    c7c9:      	cmpq	0x18(%rsp), %r12
    c7ce:      	jne	0xc7db <generic_usdt_path+0x1edb>
    c7d0:      	cmpq	0x20(%rsp), %rdx
    c7d5:      	je	0x1636d <generic_usdt_path+0xba6d>
    c7db:      	movl	$0x4, %eax
    c7e0:      	leaq	0x10(%rsp), %rdi
    c7e5:      	movl	$0x8, %esi
    c7ea:      	callq	*%rax
    c7ec:      	cmpq	0x10(%rsp), %r12
    c7f1:      	je	0xc8e9 <generic_usdt_path+0x1fe9>
    c7f7:      	leaq	0x18(%r12), %rbx
    c7fc:      	movl	$0x4, %eax
    c801:      	movq	%rbp, %rdi
    c804:      	movl	$0x8, %esi
    c809:      	movq	%rbx, %rdx
    c80c:      	callq	*%rax
    c80e:      	cmpq	%r12, (%rsp)
    c812:      	je	0xc8e9 <generic_usdt_path+0x1fe9>
    c818:      	movl	$0x4, %eax
    c81d:      	leaq	0x8(%rsp), %rdi
    c822:      	movl	$0x8, %esi
    c827:      	movq	%rbx, %rdx
    c82a:      	callq	*%rax
    c82c:      	addq	$0x20, %r12
    c830:      	movl	$0x4, %eax
    c835:      	leaq	0x58(%rsp), %rdi
    c83a:      	movl	$0x10, %ecx
    c83f:      	movl	$0x10, %esi
    c844:      	movq	%r12, %rdx
    c847:      	callq	*%rax
    c849:      	movq	0x28(%rsp), %rbx
    c84e:      	movq	0x48(%rsp), %rax
    c853:      	movl	0x5c(%rsp), %r15d
    c858:      	subq	%rbx, %rax
    c85b:      	movl	0x50(%rsp), %r12d
    c860:      	movl	%r15d, %edx
    c863:      	subl	%r12d, %edx
    c866:      	movl	$0x0, %ecx
    c86b:      	cmovbl	%ecx, %edx
    c86e:      	addq	0x60(%rsp), %rdx
    c873:      	xorl	%esi, %esi
    c875:      	cmpl	%r15d, %r12d
    c878:      	seta	%sil
    c87c:      	movl	%r15d, %ecx
    c87f:      	cmovbl	%r12d, %ecx
    c883:      	addl	%ecx, %esi
    c885:      	movl	%r12d, %edi
    c888:      	subl	%esi, %edi
    c88a:      	movl	%edi, 0x50(%rsp)
    c88e:      	subq	%rsi, %rax
    c891:      	jb	0x16372 <generic_usdt_path+0xba72>
    c897:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    c89d:      	ja	0x16372 <generic_usdt_path+0xba72>
    c8a3:      	cmpl	%r15d, %r12d
    c8a6:      	jbe	0xc8ac <generic_usdt_path+0x1fac>
    c8a8:      	movb	$0x2f, (%rbx,%rax)
    c8ac:      	xorl	%edi, %edi
    c8ae:      	cmpl	%r15d, %r12d
    c8b1:      	seta	%dil
    c8b5:      	movzbl	%cl, %esi
    c8b8:      	addq	%rax, %rbx
    c8bb:      	addq	%rbx, %rdi
    c8be:      	movl	$0x4, %eax
    c8c3:      	callq	*%rax
    c8c5:      	movq	%rbx, 0x48(%rsp)
    c8ca:      	cmpl	%r15d, %r12d
    c8cd:      	jbe	0x16372 <generic_usdt_path+0xba72>
    c8d3:      	movq	0x8(%rsp), %r12
    c8d8:      	movq	%r12, 0x30(%rsp)
    c8dd:      	movq	0x38(%rsp), %rdx
    c8e2:      	movq	0x40(%rsp), %r15
    c8e7:      	jmp	0xc93a <generic_usdt_path+0x203a>
    c8e9:      	leaq	0x10(%r15), %rdx
    c8ed:      	movl	$0x4, %eax
    c8f2:      	movq	%rbp, %rdi
    c8f5:      	movl	$0x8, %esi
    c8fa:      	callq	*%rax
    c8fc:      	movq	0x40(%rsp), %rax
    c901:      	cmpq	(%rsp), %rax
    c905:      	je	0x1636d <generic_usdt_path+0xba6d>
    c90b:      	addq	$0x18, %r15
    c90f:      	movl	$0x4, %eax
    c914:      	leaq	0x30(%rsp), %rdi
    c919:      	movl	$0x8, %esi
    c91e:      	movq	%r15, %rdx
    c921:      	callq	*%rax
    c923:      	movq	(%rsp), %r15
    c927:      	movq	%r15, 0x40(%rsp)
    c92c:      	leaq	0x20(%r15), %rdx
    c930:      	movq	%rdx, 0x38(%rsp)
    c935:      	movq	0x30(%rsp), %r12
    c93a:      	cmpq	0x18(%rsp), %r12
    c93f:      	jne	0xc94c <generic_usdt_path+0x204c>
    c941:      	cmpq	0x20(%rsp), %rdx
    c946:      	je	0x1636d <generic_usdt_path+0xba6d>
    c94c:      	movl	$0x4, %eax
    c951:      	leaq	0x10(%rsp), %rdi
    c956:      	movl	$0x8, %esi
    c95b:      	callq	*%rax
    c95d:      	cmpq	0x10(%rsp), %r12
    c962:      	je	0xca5a <generic_usdt_path+0x215a>
    c968:      	leaq	0x18(%r12), %rbx
    c96d:      	movl	$0x4, %eax
    c972:      	movq	%rbp, %rdi
    c975:      	movl	$0x8, %esi
    c97a:      	movq	%rbx, %rdx
    c97d:      	callq	*%rax
    c97f:      	cmpq	%r12, (%rsp)
    c983:      	je	0xca5a <generic_usdt_path+0x215a>
    c989:      	movl	$0x4, %eax
    c98e:      	leaq	0x8(%rsp), %rdi
    c993:      	movl	$0x8, %esi
    c998:      	movq	%rbx, %rdx
    c99b:      	callq	*%rax
    c99d:      	addq	$0x20, %r12
    c9a1:      	movl	$0x4, %eax
    c9a6:      	leaq	0x58(%rsp), %rdi
    c9ab:      	movl	$0x10, %ecx
    c9b0:      	movl	$0x10, %esi
    c9b5:      	movq	%r12, %rdx
    c9b8:      	callq	*%rax
    c9ba:      	movq	0x28(%rsp), %rbx
    c9bf:      	movq	0x48(%rsp), %rax
    c9c4:      	movl	0x5c(%rsp), %r15d
    c9c9:      	subq	%rbx, %rax
    c9cc:      	movl	0x50(%rsp), %r12d
    c9d1:      	movl	%r15d, %edx
    c9d4:      	subl	%r12d, %edx
    c9d7:      	movl	$0x0, %ecx
    c9dc:      	cmovbl	%ecx, %edx
    c9df:      	addq	0x60(%rsp), %rdx
    c9e4:      	xorl	%esi, %esi
    c9e6:      	cmpl	%r15d, %r12d
    c9e9:      	seta	%sil
    c9ed:      	movl	%r15d, %ecx
    c9f0:      	cmovbl	%r12d, %ecx
    c9f4:      	addl	%ecx, %esi
    c9f6:      	movl	%r12d, %edi
    c9f9:      	subl	%esi, %edi
    c9fb:      	movl	%edi, 0x50(%rsp)
    c9ff:      	subq	%rsi, %rax
    ca02:      	jb	0x16372 <generic_usdt_path+0xba72>
    ca08:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ca0e:      	ja	0x16372 <generic_usdt_path+0xba72>
    ca14:      	cmpl	%r15d, %r12d
    ca17:      	jbe	0xca1d <generic_usdt_path+0x211d>
    ca19:      	movb	$0x2f, (%rbx,%rax)
    ca1d:      	xorl	%edi, %edi
    ca1f:      	cmpl	%r15d, %r12d
    ca22:      	seta	%dil
    ca26:      	movzbl	%cl, %esi
    ca29:      	addq	%rax, %rbx
    ca2c:      	addq	%rbx, %rdi
    ca2f:      	movl	$0x4, %eax
    ca34:      	callq	*%rax
    ca36:      	movq	%rbx, 0x48(%rsp)
    ca3b:      	cmpl	%r15d, %r12d
    ca3e:      	jbe	0x16372 <generic_usdt_path+0xba72>
    ca44:      	movq	0x8(%rsp), %r12
    ca49:      	movq	%r12, 0x30(%rsp)
    ca4e:      	movq	0x38(%rsp), %rdx
    ca53:      	movq	0x40(%rsp), %r15
    ca58:      	jmp	0xcaab <generic_usdt_path+0x21ab>
    ca5a:      	leaq	0x10(%r15), %rdx
    ca5e:      	movl	$0x4, %eax
    ca63:      	movq	%rbp, %rdi
    ca66:      	movl	$0x8, %esi
    ca6b:      	callq	*%rax
    ca6d:      	movq	0x40(%rsp), %rax
    ca72:      	cmpq	(%rsp), %rax
    ca76:      	je	0x1636d <generic_usdt_path+0xba6d>
    ca7c:      	addq	$0x18, %r15
    ca80:      	movl	$0x4, %eax
    ca85:      	leaq	0x30(%rsp), %rdi
    ca8a:      	movl	$0x8, %esi
    ca8f:      	movq	%r15, %rdx
    ca92:      	callq	*%rax
    ca94:      	movq	(%rsp), %r15
    ca98:      	movq	%r15, 0x40(%rsp)
    ca9d:      	leaq	0x20(%r15), %rdx
    caa1:      	movq	%rdx, 0x38(%rsp)
    caa6:      	movq	0x30(%rsp), %r12
    caab:      	cmpq	0x18(%rsp), %r12
    cab0:      	jne	0xcabd <generic_usdt_path+0x21bd>
    cab2:      	cmpq	0x20(%rsp), %rdx
    cab7:      	je	0x1636d <generic_usdt_path+0xba6d>
    cabd:      	movl	$0x4, %eax
    cac2:      	leaq	0x10(%rsp), %rdi
    cac7:      	movl	$0x8, %esi
    cacc:      	callq	*%rax
    cace:      	cmpq	0x10(%rsp), %r12
    cad3:      	je	0xcbcb <generic_usdt_path+0x22cb>
    cad9:      	leaq	0x18(%r12), %rbx
    cade:      	movl	$0x4, %eax
    cae3:      	movq	%rbp, %rdi
    cae6:      	movl	$0x8, %esi
    caeb:      	movq	%rbx, %rdx
    caee:      	callq	*%rax
    caf0:      	cmpq	%r12, (%rsp)
    caf4:      	je	0xcbcb <generic_usdt_path+0x22cb>
    cafa:      	movl	$0x4, %eax
    caff:      	leaq	0x8(%rsp), %rdi
    cb04:      	movl	$0x8, %esi
    cb09:      	movq	%rbx, %rdx
    cb0c:      	callq	*%rax
    cb0e:      	addq	$0x20, %r12
    cb12:      	movl	$0x4, %eax
    cb17:      	leaq	0x58(%rsp), %rdi
    cb1c:      	movl	$0x10, %ecx
    cb21:      	movl	$0x10, %esi
    cb26:      	movq	%r12, %rdx
    cb29:      	callq	*%rax
    cb2b:      	movq	0x28(%rsp), %rbx
    cb30:      	movq	0x48(%rsp), %rax
    cb35:      	movl	0x5c(%rsp), %r15d
    cb3a:      	subq	%rbx, %rax
    cb3d:      	movl	0x50(%rsp), %r12d
    cb42:      	movl	%r15d, %edx
    cb45:      	subl	%r12d, %edx
    cb48:      	movl	$0x0, %ecx
    cb4d:      	cmovbl	%ecx, %edx
    cb50:      	addq	0x60(%rsp), %rdx
    cb55:      	xorl	%esi, %esi
    cb57:      	cmpl	%r15d, %r12d
    cb5a:      	seta	%sil
    cb5e:      	movl	%r15d, %ecx
    cb61:      	cmovbl	%r12d, %ecx
    cb65:      	addl	%ecx, %esi
    cb67:      	movl	%r12d, %edi
    cb6a:      	subl	%esi, %edi
    cb6c:      	movl	%edi, 0x50(%rsp)
    cb70:      	subq	%rsi, %rax
    cb73:      	jb	0x16372 <generic_usdt_path+0xba72>
    cb79:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    cb7f:      	ja	0x16372 <generic_usdt_path+0xba72>
    cb85:      	cmpl	%r15d, %r12d
    cb88:      	jbe	0xcb8e <generic_usdt_path+0x228e>
    cb8a:      	movb	$0x2f, (%rbx,%rax)
    cb8e:      	xorl	%edi, %edi
    cb90:      	cmpl	%r15d, %r12d
    cb93:      	seta	%dil
    cb97:      	movzbl	%cl, %esi
    cb9a:      	addq	%rax, %rbx
    cb9d:      	addq	%rbx, %rdi
    cba0:      	movl	$0x4, %eax
    cba5:      	callq	*%rax
    cba7:      	movq	%rbx, 0x48(%rsp)
    cbac:      	cmpl	%r15d, %r12d
    cbaf:      	jbe	0x16372 <generic_usdt_path+0xba72>
    cbb5:      	movq	0x8(%rsp), %r12
    cbba:      	movq	%r12, 0x30(%rsp)
    cbbf:      	movq	0x38(%rsp), %rdx
    cbc4:      	movq	0x40(%rsp), %r15
    cbc9:      	jmp	0xcc1c <generic_usdt_path+0x231c>
    cbcb:      	leaq	0x10(%r15), %rdx
    cbcf:      	movl	$0x4, %eax
    cbd4:      	movq	%rbp, %rdi
    cbd7:      	movl	$0x8, %esi
    cbdc:      	callq	*%rax
    cbde:      	movq	0x40(%rsp), %rax
    cbe3:      	cmpq	(%rsp), %rax
    cbe7:      	je	0x1636d <generic_usdt_path+0xba6d>
    cbed:      	addq	$0x18, %r15
    cbf1:      	movl	$0x4, %eax
    cbf6:      	leaq	0x30(%rsp), %rdi
    cbfb:      	movl	$0x8, %esi
    cc00:      	movq	%r15, %rdx
    cc03:      	callq	*%rax
    cc05:      	movq	(%rsp), %r15
    cc09:      	movq	%r15, 0x40(%rsp)
    cc0e:      	leaq	0x20(%r15), %rdx
    cc12:      	movq	%rdx, 0x38(%rsp)
    cc17:      	movq	0x30(%rsp), %r12
    cc1c:      	cmpq	0x18(%rsp), %r12
    cc21:      	jne	0xcc2e <generic_usdt_path+0x232e>
    cc23:      	cmpq	0x20(%rsp), %rdx
    cc28:      	je	0x1636d <generic_usdt_path+0xba6d>
    cc2e:      	movl	$0x4, %eax
    cc33:      	leaq	0x10(%rsp), %rdi
    cc38:      	movl	$0x8, %esi
    cc3d:      	callq	*%rax
    cc3f:      	cmpq	0x10(%rsp), %r12
    cc44:      	je	0xcd3c <generic_usdt_path+0x243c>
    cc4a:      	leaq	0x18(%r12), %rbx
    cc4f:      	movl	$0x4, %eax
    cc54:      	movq	%rbp, %rdi
    cc57:      	movl	$0x8, %esi
    cc5c:      	movq	%rbx, %rdx
    cc5f:      	callq	*%rax
    cc61:      	cmpq	%r12, (%rsp)
    cc65:      	je	0xcd3c <generic_usdt_path+0x243c>
    cc6b:      	movl	$0x4, %eax
    cc70:      	leaq	0x8(%rsp), %rdi
    cc75:      	movl	$0x8, %esi
    cc7a:      	movq	%rbx, %rdx
    cc7d:      	callq	*%rax
    cc7f:      	addq	$0x20, %r12
    cc83:      	movl	$0x4, %eax
    cc88:      	leaq	0x58(%rsp), %rdi
    cc8d:      	movl	$0x10, %ecx
    cc92:      	movl	$0x10, %esi
    cc97:      	movq	%r12, %rdx
    cc9a:      	callq	*%rax
    cc9c:      	movq	0x28(%rsp), %rbx
    cca1:      	movq	0x48(%rsp), %rax
    cca6:      	movl	0x5c(%rsp), %r15d
    ccab:      	subq	%rbx, %rax
    ccae:      	movl	0x50(%rsp), %r12d
    ccb3:      	movl	%r15d, %edx
    ccb6:      	subl	%r12d, %edx
    ccb9:      	movl	$0x0, %ecx
    ccbe:      	cmovbl	%ecx, %edx
    ccc1:      	addq	0x60(%rsp), %rdx
    ccc6:      	xorl	%esi, %esi
    ccc8:      	cmpl	%r15d, %r12d
    cccb:      	seta	%sil
    cccf:      	movl	%r15d, %ecx
    ccd2:      	cmovbl	%r12d, %ecx
    ccd6:      	addl	%ecx, %esi
    ccd8:      	movl	%r12d, %edi
    ccdb:      	subl	%esi, %edi
    ccdd:      	movl	%edi, 0x50(%rsp)
    cce1:      	subq	%rsi, %rax
    cce4:      	jb	0x16372 <generic_usdt_path+0xba72>
    ccea:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ccf0:      	ja	0x16372 <generic_usdt_path+0xba72>
    ccf6:      	cmpl	%r15d, %r12d
    ccf9:      	jbe	0xccff <generic_usdt_path+0x23ff>
    ccfb:      	movb	$0x2f, (%rbx,%rax)
    ccff:      	xorl	%edi, %edi
    cd01:      	cmpl	%r15d, %r12d
    cd04:      	seta	%dil
    cd08:      	movzbl	%cl, %esi
    cd0b:      	addq	%rax, %rbx
    cd0e:      	addq	%rbx, %rdi
    cd11:      	movl	$0x4, %eax
    cd16:      	callq	*%rax
    cd18:      	movq	%rbx, 0x48(%rsp)
    cd1d:      	cmpl	%r15d, %r12d
    cd20:      	jbe	0x16372 <generic_usdt_path+0xba72>
    cd26:      	movq	0x8(%rsp), %r12
    cd2b:      	movq	%r12, 0x30(%rsp)
    cd30:      	movq	0x38(%rsp), %rdx
    cd35:      	movq	0x40(%rsp), %r15
    cd3a:      	jmp	0xcd8d <generic_usdt_path+0x248d>
    cd3c:      	leaq	0x10(%r15), %rdx
    cd40:      	movl	$0x4, %eax
    cd45:      	movq	%rbp, %rdi
    cd48:      	movl	$0x8, %esi
    cd4d:      	callq	*%rax
    cd4f:      	movq	0x40(%rsp), %rax
    cd54:      	cmpq	(%rsp), %rax
    cd58:      	je	0x1636d <generic_usdt_path+0xba6d>
    cd5e:      	addq	$0x18, %r15
    cd62:      	movl	$0x4, %eax
    cd67:      	leaq	0x30(%rsp), %rdi
    cd6c:      	movl	$0x8, %esi
    cd71:      	movq	%r15, %rdx
    cd74:      	callq	*%rax
    cd76:      	movq	(%rsp), %r15
    cd7a:      	movq	%r15, 0x40(%rsp)
    cd7f:      	leaq	0x20(%r15), %rdx
    cd83:      	movq	%rdx, 0x38(%rsp)
    cd88:      	movq	0x30(%rsp), %r12
    cd8d:      	cmpq	0x18(%rsp), %r12
    cd92:      	jne	0xcd9f <generic_usdt_path+0x249f>
    cd94:      	cmpq	0x20(%rsp), %rdx
    cd99:      	je	0x1636d <generic_usdt_path+0xba6d>
    cd9f:      	movl	$0x4, %eax
    cda4:      	leaq	0x10(%rsp), %rdi
    cda9:      	movl	$0x8, %esi
    cdae:      	callq	*%rax
    cdb0:      	cmpq	0x10(%rsp), %r12
    cdb5:      	je	0xcead <generic_usdt_path+0x25ad>
    cdbb:      	leaq	0x18(%r12), %rbx
    cdc0:      	movl	$0x4, %eax
    cdc5:      	movq	%rbp, %rdi
    cdc8:      	movl	$0x8, %esi
    cdcd:      	movq	%rbx, %rdx
    cdd0:      	callq	*%rax
    cdd2:      	cmpq	%r12, (%rsp)
    cdd6:      	je	0xcead <generic_usdt_path+0x25ad>
    cddc:      	movl	$0x4, %eax
    cde1:      	leaq	0x8(%rsp), %rdi
    cde6:      	movl	$0x8, %esi
    cdeb:      	movq	%rbx, %rdx
    cdee:      	callq	*%rax
    cdf0:      	addq	$0x20, %r12
    cdf4:      	movl	$0x4, %eax
    cdf9:      	leaq	0x58(%rsp), %rdi
    cdfe:      	movl	$0x10, %ecx
    ce03:      	movl	$0x10, %esi
    ce08:      	movq	%r12, %rdx
    ce0b:      	callq	*%rax
    ce0d:      	movq	0x28(%rsp), %rbx
    ce12:      	movq	0x48(%rsp), %rax
    ce17:      	movl	0x5c(%rsp), %r15d
    ce1c:      	subq	%rbx, %rax
    ce1f:      	movl	0x50(%rsp), %r12d
    ce24:      	movl	%r15d, %edx
    ce27:      	subl	%r12d, %edx
    ce2a:      	movl	$0x0, %ecx
    ce2f:      	cmovbl	%ecx, %edx
    ce32:      	addq	0x60(%rsp), %rdx
    ce37:      	xorl	%esi, %esi
    ce39:      	cmpl	%r15d, %r12d
    ce3c:      	seta	%sil
    ce40:      	movl	%r15d, %ecx
    ce43:      	cmovbl	%r12d, %ecx
    ce47:      	addl	%ecx, %esi
    ce49:      	movl	%r12d, %edi
    ce4c:      	subl	%esi, %edi
    ce4e:      	movl	%edi, 0x50(%rsp)
    ce52:      	subq	%rsi, %rax
    ce55:      	jb	0x16372 <generic_usdt_path+0xba72>
    ce5b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ce61:      	ja	0x16372 <generic_usdt_path+0xba72>
    ce67:      	cmpl	%r15d, %r12d
    ce6a:      	jbe	0xce70 <generic_usdt_path+0x2570>
    ce6c:      	movb	$0x2f, (%rbx,%rax)
    ce70:      	xorl	%edi, %edi
    ce72:      	cmpl	%r15d, %r12d
    ce75:      	seta	%dil
    ce79:      	movzbl	%cl, %esi
    ce7c:      	addq	%rax, %rbx
    ce7f:      	addq	%rbx, %rdi
    ce82:      	movl	$0x4, %eax
    ce87:      	callq	*%rax
    ce89:      	movq	%rbx, 0x48(%rsp)
    ce8e:      	cmpl	%r15d, %r12d
    ce91:      	jbe	0x16372 <generic_usdt_path+0xba72>
    ce97:      	movq	0x8(%rsp), %r12
    ce9c:      	movq	%r12, 0x30(%rsp)
    cea1:      	movq	0x38(%rsp), %rdx
    cea6:      	movq	0x40(%rsp), %r15
    ceab:      	jmp	0xcefe <generic_usdt_path+0x25fe>
    cead:      	leaq	0x10(%r15), %rdx
    ceb1:      	movl	$0x4, %eax
    ceb6:      	movq	%rbp, %rdi
    ceb9:      	movl	$0x8, %esi
    cebe:      	callq	*%rax
    cec0:      	movq	0x40(%rsp), %rax
    cec5:      	cmpq	(%rsp), %rax
    cec9:      	je	0x1636d <generic_usdt_path+0xba6d>
    cecf:      	addq	$0x18, %r15
    ced3:      	movl	$0x4, %eax
    ced8:      	leaq	0x30(%rsp), %rdi
    cedd:      	movl	$0x8, %esi
    cee2:      	movq	%r15, %rdx
    cee5:      	callq	*%rax
    cee7:      	movq	(%rsp), %r15
    ceeb:      	movq	%r15, 0x40(%rsp)
    cef0:      	leaq	0x20(%r15), %rdx
    cef4:      	movq	%rdx, 0x38(%rsp)
    cef9:      	movq	0x30(%rsp), %r12
    cefe:      	cmpq	0x18(%rsp), %r12
    cf03:      	jne	0xcf10 <generic_usdt_path+0x2610>
    cf05:      	cmpq	0x20(%rsp), %rdx
    cf0a:      	je	0x1636d <generic_usdt_path+0xba6d>
    cf10:      	movl	$0x4, %eax
    cf15:      	leaq	0x10(%rsp), %rdi
    cf1a:      	movl	$0x8, %esi
    cf1f:      	callq	*%rax
    cf21:      	cmpq	0x10(%rsp), %r12
    cf26:      	je	0xd01e <generic_usdt_path+0x271e>
    cf2c:      	leaq	0x18(%r12), %rbx
    cf31:      	movl	$0x4, %eax
    cf36:      	movq	%rbp, %rdi
    cf39:      	movl	$0x8, %esi
    cf3e:      	movq	%rbx, %rdx
    cf41:      	callq	*%rax
    cf43:      	cmpq	%r12, (%rsp)
    cf47:      	je	0xd01e <generic_usdt_path+0x271e>
    cf4d:      	movl	$0x4, %eax
    cf52:      	leaq	0x8(%rsp), %rdi
    cf57:      	movl	$0x8, %esi
    cf5c:      	movq	%rbx, %rdx
    cf5f:      	callq	*%rax
    cf61:      	addq	$0x20, %r12
    cf65:      	movl	$0x4, %eax
    cf6a:      	leaq	0x58(%rsp), %rdi
    cf6f:      	movl	$0x10, %ecx
    cf74:      	movl	$0x10, %esi
    cf79:      	movq	%r12, %rdx
    cf7c:      	callq	*%rax
    cf7e:      	movq	0x28(%rsp), %rbx
    cf83:      	movq	0x48(%rsp), %rax
    cf88:      	movl	0x5c(%rsp), %r15d
    cf8d:      	subq	%rbx, %rax
    cf90:      	movl	0x50(%rsp), %r12d
    cf95:      	movl	%r15d, %edx
    cf98:      	subl	%r12d, %edx
    cf9b:      	movl	$0x0, %ecx
    cfa0:      	cmovbl	%ecx, %edx
    cfa3:      	addq	0x60(%rsp), %rdx
    cfa8:      	xorl	%esi, %esi
    cfaa:      	cmpl	%r15d, %r12d
    cfad:      	seta	%sil
    cfb1:      	movl	%r15d, %ecx
    cfb4:      	cmovbl	%r12d, %ecx
    cfb8:      	addl	%ecx, %esi
    cfba:      	movl	%r12d, %edi
    cfbd:      	subl	%esi, %edi
    cfbf:      	movl	%edi, 0x50(%rsp)
    cfc3:      	subq	%rsi, %rax
    cfc6:      	jb	0x16372 <generic_usdt_path+0xba72>
    cfcc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    cfd2:      	ja	0x16372 <generic_usdt_path+0xba72>
    cfd8:      	cmpl	%r15d, %r12d
    cfdb:      	jbe	0xcfe1 <generic_usdt_path+0x26e1>
    cfdd:      	movb	$0x2f, (%rbx,%rax)
    cfe1:      	xorl	%edi, %edi
    cfe3:      	cmpl	%r15d, %r12d
    cfe6:      	seta	%dil
    cfea:      	movzbl	%cl, %esi
    cfed:      	addq	%rax, %rbx
    cff0:      	addq	%rbx, %rdi
    cff3:      	movl	$0x4, %eax
    cff8:      	callq	*%rax
    cffa:      	movq	%rbx, 0x48(%rsp)
    cfff:      	cmpl	%r15d, %r12d
    d002:      	jbe	0x16372 <generic_usdt_path+0xba72>
    d008:      	movq	0x8(%rsp), %r12
    d00d:      	movq	%r12, 0x30(%rsp)
    d012:      	movq	0x38(%rsp), %rdx
    d017:      	movq	0x40(%rsp), %r15
    d01c:      	jmp	0xd06f <generic_usdt_path+0x276f>
    d01e:      	leaq	0x10(%r15), %rdx
    d022:      	movl	$0x4, %eax
    d027:      	movq	%rbp, %rdi
    d02a:      	movl	$0x8, %esi
    d02f:      	callq	*%rax
    d031:      	movq	0x40(%rsp), %rax
    d036:      	cmpq	(%rsp), %rax
    d03a:      	je	0x1636d <generic_usdt_path+0xba6d>
    d040:      	addq	$0x18, %r15
    d044:      	movl	$0x4, %eax
    d049:      	leaq	0x30(%rsp), %rdi
    d04e:      	movl	$0x8, %esi
    d053:      	movq	%r15, %rdx
    d056:      	callq	*%rax
    d058:      	movq	(%rsp), %r15
    d05c:      	movq	%r15, 0x40(%rsp)
    d061:      	leaq	0x20(%r15), %rdx
    d065:      	movq	%rdx, 0x38(%rsp)
    d06a:      	movq	0x30(%rsp), %r12
    d06f:      	cmpq	0x18(%rsp), %r12
    d074:      	jne	0xd081 <generic_usdt_path+0x2781>
    d076:      	cmpq	0x20(%rsp), %rdx
    d07b:      	je	0x1636d <generic_usdt_path+0xba6d>
    d081:      	movl	$0x4, %eax
    d086:      	leaq	0x10(%rsp), %rdi
    d08b:      	movl	$0x8, %esi
    d090:      	callq	*%rax
    d092:      	cmpq	0x10(%rsp), %r12
    d097:      	je	0xd18f <generic_usdt_path+0x288f>
    d09d:      	leaq	0x18(%r12), %rbx
    d0a2:      	movl	$0x4, %eax
    d0a7:      	movq	%rbp, %rdi
    d0aa:      	movl	$0x8, %esi
    d0af:      	movq	%rbx, %rdx
    d0b2:      	callq	*%rax
    d0b4:      	cmpq	%r12, (%rsp)
    d0b8:      	je	0xd18f <generic_usdt_path+0x288f>
    d0be:      	movl	$0x4, %eax
    d0c3:      	leaq	0x8(%rsp), %rdi
    d0c8:      	movl	$0x8, %esi
    d0cd:      	movq	%rbx, %rdx
    d0d0:      	callq	*%rax
    d0d2:      	addq	$0x20, %r12
    d0d6:      	movl	$0x4, %eax
    d0db:      	leaq	0x58(%rsp), %rdi
    d0e0:      	movl	$0x10, %ecx
    d0e5:      	movl	$0x10, %esi
    d0ea:      	movq	%r12, %rdx
    d0ed:      	callq	*%rax
    d0ef:      	movq	0x28(%rsp), %rbx
    d0f4:      	movq	0x48(%rsp), %rax
    d0f9:      	movl	0x5c(%rsp), %r15d
    d0fe:      	subq	%rbx, %rax
    d101:      	movl	0x50(%rsp), %r12d
    d106:      	movl	%r15d, %edx
    d109:      	subl	%r12d, %edx
    d10c:      	movl	$0x0, %ecx
    d111:      	cmovbl	%ecx, %edx
    d114:      	addq	0x60(%rsp), %rdx
    d119:      	xorl	%esi, %esi
    d11b:      	cmpl	%r15d, %r12d
    d11e:      	seta	%sil
    d122:      	movl	%r15d, %ecx
    d125:      	cmovbl	%r12d, %ecx
    d129:      	addl	%ecx, %esi
    d12b:      	movl	%r12d, %edi
    d12e:      	subl	%esi, %edi
    d130:      	movl	%edi, 0x50(%rsp)
    d134:      	subq	%rsi, %rax
    d137:      	jb	0x16372 <generic_usdt_path+0xba72>
    d13d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d143:      	ja	0x16372 <generic_usdt_path+0xba72>
    d149:      	cmpl	%r15d, %r12d
    d14c:      	jbe	0xd152 <generic_usdt_path+0x2852>
    d14e:      	movb	$0x2f, (%rbx,%rax)
    d152:      	xorl	%edi, %edi
    d154:      	cmpl	%r15d, %r12d
    d157:      	seta	%dil
    d15b:      	movzbl	%cl, %esi
    d15e:      	addq	%rax, %rbx
    d161:      	addq	%rbx, %rdi
    d164:      	movl	$0x4, %eax
    d169:      	callq	*%rax
    d16b:      	movq	%rbx, 0x48(%rsp)
    d170:      	cmpl	%r15d, %r12d
    d173:      	jbe	0x16372 <generic_usdt_path+0xba72>
    d179:      	movq	0x8(%rsp), %r12
    d17e:      	movq	%r12, 0x30(%rsp)
    d183:      	movq	0x38(%rsp), %rdx
    d188:      	movq	0x40(%rsp), %r15
    d18d:      	jmp	0xd1e0 <generic_usdt_path+0x28e0>
    d18f:      	leaq	0x10(%r15), %rdx
    d193:      	movl	$0x4, %eax
    d198:      	movq	%rbp, %rdi
    d19b:      	movl	$0x8, %esi
    d1a0:      	callq	*%rax
    d1a2:      	movq	0x40(%rsp), %rax
    d1a7:      	cmpq	(%rsp), %rax
    d1ab:      	je	0x1636d <generic_usdt_path+0xba6d>
    d1b1:      	addq	$0x18, %r15
    d1b5:      	movl	$0x4, %eax
    d1ba:      	leaq	0x30(%rsp), %rdi
    d1bf:      	movl	$0x8, %esi
    d1c4:      	movq	%r15, %rdx
    d1c7:      	callq	*%rax
    d1c9:      	movq	(%rsp), %r15
    d1cd:      	movq	%r15, 0x40(%rsp)
    d1d2:      	leaq	0x20(%r15), %rdx
    d1d6:      	movq	%rdx, 0x38(%rsp)
    d1db:      	movq	0x30(%rsp), %r12
    d1e0:      	cmpq	0x18(%rsp), %r12
    d1e5:      	jne	0xd1f2 <generic_usdt_path+0x28f2>
    d1e7:      	cmpq	0x20(%rsp), %rdx
    d1ec:      	je	0x1636d <generic_usdt_path+0xba6d>
    d1f2:      	movl	$0x4, %eax
    d1f7:      	leaq	0x10(%rsp), %rdi
    d1fc:      	movl	$0x8, %esi
    d201:      	callq	*%rax
    d203:      	cmpq	0x10(%rsp), %r12
    d208:      	je	0xd300 <generic_usdt_path+0x2a00>
    d20e:      	leaq	0x18(%r12), %rbx
    d213:      	movl	$0x4, %eax
    d218:      	movq	%rbp, %rdi
    d21b:      	movl	$0x8, %esi
    d220:      	movq	%rbx, %rdx
    d223:      	callq	*%rax
    d225:      	cmpq	%r12, (%rsp)
    d229:      	je	0xd300 <generic_usdt_path+0x2a00>
    d22f:      	movl	$0x4, %eax
    d234:      	leaq	0x8(%rsp), %rdi
    d239:      	movl	$0x8, %esi
    d23e:      	movq	%rbx, %rdx
    d241:      	callq	*%rax
    d243:      	addq	$0x20, %r12
    d247:      	movl	$0x4, %eax
    d24c:      	leaq	0x58(%rsp), %rdi
    d251:      	movl	$0x10, %ecx
    d256:      	movl	$0x10, %esi
    d25b:      	movq	%r12, %rdx
    d25e:      	callq	*%rax
    d260:      	movq	0x28(%rsp), %rbx
    d265:      	movq	0x48(%rsp), %rax
    d26a:      	movl	0x5c(%rsp), %r15d
    d26f:      	subq	%rbx, %rax
    d272:      	movl	0x50(%rsp), %r12d
    d277:      	movl	%r15d, %edx
    d27a:      	subl	%r12d, %edx
    d27d:      	movl	$0x0, %ecx
    d282:      	cmovbl	%ecx, %edx
    d285:      	addq	0x60(%rsp), %rdx
    d28a:      	xorl	%esi, %esi
    d28c:      	cmpl	%r15d, %r12d
    d28f:      	seta	%sil
    d293:      	movl	%r15d, %ecx
    d296:      	cmovbl	%r12d, %ecx
    d29a:      	addl	%ecx, %esi
    d29c:      	movl	%r12d, %edi
    d29f:      	subl	%esi, %edi
    d2a1:      	movl	%edi, 0x50(%rsp)
    d2a5:      	subq	%rsi, %rax
    d2a8:      	jb	0x16372 <generic_usdt_path+0xba72>
    d2ae:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d2b4:      	ja	0x16372 <generic_usdt_path+0xba72>
    d2ba:      	cmpl	%r15d, %r12d
    d2bd:      	jbe	0xd2c3 <generic_usdt_path+0x29c3>
    d2bf:      	movb	$0x2f, (%rbx,%rax)
    d2c3:      	xorl	%edi, %edi
    d2c5:      	cmpl	%r15d, %r12d
    d2c8:      	seta	%dil
    d2cc:      	movzbl	%cl, %esi
    d2cf:      	addq	%rax, %rbx
    d2d2:      	addq	%rbx, %rdi
    d2d5:      	movl	$0x4, %eax
    d2da:      	callq	*%rax
    d2dc:      	movq	%rbx, 0x48(%rsp)
    d2e1:      	cmpl	%r15d, %r12d
    d2e4:      	jbe	0x16372 <generic_usdt_path+0xba72>
    d2ea:      	movq	0x8(%rsp), %r12
    d2ef:      	movq	%r12, 0x30(%rsp)
    d2f4:      	movq	0x38(%rsp), %rdx
    d2f9:      	movq	0x40(%rsp), %r15
    d2fe:      	jmp	0xd351 <generic_usdt_path+0x2a51>
    d300:      	leaq	0x10(%r15), %rdx
    d304:      	movl	$0x4, %eax
    d309:      	movq	%rbp, %rdi
    d30c:      	movl	$0x8, %esi
    d311:      	callq	*%rax
    d313:      	movq	0x40(%rsp), %rax
    d318:      	cmpq	(%rsp), %rax
    d31c:      	je	0x1636d <generic_usdt_path+0xba6d>
    d322:      	addq	$0x18, %r15
    d326:      	movl	$0x4, %eax
    d32b:      	leaq	0x30(%rsp), %rdi
    d330:      	movl	$0x8, %esi
    d335:      	movq	%r15, %rdx
    d338:      	callq	*%rax
    d33a:      	movq	(%rsp), %r15
    d33e:      	movq	%r15, 0x40(%rsp)
    d343:      	leaq	0x20(%r15), %rdx
    d347:      	movq	%rdx, 0x38(%rsp)
    d34c:      	movq	0x30(%rsp), %r12
    d351:      	cmpq	0x18(%rsp), %r12
    d356:      	jne	0xd363 <generic_usdt_path+0x2a63>
    d358:      	cmpq	0x20(%rsp), %rdx
    d35d:      	je	0x1636d <generic_usdt_path+0xba6d>
    d363:      	movl	$0x4, %eax
    d368:      	leaq	0x10(%rsp), %rdi
    d36d:      	movl	$0x8, %esi
    d372:      	callq	*%rax
    d374:      	cmpq	0x10(%rsp), %r12
    d379:      	je	0xd471 <generic_usdt_path+0x2b71>
    d37f:      	leaq	0x18(%r12), %rbx
    d384:      	movl	$0x4, %eax
    d389:      	movq	%rbp, %rdi
    d38c:      	movl	$0x8, %esi
    d391:      	movq	%rbx, %rdx
    d394:      	callq	*%rax
    d396:      	cmpq	%r12, (%rsp)
    d39a:      	je	0xd471 <generic_usdt_path+0x2b71>
    d3a0:      	movl	$0x4, %eax
    d3a5:      	leaq	0x8(%rsp), %rdi
    d3aa:      	movl	$0x8, %esi
    d3af:      	movq	%rbx, %rdx
    d3b2:      	callq	*%rax
    d3b4:      	addq	$0x20, %r12
    d3b8:      	movl	$0x4, %eax
    d3bd:      	leaq	0x58(%rsp), %rdi
    d3c2:      	movl	$0x10, %ecx
    d3c7:      	movl	$0x10, %esi
    d3cc:      	movq	%r12, %rdx
    d3cf:      	callq	*%rax
    d3d1:      	movq	0x28(%rsp), %rbx
    d3d6:      	movq	0x48(%rsp), %rax
    d3db:      	movl	0x5c(%rsp), %r15d
    d3e0:      	subq	%rbx, %rax
    d3e3:      	movl	0x50(%rsp), %r12d
    d3e8:      	movl	%r15d, %edx
    d3eb:      	subl	%r12d, %edx
    d3ee:      	movl	$0x0, %ecx
    d3f3:      	cmovbl	%ecx, %edx
    d3f6:      	addq	0x60(%rsp), %rdx
    d3fb:      	xorl	%esi, %esi
    d3fd:      	cmpl	%r15d, %r12d
    d400:      	seta	%sil
    d404:      	movl	%r15d, %ecx
    d407:      	cmovbl	%r12d, %ecx
    d40b:      	addl	%ecx, %esi
    d40d:      	movl	%r12d, %edi
    d410:      	subl	%esi, %edi
    d412:      	movl	%edi, 0x50(%rsp)
    d416:      	subq	%rsi, %rax
    d419:      	jb	0x16372 <generic_usdt_path+0xba72>
    d41f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d425:      	ja	0x16372 <generic_usdt_path+0xba72>
    d42b:      	cmpl	%r15d, %r12d
    d42e:      	jbe	0xd434 <generic_usdt_path+0x2b34>
    d430:      	movb	$0x2f, (%rbx,%rax)
    d434:      	xorl	%edi, %edi
    d436:      	cmpl	%r15d, %r12d
    d439:      	seta	%dil
    d43d:      	movzbl	%cl, %esi
    d440:      	addq	%rax, %rbx
    d443:      	addq	%rbx, %rdi
    d446:      	movl	$0x4, %eax
    d44b:      	callq	*%rax
    d44d:      	movq	%rbx, 0x48(%rsp)
    d452:      	cmpl	%r15d, %r12d
    d455:      	jbe	0x16372 <generic_usdt_path+0xba72>
    d45b:      	movq	0x8(%rsp), %r12
    d460:      	movq	%r12, 0x30(%rsp)
    d465:      	movq	0x38(%rsp), %rdx
    d46a:      	movq	0x40(%rsp), %r15
    d46f:      	jmp	0xd4c2 <generic_usdt_path+0x2bc2>
    d471:      	leaq	0x10(%r15), %rdx
    d475:      	movl	$0x4, %eax
    d47a:      	movq	%rbp, %rdi
    d47d:      	movl	$0x8, %esi
    d482:      	callq	*%rax
    d484:      	movq	0x40(%rsp), %rax
    d489:      	cmpq	(%rsp), %rax
    d48d:      	je	0x1636d <generic_usdt_path+0xba6d>
    d493:      	addq	$0x18, %r15
    d497:      	movl	$0x4, %eax
    d49c:      	leaq	0x30(%rsp), %rdi
    d4a1:      	movl	$0x8, %esi
    d4a6:      	movq	%r15, %rdx
    d4a9:      	callq	*%rax
    d4ab:      	movq	(%rsp), %r15
    d4af:      	movq	%r15, 0x40(%rsp)
    d4b4:      	leaq	0x20(%r15), %rdx
    d4b8:      	movq	%rdx, 0x38(%rsp)
    d4bd:      	movq	0x30(%rsp), %r12
    d4c2:      	cmpq	0x18(%rsp), %r12
    d4c7:      	jne	0xd4d4 <generic_usdt_path+0x2bd4>
    d4c9:      	cmpq	0x20(%rsp), %rdx
    d4ce:      	je	0x1636d <generic_usdt_path+0xba6d>
    d4d4:      	movl	$0x4, %eax
    d4d9:      	leaq	0x10(%rsp), %rdi
    d4de:      	movl	$0x8, %esi
    d4e3:      	callq	*%rax
    d4e5:      	cmpq	0x10(%rsp), %r12
    d4ea:      	je	0xd5e2 <generic_usdt_path+0x2ce2>
    d4f0:      	leaq	0x18(%r12), %rbx
    d4f5:      	movl	$0x4, %eax
    d4fa:      	movq	%rbp, %rdi
    d4fd:      	movl	$0x8, %esi
    d502:      	movq	%rbx, %rdx
    d505:      	callq	*%rax
    d507:      	cmpq	%r12, (%rsp)
    d50b:      	je	0xd5e2 <generic_usdt_path+0x2ce2>
    d511:      	movl	$0x4, %eax
    d516:      	leaq	0x8(%rsp), %rdi
    d51b:      	movl	$0x8, %esi
    d520:      	movq	%rbx, %rdx
    d523:      	callq	*%rax
    d525:      	addq	$0x20, %r12
    d529:      	movl	$0x4, %eax
    d52e:      	leaq	0x58(%rsp), %rdi
    d533:      	movl	$0x10, %ecx
    d538:      	movl	$0x10, %esi
    d53d:      	movq	%r12, %rdx
    d540:      	callq	*%rax
    d542:      	movq	0x28(%rsp), %rbx
    d547:      	movq	0x48(%rsp), %rax
    d54c:      	movl	0x5c(%rsp), %r15d
    d551:      	subq	%rbx, %rax
    d554:      	movl	0x50(%rsp), %r12d
    d559:      	movl	%r15d, %edx
    d55c:      	subl	%r12d, %edx
    d55f:      	movl	$0x0, %ecx
    d564:      	cmovbl	%ecx, %edx
    d567:      	addq	0x60(%rsp), %rdx
    d56c:      	xorl	%esi, %esi
    d56e:      	cmpl	%r15d, %r12d
    d571:      	seta	%sil
    d575:      	movl	%r15d, %ecx
    d578:      	cmovbl	%r12d, %ecx
    d57c:      	addl	%ecx, %esi
    d57e:      	movl	%r12d, %edi
    d581:      	subl	%esi, %edi
    d583:      	movl	%edi, 0x50(%rsp)
    d587:      	subq	%rsi, %rax
    d58a:      	jb	0x16372 <generic_usdt_path+0xba72>
    d590:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d596:      	ja	0x16372 <generic_usdt_path+0xba72>
    d59c:      	cmpl	%r15d, %r12d
    d59f:      	jbe	0xd5a5 <generic_usdt_path+0x2ca5>
    d5a1:      	movb	$0x2f, (%rbx,%rax)
    d5a5:      	xorl	%edi, %edi
    d5a7:      	cmpl	%r15d, %r12d
    d5aa:      	seta	%dil
    d5ae:      	movzbl	%cl, %esi
    d5b1:      	addq	%rax, %rbx
    d5b4:      	addq	%rbx, %rdi
    d5b7:      	movl	$0x4, %eax
    d5bc:      	callq	*%rax
    d5be:      	movq	%rbx, 0x48(%rsp)
    d5c3:      	cmpl	%r15d, %r12d
    d5c6:      	jbe	0x16372 <generic_usdt_path+0xba72>
    d5cc:      	movq	0x8(%rsp), %r12
    d5d1:      	movq	%r12, 0x30(%rsp)
    d5d6:      	movq	0x38(%rsp), %rdx
    d5db:      	movq	0x40(%rsp), %r15
    d5e0:      	jmp	0xd633 <generic_usdt_path+0x2d33>
    d5e2:      	leaq	0x10(%r15), %rdx
    d5e6:      	movl	$0x4, %eax
    d5eb:      	movq	%rbp, %rdi
    d5ee:      	movl	$0x8, %esi
    d5f3:      	callq	*%rax
    d5f5:      	movq	0x40(%rsp), %rax
    d5fa:      	cmpq	(%rsp), %rax
    d5fe:      	je	0x1636d <generic_usdt_path+0xba6d>
    d604:      	addq	$0x18, %r15
    d608:      	movl	$0x4, %eax
    d60d:      	leaq	0x30(%rsp), %rdi
    d612:      	movl	$0x8, %esi
    d617:      	movq	%r15, %rdx
    d61a:      	callq	*%rax
    d61c:      	movq	(%rsp), %r15
    d620:      	movq	%r15, 0x40(%rsp)
    d625:      	leaq	0x20(%r15), %rdx
    d629:      	movq	%rdx, 0x38(%rsp)
    d62e:      	movq	0x30(%rsp), %r12
    d633:      	cmpq	0x18(%rsp), %r12
    d638:      	jne	0xd645 <generic_usdt_path+0x2d45>
    d63a:      	cmpq	0x20(%rsp), %rdx
    d63f:      	je	0x1636d <generic_usdt_path+0xba6d>
    d645:      	movl	$0x4, %eax
    d64a:      	leaq	0x10(%rsp), %rdi
    d64f:      	movl	$0x8, %esi
    d654:      	callq	*%rax
    d656:      	cmpq	0x10(%rsp), %r12
    d65b:      	je	0xd753 <generic_usdt_path+0x2e53>
    d661:      	leaq	0x18(%r12), %rbx
    d666:      	movl	$0x4, %eax
    d66b:      	movq	%rbp, %rdi
    d66e:      	movl	$0x8, %esi
    d673:      	movq	%rbx, %rdx
    d676:      	callq	*%rax
    d678:      	cmpq	%r12, (%rsp)
    d67c:      	je	0xd753 <generic_usdt_path+0x2e53>
    d682:      	movl	$0x4, %eax
    d687:      	leaq	0x8(%rsp), %rdi
    d68c:      	movl	$0x8, %esi
    d691:      	movq	%rbx, %rdx
    d694:      	callq	*%rax
    d696:      	addq	$0x20, %r12
    d69a:      	movl	$0x4, %eax
    d69f:      	leaq	0x58(%rsp), %rdi
    d6a4:      	movl	$0x10, %ecx
    d6a9:      	movl	$0x10, %esi
    d6ae:      	movq	%r12, %rdx
    d6b1:      	callq	*%rax
    d6b3:      	movq	0x28(%rsp), %rbx
    d6b8:      	movq	0x48(%rsp), %rax
    d6bd:      	movl	0x5c(%rsp), %r15d
    d6c2:      	subq	%rbx, %rax
    d6c5:      	movl	0x50(%rsp), %r12d
    d6ca:      	movl	%r15d, %edx
    d6cd:      	subl	%r12d, %edx
    d6d0:      	movl	$0x0, %ecx
    d6d5:      	cmovbl	%ecx, %edx
    d6d8:      	addq	0x60(%rsp), %rdx
    d6dd:      	xorl	%esi, %esi
    d6df:      	cmpl	%r15d, %r12d
    d6e2:      	seta	%sil
    d6e6:      	movl	%r15d, %ecx
    d6e9:      	cmovbl	%r12d, %ecx
    d6ed:      	addl	%ecx, %esi
    d6ef:      	movl	%r12d, %edi
    d6f2:      	subl	%esi, %edi
    d6f4:      	movl	%edi, 0x50(%rsp)
    d6f8:      	subq	%rsi, %rax
    d6fb:      	jb	0x16372 <generic_usdt_path+0xba72>
    d701:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d707:      	ja	0x16372 <generic_usdt_path+0xba72>
    d70d:      	cmpl	%r15d, %r12d
    d710:      	jbe	0xd716 <generic_usdt_path+0x2e16>
    d712:      	movb	$0x2f, (%rbx,%rax)
    d716:      	xorl	%edi, %edi
    d718:      	cmpl	%r15d, %r12d
    d71b:      	seta	%dil
    d71f:      	movzbl	%cl, %esi
    d722:      	addq	%rax, %rbx
    d725:      	addq	%rbx, %rdi
    d728:      	movl	$0x4, %eax
    d72d:      	callq	*%rax
    d72f:      	movq	%rbx, 0x48(%rsp)
    d734:      	cmpl	%r15d, %r12d
    d737:      	jbe	0x16372 <generic_usdt_path+0xba72>
    d73d:      	movq	0x8(%rsp), %r12
    d742:      	movq	%r12, 0x30(%rsp)
    d747:      	movq	0x38(%rsp), %rdx
    d74c:      	movq	0x40(%rsp), %r15
    d751:      	jmp	0xd7a4 <generic_usdt_path+0x2ea4>
    d753:      	leaq	0x10(%r15), %rdx
    d757:      	movl	$0x4, %eax
    d75c:      	movq	%rbp, %rdi
    d75f:      	movl	$0x8, %esi
    d764:      	callq	*%rax
    d766:      	movq	0x40(%rsp), %rax
    d76b:      	cmpq	(%rsp), %rax
    d76f:      	je	0x1636d <generic_usdt_path+0xba6d>
    d775:      	addq	$0x18, %r15
    d779:      	movl	$0x4, %eax
    d77e:      	leaq	0x30(%rsp), %rdi
    d783:      	movl	$0x8, %esi
    d788:      	movq	%r15, %rdx
    d78b:      	callq	*%rax
    d78d:      	movq	(%rsp), %r15
    d791:      	movq	%r15, 0x40(%rsp)
    d796:      	leaq	0x20(%r15), %rdx
    d79a:      	movq	%rdx, 0x38(%rsp)
    d79f:      	movq	0x30(%rsp), %r12
    d7a4:      	cmpq	0x18(%rsp), %r12
    d7a9:      	jne	0xd7b6 <generic_usdt_path+0x2eb6>
    d7ab:      	cmpq	0x20(%rsp), %rdx
    d7b0:      	je	0x1636d <generic_usdt_path+0xba6d>
    d7b6:      	movl	$0x4, %eax
    d7bb:      	leaq	0x10(%rsp), %rdi
    d7c0:      	movl	$0x8, %esi
    d7c5:      	callq	*%rax
    d7c7:      	cmpq	0x10(%rsp), %r12
    d7cc:      	je	0xd8c4 <generic_usdt_path+0x2fc4>
    d7d2:      	leaq	0x18(%r12), %rbx
    d7d7:      	movl	$0x4, %eax
    d7dc:      	movq	%rbp, %rdi
    d7df:      	movl	$0x8, %esi
    d7e4:      	movq	%rbx, %rdx
    d7e7:      	callq	*%rax
    d7e9:      	cmpq	%r12, (%rsp)
    d7ed:      	je	0xd8c4 <generic_usdt_path+0x2fc4>
    d7f3:      	movl	$0x4, %eax
    d7f8:      	leaq	0x8(%rsp), %rdi
    d7fd:      	movl	$0x8, %esi
    d802:      	movq	%rbx, %rdx
    d805:      	callq	*%rax
    d807:      	addq	$0x20, %r12
    d80b:      	movl	$0x4, %eax
    d810:      	leaq	0x58(%rsp), %rdi
    d815:      	movl	$0x10, %ecx
    d81a:      	movl	$0x10, %esi
    d81f:      	movq	%r12, %rdx
    d822:      	callq	*%rax
    d824:      	movq	0x28(%rsp), %rbx
    d829:      	movq	0x48(%rsp), %rax
    d82e:      	movl	0x5c(%rsp), %r15d
    d833:      	subq	%rbx, %rax
    d836:      	movl	0x50(%rsp), %r12d
    d83b:      	movl	%r15d, %edx
    d83e:      	subl	%r12d, %edx
    d841:      	movl	$0x0, %ecx
    d846:      	cmovbl	%ecx, %edx
    d849:      	addq	0x60(%rsp), %rdx
    d84e:      	xorl	%esi, %esi
    d850:      	cmpl	%r15d, %r12d
    d853:      	seta	%sil
    d857:      	movl	%r15d, %ecx
    d85a:      	cmovbl	%r12d, %ecx
    d85e:      	addl	%ecx, %esi
    d860:      	movl	%r12d, %edi
    d863:      	subl	%esi, %edi
    d865:      	movl	%edi, 0x50(%rsp)
    d869:      	subq	%rsi, %rax
    d86c:      	jb	0x16372 <generic_usdt_path+0xba72>
    d872:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d878:      	ja	0x16372 <generic_usdt_path+0xba72>
    d87e:      	cmpl	%r15d, %r12d
    d881:      	jbe	0xd887 <generic_usdt_path+0x2f87>
    d883:      	movb	$0x2f, (%rbx,%rax)
    d887:      	xorl	%edi, %edi
    d889:      	cmpl	%r15d, %r12d
    d88c:      	seta	%dil
    d890:      	movzbl	%cl, %esi
    d893:      	addq	%rax, %rbx
    d896:      	addq	%rbx, %rdi
    d899:      	movl	$0x4, %eax
    d89e:      	callq	*%rax
    d8a0:      	movq	%rbx, 0x48(%rsp)
    d8a5:      	cmpl	%r15d, %r12d
    d8a8:      	jbe	0x16372 <generic_usdt_path+0xba72>
    d8ae:      	movq	0x8(%rsp), %r12
    d8b3:      	movq	%r12, 0x30(%rsp)
    d8b8:      	movq	0x38(%rsp), %rdx
    d8bd:      	movq	0x40(%rsp), %r15
    d8c2:      	jmp	0xd915 <generic_usdt_path+0x3015>
    d8c4:      	leaq	0x10(%r15), %rdx
    d8c8:      	movl	$0x4, %eax
    d8cd:      	movq	%rbp, %rdi
    d8d0:      	movl	$0x8, %esi
    d8d5:      	callq	*%rax
    d8d7:      	movq	0x40(%rsp), %rax
    d8dc:      	cmpq	(%rsp), %rax
    d8e0:      	je	0x1636d <generic_usdt_path+0xba6d>
    d8e6:      	addq	$0x18, %r15
    d8ea:      	movl	$0x4, %eax
    d8ef:      	leaq	0x30(%rsp), %rdi
    d8f4:      	movl	$0x8, %esi
    d8f9:      	movq	%r15, %rdx
    d8fc:      	callq	*%rax
    d8fe:      	movq	(%rsp), %r15
    d902:      	movq	%r15, 0x40(%rsp)
    d907:      	leaq	0x20(%r15), %rdx
    d90b:      	movq	%rdx, 0x38(%rsp)
    d910:      	movq	0x30(%rsp), %r12
    d915:      	cmpq	0x18(%rsp), %r12
    d91a:      	jne	0xd927 <generic_usdt_path+0x3027>
    d91c:      	cmpq	0x20(%rsp), %rdx
    d921:      	je	0x1636d <generic_usdt_path+0xba6d>
    d927:      	movl	$0x4, %eax
    d92c:      	leaq	0x10(%rsp), %rdi
    d931:      	movl	$0x8, %esi
    d936:      	callq	*%rax
    d938:      	cmpq	0x10(%rsp), %r12
    d93d:      	je	0xda35 <generic_usdt_path+0x3135>
    d943:      	leaq	0x18(%r12), %rbx
    d948:      	movl	$0x4, %eax
    d94d:      	movq	%rbp, %rdi
    d950:      	movl	$0x8, %esi
    d955:      	movq	%rbx, %rdx
    d958:      	callq	*%rax
    d95a:      	cmpq	%r12, (%rsp)
    d95e:      	je	0xda35 <generic_usdt_path+0x3135>
    d964:      	movl	$0x4, %eax
    d969:      	leaq	0x8(%rsp), %rdi
    d96e:      	movl	$0x8, %esi
    d973:      	movq	%rbx, %rdx
    d976:      	callq	*%rax
    d978:      	addq	$0x20, %r12
    d97c:      	movl	$0x4, %eax
    d981:      	leaq	0x58(%rsp), %rdi
    d986:      	movl	$0x10, %ecx
    d98b:      	movl	$0x10, %esi
    d990:      	movq	%r12, %rdx
    d993:      	callq	*%rax
    d995:      	movq	0x28(%rsp), %rbx
    d99a:      	movq	0x48(%rsp), %rax
    d99f:      	movl	0x5c(%rsp), %r15d
    d9a4:      	subq	%rbx, %rax
    d9a7:      	movl	0x50(%rsp), %r12d
    d9ac:      	movl	%r15d, %edx
    d9af:      	subl	%r12d, %edx
    d9b2:      	movl	$0x0, %ecx
    d9b7:      	cmovbl	%ecx, %edx
    d9ba:      	addq	0x60(%rsp), %rdx
    d9bf:      	xorl	%esi, %esi
    d9c1:      	cmpl	%r15d, %r12d
    d9c4:      	seta	%sil
    d9c8:      	movl	%r15d, %ecx
    d9cb:      	cmovbl	%r12d, %ecx
    d9cf:      	addl	%ecx, %esi
    d9d1:      	movl	%r12d, %edi
    d9d4:      	subl	%esi, %edi
    d9d6:      	movl	%edi, 0x50(%rsp)
    d9da:      	subq	%rsi, %rax
    d9dd:      	jb	0x16372 <generic_usdt_path+0xba72>
    d9e3:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    d9e9:      	ja	0x16372 <generic_usdt_path+0xba72>
    d9ef:      	cmpl	%r15d, %r12d
    d9f2:      	jbe	0xd9f8 <generic_usdt_path+0x30f8>
    d9f4:      	movb	$0x2f, (%rbx,%rax)
    d9f8:      	xorl	%edi, %edi
    d9fa:      	cmpl	%r15d, %r12d
    d9fd:      	seta	%dil
    da01:      	movzbl	%cl, %esi
    da04:      	addq	%rax, %rbx
    da07:      	addq	%rbx, %rdi
    da0a:      	movl	$0x4, %eax
    da0f:      	callq	*%rax
    da11:      	movq	%rbx, 0x48(%rsp)
    da16:      	cmpl	%r15d, %r12d
    da19:      	jbe	0x16372 <generic_usdt_path+0xba72>
    da1f:      	movq	0x8(%rsp), %r12
    da24:      	movq	%r12, 0x30(%rsp)
    da29:      	movq	0x38(%rsp), %rdx
    da2e:      	movq	0x40(%rsp), %r15
    da33:      	jmp	0xda86 <generic_usdt_path+0x3186>
    da35:      	leaq	0x10(%r15), %rdx
    da39:      	movl	$0x4, %eax
    da3e:      	movq	%rbp, %rdi
    da41:      	movl	$0x8, %esi
    da46:      	callq	*%rax
    da48:      	movq	0x40(%rsp), %rax
    da4d:      	cmpq	(%rsp), %rax
    da51:      	je	0x1636d <generic_usdt_path+0xba6d>
    da57:      	addq	$0x18, %r15
    da5b:      	movl	$0x4, %eax
    da60:      	leaq	0x30(%rsp), %rdi
    da65:      	movl	$0x8, %esi
    da6a:      	movq	%r15, %rdx
    da6d:      	callq	*%rax
    da6f:      	movq	(%rsp), %r15
    da73:      	movq	%r15, 0x40(%rsp)
    da78:      	leaq	0x20(%r15), %rdx
    da7c:      	movq	%rdx, 0x38(%rsp)
    da81:      	movq	0x30(%rsp), %r12
    da86:      	cmpq	0x18(%rsp), %r12
    da8b:      	jne	0xda98 <generic_usdt_path+0x3198>
    da8d:      	cmpq	0x20(%rsp), %rdx
    da92:      	je	0x1636d <generic_usdt_path+0xba6d>
    da98:      	movl	$0x4, %eax
    da9d:      	leaq	0x10(%rsp), %rdi
    daa2:      	movl	$0x8, %esi
    daa7:      	callq	*%rax
    daa9:      	cmpq	0x10(%rsp), %r12
    daae:      	je	0xdba6 <generic_usdt_path+0x32a6>
    dab4:      	leaq	0x18(%r12), %rbx
    dab9:      	movl	$0x4, %eax
    dabe:      	movq	%rbp, %rdi
    dac1:      	movl	$0x8, %esi
    dac6:      	movq	%rbx, %rdx
    dac9:      	callq	*%rax
    dacb:      	cmpq	%r12, (%rsp)
    dacf:      	je	0xdba6 <generic_usdt_path+0x32a6>
    dad5:      	movl	$0x4, %eax
    dada:      	leaq	0x8(%rsp), %rdi
    dadf:      	movl	$0x8, %esi
    dae4:      	movq	%rbx, %rdx
    dae7:      	callq	*%rax
    dae9:      	addq	$0x20, %r12
    daed:      	movl	$0x4, %eax
    daf2:      	leaq	0x58(%rsp), %rdi
    daf7:      	movl	$0x10, %ecx
    dafc:      	movl	$0x10, %esi
    db01:      	movq	%r12, %rdx
    db04:      	callq	*%rax
    db06:      	movq	0x28(%rsp), %rbx
    db0b:      	movq	0x48(%rsp), %rax
    db10:      	movl	0x5c(%rsp), %r15d
    db15:      	subq	%rbx, %rax
    db18:      	movl	0x50(%rsp), %r12d
    db1d:      	movl	%r15d, %edx
    db20:      	subl	%r12d, %edx
    db23:      	movl	$0x0, %ecx
    db28:      	cmovbl	%ecx, %edx
    db2b:      	addq	0x60(%rsp), %rdx
    db30:      	xorl	%esi, %esi
    db32:      	cmpl	%r15d, %r12d
    db35:      	seta	%sil
    db39:      	movl	%r15d, %ecx
    db3c:      	cmovbl	%r12d, %ecx
    db40:      	addl	%ecx, %esi
    db42:      	movl	%r12d, %edi
    db45:      	subl	%esi, %edi
    db47:      	movl	%edi, 0x50(%rsp)
    db4b:      	subq	%rsi, %rax
    db4e:      	jb	0x16372 <generic_usdt_path+0xba72>
    db54:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    db5a:      	ja	0x16372 <generic_usdt_path+0xba72>
    db60:      	cmpl	%r15d, %r12d
    db63:      	jbe	0xdb69 <generic_usdt_path+0x3269>
    db65:      	movb	$0x2f, (%rbx,%rax)
    db69:      	xorl	%edi, %edi
    db6b:      	cmpl	%r15d, %r12d
    db6e:      	seta	%dil
    db72:      	movzbl	%cl, %esi
    db75:      	addq	%rax, %rbx
    db78:      	addq	%rbx, %rdi
    db7b:      	movl	$0x4, %eax
    db80:      	callq	*%rax
    db82:      	movq	%rbx, 0x48(%rsp)
    db87:      	cmpl	%r15d, %r12d
    db8a:      	jbe	0x16372 <generic_usdt_path+0xba72>
    db90:      	movq	0x8(%rsp), %r12
    db95:      	movq	%r12, 0x30(%rsp)
    db9a:      	movq	0x38(%rsp), %rdx
    db9f:      	movq	0x40(%rsp), %r15
    dba4:      	jmp	0xdbf7 <generic_usdt_path+0x32f7>
    dba6:      	leaq	0x10(%r15), %rdx
    dbaa:      	movl	$0x4, %eax
    dbaf:      	movq	%rbp, %rdi
    dbb2:      	movl	$0x8, %esi
    dbb7:      	callq	*%rax
    dbb9:      	movq	0x40(%rsp), %rax
    dbbe:      	cmpq	(%rsp), %rax
    dbc2:      	je	0x1636d <generic_usdt_path+0xba6d>
    dbc8:      	addq	$0x18, %r15
    dbcc:      	movl	$0x4, %eax
    dbd1:      	leaq	0x30(%rsp), %rdi
    dbd6:      	movl	$0x8, %esi
    dbdb:      	movq	%r15, %rdx
    dbde:      	callq	*%rax
    dbe0:      	movq	(%rsp), %r15
    dbe4:      	movq	%r15, 0x40(%rsp)
    dbe9:      	leaq	0x20(%r15), %rdx
    dbed:      	movq	%rdx, 0x38(%rsp)
    dbf2:      	movq	0x30(%rsp), %r12
    dbf7:      	cmpq	0x18(%rsp), %r12
    dbfc:      	jne	0xdc09 <generic_usdt_path+0x3309>
    dbfe:      	cmpq	0x20(%rsp), %rdx
    dc03:      	je	0x1636d <generic_usdt_path+0xba6d>
    dc09:      	movl	$0x4, %eax
    dc0e:      	leaq	0x10(%rsp), %rdi
    dc13:      	movl	$0x8, %esi
    dc18:      	callq	*%rax
    dc1a:      	cmpq	0x10(%rsp), %r12
    dc1f:      	je	0xdd17 <generic_usdt_path+0x3417>
    dc25:      	leaq	0x18(%r12), %rbx
    dc2a:      	movl	$0x4, %eax
    dc2f:      	movq	%rbp, %rdi
    dc32:      	movl	$0x8, %esi
    dc37:      	movq	%rbx, %rdx
    dc3a:      	callq	*%rax
    dc3c:      	cmpq	%r12, (%rsp)
    dc40:      	je	0xdd17 <generic_usdt_path+0x3417>
    dc46:      	movl	$0x4, %eax
    dc4b:      	leaq	0x8(%rsp), %rdi
    dc50:      	movl	$0x8, %esi
    dc55:      	movq	%rbx, %rdx
    dc58:      	callq	*%rax
    dc5a:      	addq	$0x20, %r12
    dc5e:      	movl	$0x4, %eax
    dc63:      	leaq	0x58(%rsp), %rdi
    dc68:      	movl	$0x10, %ecx
    dc6d:      	movl	$0x10, %esi
    dc72:      	movq	%r12, %rdx
    dc75:      	callq	*%rax
    dc77:      	movq	0x28(%rsp), %rbx
    dc7c:      	movq	0x48(%rsp), %rax
    dc81:      	movl	0x5c(%rsp), %r15d
    dc86:      	subq	%rbx, %rax
    dc89:      	movl	0x50(%rsp), %r12d
    dc8e:      	movl	%r15d, %edx
    dc91:      	subl	%r12d, %edx
    dc94:      	movl	$0x0, %ecx
    dc99:      	cmovbl	%ecx, %edx
    dc9c:      	addq	0x60(%rsp), %rdx
    dca1:      	xorl	%esi, %esi
    dca3:      	cmpl	%r15d, %r12d
    dca6:      	seta	%sil
    dcaa:      	movl	%r15d, %ecx
    dcad:      	cmovbl	%r12d, %ecx
    dcb1:      	addl	%ecx, %esi
    dcb3:      	movl	%r12d, %edi
    dcb6:      	subl	%esi, %edi
    dcb8:      	movl	%edi, 0x50(%rsp)
    dcbc:      	subq	%rsi, %rax
    dcbf:      	jb	0x16372 <generic_usdt_path+0xba72>
    dcc5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    dccb:      	ja	0x16372 <generic_usdt_path+0xba72>
    dcd1:      	cmpl	%r15d, %r12d
    dcd4:      	jbe	0xdcda <generic_usdt_path+0x33da>
    dcd6:      	movb	$0x2f, (%rbx,%rax)
    dcda:      	xorl	%edi, %edi
    dcdc:      	cmpl	%r15d, %r12d
    dcdf:      	seta	%dil
    dce3:      	movzbl	%cl, %esi
    dce6:      	addq	%rax, %rbx
    dce9:      	addq	%rbx, %rdi
    dcec:      	movl	$0x4, %eax
    dcf1:      	callq	*%rax
    dcf3:      	movq	%rbx, 0x48(%rsp)
    dcf8:      	cmpl	%r15d, %r12d
    dcfb:      	jbe	0x16372 <generic_usdt_path+0xba72>
    dd01:      	movq	0x8(%rsp), %r12
    dd06:      	movq	%r12, 0x30(%rsp)
    dd0b:      	movq	0x38(%rsp), %rdx
    dd10:      	movq	0x40(%rsp), %r15
    dd15:      	jmp	0xdd68 <generic_usdt_path+0x3468>
    dd17:      	leaq	0x10(%r15), %rdx
    dd1b:      	movl	$0x4, %eax
    dd20:      	movq	%rbp, %rdi
    dd23:      	movl	$0x8, %esi
    dd28:      	callq	*%rax
    dd2a:      	movq	0x40(%rsp), %rax
    dd2f:      	cmpq	(%rsp), %rax
    dd33:      	je	0x1636d <generic_usdt_path+0xba6d>
    dd39:      	addq	$0x18, %r15
    dd3d:      	movl	$0x4, %eax
    dd42:      	leaq	0x30(%rsp), %rdi
    dd47:      	movl	$0x8, %esi
    dd4c:      	movq	%r15, %rdx
    dd4f:      	callq	*%rax
    dd51:      	movq	(%rsp), %r15
    dd55:      	movq	%r15, 0x40(%rsp)
    dd5a:      	leaq	0x20(%r15), %rdx
    dd5e:      	movq	%rdx, 0x38(%rsp)
    dd63:      	movq	0x30(%rsp), %r12
    dd68:      	cmpq	0x18(%rsp), %r12
    dd6d:      	jne	0xdd7a <generic_usdt_path+0x347a>
    dd6f:      	cmpq	0x20(%rsp), %rdx
    dd74:      	je	0x1636d <generic_usdt_path+0xba6d>
    dd7a:      	movl	$0x4, %eax
    dd7f:      	leaq	0x10(%rsp), %rdi
    dd84:      	movl	$0x8, %esi
    dd89:      	callq	*%rax
    dd8b:      	cmpq	0x10(%rsp), %r12
    dd90:      	je	0xde88 <generic_usdt_path+0x3588>
    dd96:      	leaq	0x18(%r12), %rbx
    dd9b:      	movl	$0x4, %eax
    dda0:      	movq	%rbp, %rdi
    dda3:      	movl	$0x8, %esi
    dda8:      	movq	%rbx, %rdx
    ddab:      	callq	*%rax
    ddad:      	cmpq	%r12, (%rsp)
    ddb1:      	je	0xde88 <generic_usdt_path+0x3588>
    ddb7:      	movl	$0x4, %eax
    ddbc:      	leaq	0x8(%rsp), %rdi
    ddc1:      	movl	$0x8, %esi
    ddc6:      	movq	%rbx, %rdx
    ddc9:      	callq	*%rax
    ddcb:      	addq	$0x20, %r12
    ddcf:      	movl	$0x4, %eax
    ddd4:      	leaq	0x58(%rsp), %rdi
    ddd9:      	movl	$0x10, %ecx
    ddde:      	movl	$0x10, %esi
    dde3:      	movq	%r12, %rdx
    dde6:      	callq	*%rax
    dde8:      	movq	0x28(%rsp), %rbx
    dded:      	movq	0x48(%rsp), %rax
    ddf2:      	movl	0x5c(%rsp), %r15d
    ddf7:      	subq	%rbx, %rax
    ddfa:      	movl	0x50(%rsp), %r12d
    ddff:      	movl	%r15d, %edx
    de02:      	subl	%r12d, %edx
    de05:      	movl	$0x0, %ecx
    de0a:      	cmovbl	%ecx, %edx
    de0d:      	addq	0x60(%rsp), %rdx
    de12:      	xorl	%esi, %esi
    de14:      	cmpl	%r15d, %r12d
    de17:      	seta	%sil
    de1b:      	movl	%r15d, %ecx
    de1e:      	cmovbl	%r12d, %ecx
    de22:      	addl	%ecx, %esi
    de24:      	movl	%r12d, %edi
    de27:      	subl	%esi, %edi
    de29:      	movl	%edi, 0x50(%rsp)
    de2d:      	subq	%rsi, %rax
    de30:      	jb	0x16372 <generic_usdt_path+0xba72>
    de36:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    de3c:      	ja	0x16372 <generic_usdt_path+0xba72>
    de42:      	cmpl	%r15d, %r12d
    de45:      	jbe	0xde4b <generic_usdt_path+0x354b>
    de47:      	movb	$0x2f, (%rbx,%rax)
    de4b:      	xorl	%edi, %edi
    de4d:      	cmpl	%r15d, %r12d
    de50:      	seta	%dil
    de54:      	movzbl	%cl, %esi
    de57:      	addq	%rax, %rbx
    de5a:      	addq	%rbx, %rdi
    de5d:      	movl	$0x4, %eax
    de62:      	callq	*%rax
    de64:      	movq	%rbx, 0x48(%rsp)
    de69:      	cmpl	%r15d, %r12d
    de6c:      	jbe	0x16372 <generic_usdt_path+0xba72>
    de72:      	movq	0x8(%rsp), %r12
    de77:      	movq	%r12, 0x30(%rsp)
    de7c:      	movq	0x38(%rsp), %rdx
    de81:      	movq	0x40(%rsp), %r15
    de86:      	jmp	0xded9 <generic_usdt_path+0x35d9>
    de88:      	leaq	0x10(%r15), %rdx
    de8c:      	movl	$0x4, %eax
    de91:      	movq	%rbp, %rdi
    de94:      	movl	$0x8, %esi
    de99:      	callq	*%rax
    de9b:      	movq	0x40(%rsp), %rax
    dea0:      	cmpq	(%rsp), %rax
    dea4:      	je	0x1636d <generic_usdt_path+0xba6d>
    deaa:      	addq	$0x18, %r15
    deae:      	movl	$0x4, %eax
    deb3:      	leaq	0x30(%rsp), %rdi
    deb8:      	movl	$0x8, %esi
    debd:      	movq	%r15, %rdx
    dec0:      	callq	*%rax
    dec2:      	movq	(%rsp), %r15
    dec6:      	movq	%r15, 0x40(%rsp)
    decb:      	leaq	0x20(%r15), %rdx
    decf:      	movq	%rdx, 0x38(%rsp)
    ded4:      	movq	0x30(%rsp), %r12
    ded9:      	cmpq	0x18(%rsp), %r12
    dede:      	jne	0xdeeb <generic_usdt_path+0x35eb>
    dee0:      	cmpq	0x20(%rsp), %rdx
    dee5:      	je	0x1636d <generic_usdt_path+0xba6d>
    deeb:      	movl	$0x4, %eax
    def0:      	leaq	0x10(%rsp), %rdi
    def5:      	movl	$0x8, %esi
    defa:      	callq	*%rax
    defc:      	cmpq	0x10(%rsp), %r12
    df01:      	je	0xdff9 <generic_usdt_path+0x36f9>
    df07:      	leaq	0x18(%r12), %rbx
    df0c:      	movl	$0x4, %eax
    df11:      	movq	%rbp, %rdi
    df14:      	movl	$0x8, %esi
    df19:      	movq	%rbx, %rdx
    df1c:      	callq	*%rax
    df1e:      	cmpq	%r12, (%rsp)
    df22:      	je	0xdff9 <generic_usdt_path+0x36f9>
    df28:      	movl	$0x4, %eax
    df2d:      	leaq	0x8(%rsp), %rdi
    df32:      	movl	$0x8, %esi
    df37:      	movq	%rbx, %rdx
    df3a:      	callq	*%rax
    df3c:      	addq	$0x20, %r12
    df40:      	movl	$0x4, %eax
    df45:      	leaq	0x58(%rsp), %rdi
    df4a:      	movl	$0x10, %ecx
    df4f:      	movl	$0x10, %esi
    df54:      	movq	%r12, %rdx
    df57:      	callq	*%rax
    df59:      	movq	0x28(%rsp), %rbx
    df5e:      	movq	0x48(%rsp), %rax
    df63:      	movl	0x5c(%rsp), %r15d
    df68:      	subq	%rbx, %rax
    df6b:      	movl	0x50(%rsp), %r12d
    df70:      	movl	%r15d, %edx
    df73:      	subl	%r12d, %edx
    df76:      	movl	$0x0, %ecx
    df7b:      	cmovbl	%ecx, %edx
    df7e:      	addq	0x60(%rsp), %rdx
    df83:      	xorl	%esi, %esi
    df85:      	cmpl	%r15d, %r12d
    df88:      	seta	%sil
    df8c:      	movl	%r15d, %ecx
    df8f:      	cmovbl	%r12d, %ecx
    df93:      	addl	%ecx, %esi
    df95:      	movl	%r12d, %edi
    df98:      	subl	%esi, %edi
    df9a:      	movl	%edi, 0x50(%rsp)
    df9e:      	subq	%rsi, %rax
    dfa1:      	jb	0x16372 <generic_usdt_path+0xba72>
    dfa7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    dfad:      	ja	0x16372 <generic_usdt_path+0xba72>
    dfb3:      	cmpl	%r15d, %r12d
    dfb6:      	jbe	0xdfbc <generic_usdt_path+0x36bc>
    dfb8:      	movb	$0x2f, (%rbx,%rax)
    dfbc:      	xorl	%edi, %edi
    dfbe:      	cmpl	%r15d, %r12d
    dfc1:      	seta	%dil
    dfc5:      	movzbl	%cl, %esi
    dfc8:      	addq	%rax, %rbx
    dfcb:      	addq	%rbx, %rdi
    dfce:      	movl	$0x4, %eax
    dfd3:      	callq	*%rax
    dfd5:      	movq	%rbx, 0x48(%rsp)
    dfda:      	cmpl	%r15d, %r12d
    dfdd:      	jbe	0x16372 <generic_usdt_path+0xba72>
    dfe3:      	movq	0x8(%rsp), %r12
    dfe8:      	movq	%r12, 0x30(%rsp)
    dfed:      	movq	0x38(%rsp), %rdx
    dff2:      	movq	0x40(%rsp), %r15
    dff7:      	jmp	0xe04a <generic_usdt_path+0x374a>
    dff9:      	leaq	0x10(%r15), %rdx
    dffd:      	movl	$0x4, %eax
    e002:      	movq	%rbp, %rdi
    e005:      	movl	$0x8, %esi
    e00a:      	callq	*%rax
    e00c:      	movq	0x40(%rsp), %rax
    e011:      	cmpq	(%rsp), %rax
    e015:      	je	0x1636d <generic_usdt_path+0xba6d>
    e01b:      	addq	$0x18, %r15
    e01f:      	movl	$0x4, %eax
    e024:      	leaq	0x30(%rsp), %rdi
    e029:      	movl	$0x8, %esi
    e02e:      	movq	%r15, %rdx
    e031:      	callq	*%rax
    e033:      	movq	(%rsp), %r15
    e037:      	movq	%r15, 0x40(%rsp)
    e03c:      	leaq	0x20(%r15), %rdx
    e040:      	movq	%rdx, 0x38(%rsp)
    e045:      	movq	0x30(%rsp), %r12
    e04a:      	cmpq	0x18(%rsp), %r12
    e04f:      	jne	0xe05c <generic_usdt_path+0x375c>
    e051:      	cmpq	0x20(%rsp), %rdx
    e056:      	je	0x1636d <generic_usdt_path+0xba6d>
    e05c:      	movl	$0x4, %eax
    e061:      	leaq	0x10(%rsp), %rdi
    e066:      	movl	$0x8, %esi
    e06b:      	callq	*%rax
    e06d:      	cmpq	0x10(%rsp), %r12
    e072:      	je	0xe16a <generic_usdt_path+0x386a>
    e078:      	leaq	0x18(%r12), %rbx
    e07d:      	movl	$0x4, %eax
    e082:      	movq	%rbp, %rdi
    e085:      	movl	$0x8, %esi
    e08a:      	movq	%rbx, %rdx
    e08d:      	callq	*%rax
    e08f:      	cmpq	%r12, (%rsp)
    e093:      	je	0xe16a <generic_usdt_path+0x386a>
    e099:      	movl	$0x4, %eax
    e09e:      	leaq	0x8(%rsp), %rdi
    e0a3:      	movl	$0x8, %esi
    e0a8:      	movq	%rbx, %rdx
    e0ab:      	callq	*%rax
    e0ad:      	addq	$0x20, %r12
    e0b1:      	movl	$0x4, %eax
    e0b6:      	leaq	0x58(%rsp), %rdi
    e0bb:      	movl	$0x10, %ecx
    e0c0:      	movl	$0x10, %esi
    e0c5:      	movq	%r12, %rdx
    e0c8:      	callq	*%rax
    e0ca:      	movq	0x28(%rsp), %rbx
    e0cf:      	movq	0x48(%rsp), %rax
    e0d4:      	movl	0x5c(%rsp), %r15d
    e0d9:      	subq	%rbx, %rax
    e0dc:      	movl	0x50(%rsp), %r12d
    e0e1:      	movl	%r15d, %edx
    e0e4:      	subl	%r12d, %edx
    e0e7:      	movl	$0x0, %ecx
    e0ec:      	cmovbl	%ecx, %edx
    e0ef:      	addq	0x60(%rsp), %rdx
    e0f4:      	xorl	%esi, %esi
    e0f6:      	cmpl	%r15d, %r12d
    e0f9:      	seta	%sil
    e0fd:      	movl	%r15d, %ecx
    e100:      	cmovbl	%r12d, %ecx
    e104:      	addl	%ecx, %esi
    e106:      	movl	%r12d, %edi
    e109:      	subl	%esi, %edi
    e10b:      	movl	%edi, 0x50(%rsp)
    e10f:      	subq	%rsi, %rax
    e112:      	jb	0x16372 <generic_usdt_path+0xba72>
    e118:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e11e:      	ja	0x16372 <generic_usdt_path+0xba72>
    e124:      	cmpl	%r15d, %r12d
    e127:      	jbe	0xe12d <generic_usdt_path+0x382d>
    e129:      	movb	$0x2f, (%rbx,%rax)
    e12d:      	xorl	%edi, %edi
    e12f:      	cmpl	%r15d, %r12d
    e132:      	seta	%dil
    e136:      	movzbl	%cl, %esi
    e139:      	addq	%rax, %rbx
    e13c:      	addq	%rbx, %rdi
    e13f:      	movl	$0x4, %eax
    e144:      	callq	*%rax
    e146:      	movq	%rbx, 0x48(%rsp)
    e14b:      	cmpl	%r15d, %r12d
    e14e:      	jbe	0x16372 <generic_usdt_path+0xba72>
    e154:      	movq	0x8(%rsp), %r12
    e159:      	movq	%r12, 0x30(%rsp)
    e15e:      	movq	0x38(%rsp), %rdx
    e163:      	movq	0x40(%rsp), %r15
    e168:      	jmp	0xe1bb <generic_usdt_path+0x38bb>
    e16a:      	leaq	0x10(%r15), %rdx
    e16e:      	movl	$0x4, %eax
    e173:      	movq	%rbp, %rdi
    e176:      	movl	$0x8, %esi
    e17b:      	callq	*%rax
    e17d:      	movq	0x40(%rsp), %rax
    e182:      	cmpq	(%rsp), %rax
    e186:      	je	0x1636d <generic_usdt_path+0xba6d>
    e18c:      	addq	$0x18, %r15
    e190:      	movl	$0x4, %eax
    e195:      	leaq	0x30(%rsp), %rdi
    e19a:      	movl	$0x8, %esi
    e19f:      	movq	%r15, %rdx
    e1a2:      	callq	*%rax
    e1a4:      	movq	(%rsp), %r15
    e1a8:      	movq	%r15, 0x40(%rsp)
    e1ad:      	leaq	0x20(%r15), %rdx
    e1b1:      	movq	%rdx, 0x38(%rsp)
    e1b6:      	movq	0x30(%rsp), %r12
    e1bb:      	cmpq	0x18(%rsp), %r12
    e1c0:      	jne	0xe1cd <generic_usdt_path+0x38cd>
    e1c2:      	cmpq	0x20(%rsp), %rdx
    e1c7:      	je	0x1636d <generic_usdt_path+0xba6d>
    e1cd:      	movl	$0x4, %eax
    e1d2:      	leaq	0x10(%rsp), %rdi
    e1d7:      	movl	$0x8, %esi
    e1dc:      	callq	*%rax
    e1de:      	cmpq	0x10(%rsp), %r12
    e1e3:      	je	0xe2db <generic_usdt_path+0x39db>
    e1e9:      	leaq	0x18(%r12), %rbx
    e1ee:      	movl	$0x4, %eax
    e1f3:      	movq	%rbp, %rdi
    e1f6:      	movl	$0x8, %esi
    e1fb:      	movq	%rbx, %rdx
    e1fe:      	callq	*%rax
    e200:      	cmpq	%r12, (%rsp)
    e204:      	je	0xe2db <generic_usdt_path+0x39db>
    e20a:      	movl	$0x4, %eax
    e20f:      	leaq	0x8(%rsp), %rdi
    e214:      	movl	$0x8, %esi
    e219:      	movq	%rbx, %rdx
    e21c:      	callq	*%rax
    e21e:      	addq	$0x20, %r12
    e222:      	movl	$0x4, %eax
    e227:      	leaq	0x58(%rsp), %rdi
    e22c:      	movl	$0x10, %ecx
    e231:      	movl	$0x10, %esi
    e236:      	movq	%r12, %rdx
    e239:      	callq	*%rax
    e23b:      	movq	0x28(%rsp), %rbx
    e240:      	movq	0x48(%rsp), %rax
    e245:      	movl	0x5c(%rsp), %r15d
    e24a:      	subq	%rbx, %rax
    e24d:      	movl	0x50(%rsp), %r12d
    e252:      	movl	%r15d, %edx
    e255:      	subl	%r12d, %edx
    e258:      	movl	$0x0, %ecx
    e25d:      	cmovbl	%ecx, %edx
    e260:      	addq	0x60(%rsp), %rdx
    e265:      	xorl	%esi, %esi
    e267:      	cmpl	%r15d, %r12d
    e26a:      	seta	%sil
    e26e:      	movl	%r15d, %ecx
    e271:      	cmovbl	%r12d, %ecx
    e275:      	addl	%ecx, %esi
    e277:      	movl	%r12d, %edi
    e27a:      	subl	%esi, %edi
    e27c:      	movl	%edi, 0x50(%rsp)
    e280:      	subq	%rsi, %rax
    e283:      	jb	0x16372 <generic_usdt_path+0xba72>
    e289:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e28f:      	ja	0x16372 <generic_usdt_path+0xba72>
    e295:      	cmpl	%r15d, %r12d
    e298:      	jbe	0xe29e <generic_usdt_path+0x399e>
    e29a:      	movb	$0x2f, (%rbx,%rax)
    e29e:      	xorl	%edi, %edi
    e2a0:      	cmpl	%r15d, %r12d
    e2a3:      	seta	%dil
    e2a7:      	movzbl	%cl, %esi
    e2aa:      	addq	%rax, %rbx
    e2ad:      	addq	%rbx, %rdi
    e2b0:      	movl	$0x4, %eax
    e2b5:      	callq	*%rax
    e2b7:      	movq	%rbx, 0x48(%rsp)
    e2bc:      	cmpl	%r15d, %r12d
    e2bf:      	jbe	0x16372 <generic_usdt_path+0xba72>
    e2c5:      	movq	0x8(%rsp), %r12
    e2ca:      	movq	%r12, 0x30(%rsp)
    e2cf:      	movq	0x38(%rsp), %rdx
    e2d4:      	movq	0x40(%rsp), %r15
    e2d9:      	jmp	0xe32c <generic_usdt_path+0x3a2c>
    e2db:      	leaq	0x10(%r15), %rdx
    e2df:      	movl	$0x4, %eax
    e2e4:      	movq	%rbp, %rdi
    e2e7:      	movl	$0x8, %esi
    e2ec:      	callq	*%rax
    e2ee:      	movq	0x40(%rsp), %rax
    e2f3:      	cmpq	(%rsp), %rax
    e2f7:      	je	0x1636d <generic_usdt_path+0xba6d>
    e2fd:      	addq	$0x18, %r15
    e301:      	movl	$0x4, %eax
    e306:      	leaq	0x30(%rsp), %rdi
    e30b:      	movl	$0x8, %esi
    e310:      	movq	%r15, %rdx
    e313:      	callq	*%rax
    e315:      	movq	(%rsp), %r15
    e319:      	movq	%r15, 0x40(%rsp)
    e31e:      	leaq	0x20(%r15), %rdx
    e322:      	movq	%rdx, 0x38(%rsp)
    e327:      	movq	0x30(%rsp), %r12
    e32c:      	cmpq	0x18(%rsp), %r12
    e331:      	jne	0xe33e <generic_usdt_path+0x3a3e>
    e333:      	cmpq	0x20(%rsp), %rdx
    e338:      	je	0x1636d <generic_usdt_path+0xba6d>
    e33e:      	movl	$0x4, %eax
    e343:      	leaq	0x10(%rsp), %rdi
    e348:      	movl	$0x8, %esi
    e34d:      	callq	*%rax
    e34f:      	cmpq	0x10(%rsp), %r12
    e354:      	je	0xe44c <generic_usdt_path+0x3b4c>
    e35a:      	leaq	0x18(%r12), %rbx
    e35f:      	movl	$0x4, %eax
    e364:      	movq	%rbp, %rdi
    e367:      	movl	$0x8, %esi
    e36c:      	movq	%rbx, %rdx
    e36f:      	callq	*%rax
    e371:      	cmpq	%r12, (%rsp)
    e375:      	je	0xe44c <generic_usdt_path+0x3b4c>
    e37b:      	movl	$0x4, %eax
    e380:      	leaq	0x8(%rsp), %rdi
    e385:      	movl	$0x8, %esi
    e38a:      	movq	%rbx, %rdx
    e38d:      	callq	*%rax
    e38f:      	addq	$0x20, %r12
    e393:      	movl	$0x4, %eax
    e398:      	leaq	0x58(%rsp), %rdi
    e39d:      	movl	$0x10, %ecx
    e3a2:      	movl	$0x10, %esi
    e3a7:      	movq	%r12, %rdx
    e3aa:      	callq	*%rax
    e3ac:      	movq	0x28(%rsp), %rbx
    e3b1:      	movq	0x48(%rsp), %rax
    e3b6:      	movl	0x5c(%rsp), %r15d
    e3bb:      	subq	%rbx, %rax
    e3be:      	movl	0x50(%rsp), %r12d
    e3c3:      	movl	%r15d, %edx
    e3c6:      	subl	%r12d, %edx
    e3c9:      	movl	$0x0, %ecx
    e3ce:      	cmovbl	%ecx, %edx
    e3d1:      	addq	0x60(%rsp), %rdx
    e3d6:      	xorl	%esi, %esi
    e3d8:      	cmpl	%r15d, %r12d
    e3db:      	seta	%sil
    e3df:      	movl	%r15d, %ecx
    e3e2:      	cmovbl	%r12d, %ecx
    e3e6:      	addl	%ecx, %esi
    e3e8:      	movl	%r12d, %edi
    e3eb:      	subl	%esi, %edi
    e3ed:      	movl	%edi, 0x50(%rsp)
    e3f1:      	subq	%rsi, %rax
    e3f4:      	jb	0x16372 <generic_usdt_path+0xba72>
    e3fa:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e400:      	ja	0x16372 <generic_usdt_path+0xba72>
    e406:      	cmpl	%r15d, %r12d
    e409:      	jbe	0xe40f <generic_usdt_path+0x3b0f>
    e40b:      	movb	$0x2f, (%rbx,%rax)
    e40f:      	xorl	%edi, %edi
    e411:      	cmpl	%r15d, %r12d
    e414:      	seta	%dil
    e418:      	movzbl	%cl, %esi
    e41b:      	addq	%rax, %rbx
    e41e:      	addq	%rbx, %rdi
    e421:      	movl	$0x4, %eax
    e426:      	callq	*%rax
    e428:      	movq	%rbx, 0x48(%rsp)
    e42d:      	cmpl	%r15d, %r12d
    e430:      	jbe	0x16372 <generic_usdt_path+0xba72>
    e436:      	movq	0x8(%rsp), %r12
    e43b:      	movq	%r12, 0x30(%rsp)
    e440:      	movq	0x38(%rsp), %rdx
    e445:      	movq	0x40(%rsp), %r15
    e44a:      	jmp	0xe49d <generic_usdt_path+0x3b9d>
    e44c:      	leaq	0x10(%r15), %rdx
    e450:      	movl	$0x4, %eax
    e455:      	movq	%rbp, %rdi
    e458:      	movl	$0x8, %esi
    e45d:      	callq	*%rax
    e45f:      	movq	0x40(%rsp), %rax
    e464:      	cmpq	(%rsp), %rax
    e468:      	je	0x1636d <generic_usdt_path+0xba6d>
    e46e:      	addq	$0x18, %r15
    e472:      	movl	$0x4, %eax
    e477:      	leaq	0x30(%rsp), %rdi
    e47c:      	movl	$0x8, %esi
    e481:      	movq	%r15, %rdx
    e484:      	callq	*%rax
    e486:      	movq	(%rsp), %r15
    e48a:      	movq	%r15, 0x40(%rsp)
    e48f:      	leaq	0x20(%r15), %rdx
    e493:      	movq	%rdx, 0x38(%rsp)
    e498:      	movq	0x30(%rsp), %r12
    e49d:      	cmpq	0x18(%rsp), %r12
    e4a2:      	jne	0xe4af <generic_usdt_path+0x3baf>
    e4a4:      	cmpq	0x20(%rsp), %rdx
    e4a9:      	je	0x1636d <generic_usdt_path+0xba6d>
    e4af:      	movl	$0x4, %eax
    e4b4:      	leaq	0x10(%rsp), %rdi
    e4b9:      	movl	$0x8, %esi
    e4be:      	callq	*%rax
    e4c0:      	cmpq	0x10(%rsp), %r12
    e4c5:      	je	0xe5bd <generic_usdt_path+0x3cbd>
    e4cb:      	leaq	0x18(%r12), %rbx
    e4d0:      	movl	$0x4, %eax
    e4d5:      	movq	%rbp, %rdi
    e4d8:      	movl	$0x8, %esi
    e4dd:      	movq	%rbx, %rdx
    e4e0:      	callq	*%rax
    e4e2:      	cmpq	%r12, (%rsp)
    e4e6:      	je	0xe5bd <generic_usdt_path+0x3cbd>
    e4ec:      	movl	$0x4, %eax
    e4f1:      	leaq	0x8(%rsp), %rdi
    e4f6:      	movl	$0x8, %esi
    e4fb:      	movq	%rbx, %rdx
    e4fe:      	callq	*%rax
    e500:      	addq	$0x20, %r12
    e504:      	movl	$0x4, %eax
    e509:      	leaq	0x58(%rsp), %rdi
    e50e:      	movl	$0x10, %ecx
    e513:      	movl	$0x10, %esi
    e518:      	movq	%r12, %rdx
    e51b:      	callq	*%rax
    e51d:      	movq	0x28(%rsp), %rbx
    e522:      	movq	0x48(%rsp), %rax
    e527:      	movl	0x5c(%rsp), %r15d
    e52c:      	subq	%rbx, %rax
    e52f:      	movl	0x50(%rsp), %r12d
    e534:      	movl	%r15d, %edx
    e537:      	subl	%r12d, %edx
    e53a:      	movl	$0x0, %ecx
    e53f:      	cmovbl	%ecx, %edx
    e542:      	addq	0x60(%rsp), %rdx
    e547:      	xorl	%esi, %esi
    e549:      	cmpl	%r15d, %r12d
    e54c:      	seta	%sil
    e550:      	movl	%r15d, %ecx
    e553:      	cmovbl	%r12d, %ecx
    e557:      	addl	%ecx, %esi
    e559:      	movl	%r12d, %edi
    e55c:      	subl	%esi, %edi
    e55e:      	movl	%edi, 0x50(%rsp)
    e562:      	subq	%rsi, %rax
    e565:      	jb	0x16372 <generic_usdt_path+0xba72>
    e56b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e571:      	ja	0x16372 <generic_usdt_path+0xba72>
    e577:      	cmpl	%r15d, %r12d
    e57a:      	jbe	0xe580 <generic_usdt_path+0x3c80>
    e57c:      	movb	$0x2f, (%rbx,%rax)
    e580:      	xorl	%edi, %edi
    e582:      	cmpl	%r15d, %r12d
    e585:      	seta	%dil
    e589:      	movzbl	%cl, %esi
    e58c:      	addq	%rax, %rbx
    e58f:      	addq	%rbx, %rdi
    e592:      	movl	$0x4, %eax
    e597:      	callq	*%rax
    e599:      	movq	%rbx, 0x48(%rsp)
    e59e:      	cmpl	%r15d, %r12d
    e5a1:      	jbe	0x16372 <generic_usdt_path+0xba72>
    e5a7:      	movq	0x8(%rsp), %r12
    e5ac:      	movq	%r12, 0x30(%rsp)
    e5b1:      	movq	0x38(%rsp), %rdx
    e5b6:      	movq	0x40(%rsp), %r15
    e5bb:      	jmp	0xe60e <generic_usdt_path+0x3d0e>
    e5bd:      	leaq	0x10(%r15), %rdx
    e5c1:      	movl	$0x4, %eax
    e5c6:      	movq	%rbp, %rdi
    e5c9:      	movl	$0x8, %esi
    e5ce:      	callq	*%rax
    e5d0:      	movq	0x40(%rsp), %rax
    e5d5:      	cmpq	(%rsp), %rax
    e5d9:      	je	0x1636d <generic_usdt_path+0xba6d>
    e5df:      	addq	$0x18, %r15
    e5e3:      	movl	$0x4, %eax
    e5e8:      	leaq	0x30(%rsp), %rdi
    e5ed:      	movl	$0x8, %esi
    e5f2:      	movq	%r15, %rdx
    e5f5:      	callq	*%rax
    e5f7:      	movq	(%rsp), %r15
    e5fb:      	movq	%r15, 0x40(%rsp)
    e600:      	leaq	0x20(%r15), %rdx
    e604:      	movq	%rdx, 0x38(%rsp)
    e609:      	movq	0x30(%rsp), %r12
    e60e:      	cmpq	0x18(%rsp), %r12
    e613:      	jne	0xe620 <generic_usdt_path+0x3d20>
    e615:      	cmpq	0x20(%rsp), %rdx
    e61a:      	je	0x1636d <generic_usdt_path+0xba6d>
    e620:      	movl	$0x4, %eax
    e625:      	leaq	0x10(%rsp), %rdi
    e62a:      	movl	$0x8, %esi
    e62f:      	callq	*%rax
    e631:      	cmpq	0x10(%rsp), %r12
    e636:      	je	0xe72e <generic_usdt_path+0x3e2e>
    e63c:      	leaq	0x18(%r12), %rbx
    e641:      	movl	$0x4, %eax
    e646:      	movq	%rbp, %rdi
    e649:      	movl	$0x8, %esi
    e64e:      	movq	%rbx, %rdx
    e651:      	callq	*%rax
    e653:      	cmpq	%r12, (%rsp)
    e657:      	je	0xe72e <generic_usdt_path+0x3e2e>
    e65d:      	movl	$0x4, %eax
    e662:      	leaq	0x8(%rsp), %rdi
    e667:      	movl	$0x8, %esi
    e66c:      	movq	%rbx, %rdx
    e66f:      	callq	*%rax
    e671:      	addq	$0x20, %r12
    e675:      	movl	$0x4, %eax
    e67a:      	leaq	0x58(%rsp), %rdi
    e67f:      	movl	$0x10, %ecx
    e684:      	movl	$0x10, %esi
    e689:      	movq	%r12, %rdx
    e68c:      	callq	*%rax
    e68e:      	movq	0x28(%rsp), %rbx
    e693:      	movq	0x48(%rsp), %rax
    e698:      	movl	0x5c(%rsp), %r15d
    e69d:      	subq	%rbx, %rax
    e6a0:      	movl	0x50(%rsp), %r12d
    e6a5:      	movl	%r15d, %edx
    e6a8:      	subl	%r12d, %edx
    e6ab:      	movl	$0x0, %ecx
    e6b0:      	cmovbl	%ecx, %edx
    e6b3:      	addq	0x60(%rsp), %rdx
    e6b8:      	xorl	%esi, %esi
    e6ba:      	cmpl	%r15d, %r12d
    e6bd:      	seta	%sil
    e6c1:      	movl	%r15d, %ecx
    e6c4:      	cmovbl	%r12d, %ecx
    e6c8:      	addl	%ecx, %esi
    e6ca:      	movl	%r12d, %edi
    e6cd:      	subl	%esi, %edi
    e6cf:      	movl	%edi, 0x50(%rsp)
    e6d3:      	subq	%rsi, %rax
    e6d6:      	jb	0x16372 <generic_usdt_path+0xba72>
    e6dc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e6e2:      	ja	0x16372 <generic_usdt_path+0xba72>
    e6e8:      	cmpl	%r15d, %r12d
    e6eb:      	jbe	0xe6f1 <generic_usdt_path+0x3df1>
    e6ed:      	movb	$0x2f, (%rbx,%rax)
    e6f1:      	xorl	%edi, %edi
    e6f3:      	cmpl	%r15d, %r12d
    e6f6:      	seta	%dil
    e6fa:      	movzbl	%cl, %esi
    e6fd:      	addq	%rax, %rbx
    e700:      	addq	%rbx, %rdi
    e703:      	movl	$0x4, %eax
    e708:      	callq	*%rax
    e70a:      	movq	%rbx, 0x48(%rsp)
    e70f:      	cmpl	%r15d, %r12d
    e712:      	jbe	0x16372 <generic_usdt_path+0xba72>
    e718:      	movq	0x8(%rsp), %r12
    e71d:      	movq	%r12, 0x30(%rsp)
    e722:      	movq	0x38(%rsp), %rdx
    e727:      	movq	0x40(%rsp), %r15
    e72c:      	jmp	0xe77f <generic_usdt_path+0x3e7f>
    e72e:      	leaq	0x10(%r15), %rdx
    e732:      	movl	$0x4, %eax
    e737:      	movq	%rbp, %rdi
    e73a:      	movl	$0x8, %esi
    e73f:      	callq	*%rax
    e741:      	movq	0x40(%rsp), %rax
    e746:      	cmpq	(%rsp), %rax
    e74a:      	je	0x1636d <generic_usdt_path+0xba6d>
    e750:      	addq	$0x18, %r15
    e754:      	movl	$0x4, %eax
    e759:      	leaq	0x30(%rsp), %rdi
    e75e:      	movl	$0x8, %esi
    e763:      	movq	%r15, %rdx
    e766:      	callq	*%rax
    e768:      	movq	(%rsp), %r15
    e76c:      	movq	%r15, 0x40(%rsp)
    e771:      	leaq	0x20(%r15), %rdx
    e775:      	movq	%rdx, 0x38(%rsp)
    e77a:      	movq	0x30(%rsp), %r12
    e77f:      	cmpq	0x18(%rsp), %r12
    e784:      	jne	0xe791 <generic_usdt_path+0x3e91>
    e786:      	cmpq	0x20(%rsp), %rdx
    e78b:      	je	0x1636d <generic_usdt_path+0xba6d>
    e791:      	movl	$0x4, %eax
    e796:      	leaq	0x10(%rsp), %rdi
    e79b:      	movl	$0x8, %esi
    e7a0:      	callq	*%rax
    e7a2:      	cmpq	0x10(%rsp), %r12
    e7a7:      	je	0xe89f <generic_usdt_path+0x3f9f>
    e7ad:      	leaq	0x18(%r12), %rbx
    e7b2:      	movl	$0x4, %eax
    e7b7:      	movq	%rbp, %rdi
    e7ba:      	movl	$0x8, %esi
    e7bf:      	movq	%rbx, %rdx
    e7c2:      	callq	*%rax
    e7c4:      	cmpq	%r12, (%rsp)
    e7c8:      	je	0xe89f <generic_usdt_path+0x3f9f>
    e7ce:      	movl	$0x4, %eax
    e7d3:      	leaq	0x8(%rsp), %rdi
    e7d8:      	movl	$0x8, %esi
    e7dd:      	movq	%rbx, %rdx
    e7e0:      	callq	*%rax
    e7e2:      	addq	$0x20, %r12
    e7e6:      	movl	$0x4, %eax
    e7eb:      	leaq	0x58(%rsp), %rdi
    e7f0:      	movl	$0x10, %ecx
    e7f5:      	movl	$0x10, %esi
    e7fa:      	movq	%r12, %rdx
    e7fd:      	callq	*%rax
    e7ff:      	movq	0x28(%rsp), %rbx
    e804:      	movq	0x48(%rsp), %rax
    e809:      	movl	0x5c(%rsp), %r15d
    e80e:      	subq	%rbx, %rax
    e811:      	movl	0x50(%rsp), %r12d
    e816:      	movl	%r15d, %edx
    e819:      	subl	%r12d, %edx
    e81c:      	movl	$0x0, %ecx
    e821:      	cmovbl	%ecx, %edx
    e824:      	addq	0x60(%rsp), %rdx
    e829:      	xorl	%esi, %esi
    e82b:      	cmpl	%r15d, %r12d
    e82e:      	seta	%sil
    e832:      	movl	%r15d, %ecx
    e835:      	cmovbl	%r12d, %ecx
    e839:      	addl	%ecx, %esi
    e83b:      	movl	%r12d, %edi
    e83e:      	subl	%esi, %edi
    e840:      	movl	%edi, 0x50(%rsp)
    e844:      	subq	%rsi, %rax
    e847:      	jb	0x16372 <generic_usdt_path+0xba72>
    e84d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e853:      	ja	0x16372 <generic_usdt_path+0xba72>
    e859:      	cmpl	%r15d, %r12d
    e85c:      	jbe	0xe862 <generic_usdt_path+0x3f62>
    e85e:      	movb	$0x2f, (%rbx,%rax)
    e862:      	xorl	%edi, %edi
    e864:      	cmpl	%r15d, %r12d
    e867:      	seta	%dil
    e86b:      	movzbl	%cl, %esi
    e86e:      	addq	%rax, %rbx
    e871:      	addq	%rbx, %rdi
    e874:      	movl	$0x4, %eax
    e879:      	callq	*%rax
    e87b:      	movq	%rbx, 0x48(%rsp)
    e880:      	cmpl	%r15d, %r12d
    e883:      	jbe	0x16372 <generic_usdt_path+0xba72>
    e889:      	movq	0x8(%rsp), %r12
    e88e:      	movq	%r12, 0x30(%rsp)
    e893:      	movq	0x38(%rsp), %rdx
    e898:      	movq	0x40(%rsp), %r15
    e89d:      	jmp	0xe8f0 <generic_usdt_path+0x3ff0>
    e89f:      	leaq	0x10(%r15), %rdx
    e8a3:      	movl	$0x4, %eax
    e8a8:      	movq	%rbp, %rdi
    e8ab:      	movl	$0x8, %esi
    e8b0:      	callq	*%rax
    e8b2:      	movq	0x40(%rsp), %rax
    e8b7:      	cmpq	(%rsp), %rax
    e8bb:      	je	0x1636d <generic_usdt_path+0xba6d>
    e8c1:      	addq	$0x18, %r15
    e8c5:      	movl	$0x4, %eax
    e8ca:      	leaq	0x30(%rsp), %rdi
    e8cf:      	movl	$0x8, %esi
    e8d4:      	movq	%r15, %rdx
    e8d7:      	callq	*%rax
    e8d9:      	movq	(%rsp), %r15
    e8dd:      	movq	%r15, 0x40(%rsp)
    e8e2:      	leaq	0x20(%r15), %rdx
    e8e6:      	movq	%rdx, 0x38(%rsp)
    e8eb:      	movq	0x30(%rsp), %r12
    e8f0:      	cmpq	0x18(%rsp), %r12
    e8f5:      	jne	0xe902 <generic_usdt_path+0x4002>
    e8f7:      	cmpq	0x20(%rsp), %rdx
    e8fc:      	je	0x1636d <generic_usdt_path+0xba6d>
    e902:      	movl	$0x4, %eax
    e907:      	leaq	0x10(%rsp), %rdi
    e90c:      	movl	$0x8, %esi
    e911:      	callq	*%rax
    e913:      	cmpq	0x10(%rsp), %r12
    e918:      	je	0xea10 <generic_usdt_path+0x4110>
    e91e:      	leaq	0x18(%r12), %rbx
    e923:      	movl	$0x4, %eax
    e928:      	movq	%rbp, %rdi
    e92b:      	movl	$0x8, %esi
    e930:      	movq	%rbx, %rdx
    e933:      	callq	*%rax
    e935:      	cmpq	%r12, (%rsp)
    e939:      	je	0xea10 <generic_usdt_path+0x4110>
    e93f:      	movl	$0x4, %eax
    e944:      	leaq	0x8(%rsp), %rdi
    e949:      	movl	$0x8, %esi
    e94e:      	movq	%rbx, %rdx
    e951:      	callq	*%rax
    e953:      	addq	$0x20, %r12
    e957:      	movl	$0x4, %eax
    e95c:      	leaq	0x58(%rsp), %rdi
    e961:      	movl	$0x10, %ecx
    e966:      	movl	$0x10, %esi
    e96b:      	movq	%r12, %rdx
    e96e:      	callq	*%rax
    e970:      	movq	0x28(%rsp), %rbx
    e975:      	movq	0x48(%rsp), %rax
    e97a:      	movl	0x5c(%rsp), %r15d
    e97f:      	subq	%rbx, %rax
    e982:      	movl	0x50(%rsp), %r12d
    e987:      	movl	%r15d, %edx
    e98a:      	subl	%r12d, %edx
    e98d:      	movl	$0x0, %ecx
    e992:      	cmovbl	%ecx, %edx
    e995:      	addq	0x60(%rsp), %rdx
    e99a:      	xorl	%esi, %esi
    e99c:      	cmpl	%r15d, %r12d
    e99f:      	seta	%sil
    e9a3:      	movl	%r15d, %ecx
    e9a6:      	cmovbl	%r12d, %ecx
    e9aa:      	addl	%ecx, %esi
    e9ac:      	movl	%r12d, %edi
    e9af:      	subl	%esi, %edi
    e9b1:      	movl	%edi, 0x50(%rsp)
    e9b5:      	subq	%rsi, %rax
    e9b8:      	jb	0x16372 <generic_usdt_path+0xba72>
    e9be:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    e9c4:      	ja	0x16372 <generic_usdt_path+0xba72>
    e9ca:      	cmpl	%r15d, %r12d
    e9cd:      	jbe	0xe9d3 <generic_usdt_path+0x40d3>
    e9cf:      	movb	$0x2f, (%rbx,%rax)
    e9d3:      	xorl	%edi, %edi
    e9d5:      	cmpl	%r15d, %r12d
    e9d8:      	seta	%dil
    e9dc:      	movzbl	%cl, %esi
    e9df:      	addq	%rax, %rbx
    e9e2:      	addq	%rbx, %rdi
    e9e5:      	movl	$0x4, %eax
    e9ea:      	callq	*%rax
    e9ec:      	movq	%rbx, 0x48(%rsp)
    e9f1:      	cmpl	%r15d, %r12d
    e9f4:      	jbe	0x16372 <generic_usdt_path+0xba72>
    e9fa:      	movq	0x8(%rsp), %r12
    e9ff:      	movq	%r12, 0x30(%rsp)
    ea04:      	movq	0x38(%rsp), %rdx
    ea09:      	movq	0x40(%rsp), %r15
    ea0e:      	jmp	0xea61 <generic_usdt_path+0x4161>
    ea10:      	leaq	0x10(%r15), %rdx
    ea14:      	movl	$0x4, %eax
    ea19:      	movq	%rbp, %rdi
    ea1c:      	movl	$0x8, %esi
    ea21:      	callq	*%rax
    ea23:      	movq	0x40(%rsp), %rax
    ea28:      	cmpq	(%rsp), %rax
    ea2c:      	je	0x1636d <generic_usdt_path+0xba6d>
    ea32:      	addq	$0x18, %r15
    ea36:      	movl	$0x4, %eax
    ea3b:      	leaq	0x30(%rsp), %rdi
    ea40:      	movl	$0x8, %esi
    ea45:      	movq	%r15, %rdx
    ea48:      	callq	*%rax
    ea4a:      	movq	(%rsp), %r15
    ea4e:      	movq	%r15, 0x40(%rsp)
    ea53:      	leaq	0x20(%r15), %rdx
    ea57:      	movq	%rdx, 0x38(%rsp)
    ea5c:      	movq	0x30(%rsp), %r12
    ea61:      	cmpq	0x18(%rsp), %r12
    ea66:      	jne	0xea73 <generic_usdt_path+0x4173>
    ea68:      	cmpq	0x20(%rsp), %rdx
    ea6d:      	je	0x1636d <generic_usdt_path+0xba6d>
    ea73:      	movl	$0x4, %eax
    ea78:      	leaq	0x10(%rsp), %rdi
    ea7d:      	movl	$0x8, %esi
    ea82:      	callq	*%rax
    ea84:      	cmpq	0x10(%rsp), %r12
    ea89:      	je	0xeb81 <generic_usdt_path+0x4281>
    ea8f:      	leaq	0x18(%r12), %rbx
    ea94:      	movl	$0x4, %eax
    ea99:      	movq	%rbp, %rdi
    ea9c:      	movl	$0x8, %esi
    eaa1:      	movq	%rbx, %rdx
    eaa4:      	callq	*%rax
    eaa6:      	cmpq	%r12, (%rsp)
    eaaa:      	je	0xeb81 <generic_usdt_path+0x4281>
    eab0:      	movl	$0x4, %eax
    eab5:      	leaq	0x8(%rsp), %rdi
    eaba:      	movl	$0x8, %esi
    eabf:      	movq	%rbx, %rdx
    eac2:      	callq	*%rax
    eac4:      	addq	$0x20, %r12
    eac8:      	movl	$0x4, %eax
    eacd:      	leaq	0x58(%rsp), %rdi
    ead2:      	movl	$0x10, %ecx
    ead7:      	movl	$0x10, %esi
    eadc:      	movq	%r12, %rdx
    eadf:      	callq	*%rax
    eae1:      	movq	0x28(%rsp), %rbx
    eae6:      	movq	0x48(%rsp), %rax
    eaeb:      	movl	0x5c(%rsp), %r15d
    eaf0:      	subq	%rbx, %rax
    eaf3:      	movl	0x50(%rsp), %r12d
    eaf8:      	movl	%r15d, %edx
    eafb:      	subl	%r12d, %edx
    eafe:      	movl	$0x0, %ecx
    eb03:      	cmovbl	%ecx, %edx
    eb06:      	addq	0x60(%rsp), %rdx
    eb0b:      	xorl	%esi, %esi
    eb0d:      	cmpl	%r15d, %r12d
    eb10:      	seta	%sil
    eb14:      	movl	%r15d, %ecx
    eb17:      	cmovbl	%r12d, %ecx
    eb1b:      	addl	%ecx, %esi
    eb1d:      	movl	%r12d, %edi
    eb20:      	subl	%esi, %edi
    eb22:      	movl	%edi, 0x50(%rsp)
    eb26:      	subq	%rsi, %rax
    eb29:      	jb	0x16372 <generic_usdt_path+0xba72>
    eb2f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    eb35:      	ja	0x16372 <generic_usdt_path+0xba72>
    eb3b:      	cmpl	%r15d, %r12d
    eb3e:      	jbe	0xeb44 <generic_usdt_path+0x4244>
    eb40:      	movb	$0x2f, (%rbx,%rax)
    eb44:      	xorl	%edi, %edi
    eb46:      	cmpl	%r15d, %r12d
    eb49:      	seta	%dil
    eb4d:      	movzbl	%cl, %esi
    eb50:      	addq	%rax, %rbx
    eb53:      	addq	%rbx, %rdi
    eb56:      	movl	$0x4, %eax
    eb5b:      	callq	*%rax
    eb5d:      	movq	%rbx, 0x48(%rsp)
    eb62:      	cmpl	%r15d, %r12d
    eb65:      	jbe	0x16372 <generic_usdt_path+0xba72>
    eb6b:      	movq	0x8(%rsp), %r12
    eb70:      	movq	%r12, 0x30(%rsp)
    eb75:      	movq	0x38(%rsp), %rdx
    eb7a:      	movq	0x40(%rsp), %r15
    eb7f:      	jmp	0xebd2 <generic_usdt_path+0x42d2>
    eb81:      	leaq	0x10(%r15), %rdx
    eb85:      	movl	$0x4, %eax
    eb8a:      	movq	%rbp, %rdi
    eb8d:      	movl	$0x8, %esi
    eb92:      	callq	*%rax
    eb94:      	movq	0x40(%rsp), %rax
    eb99:      	cmpq	(%rsp), %rax
    eb9d:      	je	0x1636d <generic_usdt_path+0xba6d>
    eba3:      	addq	$0x18, %r15
    eba7:      	movl	$0x4, %eax
    ebac:      	leaq	0x30(%rsp), %rdi
    ebb1:      	movl	$0x8, %esi
    ebb6:      	movq	%r15, %rdx
    ebb9:      	callq	*%rax
    ebbb:      	movq	(%rsp), %r15
    ebbf:      	movq	%r15, 0x40(%rsp)
    ebc4:      	leaq	0x20(%r15), %rdx
    ebc8:      	movq	%rdx, 0x38(%rsp)
    ebcd:      	movq	0x30(%rsp), %r12
    ebd2:      	cmpq	0x18(%rsp), %r12
    ebd7:      	jne	0xebe4 <generic_usdt_path+0x42e4>
    ebd9:      	cmpq	0x20(%rsp), %rdx
    ebde:      	je	0x1636d <generic_usdt_path+0xba6d>
    ebe4:      	movl	$0x4, %eax
    ebe9:      	leaq	0x10(%rsp), %rdi
    ebee:      	movl	$0x8, %esi
    ebf3:      	callq	*%rax
    ebf5:      	cmpq	0x10(%rsp), %r12
    ebfa:      	je	0xecf2 <generic_usdt_path+0x43f2>
    ec00:      	leaq	0x18(%r12), %rbx
    ec05:      	movl	$0x4, %eax
    ec0a:      	movq	%rbp, %rdi
    ec0d:      	movl	$0x8, %esi
    ec12:      	movq	%rbx, %rdx
    ec15:      	callq	*%rax
    ec17:      	cmpq	%r12, (%rsp)
    ec1b:      	je	0xecf2 <generic_usdt_path+0x43f2>
    ec21:      	movl	$0x4, %eax
    ec26:      	leaq	0x8(%rsp), %rdi
    ec2b:      	movl	$0x8, %esi
    ec30:      	movq	%rbx, %rdx
    ec33:      	callq	*%rax
    ec35:      	addq	$0x20, %r12
    ec39:      	movl	$0x4, %eax
    ec3e:      	leaq	0x58(%rsp), %rdi
    ec43:      	movl	$0x10, %ecx
    ec48:      	movl	$0x10, %esi
    ec4d:      	movq	%r12, %rdx
    ec50:      	callq	*%rax
    ec52:      	movq	0x28(%rsp), %rbx
    ec57:      	movq	0x48(%rsp), %rax
    ec5c:      	movl	0x5c(%rsp), %r15d
    ec61:      	subq	%rbx, %rax
    ec64:      	movl	0x50(%rsp), %r12d
    ec69:      	movl	%r15d, %edx
    ec6c:      	subl	%r12d, %edx
    ec6f:      	movl	$0x0, %ecx
    ec74:      	cmovbl	%ecx, %edx
    ec77:      	addq	0x60(%rsp), %rdx
    ec7c:      	xorl	%esi, %esi
    ec7e:      	cmpl	%r15d, %r12d
    ec81:      	seta	%sil
    ec85:      	movl	%r15d, %ecx
    ec88:      	cmovbl	%r12d, %ecx
    ec8c:      	addl	%ecx, %esi
    ec8e:      	movl	%r12d, %edi
    ec91:      	subl	%esi, %edi
    ec93:      	movl	%edi, 0x50(%rsp)
    ec97:      	subq	%rsi, %rax
    ec9a:      	jb	0x16372 <generic_usdt_path+0xba72>
    eca0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    eca6:      	ja	0x16372 <generic_usdt_path+0xba72>
    ecac:      	cmpl	%r15d, %r12d
    ecaf:      	jbe	0xecb5 <generic_usdt_path+0x43b5>
    ecb1:      	movb	$0x2f, (%rbx,%rax)
    ecb5:      	xorl	%edi, %edi
    ecb7:      	cmpl	%r15d, %r12d
    ecba:      	seta	%dil
    ecbe:      	movzbl	%cl, %esi
    ecc1:      	addq	%rax, %rbx
    ecc4:      	addq	%rbx, %rdi
    ecc7:      	movl	$0x4, %eax
    eccc:      	callq	*%rax
    ecce:      	movq	%rbx, 0x48(%rsp)
    ecd3:      	cmpl	%r15d, %r12d
    ecd6:      	jbe	0x16372 <generic_usdt_path+0xba72>
    ecdc:      	movq	0x8(%rsp), %r12
    ece1:      	movq	%r12, 0x30(%rsp)
    ece6:      	movq	0x38(%rsp), %rdx
    eceb:      	movq	0x40(%rsp), %r15
    ecf0:      	jmp	0xed43 <generic_usdt_path+0x4443>
    ecf2:      	leaq	0x10(%r15), %rdx
    ecf6:      	movl	$0x4, %eax
    ecfb:      	movq	%rbp, %rdi
    ecfe:      	movl	$0x8, %esi
    ed03:      	callq	*%rax
    ed05:      	movq	0x40(%rsp), %rax
    ed0a:      	cmpq	(%rsp), %rax
    ed0e:      	je	0x1636d <generic_usdt_path+0xba6d>
    ed14:      	addq	$0x18, %r15
    ed18:      	movl	$0x4, %eax
    ed1d:      	leaq	0x30(%rsp), %rdi
    ed22:      	movl	$0x8, %esi
    ed27:      	movq	%r15, %rdx
    ed2a:      	callq	*%rax
    ed2c:      	movq	(%rsp), %r15
    ed30:      	movq	%r15, 0x40(%rsp)
    ed35:      	leaq	0x20(%r15), %rdx
    ed39:      	movq	%rdx, 0x38(%rsp)
    ed3e:      	movq	0x30(%rsp), %r12
    ed43:      	cmpq	0x18(%rsp), %r12
    ed48:      	jne	0xed55 <generic_usdt_path+0x4455>
    ed4a:      	cmpq	0x20(%rsp), %rdx
    ed4f:      	je	0x1636d <generic_usdt_path+0xba6d>
    ed55:      	movl	$0x4, %eax
    ed5a:      	leaq	0x10(%rsp), %rdi
    ed5f:      	movl	$0x8, %esi
    ed64:      	callq	*%rax
    ed66:      	cmpq	0x10(%rsp), %r12
    ed6b:      	je	0xee63 <generic_usdt_path+0x4563>
    ed71:      	leaq	0x18(%r12), %rbx
    ed76:      	movl	$0x4, %eax
    ed7b:      	movq	%rbp, %rdi
    ed7e:      	movl	$0x8, %esi
    ed83:      	movq	%rbx, %rdx
    ed86:      	callq	*%rax
    ed88:      	cmpq	%r12, (%rsp)
    ed8c:      	je	0xee63 <generic_usdt_path+0x4563>
    ed92:      	movl	$0x4, %eax
    ed97:      	leaq	0x8(%rsp), %rdi
    ed9c:      	movl	$0x8, %esi
    eda1:      	movq	%rbx, %rdx
    eda4:      	callq	*%rax
    eda6:      	addq	$0x20, %r12
    edaa:      	movl	$0x4, %eax
    edaf:      	leaq	0x58(%rsp), %rdi
    edb4:      	movl	$0x10, %ecx
    edb9:      	movl	$0x10, %esi
    edbe:      	movq	%r12, %rdx
    edc1:      	callq	*%rax
    edc3:      	movq	0x28(%rsp), %rbx
    edc8:      	movq	0x48(%rsp), %rax
    edcd:      	movl	0x5c(%rsp), %r15d
    edd2:      	subq	%rbx, %rax
    edd5:      	movl	0x50(%rsp), %r12d
    edda:      	movl	%r15d, %edx
    eddd:      	subl	%r12d, %edx
    ede0:      	movl	$0x0, %ecx
    ede5:      	cmovbl	%ecx, %edx
    ede8:      	addq	0x60(%rsp), %rdx
    eded:      	xorl	%esi, %esi
    edef:      	cmpl	%r15d, %r12d
    edf2:      	seta	%sil
    edf6:      	movl	%r15d, %ecx
    edf9:      	cmovbl	%r12d, %ecx
    edfd:      	addl	%ecx, %esi
    edff:      	movl	%r12d, %edi
    ee02:      	subl	%esi, %edi
    ee04:      	movl	%edi, 0x50(%rsp)
    ee08:      	subq	%rsi, %rax
    ee0b:      	jb	0x16372 <generic_usdt_path+0xba72>
    ee11:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ee17:      	ja	0x16372 <generic_usdt_path+0xba72>
    ee1d:      	cmpl	%r15d, %r12d
    ee20:      	jbe	0xee26 <generic_usdt_path+0x4526>
    ee22:      	movb	$0x2f, (%rbx,%rax)
    ee26:      	xorl	%edi, %edi
    ee28:      	cmpl	%r15d, %r12d
    ee2b:      	seta	%dil
    ee2f:      	movzbl	%cl, %esi
    ee32:      	addq	%rax, %rbx
    ee35:      	addq	%rbx, %rdi
    ee38:      	movl	$0x4, %eax
    ee3d:      	callq	*%rax
    ee3f:      	movq	%rbx, 0x48(%rsp)
    ee44:      	cmpl	%r15d, %r12d
    ee47:      	jbe	0x16372 <generic_usdt_path+0xba72>
    ee4d:      	movq	0x8(%rsp), %r12
    ee52:      	movq	%r12, 0x30(%rsp)
    ee57:      	movq	0x38(%rsp), %rdx
    ee5c:      	movq	0x40(%rsp), %r15
    ee61:      	jmp	0xeeb4 <generic_usdt_path+0x45b4>
    ee63:      	leaq	0x10(%r15), %rdx
    ee67:      	movl	$0x4, %eax
    ee6c:      	movq	%rbp, %rdi
    ee6f:      	movl	$0x8, %esi
    ee74:      	callq	*%rax
    ee76:      	movq	0x40(%rsp), %rax
    ee7b:      	cmpq	(%rsp), %rax
    ee7f:      	je	0x1636d <generic_usdt_path+0xba6d>
    ee85:      	addq	$0x18, %r15
    ee89:      	movl	$0x4, %eax
    ee8e:      	leaq	0x30(%rsp), %rdi
    ee93:      	movl	$0x8, %esi
    ee98:      	movq	%r15, %rdx
    ee9b:      	callq	*%rax
    ee9d:      	movq	(%rsp), %r15
    eea1:      	movq	%r15, 0x40(%rsp)
    eea6:      	leaq	0x20(%r15), %rdx
    eeaa:      	movq	%rdx, 0x38(%rsp)
    eeaf:      	movq	0x30(%rsp), %r12
    eeb4:      	cmpq	0x18(%rsp), %r12
    eeb9:      	jne	0xeec6 <generic_usdt_path+0x45c6>
    eebb:      	cmpq	0x20(%rsp), %rdx
    eec0:      	je	0x1636d <generic_usdt_path+0xba6d>
    eec6:      	movl	$0x4, %eax
    eecb:      	leaq	0x10(%rsp), %rdi
    eed0:      	movl	$0x8, %esi
    eed5:      	callq	*%rax
    eed7:      	cmpq	0x10(%rsp), %r12
    eedc:      	je	0xefd4 <generic_usdt_path+0x46d4>
    eee2:      	leaq	0x18(%r12), %rbx
    eee7:      	movl	$0x4, %eax
    eeec:      	movq	%rbp, %rdi
    eeef:      	movl	$0x8, %esi
    eef4:      	movq	%rbx, %rdx
    eef7:      	callq	*%rax
    eef9:      	cmpq	%r12, (%rsp)
    eefd:      	je	0xefd4 <generic_usdt_path+0x46d4>
    ef03:      	movl	$0x4, %eax
    ef08:      	leaq	0x8(%rsp), %rdi
    ef0d:      	movl	$0x8, %esi
    ef12:      	movq	%rbx, %rdx
    ef15:      	callq	*%rax
    ef17:      	addq	$0x20, %r12
    ef1b:      	movl	$0x4, %eax
    ef20:      	leaq	0x58(%rsp), %rdi
    ef25:      	movl	$0x10, %ecx
    ef2a:      	movl	$0x10, %esi
    ef2f:      	movq	%r12, %rdx
    ef32:      	callq	*%rax
    ef34:      	movq	0x28(%rsp), %rbx
    ef39:      	movq	0x48(%rsp), %rax
    ef3e:      	movl	0x5c(%rsp), %r15d
    ef43:      	subq	%rbx, %rax
    ef46:      	movl	0x50(%rsp), %r12d
    ef4b:      	movl	%r15d, %edx
    ef4e:      	subl	%r12d, %edx
    ef51:      	movl	$0x0, %ecx
    ef56:      	cmovbl	%ecx, %edx
    ef59:      	addq	0x60(%rsp), %rdx
    ef5e:      	xorl	%esi, %esi
    ef60:      	cmpl	%r15d, %r12d
    ef63:      	seta	%sil
    ef67:      	movl	%r15d, %ecx
    ef6a:      	cmovbl	%r12d, %ecx
    ef6e:      	addl	%ecx, %esi
    ef70:      	movl	%r12d, %edi
    ef73:      	subl	%esi, %edi
    ef75:      	movl	%edi, 0x50(%rsp)
    ef79:      	subq	%rsi, %rax
    ef7c:      	jb	0x16372 <generic_usdt_path+0xba72>
    ef82:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ef88:      	ja	0x16372 <generic_usdt_path+0xba72>
    ef8e:      	cmpl	%r15d, %r12d
    ef91:      	jbe	0xef97 <generic_usdt_path+0x4697>
    ef93:      	movb	$0x2f, (%rbx,%rax)
    ef97:      	xorl	%edi, %edi
    ef99:      	cmpl	%r15d, %r12d
    ef9c:      	seta	%dil
    efa0:      	movzbl	%cl, %esi
    efa3:      	addq	%rax, %rbx
    efa6:      	addq	%rbx, %rdi
    efa9:      	movl	$0x4, %eax
    efae:      	callq	*%rax
    efb0:      	movq	%rbx, 0x48(%rsp)
    efb5:      	cmpl	%r15d, %r12d
    efb8:      	jbe	0x16372 <generic_usdt_path+0xba72>
    efbe:      	movq	0x8(%rsp), %r12
    efc3:      	movq	%r12, 0x30(%rsp)
    efc8:      	movq	0x38(%rsp), %rdx
    efcd:      	movq	0x40(%rsp), %r15
    efd2:      	jmp	0xf025 <generic_usdt_path+0x4725>
    efd4:      	leaq	0x10(%r15), %rdx
    efd8:      	movl	$0x4, %eax
    efdd:      	movq	%rbp, %rdi
    efe0:      	movl	$0x8, %esi
    efe5:      	callq	*%rax
    efe7:      	movq	0x40(%rsp), %rax
    efec:      	cmpq	(%rsp), %rax
    eff0:      	je	0x1636d <generic_usdt_path+0xba6d>
    eff6:      	addq	$0x18, %r15
    effa:      	movl	$0x4, %eax
    efff:      	leaq	0x30(%rsp), %rdi
    f004:      	movl	$0x8, %esi
    f009:      	movq	%r15, %rdx
    f00c:      	callq	*%rax
    f00e:      	movq	(%rsp), %r15
    f012:      	movq	%r15, 0x40(%rsp)
    f017:      	leaq	0x20(%r15), %rdx
    f01b:      	movq	%rdx, 0x38(%rsp)
    f020:      	movq	0x30(%rsp), %r12
    f025:      	cmpq	0x18(%rsp), %r12
    f02a:      	jne	0xf037 <generic_usdt_path+0x4737>
    f02c:      	cmpq	0x20(%rsp), %rdx
    f031:      	je	0x1636d <generic_usdt_path+0xba6d>
    f037:      	movl	$0x4, %eax
    f03c:      	leaq	0x10(%rsp), %rdi
    f041:      	movl	$0x8, %esi
    f046:      	callq	*%rax
    f048:      	cmpq	0x10(%rsp), %r12
    f04d:      	je	0xf145 <generic_usdt_path+0x4845>
    f053:      	leaq	0x18(%r12), %rbx
    f058:      	movl	$0x4, %eax
    f05d:      	movq	%rbp, %rdi
    f060:      	movl	$0x8, %esi
    f065:      	movq	%rbx, %rdx
    f068:      	callq	*%rax
    f06a:      	cmpq	%r12, (%rsp)
    f06e:      	je	0xf145 <generic_usdt_path+0x4845>
    f074:      	movl	$0x4, %eax
    f079:      	leaq	0x8(%rsp), %rdi
    f07e:      	movl	$0x8, %esi
    f083:      	movq	%rbx, %rdx
    f086:      	callq	*%rax
    f088:      	addq	$0x20, %r12
    f08c:      	movl	$0x4, %eax
    f091:      	leaq	0x58(%rsp), %rdi
    f096:      	movl	$0x10, %ecx
    f09b:      	movl	$0x10, %esi
    f0a0:      	movq	%r12, %rdx
    f0a3:      	callq	*%rax
    f0a5:      	movq	0x28(%rsp), %rbx
    f0aa:      	movq	0x48(%rsp), %rax
    f0af:      	movl	0x5c(%rsp), %r15d
    f0b4:      	subq	%rbx, %rax
    f0b7:      	movl	0x50(%rsp), %r12d
    f0bc:      	movl	%r15d, %edx
    f0bf:      	subl	%r12d, %edx
    f0c2:      	movl	$0x0, %ecx
    f0c7:      	cmovbl	%ecx, %edx
    f0ca:      	addq	0x60(%rsp), %rdx
    f0cf:      	xorl	%esi, %esi
    f0d1:      	cmpl	%r15d, %r12d
    f0d4:      	seta	%sil
    f0d8:      	movl	%r15d, %ecx
    f0db:      	cmovbl	%r12d, %ecx
    f0df:      	addl	%ecx, %esi
    f0e1:      	movl	%r12d, %edi
    f0e4:      	subl	%esi, %edi
    f0e6:      	movl	%edi, 0x50(%rsp)
    f0ea:      	subq	%rsi, %rax
    f0ed:      	jb	0x16372 <generic_usdt_path+0xba72>
    f0f3:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f0f9:      	ja	0x16372 <generic_usdt_path+0xba72>
    f0ff:      	cmpl	%r15d, %r12d
    f102:      	jbe	0xf108 <generic_usdt_path+0x4808>
    f104:      	movb	$0x2f, (%rbx,%rax)
    f108:      	xorl	%edi, %edi
    f10a:      	cmpl	%r15d, %r12d
    f10d:      	seta	%dil
    f111:      	movzbl	%cl, %esi
    f114:      	addq	%rax, %rbx
    f117:      	addq	%rbx, %rdi
    f11a:      	movl	$0x4, %eax
    f11f:      	callq	*%rax
    f121:      	movq	%rbx, 0x48(%rsp)
    f126:      	cmpl	%r15d, %r12d
    f129:      	jbe	0x16372 <generic_usdt_path+0xba72>
    f12f:      	movq	0x8(%rsp), %r12
    f134:      	movq	%r12, 0x30(%rsp)
    f139:      	movq	0x38(%rsp), %rdx
    f13e:      	movq	0x40(%rsp), %r15
    f143:      	jmp	0xf196 <generic_usdt_path+0x4896>
    f145:      	leaq	0x10(%r15), %rdx
    f149:      	movl	$0x4, %eax
    f14e:      	movq	%rbp, %rdi
    f151:      	movl	$0x8, %esi
    f156:      	callq	*%rax
    f158:      	movq	0x40(%rsp), %rax
    f15d:      	cmpq	(%rsp), %rax
    f161:      	je	0x1636d <generic_usdt_path+0xba6d>
    f167:      	addq	$0x18, %r15
    f16b:      	movl	$0x4, %eax
    f170:      	leaq	0x30(%rsp), %rdi
    f175:      	movl	$0x8, %esi
    f17a:      	movq	%r15, %rdx
    f17d:      	callq	*%rax
    f17f:      	movq	(%rsp), %r15
    f183:      	movq	%r15, 0x40(%rsp)
    f188:      	leaq	0x20(%r15), %rdx
    f18c:      	movq	%rdx, 0x38(%rsp)
    f191:      	movq	0x30(%rsp), %r12
    f196:      	cmpq	0x18(%rsp), %r12
    f19b:      	jne	0xf1a8 <generic_usdt_path+0x48a8>
    f19d:      	cmpq	0x20(%rsp), %rdx
    f1a2:      	je	0x1636d <generic_usdt_path+0xba6d>
    f1a8:      	movl	$0x4, %eax
    f1ad:      	leaq	0x10(%rsp), %rdi
    f1b2:      	movl	$0x8, %esi
    f1b7:      	callq	*%rax
    f1b9:      	cmpq	0x10(%rsp), %r12
    f1be:      	je	0xf2b6 <generic_usdt_path+0x49b6>
    f1c4:      	leaq	0x18(%r12), %rbx
    f1c9:      	movl	$0x4, %eax
    f1ce:      	movq	%rbp, %rdi
    f1d1:      	movl	$0x8, %esi
    f1d6:      	movq	%rbx, %rdx
    f1d9:      	callq	*%rax
    f1db:      	cmpq	%r12, (%rsp)
    f1df:      	je	0xf2b6 <generic_usdt_path+0x49b6>
    f1e5:      	movl	$0x4, %eax
    f1ea:      	leaq	0x8(%rsp), %rdi
    f1ef:      	movl	$0x8, %esi
    f1f4:      	movq	%rbx, %rdx
    f1f7:      	callq	*%rax
    f1f9:      	addq	$0x20, %r12
    f1fd:      	movl	$0x4, %eax
    f202:      	leaq	0x58(%rsp), %rdi
    f207:      	movl	$0x10, %ecx
    f20c:      	movl	$0x10, %esi
    f211:      	movq	%r12, %rdx
    f214:      	callq	*%rax
    f216:      	movq	0x28(%rsp), %rbx
    f21b:      	movq	0x48(%rsp), %rax
    f220:      	movl	0x5c(%rsp), %r15d
    f225:      	subq	%rbx, %rax
    f228:      	movl	0x50(%rsp), %r12d
    f22d:      	movl	%r15d, %edx
    f230:      	subl	%r12d, %edx
    f233:      	movl	$0x0, %ecx
    f238:      	cmovbl	%ecx, %edx
    f23b:      	addq	0x60(%rsp), %rdx
    f240:      	xorl	%esi, %esi
    f242:      	cmpl	%r15d, %r12d
    f245:      	seta	%sil
    f249:      	movl	%r15d, %ecx
    f24c:      	cmovbl	%r12d, %ecx
    f250:      	addl	%ecx, %esi
    f252:      	movl	%r12d, %edi
    f255:      	subl	%esi, %edi
    f257:      	movl	%edi, 0x50(%rsp)
    f25b:      	subq	%rsi, %rax
    f25e:      	jb	0x16372 <generic_usdt_path+0xba72>
    f264:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f26a:      	ja	0x16372 <generic_usdt_path+0xba72>
    f270:      	cmpl	%r15d, %r12d
    f273:      	jbe	0xf279 <generic_usdt_path+0x4979>
    f275:      	movb	$0x2f, (%rbx,%rax)
    f279:      	xorl	%edi, %edi
    f27b:      	cmpl	%r15d, %r12d
    f27e:      	seta	%dil
    f282:      	movzbl	%cl, %esi
    f285:      	addq	%rax, %rbx
    f288:      	addq	%rbx, %rdi
    f28b:      	movl	$0x4, %eax
    f290:      	callq	*%rax
    f292:      	movq	%rbx, 0x48(%rsp)
    f297:      	cmpl	%r15d, %r12d
    f29a:      	jbe	0x16372 <generic_usdt_path+0xba72>
    f2a0:      	movq	0x8(%rsp), %r12
    f2a5:      	movq	%r12, 0x30(%rsp)
    f2aa:      	movq	0x38(%rsp), %rdx
    f2af:      	movq	0x40(%rsp), %r15
    f2b4:      	jmp	0xf307 <generic_usdt_path+0x4a07>
    f2b6:      	leaq	0x10(%r15), %rdx
    f2ba:      	movl	$0x4, %eax
    f2bf:      	movq	%rbp, %rdi
    f2c2:      	movl	$0x8, %esi
    f2c7:      	callq	*%rax
    f2c9:      	movq	0x40(%rsp), %rax
    f2ce:      	cmpq	(%rsp), %rax
    f2d2:      	je	0x1636d <generic_usdt_path+0xba6d>
    f2d8:      	addq	$0x18, %r15
    f2dc:      	movl	$0x4, %eax
    f2e1:      	leaq	0x30(%rsp), %rdi
    f2e6:      	movl	$0x8, %esi
    f2eb:      	movq	%r15, %rdx
    f2ee:      	callq	*%rax
    f2f0:      	movq	(%rsp), %r15
    f2f4:      	movq	%r15, 0x40(%rsp)
    f2f9:      	leaq	0x20(%r15), %rdx
    f2fd:      	movq	%rdx, 0x38(%rsp)
    f302:      	movq	0x30(%rsp), %r12
    f307:      	cmpq	0x18(%rsp), %r12
    f30c:      	jne	0xf319 <generic_usdt_path+0x4a19>
    f30e:      	cmpq	0x20(%rsp), %rdx
    f313:      	je	0x1636d <generic_usdt_path+0xba6d>
    f319:      	movl	$0x4, %eax
    f31e:      	leaq	0x10(%rsp), %rdi
    f323:      	movl	$0x8, %esi
    f328:      	callq	*%rax
    f32a:      	cmpq	0x10(%rsp), %r12
    f32f:      	je	0xf427 <generic_usdt_path+0x4b27>
    f335:      	leaq	0x18(%r12), %rbx
    f33a:      	movl	$0x4, %eax
    f33f:      	movq	%rbp, %rdi
    f342:      	movl	$0x8, %esi
    f347:      	movq	%rbx, %rdx
    f34a:      	callq	*%rax
    f34c:      	cmpq	%r12, (%rsp)
    f350:      	je	0xf427 <generic_usdt_path+0x4b27>
    f356:      	movl	$0x4, %eax
    f35b:      	leaq	0x8(%rsp), %rdi
    f360:      	movl	$0x8, %esi
    f365:      	movq	%rbx, %rdx
    f368:      	callq	*%rax
    f36a:      	addq	$0x20, %r12
    f36e:      	movl	$0x4, %eax
    f373:      	leaq	0x58(%rsp), %rdi
    f378:      	movl	$0x10, %ecx
    f37d:      	movl	$0x10, %esi
    f382:      	movq	%r12, %rdx
    f385:      	callq	*%rax
    f387:      	movq	0x28(%rsp), %rbx
    f38c:      	movq	0x48(%rsp), %rax
    f391:      	movl	0x5c(%rsp), %r15d
    f396:      	subq	%rbx, %rax
    f399:      	movl	0x50(%rsp), %r12d
    f39e:      	movl	%r15d, %edx
    f3a1:      	subl	%r12d, %edx
    f3a4:      	movl	$0x0, %ecx
    f3a9:      	cmovbl	%ecx, %edx
    f3ac:      	addq	0x60(%rsp), %rdx
    f3b1:      	xorl	%esi, %esi
    f3b3:      	cmpl	%r15d, %r12d
    f3b6:      	seta	%sil
    f3ba:      	movl	%r15d, %ecx
    f3bd:      	cmovbl	%r12d, %ecx
    f3c1:      	addl	%ecx, %esi
    f3c3:      	movl	%r12d, %edi
    f3c6:      	subl	%esi, %edi
    f3c8:      	movl	%edi, 0x50(%rsp)
    f3cc:      	subq	%rsi, %rax
    f3cf:      	jb	0x16372 <generic_usdt_path+0xba72>
    f3d5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f3db:      	ja	0x16372 <generic_usdt_path+0xba72>
    f3e1:      	cmpl	%r15d, %r12d
    f3e4:      	jbe	0xf3ea <generic_usdt_path+0x4aea>
    f3e6:      	movb	$0x2f, (%rbx,%rax)
    f3ea:      	xorl	%edi, %edi
    f3ec:      	cmpl	%r15d, %r12d
    f3ef:      	seta	%dil
    f3f3:      	movzbl	%cl, %esi
    f3f6:      	addq	%rax, %rbx
    f3f9:      	addq	%rbx, %rdi
    f3fc:      	movl	$0x4, %eax
    f401:      	callq	*%rax
    f403:      	movq	%rbx, 0x48(%rsp)
    f408:      	cmpl	%r15d, %r12d
    f40b:      	jbe	0x16372 <generic_usdt_path+0xba72>
    f411:      	movq	0x8(%rsp), %r12
    f416:      	movq	%r12, 0x30(%rsp)
    f41b:      	movq	0x38(%rsp), %rdx
    f420:      	movq	0x40(%rsp), %r15
    f425:      	jmp	0xf478 <generic_usdt_path+0x4b78>
    f427:      	leaq	0x10(%r15), %rdx
    f42b:      	movl	$0x4, %eax
    f430:      	movq	%rbp, %rdi
    f433:      	movl	$0x8, %esi
    f438:      	callq	*%rax
    f43a:      	movq	0x40(%rsp), %rax
    f43f:      	cmpq	(%rsp), %rax
    f443:      	je	0x1636d <generic_usdt_path+0xba6d>
    f449:      	addq	$0x18, %r15
    f44d:      	movl	$0x4, %eax
    f452:      	leaq	0x30(%rsp), %rdi
    f457:      	movl	$0x8, %esi
    f45c:      	movq	%r15, %rdx
    f45f:      	callq	*%rax
    f461:      	movq	(%rsp), %r15
    f465:      	movq	%r15, 0x40(%rsp)
    f46a:      	leaq	0x20(%r15), %rdx
    f46e:      	movq	%rdx, 0x38(%rsp)
    f473:      	movq	0x30(%rsp), %r12
    f478:      	cmpq	0x18(%rsp), %r12
    f47d:      	jne	0xf48a <generic_usdt_path+0x4b8a>
    f47f:      	cmpq	0x20(%rsp), %rdx
    f484:      	je	0x1636d <generic_usdt_path+0xba6d>
    f48a:      	movl	$0x4, %eax
    f48f:      	leaq	0x10(%rsp), %rdi
    f494:      	movl	$0x8, %esi
    f499:      	callq	*%rax
    f49b:      	cmpq	0x10(%rsp), %r12
    f4a0:      	je	0xf598 <generic_usdt_path+0x4c98>
    f4a6:      	leaq	0x18(%r12), %rbx
    f4ab:      	movl	$0x4, %eax
    f4b0:      	movq	%rbp, %rdi
    f4b3:      	movl	$0x8, %esi
    f4b8:      	movq	%rbx, %rdx
    f4bb:      	callq	*%rax
    f4bd:      	cmpq	%r12, (%rsp)
    f4c1:      	je	0xf598 <generic_usdt_path+0x4c98>
    f4c7:      	movl	$0x4, %eax
    f4cc:      	leaq	0x8(%rsp), %rdi
    f4d1:      	movl	$0x8, %esi
    f4d6:      	movq	%rbx, %rdx
    f4d9:      	callq	*%rax
    f4db:      	addq	$0x20, %r12
    f4df:      	movl	$0x4, %eax
    f4e4:      	leaq	0x58(%rsp), %rdi
    f4e9:      	movl	$0x10, %ecx
    f4ee:      	movl	$0x10, %esi
    f4f3:      	movq	%r12, %rdx
    f4f6:      	callq	*%rax
    f4f8:      	movq	0x28(%rsp), %rbx
    f4fd:      	movq	0x48(%rsp), %rax
    f502:      	movl	0x5c(%rsp), %r15d
    f507:      	subq	%rbx, %rax
    f50a:      	movl	0x50(%rsp), %r12d
    f50f:      	movl	%r15d, %edx
    f512:      	subl	%r12d, %edx
    f515:      	movl	$0x0, %ecx
    f51a:      	cmovbl	%ecx, %edx
    f51d:      	addq	0x60(%rsp), %rdx
    f522:      	xorl	%esi, %esi
    f524:      	cmpl	%r15d, %r12d
    f527:      	seta	%sil
    f52b:      	movl	%r15d, %ecx
    f52e:      	cmovbl	%r12d, %ecx
    f532:      	addl	%ecx, %esi
    f534:      	movl	%r12d, %edi
    f537:      	subl	%esi, %edi
    f539:      	movl	%edi, 0x50(%rsp)
    f53d:      	subq	%rsi, %rax
    f540:      	jb	0x16372 <generic_usdt_path+0xba72>
    f546:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f54c:      	ja	0x16372 <generic_usdt_path+0xba72>
    f552:      	cmpl	%r15d, %r12d
    f555:      	jbe	0xf55b <generic_usdt_path+0x4c5b>
    f557:      	movb	$0x2f, (%rbx,%rax)
    f55b:      	xorl	%edi, %edi
    f55d:      	cmpl	%r15d, %r12d
    f560:      	seta	%dil
    f564:      	movzbl	%cl, %esi
    f567:      	addq	%rax, %rbx
    f56a:      	addq	%rbx, %rdi
    f56d:      	movl	$0x4, %eax
    f572:      	callq	*%rax
    f574:      	movq	%rbx, 0x48(%rsp)
    f579:      	cmpl	%r15d, %r12d
    f57c:      	jbe	0x16372 <generic_usdt_path+0xba72>
    f582:      	movq	0x8(%rsp), %r12
    f587:      	movq	%r12, 0x30(%rsp)
    f58c:      	movq	0x38(%rsp), %rdx
    f591:      	movq	0x40(%rsp), %r15
    f596:      	jmp	0xf5e9 <generic_usdt_path+0x4ce9>
    f598:      	leaq	0x10(%r15), %rdx
    f59c:      	movl	$0x4, %eax
    f5a1:      	movq	%rbp, %rdi
    f5a4:      	movl	$0x8, %esi
    f5a9:      	callq	*%rax
    f5ab:      	movq	0x40(%rsp), %rax
    f5b0:      	cmpq	(%rsp), %rax
    f5b4:      	je	0x1636d <generic_usdt_path+0xba6d>
    f5ba:      	addq	$0x18, %r15
    f5be:      	movl	$0x4, %eax
    f5c3:      	leaq	0x30(%rsp), %rdi
    f5c8:      	movl	$0x8, %esi
    f5cd:      	movq	%r15, %rdx
    f5d0:      	callq	*%rax
    f5d2:      	movq	(%rsp), %r15
    f5d6:      	movq	%r15, 0x40(%rsp)
    f5db:      	leaq	0x20(%r15), %rdx
    f5df:      	movq	%rdx, 0x38(%rsp)
    f5e4:      	movq	0x30(%rsp), %r12
    f5e9:      	cmpq	0x18(%rsp), %r12
    f5ee:      	jne	0xf5fb <generic_usdt_path+0x4cfb>
    f5f0:      	cmpq	0x20(%rsp), %rdx
    f5f5:      	je	0x1636d <generic_usdt_path+0xba6d>
    f5fb:      	movl	$0x4, %eax
    f600:      	leaq	0x10(%rsp), %rdi
    f605:      	movl	$0x8, %esi
    f60a:      	callq	*%rax
    f60c:      	cmpq	0x10(%rsp), %r12
    f611:      	je	0xf709 <generic_usdt_path+0x4e09>
    f617:      	leaq	0x18(%r12), %rbx
    f61c:      	movl	$0x4, %eax
    f621:      	movq	%rbp, %rdi
    f624:      	movl	$0x8, %esi
    f629:      	movq	%rbx, %rdx
    f62c:      	callq	*%rax
    f62e:      	cmpq	%r12, (%rsp)
    f632:      	je	0xf709 <generic_usdt_path+0x4e09>
    f638:      	movl	$0x4, %eax
    f63d:      	leaq	0x8(%rsp), %rdi
    f642:      	movl	$0x8, %esi
    f647:      	movq	%rbx, %rdx
    f64a:      	callq	*%rax
    f64c:      	addq	$0x20, %r12
    f650:      	movl	$0x4, %eax
    f655:      	leaq	0x58(%rsp), %rdi
    f65a:      	movl	$0x10, %ecx
    f65f:      	movl	$0x10, %esi
    f664:      	movq	%r12, %rdx
    f667:      	callq	*%rax
    f669:      	movq	0x28(%rsp), %rbx
    f66e:      	movq	0x48(%rsp), %rax
    f673:      	movl	0x5c(%rsp), %r15d
    f678:      	subq	%rbx, %rax
    f67b:      	movl	0x50(%rsp), %r12d
    f680:      	movl	%r15d, %edx
    f683:      	subl	%r12d, %edx
    f686:      	movl	$0x0, %ecx
    f68b:      	cmovbl	%ecx, %edx
    f68e:      	addq	0x60(%rsp), %rdx
    f693:      	xorl	%esi, %esi
    f695:      	cmpl	%r15d, %r12d
    f698:      	seta	%sil
    f69c:      	movl	%r15d, %ecx
    f69f:      	cmovbl	%r12d, %ecx
    f6a3:      	addl	%ecx, %esi
    f6a5:      	movl	%r12d, %edi
    f6a8:      	subl	%esi, %edi
    f6aa:      	movl	%edi, 0x50(%rsp)
    f6ae:      	subq	%rsi, %rax
    f6b1:      	jb	0x16372 <generic_usdt_path+0xba72>
    f6b7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f6bd:      	ja	0x16372 <generic_usdt_path+0xba72>
    f6c3:      	cmpl	%r15d, %r12d
    f6c6:      	jbe	0xf6cc <generic_usdt_path+0x4dcc>
    f6c8:      	movb	$0x2f, (%rbx,%rax)
    f6cc:      	xorl	%edi, %edi
    f6ce:      	cmpl	%r15d, %r12d
    f6d1:      	seta	%dil
    f6d5:      	movzbl	%cl, %esi
    f6d8:      	addq	%rax, %rbx
    f6db:      	addq	%rbx, %rdi
    f6de:      	movl	$0x4, %eax
    f6e3:      	callq	*%rax
    f6e5:      	movq	%rbx, 0x48(%rsp)
    f6ea:      	cmpl	%r15d, %r12d
    f6ed:      	jbe	0x16372 <generic_usdt_path+0xba72>
    f6f3:      	movq	0x8(%rsp), %r12
    f6f8:      	movq	%r12, 0x30(%rsp)
    f6fd:      	movq	0x38(%rsp), %rdx
    f702:      	movq	0x40(%rsp), %r15
    f707:      	jmp	0xf75a <generic_usdt_path+0x4e5a>
    f709:      	leaq	0x10(%r15), %rdx
    f70d:      	movl	$0x4, %eax
    f712:      	movq	%rbp, %rdi
    f715:      	movl	$0x8, %esi
    f71a:      	callq	*%rax
    f71c:      	movq	0x40(%rsp), %rax
    f721:      	cmpq	(%rsp), %rax
    f725:      	je	0x1636d <generic_usdt_path+0xba6d>
    f72b:      	addq	$0x18, %r15
    f72f:      	movl	$0x4, %eax
    f734:      	leaq	0x30(%rsp), %rdi
    f739:      	movl	$0x8, %esi
    f73e:      	movq	%r15, %rdx
    f741:      	callq	*%rax
    f743:      	movq	(%rsp), %r15
    f747:      	movq	%r15, 0x40(%rsp)
    f74c:      	leaq	0x20(%r15), %rdx
    f750:      	movq	%rdx, 0x38(%rsp)
    f755:      	movq	0x30(%rsp), %r12
    f75a:      	cmpq	0x18(%rsp), %r12
    f75f:      	jne	0xf76c <generic_usdt_path+0x4e6c>
    f761:      	cmpq	0x20(%rsp), %rdx
    f766:      	je	0x1636d <generic_usdt_path+0xba6d>
    f76c:      	movl	$0x4, %eax
    f771:      	leaq	0x10(%rsp), %rdi
    f776:      	movl	$0x8, %esi
    f77b:      	callq	*%rax
    f77d:      	cmpq	0x10(%rsp), %r12
    f782:      	je	0xf87a <generic_usdt_path+0x4f7a>
    f788:      	leaq	0x18(%r12), %rbx
    f78d:      	movl	$0x4, %eax
    f792:      	movq	%rbp, %rdi
    f795:      	movl	$0x8, %esi
    f79a:      	movq	%rbx, %rdx
    f79d:      	callq	*%rax
    f79f:      	cmpq	%r12, (%rsp)
    f7a3:      	je	0xf87a <generic_usdt_path+0x4f7a>
    f7a9:      	movl	$0x4, %eax
    f7ae:      	leaq	0x8(%rsp), %rdi
    f7b3:      	movl	$0x8, %esi
    f7b8:      	movq	%rbx, %rdx
    f7bb:      	callq	*%rax
    f7bd:      	addq	$0x20, %r12
    f7c1:      	movl	$0x4, %eax
    f7c6:      	leaq	0x58(%rsp), %rdi
    f7cb:      	movl	$0x10, %ecx
    f7d0:      	movl	$0x10, %esi
    f7d5:      	movq	%r12, %rdx
    f7d8:      	callq	*%rax
    f7da:      	movq	0x28(%rsp), %rbx
    f7df:      	movq	0x48(%rsp), %rax
    f7e4:      	movl	0x5c(%rsp), %r15d
    f7e9:      	subq	%rbx, %rax
    f7ec:      	movl	0x50(%rsp), %r12d
    f7f1:      	movl	%r15d, %edx
    f7f4:      	subl	%r12d, %edx
    f7f7:      	movl	$0x0, %ecx
    f7fc:      	cmovbl	%ecx, %edx
    f7ff:      	addq	0x60(%rsp), %rdx
    f804:      	xorl	%esi, %esi
    f806:      	cmpl	%r15d, %r12d
    f809:      	seta	%sil
    f80d:      	movl	%r15d, %ecx
    f810:      	cmovbl	%r12d, %ecx
    f814:      	addl	%ecx, %esi
    f816:      	movl	%r12d, %edi
    f819:      	subl	%esi, %edi
    f81b:      	movl	%edi, 0x50(%rsp)
    f81f:      	subq	%rsi, %rax
    f822:      	jb	0x16372 <generic_usdt_path+0xba72>
    f828:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f82e:      	ja	0x16372 <generic_usdt_path+0xba72>
    f834:      	cmpl	%r15d, %r12d
    f837:      	jbe	0xf83d <generic_usdt_path+0x4f3d>
    f839:      	movb	$0x2f, (%rbx,%rax)
    f83d:      	xorl	%edi, %edi
    f83f:      	cmpl	%r15d, %r12d
    f842:      	seta	%dil
    f846:      	movzbl	%cl, %esi
    f849:      	addq	%rax, %rbx
    f84c:      	addq	%rbx, %rdi
    f84f:      	movl	$0x4, %eax
    f854:      	callq	*%rax
    f856:      	movq	%rbx, 0x48(%rsp)
    f85b:      	cmpl	%r15d, %r12d
    f85e:      	jbe	0x16372 <generic_usdt_path+0xba72>
    f864:      	movq	0x8(%rsp), %r12
    f869:      	movq	%r12, 0x30(%rsp)
    f86e:      	movq	0x38(%rsp), %rdx
    f873:      	movq	0x40(%rsp), %r15
    f878:      	jmp	0xf8cb <generic_usdt_path+0x4fcb>
    f87a:      	leaq	0x10(%r15), %rdx
    f87e:      	movl	$0x4, %eax
    f883:      	movq	%rbp, %rdi
    f886:      	movl	$0x8, %esi
    f88b:      	callq	*%rax
    f88d:      	movq	0x40(%rsp), %rax
    f892:      	cmpq	(%rsp), %rax
    f896:      	je	0x1636d <generic_usdt_path+0xba6d>
    f89c:      	addq	$0x18, %r15
    f8a0:      	movl	$0x4, %eax
    f8a5:      	leaq	0x30(%rsp), %rdi
    f8aa:      	movl	$0x8, %esi
    f8af:      	movq	%r15, %rdx
    f8b2:      	callq	*%rax
    f8b4:      	movq	(%rsp), %r15
    f8b8:      	movq	%r15, 0x40(%rsp)
    f8bd:      	leaq	0x20(%r15), %rdx
    f8c1:      	movq	%rdx, 0x38(%rsp)
    f8c6:      	movq	0x30(%rsp), %r12
    f8cb:      	cmpq	0x18(%rsp), %r12
    f8d0:      	jne	0xf8dd <generic_usdt_path+0x4fdd>
    f8d2:      	cmpq	0x20(%rsp), %rdx
    f8d7:      	je	0x1636d <generic_usdt_path+0xba6d>
    f8dd:      	movl	$0x4, %eax
    f8e2:      	leaq	0x10(%rsp), %rdi
    f8e7:      	movl	$0x8, %esi
    f8ec:      	callq	*%rax
    f8ee:      	cmpq	0x10(%rsp), %r12
    f8f3:      	je	0xf9eb <generic_usdt_path+0x50eb>
    f8f9:      	leaq	0x18(%r12), %rbx
    f8fe:      	movl	$0x4, %eax
    f903:      	movq	%rbp, %rdi
    f906:      	movl	$0x8, %esi
    f90b:      	movq	%rbx, %rdx
    f90e:      	callq	*%rax
    f910:      	cmpq	%r12, (%rsp)
    f914:      	je	0xf9eb <generic_usdt_path+0x50eb>
    f91a:      	movl	$0x4, %eax
    f91f:      	leaq	0x8(%rsp), %rdi
    f924:      	movl	$0x8, %esi
    f929:      	movq	%rbx, %rdx
    f92c:      	callq	*%rax
    f92e:      	addq	$0x20, %r12
    f932:      	movl	$0x4, %eax
    f937:      	leaq	0x58(%rsp), %rdi
    f93c:      	movl	$0x10, %ecx
    f941:      	movl	$0x10, %esi
    f946:      	movq	%r12, %rdx
    f949:      	callq	*%rax
    f94b:      	movq	0x28(%rsp), %rbx
    f950:      	movq	0x48(%rsp), %rax
    f955:      	movl	0x5c(%rsp), %r15d
    f95a:      	subq	%rbx, %rax
    f95d:      	movl	0x50(%rsp), %r12d
    f962:      	movl	%r15d, %edx
    f965:      	subl	%r12d, %edx
    f968:      	movl	$0x0, %ecx
    f96d:      	cmovbl	%ecx, %edx
    f970:      	addq	0x60(%rsp), %rdx
    f975:      	xorl	%esi, %esi
    f977:      	cmpl	%r15d, %r12d
    f97a:      	seta	%sil
    f97e:      	movl	%r15d, %ecx
    f981:      	cmovbl	%r12d, %ecx
    f985:      	addl	%ecx, %esi
    f987:      	movl	%r12d, %edi
    f98a:      	subl	%esi, %edi
    f98c:      	movl	%edi, 0x50(%rsp)
    f990:      	subq	%rsi, %rax
    f993:      	jb	0x16372 <generic_usdt_path+0xba72>
    f999:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    f99f:      	ja	0x16372 <generic_usdt_path+0xba72>
    f9a5:      	cmpl	%r15d, %r12d
    f9a8:      	jbe	0xf9ae <generic_usdt_path+0x50ae>
    f9aa:      	movb	$0x2f, (%rbx,%rax)
    f9ae:      	xorl	%edi, %edi
    f9b0:      	cmpl	%r15d, %r12d
    f9b3:      	seta	%dil
    f9b7:      	movzbl	%cl, %esi
    f9ba:      	addq	%rax, %rbx
    f9bd:      	addq	%rbx, %rdi
    f9c0:      	movl	$0x4, %eax
    f9c5:      	callq	*%rax
    f9c7:      	movq	%rbx, 0x48(%rsp)
    f9cc:      	cmpl	%r15d, %r12d
    f9cf:      	jbe	0x16372 <generic_usdt_path+0xba72>
    f9d5:      	movq	0x8(%rsp), %r12
    f9da:      	movq	%r12, 0x30(%rsp)
    f9df:      	movq	0x38(%rsp), %rdx
    f9e4:      	movq	0x40(%rsp), %r15
    f9e9:      	jmp	0xfa3c <generic_usdt_path+0x513c>
    f9eb:      	leaq	0x10(%r15), %rdx
    f9ef:      	movl	$0x4, %eax
    f9f4:      	movq	%rbp, %rdi
    f9f7:      	movl	$0x8, %esi
    f9fc:      	callq	*%rax
    f9fe:      	movq	0x40(%rsp), %rax
    fa03:      	cmpq	(%rsp), %rax
    fa07:      	je	0x1636d <generic_usdt_path+0xba6d>
    fa0d:      	addq	$0x18, %r15
    fa11:      	movl	$0x4, %eax
    fa16:      	leaq	0x30(%rsp), %rdi
    fa1b:      	movl	$0x8, %esi
    fa20:      	movq	%r15, %rdx
    fa23:      	callq	*%rax
    fa25:      	movq	(%rsp), %r15
    fa29:      	movq	%r15, 0x40(%rsp)
    fa2e:      	leaq	0x20(%r15), %rdx
    fa32:      	movq	%rdx, 0x38(%rsp)
    fa37:      	movq	0x30(%rsp), %r12
    fa3c:      	cmpq	0x18(%rsp), %r12
    fa41:      	jne	0xfa4e <generic_usdt_path+0x514e>
    fa43:      	cmpq	0x20(%rsp), %rdx
    fa48:      	je	0x1636d <generic_usdt_path+0xba6d>
    fa4e:      	movl	$0x4, %eax
    fa53:      	leaq	0x10(%rsp), %rdi
    fa58:      	movl	$0x8, %esi
    fa5d:      	callq	*%rax
    fa5f:      	cmpq	0x10(%rsp), %r12
    fa64:      	je	0xfb5c <generic_usdt_path+0x525c>
    fa6a:      	leaq	0x18(%r12), %rbx
    fa6f:      	movl	$0x4, %eax
    fa74:      	movq	%rbp, %rdi
    fa77:      	movl	$0x8, %esi
    fa7c:      	movq	%rbx, %rdx
    fa7f:      	callq	*%rax
    fa81:      	cmpq	%r12, (%rsp)
    fa85:      	je	0xfb5c <generic_usdt_path+0x525c>
    fa8b:      	movl	$0x4, %eax
    fa90:      	leaq	0x8(%rsp), %rdi
    fa95:      	movl	$0x8, %esi
    fa9a:      	movq	%rbx, %rdx
    fa9d:      	callq	*%rax
    fa9f:      	addq	$0x20, %r12
    faa3:      	movl	$0x4, %eax
    faa8:      	leaq	0x58(%rsp), %rdi
    faad:      	movl	$0x10, %ecx
    fab2:      	movl	$0x10, %esi
    fab7:      	movq	%r12, %rdx
    faba:      	callq	*%rax
    fabc:      	movq	0x28(%rsp), %rbx
    fac1:      	movq	0x48(%rsp), %rax
    fac6:      	movl	0x5c(%rsp), %r15d
    facb:      	subq	%rbx, %rax
    face:      	movl	0x50(%rsp), %r12d
    fad3:      	movl	%r15d, %edx
    fad6:      	subl	%r12d, %edx
    fad9:      	movl	$0x0, %ecx
    fade:      	cmovbl	%ecx, %edx
    fae1:      	addq	0x60(%rsp), %rdx
    fae6:      	xorl	%esi, %esi
    fae8:      	cmpl	%r15d, %r12d
    faeb:      	seta	%sil
    faef:      	movl	%r15d, %ecx
    faf2:      	cmovbl	%r12d, %ecx
    faf6:      	addl	%ecx, %esi
    faf8:      	movl	%r12d, %edi
    fafb:      	subl	%esi, %edi
    fafd:      	movl	%edi, 0x50(%rsp)
    fb01:      	subq	%rsi, %rax
    fb04:      	jb	0x16372 <generic_usdt_path+0xba72>
    fb0a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    fb10:      	ja	0x16372 <generic_usdt_path+0xba72>
    fb16:      	cmpl	%r15d, %r12d
    fb19:      	jbe	0xfb1f <generic_usdt_path+0x521f>
    fb1b:      	movb	$0x2f, (%rbx,%rax)
    fb1f:      	xorl	%edi, %edi
    fb21:      	cmpl	%r15d, %r12d
    fb24:      	seta	%dil
    fb28:      	movzbl	%cl, %esi
    fb2b:      	addq	%rax, %rbx
    fb2e:      	addq	%rbx, %rdi
    fb31:      	movl	$0x4, %eax
    fb36:      	callq	*%rax
    fb38:      	movq	%rbx, 0x48(%rsp)
    fb3d:      	cmpl	%r15d, %r12d
    fb40:      	jbe	0x16372 <generic_usdt_path+0xba72>
    fb46:      	movq	0x8(%rsp), %r12
    fb4b:      	movq	%r12, 0x30(%rsp)
    fb50:      	movq	0x38(%rsp), %rdx
    fb55:      	movq	0x40(%rsp), %r15
    fb5a:      	jmp	0xfbad <generic_usdt_path+0x52ad>
    fb5c:      	leaq	0x10(%r15), %rdx
    fb60:      	movl	$0x4, %eax
    fb65:      	movq	%rbp, %rdi
    fb68:      	movl	$0x8, %esi
    fb6d:      	callq	*%rax
    fb6f:      	movq	0x40(%rsp), %rax
    fb74:      	cmpq	(%rsp), %rax
    fb78:      	je	0x1636d <generic_usdt_path+0xba6d>
    fb7e:      	addq	$0x18, %r15
    fb82:      	movl	$0x4, %eax
    fb87:      	leaq	0x30(%rsp), %rdi
    fb8c:      	movl	$0x8, %esi
    fb91:      	movq	%r15, %rdx
    fb94:      	callq	*%rax
    fb96:      	movq	(%rsp), %r15
    fb9a:      	movq	%r15, 0x40(%rsp)
    fb9f:      	leaq	0x20(%r15), %rdx
    fba3:      	movq	%rdx, 0x38(%rsp)
    fba8:      	movq	0x30(%rsp), %r12
    fbad:      	cmpq	0x18(%rsp), %r12
    fbb2:      	jne	0xfbbf <generic_usdt_path+0x52bf>
    fbb4:      	cmpq	0x20(%rsp), %rdx
    fbb9:      	je	0x1636d <generic_usdt_path+0xba6d>
    fbbf:      	movl	$0x4, %eax
    fbc4:      	leaq	0x10(%rsp), %rdi
    fbc9:      	movl	$0x8, %esi
    fbce:      	callq	*%rax
    fbd0:      	cmpq	0x10(%rsp), %r12
    fbd5:      	je	0xfccd <generic_usdt_path+0x53cd>
    fbdb:      	leaq	0x18(%r12), %rbx
    fbe0:      	movl	$0x4, %eax
    fbe5:      	movq	%rbp, %rdi
    fbe8:      	movl	$0x8, %esi
    fbed:      	movq	%rbx, %rdx
    fbf0:      	callq	*%rax
    fbf2:      	cmpq	%r12, (%rsp)
    fbf6:      	je	0xfccd <generic_usdt_path+0x53cd>
    fbfc:      	movl	$0x4, %eax
    fc01:      	leaq	0x8(%rsp), %rdi
    fc06:      	movl	$0x8, %esi
    fc0b:      	movq	%rbx, %rdx
    fc0e:      	callq	*%rax
    fc10:      	addq	$0x20, %r12
    fc14:      	movl	$0x4, %eax
    fc19:      	leaq	0x58(%rsp), %rdi
    fc1e:      	movl	$0x10, %ecx
    fc23:      	movl	$0x10, %esi
    fc28:      	movq	%r12, %rdx
    fc2b:      	callq	*%rax
    fc2d:      	movq	0x28(%rsp), %rbx
    fc32:      	movq	0x48(%rsp), %rax
    fc37:      	movl	0x5c(%rsp), %r15d
    fc3c:      	subq	%rbx, %rax
    fc3f:      	movl	0x50(%rsp), %r12d
    fc44:      	movl	%r15d, %edx
    fc47:      	subl	%r12d, %edx
    fc4a:      	movl	$0x0, %ecx
    fc4f:      	cmovbl	%ecx, %edx
    fc52:      	addq	0x60(%rsp), %rdx
    fc57:      	xorl	%esi, %esi
    fc59:      	cmpl	%r15d, %r12d
    fc5c:      	seta	%sil
    fc60:      	movl	%r15d, %ecx
    fc63:      	cmovbl	%r12d, %ecx
    fc67:      	addl	%ecx, %esi
    fc69:      	movl	%r12d, %edi
    fc6c:      	subl	%esi, %edi
    fc6e:      	movl	%edi, 0x50(%rsp)
    fc72:      	subq	%rsi, %rax
    fc75:      	jb	0x16372 <generic_usdt_path+0xba72>
    fc7b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    fc81:      	ja	0x16372 <generic_usdt_path+0xba72>
    fc87:      	cmpl	%r15d, %r12d
    fc8a:      	jbe	0xfc90 <generic_usdt_path+0x5390>
    fc8c:      	movb	$0x2f, (%rbx,%rax)
    fc90:      	xorl	%edi, %edi
    fc92:      	cmpl	%r15d, %r12d
    fc95:      	seta	%dil
    fc99:      	movzbl	%cl, %esi
    fc9c:      	addq	%rax, %rbx
    fc9f:      	addq	%rbx, %rdi
    fca2:      	movl	$0x4, %eax
    fca7:      	callq	*%rax
    fca9:      	movq	%rbx, 0x48(%rsp)
    fcae:      	cmpl	%r15d, %r12d
    fcb1:      	jbe	0x16372 <generic_usdt_path+0xba72>
    fcb7:      	movq	0x8(%rsp), %r12
    fcbc:      	movq	%r12, 0x30(%rsp)
    fcc1:      	movq	0x38(%rsp), %rdx
    fcc6:      	movq	0x40(%rsp), %r15
    fccb:      	jmp	0xfd1e <generic_usdt_path+0x541e>
    fccd:      	leaq	0x10(%r15), %rdx
    fcd1:      	movl	$0x4, %eax
    fcd6:      	movq	%rbp, %rdi
    fcd9:      	movl	$0x8, %esi
    fcde:      	callq	*%rax
    fce0:      	movq	0x40(%rsp), %rax
    fce5:      	cmpq	(%rsp), %rax
    fce9:      	je	0x1636d <generic_usdt_path+0xba6d>
    fcef:      	addq	$0x18, %r15
    fcf3:      	movl	$0x4, %eax
    fcf8:      	leaq	0x30(%rsp), %rdi
    fcfd:      	movl	$0x8, %esi
    fd02:      	movq	%r15, %rdx
    fd05:      	callq	*%rax
    fd07:      	movq	(%rsp), %r15
    fd0b:      	movq	%r15, 0x40(%rsp)
    fd10:      	leaq	0x20(%r15), %rdx
    fd14:      	movq	%rdx, 0x38(%rsp)
    fd19:      	movq	0x30(%rsp), %r12
    fd1e:      	cmpq	0x18(%rsp), %r12
    fd23:      	jne	0xfd30 <generic_usdt_path+0x5430>
    fd25:      	cmpq	0x20(%rsp), %rdx
    fd2a:      	je	0x1636d <generic_usdt_path+0xba6d>
    fd30:      	movl	$0x4, %eax
    fd35:      	leaq	0x10(%rsp), %rdi
    fd3a:      	movl	$0x8, %esi
    fd3f:      	callq	*%rax
    fd41:      	cmpq	0x10(%rsp), %r12
    fd46:      	je	0xfe3e <generic_usdt_path+0x553e>
    fd4c:      	leaq	0x18(%r12), %rbx
    fd51:      	movl	$0x4, %eax
    fd56:      	movq	%rbp, %rdi
    fd59:      	movl	$0x8, %esi
    fd5e:      	movq	%rbx, %rdx
    fd61:      	callq	*%rax
    fd63:      	cmpq	%r12, (%rsp)
    fd67:      	je	0xfe3e <generic_usdt_path+0x553e>
    fd6d:      	movl	$0x4, %eax
    fd72:      	leaq	0x8(%rsp), %rdi
    fd77:      	movl	$0x8, %esi
    fd7c:      	movq	%rbx, %rdx
    fd7f:      	callq	*%rax
    fd81:      	addq	$0x20, %r12
    fd85:      	movl	$0x4, %eax
    fd8a:      	leaq	0x58(%rsp), %rdi
    fd8f:      	movl	$0x10, %ecx
    fd94:      	movl	$0x10, %esi
    fd99:      	movq	%r12, %rdx
    fd9c:      	callq	*%rax
    fd9e:      	movq	0x28(%rsp), %rbx
    fda3:      	movq	0x48(%rsp), %rax
    fda8:      	movl	0x5c(%rsp), %r15d
    fdad:      	subq	%rbx, %rax
    fdb0:      	movl	0x50(%rsp), %r12d
    fdb5:      	movl	%r15d, %edx
    fdb8:      	subl	%r12d, %edx
    fdbb:      	movl	$0x0, %ecx
    fdc0:      	cmovbl	%ecx, %edx
    fdc3:      	addq	0x60(%rsp), %rdx
    fdc8:      	xorl	%esi, %esi
    fdca:      	cmpl	%r15d, %r12d
    fdcd:      	seta	%sil
    fdd1:      	movl	%r15d, %ecx
    fdd4:      	cmovbl	%r12d, %ecx
    fdd8:      	addl	%ecx, %esi
    fdda:      	movl	%r12d, %edi
    fddd:      	subl	%esi, %edi
    fddf:      	movl	%edi, 0x50(%rsp)
    fde3:      	subq	%rsi, %rax
    fde6:      	jb	0x16372 <generic_usdt_path+0xba72>
    fdec:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    fdf2:      	ja	0x16372 <generic_usdt_path+0xba72>
    fdf8:      	cmpl	%r15d, %r12d
    fdfb:      	jbe	0xfe01 <generic_usdt_path+0x5501>
    fdfd:      	movb	$0x2f, (%rbx,%rax)
    fe01:      	xorl	%edi, %edi
    fe03:      	cmpl	%r15d, %r12d
    fe06:      	seta	%dil
    fe0a:      	movzbl	%cl, %esi
    fe0d:      	addq	%rax, %rbx
    fe10:      	addq	%rbx, %rdi
    fe13:      	movl	$0x4, %eax
    fe18:      	callq	*%rax
    fe1a:      	movq	%rbx, 0x48(%rsp)
    fe1f:      	cmpl	%r15d, %r12d
    fe22:      	jbe	0x16372 <generic_usdt_path+0xba72>
    fe28:      	movq	0x8(%rsp), %r12
    fe2d:      	movq	%r12, 0x30(%rsp)
    fe32:      	movq	0x38(%rsp), %rdx
    fe37:      	movq	0x40(%rsp), %r15
    fe3c:      	jmp	0xfe8f <generic_usdt_path+0x558f>
    fe3e:      	leaq	0x10(%r15), %rdx
    fe42:      	movl	$0x4, %eax
    fe47:      	movq	%rbp, %rdi
    fe4a:      	movl	$0x8, %esi
    fe4f:      	callq	*%rax
    fe51:      	movq	0x40(%rsp), %rax
    fe56:      	cmpq	(%rsp), %rax
    fe5a:      	je	0x1636d <generic_usdt_path+0xba6d>
    fe60:      	addq	$0x18, %r15
    fe64:      	movl	$0x4, %eax
    fe69:      	leaq	0x30(%rsp), %rdi
    fe6e:      	movl	$0x8, %esi
    fe73:      	movq	%r15, %rdx
    fe76:      	callq	*%rax
    fe78:      	movq	(%rsp), %r15
    fe7c:      	movq	%r15, 0x40(%rsp)
    fe81:      	leaq	0x20(%r15), %rdx
    fe85:      	movq	%rdx, 0x38(%rsp)
    fe8a:      	movq	0x30(%rsp), %r12
    fe8f:      	cmpq	0x18(%rsp), %r12
    fe94:      	jne	0xfea1 <generic_usdt_path+0x55a1>
    fe96:      	cmpq	0x20(%rsp), %rdx
    fe9b:      	je	0x1636d <generic_usdt_path+0xba6d>
    fea1:      	movl	$0x4, %eax
    fea6:      	leaq	0x10(%rsp), %rdi
    feab:      	movl	$0x8, %esi
    feb0:      	callq	*%rax
    feb2:      	cmpq	0x10(%rsp), %r12
    feb7:      	je	0xffaf <generic_usdt_path+0x56af>
    febd:      	leaq	0x18(%r12), %rbx
    fec2:      	movl	$0x4, %eax
    fec7:      	movq	%rbp, %rdi
    feca:      	movl	$0x8, %esi
    fecf:      	movq	%rbx, %rdx
    fed2:      	callq	*%rax
    fed4:      	cmpq	%r12, (%rsp)
    fed8:      	je	0xffaf <generic_usdt_path+0x56af>
    fede:      	movl	$0x4, %eax
    fee3:      	leaq	0x8(%rsp), %rdi
    fee8:      	movl	$0x8, %esi
    feed:      	movq	%rbx, %rdx
    fef0:      	callq	*%rax
    fef2:      	addq	$0x20, %r12
    fef6:      	movl	$0x4, %eax
    fefb:      	leaq	0x58(%rsp), %rdi
    ff00:      	movl	$0x10, %ecx
    ff05:      	movl	$0x10, %esi
    ff0a:      	movq	%r12, %rdx
    ff0d:      	callq	*%rax
    ff0f:      	movq	0x28(%rsp), %rbx
    ff14:      	movq	0x48(%rsp), %rax
    ff19:      	movl	0x5c(%rsp), %r15d
    ff1e:      	subq	%rbx, %rax
    ff21:      	movl	0x50(%rsp), %r12d
    ff26:      	movl	%r15d, %edx
    ff29:      	subl	%r12d, %edx
    ff2c:      	movl	$0x0, %ecx
    ff31:      	cmovbl	%ecx, %edx
    ff34:      	addq	0x60(%rsp), %rdx
    ff39:      	xorl	%esi, %esi
    ff3b:      	cmpl	%r15d, %r12d
    ff3e:      	seta	%sil
    ff42:      	movl	%r15d, %ecx
    ff45:      	cmovbl	%r12d, %ecx
    ff49:      	addl	%ecx, %esi
    ff4b:      	movl	%r12d, %edi
    ff4e:      	subl	%esi, %edi
    ff50:      	movl	%edi, 0x50(%rsp)
    ff54:      	subq	%rsi, %rax
    ff57:      	jb	0x16372 <generic_usdt_path+0xba72>
    ff5d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
    ff63:      	ja	0x16372 <generic_usdt_path+0xba72>
    ff69:      	cmpl	%r15d, %r12d
    ff6c:      	jbe	0xff72 <generic_usdt_path+0x5672>
    ff6e:      	movb	$0x2f, (%rbx,%rax)
    ff72:      	xorl	%edi, %edi
    ff74:      	cmpl	%r15d, %r12d
    ff77:      	seta	%dil
    ff7b:      	movzbl	%cl, %esi
    ff7e:      	addq	%rax, %rbx
    ff81:      	addq	%rbx, %rdi
    ff84:      	movl	$0x4, %eax
    ff89:      	callq	*%rax
    ff8b:      	movq	%rbx, 0x48(%rsp)
    ff90:      	cmpl	%r15d, %r12d
    ff93:      	jbe	0x16372 <generic_usdt_path+0xba72>
    ff99:      	movq	0x8(%rsp), %r12
    ff9e:      	movq	%r12, 0x30(%rsp)
    ffa3:      	movq	0x38(%rsp), %rdx
    ffa8:      	movq	0x40(%rsp), %r15
    ffad:      	jmp	0x10000 <generic_usdt_path+0x5700>
    ffaf:      	leaq	0x10(%r15), %rdx
    ffb3:      	movl	$0x4, %eax
    ffb8:      	movq	%rbp, %rdi
    ffbb:      	movl	$0x8, %esi
    ffc0:      	callq	*%rax
    ffc2:      	movq	0x40(%rsp), %rax
    ffc7:      	cmpq	(%rsp), %rax
    ffcb:      	je	0x1636d <generic_usdt_path+0xba6d>
    ffd1:      	addq	$0x18, %r15
    ffd5:      	movl	$0x4, %eax
    ffda:      	leaq	0x30(%rsp), %rdi
    ffdf:      	movl	$0x8, %esi
    ffe4:      	movq	%r15, %rdx
    ffe7:      	callq	*%rax
    ffe9:      	movq	(%rsp), %r15
    ffed:      	movq	%r15, 0x40(%rsp)
    fff2:      	leaq	0x20(%r15), %rdx
    fff6:      	movq	%rdx, 0x38(%rsp)
    fffb:      	movq	0x30(%rsp), %r12
   10000:      	cmpq	0x18(%rsp), %r12
   10005:      	jne	0x10012 <generic_usdt_path+0x5712>
   10007:      	cmpq	0x20(%rsp), %rdx
   1000c:      	je	0x1636d <generic_usdt_path+0xba6d>
   10012:      	movl	$0x4, %eax
   10017:      	leaq	0x10(%rsp), %rdi
   1001c:      	movl	$0x8, %esi
   10021:      	callq	*%rax
   10023:      	cmpq	0x10(%rsp), %r12
   10028:      	je	0x10120 <generic_usdt_path+0x5820>
   1002e:      	leaq	0x18(%r12), %rbx
   10033:      	movl	$0x4, %eax
   10038:      	movq	%rbp, %rdi
   1003b:      	movl	$0x8, %esi
   10040:      	movq	%rbx, %rdx
   10043:      	callq	*%rax
   10045:      	cmpq	%r12, (%rsp)
   10049:      	je	0x10120 <generic_usdt_path+0x5820>
   1004f:      	movl	$0x4, %eax
   10054:      	leaq	0x8(%rsp), %rdi
   10059:      	movl	$0x8, %esi
   1005e:      	movq	%rbx, %rdx
   10061:      	callq	*%rax
   10063:      	addq	$0x20, %r12
   10067:      	movl	$0x4, %eax
   1006c:      	leaq	0x58(%rsp), %rdi
   10071:      	movl	$0x10, %ecx
   10076:      	movl	$0x10, %esi
   1007b:      	movq	%r12, %rdx
   1007e:      	callq	*%rax
   10080:      	movq	0x28(%rsp), %rbx
   10085:      	movq	0x48(%rsp), %rax
   1008a:      	movl	0x5c(%rsp), %r15d
   1008f:      	subq	%rbx, %rax
   10092:      	movl	0x50(%rsp), %r12d
   10097:      	movl	%r15d, %edx
   1009a:      	subl	%r12d, %edx
   1009d:      	movl	$0x0, %ecx
   100a2:      	cmovbl	%ecx, %edx
   100a5:      	addq	0x60(%rsp), %rdx
   100aa:      	xorl	%esi, %esi
   100ac:      	cmpl	%r15d, %r12d
   100af:      	seta	%sil
   100b3:      	movl	%r15d, %ecx
   100b6:      	cmovbl	%r12d, %ecx
   100ba:      	addl	%ecx, %esi
   100bc:      	movl	%r12d, %edi
   100bf:      	subl	%esi, %edi
   100c1:      	movl	%edi, 0x50(%rsp)
   100c5:      	subq	%rsi, %rax
   100c8:      	jb	0x16372 <generic_usdt_path+0xba72>
   100ce:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   100d4:      	ja	0x16372 <generic_usdt_path+0xba72>
   100da:      	cmpl	%r15d, %r12d
   100dd:      	jbe	0x100e3 <generic_usdt_path+0x57e3>
   100df:      	movb	$0x2f, (%rbx,%rax)
   100e3:      	xorl	%edi, %edi
   100e5:      	cmpl	%r15d, %r12d
   100e8:      	seta	%dil
   100ec:      	movzbl	%cl, %esi
   100ef:      	addq	%rax, %rbx
   100f2:      	addq	%rbx, %rdi
   100f5:      	movl	$0x4, %eax
   100fa:      	callq	*%rax
   100fc:      	movq	%rbx, 0x48(%rsp)
   10101:      	cmpl	%r15d, %r12d
   10104:      	jbe	0x16372 <generic_usdt_path+0xba72>
   1010a:      	movq	0x8(%rsp), %r12
   1010f:      	movq	%r12, 0x30(%rsp)
   10114:      	movq	0x38(%rsp), %rdx
   10119:      	movq	0x40(%rsp), %r15
   1011e:      	jmp	0x10171 <generic_usdt_path+0x5871>
   10120:      	leaq	0x10(%r15), %rdx
   10124:      	movl	$0x4, %eax
   10129:      	movq	%rbp, %rdi
   1012c:      	movl	$0x8, %esi
   10131:      	callq	*%rax
   10133:      	movq	0x40(%rsp), %rax
   10138:      	cmpq	(%rsp), %rax
   1013c:      	je	0x1636d <generic_usdt_path+0xba6d>
   10142:      	addq	$0x18, %r15
   10146:      	movl	$0x4, %eax
   1014b:      	leaq	0x30(%rsp), %rdi
   10150:      	movl	$0x8, %esi
   10155:      	movq	%r15, %rdx
   10158:      	callq	*%rax
   1015a:      	movq	(%rsp), %r15
   1015e:      	movq	%r15, 0x40(%rsp)
   10163:      	leaq	0x20(%r15), %rdx
   10167:      	movq	%rdx, 0x38(%rsp)
   1016c:      	movq	0x30(%rsp), %r12
   10171:      	cmpq	0x18(%rsp), %r12
   10176:      	jne	0x10183 <generic_usdt_path+0x5883>
   10178:      	cmpq	0x20(%rsp), %rdx
   1017d:      	je	0x1636d <generic_usdt_path+0xba6d>
   10183:      	movl	$0x4, %eax
   10188:      	leaq	0x10(%rsp), %rdi
   1018d:      	movl	$0x8, %esi
   10192:      	callq	*%rax
   10194:      	cmpq	0x10(%rsp), %r12
   10199:      	je	0x10291 <generic_usdt_path+0x5991>
   1019f:      	leaq	0x18(%r12), %rbx
   101a4:      	movl	$0x4, %eax
   101a9:      	movq	%rbp, %rdi
   101ac:      	movl	$0x8, %esi
   101b1:      	movq	%rbx, %rdx
   101b4:      	callq	*%rax
   101b6:      	cmpq	%r12, (%rsp)
   101ba:      	je	0x10291 <generic_usdt_path+0x5991>
   101c0:      	movl	$0x4, %eax
   101c5:      	leaq	0x8(%rsp), %rdi
   101ca:      	movl	$0x8, %esi
   101cf:      	movq	%rbx, %rdx
   101d2:      	callq	*%rax
   101d4:      	addq	$0x20, %r12
   101d8:      	movl	$0x4, %eax
   101dd:      	leaq	0x58(%rsp), %rdi
   101e2:      	movl	$0x10, %ecx
   101e7:      	movl	$0x10, %esi
   101ec:      	movq	%r12, %rdx
   101ef:      	callq	*%rax
   101f1:      	movq	0x28(%rsp), %rbx
   101f6:      	movq	0x48(%rsp), %rax
   101fb:      	movl	0x5c(%rsp), %r15d
   10200:      	subq	%rbx, %rax
   10203:      	movl	0x50(%rsp), %r12d
   10208:      	movl	%r15d, %edx
   1020b:      	subl	%r12d, %edx
   1020e:      	movl	$0x0, %ecx
   10213:      	cmovbl	%ecx, %edx
   10216:      	addq	0x60(%rsp), %rdx
   1021b:      	xorl	%esi, %esi
   1021d:      	cmpl	%r15d, %r12d
   10220:      	seta	%sil
   10224:      	movl	%r15d, %ecx
   10227:      	cmovbl	%r12d, %ecx
   1022b:      	addl	%ecx, %esi
   1022d:      	movl	%r12d, %edi
   10230:      	subl	%esi, %edi
   10232:      	movl	%edi, 0x50(%rsp)
   10236:      	subq	%rsi, %rax
   10239:      	jb	0x16372 <generic_usdt_path+0xba72>
   1023f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10245:      	ja	0x16372 <generic_usdt_path+0xba72>
   1024b:      	cmpl	%r15d, %r12d
   1024e:      	jbe	0x10254 <generic_usdt_path+0x5954>
   10250:      	movb	$0x2f, (%rbx,%rax)
   10254:      	xorl	%edi, %edi
   10256:      	cmpl	%r15d, %r12d
   10259:      	seta	%dil
   1025d:      	movzbl	%cl, %esi
   10260:      	addq	%rax, %rbx
   10263:      	addq	%rbx, %rdi
   10266:      	movl	$0x4, %eax
   1026b:      	callq	*%rax
   1026d:      	movq	%rbx, 0x48(%rsp)
   10272:      	cmpl	%r15d, %r12d
   10275:      	jbe	0x16372 <generic_usdt_path+0xba72>
   1027b:      	movq	0x8(%rsp), %r12
   10280:      	movq	%r12, 0x30(%rsp)
   10285:      	movq	0x38(%rsp), %rdx
   1028a:      	movq	0x40(%rsp), %r15
   1028f:      	jmp	0x102e2 <generic_usdt_path+0x59e2>
   10291:      	leaq	0x10(%r15), %rdx
   10295:      	movl	$0x4, %eax
   1029a:      	movq	%rbp, %rdi
   1029d:      	movl	$0x8, %esi
   102a2:      	callq	*%rax
   102a4:      	movq	0x40(%rsp), %rax
   102a9:      	cmpq	(%rsp), %rax
   102ad:      	je	0x1636d <generic_usdt_path+0xba6d>
   102b3:      	addq	$0x18, %r15
   102b7:      	movl	$0x4, %eax
   102bc:      	leaq	0x30(%rsp), %rdi
   102c1:      	movl	$0x8, %esi
   102c6:      	movq	%r15, %rdx
   102c9:      	callq	*%rax
   102cb:      	movq	(%rsp), %r15
   102cf:      	movq	%r15, 0x40(%rsp)
   102d4:      	leaq	0x20(%r15), %rdx
   102d8:      	movq	%rdx, 0x38(%rsp)
   102dd:      	movq	0x30(%rsp), %r12
   102e2:      	cmpq	0x18(%rsp), %r12
   102e7:      	jne	0x102f4 <generic_usdt_path+0x59f4>
   102e9:      	cmpq	0x20(%rsp), %rdx
   102ee:      	je	0x1636d <generic_usdt_path+0xba6d>
   102f4:      	movl	$0x4, %eax
   102f9:      	leaq	0x10(%rsp), %rdi
   102fe:      	movl	$0x8, %esi
   10303:      	callq	*%rax
   10305:      	cmpq	0x10(%rsp), %r12
   1030a:      	je	0x10402 <generic_usdt_path+0x5b02>
   10310:      	leaq	0x18(%r12), %rbx
   10315:      	movl	$0x4, %eax
   1031a:      	movq	%rbp, %rdi
   1031d:      	movl	$0x8, %esi
   10322:      	movq	%rbx, %rdx
   10325:      	callq	*%rax
   10327:      	cmpq	%r12, (%rsp)
   1032b:      	je	0x10402 <generic_usdt_path+0x5b02>
   10331:      	movl	$0x4, %eax
   10336:      	leaq	0x8(%rsp), %rdi
   1033b:      	movl	$0x8, %esi
   10340:      	movq	%rbx, %rdx
   10343:      	callq	*%rax
   10345:      	addq	$0x20, %r12
   10349:      	movl	$0x4, %eax
   1034e:      	leaq	0x58(%rsp), %rdi
   10353:      	movl	$0x10, %ecx
   10358:      	movl	$0x10, %esi
   1035d:      	movq	%r12, %rdx
   10360:      	callq	*%rax
   10362:      	movq	0x28(%rsp), %rbx
   10367:      	movq	0x48(%rsp), %rax
   1036c:      	movl	0x5c(%rsp), %r15d
   10371:      	subq	%rbx, %rax
   10374:      	movl	0x50(%rsp), %r12d
   10379:      	movl	%r15d, %edx
   1037c:      	subl	%r12d, %edx
   1037f:      	movl	$0x0, %ecx
   10384:      	cmovbl	%ecx, %edx
   10387:      	addq	0x60(%rsp), %rdx
   1038c:      	xorl	%esi, %esi
   1038e:      	cmpl	%r15d, %r12d
   10391:      	seta	%sil
   10395:      	movl	%r15d, %ecx
   10398:      	cmovbl	%r12d, %ecx
   1039c:      	addl	%ecx, %esi
   1039e:      	movl	%r12d, %edi
   103a1:      	subl	%esi, %edi
   103a3:      	movl	%edi, 0x50(%rsp)
   103a7:      	subq	%rsi, %rax
   103aa:      	jb	0x16372 <generic_usdt_path+0xba72>
   103b0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   103b6:      	ja	0x16372 <generic_usdt_path+0xba72>
   103bc:      	cmpl	%r15d, %r12d
   103bf:      	jbe	0x103c5 <generic_usdt_path+0x5ac5>
   103c1:      	movb	$0x2f, (%rbx,%rax)
   103c5:      	xorl	%edi, %edi
   103c7:      	cmpl	%r15d, %r12d
   103ca:      	seta	%dil
   103ce:      	movzbl	%cl, %esi
   103d1:      	addq	%rax, %rbx
   103d4:      	addq	%rbx, %rdi
   103d7:      	movl	$0x4, %eax
   103dc:      	callq	*%rax
   103de:      	movq	%rbx, 0x48(%rsp)
   103e3:      	cmpl	%r15d, %r12d
   103e6:      	jbe	0x16372 <generic_usdt_path+0xba72>
   103ec:      	movq	0x8(%rsp), %r12
   103f1:      	movq	%r12, 0x30(%rsp)
   103f6:      	movq	0x38(%rsp), %rdx
   103fb:      	movq	0x40(%rsp), %r15
   10400:      	jmp	0x10453 <generic_usdt_path+0x5b53>
   10402:      	leaq	0x10(%r15), %rdx
   10406:      	movl	$0x4, %eax
   1040b:      	movq	%rbp, %rdi
   1040e:      	movl	$0x8, %esi
   10413:      	callq	*%rax
   10415:      	movq	0x40(%rsp), %rax
   1041a:      	cmpq	(%rsp), %rax
   1041e:      	je	0x1636d <generic_usdt_path+0xba6d>
   10424:      	addq	$0x18, %r15
   10428:      	movl	$0x4, %eax
   1042d:      	leaq	0x30(%rsp), %rdi
   10432:      	movl	$0x8, %esi
   10437:      	movq	%r15, %rdx
   1043a:      	callq	*%rax
   1043c:      	movq	(%rsp), %r15
   10440:      	movq	%r15, 0x40(%rsp)
   10445:      	leaq	0x20(%r15), %rdx
   10449:      	movq	%rdx, 0x38(%rsp)
   1044e:      	movq	0x30(%rsp), %r12
   10453:      	cmpq	0x18(%rsp), %r12
   10458:      	jne	0x10465 <generic_usdt_path+0x5b65>
   1045a:      	cmpq	0x20(%rsp), %rdx
   1045f:      	je	0x1636d <generic_usdt_path+0xba6d>
   10465:      	movl	$0x4, %eax
   1046a:      	leaq	0x10(%rsp), %rdi
   1046f:      	movl	$0x8, %esi
   10474:      	callq	*%rax
   10476:      	cmpq	0x10(%rsp), %r12
   1047b:      	je	0x10573 <generic_usdt_path+0x5c73>
   10481:      	leaq	0x18(%r12), %rbx
   10486:      	movl	$0x4, %eax
   1048b:      	movq	%rbp, %rdi
   1048e:      	movl	$0x8, %esi
   10493:      	movq	%rbx, %rdx
   10496:      	callq	*%rax
   10498:      	cmpq	%r12, (%rsp)
   1049c:      	je	0x10573 <generic_usdt_path+0x5c73>
   104a2:      	movl	$0x4, %eax
   104a7:      	leaq	0x8(%rsp), %rdi
   104ac:      	movl	$0x8, %esi
   104b1:      	movq	%rbx, %rdx
   104b4:      	callq	*%rax
   104b6:      	addq	$0x20, %r12
   104ba:      	movl	$0x4, %eax
   104bf:      	leaq	0x58(%rsp), %rdi
   104c4:      	movl	$0x10, %ecx
   104c9:      	movl	$0x10, %esi
   104ce:      	movq	%r12, %rdx
   104d1:      	callq	*%rax
   104d3:      	movq	0x28(%rsp), %rbx
   104d8:      	movq	0x48(%rsp), %rax
   104dd:      	movl	0x5c(%rsp), %r15d
   104e2:      	subq	%rbx, %rax
   104e5:      	movl	0x50(%rsp), %r12d
   104ea:      	movl	%r15d, %edx
   104ed:      	subl	%r12d, %edx
   104f0:      	movl	$0x0, %ecx
   104f5:      	cmovbl	%ecx, %edx
   104f8:      	addq	0x60(%rsp), %rdx
   104fd:      	xorl	%esi, %esi
   104ff:      	cmpl	%r15d, %r12d
   10502:      	seta	%sil
   10506:      	movl	%r15d, %ecx
   10509:      	cmovbl	%r12d, %ecx
   1050d:      	addl	%ecx, %esi
   1050f:      	movl	%r12d, %edi
   10512:      	subl	%esi, %edi
   10514:      	movl	%edi, 0x50(%rsp)
   10518:      	subq	%rsi, %rax
   1051b:      	jb	0x16372 <generic_usdt_path+0xba72>
   10521:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10527:      	ja	0x16372 <generic_usdt_path+0xba72>
   1052d:      	cmpl	%r15d, %r12d
   10530:      	jbe	0x10536 <generic_usdt_path+0x5c36>
   10532:      	movb	$0x2f, (%rbx,%rax)
   10536:      	xorl	%edi, %edi
   10538:      	cmpl	%r15d, %r12d
   1053b:      	seta	%dil
   1053f:      	movzbl	%cl, %esi
   10542:      	addq	%rax, %rbx
   10545:      	addq	%rbx, %rdi
   10548:      	movl	$0x4, %eax
   1054d:      	callq	*%rax
   1054f:      	movq	%rbx, 0x48(%rsp)
   10554:      	cmpl	%r15d, %r12d
   10557:      	jbe	0x16372 <generic_usdt_path+0xba72>
   1055d:      	movq	0x8(%rsp), %r12
   10562:      	movq	%r12, 0x30(%rsp)
   10567:      	movq	0x38(%rsp), %rdx
   1056c:      	movq	0x40(%rsp), %r15
   10571:      	jmp	0x105c4 <generic_usdt_path+0x5cc4>
   10573:      	leaq	0x10(%r15), %rdx
   10577:      	movl	$0x4, %eax
   1057c:      	movq	%rbp, %rdi
   1057f:      	movl	$0x8, %esi
   10584:      	callq	*%rax
   10586:      	movq	0x40(%rsp), %rax
   1058b:      	cmpq	(%rsp), %rax
   1058f:      	je	0x1636d <generic_usdt_path+0xba6d>
   10595:      	addq	$0x18, %r15
   10599:      	movl	$0x4, %eax
   1059e:      	leaq	0x30(%rsp), %rdi
   105a3:      	movl	$0x8, %esi
   105a8:      	movq	%r15, %rdx
   105ab:      	callq	*%rax
   105ad:      	movq	(%rsp), %r15
   105b1:      	movq	%r15, 0x40(%rsp)
   105b6:      	leaq	0x20(%r15), %rdx
   105ba:      	movq	%rdx, 0x38(%rsp)
   105bf:      	movq	0x30(%rsp), %r12
   105c4:      	cmpq	0x18(%rsp), %r12
   105c9:      	jne	0x105d6 <generic_usdt_path+0x5cd6>
   105cb:      	cmpq	0x20(%rsp), %rdx
   105d0:      	je	0x1636d <generic_usdt_path+0xba6d>
   105d6:      	movl	$0x4, %eax
   105db:      	leaq	0x10(%rsp), %rdi
   105e0:      	movl	$0x8, %esi
   105e5:      	callq	*%rax
   105e7:      	cmpq	0x10(%rsp), %r12
   105ec:      	je	0x106e4 <generic_usdt_path+0x5de4>
   105f2:      	leaq	0x18(%r12), %rbx
   105f7:      	movl	$0x4, %eax
   105fc:      	movq	%rbp, %rdi
   105ff:      	movl	$0x8, %esi
   10604:      	movq	%rbx, %rdx
   10607:      	callq	*%rax
   10609:      	cmpq	%r12, (%rsp)
   1060d:      	je	0x106e4 <generic_usdt_path+0x5de4>
   10613:      	movl	$0x4, %eax
   10618:      	leaq	0x8(%rsp), %rdi
   1061d:      	movl	$0x8, %esi
   10622:      	movq	%rbx, %rdx
   10625:      	callq	*%rax
   10627:      	addq	$0x20, %r12
   1062b:      	movl	$0x4, %eax
   10630:      	leaq	0x58(%rsp), %rdi
   10635:      	movl	$0x10, %ecx
   1063a:      	movl	$0x10, %esi
   1063f:      	movq	%r12, %rdx
   10642:      	callq	*%rax
   10644:      	movq	0x28(%rsp), %rbx
   10649:      	movq	0x48(%rsp), %rax
   1064e:      	movl	0x5c(%rsp), %r15d
   10653:      	subq	%rbx, %rax
   10656:      	movl	0x50(%rsp), %r12d
   1065b:      	movl	%r15d, %edx
   1065e:      	subl	%r12d, %edx
   10661:      	movl	$0x0, %ecx
   10666:      	cmovbl	%ecx, %edx
   10669:      	addq	0x60(%rsp), %rdx
   1066e:      	xorl	%esi, %esi
   10670:      	cmpl	%r15d, %r12d
   10673:      	seta	%sil
   10677:      	movl	%r15d, %ecx
   1067a:      	cmovbl	%r12d, %ecx
   1067e:      	addl	%ecx, %esi
   10680:      	movl	%r12d, %edi
   10683:      	subl	%esi, %edi
   10685:      	movl	%edi, 0x50(%rsp)
   10689:      	subq	%rsi, %rax
   1068c:      	jb	0x16372 <generic_usdt_path+0xba72>
   10692:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10698:      	ja	0x16372 <generic_usdt_path+0xba72>
   1069e:      	cmpl	%r15d, %r12d
   106a1:      	jbe	0x106a7 <generic_usdt_path+0x5da7>
   106a3:      	movb	$0x2f, (%rbx,%rax)
   106a7:      	xorl	%edi, %edi
   106a9:      	cmpl	%r15d, %r12d
   106ac:      	seta	%dil
   106b0:      	movzbl	%cl, %esi
   106b3:      	addq	%rax, %rbx
   106b6:      	addq	%rbx, %rdi
   106b9:      	movl	$0x4, %eax
   106be:      	callq	*%rax
   106c0:      	movq	%rbx, 0x48(%rsp)
   106c5:      	cmpl	%r15d, %r12d
   106c8:      	jbe	0x16372 <generic_usdt_path+0xba72>
   106ce:      	movq	0x8(%rsp), %r12
   106d3:      	movq	%r12, 0x30(%rsp)
   106d8:      	movq	0x38(%rsp), %rdx
   106dd:      	movq	0x40(%rsp), %r15
   106e2:      	jmp	0x10735 <generic_usdt_path+0x5e35>
   106e4:      	leaq	0x10(%r15), %rdx
   106e8:      	movl	$0x4, %eax
   106ed:      	movq	%rbp, %rdi
   106f0:      	movl	$0x8, %esi
   106f5:      	callq	*%rax
   106f7:      	movq	0x40(%rsp), %rax
   106fc:      	cmpq	(%rsp), %rax
   10700:      	je	0x1636d <generic_usdt_path+0xba6d>
   10706:      	addq	$0x18, %r15
   1070a:      	movl	$0x4, %eax
   1070f:      	leaq	0x30(%rsp), %rdi
   10714:      	movl	$0x8, %esi
   10719:      	movq	%r15, %rdx
   1071c:      	callq	*%rax
   1071e:      	movq	(%rsp), %r15
   10722:      	movq	%r15, 0x40(%rsp)
   10727:      	leaq	0x20(%r15), %rdx
   1072b:      	movq	%rdx, 0x38(%rsp)
   10730:      	movq	0x30(%rsp), %r12
   10735:      	cmpq	0x18(%rsp), %r12
   1073a:      	jne	0x10747 <generic_usdt_path+0x5e47>
   1073c:      	cmpq	0x20(%rsp), %rdx
   10741:      	je	0x1636d <generic_usdt_path+0xba6d>
   10747:      	movl	$0x4, %eax
   1074c:      	leaq	0x10(%rsp), %rdi
   10751:      	movl	$0x8, %esi
   10756:      	callq	*%rax
   10758:      	cmpq	0x10(%rsp), %r12
   1075d:      	je	0x10855 <generic_usdt_path+0x5f55>
   10763:      	leaq	0x18(%r12), %rbx
   10768:      	movl	$0x4, %eax
   1076d:      	movq	%rbp, %rdi
   10770:      	movl	$0x8, %esi
   10775:      	movq	%rbx, %rdx
   10778:      	callq	*%rax
   1077a:      	cmpq	%r12, (%rsp)
   1077e:      	je	0x10855 <generic_usdt_path+0x5f55>
   10784:      	movl	$0x4, %eax
   10789:      	leaq	0x8(%rsp), %rdi
   1078e:      	movl	$0x8, %esi
   10793:      	movq	%rbx, %rdx
   10796:      	callq	*%rax
   10798:      	addq	$0x20, %r12
   1079c:      	movl	$0x4, %eax
   107a1:      	leaq	0x58(%rsp), %rdi
   107a6:      	movl	$0x10, %ecx
   107ab:      	movl	$0x10, %esi
   107b0:      	movq	%r12, %rdx
   107b3:      	callq	*%rax
   107b5:      	movq	0x28(%rsp), %rbx
   107ba:      	movq	0x48(%rsp), %rax
   107bf:      	movl	0x5c(%rsp), %r15d
   107c4:      	subq	%rbx, %rax
   107c7:      	movl	0x50(%rsp), %r12d
   107cc:      	movl	%r15d, %edx
   107cf:      	subl	%r12d, %edx
   107d2:      	movl	$0x0, %ecx
   107d7:      	cmovbl	%ecx, %edx
   107da:      	addq	0x60(%rsp), %rdx
   107df:      	xorl	%esi, %esi
   107e1:      	cmpl	%r15d, %r12d
   107e4:      	seta	%sil
   107e8:      	movl	%r15d, %ecx
   107eb:      	cmovbl	%r12d, %ecx
   107ef:      	addl	%ecx, %esi
   107f1:      	movl	%r12d, %edi
   107f4:      	subl	%esi, %edi
   107f6:      	movl	%edi, 0x50(%rsp)
   107fa:      	subq	%rsi, %rax
   107fd:      	jb	0x16372 <generic_usdt_path+0xba72>
   10803:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10809:      	ja	0x16372 <generic_usdt_path+0xba72>
   1080f:      	cmpl	%r15d, %r12d
   10812:      	jbe	0x10818 <generic_usdt_path+0x5f18>
   10814:      	movb	$0x2f, (%rbx,%rax)
   10818:      	xorl	%edi, %edi
   1081a:      	cmpl	%r15d, %r12d
   1081d:      	seta	%dil
   10821:      	movzbl	%cl, %esi
   10824:      	addq	%rax, %rbx
   10827:      	addq	%rbx, %rdi
   1082a:      	movl	$0x4, %eax
   1082f:      	callq	*%rax
   10831:      	movq	%rbx, 0x48(%rsp)
   10836:      	cmpl	%r15d, %r12d
   10839:      	jbe	0x16372 <generic_usdt_path+0xba72>
   1083f:      	movq	0x8(%rsp), %r12
   10844:      	movq	%r12, 0x30(%rsp)
   10849:      	movq	0x38(%rsp), %rdx
   1084e:      	movq	0x40(%rsp), %r15
   10853:      	jmp	0x108a6 <generic_usdt_path+0x5fa6>
   10855:      	leaq	0x10(%r15), %rdx
   10859:      	movl	$0x4, %eax
   1085e:      	movq	%rbp, %rdi
   10861:      	movl	$0x8, %esi
   10866:      	callq	*%rax
   10868:      	movq	0x40(%rsp), %rax
   1086d:      	cmpq	(%rsp), %rax
   10871:      	je	0x1636d <generic_usdt_path+0xba6d>
   10877:      	addq	$0x18, %r15
   1087b:      	movl	$0x4, %eax
   10880:      	leaq	0x30(%rsp), %rdi
   10885:      	movl	$0x8, %esi
   1088a:      	movq	%r15, %rdx
   1088d:      	callq	*%rax
   1088f:      	movq	(%rsp), %r15
   10893:      	movq	%r15, 0x40(%rsp)
   10898:      	leaq	0x20(%r15), %rdx
   1089c:      	movq	%rdx, 0x38(%rsp)
   108a1:      	movq	0x30(%rsp), %r12
   108a6:      	cmpq	0x18(%rsp), %r12
   108ab:      	jne	0x108b8 <generic_usdt_path+0x5fb8>
   108ad:      	cmpq	0x20(%rsp), %rdx
   108b2:      	je	0x1636d <generic_usdt_path+0xba6d>
   108b8:      	movl	$0x4, %eax
   108bd:      	leaq	0x10(%rsp), %rdi
   108c2:      	movl	$0x8, %esi
   108c7:      	callq	*%rax
   108c9:      	cmpq	0x10(%rsp), %r12
   108ce:      	je	0x109c6 <generic_usdt_path+0x60c6>
   108d4:      	leaq	0x18(%r12), %rbx
   108d9:      	movl	$0x4, %eax
   108de:      	movq	%rbp, %rdi
   108e1:      	movl	$0x8, %esi
   108e6:      	movq	%rbx, %rdx
   108e9:      	callq	*%rax
   108eb:      	cmpq	%r12, (%rsp)
   108ef:      	je	0x109c6 <generic_usdt_path+0x60c6>
   108f5:      	movl	$0x4, %eax
   108fa:      	leaq	0x8(%rsp), %rdi
   108ff:      	movl	$0x8, %esi
   10904:      	movq	%rbx, %rdx
   10907:      	callq	*%rax
   10909:      	addq	$0x20, %r12
   1090d:      	movl	$0x4, %eax
   10912:      	leaq	0x58(%rsp), %rdi
   10917:      	movl	$0x10, %ecx
   1091c:      	movl	$0x10, %esi
   10921:      	movq	%r12, %rdx
   10924:      	callq	*%rax
   10926:      	movq	0x28(%rsp), %rbx
   1092b:      	movq	0x48(%rsp), %rax
   10930:      	movl	0x5c(%rsp), %r15d
   10935:      	subq	%rbx, %rax
   10938:      	movl	0x50(%rsp), %r12d
   1093d:      	movl	%r15d, %edx
   10940:      	subl	%r12d, %edx
   10943:      	movl	$0x0, %ecx
   10948:      	cmovbl	%ecx, %edx
   1094b:      	addq	0x60(%rsp), %rdx
   10950:      	xorl	%esi, %esi
   10952:      	cmpl	%r15d, %r12d
   10955:      	seta	%sil
   10959:      	movl	%r15d, %ecx
   1095c:      	cmovbl	%r12d, %ecx
   10960:      	addl	%ecx, %esi
   10962:      	movl	%r12d, %edi
   10965:      	subl	%esi, %edi
   10967:      	movl	%edi, 0x50(%rsp)
   1096b:      	subq	%rsi, %rax
   1096e:      	jb	0x16372 <generic_usdt_path+0xba72>
   10974:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1097a:      	ja	0x16372 <generic_usdt_path+0xba72>
   10980:      	cmpl	%r15d, %r12d
   10983:      	jbe	0x10989 <generic_usdt_path+0x6089>
   10985:      	movb	$0x2f, (%rbx,%rax)
   10989:      	xorl	%edi, %edi
   1098b:      	cmpl	%r15d, %r12d
   1098e:      	seta	%dil
   10992:      	movzbl	%cl, %esi
   10995:      	addq	%rax, %rbx
   10998:      	addq	%rbx, %rdi
   1099b:      	movl	$0x4, %eax
   109a0:      	callq	*%rax
   109a2:      	movq	%rbx, 0x48(%rsp)
   109a7:      	cmpl	%r15d, %r12d
   109aa:      	jbe	0x16372 <generic_usdt_path+0xba72>
   109b0:      	movq	0x8(%rsp), %r12
   109b5:      	movq	%r12, 0x30(%rsp)
   109ba:      	movq	0x38(%rsp), %rdx
   109bf:      	movq	0x40(%rsp), %r15
   109c4:      	jmp	0x10a17 <generic_usdt_path+0x6117>
   109c6:      	leaq	0x10(%r15), %rdx
   109ca:      	movl	$0x4, %eax
   109cf:      	movq	%rbp, %rdi
   109d2:      	movl	$0x8, %esi
   109d7:      	callq	*%rax
   109d9:      	movq	0x40(%rsp), %rax
   109de:      	cmpq	(%rsp), %rax
   109e2:      	je	0x1636d <generic_usdt_path+0xba6d>
   109e8:      	addq	$0x18, %r15
   109ec:      	movl	$0x4, %eax
   109f1:      	leaq	0x30(%rsp), %rdi
   109f6:      	movl	$0x8, %esi
   109fb:      	movq	%r15, %rdx
   109fe:      	callq	*%rax
   10a00:      	movq	(%rsp), %r15
   10a04:      	movq	%r15, 0x40(%rsp)
   10a09:      	leaq	0x20(%r15), %rdx
   10a0d:      	movq	%rdx, 0x38(%rsp)
   10a12:      	movq	0x30(%rsp), %r12
   10a17:      	cmpq	0x18(%rsp), %r12
   10a1c:      	jne	0x10a29 <generic_usdt_path+0x6129>
   10a1e:      	cmpq	0x20(%rsp), %rdx
   10a23:      	je	0x1636d <generic_usdt_path+0xba6d>
   10a29:      	movl	$0x4, %eax
   10a2e:      	leaq	0x10(%rsp), %rdi
   10a33:      	movl	$0x8, %esi
   10a38:      	callq	*%rax
   10a3a:      	cmpq	0x10(%rsp), %r12
   10a3f:      	je	0x10b37 <generic_usdt_path+0x6237>
   10a45:      	leaq	0x18(%r12), %rbx
   10a4a:      	movl	$0x4, %eax
   10a4f:      	movq	%rbp, %rdi
   10a52:      	movl	$0x8, %esi
   10a57:      	movq	%rbx, %rdx
   10a5a:      	callq	*%rax
   10a5c:      	cmpq	%r12, (%rsp)
   10a60:      	je	0x10b37 <generic_usdt_path+0x6237>
   10a66:      	movl	$0x4, %eax
   10a6b:      	leaq	0x8(%rsp), %rdi
   10a70:      	movl	$0x8, %esi
   10a75:      	movq	%rbx, %rdx
   10a78:      	callq	*%rax
   10a7a:      	addq	$0x20, %r12
   10a7e:      	movl	$0x4, %eax
   10a83:      	leaq	0x58(%rsp), %rdi
   10a88:      	movl	$0x10, %ecx
   10a8d:      	movl	$0x10, %esi
   10a92:      	movq	%r12, %rdx
   10a95:      	callq	*%rax
   10a97:      	movq	0x28(%rsp), %rbx
   10a9c:      	movq	0x48(%rsp), %rax
   10aa1:      	movl	0x5c(%rsp), %r15d
   10aa6:      	subq	%rbx, %rax
   10aa9:      	movl	0x50(%rsp), %r12d
   10aae:      	movl	%r15d, %edx
   10ab1:      	subl	%r12d, %edx
   10ab4:      	movl	$0x0, %ecx
   10ab9:      	cmovbl	%ecx, %edx
   10abc:      	addq	0x60(%rsp), %rdx
   10ac1:      	xorl	%esi, %esi
   10ac3:      	cmpl	%r15d, %r12d
   10ac6:      	seta	%sil
   10aca:      	movl	%r15d, %ecx
   10acd:      	cmovbl	%r12d, %ecx
   10ad1:      	addl	%ecx, %esi
   10ad3:      	movl	%r12d, %edi
   10ad6:      	subl	%esi, %edi
   10ad8:      	movl	%edi, 0x50(%rsp)
   10adc:      	subq	%rsi, %rax
   10adf:      	jb	0x16372 <generic_usdt_path+0xba72>
   10ae5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10aeb:      	ja	0x16372 <generic_usdt_path+0xba72>
   10af1:      	cmpl	%r15d, %r12d
   10af4:      	jbe	0x10afa <generic_usdt_path+0x61fa>
   10af6:      	movb	$0x2f, (%rbx,%rax)
   10afa:      	xorl	%edi, %edi
   10afc:      	cmpl	%r15d, %r12d
   10aff:      	seta	%dil
   10b03:      	movzbl	%cl, %esi
   10b06:      	addq	%rax, %rbx
   10b09:      	addq	%rbx, %rdi
   10b0c:      	movl	$0x4, %eax
   10b11:      	callq	*%rax
   10b13:      	movq	%rbx, 0x48(%rsp)
   10b18:      	cmpl	%r15d, %r12d
   10b1b:      	jbe	0x16372 <generic_usdt_path+0xba72>
   10b21:      	movq	0x8(%rsp), %r12
   10b26:      	movq	%r12, 0x30(%rsp)
   10b2b:      	movq	0x38(%rsp), %rdx
   10b30:      	movq	0x40(%rsp), %r15
   10b35:      	jmp	0x10b88 <generic_usdt_path+0x6288>
   10b37:      	leaq	0x10(%r15), %rdx
   10b3b:      	movl	$0x4, %eax
   10b40:      	movq	%rbp, %rdi
   10b43:      	movl	$0x8, %esi
   10b48:      	callq	*%rax
   10b4a:      	movq	0x40(%rsp), %rax
   10b4f:      	cmpq	(%rsp), %rax
   10b53:      	je	0x1636d <generic_usdt_path+0xba6d>
   10b59:      	addq	$0x18, %r15
   10b5d:      	movl	$0x4, %eax
   10b62:      	leaq	0x30(%rsp), %rdi
   10b67:      	movl	$0x8, %esi
   10b6c:      	movq	%r15, %rdx
   10b6f:      	callq	*%rax
   10b71:      	movq	(%rsp), %r15
   10b75:      	movq	%r15, 0x40(%rsp)
   10b7a:      	leaq	0x20(%r15), %rdx
   10b7e:      	movq	%rdx, 0x38(%rsp)
   10b83:      	movq	0x30(%rsp), %r12
   10b88:      	cmpq	0x18(%rsp), %r12
   10b8d:      	jne	0x10b9a <generic_usdt_path+0x629a>
   10b8f:      	cmpq	0x20(%rsp), %rdx
   10b94:      	je	0x1636d <generic_usdt_path+0xba6d>
   10b9a:      	movl	$0x4, %eax
   10b9f:      	leaq	0x10(%rsp), %rdi
   10ba4:      	movl	$0x8, %esi
   10ba9:      	callq	*%rax
   10bab:      	cmpq	0x10(%rsp), %r12
   10bb0:      	je	0x10ca8 <generic_usdt_path+0x63a8>
   10bb6:      	leaq	0x18(%r12), %rbx
   10bbb:      	movl	$0x4, %eax
   10bc0:      	movq	%rbp, %rdi
   10bc3:      	movl	$0x8, %esi
   10bc8:      	movq	%rbx, %rdx
   10bcb:      	callq	*%rax
   10bcd:      	cmpq	%r12, (%rsp)
   10bd1:      	je	0x10ca8 <generic_usdt_path+0x63a8>
   10bd7:      	movl	$0x4, %eax
   10bdc:      	leaq	0x8(%rsp), %rdi
   10be1:      	movl	$0x8, %esi
   10be6:      	movq	%rbx, %rdx
   10be9:      	callq	*%rax
   10beb:      	addq	$0x20, %r12
   10bef:      	movl	$0x4, %eax
   10bf4:      	leaq	0x58(%rsp), %rdi
   10bf9:      	movl	$0x10, %ecx
   10bfe:      	movl	$0x10, %esi
   10c03:      	movq	%r12, %rdx
   10c06:      	callq	*%rax
   10c08:      	movq	0x28(%rsp), %rbx
   10c0d:      	movq	0x48(%rsp), %rax
   10c12:      	movl	0x5c(%rsp), %r15d
   10c17:      	subq	%rbx, %rax
   10c1a:      	movl	0x50(%rsp), %r12d
   10c1f:      	movl	%r15d, %edx
   10c22:      	subl	%r12d, %edx
   10c25:      	movl	$0x0, %ecx
   10c2a:      	cmovbl	%ecx, %edx
   10c2d:      	addq	0x60(%rsp), %rdx
   10c32:      	xorl	%esi, %esi
   10c34:      	cmpl	%r15d, %r12d
   10c37:      	seta	%sil
   10c3b:      	movl	%r15d, %ecx
   10c3e:      	cmovbl	%r12d, %ecx
   10c42:      	addl	%ecx, %esi
   10c44:      	movl	%r12d, %edi
   10c47:      	subl	%esi, %edi
   10c49:      	movl	%edi, 0x50(%rsp)
   10c4d:      	subq	%rsi, %rax
   10c50:      	jb	0x16372 <generic_usdt_path+0xba72>
   10c56:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10c5c:      	ja	0x16372 <generic_usdt_path+0xba72>
   10c62:      	cmpl	%r15d, %r12d
   10c65:      	jbe	0x10c6b <generic_usdt_path+0x636b>
   10c67:      	movb	$0x2f, (%rbx,%rax)
   10c6b:      	xorl	%edi, %edi
   10c6d:      	cmpl	%r15d, %r12d
   10c70:      	seta	%dil
   10c74:      	movzbl	%cl, %esi
   10c77:      	addq	%rax, %rbx
   10c7a:      	addq	%rbx, %rdi
   10c7d:      	movl	$0x4, %eax
   10c82:      	callq	*%rax
   10c84:      	movq	%rbx, 0x48(%rsp)
   10c89:      	cmpl	%r15d, %r12d
   10c8c:      	jbe	0x16372 <generic_usdt_path+0xba72>
   10c92:      	movq	0x8(%rsp), %r12
   10c97:      	movq	%r12, 0x30(%rsp)
   10c9c:      	movq	0x38(%rsp), %rdx
   10ca1:      	movq	0x40(%rsp), %r15
   10ca6:      	jmp	0x10cf9 <generic_usdt_path+0x63f9>
   10ca8:      	leaq	0x10(%r15), %rdx
   10cac:      	movl	$0x4, %eax
   10cb1:      	movq	%rbp, %rdi
   10cb4:      	movl	$0x8, %esi
   10cb9:      	callq	*%rax
   10cbb:      	movq	0x40(%rsp), %rax
   10cc0:      	cmpq	(%rsp), %rax
   10cc4:      	je	0x1636d <generic_usdt_path+0xba6d>
   10cca:      	addq	$0x18, %r15
   10cce:      	movl	$0x4, %eax
   10cd3:      	leaq	0x30(%rsp), %rdi
   10cd8:      	movl	$0x8, %esi
   10cdd:      	movq	%r15, %rdx
   10ce0:      	callq	*%rax
   10ce2:      	movq	(%rsp), %r15
   10ce6:      	movq	%r15, 0x40(%rsp)
   10ceb:      	leaq	0x20(%r15), %rdx
   10cef:      	movq	%rdx, 0x38(%rsp)
   10cf4:      	movq	0x30(%rsp), %r12
   10cf9:      	cmpq	0x18(%rsp), %r12
   10cfe:      	jne	0x10d0b <generic_usdt_path+0x640b>
   10d00:      	cmpq	0x20(%rsp), %rdx
   10d05:      	je	0x1636d <generic_usdt_path+0xba6d>
   10d0b:      	movl	$0x4, %eax
   10d10:      	leaq	0x10(%rsp), %rdi
   10d15:      	movl	$0x8, %esi
   10d1a:      	callq	*%rax
   10d1c:      	cmpq	0x10(%rsp), %r12
   10d21:      	je	0x10e19 <generic_usdt_path+0x6519>
   10d27:      	leaq	0x18(%r12), %rbx
   10d2c:      	movl	$0x4, %eax
   10d31:      	movq	%rbp, %rdi
   10d34:      	movl	$0x8, %esi
   10d39:      	movq	%rbx, %rdx
   10d3c:      	callq	*%rax
   10d3e:      	cmpq	%r12, (%rsp)
   10d42:      	je	0x10e19 <generic_usdt_path+0x6519>
   10d48:      	movl	$0x4, %eax
   10d4d:      	leaq	0x8(%rsp), %rdi
   10d52:      	movl	$0x8, %esi
   10d57:      	movq	%rbx, %rdx
   10d5a:      	callq	*%rax
   10d5c:      	addq	$0x20, %r12
   10d60:      	movl	$0x4, %eax
   10d65:      	leaq	0x58(%rsp), %rdi
   10d6a:      	movl	$0x10, %ecx
   10d6f:      	movl	$0x10, %esi
   10d74:      	movq	%r12, %rdx
   10d77:      	callq	*%rax
   10d79:      	movq	0x28(%rsp), %rbx
   10d7e:      	movq	0x48(%rsp), %rax
   10d83:      	movl	0x5c(%rsp), %r15d
   10d88:      	subq	%rbx, %rax
   10d8b:      	movl	0x50(%rsp), %r12d
   10d90:      	movl	%r15d, %edx
   10d93:      	subl	%r12d, %edx
   10d96:      	movl	$0x0, %ecx
   10d9b:      	cmovbl	%ecx, %edx
   10d9e:      	addq	0x60(%rsp), %rdx
   10da3:      	xorl	%esi, %esi
   10da5:      	cmpl	%r15d, %r12d
   10da8:      	seta	%sil
   10dac:      	movl	%r15d, %ecx
   10daf:      	cmovbl	%r12d, %ecx
   10db3:      	addl	%ecx, %esi
   10db5:      	movl	%r12d, %edi
   10db8:      	subl	%esi, %edi
   10dba:      	movl	%edi, 0x50(%rsp)
   10dbe:      	subq	%rsi, %rax
   10dc1:      	jb	0x16372 <generic_usdt_path+0xba72>
   10dc7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10dcd:      	ja	0x16372 <generic_usdt_path+0xba72>
   10dd3:      	cmpl	%r15d, %r12d
   10dd6:      	jbe	0x10ddc <generic_usdt_path+0x64dc>
   10dd8:      	movb	$0x2f, (%rbx,%rax)
   10ddc:      	xorl	%edi, %edi
   10dde:      	cmpl	%r15d, %r12d
   10de1:      	seta	%dil
   10de5:      	movzbl	%cl, %esi
   10de8:      	addq	%rax, %rbx
   10deb:      	addq	%rbx, %rdi
   10dee:      	movl	$0x4, %eax
   10df3:      	callq	*%rax
   10df5:      	movq	%rbx, 0x48(%rsp)
   10dfa:      	cmpl	%r15d, %r12d
   10dfd:      	jbe	0x16372 <generic_usdt_path+0xba72>
   10e03:      	movq	0x8(%rsp), %r12
   10e08:      	movq	%r12, 0x30(%rsp)
   10e0d:      	movq	0x38(%rsp), %rdx
   10e12:      	movq	0x40(%rsp), %r15
   10e17:      	jmp	0x10e6a <generic_usdt_path+0x656a>
   10e19:      	leaq	0x10(%r15), %rdx
   10e1d:      	movl	$0x4, %eax
   10e22:      	movq	%rbp, %rdi
   10e25:      	movl	$0x8, %esi
   10e2a:      	callq	*%rax
   10e2c:      	movq	0x40(%rsp), %rax
   10e31:      	cmpq	(%rsp), %rax
   10e35:      	je	0x1636d <generic_usdt_path+0xba6d>
   10e3b:      	addq	$0x18, %r15
   10e3f:      	movl	$0x4, %eax
   10e44:      	leaq	0x30(%rsp), %rdi
   10e49:      	movl	$0x8, %esi
   10e4e:      	movq	%r15, %rdx
   10e51:      	callq	*%rax
   10e53:      	movq	(%rsp), %r15
   10e57:      	movq	%r15, 0x40(%rsp)
   10e5c:      	leaq	0x20(%r15), %rdx
   10e60:      	movq	%rdx, 0x38(%rsp)
   10e65:      	movq	0x30(%rsp), %r12
   10e6a:      	cmpq	0x18(%rsp), %r12
   10e6f:      	jne	0x10e7c <generic_usdt_path+0x657c>
   10e71:      	cmpq	0x20(%rsp), %rdx
   10e76:      	je	0x1636d <generic_usdt_path+0xba6d>
   10e7c:      	movl	$0x4, %eax
   10e81:      	leaq	0x10(%rsp), %rdi
   10e86:      	movl	$0x8, %esi
   10e8b:      	callq	*%rax
   10e8d:      	cmpq	0x10(%rsp), %r12
   10e92:      	je	0x10f8a <generic_usdt_path+0x668a>
   10e98:      	leaq	0x18(%r12), %rbx
   10e9d:      	movl	$0x4, %eax
   10ea2:      	movq	%rbp, %rdi
   10ea5:      	movl	$0x8, %esi
   10eaa:      	movq	%rbx, %rdx
   10ead:      	callq	*%rax
   10eaf:      	cmpq	%r12, (%rsp)
   10eb3:      	je	0x10f8a <generic_usdt_path+0x668a>
   10eb9:      	movl	$0x4, %eax
   10ebe:      	leaq	0x8(%rsp), %rdi
   10ec3:      	movl	$0x8, %esi
   10ec8:      	movq	%rbx, %rdx
   10ecb:      	callq	*%rax
   10ecd:      	addq	$0x20, %r12
   10ed1:      	movl	$0x4, %eax
   10ed6:      	leaq	0x58(%rsp), %rdi
   10edb:      	movl	$0x10, %ecx
   10ee0:      	movl	$0x10, %esi
   10ee5:      	movq	%r12, %rdx
   10ee8:      	callq	*%rax
   10eea:      	movq	0x28(%rsp), %rbx
   10eef:      	movq	0x48(%rsp), %rax
   10ef4:      	movl	0x5c(%rsp), %r15d
   10ef9:      	subq	%rbx, %rax
   10efc:      	movl	0x50(%rsp), %r12d
   10f01:      	movl	%r15d, %edx
   10f04:      	subl	%r12d, %edx
   10f07:      	movl	$0x0, %ecx
   10f0c:      	cmovbl	%ecx, %edx
   10f0f:      	addq	0x60(%rsp), %rdx
   10f14:      	xorl	%esi, %esi
   10f16:      	cmpl	%r15d, %r12d
   10f19:      	seta	%sil
   10f1d:      	movl	%r15d, %ecx
   10f20:      	cmovbl	%r12d, %ecx
   10f24:      	addl	%ecx, %esi
   10f26:      	movl	%r12d, %edi
   10f29:      	subl	%esi, %edi
   10f2b:      	movl	%edi, 0x50(%rsp)
   10f2f:      	subq	%rsi, %rax
   10f32:      	jb	0x16372 <generic_usdt_path+0xba72>
   10f38:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   10f3e:      	ja	0x16372 <generic_usdt_path+0xba72>
   10f44:      	cmpl	%r15d, %r12d
   10f47:      	jbe	0x10f4d <generic_usdt_path+0x664d>
   10f49:      	movb	$0x2f, (%rbx,%rax)
   10f4d:      	xorl	%edi, %edi
   10f4f:      	cmpl	%r15d, %r12d
   10f52:      	seta	%dil
   10f56:      	movzbl	%cl, %esi
   10f59:      	addq	%rax, %rbx
   10f5c:      	addq	%rbx, %rdi
   10f5f:      	movl	$0x4, %eax
   10f64:      	callq	*%rax
   10f66:      	movq	%rbx, 0x48(%rsp)
   10f6b:      	cmpl	%r15d, %r12d
   10f6e:      	jbe	0x16372 <generic_usdt_path+0xba72>
   10f74:      	movq	0x8(%rsp), %r12
   10f79:      	movq	%r12, 0x30(%rsp)
   10f7e:      	movq	0x38(%rsp), %rdx
   10f83:      	movq	0x40(%rsp), %r15
   10f88:      	jmp	0x10fdb <generic_usdt_path+0x66db>
   10f8a:      	leaq	0x10(%r15), %rdx
   10f8e:      	movl	$0x4, %eax
   10f93:      	movq	%rbp, %rdi
   10f96:      	movl	$0x8, %esi
   10f9b:      	callq	*%rax
   10f9d:      	movq	0x40(%rsp), %rax
   10fa2:      	cmpq	(%rsp), %rax
   10fa6:      	je	0x1636d <generic_usdt_path+0xba6d>
   10fac:      	addq	$0x18, %r15
   10fb0:      	movl	$0x4, %eax
   10fb5:      	leaq	0x30(%rsp), %rdi
   10fba:      	movl	$0x8, %esi
   10fbf:      	movq	%r15, %rdx
   10fc2:      	callq	*%rax
   10fc4:      	movq	(%rsp), %r15
   10fc8:      	movq	%r15, 0x40(%rsp)
   10fcd:      	leaq	0x20(%r15), %rdx
   10fd1:      	movq	%rdx, 0x38(%rsp)
   10fd6:      	movq	0x30(%rsp), %r12
   10fdb:      	cmpq	0x18(%rsp), %r12
   10fe0:      	jne	0x10fed <generic_usdt_path+0x66ed>
   10fe2:      	cmpq	0x20(%rsp), %rdx
   10fe7:      	je	0x1636d <generic_usdt_path+0xba6d>
   10fed:      	movl	$0x4, %eax
   10ff2:      	leaq	0x10(%rsp), %rdi
   10ff7:      	movl	$0x8, %esi
   10ffc:      	callq	*%rax
   10ffe:      	cmpq	0x10(%rsp), %r12
   11003:      	je	0x110fb <generic_usdt_path+0x67fb>
   11009:      	leaq	0x18(%r12), %rbx
   1100e:      	movl	$0x4, %eax
   11013:      	movq	%rbp, %rdi
   11016:      	movl	$0x8, %esi
   1101b:      	movq	%rbx, %rdx
   1101e:      	callq	*%rax
   11020:      	cmpq	%r12, (%rsp)
   11024:      	je	0x110fb <generic_usdt_path+0x67fb>
   1102a:      	movl	$0x4, %eax
   1102f:      	leaq	0x8(%rsp), %rdi
   11034:      	movl	$0x8, %esi
   11039:      	movq	%rbx, %rdx
   1103c:      	callq	*%rax
   1103e:      	addq	$0x20, %r12
   11042:      	movl	$0x4, %eax
   11047:      	leaq	0x58(%rsp), %rdi
   1104c:      	movl	$0x10, %ecx
   11051:      	movl	$0x10, %esi
   11056:      	movq	%r12, %rdx
   11059:      	callq	*%rax
   1105b:      	movq	0x28(%rsp), %rbx
   11060:      	movq	0x48(%rsp), %rax
   11065:      	movl	0x5c(%rsp), %r15d
   1106a:      	subq	%rbx, %rax
   1106d:      	movl	0x50(%rsp), %r12d
   11072:      	movl	%r15d, %edx
   11075:      	subl	%r12d, %edx
   11078:      	movl	$0x0, %ecx
   1107d:      	cmovbl	%ecx, %edx
   11080:      	addq	0x60(%rsp), %rdx
   11085:      	xorl	%esi, %esi
   11087:      	cmpl	%r15d, %r12d
   1108a:      	seta	%sil
   1108e:      	movl	%r15d, %ecx
   11091:      	cmovbl	%r12d, %ecx
   11095:      	addl	%ecx, %esi
   11097:      	movl	%r12d, %edi
   1109a:      	subl	%esi, %edi
   1109c:      	movl	%edi, 0x50(%rsp)
   110a0:      	subq	%rsi, %rax
   110a3:      	jb	0x16372 <generic_usdt_path+0xba72>
   110a9:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   110af:      	ja	0x16372 <generic_usdt_path+0xba72>
   110b5:      	cmpl	%r15d, %r12d
   110b8:      	jbe	0x110be <generic_usdt_path+0x67be>
   110ba:      	movb	$0x2f, (%rbx,%rax)
   110be:      	xorl	%edi, %edi
   110c0:      	cmpl	%r15d, %r12d
   110c3:      	seta	%dil
   110c7:      	movzbl	%cl, %esi
   110ca:      	addq	%rax, %rbx
   110cd:      	addq	%rbx, %rdi
   110d0:      	movl	$0x4, %eax
   110d5:      	callq	*%rax
   110d7:      	movq	%rbx, 0x48(%rsp)
   110dc:      	cmpl	%r15d, %r12d
   110df:      	jbe	0x16372 <generic_usdt_path+0xba72>
   110e5:      	movq	0x8(%rsp), %r12
   110ea:      	movq	%r12, 0x30(%rsp)
   110ef:      	movq	0x38(%rsp), %rdx
   110f4:      	movq	0x40(%rsp), %r15
   110f9:      	jmp	0x1114c <generic_usdt_path+0x684c>
   110fb:      	leaq	0x10(%r15), %rdx
   110ff:      	movl	$0x4, %eax
   11104:      	movq	%rbp, %rdi
   11107:      	movl	$0x8, %esi
   1110c:      	callq	*%rax
   1110e:      	movq	0x40(%rsp), %rax
   11113:      	cmpq	(%rsp), %rax
   11117:      	je	0x1636d <generic_usdt_path+0xba6d>
   1111d:      	addq	$0x18, %r15
   11121:      	movl	$0x4, %eax
   11126:      	leaq	0x30(%rsp), %rdi
   1112b:      	movl	$0x8, %esi
   11130:      	movq	%r15, %rdx
   11133:      	callq	*%rax
   11135:      	movq	(%rsp), %r15
   11139:      	movq	%r15, 0x40(%rsp)
   1113e:      	leaq	0x20(%r15), %rdx
   11142:      	movq	%rdx, 0x38(%rsp)
   11147:      	movq	0x30(%rsp), %r12
   1114c:      	cmpq	0x18(%rsp), %r12
   11151:      	jne	0x1115e <generic_usdt_path+0x685e>
   11153:      	cmpq	0x20(%rsp), %rdx
   11158:      	je	0x1636d <generic_usdt_path+0xba6d>
   1115e:      	movl	$0x4, %eax
   11163:      	leaq	0x10(%rsp), %rdi
   11168:      	movl	$0x8, %esi
   1116d:      	callq	*%rax
   1116f:      	cmpq	0x10(%rsp), %r12
   11174:      	je	0x1126c <generic_usdt_path+0x696c>
   1117a:      	leaq	0x18(%r12), %rbx
   1117f:      	movl	$0x4, %eax
   11184:      	movq	%rbp, %rdi
   11187:      	movl	$0x8, %esi
   1118c:      	movq	%rbx, %rdx
   1118f:      	callq	*%rax
   11191:      	cmpq	%r12, (%rsp)
   11195:      	je	0x1126c <generic_usdt_path+0x696c>
   1119b:      	movl	$0x4, %eax
   111a0:      	leaq	0x8(%rsp), %rdi
   111a5:      	movl	$0x8, %esi
   111aa:      	movq	%rbx, %rdx
   111ad:      	callq	*%rax
   111af:      	addq	$0x20, %r12
   111b3:      	movl	$0x4, %eax
   111b8:      	leaq	0x58(%rsp), %rdi
   111bd:      	movl	$0x10, %ecx
   111c2:      	movl	$0x10, %esi
   111c7:      	movq	%r12, %rdx
   111ca:      	callq	*%rax
   111cc:      	movq	0x28(%rsp), %rbx
   111d1:      	movq	0x48(%rsp), %rax
   111d6:      	movl	0x5c(%rsp), %r15d
   111db:      	subq	%rbx, %rax
   111de:      	movl	0x50(%rsp), %r12d
   111e3:      	movl	%r15d, %edx
   111e6:      	subl	%r12d, %edx
   111e9:      	movl	$0x0, %ecx
   111ee:      	cmovbl	%ecx, %edx
   111f1:      	addq	0x60(%rsp), %rdx
   111f6:      	xorl	%esi, %esi
   111f8:      	cmpl	%r15d, %r12d
   111fb:      	seta	%sil
   111ff:      	movl	%r15d, %ecx
   11202:      	cmovbl	%r12d, %ecx
   11206:      	addl	%ecx, %esi
   11208:      	movl	%r12d, %edi
   1120b:      	subl	%esi, %edi
   1120d:      	movl	%edi, 0x50(%rsp)
   11211:      	subq	%rsi, %rax
   11214:      	jb	0x16372 <generic_usdt_path+0xba72>
   1121a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11220:      	ja	0x16372 <generic_usdt_path+0xba72>
   11226:      	cmpl	%r15d, %r12d
   11229:      	jbe	0x1122f <generic_usdt_path+0x692f>
   1122b:      	movb	$0x2f, (%rbx,%rax)
   1122f:      	xorl	%edi, %edi
   11231:      	cmpl	%r15d, %r12d
   11234:      	seta	%dil
   11238:      	movzbl	%cl, %esi
   1123b:      	addq	%rax, %rbx
   1123e:      	addq	%rbx, %rdi
   11241:      	movl	$0x4, %eax
   11246:      	callq	*%rax
   11248:      	movq	%rbx, 0x48(%rsp)
   1124d:      	cmpl	%r15d, %r12d
   11250:      	jbe	0x16372 <generic_usdt_path+0xba72>
   11256:      	movq	0x8(%rsp), %r12
   1125b:      	movq	%r12, 0x30(%rsp)
   11260:      	movq	0x38(%rsp), %rdx
   11265:      	movq	0x40(%rsp), %r15
   1126a:      	jmp	0x112bd <generic_usdt_path+0x69bd>
   1126c:      	leaq	0x10(%r15), %rdx
   11270:      	movl	$0x4, %eax
   11275:      	movq	%rbp, %rdi
   11278:      	movl	$0x8, %esi
   1127d:      	callq	*%rax
   1127f:      	movq	0x40(%rsp), %rax
   11284:      	cmpq	(%rsp), %rax
   11288:      	je	0x1636d <generic_usdt_path+0xba6d>
   1128e:      	addq	$0x18, %r15
   11292:      	movl	$0x4, %eax
   11297:      	leaq	0x30(%rsp), %rdi
   1129c:      	movl	$0x8, %esi
   112a1:      	movq	%r15, %rdx
   112a4:      	callq	*%rax
   112a6:      	movq	(%rsp), %r15
   112aa:      	movq	%r15, 0x40(%rsp)
   112af:      	leaq	0x20(%r15), %rdx
   112b3:      	movq	%rdx, 0x38(%rsp)
   112b8:      	movq	0x30(%rsp), %r12
   112bd:      	cmpq	0x18(%rsp), %r12
   112c2:      	jne	0x112cf <generic_usdt_path+0x69cf>
   112c4:      	cmpq	0x20(%rsp), %rdx
   112c9:      	je	0x1636d <generic_usdt_path+0xba6d>
   112cf:      	movl	$0x4, %eax
   112d4:      	leaq	0x10(%rsp), %rdi
   112d9:      	movl	$0x8, %esi
   112de:      	callq	*%rax
   112e0:      	cmpq	0x10(%rsp), %r12
   112e5:      	je	0x113dd <generic_usdt_path+0x6add>
   112eb:      	leaq	0x18(%r12), %rbx
   112f0:      	movl	$0x4, %eax
   112f5:      	movq	%rbp, %rdi
   112f8:      	movl	$0x8, %esi
   112fd:      	movq	%rbx, %rdx
   11300:      	callq	*%rax
   11302:      	cmpq	%r12, (%rsp)
   11306:      	je	0x113dd <generic_usdt_path+0x6add>
   1130c:      	movl	$0x4, %eax
   11311:      	leaq	0x8(%rsp), %rdi
   11316:      	movl	$0x8, %esi
   1131b:      	movq	%rbx, %rdx
   1131e:      	callq	*%rax
   11320:      	addq	$0x20, %r12
   11324:      	movl	$0x4, %eax
   11329:      	leaq	0x58(%rsp), %rdi
   1132e:      	movl	$0x10, %ecx
   11333:      	movl	$0x10, %esi
   11338:      	movq	%r12, %rdx
   1133b:      	callq	*%rax
   1133d:      	movq	0x28(%rsp), %rbx
   11342:      	movq	0x48(%rsp), %rax
   11347:      	movl	0x5c(%rsp), %r15d
   1134c:      	subq	%rbx, %rax
   1134f:      	movl	0x50(%rsp), %r12d
   11354:      	movl	%r15d, %edx
   11357:      	subl	%r12d, %edx
   1135a:      	movl	$0x0, %ecx
   1135f:      	cmovbl	%ecx, %edx
   11362:      	addq	0x60(%rsp), %rdx
   11367:      	xorl	%esi, %esi
   11369:      	cmpl	%r15d, %r12d
   1136c:      	seta	%sil
   11370:      	movl	%r15d, %ecx
   11373:      	cmovbl	%r12d, %ecx
   11377:      	addl	%ecx, %esi
   11379:      	movl	%r12d, %edi
   1137c:      	subl	%esi, %edi
   1137e:      	movl	%edi, 0x50(%rsp)
   11382:      	subq	%rsi, %rax
   11385:      	jb	0x16372 <generic_usdt_path+0xba72>
   1138b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11391:      	ja	0x16372 <generic_usdt_path+0xba72>
   11397:      	cmpl	%r15d, %r12d
   1139a:      	jbe	0x113a0 <generic_usdt_path+0x6aa0>
   1139c:      	movb	$0x2f, (%rbx,%rax)
   113a0:      	xorl	%edi, %edi
   113a2:      	cmpl	%r15d, %r12d
   113a5:      	seta	%dil
   113a9:      	movzbl	%cl, %esi
   113ac:      	addq	%rax, %rbx
   113af:      	addq	%rbx, %rdi
   113b2:      	movl	$0x4, %eax
   113b7:      	callq	*%rax
   113b9:      	movq	%rbx, 0x48(%rsp)
   113be:      	cmpl	%r15d, %r12d
   113c1:      	jbe	0x16372 <generic_usdt_path+0xba72>
   113c7:      	movq	0x8(%rsp), %r12
   113cc:      	movq	%r12, 0x30(%rsp)
   113d1:      	movq	0x38(%rsp), %rdx
   113d6:      	movq	0x40(%rsp), %r15
   113db:      	jmp	0x1142e <generic_usdt_path+0x6b2e>
   113dd:      	leaq	0x10(%r15), %rdx
   113e1:      	movl	$0x4, %eax
   113e6:      	movq	%rbp, %rdi
   113e9:      	movl	$0x8, %esi
   113ee:      	callq	*%rax
   113f0:      	movq	0x40(%rsp), %rax
   113f5:      	cmpq	(%rsp), %rax
   113f9:      	je	0x1636d <generic_usdt_path+0xba6d>
   113ff:      	addq	$0x18, %r15
   11403:      	movl	$0x4, %eax
   11408:      	leaq	0x30(%rsp), %rdi
   1140d:      	movl	$0x8, %esi
   11412:      	movq	%r15, %rdx
   11415:      	callq	*%rax
   11417:      	movq	(%rsp), %r15
   1141b:      	movq	%r15, 0x40(%rsp)
   11420:      	leaq	0x20(%r15), %rdx
   11424:      	movq	%rdx, 0x38(%rsp)
   11429:      	movq	0x30(%rsp), %r12
   1142e:      	cmpq	0x18(%rsp), %r12
   11433:      	jne	0x11440 <generic_usdt_path+0x6b40>
   11435:      	cmpq	0x20(%rsp), %rdx
   1143a:      	je	0x1636d <generic_usdt_path+0xba6d>
   11440:      	movl	$0x4, %eax
   11445:      	leaq	0x10(%rsp), %rdi
   1144a:      	movl	$0x8, %esi
   1144f:      	callq	*%rax
   11451:      	cmpq	0x10(%rsp), %r12
   11456:      	je	0x1154e <generic_usdt_path+0x6c4e>
   1145c:      	leaq	0x18(%r12), %rbx
   11461:      	movl	$0x4, %eax
   11466:      	movq	%rbp, %rdi
   11469:      	movl	$0x8, %esi
   1146e:      	movq	%rbx, %rdx
   11471:      	callq	*%rax
   11473:      	cmpq	%r12, (%rsp)
   11477:      	je	0x1154e <generic_usdt_path+0x6c4e>
   1147d:      	movl	$0x4, %eax
   11482:      	leaq	0x8(%rsp), %rdi
   11487:      	movl	$0x8, %esi
   1148c:      	movq	%rbx, %rdx
   1148f:      	callq	*%rax
   11491:      	addq	$0x20, %r12
   11495:      	movl	$0x4, %eax
   1149a:      	leaq	0x58(%rsp), %rdi
   1149f:      	movl	$0x10, %ecx
   114a4:      	movl	$0x10, %esi
   114a9:      	movq	%r12, %rdx
   114ac:      	callq	*%rax
   114ae:      	movq	0x28(%rsp), %rbx
   114b3:      	movq	0x48(%rsp), %rax
   114b8:      	movl	0x5c(%rsp), %r15d
   114bd:      	subq	%rbx, %rax
   114c0:      	movl	0x50(%rsp), %r12d
   114c5:      	movl	%r15d, %edx
   114c8:      	subl	%r12d, %edx
   114cb:      	movl	$0x0, %ecx
   114d0:      	cmovbl	%ecx, %edx
   114d3:      	addq	0x60(%rsp), %rdx
   114d8:      	xorl	%esi, %esi
   114da:      	cmpl	%r15d, %r12d
   114dd:      	seta	%sil
   114e1:      	movl	%r15d, %ecx
   114e4:      	cmovbl	%r12d, %ecx
   114e8:      	addl	%ecx, %esi
   114ea:      	movl	%r12d, %edi
   114ed:      	subl	%esi, %edi
   114ef:      	movl	%edi, 0x50(%rsp)
   114f3:      	subq	%rsi, %rax
   114f6:      	jb	0x16372 <generic_usdt_path+0xba72>
   114fc:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11502:      	ja	0x16372 <generic_usdt_path+0xba72>
   11508:      	cmpl	%r15d, %r12d
   1150b:      	jbe	0x11511 <generic_usdt_path+0x6c11>
   1150d:      	movb	$0x2f, (%rbx,%rax)
   11511:      	xorl	%edi, %edi
   11513:      	cmpl	%r15d, %r12d
   11516:      	seta	%dil
   1151a:      	movzbl	%cl, %esi
   1151d:      	addq	%rax, %rbx
   11520:      	addq	%rbx, %rdi
   11523:      	movl	$0x4, %eax
   11528:      	callq	*%rax
   1152a:      	movq	%rbx, 0x48(%rsp)
   1152f:      	cmpl	%r15d, %r12d
   11532:      	jbe	0x16372 <generic_usdt_path+0xba72>
   11538:      	movq	0x8(%rsp), %r12
   1153d:      	movq	%r12, 0x30(%rsp)
   11542:      	movq	0x38(%rsp), %rdx
   11547:      	movq	0x40(%rsp), %r15
   1154c:      	jmp	0x1159f <generic_usdt_path+0x6c9f>
   1154e:      	leaq	0x10(%r15), %rdx
   11552:      	movl	$0x4, %eax
   11557:      	movq	%rbp, %rdi
   1155a:      	movl	$0x8, %esi
   1155f:      	callq	*%rax
   11561:      	movq	0x40(%rsp), %rax
   11566:      	cmpq	(%rsp), %rax
   1156a:      	je	0x1636d <generic_usdt_path+0xba6d>
   11570:      	addq	$0x18, %r15
   11574:      	movl	$0x4, %eax
   11579:      	leaq	0x30(%rsp), %rdi
   1157e:      	movl	$0x8, %esi
   11583:      	movq	%r15, %rdx
   11586:      	callq	*%rax
   11588:      	movq	(%rsp), %r15
   1158c:      	movq	%r15, 0x40(%rsp)
   11591:      	leaq	0x20(%r15), %rdx
   11595:      	movq	%rdx, 0x38(%rsp)
   1159a:      	movq	0x30(%rsp), %r12
   1159f:      	cmpq	0x18(%rsp), %r12
   115a4:      	jne	0x115b1 <generic_usdt_path+0x6cb1>
   115a6:      	cmpq	0x20(%rsp), %rdx
   115ab:      	je	0x1636d <generic_usdt_path+0xba6d>
   115b1:      	movl	$0x4, %eax
   115b6:      	leaq	0x10(%rsp), %rdi
   115bb:      	movl	$0x8, %esi
   115c0:      	callq	*%rax
   115c2:      	cmpq	0x10(%rsp), %r12
   115c7:      	je	0x116bf <generic_usdt_path+0x6dbf>
   115cd:      	leaq	0x18(%r12), %rbx
   115d2:      	movl	$0x4, %eax
   115d7:      	movq	%rbp, %rdi
   115da:      	movl	$0x8, %esi
   115df:      	movq	%rbx, %rdx
   115e2:      	callq	*%rax
   115e4:      	cmpq	%r12, (%rsp)
   115e8:      	je	0x116bf <generic_usdt_path+0x6dbf>
   115ee:      	movl	$0x4, %eax
   115f3:      	leaq	0x8(%rsp), %rdi
   115f8:      	movl	$0x8, %esi
   115fd:      	movq	%rbx, %rdx
   11600:      	callq	*%rax
   11602:      	addq	$0x20, %r12
   11606:      	movl	$0x4, %eax
   1160b:      	leaq	0x58(%rsp), %rdi
   11610:      	movl	$0x10, %ecx
   11615:      	movl	$0x10, %esi
   1161a:      	movq	%r12, %rdx
   1161d:      	callq	*%rax
   1161f:      	movq	0x28(%rsp), %rbx
   11624:      	movq	0x48(%rsp), %rax
   11629:      	movl	0x5c(%rsp), %r15d
   1162e:      	subq	%rbx, %rax
   11631:      	movl	0x50(%rsp), %r12d
   11636:      	movl	%r15d, %edx
   11639:      	subl	%r12d, %edx
   1163c:      	movl	$0x0, %ecx
   11641:      	cmovbl	%ecx, %edx
   11644:      	addq	0x60(%rsp), %rdx
   11649:      	xorl	%esi, %esi
   1164b:      	cmpl	%r15d, %r12d
   1164e:      	seta	%sil
   11652:      	movl	%r15d, %ecx
   11655:      	cmovbl	%r12d, %ecx
   11659:      	addl	%ecx, %esi
   1165b:      	movl	%r12d, %edi
   1165e:      	subl	%esi, %edi
   11660:      	movl	%edi, 0x50(%rsp)
   11664:      	subq	%rsi, %rax
   11667:      	jb	0x16372 <generic_usdt_path+0xba72>
   1166d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11673:      	ja	0x16372 <generic_usdt_path+0xba72>
   11679:      	cmpl	%r15d, %r12d
   1167c:      	jbe	0x11682 <generic_usdt_path+0x6d82>
   1167e:      	movb	$0x2f, (%rbx,%rax)
   11682:      	xorl	%edi, %edi
   11684:      	cmpl	%r15d, %r12d
   11687:      	seta	%dil
   1168b:      	movzbl	%cl, %esi
   1168e:      	addq	%rax, %rbx
   11691:      	addq	%rbx, %rdi
   11694:      	movl	$0x4, %eax
   11699:      	callq	*%rax
   1169b:      	movq	%rbx, 0x48(%rsp)
   116a0:      	cmpl	%r15d, %r12d
   116a3:      	jbe	0x16372 <generic_usdt_path+0xba72>
   116a9:      	movq	0x8(%rsp), %r12
   116ae:      	movq	%r12, 0x30(%rsp)
   116b3:      	movq	0x38(%rsp), %rdx
   116b8:      	movq	0x40(%rsp), %r15
   116bd:      	jmp	0x11710 <generic_usdt_path+0x6e10>
   116bf:      	leaq	0x10(%r15), %rdx
   116c3:      	movl	$0x4, %eax
   116c8:      	movq	%rbp, %rdi
   116cb:      	movl	$0x8, %esi
   116d0:      	callq	*%rax
   116d2:      	movq	0x40(%rsp), %rax
   116d7:      	cmpq	(%rsp), %rax
   116db:      	je	0x1636d <generic_usdt_path+0xba6d>
   116e1:      	addq	$0x18, %r15
   116e5:      	movl	$0x4, %eax
   116ea:      	leaq	0x30(%rsp), %rdi
   116ef:      	movl	$0x8, %esi
   116f4:      	movq	%r15, %rdx
   116f7:      	callq	*%rax
   116f9:      	movq	(%rsp), %r15
   116fd:      	movq	%r15, 0x40(%rsp)
   11702:      	leaq	0x20(%r15), %rdx
   11706:      	movq	%rdx, 0x38(%rsp)
   1170b:      	movq	0x30(%rsp), %r12
   11710:      	cmpq	0x18(%rsp), %r12
   11715:      	jne	0x11722 <generic_usdt_path+0x6e22>
   11717:      	cmpq	0x20(%rsp), %rdx
   1171c:      	je	0x1636d <generic_usdt_path+0xba6d>
   11722:      	movl	$0x4, %eax
   11727:      	leaq	0x10(%rsp), %rdi
   1172c:      	movl	$0x8, %esi
   11731:      	callq	*%rax
   11733:      	cmpq	0x10(%rsp), %r12
   11738:      	je	0x11830 <generic_usdt_path+0x6f30>
   1173e:      	leaq	0x18(%r12), %rbx
   11743:      	movl	$0x4, %eax
   11748:      	movq	%rbp, %rdi
   1174b:      	movl	$0x8, %esi
   11750:      	movq	%rbx, %rdx
   11753:      	callq	*%rax
   11755:      	cmpq	%r12, (%rsp)
   11759:      	je	0x11830 <generic_usdt_path+0x6f30>
   1175f:      	movl	$0x4, %eax
   11764:      	leaq	0x8(%rsp), %rdi
   11769:      	movl	$0x8, %esi
   1176e:      	movq	%rbx, %rdx
   11771:      	callq	*%rax
   11773:      	addq	$0x20, %r12
   11777:      	movl	$0x4, %eax
   1177c:      	leaq	0x58(%rsp), %rdi
   11781:      	movl	$0x10, %ecx
   11786:      	movl	$0x10, %esi
   1178b:      	movq	%r12, %rdx
   1178e:      	callq	*%rax
   11790:      	movq	0x28(%rsp), %rbx
   11795:      	movq	0x48(%rsp), %rax
   1179a:      	movl	0x5c(%rsp), %r15d
   1179f:      	subq	%rbx, %rax
   117a2:      	movl	0x50(%rsp), %r12d
   117a7:      	movl	%r15d, %edx
   117aa:      	subl	%r12d, %edx
   117ad:      	movl	$0x0, %ecx
   117b2:      	cmovbl	%ecx, %edx
   117b5:      	addq	0x60(%rsp), %rdx
   117ba:      	xorl	%esi, %esi
   117bc:      	cmpl	%r15d, %r12d
   117bf:      	seta	%sil
   117c3:      	movl	%r15d, %ecx
   117c6:      	cmovbl	%r12d, %ecx
   117ca:      	addl	%ecx, %esi
   117cc:      	movl	%r12d, %edi
   117cf:      	subl	%esi, %edi
   117d1:      	movl	%edi, 0x50(%rsp)
   117d5:      	subq	%rsi, %rax
   117d8:      	jb	0x16372 <generic_usdt_path+0xba72>
   117de:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   117e4:      	ja	0x16372 <generic_usdt_path+0xba72>
   117ea:      	cmpl	%r15d, %r12d
   117ed:      	jbe	0x117f3 <generic_usdt_path+0x6ef3>
   117ef:      	movb	$0x2f, (%rbx,%rax)
   117f3:      	xorl	%edi, %edi
   117f5:      	cmpl	%r15d, %r12d
   117f8:      	seta	%dil
   117fc:      	movzbl	%cl, %esi
   117ff:      	addq	%rax, %rbx
   11802:      	addq	%rbx, %rdi
   11805:      	movl	$0x4, %eax
   1180a:      	callq	*%rax
   1180c:      	movq	%rbx, 0x48(%rsp)
   11811:      	cmpl	%r15d, %r12d
   11814:      	jbe	0x16372 <generic_usdt_path+0xba72>
   1181a:      	movq	0x8(%rsp), %r12
   1181f:      	movq	%r12, 0x30(%rsp)
   11824:      	movq	0x38(%rsp), %rdx
   11829:      	movq	0x40(%rsp), %r15
   1182e:      	jmp	0x11881 <generic_usdt_path+0x6f81>
   11830:      	leaq	0x10(%r15), %rdx
   11834:      	movl	$0x4, %eax
   11839:      	movq	%rbp, %rdi
   1183c:      	movl	$0x8, %esi
   11841:      	callq	*%rax
   11843:      	movq	0x40(%rsp), %rax
   11848:      	cmpq	(%rsp), %rax
   1184c:      	je	0x1636d <generic_usdt_path+0xba6d>
   11852:      	addq	$0x18, %r15
   11856:      	movl	$0x4, %eax
   1185b:      	leaq	0x30(%rsp), %rdi
   11860:      	movl	$0x8, %esi
   11865:      	movq	%r15, %rdx
   11868:      	callq	*%rax
   1186a:      	movq	(%rsp), %r15
   1186e:      	movq	%r15, 0x40(%rsp)
   11873:      	leaq	0x20(%r15), %rdx
   11877:      	movq	%rdx, 0x38(%rsp)
   1187c:      	movq	0x30(%rsp), %r12
   11881:      	cmpq	0x18(%rsp), %r12
   11886:      	jne	0x11893 <generic_usdt_path+0x6f93>
   11888:      	cmpq	0x20(%rsp), %rdx
   1188d:      	je	0x1636d <generic_usdt_path+0xba6d>
   11893:      	movl	$0x4, %eax
   11898:      	leaq	0x10(%rsp), %rdi
   1189d:      	movl	$0x8, %esi
   118a2:      	callq	*%rax
   118a4:      	cmpq	0x10(%rsp), %r12
   118a9:      	je	0x119a1 <generic_usdt_path+0x70a1>
   118af:      	leaq	0x18(%r12), %rbx
   118b4:      	movl	$0x4, %eax
   118b9:      	movq	%rbp, %rdi
   118bc:      	movl	$0x8, %esi
   118c1:      	movq	%rbx, %rdx
   118c4:      	callq	*%rax
   118c6:      	cmpq	%r12, (%rsp)
   118ca:      	je	0x119a1 <generic_usdt_path+0x70a1>
   118d0:      	movl	$0x4, %eax
   118d5:      	leaq	0x8(%rsp), %rdi
   118da:      	movl	$0x8, %esi
   118df:      	movq	%rbx, %rdx
   118e2:      	callq	*%rax
   118e4:      	addq	$0x20, %r12
   118e8:      	movl	$0x4, %eax
   118ed:      	leaq	0x58(%rsp), %rdi
   118f2:      	movl	$0x10, %ecx
   118f7:      	movl	$0x10, %esi
   118fc:      	movq	%r12, %rdx
   118ff:      	callq	*%rax
   11901:      	movq	0x28(%rsp), %rbx
   11906:      	movq	0x48(%rsp), %rax
   1190b:      	movl	0x5c(%rsp), %r15d
   11910:      	subq	%rbx, %rax
   11913:      	movl	0x50(%rsp), %r12d
   11918:      	movl	%r15d, %edx
   1191b:      	subl	%r12d, %edx
   1191e:      	movl	$0x0, %ecx
   11923:      	cmovbl	%ecx, %edx
   11926:      	addq	0x60(%rsp), %rdx
   1192b:      	xorl	%esi, %esi
   1192d:      	cmpl	%r15d, %r12d
   11930:      	seta	%sil
   11934:      	movl	%r15d, %ecx
   11937:      	cmovbl	%r12d, %ecx
   1193b:      	addl	%ecx, %esi
   1193d:      	movl	%r12d, %edi
   11940:      	subl	%esi, %edi
   11942:      	movl	%edi, 0x50(%rsp)
   11946:      	subq	%rsi, %rax
   11949:      	jb	0x16372 <generic_usdt_path+0xba72>
   1194f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11955:      	ja	0x16372 <generic_usdt_path+0xba72>
   1195b:      	cmpl	%r15d, %r12d
   1195e:      	jbe	0x11964 <generic_usdt_path+0x7064>
   11960:      	movb	$0x2f, (%rbx,%rax)
   11964:      	xorl	%edi, %edi
   11966:      	cmpl	%r15d, %r12d
   11969:      	seta	%dil
   1196d:      	movzbl	%cl, %esi
   11970:      	addq	%rax, %rbx
   11973:      	addq	%rbx, %rdi
   11976:      	movl	$0x4, %eax
   1197b:      	callq	*%rax
   1197d:      	movq	%rbx, 0x48(%rsp)
   11982:      	cmpl	%r15d, %r12d
   11985:      	jbe	0x16372 <generic_usdt_path+0xba72>
   1198b:      	movq	0x8(%rsp), %r12
   11990:      	movq	%r12, 0x30(%rsp)
   11995:      	movq	0x38(%rsp), %rdx
   1199a:      	movq	0x40(%rsp), %r15
   1199f:      	jmp	0x119f2 <generic_usdt_path+0x70f2>
   119a1:      	leaq	0x10(%r15), %rdx
   119a5:      	movl	$0x4, %eax
   119aa:      	movq	%rbp, %rdi
   119ad:      	movl	$0x8, %esi
   119b2:      	callq	*%rax
   119b4:      	movq	0x40(%rsp), %rax
   119b9:      	cmpq	(%rsp), %rax
   119bd:      	je	0x1636d <generic_usdt_path+0xba6d>
   119c3:      	addq	$0x18, %r15
   119c7:      	movl	$0x4, %eax
   119cc:      	leaq	0x30(%rsp), %rdi
   119d1:      	movl	$0x8, %esi
   119d6:      	movq	%r15, %rdx
   119d9:      	callq	*%rax
   119db:      	movq	(%rsp), %r15
   119df:      	movq	%r15, 0x40(%rsp)
   119e4:      	leaq	0x20(%r15), %rdx
   119e8:      	movq	%rdx, 0x38(%rsp)
   119ed:      	movq	0x30(%rsp), %r12
   119f2:      	cmpq	0x18(%rsp), %r12
   119f7:      	jne	0x11a04 <generic_usdt_path+0x7104>
   119f9:      	cmpq	0x20(%rsp), %rdx
   119fe:      	je	0x1636d <generic_usdt_path+0xba6d>
   11a04:      	movl	$0x4, %eax
   11a09:      	leaq	0x10(%rsp), %rdi
   11a0e:      	movl	$0x8, %esi
   11a13:      	callq	*%rax
   11a15:      	cmpq	0x10(%rsp), %r12
   11a1a:      	je	0x11b12 <generic_usdt_path+0x7212>
   11a20:      	leaq	0x18(%r12), %rbx
   11a25:      	movl	$0x4, %eax
   11a2a:      	movq	%rbp, %rdi
   11a2d:      	movl	$0x8, %esi
   11a32:      	movq	%rbx, %rdx
   11a35:      	callq	*%rax
   11a37:      	cmpq	%r12, (%rsp)
   11a3b:      	je	0x11b12 <generic_usdt_path+0x7212>
   11a41:      	movl	$0x4, %eax
   11a46:      	leaq	0x8(%rsp), %rdi
   11a4b:      	movl	$0x8, %esi
   11a50:      	movq	%rbx, %rdx
   11a53:      	callq	*%rax
   11a55:      	addq	$0x20, %r12
   11a59:      	movl	$0x4, %eax
   11a5e:      	leaq	0x58(%rsp), %rdi
   11a63:      	movl	$0x10, %ecx
   11a68:      	movl	$0x10, %esi
   11a6d:      	movq	%r12, %rdx
   11a70:      	callq	*%rax
   11a72:      	movq	0x28(%rsp), %rbx
   11a77:      	movq	0x48(%rsp), %rax
   11a7c:      	movl	0x5c(%rsp), %r15d
   11a81:      	subq	%rbx, %rax
   11a84:      	movl	0x50(%rsp), %r12d
   11a89:      	movl	%r15d, %edx
   11a8c:      	subl	%r12d, %edx
   11a8f:      	movl	$0x0, %ecx
   11a94:      	cmovbl	%ecx, %edx
   11a97:      	addq	0x60(%rsp), %rdx
   11a9c:      	xorl	%esi, %esi
   11a9e:      	cmpl	%r15d, %r12d
   11aa1:      	seta	%sil
   11aa5:      	movl	%r15d, %ecx
   11aa8:      	cmovbl	%r12d, %ecx
   11aac:      	addl	%ecx, %esi
   11aae:      	movl	%r12d, %edi
   11ab1:      	subl	%esi, %edi
   11ab3:      	movl	%edi, 0x50(%rsp)
   11ab7:      	subq	%rsi, %rax
   11aba:      	jb	0x16372 <generic_usdt_path+0xba72>
   11ac0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11ac6:      	ja	0x16372 <generic_usdt_path+0xba72>
   11acc:      	cmpl	%r15d, %r12d
   11acf:      	jbe	0x11ad5 <generic_usdt_path+0x71d5>
   11ad1:      	movb	$0x2f, (%rbx,%rax)
   11ad5:      	xorl	%edi, %edi
   11ad7:      	cmpl	%r15d, %r12d
   11ada:      	seta	%dil
   11ade:      	movzbl	%cl, %esi
   11ae1:      	addq	%rax, %rbx
   11ae4:      	addq	%rbx, %rdi
   11ae7:      	movl	$0x4, %eax
   11aec:      	callq	*%rax
   11aee:      	movq	%rbx, 0x48(%rsp)
   11af3:      	cmpl	%r15d, %r12d
   11af6:      	jbe	0x16372 <generic_usdt_path+0xba72>
   11afc:      	movq	0x8(%rsp), %r12
   11b01:      	movq	%r12, 0x30(%rsp)
   11b06:      	movq	0x38(%rsp), %rdx
   11b0b:      	movq	0x40(%rsp), %r15
   11b10:      	jmp	0x11b63 <generic_usdt_path+0x7263>
   11b12:      	leaq	0x10(%r15), %rdx
   11b16:      	movl	$0x4, %eax
   11b1b:      	movq	%rbp, %rdi
   11b1e:      	movl	$0x8, %esi
   11b23:      	callq	*%rax
   11b25:      	movq	0x40(%rsp), %rax
   11b2a:      	cmpq	(%rsp), %rax
   11b2e:      	je	0x1636d <generic_usdt_path+0xba6d>
   11b34:      	addq	$0x18, %r15
   11b38:      	movl	$0x4, %eax
   11b3d:      	leaq	0x30(%rsp), %rdi
   11b42:      	movl	$0x8, %esi
   11b47:      	movq	%r15, %rdx
   11b4a:      	callq	*%rax
   11b4c:      	movq	(%rsp), %r15
   11b50:      	movq	%r15, 0x40(%rsp)
   11b55:      	leaq	0x20(%r15), %rdx
   11b59:      	movq	%rdx, 0x38(%rsp)
   11b5e:      	movq	0x30(%rsp), %r12
   11b63:      	cmpq	0x18(%rsp), %r12
   11b68:      	jne	0x11b75 <generic_usdt_path+0x7275>
   11b6a:      	cmpq	0x20(%rsp), %rdx
   11b6f:      	je	0x1636d <generic_usdt_path+0xba6d>
   11b75:      	movl	$0x4, %eax
   11b7a:      	leaq	0x10(%rsp), %rdi
   11b7f:      	movl	$0x8, %esi
   11b84:      	callq	*%rax
   11b86:      	cmpq	0x10(%rsp), %r12
   11b8b:      	je	0x11c83 <generic_usdt_path+0x7383>
   11b91:      	leaq	0x18(%r12), %rbx
   11b96:      	movl	$0x4, %eax
   11b9b:      	movq	%rbp, %rdi
   11b9e:      	movl	$0x8, %esi
   11ba3:      	movq	%rbx, %rdx
   11ba6:      	callq	*%rax
   11ba8:      	cmpq	%r12, (%rsp)
   11bac:      	je	0x11c83 <generic_usdt_path+0x7383>
   11bb2:      	movl	$0x4, %eax
   11bb7:      	leaq	0x8(%rsp), %rdi
   11bbc:      	movl	$0x8, %esi
   11bc1:      	movq	%rbx, %rdx
   11bc4:      	callq	*%rax
   11bc6:      	addq	$0x20, %r12
   11bca:      	movl	$0x4, %eax
   11bcf:      	leaq	0x58(%rsp), %rdi
   11bd4:      	movl	$0x10, %ecx
   11bd9:      	movl	$0x10, %esi
   11bde:      	movq	%r12, %rdx
   11be1:      	callq	*%rax
   11be3:      	movq	0x28(%rsp), %rbx
   11be8:      	movq	0x48(%rsp), %rax
   11bed:      	movl	0x5c(%rsp), %r15d
   11bf2:      	subq	%rbx, %rax
   11bf5:      	movl	0x50(%rsp), %r12d
   11bfa:      	movl	%r15d, %edx
   11bfd:      	subl	%r12d, %edx
   11c00:      	movl	$0x0, %ecx
   11c05:      	cmovbl	%ecx, %edx
   11c08:      	addq	0x60(%rsp), %rdx
   11c0d:      	xorl	%esi, %esi
   11c0f:      	cmpl	%r15d, %r12d
   11c12:      	seta	%sil
   11c16:      	movl	%r15d, %ecx
   11c19:      	cmovbl	%r12d, %ecx
   11c1d:      	addl	%ecx, %esi
   11c1f:      	movl	%r12d, %edi
   11c22:      	subl	%esi, %edi
   11c24:      	movl	%edi, 0x50(%rsp)
   11c28:      	subq	%rsi, %rax
   11c2b:      	jb	0x16372 <generic_usdt_path+0xba72>
   11c31:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11c37:      	ja	0x16372 <generic_usdt_path+0xba72>
   11c3d:      	cmpl	%r15d, %r12d
   11c40:      	jbe	0x11c46 <generic_usdt_path+0x7346>
   11c42:      	movb	$0x2f, (%rbx,%rax)
   11c46:      	xorl	%edi, %edi
   11c48:      	cmpl	%r15d, %r12d
   11c4b:      	seta	%dil
   11c4f:      	movzbl	%cl, %esi
   11c52:      	addq	%rax, %rbx
   11c55:      	addq	%rbx, %rdi
   11c58:      	movl	$0x4, %eax
   11c5d:      	callq	*%rax
   11c5f:      	movq	%rbx, 0x48(%rsp)
   11c64:      	cmpl	%r15d, %r12d
   11c67:      	jbe	0x16372 <generic_usdt_path+0xba72>
   11c6d:      	movq	0x8(%rsp), %r12
   11c72:      	movq	%r12, 0x30(%rsp)
   11c77:      	movq	0x38(%rsp), %rdx
   11c7c:      	movq	0x40(%rsp), %r15
   11c81:      	jmp	0x11cd4 <generic_usdt_path+0x73d4>
   11c83:      	leaq	0x10(%r15), %rdx
   11c87:      	movl	$0x4, %eax
   11c8c:      	movq	%rbp, %rdi
   11c8f:      	movl	$0x8, %esi
   11c94:      	callq	*%rax
   11c96:      	movq	0x40(%rsp), %rax
   11c9b:      	cmpq	(%rsp), %rax
   11c9f:      	je	0x1636d <generic_usdt_path+0xba6d>
   11ca5:      	addq	$0x18, %r15
   11ca9:      	movl	$0x4, %eax
   11cae:      	leaq	0x30(%rsp), %rdi
   11cb3:      	movl	$0x8, %esi
   11cb8:      	movq	%r15, %rdx
   11cbb:      	callq	*%rax
   11cbd:      	movq	(%rsp), %r15
   11cc1:      	movq	%r15, 0x40(%rsp)
   11cc6:      	leaq	0x20(%r15), %rdx
   11cca:      	movq	%rdx, 0x38(%rsp)
   11ccf:      	movq	0x30(%rsp), %r12
   11cd4:      	cmpq	0x18(%rsp), %r12
   11cd9:      	jne	0x11ce6 <generic_usdt_path+0x73e6>
   11cdb:      	cmpq	0x20(%rsp), %rdx
   11ce0:      	je	0x1636d <generic_usdt_path+0xba6d>
   11ce6:      	movl	$0x4, %eax
   11ceb:      	leaq	0x10(%rsp), %rdi
   11cf0:      	movl	$0x8, %esi
   11cf5:      	callq	*%rax
   11cf7:      	cmpq	0x10(%rsp), %r12
   11cfc:      	je	0x11df4 <generic_usdt_path+0x74f4>
   11d02:      	leaq	0x18(%r12), %rbx
   11d07:      	movl	$0x4, %eax
   11d0c:      	movq	%rbp, %rdi
   11d0f:      	movl	$0x8, %esi
   11d14:      	movq	%rbx, %rdx
   11d17:      	callq	*%rax
   11d19:      	cmpq	%r12, (%rsp)
   11d1d:      	je	0x11df4 <generic_usdt_path+0x74f4>
   11d23:      	movl	$0x4, %eax
   11d28:      	leaq	0x8(%rsp), %rdi
   11d2d:      	movl	$0x8, %esi
   11d32:      	movq	%rbx, %rdx
   11d35:      	callq	*%rax
   11d37:      	addq	$0x20, %r12
   11d3b:      	movl	$0x4, %eax
   11d40:      	leaq	0x58(%rsp), %rdi
   11d45:      	movl	$0x10, %ecx
   11d4a:      	movl	$0x10, %esi
   11d4f:      	movq	%r12, %rdx
   11d52:      	callq	*%rax
   11d54:      	movq	0x28(%rsp), %rbx
   11d59:      	movq	0x48(%rsp), %rax
   11d5e:      	movl	0x5c(%rsp), %r15d
   11d63:      	subq	%rbx, %rax
   11d66:      	movl	0x50(%rsp), %r12d
   11d6b:      	movl	%r15d, %edx
   11d6e:      	subl	%r12d, %edx
   11d71:      	movl	$0x0, %ecx
   11d76:      	cmovbl	%ecx, %edx
   11d79:      	addq	0x60(%rsp), %rdx
   11d7e:      	xorl	%esi, %esi
   11d80:      	cmpl	%r15d, %r12d
   11d83:      	seta	%sil
   11d87:      	movl	%r15d, %ecx
   11d8a:      	cmovbl	%r12d, %ecx
   11d8e:      	addl	%ecx, %esi
   11d90:      	movl	%r12d, %edi
   11d93:      	subl	%esi, %edi
   11d95:      	movl	%edi, 0x50(%rsp)
   11d99:      	subq	%rsi, %rax
   11d9c:      	jb	0x16372 <generic_usdt_path+0xba72>
   11da2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11da8:      	ja	0x16372 <generic_usdt_path+0xba72>
   11dae:      	cmpl	%r15d, %r12d
   11db1:      	jbe	0x11db7 <generic_usdt_path+0x74b7>
   11db3:      	movb	$0x2f, (%rbx,%rax)
   11db7:      	xorl	%edi, %edi
   11db9:      	cmpl	%r15d, %r12d
   11dbc:      	seta	%dil
   11dc0:      	movzbl	%cl, %esi
   11dc3:      	addq	%rax, %rbx
   11dc6:      	addq	%rbx, %rdi
   11dc9:      	movl	$0x4, %eax
   11dce:      	callq	*%rax
   11dd0:      	movq	%rbx, 0x48(%rsp)
   11dd5:      	cmpl	%r15d, %r12d
   11dd8:      	jbe	0x16372 <generic_usdt_path+0xba72>
   11dde:      	movq	0x8(%rsp), %r12
   11de3:      	movq	%r12, 0x30(%rsp)
   11de8:      	movq	0x38(%rsp), %rdx
   11ded:      	movq	0x40(%rsp), %r15
   11df2:      	jmp	0x11e45 <generic_usdt_path+0x7545>
   11df4:      	leaq	0x10(%r15), %rdx
   11df8:      	movl	$0x4, %eax
   11dfd:      	movq	%rbp, %rdi
   11e00:      	movl	$0x8, %esi
   11e05:      	callq	*%rax
   11e07:      	movq	0x40(%rsp), %rax
   11e0c:      	cmpq	(%rsp), %rax
   11e10:      	je	0x1636d <generic_usdt_path+0xba6d>
   11e16:      	addq	$0x18, %r15
   11e1a:      	movl	$0x4, %eax
   11e1f:      	leaq	0x30(%rsp), %rdi
   11e24:      	movl	$0x8, %esi
   11e29:      	movq	%r15, %rdx
   11e2c:      	callq	*%rax
   11e2e:      	movq	(%rsp), %r15
   11e32:      	movq	%r15, 0x40(%rsp)
   11e37:      	leaq	0x20(%r15), %rdx
   11e3b:      	movq	%rdx, 0x38(%rsp)
   11e40:      	movq	0x30(%rsp), %r12
   11e45:      	cmpq	0x18(%rsp), %r12
   11e4a:      	jne	0x11e57 <generic_usdt_path+0x7557>
   11e4c:      	cmpq	0x20(%rsp), %rdx
   11e51:      	je	0x1636d <generic_usdt_path+0xba6d>
   11e57:      	movl	$0x4, %eax
   11e5c:      	leaq	0x10(%rsp), %rdi
   11e61:      	movl	$0x8, %esi
   11e66:      	callq	*%rax
   11e68:      	cmpq	0x10(%rsp), %r12
   11e6d:      	je	0x11f65 <generic_usdt_path+0x7665>
   11e73:      	leaq	0x18(%r12), %rbx
   11e78:      	movl	$0x4, %eax
   11e7d:      	movq	%rbp, %rdi
   11e80:      	movl	$0x8, %esi
   11e85:      	movq	%rbx, %rdx
   11e88:      	callq	*%rax
   11e8a:      	cmpq	%r12, (%rsp)
   11e8e:      	je	0x11f65 <generic_usdt_path+0x7665>
   11e94:      	movl	$0x4, %eax
   11e99:      	leaq	0x8(%rsp), %rdi
   11e9e:      	movl	$0x8, %esi
   11ea3:      	movq	%rbx, %rdx
   11ea6:      	callq	*%rax
   11ea8:      	addq	$0x20, %r12
   11eac:      	movl	$0x4, %eax
   11eb1:      	leaq	0x58(%rsp), %rdi
   11eb6:      	movl	$0x10, %ecx
   11ebb:      	movl	$0x10, %esi
   11ec0:      	movq	%r12, %rdx
   11ec3:      	callq	*%rax
   11ec5:      	movq	0x28(%rsp), %rbx
   11eca:      	movq	0x48(%rsp), %rax
   11ecf:      	movl	0x5c(%rsp), %r15d
   11ed4:      	subq	%rbx, %rax
   11ed7:      	movl	0x50(%rsp), %r12d
   11edc:      	movl	%r15d, %edx
   11edf:      	subl	%r12d, %edx
   11ee2:      	movl	$0x0, %ecx
   11ee7:      	cmovbl	%ecx, %edx
   11eea:      	addq	0x60(%rsp), %rdx
   11eef:      	xorl	%esi, %esi
   11ef1:      	cmpl	%r15d, %r12d
   11ef4:      	seta	%sil
   11ef8:      	movl	%r15d, %ecx
   11efb:      	cmovbl	%r12d, %ecx
   11eff:      	addl	%ecx, %esi
   11f01:      	movl	%r12d, %edi
   11f04:      	subl	%esi, %edi
   11f06:      	movl	%edi, 0x50(%rsp)
   11f0a:      	subq	%rsi, %rax
   11f0d:      	jb	0x16372 <generic_usdt_path+0xba72>
   11f13:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   11f19:      	ja	0x16372 <generic_usdt_path+0xba72>
   11f1f:      	cmpl	%r15d, %r12d
   11f22:      	jbe	0x11f28 <generic_usdt_path+0x7628>
   11f24:      	movb	$0x2f, (%rbx,%rax)
   11f28:      	xorl	%edi, %edi
   11f2a:      	cmpl	%r15d, %r12d
   11f2d:      	seta	%dil
   11f31:      	movzbl	%cl, %esi
   11f34:      	addq	%rax, %rbx
   11f37:      	addq	%rbx, %rdi
   11f3a:      	movl	$0x4, %eax
   11f3f:      	callq	*%rax
   11f41:      	movq	%rbx, 0x48(%rsp)
   11f46:      	cmpl	%r15d, %r12d
   11f49:      	jbe	0x16372 <generic_usdt_path+0xba72>
   11f4f:      	movq	0x8(%rsp), %r12
   11f54:      	movq	%r12, 0x30(%rsp)
   11f59:      	movq	0x38(%rsp), %rdx
   11f5e:      	movq	0x40(%rsp), %r15
   11f63:      	jmp	0x11fb6 <generic_usdt_path+0x76b6>
   11f65:      	leaq	0x10(%r15), %rdx
   11f69:      	movl	$0x4, %eax
   11f6e:      	movq	%rbp, %rdi
   11f71:      	movl	$0x8, %esi
   11f76:      	callq	*%rax
   11f78:      	movq	0x40(%rsp), %rax
   11f7d:      	cmpq	(%rsp), %rax
   11f81:      	je	0x1636d <generic_usdt_path+0xba6d>
   11f87:      	addq	$0x18, %r15
   11f8b:      	movl	$0x4, %eax
   11f90:      	leaq	0x30(%rsp), %rdi
   11f95:      	movl	$0x8, %esi
   11f9a:      	movq	%r15, %rdx
   11f9d:      	callq	*%rax
   11f9f:      	movq	(%rsp), %r15
   11fa3:      	movq	%r15, 0x40(%rsp)
   11fa8:      	leaq	0x20(%r15), %rdx
   11fac:      	movq	%rdx, 0x38(%rsp)
   11fb1:      	movq	0x30(%rsp), %r12
   11fb6:      	cmpq	0x18(%rsp), %r12
   11fbb:      	jne	0x11fc8 <generic_usdt_path+0x76c8>
   11fbd:      	cmpq	0x20(%rsp), %rdx
   11fc2:      	je	0x1636d <generic_usdt_path+0xba6d>
   11fc8:      	movl	$0x4, %eax
   11fcd:      	leaq	0x10(%rsp), %rdi
   11fd2:      	movl	$0x8, %esi
   11fd7:      	callq	*%rax
   11fd9:      	cmpq	0x10(%rsp), %r12
   11fde:      	je	0x120d6 <generic_usdt_path+0x77d6>
   11fe4:      	leaq	0x18(%r12), %rbx
   11fe9:      	movl	$0x4, %eax
   11fee:      	movq	%rbp, %rdi
   11ff1:      	movl	$0x8, %esi
   11ff6:      	movq	%rbx, %rdx
   11ff9:      	callq	*%rax
   11ffb:      	cmpq	%r12, (%rsp)
   11fff:      	je	0x120d6 <generic_usdt_path+0x77d6>
   12005:      	movl	$0x4, %eax
   1200a:      	leaq	0x8(%rsp), %rdi
   1200f:      	movl	$0x8, %esi
   12014:      	movq	%rbx, %rdx
   12017:      	callq	*%rax
   12019:      	addq	$0x20, %r12
   1201d:      	movl	$0x4, %eax
   12022:      	leaq	0x58(%rsp), %rdi
   12027:      	movl	$0x10, %ecx
   1202c:      	movl	$0x10, %esi
   12031:      	movq	%r12, %rdx
   12034:      	callq	*%rax
   12036:      	movq	0x28(%rsp), %rbx
   1203b:      	movq	0x48(%rsp), %rax
   12040:      	movl	0x5c(%rsp), %r15d
   12045:      	subq	%rbx, %rax
   12048:      	movl	0x50(%rsp), %r12d
   1204d:      	movl	%r15d, %edx
   12050:      	subl	%r12d, %edx
   12053:      	movl	$0x0, %ecx
   12058:      	cmovbl	%ecx, %edx
   1205b:      	addq	0x60(%rsp), %rdx
   12060:      	xorl	%esi, %esi
   12062:      	cmpl	%r15d, %r12d
   12065:      	seta	%sil
   12069:      	movl	%r15d, %ecx
   1206c:      	cmovbl	%r12d, %ecx
   12070:      	addl	%ecx, %esi
   12072:      	movl	%r12d, %edi
   12075:      	subl	%esi, %edi
   12077:      	movl	%edi, 0x50(%rsp)
   1207b:      	subq	%rsi, %rax
   1207e:      	jb	0x16372 <generic_usdt_path+0xba72>
   12084:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1208a:      	ja	0x16372 <generic_usdt_path+0xba72>
   12090:      	cmpl	%r15d, %r12d
   12093:      	jbe	0x12099 <generic_usdt_path+0x7799>
   12095:      	movb	$0x2f, (%rbx,%rax)
   12099:      	xorl	%edi, %edi
   1209b:      	cmpl	%r15d, %r12d
   1209e:      	seta	%dil
   120a2:      	movzbl	%cl, %esi
   120a5:      	addq	%rax, %rbx
   120a8:      	addq	%rbx, %rdi
   120ab:      	movl	$0x4, %eax
   120b0:      	callq	*%rax
   120b2:      	movq	%rbx, 0x48(%rsp)
   120b7:      	cmpl	%r15d, %r12d
   120ba:      	jbe	0x16372 <generic_usdt_path+0xba72>
   120c0:      	movq	0x8(%rsp), %r12
   120c5:      	movq	%r12, 0x30(%rsp)
   120ca:      	movq	0x38(%rsp), %rdx
   120cf:      	movq	0x40(%rsp), %r15
   120d4:      	jmp	0x12127 <generic_usdt_path+0x7827>
   120d6:      	leaq	0x10(%r15), %rdx
   120da:      	movl	$0x4, %eax
   120df:      	movq	%rbp, %rdi
   120e2:      	movl	$0x8, %esi
   120e7:      	callq	*%rax
   120e9:      	movq	0x40(%rsp), %rax
   120ee:      	cmpq	(%rsp), %rax
   120f2:      	je	0x1636d <generic_usdt_path+0xba6d>
   120f8:      	addq	$0x18, %r15
   120fc:      	movl	$0x4, %eax
   12101:      	leaq	0x30(%rsp), %rdi
   12106:      	movl	$0x8, %esi
   1210b:      	movq	%r15, %rdx
   1210e:      	callq	*%rax
   12110:      	movq	(%rsp), %r15
   12114:      	movq	%r15, 0x40(%rsp)
   12119:      	leaq	0x20(%r15), %rdx
   1211d:      	movq	%rdx, 0x38(%rsp)
   12122:      	movq	0x30(%rsp), %r12
   12127:      	cmpq	0x18(%rsp), %r12
   1212c:      	jne	0x12139 <generic_usdt_path+0x7839>
   1212e:      	cmpq	0x20(%rsp), %rdx
   12133:      	je	0x1636d <generic_usdt_path+0xba6d>
   12139:      	movl	$0x4, %eax
   1213e:      	leaq	0x10(%rsp), %rdi
   12143:      	movl	$0x8, %esi
   12148:      	callq	*%rax
   1214a:      	cmpq	0x10(%rsp), %r12
   1214f:      	je	0x12247 <generic_usdt_path+0x7947>
   12155:      	leaq	0x18(%r12), %rbx
   1215a:      	movl	$0x4, %eax
   1215f:      	movq	%rbp, %rdi
   12162:      	movl	$0x8, %esi
   12167:      	movq	%rbx, %rdx
   1216a:      	callq	*%rax
   1216c:      	cmpq	%r12, (%rsp)
   12170:      	je	0x12247 <generic_usdt_path+0x7947>
   12176:      	movl	$0x4, %eax
   1217b:      	leaq	0x8(%rsp), %rdi
   12180:      	movl	$0x8, %esi
   12185:      	movq	%rbx, %rdx
   12188:      	callq	*%rax
   1218a:      	addq	$0x20, %r12
   1218e:      	movl	$0x4, %eax
   12193:      	leaq	0x58(%rsp), %rdi
   12198:      	movl	$0x10, %ecx
   1219d:      	movl	$0x10, %esi
   121a2:      	movq	%r12, %rdx
   121a5:      	callq	*%rax
   121a7:      	movq	0x28(%rsp), %rbx
   121ac:      	movq	0x48(%rsp), %rax
   121b1:      	movl	0x5c(%rsp), %r15d
   121b6:      	subq	%rbx, %rax
   121b9:      	movl	0x50(%rsp), %r12d
   121be:      	movl	%r15d, %edx
   121c1:      	subl	%r12d, %edx
   121c4:      	movl	$0x0, %ecx
   121c9:      	cmovbl	%ecx, %edx
   121cc:      	addq	0x60(%rsp), %rdx
   121d1:      	xorl	%esi, %esi
   121d3:      	cmpl	%r15d, %r12d
   121d6:      	seta	%sil
   121da:      	movl	%r15d, %ecx
   121dd:      	cmovbl	%r12d, %ecx
   121e1:      	addl	%ecx, %esi
   121e3:      	movl	%r12d, %edi
   121e6:      	subl	%esi, %edi
   121e8:      	movl	%edi, 0x50(%rsp)
   121ec:      	subq	%rsi, %rax
   121ef:      	jb	0x16372 <generic_usdt_path+0xba72>
   121f5:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   121fb:      	ja	0x16372 <generic_usdt_path+0xba72>
   12201:      	cmpl	%r15d, %r12d
   12204:      	jbe	0x1220a <generic_usdt_path+0x790a>
   12206:      	movb	$0x2f, (%rbx,%rax)
   1220a:      	xorl	%edi, %edi
   1220c:      	cmpl	%r15d, %r12d
   1220f:      	seta	%dil
   12213:      	movzbl	%cl, %esi
   12216:      	addq	%rax, %rbx
   12219:      	addq	%rbx, %rdi
   1221c:      	movl	$0x4, %eax
   12221:      	callq	*%rax
   12223:      	movq	%rbx, 0x48(%rsp)
   12228:      	cmpl	%r15d, %r12d
   1222b:      	jbe	0x16372 <generic_usdt_path+0xba72>
   12231:      	movq	0x8(%rsp), %r12
   12236:      	movq	%r12, 0x30(%rsp)
   1223b:      	movq	0x38(%rsp), %rdx
   12240:      	movq	0x40(%rsp), %r15
   12245:      	jmp	0x12298 <generic_usdt_path+0x7998>
   12247:      	leaq	0x10(%r15), %rdx
   1224b:      	movl	$0x4, %eax
   12250:      	movq	%rbp, %rdi
   12253:      	movl	$0x8, %esi
   12258:      	callq	*%rax
   1225a:      	movq	0x40(%rsp), %rax
   1225f:      	cmpq	(%rsp), %rax
   12263:      	je	0x1636d <generic_usdt_path+0xba6d>
   12269:      	addq	$0x18, %r15
   1226d:      	movl	$0x4, %eax
   12272:      	leaq	0x30(%rsp), %rdi
   12277:      	movl	$0x8, %esi
   1227c:      	movq	%r15, %rdx
   1227f:      	callq	*%rax
   12281:      	movq	(%rsp), %r15
   12285:      	movq	%r15, 0x40(%rsp)
   1228a:      	leaq	0x20(%r15), %rdx
   1228e:      	movq	%rdx, 0x38(%rsp)
   12293:      	movq	0x30(%rsp), %r12
   12298:      	cmpq	0x18(%rsp), %r12
   1229d:      	jne	0x122aa <generic_usdt_path+0x79aa>
   1229f:      	cmpq	0x20(%rsp), %rdx
   122a4:      	je	0x1636d <generic_usdt_path+0xba6d>
   122aa:      	movl	$0x4, %eax
   122af:      	leaq	0x10(%rsp), %rdi
   122b4:      	movl	$0x8, %esi
   122b9:      	callq	*%rax
   122bb:      	cmpq	0x10(%rsp), %r12
   122c0:      	je	0x123b8 <generic_usdt_path+0x7ab8>
   122c6:      	leaq	0x18(%r12), %rbx
   122cb:      	movl	$0x4, %eax
   122d0:      	movq	%rbp, %rdi
   122d3:      	movl	$0x8, %esi
   122d8:      	movq	%rbx, %rdx
   122db:      	callq	*%rax
   122dd:      	cmpq	%r12, (%rsp)
   122e1:      	je	0x123b8 <generic_usdt_path+0x7ab8>
   122e7:      	movl	$0x4, %eax
   122ec:      	leaq	0x8(%rsp), %rdi
   122f1:      	movl	$0x8, %esi
   122f6:      	movq	%rbx, %rdx
   122f9:      	callq	*%rax
   122fb:      	addq	$0x20, %r12
   122ff:      	movl	$0x4, %eax
   12304:      	leaq	0x58(%rsp), %rdi
   12309:      	movl	$0x10, %ecx
   1230e:      	movl	$0x10, %esi
   12313:      	movq	%r12, %rdx
   12316:      	callq	*%rax
   12318:      	movq	0x28(%rsp), %rbx
   1231d:      	movq	0x48(%rsp), %rax
   12322:      	movl	0x5c(%rsp), %r15d
   12327:      	subq	%rbx, %rax
   1232a:      	movl	0x50(%rsp), %r12d
   1232f:      	movl	%r15d, %edx
   12332:      	subl	%r12d, %edx
   12335:      	movl	$0x0, %ecx
   1233a:      	cmovbl	%ecx, %edx
   1233d:      	addq	0x60(%rsp), %rdx
   12342:      	xorl	%esi, %esi
   12344:      	cmpl	%r15d, %r12d
   12347:      	seta	%sil
   1234b:      	movl	%r15d, %ecx
   1234e:      	cmovbl	%r12d, %ecx
   12352:      	addl	%ecx, %esi
   12354:      	movl	%r12d, %edi
   12357:      	subl	%esi, %edi
   12359:      	movl	%edi, 0x50(%rsp)
   1235d:      	subq	%rsi, %rax
   12360:      	jb	0x16372 <generic_usdt_path+0xba72>
   12366:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1236c:      	ja	0x16372 <generic_usdt_path+0xba72>
   12372:      	cmpl	%r15d, %r12d
   12375:      	jbe	0x1237b <generic_usdt_path+0x7a7b>
   12377:      	movb	$0x2f, (%rbx,%rax)
   1237b:      	xorl	%edi, %edi
   1237d:      	cmpl	%r15d, %r12d
   12380:      	seta	%dil
   12384:      	movzbl	%cl, %esi
   12387:      	addq	%rax, %rbx
   1238a:      	addq	%rbx, %rdi
   1238d:      	movl	$0x4, %eax
   12392:      	callq	*%rax
   12394:      	movq	%rbx, 0x48(%rsp)
   12399:      	cmpl	%r15d, %r12d
   1239c:      	jbe	0x16372 <generic_usdt_path+0xba72>
   123a2:      	movq	0x8(%rsp), %r12
   123a7:      	movq	%r12, 0x30(%rsp)
   123ac:      	movq	0x38(%rsp), %rdx
   123b1:      	movq	0x40(%rsp), %r15
   123b6:      	jmp	0x12409 <generic_usdt_path+0x7b09>
   123b8:      	leaq	0x10(%r15), %rdx
   123bc:      	movl	$0x4, %eax
   123c1:      	movq	%rbp, %rdi
   123c4:      	movl	$0x8, %esi
   123c9:      	callq	*%rax
   123cb:      	movq	0x40(%rsp), %rax
   123d0:      	cmpq	(%rsp), %rax
   123d4:      	je	0x1636d <generic_usdt_path+0xba6d>
   123da:      	addq	$0x18, %r15
   123de:      	movl	$0x4, %eax
   123e3:      	leaq	0x30(%rsp), %rdi
   123e8:      	movl	$0x8, %esi
   123ed:      	movq	%r15, %rdx
   123f0:      	callq	*%rax
   123f2:      	movq	(%rsp), %r15
   123f6:      	movq	%r15, 0x40(%rsp)
   123fb:      	leaq	0x20(%r15), %rdx
   123ff:      	movq	%rdx, 0x38(%rsp)
   12404:      	movq	0x30(%rsp), %r12
   12409:      	cmpq	0x18(%rsp), %r12
   1240e:      	jne	0x1241b <generic_usdt_path+0x7b1b>
   12410:      	cmpq	0x20(%rsp), %rdx
   12415:      	je	0x1636d <generic_usdt_path+0xba6d>
   1241b:      	movl	$0x4, %eax
   12420:      	leaq	0x10(%rsp), %rdi
   12425:      	movl	$0x8, %esi
   1242a:      	callq	*%rax
   1242c:      	cmpq	0x10(%rsp), %r12
   12431:      	je	0x12529 <generic_usdt_path+0x7c29>
   12437:      	leaq	0x18(%r12), %rbx
   1243c:      	movl	$0x4, %eax
   12441:      	movq	%rbp, %rdi
   12444:      	movl	$0x8, %esi
   12449:      	movq	%rbx, %rdx
   1244c:      	callq	*%rax
   1244e:      	cmpq	%r12, (%rsp)
   12452:      	je	0x12529 <generic_usdt_path+0x7c29>
   12458:      	movl	$0x4, %eax
   1245d:      	leaq	0x8(%rsp), %rdi
   12462:      	movl	$0x8, %esi
   12467:      	movq	%rbx, %rdx
   1246a:      	callq	*%rax
   1246c:      	addq	$0x20, %r12
   12470:      	movl	$0x4, %eax
   12475:      	leaq	0x58(%rsp), %rdi
   1247a:      	movl	$0x10, %ecx
   1247f:      	movl	$0x10, %esi
   12484:      	movq	%r12, %rdx
   12487:      	callq	*%rax
   12489:      	movq	0x28(%rsp), %rbx
   1248e:      	movq	0x48(%rsp), %rax
   12493:      	movl	0x5c(%rsp), %r15d
   12498:      	subq	%rbx, %rax
   1249b:      	movl	0x50(%rsp), %r12d
   124a0:      	movl	%r15d, %edx
   124a3:      	subl	%r12d, %edx
   124a6:      	movl	$0x0, %ecx
   124ab:      	cmovbl	%ecx, %edx
   124ae:      	addq	0x60(%rsp), %rdx
   124b3:      	xorl	%esi, %esi
   124b5:      	cmpl	%r15d, %r12d
   124b8:      	seta	%sil
   124bc:      	movl	%r15d, %ecx
   124bf:      	cmovbl	%r12d, %ecx
   124c3:      	addl	%ecx, %esi
   124c5:      	movl	%r12d, %edi
   124c8:      	subl	%esi, %edi
   124ca:      	movl	%edi, 0x50(%rsp)
   124ce:      	subq	%rsi, %rax
   124d1:      	jb	0x16372 <generic_usdt_path+0xba72>
   124d7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   124dd:      	ja	0x16372 <generic_usdt_path+0xba72>
   124e3:      	cmpl	%r15d, %r12d
   124e6:      	jbe	0x124ec <generic_usdt_path+0x7bec>
   124e8:      	movb	$0x2f, (%rbx,%rax)
   124ec:      	xorl	%edi, %edi
   124ee:      	cmpl	%r15d, %r12d
   124f1:      	seta	%dil
   124f5:      	movzbl	%cl, %esi
   124f8:      	addq	%rax, %rbx
   124fb:      	addq	%rbx, %rdi
   124fe:      	movl	$0x4, %eax
   12503:      	callq	*%rax
   12505:      	movq	%rbx, 0x48(%rsp)
   1250a:      	cmpl	%r15d, %r12d
   1250d:      	jbe	0x16372 <generic_usdt_path+0xba72>
   12513:      	movq	0x8(%rsp), %r12
   12518:      	movq	%r12, 0x30(%rsp)
   1251d:      	movq	0x38(%rsp), %rdx
   12522:      	movq	0x40(%rsp), %r15
   12527:      	jmp	0x1257a <generic_usdt_path+0x7c7a>
   12529:      	leaq	0x10(%r15), %rdx
   1252d:      	movl	$0x4, %eax
   12532:      	movq	%rbp, %rdi
   12535:      	movl	$0x8, %esi
   1253a:      	callq	*%rax
   1253c:      	movq	0x40(%rsp), %rax
   12541:      	cmpq	(%rsp), %rax
   12545:      	je	0x1636d <generic_usdt_path+0xba6d>
   1254b:      	addq	$0x18, %r15
   1254f:      	movl	$0x4, %eax
   12554:      	leaq	0x30(%rsp), %rdi
   12559:      	movl	$0x8, %esi
   1255e:      	movq	%r15, %rdx
   12561:      	callq	*%rax
   12563:      	movq	(%rsp), %r15
   12567:      	movq	%r15, 0x40(%rsp)
   1256c:      	leaq	0x20(%r15), %rdx
   12570:      	movq	%rdx, 0x38(%rsp)
   12575:      	movq	0x30(%rsp), %r12
   1257a:      	cmpq	0x18(%rsp), %r12
   1257f:      	jne	0x1258c <generic_usdt_path+0x7c8c>
   12581:      	cmpq	0x20(%rsp), %rdx
   12586:      	je	0x1636d <generic_usdt_path+0xba6d>
   1258c:      	movl	$0x4, %eax
   12591:      	leaq	0x10(%rsp), %rdi
   12596:      	movl	$0x8, %esi
   1259b:      	callq	*%rax
   1259d:      	cmpq	0x10(%rsp), %r12
   125a2:      	je	0x1269a <generic_usdt_path+0x7d9a>
   125a8:      	leaq	0x18(%r12), %rbx
   125ad:      	movl	$0x4, %eax
   125b2:      	movq	%rbp, %rdi
   125b5:      	movl	$0x8, %esi
   125ba:      	movq	%rbx, %rdx
   125bd:      	callq	*%rax
   125bf:      	cmpq	%r12, (%rsp)
   125c3:      	je	0x1269a <generic_usdt_path+0x7d9a>
   125c9:      	movl	$0x4, %eax
   125ce:      	leaq	0x8(%rsp), %rdi
   125d3:      	movl	$0x8, %esi
   125d8:      	movq	%rbx, %rdx
   125db:      	callq	*%rax
   125dd:      	addq	$0x20, %r12
   125e1:      	movl	$0x4, %eax
   125e6:      	leaq	0x58(%rsp), %rdi
   125eb:      	movl	$0x10, %ecx
   125f0:      	movl	$0x10, %esi
   125f5:      	movq	%r12, %rdx
   125f8:      	callq	*%rax
   125fa:      	movq	0x28(%rsp), %rbx
   125ff:      	movq	0x48(%rsp), %rax
   12604:      	movl	0x5c(%rsp), %r15d
   12609:      	subq	%rbx, %rax
   1260c:      	movl	0x50(%rsp), %r12d
   12611:      	movl	%r15d, %edx
   12614:      	subl	%r12d, %edx
   12617:      	movl	$0x0, %ecx
   1261c:      	cmovbl	%ecx, %edx
   1261f:      	addq	0x60(%rsp), %rdx
   12624:      	xorl	%esi, %esi
   12626:      	cmpl	%r15d, %r12d
   12629:      	seta	%sil
   1262d:      	movl	%r15d, %ecx
   12630:      	cmovbl	%r12d, %ecx
   12634:      	addl	%ecx, %esi
   12636:      	movl	%r12d, %edi
   12639:      	subl	%esi, %edi
   1263b:      	movl	%edi, 0x50(%rsp)
   1263f:      	subq	%rsi, %rax
   12642:      	jb	0x16372 <generic_usdt_path+0xba72>
   12648:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1264e:      	ja	0x16372 <generic_usdt_path+0xba72>
   12654:      	cmpl	%r15d, %r12d
   12657:      	jbe	0x1265d <generic_usdt_path+0x7d5d>
   12659:      	movb	$0x2f, (%rbx,%rax)
   1265d:      	xorl	%edi, %edi
   1265f:      	cmpl	%r15d, %r12d
   12662:      	seta	%dil
   12666:      	movzbl	%cl, %esi
   12669:      	addq	%rax, %rbx
   1266c:      	addq	%rbx, %rdi
   1266f:      	movl	$0x4, %eax
   12674:      	callq	*%rax
   12676:      	movq	%rbx, 0x48(%rsp)
   1267b:      	cmpl	%r15d, %r12d
   1267e:      	jbe	0x16372 <generic_usdt_path+0xba72>
   12684:      	movq	0x8(%rsp), %r12
   12689:      	movq	%r12, 0x30(%rsp)
   1268e:      	movq	0x38(%rsp), %rdx
   12693:      	movq	0x40(%rsp), %r15
   12698:      	jmp	0x126eb <generic_usdt_path+0x7deb>
   1269a:      	leaq	0x10(%r15), %rdx
   1269e:      	movl	$0x4, %eax
   126a3:      	movq	%rbp, %rdi
   126a6:      	movl	$0x8, %esi
   126ab:      	callq	*%rax
   126ad:      	movq	0x40(%rsp), %rax
   126b2:      	cmpq	(%rsp), %rax
   126b6:      	je	0x1636d <generic_usdt_path+0xba6d>
   126bc:      	addq	$0x18, %r15
   126c0:      	movl	$0x4, %eax
   126c5:      	leaq	0x30(%rsp), %rdi
   126ca:      	movl	$0x8, %esi
   126cf:      	movq	%r15, %rdx
   126d2:      	callq	*%rax
   126d4:      	movq	(%rsp), %r15
   126d8:      	movq	%r15, 0x40(%rsp)
   126dd:      	leaq	0x20(%r15), %rdx
   126e1:      	movq	%rdx, 0x38(%rsp)
   126e6:      	movq	0x30(%rsp), %r12
   126eb:      	cmpq	0x18(%rsp), %r12
   126f0:      	jne	0x126fd <generic_usdt_path+0x7dfd>
   126f2:      	cmpq	0x20(%rsp), %rdx
   126f7:      	je	0x1636d <generic_usdt_path+0xba6d>
   126fd:      	movl	$0x4, %eax
   12702:      	leaq	0x10(%rsp), %rdi
   12707:      	movl	$0x8, %esi
   1270c:      	callq	*%rax
   1270e:      	cmpq	0x10(%rsp), %r12
   12713:      	je	0x1280b <generic_usdt_path+0x7f0b>
   12719:      	leaq	0x18(%r12), %rbx
   1271e:      	movl	$0x4, %eax
   12723:      	movq	%rbp, %rdi
   12726:      	movl	$0x8, %esi
   1272b:      	movq	%rbx, %rdx
   1272e:      	callq	*%rax
   12730:      	cmpq	%r12, (%rsp)
   12734:      	je	0x1280b <generic_usdt_path+0x7f0b>
   1273a:      	movl	$0x4, %eax
   1273f:      	leaq	0x8(%rsp), %rdi
   12744:      	movl	$0x8, %esi
   12749:      	movq	%rbx, %rdx
   1274c:      	callq	*%rax
   1274e:      	addq	$0x20, %r12
   12752:      	movl	$0x4, %eax
   12757:      	leaq	0x58(%rsp), %rdi
   1275c:      	movl	$0x10, %ecx
   12761:      	movl	$0x10, %esi
   12766:      	movq	%r12, %rdx
   12769:      	callq	*%rax
   1276b:      	movq	0x28(%rsp), %rbx
   12770:      	movq	0x48(%rsp), %rax
   12775:      	movl	0x5c(%rsp), %r15d
   1277a:      	subq	%rbx, %rax
   1277d:      	movl	0x50(%rsp), %r12d
   12782:      	movl	%r15d, %edx
   12785:      	subl	%r12d, %edx
   12788:      	movl	$0x0, %ecx
   1278d:      	cmovbl	%ecx, %edx
   12790:      	addq	0x60(%rsp), %rdx
   12795:      	xorl	%esi, %esi
   12797:      	cmpl	%r15d, %r12d
   1279a:      	seta	%sil
   1279e:      	movl	%r15d, %ecx
   127a1:      	cmovbl	%r12d, %ecx
   127a5:      	addl	%ecx, %esi
   127a7:      	movl	%r12d, %edi
   127aa:      	subl	%esi, %edi
   127ac:      	movl	%edi, 0x50(%rsp)
   127b0:      	subq	%rsi, %rax
   127b3:      	jb	0x16372 <generic_usdt_path+0xba72>
   127b9:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   127bf:      	ja	0x16372 <generic_usdt_path+0xba72>
   127c5:      	cmpl	%r15d, %r12d
   127c8:      	jbe	0x127ce <generic_usdt_path+0x7ece>
   127ca:      	movb	$0x2f, (%rbx,%rax)
   127ce:      	xorl	%edi, %edi
   127d0:      	cmpl	%r15d, %r12d
   127d3:      	seta	%dil
   127d7:      	movzbl	%cl, %esi
   127da:      	addq	%rax, %rbx
   127dd:      	addq	%rbx, %rdi
   127e0:      	movl	$0x4, %eax
   127e5:      	callq	*%rax
   127e7:      	movq	%rbx, 0x48(%rsp)
   127ec:      	cmpl	%r15d, %r12d
   127ef:      	jbe	0x16372 <generic_usdt_path+0xba72>
   127f5:      	movq	0x8(%rsp), %r12
   127fa:      	movq	%r12, 0x30(%rsp)
   127ff:      	movq	0x38(%rsp), %rdx
   12804:      	movq	0x40(%rsp), %r15
   12809:      	jmp	0x1285c <generic_usdt_path+0x7f5c>
   1280b:      	leaq	0x10(%r15), %rdx
   1280f:      	movl	$0x4, %eax
   12814:      	movq	%rbp, %rdi
   12817:      	movl	$0x8, %esi
   1281c:      	callq	*%rax
   1281e:      	movq	0x40(%rsp), %rax
   12823:      	cmpq	(%rsp), %rax
   12827:      	je	0x1636d <generic_usdt_path+0xba6d>
   1282d:      	addq	$0x18, %r15
   12831:      	movl	$0x4, %eax
   12836:      	leaq	0x30(%rsp), %rdi
   1283b:      	movl	$0x8, %esi
   12840:      	movq	%r15, %rdx
   12843:      	callq	*%rax
   12845:      	movq	(%rsp), %r15
   12849:      	movq	%r15, 0x40(%rsp)
   1284e:      	leaq	0x20(%r15), %rdx
   12852:      	movq	%rdx, 0x38(%rsp)
   12857:      	movq	0x30(%rsp), %r12
   1285c:      	cmpq	0x18(%rsp), %r12
   12861:      	jne	0x1286e <generic_usdt_path+0x7f6e>
   12863:      	cmpq	0x20(%rsp), %rdx
   12868:      	je	0x1636d <generic_usdt_path+0xba6d>
   1286e:      	movl	$0x4, %eax
   12873:      	leaq	0x10(%rsp), %rdi
   12878:      	movl	$0x8, %esi
   1287d:      	callq	*%rax
   1287f:      	cmpq	0x10(%rsp), %r12
   12884:      	je	0x1297c <generic_usdt_path+0x807c>
   1288a:      	leaq	0x18(%r12), %rbx
   1288f:      	movl	$0x4, %eax
   12894:      	movq	%rbp, %rdi
   12897:      	movl	$0x8, %esi
   1289c:      	movq	%rbx, %rdx
   1289f:      	callq	*%rax
   128a1:      	cmpq	%r12, (%rsp)
   128a5:      	je	0x1297c <generic_usdt_path+0x807c>
   128ab:      	movl	$0x4, %eax
   128b0:      	leaq	0x8(%rsp), %rdi
   128b5:      	movl	$0x8, %esi
   128ba:      	movq	%rbx, %rdx
   128bd:      	callq	*%rax
   128bf:      	addq	$0x20, %r12
   128c3:      	movl	$0x4, %eax
   128c8:      	leaq	0x58(%rsp), %rdi
   128cd:      	movl	$0x10, %ecx
   128d2:      	movl	$0x10, %esi
   128d7:      	movq	%r12, %rdx
   128da:      	callq	*%rax
   128dc:      	movq	0x28(%rsp), %rbx
   128e1:      	movq	0x48(%rsp), %rax
   128e6:      	movl	0x5c(%rsp), %r15d
   128eb:      	subq	%rbx, %rax
   128ee:      	movl	0x50(%rsp), %r12d
   128f3:      	movl	%r15d, %edx
   128f6:      	subl	%r12d, %edx
   128f9:      	movl	$0x0, %ecx
   128fe:      	cmovbl	%ecx, %edx
   12901:      	addq	0x60(%rsp), %rdx
   12906:      	xorl	%esi, %esi
   12908:      	cmpl	%r15d, %r12d
   1290b:      	seta	%sil
   1290f:      	movl	%r15d, %ecx
   12912:      	cmovbl	%r12d, %ecx
   12916:      	addl	%ecx, %esi
   12918:      	movl	%r12d, %edi
   1291b:      	subl	%esi, %edi
   1291d:      	movl	%edi, 0x50(%rsp)
   12921:      	subq	%rsi, %rax
   12924:      	jb	0x16372 <generic_usdt_path+0xba72>
   1292a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12930:      	ja	0x16372 <generic_usdt_path+0xba72>
   12936:      	cmpl	%r15d, %r12d
   12939:      	jbe	0x1293f <generic_usdt_path+0x803f>
   1293b:      	movb	$0x2f, (%rbx,%rax)
   1293f:      	xorl	%edi, %edi
   12941:      	cmpl	%r15d, %r12d
   12944:      	seta	%dil
   12948:      	movzbl	%cl, %esi
   1294b:      	addq	%rax, %rbx
   1294e:      	addq	%rbx, %rdi
   12951:      	movl	$0x4, %eax
   12956:      	callq	*%rax
   12958:      	movq	%rbx, 0x48(%rsp)
   1295d:      	cmpl	%r15d, %r12d
   12960:      	jbe	0x16372 <generic_usdt_path+0xba72>
   12966:      	movq	0x8(%rsp), %r12
   1296b:      	movq	%r12, 0x30(%rsp)
   12970:      	movq	0x38(%rsp), %rdx
   12975:      	movq	0x40(%rsp), %r15
   1297a:      	jmp	0x129cd <generic_usdt_path+0x80cd>
   1297c:      	leaq	0x10(%r15), %rdx
   12980:      	movl	$0x4, %eax
   12985:      	movq	%rbp, %rdi
   12988:      	movl	$0x8, %esi
   1298d:      	callq	*%rax
   1298f:      	movq	0x40(%rsp), %rax
   12994:      	cmpq	(%rsp), %rax
   12998:      	je	0x1636d <generic_usdt_path+0xba6d>
   1299e:      	addq	$0x18, %r15
   129a2:      	movl	$0x4, %eax
   129a7:      	leaq	0x30(%rsp), %rdi
   129ac:      	movl	$0x8, %esi
   129b1:      	movq	%r15, %rdx
   129b4:      	callq	*%rax
   129b6:      	movq	(%rsp), %r15
   129ba:      	movq	%r15, 0x40(%rsp)
   129bf:      	leaq	0x20(%r15), %rdx
   129c3:      	movq	%rdx, 0x38(%rsp)
   129c8:      	movq	0x30(%rsp), %r12
   129cd:      	cmpq	0x18(%rsp), %r12
   129d2:      	jne	0x129df <generic_usdt_path+0x80df>
   129d4:      	cmpq	0x20(%rsp), %rdx
   129d9:      	je	0x1636d <generic_usdt_path+0xba6d>
   129df:      	movl	$0x4, %eax
   129e4:      	leaq	0x10(%rsp), %rdi
   129e9:      	movl	$0x8, %esi
   129ee:      	callq	*%rax
   129f0:      	cmpq	0x10(%rsp), %r12
   129f5:      	je	0x12aed <generic_usdt_path+0x81ed>
   129fb:      	leaq	0x18(%r12), %rbx
   12a00:      	movl	$0x4, %eax
   12a05:      	movq	%rbp, %rdi
   12a08:      	movl	$0x8, %esi
   12a0d:      	movq	%rbx, %rdx
   12a10:      	callq	*%rax
   12a12:      	cmpq	%r12, (%rsp)
   12a16:      	je	0x12aed <generic_usdt_path+0x81ed>
   12a1c:      	movl	$0x4, %eax
   12a21:      	leaq	0x8(%rsp), %rdi
   12a26:      	movl	$0x8, %esi
   12a2b:      	movq	%rbx, %rdx
   12a2e:      	callq	*%rax
   12a30:      	addq	$0x20, %r12
   12a34:      	movl	$0x4, %eax
   12a39:      	leaq	0x58(%rsp), %rdi
   12a3e:      	movl	$0x10, %ecx
   12a43:      	movl	$0x10, %esi
   12a48:      	movq	%r12, %rdx
   12a4b:      	callq	*%rax
   12a4d:      	movq	0x28(%rsp), %rbx
   12a52:      	movq	0x48(%rsp), %rax
   12a57:      	movl	0x5c(%rsp), %r15d
   12a5c:      	subq	%rbx, %rax
   12a5f:      	movl	0x50(%rsp), %r12d
   12a64:      	movl	%r15d, %edx
   12a67:      	subl	%r12d, %edx
   12a6a:      	movl	$0x0, %ecx
   12a6f:      	cmovbl	%ecx, %edx
   12a72:      	addq	0x60(%rsp), %rdx
   12a77:      	xorl	%esi, %esi
   12a79:      	cmpl	%r15d, %r12d
   12a7c:      	seta	%sil
   12a80:      	movl	%r15d, %ecx
   12a83:      	cmovbl	%r12d, %ecx
   12a87:      	addl	%ecx, %esi
   12a89:      	movl	%r12d, %edi
   12a8c:      	subl	%esi, %edi
   12a8e:      	movl	%edi, 0x50(%rsp)
   12a92:      	subq	%rsi, %rax
   12a95:      	jb	0x16372 <generic_usdt_path+0xba72>
   12a9b:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12aa1:      	ja	0x16372 <generic_usdt_path+0xba72>
   12aa7:      	cmpl	%r15d, %r12d
   12aaa:      	jbe	0x12ab0 <generic_usdt_path+0x81b0>
   12aac:      	movb	$0x2f, (%rbx,%rax)
   12ab0:      	xorl	%edi, %edi
   12ab2:      	cmpl	%r15d, %r12d
   12ab5:      	seta	%dil
   12ab9:      	movzbl	%cl, %esi
   12abc:      	addq	%rax, %rbx
   12abf:      	addq	%rbx, %rdi
   12ac2:      	movl	$0x4, %eax
   12ac7:      	callq	*%rax
   12ac9:      	movq	%rbx, 0x48(%rsp)
   12ace:      	cmpl	%r15d, %r12d
   12ad1:      	jbe	0x16372 <generic_usdt_path+0xba72>
   12ad7:      	movq	0x8(%rsp), %r12
   12adc:      	movq	%r12, 0x30(%rsp)
   12ae1:      	movq	0x38(%rsp), %rdx
   12ae6:      	movq	0x40(%rsp), %r15
   12aeb:      	jmp	0x12b3e <generic_usdt_path+0x823e>
   12aed:      	leaq	0x10(%r15), %rdx
   12af1:      	movl	$0x4, %eax
   12af6:      	movq	%rbp, %rdi
   12af9:      	movl	$0x8, %esi
   12afe:      	callq	*%rax
   12b00:      	movq	0x40(%rsp), %rax
   12b05:      	cmpq	(%rsp), %rax
   12b09:      	je	0x1636d <generic_usdt_path+0xba6d>
   12b0f:      	addq	$0x18, %r15
   12b13:      	movl	$0x4, %eax
   12b18:      	leaq	0x30(%rsp), %rdi
   12b1d:      	movl	$0x8, %esi
   12b22:      	movq	%r15, %rdx
   12b25:      	callq	*%rax
   12b27:      	movq	(%rsp), %r15
   12b2b:      	movq	%r15, 0x40(%rsp)
   12b30:      	leaq	0x20(%r15), %rdx
   12b34:      	movq	%rdx, 0x38(%rsp)
   12b39:      	movq	0x30(%rsp), %r12
   12b3e:      	cmpq	0x18(%rsp), %r12
   12b43:      	jne	0x12b50 <generic_usdt_path+0x8250>
   12b45:      	cmpq	0x20(%rsp), %rdx
   12b4a:      	je	0x1636d <generic_usdt_path+0xba6d>
   12b50:      	movl	$0x4, %eax
   12b55:      	leaq	0x10(%rsp), %rdi
   12b5a:      	movl	$0x8, %esi
   12b5f:      	callq	*%rax
   12b61:      	cmpq	0x10(%rsp), %r12
   12b66:      	je	0x12c5e <generic_usdt_path+0x835e>
   12b6c:      	leaq	0x18(%r12), %rbx
   12b71:      	movl	$0x4, %eax
   12b76:      	movq	%rbp, %rdi
   12b79:      	movl	$0x8, %esi
   12b7e:      	movq	%rbx, %rdx
   12b81:      	callq	*%rax
   12b83:      	cmpq	%r12, (%rsp)
   12b87:      	je	0x12c5e <generic_usdt_path+0x835e>
   12b8d:      	movl	$0x4, %eax
   12b92:      	leaq	0x8(%rsp), %rdi
   12b97:      	movl	$0x8, %esi
   12b9c:      	movq	%rbx, %rdx
   12b9f:      	callq	*%rax
   12ba1:      	addq	$0x20, %r12
   12ba5:      	movl	$0x4, %eax
   12baa:      	leaq	0x58(%rsp), %rdi
   12baf:      	movl	$0x10, %ecx
   12bb4:      	movl	$0x10, %esi
   12bb9:      	movq	%r12, %rdx
   12bbc:      	callq	*%rax
   12bbe:      	movq	0x28(%rsp), %rbx
   12bc3:      	movq	0x48(%rsp), %rax
   12bc8:      	movl	0x5c(%rsp), %r15d
   12bcd:      	subq	%rbx, %rax
   12bd0:      	movl	0x50(%rsp), %r12d
   12bd5:      	movl	%r15d, %edx
   12bd8:      	subl	%r12d, %edx
   12bdb:      	movl	$0x0, %ecx
   12be0:      	cmovbl	%ecx, %edx
   12be3:      	addq	0x60(%rsp), %rdx
   12be8:      	xorl	%esi, %esi
   12bea:      	cmpl	%r15d, %r12d
   12bed:      	seta	%sil
   12bf1:      	movl	%r15d, %ecx
   12bf4:      	cmovbl	%r12d, %ecx
   12bf8:      	addl	%ecx, %esi
   12bfa:      	movl	%r12d, %edi
   12bfd:      	subl	%esi, %edi
   12bff:      	movl	%edi, 0x50(%rsp)
   12c03:      	subq	%rsi, %rax
   12c06:      	jb	0x16372 <generic_usdt_path+0xba72>
   12c0c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12c12:      	ja	0x16372 <generic_usdt_path+0xba72>
   12c18:      	cmpl	%r15d, %r12d
   12c1b:      	jbe	0x12c21 <generic_usdt_path+0x8321>
   12c1d:      	movb	$0x2f, (%rbx,%rax)
   12c21:      	xorl	%edi, %edi
   12c23:      	cmpl	%r15d, %r12d
   12c26:      	seta	%dil
   12c2a:      	movzbl	%cl, %esi
   12c2d:      	addq	%rax, %rbx
   12c30:      	addq	%rbx, %rdi
   12c33:      	movl	$0x4, %eax
   12c38:      	callq	*%rax
   12c3a:      	movq	%rbx, 0x48(%rsp)
   12c3f:      	cmpl	%r15d, %r12d
   12c42:      	jbe	0x16372 <generic_usdt_path+0xba72>
   12c48:      	movq	0x8(%rsp), %r12
   12c4d:      	movq	%r12, 0x30(%rsp)
   12c52:      	movq	0x38(%rsp), %rdx
   12c57:      	movq	0x40(%rsp), %r15
   12c5c:      	jmp	0x12caf <generic_usdt_path+0x83af>
   12c5e:      	leaq	0x10(%r15), %rdx
   12c62:      	movl	$0x4, %eax
   12c67:      	movq	%rbp, %rdi
   12c6a:      	movl	$0x8, %esi
   12c6f:      	callq	*%rax
   12c71:      	movq	0x40(%rsp), %rax
   12c76:      	cmpq	(%rsp), %rax
   12c7a:      	je	0x1636d <generic_usdt_path+0xba6d>
   12c80:      	addq	$0x18, %r15
   12c84:      	movl	$0x4, %eax
   12c89:      	leaq	0x30(%rsp), %rdi
   12c8e:      	movl	$0x8, %esi
   12c93:      	movq	%r15, %rdx
   12c96:      	callq	*%rax
   12c98:      	movq	(%rsp), %r15
   12c9c:      	movq	%r15, 0x40(%rsp)
   12ca1:      	leaq	0x20(%r15), %rdx
   12ca5:      	movq	%rdx, 0x38(%rsp)
   12caa:      	movq	0x30(%rsp), %r12
   12caf:      	cmpq	0x18(%rsp), %r12
   12cb4:      	jne	0x12cc1 <generic_usdt_path+0x83c1>
   12cb6:      	cmpq	0x20(%rsp), %rdx
   12cbb:      	je	0x1636d <generic_usdt_path+0xba6d>
   12cc1:      	movl	$0x4, %eax
   12cc6:      	leaq	0x10(%rsp), %rdi
   12ccb:      	movl	$0x8, %esi
   12cd0:      	callq	*%rax
   12cd2:      	cmpq	0x10(%rsp), %r12
   12cd7:      	je	0x12dcf <generic_usdt_path+0x84cf>
   12cdd:      	leaq	0x18(%r12), %rbx
   12ce2:      	movl	$0x4, %eax
   12ce7:      	movq	%rbp, %rdi
   12cea:      	movl	$0x8, %esi
   12cef:      	movq	%rbx, %rdx
   12cf2:      	callq	*%rax
   12cf4:      	cmpq	%r12, (%rsp)
   12cf8:      	je	0x12dcf <generic_usdt_path+0x84cf>
   12cfe:      	movl	$0x4, %eax
   12d03:      	leaq	0x8(%rsp), %rdi
   12d08:      	movl	$0x8, %esi
   12d0d:      	movq	%rbx, %rdx
   12d10:      	callq	*%rax
   12d12:      	addq	$0x20, %r12
   12d16:      	movl	$0x4, %eax
   12d1b:      	leaq	0x58(%rsp), %rdi
   12d20:      	movl	$0x10, %ecx
   12d25:      	movl	$0x10, %esi
   12d2a:      	movq	%r12, %rdx
   12d2d:      	callq	*%rax
   12d2f:      	movq	0x28(%rsp), %rbx
   12d34:      	movq	0x48(%rsp), %rax
   12d39:      	movl	0x5c(%rsp), %r15d
   12d3e:      	subq	%rbx, %rax
   12d41:      	movl	0x50(%rsp), %r12d
   12d46:      	movl	%r15d, %edx
   12d49:      	subl	%r12d, %edx
   12d4c:      	movl	$0x0, %ecx
   12d51:      	cmovbl	%ecx, %edx
   12d54:      	addq	0x60(%rsp), %rdx
   12d59:      	xorl	%esi, %esi
   12d5b:      	cmpl	%r15d, %r12d
   12d5e:      	seta	%sil
   12d62:      	movl	%r15d, %ecx
   12d65:      	cmovbl	%r12d, %ecx
   12d69:      	addl	%ecx, %esi
   12d6b:      	movl	%r12d, %edi
   12d6e:      	subl	%esi, %edi
   12d70:      	movl	%edi, 0x50(%rsp)
   12d74:      	subq	%rsi, %rax
   12d77:      	jb	0x16372 <generic_usdt_path+0xba72>
   12d7d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12d83:      	ja	0x16372 <generic_usdt_path+0xba72>
   12d89:      	cmpl	%r15d, %r12d
   12d8c:      	jbe	0x12d92 <generic_usdt_path+0x8492>
   12d8e:      	movb	$0x2f, (%rbx,%rax)
   12d92:      	xorl	%edi, %edi
   12d94:      	cmpl	%r15d, %r12d
   12d97:      	seta	%dil
   12d9b:      	movzbl	%cl, %esi
   12d9e:      	addq	%rax, %rbx
   12da1:      	addq	%rbx, %rdi
   12da4:      	movl	$0x4, %eax
   12da9:      	callq	*%rax
   12dab:      	movq	%rbx, 0x48(%rsp)
   12db0:      	cmpl	%r15d, %r12d
   12db3:      	jbe	0x16372 <generic_usdt_path+0xba72>
   12db9:      	movq	0x8(%rsp), %r12
   12dbe:      	movq	%r12, 0x30(%rsp)
   12dc3:      	movq	0x38(%rsp), %rdx
   12dc8:      	movq	0x40(%rsp), %r15
   12dcd:      	jmp	0x12e20 <generic_usdt_path+0x8520>
   12dcf:      	leaq	0x10(%r15), %rdx
   12dd3:      	movl	$0x4, %eax
   12dd8:      	movq	%rbp, %rdi
   12ddb:      	movl	$0x8, %esi
   12de0:      	callq	*%rax
   12de2:      	movq	0x40(%rsp), %rax
   12de7:      	cmpq	(%rsp), %rax
   12deb:      	je	0x1636d <generic_usdt_path+0xba6d>
   12df1:      	addq	$0x18, %r15
   12df5:      	movl	$0x4, %eax
   12dfa:      	leaq	0x30(%rsp), %rdi
   12dff:      	movl	$0x8, %esi
   12e04:      	movq	%r15, %rdx
   12e07:      	callq	*%rax
   12e09:      	movq	(%rsp), %r15
   12e0d:      	movq	%r15, 0x40(%rsp)
   12e12:      	leaq	0x20(%r15), %rdx
   12e16:      	movq	%rdx, 0x38(%rsp)
   12e1b:      	movq	0x30(%rsp), %r12
   12e20:      	cmpq	0x18(%rsp), %r12
   12e25:      	jne	0x12e32 <generic_usdt_path+0x8532>
   12e27:      	cmpq	0x20(%rsp), %rdx
   12e2c:      	je	0x1636d <generic_usdt_path+0xba6d>
   12e32:      	movl	$0x4, %eax
   12e37:      	leaq	0x10(%rsp), %rdi
   12e3c:      	movl	$0x8, %esi
   12e41:      	callq	*%rax
   12e43:      	cmpq	0x10(%rsp), %r12
   12e48:      	je	0x12f40 <generic_usdt_path+0x8640>
   12e4e:      	leaq	0x18(%r12), %rbx
   12e53:      	movl	$0x4, %eax
   12e58:      	movq	%rbp, %rdi
   12e5b:      	movl	$0x8, %esi
   12e60:      	movq	%rbx, %rdx
   12e63:      	callq	*%rax
   12e65:      	cmpq	%r12, (%rsp)
   12e69:      	je	0x12f40 <generic_usdt_path+0x8640>
   12e6f:      	movl	$0x4, %eax
   12e74:      	leaq	0x8(%rsp), %rdi
   12e79:      	movl	$0x8, %esi
   12e7e:      	movq	%rbx, %rdx
   12e81:      	callq	*%rax
   12e83:      	addq	$0x20, %r12
   12e87:      	movl	$0x4, %eax
   12e8c:      	leaq	0x58(%rsp), %rdi
   12e91:      	movl	$0x10, %ecx
   12e96:      	movl	$0x10, %esi
   12e9b:      	movq	%r12, %rdx
   12e9e:      	callq	*%rax
   12ea0:      	movq	0x28(%rsp), %rbx
   12ea5:      	movq	0x48(%rsp), %rax
   12eaa:      	movl	0x5c(%rsp), %r15d
   12eaf:      	subq	%rbx, %rax
   12eb2:      	movl	0x50(%rsp), %r12d
   12eb7:      	movl	%r15d, %edx
   12eba:      	subl	%r12d, %edx
   12ebd:      	movl	$0x0, %ecx
   12ec2:      	cmovbl	%ecx, %edx
   12ec5:      	addq	0x60(%rsp), %rdx
   12eca:      	xorl	%esi, %esi
   12ecc:      	cmpl	%r15d, %r12d
   12ecf:      	seta	%sil
   12ed3:      	movl	%r15d, %ecx
   12ed6:      	cmovbl	%r12d, %ecx
   12eda:      	addl	%ecx, %esi
   12edc:      	movl	%r12d, %edi
   12edf:      	subl	%esi, %edi
   12ee1:      	movl	%edi, 0x50(%rsp)
   12ee5:      	subq	%rsi, %rax
   12ee8:      	jb	0x16372 <generic_usdt_path+0xba72>
   12eee:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   12ef4:      	ja	0x16372 <generic_usdt_path+0xba72>
   12efa:      	cmpl	%r15d, %r12d
   12efd:      	jbe	0x12f03 <generic_usdt_path+0x8603>
   12eff:      	movb	$0x2f, (%rbx,%rax)
   12f03:      	xorl	%edi, %edi
   12f05:      	cmpl	%r15d, %r12d
   12f08:      	seta	%dil
   12f0c:      	movzbl	%cl, %esi
   12f0f:      	addq	%rax, %rbx
   12f12:      	addq	%rbx, %rdi
   12f15:      	movl	$0x4, %eax
   12f1a:      	callq	*%rax
   12f1c:      	movq	%rbx, 0x48(%rsp)
   12f21:      	cmpl	%r15d, %r12d
   12f24:      	jbe	0x16372 <generic_usdt_path+0xba72>
   12f2a:      	movq	0x8(%rsp), %r12
   12f2f:      	movq	%r12, 0x30(%rsp)
   12f34:      	movq	0x38(%rsp), %rdx
   12f39:      	movq	0x40(%rsp), %r15
   12f3e:      	jmp	0x12f91 <generic_usdt_path+0x8691>
   12f40:      	leaq	0x10(%r15), %rdx
   12f44:      	movl	$0x4, %eax
   12f49:      	movq	%rbp, %rdi
   12f4c:      	movl	$0x8, %esi
   12f51:      	callq	*%rax
   12f53:      	movq	0x40(%rsp), %rax
   12f58:      	cmpq	(%rsp), %rax
   12f5c:      	je	0x1636d <generic_usdt_path+0xba6d>
   12f62:      	addq	$0x18, %r15
   12f66:      	movl	$0x4, %eax
   12f6b:      	leaq	0x30(%rsp), %rdi
   12f70:      	movl	$0x8, %esi
   12f75:      	movq	%r15, %rdx
   12f78:      	callq	*%rax
   12f7a:      	movq	(%rsp), %r15
   12f7e:      	movq	%r15, 0x40(%rsp)
   12f83:      	leaq	0x20(%r15), %rdx
   12f87:      	movq	%rdx, 0x38(%rsp)
   12f8c:      	movq	0x30(%rsp), %r12
   12f91:      	cmpq	0x18(%rsp), %r12
   12f96:      	jne	0x12fa3 <generic_usdt_path+0x86a3>
   12f98:      	cmpq	0x20(%rsp), %rdx
   12f9d:      	je	0x1636d <generic_usdt_path+0xba6d>
   12fa3:      	movl	$0x4, %eax
   12fa8:      	leaq	0x10(%rsp), %rdi
   12fad:      	movl	$0x8, %esi
   12fb2:      	callq	*%rax
   12fb4:      	cmpq	0x10(%rsp), %r12
   12fb9:      	je	0x130b1 <generic_usdt_path+0x87b1>
   12fbf:      	leaq	0x18(%r12), %rbx
   12fc4:      	movl	$0x4, %eax
   12fc9:      	movq	%rbp, %rdi
   12fcc:      	movl	$0x8, %esi
   12fd1:      	movq	%rbx, %rdx
   12fd4:      	callq	*%rax
   12fd6:      	cmpq	%r12, (%rsp)
   12fda:      	je	0x130b1 <generic_usdt_path+0x87b1>
   12fe0:      	movl	$0x4, %eax
   12fe5:      	leaq	0x8(%rsp), %rdi
   12fea:      	movl	$0x8, %esi
   12fef:      	movq	%rbx, %rdx
   12ff2:      	callq	*%rax
   12ff4:      	addq	$0x20, %r12
   12ff8:      	movl	$0x4, %eax
   12ffd:      	leaq	0x58(%rsp), %rdi
   13002:      	movl	$0x10, %ecx
   13007:      	movl	$0x10, %esi
   1300c:      	movq	%r12, %rdx
   1300f:      	callq	*%rax
   13011:      	movq	0x28(%rsp), %rbx
   13016:      	movq	0x48(%rsp), %rax
   1301b:      	movl	0x5c(%rsp), %r15d
   13020:      	subq	%rbx, %rax
   13023:      	movl	0x50(%rsp), %r12d
   13028:      	movl	%r15d, %edx
   1302b:      	subl	%r12d, %edx
   1302e:      	movl	$0x0, %ecx
   13033:      	cmovbl	%ecx, %edx
   13036:      	addq	0x60(%rsp), %rdx
   1303b:      	xorl	%esi, %esi
   1303d:      	cmpl	%r15d, %r12d
   13040:      	seta	%sil
   13044:      	movl	%r15d, %ecx
   13047:      	cmovbl	%r12d, %ecx
   1304b:      	addl	%ecx, %esi
   1304d:      	movl	%r12d, %edi
   13050:      	subl	%esi, %edi
   13052:      	movl	%edi, 0x50(%rsp)
   13056:      	subq	%rsi, %rax
   13059:      	jb	0x16372 <generic_usdt_path+0xba72>
   1305f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13065:      	ja	0x16372 <generic_usdt_path+0xba72>
   1306b:      	cmpl	%r15d, %r12d
   1306e:      	jbe	0x13074 <generic_usdt_path+0x8774>
   13070:      	movb	$0x2f, (%rbx,%rax)
   13074:      	xorl	%edi, %edi
   13076:      	cmpl	%r15d, %r12d
   13079:      	seta	%dil
   1307d:      	movzbl	%cl, %esi
   13080:      	addq	%rax, %rbx
   13083:      	addq	%rbx, %rdi
   13086:      	movl	$0x4, %eax
   1308b:      	callq	*%rax
   1308d:      	movq	%rbx, 0x48(%rsp)
   13092:      	cmpl	%r15d, %r12d
   13095:      	jbe	0x16372 <generic_usdt_path+0xba72>
   1309b:      	movq	0x8(%rsp), %r12
   130a0:      	movq	%r12, 0x30(%rsp)
   130a5:      	movq	0x38(%rsp), %rdx
   130aa:      	movq	0x40(%rsp), %r15
   130af:      	jmp	0x13102 <generic_usdt_path+0x8802>
   130b1:      	leaq	0x10(%r15), %rdx
   130b5:      	movl	$0x4, %eax
   130ba:      	movq	%rbp, %rdi
   130bd:      	movl	$0x8, %esi
   130c2:      	callq	*%rax
   130c4:      	movq	0x40(%rsp), %rax
   130c9:      	cmpq	(%rsp), %rax
   130cd:      	je	0x1636d <generic_usdt_path+0xba6d>
   130d3:      	addq	$0x18, %r15
   130d7:      	movl	$0x4, %eax
   130dc:      	leaq	0x30(%rsp), %rdi
   130e1:      	movl	$0x8, %esi
   130e6:      	movq	%r15, %rdx
   130e9:      	callq	*%rax
   130eb:      	movq	(%rsp), %r15
   130ef:      	movq	%r15, 0x40(%rsp)
   130f4:      	leaq	0x20(%r15), %rdx
   130f8:      	movq	%rdx, 0x38(%rsp)
   130fd:      	movq	0x30(%rsp), %r12
   13102:      	cmpq	0x18(%rsp), %r12
   13107:      	jne	0x13114 <generic_usdt_path+0x8814>
   13109:      	cmpq	0x20(%rsp), %rdx
   1310e:      	je	0x1636d <generic_usdt_path+0xba6d>
   13114:      	movl	$0x4, %eax
   13119:      	leaq	0x10(%rsp), %rdi
   1311e:      	movl	$0x8, %esi
   13123:      	callq	*%rax
   13125:      	cmpq	0x10(%rsp), %r12
   1312a:      	je	0x13222 <generic_usdt_path+0x8922>
   13130:      	leaq	0x18(%r12), %rbx
   13135:      	movl	$0x4, %eax
   1313a:      	movq	%rbp, %rdi
   1313d:      	movl	$0x8, %esi
   13142:      	movq	%rbx, %rdx
   13145:      	callq	*%rax
   13147:      	cmpq	%r12, (%rsp)
   1314b:      	je	0x13222 <generic_usdt_path+0x8922>
   13151:      	movl	$0x4, %eax
   13156:      	leaq	0x8(%rsp), %rdi
   1315b:      	movl	$0x8, %esi
   13160:      	movq	%rbx, %rdx
   13163:      	callq	*%rax
   13165:      	addq	$0x20, %r12
   13169:      	movl	$0x4, %eax
   1316e:      	leaq	0x58(%rsp), %rdi
   13173:      	movl	$0x10, %ecx
   13178:      	movl	$0x10, %esi
   1317d:      	movq	%r12, %rdx
   13180:      	callq	*%rax
   13182:      	movq	0x28(%rsp), %rbx
   13187:      	movq	0x48(%rsp), %rax
   1318c:      	movl	0x5c(%rsp), %r15d
   13191:      	subq	%rbx, %rax
   13194:      	movl	0x50(%rsp), %r12d
   13199:      	movl	%r15d, %edx
   1319c:      	subl	%r12d, %edx
   1319f:      	movl	$0x0, %ecx
   131a4:      	cmovbl	%ecx, %edx
   131a7:      	addq	0x60(%rsp), %rdx
   131ac:      	xorl	%esi, %esi
   131ae:      	cmpl	%r15d, %r12d
   131b1:      	seta	%sil
   131b5:      	movl	%r15d, %ecx
   131b8:      	cmovbl	%r12d, %ecx
   131bc:      	addl	%ecx, %esi
   131be:      	movl	%r12d, %edi
   131c1:      	subl	%esi, %edi
   131c3:      	movl	%edi, 0x50(%rsp)
   131c7:      	subq	%rsi, %rax
   131ca:      	jb	0x16372 <generic_usdt_path+0xba72>
   131d0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   131d6:      	ja	0x16372 <generic_usdt_path+0xba72>
   131dc:      	cmpl	%r15d, %r12d
   131df:      	jbe	0x131e5 <generic_usdt_path+0x88e5>
   131e1:      	movb	$0x2f, (%rbx,%rax)
   131e5:      	xorl	%edi, %edi
   131e7:      	cmpl	%r15d, %r12d
   131ea:      	seta	%dil
   131ee:      	movzbl	%cl, %esi
   131f1:      	addq	%rax, %rbx
   131f4:      	addq	%rbx, %rdi
   131f7:      	movl	$0x4, %eax
   131fc:      	callq	*%rax
   131fe:      	movq	%rbx, 0x48(%rsp)
   13203:      	cmpl	%r15d, %r12d
   13206:      	jbe	0x16372 <generic_usdt_path+0xba72>
   1320c:      	movq	0x8(%rsp), %r12
   13211:      	movq	%r12, 0x30(%rsp)
   13216:      	movq	0x38(%rsp), %rdx
   1321b:      	movq	0x40(%rsp), %r15
   13220:      	jmp	0x13273 <generic_usdt_path+0x8973>
   13222:      	leaq	0x10(%r15), %rdx
   13226:      	movl	$0x4, %eax
   1322b:      	movq	%rbp, %rdi
   1322e:      	movl	$0x8, %esi
   13233:      	callq	*%rax
   13235:      	movq	0x40(%rsp), %rax
   1323a:      	cmpq	(%rsp), %rax
   1323e:      	je	0x1636d <generic_usdt_path+0xba6d>
   13244:      	addq	$0x18, %r15
   13248:      	movl	$0x4, %eax
   1324d:      	leaq	0x30(%rsp), %rdi
   13252:      	movl	$0x8, %esi
   13257:      	movq	%r15, %rdx
   1325a:      	callq	*%rax
   1325c:      	movq	(%rsp), %r15
   13260:      	movq	%r15, 0x40(%rsp)
   13265:      	leaq	0x20(%r15), %rdx
   13269:      	movq	%rdx, 0x38(%rsp)
   1326e:      	movq	0x30(%rsp), %r12
   13273:      	cmpq	0x18(%rsp), %r12
   13278:      	jne	0x13285 <generic_usdt_path+0x8985>
   1327a:      	cmpq	0x20(%rsp), %rdx
   1327f:      	je	0x1636d <generic_usdt_path+0xba6d>
   13285:      	movl	$0x4, %eax
   1328a:      	leaq	0x10(%rsp), %rdi
   1328f:      	movl	$0x8, %esi
   13294:      	callq	*%rax
   13296:      	cmpq	0x10(%rsp), %r12
   1329b:      	je	0x13393 <generic_usdt_path+0x8a93>
   132a1:      	leaq	0x18(%r12), %rbx
   132a6:      	movl	$0x4, %eax
   132ab:      	movq	%rbp, %rdi
   132ae:      	movl	$0x8, %esi
   132b3:      	movq	%rbx, %rdx
   132b6:      	callq	*%rax
   132b8:      	cmpq	%r12, (%rsp)
   132bc:      	je	0x13393 <generic_usdt_path+0x8a93>
   132c2:      	movl	$0x4, %eax
   132c7:      	leaq	0x8(%rsp), %rdi
   132cc:      	movl	$0x8, %esi
   132d1:      	movq	%rbx, %rdx
   132d4:      	callq	*%rax
   132d6:      	addq	$0x20, %r12
   132da:      	movl	$0x4, %eax
   132df:      	leaq	0x58(%rsp), %rdi
   132e4:      	movl	$0x10, %ecx
   132e9:      	movl	$0x10, %esi
   132ee:      	movq	%r12, %rdx
   132f1:      	callq	*%rax
   132f3:      	movq	0x28(%rsp), %rbx
   132f8:      	movq	0x48(%rsp), %rax
   132fd:      	movl	0x5c(%rsp), %r15d
   13302:      	subq	%rbx, %rax
   13305:      	movl	0x50(%rsp), %r12d
   1330a:      	movl	%r15d, %edx
   1330d:      	subl	%r12d, %edx
   13310:      	movl	$0x0, %ecx
   13315:      	cmovbl	%ecx, %edx
   13318:      	addq	0x60(%rsp), %rdx
   1331d:      	xorl	%esi, %esi
   1331f:      	cmpl	%r15d, %r12d
   13322:      	seta	%sil
   13326:      	movl	%r15d, %ecx
   13329:      	cmovbl	%r12d, %ecx
   1332d:      	addl	%ecx, %esi
   1332f:      	movl	%r12d, %edi
   13332:      	subl	%esi, %edi
   13334:      	movl	%edi, 0x50(%rsp)
   13338:      	subq	%rsi, %rax
   1333b:      	jb	0x16372 <generic_usdt_path+0xba72>
   13341:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13347:      	ja	0x16372 <generic_usdt_path+0xba72>
   1334d:      	cmpl	%r15d, %r12d
   13350:      	jbe	0x13356 <generic_usdt_path+0x8a56>
   13352:      	movb	$0x2f, (%rbx,%rax)
   13356:      	xorl	%edi, %edi
   13358:      	cmpl	%r15d, %r12d
   1335b:      	seta	%dil
   1335f:      	movzbl	%cl, %esi
   13362:      	addq	%rax, %rbx
   13365:      	addq	%rbx, %rdi
   13368:      	movl	$0x4, %eax
   1336d:      	callq	*%rax
   1336f:      	movq	%rbx, 0x48(%rsp)
   13374:      	cmpl	%r15d, %r12d
   13377:      	jbe	0x16372 <generic_usdt_path+0xba72>
   1337d:      	movq	0x8(%rsp), %r12
   13382:      	movq	%r12, 0x30(%rsp)
   13387:      	movq	0x38(%rsp), %rdx
   1338c:      	movq	0x40(%rsp), %r15
   13391:      	jmp	0x133e4 <generic_usdt_path+0x8ae4>
   13393:      	leaq	0x10(%r15), %rdx
   13397:      	movl	$0x4, %eax
   1339c:      	movq	%rbp, %rdi
   1339f:      	movl	$0x8, %esi
   133a4:      	callq	*%rax
   133a6:      	movq	0x40(%rsp), %rax
   133ab:      	cmpq	(%rsp), %rax
   133af:      	je	0x1636d <generic_usdt_path+0xba6d>
   133b5:      	addq	$0x18, %r15
   133b9:      	movl	$0x4, %eax
   133be:      	leaq	0x30(%rsp), %rdi
   133c3:      	movl	$0x8, %esi
   133c8:      	movq	%r15, %rdx
   133cb:      	callq	*%rax
   133cd:      	movq	(%rsp), %r15
   133d1:      	movq	%r15, 0x40(%rsp)
   133d6:      	leaq	0x20(%r15), %rdx
   133da:      	movq	%rdx, 0x38(%rsp)
   133df:      	movq	0x30(%rsp), %r12
   133e4:      	cmpq	0x18(%rsp), %r12
   133e9:      	jne	0x133f6 <generic_usdt_path+0x8af6>
   133eb:      	cmpq	0x20(%rsp), %rdx
   133f0:      	je	0x1636d <generic_usdt_path+0xba6d>
   133f6:      	movl	$0x4, %eax
   133fb:      	leaq	0x10(%rsp), %rdi
   13400:      	movl	$0x8, %esi
   13405:      	callq	*%rax
   13407:      	cmpq	0x10(%rsp), %r12
   1340c:      	je	0x13504 <generic_usdt_path+0x8c04>
   13412:      	leaq	0x18(%r12), %rbx
   13417:      	movl	$0x4, %eax
   1341c:      	movq	%rbp, %rdi
   1341f:      	movl	$0x8, %esi
   13424:      	movq	%rbx, %rdx
   13427:      	callq	*%rax
   13429:      	cmpq	%r12, (%rsp)
   1342d:      	je	0x13504 <generic_usdt_path+0x8c04>
   13433:      	movl	$0x4, %eax
   13438:      	leaq	0x8(%rsp), %rdi
   1343d:      	movl	$0x8, %esi
   13442:      	movq	%rbx, %rdx
   13445:      	callq	*%rax
   13447:      	addq	$0x20, %r12
   1344b:      	movl	$0x4, %eax
   13450:      	leaq	0x58(%rsp), %rdi
   13455:      	movl	$0x10, %ecx
   1345a:      	movl	$0x10, %esi
   1345f:      	movq	%r12, %rdx
   13462:      	callq	*%rax
   13464:      	movq	0x28(%rsp), %rbx
   13469:      	movq	0x48(%rsp), %rax
   1346e:      	movl	0x5c(%rsp), %r15d
   13473:      	subq	%rbx, %rax
   13476:      	movl	0x50(%rsp), %r12d
   1347b:      	movl	%r15d, %edx
   1347e:      	subl	%r12d, %edx
   13481:      	movl	$0x0, %ecx
   13486:      	cmovbl	%ecx, %edx
   13489:      	addq	0x60(%rsp), %rdx
   1348e:      	xorl	%esi, %esi
   13490:      	cmpl	%r15d, %r12d
   13493:      	seta	%sil
   13497:      	movl	%r15d, %ecx
   1349a:      	cmovbl	%r12d, %ecx
   1349e:      	addl	%ecx, %esi
   134a0:      	movl	%r12d, %edi
   134a3:      	subl	%esi, %edi
   134a5:      	movl	%edi, 0x50(%rsp)
   134a9:      	subq	%rsi, %rax
   134ac:      	jb	0x16372 <generic_usdt_path+0xba72>
   134b2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   134b8:      	ja	0x16372 <generic_usdt_path+0xba72>
   134be:      	cmpl	%r15d, %r12d
   134c1:      	jbe	0x134c7 <generic_usdt_path+0x8bc7>
   134c3:      	movb	$0x2f, (%rbx,%rax)
   134c7:      	xorl	%edi, %edi
   134c9:      	cmpl	%r15d, %r12d
   134cc:      	seta	%dil
   134d0:      	movzbl	%cl, %esi
   134d3:      	addq	%rax, %rbx
   134d6:      	addq	%rbx, %rdi
   134d9:      	movl	$0x4, %eax
   134de:      	callq	*%rax
   134e0:      	movq	%rbx, 0x48(%rsp)
   134e5:      	cmpl	%r15d, %r12d
   134e8:      	jbe	0x16372 <generic_usdt_path+0xba72>
   134ee:      	movq	0x8(%rsp), %r12
   134f3:      	movq	%r12, 0x30(%rsp)
   134f8:      	movq	0x38(%rsp), %rdx
   134fd:      	movq	0x40(%rsp), %r15
   13502:      	jmp	0x13555 <generic_usdt_path+0x8c55>
   13504:      	leaq	0x10(%r15), %rdx
   13508:      	movl	$0x4, %eax
   1350d:      	movq	%rbp, %rdi
   13510:      	movl	$0x8, %esi
   13515:      	callq	*%rax
   13517:      	movq	0x40(%rsp), %rax
   1351c:      	cmpq	(%rsp), %rax
   13520:      	je	0x1636d <generic_usdt_path+0xba6d>
   13526:      	addq	$0x18, %r15
   1352a:      	movl	$0x4, %eax
   1352f:      	leaq	0x30(%rsp), %rdi
   13534:      	movl	$0x8, %esi
   13539:      	movq	%r15, %rdx
   1353c:      	callq	*%rax
   1353e:      	movq	(%rsp), %r15
   13542:      	movq	%r15, 0x40(%rsp)
   13547:      	leaq	0x20(%r15), %rdx
   1354b:      	movq	%rdx, 0x38(%rsp)
   13550:      	movq	0x30(%rsp), %r12
   13555:      	cmpq	0x18(%rsp), %r12
   1355a:      	jne	0x13567 <generic_usdt_path+0x8c67>
   1355c:      	cmpq	0x20(%rsp), %rdx
   13561:      	je	0x1636d <generic_usdt_path+0xba6d>
   13567:      	movl	$0x4, %eax
   1356c:      	leaq	0x10(%rsp), %rdi
   13571:      	movl	$0x8, %esi
   13576:      	callq	*%rax
   13578:      	cmpq	0x10(%rsp), %r12
   1357d:      	je	0x13675 <generic_usdt_path+0x8d75>
   13583:      	leaq	0x18(%r12), %rbx
   13588:      	movl	$0x4, %eax
   1358d:      	movq	%rbp, %rdi
   13590:      	movl	$0x8, %esi
   13595:      	movq	%rbx, %rdx
   13598:      	callq	*%rax
   1359a:      	cmpq	%r12, (%rsp)
   1359e:      	je	0x13675 <generic_usdt_path+0x8d75>
   135a4:      	movl	$0x4, %eax
   135a9:      	leaq	0x8(%rsp), %rdi
   135ae:      	movl	$0x8, %esi
   135b3:      	movq	%rbx, %rdx
   135b6:      	callq	*%rax
   135b8:      	addq	$0x20, %r12
   135bc:      	movl	$0x4, %eax
   135c1:      	leaq	0x58(%rsp), %rdi
   135c6:      	movl	$0x10, %ecx
   135cb:      	movl	$0x10, %esi
   135d0:      	movq	%r12, %rdx
   135d3:      	callq	*%rax
   135d5:      	movq	0x28(%rsp), %rbx
   135da:      	movq	0x48(%rsp), %rax
   135df:      	movl	0x5c(%rsp), %r15d
   135e4:      	subq	%rbx, %rax
   135e7:      	movl	0x50(%rsp), %r12d
   135ec:      	movl	%r15d, %edx
   135ef:      	subl	%r12d, %edx
   135f2:      	movl	$0x0, %ecx
   135f7:      	cmovbl	%ecx, %edx
   135fa:      	addq	0x60(%rsp), %rdx
   135ff:      	xorl	%esi, %esi
   13601:      	cmpl	%r15d, %r12d
   13604:      	seta	%sil
   13608:      	movl	%r15d, %ecx
   1360b:      	cmovbl	%r12d, %ecx
   1360f:      	addl	%ecx, %esi
   13611:      	movl	%r12d, %edi
   13614:      	subl	%esi, %edi
   13616:      	movl	%edi, 0x50(%rsp)
   1361a:      	subq	%rsi, %rax
   1361d:      	jb	0x16372 <generic_usdt_path+0xba72>
   13623:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13629:      	ja	0x16372 <generic_usdt_path+0xba72>
   1362f:      	cmpl	%r15d, %r12d
   13632:      	jbe	0x13638 <generic_usdt_path+0x8d38>
   13634:      	movb	$0x2f, (%rbx,%rax)
   13638:      	xorl	%edi, %edi
   1363a:      	cmpl	%r15d, %r12d
   1363d:      	seta	%dil
   13641:      	movzbl	%cl, %esi
   13644:      	addq	%rax, %rbx
   13647:      	addq	%rbx, %rdi
   1364a:      	movl	$0x4, %eax
   1364f:      	callq	*%rax
   13651:      	movq	%rbx, 0x48(%rsp)
   13656:      	cmpl	%r15d, %r12d
   13659:      	jbe	0x16372 <generic_usdt_path+0xba72>
   1365f:      	movq	0x8(%rsp), %r12
   13664:      	movq	%r12, 0x30(%rsp)
   13669:      	movq	0x38(%rsp), %rdx
   1366e:      	movq	0x40(%rsp), %r15
   13673:      	jmp	0x136c6 <generic_usdt_path+0x8dc6>
   13675:      	leaq	0x10(%r15), %rdx
   13679:      	movl	$0x4, %eax
   1367e:      	movq	%rbp, %rdi
   13681:      	movl	$0x8, %esi
   13686:      	callq	*%rax
   13688:      	movq	0x40(%rsp), %rax
   1368d:      	cmpq	(%rsp), %rax
   13691:      	je	0x1636d <generic_usdt_path+0xba6d>
   13697:      	addq	$0x18, %r15
   1369b:      	movl	$0x4, %eax
   136a0:      	leaq	0x30(%rsp), %rdi
   136a5:      	movl	$0x8, %esi
   136aa:      	movq	%r15, %rdx
   136ad:      	callq	*%rax
   136af:      	movq	(%rsp), %r15
   136b3:      	movq	%r15, 0x40(%rsp)
   136b8:      	leaq	0x20(%r15), %rdx
   136bc:      	movq	%rdx, 0x38(%rsp)
   136c1:      	movq	0x30(%rsp), %r12
   136c6:      	cmpq	0x18(%rsp), %r12
   136cb:      	jne	0x136d8 <generic_usdt_path+0x8dd8>
   136cd:      	cmpq	0x20(%rsp), %rdx
   136d2:      	je	0x1636d <generic_usdt_path+0xba6d>
   136d8:      	movl	$0x4, %eax
   136dd:      	leaq	0x10(%rsp), %rdi
   136e2:      	movl	$0x8, %esi
   136e7:      	callq	*%rax
   136e9:      	cmpq	0x10(%rsp), %r12
   136ee:      	je	0x137e6 <generic_usdt_path+0x8ee6>
   136f4:      	leaq	0x18(%r12), %rbx
   136f9:      	movl	$0x4, %eax
   136fe:      	movq	%rbp, %rdi
   13701:      	movl	$0x8, %esi
   13706:      	movq	%rbx, %rdx
   13709:      	callq	*%rax
   1370b:      	cmpq	%r12, (%rsp)
   1370f:      	je	0x137e6 <generic_usdt_path+0x8ee6>
   13715:      	movl	$0x4, %eax
   1371a:      	leaq	0x8(%rsp), %rdi
   1371f:      	movl	$0x8, %esi
   13724:      	movq	%rbx, %rdx
   13727:      	callq	*%rax
   13729:      	addq	$0x20, %r12
   1372d:      	movl	$0x4, %eax
   13732:      	leaq	0x58(%rsp), %rdi
   13737:      	movl	$0x10, %ecx
   1373c:      	movl	$0x10, %esi
   13741:      	movq	%r12, %rdx
   13744:      	callq	*%rax
   13746:      	movq	0x28(%rsp), %rbx
   1374b:      	movq	0x48(%rsp), %rax
   13750:      	movl	0x5c(%rsp), %r15d
   13755:      	subq	%rbx, %rax
   13758:      	movl	0x50(%rsp), %r12d
   1375d:      	movl	%r15d, %edx
   13760:      	subl	%r12d, %edx
   13763:      	movl	$0x0, %ecx
   13768:      	cmovbl	%ecx, %edx
   1376b:      	addq	0x60(%rsp), %rdx
   13770:      	xorl	%esi, %esi
   13772:      	cmpl	%r15d, %r12d
   13775:      	seta	%sil
   13779:      	movl	%r15d, %ecx
   1377c:      	cmovbl	%r12d, %ecx
   13780:      	addl	%ecx, %esi
   13782:      	movl	%r12d, %edi
   13785:      	subl	%esi, %edi
   13787:      	movl	%edi, 0x50(%rsp)
   1378b:      	subq	%rsi, %rax
   1378e:      	jb	0x16372 <generic_usdt_path+0xba72>
   13794:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1379a:      	ja	0x16372 <generic_usdt_path+0xba72>
   137a0:      	cmpl	%r15d, %r12d
   137a3:      	jbe	0x137a9 <generic_usdt_path+0x8ea9>
   137a5:      	movb	$0x2f, (%rbx,%rax)
   137a9:      	xorl	%edi, %edi
   137ab:      	cmpl	%r15d, %r12d
   137ae:      	seta	%dil
   137b2:      	movzbl	%cl, %esi
   137b5:      	addq	%rax, %rbx
   137b8:      	addq	%rbx, %rdi
   137bb:      	movl	$0x4, %eax
   137c0:      	callq	*%rax
   137c2:      	movq	%rbx, 0x48(%rsp)
   137c7:      	cmpl	%r15d, %r12d
   137ca:      	jbe	0x16372 <generic_usdt_path+0xba72>
   137d0:      	movq	0x8(%rsp), %r12
   137d5:      	movq	%r12, 0x30(%rsp)
   137da:      	movq	0x38(%rsp), %rdx
   137df:      	movq	0x40(%rsp), %r15
   137e4:      	jmp	0x13837 <generic_usdt_path+0x8f37>
   137e6:      	leaq	0x10(%r15), %rdx
   137ea:      	movl	$0x4, %eax
   137ef:      	movq	%rbp, %rdi
   137f2:      	movl	$0x8, %esi
   137f7:      	callq	*%rax
   137f9:      	movq	0x40(%rsp), %rax
   137fe:      	cmpq	(%rsp), %rax
   13802:      	je	0x1636d <generic_usdt_path+0xba6d>
   13808:      	addq	$0x18, %r15
   1380c:      	movl	$0x4, %eax
   13811:      	leaq	0x30(%rsp), %rdi
   13816:      	movl	$0x8, %esi
   1381b:      	movq	%r15, %rdx
   1381e:      	callq	*%rax
   13820:      	movq	(%rsp), %r15
   13824:      	movq	%r15, 0x40(%rsp)
   13829:      	leaq	0x20(%r15), %rdx
   1382d:      	movq	%rdx, 0x38(%rsp)
   13832:      	movq	0x30(%rsp), %r12
   13837:      	cmpq	0x18(%rsp), %r12
   1383c:      	jne	0x13849 <generic_usdt_path+0x8f49>
   1383e:      	cmpq	0x20(%rsp), %rdx
   13843:      	je	0x1636d <generic_usdt_path+0xba6d>
   13849:      	movl	$0x4, %eax
   1384e:      	leaq	0x10(%rsp), %rdi
   13853:      	movl	$0x8, %esi
   13858:      	callq	*%rax
   1385a:      	cmpq	0x10(%rsp), %r12
   1385f:      	je	0x13957 <generic_usdt_path+0x9057>
   13865:      	leaq	0x18(%r12), %rbx
   1386a:      	movl	$0x4, %eax
   1386f:      	movq	%rbp, %rdi
   13872:      	movl	$0x8, %esi
   13877:      	movq	%rbx, %rdx
   1387a:      	callq	*%rax
   1387c:      	cmpq	%r12, (%rsp)
   13880:      	je	0x13957 <generic_usdt_path+0x9057>
   13886:      	movl	$0x4, %eax
   1388b:      	leaq	0x8(%rsp), %rdi
   13890:      	movl	$0x8, %esi
   13895:      	movq	%rbx, %rdx
   13898:      	callq	*%rax
   1389a:      	addq	$0x20, %r12
   1389e:      	movl	$0x4, %eax
   138a3:      	leaq	0x58(%rsp), %rdi
   138a8:      	movl	$0x10, %ecx
   138ad:      	movl	$0x10, %esi
   138b2:      	movq	%r12, %rdx
   138b5:      	callq	*%rax
   138b7:      	movq	0x28(%rsp), %rbx
   138bc:      	movq	0x48(%rsp), %rax
   138c1:      	movl	0x5c(%rsp), %r15d
   138c6:      	subq	%rbx, %rax
   138c9:      	movl	0x50(%rsp), %r12d
   138ce:      	movl	%r15d, %edx
   138d1:      	subl	%r12d, %edx
   138d4:      	movl	$0x0, %ecx
   138d9:      	cmovbl	%ecx, %edx
   138dc:      	addq	0x60(%rsp), %rdx
   138e1:      	xorl	%esi, %esi
   138e3:      	cmpl	%r15d, %r12d
   138e6:      	seta	%sil
   138ea:      	movl	%r15d, %ecx
   138ed:      	cmovbl	%r12d, %ecx
   138f1:      	addl	%ecx, %esi
   138f3:      	movl	%r12d, %edi
   138f6:      	subl	%esi, %edi
   138f8:      	movl	%edi, 0x50(%rsp)
   138fc:      	subq	%rsi, %rax
   138ff:      	jb	0x16372 <generic_usdt_path+0xba72>
   13905:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1390b:      	ja	0x16372 <generic_usdt_path+0xba72>
   13911:      	cmpl	%r15d, %r12d
   13914:      	jbe	0x1391a <generic_usdt_path+0x901a>
   13916:      	movb	$0x2f, (%rbx,%rax)
   1391a:      	xorl	%edi, %edi
   1391c:      	cmpl	%r15d, %r12d
   1391f:      	seta	%dil
   13923:      	movzbl	%cl, %esi
   13926:      	addq	%rax, %rbx
   13929:      	addq	%rbx, %rdi
   1392c:      	movl	$0x4, %eax
   13931:      	callq	*%rax
   13933:      	movq	%rbx, 0x48(%rsp)
   13938:      	cmpl	%r15d, %r12d
   1393b:      	jbe	0x16372 <generic_usdt_path+0xba72>
   13941:      	movq	0x8(%rsp), %r12
   13946:      	movq	%r12, 0x30(%rsp)
   1394b:      	movq	0x38(%rsp), %rdx
   13950:      	movq	0x40(%rsp), %r15
   13955:      	jmp	0x139a8 <generic_usdt_path+0x90a8>
   13957:      	leaq	0x10(%r15), %rdx
   1395b:      	movl	$0x4, %eax
   13960:      	movq	%rbp, %rdi
   13963:      	movl	$0x8, %esi
   13968:      	callq	*%rax
   1396a:      	movq	0x40(%rsp), %rax
   1396f:      	cmpq	(%rsp), %rax
   13973:      	je	0x1636d <generic_usdt_path+0xba6d>
   13979:      	addq	$0x18, %r15
   1397d:      	movl	$0x4, %eax
   13982:      	leaq	0x30(%rsp), %rdi
   13987:      	movl	$0x8, %esi
   1398c:      	movq	%r15, %rdx
   1398f:      	callq	*%rax
   13991:      	movq	(%rsp), %r15
   13995:      	movq	%r15, 0x40(%rsp)
   1399a:      	leaq	0x20(%r15), %rdx
   1399e:      	movq	%rdx, 0x38(%rsp)
   139a3:      	movq	0x30(%rsp), %r12
   139a8:      	cmpq	0x18(%rsp), %r12
   139ad:      	jne	0x139ba <generic_usdt_path+0x90ba>
   139af:      	cmpq	0x20(%rsp), %rdx
   139b4:      	je	0x1636d <generic_usdt_path+0xba6d>
   139ba:      	movl	$0x4, %eax
   139bf:      	leaq	0x10(%rsp), %rdi
   139c4:      	movl	$0x8, %esi
   139c9:      	callq	*%rax
   139cb:      	cmpq	0x10(%rsp), %r12
   139d0:      	je	0x13ac8 <generic_usdt_path+0x91c8>
   139d6:      	leaq	0x18(%r12), %rbx
   139db:      	movl	$0x4, %eax
   139e0:      	movq	%rbp, %rdi
   139e3:      	movl	$0x8, %esi
   139e8:      	movq	%rbx, %rdx
   139eb:      	callq	*%rax
   139ed:      	cmpq	%r12, (%rsp)
   139f1:      	je	0x13ac8 <generic_usdt_path+0x91c8>
   139f7:      	movl	$0x4, %eax
   139fc:      	leaq	0x8(%rsp), %rdi
   13a01:      	movl	$0x8, %esi
   13a06:      	movq	%rbx, %rdx
   13a09:      	callq	*%rax
   13a0b:      	addq	$0x20, %r12
   13a0f:      	movl	$0x4, %eax
   13a14:      	leaq	0x58(%rsp), %rdi
   13a19:      	movl	$0x10, %ecx
   13a1e:      	movl	$0x10, %esi
   13a23:      	movq	%r12, %rdx
   13a26:      	callq	*%rax
   13a28:      	movq	0x28(%rsp), %rbx
   13a2d:      	movq	0x48(%rsp), %rax
   13a32:      	movl	0x5c(%rsp), %r15d
   13a37:      	subq	%rbx, %rax
   13a3a:      	movl	0x50(%rsp), %r12d
   13a3f:      	movl	%r15d, %edx
   13a42:      	subl	%r12d, %edx
   13a45:      	movl	$0x0, %ecx
   13a4a:      	cmovbl	%ecx, %edx
   13a4d:      	addq	0x60(%rsp), %rdx
   13a52:      	xorl	%esi, %esi
   13a54:      	cmpl	%r15d, %r12d
   13a57:      	seta	%sil
   13a5b:      	movl	%r15d, %ecx
   13a5e:      	cmovbl	%r12d, %ecx
   13a62:      	addl	%ecx, %esi
   13a64:      	movl	%r12d, %edi
   13a67:      	subl	%esi, %edi
   13a69:      	movl	%edi, 0x50(%rsp)
   13a6d:      	subq	%rsi, %rax
   13a70:      	jb	0x16372 <generic_usdt_path+0xba72>
   13a76:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13a7c:      	ja	0x16372 <generic_usdt_path+0xba72>
   13a82:      	cmpl	%r15d, %r12d
   13a85:      	jbe	0x13a8b <generic_usdt_path+0x918b>
   13a87:      	movb	$0x2f, (%rbx,%rax)
   13a8b:      	xorl	%edi, %edi
   13a8d:      	cmpl	%r15d, %r12d
   13a90:      	seta	%dil
   13a94:      	movzbl	%cl, %esi
   13a97:      	addq	%rax, %rbx
   13a9a:      	addq	%rbx, %rdi
   13a9d:      	movl	$0x4, %eax
   13aa2:      	callq	*%rax
   13aa4:      	movq	%rbx, 0x48(%rsp)
   13aa9:      	cmpl	%r15d, %r12d
   13aac:      	jbe	0x16372 <generic_usdt_path+0xba72>
   13ab2:      	movq	0x8(%rsp), %r12
   13ab7:      	movq	%r12, 0x30(%rsp)
   13abc:      	movq	0x38(%rsp), %rdx
   13ac1:      	movq	0x40(%rsp), %r15
   13ac6:      	jmp	0x13b19 <generic_usdt_path+0x9219>
   13ac8:      	leaq	0x10(%r15), %rdx
   13acc:      	movl	$0x4, %eax
   13ad1:      	movq	%rbp, %rdi
   13ad4:      	movl	$0x8, %esi
   13ad9:      	callq	*%rax
   13adb:      	movq	0x40(%rsp), %rax
   13ae0:      	cmpq	(%rsp), %rax
   13ae4:      	je	0x1636d <generic_usdt_path+0xba6d>
   13aea:      	addq	$0x18, %r15
   13aee:      	movl	$0x4, %eax
   13af3:      	leaq	0x30(%rsp), %rdi
   13af8:      	movl	$0x8, %esi
   13afd:      	movq	%r15, %rdx
   13b00:      	callq	*%rax
   13b02:      	movq	(%rsp), %r15
   13b06:      	movq	%r15, 0x40(%rsp)
   13b0b:      	leaq	0x20(%r15), %rdx
   13b0f:      	movq	%rdx, 0x38(%rsp)
   13b14:      	movq	0x30(%rsp), %r12
   13b19:      	cmpq	0x18(%rsp), %r12
   13b1e:      	jne	0x13b2b <generic_usdt_path+0x922b>
   13b20:      	cmpq	0x20(%rsp), %rdx
   13b25:      	je	0x1636d <generic_usdt_path+0xba6d>
   13b2b:      	movl	$0x4, %eax
   13b30:      	leaq	0x10(%rsp), %rdi
   13b35:      	movl	$0x8, %esi
   13b3a:      	callq	*%rax
   13b3c:      	cmpq	0x10(%rsp), %r12
   13b41:      	je	0x13c39 <generic_usdt_path+0x9339>
   13b47:      	leaq	0x18(%r12), %rbx
   13b4c:      	movl	$0x4, %eax
   13b51:      	movq	%rbp, %rdi
   13b54:      	movl	$0x8, %esi
   13b59:      	movq	%rbx, %rdx
   13b5c:      	callq	*%rax
   13b5e:      	cmpq	%r12, (%rsp)
   13b62:      	je	0x13c39 <generic_usdt_path+0x9339>
   13b68:      	movl	$0x4, %eax
   13b6d:      	leaq	0x8(%rsp), %rdi
   13b72:      	movl	$0x8, %esi
   13b77:      	movq	%rbx, %rdx
   13b7a:      	callq	*%rax
   13b7c:      	addq	$0x20, %r12
   13b80:      	movl	$0x4, %eax
   13b85:      	leaq	0x58(%rsp), %rdi
   13b8a:      	movl	$0x10, %ecx
   13b8f:      	movl	$0x10, %esi
   13b94:      	movq	%r12, %rdx
   13b97:      	callq	*%rax
   13b99:      	movq	0x28(%rsp), %rbx
   13b9e:      	movq	0x48(%rsp), %rax
   13ba3:      	movl	0x5c(%rsp), %r15d
   13ba8:      	subq	%rbx, %rax
   13bab:      	movl	0x50(%rsp), %r12d
   13bb0:      	movl	%r15d, %edx
   13bb3:      	subl	%r12d, %edx
   13bb6:      	movl	$0x0, %ecx
   13bbb:      	cmovbl	%ecx, %edx
   13bbe:      	addq	0x60(%rsp), %rdx
   13bc3:      	xorl	%esi, %esi
   13bc5:      	cmpl	%r15d, %r12d
   13bc8:      	seta	%sil
   13bcc:      	movl	%r15d, %ecx
   13bcf:      	cmovbl	%r12d, %ecx
   13bd3:      	addl	%ecx, %esi
   13bd5:      	movl	%r12d, %edi
   13bd8:      	subl	%esi, %edi
   13bda:      	movl	%edi, 0x50(%rsp)
   13bde:      	subq	%rsi, %rax
   13be1:      	jb	0x16372 <generic_usdt_path+0xba72>
   13be7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13bed:      	ja	0x16372 <generic_usdt_path+0xba72>
   13bf3:      	cmpl	%r15d, %r12d
   13bf6:      	jbe	0x13bfc <generic_usdt_path+0x92fc>
   13bf8:      	movb	$0x2f, (%rbx,%rax)
   13bfc:      	xorl	%edi, %edi
   13bfe:      	cmpl	%r15d, %r12d
   13c01:      	seta	%dil
   13c05:      	movzbl	%cl, %esi
   13c08:      	addq	%rax, %rbx
   13c0b:      	addq	%rbx, %rdi
   13c0e:      	movl	$0x4, %eax
   13c13:      	callq	*%rax
   13c15:      	movq	%rbx, 0x48(%rsp)
   13c1a:      	cmpl	%r15d, %r12d
   13c1d:      	jbe	0x16372 <generic_usdt_path+0xba72>
   13c23:      	movq	0x8(%rsp), %r12
   13c28:      	movq	%r12, 0x30(%rsp)
   13c2d:      	movq	0x38(%rsp), %rdx
   13c32:      	movq	0x40(%rsp), %r15
   13c37:      	jmp	0x13c8a <generic_usdt_path+0x938a>
   13c39:      	leaq	0x10(%r15), %rdx
   13c3d:      	movl	$0x4, %eax
   13c42:      	movq	%rbp, %rdi
   13c45:      	movl	$0x8, %esi
   13c4a:      	callq	*%rax
   13c4c:      	movq	0x40(%rsp), %rax
   13c51:      	cmpq	(%rsp), %rax
   13c55:      	je	0x1636d <generic_usdt_path+0xba6d>
   13c5b:      	addq	$0x18, %r15
   13c5f:      	movl	$0x4, %eax
   13c64:      	leaq	0x30(%rsp), %rdi
   13c69:      	movl	$0x8, %esi
   13c6e:      	movq	%r15, %rdx
   13c71:      	callq	*%rax
   13c73:      	movq	(%rsp), %r15
   13c77:      	movq	%r15, 0x40(%rsp)
   13c7c:      	leaq	0x20(%r15), %rdx
   13c80:      	movq	%rdx, 0x38(%rsp)
   13c85:      	movq	0x30(%rsp), %r12
   13c8a:      	cmpq	0x18(%rsp), %r12
   13c8f:      	jne	0x13c9c <generic_usdt_path+0x939c>
   13c91:      	cmpq	0x20(%rsp), %rdx
   13c96:      	je	0x1636d <generic_usdt_path+0xba6d>
   13c9c:      	movl	$0x4, %eax
   13ca1:      	leaq	0x10(%rsp), %rdi
   13ca6:      	movl	$0x8, %esi
   13cab:      	callq	*%rax
   13cad:      	cmpq	0x10(%rsp), %r12
   13cb2:      	je	0x13daa <generic_usdt_path+0x94aa>
   13cb8:      	leaq	0x18(%r12), %rbx
   13cbd:      	movl	$0x4, %eax
   13cc2:      	movq	%rbp, %rdi
   13cc5:      	movl	$0x8, %esi
   13cca:      	movq	%rbx, %rdx
   13ccd:      	callq	*%rax
   13ccf:      	cmpq	%r12, (%rsp)
   13cd3:      	je	0x13daa <generic_usdt_path+0x94aa>
   13cd9:      	movl	$0x4, %eax
   13cde:      	leaq	0x8(%rsp), %rdi
   13ce3:      	movl	$0x8, %esi
   13ce8:      	movq	%rbx, %rdx
   13ceb:      	callq	*%rax
   13ced:      	addq	$0x20, %r12
   13cf1:      	movl	$0x4, %eax
   13cf6:      	leaq	0x58(%rsp), %rdi
   13cfb:      	movl	$0x10, %ecx
   13d00:      	movl	$0x10, %esi
   13d05:      	movq	%r12, %rdx
   13d08:      	callq	*%rax
   13d0a:      	movq	0x28(%rsp), %rbx
   13d0f:      	movq	0x48(%rsp), %rax
   13d14:      	movl	0x5c(%rsp), %r15d
   13d19:      	subq	%rbx, %rax
   13d1c:      	movl	0x50(%rsp), %r12d
   13d21:      	movl	%r15d, %edx
   13d24:      	subl	%r12d, %edx
   13d27:      	movl	$0x0, %ecx
   13d2c:      	cmovbl	%ecx, %edx
   13d2f:      	addq	0x60(%rsp), %rdx
   13d34:      	xorl	%esi, %esi
   13d36:      	cmpl	%r15d, %r12d
   13d39:      	seta	%sil
   13d3d:      	movl	%r15d, %ecx
   13d40:      	cmovbl	%r12d, %ecx
   13d44:      	addl	%ecx, %esi
   13d46:      	movl	%r12d, %edi
   13d49:      	subl	%esi, %edi
   13d4b:      	movl	%edi, 0x50(%rsp)
   13d4f:      	subq	%rsi, %rax
   13d52:      	jb	0x16372 <generic_usdt_path+0xba72>
   13d58:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13d5e:      	ja	0x16372 <generic_usdt_path+0xba72>
   13d64:      	cmpl	%r15d, %r12d
   13d67:      	jbe	0x13d6d <generic_usdt_path+0x946d>
   13d69:      	movb	$0x2f, (%rbx,%rax)
   13d6d:      	xorl	%edi, %edi
   13d6f:      	cmpl	%r15d, %r12d
   13d72:      	seta	%dil
   13d76:      	movzbl	%cl, %esi
   13d79:      	addq	%rax, %rbx
   13d7c:      	addq	%rbx, %rdi
   13d7f:      	movl	$0x4, %eax
   13d84:      	callq	*%rax
   13d86:      	movq	%rbx, 0x48(%rsp)
   13d8b:      	cmpl	%r15d, %r12d
   13d8e:      	jbe	0x16372 <generic_usdt_path+0xba72>
   13d94:      	movq	0x8(%rsp), %r12
   13d99:      	movq	%r12, 0x30(%rsp)
   13d9e:      	movq	0x38(%rsp), %rdx
   13da3:      	movq	0x40(%rsp), %r15
   13da8:      	jmp	0x13dfb <generic_usdt_path+0x94fb>
   13daa:      	leaq	0x10(%r15), %rdx
   13dae:      	movl	$0x4, %eax
   13db3:      	movq	%rbp, %rdi
   13db6:      	movl	$0x8, %esi
   13dbb:      	callq	*%rax
   13dbd:      	movq	0x40(%rsp), %rax
   13dc2:      	cmpq	(%rsp), %rax
   13dc6:      	je	0x1636d <generic_usdt_path+0xba6d>
   13dcc:      	addq	$0x18, %r15
   13dd0:      	movl	$0x4, %eax
   13dd5:      	leaq	0x30(%rsp), %rdi
   13dda:      	movl	$0x8, %esi
   13ddf:      	movq	%r15, %rdx
   13de2:      	callq	*%rax
   13de4:      	movq	(%rsp), %r15
   13de8:      	movq	%r15, 0x40(%rsp)
   13ded:      	leaq	0x20(%r15), %rdx
   13df1:      	movq	%rdx, 0x38(%rsp)
   13df6:      	movq	0x30(%rsp), %r12
   13dfb:      	cmpq	0x18(%rsp), %r12
   13e00:      	jne	0x13e0d <generic_usdt_path+0x950d>
   13e02:      	cmpq	0x20(%rsp), %rdx
   13e07:      	je	0x1636d <generic_usdt_path+0xba6d>
   13e0d:      	movl	$0x4, %eax
   13e12:      	leaq	0x10(%rsp), %rdi
   13e17:      	movl	$0x8, %esi
   13e1c:      	callq	*%rax
   13e1e:      	cmpq	0x10(%rsp), %r12
   13e23:      	je	0x13f1b <generic_usdt_path+0x961b>
   13e29:      	leaq	0x18(%r12), %rbx
   13e2e:      	movl	$0x4, %eax
   13e33:      	movq	%rbp, %rdi
   13e36:      	movl	$0x8, %esi
   13e3b:      	movq	%rbx, %rdx
   13e3e:      	callq	*%rax
   13e40:      	cmpq	%r12, (%rsp)
   13e44:      	je	0x13f1b <generic_usdt_path+0x961b>
   13e4a:      	movl	$0x4, %eax
   13e4f:      	leaq	0x8(%rsp), %rdi
   13e54:      	movl	$0x8, %esi
   13e59:      	movq	%rbx, %rdx
   13e5c:      	callq	*%rax
   13e5e:      	addq	$0x20, %r12
   13e62:      	movl	$0x4, %eax
   13e67:      	leaq	0x58(%rsp), %rdi
   13e6c:      	movl	$0x10, %ecx
   13e71:      	movl	$0x10, %esi
   13e76:      	movq	%r12, %rdx
   13e79:      	callq	*%rax
   13e7b:      	movq	0x28(%rsp), %rbx
   13e80:      	movq	0x48(%rsp), %rax
   13e85:      	movl	0x5c(%rsp), %r15d
   13e8a:      	subq	%rbx, %rax
   13e8d:      	movl	0x50(%rsp), %r12d
   13e92:      	movl	%r15d, %edx
   13e95:      	subl	%r12d, %edx
   13e98:      	movl	$0x0, %ecx
   13e9d:      	cmovbl	%ecx, %edx
   13ea0:      	addq	0x60(%rsp), %rdx
   13ea5:      	xorl	%esi, %esi
   13ea7:      	cmpl	%r15d, %r12d
   13eaa:      	seta	%sil
   13eae:      	movl	%r15d, %ecx
   13eb1:      	cmovbl	%r12d, %ecx
   13eb5:      	addl	%ecx, %esi
   13eb7:      	movl	%r12d, %edi
   13eba:      	subl	%esi, %edi
   13ebc:      	movl	%edi, 0x50(%rsp)
   13ec0:      	subq	%rsi, %rax
   13ec3:      	jb	0x16372 <generic_usdt_path+0xba72>
   13ec9:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   13ecf:      	ja	0x16372 <generic_usdt_path+0xba72>
   13ed5:      	cmpl	%r15d, %r12d
   13ed8:      	jbe	0x13ede <generic_usdt_path+0x95de>
   13eda:      	movb	$0x2f, (%rbx,%rax)
   13ede:      	xorl	%edi, %edi
   13ee0:      	cmpl	%r15d, %r12d
   13ee3:      	seta	%dil
   13ee7:      	movzbl	%cl, %esi
   13eea:      	addq	%rax, %rbx
   13eed:      	addq	%rbx, %rdi
   13ef0:      	movl	$0x4, %eax
   13ef5:      	callq	*%rax
   13ef7:      	movq	%rbx, 0x48(%rsp)
   13efc:      	cmpl	%r15d, %r12d
   13eff:      	jbe	0x16372 <generic_usdt_path+0xba72>
   13f05:      	movq	0x8(%rsp), %r12
   13f0a:      	movq	%r12, 0x30(%rsp)
   13f0f:      	movq	0x38(%rsp), %rdx
   13f14:      	movq	0x40(%rsp), %r15
   13f19:      	jmp	0x13f6c <generic_usdt_path+0x966c>
   13f1b:      	leaq	0x10(%r15), %rdx
   13f1f:      	movl	$0x4, %eax
   13f24:      	movq	%rbp, %rdi
   13f27:      	movl	$0x8, %esi
   13f2c:      	callq	*%rax
   13f2e:      	movq	0x40(%rsp), %rax
   13f33:      	cmpq	(%rsp), %rax
   13f37:      	je	0x1636d <generic_usdt_path+0xba6d>
   13f3d:      	addq	$0x18, %r15
   13f41:      	movl	$0x4, %eax
   13f46:      	leaq	0x30(%rsp), %rdi
   13f4b:      	movl	$0x8, %esi
   13f50:      	movq	%r15, %rdx
   13f53:      	callq	*%rax
   13f55:      	movq	(%rsp), %r15
   13f59:      	movq	%r15, 0x40(%rsp)
   13f5e:      	leaq	0x20(%r15), %rdx
   13f62:      	movq	%rdx, 0x38(%rsp)
   13f67:      	movq	0x30(%rsp), %r12
   13f6c:      	cmpq	0x18(%rsp), %r12
   13f71:      	jne	0x13f7e <generic_usdt_path+0x967e>
   13f73:      	cmpq	0x20(%rsp), %rdx
   13f78:      	je	0x1636d <generic_usdt_path+0xba6d>
   13f7e:      	movl	$0x4, %eax
   13f83:      	leaq	0x10(%rsp), %rdi
   13f88:      	movl	$0x8, %esi
   13f8d:      	callq	*%rax
   13f8f:      	cmpq	0x10(%rsp), %r12
   13f94:      	je	0x1408c <generic_usdt_path+0x978c>
   13f9a:      	leaq	0x18(%r12), %rbx
   13f9f:      	movl	$0x4, %eax
   13fa4:      	movq	%rbp, %rdi
   13fa7:      	movl	$0x8, %esi
   13fac:      	movq	%rbx, %rdx
   13faf:      	callq	*%rax
   13fb1:      	cmpq	%r12, (%rsp)
   13fb5:      	je	0x1408c <generic_usdt_path+0x978c>
   13fbb:      	movl	$0x4, %eax
   13fc0:      	leaq	0x8(%rsp), %rdi
   13fc5:      	movl	$0x8, %esi
   13fca:      	movq	%rbx, %rdx
   13fcd:      	callq	*%rax
   13fcf:      	addq	$0x20, %r12
   13fd3:      	movl	$0x4, %eax
   13fd8:      	leaq	0x58(%rsp), %rdi
   13fdd:      	movl	$0x10, %ecx
   13fe2:      	movl	$0x10, %esi
   13fe7:      	movq	%r12, %rdx
   13fea:      	callq	*%rax
   13fec:      	movq	0x28(%rsp), %rbx
   13ff1:      	movq	0x48(%rsp), %rax
   13ff6:      	movl	0x5c(%rsp), %r15d
   13ffb:      	subq	%rbx, %rax
   13ffe:      	movl	0x50(%rsp), %r12d
   14003:      	movl	%r15d, %edx
   14006:      	subl	%r12d, %edx
   14009:      	movl	$0x0, %ecx
   1400e:      	cmovbl	%ecx, %edx
   14011:      	addq	0x60(%rsp), %rdx
   14016:      	xorl	%esi, %esi
   14018:      	cmpl	%r15d, %r12d
   1401b:      	seta	%sil
   1401f:      	movl	%r15d, %ecx
   14022:      	cmovbl	%r12d, %ecx
   14026:      	addl	%ecx, %esi
   14028:      	movl	%r12d, %edi
   1402b:      	subl	%esi, %edi
   1402d:      	movl	%edi, 0x50(%rsp)
   14031:      	subq	%rsi, %rax
   14034:      	jb	0x16372 <generic_usdt_path+0xba72>
   1403a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14040:      	ja	0x16372 <generic_usdt_path+0xba72>
   14046:      	cmpl	%r15d, %r12d
   14049:      	jbe	0x1404f <generic_usdt_path+0x974f>
   1404b:      	movb	$0x2f, (%rbx,%rax)
   1404f:      	xorl	%edi, %edi
   14051:      	cmpl	%r15d, %r12d
   14054:      	seta	%dil
   14058:      	movzbl	%cl, %esi
   1405b:      	addq	%rax, %rbx
   1405e:      	addq	%rbx, %rdi
   14061:      	movl	$0x4, %eax
   14066:      	callq	*%rax
   14068:      	movq	%rbx, 0x48(%rsp)
   1406d:      	cmpl	%r15d, %r12d
   14070:      	jbe	0x16372 <generic_usdt_path+0xba72>
   14076:      	movq	0x8(%rsp), %r12
   1407b:      	movq	%r12, 0x30(%rsp)
   14080:      	movq	0x38(%rsp), %rdx
   14085:      	movq	0x40(%rsp), %r15
   1408a:      	jmp	0x140dd <generic_usdt_path+0x97dd>
   1408c:      	leaq	0x10(%r15), %rdx
   14090:      	movl	$0x4, %eax
   14095:      	movq	%rbp, %rdi
   14098:      	movl	$0x8, %esi
   1409d:      	callq	*%rax
   1409f:      	movq	0x40(%rsp), %rax
   140a4:      	cmpq	(%rsp), %rax
   140a8:      	je	0x1636d <generic_usdt_path+0xba6d>
   140ae:      	addq	$0x18, %r15
   140b2:      	movl	$0x4, %eax
   140b7:      	leaq	0x30(%rsp), %rdi
   140bc:      	movl	$0x8, %esi
   140c1:      	movq	%r15, %rdx
   140c4:      	callq	*%rax
   140c6:      	movq	(%rsp), %r15
   140ca:      	movq	%r15, 0x40(%rsp)
   140cf:      	leaq	0x20(%r15), %rdx
   140d3:      	movq	%rdx, 0x38(%rsp)
   140d8:      	movq	0x30(%rsp), %r12
   140dd:      	cmpq	0x18(%rsp), %r12
   140e2:      	jne	0x140ef <generic_usdt_path+0x97ef>
   140e4:      	cmpq	0x20(%rsp), %rdx
   140e9:      	je	0x1636d <generic_usdt_path+0xba6d>
   140ef:      	movl	$0x4, %eax
   140f4:      	leaq	0x10(%rsp), %rdi
   140f9:      	movl	$0x8, %esi
   140fe:      	callq	*%rax
   14100:      	cmpq	0x10(%rsp), %r12
   14105:      	je	0x141fd <generic_usdt_path+0x98fd>
   1410b:      	leaq	0x18(%r12), %rbx
   14110:      	movl	$0x4, %eax
   14115:      	movq	%rbp, %rdi
   14118:      	movl	$0x8, %esi
   1411d:      	movq	%rbx, %rdx
   14120:      	callq	*%rax
   14122:      	cmpq	%r12, (%rsp)
   14126:      	je	0x141fd <generic_usdt_path+0x98fd>
   1412c:      	movl	$0x4, %eax
   14131:      	leaq	0x8(%rsp), %rdi
   14136:      	movl	$0x8, %esi
   1413b:      	movq	%rbx, %rdx
   1413e:      	callq	*%rax
   14140:      	addq	$0x20, %r12
   14144:      	movl	$0x4, %eax
   14149:      	leaq	0x58(%rsp), %rdi
   1414e:      	movl	$0x10, %ecx
   14153:      	movl	$0x10, %esi
   14158:      	movq	%r12, %rdx
   1415b:      	callq	*%rax
   1415d:      	movq	0x28(%rsp), %rbx
   14162:      	movq	0x48(%rsp), %rax
   14167:      	movl	0x5c(%rsp), %r15d
   1416c:      	subq	%rbx, %rax
   1416f:      	movl	0x50(%rsp), %r12d
   14174:      	movl	%r15d, %edx
   14177:      	subl	%r12d, %edx
   1417a:      	movl	$0x0, %ecx
   1417f:      	cmovbl	%ecx, %edx
   14182:      	addq	0x60(%rsp), %rdx
   14187:      	xorl	%esi, %esi
   14189:      	cmpl	%r15d, %r12d
   1418c:      	seta	%sil
   14190:      	movl	%r15d, %ecx
   14193:      	cmovbl	%r12d, %ecx
   14197:      	addl	%ecx, %esi
   14199:      	movl	%r12d, %edi
   1419c:      	subl	%esi, %edi
   1419e:      	movl	%edi, 0x50(%rsp)
   141a2:      	subq	%rsi, %rax
   141a5:      	jb	0x16372 <generic_usdt_path+0xba72>
   141ab:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   141b1:      	ja	0x16372 <generic_usdt_path+0xba72>
   141b7:      	cmpl	%r15d, %r12d
   141ba:      	jbe	0x141c0 <generic_usdt_path+0x98c0>
   141bc:      	movb	$0x2f, (%rbx,%rax)
   141c0:      	xorl	%edi, %edi
   141c2:      	cmpl	%r15d, %r12d
   141c5:      	seta	%dil
   141c9:      	movzbl	%cl, %esi
   141cc:      	addq	%rax, %rbx
   141cf:      	addq	%rbx, %rdi
   141d2:      	movl	$0x4, %eax
   141d7:      	callq	*%rax
   141d9:      	movq	%rbx, 0x48(%rsp)
   141de:      	cmpl	%r15d, %r12d
   141e1:      	jbe	0x16372 <generic_usdt_path+0xba72>
   141e7:      	movq	0x8(%rsp), %r12
   141ec:      	movq	%r12, 0x30(%rsp)
   141f1:      	movq	0x38(%rsp), %rdx
   141f6:      	movq	0x40(%rsp), %r15
   141fb:      	jmp	0x1424e <generic_usdt_path+0x994e>
   141fd:      	leaq	0x10(%r15), %rdx
   14201:      	movl	$0x4, %eax
   14206:      	movq	%rbp, %rdi
   14209:      	movl	$0x8, %esi
   1420e:      	callq	*%rax
   14210:      	movq	0x40(%rsp), %rax
   14215:      	cmpq	(%rsp), %rax
   14219:      	je	0x1636d <generic_usdt_path+0xba6d>
   1421f:      	addq	$0x18, %r15
   14223:      	movl	$0x4, %eax
   14228:      	leaq	0x30(%rsp), %rdi
   1422d:      	movl	$0x8, %esi
   14232:      	movq	%r15, %rdx
   14235:      	callq	*%rax
   14237:      	movq	(%rsp), %r15
   1423b:      	movq	%r15, 0x40(%rsp)
   14240:      	leaq	0x20(%r15), %rdx
   14244:      	movq	%rdx, 0x38(%rsp)
   14249:      	movq	0x30(%rsp), %r12
   1424e:      	cmpq	0x18(%rsp), %r12
   14253:      	jne	0x14260 <generic_usdt_path+0x9960>
   14255:      	cmpq	0x20(%rsp), %rdx
   1425a:      	je	0x1636d <generic_usdt_path+0xba6d>
   14260:      	movl	$0x4, %eax
   14265:      	leaq	0x10(%rsp), %rdi
   1426a:      	movl	$0x8, %esi
   1426f:      	callq	*%rax
   14271:      	cmpq	0x10(%rsp), %r12
   14276:      	je	0x1436e <generic_usdt_path+0x9a6e>
   1427c:      	leaq	0x18(%r12), %rbx
   14281:      	movl	$0x4, %eax
   14286:      	movq	%rbp, %rdi
   14289:      	movl	$0x8, %esi
   1428e:      	movq	%rbx, %rdx
   14291:      	callq	*%rax
   14293:      	cmpq	%r12, (%rsp)
   14297:      	je	0x1436e <generic_usdt_path+0x9a6e>
   1429d:      	movl	$0x4, %eax
   142a2:      	leaq	0x8(%rsp), %rdi
   142a7:      	movl	$0x8, %esi
   142ac:      	movq	%rbx, %rdx
   142af:      	callq	*%rax
   142b1:      	addq	$0x20, %r12
   142b5:      	movl	$0x4, %eax
   142ba:      	leaq	0x58(%rsp), %rdi
   142bf:      	movl	$0x10, %ecx
   142c4:      	movl	$0x10, %esi
   142c9:      	movq	%r12, %rdx
   142cc:      	callq	*%rax
   142ce:      	movq	0x28(%rsp), %rbx
   142d3:      	movq	0x48(%rsp), %rax
   142d8:      	movl	0x5c(%rsp), %r15d
   142dd:      	subq	%rbx, %rax
   142e0:      	movl	0x50(%rsp), %r12d
   142e5:      	movl	%r15d, %edx
   142e8:      	subl	%r12d, %edx
   142eb:      	movl	$0x0, %ecx
   142f0:      	cmovbl	%ecx, %edx
   142f3:      	addq	0x60(%rsp), %rdx
   142f8:      	xorl	%esi, %esi
   142fa:      	cmpl	%r15d, %r12d
   142fd:      	seta	%sil
   14301:      	movl	%r15d, %ecx
   14304:      	cmovbl	%r12d, %ecx
   14308:      	addl	%ecx, %esi
   1430a:      	movl	%r12d, %edi
   1430d:      	subl	%esi, %edi
   1430f:      	movl	%edi, 0x50(%rsp)
   14313:      	subq	%rsi, %rax
   14316:      	jb	0x16372 <generic_usdt_path+0xba72>
   1431c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14322:      	ja	0x16372 <generic_usdt_path+0xba72>
   14328:      	cmpl	%r15d, %r12d
   1432b:      	jbe	0x14331 <generic_usdt_path+0x9a31>
   1432d:      	movb	$0x2f, (%rbx,%rax)
   14331:      	xorl	%edi, %edi
   14333:      	cmpl	%r15d, %r12d
   14336:      	seta	%dil
   1433a:      	movzbl	%cl, %esi
   1433d:      	addq	%rax, %rbx
   14340:      	addq	%rbx, %rdi
   14343:      	movl	$0x4, %eax
   14348:      	callq	*%rax
   1434a:      	movq	%rbx, 0x48(%rsp)
   1434f:      	cmpl	%r15d, %r12d
   14352:      	jbe	0x16372 <generic_usdt_path+0xba72>
   14358:      	movq	0x8(%rsp), %r12
   1435d:      	movq	%r12, 0x30(%rsp)
   14362:      	movq	0x38(%rsp), %rdx
   14367:      	movq	0x40(%rsp), %r15
   1436c:      	jmp	0x143bf <generic_usdt_path+0x9abf>
   1436e:      	leaq	0x10(%r15), %rdx
   14372:      	movl	$0x4, %eax
   14377:      	movq	%rbp, %rdi
   1437a:      	movl	$0x8, %esi
   1437f:      	callq	*%rax
   14381:      	movq	0x40(%rsp), %rax
   14386:      	cmpq	(%rsp), %rax
   1438a:      	je	0x1636d <generic_usdt_path+0xba6d>
   14390:      	addq	$0x18, %r15
   14394:      	movl	$0x4, %eax
   14399:      	leaq	0x30(%rsp), %rdi
   1439e:      	movl	$0x8, %esi
   143a3:      	movq	%r15, %rdx
   143a6:      	callq	*%rax
   143a8:      	movq	(%rsp), %r15
   143ac:      	movq	%r15, 0x40(%rsp)
   143b1:      	leaq	0x20(%r15), %rdx
   143b5:      	movq	%rdx, 0x38(%rsp)
   143ba:      	movq	0x30(%rsp), %r12
   143bf:      	cmpq	0x18(%rsp), %r12
   143c4:      	jne	0x143d1 <generic_usdt_path+0x9ad1>
   143c6:      	cmpq	0x20(%rsp), %rdx
   143cb:      	je	0x1636d <generic_usdt_path+0xba6d>
   143d1:      	movl	$0x4, %eax
   143d6:      	leaq	0x10(%rsp), %rdi
   143db:      	movl	$0x8, %esi
   143e0:      	callq	*%rax
   143e2:      	cmpq	0x10(%rsp), %r12
   143e7:      	je	0x144df <generic_usdt_path+0x9bdf>
   143ed:      	leaq	0x18(%r12), %rbx
   143f2:      	movl	$0x4, %eax
   143f7:      	movq	%rbp, %rdi
   143fa:      	movl	$0x8, %esi
   143ff:      	movq	%rbx, %rdx
   14402:      	callq	*%rax
   14404:      	cmpq	%r12, (%rsp)
   14408:      	je	0x144df <generic_usdt_path+0x9bdf>
   1440e:      	movl	$0x4, %eax
   14413:      	leaq	0x8(%rsp), %rdi
   14418:      	movl	$0x8, %esi
   1441d:      	movq	%rbx, %rdx
   14420:      	callq	*%rax
   14422:      	addq	$0x20, %r12
   14426:      	movl	$0x4, %eax
   1442b:      	leaq	0x58(%rsp), %rdi
   14430:      	movl	$0x10, %ecx
   14435:      	movl	$0x10, %esi
   1443a:      	movq	%r12, %rdx
   1443d:      	callq	*%rax
   1443f:      	movq	0x28(%rsp), %rbx
   14444:      	movq	0x48(%rsp), %rax
   14449:      	movl	0x5c(%rsp), %r15d
   1444e:      	subq	%rbx, %rax
   14451:      	movl	0x50(%rsp), %r12d
   14456:      	movl	%r15d, %edx
   14459:      	subl	%r12d, %edx
   1445c:      	movl	$0x0, %ecx
   14461:      	cmovbl	%ecx, %edx
   14464:      	addq	0x60(%rsp), %rdx
   14469:      	xorl	%esi, %esi
   1446b:      	cmpl	%r15d, %r12d
   1446e:      	seta	%sil
   14472:      	movl	%r15d, %ecx
   14475:      	cmovbl	%r12d, %ecx
   14479:      	addl	%ecx, %esi
   1447b:      	movl	%r12d, %edi
   1447e:      	subl	%esi, %edi
   14480:      	movl	%edi, 0x50(%rsp)
   14484:      	subq	%rsi, %rax
   14487:      	jb	0x16372 <generic_usdt_path+0xba72>
   1448d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14493:      	ja	0x16372 <generic_usdt_path+0xba72>
   14499:      	cmpl	%r15d, %r12d
   1449c:      	jbe	0x144a2 <generic_usdt_path+0x9ba2>
   1449e:      	movb	$0x2f, (%rbx,%rax)
   144a2:      	xorl	%edi, %edi
   144a4:      	cmpl	%r15d, %r12d
   144a7:      	seta	%dil
   144ab:      	movzbl	%cl, %esi
   144ae:      	addq	%rax, %rbx
   144b1:      	addq	%rbx, %rdi
   144b4:      	movl	$0x4, %eax
   144b9:      	callq	*%rax
   144bb:      	movq	%rbx, 0x48(%rsp)
   144c0:      	cmpl	%r15d, %r12d
   144c3:      	jbe	0x16372 <generic_usdt_path+0xba72>
   144c9:      	movq	0x8(%rsp), %r12
   144ce:      	movq	%r12, 0x30(%rsp)
   144d3:      	movq	0x38(%rsp), %rdx
   144d8:      	movq	0x40(%rsp), %r15
   144dd:      	jmp	0x14530 <generic_usdt_path+0x9c30>
   144df:      	leaq	0x10(%r15), %rdx
   144e3:      	movl	$0x4, %eax
   144e8:      	movq	%rbp, %rdi
   144eb:      	movl	$0x8, %esi
   144f0:      	callq	*%rax
   144f2:      	movq	0x40(%rsp), %rax
   144f7:      	cmpq	(%rsp), %rax
   144fb:      	je	0x1636d <generic_usdt_path+0xba6d>
   14501:      	addq	$0x18, %r15
   14505:      	movl	$0x4, %eax
   1450a:      	leaq	0x30(%rsp), %rdi
   1450f:      	movl	$0x8, %esi
   14514:      	movq	%r15, %rdx
   14517:      	callq	*%rax
   14519:      	movq	(%rsp), %r15
   1451d:      	movq	%r15, 0x40(%rsp)
   14522:      	leaq	0x20(%r15), %rdx
   14526:      	movq	%rdx, 0x38(%rsp)
   1452b:      	movq	0x30(%rsp), %r12
   14530:      	cmpq	0x18(%rsp), %r12
   14535:      	jne	0x14542 <generic_usdt_path+0x9c42>
   14537:      	cmpq	0x20(%rsp), %rdx
   1453c:      	je	0x1636d <generic_usdt_path+0xba6d>
   14542:      	movl	$0x4, %eax
   14547:      	leaq	0x10(%rsp), %rdi
   1454c:      	movl	$0x8, %esi
   14551:      	callq	*%rax
   14553:      	cmpq	0x10(%rsp), %r12
   14558:      	je	0x14650 <generic_usdt_path+0x9d50>
   1455e:      	leaq	0x18(%r12), %rbx
   14563:      	movl	$0x4, %eax
   14568:      	movq	%rbp, %rdi
   1456b:      	movl	$0x8, %esi
   14570:      	movq	%rbx, %rdx
   14573:      	callq	*%rax
   14575:      	cmpq	%r12, (%rsp)
   14579:      	je	0x14650 <generic_usdt_path+0x9d50>
   1457f:      	movl	$0x4, %eax
   14584:      	leaq	0x8(%rsp), %rdi
   14589:      	movl	$0x8, %esi
   1458e:      	movq	%rbx, %rdx
   14591:      	callq	*%rax
   14593:      	addq	$0x20, %r12
   14597:      	movl	$0x4, %eax
   1459c:      	leaq	0x58(%rsp), %rdi
   145a1:      	movl	$0x10, %ecx
   145a6:      	movl	$0x10, %esi
   145ab:      	movq	%r12, %rdx
   145ae:      	callq	*%rax
   145b0:      	movq	0x28(%rsp), %rbx
   145b5:      	movq	0x48(%rsp), %rax
   145ba:      	movl	0x5c(%rsp), %r15d
   145bf:      	subq	%rbx, %rax
   145c2:      	movl	0x50(%rsp), %r12d
   145c7:      	movl	%r15d, %edx
   145ca:      	subl	%r12d, %edx
   145cd:      	movl	$0x0, %ecx
   145d2:      	cmovbl	%ecx, %edx
   145d5:      	addq	0x60(%rsp), %rdx
   145da:      	xorl	%esi, %esi
   145dc:      	cmpl	%r15d, %r12d
   145df:      	seta	%sil
   145e3:      	movl	%r15d, %ecx
   145e6:      	cmovbl	%r12d, %ecx
   145ea:      	addl	%ecx, %esi
   145ec:      	movl	%r12d, %edi
   145ef:      	subl	%esi, %edi
   145f1:      	movl	%edi, 0x50(%rsp)
   145f5:      	subq	%rsi, %rax
   145f8:      	jb	0x16372 <generic_usdt_path+0xba72>
   145fe:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14604:      	ja	0x16372 <generic_usdt_path+0xba72>
   1460a:      	cmpl	%r15d, %r12d
   1460d:      	jbe	0x14613 <generic_usdt_path+0x9d13>
   1460f:      	movb	$0x2f, (%rbx,%rax)
   14613:      	xorl	%edi, %edi
   14615:      	cmpl	%r15d, %r12d
   14618:      	seta	%dil
   1461c:      	movzbl	%cl, %esi
   1461f:      	addq	%rax, %rbx
   14622:      	addq	%rbx, %rdi
   14625:      	movl	$0x4, %eax
   1462a:      	callq	*%rax
   1462c:      	movq	%rbx, 0x48(%rsp)
   14631:      	cmpl	%r15d, %r12d
   14634:      	jbe	0x16372 <generic_usdt_path+0xba72>
   1463a:      	movq	0x8(%rsp), %r12
   1463f:      	movq	%r12, 0x30(%rsp)
   14644:      	movq	0x38(%rsp), %rdx
   14649:      	movq	0x40(%rsp), %r15
   1464e:      	jmp	0x146a1 <generic_usdt_path+0x9da1>
   14650:      	leaq	0x10(%r15), %rdx
   14654:      	movl	$0x4, %eax
   14659:      	movq	%rbp, %rdi
   1465c:      	movl	$0x8, %esi
   14661:      	callq	*%rax
   14663:      	movq	0x40(%rsp), %rax
   14668:      	cmpq	(%rsp), %rax
   1466c:      	je	0x1636d <generic_usdt_path+0xba6d>
   14672:      	addq	$0x18, %r15
   14676:      	movl	$0x4, %eax
   1467b:      	leaq	0x30(%rsp), %rdi
   14680:      	movl	$0x8, %esi
   14685:      	movq	%r15, %rdx
   14688:      	callq	*%rax
   1468a:      	movq	(%rsp), %r15
   1468e:      	movq	%r15, 0x40(%rsp)
   14693:      	leaq	0x20(%r15), %rdx
   14697:      	movq	%rdx, 0x38(%rsp)
   1469c:      	movq	0x30(%rsp), %r12
   146a1:      	cmpq	0x18(%rsp), %r12
   146a6:      	jne	0x146b3 <generic_usdt_path+0x9db3>
   146a8:      	cmpq	0x20(%rsp), %rdx
   146ad:      	je	0x1636d <generic_usdt_path+0xba6d>
   146b3:      	movl	$0x4, %eax
   146b8:      	leaq	0x10(%rsp), %rdi
   146bd:      	movl	$0x8, %esi
   146c2:      	callq	*%rax
   146c4:      	cmpq	0x10(%rsp), %r12
   146c9:      	je	0x147c1 <generic_usdt_path+0x9ec1>
   146cf:      	leaq	0x18(%r12), %rbx
   146d4:      	movl	$0x4, %eax
   146d9:      	movq	%rbp, %rdi
   146dc:      	movl	$0x8, %esi
   146e1:      	movq	%rbx, %rdx
   146e4:      	callq	*%rax
   146e6:      	cmpq	%r12, (%rsp)
   146ea:      	je	0x147c1 <generic_usdt_path+0x9ec1>
   146f0:      	movl	$0x4, %eax
   146f5:      	leaq	0x8(%rsp), %rdi
   146fa:      	movl	$0x8, %esi
   146ff:      	movq	%rbx, %rdx
   14702:      	callq	*%rax
   14704:      	addq	$0x20, %r12
   14708:      	movl	$0x4, %eax
   1470d:      	leaq	0x58(%rsp), %rdi
   14712:      	movl	$0x10, %ecx
   14717:      	movl	$0x10, %esi
   1471c:      	movq	%r12, %rdx
   1471f:      	callq	*%rax
   14721:      	movq	0x28(%rsp), %rbx
   14726:      	movq	0x48(%rsp), %rax
   1472b:      	movl	0x5c(%rsp), %r15d
   14730:      	subq	%rbx, %rax
   14733:      	movl	0x50(%rsp), %r12d
   14738:      	movl	%r15d, %edx
   1473b:      	subl	%r12d, %edx
   1473e:      	movl	$0x0, %ecx
   14743:      	cmovbl	%ecx, %edx
   14746:      	addq	0x60(%rsp), %rdx
   1474b:      	xorl	%esi, %esi
   1474d:      	cmpl	%r15d, %r12d
   14750:      	seta	%sil
   14754:      	movl	%r15d, %ecx
   14757:      	cmovbl	%r12d, %ecx
   1475b:      	addl	%ecx, %esi
   1475d:      	movl	%r12d, %edi
   14760:      	subl	%esi, %edi
   14762:      	movl	%edi, 0x50(%rsp)
   14766:      	subq	%rsi, %rax
   14769:      	jb	0x16372 <generic_usdt_path+0xba72>
   1476f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14775:      	ja	0x16372 <generic_usdt_path+0xba72>
   1477b:      	cmpl	%r15d, %r12d
   1477e:      	jbe	0x14784 <generic_usdt_path+0x9e84>
   14780:      	movb	$0x2f, (%rbx,%rax)
   14784:      	xorl	%edi, %edi
   14786:      	cmpl	%r15d, %r12d
   14789:      	seta	%dil
   1478d:      	movzbl	%cl, %esi
   14790:      	addq	%rax, %rbx
   14793:      	addq	%rbx, %rdi
   14796:      	movl	$0x4, %eax
   1479b:      	callq	*%rax
   1479d:      	movq	%rbx, 0x48(%rsp)
   147a2:      	cmpl	%r15d, %r12d
   147a5:      	jbe	0x16372 <generic_usdt_path+0xba72>
   147ab:      	movq	0x8(%rsp), %r12
   147b0:      	movq	%r12, 0x30(%rsp)
   147b5:      	movq	0x38(%rsp), %rdx
   147ba:      	movq	0x40(%rsp), %r15
   147bf:      	jmp	0x14812 <generic_usdt_path+0x9f12>
   147c1:      	leaq	0x10(%r15), %rdx
   147c5:      	movl	$0x4, %eax
   147ca:      	movq	%rbp, %rdi
   147cd:      	movl	$0x8, %esi
   147d2:      	callq	*%rax
   147d4:      	movq	0x40(%rsp), %rax
   147d9:      	cmpq	(%rsp), %rax
   147dd:      	je	0x1636d <generic_usdt_path+0xba6d>
   147e3:      	addq	$0x18, %r15
   147e7:      	movl	$0x4, %eax
   147ec:      	leaq	0x30(%rsp), %rdi
   147f1:      	movl	$0x8, %esi
   147f6:      	movq	%r15, %rdx
   147f9:      	callq	*%rax
   147fb:      	movq	(%rsp), %r15
   147ff:      	movq	%r15, 0x40(%rsp)
   14804:      	leaq	0x20(%r15), %rdx
   14808:      	movq	%rdx, 0x38(%rsp)
   1480d:      	movq	0x30(%rsp), %r12
   14812:      	cmpq	0x18(%rsp), %r12
   14817:      	jne	0x14824 <generic_usdt_path+0x9f24>
   14819:      	cmpq	0x20(%rsp), %rdx
   1481e:      	je	0x1636d <generic_usdt_path+0xba6d>
   14824:      	movl	$0x4, %eax
   14829:      	leaq	0x10(%rsp), %rdi
   1482e:      	movl	$0x8, %esi
   14833:      	callq	*%rax
   14835:      	cmpq	0x10(%rsp), %r12
   1483a:      	je	0x14932 <generic_usdt_path+0xa032>
   14840:      	leaq	0x18(%r12), %rbx
   14845:      	movl	$0x4, %eax
   1484a:      	movq	%rbp, %rdi
   1484d:      	movl	$0x8, %esi
   14852:      	movq	%rbx, %rdx
   14855:      	callq	*%rax
   14857:      	cmpq	%r12, (%rsp)
   1485b:      	je	0x14932 <generic_usdt_path+0xa032>
   14861:      	movl	$0x4, %eax
   14866:      	leaq	0x8(%rsp), %rdi
   1486b:      	movl	$0x8, %esi
   14870:      	movq	%rbx, %rdx
   14873:      	callq	*%rax
   14875:      	addq	$0x20, %r12
   14879:      	movl	$0x4, %eax
   1487e:      	leaq	0x58(%rsp), %rdi
   14883:      	movl	$0x10, %ecx
   14888:      	movl	$0x10, %esi
   1488d:      	movq	%r12, %rdx
   14890:      	callq	*%rax
   14892:      	movq	0x28(%rsp), %rbx
   14897:      	movq	0x48(%rsp), %rax
   1489c:      	movl	0x5c(%rsp), %r15d
   148a1:      	subq	%rbx, %rax
   148a4:      	movl	0x50(%rsp), %r12d
   148a9:      	movl	%r15d, %edx
   148ac:      	subl	%r12d, %edx
   148af:      	movl	$0x0, %ecx
   148b4:      	cmovbl	%ecx, %edx
   148b7:      	addq	0x60(%rsp), %rdx
   148bc:      	xorl	%esi, %esi
   148be:      	cmpl	%r15d, %r12d
   148c1:      	seta	%sil
   148c5:      	movl	%r15d, %ecx
   148c8:      	cmovbl	%r12d, %ecx
   148cc:      	addl	%ecx, %esi
   148ce:      	movl	%r12d, %edi
   148d1:      	subl	%esi, %edi
   148d3:      	movl	%edi, 0x50(%rsp)
   148d7:      	subq	%rsi, %rax
   148da:      	jb	0x16372 <generic_usdt_path+0xba72>
   148e0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   148e6:      	ja	0x16372 <generic_usdt_path+0xba72>
   148ec:      	cmpl	%r15d, %r12d
   148ef:      	jbe	0x148f5 <generic_usdt_path+0x9ff5>
   148f1:      	movb	$0x2f, (%rbx,%rax)
   148f5:      	xorl	%edi, %edi
   148f7:      	cmpl	%r15d, %r12d
   148fa:      	seta	%dil
   148fe:      	movzbl	%cl, %esi
   14901:      	addq	%rax, %rbx
   14904:      	addq	%rbx, %rdi
   14907:      	movl	$0x4, %eax
   1490c:      	callq	*%rax
   1490e:      	movq	%rbx, 0x48(%rsp)
   14913:      	cmpl	%r15d, %r12d
   14916:      	jbe	0x16372 <generic_usdt_path+0xba72>
   1491c:      	movq	0x8(%rsp), %r12
   14921:      	movq	%r12, 0x30(%rsp)
   14926:      	movq	0x38(%rsp), %rdx
   1492b:      	movq	0x40(%rsp), %r15
   14930:      	jmp	0x14983 <generic_usdt_path+0xa083>
   14932:      	leaq	0x10(%r15), %rdx
   14936:      	movl	$0x4, %eax
   1493b:      	movq	%rbp, %rdi
   1493e:      	movl	$0x8, %esi
   14943:      	callq	*%rax
   14945:      	movq	0x40(%rsp), %rax
   1494a:      	cmpq	(%rsp), %rax
   1494e:      	je	0x1636d <generic_usdt_path+0xba6d>
   14954:      	addq	$0x18, %r15
   14958:      	movl	$0x4, %eax
   1495d:      	leaq	0x30(%rsp), %rdi
   14962:      	movl	$0x8, %esi
   14967:      	movq	%r15, %rdx
   1496a:      	callq	*%rax
   1496c:      	movq	(%rsp), %r15
   14970:      	movq	%r15, 0x40(%rsp)
   14975:      	leaq	0x20(%r15), %rdx
   14979:      	movq	%rdx, 0x38(%rsp)
   1497e:      	movq	0x30(%rsp), %r12
   14983:      	cmpq	0x18(%rsp), %r12
   14988:      	jne	0x14995 <generic_usdt_path+0xa095>
   1498a:      	cmpq	0x20(%rsp), %rdx
   1498f:      	je	0x1636d <generic_usdt_path+0xba6d>
   14995:      	movl	$0x4, %eax
   1499a:      	leaq	0x10(%rsp), %rdi
   1499f:      	movl	$0x8, %esi
   149a4:      	callq	*%rax
   149a6:      	cmpq	0x10(%rsp), %r12
   149ab:      	je	0x14aa3 <generic_usdt_path+0xa1a3>
   149b1:      	leaq	0x18(%r12), %rbx
   149b6:      	movl	$0x4, %eax
   149bb:      	movq	%rbp, %rdi
   149be:      	movl	$0x8, %esi
   149c3:      	movq	%rbx, %rdx
   149c6:      	callq	*%rax
   149c8:      	cmpq	%r12, (%rsp)
   149cc:      	je	0x14aa3 <generic_usdt_path+0xa1a3>
   149d2:      	movl	$0x4, %eax
   149d7:      	leaq	0x8(%rsp), %rdi
   149dc:      	movl	$0x8, %esi
   149e1:      	movq	%rbx, %rdx
   149e4:      	callq	*%rax
   149e6:      	addq	$0x20, %r12
   149ea:      	movl	$0x4, %eax
   149ef:      	leaq	0x58(%rsp), %rdi
   149f4:      	movl	$0x10, %ecx
   149f9:      	movl	$0x10, %esi
   149fe:      	movq	%r12, %rdx
   14a01:      	callq	*%rax
   14a03:      	movq	0x28(%rsp), %rbx
   14a08:      	movq	0x48(%rsp), %rax
   14a0d:      	movl	0x5c(%rsp), %r15d
   14a12:      	subq	%rbx, %rax
   14a15:      	movl	0x50(%rsp), %r12d
   14a1a:      	movl	%r15d, %edx
   14a1d:      	subl	%r12d, %edx
   14a20:      	movl	$0x0, %ecx
   14a25:      	cmovbl	%ecx, %edx
   14a28:      	addq	0x60(%rsp), %rdx
   14a2d:      	xorl	%esi, %esi
   14a2f:      	cmpl	%r15d, %r12d
   14a32:      	seta	%sil
   14a36:      	movl	%r15d, %ecx
   14a39:      	cmovbl	%r12d, %ecx
   14a3d:      	addl	%ecx, %esi
   14a3f:      	movl	%r12d, %edi
   14a42:      	subl	%esi, %edi
   14a44:      	movl	%edi, 0x50(%rsp)
   14a48:      	subq	%rsi, %rax
   14a4b:      	jb	0x16372 <generic_usdt_path+0xba72>
   14a51:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14a57:      	ja	0x16372 <generic_usdt_path+0xba72>
   14a5d:      	cmpl	%r15d, %r12d
   14a60:      	jbe	0x14a66 <generic_usdt_path+0xa166>
   14a62:      	movb	$0x2f, (%rbx,%rax)
   14a66:      	xorl	%edi, %edi
   14a68:      	cmpl	%r15d, %r12d
   14a6b:      	seta	%dil
   14a6f:      	movzbl	%cl, %esi
   14a72:      	addq	%rax, %rbx
   14a75:      	addq	%rbx, %rdi
   14a78:      	movl	$0x4, %eax
   14a7d:      	callq	*%rax
   14a7f:      	movq	%rbx, 0x48(%rsp)
   14a84:      	cmpl	%r15d, %r12d
   14a87:      	jbe	0x16372 <generic_usdt_path+0xba72>
   14a8d:      	movq	0x8(%rsp), %r12
   14a92:      	movq	%r12, 0x30(%rsp)
   14a97:      	movq	0x38(%rsp), %rdx
   14a9c:      	movq	0x40(%rsp), %r15
   14aa1:      	jmp	0x14af4 <generic_usdt_path+0xa1f4>
   14aa3:      	leaq	0x10(%r15), %rdx
   14aa7:      	movl	$0x4, %eax
   14aac:      	movq	%rbp, %rdi
   14aaf:      	movl	$0x8, %esi
   14ab4:      	callq	*%rax
   14ab6:      	movq	0x40(%rsp), %rax
   14abb:      	cmpq	(%rsp), %rax
   14abf:      	je	0x1636d <generic_usdt_path+0xba6d>
   14ac5:      	addq	$0x18, %r15
   14ac9:      	movl	$0x4, %eax
   14ace:      	leaq	0x30(%rsp), %rdi
   14ad3:      	movl	$0x8, %esi
   14ad8:      	movq	%r15, %rdx
   14adb:      	callq	*%rax
   14add:      	movq	(%rsp), %r15
   14ae1:      	movq	%r15, 0x40(%rsp)
   14ae6:      	leaq	0x20(%r15), %rdx
   14aea:      	movq	%rdx, 0x38(%rsp)
   14aef:      	movq	0x30(%rsp), %r12
   14af4:      	cmpq	0x18(%rsp), %r12
   14af9:      	jne	0x14b06 <generic_usdt_path+0xa206>
   14afb:      	cmpq	0x20(%rsp), %rdx
   14b00:      	je	0x1636d <generic_usdt_path+0xba6d>
   14b06:      	movl	$0x4, %eax
   14b0b:      	leaq	0x10(%rsp), %rdi
   14b10:      	movl	$0x8, %esi
   14b15:      	callq	*%rax
   14b17:      	cmpq	0x10(%rsp), %r12
   14b1c:      	je	0x14c14 <generic_usdt_path+0xa314>
   14b22:      	leaq	0x18(%r12), %rbx
   14b27:      	movl	$0x4, %eax
   14b2c:      	movq	%rbp, %rdi
   14b2f:      	movl	$0x8, %esi
   14b34:      	movq	%rbx, %rdx
   14b37:      	callq	*%rax
   14b39:      	cmpq	%r12, (%rsp)
   14b3d:      	je	0x14c14 <generic_usdt_path+0xa314>
   14b43:      	movl	$0x4, %eax
   14b48:      	leaq	0x8(%rsp), %rdi
   14b4d:      	movl	$0x8, %esi
   14b52:      	movq	%rbx, %rdx
   14b55:      	callq	*%rax
   14b57:      	addq	$0x20, %r12
   14b5b:      	movl	$0x4, %eax
   14b60:      	leaq	0x58(%rsp), %rdi
   14b65:      	movl	$0x10, %ecx
   14b6a:      	movl	$0x10, %esi
   14b6f:      	movq	%r12, %rdx
   14b72:      	callq	*%rax
   14b74:      	movq	0x28(%rsp), %rbx
   14b79:      	movq	0x48(%rsp), %rax
   14b7e:      	movl	0x5c(%rsp), %r15d
   14b83:      	subq	%rbx, %rax
   14b86:      	movl	0x50(%rsp), %r12d
   14b8b:      	movl	%r15d, %edx
   14b8e:      	subl	%r12d, %edx
   14b91:      	movl	$0x0, %ecx
   14b96:      	cmovbl	%ecx, %edx
   14b99:      	addq	0x60(%rsp), %rdx
   14b9e:      	xorl	%esi, %esi
   14ba0:      	cmpl	%r15d, %r12d
   14ba3:      	seta	%sil
   14ba7:      	movl	%r15d, %ecx
   14baa:      	cmovbl	%r12d, %ecx
   14bae:      	addl	%ecx, %esi
   14bb0:      	movl	%r12d, %edi
   14bb3:      	subl	%esi, %edi
   14bb5:      	movl	%edi, 0x50(%rsp)
   14bb9:      	subq	%rsi, %rax
   14bbc:      	jb	0x16372 <generic_usdt_path+0xba72>
   14bc2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14bc8:      	ja	0x16372 <generic_usdt_path+0xba72>
   14bce:      	cmpl	%r15d, %r12d
   14bd1:      	jbe	0x14bd7 <generic_usdt_path+0xa2d7>
   14bd3:      	movb	$0x2f, (%rbx,%rax)
   14bd7:      	xorl	%edi, %edi
   14bd9:      	cmpl	%r15d, %r12d
   14bdc:      	seta	%dil
   14be0:      	movzbl	%cl, %esi
   14be3:      	addq	%rax, %rbx
   14be6:      	addq	%rbx, %rdi
   14be9:      	movl	$0x4, %eax
   14bee:      	callq	*%rax
   14bf0:      	movq	%rbx, 0x48(%rsp)
   14bf5:      	cmpl	%r15d, %r12d
   14bf8:      	jbe	0x16372 <generic_usdt_path+0xba72>
   14bfe:      	movq	0x8(%rsp), %r12
   14c03:      	movq	%r12, 0x30(%rsp)
   14c08:      	movq	0x38(%rsp), %rdx
   14c0d:      	movq	0x40(%rsp), %r15
   14c12:      	jmp	0x14c65 <generic_usdt_path+0xa365>
   14c14:      	leaq	0x10(%r15), %rdx
   14c18:      	movl	$0x4, %eax
   14c1d:      	movq	%rbp, %rdi
   14c20:      	movl	$0x8, %esi
   14c25:      	callq	*%rax
   14c27:      	movq	0x40(%rsp), %rax
   14c2c:      	cmpq	(%rsp), %rax
   14c30:      	je	0x1636d <generic_usdt_path+0xba6d>
   14c36:      	addq	$0x18, %r15
   14c3a:      	movl	$0x4, %eax
   14c3f:      	leaq	0x30(%rsp), %rdi
   14c44:      	movl	$0x8, %esi
   14c49:      	movq	%r15, %rdx
   14c4c:      	callq	*%rax
   14c4e:      	movq	(%rsp), %r15
   14c52:      	movq	%r15, 0x40(%rsp)
   14c57:      	leaq	0x20(%r15), %rdx
   14c5b:      	movq	%rdx, 0x38(%rsp)
   14c60:      	movq	0x30(%rsp), %r12
   14c65:      	cmpq	0x18(%rsp), %r12
   14c6a:      	jne	0x14c77 <generic_usdt_path+0xa377>
   14c6c:      	cmpq	0x20(%rsp), %rdx
   14c71:      	je	0x1636d <generic_usdt_path+0xba6d>
   14c77:      	movl	$0x4, %eax
   14c7c:      	leaq	0x10(%rsp), %rdi
   14c81:      	movl	$0x8, %esi
   14c86:      	callq	*%rax
   14c88:      	cmpq	0x10(%rsp), %r12
   14c8d:      	je	0x14d85 <generic_usdt_path+0xa485>
   14c93:      	leaq	0x18(%r12), %rbx
   14c98:      	movl	$0x4, %eax
   14c9d:      	movq	%rbp, %rdi
   14ca0:      	movl	$0x8, %esi
   14ca5:      	movq	%rbx, %rdx
   14ca8:      	callq	*%rax
   14caa:      	cmpq	%r12, (%rsp)
   14cae:      	je	0x14d85 <generic_usdt_path+0xa485>
   14cb4:      	movl	$0x4, %eax
   14cb9:      	leaq	0x8(%rsp), %rdi
   14cbe:      	movl	$0x8, %esi
   14cc3:      	movq	%rbx, %rdx
   14cc6:      	callq	*%rax
   14cc8:      	addq	$0x20, %r12
   14ccc:      	movl	$0x4, %eax
   14cd1:      	leaq	0x58(%rsp), %rdi
   14cd6:      	movl	$0x10, %ecx
   14cdb:      	movl	$0x10, %esi
   14ce0:      	movq	%r12, %rdx
   14ce3:      	callq	*%rax
   14ce5:      	movq	0x28(%rsp), %rbx
   14cea:      	movq	0x48(%rsp), %rax
   14cef:      	movl	0x5c(%rsp), %r15d
   14cf4:      	subq	%rbx, %rax
   14cf7:      	movl	0x50(%rsp), %r12d
   14cfc:      	movl	%r15d, %edx
   14cff:      	subl	%r12d, %edx
   14d02:      	movl	$0x0, %ecx
   14d07:      	cmovbl	%ecx, %edx
   14d0a:      	addq	0x60(%rsp), %rdx
   14d0f:      	xorl	%esi, %esi
   14d11:      	cmpl	%r15d, %r12d
   14d14:      	seta	%sil
   14d18:      	movl	%r15d, %ecx
   14d1b:      	cmovbl	%r12d, %ecx
   14d1f:      	addl	%ecx, %esi
   14d21:      	movl	%r12d, %edi
   14d24:      	subl	%esi, %edi
   14d26:      	movl	%edi, 0x50(%rsp)
   14d2a:      	subq	%rsi, %rax
   14d2d:      	jb	0x16372 <generic_usdt_path+0xba72>
   14d33:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14d39:      	ja	0x16372 <generic_usdt_path+0xba72>
   14d3f:      	cmpl	%r15d, %r12d
   14d42:      	jbe	0x14d48 <generic_usdt_path+0xa448>
   14d44:      	movb	$0x2f, (%rbx,%rax)
   14d48:      	xorl	%edi, %edi
   14d4a:      	cmpl	%r15d, %r12d
   14d4d:      	seta	%dil
   14d51:      	movzbl	%cl, %esi
   14d54:      	addq	%rax, %rbx
   14d57:      	addq	%rbx, %rdi
   14d5a:      	movl	$0x4, %eax
   14d5f:      	callq	*%rax
   14d61:      	movq	%rbx, 0x48(%rsp)
   14d66:      	cmpl	%r15d, %r12d
   14d69:      	jbe	0x16372 <generic_usdt_path+0xba72>
   14d6f:      	movq	0x8(%rsp), %r12
   14d74:      	movq	%r12, 0x30(%rsp)
   14d79:      	movq	0x38(%rsp), %rdx
   14d7e:      	movq	0x40(%rsp), %r15
   14d83:      	jmp	0x14dd6 <generic_usdt_path+0xa4d6>
   14d85:      	leaq	0x10(%r15), %rdx
   14d89:      	movl	$0x4, %eax
   14d8e:      	movq	%rbp, %rdi
   14d91:      	movl	$0x8, %esi
   14d96:      	callq	*%rax
   14d98:      	movq	0x40(%rsp), %rax
   14d9d:      	cmpq	(%rsp), %rax
   14da1:      	je	0x1636d <generic_usdt_path+0xba6d>
   14da7:      	addq	$0x18, %r15
   14dab:      	movl	$0x4, %eax
   14db0:      	leaq	0x30(%rsp), %rdi
   14db5:      	movl	$0x8, %esi
   14dba:      	movq	%r15, %rdx
   14dbd:      	callq	*%rax
   14dbf:      	movq	(%rsp), %r15
   14dc3:      	movq	%r15, 0x40(%rsp)
   14dc8:      	leaq	0x20(%r15), %rdx
   14dcc:      	movq	%rdx, 0x38(%rsp)
   14dd1:      	movq	0x30(%rsp), %r12
   14dd6:      	cmpq	0x18(%rsp), %r12
   14ddb:      	jne	0x14de8 <generic_usdt_path+0xa4e8>
   14ddd:      	cmpq	0x20(%rsp), %rdx
   14de2:      	je	0x1636d <generic_usdt_path+0xba6d>
   14de8:      	movl	$0x4, %eax
   14ded:      	leaq	0x10(%rsp), %rdi
   14df2:      	movl	$0x8, %esi
   14df7:      	callq	*%rax
   14df9:      	cmpq	0x10(%rsp), %r12
   14dfe:      	je	0x14ef6 <generic_usdt_path+0xa5f6>
   14e04:      	leaq	0x18(%r12), %rbx
   14e09:      	movl	$0x4, %eax
   14e0e:      	movq	%rbp, %rdi
   14e11:      	movl	$0x8, %esi
   14e16:      	movq	%rbx, %rdx
   14e19:      	callq	*%rax
   14e1b:      	cmpq	%r12, (%rsp)
   14e1f:      	je	0x14ef6 <generic_usdt_path+0xa5f6>
   14e25:      	movl	$0x4, %eax
   14e2a:      	leaq	0x8(%rsp), %rdi
   14e2f:      	movl	$0x8, %esi
   14e34:      	movq	%rbx, %rdx
   14e37:      	callq	*%rax
   14e39:      	addq	$0x20, %r12
   14e3d:      	movl	$0x4, %eax
   14e42:      	leaq	0x58(%rsp), %rdi
   14e47:      	movl	$0x10, %ecx
   14e4c:      	movl	$0x10, %esi
   14e51:      	movq	%r12, %rdx
   14e54:      	callq	*%rax
   14e56:      	movq	0x28(%rsp), %rbx
   14e5b:      	movq	0x48(%rsp), %rax
   14e60:      	movl	0x5c(%rsp), %r15d
   14e65:      	subq	%rbx, %rax
   14e68:      	movl	0x50(%rsp), %r12d
   14e6d:      	movl	%r15d, %edx
   14e70:      	subl	%r12d, %edx
   14e73:      	movl	$0x0, %ecx
   14e78:      	cmovbl	%ecx, %edx
   14e7b:      	addq	0x60(%rsp), %rdx
   14e80:      	xorl	%esi, %esi
   14e82:      	cmpl	%r15d, %r12d
   14e85:      	seta	%sil
   14e89:      	movl	%r15d, %ecx
   14e8c:      	cmovbl	%r12d, %ecx
   14e90:      	addl	%ecx, %esi
   14e92:      	movl	%r12d, %edi
   14e95:      	subl	%esi, %edi
   14e97:      	movl	%edi, 0x50(%rsp)
   14e9b:      	subq	%rsi, %rax
   14e9e:      	jb	0x16372 <generic_usdt_path+0xba72>
   14ea4:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   14eaa:      	ja	0x16372 <generic_usdt_path+0xba72>
   14eb0:      	cmpl	%r15d, %r12d
   14eb3:      	jbe	0x14eb9 <generic_usdt_path+0xa5b9>
   14eb5:      	movb	$0x2f, (%rbx,%rax)
   14eb9:      	xorl	%edi, %edi
   14ebb:      	cmpl	%r15d, %r12d
   14ebe:      	seta	%dil
   14ec2:      	movzbl	%cl, %esi
   14ec5:      	addq	%rax, %rbx
   14ec8:      	addq	%rbx, %rdi
   14ecb:      	movl	$0x4, %eax
   14ed0:      	callq	*%rax
   14ed2:      	movq	%rbx, 0x48(%rsp)
   14ed7:      	cmpl	%r15d, %r12d
   14eda:      	jbe	0x16372 <generic_usdt_path+0xba72>
   14ee0:      	movq	0x8(%rsp), %r12
   14ee5:      	movq	%r12, 0x30(%rsp)
   14eea:      	movq	0x38(%rsp), %rdx
   14eef:      	movq	0x40(%rsp), %r15
   14ef4:      	jmp	0x14f47 <generic_usdt_path+0xa647>
   14ef6:      	leaq	0x10(%r15), %rdx
   14efa:      	movl	$0x4, %eax
   14eff:      	movq	%rbp, %rdi
   14f02:      	movl	$0x8, %esi
   14f07:      	callq	*%rax
   14f09:      	movq	0x40(%rsp), %rax
   14f0e:      	cmpq	(%rsp), %rax
   14f12:      	je	0x1636d <generic_usdt_path+0xba6d>
   14f18:      	addq	$0x18, %r15
   14f1c:      	movl	$0x4, %eax
   14f21:      	leaq	0x30(%rsp), %rdi
   14f26:      	movl	$0x8, %esi
   14f2b:      	movq	%r15, %rdx
   14f2e:      	callq	*%rax
   14f30:      	movq	(%rsp), %r15
   14f34:      	movq	%r15, 0x40(%rsp)
   14f39:      	leaq	0x20(%r15), %rdx
   14f3d:      	movq	%rdx, 0x38(%rsp)
   14f42:      	movq	0x30(%rsp), %r12
   14f47:      	cmpq	0x18(%rsp), %r12
   14f4c:      	jne	0x14f59 <generic_usdt_path+0xa659>
   14f4e:      	cmpq	0x20(%rsp), %rdx
   14f53:      	je	0x1636d <generic_usdt_path+0xba6d>
   14f59:      	movl	$0x4, %eax
   14f5e:      	leaq	0x10(%rsp), %rdi
   14f63:      	movl	$0x8, %esi
   14f68:      	callq	*%rax
   14f6a:      	cmpq	0x10(%rsp), %r12
   14f6f:      	je	0x15067 <generic_usdt_path+0xa767>
   14f75:      	leaq	0x18(%r12), %rbx
   14f7a:      	movl	$0x4, %eax
   14f7f:      	movq	%rbp, %rdi
   14f82:      	movl	$0x8, %esi
   14f87:      	movq	%rbx, %rdx
   14f8a:      	callq	*%rax
   14f8c:      	cmpq	%r12, (%rsp)
   14f90:      	je	0x15067 <generic_usdt_path+0xa767>
   14f96:      	movl	$0x4, %eax
   14f9b:      	leaq	0x8(%rsp), %rdi
   14fa0:      	movl	$0x8, %esi
   14fa5:      	movq	%rbx, %rdx
   14fa8:      	callq	*%rax
   14faa:      	addq	$0x20, %r12
   14fae:      	movl	$0x4, %eax
   14fb3:      	leaq	0x58(%rsp), %rdi
   14fb8:      	movl	$0x10, %ecx
   14fbd:      	movl	$0x10, %esi
   14fc2:      	movq	%r12, %rdx
   14fc5:      	callq	*%rax
   14fc7:      	movq	0x28(%rsp), %rbx
   14fcc:      	movq	0x48(%rsp), %rax
   14fd1:      	movl	0x5c(%rsp), %r15d
   14fd6:      	subq	%rbx, %rax
   14fd9:      	movl	0x50(%rsp), %r12d
   14fde:      	movl	%r15d, %edx
   14fe1:      	subl	%r12d, %edx
   14fe4:      	movl	$0x0, %ecx
   14fe9:      	cmovbl	%ecx, %edx
   14fec:      	addq	0x60(%rsp), %rdx
   14ff1:      	xorl	%esi, %esi
   14ff3:      	cmpl	%r15d, %r12d
   14ff6:      	seta	%sil
   14ffa:      	movl	%r15d, %ecx
   14ffd:      	cmovbl	%r12d, %ecx
   15001:      	addl	%ecx, %esi
   15003:      	movl	%r12d, %edi
   15006:      	subl	%esi, %edi
   15008:      	movl	%edi, 0x50(%rsp)
   1500c:      	subq	%rsi, %rax
   1500f:      	jb	0x16372 <generic_usdt_path+0xba72>
   15015:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1501b:      	ja	0x16372 <generic_usdt_path+0xba72>
   15021:      	cmpl	%r15d, %r12d
   15024:      	jbe	0x1502a <generic_usdt_path+0xa72a>
   15026:      	movb	$0x2f, (%rbx,%rax)
   1502a:      	xorl	%edi, %edi
   1502c:      	cmpl	%r15d, %r12d
   1502f:      	seta	%dil
   15033:      	movzbl	%cl, %esi
   15036:      	addq	%rax, %rbx
   15039:      	addq	%rbx, %rdi
   1503c:      	movl	$0x4, %eax
   15041:      	callq	*%rax
   15043:      	movq	%rbx, 0x48(%rsp)
   15048:      	cmpl	%r15d, %r12d
   1504b:      	jbe	0x16372 <generic_usdt_path+0xba72>
   15051:      	movq	0x8(%rsp), %r12
   15056:      	movq	%r12, 0x30(%rsp)
   1505b:      	movq	0x38(%rsp), %rdx
   15060:      	movq	0x40(%rsp), %r15
   15065:      	jmp	0x150b8 <generic_usdt_path+0xa7b8>
   15067:      	leaq	0x10(%r15), %rdx
   1506b:      	movl	$0x4, %eax
   15070:      	movq	%rbp, %rdi
   15073:      	movl	$0x8, %esi
   15078:      	callq	*%rax
   1507a:      	movq	0x40(%rsp), %rax
   1507f:      	cmpq	(%rsp), %rax
   15083:      	je	0x1636d <generic_usdt_path+0xba6d>
   15089:      	addq	$0x18, %r15
   1508d:      	movl	$0x4, %eax
   15092:      	leaq	0x30(%rsp), %rdi
   15097:      	movl	$0x8, %esi
   1509c:      	movq	%r15, %rdx
   1509f:      	callq	*%rax
   150a1:      	movq	(%rsp), %r15
   150a5:      	movq	%r15, 0x40(%rsp)
   150aa:      	leaq	0x20(%r15), %rdx
   150ae:      	movq	%rdx, 0x38(%rsp)
   150b3:      	movq	0x30(%rsp), %r12
   150b8:      	cmpq	0x18(%rsp), %r12
   150bd:      	jne	0x150ca <generic_usdt_path+0xa7ca>
   150bf:      	cmpq	0x20(%rsp), %rdx
   150c4:      	je	0x1636d <generic_usdt_path+0xba6d>
   150ca:      	movl	$0x4, %eax
   150cf:      	leaq	0x10(%rsp), %rdi
   150d4:      	movl	$0x8, %esi
   150d9:      	callq	*%rax
   150db:      	cmpq	0x10(%rsp), %r12
   150e0:      	je	0x151d8 <generic_usdt_path+0xa8d8>
   150e6:      	leaq	0x18(%r12), %rbx
   150eb:      	movl	$0x4, %eax
   150f0:      	movq	%rbp, %rdi
   150f3:      	movl	$0x8, %esi
   150f8:      	movq	%rbx, %rdx
   150fb:      	callq	*%rax
   150fd:      	cmpq	%r12, (%rsp)
   15101:      	je	0x151d8 <generic_usdt_path+0xa8d8>
   15107:      	movl	$0x4, %eax
   1510c:      	leaq	0x8(%rsp), %rdi
   15111:      	movl	$0x8, %esi
   15116:      	movq	%rbx, %rdx
   15119:      	callq	*%rax
   1511b:      	addq	$0x20, %r12
   1511f:      	movl	$0x4, %eax
   15124:      	leaq	0x58(%rsp), %rdi
   15129:      	movl	$0x10, %ecx
   1512e:      	movl	$0x10, %esi
   15133:      	movq	%r12, %rdx
   15136:      	callq	*%rax
   15138:      	movq	0x28(%rsp), %rbx
   1513d:      	movq	0x48(%rsp), %rax
   15142:      	movl	0x5c(%rsp), %r15d
   15147:      	subq	%rbx, %rax
   1514a:      	movl	0x50(%rsp), %r12d
   1514f:      	movl	%r15d, %edx
   15152:      	subl	%r12d, %edx
   15155:      	movl	$0x0, %ecx
   1515a:      	cmovbl	%ecx, %edx
   1515d:      	addq	0x60(%rsp), %rdx
   15162:      	xorl	%esi, %esi
   15164:      	cmpl	%r15d, %r12d
   15167:      	seta	%sil
   1516b:      	movl	%r15d, %ecx
   1516e:      	cmovbl	%r12d, %ecx
   15172:      	addl	%ecx, %esi
   15174:      	movl	%r12d, %edi
   15177:      	subl	%esi, %edi
   15179:      	movl	%edi, 0x50(%rsp)
   1517d:      	subq	%rsi, %rax
   15180:      	jb	0x16372 <generic_usdt_path+0xba72>
   15186:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1518c:      	ja	0x16372 <generic_usdt_path+0xba72>
   15192:      	cmpl	%r15d, %r12d
   15195:      	jbe	0x1519b <generic_usdt_path+0xa89b>
   15197:      	movb	$0x2f, (%rbx,%rax)
   1519b:      	xorl	%edi, %edi
   1519d:      	cmpl	%r15d, %r12d
   151a0:      	seta	%dil
   151a4:      	movzbl	%cl, %esi
   151a7:      	addq	%rax, %rbx
   151aa:      	addq	%rbx, %rdi
   151ad:      	movl	$0x4, %eax
   151b2:      	callq	*%rax
   151b4:      	movq	%rbx, 0x48(%rsp)
   151b9:      	cmpl	%r15d, %r12d
   151bc:      	jbe	0x16372 <generic_usdt_path+0xba72>
   151c2:      	movq	0x8(%rsp), %r12
   151c7:      	movq	%r12, 0x30(%rsp)
   151cc:      	movq	0x38(%rsp), %rdx
   151d1:      	movq	0x40(%rsp), %r15
   151d6:      	jmp	0x15229 <generic_usdt_path+0xa929>
   151d8:      	leaq	0x10(%r15), %rdx
   151dc:      	movl	$0x4, %eax
   151e1:      	movq	%rbp, %rdi
   151e4:      	movl	$0x8, %esi
   151e9:      	callq	*%rax
   151eb:      	movq	0x40(%rsp), %rax
   151f0:      	cmpq	(%rsp), %rax
   151f4:      	je	0x1636d <generic_usdt_path+0xba6d>
   151fa:      	addq	$0x18, %r15
   151fe:      	movl	$0x4, %eax
   15203:      	leaq	0x30(%rsp), %rdi
   15208:      	movl	$0x8, %esi
   1520d:      	movq	%r15, %rdx
   15210:      	callq	*%rax
   15212:      	movq	(%rsp), %r15
   15216:      	movq	%r15, 0x40(%rsp)
   1521b:      	leaq	0x20(%r15), %rdx
   1521f:      	movq	%rdx, 0x38(%rsp)
   15224:      	movq	0x30(%rsp), %r12
   15229:      	cmpq	0x18(%rsp), %r12
   1522e:      	jne	0x1523b <generic_usdt_path+0xa93b>
   15230:      	cmpq	0x20(%rsp), %rdx
   15235:      	je	0x1636d <generic_usdt_path+0xba6d>
   1523b:      	movl	$0x4, %eax
   15240:      	leaq	0x10(%rsp), %rdi
   15245:      	movl	$0x8, %esi
   1524a:      	callq	*%rax
   1524c:      	cmpq	0x10(%rsp), %r12
   15251:      	je	0x15349 <generic_usdt_path+0xaa49>
   15257:      	leaq	0x18(%r12), %rbx
   1525c:      	movl	$0x4, %eax
   15261:      	movq	%rbp, %rdi
   15264:      	movl	$0x8, %esi
   15269:      	movq	%rbx, %rdx
   1526c:      	callq	*%rax
   1526e:      	cmpq	%r12, (%rsp)
   15272:      	je	0x15349 <generic_usdt_path+0xaa49>
   15278:      	movl	$0x4, %eax
   1527d:      	leaq	0x8(%rsp), %rdi
   15282:      	movl	$0x8, %esi
   15287:      	movq	%rbx, %rdx
   1528a:      	callq	*%rax
   1528c:      	addq	$0x20, %r12
   15290:      	movl	$0x4, %eax
   15295:      	leaq	0x58(%rsp), %rdi
   1529a:      	movl	$0x10, %ecx
   1529f:      	movl	$0x10, %esi
   152a4:      	movq	%r12, %rdx
   152a7:      	callq	*%rax
   152a9:      	movq	0x28(%rsp), %rbx
   152ae:      	movq	0x48(%rsp), %rax
   152b3:      	movl	0x5c(%rsp), %r15d
   152b8:      	subq	%rbx, %rax
   152bb:      	movl	0x50(%rsp), %r12d
   152c0:      	movl	%r15d, %edx
   152c3:      	subl	%r12d, %edx
   152c6:      	movl	$0x0, %ecx
   152cb:      	cmovbl	%ecx, %edx
   152ce:      	addq	0x60(%rsp), %rdx
   152d3:      	xorl	%esi, %esi
   152d5:      	cmpl	%r15d, %r12d
   152d8:      	seta	%sil
   152dc:      	movl	%r15d, %ecx
   152df:      	cmovbl	%r12d, %ecx
   152e3:      	addl	%ecx, %esi
   152e5:      	movl	%r12d, %edi
   152e8:      	subl	%esi, %edi
   152ea:      	movl	%edi, 0x50(%rsp)
   152ee:      	subq	%rsi, %rax
   152f1:      	jb	0x16372 <generic_usdt_path+0xba72>
   152f7:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   152fd:      	ja	0x16372 <generic_usdt_path+0xba72>
   15303:      	cmpl	%r15d, %r12d
   15306:      	jbe	0x1530c <generic_usdt_path+0xaa0c>
   15308:      	movb	$0x2f, (%rbx,%rax)
   1530c:      	xorl	%edi, %edi
   1530e:      	cmpl	%r15d, %r12d
   15311:      	seta	%dil
   15315:      	movzbl	%cl, %esi
   15318:      	addq	%rax, %rbx
   1531b:      	addq	%rbx, %rdi
   1531e:      	movl	$0x4, %eax
   15323:      	callq	*%rax
   15325:      	movq	%rbx, 0x48(%rsp)
   1532a:      	cmpl	%r15d, %r12d
   1532d:      	jbe	0x16372 <generic_usdt_path+0xba72>
   15333:      	movq	0x8(%rsp), %r12
   15338:      	movq	%r12, 0x30(%rsp)
   1533d:      	movq	0x38(%rsp), %rdx
   15342:      	movq	0x40(%rsp), %r15
   15347:      	jmp	0x1539a <generic_usdt_path+0xaa9a>
   15349:      	leaq	0x10(%r15), %rdx
   1534d:      	movl	$0x4, %eax
   15352:      	movq	%rbp, %rdi
   15355:      	movl	$0x8, %esi
   1535a:      	callq	*%rax
   1535c:      	movq	0x40(%rsp), %rax
   15361:      	cmpq	(%rsp), %rax
   15365:      	je	0x1636d <generic_usdt_path+0xba6d>
   1536b:      	addq	$0x18, %r15
   1536f:      	movl	$0x4, %eax
   15374:      	leaq	0x30(%rsp), %rdi
   15379:      	movl	$0x8, %esi
   1537e:      	movq	%r15, %rdx
   15381:      	callq	*%rax
   15383:      	movq	(%rsp), %r15
   15387:      	movq	%r15, 0x40(%rsp)
   1538c:      	leaq	0x20(%r15), %rdx
   15390:      	movq	%rdx, 0x38(%rsp)
   15395:      	movq	0x30(%rsp), %r12
   1539a:      	cmpq	0x18(%rsp), %r12
   1539f:      	jne	0x153ac <generic_usdt_path+0xaaac>
   153a1:      	cmpq	0x20(%rsp), %rdx
   153a6:      	je	0x1636d <generic_usdt_path+0xba6d>
   153ac:      	movl	$0x4, %eax
   153b1:      	leaq	0x10(%rsp), %rdi
   153b6:      	movl	$0x8, %esi
   153bb:      	callq	*%rax
   153bd:      	cmpq	0x10(%rsp), %r12
   153c2:      	je	0x154ba <generic_usdt_path+0xabba>
   153c8:      	leaq	0x18(%r12), %rbx
   153cd:      	movl	$0x4, %eax
   153d2:      	movq	%rbp, %rdi
   153d5:      	movl	$0x8, %esi
   153da:      	movq	%rbx, %rdx
   153dd:      	callq	*%rax
   153df:      	cmpq	%r12, (%rsp)
   153e3:      	je	0x154ba <generic_usdt_path+0xabba>
   153e9:      	movl	$0x4, %eax
   153ee:      	leaq	0x8(%rsp), %rdi
   153f3:      	movl	$0x8, %esi
   153f8:      	movq	%rbx, %rdx
   153fb:      	callq	*%rax
   153fd:      	addq	$0x20, %r12
   15401:      	movl	$0x4, %eax
   15406:      	leaq	0x58(%rsp), %rdi
   1540b:      	movl	$0x10, %ecx
   15410:      	movl	$0x10, %esi
   15415:      	movq	%r12, %rdx
   15418:      	callq	*%rax
   1541a:      	movq	0x28(%rsp), %rbx
   1541f:      	movq	0x48(%rsp), %rax
   15424:      	movl	0x5c(%rsp), %r15d
   15429:      	subq	%rbx, %rax
   1542c:      	movl	0x50(%rsp), %r12d
   15431:      	movl	%r15d, %edx
   15434:      	subl	%r12d, %edx
   15437:      	movl	$0x0, %ecx
   1543c:      	cmovbl	%ecx, %edx
   1543f:      	addq	0x60(%rsp), %rdx
   15444:      	xorl	%esi, %esi
   15446:      	cmpl	%r15d, %r12d
   15449:      	seta	%sil
   1544d:      	movl	%r15d, %ecx
   15450:      	cmovbl	%r12d, %ecx
   15454:      	addl	%ecx, %esi
   15456:      	movl	%r12d, %edi
   15459:      	subl	%esi, %edi
   1545b:      	movl	%edi, 0x50(%rsp)
   1545f:      	subq	%rsi, %rax
   15462:      	jb	0x16372 <generic_usdt_path+0xba72>
   15468:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   1546e:      	ja	0x16372 <generic_usdt_path+0xba72>
   15474:      	cmpl	%r15d, %r12d
   15477:      	jbe	0x1547d <generic_usdt_path+0xab7d>
   15479:      	movb	$0x2f, (%rbx,%rax)
   1547d:      	xorl	%edi, %edi
   1547f:      	cmpl	%r15d, %r12d
   15482:      	seta	%dil
   15486:      	movzbl	%cl, %esi
   15489:      	addq	%rax, %rbx
   1548c:      	addq	%rbx, %rdi
   1548f:      	movl	$0x4, %eax
   15494:      	callq	*%rax
   15496:      	movq	%rbx, 0x48(%rsp)
   1549b:      	cmpl	%r15d, %r12d
   1549e:      	jbe	0x16372 <generic_usdt_path+0xba72>
   154a4:      	movq	0x8(%rsp), %r12
   154a9:      	movq	%r12, 0x30(%rsp)
   154ae:      	movq	0x38(%rsp), %rdx
   154b3:      	movq	0x40(%rsp), %r15
   154b8:      	jmp	0x1550b <generic_usdt_path+0xac0b>
   154ba:      	leaq	0x10(%r15), %rdx
   154be:      	movl	$0x4, %eax
   154c3:      	movq	%rbp, %rdi
   154c6:      	movl	$0x8, %esi
   154cb:      	callq	*%rax
   154cd:      	movq	0x40(%rsp), %rax
   154d2:      	cmpq	(%rsp), %rax
   154d6:      	je	0x1636d <generic_usdt_path+0xba6d>
   154dc:      	addq	$0x18, %r15
   154e0:      	movl	$0x4, %eax
   154e5:      	leaq	0x30(%rsp), %rdi
   154ea:      	movl	$0x8, %esi
   154ef:      	movq	%r15, %rdx
   154f2:      	callq	*%rax
   154f4:      	movq	(%rsp), %r15
   154f8:      	movq	%r15, 0x40(%rsp)
   154fd:      	leaq	0x20(%r15), %rdx
   15501:      	movq	%rdx, 0x38(%rsp)
   15506:      	movq	0x30(%rsp), %r12
   1550b:      	cmpq	0x18(%rsp), %r12
   15510:      	jne	0x1551d <generic_usdt_path+0xac1d>
   15512:      	cmpq	0x20(%rsp), %rdx
   15517:      	je	0x1636d <generic_usdt_path+0xba6d>
   1551d:      	movl	$0x4, %eax
   15522:      	leaq	0x10(%rsp), %rdi
   15527:      	movl	$0x8, %esi
   1552c:      	callq	*%rax
   1552e:      	cmpq	0x10(%rsp), %r12
   15533:      	je	0x1562b <generic_usdt_path+0xad2b>
   15539:      	leaq	0x18(%r12), %rbx
   1553e:      	movl	$0x4, %eax
   15543:      	movq	%rbp, %rdi
   15546:      	movl	$0x8, %esi
   1554b:      	movq	%rbx, %rdx
   1554e:      	callq	*%rax
   15550:      	cmpq	%r12, (%rsp)
   15554:      	je	0x1562b <generic_usdt_path+0xad2b>
   1555a:      	movl	$0x4, %eax
   1555f:      	leaq	0x8(%rsp), %rdi
   15564:      	movl	$0x8, %esi
   15569:      	movq	%rbx, %rdx
   1556c:      	callq	*%rax
   1556e:      	addq	$0x20, %r12
   15572:      	movl	$0x4, %eax
   15577:      	leaq	0x58(%rsp), %rdi
   1557c:      	movl	$0x10, %ecx
   15581:      	movl	$0x10, %esi
   15586:      	movq	%r12, %rdx
   15589:      	callq	*%rax
   1558b:      	movq	0x28(%rsp), %rbx
   15590:      	movq	0x48(%rsp), %rax
   15595:      	movl	0x5c(%rsp), %r15d
   1559a:      	subq	%rbx, %rax
   1559d:      	movl	0x50(%rsp), %r12d
   155a2:      	movl	%r15d, %edx
   155a5:      	subl	%r12d, %edx
   155a8:      	movl	$0x0, %ecx
   155ad:      	cmovbl	%ecx, %edx
   155b0:      	addq	0x60(%rsp), %rdx
   155b5:      	xorl	%esi, %esi
   155b7:      	cmpl	%r15d, %r12d
   155ba:      	seta	%sil
   155be:      	movl	%r15d, %ecx
   155c1:      	cmovbl	%r12d, %ecx
   155c5:      	addl	%ecx, %esi
   155c7:      	movl	%r12d, %edi
   155ca:      	subl	%esi, %edi
   155cc:      	movl	%edi, 0x50(%rsp)
   155d0:      	subq	%rsi, %rax
   155d3:      	jb	0x16372 <generic_usdt_path+0xba72>
   155d9:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   155df:      	ja	0x16372 <generic_usdt_path+0xba72>
   155e5:      	cmpl	%r15d, %r12d
   155e8:      	jbe	0x155ee <generic_usdt_path+0xacee>
   155ea:      	movb	$0x2f, (%rbx,%rax)
   155ee:      	xorl	%edi, %edi
   155f0:      	cmpl	%r15d, %r12d
   155f3:      	seta	%dil
   155f7:      	movzbl	%cl, %esi
   155fa:      	addq	%rax, %rbx
   155fd:      	addq	%rbx, %rdi
   15600:      	movl	$0x4, %eax
   15605:      	callq	*%rax
   15607:      	movq	%rbx, 0x48(%rsp)
   1560c:      	cmpl	%r15d, %r12d
   1560f:      	jbe	0x16372 <generic_usdt_path+0xba72>
   15615:      	movq	0x8(%rsp), %r12
   1561a:      	movq	%r12, 0x30(%rsp)
   1561f:      	movq	0x38(%rsp), %rdx
   15624:      	movq	0x40(%rsp), %r15
   15629:      	jmp	0x1567c <generic_usdt_path+0xad7c>
   1562b:      	leaq	0x10(%r15), %rdx
   1562f:      	movl	$0x4, %eax
   15634:      	movq	%rbp, %rdi
   15637:      	movl	$0x8, %esi
   1563c:      	callq	*%rax
   1563e:      	movq	0x40(%rsp), %rax
   15643:      	cmpq	(%rsp), %rax
   15647:      	je	0x1636d <generic_usdt_path+0xba6d>
   1564d:      	addq	$0x18, %r15
   15651:      	movl	$0x4, %eax
   15656:      	leaq	0x30(%rsp), %rdi
   1565b:      	movl	$0x8, %esi
   15660:      	movq	%r15, %rdx
   15663:      	callq	*%rax
   15665:      	movq	(%rsp), %r15
   15669:      	movq	%r15, 0x40(%rsp)
   1566e:      	leaq	0x20(%r15), %rdx
   15672:      	movq	%rdx, 0x38(%rsp)
   15677:      	movq	0x30(%rsp), %r12
   1567c:      	cmpq	0x18(%rsp), %r12
   15681:      	jne	0x1568e <generic_usdt_path+0xad8e>
   15683:      	cmpq	0x20(%rsp), %rdx
   15688:      	je	0x1636d <generic_usdt_path+0xba6d>
   1568e:      	movl	$0x4, %eax
   15693:      	leaq	0x10(%rsp), %rdi
   15698:      	movl	$0x8, %esi
   1569d:      	callq	*%rax
   1569f:      	cmpq	0x10(%rsp), %r12
   156a4:      	je	0x1579c <generic_usdt_path+0xae9c>
   156aa:      	leaq	0x18(%r12), %rbx
   156af:      	movl	$0x4, %eax
   156b4:      	movq	%rbp, %rdi
   156b7:      	movl	$0x8, %esi
   156bc:      	movq	%rbx, %rdx
   156bf:      	callq	*%rax
   156c1:      	cmpq	%r12, (%rsp)
   156c5:      	je	0x1579c <generic_usdt_path+0xae9c>
   156cb:      	movl	$0x4, %eax
   156d0:      	leaq	0x8(%rsp), %rdi
   156d5:      	movl	$0x8, %esi
   156da:      	movq	%rbx, %rdx
   156dd:      	callq	*%rax
   156df:      	addq	$0x20, %r12
   156e3:      	movl	$0x4, %eax
   156e8:      	leaq	0x58(%rsp), %rdi
   156ed:      	movl	$0x10, %ecx
   156f2:      	movl	$0x10, %esi
   156f7:      	movq	%r12, %rdx
   156fa:      	callq	*%rax
   156fc:      	movq	0x28(%rsp), %rbx
   15701:      	movq	0x48(%rsp), %rax
   15706:      	movl	0x5c(%rsp), %r15d
   1570b:      	subq	%rbx, %rax
   1570e:      	movl	0x50(%rsp), %r12d
   15713:      	movl	%r15d, %edx
   15716:      	subl	%r12d, %edx
   15719:      	movl	$0x0, %ecx
   1571e:      	cmovbl	%ecx, %edx
   15721:      	addq	0x60(%rsp), %rdx
   15726:      	xorl	%esi, %esi
   15728:      	cmpl	%r15d, %r12d
   1572b:      	seta	%sil
   1572f:      	movl	%r15d, %ecx
   15732:      	cmovbl	%r12d, %ecx
   15736:      	addl	%ecx, %esi
   15738:      	movl	%r12d, %edi
   1573b:      	subl	%esi, %edi
   1573d:      	movl	%edi, 0x50(%rsp)
   15741:      	subq	%rsi, %rax
   15744:      	jb	0x16372 <generic_usdt_path+0xba72>
   1574a:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15750:      	ja	0x16372 <generic_usdt_path+0xba72>
   15756:      	cmpl	%r15d, %r12d
   15759:      	jbe	0x1575f <generic_usdt_path+0xae5f>
   1575b:      	movb	$0x2f, (%rbx,%rax)
   1575f:      	xorl	%edi, %edi
   15761:      	cmpl	%r15d, %r12d
   15764:      	seta	%dil
   15768:      	movzbl	%cl, %esi
   1576b:      	addq	%rax, %rbx
   1576e:      	addq	%rbx, %rdi
   15771:      	movl	$0x4, %eax
   15776:      	callq	*%rax
   15778:      	movq	%rbx, 0x48(%rsp)
   1577d:      	cmpl	%r15d, %r12d
   15780:      	jbe	0x16372 <generic_usdt_path+0xba72>
   15786:      	movq	0x8(%rsp), %r12
   1578b:      	movq	%r12, 0x30(%rsp)
   15790:      	movq	0x38(%rsp), %rdx
   15795:      	movq	0x40(%rsp), %r15
   1579a:      	jmp	0x157ed <generic_usdt_path+0xaeed>
   1579c:      	leaq	0x10(%r15), %rdx
   157a0:      	movl	$0x4, %eax
   157a5:      	movq	%rbp, %rdi
   157a8:      	movl	$0x8, %esi
   157ad:      	callq	*%rax
   157af:      	movq	0x40(%rsp), %rax
   157b4:      	cmpq	(%rsp), %rax
   157b8:      	je	0x1636d <generic_usdt_path+0xba6d>
   157be:      	addq	$0x18, %r15
   157c2:      	movl	$0x4, %eax
   157c7:      	leaq	0x30(%rsp), %rdi
   157cc:      	movl	$0x8, %esi
   157d1:      	movq	%r15, %rdx
   157d4:      	callq	*%rax
   157d6:      	movq	(%rsp), %r15
   157da:      	movq	%r15, 0x40(%rsp)
   157df:      	leaq	0x20(%r15), %rdx
   157e3:      	movq	%rdx, 0x38(%rsp)
   157e8:      	movq	0x30(%rsp), %r12
   157ed:      	cmpq	0x18(%rsp), %r12
   157f2:      	jne	0x157ff <generic_usdt_path+0xaeff>
   157f4:      	cmpq	0x20(%rsp), %rdx
   157f9:      	je	0x1636d <generic_usdt_path+0xba6d>
   157ff:      	movl	$0x4, %eax
   15804:      	leaq	0x10(%rsp), %rdi
   15809:      	movl	$0x8, %esi
   1580e:      	callq	*%rax
   15810:      	cmpq	0x10(%rsp), %r12
   15815:      	je	0x1590d <generic_usdt_path+0xb00d>
   1581b:      	leaq	0x18(%r12), %rbx
   15820:      	movl	$0x4, %eax
   15825:      	movq	%rbp, %rdi
   15828:      	movl	$0x8, %esi
   1582d:      	movq	%rbx, %rdx
   15830:      	callq	*%rax
   15832:      	cmpq	%r12, (%rsp)
   15836:      	je	0x1590d <generic_usdt_path+0xb00d>
   1583c:      	movl	$0x4, %eax
   15841:      	leaq	0x8(%rsp), %rdi
   15846:      	movl	$0x8, %esi
   1584b:      	movq	%rbx, %rdx
   1584e:      	callq	*%rax
   15850:      	addq	$0x20, %r12
   15854:      	movl	$0x4, %eax
   15859:      	leaq	0x58(%rsp), %rdi
   1585e:      	movl	$0x10, %ecx
   15863:      	movl	$0x10, %esi
   15868:      	movq	%r12, %rdx
   1586b:      	callq	*%rax
   1586d:      	movq	0x28(%rsp), %rbx
   15872:      	movq	0x48(%rsp), %rax
   15877:      	movl	0x5c(%rsp), %r15d
   1587c:      	subq	%rbx, %rax
   1587f:      	movl	0x50(%rsp), %r12d
   15884:      	movl	%r15d, %edx
   15887:      	subl	%r12d, %edx
   1588a:      	movl	$0x0, %ecx
   1588f:      	cmovbl	%ecx, %edx
   15892:      	addq	0x60(%rsp), %rdx
   15897:      	xorl	%esi, %esi
   15899:      	cmpl	%r15d, %r12d
   1589c:      	seta	%sil
   158a0:      	movl	%r15d, %ecx
   158a3:      	cmovbl	%r12d, %ecx
   158a7:      	addl	%ecx, %esi
   158a9:      	movl	%r12d, %edi
   158ac:      	subl	%esi, %edi
   158ae:      	movl	%edi, 0x50(%rsp)
   158b2:      	subq	%rsi, %rax
   158b5:      	jb	0x16372 <generic_usdt_path+0xba72>
   158bb:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   158c1:      	ja	0x16372 <generic_usdt_path+0xba72>
   158c7:      	cmpl	%r15d, %r12d
   158ca:      	jbe	0x158d0 <generic_usdt_path+0xafd0>
   158cc:      	movb	$0x2f, (%rbx,%rax)
   158d0:      	xorl	%edi, %edi
   158d2:      	cmpl	%r15d, %r12d
   158d5:      	seta	%dil
   158d9:      	movzbl	%cl, %esi
   158dc:      	addq	%rax, %rbx
   158df:      	addq	%rbx, %rdi
   158e2:      	movl	$0x4, %eax
   158e7:      	callq	*%rax
   158e9:      	movq	%rbx, 0x48(%rsp)
   158ee:      	cmpl	%r15d, %r12d
   158f1:      	jbe	0x16372 <generic_usdt_path+0xba72>
   158f7:      	movq	0x8(%rsp), %r12
   158fc:      	movq	%r12, 0x30(%rsp)
   15901:      	movq	0x38(%rsp), %rdx
   15906:      	movq	0x40(%rsp), %r15
   1590b:      	jmp	0x1595e <generic_usdt_path+0xb05e>
   1590d:      	leaq	0x10(%r15), %rdx
   15911:      	movl	$0x4, %eax
   15916:      	movq	%rbp, %rdi
   15919:      	movl	$0x8, %esi
   1591e:      	callq	*%rax
   15920:      	movq	0x40(%rsp), %rax
   15925:      	cmpq	(%rsp), %rax
   15929:      	je	0x1636d <generic_usdt_path+0xba6d>
   1592f:      	addq	$0x18, %r15
   15933:      	movl	$0x4, %eax
   15938:      	leaq	0x30(%rsp), %rdi
   1593d:      	movl	$0x8, %esi
   15942:      	movq	%r15, %rdx
   15945:      	callq	*%rax
   15947:      	movq	(%rsp), %r15
   1594b:      	movq	%r15, 0x40(%rsp)
   15950:      	leaq	0x20(%r15), %rdx
   15954:      	movq	%rdx, 0x38(%rsp)
   15959:      	movq	0x30(%rsp), %r12
   1595e:      	cmpq	0x18(%rsp), %r12
   15963:      	jne	0x15970 <generic_usdt_path+0xb070>
   15965:      	cmpq	0x20(%rsp), %rdx
   1596a:      	je	0x1636d <generic_usdt_path+0xba6d>
   15970:      	movl	$0x4, %eax
   15975:      	leaq	0x10(%rsp), %rdi
   1597a:      	movl	$0x8, %esi
   1597f:      	callq	*%rax
   15981:      	cmpq	0x10(%rsp), %r12
   15986:      	je	0x15a7e <generic_usdt_path+0xb17e>
   1598c:      	leaq	0x18(%r12), %rbx
   15991:      	movl	$0x4, %eax
   15996:      	movq	%rbp, %rdi
   15999:      	movl	$0x8, %esi
   1599e:      	movq	%rbx, %rdx
   159a1:      	callq	*%rax
   159a3:      	cmpq	%r12, (%rsp)
   159a7:      	je	0x15a7e <generic_usdt_path+0xb17e>
   159ad:      	movl	$0x4, %eax
   159b2:      	leaq	0x8(%rsp), %rdi
   159b7:      	movl	$0x8, %esi
   159bc:      	movq	%rbx, %rdx
   159bf:      	callq	*%rax
   159c1:      	addq	$0x20, %r12
   159c5:      	movl	$0x4, %eax
   159ca:      	leaq	0x58(%rsp), %rdi
   159cf:      	movl	$0x10, %ecx
   159d4:      	movl	$0x10, %esi
   159d9:      	movq	%r12, %rdx
   159dc:      	callq	*%rax
   159de:      	movq	0x28(%rsp), %rbx
   159e3:      	movq	0x48(%rsp), %rax
   159e8:      	movl	0x5c(%rsp), %r15d
   159ed:      	subq	%rbx, %rax
   159f0:      	movl	0x50(%rsp), %r12d
   159f5:      	movl	%r15d, %edx
   159f8:      	subl	%r12d, %edx
   159fb:      	movl	$0x0, %ecx
   15a00:      	cmovbl	%ecx, %edx
   15a03:      	addq	0x60(%rsp), %rdx
   15a08:      	xorl	%esi, %esi
   15a0a:      	cmpl	%r15d, %r12d
   15a0d:      	seta	%sil
   15a11:      	movl	%r15d, %ecx
   15a14:      	cmovbl	%r12d, %ecx
   15a18:      	addl	%ecx, %esi
   15a1a:      	movl	%r12d, %edi
   15a1d:      	subl	%esi, %edi
   15a1f:      	movl	%edi, 0x50(%rsp)
   15a23:      	subq	%rsi, %rax
   15a26:      	jb	0x16372 <generic_usdt_path+0xba72>
   15a2c:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15a32:      	ja	0x16372 <generic_usdt_path+0xba72>
   15a38:      	cmpl	%r15d, %r12d
   15a3b:      	jbe	0x15a41 <generic_usdt_path+0xb141>
   15a3d:      	movb	$0x2f, (%rbx,%rax)
   15a41:      	xorl	%edi, %edi
   15a43:      	cmpl	%r15d, %r12d
   15a46:      	seta	%dil
   15a4a:      	movzbl	%cl, %esi
   15a4d:      	addq	%rax, %rbx
   15a50:      	addq	%rbx, %rdi
   15a53:      	movl	$0x4, %eax
   15a58:      	callq	*%rax
   15a5a:      	movq	%rbx, 0x48(%rsp)
   15a5f:      	cmpl	%r15d, %r12d
   15a62:      	jbe	0x16372 <generic_usdt_path+0xba72>
   15a68:      	movq	0x8(%rsp), %r12
   15a6d:      	movq	%r12, 0x30(%rsp)
   15a72:      	movq	0x38(%rsp), %rdx
   15a77:      	movq	0x40(%rsp), %r15
   15a7c:      	jmp	0x15acf <generic_usdt_path+0xb1cf>
   15a7e:      	leaq	0x10(%r15), %rdx
   15a82:      	movl	$0x4, %eax
   15a87:      	movq	%rbp, %rdi
   15a8a:      	movl	$0x8, %esi
   15a8f:      	callq	*%rax
   15a91:      	movq	0x40(%rsp), %rax
   15a96:      	cmpq	(%rsp), %rax
   15a9a:      	je	0x1636d <generic_usdt_path+0xba6d>
   15aa0:      	addq	$0x18, %r15
   15aa4:      	movl	$0x4, %eax
   15aa9:      	leaq	0x30(%rsp), %rdi
   15aae:      	movl	$0x8, %esi
   15ab3:      	movq	%r15, %rdx
   15ab6:      	callq	*%rax
   15ab8:      	movq	(%rsp), %r15
   15abc:      	movq	%r15, 0x40(%rsp)
   15ac1:      	leaq	0x20(%r15), %rdx
   15ac5:      	movq	%rdx, 0x38(%rsp)
   15aca:      	movq	0x30(%rsp), %r12
   15acf:      	cmpq	0x18(%rsp), %r12
   15ad4:      	jne	0x15ae1 <generic_usdt_path+0xb1e1>
   15ad6:      	cmpq	0x20(%rsp), %rdx
   15adb:      	je	0x1636d <generic_usdt_path+0xba6d>
   15ae1:      	movl	$0x4, %eax
   15ae6:      	leaq	0x10(%rsp), %rdi
   15aeb:      	movl	$0x8, %esi
   15af0:      	callq	*%rax
   15af2:      	cmpq	0x10(%rsp), %r12
   15af7:      	je	0x15bef <generic_usdt_path+0xb2ef>
   15afd:      	leaq	0x18(%r12), %rbx
   15b02:      	movl	$0x4, %eax
   15b07:      	movq	%rbp, %rdi
   15b0a:      	movl	$0x8, %esi
   15b0f:      	movq	%rbx, %rdx
   15b12:      	callq	*%rax
   15b14:      	cmpq	%r12, (%rsp)
   15b18:      	je	0x15bef <generic_usdt_path+0xb2ef>
   15b1e:      	movl	$0x4, %eax
   15b23:      	leaq	0x8(%rsp), %rdi
   15b28:      	movl	$0x8, %esi
   15b2d:      	movq	%rbx, %rdx
   15b30:      	callq	*%rax
   15b32:      	addq	$0x20, %r12
   15b36:      	movl	$0x4, %eax
   15b3b:      	leaq	0x58(%rsp), %rdi
   15b40:      	movl	$0x10, %ecx
   15b45:      	movl	$0x10, %esi
   15b4a:      	movq	%r12, %rdx
   15b4d:      	callq	*%rax
   15b4f:      	movq	0x28(%rsp), %rbx
   15b54:      	movq	0x48(%rsp), %rax
   15b59:      	movl	0x5c(%rsp), %r15d
   15b5e:      	subq	%rbx, %rax
   15b61:      	movl	0x50(%rsp), %r12d
   15b66:      	movl	%r15d, %edx
   15b69:      	subl	%r12d, %edx
   15b6c:      	movl	$0x0, %ecx
   15b71:      	cmovbl	%ecx, %edx
   15b74:      	addq	0x60(%rsp), %rdx
   15b79:      	xorl	%esi, %esi
   15b7b:      	cmpl	%r15d, %r12d
   15b7e:      	seta	%sil
   15b82:      	movl	%r15d, %ecx
   15b85:      	cmovbl	%r12d, %ecx
   15b89:      	addl	%ecx, %esi
   15b8b:      	movl	%r12d, %edi
   15b8e:      	subl	%esi, %edi
   15b90:      	movl	%edi, 0x50(%rsp)
   15b94:      	subq	%rsi, %rax
   15b97:      	jb	0x16372 <generic_usdt_path+0xba72>
   15b9d:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15ba3:      	ja	0x16372 <generic_usdt_path+0xba72>
   15ba9:      	cmpl	%r15d, %r12d
   15bac:      	jbe	0x15bb2 <generic_usdt_path+0xb2b2>
   15bae:      	movb	$0x2f, (%rbx,%rax)
   15bb2:      	xorl	%edi, %edi
   15bb4:      	cmpl	%r15d, %r12d
   15bb7:      	seta	%dil
   15bbb:      	movzbl	%cl, %esi
   15bbe:      	addq	%rax, %rbx
   15bc1:      	addq	%rbx, %rdi
   15bc4:      	movl	$0x4, %eax
   15bc9:      	callq	*%rax
   15bcb:      	movq	%rbx, 0x48(%rsp)
   15bd0:      	cmpl	%r15d, %r12d
   15bd3:      	jbe	0x16372 <generic_usdt_path+0xba72>
   15bd9:      	movq	0x8(%rsp), %r12
   15bde:      	movq	%r12, 0x30(%rsp)
   15be3:      	movq	0x38(%rsp), %rdx
   15be8:      	movq	0x40(%rsp), %r15
   15bed:      	jmp	0x15c40 <generic_usdt_path+0xb340>
   15bef:      	leaq	0x10(%r15), %rdx
   15bf3:      	movl	$0x4, %eax
   15bf8:      	movq	%rbp, %rdi
   15bfb:      	movl	$0x8, %esi
   15c00:      	callq	*%rax
   15c02:      	movq	0x40(%rsp), %rax
   15c07:      	cmpq	(%rsp), %rax
   15c0b:      	je	0x1636d <generic_usdt_path+0xba6d>
   15c11:      	addq	$0x18, %r15
   15c15:      	movl	$0x4, %eax
   15c1a:      	leaq	0x30(%rsp), %rdi
   15c1f:      	movl	$0x8, %esi
   15c24:      	movq	%r15, %rdx
   15c27:      	callq	*%rax
   15c29:      	movq	(%rsp), %r15
   15c2d:      	movq	%r15, 0x40(%rsp)
   15c32:      	leaq	0x20(%r15), %rdx
   15c36:      	movq	%rdx, 0x38(%rsp)
   15c3b:      	movq	0x30(%rsp), %r12
   15c40:      	cmpq	0x18(%rsp), %r12
   15c45:      	jne	0x15c52 <generic_usdt_path+0xb352>
   15c47:      	cmpq	0x20(%rsp), %rdx
   15c4c:      	je	0x1636d <generic_usdt_path+0xba6d>
   15c52:      	movl	$0x4, %eax
   15c57:      	leaq	0x10(%rsp), %rdi
   15c5c:      	movl	$0x8, %esi
   15c61:      	callq	*%rax
   15c63:      	cmpq	0x10(%rsp), %r12
   15c68:      	je	0x15d60 <generic_usdt_path+0xb460>
   15c6e:      	leaq	0x18(%r12), %rbx
   15c73:      	movl	$0x4, %eax
   15c78:      	movq	%rbp, %rdi
   15c7b:      	movl	$0x8, %esi
   15c80:      	movq	%rbx, %rdx
   15c83:      	callq	*%rax
   15c85:      	cmpq	%r12, (%rsp)
   15c89:      	je	0x15d60 <generic_usdt_path+0xb460>
   15c8f:      	movl	$0x4, %eax
   15c94:      	leaq	0x8(%rsp), %rdi
   15c99:      	movl	$0x8, %esi
   15c9e:      	movq	%rbx, %rdx
   15ca1:      	callq	*%rax
   15ca3:      	addq	$0x20, %r12
   15ca7:      	movl	$0x4, %eax
   15cac:      	leaq	0x58(%rsp), %rdi
   15cb1:      	movl	$0x10, %ecx
   15cb6:      	movl	$0x10, %esi
   15cbb:      	movq	%r12, %rdx
   15cbe:      	callq	*%rax
   15cc0:      	movq	0x28(%rsp), %rbx
   15cc5:      	movq	0x48(%rsp), %rax
   15cca:      	movl	0x5c(%rsp), %r15d
   15ccf:      	subq	%rbx, %rax
   15cd2:      	movl	0x50(%rsp), %r12d
   15cd7:      	movl	%r15d, %edx
   15cda:      	subl	%r12d, %edx
   15cdd:      	movl	$0x0, %ecx
   15ce2:      	cmovbl	%ecx, %edx
   15ce5:      	addq	0x60(%rsp), %rdx
   15cea:      	xorl	%esi, %esi
   15cec:      	cmpl	%r15d, %r12d
   15cef:      	seta	%sil
   15cf3:      	movl	%r15d, %ecx
   15cf6:      	cmovbl	%r12d, %ecx
   15cfa:      	addl	%ecx, %esi
   15cfc:      	movl	%r12d, %edi
   15cff:      	subl	%esi, %edi
   15d01:      	movl	%edi, 0x50(%rsp)
   15d05:      	subq	%rsi, %rax
   15d08:      	jb	0x16372 <generic_usdt_path+0xba72>
   15d0e:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15d14:      	ja	0x16372 <generic_usdt_path+0xba72>
   15d1a:      	cmpl	%r15d, %r12d
   15d1d:      	jbe	0x15d23 <generic_usdt_path+0xb423>
   15d1f:      	movb	$0x2f, (%rbx,%rax)
   15d23:      	xorl	%edi, %edi
   15d25:      	cmpl	%r15d, %r12d
   15d28:      	seta	%dil
   15d2c:      	movzbl	%cl, %esi
   15d2f:      	addq	%rax, %rbx
   15d32:      	addq	%rbx, %rdi
   15d35:      	movl	$0x4, %eax
   15d3a:      	callq	*%rax
   15d3c:      	movq	%rbx, 0x48(%rsp)
   15d41:      	cmpl	%r15d, %r12d
   15d44:      	jbe	0x16372 <generic_usdt_path+0xba72>
   15d4a:      	movq	0x8(%rsp), %r12
   15d4f:      	movq	%r12, 0x30(%rsp)
   15d54:      	movq	0x38(%rsp), %rdx
   15d59:      	movq	0x40(%rsp), %r15
   15d5e:      	jmp	0x15db1 <generic_usdt_path+0xb4b1>
   15d60:      	leaq	0x10(%r15), %rdx
   15d64:      	movl	$0x4, %eax
   15d69:      	movq	%rbp, %rdi
   15d6c:      	movl	$0x8, %esi
   15d71:      	callq	*%rax
   15d73:      	movq	0x40(%rsp), %rax
   15d78:      	cmpq	(%rsp), %rax
   15d7c:      	je	0x1636d <generic_usdt_path+0xba6d>
   15d82:      	addq	$0x18, %r15
   15d86:      	movl	$0x4, %eax
   15d8b:      	leaq	0x30(%rsp), %rdi
   15d90:      	movl	$0x8, %esi
   15d95:      	movq	%r15, %rdx
   15d98:      	callq	*%rax
   15d9a:      	movq	(%rsp), %r15
   15d9e:      	movq	%r15, 0x40(%rsp)
   15da3:      	leaq	0x20(%r15), %rdx
   15da7:      	movq	%rdx, 0x38(%rsp)
   15dac:      	movq	0x30(%rsp), %r12
   15db1:      	cmpq	0x18(%rsp), %r12
   15db6:      	jne	0x15dc3 <generic_usdt_path+0xb4c3>
   15db8:      	cmpq	0x20(%rsp), %rdx
   15dbd:      	je	0x1636d <generic_usdt_path+0xba6d>
   15dc3:      	movl	$0x4, %eax
   15dc8:      	leaq	0x10(%rsp), %rdi
   15dcd:      	movl	$0x8, %esi
   15dd2:      	callq	*%rax
   15dd4:      	cmpq	0x10(%rsp), %r12
   15dd9:      	je	0x15ed1 <generic_usdt_path+0xb5d1>
   15ddf:      	leaq	0x18(%r12), %rbx
   15de4:      	movl	$0x4, %eax
   15de9:      	movq	%rbp, %rdi
   15dec:      	movl	$0x8, %esi
   15df1:      	movq	%rbx, %rdx
   15df4:      	callq	*%rax
   15df6:      	cmpq	%r12, (%rsp)
   15dfa:      	je	0x15ed1 <generic_usdt_path+0xb5d1>
   15e00:      	movl	$0x4, %eax
   15e05:      	leaq	0x8(%rsp), %rdi
   15e0a:      	movl	$0x8, %esi
   15e0f:      	movq	%rbx, %rdx
   15e12:      	callq	*%rax
   15e14:      	addq	$0x20, %r12
   15e18:      	movl	$0x4, %eax
   15e1d:      	leaq	0x58(%rsp), %rdi
   15e22:      	movl	$0x10, %ecx
   15e27:      	movl	$0x10, %esi
   15e2c:      	movq	%r12, %rdx
   15e2f:      	callq	*%rax
   15e31:      	movq	0x28(%rsp), %rbx
   15e36:      	movq	0x48(%rsp), %rax
   15e3b:      	movl	0x5c(%rsp), %r15d
   15e40:      	subq	%rbx, %rax
   15e43:      	movl	0x50(%rsp), %r12d
   15e48:      	movl	%r15d, %edx
   15e4b:      	subl	%r12d, %edx
   15e4e:      	movl	$0x0, %ecx
   15e53:      	cmovbl	%ecx, %edx
   15e56:      	addq	0x60(%rsp), %rdx
   15e5b:      	xorl	%esi, %esi
   15e5d:      	cmpl	%r15d, %r12d
   15e60:      	seta	%sil
   15e64:      	movl	%r15d, %ecx
   15e67:      	cmovbl	%r12d, %ecx
   15e6b:      	addl	%ecx, %esi
   15e6d:      	movl	%r12d, %edi
   15e70:      	subl	%esi, %edi
   15e72:      	movl	%edi, 0x50(%rsp)
   15e76:      	subq	%rsi, %rax
   15e79:      	jb	0x16372 <generic_usdt_path+0xba72>
   15e7f:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15e85:      	ja	0x16372 <generic_usdt_path+0xba72>
   15e8b:      	cmpl	%r15d, %r12d
   15e8e:      	jbe	0x15e94 <generic_usdt_path+0xb594>
   15e90:      	movb	$0x2f, (%rbx,%rax)
   15e94:      	xorl	%edi, %edi
   15e96:      	cmpl	%r15d, %r12d
   15e99:      	seta	%dil
   15e9d:      	movzbl	%cl, %esi
   15ea0:      	addq	%rax, %rbx
   15ea3:      	addq	%rbx, %rdi
   15ea6:      	movl	$0x4, %eax
   15eab:      	callq	*%rax
   15ead:      	movq	%rbx, 0x48(%rsp)
   15eb2:      	cmpl	%r15d, %r12d
   15eb5:      	jbe	0x16372 <generic_usdt_path+0xba72>
   15ebb:      	movq	0x8(%rsp), %r12
   15ec0:      	movq	%r12, 0x30(%rsp)
   15ec5:      	movq	0x38(%rsp), %rdx
   15eca:      	movq	0x40(%rsp), %r15
   15ecf:      	jmp	0x15f22 <generic_usdt_path+0xb622>
   15ed1:      	leaq	0x10(%r15), %rdx
   15ed5:      	movl	$0x4, %eax
   15eda:      	movq	%rbp, %rdi
   15edd:      	movl	$0x8, %esi
   15ee2:      	callq	*%rax
   15ee4:      	movq	0x40(%rsp), %rax
   15ee9:      	cmpq	(%rsp), %rax
   15eed:      	je	0x1636d <generic_usdt_path+0xba6d>
   15ef3:      	addq	$0x18, %r15
   15ef7:      	movl	$0x4, %eax
   15efc:      	leaq	0x30(%rsp), %rdi
   15f01:      	movl	$0x8, %esi
   15f06:      	movq	%r15, %rdx
   15f09:      	callq	*%rax
   15f0b:      	movq	(%rsp), %r15
   15f0f:      	movq	%r15, 0x40(%rsp)
   15f14:      	leaq	0x20(%r15), %rdx
   15f18:      	movq	%rdx, 0x38(%rsp)
   15f1d:      	movq	0x30(%rsp), %r12
   15f22:      	cmpq	0x18(%rsp), %r12
   15f27:      	jne	0x15f34 <generic_usdt_path+0xb634>
   15f29:      	cmpq	0x20(%rsp), %rdx
   15f2e:      	je	0x1636d <generic_usdt_path+0xba6d>
   15f34:      	movl	$0x4, %eax
   15f39:      	leaq	0x10(%rsp), %rdi
   15f3e:      	movl	$0x8, %esi
   15f43:      	callq	*%rax
   15f45:      	cmpq	0x10(%rsp), %r12
   15f4a:      	je	0x16042 <generic_usdt_path+0xb742>
   15f50:      	leaq	0x18(%r12), %rbx
   15f55:      	movl	$0x4, %eax
   15f5a:      	movq	%rbp, %rdi
   15f5d:      	movl	$0x8, %esi
   15f62:      	movq	%rbx, %rdx
   15f65:      	callq	*%rax
   15f67:      	cmpq	%r12, (%rsp)
   15f6b:      	je	0x16042 <generic_usdt_path+0xb742>
   15f71:      	movl	$0x4, %eax
   15f76:      	leaq	0x8(%rsp), %rdi
   15f7b:      	movl	$0x8, %esi
   15f80:      	movq	%rbx, %rdx
   15f83:      	callq	*%rax
   15f85:      	addq	$0x20, %r12
   15f89:      	movl	$0x4, %eax
   15f8e:      	leaq	0x58(%rsp), %rdi
   15f93:      	movl	$0x10, %ecx
   15f98:      	movl	$0x10, %esi
   15f9d:      	movq	%r12, %rdx
   15fa0:      	callq	*%rax
   15fa2:      	movq	0x28(%rsp), %rbx
   15fa7:      	movq	0x48(%rsp), %rax
   15fac:      	movl	0x5c(%rsp), %r15d
   15fb1:      	subq	%rbx, %rax
   15fb4:      	movl	0x50(%rsp), %r12d
   15fb9:      	movl	%r15d, %edx
   15fbc:      	subl	%r12d, %edx
   15fbf:      	movl	$0x0, %ecx
   15fc4:      	cmovbl	%ecx, %edx
   15fc7:      	addq	0x60(%rsp), %rdx
   15fcc:      	xorl	%esi, %esi
   15fce:      	cmpl	%r15d, %r12d
   15fd1:      	seta	%sil
   15fd5:      	movl	%r15d, %ecx
   15fd8:      	cmovbl	%r12d, %ecx
   15fdc:      	addl	%ecx, %esi
   15fde:      	movl	%r12d, %edi
   15fe1:      	subl	%esi, %edi
   15fe3:      	movl	%edi, 0x50(%rsp)
   15fe7:      	subq	%rsi, %rax
   15fea:      	jb	0x16372 <generic_usdt_path+0xba72>
   15ff0:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   15ff6:      	ja	0x16372 <generic_usdt_path+0xba72>
   15ffc:      	cmpl	%r15d, %r12d
   15fff:      	jbe	0x16005 <generic_usdt_path+0xb705>
   16001:      	movb	$0x2f, (%rbx,%rax)
   16005:      	xorl	%edi, %edi
   16007:      	cmpl	%r15d, %r12d
   1600a:      	seta	%dil
   1600e:      	movzbl	%cl, %esi
   16011:      	addq	%rax, %rbx
   16014:      	addq	%rbx, %rdi
   16017:      	movl	$0x4, %eax
   1601c:      	callq	*%rax
   1601e:      	movq	%rbx, 0x48(%rsp)
   16023:      	cmpl	%r15d, %r12d
   16026:      	jbe	0x16372 <generic_usdt_path+0xba72>
   1602c:      	movq	0x8(%rsp), %r12
   16031:      	movq	%r12, 0x30(%rsp)
   16036:      	movq	0x38(%rsp), %rdx
   1603b:      	movq	0x40(%rsp), %r15
   16040:      	jmp	0x16093 <generic_usdt_path+0xb793>
   16042:      	leaq	0x10(%r15), %rdx
   16046:      	movl	$0x4, %eax
   1604b:      	movq	%rbp, %rdi
   1604e:      	movl	$0x8, %esi
   16053:      	callq	*%rax
   16055:      	movq	0x40(%rsp), %rax
   1605a:      	cmpq	(%rsp), %rax
   1605e:      	je	0x1636d <generic_usdt_path+0xba6d>
   16064:      	addq	$0x18, %r15
   16068:      	movl	$0x4, %eax
   1606d:      	leaq	0x30(%rsp), %rdi
   16072:      	movl	$0x8, %esi
   16077:      	movq	%r15, %rdx
   1607a:      	callq	*%rax
   1607c:      	movq	(%rsp), %r15
   16080:      	movq	%r15, 0x40(%rsp)
   16085:      	leaq	0x20(%r15), %rdx
   16089:      	movq	%rdx, 0x38(%rsp)
   1608e:      	movq	0x30(%rsp), %r12
   16093:      	cmpq	0x18(%rsp), %r12
   16098:      	jne	0x160a5 <generic_usdt_path+0xb7a5>
   1609a:      	cmpq	0x20(%rsp), %rdx
   1609f:      	je	0x1636d <generic_usdt_path+0xba6d>
   160a5:      	movl	$0x4, %eax
   160aa:      	leaq	0x10(%rsp), %rdi
   160af:      	movl	$0x8, %esi
   160b4:      	callq	*%rax
   160b6:      	cmpq	0x10(%rsp), %r12
   160bb:      	je	0x161b3 <generic_usdt_path+0xb8b3>
   160c1:      	leaq	0x18(%r12), %rbx
   160c6:      	movl	$0x4, %eax
   160cb:      	movq	%rbp, %rdi
   160ce:      	movl	$0x8, %esi
   160d3:      	movq	%rbx, %rdx
   160d6:      	callq	*%rax
   160d8:      	cmpq	%r12, (%rsp)
   160dc:      	je	0x161b3 <generic_usdt_path+0xb8b3>
   160e2:      	movl	$0x4, %eax
   160e7:      	leaq	0x8(%rsp), %rdi
   160ec:      	movl	$0x8, %esi
   160f1:      	movq	%rbx, %rdx
   160f4:      	callq	*%rax
   160f6:      	addq	$0x20, %r12
   160fa:      	movl	$0x4, %eax
   160ff:      	leaq	0x58(%rsp), %rdi
   16104:      	movl	$0x10, %ecx
   16109:      	movl	$0x10, %esi
   1610e:      	movq	%r12, %rdx
   16111:      	callq	*%rax
   16113:      	movq	0x28(%rsp), %rbx
   16118:      	movq	0x48(%rsp), %rax
   1611d:      	movl	0x5c(%rsp), %r15d
   16122:      	subq	%rbx, %rax
   16125:      	movl	0x50(%rsp), %r12d
   1612a:      	movl	%r15d, %edx
   1612d:      	subl	%r12d, %edx
   16130:      	movl	$0x0, %ecx
   16135:      	cmovbl	%ecx, %edx
   16138:      	addq	0x60(%rsp), %rdx
   1613d:      	xorl	%esi, %esi
   1613f:      	cmpl	%r15d, %r12d
   16142:      	seta	%sil
   16146:      	movl	%r15d, %ecx
   16149:      	cmovbl	%r12d, %ecx
   1614d:      	addl	%ecx, %esi
   1614f:      	movl	%r12d, %edi
   16152:      	subl	%esi, %edi
   16154:      	movl	%edi, 0x50(%rsp)
   16158:      	subq	%rsi, %rax
   1615b:      	jb	0x16372 <generic_usdt_path+0xba72>
   16161:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   16167:      	ja	0x16372 <generic_usdt_path+0xba72>
   1616d:      	cmpl	%r15d, %r12d
   16170:      	jbe	0x16176 <generic_usdt_path+0xb876>
   16172:      	movb	$0x2f, (%rbx,%rax)
   16176:      	xorl	%edi, %edi
   16178:      	cmpl	%r15d, %r12d
   1617b:      	seta	%dil
   1617f:      	movzbl	%cl, %esi
   16182:      	addq	%rax, %rbx
   16185:      	addq	%rbx, %rdi
   16188:      	movl	$0x4, %eax
   1618d:      	callq	*%rax
   1618f:      	movq	%rbx, 0x48(%rsp)
   16194:      	cmpl	%r15d, %r12d
   16197:      	jbe	0x16372 <generic_usdt_path+0xba72>
   1619d:      	movq	0x8(%rsp), %r12
   161a2:      	movq	%r12, 0x30(%rsp)
   161a7:      	movq	0x38(%rsp), %rdx
   161ac:      	movq	0x40(%rsp), %r15
   161b1:      	jmp	0x16204 <generic_usdt_path+0xb904>
   161b3:      	leaq	0x10(%r15), %rdx
   161b7:      	movl	$0x4, %eax
   161bc:      	movq	%rbp, %rdi
   161bf:      	movl	$0x8, %esi
   161c4:      	callq	*%rax
   161c6:      	movq	0x40(%rsp), %rax
   161cb:      	cmpq	(%rsp), %rax
   161cf:      	je	0x1636d <generic_usdt_path+0xba6d>
   161d5:      	addq	$0x18, %r15
   161d9:      	movl	$0x4, %eax
   161de:      	leaq	0x30(%rsp), %rdi
   161e3:      	movl	$0x8, %esi
   161e8:      	movq	%r15, %rdx
   161eb:      	callq	*%rax
   161ed:      	movq	(%rsp), %r15
   161f1:      	movq	%r15, 0x40(%rsp)
   161f6:      	leaq	0x20(%r15), %rdx
   161fa:      	movq	%rdx, 0x38(%rsp)
   161ff:      	movq	0x30(%rsp), %r12
   16204:      	cmpq	0x18(%rsp), %r12
   16209:      	jne	0x16216 <generic_usdt_path+0xb916>
   1620b:      	cmpq	0x20(%rsp), %rdx
   16210:      	je	0x1636d <generic_usdt_path+0xba6d>
   16216:      	movl	$0x4, %eax
   1621b:      	leaq	0x10(%rsp), %rdi
   16220:      	movl	$0x8, %esi
   16225:      	callq	*%rax
   16227:      	cmpq	0x10(%rsp), %r12
   1622c:      	je	0x16316 <generic_usdt_path+0xba16>
   16232:      	leaq	0x18(%r12), %rbx
   16237:      	movl	$0x4, %eax
   1623c:      	movq	%rbp, %rdi
   1623f:      	movl	$0x8, %esi
   16244:      	movq	%rbx, %rdx
   16247:      	callq	*%rax
   16249:      	cmpq	%r12, (%rsp)
   1624d:      	je	0x16316 <generic_usdt_path+0xba16>
   16253:      	movl	$0x4, %eax
   16258:      	leaq	0x8(%rsp), %rdi
   1625d:      	movl	$0x8, %esi
   16262:      	movq	%rbx, %rdx
   16265:      	callq	*%rax
   16267:      	addq	$0x20, %r12
   1626b:      	movl	$0x4, %eax
   16270:      	leaq	0x58(%rsp), %rdi
   16275:      	movl	$0x10, %ecx
   1627a:      	movl	$0x10, %esi
   1627f:      	movq	%r12, %rdx
   16282:      	callq	*%rax
   16284:      	movq	0x28(%rsp), %rbx
   16289:      	movq	0x48(%rsp), %rax
   1628e:      	movl	0x5c(%rsp), %r15d
   16293:      	subq	%rbx, %rax
   16296:      	movl	0x50(%rsp), %r12d
   1629b:      	movl	%r15d, %edx
   1629e:      	subl	%r12d, %edx
   162a1:      	movl	$0x0, %ecx
   162a6:      	cmovbl	%ecx, %edx
   162a9:      	addq	0x60(%rsp), %rdx
   162ae:      	xorl	%esi, %esi
   162b0:      	cmpl	%r15d, %r12d
   162b3:      	seta	%sil
   162b7:      	movl	%r15d, %ecx
   162ba:      	cmovbl	%r12d, %ecx
   162be:      	addl	%ecx, %esi
   162c0:      	movl	%r12d, %edi
   162c3:      	subl	%esi, %edi
   162c5:      	movl	%edi, 0x50(%rsp)
   162c9:      	subq	%rsi, %rax
   162cc:      	jb	0x16372 <generic_usdt_path+0xba72>
   162d2:      	cmpq	$0xfff, %rax            # imm = 0xFFF
   162d8:      	ja	0x16372 <generic_usdt_path+0xba72>
   162de:      	cmpl	%r15d, %r12d
   162e1:      	jbe	0x162e7 <generic_usdt_path+0xb9e7>
   162e3:      	movb	$0x2f, (%rbx,%rax)
   162e7:      	xorl	%edi, %edi
   162e9:      	cmpl	%r15d, %r12d
   162ec:      	seta	%dil
   162f0:      	movzbl	%cl, %esi
   162f3:      	addq	%rax, %rbx
   162f6:      	addq	%rbx, %rdi
   162f9:      	movl	$0x4, %eax
   162fe:      	callq	*%rax
   16300:      	movq	%rbx, 0x48(%rsp)
   16305:      	cmpl	%r15d, %r12d
   16308:      	jbe	0x16372 <generic_usdt_path+0xba72>
   1630a:      	movq	0x8(%rsp), %rax
   1630f:      	movq	%rax, 0x30(%rsp)
   16314:      	jmp	0x1635e <generic_usdt_path+0xba5e>
   16316:      	leaq	0x10(%r15), %rdx
   1631a:      	movl	$0x4, %eax
   1631f:      	movq	%rbp, %rdi
   16322:      	movl	$0x8, %esi
   16327:      	callq	*%rax
   16329:      	movq	0x40(%rsp), %rax
   1632e:      	cmpq	(%rsp), %rax
   16332:      	je	0x1636d <generic_usdt_path+0xba6d>
   16334:      	addq	$0x18, %r15
   16338:      	movl	$0x4, %eax
   1633d:      	leaq	0x30(%rsp), %rdi
   16342:      	movl	$0x8, %esi
   16347:      	movq	%r15, %rdx
   1634a:      	callq	*%rax
   1634c:      	movq	(%rsp), %rax
   16350:      	movq	%rax, 0x40(%rsp)
   16355:      	addq	$0x20, %rax
   16359:      	movq	%rax, 0x38(%rsp)
   1635e:      	movl	0x6c(%rsp), %eax
   16362:      	addl	$-0x80, %eax
   16365:      	jne	0xaaa3 <generic_usdt_path+0x1a3>
   1636b:      	jmp	0x16372 <generic_usdt_path+0xba72>
   1636d:      	movb	$0x1, 0x54(%rsp)
   16372:      	movl	0x6428(%r14), %eax
   16379:      	incl	%eax
   1637b:      	movl	%eax, 0x6428(%r14)
   16382:      	movl	0x48(%rsp), %ecx
   16386:      	subl	0x80(%rsp), %ecx
   1638d:      	movl	%ecx, 0x6424(%r14)
   16394:      	cmpb	$0x0, 0x54(%rsp)
   16399:      	jne	0x163e1 <generic_usdt_path+0xbae1>
   1639b:      	cmpl	$0x8, %eax
   1639e:      	je	0x163e1 <generic_usdt_path+0xbae1>
   163a0:      	movq	0x30(%rsp), %rax
   163a5:      	movq	%rax, 0x6458(%r14)
   163ac:      	movq	0x38(%rsp), %rax
   163b1:      	movq	%rax, 0x6460(%r14)
   163b8:      	movq	0x40(%rsp), %rax
   163bd:      	movq	%rax, 0x6468(%r14)
   163c4:      	movq	(%rip), %rcx            # 0x163cb <generic_usdt_path+0xbacb>
   163cb:      	movl	$0x6, %edx
   163d0:      	movl	$0xc, %eax
   163d5:      	movq	0x78(%rsp), %rdi
   163da:      	movl	$0x6, %edx
   163df:      	jmp	0x163fc <generic_usdt_path+0xbafc>
   163e1:      	movq	(%rip), %rcx            # 0x163e8 <generic_usdt_path+0xbae8>
   163e8:      	movl	$0x1, %edx
   163ed:      	movl	$0xc, %eax
   163f2:      	movq	0x78(%rsp), %rdi
   163f7:      	movl	$0x1, %edx
   163fc:      	movq	(%rip), %rsi            # 0x16403 <generic_usdt_path+0xbb03>
   16403:      	jmp	0x16777 <generic_usdt_path+0xbe77>
   16408:      	movl	$0x1, (%rsp)
   1640f:      	movq	(%rip), %rdi            # 0x16416 <generic_usdt_path+0xbb16>
   16416:      	xorl	%ecx, %ecx
   16418:      	leaq	0x18(%rsp), %rsi
   1641d:      	movq	%rsp, %rdx
   16420:      	movl	$0x2, %eax
   16425:      	xorl	%ecx, %ecx
   16427:      	callq	*%rax
   16429:      	movq	0x58(%rsp), %r12
   1642e:      	leaq	0x10(%r12), %rdx
   16433:      	leaq	0x18(%rsp), %rdi
   16438:      	movl	$0x8, %ecx
   1643d:      	movl	$0x4, %eax
   16442:      	leaq	0xfff(%r15), %rbx
   16449:      	movl	$0x8, %esi
   1644e:      	callq	*%rax
   16450:      	cmpq	$0x0, 0x18(%rsp)
   16456:      	jne	0x1649f <generic_usdt_path+0xbb9f>
   16458:      	leaq	0x18(%r12), %rdx
   1645d:      	leaq	0x18(%rsp), %rdi
   16462:      	movl	$0x8, %ecx
   16467:      	movl	$0x4, %eax
   1646c:      	movl	$0x8, %esi
   16471:      	callq	*%rax
   16473:      	cmpq	%r12, 0x18(%rsp)
   16478:      	je	0x1649f <generic_usdt_path+0xbb9f>
   1647a:      	movq	%r15, %rbx
   1647d:      	addq	$0xff5, %rbx            # imm = 0xFF5
   16484:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
   1648e:      	movq	%rax, 0xff5(%r15)
   16495:      	movw	$0x2964, 0xffd(%r15)    # imm = 0x2964
   1649f:      	movl	$0x23, %eax
   164a4:      	callq	*%rax
   164a6:      	leaq	0xd50(%rax), %rdx
   164ad:      	movq	%rsp, %rdi
   164b0:      	movl	$0x8, %ecx
   164b5:      	movl	$0x4, %eax
   164ba:      	movl	$0x8, %esi
   164bf:      	callq	*%rax
   164c1:      	testq	%rax, %rax
   164c4:      	je	0x16523 <generic_usdt_path+0xbc23>
   164c6:      	negl	%eax
   164c8:      	movw	%ax, 0x18(%rsp)
   164cd:      	movw	$0x6, 0x1a(%rsp)
   164d4:      	movabsq	$0x400000033, %rax      # imm = 0x400000033
   164de:      	movq	%rax, 0x1c(%rsp)
   164e3:      	movq	(%rip), %rdi            # 0x164ea <generic_usdt_path+0xbbea>
   164ea:      	leaq	0x18(%rsp), %rsi
   164ef:      	movl	$0x1, %eax
   164f4:      	callq	*%rax
   164f6:      	testq	%rax, %rax
   164f9:      	je	0x164ff <generic_usdt_path+0xbbff>
   164fb:      	incl	(%rax)
   164fd:      	jmp	0x16523 <generic_usdt_path+0xbc23>
   164ff:      	movl	$0x1, 0x8(%rsp)
   16507:      	movq	(%rip), %rdi            # 0x1650e <generic_usdt_path+0xbc0e>
   1650e:      	xorl	%ecx, %ecx
   16510:      	leaq	0x18(%rsp), %rsi
   16515:      	leaq	0x8(%rsp), %rdx
   1651a:      	movl	$0x2, %eax
   1651f:      	xorl	%ecx, %ecx
   16521:      	callq	*%rax
   16523:      	movq	(%rsp), %rdx
   16527:      	leaq	0x18(%rdx), %r13
   1652b:      	movq	0x6440(%r14), %r12
   16532:      	leaq	0x6448(%r14), %rdi
   16539:      	addq	$0x20, %rdx
   1653d:      	movl	$0x8, %ecx
   16542:      	movl	$0x4, %eax
   16547:      	movl	$0x8, %esi
   1654c:      	callq	*%rax
   1654e:      	testq	%rax, %rax
   16551:      	je	0x165b0 <generic_usdt_path+0xbcb0>
   16553:      	negl	%eax
   16555:      	movw	%ax, 0x18(%rsp)
   1655a:      	movw	$0x6, 0x1a(%rsp)
   16561:      	movabsq	$0x400000038, %rax      # imm = 0x400000038
   1656b:      	movq	%rax, 0x1c(%rsp)
   16570:      	movq	(%rip), %rdi            # 0x16577 <generic_usdt_path+0xbc77>
   16577:      	leaq	0x18(%rsp), %rsi
   1657c:      	movl	$0x1, %eax
   16581:      	callq	*%rax
   16583:      	testq	%rax, %rax
   16586:      	je	0x1658c <generic_usdt_path+0xbc8c>
   16588:      	incl	(%rax)
   1658a:      	jmp	0x165b0 <generic_usdt_path+0xbcb0>
   1658c:      	movl	$0x1, 0x8(%rsp)
   16594:      	movq	(%rip), %rdi            # 0x1659b <generic_usdt_path+0xbc9b>
   1659b:      	xorl	%ecx, %ecx
   1659d:      	leaq	0x18(%rsp), %rsi
   165a2:      	leaq	0x8(%rsp), %rdx
   165a7:      	movl	$0x2, %eax
   165ac:      	xorl	%ecx, %ecx
   165ae:      	callq	*%rax
   165b0:      	leaq	0x6450(%r14), %rdi
   165b7:      	movl	$0x8, %ecx
   165bc:      	movl	$0x4, %eax
   165c1:      	movl	$0x8, %esi
   165c6:      	movq	%r13, %rdx
   165c9:      	callq	*%rax
   165cb:      	testq	%rax, %rax
   165ce:      	je	0x1662d <generic_usdt_path+0xbd2d>
   165d0:      	negl	%eax
   165d2:      	movw	%ax, 0x18(%rsp)
   165d7:      	movw	$0x6, 0x1a(%rsp)
   165de:      	movabsq	$0x400000039, %rax      # imm = 0x400000039
   165e8:      	movq	%rax, 0x1c(%rsp)
   165ed:      	movq	(%rip), %rdi            # 0x165f4 <generic_usdt_path+0xbcf4>
   165f4:      	leaq	0x18(%rsp), %rsi
   165f9:      	movl	$0x1, %eax
   165fe:      	callq	*%rax
   16600:      	testq	%rax, %rax
   16603:      	je	0x16609 <generic_usdt_path+0xbd09>
   16605:      	incl	(%rax)
   16607:      	jmp	0x1662d <generic_usdt_path+0xbd2d>
   16609:      	movl	$0x1, 0x8(%rsp)
   16611:      	movq	(%rip), %rdi            # 0x16618 <generic_usdt_path+0xbd18>
   16618:      	xorl	%ecx, %ecx
   1661a:      	leaq	0x18(%rsp), %rsi
   1661f:      	leaq	0x8(%rsp), %rdx
   16624:      	movl	$0x2, %eax
   16629:      	xorl	%ecx, %ecx
   1662b:      	callq	*%rax
   1662d:      	leaq	0x6458(%r14), %rdi
   16634:      	leaq	0x8(%r12), %rdx
   16639:      	movl	$0x8, %ecx
   1663e:      	movl	$0x4, %eax
   16643:      	movl	$0x8, %esi
   16648:      	callq	*%rax
   1664a:      	testq	%rax, %rax
   1664d:      	je	0x166ac <generic_usdt_path+0xbdac>
   1664f:      	negl	%eax
   16651:      	movw	%ax, 0x18(%rsp)
   16656:      	movw	$0x6, 0x1a(%rsp)
   1665d:      	movabsq	$0x40000003a, %rax      # imm = 0x40000003A
   16667:      	movq	%rax, 0x1c(%rsp)
   1666c:      	movq	(%rip), %rdi            # 0x16673 <generic_usdt_path+0xbd73>
   16673:      	leaq	0x18(%rsp), %rsi
   16678:      	movl	$0x1, %eax
   1667d:      	callq	*%rax
   1667f:      	testq	%rax, %rax
   16682:      	je	0x16688 <generic_usdt_path+0xbd88>
   16684:      	incl	(%rax)
   16686:      	jmp	0x166ac <generic_usdt_path+0xbdac>
   16688:      	movl	$0x1, 0x8(%rsp)
   16690:      	movq	(%rip), %rdi            # 0x16697 <generic_usdt_path+0xbd97>
   16697:      	xorl	%ecx, %ecx
   16699:      	leaq	0x18(%rsp), %rsi
   1669e:      	leaq	0x8(%rsp), %rdx
   166a3:      	movl	$0x2, %eax
   166a8:      	xorl	%ecx, %ecx
   166aa:      	callq	*%rax
   166ac:      	movq	%r14, %rdi
   166af:      	addq	$0x6460, %rdi           # imm = 0x6460
   166b6:      	movl	$0x8, %ecx
   166bb:      	movl	$0x4, %eax
   166c0:      	movl	$0x8, %esi
   166c5:      	movq	%r12, %rdx
   166c8:      	callq	*%rax
   166ca:      	testq	%rax, %rax
   166cd:      	je	0x1672c <generic_usdt_path+0xbe2c>
   166cf:      	negl	%eax
   166d1:      	movw	%ax, 0x18(%rsp)
   166d6:      	movw	$0x6, 0x1a(%rsp)
   166dd:      	movabsq	$0x40000003b, %rax      # imm = 0x40000003B
   166e7:      	movq	%rax, 0x1c(%rsp)
   166ec:      	movq	(%rip), %rdi            # 0x166f3 <generic_usdt_path+0xbdf3>
   166f3:      	leaq	0x18(%rsp), %rsi
   166f8:      	movl	$0x1, %eax
   166fd:      	callq	*%rax
   166ff:      	testq	%rax, %rax
   16702:      	je	0x16708 <generic_usdt_path+0xbe08>
   16704:      	incl	(%rax)
   16706:      	jmp	0x1672c <generic_usdt_path+0xbe2c>
   16708:      	movl	$0x1, 0x8(%rsp)
   16710:      	movq	(%rip), %rdi            # 0x16717 <generic_usdt_path+0xbe17>
   16717:      	xorl	%ecx, %ecx
   16719:      	leaq	0x18(%rsp), %rsi
   1671e:      	leaq	0x8(%rsp), %rdx
   16723:      	movl	$0x2, %eax
   16728:      	xorl	%ecx, %ecx
   1672a:      	callq	*%rax
   1672c:      	movq	0x6460(%r14), %rax
   16733:      	addq	$-0x20, %rax
   16737:      	movq	%rax, 0x6468(%r14)
   1673e:      	movl	$0x0, 0x6428(%r14)
   16749:      	subl	%r15d, %ebx
   1674c:      	movl	%ebx, 0x6424(%r14)
   16753:      	movl	$0x1, 0x6420(%r14)
   1675e:      	movq	(%rip), %rsi            # 0x16765 <generic_usdt_path+0xbe65>
   16765:      	movl	$0x6, %ecx
   1676a:      	movl	$0xc, %eax
   1676f:      	movq	%rbp, %rdi
   16772:      	movl	$0x6, %edx
   16777:      	callq	*%rax
   16779:      	xorl	%eax, %eax
   1677b:      	addq	$0x88, %rsp
   16782:      	popq	%rbx
   16783:      	popq	%r12
   16785:      	popq	%r13
   16787:      	popq	%r14
   16789:      	popq	%r15
   1678b:      	popq	%rbp
   1678c:      	retq

Disassembly of section uprobe/generic_usdt:

0000000000000000 <generic_usdt_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x88, %rsp
      11:      	movq	%rdi, %rbx
      14:      	movl	$0x0, 0x38(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <generic_usdt_event+0x23>
      23:      	leaq	0x38(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x62d <generic_usdt_event+0x62d>
      38:      	movq	%rax, %r14
      3b:      	leaq	0x5ef8(%rax), %rsi
      42:      	movl	$0x0, 0x5ef8(%rax)
      4c:      	movq	(%rip), %rdi            # 0x53 <generic_usdt_event+0x53>
      53:      	movl	$0x1, %eax
      58:      	callq	*%rax
      5a:      	testq	%rax, %rax
      5d:      	je	0x62d <generic_usdt_event+0x62d>
      63:      	movl	0x64(%rax), %ecx
      66:      	movl	%ecx, 0x14(%rsp)
      6a:      	testl	%ecx, %ecx
      6c:      	je	0x23b <generic_usdt_event+0x23b>
      72:      	movq	%rax, %r12
      75:      	movq	(%rip), %rdi            # 0x7c <generic_usdt_event+0x7c>
      7c:      	leaq	0x14(%rsp), %rsi
      81:      	movl	$0x1, %eax
      86:      	callq	*%rax
      88:      	testq	%rax, %rax
      8b:      	je	0x62d <generic_usdt_event+0x62d>
      91:      	movq	%rax, %r15
      94:      	movl	$0x0, 0x3c(%rsp)
      9c:      	movq	(%rip), %rdi            # 0xa3 <generic_usdt_event+0xa3>
      a3:      	leaq	0x3c(%rsp), %rsi
      a8:      	movl	$0x1, %eax
      ad:      	callq	*%rax
      af:      	testq	%rax, %rax
      b2:      	je	0xd8 <generic_usdt_event+0xd8>
      b4:      	cmpq	$0x63677270, 0x20(%rax) # imm = 0x63677270
      bc:      	jne	0xdc <generic_usdt_event+0xdc>
      be:      	movl	$0x50, %eax
      c3:      	callq	*%rax
      c5:      	movq	%rax, 0x8(%rsp)
      ca:      	testq	%rax, %rax
      cd:      	jne	0x1f6 <generic_usdt_event+0x1f6>
      d3:      	jmp	0x62d <generic_usdt_event+0x62d>
      d8:      	xorl	%ebp, %ebp
      da:      	jmp	0xdf <generic_usdt_event+0xdf>
      dc:      	movl	0x10(%rax), %ebp
      df:      	movl	$0x23, %eax
      e4:      	callq	*%rax
      e6:      	movq	$0x0, 0x20(%rsp)
      ef:      	leaq	0xf90(%rax), %rdx
      f6:      	leaq	0x28(%rsp), %rdi
      fb:      	movl	$0x8, %ecx
     100:      	movl	$0x71, %eax
     105:      	movl	$0x8, %esi
     10a:      	callq	*%rax
     10c:      	movq	0x28(%rsp), %rax
     111:      	testq	%rax, %rax
     114:      	je	0x62d <generic_usdt_event+0x62d>
     11a:      	cmpl	$0xb, %ebp
     11d:      	ja	0x62d <generic_usdt_event+0x62d>
     123:      	movl	%ebp, %edx
     125:      	leaq	(%rax,%rdx,8), %rcx
     129:      	leaq	0x40(%rsp), %rdi
     12e:      	movl	$0x8, %esi
     133:      	movl	$0x71, %eax
     138:      	shlq	$0x3, %rdx
     13c:      	addq	0x28(%rsp), %rdx
     141:      	movl	$0x8, %esi
     146:      	callq	*%rax
     148:      	movq	0x40(%rsp), %rcx
     14d:      	testq	%rcx, %rcx
     150:      	je	0x62d <generic_usdt_event+0x62d>
     156:      	leaq	0x20(%rsp), %rdi
     15b:      	movl	$0x8, %edx
     160:      	movl	$0x71, %eax
     165:      	movq	0x40(%rsp), %rdx
     16a:      	movl	$0x8, %esi
     16f:      	callq	*%rax
     171:      	movq	0x20(%rsp), %rdx
     176:      	testq	%rdx, %rdx
     179:      	je	0x62d <generic_usdt_event+0x62d>
     17f:      	movq	$0x0, 0x40(%rsp)
     188:      	addq	$0x100, %rdx            # imm = 0x100
     18f:      	leaq	0x40(%rsp), %rdi
     194:      	movl	$0x8, %ecx
     199:      	movl	$0x71, %eax
     19e:      	movl	$0x8, %esi
     1a3:      	callq	*%rax
     1a5:      	movq	0x40(%rsp), %rdx
     1aa:      	movq	$0x0, 0x40(%rsp)
     1b3:      	testq	%rdx, %rdx
     1b6:      	je	0x1e6 <generic_usdt_event+0x1e6>
     1b8:      	addq	$0x60, %rdx
     1bc:      	leaq	0x40(%rsp), %rdi
     1c1:      	movl	$0x8, %ecx
     1c6:      	movl	$0x71, %eax
     1cb:      	movl	$0x8, %esi
     1d0:      	callq	*%rax
     1d2:      	movq	0x40(%rsp), %rax
     1d7:      	movq	%rax, 0x8(%rsp)
     1dc:      	testq	%rax, %rax
     1df:      	jne	0x1f6 <generic_usdt_event+0x1f6>
     1e1:      	jmp	0x62d <generic_usdt_event+0x62d>
     1e6:      	xorl	%eax, %eax
     1e8:      	movq	%rax, 0x8(%rsp)
     1ed:      	testq	%rax, %rax
     1f0:      	je	0x62d <generic_usdt_event+0x62d>
     1f6:      	movq	%rax, 0x40(%rsp)
     1fb:      	movq	(%rip), %rdi            # 0x202 <generic_usdt_event+0x202>
     202:      	leaq	0x40(%rsp), %rsi
     207:      	movl	$0x1, %eax
     20c:      	callq	*%rax
     20e:      	testq	%rax, %rax
     211:      	je	0x220 <generic_usdt_event+0x220>
     213:      	movq	(%rax), %rax
     216:      	testq	%rax, %rax
     219:      	je	0x220 <generic_usdt_event+0x220>
     21b:      	movq	%rax, 0x8(%rsp)
     220:      	leaq	0x8(%rsp), %rsi
     225:      	movl	$0x1, %eax
     22a:      	movq	%r15, %rdi
     22d:      	callq	*%rax
     22f:      	testq	%rax, %rax
     232:      	movq	%r12, %rax
     235:      	je	0x641 <generic_usdt_event+0x641>
     23b:      	movl	(%rax), %eax
     23d:      	movq	%rax, 0x60(%r14)
     241:      	movq	$0x0, 0x68(%r14)
     249:      	movq	$0x0, 0x5efc(%r14)
     254:      	movl	$0x0, 0x6420(%r14)
     25f:      	movq	$0x0, 0x5eb8(%r14)
     26a:      	movq	$0x0, 0x5ec0(%r14)
     275:      	movq	$0x0, 0x5ec8(%r14)
     280:      	movq	$0x0, 0x5ed0(%r14)
     28b:      	movq	$0x0, 0x5ed8(%r14)
     296:      	movb	$0x0, 0x5ee0(%r14)
     29e:      	movl	$0x23, %eax
     2a3:      	callq	*%rax
     2a5:      	movq	%rax, %r15
     2a8:      	leaq	0xd70(%rax), %rdx
     2af:      	leaq	0x20(%rsp), %rdi
     2b4:      	movl	$0x8, %ecx
     2b9:      	movl	$0x4, %eax
     2be:      	leaq	0x20(%r14), %r12
     2c2:      	movl	$0x4, %r13d
     2c8:      	movl	$0x8, %esi
     2cd:      	callq	*%rax
     2cf:      	movq	0x20(%rsp), %rcx
     2d4:      	leaq	0x40(%rsp), %rdi
     2d9:      	movl	$0x48, %edx
     2de:      	movl	$0x4, %eax
     2e3:      	movq	0x20(%rsp), %rdx
     2e8:      	movl	$0x48, %esi
     2ed:      	callq	*%rax
     2ef:      	movl	$0x218, %edx            # imm = 0x218
     2f4:      	movq	0x48(%rsp), %rcx
     2f9:      	addq	%rdx, %rcx
     2fc:      	movl	$0x4, %esi
     301:      	movl	$0x4, %eax
     306:      	addq	0x48(%rsp), %rdx
     30b:      	movq	%r12, %rdi
     30e:      	movl	$0x4, %esi
     313:      	callq	*%rax
     315:      	leaq	0x24(%r14), %rdi
     319:      	movl	$0x4d8, %edx            # imm = 0x4D8
     31e:      	movq	0x50(%rsp), %rcx
     323:      	addq	%rdx, %rcx
     326:      	movl	$0x4, %esi
     32b:      	movl	$0x4, %eax
     330:      	addq	0x50(%rsp), %rdx
     335:      	movl	$0x4, %esi
     33a:      	callq	*%rax
     33c:      	leaq	0x28(%r14), %rdi
     340:      	movq	0x58(%rsp), %rcx
     345:      	addq	$0x58, %rcx
     349:      	movl	$0x4, %edx
     34e:      	movl	$0x4, %eax
     353:      	movq	0x58(%rsp), %rdx
     358:      	addq	$0x58, %rdx
     35c:      	movl	$0x4, %esi
     361:      	callq	*%rax
     363:      	movq	$0x0, 0x8(%rsp)
     36c:      	leaq	0xb58(%r15), %rdx
     373:      	leaq	0x8(%rsp), %rdi
     378:      	movl	$0x8, %ecx
     37d:      	movl	$0x4, %eax
     382:      	movl	$0x8, %esi
     387:      	callq	*%rax
     389:      	movq	0x8(%rsp), %rcx
     38e:      	testq	%rcx, %rcx
     391:      	je	0x427 <generic_usdt_event+0x427>
     397:      	movl	$0x0, 0x18(%rsp)
     39f:      	addq	$0x4, %rcx
     3a3:      	leaq	0x18(%rsp), %rdi
     3a8:      	movl	$0x4, %eax
     3ad:      	movq	0x8(%rsp), %rdx
     3b2:      	addq	$0x4, %rdx
     3b6:      	movl	$0x4, %esi
     3bb:      	callq	*%rax
     3bd:      	movq	0x8(%rsp), %rax
     3c2:      	movslq	0x18(%rsp), %rcx
     3c7:      	shlq	$0x4, %rcx
     3cb:      	addq	%rax, %rcx
     3ce:      	addq	$0x80, %rcx
     3d5:      	leaq	0x28(%rsp), %rdi
     3da:      	movl	$0x10, %edx
     3df:      	movl	$0x4, %eax
     3e4:      	movq	0x8(%rsp), %rcx
     3e9:      	movslq	0x18(%rsp), %rdx
     3ee:      	shlq	$0x4, %rdx
     3f2:      	addq	%rcx, %rdx
     3f5:      	addq	$0x80, %rdx
     3fc:      	movl	$0x10, %esi
     401:      	callq	*%rax
     403:      	leaq	0x2c(%r14), %rdi
     407:      	movl	$0x158, %edx            # imm = 0x158
     40c:      	movq	0x30(%rsp), %rcx
     411:      	addq	%rdx, %rcx
     414:      	movl	$0x4, %eax
     419:      	addq	0x30(%rsp), %rdx
     41e:      	movl	$0x4, %esi
     423:      	callq	*%rax
     425:      	jmp	0x42f <generic_usdt_event+0x42f>
     427:      	movl	$0x0, 0x2c(%r14)
     42f:      	leaq	0x30(%r14), %rdi
     433:      	movl	$0x158, %r12d           # imm = 0x158
     439:      	movq	0x60(%rsp), %rcx
     43e:      	addq	%r12, %rcx
     441:      	movl	$0x4, %edx
     446:      	movl	$0x4, %eax
     44b:      	movq	0x60(%rsp), %rdx
     450:      	addq	%r12, %rdx
     453:      	movl	$0x4, %esi
     458:      	callq	*%rax
     45a:      	leaq	0x34(%r14), %rdi
     45e:      	movl	$0x118, %edx            # imm = 0x118
     463:      	movq	0x68(%rsp), %rcx
     468:      	addq	%rdx, %rcx
     46b:      	movl	$0x4, %esi
     470:      	movl	$0x4, %eax
     475:      	addq	0x68(%rsp), %rdx
     47a:      	movl	$0x4, %esi
     47f:      	callq	*%rax
     481:      	leaq	0x38(%r14), %rdi
     485:      	movl	$0x98, %r13d
     48b:      	movq	0x70(%rsp), %rcx
     490:      	addq	%r13, %rcx
     493:      	movl	$0x4, %edx
     498:      	movl	$0x4, %eax
     49d:      	movq	0x70(%rsp), %rdx
     4a2:      	addq	%r13, %rdx
     4a5:      	movl	$0x4, %esi
     4aa:      	callq	*%rax
     4ac:      	leaq	0x3c(%r14), %rdi
     4b0:      	movq	0x78(%rsp), %rcx
     4b5:      	addq	%r13, %rcx
     4b8:      	movl	$0x4, %edx
     4bd:      	movl	$0x4, %eax
     4c2:      	addq	0x78(%rsp), %r13
     4c7:      	movl	$0x4, %esi
     4cc:      	movq	%r13, %rdx
     4cf:      	callq	*%rax
     4d1:      	leaq	0x40(%r14), %rdi
     4d5:      	movq	0x80(%rsp), %rcx
     4dd:      	addq	$0x58, %rcx
     4e1:      	movl	$0x4, %edx
     4e6:      	movl	$0x4, %eax
     4eb:      	movq	0x80(%rsp), %rdx
     4f3:      	addq	$0x58, %rdx
     4f7:      	movl	$0x4, %esi
     4fc:      	callq	*%rax
     4fe:      	movq	$0x0, 0x28(%rsp)
     507:      	movq	$0x0, 0x8(%rsp)
     510:      	addq	$0xd00, %r15            # imm = 0xD00
     517:      	leaq	0x28(%rsp), %rdi
     51c:      	movl	$0x8, %ecx
     521:      	movl	$0x4, %eax
     526:      	movl	$0x8, %esi
     52b:      	movq	%r15, %rdx
     52e:      	callq	*%rax
     530:      	movl	$0x90, %edx
     535:      	movq	0x28(%rsp), %rcx
     53a:      	addq	%rdx, %rcx
     53d:      	leaq	0x8(%rsp), %rdi
     542:      	movl	$0x8, %esi
     547:      	movl	$0x4, %eax
     54c:      	addq	0x28(%rsp), %rdx
     551:      	movl	$0x8, %esi
     556:      	callq	*%rax
     558:      	leaq	0x44(%r14), %rdi
     55c:      	movq	0x8(%rsp), %rcx
     561:      	addq	%r12, %rcx
     564:      	movl	$0x4, %edx
     569:      	movl	$0x4, %eax
     56e:      	addq	0x8(%rsp), %r12
     573:      	movl	$0x4, %esi
     578:      	movq	%r12, %rdx
     57b:      	callq	*%rax
     57d:      	leaq	0x48(%r14), %r12
     581:      	leaq	0x40(%rsp), %rdi
     586:      	movl	$0x8, %ecx
     58b:      	movl	$0x4, %eax
     590:      	movl	$0x8, %esi
     595:      	movq	%r15, %rdx
     598:      	callq	*%rax
     59a:      	movq	0x40(%rsp), %r15
     59f:      	leaq	0x50(%r14), %rdi
     5a3:      	leaq	0x40(%r15), %rdx
     5a7:      	movl	$0x8, %ecx
     5ac:      	movl	$0x4, %eax
     5b1:      	movl	$0x8, %esi
     5b6:      	callq	*%rax
     5b8:      	movq	%r14, %rdi
     5bb:      	addq	$0x58, %rdi
     5bf:      	leaq	0x30(%r15), %rdx
     5c3:      	movl	$0x8, %ecx
     5c8:      	movl	$0x4, %eax
     5cd:      	movl	$0x8, %esi
     5d2:      	callq	*%rax
     5d4:      	addq	$0x38, %r15
     5d8:      	movl	$0x8, %ecx
     5dd:      	movl	$0x4, %eax
     5e2:      	movq	%r12, %rdi
     5e5:      	movl	$0x8, %esi
     5ea:      	movq	%r15, %rdx
     5ed:      	callq	*%rax
     5ef:      	movb	$0x0, 0x5f08(%r14)
     5f7:      	movb	$0x0, 0x1(%r14)
     5fc:      	movq	$0x0, 0x5ee8(%r14)
     607:      	movq	$0x0, 0x5ef0(%r14)
     612:      	movq	(%rip), %rsi            # 0x619 <generic_usdt_event+0x619>
     619:      	movl	$0x2, %ecx
     61e:      	movl	$0xc, %eax
     623:      	movq	%rbx, %rdi
     626:      	movl	$0x2, %edx
     62b:      	callq	*%rax
     62d:      	xorl	%eax, %eax
     62f:      	addq	$0x88, %rsp
     636:      	popq	%rbx
     637:      	popq	%r12
     639:      	popq	%r13
     63b:      	popq	%r14
     63d:      	popq	%r15
     63f:      	popq	%rbp
     640:      	retq
     641:      	movq	$-0x1, 0x18(%rsp)
     64a:      	leaq	0x18(%rsp), %rsi
     64f:      	movl	$0x1, %eax
     654:      	movq	%r15, %rdi
     657:      	callq	*%rax
     659:      	testq	%rax, %rax
     65c:      	je	0x62d <generic_usdt_event+0x62d>
     65e:      	movl	$0x1, 0x14(%rsp)
     666:      	movq	(%rip), %rdi            # 0x66d <generic_usdt_event+0x66d>
     66d:      	leaq	0x14(%rsp), %rsi
     672:      	movl	$0x1, %eax
     677:      	callq	*%rax
     679:      	testq	%rax, %rax
     67c:      	je	0x62d <generic_usdt_event+0x62d>
     67e:      	movq	%rax, %rdi
     681:      	leaq	0x8(%rsp), %rsi
     686:      	movl	$0x1, %eax
     68b:      	callq	*%rax
     68d:      	testq	%rax, %rax
     690:      	movq	%r12, %rax
     693:      	jne	0x62d <generic_usdt_event+0x62d>
     695:      	jmp	0x23b <generic_usdt_event+0x23b>

Disassembly of section uprobe.s/generic_usdt:

0000000000000000 <generic_sleepable_preload>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xa8, %rsp
      11:      	movq	%rdi, %r14
      14:      	movl	$0x0, 0xa4(%rsp)
      1f:      	movq	(%rip), %rdi            # 0x26 <generic_sleepable_preload+0x26>
      26:      	leaq	0xa4(%rsp), %rsi
      2e:      	movl	$0x1, %eax
      33:      	callq	*%rax
      35:      	testq	%rax, %rax
      38:      	je	0x125 <generic_sleepable_preload+0x125>
      3e:      	movq	%rax, %rbx
      41:      	leaq	0x98(%r14), %rax
      48:      	movq	%rax, 0x60(%rsp)
      4d:      	leaq	0x80(%r14), %rax
      54:      	movq	%rax, 0x58(%rsp)
      59:      	leaq	0x70(%r14), %rax
      5d:      	movq	%rax, 0x98(%rsp)
      65:      	leaq	0x68(%r14), %rax
      69:      	movq	%rax, 0x48(%rsp)
      6e:      	leaq	0x60(%r14), %rax
      72:      	movq	%rax, 0x90(%rsp)
      7a:      	leaq	0x58(%r14), %rax
      7e:      	movq	%rax, 0x40(%rsp)
      83:      	leaq	0x50(%r14), %rax
      87:      	movq	%rax, 0x88(%rsp)
      8f:      	leaq	0x48(%r14), %rax
      93:      	movq	%rax, 0x38(%rsp)
      98:      	leaq	0x40(%r14), %rax
      9c:      	movq	%rax, 0x80(%rsp)
      a4:      	leaq	0x38(%r14), %rax
      a8:      	movq	%rax, 0x30(%rsp)
      ad:      	leaq	0x30(%r14), %rax
      b1:      	movq	%rax, 0x78(%rsp)
      b6:      	leaq	0x28(%r14), %rax
      ba:      	movq	%rax, 0x28(%rsp)
      bf:      	leaq	0x20(%r14), %rax
      c3:      	movq	%rax, 0x70(%rsp)
      c8:      	leaq	0x18(%r14), %rax
      cc:      	movq	%rax, 0x20(%rsp)
      d1:      	leaq	0x10(%r14), %rax
      d5:      	movq	%rax, 0x68(%rsp)
      da:      	leaq	0x8(%r14), %rax
      de:      	movq	%rax, 0x50(%rsp)
      e3:      	movl	0x18(%rbx), %eax
      e6:      	testl	$0x100, %eax            # imm = 0x100
      eb:      	jne	0x139 <generic_sleepable_preload+0x139>
      ed:      	movl	0x1c(%rbx), %eax
      f0:      	testl	$0x100, %eax            # imm = 0x100
      f5:      	jne	0x199 <generic_sleepable_preload+0x199>
      fb:      	movl	0x20(%rbx), %eax
      fe:      	testl	$0x100, %eax            # imm = 0x100
     103:      	jne	0x1f9 <generic_sleepable_preload+0x1f9>
     109:      	movl	0x24(%rbx), %eax
     10c:      	testl	$0x100, %eax            # imm = 0x100
     111:      	jne	0x259 <generic_sleepable_preload+0x259>
     117:      	movl	0x28(%rbx), %eax
     11a:      	testl	$0x100, %eax            # imm = 0x100
     11f:      	jne	0x2b9 <generic_sleepable_preload+0x2b9>
     125:      	xorl	%eax, %eax
     127:      	addq	$0xa8, %rsp
     12e:      	popq	%rbx
     12f:      	popq	%r12
     131:      	popq	%r13
     133:      	popq	%r14
     135:      	popq	%r15
     137:      	popq	%rbp
     138:      	retq
     139:      	testb	%al, %al
     13b:      	js	0x31b <generic_sleepable_preload+0x31b>
     141:      	movzbl	0x211(%rbx), %eax
     148:      	xorl	%ecx, %ecx
     14a:      	cmpl	$0x2, %eax
     14d:      	jg	0x50a <generic_sleepable_preload+0x50a>
     153:      	cmpl	$0x1, %eax
     156:      	je	0xa50 <generic_sleepable_preload+0xa50>
     15c:      	cmpl	$0x2, %eax
     15f:      	jne	0xbbb <generic_sleepable_preload+0xbbb>
     165:      	movl	0x208(%rbx), %edx
     16b:      	andl	$0xfff, %edx            # imm = 0xFFF
     171:      	addq	%r14, %rdx
     174:      	leaq	0x10(%rsp), %rdi
     179:      	movl	$0x8, %ecx
     17e:      	movl	$0x71, %eax
     183:      	movl	$0x8, %esi
     188:      	callq	*%rax
     18a:      	testl	%eax, %eax
     18c:      	je	0xa5c <generic_sleepable_preload+0xa5c>
     192:      	xorl	%ecx, %ecx
     194:      	jmp	0xbbb <generic_sleepable_preload+0xbbb>
     199:      	testb	%al, %al
     19b:      	js	0x37e <generic_sleepable_preload+0x37e>
     1a1:      	movzbl	0x229(%rbx), %eax
     1a8:      	xorl	%ecx, %ecx
     1aa:      	cmpl	$0x2, %eax
     1ad:      	jg	0x5cf <generic_sleepable_preload+0x5cf>
     1b3:      	cmpl	$0x1, %eax
     1b6:      	je	0xa84 <generic_sleepable_preload+0xa84>
     1bc:      	cmpl	$0x2, %eax
     1bf:      	jne	0xf58 <generic_sleepable_preload+0xf58>
     1c5:      	movl	0x220(%rbx), %edx
     1cb:      	andl	$0xfff, %edx            # imm = 0xFFF
     1d1:      	addq	%r14, %rdx
     1d4:      	leaq	0x10(%rsp), %rdi
     1d9:      	movl	$0x8, %ecx
     1de:      	movl	$0x71, %eax
     1e3:      	movl	$0x8, %esi
     1e8:      	callq	*%rax
     1ea:      	testl	%eax, %eax
     1ec:      	je	0xa90 <generic_sleepable_preload+0xa90>
     1f2:      	xorl	%ecx, %ecx
     1f4:      	jmp	0xf58 <generic_sleepable_preload+0xf58>
     1f9:      	testb	%al, %al
     1fb:      	js	0x3e1 <generic_sleepable_preload+0x3e1>
     201:      	movzbl	0x241(%rbx), %eax
     208:      	xorl	%ecx, %ecx
     20a:      	cmpl	$0x2, %eax
     20d:      	jg	0x649 <generic_sleepable_preload+0x649>
     213:      	cmpl	$0x1, %eax
     216:      	je	0xabd <generic_sleepable_preload+0xabd>
     21c:      	cmpl	$0x2, %eax
     21f:      	jne	0x1307 <generic_sleepable_preload+0x1307>
     225:      	movl	0x238(%rbx), %edx
     22b:      	andl	$0xfff, %edx            # imm = 0xFFF
     231:      	addq	%r14, %rdx
     234:      	leaq	0x10(%rsp), %rdi
     239:      	movl	$0x8, %ecx
     23e:      	movl	$0x71, %eax
     243:      	movl	$0x8, %esi
     248:      	callq	*%rax
     24a:      	testl	%eax, %eax
     24c:      	je	0xac9 <generic_sleepable_preload+0xac9>
     252:      	xorl	%ecx, %ecx
     254:      	jmp	0x1307 <generic_sleepable_preload+0x1307>
     259:      	testb	%al, %al
     25b:      	js	0x444 <generic_sleepable_preload+0x444>
     261:      	movzbl	0x259(%rbx), %eax
     268:      	xorl	%ecx, %ecx
     26a:      	cmpl	$0x2, %eax
     26d:      	jg	0x6c3 <generic_sleepable_preload+0x6c3>
     273:      	cmpl	$0x1, %eax
     276:      	je	0xaf1 <generic_sleepable_preload+0xaf1>
     27c:      	cmpl	$0x2, %eax
     27f:      	jne	0x16b6 <generic_sleepable_preload+0x16b6>
     285:      	movl	0x250(%rbx), %edx
     28b:      	andl	$0xfff, %edx            # imm = 0xFFF
     291:      	addq	%r14, %rdx
     294:      	leaq	0x10(%rsp), %rdi
     299:      	movl	$0x8, %ecx
     29e:      	movl	$0x71, %eax
     2a3:      	movl	$0x8, %esi
     2a8:      	callq	*%rax
     2aa:      	testl	%eax, %eax
     2ac:      	je	0xafd <generic_sleepable_preload+0xafd>
     2b2:      	xorl	%ecx, %ecx
     2b4:      	jmp	0x16b6 <generic_sleepable_preload+0x16b6>
     2b9:      	testb	%al, %al
     2bb:      	js	0x4a7 <generic_sleepable_preload+0x4a7>
     2c1:      	movzbl	0x271(%rbx), %eax
     2c8:      	xorl	%ecx, %ecx
     2ca:      	cmpl	$0x2, %eax
     2cd:      	jg	0x73d <generic_sleepable_preload+0x73d>
     2d3:      	cmpl	$0x1, %eax
     2d6:      	je	0xb25 <generic_sleepable_preload+0xb25>
     2dc:      	cmpl	$0x2, %eax
     2df:      	jne	0x1a67 <generic_sleepable_preload+0x1a67>
     2e5:      	movl	0x268(%rbx), %eax
     2eb:      	andl	$0xfff, %eax            # imm = 0xFFF
     2f0:      	addq	%rax, %r14
     2f3:      	leaq	0x10(%rsp), %rdi
     2f8:      	movl	$0x8, %ecx
     2fd:      	movl	$0x71, %eax
     302:      	movl	$0x8, %esi
     307:      	movq	%r14, %rdx
     30a:      	callq	*%rax
     30c:      	testl	%eax, %eax
     30e:      	je	0xb31 <generic_sleepable_preload+0xb31>
     314:      	xorl	%ecx, %ecx
     316:      	jmp	0x1a67 <generic_sleepable_preload+0x1a67>
     31b:      	movzbl	0x2c2(%rbx), %eax
     322:      	movzwl	0x2c0(%rbx), %ecx
     329:      	rorxl	$0x3, %ecx, %edx
     32f:      	xorl	%ecx, %ecx
     331:      	cmpl	$0x7, %edx
     334:      	jle	0x7b9 <generic_sleepable_preload+0x7b9>
     33a:      	cmpl	$0xb, %edx
     33d:      	jle	0x89d <generic_sleepable_preload+0x89d>
     343:      	cmpl	$0xd, %edx
     346:      	jle	0x1f9f <generic_sleepable_preload+0x1f9f>
     34c:      	movq	0x98(%rsp), %rsi
     354:      	cmpl	$0xe, %edx
     357:      	je	0x1fb6 <generic_sleepable_preload+0x1fb6>
     35d:      	movq	0x58(%rsp), %rsi
     362:      	cmpl	$0x10, %edx
     365:      	je	0x1fb6 <generic_sleepable_preload+0x1fb6>
     36b:      	cmpl	$0x13, %edx
     36e:      	jne	0x1fc9 <generic_sleepable_preload+0x1fc9>
     374:      	movq	0x60(%rsp), %rsi
     379:      	jmp	0x1fb6 <generic_sleepable_preload+0x1fb6>
     37e:      	movzbl	0x2c6(%rbx), %eax
     385:      	movzwl	0x2c4(%rbx), %ecx
     38c:      	rorxl	$0x3, %ecx, %edx
     392:      	xorl	%ecx, %ecx
     394:      	cmpl	$0x7, %edx
     397:      	jle	0x7e9 <generic_sleepable_preload+0x7e9>
     39d:      	cmpl	$0xb, %edx
     3a0:      	jle	0x8ca <generic_sleepable_preload+0x8ca>
     3a6:      	cmpl	$0xd, %edx
     3a9:      	jle	0x229a <generic_sleepable_preload+0x229a>
     3af:      	movq	0x98(%rsp), %rsi
     3b7:      	cmpl	$0xe, %edx
     3ba:      	je	0x265e <generic_sleepable_preload+0x265e>
     3c0:      	movq	0x60(%rsp), %rsi
     3c5:      	cmpl	$0x13, %edx
     3c8:      	je	0x265e <generic_sleepable_preload+0x265e>
     3ce:      	movq	0x58(%rsp), %rsi
     3d3:      	cmpl	$0x10, %edx
     3d6:      	je	0x265e <generic_sleepable_preload+0x265e>
     3dc:      	jmp	0x2671 <generic_sleepable_preload+0x2671>
     3e1:      	movzbl	0x2ca(%rbx), %eax
     3e8:      	movzwl	0x2c8(%rbx), %ecx
     3ef:      	rorxl	$0x3, %ecx, %edx
     3f5:      	xorl	%ecx, %ecx
     3f7:      	cmpl	$0x7, %edx
     3fa:      	jle	0x816 <generic_sleepable_preload+0x816>
     400:      	cmpl	$0xb, %edx
     403:      	jle	0x8f7 <generic_sleepable_preload+0x8f7>
     409:      	cmpl	$0xd, %edx
     40c:      	jle	0x22be <generic_sleepable_preload+0x22be>
     412:      	movq	0x98(%rsp), %rsi
     41a:      	cmpl	$0xe, %edx
     41d:      	je	0x2962 <generic_sleepable_preload+0x2962>
     423:      	movq	0x60(%rsp), %rsi
     428:      	cmpl	$0x13, %edx
     42b:      	je	0x2962 <generic_sleepable_preload+0x2962>
     431:      	movq	0x58(%rsp), %rsi
     436:      	cmpl	$0x10, %edx
     439:      	je	0x2962 <generic_sleepable_preload+0x2962>
     43f:      	jmp	0x2975 <generic_sleepable_preload+0x2975>
     444:      	movzbl	0x2ce(%rbx), %eax
     44b:      	movzwl	0x2cc(%rbx), %ecx
     452:      	rorxl	$0x3, %ecx, %edx
     458:      	xorl	%ecx, %ecx
     45a:      	cmpl	$0x7, %edx
     45d:      	jle	0x843 <generic_sleepable_preload+0x843>
     463:      	cmpl	$0xb, %edx
     466:      	jle	0x924 <generic_sleepable_preload+0x924>
     46c:      	cmpl	$0xd, %edx
     46f:      	jle	0x22e2 <generic_sleepable_preload+0x22e2>
     475:      	movq	0x98(%rsp), %rsi
     47d:      	cmpl	$0xe, %edx
     480:      	je	0x2c66 <generic_sleepable_preload+0x2c66>
     486:      	movq	0x60(%rsp), %rsi
     48b:      	cmpl	$0x13, %edx
     48e:      	je	0x2c66 <generic_sleepable_preload+0x2c66>
     494:      	movq	0x58(%rsp), %rsi
     499:      	cmpl	$0x10, %edx
     49c:      	je	0x2c66 <generic_sleepable_preload+0x2c66>
     4a2:      	jmp	0x2c79 <generic_sleepable_preload+0x2c79>
     4a7:      	movzbl	0x2d2(%rbx), %eax
     4ae:      	movzwl	0x2d0(%rbx), %ecx
     4b5:      	rorxl	$0x3, %ecx, %edx
     4bb:      	xorl	%ecx, %ecx
     4bd:      	cmpl	$0x7, %edx
     4c0:      	jle	0x870 <generic_sleepable_preload+0x870>
     4c6:      	cmpl	$0xb, %edx
     4c9:      	jle	0x951 <generic_sleepable_preload+0x951>
     4cf:      	cmpl	$0xd, %edx
     4d2:      	jle	0x2306 <generic_sleepable_preload+0x2306>
     4d8:      	movq	0x98(%rsp), %r14
     4e0:      	cmpl	$0xe, %edx
     4e3:      	je	0x231d <generic_sleepable_preload+0x231d>
     4e9:      	movq	0x60(%rsp), %r14
     4ee:      	cmpl	$0x13, %edx
     4f1:      	je	0x231d <generic_sleepable_preload+0x231d>
     4f7:      	movq	0x58(%rsp), %r14
     4fc:      	cmpl	$0x10, %edx
     4ff:      	je	0x231d <generic_sleepable_preload+0x231d>
     505:      	jmp	0x2330 <generic_sleepable_preload+0x2330>
     50a:      	cmpl	$0x3, %eax
     50d:      	je	0xb59 <generic_sleepable_preload+0xb59>
     513:      	cmpl	$0x4, %eax
     516:      	jne	0xbbb <generic_sleepable_preload+0xbbb>
     51c:      	movl	0x208(%rbx), %edx
     522:      	andl	$0xfff, %edx            # imm = 0xFFF
     528:      	addq	%r14, %rdx
     52b:      	leaq	0x10(%rsp), %rdi
     530:      	movl	$0x8, %ecx
     535:      	movl	$0x71, %eax
     53a:      	movl	$0x8, %esi
     53f:      	callq	*%rax
     541:      	testl	%eax, %eax
     543:      	jne	0xbb8 <generic_sleepable_preload+0xbb8>
     549:      	movl	0x20c(%rbx), %edx
     54f:      	andl	$0xfff, %edx            # imm = 0xFFF
     555:      	addq	%r14, %rdx
     558:      	movq	%rsp, %rdi
     55b:      	movl	$0x8, %ecx
     560:      	movl	$0x71, %eax
     565:      	movl	$0x8, %esi
     56a:      	callq	*%rax
     56c:      	testl	%eax, %eax
     56e:      	jne	0xbb8 <generic_sleepable_preload+0xbb8>
     574:      	movzbl	0x213(%rbx), %eax
     57b:      	shlxq	%rax, (%rsp), %rax
     581:      	movq	0x200(%rbx), %rcx
     588:      	addq	0x10(%rsp), %rcx
     58d:      	addq	%rax, %rcx
     590:      	leaq	0x10(%rsp), %rdi
     595:      	movl	$0x8, %edx
     59a:      	movl	$0x94, %eax
     59f:      	movzbl	0x213(%rbx), %ecx
     5a6:      	shlxq	%rcx, (%rsp), %rcx
     5ac:      	movq	0x200(%rbx), %rdx
     5b3:      	addq	0x10(%rsp), %rdx
     5b8:      	addq	%rcx, %rdx
     5bb:      	movl	$0x8, %esi
     5c0:      	callq	*%rax
     5c2:      	testl	%eax, %eax
     5c4:      	jne	0xbb8 <generic_sleepable_preload+0xbb8>
     5ca:      	jmp	0xa5c <generic_sleepable_preload+0xa5c>
     5cf:      	cmpl	$0x4, %eax
     5d2:      	je	0xeaf <generic_sleepable_preload+0xeaf>
     5d8:      	cmpl	$0x3, %eax
     5db:      	jne	0xf58 <generic_sleepable_preload+0xf58>
     5e1:      	movl	0x220(%rbx), %edx
     5e7:      	andl	$0xfff, %edx            # imm = 0xFFF
     5ed:      	addq	%r14, %rdx
     5f0:      	leaq	0x10(%rsp), %rdi
     5f5:      	movl	$0x8, %ecx
     5fa:      	movl	$0x71, %eax
     5ff:      	movl	$0x8, %esi
     604:      	callq	*%rax
     606:      	testl	%eax, %eax
     608:      	jne	0xf55 <generic_sleepable_preload+0xf55>
     60e:      	movq	0x10(%rsp), %rcx
     613:      	addq	0x218(%rbx), %rcx
     61a:      	leaq	0x10(%rsp), %rdi
     61f:      	movl	$0x8, %edx
     624:      	movl	$0x94, %eax
     629:      	movq	0x10(%rsp), %rdx
     62e:      	addq	0x218(%rbx), %rdx
     635:      	movl	$0x8, %esi
     63a:      	callq	*%rax
     63c:      	testl	%eax, %eax
     63e:      	jne	0xf55 <generic_sleepable_preload+0xf55>
     644:      	jmp	0xa90 <generic_sleepable_preload+0xa90>
     649:      	cmpl	$0x4, %eax
     64c:      	je	0x125e <generic_sleepable_preload+0x125e>
     652:      	cmpl	$0x3, %eax
     655:      	jne	0x1307 <generic_sleepable_preload+0x1307>
     65b:      	movl	0x238(%rbx), %edx
     661:      	andl	$0xfff, %edx            # imm = 0xFFF
     667:      	addq	%r14, %rdx
     66a:      	leaq	0x10(%rsp), %rdi
     66f:      	movl	$0x8, %ecx
     674:      	movl	$0x71, %eax
     679:      	movl	$0x8, %esi
     67e:      	callq	*%rax
     680:      	testl	%eax, %eax
     682:      	jne	0x1304 <generic_sleepable_preload+0x1304>
     688:      	movq	0x10(%rsp), %rcx
     68d:      	addq	0x230(%rbx), %rcx
     694:      	leaq	0x10(%rsp), %rdi
     699:      	movl	$0x8, %edx
     69e:      	movl	$0x94, %eax
     6a3:      	movq	0x10(%rsp), %rdx
     6a8:      	addq	0x230(%rbx), %rdx
     6af:      	movl	$0x8, %esi
     6b4:      	callq	*%rax
     6b6:      	testl	%eax, %eax
     6b8:      	jne	0x1304 <generic_sleepable_preload+0x1304>
     6be:      	jmp	0xac9 <generic_sleepable_preload+0xac9>
     6c3:      	cmpl	$0x4, %eax
     6c6:      	je	0x160d <generic_sleepable_preload+0x160d>
     6cc:      	cmpl	$0x3, %eax
     6cf:      	jne	0x16b6 <generic_sleepable_preload+0x16b6>
     6d5:      	movl	0x250(%rbx), %edx
     6db:      	andl	$0xfff, %edx            # imm = 0xFFF
     6e1:      	addq	%r14, %rdx
     6e4:      	leaq	0x10(%rsp), %rdi
     6e9:      	movl	$0x8, %ecx
     6ee:      	movl	$0x71, %eax
     6f3:      	movl	$0x8, %esi
     6f8:      	callq	*%rax
     6fa:      	testl	%eax, %eax
     6fc:      	jne	0x16b3 <generic_sleepable_preload+0x16b3>
     702:      	movq	0x10(%rsp), %rcx
     707:      	addq	0x248(%rbx), %rcx
     70e:      	leaq	0x10(%rsp), %rdi
     713:      	movl	$0x8, %edx
     718:      	movl	$0x94, %eax
     71d:      	movq	0x10(%rsp), %rdx
     722:      	addq	0x248(%rbx), %rdx
     729:      	movl	$0x8, %esi
     72e:      	callq	*%rax
     730:      	testl	%eax, %eax
     732:      	jne	0x16b3 <generic_sleepable_preload+0x16b3>
     738:      	jmp	0xafd <generic_sleepable_preload+0xafd>
     73d:      	cmpl	$0x4, %eax
     740:      	je	0x19bc <generic_sleepable_preload+0x19bc>
     746:      	cmpl	$0x3, %eax
     749:      	jne	0x1a67 <generic_sleepable_preload+0x1a67>
     74f:      	movl	0x268(%rbx), %eax
     755:      	andl	$0xfff, %eax            # imm = 0xFFF
     75a:      	addq	%rax, %r14
     75d:      	leaq	0x10(%rsp), %rdi
     762:      	movl	$0x8, %ecx
     767:      	movl	$0x71, %eax
     76c:      	movl	$0x8, %esi
     771:      	movq	%r14, %rdx
     774:      	callq	*%rax
     776:      	testl	%eax, %eax
     778:      	jne	0x1a64 <generic_sleepable_preload+0x1a64>
     77e:      	movq	0x10(%rsp), %rcx
     783:      	addq	0x260(%rbx), %rcx
     78a:      	leaq	0x10(%rsp), %rdi
     78f:      	movl	$0x8, %edx
     794:      	movl	$0x94, %eax
     799:      	movq	0x10(%rsp), %rdx
     79e:      	addq	0x260(%rbx), %rdx
     7a5:      	movl	$0x8, %esi
     7aa:      	callq	*%rax
     7ac:      	testl	%eax, %eax
     7ae:      	jne	0x1a64 <generic_sleepable_preload+0x1a64>
     7b4:      	jmp	0xb31 <generic_sleepable_preload+0xb31>
     7b9:      	cmpl	$0x3, %edx
     7bc:      	jg	0x97e <generic_sleepable_preload+0x97e>
     7c2:      	cmpl	$0x1, %edx
     7c5:      	jg	0x1e55 <generic_sleepable_preload+0x1e55>
     7cb:      	movq	%r14, %rsi
     7ce:      	testl	%edx, %edx
     7d0:      	je	0x1fb6 <generic_sleepable_preload+0x1fb6>
     7d6:      	movq	0x50(%rsp), %rsi
     7db:      	cmpl	$0x1, %edx
     7de:      	je	0x1fb6 <generic_sleepable_preload+0x1fb6>
     7e4:      	jmp	0x1fc9 <generic_sleepable_preload+0x1fc9>
     7e9:      	cmpl	$0x3, %edx
     7ec:      	jg	0x9a8 <generic_sleepable_preload+0x9a8>
     7f2:      	cmpl	$0x1, %edx
     7f5:      	jg	0x1e76 <generic_sleepable_preload+0x1e76>
     7fb:      	testl	%edx, %edx
     7fd:      	je	0x265b <generic_sleepable_preload+0x265b>
     803:      	movq	0x50(%rsp), %rsi
     808:      	cmpl	$0x1, %edx
     80b:      	je	0x265e <generic_sleepable_preload+0x265e>
     811:      	jmp	0x2671 <generic_sleepable_preload+0x2671>
     816:      	cmpl	$0x3, %edx
     819:      	jg	0x9d2 <generic_sleepable_preload+0x9d2>
     81f:      	cmpl	$0x1, %edx
     822:      	jg	0x1e97 <generic_sleepable_preload+0x1e97>
     828:      	testl	%edx, %edx
     82a:      	je	0x295f <generic_sleepable_preload+0x295f>
     830:      	movq	0x50(%rsp), %rsi
     835:      	cmpl	$0x1, %edx
     838:      	je	0x2962 <generic_sleepable_preload+0x2962>
     83e:      	jmp	0x2975 <generic_sleepable_preload+0x2975>
     843:      	cmpl	$0x3, %edx
     846:      	jg	0x9fc <generic_sleepable_preload+0x9fc>
     84c:      	cmpl	$0x1, %edx
     84f:      	jg	0x1eb8 <generic_sleepable_preload+0x1eb8>
     855:      	testl	%edx, %edx
     857:      	je	0x2c63 <generic_sleepable_preload+0x2c63>
     85d:      	movq	0x50(%rsp), %rsi
     862:      	cmpl	$0x1, %edx
     865:      	je	0x2c66 <generic_sleepable_preload+0x2c66>
     86b:      	jmp	0x2c79 <generic_sleepable_preload+0x2c79>
     870:      	cmpl	$0x3, %edx
     873:      	jg	0xa26 <generic_sleepable_preload+0xa26>
     879:      	cmpl	$0x1, %edx
     87c:      	jg	0x1ed9 <generic_sleepable_preload+0x1ed9>
     882:      	testl	%edx, %edx
     884:      	je	0x231d <generic_sleepable_preload+0x231d>
     88a:      	cmpl	$0x1, %edx
     88d:      	movq	0x50(%rsp), %r14
     892:      	je	0x231d <generic_sleepable_preload+0x231d>
     898:      	jmp	0x2330 <generic_sleepable_preload+0x2330>
     89d:      	cmpl	$0x9, %edx
     8a0:      	jg	0x1da1 <generic_sleepable_preload+0x1da1>
     8a6:      	movq	0x80(%rsp), %rsi
     8ae:      	cmpl	$0x8, %edx
     8b1:      	je	0x1fb6 <generic_sleepable_preload+0x1fb6>
     8b7:      	movq	0x38(%rsp), %rsi
     8bc:      	cmpl	$0x9, %edx
     8bf:      	je	0x1fb6 <generic_sleepable_preload+0x1fb6>
     8c5:      	jmp	0x1fc9 <generic_sleepable_preload+0x1fc9>
     8ca:      	cmpl	$0x9, %edx
     8cd:      	jg	0x1dc5 <generic_sleepable_preload+0x1dc5>
     8d3:      	movq	0x80(%rsp), %rsi
     8db:      	cmpl	$0x8, %edx
     8de:      	je	0x265e <generic_sleepable_preload+0x265e>
     8e4:      	movq	0x38(%rsp), %rsi
     8e9:      	cmpl	$0x9, %edx
     8ec:      	je	0x265e <generic_sleepable_preload+0x265e>
     8f2:      	jmp	0x2671 <generic_sleepable_preload+0x2671>
     8f7:      	cmpl	$0x9, %edx
     8fa:      	jg	0x1de9 <generic_sleepable_preload+0x1de9>
     900:      	movq	0x80(%rsp), %rsi
     908:      	cmpl	$0x8, %edx
     90b:      	je	0x2962 <generic_sleepable_preload+0x2962>
     911:      	movq	0x38(%rsp), %rsi
     916:      	cmpl	$0x9, %edx
     919:      	je	0x2962 <generic_sleepable_preload+0x2962>
     91f:      	jmp	0x2975 <generic_sleepable_preload+0x2975>
     924:      	cmpl	$0x9, %edx
     927:      	jg	0x1e0d <generic_sleepable_preload+0x1e0d>
     92d:      	movq	0x80(%rsp), %rsi
     935:      	cmpl	$0x8, %edx
     938:      	je	0x2c66 <generic_sleepable_preload+0x2c66>
     93e:      	movq	0x38(%rsp), %rsi
     943:      	cmpl	$0x9, %edx
     946:      	je	0x2c66 <generic_sleepable_preload+0x2c66>
     94c:      	jmp	0x2c79 <generic_sleepable_preload+0x2c79>
     951:      	cmpl	$0x9, %edx
     954:      	jg	0x1e31 <generic_sleepable_preload+0x1e31>
     95a:      	movq	0x80(%rsp), %r14
     962:      	cmpl	$0x8, %edx
     965:      	je	0x231d <generic_sleepable_preload+0x231d>
     96b:      	movq	0x38(%rsp), %r14
     970:      	cmpl	$0x9, %edx
     973:      	je	0x231d <generic_sleepable_preload+0x231d>
     979:      	jmp	0x2330 <generic_sleepable_preload+0x2330>
     97e:      	cmpl	$0x5, %edx
     981:      	jg	0x1efa <generic_sleepable_preload+0x1efa>
     987:      	movq	0x70(%rsp), %rsi
     98c:      	cmpl	$0x4, %edx
     98f:      	je	0x1fb6 <generic_sleepable_preload+0x1fb6>
     995:      	movq	0x28(%rsp), %rsi
     99a:      	cmpl	$0x5, %edx
     99d:      	je	0x1fb6 <generic_sleepable_preload+0x1fb6>
     9a3:      	jmp	0x1fc9 <generic_sleepable_preload+0x1fc9>
     9a8:      	cmpl	$0x5, %edx
     9ab:      	jg	0x1f1b <generic_sleepable_preload+0x1f1b>
     9b1:      	movq	0x70(%rsp), %rsi
     9b6:      	cmpl	$0x4, %edx
     9b9:      	je	0x265e <generic_sleepable_preload+0x265e>
     9bf:      	movq	0x28(%rsp), %rsi
     9c4:      	cmpl	$0x5, %edx
     9c7:      	je	0x265e <generic_sleepable_preload+0x265e>
     9cd:      	jmp	0x2671 <generic_sleepable_preload+0x2671>
     9d2:      	cmpl	$0x5, %edx
     9d5:      	jg	0x1f3c <generic_sleepable_preload+0x1f3c>
     9db:      	movq	0x70(%rsp), %rsi
     9e0:      	cmpl	$0x4, %edx
     9e3:      	je	0x2962 <generic_sleepable_preload+0x2962>
     9e9:      	movq	0x28(%rsp), %rsi
     9ee:      	cmpl	$0x5, %edx
     9f1:      	je	0x2962 <generic_sleepable_preload+0x2962>
     9f7:      	jmp	0x2975 <generic_sleepable_preload+0x2975>
     9fc:      	cmpl	$0x5, %edx
     9ff:      	jg	0x1f5d <generic_sleepable_preload+0x1f5d>
     a05:      	movq	0x70(%rsp), %rsi
     a0a:      	cmpl	$0x4, %edx
     a0d:      	je	0x2c66 <generic_sleepable_preload+0x2c66>
     a13:      	movq	0x28(%rsp), %rsi
     a18:      	cmpl	$0x5, %edx
     a1b:      	je	0x2c66 <generic_sleepable_preload+0x2c66>
     a21:      	jmp	0x2c79 <generic_sleepable_preload+0x2c79>
     a26:      	cmpl	$0x5, %edx
     a29:      	jg	0x1f7e <generic_sleepable_preload+0x1f7e>
     a2f:      	movq	0x70(%rsp), %r14
     a34:      	cmpl	$0x4, %edx
     a37:      	je	0x231d <generic_sleepable_preload+0x231d>
     a3d:      	movq	0x28(%rsp), %r14
     a42:      	cmpl	$0x5, %edx
     a45:      	je	0x231d <generic_sleepable_preload+0x231d>
     a4b:      	jmp	0x2330 <generic_sleepable_preload+0x2330>
     a50:      	movq	0x200(%rbx), %rax
     a57:      	movq	%rax, 0x10(%rsp)
     a5c:      	movzbl	0x210(%rbx), %eax
     a63:      	shlxq	%rax, 0x10(%rsp), %rcx
     a6a:      	cmpb	$0x0, 0x212(%rbx)
     a71:      	shrxq	%rax, %rcx, %rdx
     a76:      	sarxq	%rax, %rcx, %rcx
     a7b:      	cmoveq	%rdx, %rcx
     a7f:      	jmp	0xbbb <generic_sleepable_preload+0xbbb>
     a84:      	movq	0x218(%rbx), %rax
     a8b:      	movq	%rax, 0x10(%rsp)
     a90:      	movzbl	0x228(%rbx), %eax
     a97:      	shlxq	%rax, 0x10(%rsp), %rcx
     a9e:      	movq	%rcx, 0x10(%rsp)
     aa3:      	cmpb	$0x0, 0x22a(%rbx)
     aaa:      	shrxq	%rax, %rcx, %rdx
     aaf:      	sarxq	%rax, %rcx, %rcx
     ab4:      	cmoveq	%rdx, %rcx
     ab8:      	jmp	0xf58 <generic_sleepable_preload+0xf58>
     abd:      	movq	0x230(%rbx), %rax
     ac4:      	movq	%rax, 0x10(%rsp)
     ac9:      	movzbl	0x240(%rbx), %eax
     ad0:      	shlxq	%rax, 0x10(%rsp), %rcx
     ad7:      	cmpb	$0x0, 0x242(%rbx)
     ade:      	shrxq	%rax, %rcx, %rdx
     ae3:      	sarxq	%rax, %rcx, %rcx
     ae8:      	cmoveq	%rdx, %rcx
     aec:      	jmp	0x1307 <generic_sleepable_preload+0x1307>
     af1:      	movq	0x248(%rbx), %rax
     af8:      	movq	%rax, 0x10(%rsp)
     afd:      	movzbl	0x258(%rbx), %eax
     b04:      	shlxq	%rax, 0x10(%rsp), %rcx
     b0b:      	cmpb	$0x0, 0x25a(%rbx)
     b12:      	shrxq	%rax, %rcx, %rdx
     b17:      	sarxq	%rax, %rcx, %rcx
     b1c:      	cmoveq	%rdx, %rcx
     b20:      	jmp	0x16b6 <generic_sleepable_preload+0x16b6>
     b25:      	movq	0x260(%rbx), %rax
     b2c:      	movq	%rax, 0x10(%rsp)
     b31:      	movzbl	0x270(%rbx), %eax
     b38:      	shlxq	%rax, 0x10(%rsp), %rcx
     b3f:      	cmpb	$0x0, 0x272(%rbx)
     b46:      	shrxq	%rax, %rcx, %rdx
     b4b:      	sarxq	%rax, %rcx, %rcx
     b50:      	cmoveq	%rdx, %rcx
     b54:      	jmp	0x1a67 <generic_sleepable_preload+0x1a67>
     b59:      	movl	0x208(%rbx), %edx
     b5f:      	andl	$0xfff, %edx            # imm = 0xFFF
     b65:      	addq	%r14, %rdx
     b68:      	leaq	0x10(%rsp), %rdi
     b6d:      	movl	$0x8, %ecx
     b72:      	movl	$0x71, %eax
     b77:      	movl	$0x8, %esi
     b7c:      	callq	*%rax
     b7e:      	testl	%eax, %eax
     b80:      	jne	0xbb8 <generic_sleepable_preload+0xbb8>
     b82:      	movq	0x10(%rsp), %rcx
     b87:      	addq	0x200(%rbx), %rcx
     b8e:      	leaq	0x10(%rsp), %rdi
     b93:      	movl	$0x8, %edx
     b98:      	movl	$0x94, %eax
     b9d:      	movq	0x10(%rsp), %rdx
     ba2:      	addq	0x200(%rbx), %rdx
     ba9:      	movl	$0x8, %esi
     bae:      	callq	*%rax
     bb0:      	testl	%eax, %eax
     bb2:      	je	0xa5c <generic_sleepable_preload+0xa5c>
     bb8:      	movslq	%eax, %rcx
     bbb:      	movq	%rcx, 0x8(%rsp)
     bc0:      	xorl	%r13d, %r13d
     bc3:      	movb	$0x1, %bpl
     bc6:      	cmpw	$0x0, 0x76(%rbx)
     bcb:      	je	0x311c <generic_sleepable_preload+0x311c>
     bd1:      	movl	0x70(%rbx), %eax
     bd4:      	addq	%rax, %rcx
     bd7:      	movq	%rcx, 0x8(%rsp)
     bdc:      	cmpw	$0x0, 0x74(%rbx)
     be1:      	je	0xc06 <generic_sleepable_preload+0xc06>
     be3:      	leaq	0x8(%rsp), %rdi
     be8:      	movl	$0x8, %edx
     bed:      	movl	$0x94, %eax
     bf2:      	movq	0x8(%rsp), %rdx
     bf7:      	movl	$0x8, %esi
     bfc:      	callq	*%rax
     bfe:      	testl	%eax, %eax
     c00:      	js	0x1d6b <generic_sleepable_preload+0x1d6b>
     c06:      	cmpw	$0x0, 0x7e(%rbx)
     c0b:      	je	0x311c <generic_sleepable_preload+0x311c>
     c11:      	movl	0x78(%rbx), %ecx
     c14:      	addq	0x8(%rsp), %rcx
     c19:      	movq	%rcx, 0x8(%rsp)
     c1e:      	cmpw	$0x0, 0x7c(%rbx)
     c23:      	je	0xc48 <generic_sleepable_preload+0xc48>
     c25:      	leaq	0x8(%rsp), %rdi
     c2a:      	movl	$0x8, %edx
     c2f:      	movl	$0x94, %eax
     c34:      	movq	0x8(%rsp), %rdx
     c39:      	movl	$0x8, %esi
     c3e:      	callq	*%rax
     c40:      	testl	%eax, %eax
     c42:      	js	0x2610 <generic_sleepable_preload+0x2610>
     c48:      	cmpw	$0x0, 0x86(%rbx)
     c50:      	je	0x311c <generic_sleepable_preload+0x311c>
     c56:      	movl	0x80(%rbx), %ecx
     c5c:      	addq	0x8(%rsp), %rcx
     c61:      	movq	%rcx, 0x8(%rsp)
     c66:      	cmpw	$0x0, 0x84(%rbx)
     c6e:      	je	0xc93 <generic_sleepable_preload+0xc93>
     c70:      	leaq	0x8(%rsp), %rdi
     c75:      	movl	$0x8, %edx
     c7a:      	movl	$0x94, %eax
     c7f:      	movq	0x8(%rsp), %rdx
     c84:      	movl	$0x8, %esi
     c89:      	callq	*%rax
     c8b:      	testl	%eax, %eax
     c8d:      	js	0x2f67 <generic_sleepable_preload+0x2f67>
     c93:      	cmpw	$0x0, 0x8e(%rbx)
     c9b:      	je	0x311c <generic_sleepable_preload+0x311c>
     ca1:      	movl	0x88(%rbx), %ecx
     ca7:      	addq	0x8(%rsp), %rcx
     cac:      	movq	%rcx, 0x8(%rsp)
     cb1:      	cmpw	$0x0, 0x8c(%rbx)
     cb9:      	je	0xcde <generic_sleepable_preload+0xcde>
     cbb:      	leaq	0x8(%rsp), %rdi
     cc0:      	movl	$0x8, %edx
     cc5:      	movl	$0x94, %eax
     cca:      	movq	0x8(%rsp), %rdx
     ccf:      	movl	$0x8, %esi
     cd4:      	callq	*%rax
     cd6:      	testl	%eax, %eax
     cd8:      	js	0x2fd3 <generic_sleepable_preload+0x2fd3>
     cde:      	cmpw	$0x0, 0x96(%rbx)
     ce6:      	je	0x311c <generic_sleepable_preload+0x311c>
     cec:      	movl	0x90(%rbx), %ecx
     cf2:      	addq	0x8(%rsp), %rcx
     cf7:      	movq	%rcx, 0x8(%rsp)
     cfc:      	cmpw	$0x0, 0x94(%rbx)
     d04:      	je	0xd29 <generic_sleepable_preload+0xd29>
     d06:      	leaq	0x8(%rsp), %rdi
     d0b:      	movl	$0x8, %edx
     d10:      	movl	$0x94, %eax
     d15:      	movq	0x8(%rsp), %rdx
     d1a:      	movl	$0x8, %esi
     d1f:      	callq	*%rax
     d21:      	testl	%eax, %eax
     d23:      	js	0x303f <generic_sleepable_preload+0x303f>
     d29:      	cmpw	$0x0, 0x9e(%rbx)
     d31:      	je	0x311c <generic_sleepable_preload+0x311c>
     d37:      	movl	0x98(%rbx), %ecx
     d3d:      	addq	0x8(%rsp), %rcx
     d42:      	movq	%rcx, 0x8(%rsp)
     d47:      	cmpw	$0x0, 0x9c(%rbx)
     d4f:      	je	0xd74 <generic_sleepable_preload+0xd74>
     d51:      	leaq	0x8(%rsp), %rdi
     d56:      	movl	$0x8, %edx
     d5b:      	movl	$0x94, %eax
     d60:      	movq	0x8(%rsp), %rdx
     d65:      	movl	$0x8, %esi
     d6a:      	callq	*%rax
     d6c:      	testl	%eax, %eax
     d6e:      	js	0x30ab <generic_sleepable_preload+0x30ab>
     d74:      	cmpw	$0x0, 0xa6(%rbx)
     d7c:      	je	0x311c <generic_sleepable_preload+0x311c>
     d82:      	movl	0xa0(%rbx), %ecx
     d88:      	addq	0x8(%rsp), %rcx
     d8d:      	movq	%rcx, 0x8(%rsp)
     d92:      	cmpw	$0x0, 0xa4(%rbx)
     d9a:      	je	0xdbf <generic_sleepable_preload+0xdbf>
     d9c:      	leaq	0x8(%rsp), %rdi
     da1:      	movl	$0x8, %edx
     da6:      	movl	$0x94, %eax
     dab:      	movq	0x8(%rsp), %rdx
     db0:      	movl	$0x8, %esi
     db5:      	callq	*%rax
     db7:      	testl	%eax, %eax
     db9:      	js	0x3114 <generic_sleepable_preload+0x3114>
     dbf:      	cmpw	$0x0, 0xae(%rbx)
     dc7:      	je	0x311c <generic_sleepable_preload+0x311c>
     dcd:      	movl	0xa8(%rbx), %ecx
     dd3:      	addq	0x8(%rsp), %rcx
     dd8:      	movq	%rcx, 0x8(%rsp)
     ddd:      	cmpw	$0x0, 0xac(%rbx)
     de5:      	je	0xe0a <generic_sleepable_preload+0xe0a>
     de7:      	leaq	0x8(%rsp), %rdi
     dec:      	movl	$0x8, %edx
     df1:      	movl	$0x94, %eax
     df6:      	movq	0x8(%rsp), %rdx
     dfb:      	movl	$0x8, %esi
     e00:      	callq	*%rax
     e02:      	testl	%eax, %eax
     e04:      	js	0x38a9 <generic_sleepable_preload+0x38a9>
     e0a:      	cmpw	$0x0, 0xb6(%rbx)
     e12:      	je	0x311c <generic_sleepable_preload+0x311c>
     e18:      	movl	0xb0(%rbx), %ecx
     e1e:      	addq	0x8(%rsp), %rcx
     e23:      	movq	%rcx, 0x8(%rsp)
     e28:      	cmpw	$0x0, 0xb4(%rbx)
     e30:      	je	0xe55 <generic_sleepable_preload+0xe55>
     e32:      	leaq	0x8(%rsp), %rdi
     e37:      	movl	$0x8, %edx
     e3c:      	movl	$0x94, %eax
     e41:      	movq	0x8(%rsp), %rdx
     e46:      	movl	$0x8, %esi
     e4b:      	callq	*%rax
     e4d:      	testl	%eax, %eax
     e4f:      	js	0x395d <generic_sleepable_preload+0x395d>
     e55:      	cmpw	$0x0, 0xbe(%rbx)
     e5d:      	je	0x311c <generic_sleepable_preload+0x311c>
     e63:      	movl	0xb8(%rbx), %ecx
     e69:      	addq	0x8(%rsp), %rcx
     e6e:      	movq	%rcx, 0x8(%rsp)
     e73:      	cmpw	$0x0, 0xbc(%rbx)
     e7b:      	je	0x311c <generic_sleepable_preload+0x311c>
     e81:      	leaq	0x8(%rsp), %rdi
     e86:      	movl	$0x8, %edx
     e8b:      	movl	$0x94, %eax
     e90:      	movq	0x8(%rsp), %rdx
     e95:      	movl	$0x8, %esi
     e9a:      	callq	*%rax
     e9c:      	testl	%eax, %eax
     e9e:      	jns	0x311c <generic_sleepable_preload+0x311c>
     ea4:      	movl	$0xa, %r13d
     eaa:      	jmp	0x311a <generic_sleepable_preload+0x311a>
     eaf:      	movl	0x220(%rbx), %edx
     eb5:      	andl	$0xfff, %edx            # imm = 0xFFF
     ebb:      	addq	%r14, %rdx
     ebe:      	leaq	0x10(%rsp), %rdi
     ec3:      	movl	$0x8, %ecx
     ec8:      	movl	$0x71, %eax
     ecd:      	movl	$0x8, %esi
     ed2:      	callq	*%rax
     ed4:      	testl	%eax, %eax
     ed6:      	jne	0xf55 <generic_sleepable_preload+0xf55>
     ed8:      	movl	0x224(%rbx), %edx
     ede:      	andl	$0xfff, %edx            # imm = 0xFFF
     ee4:      	addq	%r14, %rdx
     ee7:      	movq	%rsp, %rdi
     eea:      	movl	$0x8, %ecx
     eef:      	movl	$0x71, %eax
     ef4:      	movl	$0x8, %esi
     ef9:      	callq	*%rax
     efb:      	testl	%eax, %eax
     efd:      	jne	0xf55 <generic_sleepable_preload+0xf55>
     eff:      	movzbl	0x22b(%rbx), %eax
     f06:      	shlxq	%rax, (%rsp), %rax
     f0c:      	movq	0x218(%rbx), %rcx
     f13:      	addq	0x10(%rsp), %rcx
     f18:      	addq	%rax, %rcx
     f1b:      	leaq	0x10(%rsp), %rdi
     f20:      	movl	$0x8, %edx
     f25:      	movl	$0x94, %eax
     f2a:      	movzbl	0x22b(%rbx), %ecx
     f31:      	shlxq	%rcx, (%rsp), %rcx
     f37:      	movq	0x218(%rbx), %rdx
     f3e:      	addq	0x10(%rsp), %rdx
     f43:      	addq	%rcx, %rdx
     f46:      	movl	$0x8, %esi
     f4b:      	callq	*%rax
     f4d:      	testl	%eax, %eax
     f4f:      	je	0xa90 <generic_sleepable_preload+0xa90>
     f55:      	movslq	%eax, %rcx
     f58:      	movq	%rcx, 0x8(%rsp)
     f5d:      	xorl	%r13d, %r13d
     f60:      	movb	$0x1, %bpl
     f63:      	cmpw	$0x0, 0xc6(%rbx)
     f6b:      	je	0x31e5 <generic_sleepable_preload+0x31e5>
     f71:      	movl	0xc0(%rbx), %eax
     f77:      	addq	%rax, %rcx
     f7a:      	movq	%rcx, 0x8(%rsp)
     f7f:      	cmpw	$0x0, 0xc4(%rbx)
     f87:      	je	0xfac <generic_sleepable_preload+0xfac>
     f89:      	leaq	0x8(%rsp), %rdi
     f8e:      	movl	$0x8, %edx
     f93:      	movl	$0x94, %eax
     f98:      	movq	0x8(%rsp), %rdx
     f9d:      	movl	$0x8, %esi
     fa2:      	callq	*%rax
     fa4:      	testl	%eax, %eax
     fa6:      	js	0x1d76 <generic_sleepable_preload+0x1d76>
     fac:      	cmpw	$0x0, 0xce(%rbx)
     fb4:      	je	0x31e5 <generic_sleepable_preload+0x31e5>
     fba:      	movl	0xc8(%rbx), %ecx
     fc0:      	addq	0x8(%rsp), %rcx
     fc5:      	movq	%rcx, 0x8(%rsp)
     fca:      	cmpw	$0x0, 0xcc(%rbx)
     fd2:      	je	0xff7 <generic_sleepable_preload+0xff7>
     fd4:      	leaq	0x8(%rsp), %rdi
     fd9:      	movl	$0x8, %edx
     fde:      	movl	$0x94, %eax
     fe3:      	movq	0x8(%rsp), %rdx
     fe8:      	movl	$0x8, %esi
     fed:      	callq	*%rax
     fef:      	testl	%eax, %eax
     ff1:      	js	0x261b <generic_sleepable_preload+0x261b>
     ff7:      	cmpw	$0x0, 0xd6(%rbx)
     fff:      	je	0x31e5 <generic_sleepable_preload+0x31e5>
    1005:      	movl	0xd0(%rbx), %ecx
    100b:      	addq	0x8(%rsp), %rcx
    1010:      	movq	%rcx, 0x8(%rsp)
    1015:      	cmpw	$0x0, 0xd4(%rbx)
    101d:      	je	0x1042 <generic_sleepable_preload+0x1042>
    101f:      	leaq	0x8(%rsp), %rdi
    1024:      	movl	$0x8, %edx
    1029:      	movl	$0x94, %eax
    102e:      	movq	0x8(%rsp), %rdx
    1033:      	movl	$0x8, %esi
    1038:      	callq	*%rax
    103a:      	testl	%eax, %eax
    103c:      	js	0x2f72 <generic_sleepable_preload+0x2f72>
    1042:      	cmpw	$0x0, 0xde(%rbx)
    104a:      	je	0x31e5 <generic_sleepable_preload+0x31e5>
    1050:      	movl	0xd8(%rbx), %ecx
    1056:      	addq	0x8(%rsp), %rcx
    105b:      	movq	%rcx, 0x8(%rsp)
    1060:      	cmpw	$0x0, 0xdc(%rbx)
    1068:      	je	0x108d <generic_sleepable_preload+0x108d>
    106a:      	leaq	0x8(%rsp), %rdi
    106f:      	movl	$0x8, %edx
    1074:      	movl	$0x94, %eax
    1079:      	movq	0x8(%rsp), %rdx
    107e:      	movl	$0x8, %esi
    1083:      	callq	*%rax
    1085:      	testl	%eax, %eax
    1087:      	js	0x2fde <generic_sleepable_preload+0x2fde>
    108d:      	cmpw	$0x0, 0xe6(%rbx)
    1095:      	je	0x31e5 <generic_sleepable_preload+0x31e5>
    109b:      	movl	0xe0(%rbx), %ecx
    10a1:      	addq	0x8(%rsp), %rcx
    10a6:      	movq	%rcx, 0x8(%rsp)
    10ab:      	cmpw	$0x0, 0xe4(%rbx)
    10b3:      	je	0x10d8 <generic_sleepable_preload+0x10d8>
    10b5:      	leaq	0x8(%rsp), %rdi
    10ba:      	movl	$0x8, %edx
    10bf:      	movl	$0x94, %eax
    10c4:      	movq	0x8(%rsp), %rdx
    10c9:      	movl	$0x8, %esi
    10ce:      	callq	*%rax
    10d0:      	testl	%eax, %eax
    10d2:      	js	0x304a <generic_sleepable_preload+0x304a>
    10d8:      	cmpw	$0x0, 0xee(%rbx)
    10e0:      	je	0x31e5 <generic_sleepable_preload+0x31e5>
    10e6:      	movl	0xe8(%rbx), %ecx
    10ec:      	addq	0x8(%rsp), %rcx
    10f1:      	movq	%rcx, 0x8(%rsp)
    10f6:      	cmpw	$0x0, 0xec(%rbx)
    10fe:      	je	0x1123 <generic_sleepable_preload+0x1123>
    1100:      	leaq	0x8(%rsp), %rdi
    1105:      	movl	$0x8, %edx
    110a:      	movl	$0x94, %eax
    110f:      	movq	0x8(%rsp), %rdx
    1114:      	movl	$0x8, %esi
    1119:      	callq	*%rax
    111b:      	testl	%eax, %eax
    111d:      	js	0x30b3 <generic_sleepable_preload+0x30b3>
    1123:      	cmpw	$0x0, 0xf6(%rbx)
    112b:      	je	0x31e5 <generic_sleepable_preload+0x31e5>
    1131:      	movl	0xf0(%rbx), %ecx
    1137:      	addq	0x8(%rsp), %rcx
    113c:      	movq	%rcx, 0x8(%rsp)
    1141:      	cmpw	$0x0, 0xf4(%rbx)
    1149:      	je	0x116e <generic_sleepable_preload+0x116e>
    114b:      	leaq	0x8(%rsp), %rdi
    1150:      	movl	$0x8, %edx
    1155:      	movl	$0x94, %eax
    115a:      	movq	0x8(%rsp), %rdx
    115f:      	movl	$0x8, %esi
    1164:      	callq	*%rax
    1166:      	testl	%eax, %eax
    1168:      	js	0x31dd <generic_sleepable_preload+0x31dd>
    116e:      	cmpw	$0x0, 0xfe(%rbx)
    1176:      	je	0x31e5 <generic_sleepable_preload+0x31e5>
    117c:      	movl	0xf8(%rbx), %ecx
    1182:      	addq	0x8(%rsp), %rcx
    1187:      	movq	%rcx, 0x8(%rsp)
    118c:      	cmpw	$0x0, 0xfc(%rbx)
    1194:      	je	0x11b9 <generic_sleepable_preload+0x11b9>
    1196:      	leaq	0x8(%rsp), %rdi
    119b:      	movl	$0x8, %edx
    11a0:      	movl	$0x94, %eax
    11a5:      	movq	0x8(%rsp), %rdx
    11aa:      	movl	$0x8, %esi
    11af:      	callq	*%rax
    11b1:      	testl	%eax, %eax
    11b3:      	js	0x38b6 <generic_sleepable_preload+0x38b6>
    11b9:      	cmpw	$0x0, 0x106(%rbx)
    11c1:      	je	0x31e5 <generic_sleepable_preload+0x31e5>
    11c7:      	movl	0x100(%rbx), %ecx
    11cd:      	addq	0x8(%rsp), %rcx
    11d2:      	movq	%rcx, 0x8(%rsp)
    11d7:      	cmpw	$0x0, 0x104(%rbx)
    11df:      	je	0x1204 <generic_sleepable_preload+0x1204>
    11e1:      	leaq	0x8(%rsp), %rdi
    11e6:      	movl	$0x8, %edx
    11eb:      	movl	$0x94, %eax
    11f0:      	movq	0x8(%rsp), %rdx
    11f5:      	movl	$0x8, %esi
    11fa:      	callq	*%rax
    11fc:      	testl	%eax, %eax
    11fe:      	js	0x3968 <generic_sleepable_preload+0x3968>
    1204:      	cmpw	$0x0, 0x10e(%rbx)
    120c:      	je	0x31e5 <generic_sleepable_preload+0x31e5>
    1212:      	movl	0x108(%rbx), %ecx
    1218:      	addq	0x8(%rsp), %rcx
    121d:      	movq	%rcx, 0x8(%rsp)
    1222:      	cmpw	$0x0, 0x10c(%rbx)
    122a:      	je	0x31e5 <generic_sleepable_preload+0x31e5>
    1230:      	leaq	0x8(%rsp), %rdi
    1235:      	movl	$0x8, %edx
    123a:      	movl	$0x94, %eax
    123f:      	movq	0x8(%rsp), %rdx
    1244:      	movl	$0x8, %esi
    1249:      	callq	*%rax
    124b:      	testl	%eax, %eax
    124d:      	jns	0x31e5 <generic_sleepable_preload+0x31e5>
    1253:      	movl	$0xa, %r13d
    1259:      	jmp	0x31e3 <generic_sleepable_preload+0x31e3>
    125e:      	movl	0x238(%rbx), %edx
    1264:      	andl	$0xfff, %edx            # imm = 0xFFF
    126a:      	addq	%r14, %rdx
    126d:      	leaq	0x10(%rsp), %rdi
    1272:      	movl	$0x8, %ecx
    1277:      	movl	$0x71, %eax
    127c:      	movl	$0x8, %esi
    1281:      	callq	*%rax
    1283:      	testl	%eax, %eax
    1285:      	jne	0x1304 <generic_sleepable_preload+0x1304>
    1287:      	movl	0x23c(%rbx), %edx
    128d:      	andl	$0xfff, %edx            # imm = 0xFFF
    1293:      	addq	%r14, %rdx
    1296:      	movq	%rsp, %rdi
    1299:      	movl	$0x8, %ecx
    129e:      	movl	$0x71, %eax
    12a3:      	movl	$0x8, %esi
    12a8:      	callq	*%rax
    12aa:      	testl	%eax, %eax
    12ac:      	jne	0x1304 <generic_sleepable_preload+0x1304>
    12ae:      	movzbl	0x243(%rbx), %eax
    12b5:      	shlxq	%rax, (%rsp), %rax
    12bb:      	movq	0x230(%rbx), %rcx
    12c2:      	addq	0x10(%rsp), %rcx
    12c7:      	addq	%rax, %rcx
    12ca:      	leaq	0x10(%rsp), %rdi
    12cf:      	movl	$0x8, %edx
    12d4:      	movl	$0x94, %eax
    12d9:      	movzbl	0x243(%rbx), %ecx
    12e0:      	shlxq	%rcx, (%rsp), %rcx
    12e6:      	movq	0x230(%rbx), %rdx
    12ed:      	addq	0x10(%rsp), %rdx
    12f2:      	addq	%rcx, %rdx
    12f5:      	movl	$0x8, %esi
    12fa:      	callq	*%rax
    12fc:      	testl	%eax, %eax
    12fe:      	je	0xac9 <generic_sleepable_preload+0xac9>
    1304:      	movslq	%eax, %rcx
    1307:      	movq	%rcx, 0x8(%rsp)
    130c:      	xorl	%r13d, %r13d
    130f:      	movb	$0x1, %bpl
    1312:      	cmpw	$0x0, 0x116(%rbx)
    131a:      	je	0x32ab <generic_sleepable_preload+0x32ab>
    1320:      	movl	0x110(%rbx), %eax
    1326:      	addq	%rax, %rcx
    1329:      	movq	%rcx, 0x8(%rsp)
    132e:      	cmpw	$0x0, 0x114(%rbx)
    1336:      	je	0x135b <generic_sleepable_preload+0x135b>
    1338:      	leaq	0x8(%rsp), %rdi
    133d:      	movl	$0x8, %edx
    1342:      	movl	$0x94, %eax
    1347:      	movq	0x8(%rsp), %rdx
    134c:      	movl	$0x8, %esi
    1351:      	callq	*%rax
    1353:      	testl	%eax, %eax
    1355:      	js	0x1d81 <generic_sleepable_preload+0x1d81>
    135b:      	cmpw	$0x0, 0x11e(%rbx)
    1363:      	je	0x32ab <generic_sleepable_preload+0x32ab>
    1369:      	movl	0x118(%rbx), %ecx
    136f:      	addq	0x8(%rsp), %rcx
    1374:      	movq	%rcx, 0x8(%rsp)
    1379:      	cmpw	$0x0, 0x11c(%rbx)
    1381:      	je	0x13a6 <generic_sleepable_preload+0x13a6>
    1383:      	leaq	0x8(%rsp), %rdi
    1388:      	movl	$0x8, %edx
    138d:      	movl	$0x94, %eax
    1392:      	movq	0x8(%rsp), %rdx
    1397:      	movl	$0x8, %esi
    139c:      	callq	*%rax
    139e:      	testl	%eax, %eax
    13a0:      	js	0x2626 <generic_sleepable_preload+0x2626>
    13a6:      	cmpw	$0x0, 0x126(%rbx)
    13ae:      	je	0x32ab <generic_sleepable_preload+0x32ab>
    13b4:      	movl	0x120(%rbx), %ecx
    13ba:      	addq	0x8(%rsp), %rcx
    13bf:      	movq	%rcx, 0x8(%rsp)
    13c4:      	cmpw	$0x0, 0x124(%rbx)
    13cc:      	je	0x13f1 <generic_sleepable_preload+0x13f1>
    13ce:      	leaq	0x8(%rsp), %rdi
    13d3:      	movl	$0x8, %edx
    13d8:      	movl	$0x94, %eax
    13dd:      	movq	0x8(%rsp), %rdx
    13e2:      	movl	$0x8, %esi
    13e7:      	callq	*%rax
    13e9:      	testl	%eax, %eax
    13eb:      	js	0x2f7d <generic_sleepable_preload+0x2f7d>
    13f1:      	cmpw	$0x0, 0x12e(%rbx)
    13f9:      	je	0x32ab <generic_sleepable_preload+0x32ab>
    13ff:      	movl	0x128(%rbx), %ecx
    1405:      	addq	0x8(%rsp), %rcx
    140a:      	movq	%rcx, 0x8(%rsp)
    140f:      	cmpw	$0x0, 0x12c(%rbx)
    1417:      	je	0x143c <generic_sleepable_preload+0x143c>
    1419:      	leaq	0x8(%rsp), %rdi
    141e:      	movl	$0x8, %edx
    1423:      	movl	$0x94, %eax
    1428:      	movq	0x8(%rsp), %rdx
    142d:      	movl	$0x8, %esi
    1432:      	callq	*%rax
    1434:      	testl	%eax, %eax
    1436:      	js	0x2fe9 <generic_sleepable_preload+0x2fe9>
    143c:      	cmpw	$0x0, 0x136(%rbx)
    1444:      	je	0x32ab <generic_sleepable_preload+0x32ab>
    144a:      	movl	0x130(%rbx), %ecx
    1450:      	addq	0x8(%rsp), %rcx
    1455:      	movq	%rcx, 0x8(%rsp)
    145a:      	cmpw	$0x0, 0x134(%rbx)
    1462:      	je	0x1487 <generic_sleepable_preload+0x1487>
    1464:      	leaq	0x8(%rsp), %rdi
    1469:      	movl	$0x8, %edx
    146e:      	movl	$0x94, %eax
    1473:      	movq	0x8(%rsp), %rdx
    1478:      	movl	$0x8, %esi
    147d:      	callq	*%rax
    147f:      	testl	%eax, %eax
    1481:      	js	0x3055 <generic_sleepable_preload+0x3055>
    1487:      	cmpw	$0x0, 0x13e(%rbx)
    148f:      	je	0x32ab <generic_sleepable_preload+0x32ab>
    1495:      	movl	0x138(%rbx), %ecx
    149b:      	addq	0x8(%rsp), %rcx
    14a0:      	movq	%rcx, 0x8(%rsp)
    14a5:      	cmpw	$0x0, 0x13c(%rbx)
    14ad:      	je	0x14d2 <generic_sleepable_preload+0x14d2>
    14af:      	leaq	0x8(%rsp), %rdi
    14b4:      	movl	$0x8, %edx
    14b9:      	movl	$0x94, %eax
    14be:      	movq	0x8(%rsp), %rdx
    14c3:      	movl	$0x8, %esi
    14c8:      	callq	*%rax
    14ca:      	testl	%eax, %eax
    14cc:      	js	0x30be <generic_sleepable_preload+0x30be>
    14d2:      	cmpw	$0x0, 0x146(%rbx)
    14da:      	je	0x32ab <generic_sleepable_preload+0x32ab>
    14e0:      	movl	0x140(%rbx), %ecx
    14e6:      	addq	0x8(%rsp), %rcx
    14eb:      	movq	%rcx, 0x8(%rsp)
    14f0:      	cmpw	$0x0, 0x144(%rbx)
    14f8:      	je	0x151d <generic_sleepable_preload+0x151d>
    14fa:      	leaq	0x8(%rsp), %rdi
    14ff:      	movl	$0x8, %edx
    1504:      	movl	$0x94, %eax
    1509:      	movq	0x8(%rsp), %rdx
    150e:      	movl	$0x8, %esi
    1513:      	callq	*%rax
    1515:      	testl	%eax, %eax
    1517:      	js	0x32a3 <generic_sleepable_preload+0x32a3>
    151d:      	cmpw	$0x0, 0x14e(%rbx)
    1525:      	je	0x32ab <generic_sleepable_preload+0x32ab>
    152b:      	movl	0x148(%rbx), %ecx
    1531:      	addq	0x8(%rsp), %rcx
    1536:      	movq	%rcx, 0x8(%rsp)
    153b:      	cmpw	$0x0, 0x14c(%rbx)
    1543:      	je	0x1568 <generic_sleepable_preload+0x1568>
    1545:      	leaq	0x8(%rsp), %rdi
    154a:      	movl	$0x8, %edx
    154f:      	movl	$0x94, %eax
    1554:      	movq	0x8(%rsp), %rdx
    1559:      	movl	$0x8, %esi
    155e:      	callq	*%rax
    1560:      	testl	%eax, %eax
    1562:      	js	0x38c3 <generic_sleepable_preload+0x38c3>
    1568:      	cmpw	$0x0, 0x156(%rbx)
    1570:      	je	0x32ab <generic_sleepable_preload+0x32ab>
    1576:      	movl	0x150(%rbx), %ecx
    157c:      	addq	0x8(%rsp), %rcx
    1581:      	movq	%rcx, 0x8(%rsp)
    1586:      	cmpw	$0x0, 0x154(%rbx)
    158e:      	je	0x15b3 <generic_sleepable_preload+0x15b3>
    1590:      	leaq	0x8(%rsp), %rdi
    1595:      	movl	$0x8, %edx
    159a:      	movl	$0x94, %eax
    159f:      	movq	0x8(%rsp), %rdx
    15a4:      	movl	$0x8, %esi
    15a9:      	callq	*%rax
    15ab:      	testl	%eax, %eax
    15ad:      	js	0x3973 <generic_sleepable_preload+0x3973>
    15b3:      	cmpw	$0x0, 0x15e(%rbx)
    15bb:      	je	0x32ab <generic_sleepable_preload+0x32ab>
    15c1:      	movl	0x158(%rbx), %ecx
    15c7:      	addq	0x8(%rsp), %rcx
    15cc:      	movq	%rcx, 0x8(%rsp)
    15d1:      	cmpw	$0x0, 0x15c(%rbx)
    15d9:      	je	0x32ab <generic_sleepable_preload+0x32ab>
    15df:      	leaq	0x8(%rsp), %rdi
    15e4:      	movl	$0x8, %edx
    15e9:      	movl	$0x94, %eax
    15ee:      	movq	0x8(%rsp), %rdx
    15f3:      	movl	$0x8, %esi
    15f8:      	callq	*%rax
    15fa:      	testl	%eax, %eax
    15fc:      	jns	0x32ab <generic_sleepable_preload+0x32ab>
    1602:      	movl	$0xa, %r13d
    1608:      	jmp	0x32a9 <generic_sleepable_preload+0x32a9>
    160d:      	movl	0x250(%rbx), %edx
    1613:      	andl	$0xfff, %edx            # imm = 0xFFF
    1619:      	addq	%r14, %rdx
    161c:      	leaq	0x10(%rsp), %rdi
    1621:      	movl	$0x8, %ecx
    1626:      	movl	$0x71, %eax
    162b:      	movl	$0x8, %esi
    1630:      	callq	*%rax
    1632:      	testl	%eax, %eax
    1634:      	jne	0x16b3 <generic_sleepable_preload+0x16b3>
    1636:      	movl	0x254(%rbx), %edx
    163c:      	andl	$0xfff, %edx            # imm = 0xFFF
    1642:      	addq	%r14, %rdx
    1645:      	movq	%rsp, %rdi
    1648:      	movl	$0x8, %ecx
    164d:      	movl	$0x71, %eax
    1652:      	movl	$0x8, %esi
    1657:      	callq	*%rax
    1659:      	testl	%eax, %eax
    165b:      	jne	0x16b3 <generic_sleepable_preload+0x16b3>
    165d:      	movzbl	0x25b(%rbx), %eax
    1664:      	shlxq	%rax, (%rsp), %rax
    166a:      	movq	0x248(%rbx), %rcx
    1671:      	addq	0x10(%rsp), %rcx
    1676:      	addq	%rax, %rcx
    1679:      	leaq	0x10(%rsp), %rdi
    167e:      	movl	$0x8, %edx
    1683:      	movl	$0x94, %eax
    1688:      	movzbl	0x25b(%rbx), %ecx
    168f:      	shlxq	%rcx, (%rsp), %rcx
    1695:      	movq	0x248(%rbx), %rdx
    169c:      	addq	0x10(%rsp), %rdx
    16a1:      	addq	%rcx, %rdx
    16a4:      	movl	$0x8, %esi
    16a9:      	callq	*%rax
    16ab:      	testl	%eax, %eax
    16ad:      	je	0xafd <generic_sleepable_preload+0xafd>
    16b3:      	movslq	%eax, %rcx
    16b6:      	movq	%rcx, 0x8(%rsp)
    16bb:      	xorl	%r13d, %r13d
    16be:      	movb	$0x1, %bpl
    16c1:      	cmpw	$0x0, 0x166(%rbx)
    16c9:      	je	0x3371 <generic_sleepable_preload+0x3371>
    16cf:      	movl	0x160(%rbx), %eax
    16d5:      	addq	%rax, %rcx
    16d8:      	movq	%rcx, 0x8(%rsp)
    16dd:      	cmpw	$0x0, 0x164(%rbx)
    16e5:      	je	0x170a <generic_sleepable_preload+0x170a>
    16e7:      	leaq	0x8(%rsp), %rdi
    16ec:      	movl	$0x8, %edx
    16f1:      	movl	$0x94, %eax
    16f6:      	movq	0x8(%rsp), %rdx
    16fb:      	movl	$0x8, %esi
    1700:      	callq	*%rax
    1702:      	testl	%eax, %eax
    1704:      	js	0x1d8c <generic_sleepable_preload+0x1d8c>
    170a:      	cmpw	$0x0, 0x16e(%rbx)
    1712:      	je	0x3371 <generic_sleepable_preload+0x3371>
    1718:      	movl	0x168(%rbx), %ecx
    171e:      	addq	0x8(%rsp), %rcx
    1723:      	movq	%rcx, 0x8(%rsp)
    1728:      	cmpw	$0x0, 0x16c(%rbx)
    1730:      	je	0x1755 <generic_sleepable_preload+0x1755>
    1732:      	leaq	0x8(%rsp), %rdi
    1737:      	movl	$0x8, %edx
    173c:      	movl	$0x94, %eax
    1741:      	movq	0x8(%rsp), %rdx
    1746:      	movl	$0x8, %esi
    174b:      	callq	*%rax
    174d:      	testl	%eax, %eax
    174f:      	js	0x2631 <generic_sleepable_preload+0x2631>
    1755:      	cmpw	$0x0, 0x176(%rbx)
    175d:      	je	0x3371 <generic_sleepable_preload+0x3371>
    1763:      	movl	0x170(%rbx), %ecx
    1769:      	addq	0x8(%rsp), %rcx
    176e:      	movq	%rcx, 0x8(%rsp)
    1773:      	cmpw	$0x0, 0x174(%rbx)
    177b:      	je	0x17a0 <generic_sleepable_preload+0x17a0>
    177d:      	leaq	0x8(%rsp), %rdi
    1782:      	movl	$0x8, %edx
    1787:      	movl	$0x94, %eax
    178c:      	movq	0x8(%rsp), %rdx
    1791:      	movl	$0x8, %esi
    1796:      	callq	*%rax
    1798:      	testl	%eax, %eax
    179a:      	js	0x2f88 <generic_sleepable_preload+0x2f88>
    17a0:      	cmpw	$0x0, 0x17e(%rbx)
    17a8:      	je	0x3371 <generic_sleepable_preload+0x3371>
    17ae:      	movl	0x178(%rbx), %ecx
    17b4:      	addq	0x8(%rsp), %rcx
    17b9:      	movq	%rcx, 0x8(%rsp)
    17be:      	cmpw	$0x0, 0x17c(%rbx)
    17c6:      	je	0x17eb <generic_sleepable_preload+0x17eb>
    17c8:      	leaq	0x8(%rsp), %rdi
    17cd:      	movl	$0x8, %edx
    17d2:      	movl	$0x94, %eax
    17d7:      	movq	0x8(%rsp), %rdx
    17dc:      	movl	$0x8, %esi
    17e1:      	callq	*%rax
    17e3:      	testl	%eax, %eax
    17e5:      	js	0x2ff4 <generic_sleepable_preload+0x2ff4>
    17eb:      	cmpw	$0x0, 0x186(%rbx)
    17f3:      	je	0x3371 <generic_sleepable_preload+0x3371>
    17f9:      	movl	0x180(%rbx), %ecx
    17ff:      	addq	0x8(%rsp), %rcx
    1804:      	movq	%rcx, 0x8(%rsp)
    1809:      	cmpw	$0x0, 0x184(%rbx)
    1811:      	je	0x1836 <generic_sleepable_preload+0x1836>
    1813:      	leaq	0x8(%rsp), %rdi
    1818:      	movl	$0x8, %edx
    181d:      	movl	$0x94, %eax
    1822:      	movq	0x8(%rsp), %rdx
    1827:      	movl	$0x8, %esi
    182c:      	callq	*%rax
    182e:      	testl	%eax, %eax
    1830:      	js	0x3060 <generic_sleepable_preload+0x3060>
    1836:      	cmpw	$0x0, 0x18e(%rbx)
    183e:      	je	0x3371 <generic_sleepable_preload+0x3371>
    1844:      	movl	0x188(%rbx), %ecx
    184a:      	addq	0x8(%rsp), %rcx
    184f:      	movq	%rcx, 0x8(%rsp)
    1854:      	cmpw	$0x0, 0x18c(%rbx)
    185c:      	je	0x1881 <generic_sleepable_preload+0x1881>
    185e:      	leaq	0x8(%rsp), %rdi
    1863:      	movl	$0x8, %edx
    1868:      	movl	$0x94, %eax
    186d:      	movq	0x8(%rsp), %rdx
    1872:      	movl	$0x8, %esi
    1877:      	callq	*%rax
    1879:      	testl	%eax, %eax
    187b:      	js	0x30c9 <generic_sleepable_preload+0x30c9>
    1881:      	cmpw	$0x0, 0x196(%rbx)
    1889:      	je	0x3371 <generic_sleepable_preload+0x3371>
    188f:      	movl	0x190(%rbx), %ecx
    1895:      	addq	0x8(%rsp), %rcx
    189a:      	movq	%rcx, 0x8(%rsp)
    189f:      	cmpw	$0x0, 0x194(%rbx)
    18a7:      	je	0x18cc <generic_sleepable_preload+0x18cc>
    18a9:      	leaq	0x8(%rsp), %rdi
    18ae:      	movl	$0x8, %edx
    18b3:      	movl	$0x94, %eax
    18b8:      	movq	0x8(%rsp), %rdx
    18bd:      	movl	$0x8, %esi
    18c2:      	callq	*%rax
    18c4:      	testl	%eax, %eax
    18c6:      	js	0x3369 <generic_sleepable_preload+0x3369>
    18cc:      	cmpw	$0x0, 0x19e(%rbx)
    18d4:      	je	0x3371 <generic_sleepable_preload+0x3371>
    18da:      	movl	0x198(%rbx), %ecx
    18e0:      	addq	0x8(%rsp), %rcx
    18e5:      	movq	%rcx, 0x8(%rsp)
    18ea:      	cmpw	$0x0, 0x19c(%rbx)
    18f2:      	je	0x1917 <generic_sleepable_preload+0x1917>
    18f4:      	leaq	0x8(%rsp), %rdi
    18f9:      	movl	$0x8, %edx
    18fe:      	movl	$0x94, %eax
    1903:      	movq	0x8(%rsp), %rdx
    1908:      	movl	$0x8, %esi
    190d:      	callq	*%rax
    190f:      	testl	%eax, %eax
    1911:      	js	0x38d0 <generic_sleepable_preload+0x38d0>
    1917:      	cmpw	$0x0, 0x1a6(%rbx)
    191f:      	je	0x3371 <generic_sleepable_preload+0x3371>
    1925:      	movl	0x1a0(%rbx), %ecx
    192b:      	addq	0x8(%rsp), %rcx
    1930:      	movq	%rcx, 0x8(%rsp)
    1935:      	cmpw	$0x0, 0x1a4(%rbx)
    193d:      	je	0x1962 <generic_sleepable_preload+0x1962>
    193f:      	leaq	0x8(%rsp), %rdi
    1944:      	movl	$0x8, %edx
    1949:      	movl	$0x94, %eax
    194e:      	movq	0x8(%rsp), %rdx
    1953:      	movl	$0x8, %esi
    1958:      	callq	*%rax
    195a:      	testl	%eax, %eax
    195c:      	js	0x397e <generic_sleepable_preload+0x397e>
    1962:      	cmpw	$0x0, 0x1ae(%rbx)
    196a:      	je	0x3371 <generic_sleepable_preload+0x3371>
    1970:      	movl	0x1a8(%rbx), %ecx
    1976:      	addq	0x8(%rsp), %rcx
    197b:      	movq	%rcx, 0x8(%rsp)
    1980:      	cmpw	$0x0, 0x1ac(%rbx)
    1988:      	je	0x3371 <generic_sleepable_preload+0x3371>
    198e:      	leaq	0x8(%rsp), %rdi
    1993:      	movl	$0x8, %edx
    1998:      	movl	$0x94, %eax
    199d:      	movq	0x8(%rsp), %rdx
    19a2:      	movl	$0x8, %esi
    19a7:      	callq	*%rax
    19a9:      	testl	%eax, %eax
    19ab:      	jns	0x3371 <generic_sleepable_preload+0x3371>
    19b1:      	movl	$0xa, %r13d
    19b7:      	jmp	0x336f <generic_sleepable_preload+0x336f>
    19bc:      	movl	0x268(%rbx), %edx
    19c2:      	andl	$0xfff, %edx            # imm = 0xFFF
    19c8:      	addq	%r14, %rdx
    19cb:      	leaq	0x10(%rsp), %rdi
    19d0:      	movl	$0x8, %ecx
    19d5:      	movl	$0x71, %eax
    19da:      	movl	$0x8, %esi
    19df:      	callq	*%rax
    19e1:      	testl	%eax, %eax
    19e3:      	jne	0x1a64 <generic_sleepable_preload+0x1a64>
    19e5:      	movl	0x26c(%rbx), %eax
    19eb:      	andl	$0xfff, %eax            # imm = 0xFFF
    19f0:      	addq	%rax, %r14
    19f3:      	movq	%rsp, %rdi
    19f6:      	movl	$0x8, %ecx
    19fb:      	movl	$0x71, %eax
    1a00:      	movl	$0x8, %esi
    1a05:      	movq	%r14, %rdx
    1a08:      	callq	*%rax
    1a0a:      	testl	%eax, %eax
    1a0c:      	jne	0x1a64 <generic_sleepable_preload+0x1a64>
    1a0e:      	movzbl	0x273(%rbx), %eax
    1a15:      	shlxq	%rax, (%rsp), %rax
    1a1b:      	movq	0x260(%rbx), %rcx
    1a22:      	addq	0x10(%rsp), %rcx
    1a27:      	addq	%rax, %rcx
    1a2a:      	leaq	0x10(%rsp), %rdi
    1a2f:      	movl	$0x8, %edx
    1a34:      	movl	$0x94, %eax
    1a39:      	movzbl	0x273(%rbx), %ecx
    1a40:      	shlxq	%rcx, (%rsp), %rcx
    1a46:      	movq	0x260(%rbx), %rdx
    1a4d:      	addq	0x10(%rsp), %rdx
    1a52:      	addq	%rcx, %rdx
    1a55:      	movl	$0x8, %esi
    1a5a:      	callq	*%rax
    1a5c:      	testl	%eax, %eax
    1a5e:      	je	0xb31 <generic_sleepable_preload+0xb31>
    1a64:      	movslq	%eax, %rcx
    1a67:      	movq	%rcx, 0x8(%rsp)
    1a6c:      	xorl	%ebp, %ebp
    1a6e:      	movb	$0x1, %r12b
    1a71:      	cmpw	$0x0, 0x1b6(%rbx)
    1a79:      	je	0x3437 <generic_sleepable_preload+0x3437>
    1a7f:      	movl	0x1b0(%rbx), %eax
    1a85:      	addq	%rax, %rcx
    1a88:      	movq	%rcx, 0x8(%rsp)
    1a8d:      	cmpw	$0x0, 0x1b4(%rbx)
    1a95:      	je	0x1aba <generic_sleepable_preload+0x1aba>
    1a97:      	leaq	0x8(%rsp), %rdi
    1a9c:      	movl	$0x8, %edx
    1aa1:      	movl	$0x94, %eax
    1aa6:      	movq	0x8(%rsp), %rdx
    1aab:      	movl	$0x8, %esi
    1ab0:      	callq	*%rax
    1ab2:      	testl	%eax, %eax
    1ab4:      	js	0x1d97 <generic_sleepable_preload+0x1d97>
    1aba:      	cmpw	$0x0, 0x1be(%rbx)
    1ac2:      	je	0x3437 <generic_sleepable_preload+0x3437>
    1ac8:      	movl	0x1b8(%rbx), %ecx
    1ace:      	addq	0x8(%rsp), %rcx
    1ad3:      	movq	%rcx, 0x8(%rsp)
    1ad8:      	cmpw	$0x0, 0x1bc(%rbx)
    1ae0:      	je	0x1b05 <generic_sleepable_preload+0x1b05>
    1ae2:      	leaq	0x8(%rsp), %rdi
    1ae7:      	movl	$0x8, %edx
    1aec:      	movl	$0x94, %eax
    1af1:      	movq	0x8(%rsp), %rdx
    1af6:      	movl	$0x8, %esi
    1afb:      	callq	*%rax
    1afd:      	testl	%eax, %eax
    1aff:      	js	0x263c <generic_sleepable_preload+0x263c>
    1b05:      	cmpw	$0x0, 0x1c6(%rbx)
    1b0d:      	je	0x3437 <generic_sleepable_preload+0x3437>
    1b13:      	movl	0x1c0(%rbx), %ecx
    1b19:      	addq	0x8(%rsp), %rcx
    1b1e:      	movq	%rcx, 0x8(%rsp)
    1b23:      	cmpw	$0x0, 0x1c4(%rbx)
    1b2b:      	je	0x1b50 <generic_sleepable_preload+0x1b50>
    1b2d:      	leaq	0x8(%rsp), %rdi
    1b32:      	movl	$0x8, %edx
    1b37:      	movl	$0x94, %eax
    1b3c:      	movq	0x8(%rsp), %rdx
    1b41:      	movl	$0x8, %esi
    1b46:      	callq	*%rax
    1b48:      	testl	%eax, %eax
    1b4a:      	js	0x2f93 <generic_sleepable_preload+0x2f93>
    1b50:      	cmpw	$0x0, 0x1ce(%rbx)
    1b58:      	je	0x3437 <generic_sleepable_preload+0x3437>
    1b5e:      	movl	0x1c8(%rbx), %ecx
    1b64:      	addq	0x8(%rsp), %rcx
    1b69:      	movq	%rcx, 0x8(%rsp)
    1b6e:      	cmpw	$0x0, 0x1cc(%rbx)
    1b76:      	je	0x1b9b <generic_sleepable_preload+0x1b9b>
    1b78:      	leaq	0x8(%rsp), %rdi
    1b7d:      	movl	$0x8, %edx
    1b82:      	movl	$0x94, %eax
    1b87:      	movq	0x8(%rsp), %rdx
    1b8c:      	movl	$0x8, %esi
    1b91:      	callq	*%rax
    1b93:      	testl	%eax, %eax
    1b95:      	js	0x2fff <generic_sleepable_preload+0x2fff>
    1b9b:      	cmpw	$0x0, 0x1d6(%rbx)
    1ba3:      	je	0x3437 <generic_sleepable_preload+0x3437>
    1ba9:      	movl	0x1d0(%rbx), %ecx
    1baf:      	addq	0x8(%rsp), %rcx
    1bb4:      	movq	%rcx, 0x8(%rsp)
    1bb9:      	cmpw	$0x0, 0x1d4(%rbx)
    1bc1:      	je	0x1be6 <generic_sleepable_preload+0x1be6>
    1bc3:      	leaq	0x8(%rsp), %rdi
    1bc8:      	movl	$0x8, %edx
    1bcd:      	movl	$0x94, %eax
    1bd2:      	movq	0x8(%rsp), %rdx
    1bd7:      	movl	$0x8, %esi
    1bdc:      	callq	*%rax
    1bde:      	testl	%eax, %eax
    1be0:      	js	0x306b <generic_sleepable_preload+0x306b>
    1be6:      	cmpw	$0x0, 0x1de(%rbx)
    1bee:      	je	0x3437 <generic_sleepable_preload+0x3437>
    1bf4:      	movl	0x1d8(%rbx), %ecx
    1bfa:      	addq	0x8(%rsp), %rcx
    1bff:      	movq	%rcx, 0x8(%rsp)
    1c04:      	cmpw	$0x0, 0x1dc(%rbx)
    1c0c:      	je	0x1c31 <generic_sleepable_preload+0x1c31>
    1c0e:      	leaq	0x8(%rsp), %rdi
    1c13:      	movl	$0x8, %edx
    1c18:      	movl	$0x94, %eax
    1c1d:      	movq	0x8(%rsp), %rdx
    1c22:      	movl	$0x8, %esi
    1c27:      	callq	*%rax
    1c29:      	testl	%eax, %eax
    1c2b:      	js	0x30d4 <generic_sleepable_preload+0x30d4>
    1c31:      	cmpw	$0x0, 0x1e6(%rbx)
    1c39:      	je	0x3437 <generic_sleepable_preload+0x3437>
    1c3f:      	movl	0x1e0(%rbx), %ecx
    1c45:      	addq	0x8(%rsp), %rcx
    1c4a:      	movq	%rcx, 0x8(%rsp)
    1c4f:      	cmpw	$0x0, 0x1e4(%rbx)
    1c57:      	je	0x1c7c <generic_sleepable_preload+0x1c7c>
    1c59:      	leaq	0x8(%rsp), %rdi
    1c5e:      	movl	$0x8, %edx
    1c63:      	movl	$0x94, %eax
    1c68:      	movq	0x8(%rsp), %rdx
    1c6d:      	movl	$0x8, %esi
    1c72:      	callq	*%rax
    1c74:      	testl	%eax, %eax
    1c76:      	js	0x342f <generic_sleepable_preload+0x342f>
    1c7c:      	cmpw	$0x0, 0x1ee(%rbx)
    1c84:      	je	0x3437 <generic_sleepable_preload+0x3437>
    1c8a:      	movl	0x1e8(%rbx), %ecx
    1c90:      	addq	0x8(%rsp), %rcx
    1c95:      	movq	%rcx, 0x8(%rsp)
    1c9a:      	cmpw	$0x0, 0x1ec(%rbx)
    1ca2:      	je	0x1cc7 <generic_sleepable_preload+0x1cc7>
    1ca4:      	leaq	0x8(%rsp), %rdi
    1ca9:      	movl	$0x8, %edx
    1cae:      	movl	$0x94, %eax
    1cb3:      	movq	0x8(%rsp), %rdx
    1cb8:      	movl	$0x8, %esi
    1cbd:      	callq	*%rax
    1cbf:      	testl	%eax, %eax
    1cc1:      	js	0x38dd <generic_sleepable_preload+0x38dd>
    1cc7:      	cmpw	$0x0, 0x1f6(%rbx)
    1ccf:      	je	0x3437 <generic_sleepable_preload+0x3437>
    1cd5:      	movl	0x1f0(%rbx), %ecx
    1cdb:      	addq	0x8(%rsp), %rcx
    1ce0:      	movq	%rcx, 0x8(%rsp)
    1ce5:      	cmpw	$0x0, 0x1f4(%rbx)
    1ced:      	je	0x1d12 <generic_sleepable_preload+0x1d12>
    1cef:      	leaq	0x8(%rsp), %rdi
    1cf4:      	movl	$0x8, %edx
    1cf9:      	movl	$0x94, %eax
    1cfe:      	movq	0x8(%rsp), %rdx
    1d03:      	movl	$0x8, %esi
    1d08:      	callq	*%rax
    1d0a:      	testl	%eax, %eax
    1d0c:      	js	0x3989 <generic_sleepable_preload+0x3989>
    1d12:      	cmpw	$0x0, 0x1fe(%rbx)
    1d1a:      	je	0x3437 <generic_sleepable_preload+0x3437>
    1d20:      	movl	0x1f8(%rbx), %ecx
    1d26:      	addq	0x8(%rsp), %rcx
    1d2b:      	movq	%rcx, 0x8(%rsp)
    1d30:      	cmpw	$0x0, 0x1fc(%rbx)
    1d38:      	je	0x3437 <generic_sleepable_preload+0x3437>
    1d3e:      	leaq	0x8(%rsp), %rdi
    1d43:      	movl	$0x8, %edx
    1d48:      	movl	$0x94, %eax
    1d4d:      	movq	0x8(%rsp), %rdx
    1d52:      	movl	$0x8, %esi
    1d57:      	callq	*%rax
    1d59:      	testl	%eax, %eax
    1d5b:      	jns	0x3437 <generic_sleepable_preload+0x3437>
    1d61:      	movl	$0xa, %ebp
    1d66:      	jmp	0x3434 <generic_sleepable_preload+0x3434>
    1d6b:      	movl	$0x1, %r13d
    1d71:      	jmp	0x311a <generic_sleepable_preload+0x311a>
    1d76:      	movl	$0x1, %r13d
    1d7c:      	jmp	0x31e3 <generic_sleepable_preload+0x31e3>
    1d81:      	movl	$0x1, %r13d
    1d87:      	jmp	0x32a9 <generic_sleepable_preload+0x32a9>
    1d8c:      	movl	$0x1, %r13d
    1d92:      	jmp	0x336f <generic_sleepable_preload+0x336f>
    1d97:      	movl	$0x1, %ebp
    1d9c:      	jmp	0x3434 <generic_sleepable_preload+0x3434>
    1da1:      	movq	0x88(%rsp), %rsi
    1da9:      	cmpl	$0xa, %edx
    1dac:      	je	0x1fb6 <generic_sleepable_preload+0x1fb6>
    1db2:      	movq	0x40(%rsp), %rsi
    1db7:      	cmpl	$0xb, %edx
    1dba:      	je	0x1fb6 <generic_sleepable_preload+0x1fb6>
    1dc0:      	jmp	0x1fc9 <generic_sleepable_preload+0x1fc9>
    1dc5:      	movq	0x88(%rsp), %rsi
    1dcd:      	cmpl	$0xa, %edx
    1dd0:      	je	0x265e <generic_sleepable_preload+0x265e>
    1dd6:      	movq	0x40(%rsp), %rsi
    1ddb:      	cmpl	$0xb, %edx
    1dde:      	je	0x265e <generic_sleepable_preload+0x265e>
    1de4:      	jmp	0x2671 <generic_sleepable_preload+0x2671>
    1de9:      	movq	0x88(%rsp), %rsi
    1df1:      	cmpl	$0xa, %edx
    1df4:      	je	0x2962 <generic_sleepable_preload+0x2962>
    1dfa:      	movq	0x40(%rsp), %rsi
    1dff:      	cmpl	$0xb, %edx
    1e02:      	je	0x2962 <generic_sleepable_preload+0x2962>
    1e08:      	jmp	0x2975 <generic_sleepable_preload+0x2975>
    1e0d:      	movq	0x88(%rsp), %rsi
    1e15:      	cmpl	$0xa, %edx
    1e18:      	je	0x2c66 <generic_sleepable_preload+0x2c66>
    1e1e:      	movq	0x40(%rsp), %rsi
    1e23:      	cmpl	$0xb, %edx
    1e26:      	je	0x2c66 <generic_sleepable_preload+0x2c66>
    1e2c:      	jmp	0x2c79 <generic_sleepable_preload+0x2c79>
    1e31:      	movq	0x88(%rsp), %r14
    1e39:      	cmpl	$0xa, %edx
    1e3c:      	je	0x231d <generic_sleepable_preload+0x231d>
    1e42:      	movq	0x40(%rsp), %r14
    1e47:      	cmpl	$0xb, %edx
    1e4a:      	je	0x231d <generic_sleepable_preload+0x231d>
    1e50:      	jmp	0x2330 <generic_sleepable_preload+0x2330>
    1e55:      	movq	0x68(%rsp), %rsi
    1e5a:      	cmpl	$0x2, %edx
    1e5d:      	je	0x1fb6 <generic_sleepable_preload+0x1fb6>
    1e63:      	movq	0x20(%rsp), %rsi
    1e68:      	cmpl	$0x3, %edx
    1e6b:      	je	0x1fb6 <generic_sleepable_preload+0x1fb6>
    1e71:      	jmp	0x1fc9 <generic_sleepable_preload+0x1fc9>
    1e76:      	movq	0x68(%rsp), %rsi
    1e7b:      	cmpl	$0x2, %edx
    1e7e:      	je	0x265e <generic_sleepable_preload+0x265e>
    1e84:      	movq	0x20(%rsp), %rsi
    1e89:      	cmpl	$0x3, %edx
    1e8c:      	je	0x265e <generic_sleepable_preload+0x265e>
    1e92:      	jmp	0x2671 <generic_sleepable_preload+0x2671>
    1e97:      	movq	0x68(%rsp), %rsi
    1e9c:      	cmpl	$0x2, %edx
    1e9f:      	je	0x2962 <generic_sleepable_preload+0x2962>
    1ea5:      	movq	0x20(%rsp), %rsi
    1eaa:      	cmpl	$0x3, %edx
    1ead:      	je	0x2962 <generic_sleepable_preload+0x2962>
    1eb3:      	jmp	0x2975 <generic_sleepable_preload+0x2975>
    1eb8:      	movq	0x68(%rsp), %rsi
    1ebd:      	cmpl	$0x2, %edx
    1ec0:      	je	0x2c66 <generic_sleepable_preload+0x2c66>
    1ec6:      	movq	0x20(%rsp), %rsi
    1ecb:      	cmpl	$0x3, %edx
    1ece:      	je	0x2c66 <generic_sleepable_preload+0x2c66>
    1ed4:      	jmp	0x2c79 <generic_sleepable_preload+0x2c79>
    1ed9:      	movq	0x68(%rsp), %r14
    1ede:      	cmpl	$0x2, %edx
    1ee1:      	je	0x231d <generic_sleepable_preload+0x231d>
    1ee7:      	movq	0x20(%rsp), %r14
    1eec:      	cmpl	$0x3, %edx
    1eef:      	je	0x231d <generic_sleepable_preload+0x231d>
    1ef5:      	jmp	0x2330 <generic_sleepable_preload+0x2330>
    1efa:      	movq	0x78(%rsp), %rsi
    1eff:      	cmpl	$0x6, %edx
    1f02:      	je	0x1fb6 <generic_sleepable_preload+0x1fb6>
    1f08:      	movq	0x30(%rsp), %rsi
    1f0d:      	cmpl	$0x7, %edx
    1f10:      	je	0x1fb6 <generic_sleepable_preload+0x1fb6>
    1f16:      	jmp	0x1fc9 <generic_sleepable_preload+0x1fc9>
    1f1b:      	movq	0x78(%rsp), %rsi
    1f20:      	cmpl	$0x6, %edx
    1f23:      	je	0x265e <generic_sleepable_preload+0x265e>
    1f29:      	movq	0x30(%rsp), %rsi
    1f2e:      	cmpl	$0x7, %edx
    1f31:      	je	0x265e <generic_sleepable_preload+0x265e>
    1f37:      	jmp	0x2671 <generic_sleepable_preload+0x2671>
    1f3c:      	movq	0x78(%rsp), %rsi
    1f41:      	cmpl	$0x6, %edx
    1f44:      	je	0x2962 <generic_sleepable_preload+0x2962>
    1f4a:      	movq	0x30(%rsp), %rsi
    1f4f:      	cmpl	$0x7, %edx
    1f52:      	je	0x2962 <generic_sleepable_preload+0x2962>
    1f58:      	jmp	0x2975 <generic_sleepable_preload+0x2975>
    1f5d:      	movq	0x78(%rsp), %rsi
    1f62:      	cmpl	$0x6, %edx
    1f65:      	je	0x2c66 <generic_sleepable_preload+0x2c66>
    1f6b:      	movq	0x30(%rsp), %rsi
    1f70:      	cmpl	$0x7, %edx
    1f73:      	je	0x2c66 <generic_sleepable_preload+0x2c66>
    1f79:      	jmp	0x2c79 <generic_sleepable_preload+0x2c79>
    1f7e:      	movq	0x78(%rsp), %r14
    1f83:      	cmpl	$0x6, %edx
    1f86:      	je	0x231d <generic_sleepable_preload+0x231d>
    1f8c:      	movq	0x30(%rsp), %r14
    1f91:      	cmpl	$0x7, %edx
    1f94:      	je	0x231d <generic_sleepable_preload+0x231d>
    1f9a:      	jmp	0x2330 <generic_sleepable_preload+0x2330>
    1f9f:      	movq	0x90(%rsp), %rsi
    1fa7:      	cmpl	$0xc, %edx
    1faa:      	je	0x1fb6 <generic_sleepable_preload+0x1fb6>
    1fac:      	movq	0x48(%rsp), %rsi
    1fb1:      	cmpl	$0xd, %edx
    1fb4:      	jne	0x1fc9 <generic_sleepable_preload+0x1fc9>
    1fb6:      	shlb	$0x3, %al
    1fb9:      	movb	$0x40, %cl
    1fbb:      	subb	%al, %cl
    1fbd:      	movl	$0x40, %eax
    1fc2:      	subl	%ecx, %eax
    1fc4:      	bzhiq	%rax, (%rsi), %rcx
    1fc9:      	movq	%rcx, (%rsp)
    1fcd:      	movl	0x4(%rbx), %r15d
    1fd1:      	xorl	%r13d, %r13d
    1fd4:      	movb	$0x1, %bpl
    1fd7:      	cmpw	$0x0, 0x76(%rbx)
    1fdc:      	je	0x34ee <generic_sleepable_preload+0x34ee>
    1fe2:      	movl	0x70(%rbx), %eax
    1fe5:      	addq	%rax, %rcx
    1fe8:      	movq	%rcx, (%rsp)
    1fec:      	cmpw	$0x0, 0x74(%rbx)
    1ff1:      	je	0x2013 <generic_sleepable_preload+0x2013>
    1ff3:      	movq	%rsp, %rdi
    1ff6:      	movl	$0x8, %edx
    1ffb:      	movl	$0x94, %eax
    2000:      	movq	(%rsp), %rdx
    2004:      	movl	$0x8, %esi
    2009:      	callq	*%rax
    200b:      	testl	%eax, %eax
    200d:      	js	0x228f <generic_sleepable_preload+0x228f>
    2013:      	cmpw	$0x0, 0x7e(%rbx)
    2018:      	je	0x34ee <generic_sleepable_preload+0x34ee>
    201e:      	movl	0x78(%rbx), %ecx
    2021:      	addq	(%rsp), %rcx
    2025:      	movq	%rcx, (%rsp)
    2029:      	cmpw	$0x0, 0x7c(%rbx)
    202e:      	je	0x2050 <generic_sleepable_preload+0x2050>
    2030:      	movq	%rsp, %rdi
    2033:      	movl	$0x8, %edx
    2038:      	movl	$0x94, %eax
    203d:      	movq	(%rsp), %rdx
    2041:      	movl	$0x8, %esi
    2046:      	callq	*%rax
    2048:      	testl	%eax, %eax
    204a:      	js	0x2646 <generic_sleepable_preload+0x2646>
    2050:      	cmpw	$0x0, 0x86(%rbx)
    2058:      	je	0x34ee <generic_sleepable_preload+0x34ee>
    205e:      	movl	0x80(%rbx), %ecx
    2064:      	addq	(%rsp), %rcx
    2068:      	movq	%rcx, (%rsp)
    206c:      	cmpw	$0x0, 0x84(%rbx)
    2074:      	je	0x2096 <generic_sleepable_preload+0x2096>
    2076:      	movq	%rsp, %rdi
    2079:      	movl	$0x8, %edx
    207e:      	movl	$0x94, %eax
    2083:      	movq	(%rsp), %rdx
    2087:      	movl	$0x8, %esi
    208c:      	callq	*%rax
    208e:      	testl	%eax, %eax
    2090:      	js	0x2f9d <generic_sleepable_preload+0x2f9d>
    2096:      	cmpw	$0x0, 0x8e(%rbx)
    209e:      	je	0x34ee <generic_sleepable_preload+0x34ee>
    20a4:      	movl	0x88(%rbx), %ecx
    20aa:      	addq	(%rsp), %rcx
    20ae:      	movq	%rcx, (%rsp)
    20b2:      	cmpw	$0x0, 0x8c(%rbx)
    20ba:      	je	0x20dc <generic_sleepable_preload+0x20dc>
    20bc:      	movq	%rsp, %rdi
    20bf:      	movl	$0x8, %edx
    20c4:      	movl	$0x94, %eax
    20c9:      	movq	(%rsp), %rdx
    20cd:      	movl	$0x8, %esi
    20d2:      	callq	*%rax
    20d4:      	testl	%eax, %eax
    20d6:      	js	0x3009 <generic_sleepable_preload+0x3009>
    20dc:      	cmpw	$0x0, 0x96(%rbx)
    20e4:      	je	0x34ee <generic_sleepable_preload+0x34ee>
    20ea:      	movl	0x90(%rbx), %ecx
    20f0:      	addq	(%rsp), %rcx
    20f4:      	movq	%rcx, (%rsp)
    20f8:      	cmpw	$0x0, 0x94(%rbx)
    2100:      	je	0x2122 <generic_sleepable_preload+0x2122>
    2102:      	movq	%rsp, %rdi
    2105:      	movl	$0x8, %edx
    210a:      	movl	$0x94, %eax
    210f:      	movq	(%rsp), %rdx
    2113:      	movl	$0x8, %esi
    2118:      	callq	*%rax
    211a:      	testl	%eax, %eax
    211c:      	js	0x3075 <generic_sleepable_preload+0x3075>
    2122:      	cmpw	$0x0, 0x9e(%rbx)
    212a:      	je	0x34ee <generic_sleepable_preload+0x34ee>
    2130:      	movl	0x98(%rbx), %ecx
    2136:      	addq	(%rsp), %rcx
    213a:      	movq	%rcx, (%rsp)
    213e:      	cmpw	$0x0, 0x9c(%rbx)
    2146:      	je	0x2168 <generic_sleepable_preload+0x2168>
    2148:      	movq	%rsp, %rdi
    214b:      	movl	$0x8, %edx
    2150:      	movl	$0x94, %eax
    2155:      	movq	(%rsp), %rdx
    2159:      	movl	$0x8, %esi
    215e:      	callq	*%rax
    2160:      	testl	%eax, %eax
    2162:      	js	0x30de <generic_sleepable_preload+0x30de>
    2168:      	cmpw	$0x0, 0xa6(%rbx)
    2170:      	je	0x34ee <generic_sleepable_preload+0x34ee>
    2176:      	movl	0xa0(%rbx), %ecx
    217c:      	addq	(%rsp), %rcx
    2180:      	movq	%rcx, (%rsp)
    2184:      	cmpw	$0x0, 0xa4(%rbx)
    218c:      	je	0x21ae <generic_sleepable_preload+0x21ae>
    218e:      	movq	%rsp, %rdi
    2191:      	movl	$0x8, %edx
    2196:      	movl	$0x94, %eax
    219b:      	movq	(%rsp), %rdx
    219f:      	movl	$0x8, %esi
    21a4:      	callq	*%rax
    21a6:      	testl	%eax, %eax
    21a8:      	js	0x34e6 <generic_sleepable_preload+0x34e6>
    21ae:      	cmpw	$0x0, 0xae(%rbx)
    21b6:      	je	0x34ee <generic_sleepable_preload+0x34ee>
    21bc:      	movl	0xa8(%rbx), %ecx
    21c2:      	addq	(%rsp), %rcx
    21c6:      	movq	%rcx, (%rsp)
    21ca:      	cmpw	$0x0, 0xac(%rbx)
    21d2:      	je	0x21f4 <generic_sleepable_preload+0x21f4>
    21d4:      	movq	%rsp, %rdi
    21d7:      	movl	$0x8, %edx
    21dc:      	movl	$0x94, %eax
    21e1:      	movq	(%rsp), %rdx
    21e5:      	movl	$0x8, %esi
    21ea:      	callq	*%rax
    21ec:      	testl	%eax, %eax
    21ee:      	js	0x38ea <generic_sleepable_preload+0x38ea>
    21f4:      	cmpw	$0x0, 0xb6(%rbx)
    21fc:      	je	0x34ee <generic_sleepable_preload+0x34ee>
    2202:      	movl	0xb0(%rbx), %ecx
    2208:      	addq	(%rsp), %rcx
    220c:      	movq	%rcx, (%rsp)
    2210:      	cmpw	$0x0, 0xb4(%rbx)
    2218:      	je	0x223a <generic_sleepable_preload+0x223a>
    221a:      	movq	%rsp, %rdi
    221d:      	movl	$0x8, %edx
    2222:      	movl	$0x94, %eax
    2227:      	movq	(%rsp), %rdx
    222b:      	movl	$0x8, %esi
    2230:      	callq	*%rax
    2232:      	testl	%eax, %eax
    2234:      	js	0x3993 <generic_sleepable_preload+0x3993>
    223a:      	cmpw	$0x0, 0xbe(%rbx)
    2242:      	je	0x34ee <generic_sleepable_preload+0x34ee>
    2248:      	movl	0xb8(%rbx), %ecx
    224e:      	addq	(%rsp), %rcx
    2252:      	movq	%rcx, (%rsp)
    2256:      	cmpw	$0x0, 0xbc(%rbx)
    225e:      	je	0x34ee <generic_sleepable_preload+0x34ee>
    2264:      	movq	%rsp, %rdi
    2267:      	movl	$0x8, %edx
    226c:      	movl	$0x94, %eax
    2271:      	movq	(%rsp), %rdx
    2275:      	movl	$0x8, %esi
    227a:      	callq	*%rax
    227c:      	testl	%eax, %eax
    227e:      	jns	0x34ee <generic_sleepable_preload+0x34ee>
    2284:      	movl	$0xa, %r13d
    228a:      	jmp	0x34ec <generic_sleepable_preload+0x34ec>
    228f:      	movl	$0x1, %r13d
    2295:      	jmp	0x34ec <generic_sleepable_preload+0x34ec>
    229a:      	movq	0x90(%rsp), %rsi
    22a2:      	cmpl	$0xc, %edx
    22a5:      	je	0x265e <generic_sleepable_preload+0x265e>
    22ab:      	movq	0x48(%rsp), %rsi
    22b0:      	cmpl	$0xd, %edx
    22b3:      	je	0x265e <generic_sleepable_preload+0x265e>
    22b9:      	jmp	0x2671 <generic_sleepable_preload+0x2671>
    22be:      	movq	0x90(%rsp), %rsi
    22c6:      	cmpl	$0xc, %edx
    22c9:      	je	0x2962 <generic_sleepable_preload+0x2962>
    22cf:      	movq	0x48(%rsp), %rsi
    22d4:      	cmpl	$0xd, %edx
    22d7:      	je	0x2962 <generic_sleepable_preload+0x2962>
    22dd:      	jmp	0x2975 <generic_sleepable_preload+0x2975>
    22e2:      	movq	0x90(%rsp), %rsi
    22ea:      	cmpl	$0xc, %edx
    22ed:      	je	0x2c66 <generic_sleepable_preload+0x2c66>
    22f3:      	movq	0x48(%rsp), %rsi
    22f8:      	cmpl	$0xd, %edx
    22fb:      	je	0x2c66 <generic_sleepable_preload+0x2c66>
    2301:      	jmp	0x2c79 <generic_sleepable_preload+0x2c79>
    2306:      	movq	0x90(%rsp), %r14
    230e:      	cmpl	$0xc, %edx
    2311:      	je	0x231d <generic_sleepable_preload+0x231d>
    2313:      	movq	0x48(%rsp), %r14
    2318:      	cmpl	$0xd, %edx
    231b:      	jne	0x2330 <generic_sleepable_preload+0x2330>
    231d:      	shlb	$0x3, %al
    2320:      	movb	$0x40, %cl
    2322:      	subb	%al, %cl
    2324:      	movl	$0x40, %eax
    2329:      	subl	%ecx, %eax
    232b:      	bzhiq	%rax, (%r14), %rcx
    2330:      	movq	%rcx, (%rsp)
    2334:      	movl	0x14(%rbx), %r14d
    2338:      	xorl	%ebp, %ebp
    233a:      	movb	$0x1, %r12b
    233d:      	cmpw	$0x0, 0x1b6(%rbx)
    2345:      	je	0x35b1 <generic_sleepable_preload+0x35b1>
    234b:      	movl	0x1b0(%rbx), %eax
    2351:      	addq	%rax, %rcx
    2354:      	movq	%rcx, (%rsp)
    2358:      	cmpw	$0x0, 0x1b4(%rbx)
    2360:      	je	0x2382 <generic_sleepable_preload+0x2382>
    2362:      	movq	%rsp, %rdi
    2365:      	movl	$0x8, %edx
    236a:      	movl	$0x94, %eax
    236f:      	movq	(%rsp), %rdx
    2373:      	movl	$0x8, %esi
    2378:      	callq	*%rax
    237a:      	testl	%eax, %eax
    237c:      	js	0x2606 <generic_sleepable_preload+0x2606>
    2382:      	cmpw	$0x0, 0x1be(%rbx)
    238a:      	je	0x35b1 <generic_sleepable_preload+0x35b1>
    2390:      	movl	0x1b8(%rbx), %ecx
    2396:      	addq	(%rsp), %rcx
    239a:      	movq	%rcx, (%rsp)
    239e:      	cmpw	$0x0, 0x1bc(%rbx)
    23a6:      	je	0x23c8 <generic_sleepable_preload+0x23c8>
    23a8:      	movq	%rsp, %rdi
    23ab:      	movl	$0x8, %edx
    23b0:      	movl	$0x94, %eax
    23b5:      	movq	(%rsp), %rdx
    23b9:      	movl	$0x8, %esi
    23be:      	callq	*%rax
    23c0:      	testl	%eax, %eax
    23c2:      	js	0x2651 <generic_sleepable_preload+0x2651>
    23c8:      	cmpw	$0x0, 0x1c6(%rbx)
    23d0:      	je	0x35b1 <generic_sleepable_preload+0x35b1>
    23d6:      	movl	0x1c0(%rbx), %ecx
    23dc:      	addq	(%rsp), %rcx
    23e0:      	movq	%rcx, (%rsp)
    23e4:      	cmpw	$0x0, 0x1c4(%rbx)
    23ec:      	je	0x240e <generic_sleepable_preload+0x240e>
    23ee:      	movq	%rsp, %rdi
    23f1:      	movl	$0x8, %edx
    23f6:      	movl	$0x94, %eax
    23fb:      	movq	(%rsp), %rdx
    23ff:      	movl	$0x8, %esi
    2404:      	callq	*%rax
    2406:      	testl	%eax, %eax
    2408:      	js	0x2fa8 <generic_sleepable_preload+0x2fa8>
    240e:      	cmpw	$0x0, 0x1ce(%rbx)
    2416:      	je	0x35b1 <generic_sleepable_preload+0x35b1>
    241c:      	movl	0x1c8(%rbx), %ecx
    2422:      	addq	(%rsp), %rcx
    2426:      	movq	%rcx, (%rsp)
    242a:      	cmpw	$0x0, 0x1cc(%rbx)
    2432:      	je	0x2454 <generic_sleepable_preload+0x2454>
    2434:      	movq	%rsp, %rdi
    2437:      	movl	$0x8, %edx
    243c:      	movl	$0x94, %eax
    2441:      	movq	(%rsp), %rdx
    2445:      	movl	$0x8, %esi
    244a:      	callq	*%rax
    244c:      	testl	%eax, %eax
    244e:      	js	0x3014 <generic_sleepable_preload+0x3014>
    2454:      	cmpw	$0x0, 0x1d6(%rbx)
    245c:      	je	0x35b1 <generic_sleepable_preload+0x35b1>
    2462:      	movl	0x1d0(%rbx), %ecx
    2468:      	addq	(%rsp), %rcx
    246c:      	movq	%rcx, (%rsp)
    2470:      	cmpw	$0x0, 0x1d4(%rbx)
    2478:      	je	0x249a <generic_sleepable_preload+0x249a>
    247a:      	movq	%rsp, %rdi
    247d:      	movl	$0x8, %edx
    2482:      	movl	$0x94, %eax
    2487:      	movq	(%rsp), %rdx
    248b:      	movl	$0x8, %esi
    2490:      	callq	*%rax
    2492:      	testl	%eax, %eax
    2494:      	js	0x3080 <generic_sleepable_preload+0x3080>
    249a:      	cmpw	$0x0, 0x1de(%rbx)
    24a2:      	je	0x35b1 <generic_sleepable_preload+0x35b1>
    24a8:      	movl	0x1d8(%rbx), %ecx
    24ae:      	addq	(%rsp), %rcx
    24b2:      	movq	%rcx, (%rsp)
    24b6:      	cmpw	$0x0, 0x1dc(%rbx)
    24be:      	je	0x24e0 <generic_sleepable_preload+0x24e0>
    24c0:      	movq	%rsp, %rdi
    24c3:      	movl	$0x8, %edx
    24c8:      	movl	$0x94, %eax
    24cd:      	movq	(%rsp), %rdx
    24d1:      	movl	$0x8, %esi
    24d6:      	callq	*%rax
    24d8:      	testl	%eax, %eax
    24da:      	js	0x30e9 <generic_sleepable_preload+0x30e9>
    24e0:      	cmpw	$0x0, 0x1e6(%rbx)
    24e8:      	je	0x35b1 <generic_sleepable_preload+0x35b1>
    24ee:      	movl	0x1e0(%rbx), %ecx
    24f4:      	addq	(%rsp), %rcx
    24f8:      	movq	%rcx, (%rsp)
    24fc:      	cmpw	$0x0, 0x1e4(%rbx)
    2504:      	je	0x2526 <generic_sleepable_preload+0x2526>
    2506:      	movq	%rsp, %rdi
    2509:      	movl	$0x8, %edx
    250e:      	movl	$0x94, %eax
    2513:      	movq	(%rsp), %rdx
    2517:      	movl	$0x8, %esi
    251c:      	callq	*%rax
    251e:      	testl	%eax, %eax
    2520:      	js	0x35a9 <generic_sleepable_preload+0x35a9>
    2526:      	cmpw	$0x0, 0x1ee(%rbx)
    252e:      	je	0x35b1 <generic_sleepable_preload+0x35b1>
    2534:      	movl	0x1e8(%rbx), %ecx
    253a:      	addq	(%rsp), %rcx
    253e:      	movq	%rcx, (%rsp)
    2542:      	cmpw	$0x0, 0x1ec(%rbx)
    254a:      	je	0x256c <generic_sleepable_preload+0x256c>
    254c:      	movq	%rsp, %rdi
    254f:      	movl	$0x8, %edx
    2554:      	movl	$0x94, %eax
    2559:      	movq	(%rsp), %rdx
    255d:      	movl	$0x8, %esi
    2562:      	callq	*%rax
    2564:      	testl	%eax, %eax
    2566:      	js	0x3901 <generic_sleepable_preload+0x3901>
    256c:      	cmpw	$0x0, 0x1f6(%rbx)
    2574:      	je	0x35b1 <generic_sleepable_preload+0x35b1>
    257a:      	movl	0x1f0(%rbx), %ecx
    2580:      	addq	(%rsp), %rcx
    2584:      	movq	%rcx, (%rsp)
    2588:      	cmpw	$0x0, 0x1f4(%rbx)
    2590:      	je	0x25b2 <generic_sleepable_preload+0x25b2>
    2592:      	movq	%rsp, %rdi
    2595:      	movl	$0x8, %edx
    259a:      	movl	$0x94, %eax
    259f:      	movq	(%rsp), %rdx
    25a3:      	movl	$0x8, %esi
    25a8:      	callq	*%rax
    25aa:      	testl	%eax, %eax
    25ac:      	js	0x399e <generic_sleepable_preload+0x399e>
    25b2:      	cmpw	$0x0, 0x1fe(%rbx)
    25ba:      	je	0x35b1 <generic_sleepable_preload+0x35b1>
    25c0:      	movl	0x1f8(%rbx), %ecx
    25c6:      	addq	(%rsp), %rcx
    25ca:      	movq	%rcx, (%rsp)
    25ce:      	cmpw	$0x0, 0x1fc(%rbx)
    25d6:      	je	0x35b1 <generic_sleepable_preload+0x35b1>
    25dc:      	movq	%rsp, %rdi
    25df:      	movl	$0x8, %edx
    25e4:      	movl	$0x94, %eax
    25e9:      	movq	(%rsp), %rdx
    25ed:      	movl	$0x8, %esi
    25f2:      	callq	*%rax
    25f4:      	testl	%eax, %eax
    25f6:      	jns	0x35b1 <generic_sleepable_preload+0x35b1>
    25fc:      	movl	$0xa, %ebp
    2601:      	jmp	0x35ae <generic_sleepable_preload+0x35ae>
    2606:      	movl	$0x1, %ebp
    260b:      	jmp	0x35ae <generic_sleepable_preload+0x35ae>
    2610:      	movl	$0x2, %r13d
    2616:      	jmp	0x311a <generic_sleepable_preload+0x311a>
    261b:      	movl	$0x2, %r13d
    2621:      	jmp	0x31e3 <generic_sleepable_preload+0x31e3>
    2626:      	movl	$0x2, %r13d
    262c:      	jmp	0x32a9 <generic_sleepable_preload+0x32a9>
    2631:      	movl	$0x2, %r13d
    2637:      	jmp	0x336f <generic_sleepable_preload+0x336f>
    263c:      	movl	$0x2, %ebp
    2641:      	jmp	0x3434 <generic_sleepable_preload+0x3434>
    2646:      	movl	$0x2, %r13d
    264c:      	jmp	0x34ec <generic_sleepable_preload+0x34ec>
    2651:      	movl	$0x2, %ebp
    2656:      	jmp	0x35ae <generic_sleepable_preload+0x35ae>
    265b:      	movq	%r14, %rsi
    265e:      	shlb	$0x3, %al
    2661:      	movb	$0x40, %cl
    2663:      	subb	%al, %cl
    2665:      	movl	$0x40, %eax
    266a:      	subl	%ecx, %eax
    266c:      	bzhiq	%rax, (%rsi), %rcx
    2671:      	movq	%rcx, (%rsp)
    2675:      	movl	0x8(%rbx), %r15d
    2679:      	xorl	%r13d, %r13d
    267c:      	movb	$0x1, %bpl
    267f:      	cmpw	$0x0, 0xc6(%rbx)
    2687:      	je	0x3668 <generic_sleepable_preload+0x3668>
    268d:      	movl	0xc0(%rbx), %eax
    2693:      	addq	%rax, %rcx
    2696:      	movq	%rcx, (%rsp)
    269a:      	cmpw	$0x0, 0xc4(%rbx)
    26a2:      	je	0x26c4 <generic_sleepable_preload+0x26c4>
    26a4:      	movq	%rsp, %rdi
    26a7:      	movl	$0x8, %edx
    26ac:      	movl	$0x94, %eax
    26b1:      	movq	(%rsp), %rdx
    26b5:      	movl	$0x8, %esi
    26ba:      	callq	*%rax
    26bc:      	testl	%eax, %eax
    26be:      	js	0x2949 <generic_sleepable_preload+0x2949>
    26c4:      	cmpw	$0x0, 0xce(%rbx)
    26cc:      	je	0x3668 <generic_sleepable_preload+0x3668>
    26d2:      	movl	0xc8(%rbx), %ecx
    26d8:      	addq	(%rsp), %rcx
    26dc:      	movq	%rcx, (%rsp)
    26e0:      	cmpw	$0x0, 0xcc(%rbx)
    26e8:      	je	0x270a <generic_sleepable_preload+0x270a>
    26ea:      	movq	%rsp, %rdi
    26ed:      	movl	$0x8, %edx
    26f2:      	movl	$0x94, %eax
    26f7:      	movq	(%rsp), %rdx
    26fb:      	movl	$0x8, %esi
    2700:      	callq	*%rax
    2702:      	testl	%eax, %eax
    2704:      	js	0x2954 <generic_sleepable_preload+0x2954>
    270a:      	cmpw	$0x0, 0xd6(%rbx)
    2712:      	je	0x3668 <generic_sleepable_preload+0x3668>
    2718:      	movl	0xd0(%rbx), %ecx
    271e:      	addq	(%rsp), %rcx
    2722:      	movq	%rcx, (%rsp)
    2726:      	cmpw	$0x0, 0xd4(%rbx)
    272e:      	je	0x2750 <generic_sleepable_preload+0x2750>
    2730:      	movq	%rsp, %rdi
    2733:      	movl	$0x8, %edx
    2738:      	movl	$0x94, %eax
    273d:      	movq	(%rsp), %rdx
    2741:      	movl	$0x8, %esi
    2746:      	callq	*%rax
    2748:      	testl	%eax, %eax
    274a:      	js	0x2fb2 <generic_sleepable_preload+0x2fb2>
    2750:      	cmpw	$0x0, 0xde(%rbx)
    2758:      	je	0x3668 <generic_sleepable_preload+0x3668>
    275e:      	movl	0xd8(%rbx), %ecx
    2764:      	addq	(%rsp), %rcx
    2768:      	movq	%rcx, (%rsp)
    276c:      	cmpw	$0x0, 0xdc(%rbx)
    2774:      	je	0x2796 <generic_sleepable_preload+0x2796>
    2776:      	movq	%rsp, %rdi
    2779:      	movl	$0x8, %edx
    277e:      	movl	$0x94, %eax
    2783:      	movq	(%rsp), %rdx
    2787:      	movl	$0x8, %esi
    278c:      	callq	*%rax
    278e:      	testl	%eax, %eax
    2790:      	js	0x301e <generic_sleepable_preload+0x301e>
    2796:      	cmpw	$0x0, 0xe6(%rbx)
    279e:      	je	0x3668 <generic_sleepable_preload+0x3668>
    27a4:      	movl	0xe0(%rbx), %ecx
    27aa:      	addq	(%rsp), %rcx
    27ae:      	movq	%rcx, (%rsp)
    27b2:      	cmpw	$0x0, 0xe4(%rbx)
    27ba:      	je	0x27dc <generic_sleepable_preload+0x27dc>
    27bc:      	movq	%rsp, %rdi
    27bf:      	movl	$0x8, %edx
    27c4:      	movl	$0x94, %eax
    27c9:      	movq	(%rsp), %rdx
    27cd:      	movl	$0x8, %esi
    27d2:      	callq	*%rax
    27d4:      	testl	%eax, %eax
    27d6:      	js	0x308a <generic_sleepable_preload+0x308a>
    27dc:      	cmpw	$0x0, 0xee(%rbx)
    27e4:      	je	0x3668 <generic_sleepable_preload+0x3668>
    27ea:      	movl	0xe8(%rbx), %ecx
    27f0:      	addq	(%rsp), %rcx
    27f4:      	movq	%rcx, (%rsp)
    27f8:      	cmpw	$0x0, 0xec(%rbx)
    2800:      	je	0x2822 <generic_sleepable_preload+0x2822>
    2802:      	movq	%rsp, %rdi
    2805:      	movl	$0x8, %edx
    280a:      	movl	$0x94, %eax
    280f:      	movq	(%rsp), %rdx
    2813:      	movl	$0x8, %esi
    2818:      	callq	*%rax
    281a:      	testl	%eax, %eax
    281c:      	js	0x30f3 <generic_sleepable_preload+0x30f3>
    2822:      	cmpw	$0x0, 0xf6(%rbx)
    282a:      	je	0x3668 <generic_sleepable_preload+0x3668>
    2830:      	movl	0xf0(%rbx), %ecx
    2836:      	addq	(%rsp), %rcx
    283a:      	movq	%rcx, (%rsp)
    283e:      	cmpw	$0x0, 0xf4(%rbx)
    2846:      	je	0x2868 <generic_sleepable_preload+0x2868>
    2848:      	movq	%rsp, %rdi
    284b:      	movl	$0x8, %edx
    2850:      	movl	$0x94, %eax
    2855:      	movq	(%rsp), %rdx
    2859:      	movl	$0x8, %esi
    285e:      	callq	*%rax
    2860:      	testl	%eax, %eax
    2862:      	js	0x3660 <generic_sleepable_preload+0x3660>
    2868:      	cmpw	$0x0, 0xfe(%rbx)
    2870:      	je	0x3668 <generic_sleepable_preload+0x3668>
    2876:      	movl	0xf8(%rbx), %ecx
    287c:      	addq	(%rsp), %rcx
    2880:      	movq	%rcx, (%rsp)
    2884:      	cmpw	$0x0, 0xfc(%rbx)
    288c:      	je	0x28ae <generic_sleepable_preload+0x28ae>
    288e:      	movq	%rsp, %rdi
    2891:      	movl	$0x8, %edx
    2896:      	movl	$0x94, %eax
    289b:      	movq	(%rsp), %rdx
    289f:      	movl	$0x8, %esi
    28a4:      	callq	*%rax
    28a6:      	testl	%eax, %eax
    28a8:      	js	0x3918 <generic_sleepable_preload+0x3918>
    28ae:      	cmpw	$0x0, 0x106(%rbx)
    28b6:      	je	0x3668 <generic_sleepable_preload+0x3668>
    28bc:      	movl	0x100(%rbx), %ecx
    28c2:      	addq	(%rsp), %rcx
    28c6:      	movq	%rcx, (%rsp)
    28ca:      	cmpw	$0x0, 0x104(%rbx)
    28d2:      	je	0x28f4 <generic_sleepable_preload+0x28f4>
    28d4:      	movq	%rsp, %rdi
    28d7:      	movl	$0x8, %edx
    28dc:      	movl	$0x94, %eax
    28e1:      	movq	(%rsp), %rdx
    28e5:      	movl	$0x8, %esi
    28ea:      	callq	*%rax
    28ec:      	testl	%eax, %eax
    28ee:      	js	0x39a8 <generic_sleepable_preload+0x39a8>
    28f4:      	cmpw	$0x0, 0x10e(%rbx)
    28fc:      	je	0x3668 <generic_sleepable_preload+0x3668>
    2902:      	movl	0x108(%rbx), %ecx
    2908:      	addq	(%rsp), %rcx
    290c:      	movq	%rcx, (%rsp)
    2910:      	cmpw	$0x0, 0x10c(%rbx)
    2918:      	je	0x3668 <generic_sleepable_preload+0x3668>
    291e:      	movq	%rsp, %rdi
    2921:      	movl	$0x8, %edx
    2926:      	movl	$0x94, %eax
    292b:      	movq	(%rsp), %rdx
    292f:      	movl	$0x8, %esi
    2934:      	callq	*%rax
    2936:      	testl	%eax, %eax
    2938:      	jns	0x3668 <generic_sleepable_preload+0x3668>
    293e:      	movl	$0xa, %r13d
    2944:      	jmp	0x3666 <generic_sleepable_preload+0x3666>
    2949:      	movl	$0x1, %r13d
    294f:      	jmp	0x3666 <generic_sleepable_preload+0x3666>
    2954:      	movl	$0x2, %r13d
    295a:      	jmp	0x3666 <generic_sleepable_preload+0x3666>
    295f:      	movq	%r14, %rsi
    2962:      	shlb	$0x3, %al
    2965:      	movb	$0x40, %cl
    2967:      	subb	%al, %cl
    2969:      	movl	$0x40, %eax
    296e:      	subl	%ecx, %eax
    2970:      	bzhiq	%rax, (%rsi), %rcx
    2975:      	movq	%rcx, (%rsp)
    2979:      	movl	0xc(%rbx), %r15d
    297d:      	xorl	%r13d, %r13d
    2980:      	movb	$0x1, %bpl
    2983:      	cmpw	$0x0, 0x116(%rbx)
    298b:      	je	0x372b <generic_sleepable_preload+0x372b>
    2991:      	movl	0x110(%rbx), %eax
    2997:      	addq	%rax, %rcx
    299a:      	movq	%rcx, (%rsp)
    299e:      	cmpw	$0x0, 0x114(%rbx)
    29a6:      	je	0x29c8 <generic_sleepable_preload+0x29c8>
    29a8:      	movq	%rsp, %rdi
    29ab:      	movl	$0x8, %edx
    29b0:      	movl	$0x94, %eax
    29b5:      	movq	(%rsp), %rdx
    29b9:      	movl	$0x8, %esi
    29be:      	callq	*%rax
    29c0:      	testl	%eax, %eax
    29c2:      	js	0x2c4d <generic_sleepable_preload+0x2c4d>
    29c8:      	cmpw	$0x0, 0x11e(%rbx)
    29d0:      	je	0x372b <generic_sleepable_preload+0x372b>
    29d6:      	movl	0x118(%rbx), %ecx
    29dc:      	addq	(%rsp), %rcx
    29e0:      	movq	%rcx, (%rsp)
    29e4:      	cmpw	$0x0, 0x11c(%rbx)
    29ec:      	je	0x2a0e <generic_sleepable_preload+0x2a0e>
    29ee:      	movq	%rsp, %rdi
    29f1:      	movl	$0x8, %edx
    29f6:      	movl	$0x94, %eax
    29fb:      	movq	(%rsp), %rdx
    29ff:      	movl	$0x8, %esi
    2a04:      	callq	*%rax
    2a06:      	testl	%eax, %eax
    2a08:      	js	0x2c58 <generic_sleepable_preload+0x2c58>
    2a0e:      	cmpw	$0x0, 0x126(%rbx)
    2a16:      	je	0x372b <generic_sleepable_preload+0x372b>
    2a1c:      	movl	0x120(%rbx), %ecx
    2a22:      	addq	(%rsp), %rcx
    2a26:      	movq	%rcx, (%rsp)
    2a2a:      	cmpw	$0x0, 0x124(%rbx)
    2a32:      	je	0x2a54 <generic_sleepable_preload+0x2a54>
    2a34:      	movq	%rsp, %rdi
    2a37:      	movl	$0x8, %edx
    2a3c:      	movl	$0x94, %eax
    2a41:      	movq	(%rsp), %rdx
    2a45:      	movl	$0x8, %esi
    2a4a:      	callq	*%rax
    2a4c:      	testl	%eax, %eax
    2a4e:      	js	0x2fbd <generic_sleepable_preload+0x2fbd>
    2a54:      	cmpw	$0x0, 0x12e(%rbx)
    2a5c:      	je	0x372b <generic_sleepable_preload+0x372b>
    2a62:      	movl	0x128(%rbx), %ecx
    2a68:      	addq	(%rsp), %rcx
    2a6c:      	movq	%rcx, (%rsp)
    2a70:      	cmpw	$0x0, 0x12c(%rbx)
    2a78:      	je	0x2a9a <generic_sleepable_preload+0x2a9a>
    2a7a:      	movq	%rsp, %rdi
    2a7d:      	movl	$0x8, %edx
    2a82:      	movl	$0x94, %eax
    2a87:      	movq	(%rsp), %rdx
    2a8b:      	movl	$0x8, %esi
    2a90:      	callq	*%rax
    2a92:      	testl	%eax, %eax
    2a94:      	js	0x3029 <generic_sleepable_preload+0x3029>
    2a9a:      	cmpw	$0x0, 0x136(%rbx)
    2aa2:      	je	0x372b <generic_sleepable_preload+0x372b>
    2aa8:      	movl	0x130(%rbx), %ecx
    2aae:      	addq	(%rsp), %rcx
    2ab2:      	movq	%rcx, (%rsp)
    2ab6:      	cmpw	$0x0, 0x134(%rbx)
    2abe:      	je	0x2ae0 <generic_sleepable_preload+0x2ae0>
    2ac0:      	movq	%rsp, %rdi
    2ac3:      	movl	$0x8, %edx
    2ac8:      	movl	$0x94, %eax
    2acd:      	movq	(%rsp), %rdx
    2ad1:      	movl	$0x8, %esi
    2ad6:      	callq	*%rax
    2ad8:      	testl	%eax, %eax
    2ada:      	js	0x3095 <generic_sleepable_preload+0x3095>
    2ae0:      	cmpw	$0x0, 0x13e(%rbx)
    2ae8:      	je	0x372b <generic_sleepable_preload+0x372b>
    2aee:      	movl	0x138(%rbx), %ecx
    2af4:      	addq	(%rsp), %rcx
    2af8:      	movq	%rcx, (%rsp)
    2afc:      	cmpw	$0x0, 0x13c(%rbx)
    2b04:      	je	0x2b26 <generic_sleepable_preload+0x2b26>
    2b06:      	movq	%rsp, %rdi
    2b09:      	movl	$0x8, %edx
    2b0e:      	movl	$0x94, %eax
    2b13:      	movq	(%rsp), %rdx
    2b17:      	movl	$0x8, %esi
    2b1c:      	callq	*%rax
    2b1e:      	testl	%eax, %eax
    2b20:      	js	0x30fe <generic_sleepable_preload+0x30fe>
    2b26:      	cmpw	$0x0, 0x146(%rbx)
    2b2e:      	je	0x372b <generic_sleepable_preload+0x372b>
    2b34:      	movl	0x140(%rbx), %ecx
    2b3a:      	addq	(%rsp), %rcx
    2b3e:      	movq	%rcx, (%rsp)
    2b42:      	cmpw	$0x0, 0x144(%rbx)
    2b4a:      	je	0x2b6c <generic_sleepable_preload+0x2b6c>
    2b4c:      	movq	%rsp, %rdi
    2b4f:      	movl	$0x8, %edx
    2b54:      	movl	$0x94, %eax
    2b59:      	movq	(%rsp), %rdx
    2b5d:      	movl	$0x8, %esi
    2b62:      	callq	*%rax
    2b64:      	testl	%eax, %eax
    2b66:      	js	0x3723 <generic_sleepable_preload+0x3723>
    2b6c:      	cmpw	$0x0, 0x14e(%rbx)
    2b74:      	je	0x372b <generic_sleepable_preload+0x372b>
    2b7a:      	movl	0x148(%rbx), %ecx
    2b80:      	addq	(%rsp), %rcx
    2b84:      	movq	%rcx, (%rsp)
    2b88:      	cmpw	$0x0, 0x14c(%rbx)
    2b90:      	je	0x2bb2 <generic_sleepable_preload+0x2bb2>
    2b92:      	movq	%rsp, %rdi
    2b95:      	movl	$0x8, %edx
    2b9a:      	movl	$0x94, %eax
    2b9f:      	movq	(%rsp), %rdx
    2ba3:      	movl	$0x8, %esi
    2ba8:      	callq	*%rax
    2baa:      	testl	%eax, %eax
    2bac:      	js	0x392f <generic_sleepable_preload+0x392f>
    2bb2:      	cmpw	$0x0, 0x156(%rbx)
    2bba:      	je	0x372b <generic_sleepable_preload+0x372b>
    2bc0:      	movl	0x150(%rbx), %ecx
    2bc6:      	addq	(%rsp), %rcx
    2bca:      	movq	%rcx, (%rsp)
    2bce:      	cmpw	$0x0, 0x154(%rbx)
    2bd6:      	je	0x2bf8 <generic_sleepable_preload+0x2bf8>
    2bd8:      	movq	%rsp, %rdi
    2bdb:      	movl	$0x8, %edx
    2be0:      	movl	$0x94, %eax
    2be5:      	movq	(%rsp), %rdx
    2be9:      	movl	$0x8, %esi
    2bee:      	callq	*%rax
    2bf0:      	testl	%eax, %eax
    2bf2:      	js	0x39b3 <generic_sleepable_preload+0x39b3>
    2bf8:      	cmpw	$0x0, 0x15e(%rbx)
    2c00:      	je	0x372b <generic_sleepable_preload+0x372b>
    2c06:      	movl	0x158(%rbx), %ecx
    2c0c:      	addq	(%rsp), %rcx
    2c10:      	movq	%rcx, (%rsp)
    2c14:      	cmpw	$0x0, 0x15c(%rbx)
    2c1c:      	je	0x372b <generic_sleepable_preload+0x372b>
    2c22:      	movq	%rsp, %rdi
    2c25:      	movl	$0x8, %edx
    2c2a:      	movl	$0x94, %eax
    2c2f:      	movq	(%rsp), %rdx
    2c33:      	movl	$0x8, %esi
    2c38:      	callq	*%rax
    2c3a:      	testl	%eax, %eax
    2c3c:      	jns	0x372b <generic_sleepable_preload+0x372b>
    2c42:      	movl	$0xa, %r13d
    2c48:      	jmp	0x3729 <generic_sleepable_preload+0x3729>
    2c4d:      	movl	$0x1, %r13d
    2c53:      	jmp	0x3729 <generic_sleepable_preload+0x3729>
    2c58:      	movl	$0x2, %r13d
    2c5e:      	jmp	0x3729 <generic_sleepable_preload+0x3729>
    2c63:      	movq	%r14, %rsi
    2c66:      	shlb	$0x3, %al
    2c69:      	movb	$0x40, %cl
    2c6b:      	subb	%al, %cl
    2c6d:      	movl	$0x40, %eax
    2c72:      	subl	%ecx, %eax
    2c74:      	bzhiq	%rax, (%rsi), %rcx
    2c79:      	movq	%rcx, (%rsp)
    2c7d:      	movl	0x10(%rbx), %r15d
    2c81:      	xorl	%r13d, %r13d
    2c84:      	movb	$0x1, %bpl
    2c87:      	cmpw	$0x0, 0x166(%rbx)
    2c8f:      	je	0x37ee <generic_sleepable_preload+0x37ee>
    2c95:      	movl	0x160(%rbx), %eax
    2c9b:      	addq	%rax, %rcx
    2c9e:      	movq	%rcx, (%rsp)
    2ca2:      	cmpw	$0x0, 0x164(%rbx)
    2caa:      	je	0x2ccc <generic_sleepable_preload+0x2ccc>
    2cac:      	movq	%rsp, %rdi
    2caf:      	movl	$0x8, %edx
    2cb4:      	movl	$0x94, %eax
    2cb9:      	movq	(%rsp), %rdx
    2cbd:      	movl	$0x8, %esi
    2cc2:      	callq	*%rax
    2cc4:      	testl	%eax, %eax
    2cc6:      	js	0x2f51 <generic_sleepable_preload+0x2f51>
    2ccc:      	cmpw	$0x0, 0x16e(%rbx)
    2cd4:      	je	0x37ee <generic_sleepable_preload+0x37ee>
    2cda:      	movl	0x168(%rbx), %ecx
    2ce0:      	addq	(%rsp), %rcx
    2ce4:      	movq	%rcx, (%rsp)
    2ce8:      	cmpw	$0x0, 0x16c(%rbx)
    2cf0:      	je	0x2d12 <generic_sleepable_preload+0x2d12>
    2cf2:      	movq	%rsp, %rdi
    2cf5:      	movl	$0x8, %edx
    2cfa:      	movl	$0x94, %eax
    2cff:      	movq	(%rsp), %rdx
    2d03:      	movl	$0x8, %esi
    2d08:      	callq	*%rax
    2d0a:      	testl	%eax, %eax
    2d0c:      	js	0x2f5c <generic_sleepable_preload+0x2f5c>
    2d12:      	cmpw	$0x0, 0x176(%rbx)
    2d1a:      	je	0x37ee <generic_sleepable_preload+0x37ee>
    2d20:      	movl	0x170(%rbx), %ecx
    2d26:      	addq	(%rsp), %rcx
    2d2a:      	movq	%rcx, (%rsp)
    2d2e:      	cmpw	$0x0, 0x174(%rbx)
    2d36:      	je	0x2d58 <generic_sleepable_preload+0x2d58>
    2d38:      	movq	%rsp, %rdi
    2d3b:      	movl	$0x8, %edx
    2d40:      	movl	$0x94, %eax
    2d45:      	movq	(%rsp), %rdx
    2d49:      	movl	$0x8, %esi
    2d4e:      	callq	*%rax
    2d50:      	testl	%eax, %eax
    2d52:      	js	0x2fc8 <generic_sleepable_preload+0x2fc8>
    2d58:      	cmpw	$0x0, 0x17e(%rbx)
    2d60:      	je	0x37ee <generic_sleepable_preload+0x37ee>
    2d66:      	movl	0x178(%rbx), %ecx
    2d6c:      	addq	(%rsp), %rcx
    2d70:      	movq	%rcx, (%rsp)
    2d74:      	cmpw	$0x0, 0x17c(%rbx)
    2d7c:      	je	0x2d9e <generic_sleepable_preload+0x2d9e>
    2d7e:      	movq	%rsp, %rdi
    2d81:      	movl	$0x8, %edx
    2d86:      	movl	$0x94, %eax
    2d8b:      	movq	(%rsp), %rdx
    2d8f:      	movl	$0x8, %esi
    2d94:      	callq	*%rax
    2d96:      	testl	%eax, %eax
    2d98:      	js	0x3034 <generic_sleepable_preload+0x3034>
    2d9e:      	cmpw	$0x0, 0x186(%rbx)
    2da6:      	je	0x37ee <generic_sleepable_preload+0x37ee>
    2dac:      	movl	0x180(%rbx), %ecx
    2db2:      	addq	(%rsp), %rcx
    2db6:      	movq	%rcx, (%rsp)
    2dba:      	cmpw	$0x0, 0x184(%rbx)
    2dc2:      	je	0x2de4 <generic_sleepable_preload+0x2de4>
    2dc4:      	movq	%rsp, %rdi
    2dc7:      	movl	$0x8, %edx
    2dcc:      	movl	$0x94, %eax
    2dd1:      	movq	(%rsp), %rdx
    2dd5:      	movl	$0x8, %esi
    2dda:      	callq	*%rax
    2ddc:      	testl	%eax, %eax
    2dde:      	js	0x30a0 <generic_sleepable_preload+0x30a0>
    2de4:      	cmpw	$0x0, 0x18e(%rbx)
    2dec:      	je	0x37ee <generic_sleepable_preload+0x37ee>
    2df2:      	movl	0x188(%rbx), %ecx
    2df8:      	addq	(%rsp), %rcx
    2dfc:      	movq	%rcx, (%rsp)
    2e00:      	cmpw	$0x0, 0x18c(%rbx)
    2e08:      	je	0x2e2a <generic_sleepable_preload+0x2e2a>
    2e0a:      	movq	%rsp, %rdi
    2e0d:      	movl	$0x8, %edx
    2e12:      	movl	$0x94, %eax
    2e17:      	movq	(%rsp), %rdx
    2e1b:      	movl	$0x8, %esi
    2e20:      	callq	*%rax
    2e22:      	testl	%eax, %eax
    2e24:      	js	0x3109 <generic_sleepable_preload+0x3109>
    2e2a:      	cmpw	$0x0, 0x196(%rbx)
    2e32:      	je	0x37ee <generic_sleepable_preload+0x37ee>
    2e38:      	movl	0x190(%rbx), %ecx
    2e3e:      	addq	(%rsp), %rcx
    2e42:      	movq	%rcx, (%rsp)
    2e46:      	cmpw	$0x0, 0x194(%rbx)
    2e4e:      	je	0x2e70 <generic_sleepable_preload+0x2e70>
    2e50:      	movq	%rsp, %rdi
    2e53:      	movl	$0x8, %edx
    2e58:      	movl	$0x94, %eax
    2e5d:      	movq	(%rsp), %rdx
    2e61:      	movl	$0x8, %esi
    2e66:      	callq	*%rax
    2e68:      	testl	%eax, %eax
    2e6a:      	js	0x37e6 <generic_sleepable_preload+0x37e6>
    2e70:      	cmpw	$0x0, 0x19e(%rbx)
    2e78:      	je	0x37ee <generic_sleepable_preload+0x37ee>
    2e7e:      	movl	0x198(%rbx), %ecx
    2e84:      	addq	(%rsp), %rcx
    2e88:      	movq	%rcx, (%rsp)
    2e8c:      	cmpw	$0x0, 0x19c(%rbx)
    2e94:      	je	0x2eb6 <generic_sleepable_preload+0x2eb6>
    2e96:      	movq	%rsp, %rdi
    2e99:      	movl	$0x8, %edx
    2e9e:      	movl	$0x94, %eax
    2ea3:      	movq	(%rsp), %rdx
    2ea7:      	movl	$0x8, %esi
    2eac:      	callq	*%rax
    2eae:      	testl	%eax, %eax
    2eb0:      	js	0x3946 <generic_sleepable_preload+0x3946>
    2eb6:      	cmpw	$0x0, 0x1a6(%rbx)
    2ebe:      	je	0x37ee <generic_sleepable_preload+0x37ee>
    2ec4:      	movl	0x1a0(%rbx), %ecx
    2eca:      	addq	(%rsp), %rcx
    2ece:      	movq	%rcx, (%rsp)
    2ed2:      	cmpw	$0x0, 0x1a4(%rbx)
    2eda:      	je	0x2efc <generic_sleepable_preload+0x2efc>
    2edc:      	movq	%rsp, %rdi
    2edf:      	movl	$0x8, %edx
    2ee4:      	movl	$0x94, %eax
    2ee9:      	movq	(%rsp), %rdx
    2eed:      	movl	$0x8, %esi
    2ef2:      	callq	*%rax
    2ef4:      	testl	%eax, %eax
    2ef6:      	js	0x39be <generic_sleepable_preload+0x39be>
    2efc:      	cmpw	$0x0, 0x1ae(%rbx)
    2f04:      	je	0x37ee <generic_sleepable_preload+0x37ee>
    2f0a:      	movl	0x1a8(%rbx), %ecx
    2f10:      	addq	(%rsp), %rcx
    2f14:      	movq	%rcx, (%rsp)
    2f18:      	cmpw	$0x0, 0x1ac(%rbx)
    2f20:      	je	0x37ee <generic_sleepable_preload+0x37ee>
    2f26:      	movq	%rsp, %rdi
    2f29:      	movl	$0x8, %edx
    2f2e:      	movl	$0x94, %eax
    2f33:      	movq	(%rsp), %rdx
    2f37:      	movl	$0x8, %esi
    2f3c:      	callq	*%rax
    2f3e:      	testl	%eax, %eax
    2f40:      	jns	0x37ee <generic_sleepable_preload+0x37ee>
    2f46:      	movl	$0xa, %r13d
    2f4c:      	jmp	0x37ec <generic_sleepable_preload+0x37ec>
    2f51:      	movl	$0x1, %r13d
    2f57:      	jmp	0x37ec <generic_sleepable_preload+0x37ec>
    2f5c:      	movl	$0x2, %r13d
    2f62:      	jmp	0x37ec <generic_sleepable_preload+0x37ec>
    2f67:      	movl	$0x3, %r13d
    2f6d:      	jmp	0x311a <generic_sleepable_preload+0x311a>
    2f72:      	movl	$0x3, %r13d
    2f78:      	jmp	0x31e3 <generic_sleepable_preload+0x31e3>
    2f7d:      	movl	$0x3, %r13d
    2f83:      	jmp	0x32a9 <generic_sleepable_preload+0x32a9>
    2f88:      	movl	$0x3, %r13d
    2f8e:      	jmp	0x336f <generic_sleepable_preload+0x336f>
    2f93:      	movl	$0x3, %ebp
    2f98:      	jmp	0x3434 <generic_sleepable_preload+0x3434>
    2f9d:      	movl	$0x3, %r13d
    2fa3:      	jmp	0x34ec <generic_sleepable_preload+0x34ec>
    2fa8:      	movl	$0x3, %ebp
    2fad:      	jmp	0x35ae <generic_sleepable_preload+0x35ae>
    2fb2:      	movl	$0x3, %r13d
    2fb8:      	jmp	0x3666 <generic_sleepable_preload+0x3666>
    2fbd:      	movl	$0x3, %r13d
    2fc3:      	jmp	0x3729 <generic_sleepable_preload+0x3729>
    2fc8:      	movl	$0x3, %r13d
    2fce:      	jmp	0x37ec <generic_sleepable_preload+0x37ec>
    2fd3:      	movl	$0x4, %r13d
    2fd9:      	jmp	0x311a <generic_sleepable_preload+0x311a>
    2fde:      	movl	$0x4, %r13d
    2fe4:      	jmp	0x31e3 <generic_sleepable_preload+0x31e3>
    2fe9:      	movl	$0x4, %r13d
    2fef:      	jmp	0x32a9 <generic_sleepable_preload+0x32a9>
    2ff4:      	movl	$0x4, %r13d
    2ffa:      	jmp	0x336f <generic_sleepable_preload+0x336f>
    2fff:      	movl	$0x4, %ebp
    3004:      	jmp	0x3434 <generic_sleepable_preload+0x3434>
    3009:      	movl	$0x4, %r13d
    300f:      	jmp	0x34ec <generic_sleepable_preload+0x34ec>
    3014:      	movl	$0x4, %ebp
    3019:      	jmp	0x35ae <generic_sleepable_preload+0x35ae>
    301e:      	movl	$0x4, %r13d
    3024:      	jmp	0x3666 <generic_sleepable_preload+0x3666>
    3029:      	movl	$0x4, %r13d
    302f:      	jmp	0x3729 <generic_sleepable_preload+0x3729>
    3034:      	movl	$0x4, %r13d
    303a:      	jmp	0x37ec <generic_sleepable_preload+0x37ec>
    303f:      	movl	$0x5, %r13d
    3045:      	jmp	0x311a <generic_sleepable_preload+0x311a>
    304a:      	movl	$0x5, %r13d
    3050:      	jmp	0x31e3 <generic_sleepable_preload+0x31e3>
    3055:      	movl	$0x5, %r13d
    305b:      	jmp	0x32a9 <generic_sleepable_preload+0x32a9>
    3060:      	movl	$0x5, %r13d
    3066:      	jmp	0x336f <generic_sleepable_preload+0x336f>
    306b:      	movl	$0x5, %ebp
    3070:      	jmp	0x3434 <generic_sleepable_preload+0x3434>
    3075:      	movl	$0x5, %r13d
    307b:      	jmp	0x34ec <generic_sleepable_preload+0x34ec>
    3080:      	movl	$0x5, %ebp
    3085:      	jmp	0x35ae <generic_sleepable_preload+0x35ae>
    308a:      	movl	$0x5, %r13d
    3090:      	jmp	0x3666 <generic_sleepable_preload+0x3666>
    3095:      	movl	$0x5, %r13d
    309b:      	jmp	0x3729 <generic_sleepable_preload+0x3729>
    30a0:      	movl	$0x5, %r13d
    30a6:      	jmp	0x37ec <generic_sleepable_preload+0x37ec>
    30ab:      	movl	$0x6, %r13d
    30b1:      	jmp	0x311a <generic_sleepable_preload+0x311a>
    30b3:      	movl	$0x6, %r13d
    30b9:      	jmp	0x31e3 <generic_sleepable_preload+0x31e3>
    30be:      	movl	$0x6, %r13d
    30c4:      	jmp	0x32a9 <generic_sleepable_preload+0x32a9>
    30c9:      	movl	$0x6, %r13d
    30cf:      	jmp	0x336f <generic_sleepable_preload+0x336f>
    30d4:      	movl	$0x6, %ebp
    30d9:      	jmp	0x3434 <generic_sleepable_preload+0x3434>
    30de:      	movl	$0x6, %r13d
    30e4:      	jmp	0x34ec <generic_sleepable_preload+0x34ec>
    30e9:      	movl	$0x6, %ebp
    30ee:      	jmp	0x35ae <generic_sleepable_preload+0x35ae>
    30f3:      	movl	$0x6, %r13d
    30f9:      	jmp	0x3666 <generic_sleepable_preload+0x3666>
    30fe:      	movl	$0x6, %r13d
    3104:      	jmp	0x3729 <generic_sleepable_preload+0x3729>
    3109:      	movl	$0x6, %r13d
    310f:      	jmp	0x37ec <generic_sleepable_preload+0x37ec>
    3114:      	movl	$0x7, %r13d
    311a:      	xorl	%ebp, %ebp
    311c:      	movl	0x4(%rbx), %r15d
    3120:      	leaq	0x8(%rsp), %rdi
    3125:      	movl	$0x8, %ecx
    312a:      	movl	$0x4, %eax
    312f:      	movl	$0x8, %esi
    3134:      	movq	%rdi, %rdx
    3137:      	callq	*%rax
    3139:      	cmpl	$0x6, %r15d
    313d:      	jne	0xed <generic_sleepable_preload+0xed>
    3143:      	movq	0x8(%rsp), %rax
    3148:      	movq	%rax, 0x18(%rsp)
    314d:      	movl	$0xe, %eax
    3152:      	callq	*%rax
    3154:      	movq	%rax, 0x10(%rsp)
    3159:      	movl	$0x0, (%rsp)
    3160:      	movq	(%rip), %rdi            # 0x3167 <generic_sleepable_preload+0x3167>
    3167:      	movq	%rsp, %rsi
    316a:      	movl	$0x1, %eax
    316f:      	callq	*%rax
    3171:      	testq	%rax, %rax
    3174:      	je	0xed <generic_sleepable_preload+0xed>
    317a:      	movq	%rax, %rdx
    317d:      	movq	(%rip), %r12            # 0x3184 <generic_sleepable_preload+0x3184>
    3184:      	xorl	%ecx, %ecx
    3186:      	movl	%ebp, %r15d
    3189:      	movl	%r13d, %ebp
    318c:      	leaq	0x10(%rsp), %r13
    3191:      	movl	$0x2, %eax
    3196:      	movq	%r12, %rdi
    3199:      	movq	%r13, %rsi
    319c:      	xorl	%ecx, %ecx
    319e:      	callq	*%rax
    31a0:      	movl	$0x1, %eax
    31a5:      	movq	%r12, %rdi
    31a8:      	movq	%r13, %rsi
    31ab:      	callq	*%rax
    31ad:      	testq	%rax, %rax
    31b0:      	je	0xed <generic_sleepable_preload+0xed>
    31b6:      	testb	%r15b, %r15b
    31b9:      	je	0x35a2 <generic_sleepable_preload+0x35a2>
    31bf:      	movq	%rax, %rdi
    31c2:      	addq	$0x4, %rdi
    31c6:      	movl	$0x1000, %ecx           # imm = 0x1000
    31cb:      	movq	%rax, %r12
    31ce:      	movl	$0x72, %eax
    31d3:      	movq	0x18(%rsp), %rdx
    31d8:      	jmp	0x358b <generic_sleepable_preload+0x358b>
    31dd:      	movl	$0x7, %r13d
    31e3:      	xorl	%ebp, %ebp
    31e5:      	movl	0x8(%rbx), %r15d
    31e9:      	leaq	0x8(%rsp), %rdi
    31ee:      	movl	$0x8, %ecx
    31f3:      	movl	$0x4, %eax
    31f8:      	movl	$0x8, %esi
    31fd:      	movq	%rdi, %rdx
    3200:      	callq	*%rax
    3202:      	cmpl	$0x6, %r15d
    3206:      	jne	0xfb <generic_sleepable_preload+0xfb>
    320c:      	movq	0x8(%rsp), %rax
    3211:      	movq	%rax, 0x18(%rsp)
    3216:      	movl	$0xe, %eax
    321b:      	callq	*%rax
    321d:      	movq	%rax, 0x10(%rsp)
    3222:      	movl	$0x0, (%rsp)
    3229:      	movq	(%rip), %rdi            # 0x3230 <generic_sleepable_preload+0x3230>
    3230:      	movq	%rsp, %rsi
    3233:      	movl	$0x1, %eax
    3238:      	callq	*%rax
    323a:      	testq	%rax, %rax
    323d:      	je	0xfb <generic_sleepable_preload+0xfb>
    3243:      	movq	%rax, %rdx
    3246:      	movq	(%rip), %r12            # 0x324d <generic_sleepable_preload+0x324d>
    324d:      	xorl	%ecx, %ecx
    324f:      	movl	%r13d, %r15d
    3252:      	leaq	0x10(%rsp), %r13
    3257:      	movl	$0x2, %eax
    325c:      	movq	%r12, %rdi
    325f:      	movq	%r13, %rsi
    3262:      	xorl	%ecx, %ecx
    3264:      	callq	*%rax
    3266:      	movl	$0x1, %eax
    326b:      	movq	%r12, %rdi
    326e:      	movq	%r13, %rsi
    3271:      	callq	*%rax
    3273:      	testq	%rax, %rax
    3276:      	je	0xfb <generic_sleepable_preload+0xfb>
    327c:      	testb	%bpl, %bpl
    327f:      	je	0x371b <generic_sleepable_preload+0x371b>
    3285:      	movq	%rax, %rdi
    3288:      	addq	$0x4, %rdi
    328c:      	movl	$0x1000, %ecx           # imm = 0x1000
    3291:      	movq	%rax, %r12
    3294:      	movl	$0x72, %eax
    3299:      	movq	0x18(%rsp), %rdx
    329e:      	jmp	0x3702 <generic_sleepable_preload+0x3702>
    32a3:      	movl	$0x7, %r13d
    32a9:      	xorl	%ebp, %ebp
    32ab:      	movl	0xc(%rbx), %r15d
    32af:      	leaq	0x8(%rsp), %rdi
    32b4:      	movl	$0x8, %ecx
    32b9:      	movl	$0x4, %eax
    32be:      	movl	$0x8, %esi
    32c3:      	movq	%rdi, %rdx
    32c6:      	callq	*%rax
    32c8:      	cmpl	$0x6, %r15d
    32cc:      	jne	0x109 <generic_sleepable_preload+0x109>
    32d2:      	movq	0x8(%rsp), %rax
    32d7:      	movq	%rax, 0x18(%rsp)
    32dc:      	movl	$0xe, %eax
    32e1:      	callq	*%rax
    32e3:      	movq	%rax, 0x10(%rsp)
    32e8:      	movl	$0x0, (%rsp)
    32ef:      	movq	(%rip), %rdi            # 0x32f6 <generic_sleepable_preload+0x32f6>
    32f6:      	movq	%rsp, %rsi
    32f9:      	movl	$0x1, %eax
    32fe:      	callq	*%rax
    3300:      	testq	%rax, %rax
    3303:      	je	0x109 <generic_sleepable_preload+0x109>
    3309:      	movq	%rax, %rdx
    330c:      	movq	(%rip), %r12            # 0x3313 <generic_sleepable_preload+0x3313>
    3313:      	xorl	%ecx, %ecx
    3315:      	movl	%r13d, %r15d
    3318:      	leaq	0x10(%rsp), %r13
    331d:      	movl	$0x2, %eax
    3322:      	movq	%r12, %rdi
    3325:      	movq	%r13, %rsi
    3328:      	xorl	%ecx, %ecx
    332a:      	callq	*%rax
    332c:      	movl	$0x1, %eax
    3331:      	movq	%r12, %rdi
    3334:      	movq	%r13, %rsi
    3337:      	callq	*%rax
    3339:      	testq	%rax, %rax
    333c:      	je	0x109 <generic_sleepable_preload+0x109>
    3342:      	testb	%bpl, %bpl
    3345:      	je	0x37de <generic_sleepable_preload+0x37de>
    334b:      	movq	%rax, %rdi
    334e:      	addq	$0x4, %rdi
    3352:      	movl	$0x1000, %ecx           # imm = 0x1000
    3357:      	movq	%rax, %r12
    335a:      	movl	$0x72, %eax
    335f:      	movq	0x18(%rsp), %rdx
    3364:      	jmp	0x37c5 <generic_sleepable_preload+0x37c5>
    3369:      	movl	$0x7, %r13d
    336f:      	xorl	%ebp, %ebp
    3371:      	movl	0x10(%rbx), %r15d
    3375:      	leaq	0x8(%rsp), %rdi
    337a:      	movl	$0x8, %ecx
    337f:      	movl	$0x4, %eax
    3384:      	movl	$0x8, %esi
    3389:      	movq	%rdi, %rdx
    338c:      	callq	*%rax
    338e:      	cmpl	$0x6, %r15d
    3392:      	jne	0x117 <generic_sleepable_preload+0x117>
    3398:      	movq	0x8(%rsp), %rax
    339d:      	movq	%rax, 0x18(%rsp)
    33a2:      	movl	$0xe, %eax
    33a7:      	callq	*%rax
    33a9:      	movq	%rax, 0x10(%rsp)
    33ae:      	movl	$0x0, (%rsp)
    33b5:      	movq	(%rip), %rdi            # 0x33bc <generic_sleepable_preload+0x33bc>
    33bc:      	movq	%rsp, %rsi
    33bf:      	movl	$0x1, %eax
    33c4:      	callq	*%rax
    33c6:      	testq	%rax, %rax
    33c9:      	je	0x117 <generic_sleepable_preload+0x117>
    33cf:      	movq	%rax, %rdx
    33d2:      	movq	(%rip), %r12            # 0x33d9 <generic_sleepable_preload+0x33d9>
    33d9:      	xorl	%ecx, %ecx
    33db:      	movl	%r13d, %r15d
    33de:      	leaq	0x10(%rsp), %r13
    33e3:      	movl	$0x2, %eax
    33e8:      	movq	%r12, %rdi
    33eb:      	movq	%r13, %rsi
    33ee:      	xorl	%ecx, %ecx
    33f0:      	callq	*%rax
    33f2:      	movl	$0x1, %eax
    33f7:      	movq	%r12, %rdi
    33fa:      	movq	%r13, %rsi
    33fd:      	callq	*%rax
    33ff:      	testq	%rax, %rax
    3402:      	je	0x117 <generic_sleepable_preload+0x117>
    3408:      	testb	%bpl, %bpl
    340b:      	je	0x38a1 <generic_sleepable_preload+0x38a1>
    3411:      	movq	%rax, %rdi
    3414:      	addq	$0x4, %rdi
    3418:      	movl	$0x1000, %ecx           # imm = 0x1000
    341d:      	movq	%rax, %r12
    3420:      	movl	$0x72, %eax
    3425:      	movq	0x18(%rsp), %rdx
    342a:      	jmp	0x3888 <generic_sleepable_preload+0x3888>
    342f:      	movl	$0x7, %ebp
    3434:      	xorl	%r12d, %r12d
    3437:      	movl	0x14(%rbx), %ebx
    343a:      	leaq	0x8(%rsp), %rdi
    343f:      	movl	$0x8, %ecx
    3444:      	movl	$0x4, %eax
    3449:      	movl	$0x8, %esi
    344e:      	movq	%rdi, %rdx
    3451:      	callq	*%rax
    3453:      	cmpl	$0x6, %ebx
    3456:      	jne	0x125 <generic_sleepable_preload+0x125>
    345c:      	movq	0x8(%rsp), %rbx
    3461:      	movl	$0xe, %eax
    3466:      	callq	*%rax
    3468:      	movq	%rax, 0x10(%rsp)
    346d:      	movl	$0x0, (%rsp)
    3474:      	movq	(%rip), %rdi            # 0x347b <generic_sleepable_preload+0x347b>
    347b:      	movq	%rsp, %rsi
    347e:      	movl	$0x1, %eax
    3483:      	callq	*%rax
    3485:      	testq	%rax, %rax
    3488:      	je	0x125 <generic_sleepable_preload+0x125>
    348e:      	movq	%rax, %rdx
    3491:      	movq	(%rip), %r14            # 0x3498 <generic_sleepable_preload+0x3498>
    3498:      	xorl	%ecx, %ecx
    349a:      	leaq	0x10(%rsp), %r15
    349f:      	movl	$0x2, %eax
    34a4:      	movq	%r14, %rdi
    34a7:      	movq	%r15, %rsi
    34aa:      	xorl	%ecx, %ecx
    34ac:      	callq	*%rax
    34ae:      	movl	$0x1, %eax
    34b3:      	movq	%r14, %rdi
    34b6:      	movq	%r15, %rsi
    34b9:      	callq	*%rax
    34bb:      	testq	%rax, %rax
    34be:      	je	0x125 <generic_sleepable_preload+0x125>
    34c4:      	testb	%r12b, %r12b
    34c7:      	je	0x3659 <generic_sleepable_preload+0x3659>
    34cd:      	movq	%rax, %rdi
    34d0:      	addq	$0x4, %rdi
    34d4:      	movl	$0x1000, %ecx           # imm = 0x1000
    34d9:      	movq	%rax, %r14
    34dc:      	movl	$0x72, %eax
    34e1:      	jmp	0x363e <generic_sleepable_preload+0x363e>
    34e6:      	movl	$0x7, %r13d
    34ec:      	xorl	%ebp, %ebp
    34ee:      	cmpl	$0x6, %r15d
    34f2:      	jne	0xed <generic_sleepable_preload+0xed>
    34f8:      	movq	(%rsp), %rax
    34fc:      	movq	%rax, 0x18(%rsp)
    3501:      	movl	$0xe, %eax
    3506:      	callq	*%rax
    3508:      	movq	%rax, 0x10(%rsp)
    350d:      	movl	$0x0, 0x8(%rsp)
    3515:      	movq	(%rip), %rdi            # 0x351c <generic_sleepable_preload+0x351c>
    351c:      	leaq	0x8(%rsp), %rsi
    3521:      	movl	$0x1, %eax
    3526:      	callq	*%rax
    3528:      	testq	%rax, %rax
    352b:      	je	0xed <generic_sleepable_preload+0xed>
    3531:      	movq	%rax, %rdx
    3534:      	movq	(%rip), %r12            # 0x353b <generic_sleepable_preload+0x353b>
    353b:      	xorl	%ecx, %ecx
    353d:      	movl	%ebp, %r15d
    3540:      	movl	%r13d, %ebp
    3543:      	leaq	0x10(%rsp), %r13
    3548:      	movl	$0x2, %eax
    354d:      	movq	%r12, %rdi
    3550:      	movq	%r13, %rsi
    3553:      	xorl	%ecx, %ecx
    3555:      	callq	*%rax
    3557:      	movl	$0x1, %eax
    355c:      	movq	%r12, %rdi
    355f:      	movq	%r13, %rsi
    3562:      	callq	*%rax
    3564:      	testq	%rax, %rax
    3567:      	je	0xed <generic_sleepable_preload+0xed>
    356d:      	testb	%r15b, %r15b
    3570:      	je	0x35a2 <generic_sleepable_preload+0x35a2>
    3572:      	movq	%rax, %rdi
    3575:      	addq	$0x4, %rdi
    3579:      	movl	$0x1000, %ecx           # imm = 0x1000
    357e:      	movq	%rax, %r12
    3581:      	movl	$0x72, %eax
    3586:      	movq	0x18(%rsp), %rdx
    358b:      	movl	$0x1000, %esi           # imm = 0x1000
    3590:      	callq	*%rax
    3592:      	movq	%rax, %rcx
    3595:      	movq	%r12, %rax
    3598:      	testq	%rcx, %rcx
    359b:      	jns	0x35a2 <generic_sleepable_preload+0x35a2>
    359d:      	movl	$0xffffffff, %ebp       # imm = 0xFFFFFFFF
    35a2:      	movl	%ebp, (%rax)
    35a4:      	jmp	0xed <generic_sleepable_preload+0xed>
    35a9:      	movl	$0x7, %ebp
    35ae:      	xorl	%r12d, %r12d
    35b1:      	cmpl	$0x6, %r14d
    35b5:      	jne	0x125 <generic_sleepable_preload+0x125>
    35bb:      	movq	(%rsp), %rbx
    35bf:      	movl	$0xe, %eax
    35c4:      	callq	*%rax
    35c6:      	movq	%rax, 0x10(%rsp)
    35cb:      	movl	$0x0, 0x8(%rsp)
    35d3:      	movq	(%rip), %rdi            # 0x35da <generic_sleepable_preload+0x35da>
    35da:      	leaq	0x8(%rsp), %rsi
    35df:      	movl	$0x1, %eax
    35e4:      	callq	*%rax
    35e6:      	testq	%rax, %rax
    35e9:      	je	0x125 <generic_sleepable_preload+0x125>
    35ef:      	movq	%rax, %rdx
    35f2:      	movq	(%rip), %r14            # 0x35f9 <generic_sleepable_preload+0x35f9>
    35f9:      	xorl	%ecx, %ecx
    35fb:      	leaq	0x10(%rsp), %r15
    3600:      	movl	$0x2, %eax
    3605:      	movq	%r14, %rdi
    3608:      	movq	%r15, %rsi
    360b:      	xorl	%ecx, %ecx
    360d:      	callq	*%rax
    360f:      	movl	$0x1, %eax
    3614:      	movq	%r14, %rdi
    3617:      	movq	%r15, %rsi
    361a:      	callq	*%rax
    361c:      	testq	%rax, %rax
    361f:      	je	0x125 <generic_sleepable_preload+0x125>
    3625:      	testb	%r12b, %r12b
    3628:      	je	0x3659 <generic_sleepable_preload+0x3659>
    362a:      	movq	%rax, %rdi
    362d:      	addq	$0x4, %rdi
    3631:      	movl	$0x1000, %ecx           # imm = 0x1000
    3636:      	movq	%rax, %r14
    3639:      	movl	$0x72, %eax
    363e:      	movl	$0x1000, %esi           # imm = 0x1000
    3643:      	movq	%rbx, %rdx
    3646:      	callq	*%rax
    3648:      	movq	%rax, %rcx
    364b:      	movq	%r14, %rax
    364e:      	testq	%rcx, %rcx
    3651:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    3656:      	cmovsl	%ecx, %ebp
    3659:      	movl	%ebp, (%rax)
    365b:      	jmp	0x125 <generic_sleepable_preload+0x125>
    3660:      	movl	$0x7, %r13d
    3666:      	xorl	%ebp, %ebp
    3668:      	cmpl	$0x6, %r15d
    366c:      	jne	0xfb <generic_sleepable_preload+0xfb>
    3672:      	movq	(%rsp), %rax
    3676:      	movq	%rax, 0x18(%rsp)
    367b:      	movl	$0xe, %eax
    3680:      	callq	*%rax
    3682:      	movq	%rax, 0x10(%rsp)
    3687:      	movl	$0x0, 0x8(%rsp)
    368f:      	movq	(%rip), %rdi            # 0x3696 <generic_sleepable_preload+0x3696>
    3696:      	leaq	0x8(%rsp), %rsi
    369b:      	movl	$0x1, %eax
    36a0:      	callq	*%rax
    36a2:      	testq	%rax, %rax
    36a5:      	je	0xfb <generic_sleepable_preload+0xfb>
    36ab:      	movq	%rax, %rdx
    36ae:      	movq	(%rip), %r12            # 0x36b5 <generic_sleepable_preload+0x36b5>
    36b5:      	xorl	%ecx, %ecx
    36b7:      	movl	%r13d, %r15d
    36ba:      	leaq	0x10(%rsp), %r13
    36bf:      	movl	$0x2, %eax
    36c4:      	movq	%r12, %rdi
    36c7:      	movq	%r13, %rsi
    36ca:      	xorl	%ecx, %ecx
    36cc:      	callq	*%rax
    36ce:      	movl	$0x1, %eax
    36d3:      	movq	%r12, %rdi
    36d6:      	movq	%r13, %rsi
    36d9:      	callq	*%rax
    36db:      	testq	%rax, %rax
    36de:      	je	0xfb <generic_sleepable_preload+0xfb>
    36e4:      	testb	%bpl, %bpl
    36e7:      	je	0x371b <generic_sleepable_preload+0x371b>
    36e9:      	movq	%rax, %rdi
    36ec:      	addq	$0x4, %rdi
    36f0:      	movl	$0x1000, %ecx           # imm = 0x1000
    36f5:      	movq	%rax, %r12
    36f8:      	movl	$0x72, %eax
    36fd:      	movq	0x18(%rsp), %rdx
    3702:      	movl	$0x1000, %esi           # imm = 0x1000
    3707:      	callq	*%rax
    3709:      	movq	%rax, %rcx
    370c:      	movq	%r12, %rax
    370f:      	testq	%rcx, %rcx
    3712:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    3717:      	cmovsl	%ecx, %r15d
    371b:      	movl	%r15d, (%rax)
    371e:      	jmp	0xfb <generic_sleepable_preload+0xfb>
    3723:      	movl	$0x7, %r13d
    3729:      	xorl	%ebp, %ebp
    372b:      	cmpl	$0x6, %r15d
    372f:      	jne	0x109 <generic_sleepable_preload+0x109>
    3735:      	movq	(%rsp), %rax
    3739:      	movq	%rax, 0x18(%rsp)
    373e:      	movl	$0xe, %eax
    3743:      	callq	*%rax
    3745:      	movq	%rax, 0x10(%rsp)
    374a:      	movl	$0x0, 0x8(%rsp)
    3752:      	movq	(%rip), %rdi            # 0x3759 <generic_sleepable_preload+0x3759>
    3759:      	leaq	0x8(%rsp), %rsi
    375e:      	movl	$0x1, %eax
    3763:      	callq	*%rax
    3765:      	testq	%rax, %rax
    3768:      	je	0x109 <generic_sleepable_preload+0x109>
    376e:      	movq	%rax, %rdx
    3771:      	movq	(%rip), %r12            # 0x3778 <generic_sleepable_preload+0x3778>
    3778:      	xorl	%ecx, %ecx
    377a:      	movl	%r13d, %r15d
    377d:      	leaq	0x10(%rsp), %r13
    3782:      	movl	$0x2, %eax
    3787:      	movq	%r12, %rdi
    378a:      	movq	%r13, %rsi
    378d:      	xorl	%ecx, %ecx
    378f:      	callq	*%rax
    3791:      	movl	$0x1, %eax
    3796:      	movq	%r12, %rdi
    3799:      	movq	%r13, %rsi
    379c:      	callq	*%rax
    379e:      	testq	%rax, %rax
    37a1:      	je	0x109 <generic_sleepable_preload+0x109>
    37a7:      	testb	%bpl, %bpl
    37aa:      	je	0x37de <generic_sleepable_preload+0x37de>
    37ac:      	movq	%rax, %rdi
    37af:      	addq	$0x4, %rdi
    37b3:      	movl	$0x1000, %ecx           # imm = 0x1000
    37b8:      	movq	%rax, %r12
    37bb:      	movl	$0x72, %eax
    37c0:      	movq	0x18(%rsp), %rdx
    37c5:      	movl	$0x1000, %esi           # imm = 0x1000
    37ca:      	callq	*%rax
    37cc:      	movq	%rax, %rcx
    37cf:      	movq	%r12, %rax
    37d2:      	testq	%rcx, %rcx
    37d5:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    37da:      	cmovsl	%ecx, %r15d
    37de:      	movl	%r15d, (%rax)
    37e1:      	jmp	0x109 <generic_sleepable_preload+0x109>
    37e6:      	movl	$0x7, %r13d
    37ec:      	xorl	%ebp, %ebp
    37ee:      	cmpl	$0x6, %r15d
    37f2:      	jne	0x117 <generic_sleepable_preload+0x117>
    37f8:      	movq	(%rsp), %rax
    37fc:      	movq	%rax, 0x18(%rsp)
    3801:      	movl	$0xe, %eax
    3806:      	callq	*%rax
    3808:      	movq	%rax, 0x10(%rsp)
    380d:      	movl	$0x0, 0x8(%rsp)
    3815:      	movq	(%rip), %rdi            # 0x381c <generic_sleepable_preload+0x381c>
    381c:      	leaq	0x8(%rsp), %rsi
    3821:      	movl	$0x1, %eax
    3826:      	callq	*%rax
    3828:      	testq	%rax, %rax
    382b:      	je	0x117 <generic_sleepable_preload+0x117>
    3831:      	movq	%rax, %rdx
    3834:      	movq	(%rip), %r12            # 0x383b <generic_sleepable_preload+0x383b>
    383b:      	xorl	%ecx, %ecx
    383d:      	movl	%r13d, %r15d
    3840:      	leaq	0x10(%rsp), %r13
    3845:      	movl	$0x2, %eax
    384a:      	movq	%r12, %rdi
    384d:      	movq	%r13, %rsi
    3850:      	xorl	%ecx, %ecx
    3852:      	callq	*%rax
    3854:      	movl	$0x1, %eax
    3859:      	movq	%r12, %rdi
    385c:      	movq	%r13, %rsi
    385f:      	callq	*%rax
    3861:      	testq	%rax, %rax
    3864:      	je	0x117 <generic_sleepable_preload+0x117>
    386a:      	testb	%bpl, %bpl
    386d:      	je	0x38a1 <generic_sleepable_preload+0x38a1>
    386f:      	movq	%rax, %rdi
    3872:      	addq	$0x4, %rdi
    3876:      	movl	$0x1000, %ecx           # imm = 0x1000
    387b:      	movq	%rax, %r12
    387e:      	movl	$0x72, %eax
    3883:      	movq	0x18(%rsp), %rdx
    3888:      	movl	$0x1000, %esi           # imm = 0x1000
    388d:      	callq	*%rax
    388f:      	movq	%rax, %rcx
    3892:      	movq	%r12, %rax
    3895:      	testq	%rcx, %rcx
    3898:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    389d:      	cmovsl	%ecx, %r15d
    38a1:      	movl	%r15d, (%rax)
    38a4:      	jmp	0x117 <generic_sleepable_preload+0x117>
    38a9:      	xorl	%ebp, %ebp
    38ab:      	movl	$0x8, %r13d
    38b1:      	jmp	0x311c <generic_sleepable_preload+0x311c>
    38b6:      	xorl	%ebp, %ebp
    38b8:      	movl	$0x8, %r13d
    38be:      	jmp	0x31e5 <generic_sleepable_preload+0x31e5>
    38c3:      	xorl	%ebp, %ebp
    38c5:      	movl	$0x8, %r13d
    38cb:      	jmp	0x32ab <generic_sleepable_preload+0x32ab>
    38d0:      	xorl	%ebp, %ebp
    38d2:      	movl	$0x8, %r13d
    38d8:      	jmp	0x3371 <generic_sleepable_preload+0x3371>
    38dd:      	xorl	%r12d, %r12d
    38e0:      	movl	$0x8, %ebp
    38e5:      	jmp	0x3437 <generic_sleepable_preload+0x3437>
    38ea:      	xorl	%ebp, %ebp
    38ec:      	movl	$0x8, %r13d
    38f2:      	cmpl	$0x6, %r15d
    38f6:      	jne	0xed <generic_sleepable_preload+0xed>
    38fc:      	jmp	0x34f8 <generic_sleepable_preload+0x34f8>
    3901:      	xorl	%r12d, %r12d
    3904:      	movl	$0x8, %ebp
    3909:      	cmpl	$0x6, %r14d
    390d:      	jne	0x125 <generic_sleepable_preload+0x125>
    3913:      	jmp	0x35bb <generic_sleepable_preload+0x35bb>
    3918:      	xorl	%ebp, %ebp
    391a:      	movl	$0x8, %r13d
    3920:      	cmpl	$0x6, %r15d
    3924:      	jne	0xfb <generic_sleepable_preload+0xfb>
    392a:      	jmp	0x3672 <generic_sleepable_preload+0x3672>
    392f:      	xorl	%ebp, %ebp
    3931:      	movl	$0x8, %r13d
    3937:      	cmpl	$0x6, %r15d
    393b:      	jne	0x109 <generic_sleepable_preload+0x109>
    3941:      	jmp	0x3735 <generic_sleepable_preload+0x3735>
    3946:      	xorl	%ebp, %ebp
    3948:      	movl	$0x8, %r13d
    394e:      	cmpl	$0x6, %r15d
    3952:      	jne	0x117 <generic_sleepable_preload+0x117>
    3958:      	jmp	0x37f8 <generic_sleepable_preload+0x37f8>
    395d:      	movl	$0x9, %r13d
    3963:      	jmp	0x311a <generic_sleepable_preload+0x311a>
    3968:      	movl	$0x9, %r13d
    396e:      	jmp	0x31e3 <generic_sleepable_preload+0x31e3>
    3973:      	movl	$0x9, %r13d
    3979:      	jmp	0x32a9 <generic_sleepable_preload+0x32a9>
    397e:      	movl	$0x9, %r13d
    3984:      	jmp	0x336f <generic_sleepable_preload+0x336f>
    3989:      	movl	$0x9, %ebp
    398e:      	jmp	0x3434 <generic_sleepable_preload+0x3434>
    3993:      	movl	$0x9, %r13d
    3999:      	jmp	0x34ec <generic_sleepable_preload+0x34ec>
    399e:      	movl	$0x9, %ebp
    39a3:      	jmp	0x35ae <generic_sleepable_preload+0x35ae>
    39a8:      	movl	$0x9, %r13d
    39ae:      	jmp	0x3666 <generic_sleepable_preload+0x3666>
    39b3:      	movl	$0x9, %r13d
    39b9:      	jmp	0x3729 <generic_sleepable_preload+0x3729>
    39be:      	movl	$0x9, %r13d
    39c4:      	jmp	0x37ec <generic_sleepable_preload+0x37ec>
    39c9:      	nopl	(%rax)

00000000000039d0 <generic_sleepable_preload_cleanup>:
    39d0:      	pushq	%rax
    39d1:      	movl	$0xe, %eax
    39d6:      	callq	*%rax
    39d8:      	movq	%rax, (%rsp)
    39dc:      	movq	(%rip), %rdi            # 0x39e3 <generic_sleepable_preload_cleanup+0x13>
    39e3:      	movq	%rsp, %rsi
    39e6:      	movl	$0x3, %eax
    39eb:      	callq	*%rax
    39ed:      	xorl	%eax, %eax
    39ef:      	popq	%rcx
    39f0:      	retq
    39f1:      	nopw	%cs:(%rax,%rax)

0000000000003a00 <generic_sleepable_offload>:
    3a00:      	pushq	%rax
    3a01:      	movl	$0xe, %eax
    3a06:      	callq	*%rax
    3a08:      	movq	%rax, (%rsp)
    3a0c:      	movq	(%rip), %rdi            # 0x3a13 <generic_sleepable_offload+0x13>
    3a13:      	movq	%rsp, %rsi
    3a16:      	movl	$0x1, %eax
    3a1b:      	callq	*%rax
    3a1d:      	testq	%rax, %rax
    3a20:      	je	0x3a54 <generic_sleepable_offload+0x54>
    3a22:      	movq	(%rax), %rcx
    3a25:      	movq	%rax, %rsi
    3a28:      	addq	$0x8, %rsi
    3a2c:      	movl	$0x4, %edx
    3a31:      	movq	%rax, %rdi
    3a34:      	movl	$0x24, %eax
    3a39:      	movq	(%rdi), %rdi
    3a3c:      	movl	$0x4, %edx
    3a41:      	callq	*%rax
    3a43:      	movq	(%rip), %rdi            # 0x3a4a <generic_sleepable_offload+0x4a>
    3a4a:      	movq	%rsp, %rsi
    3a4d:      	movl	$0x3, %eax
    3a52:      	callq	*%rax
    3a54:      	xorl	%eax, %eax
    3a56:      	popq	%rcx
    3a57:      	retq
