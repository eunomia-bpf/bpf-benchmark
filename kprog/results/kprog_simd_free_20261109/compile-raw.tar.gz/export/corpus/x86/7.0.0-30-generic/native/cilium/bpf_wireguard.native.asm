
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/cilium/bpf_wireguard.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <__check_cluster_id_bits>:
       0:      	movq	(%rip), %rax            # 0x7 <__check_cluster_id_bits+0x7>
       7:      	movl	(%rax), %eax
       9:      	retq
       a:      	nopw	(%rax,%rax)

0000000000000010 <__check_device_mtu>:
      10:      	movq	(%rip), %rax            # 0x17 <__check_device_mtu+0x7>
      17:      	movzwl	(%rax), %eax
      1a:      	retq

Disassembly of section tc/tail:

0000000000000000 <tail_drop_notify>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0x58, %rsp
       e:      	movq	%rdi, %rbx
      11:      	movl	0x38(%rdi), %r15d
      15:      	movq	(%rip), %rax            # 0x1c <tail_drop_notify+0x1c>
      1c:      	cmpb	$0x0, (%rax)
      1f:      	je	0x46 <tail_drop_notify+0x46>
      21:      	movl	$0x0, 0x10(%rsp)
      29:      	movl	$0x1, %eax
      2e:      	movq	(%rip), %rdi            # 0x35 <tail_drop_notify+0x35>
      35:      	leaq	0x10(%rsp), %rsi
      3a:      	callq	*%rax
      3c:      	testq	%rax, %rax
      3f:      	je	0x46 <tail_drop_notify+0x46>
      41:      	movq	(%rax), %r12
      44:      	jmp	0x49 <tail_drop_notify+0x49>
      46:      	xorl	%r12d, %r12d
      49:      	movl	0x40(%rbx), %ebp
      4c:      	movl	0x70(%rbx), %r13d
      50:      	movq	$0x2, 0x40(%rsp)
      59:      	movq	(%rip), %rax            # 0x60 <tail_drop_notify+0x60>
      60:      	cmpl	$0x0, (%rax)
      63:      	movl	%r13d, %edi
      66:      	je	0x1c4 <tail_drop_notify+0x1c4>
      6c:      	movq	%r12, 0x8(%rsp)
      71:      	movl	%r15d, (%rsp)
      75:      	movq	(%rip), %rcx            # 0x7c <tail_drop_notify+0x7c>
      7c:      	movl	(%rcx), %ecx
      7e:      	movq	%rcx, 0x48(%rsp)
      83:      	movl	(%rax), %r12d
      86:      	movl	$0x5, %ecx
      8b:      	xorl	%eax, %eax
      8d:      	callq	*%rcx
      8f:      	movq	%rax, %r15
      92:      	movl	$0x2, 0x4(%rsp)
      9a:      	movl	$0x1, %eax
      9f:      	movq	(%rip), %rdi            # 0xa6 <tail_drop_notify+0xa6>
      a6:      	leaq	0x4(%rsp), %rsi
      ab:      	callq	*%rax
      ad:      	movq	%rax, %r14
      b0:      	testq	%rax, %rax
      b3:      	jne	0xe3 <tail_drop_notify+0xe3>
      b5:      	movq	$0x0, 0x50(%rsp)
      be:      	movl	$0x2, %eax
      c3:      	movq	(%rip), %rdi            # 0xca <tail_drop_notify+0xca>
      ca:      	leaq	0x4(%rsp), %rsi
      cf:      	leaq	0x50(%rsp), %r14
      d4:      	movq	%r14, %rdx
      d7:      	xorl	%ecx, %ecx
      d9:      	callq	*%rax
      db:      	testl	%eax, %eax
      dd:      	js	0x2a7 <tail_drop_notify+0x2a7>
      e3:      	movl	$0x1, %eax
      e8:      	movq	(%rip), %rdi            # 0xef <tail_drop_notify+0xef>
      ef:      	leaq	0x40(%rsp), %rsi
      f4:      	callq	*%rax
      f6:      	testq	%rax, %rax
      f9:      	je	0x16b <tail_drop_notify+0x16b>
      fb:      	movq	(%rax), %rcx
      fe:      	movq	%r15, %rsi
     101:      	subq	%rcx, %rsi
     104:      	cmpq	$0x3b9aca00, %rsi       # imm = 0x3B9ACA00
     10b:      	jbe	0x1a4 <tail_drop_notify+0x1a4>
     111:      	movl	$0x3b9aca00, %ecx       # imm = 0x3B9ACA00
     116:      	movq	%rax, %rdi
     119:      	movq	%rsi, %rax
     11c:      	xorl	%edx, %edx
     11e:      	divq	%rcx
     121:      	movq	%rax, %rcx
     124:      	movl	$0x3b9aca00, %r8d       # imm = 0x3B9ACA00
     12a:      	movq	%rsi, %rax
     12d:      	xorl	%edx, %edx
     12f:      	divq	%r8
     132:      	movq	%rdi, %rax
     135:      	imulq	%r12, %rcx
     139:      	addq	0x8(%rdi), %rcx
     13d:      	movq	%rcx, 0x8(%rdi)
     141:      	subq	%rdx, %r15
     144:      	movq	%r15, (%rdi)
     147:      	movq	0x48(%rsp), %rdx
     14c:      	cmpq	%rdx, %rcx
     14f:      	movl	(%rsp), %r15d
     153:      	movq	0x8(%rsp), %r12
     158:      	jbe	0x161 <tail_drop_notify+0x161>
     15a:      	movq	%rdx, 0x8(%rax)
     15e:      	movq	%rdx, %rcx
     161:      	testq	%rcx, %rcx
     164:      	jne	0x1ba <tail_drop_notify+0x1ba>
     166:      	jmp	0x2ba <tail_drop_notify+0x2ba>
     16b:      	movq	%r15, 0x10(%rsp)
     170:      	decq	%r12
     173:      	movq	%r12, 0x18(%rsp)
     178:      	movl	$0x2, %eax
     17d:      	movq	(%rip), %rdi            # 0x184 <tail_drop_notify+0x184>
     184:      	leaq	0x40(%rsp), %rsi
     189:      	leaq	0x10(%rsp), %rdx
     18e:      	xorl	%ecx, %ecx
     190:      	callq	*%rax
     192:      	testl	%eax, %eax
     194:      	movl	(%rsp), %r15d
     198:      	movq	0x8(%rsp), %r12
     19d:      	jns	0x1c1 <tail_drop_notify+0x1c1>
     19f:      	jmp	0x2ba <tail_drop_notify+0x2ba>
     1a4:      	movq	0x8(%rax), %rcx
     1a8:      	movl	(%rsp), %r15d
     1ac:      	movq	0x8(%rsp), %r12
     1b1:      	testq	%rcx, %rcx
     1b4:      	je	0x2ba <tail_drop_notify+0x2ba>
     1ba:      	decq	%rcx
     1bd:      	movq	%rcx, 0x8(%rax)
     1c1:      	movl	0x70(%rbx), %edi
     1c4:      	movl	%ebp, %ecx
     1c6:      	shrl	$0x10, %ecx
     1c9:      	movl	%ebp, %edx
     1cb:      	shrl	$0x8, %edx
     1ce:      	movzwl	0xb4(%rbx), %eax
     1d5:      	cmpl	$0xdd86, %eax           # imm = 0xDD86
     1da:      	sete	%sil
     1de:      	orb	$0x2, %sil
     1e2:      	movq	(%rip), %rax            # 0x1e9 <tail_drop_notify+0x1e9>
     1e9:      	movl	(%rax), %eax
     1eb:      	cmpl	%eax, %edi
     1ed:      	cmovbl	%edi, %eax
     1f0:      	movl	0x98(%rbx), %r11d
     1f7:      	movl	0x30(%rbx), %r8d
     1fb:      	movl	0x34(%rbx), %r9d
     1ff:      	movl	0x3c(%rbx), %r10d
     203:      	movl	%r15d, %edi
     206:      	shrl	$0x8, %edi
     209:      	movq	0x10(%rbx), %r14
     20d:      	testq	%r14, %r14
     210:      	je	0x21b <tail_drop_notify+0x21b>
     212:      	movl	0xe0(%r14), %r14d
     219:      	jmp	0x21e <tail_drop_notify+0x21e>
     21b:      	xorl	%r14d, %r14d
     21e:      	movb	$0x0, 0x37(%rsp)
     223:      	movw	$0x0, 0x35(%rsp)
     22a:      	movb	$0x1, 0x10(%rsp)
     22f:      	movb	%r15b, 0x11(%rsp)
     234:      	movw	$0x0, 0x12(%rsp)
     23b:      	movl	%r11d, 0x14(%rsp)
     240:      	movl	%r13d, 0x18(%rsp)
     245:      	movw	%ax, 0x1c(%rsp)
     24a:      	movw	$0x3, 0x1e(%rsp)
     251:      	movl	%r8d, 0x20(%rsp)
     256:      	movl	%r9d, 0x24(%rsp)
     25b:      	movl	%r10d, 0x28(%rsp)
     260:      	movw	%cx, 0x2c(%rsp)
     265:      	movb	%dl, 0x2e(%rsp)
     269:      	movb	%dil, 0x2f(%rsp)
     26e:      	movl	%r14d, 0x30(%rsp)
     273:      	movb	%sil, 0x34(%rsp)
     278:      	movq	%r12, 0x38(%rsp)
     27d:      	movl	$0x19, %r9d
     283:      	shlq	$0x20, %rax
     287:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     28c:      	orq	%rax, %rdx
     28f:      	movq	(%rip), %rsi            # 0x296 <tail_drop_notify+0x296>
     296:      	leaq	0x10(%rsp), %rcx
     29b:      	movq	%rbx, %rdi
     29e:      	movl	$0x30, %r8d
     2a4:      	callq	*%r9
     2a7:      	movzbl	%bpl, %eax
     2ab:      	addq	$0x58, %rsp
     2af:      	popq	%rbx
     2b0:      	popq	%r12
     2b2:      	popq	%r13
     2b4:      	popq	%r14
     2b6:      	popq	%r15
     2b8:      	popq	%rbp
     2b9:      	retq
     2ba:      	incq	(%r14)
     2bd:      	jmp	0x2a7 <tail_drop_notify+0x2a7>
     2bf:      	nop

00000000000002c0 <tail_icmp6_send_time_exceeded>:
     2c0:      	pushq	%rbp
     2c1:      	pushq	%r15
     2c3:      	pushq	%r14
     2c5:      	pushq	%r13
     2c7:      	pushq	%r12
     2c9:      	pushq	%rbx
     2ca:      	subq	$0xc8, %rsp
     2d1:      	movq	%rdi, %rbx
     2d4:      	movl	0x30(%rdi), %r14d
     2d8:      	movl	0x34(%rdi), %r13d
     2dc:      	movl	$0x0, 0x30(%rdi)
     2e3:      	movq	$0x0, 0x78(%rsp)
     2ec:      	movq	$0x0, 0x70(%rsp)
     2f5:      	movq	$0x0, 0x68(%rsp)
     2fe:      	movq	$0x0, 0x60(%rsp)
     307:      	movq	$0x0, 0x58(%rsp)
     310:      	movq	$0x0, 0x50(%rsp)
     319:      	movq	$0x0, 0x48(%rsp)
     322:      	movq	$0x0, 0x40(%rsp)
     32b:      	movq	$0x0, 0x38(%rsp)
     334:      	movq	$0x0, 0x30(%rsp)
     33d:      	movw	$0x0, 0x4(%rsp)
     344:      	movb	$0x3a, 0x7(%rsp)
     349:      	movq	(%rip), %rax            # 0x350 <tail_icmp6_send_time_exceeded+0x90>
     350:      	movq	(%rax), %rcx
     353:      	movq	%rcx, 0x90(%rsp)
     35b:      	movq	0x8(%rax), %rax
     35f:      	movq	%rax, 0x88(%rsp)
     367:      	movq	$0x3, 0x30(%rsp)
     370:      	leaq	0x38(%rsp), %r15
     375:      	movl	$0xe02, 0x8(%rsp)       # imm = 0xE02
     37d:      	movl	0x98(%rdi), %eax
     383:      	movl	%eax, 0xc(%rsp)
     387:      	movq	$0x0, 0x10(%rsp)
     390:      	movl	$0x0, 0x18(%rsp)
     398:      	movl	$0x19, %eax
     39d:      	movq	(%rip), %rsi            # 0x3a4 <tail_icmp6_send_time_exceeded+0xe4>
     3a4:      	leaq	0x8(%rsp), %rcx
     3a9:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     3ae:      	movl	$0x14, %r8d
     3b4:      	callq	*%rax
     3b6:      	movl	$0x1a, %eax
     3bb:      	movq	%rbx, %rdi
     3be:      	movl	%r14d, %esi
     3c1:      	movq	%r15, %rdx
     3c4:      	movl	$0x28, %ecx
     3c9:      	callq	*%rax
     3cb:      	movl	$0xffffff7a, %ebp       # imm = 0xFFFFFF7A
     3d0:      	testl	%eax, %eax
     3d2:      	js	0x8dd <tail_icmp6_send_time_exceeded+0x61d>
     3d8:      	movl	$0x9, %eax
     3dd:      	leal	0x6(%r14), %esi
     3e1:      	leaq	0x7(%rsp), %rdx
     3e6:      	movq	%rbx, %rdi
     3e9:      	movl	$0x1, %ecx
     3ee:      	xorl	%r8d, %r8d
     3f1:      	callq	*%rax
     3f3:      	testl	%eax, %eax
     3f5:      	js	0x8d8 <tail_icmp6_send_time_exceeded+0x618>
     3fb:      	leaq	0x60(%rsp), %rdx
     400:      	movzbl	0x3e(%rsp), %eax
     405:      	cmpl	$0x6, %eax
     408:      	je	0x533 <tail_icmp6_send_time_exceeded+0x273>
     40e:      	cmpl	$0x3a, %eax
     411:      	je	0x421 <tail_icmp6_send_time_exceeded+0x161>
     413:      	movl	$0xffffff72, %ebp       # imm = 0xFFFFFF72
     418:      	cmpl	$0x11, %eax
     41b:      	jne	0x8dd <tail_icmp6_send_time_exceeded+0x61d>
     421:      	movl	$0x1a, %eax
     426:      	leal	0x28(%r14), %r15d
     42a:      	movq	%rbx, %rdi
     42d:      	movl	%r15d, %esi
     430:      	movl	$0x8, %ecx
     435:      	callq	*%rax
     437:      	movl	$0xffffff7a, %ebp       # imm = 0xFFFFFF7A
     43c:      	testl	%eax, %eax
     43e:      	js	0x8dd <tail_icmp6_send_time_exceeded+0x61d>
     444:      	movl	$0x1c, %eax
     449:      	leaq	0x30(%rsp), %rdx
     44e:      	xorl	%edi, %edi
     450:      	xorl	%esi, %esi
     452:      	movl	$0x38, %ecx
     457:      	xorl	%r8d, %r8d
     45a:      	callq	*%rax
     45c:      	movl	$0x38000000, 0x8(%rsp)  # imm = 0x38000000
     464:      	movl	$0x3a000000, 0x20(%rsp) # imm = 0x3A000000
     46c:      	leaq	0x40(%rsp), %rdx
     471:      	movl	$0x1c, %r9d
     477:      	xorl	%edi, %edi
     479:      	xorl	%esi, %esi
     47b:      	movl	$0x10, %ecx
     480:      	movl	%eax, %r8d
     483:      	callq	*%r9
     486:      	leaq	0x50(%rsp), %rdx
     48b:      	movl	$0x1c, %r9d
     491:      	xorl	%edi, %edi
     493:      	xorl	%esi, %esi
     495:      	movl	$0x10, %ecx
     49a:      	movl	%eax, %r8d
     49d:      	callq	*%r9
     4a0:      	movl	$0x1c, %r9d
     4a6:      	leaq	0x8(%rsp), %rdx
     4ab:      	xorl	%edi, %edi
     4ad:      	xorl	%esi, %esi
     4af:      	movl	$0x4, %ecx
     4b4:      	movl	%eax, %r8d
     4b7:      	callq	*%r9
     4ba:      	movl	$0x1c, %r9d
     4c0:      	leaq	0x20(%rsp), %rdx
     4c5:      	xorl	%edi, %edi
     4c7:      	xorl	%esi, %esi
     4c9:      	movl	$0x4, %ecx
     4ce:      	movl	%eax, %r8d
     4d1:      	callq	*%r9
     4d4:      	movl	%eax, %r12d
     4d7:      	movw	$0x3800, 0x4(%rsp)      # imm = 0x3800
     4de:      	movbew	0x3c(%rsp), %ax
     4e5:      	movzwl	%ax, %eax
     4e8:      	movl	$0x26, %ecx
     4ed:      	movl	0x70(%rbx), %edx
     4f0:      	negl	%eax
     4f2:      	leal	(%rdx,%rax), %esi
     4f5:      	addl	$0x38, %esi
     4f8:      	movq	%rbx, %rdi
     4fb:      	xorl	%edx, %edx
     4fd:      	callq	*%rcx
     4ff:      	testl	%eax, %eax
     501:      	js	0x8d8 <tail_icmp6_send_time_exceeded+0x618>
     507:      	movl	$0x9, %eax
     50c:      	leaq	0x30(%rsp), %rdx
     511:      	movq	%rbx, %rdi
     514:      	movl	%r15d, %esi
     517:      	movl	$0x38, %ecx
     51c:      	xorl	%r8d, %r8d
     51f:      	callq	*%rax
     521:      	testl	%eax, %eax
     523:      	js	0x8d8 <tail_icmp6_send_time_exceeded+0x618>
     529:      	movl	$0x9, %eax
     52e:      	jmp	0x63b <tail_icmp6_send_time_exceeded+0x37b>
     533:      	movl	$0x1a, %eax
     538:      	leal	0x28(%r14), %r15d
     53c:      	movq	%rbx, %rdi
     53f:      	movl	%r15d, %esi
     542:      	movl	$0x14, %ecx
     547:      	callq	*%rax
     549:      	testl	%eax, %eax
     54b:      	js	0x8dd <tail_icmp6_send_time_exceeded+0x61d>
     551:      	movl	$0x1c, %eax
     556:      	leaq	0x30(%rsp), %rdx
     55b:      	xorl	%edi, %edi
     55d:      	xorl	%esi, %esi
     55f:      	movl	$0x44, %ecx
     564:      	xorl	%r8d, %r8d
     567:      	callq	*%rax
     569:      	movl	$0x44000000, 0x8(%rsp)  # imm = 0x44000000
     571:      	movl	$0x3a000000, 0x20(%rsp) # imm = 0x3A000000
     579:      	leaq	0x40(%rsp), %rdx
     57e:      	movl	$0x1c, %r9d
     584:      	xorl	%edi, %edi
     586:      	xorl	%esi, %esi
     588:      	movl	$0x10, %ecx
     58d:      	movl	%eax, %r8d
     590:      	callq	*%r9
     593:      	leaq	0x50(%rsp), %rdx
     598:      	movl	$0x1c, %r9d
     59e:      	xorl	%edi, %edi
     5a0:      	xorl	%esi, %esi
     5a2:      	movl	$0x10, %ecx
     5a7:      	movl	%eax, %r8d
     5aa:      	callq	*%r9
     5ad:      	movl	$0x1c, %r9d
     5b3:      	leaq	0x8(%rsp), %rdx
     5b8:      	xorl	%edi, %edi
     5ba:      	xorl	%esi, %esi
     5bc:      	movl	$0x4, %ecx
     5c1:      	movl	%eax, %r8d
     5c4:      	callq	*%r9
     5c7:      	movl	$0x1c, %r9d
     5cd:      	leaq	0x20(%rsp), %rdx
     5d2:      	xorl	%edi, %edi
     5d4:      	xorl	%esi, %esi
     5d6:      	movl	$0x4, %ecx
     5db:      	movl	%eax, %r8d
     5de:      	callq	*%r9
     5e1:      	movl	%eax, %r12d
     5e4:      	movw	$0x4400, 0x4(%rsp)      # imm = 0x4400
     5eb:      	movbew	0x3c(%rsp), %ax
     5f2:      	movzwl	%ax, %eax
     5f5:      	movl	$0x26, %ecx
     5fa:      	movl	0x70(%rbx), %edx
     5fd:      	negl	%eax
     5ff:      	leal	(%rdx,%rax), %esi
     602:      	addl	$0x44, %esi
     605:      	movq	%rbx, %rdi
     608:      	xorl	%edx, %edx
     60a:      	callq	*%rcx
     60c:      	testl	%eax, %eax
     60e:      	js	0x8d8 <tail_icmp6_send_time_exceeded+0x618>
     614:      	movl	$0x9, %eax
     619:      	leaq	0x30(%rsp), %rdx
     61e:      	movq	%rbx, %rdi
     621:      	movl	%r15d, %esi
     624:      	movl	$0x44, %ecx
     629:      	xorl	%r8d, %r8d
     62c:      	callq	*%rax
     62e:      	testl	%eax, %eax
     630:      	js	0x8d8 <tail_icmp6_send_time_exceeded+0x618>
     636:      	movl	$0x9, %eax
     63b:      	leal	0x4(%r14), %esi
     63f:      	leaq	0x4(%rsp), %rdx
     644:      	movq	%rbx, %rdi
     647:      	movl	$0x2, %ecx
     64c:      	xorl	%r8d, %r8d
     64f:      	callq	*%rax
     651:      	movl	$0xffffff73, %ebp       # imm = 0xFFFFFF73
     656:      	testl	%eax, %eax
     658:      	js	0x8dd <tail_icmp6_send_time_exceeded+0x61d>
     65e:      	leal	0x2a(%r14), %r15d
     662:      	movl	$0xb, %eax
     667:      	movq	%rbx, %rdi
     66a:      	movl	%r15d, %esi
     66d:      	xorl	%edx, %edx
     66f:      	movl	%r12d, %ecx
     672:      	movl	$0x10, %r8d
     678:      	callq	*%rax
     67a:      	testl	%eax, %eax
     67c:      	js	0x998 <tail_icmp6_send_time_exceeded+0x6d8>
     682:      	movq	0x90(%rsp), %rax
     68a:      	movq	0x88(%rsp), %rcx
     692:      	movq	%rax, 0x20(%rsp)
     697:      	movq	%rcx, 0x28(%rsp)
     69c:      	movq	(%rip), %rax            # 0x6a3 <tail_icmp6_send_time_exceeded+0x3e3>
     6a3:      	movq	(%rax), %rax
     6a6:      	movq	%rax, 0x98(%rsp)
     6ae:      	movl	$0x1a, %eax
     6b3:      	leal	0x8(%r14), %r12d
     6b7:      	leaq	0xa8(%rsp), %rdx
     6bf:      	movq	%rbx, %rdi
     6c2:      	movl	%r12d, %esi
     6c5:      	movl	$0x10, %ecx
     6ca:      	callq	*%rax
     6cc:      	movl	$0xffffff7a, %ebp       # imm = 0xFFFFFF7A
     6d1:      	testl	%eax, %eax
     6d3:      	js	0x8dd <tail_icmp6_send_time_exceeded+0x61d>
     6d9:      	movl	$0x1a, %eax
     6de:      	addl	$0x18, %r14d
     6e2:      	leaq	0xb8(%rsp), %rdx
     6ea:      	movq	%rbx, %rdi
     6ed:      	movl	%r14d, %esi
     6f0:      	movl	$0x10, %ecx
     6f5:      	callq	*%rax
     6f7:      	testl	%eax, %eax
     6f9:      	js	0x8dd <tail_icmp6_send_time_exceeded+0x61d>
     6ff:      	movl	$0x9, %eax
     704:      	leaq	0x20(%rsp), %rdx
     709:      	movq	%rbx, %rdi
     70c:      	movl	%r12d, %esi
     70f:      	movl	$0x10, %ecx
     714:      	xorl	%r8d, %r8d
     717:      	callq	*%rax
     719:      	testl	%eax, %eax
     71b:      	js	0x8d8 <tail_icmp6_send_time_exceeded+0x618>
     721:      	movl	$0x9, %eax
     726:      	leaq	0xa8(%rsp), %rdx
     72e:      	movq	%rbx, %rdi
     731:      	movl	%r14d, %esi
     734:      	movl	$0x10, %ecx
     739:      	xorl	%r8d, %r8d
     73c:      	callq	*%rax
     73e:      	testl	%eax, %eax
     740:      	js	0x8d8 <tail_icmp6_send_time_exceeded+0x618>
     746:      	movl	$0x1c, %eax
     74b:      	leaq	0xa8(%rsp), %rdi
     753:      	leaq	0x20(%rsp), %rdx
     758:      	movl	$0x10, %esi
     75d:      	movl	$0x10, %ecx
     762:      	xorl	%r8d, %r8d
     765:      	callq	*%rax
     767:      	movl	$0xb, %r14d
     76d:      	movq	%rbx, %rdi
     770:      	movl	%r15d, %esi
     773:      	xorl	%edx, %edx
     775:      	movl	%eax, %ecx
     777:      	movl	$0x10, %r8d
     77d:      	callq	*%r14
     780:      	movl	$0xffffff66, %ebp       # imm = 0xFFFFFF66
     785:      	testl	%eax, %eax
     787:      	js	0x8dd <tail_icmp6_send_time_exceeded+0x61d>
     78d:      	movl	$0x1c, %eax
     792:      	leaq	0xb8(%rsp), %rdi
     79a:      	leaq	0xa8(%rsp), %rdx
     7a2:      	movl	$0x10, %esi
     7a7:      	movl	$0x10, %ecx
     7ac:      	xorl	%r8d, %r8d
     7af:      	callq	*%rax
     7b1:      	movq	%rbx, %rdi
     7b4:      	movl	%r15d, %esi
     7b7:      	xorl	%edx, %edx
     7b9:      	movl	%eax, %ecx
     7bb:      	movl	$0x10, %r8d
     7c1:      	callq	*%r14
     7c4:      	testl	%eax, %eax
     7c6:      	js	0x8dd <tail_icmp6_send_time_exceeded+0x61d>
     7cc:      	movl	$0x1a, %eax
     7d1:      	leaq	0xa0(%rsp), %rdx
     7d9:      	movq	%rbx, %rdi
     7dc:      	movl	$0x6, %esi
     7e1:      	movl	$0x6, %ecx
     7e6:      	callq	*%rax
     7e8:      	movl	$0xffffff7a, %ebp       # imm = 0xFFFFFF7A
     7ed:      	testl	%eax, %eax
     7ef:      	js	0x8dd <tail_icmp6_send_time_exceeded+0x61d>
     7f5:      	movl	$0x9, %eax
     7fa:      	leaq	0xa0(%rsp), %rdx
     802:      	movq	%rbx, %rdi
     805:      	xorl	%esi, %esi
     807:      	movl	$0x6, %ecx
     80c:      	xorl	%r8d, %r8d
     80f:      	callq	*%rax
     811:      	testl	%eax, %eax
     813:      	js	0x8d8 <tail_icmp6_send_time_exceeded+0x618>
     819:      	movl	$0x9, %eax
     81e:      	leaq	0x98(%rsp), %rdx
     826:      	xorl	%r14d, %r14d
     829:      	movq	%rbx, %rdi
     82c:      	movl	$0x6, %esi
     831:      	movl	$0x6, %ecx
     836:      	xorl	%r8d, %r8d
     839:      	callq	*%rax
     83b:      	movl	$0xffffff73, %ebp       # imm = 0xFFFFFF73
     840:      	testl	%eax, %eax
     842:      	js	0x8dd <tail_icmp6_send_time_exceeded+0x61d>
     848:      	movq	0x10(%rbx), %rax
     84c:      	testq	%rax, %rax
     84f:      	je	0x858 <tail_icmp6_send_time_exceeded+0x598>
     851:      	movl	0xe0(%rax), %r14d
     858:      	movl	0x70(%rbx), %eax
     85b:      	movq	(%rip), %rcx            # 0x862 <tail_icmp6_send_time_exceeded+0x5a2>
     862:      	movl	(%rcx), %edx
     864:      	cmpl	%edx, %eax
     866:      	movl	$0x403, 0x8(%rsp)       # imm = 0x403
     86e:      	cmovbl	%eax, %edx
     871:      	movl	0x98(%rbx), %ecx
     877:      	movl	%ecx, 0xc(%rsp)
     87b:      	movl	%eax, 0x10(%rsp)
     87f:      	movw	%dx, 0x14(%rsp)
     884:      	movw	$0x1, 0x16(%rsp)
     88b:      	movl	%r14d, 0x18(%rsp)
     890:      	movl	$0x0, 0x1c(%rsp)
     898:      	movl	$0x19, %eax
     89d:      	shlq	$0x20, %rdx
     8a1:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
     8a6:      	orq	%rcx, %rdx
     8a9:      	movq	(%rip), %rsi            # 0x8b0 <tail_icmp6_send_time_exceeded+0x5f0>
     8b0:      	leaq	0x8(%rsp), %rcx
     8b5:      	movq	%rbx, %rdi
     8b8:      	movl	$0x18, %r8d
     8be:      	callq	*%rax
     8c0:      	movq	0x10(%rbx), %rax
     8c4:      	testq	%rax, %rax
     8c7:      	je	0x9a2 <tail_icmp6_send_time_exceeded+0x6e2>
     8cd:      	movl	0xe0(%rax), %edi
     8d3:      	jmp	0x9a4 <tail_icmp6_send_time_exceeded+0x6e4>
     8d8:      	movl	$0xffffff73, %ebp       # imm = 0xFFFFFF73
     8dd:      	movl	%ebp, %eax
     8df:      	negl	%eax
     8e1:      	cmovsl	%ebp, %eax
     8e4:      	movq	$0x0, 0x30(%rbx)
     8ec:      	movzbl	%al, %eax
     8ef:      	movl	%eax, 0x38(%rbx)
     8f2:      	movabsq	$0x142670200000000, %rcx # imm = 0x142670200000000
     8fc:      	movq	%rcx, 0x3c(%rbx)
     900:      	movl	0x70(%rbx), %r14d
     904:      	movabsq	$0x6701420000, %rcx     # imm = 0x6701420000
     90e:      	movq	%rcx, 0x8(%rsp)
     913:      	movb	%al, 0x8(%rsp)
     917:      	andb	$0x3, %r13b
     91b:      	movb	%r13b, 0x9(%rsp)
     920:      	movl	$0x1, %eax
     925:      	movq	(%rip), %rdi            # 0x92c <tail_icmp6_send_time_exceeded+0x66c>
     92c:      	leaq	0x8(%rsp), %rsi
     931:      	callq	*%rax
     933:      	testq	%rax, %rax
     936:      	je	0x941 <tail_icmp6_send_time_exceeded+0x681>
     938:      	incq	(%rax)
     93b:      	addq	%r14, 0x8(%rax)
     93f:      	jmp	0x969 <tail_icmp6_send_time_exceeded+0x6a9>
     941:      	movq	$0x1, 0x30(%rsp)
     94a:      	movq	%r14, 0x38(%rsp)
     94f:      	movl	$0x2, %eax
     954:      	movq	(%rip), %rdi            # 0x95b <tail_icmp6_send_time_exceeded+0x69b>
     95b:      	leaq	0x8(%rsp), %rsi
     960:      	leaq	0x30(%rsp), %rdx
     965:      	xorl	%ecx, %ecx
     967:      	callq	*%rax
     969:      	movl	$0xc, %eax
     96e:      	movq	(%rip), %rsi            # 0x975 <tail_icmp6_send_time_exceeded+0x6b5>
     975:      	movq	%rbx, %rdi
     978:      	movl	$0x1, %edx
     97d:      	callq	*%rax
     97f:      	movl	$0x2, %ebp
     984:      	movl	%ebp, %eax
     986:      	addq	$0xc8, %rsp
     98d:      	popq	%rbx
     98e:      	popq	%r12
     990:      	popq	%r13
     992:      	popq	%r14
     994:      	popq	%r15
     996:      	popq	%rbp
     997:      	retq
     998:      	movl	$0xffffff66, %ebp       # imm = 0xFFFFFF66
     99d:      	jmp	0x8dd <tail_icmp6_send_time_exceeded+0x61d>
     9a2:      	xorl	%edi, %edi
     9a4:      	movl	$0x17, %eax
     9a9:      	xorl	%esi, %esi
     9ab:      	callq	*%rax
     9ad:      	movl	%eax, %ebp
     9af:      	testl	%eax, %eax
     9b1:      	js	0x8dd <tail_icmp6_send_time_exceeded+0x61d>
     9b7:      	cmpl	$0x2, %ebp
     9ba:      	jne	0x984 <tail_icmp6_send_time_exceeded+0x6c4>
     9bc:      	jmp	0x8dd <tail_icmp6_send_time_exceeded+0x61d>

Disassembly of section tc/entry:

0000000000000000 <cil_from_wireguard>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%rbx
       6:      	subq	$0x28, %rsp
       a:      	movq	%rdi, %rbx
       d:      	movl	$0x0, 0x30(%rdi)
      14:      	movl	$0x0, 0x34(%rdi)
      1b:      	movl	$0x0, 0x38(%rdi)
      22:      	movl	$0x0, 0x3c(%rdi)
      29:      	movl	$0x0, 0x40(%rdi)
      30:      	movq	(%rip), %rax            # 0x37 <cil_from_wireguard+0x37>
      37:      	cmpb	$0x0, (%rax)
      3a:      	je	0x85 <cil_from_wireguard+0x85>
      3c:      	movzbl	(%rax), %ebp
      3f:      	cmpw	$0x8, 0xb4(%rbx)
      47:      	jne	0x5e <cil_from_wireguard+0x5e>
      49:      	movq	0xd0(%rbx), %rax
      50:      	leaq	0x14(%rax), %rcx
      54:      	cmpq	0x50(%rbx), %rcx
      58:      	jbe	0x10c <cil_from_wireguard+0x10c>
      5e:      	movl	$0x0, 0x18(%rsp)
      66:      	movl	$0x1, %eax
      6b:      	movq	(%rip), %rdi            # 0x72 <cil_from_wireguard+0x72>
      72:      	leaq	0x18(%rsp), %rsi
      77:      	callq	*%rax
      79:      	testq	%rax, %rax
      7c:      	je	0x85 <cil_from_wireguard+0x85>
      7e:      	movq	$0x0, (%rax)
      85:      	movq	(%rip), %rax            # 0x8c <cil_from_wireguard+0x8c>
      8c:      	cmpb	$0x0, (%rax)
      8f:      	je	0x9b <cil_from_wireguard+0x9b>
      91:      	movl	$0xd00, 0xa8(%rbx)      # imm = 0xD00
      9b:      	movq	(%rip), %rax            # 0xa2 <cil_from_wireguard+0xa2>
      a2:      	movl	(%rax), %eax
      a4:      	movl	0x70(%rbx), %ebx
      a7:      	movabsq	$0x70154010c, %rax      # imm = 0x70154010C
      b1:      	movq	%rax, 0x10(%rsp)
      b6:      	movl	$0x1, %eax
      bb:      	movq	(%rip), %rdi            # 0xc2 <cil_from_wireguard+0xc2>
      c2:      	leaq	0x10(%rsp), %rsi
      c7:      	callq	*%rax
      c9:      	testq	%rax, %rax
      cc:      	je	0xd7 <cil_from_wireguard+0xd7>
      ce:      	incq	(%rax)
      d1:      	addq	%rbx, 0x8(%rax)
      d5:      	jmp	0xff <cil_from_wireguard+0xff>
      d7:      	movq	$0x1, 0x18(%rsp)
      e0:      	movq	%rbx, 0x20(%rsp)
      e5:      	movl	$0x2, %eax
      ea:      	movq	(%rip), %rdi            # 0xf1 <cil_from_wireguard+0xf1>
      f1:      	leaq	0x10(%rsp), %rsi
      f6:      	leaq	0x18(%rsp), %rdx
      fb:      	xorl	%ecx, %ecx
      fd:      	callq	*%rax
      ff:      	xorl	%eax, %eax
     101:      	addq	$0x28, %rsp
     105:      	popq	%rbx
     106:      	popq	%r14
     108:      	popq	%r15
     10a:      	popq	%rbp
     10b:      	retq
     10c:      	movzbl	(%rax), %r15d
     110:      	andl	$0xf, %r15d
     114:      	cmpb	$0x6, %r15b
     118:      	jae	0x149 <cil_from_wireguard+0x149>
     11a:      	xorl	%r14d, %r14d
     11d:      	movl	$0x0, 0x18(%rsp)
     125:      	movl	$0x1, %eax
     12a:      	movq	(%rip), %rdi            # 0x131 <cil_from_wireguard+0x131>
     131:      	leaq	0x18(%rsp), %rsi
     136:      	callq	*%rax
     138:      	testq	%rax, %rax
     13b:      	je	0x85 <cil_from_wireguard+0x85>
     141:      	movq	%r14, (%rax)
     144:      	jmp	0x85 <cil_from_wireguard+0x85>
     149:      	movl	$0x1a, %eax
     14e:      	leaq	0x10(%rsp), %rdx
     153:      	movq	%rbx, %rdi
     156:      	movl	$0x14, %esi
     15b:      	movl	$0x1, %ecx
     160:      	callq	*%rax
     162:      	testl	%eax, %eax
     164:      	js	0x5e <cil_from_wireguard+0x5e>
     16a:      	movzbl	0x10(%rsp), %eax
     16f:      	testl	%eax, %eax
     171:      	je	0x11a <cil_from_wireguard+0x11a>
     173:      	movl	$0x15, %r14d
     179:      	cmpl	$0x1, %eax
     17c:      	je	0x209 <cil_from_wireguard+0x209>
     182:      	movl	$0x1a, %eax
     187:      	leaq	0xf(%rsp), %rdx
     18c:      	movq	%rbx, %rdi
     18f:      	movl	$0x15, %esi
     194:      	movl	$0x1, %ecx
     199:      	callq	*%rax
     19b:      	testl	%eax, %eax
     19d:      	js	0x5e <cil_from_wireguard+0x5e>
     1a3:      	movl	$0x14, %r14d
     1a9:      	cmpb	%bpl, 0x10(%rsp)
     1ae:      	jne	0x1ff <cil_from_wireguard+0x1ff>
     1b0:      	movzbl	0xf(%rsp), %eax
     1b5:      	cmpl	$0xa, %eax
     1b8:      	je	0x30d <cil_from_wireguard+0x30d>
     1be:      	cmpl	$0x6, %eax
     1c1:      	je	0x2e1 <cil_from_wireguard+0x2e1>
     1c7:      	cmpl	$0x4, %eax
     1ca:      	jne	0x5e <cil_from_wireguard+0x5e>
     1d0:      	movl	$0x1a, %eax
     1d5:      	addl	$0x2, %r14d
     1d9:      	leaq	0x18(%rsp), %rdx
     1de:      	movq	%rbx, %rdi
     1e1:      	movl	%r14d, %esi
     1e4:      	movl	$0x2, %ecx
     1e9:      	callq	*%rax
     1eb:      	xorl	%r14d, %r14d
     1ee:      	testl	%eax, %eax
     1f0:      	movbew	0x18(%rsp), %cx
     1f7:      	movzwl	%cx, %ecx
     1fa:      	jmp	0x334 <cil_from_wireguard+0x334>
     1ff:      	movzbl	0xf(%rsp), %r14d
     205:      	addl	$0x14, %r14d
     209:      	leal	0x14(,%r15,4), %r15d
     211:      	cmpl	%r15d, %r14d
     214:      	jae	0x11a <cil_from_wireguard+0x11a>
     21a:      	movl	$0x1a, %eax
     21f:      	leaq	0x10(%rsp), %rdx
     224:      	movq	%rbx, %rdi
     227:      	movl	%r14d, %esi
     22a:      	movl	$0x1, %ecx
     22f:      	callq	*%rax
     231:      	testl	%eax, %eax
     233:      	js	0x5e <cil_from_wireguard+0x5e>
     239:      	movzbl	0x10(%rsp), %eax
     23e:      	testl	%eax, %eax
     240:      	je	0x11a <cil_from_wireguard+0x11a>
     246:      	cmpl	$0x1, %eax
     249:      	je	0x27b <cil_from_wireguard+0x27b>
     24b:      	movl	$0x1a, %eax
     250:      	leal	0x1(%r14), %esi
     254:      	leaq	0xf(%rsp), %rdx
     259:      	movq	%rbx, %rdi
     25c:      	movl	$0x1, %ecx
     261:      	callq	*%rax
     263:      	testl	%eax, %eax
     265:      	js	0x5e <cil_from_wireguard+0x5e>
     26b:      	cmpb	%bpl, 0x10(%rsp)
     270:      	je	0x1b0 <cil_from_wireguard+0x1b0>
     276:      	movzbl	0xf(%rsp), %eax
     27b:      	addl	%eax, %r14d
     27e:      	cmpl	%r15d, %r14d
     281:      	jae	0x11a <cil_from_wireguard+0x11a>
     287:      	movl	$0x1a, %eax
     28c:      	leaq	0x10(%rsp), %rdx
     291:      	movq	%rbx, %rdi
     294:      	movl	%r14d, %esi
     297:      	movl	$0x1, %ecx
     29c:      	callq	*%rax
     29e:      	testl	%eax, %eax
     2a0:      	js	0x5e <cil_from_wireguard+0x5e>
     2a6:      	cmpb	$0x2, 0x10(%rsp)
     2ab:      	jb	0x11a <cil_from_wireguard+0x11a>
     2b1:      	movl	$0x1a, %eax
     2b6:      	leal	0x1(%r14), %esi
     2ba:      	leaq	0xf(%rsp), %rdx
     2bf:      	movq	%rbx, %rdi
     2c2:      	movl	$0x1, %ecx
     2c7:      	callq	*%rax
     2c9:      	testl	%eax, %eax
     2cb:      	js	0x5e <cil_from_wireguard+0x5e>
     2d1:      	cmpb	%bpl, 0x10(%rsp)
     2d6:      	jne	0x11a <cil_from_wireguard+0x11a>
     2dc:      	jmp	0x1b0 <cil_from_wireguard+0x1b0>
     2e1:      	movl	$0x1a, %eax
     2e6:      	addl	$0x2, %r14d
     2ea:      	leaq	0x18(%rsp), %rdx
     2ef:      	movq	%rbx, %rdi
     2f2:      	movl	%r14d, %esi
     2f5:      	movl	$0x4, %ecx
     2fa:      	callq	*%rax
     2fc:      	xorl	%ecx, %ecx
     2fe:      	testl	%eax, %eax
     300:      	movbel	0x18(%rsp), %r14d
     307:      	cmovsl	%ecx, %r14d
     30b:      	jmp	0x338 <cil_from_wireguard+0x338>
     30d:      	movl	$0x1a, %eax
     312:      	addl	$0x2, %r14d
     316:      	leaq	0x18(%rsp), %rdx
     31b:      	movq	%rbx, %rdi
     31e:      	movl	%r14d, %esi
     321:      	movl	$0x8, %ecx
     326:      	callq	*%rax
     328:      	xorl	%r14d, %r14d
     32b:      	testl	%eax, %eax
     32d:      	movbeq	0x18(%rsp), %rcx
     334:      	cmovnsq	%rcx, %r14
     338:      	testl	%eax, %eax
     33a:      	jns	0x11d <cil_from_wireguard+0x11d>
     340:      	jmp	0x5e <cil_from_wireguard+0x5e>
     345:      	nopw	%cs:(%rax,%rax)

0000000000000350 <cil_to_wireguard>:
     350:      	pushq	%rbp
     351:      	pushq	%r15
     353:      	pushq	%r14
     355:      	pushq	%rbx
     356:      	subq	$0x28, %rsp
     35a:      	movq	%rdi, %rbx
     35d:      	movl	0xa8(%rdi), %eax
     363:      	notl	%eax
     365:      	testl	$0xf00, %eax            # imm = 0xF00
     36a:      	jne	0x37d <cil_to_wireguard+0x2d>
     36c:      	movq	(%rip), %rax            # 0x373 <cil_to_wireguard+0x23>
     373:      	movl	(%rax), %ecx
     375:      	movl	(%rax), %ecx
     377:      	movl	(%rax), %ecx
     379:      	movl	(%rax), %ecx
     37b:      	movl	(%rax), %eax
     37d:      	movl	$0x0, 0x30(%rbx)
     384:      	movl	$0x0, 0x34(%rbx)
     38b:      	movl	$0x0, 0x38(%rbx)
     392:      	movl	$0x0, 0x3c(%rbx)
     399:      	movl	$0x0, 0x40(%rbx)
     3a0:      	movq	(%rip), %rax            # 0x3a7 <cil_to_wireguard+0x57>
     3a7:      	cmpb	$0x0, (%rax)
     3aa:      	je	0x3f5 <cil_to_wireguard+0xa5>
     3ac:      	movzbl	(%rax), %ebp
     3af:      	cmpw	$0x8, 0xb4(%rbx)
     3b7:      	jne	0x3ce <cil_to_wireguard+0x7e>
     3b9:      	movq	0xd0(%rbx), %rax
     3c0:      	leaq	0x14(%rax), %rcx
     3c4:      	cmpq	0x50(%rbx), %rcx
     3c8:      	jbe	0x466 <cil_to_wireguard+0x116>
     3ce:      	movl	$0x0, 0x18(%rsp)
     3d6:      	movl	$0x1, %eax
     3db:      	movq	(%rip), %rdi            # 0x3e2 <cil_to_wireguard+0x92>
     3e2:      	leaq	0x18(%rsp), %rsi
     3e7:      	callq	*%rax
     3e9:      	testq	%rax, %rax
     3ec:      	je	0x3f5 <cil_to_wireguard+0xa5>
     3ee:      	movq	$0x0, (%rax)
     3f5:      	movq	(%rip), %rax            # 0x3fc <cil_to_wireguard+0xac>
     3fc:      	movl	(%rax), %eax
     3fe:      	movl	0x70(%rbx), %ebx
     401:      	movabsq	$0x7017d020d, %rax      # imm = 0x7017D020D
     40b:      	movq	%rax, 0x10(%rsp)
     410:      	movl	$0x1, %eax
     415:      	movq	(%rip), %rdi            # 0x41c <cil_to_wireguard+0xcc>
     41c:      	leaq	0x10(%rsp), %rsi
     421:      	callq	*%rax
     423:      	testq	%rax, %rax
     426:      	je	0x431 <cil_to_wireguard+0xe1>
     428:      	incq	(%rax)
     42b:      	addq	%rbx, 0x8(%rax)
     42f:      	jmp	0x459 <cil_to_wireguard+0x109>
     431:      	movq	$0x1, 0x18(%rsp)
     43a:      	movq	%rbx, 0x20(%rsp)
     43f:      	movl	$0x2, %eax
     444:      	movq	(%rip), %rdi            # 0x44b <cil_to_wireguard+0xfb>
     44b:      	leaq	0x10(%rsp), %rsi
     450:      	leaq	0x18(%rsp), %rdx
     455:      	xorl	%ecx, %ecx
     457:      	callq	*%rax
     459:      	xorl	%eax, %eax
     45b:      	addq	$0x28, %rsp
     45f:      	popq	%rbx
     460:      	popq	%r14
     462:      	popq	%r15
     464:      	popq	%rbp
     465:      	retq
     466:      	movzbl	(%rax), %r15d
     46a:      	andl	$0xf, %r15d
     46e:      	cmpb	$0x6, %r15b
     472:      	jae	0x4a3 <cil_to_wireguard+0x153>
     474:      	xorl	%r14d, %r14d
     477:      	movl	$0x0, 0x18(%rsp)
     47f:      	movl	$0x1, %eax
     484:      	movq	(%rip), %rdi            # 0x48b <cil_to_wireguard+0x13b>
     48b:      	leaq	0x18(%rsp), %rsi
     490:      	callq	*%rax
     492:      	testq	%rax, %rax
     495:      	je	0x3f5 <cil_to_wireguard+0xa5>
     49b:      	movq	%r14, (%rax)
     49e:      	jmp	0x3f5 <cil_to_wireguard+0xa5>
     4a3:      	movl	$0x1a, %eax
     4a8:      	leaq	0x10(%rsp), %rdx
     4ad:      	movq	%rbx, %rdi
     4b0:      	movl	$0x14, %esi
     4b5:      	movl	$0x1, %ecx
     4ba:      	callq	*%rax
     4bc:      	testl	%eax, %eax
     4be:      	js	0x3ce <cil_to_wireguard+0x7e>
     4c4:      	movzbl	0x10(%rsp), %eax
     4c9:      	testl	%eax, %eax
     4cb:      	je	0x474 <cil_to_wireguard+0x124>
     4cd:      	movl	$0x15, %r14d
     4d3:      	cmpl	$0x1, %eax
     4d6:      	je	0x563 <cil_to_wireguard+0x213>
     4dc:      	movl	$0x1a, %eax
     4e1:      	leaq	0xf(%rsp), %rdx
     4e6:      	movq	%rbx, %rdi
     4e9:      	movl	$0x15, %esi
     4ee:      	movl	$0x1, %ecx
     4f3:      	callq	*%rax
     4f5:      	testl	%eax, %eax
     4f7:      	js	0x3ce <cil_to_wireguard+0x7e>
     4fd:      	movl	$0x14, %r14d
     503:      	cmpb	%bpl, 0x10(%rsp)
     508:      	jne	0x559 <cil_to_wireguard+0x209>
     50a:      	movzbl	0xf(%rsp), %eax
     50f:      	cmpl	$0xa, %eax
     512:      	je	0x667 <cil_to_wireguard+0x317>
     518:      	cmpl	$0x6, %eax
     51b:      	je	0x63b <cil_to_wireguard+0x2eb>
     521:      	cmpl	$0x4, %eax
     524:      	jne	0x3ce <cil_to_wireguard+0x7e>
     52a:      	movl	$0x1a, %eax
     52f:      	addl	$0x2, %r14d
     533:      	leaq	0x18(%rsp), %rdx
     538:      	movq	%rbx, %rdi
     53b:      	movl	%r14d, %esi
     53e:      	movl	$0x2, %ecx
     543:      	callq	*%rax
     545:      	xorl	%r14d, %r14d
     548:      	testl	%eax, %eax
     54a:      	movbew	0x18(%rsp), %cx
     551:      	movzwl	%cx, %ecx
     554:      	jmp	0x68e <cil_to_wireguard+0x33e>
     559:      	movzbl	0xf(%rsp), %r14d
     55f:      	addl	$0x14, %r14d
     563:      	leal	0x14(,%r15,4), %r15d
     56b:      	cmpl	%r15d, %r14d
     56e:      	jae	0x474 <cil_to_wireguard+0x124>
     574:      	movl	$0x1a, %eax
     579:      	leaq	0x10(%rsp), %rdx
     57e:      	movq	%rbx, %rdi
     581:      	movl	%r14d, %esi
     584:      	movl	$0x1, %ecx
     589:      	callq	*%rax
     58b:      	testl	%eax, %eax
     58d:      	js	0x3ce <cil_to_wireguard+0x7e>
     593:      	movzbl	0x10(%rsp), %eax
     598:      	testl	%eax, %eax
     59a:      	je	0x474 <cil_to_wireguard+0x124>
     5a0:      	cmpl	$0x1, %eax
     5a3:      	je	0x5d5 <cil_to_wireguard+0x285>
     5a5:      	movl	$0x1a, %eax
     5aa:      	leal	0x1(%r14), %esi
     5ae:      	leaq	0xf(%rsp), %rdx
     5b3:      	movq	%rbx, %rdi
     5b6:      	movl	$0x1, %ecx
     5bb:      	callq	*%rax
     5bd:      	testl	%eax, %eax
     5bf:      	js	0x3ce <cil_to_wireguard+0x7e>
     5c5:      	cmpb	%bpl, 0x10(%rsp)
     5ca:      	je	0x50a <cil_to_wireguard+0x1ba>
     5d0:      	movzbl	0xf(%rsp), %eax
     5d5:      	addl	%eax, %r14d
     5d8:      	cmpl	%r15d, %r14d
     5db:      	jae	0x474 <cil_to_wireguard+0x124>
     5e1:      	movl	$0x1a, %eax
     5e6:      	leaq	0x10(%rsp), %rdx
     5eb:      	movq	%rbx, %rdi
     5ee:      	movl	%r14d, %esi
     5f1:      	movl	$0x1, %ecx
     5f6:      	callq	*%rax
     5f8:      	testl	%eax, %eax
     5fa:      	js	0x3ce <cil_to_wireguard+0x7e>
     600:      	cmpb	$0x2, 0x10(%rsp)
     605:      	jb	0x474 <cil_to_wireguard+0x124>
     60b:      	movl	$0x1a, %eax
     610:      	leal	0x1(%r14), %esi
     614:      	leaq	0xf(%rsp), %rdx
     619:      	movq	%rbx, %rdi
     61c:      	movl	$0x1, %ecx
     621:      	callq	*%rax
     623:      	testl	%eax, %eax
     625:      	js	0x3ce <cil_to_wireguard+0x7e>
     62b:      	cmpb	%bpl, 0x10(%rsp)
     630:      	jne	0x474 <cil_to_wireguard+0x124>
     636:      	jmp	0x50a <cil_to_wireguard+0x1ba>
     63b:      	movl	$0x1a, %eax
     640:      	addl	$0x2, %r14d
     644:      	leaq	0x18(%rsp), %rdx
     649:      	movq	%rbx, %rdi
     64c:      	movl	%r14d, %esi
     64f:      	movl	$0x4, %ecx
     654:      	callq	*%rax
     656:      	xorl	%ecx, %ecx
     658:      	testl	%eax, %eax
     65a:      	movbel	0x18(%rsp), %r14d
     661:      	cmovsl	%ecx, %r14d
     665:      	jmp	0x692 <cil_to_wireguard+0x342>
     667:      	movl	$0x1a, %eax
     66c:      	addl	$0x2, %r14d
     670:      	leaq	0x18(%rsp), %rdx
     675:      	movq	%rbx, %rdi
     678:      	movl	%r14d, %esi
     67b:      	movl	$0x8, %ecx
     680:      	callq	*%rax
     682:      	xorl	%r14d, %r14d
     685:      	testl	%eax, %eax
     687:      	movbeq	0x18(%rsp), %rcx
     68e:      	cmovnsq	%rcx, %r14
     692:      	testl	%eax, %eax
     694:      	jns	0x477 <cil_to_wireguard+0x127>
     69a:      	jmp	0x3ce <cil_to_wireguard+0x7e>
