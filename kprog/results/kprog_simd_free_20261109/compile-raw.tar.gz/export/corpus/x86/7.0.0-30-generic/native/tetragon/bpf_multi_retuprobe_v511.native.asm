
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_multi_retuprobe_v511.native.o:	file format elf64-x86-64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
       5:      	testq	%rdx, %rdx
       8:      	je	0x74 <native_bpf_strncasestr+0x74>
       a:      	pushq	%rbx
       b:      	xorl	%ecx, %ecx
       d:      	jmp	0x1b <native_bpf_strncasestr+0x1b>
       f:      	nop
      10:      	incq	%rcx
      13:      	incq	%rdi
      16:      	cmpq	%rdx, %rcx
      19:      	je	0x73 <native_bpf_strncasestr+0x73>
      1b:      	xorl	%r8d, %r8d
      1e:      	nop
      20:      	leaq	(%rcx,%r8), %r9
      24:      	cmpq	%rdx, %r9
      27:      	jae	0x10 <native_bpf_strncasestr+0x10>
      29:      	movsbl	(%rsi,%r8), %r9d
      2e:      	testl	%r9d, %r9d
      31:      	je	0x71 <native_bpf_strncasestr+0x71>
      33:      	movsbl	(%rdi,%r8), %r10d
      38:      	leal	-0x41(%r10), %r11d
      3c:      	movl	%r10d, %ebx
      3f:      	orl	$0x20, %ebx
      42:      	cmpl	$0x1a, %r11d
      46:      	cmovael	%r10d, %ebx
      4a:      	leal	-0x41(%r9), %r10d
      4e:      	movl	%r9d, %r11d
      51:      	orl	$0x20, %r11d
      55:      	cmpl	$0x1a, %r10d
      59:      	cmovael	%r9d, %r11d
      5d:      	cmpl	%r11d, %ebx
      60:      	jne	0x10 <native_bpf_strncasestr+0x10>
      62:      	leaq	0x1(%r8), %r9
      66:      	cmpq	$0x63, %r8
      6a:      	movq	%r9, %r8
      6d:      	jb	0x20 <native_bpf_strncasestr+0x20>
      6f:      	jmp	0x10 <native_bpf_strncasestr+0x10>
      71:      	movl	%ecx, %eax
      73:      	popq	%rbx
      74:      	retq

Disassembly of section uprobe.multi:

0000000000000000 <generic_retuprobe_filter_arg>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xb8, %rsp
      11:      	movq	%rdi, %r13
      14:      	movl	$0x0, 0x94(%rsp)
      1f:      	movq	(%rip), %rdi            # 0x26 <generic_retuprobe_filter_arg+0x26>
      26:      	leaq	0x94(%rsp), %rsi
      2e:      	movl	$0x1, %eax
      33:      	callq	*%rax
      35:      	testq	%rax, %rax
      38:      	je	0x179 <generic_retuprobe_filter_arg+0x179>
      3e:      	movq	%rax, %r14
      41:      	movl	0x5f00(%rax), %ebx
      47:      	leaq	0x5ef8(%rax), %rsi
      4e:      	movq	(%rip), %rdi            # 0x55 <generic_retuprobe_filter_arg+0x55>
      55:      	movl	$0x1, %eax
      5a:      	callq	*%rax
      5c:      	testq	%rax, %rax
      5f:      	je	0x15e <generic_retuprobe_filter_arg+0x15e>
      65:      	cmpb	$0x0, 0x5ee0(%r14)
      6d:      	je	0x15e <generic_retuprobe_filter_arg+0x15e>
      73:      	movq	%rax, %rdi
      76:      	movl	%ebx, %eax
      78:      	andl	$0x7, %eax
      7b:      	cmpb	$0x0, 0x5ec1(%r14,%rax)
      84:      	je	0xb8 <generic_retuprobe_filter_arg+0xb8>
      86:      	movl	%eax, %eax
      88:      	movl	0x4(%rdi,%rax,4), %ecx
      8c:      	leaq	(%rcx,%rax,4), %r11
      90:      	addq	$0x8, %r11
      94:      	movl	%r11d, %r9d
      97:      	andl	$0x3ff, %r9d            # imm = 0x3FF
      9e:      	cmpl	$0x19, (%rdi,%r9)
      a3:      	jae	0x104 <generic_retuprobe_filter_arg+0x104>
      a5:      	cmpq	$0x1, %r9
      a9:      	je	0x15e <generic_retuprobe_filter_arg+0x15e>
      af:      	testl	%r9d, %r9d
      b2:      	jne	0x13c <generic_retuprobe_filter_arg+0x13c>
      b8:      	cmpl	$0x1, %ebx
      bb:      	jg	0xd9 <generic_retuprobe_filter_arg+0xd9>
      bd:      	cmpl	$-0x1, %ebx
      c0:      	je	0x18d <generic_retuprobe_filter_arg+0x18d>
      c6:      	testl	%ebx, %ebx
      c8:      	je	0x199 <generic_retuprobe_filter_arg+0x199>
      ce:      	cmpl	$0x1, %ebx
      d1:      	je	0x1a8 <generic_retuprobe_filter_arg+0x1a8>
      d7:      	jmp	0xf4 <generic_retuprobe_filter_arg+0xf4>
      d9:      	cmpl	$0x2, %ebx
      dc:      	je	0x1b7 <generic_retuprobe_filter_arg+0x1b7>
      e2:      	cmpl	$0x3, %ebx
      e5:      	je	0x1c6 <generic_retuprobe_filter_arg+0x1c6>
      eb:      	cmpl	$0x4, %ebx
      ee:      	je	0x1d5 <generic_retuprobe_filter_arg+0x1d5>
      f4:      	cmpl	$0x4, %ebx
      f7:      	jg	0x206 <generic_retuprobe_filter_arg+0x206>
      fd:      	incl	%ebx
      ff:      	jmp	0x1e4 <generic_retuprobe_filter_arg+0x1e4>
     104:      	leaq	(%rdi,%r9), %rax
     108:      	movq	%rax, 0xa8(%rsp)
     110:      	xorl	%ecx, %ecx
     112:      	leaq	0x70(%rsp), %rax
     117:      	movq	%rax, 0x20(%rsp)
     11c:      	movq	%r13, 0x28(%rsp)
     121:      	movq	%rbx, 0xa0(%rsp)
     129:      	movq	%rdi, (%rsp)
     12d:      	movq	%r9, 0x8(%rsp)
     132:      	movq	%r11, 0x10(%rsp)
     137:      	jmp	0x286 <generic_retuprobe_filter_arg+0x286>
     13c:      	movl	%r9d, 0x5f04(%r14)
     143:      	movq	(%rip), %rsi            # 0x14a <generic_retuprobe_filter_arg+0x14a>
     14a:      	movl	$0x4, %ecx
     14f:      	movl	$0xc, %eax
     154:      	movq	%r13, %rdi
     157:      	movl	$0x4, %edx
     15c:      	callq	*%rax
     15e:      	movq	(%rip), %rsi            # 0x165 <generic_retuprobe_filter_arg+0x165>
     165:      	movl	$0x5, %ecx
     16a:      	movl	$0xc, %eax
     16f:      	movq	%r13, %rdi
     172:      	movl	$0x5, %edx
     177:      	callq	*%rax
     179:      	xorl	%eax, %eax
     17b:      	addq	$0xb8, %rsp
     182:      	popq	%rbx
     183:      	popq	%r12
     185:      	popq	%r13
     187:      	popq	%r14
     189:      	popq	%r15
     18b:      	popq	%rbp
     18c:      	retq
     18d:      	xorl	%ebx, %ebx
     18f:      	cmpb	$0x0, 0x5ec1(%r14)
     197:      	jne	0x1e4 <generic_retuprobe_filter_arg+0x1e4>
     199:      	movl	$0x1, %ebx
     19e:      	cmpb	$0x0, 0x5ec2(%r14)
     1a6:      	jne	0x1e4 <generic_retuprobe_filter_arg+0x1e4>
     1a8:      	movl	$0x2, %ebx
     1ad:      	cmpb	$0x0, 0x5ec3(%r14)
     1b5:      	jne	0x1e4 <generic_retuprobe_filter_arg+0x1e4>
     1b7:      	movl	$0x3, %ebx
     1bc:      	cmpb	$0x0, 0x5ec4(%r14)
     1c4:      	jne	0x1e4 <generic_retuprobe_filter_arg+0x1e4>
     1c6:      	movl	$0x4, %ebx
     1cb:      	cmpb	$0x0, 0x5ec5(%r14)
     1d3:      	jne	0x1e4 <generic_retuprobe_filter_arg+0x1e4>
     1d5:      	movl	$0x5, %ebx
     1da:      	cmpb	$0x0, 0x5ec6(%r14)
     1e2:      	je	0x206 <generic_retuprobe_filter_arg+0x206>
     1e4:      	movl	%ebx, 0x5f00(%r14)
     1eb:      	movq	(%rip), %rsi            # 0x1f2 <generic_retuprobe_filter_arg+0x1f2>
     1f2:      	movl	$0x3, %ecx
     1f7:      	movl	$0xc, %eax
     1fc:      	movq	%r13, %rdi
     1ff:      	movl	$0x3, %edx
     204:      	callq	*%rax
     206:      	movq	0x60(%r14), %rbx
     20a:      	movl	$0xe, %eax
     20f:      	callq	*%rax
     211:      	movq	%rbx, 0x38(%rsp)
     216:      	movq	%rax, 0x40(%rsp)
     21b:      	movq	(%rip), %rdi            # 0x222 <generic_retuprobe_filter_arg+0x222>
     222:      	leaq	0x38(%rsp), %rsi
     227:      	movl	$0x1, %eax
     22c:      	callq	*%rax
     22e:      	testq	%rax, %rax
     231:      	je	0x179 <generic_retuprobe_filter_arg+0x179>
     237:      	movq	(%rip), %rdi            # 0x23e <generic_retuprobe_filter_arg+0x23e>
     23e:      	leaq	0x38(%rsp), %rsi
     243:      	movl	$0x3, %eax
     248:      	callq	*%rax
     24a:      	jmp	0x179 <generic_retuprobe_filter_arg+0x179>
     24f:      	xorl	%ebx, %ebx
     251:      	cmpl	$0x3, %eax
     254:      	sete	%bl
     257:      	nopw	(%rax,%rax)
     260:      	testq	%rbx, %rbx
     263:      	movq	0xa0(%rsp), %rbx
     26b:      	je	0xb8 <generic_retuprobe_filter_arg+0xb8>
     271:      	movq	0xb0(%rsp), %rcx
     279:      	incq	%rcx
     27c:      	cmpq	$0x5, %rcx
     280:      	je	0xa5 <generic_retuprobe_filter_arg+0xa5>
     286:      	movq	0xa8(%rsp), %rax
     28e:      	movl	0x4(%rax,%rcx,4), %r12d
     293:      	testl	$0x3ff, %r12d           # imm = 0x3FF
     29a:      	je	0xa5 <generic_retuprobe_filter_arg+0xa5>
     2a0:      	movq	%rcx, 0xb0(%rsp)
     2a8:      	addl	%r11d, %r12d
     2ab:      	andl	$0x3ff, %r12d           # imm = 0x3FF
     2b2:      	movl	0x4(%rdi,%r12), %eax
     2b7:      	cmpl	$0x23, %eax
     2ba:      	je	0xb8 <generic_retuprobe_filter_arg+0xb8>
     2c0:      	addq	%rdi, %r12
     2c3:      	movl	(%r12), %ecx
     2c7:      	cmpq	$0x4, %rcx
     2cb:      	ja	0xb8 <generic_retuprobe_filter_arg+0xb8>
     2d1:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
     2da:      	jne	0xb8 <generic_retuprobe_filter_arg+0xb8>
     2e0:      	movq	0x5e78(%r14,%rcx,8), %rcx
     2e8:      	andl	$0x7ff, %ecx            # imm = 0x7FF
     2ee:      	leaq	(%r14,%rcx), %r15
     2f2:      	addq	$0x90, %r15
     2f9:      	movl	0xc(%r12), %ecx
     2fe:      	cmpl	$0x1b, %ecx
     301:      	jle	0x31e <generic_retuprobe_filter_arg+0x31e>
     303:      	cmpl	$0x25, %ecx
     306:      	jg	0x349 <generic_retuprobe_filter_arg+0x349>
     308:      	leal	-0x1c(%rcx), %edx
     30b:      	cmpl	$0x9, %edx
     30e:      	jb	0x38f <generic_retuprobe_filter_arg+0x38f>
     310:      	cmpl	$0x25, %ecx
     313:      	je	0x5a9 <generic_retuprobe_filter_arg+0x5a9>
     319:      	jmp	0x271 <generic_retuprobe_filter_arg+0x271>
     31e:      	cmpl	$0x9, %ecx
     321:      	jle	0x36f <generic_retuprobe_filter_arg+0x36f>
     323:      	leal	-0xa(%rcx), %edx
     326:      	cmpl	$0x4, %edx
     329:      	jb	0x38f <generic_retuprobe_filter_arg+0x38f>
     32b:      	leal	-0xf(%rcx), %edx
     32e:      	cmpl	$0x2, %edx
     331:      	jb	0x5a9 <generic_retuprobe_filter_arg+0x5a9>
     337:      	cmpl	$0x11, %ecx
     33a:      	jne	0x271 <generic_retuprobe_filter_arg+0x271>
     340:      	addq	$0x4, %r15
     344:      	jmp	0x5a9 <generic_retuprobe_filter_arg+0x5a9>
     349:      	cmpl	$0x29, %ecx
     34c:      	jg	0x513 <generic_retuprobe_filter_arg+0x513>
     352:      	leal	-0x26(%rcx), %edx
     355:      	cmpl	$0x2, %edx
     358:      	jb	0x4aa <generic_retuprobe_filter_arg+0x4aa>
     35e:      	leal	-0x28(%rcx), %edx
     361:      	cmpl	$0x2, %edx
     364:      	jb	0x455 <generic_retuprobe_filter_arg+0x455>
     36a:      	jmp	0x271 <generic_retuprobe_filter_arg+0x271>
     36f:      	cmpl	$0x4, %ecx
     372:      	jg	0x442 <generic_retuprobe_filter_arg+0x442>
     378:      	cmpl	$0x1, %ecx
     37b:      	je	0x38f <generic_retuprobe_filter_arg+0x38f>
     37d:      	cmpl	$0x2, %ecx
     380:      	je	0xb43 <generic_retuprobe_filter_arg+0xb43>
     386:      	cmpl	$0x4, %ecx
     389:      	jne	0x271 <generic_retuprobe_filter_arg+0x271>
     38f:      	cmpl	$0xb, %ecx
     392:      	jle	0x41f <generic_retuprobe_filter_arg+0x41f>
     398:      	cmpl	$0x24, %ecx
     39b:      	ja	0x6cc <generic_retuprobe_filter_arg+0x6cc>
     3a1:      	movl	%ecx, %edx
     3a3:      	movabsq	$0x1e00000000, %rsi     # imm = 0x1E00000000
     3ad:      	btq	%rdx, %rsi
     3b1:      	jb	0x4e7 <generic_retuprobe_filter_arg+0x4e7>
     3b7:      	movl	$0x60000000, %esi       # imm = 0x60000000
     3bc:      	btq	%rdx, %rsi
     3c0:      	jb	0x918 <generic_retuprobe_filter_arg+0x918>
     3c6:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
     3d0:      	btq	%rdx, %rsi
     3d4:      	jae	0x6cc <generic_retuprobe_filter_arg+0x6cc>
     3da:      	cmpl	$0x20, %eax
     3dd:      	ja	0xb8 <generic_retuprobe_filter_arg+0xb8>
     3e3:      	movl	%eax, %ecx
     3e5:      	movl	$0x101e, %edx           # imm = 0x101E
     3ea:      	btq	%rcx, %rdx
     3ee:      	jae	0x1001 <generic_retuprobe_filter_arg+0x1001>
     3f4:      	movl	0x10(%r12), %ecx
     3f9:      	cmpl	$0x2, %eax
     3fc:      	jle	0x15ba <generic_retuprobe_filter_arg+0x15ba>
     402:      	leal	-0x3(%rax), %edx
     405:      	cmpl	$0x2, %edx
     408:      	jae	0x1d33 <generic_retuprobe_filter_arg+0x1d33>
     40e:      	movzbl	(%r15), %edx
     412:      	cmpl	%edx, %ecx
     414:      	je	0x24f <generic_retuprobe_filter_arg+0x24f>
     41a:      	jmp	0x1e74 <generic_retuprobe_filter_arg+0x1e74>
     41f:      	leal	-0xa(%rcx), %edx
     422:      	cmpl	$0x2, %edx
     425:      	jb	0xbbf <generic_retuprobe_filter_arg+0xbbf>
     42b:      	cmpl	$0x1, %ecx
     42e:      	je	0x6d8 <generic_retuprobe_filter_arg+0x6d8>
     434:      	cmpl	$0x4, %ecx
     437:      	je	0x6d8 <generic_retuprobe_filter_arg+0x6d8>
     43d:      	jmp	0x271 <generic_retuprobe_filter_arg+0x271>
     442:      	cmpl	$0x5, %ecx
     445:      	je	0x455 <generic_retuprobe_filter_arg+0x455>
     447:      	cmpl	$0x6, %ecx
     44a:      	je	0x4aa <generic_retuprobe_filter_arg+0x4aa>
     44c:      	cmpl	$0x7, %ecx
     44f:      	jne	0x271 <generic_retuprobe_filter_arg+0x271>
     455:      	movq	$0x0, 0x58(%rsp)
     45e:      	movq	$0x0, 0x50(%rsp)
     467:      	movq	$0x0, 0x48(%rsp)
     470:      	movq	$0x0, 0x40(%rsp)
     479:      	movq	$0x0, 0x38(%rsp)
     482:      	cmpl	$0x27, %ecx
     485:      	jg	0x716 <generic_retuprobe_filter_arg+0x716>
     48b:      	cmpl	$0x5, %ecx
     48e:      	je	0xd25 <generic_retuprobe_filter_arg+0xd25>
     494:      	movq	%r15, %rdx
     497:      	movl	$0x0, %ebx
     49c:      	cmpl	$0x7, %ecx
     49f:      	je	0xd27 <generic_retuprobe_filter_arg+0xd27>
     4a5:      	jmp	0x1bc9 <generic_retuprobe_filter_arg+0x1bc9>
     4aa:      	movl	(%r15), %ebp
     4ad:      	addq	$0x4, %r15
     4b1:      	movq	%r15, 0x18(%rsp)
     4b6:      	cmpl	$0x19, %eax
     4b9:      	jg	0x79a <generic_retuprobe_filter_arg+0x79a>
     4bf:      	leal	-0x3(%rax), %ecx
     4c2:      	cmpl	$0x2, %ecx
     4c5:      	jb	0xf7d <generic_retuprobe_filter_arg+0xf7d>
     4cb:      	cmpl	$0x8, %eax
     4ce:      	je	0xee5 <generic_retuprobe_filter_arg+0xee5>
     4d4:      	movl	$0x0, %ebx
     4d9:      	cmpl	$0x9, %eax
     4dc:      	je	0x7ba <generic_retuprobe_filter_arg+0x7ba>
     4e2:      	jmp	0x3351 <generic_retuprobe_filter_arg+0x3351>
     4e7:      	cmpl	$0x9, %eax
     4ea:      	jle	0xb32 <generic_retuprobe_filter_arg+0xb32>
     4f0:      	cmpl	$0x1d, %eax
     4f3:      	jg	0xe9e <generic_retuprobe_filter_arg+0xe9e>
     4f9:      	leal	-0xa(%rax), %edx
     4fc:      	cmpl	$0x2, %edx
     4ff:      	jb	0xc4b <generic_retuprobe_filter_arg+0xc4b>
     505:      	cmpl	$0xc, %eax
     508:      	je	0xbd5 <generic_retuprobe_filter_arg+0xbd5>
     50e:      	jmp	0xb8 <generic_retuprobe_filter_arg+0xb8>
     513:      	cmpl	$0x2a, %ecx
     516:      	je	0x5a9 <generic_retuprobe_filter_arg+0x5a9>
     51c:      	cmpl	$0x2c, %ecx
     51f:      	jne	0x271 <generic_retuprobe_filter_arg+0x271>
     525:      	movq	%r15, %rcx
     528:      	leaq	0x4(%r15), %r8
     52c:      	movzbl	0x3(%r15), %ebp
     531:      	movzbl	%bpl, %esi
     535:      	cmpl	$0x19, %eax
     538:      	jg	0x12bf <generic_retuprobe_filter_arg+0x12bf>
     53e:      	leal	-0x3(%rax), %ecx
     541:      	cmpl	$0x2, %ecx
     544:      	jae	0x18b9 <generic_retuprobe_filter_arg+0x18b9>
     54a:      	movl	$0x0, 0x70(%rsp)
     552:      	movl	$0x100, %r13d           # imm = 0x100
     558:      	cmpb	$-0x70, %bpl
     55c:      	ja	0x1589 <generic_retuprobe_filter_arg+0x1589>
     562:      	testb	%bpl, %bpl
     565:      	je	0x578 <generic_retuprobe_filter_arg+0x578>
     567:      	movl	%esi, %eax
     569:      	movl	$0x18, %ecx
     56e:      	cltd
     56f:      	idivl	%ecx
     571:      	movl	%esi, %r13d
     574:      	testl	%edx, %edx
     576:      	je	0x59c <generic_retuprobe_filter_arg+0x59c>
     578:      	movl	%esi, %eax
     57a:      	movl	$0x18, %ecx
     57f:      	cltd
     580:      	idivl	%ecx
     582:      	shll	$0x3, %eax
     585:      	leal	(%rax,%rax,2), %eax
     588:      	addl	$0x18, %eax
     58b:      	movzwl	%ax, %r13d
     58f:      	cmpl	$0x90, %r13d
     596:      	ja	0x1589 <generic_retuprobe_filter_arg+0x1589>
     59c:      	movl	%r13d, %eax
     59f:      	cltd
     5a0:      	idivl	%ecx
     5a2:      	decl	%eax
     5a4:      	jmp	0x2479 <generic_retuprobe_filter_arg+0x2479>
     5a9:      	movl	(%r15), %ebp
     5ac:      	movl	%eax, %ecx
     5ae:      	andl	$-0x2, %ecx
     5b1:      	cmpl	$0x24, %ecx
     5b4:      	je	0x5be <generic_retuprobe_filter_arg+0x5be>
     5b6:      	testl	%ebp, %ebp
     5b8:      	je	0xb8 <generic_retuprobe_filter_arg+0xb8>
     5be:      	cmpl	$0x25, %eax
     5c1:      	ja	0x8f5 <generic_retuprobe_filter_arg+0x8f5>
     5c7:      	movl	%eax, %ecx
     5c9:      	movl	$0x4000100, %edx        # imm = 0x4000100
     5ce:      	btq	%rcx, %rdx
     5d2:      	jb	0xa94 <generic_retuprobe_filter_arg+0xa94>
     5d8:      	movl	$0x8000200, %edx        # imm = 0x8000200
     5dd:      	btq	%rcx, %rdx
     5e1:      	jb	0x95d <generic_retuprobe_filter_arg+0x95d>
     5e7:      	movabsq	$0x3000000000, %rdx     # imm = 0x3000000000
     5f1:      	btq	%rcx, %rdx
     5f5:      	jae	0x8f5 <generic_retuprobe_filter_arg+0x8f5>
     5fb:      	movw	$0x0, 0x38(%rsp)
     602:      	cmpl	$0x1000, %ebp           # imm = 0x1000
     608:      	ja	0x911 <generic_retuprobe_filter_arg+0x911>
     60e:      	leaq	(%r15,%rbp), %rcx
     612:      	addq	$0x8, %rcx
     616:      	movl	$0x4, %eax
     61b:      	leaq	0x38(%rsp), %rdi
     620:      	movl	$0x2, %edx
     625:      	movl	(%r15), %ecx
     628:      	leaq	(%r15,%rcx), %rdx
     62c:      	addq	$0x8, %rdx
     630:      	movl	$0x2, %esi
     635:      	callq	*%rax
     637:      	movl	0x10(%r12), %ecx
     63c:      	testl	%ecx, %ecx
     63e:      	je	0x3153 <generic_retuprobe_filter_arg+0x3153>
     644:      	movzwl	0x38(%rsp), %eax
     649:      	andl	$0xf000, %eax           # imm = 0xF000
     64e:      	movl	$0x1, %ebx
     653:      	cmpl	%eax, %ecx
     655:      	je	0x3155 <generic_retuprobe_filter_arg+0x3155>
     65b:      	movl	0x8(%r12), %ecx
     660:      	cmpl	$0xd, %ecx
     663:      	movq	(%rsp), %rdi
     667:      	movq	0x8(%rsp), %r9
     66c:      	movq	0x10(%rsp), %r11
     671:      	jb	0x911 <generic_retuprobe_filter_arg+0x911>
     677:      	movl	0x14(%r12), %edx
     67c:      	testl	%edx, %edx
     67e:      	je	0x911 <generic_retuprobe_filter_arg+0x911>
     684:      	cmpl	%eax, %edx
     686:      	je	0x3163 <generic_retuprobe_filter_arg+0x3163>
     68c:      	cmpl	$0x11, %ecx
     68f:      	jb	0x911 <generic_retuprobe_filter_arg+0x911>
     695:      	movl	0x18(%r12), %edx
     69a:      	testl	%edx, %edx
     69c:      	je	0x911 <generic_retuprobe_filter_arg+0x911>
     6a2:      	cmpl	%eax, %edx
     6a4:      	je	0x3163 <generic_retuprobe_filter_arg+0x3163>
     6aa:      	cmpl	$0x15, %ecx
     6ad:      	jb	0x3678 <generic_retuprobe_filter_arg+0x3678>
     6b3:      	movl	0x1c(%r12), %ecx
     6b8:      	testl	%ecx, %ecx
     6ba:      	je	0x3678 <generic_retuprobe_filter_arg+0x3678>
     6c0:      	xorl	%ebx, %ebx
     6c2:      	cmpl	%eax, %ecx
     6c4:      	sete	%bl
     6c7:      	jmp	0xa8a <generic_retuprobe_filter_arg+0xa8a>
     6cc:      	leal	-0xc(%rcx), %edx
     6cf:      	cmpl	$0x2, %edx
     6d2:      	jae	0xbb6 <generic_retuprobe_filter_arg+0xbb6>
     6d8:      	cmpl	$0x20, %eax
     6db:      	ja	0xb8 <generic_retuprobe_filter_arg+0xb8>
     6e1:      	movl	%eax, %edx
     6e3:      	movl	$0x101e, %esi           # imm = 0x101E
     6e8:      	btq	%rdx, %rsi
     6ec:      	jae	0x735 <generic_retuprobe_filter_arg+0x735>
     6ee:      	movl	0x10(%r12), %edx
     6f3:      	cmpl	$0x2, %eax
     6f6:      	jle	0xb7f <generic_retuprobe_filter_arg+0xb7f>
     6fc:      	leal	-0x3(%rax), %esi
     6ff:      	cmpl	$0x2, %esi
     702:      	jae	0xfea <generic_retuprobe_filter_arg+0xfea>
     708:      	cmpl	%edx, (%r15)
     70b:      	je	0x24f <generic_retuprobe_filter_arg+0x24f>
     711:      	jmp	0x21da <generic_retuprobe_filter_arg+0x21da>
     716:      	cmpl	$0x28, %ecx
     719:      	je	0xcfb <generic_retuprobe_filter_arg+0xcfb>
     71f:      	movq	%r15, %rdx
     722:      	movl	$0x0, %ebx
     727:      	cmpl	$0x29, %ecx
     72a:      	je	0xd27 <generic_retuprobe_filter_arg+0xd27>
     730:      	jmp	0x1bc9 <generic_retuprobe_filter_arg+0x1bc9>
     735:      	movl	$0xc00, %esi            # imm = 0xC00
     73a:      	btq	%rdx, %rsi
     73e:      	jb	0xcbb <generic_retuprobe_filter_arg+0xcbb>
     744:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
     74e:      	btq	%rdx, %rsi
     752:      	jae	0xb8 <generic_retuprobe_filter_arg+0xb8>
     758:      	cmpl	$0x1f, %eax
     75b:      	jne	0x128b <generic_retuprobe_filter_arg+0x128b>
     761:      	movl	0x10(%r12), %esi
     766:      	movl	0x14(%r12), %edx
     76b:      	cmpl	$0xc, %ecx
     76e:      	ja	0x1ef2 <generic_retuprobe_filter_arg+0x1ef2>
     774:      	movl	$0x1402, %eax           # imm = 0x1402
     779:      	btl	%ecx, %eax
     77c:      	jae	0x1ef2 <generic_retuprobe_filter_arg+0x1ef2>
     782:      	movl	(%r15), %eax
     785:      	cmpl	%eax, %esi
     787:      	jg	0x1f01 <generic_retuprobe_filter_arg+0x1f01>
     78d:      	cmpl	%edx, %eax
     78f:      	jle	0x271 <generic_retuprobe_filter_arg+0x271>
     795:      	jmp	0x1f01 <generic_retuprobe_filter_arg+0x1f01>
     79a:      	cmpl	$0x20, %eax
     79d:      	jg	0xdab <generic_retuprobe_filter_arg+0xdab>
     7a3:      	cmpl	$0x1a, %eax
     7a6:      	je	0xee5 <generic_retuprobe_filter_arg+0xee5>
     7ac:      	movl	$0x0, %ebx
     7b1:      	cmpl	$0x1b, %eax
     7b4:      	jne	0x3351 <generic_retuprobe_filter_arg+0x3351>
     7ba:      	movl	0x10(%r12), %eax
     7bf:      	movl	%eax, 0x38(%rsp)
     7c3:      	movl	$0x0, 0x70(%rsp)
     7cb:      	movl	$0x1, %eax
     7d0:      	leaq	0x38(%rsp), %rsi
     7d5:      	movq	(%rip), %rdi            # 0x7dc <generic_retuprobe_filter_arg+0x7dc>
     7dc:      	callq	*%rax
     7de:      	testl	%ebp, %ebp
     7e0:      	je	0x3341 <generic_retuprobe_filter_arg+0x3341>
     7e6:      	movq	%rax, %r15
     7e9:      	movl	$0x0, %ebx
     7ee:      	testq	%rax, %rax
     7f1:      	je	0x3343 <generic_retuprobe_filter_arg+0x3343>
     7f7:      	movl	$0x1, %eax
     7fc:      	movq	0x20(%rsp), %rsi
     801:      	movq	(%rip), %rdi            # 0x808 <generic_retuprobe_filter_arg+0x808>
     808:      	callq	*%rax
     80a:      	testq	%rax, %rax
     80d:      	je	0x3341 <generic_retuprobe_filter_arg+0x3341>
     813:      	movq	%rax, %rsi
     816:      	movq	%r15, 0x60(%rsp)
     81b:      	cmpl	$0x7f, %ebp
     81e:      	movl	$0x7f, %eax
     823:      	cmovbl	%ebp, %eax
     826:      	shll	$0x3, %eax
     829:      	movl	%eax, (%rsi)
     82b:      	movq	%rbp, %rax
     82e:      	negq	%rax
     831:      	movl	$0x3, %ecx
     836:      	subq	%rbp, %rcx
     839:      	leal	-0x4(%rbp), %edx
     83c:      	movq	%rsi, %rdi
     83f:      	addq	$0x7, %rdi
     843:      	movl	$0x2, %r8d
     849:      	subq	%rbp, %r8
     84c:      	leal	-0x3(%rbp), %r9d
     850:      	movl	$0x1, %r10d
     856:      	subq	%rbp, %r10
     859:      	leal	-0x2(%rbp), %r11d
     85d:      	decl	%ebp
     85f:      	xorl	%ebx, %ebx
     861:      	movq	0x18(%rsp), %r15
     866:      	leal	(%rbx,%rbp), %r13d
     86a:      	andl	$0xfff, %r13d           # imm = 0xFFF
     871:      	movzbl	(%r15,%r13), %r13d
     876:      	movb	%r13b, -0x3(%rdi)
     87a:      	cmpq	%rbx, %r10
     87d:      	je	0x8d7 <generic_retuprobe_filter_arg+0x8d7>
     87f:      	leal	(%r11,%rbx), %r13d
     883:      	andl	$0xfff, %r13d           # imm = 0xFFF
     88a:      	movzbl	(%r15,%r13), %r13d
     88f:      	movb	%r13b, -0x2(%rdi)
     893:      	cmpq	%rbx, %r8
     896:      	je	0x8d7 <generic_retuprobe_filter_arg+0x8d7>
     898:      	leal	(%r9,%rbx), %r13d
     89c:      	andl	$0xfff, %r13d           # imm = 0xFFF
     8a3:      	movzbl	(%r15,%r13), %r13d
     8a8:      	movb	%r13b, -0x1(%rdi)
     8ac:      	cmpq	%rbx, %rcx
     8af:      	je	0x8d7 <generic_retuprobe_filter_arg+0x8d7>
     8b1:      	cmpq	$-0x7c, %rbx
     8b5:      	je	0x8d7 <generic_retuprobe_filter_arg+0x8d7>
     8b7:      	leal	(%rdx,%rbx), %r13d
     8bb:      	andl	$0xfff, %r13d           # imm = 0xFFF
     8c2:      	movzbl	(%r15,%r13), %r13d
     8c7:      	movb	%r13b, (%rdi)
     8ca:      	addq	$-0x4, %rbx
     8ce:      	addq	$0x4, %rdi
     8d2:      	cmpq	%rbx, %rax
     8d5:      	jne	0x866 <generic_retuprobe_filter_arg+0x866>
     8d7:      	movl	$0x1, %eax
     8dc:      	movq	0x60(%rsp), %rdi
     8e1:      	callq	*%rax
     8e3:      	xorl	%ebx, %ebx
     8e5:      	testq	%rax, %rax
     8e8:      	setne	%bl
     8eb:      	movq	0x28(%rsp), %r13
     8f0:      	jmp	0x3343 <generic_retuprobe_filter_arg+0x3343>
     8f5:      	addl	$-0x3, %eax
     8f8:      	cmpl	$0x2, %eax
     8fb:      	jae	0x911 <generic_retuprobe_filter_arg+0x911>
     8fd:      	movl	$0x0, 0x70(%rsp)
     905:      	cmpl	$0x1000, %ebp           # imm = 0x1000
     90b:      	jbe	0x10f0 <generic_retuprobe_filter_arg+0x10f0>
     911:      	xorl	%ebx, %ebx
     913:      	jmp	0x3163 <generic_retuprobe_filter_arg+0x3163>
     918:      	cmpl	$0x20, %eax
     91b:      	ja	0xb8 <generic_retuprobe_filter_arg+0xb8>
     921:      	movl	%eax, %ecx
     923:      	movl	$0x101e, %edx           # imm = 0x101E
     928:      	btq	%rcx, %rdx
     92c:      	jae	0x1033 <generic_retuprobe_filter_arg+0x1033>
     932:      	movl	0x10(%r12), %ecx
     937:      	cmpl	$0x2, %eax
     93a:      	jle	0x15dd <generic_retuprobe_filter_arg+0x15dd>
     940:      	leal	-0x3(%rax), %edx
     943:      	cmpl	$0x2, %edx
     946:      	jae	0x1d4d <generic_retuprobe_filter_arg+0x1d4d>
     94c:      	movzwl	(%r15), %edx
     950:      	cmpl	%edx, %ecx
     952:      	je	0x24f <generic_retuprobe_filter_arg+0x24f>
     958:      	jmp	0x1eb9 <generic_retuprobe_filter_arg+0x1eb9>
     95d:      	movl	0x10(%r12), %eax
     962:      	movl	%eax, 0x38(%rsp)
     966:      	movl	$0x0, 0x70(%rsp)
     96e:      	movl	$0x1, %eax
     973:      	leaq	0x38(%rsp), %rsi
     978:      	movq	(%rip), %rdi            # 0x97f <generic_retuprobe_filter_arg+0x97f>
     97f:      	callq	*%rax
     981:      	testl	%ebp, %ebp
     983:      	je	0x3153 <generic_retuprobe_filter_arg+0x3153>
     989:      	movl	$0x0, %ebx
     98e:      	testq	%rax, %rax
     991:      	je	0x3155 <generic_retuprobe_filter_arg+0x3155>
     997:      	movq	%rax, 0x18(%rsp)
     99c:      	movl	$0x1, %eax
     9a1:      	movq	0x20(%rsp), %rsi
     9a6:      	movq	(%rip), %rdi            # 0x9ad <generic_retuprobe_filter_arg+0x9ad>
     9ad:      	callq	*%rax
     9af:      	testq	%rax, %rax
     9b2:      	je	0x3153 <generic_retuprobe_filter_arg+0x3153>
     9b8:      	movq	%rax, %rsi
     9bb:      	cmpl	$0x7f, %ebp
     9be:      	movl	$0x7f, %eax
     9c3:      	cmovbl	%ebp, %eax
     9c6:      	shll	$0x3, %eax
     9c9:      	movl	%eax, (%rsi)
     9cb:      	movq	%rbp, %rax
     9ce:      	negq	%rax
     9d1:      	movl	$0x3, %ecx
     9d6:      	subq	%rbp, %rcx
     9d9:      	leal	-0x4(%rbp), %edx
     9dc:      	movq	%rsi, %rdi
     9df:      	addq	$0x7, %rdi
     9e3:      	movl	$0x2, %r8d
     9e9:      	subq	%rbp, %r8
     9ec:      	leal	-0x3(%rbp), %r9d
     9f0:      	movl	$0x1, %r10d
     9f6:      	subq	%rbp, %r10
     9f9:      	leal	-0x2(%rbp), %r11d
     9fd:      	decl	%ebp
     9ff:      	xorl	%ebx, %ebx
     a01:      	leal	(%rbx,%rbp), %r13d
     a05:      	andl	$0xfff, %r13d           # imm = 0xFFF
     a0c:      	movzbl	0x4(%r15,%r13), %r13d
     a12:      	movb	%r13b, -0x3(%rdi)
     a16:      	cmpq	%rbx, %r10
     a19:      	je	0xa76 <generic_retuprobe_filter_arg+0xa76>
     a1b:      	leal	(%r11,%rbx), %r13d
     a1f:      	andl	$0xfff, %r13d           # imm = 0xFFF
     a26:      	movzbl	0x4(%r15,%r13), %r13d
     a2c:      	movb	%r13b, -0x2(%rdi)
     a30:      	cmpq	%rbx, %r8
     a33:      	je	0xa76 <generic_retuprobe_filter_arg+0xa76>
     a35:      	leal	(%r9,%rbx), %r13d
     a39:      	andl	$0xfff, %r13d           # imm = 0xFFF
     a40:      	movzbl	0x4(%r15,%r13), %r13d
     a46:      	movb	%r13b, -0x1(%rdi)
     a4a:      	cmpq	%rbx, %rcx
     a4d:      	je	0xa76 <generic_retuprobe_filter_arg+0xa76>
     a4f:      	cmpq	$-0x7c, %rbx
     a53:      	je	0xa76 <generic_retuprobe_filter_arg+0xa76>
     a55:      	leal	(%rdx,%rbx), %r13d
     a59:      	andl	$0xfff, %r13d           # imm = 0xFFF
     a60:      	movzbl	0x4(%r15,%r13), %r13d
     a66:      	movb	%r13b, (%rdi)
     a69:      	addq	$-0x4, %rbx
     a6d:      	addq	$0x4, %rdi
     a71:      	cmpq	%rbx, %rax
     a74:      	jne	0xa01 <generic_retuprobe_filter_arg+0xa01>
     a76:      	movl	$0x1, %eax
     a7b:      	movq	0x18(%rsp), %rdi
     a80:      	callq	*%rax
     a82:      	xorl	%ebx, %ebx
     a84:      	testq	%rax, %rax
     a87:      	setne	%bl
     a8a:      	movq	0x28(%rsp), %r13
     a8f:      	jmp	0x3155 <generic_retuprobe_filter_arg+0x3155>
     a94:      	movl	0x10(%r12), %eax
     a99:      	movl	%eax, 0x38(%rsp)
     a9d:      	movl	$0x0, 0x70(%rsp)
     aa5:      	movl	$0x1, %eax
     aaa:      	leaq	0x38(%rsp), %rsi
     aaf:      	movq	(%rip), %rdi            # 0xab6 <generic_retuprobe_filter_arg+0xab6>
     ab6:      	callq	*%rax
     ab8:      	testl	%ebp, %ebp
     aba:      	je	0x3153 <generic_retuprobe_filter_arg+0x3153>
     ac0:      	movl	$0x0, %ebx
     ac5:      	testq	%rax, %rax
     ac8:      	je	0x3155 <generic_retuprobe_filter_arg+0x3155>
     ace:      	movq	%rax, 0x18(%rsp)
     ad3:      	movl	$0x1, %eax
     ad8:      	movq	0x20(%rsp), %rsi
     add:      	movq	(%rip), %rdi            # 0xae4 <generic_retuprobe_filter_arg+0xae4>
     ae4:      	callq	*%rax
     ae6:      	testq	%rax, %rax
     ae9:      	je	0x3153 <generic_retuprobe_filter_arg+0x3153>
     aef:      	movq	%rax, %rbx
     af2:      	addq	$0x4, %r15
     af6:      	cmpl	$0xff, %ebp
     afc:      	movl	$0xff, %eax
     b01:      	cmovael	%eax, %ebp
     b04:      	leal	(,%rbp,8), %eax
     b0b:      	movl	%eax, (%rbx)
     b0d:      	movq	%rbx, %rdi
     b10:      	addq	$0x4, %rdi
     b14:      	movl	$0x4, %eax
     b19:      	movl	%ebp, %esi
     b1b:      	movq	%r15, %rdx
     b1e:      	callq	*%rax
     b20:      	movl	$0x1, %eax
     b25:      	movq	0x18(%rsp), %rdi
     b2a:      	movq	%rbx, %rsi
     b2d:      	jmp	0x3147 <generic_retuprobe_filter_arg+0x3147>
     b32:      	leal	-0x1(%rax), %edx
     b35:      	cmpl	$0x4, %edx
     b38:      	jb	0xbd5 <generic_retuprobe_filter_arg+0xbd5>
     b3e:      	jmp	0xb8 <generic_retuprobe_filter_arg+0xb8>
     b43:      	movq	%r15, %r13
     b46:      	movl	0x4(%r15), %ebp
     b4a:      	addq	$0x8, %r13
     b4e:      	cmpl	$0x19, %eax
     b51:      	jg	0x1141 <generic_retuprobe_filter_arg+0x1141>
     b57:      	leal	-0x3(%rax), %ecx
     b5a:      	cmpl	$0x2, %ecx
     b5d:      	jb	0x1a8b <generic_retuprobe_filter_arg+0x1a8b>
     b63:      	cmpl	$0x8, %eax
     b66:      	je	0x19f5 <generic_retuprobe_filter_arg+0x19f5>
     b6c:      	movl	$0x0, %ebx
     b71:      	cmpl	$0x9, %eax
     b74:      	je	0x1161 <generic_retuprobe_filter_arg+0x1161>
     b7a:      	jmp	0x3640 <generic_retuprobe_filter_arg+0x3640>
     b7f:      	cmpl	$0x1, %eax
     b82:      	je	0x1414 <generic_retuprobe_filter_arg+0x1414>
     b88:      	cmpl	$0x2, %eax
     b8b:      	jne	0x21da <generic_retuprobe_filter_arg+0x21da>
     b91:      	cmpl	$0xc, %ecx
     b94:      	ja	0x21d1 <generic_retuprobe_filter_arg+0x21d1>
     b9a:      	movl	$0x1402, %esi           # imm = 0x1402
     b9f:      	btl	%ecx, %esi
     ba2:      	jae	0x21d1 <generic_retuprobe_filter_arg+0x21d1>
     ba8:      	cmpl	%edx, (%r15)
     bab:      	jl	0x271 <generic_retuprobe_filter_arg+0x271>
     bb1:      	jmp	0x21da <generic_retuprobe_filter_arg+0x21da>
     bb6:      	cmpl	$0x1c, %ecx
     bb9:      	jne	0x271 <generic_retuprobe_filter_arg+0x271>
     bbf:      	cmpl	$0x20, %eax
     bc2:      	ja	0xb8 <generic_retuprobe_filter_arg+0xb8>
     bc8:      	movl	%eax, %edx
     bca:      	movl	$0x101e, %esi           # imm = 0x101E
     bcf:      	btq	%rdx, %rsi
     bd3:      	jae	0xbf9 <generic_retuprobe_filter_arg+0xbf9>
     bd5:      	movq	0x10(%r12), %rdx
     bda:      	cmpl	$0x2, %eax
     bdd:      	jle	0xc1d <generic_retuprobe_filter_arg+0xc1d>
     bdf:      	leal	-0x3(%rax), %esi
     be2:      	cmpl	$0x2, %esi
     be5:      	jae	0xe87 <generic_retuprobe_filter_arg+0xe87>
     beb:      	cmpq	%rdx, (%r15)
     bee:      	je	0x24f <generic_retuprobe_filter_arg+0x24f>
     bf4:      	jmp	0x1cb8 <generic_retuprobe_filter_arg+0x1cb8>
     bf9:      	movl	$0xc00, %esi            # imm = 0xC00
     bfe:      	btq	%rdx, %rsi
     c02:      	jb	0xc4b <generic_retuprobe_filter_arg+0xc4b>
     c04:      	movabsq	$0x180000000, %rsi      # imm = 0x180000000
     c0e:      	btq	%rdx, %rsi
     c12:      	jb	0xeaa <generic_retuprobe_filter_arg+0xeaa>
     c18:      	jmp	0xb8 <generic_retuprobe_filter_arg+0xb8>
     c1d:      	cmpl	$0x1, %eax
     c20:      	je	0x10d4 <generic_retuprobe_filter_arg+0x10d4>
     c26:      	cmpl	$0x2, %eax
     c29:      	jne	0x1cb8 <generic_retuprobe_filter_arg+0x1cb8>
     c2f:      	cmpl	$0xc, %ecx
     c32:      	je	0xc3d <generic_retuprobe_filter_arg+0xc3d>
     c34:      	cmpl	$0xa, %ecx
     c37:      	jne	0x1caf <generic_retuprobe_filter_arg+0x1caf>
     c3d:      	cmpq	%rdx, (%r15)
     c40:      	jl	0x271 <generic_retuprobe_filter_arg+0x271>
     c46:      	jmp	0x1cb8 <generic_retuprobe_filter_arg+0x1cb8>
     c4b:      	movzbl	0x10(%r12), %eax
     c51:      	movl	%eax, 0x70(%rsp)
     c55:      	movl	$0x1, %eax
     c5a:      	movq	0x20(%rsp), %rsi
     c5f:      	movq	(%rip), %rdi            # 0xc66 <generic_retuprobe_filter_arg+0xc66>
     c66:      	callq	*%rax
     c68:      	testq	%rax, %rax
     c6b:      	je	0x19c8 <generic_retuprobe_filter_arg+0x19c8>
     c71:      	movq	%rax, %rdi
     c74:      	movq	(%r15), %rax
     c77:      	movq	%rax, 0x38(%rsp)
     c7c:      	movl	$0x1, %eax
     c81:      	leaq	0x38(%rsp), %rsi
     c86:      	callq	*%rax
     c88:      	movl	0x4(%r12), %ecx
     c8d:      	cmpl	$0xb, %ecx
     c90:      	je	0x16b2 <generic_retuprobe_filter_arg+0x16b2>
     c96:      	cmpl	$0xa, %ecx
     c99:      	movq	(%rsp), %rdi
     c9d:      	movq	0x8(%rsp), %r9
     ca2:      	movq	0x10(%rsp), %r11
     ca7:      	jne	0x16ce <generic_retuprobe_filter_arg+0x16ce>
     cad:      	testq	%rax, %rax
     cb0:      	setne	%al
     cb3:      	movzbl	%al, %ebx
     cb6:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
     cbb:      	movzbl	0x10(%r12), %eax
     cc1:      	movl	%eax, 0x70(%rsp)
     cc5:      	movl	$0x1, %eax
     cca:      	movq	0x20(%rsp), %rsi
     ccf:      	movq	(%rip), %rdi            # 0xcd6 <generic_retuprobe_filter_arg+0xcd6>
     cd6:      	callq	*%rax
     cd8:      	testq	%rax, %rax
     cdb:      	je	0x19c8 <generic_retuprobe_filter_arg+0x19c8>
     ce1:      	movq	%rax, %rdi
     ce4:      	movl	(%r15), %eax
     ce7:      	movq	%rax, 0x38(%rsp)
     cec:      	movl	$0x1, %eax
     cf1:      	leaq	0x38(%rsp), %rsi
     cf6:      	jmp	0x1996 <generic_retuprobe_filter_arg+0x1996>
     cfb:      	movzwl	(%r15), %edx
     cff:      	movw	%dx, 0x5e(%rsp)
     d04:      	movzwl	0x2(%r15), %edx
     d09:      	movw	%dx, 0x58(%rsp)
     d0e:      	movq	0x8(%r15), %rdx
     d12:      	movq	%rdx, 0x38(%rsp)
     d17:      	movq	0x10(%r15), %rdx
     d1b:      	movq	%rdx, 0x40(%rsp)
     d20:      	leaq	0x38(%rsp), %r15
     d25:      	xorl	%edx, %edx
     d27:      	cmpl	$0x13, %eax
     d2a:      	jle	0xd53 <generic_retuprobe_filter_arg+0xd53>
     d2c:      	cmpl	$0x17, %eax
     d2f:      	jg	0xd86 <generic_retuprobe_filter_arg+0xd86>
     d31:      	leal	-0x14(%rax), %ecx
     d34:      	cmpl	$0x2, %ecx
     d37:      	jb	0x12fb <generic_retuprobe_filter_arg+0x12fb>
     d3d:      	leal	-0x16(%rax), %ecx
     d40:      	movl	$0x0, %ebx
     d45:      	cmpl	$0x2, %ecx
     d48:      	jb	0x12f1 <generic_retuprobe_filter_arg+0x12f1>
     d4e:      	jmp	0x1bc9 <generic_retuprobe_filter_arg+0x1bc9>
     d53:      	cmpl	$0xf, %eax
     d56:      	jle	0xf98 <generic_retuprobe_filter_arg+0xf98>
     d5c:      	cmpl	$0x11, %eax
     d5f:      	jg	0x12de <generic_retuprobe_filter_arg+0x12de>
     d65:      	cmpl	$0x10, %eax
     d68:      	je	0x12f1 <generic_retuprobe_filter_arg+0x12f1>
     d6e:      	movl	$0x0, %ebx
     d73:      	cmpl	$0x11, %eax
     d76:      	jne	0x1bc9 <generic_retuprobe_filter_arg+0x1bc9>
     d7c:      	movzwl	0x24(%r15), %ebx
     d81:      	jmp	0x1b49 <generic_retuprobe_filter_arg+0x1b49>
     d86:      	cmpl	$0x1b, %eax
     d89:      	jg	0x1337 <generic_retuprobe_filter_arg+0x1337>
     d8f:      	cmpl	$0x18, %eax
     d92:      	je	0x1374 <generic_retuprobe_filter_arg+0x1374>
     d98:      	movl	$0x0, %ebx
     d9d:      	cmpl	$0x19, %eax
     da0:      	je	0x1367 <generic_retuprobe_filter_arg+0x1367>
     da6:      	jmp	0x1bc9 <generic_retuprobe_filter_arg+0x1bc9>
     dab:      	cmpl	$0x21, %eax
     dae:      	je	0x1439 <generic_retuprobe_filter_arg+0x1439>
     db4:      	movl	$0x0, %ebx
     db9:      	cmpl	$0x22, %eax
     dbc:      	jne	0x3351 <generic_retuprobe_filter_arg+0x3351>
     dc2:      	xorl	%ebx, %ebx
     dc4:      	xorl	%r13d, %r13d
     dc7:      	movl	0x10(%r12,%rbx,4), %eax
     dcc:      	movl	%eax, 0x38(%rsp)
     dd0:      	movl	$0x1, %eax
     dd5:      	leaq	0x38(%rsp), %rsi
     dda:      	movq	(%rip), %rdi            # 0xde1 <generic_retuprobe_filter_arg+0xde1>
     de1:      	callq	*%rax
     de3:      	testq	%rax, %rax
     de6:      	je	0x216c <generic_retuprobe_filter_arg+0x216c>
     dec:      	testl	%ebp, %ebp
     dee:      	movq	0x10(%rsp), %r11
     df3:      	je	0xe64 <generic_retuprobe_filter_arg+0xe64>
     df5:      	movq	0x18(%rsp), %rdx
     dfa:      	xorl	%ecx, %ecx
     dfc:      	jmp	0xe09 <generic_retuprobe_filter_arg+0xe09>
     dfe:      	incq	%rcx
     e01:      	incq	%rdx
     e04:      	cmpq	%rbp, %rcx
     e07:      	je	0xe64 <generic_retuprobe_filter_arg+0xe64>
     e09:      	xorl	%esi, %esi
     e0b:      	nopl	(%rax,%rax)
     e10:      	leaq	(%rcx,%rsi), %rdi
     e14:      	cmpq	%rbp, %rdi
     e17:      	jae	0xdfe <generic_retuprobe_filter_arg+0xdfe>
     e19:      	movsbl	(%rax,%rsi), %edi
     e1d:      	testl	%edi, %edi
     e1f:      	je	0xe5c <generic_retuprobe_filter_arg+0xe5c>
     e21:      	movsbl	(%rdx,%rsi), %r9d
     e26:      	leal	-0x41(%r9), %r10d
     e2a:      	movl	%r9d, %r8d
     e2d:      	orl	$0x20, %r8d
     e31:      	cmpl	$0x1a, %r10d
     e35:      	cmovael	%r9d, %r8d
     e39:      	leal	-0x41(%rdi), %r10d
     e3d:      	movl	%edi, %r9d
     e40:      	orl	$0x20, %r9d
     e44:      	cmpl	$0x1a, %r10d
     e48:      	cmovael	%edi, %r9d
     e4c:      	cmpq	$0x62, %rsi
     e50:      	ja	0xdfe <generic_retuprobe_filter_arg+0xdfe>
     e52:      	incq	%rsi
     e55:      	cmpl	%r9d, %r8d
     e58:      	je	0xe10 <generic_retuprobe_filter_arg+0xe10>
     e5a:      	jmp	0xdfe <generic_retuprobe_filter_arg+0xdfe>
     e5c:      	testl	%ecx, %ecx
     e5e:      	jns	0x261e <generic_retuprobe_filter_arg+0x261e>
     e64:      	leal	0xc(%r13), %eax
     e68:      	cmpl	0x8(%r12), %eax
     e6d:      	jae	0xe80 <generic_retuprobe_filter_arg+0xe80>
     e6f:      	addl	$0x4, %r13d
     e73:      	incq	%rbx
     e76:      	cmpq	$0x64, %rbx
     e7a:      	jne	0xdc7 <generic_retuprobe_filter_arg+0xdc7>
     e80:      	xorl	%ebx, %ebx
     e82:      	jmp	0x2623 <generic_retuprobe_filter_arg+0x2623>
     e87:      	cmpl	$0xc, %eax
     e8a:      	jne	0x1cb8 <generic_retuprobe_filter_arg+0x1cb8>
     e90:      	testq	%rdx, (%r15)
     e93:      	jne	0x271 <generic_retuprobe_filter_arg+0x271>
     e99:      	jmp	0x1cb8 <generic_retuprobe_filter_arg+0x1cb8>
     e9e:      	leal	-0x1f(%rax), %edx
     ea1:      	cmpl	$0x2, %edx
     ea4:      	jae	0x17e1 <generic_retuprobe_filter_arg+0x17e1>
     eaa:      	cmpl	$0x1f, %eax
     ead:      	jne	0xfbd <generic_retuprobe_filter_arg+0xfbd>
     eb3:      	movq	0x10(%r12), %rsi
     eb8:      	movq	0x18(%r12), %rdx
     ebd:      	cmpl	$0xa, %ecx
     ec0:      	je	0xecb <generic_retuprobe_filter_arg+0xecb>
     ec2:      	cmpl	$0xc, %ecx
     ec5:      	jne	0x1aa6 <generic_retuprobe_filter_arg+0x1aa6>
     ecb:      	movq	(%r15), %rax
     ece:      	cmpq	%rax, %rsi
     ed1:      	jg	0x1ab7 <generic_retuprobe_filter_arg+0x1ab7>
     ed7:      	cmpq	%rdx, %rax
     eda:      	jle	0x271 <generic_retuprobe_filter_arg+0x271>
     ee0:      	jmp	0x1ab7 <generic_retuprobe_filter_arg+0x1ab7>
     ee5:      	movl	0x10(%r12), %eax
     eea:      	movl	%eax, 0x38(%rsp)
     eee:      	movl	$0x0, 0x70(%rsp)
     ef6:      	movl	$0x1, %eax
     efb:      	leaq	0x38(%rsp), %rsi
     f00:      	movq	(%rip), %rdi            # 0xf07 <generic_retuprobe_filter_arg+0xf07>
     f07:      	callq	*%rax
     f09:      	testl	%ebp, %ebp
     f0b:      	je	0x3341 <generic_retuprobe_filter_arg+0x3341>
     f11:      	movq	%rax, %r15
     f14:      	movl	$0x0, %ebx
     f19:      	testq	%rax, %rax
     f1c:      	je	0x3343 <generic_retuprobe_filter_arg+0x3343>
     f22:      	movl	$0x1, %eax
     f27:      	movq	0x20(%rsp), %rsi
     f2c:      	movq	(%rip), %rdi            # 0xf33 <generic_retuprobe_filter_arg+0xf33>
     f33:      	callq	*%rax
     f35:      	testq	%rax, %rax
     f38:      	je	0x3341 <generic_retuprobe_filter_arg+0x3341>
     f3e:      	cmpl	$0xff, %ebp
     f44:      	movl	$0xff, %ecx
     f49:      	cmovael	%ecx, %ebp
     f4c:      	leal	(,%rbp,8), %ecx
     f53:      	movl	%ecx, (%rax)
     f55:      	movq	%rax, %rdi
     f58:      	addq	$0x4, %rdi
     f5c:      	movq	%rax, %rbx
     f5f:      	movl	$0x4, %eax
     f64:      	movq	0x18(%rsp), %rdx
     f69:      	movl	%ebp, %esi
     f6b:      	callq	*%rax
     f6d:      	movl	$0x1, %eax
     f72:      	movq	%r15, %rdi
     f75:      	movq	%rbx, %rsi
     f78:      	jmp	0x3335 <generic_retuprobe_filter_arg+0x3335>
     f7d:      	movl	$0x0, 0x70(%rsp)
     f85:      	cmpl	$0x1000, %ebp           # imm = 0x1000
     f8b:      	jbe	0x14eb <generic_retuprobe_filter_arg+0x14eb>
     f91:      	xorl	%ebx, %ebx
     f93:      	jmp	0x3351 <generic_retuprobe_filter_arg+0x3351>
     f98:      	cmpl	$0xd, %eax
     f9b:      	je	0x1374 <generic_retuprobe_filter_arg+0x1374>
     fa1:      	cmpl	$0xe, %eax
     fa4:      	je	0x1367 <generic_retuprobe_filter_arg+0x1367>
     faa:      	movl	$0x0, %ebx
     faf:      	cmpl	$0xf, %eax
     fb2:      	je	0x12fb <generic_retuprobe_filter_arg+0x12fb>
     fb8:      	jmp	0x1bc9 <generic_retuprobe_filter_arg+0x1bc9>
     fbd:      	movq	0x10(%r12), %rsi
     fc2:      	movq	0x18(%r12), %rax
     fc7:      	cmpl	$0xc, %ecx
     fca:      	je	0xfd5 <generic_retuprobe_filter_arg+0xfd5>
     fcc:      	cmpl	$0xa, %ecx
     fcf:      	jne	0x1af8 <generic_retuprobe_filter_arg+0x1af8>
     fd5:      	movq	(%r15), %rdx
     fd8:      	cmpq	%rdx, %rsi
     fdb:      	setle	%sil
     fdf:      	cmpq	%rax, %rdx
     fe2:      	setle	%al
     fe5:      	jmp	0x1b08 <generic_retuprobe_filter_arg+0x1b08>
     fea:      	cmpl	$0xc, %eax
     fed:      	jne	0x21da <generic_retuprobe_filter_arg+0x21da>
     ff3:      	testl	%edx, (%r15)
     ff6:      	jne	0x271 <generic_retuprobe_filter_arg+0x271>
     ffc:      	jmp	0x21da <generic_retuprobe_filter_arg+0x21da>
    1001:      	movl	$0xc00, %edx            # imm = 0xC00
    1006:      	btq	%rcx, %rdx
    100a:      	jb	0x1600 <generic_retuprobe_filter_arg+0x1600>
    1010:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    101a:      	btq	%rcx, %rdx
    101e:      	jae	0xb8 <generic_retuprobe_filter_arg+0xb8>
    1024:      	cmpl	$0x1f, %eax
    1027:      	jne	0x1d9f <generic_retuprobe_filter_arg+0x1d9f>
    102d:      	movzbl	(%r15), %eax
    1031:      	jmp	0x1063 <generic_retuprobe_filter_arg+0x1063>
    1033:      	movl	$0xc00, %edx            # imm = 0xC00
    1038:      	btq	%rcx, %rdx
    103c:      	jb	0x1641 <generic_retuprobe_filter_arg+0x1641>
    1042:      	movabsq	$0x180000000, %rdx      # imm = 0x180000000
    104c:      	btq	%rcx, %rdx
    1050:      	jae	0xb8 <generic_retuprobe_filter_arg+0xb8>
    1056:      	cmpl	$0x1f, %eax
    1059:      	jne	0x1daa <generic_retuprobe_filter_arg+0x1daa>
    105f:      	movzwl	(%r15), %eax
    1063:      	cmpl	%eax, 0x10(%r12)
    1068:      	ja	0x1075 <generic_retuprobe_filter_arg+0x1075>
    106a:      	cmpl	%eax, 0x14(%r12)
    106f:      	jae	0x271 <generic_retuprobe_filter_arg+0x271>
    1075:      	movl	0x8(%r12), %ecx
    107a:      	cmpl	$0x11, %ecx
    107d:      	jb	0xb8 <generic_retuprobe_filter_arg+0xb8>
    1083:      	cmpl	%eax, 0x18(%r12)
    1088:      	ja	0x1095 <generic_retuprobe_filter_arg+0x1095>
    108a:      	cmpl	%eax, 0x1c(%r12)
    108f:      	jae	0x271 <generic_retuprobe_filter_arg+0x271>
    1095:      	cmpl	$0x19, %ecx
    1098:      	jb	0xb8 <generic_retuprobe_filter_arg+0xb8>
    109e:      	cmpl	%eax, 0x20(%r12)
    10a3:      	ja	0x10b0 <generic_retuprobe_filter_arg+0x10b0>
    10a5:      	cmpl	%eax, 0x24(%r12)
    10aa:      	jae	0x271 <generic_retuprobe_filter_arg+0x271>
    10b0:      	cmpl	$0x21, %ecx
    10b3:      	jb	0xb8 <generic_retuprobe_filter_arg+0xb8>
    10b9:      	cmpl	%eax, 0x28(%r12)
    10be:      	ja	0xb8 <generic_retuprobe_filter_arg+0xb8>
    10c4:      	cmpl	%eax, 0x2c(%r12)
    10c9:      	jae	0x271 <generic_retuprobe_filter_arg+0x271>
    10cf:      	jmp	0xb8 <generic_retuprobe_filter_arg+0xb8>
    10d4:      	cmpl	$0xc, %ecx
    10d7:      	je	0x10e2 <generic_retuprobe_filter_arg+0x10e2>
    10d9:      	cmpl	$0xa, %ecx
    10dc:      	jne	0x1ca4 <generic_retuprobe_filter_arg+0x1ca4>
    10e2:      	cmpq	%rdx, (%r15)
    10e5:      	jg	0x271 <generic_retuprobe_filter_arg+0x271>
    10eb:      	jmp	0x1cb8 <generic_retuprobe_filter_arg+0x1cb8>
    10f0:      	movzwl	%bp, %eax
    10f3:      	cmpl	$0x90, %eax
    10f8:      	ja	0x16d8 <generic_retuprobe_filter_arg+0x16d8>
    10fe:      	testw	%bp, %bp
    1101:      	je	0x1113 <generic_retuprobe_filter_arg+0x1113>
    1103:      	movl	%ebp, %eax
    1105:      	movl	$0x18, %ecx
    110a:      	cltd
    110b:      	idivl	%ecx
    110d:      	movl	%ebp, %esi
    110f:      	testl	%edx, %edx
    1111:      	je	0x1135 <generic_retuprobe_filter_arg+0x1135>
    1113:      	movl	%ebp, %eax
    1115:      	movl	$0x18, %ecx
    111a:      	cltd
    111b:      	idivl	%ecx
    111d:      	shll	$0x3, %eax
    1120:      	leal	(%rax,%rax,2), %eax
    1123:      	addl	$0x18, %eax
    1126:      	movzwl	%ax, %esi
    1129:      	cmpl	$0x90, %esi
    112f:      	ja	0x1710 <generic_retuprobe_filter_arg+0x1710>
    1135:      	movl	%esi, %eax
    1137:      	cltd
    1138:      	idivl	%ecx
    113a:      	decl	%eax
    113c:      	jmp	0x22dc <generic_retuprobe_filter_arg+0x22dc>
    1141:      	cmpl	$0x20, %eax
    1144:      	jg	0x1827 <generic_retuprobe_filter_arg+0x1827>
    114a:      	cmpl	$0x1a, %eax
    114d:      	je	0x19f5 <generic_retuprobe_filter_arg+0x19f5>
    1153:      	movl	$0x0, %ebx
    1158:      	cmpl	$0x1b, %eax
    115b:      	jne	0x3640 <generic_retuprobe_filter_arg+0x3640>
    1161:      	movl	0x10(%r12), %eax
    1166:      	movl	%eax, 0x38(%rsp)
    116a:      	movl	$0x0, 0x70(%rsp)
    1172:      	movl	$0x1, %eax
    1177:      	leaq	0x38(%rsp), %rsi
    117c:      	movq	(%rip), %rdi            # 0x1183 <generic_retuprobe_filter_arg+0x1183>
    1183:      	callq	*%rax
    1185:      	testl	%ebp, %ebp
    1187:      	je	0x3630 <generic_retuprobe_filter_arg+0x3630>
    118d:      	movq	%rax, %r15
    1190:      	movl	$0x0, %ebx
    1195:      	testq	%rax, %rax
    1198:      	je	0x3632 <generic_retuprobe_filter_arg+0x3632>
    119e:      	movl	$0x1, %eax
    11a3:      	movq	0x20(%rsp), %rsi
    11a8:      	movq	(%rip), %rdi            # 0x11af <generic_retuprobe_filter_arg+0x11af>
    11af:      	callq	*%rax
    11b1:      	testq	%rax, %rax
    11b4:      	je	0x3630 <generic_retuprobe_filter_arg+0x3630>
    11ba:      	movq	%rax, %rsi
    11bd:      	movq	%r15, 0x18(%rsp)
    11c2:      	cmpl	$0x7f, %ebp
    11c5:      	movl	$0x7f, %eax
    11ca:      	cmovbl	%ebp, %eax
    11cd:      	shll	$0x3, %eax
    11d0:      	movl	%eax, (%rsi)
    11d2:      	movq	%rbp, %rax
    11d5:      	negq	%rax
    11d8:      	movl	$0x3, %ecx
    11dd:      	subq	%rbp, %rcx
    11e0:      	leal	-0x4(%rbp), %edx
    11e3:      	movq	%rsi, %rdi
    11e6:      	addq	$0x7, %rdi
    11ea:      	movl	$0x2, %r8d
    11f0:      	subq	%rbp, %r8
    11f3:      	leal	-0x3(%rbp), %r9d
    11f7:      	movl	$0x1, %r10d
    11fd:      	subq	%rbp, %r10
    1200:      	leal	-0x2(%rbp), %r11d
    1204:      	decl	%ebp
    1206:      	xorl	%ebx, %ebx
    1208:      	movq	%r13, %r15
    120b:      	leal	(%rbx,%rbp), %r13d
    120f:      	andl	$0xfff, %r13d           # imm = 0xFFF
    1216:      	movzbl	(%r15,%r13), %r13d
    121b:      	movb	%r13b, -0x3(%rdi)
    121f:      	cmpq	%rbx, %r10
    1222:      	je	0x127c <generic_retuprobe_filter_arg+0x127c>
    1224:      	leal	(%r11,%rbx), %r13d
    1228:      	andl	$0xfff, %r13d           # imm = 0xFFF
    122f:      	movzbl	(%r15,%r13), %r13d
    1234:      	movb	%r13b, -0x2(%rdi)
    1238:      	cmpq	%rbx, %r8
    123b:      	je	0x127c <generic_retuprobe_filter_arg+0x127c>
    123d:      	leal	(%r9,%rbx), %r13d
    1241:      	andl	$0xfff, %r13d           # imm = 0xFFF
    1248:      	movzbl	(%r15,%r13), %r13d
    124d:      	movb	%r13b, -0x1(%rdi)
    1251:      	cmpq	%rbx, %rcx
    1254:      	je	0x127c <generic_retuprobe_filter_arg+0x127c>
    1256:      	cmpq	$-0x7c, %rbx
    125a:      	je	0x127c <generic_retuprobe_filter_arg+0x127c>
    125c:      	leal	(%rdx,%rbx), %r13d
    1260:      	andl	$0xfff, %r13d           # imm = 0xFFF
    1267:      	movzbl	(%r15,%r13), %r13d
    126c:      	movb	%r13b, (%rdi)
    126f:      	addq	$-0x4, %rbx
    1273:      	addq	$0x4, %rdi
    1277:      	cmpq	%rbx, %rax
    127a:      	jne	0x120b <generic_retuprobe_filter_arg+0x120b>
    127c:      	movl	$0x1, %eax
    1281:      	movq	0x18(%rsp), %rdi
    1286:      	jmp	0x3624 <generic_retuprobe_filter_arg+0x3624>
    128b:      	movl	0x10(%r12), %esi
    1290:      	movl	0x14(%r12), %eax
    1295:      	cmpl	$0xc, %ecx
    1298:      	ja	0x1f4b <generic_retuprobe_filter_arg+0x1f4b>
    129e:      	movl	$0x1402, %edx           # imm = 0x1402
    12a3:      	btl	%ecx, %edx
    12a6:      	jae	0x1f4b <generic_retuprobe_filter_arg+0x1f4b>
    12ac:      	movl	(%r15), %edx
    12af:      	cmpl	%edx, %esi
    12b1:      	setle	%sil
    12b5:      	cmpl	%eax, %edx
    12b7:      	setle	%al
    12ba:      	jmp	0x1f59 <generic_retuprobe_filter_arg+0x1f59>
    12bf:      	cmpl	$0x1c, %eax
    12c2:      	je	0x195e <generic_retuprobe_filter_arg+0x195e>
    12c8:      	movq	%r8, 0x18(%rsp)
    12cd:      	movq	%rsi, %r15
    12d0:      	cmpl	$0x1a, %eax
    12d3:      	je	0x18ca <generic_retuprobe_filter_arg+0x18ca>
    12d9:      	jmp	0xb8 <generic_retuprobe_filter_arg+0xb8>
    12de:      	cmpl	$0x12, %eax
    12e1:      	je	0x12fb <generic_retuprobe_filter_arg+0x12fb>
    12e3:      	movl	$0x0, %ebx
    12e8:      	cmpl	$0x13, %eax
    12eb:      	jne	0x1bc9 <generic_retuprobe_filter_arg+0x1bc9>
    12f1:      	movq	%r15, %rdx
    12f4:      	movzwl	0x22(%r15), %r13d
    12f9:      	jmp	0x1303 <generic_retuprobe_filter_arg+0x1303>
    12fb:      	movq	%r15, %rdx
    12fe:      	movzwl	0x20(%r15), %r13d
    1303:      	xorl	%esi, %esi
    1305:      	xorl	%ebp, %ebp
    1307:      	xorl	%r15d, %r15d
    130a:      	xorl	%ebx, %ebx
    130c:      	cmpl	$0x11, %eax
    130f:      	jg	0x138f <generic_retuprobe_filter_arg+0x138f>
    1311:      	leal	-0xd(%rax), %ecx
    1314:      	cmpl	$0x2, %ecx
    1317:      	jb	0x13c2 <generic_retuprobe_filter_arg+0x13c2>
    131d:      	leal	-0xf(%rax), %ecx
    1320:      	cmpl	$0x2, %ecx
    1323:      	jb	0x1548 <generic_retuprobe_filter_arg+0x1548>
    1329:      	cmpl	$0x11, %eax
    132c:      	je	0x1b49 <generic_retuprobe_filter_arg+0x1b49>
    1332:      	jmp	0x1bc9 <generic_retuprobe_filter_arg+0x1bc9>
    1337:      	cmpl	$0x1c, %eax
    133a:      	je	0x1b44 <generic_retuprobe_filter_arg+0x1b44>
    1340:      	movl	$0x0, %ebx
    1345:      	cmpl	$0x1d, %eax
    1348:      	jne	0x1bc9 <generic_retuprobe_filter_arg+0x1bc9>
    134e:      	cmpl	$0x7, %ecx
    1351:      	jne	0x20df <generic_retuprobe_filter_arg+0x20df>
    1357:      	testq	%rdx, %rdx
    135a:      	jne	0x20eb <generic_retuprobe_filter_arg+0x20eb>
    1360:      	xorl	%ebx, %ebx
    1362:      	jmp	0x20fd <generic_retuprobe_filter_arg+0x20fd>
    1367:      	movq	0x10(%r15), %rsi
    136b:      	movq	%r15, %rdx
    136e:      	movq	0x18(%r15), %r15
    1372:      	jmp	0x137e <generic_retuprobe_filter_arg+0x137e>
    1374:      	movq	(%r15), %rsi
    1377:      	movq	%r15, %rdx
    137a:      	movq	0x8(%r15), %r15
    137e:      	movq	%rsi, %rbp
    1381:      	shrq	$0x20, %rbp
    1385:      	xorl	%r13d, %r13d
    1388:      	xorl	%ebx, %ebx
    138a:      	cmpl	$0x11, %eax
    138d:      	jle	0x1311 <generic_retuprobe_filter_arg+0x1311>
    138f:      	cmpl	$0x19, %eax
    1392:      	ja	0x153c <generic_retuprobe_filter_arg+0x153c>
    1398:      	movl	$0x500000, %ecx         # imm = 0x500000
    139d:      	btl	%eax, %ecx
    13a0:      	jb	0x1682 <generic_retuprobe_filter_arg+0x1682>
    13a6:      	movl	$0xa00000, %ecx         # imm = 0xA00000
    13ab:      	btl	%eax, %ecx
    13ae:      	jb	0x169a <generic_retuprobe_filter_arg+0x169a>
    13b4:      	movl	$0x3000000, %ecx        # imm = 0x3000000
    13b9:      	btl	%eax, %ecx
    13bc:      	jae	0x153c <generic_retuprobe_filter_arg+0x153c>
    13c2:      	movzwl	0x26(%rdx), %eax
    13c6:      	cmpl	$0xa, %eax
    13c9:      	je	0x1740 <generic_retuprobe_filter_arg+0x1740>
    13cf:      	cmpl	$0x2, %eax
    13d2:      	jne	0x17d2 <generic_retuprobe_filter_arg+0x17d2>
    13d8:      	movq	%rsi, %rbx
    13db:      	movl	0x10(%r12), %eax
    13e0:      	movl	%eax, 0x34(%rsp)
    13e4:      	movl	$0x1, %eax
    13e9:      	leaq	0x34(%rsp), %rsi
    13ee:      	movq	(%rip), %rdi            # 0x13f5 <generic_retuprobe_filter_arg+0x13f5>
    13f5:      	callq	*%rax
    13f7:      	testq	%rax, %rax
    13fa:      	je	0x1c10 <generic_retuprobe_filter_arg+0x1c10>
    1400:      	movq	%rax, %rdi
    1403:      	movl	$0x20, 0x70(%rsp)
    140b:      	movl	%ebx, 0x74(%rsp)
    140f:      	jmp	0x178c <generic_retuprobe_filter_arg+0x178c>
    1414:      	cmpl	$0xc, %ecx
    1417:      	ja	0x21c6 <generic_retuprobe_filter_arg+0x21c6>
    141d:      	movl	$0x1402, %esi           # imm = 0x1402
    1422:      	btl	%ecx, %esi
    1425:      	jae	0x21c6 <generic_retuprobe_filter_arg+0x21c6>
    142b:      	cmpl	%edx, (%r15)
    142e:      	jg	0x271 <generic_retuprobe_filter_arg+0x271>
    1434:      	jmp	0x21da <generic_retuprobe_filter_arg+0x21da>
    1439:      	xorl	%ebx, %ebx
    143b:      	xorl	%r13d, %r13d
    143e:      	movl	0x10(%r12,%rbx,4), %eax
    1443:      	movl	%eax, 0x38(%rsp)
    1447:      	movl	$0x1, %eax
    144c:      	leaq	0x38(%rsp), %rsi
    1451:      	movq	(%rip), %rdi            # 0x1458 <generic_retuprobe_filter_arg+0x1458>
    1458:      	callq	*%rax
    145a:      	testq	%rax, %rax
    145d:      	je	0x2152 <generic_retuprobe_filter_arg+0x2152>
    1463:      	testl	%ebp, %ebp
    1465:      	movq	0x8(%rsp), %r9
    146a:      	movq	0x10(%rsp), %r11
    146f:      	je	0x14bf <generic_retuprobe_filter_arg+0x14bf>
    1471:      	movq	0x18(%rsp), %rdx
    1476:      	xorl	%ecx, %ecx
    1478:      	jmp	0x1485 <generic_retuprobe_filter_arg+0x1485>
    147a:      	incq	%rcx
    147d:      	incq	%rdx
    1480:      	cmpq	%rbp, %rcx
    1483:      	je	0x14bf <generic_retuprobe_filter_arg+0x14bf>
    1485:      	xorl	%esi, %esi
    1487:      	nopw	(%rax,%rax)
    1490:      	leaq	(%rcx,%rsi), %rdi
    1494:      	cmpq	%rbp, %rdi
    1497:      	jae	0x147a <generic_retuprobe_filter_arg+0x147a>
    1499:      	movzbl	(%rax,%rsi), %edi
    149d:      	testb	%dil, %dil
    14a0:      	je	0x14b7 <generic_retuprobe_filter_arg+0x14b7>
    14a2:      	cmpq	$0x62, %rsi
    14a6:      	ja	0x147a <generic_retuprobe_filter_arg+0x147a>
    14a8:      	leaq	0x1(%rsi), %r8
    14ac:      	cmpb	%dil, (%rdx,%rsi)
    14b0:      	movq	%r8, %rsi
    14b3:      	je	0x1490 <generic_retuprobe_filter_arg+0x1490>
    14b5:      	jmp	0x147a <generic_retuprobe_filter_arg+0x147a>
    14b7:      	testl	%ecx, %ecx
    14b9:      	jns	0x260b <generic_retuprobe_filter_arg+0x260b>
    14bf:      	leal	0xc(%r13), %eax
    14c3:      	cmpl	0x8(%r12), %eax
    14c8:      	jae	0x14db <generic_retuprobe_filter_arg+0x14db>
    14ca:      	addl	$0x4, %r13d
    14ce:      	incq	%rbx
    14d1:      	cmpq	$0x64, %rbx
    14d5:      	jne	0x143e <generic_retuprobe_filter_arg+0x143e>
    14db:      	xorl	%ebx, %ebx
    14dd:      	movq	0x28(%rsp), %r13
    14e2:      	movq	(%rsp), %rdi
    14e6:      	jmp	0x3351 <generic_retuprobe_filter_arg+0x3351>
    14eb:      	movzwl	%bp, %eax
    14ee:      	cmpl	$0x90, %eax
    14f3:      	ja	0x1c3c <generic_retuprobe_filter_arg+0x1c3c>
    14f9:      	testw	%bp, %bp
    14fc:      	je	0x150e <generic_retuprobe_filter_arg+0x150e>
    14fe:      	movl	%ebp, %eax
    1500:      	movl	$0x18, %ecx
    1505:      	cltd
    1506:      	idivl	%ecx
    1508:      	movl	%ebp, %esi
    150a:      	testl	%edx, %edx
    150c:      	je	0x1530 <generic_retuprobe_filter_arg+0x1530>
    150e:      	movl	%ebp, %eax
    1510:      	movl	$0x18, %ecx
    1515:      	cltd
    1516:      	idivl	%ecx
    1518:      	shll	$0x3, %eax
    151b:      	leal	(%rax,%rax,2), %eax
    151e:      	addl	$0x18, %eax
    1521:      	movzwl	%ax, %esi
    1524:      	cmpl	$0x90, %esi
    152a:      	ja	0x1c74 <generic_retuprobe_filter_arg+0x1c74>
    1530:      	movl	%esi, %eax
    1532:      	cltd
    1533:      	idivl	%ecx
    1535:      	decl	%eax
    1537:      	jmp	0x288d <generic_retuprobe_filter_arg+0x288d>
    153c:      	addl	$-0x12, %eax
    153f:      	cmpl	$0x2, %eax
    1542:      	jae	0x1bc9 <generic_retuprobe_filter_arg+0x1bc9>
    1548:      	movzbl	0x10(%r12), %eax
    154e:      	movl	%eax, 0x34(%rsp)
    1552:      	movl	$0x1, %eax
    1557:      	movq	(%rip), %rdi            # 0x155e <generic_retuprobe_filter_arg+0x155e>
    155e:      	leaq	0x34(%rsp), %rsi
    1563:      	callq	*%rax
    1565:      	testq	%rax, %rax
    1568:      	je	0x2138 <generic_retuprobe_filter_arg+0x2138>
    156e:      	movq	%rax, %rdi
    1571:      	movzwl	%r13w, %eax
    1575:      	movq	%rax, 0x70(%rsp)
    157a:      	movl	$0x1, %eax
    157f:      	movq	0x20(%rsp), %rsi
    1584:      	jmp	0x1b84 <generic_retuprobe_filter_arg+0x1b84>
    1589:      	leal	-0x100(%r13), %eax
    1590:      	rorxl	$0x8, %eax, %eax
    1596:      	cmpl	$0x2, %eax
    1599:      	jg	0x1d67 <generic_retuprobe_filter_arg+0x1d67>
    159f:      	testl	%eax, %eax
    15a1:      	je	0x246d <generic_retuprobe_filter_arg+0x246d>
    15a7:      	cmpl	$0x1, %eax
    15aa:      	jne	0x2466 <generic_retuprobe_filter_arg+0x2466>
    15b0:      	movl	$0x7, %eax
    15b5:      	jmp	0x2479 <generic_retuprobe_filter_arg+0x2479>
    15ba:      	cmpl	$0x1, %eax
    15bd:      	je	0x1e68 <generic_retuprobe_filter_arg+0x1e68>
    15c3:      	cmpl	$0x2, %eax
    15c6:      	jne	0x1e74 <generic_retuprobe_filter_arg+0x1e74>
    15cc:      	movzbl	(%r15), %edx
    15d0:      	cmpl	%edx, %ecx
    15d2:      	ja	0x271 <generic_retuprobe_filter_arg+0x271>
    15d8:      	jmp	0x1e74 <generic_retuprobe_filter_arg+0x1e74>
    15dd:      	cmpl	$0x1, %eax
    15e0:      	je	0x1ead <generic_retuprobe_filter_arg+0x1ead>
    15e6:      	cmpl	$0x2, %eax
    15e9:      	jne	0x1eb9 <generic_retuprobe_filter_arg+0x1eb9>
    15ef:      	movzwl	(%r15), %edx
    15f3:      	cmpl	%edx, %ecx
    15f5:      	ja	0x271 <generic_retuprobe_filter_arg+0x271>
    15fb:      	jmp	0x1eb9 <generic_retuprobe_filter_arg+0x1eb9>
    1600:      	movzbl	0x10(%r12), %eax
    1606:      	movl	%eax, 0x70(%rsp)
    160a:      	movl	$0x1, %eax
    160f:      	movq	0x20(%rsp), %rsi
    1614:      	movq	(%rip), %rdi            # 0x161b <generic_retuprobe_filter_arg+0x161b>
    161b:      	callq	*%rax
    161d:      	testq	%rax, %rax
    1620:      	je	0x19c8 <generic_retuprobe_filter_arg+0x19c8>
    1626:      	movq	%rax, %rdi
    1629:      	movzbl	(%r15), %eax
    162d:      	movq	%rax, 0x38(%rsp)
    1632:      	movl	$0x1, %eax
    1637:      	leaq	0x38(%rsp), %rsi
    163c:      	jmp	0x1996 <generic_retuprobe_filter_arg+0x1996>
    1641:      	movzbl	0x10(%r12), %eax
    1647:      	movl	%eax, 0x70(%rsp)
    164b:      	movl	$0x1, %eax
    1650:      	movq	0x20(%rsp), %rsi
    1655:      	movq	(%rip), %rdi            # 0x165c <generic_retuprobe_filter_arg+0x165c>
    165c:      	callq	*%rax
    165e:      	testq	%rax, %rax
    1661:      	je	0x19c8 <generic_retuprobe_filter_arg+0x19c8>
    1667:      	movq	%rax, %rdi
    166a:      	movzwl	(%r15), %eax
    166e:      	movq	%rax, 0x38(%rsp)
    1673:      	movl	$0x1, %eax
    1678:      	leaq	0x38(%rsp), %rsi
    167d:      	jmp	0x1996 <generic_retuprobe_filter_arg+0x1996>
    1682:      	movzwl	%r13w, %eax
    1686:      	xorl	%ebx, %ebx
    1688:      	cmpl	$0x400, %eax            # imm = 0x400
    168d:      	setb	%bl
    1690:      	movq	0x28(%rsp), %r13
    1695:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
    169a:      	movzwl	%r13w, %eax
    169e:      	xorl	%ebx, %ebx
    16a0:      	cmpl	$0x400, %eax            # imm = 0x400
    16a5:      	setae	%bl
    16a8:      	movq	0x28(%rsp), %r13
    16ad:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
    16b2:      	testq	%rax, %rax
    16b5:      	sete	%al
    16b8:      	movq	(%rsp), %rdi
    16bc:      	movq	0x8(%rsp), %r9
    16c1:      	movq	0x10(%rsp), %r11
    16c6:      	movzbl	%al, %ebx
    16c9:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
    16ce:      	xorl	%eax, %eax
    16d0:      	movzbl	%al, %ebx
    16d3:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
    16d8:      	movl	$0x100, %esi            # imm = 0x100
    16dd:      	cmpl	$0x101, %eax            # imm = 0x101
    16e2:      	jb	0x1710 <generic_retuprobe_filter_arg+0x1710>
    16e4:      	movl	$0x200, %esi            # imm = 0x200
    16e9:      	cmpl	$0x201, %eax            # imm = 0x201
    16ee:      	jb	0x1710 <generic_retuprobe_filter_arg+0x1710>
    16f0:      	movl	$0x400, %esi            # imm = 0x400
    16f5:      	cmpl	$0x401, %eax            # imm = 0x401
    16fa:      	jb	0x1710 <generic_retuprobe_filter_arg+0x1710>
    16fc:      	xorl	%esi, %esi
    16fe:      	cmpl	$0x801, %eax            # imm = 0x801
    1703:      	setae	%sil
    1707:      	shll	$0xb, %esi
    170a:      	addl	$0x800, %esi            # imm = 0x800
    1710:      	leal	-0x100(%rsi), %eax
    1716:      	rorxl	$0x8, %eax, %eax
    171c:      	cmpl	$0x2, %eax
    171f:      	jg	0x1c20 <generic_retuprobe_filter_arg+0x1c20>
    1725:      	testl	%eax, %eax
    1727:      	je	0x22d0 <generic_retuprobe_filter_arg+0x22d0>
    172d:      	cmpl	$0x1, %eax
    1730:      	jne	0x22c9 <generic_retuprobe_filter_arg+0x22c9>
    1736:      	movl	$0x7, %eax
    173b:      	jmp	0x22dc <generic_retuprobe_filter_arg+0x22dc>
    1740:      	movq	%rsi, %rbx
    1743:      	movl	0x14(%r12), %eax
    1748:      	movl	%eax, 0x34(%rsp)
    174c:      	movl	$0x1, %eax
    1751:      	movq	(%rip), %rdi            # 0x1758 <generic_retuprobe_filter_arg+0x1758>
    1758:      	leaq	0x34(%rsp), %rsi
    175d:      	callq	*%rax
    175f:      	testq	%rax, %rax
    1762:      	je	0x1c10 <generic_retuprobe_filter_arg+0x1c10>
    1768:      	movq	%rax, %rdi
    176b:      	movl	$0x80, 0x70(%rsp)
    1773:      	movl	%ebx, 0x74(%rsp)
    1777:      	movl	%ebp, 0x78(%rsp)
    177b:      	movl	%r15d, 0x7c(%rsp)
    1780:      	shrq	$0x20, %r15
    1784:      	movl	%r15d, 0x80(%rsp)
    178c:      	movl	$0x1, %eax
    1791:      	movq	0x20(%rsp), %rsi
    1796:      	callq	*%rax
    1798:      	movl	0x4(%r12), %ecx
    179d:      	leal	-0x18(%rcx), %edx
    17a0:      	cmpl	$0x2, %edx
    17a3:      	jb	0x1e2b <generic_retuprobe_filter_arg+0x1e2b>
    17a9:      	addl	$-0xd, %ecx
    17ac:      	cmpl	$0x1, %ecx
    17af:      	movq	(%rsp), %rdi
    17b3:      	movq	0x8(%rsp), %r9
    17b8:      	movq	0x10(%rsp), %r11
    17bd:      	ja	0x17d2 <generic_retuprobe_filter_arg+0x17d2>
    17bf:      	testq	%rax, %rax
    17c2:      	setne	%al
    17c5:      	movzbl	%al, %ebx
    17c8:      	movq	0x28(%rsp), %r13
    17cd:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
    17d2:      	xorl	%eax, %eax
    17d4:      	movzbl	%al, %ebx
    17d7:      	movq	0x28(%rsp), %r13
    17dc:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
    17e1:      	cmpl	$0x1e, %eax
    17e4:      	jne	0xb8 <generic_retuprobe_filter_arg+0xb8>
    17ea:      	movl	0x10(%r12), %eax
    17ef:      	andl	$0x7, %eax
    17f2:      	movl	%eax, %ecx
    17f4:      	cmpl	$0x0, 0x5ea0(%r14,%rcx,4)
    17fd:      	jne	0xb8 <generic_retuprobe_filter_arg+0xb8>
    1803:      	movq	(%r15), %rcx
    1806:      	movq	0x5e78(%r14,%rax,8), %rax
    180e:      	andl	$0x7ff, %eax            # imm = 0x7FF
    1813:      	xorl	%ebx, %ebx
    1815:      	andnq	0x90(%r14,%rax), %rcx, %rax
    181f:      	setne	%bl
    1822:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
    1827:      	movq	%r13, 0x18(%rsp)
    182c:      	cmpl	$0x21, %eax
    182f:      	je	0x1f9f <generic_retuprobe_filter_arg+0x1f9f>
    1835:      	movl	$0x0, %ebx
    183a:      	cmpl	$0x22, %eax
    183d:      	jne	0x3640 <generic_retuprobe_filter_arg+0x3640>
    1843:      	movl	$0x10, %r13d
    1849:      	movl	(%r12,%r13), %eax
    184d:      	movl	%eax, 0x38(%rsp)
    1851:      	movl	$0x1, %eax
    1856:      	leaq	0x38(%rsp), %rsi
    185b:      	movq	(%rip), %rdi            # 0x1862 <generic_retuprobe_filter_arg+0x1862>
    1862:      	callq	*%rax
    1864:      	testq	%rax, %rax
    1867:      	je	0x3630 <generic_retuprobe_filter_arg+0x3630>
    186d:      	movq	0x18(%rsp), %rdi
    1872:      	movq	%rax, %rsi
    1875:      	movq	%rbp, %rdx
    1878:      	callq	0x187d <generic_retuprobe_filter_arg+0x187d>
    187d:      	testl	%eax, %eax
    187f:      	jns	0x2c4c <generic_retuprobe_filter_arg+0x2c4c>
    1885:      	addq	$0x4, %r13
    1889:      	leal	-0x8(%r13), %eax
    188d:      	cmpl	0x8(%r12), %eax
    1892:      	movq	(%rsp), %rdi
    1896:      	movq	0x8(%rsp), %r9
    189b:      	movq	0x10(%rsp), %r11
    18a0:      	jae	0x1a9f <generic_retuprobe_filter_arg+0x1a9f>
    18a6:      	movl	$0x0, %ebx
    18ab:      	cmpq	$0x1a0, %r13            # imm = 0x1A0
    18b2:      	jne	0x1849 <generic_retuprobe_filter_arg+0x1849>
    18b4:      	jmp	0x3640 <generic_retuprobe_filter_arg+0x3640>
    18b9:      	movq	%r8, 0x18(%rsp)
    18be:      	movq	%rsi, %r15
    18c1:      	cmpl	$0x8, %eax
    18c4:      	jne	0xb8 <generic_retuprobe_filter_arg+0xb8>
    18ca:      	movl	0x10(%r12), %eax
    18cf:      	movl	%eax, 0x38(%rsp)
    18d3:      	movl	$0x0, 0x70(%rsp)
    18db:      	movl	$0x1, %eax
    18e0:      	leaq	0x38(%rsp), %rsi
    18e5:      	movq	(%rip), %rdi            # 0x18ec <generic_retuprobe_filter_arg+0x18ec>
    18ec:      	callq	*%rax
    18ee:      	testb	%bpl, %bpl
    18f1:      	je	0x1bd3 <generic_retuprobe_filter_arg+0x1bd3>
    18f7:      	movq	%rax, %r13
    18fa:      	movl	$0x0, %ebx
    18ff:      	testq	%rax, %rax
    1902:      	je	0x1bd5 <generic_retuprobe_filter_arg+0x1bd5>
    1908:      	movl	$0x1, %eax
    190d:      	movq	0x20(%rsp), %rsi
    1912:      	movq	(%rip), %rdi            # 0x1919 <generic_retuprobe_filter_arg+0x1919>
    1919:      	callq	*%rax
    191b:      	testq	%rax, %rax
    191e:      	je	0x1bd3 <generic_retuprobe_filter_arg+0x1bd3>
    1924:      	movq	%r15, %rsi
    1927:      	movl	%esi, %ecx
    1929:      	shll	$0x3, %ecx
    192c:      	movl	%ecx, (%rax)
    192e:      	movq	%rax, %rdi
    1931:      	addq	$0x4, %rdi
    1935:      	movq	%rax, %rbx
    1938:      	movl	$0x4, %eax
    193d:      	movq	0x18(%rsp), %rdx
    1942:      	callq	*%rax
    1944:      	movl	$0x1, %eax
    1949:      	movq	%r13, %rdi
    194c:      	movq	%rbx, %rsi
    194f:      	callq	*%rax
    1951:      	xorl	%ebx, %ebx
    1953:      	testq	%rax, %rax
    1956:      	setne	%bl
    1959:      	jmp	0x1bd5 <generic_retuprobe_filter_arg+0x1bd5>
    195e:      	movzwl	(%r15), %ebx
    1962:      	movzbl	0x10(%r12), %eax
    1968:      	movl	%eax, 0x70(%rsp)
    196c:      	movl	$0x1, %eax
    1971:      	movq	0x20(%rsp), %rsi
    1976:      	movq	(%rip), %rdi            # 0x197d <generic_retuprobe_filter_arg+0x197d>
    197d:      	callq	*%rax
    197f:      	testq	%rax, %rax
    1982:      	je	0x19c8 <generic_retuprobe_filter_arg+0x19c8>
    1984:      	movq	%rax, %rdi
    1987:      	movq	%rbx, 0x38(%rsp)
    198c:      	movl	$0x1, %eax
    1991:      	leaq	0x38(%rsp), %rsi
    1996:      	callq	*%rax
    1998:      	movl	0x4(%r12), %edx
    199d:      	xorl	%ecx, %ecx
    199f:      	cmpl	$0x1d, %edx
    19a2:      	ja	0x2793 <generic_retuprobe_filter_arg+0x2793>
    19a8:      	movl	$0x30038400, %esi       # imm = 0x30038400
    19ad:      	btl	%edx, %esi
    19b0:      	movq	(%rsp), %rdi
    19b4:      	movq	0x8(%rsp), %r9
    19b9:      	movq	0x10(%rsp), %r11
    19be:      	jae	0x19dd <generic_retuprobe_filter_arg+0x19dd>
    19c0:      	testq	%rax, %rax
    19c3:      	setne	%cl
    19c6:      	jmp	0x19ed <generic_retuprobe_filter_arg+0x19ed>
    19c8:      	xorl	%ebx, %ebx
    19ca:      	movq	(%rsp), %rdi
    19ce:      	movq	0x8(%rsp), %r9
    19d3:      	movq	0x10(%rsp), %r11
    19d8:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
    19dd:      	movl	$0xc0800, %esi          # imm = 0xC0800
    19e2:      	btl	%edx, %esi
    19e5:      	jae	0x19ed <generic_retuprobe_filter_arg+0x19ed>
    19e7:      	testq	%rax, %rax
    19ea:      	sete	%cl
    19ed:      	movzbl	%cl, %ebx
    19f0:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
    19f5:      	movl	0x10(%r12), %eax
    19fa:      	movl	%eax, 0x38(%rsp)
    19fe:      	movl	$0x0, 0x70(%rsp)
    1a06:      	movl	$0x1, %eax
    1a0b:      	leaq	0x38(%rsp), %rsi
    1a10:      	movq	(%rip), %rdi            # 0x1a17 <generic_retuprobe_filter_arg+0x1a17>
    1a17:      	callq	*%rax
    1a19:      	testl	%ebp, %ebp
    1a1b:      	je	0x3630 <generic_retuprobe_filter_arg+0x3630>
    1a21:      	movq	%rax, %r15
    1a24:      	movl	$0x0, %ebx
    1a29:      	testq	%rax, %rax
    1a2c:      	je	0x3632 <generic_retuprobe_filter_arg+0x3632>
    1a32:      	movl	$0x1, %eax
    1a37:      	movq	0x20(%rsp), %rsi
    1a3c:      	movq	(%rip), %rdi            # 0x1a43 <generic_retuprobe_filter_arg+0x1a43>
    1a43:      	callq	*%rax
    1a45:      	testq	%rax, %rax
    1a48:      	je	0x3630 <generic_retuprobe_filter_arg+0x3630>
    1a4e:      	cmpl	$0xff, %ebp
    1a54:      	movl	$0xff, %ecx
    1a59:      	cmovael	%ecx, %ebp
    1a5c:      	leal	(,%rbp,8), %ecx
    1a63:      	movl	%ecx, (%rax)
    1a65:      	movq	%rax, %rdi
    1a68:      	addq	$0x4, %rdi
    1a6c:      	movq	%rax, %rbx
    1a6f:      	movl	$0x4, %eax
    1a74:      	movl	%ebp, %esi
    1a76:      	movq	%r13, %rdx
    1a79:      	callq	*%rax
    1a7b:      	movl	$0x1, %eax
    1a80:      	movq	%r15, %rdi
    1a83:      	movq	%rbx, %rsi
    1a86:      	jmp	0x3624 <generic_retuprobe_filter_arg+0x3624>
    1a8b:      	movl	$0x0, 0x70(%rsp)
    1a93:      	cmpl	$0x1000, %ebp           # imm = 0x1000
    1a99:      	jbe	0x2046 <generic_retuprobe_filter_arg+0x2046>
    1a9f:      	xorl	%ebx, %ebx
    1aa1:      	jmp	0x3640 <generic_retuprobe_filter_arg+0x3640>
    1aa6:      	movq	(%r15), %rax
    1aa9:      	cmpq	%rax, %rsi
    1aac:      	ja	0x1ab7 <generic_retuprobe_filter_arg+0x1ab7>
    1aae:      	cmpq	%rdx, %rax
    1ab1:      	jbe	0x271 <generic_retuprobe_filter_arg+0x271>
    1ab7:      	movl	0x8(%r12), %edx
    1abc:      	cmpl	$0x19, %edx
    1abf:      	jb	0xb8 <generic_retuprobe_filter_arg+0xb8>
    1ac5:      	movq	0x20(%r12), %rdi
    1aca:      	movq	0x28(%r12), %rsi
    1acf:      	cmpl	$0xc, %ecx
    1ad2:      	je	0x1add <generic_retuprobe_filter_arg+0x1add>
    1ad4:      	cmpl	$0xa, %ecx
    1ad7:      	jne	0x2178 <generic_retuprobe_filter_arg+0x2178>
    1add:      	cmpq	%rax, %rdi
    1ae0:      	movq	(%rsp), %rdi
    1ae4:      	jg	0x218a <generic_retuprobe_filter_arg+0x218a>
    1aea:      	cmpq	%rsi, %rax
    1aed:      	jle	0x271 <generic_retuprobe_filter_arg+0x271>
    1af3:      	jmp	0x218a <generic_retuprobe_filter_arg+0x218a>
    1af8:      	movq	(%r15), %rdx
    1afb:      	cmpq	%rdx, %rsi
    1afe:      	setbe	%sil
    1b02:      	cmpq	%rax, %rdx
    1b05:      	setbe	%al
    1b08:      	andb	%sil, %al
    1b0b:      	movl	0x8(%r12), %esi
    1b10:      	cmpl	$0x19, %esi
    1b13:      	jb	0x2fe6 <generic_retuprobe_filter_arg+0x2fe6>
    1b19:      	movq	0x20(%r12), %r8
    1b1e:      	movq	0x28(%r12), %rdi
    1b23:      	cmpl	$0xc, %ecx
    1b26:      	je	0x1b31 <generic_retuprobe_filter_arg+0x1b31>
    1b28:      	cmpl	$0xa, %ecx
    1b2b:      	jne	0x2097 <generic_retuprobe_filter_arg+0x2097>
    1b31:      	cmpq	%rdx, %r8
    1b34:      	setle	%r8b
    1b38:      	cmpq	%rdi, %rdx
    1b3b:      	setle	%dil
    1b3f:      	jmp	0x20a5 <generic_retuprobe_filter_arg+0x20a5>
    1b44:      	movzwl	0x26(%r15), %ebx
    1b49:      	movzbl	0x10(%r12), %eax
    1b4f:      	movl	%eax, 0x34(%rsp)
    1b53:      	movl	$0x1, %eax
    1b58:      	movq	(%rip), %rdi            # 0x1b5f <generic_retuprobe_filter_arg+0x1b5f>
    1b5f:      	leaq	0x34(%rsp), %rsi
    1b64:      	callq	*%rax
    1b66:      	testq	%rax, %rax
    1b69:      	je	0x2138 <generic_retuprobe_filter_arg+0x2138>
    1b6f:      	movq	%rax, %rdi
    1b72:      	movzwl	%bx, %eax
    1b75:      	movq	%rax, 0x70(%rsp)
    1b7a:      	movl	$0x1, %eax
    1b7f:      	movq	0x20(%rsp), %rsi
    1b84:      	callq	*%rax
    1b86:      	movl	0x4(%r12), %edx
    1b8b:      	xorl	%ecx, %ecx
    1b8d:      	cmpl	$0x1d, %edx
    1b90:      	ja	0x2a26 <generic_retuprobe_filter_arg+0x2a26>
    1b96:      	movl	$0x30038400, %esi       # imm = 0x30038400
    1b9b:      	btl	%edx, %esi
    1b9e:      	movq	(%rsp), %rdi
    1ba2:      	movq	0x8(%rsp), %r9
    1ba7:      	movq	0x10(%rsp), %r11
    1bac:      	jae	0x1bb6 <generic_retuprobe_filter_arg+0x1bb6>
    1bae:      	testq	%rax, %rax
    1bb1:      	setne	%cl
    1bb4:      	jmp	0x1bc6 <generic_retuprobe_filter_arg+0x1bc6>
    1bb6:      	movl	$0xc0800, %esi          # imm = 0xC0800
    1bbb:      	btl	%edx, %esi
    1bbe:      	jae	0x1bc6 <generic_retuprobe_filter_arg+0x1bc6>
    1bc0:      	testq	%rax, %rax
    1bc3:      	sete	%cl
    1bc6:      	movzbl	%cl, %ebx
    1bc9:      	movq	0x28(%rsp), %r13
    1bce:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
    1bd3:      	xorl	%ebx, %ebx
    1bd5:      	movl	0x4(%r12), %eax
    1bda:      	cmpq	$0x25, %rax
    1bde:      	ja	0x2aeb <generic_retuprobe_filter_arg+0x2aeb>
    1be4:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    1bee:      	btq	%rax, %rcx
    1bf2:      	movq	0x28(%rsp), %r13
    1bf7:      	movq	(%rsp), %rdi
    1bfb:      	movq	0x8(%rsp), %r9
    1c00:      	movq	0x10(%rsp), %r11
    1c05:      	jb	0x3186 <generic_retuprobe_filter_arg+0x3186>
    1c0b:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
    1c10:      	movl	0x4(%r12), %eax
    1c15:      	andl	$-0x2, %eax
    1c18:      	cmpl	$0x18, %eax
    1c1b:      	jmp	0x1e2e <generic_retuprobe_filter_arg+0x1e2e>
    1c20:      	cmpl	$0x3, %eax
    1c23:      	je	0x22d7 <generic_retuprobe_filter_arg+0x22d7>
    1c29:      	cmpl	$0x7, %eax
    1c2c:      	jne	0x22c9 <generic_retuprobe_filter_arg+0x22c9>
    1c32:      	movl	$0x9, %eax
    1c37:      	jmp	0x22dc <generic_retuprobe_filter_arg+0x22dc>
    1c3c:      	movl	$0x100, %esi            # imm = 0x100
    1c41:      	cmpl	$0x101, %eax            # imm = 0x101
    1c46:      	jb	0x1c74 <generic_retuprobe_filter_arg+0x1c74>
    1c48:      	movl	$0x200, %esi            # imm = 0x200
    1c4d:      	cmpl	$0x201, %eax            # imm = 0x201
    1c52:      	jb	0x1c74 <generic_retuprobe_filter_arg+0x1c74>
    1c54:      	movl	$0x400, %esi            # imm = 0x400
    1c59:      	cmpl	$0x401, %eax            # imm = 0x401
    1c5e:      	jb	0x1c74 <generic_retuprobe_filter_arg+0x1c74>
    1c60:      	xorl	%esi, %esi
    1c62:      	cmpl	$0x801, %eax            # imm = 0x801
    1c67:      	setae	%sil
    1c6b:      	shll	$0xb, %esi
    1c6e:      	addl	$0x800, %esi            # imm = 0x800
    1c74:      	leal	-0x100(%rsi), %eax
    1c7a:      	rorxl	$0x8, %eax, %eax
    1c80:      	cmpl	$0x2, %eax
    1c83:      	jg	0x1e4c <generic_retuprobe_filter_arg+0x1e4c>
    1c89:      	testl	%eax, %eax
    1c8b:      	je	0x2881 <generic_retuprobe_filter_arg+0x2881>
    1c91:      	cmpl	$0x1, %eax
    1c94:      	jne	0x287a <generic_retuprobe_filter_arg+0x287a>
    1c9a:      	movl	$0x7, %eax
    1c9f:      	jmp	0x288d <generic_retuprobe_filter_arg+0x288d>
    1ca4:      	cmpq	%rdx, (%r15)
    1ca7:      	ja	0x271 <generic_retuprobe_filter_arg+0x271>
    1cad:      	jmp	0x1cb8 <generic_retuprobe_filter_arg+0x1cb8>
    1caf:      	cmpq	%rdx, (%r15)
    1cb2:      	jb	0x271 <generic_retuprobe_filter_arg+0x271>
    1cb8:      	movl	0x8(%r12), %edx
    1cbd:      	cmpl	$0x11, %edx
    1cc0:      	jb	0x36a7 <generic_retuprobe_filter_arg+0x36a7>
    1cc6:      	movq	0x18(%r12), %rsi
    1ccb:      	cmpl	$0x2, %eax
    1cce:      	jle	0x1cea <generic_retuprobe_filter_arg+0x1cea>
    1cd0:      	leal	-0x3(%rax), %edi
    1cd3:      	cmpl	$0x2, %edi
    1cd6:      	jae	0x1d18 <generic_retuprobe_filter_arg+0x1d18>
    1cd8:      	cmpq	%rsi, (%r15)
    1cdb:      	movq	(%rsp), %rdi
    1cdf:      	je	0x24f <generic_retuprobe_filter_arg+0x24f>
    1ce5:      	jmp	0x2804 <generic_retuprobe_filter_arg+0x2804>
    1cea:      	cmpl	$0x1, %eax
    1ced:      	je	0x1d83 <generic_retuprobe_filter_arg+0x1d83>
    1cf3:      	cmpl	$0x2, %eax
    1cf6:      	jne	0x2804 <generic_retuprobe_filter_arg+0x2804>
    1cfc:      	cmpl	$0xc, %ecx
    1cff:      	je	0x1d0a <generic_retuprobe_filter_arg+0x1d0a>
    1d01:      	cmpl	$0xa, %ecx
    1d04:      	jne	0x27fb <generic_retuprobe_filter_arg+0x27fb>
    1d0a:      	cmpq	%rsi, (%r15)
    1d0d:      	jl	0x271 <generic_retuprobe_filter_arg+0x271>
    1d13:      	jmp	0x2804 <generic_retuprobe_filter_arg+0x2804>
    1d18:      	cmpl	$0xc, %eax
    1d1b:      	movq	(%rsp), %rdi
    1d1f:      	jne	0x2804 <generic_retuprobe_filter_arg+0x2804>
    1d25:      	testq	%rsi, (%r15)
    1d28:      	jne	0x271 <generic_retuprobe_filter_arg+0x271>
    1d2e:      	jmp	0x2804 <generic_retuprobe_filter_arg+0x2804>
    1d33:      	cmpl	$0xc, %eax
    1d36:      	jne	0x1e74 <generic_retuprobe_filter_arg+0x1e74>
    1d3c:      	movzbl	(%r15), %edx
    1d40:      	testl	%edx, %ecx
    1d42:      	jne	0x271 <generic_retuprobe_filter_arg+0x271>
    1d48:      	jmp	0x1e74 <generic_retuprobe_filter_arg+0x1e74>
    1d4d:      	cmpl	$0xc, %eax
    1d50:      	jne	0x1eb9 <generic_retuprobe_filter_arg+0x1eb9>
    1d56:      	movzwl	(%r15), %edx
    1d5a:      	testl	%edx, %ecx
    1d5c:      	jne	0x271 <generic_retuprobe_filter_arg+0x271>
    1d62:      	jmp	0x1eb9 <generic_retuprobe_filter_arg+0x1eb9>
    1d67:      	cmpl	$0x3, %eax
    1d6a:      	je	0x2474 <generic_retuprobe_filter_arg+0x2474>
    1d70:      	cmpl	$0x7, %eax
    1d73:      	jne	0x2466 <generic_retuprobe_filter_arg+0x2466>
    1d79:      	movl	$0x9, %eax
    1d7e:      	jmp	0x2479 <generic_retuprobe_filter_arg+0x2479>
    1d83:      	cmpl	$0xc, %ecx
    1d86:      	je	0x1d91 <generic_retuprobe_filter_arg+0x1d91>
    1d88:      	cmpl	$0xa, %ecx
    1d8b:      	jne	0x27f0 <generic_retuprobe_filter_arg+0x27f0>
    1d91:      	cmpq	%rsi, (%r15)
    1d94:      	jg	0x271 <generic_retuprobe_filter_arg+0x271>
    1d9a:      	jmp	0x2804 <generic_retuprobe_filter_arg+0x2804>
    1d9f:      	movl	0x8(%r12), %edx
    1da4:      	movzbl	(%r15), %ecx
    1da8:      	jmp	0x1db3 <generic_retuprobe_filter_arg+0x1db3>
    1daa:      	movl	0x8(%r12), %edx
    1daf:      	movzwl	(%r15), %ecx
    1db3:      	cmpl	%ecx, 0x10(%r12)
    1db8:      	setbe	%sil
    1dbc:      	cmpl	%ecx, 0x14(%r12)
    1dc1:      	setae	%al
    1dc4:      	andb	%sil, %al
    1dc7:      	cmpl	$0x11, %edx
    1dca:      	jb	0x2fe6 <generic_retuprobe_filter_arg+0x2fe6>
    1dd0:      	cmpl	%ecx, 0x18(%r12)
    1dd5:      	setbe	%sil
    1dd9:      	cmpl	%ecx, 0x1c(%r12)
    1dde:      	setae	%dil
    1de2:      	andb	%sil, %dil
    1de5:      	orb	%dil, %al
    1de8:      	cmpl	$0x19, %edx
    1deb:      	jb	0x2fe2 <generic_retuprobe_filter_arg+0x2fe2>
    1df1:      	cmpl	%ecx, 0x20(%r12)
    1df6:      	setbe	%sil
    1dfa:      	cmpl	%ecx, 0x24(%r12)
    1dff:      	setae	%dil
    1e03:      	andb	%sil, %dil
    1e06:      	orb	%dil, %al
    1e09:      	cmpl	$0x21, %edx
    1e0c:      	jb	0x2fe2 <generic_retuprobe_filter_arg+0x2fe2>
    1e12:      	cmpl	%ecx, 0x28(%r12)
    1e17:      	setbe	%dl
    1e1a:      	cmpl	%ecx, 0x2c(%r12)
    1e1f:      	setae	%cl
    1e22:      	andb	%dl, %cl
    1e24:      	orb	%cl, %al
    1e26:      	jmp	0x2fe2 <generic_retuprobe_filter_arg+0x2fe2>
    1e2b:      	testq	%rax, %rax
    1e2e:      	sete	%al
    1e31:      	movq	(%rsp), %rdi
    1e35:      	movq	0x8(%rsp), %r9
    1e3a:      	movq	0x10(%rsp), %r11
    1e3f:      	movzbl	%al, %ebx
    1e42:      	movq	0x28(%rsp), %r13
    1e47:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
    1e4c:      	cmpl	$0x3, %eax
    1e4f:      	je	0x2888 <generic_retuprobe_filter_arg+0x2888>
    1e55:      	cmpl	$0x7, %eax
    1e58:      	jne	0x287a <generic_retuprobe_filter_arg+0x287a>
    1e5e:      	movl	$0x9, %eax
    1e63:      	jmp	0x288d <generic_retuprobe_filter_arg+0x288d>
    1e68:      	movzbl	(%r15), %edx
    1e6c:      	cmpl	%edx, %ecx
    1e6e:      	jb	0x271 <generic_retuprobe_filter_arg+0x271>
    1e74:      	movl	0x8(%r12), %ecx
    1e79:      	cmpl	$0xd, %ecx
    1e7c:      	jb	0x36a7 <generic_retuprobe_filter_arg+0x36a7>
    1e82:      	movl	0x14(%r12), %edx
    1e87:      	cmpl	$0x2, %eax
    1e8a:      	jle	0x2283 <generic_retuprobe_filter_arg+0x2283>
    1e90:      	leal	-0x3(%rax), %esi
    1e93:      	cmpl	$0x2, %esi
    1e96:      	jae	0x2a39 <generic_retuprobe_filter_arg+0x2a39>
    1e9c:      	movzbl	(%r15), %esi
    1ea0:      	cmpl	%esi, %edx
    1ea2:      	je	0x24f <generic_retuprobe_filter_arg+0x24f>
    1ea8:      	jmp	0x2b1d <generic_retuprobe_filter_arg+0x2b1d>
    1ead:      	movzwl	(%r15), %edx
    1eb1:      	cmpl	%edx, %ecx
    1eb3:      	jb	0x271 <generic_retuprobe_filter_arg+0x271>
    1eb9:      	movl	0x8(%r12), %ecx
    1ebe:      	cmpl	$0xd, %ecx
    1ec1:      	jb	0x36a7 <generic_retuprobe_filter_arg+0x36a7>
    1ec7:      	movl	0x14(%r12), %edx
    1ecc:      	cmpl	$0x2, %eax
    1ecf:      	jle	0x22a6 <generic_retuprobe_filter_arg+0x22a6>
    1ed5:      	leal	-0x3(%rax), %esi
    1ed8:      	cmpl	$0x2, %esi
    1edb:      	jae	0x2a53 <generic_retuprobe_filter_arg+0x2a53>
    1ee1:      	movzwl	(%r15), %esi
    1ee5:      	cmpl	%esi, %edx
    1ee7:      	je	0x24f <generic_retuprobe_filter_arg+0x24f>
    1eed:      	jmp	0x2b5d <generic_retuprobe_filter_arg+0x2b5d>
    1ef2:      	movl	(%r15), %eax
    1ef5:      	cmpl	%eax, %esi
    1ef7:      	ja	0x1f01 <generic_retuprobe_filter_arg+0x1f01>
    1ef9:      	cmpl	%edx, %eax
    1efb:      	jbe	0x271 <generic_retuprobe_filter_arg+0x271>
    1f01:      	movl	0x8(%r12), %edx
    1f06:      	cmpl	$0x11, %edx
    1f09:      	jb	0xb8 <generic_retuprobe_filter_arg+0xb8>
    1f0f:      	movl	0x18(%r12), %edi
    1f14:      	movl	0x1c(%r12), %esi
    1f19:      	cmpl	$0xc, %ecx
    1f1c:      	ja	0x2693 <generic_retuprobe_filter_arg+0x2693>
    1f22:      	movl	$0x1402, %r8d           # imm = 0x1402
    1f28:      	btl	%ecx, %r8d
    1f2c:      	jae	0x2693 <generic_retuprobe_filter_arg+0x2693>
    1f32:      	cmpl	%eax, %edi
    1f34:      	movq	(%rsp), %rdi
    1f38:      	jg	0x26a3 <generic_retuprobe_filter_arg+0x26a3>
    1f3e:      	cmpl	%esi, %eax
    1f40:      	jle	0x271 <generic_retuprobe_filter_arg+0x271>
    1f46:      	jmp	0x26a3 <generic_retuprobe_filter_arg+0x26a3>
    1f4b:      	movl	(%r15), %edx
    1f4e:      	cmpl	%edx, %esi
    1f50:      	setbe	%sil
    1f54:      	cmpl	%eax, %edx
    1f56:      	setbe	%al
    1f59:      	andb	%sil, %al
    1f5c:      	movl	0x8(%r12), %esi
    1f61:      	cmpl	$0x11, %esi
    1f64:      	jb	0x2fe6 <generic_retuprobe_filter_arg+0x2fe6>
    1f6a:      	movl	0x18(%r12), %r8d
    1f6f:      	movl	0x1c(%r12), %edi
    1f74:      	cmpl	$0xc, %ecx
    1f77:      	ja	0x2636 <generic_retuprobe_filter_arg+0x2636>
    1f7d:      	movl	$0x1402, %r10d          # imm = 0x1402
    1f83:      	btl	%ecx, %r10d
    1f87:      	jae	0x2636 <generic_retuprobe_filter_arg+0x2636>
    1f8d:      	cmpl	%edx, %r8d
    1f90:      	setle	%r8b
    1f94:      	cmpl	%edi, %edx
    1f96:      	setle	%dil
    1f9a:      	jmp	0x2643 <generic_retuprobe_filter_arg+0x2643>
    1f9f:      	xorl	%ebx, %ebx
    1fa1:      	xorl	%r13d, %r13d
    1fa4:      	movl	0x10(%r12,%rbx,4), %eax
    1fa9:      	movl	%eax, 0x38(%rsp)
    1fad:      	movl	$0x1, %eax
    1fb2:      	leaq	0x38(%rsp), %rsi
    1fb7:      	movq	(%rip), %rdi            # 0x1fbe <generic_retuprobe_filter_arg+0x1fbe>
    1fbe:      	callq	*%rax
    1fc0:      	testq	%rax, %rax
    1fc3:      	je	0x2b91 <generic_retuprobe_filter_arg+0x2b91>
    1fc9:      	testl	%ebp, %ebp
    1fcb:      	movq	0x8(%rsp), %r9
    1fd0:      	movq	0x10(%rsp), %r11
    1fd5:      	je	0x201f <generic_retuprobe_filter_arg+0x201f>
    1fd7:      	movq	0x18(%rsp), %rdx
    1fdc:      	xorl	%ecx, %ecx
    1fde:      	jmp	0x1feb <generic_retuprobe_filter_arg+0x1feb>
    1fe0:      	incq	%rcx
    1fe3:      	incq	%rdx
    1fe6:      	cmpq	%rbp, %rcx
    1fe9:      	je	0x201f <generic_retuprobe_filter_arg+0x201f>
    1feb:      	xorl	%esi, %esi
    1fed:      	nopl	(%rax)
    1ff0:      	leaq	(%rcx,%rsi), %rdi
    1ff4:      	cmpq	%rbp, %rdi
    1ff7:      	jae	0x1fe0 <generic_retuprobe_filter_arg+0x1fe0>
    1ff9:      	movzbl	(%rax,%rsi), %edi
    1ffd:      	testb	%dil, %dil
    2000:      	je	0x2017 <generic_retuprobe_filter_arg+0x2017>
    2002:      	cmpq	$0x62, %rsi
    2006:      	ja	0x1fe0 <generic_retuprobe_filter_arg+0x1fe0>
    2008:      	leaq	0x1(%rsi), %r8
    200c:      	cmpb	%dil, (%rdx,%rsi)
    2010:      	movq	%r8, %rsi
    2013:      	je	0x1ff0 <generic_retuprobe_filter_arg+0x1ff0>
    2015:      	jmp	0x1fe0 <generic_retuprobe_filter_arg+0x1fe0>
    2017:      	testl	%ecx, %ecx
    2019:      	jns	0x2e31 <generic_retuprobe_filter_arg+0x2e31>
    201f:      	leal	0xc(%r13), %eax
    2023:      	cmpl	0x8(%r12), %eax
    2028:      	jae	0x203b <generic_retuprobe_filter_arg+0x203b>
    202a:      	addl	$0x4, %r13d
    202e:      	incq	%rbx
    2031:      	cmpq	$0x64, %rbx
    2035:      	jne	0x1fa4 <generic_retuprobe_filter_arg+0x1fa4>
    203b:      	xorl	%ebx, %ebx
    203d:      	movq	(%rsp), %rdi
    2041:      	jmp	0x3640 <generic_retuprobe_filter_arg+0x3640>
    2046:      	movzwl	%bp, %eax
    2049:      	cmpl	$0x90, %eax
    204e:      	ja	0x26e8 <generic_retuprobe_filter_arg+0x26e8>
    2054:      	testw	%bp, %bp
    2057:      	je	0x2069 <generic_retuprobe_filter_arg+0x2069>
    2059:      	movl	%ebp, %eax
    205b:      	movl	$0x18, %ecx
    2060:      	cltd
    2061:      	idivl	%ecx
    2063:      	movl	%ebp, %esi
    2065:      	testl	%edx, %edx
    2067:      	je	0x208b <generic_retuprobe_filter_arg+0x208b>
    2069:      	movl	%ebp, %eax
    206b:      	movl	$0x18, %ecx
    2070:      	cltd
    2071:      	idivl	%ecx
    2073:      	shll	$0x3, %eax
    2076:      	leal	(%rax,%rax,2), %eax
    2079:      	addl	$0x18, %eax
    207c:      	movzwl	%ax, %esi
    207f:      	cmpl	$0x90, %esi
    2085:      	ja	0x2720 <generic_retuprobe_filter_arg+0x2720>
    208b:      	movl	%esi, %eax
    208d:      	cltd
    208e:      	idivl	%ecx
    2090:      	decl	%eax
    2092:      	jmp	0x2e52 <generic_retuprobe_filter_arg+0x2e52>
    2097:      	cmpq	%rdx, %r8
    209a:      	setbe	%r8b
    209e:      	cmpq	%rdi, %rdx
    20a1:      	setbe	%dil
    20a5:      	andb	%r8b, %dil
    20a8:      	orb	%dil, %al
    20ab:      	cmpl	$0x29, %esi
    20ae:      	jb	0x2fe2 <generic_retuprobe_filter_arg+0x2fe2>
    20b4:      	movq	0x30(%r12), %r8
    20b9:      	movq	0x38(%r12), %rdi
    20be:      	cmpl	$0xc, %ecx
    20c1:      	je	0x20cc <generic_retuprobe_filter_arg+0x20cc>
    20c3:      	cmpl	$0xa, %ecx
    20c6:      	jne	0x2750 <generic_retuprobe_filter_arg+0x2750>
    20cc:      	cmpq	%rdx, %r8
    20cf:      	setle	%r8b
    20d3:      	cmpq	%rdi, %rdx
    20d6:      	setle	%dil
    20da:      	jmp	0x275e <generic_retuprobe_filter_arg+0x275e>
    20df:      	xorl	%ebx, %ebx
    20e1:      	cmpl	$0x29, %ecx
    20e4:      	jne	0x20ef <generic_retuprobe_filter_arg+0x20ef>
    20e6:      	testq	%rdx, %rdx
    20e9:      	je	0x20ef <generic_retuprobe_filter_arg+0x20ef>
    20eb:      	movzbl	0x3a(%rdx), %ebx
    20ef:      	cmpl	$0x29, %ecx
    20f2:      	je	0x20fd <generic_retuprobe_filter_arg+0x20fd>
    20f4:      	cmpl	$0x7, %ecx
    20f7:      	jne	0x2687 <generic_retuprobe_filter_arg+0x2687>
    20fd:      	movzbl	0x10(%r12), %eax
    2103:      	movl	%eax, 0x34(%rsp)
    2107:      	movl	$0x1, %eax
    210c:      	movq	(%rip), %rdi            # 0x2113 <generic_retuprobe_filter_arg+0x2113>
    2113:      	leaq	0x34(%rsp), %rsi
    2118:      	callq	*%rax
    211a:      	testq	%rax, %rax
    211d:      	je	0x2138 <generic_retuprobe_filter_arg+0x2138>
    211f:      	movq	%rax, %rdi
    2122:      	movl	%ebx, %eax
    2124:      	movq	%rax, 0x70(%rsp)
    2129:      	movl	$0x1, %eax
    212e:      	movq	0x20(%rsp), %rsi
    2133:      	jmp	0x1b84 <generic_retuprobe_filter_arg+0x1b84>
    2138:      	xorl	%ebx, %ebx
    213a:      	movq	(%rsp), %rdi
    213e:      	movq	0x8(%rsp), %r9
    2143:      	movq	0x10(%rsp), %r11
    2148:      	movq	0x28(%rsp), %r13
    214d:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
    2152:      	xorl	%ebx, %ebx
    2154:      	movq	0x28(%rsp), %r13
    2159:      	movq	0x8(%rsp), %r9
    215e:      	movq	0x10(%rsp), %r11
    2163:      	movq	(%rsp), %rdi
    2167:      	jmp	0x3351 <generic_retuprobe_filter_arg+0x3351>
    216c:      	xorl	%ebx, %ebx
    216e:      	movq	0x10(%rsp), %r11
    2173:      	jmp	0x2623 <generic_retuprobe_filter_arg+0x2623>
    2178:      	cmpq	%rax, %rdi
    217b:      	movq	(%rsp), %rdi
    217f:      	ja	0x218a <generic_retuprobe_filter_arg+0x218a>
    2181:      	cmpq	%rsi, %rax
    2184:      	jbe	0x271 <generic_retuprobe_filter_arg+0x271>
    218a:      	cmpl	$0x29, %edx
    218d:      	jb	0xb8 <generic_retuprobe_filter_arg+0xb8>
    2193:      	movq	0x30(%r12), %rdi
    2198:      	movq	0x38(%r12), %rsi
    219d:      	cmpl	$0xc, %ecx
    21a0:      	je	0x21ab <generic_retuprobe_filter_arg+0x21ab>
    21a2:      	cmpl	$0xa, %ecx
    21a5:      	jne	0x27a6 <generic_retuprobe_filter_arg+0x27a6>
    21ab:      	cmpq	%rax, %rdi
    21ae:      	movq	(%rsp), %rdi
    21b2:      	jg	0x27b8 <generic_retuprobe_filter_arg+0x27b8>
    21b8:      	cmpq	%rsi, %rax
    21bb:      	jle	0x271 <generic_retuprobe_filter_arg+0x271>
    21c1:      	jmp	0x27b8 <generic_retuprobe_filter_arg+0x27b8>
    21c6:      	cmpl	%edx, (%r15)
    21c9:      	ja	0x271 <generic_retuprobe_filter_arg+0x271>
    21cf:      	jmp	0x21da <generic_retuprobe_filter_arg+0x21da>
    21d1:      	cmpl	%edx, (%r15)
    21d4:      	jb	0x271 <generic_retuprobe_filter_arg+0x271>
    21da:      	movl	0x8(%r12), %edx
    21df:      	cmpl	$0xd, %edx
    21e2:      	jb	0x36a7 <generic_retuprobe_filter_arg+0x36a7>
    21e8:      	movl	0x14(%r12), %esi
    21ed:      	cmpl	$0x2, %eax
    21f0:      	jle	0x220c <generic_retuprobe_filter_arg+0x220c>
    21f2:      	leal	-0x3(%rax), %edi
    21f5:      	cmpl	$0x2, %edi
    21f8:      	jae	0x2241 <generic_retuprobe_filter_arg+0x2241>
    21fa:      	cmpl	%esi, (%r15)
    21fd:      	movq	(%rsp), %rdi
    2201:      	je	0x24f <generic_retuprobe_filter_arg+0x24f>
    2207:      	jmp	0x2cbb <generic_retuprobe_filter_arg+0x2cbb>
    220c:      	cmpl	$0x1, %eax
    220f:      	je	0x225c <generic_retuprobe_filter_arg+0x225c>
    2211:      	cmpl	$0x2, %eax
    2214:      	jne	0x2cbb <generic_retuprobe_filter_arg+0x2cbb>
    221a:      	cmpl	$0xc, %ecx
    221d:      	ja	0x2cb2 <generic_retuprobe_filter_arg+0x2cb2>
    2223:      	movl	$0x1402, %r8d           # imm = 0x1402
    2229:      	btl	%ecx, %r8d
    222d:      	jae	0x2cb2 <generic_retuprobe_filter_arg+0x2cb2>
    2233:      	cmpl	%esi, (%r15)
    2236:      	jl	0x271 <generic_retuprobe_filter_arg+0x271>
    223c:      	jmp	0x2cbb <generic_retuprobe_filter_arg+0x2cbb>
    2241:      	cmpl	$0xc, %eax
    2244:      	movq	(%rsp), %rdi
    2248:      	jne	0x2cbb <generic_retuprobe_filter_arg+0x2cbb>
    224e:      	testl	%esi, (%r15)
    2251:      	jne	0x271 <generic_retuprobe_filter_arg+0x271>
    2257:      	jmp	0x2cbb <generic_retuprobe_filter_arg+0x2cbb>
    225c:      	cmpl	$0xc, %ecx
    225f:      	ja	0x2ca7 <generic_retuprobe_filter_arg+0x2ca7>
    2265:      	movl	$0x1402, %r8d           # imm = 0x1402
    226b:      	btl	%ecx, %r8d
    226f:      	jae	0x2ca7 <generic_retuprobe_filter_arg+0x2ca7>
    2275:      	cmpl	%esi, (%r15)
    2278:      	jg	0x271 <generic_retuprobe_filter_arg+0x271>
    227e:      	jmp	0x2cbb <generic_retuprobe_filter_arg+0x2cbb>
    2283:      	cmpl	$0x1, %eax
    2286:      	je	0x2b11 <generic_retuprobe_filter_arg+0x2b11>
    228c:      	cmpl	$0x2, %eax
    228f:      	jne	0x2b1d <generic_retuprobe_filter_arg+0x2b1d>
    2295:      	movzbl	(%r15), %esi
    2299:      	cmpl	%esi, %edx
    229b:      	ja	0x271 <generic_retuprobe_filter_arg+0x271>
    22a1:      	jmp	0x2b1d <generic_retuprobe_filter_arg+0x2b1d>
    22a6:      	cmpl	$0x1, %eax
    22a9:      	je	0x2b51 <generic_retuprobe_filter_arg+0x2b51>
    22af:      	cmpl	$0x2, %eax
    22b2:      	jne	0x2b5d <generic_retuprobe_filter_arg+0x2b5d>
    22b8:      	movzwl	(%r15), %esi
    22bc:      	cmpl	%esi, %edx
    22be:      	ja	0x271 <generic_retuprobe_filter_arg+0x271>
    22c4:      	jmp	0x2b5d <generic_retuprobe_filter_arg+0x2b5d>
    22c9:      	movl	$0xa, %eax
    22ce:      	jmp	0x22dc <generic_retuprobe_filter_arg+0x22dc>
    22d0:      	movl	$0x6, %eax
    22d5:      	jmp	0x22dc <generic_retuprobe_filter_arg+0x22dc>
    22d7:      	movl	$0x8, %eax
    22dc:      	movl	%eax, %ecx
    22de:      	andl	$0xf, %ecx
    22e1:      	movl	0x10(%r12,%rcx,4), %ecx
    22e6:      	cmpl	$-0x1, %ecx
    22e9:      	je	0x3153 <generic_retuprobe_filter_arg+0x3153>
    22ef:      	movl	%ecx, 0x6c(%rsp)
    22f3:      	movl	%eax, 0x18(%rsp)
    22f7:      	movq	%rsi, 0x88(%rsp)
    22ff:      	movl	$0x1, %eax
    2304:      	movq	(%rip), %rdi            # 0x230b <generic_retuprobe_filter_arg+0x230b>
    230b:      	movq	0x20(%rsp), %rbx
    2310:      	movq	%rbx, %rsi
    2313:      	callq	*%rax
    2315:      	movq	%rax, 0x60(%rsp)
    231a:      	movl	$0x1, %eax
    231f:      	movq	(%rip), %rdi            # 0x2326 <generic_retuprobe_filter_arg+0x2326>
    2326:      	movq	%rbx, %rsi
    2329:      	callq	*%rax
    232b:      	movq	0x60(%rsp), %rdx
    2330:      	testq	%rdx, %rdx
    2333:      	je	0x3153 <generic_retuprobe_filter_arg+0x3153>
    2339:      	movl	$0x0, %ebx
    233e:      	testq	%rax, %rax
    2341:      	movq	(%rsp), %rdi
    2345:      	movq	0x8(%rsp), %r9
    234a:      	movq	0x10(%rsp), %r11
    234f:      	je	0x3163 <generic_retuprobe_filter_arg+0x3163>
    2355:      	movq	%rdx, %rcx
    2358:      	movq	%rax, %rbx
    235b:      	movq	%r15, %rdx
    235e:      	addq	$0x4, %rdx
    2362:      	cmpl	$0x5, 0x18(%rsp)
    2367:      	jg	0x239c <generic_retuprobe_filter_arg+0x239c>
    2369:      	movq	%rcx, %r15
    236c:      	movb	%bpl, (%rcx)
    236f:      	leaq	0x1(%rcx), %rdi
    2373:      	movl	$0x4, %eax
    2378:      	movl	%ebp, %esi
    237a:      	callq	*%rax
    237c:      	movq	0x88(%rsp), %rsi
    2384:      	subl	%ebp, %esi
    2386:      	jbe	0x23d3 <generic_retuprobe_filter_arg+0x23d3>
    2388:      	leaq	(%r15,%rbp), %rdi
    238c:      	incq	%rdi
    238f:      	andl	$0xfff, %esi            # imm = 0xFFF
    2395:      	movl	$0x4, %eax
    239a:      	jmp	0x23ce <generic_retuprobe_filter_arg+0x23ce>
    239c:      	movq	%rcx, %r15
    239f:      	movw	%bp, (%rcx)
    23a2:      	leaq	0x2(%rcx), %rdi
    23a6:      	movl	$0x4, %eax
    23ab:      	movl	%ebp, %esi
    23ad:      	callq	*%rax
    23af:      	movq	0x88(%rsp), %rsi
    23b7:      	subl	%ebp, %esi
    23b9:      	jbe	0x23d3 <generic_retuprobe_filter_arg+0x23d3>
    23bb:      	leaq	(%r15,%rbp), %rdi
    23bf:      	addq	$0x2, %rdi
    23c3:      	andl	$0xfff, %esi            # imm = 0xFFF
    23c9:      	movl	$0x4, %eax
    23ce:      	movq	%rbx, %rdx
    23d1:      	callq	*%rax
    23d3:      	movl	0x6c(%rsp), %eax
    23d7:      	movl	%eax, 0x38(%rsp)
    23db:      	movl	0x18(%rsp), %eax
    23df:      	cmpl	$0x4, %eax
    23e2:      	movq	(%rsp), %rdi
    23e6:      	movq	0x8(%rsp), %r9
    23eb:      	movq	0x10(%rsp), %r11
    23f0:      	jle	0x242c <generic_retuprobe_filter_arg+0x242c>
    23f2:      	cmpl	$0x7, %eax
    23f5:      	jg	0x2a6d <generic_retuprobe_filter_arg+0x2a6d>
    23fb:      	cmpl	$0x5, %eax
    23fe:      	je	0x3111 <generic_retuprobe_filter_arg+0x3111>
    2404:      	cmpl	$0x6, %eax
    2407:      	je	0x30d8 <generic_retuprobe_filter_arg+0x30d8>
    240d:      	cmpl	$0x7, %eax
    2410:      	jne	0x911 <generic_retuprobe_filter_arg+0x911>
    2416:      	movl	$0x1, %eax
    241b:      	leaq	0x38(%rsp), %rsi
    2420:      	movq	(%rip), %rdi            # 0x2427 <generic_retuprobe_filter_arg+0x2427>
    2427:      	jmp	0x3135 <generic_retuprobe_filter_arg+0x3135>
    242c:      	cmpl	$0x1, %eax
    242f:      	jle	0x2ba6 <generic_retuprobe_filter_arg+0x2ba6>
    2435:      	cmpl	$0x2, %eax
    2438:      	je	0x30fe <generic_retuprobe_filter_arg+0x30fe>
    243e:      	cmpl	$0x3, %eax
    2441:      	je	0x30c5 <generic_retuprobe_filter_arg+0x30c5>
    2447:      	cmpl	$0x4, %eax
    244a:      	jne	0x911 <generic_retuprobe_filter_arg+0x911>
    2450:      	movl	$0x1, %eax
    2455:      	leaq	0x38(%rsp), %rsi
    245a:      	movq	(%rip), %rdi            # 0x2461 <generic_retuprobe_filter_arg+0x2461>
    2461:      	jmp	0x3135 <generic_retuprobe_filter_arg+0x3135>
    2466:      	movl	$0xa, %eax
    246b:      	jmp	0x2479 <generic_retuprobe_filter_arg+0x2479>
    246d:      	movl	$0x6, %eax
    2472:      	jmp	0x2479 <generic_retuprobe_filter_arg+0x2479>
    2474:      	movl	$0x8, %eax
    2479:      	movl	%eax, %ecx
    247b:      	andl	$0xf, %ecx
    247e:      	movl	0x10(%r12,%rcx,4), %ecx
    2483:      	cmpl	$-0x1, %ecx
    2486:      	je	0x2d90 <generic_retuprobe_filter_arg+0x2d90>
    248c:      	movl	%ecx, 0x6c(%rsp)
    2490:      	movl	%eax, 0x60(%rsp)
    2494:      	movq	%r8, 0x18(%rsp)
    2499:      	movq	%rsi, 0x88(%rsp)
    24a1:      	movl	$0x1, %eax
    24a6:      	movq	(%rip), %rdi            # 0x24ad <generic_retuprobe_filter_arg+0x24ad>
    24ad:      	movq	0x20(%rsp), %rbx
    24b2:      	movq	%rbx, %rsi
    24b5:      	callq	*%rax
    24b7:      	movq	%rax, %r15
    24ba:      	movl	$0x1, %eax
    24bf:      	movq	(%rip), %rdi            # 0x24c6 <generic_retuprobe_filter_arg+0x24c6>
    24c6:      	movq	%rbx, %rsi
    24c9:      	callq	*%rax
    24cb:      	testq	%r15, %r15
    24ce:      	je	0x3261 <generic_retuprobe_filter_arg+0x3261>
    24d4:      	movl	$0x0, %ebx
    24d9:      	testq	%rax, %rax
    24dc:      	movq	(%rsp), %rdi
    24e0:      	movq	0x8(%rsp), %r9
    24e5:      	movq	0x10(%rsp), %r11
    24ea:      	je	0x3271 <generic_retuprobe_filter_arg+0x3271>
    24f0:      	movq	%r15, %rcx
    24f3:      	movq	%rax, %r15
    24f6:      	cmpl	$0x5, 0x60(%rsp)
    24fb:      	jg	0x2537 <generic_retuprobe_filter_arg+0x2537>
    24fd:      	movb	%bpl, (%rcx)
    2500:      	movq	%rcx, %rbp
    2503:      	leaq	0x1(%rcx), %rdi
    2507:      	movl	$0x4, %eax
    250c:      	movq	0x88(%rsp), %rbx
    2514:      	movq	0x18(%rsp), %rdx
    2519:      	movl	%ebx, %esi
    251b:      	callq	*%rax
    251d:      	subl	%ebx, %r13d
    2520:      	jbe	0x2578 <generic_retuprobe_filter_arg+0x2578>
    2522:      	leaq	(%rbx,%rbp), %rdi
    2526:      	incq	%rdi
    2529:      	andl	$0xfff, %r13d           # imm = 0xFFF
    2530:      	movl	$0x4, %eax
    2535:      	jmp	0x2570 <generic_retuprobe_filter_arg+0x2570>
    2537:      	movq	0x88(%rsp), %rbx
    253f:      	movq	%rcx, %rbp
    2542:      	movw	%bx, (%rcx)
    2545:      	leaq	0x2(%rcx), %rdi
    2549:      	movl	$0x4, %eax
    254e:      	movq	0x18(%rsp), %rdx
    2553:      	movl	%ebx, %esi
    2555:      	callq	*%rax
    2557:      	subl	%ebx, %r13d
    255a:      	jbe	0x2578 <generic_retuprobe_filter_arg+0x2578>
    255c:      	leaq	(%rbx,%rbp), %rdi
    2560:      	addq	$0x2, %rdi
    2564:      	andl	$0xfff, %r13d           # imm = 0xFFF
    256b:      	movl	$0x4, %eax
    2570:      	movl	%r13d, %esi
    2573:      	movq	%r15, %rdx
    2576:      	callq	*%rax
    2578:      	movl	0x6c(%rsp), %eax
    257c:      	movl	%eax, 0x38(%rsp)
    2580:      	movl	0x60(%rsp), %eax
    2584:      	cmpl	$0x4, %eax
    2587:      	movq	(%rsp), %rdi
    258b:      	movq	0x8(%rsp), %r9
    2590:      	movq	0x10(%rsp), %r11
    2595:      	jle	0x25d1 <generic_retuprobe_filter_arg+0x25d1>
    2597:      	cmpl	$0x7, %eax
    259a:      	jg	0x2aba <generic_retuprobe_filter_arg+0x2aba>
    25a0:      	cmpl	$0x5, %eax
    25a3:      	je	0x321f <generic_retuprobe_filter_arg+0x321f>
    25a9:      	cmpl	$0x6, %eax
    25ac:      	je	0x31e6 <generic_retuprobe_filter_arg+0x31e6>
    25b2:      	cmpl	$0x7, %eax
    25b5:      	jne	0x2d90 <generic_retuprobe_filter_arg+0x2d90>
    25bb:      	movl	$0x1, %eax
    25c0:      	leaq	0x38(%rsp), %rsi
    25c5:      	movq	(%rip), %rdi            # 0x25cc <generic_retuprobe_filter_arg+0x25cc>
    25cc:      	jmp	0x3243 <generic_retuprobe_filter_arg+0x3243>
    25d1:      	cmpl	$0x1, %eax
    25d4:      	jle	0x2d6d <generic_retuprobe_filter_arg+0x2d6d>
    25da:      	cmpl	$0x2, %eax
    25dd:      	je	0x320c <generic_retuprobe_filter_arg+0x320c>
    25e3:      	cmpl	$0x3, %eax
    25e6:      	je	0x31d3 <generic_retuprobe_filter_arg+0x31d3>
    25ec:      	cmpl	$0x4, %eax
    25ef:      	jne	0x2d90 <generic_retuprobe_filter_arg+0x2d90>
    25f5:      	movl	$0x1, %eax
    25fa:      	leaq	0x38(%rsp), %rsi
    25ff:      	movq	(%rip), %rdi            # 0x2606 <generic_retuprobe_filter_arg+0x2606>
    2606:      	jmp	0x3243 <generic_retuprobe_filter_arg+0x3243>
    260b:      	movl	$0x1, %ebx
    2610:      	movq	0x28(%rsp), %r13
    2615:      	movq	(%rsp), %rdi
    2619:      	jmp	0x3351 <generic_retuprobe_filter_arg+0x3351>
    261e:      	movl	$0x1, %ebx
    2623:      	movq	0x28(%rsp), %r13
    2628:      	movq	(%rsp), %rdi
    262c:      	movq	0x8(%rsp), %r9
    2631:      	jmp	0x3351 <generic_retuprobe_filter_arg+0x3351>
    2636:      	cmpl	%edx, %r8d
    2639:      	setbe	%r8b
    263d:      	cmpl	%edi, %edx
    263f:      	setbe	%dil
    2643:      	andb	%r8b, %dil
    2646:      	orb	%dil, %al
    2649:      	cmpl	$0x19, %esi
    264c:      	jb	0x2fe2 <generic_retuprobe_filter_arg+0x2fe2>
    2652:      	movl	0x20(%r12), %r8d
    2657:      	movl	0x24(%r12), %edi
    265c:      	cmpl	$0xc, %ecx
    265f:      	ja	0x2bfe <generic_retuprobe_filter_arg+0x2bfe>
    2665:      	movl	$0x1402, %r10d          # imm = 0x1402
    266b:      	btl	%ecx, %r10d
    266f:      	jae	0x2bfe <generic_retuprobe_filter_arg+0x2bfe>
    2675:      	cmpl	%edx, %r8d
    2678:      	setle	%r8b
    267c:      	cmpl	%edi, %edx
    267e:      	setle	%dil
    2682:      	jmp	0x2c0b <generic_retuprobe_filter_arg+0x2c0b>
    2687:      	xorl	%ebx, %ebx
    2689:      	movq	0x28(%rsp), %r13
    268e:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
    2693:      	cmpl	%eax, %edi
    2695:      	movq	(%rsp), %rdi
    2699:      	ja	0x26a3 <generic_retuprobe_filter_arg+0x26a3>
    269b:      	cmpl	%esi, %eax
    269d:      	jbe	0x271 <generic_retuprobe_filter_arg+0x271>
    26a3:      	cmpl	$0x19, %edx
    26a6:      	jb	0xb8 <generic_retuprobe_filter_arg+0xb8>
    26ac:      	movl	0x20(%r12), %edi
    26b1:      	movl	0x24(%r12), %esi
    26b6:      	cmpl	$0xc, %ecx
    26b9:      	ja	0x2c56 <generic_retuprobe_filter_arg+0x2c56>
    26bf:      	movl	$0x1402, %r8d           # imm = 0x1402
    26c5:      	btl	%ecx, %r8d
    26c9:      	jae	0x2c56 <generic_retuprobe_filter_arg+0x2c56>
    26cf:      	cmpl	%eax, %edi
    26d1:      	movq	(%rsp), %rdi
    26d5:      	jg	0x2c66 <generic_retuprobe_filter_arg+0x2c66>
    26db:      	cmpl	%esi, %eax
    26dd:      	jle	0x271 <generic_retuprobe_filter_arg+0x271>
    26e3:      	jmp	0x2c66 <generic_retuprobe_filter_arg+0x2c66>
    26e8:      	movl	$0x100, %esi            # imm = 0x100
    26ed:      	cmpl	$0x101, %eax            # imm = 0x101
    26f2:      	jb	0x2720 <generic_retuprobe_filter_arg+0x2720>
    26f4:      	movl	$0x200, %esi            # imm = 0x200
    26f9:      	cmpl	$0x201, %eax            # imm = 0x201
    26fe:      	jb	0x2720 <generic_retuprobe_filter_arg+0x2720>
    2700:      	movl	$0x400, %esi            # imm = 0x400
    2705:      	cmpl	$0x401, %eax            # imm = 0x401
    270a:      	jb	0x2720 <generic_retuprobe_filter_arg+0x2720>
    270c:      	xorl	%esi, %esi
    270e:      	cmpl	$0x801, %eax            # imm = 0x801
    2713:      	setae	%sil
    2717:      	shll	$0xb, %esi
    271a:      	addl	$0x800, %esi            # imm = 0x800
    2720:      	leal	-0x100(%rsi), %eax
    2726:      	rorxl	$0x8, %eax, %eax
    272c:      	cmpl	$0x2, %eax
    272f:      	jg	0x2af5 <generic_retuprobe_filter_arg+0x2af5>
    2735:      	testl	%eax, %eax
    2737:      	je	0x2e46 <generic_retuprobe_filter_arg+0x2e46>
    273d:      	cmpl	$0x1, %eax
    2740:      	jne	0x2e3f <generic_retuprobe_filter_arg+0x2e3f>
    2746:      	movl	$0x7, %eax
    274b:      	jmp	0x2e52 <generic_retuprobe_filter_arg+0x2e52>
    2750:      	cmpq	%rdx, %r8
    2753:      	setbe	%r8b
    2757:      	cmpq	%rdi, %rdx
    275a:      	setbe	%dil
    275e:      	andb	%r8b, %dil
    2761:      	orb	%dil, %al
    2764:      	cmpl	$0x39, %esi
    2767:      	jb	0x2fe2 <generic_retuprobe_filter_arg+0x2fe2>
    276d:      	movq	0x40(%r12), %rdi
    2772:      	movq	0x48(%r12), %rsi
    2777:      	cmpl	$0xc, %ecx
    277a:      	je	0x2785 <generic_retuprobe_filter_arg+0x2785>
    277c:      	cmpl	$0xa, %ecx
    277f:      	jne	0x2d5f <generic_retuprobe_filter_arg+0x2d5f>
    2785:      	cmpq	%rdx, %rdi
    2788:      	setle	%cl
    278b:      	cmpq	%rsi, %rdx
    278e:      	jmp	0x2c44 <generic_retuprobe_filter_arg+0x2c44>
    2793:      	movq	(%rsp), %rdi
    2797:      	movq	0x8(%rsp), %r9
    279c:      	movq	0x10(%rsp), %r11
    27a1:      	jmp	0x19ed <generic_retuprobe_filter_arg+0x19ed>
    27a6:      	cmpq	%rax, %rdi
    27a9:      	movq	(%rsp), %rdi
    27ad:      	ja	0x27b8 <generic_retuprobe_filter_arg+0x27b8>
    27af:      	cmpq	%rsi, %rax
    27b2:      	jbe	0x271 <generic_retuprobe_filter_arg+0x271>
    27b8:      	cmpl	$0x39, %edx
    27bb:      	jb	0xb8 <generic_retuprobe_filter_arg+0xb8>
    27c1:      	movq	0x40(%r12), %rsi
    27c6:      	movq	0x48(%r12), %rdx
    27cb:      	cmpl	$0xc, %ecx
    27ce:      	je	0x27d9 <generic_retuprobe_filter_arg+0x27d9>
    27d0:      	cmpl	$0xa, %ecx
    27d3:      	jne	0x2da6 <generic_retuprobe_filter_arg+0x2da6>
    27d9:      	cmpq	%rax, %rsi
    27dc:      	jg	0xb8 <generic_retuprobe_filter_arg+0xb8>
    27e2:      	cmpq	%rdx, %rax
    27e5:      	jle	0x271 <generic_retuprobe_filter_arg+0x271>
    27eb:      	jmp	0xb8 <generic_retuprobe_filter_arg+0xb8>
    27f0:      	cmpq	%rsi, (%r15)
    27f3:      	ja	0x271 <generic_retuprobe_filter_arg+0x271>
    27f9:      	jmp	0x2804 <generic_retuprobe_filter_arg+0x2804>
    27fb:      	cmpq	%rsi, (%r15)
    27fe:      	jb	0x271 <generic_retuprobe_filter_arg+0x271>
    2804:      	cmpl	$0x19, %edx
    2807:      	jb	0x36a7 <generic_retuprobe_filter_arg+0x36a7>
    280d:      	movq	0x20(%r12), %rsi
    2812:      	cmpl	$0x2, %eax
    2815:      	jle	0x2831 <generic_retuprobe_filter_arg+0x2831>
    2817:      	leal	-0x3(%rax), %edi
    281a:      	cmpl	$0x2, %edi
    281d:      	jae	0x285f <generic_retuprobe_filter_arg+0x285f>
    281f:      	cmpq	%rsi, (%r15)
    2822:      	movq	(%rsp), %rdi
    2826:      	je	0x24f <generic_retuprobe_filter_arg+0x24f>
    282c:      	jmp	0x3007 <generic_retuprobe_filter_arg+0x3007>
    2831:      	cmpl	$0x1, %eax
    2834:      	je	0x2a9e <generic_retuprobe_filter_arg+0x2a9e>
    283a:      	cmpl	$0x2, %eax
    283d:      	jne	0x3007 <generic_retuprobe_filter_arg+0x3007>
    2843:      	cmpl	$0xc, %ecx
    2846:      	je	0x2851 <generic_retuprobe_filter_arg+0x2851>
    2848:      	cmpl	$0xa, %ecx
    284b:      	jne	0x2ffe <generic_retuprobe_filter_arg+0x2ffe>
    2851:      	cmpq	%rsi, (%r15)
    2854:      	jl	0x271 <generic_retuprobe_filter_arg+0x271>
    285a:      	jmp	0x3007 <generic_retuprobe_filter_arg+0x3007>
    285f:      	cmpl	$0xc, %eax
    2862:      	movq	(%rsp), %rdi
    2866:      	jne	0x3007 <generic_retuprobe_filter_arg+0x3007>
    286c:      	testq	%rsi, (%r15)
    286f:      	jne	0x271 <generic_retuprobe_filter_arg+0x271>
    2875:      	jmp	0x3007 <generic_retuprobe_filter_arg+0x3007>
    287a:      	movl	$0xa, %eax
    287f:      	jmp	0x288d <generic_retuprobe_filter_arg+0x288d>
    2881:      	movl	$0x6, %eax
    2886:      	jmp	0x288d <generic_retuprobe_filter_arg+0x288d>
    2888:      	movl	$0x8, %eax
    288d:      	movl	%eax, %ecx
    288f:      	andl	$0xf, %ecx
    2892:      	movl	0x10(%r12,%rcx,4), %ecx
    2897:      	cmpl	$-0x1, %ecx
    289a:      	je	0x2e26 <generic_retuprobe_filter_arg+0x2e26>
    28a0:      	movl	%ecx, 0x6c(%rsp)
    28a4:      	movl	%eax, 0x88(%rsp)
    28ab:      	movq	%rsi, 0x98(%rsp)
    28b3:      	movl	$0x1, %eax
    28b8:      	movq	(%rip), %rdi            # 0x28bf <generic_retuprobe_filter_arg+0x28bf>
    28bf:      	movq	0x20(%rsp), %rbx
    28c4:      	movq	%rbx, %rsi
    28c7:      	callq	*%rax
    28c9:      	movq	%rax, %r15
    28cc:      	movl	$0x1, %eax
    28d1:      	movq	(%rip), %rdi            # 0x28d8 <generic_retuprobe_filter_arg+0x28d8>
    28d8:      	movq	%rbx, %rsi
    28db:      	callq	*%rax
    28dd:      	movq	%r15, 0x60(%rsp)
    28e2:      	testq	%r15, %r15
    28e5:      	je	0x3341 <generic_retuprobe_filter_arg+0x3341>
    28eb:      	movl	$0x0, %ebx
    28f0:      	testq	%rax, %rax
    28f3:      	movq	(%rsp), %rdi
    28f7:      	movq	0x8(%rsp), %r9
    28fc:      	movq	0x10(%rsp), %r11
    2901:      	je	0x3351 <generic_retuprobe_filter_arg+0x3351>
    2907:      	movq	%rax, %r15
    290a:      	movl	0x88(%rsp), %ebx
    2911:      	cmpl	$0x5, %ebx
    2914:      	jg	0x2958 <generic_retuprobe_filter_arg+0x2958>
    2916:      	movq	0x60(%rsp), %rax
    291b:      	movb	%bpl, (%rax)
    291e:      	leaq	0x1(%rax), %rdi
    2922:      	movl	$0x4, %eax
    2927:      	movq	0x18(%rsp), %rdx
    292c:      	movl	%ebp, %esi
    292e:      	callq	*%rax
    2930:      	movq	0x98(%rsp), %rsi
    2938:      	subl	%ebp, %esi
    293a:      	jbe	0x299b <generic_retuprobe_filter_arg+0x299b>
    293c:      	movq	0x60(%rsp), %rax
    2941:      	leaq	(%rax,%rbp), %rdi
    2945:      	incq	%rdi
    2948:      	andl	$0xfff, %esi            # imm = 0xFFF
    294e:      	movl	$0x4, %eax
    2953:      	movq	%r15, %rdx
    2956:      	jmp	0x2999 <generic_retuprobe_filter_arg+0x2999>
    2958:      	movq	0x60(%rsp), %rax
    295d:      	movw	%bp, (%rax)
    2960:      	leaq	0x2(%rax), %rdi
    2964:      	movl	$0x4, %eax
    2969:      	movq	0x18(%rsp), %rdx
    296e:      	movl	%ebp, %esi
    2970:      	callq	*%rax
    2972:      	movq	0x98(%rsp), %rsi
    297a:      	subl	%ebp, %esi
    297c:      	jbe	0x299b <generic_retuprobe_filter_arg+0x299b>
    297e:      	movq	0x60(%rsp), %rax
    2983:      	leaq	(%rax,%rbp), %rdi
    2987:      	addq	$0x2, %rdi
    298b:      	andl	$0xfff, %esi            # imm = 0xFFF
    2991:      	movl	$0x4, %eax
    2996:      	movq	%r15, %rdx
    2999:      	callq	*%rax
    299b:      	movl	0x6c(%rsp), %eax
    299f:      	movl	%eax, 0x38(%rsp)
    29a3:      	cmpl	$0x4, %ebx
    29a6:      	movq	0x8(%rsp), %r9
    29ab:      	movq	0x10(%rsp), %r11
    29b0:      	jle	0x29ec <generic_retuprobe_filter_arg+0x29ec>
    29b2:      	cmpl	$0x7, %ebx
    29b5:      	jg	0x2bcd <generic_retuprobe_filter_arg+0x2bcd>
    29bb:      	cmpl	$0x5, %ebx
    29be:      	je	0x32fd <generic_retuprobe_filter_arg+0x32fd>
    29c4:      	cmpl	$0x6, %ebx
    29c7:      	je	0x32c4 <generic_retuprobe_filter_arg+0x32c4>
    29cd:      	cmpl	$0x7, %ebx
    29d0:      	jne	0x2e26 <generic_retuprobe_filter_arg+0x2e26>
    29d6:      	movl	$0x1, %eax
    29db:      	leaq	0x38(%rsp), %rsi
    29e0:      	movq	(%rip), %rdi            # 0x29e7 <generic_retuprobe_filter_arg+0x29e7>
    29e7:      	jmp	0x3321 <generic_retuprobe_filter_arg+0x3321>
    29ec:      	cmpl	$0x1, %ebx
    29ef:      	jle	0x2e03 <generic_retuprobe_filter_arg+0x2e03>
    29f5:      	cmpl	$0x2, %ebx
    29f8:      	je	0x32ea <generic_retuprobe_filter_arg+0x32ea>
    29fe:      	cmpl	$0x3, %ebx
    2a01:      	je	0x32b1 <generic_retuprobe_filter_arg+0x32b1>
    2a07:      	cmpl	$0x4, %ebx
    2a0a:      	jne	0x2e26 <generic_retuprobe_filter_arg+0x2e26>
    2a10:      	movl	$0x1, %eax
    2a15:      	leaq	0x38(%rsp), %rsi
    2a1a:      	movq	(%rip), %rdi            # 0x2a21 <generic_retuprobe_filter_arg+0x2a21>
    2a21:      	jmp	0x3321 <generic_retuprobe_filter_arg+0x3321>
    2a26:      	movq	(%rsp), %rdi
    2a2a:      	movq	0x8(%rsp), %r9
    2a2f:      	movq	0x10(%rsp), %r11
    2a34:      	jmp	0x1bc6 <generic_retuprobe_filter_arg+0x1bc6>
    2a39:      	cmpl	$0xc, %eax
    2a3c:      	jne	0x2b1d <generic_retuprobe_filter_arg+0x2b1d>
    2a42:      	movzbl	(%r15), %esi
    2a46:      	testl	%esi, %edx
    2a48:      	jne	0x271 <generic_retuprobe_filter_arg+0x271>
    2a4e:      	jmp	0x2b1d <generic_retuprobe_filter_arg+0x2b1d>
    2a53:      	cmpl	$0xc, %eax
    2a56:      	jne	0x2b5d <generic_retuprobe_filter_arg+0x2b5d>
    2a5c:      	movzwl	(%r15), %esi
    2a60:      	testl	%esi, %edx
    2a62:      	jne	0x271 <generic_retuprobe_filter_arg+0x271>
    2a68:      	jmp	0x2b5d <generic_retuprobe_filter_arg+0x2b5d>
    2a6d:      	cmpl	$0x8, %eax
    2a70:      	je	0x3124 <generic_retuprobe_filter_arg+0x3124>
    2a76:      	cmpl	$0x9, %eax
    2a79:      	je	0x30eb <generic_retuprobe_filter_arg+0x30eb>
    2a7f:      	cmpl	$0xa, %eax
    2a82:      	jne	0x911 <generic_retuprobe_filter_arg+0x911>
    2a88:      	movl	$0x1, %eax
    2a8d:      	leaq	0x38(%rsp), %rsi
    2a92:      	movq	(%rip), %rdi            # 0x2a99 <generic_retuprobe_filter_arg+0x2a99>
    2a99:      	jmp	0x3135 <generic_retuprobe_filter_arg+0x3135>
    2a9e:      	cmpl	$0xc, %ecx
    2aa1:      	je	0x2aac <generic_retuprobe_filter_arg+0x2aac>
    2aa3:      	cmpl	$0xa, %ecx
    2aa6:      	jne	0x2ff3 <generic_retuprobe_filter_arg+0x2ff3>
    2aac:      	cmpq	%rsi, (%r15)
    2aaf:      	jg	0x271 <generic_retuprobe_filter_arg+0x271>
    2ab5:      	jmp	0x3007 <generic_retuprobe_filter_arg+0x3007>
    2aba:      	cmpl	$0x8, %eax
    2abd:      	je	0x3232 <generic_retuprobe_filter_arg+0x3232>
    2ac3:      	cmpl	$0x9, %eax
    2ac6:      	je	0x31f9 <generic_retuprobe_filter_arg+0x31f9>
    2acc:      	cmpl	$0xa, %eax
    2acf:      	jne	0x2d90 <generic_retuprobe_filter_arg+0x2d90>
    2ad5:      	movl	$0x1, %eax
    2ada:      	leaq	0x38(%rsp), %rsi
    2adf:      	movq	(%rip), %rdi            # 0x2ae6 <generic_retuprobe_filter_arg+0x2ae6>
    2ae6:      	jmp	0x3243 <generic_retuprobe_filter_arg+0x3243>
    2aeb:      	movq	0x28(%rsp), %r13
    2af0:      	jmp	0x19ca <generic_retuprobe_filter_arg+0x19ca>
    2af5:      	cmpl	$0x3, %eax
    2af8:      	je	0x2e4d <generic_retuprobe_filter_arg+0x2e4d>
    2afe:      	cmpl	$0x7, %eax
    2b01:      	jne	0x2e3f <generic_retuprobe_filter_arg+0x2e3f>
    2b07:      	movl	$0x9, %eax
    2b0c:      	jmp	0x2e52 <generic_retuprobe_filter_arg+0x2e52>
    2b11:      	movzbl	(%r15), %esi
    2b15:      	cmpl	%esi, %edx
    2b17:      	jb	0x271 <generic_retuprobe_filter_arg+0x271>
    2b1d:      	cmpl	$0x11, %ecx
    2b20:      	jb	0x36a7 <generic_retuprobe_filter_arg+0x36a7>
    2b26:      	movl	0x18(%r12), %edx
    2b2b:      	cmpl	$0x2, %eax
    2b2e:      	jle	0x2dbd <generic_retuprobe_filter_arg+0x2dbd>
    2b34:      	leal	-0x3(%rax), %esi
    2b37:      	cmpl	$0x2, %esi
    2b3a:      	jae	0x307e <generic_retuprobe_filter_arg+0x307e>
    2b40:      	movzbl	(%r15), %esi
    2b44:      	cmpl	%esi, %edx
    2b46:      	je	0x24f <generic_retuprobe_filter_arg+0x24f>
    2b4c:      	jmp	0x3385 <generic_retuprobe_filter_arg+0x3385>
    2b51:      	movzwl	(%r15), %esi
    2b55:      	cmpl	%esi, %edx
    2b57:      	jb	0x271 <generic_retuprobe_filter_arg+0x271>
    2b5d:      	cmpl	$0x11, %ecx
    2b60:      	jb	0x36a7 <generic_retuprobe_filter_arg+0x36a7>
    2b66:      	movl	0x18(%r12), %edx
    2b6b:      	cmpl	$0x2, %eax
    2b6e:      	jle	0x2de0 <generic_retuprobe_filter_arg+0x2de0>
    2b74:      	leal	-0x3(%rax), %esi
    2b77:      	cmpl	$0x2, %esi
    2b7a:      	jae	0x3098 <generic_retuprobe_filter_arg+0x3098>
    2b80:      	movzwl	(%r15), %esi
    2b84:      	cmpl	%esi, %edx
    2b86:      	je	0x24f <generic_retuprobe_filter_arg+0x24f>
    2b8c:      	jmp	0x33cc <generic_retuprobe_filter_arg+0x33cc>
    2b91:      	xorl	%ebx, %ebx
    2b93:      	movq	0x8(%rsp), %r9
    2b98:      	movq	0x10(%rsp), %r11
    2b9d:      	movq	(%rsp), %rdi
    2ba1:      	jmp	0x3640 <generic_retuprobe_filter_arg+0x3640>
    2ba6:      	testl	%eax, %eax
    2ba8:      	je	0x30b2 <generic_retuprobe_filter_arg+0x30b2>
    2bae:      	cmpl	$0x1, %eax
    2bb1:      	jne	0x911 <generic_retuprobe_filter_arg+0x911>
    2bb7:      	movl	$0x1, %eax
    2bbc:      	leaq	0x38(%rsp), %rsi
    2bc1:      	movq	(%rip), %rdi            # 0x2bc8 <generic_retuprobe_filter_arg+0x2bc8>
    2bc8:      	jmp	0x3135 <generic_retuprobe_filter_arg+0x3135>
    2bcd:      	cmpl	$0x8, %ebx
    2bd0:      	je	0x3310 <generic_retuprobe_filter_arg+0x3310>
    2bd6:      	cmpl	$0x9, %ebx
    2bd9:      	je	0x32d7 <generic_retuprobe_filter_arg+0x32d7>
    2bdf:      	cmpl	$0xa, %ebx
    2be2:      	jne	0x2e26 <generic_retuprobe_filter_arg+0x2e26>
    2be8:      	movl	$0x1, %eax
    2bed:      	leaq	0x38(%rsp), %rsi
    2bf2:      	movq	(%rip), %rdi            # 0x2bf9 <generic_retuprobe_filter_arg+0x2bf9>
    2bf9:      	jmp	0x3321 <generic_retuprobe_filter_arg+0x3321>
    2bfe:      	cmpl	%edx, %r8d
    2c01:      	setbe	%r8b
    2c05:      	cmpl	%edi, %edx
    2c07:      	setbe	%dil
    2c0b:      	andb	%r8b, %dil
    2c0e:      	orb	%dil, %al
    2c11:      	cmpl	$0x21, %esi
    2c14:      	jb	0x2fe2 <generic_retuprobe_filter_arg+0x2fe2>
    2c1a:      	movl	0x28(%r12), %edi
    2c1f:      	movl	0x2c(%r12), %esi
    2c24:      	cmpl	$0xc, %ecx
    2c27:      	ja	0x2fd4 <generic_retuprobe_filter_arg+0x2fd4>
    2c2d:      	movl	$0x1402, %r8d           # imm = 0x1402
    2c33:      	btl	%ecx, %r8d
    2c37:      	jae	0x2fd4 <generic_retuprobe_filter_arg+0x2fd4>
    2c3d:      	cmpl	%edx, %edi
    2c3f:      	setle	%cl
    2c42:      	cmpl	%esi, %edx
    2c44:      	setle	%dl
    2c47:      	jmp	0x2fde <generic_retuprobe_filter_arg+0x2fde>
    2c4c:      	movl	$0x1, %ebx
    2c51:      	jmp	0x3632 <generic_retuprobe_filter_arg+0x3632>
    2c56:      	cmpl	%eax, %edi
    2c58:      	movq	(%rsp), %rdi
    2c5c:      	ja	0x2c66 <generic_retuprobe_filter_arg+0x2c66>
    2c5e:      	cmpl	%esi, %eax
    2c60:      	jbe	0x271 <generic_retuprobe_filter_arg+0x271>
    2c66:      	cmpl	$0x21, %edx
    2c69:      	jb	0xb8 <generic_retuprobe_filter_arg+0xb8>
    2c6f:      	movl	0x28(%r12), %esi
    2c74:      	movl	0x2c(%r12), %edx
    2c79:      	cmpl	$0xc, %ecx
    2c7c:      	ja	0x318f <generic_retuprobe_filter_arg+0x318f>
    2c82:      	movl	$0x1402, %r8d           # imm = 0x1402
    2c88:      	btl	%ecx, %r8d
    2c8c:      	jae	0x318f <generic_retuprobe_filter_arg+0x318f>
    2c92:      	cmpl	%eax, %esi
    2c94:      	jg	0xb8 <generic_retuprobe_filter_arg+0xb8>
    2c9a:      	cmpl	%edx, %eax
    2c9c:      	jle	0x271 <generic_retuprobe_filter_arg+0x271>
    2ca2:      	jmp	0xb8 <generic_retuprobe_filter_arg+0xb8>
    2ca7:      	cmpl	%esi, (%r15)
    2caa:      	ja	0x271 <generic_retuprobe_filter_arg+0x271>
    2cb0:      	jmp	0x2cbb <generic_retuprobe_filter_arg+0x2cbb>
    2cb2:      	cmpl	%esi, (%r15)
    2cb5:      	jb	0x271 <generic_retuprobe_filter_arg+0x271>
    2cbb:      	cmpl	$0x11, %edx
    2cbe:      	jb	0x36a7 <generic_retuprobe_filter_arg+0x36a7>
    2cc4:      	movl	0x18(%r12), %esi
    2cc9:      	cmpl	$0x2, %eax
    2ccc:      	jle	0x2ce8 <generic_retuprobe_filter_arg+0x2ce8>
    2cce:      	leal	-0x3(%rax), %edi
    2cd1:      	cmpl	$0x2, %edi
    2cd4:      	jae	0x2d1d <generic_retuprobe_filter_arg+0x2d1d>
    2cd6:      	cmpl	%esi, (%r15)
    2cd9:      	movq	(%rsp), %rdi
    2cdd:      	je	0x24f <generic_retuprobe_filter_arg+0x24f>
    2ce3:      	jmp	0x3457 <generic_retuprobe_filter_arg+0x3457>
    2ce8:      	cmpl	$0x1, %eax
    2ceb:      	je	0x2d38 <generic_retuprobe_filter_arg+0x2d38>
    2ced:      	cmpl	$0x2, %eax
    2cf0:      	jne	0x3457 <generic_retuprobe_filter_arg+0x3457>
    2cf6:      	cmpl	$0xc, %ecx
    2cf9:      	ja	0x344e <generic_retuprobe_filter_arg+0x344e>
    2cff:      	movl	$0x1402, %r8d           # imm = 0x1402
    2d05:      	btl	%ecx, %r8d
    2d09:      	jae	0x344e <generic_retuprobe_filter_arg+0x344e>
    2d0f:      	cmpl	%esi, (%r15)
    2d12:      	jl	0x271 <generic_retuprobe_filter_arg+0x271>
    2d18:      	jmp	0x3457 <generic_retuprobe_filter_arg+0x3457>
    2d1d:      	cmpl	$0xc, %eax
    2d20:      	movq	(%rsp), %rdi
    2d24:      	jne	0x3457 <generic_retuprobe_filter_arg+0x3457>
    2d2a:      	testl	%esi, (%r15)
    2d2d:      	jne	0x271 <generic_retuprobe_filter_arg+0x271>
    2d33:      	jmp	0x3457 <generic_retuprobe_filter_arg+0x3457>
    2d38:      	cmpl	$0xc, %ecx
    2d3b:      	ja	0x3443 <generic_retuprobe_filter_arg+0x3443>
    2d41:      	movl	$0x1402, %r8d           # imm = 0x1402
    2d47:      	btl	%ecx, %r8d
    2d4b:      	jae	0x3443 <generic_retuprobe_filter_arg+0x3443>
    2d51:      	cmpl	%esi, (%r15)
    2d54:      	jg	0x271 <generic_retuprobe_filter_arg+0x271>
    2d5a:      	jmp	0x3457 <generic_retuprobe_filter_arg+0x3457>
    2d5f:      	cmpq	%rdx, %rdi
    2d62:      	setbe	%cl
    2d65:      	cmpq	%rsi, %rdx
    2d68:      	jmp	0x2fdb <generic_retuprobe_filter_arg+0x2fdb>
    2d6d:      	testl	%eax, %eax
    2d6f:      	je	0x31c0 <generic_retuprobe_filter_arg+0x31c0>
    2d75:      	cmpl	$0x1, %eax
    2d78:      	jne	0x2d90 <generic_retuprobe_filter_arg+0x2d90>
    2d7a:      	movl	$0x1, %eax
    2d7f:      	leaq	0x38(%rsp), %rsi
    2d84:      	movq	(%rip), %rdi            # 0x2d8b <generic_retuprobe_filter_arg+0x2d8b>
    2d8b:      	jmp	0x3243 <generic_retuprobe_filter_arg+0x3243>
    2d90:      	xorl	%ebx, %ebx
    2d92:      	movl	0x4(%r12), %eax
    2d97:      	cmpq	$0x25, %rax
    2d9b:      	jbe	0x3280 <generic_retuprobe_filter_arg+0x3280>
    2da1:      	jmp	0x1bc9 <generic_retuprobe_filter_arg+0x1bc9>
    2da6:      	cmpq	%rax, %rsi
    2da9:      	ja	0xb8 <generic_retuprobe_filter_arg+0xb8>
    2daf:      	cmpq	%rdx, %rax
    2db2:      	jbe	0x271 <generic_retuprobe_filter_arg+0x271>
    2db8:      	jmp	0xb8 <generic_retuprobe_filter_arg+0xb8>
    2dbd:      	cmpl	$0x1, %eax
    2dc0:      	je	0x3379 <generic_retuprobe_filter_arg+0x3379>
    2dc6:      	cmpl	$0x2, %eax
    2dc9:      	jne	0x3385 <generic_retuprobe_filter_arg+0x3385>
    2dcf:      	movzbl	(%r15), %esi
    2dd3:      	cmpl	%esi, %edx
    2dd5:      	ja	0x271 <generic_retuprobe_filter_arg+0x271>
    2ddb:      	jmp	0x3385 <generic_retuprobe_filter_arg+0x3385>
    2de0:      	cmpl	$0x1, %eax
    2de3:      	je	0x33c0 <generic_retuprobe_filter_arg+0x33c0>
    2de9:      	cmpl	$0x2, %eax
    2dec:      	jne	0x33cc <generic_retuprobe_filter_arg+0x33cc>
    2df2:      	movzwl	(%r15), %esi
    2df6:      	cmpl	%esi, %edx
    2df8:      	ja	0x271 <generic_retuprobe_filter_arg+0x271>
    2dfe:      	jmp	0x33cc <generic_retuprobe_filter_arg+0x33cc>
    2e03:      	testl	%ebx, %ebx
    2e05:      	je	0x329e <generic_retuprobe_filter_arg+0x329e>
    2e0b:      	cmpl	$0x1, %ebx
    2e0e:      	jne	0x2e26 <generic_retuprobe_filter_arg+0x2e26>
    2e10:      	movl	$0x1, %eax
    2e15:      	leaq	0x38(%rsp), %rsi
    2e1a:      	movq	(%rip), %rdi            # 0x2e21 <generic_retuprobe_filter_arg+0x2e21>
    2e21:      	jmp	0x3321 <generic_retuprobe_filter_arg+0x3321>
    2e26:      	xorl	%ebx, %ebx
    2e28:      	movq	(%rsp), %rdi
    2e2c:      	jmp	0x3351 <generic_retuprobe_filter_arg+0x3351>
    2e31:      	movl	$0x1, %ebx
    2e36:      	movq	(%rsp), %rdi
    2e3a:      	jmp	0x3640 <generic_retuprobe_filter_arg+0x3640>
    2e3f:      	movl	$0xa, %eax
    2e44:      	jmp	0x2e52 <generic_retuprobe_filter_arg+0x2e52>
    2e46:      	movl	$0x6, %eax
    2e4b:      	jmp	0x2e52 <generic_retuprobe_filter_arg+0x2e52>
    2e4d:      	movl	$0x8, %eax
    2e52:      	movl	%eax, %ecx
    2e54:      	andl	$0xf, %ecx
    2e57:      	movl	0x10(%r12,%rcx,4), %ecx
    2e5c:      	cmpl	$-0x1, %ecx
    2e5f:      	je	0x3630 <generic_retuprobe_filter_arg+0x3630>
    2e65:      	movl	%ecx, 0x6c(%rsp)
    2e69:      	movl	%eax, 0x88(%rsp)
    2e70:      	movq	%rsi, 0x60(%rsp)
    2e75:      	movl	$0x1, %eax
    2e7a:      	movq	(%rip), %rdi            # 0x2e81 <generic_retuprobe_filter_arg+0x2e81>
    2e81:      	movq	0x20(%rsp), %rbx
    2e86:      	movq	%rbx, %rsi
    2e89:      	callq	*%rax
    2e8b:      	movq	%rax, %r15
    2e8e:      	movl	$0x1, %eax
    2e93:      	movq	(%rip), %rdi            # 0x2e9a <generic_retuprobe_filter_arg+0x2e9a>
    2e9a:      	movq	%rbx, %rsi
    2e9d:      	callq	*%rax
    2e9f:      	movq	%r15, 0x18(%rsp)
    2ea4:      	testq	%r15, %r15
    2ea7:      	je	0x3630 <generic_retuprobe_filter_arg+0x3630>
    2ead:      	movl	$0x0, %ebx
    2eb2:      	testq	%rax, %rax
    2eb5:      	movq	(%rsp), %rdi
    2eb9:      	movq	0x8(%rsp), %r9
    2ebe:      	movq	0x10(%rsp), %r11
    2ec3:      	je	0x3640 <generic_retuprobe_filter_arg+0x3640>
    2ec9:      	movq	%rax, %r15
    2ecc:      	movl	0x88(%rsp), %ebx
    2ed3:      	cmpl	$0x5, %ebx
    2ed6:      	jg	0x2f15 <generic_retuprobe_filter_arg+0x2f15>
    2ed8:      	movq	0x18(%rsp), %rax
    2edd:      	movb	%bpl, (%rax)
    2ee0:      	leaq	0x1(%rax), %rdi
    2ee4:      	movl	$0x4, %eax
    2ee9:      	movl	%ebp, %esi
    2eeb:      	movq	%r13, %rdx
    2eee:      	callq	*%rax
    2ef0:      	movq	0x60(%rsp), %rsi
    2ef5:      	subl	%ebp, %esi
    2ef7:      	jbe	0x2f53 <generic_retuprobe_filter_arg+0x2f53>
    2ef9:      	movq	0x18(%rsp), %rax
    2efe:      	leaq	(%rax,%rbp), %rdi
    2f02:      	incq	%rdi
    2f05:      	andl	$0xfff, %esi            # imm = 0xFFF
    2f0b:      	movl	$0x4, %eax
    2f10:      	movq	%r15, %rdx
    2f13:      	jmp	0x2f51 <generic_retuprobe_filter_arg+0x2f51>
    2f15:      	movq	0x18(%rsp), %rax
    2f1a:      	movw	%bp, (%rax)
    2f1d:      	leaq	0x2(%rax), %rdi
    2f21:      	movl	$0x4, %eax
    2f26:      	movl	%ebp, %esi
    2f28:      	movq	%r13, %rdx
    2f2b:      	callq	*%rax
    2f2d:      	movq	0x60(%rsp), %rsi
    2f32:      	subl	%ebp, %esi
    2f34:      	jbe	0x2f53 <generic_retuprobe_filter_arg+0x2f53>
    2f36:      	movq	0x18(%rsp), %rax
    2f3b:      	leaq	(%rax,%rbp), %rdi
    2f3f:      	addq	$0x2, %rdi
    2f43:      	andl	$0xfff, %esi            # imm = 0xFFF
    2f49:      	movl	$0x4, %eax
    2f4e:      	movq	%r15, %rdx
    2f51:      	callq	*%rax
    2f53:      	movl	0x6c(%rsp), %eax
    2f57:      	movl	%eax, 0x38(%rsp)
    2f5b:      	cmpl	$0x4, %ebx
    2f5e:      	jle	0x2f9a <generic_retuprobe_filter_arg+0x2f9a>
    2f60:      	cmpl	$0x7, %ebx
    2f63:      	jg	0x3412 <generic_retuprobe_filter_arg+0x3412>
    2f69:      	cmpl	$0x5, %ebx
    2f6c:      	je	0x35ec <generic_retuprobe_filter_arg+0x35ec>
    2f72:      	cmpl	$0x6, %ebx
    2f75:      	je	0x35b3 <generic_retuprobe_filter_arg+0x35b3>
    2f7b:      	cmpl	$0x7, %ebx
    2f7e:      	jne	0x3630 <generic_retuprobe_filter_arg+0x3630>
    2f84:      	movl	$0x1, %eax
    2f89:      	leaq	0x38(%rsp), %rsi
    2f8e:      	movq	(%rip), %rdi            # 0x2f95 <generic_retuprobe_filter_arg+0x2f95>
    2f95:      	jmp	0x3610 <generic_retuprobe_filter_arg+0x3610>
    2f9a:      	cmpl	$0x1, %ebx
    2f9d:      	jle	0x34f8 <generic_retuprobe_filter_arg+0x34f8>
    2fa3:      	cmpl	$0x2, %ebx
    2fa6:      	je	0x35d9 <generic_retuprobe_filter_arg+0x35d9>
    2fac:      	cmpl	$0x3, %ebx
    2faf:      	je	0x35a0 <generic_retuprobe_filter_arg+0x35a0>
    2fb5:      	cmpl	$0x4, %ebx
    2fb8:      	jne	0x3630 <generic_retuprobe_filter_arg+0x3630>
    2fbe:      	movl	$0x1, %eax
    2fc3:      	leaq	0x38(%rsp), %rsi
    2fc8:      	movq	(%rip), %rdi            # 0x2fcf <generic_retuprobe_filter_arg+0x2fcf>
    2fcf:      	jmp	0x3610 <generic_retuprobe_filter_arg+0x3610>
    2fd4:      	cmpl	%edx, %edi
    2fd6:      	setbe	%cl
    2fd9:      	cmpl	%esi, %edx
    2fdb:      	setbe	%dl
    2fde:      	andb	%cl, %dl
    2fe0:      	orb	%dl, %al
    2fe2:      	movq	(%rsp), %rdi
    2fe6:      	testb	%al, %al
    2fe8:      	je	0x271 <generic_retuprobe_filter_arg+0x271>
    2fee:      	jmp	0xb8 <generic_retuprobe_filter_arg+0xb8>
    2ff3:      	cmpq	%rsi, (%r15)
    2ff6:      	ja	0x271 <generic_retuprobe_filter_arg+0x271>
    2ffc:      	jmp	0x3007 <generic_retuprobe_filter_arg+0x3007>
    2ffe:      	cmpq	%rsi, (%r15)
    3001:      	jb	0x271 <generic_retuprobe_filter_arg+0x271>
    3007:      	cmpl	$0x21, %edx
    300a:      	jb	0x36a7 <generic_retuprobe_filter_arg+0x36a7>
    3010:      	movq	0x28(%r12), %rdx
    3015:      	cmpl	$0x2, %eax
    3018:      	jle	0x3042 <generic_retuprobe_filter_arg+0x3042>
    301a:      	leal	-0x3(%rax), %ecx
    301d:      	cmpl	$0x2, %ecx
    3020:      	jb	0x3070 <generic_retuprobe_filter_arg+0x3070>
    3022:      	cmpl	$0x6, %eax
    3025:      	je	0x271 <generic_retuprobe_filter_arg+0x271>
    302b:      	cmpl	$0xc, %eax
    302e:      	jne	0xb8 <generic_retuprobe_filter_arg+0xb8>
    3034:      	testq	%rdx, (%r15)
    3037:      	jne	0x271 <generic_retuprobe_filter_arg+0x271>
    303d:      	jmp	0x36a7 <generic_retuprobe_filter_arg+0x36a7>
    3042:      	cmpl	$0x1, %eax
    3045:      	je	0x31a4 <generic_retuprobe_filter_arg+0x31a4>
    304b:      	cmpl	$0x2, %eax
    304e:      	jne	0xb8 <generic_retuprobe_filter_arg+0xb8>
    3054:      	cmpl	$0xc, %ecx
    3057:      	je	0x3062 <generic_retuprobe_filter_arg+0x3062>
    3059:      	cmpl	$0xa, %ecx
    305c:      	jne	0x3571 <generic_retuprobe_filter_arg+0x3571>
    3062:      	cmpq	%rdx, (%r15)
    3065:      	jl	0x271 <generic_retuprobe_filter_arg+0x271>
    306b:      	jmp	0x36a7 <generic_retuprobe_filter_arg+0x36a7>
    3070:      	cmpq	%rdx, (%r15)
    3073:      	jne	0x36a7 <generic_retuprobe_filter_arg+0x36a7>
    3079:      	jmp	0x24f <generic_retuprobe_filter_arg+0x24f>
    307e:      	cmpl	$0xc, %eax
    3081:      	jne	0x3385 <generic_retuprobe_filter_arg+0x3385>
    3087:      	movzbl	(%r15), %esi
    308b:      	testl	%esi, %edx
    308d:      	jne	0x271 <generic_retuprobe_filter_arg+0x271>
    3093:      	jmp	0x3385 <generic_retuprobe_filter_arg+0x3385>
    3098:      	cmpl	$0xc, %eax
    309b:      	jne	0x33cc <generic_retuprobe_filter_arg+0x33cc>
    30a1:      	movzwl	(%r15), %esi
    30a5:      	testl	%esi, %edx
    30a7:      	jne	0x271 <generic_retuprobe_filter_arg+0x271>
    30ad:      	jmp	0x33cc <generic_retuprobe_filter_arg+0x33cc>
    30b2:      	movl	$0x1, %eax
    30b7:      	movq	(%rip), %rdi            # 0x30be <generic_retuprobe_filter_arg+0x30be>
    30be:      	leaq	0x38(%rsp), %rsi
    30c3:      	jmp	0x3135 <generic_retuprobe_filter_arg+0x3135>
    30c5:      	movl	$0x1, %eax
    30ca:      	leaq	0x38(%rsp), %rsi
    30cf:      	movq	(%rip), %rdi            # 0x30d6 <generic_retuprobe_filter_arg+0x30d6>
    30d6:      	jmp	0x3135 <generic_retuprobe_filter_arg+0x3135>
    30d8:      	movl	$0x1, %eax
    30dd:      	leaq	0x38(%rsp), %rsi
    30e2:      	movq	(%rip), %rdi            # 0x30e9 <generic_retuprobe_filter_arg+0x30e9>
    30e9:      	jmp	0x3135 <generic_retuprobe_filter_arg+0x3135>
    30eb:      	movl	$0x1, %eax
    30f0:      	leaq	0x38(%rsp), %rsi
    30f5:      	movq	(%rip), %rdi            # 0x30fc <generic_retuprobe_filter_arg+0x30fc>
    30fc:      	jmp	0x3135 <generic_retuprobe_filter_arg+0x3135>
    30fe:      	movl	$0x1, %eax
    3103:      	leaq	0x38(%rsp), %rsi
    3108:      	movq	(%rip), %rdi            # 0x310f <generic_retuprobe_filter_arg+0x310f>
    310f:      	jmp	0x3135 <generic_retuprobe_filter_arg+0x3135>
    3111:      	movl	$0x1, %eax
    3116:      	leaq	0x38(%rsp), %rsi
    311b:      	movq	(%rip), %rdi            # 0x3122 <generic_retuprobe_filter_arg+0x3122>
    3122:      	jmp	0x3135 <generic_retuprobe_filter_arg+0x3135>
    3124:      	movl	$0x1, %eax
    3129:      	leaq	0x38(%rsp), %rsi
    312e:      	movq	(%rip), %rdi            # 0x3135 <generic_retuprobe_filter_arg+0x3135>
    3135:      	callq	*%rax
    3137:      	testq	%rax, %rax
    313a:      	je	0x3153 <generic_retuprobe_filter_arg+0x3153>
    313c:      	movq	%rax, %rdi
    313f:      	movl	$0x1, %eax
    3144:      	movq	%r15, %rsi
    3147:      	callq	*%rax
    3149:      	xorl	%ebx, %ebx
    314b:      	testq	%rax, %rax
    314e:      	setne	%bl
    3151:      	jmp	0x3155 <generic_retuprobe_filter_arg+0x3155>
    3153:      	xorl	%ebx, %ebx
    3155:      	movq	(%rsp), %rdi
    3159:      	movq	0x8(%rsp), %r9
    315e:      	movq	0x10(%rsp), %r11
    3163:      	movl	0x4(%r12), %eax
    3168:      	cmpq	$0x25, %rax
    316c:      	ja	0x260 <generic_retuprobe_filter_arg+0x260>
    3172:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    317c:      	btq	%rax, %rcx
    3180:      	jae	0x260 <generic_retuprobe_filter_arg+0x260>
    3186:      	xorq	$0x1, %rbx
    318a:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
    318f:      	cmpl	%eax, %esi
    3191:      	ja	0xb8 <generic_retuprobe_filter_arg+0xb8>
    3197:      	cmpl	%edx, %eax
    3199:      	jbe	0x271 <generic_retuprobe_filter_arg+0x271>
    319f:      	jmp	0xb8 <generic_retuprobe_filter_arg+0xb8>
    31a4:      	cmpl	$0xc, %ecx
    31a7:      	je	0x31b2 <generic_retuprobe_filter_arg+0x31b2>
    31a9:      	cmpl	$0xa, %ecx
    31ac:      	jne	0x357f <generic_retuprobe_filter_arg+0x357f>
    31b2:      	cmpq	%rdx, (%r15)
    31b5:      	jg	0x271 <generic_retuprobe_filter_arg+0x271>
    31bb:      	jmp	0x36a7 <generic_retuprobe_filter_arg+0x36a7>
    31c0:      	movl	$0x1, %eax
    31c5:      	movq	(%rip), %rdi            # 0x31cc <generic_retuprobe_filter_arg+0x31cc>
    31cc:      	leaq	0x38(%rsp), %rsi
    31d1:      	jmp	0x3243 <generic_retuprobe_filter_arg+0x3243>
    31d3:      	movl	$0x1, %eax
    31d8:      	leaq	0x38(%rsp), %rsi
    31dd:      	movq	(%rip), %rdi            # 0x31e4 <generic_retuprobe_filter_arg+0x31e4>
    31e4:      	jmp	0x3243 <generic_retuprobe_filter_arg+0x3243>
    31e6:      	movl	$0x1, %eax
    31eb:      	leaq	0x38(%rsp), %rsi
    31f0:      	movq	(%rip), %rdi            # 0x31f7 <generic_retuprobe_filter_arg+0x31f7>
    31f7:      	jmp	0x3243 <generic_retuprobe_filter_arg+0x3243>
    31f9:      	movl	$0x1, %eax
    31fe:      	leaq	0x38(%rsp), %rsi
    3203:      	movq	(%rip), %rdi            # 0x320a <generic_retuprobe_filter_arg+0x320a>
    320a:      	jmp	0x3243 <generic_retuprobe_filter_arg+0x3243>
    320c:      	movl	$0x1, %eax
    3211:      	leaq	0x38(%rsp), %rsi
    3216:      	movq	(%rip), %rdi            # 0x321d <generic_retuprobe_filter_arg+0x321d>
    321d:      	jmp	0x3243 <generic_retuprobe_filter_arg+0x3243>
    321f:      	movl	$0x1, %eax
    3224:      	leaq	0x38(%rsp), %rsi
    3229:      	movq	(%rip), %rdi            # 0x3230 <generic_retuprobe_filter_arg+0x3230>
    3230:      	jmp	0x3243 <generic_retuprobe_filter_arg+0x3243>
    3232:      	movl	$0x1, %eax
    3237:      	leaq	0x38(%rsp), %rsi
    323c:      	movq	(%rip), %rdi            # 0x3243 <generic_retuprobe_filter_arg+0x3243>
    3243:      	callq	*%rax
    3245:      	testq	%rax, %rax
    3248:      	je	0x3261 <generic_retuprobe_filter_arg+0x3261>
    324a:      	movq	%rax, %rdi
    324d:      	movl	$0x1, %eax
    3252:      	movq	%rbp, %rsi
    3255:      	callq	*%rax
    3257:      	xorl	%ebx, %ebx
    3259:      	testq	%rax, %rax
    325c:      	setne	%bl
    325f:      	jmp	0x3263 <generic_retuprobe_filter_arg+0x3263>
    3261:      	xorl	%ebx, %ebx
    3263:      	movq	(%rsp), %rdi
    3267:      	movq	0x8(%rsp), %r9
    326c:      	movq	0x10(%rsp), %r11
    3271:      	movl	0x4(%r12), %eax
    3276:      	cmpq	$0x25, %rax
    327a:      	ja	0x1bc9 <generic_retuprobe_filter_arg+0x1bc9>
    3280:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    328a:      	btq	%rax, %rcx
    328e:      	movq	0x28(%rsp), %r13
    3293:      	jb	0x3186 <generic_retuprobe_filter_arg+0x3186>
    3299:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
    329e:      	movl	$0x1, %eax
    32a3:      	movq	(%rip), %rdi            # 0x32aa <generic_retuprobe_filter_arg+0x32aa>
    32aa:      	leaq	0x38(%rsp), %rsi
    32af:      	jmp	0x3321 <generic_retuprobe_filter_arg+0x3321>
    32b1:      	movl	$0x1, %eax
    32b6:      	leaq	0x38(%rsp), %rsi
    32bb:      	movq	(%rip), %rdi            # 0x32c2 <generic_retuprobe_filter_arg+0x32c2>
    32c2:      	jmp	0x3321 <generic_retuprobe_filter_arg+0x3321>
    32c4:      	movl	$0x1, %eax
    32c9:      	leaq	0x38(%rsp), %rsi
    32ce:      	movq	(%rip), %rdi            # 0x32d5 <generic_retuprobe_filter_arg+0x32d5>
    32d5:      	jmp	0x3321 <generic_retuprobe_filter_arg+0x3321>
    32d7:      	movl	$0x1, %eax
    32dc:      	leaq	0x38(%rsp), %rsi
    32e1:      	movq	(%rip), %rdi            # 0x32e8 <generic_retuprobe_filter_arg+0x32e8>
    32e8:      	jmp	0x3321 <generic_retuprobe_filter_arg+0x3321>
    32ea:      	movl	$0x1, %eax
    32ef:      	leaq	0x38(%rsp), %rsi
    32f4:      	movq	(%rip), %rdi            # 0x32fb <generic_retuprobe_filter_arg+0x32fb>
    32fb:      	jmp	0x3321 <generic_retuprobe_filter_arg+0x3321>
    32fd:      	movl	$0x1, %eax
    3302:      	leaq	0x38(%rsp), %rsi
    3307:      	movq	(%rip), %rdi            # 0x330e <generic_retuprobe_filter_arg+0x330e>
    330e:      	jmp	0x3321 <generic_retuprobe_filter_arg+0x3321>
    3310:      	movl	$0x1, %eax
    3315:      	leaq	0x38(%rsp), %rsi
    331a:      	movq	(%rip), %rdi            # 0x3321 <generic_retuprobe_filter_arg+0x3321>
    3321:      	callq	*%rax
    3323:      	testq	%rax, %rax
    3326:      	je	0x3341 <generic_retuprobe_filter_arg+0x3341>
    3328:      	movq	%rax, %rdi
    332b:      	movl	$0x1, %eax
    3330:      	movq	0x60(%rsp), %rsi
    3335:      	callq	*%rax
    3337:      	xorl	%ebx, %ebx
    3339:      	testq	%rax, %rax
    333c:      	setne	%bl
    333f:      	jmp	0x3343 <generic_retuprobe_filter_arg+0x3343>
    3341:      	xorl	%ebx, %ebx
    3343:      	movq	(%rsp), %rdi
    3347:      	movq	0x8(%rsp), %r9
    334c:      	movq	0x10(%rsp), %r11
    3351:      	movl	0x4(%r12), %eax
    3356:      	cmpq	$0x25, %rax
    335a:      	ja	0x260 <generic_retuprobe_filter_arg+0x260>
    3360:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    336a:      	btq	%rax, %rcx
    336e:      	jb	0x3668 <generic_retuprobe_filter_arg+0x3668>
    3374:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
    3379:      	movzbl	(%r15), %esi
    337d:      	cmpl	%esi, %edx
    337f:      	jb	0x271 <generic_retuprobe_filter_arg+0x271>
    3385:      	cmpl	$0x15, %ecx
    3388:      	jb	0x36a7 <generic_retuprobe_filter_arg+0x36a7>
    338e:      	movl	0x1c(%r12), %ecx
    3393:      	cmpl	$0x2, %eax
    3396:      	jle	0x351f <generic_retuprobe_filter_arg+0x351f>
    339c:      	leal	-0x3(%rax), %edx
    339f:      	cmpl	$0x2, %edx
    33a2:      	jb	0x355a <generic_retuprobe_filter_arg+0x355a>
    33a8:      	cmpl	$0x6, %eax
    33ab:      	je	0x271 <generic_retuprobe_filter_arg+0x271>
    33b1:      	cmpl	$0xc, %eax
    33b4:      	jne	0xb8 <generic_retuprobe_filter_arg+0xb8>
    33ba:      	movzbl	(%r15), %edx
    33be:      	jmp	0x3405 <generic_retuprobe_filter_arg+0x3405>
    33c0:      	movzwl	(%r15), %esi
    33c4:      	cmpl	%esi, %edx
    33c6:      	jb	0x271 <generic_retuprobe_filter_arg+0x271>
    33cc:      	cmpl	$0x15, %ecx
    33cf:      	jb	0x36a7 <generic_retuprobe_filter_arg+0x36a7>
    33d5:      	movl	0x1c(%r12), %ecx
    33da:      	cmpl	$0x2, %eax
    33dd:      	jle	0x3537 <generic_retuprobe_filter_arg+0x3537>
    33e3:      	leal	-0x3(%rax), %edx
    33e6:      	cmpl	$0x2, %edx
    33e9:      	jb	0x3560 <generic_retuprobe_filter_arg+0x3560>
    33ef:      	cmpl	$0x6, %eax
    33f2:      	je	0x271 <generic_retuprobe_filter_arg+0x271>
    33f8:      	cmpl	$0xc, %eax
    33fb:      	jne	0xb8 <generic_retuprobe_filter_arg+0xb8>
    3401:      	movzwl	(%r15), %edx
    3405:      	testl	%edx, %ecx
    3407:      	jne	0x271 <generic_retuprobe_filter_arg+0x271>
    340d:      	jmp	0x36a7 <generic_retuprobe_filter_arg+0x36a7>
    3412:      	cmpl	$0x8, %ebx
    3415:      	je	0x35ff <generic_retuprobe_filter_arg+0x35ff>
    341b:      	cmpl	$0x9, %ebx
    341e:      	je	0x35c6 <generic_retuprobe_filter_arg+0x35c6>
    3424:      	cmpl	$0xa, %ebx
    3427:      	jne	0x3630 <generic_retuprobe_filter_arg+0x3630>
    342d:      	movl	$0x1, %eax
    3432:      	leaq	0x38(%rsp), %rsi
    3437:      	movq	(%rip), %rdi            # 0x343e <generic_retuprobe_filter_arg+0x343e>
    343e:      	jmp	0x3610 <generic_retuprobe_filter_arg+0x3610>
    3443:      	cmpl	%esi, (%r15)
    3446:      	ja	0x271 <generic_retuprobe_filter_arg+0x271>
    344c:      	jmp	0x3457 <generic_retuprobe_filter_arg+0x3457>
    344e:      	cmpl	%esi, (%r15)
    3451:      	jb	0x271 <generic_retuprobe_filter_arg+0x271>
    3457:      	cmpl	$0x15, %edx
    345a:      	jb	0x36a7 <generic_retuprobe_filter_arg+0x36a7>
    3460:      	movl	0x1c(%r12), %edx
    3465:      	cmpl	$0x2, %eax
    3468:      	jle	0x3492 <generic_retuprobe_filter_arg+0x3492>
    346a:      	leal	-0x3(%rax), %ecx
    346d:      	cmpl	$0x2, %ecx
    3470:      	jb	0x34c5 <generic_retuprobe_filter_arg+0x34c5>
    3472:      	cmpl	$0x6, %eax
    3475:      	je	0x271 <generic_retuprobe_filter_arg+0x271>
    347b:      	cmpl	$0xc, %eax
    347e:      	jne	0xb8 <generic_retuprobe_filter_arg+0xb8>
    3484:      	testl	%edx, (%r15)
    3487:      	jne	0x271 <generic_retuprobe_filter_arg+0x271>
    348d:      	jmp	0x36a7 <generic_retuprobe_filter_arg+0x36a7>
    3492:      	cmpl	$0x1, %eax
    3495:      	je	0x34d3 <generic_retuprobe_filter_arg+0x34d3>
    3497:      	cmpl	$0x2, %eax
    349a:      	jne	0xb8 <generic_retuprobe_filter_arg+0xb8>
    34a0:      	cmpl	$0xc, %ecx
    34a3:      	ja	0x3693 <generic_retuprobe_filter_arg+0x3693>
    34a9:      	movl	$0x1402, %esi           # imm = 0x1402
    34ae:      	btl	%ecx, %esi
    34b1:      	jae	0x3693 <generic_retuprobe_filter_arg+0x3693>
    34b7:      	cmpl	%edx, (%r15)
    34ba:      	jl	0x271 <generic_retuprobe_filter_arg+0x271>
    34c0:      	jmp	0x36a7 <generic_retuprobe_filter_arg+0x36a7>
    34c5:      	cmpl	%edx, (%r15)
    34c8:      	je	0x24f <generic_retuprobe_filter_arg+0x24f>
    34ce:      	jmp	0x36a7 <generic_retuprobe_filter_arg+0x36a7>
    34d3:      	cmpl	$0xc, %ecx
    34d6:      	ja	0x369e <generic_retuprobe_filter_arg+0x369e>
    34dc:      	movl	$0x1402, %esi           # imm = 0x1402
    34e1:      	btl	%ecx, %esi
    34e4:      	jae	0x369e <generic_retuprobe_filter_arg+0x369e>
    34ea:      	cmpl	%edx, (%r15)
    34ed:      	jg	0x271 <generic_retuprobe_filter_arg+0x271>
    34f3:      	jmp	0x36a7 <generic_retuprobe_filter_arg+0x36a7>
    34f8:      	testl	%ebx, %ebx
    34fa:      	je	0x358d <generic_retuprobe_filter_arg+0x358d>
    3500:      	cmpl	$0x1, %ebx
    3503:      	jne	0x3630 <generic_retuprobe_filter_arg+0x3630>
    3509:      	movl	$0x1, %eax
    350e:      	leaq	0x38(%rsp), %rsi
    3513:      	movq	(%rip), %rdi            # 0x351a <generic_retuprobe_filter_arg+0x351a>
    351a:      	jmp	0x3610 <generic_retuprobe_filter_arg+0x3610>
    351f:      	cmpl	$0x1, %eax
    3522:      	je	0x367f <generic_retuprobe_filter_arg+0x367f>
    3528:      	cmpl	$0x2, %eax
    352b:      	jne	0xb8 <generic_retuprobe_filter_arg+0xb8>
    3531:      	movzbl	(%r15), %edx
    3535:      	jmp	0x354d <generic_retuprobe_filter_arg+0x354d>
    3537:      	cmpl	$0x1, %eax
    353a:      	je	0x3685 <generic_retuprobe_filter_arg+0x3685>
    3540:      	cmpl	$0x2, %eax
    3543:      	jne	0xb8 <generic_retuprobe_filter_arg+0xb8>
    3549:      	movzwl	(%r15), %edx
    354d:      	cmpl	%edx, %ecx
    354f:      	ja	0x271 <generic_retuprobe_filter_arg+0x271>
    3555:      	jmp	0x36a7 <generic_retuprobe_filter_arg+0x36a7>
    355a:      	movzbl	(%r15), %edx
    355e:      	jmp	0x3564 <generic_retuprobe_filter_arg+0x3564>
    3560:      	movzwl	(%r15), %edx
    3564:      	cmpl	%edx, %ecx
    3566:      	je	0x24f <generic_retuprobe_filter_arg+0x24f>
    356c:      	jmp	0x36a7 <generic_retuprobe_filter_arg+0x36a7>
    3571:      	cmpq	%rdx, (%r15)
    3574:      	jb	0x271 <generic_retuprobe_filter_arg+0x271>
    357a:      	jmp	0x36a7 <generic_retuprobe_filter_arg+0x36a7>
    357f:      	cmpq	%rdx, (%r15)
    3582:      	ja	0x271 <generic_retuprobe_filter_arg+0x271>
    3588:      	jmp	0x36a7 <generic_retuprobe_filter_arg+0x36a7>
    358d:      	movl	$0x1, %eax
    3592:      	movq	(%rip), %rdi            # 0x3599 <generic_retuprobe_filter_arg+0x3599>
    3599:      	leaq	0x38(%rsp), %rsi
    359e:      	jmp	0x3610 <generic_retuprobe_filter_arg+0x3610>
    35a0:      	movl	$0x1, %eax
    35a5:      	leaq	0x38(%rsp), %rsi
    35aa:      	movq	(%rip), %rdi            # 0x35b1 <generic_retuprobe_filter_arg+0x35b1>
    35b1:      	jmp	0x3610 <generic_retuprobe_filter_arg+0x3610>
    35b3:      	movl	$0x1, %eax
    35b8:      	leaq	0x38(%rsp), %rsi
    35bd:      	movq	(%rip), %rdi            # 0x35c4 <generic_retuprobe_filter_arg+0x35c4>
    35c4:      	jmp	0x3610 <generic_retuprobe_filter_arg+0x3610>
    35c6:      	movl	$0x1, %eax
    35cb:      	leaq	0x38(%rsp), %rsi
    35d0:      	movq	(%rip), %rdi            # 0x35d7 <generic_retuprobe_filter_arg+0x35d7>
    35d7:      	jmp	0x3610 <generic_retuprobe_filter_arg+0x3610>
    35d9:      	movl	$0x1, %eax
    35de:      	leaq	0x38(%rsp), %rsi
    35e3:      	movq	(%rip), %rdi            # 0x35ea <generic_retuprobe_filter_arg+0x35ea>
    35ea:      	jmp	0x3610 <generic_retuprobe_filter_arg+0x3610>
    35ec:      	movl	$0x1, %eax
    35f1:      	leaq	0x38(%rsp), %rsi
    35f6:      	movq	(%rip), %rdi            # 0x35fd <generic_retuprobe_filter_arg+0x35fd>
    35fd:      	jmp	0x3610 <generic_retuprobe_filter_arg+0x3610>
    35ff:      	movl	$0x1, %eax
    3604:      	leaq	0x38(%rsp), %rsi
    3609:      	movq	(%rip), %rdi            # 0x3610 <generic_retuprobe_filter_arg+0x3610>
    3610:      	callq	*%rax
    3612:      	testq	%rax, %rax
    3615:      	je	0x3630 <generic_retuprobe_filter_arg+0x3630>
    3617:      	movq	%rax, %rdi
    361a:      	movl	$0x1, %eax
    361f:      	movq	0x18(%rsp), %rsi
    3624:      	callq	*%rax
    3626:      	xorl	%ebx, %ebx
    3628:      	testq	%rax, %rax
    362b:      	setne	%bl
    362e:      	jmp	0x3632 <generic_retuprobe_filter_arg+0x3632>
    3630:      	xorl	%ebx, %ebx
    3632:      	movq	(%rsp), %rdi
    3636:      	movq	0x8(%rsp), %r9
    363b:      	movq	0x10(%rsp), %r11
    3640:      	movl	0x4(%r12), %eax
    3645:      	cmpq	$0x25, %rax
    3649:      	ja	0x1bc9 <generic_retuprobe_filter_arg+0x1bc9>
    364f:      	movabsq	$0x200c000050, %rcx     # imm = 0x200C000050
    3659:      	btq	%rax, %rcx
    365d:      	movq	0x28(%rsp), %r13
    3662:      	jae	0x260 <generic_retuprobe_filter_arg+0x260>
    3668:      	xorl	%eax, %eax
    366a:      	testq	%rbx, %rbx
    366d:      	sete	%al
    3670:      	movq	%rax, %rbx
    3673:      	jmp	0x260 <generic_retuprobe_filter_arg+0x260>
    3678:      	xorl	%ebx, %ebx
    367a:      	jmp	0xa8a <generic_retuprobe_filter_arg+0xa8a>
    367f:      	movzbl	(%r15), %edx
    3683:      	jmp	0x3689 <generic_retuprobe_filter_arg+0x3689>
    3685:      	movzwl	(%r15), %edx
    3689:      	cmpl	%edx, %ecx
    368b:      	jb	0x271 <generic_retuprobe_filter_arg+0x271>
    3691:      	jmp	0x36a7 <generic_retuprobe_filter_arg+0x36a7>
    3693:      	cmpl	%edx, (%r15)
    3696:      	jb	0x271 <generic_retuprobe_filter_arg+0x271>
    369c:      	jmp	0x36a7 <generic_retuprobe_filter_arg+0x36a7>
    369e:      	cmpl	%edx, (%r15)
    36a1:      	ja	0x271 <generic_retuprobe_filter_arg+0x271>
    36a7:      	orl	$0x2, %eax
    36aa:      	cmpl	$0x6, %eax
    36ad:      	je	0x271 <generic_retuprobe_filter_arg+0x271>
    36b3:      	jmp	0xb8 <generic_retuprobe_filter_arg+0xb8>
    36b8:      	nopl	(%rax,%rax)

00000000000036c0 <generic_retuprobe_actions>:
    36c0:      	pushq	%rbp
    36c1:      	pushq	%r15
    36c3:      	pushq	%r14
    36c5:      	pushq	%r13
    36c7:      	pushq	%r12
    36c9:      	pushq	%rbx
    36ca:      	subq	$0xa8, %rsp
    36d1:      	movq	%rdi, 0x80(%rsp)
    36d9:      	movl	$0x0, 0x88(%rsp)
    36e4:      	movq	(%rip), %rdi            # 0x36eb <generic_retuprobe_actions+0x2b>
    36eb:      	leaq	0x88(%rsp), %rsi
    36f3:      	movl	$0x1, %eax
    36f8:      	callq	*%rax
    36fa:      	testq	%rax, %rax
    36fd:      	je	0x41f8 <generic_retuprobe_actions+0xb38>
    3703:      	movq	%rax, %rsi
    3706:      	movl	0x5f04(%rax), %ebx
    370c:      	cmpl	$0x2, %ebx
    370f:      	jl	0x41f8 <generic_retuprobe_actions+0xb38>
    3715:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    371c:      	movq	(%rip), %rdi            # 0x3723 <generic_retuprobe_actions+0x63>
    3723:      	movl	$0x1, %eax
    3728:      	callq	*%rax
    372a:      	testq	%rax, %rax
    372d:      	je	0x41f8 <generic_retuprobe_actions+0xb38>
    3733:      	movq	%rax, %r14
    3736:      	movl	%ebx, %eax
    3738:      	andl	$0x7ff, %eax            # imm = 0x7FF
    373d:      	addl	(%r14,%rax), %ebx
    3741:      	movl	$0x0, 0x8c(%rsp)
    374c:      	movq	(%rip), %rdi            # 0x3753 <generic_retuprobe_actions+0x93>
    3753:      	leaq	0x8c(%rsp), %rsi
    375b:      	movl	$0x1, %eax
    3760:      	andl	$0x7ff, %ebx            # imm = 0x7FF
    3766:      	callq	*%rax
    3768:      	testq	%rax, %rax
    376b:      	je	0x3792 <generic_retuprobe_actions+0xd2>
    376d:      	cmpb	$0x0, (%rax)
    3770:      	sete	0x17(%rsp)
    3775:      	je	0x37ad <generic_retuprobe_actions+0xed>
    3777:      	movl	$0x5, %eax
    377c:      	movq	%rax, 0x78(%rsp)
    3781:      	movl	$0x9, %eax
    3786:      	movq	%rax, 0x70(%rsp)
    378b:      	movl	$0x7, %eax
    3790:      	jmp	0x37c6 <generic_retuprobe_actions+0x106>
    3792:      	movl	$0x4, %eax
    3797:      	movq	%rax, 0x78(%rsp)
    379c:      	movl	$0x8, %eax
    37a1:      	movq	%rax, 0x70(%rsp)
    37a6:      	movb	$0x1, 0x17(%rsp)
    37ab:      	jmp	0x37c1 <generic_retuprobe_actions+0x101>
    37ad:      	movl	$0x4, %eax
    37b2:      	movq	%rax, 0x78(%rsp)
    37b7:      	movl	$0x8, %eax
    37bc:      	movq	%rax, 0x70(%rsp)
    37c1:      	movl	$0x6, %eax
    37c6:      	movq	%rax, 0x68(%rsp)
    37cb:      	addq	%rbx, %r14
    37ce:      	movb	$0x1, %al
    37d0:      	movl	%eax, 0x44(%rsp)
    37d4:      	movq	(%rip), %rbp            # 0x37db <generic_retuprobe_actions+0x11b>
    37db:      	xorl	%r12d, %r12d
    37de:      	xorl	%r15d, %r15d
    37e1:      	jmp	0x380a <generic_retuprobe_actions+0x14a>
    37e3:      	incl	%r15d
    37e6:      	movl	0x4(%r14,%r15,4), %eax
    37eb:      	movl	%eax, 0x78(%rdx)
    37ee:      	nop
    37f0:      	movq	%r13, 0x70(%rdx)
    37f4:      	incl	%r15d
    37f7:      	movl	%r15d, %ebx
    37fa:      	incl	%r12d
    37fd:      	movl	%ebx, %r15d
    3800:      	cmpl	$0x3, %r12d
    3804:      	je	0x41d1 <generic_retuprobe_actions+0xb11>
    380a:      	leal	0x4(,%r15,4), %eax
    3812:      	cmpl	(%r14), %eax
    3815:      	jae	0x41d1 <generic_retuprobe_actions+0xb11>
    381b:      	movl	%r15d, %eax
    381e:      	movslq	0x4(%r14,%rax,4), %r13
    3823:      	movl	$0x0, 0x90(%rsp)
    382e:      	movl	$0x1, %eax
    3833:      	leaq	0x90(%rsp), %rsi
    383b:      	movq	%rbp, %rdi
    383e:      	callq	*%rax
    3840:      	xorl	%ebx, %ebx
    3842:      	testq	%rax, %rax
    3845:      	je	0x37fa <generic_retuprobe_actions+0x13a>
    3847:      	movq	%rax, %rdx
    384a:      	cmpl	$0x7, %r13d
    384e:      	jg	0x3880 <generic_retuprobe_actions+0x1c0>
    3850:      	cmpl	$0x3, %r13d
    3854:      	jg	0x38d6 <generic_retuprobe_actions+0x216>
    385a:      	cmpl	$0x1, %r13d
    385e:      	jg	0x3a27 <generic_retuprobe_actions+0x367>
    3864:      	testl	%r13d, %r13d
    3867:      	je	0x3c37 <generic_retuprobe_actions+0x577>
    386d:      	cmpl	$0x1, %r13d
    3871:      	je	0x3a40 <generic_retuprobe_actions+0x380>
    3877:      	jmp	0x37f0 <generic_retuprobe_actions+0x130>
    387c:      	nopl	(%rax)
    3880:      	cmpl	$0xb, %r13d
    3884:      	jg	0x39f0 <generic_retuprobe_actions+0x330>
    388a:      	leal	-0xa(%r13), %eax
    388e:      	cmpl	$0x2, %eax
    3891:      	jb	0x3acf <generic_retuprobe_actions+0x40f>
    3897:      	cmpl	$0x8, %r13d
    389b:      	je	0x3b91 <generic_retuprobe_actions+0x4d1>
    38a1:      	cmpl	$0x9, %r13d
    38a5:      	jne	0x37f0 <generic_retuprobe_actions+0x130>
    38ab:      	movq	%r13, 0x8(%rsp)
    38b0:      	movq	%r14, %rax
    38b3:      	movq	%rbp, %r13
    38b6:      	incl	%r15d
    38b9:      	movl	0x4(%r14,%r15,4), %eax
    38be:      	movq	%rdx, %rbp
    38c1:      	movl	$0x3, %ebx
    38c6:      	cmpb	$0x0, 0x17(%rsp)
    38cb:      	jne	0x3d13 <generic_retuprobe_actions+0x653>
    38d1:      	jmp	0x3d38 <generic_retuprobe_actions+0x678>
    38d6:      	leal	-0x6(%r13), %eax
    38da:      	cmpl	$0x2, %eax
    38dd:      	jb	0x37e3 <generic_retuprobe_actions+0x123>
    38e3:      	cmpl	$0x4, %r13d
    38e7:      	je	0x3b9e <generic_retuprobe_actions+0x4de>
    38ed:      	cmpl	$0x5, %r13d
    38f1:      	jne	0x37f0 <generic_retuprobe_actions+0x130>
    38f7:      	leal	0x1(%r15), %eax
    38fb:      	movl	0x4(%r14,%rax,4), %eax
    3900:      	addl	$0x2, %r15d
    3904:      	movl	0x4(%r14,%r15,4), %ebx
    3909:      	movq	$0x0, 0x20(%rsp)
    3912:      	movq	$0x0, 0x18(%rsp)
    391b:      	andl	$0x7, %eax
    391e:      	cmpl	$0x4, %eax
    3921:      	ja	0x37f0 <generic_retuprobe_actions+0x130>
    3927:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    392f:      	jne	0x37f0 <generic_retuprobe_actions+0x130>
    3935:      	movq	0x5e78(%rdx,%rax,8), %rax
    393d:      	andl	$0x7ff, %eax            # imm = 0x7FF
    3942:      	movl	0x90(%rdx,%rax), %eax
    3949:      	movl	%eax, 0x20(%rsp)
    394d:      	movl	$0xe, %eax
    3952:      	movq	%rdx, 0x8(%rsp)
    3957:      	callq	*%rax
    3959:      	shrq	$0x20, %rax
    395d:      	movq	%rax, 0x18(%rsp)
    3962:      	movl	$0x1, %eax
    3967:      	leaq	0x18(%rsp), %rsi
    396c:      	movq	(%rip), %rdi            # 0x3973 <generic_retuprobe_actions+0x2b3>
    3973:      	callq	*%rax
    3975:      	movq	0x8(%rsp), %rdx
    397a:      	testq	%rax, %rax
    397d:      	je	0x37f0 <generic_retuprobe_actions+0x130>
    3983:      	andl	$0x7, %ebx
    3986:      	cmpl	$0x4, %ebx
    3989:      	ja	0x37f0 <generic_retuprobe_actions+0x130>
    398f:      	cmpl	$0x0, 0x5ea0(%rdx,%rbx,4)
    3997:      	jne	0x37f0 <generic_retuprobe_actions+0x130>
    399d:      	movq	0x5e78(%rdx,%rbx,8), %rcx
    39a5:      	movl	$0x0, 0x24(%rsp)
    39ad:      	andl	$0x7ff, %ecx            # imm = 0x7FF
    39b3:      	movl	0x90(%rdx,%rcx), %ecx
    39ba:      	movl	%ecx, 0x20(%rsp)
    39be:      	movq	%rax, %rbx
    39c1:      	movl	$0xe, %eax
    39c6:      	callq	*%rax
    39c8:      	shrq	$0x20, %rax
    39cc:      	movq	%rax, 0x18(%rsp)
    39d1:      	movl	$0x2, %eax
    39d6:      	xorl	%ecx, %ecx
    39d8:      	leaq	0x18(%rsp), %rsi
    39dd:      	movq	(%rip), %rdi            # 0x39e4 <generic_retuprobe_actions+0x324>
    39e4:      	movq	%rbx, %rdx
    39e7:      	xorl	%ecx, %ecx
    39e9:      	callq	*%rax
    39eb:      	jmp	0x3c2d <generic_retuprobe_actions+0x56d>
    39f0:      	cmpl	$0xc, %r13d
    39f4:      	je	0x3d24 <generic_retuprobe_actions+0x664>
    39fa:      	cmpl	$0xd, %r13d
    39fe:      	je	0x3bb6 <generic_retuprobe_actions+0x4f6>
    3a04:      	cmpl	$0xe, %r13d
    3a08:      	jne	0x37f0 <generic_retuprobe_actions+0x130>
    3a0e:      	movq	%r13, 0x8(%rsp)
    3a13:      	movq	%rbp, %r13
    3a16:      	movq	%rdx, %rbp
    3a19:      	addl	$0x2, %r15d
    3a1d:      	movq	0x70(%rsp), %rbx
    3a22:      	jmp	0x3d38 <generic_retuprobe_actions+0x678>
    3a27:      	movl	$0x9, %eax
    3a2c:      	cmpl	$0x2, %r13d
    3a30:      	je	0x3cfc <generic_retuprobe_actions+0x63c>
    3a36:      	cmpl	$0x3, %r13d
    3a3a:      	jne	0x37f0 <generic_retuprobe_actions+0x130>
    3a40:      	movq	%rdx, 0x8(%rsp)
    3a45:      	leal	0x1(%r15), %eax
    3a49:      	movq	%r14, %rcx
    3a4c:      	movl	0x4(%r14,%rax,4), %r14d
    3a51:      	addl	$0x2, %r15d
    3a55:      	movq	%rcx, %rbp
    3a58:      	movl	0x4(%rcx,%r15,4), %eax
    3a5d:      	movq	%rax, 0x38(%rsp)
    3a62:      	movq	$0x0, 0x20(%rsp)
    3a6b:      	movq	$0x0, 0x18(%rsp)
    3a74:      	movl	$0x0, 0x28(%rsp)
    3a7c:      	movl	$0x1, %eax
    3a81:      	leaq	0x28(%rsp), %rsi
    3a86:      	movq	(%rip), %rdi            # 0x3a8d <generic_retuprobe_actions+0x3cd>
    3a8d:      	callq	*%rax
    3a8f:      	xorl	%ecx, %ecx
    3a91:      	testq	%rax, %rax
    3a94:      	je	0x3ec8 <generic_retuprobe_actions+0x808>
    3a9a:      	andl	$0x7, %r14d
    3a9e:      	cmpl	$0x4, %r14d
    3aa2:      	movq	0x8(%rsp), %rdx
    3aa7:      	ja	0x3ab8 <generic_retuprobe_actions+0x3f8>
    3aa9:      	cmpl	$0x0, 0x5ea0(%rdx,%r14,4)
    3ab2:      	je	0x3d6d <generic_retuprobe_actions+0x6ad>
    3ab8:      	movq	%rbp, %r14
    3abb:      	movq	(%rip), %rbp            # 0x3ac2 <generic_retuprobe_actions+0x402>
    3ac2:      	testl	%ecx, %ecx
    3ac4:      	jne	0x37fa <generic_retuprobe_actions+0x13a>
    3aca:      	jmp	0x37f0 <generic_retuprobe_actions+0x130>
    3acf:      	incl	%r15d
    3ad2:      	movl	0x4(%r14,%r15,4), %eax
    3ad7:      	andl	$0x7, %eax
    3ada:      	xorl	%ecx, %ecx
    3adc:      	cmpl	$0x4, %eax
    3adf:      	ja	0x3ed7 <generic_retuprobe_actions+0x817>
    3ae5:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    3aed:      	jne	0x3ed7 <generic_retuprobe_actions+0x817>
    3af3:      	movq	0x5e78(%rdx,%rax,8), %rax
    3afb:      	andl	$0x7ff, %eax            # imm = 0x7FF
    3b00:      	movq	0xb8(%rdx,%rax), %rax
    3b08:      	movq	%rax, 0x28(%rsp)
    3b0d:      	testq	%rax, %rax
    3b10:      	je	0x3ed7 <generic_retuprobe_actions+0x817>
    3b16:      	movq	%rdx, 0x8(%rsp)
    3b1b:      	cmpl	$0xa, %r13d
    3b1f:      	jne	0x3ee4 <generic_retuprobe_actions+0x824>
    3b25:      	movl	$0xe, %eax
    3b2a:      	callq	*%rax
    3b2c:      	movq	%rax, 0x38(%rsp)
    3b31:      	shrq	$0x20, %rax
    3b35:      	movl	%eax, 0x18(%rsp)
    3b39:      	movl	$0x1, %eax
    3b3e:      	leaq	0x18(%rsp), %rsi
    3b43:      	movq	(%rip), %rdi            # 0x3b4a <generic_retuprobe_actions+0x48a>
    3b4a:      	callq	*%rax
    3b4c:      	xorl	%ecx, %ecx
    3b4e:      	testq	%rax, %rax
    3b51:      	movq	0x8(%rsp), %rdx
    3b56:      	je	0x3ed7 <generic_retuprobe_actions+0x817>
    3b5c:      	movl	(%rax), %ecx
    3b5e:      	movl	%ecx, 0x18(%rsp)
    3b62:      	movq	0x38(%rsp), %rcx
    3b67:      	movl	%ecx, 0x1c(%rsp)
    3b6b:      	movq	0x8(%rax), %rax
    3b6f:      	movq	%rax, 0x20(%rsp)
    3b74:      	xorl	%ecx, %ecx
    3b76:      	movl	$0x2, %eax
    3b7b:      	leaq	0x28(%rsp), %rsi
    3b80:      	leaq	0x18(%rsp), %rdx
    3b85:      	movq	(%rip), %rdi            # 0x3b8c <generic_retuprobe_actions+0x4cc>
    3b8c:      	jmp	0x3e30 <generic_retuprobe_actions+0x770>
    3b91:      	movl	$0x0, 0x44(%rsp)
    3b99:      	jmp	0x37f0 <generic_retuprobe_actions+0x130>
    3b9e:      	movq	%r13, 0x8(%rsp)
    3ba3:      	movq	%rbp, %r13
    3ba6:      	movq	%rdx, %rbp
    3ba9:      	incl	%r15d
    3bac:      	movq	0x78(%rsp), %rbx
    3bb1:      	jmp	0x3d38 <generic_retuprobe_actions+0x678>
    3bb6:      	movq	%rdx, 0x8(%rsp)
    3bbb:      	movl	$0xe, %eax
    3bc0:      	callq	*%rax
    3bc2:      	movq	%rax, 0x50(%rsp)
    3bc7:      	movl	$0x1, %eax
    3bcc:      	leaq	0x50(%rsp), %rsi
    3bd1:      	movq	(%rip), %rdi            # 0x3bd8 <generic_retuprobe_actions+0x518>
    3bd8:      	callq	*%rax
    3bda:      	testq	%rax, %rax
    3bdd:      	je	0x3c2d <generic_retuprobe_actions+0x56d>
    3bdf:      	movq	0x4(%rax), %rax
    3be3:      	movq	%rax, 0x28(%rsp)
    3be8:      	movl	$0x2, 0x30(%rsp)
    3bf0:      	movl	$0x1, %eax
    3bf5:      	leaq	0x28(%rsp), %rsi
    3bfa:      	movq	(%rip), %rbx            # 0x3c01 <generic_retuprobe_actions+0x541>
    3c01:      	movq	%rbx, %rdi
    3c04:      	callq	*%rax
    3c06:      	movl	$0x1, 0x5c(%rsp)
    3c0e:      	testq	%rax, %rax
    3c11:      	je	0x3e48 <generic_retuprobe_actions+0x788>
    3c17:      	lock
    3c18:      	incl	(%rax)
    3c1a:      	movl	$0x3, %eax
    3c1f:      	leaq	0x50(%rsp), %rsi
    3c24:      	movq	(%rip), %rdi            # 0x3c2b <generic_retuprobe_actions+0x56b>
    3c2b:      	callq	*%rax
    3c2d:      	movq	0x8(%rsp), %rdx
    3c32:      	jmp	0x37f0 <generic_retuprobe_actions+0x130>
    3c37:      	movq	%rdx, 0x8(%rsp)
    3c3c:      	leal	0x1(%r15), %eax
    3c40:      	movl	0x4(%r14,%rax,4), %ebx
    3c45:      	leal	0x2(%r15), %eax
    3c49:      	movl	0x4(%r14,%rax,4), %eax
    3c4e:      	movl	%eax, 0x60(%rsp)
    3c52:      	movl	$0x7d, %eax
    3c57:      	callq	*%rax
    3c59:      	movq	%rax, 0x18(%rsp)
    3c5e:      	movl	$0x0, 0x50(%rsp)
    3c66:      	movq	%rbx, 0xa0(%rsp)
    3c6e:      	testq	%rbx, %rbx
    3c71:      	je	0x40e8 <generic_retuprobe_actions+0xa28>
    3c77:      	movl	$0x1, %eax
    3c7c:      	movq	(%rip), %rdi            # 0x3c83 <generic_retuprobe_actions+0x5c3>
    3c83:      	leaq	0x50(%rsp), %rsi
    3c88:      	callq	*%rax
    3c8a:      	testq	%rax, %rax
    3c8d:      	je	0x40e8 <generic_retuprobe_actions+0xa28>
    3c93:      	movq	%rax, 0x48(%rsp)
    3c98:      	movq	%rax, %rbx
    3c9b:      	movl	$0x1, %eax
    3ca0:      	leaq	0x50(%rsp), %rsi
    3ca5:      	movq	(%rip), %rdi            # 0x3cac <generic_retuprobe_actions+0x5ec>
    3cac:      	callq	*%rax
    3cae:      	movq	%rax, %rdx
    3cb1:      	movq	0x8(%rsp), %rcx
    3cb6:      	movq	0x60(%rcx), %rax
    3cba:      	movq	%rax, (%rbx)
    3cbd:      	movq	0x70(%rcx), %rax
    3cc1:      	movq	%rax, 0x8(%rbx)
    3cc5:      	xorl	%eax, %eax
    3cc7:      	movq	%rax, 0x38(%rsp)
    3ccc:      	movl	$0x0, %eax
    3cd1:      	movl	0x60(%rsp), %esi
    3cd5:      	cmpl	$0x2, %esi
    3cd8:      	je	0x3f0f <generic_retuprobe_actions+0x84f>
    3cde:      	cmpl	$0x1, %esi
    3ce1:      	je	0x3f0c <generic_retuprobe_actions+0x84c>
    3ce7:      	testl	%esi, %esi
    3ce9:      	jne	0x40e8 <generic_retuprobe_actions+0xa28>
    3cef:      	movq	0x8(%rsp), %rax
    3cf4:      	movl	0x7c(%rax), %eax
    3cf7:      	jmp	0x3f0f <generic_retuprobe_actions+0x84f>
    3cfc:      	movq	%r13, 0x8(%rsp)
    3d01:      	movq	%rbp, %r13
    3d04:      	movq	%rdx, %rbp
    3d07:      	movl	$0x3, %ebx
    3d0c:      	cmpb	$0x0, 0x17(%rsp)
    3d11:      	je	0x3d38 <generic_retuprobe_actions+0x678>
    3d13:      	movslq	%eax, %rdi
    3d16:      	movl	$0x6d, %eax
    3d1b:      	callq	*%rax
    3d1d:      	movl	$0x2, %ebx
    3d22:      	jmp	0x3d38 <generic_retuprobe_actions+0x678>
    3d24:      	movq	%r13, 0x8(%rsp)
    3d29:      	movq	%rbp, %r13
    3d2c:      	movq	%rdx, %rbp
    3d2f:      	addl	$0x3, %r15d
    3d33:      	movq	0x68(%rsp), %rbx
    3d38:      	movl	$0x0, 0x18(%rsp)
    3d40:      	movl	$0x1, %eax
    3d45:      	leaq	0x18(%rsp), %rsi
    3d4a:      	movq	(%rip), %rdi            # 0x3d51 <generic_retuprobe_actions+0x691>
    3d51:      	callq	*%rax
    3d53:      	testq	%rax, %rax
    3d56:      	je	0x3d5d <generic_retuprobe_actions+0x69d>
    3d58:      	lock
    3d59:      	incq	(%rax,%rbx,8)
    3d5d:      	movq	%rbp, %rdx
    3d60:      	movq	%r13, %rbp
    3d63:      	movq	0x8(%rsp), %r13
    3d68:      	jmp	0x37f0 <generic_retuprobe_actions+0x130>
    3d6d:      	movq	%rax, 0x48(%rsp)
    3d72:      	movq	0x5e78(%rdx,%r14,8), %rax
    3d7a:      	movl	$0x0, 0x24(%rsp)
    3d82:      	andl	$0x7ff, %eax            # imm = 0x7FF
    3d87:      	movl	0x90(%rdx,%rax), %eax
    3d8e:      	movl	%eax, 0x20(%rsp)
    3d92:      	movl	$0xe, %eax
    3d97:      	callq	*%rax
    3d99:      	shrq	$0x20, %rax
    3d9d:      	movq	%rax, 0x18(%rsp)
    3da2:      	cmpl	$0x1, %r13d
    3da6:      	jne	0x3eb2 <generic_retuprobe_actions+0x7f2>
    3dac:      	movq	0x38(%rsp), %rax
    3db1:      	andl	$0x7, %eax
    3db4:      	cmpl	$0x4, %eax
    3db7:      	movq	%rbp, %r14
    3dba:      	movl	$0x0, %ecx
    3dbf:      	ja	0x3ecb <generic_retuprobe_actions+0x80b>
    3dc5:      	movq	0x8(%rsp), %rdx
    3dca:      	cmpl	$0x0, 0x5ea0(%rdx,%rax,4)
    3dd2:      	movq	(%rip), %rbp            # 0x3dd9 <generic_retuprobe_actions+0x719>
    3dd9:      	jne	0x3ed7 <generic_retuprobe_actions+0x817>
    3ddf:      	movq	0x5e78(%rdx,%rax,8), %rax
    3de7:      	andl	$0x7ff, %eax            # imm = 0x7FF
    3dec:      	addq	%rax, %rdx
    3def:      	addq	$0x90, %rdx
    3df6:      	movq	0x8(%rsp), %rcx
    3dfb:      	movl	0x90(%rcx,%rax), %esi
    3e02:      	andl	$0xfff, %esi            # imm = 0xFFF
    3e08:      	addq	$0x8, %rsi
    3e0c:      	movl	$0x4, %eax
    3e11:      	movq	0x48(%rsp), %rdi
    3e16:      	callq	*%rax
    3e18:      	xorl	%ecx, %ecx
    3e1a:      	movl	$0x2, %eax
    3e1f:      	leaq	0x18(%rsp), %rsi
    3e24:      	movq	(%rip), %rdi            # 0x3e2b <generic_retuprobe_actions+0x76b>
    3e2b:      	movq	0x48(%rsp), %rdx
    3e30:      	xorl	%ecx, %ecx
    3e32:      	callq	*%rax
    3e34:      	xorl	%ecx, %ecx
    3e36:      	movq	0x8(%rsp), %rdx
    3e3b:      	testl	%ecx, %ecx
    3e3d:      	jne	0x37fa <generic_retuprobe_actions+0x13a>
    3e43:      	jmp	0x37f0 <generic_retuprobe_actions+0x130>
    3e48:      	movl	$0x2, %eax
    3e4d:      	movl	$0x1, %ecx
    3e52:      	leaq	0x5c(%rsp), %rdx
    3e57:      	leaq	0x28(%rsp), %rsi
    3e5c:      	movq	%rbx, %rdi
    3e5f:      	callq	*%rax
    3e61:      	testq	%rax, %rax
    3e64:      	je	0x3c1a <generic_retuprobe_actions+0x55a>
    3e6a:      	movq	%rax, 0x38(%rsp)
    3e6f:      	negl	%eax
    3e71:      	movw	%ax, 0x18(%rsp)
    3e76:      	movw	$0x3, 0x1a(%rsp)
    3e7d:      	movabsq	$0x20000003b, %rax      # imm = 0x20000003B
    3e87:      	movq	%rax, 0x1c(%rsp)
    3e8c:      	movl	$0x1, %eax
    3e91:      	leaq	0x18(%rsp), %rsi
    3e96:      	movq	(%rip), %rbx            # 0x3e9d <generic_retuprobe_actions+0x7dd>
    3e9d:      	movq	%rbx, %rdi
    3ea0:      	callq	*%rax
    3ea2:      	testq	%rax, %rax
    3ea5:      	je	0x4178 <generic_retuprobe_actions+0xab8>
    3eab:      	incl	(%rax)
    3ead:      	jmp	0x419e <generic_retuprobe_actions+0xade>
    3eb2:      	movl	$0x3, %eax
    3eb7:      	leaq	0x18(%rsp), %rsi
    3ebc:      	movq	(%rip), %rdi            # 0x3ec3 <generic_retuprobe_actions+0x803>
    3ec3:      	callq	*%rax
    3ec5:      	movq	%rax, %rcx
    3ec8:      	movq	%rbp, %r14
    3ecb:      	movq	(%rip), %rbp            # 0x3ed2 <generic_retuprobe_actions+0x812>
    3ed2:      	movq	0x8(%rsp), %rdx
    3ed7:      	testl	%ecx, %ecx
    3ed9:      	jne	0x37fa <generic_retuprobe_actions+0x13a>
    3edf:      	jmp	0x37f0 <generic_retuprobe_actions+0x130>
    3ee4:      	movl	$0x3, %eax
    3ee9:      	leaq	0x28(%rsp), %rsi
    3eee:      	movq	(%rip), %rdi            # 0x3ef5 <generic_retuprobe_actions+0x835>
    3ef5:      	callq	*%rax
    3ef7:      	movq	%rax, %rcx
    3efa:      	movq	0x8(%rsp), %rdx
    3eff:      	testl	%ecx, %ecx
    3f01:      	jne	0x37fa <generic_retuprobe_actions+0x13a>
    3f07:      	jmp	0x37f0 <generic_retuprobe_actions+0x130>
    3f0c:      	movl	0x10(%rcx), %eax
    3f0f:      	movq	%r14, 0x60(%rsp)
    3f14:      	movl	%eax, %eax
    3f16:      	movq	%rbx, 0x98(%rsp)
    3f1e:      	movq	%rax, 0x10(%rbx)
    3f22:      	movq	0x48(%rsp), %rdi
    3f27:      	addq	$0x18, %rdi
    3f2b:      	movl	$0x4, %eax
    3f30:      	movl	$0xc8, %ecx
    3f35:      	movq	%rdi, 0x48(%rsp)
    3f3a:      	movl	$0xc8, %esi
    3f3f:      	callq	*%rax
    3f41:      	xorl	%r14d, %r14d
    3f44:      	leaq	0x28(%rsp), %rbx
    3f49:      	jmp	0x3f63 <generic_retuprobe_actions+0x8a3>
    3f4b:      	nopl	(%rax,%rax)
    3f50:      	leaq	0x28(%rsp), %rbx
    3f55:      	addq	$0x4, %r14
    3f59:      	cmpq	$0x14, %r14
    3f5d:      	je	0x408b <generic_retuprobe_actions+0x9cb>
    3f63:      	movl	$0x0, 0x28(%rsp)
    3f6b:      	movl	$0x1, %eax
    3f70:      	movq	%rbp, %rdi
    3f73:      	movq	%rbx, %rsi
    3f76:      	callq	*%rax
    3f78:      	testq	%rax, %rax
    3f7b:      	je	0x408b <generic_retuprobe_actions+0x9cb>
    3f81:      	movq	%rax, %rsi
    3f84:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    3f8b:      	movl	$0x1, %eax
    3f90:      	movq	(%rip), %rdi            # 0x3f97 <generic_retuprobe_actions+0x8d7>
    3f97:      	callq	*%rax
    3f99:      	testq	%rax, %rax
    3f9c:      	je	0x408b <generic_retuprobe_actions+0x9cb>
    3fa2:      	cmpl	$-0x1, 0x40(%rax,%r14)
    3fa8:      	movq	0x8(%rsp), %rdx
    3fad:      	je	0x408b <generic_retuprobe_actions+0x9cb>
    3fb3:      	movq	0x5e78(%rdx,%r14,2), %rax
    3fbb:      	movl	0x4(%rdx), %ecx
    3fbe:      	cmpq	%rcx, %rax
    3fc1:      	jge	0x408b <generic_retuprobe_actions+0x9cb>
    3fc7:      	cmpq	$0x10, %r14
    3fcb:      	je	0x4032 <generic_retuprobe_actions+0x972>
    3fcd:      	movl	$0x0, 0x28(%rsp)
    3fd5:      	movl	$0x1, %eax
    3fda:      	movq	%rbp, %rdi
    3fdd:      	movq	%rbx, %rsi
    3fe0:      	callq	*%rax
    3fe2:      	testq	%rax, %rax
    3fe5:      	je	0x4025 <generic_retuprobe_actions+0x965>
    3fe7:      	movq	%rax, %rsi
    3fea:      	addq	$0x5ef8, %rsi           # imm = 0x5EF8
    3ff1:      	movl	$0x1, %eax
    3ff6:      	movq	(%rip), %rdi            # 0x3ffd <generic_retuprobe_actions+0x93d>
    3ffd:      	callq	*%rax
    3fff:      	testq	%rax, %rax
    4002:      	je	0x4025 <generic_retuprobe_actions+0x965>
    4004:      	cmpl	$-0x1, 0x44(%rax,%r14)
    400a:      	movq	0x8(%rsp), %rdx
    400f:      	movq	0x5e78(%rdx,%r14,2), %rax
    4017:      	je	0x4032 <generic_retuprobe_actions+0x972>
    4019:      	movl	0x5e80(%rdx,%r14,2), %ebx
    4021:      	subl	%eax, %ebx
    4023:      	jmp	0x403a <generic_retuprobe_actions+0x97a>
    4025:      	movq	0x8(%rsp), %rdx
    402a:      	movq	0x5e78(%rdx,%r14,2), %rax
    4032:      	movl	0x4(%rdx), %ebx
    4035:      	subl	%eax, %ebx
    4037:      	addl	$0x4, %ebx
    403a:      	testl	%ebx, %ebx
    403c:      	jle	0x3f50 <generic_retuprobe_actions+0x890>
    4042:      	addl	$0x3ffc, %eax           # imm = 0x3FFC
    4047:      	andl	$0x3fff, %eax           # imm = 0x3FFF
    404c:      	cmpl	$0x28, %ebx
    404f:      	movl	$0x28, %ecx
    4054:      	cmovgel	%ecx, %ebx
    4057:      	movzbl	0x38(%rsp), %ebp
    405c:      	movq	0x48(%rsp), %rcx
    4061:      	leaq	(%rcx,%rbp), %rdi
    4065:      	addq	%rax, %rdx
    4068:      	addq	$0x90, %rdx
    406f:      	movl	$0x4, %eax
    4074:      	movl	%ebx, %esi
    4076:      	callq	*%rax
    4078:      	addl	%ebp, %ebx
    407a:      	movq	(%rip), %rbp            # 0x4081 <generic_retuprobe_actions+0x9c1>
    4081:      	movq	%rbx, 0x38(%rsp)
    4086:      	jmp	0x3f50 <generic_retuprobe_actions+0x890>
    408b:      	movl	$0x1, %eax
    4090:      	movq	(%rip), %rdi            # 0x4097 <generic_retuprobe_actions+0x9d7>
    4097:      	movq	0x98(%rsp), %rbx
    409f:      	movq	%rbx, %rsi
    40a2:      	callq	*%rax
    40a4:      	testq	%rax, %rax
    40a7:      	movq	0x60(%rsp), %r14
    40ac:      	je	0x40ce <generic_retuprobe_actions+0xa0e>
    40ae:      	imulq	$-0xf4240, 0xa0(%rsp), %rcx # imm = 0xFFF0BDC0
    40ba:      	addq	0x18(%rsp), %rcx
    40bf:      	cmpq	%rcx, (%rax)
    40c2:      	jbe	0x40ce <generic_retuprobe_actions+0xa0e>
    40c4:      	movl	$0x0, 0x44(%rsp)
    40cc:      	jmp	0x40e8 <generic_retuprobe_actions+0xa28>
    40ce:      	movl	$0x2, %eax
    40d3:      	xorl	%ecx, %ecx
    40d5:      	movq	(%rip), %rdi            # 0x40dc <generic_retuprobe_actions+0xa1c>
    40dc:      	leaq	0x18(%rsp), %rdx
    40e1:      	movq	%rbx, %rsi
    40e4:      	xorl	%ecx, %ecx
    40e6:      	callq	*%rax
    40e8:      	leal	0x3(%r15), %eax
    40ec:      	cmpl	$0x0, 0x4(%r14,%rax,4)
    40f2:      	movq	0x8(%rsp), %rdx
    40f7:      	je	0x4123 <generic_retuprobe_actions+0xa63>
    40f9:      	orb	$0x2, 0x1(%rdx)
    40fd:      	movl	$0x1b, %eax
    4102:      	movq	0x80(%rsp), %rdi
    410a:      	xorl	%ecx, %ecx
    410c:      	movq	(%rip), %rsi            # 0x4113 <generic_retuprobe_actions+0xa53>
    4113:      	xorl	%edx, %edx
    4115:      	callq	*%rax
    4117:      	movq	0x8(%rsp), %rdx
    411c:      	movq	%rax, 0x80(%rdx)
    4123:      	leal	0x4(%r15), %eax
    4127:      	cmpl	$0x0, 0x4(%r14,%rax,4)
    412d:      	je	0x415f <generic_retuprobe_actions+0xa9f>
    412f:      	orb	$0x4, 0x1(%rdx)
    4133:      	movl	$0x1b, %eax
    4138:      	movq	0x80(%rsp), %rdi
    4140:      	movq	(%rip), %rsi            # 0x4147 <generic_retuprobe_actions+0xa87>
    4147:      	movl	$0x100, %ecx            # imm = 0x100
    414c:      	movl	$0x100, %edx            # imm = 0x100
    4151:      	callq	*%rax
    4153:      	movq	0x8(%rsp), %rdx
    4158:      	movq	%rax, 0x88(%rdx)
    415f:      	addl	$0x5, %r15d
    4163:      	cmpl	$0x0, 0x4(%r14,%r15,4)
    4169:      	je	0x37f0 <generic_retuprobe_actions+0x130>
    416f:      	orb	$0x8, 0x1(%rdx)
    4173:      	jmp	0x37f0 <generic_retuprobe_actions+0x130>
    4178:      	movl	$0x1, 0x94(%rsp)
    4183:      	movl	$0x2, %eax
    4188:      	xorl	%ecx, %ecx
    418a:      	leaq	0x94(%rsp), %rdx
    4192:      	leaq	0x18(%rsp), %rsi
    4197:      	movq	%rbx, %rdi
    419a:      	xorl	%ecx, %ecx
    419c:      	callq	*%rax
    419e:      	cmpl	$0x0, 0x38(%rsp)
    41a3:      	je	0x3c1a <generic_retuprobe_actions+0x55a>
    41a9:      	movl	$0x1, %eax
    41ae:      	leaq	0x28(%rsp), %rsi
    41b3:      	movq	(%rip), %rdi            # 0x41ba <generic_retuprobe_actions+0xafa>
    41ba:      	callq	*%rax
    41bc:      	testq	%rax, %rax
    41bf:      	je	0x3c1a <generic_retuprobe_actions+0x55a>
    41c5:      	movl	0x5c(%rsp), %ecx
    41c9:      	lock
    41ca:      	addl	%ecx, (%rax)
    41cc:      	jmp	0x3c1a <generic_retuprobe_actions+0x55a>
    41d1:      	cmpb	$0x0, 0x44(%rsp)
    41d6:      	je	0x41f8 <generic_retuprobe_actions+0xb38>
    41d8:      	movq	(%rip), %rsi            # 0x41df <generic_retuprobe_actions+0xb1f>
    41df:      	movl	$0x5, %ecx
    41e4:      	movl	$0xc, %eax
    41e9:      	movq	0x80(%rsp), %rdi
    41f1:      	movl	$0x5, %edx
    41f6:      	callq	*%rax
    41f8:      	xorl	%eax, %eax
    41fa:      	addq	$0xa8, %rsp
    4201:      	popq	%rbx
    4202:      	popq	%r12
    4204:      	popq	%r13
    4206:      	popq	%r14
    4208:      	popq	%r15
    420a:      	popq	%rbp
    420b:      	retq
    420c:      	nopl	(%rax)

0000000000004210 <generic_retuprobe_output>:
    4210:      	pushq	%r15
    4212:      	pushq	%r14
    4214:      	pushq	%rbx
    4215:      	subq	$0x10, %rsp
    4219:      	movq	%rdi, %r14
    421c:      	movl	$0x0, 0x8(%rsp)
    4224:      	movq	(%rip), %rdi            # 0x422b <generic_retuprobe_output+0x1b>
    422b:      	leaq	0x8(%rsp), %rsi
    4230:      	movl	$0x1, %eax
    4235:      	callq	*%rax
    4237:      	testq	%rax, %rax
    423a:      	je	0x4313 <generic_retuprobe_output+0x103>
    4240:      	movq	%rax, %rbx
    4243:      	movl	$0x90, %eax
    4248:      	addl	0x4(%rbx), %eax
    424b:      	andl	$0x7fff, %eax           # imm = 0x7FFF
    4250:      	cmpl	$0x2328, %eax           # imm = 0x2328
    4255:      	movl	$0x2328, %r15d          # imm = 0x2328
    425b:      	cmovbl	%eax, %r15d
    425f:      	movl	$0x0, 0xc(%rsp)
    4267:      	movq	(%rip), %rdi            # 0x426e <generic_retuprobe_output+0x5e>
    426e:      	leaq	0xc(%rsp), %rsi
    4273:      	movl	$0x1, %eax
    4278:      	callq	*%rax
    427a:      	testq	%rax, %rax
    427d:      	je	0x42d1 <generic_retuprobe_output+0xc1>
    427f:      	cmpb	$0x0, 0x28(%rax)
    4283:      	je	0x42d1 <generic_retuprobe_output+0xc1>
    4285:      	movq	(%rip), %rsi            # 0x428c <generic_retuprobe_output+0x7c>
    428c:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
    4291:      	movl	$0x19, %eax
    4296:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
    429b:      	movq	%r14, %rdi
    429e:      	movq	%rbx, %rcx
    42a1:      	movq	%r15, %r8
    42a4:      	callq	*%rax
    42a6:      	testq	%rax, %rax
    42a9:      	js	0x436e <generic_retuprobe_output+0x15e>
    42af:      	movl	$0x0, 0x4(%rsp)
    42b7:      	movq	(%rip), %rdi            # 0x42be <generic_retuprobe_output+0xae>
    42be:      	leaq	0x4(%rsp), %rsi
    42c3:      	movl	$0x1, %eax
    42c8:      	callq	*%rax
    42ca:      	testq	%rax, %rax
    42cd:      	jne	0x430e <generic_retuprobe_output+0xfe>
    42cf:      	jmp	0x4313 <generic_retuprobe_output+0x103>
    42d1:      	movq	(%rip), %rdi            # 0x42d8 <generic_retuprobe_output+0xc8>
    42d8:      	xorl	%ecx, %ecx
    42da:      	movl	$0x82, %eax
    42df:      	movq	%rbx, %rsi
    42e2:      	movq	%r15, %rdx
    42e5:      	xorl	%ecx, %ecx
    42e7:      	callq	*%rax
    42e9:      	testq	%rax, %rax
    42ec:      	js	0x431f <generic_retuprobe_output+0x10f>
    42ee:      	movl	$0x0, 0x4(%rsp)
    42f6:      	movq	(%rip), %rdi            # 0x42fd <generic_retuprobe_output+0xed>
    42fd:      	leaq	0x4(%rsp), %rsi
    4302:      	movl	$0x1, %eax
    4307:      	callq	*%rax
    4309:      	testq	%rax, %rax
    430c:      	je	0x4313 <generic_retuprobe_output+0x103>
    430e:      	lock
    430f:      	incq	0x8(%rax)
    4313:      	xorl	%eax, %eax
    4315:      	addq	$0x10, %rsp
    4319:      	popq	%rbx
    431a:      	popq	%r14
    431c:      	popq	%r15
    431e:      	retq
    431f:      	movq	%rax, %rbx
    4322:      	movl	$0x0, 0x4(%rsp)
    432a:      	movq	(%rip), %rdi            # 0x4331 <generic_retuprobe_output+0x121>
    4331:      	leaq	0x4(%rsp), %rsi
    4336:      	movl	$0x1, %eax
    433b:      	callq	*%rax
    433d:      	testq	%rax, %rax
    4340:      	je	0x4313 <generic_retuprobe_output+0x103>
    4342:      	cmpq	$-0xc, %rbx
    4346:      	jg	0x43b2 <generic_retuprobe_output+0x1a2>
    4348:      	cmpq	$-0x1c, %rbx
    434c:      	je	0x43f4 <generic_retuprobe_output+0x1e4>
    4352:      	cmpq	$-0x16, %rbx
    4356:      	je	0x43a3 <generic_retuprobe_output+0x193>
    4358:      	cmpq	$-0x10, %rbx
    435c:      	jne	0x43e5 <generic_retuprobe_output+0x1d5>
    4362:      	addq	$0x360, %rax            # imm = 0x360
    4368:      	lock
    4369:      	incq	(%rax)
    436c:      	jmp	0x4313 <generic_retuprobe_output+0x103>
    436e:      	movq	%rax, %rbx
    4371:      	movl	$0x0, 0x4(%rsp)
    4379:      	movq	(%rip), %rdi            # 0x4380 <generic_retuprobe_output+0x170>
    4380:      	leaq	0x4(%rsp), %rsi
    4385:      	movl	$0x1, %eax
    438a:      	callq	*%rax
    438c:      	testq	%rax, %rax
    438f:      	je	0x4313 <generic_retuprobe_output+0x103>
    4391:      	cmpq	$-0xc, %rbx
    4395:      	jg	0x43d3 <generic_retuprobe_output+0x1c3>
    4397:      	cmpq	$-0x1c, %rbx
    439b:      	je	0x43f4 <generic_retuprobe_output+0x1e4>
    439d:      	cmpq	$-0x16, %rbx
    43a1:      	jne	0x4358 <generic_retuprobe_output+0x148>
    43a3:      	addq	$0x368, %rax            # imm = 0x368
    43a9:      	lock
    43aa:      	incq	(%rax)
    43ad:      	jmp	0x4313 <generic_retuprobe_output+0x103>
    43b2:      	cmpq	$-0xb, %rbx
    43b6:      	je	0x4403 <generic_retuprobe_output+0x1f3>
    43b8:      	cmpq	$-0x7, %rbx
    43bc:      	je	0x4412 <generic_retuprobe_output+0x202>
    43be:      	cmpq	$-0x2, %rbx
    43c2:      	jne	0x43e5 <generic_retuprobe_output+0x1d5>
    43c4:      	addq	$0x350, %rax            # imm = 0x350
    43ca:      	lock
    43cb:      	incq	(%rax)
    43ce:      	jmp	0x4313 <generic_retuprobe_output+0x103>
    43d3:      	cmpq	$-0xb, %rbx
    43d7:      	je	0x4403 <generic_retuprobe_output+0x1f3>
    43d9:      	cmpq	$-0x7, %rbx
    43dd:      	je	0x4412 <generic_retuprobe_output+0x202>
    43df:      	cmpq	$-0x2, %rbx
    43e3:      	je	0x43c4 <generic_retuprobe_output+0x1b4>
    43e5:      	addq	$0x348, %rax            # imm = 0x348
    43eb:      	lock
    43ec:      	incq	(%rax)
    43ef:      	jmp	0x4313 <generic_retuprobe_output+0x103>
    43f4:      	addq	$0x370, %rax            # imm = 0x370
    43fa:      	lock
    43fb:      	incq	(%rax)
    43fe:      	jmp	0x4313 <generic_retuprobe_output+0x103>
    4403:      	addq	$0x378, %rax            # imm = 0x378
    4409:      	lock
    440a:      	incq	(%rax)
    440d:      	jmp	0x4313 <generic_retuprobe_output+0x103>
    4412:      	addq	$0x358, %rax            # imm = 0x358
    4418:      	lock
    4419:      	incq	(%rax)
    441c:      	jmp	0x4313 <generic_retuprobe_output+0x103>

Disassembly of section uprobe.multi/generic_retuprobe:

0000000000000000 <generic_retuprobe_event>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xf8, %rsp
      11:      	movq	%rdi, %r13
      14:      	movq	0x50(%rdi), %r14
      18:      	movl	$0x0, 0xe8(%rsp)
      23:      	movq	(%rip), %rdi            # 0x2a <generic_retuprobe_event+0x2a>
      2a:      	leaq	0xe8(%rsp), %rsi
      32:      	movl	$0x1, %eax
      37:      	callq	*%rax
      39:      	xorl	%ebp, %ebp
      3b:      	testq	%rax, %rax
      3e:      	je	0x30d1 <generic_retuprobe_event+0x30d1>
      44:      	movq	%rax, %r15
      47:      	movq	%rax, %rbx
      4a:      	movl	$0xae, %eax
      4f:      	movq	%r13, %rdi
      52:      	callq	*%rax
      54:      	leaq	0x5ef8(%r15), %rsi
      5b:      	movl	%eax, 0x5ef8(%r15)
      62:      	movq	(%rip), %rdi            # 0x69 <generic_retuprobe_event+0x69>
      69:      	movl	$0x1, %eax
      6e:      	callq	*%rax
      70:      	testq	%rax, %rax
      73:      	je	0x30d1 <generic_retuprobe_event+0x30d1>
      79:      	movq	%rax, %r12
      7c:      	movl	(%rax), %eax
      7e:      	movq	%rax, 0x60(%rbx)
      82:      	movl	$0xe, %eax
      87:      	callq	*%rax
      89:      	cmpq	$-0x16, %rax
      8d:      	jne	0xae <generic_retuprobe_event+0xae>
      8f:      	leaq	0x20(%r13), %rdx
      93:      	leaq	0x38(%rsp), %rdi
      98:      	movl	$0x8, %ecx
      9d:      	movl	$0x4, %eax
      a2:      	movl	$0x8, %esi
      a7:      	callq	*%rax
      a9:      	movq	0x38(%rsp), %rax
      ae:      	movq	%rax, 0x68(%rbx)
      b2:      	movl	$0xe, %eax
      b7:      	callq	*%rax
      b9:      	movl	%eax, 0x7c(%rbx)
      bc:      	movq	0x60(%rbx), %rax
      c0:      	movq	0x68(%rbx), %rcx
      c4:      	movq	%rax, 0x38(%rsp)
      c9:      	movq	%rcx, 0x40(%rsp)
      ce:      	movq	(%rip), %rdi            # 0xd5 <generic_retuprobe_event+0xd5>
      d5:      	leaq	0x38(%rsp), %rsi
      da:      	movl	$0x1, %eax
      df:      	callq	*%rax
      e1:      	testq	%rax, %rax
      e4:      	je	0x30d1 <generic_retuprobe_event+0x30d1>
      ea:      	movq	%r14, 0x8(%rsp)
      ef:      	movq	(%rax), %r14
      f2:      	movq	0x8(%rax), %rbp
      f6:      	movq	0x10(%rax), %rax
      fa:      	movq	%rax, 0xb8(%rsp)
     102:      	movq	(%rip), %rdi            # 0x109 <generic_retuprobe_event+0x109>
     109:      	leaq	0x38(%rsp), %rsi
     10e:      	movl	$0x3, %eax
     113:      	callq	*%rax
     115:      	movq	%r14, 0x90(%rbx)
     11c:      	movl	0x58(%r12), %eax
     121:      	movl	0x5c(%r12), %r14d
     126:      	testl	%r14d, %r14d
     129:      	je	0x199 <generic_retuprobe_event+0x199>
     12b:      	movl	%eax, 0x28(%rsp)
     12f:      	movl	$0x0, 0x5ea0(%rbx)
     139:      	movl	$0x0, 0xec(%rsp)
     144:      	movq	(%rip), %rdi            # 0x14b <generic_retuprobe_event+0x14b>
     14b:      	leaq	0xec(%rsp), %rsi
     153:      	movl	$0x1, %eax
     158:      	callq	*%rax
     15a:      	testq	%rax, %rax
     15d:      	je	0x29c <generic_retuprobe_event+0x29c>
     163:      	movq	%rax, %rcx
     166:      	movl	0x5ea0(%rax), %eax
     16c:      	movl	%eax, 0x98(%rcx)
     172:      	movq	$0xc, 0x5e78(%rcx)
     17d:      	testl	%eax, %eax
     17f:      	je	0x2ad <generic_retuprobe_event+0x2ad>
     185:      	movq	0x8(%rsp), %r8
     18a:      	movl	$0x4, %r14d
     190:      	movl	0x28(%rsp), %eax
     194:      	jmp	0x2d99 <generic_retuprobe_event+0x2d99>
     199:      	movl	$0x8, %r14d
     19f:      	movq	0x8(%rsp), %r8
     1a4:      	addq	$0x90, %r15
     1ab:      	cmpl	$0x3, %eax
     1ae:      	jne	0x2db4 <generic_retuprobe_event+0x2db4>
     1b4:      	movq	%r14, %rax
     1b7:      	movl	$0x0, (%r15,%r14)
     1bf:      	leaq	0x4(%r14), %rax
     1c3:      	cmpq	$0x0, 0xb8(%rsp)
     1cc:      	movq	%r13, 0xc8(%rsp)
     1d4:      	movq	%r12, 0x98(%rsp)
     1dc:      	je	0x31e <generic_retuprobe_event+0x31e>
     1e2:      	movq	%rax, 0x28(%rsp)
     1e7:      	leaq	0x38(%rsp), %rdi
     1ec:      	movl	$0x4, %r12d
     1f2:      	movl	$0x10, %ecx
     1f7:      	movl	$0x4, %eax
     1fc:      	movl	$0x10, %esi
     201:      	movq	%rbp, %rdx
     204:      	callq	*%rax
     206:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     20b:      	testl	%eax, %eax
     20d:      	js	0xbc3 <generic_retuprobe_event+0xbc3>
     213:      	movq	%rbp, 0x88(%rsp)
     21b:      	movq	0x40(%rsp), %r13
     220:      	movq	0x8(%rsp), %rax
     225:      	cmpq	%rax, %r13
     228:      	movq	%rax, %rbp
     22b:      	cmovbq	%r13, %rbp
     22f:      	testq	%rax, %rax
     232:      	cmovneq	%rbp, %r13
     236:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
     23b:      	cmpq	$0xffe, %r13            # imm = 0xFFE
     242:      	ja	0xbc3 <generic_retuprobe_event+0xbc3>
     248:      	addq	$0xc, %r14
     24c:      	movq	%r14, 0x20(%rsp)
     251:      	leaq	(%r15,%r14), %rdi
     255:      	movq	0x38(%rsp), %rcx
     25a:      	movl	$0x4, %eax
     25f:      	movq	0x38(%rsp), %rdx
     264:      	movl	%r13d, %esi
     267:      	callq	*%rax
     269:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     26e:      	testl	%eax, %eax
     270:      	js	0xbc3 <generic_retuprobe_event+0xbc3>
     276:      	movq	0x8(%rsp), %rax
     27b:      	testq	%rax, %rax
     27e:      	je	0xaf8 <generic_retuprobe_event+0xaf8>
     284:      	subq	%rbp, %rax
     287:      	movq	%rax, 0x8(%rsp)
     28c:      	movq	0x28(%rsp), %rax
     291:      	jne	0xb04 <generic_retuprobe_event+0xb04>
     297:      	jmp	0x320 <generic_retuprobe_event+0x320>
     29c:      	xorl	%r14d, %r14d
     29f:      	movq	0x8(%rsp), %r8
     2a4:      	movl	0x28(%rsp), %eax
     2a8:      	jmp	0x2d99 <generic_retuprobe_event+0x2d99>
     2ad:      	leaq	0x9c(%rcx), %rdx
     2b4:      	movq	0x8(%rsp), %rax
     2b9:      	movq	%rax, 0x38(%rsp)
     2be:      	movq	$0x0, 0x78(%rsp)
     2c7:      	cmpl	$0x17, %r14d
     2cb:      	movq	%rcx, (%rsp)
     2cf:      	movq	%r15, 0x20(%rsp)
     2d4:      	movq	%r13, 0xc8(%rsp)
     2dc:      	jle	0x335 <generic_retuprobe_event+0x335>
     2de:      	cmpl	$0x18, %r14d
     2e2:      	je	0x350 <generic_retuprobe_event+0x350>
     2e4:      	cmpl	$0x25, %r14d
     2e8:      	je	0x393 <generic_retuprobe_event+0x393>
     2ee:      	cmpl	$0x2a, %r14d
     2f2:      	jne	0xa35 <generic_retuprobe_event+0xa35>
     2f8:      	movq	$0x0, 0xa8(%rsp)
     304:      	movq	0x8(%rsp), %rax
     309:      	movq	%rax, 0xb0(%rsp)
     311:      	leaq	0xa8(%rsp), %rax
     319:      	jmp	0x3c5 <generic_retuprobe_event+0x3c5>
     31e:      	xorl	%ebp, %ebp
     320:      	movl	%ebp, (%r15,%rax)
     324:      	movl	%ebp, 0x4(%r15,%rax)
     329:      	addq	$0x8, %rbp
     32d:      	movq	%rbp, %r12
     330:      	jmp	0xbcc <generic_retuprobe_event+0xbcc>
     335:      	cmpl	$0xf, %r14d
     339:      	je	0x96c <generic_retuprobe_event+0x96c>
     33f:      	cmpl	$0x10, %r14d
     343:      	jne	0xa35 <generic_retuprobe_event+0xa35>
     349:      	leaq	0x10(%rsp), %r14
     34e:      	jmp	0x37d <generic_retuprobe_event+0x37d>
     350:      	leaq	0x10(%rsp), %r14
     355:      	movl	$0x8, %ecx
     35a:      	movl	$0x4, %eax
     35f:      	movq	0x8(%rsp), %rdx
     364:      	movq	0x38(%rsp), %rdx
     369:      	movq	%r14, %rdi
     36c:      	movl	$0x8, %esi
     371:      	callq	*%rax
     373:      	movq	0x10(%rsp), %rax
     378:      	movq	%rax, 0x38(%rsp)
     37d:      	leaq	0x38(%rsp), %rdx
     382:      	movl	$0x8, %ecx
     387:      	movl	$0x4, %eax
     38c:      	leaq	0x10(%rsp), %rdi
     391:      	jmp	0x3b5 <generic_retuprobe_event+0x3b5>
     393:      	movq	0x8(%rsp), %rax
     398:      	leaq	0x40(%rax), %rcx
     39c:      	movq	%rcx, 0x38(%rsp)
     3a1:      	leaq	0x10(%rsp), %rdi
     3a6:      	movl	$0x8, %edx
     3ab:      	movl	$0x4, %eax
     3b0:      	movq	0x38(%rsp), %rdx
     3b5:      	movl	$0x8, %esi
     3ba:      	callq	*%rax
     3bc:      	movq	0x10(%rsp), %rax
     3c1:      	addq	$0x40, %rax
     3c5:      	movq	%rax, 0x90(%rsp)
     3cd:      	movl	$0x0, 0xc4(%rsp)
     3d8:      	movq	(%rip), %rdi            # 0x3df <generic_retuprobe_event+0x3df>
     3df:      	leaq	0xc4(%rsp), %rsi
     3e7:      	movl	$0x1, %eax
     3ec:      	callq	*%rax
     3ee:      	testq	%rax, %rax
     3f1:      	je	0x4b2 <generic_retuprobe_event+0x4b2>
     3f7:      	movq	%rax, %r13
     3fa:      	movq	%rbp, 0x88(%rsp)
     402:      	movq	%r12, 0x98(%rsp)
     40a:      	addq	$0x1000, %rax           # imm = 0x1000
     410:      	movq	%rax, 0x18(%rsp)
     415:      	movl	$0x23, %eax
     41a:      	callq	*%rax
     41c:      	leaq	0xd50(%rax), %rdx
     423:      	leaq	0xd0(%rsp), %rdi
     42b:      	movl	$0x8, %ecx
     430:      	movl	$0x4, %eax
     435:      	movl	$0x8, %esi
     43a:      	callq	*%rax
     43c:      	movq	0xd0(%rsp), %r12
     444:      	movq	0x90(%rsp), %rax
     44c:      	leaq	0x8(%rax), %rdx
     450:      	leaq	0xd8(%rsp), %rdi
     458:      	movl	$0x8, %ecx
     45d:      	movl	$0x4, %eax
     462:      	leaq	0x18(%r12), %rcx
     467:      	movq	%rcx, 0xf0(%rsp)
     46f:      	movl	$0x8, %esi
     474:      	movq	%rdx, 0x30(%rsp)
     479:      	callq	*%rax
     47b:      	movq	0xd8(%rsp), %rbp
     483:      	leaq	0x10(%rbp), %rdx
     487:      	leaq	0x38(%rsp), %rdi
     48c:      	movl	$0x8, %ecx
     491:      	movl	$0x4, %eax
     496:      	movl	$0x8, %esi
     49b:      	callq	*%rax
     49d:      	cmpq	$0x0, 0x38(%rsp)
     4a3:      	movl	$0x1000, %r14d          # imm = 0x1000
     4a9:      	je	0x4bf <generic_retuprobe_event+0x4bf>
     4ab:      	movq	0x18(%rsp), %rcx
     4b0:      	jmp	0x510 <generic_retuprobe_event+0x510>
     4b2:      	xorl	%r13d, %r13d
     4b5:      	movq	0x8(%rsp), %r8
     4ba:      	jmp	0xd16 <generic_retuprobe_event+0xd16>
     4bf:      	leaq	0x18(%rbp), %rdx
     4c3:      	leaq	0x38(%rsp), %rdi
     4c8:      	movl	$0x8, %ecx
     4cd:      	movl	$0x4, %eax
     4d2:      	movl	$0x8, %esi
     4d7:      	callq	*%rax
     4d9:      	cmpq	%rbp, 0x38(%rsp)
     4de:      	movq	0x18(%rsp), %rcx
     4e3:      	je	0x510 <generic_retuprobe_event+0x510>
     4e5:      	movq	%r13, %rcx
     4e8:      	addq	$0xff6, %rcx            # imm = 0xFF6
     4ef:      	movabsq	$0x6574656c65642820, %rax # imm = 0x6574656C65642820
     4f9:      	movq	%rax, 0xff6(%r13)
     500:      	movw	$0x2964, 0xffe(%r13)    # imm = 0x2964
     50a:      	movl	$0xff6, %r14d           # imm = 0xFF6
     510:      	movq	$0x0, 0x40(%rsp)
     519:      	movq	$0x0, 0x38(%rsp)
     522:      	movq	%r13, 0x48(%rsp)
     527:      	movq	$0x0, 0x50(%rsp)
     530:      	movq	$0x0, 0x58(%rsp)
     539:      	movq	$0x0, 0x60(%rsp)
     542:      	movq	%rcx, 0x18(%rsp)
     547:      	movq	%rcx, 0x68(%rsp)
     54c:      	movl	%r14d, 0x70(%rsp)
     551:      	movb	$0x0, 0x74(%rsp)
     556:      	addq	$0x20, %r12
     55a:      	leaq	0x38(%rsp), %rdi
     55f:      	movl	$0x8, %ecx
     564:      	movl	$0x4, %eax
     569:      	leaq	0x40(%rsp), %r13
     56e:      	leaq	0x50(%rsp), %rbp
     573:      	leaq	0x58(%rsp), %r14
     578:      	movl	$0x8, %esi
     57d:      	movq	%r12, %rdx
     580:      	callq	*%rax
     582:      	movl	$0x8, %ecx
     587:      	movl	$0x4, %eax
     58c:      	movq	0xf0(%rsp), %rdx
     594:      	movq	%r13, %rdi
     597:      	movl	$0x8, %esi
     59c:      	callq	*%rax
     59e:      	movl	$0x8, %ecx
     5a3:      	movl	$0x4, %eax
     5a8:      	movq	0x30(%rsp), %rdx
     5ad:      	movq	%rbp, %rdi
     5b0:      	movl	$0x8, %esi
     5b5:      	callq	*%rax
     5b7:      	movl	$0x8, %ecx
     5bc:      	movl	$0x4, %eax
     5c1:      	movq	0x90(%rsp), %rdx
     5c9:      	movq	%r14, %rdi
     5cc:      	movl	$0x8, %esi
     5d1:      	callq	*%rax
     5d3:      	movq	0x58(%rsp), %rax
     5d8:      	addq	$-0x20, %rax
     5dc:      	movq	%rax, 0x60(%rsp)
     5e1:      	movq	(%rip), %rax            # 0x5e8 <generic_retuprobe_event+0x5e8>
     5e8:      	cmpb	$0x0, (%rax)
     5eb:      	je	0x7b5 <generic_retuprobe_event+0x7b5>
     5f1:      	movl	$0x80, %r13d
     5f7:      	movl	$0x8, %ebp
     5fc:      	movq	0x50(%rsp), %r14
     601:      	movq	0x58(%rsp), %rdx
     606:      	movq	0x60(%rsp), %r12
     60b:      	cmpq	0x38(%rsp), %r14
     610:      	jne	0x61d <generic_retuprobe_event+0x61d>
     612:      	cmpq	0x40(%rsp), %rdx
     617:      	je	0xaee <generic_retuprobe_event+0xaee>
     61d:      	movl	$0x4, %eax
     622:      	leaq	0xa0(%rsp), %rdi
     62a:      	movl	$0x8, %esi
     62f:      	callq	*%rax
     631:      	cmpq	0xa0(%rsp), %r14
     639:      	movl	$0x8, %r15d
     63f:      	je	0x74c <generic_retuprobe_event+0x74c>
     645:      	leaq	0x18(%r14), %rbp
     649:      	movl	$0x4, %eax
     64e:      	leaq	0x10(%rsp), %rdi
     653:      	movl	$0x8, %esi
     658:      	movq	%rbp, %rdx
     65b:      	callq	*%rax
     65d:      	cmpq	%r14, 0x10(%rsp)
     662:      	je	0x74c <generic_retuprobe_event+0x74c>
     668:      	movl	$0x4, %eax
     66d:      	leaq	0xe0(%rsp), %rdi
     675:      	movl	$0x8, %esi
     67a:      	movq	%rbp, %rdx
     67d:      	callq	*%rax
     67f:      	addq	$0x20, %r14
     683:      	movl	$0x4, %eax
     688:      	leaq	0x78(%rsp), %rdi
     68d:      	movl	$0x10, %ecx
     692:      	movl	$0x10, %esi
     697:      	movq	%r14, %rdx
     69a:      	callq	*%rax
     69c:      	movq	0x48(%rsp), %r14
     6a1:      	movq	0x68(%rsp), %rax
     6a6:      	movl	0x7c(%rsp), %ebp
     6aa:      	subq	%r14, %rax
     6ad:      	movl	0x70(%rsp), %r12d
     6b2:      	movl	%ebp, %edx
     6b4:      	subl	%r12d, %edx
     6b7:      	movl	$0x0, %ecx
     6bc:      	cmovbl	%ecx, %edx
     6bf:      	addq	0x80(%rsp), %rdx
     6c7:      	xorl	%esi, %esi
     6c9:      	cmpl	%ebp, %r12d
     6cc:      	seta	%sil
     6d0:      	movl	%ebp, %ecx
     6d2:      	cmovbl	%r12d, %ecx
     6d6:      	addl	%ecx, %esi
     6d8:      	movl	%r12d, %edi
     6db:      	subl	%esi, %edi
     6dd:      	movl	%edi, 0x70(%rsp)
     6e1:      	subq	%rsi, %rax
     6e4:      	movq	0x20(%rsp), %r15
     6e9:      	jb	0xbfc <generic_retuprobe_event+0xbfc>
     6ef:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     6f5:      	ja	0xbfc <generic_retuprobe_event+0xbfc>
     6fb:      	cmpl	%ebp, %r12d
     6fe:      	jbe	0x705 <generic_retuprobe_event+0x705>
     700:      	movb	$0x2f, (%r14,%rax)
     705:      	xorl	%edi, %edi
     707:      	cmpl	%ebp, %r12d
     70a:      	seta	%dil
     70e:      	movzbl	%cl, %esi
     711:      	addq	%rax, %r14
     714:      	addq	%r14, %rdi
     717:      	movl	$0x4, %eax
     71c:      	callq	*%rax
     71e:      	movq	%r14, 0x68(%rsp)
     723:      	cmpl	%ebp, %r12d
     726:      	jbe	0xbfc <generic_retuprobe_event+0xbfc>
     72c:      	movq	0xe0(%rsp), %rax
     734:      	movq	%rax, 0x50(%rsp)
     739:      	movl	$0x8, %ebp
     73e:      	decl	%r13d
     741:      	jne	0x5fc <generic_retuprobe_event+0x5fc>
     747:      	jmp	0xbfc <generic_retuprobe_event+0xbfc>
     74c:      	leaq	0x10(%r12), %rdx
     751:      	movl	$0x4, %eax
     756:      	leaq	0x10(%rsp), %rdi
     75b:      	movl	$0x8, %esi
     760:      	callq	*%rax
     762:      	movq	0x60(%rsp), %rax
     767:      	cmpq	0x10(%rsp), %rax
     76c:      	movl	$0x8, %ebp
     771:      	je	0xbf2 <generic_retuprobe_event+0xbf2>
     777:      	addq	$0x18, %r12
     77b:      	movl	$0x4, %eax
     780:      	leaq	0x50(%rsp), %rdi
     785:      	movl	$0x8, %esi
     78a:      	movq	%r12, %rdx
     78d:      	callq	*%rax
     78f:      	movq	0x10(%rsp), %rax
     794:      	movq	%rax, 0x60(%rsp)
     799:      	addq	$0x20, %rax
     79d:      	movq	%rax, 0x58(%rsp)
     7a2:      	movq	0x20(%rsp), %r15
     7a7:      	decl	%r13d
     7aa:      	jne	0x5fc <generic_retuprobe_event+0x5fc>
     7b0:      	jmp	0xbfc <generic_retuprobe_event+0xbfc>
     7b5:      	movl	$0x80, %r13d
     7bb:      	movl	$0x8, %ebp
     7c0:      	jmp	0x7cb <generic_retuprobe_event+0x7cb>
     7c2:      	decl	%r13d
     7c5:      	je	0xbfc <generic_retuprobe_event+0xbfc>
     7cb:      	movq	0x50(%rsp), %r14
     7d0:      	movq	0x58(%rsp), %rdx
     7d5:      	movq	0x60(%rsp), %r12
     7da:      	cmpq	0x38(%rsp), %r14
     7df:      	jne	0x7ec <generic_retuprobe_event+0x7ec>
     7e1:      	cmpq	0x40(%rsp), %rdx
     7e6:      	je	0xaee <generic_retuprobe_event+0xaee>
     7ec:      	movl	$0x4, %eax
     7f1:      	leaq	0xa0(%rsp), %rdi
     7f9:      	movl	$0x8, %esi
     7fe:      	callq	*%rax
     800:      	cmpq	0xa0(%rsp), %r14
     808:      	movl	$0x8, %ecx
     80d:      	je	0x911 <generic_retuprobe_event+0x911>
     813:      	leaq	0x18(%r14), %rbp
     817:      	movl	$0x4, %eax
     81c:      	leaq	0x10(%rsp), %rdi
     821:      	movl	$0x8, %esi
     826:      	movq	%rbp, %rdx
     829:      	callq	*%rax
     82b:      	movl	$0x8, %ecx
     830:      	cmpq	%r14, 0x10(%rsp)
     835:      	je	0x911 <generic_retuprobe_event+0x911>
     83b:      	movl	$0x4, %eax
     840:      	leaq	0xe0(%rsp), %rdi
     848:      	movl	$0x8, %esi
     84d:      	movq	%rbp, %rdx
     850:      	callq	*%rax
     852:      	addq	$0x20, %r14
     856:      	movl	$0x4, %eax
     85b:      	leaq	0x78(%rsp), %rdi
     860:      	movl	$0x10, %ecx
     865:      	movl	$0x10, %esi
     86a:      	movq	%r14, %rdx
     86d:      	callq	*%rax
     86f:      	movq	0x48(%rsp), %r14
     874:      	movq	0x68(%rsp), %rax
     879:      	movl	0x7c(%rsp), %ebp
     87d:      	subq	%r14, %rax
     880:      	movl	0x70(%rsp), %r12d
     885:      	movl	%ebp, %edx
     887:      	subl	%r12d, %edx
     88a:      	movl	$0x0, %ecx
     88f:      	cmovbl	%ecx, %edx
     892:      	addq	0x80(%rsp), %rdx
     89a:      	xorl	%esi, %esi
     89c:      	cmpl	%ebp, %r12d
     89f:      	seta	%sil
     8a3:      	movl	%ebp, %ecx
     8a5:      	cmovbl	%r12d, %ecx
     8a9:      	addl	%ecx, %esi
     8ab:      	movl	%r12d, %edi
     8ae:      	subl	%esi, %edi
     8b0:      	movl	%edi, 0x70(%rsp)
     8b4:      	subq	%rsi, %rax
     8b7:      	jb	0xbfc <generic_retuprobe_event+0xbfc>
     8bd:      	cmpq	$0xfff, %rax            # imm = 0xFFF
     8c3:      	ja	0xbfc <generic_retuprobe_event+0xbfc>
     8c9:      	cmpl	%ebp, %r12d
     8cc:      	jbe	0x8d3 <generic_retuprobe_event+0x8d3>
     8ce:      	movb	$0x2f, (%r14,%rax)
     8d3:      	xorl	%edi, %edi
     8d5:      	cmpl	%ebp, %r12d
     8d8:      	seta	%dil
     8dc:      	movzbl	%cl, %esi
     8df:      	addq	%rax, %r14
     8e2:      	addq	%r14, %rdi
     8e5:      	movl	$0x4, %eax
     8ea:      	callq	*%rax
     8ec:      	movq	%r14, 0x68(%rsp)
     8f1:      	cmpl	%ebp, %r12d
     8f4:      	jbe	0xbfc <generic_retuprobe_event+0xbfc>
     8fa:      	movq	0xe0(%rsp), %rax
     902:      	movq	%rax, 0x50(%rsp)
     907:      	movl	$0x8, %ebp
     90c:      	jmp	0x7c2 <generic_retuprobe_event+0x7c2>
     911:      	leaq	0x10(%r12), %rdx
     916:      	movl	$0x4, %eax
     91b:      	leaq	0x10(%rsp), %rdi
     920:      	movl	$0x8, %esi
     925:      	callq	*%rax
     927:      	movq	0x60(%rsp), %rax
     92c:      	cmpq	0x10(%rsp), %rax
     931:      	movl	$0x8, %ebp
     936:      	je	0xaee <generic_retuprobe_event+0xaee>
     93c:      	addq	$0x18, %r12
     940:      	movl	$0x4, %eax
     945:      	leaq	0x50(%rsp), %rdi
     94a:      	movl	$0x8, %esi
     94f:      	movq	%r12, %rdx
     952:      	callq	*%rax
     954:      	movq	0x10(%rsp), %rax
     959:      	movq	%rax, 0x60(%rsp)
     95e:      	addq	$0x20, %rax
     962:      	movq	%rax, 0x58(%rsp)
     967:      	jmp	0x7c2 <generic_retuprobe_event+0x7c2>
     96c:      	movq	%rdx, 0x30(%rsp)
     971:      	leaq	0x78(%rsp), %rdi
     976:      	leaq	0x38(%rsp), %rdx
     97b:      	movl	$0x8, %ecx
     980:      	movl	$0x4, %eax
     985:      	movl	$0x8, %esi
     98a:      	callq	*%rax
     98c:      	movq	0x78(%rsp), %rax
     991:      	movq	%rax, 0x90(%rsp)
     999:      	testq	%rax, %rax
     99c:      	jne	0x3cd <generic_retuprobe_event+0x3cd>
     9a2:      	movl	$0x0, 0xa8(%rsp)
     9ad:      	movq	(%rip), %rdi            # 0x9b4 <generic_retuprobe_event+0x9b4>
     9b4:      	leaq	0xa8(%rsp), %rsi
     9bc:      	movl	$0x1, %eax
     9c1:      	callq	*%rax
     9c3:      	xorl	%r13d, %r13d
     9c6:      	testq	%rax, %rax
     9c9:      	je	0xea0 <generic_retuprobe_event+0xea0>
     9cf:      	cmpl	$0x19, %r14d
     9d3:      	movq	(%rsp), %rcx
     9d7:      	jg	0xf66 <generic_retuprobe_event+0xf66>
     9dd:      	cmpl	$0x12, %r14d
     9e1:      	movq	0x30(%rsp), %rdi
     9e6:      	jle	0x10c6 <generic_retuprobe_event+0x10c6>
     9ec:      	cmpl	$0x14, %r14d
     9f0:      	jle	0x1409 <generic_retuprobe_event+0x1409>
     9f6:      	cmpl	$0x15, %r14d
     9fa:      	je	0x1e32 <generic_retuprobe_event+0x1e32>
     a00:      	cmpl	$0x16, %r14d
     a04:      	je	0x1d9a <generic_retuprobe_event+0x1d9a>
     a0a:      	cmpl	$0x17, %r14d
     a0e:      	movq	0x8(%rsp), %r8
     a13:      	jne	0x2d56 <generic_retuprobe_event+0x2d56>
     a19:      	movl	$0x0, 0xa0(%rcx)
     a23:      	movl	%r8d, 0x9c(%rcx)
     a2a:      	movl	$0x8, %r13d
     a30:      	jmp	0x2d56 <generic_retuprobe_event+0x2d56>
     a35:      	movq	%rdx, 0x30(%rsp)
     a3a:      	cmpl	$0x2c, %r14d
     a3e:      	ja	0x9a2 <generic_retuprobe_event+0x9a2>
     a44:      	movl	%r14d, %eax
     a47:      	movabsq	$0x11c1f2027cf2, %rcx   # imm = 0x11C1F2027CF2
     a51:      	btq	%rax, %rcx
     a55:      	jae	0x9a2 <generic_retuprobe_event+0x9a2>
     a5b:      	movq	0x8(%rsp), %rax
     a60:      	movq	%rax, 0x10(%rsp)
     a65:      	movl	$0x0, 0xe0(%rsp)
     a70:      	movq	(%rip), %rdi            # 0xa77 <generic_retuprobe_event+0xa77>
     a77:      	leaq	0xe0(%rsp), %rsi
     a7f:      	movl	$0x1, %eax
     a84:      	callq	*%rax
     a86:      	testq	%rax, %rax
     a89:      	movq	%rbp, 0x88(%rsp)
     a91:      	je	0xbe7 <generic_retuprobe_event+0xbe7>
     a97:      	xorl	%r13d, %r13d
     a9a:      	cmpl	$0x10, %r14d
     a9e:      	jle	0xd1f <generic_retuprobe_event+0xd1f>
     aa4:      	cmpl	$0x1e, %r14d
     aa8:      	movq	0x30(%rsp), %rdi
     aad:      	movq	%r12, %rbp
     ab0:      	jle	0xeaa <generic_retuprobe_event+0xeaa>
     ab6:      	cmpl	$0x26, %r14d
     aba:      	jg	0xfa4 <generic_retuprobe_event+0xfa4>
     ac0:      	leal	-0x1f(%r14), %eax
     ac4:      	cmpl	$0x2, %eax
     ac7:      	jae	0x14f1 <generic_retuprobe_event+0x14f1>
     acd:      	leaq	0x10(%rsp), %rdx
     ad2:      	movl	$0x4, %r13d
     ad8:      	movl	$0x1, %ecx
     add:      	movl	$0x4, %eax
     ae2:      	movl	$0x1, %esi
     ae7:      	callq	*%rax
     ae9:      	jmp	0x2d42 <generic_retuprobe_event+0x2d42>
     aee:      	movb	$0x1, 0x74(%rsp)
     af3:      	jmp	0xbfc <generic_retuprobe_event+0xbfc>
     af8:      	xorl	%eax, %eax
     afa:      	movq	%rax, 0x8(%rsp)
     aff:      	movq	0x28(%rsp), %rax
     b04:      	cmpq	$0x1, 0xb8(%rsp)
     b0d:      	jne	0xb17 <generic_retuprobe_event+0xb17>
     b0f:      	movq	%r13, %rbp
     b12:      	jmp	0x320 <generic_retuprobe_event+0x320>
     b17:      	movq	0x88(%rsp), %rax
     b1f:      	leaq	0x10(%rax), %rdx
     b23:      	leaq	0x38(%rsp), %rdi
     b28:      	movl	$0x4, %r12d
     b2e:      	movl	$0x10, %ecx
     b33:      	movl	$0x4, %eax
     b38:      	movl	$0x10, %esi
     b3d:      	callq	*%rax
     b3f:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     b44:      	testl	%eax, %eax
     b46:      	js	0xbc3 <generic_retuprobe_event+0xbc3>
     b48:      	movq	0x40(%rsp), %r14
     b4d:      	movq	0x8(%rsp), %rax
     b52:      	cmpq	%rax, %r14
     b55:      	movq	%rax, %rbp
     b58:      	cmovbq	%r14, %rbp
     b5c:      	testq	%rax, %rax
     b5f:      	cmovneq	%rbp, %r14
     b63:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
     b68:      	cmpq	$0xffe, %r14            # imm = 0xFFE
     b6f:      	ja	0xbc3 <generic_retuprobe_event+0xbc3>
     b71:      	movq	0x20(%rsp), %rax
     b76:      	addq	%r13, %rax
     b79:      	movq	%rax, 0x20(%rsp)
     b7e:      	leaq	(%r15,%rax), %rdi
     b82:      	movq	0x38(%rsp), %rcx
     b87:      	movl	$0x4, %eax
     b8c:      	movq	0x38(%rsp), %rdx
     b91:      	movl	%r14d, %esi
     b94:      	callq	*%rax
     b96:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
     b9b:      	testl	%eax, %eax
     b9d:      	js	0xbc3 <generic_retuprobe_event+0xbc3>
     b9f:      	addq	%r14, %r13
     ba2:      	movq	0x8(%rsp), %rax
     ba7:      	testq	%rax, %rax
     baa:      	je	0x1990 <generic_retuprobe_event+0x1990>
     bb0:      	subq	%rbp, %rax
     bb3:      	movq	%rax, 0x8(%rsp)
     bb8:      	jne	0x1997 <generic_retuprobe_event+0x1997>
     bbe:      	jmp	0x1a67 <generic_retuprobe_event+0x1a67>
     bc3:      	movq	0x28(%rsp), %rax
     bc8:      	movl	%ecx, (%r15,%rax)
     bcc:      	addq	%rax, %r12
     bcf:      	movq	%r12, %rbp
     bd2:      	movq	0xc8(%rsp), %r13
     bda:      	movq	0x98(%rsp), %r12
     be2:      	jmp	0x2e38 <generic_retuprobe_event+0x2e38>
     be7:      	movq	%r12, %rbp
     bea:      	xorl	%r13d, %r13d
     bed:      	jmp	0x2d42 <generic_retuprobe_event+0x2d42>
     bf2:      	movb	$0x1, 0x74(%rsp)
     bf7:      	movq	0x20(%rsp), %r15
     bfc:      	movq	0x68(%rsp), %rax
     c01:      	movq	0x18(%rsp), %rdx
     c06:      	xorl	%ebp, %ebp
     c08:      	cmpq	%rdx, %rax
     c0b:      	je	0xc48 <generic_retuprobe_event+0xc48>
     c0d:      	cmpb	$0x0, 0x74(%rsp)
     c12:      	sete	%cl
     c15:      	movl	0x70(%rsp), %edx
     c19:      	movl	$0x1000, %r13d          # imm = 0x1000
     c1f:      	subl	%edx, %r13d
     c22:      	testl	%edx, %edx
     c24:      	cmovlel	%edx, %r13d
     c28:      	testq	%rax, %rax
     c2b:      	movq	0x98(%rsp), %r12
     c33:      	movq	0x8(%rsp), %r8
     c38:      	je	0xd0b <generic_retuprobe_event+0xd0b>
     c3e:      	movb	%cl, %bpl
     c41:      	addl	%ebp, %ebp
     c43:      	movq	%rax, %rdx
     c46:      	jmp	0xc53 <generic_retuprobe_event+0xc53>
     c48:      	xorl	%r13d, %r13d
     c4b:      	movq	0x98(%rsp), %r12
     c53:      	movq	(%rsp), %r14
     c57:      	movq	%r14, %rdi
     c5a:      	addq	$0xa0, %rdi
     c61:      	andl	$0xfff, %r13d           # imm = 0xFFF
     c68:      	movl	$0x4, %eax
     c6d:      	movl	%r13d, %esi
     c70:      	callq	*%rax
     c72:      	movl	%r13d, 0x9c(%r14)
     c79:      	leaq	0x38(%rsp), %rdi
     c7e:      	movl	$0x8, %ecx
     c83:      	movl	$0x4, %eax
     c88:      	movq	0x30(%rsp), %rdx
     c8d:      	movl	$0x8, %esi
     c92:      	callq	*%rax
     c94:      	movq	0x38(%rsp), %rcx
     c99:      	addq	$0x30, %rcx
     c9d:      	leaq	0x78(%rsp), %rdi
     ca2:      	movl	$0x8, %edx
     ca7:      	movl	$0x4, %eax
     cac:      	movq	0x38(%rsp), %rdx
     cb1:      	addq	$0x30, %rdx
     cb5:      	movl	$0x8, %esi
     cba:      	callq	*%rax
     cbc:      	movq	0x78(%rsp), %rcx
     cc1:      	leaq	0x10(%rsp), %rdi
     cc6:      	movl	$0x2, %edx
     ccb:      	movl	$0x4, %eax
     cd0:      	movq	0x78(%rsp), %rdx
     cd5:      	movl	$0x2, %esi
     cda:      	callq	*%rax
     cdc:      	movq	%r14, %rcx
     cdf:      	movl	%ebp, 0xa0(%r14,%r13)
     ce7:      	movzwl	0x10(%rsp), %eax
     cec:      	movw	%ax, 0xa4(%r14,%r13)
     cf5:      	addl	$0xa, %r13d
     cf9:      	movq	0x88(%rsp), %rbp
     d01:      	movq	0x8(%rsp), %r8
     d06:      	jmp	0x2d56 <generic_retuprobe_event+0x2d56>
     d0b:      	xorl	%r13d, %r13d
     d0e:      	movq	0x88(%rsp), %rbp
     d16:      	movl	0x28(%rsp), %eax
     d1a:      	jmp	0x2d5f <generic_retuprobe_event+0x2d5f>
     d1f:      	movq	%r12, %rbp
     d22:      	cmpl	$0x9, %r14d
     d26:      	movq	0x30(%rsp), %rdi
     d2b:      	jg	0xedb <generic_retuprobe_event+0xedb>
     d31:      	cmpl	$0x4, %r14d
     d35:      	movq	(%rsp), %rcx
     d39:      	jle	0x1120 <generic_retuprobe_event+0x1120>
     d3f:      	cmpl	$0x5, %r14d
     d43:      	je	0x16dc <generic_retuprobe_event+0x16dc>
     d49:      	cmpl	$0x6, %r14d
     d4d:      	je	0xf43 <generic_retuprobe_event+0xf43>
     d53:      	movq	%rax, 0x18(%rsp)
     d58:      	cmpl	$0x7, %r14d
     d5c:      	jne	0x2d46 <generic_retuprobe_event+0x2d46>
     d62:      	movq	0x10(%rsp), %r13
     d67:      	movq	%r13, 0xc4(%rcx)
     d6e:      	leaq	0xc2(%rcx), %rdi
     d75:      	leaq	0x10(%r13), %rdx
     d79:      	movq	%rcx, %r12
     d7c:      	movl	$0x2, %ecx
     d81:      	movl	$0x4, %eax
     d86:      	movl	$0x2, %esi
     d8b:      	callq	*%rax
     d8d:      	leaq	0xd6(%r12), %rdi
     d95:      	leaq	0x12(%r13), %rdx
     d99:      	movl	$0x1, %ecx
     d9e:      	movl	$0x4, %eax
     da3:      	movl	$0x1, %esi
     da8:      	callq	*%rax
     daa:      	leaq	0xd4(%r12), %rdi
     db2:      	leaq	0x226(%r13), %rdx
     db9:      	movl	$0x2, %ecx
     dbe:      	movl	$0x4, %eax
     dc3:      	movl	$0x2, %esi
     dc8:      	callq	*%rax
     dca:      	leaq	0xc0(%r12), %rdi
     dd2:      	leaq	0x224(%r13), %rdx
     dd9:      	movl	$0x2, %ecx
     dde:      	movl	$0x4, %eax
     de3:      	movl	$0x2, %esi
     de8:      	callq	*%rax
     dea:      	leaq	0xcc(%r12), %rdi
     df2:      	leaq	0x21c(%r13), %rdx
     df9:      	movl	$0x4, %ecx
     dfe:      	movl	$0x4, %eax
     e03:      	movl	$0x4, %esi
     e08:      	callq	*%rax
     e0a:      	leaq	0xd0(%r12), %rdi
     e12:      	leaq	0x218(%r13), %rdx
     e19:      	movl	$0x4, %ecx
     e1e:      	movl	$0x4, %eax
     e23:      	movl	$0x4, %esi
     e28:      	callq	*%rax
     e2a:      	movq	0x30(%rsp), %rdi
     e2f:      	leaq	0xac(%r12), %r14
     e37:      	movq	$0x0, (%rdi)
     e3e:      	movq	$0x0, 0x8(%rdi)
     e46:      	movq	$0x0, 0x10(%rdi)
     e4e:      	movq	$0x0, 0x18(%rdi)
     e56:      	movzwl	0xc2(%r12), %eax
     e5f:      	cmpl	$0xa, %eax
     e62:      	je	0x214f <generic_retuprobe_event+0x214f>
     e68:      	cmpl	$0x2, %eax
     e6b:      	jne	0x217c <generic_retuprobe_event+0x217c>
     e71:      	leaq	0x4(%r13), %rdx
     e75:      	movl	$0x4, %ecx
     e7a:      	movl	$0x4, %eax
     e7f:      	movl	$0x4, %esi
     e84:      	callq	*%rax
     e86:      	movl	$0x4, %ecx
     e8b:      	movl	$0x4, %eax
     e90:      	movq	%r14, %rdi
     e93:      	movl	$0x4, %esi
     e98:      	movq	%r13, %rdx
     e9b:      	jmp	0x217a <generic_retuprobe_event+0x217a>
     ea0:      	movq	0x8(%rsp), %r8
     ea5:      	jmp	0x1400 <generic_retuprobe_event+0x1400>
     eaa:      	cmpl	$0x1c, %r14d
     eae:      	jg	0x10ff <generic_retuprobe_event+0x10ff>
     eb4:      	cmpl	$0x11, %r14d
     eb8:      	je	0x152e <generic_retuprobe_event+0x152e>
     ebe:      	cmpl	$0x19, %r14d
     ec2:      	je	0x15fd <generic_retuprobe_event+0x15fd>
     ec8:      	cmpl	$0x1c, %r14d
     ecc:      	movq	(%rsp), %rcx
     ed0:      	je	0x1130 <generic_retuprobe_event+0x1130>
     ed6:      	jmp	0x2d46 <generic_retuprobe_event+0x2d46>
     edb:      	leal	-0xa(%r14), %eax
     edf:      	cmpl	$0x2, %eax
     ee2:      	movq	(%rsp), %rcx
     ee6:      	jb	0x1130 <generic_retuprobe_event+0x1130>
     eec:      	leal	-0xc(%r14), %eax
     ef0:      	cmpl	$0x2, %eax
     ef3:      	jb	0x1151 <generic_retuprobe_event+0x1151>
     ef9:      	cmpl	$0xe, %r14d
     efd:      	jne	0x2d46 <generic_retuprobe_event+0x2d46>
     f03:      	leaq	0x38(%rsp), %rdi
     f08:      	leaq	0x10(%rsp), %r14
     f0d:      	movl	$0x8, %ecx
     f12:      	movl	$0x4, %eax
     f17:      	movl	$0x8, %esi
     f1c:      	movq	%r14, %rdx
     f1f:      	callq	*%rax
     f21:      	movq	0x38(%rsp), %rcx
     f26:      	movl	$0x8, %edx
     f2b:      	movl	$0x4, %eax
     f30:      	movq	0x38(%rsp), %rdx
     f35:      	movq	%r14, %rdi
     f38:      	movl	$0x8, %esi
     f3d:      	callq	*%rax
     f3f:      	movq	(%rsp), %rcx
     f43:      	movq	0x10(%rsp), %rdx
     f48:      	movq	%rcx, %rdi
     f4b:      	addq	$0xa0, %rdi
     f52:      	movl	$0x1001, %ecx           # imm = 0x1001
     f57:      	movl	$0x2d, %eax
     f5c:      	movl	$0x1001, %esi           # imm = 0x1001
     f61:      	jmp	0x18d4 <generic_retuprobe_event+0x18d4>
     f66:      	cmpl	$0x20, %r14d
     f6a:      	movq	0x30(%rsp), %rdi
     f6f:      	jle	0x1309 <generic_retuprobe_event+0x1309>
     f75:      	leal	-0x21(%r14), %ecx
     f79:      	cmpl	$0x4, %ecx
     f7c:      	jae	0x1172 <generic_retuprobe_event+0x1172>
     f82:      	movl	$0x8, %r13d
     f88:      	movl	$0x8, %ecx
     f8d:      	movl	$0x4, %eax
     f92:      	movq	0x8(%rsp), %r14
     f97:      	movl	$0x8, %esi
     f9c:      	movq	%r14, %rdx
     f9f:      	jmp	0x13fb <generic_retuprobe_event+0x13fb>
     fa4:      	cmpl	$0x27, %r14d
     fa8:      	je	0x18b0 <generic_retuprobe_event+0x18b0>
     fae:      	cmpl	$0x28, %r14d
     fb2:      	je	0x18f6 <generic_retuprobe_event+0x18f6>
     fb8:      	cmpl	$0x2c, %r14d
     fbc:      	movq	(%rsp), %rcx
     fc0:      	jne	0x2d46 <generic_retuprobe_event+0x2d46>
     fc6:      	movq	0x10(%rsp), %r12
     fcb:      	movb	$0x0, 0x38(%rsp)
     fd0:      	movq	$0x0, 0x68(%rdi)
     fd8:      	movq	$0x0, 0x60(%rdi)
     fe0:      	movq	$0x0, 0x58(%rdi)
     fe8:      	movq	$0x0, 0x50(%rdi)
     ff0:      	movq	$0x0, 0x48(%rdi)
     ff8:      	movq	$0x0, 0x40(%rdi)
    1000:      	movq	$0x0, 0x38(%rdi)
    1008:      	movq	$0x0, 0x30(%rdi)
    1010:      	movq	$0x0, 0x28(%rdi)
    1018:      	movq	$0x0, 0x20(%rdi)
    1020:      	movq	$0x0, 0x18(%rdi)
    1028:      	movq	$0x0, 0x10(%rdi)
    1030:      	movq	$0x0, 0x8(%rdi)
    1038:      	movq	$0x0, (%rdi)
    103f:      	movl	$0x2, %ecx
    1044:      	movl	$0x4, %eax
    1049:      	movl	$0x2, %esi
    104e:      	movq	%r12, %rdx
    1051:      	callq	*%rax
    1053:      	testq	%rax, %rax
    1056:      	js	0x2392 <generic_retuprobe_event+0x2392>
    105c:      	leaq	0x2(%r12), %r14
    1061:      	leaq	0x38(%rsp), %rdi
    1066:      	movl	$0x1, %ecx
    106b:      	movl	$0x4, %eax
    1070:      	movl	$0x1, %esi
    1075:      	movq	%r14, %rdx
    1078:      	callq	*%rax
    107a:      	testq	%rax, %rax
    107d:      	js	0x2392 <generic_retuprobe_event+0x2392>
    1083:      	movq	(%rsp), %rax
    1087:      	movq	%rax, %rdi
    108a:      	addq	$0xa0, %rdi
    1091:      	cmpb	$0x0, 0x38(%rsp)
    1096:      	sete	0x9e(%rax)
    109d:      	je	0x2367 <generic_retuprobe_event+0x2367>
    10a3:      	movl	$0x6c, %ecx
    10a8:      	movl	$0x2d, %eax
    10ad:      	movl	$0x6c, %esi
    10b2:      	movq	%r14, %rdx
    10b5:      	callq	*%rax
    10b7:      	testl	%eax, %eax
    10b9:      	js	0x2392 <generic_retuprobe_event+0x2392>
    10bf:      	decb	%al
    10c1:      	jmp	0x2388 <generic_retuprobe_event+0x2388>
    10c6:      	cmpl	$0x7, %r14d
    10ca:      	jg	0x13d2 <generic_retuprobe_event+0x13d2>
    10d0:      	cmpl	$0x2, %r14d
    10d4:      	je	0x1a87 <generic_retuprobe_event+0x1a87>
    10da:      	cmpl	$0x3, %r14d
    10de:      	movq	0x8(%rsp), %r8
    10e3:      	jne	0x2d56 <generic_retuprobe_event+0x2d56>
    10e9:      	movq	$0x0, 0x9c(%rax)
    10f4:      	movl	$0x8, %r13d
    10fa:      	jmp	0x2d56 <generic_retuprobe_event+0x2d56>
    10ff:      	leaq	0x10(%rsp), %rdx
    1104:      	movl	$0x4, %r13d
    110a:      	movl	$0x2, %ecx
    110f:      	movl	$0x4, %eax
    1114:      	movl	$0x2, %esi
    1119:      	callq	*%rax
    111b:      	jmp	0x2d42 <generic_retuprobe_event+0x2d42>
    1120:      	cmpl	$0x1, %r14d
    1124:      	je	0x1151 <generic_retuprobe_event+0x1151>
    1126:      	cmpl	$0x4, %r14d
    112a:      	jne	0x2d46 <generic_retuprobe_event+0x2d46>
    1130:      	movl	$0x8, %r13d
    1136:      	leaq	0x10(%rsp), %rdx
    113b:      	movl	$0x8, %ecx
    1140:      	movl	$0x4, %eax
    1145:      	movl	$0x8, %esi
    114a:      	callq	*%rax
    114c:      	jmp	0x2d42 <generic_retuprobe_event+0x2d42>
    1151:      	leaq	0x10(%rsp), %rdx
    1156:      	movl	$0x4, %r13d
    115c:      	movl	$0x4, %ecx
    1161:      	movl	$0x4, %eax
    1166:      	movl	$0x4, %esi
    116b:      	callq	*%rax
    116d:      	jmp	0x2d42 <generic_retuprobe_event+0x2d42>
    1172:      	cmpl	$0x2b, %r14d
    1176:      	je	0x1f4c <generic_retuprobe_event+0x1f4c>
    117c:      	cmpl	$0x29, %r14d
    1180:      	movq	0x8(%rsp), %r8
    1185:      	movq	(%rsp), %rcx
    1189:      	jne	0x2d56 <generic_retuprobe_event+0x2d56>
    118f:      	movq	%rdi, 0x30(%rsp)
    1194:      	movq	%rbp, 0x88(%rsp)
    119c:      	movq	%r12, %rbp
    119f:      	movq	%rax, 0x18(%rsp)
    11a4:      	leaq	0x18(%r8), %rdx
    11a8:      	leaq	0x38(%rsp), %rdi
    11ad:      	movl	$0x4, %r14d
    11b3:      	movl	$0x8, %ecx
    11b8:      	movl	$0x4, %eax
    11bd:      	movl	$0x8, %esi
    11c2:      	callq	*%rax
    11c4:      	movq	0x38(%rsp), %r13
    11c9:      	testq	%r13, %r13
    11cc:      	je	0x2429 <generic_retuprobe_event+0x2429>
    11d2:      	movq	(%rsp), %r12
    11d6:      	movq	%r13, 0xc4(%r12)
    11de:      	leaq	0xc2(%r12), %rdi
    11e6:      	leaq	0x10(%r13), %rdx
    11ea:      	movl	$0x2, %ecx
    11ef:      	movl	$0x4, %eax
    11f4:      	movl	$0x2, %esi
    11f9:      	callq	*%rax
    11fb:      	leaq	0xd6(%r12), %rdi
    1203:      	leaq	0x12(%r13), %rdx
    1207:      	movl	$0x1, %ecx
    120c:      	movl	$0x4, %eax
    1211:      	movl	$0x1, %esi
    1216:      	callq	*%rax
    1218:      	leaq	0xd4(%r12), %rdi
    1220:      	leaq	0x226(%r13), %rdx
    1227:      	movl	$0x2, %ecx
    122c:      	movl	$0x4, %eax
    1231:      	movl	$0x2, %esi
    1236:      	callq	*%rax
    1238:      	leaq	0xc0(%r12), %rdi
    1240:      	leaq	0x224(%r13), %rdx
    1247:      	movl	$0x2, %ecx
    124c:      	movl	$0x4, %eax
    1251:      	movl	$0x2, %esi
    1256:      	callq	*%rax
    1258:      	leaq	0xcc(%r12), %rdi
    1260:      	leaq	0x21c(%r13), %rdx
    1267:      	movl	$0x4, %eax
    126c:      	movl	$0x4, %esi
    1271:      	callq	*%rax
    1273:      	leaq	0xd0(%r12), %rdi
    127b:      	leaq	0x218(%r13), %rdx
    1282:      	movl	$0x4, %eax
    1287:      	movl	$0x4, %esi
    128c:      	callq	*%rax
    128e:      	leaq	0xac(%r12), %r14
    1296:      	movq	0x30(%rsp), %rax
    129b:      	movq	$0x0, (%rax)
    12a2:      	movq	$0x0, 0x8(%rax)
    12aa:      	movq	$0x0, 0x10(%rax)
    12b2:      	movq	$0x0, 0x18(%rax)
    12ba:      	movzwl	0xc2(%r12), %eax
    12c3:      	cmpl	$0xa, %eax
    12c6:      	je	0x239d <generic_retuprobe_event+0x239d>
    12cc:      	cmpl	$0x2, %eax
    12cf:      	jne	0x23cf <generic_retuprobe_event+0x23cf>
    12d5:      	leaq	0x4(%r13), %rdx
    12d9:      	movl	$0x4, %ecx
    12de:      	movl	$0x4, %eax
    12e3:      	movq	0x30(%rsp), %rdi
    12e8:      	movl	$0x4, %esi
    12ed:      	callq	*%rax
    12ef:      	movl	$0x4, %ecx
    12f4:      	movl	$0x4, %eax
    12f9:      	movq	%r14, %rdi
    12fc:      	movl	$0x4, %esi
    1301:      	movq	%r13, %rdx
    1304:      	jmp	0x23cd <generic_retuprobe_event+0x23cd>
    1309:      	cmpl	$0x1a, %r14d
    130d:      	je	0x1ff7 <generic_retuprobe_event+0x1ff7>
    1313:      	cmpl	$0x1b, %r14d
    1317:      	movq	0x8(%rsp), %r8
    131c:      	jne	0x2d56 <generic_retuprobe_event+0x2d56>
    1322:      	movq	$0x0, 0x48(%rdi)
    132a:      	movq	$0x0, 0x40(%rdi)
    1332:      	movq	$0x0, 0x38(%rdi)
    133a:      	movq	$0x0, 0x30(%rdi)
    1342:      	movq	$0x0, 0x28(%rdi)
    134a:      	movq	$0x0, 0x20(%rdi)
    1352:      	movq	$0x0, 0x18(%rdi)
    135a:      	movq	$0x0, 0x10(%rdi)
    1362:      	movq	$0x0, 0x8(%rdi)
    136a:      	movq	$0x0, (%rdi)
    1371:      	leaq	0xac(%rcx), %rdi
    1378:      	leaq	0x18(%r8), %rdx
    137c:      	movl	$0x3f, %ecx
    1381:      	movl	$0x2d, %eax
    1386:      	movl	$0x3f, %esi
    138b:      	callq	*%rax
    138d:      	testq	%rax, %rax
    1390:      	js	0x2356 <generic_retuprobe_event+0x2356>
    1396:      	movq	(%rsp), %r14
    139a:      	movq	%r14, %rdi
    139d:      	addq	$0xa4, %rdi
    13a4:      	movq	0x8(%rsp), %r13
    13a9:      	leaq	0x348(%r13), %rdx
    13b0:      	movl	$0x8, %ecx
    13b5:      	movl	$0x4, %eax
    13ba:      	movl	$0x8, %esi
    13bf:      	callq	*%rax
    13c1:      	movq	%r13, %r8
    13c4:      	movq	%r14, %rcx
    13c7:      	movl	$0x50, %r13d
    13cd:      	jmp	0x2d56 <generic_retuprobe_event+0x2d56>
    13d2:      	cmpl	$0x8, %r14d
    13d6:      	je	0x1b44 <generic_retuprobe_event+0x1b44>
    13dc:      	cmpl	$0x12, %r14d
    13e0:      	movq	0x8(%rsp), %r8
    13e5:      	jne	0x2d56 <generic_retuprobe_event+0x2d56>
    13eb:      	xorl	%r13d, %r13d
    13ee:      	movl	$0x4, %eax
    13f3:      	xorl	%esi, %esi
    13f5:      	movq	%r8, %rdx
    13f8:      	movq	%r8, %r14
    13fb:      	callq	*%rax
    13fd:      	movq	%r14, %r8
    1400:      	movq	(%rsp), %rcx
    1404:      	jmp	0x2d56 <generic_retuprobe_event+0x2d56>
    1409:      	cmpl	$0x13, %r14d
    140d:      	je	0x1ee1 <generic_retuprobe_event+0x1ee1>
    1413:      	cmpl	$0x14, %r14d
    1417:      	movq	0x8(%rsp), %r8
    141c:      	jne	0x2d56 <generic_retuprobe_event+0x2d56>
    1422:      	movq	$0x0, 0x38(%rsp)
    142b:      	leaq	0x110(%r8), %rdx
    1432:      	movq	%rdi, %r13
    1435:      	leaq	0x38(%rsp), %rdi
    143a:      	movl	$0x8, %ecx
    143f:      	movl	$0x4, %eax
    1444:      	movq	0x8(%rsp), %rcx
    1449:      	leaq	0xd8(%rcx), %r14
    1450:      	movl	$0x8, %esi
    1455:      	callq	*%rax
    1457:      	movq	0x38(%rsp), %rcx
    145c:      	movl	$0x80, %edx
    1461:      	movl	$0x2d, %eax
    1466:      	movq	0x38(%rsp), %rdx
    146b:      	movq	%r13, %rdi
    146e:      	movl	$0x80, %esi
    1473:      	callq	*%rax
    1475:      	movq	(%rsp), %rax
    1479:      	leaq	0x12c(%rax), %rdi
    1480:      	movl	$0x4, %ecx
    1485:      	movl	$0x4, %eax
    148a:      	movl	$0x4, %esi
    148f:      	movq	%r14, %rdx
    1492:      	movq	0x8(%rsp), %r14
    1497:      	callq	*%rax
    1499:      	movq	(%rsp), %rax
    149d:      	leaq	0x11c(%rax), %rdi
    14a4:      	leaq	0xe0(%r14), %rdx
    14ab:      	movl	$0x8, %ecx
    14b0:      	movl	$0x4, %eax
    14b5:      	movl	$0x8, %esi
    14ba:      	callq	*%rax
    14bc:      	movq	(%rsp), %rdi
    14c0:      	addq	$0x124, %rdi            # imm = 0x124
    14c7:      	leaq	0x118(%r14), %rdx
    14ce:      	movl	$0x8, %ecx
    14d3:      	movl	$0x4, %eax
    14d8:      	movl	$0x8, %esi
    14dd:      	callq	*%rax
    14df:      	movq	%r14, %r8
    14e2:      	movq	(%rsp), %rcx
    14e6:      	movl	$0x98, %r13d
    14ec:      	jmp	0x2d56 <generic_retuprobe_event+0x2d56>
    14f1:      	cmpl	$0x26, %r14d
    14f5:      	movq	(%rsp), %rcx
    14f9:      	jne	0x2d46 <generic_retuprobe_event+0x2d46>
    14ff:      	movq	0x10(%rsp), %rsi
    1504:      	movzwl	%si, %edx
    1507:      	addq	0xc8(%rsp), %rdx
    150f:      	shrl	$0x10, %esi
    1512:      	andl	$0xfff, %esi            # imm = 0xFFF
    1518:      	movq	%rcx, %rdi
    151b:      	addq	$0xa0, %rdi
    1522:      	incl	%esi
    1524:      	movl	$0x2d, %eax
    1529:      	jmp	0x18d4 <generic_retuprobe_event+0x18d4>
    152e:      	movq	$0x0, 0x40(%rsp)
    1537:      	movq	$0x0, 0x38(%rsp)
    1540:      	movl	$0xe, %eax
    1545:      	callq	*%rax
    1547:      	shrq	$0x20, %rax
    154b:      	movq	%rax, 0x38(%rsp)
    1550:      	leaq	0x78(%rsp), %rdi
    1555:      	leaq	0x10(%rsp), %rdx
    155a:      	movl	$0x4, %ecx
    155f:      	movl	$0x4, %eax
    1564:      	movl	$0x4, %esi
    1569:      	callq	*%rax
    156b:      	movl	0x78(%rsp), %eax
    156f:      	movl	%eax, 0x40(%rsp)
    1573:      	movq	(%rip), %rdi            # 0x157a <generic_retuprobe_event+0x157a>
    157a:      	leaq	0x38(%rsp), %rsi
    157f:      	movl	$0x1, %eax
    1584:      	callq	*%rax
    1586:      	testq	%rax, %rax
    1589:      	je	0x2093 <generic_retuprobe_event+0x2093>
    158f:      	movl	(%rax), %r13d
    1592:      	leaq	0x78(%rsp), %rdx
    1597:      	movq	%rax, %r14
    159a:      	movl	$0x4, %eax
    159f:      	movq	0x30(%rsp), %r12
    15a4:      	movl	$0x4, %ecx
    15a9:      	movq	%r12, %rdi
    15ac:      	movl	$0x4, %esi
    15b1:      	callq	*%rax
    15b3:      	andl	$0xfff, %r13d           # imm = 0xFFF
    15ba:      	movq	(%rsp), %rdi
    15be:      	addq	$0xa0, %rdi
    15c5:      	leaq	0x4(%r13), %rsi
    15c9:      	movl	$0x4, %eax
    15ce:      	movq	%r14, %rdx
    15d1:      	callq	*%rax
    15d3:      	leaq	(%r12,%r13), %rdi
    15d7:      	addq	$0x8, %rdi
    15db:      	leaq	(%r14,%r13), %rdx
    15df:      	addq	$0x4, %rdx
    15e3:      	movl	$0x4, %eax
    15e8:      	movl	$0x4, %ecx
    15ed:      	movl	$0x4, %esi
    15f2:      	callq	*%rax
    15f4:      	addq	$0xc, %r13
    15f8:      	jmp	0x2d42 <generic_retuprobe_event+0x2d42>
    15fd:      	movq	%rax, %r12
    1600:      	movq	0x10(%rsp), %r14
    1605:      	leaq	0xa0(%rsp), %rdi
    160d:      	movl	$0x1, %ecx
    1612:      	movl	$0x4, %eax
    1617:      	movl	$0x1, %esi
    161c:      	movq	%r14, %rdx
    161f:      	callq	*%rax
    1621:      	cmpb	$0x1, 0xa0(%rsp)
    1629:      	jne	0x207c <generic_retuprobe_event+0x207c>
    162f:      	addq	$0x10, %r14
    1633:      	leaq	0x38(%rsp), %rdi
    1638:      	movl	$0x8, %ecx
    163d:      	movl	$0x4, %eax
    1642:      	movl	$0x8, %esi
    1647:      	movq	%r14, %rdx
    164a:      	callq	*%rax
    164c:      	movq	0x38(%rsp), %rdx
    1651:      	leaq	0x78(%rsp), %rdi
    1656:      	movl	$0x8, %ecx
    165b:      	movl	$0x4, %eax
    1660:      	movl	$0x8, %esi
    1665:      	callq	*%rax
    1667:      	movq	0x38(%rsp), %rdx
    166c:      	addq	$0x8, %rdx
    1670:      	leaq	0xa8(%rsp), %rdi
    1678:      	movl	$0x8, %ecx
    167d:      	movl	$0x4, %eax
    1682:      	movl	$0x8, %esi
    1687:      	callq	*%rax
    1689:      	movq	0x78(%rsp), %rdx
    168e:      	movq	0xa8(%rsp), %r14
    1696:      	cmpq	$0xfff, %r14            # imm = 0xFFF
    169d:      	movl	$0xfff, %r13d           # imm = 0xFFF
    16a3:      	cmovbq	%r14, %r13
    16a7:      	movq	%r12, %rdi
    16aa:      	addq	$0xa4, %rdi
    16b1:      	movl	$0x4, %eax
    16b6:      	movl	%r13d, %esi
    16b9:      	callq	*%rax
    16bb:      	testl	%eax, %eax
    16bd:      	js	0x221e <generic_retuprobe_event+0x221e>
    16c3:      	movl	%r14d, 0x9c(%r12)
    16cb:      	movl	%r13d, 0xa0(%r12)
    16d3:      	addq	$0x8, %r13
    16d7:      	jmp	0x2d42 <generic_retuprobe_event+0x2d42>
    16dc:      	movq	0x10(%rsp), %r13
    16e1:      	leaq	0xc4(%rcx), %rdi
    16e8:      	leaq	0x98(%r13), %rdx
    16ef:      	movq	%rcx, %r14
    16f2:      	movl	$0x4, %ecx
    16f7:      	movl	$0x4, %eax
    16fc:      	movl	$0x4, %esi
    1701:      	callq	*%rax
    1703:      	leaq	0xc8(%r14), %rdi
    170a:      	leaq	0x70(%r13), %rdx
    170e:      	movl	$0x4, %ecx
    1713:      	movl	$0x4, %eax
    1718:      	movl	$0x4, %esi
    171d:      	callq	*%rax
    171f:      	leaq	0xcc(%r14), %rdi
    1726:      	leaq	0x90(%r13), %rdx
    172d:      	movl	$0x4, %ecx
    1732:      	movl	$0x4, %eax
    1737:      	movl	$0x4, %esi
    173c:      	callq	*%rax
    173e:      	leaq	0xd0(%r14), %rdi
    1745:      	leaq	0xa8(%r13), %rdx
    174c:      	movl	$0x4, %ecx
    1751:      	movl	$0x4, %eax
    1756:      	movl	$0x4, %esi
    175b:      	callq	*%rax
    175d:      	movq	$0x0, 0x38(%rsp)
    1766:      	leaq	0xc8(%r13), %rdx
    176d:      	leaq	0x38(%rsp), %rdi
    1772:      	movl	$0x8, %ecx
    1777:      	movl	$0x4, %eax
    177c:      	movl	$0x8, %esi
    1781:      	callq	*%rax
    1783:      	leaq	0xb8(%r13), %rdx
    178a:      	leaq	0xa0(%rsp), %rdi
    1792:      	movl	$0x2, %ecx
    1797:      	movl	$0x4, %eax
    179c:      	movl	$0x2, %esi
    17a1:      	callq	*%rax
    17a3:      	movzwl	0xa0(%rsp), %r12d
    17ac:      	addq	0x38(%rsp), %r12
    17b1:      	leaq	0xc4(%rsp), %rdi
    17b9:      	movl	$0x1, %ecx
    17be:      	movl	$0x4, %eax
    17c3:      	movl	$0x1, %esi
    17c8:      	movq	%r12, %rdx
    17cb:      	callq	*%rax
    17cd:      	movzbl	0xc4(%rsp), %eax
    17d5:      	shrl	$0x4, %eax
    17d8:      	cmpl	$0x6, %eax
    17db:      	je	0x209f <generic_retuprobe_event+0x209f>
    17e1:      	cmpl	$0x4, %eax
    17e4:      	jne	0x2d3c <generic_retuprobe_event+0x2d3c>
    17ea:      	movq	%rbx, 0x18(%rsp)
    17ef:      	leaq	0x9(%r12), %rdx
    17f4:      	leaq	0xd0(%rsp), %rdi
    17fc:      	movl	$0x1, %ecx
    1801:      	movl	$0x4, %eax
    1806:      	movl	$0x1, %esi
    180b:      	callq	*%rax
    180d:      	movzbl	0xd0(%rsp), %eax
    1815:      	movq	(%rsp), %rsi
    1819:      	movw	%ax, 0xc0(%rsi)
    1820:      	movw	$0x2, 0xc2(%rsi)
    1829:      	leaq	0xc(%r12), %rdx
    182e:      	movq	0x30(%rsp), %rdi
    1833:      	movq	$0x0, (%rdi)
    183a:      	movq	$0x0, 0x8(%rdi)
    1842:      	movq	$0x0, 0x10(%rdi)
    184a:      	movq	$0x0, 0x18(%rdi)
    1852:      	movl	$0x4, %ecx
    1857:      	movl	$0x4, %eax
    185c:      	leaq	0xac(%rsi), %r14
    1863:      	movl	$0x4, %esi
    1868:      	callq	*%rax
    186a:      	addq	$0x10, %r12
    186e:      	movl	$0x4, %ecx
    1873:      	movl	$0x4, %eax
    1878:      	movq	%r14, %rdi
    187b:      	movl	$0x4, %esi
    1880:      	movq	%r12, %rdx
    1883:      	callq	*%rax
    1885:      	movq	%r13, 0x90(%rsp)
    188d:      	leaq	0xb6(%r13), %rdx
    1894:      	leaq	0xd8(%rsp), %rdi
    189c:      	movl	$0x2, %ecx
    18a1:      	movl	$0x4, %eax
    18a6:      	movl	$0x2, %esi
    18ab:      	jmp	0x2baa <generic_retuprobe_event+0x2baa>
    18b0:      	movl	$0x120, %edx            # imm = 0x120
    18b5:      	addq	0x10(%rsp), %rdx
    18ba:      	movq	(%rsp), %rdi
    18be:      	addq	$0xa0, %rdi
    18c5:      	movl	$0x11, %ecx
    18ca:      	movl	$0x2d, %eax
    18cf:      	movl	$0x11, %esi
    18d4:      	callq	*%rax
    18d6:      	movq	%rax, %r13
    18d9:      	testq	%rax, %rax
    18dc:      	js	0x2d42 <generic_retuprobe_event+0x2d42>
    18e2:      	leal	-0x1(%r13), %eax
    18e6:      	movq	0x30(%rsp), %rcx
    18eb:      	movl	%eax, (%rcx)
    18ed:      	addq	$0x3, %r13
    18f1:      	jmp	0x2d42 <generic_retuprobe_event+0x2d42>
    18f6:      	movq	0x10(%rsp), %r12
    18fb:      	movq	$0x0, 0x10(%rdi)
    1903:      	movq	$0x0, 0x8(%rdi)
    190b:      	movq	$0x0, (%rdi)
    1912:      	movl	$0x2, %ecx
    1917:      	movl	$0x4, %eax
    191c:      	movq	%rdi, %r14
    191f:      	movl	$0x2, %esi
    1924:      	movq	%r12, %rdx
    1927:      	callq	*%rax
    1929:      	testq	%rax, %rax
    192c:      	movq	(%rsp), %rcx
    1930:      	js	0x2290 <generic_retuprobe_event+0x2290>
    1936:      	movzwl	(%r14), %eax
    193a:      	cmpl	$0xa, %eax
    193d:      	je	0x2235 <generic_retuprobe_event+0x2235>
    1943:      	cmpl	$0x2, %eax
    1946:      	jne	0x2277 <generic_retuprobe_event+0x2277>
    194c:      	leaq	0x4(%r12), %rdx
    1951:      	leaq	0x38(%rsp), %rdi
    1956:      	movl	$0x4, %ecx
    195b:      	movl	$0x4, %eax
    1960:      	movl	$0x4, %esi
    1965:      	callq	*%rax
    1967:      	movl	0x38(%rsp), %eax
    196b:      	movq	(%rsp), %rdi
    196f:      	movq	%rax, 0xa4(%rdi)
    1976:      	addq	$0x9e, %rdi
    197d:      	addq	$0x2, %r12
    1981:      	movl	$0x2, %ecx
    1986:      	movl	$0x4, %eax
    198b:      	jmp	0x226d <generic_retuprobe_event+0x226d>
    1990:      	xorl	%eax, %eax
    1992:      	movq	%rax, 0x8(%rsp)
    1997:      	cmpq	$0x3, 0xb8(%rsp)
    19a0:      	jb	0x1a67 <generic_retuprobe_event+0x1a67>
    19a6:      	movq	%r14, %rbp
    19a9:      	movq	%rbx, 0x18(%rsp)
    19ae:      	movq	0x88(%rsp), %rax
    19b6:      	leaq	0x20(%rax), %rdx
    19ba:      	leaq	0x38(%rsp), %rdi
    19bf:      	movl	$0x4, %r12d
    19c5:      	movl	$0x10, %ecx
    19ca:      	movl	$0x4, %eax
    19cf:      	movl	$0x10, %esi
    19d4:      	callq	*%rax
    19d6:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    19db:      	testl	%eax, %eax
    19dd:      	js	0x1a74 <generic_retuprobe_event+0x1a74>
    19e3:      	movq	0x40(%rsp), %r14
    19e8:      	movq	0x8(%rsp), %rax
    19ed:      	cmpq	%rax, %r14
    19f0:      	movq	%rax, %rcx
    19f3:      	cmovbq	%r14, %rcx
    19f7:      	testq	%rax, %rax
    19fa:      	movq	%rcx, %rbx
    19fd:      	cmovneq	%rcx, %r14
    1a01:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    1a06:      	cmpq	$0xffe, %r14            # imm = 0xFFE
    1a0d:      	ja	0x1a74 <generic_retuprobe_event+0x1a74>
    1a0f:      	addq	0x20(%rsp), %rbp
    1a14:      	movq	%rbp, (%rsp)
    1a18:      	movl	%ebp, %edi
    1a1a:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    1a20:      	addq	%r15, %rdi
    1a23:      	movq	0x38(%rsp), %rcx
    1a28:      	movl	$0x4, %eax
    1a2d:      	movq	0x38(%rsp), %rdx
    1a32:      	movl	%r14d, %esi
    1a35:      	callq	*%rax
    1a37:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1a3c:      	testl	%eax, %eax
    1a3e:      	js	0x1a74 <generic_retuprobe_event+0x1a74>
    1a40:      	movq	%r15, 0x20(%rsp)
    1a45:      	movq	%r14, %r15
    1a48:      	addq	%r14, %r13
    1a4b:      	cmpq	$0x0, 0x8(%rsp)
    1a51:      	je	0x24ca <generic_retuprobe_event+0x24ca>
    1a57:      	subq	%rbx, 0x8(%rsp)
    1a5c:      	jne	0x24d1 <generic_retuprobe_event+0x24d1>
    1a62:      	jmp	0x24dc <generic_retuprobe_event+0x24dc>
    1a67:      	movq	%r13, %rbp
    1a6a:      	movq	0x28(%rsp), %rax
    1a6f:      	jmp	0x320 <generic_retuprobe_event+0x320>
    1a74:      	movq	0x28(%rsp), %rax
    1a79:      	movl	%ecx, (%r15,%rax)
    1a7d:      	movq	0x18(%rsp), %rbx
    1a82:      	jmp	0xbcc <generic_retuprobe_event+0xbcc>
    1a87:      	movq	%rbp, 0x88(%rsp)
    1a8f:      	movq	%r12, 0x98(%rsp)
    1a97:      	movq	$0x0, 0x78(%rsp)
    1aa0:      	movq	$0x0, 0x38(%rsp)
    1aa9:      	leaq	0x78(%rsp), %rdi
    1aae:      	leaq	0x38(%rsp), %rdx
    1ab3:      	movl	$0x8, %ecx
    1ab8:      	movq	%rax, %r12
    1abb:      	movl	$0x4, %eax
    1ac0:      	movl	$0x4, %r13d
    1ac6:      	movl	$0x8, %esi
    1acb:      	callq	*%rax
    1acd:      	movq	0x78(%rsp), %rbp
    1ad2:      	cmpq	$0xfff, %rbp            # imm = 0xFFF
    1ad9:      	movl	$0xfff, %r14d           # imm = 0xFFF
    1adf:      	cmovbq	%rbp, %r14
    1ae3:      	movq	%r12, 0x18(%rsp)
    1ae8:      	addq	$0xa4, %r12
    1aef:      	movl	$0x4, %eax
    1af4:      	movq	0x8(%rsp), %rdx
    1af9:      	movq	%r12, %rdi
    1afc:      	movl	%r14d, %esi
    1aff:      	callq	*%rax
    1b01:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1b06:      	testl	%eax, %eax
    1b08:      	js	0x1b1f <generic_retuprobe_event+0x1b1f>
    1b0a:      	movq	0x18(%rsp), %rax
    1b0f:      	movl	%r14d, 0xa0(%rax)
    1b16:      	addq	$0x8, %r14
    1b1a:      	movl	%ebp, %ecx
    1b1c:      	movq	%r14, %r13
    1b1f:      	movq	0x18(%rsp), %rax
    1b24:      	movl	%ecx, 0x9c(%rax)
    1b2a:      	movq	0x98(%rsp), %r12
    1b32:      	movq	0x8(%rsp), %r8
    1b37:      	movq	0x88(%rsp), %rbp
    1b3f:      	jmp	0x1400 <generic_retuprobe_event+0x1400>
    1b44:      	movq	%rbp, %r14
    1b47:      	leaq	0xc4(%rcx), %rbp
    1b4e:      	leaq	0xdc(%rcx), %rax
    1b55:      	movq	%rax, 0x18(%rsp)
    1b5a:      	movq	0x8(%rsp), %r13
    1b5f:      	leaq	0x8(%r13), %rdx
    1b63:      	movl	$0x4, %ecx
    1b68:      	movl	$0x4, %eax
    1b6d:      	movl	$0x4, %esi
    1b72:      	callq	*%rax
    1b74:      	movq	(%rsp), %rax
    1b78:      	leaq	0xa0(%rax), %rdi
    1b7f:      	leaq	0xc(%r13), %rdx
    1b83:      	movl	$0x4, %ecx
    1b88:      	movl	$0x4, %eax
    1b8d:      	movl	$0x4, %esi
    1b92:      	callq	*%rax
    1b94:      	movq	(%rsp), %rax
    1b98:      	leaq	0xac(%rax), %rdi
    1b9f:      	leaq	0x18(%r13), %rdx
    1ba3:      	movl	$0x4, %ecx
    1ba8:      	movl	$0x4, %eax
    1bad:      	movl	$0x4, %esi
    1bb2:      	callq	*%rax
    1bb4:      	movq	(%rsp), %rax
    1bb8:      	leaq	0xb0(%rax), %rdi
    1bbf:      	leaq	0x1c(%r13), %rdx
    1bc3:      	movl	$0x4, %ecx
    1bc8:      	movl	$0x4, %eax
    1bcd:      	movl	$0x4, %esi
    1bd2:      	callq	*%rax
    1bd4:      	movq	(%rsp), %rax
    1bd8:      	leaq	0xa4(%rax), %rdi
    1bdf:      	leaq	0x10(%r13), %rdx
    1be3:      	movl	$0x4, %ecx
    1be8:      	movl	$0x4, %eax
    1bed:      	movl	$0x4, %esi
    1bf2:      	callq	*%rax
    1bf4:      	movq	(%rsp), %rax
    1bf8:      	leaq	0xa8(%rax), %rdi
    1bff:      	leaq	0x14(%r13), %rdx
    1c03:      	movl	$0x4, %ecx
    1c08:      	movl	$0x4, %eax
    1c0d:      	movl	$0x4, %esi
    1c12:      	callq	*%rax
    1c14:      	movq	(%rsp), %rax
    1c18:      	leaq	0xb4(%rax), %rdi
    1c1f:      	leaq	0x20(%r13), %rdx
    1c23:      	movl	$0x4, %ecx
    1c28:      	movl	$0x4, %eax
    1c2d:      	movl	$0x4, %esi
    1c32:      	callq	*%rax
    1c34:      	movq	(%rsp), %rax
    1c38:      	leaq	0xb8(%rax), %rdi
    1c3f:      	leaq	0x24(%r13), %rdx
    1c43:      	movl	$0x4, %ecx
    1c48:      	movl	$0x4, %eax
    1c4d:      	movl	$0x4, %esi
    1c52:      	callq	*%rax
    1c54:      	movq	(%rsp), %rax
    1c58:      	movl	$0x0, 0xc0(%rax)
    1c62:      	movq	(%rsp), %rax
    1c66:      	leaq	0xbc(%rax), %rdi
    1c6d:      	leaq	0x28(%r13), %rdx
    1c71:      	movl	$0x4, %ecx
    1c76:      	movl	$0x4, %eax
    1c7b:      	movl	$0x4, %esi
    1c80:      	callq	*%rax
    1c82:      	movq	(%rsp), %rax
    1c86:      	leaq	0xcc(%rax), %rdi
    1c8d:      	leaq	0x40(%r13), %rdx
    1c91:      	movl	$0x8, %ecx
    1c96:      	movl	$0x4, %eax
    1c9b:      	movl	$0x8, %esi
    1ca0:      	callq	*%rax
    1ca2:      	movq	(%rsp), %rax
    1ca6:      	leaq	0xd4(%rax), %rdi
    1cad:      	leaq	0x30(%r13), %rdx
    1cb1:      	movl	$0x8, %ecx
    1cb6:      	movl	$0x4, %eax
    1cbb:      	movl	$0x8, %esi
    1cc0:      	callq	*%rax
    1cc2:      	leaq	0x38(%r13), %rdx
    1cc6:      	movl	$0x8, %ecx
    1ccb:      	movl	$0x4, %eax
    1cd0:      	movq	%rbp, %rdi
    1cd3:      	movq	%r14, %rbp
    1cd6:      	movl	$0x8, %esi
    1cdb:      	callq	*%rax
    1cdd:      	leaq	0x90(%r13), %rdx
    1ce4:      	leaq	0x38(%rsp), %rdi
    1ce9:      	movl	$0x8, %ecx
    1cee:      	movl	$0x4, %eax
    1cf3:      	movl	$0x8, %esi
    1cf8:      	callq	*%rax
    1cfa:      	movq	0x38(%rsp), %r14
    1cff:      	leaq	0xc8(%r14), %rdx
    1d06:      	movl	$0x4, %ecx
    1d0b:      	movl	$0x4, %eax
    1d10:      	movq	0x18(%rsp), %rdi
    1d15:      	movl	$0x4, %esi
    1d1a:      	callq	*%rax
    1d1c:      	movq	(%rsp), %rax
    1d20:      	leaq	0xe0(%rax), %rdi
    1d27:      	leaq	0xcc(%r14), %rdx
    1d2e:      	movl	$0x4, %ecx
    1d33:      	movl	$0x4, %eax
    1d38:      	movl	$0x4, %esi
    1d3d:      	callq	*%rax
    1d3f:      	movq	(%rsp), %rax
    1d43:      	leaq	0xe4(%rax), %rdi
    1d4a:      	leaq	0xd0(%r14), %rdx
    1d51:      	movl	$0x4, %ecx
    1d56:      	movl	$0x4, %eax
    1d5b:      	movl	$0x4, %esi
    1d60:      	callq	*%rax
    1d62:      	movq	(%rsp), %rdi
    1d66:      	addq	$0xe8, %rdi
    1d6d:      	addq	$0x158, %r14            # imm = 0x158
    1d74:      	movl	$0x4, %ecx
    1d79:      	movl	$0x4, %eax
    1d7e:      	movl	$0x4, %esi
    1d83:      	movq	%r14, %rdx
    1d86:      	callq	*%rax
    1d88:      	movq	%r13, %r8
    1d8b:      	movq	(%rsp), %rcx
    1d8f:      	movl	$0x50, %r13d
    1d95:      	jmp	0x2d56 <generic_retuprobe_event+0x2d56>
    1d9a:      	movq	0x8(%rsp), %r14
    1d9f:      	leaq	0xc8(%r14), %rdx
    1da6:      	movl	$0x4, %ecx
    1dab:      	movl	$0x4, %eax
    1db0:      	movl	$0x4, %esi
    1db5:      	callq	*%rax
    1db7:      	movq	(%rsp), %rax
    1dbb:      	leaq	0xa0(%rax), %rdi
    1dc2:      	leaq	0xcc(%r14), %rdx
    1dc9:      	movl	$0x4, %ecx
    1dce:      	movl	$0x4, %eax
    1dd3:      	movl	$0x4, %esi
    1dd8:      	callq	*%rax
    1dda:      	movq	(%rsp), %rax
    1dde:      	leaq	0xa4(%rax), %rdi
    1de5:      	leaq	0xd0(%r14), %rdx
    1dec:      	movl	$0x4, %ecx
    1df1:      	movl	$0x4, %eax
    1df6:      	movl	$0x4, %esi
    1dfb:      	callq	*%rax
    1dfd:      	movq	(%rsp), %rdi
    1e01:      	addq	$0xa8, %rdi
    1e08:      	leaq	0x158(%r14), %rdx
    1e0f:      	movl	$0x4, %ecx
    1e14:      	movl	$0x4, %eax
    1e19:      	movl	$0x4, %esi
    1e1e:      	callq	*%rax
    1e20:      	movq	%r14, %r8
    1e23:      	movq	(%rsp), %rcx
    1e27:      	movl	$0x10, %r13d
    1e2d:      	jmp	0x2d56 <generic_retuprobe_event+0x2d56>
    1e32:      	movq	0x8(%rsp), %r14
    1e37:      	leaq	0x38(%r14), %rdx
    1e3b:      	movl	$0x4, %ecx
    1e40:      	movl	$0x4, %eax
    1e45:      	movl	$0x4, %esi
    1e4a:      	callq	*%rax
    1e4c:      	movq	(%rsp), %rax
    1e50:      	leaq	0xa0(%rax), %rdi
    1e57:      	leaq	0x3c(%r14), %rdx
    1e5b:      	movl	$0x4, %ecx
    1e60:      	movl	$0x4, %eax
    1e65:      	movl	$0x4, %esi
    1e6a:      	callq	*%rax
    1e6c:      	movq	(%rsp), %rax
    1e70:      	leaq	0xa4(%rax), %rdi
    1e77:      	leaq	0x40(%r14), %rdx
    1e7b:      	movl	$0x4, %ecx
    1e80:      	movl	$0x4, %eax
    1e85:      	movl	$0x4, %esi
    1e8a:      	callq	*%rax
    1e8c:      	movq	(%rsp), %rax
    1e90:      	leaq	0xa8(%rax), %rdi
    1e97:      	leaq	0x44(%r14), %rdx
    1e9b:      	movl	$0x4, %ecx
    1ea0:      	movl	$0x4, %eax
    1ea5:      	movl	$0x4, %esi
    1eaa:      	callq	*%rax
    1eac:      	movq	(%rsp), %rdi
    1eb0:      	addq	$0xac, %rdi
    1eb7:      	leaq	0x80(%r14), %rdx
    1ebe:      	movl	$0x10, %ecx
    1ec3:      	movl	$0x4, %eax
    1ec8:      	movl	$0x10, %esi
    1ecd:      	callq	*%rax
    1ecf:      	movq	%r14, %r8
    1ed2:      	movq	(%rsp), %rcx
    1ed6:      	movl	$0x20, %r13d
    1edc:      	jmp	0x2d56 <generic_retuprobe_event+0x2d56>
    1ee1:      	movl	$0x4, %ecx
    1ee6:      	movl	$0x4, %eax
    1eeb:      	movq	0x8(%rsp), %r14
    1ef0:      	movl	$0x4, %esi
    1ef5:      	movq	%r14, %rdx
    1ef8:      	callq	*%rax
    1efa:      	movq	(%rsp), %rax
    1efe:      	leaq	0xa0(%rax), %rdi
    1f05:      	leaq	0x4(%r14), %rdx
    1f09:      	movl	$0x4, %ecx
    1f0e:      	movl	$0x4, %eax
    1f13:      	movl	$0x4, %esi
    1f18:      	callq	*%rax
    1f1a:      	movq	(%rsp), %rdi
    1f1e:      	addq	$0xa4, %rdi
    1f25:      	leaq	0x30(%r14), %rdx
    1f29:      	movl	$0x10, %ecx
    1f2e:      	movl	$0x4, %eax
    1f33:      	movl	$0x10, %esi
    1f38:      	callq	*%rax
    1f3a:      	movq	%r14, %r8
    1f3d:      	movq	(%rsp), %rcx
    1f41:      	movl	$0x18, %r13d
    1f47:      	jmp	0x2d56 <generic_retuprobe_event+0x2d56>
    1f4c:      	movq	0x8(%rsp), %r13
    1f51:      	leaq	0x4(%r13), %rdx
    1f55:      	leaq	0x38(%rsp), %rdi
    1f5a:      	movl	$0x4, %ecx
    1f5f:      	movl	$0x4, %eax
    1f64:      	movl	$0x4, %esi
    1f69:      	callq	*%rax
    1f6b:      	movl	0x38(%rsp), %eax
    1f6f:      	movq	(%rsp), %r14
    1f73:      	movl	%eax, 0x9c(%r14)
    1f7a:      	leaq	0xc(%r13), %rdx
    1f7e:      	leaq	0x38(%rsp), %rdi
    1f83:      	movl	$0x4, %ecx
    1f88:      	movl	$0x4, %eax
    1f8d:      	movl	$0x4, %esi
    1f92:      	callq	*%rax
    1f94:      	movl	0x38(%rsp), %eax
    1f98:      	movl	%eax, 0xa0(%r14)
    1f9f:      	leaq	0x50(%r13), %rdx
    1fa3:      	leaq	0x38(%rsp), %rdi
    1fa8:      	movl	$0x8, %ecx
    1fad:      	movl	$0x2d, %eax
    1fb2:      	movl	$0x8, %esi
    1fb7:      	callq	*%rax
    1fb9:      	movq	%r14, %rdi
    1fbc:      	addq	$0xa4, %rdi
    1fc3:      	movl	$0x3f8, %edx            # imm = 0x3F8
    1fc8:      	movq	0x38(%rsp), %rcx
    1fcd:      	addq	%rdx, %rcx
    1fd0:      	movl	$0x10, %esi
    1fd5:      	movl	$0x2d, %eax
    1fda:      	addq	0x38(%rsp), %rdx
    1fdf:      	movl	$0x10, %esi
    1fe4:      	callq	*%rax
    1fe6:      	movq	%r13, %r8
    1fe9:      	movq	%r14, %rcx
    1fec:      	movl	$0x18, %r13d
    1ff2:      	jmp	0x2d56 <generic_retuprobe_event+0x2d56>
    1ff7:      	movq	$0x0, 0x48(%rdi)
    1fff:      	movq	$0x0, 0x40(%rdi)
    2007:      	movq	$0x0, 0x38(%rdi)
    200f:      	movq	$0x0, 0x30(%rdi)
    2017:      	movq	$0x0, 0x28(%rdi)
    201f:      	movq	$0x0, 0x20(%rdi)
    2027:      	movq	$0x0, 0x18(%rdi)
    202f:      	movq	$0x0, 0x10(%rdi)
    2037:      	movq	$0x0, 0x8(%rdi)
    203f:      	movq	%rdi, 0x30(%rsp)
    2044:      	movq	$0x0, (%rdi)
    204b:      	leaq	0x38(%rsp), %rdi
    2050:      	movl	$0x8, %ecx
    2055:      	movl	$0x4, %eax
    205a:      	movq	0x8(%rsp), %rdx
    205f:      	movl	$0x8, %esi
    2064:      	callq	*%rax
    2066:      	testq	%rax, %rax
    2069:      	je	0x229b <generic_retuprobe_event+0x229b>
    206f:      	xorl	%r13d, %r13d
    2072:      	movq	0x8(%rsp), %r8
    2077:      	jmp	0x2484 <generic_retuprobe_event+0x2484>
    207c:      	movq	$0x0, 0x9c(%r12)
    2088:      	movl	$0x8, %r13d
    208e:      	jmp	0x2d42 <generic_retuprobe_event+0x2d42>
    2093:      	movq	$-0x1, %r13
    209a:      	jmp	0x2d42 <generic_retuprobe_event+0x2d42>
    209f:      	movq	%r13, 0x90(%rsp)
    20a7:      	movq	%rbx, 0x18(%rsp)
    20ac:      	movq	0x38(%rsp), %r14
    20b1:      	movl	$0x0, 0x78(%rsp)
    20b9:      	movzwl	0xa0(%rsp), %r12d
    20c2:      	movq	(%rip), %rdi            # 0x20c9 <generic_retuprobe_event+0x20c9>
    20c9:      	leaq	0x78(%rsp), %rsi
    20ce:      	movl	$0x1, %eax
    20d3:      	leaq	(%r14,%r12), %r13
    20d7:      	callq	*%rax
    20d9:      	testq	%rax, %rax
    20dc:      	je	0x2b53 <generic_retuprobe_event+0x2b53>
    20e2:      	movq	%rax, %rbx
    20e5:      	movw	%r12w, (%rax)
    20e9:      	movb	$-0x1, 0x5(%rax)
    20ed:      	movb	$0x0, 0x7(%rax)
    20f1:      	movq	%rax, %rdi
    20f4:      	addq	$0x6, %rdi
    20f8:      	leaq	0x6(%r13), %rdx
    20fc:      	movl	$0x1, %ecx
    2101:      	movl	$0x4, %eax
    2106:      	movq	%rdi, %r12
    2109:      	movl	$0x1, %esi
    210e:      	callq	*%rax
    2110:      	testq	%rax, %rax
    2113:      	js	0x2b53 <generic_retuprobe_event+0x2b53>
    2119:      	movzbl	0x5(%rbx), %eax
    211d:      	cmpl	$0x32, %eax
    2120:      	jg	0x2492 <generic_retuprobe_event+0x2492>
    2126:      	testl	%eax, %eax
    2128:      	je	0x24ba <generic_retuprobe_event+0x24ba>
    212e:      	cmpl	$0x2b, %eax
    2131:      	je	0x24ba <generic_retuprobe_event+0x24ba>
    2137:      	cmpl	$0x2c, %eax
    213a:      	jne	0x2661 <generic_retuprobe_event+0x2661>
    2140:      	movw	$0x8, 0x2(%rbx)
    2146:      	movw	$0x8, %ax
    214a:      	jmp	0x25bc <generic_retuprobe_event+0x25bc>
    214f:      	leaq	0x48(%r13), %rdx
    2153:      	movl	$0x10, %ecx
    2158:      	movl	$0x4, %eax
    215d:      	movl	$0x10, %esi
    2162:      	callq	*%rax
    2164:      	leaq	0x38(%r13), %rdx
    2168:      	movl	$0x10, %ecx
    216d:      	movl	$0x4, %eax
    2172:      	movq	%r14, %rdi
    2175:      	movl	$0x10, %esi
    217a:      	callq	*%rax
    217c:      	movq	(%rsp), %r12
    2180:      	leaq	0xbc(%r12), %rdi
    2188:      	leaq	0xc(%r13), %r14
    218c:      	addq	$0xe, %r13
    2190:      	movl	$0x2, %ecx
    2195:      	movl	$0x4, %eax
    219a:      	movl	$0x2, %esi
    219f:      	movq	%r13, %rdx
    21a2:      	callq	*%rax
    21a4:      	movq	%r12, %rdi
    21a7:      	addq	$0xbe, %rdi
    21ae:      	movl	$0x2, %ecx
    21b3:      	movl	$0x4, %eax
    21b8:      	movl	$0x2, %esi
    21bd:      	movq	%r14, %rdx
    21c0:      	callq	*%rax
    21c2:      	movzwl	0xbe(%r12), %eax
    21cb:      	movbew	%ax, 0xbe(%r12)
    21d6:      	movq	0x10(%rsp), %rax
    21db:      	movq	%rax, 0x38(%rsp)
    21e0:      	movq	(%rip), %rdi            # 0x21e7 <generic_retuprobe_event+0x21e7>
    21e7:      	leaq	0x38(%rsp), %rsi
    21ec:      	movl	$0x1, %eax
    21f1:      	callq	*%rax
    21f3:      	testq	%rax, %rax
    21f6:      	je	0x2d3c <generic_retuprobe_event+0x2d3c>
    21fc:      	movl	(%rax), %ecx
    21fe:      	movq	0x18(%rsp), %r12
    2203:      	movl	%ecx, 0x10(%r12)
    2208:      	movq	0x8(%rax), %rcx
    220c:      	movq	%rcx, 0x18(%r12)
    2211:      	movl	0x4(%rax), %eax
    2214:      	movl	%eax, 0x7c(%r12)
    2219:      	jmp	0x2d3c <generic_retuprobe_event+0x2d3c>
    221e:      	movl	$0xfffffffe, 0x9c(%r12) # imm = 0xFFFFFFFE
    222a:      	movl	$0x4, %r13d
    2230:      	jmp	0x2d42 <generic_retuprobe_event+0x2d42>
    2235:      	leaq	0xa4(%rcx), %rdi
    223c:      	leaq	0x8(%r12), %rdx
    2241:      	movq	%rcx, %r14
    2244:      	movl	$0x10, %ecx
    2249:      	movl	$0x4, %eax
    224e:      	movl	$0x10, %esi
    2253:      	callq	*%rax
    2255:      	movq	%r14, %rdi
    2258:      	addq	$0x9e, %rdi
    225f:      	addq	$0x2, %r12
    2263:      	movl	$0x2, %ecx
    2268:      	movl	$0x4, %eax
    226d:      	movl	$0x2, %esi
    2272:      	movq	%r12, %rdx
    2275:      	callq	*%rax
    2277:      	movq	(%rsp), %rcx
    227b:      	movzwl	0x9e(%rcx), %eax
    2282:      	movbew	%ax, 0x9e(%rcx)
    228b:      	movq	0x20(%rsp), %r15
    2290:      	movl	$0x18, %r13d
    2296:      	jmp	0x2d46 <generic_retuprobe_event+0x2d46>
    229b:      	movq	(%rsp), %rax
    229f:      	leaq	0xac(%rax), %rdi
    22a6:      	movq	0x38(%rsp), %rcx
    22ab:      	movl	$0x3f, %edx
    22b0:      	movl	$0x2d, %eax
    22b5:      	movq	0x38(%rsp), %rdx
    22ba:      	movl	$0x3f, %esi
    22bf:      	callq	*%rax
    22c1:      	testq	%rax, %rax
    22c4:      	js	0x206f <generic_retuprobe_event+0x206f>
    22ca:      	movq	0x8(%rsp), %r14
    22cf:      	leaq	0x8(%r14), %rdx
    22d3:      	leaq	0x78(%rsp), %rdi
    22d8:      	movl	$0x8, %ecx
    22dd:      	movl	$0x4, %eax
    22e2:      	movl	$0x8, %esi
    22e7:      	callq	*%rax
    22e9:      	movq	(%rsp), %rdi
    22ed:      	addq	$0xa4, %rdi
    22f4:      	movl	$0x348, %edx            # imm = 0x348
    22f9:      	movq	0x78(%rsp), %rcx
    22fe:      	addq	%rdx, %rcx
    2301:      	movl	$0x8, %esi
    2306:      	movl	$0x4, %eax
    230b:      	addq	0x78(%rsp), %rdx
    2310:      	movl	$0x8, %esi
    2315:      	callq	*%rax
    2317:      	leaq	0x58(%r14), %rdx
    231b:      	leaq	0x78(%rsp), %rdi
    2320:      	movl	$0x4, %ecx
    2325:      	movl	$0x4, %eax
    232a:      	movl	$0x4, %esi
    232f:      	callq	*%rax
    2331:      	movl	$0x50, %r13d
    2337:      	testq	%rax, %rax
    233a:      	jne	0x2072 <generic_retuprobe_event+0x2072>
    2340:      	xorl	%eax, %eax
    2342:      	cmpl	$0x0, 0x78(%rsp)
    2347:      	setne	%al
    234a:      	movq	0x30(%rsp), %rcx
    234f:      	movl	%eax, (%rcx)
    2351:      	jmp	0x2072 <generic_retuprobe_event+0x2072>
    2356:      	xorl	%r13d, %r13d
    2359:      	movq	(%rsp), %rcx
    235d:      	movq	0x8(%rsp), %r8
    2362:      	jmp	0x2d56 <generic_retuprobe_event+0x2d56>
    2367:      	addq	$0x3, %r12
    236b:      	movl	$0x6b, %ecx
    2370:      	movl	$0x71, %eax
    2375:      	movl	$0x6b, %esi
    237a:      	movq	%r12, %rdx
    237d:      	callq	*%rax
    237f:      	movq	%rax, %rcx
    2382:      	movb	$0x6b, %al
    2384:      	testl	%ecx, %ecx
    2386:      	js	0x2392 <generic_retuprobe_event+0x2392>
    2388:      	movq	(%rsp), %rcx
    238c:      	movb	%al, 0x9f(%rcx)
    2392:      	movl	$0x70, %r13d
    2398:      	jmp	0x2d42 <generic_retuprobe_event+0x2d42>
    239d:      	leaq	0x48(%r13), %rdx
    23a1:      	movl	$0x10, %ecx
    23a6:      	movl	$0x4, %eax
    23ab:      	movq	0x30(%rsp), %rdi
    23b0:      	movl	$0x10, %esi
    23b5:      	callq	*%rax
    23b7:      	leaq	0x38(%r13), %rdx
    23bb:      	movl	$0x10, %ecx
    23c0:      	movl	$0x4, %eax
    23c5:      	movq	%r14, %rdi
    23c8:      	movl	$0x10, %esi
    23cd:      	callq	*%rax
    23cf:      	movq	(%rsp), %r12
    23d3:      	leaq	0xbc(%r12), %rdi
    23db:      	leaq	0xc(%r13), %r14
    23df:      	addq	$0xe, %r13
    23e3:      	movl	$0x2, %ecx
    23e8:      	movl	$0x4, %eax
    23ed:      	movl	$0x2, %esi
    23f2:      	movq	%r13, %rdx
    23f5:      	callq	*%rax
    23f7:      	movq	%r12, %rdi
    23fa:      	addq	$0xbe, %rdi
    2401:      	movl	$0x2, %ecx
    2406:      	movl	$0x4, %eax
    240b:      	movl	$0x2, %esi
    2410:      	movq	%r14, %rdx
    2413:      	callq	*%rax
    2415:      	movzwl	0xbe(%r12), %eax
    241e:      	movbew	%ax, 0xbe(%r12)
    2429:      	movq	(%rsp), %rax
    242d:      	movq	0xc4(%rax), %rax
    2434:      	movq	%rax, 0x38(%rsp)
    2439:      	movq	(%rip), %rdi            # 0x2440 <generic_retuprobe_event+0x2440>
    2440:      	leaq	0x38(%rsp), %rsi
    2445:      	movl	$0x1, %eax
    244a:      	callq	*%rax
    244c:      	testq	%rax, %rax
    244f:      	je	0x246e <generic_retuprobe_event+0x246e>
    2451:      	movl	(%rax), %ecx
    2453:      	movq	0x18(%rsp), %r12
    2458:      	movl	%ecx, 0x10(%r12)
    245d:      	movq	0x8(%rax), %rcx
    2461:      	movq	%rcx, 0x18(%r12)
    2466:      	movl	0x4(%rax), %eax
    2469:      	movl	%eax, 0x7c(%r12)
    246e:      	movl	$0x40, %r13d
    2474:      	movq	%rbp, %r12
    2477:      	movq	0x8(%rsp), %r8
    247c:      	movq	0x88(%rsp), %rbp
    2484:      	movq	(%rsp), %rcx
    2488:      	movq	0x20(%rsp), %r15
    248d:      	jmp	0x2d56 <generic_retuprobe_event+0x2d56>
    2492:      	cmpl	$0x33, %eax
    2495:      	je	0x25ad <generic_retuprobe_event+0x25ad>
    249b:      	cmpl	$0x3c, %eax
    249e:      	je	0x24ba <generic_retuprobe_event+0x24ba>
    24a0:      	cmpl	$0xff, %eax
    24a5:      	jne	0x2661 <generic_retuprobe_event+0x2661>
    24ab:      	movw	$0x28, 0x2(%rbx)
    24b1:      	movw	$0x28, %ax
    24b5:      	jmp	0x25bc <generic_retuprobe_event+0x25bc>
    24ba:      	movzbl	0x7(%rbx), %eax
    24be:      	leal	0x8(,%rax,8), %eax
    24c5:      	jmp	0x25b8 <generic_retuprobe_event+0x25b8>
    24ca:      	xorl	%eax, %eax
    24cc:      	movq	%rax, 0x8(%rsp)
    24d1:      	cmpq	$0x3, 0xb8(%rsp)
    24da:      	jne	0x24f3 <generic_retuprobe_event+0x24f3>
    24dc:      	movq	%r13, %rbp
    24df:      	movq	0x18(%rsp), %rbx
    24e4:      	movq	0x28(%rsp), %rax
    24e9:      	movq	0x20(%rsp), %r15
    24ee:      	jmp	0x320 <generic_retuprobe_event+0x320>
    24f3:      	movq	0x88(%rsp), %rax
    24fb:      	leaq	0x30(%rax), %rdx
    24ff:      	leaq	0x38(%rsp), %rdi
    2504:      	movl	$0x4, %r12d
    250a:      	movl	$0x10, %ecx
    250f:      	movl	$0x4, %eax
    2514:      	movl	$0x10, %esi
    2519:      	callq	*%rax
    251b:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2520:      	testl	%eax, %eax
    2522:      	js	0x325d <generic_retuprobe_event+0x325d>
    2528:      	movq	0x40(%rsp), %rdx
    252d:      	movq	0x8(%rsp), %rax
    2532:      	cmpq	%rax, %rdx
    2535:      	movq	%rax, %rbx
    2538:      	cmovbq	%rdx, %rbx
    253c:      	testq	%rax, %rax
    253f:      	cmovneq	%rbx, %rdx
    2543:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2548:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    254f:      	ja	0x325d <generic_retuprobe_event+0x325d>
    2555:      	movq	%rdx, %r14
    2558:      	movq	%r15, %rdi
    255b:      	addq	(%rsp), %rdi
    255f:      	movq	%rdi, %r15
    2562:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2568:      	addq	0x20(%rsp), %rdi
    256d:      	movq	0x38(%rsp), %rcx
    2572:      	movl	$0x4, %eax
    2577:      	movq	%rdx, %rsi
    257a:      	movq	0x38(%rsp), %rdx
    257f:      	callq	*%rax
    2581:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2586:      	testl	%eax, %eax
    2588:      	js	0x325d <generic_retuprobe_event+0x325d>
    258e:      	addq	%r14, %r13
    2591:      	cmpq	$0x0, 0x8(%rsp)
    2597:      	je	0x28ad <generic_retuprobe_event+0x28ad>
    259d:      	subq	%rbx, 0x8(%rsp)
    25a2:      	jne	0x28b4 <generic_retuprobe_event+0x28b4>
    25a8:      	jmp	0x24dc <generic_retuprobe_event+0x24dc>
    25ad:      	movzbl	0x7(%rbx), %eax
    25b1:      	leal	0x8(,%rax,4), %eax
    25b8:      	movw	%ax, 0x2(%rbx)
    25bc:      	addw	(%rbx), %ax
    25bf:      	movw	%ax, (%rbx)
    25c2:      	movzbl	0x6(%rbx), %ecx
    25c6:      	cmpq	$0x3c, %rcx
    25ca:      	ja	0x30e5 <generic_retuprobe_event+0x30e5>
    25d0:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    25da:      	btq	%rcx, %rdx
    25de:      	jae	0x30e5 <generic_retuprobe_event+0x30e5>
    25e4:      	movb	%cl, 0x5(%rbx)
    25e7:      	movzwl	%ax, %ecx
    25ea:      	addq	%r14, %rcx
    25ed:      	movl	$0x2, %edx
    25f2:      	movl	$0x4, %eax
    25f7:      	movq	%r12, %rdi
    25fa:      	movzwl	(%rbx), %edx
    25fd:      	addq	%r14, %rdx
    2600:      	movl	$0x2, %esi
    2605:      	callq	*%rax
    2607:      	testq	%rax, %rax
    260a:      	js	0x2b53 <generic_retuprobe_event+0x2b53>
    2610:      	movzbl	0x5(%rbx), %eax
    2614:      	cmpl	$0x32, %eax
    2617:      	jg	0x2633 <generic_retuprobe_event+0x2633>
    2619:      	testl	%eax, %eax
    261b:      	je	0x2650 <generic_retuprobe_event+0x2650>
    261d:      	cmpl	$0x2b, %eax
    2620:      	je	0x2650 <generic_retuprobe_event+0x2650>
    2622:      	cmpl	$0x2c, %eax
    2625:      	jne	0x267b <generic_retuprobe_event+0x267b>
    2627:      	movw	$0x8, 0x2(%rbx)
    262d:      	movw	$0x8, %ax
    2631:      	jmp	0x267f <generic_retuprobe_event+0x267f>
    2633:      	cmpl	$0x33, %eax
    2636:      	je	0x266a <generic_retuprobe_event+0x266a>
    2638:      	cmpl	$0x3c, %eax
    263b:      	je	0x2650 <generic_retuprobe_event+0x2650>
    263d:      	cmpl	$0xff, %eax
    2642:      	jne	0x267b <generic_retuprobe_event+0x267b>
    2644:      	movw	$0x28, 0x2(%rbx)
    264a:      	movw	$0x28, %ax
    264e:      	jmp	0x267f <generic_retuprobe_event+0x267f>
    2650:      	movzbl	0x7(%rbx), %eax
    2654:      	leal	0x8(,%rax,8), %eax
    265b:      	movw	%ax, 0x2(%rbx)
    265f:      	jmp	0x267f <generic_retuprobe_event+0x267f>
    2661:      	movzwl	0x2(%rbx), %eax
    2665:      	jmp	0x25bc <generic_retuprobe_event+0x25bc>
    266a:      	movzbl	0x7(%rbx), %eax
    266e:      	leal	0x8(,%rax,4), %eax
    2675:      	movw	%ax, 0x2(%rbx)
    2679:      	jmp	0x267f <generic_retuprobe_event+0x267f>
    267b:      	movzwl	0x2(%rbx), %eax
    267f:      	addw	(%rbx), %ax
    2682:      	movw	%ax, (%rbx)
    2685:      	movzbl	0x6(%rbx), %ecx
    2689:      	cmpq	$0x3c, %rcx
    268d:      	ja	0x30e5 <generic_retuprobe_event+0x30e5>
    2693:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    269d:      	btq	%rcx, %rdx
    26a1:      	jae	0x30e5 <generic_retuprobe_event+0x30e5>
    26a7:      	movb	%cl, 0x5(%rbx)
    26aa:      	movzwl	%ax, %ecx
    26ad:      	addq	%r14, %rcx
    26b0:      	movl	$0x2, %edx
    26b5:      	movl	$0x4, %eax
    26ba:      	movq	%r12, %rdi
    26bd:      	movzwl	(%rbx), %edx
    26c0:      	addq	%r14, %rdx
    26c3:      	movl	$0x2, %esi
    26c8:      	callq	*%rax
    26ca:      	testq	%rax, %rax
    26cd:      	js	0x2b53 <generic_retuprobe_event+0x2b53>
    26d3:      	movzbl	0x5(%rbx), %eax
    26d7:      	cmpl	$0x32, %eax
    26da:      	jg	0x26f6 <generic_retuprobe_event+0x26f6>
    26dc:      	testl	%eax, %eax
    26de:      	je	0x2713 <generic_retuprobe_event+0x2713>
    26e0:      	cmpl	$0x2b, %eax
    26e3:      	je	0x2713 <generic_retuprobe_event+0x2713>
    26e5:      	cmpl	$0x2c, %eax
    26e8:      	jne	0x2735 <generic_retuprobe_event+0x2735>
    26ea:      	movw	$0x8, 0x2(%rbx)
    26f0:      	movw	$0x8, %ax
    26f4:      	jmp	0x2739 <generic_retuprobe_event+0x2739>
    26f6:      	cmpl	$0x33, %eax
    26f9:      	je	0x2724 <generic_retuprobe_event+0x2724>
    26fb:      	cmpl	$0x3c, %eax
    26fe:      	je	0x2713 <generic_retuprobe_event+0x2713>
    2700:      	cmpl	$0xff, %eax
    2705:      	jne	0x2735 <generic_retuprobe_event+0x2735>
    2707:      	movw	$0x28, 0x2(%rbx)
    270d:      	movw	$0x28, %ax
    2711:      	jmp	0x2739 <generic_retuprobe_event+0x2739>
    2713:      	movzbl	0x7(%rbx), %eax
    2717:      	leal	0x8(,%rax,8), %eax
    271e:      	movw	%ax, 0x2(%rbx)
    2722:      	jmp	0x2739 <generic_retuprobe_event+0x2739>
    2724:      	movzbl	0x7(%rbx), %eax
    2728:      	leal	0x8(,%rax,4), %eax
    272f:      	movw	%ax, 0x2(%rbx)
    2733:      	jmp	0x2739 <generic_retuprobe_event+0x2739>
    2735:      	movzwl	0x2(%rbx), %eax
    2739:      	addw	(%rbx), %ax
    273c:      	movw	%ax, (%rbx)
    273f:      	movzbl	0x6(%rbx), %ecx
    2743:      	cmpq	$0x3c, %rcx
    2747:      	ja	0x30e5 <generic_retuprobe_event+0x30e5>
    274d:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2757:      	btq	%rcx, %rdx
    275b:      	jae	0x30e5 <generic_retuprobe_event+0x30e5>
    2761:      	movb	%cl, 0x5(%rbx)
    2764:      	movzwl	%ax, %ecx
    2767:      	addq	%r14, %rcx
    276a:      	movl	$0x2, %edx
    276f:      	movl	$0x4, %eax
    2774:      	movq	%r12, %rdi
    2777:      	movzwl	(%rbx), %edx
    277a:      	addq	%r14, %rdx
    277d:      	movl	$0x2, %esi
    2782:      	callq	*%rax
    2784:      	testq	%rax, %rax
    2787:      	js	0x2b53 <generic_retuprobe_event+0x2b53>
    278d:      	movzbl	0x5(%rbx), %eax
    2791:      	cmpl	$0x32, %eax
    2794:      	jg	0x27b0 <generic_retuprobe_event+0x27b0>
    2796:      	testl	%eax, %eax
    2798:      	je	0x27cd <generic_retuprobe_event+0x27cd>
    279a:      	cmpl	$0x2b, %eax
    279d:      	je	0x27cd <generic_retuprobe_event+0x27cd>
    279f:      	cmpl	$0x2c, %eax
    27a2:      	jne	0x27ef <generic_retuprobe_event+0x27ef>
    27a4:      	movw	$0x8, 0x2(%rbx)
    27aa:      	movw	$0x8, %ax
    27ae:      	jmp	0x27f3 <generic_retuprobe_event+0x27f3>
    27b0:      	cmpl	$0x33, %eax
    27b3:      	je	0x27de <generic_retuprobe_event+0x27de>
    27b5:      	cmpl	$0x3c, %eax
    27b8:      	je	0x27cd <generic_retuprobe_event+0x27cd>
    27ba:      	cmpl	$0xff, %eax
    27bf:      	jne	0x27ef <generic_retuprobe_event+0x27ef>
    27c1:      	movw	$0x28, 0x2(%rbx)
    27c7:      	movw	$0x28, %ax
    27cb:      	jmp	0x27f3 <generic_retuprobe_event+0x27f3>
    27cd:      	movzbl	0x7(%rbx), %eax
    27d1:      	leal	0x8(,%rax,8), %eax
    27d8:      	movw	%ax, 0x2(%rbx)
    27dc:      	jmp	0x27f3 <generic_retuprobe_event+0x27f3>
    27de:      	movzbl	0x7(%rbx), %eax
    27e2:      	leal	0x8(,%rax,4), %eax
    27e9:      	movw	%ax, 0x2(%rbx)
    27ed:      	jmp	0x27f3 <generic_retuprobe_event+0x27f3>
    27ef:      	movzwl	0x2(%rbx), %eax
    27f3:      	addw	(%rbx), %ax
    27f6:      	movw	%ax, (%rbx)
    27f9:      	movzbl	0x6(%rbx), %ecx
    27fd:      	cmpq	$0x3c, %rcx
    2801:      	ja	0x30e5 <generic_retuprobe_event+0x30e5>
    2807:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2811:      	btq	%rcx, %rdx
    2815:      	jae	0x30e5 <generic_retuprobe_event+0x30e5>
    281b:      	movb	%cl, 0x5(%rbx)
    281e:      	movzwl	%ax, %ecx
    2821:      	addq	%r14, %rcx
    2824:      	movl	$0x2, %edx
    2829:      	movl	$0x4, %eax
    282e:      	movq	%r12, %rdi
    2831:      	movzwl	(%rbx), %edx
    2834:      	addq	%r14, %rdx
    2837:      	movl	$0x2, %esi
    283c:      	callq	*%rax
    283e:      	testq	%rax, %rax
    2841:      	js	0x2b53 <generic_retuprobe_event+0x2b53>
    2847:      	movzbl	0x5(%rbx), %eax
    284b:      	cmpl	$0x32, %eax
    284e:      	jg	0x2871 <generic_retuprobe_event+0x2871>
    2850:      	testl	%eax, %eax
    2852:      	je	0x2899 <generic_retuprobe_event+0x2899>
    2854:      	cmpl	$0x2b, %eax
    2857:      	je	0x2899 <generic_retuprobe_event+0x2899>
    2859:      	cmpl	$0x2c, %eax
    285c:      	jne	0x2990 <generic_retuprobe_event+0x2990>
    2862:      	movw	$0x8, 0x2(%rbx)
    2868:      	movw	$0x8, %ax
    286c:      	jmp	0x2994 <generic_retuprobe_event+0x2994>
    2871:      	cmpl	$0x33, %eax
    2874:      	je	0x297f <generic_retuprobe_event+0x297f>
    287a:      	cmpl	$0x3c, %eax
    287d:      	je	0x2899 <generic_retuprobe_event+0x2899>
    287f:      	cmpl	$0xff, %eax
    2884:      	jne	0x2990 <generic_retuprobe_event+0x2990>
    288a:      	movw	$0x28, 0x2(%rbx)
    2890:      	movw	$0x28, %ax
    2894:      	jmp	0x2994 <generic_retuprobe_event+0x2994>
    2899:      	movzbl	0x7(%rbx), %eax
    289d:      	leal	0x8(,%rax,8), %eax
    28a4:      	movw	%ax, 0x2(%rbx)
    28a8:      	jmp	0x2994 <generic_retuprobe_event+0x2994>
    28ad:      	xorl	%eax, %eax
    28af:      	movq	%rax, 0x8(%rsp)
    28b4:      	cmpq	$0x5, 0xb8(%rsp)
    28bd:      	jb	0x24dc <generic_retuprobe_event+0x24dc>
    28c3:      	movq	0x88(%rsp), %rax
    28cb:      	leaq	0x40(%rax), %rdx
    28cf:      	leaq	0x38(%rsp), %rdi
    28d4:      	movl	$0x4, %r12d
    28da:      	movl	$0x10, %ecx
    28df:      	movl	$0x4, %eax
    28e4:      	movl	$0x10, %esi
    28e9:      	callq	*%rax
    28eb:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    28f0:      	testl	%eax, %eax
    28f2:      	js	0x325d <generic_retuprobe_event+0x325d>
    28f8:      	movq	0x40(%rsp), %rdx
    28fd:      	movq	0x8(%rsp), %rax
    2902:      	cmpq	%rax, %rdx
    2905:      	movq	%rax, %rbx
    2908:      	cmovbq	%rdx, %rbx
    290c:      	testq	%rax, %rax
    290f:      	cmovneq	%rbx, %rdx
    2913:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    2918:      	movq	%rdx, (%rsp)
    291c:      	cmpq	$0xffe, %rdx            # imm = 0xFFE
    2923:      	ja	0x325d <generic_retuprobe_event+0x325d>
    2929:      	movq	%r14, %rdi
    292c:      	addq	%r15, %rdi
    292f:      	movq	%rdi, %r14
    2932:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    2938:      	addq	0x20(%rsp), %rdi
    293d:      	movq	0x38(%rsp), %rcx
    2942:      	movl	$0x4, %eax
    2947:      	movq	(%rsp), %rsi
    294b:      	movq	0x38(%rsp), %rdx
    2950:      	callq	*%rax
    2952:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2957:      	testl	%eax, %eax
    2959:      	js	0x325d <generic_retuprobe_event+0x325d>
    295f:      	addq	(%rsp), %r13
    2963:      	cmpq	$0x0, 0x8(%rsp)
    2969:      	je	0x30f2 <generic_retuprobe_event+0x30f2>
    296f:      	subq	%rbx, 0x8(%rsp)
    2974:      	jne	0x30f9 <generic_retuprobe_event+0x30f9>
    297a:      	jmp	0x24dc <generic_retuprobe_event+0x24dc>
    297f:      	movzbl	0x7(%rbx), %eax
    2983:      	leal	0x8(,%rax,4), %eax
    298a:      	movw	%ax, 0x2(%rbx)
    298e:      	jmp	0x2994 <generic_retuprobe_event+0x2994>
    2990:      	movzwl	0x2(%rbx), %eax
    2994:      	addw	(%rbx), %ax
    2997:      	movw	%ax, (%rbx)
    299a:      	movzbl	0x6(%rbx), %ecx
    299e:      	cmpq	$0x3c, %rcx
    29a2:      	ja	0x30e5 <generic_retuprobe_event+0x30e5>
    29a8:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    29b2:      	btq	%rcx, %rdx
    29b6:      	jae	0x30e5 <generic_retuprobe_event+0x30e5>
    29bc:      	movb	%cl, 0x5(%rbx)
    29bf:      	movzwl	%ax, %ecx
    29c2:      	addq	%r14, %rcx
    29c5:      	movl	$0x2, %edx
    29ca:      	movl	$0x4, %eax
    29cf:      	movq	%r12, %rdi
    29d2:      	movzwl	(%rbx), %edx
    29d5:      	addq	%r14, %rdx
    29d8:      	movl	$0x2, %esi
    29dd:      	callq	*%rax
    29df:      	testq	%rax, %rax
    29e2:      	js	0x2b53 <generic_retuprobe_event+0x2b53>
    29e8:      	movzbl	0x5(%rbx), %eax
    29ec:      	cmpl	$0x32, %eax
    29ef:      	jg	0x2a0b <generic_retuprobe_event+0x2a0b>
    29f1:      	testl	%eax, %eax
    29f3:      	je	0x2a28 <generic_retuprobe_event+0x2a28>
    29f5:      	cmpl	$0x2b, %eax
    29f8:      	je	0x2a28 <generic_retuprobe_event+0x2a28>
    29fa:      	cmpl	$0x2c, %eax
    29fd:      	jne	0x2a4a <generic_retuprobe_event+0x2a4a>
    29ff:      	movw	$0x8, 0x2(%rbx)
    2a05:      	movw	$0x8, %ax
    2a09:      	jmp	0x2a4e <generic_retuprobe_event+0x2a4e>
    2a0b:      	cmpl	$0x33, %eax
    2a0e:      	je	0x2a39 <generic_retuprobe_event+0x2a39>
    2a10:      	cmpl	$0x3c, %eax
    2a13:      	je	0x2a28 <generic_retuprobe_event+0x2a28>
    2a15:      	cmpl	$0xff, %eax
    2a1a:      	jne	0x2a4a <generic_retuprobe_event+0x2a4a>
    2a1c:      	movw	$0x28, 0x2(%rbx)
    2a22:      	movw	$0x28, %ax
    2a26:      	jmp	0x2a4e <generic_retuprobe_event+0x2a4e>
    2a28:      	movzbl	0x7(%rbx), %eax
    2a2c:      	leal	0x8(,%rax,8), %eax
    2a33:      	movw	%ax, 0x2(%rbx)
    2a37:      	jmp	0x2a4e <generic_retuprobe_event+0x2a4e>
    2a39:      	movzbl	0x7(%rbx), %eax
    2a3d:      	leal	0x8(,%rax,4), %eax
    2a44:      	movw	%ax, 0x2(%rbx)
    2a48:      	jmp	0x2a4e <generic_retuprobe_event+0x2a4e>
    2a4a:      	movzwl	0x2(%rbx), %eax
    2a4e:      	addw	(%rbx), %ax
    2a51:      	movw	%ax, (%rbx)
    2a54:      	movzbl	0x6(%rbx), %ecx
    2a58:      	cmpq	$0x3c, %rcx
    2a5c:      	ja	0x30e5 <generic_retuprobe_event+0x30e5>
    2a62:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2a6c:      	btq	%rcx, %rdx
    2a70:      	jae	0x30e5 <generic_retuprobe_event+0x30e5>
    2a76:      	movb	%cl, 0x5(%rbx)
    2a79:      	movzwl	%ax, %ecx
    2a7c:      	addq	%r14, %rcx
    2a7f:      	movl	$0x2, %edx
    2a84:      	movl	$0x4, %eax
    2a89:      	movq	%r12, %rdi
    2a8c:      	movzwl	(%rbx), %edx
    2a8f:      	addq	%r14, %rdx
    2a92:      	movl	$0x2, %esi
    2a97:      	callq	*%rax
    2a99:      	testq	%rax, %rax
    2a9c:      	js	0x2b53 <generic_retuprobe_event+0x2b53>
    2aa2:      	movzbl	0x5(%rbx), %eax
    2aa6:      	cmpl	$0x32, %eax
    2aa9:      	jg	0x2ac5 <generic_retuprobe_event+0x2ac5>
    2aab:      	testl	%eax, %eax
    2aad:      	je	0x2ae2 <generic_retuprobe_event+0x2ae2>
    2aaf:      	cmpl	$0x2b, %eax
    2ab2:      	je	0x2ae2 <generic_retuprobe_event+0x2ae2>
    2ab4:      	cmpl	$0x2c, %eax
    2ab7:      	jne	0x2b04 <generic_retuprobe_event+0x2b04>
    2ab9:      	movw	$0x8, 0x2(%rbx)
    2abf:      	movw	$0x8, %ax
    2ac3:      	jmp	0x2b08 <generic_retuprobe_event+0x2b08>
    2ac5:      	cmpl	$0x33, %eax
    2ac8:      	je	0x2af3 <generic_retuprobe_event+0x2af3>
    2aca:      	cmpl	$0x3c, %eax
    2acd:      	je	0x2ae2 <generic_retuprobe_event+0x2ae2>
    2acf:      	cmpl	$0xff, %eax
    2ad4:      	jne	0x2b04 <generic_retuprobe_event+0x2b04>
    2ad6:      	movw	$0x28, 0x2(%rbx)
    2adc:      	movw	$0x28, %ax
    2ae0:      	jmp	0x2b08 <generic_retuprobe_event+0x2b08>
    2ae2:      	movzbl	0x7(%rbx), %eax
    2ae6:      	leal	0x8(,%rax,8), %eax
    2aed:      	movw	%ax, 0x2(%rbx)
    2af1:      	jmp	0x2b08 <generic_retuprobe_event+0x2b08>
    2af3:      	movzbl	0x7(%rbx), %eax
    2af7:      	leal	0x8(,%rax,4), %eax
    2afe:      	movw	%ax, 0x2(%rbx)
    2b02:      	jmp	0x2b08 <generic_retuprobe_event+0x2b08>
    2b04:      	movzwl	0x2(%rbx), %eax
    2b08:      	addw	(%rbx), %ax
    2b0b:      	movw	%ax, (%rbx)
    2b0e:      	movzbl	0x6(%rbx), %ecx
    2b12:      	cmpq	$0x3c, %rcx
    2b16:      	ja	0x30e5 <generic_retuprobe_event+0x30e5>
    2b1c:      	movabsq	$0x1008180000000001, %rdx # imm = 0x1008180000000001
    2b26:      	btq	%rcx, %rdx
    2b2a:      	jae	0x30e5 <generic_retuprobe_event+0x30e5>
    2b30:      	movb	%cl, 0x5(%rbx)
    2b33:      	movzwl	%ax, %ecx
    2b36:      	addq	%r14, %rcx
    2b39:      	movl	$0x2, %edx
    2b3e:      	movl	$0x4, %eax
    2b43:      	movzwl	(%rbx), %edx
    2b46:      	addq	%r14, %rdx
    2b49:      	movq	%r12, %rdi
    2b4c:      	movl	$0x2, %esi
    2b51:      	callq	*%rax
    2b53:      	xorl	%ecx, %ecx
    2b55:      	movb	%cl, 0xd0(%rsp)
    2b5c:      	movzbl	%cl, %eax
    2b5f:      	movq	(%rsp), %rbx
    2b63:      	movw	%ax, 0xc0(%rbx)
    2b6a:      	movw	$0xa, 0xc2(%rbx)
    2b73:      	leaq	0x8(%r13), %rdx
    2b77:      	movl	$0x10, %ecx
    2b7c:      	movl	$0x4, %eax
    2b81:      	movq	0x30(%rsp), %rdi
    2b86:      	movl	$0x10, %esi
    2b8b:      	callq	*%rax
    2b8d:      	leaq	0xac(%rbx), %rdi
    2b94:      	addq	$0x18, %r13
    2b98:      	movl	$0x10, %ecx
    2b9d:      	movl	$0x4, %eax
    2ba2:      	movl	$0x10, %esi
    2ba7:      	movq	%r13, %rdx
    2baa:      	callq	*%rax
    2bac:      	movzbl	0xd0(%rsp), %eax
    2bb4:      	cmpl	$0x11, %eax
    2bb7:      	je	0x2c0b <generic_retuprobe_event+0x2c0b>
    2bb9:      	cmpl	$0x6, %eax
    2bbc:      	jne	0x2c5b <generic_retuprobe_event+0x2c5b>
    2bc2:      	movq	0x38(%rsp), %r14
    2bc7:      	movzwl	0xd8(%rsp), %r12d
    2bd0:      	leaq	(%r14,%r12), %rdx
    2bd4:      	movq	(%rsp), %r13
    2bd8:      	leaq	0xbc(%r13), %rdi
    2bdf:      	movl	$0x2, %ecx
    2be4:      	movl	$0x4, %eax
    2be9:      	movl	$0x2, %esi
    2bee:      	callq	*%rax
    2bf0:      	leaq	0xbe(%r13), %rdi
    2bf7:      	leaq	(%r14,%r12), %rdx
    2bfb:      	addq	$0x2, %rdx
    2bff:      	movl	$0x2, %ecx
    2c04:      	movl	$0x4, %eax
    2c09:      	jmp	0x2c52 <generic_retuprobe_event+0x2c52>
    2c0b:      	movq	0x38(%rsp), %r14
    2c10:      	movzwl	0xd8(%rsp), %r12d
    2c19:      	leaq	(%r14,%r12), %rdx
    2c1d:      	movq	(%rsp), %r13
    2c21:      	leaq	0xbc(%r13), %rdi
    2c28:      	movl	$0x2, %ecx
    2c2d:      	movl	$0x4, %eax
    2c32:      	movl	$0x2, %esi
    2c37:      	callq	*%rax
    2c39:      	leaq	0xbe(%r13), %rdi
    2c40:      	leaq	(%r14,%r12), %rdx
    2c44:      	addq	$0x2, %rdx
    2c48:      	movl	$0x2, %ecx
    2c4d:      	movl	$0x4, %eax
    2c52:      	movl	$0x2, %esi
    2c57:      	callq	*%rax
    2c59:      	jmp	0x2c6a <generic_retuprobe_event+0x2c6a>
    2c5b:      	movq	(%rsp), %r13
    2c5f:      	movl	$0x0, 0xbc(%r13)
    2c6a:      	movzwl	0xbc(%r13), %eax
    2c72:      	movzwl	0xbe(%r13), %ecx
    2c7a:      	movbew	%ax, 0xbc(%r13)
    2c84:      	movbew	%cx, 0xbe(%r13)
    2c8e:      	movq	0x90(%rsp), %rdx
    2c96:      	addq	$0xe0, %rdx
    2c9d:      	leaq	0x78(%rsp), %rdi
    2ca2:      	movl	$0x8, %ecx
    2ca7:      	movl	$0x4, %eax
    2cac:      	movl	$0x4, %ebx
    2cb1:      	movl	$0x8, %esi
    2cb6:      	callq	*%rax
    2cb8:      	movq	0x78(%rsp), %rcx
    2cbd:      	testq	%rcx, %rcx
    2cc0:      	je	0x2d32 <generic_retuprobe_event+0x2d32>
    2cc2:      	addq	$0x5, %rcx
    2cc6:      	leaq	0xa8(%rsp), %rdi
    2cce:      	movl	$0x8, %edx
    2cd3:      	movl	$0x4, %eax
    2cd8:      	movq	0x78(%rsp), %rdx
    2cdd:      	addq	$0x5, %rdx
    2ce1:      	movl	$0x8, %esi
    2ce6:      	callq	*%rax
    2ce8:      	movq	0x78(%rsp), %r12
    2ced:      	movq	0xa8(%rsp), %r13
    2cf5:      	movq	(%rsp), %r14
    2cf9:      	leaq	0xd4(%r14), %rdi
    2d00:      	leaq	(%r12,%r13,8), %rdx
    2d04:      	addq	$0x44, %rdx
    2d08:      	movl	$0x4, %eax
    2d0d:      	movl	$0x4, %esi
    2d12:      	callq	*%rax
    2d14:      	addq	$0xd8, %r14
    2d1b:      	leaq	(%r12,%r13,8), %rdx
    2d1f:      	addq	$0x45, %rdx
    2d23:      	movl	$0x4, %eax
    2d28:      	movq	%r14, %rdi
    2d2b:      	movl	$0x4, %esi
    2d30:      	callq	*%rax
    2d32:      	movq	0x18(%rsp), %rbx
    2d37:      	movq	0x20(%rsp), %r15
    2d3c:      	movl	$0x40, %r13d
    2d42:      	movq	(%rsp), %rcx
    2d46:      	movq	%rbp, %r12
    2d49:      	movq	0x8(%rsp), %r8
    2d4e:      	movq	0x88(%rsp), %rbp
    2d56:      	testl	%r13d, %r13d
    2d59:      	movl	0x28(%rsp), %eax
    2d5d:      	js	0x2d77 <generic_retuprobe_event+0x2d77>
    2d5f:      	andl	$0x7fffffff, %r13d      # imm = 0x7FFFFFFF
    2d66:      	addq	$0x4, %r13
    2d6a:      	movq	%r13, %r14
    2d6d:      	movq	0xc8(%rsp), %r13
    2d75:      	jmp	0x2d99 <generic_retuprobe_event+0x2d99>
    2d77:      	movl	$0xffffffff, 0x5ea0(%rcx) # imm = 0xFFFFFFFF
    2d81:      	movl	$0xffffffff, 0x98(%rcx) # imm = 0xFFFFFFFF
    2d8b:      	movq	0xc8(%rsp), %r13
    2d93:      	movl	$0x4, %r14d
    2d99:      	addl	$0x8, %r14d
    2d9d:      	andl	$0x1fff, %r14d          # imm = 0x1FFF
    2da4:      	addq	$0x90, %r15
    2dab:      	cmpl	$0x3, %eax
    2dae:      	je	0x1b4 <generic_retuprobe_event+0x1b4>
    2db4:      	cmpl	$0x2, %eax
    2db7:      	jne	0x2e35 <generic_retuprobe_event+0x2e35>
    2db9:      	movq	%rbx, 0x18(%rsp)
    2dbe:      	movq	%rbp, %rdx
    2dc1:      	movq	%r12, 0x98(%rsp)
    2dc9:      	movq	%r14, %rcx
    2dcc:      	movl	$0x0, (%r15,%r14)
    2dd4:      	cmpq	$0xfff, %r8             # imm = 0xFFF
    2ddb:      	movq	%r8, %rbx
    2dde:      	movl	$0xfff, %r14d           # imm = 0xFFF
    2de4:      	cmovbq	%r8, %r14
    2de8:      	leaq	(%r15,%rcx), %rdi
    2dec:      	addq	$0xc, %rdi
    2df0:      	movl	$0x4, %eax
    2df5:      	leaq	0x4(%rcx), %r12
    2df9:      	addq	%rcx, %r15
    2dfc:      	addq	$0x4, %r15
    2e00:      	movl	$0x4, %ebp
    2e05:      	movl	%r14d, %esi
    2e08:      	callq	*%rax
    2e0a:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    2e0f:      	testl	%eax, %eax
    2e11:      	js	0x2e20 <generic_retuprobe_event+0x2e20>
    2e13:      	movl	%r14d, 0x4(%r15)
    2e17:      	addq	$0x8, %r14
    2e1b:      	movl	%ebx, %ecx
    2e1d:      	movq	%r14, %rbp
    2e20:      	addq	%r12, %rbp
    2e23:      	movl	%ecx, (%r15)
    2e26:      	movq	0x98(%rsp), %r12
    2e2e:      	movq	0x18(%rsp), %rbx
    2e33:      	jmp	0x2e38 <generic_retuprobe_event+0x2e38>
    2e35:      	movq	%r14, %rbp
    2e38:      	movl	$0x23, %eax
    2e3d:      	callq	*%rax
    2e3f:      	movq	%rax, %rcx
    2e42:      	movq	%rax, 0x38(%rsp)
    2e47:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    2e4e:      	leaq	0xa8(%rsp), %rdi
    2e56:      	movl	$0x4, %edx
    2e5b:      	movl	$0x71, %eax
    2e60:      	movl	$0xaf4, %edx            # imm = 0xAF4
    2e65:      	addq	0x38(%rsp), %rdx
    2e6a:      	movl	$0x4, %esi
    2e6f:      	callq	*%rax
    2e71:      	movl	0xa8(%rsp), %eax
    2e78:      	movl	%eax, 0x78(%rsp)
    2e7c:      	movq	(%rip), %rdi            # 0x2e83 <generic_retuprobe_event+0x2e83>
    2e83:      	leaq	0x78(%rsp), %rsi
    2e88:      	movl	$0x1, %eax
    2e8d:      	callq	*%rax
    2e8f:      	testq	%rax, %rax
    2e92:      	je	0x2ea2 <generic_retuprobe_event+0x2ea2>
    2e94:      	movq	%rax, %r15
    2e97:      	cmpq	$0x0, 0x8(%rax)
    2e9c:      	jne	0x3078 <generic_retuprobe_event+0x3078>
    2ea2:      	movl	$0xb00, %edx            # imm = 0xB00
    2ea7:      	movq	0x38(%rsp), %rcx
    2eac:      	addq	%rdx, %rcx
    2eaf:      	leaq	0x38(%rsp), %rdi
    2eb4:      	movl	$0x8, %esi
    2eb9:      	movl	$0x71, %eax
    2ebe:      	addq	0x38(%rsp), %rdx
    2ec3:      	movl	$0x8, %esi
    2ec8:      	callq	*%rax
    2eca:      	movq	0x38(%rsp), %rcx
    2ecf:      	testq	%rcx, %rcx
    2ed2:      	je	0x3075 <generic_retuprobe_event+0x3075>
    2ed8:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    2edf:      	leaq	0xa8(%rsp), %rdi
    2ee7:      	movl	$0x4, %edx
    2eec:      	movl	$0x71, %eax
    2ef1:      	movl	$0xaf4, %edx            # imm = 0xAF4
    2ef6:      	addq	0x38(%rsp), %rdx
    2efb:      	movl	$0x4, %esi
    2f00:      	callq	*%rax
    2f02:      	movl	0xa8(%rsp), %eax
    2f09:      	movl	%eax, 0x78(%rsp)
    2f0d:      	movq	(%rip), %rdi            # 0x2f14 <generic_retuprobe_event+0x2f14>
    2f14:      	leaq	0x78(%rsp), %rsi
    2f19:      	movl	$0x1, %eax
    2f1e:      	callq	*%rax
    2f20:      	testq	%rax, %rax
    2f23:      	je	0x2f33 <generic_retuprobe_event+0x2f33>
    2f25:      	movq	%rax, %r15
    2f28:      	cmpq	$0x0, 0x8(%rax)
    2f2d:      	jne	0x3078 <generic_retuprobe_event+0x3078>
    2f33:      	movl	$0xb00, %edx            # imm = 0xB00
    2f38:      	movq	0x38(%rsp), %rcx
    2f3d:      	addq	%rdx, %rcx
    2f40:      	leaq	0x38(%rsp), %rdi
    2f45:      	movl	$0x8, %esi
    2f4a:      	movl	$0x71, %eax
    2f4f:      	addq	0x38(%rsp), %rdx
    2f54:      	movl	$0x8, %esi
    2f59:      	callq	*%rax
    2f5b:      	movq	0x38(%rsp), %rcx
    2f60:      	testq	%rcx, %rcx
    2f63:      	je	0x3075 <generic_retuprobe_event+0x3075>
    2f69:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    2f70:      	leaq	0xa8(%rsp), %rdi
    2f78:      	movl	$0x4, %edx
    2f7d:      	movl	$0x71, %eax
    2f82:      	movl	$0xaf4, %edx            # imm = 0xAF4
    2f87:      	addq	0x38(%rsp), %rdx
    2f8c:      	movl	$0x4, %esi
    2f91:      	callq	*%rax
    2f93:      	movl	0xa8(%rsp), %eax
    2f9a:      	movl	%eax, 0x78(%rsp)
    2f9e:      	movq	(%rip), %rdi            # 0x2fa5 <generic_retuprobe_event+0x2fa5>
    2fa5:      	leaq	0x78(%rsp), %rsi
    2faa:      	movl	$0x1, %eax
    2faf:      	callq	*%rax
    2fb1:      	testq	%rax, %rax
    2fb4:      	je	0x2fc4 <generic_retuprobe_event+0x2fc4>
    2fb6:      	movq	%rax, %r15
    2fb9:      	cmpq	$0x0, 0x8(%rax)
    2fbe:      	jne	0x3078 <generic_retuprobe_event+0x3078>
    2fc4:      	movl	$0xb00, %edx            # imm = 0xB00
    2fc9:      	movq	0x38(%rsp), %rcx
    2fce:      	addq	%rdx, %rcx
    2fd1:      	leaq	0x38(%rsp), %rdi
    2fd6:      	movl	$0x8, %esi
    2fdb:      	movl	$0x71, %eax
    2fe0:      	addq	0x38(%rsp), %rdx
    2fe5:      	movl	$0x8, %esi
    2fea:      	callq	*%rax
    2fec:      	movq	0x38(%rsp), %rcx
    2ff1:      	testq	%rcx, %rcx
    2ff4:      	je	0x3075 <generic_retuprobe_event+0x3075>
    2ff6:      	addq	$0xaf4, %rcx            # imm = 0xAF4
    2ffd:      	leaq	0xa8(%rsp), %rdi
    3005:      	movl	$0x4, %edx
    300a:      	movl	$0x71, %eax
    300f:      	movl	$0xaf4, %edx            # imm = 0xAF4
    3014:      	addq	0x38(%rsp), %rdx
    3019:      	movl	$0x4, %esi
    301e:      	callq	*%rax
    3020:      	movl	0xa8(%rsp), %eax
    3027:      	movl	%eax, 0x78(%rsp)
    302b:      	movq	(%rip), %rdi            # 0x3032 <generic_retuprobe_event+0x3032>
    3032:      	leaq	0x78(%rsp), %rsi
    3037:      	movl	$0x1, %eax
    303c:      	callq	*%rax
    303e:      	testq	%rax, %rax
    3041:      	je	0x304d <generic_retuprobe_event+0x304d>
    3043:      	movq	%rax, %r15
    3046:      	cmpq	$0x0, 0x8(%rax)
    304b:      	jne	0x3078 <generic_retuprobe_event+0x3078>
    304d:      	movl	$0xb00, %edx            # imm = 0xB00
    3052:      	movq	0x38(%rsp), %rcx
    3057:      	addq	%rdx, %rcx
    305a:      	leaq	0x38(%rsp), %rdi
    305f:      	movl	$0x8, %esi
    3064:      	movl	$0x71, %eax
    3069:      	addq	0x38(%rsp), %rdx
    306e:      	movl	$0x8, %esi
    3073:      	callq	*%rax
    3075:      	xorl	%r15d, %r15d
    3078:      	movl	$0x10f, (%rbx)          # imm = 0x10F
    307e:      	movl	%ebp, 0x4(%rbx)
    3081:      	movl	$0x7d, %eax
    3086:      	callq	*%rax
    3088:      	movq	%rax, 0x8(%rbx)
    308c:      	testq	%r15, %r15
    308f:      	je	0x309f <generic_retuprobe_event+0x309f>
    3091:      	movl	(%r15), %eax
    3094:      	movl	%eax, 0x10(%rbx)
    3097:      	movq	0x8(%r15), %rax
    309b:      	movq	%rax, 0x18(%rbx)
    309f:      	movl	$0x0, 0x14(%rbx)
    30a6:      	movl	(%r12), %eax
    30aa:      	movq	%rax, 0x60(%rbx)
    30ae:      	movl	%ebp, 0x4(%rbx)
    30b1:      	movq	(%rip), %rsi            # 0x30b8 <generic_retuprobe_event+0x30b8>
    30b8:      	movl	$0x3, %ecx
    30bd:      	movl	$0xc, %eax
    30c2:      	movq	%r13, %rdi
    30c5:      	movl	$0x3, %edx
    30ca:      	callq	*%rax
    30cc:      	movl	$0x1, %ebp
    30d1:      	movl	%ebp, %eax
    30d3:      	addq	$0xf8, %rsp
    30da:      	popq	%rbx
    30db:      	popq	%r12
    30dd:      	popq	%r13
    30df:      	popq	%r14
    30e1:      	popq	%r15
    30e3:      	popq	%rbp
    30e4:      	retq
    30e5:      	movw	%ax, 0xd8(%rsp)
    30ed:      	jmp	0x2b55 <generic_retuprobe_event+0x2b55>
    30f2:      	xorl	%eax, %eax
    30f4:      	movq	%rax, 0x8(%rsp)
    30f9:      	cmpq	$0x5, 0xb8(%rsp)
    3102:      	je	0x24dc <generic_retuprobe_event+0x24dc>
    3108:      	movq	0x88(%rsp), %rax
    3110:      	leaq	0x50(%rax), %rdx
    3114:      	leaq	0x38(%rsp), %rdi
    3119:      	movl	$0x4, %r12d
    311f:      	movl	$0x10, %ecx
    3124:      	movl	$0x4, %eax
    3129:      	movl	$0x10, %esi
    312e:      	callq	*%rax
    3130:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3135:      	testl	%eax, %eax
    3137:      	js	0x325d <generic_retuprobe_event+0x325d>
    313d:      	movq	0x40(%rsp), %r15
    3142:      	movq	0x8(%rsp), %rax
    3147:      	cmpq	%rax, %r15
    314a:      	movq	%rax, %rbx
    314d:      	cmovbq	%r15, %rbx
    3151:      	testq	%rax, %rax
    3154:      	cmovneq	%rbx, %r15
    3158:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    315d:      	cmpq	$0xffe, %r15            # imm = 0xFFE
    3164:      	ja	0x325d <generic_retuprobe_event+0x325d>
    316a:      	movq	(%rsp), %rdi
    316e:      	addq	%r14, %rdi
    3171:      	movq	%rdi, %r14
    3174:      	andl	$0x3fff, %edi           # imm = 0x3FFF
    317a:      	addq	0x20(%rsp), %rdi
    317f:      	movq	0x38(%rsp), %rcx
    3184:      	movl	$0x4, %eax
    3189:      	movq	0x38(%rsp), %rdx
    318e:      	movl	%r15d, %esi
    3191:      	callq	*%rax
    3193:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3198:      	testl	%eax, %eax
    319a:      	js	0x325d <generic_retuprobe_event+0x325d>
    31a0:      	addq	%r15, %r13
    31a3:      	cmpq	$0x0, 0x8(%rsp)
    31a9:      	je	0x31b7 <generic_retuprobe_event+0x31b7>
    31ab:      	subq	%rbx, 0x8(%rsp)
    31b0:      	jne	0x31be <generic_retuprobe_event+0x31be>
    31b2:      	jmp	0x24dc <generic_retuprobe_event+0x24dc>
    31b7:      	xorl	%eax, %eax
    31b9:      	movq	%rax, 0x8(%rsp)
    31be:      	cmpq	$0x7, 0xb8(%rsp)
    31c7:      	jb	0x24dc <generic_retuprobe_event+0x24dc>
    31cd:      	movq	0x88(%rsp), %rdx
    31d5:      	addq	$0x60, %rdx
    31d9:      	leaq	0x38(%rsp), %rdi
    31de:      	movl	$0x4, %r12d
    31e4:      	movl	$0x10, %ecx
    31e9:      	movl	$0x4, %eax
    31ee:      	movl	$0x10, %esi
    31f3:      	callq	*%rax
    31f5:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    31fa:      	testl	%eax, %eax
    31fc:      	js	0x325d <generic_retuprobe_event+0x325d>
    31fe:      	movq	0x40(%rsp), %rax
    3203:      	movq	0x8(%rsp), %rcx
    3208:      	cmpq	%rcx, %rax
    320b:      	movq	%rcx, %rbp
    320e:      	cmovbq	%rax, %rbp
    3212:      	testq	%rcx, %rcx
    3215:      	cmoveq	%rax, %rbp
    3219:      	movl	$0xfffffffd, %ecx       # imm = 0xFFFFFFFD
    321e:      	cmpq	$0xffe, %rbp            # imm = 0xFFE
    3225:      	ja	0x325d <generic_retuprobe_event+0x325d>
    3227:      	addq	%r14, %r15
    322a:      	andl	$0x3fff, %r15d          # imm = 0x3FFF
    3231:      	addq	0x20(%rsp), %r15
    3236:      	movq	0x38(%rsp), %rcx
    323b:      	movl	$0x4, %eax
    3240:      	movq	0x38(%rsp), %rdx
    3245:      	movq	%r15, %rdi
    3248:      	movl	%ebp, %esi
    324a:      	callq	*%rax
    324c:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3251:      	testl	%eax, %eax
    3253:      	js	0x325d <generic_retuprobe_event+0x325d>
    3255:      	addq	%r13, %rbp
    3258:      	jmp	0x24df <generic_retuprobe_event+0x24df>
    325d:      	movq	0x28(%rsp), %rax
    3262:      	movq	0x20(%rsp), %rdx
    3267:      	movl	%ecx, (%rdx,%rax)
    326a:      	movq	0x18(%rsp), %rbx
    326f:      	jmp	0xbcc <generic_retuprobe_event+0xbcc>
