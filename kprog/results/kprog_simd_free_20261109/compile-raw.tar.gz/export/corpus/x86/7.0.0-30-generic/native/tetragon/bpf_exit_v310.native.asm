
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_exit_v310.native.o:	file format elf64-x86-64

Disassembly of section kprobe/acct_process:

0000000000000000 <event_exit_acct_process>:
       0:      	pushq	%r15
       2:      	pushq	%r14
       4:      	pushq	%r13
       6:      	pushq	%r12
       8:      	pushq	%rbx
       9:      	subq	$0x10, %rsp
       d:      	movq	%rdi, %r15
      10:      	movl	$0xe, %eax
      15:      	callq	*%rax
      17:      	movq	%rax, %r14
      1a:      	shrq	$0x20, %r14
      1e:      	movl	%r14d, 0x8(%rsp)
      23:      	movq	(%rip), %rdi            # 0x2a <event_exit_acct_process+0x2a>
      2a:      	leaq	0x8(%rsp), %rsi
      2f:      	movl	$0x1, %eax
      34:      	callq	*%rax
      36:      	testq	%rax, %rax
      39:      	je	0x1fe <event_exit_acct_process+0x1fe>
      3f:      	movq	%rax, %rbx
      42:      	cmpq	$0x0, 0x8(%rax)
      47:      	je	0x189 <event_exit_acct_process+0x189>
      4d:      	movl	$0x23, %eax
      52:      	callq	*%rax
      54:      	movq	%rax, %r12
      57:      	movl	$0x0, 0xc(%rsp)
      5f:      	movq	(%rip), %rdi            # 0x66 <event_exit_acct_process+0x66>
      66:      	leaq	0xc(%rsp), %rsi
      6b:      	movl	$0x1, %eax
      70:      	callq	*%rax
      72:      	testq	%rax, %rax
      75:      	je	0x1fe <event_exit_acct_process+0x1fe>
      7b:      	movabsq	$0x2800000007, %rcx     # imm = 0x2800000007
      85:      	movq	%rcx, (%rax)
      88:      	movq	%rax, %r13
      8b:      	movl	$0x5, %eax
      90:      	callq	*%rax
      92:      	movq	%rax, 0x8(%r13)
      96:      	movl	%r14d, 0x10(%r13)
      9a:      	movl	$0x0, 0x14(%r13)
      a2:      	movq	0x8(%rbx), %rax
      a6:      	movq	%rax, 0x18(%r13)
      aa:      	movq	%r13, %rdi
      ad:      	addq	$0x20, %rdi
      b1:      	movl	%r14d, 0x24(%r13)
      b5:      	addq	$0xa8c, %r12            # imm = 0xA8C
      bc:      	movl	$0x4, %ecx
      c1:      	movl	$0x4, %eax
      c6:      	movl	$0x4, %esi
      cb:      	movq	%r12, %rdx
      ce:      	callq	*%rax
      d0:      	movq	(%rip), %rsi            # 0xd7 <event_exit_acct_process+0xd7>
      d7:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
      dc:      	movl	$0x28, %edx
      e1:      	movl	$0x19, %eax
      e6:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
      eb:      	movl	$0x28, %r8d
      f1:      	movq	%r15, %rdi
      f4:      	movq	%r13, %rcx
      f7:      	callq	*%rax
      f9:      	testq	%rax, %rax
      fc:      	jns	0x189 <event_exit_acct_process+0x189>
     102:      	movq	%rax, %r15
     105:      	movl	$0x0, 0x8(%rsp)
     10d:      	movq	(%rip), %rdi            # 0x114 <event_exit_acct_process+0x114>
     114:      	leaq	0x8(%rsp), %rsi
     119:      	movl	$0x1, %eax
     11e:      	callq	*%rax
     120:      	testq	%rax, %rax
     123:      	je	0x189 <event_exit_acct_process+0x189>
     125:      	cmpq	$-0xc, %r15
     129:      	jg	0x145 <event_exit_acct_process+0x145>
     12b:      	cmpq	$-0x1c, %r15
     12f:      	je	0x15f <event_exit_acct_process+0x15f>
     131:      	cmpq	$-0x16, %r15
     135:      	je	0x177 <event_exit_acct_process+0x177>
     137:      	cmpq	$-0x10, %r15
     13b:      	jne	0x16f <event_exit_acct_process+0x16f>
     13d:      	addq	$0x1a0, %rax            # imm = 0x1A0
     143:      	jmp	0x185 <event_exit_acct_process+0x185>
     145:      	cmpq	$-0xb, %r15
     149:      	je	0x167 <event_exit_acct_process+0x167>
     14b:      	cmpq	$-0x7, %r15
     14f:      	je	0x17f <event_exit_acct_process+0x17f>
     151:      	cmpq	$-0x2, %r15
     155:      	jne	0x16f <event_exit_acct_process+0x16f>
     157:      	addq	$0x190, %rax            # imm = 0x190
     15d:      	jmp	0x185 <event_exit_acct_process+0x185>
     15f:      	addq	$0x1b0, %rax            # imm = 0x1B0
     165:      	jmp	0x185 <event_exit_acct_process+0x185>
     167:      	addq	$0x1b8, %rax            # imm = 0x1B8
     16d:      	jmp	0x185 <event_exit_acct_process+0x185>
     16f:      	addq	$0x188, %rax            # imm = 0x188
     175:      	jmp	0x185 <event_exit_acct_process+0x185>
     177:      	addq	$0x1a8, %rax            # imm = 0x1A8
     17d:      	jmp	0x185 <event_exit_acct_process+0x185>
     17f:      	addq	$0x198, %rax            # imm = 0x198
     185:      	lock
     186:      	incq	(%rax)
     189:      	movl	%r14d, 0xc(%rsp)
     18e:      	movq	(%rip), %rdi            # 0x195 <event_exit_acct_process+0x195>
     195:      	leaq	0xc(%rsp), %rsi
     19a:      	movl	$0x3, %eax
     19f:      	callq	*%rax
     1a1:      	testl	%eax, %eax
     1a3:      	je	0x1ca <event_exit_acct_process+0x1ca>
     1a5:      	movl	$0x2, 0x8(%rsp)
     1ad:      	movq	(%rip), %rdi            # 0x1b4 <event_exit_acct_process+0x1b4>
     1b4:      	leaq	0x8(%rsp), %rsi
     1b9:      	movl	$0x1, %eax
     1be:      	callq	*%rax
     1c0:      	testq	%rax, %rax
     1c3:      	je	0x1ed <event_exit_acct_process+0x1ed>
     1c5:      	incq	(%rax)
     1c8:      	jmp	0x1ed <event_exit_acct_process+0x1ed>
     1ca:      	movl	$0x0, 0x8(%rsp)
     1d2:      	movq	(%rip), %rdi            # 0x1d9 <event_exit_acct_process+0x1d9>
     1d9:      	leaq	0x8(%rsp), %rsi
     1de:      	movl	$0x1, %eax
     1e3:      	callq	*%rax
     1e5:      	testq	%rax, %rax
     1e8:      	je	0x1ed <event_exit_acct_process+0x1ed>
     1ea:      	decq	(%rax)
     1ed:      	movq	(%rip), %rdi            # 0x1f4 <event_exit_acct_process+0x1f4>
     1f4:      	movl	$0x3, %eax
     1f9:      	movq	%rbx, %rsi
     1fc:      	callq	*%rax
     1fe:      	xorl	%eax, %eax
     200:      	addq	$0x10, %rsp
     204:      	popq	%rbx
     205:      	popq	%r12
     207:      	popq	%r13
     209:      	popq	%r14
     20b:      	popq	%r15
     20d:      	retq

Disassembly of section kprobe/disassociate_ctty:

0000000000000000 <event_exit_disassociate_ctty>:
       0:      	pushq	%r15
       2:      	pushq	%r14
       4:      	pushq	%r13
       6:      	pushq	%r12
       8:      	pushq	%rbx
       9:      	subq	$0x10, %rsp
       d:      	movq	%rdi, %r15
      10:      	leaq	0x70(%rdi), %rdx
      14:      	movq	%rsp, %rdi
      17:      	movl	$0x8, %ecx
      1c:      	movl	$0x4, %eax
      21:      	movl	$0x8, %esi
      26:      	callq	*%rax
      28:      	cmpl	$0x0, (%rsp)
      2c:      	je	0x214 <event_exit_disassociate_ctty+0x214>
      32:      	movl	$0xe, %eax
      37:      	callq	*%rax
      39:      	movq	%rax, %r14
      3c:      	shrq	$0x20, %r14
      40:      	movl	%r14d, (%rsp)
      44:      	movq	(%rip), %rdi            # 0x4b <event_exit_disassociate_ctty+0x4b>
      4b:      	movq	%rsp, %rsi
      4e:      	movl	$0x1, %eax
      53:      	callq	*%rax
      55:      	testq	%rax, %rax
      58:      	je	0x214 <event_exit_disassociate_ctty+0x214>
      5e:      	movq	%rax, %rbx
      61:      	cmpq	$0x0, 0x8(%rax)
      66:      	je	0x1a5 <event_exit_disassociate_ctty+0x1a5>
      6c:      	movl	$0x23, %eax
      71:      	callq	*%rax
      73:      	movq	%rax, %r12
      76:      	movl	$0x0, 0xc(%rsp)
      7e:      	movq	(%rip), %rdi            # 0x85 <event_exit_disassociate_ctty+0x85>
      85:      	leaq	0xc(%rsp), %rsi
      8a:      	movl	$0x1, %eax
      8f:      	callq	*%rax
      91:      	testq	%rax, %rax
      94:      	je	0x214 <event_exit_disassociate_ctty+0x214>
      9a:      	movabsq	$0x2800000007, %rcx     # imm = 0x2800000007
      a4:      	movq	%rcx, (%rax)
      a7:      	movq	%rax, %r13
      aa:      	movl	$0x5, %eax
      af:      	callq	*%rax
      b1:      	movq	%rax, 0x8(%r13)
      b5:      	movl	%r14d, 0x10(%r13)
      b9:      	movl	$0x0, 0x14(%r13)
      c1:      	movq	0x8(%rbx), %rax
      c5:      	movq	%rax, 0x18(%r13)
      c9:      	movq	%r13, %rdi
      cc:      	addq	$0x20, %rdi
      d0:      	movl	%r14d, 0x24(%r13)
      d4:      	addq	$0xa8c, %r12            # imm = 0xA8C
      db:      	movl	$0x4, %ecx
      e0:      	movl	$0x4, %eax
      e5:      	movl	$0x4, %esi
      ea:      	movq	%r12, %rdx
      ed:      	callq	*%rax
      ef:      	movq	(%rip), %rsi            # 0xf6 <event_exit_disassociate_ctty+0xf6>
      f6:      	movl	$0xffffffff, %ecx       # imm = 0xFFFFFFFF
      fb:      	movl	$0x28, %edx
     100:      	movl	$0x19, %eax
     105:      	movl	$0xffffffff, %edx       # imm = 0xFFFFFFFF
     10a:      	movl	$0x28, %r8d
     110:      	movq	%r15, %rdi
     113:      	movq	%r13, %rcx
     116:      	callq	*%rax
     118:      	testq	%rax, %rax
     11b:      	jns	0x1a5 <event_exit_disassociate_ctty+0x1a5>
     121:      	movq	%rax, %r15
     124:      	movl	$0x0, (%rsp)
     12b:      	movq	(%rip), %rdi            # 0x132 <event_exit_disassociate_ctty+0x132>
     132:      	movq	%rsp, %rsi
     135:      	movl	$0x1, %eax
     13a:      	callq	*%rax
     13c:      	testq	%rax, %rax
     13f:      	je	0x1a5 <event_exit_disassociate_ctty+0x1a5>
     141:      	cmpq	$-0xc, %r15
     145:      	jg	0x161 <event_exit_disassociate_ctty+0x161>
     147:      	cmpq	$-0x1c, %r15
     14b:      	je	0x17b <event_exit_disassociate_ctty+0x17b>
     14d:      	cmpq	$-0x16, %r15
     151:      	je	0x193 <event_exit_disassociate_ctty+0x193>
     153:      	cmpq	$-0x10, %r15
     157:      	jne	0x18b <event_exit_disassociate_ctty+0x18b>
     159:      	addq	$0x1a0, %rax            # imm = 0x1A0
     15f:      	jmp	0x1a1 <event_exit_disassociate_ctty+0x1a1>
     161:      	cmpq	$-0xb, %r15
     165:      	je	0x183 <event_exit_disassociate_ctty+0x183>
     167:      	cmpq	$-0x7, %r15
     16b:      	je	0x19b <event_exit_disassociate_ctty+0x19b>
     16d:      	cmpq	$-0x2, %r15
     171:      	jne	0x18b <event_exit_disassociate_ctty+0x18b>
     173:      	addq	$0x190, %rax            # imm = 0x190
     179:      	jmp	0x1a1 <event_exit_disassociate_ctty+0x1a1>
     17b:      	addq	$0x1b0, %rax            # imm = 0x1B0
     181:      	jmp	0x1a1 <event_exit_disassociate_ctty+0x1a1>
     183:      	addq	$0x1b8, %rax            # imm = 0x1B8
     189:      	jmp	0x1a1 <event_exit_disassociate_ctty+0x1a1>
     18b:      	addq	$0x188, %rax            # imm = 0x188
     191:      	jmp	0x1a1 <event_exit_disassociate_ctty+0x1a1>
     193:      	addq	$0x1a8, %rax            # imm = 0x1A8
     199:      	jmp	0x1a1 <event_exit_disassociate_ctty+0x1a1>
     19b:      	addq	$0x198, %rax            # imm = 0x198
     1a1:      	lock
     1a2:      	incq	(%rax)
     1a5:      	movl	%r14d, 0xc(%rsp)
     1aa:      	movq	(%rip), %rdi            # 0x1b1 <event_exit_disassociate_ctty+0x1b1>
     1b1:      	leaq	0xc(%rsp), %rsi
     1b6:      	movl	$0x3, %eax
     1bb:      	callq	*%rax
     1bd:      	testl	%eax, %eax
     1bf:      	je	0x1e3 <event_exit_disassociate_ctty+0x1e3>
     1c1:      	movl	$0x2, (%rsp)
     1c8:      	movq	(%rip), %rdi            # 0x1cf <event_exit_disassociate_ctty+0x1cf>
     1cf:      	movq	%rsp, %rsi
     1d2:      	movl	$0x1, %eax
     1d7:      	callq	*%rax
     1d9:      	testq	%rax, %rax
     1dc:      	je	0x203 <event_exit_disassociate_ctty+0x203>
     1de:      	incq	(%rax)
     1e1:      	jmp	0x203 <event_exit_disassociate_ctty+0x203>
     1e3:      	movl	$0x0, (%rsp)
     1ea:      	movq	(%rip), %rdi            # 0x1f1 <event_exit_disassociate_ctty+0x1f1>
     1f1:      	movq	%rsp, %rsi
     1f4:      	movl	$0x1, %eax
     1f9:      	callq	*%rax
     1fb:      	testq	%rax, %rax
     1fe:      	je	0x203 <event_exit_disassociate_ctty+0x203>
     200:      	decq	(%rax)
     203:      	movq	(%rip), %rdi            # 0x20a <event_exit_disassociate_ctty+0x20a>
     20a:      	movl	$0x3, %eax
     20f:      	movq	%rbx, %rsi
     212:      	callq	*%rax
     214:      	xorl	%eax, %eax
     216:      	addq	$0x10, %rsp
     21a:      	popq	%rbx
     21b:      	popq	%r12
     21d:      	popq	%r13
     21f:      	popq	%r14
     221:      	popq	%r15
     223:      	retq
