
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/otel/dotnet_tracer.native.o:	file format elf64-x86-64

Disassembly of section perf_event/unwind_dotnet:

0000000000000000 <perf_unwind_dotnet>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xa8, %rsp
      11:      	movq	%rdi, %r15
      14:      	movl	$0x0, 0x10(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <perf_unwind_dotnet+0x23>
      23:      	leaq	0x10(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x78cb <perf_unwind_dotnet+0x78cb>
      38:      	movq	%rax, %r14
      3b:      	movl	(%rax), %eax
      3d:      	movl	%eax, 0xa4(%rsp)
      44:      	movq	(%rip), %rbp            # 0x4b <perf_unwind_dotnet+0x4b>
      4b:      	cmpl	$0x0, (%rbp)
      4f:      	jne	0x753 <perf_unwind_dotnet+0x753>
      55:      	movq	(%rip), %rdi            # 0x5c <perf_unwind_dotnet+0x5c>
      5c:      	leaq	0xa4(%rsp), %rsi
      64:      	movl	$0x1, %eax
      69:      	callq	*%rax
      6b:      	testq	%rax, %rax
      6e:      	je	0x9d <perf_unwind_dotnet+0x9d>
      70:      	movb	$0x2, 0x1385(%r14)
      78:      	movl	$0x5a, 0x70(%rsp)
      80:      	movq	(%rip), %rdi            # 0x87 <perf_unwind_dotnet+0x87>
      87:      	leaq	0x70(%rsp), %rsi
      8c:      	movl	$0x1, %eax
      91:      	callq	*%rax
      93:      	testq	%rax, %rax
      96:      	je	0xd3 <perf_unwind_dotnet+0xd3>
      98:      	incq	(%rax)
      9b:      	jmp	0xdd <perf_unwind_dotnet+0xdd>
      9d:      	cmpl	$0x0, (%rbp)
      a1:      	jne	0x83d <perf_unwind_dotnet+0x83d>
      a7:      	movl	$0x5c, 0x70(%rsp)
      af:      	movq	(%rip), %rdi            # 0xb6 <perf_unwind_dotnet+0xb6>
      b6:      	leaq	0x70(%rsp), %rsi
      bb:      	movl	$0x1, %eax
      c0:      	callq	*%rax
      c2:      	testq	%rax, %rax
      c5:      	je	0x2ae <perf_unwind_dotnet+0x2ae>
      cb:      	incq	(%rax)
      ce:      	jmp	0x2b8 <perf_unwind_dotnet+0x2b8>
      d3:      	cmpl	$0x0, (%rbp)
      d7:      	jne	0x8bd <perf_unwind_dotnet+0x8bd>
      dd:      	movq	0xed0(%r14), %r12
      e4:      	movq	0xed8(%r14), %rbx
      eb:      	movq	0xee0(%r14), %r13
      f2:      	movzbl	0xf30(%r14), %ecx
      fa:      	cmpl	$0x0, (%rbp)
      fe:      	jne	0x7c4 <perf_unwind_dotnet+0x7c4>
     104:      	cmpq	%rbx, %r13
     107:      	jb	0x77c0 <perf_unwind_dotnet+0x77c0>
     10d:      	leaq	0x2000(%rbx), %rax
     114:      	cmpq	%rax, %r13
     117:      	jae	0x77c0 <perf_unwind_dotnet+0x77c0>
     11d:      	movb	%cl, 0x98(%rsp)
     124:      	movq	%r15, 0x60(%rsp)
     129:      	leaq	0xed0(%r14), %rbx
     130:      	movq	%r14, %rax
     133:      	addq	$0xf80, %rax            # imm = 0xF80
     139:      	movq	%rax, 0x90(%rsp)
     141:      	movq	0xf10(%r14), %rbp
     148:      	movq	0xf20(%r14), %r15
     14f:      	movq	%r12, 0x68(%rsp)
     154:      	movb	$0x1, 0xf30(%r14)
     15c:      	movq	%rbp, %rax
     15f:      	andq	$-0x80, %rax
     163:      	cmpq	$0x80, %rax
     169:      	jne	0x24e <perf_unwind_dotnet+0x24e>
     16f:      	movq	0xed8(%r14), %rax
     176:      	movl	$0x8, %ecx
     17b:      	movl	$0x70, %r8d
     181:      	movq	0xed8(%r14), %rdx
     188:      	movq	%rbx, %rdi
     18b:      	movl	$0x8, %esi
     190:      	callq	*%r8
     193:      	testq	%rax, %rax
     196:      	je	0x2c2 <perf_unwind_dotnet+0x2c2>
     19c:      	movq	(%rip), %rbp            # 0x1a3 <perf_unwind_dotnet+0x1a3>
     1a3:      	cmpl	$0x0, (%rbp)
     1a7:      	jne	0x9ce <perf_unwind_dotnet+0x9ce>
     1ad:      	movl	$0x5d, 0xc(%rsp)
     1b5:      	movq	(%rip), %rdi            # 0x1bc <perf_unwind_dotnet+0x1bc>
     1bc:      	leaq	0xc(%rsp), %rsi
     1c1:      	movl	$0x1, %eax
     1c6:      	callq	*%rax
     1c8:      	testq	%rax, %rax
     1cb:      	movq	0x60(%rsp), %r15
     1d0:      	jne	0x2a6 <perf_unwind_dotnet+0x2a6>
     1d6:      	cmpl	$0x0, (%rbp)
     1da:      	je	0x780d <perf_unwind_dotnet+0x780d>
     1e0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     1ea:      	movq	%rax, 0x36(%rsp)
     1ef:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     1f9:      	movq	%rax, 0x30(%rsp)
     1fe:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     208:      	movq	%rax, 0x28(%rsp)
     20d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     217:      	movq	%rax, 0x20(%rsp)
     21c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     226:      	movq	%rax, 0x18(%rsp)
     22b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     235:      	movq	%rax, 0x10(%rsp)
     23a:      	leaq	0x10(%rsp), %rdi
     23f:      	movl	$0x2e, %eax
     244:      	movl	$0x6, %ecx
     249:      	jmp	0x472 <perf_unwind_dotnet+0x472>
     24e:      	leaq	0x70(%rsp), %rdi
     253:      	movl	$0x10, %eax
     258:      	movl	$0x70, %ecx
     25d:      	movl	$0x10, %esi
     262:      	movq	%r13, %rdx
     265:      	callq	*%rcx
     267:      	testq	%rax, %rax
     26a:      	je	0x2d2 <perf_unwind_dotnet+0x2d2>
     26c:      	movq	(%rip), %rbp            # 0x273 <perf_unwind_dotnet+0x273>
     273:      	cmpl	$0x0, (%rbp)
     277:      	jne	0xa27 <perf_unwind_dotnet+0xa27>
     27d:      	movl	$0x5d, 0xc(%rsp)
     285:      	movq	(%rip), %rdi            # 0x28c <perf_unwind_dotnet+0x28c>
     28c:      	leaq	0xc(%rsp), %rsi
     291:      	movl	$0x1, %eax
     296:      	callq	*%rax
     298:      	testq	%rax, %rax
     29b:      	movq	0x60(%rsp), %r15
     2a0:      	je	0x3ff <perf_unwind_dotnet+0x3ff>
     2a6:      	incq	(%rax)
     2a9:      	jmp	0x780d <perf_unwind_dotnet+0x780d>
     2ae:      	cmpl	$0x0, (%rbp)
     2b2:      	jne	0x938 <perf_unwind_dotnet+0x938>
     2b8:      	movl	$0x1770, %eax           # imm = 0x1770
     2bd:      	jmp	0x7812 <perf_unwind_dotnet+0x7812>
     2c2:      	addq	$0x8, 0xed8(%r14)
     2ca:      	andl	$0x7f, %ebp
     2cd:      	jmp	0xbef <perf_unwind_dotnet+0xbef>
     2d2:      	addq	$0x10, %r13
     2d6:      	movq	%r13, 0xed8(%r14)
     2dd:      	movq	0x70(%rsp), %rax
     2e2:      	movq	%rax, 0xee0(%r14)
     2e9:      	movq	0x78(%rsp), %rax
     2ee:      	movq	%rax, 0xed0(%r14)
     2f5:      	movq	(%rip), %rax            # 0x2fc <perf_unwind_dotnet+0x2fc>
     2fc:      	cmpl	$0x0, (%rax)
     2ff:      	jne	0xa80 <perf_unwind_dotnet+0xa80>
     305:      	cmpq	$0x100, %rbp            # imm = 0x100
     30c:      	jb	0xbef <perf_unwind_dotnet+0xbef>
     312:      	movq	0xf10(%r14), %rbp
     319:      	movq	0xf20(%r14), %rax
     320:      	movq	%r12, %r13
     323:      	movq	%rax, 0x88(%rsp)
     32b:      	subq	%rax, %r13
     32e:      	movq	(%rip), %rax            # 0x335 <perf_unwind_dotnet+0x335>
     335:      	cmpl	$0x0, (%rax)
     338:      	jne	0xb19 <perf_unwind_dotnet+0xb19>
     33e:      	movq	%r13, %r15
     341:      	andq	$-0x4, %r15
     345:      	movl	$0x100, %ecx            # imm = 0x100
     34a:      	movq	%r15, %rax
     34d:      	xorl	%edx, %edx
     34f:      	divq	%rcx
     352:      	movq	%rax, %rcx
     355:      	movl	$0x7f, %eax
     35a:      	subq	%rcx, %rax
     35d:      	jns	0x376 <perf_unwind_dotnet+0x376>
     35f:      	movl	$0x100, %ecx            # imm = 0x100
     364:      	movq	%r15, %rax
     367:      	xorl	%edx, %edx
     369:      	divq	%rcx
     36c:      	leaq	-0x3fc(%rbp,%rax,4), %rbp
     374:      	xorl	%eax, %eax
     376:      	movl	$0x80, %ecx
     37b:      	cqto
     37d:      	idivq	%rcx
     380:      	movq	0x90(%rsp), %rax
     388:      	leaq	(%rax,%rdx,4), %rdi
     38c:      	movl	$0x200, %eax            # imm = 0x200
     391:      	movl	$0x70, %ecx
     396:      	movl	$0x200, %esi            # imm = 0x200
     39b:      	movq	%rbp, %rdx
     39e:      	callq	*%rcx
     3a0:      	testq	%rax, %rax
     3a3:      	je	0x484 <perf_unwind_dotnet+0x484>
     3a9:      	movq	(%rip), %rbp            # 0x3b0 <perf_unwind_dotnet+0x3b0>
     3b0:      	cmpl	$0x0, (%rbp)
     3b4:      	jne	0x6fc <perf_unwind_dotnet+0x6fc>
     3ba:      	movl	$0x5e, 0xc(%rsp)
     3c2:      	movq	(%rip), %rdi            # 0x3c9 <perf_unwind_dotnet+0x3c9>
     3c9:      	leaq	0xc(%rsp), %rsi
     3ce:      	movl	$0x1, %eax
     3d3:      	callq	*%rax
     3d5:      	testq	%rax, %rax
     3d8:      	movq	0x60(%rsp), %r15
     3dd:      	movq	%rbx, %r12
     3e0:      	je	0x4f6 <perf_unwind_dotnet+0x4f6>
     3e6:      	incq	(%rax)
     3e9:      	movl	$0x1772, %edx           # imm = 0x1772
     3ee:      	xorl	%ebx, %ebx
     3f0:      	cmpl	$0x0, (%rbp)
     3f4:      	je	0x511 <perf_unwind_dotnet+0x511>
     3fa:      	jmp	0x1acf <perf_unwind_dotnet+0x1acf>
     3ff:      	cmpl	$0x0, (%rbp)
     403:      	je	0x780d <perf_unwind_dotnet+0x780d>
     409:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     413:      	movq	%rax, 0x36(%rsp)
     418:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     422:      	movq	%rax, 0x30(%rsp)
     427:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     431:      	movq	%rax, 0x28(%rsp)
     436:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     440:      	movq	%rax, 0x20(%rsp)
     445:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     44f:      	movq	%rax, 0x18(%rsp)
     454:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     45e:      	movq	%rax, 0x10(%rsp)
     463:      	leaq	0x10(%rsp), %rdi
     468:      	movl	$0x2e, %eax
     46d:      	movl	$0x6, %ecx
     472:      	movl	0xc(%rsp), %edx
     476:      	movl	$0x2e, %esi
     47b:      	xorl	%eax, %eax
     47d:      	callq	*%rcx
     47f:      	jmp	0x780d <perf_unwind_dotnet+0x780d>
     484:      	movl	0x117c(%r14), %ebp
     48b:      	movq	(%rip), %rax            # 0x492 <perf_unwind_dotnet+0x492>
     492:      	cmpl	$0x0, (%rax)
     495:      	jne	0x1138 <perf_unwind_dotnet+0x1138>
     49b:      	movl	$0x20, %ecx
     4a0:      	movq	%r15, %rax
     4a3:      	xorl	%edx, %edx
     4a5:      	divq	%rcx
     4a8:      	movl	$0x8, %ecx
     4ad:      	xorl	%edx, %edx
     4af:      	divq	%rcx
     4b2:      	shll	$0x2, %edx
     4b5:      	movb	$0x1c, %al
     4b7:      	subb	%dl, %al
     4b9:      	shrxl	%eax, %ebp, %r15d
     4be:      	testl	%r15d, %r15d
     4c1:      	je	0x633 <perf_unwind_dotnet+0x633>
     4c7:      	andq	$-0x20, %r13
     4cb:      	movq	(%rip), %rbp            # 0x4d2 <perf_unwind_dotnet+0x4d2>
     4d2:      	movl	%r15d, %ecx
     4d5:      	andl	$0xf, %ecx
     4d8:      	jne	0xb77 <perf_unwind_dotnet+0xb77>
     4de:      	movl	%r15d, %ecx
     4e1:      	shrl	$0x4, %ecx
     4e4:      	andl	$0xf, %ecx
     4e7:      	je	0x73f <perf_unwind_dotnet+0x73f>
     4ed:      	addq	$-0x20, %r13
     4f1:      	jmp	0xb77 <perf_unwind_dotnet+0xb77>
     4f6:      	cmpl	$0x0, (%rbp)
     4fa:      	jne	0x1244 <perf_unwind_dotnet+0x1244>
     500:      	movl	$0x1772, %edx           # imm = 0x1772
     505:      	xorl	%ebx, %ebx
     507:      	cmpl	$0x0, (%rbp)
     50b:      	jne	0x1acf <perf_unwind_dotnet+0x1acf>
     511:      	movl	$0x1772, %eax           # imm = 0x1772
     516:      	testb	%bl, %bl
     518:      	je	0x7812 <perf_unwind_dotnet+0x7812>
     51e:      	movl	0x2c0(%r14), %eax
     525:      	cmpq	$0x7f, %rax
     529:      	jb	0x5d5 <perf_unwind_dotnet+0x5d5>
     52f:      	cmpl	$0x0, (%rbp)
     533:      	jne	0x12d0 <perf_unwind_dotnet+0x12d0>
     539:      	movl	$0x2, 0xc(%rsp)
     541:      	movq	(%rip), %rdi            # 0x548 <perf_unwind_dotnet+0x548>
     548:      	leaq	0xc(%rsp), %rsi
     54d:      	movl	$0x1, %eax
     552:      	callq	*%rax
     554:      	testq	%rax, %rax
     557:      	jne	0xc42 <perf_unwind_dotnet+0xc42>
     55d:      	cmpl	$0x0, (%rbp)
     561:      	je	0xc51 <perf_unwind_dotnet+0xc51>
     567:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     571:      	movq	%rax, 0x36(%rsp)
     576:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     580:      	movq	%rax, 0x30(%rsp)
     585:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     58f:      	movq	%rax, 0x28(%rsp)
     594:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     59e:      	movq	%rax, 0x20(%rsp)
     5a3:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     5ad:      	movq	%rax, 0x18(%rsp)
     5b2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     5bc:      	movq	%rax, 0x10(%rsp)
     5c1:      	leaq	0x10(%rsp), %rdi
     5c6:      	movl	$0x2e, %eax
     5cb:      	movl	$0x6, %ecx
     5d0:      	jmp	0x109c <perf_unwind_dotnet+0x109c>
     5d5:      	leal	0x1(%rax), %ecx
     5d8:      	movl	%ecx, 0x2c0(%r14)
     5df:      	leaq	(%rax,%rax,2), %rax
     5e3:      	movq	$0x0, 0x2d0(%r14,%rax,8)
     5ef:      	movq	$0x1773, 0x2d8(%r14,%rax,8) # imm = 0x1773
     5fb:      	movb	$-0x76, 0x2e0(%r14,%rax,8)
     604:      	movl	$0x0, 0x2e1(%r14,%rax,8)
     610:      	movl	$0x0, 0x2e4(%r14,%rax,8)
     61c:      	movq	%r12, %rbx
     61f:      	movq	(%rbx), %r13
     622:      	movl	(%rbp), %eax
     625:      	testq	%r13, %r13
     628:      	jne	0xd8a <perf_unwind_dotnet+0xd8a>
     62e:      	jmp	0x2594 <perf_unwind_dotnet+0x2594>
     633:      	andq	$-0x100, %r13
     63a:      	addq	$-0x20, %r13
     63e:      	movl	0x1178(%r14), %r15d
     645:      	movq	(%rip), %rbp            # 0x64c <perf_unwind_dotnet+0x64c>
     64c:      	cmpl	$0x0, (%rbp)
     650:      	jne	0x14a0 <perf_unwind_dotnet+0x14a0>
     656:      	xorl	%ecx, %ecx
     658:      	testl	%r15d, %r15d
     65b:      	je	0x1534 <perf_unwind_dotnet+0x1534>
     661:      	movl	%ecx, %eax
     663:      	shll	$0x8, %eax
     666:      	subq	%rax, %r13
     669:      	jae	0x1a5e <perf_unwind_dotnet+0x1a5e>
     66f:      	cmpl	$0x0, (%rbp)
     673:      	je	0x3ba <perf_unwind_dotnet+0x3ba>
     679:      	movabsq	$0xa657361625f63, %rax  # imm = 0xA657361625F63
     683:      	movq	%rax, 0x36(%rsp)
     688:      	movabsq	$0x5f637020776f6c65, %rax # imm = 0x5F637020776F6C65
     692:      	movq	%rax, 0x30(%rsp)
     697:      	movabsq	$0x6220746e65772068, %rax # imm = 0x6220746E65772068
     6a1:      	movq	%rax, 0x28(%rsp)
     6a6:      	movabsq	$0x6372616573207061, %rax # imm = 0x6372616573207061
     6b0:      	movq	%rax, 0x20(%rsp)
     6b5:      	movabsq	$0x6d20656c6262696e, %rax # imm = 0x6D20656C6262696E
     6bf:      	movq	%rax, 0x18(%rsp)
     6c4:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
     6ce:      	movq	%rax, 0x10(%rsp)
     6d3:      	leaq	0x10(%rsp), %rdi
     6d8:      	movl	$0x2e, %eax
     6dd:      	movl	$0x6, %ecx
     6e2:      	movl	$0x2e, %esi
     6e7:      	xorl	%eax, %eax
     6e9:      	callq	*%rcx
     6eb:      	movq	(%rip), %rbp            # 0x6f2 <perf_unwind_dotnet+0x6f2>
     6f2:      	cmpl	$0x0, (%rbp)
     6f6:      	je	0x3ba <perf_unwind_dotnet+0x3ba>
     6fc:      	movabsq	$0x6e756f6620746f6e, %rax # imm = 0x6E756F6620746F6E
     706:      	movq	%rax, 0x18(%rsp)
     70b:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
     715:      	movq	%rax, 0x10(%rsp)
     71a:      	movl	$0xa646e, 0x1f(%rsp)    # imm = 0xA646E
     722:      	leaq	0x10(%rsp), %rdi
     727:      	movl	$0x13, %eax
     72c:      	movl	$0x6, %ecx
     731:      	movl	$0x13, %esi
     736:      	xorl	%eax, %eax
     738:      	callq	*%rcx
     73a:      	jmp	0x3ba <perf_unwind_dotnet+0x3ba>
     73f:      	movl	%r15d, %ecx
     742:      	shrl	$0x8, %ecx
     745:      	andl	$0xf, %ecx
     748:      	je	0x7ac <perf_unwind_dotnet+0x7ac>
     74a:      	addq	$-0x40, %r13
     74e:      	jmp	0xb77 <perf_unwind_dotnet+0xb77>
     753:      	movabsq	$0x3d3d206425207465, %rax # imm = 0x3D3D206425207465
     75d:      	movq	%rax, 0x20(%rsp)
     762:      	movabsq	$0x6e746f645f646e69, %rax # imm = 0x6E746F645F646E69
     76c:      	movq	%rax, 0x18(%rsp)
     771:      	movabsq	$0x776e75203d3d3d3d, %rax # imm = 0x776E75203D3D3D3D
     77b:      	movq	%rax, 0x10(%rsp)
     780:      	movl	$0xa3d3d, 0x28(%rsp)    # imm = 0xA3D3D
     788:      	leaq	0x10(%rsp), %rdi
     78d:      	movl	$0x1c, %eax
     792:      	movl	$0x6, %ecx
     797:      	movl	0x2c0(%r14), %edx
     79e:      	movl	$0x1c, %esi
     7a3:      	xorl	%eax, %eax
     7a5:      	callq	*%rcx
     7a7:      	jmp	0x55 <perf_unwind_dotnet+0x55>
     7ac:      	movl	%r15d, %ecx
     7af:      	shrl	$0xc, %ecx
     7b2:      	andl	$0xf, %ecx
     7b5:      	je	0x8a5 <perf_unwind_dotnet+0x8a5>
     7bb:      	addq	$-0x60, %r13
     7bf:      	jmp	0xb77 <perf_unwind_dotnet+0xb77>
     7c4:      	movabsq	$0x6c25203a7066202c, %rax # imm = 0x6C25203A7066202C
     7ce:      	movq	%rax, 0x28(%rsp)
     7d3:      	movabsq	$0x786c25203a707320, %rax # imm = 0x786C25203A707320
     7dd:      	movq	%rax, 0x20(%rsp)
     7e2:      	movabsq	$0x2c786c25203a6370, %rax # imm = 0x2C786C25203A6370
     7ec:      	movq	%rax, 0x18(%rsp)
     7f1:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
     7fb:      	movq	%rax, 0x10(%rsp)
     800:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
     808:      	leaq	0x10(%rsp), %rdi
     80d:      	movl	$0x23, %eax
     812:      	movl	$0x6, %r9d
     818:      	movl	$0x23, %esi
     81d:      	movq	%r12, %rdx
     820:      	movl	%ecx, %ebp
     822:      	movq	%rbx, %rcx
     825:      	movq	%r13, %r8
     828:      	xorl	%eax, %eax
     82a:      	callq	*%r9
     82d:      	movl	%ebp, %ecx
     82f:      	cmpq	%rbx, %r13
     832:      	jae	0x10d <perf_unwind_dotnet+0x10d>
     838:      	jmp	0x77c0 <perf_unwind_dotnet+0x77c0>
     83d:      	movabsq	$0xa646970207369, %rax  # imm = 0xA646970207369
     847:      	movq	%rax, 0x30(%rsp)
     84c:      	movabsq	$0x687420726f66206f, %rax # imm = 0x687420726F66206F
     856:      	movq	%rax, 0x28(%rsp)
     85b:      	movabsq	$0x666e49636f725074, %rax # imm = 0x666E49636F725074
     865:      	movq	%rax, 0x20(%rsp)
     86a:      	movabsq	$0x656e746f44206f6e, %rax # imm = 0x656E746F44206F6E
     874:      	movq	%rax, 0x18(%rsp)
     879:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
     883:      	movq	%rax, 0x10(%rsp)
     888:      	leaq	0x10(%rsp), %rdi
     88d:      	movl	$0x28, %eax
     892:      	movl	$0x6, %ecx
     897:      	movl	$0x28, %esi
     89c:      	xorl	%eax, %eax
     89e:      	callq	*%rcx
     8a0:      	jmp	0xa7 <perf_unwind_dotnet+0xa7>
     8a5:      	movl	%r15d, %ecx
     8a8:      	shrl	$0x10, %ecx
     8ab:      	andl	$0xf, %ecx
     8ae:      	je	0x9b3 <perf_unwind_dotnet+0x9b3>
     8b4:      	addq	$-0x80, %r13
     8b8:      	jmp	0xb77 <perf_unwind_dotnet+0xb77>
     8bd:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     8c7:      	movq	%rax, 0x36(%rsp)
     8cc:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     8d6:      	movq	%rax, 0x30(%rsp)
     8db:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     8e5:      	movq	%rax, 0x28(%rsp)
     8ea:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     8f4:      	movq	%rax, 0x20(%rsp)
     8f9:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     903:      	movq	%rax, 0x18(%rsp)
     908:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     912:      	movq	%rax, 0x10(%rsp)
     917:      	leaq	0x10(%rsp), %rdi
     91c:      	movl	$0x2e, %eax
     921:      	movl	$0x6, %ecx
     926:      	movl	0x70(%rsp), %edx
     92a:      	movl	$0x2e, %esi
     92f:      	xorl	%eax, %eax
     931:      	callq	*%rcx
     933:      	jmp	0xdd <perf_unwind_dotnet+0xdd>
     938:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     942:      	movq	%rax, 0x36(%rsp)
     947:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     951:      	movq	%rax, 0x30(%rsp)
     956:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     960:      	movq	%rax, 0x28(%rsp)
     965:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     96f:      	movq	%rax, 0x20(%rsp)
     974:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     97e:      	movq	%rax, 0x18(%rsp)
     983:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     98d:      	movq	%rax, 0x10(%rsp)
     992:      	leaq	0x10(%rsp), %rdi
     997:      	movl	$0x2e, %eax
     99c:      	movl	$0x6, %ecx
     9a1:      	movl	0x70(%rsp), %edx
     9a5:      	movl	$0x2e, %esi
     9aa:      	xorl	%eax, %eax
     9ac:      	callq	*%rcx
     9ae:      	jmp	0x2b8 <perf_unwind_dotnet+0x2b8>
     9b3:      	movl	%r15d, %ecx
     9b6:      	shrl	$0x14, %ecx
     9b9:      	andl	$0xf, %ecx
     9bc:      	je	0xb05 <perf_unwind_dotnet+0xb05>
     9c2:      	addq	$-0xa0, %r13
     9c9:      	jmp	0xb70 <perf_unwind_dotnet+0xb70>
     9ce:      	movabsq	$0xa7265746e696f, %rax  # imm = 0xA7265746E696F
     9d8:      	movq	%rax, 0x28(%rsp)
     9dd:      	movabsq	$0x70206b6361747320, %rax # imm = 0x70206B6361747320
     9e7:      	movq	%rax, 0x20(%rsp)
     9ec:      	movabsq	$0x646162203e2d2d20, %rax # imm = 0x646162203E2D2D20
     9f6:      	movq	%rax, 0x18(%rsp)
     9fb:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
     a05:      	movq	%rax, 0x10(%rsp)
     a0a:      	leaq	0x10(%rsp), %rdi
     a0f:      	movl	$0x20, %eax
     a14:      	movl	$0x6, %ecx
     a19:      	movl	$0x20, %esi
     a1e:      	xorl	%eax, %eax
     a20:      	callq	*%rcx
     a22:      	jmp	0x1ad <perf_unwind_dotnet+0x1ad>
     a27:      	movabsq	$0xa7265746e696f, %rax  # imm = 0xA7265746E696F
     a31:      	movq	%rax, 0x28(%rsp)
     a36:      	movabsq	$0x7020656d61726620, %rax # imm = 0x7020656D61726620
     a40:      	movq	%rax, 0x20(%rsp)
     a45:      	movabsq	$0x646162203e2d2d20, %rax # imm = 0x646162203E2D2D20
     a4f:      	movq	%rax, 0x18(%rsp)
     a54:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
     a5e:      	movq	%rax, 0x10(%rsp)
     a63:      	leaq	0x10(%rsp), %rdi
     a68:      	movl	$0x20, %eax
     a6d:      	movl	$0x6, %ecx
     a72:      	movl	$0x20, %esi
     a77:      	xorl	%eax, %eax
     a79:      	callq	*%rcx
     a7b:      	jmp	0x27d <perf_unwind_dotnet+0x27d>
     a80:      	movabsq	$0x6c25203a7066202c, %rax # imm = 0x6C25203A7066202C
     a8a:      	movq	%rax, 0x28(%rsp)
     a8f:      	movabsq	$0x786c25203a707320, %rax # imm = 0x786C25203A707320
     a99:      	movq	%rax, 0x20(%rsp)
     a9e:      	movabsq	$0x2c786c25203a6370, %rax # imm = 0x2C786C25203A6370
     aa8:      	movq	%rax, 0x18(%rsp)
     aad:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
     ab7:      	movq	%rax, 0x10(%rsp)
     abc:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
     ac4:      	leaq	0x10(%rsp), %rdi
     ac9:      	movl	$0x23, %eax
     ace:      	movl	$0x6, %r9d
     ad4:      	movq	0xed0(%r14), %rdx
     adb:      	movq	0xed8(%r14), %rcx
     ae2:      	movq	0xee0(%r14), %r8
     ae9:      	movl	$0x23, %esi
     aee:      	xorl	%eax, %eax
     af0:      	callq	*%r9
     af3:      	cmpq	$0x100, %rbp            # imm = 0x100
     afa:      	jae	0x312 <perf_unwind_dotnet+0x312>
     b00:      	jmp	0xbef <perf_unwind_dotnet+0xbef>
     b05:      	movl	%r15d, %ecx
     b08:      	shrl	$0x18, %ecx
     b0b:      	andl	$0xf, %ecx
     b0e:      	je	0xb62 <perf_unwind_dotnet+0xb62>
     b10:      	addq	$-0xc0, %r13
     b17:      	jmp	0xb70 <perf_unwind_dotnet+0xb70>
     b19:      	leaq	(%rip), %rsi            # 0xb20 <perf_unwind_dotnet+0xb20>
     b20:      	leaq	0x10(%rsp), %rax
     b25:      	movl	$0x8, %ecx
     b2a:      	movq	%rax, %rdi
     b2d:      	rep		movsq	(%rsi), %es:(%rdi)
     b30:      	movw	$0xa, 0x50(%rsp)
     b37:      	movl	$0x42, %ecx
     b3c:      	movl	$0x6, %r9d
     b42:      	movq	%rax, %rdi
     b45:      	movl	$0x42, %esi
     b4a:      	movq	%r13, %rdx
     b4d:      	movq	0x88(%rsp), %rcx
     b55:      	movq	%rbp, %r8
     b58:      	xorl	%eax, %eax
     b5a:      	callq	*%r9
     b5d:      	jmp	0x33e <perf_unwind_dotnet+0x33e>
     b62:      	shrl	$0x1c, %r15d
     b66:      	addq	$-0xe0, %r13
     b6d:      	movl	%r15d, %ecx
     b70:      	movq	(%rip), %rbp            # 0xb77 <perf_unwind_dotnet+0xb77>
     b77:      	movq	0x88(%rsp), %rax
     b7f:      	addq	%r13, %rax
     b82:      	leal	-0x4(,%rcx,4), %r15d
     b8a:      	addq	%rax, %r15
     b8d:      	cmpl	$0x0, (%rbp)
     b91:      	jne	0x11c5 <perf_unwind_dotnet+0x11c5>
     b97:      	leaq	-0x8(%r15), %rdx
     b9b:      	leaq	0x68(%rsp), %rdi
     ba0:      	movl	$0x8, %eax
     ba5:      	movl	$0x70, %ecx
     baa:      	movl	$0x8, %esi
     baf:      	callq	*%rcx
     bb1:      	testq	%rax, %rax
     bb4:      	je	0xbea <perf_unwind_dotnet+0xbea>
     bb6:      	cmpl	$0x0, (%rbp)
     bba:      	jne	0x1338 <perf_unwind_dotnet+0x1338>
     bc0:      	movl	$0x5e, 0xc(%rsp)
     bc8:      	movq	(%rip), %rdi            # 0xbcf <perf_unwind_dotnet+0xbcf>
     bcf:      	leaq	0xc(%rsp), %rsi
     bd4:      	movl	$0x1, %eax
     bd9:      	callq	*%rax
     bdb:      	testq	%rax, %rax
     bde:      	movq	0x60(%rsp), %r15
     be3:      	je	0xc5b <perf_unwind_dotnet+0xc5b>
     be5:      	incq	(%rax)
     be8:      	jmp	0xc65 <perf_unwind_dotnet+0xc65>
     bea:      	movl	$0x1f, %ebp
     bef:      	movq	(%rip), %rax            # 0xbf6 <perf_unwind_dotnet+0xbf6>
     bf6:      	cmpl	$0x0, (%rax)
     bf9:      	jne	0xc6f <perf_unwind_dotnet+0xc6f>
     bfb:      	movl	0x2c0(%r14), %eax
     c02:      	cmpq	$0x7f, %rax
     c06:      	jb	0xcc9 <perf_unwind_dotnet+0xcc9>
     c0c:      	movq	(%rip), %rbp            # 0xc13 <perf_unwind_dotnet+0xc13>
     c13:      	cmpl	$0x0, (%rbp)
     c17:      	jne	0xdbe <perf_unwind_dotnet+0xdbe>
     c1d:      	movl	$0x2, 0xc(%rsp)
     c25:      	movq	(%rip), %rdi            # 0xc2c <perf_unwind_dotnet+0xc2c>
     c2c:      	leaq	0xc(%rsp), %rsi
     c31:      	movl	$0x1, %eax
     c36:      	callq	*%rax
     c38:      	testq	%rax, %rax
     c3b:      	movq	0x60(%rsp), %r15
     c40:      	je	0xc47 <perf_unwind_dotnet+0xc47>
     c42:      	incq	(%rax)
     c45:      	jmp	0xc51 <perf_unwind_dotnet+0xc51>
     c47:      	cmpl	$0x0, (%rbp)
     c4b:      	jne	0x1033 <perf_unwind_dotnet+0x1033>
     c51:      	movl	$0x2, %eax
     c56:      	jmp	0x7812 <perf_unwind_dotnet+0x7812>
     c5b:      	cmpl	$0x0, (%rbp)
     c5f:      	jne	0x1be3 <perf_unwind_dotnet+0x1be3>
     c65:      	movl	$0x1772, %eax           # imm = 0x1772
     c6a:      	jmp	0x7812 <perf_unwind_dotnet+0x7812>
     c6f:      	leaq	(%rip), %rsi            # 0xc76 <perf_unwind_dotnet+0xc76>
     c76:      	leaq	0x10(%rsp), %rax
     c7b:      	movl	$0x8, %ecx
     c80:      	movq	%rax, %rdi
     c83:      	rep		movsq	(%rsi), %es:(%rdi)
     c86:      	movb	$0x0, 0x52(%rsp)
     c8b:      	movw	$0xa78, 0x50(%rsp)      # imm = 0xA78
     c92:      	movl	$0x43, %ecx
     c97:      	movl	$0x6, %r9d
     c9d:      	movq	0x68(%rsp), %rcx
     ca2:      	movq	%r12, %r8
     ca5:      	subq	%r15, %r8
     ca8:      	movq	%rax, %rdi
     cab:      	movl	$0x43, %esi
     cb0:      	movq	%r15, %rdx
     cb3:      	xorl	%eax, %eax
     cb5:      	callq	*%r9
     cb8:      	movl	0x2c0(%r14), %eax
     cbf:      	cmpq	$0x7f, %rax
     cc3:      	jae	0xc0c <perf_unwind_dotnet+0xc0c>
     cc9:      	movq	0x68(%rsp), %rcx
     cce:      	subq	%r15, %r12
     cd1:      	shlq	$0x5, %rcx
     cd5:      	addq	%rbp, %rcx
     cd8:      	leal	0x1(%rax), %edx
     cdb:      	movl	%edx, 0x2c0(%r14)
     ce2:      	leaq	(%rax,%rax,2), %rax
     ce6:      	movq	%rcx, 0x2d0(%r14,%rax,8)
     cee:      	movq	%r12, 0x2d8(%r14,%rax,8)
     cf6:      	movb	$0xa, 0x2e0(%r14,%rax,8)
     cff:      	movzbl	0x98(%rsp), %ecx
     d07:      	movb	%cl, 0x2e1(%r14,%rax,8)
     d0f:      	movl	$0x0, 0x2e2(%r14,%rax,8)
     d1b:      	movw	$0x0, 0x2e6(%r14,%rax,8)
     d26:      	movl	$0x5b, 0xc(%rsp)
     d2e:      	movq	(%rip), %rdi            # 0xd35 <perf_unwind_dotnet+0xd35>
     d35:      	leaq	0xc(%rsp), %rsi
     d3a:      	movl	$0x1, %eax
     d3f:      	callq	*%rax
     d41:      	testq	%rax, %rax
     d44:      	je	0xd65 <perf_unwind_dotnet+0xd65>
     d46:      	incq	(%rax)
     d49:      	movq	0x60(%rsp), %r15
     d4e:      	movq	(%rip), %rbp            # 0xd55 <perf_unwind_dotnet+0xd55>
     d55:      	movq	(%rbx), %r13
     d58:      	movl	(%rbp), %eax
     d5b:      	testq	%r13, %r13
     d5e:      	jne	0xd8a <perf_unwind_dotnet+0xd8a>
     d60:      	jmp	0x2594 <perf_unwind_dotnet+0x2594>
     d65:      	movq	(%rip), %rbp            # 0xd6c <perf_unwind_dotnet+0xd6c>
     d6c:      	cmpl	$0x0, (%rbp)
     d70:      	movq	0x60(%rsp), %r15
     d75:      	jne	0x10ae <perf_unwind_dotnet+0x10ae>
     d7b:      	movq	(%rbx), %r13
     d7e:      	movl	(%rbp), %eax
     d81:      	testq	%r13, %r13
     d84:      	je	0x2594 <perf_unwind_dotnet+0x2594>
     d8a:      	testl	%eax, %eax
     d8c:      	jne	0xe26 <perf_unwind_dotnet+0xe26>
     d92:      	movq	%r13, %rax
     d95:      	shrq	$0x38, %rax
     d99:      	je	0xeb8 <perf_unwind_dotnet+0xeb8>
     d9f:      	cmpl	$0x0, (%rbp)
     da3:      	jne	0x252c <perf_unwind_dotnet+0x252c>
     da9:      	movl	$0xb, 0xf28(%r14)
     db4:      	movl	$0xfab, %eax            # imm = 0xFAB
     db9:      	jmp	0x7812 <perf_unwind_dotnet+0x7812>
     dbe:      	movabsq	$0xa6c6c75662073, %rax  # imm = 0xA6C6C75662073
     dc8:      	movq	%rax, 0x2d(%rsp)
     dcd:      	movabsq	$0x66207369206b6361, %rax # imm = 0x66207369206B6361
     dd7:      	movq	%rax, 0x28(%rsp)
     ddc:      	movabsq	$0x7473203a656d6172, %rax # imm = 0x7473203A656D6172
     de6:      	movq	%rax, 0x20(%rsp)
     deb:      	movabsq	$0x662068737570206f, %rax # imm = 0x662068737570206F
     df5:      	movq	%rax, 0x18(%rsp)
     dfa:      	movabsq	$0x7420656c62616e75, %rax # imm = 0x7420656C62616E75
     e04:      	movq	%rax, 0x10(%rsp)
     e09:      	leaq	0x10(%rsp), %rdi
     e0e:      	movl	$0x25, %eax
     e13:      	movl	$0x6, %ecx
     e18:      	movl	$0x25, %esi
     e1d:      	xorl	%eax, %eax
     e1f:      	callq	*%rcx
     e21:      	jmp	0xc1d <perf_unwind_dotnet+0xc1d>
     e26:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
     e30:      	movq	%rax, 0x38(%rsp)
     e35:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
     e3f:      	movq	%rax, 0x30(%rsp)
     e44:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
     e4e:      	movq	%rax, 0x28(%rsp)
     e53:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
     e5d:      	movq	%rax, 0x20(%rsp)
     e62:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
     e6c:      	movq	%rax, 0x18(%rsp)
     e71:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
     e7b:      	movq	%rax, 0x10(%rsp)
     e80:      	movb	$0x0, 0x40(%rsp)
     e85:      	leaq	0x10(%rsp), %rdi
     e8a:      	movl	$0x31, %eax
     e8f:      	movl	$0x6, %ecx
     e94:      	movl	0x2c0(%r14), %edx
     e9b:      	movl	$0x31, %esi
     ea0:      	xorl	%eax, %eax
     ea2:      	callq	*%rcx
     ea4:      	movq	0xed0(%r14), %r13
     eab:      	movq	%r13, %rax
     eae:      	shrq	$0x38, %rax
     eb2:      	jne	0xd9f <perf_unwind_dotnet+0xd9f>
     eb8:      	cmpq	$0xfff, %r13            # imm = 0xFFF
     ebf:      	ja	0xee0 <perf_unwind_dotnet+0xee0>
     ec1:      	cmpl	$0x0, (%rbp)
     ec5:      	jne	0x26c7 <perf_unwind_dotnet+0x26c7>
     ecb:      	movl	$0x31, 0xf28(%r14)
     ed6:      	movl	$0xfae, %eax            # imm = 0xFAE
     edb:      	jmp	0x7812 <perf_unwind_dotnet+0x7812>
     ee0:      	movl	(%r14), %eax
     ee3:      	movl	$0x60, 0x70(%rsp)
     eeb:      	movbel	%eax, 0x74(%rsp)
     ef1:      	movbeq	%r13, 0x78(%rsp)
     ef8:      	movq	(%rip), %rdi            # 0xeff <perf_unwind_dotnet+0xeff>
     eff:      	leaq	0x70(%rsp), %rsi
     f04:      	movl	$0x1, %eax
     f09:      	callq	*%rax
     f0b:      	testq	%rax, %rax
     f0e:      	je	0x8843 <perf_unwind_dotnet+0x8843>
     f14:      	movq	%rbx, 0x98(%rsp)
     f1c:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
     f26:      	movq	0x8(%rax), %r12
     f2a:      	movq	%r12, %rcx
     f2d:      	andq	%rdx, %rcx
     f30:      	movq	%rcx, 0xf20(%r14)
     f37:      	movq	(%rax), %rax
     f3a:      	movq	%rax, 0xf10(%r14)
     f41:      	shrq	$0x38, %r12
     f45:      	movq	%r13, %rax
     f48:      	subq	%rcx, %rax
     f4b:      	movq	%rax, 0xf18(%r14)
     f52:      	cmpl	$0x0, (%rbp)
     f56:      	jne	0x1391 <perf_unwind_dotnet+0x1391>
     f5c:      	cmpl	$0x1, %r12d
     f60:      	jne	0x1d0e <perf_unwind_dotnet+0x1d0e>
     f66:      	movq	0xf10(%r14), %rax
     f6d:      	movq	%rax, 0x70(%rsp)
     f72:      	movq	0xf18(%r14), %rbx
     f79:      	movq	(%rip), %rdi            # 0xf80 <perf_unwind_dotnet+0xf80>
     f80:      	leaq	0x70(%rsp), %rsi
     f85:      	movl	$0x1, %eax
     f8a:      	callq	*%rax
     f8c:      	movl	$0x1, %r12d
     f92:      	testq	%rax, %rax
     f95:      	je	0x1d0e <perf_unwind_dotnet+0x1d0e>
     f9b:      	cmpq	%rbx, (%rax)
     f9e:      	ja	0xfa6 <perf_unwind_dotnet+0xfa6>
     fa0:      	cmpq	%rbx, 0x8(%rax)
     fa4:      	jae	0xfba <perf_unwind_dotnet+0xfba>
     fa6:      	cmpq	%rbx, 0x10(%rax)
     faa:      	ja	0x1d0e <perf_unwind_dotnet+0x1d0e>
     fb0:      	cmpq	%rbx, 0x18(%rax)
     fb4:      	jb	0x1d0e <perf_unwind_dotnet+0x1d0e>
     fba:      	cmpl	$0x0, (%rbp)
     fbe:      	jne	0x1c5e <perf_unwind_dotnet+0x1c5e>
     fc4:      	movl	0x1380(%r14), %ecx
     fcb:      	movl	0x20(%rax), %edx
     fce:      	btl	%edx, %ecx
     fd1:      	jae	0x1cd1 <perf_unwind_dotnet+0x1cd1>
     fd7:      	cmpl	$0x0, (%rbp)
     fdb:      	je	0x1d0e <perf_unwind_dotnet+0x1d0e>
     fe1:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
     feb:      	movq	%rax, 0x20(%rsp)
     ff0:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
     ffa:      	movq	%rax, 0x18(%rsp)
     fff:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    1009:      	movq	%rax, 0x10(%rsp)
    100e:      	movl	$0xa656e, 0x27(%rsp)    # imm = 0xA656E
    1016:      	leaq	0x10(%rsp), %rdi
    101b:      	movl	$0x1b, %eax
    1020:      	movl	$0x6, %ecx
    1025:      	movl	$0x1b, %esi
    102a:      	xorl	%eax, %eax
    102c:      	callq	*%rcx
    102e:      	jmp	0x1d0e <perf_unwind_dotnet+0x1d0e>
    1033:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    103d:      	movq	%rax, 0x36(%rsp)
    1042:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    104c:      	movq	%rax, 0x30(%rsp)
    1051:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    105b:      	movq	%rax, 0x28(%rsp)
    1060:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    106a:      	movq	%rax, 0x20(%rsp)
    106f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1079:      	movq	%rax, 0x18(%rsp)
    107e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1088:      	movq	%rax, 0x10(%rsp)
    108d:      	leaq	0x10(%rsp), %rdi
    1092:      	movl	$0x2e, %eax
    1097:      	movl	$0x6, %ecx
    109c:      	movl	0xc(%rsp), %edx
    10a0:      	movl	$0x2e, %esi
    10a5:      	xorl	%eax, %eax
    10a7:      	callq	*%rcx
    10a9:      	jmp	0xc51 <perf_unwind_dotnet+0xc51>
    10ae:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    10b8:      	movq	%rax, 0x36(%rsp)
    10bd:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    10c7:      	movq	%rax, 0x30(%rsp)
    10cc:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    10d6:      	movq	%rax, 0x28(%rsp)
    10db:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    10e5:      	movq	%rax, 0x20(%rsp)
    10ea:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    10f4:      	movq	%rax, 0x18(%rsp)
    10f9:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1103:      	movq	%rax, 0x10(%rsp)
    1108:      	leaq	0x10(%rsp), %rdi
    110d:      	movl	$0x2e, %eax
    1112:      	movl	$0x6, %ecx
    1117:      	movl	0xc(%rsp), %edx
    111b:      	movl	$0x2e, %esi
    1120:      	xorl	%eax, %eax
    1122:      	callq	*%rcx
    1124:      	movq	(%rbx), %r13
    1127:      	movl	(%rbp), %eax
    112a:      	testq	%r13, %r13
    112d:      	jne	0xd8a <perf_unwind_dotnet+0xd8a>
    1133:      	jmp	0x2594 <perf_unwind_dotnet+0x2594>
    1138:      	movabsq	$0xa782520797274, %rax  # imm = 0xA782520797274
    1142:      	movq	%rax, 0x3e(%rsp)
    1147:      	movabsq	$0x72746e6520747372, %rax # imm = 0x72746E6520747372
    1151:      	movq	%rax, 0x38(%rsp)
    1156:      	movabsq	$0x6966203a786c2520, %rax # imm = 0x6966203A786C2520
    1160:      	movq	%rax, 0x30(%rsp)
    1165:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    116f:      	movq	%rax, 0x28(%rsp)
    1174:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    117e:      	movq	%rax, 0x20(%rsp)
    1183:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    118d:      	movq	%rax, 0x18(%rsp)
    1192:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    119c:      	movq	%rax, 0x10(%rsp)
    11a1:      	leaq	0x10(%rsp), %rdi
    11a6:      	movl	$0x36, %eax
    11ab:      	movl	$0x6, %r8d
    11b1:      	movl	$0x36, %esi
    11b6:      	movq	%r15, %rdx
    11b9:      	movl	%ebp, %ecx
    11bb:      	xorl	%eax, %eax
    11bd:      	callq	*%r8
    11c0:      	jmp	0x49b <perf_unwind_dotnet+0x49b>
    11c5:      	movabsq	$0xa786c253d7465, %rax  # imm = 0xA786C253D7465
    11cf:      	movq	%rax, 0x36(%rsp)
    11d4:      	movabsq	$0x746572202c78253d, %rax # imm = 0x746572202C78253D
    11de:      	movq	%rax, 0x30(%rsp)
    11e3:      	movabsq	$0x6c6176202c786c25, %rax # imm = 0x6C6176202C786C25
    11ed:      	movq	%rax, 0x28(%rsp)
    11f2:      	movabsq	$0x203d2061746c6564, %rax # imm = 0x203D2061746C6564
    11fc:      	movq	%rax, 0x20(%rsp)
    1201:      	movabsq	$0x5f6370203e2d2d20, %rax # imm = 0x5F6370203E2D2D20
    120b:      	movq	%rax, 0x18(%rsp)
    1210:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    121a:      	movq	%rax, 0x10(%rsp)
    121f:      	leaq	0x10(%rsp), %rdi
    1224:      	movl	$0x2e, %eax
    1229:      	movl	$0x6, %r9d
    122f:      	movl	$0x2e, %esi
    1234:      	movq	%r13, %rdx
    1237:      	movq	%r15, %r8
    123a:      	xorl	%eax, %eax
    123c:      	callq	*%r9
    123f:      	jmp	0xb97 <perf_unwind_dotnet+0xb97>
    1244:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    124e:      	movq	%rax, 0x36(%rsp)
    1253:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    125d:      	movq	%rax, 0x30(%rsp)
    1262:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    126c:      	movq	%rax, 0x28(%rsp)
    1271:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    127b:      	movq	%rax, 0x20(%rsp)
    1280:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    128a:      	movq	%rax, 0x18(%rsp)
    128f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1299:      	movq	%rax, 0x10(%rsp)
    129e:      	leaq	0x10(%rsp), %rdi
    12a3:      	movl	$0x2e, %eax
    12a8:      	movl	$0x6, %ecx
    12ad:      	movl	0xc(%rsp), %edx
    12b1:      	movl	$0x2e, %esi
    12b6:      	xorl	%eax, %eax
    12b8:      	callq	*%rcx
    12ba:      	movl	$0x1772, %edx           # imm = 0x1772
    12bf:      	xorl	%ebx, %ebx
    12c1:      	cmpl	$0x0, (%rbp)
    12c5:      	je	0x511 <perf_unwind_dotnet+0x511>
    12cb:      	jmp	0x1acf <perf_unwind_dotnet+0x1acf>
    12d0:      	movabsq	$0xa6c6c75662073, %rax  # imm = 0xA6C6C75662073
    12da:      	movq	%rax, 0x2d(%rsp)
    12df:      	movabsq	$0x66207369206b6361, %rax # imm = 0x66207369206B6361
    12e9:      	movq	%rax, 0x28(%rsp)
    12ee:      	movabsq	$0x7473203a656d6172, %rax # imm = 0x7473203A656D6172
    12f8:      	movq	%rax, 0x20(%rsp)
    12fd:      	movabsq	$0x662068737570206f, %rax # imm = 0x662068737570206F
    1307:      	movq	%rax, 0x18(%rsp)
    130c:      	movabsq	$0x7420656c62616e75, %rax # imm = 0x7420656C62616E75
    1316:      	movq	%rax, 0x10(%rsp)
    131b:      	leaq	0x10(%rsp), %rdi
    1320:      	movl	$0x25, %eax
    1325:      	movl	$0x6, %ecx
    132a:      	movl	$0x25, %esi
    132f:      	xorl	%eax, %eax
    1331:      	callq	*%rcx
    1333:      	jmp	0x539 <perf_unwind_dotnet+0x539>
    1338:      	movabsq	$0xa726564616568, %rax  # imm = 0xA726564616568
    1342:      	movq	%rax, 0x26(%rsp)
    1347:      	movabsq	$0x65682065646f6320, %rax # imm = 0x65682065646F6320
    1351:      	movq	%rax, 0x20(%rsp)
    1356:      	movabsq	$0x646162203e2d2d20, %rax # imm = 0x646162203E2D2D20
    1360:      	movq	%rax, 0x18(%rsp)
    1365:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    136f:      	movq	%rax, 0x10(%rsp)
    1374:      	leaq	0x10(%rsp), %rdi
    1379:      	movl	$0x1e, %eax
    137e:      	movl	$0x6, %ecx
    1383:      	movl	$0x1e, %esi
    1388:      	xorl	%eax, %eax
    138a:      	callq	*%rcx
    138c:      	jmp	0xbc0 <perf_unwind_dotnet+0xbc0>
    1391:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    139b:      	movq	%rax, 0x38(%rsp)
    13a0:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    13aa:      	movq	%rax, 0x30(%rsp)
    13af:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    13b9:      	movq	%rax, 0x28(%rsp)
    13be:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    13c8:      	movq	%rax, 0x20(%rsp)
    13cd:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    13d7:      	movq	%rax, 0x18(%rsp)
    13dc:      	movabsq	$0x6365732074786554, %rbx # imm = 0x6365732074786554
    13e6:      	movq	%rbx, 0x10(%rsp)
    13eb:      	movw	$0xa, 0x40(%rsp)
    13f2:      	leaq	0x10(%rsp), %rdi
    13f7:      	movl	$0x32, %eax
    13fc:      	movl	$0x6, %r9d
    1402:      	movq	0xf10(%r14), %rcx
    1409:      	movl	$0x32, %esi
    140e:      	movq	%r13, %rdx
    1411:      	movl	%r12d, %r8d
    1414:      	xorl	%eax, %eax
    1416:      	callq	*%r9
    1419:      	cmpl	$0x0, (%rbp)
    141d:      	je	0xf5c <perf_unwind_dotnet+0xf5c>
    1423:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    142d:      	movq	%rax, 0x37(%rsp)
    1432:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    143c:      	movq	%rax, 0x30(%rsp)
    1441:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    144b:      	movq	%rax, 0x28(%rsp)
    1450:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    145a:      	movq	%rax, 0x20(%rsp)
    145f:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    1469:      	movq	%rax, 0x18(%rsp)
    146e:      	movq	%rbx, 0x10(%rsp)
    1473:      	leaq	0x10(%rsp), %rdi
    1478:      	movl	$0x2f, %eax
    147d:      	movl	$0x6, %r8d
    1483:      	movq	0xf18(%r14), %rcx
    148a:      	movq	0xf20(%r14), %rdx
    1491:      	movl	$0x2f, %esi
    1496:      	xorl	%eax, %eax
    1498:      	callq	*%r8
    149b:      	jmp	0xf5c <perf_unwind_dotnet+0xf5c>
    14a0:      	movabsq	$0xa782520797274, %rax  # imm = 0xA782520797274
    14aa:      	movq	%rax, 0x3f(%rsp)
    14af:      	movabsq	$0x746e6520646e6f63, %rax # imm = 0x746E6520646E6F63
    14b9:      	movq	%rax, 0x38(%rsp)
    14be:      	movabsq	$0x6573203a786c2520, %rax # imm = 0x6573203A786C2520
    14c8:      	movq	%rax, 0x30(%rsp)
    14cd:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    14d7:      	movq	%rax, 0x28(%rsp)
    14dc:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    14e6:      	movq	%rax, 0x20(%rsp)
    14eb:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    14f5:      	movq	%rax, 0x18(%rsp)
    14fa:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    1504:      	movq	%rax, 0x10(%rsp)
    1509:      	leaq	0x10(%rsp), %rdi
    150e:      	movl	$0x37, %eax
    1513:      	movl	$0x6, %r8d
    1519:      	movl	$0x37, %esi
    151e:      	movq	%r13, %rdx
    1521:      	movl	%r15d, %ecx
    1524:      	xorl	%eax, %eax
    1526:      	callq	*%r8
    1529:      	xorl	%ecx, %ecx
    152b:      	testl	%r15d, %r15d
    152e:      	jne	0x661 <perf_unwind_dotnet+0x661>
    1534:      	movq	0x1170(%r14), %rax
    153b:      	movl	$0xffffff84, %ecx       # imm = 0xFFFFFF84
    1540:      	testq	%rax, %rax
    1543:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    1549:      	movq	0x1168(%r14), %rax
    1550:      	movl	$0xffffff86, %ecx       # imm = 0xFFFFFF86
    1555:      	testq	%rax, %rax
    1558:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    155e:      	movq	0x1160(%r14), %rax
    1565:      	movl	$0xffffff88, %ecx       # imm = 0xFFFFFF88
    156a:      	testq	%rax, %rax
    156d:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    1573:      	movq	0x1158(%r14), %rax
    157a:      	movl	$0xffffff8a, %ecx       # imm = 0xFFFFFF8A
    157f:      	testq	%rax, %rax
    1582:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    1588:      	movq	0x1150(%r14), %rax
    158f:      	movl	$0xffffff8c, %ecx       # imm = 0xFFFFFF8C
    1594:      	testq	%rax, %rax
    1597:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    159d:      	movq	0x1148(%r14), %rax
    15a4:      	movl	$0xffffff8e, %ecx       # imm = 0xFFFFFF8E
    15a9:      	testq	%rax, %rax
    15ac:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    15b2:      	movq	0x1140(%r14), %rax
    15b9:      	movl	$0xffffff90, %ecx       # imm = 0xFFFFFF90
    15be:      	testq	%rax, %rax
    15c1:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    15c7:      	movq	0x1138(%r14), %rax
    15ce:      	movl	$0xffffff92, %ecx       # imm = 0xFFFFFF92
    15d3:      	testq	%rax, %rax
    15d6:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    15dc:      	movq	0x1130(%r14), %rax
    15e3:      	movl	$0xffffff94, %ecx       # imm = 0xFFFFFF94
    15e8:      	testq	%rax, %rax
    15eb:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    15f1:      	movq	0x1128(%r14), %rax
    15f8:      	movl	$0xffffff96, %ecx       # imm = 0xFFFFFF96
    15fd:      	testq	%rax, %rax
    1600:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    1606:      	movq	0x1120(%r14), %rax
    160d:      	movl	$0xffffff98, %ecx       # imm = 0xFFFFFF98
    1612:      	testq	%rax, %rax
    1615:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    161b:      	movq	0x1118(%r14), %rax
    1622:      	movl	$0xffffff9a, %ecx       # imm = 0xFFFFFF9A
    1627:      	testq	%rax, %rax
    162a:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    1630:      	movq	0x1110(%r14), %rax
    1637:      	movl	$0xffffff9c, %ecx       # imm = 0xFFFFFF9C
    163c:      	testq	%rax, %rax
    163f:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    1645:      	movq	0x1108(%r14), %rax
    164c:      	movl	$0xffffff9e, %ecx       # imm = 0xFFFFFF9E
    1651:      	testq	%rax, %rax
    1654:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    165a:      	movq	0x1100(%r14), %rax
    1661:      	movl	$0xffffffa0, %ecx       # imm = 0xFFFFFFA0
    1666:      	testq	%rax, %rax
    1669:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    166f:      	movq	0x10f8(%r14), %rax
    1676:      	movl	$0xffffffa2, %ecx       # imm = 0xFFFFFFA2
    167b:      	testq	%rax, %rax
    167e:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    1684:      	movq	0x10f0(%r14), %rax
    168b:      	movl	$0xffffffa4, %ecx       # imm = 0xFFFFFFA4
    1690:      	testq	%rax, %rax
    1693:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    1699:      	movq	0x10e8(%r14), %rax
    16a0:      	movl	$0xffffffa6, %ecx       # imm = 0xFFFFFFA6
    16a5:      	testq	%rax, %rax
    16a8:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    16ae:      	movq	0x10e0(%r14), %rax
    16b5:      	movl	$0xffffffa8, %ecx       # imm = 0xFFFFFFA8
    16ba:      	testq	%rax, %rax
    16bd:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    16c3:      	movq	0x10d8(%r14), %rax
    16ca:      	movl	$0xffffffaa, %ecx       # imm = 0xFFFFFFAA
    16cf:      	testq	%rax, %rax
    16d2:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    16d8:      	movq	0x10d0(%r14), %rax
    16df:      	movl	$0xffffffac, %ecx       # imm = 0xFFFFFFAC
    16e4:      	testq	%rax, %rax
    16e7:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    16ed:      	movq	0x10c8(%r14), %rax
    16f4:      	movl	$0xffffffae, %ecx       # imm = 0xFFFFFFAE
    16f9:      	testq	%rax, %rax
    16fc:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    1702:      	movq	0x10c0(%r14), %rax
    1709:      	movl	$0xffffffb0, %ecx       # imm = 0xFFFFFFB0
    170e:      	testq	%rax, %rax
    1711:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    1717:      	movq	0x10b8(%r14), %rax
    171e:      	movl	$0xffffffb2, %ecx       # imm = 0xFFFFFFB2
    1723:      	testq	%rax, %rax
    1726:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    172c:      	movq	0x10b0(%r14), %rax
    1733:      	movl	$0xffffffb4, %ecx       # imm = 0xFFFFFFB4
    1738:      	testq	%rax, %rax
    173b:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    1741:      	movq	0x10a8(%r14), %rax
    1748:      	movl	$0xffffffb6, %ecx       # imm = 0xFFFFFFB6
    174d:      	testq	%rax, %rax
    1750:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    1756:      	movq	0x10a0(%r14), %rax
    175d:      	movl	$0xffffffb8, %ecx       # imm = 0xFFFFFFB8
    1762:      	testq	%rax, %rax
    1765:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    176b:      	movq	0x1098(%r14), %rax
    1772:      	movl	$0xffffffba, %ecx       # imm = 0xFFFFFFBA
    1777:      	testq	%rax, %rax
    177a:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    1780:      	movq	0x1090(%r14), %rax
    1787:      	movl	$0xffffffbc, %ecx       # imm = 0xFFFFFFBC
    178c:      	testq	%rax, %rax
    178f:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    1795:      	movq	0x1088(%r14), %rax
    179c:      	movl	$0xffffffbe, %ecx       # imm = 0xFFFFFFBE
    17a1:      	testq	%rax, %rax
    17a4:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    17aa:      	movq	0x1080(%r14), %rax
    17b1:      	movl	$0xffffffc0, %ecx       # imm = 0xFFFFFFC0
    17b6:      	testq	%rax, %rax
    17b9:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    17bf:      	movq	0x1078(%r14), %rax
    17c6:      	movl	$0xffffffc2, %ecx       # imm = 0xFFFFFFC2
    17cb:      	testq	%rax, %rax
    17ce:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    17d4:      	movq	0x1070(%r14), %rax
    17db:      	movl	$0xffffffc4, %ecx       # imm = 0xFFFFFFC4
    17e0:      	testq	%rax, %rax
    17e3:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    17e9:      	movq	0x1068(%r14), %rax
    17f0:      	movl	$0xffffffc6, %ecx       # imm = 0xFFFFFFC6
    17f5:      	testq	%rax, %rax
    17f8:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    17fe:      	movq	0x1060(%r14), %rax
    1805:      	movl	$0xffffffc8, %ecx       # imm = 0xFFFFFFC8
    180a:      	testq	%rax, %rax
    180d:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    1813:      	movq	0x1058(%r14), %rax
    181a:      	movl	$0xffffffca, %ecx       # imm = 0xFFFFFFCA
    181f:      	testq	%rax, %rax
    1822:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    1828:      	movq	0x1050(%r14), %rax
    182f:      	movl	$0xffffffcc, %ecx       # imm = 0xFFFFFFCC
    1834:      	testq	%rax, %rax
    1837:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    183d:      	movq	0x1048(%r14), %rax
    1844:      	movl	$0xffffffce, %ecx       # imm = 0xFFFFFFCE
    1849:      	testq	%rax, %rax
    184c:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    1852:      	movq	0x1040(%r14), %rax
    1859:      	movl	$0xffffffd0, %ecx       # imm = 0xFFFFFFD0
    185e:      	testq	%rax, %rax
    1861:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    1867:      	movq	0x1038(%r14), %rax
    186e:      	movl	$0xffffffd2, %ecx       # imm = 0xFFFFFFD2
    1873:      	testq	%rax, %rax
    1876:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    187c:      	movq	0x1030(%r14), %rax
    1883:      	movl	$0xffffffd4, %ecx       # imm = 0xFFFFFFD4
    1888:      	testq	%rax, %rax
    188b:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    1891:      	movq	0x1028(%r14), %rax
    1898:      	movl	$0xffffffd6, %ecx       # imm = 0xFFFFFFD6
    189d:      	testq	%rax, %rax
    18a0:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    18a6:      	movq	0x1020(%r14), %rax
    18ad:      	movl	$0xffffffd8, %ecx       # imm = 0xFFFFFFD8
    18b2:      	testq	%rax, %rax
    18b5:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    18bb:      	movq	0x1018(%r14), %rax
    18c2:      	movl	$0xffffffda, %ecx       # imm = 0xFFFFFFDA
    18c7:      	testq	%rax, %rax
    18ca:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    18d0:      	movq	0x1010(%r14), %rax
    18d7:      	movl	$0xffffffdc, %ecx       # imm = 0xFFFFFFDC
    18dc:      	testq	%rax, %rax
    18df:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    18e5:      	movq	0x1008(%r14), %rax
    18ec:      	movl	$0xffffffde, %ecx       # imm = 0xFFFFFFDE
    18f1:      	testq	%rax, %rax
    18f4:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    18fa:      	movq	0x1000(%r14), %rax
    1901:      	movl	$0xffffffe0, %ecx       # imm = 0xFFFFFFE0
    1906:      	testq	%rax, %rax
    1909:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    190f:      	movq	0xff8(%r14), %rax
    1916:      	movl	$0xffffffe2, %ecx       # imm = 0xFFFFFFE2
    191b:      	testq	%rax, %rax
    191e:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    1924:      	movq	0xff0(%r14), %rax
    192b:      	movl	$0xffffffe4, %ecx       # imm = 0xFFFFFFE4
    1930:      	testq	%rax, %rax
    1933:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    1939:      	movq	0xfe8(%r14), %rax
    1940:      	movl	$0xffffffe6, %ecx       # imm = 0xFFFFFFE6
    1945:      	testq	%rax, %rax
    1948:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    194e:      	movq	0xfe0(%r14), %rax
    1955:      	movl	$0xffffffe8, %ecx       # imm = 0xFFFFFFE8
    195a:      	testq	%rax, %rax
    195d:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    1963:      	movq	0xfd8(%r14), %rax
    196a:      	movl	$0xffffffea, %ecx       # imm = 0xFFFFFFEA
    196f:      	testq	%rax, %rax
    1972:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    1978:      	movq	0xfd0(%r14), %rax
    197f:      	movl	$0xffffffec, %ecx       # imm = 0xFFFFFFEC
    1984:      	testq	%rax, %rax
    1987:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    198d:      	movq	0xfc8(%r14), %rax
    1994:      	movl	$0xffffffee, %ecx       # imm = 0xFFFFFFEE
    1999:      	testq	%rax, %rax
    199c:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    19a2:      	movq	0xfc0(%r14), %rax
    19a9:      	movl	$0xfffffff0, %ecx       # imm = 0xFFFFFFF0
    19ae:      	testq	%rax, %rax
    19b1:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    19b7:      	movq	0xfb8(%r14), %rax
    19be:      	movl	$0xfffffff2, %ecx       # imm = 0xFFFFFFF2
    19c3:      	testq	%rax, %rax
    19c6:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    19c8:      	movq	0xfb0(%r14), %rax
    19cf:      	movl	$0xfffffff4, %ecx       # imm = 0xFFFFFFF4
    19d4:      	testq	%rax, %rax
    19d7:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    19d9:      	movq	0xfa8(%r14), %rax
    19e0:      	movl	$0xfffffff6, %ecx       # imm = 0xFFFFFFF6
    19e5:      	testq	%rax, %rax
    19e8:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    19ea:      	movq	0xfa0(%r14), %rax
    19f1:      	movl	$0xfffffff8, %ecx       # imm = 0xFFFFFFF8
    19f6:      	testq	%rax, %rax
    19f9:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    19fb:      	movq	0xf98(%r14), %rax
    1a02:      	movl	$0xfffffffa, %ecx       # imm = 0xFFFFFFFA
    1a07:      	testq	%rax, %rax
    1a0a:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    1a0c:      	movq	0xf90(%r14), %rax
    1a13:      	movl	$0xfffffffc, %ecx       # imm = 0xFFFFFFFC
    1a18:      	testq	%rax, %rax
    1a1b:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    1a1d:      	movq	0xf88(%r14), %rax
    1a24:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1a29:      	testq	%rax, %rax
    1a2c:      	jne	0x1a3b <perf_unwind_dotnet+0x1a3b>
    1a2e:      	movq	0x90(%rsp), %rax
    1a36:      	movq	(%rax), %rax
    1a39:      	xorl	%ecx, %ecx
    1a3b:      	xorl	%edx, %edx
    1a3d:      	movq	%rax, %r15
    1a40:      	shrq	$0x20, %r15
    1a44:      	setne	%dl
    1a47:      	cmovel	%eax, %r15d
    1a4b:      	subl	%edx, %ecx
    1a4d:      	addl	$0x7e, %ecx
    1a50:      	movl	%ecx, %eax
    1a52:      	shll	$0x8, %eax
    1a55:      	subq	%rax, %r13
    1a58:      	jb	0x66f <perf_unwind_dotnet+0x66f>
    1a5e:      	cmpl	$0x0, (%rbp)
    1a62:      	jne	0x1b44 <perf_unwind_dotnet+0x1b44>
    1a68:      	testl	%r15d, %r15d
    1a6b:      	jne	0x4d2 <perf_unwind_dotnet+0x4d2>
    1a71:      	movl	$0x5f, 0xc(%rsp)
    1a79:      	movq	(%rip), %rdi            # 0x1a80 <perf_unwind_dotnet+0x1a80>
    1a80:      	leaq	0xc(%rsp), %rsi
    1a85:      	movl	$0x1, %eax
    1a8a:      	callq	*%rax
    1a8c:      	movq	%rbx, %r12
    1a8f:      	testq	%rax, %rax
    1a92:      	je	0x1aaf <perf_unwind_dotnet+0x1aaf>
    1a94:      	incq	(%rax)
    1a97:      	movq	0x60(%rsp), %r15
    1a9c:      	movl	$0x1773, %edx           # imm = 0x1773
    1aa1:      	movb	$0x1, %bl
    1aa3:      	cmpl	$0x0, (%rbp)
    1aa7:      	je	0x511 <perf_unwind_dotnet+0x511>
    1aad:      	jmp	0x1acf <perf_unwind_dotnet+0x1acf>
    1aaf:      	cmpl	$0x0, (%rbp)
    1ab3:      	movq	0x60(%rsp), %r15
    1ab8:      	jne	0x21de <perf_unwind_dotnet+0x21de>
    1abe:      	movl	$0x1773, %edx           # imm = 0x1773
    1ac3:      	movb	$0x1, %bl
    1ac5:      	cmpl	$0x0, (%rbp)
    1ac9:      	je	0x511 <perf_unwind_dotnet+0x511>
    1acf:      	movabsq	$0xa642520687469, %rax  # imm = 0xA642520687469
    1ad9:      	movq	%rax, 0x30(%rsp)
    1ade:      	movabsq	$0x772064656c696166, %rax # imm = 0x772064656C696166
    1ae8:      	movq	%rax, 0x28(%rsp)
    1aed:      	movabsq	$0x2074726174735f65, %rax # imm = 0x2074726174735F65
    1af7:      	movq	%rax, 0x20(%rsp)
    1afc:      	movabsq	$0x646f63203e2d2d20, %rax # imm = 0x646F63203E2D2D20
    1b06:      	movq	%rax, 0x18(%rsp)
    1b0b:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    1b15:      	movq	%rax, 0x10(%rsp)
    1b1a:      	leaq	0x10(%rsp), %rdi
    1b1f:      	movl	$0x28, %eax
    1b24:      	movl	$0x6, %ecx
    1b29:      	movl	$0x28, %esi
    1b2e:      	xorl	%eax, %eax
    1b30:      	callq	*%rcx
    1b32:      	movl	$0x1772, %eax           # imm = 0x1772
    1b37:      	testb	%bl, %bl
    1b39:      	jne	0x51e <perf_unwind_dotnet+0x51e>
    1b3f:      	jmp	0x7812 <perf_unwind_dotnet+0x7812>
    1b44:      	movabsq	$0x207972746e65202c, %rax # imm = 0x207972746E65202C
    1b4e:      	movq	%rax, 0x40(%rsp)
    1b53:      	movabsq	$0x6425206465707069, %rax # imm = 0x6425206465707069
    1b5d:      	movq	%rax, 0x38(%rsp)
    1b62:      	movabsq	$0x6b73203a786c2520, %rax # imm = 0x6B73203A786C2520
    1b6c:      	movq	%rax, 0x30(%rsp)
    1b71:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    1b7b:      	movq	%rax, 0x28(%rsp)
    1b80:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    1b8a:      	movq	%rax, 0x20(%rsp)
    1b8f:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    1b99:      	movq	%rax, 0x18(%rsp)
    1b9e:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    1ba8:      	movq	%rax, 0x10(%rsp)
    1bad:      	movl	$0xa7825, 0x48(%rsp)    # imm = 0xA7825
    1bb5:      	leaq	0x10(%rsp), %rdi
    1bba:      	movl	$0x3c, %eax
    1bbf:      	movl	$0x6, %r9d
    1bc5:      	movl	$0x3c, %esi
    1bca:      	movq	%r13, %rdx
    1bcd:      	movl	%r15d, %r8d
    1bd0:      	xorl	%eax, %eax
    1bd2:      	callq	*%r9
    1bd5:      	testl	%r15d, %r15d
    1bd8:      	jne	0x4d2 <perf_unwind_dotnet+0x4d2>
    1bde:      	jmp	0x1a71 <perf_unwind_dotnet+0x1a71>
    1be3:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1bed:      	movq	%rax, 0x36(%rsp)
    1bf2:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1bfc:      	movq	%rax, 0x30(%rsp)
    1c01:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1c0b:      	movq	%rax, 0x28(%rsp)
    1c10:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1c1a:      	movq	%rax, 0x20(%rsp)
    1c1f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1c29:      	movq	%rax, 0x18(%rsp)
    1c2e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1c38:      	movq	%rax, 0x10(%rsp)
    1c3d:      	leaq	0x10(%rsp), %rdi
    1c42:      	movl	$0x2e, %eax
    1c47:      	movl	$0x6, %ecx
    1c4c:      	movl	0xc(%rsp), %edx
    1c50:      	movl	$0x2e, %esi
    1c55:      	xorl	%eax, %eax
    1c57:      	callq	*%rcx
    1c59:      	jmp	0xc65 <perf_unwind_dotnet+0xc65>
    1c5e:      	movabsq	$0xa642520686374, %rcx  # imm = 0xA642520686374
    1c68:      	movq	%rcx, 0x26(%rsp)
    1c6d:      	movabsq	$0x6374616d20737465, %rcx # imm = 0x6374616D20737465
    1c77:      	movq	%rcx, 0x20(%rsp)
    1c7c:      	movabsq	$0x7366666f5f726574, %rcx # imm = 0x7366666F5F726574
    1c86:      	movq	%rcx, 0x18(%rsp)
    1c8b:      	movabsq	$0x6572707265746e69, %rcx # imm = 0x6572707265746E69
    1c95:      	movq	%rcx, 0x10(%rsp)
    1c9a:      	leaq	0x10(%rsp), %rdi
    1c9f:      	movl	$0x1e, %ecx
    1ca4:      	movl	$0x6, %r8d
    1caa:      	movzwl	0x20(%rax), %edx
    1cae:      	movl	$0x1e, %esi
    1cb3:      	movq	%rax, %rbx
    1cb6:      	xorl	%eax, %eax
    1cb8:      	callq	*%r8
    1cbb:      	movq	%rbx, %rax
    1cbe:      	movl	0x1380(%r14), %ecx
    1cc5:      	movl	0x20(%rax), %edx
    1cc8:      	btl	%edx, %ecx
    1ccb:      	jb	0xfd7 <perf_unwind_dotnet+0xfd7>
    1cd1:      	movq	%rax, %rbx
    1cd4:      	movl	$0x0, 0x68(%rsp)
    1cdc:      	movq	(%rip), %rdi            # 0x1ce3 <perf_unwind_dotnet+0x1ce3>
    1ce3:      	leaq	0x68(%rsp), %rsi
    1ce8:      	movl	$0x1, %eax
    1ced:      	callq	*%rax
    1cef:      	testq	%rax, %rax
    1cf2:      	je	0x1cfc <perf_unwind_dotnet+0x1cfc>
    1cf4:      	incq	(%rax)
    1cf7:      	movq	%rbx, %rax
    1cfa:      	jmp	0x1d09 <perf_unwind_dotnet+0x1d09>
    1cfc:      	cmpl	$0x0, (%rbp)
    1d00:      	movq	%rbx, %rax
    1d03:      	jne	0x2353 <perf_unwind_dotnet+0x2353>
    1d09:      	movzwl	0x20(%rax), %r12d
    1d0e:      	xorl	%eax, %eax
    1d10:      	cmpl	$0x8, %r12d
    1d14:      	jne	0x7815 <perf_unwind_dotnet+0x7815>
    1d1a:      	movq	0xed0(%r14), %r12
    1d21:      	movq	0xed8(%r14), %rbx
    1d28:      	movq	0xee0(%r14), %r13
    1d2f:      	movzbl	0xf30(%r14), %ecx
    1d37:      	cmpl	$0x0, (%rbp)
    1d3b:      	jne	0x2136 <perf_unwind_dotnet+0x2136>
    1d41:      	cmpq	%rbx, %r13
    1d44:      	jb	0x77c0 <perf_unwind_dotnet+0x77c0>
    1d4a:      	leaq	0x2000(%rbx), %rax
    1d51:      	cmpq	%rax, %r13
    1d54:      	jae	0x77c0 <perf_unwind_dotnet+0x77c0>
    1d5a:      	movl	%ecx, %ebx
    1d5c:      	movq	0xf10(%r14), %rbp
    1d63:      	movq	0xf20(%r14), %r15
    1d6a:      	movq	%r12, 0x68(%rsp)
    1d6f:      	movb	$0x1, 0xf30(%r14)
    1d77:      	movq	%rbp, %rax
    1d7a:      	andq	$-0x80, %rax
    1d7e:      	cmpq	$0x80, %rax
    1d84:      	jne	0x1dc8 <perf_unwind_dotnet+0x1dc8>
    1d86:      	movq	0xed8(%r14), %rax
    1d8d:      	movl	$0x8, %ecx
    1d92:      	movl	$0x70, %r8d
    1d98:      	movq	0x98(%rsp), %rdi
    1da0:      	movq	0xed8(%r14), %rdx
    1da7:      	movl	$0x8, %esi
    1dac:      	callq	*%r8
    1daf:      	testq	%rax, %rax
    1db2:      	jne	0x19c <perf_unwind_dotnet+0x19c>
    1db8:      	addq	$0x8, 0xed8(%r14)
    1dc0:      	andl	$0x7f, %ebp
    1dc3:      	jmp	0x2431 <perf_unwind_dotnet+0x2431>
    1dc8:      	leaq	0x70(%rsp), %rdi
    1dcd:      	movl	$0x10, %eax
    1dd2:      	movl	$0x70, %ecx
    1dd7:      	movl	$0x10, %esi
    1ddc:      	movq	%r13, %rdx
    1ddf:      	callq	*%rcx
    1de1:      	testq	%rax, %rax
    1de4:      	jne	0x26c <perf_unwind_dotnet+0x26c>
    1dea:      	addq	$0x10, %r13
    1dee:      	movq	%r13, 0xed8(%r14)
    1df5:      	movq	0x70(%rsp), %rax
    1dfa:      	movq	%rax, 0xee0(%r14)
    1e01:      	movq	0x78(%rsp), %rax
    1e06:      	movq	%rax, 0xed0(%r14)
    1e0d:      	movq	(%rip), %rax            # 0x1e14 <perf_unwind_dotnet+0x1e14>
    1e14:      	cmpl	$0x0, (%rax)
    1e17:      	jne	0x226a <perf_unwind_dotnet+0x226a>
    1e1d:      	cmpq	$0x100, %rbp            # imm = 0x100
    1e24:      	jb	0x2431 <perf_unwind_dotnet+0x2431>
    1e2a:      	movq	0xf10(%r14), %rbp
    1e31:      	movq	0xf20(%r14), %rax
    1e38:      	movq	%r12, %r13
    1e3b:      	movq	%rax, 0x88(%rsp)
    1e43:      	subq	%rax, %r13
    1e46:      	movq	(%rip), %rax            # 0x1e4d <perf_unwind_dotnet+0x1e4d>
    1e4d:      	cmpl	$0x0, (%rax)
    1e50:      	jne	0x230a <perf_unwind_dotnet+0x230a>
    1e56:      	movq	%r13, %r15
    1e59:      	andq	$-0x4, %r15
    1e5d:      	movl	$0x100, %ecx            # imm = 0x100
    1e62:      	movq	%r15, %rax
    1e65:      	xorl	%edx, %edx
    1e67:      	divq	%rcx
    1e6a:      	movq	%rax, %rcx
    1e6d:      	movl	$0x7f, %eax
    1e72:      	subq	%rcx, %rax
    1e75:      	jns	0x1e8e <perf_unwind_dotnet+0x1e8e>
    1e77:      	movl	$0x100, %ecx            # imm = 0x100
    1e7c:      	movq	%r15, %rax
    1e7f:      	xorl	%edx, %edx
    1e81:      	divq	%rcx
    1e84:      	leaq	-0x3fc(%rbp,%rax,4), %rbp
    1e8c:      	xorl	%eax, %eax
    1e8e:      	movl	$0x80, %ecx
    1e93:      	cqto
    1e95:      	idivq	%rcx
    1e98:      	movq	0x90(%rsp), %rax
    1ea0:      	leaq	(%rax,%rdx,4), %rdi
    1ea4:      	movl	$0x200, %eax            # imm = 0x200
    1ea9:      	movl	$0x70, %ecx
    1eae:      	movl	$0x200, %esi            # imm = 0x200
    1eb3:      	movq	%rbp, %rdx
    1eb6:      	callq	*%rcx
    1eb8:      	testq	%rax, %rax
    1ebb:      	je	0x1ef2 <perf_unwind_dotnet+0x1ef2>
    1ebd:      	movq	(%rip), %rax            # 0x1ec4 <perf_unwind_dotnet+0x1ec4>
    1ec4:      	cmpl	$0x0, (%rax)
    1ec7:      	jne	0x20c7 <perf_unwind_dotnet+0x20c7>
    1ecd:      	movl	$0x5e, 0xc(%rsp)
    1ed5:      	movq	(%rip), %rdi            # 0x1edc <perf_unwind_dotnet+0x1edc>
    1edc:      	leaq	0xc(%rsp), %rsi
    1ee1:      	movl	$0x1, %eax
    1ee6:      	callq	*%rax
    1ee8:      	testq	%rax, %rax
    1eeb:      	je	0x1f5d <perf_unwind_dotnet+0x1f5d>
    1eed:      	incq	(%rax)
    1ef0:      	jmp	0x1f6d <perf_unwind_dotnet+0x1f6d>
    1ef2:      	movl	0x117c(%r14), %ebp
    1ef9:      	movq	(%rip), %rax            # 0x1f00 <perf_unwind_dotnet+0x1f00>
    1f00:      	cmpl	$0x0, (%rax)
    1f03:      	jne	0x28ff <perf_unwind_dotnet+0x28ff>
    1f09:      	movl	$0x20, %ecx
    1f0e:      	movq	%r15, %rax
    1f11:      	xorl	%edx, %edx
    1f13:      	divq	%rcx
    1f16:      	movl	$0x8, %ecx
    1f1b:      	xorl	%edx, %edx
    1f1d:      	divq	%rcx
    1f20:      	shll	$0x2, %edx
    1f23:      	movb	$0x1c, %al
    1f25:      	subb	%dl, %al
    1f27:      	shrxl	%eax, %ebp, %r15d
    1f2c:      	testl	%r15d, %r15d
    1f2f:      	je	0x1ffa <perf_unwind_dotnet+0x1ffa>
    1f35:      	andq	$-0x20, %r13
    1f39:      	movl	%r15d, %ecx
    1f3c:      	andl	$0xf, %ecx
    1f3f:      	jne	0x23dc <perf_unwind_dotnet+0x23dc>
    1f45:      	movl	%r15d, %ecx
    1f48:      	shrl	$0x4, %ecx
    1f4b:      	andl	$0xf, %ecx
    1f4e:      	je	0x210a <perf_unwind_dotnet+0x210a>
    1f54:      	addq	$-0x20, %r13
    1f58:      	jmp	0x23dc <perf_unwind_dotnet+0x23dc>
    1f5d:      	movq	(%rip), %rax            # 0x1f64 <perf_unwind_dotnet+0x1f64>
    1f64:      	cmpl	$0x0, (%rax)
    1f67:      	jne	0x2a0b <perf_unwind_dotnet+0x2a0b>
    1f6d:      	movl	$0x1772, %edx           # imm = 0x1772
    1f72:      	xorl	%ebx, %ebx
    1f74:      	movq	(%rip), %rax            # 0x1f7b <perf_unwind_dotnet+0x1f7b>
    1f7b:      	cmpl	$0x0, (%rax)
    1f7e:      	jne	0x31be <perf_unwind_dotnet+0x31be>
    1f84:      	movl	$0x1772, %eax           # imm = 0x1772
    1f89:      	testb	%bl, %bl
    1f8b:      	movq	0x60(%rsp), %r15
    1f90:      	movq	(%rip), %rbp            # 0x1f97 <perf_unwind_dotnet+0x1f97>
    1f97:      	je	0x7812 <perf_unwind_dotnet+0x7812>
    1f9d:      	movl	0x2c0(%r14), %eax
    1fa4:      	cmpq	$0x7e, %rax
    1fa8:      	ja	0x52f <perf_unwind_dotnet+0x52f>
    1fae:      	leal	0x1(%rax), %ecx
    1fb1:      	movl	%ecx, 0x2c0(%r14)
    1fb8:      	leaq	(%rax,%rax,2), %rax
    1fbc:      	movq	$0x0, 0x2d0(%r14,%rax,8)
    1fc8:      	movq	$0x1773, 0x2d8(%r14,%rax,8) # imm = 0x1773
    1fd4:      	movb	$-0x76, 0x2e0(%r14,%rax,8)
    1fdd:      	movl	$0x0, 0x2e1(%r14,%rax,8)
    1fe9:      	movl	$0x0, 0x2e4(%r14,%rax,8)
    1ff5:      	jmp	0x24e4 <perf_unwind_dotnet+0x24e4>
    1ffa:      	andq	$-0x100, %r13
    2001:      	addq	$-0x20, %r13
    2005:      	movl	0x1178(%r14), %r15d
    200c:      	movq	(%rip), %rax            # 0x2013 <perf_unwind_dotnet+0x2013>
    2013:      	cmpl	$0x0, (%rax)
    2016:      	jne	0x2b9b <perf_unwind_dotnet+0x2b9b>
    201c:      	xorl	%ecx, %ecx
    201e:      	testl	%r15d, %r15d
    2021:      	je	0x2c2f <perf_unwind_dotnet+0x2c2f>
    2027:      	movl	%ecx, %eax
    2029:      	shll	$0x8, %eax
    202c:      	subq	%rax, %r13
    202f:      	jae	0x3159 <perf_unwind_dotnet+0x3159>
    2035:      	movq	(%rip), %rax            # 0x203c <perf_unwind_dotnet+0x203c>
    203c:      	cmpl	$0x0, (%rax)
    203f:      	je	0x1ecd <perf_unwind_dotnet+0x1ecd>
    2045:      	movabsq	$0xa657361625f63, %rax  # imm = 0xA657361625F63
    204f:      	movq	%rax, 0x36(%rsp)
    2054:      	movabsq	$0x5f637020776f6c65, %rax # imm = 0x5F637020776F6C65
    205e:      	movq	%rax, 0x30(%rsp)
    2063:      	movabsq	$0x6220746e65772068, %rax # imm = 0x6220746E65772068
    206d:      	movq	%rax, 0x28(%rsp)
    2072:      	movabsq	$0x6372616573207061, %rax # imm = 0x6372616573207061
    207c:      	movq	%rax, 0x20(%rsp)
    2081:      	movabsq	$0x6d20656c6262696e, %rax # imm = 0x6D20656C6262696E
    208b:      	movq	%rax, 0x18(%rsp)
    2090:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    209a:      	movq	%rax, 0x10(%rsp)
    209f:      	leaq	0x10(%rsp), %rdi
    20a4:      	movl	$0x2e, %eax
    20a9:      	movl	$0x6, %ecx
    20ae:      	movl	$0x2e, %esi
    20b3:      	xorl	%eax, %eax
    20b5:      	callq	*%rcx
    20b7:      	movq	(%rip), %rax            # 0x20be <perf_unwind_dotnet+0x20be>
    20be:      	cmpl	$0x0, (%rax)
    20c1:      	je	0x1ecd <perf_unwind_dotnet+0x1ecd>
    20c7:      	movabsq	$0x6e756f6620746f6e, %rax # imm = 0x6E756F6620746F6E
    20d1:      	movq	%rax, 0x18(%rsp)
    20d6:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    20e0:      	movq	%rax, 0x10(%rsp)
    20e5:      	movl	$0xa646e, 0x1f(%rsp)    # imm = 0xA646E
    20ed:      	leaq	0x10(%rsp), %rdi
    20f2:      	movl	$0x13, %eax
    20f7:      	movl	$0x6, %ecx
    20fc:      	movl	$0x13, %esi
    2101:      	xorl	%eax, %eax
    2103:      	callq	*%rcx
    2105:      	jmp	0x1ecd <perf_unwind_dotnet+0x1ecd>
    210a:      	movl	%r15d, %ecx
    210d:      	shrl	$0x8, %ecx
    2110:      	andl	$0xf, %ecx
    2113:      	je	0x211e <perf_unwind_dotnet+0x211e>
    2115:      	addq	$-0x40, %r13
    2119:      	jmp	0x23dc <perf_unwind_dotnet+0x23dc>
    211e:      	movl	%r15d, %ecx
    2121:      	shrl	$0xc, %ecx
    2124:      	andl	$0xf, %ecx
    2127:      	je	0x21af <perf_unwind_dotnet+0x21af>
    212d:      	addq	$-0x60, %r13
    2131:      	jmp	0x23dc <perf_unwind_dotnet+0x23dc>
    2136:      	movabsq	$0x6c25203a7066202c, %rax # imm = 0x6C25203A7066202C
    2140:      	movq	%rax, 0x28(%rsp)
    2145:      	movabsq	$0x786c25203a707320, %rax # imm = 0x786C25203A707320
    214f:      	movq	%rax, 0x20(%rsp)
    2154:      	movabsq	$0x2c786c25203a6370, %rax # imm = 0x2C786C25203A6370
    215e:      	movq	%rax, 0x18(%rsp)
    2163:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    216d:      	movq	%rax, 0x10(%rsp)
    2172:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    217a:      	leaq	0x10(%rsp), %rdi
    217f:      	movl	$0x23, %eax
    2184:      	movl	$0x6, %r9d
    218a:      	movl	$0x23, %esi
    218f:      	movq	%r12, %rdx
    2192:      	movl	%ecx, %ebp
    2194:      	movq	%rbx, %rcx
    2197:      	movq	%r13, %r8
    219a:      	xorl	%eax, %eax
    219c:      	callq	*%r9
    219f:      	movl	%ebp, %ecx
    21a1:      	cmpq	%rbx, %r13
    21a4:      	jae	0x1d4a <perf_unwind_dotnet+0x1d4a>
    21aa:      	jmp	0x77c0 <perf_unwind_dotnet+0x77c0>
    21af:      	movl	%r15d, %ecx
    21b2:      	shrl	$0x10, %ecx
    21b5:      	andl	$0xf, %ecx
    21b8:      	je	0x21c3 <perf_unwind_dotnet+0x21c3>
    21ba:      	addq	$-0x80, %r13
    21be:      	jmp	0x23dc <perf_unwind_dotnet+0x23dc>
    21c3:      	movl	%r15d, %ecx
    21c6:      	shrl	$0x14, %ecx
    21c9:      	andl	$0xf, %ecx
    21cc:      	je	0x22ef <perf_unwind_dotnet+0x22ef>
    21d2:      	addq	$-0xa0, %r13
    21d9:      	jmp	0x23dc <perf_unwind_dotnet+0x23dc>
    21de:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    21e8:      	movq	%rax, 0x36(%rsp)
    21ed:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    21f7:      	movq	%rax, 0x30(%rsp)
    21fc:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2206:      	movq	%rax, 0x28(%rsp)
    220b:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2215:      	movq	%rax, 0x20(%rsp)
    221a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2224:      	movq	%rax, 0x18(%rsp)
    2229:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2233:      	movq	%rax, 0x10(%rsp)
    2238:      	leaq	0x10(%rsp), %rdi
    223d:      	movl	$0x2e, %eax
    2242:      	movl	$0x6, %ecx
    2247:      	movl	0xc(%rsp), %edx
    224b:      	movl	$0x2e, %esi
    2250:      	xorl	%eax, %eax
    2252:      	callq	*%rcx
    2254:      	movl	$0x1773, %edx           # imm = 0x1773
    2259:      	movb	$0x1, %bl
    225b:      	cmpl	$0x0, (%rbp)
    225f:      	je	0x511 <perf_unwind_dotnet+0x511>
    2265:      	jmp	0x1acf <perf_unwind_dotnet+0x1acf>
    226a:      	movabsq	$0x6c25203a7066202c, %rax # imm = 0x6C25203A7066202C
    2274:      	movq	%rax, 0x28(%rsp)
    2279:      	movabsq	$0x786c25203a707320, %rax # imm = 0x786C25203A707320
    2283:      	movq	%rax, 0x20(%rsp)
    2288:      	movabsq	$0x2c786c25203a6370, %rax # imm = 0x2C786C25203A6370
    2292:      	movq	%rax, 0x18(%rsp)
    2297:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    22a1:      	movq	%rax, 0x10(%rsp)
    22a6:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    22ae:      	leaq	0x10(%rsp), %rdi
    22b3:      	movl	$0x23, %eax
    22b8:      	movl	$0x6, %r9d
    22be:      	movq	0xed0(%r14), %rdx
    22c5:      	movq	0xed8(%r14), %rcx
    22cc:      	movq	0xee0(%r14), %r8
    22d3:      	movl	$0x23, %esi
    22d8:      	xorl	%eax, %eax
    22da:      	callq	*%r9
    22dd:      	cmpq	$0x100, %rbp            # imm = 0x100
    22e4:      	jae	0x1e2a <perf_unwind_dotnet+0x1e2a>
    22ea:      	jmp	0x2431 <perf_unwind_dotnet+0x2431>
    22ef:      	movl	%r15d, %ecx
    22f2:      	shrl	$0x18, %ecx
    22f5:      	andl	$0xf, %ecx
    22f8:      	je	0x23ce <perf_unwind_dotnet+0x23ce>
    22fe:      	addq	$-0xc0, %r13
    2305:      	jmp	0x23dc <perf_unwind_dotnet+0x23dc>
    230a:      	leaq	(%rip), %rsi            # 0x2311 <perf_unwind_dotnet+0x2311>
    2311:      	leaq	0x10(%rsp), %rax
    2316:      	movl	$0x8, %ecx
    231b:      	movq	%rax, %rdi
    231e:      	rep		movsq	(%rsi), %es:(%rdi)
    2321:      	movw	$0xa, 0x50(%rsp)
    2328:      	movl	$0x42, %ecx
    232d:      	movl	$0x6, %r9d
    2333:      	movq	%rax, %rdi
    2336:      	movl	$0x42, %esi
    233b:      	movq	%r13, %rdx
    233e:      	movq	0x88(%rsp), %rcx
    2346:      	movq	%rbp, %r8
    2349:      	xorl	%eax, %eax
    234b:      	callq	*%r9
    234e:      	jmp	0x1e56 <perf_unwind_dotnet+0x1e56>
    2353:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    235d:      	movq	%rax, 0x36(%rsp)
    2362:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    236c:      	movq	%rax, 0x30(%rsp)
    2371:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    237b:      	movq	%rax, 0x28(%rsp)
    2380:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    238a:      	movq	%rax, 0x20(%rsp)
    238f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2399:      	movq	%rax, 0x18(%rsp)
    239e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    23a8:      	movq	%rax, 0x10(%rsp)
    23ad:      	leaq	0x10(%rsp), %rdi
    23b2:      	movl	$0x2e, %eax
    23b7:      	movl	$0x6, %ecx
    23bc:      	movl	0x68(%rsp), %edx
    23c0:      	movl	$0x2e, %esi
    23c5:      	xorl	%eax, %eax
    23c7:      	callq	*%rcx
    23c9:      	jmp	0x1cf7 <perf_unwind_dotnet+0x1cf7>
    23ce:      	shrl	$0x1c, %r15d
    23d2:      	addq	$-0xe0, %r13
    23d9:      	movl	%r15d, %ecx
    23dc:      	movq	0x88(%rsp), %rax
    23e4:      	addq	%r13, %rax
    23e7:      	leal	-0x4(,%rcx,4), %r15d
    23ef:      	addq	%rax, %r15
    23f2:      	movq	(%rip), %rax            # 0x23f9 <perf_unwind_dotnet+0x23f9>
    23f9:      	cmpl	$0x0, (%rax)
    23fc:      	jne	0x298c <perf_unwind_dotnet+0x298c>
    2402:      	leaq	-0x8(%r15), %rdx
    2406:      	leaq	0x68(%rsp), %rdi
    240b:      	movl	$0x8, %eax
    2410:      	movl	$0x70, %ecx
    2415:      	movl	$0x8, %esi
    241a:      	callq	*%rcx
    241c:      	testq	%rax, %rax
    241f:      	movq	(%rip), %rbp            # 0x2426 <perf_unwind_dotnet+0x2426>
    2426:      	jne	0xbb6 <perf_unwind_dotnet+0xbb6>
    242c:      	movl	$0x1f, %ebp
    2431:      	movq	(%rip), %rax            # 0x2438 <perf_unwind_dotnet+0x2438>
    2438:      	cmpl	$0x0, (%rax)
    243b:      	jne	0x25b1 <perf_unwind_dotnet+0x25b1>
    2441:      	movl	0x2c0(%r14), %eax
    2448:      	cmpq	$0x7e, %rax
    244c:      	ja	0xc0c <perf_unwind_dotnet+0xc0c>
    2452:      	movq	0x68(%rsp), %rcx
    2457:      	subq	%r15, %r12
    245a:      	shlq	$0x5, %rcx
    245e:      	addq	%rbp, %rcx
    2461:      	leal	0x1(%rax), %edx
    2464:      	movl	%edx, 0x2c0(%r14)
    246b:      	leaq	(%rax,%rax,2), %rax
    246f:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    2477:      	movq	%r12, 0x2d8(%r14,%rax,8)
    247f:      	movb	$0xa, 0x2e0(%r14,%rax,8)
    2488:      	movb	%bl, 0x2e1(%r14,%rax,8)
    2490:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    249c:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    24a7:      	movl	$0x5b, 0xc(%rsp)
    24af:      	movq	(%rip), %rdi            # 0x24b6 <perf_unwind_dotnet+0x24b6>
    24b6:      	leaq	0xc(%rsp), %rsi
    24bb:      	movl	$0x1, %eax
    24c0:      	callq	*%rax
    24c2:      	testq	%rax, %rax
    24c5:      	je	0x24d3 <perf_unwind_dotnet+0x24d3>
    24c7:      	incq	(%rax)
    24ca:      	movq	(%rip), %rbp            # 0x24d1 <perf_unwind_dotnet+0x24d1>
    24d1:      	jmp	0x24e4 <perf_unwind_dotnet+0x24e4>
    24d3:      	movq	(%rip), %rbp            # 0x24da <perf_unwind_dotnet+0x24da>
    24da:      	cmpl	$0x0, (%rbp)
    24de:      	jne	0x2884 <perf_unwind_dotnet+0x2884>
    24e4:      	movq	0x98(%rsp), %rax
    24ec:      	movq	(%rax), %r13
    24ef:      	movl	(%rbp), %eax
    24f2:      	testq	%r13, %r13
    24f5:      	je	0x258f <perf_unwind_dotnet+0x258f>
    24fb:      	testl	%eax, %eax
    24fd:      	jne	0x2610 <perf_unwind_dotnet+0x2610>
    2503:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    250d:      	cmpq	%rax, %r13
    2510:      	jbe	0x26a8 <perf_unwind_dotnet+0x26a8>
    2516:      	movq	0x60(%rsp), %r15
    251b:      	movq	(%rip), %rbp            # 0x2522 <perf_unwind_dotnet+0x2522>
    2522:      	cmpl	$0x0, (%rbp)
    2526:      	je	0xda9 <perf_unwind_dotnet+0xda9>
    252c:      	movabsq	$0x7373657264646120, %rax # imm = 0x7373657264646120
    2536:      	movq	%rax, 0x28(%rsp)
    253b:      	movabsq	$0x6c656e72656b2061, %rax # imm = 0x6C656E72656B2061
    2545:      	movq	%rax, 0x20(%rsp)
    254a:      	movabsq	$0x20736920786c2520, %rax # imm = 0x20736920786C2520
    2554:      	movq	%rax, 0x18(%rsp)
    2559:      	movabsq	$0x65756c6176204350, %rax # imm = 0x65756C6176204350
    2563:      	movq	%rax, 0x10(%rsp)
    2568:      	movw	$0xa, 0x30(%rsp)
    256f:      	leaq	0x10(%rsp), %rdi
    2574:      	movl	$0x22, %eax
    2579:      	movl	$0x6, %ecx
    257e:      	movl	$0x22, %esi
    2583:      	movq	%r13, %rdx
    2586:      	xorl	%eax, %eax
    2588:      	callq	*%rcx
    258a:      	jmp	0xda9 <perf_unwind_dotnet+0xda9>
    258f:      	movq	0x60(%rsp), %r15
    2594:      	testl	%eax, %eax
    2596:      	jne	0x8900 <perf_unwind_dotnet+0x8900>
    259c:      	movl	$0x1, 0xf28(%r14)
    25a7:      	movl	$0xfad, %eax            # imm = 0xFAD
    25ac:      	jmp	0x7812 <perf_unwind_dotnet+0x7812>
    25b1:      	leaq	(%rip), %rsi            # 0x25b8 <perf_unwind_dotnet+0x25b8>
    25b8:      	leaq	0x10(%rsp), %rax
    25bd:      	movl	$0x8, %ecx
    25c2:      	movq	%rax, %rdi
    25c5:      	rep		movsq	(%rsi), %es:(%rdi)
    25c8:      	movb	$0x0, 0x52(%rsp)
    25cd:      	movw	$0xa78, 0x50(%rsp)      # imm = 0xA78
    25d4:      	movl	$0x43, %ecx
    25d9:      	movl	$0x6, %r9d
    25df:      	movq	0x68(%rsp), %rcx
    25e4:      	movq	%r12, %r8
    25e7:      	subq	%r15, %r8
    25ea:      	movq	%rax, %rdi
    25ed:      	movl	$0x43, %esi
    25f2:      	movq	%r15, %rdx
    25f5:      	xorl	%eax, %eax
    25f7:      	callq	*%r9
    25fa:      	movl	0x2c0(%r14), %eax
    2601:      	cmpq	$0x7e, %rax
    2605:      	ja	0xc0c <perf_unwind_dotnet+0xc0c>
    260b:      	jmp	0x2452 <perf_unwind_dotnet+0x2452>
    2610:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    261a:      	movq	%rax, 0x38(%rsp)
    261f:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    2629:      	movq	%rax, 0x30(%rsp)
    262e:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    2638:      	movq	%rax, 0x28(%rsp)
    263d:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    2647:      	movq	%rax, 0x20(%rsp)
    264c:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    2656:      	movq	%rax, 0x18(%rsp)
    265b:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    2665:      	movq	%rax, 0x10(%rsp)
    266a:      	movb	$0x0, 0x40(%rsp)
    266f:      	leaq	0x10(%rsp), %rdi
    2674:      	movl	$0x31, %eax
    2679:      	movl	$0x6, %ecx
    267e:      	movl	0x2c0(%r14), %edx
    2685:      	movl	$0x31, %esi
    268a:      	xorl	%eax, %eax
    268c:      	callq	*%rcx
    268e:      	movq	0xed0(%r14), %r13
    2695:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    269f:      	cmpq	%rax, %r13
    26a2:      	ja	0x2516 <perf_unwind_dotnet+0x2516>
    26a8:      	cmpq	$0x1000, %r13           # imm = 0x1000
    26af:      	jae	0x2723 <perf_unwind_dotnet+0x2723>
    26b1:      	movq	0x60(%rsp), %r15
    26b6:      	movq	(%rip), %rbp            # 0x26bd <perf_unwind_dotnet+0x26bd>
    26bd:      	cmpl	$0x0, (%rbp)
    26c1:      	je	0xecb <perf_unwind_dotnet+0xecb>
    26c7:      	movabsq	$0xa676e69726f6e, %rax  # imm = 0xA676E69726F6E
    26d1:      	movq	%rax, 0x26(%rsp)
    26d6:      	movabsq	$0x6f6e6769202c786c, %rax # imm = 0x6F6E6769202C786C
    26e0:      	movq	%rax, 0x20(%rsp)
    26e5:      	movabsq	$0x252065756c617620, %rax # imm = 0x252065756C617620
    26ef:      	movq	%rax, 0x18(%rsp)
    26f4:      	movabsq	$0x6370206c6c616d73, %rax # imm = 0x6370206C6C616D73
    26fe:      	movq	%rax, 0x10(%rsp)
    2703:      	leaq	0x10(%rsp), %rdi
    2708:      	movl	$0x1e, %eax
    270d:      	movl	$0x6, %ecx
    2712:      	movl	$0x1e, %esi
    2717:      	movq	%r13, %rdx
    271a:      	xorl	%eax, %eax
    271c:      	callq	*%rcx
    271e:      	jmp	0xecb <perf_unwind_dotnet+0xecb>
    2723:      	movl	(%r14), %eax
    2726:      	movl	$0x60, 0x70(%rsp)
    272e:      	movbel	%eax, 0x74(%rsp)
    2734:      	movbeq	%r13, 0x78(%rsp)
    273b:      	movq	(%rip), %rdi            # 0x2742 <perf_unwind_dotnet+0x2742>
    2742:      	leaq	0x70(%rsp), %rsi
    2747:      	movl	$0x1, %eax
    274c:      	callq	*%rax
    274e:      	testq	%rax, %rax
    2751:      	je	0x8837 <perf_unwind_dotnet+0x8837>
    2757:      	movq	0x8(%rax), %r12
    275b:      	movq	%r12, %rcx
    275e:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    2768:      	andq	%rdx, %rcx
    276b:      	movq	%rcx, 0xf20(%r14)
    2772:      	movq	(%rax), %rax
    2775:      	movq	%rax, 0xf10(%r14)
    277c:      	shrq	$0x38, %r12
    2780:      	movq	%r13, %rax
    2783:      	subq	%rcx, %rax
    2786:      	movq	%rax, 0xf18(%r14)
    278d:      	movq	(%rip), %rax            # 0x2794 <perf_unwind_dotnet+0x2794>
    2794:      	cmpl	$0x0, (%rax)
    2797:      	jne	0x2a86 <perf_unwind_dotnet+0x2a86>
    279d:      	cmpl	$0x1, %r12d
    27a1:      	jne	0x336c <perf_unwind_dotnet+0x336c>
    27a7:      	movq	0xf10(%r14), %rax
    27ae:      	movq	%rax, 0x70(%rsp)
    27b3:      	movq	0xf18(%r14), %rbx
    27ba:      	movq	(%rip), %rdi            # 0x27c1 <perf_unwind_dotnet+0x27c1>
    27c1:      	leaq	0x70(%rsp), %rsi
    27c6:      	movl	$0x1, %eax
    27cb:      	callq	*%rax
    27cd:      	movl	$0x1, %r12d
    27d3:      	testq	%rax, %rax
    27d6:      	je	0x336c <perf_unwind_dotnet+0x336c>
    27dc:      	movq	%rax, %r15
    27df:      	cmpq	%rbx, (%rax)
    27e2:      	ja	0x27ea <perf_unwind_dotnet+0x27ea>
    27e4:      	cmpq	%rbx, 0x8(%r15)
    27e8:      	jae	0x27fe <perf_unwind_dotnet+0x27fe>
    27ea:      	cmpq	%rbx, 0x10(%r15)
    27ee:      	ja	0x336c <perf_unwind_dotnet+0x336c>
    27f4:      	cmpq	%rbx, 0x18(%r15)
    27f8:      	jb	0x336c <perf_unwind_dotnet+0x336c>
    27fe:      	movq	(%rip), %rax            # 0x2805 <perf_unwind_dotnet+0x2805>
    2805:      	cmpl	$0x0, (%rax)
    2808:      	jne	0x32c5 <perf_unwind_dotnet+0x32c5>
    280e:      	movl	0x1380(%r14), %eax
    2815:      	movl	0x20(%r15), %ecx
    2819:      	btl	%ecx, %eax
    281c:      	jae	0x3332 <perf_unwind_dotnet+0x3332>
    2822:      	movq	(%rip), %rax            # 0x2829 <perf_unwind_dotnet+0x2829>
    2829:      	cmpl	$0x0, (%rax)
    282c:      	je	0x336c <perf_unwind_dotnet+0x336c>
    2832:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    283c:      	movq	%rax, 0x20(%rsp)
    2841:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    284b:      	movq	%rax, 0x18(%rsp)
    2850:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    285a:      	movq	%rax, 0x10(%rsp)
    285f:      	movl	$0xa656e, 0x27(%rsp)    # imm = 0xA656E
    2867:      	leaq	0x10(%rsp), %rdi
    286c:      	movl	$0x1b, %eax
    2871:      	movl	$0x6, %ecx
    2876:      	movl	$0x1b, %esi
    287b:      	xorl	%eax, %eax
    287d:      	callq	*%rcx
    287f:      	jmp	0x336c <perf_unwind_dotnet+0x336c>
    2884:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    288e:      	movq	%rax, 0x36(%rsp)
    2893:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    289d:      	movq	%rax, 0x30(%rsp)
    28a2:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    28ac:      	movq	%rax, 0x28(%rsp)
    28b1:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    28bb:      	movq	%rax, 0x20(%rsp)
    28c0:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    28ca:      	movq	%rax, 0x18(%rsp)
    28cf:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    28d9:      	movq	%rax, 0x10(%rsp)
    28de:      	leaq	0x10(%rsp), %rdi
    28e3:      	movl	$0x2e, %eax
    28e8:      	movl	$0x6, %ecx
    28ed:      	movl	0xc(%rsp), %edx
    28f1:      	movl	$0x2e, %esi
    28f6:      	xorl	%eax, %eax
    28f8:      	callq	*%rcx
    28fa:      	jmp	0x24e4 <perf_unwind_dotnet+0x24e4>
    28ff:      	movabsq	$0xa782520797274, %rax  # imm = 0xA782520797274
    2909:      	movq	%rax, 0x3e(%rsp)
    290e:      	movabsq	$0x72746e6520747372, %rax # imm = 0x72746E6520747372
    2918:      	movq	%rax, 0x38(%rsp)
    291d:      	movabsq	$0x6966203a786c2520, %rax # imm = 0x6966203A786C2520
    2927:      	movq	%rax, 0x30(%rsp)
    292c:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    2936:      	movq	%rax, 0x28(%rsp)
    293b:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    2945:      	movq	%rax, 0x20(%rsp)
    294a:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    2954:      	movq	%rax, 0x18(%rsp)
    2959:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    2963:      	movq	%rax, 0x10(%rsp)
    2968:      	leaq	0x10(%rsp), %rdi
    296d:      	movl	$0x36, %eax
    2972:      	movl	$0x6, %r8d
    2978:      	movl	$0x36, %esi
    297d:      	movq	%r15, %rdx
    2980:      	movl	%ebp, %ecx
    2982:      	xorl	%eax, %eax
    2984:      	callq	*%r8
    2987:      	jmp	0x1f09 <perf_unwind_dotnet+0x1f09>
    298c:      	movabsq	$0xa786c253d7465, %rax  # imm = 0xA786C253D7465
    2996:      	movq	%rax, 0x36(%rsp)
    299b:      	movabsq	$0x746572202c78253d, %rax # imm = 0x746572202C78253D
    29a5:      	movq	%rax, 0x30(%rsp)
    29aa:      	movabsq	$0x6c6176202c786c25, %rax # imm = 0x6C6176202C786C25
    29b4:      	movq	%rax, 0x28(%rsp)
    29b9:      	movabsq	$0x203d2061746c6564, %rax # imm = 0x203D2061746C6564
    29c3:      	movq	%rax, 0x20(%rsp)
    29c8:      	movabsq	$0x5f6370203e2d2d20, %rax # imm = 0x5F6370203E2D2D20
    29d2:      	movq	%rax, 0x18(%rsp)
    29d7:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    29e1:      	movq	%rax, 0x10(%rsp)
    29e6:      	leaq	0x10(%rsp), %rdi
    29eb:      	movl	$0x2e, %eax
    29f0:      	movl	$0x6, %r9d
    29f6:      	movl	$0x2e, %esi
    29fb:      	movq	%r13, %rdx
    29fe:      	movq	%r15, %r8
    2a01:      	xorl	%eax, %eax
    2a03:      	callq	*%r9
    2a06:      	jmp	0x2402 <perf_unwind_dotnet+0x2402>
    2a0b:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2a15:      	movq	%rax, 0x36(%rsp)
    2a1a:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2a24:      	movq	%rax, 0x30(%rsp)
    2a29:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2a33:      	movq	%rax, 0x28(%rsp)
    2a38:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2a42:      	movq	%rax, 0x20(%rsp)
    2a47:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2a51:      	movq	%rax, 0x18(%rsp)
    2a56:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2a60:      	movq	%rax, 0x10(%rsp)
    2a65:      	leaq	0x10(%rsp), %rdi
    2a6a:      	movl	$0x2e, %eax
    2a6f:      	movl	$0x6, %ecx
    2a74:      	movl	0xc(%rsp), %edx
    2a78:      	movl	$0x2e, %esi
    2a7d:      	xorl	%eax, %eax
    2a7f:      	callq	*%rcx
    2a81:      	jmp	0x1f6d <perf_unwind_dotnet+0x1f6d>
    2a86:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    2a90:      	movq	%rax, 0x38(%rsp)
    2a95:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    2a9f:      	movq	%rax, 0x30(%rsp)
    2aa4:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    2aae:      	movq	%rax, 0x28(%rsp)
    2ab3:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    2abd:      	movq	%rax, 0x20(%rsp)
    2ac2:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    2acc:      	movq	%rax, 0x18(%rsp)
    2ad1:      	movabsq	$0x6365732074786554, %rbx # imm = 0x6365732074786554
    2adb:      	movq	%rbx, 0x10(%rsp)
    2ae0:      	movw	$0xa, 0x40(%rsp)
    2ae7:      	leaq	0x10(%rsp), %rdi
    2aec:      	movl	$0x32, %eax
    2af1:      	movl	$0x6, %r9d
    2af7:      	movq	0xf10(%r14), %rcx
    2afe:      	movl	$0x32, %esi
    2b03:      	movq	%r13, %rdx
    2b06:      	movl	%r12d, %r8d
    2b09:      	xorl	%eax, %eax
    2b0b:      	callq	*%r9
    2b0e:      	movq	(%rip), %rax            # 0x2b15 <perf_unwind_dotnet+0x2b15>
    2b15:      	cmpl	$0x0, (%rax)
    2b18:      	je	0x279d <perf_unwind_dotnet+0x279d>
    2b1e:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    2b28:      	movq	%rax, 0x37(%rsp)
    2b2d:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    2b37:      	movq	%rax, 0x30(%rsp)
    2b3c:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    2b46:      	movq	%rax, 0x28(%rsp)
    2b4b:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    2b55:      	movq	%rax, 0x20(%rsp)
    2b5a:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    2b64:      	movq	%rax, 0x18(%rsp)
    2b69:      	movq	%rbx, 0x10(%rsp)
    2b6e:      	leaq	0x10(%rsp), %rdi
    2b73:      	movl	$0x2f, %eax
    2b78:      	movl	$0x6, %r8d
    2b7e:      	movq	0xf18(%r14), %rcx
    2b85:      	movq	0xf20(%r14), %rdx
    2b8c:      	movl	$0x2f, %esi
    2b91:      	xorl	%eax, %eax
    2b93:      	callq	*%r8
    2b96:      	jmp	0x279d <perf_unwind_dotnet+0x279d>
    2b9b:      	movabsq	$0xa782520797274, %rax  # imm = 0xA782520797274
    2ba5:      	movq	%rax, 0x3f(%rsp)
    2baa:      	movabsq	$0x746e6520646e6f63, %rax # imm = 0x746E6520646E6F63
    2bb4:      	movq	%rax, 0x38(%rsp)
    2bb9:      	movabsq	$0x6573203a786c2520, %rax # imm = 0x6573203A786C2520
    2bc3:      	movq	%rax, 0x30(%rsp)
    2bc8:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    2bd2:      	movq	%rax, 0x28(%rsp)
    2bd7:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    2be1:      	movq	%rax, 0x20(%rsp)
    2be6:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    2bf0:      	movq	%rax, 0x18(%rsp)
    2bf5:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    2bff:      	movq	%rax, 0x10(%rsp)
    2c04:      	leaq	0x10(%rsp), %rdi
    2c09:      	movl	$0x37, %eax
    2c0e:      	movl	$0x6, %r8d
    2c14:      	movl	$0x37, %esi
    2c19:      	movq	%r13, %rdx
    2c1c:      	movl	%r15d, %ecx
    2c1f:      	xorl	%eax, %eax
    2c21:      	callq	*%r8
    2c24:      	xorl	%ecx, %ecx
    2c26:      	testl	%r15d, %r15d
    2c29:      	jne	0x2027 <perf_unwind_dotnet+0x2027>
    2c2f:      	movq	0x1170(%r14), %rax
    2c36:      	movl	$0xffffff84, %ecx       # imm = 0xFFFFFF84
    2c3b:      	testq	%rax, %rax
    2c3e:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2c44:      	movq	0x1168(%r14), %rax
    2c4b:      	movl	$0xffffff86, %ecx       # imm = 0xFFFFFF86
    2c50:      	testq	%rax, %rax
    2c53:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2c59:      	movq	0x1160(%r14), %rax
    2c60:      	movl	$0xffffff88, %ecx       # imm = 0xFFFFFF88
    2c65:      	testq	%rax, %rax
    2c68:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2c6e:      	movq	0x1158(%r14), %rax
    2c75:      	movl	$0xffffff8a, %ecx       # imm = 0xFFFFFF8A
    2c7a:      	testq	%rax, %rax
    2c7d:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2c83:      	movq	0x1150(%r14), %rax
    2c8a:      	movl	$0xffffff8c, %ecx       # imm = 0xFFFFFF8C
    2c8f:      	testq	%rax, %rax
    2c92:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2c98:      	movq	0x1148(%r14), %rax
    2c9f:      	movl	$0xffffff8e, %ecx       # imm = 0xFFFFFF8E
    2ca4:      	testq	%rax, %rax
    2ca7:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2cad:      	movq	0x1140(%r14), %rax
    2cb4:      	movl	$0xffffff90, %ecx       # imm = 0xFFFFFF90
    2cb9:      	testq	%rax, %rax
    2cbc:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2cc2:      	movq	0x1138(%r14), %rax
    2cc9:      	movl	$0xffffff92, %ecx       # imm = 0xFFFFFF92
    2cce:      	testq	%rax, %rax
    2cd1:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2cd7:      	movq	0x1130(%r14), %rax
    2cde:      	movl	$0xffffff94, %ecx       # imm = 0xFFFFFF94
    2ce3:      	testq	%rax, %rax
    2ce6:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2cec:      	movq	0x1128(%r14), %rax
    2cf3:      	movl	$0xffffff96, %ecx       # imm = 0xFFFFFF96
    2cf8:      	testq	%rax, %rax
    2cfb:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2d01:      	movq	0x1120(%r14), %rax
    2d08:      	movl	$0xffffff98, %ecx       # imm = 0xFFFFFF98
    2d0d:      	testq	%rax, %rax
    2d10:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2d16:      	movq	0x1118(%r14), %rax
    2d1d:      	movl	$0xffffff9a, %ecx       # imm = 0xFFFFFF9A
    2d22:      	testq	%rax, %rax
    2d25:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2d2b:      	movq	0x1110(%r14), %rax
    2d32:      	movl	$0xffffff9c, %ecx       # imm = 0xFFFFFF9C
    2d37:      	testq	%rax, %rax
    2d3a:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2d40:      	movq	0x1108(%r14), %rax
    2d47:      	movl	$0xffffff9e, %ecx       # imm = 0xFFFFFF9E
    2d4c:      	testq	%rax, %rax
    2d4f:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2d55:      	movq	0x1100(%r14), %rax
    2d5c:      	movl	$0xffffffa0, %ecx       # imm = 0xFFFFFFA0
    2d61:      	testq	%rax, %rax
    2d64:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2d6a:      	movq	0x10f8(%r14), %rax
    2d71:      	movl	$0xffffffa2, %ecx       # imm = 0xFFFFFFA2
    2d76:      	testq	%rax, %rax
    2d79:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2d7f:      	movq	0x10f0(%r14), %rax
    2d86:      	movl	$0xffffffa4, %ecx       # imm = 0xFFFFFFA4
    2d8b:      	testq	%rax, %rax
    2d8e:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2d94:      	movq	0x10e8(%r14), %rax
    2d9b:      	movl	$0xffffffa6, %ecx       # imm = 0xFFFFFFA6
    2da0:      	testq	%rax, %rax
    2da3:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2da9:      	movq	0x10e0(%r14), %rax
    2db0:      	movl	$0xffffffa8, %ecx       # imm = 0xFFFFFFA8
    2db5:      	testq	%rax, %rax
    2db8:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2dbe:      	movq	0x10d8(%r14), %rax
    2dc5:      	movl	$0xffffffaa, %ecx       # imm = 0xFFFFFFAA
    2dca:      	testq	%rax, %rax
    2dcd:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2dd3:      	movq	0x10d0(%r14), %rax
    2dda:      	movl	$0xffffffac, %ecx       # imm = 0xFFFFFFAC
    2ddf:      	testq	%rax, %rax
    2de2:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2de8:      	movq	0x10c8(%r14), %rax
    2def:      	movl	$0xffffffae, %ecx       # imm = 0xFFFFFFAE
    2df4:      	testq	%rax, %rax
    2df7:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2dfd:      	movq	0x10c0(%r14), %rax
    2e04:      	movl	$0xffffffb0, %ecx       # imm = 0xFFFFFFB0
    2e09:      	testq	%rax, %rax
    2e0c:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2e12:      	movq	0x10b8(%r14), %rax
    2e19:      	movl	$0xffffffb2, %ecx       # imm = 0xFFFFFFB2
    2e1e:      	testq	%rax, %rax
    2e21:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2e27:      	movq	0x10b0(%r14), %rax
    2e2e:      	movl	$0xffffffb4, %ecx       # imm = 0xFFFFFFB4
    2e33:      	testq	%rax, %rax
    2e36:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2e3c:      	movq	0x10a8(%r14), %rax
    2e43:      	movl	$0xffffffb6, %ecx       # imm = 0xFFFFFFB6
    2e48:      	testq	%rax, %rax
    2e4b:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2e51:      	movq	0x10a0(%r14), %rax
    2e58:      	movl	$0xffffffb8, %ecx       # imm = 0xFFFFFFB8
    2e5d:      	testq	%rax, %rax
    2e60:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2e66:      	movq	0x1098(%r14), %rax
    2e6d:      	movl	$0xffffffba, %ecx       # imm = 0xFFFFFFBA
    2e72:      	testq	%rax, %rax
    2e75:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2e7b:      	movq	0x1090(%r14), %rax
    2e82:      	movl	$0xffffffbc, %ecx       # imm = 0xFFFFFFBC
    2e87:      	testq	%rax, %rax
    2e8a:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2e90:      	movq	0x1088(%r14), %rax
    2e97:      	movl	$0xffffffbe, %ecx       # imm = 0xFFFFFFBE
    2e9c:      	testq	%rax, %rax
    2e9f:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2ea5:      	movq	0x1080(%r14), %rax
    2eac:      	movl	$0xffffffc0, %ecx       # imm = 0xFFFFFFC0
    2eb1:      	testq	%rax, %rax
    2eb4:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2eba:      	movq	0x1078(%r14), %rax
    2ec1:      	movl	$0xffffffc2, %ecx       # imm = 0xFFFFFFC2
    2ec6:      	testq	%rax, %rax
    2ec9:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2ecf:      	movq	0x1070(%r14), %rax
    2ed6:      	movl	$0xffffffc4, %ecx       # imm = 0xFFFFFFC4
    2edb:      	testq	%rax, %rax
    2ede:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2ee4:      	movq	0x1068(%r14), %rax
    2eeb:      	movl	$0xffffffc6, %ecx       # imm = 0xFFFFFFC6
    2ef0:      	testq	%rax, %rax
    2ef3:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2ef9:      	movq	0x1060(%r14), %rax
    2f00:      	movl	$0xffffffc8, %ecx       # imm = 0xFFFFFFC8
    2f05:      	testq	%rax, %rax
    2f08:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2f0e:      	movq	0x1058(%r14), %rax
    2f15:      	movl	$0xffffffca, %ecx       # imm = 0xFFFFFFCA
    2f1a:      	testq	%rax, %rax
    2f1d:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2f23:      	movq	0x1050(%r14), %rax
    2f2a:      	movl	$0xffffffcc, %ecx       # imm = 0xFFFFFFCC
    2f2f:      	testq	%rax, %rax
    2f32:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2f38:      	movq	0x1048(%r14), %rax
    2f3f:      	movl	$0xffffffce, %ecx       # imm = 0xFFFFFFCE
    2f44:      	testq	%rax, %rax
    2f47:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2f4d:      	movq	0x1040(%r14), %rax
    2f54:      	movl	$0xffffffd0, %ecx       # imm = 0xFFFFFFD0
    2f59:      	testq	%rax, %rax
    2f5c:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2f62:      	movq	0x1038(%r14), %rax
    2f69:      	movl	$0xffffffd2, %ecx       # imm = 0xFFFFFFD2
    2f6e:      	testq	%rax, %rax
    2f71:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2f77:      	movq	0x1030(%r14), %rax
    2f7e:      	movl	$0xffffffd4, %ecx       # imm = 0xFFFFFFD4
    2f83:      	testq	%rax, %rax
    2f86:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2f8c:      	movq	0x1028(%r14), %rax
    2f93:      	movl	$0xffffffd6, %ecx       # imm = 0xFFFFFFD6
    2f98:      	testq	%rax, %rax
    2f9b:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2fa1:      	movq	0x1020(%r14), %rax
    2fa8:      	movl	$0xffffffd8, %ecx       # imm = 0xFFFFFFD8
    2fad:      	testq	%rax, %rax
    2fb0:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2fb6:      	movq	0x1018(%r14), %rax
    2fbd:      	movl	$0xffffffda, %ecx       # imm = 0xFFFFFFDA
    2fc2:      	testq	%rax, %rax
    2fc5:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2fcb:      	movq	0x1010(%r14), %rax
    2fd2:      	movl	$0xffffffdc, %ecx       # imm = 0xFFFFFFDC
    2fd7:      	testq	%rax, %rax
    2fda:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2fe0:      	movq	0x1008(%r14), %rax
    2fe7:      	movl	$0xffffffde, %ecx       # imm = 0xFFFFFFDE
    2fec:      	testq	%rax, %rax
    2fef:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    2ff5:      	movq	0x1000(%r14), %rax
    2ffc:      	movl	$0xffffffe0, %ecx       # imm = 0xFFFFFFE0
    3001:      	testq	%rax, %rax
    3004:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    300a:      	movq	0xff8(%r14), %rax
    3011:      	movl	$0xffffffe2, %ecx       # imm = 0xFFFFFFE2
    3016:      	testq	%rax, %rax
    3019:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    301f:      	movq	0xff0(%r14), %rax
    3026:      	movl	$0xffffffe4, %ecx       # imm = 0xFFFFFFE4
    302b:      	testq	%rax, %rax
    302e:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    3034:      	movq	0xfe8(%r14), %rax
    303b:      	movl	$0xffffffe6, %ecx       # imm = 0xFFFFFFE6
    3040:      	testq	%rax, %rax
    3043:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    3049:      	movq	0xfe0(%r14), %rax
    3050:      	movl	$0xffffffe8, %ecx       # imm = 0xFFFFFFE8
    3055:      	testq	%rax, %rax
    3058:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    305e:      	movq	0xfd8(%r14), %rax
    3065:      	movl	$0xffffffea, %ecx       # imm = 0xFFFFFFEA
    306a:      	testq	%rax, %rax
    306d:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    3073:      	movq	0xfd0(%r14), %rax
    307a:      	movl	$0xffffffec, %ecx       # imm = 0xFFFFFFEC
    307f:      	testq	%rax, %rax
    3082:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    3088:      	movq	0xfc8(%r14), %rax
    308f:      	movl	$0xffffffee, %ecx       # imm = 0xFFFFFFEE
    3094:      	testq	%rax, %rax
    3097:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    309d:      	movq	0xfc0(%r14), %rax
    30a4:      	movl	$0xfffffff0, %ecx       # imm = 0xFFFFFFF0
    30a9:      	testq	%rax, %rax
    30ac:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    30b2:      	movq	0xfb8(%r14), %rax
    30b9:      	movl	$0xfffffff2, %ecx       # imm = 0xFFFFFFF2
    30be:      	testq	%rax, %rax
    30c1:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    30c3:      	movq	0xfb0(%r14), %rax
    30ca:      	movl	$0xfffffff4, %ecx       # imm = 0xFFFFFFF4
    30cf:      	testq	%rax, %rax
    30d2:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    30d4:      	movq	0xfa8(%r14), %rax
    30db:      	movl	$0xfffffff6, %ecx       # imm = 0xFFFFFFF6
    30e0:      	testq	%rax, %rax
    30e3:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    30e5:      	movq	0xfa0(%r14), %rax
    30ec:      	movl	$0xfffffff8, %ecx       # imm = 0xFFFFFFF8
    30f1:      	testq	%rax, %rax
    30f4:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    30f6:      	movq	0xf98(%r14), %rax
    30fd:      	movl	$0xfffffffa, %ecx       # imm = 0xFFFFFFFA
    3102:      	testq	%rax, %rax
    3105:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    3107:      	movq	0xf90(%r14), %rax
    310e:      	movl	$0xfffffffc, %ecx       # imm = 0xFFFFFFFC
    3113:      	testq	%rax, %rax
    3116:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    3118:      	movq	0xf88(%r14), %rax
    311f:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3124:      	testq	%rax, %rax
    3127:      	jne	0x3136 <perf_unwind_dotnet+0x3136>
    3129:      	movq	0x90(%rsp), %rax
    3131:      	movq	(%rax), %rax
    3134:      	xorl	%ecx, %ecx
    3136:      	xorl	%edx, %edx
    3138:      	movq	%rax, %r15
    313b:      	shrq	$0x20, %r15
    313f:      	setne	%dl
    3142:      	cmovel	%eax, %r15d
    3146:      	subl	%edx, %ecx
    3148:      	addl	$0x7e, %ecx
    314b:      	movl	%ecx, %eax
    314d:      	shll	$0x8, %eax
    3150:      	subq	%rax, %r13
    3153:      	jb	0x2035 <perf_unwind_dotnet+0x2035>
    3159:      	movq	(%rip), %rax            # 0x3160 <perf_unwind_dotnet+0x3160>
    3160:      	cmpl	$0x0, (%rax)
    3163:      	jne	0x3226 <perf_unwind_dotnet+0x3226>
    3169:      	testl	%r15d, %r15d
    316c:      	jne	0x1f39 <perf_unwind_dotnet+0x1f39>
    3172:      	movl	$0x5f, 0xc(%rsp)
    317a:      	movq	(%rip), %rdi            # 0x3181 <perf_unwind_dotnet+0x3181>
    3181:      	leaq	0xc(%rsp), %rsi
    3186:      	movl	$0x1, %eax
    318b:      	callq	*%rax
    318d:      	testq	%rax, %rax
    3190:      	je	0x3197 <perf_unwind_dotnet+0x3197>
    3192:      	incq	(%rax)
    3195:      	jmp	0x31a7 <perf_unwind_dotnet+0x31a7>
    3197:      	movq	(%rip), %rax            # 0x319e <perf_unwind_dotnet+0x319e>
    319e:      	cmpl	$0x0, (%rax)
    31a1:      	jne	0x3835 <perf_unwind_dotnet+0x3835>
    31a7:      	movl	$0x1773, %edx           # imm = 0x1773
    31ac:      	movb	$0x1, %bl
    31ae:      	movq	(%rip), %rax            # 0x31b5 <perf_unwind_dotnet+0x31b5>
    31b5:      	cmpl	$0x0, (%rax)
    31b8:      	je	0x1f84 <perf_unwind_dotnet+0x1f84>
    31be:      	movabsq	$0xa642520687469, %rax  # imm = 0xA642520687469
    31c8:      	movq	%rax, 0x30(%rsp)
    31cd:      	movabsq	$0x772064656c696166, %rax # imm = 0x772064656C696166
    31d7:      	movq	%rax, 0x28(%rsp)
    31dc:      	movabsq	$0x2074726174735f65, %rax # imm = 0x2074726174735F65
    31e6:      	movq	%rax, 0x20(%rsp)
    31eb:      	movabsq	$0x646f63203e2d2d20, %rax # imm = 0x646F63203E2D2D20
    31f5:      	movq	%rax, 0x18(%rsp)
    31fa:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    3204:      	movq	%rax, 0x10(%rsp)
    3209:      	leaq	0x10(%rsp), %rdi
    320e:      	movl	$0x28, %eax
    3213:      	movl	$0x6, %ecx
    3218:      	movl	$0x28, %esi
    321d:      	xorl	%eax, %eax
    321f:      	callq	*%rcx
    3221:      	jmp	0x1f84 <perf_unwind_dotnet+0x1f84>
    3226:      	movabsq	$0x207972746e65202c, %rax # imm = 0x207972746E65202C
    3230:      	movq	%rax, 0x40(%rsp)
    3235:      	movabsq	$0x6425206465707069, %rax # imm = 0x6425206465707069
    323f:      	movq	%rax, 0x38(%rsp)
    3244:      	movabsq	$0x6b73203a786c2520, %rax # imm = 0x6B73203A786C2520
    324e:      	movq	%rax, 0x30(%rsp)
    3253:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    325d:      	movq	%rax, 0x28(%rsp)
    3262:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    326c:      	movq	%rax, 0x20(%rsp)
    3271:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    327b:      	movq	%rax, 0x18(%rsp)
    3280:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    328a:      	movq	%rax, 0x10(%rsp)
    328f:      	movl	$0xa7825, 0x48(%rsp)    # imm = 0xA7825
    3297:      	leaq	0x10(%rsp), %rdi
    329c:      	movl	$0x3c, %eax
    32a1:      	movl	$0x6, %r9d
    32a7:      	movl	$0x3c, %esi
    32ac:      	movq	%r13, %rdx
    32af:      	movl	%r15d, %r8d
    32b2:      	xorl	%eax, %eax
    32b4:      	callq	*%r9
    32b7:      	testl	%r15d, %r15d
    32ba:      	jne	0x1f39 <perf_unwind_dotnet+0x1f39>
    32c0:      	jmp	0x3172 <perf_unwind_dotnet+0x3172>
    32c5:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    32cf:      	movq	%rax, 0x26(%rsp)
    32d4:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    32de:      	movq	%rax, 0x20(%rsp)
    32e3:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    32ed:      	movq	%rax, 0x18(%rsp)
    32f2:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    32fc:      	movq	%rax, 0x10(%rsp)
    3301:      	leaq	0x10(%rsp), %rdi
    3306:      	movl	$0x1e, %eax
    330b:      	movl	$0x6, %ecx
    3310:      	movzwl	0x20(%r15), %edx
    3315:      	movl	$0x1e, %esi
    331a:      	xorl	%eax, %eax
    331c:      	callq	*%rcx
    331e:      	movl	0x1380(%r14), %eax
    3325:      	movl	0x20(%r15), %ecx
    3329:      	btl	%ecx, %eax
    332c:      	jb	0x2822 <perf_unwind_dotnet+0x2822>
    3332:      	movl	$0x0, 0x68(%rsp)
    333a:      	movq	(%rip), %rdi            # 0x3341 <perf_unwind_dotnet+0x3341>
    3341:      	leaq	0x68(%rsp), %rsi
    3346:      	movl	$0x1, %eax
    334b:      	callq	*%rax
    334d:      	testq	%rax, %rax
    3350:      	je	0x3357 <perf_unwind_dotnet+0x3357>
    3352:      	incq	(%rax)
    3355:      	jmp	0x3367 <perf_unwind_dotnet+0x3367>
    3357:      	movq	(%rip), %rax            # 0x335e <perf_unwind_dotnet+0x335e>
    335e:      	cmpl	$0x0, (%rax)
    3361:      	jne	0x3994 <perf_unwind_dotnet+0x3994>
    3367:      	movzwl	0x20(%r15), %r12d
    336c:      	cmpl	$0x8, %r12d
    3370:      	jne	0x8da3 <perf_unwind_dotnet+0x8da3>
    3376:      	movq	0xed0(%r14), %r12
    337d:      	movq	0xed8(%r14), %rbx
    3384:      	movq	0xee0(%r14), %r13
    338b:      	movzbl	0xf30(%r14), %eax
    3393:      	movb	%al, 0x88(%rsp)
    339a:      	movq	(%rip), %rax            # 0x33a1 <perf_unwind_dotnet+0x33a1>
    33a1:      	cmpl	$0x0, (%rax)
    33a4:      	jne	0x3791 <perf_unwind_dotnet+0x3791>
    33aa:      	cmpq	%rbx, %r13
    33ad:      	jb	0x77bb <perf_unwind_dotnet+0x77bb>
    33b3:      	leaq	0x2000(%rbx), %rax
    33ba:      	cmpq	%rax, %r13
    33bd:      	jae	0x77bb <perf_unwind_dotnet+0x77bb>
    33c3:      	movq	0xf10(%r14), %rbp
    33ca:      	movq	0xf20(%r14), %r15
    33d1:      	movq	%r12, 0x68(%rsp)
    33d6:      	movb	$0x1, 0xf30(%r14)
    33de:      	movq	%rbp, %rax
    33e1:      	andq	$-0x80, %rax
    33e5:      	cmpq	$0x80, %rax
    33eb:      	jne	0x342f <perf_unwind_dotnet+0x342f>
    33ed:      	movq	0xed8(%r14), %rax
    33f4:      	movl	$0x8, %ecx
    33f9:      	movl	$0x70, %r8d
    33ff:      	movq	0x98(%rsp), %rdi
    3407:      	movq	0xed8(%r14), %rdx
    340e:      	movl	$0x8, %esi
    3413:      	callq	*%r8
    3416:      	testq	%rax, %rax
    3419:      	jne	0x19c <perf_unwind_dotnet+0x19c>
    341f:      	addq	$0x8, 0xed8(%r14)
    3427:      	andl	$0x7f, %ebp
    342a:      	jmp	0x3a6a <perf_unwind_dotnet+0x3a6a>
    342f:      	leaq	0x70(%rsp), %rdi
    3434:      	movl	$0x10, %eax
    3439:      	movl	$0x70, %ecx
    343e:      	movl	$0x10, %esi
    3443:      	movq	%r13, %rdx
    3446:      	callq	*%rcx
    3448:      	testq	%rax, %rax
    344b:      	jne	0x26c <perf_unwind_dotnet+0x26c>
    3451:      	addq	$0x10, %r13
    3455:      	movq	%r13, 0xed8(%r14)
    345c:      	movq	0x70(%rsp), %rax
    3461:      	movq	%rax, 0xee0(%r14)
    3468:      	movq	0x78(%rsp), %rax
    346d:      	movq	%rax, 0xed0(%r14)
    3474:      	movq	(%rip), %rax            # 0x347b <perf_unwind_dotnet+0x347b>
    347b:      	cmpl	$0x0, (%rax)
    347e:      	jne	0x38b0 <perf_unwind_dotnet+0x38b0>
    3484:      	cmpq	$0x100, %rbp            # imm = 0x100
    348b:      	jb	0x3a6a <perf_unwind_dotnet+0x3a6a>
    3491:      	movq	0xf10(%r14), %rbp
    3498:      	movq	0xf20(%r14), %rbx
    349f:      	movq	%r12, %r13
    34a2:      	subq	%rbx, %r13
    34a5:      	movq	(%rip), %rax            # 0x34ac <perf_unwind_dotnet+0x34ac>
    34ac:      	cmpl	$0x0, (%rax)
    34af:      	jne	0x3950 <perf_unwind_dotnet+0x3950>
    34b5:      	movq	%r13, %r15
    34b8:      	andq	$-0x4, %r15
    34bc:      	movl	$0x100, %ecx            # imm = 0x100
    34c1:      	movq	%r15, %rax
    34c4:      	xorl	%edx, %edx
    34c6:      	divq	%rcx
    34c9:      	movq	%rax, %rcx
    34cc:      	movl	$0x7f, %eax
    34d1:      	subq	%rcx, %rax
    34d4:      	jns	0x34ed <perf_unwind_dotnet+0x34ed>
    34d6:      	movl	$0x100, %ecx            # imm = 0x100
    34db:      	movq	%r15, %rax
    34de:      	xorl	%edx, %edx
    34e0:      	divq	%rcx
    34e3:      	leaq	-0x3fc(%rbp,%rax,4), %rbp
    34eb:      	xorl	%eax, %eax
    34ed:      	movl	$0x80, %ecx
    34f2:      	cqto
    34f4:      	idivq	%rcx
    34f7:      	movq	0x90(%rsp), %rax
    34ff:      	leaq	(%rax,%rdx,4), %rdi
    3503:      	movl	$0x200, %eax            # imm = 0x200
    3508:      	movl	$0x70, %ecx
    350d:      	movl	$0x200, %esi            # imm = 0x200
    3512:      	movq	%rbp, %rdx
    3515:      	callq	*%rcx
    3517:      	testq	%rax, %rax
    351a:      	je	0x3551 <perf_unwind_dotnet+0x3551>
    351c:      	movq	(%rip), %rax            # 0x3523 <perf_unwind_dotnet+0x3523>
    3523:      	cmpl	$0x0, (%rax)
    3526:      	jne	0x3726 <perf_unwind_dotnet+0x3726>
    352c:      	movl	$0x5e, 0xc(%rsp)
    3534:      	movq	(%rip), %rdi            # 0x353b <perf_unwind_dotnet+0x353b>
    353b:      	leaq	0xc(%rsp), %rsi
    3540:      	movl	$0x1, %eax
    3545:      	callq	*%rax
    3547:      	testq	%rax, %rax
    354a:      	je	0x35bc <perf_unwind_dotnet+0x35bc>
    354c:      	incq	(%rax)
    354f:      	jmp	0x35cc <perf_unwind_dotnet+0x35cc>
    3551:      	movl	0x117c(%r14), %ebp
    3558:      	movq	(%rip), %rax            # 0x355f <perf_unwind_dotnet+0x355f>
    355f:      	cmpl	$0x0, (%rax)
    3562:      	jne	0x3e3a <perf_unwind_dotnet+0x3e3a>
    3568:      	movl	$0x20, %ecx
    356d:      	movq	%r15, %rax
    3570:      	xorl	%edx, %edx
    3572:      	divq	%rcx
    3575:      	movl	$0x8, %ecx
    357a:      	xorl	%edx, %edx
    357c:      	divq	%rcx
    357f:      	shll	$0x2, %edx
    3582:      	movb	$0x1c, %al
    3584:      	subb	%dl, %al
    3586:      	shrxl	%eax, %ebp, %r15d
    358b:      	testl	%r15d, %r15d
    358e:      	je	0x3659 <perf_unwind_dotnet+0x3659>
    3594:      	andq	$-0x20, %r13
    3598:      	movl	%r15d, %ecx
    359b:      	andl	$0xf, %ecx
    359e:      	jne	0x3a1d <perf_unwind_dotnet+0x3a1d>
    35a4:      	movl	%r15d, %ecx
    35a7:      	shrl	$0x4, %ecx
    35aa:      	andl	$0xf, %ecx
    35ad:      	je	0x3769 <perf_unwind_dotnet+0x3769>
    35b3:      	addq	$-0x20, %r13
    35b7:      	jmp	0x3a1d <perf_unwind_dotnet+0x3a1d>
    35bc:      	movq	(%rip), %rax            # 0x35c3 <perf_unwind_dotnet+0x35c3>
    35c3:      	cmpl	$0x0, (%rax)
    35c6:      	jne	0x3f46 <perf_unwind_dotnet+0x3f46>
    35cc:      	movl	$0x1772, %edx           # imm = 0x1772
    35d1:      	xorl	%ebx, %ebx
    35d3:      	movq	(%rip), %rax            # 0x35da <perf_unwind_dotnet+0x35da>
    35da:      	cmpl	$0x0, (%rax)
    35dd:      	jne	0x46f9 <perf_unwind_dotnet+0x46f9>
    35e3:      	movl	$0x1772, %eax           # imm = 0x1772
    35e8:      	testb	%bl, %bl
    35ea:      	movq	0x60(%rsp), %r15
    35ef:      	movq	(%rip), %rbp            # 0x35f6 <perf_unwind_dotnet+0x35f6>
    35f6:      	je	0x7812 <perf_unwind_dotnet+0x7812>
    35fc:      	movl	0x2c0(%r14), %eax
    3603:      	cmpq	$0x7e, %rax
    3607:      	ja	0x52f <perf_unwind_dotnet+0x52f>
    360d:      	leal	0x1(%rax), %ecx
    3610:      	movl	%ecx, 0x2c0(%r14)
    3617:      	leaq	(%rax,%rax,2), %rax
    361b:      	movq	$0x0, 0x2d0(%r14,%rax,8)
    3627:      	movq	$0x1773, 0x2d8(%r14,%rax,8) # imm = 0x1773
    3633:      	movb	$-0x76, 0x2e0(%r14,%rax,8)
    363c:      	movl	$0x0, 0x2e1(%r14,%rax,8)
    3648:      	movl	$0x0, 0x2e4(%r14,%rax,8)
    3654:      	jmp	0x3b1d <perf_unwind_dotnet+0x3b1d>
    3659:      	andq	$-0x100, %r13
    3660:      	addq	$-0x20, %r13
    3664:      	movl	0x1178(%r14), %r15d
    366b:      	movq	(%rip), %rax            # 0x3672 <perf_unwind_dotnet+0x3672>
    3672:      	cmpl	$0x0, (%rax)
    3675:      	jne	0x40d6 <perf_unwind_dotnet+0x40d6>
    367b:      	xorl	%ecx, %ecx
    367d:      	testl	%r15d, %r15d
    3680:      	je	0x416a <perf_unwind_dotnet+0x416a>
    3686:      	movl	%ecx, %eax
    3688:      	shll	$0x8, %eax
    368b:      	subq	%rax, %r13
    368e:      	jae	0x4694 <perf_unwind_dotnet+0x4694>
    3694:      	movq	(%rip), %rax            # 0x369b <perf_unwind_dotnet+0x369b>
    369b:      	cmpl	$0x0, (%rax)
    369e:      	je	0x352c <perf_unwind_dotnet+0x352c>
    36a4:      	movabsq	$0xa657361625f63, %rax  # imm = 0xA657361625F63
    36ae:      	movq	%rax, 0x36(%rsp)
    36b3:      	movabsq	$0x5f637020776f6c65, %rax # imm = 0x5F637020776F6C65
    36bd:      	movq	%rax, 0x30(%rsp)
    36c2:      	movabsq	$0x6220746e65772068, %rax # imm = 0x6220746E65772068
    36cc:      	movq	%rax, 0x28(%rsp)
    36d1:      	movabsq	$0x6372616573207061, %rax # imm = 0x6372616573207061
    36db:      	movq	%rax, 0x20(%rsp)
    36e0:      	movabsq	$0x6d20656c6262696e, %rax # imm = 0x6D20656C6262696E
    36ea:      	movq	%rax, 0x18(%rsp)
    36ef:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    36f9:      	movq	%rax, 0x10(%rsp)
    36fe:      	leaq	0x10(%rsp), %rdi
    3703:      	movl	$0x2e, %eax
    3708:      	movl	$0x6, %ecx
    370d:      	movl	$0x2e, %esi
    3712:      	xorl	%eax, %eax
    3714:      	callq	*%rcx
    3716:      	movq	(%rip), %rax            # 0x371d <perf_unwind_dotnet+0x371d>
    371d:      	cmpl	$0x0, (%rax)
    3720:      	je	0x352c <perf_unwind_dotnet+0x352c>
    3726:      	movabsq	$0x6e756f6620746f6e, %rax # imm = 0x6E756F6620746F6E
    3730:      	movq	%rax, 0x18(%rsp)
    3735:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    373f:      	movq	%rax, 0x10(%rsp)
    3744:      	movl	$0xa646e, 0x1f(%rsp)    # imm = 0xA646E
    374c:      	leaq	0x10(%rsp), %rdi
    3751:      	movl	$0x13, %eax
    3756:      	movl	$0x6, %ecx
    375b:      	movl	$0x13, %esi
    3760:      	xorl	%eax, %eax
    3762:      	callq	*%rcx
    3764:      	jmp	0x352c <perf_unwind_dotnet+0x352c>
    3769:      	movl	%r15d, %ecx
    376c:      	shrl	$0x8, %ecx
    376f:      	andl	$0xf, %ecx
    3772:      	je	0x377d <perf_unwind_dotnet+0x377d>
    3774:      	addq	$-0x40, %r13
    3778:      	jmp	0x3a1d <perf_unwind_dotnet+0x3a1d>
    377d:      	movl	%r15d, %ecx
    3780:      	shrl	$0xc, %ecx
    3783:      	andl	$0xf, %ecx
    3786:      	je	0x3806 <perf_unwind_dotnet+0x3806>
    3788:      	addq	$-0x60, %r13
    378c:      	jmp	0x3a1d <perf_unwind_dotnet+0x3a1d>
    3791:      	movabsq	$0x6c25203a7066202c, %rax # imm = 0x6C25203A7066202C
    379b:      	movq	%rax, 0x28(%rsp)
    37a0:      	movabsq	$0x786c25203a707320, %rax # imm = 0x786C25203A707320
    37aa:      	movq	%rax, 0x20(%rsp)
    37af:      	movabsq	$0x2c786c25203a6370, %rax # imm = 0x2C786C25203A6370
    37b9:      	movq	%rax, 0x18(%rsp)
    37be:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    37c8:      	movq	%rax, 0x10(%rsp)
    37cd:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    37d5:      	leaq	0x10(%rsp), %rdi
    37da:      	movl	$0x23, %eax
    37df:      	movl	$0x6, %r9d
    37e5:      	movl	$0x23, %esi
    37ea:      	movq	%r12, %rdx
    37ed:      	movq	%rbx, %rcx
    37f0:      	movq	%r13, %r8
    37f3:      	xorl	%eax, %eax
    37f5:      	callq	*%r9
    37f8:      	cmpq	%rbx, %r13
    37fb:      	jae	0x33b3 <perf_unwind_dotnet+0x33b3>
    3801:      	jmp	0x77bb <perf_unwind_dotnet+0x77bb>
    3806:      	movl	%r15d, %ecx
    3809:      	shrl	$0x10, %ecx
    380c:      	andl	$0xf, %ecx
    380f:      	je	0x381a <perf_unwind_dotnet+0x381a>
    3811:      	addq	$-0x80, %r13
    3815:      	jmp	0x3a1d <perf_unwind_dotnet+0x3a1d>
    381a:      	movl	%r15d, %ecx
    381d:      	shrl	$0x14, %ecx
    3820:      	andl	$0xf, %ecx
    3823:      	je	0x3935 <perf_unwind_dotnet+0x3935>
    3829:      	addq	$-0xa0, %r13
    3830:      	jmp	0x3a1d <perf_unwind_dotnet+0x3a1d>
    3835:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    383f:      	movq	%rax, 0x36(%rsp)
    3844:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    384e:      	movq	%rax, 0x30(%rsp)
    3853:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    385d:      	movq	%rax, 0x28(%rsp)
    3862:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    386c:      	movq	%rax, 0x20(%rsp)
    3871:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    387b:      	movq	%rax, 0x18(%rsp)
    3880:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    388a:      	movq	%rax, 0x10(%rsp)
    388f:      	leaq	0x10(%rsp), %rdi
    3894:      	movl	$0x2e, %eax
    3899:      	movl	$0x6, %ecx
    389e:      	movl	0xc(%rsp), %edx
    38a2:      	movl	$0x2e, %esi
    38a7:      	xorl	%eax, %eax
    38a9:      	callq	*%rcx
    38ab:      	jmp	0x31a7 <perf_unwind_dotnet+0x31a7>
    38b0:      	movabsq	$0x6c25203a7066202c, %rax # imm = 0x6C25203A7066202C
    38ba:      	movq	%rax, 0x28(%rsp)
    38bf:      	movabsq	$0x786c25203a707320, %rax # imm = 0x786C25203A707320
    38c9:      	movq	%rax, 0x20(%rsp)
    38ce:      	movabsq	$0x2c786c25203a6370, %rax # imm = 0x2C786C25203A6370
    38d8:      	movq	%rax, 0x18(%rsp)
    38dd:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    38e7:      	movq	%rax, 0x10(%rsp)
    38ec:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    38f4:      	leaq	0x10(%rsp), %rdi
    38f9:      	movl	$0x23, %eax
    38fe:      	movl	$0x6, %r9d
    3904:      	movq	0xed0(%r14), %rdx
    390b:      	movq	0xed8(%r14), %rcx
    3912:      	movq	0xee0(%r14), %r8
    3919:      	movl	$0x23, %esi
    391e:      	xorl	%eax, %eax
    3920:      	callq	*%r9
    3923:      	cmpq	$0x100, %rbp            # imm = 0x100
    392a:      	jae	0x3491 <perf_unwind_dotnet+0x3491>
    3930:      	jmp	0x3a6a <perf_unwind_dotnet+0x3a6a>
    3935:      	movl	%r15d, %ecx
    3938:      	shrl	$0x18, %ecx
    393b:      	andl	$0xf, %ecx
    393e:      	je	0x3a0f <perf_unwind_dotnet+0x3a0f>
    3944:      	addq	$-0xc0, %r13
    394b:      	jmp	0x3a1d <perf_unwind_dotnet+0x3a1d>
    3950:      	leaq	(%rip), %rsi            # 0x3957 <perf_unwind_dotnet+0x3957>
    3957:      	leaq	0x10(%rsp), %rax
    395c:      	movl	$0x8, %ecx
    3961:      	movq	%rax, %rdi
    3964:      	rep		movsq	(%rsi), %es:(%rdi)
    3967:      	movw	$0xa, 0x50(%rsp)
    396e:      	movl	$0x42, %ecx
    3973:      	movl	$0x6, %r9d
    3979:      	movq	%rax, %rdi
    397c:      	movl	$0x42, %esi
    3981:      	movq	%r13, %rdx
    3984:      	movq	%rbx, %rcx
    3987:      	movq	%rbp, %r8
    398a:      	xorl	%eax, %eax
    398c:      	callq	*%r9
    398f:      	jmp	0x34b5 <perf_unwind_dotnet+0x34b5>
    3994:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    399e:      	movq	%rax, 0x36(%rsp)
    39a3:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    39ad:      	movq	%rax, 0x30(%rsp)
    39b2:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    39bc:      	movq	%rax, 0x28(%rsp)
    39c1:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    39cb:      	movq	%rax, 0x20(%rsp)
    39d0:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    39da:      	movq	%rax, 0x18(%rsp)
    39df:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    39e9:      	movq	%rax, 0x10(%rsp)
    39ee:      	leaq	0x10(%rsp), %rdi
    39f3:      	movl	$0x2e, %eax
    39f8:      	movl	$0x6, %ecx
    39fd:      	movl	0x68(%rsp), %edx
    3a01:      	movl	$0x2e, %esi
    3a06:      	xorl	%eax, %eax
    3a08:      	callq	*%rcx
    3a0a:      	jmp	0x3367 <perf_unwind_dotnet+0x3367>
    3a0f:      	shrl	$0x1c, %r15d
    3a13:      	addq	$-0xe0, %r13
    3a1a:      	movl	%r15d, %ecx
    3a1d:      	addq	%r13, %rbx
    3a20:      	leal	-0x4(,%rcx,4), %r15d
    3a28:      	addq	%rbx, %r15
    3a2b:      	movq	(%rip), %rax            # 0x3a32 <perf_unwind_dotnet+0x3a32>
    3a32:      	cmpl	$0x0, (%rax)
    3a35:      	jne	0x3ec7 <perf_unwind_dotnet+0x3ec7>
    3a3b:      	leaq	-0x8(%r15), %rdx
    3a3f:      	leaq	0x68(%rsp), %rdi
    3a44:      	movl	$0x8, %eax
    3a49:      	movl	$0x70, %ecx
    3a4e:      	movl	$0x8, %esi
    3a53:      	callq	*%rcx
    3a55:      	testq	%rax, %rax
    3a58:      	movq	(%rip), %rbp            # 0x3a5f <perf_unwind_dotnet+0x3a5f>
    3a5f:      	jne	0xbb6 <perf_unwind_dotnet+0xbb6>
    3a65:      	movl	$0x1f, %ebp
    3a6a:      	movq	(%rip), %rax            # 0x3a71 <perf_unwind_dotnet+0x3a71>
    3a71:      	cmpl	$0x0, (%rax)
    3a74:      	jne	0x3cc3 <perf_unwind_dotnet+0x3cc3>
    3a7a:      	movl	0x2c0(%r14), %eax
    3a81:      	cmpq	$0x7e, %rax
    3a85:      	ja	0xc0c <perf_unwind_dotnet+0xc0c>
    3a8b:      	movq	0x68(%rsp), %rcx
    3a90:      	subq	%r15, %r12
    3a93:      	shlq	$0x5, %rcx
    3a97:      	addq	%rbp, %rcx
    3a9a:      	leal	0x1(%rax), %edx
    3a9d:      	movl	%edx, 0x2c0(%r14)
    3aa4:      	leaq	(%rax,%rax,2), %rax
    3aa8:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    3ab0:      	movq	%r12, 0x2d8(%r14,%rax,8)
    3ab8:      	movb	$0xa, 0x2e0(%r14,%rax,8)
    3ac1:      	movzbl	0x88(%rsp), %ecx
    3ac9:      	movb	%cl, 0x2e1(%r14,%rax,8)
    3ad1:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    3add:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    3ae8:      	movl	$0x5b, 0xc(%rsp)
    3af0:      	movq	(%rip), %rdi            # 0x3af7 <perf_unwind_dotnet+0x3af7>
    3af7:      	leaq	0xc(%rsp), %rsi
    3afc:      	movl	$0x1, %eax
    3b01:      	callq	*%rax
    3b03:      	testq	%rax, %rax
    3b06:      	je	0x3b0d <perf_unwind_dotnet+0x3b0d>
    3b08:      	incq	(%rax)
    3b0b:      	jmp	0x3b1d <perf_unwind_dotnet+0x3b1d>
    3b0d:      	movq	(%rip), %rax            # 0x3b14 <perf_unwind_dotnet+0x3b14>
    3b14:      	cmpl	$0x0, (%rax)
    3b17:      	jne	0x3dbf <perf_unwind_dotnet+0x3dbf>
    3b1d:      	movq	0x98(%rsp), %rax
    3b25:      	movq	(%rax), %r13
    3b28:      	movq	(%rip), %rax            # 0x3b2f <perf_unwind_dotnet+0x3b2f>
    3b2f:      	movl	(%rax), %eax
    3b31:      	testq	%r13, %r13
    3b34:      	je	0x88ec <perf_unwind_dotnet+0x88ec>
    3b3a:      	testl	%eax, %eax
    3b3c:      	jne	0x3d22 <perf_unwind_dotnet+0x3d22>
    3b42:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    3b4c:      	cmpq	%rax, %r13
    3b4f:      	ja	0x2516 <perf_unwind_dotnet+0x2516>
    3b55:      	cmpq	$0x1000, %r13           # imm = 0x1000
    3b5c:      	jb	0x26b1 <perf_unwind_dotnet+0x26b1>
    3b62:      	movl	(%r14), %eax
    3b65:      	movl	$0x60, 0x70(%rsp)
    3b6d:      	movbel	%eax, 0x74(%rsp)
    3b73:      	movbeq	%r13, 0x78(%rsp)
    3b7a:      	movq	(%rip), %rdi            # 0x3b81 <perf_unwind_dotnet+0x3b81>
    3b81:      	leaq	0x70(%rsp), %rsi
    3b86:      	movl	$0x1, %eax
    3b8b:      	callq	*%rax
    3b8d:      	testq	%rax, %rax
    3b90:      	je	0x8837 <perf_unwind_dotnet+0x8837>
    3b96:      	movq	0x8(%rax), %r12
    3b9a:      	movq	%r12, %rcx
    3b9d:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    3ba7:      	andq	%rdx, %rcx
    3baa:      	movq	%rcx, 0xf20(%r14)
    3bb1:      	movq	(%rax), %rax
    3bb4:      	movq	%rax, 0xf10(%r14)
    3bbb:      	shrq	$0x38, %r12
    3bbf:      	movq	%r13, %rax
    3bc2:      	subq	%rcx, %rax
    3bc5:      	movq	%rax, 0xf18(%r14)
    3bcc:      	movq	(%rip), %rax            # 0x3bd3 <perf_unwind_dotnet+0x3bd3>
    3bd3:      	cmpl	$0x0, (%rax)
    3bd6:      	jne	0x3fc1 <perf_unwind_dotnet+0x3fc1>
    3bdc:      	cmpl	$0x1, %r12d
    3be0:      	jne	0x48a7 <perf_unwind_dotnet+0x48a7>
    3be6:      	movq	0xf10(%r14), %rax
    3bed:      	movq	%rax, 0x70(%rsp)
    3bf2:      	movq	0xf18(%r14), %rbx
    3bf9:      	movq	(%rip), %rdi            # 0x3c00 <perf_unwind_dotnet+0x3c00>
    3c00:      	leaq	0x70(%rsp), %rsi
    3c05:      	movl	$0x1, %eax
    3c0a:      	callq	*%rax
    3c0c:      	movl	$0x1, %r12d
    3c12:      	testq	%rax, %rax
    3c15:      	je	0x48a7 <perf_unwind_dotnet+0x48a7>
    3c1b:      	movq	%rax, %r15
    3c1e:      	cmpq	%rbx, (%rax)
    3c21:      	ja	0x3c29 <perf_unwind_dotnet+0x3c29>
    3c23:      	cmpq	%rbx, 0x8(%r15)
    3c27:      	jae	0x3c3d <perf_unwind_dotnet+0x3c3d>
    3c29:      	cmpq	%rbx, 0x10(%r15)
    3c2d:      	ja	0x48a7 <perf_unwind_dotnet+0x48a7>
    3c33:      	cmpq	%rbx, 0x18(%r15)
    3c37:      	jb	0x48a7 <perf_unwind_dotnet+0x48a7>
    3c3d:      	movq	(%rip), %rax            # 0x3c44 <perf_unwind_dotnet+0x3c44>
    3c44:      	cmpl	$0x0, (%rax)
    3c47:      	jne	0x4800 <perf_unwind_dotnet+0x4800>
    3c4d:      	movl	0x1380(%r14), %eax
    3c54:      	movl	0x20(%r15), %ecx
    3c58:      	btl	%ecx, %eax
    3c5b:      	jae	0x486d <perf_unwind_dotnet+0x486d>
    3c61:      	movq	(%rip), %rax            # 0x3c68 <perf_unwind_dotnet+0x3c68>
    3c68:      	cmpl	$0x0, (%rax)
    3c6b:      	je	0x48a7 <perf_unwind_dotnet+0x48a7>
    3c71:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    3c7b:      	movq	%rax, 0x20(%rsp)
    3c80:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    3c8a:      	movq	%rax, 0x18(%rsp)
    3c8f:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    3c99:      	movq	%rax, 0x10(%rsp)
    3c9e:      	movl	$0xa656e, 0x27(%rsp)    # imm = 0xA656E
    3ca6:      	leaq	0x10(%rsp), %rdi
    3cab:      	movl	$0x1b, %eax
    3cb0:      	movl	$0x6, %ecx
    3cb5:      	movl	$0x1b, %esi
    3cba:      	xorl	%eax, %eax
    3cbc:      	callq	*%rcx
    3cbe:      	jmp	0x48a7 <perf_unwind_dotnet+0x48a7>
    3cc3:      	leaq	(%rip), %rsi            # 0x3cca <perf_unwind_dotnet+0x3cca>
    3cca:      	leaq	0x10(%rsp), %rax
    3ccf:      	movl	$0x8, %ecx
    3cd4:      	movq	%rax, %rdi
    3cd7:      	rep		movsq	(%rsi), %es:(%rdi)
    3cda:      	movb	$0x0, 0x52(%rsp)
    3cdf:      	movw	$0xa78, 0x50(%rsp)      # imm = 0xA78
    3ce6:      	movl	$0x43, %ecx
    3ceb:      	movl	$0x6, %r9d
    3cf1:      	movq	0x68(%rsp), %rcx
    3cf6:      	movq	%r12, %r8
    3cf9:      	subq	%r15, %r8
    3cfc:      	movq	%rax, %rdi
    3cff:      	movl	$0x43, %esi
    3d04:      	movq	%r15, %rdx
    3d07:      	xorl	%eax, %eax
    3d09:      	callq	*%r9
    3d0c:      	movl	0x2c0(%r14), %eax
    3d13:      	cmpq	$0x7e, %rax
    3d17:      	ja	0xc0c <perf_unwind_dotnet+0xc0c>
    3d1d:      	jmp	0x3a8b <perf_unwind_dotnet+0x3a8b>
    3d22:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    3d2c:      	movq	%rax, 0x38(%rsp)
    3d31:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    3d3b:      	movq	%rax, 0x30(%rsp)
    3d40:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    3d4a:      	movq	%rax, 0x28(%rsp)
    3d4f:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    3d59:      	movq	%rax, 0x20(%rsp)
    3d5e:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    3d68:      	movq	%rax, 0x18(%rsp)
    3d6d:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    3d77:      	movq	%rax, 0x10(%rsp)
    3d7c:      	movb	$0x0, 0x40(%rsp)
    3d81:      	leaq	0x10(%rsp), %rdi
    3d86:      	movl	$0x31, %eax
    3d8b:      	movl	$0x6, %ecx
    3d90:      	movl	0x2c0(%r14), %edx
    3d97:      	movl	$0x31, %esi
    3d9c:      	xorl	%eax, %eax
    3d9e:      	callq	*%rcx
    3da0:      	movq	0xed0(%r14), %r13
    3da7:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    3db1:      	cmpq	%rax, %r13
    3db4:      	ja	0x2516 <perf_unwind_dotnet+0x2516>
    3dba:      	jmp	0x3b55 <perf_unwind_dotnet+0x3b55>
    3dbf:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3dc9:      	movq	%rax, 0x36(%rsp)
    3dce:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3dd8:      	movq	%rax, 0x30(%rsp)
    3ddd:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3de7:      	movq	%rax, 0x28(%rsp)
    3dec:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3df6:      	movq	%rax, 0x20(%rsp)
    3dfb:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3e05:      	movq	%rax, 0x18(%rsp)
    3e0a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3e14:      	movq	%rax, 0x10(%rsp)
    3e19:      	leaq	0x10(%rsp), %rdi
    3e1e:      	movl	$0x2e, %eax
    3e23:      	movl	$0x6, %ecx
    3e28:      	movl	0xc(%rsp), %edx
    3e2c:      	movl	$0x2e, %esi
    3e31:      	xorl	%eax, %eax
    3e33:      	callq	*%rcx
    3e35:      	jmp	0x3b1d <perf_unwind_dotnet+0x3b1d>
    3e3a:      	movabsq	$0xa782520797274, %rax  # imm = 0xA782520797274
    3e44:      	movq	%rax, 0x3e(%rsp)
    3e49:      	movabsq	$0x72746e6520747372, %rax # imm = 0x72746E6520747372
    3e53:      	movq	%rax, 0x38(%rsp)
    3e58:      	movabsq	$0x6966203a786c2520, %rax # imm = 0x6966203A786C2520
    3e62:      	movq	%rax, 0x30(%rsp)
    3e67:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    3e71:      	movq	%rax, 0x28(%rsp)
    3e76:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    3e80:      	movq	%rax, 0x20(%rsp)
    3e85:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    3e8f:      	movq	%rax, 0x18(%rsp)
    3e94:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    3e9e:      	movq	%rax, 0x10(%rsp)
    3ea3:      	leaq	0x10(%rsp), %rdi
    3ea8:      	movl	$0x36, %eax
    3ead:      	movl	$0x6, %r8d
    3eb3:      	movl	$0x36, %esi
    3eb8:      	movq	%r15, %rdx
    3ebb:      	movl	%ebp, %ecx
    3ebd:      	xorl	%eax, %eax
    3ebf:      	callq	*%r8
    3ec2:      	jmp	0x3568 <perf_unwind_dotnet+0x3568>
    3ec7:      	movabsq	$0xa786c253d7465, %rax  # imm = 0xA786C253D7465
    3ed1:      	movq	%rax, 0x36(%rsp)
    3ed6:      	movabsq	$0x746572202c78253d, %rax # imm = 0x746572202C78253D
    3ee0:      	movq	%rax, 0x30(%rsp)
    3ee5:      	movabsq	$0x6c6176202c786c25, %rax # imm = 0x6C6176202C786C25
    3eef:      	movq	%rax, 0x28(%rsp)
    3ef4:      	movabsq	$0x203d2061746c6564, %rax # imm = 0x203D2061746C6564
    3efe:      	movq	%rax, 0x20(%rsp)
    3f03:      	movabsq	$0x5f6370203e2d2d20, %rax # imm = 0x5F6370203E2D2D20
    3f0d:      	movq	%rax, 0x18(%rsp)
    3f12:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    3f1c:      	movq	%rax, 0x10(%rsp)
    3f21:      	leaq	0x10(%rsp), %rdi
    3f26:      	movl	$0x2e, %eax
    3f2b:      	movl	$0x6, %r9d
    3f31:      	movl	$0x2e, %esi
    3f36:      	movq	%r13, %rdx
    3f39:      	movq	%r15, %r8
    3f3c:      	xorl	%eax, %eax
    3f3e:      	callq	*%r9
    3f41:      	jmp	0x3a3b <perf_unwind_dotnet+0x3a3b>
    3f46:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3f50:      	movq	%rax, 0x36(%rsp)
    3f55:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3f5f:      	movq	%rax, 0x30(%rsp)
    3f64:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3f6e:      	movq	%rax, 0x28(%rsp)
    3f73:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3f7d:      	movq	%rax, 0x20(%rsp)
    3f82:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3f8c:      	movq	%rax, 0x18(%rsp)
    3f91:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3f9b:      	movq	%rax, 0x10(%rsp)
    3fa0:      	leaq	0x10(%rsp), %rdi
    3fa5:      	movl	$0x2e, %eax
    3faa:      	movl	$0x6, %ecx
    3faf:      	movl	0xc(%rsp), %edx
    3fb3:      	movl	$0x2e, %esi
    3fb8:      	xorl	%eax, %eax
    3fba:      	callq	*%rcx
    3fbc:      	jmp	0x35cc <perf_unwind_dotnet+0x35cc>
    3fc1:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    3fcb:      	movq	%rax, 0x38(%rsp)
    3fd0:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    3fda:      	movq	%rax, 0x30(%rsp)
    3fdf:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    3fe9:      	movq	%rax, 0x28(%rsp)
    3fee:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    3ff8:      	movq	%rax, 0x20(%rsp)
    3ffd:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    4007:      	movq	%rax, 0x18(%rsp)
    400c:      	movabsq	$0x6365732074786554, %rbx # imm = 0x6365732074786554
    4016:      	movq	%rbx, 0x10(%rsp)
    401b:      	movw	$0xa, 0x40(%rsp)
    4022:      	leaq	0x10(%rsp), %rdi
    4027:      	movl	$0x32, %eax
    402c:      	movl	$0x6, %r9d
    4032:      	movq	0xf10(%r14), %rcx
    4039:      	movl	$0x32, %esi
    403e:      	movq	%r13, %rdx
    4041:      	movl	%r12d, %r8d
    4044:      	xorl	%eax, %eax
    4046:      	callq	*%r9
    4049:      	movq	(%rip), %rax            # 0x4050 <perf_unwind_dotnet+0x4050>
    4050:      	cmpl	$0x0, (%rax)
    4053:      	je	0x3bdc <perf_unwind_dotnet+0x3bdc>
    4059:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    4063:      	movq	%rax, 0x37(%rsp)
    4068:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    4072:      	movq	%rax, 0x30(%rsp)
    4077:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    4081:      	movq	%rax, 0x28(%rsp)
    4086:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    4090:      	movq	%rax, 0x20(%rsp)
    4095:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    409f:      	movq	%rax, 0x18(%rsp)
    40a4:      	movq	%rbx, 0x10(%rsp)
    40a9:      	leaq	0x10(%rsp), %rdi
    40ae:      	movl	$0x2f, %eax
    40b3:      	movl	$0x6, %r8d
    40b9:      	movq	0xf18(%r14), %rcx
    40c0:      	movq	0xf20(%r14), %rdx
    40c7:      	movl	$0x2f, %esi
    40cc:      	xorl	%eax, %eax
    40ce:      	callq	*%r8
    40d1:      	jmp	0x3bdc <perf_unwind_dotnet+0x3bdc>
    40d6:      	movabsq	$0xa782520797274, %rax  # imm = 0xA782520797274
    40e0:      	movq	%rax, 0x3f(%rsp)
    40e5:      	movabsq	$0x746e6520646e6f63, %rax # imm = 0x746E6520646E6F63
    40ef:      	movq	%rax, 0x38(%rsp)
    40f4:      	movabsq	$0x6573203a786c2520, %rax # imm = 0x6573203A786C2520
    40fe:      	movq	%rax, 0x30(%rsp)
    4103:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    410d:      	movq	%rax, 0x28(%rsp)
    4112:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    411c:      	movq	%rax, 0x20(%rsp)
    4121:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    412b:      	movq	%rax, 0x18(%rsp)
    4130:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    413a:      	movq	%rax, 0x10(%rsp)
    413f:      	leaq	0x10(%rsp), %rdi
    4144:      	movl	$0x37, %eax
    4149:      	movl	$0x6, %r8d
    414f:      	movl	$0x37, %esi
    4154:      	movq	%r13, %rdx
    4157:      	movl	%r15d, %ecx
    415a:      	xorl	%eax, %eax
    415c:      	callq	*%r8
    415f:      	xorl	%ecx, %ecx
    4161:      	testl	%r15d, %r15d
    4164:      	jne	0x3686 <perf_unwind_dotnet+0x3686>
    416a:      	movq	0x1170(%r14), %rax
    4171:      	movl	$0xffffff84, %ecx       # imm = 0xFFFFFF84
    4176:      	testq	%rax, %rax
    4179:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    417f:      	movq	0x1168(%r14), %rax
    4186:      	movl	$0xffffff86, %ecx       # imm = 0xFFFFFF86
    418b:      	testq	%rax, %rax
    418e:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    4194:      	movq	0x1160(%r14), %rax
    419b:      	movl	$0xffffff88, %ecx       # imm = 0xFFFFFF88
    41a0:      	testq	%rax, %rax
    41a3:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    41a9:      	movq	0x1158(%r14), %rax
    41b0:      	movl	$0xffffff8a, %ecx       # imm = 0xFFFFFF8A
    41b5:      	testq	%rax, %rax
    41b8:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    41be:      	movq	0x1150(%r14), %rax
    41c5:      	movl	$0xffffff8c, %ecx       # imm = 0xFFFFFF8C
    41ca:      	testq	%rax, %rax
    41cd:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    41d3:      	movq	0x1148(%r14), %rax
    41da:      	movl	$0xffffff8e, %ecx       # imm = 0xFFFFFF8E
    41df:      	testq	%rax, %rax
    41e2:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    41e8:      	movq	0x1140(%r14), %rax
    41ef:      	movl	$0xffffff90, %ecx       # imm = 0xFFFFFF90
    41f4:      	testq	%rax, %rax
    41f7:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    41fd:      	movq	0x1138(%r14), %rax
    4204:      	movl	$0xffffff92, %ecx       # imm = 0xFFFFFF92
    4209:      	testq	%rax, %rax
    420c:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    4212:      	movq	0x1130(%r14), %rax
    4219:      	movl	$0xffffff94, %ecx       # imm = 0xFFFFFF94
    421e:      	testq	%rax, %rax
    4221:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    4227:      	movq	0x1128(%r14), %rax
    422e:      	movl	$0xffffff96, %ecx       # imm = 0xFFFFFF96
    4233:      	testq	%rax, %rax
    4236:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    423c:      	movq	0x1120(%r14), %rax
    4243:      	movl	$0xffffff98, %ecx       # imm = 0xFFFFFF98
    4248:      	testq	%rax, %rax
    424b:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    4251:      	movq	0x1118(%r14), %rax
    4258:      	movl	$0xffffff9a, %ecx       # imm = 0xFFFFFF9A
    425d:      	testq	%rax, %rax
    4260:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    4266:      	movq	0x1110(%r14), %rax
    426d:      	movl	$0xffffff9c, %ecx       # imm = 0xFFFFFF9C
    4272:      	testq	%rax, %rax
    4275:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    427b:      	movq	0x1108(%r14), %rax
    4282:      	movl	$0xffffff9e, %ecx       # imm = 0xFFFFFF9E
    4287:      	testq	%rax, %rax
    428a:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    4290:      	movq	0x1100(%r14), %rax
    4297:      	movl	$0xffffffa0, %ecx       # imm = 0xFFFFFFA0
    429c:      	testq	%rax, %rax
    429f:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    42a5:      	movq	0x10f8(%r14), %rax
    42ac:      	movl	$0xffffffa2, %ecx       # imm = 0xFFFFFFA2
    42b1:      	testq	%rax, %rax
    42b4:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    42ba:      	movq	0x10f0(%r14), %rax
    42c1:      	movl	$0xffffffa4, %ecx       # imm = 0xFFFFFFA4
    42c6:      	testq	%rax, %rax
    42c9:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    42cf:      	movq	0x10e8(%r14), %rax
    42d6:      	movl	$0xffffffa6, %ecx       # imm = 0xFFFFFFA6
    42db:      	testq	%rax, %rax
    42de:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    42e4:      	movq	0x10e0(%r14), %rax
    42eb:      	movl	$0xffffffa8, %ecx       # imm = 0xFFFFFFA8
    42f0:      	testq	%rax, %rax
    42f3:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    42f9:      	movq	0x10d8(%r14), %rax
    4300:      	movl	$0xffffffaa, %ecx       # imm = 0xFFFFFFAA
    4305:      	testq	%rax, %rax
    4308:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    430e:      	movq	0x10d0(%r14), %rax
    4315:      	movl	$0xffffffac, %ecx       # imm = 0xFFFFFFAC
    431a:      	testq	%rax, %rax
    431d:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    4323:      	movq	0x10c8(%r14), %rax
    432a:      	movl	$0xffffffae, %ecx       # imm = 0xFFFFFFAE
    432f:      	testq	%rax, %rax
    4332:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    4338:      	movq	0x10c0(%r14), %rax
    433f:      	movl	$0xffffffb0, %ecx       # imm = 0xFFFFFFB0
    4344:      	testq	%rax, %rax
    4347:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    434d:      	movq	0x10b8(%r14), %rax
    4354:      	movl	$0xffffffb2, %ecx       # imm = 0xFFFFFFB2
    4359:      	testq	%rax, %rax
    435c:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    4362:      	movq	0x10b0(%r14), %rax
    4369:      	movl	$0xffffffb4, %ecx       # imm = 0xFFFFFFB4
    436e:      	testq	%rax, %rax
    4371:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    4377:      	movq	0x10a8(%r14), %rax
    437e:      	movl	$0xffffffb6, %ecx       # imm = 0xFFFFFFB6
    4383:      	testq	%rax, %rax
    4386:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    438c:      	movq	0x10a0(%r14), %rax
    4393:      	movl	$0xffffffb8, %ecx       # imm = 0xFFFFFFB8
    4398:      	testq	%rax, %rax
    439b:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    43a1:      	movq	0x1098(%r14), %rax
    43a8:      	movl	$0xffffffba, %ecx       # imm = 0xFFFFFFBA
    43ad:      	testq	%rax, %rax
    43b0:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    43b6:      	movq	0x1090(%r14), %rax
    43bd:      	movl	$0xffffffbc, %ecx       # imm = 0xFFFFFFBC
    43c2:      	testq	%rax, %rax
    43c5:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    43cb:      	movq	0x1088(%r14), %rax
    43d2:      	movl	$0xffffffbe, %ecx       # imm = 0xFFFFFFBE
    43d7:      	testq	%rax, %rax
    43da:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    43e0:      	movq	0x1080(%r14), %rax
    43e7:      	movl	$0xffffffc0, %ecx       # imm = 0xFFFFFFC0
    43ec:      	testq	%rax, %rax
    43ef:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    43f5:      	movq	0x1078(%r14), %rax
    43fc:      	movl	$0xffffffc2, %ecx       # imm = 0xFFFFFFC2
    4401:      	testq	%rax, %rax
    4404:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    440a:      	movq	0x1070(%r14), %rax
    4411:      	movl	$0xffffffc4, %ecx       # imm = 0xFFFFFFC4
    4416:      	testq	%rax, %rax
    4419:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    441f:      	movq	0x1068(%r14), %rax
    4426:      	movl	$0xffffffc6, %ecx       # imm = 0xFFFFFFC6
    442b:      	testq	%rax, %rax
    442e:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    4434:      	movq	0x1060(%r14), %rax
    443b:      	movl	$0xffffffc8, %ecx       # imm = 0xFFFFFFC8
    4440:      	testq	%rax, %rax
    4443:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    4449:      	movq	0x1058(%r14), %rax
    4450:      	movl	$0xffffffca, %ecx       # imm = 0xFFFFFFCA
    4455:      	testq	%rax, %rax
    4458:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    445e:      	movq	0x1050(%r14), %rax
    4465:      	movl	$0xffffffcc, %ecx       # imm = 0xFFFFFFCC
    446a:      	testq	%rax, %rax
    446d:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    4473:      	movq	0x1048(%r14), %rax
    447a:      	movl	$0xffffffce, %ecx       # imm = 0xFFFFFFCE
    447f:      	testq	%rax, %rax
    4482:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    4488:      	movq	0x1040(%r14), %rax
    448f:      	movl	$0xffffffd0, %ecx       # imm = 0xFFFFFFD0
    4494:      	testq	%rax, %rax
    4497:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    449d:      	movq	0x1038(%r14), %rax
    44a4:      	movl	$0xffffffd2, %ecx       # imm = 0xFFFFFFD2
    44a9:      	testq	%rax, %rax
    44ac:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    44b2:      	movq	0x1030(%r14), %rax
    44b9:      	movl	$0xffffffd4, %ecx       # imm = 0xFFFFFFD4
    44be:      	testq	%rax, %rax
    44c1:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    44c7:      	movq	0x1028(%r14), %rax
    44ce:      	movl	$0xffffffd6, %ecx       # imm = 0xFFFFFFD6
    44d3:      	testq	%rax, %rax
    44d6:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    44dc:      	movq	0x1020(%r14), %rax
    44e3:      	movl	$0xffffffd8, %ecx       # imm = 0xFFFFFFD8
    44e8:      	testq	%rax, %rax
    44eb:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    44f1:      	movq	0x1018(%r14), %rax
    44f8:      	movl	$0xffffffda, %ecx       # imm = 0xFFFFFFDA
    44fd:      	testq	%rax, %rax
    4500:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    4506:      	movq	0x1010(%r14), %rax
    450d:      	movl	$0xffffffdc, %ecx       # imm = 0xFFFFFFDC
    4512:      	testq	%rax, %rax
    4515:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    451b:      	movq	0x1008(%r14), %rax
    4522:      	movl	$0xffffffde, %ecx       # imm = 0xFFFFFFDE
    4527:      	testq	%rax, %rax
    452a:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    4530:      	movq	0x1000(%r14), %rax
    4537:      	movl	$0xffffffe0, %ecx       # imm = 0xFFFFFFE0
    453c:      	testq	%rax, %rax
    453f:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    4545:      	movq	0xff8(%r14), %rax
    454c:      	movl	$0xffffffe2, %ecx       # imm = 0xFFFFFFE2
    4551:      	testq	%rax, %rax
    4554:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    455a:      	movq	0xff0(%r14), %rax
    4561:      	movl	$0xffffffe4, %ecx       # imm = 0xFFFFFFE4
    4566:      	testq	%rax, %rax
    4569:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    456f:      	movq	0xfe8(%r14), %rax
    4576:      	movl	$0xffffffe6, %ecx       # imm = 0xFFFFFFE6
    457b:      	testq	%rax, %rax
    457e:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    4584:      	movq	0xfe0(%r14), %rax
    458b:      	movl	$0xffffffe8, %ecx       # imm = 0xFFFFFFE8
    4590:      	testq	%rax, %rax
    4593:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    4599:      	movq	0xfd8(%r14), %rax
    45a0:      	movl	$0xffffffea, %ecx       # imm = 0xFFFFFFEA
    45a5:      	testq	%rax, %rax
    45a8:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    45ae:      	movq	0xfd0(%r14), %rax
    45b5:      	movl	$0xffffffec, %ecx       # imm = 0xFFFFFFEC
    45ba:      	testq	%rax, %rax
    45bd:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    45c3:      	movq	0xfc8(%r14), %rax
    45ca:      	movl	$0xffffffee, %ecx       # imm = 0xFFFFFFEE
    45cf:      	testq	%rax, %rax
    45d2:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    45d8:      	movq	0xfc0(%r14), %rax
    45df:      	movl	$0xfffffff0, %ecx       # imm = 0xFFFFFFF0
    45e4:      	testq	%rax, %rax
    45e7:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    45ed:      	movq	0xfb8(%r14), %rax
    45f4:      	movl	$0xfffffff2, %ecx       # imm = 0xFFFFFFF2
    45f9:      	testq	%rax, %rax
    45fc:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    45fe:      	movq	0xfb0(%r14), %rax
    4605:      	movl	$0xfffffff4, %ecx       # imm = 0xFFFFFFF4
    460a:      	testq	%rax, %rax
    460d:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    460f:      	movq	0xfa8(%r14), %rax
    4616:      	movl	$0xfffffff6, %ecx       # imm = 0xFFFFFFF6
    461b:      	testq	%rax, %rax
    461e:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    4620:      	movq	0xfa0(%r14), %rax
    4627:      	movl	$0xfffffff8, %ecx       # imm = 0xFFFFFFF8
    462c:      	testq	%rax, %rax
    462f:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    4631:      	movq	0xf98(%r14), %rax
    4638:      	movl	$0xfffffffa, %ecx       # imm = 0xFFFFFFFA
    463d:      	testq	%rax, %rax
    4640:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    4642:      	movq	0xf90(%r14), %rax
    4649:      	movl	$0xfffffffc, %ecx       # imm = 0xFFFFFFFC
    464e:      	testq	%rax, %rax
    4651:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    4653:      	movq	0xf88(%r14), %rax
    465a:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    465f:      	testq	%rax, %rax
    4662:      	jne	0x4671 <perf_unwind_dotnet+0x4671>
    4664:      	movq	0x90(%rsp), %rax
    466c:      	movq	(%rax), %rax
    466f:      	xorl	%ecx, %ecx
    4671:      	xorl	%edx, %edx
    4673:      	movq	%rax, %r15
    4676:      	shrq	$0x20, %r15
    467a:      	setne	%dl
    467d:      	cmovel	%eax, %r15d
    4681:      	subl	%edx, %ecx
    4683:      	addl	$0x7e, %ecx
    4686:      	movl	%ecx, %eax
    4688:      	shll	$0x8, %eax
    468b:      	subq	%rax, %r13
    468e:      	jb	0x3694 <perf_unwind_dotnet+0x3694>
    4694:      	movq	(%rip), %rax            # 0x469b <perf_unwind_dotnet+0x469b>
    469b:      	cmpl	$0x0, (%rax)
    469e:      	jne	0x4761 <perf_unwind_dotnet+0x4761>
    46a4:      	testl	%r15d, %r15d
    46a7:      	jne	0x3598 <perf_unwind_dotnet+0x3598>
    46ad:      	movl	$0x5f, 0xc(%rsp)
    46b5:      	movq	(%rip), %rdi            # 0x46bc <perf_unwind_dotnet+0x46bc>
    46bc:      	leaq	0xc(%rsp), %rsi
    46c1:      	movl	$0x1, %eax
    46c6:      	callq	*%rax
    46c8:      	testq	%rax, %rax
    46cb:      	je	0x46d2 <perf_unwind_dotnet+0x46d2>
    46cd:      	incq	(%rax)
    46d0:      	jmp	0x46e2 <perf_unwind_dotnet+0x46e2>
    46d2:      	movq	(%rip), %rax            # 0x46d9 <perf_unwind_dotnet+0x46d9>
    46d9:      	cmpl	$0x0, (%rax)
    46dc:      	jne	0x4d70 <perf_unwind_dotnet+0x4d70>
    46e2:      	movl	$0x1773, %edx           # imm = 0x1773
    46e7:      	movb	$0x1, %bl
    46e9:      	movq	(%rip), %rax            # 0x46f0 <perf_unwind_dotnet+0x46f0>
    46f0:      	cmpl	$0x0, (%rax)
    46f3:      	je	0x35e3 <perf_unwind_dotnet+0x35e3>
    46f9:      	movabsq	$0xa642520687469, %rax  # imm = 0xA642520687469
    4703:      	movq	%rax, 0x30(%rsp)
    4708:      	movabsq	$0x772064656c696166, %rax # imm = 0x772064656C696166
    4712:      	movq	%rax, 0x28(%rsp)
    4717:      	movabsq	$0x2074726174735f65, %rax # imm = 0x2074726174735F65
    4721:      	movq	%rax, 0x20(%rsp)
    4726:      	movabsq	$0x646f63203e2d2d20, %rax # imm = 0x646F63203E2D2D20
    4730:      	movq	%rax, 0x18(%rsp)
    4735:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    473f:      	movq	%rax, 0x10(%rsp)
    4744:      	leaq	0x10(%rsp), %rdi
    4749:      	movl	$0x28, %eax
    474e:      	movl	$0x6, %ecx
    4753:      	movl	$0x28, %esi
    4758:      	xorl	%eax, %eax
    475a:      	callq	*%rcx
    475c:      	jmp	0x35e3 <perf_unwind_dotnet+0x35e3>
    4761:      	movabsq	$0x207972746e65202c, %rax # imm = 0x207972746E65202C
    476b:      	movq	%rax, 0x40(%rsp)
    4770:      	movabsq	$0x6425206465707069, %rax # imm = 0x6425206465707069
    477a:      	movq	%rax, 0x38(%rsp)
    477f:      	movabsq	$0x6b73203a786c2520, %rax # imm = 0x6B73203A786C2520
    4789:      	movq	%rax, 0x30(%rsp)
    478e:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    4798:      	movq	%rax, 0x28(%rsp)
    479d:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    47a7:      	movq	%rax, 0x20(%rsp)
    47ac:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    47b6:      	movq	%rax, 0x18(%rsp)
    47bb:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    47c5:      	movq	%rax, 0x10(%rsp)
    47ca:      	movl	$0xa7825, 0x48(%rsp)    # imm = 0xA7825
    47d2:      	leaq	0x10(%rsp), %rdi
    47d7:      	movl	$0x3c, %eax
    47dc:      	movl	$0x6, %r9d
    47e2:      	movl	$0x3c, %esi
    47e7:      	movq	%r13, %rdx
    47ea:      	movl	%r15d, %r8d
    47ed:      	xorl	%eax, %eax
    47ef:      	callq	*%r9
    47f2:      	testl	%r15d, %r15d
    47f5:      	jne	0x3598 <perf_unwind_dotnet+0x3598>
    47fb:      	jmp	0x46ad <perf_unwind_dotnet+0x46ad>
    4800:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    480a:      	movq	%rax, 0x26(%rsp)
    480f:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    4819:      	movq	%rax, 0x20(%rsp)
    481e:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    4828:      	movq	%rax, 0x18(%rsp)
    482d:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    4837:      	movq	%rax, 0x10(%rsp)
    483c:      	leaq	0x10(%rsp), %rdi
    4841:      	movl	$0x1e, %eax
    4846:      	movl	$0x6, %ecx
    484b:      	movzwl	0x20(%r15), %edx
    4850:      	movl	$0x1e, %esi
    4855:      	xorl	%eax, %eax
    4857:      	callq	*%rcx
    4859:      	movl	0x1380(%r14), %eax
    4860:      	movl	0x20(%r15), %ecx
    4864:      	btl	%ecx, %eax
    4867:      	jb	0x3c61 <perf_unwind_dotnet+0x3c61>
    486d:      	movl	$0x0, 0x68(%rsp)
    4875:      	movq	(%rip), %rdi            # 0x487c <perf_unwind_dotnet+0x487c>
    487c:      	leaq	0x68(%rsp), %rsi
    4881:      	movl	$0x1, %eax
    4886:      	callq	*%rax
    4888:      	testq	%rax, %rax
    488b:      	je	0x4892 <perf_unwind_dotnet+0x4892>
    488d:      	incq	(%rax)
    4890:      	jmp	0x48a2 <perf_unwind_dotnet+0x48a2>
    4892:      	movq	(%rip), %rax            # 0x4899 <perf_unwind_dotnet+0x4899>
    4899:      	cmpl	$0x0, (%rax)
    489c:      	jne	0x4ecf <perf_unwind_dotnet+0x4ecf>
    48a2:      	movzwl	0x20(%r15), %r12d
    48a7:      	cmpl	$0x8, %r12d
    48ab:      	jne	0x8da3 <perf_unwind_dotnet+0x8da3>
    48b1:      	movq	0xed0(%r14), %r12
    48b8:      	movq	0xed8(%r14), %rbx
    48bf:      	movq	0xee0(%r14), %r13
    48c6:      	movzbl	0xf30(%r14), %eax
    48ce:      	movb	%al, 0x88(%rsp)
    48d5:      	movq	(%rip), %rax            # 0x48dc <perf_unwind_dotnet+0x48dc>
    48dc:      	cmpl	$0x0, (%rax)
    48df:      	jne	0x4ccc <perf_unwind_dotnet+0x4ccc>
    48e5:      	cmpq	%rbx, %r13
    48e8:      	jb	0x77bb <perf_unwind_dotnet+0x77bb>
    48ee:      	leaq	0x2000(%rbx), %rax
    48f5:      	cmpq	%rax, %r13
    48f8:      	jae	0x77bb <perf_unwind_dotnet+0x77bb>
    48fe:      	movq	0xf10(%r14), %rbp
    4905:      	movq	0xf20(%r14), %r15
    490c:      	movq	%r12, 0x68(%rsp)
    4911:      	movb	$0x1, 0xf30(%r14)
    4919:      	movq	%rbp, %rax
    491c:      	andq	$-0x80, %rax
    4920:      	cmpq	$0x80, %rax
    4926:      	jne	0x496a <perf_unwind_dotnet+0x496a>
    4928:      	movq	0xed8(%r14), %rax
    492f:      	movl	$0x8, %ecx
    4934:      	movl	$0x70, %r8d
    493a:      	movq	0x98(%rsp), %rdi
    4942:      	movq	0xed8(%r14), %rdx
    4949:      	movl	$0x8, %esi
    494e:      	callq	*%r8
    4951:      	testq	%rax, %rax
    4954:      	jne	0x19c <perf_unwind_dotnet+0x19c>
    495a:      	addq	$0x8, 0xed8(%r14)
    4962:      	andl	$0x7f, %ebp
    4965:      	jmp	0x4fa5 <perf_unwind_dotnet+0x4fa5>
    496a:      	leaq	0x70(%rsp), %rdi
    496f:      	movl	$0x10, %eax
    4974:      	movl	$0x70, %ecx
    4979:      	movl	$0x10, %esi
    497e:      	movq	%r13, %rdx
    4981:      	callq	*%rcx
    4983:      	testq	%rax, %rax
    4986:      	jne	0x26c <perf_unwind_dotnet+0x26c>
    498c:      	addq	$0x10, %r13
    4990:      	movq	%r13, 0xed8(%r14)
    4997:      	movq	0x70(%rsp), %rax
    499c:      	movq	%rax, 0xee0(%r14)
    49a3:      	movq	0x78(%rsp), %rax
    49a8:      	movq	%rax, 0xed0(%r14)
    49af:      	movq	(%rip), %rax            # 0x49b6 <perf_unwind_dotnet+0x49b6>
    49b6:      	cmpl	$0x0, (%rax)
    49b9:      	jne	0x4deb <perf_unwind_dotnet+0x4deb>
    49bf:      	cmpq	$0x100, %rbp            # imm = 0x100
    49c6:      	jb	0x4fa5 <perf_unwind_dotnet+0x4fa5>
    49cc:      	movq	0xf10(%r14), %rbp
    49d3:      	movq	0xf20(%r14), %rbx
    49da:      	movq	%r12, %r13
    49dd:      	subq	%rbx, %r13
    49e0:      	movq	(%rip), %rax            # 0x49e7 <perf_unwind_dotnet+0x49e7>
    49e7:      	cmpl	$0x0, (%rax)
    49ea:      	jne	0x4e8b <perf_unwind_dotnet+0x4e8b>
    49f0:      	movq	%r13, %r15
    49f3:      	andq	$-0x4, %r15
    49f7:      	movl	$0x100, %ecx            # imm = 0x100
    49fc:      	movq	%r15, %rax
    49ff:      	xorl	%edx, %edx
    4a01:      	divq	%rcx
    4a04:      	movq	%rax, %rcx
    4a07:      	movl	$0x7f, %eax
    4a0c:      	subq	%rcx, %rax
    4a0f:      	jns	0x4a28 <perf_unwind_dotnet+0x4a28>
    4a11:      	movl	$0x100, %ecx            # imm = 0x100
    4a16:      	movq	%r15, %rax
    4a19:      	xorl	%edx, %edx
    4a1b:      	divq	%rcx
    4a1e:      	leaq	-0x3fc(%rbp,%rax,4), %rbp
    4a26:      	xorl	%eax, %eax
    4a28:      	movl	$0x80, %ecx
    4a2d:      	cqto
    4a2f:      	idivq	%rcx
    4a32:      	movq	0x90(%rsp), %rax
    4a3a:      	leaq	(%rax,%rdx,4), %rdi
    4a3e:      	movl	$0x200, %eax            # imm = 0x200
    4a43:      	movl	$0x70, %ecx
    4a48:      	movl	$0x200, %esi            # imm = 0x200
    4a4d:      	movq	%rbp, %rdx
    4a50:      	callq	*%rcx
    4a52:      	testq	%rax, %rax
    4a55:      	je	0x4a8c <perf_unwind_dotnet+0x4a8c>
    4a57:      	movq	(%rip), %rax            # 0x4a5e <perf_unwind_dotnet+0x4a5e>
    4a5e:      	cmpl	$0x0, (%rax)
    4a61:      	jne	0x4c61 <perf_unwind_dotnet+0x4c61>
    4a67:      	movl	$0x5e, 0xc(%rsp)
    4a6f:      	movq	(%rip), %rdi            # 0x4a76 <perf_unwind_dotnet+0x4a76>
    4a76:      	leaq	0xc(%rsp), %rsi
    4a7b:      	movl	$0x1, %eax
    4a80:      	callq	*%rax
    4a82:      	testq	%rax, %rax
    4a85:      	je	0x4af7 <perf_unwind_dotnet+0x4af7>
    4a87:      	incq	(%rax)
    4a8a:      	jmp	0x4b07 <perf_unwind_dotnet+0x4b07>
    4a8c:      	movl	0x117c(%r14), %ebp
    4a93:      	movq	(%rip), %rax            # 0x4a9a <perf_unwind_dotnet+0x4a9a>
    4a9a:      	cmpl	$0x0, (%rax)
    4a9d:      	jne	0x5375 <perf_unwind_dotnet+0x5375>
    4aa3:      	movl	$0x20, %ecx
    4aa8:      	movq	%r15, %rax
    4aab:      	xorl	%edx, %edx
    4aad:      	divq	%rcx
    4ab0:      	movl	$0x8, %ecx
    4ab5:      	xorl	%edx, %edx
    4ab7:      	divq	%rcx
    4aba:      	shll	$0x2, %edx
    4abd:      	movb	$0x1c, %al
    4abf:      	subb	%dl, %al
    4ac1:      	shrxl	%eax, %ebp, %r15d
    4ac6:      	testl	%r15d, %r15d
    4ac9:      	je	0x4b94 <perf_unwind_dotnet+0x4b94>
    4acf:      	andq	$-0x20, %r13
    4ad3:      	movl	%r15d, %ecx
    4ad6:      	andl	$0xf, %ecx
    4ad9:      	jne	0x4f58 <perf_unwind_dotnet+0x4f58>
    4adf:      	movl	%r15d, %ecx
    4ae2:      	shrl	$0x4, %ecx
    4ae5:      	andl	$0xf, %ecx
    4ae8:      	je	0x4ca4 <perf_unwind_dotnet+0x4ca4>
    4aee:      	addq	$-0x20, %r13
    4af2:      	jmp	0x4f58 <perf_unwind_dotnet+0x4f58>
    4af7:      	movq	(%rip), %rax            # 0x4afe <perf_unwind_dotnet+0x4afe>
    4afe:      	cmpl	$0x0, (%rax)
    4b01:      	jne	0x5481 <perf_unwind_dotnet+0x5481>
    4b07:      	movl	$0x1772, %edx           # imm = 0x1772
    4b0c:      	xorl	%ebx, %ebx
    4b0e:      	movq	(%rip), %rax            # 0x4b15 <perf_unwind_dotnet+0x4b15>
    4b15:      	cmpl	$0x0, (%rax)
    4b18:      	jne	0x5822 <perf_unwind_dotnet+0x5822>
    4b1e:      	movl	$0x1772, %eax           # imm = 0x1772
    4b23:      	testb	%bl, %bl
    4b25:      	movq	0x60(%rsp), %r15
    4b2a:      	movq	(%rip), %rbp            # 0x4b31 <perf_unwind_dotnet+0x4b31>
    4b31:      	je	0x7812 <perf_unwind_dotnet+0x7812>
    4b37:      	movl	0x2c0(%r14), %eax
    4b3e:      	cmpq	$0x7e, %rax
    4b42:      	ja	0x52f <perf_unwind_dotnet+0x52f>
    4b48:      	leal	0x1(%rax), %ecx
    4b4b:      	movl	%ecx, 0x2c0(%r14)
    4b52:      	leaq	(%rax,%rax,2), %rax
    4b56:      	movq	$0x0, 0x2d0(%r14,%rax,8)
    4b62:      	movq	$0x1773, 0x2d8(%r14,%rax,8) # imm = 0x1773
    4b6e:      	movb	$-0x76, 0x2e0(%r14,%rax,8)
    4b77:      	movl	$0x0, 0x2e1(%r14,%rax,8)
    4b83:      	movl	$0x0, 0x2e4(%r14,%rax,8)
    4b8f:      	jmp	0x5058 <perf_unwind_dotnet+0x5058>
    4b94:      	andq	$-0x100, %r13
    4b9b:      	addq	$-0x20, %r13
    4b9f:      	movl	0x1178(%r14), %r15d
    4ba6:      	movq	(%rip), %rax            # 0x4bad <perf_unwind_dotnet+0x4bad>
    4bad:      	cmpl	$0x0, (%rax)
    4bb0:      	jne	0x5611 <perf_unwind_dotnet+0x5611>
    4bb6:      	xorl	%ecx, %ecx
    4bb8:      	testl	%r15d, %r15d
    4bbb:      	je	0x56a5 <perf_unwind_dotnet+0x56a5>
    4bc1:      	movl	%ecx, %eax
    4bc3:      	shll	$0x8, %eax
    4bc6:      	subq	%rax, %r13
    4bc9:      	jae	0x57bd <perf_unwind_dotnet+0x57bd>
    4bcf:      	movq	(%rip), %rax            # 0x4bd6 <perf_unwind_dotnet+0x4bd6>
    4bd6:      	cmpl	$0x0, (%rax)
    4bd9:      	je	0x4a67 <perf_unwind_dotnet+0x4a67>
    4bdf:      	movabsq	$0xa657361625f63, %rax  # imm = 0xA657361625F63
    4be9:      	movq	%rax, 0x36(%rsp)
    4bee:      	movabsq	$0x5f637020776f6c65, %rax # imm = 0x5F637020776F6C65
    4bf8:      	movq	%rax, 0x30(%rsp)
    4bfd:      	movabsq	$0x6220746e65772068, %rax # imm = 0x6220746E65772068
    4c07:      	movq	%rax, 0x28(%rsp)
    4c0c:      	movabsq	$0x6372616573207061, %rax # imm = 0x6372616573207061
    4c16:      	movq	%rax, 0x20(%rsp)
    4c1b:      	movabsq	$0x6d20656c6262696e, %rax # imm = 0x6D20656C6262696E
    4c25:      	movq	%rax, 0x18(%rsp)
    4c2a:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    4c34:      	movq	%rax, 0x10(%rsp)
    4c39:      	leaq	0x10(%rsp), %rdi
    4c3e:      	movl	$0x2e, %eax
    4c43:      	movl	$0x6, %ecx
    4c48:      	movl	$0x2e, %esi
    4c4d:      	xorl	%eax, %eax
    4c4f:      	callq	*%rcx
    4c51:      	movq	(%rip), %rax            # 0x4c58 <perf_unwind_dotnet+0x4c58>
    4c58:      	cmpl	$0x0, (%rax)
    4c5b:      	je	0x4a67 <perf_unwind_dotnet+0x4a67>
    4c61:      	movabsq	$0x6e756f6620746f6e, %rax # imm = 0x6E756F6620746F6E
    4c6b:      	movq	%rax, 0x18(%rsp)
    4c70:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    4c7a:      	movq	%rax, 0x10(%rsp)
    4c7f:      	movl	$0xa646e, 0x1f(%rsp)    # imm = 0xA646E
    4c87:      	leaq	0x10(%rsp), %rdi
    4c8c:      	movl	$0x13, %eax
    4c91:      	movl	$0x6, %ecx
    4c96:      	movl	$0x13, %esi
    4c9b:      	xorl	%eax, %eax
    4c9d:      	callq	*%rcx
    4c9f:      	jmp	0x4a67 <perf_unwind_dotnet+0x4a67>
    4ca4:      	movl	%r15d, %ecx
    4ca7:      	shrl	$0x8, %ecx
    4caa:      	andl	$0xf, %ecx
    4cad:      	je	0x4cb8 <perf_unwind_dotnet+0x4cb8>
    4caf:      	addq	$-0x40, %r13
    4cb3:      	jmp	0x4f58 <perf_unwind_dotnet+0x4f58>
    4cb8:      	movl	%r15d, %ecx
    4cbb:      	shrl	$0xc, %ecx
    4cbe:      	andl	$0xf, %ecx
    4cc1:      	je	0x4d41 <perf_unwind_dotnet+0x4d41>
    4cc3:      	addq	$-0x60, %r13
    4cc7:      	jmp	0x4f58 <perf_unwind_dotnet+0x4f58>
    4ccc:      	movabsq	$0x6c25203a7066202c, %rax # imm = 0x6C25203A7066202C
    4cd6:      	movq	%rax, 0x28(%rsp)
    4cdb:      	movabsq	$0x786c25203a707320, %rax # imm = 0x786C25203A707320
    4ce5:      	movq	%rax, 0x20(%rsp)
    4cea:      	movabsq	$0x2c786c25203a6370, %rax # imm = 0x2C786C25203A6370
    4cf4:      	movq	%rax, 0x18(%rsp)
    4cf9:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    4d03:      	movq	%rax, 0x10(%rsp)
    4d08:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    4d10:      	leaq	0x10(%rsp), %rdi
    4d15:      	movl	$0x23, %eax
    4d1a:      	movl	$0x6, %r9d
    4d20:      	movl	$0x23, %esi
    4d25:      	movq	%r12, %rdx
    4d28:      	movq	%rbx, %rcx
    4d2b:      	movq	%r13, %r8
    4d2e:      	xorl	%eax, %eax
    4d30:      	callq	*%r9
    4d33:      	cmpq	%rbx, %r13
    4d36:      	jae	0x48ee <perf_unwind_dotnet+0x48ee>
    4d3c:      	jmp	0x77bb <perf_unwind_dotnet+0x77bb>
    4d41:      	movl	%r15d, %ecx
    4d44:      	shrl	$0x10, %ecx
    4d47:      	andl	$0xf, %ecx
    4d4a:      	je	0x4d55 <perf_unwind_dotnet+0x4d55>
    4d4c:      	addq	$-0x80, %r13
    4d50:      	jmp	0x4f58 <perf_unwind_dotnet+0x4f58>
    4d55:      	movl	%r15d, %ecx
    4d58:      	shrl	$0x14, %ecx
    4d5b:      	andl	$0xf, %ecx
    4d5e:      	je	0x4e70 <perf_unwind_dotnet+0x4e70>
    4d64:      	addq	$-0xa0, %r13
    4d6b:      	jmp	0x4f58 <perf_unwind_dotnet+0x4f58>
    4d70:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4d7a:      	movq	%rax, 0x36(%rsp)
    4d7f:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4d89:      	movq	%rax, 0x30(%rsp)
    4d8e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4d98:      	movq	%rax, 0x28(%rsp)
    4d9d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4da7:      	movq	%rax, 0x20(%rsp)
    4dac:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4db6:      	movq	%rax, 0x18(%rsp)
    4dbb:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4dc5:      	movq	%rax, 0x10(%rsp)
    4dca:      	leaq	0x10(%rsp), %rdi
    4dcf:      	movl	$0x2e, %eax
    4dd4:      	movl	$0x6, %ecx
    4dd9:      	movl	0xc(%rsp), %edx
    4ddd:      	movl	$0x2e, %esi
    4de2:      	xorl	%eax, %eax
    4de4:      	callq	*%rcx
    4de6:      	jmp	0x46e2 <perf_unwind_dotnet+0x46e2>
    4deb:      	movabsq	$0x6c25203a7066202c, %rax # imm = 0x6C25203A7066202C
    4df5:      	movq	%rax, 0x28(%rsp)
    4dfa:      	movabsq	$0x786c25203a707320, %rax # imm = 0x786C25203A707320
    4e04:      	movq	%rax, 0x20(%rsp)
    4e09:      	movabsq	$0x2c786c25203a6370, %rax # imm = 0x2C786C25203A6370
    4e13:      	movq	%rax, 0x18(%rsp)
    4e18:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    4e22:      	movq	%rax, 0x10(%rsp)
    4e27:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    4e2f:      	leaq	0x10(%rsp), %rdi
    4e34:      	movl	$0x23, %eax
    4e39:      	movl	$0x6, %r9d
    4e3f:      	movq	0xed0(%r14), %rdx
    4e46:      	movq	0xed8(%r14), %rcx
    4e4d:      	movq	0xee0(%r14), %r8
    4e54:      	movl	$0x23, %esi
    4e59:      	xorl	%eax, %eax
    4e5b:      	callq	*%r9
    4e5e:      	cmpq	$0x100, %rbp            # imm = 0x100
    4e65:      	jae	0x49cc <perf_unwind_dotnet+0x49cc>
    4e6b:      	jmp	0x4fa5 <perf_unwind_dotnet+0x4fa5>
    4e70:      	movl	%r15d, %ecx
    4e73:      	shrl	$0x18, %ecx
    4e76:      	andl	$0xf, %ecx
    4e79:      	je	0x4f4a <perf_unwind_dotnet+0x4f4a>
    4e7f:      	addq	$-0xc0, %r13
    4e86:      	jmp	0x4f58 <perf_unwind_dotnet+0x4f58>
    4e8b:      	leaq	(%rip), %rsi            # 0x4e92 <perf_unwind_dotnet+0x4e92>
    4e92:      	leaq	0x10(%rsp), %rax
    4e97:      	movl	$0x8, %ecx
    4e9c:      	movq	%rax, %rdi
    4e9f:      	rep		movsq	(%rsi), %es:(%rdi)
    4ea2:      	movw	$0xa, 0x50(%rsp)
    4ea9:      	movl	$0x42, %ecx
    4eae:      	movl	$0x6, %r9d
    4eb4:      	movq	%rax, %rdi
    4eb7:      	movl	$0x42, %esi
    4ebc:      	movq	%r13, %rdx
    4ebf:      	movq	%rbx, %rcx
    4ec2:      	movq	%rbp, %r8
    4ec5:      	xorl	%eax, %eax
    4ec7:      	callq	*%r9
    4eca:      	jmp	0x49f0 <perf_unwind_dotnet+0x49f0>
    4ecf:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4ed9:      	movq	%rax, 0x36(%rsp)
    4ede:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4ee8:      	movq	%rax, 0x30(%rsp)
    4eed:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4ef7:      	movq	%rax, 0x28(%rsp)
    4efc:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4f06:      	movq	%rax, 0x20(%rsp)
    4f0b:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4f15:      	movq	%rax, 0x18(%rsp)
    4f1a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4f24:      	movq	%rax, 0x10(%rsp)
    4f29:      	leaq	0x10(%rsp), %rdi
    4f2e:      	movl	$0x2e, %eax
    4f33:      	movl	$0x6, %ecx
    4f38:      	movl	0x68(%rsp), %edx
    4f3c:      	movl	$0x2e, %esi
    4f41:      	xorl	%eax, %eax
    4f43:      	callq	*%rcx
    4f45:      	jmp	0x48a2 <perf_unwind_dotnet+0x48a2>
    4f4a:      	shrl	$0x1c, %r15d
    4f4e:      	addq	$-0xe0, %r13
    4f55:      	movl	%r15d, %ecx
    4f58:      	addq	%r13, %rbx
    4f5b:      	leal	-0x4(,%rcx,4), %r15d
    4f63:      	addq	%rbx, %r15
    4f66:      	movq	(%rip), %rax            # 0x4f6d <perf_unwind_dotnet+0x4f6d>
    4f6d:      	cmpl	$0x0, (%rax)
    4f70:      	jne	0x5402 <perf_unwind_dotnet+0x5402>
    4f76:      	leaq	-0x8(%r15), %rdx
    4f7a:      	leaq	0x68(%rsp), %rdi
    4f7f:      	movl	$0x8, %eax
    4f84:      	movl	$0x70, %ecx
    4f89:      	movl	$0x8, %esi
    4f8e:      	callq	*%rcx
    4f90:      	testq	%rax, %rax
    4f93:      	movq	(%rip), %rbp            # 0x4f9a <perf_unwind_dotnet+0x4f9a>
    4f9a:      	jne	0xbb6 <perf_unwind_dotnet+0xbb6>
    4fa0:      	movl	$0x1f, %ebp
    4fa5:      	movq	(%rip), %rax            # 0x4fac <perf_unwind_dotnet+0x4fac>
    4fac:      	cmpl	$0x0, (%rax)
    4faf:      	jne	0x51fe <perf_unwind_dotnet+0x51fe>
    4fb5:      	movl	0x2c0(%r14), %eax
    4fbc:      	cmpq	$0x7e, %rax
    4fc0:      	ja	0xc0c <perf_unwind_dotnet+0xc0c>
    4fc6:      	movq	0x68(%rsp), %rcx
    4fcb:      	subq	%r15, %r12
    4fce:      	shlq	$0x5, %rcx
    4fd2:      	addq	%rbp, %rcx
    4fd5:      	leal	0x1(%rax), %edx
    4fd8:      	movl	%edx, 0x2c0(%r14)
    4fdf:      	leaq	(%rax,%rax,2), %rax
    4fe3:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    4feb:      	movq	%r12, 0x2d8(%r14,%rax,8)
    4ff3:      	movb	$0xa, 0x2e0(%r14,%rax,8)
    4ffc:      	movzbl	0x88(%rsp), %ecx
    5004:      	movb	%cl, 0x2e1(%r14,%rax,8)
    500c:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    5018:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    5023:      	movl	$0x5b, 0xc(%rsp)
    502b:      	movq	(%rip), %rdi            # 0x5032 <perf_unwind_dotnet+0x5032>
    5032:      	leaq	0xc(%rsp), %rsi
    5037:      	movl	$0x1, %eax
    503c:      	callq	*%rax
    503e:      	testq	%rax, %rax
    5041:      	je	0x5048 <perf_unwind_dotnet+0x5048>
    5043:      	incq	(%rax)
    5046:      	jmp	0x5058 <perf_unwind_dotnet+0x5058>
    5048:      	movq	(%rip), %rax            # 0x504f <perf_unwind_dotnet+0x504f>
    504f:      	cmpl	$0x0, (%rax)
    5052:      	jne	0x52fa <perf_unwind_dotnet+0x52fa>
    5058:      	movq	0x98(%rsp), %rax
    5060:      	movq	(%rax), %r13
    5063:      	movq	(%rip), %rax            # 0x506a <perf_unwind_dotnet+0x506a>
    506a:      	movl	(%rax), %eax
    506c:      	testq	%r13, %r13
    506f:      	je	0x88ec <perf_unwind_dotnet+0x88ec>
    5075:      	testl	%eax, %eax
    5077:      	jne	0x525d <perf_unwind_dotnet+0x525d>
    507d:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    5087:      	cmpq	%rax, %r13
    508a:      	ja	0x2516 <perf_unwind_dotnet+0x2516>
    5090:      	cmpq	$0x1000, %r13           # imm = 0x1000
    5097:      	jb	0x26b1 <perf_unwind_dotnet+0x26b1>
    509d:      	movl	(%r14), %eax
    50a0:      	movl	$0x60, 0x70(%rsp)
    50a8:      	movbel	%eax, 0x74(%rsp)
    50ae:      	movbeq	%r13, 0x78(%rsp)
    50b5:      	movq	(%rip), %rdi            # 0x50bc <perf_unwind_dotnet+0x50bc>
    50bc:      	leaq	0x70(%rsp), %rsi
    50c1:      	movl	$0x1, %eax
    50c6:      	callq	*%rax
    50c8:      	testq	%rax, %rax
    50cb:      	je	0x8837 <perf_unwind_dotnet+0x8837>
    50d1:      	movq	0x8(%rax), %r12
    50d5:      	movq	%r12, %rcx
    50d8:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    50e2:      	andq	%rdx, %rcx
    50e5:      	movq	%rcx, 0xf20(%r14)
    50ec:      	movq	(%rax), %rax
    50ef:      	movq	%rax, 0xf10(%r14)
    50f6:      	shrq	$0x38, %r12
    50fa:      	movq	%r13, %rax
    50fd:      	subq	%rcx, %rax
    5100:      	movq	%rax, 0xf18(%r14)
    5107:      	movq	(%rip), %rax            # 0x510e <perf_unwind_dotnet+0x510e>
    510e:      	cmpl	$0x0, (%rax)
    5111:      	jne	0x54fc <perf_unwind_dotnet+0x54fc>
    5117:      	cmpl	$0x1, %r12d
    511b:      	jne	0x59d0 <perf_unwind_dotnet+0x59d0>
    5121:      	movq	0xf10(%r14), %rax
    5128:      	movq	%rax, 0x70(%rsp)
    512d:      	movq	0xf18(%r14), %rbx
    5134:      	movq	(%rip), %rdi            # 0x513b <perf_unwind_dotnet+0x513b>
    513b:      	leaq	0x70(%rsp), %rsi
    5140:      	movl	$0x1, %eax
    5145:      	callq	*%rax
    5147:      	movl	$0x1, %r12d
    514d:      	testq	%rax, %rax
    5150:      	je	0x59d0 <perf_unwind_dotnet+0x59d0>
    5156:      	movq	%rax, %r15
    5159:      	cmpq	%rbx, (%rax)
    515c:      	ja	0x5164 <perf_unwind_dotnet+0x5164>
    515e:      	cmpq	%rbx, 0x8(%r15)
    5162:      	jae	0x5178 <perf_unwind_dotnet+0x5178>
    5164:      	cmpq	%rbx, 0x10(%r15)
    5168:      	ja	0x59d0 <perf_unwind_dotnet+0x59d0>
    516e:      	cmpq	%rbx, 0x18(%r15)
    5172:      	jb	0x59d0 <perf_unwind_dotnet+0x59d0>
    5178:      	movq	(%rip), %rax            # 0x517f <perf_unwind_dotnet+0x517f>
    517f:      	cmpl	$0x0, (%rax)
    5182:      	jne	0x5929 <perf_unwind_dotnet+0x5929>
    5188:      	movl	0x1380(%r14), %eax
    518f:      	movl	0x20(%r15), %ecx
    5193:      	btl	%ecx, %eax
    5196:      	jae	0x5996 <perf_unwind_dotnet+0x5996>
    519c:      	movq	(%rip), %rax            # 0x51a3 <perf_unwind_dotnet+0x51a3>
    51a3:      	cmpl	$0x0, (%rax)
    51a6:      	je	0x59d0 <perf_unwind_dotnet+0x59d0>
    51ac:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    51b6:      	movq	%rax, 0x20(%rsp)
    51bb:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    51c5:      	movq	%rax, 0x18(%rsp)
    51ca:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    51d4:      	movq	%rax, 0x10(%rsp)
    51d9:      	movl	$0xa656e, 0x27(%rsp)    # imm = 0xA656E
    51e1:      	leaq	0x10(%rsp), %rdi
    51e6:      	movl	$0x1b, %eax
    51eb:      	movl	$0x6, %ecx
    51f0:      	movl	$0x1b, %esi
    51f5:      	xorl	%eax, %eax
    51f7:      	callq	*%rcx
    51f9:      	jmp	0x59d0 <perf_unwind_dotnet+0x59d0>
    51fe:      	leaq	(%rip), %rsi            # 0x5205 <perf_unwind_dotnet+0x5205>
    5205:      	leaq	0x10(%rsp), %rax
    520a:      	movl	$0x8, %ecx
    520f:      	movq	%rax, %rdi
    5212:      	rep		movsq	(%rsi), %es:(%rdi)
    5215:      	movb	$0x0, 0x52(%rsp)
    521a:      	movw	$0xa78, 0x50(%rsp)      # imm = 0xA78
    5221:      	movl	$0x43, %ecx
    5226:      	movl	$0x6, %r9d
    522c:      	movq	0x68(%rsp), %rcx
    5231:      	movq	%r12, %r8
    5234:      	subq	%r15, %r8
    5237:      	movq	%rax, %rdi
    523a:      	movl	$0x43, %esi
    523f:      	movq	%r15, %rdx
    5242:      	xorl	%eax, %eax
    5244:      	callq	*%r9
    5247:      	movl	0x2c0(%r14), %eax
    524e:      	cmpq	$0x7e, %rax
    5252:      	ja	0xc0c <perf_unwind_dotnet+0xc0c>
    5258:      	jmp	0x4fc6 <perf_unwind_dotnet+0x4fc6>
    525d:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    5267:      	movq	%rax, 0x38(%rsp)
    526c:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    5276:      	movq	%rax, 0x30(%rsp)
    527b:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    5285:      	movq	%rax, 0x28(%rsp)
    528a:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    5294:      	movq	%rax, 0x20(%rsp)
    5299:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    52a3:      	movq	%rax, 0x18(%rsp)
    52a8:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    52b2:      	movq	%rax, 0x10(%rsp)
    52b7:      	movb	$0x0, 0x40(%rsp)
    52bc:      	leaq	0x10(%rsp), %rdi
    52c1:      	movl	$0x31, %eax
    52c6:      	movl	$0x6, %ecx
    52cb:      	movl	0x2c0(%r14), %edx
    52d2:      	movl	$0x31, %esi
    52d7:      	xorl	%eax, %eax
    52d9:      	callq	*%rcx
    52db:      	movq	0xed0(%r14), %r13
    52e2:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    52ec:      	cmpq	%rax, %r13
    52ef:      	ja	0x2516 <perf_unwind_dotnet+0x2516>
    52f5:      	jmp	0x5090 <perf_unwind_dotnet+0x5090>
    52fa:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5304:      	movq	%rax, 0x36(%rsp)
    5309:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5313:      	movq	%rax, 0x30(%rsp)
    5318:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5322:      	movq	%rax, 0x28(%rsp)
    5327:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5331:      	movq	%rax, 0x20(%rsp)
    5336:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5340:      	movq	%rax, 0x18(%rsp)
    5345:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    534f:      	movq	%rax, 0x10(%rsp)
    5354:      	leaq	0x10(%rsp), %rdi
    5359:      	movl	$0x2e, %eax
    535e:      	movl	$0x6, %ecx
    5363:      	movl	0xc(%rsp), %edx
    5367:      	movl	$0x2e, %esi
    536c:      	xorl	%eax, %eax
    536e:      	callq	*%rcx
    5370:      	jmp	0x5058 <perf_unwind_dotnet+0x5058>
    5375:      	movabsq	$0xa782520797274, %rax  # imm = 0xA782520797274
    537f:      	movq	%rax, 0x3e(%rsp)
    5384:      	movabsq	$0x72746e6520747372, %rax # imm = 0x72746E6520747372
    538e:      	movq	%rax, 0x38(%rsp)
    5393:      	movabsq	$0x6966203a786c2520, %rax # imm = 0x6966203A786C2520
    539d:      	movq	%rax, 0x30(%rsp)
    53a2:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    53ac:      	movq	%rax, 0x28(%rsp)
    53b1:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    53bb:      	movq	%rax, 0x20(%rsp)
    53c0:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    53ca:      	movq	%rax, 0x18(%rsp)
    53cf:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    53d9:      	movq	%rax, 0x10(%rsp)
    53de:      	leaq	0x10(%rsp), %rdi
    53e3:      	movl	$0x36, %eax
    53e8:      	movl	$0x6, %r8d
    53ee:      	movl	$0x36, %esi
    53f3:      	movq	%r15, %rdx
    53f6:      	movl	%ebp, %ecx
    53f8:      	xorl	%eax, %eax
    53fa:      	callq	*%r8
    53fd:      	jmp	0x4aa3 <perf_unwind_dotnet+0x4aa3>
    5402:      	movabsq	$0xa786c253d7465, %rax  # imm = 0xA786C253D7465
    540c:      	movq	%rax, 0x36(%rsp)
    5411:      	movabsq	$0x746572202c78253d, %rax # imm = 0x746572202C78253D
    541b:      	movq	%rax, 0x30(%rsp)
    5420:      	movabsq	$0x6c6176202c786c25, %rax # imm = 0x6C6176202C786C25
    542a:      	movq	%rax, 0x28(%rsp)
    542f:      	movabsq	$0x203d2061746c6564, %rax # imm = 0x203D2061746C6564
    5439:      	movq	%rax, 0x20(%rsp)
    543e:      	movabsq	$0x5f6370203e2d2d20, %rax # imm = 0x5F6370203E2D2D20
    5448:      	movq	%rax, 0x18(%rsp)
    544d:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    5457:      	movq	%rax, 0x10(%rsp)
    545c:      	leaq	0x10(%rsp), %rdi
    5461:      	movl	$0x2e, %eax
    5466:      	movl	$0x6, %r9d
    546c:      	movl	$0x2e, %esi
    5471:      	movq	%r13, %rdx
    5474:      	movq	%r15, %r8
    5477:      	xorl	%eax, %eax
    5479:      	callq	*%r9
    547c:      	jmp	0x4f76 <perf_unwind_dotnet+0x4f76>
    5481:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    548b:      	movq	%rax, 0x36(%rsp)
    5490:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    549a:      	movq	%rax, 0x30(%rsp)
    549f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    54a9:      	movq	%rax, 0x28(%rsp)
    54ae:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    54b8:      	movq	%rax, 0x20(%rsp)
    54bd:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    54c7:      	movq	%rax, 0x18(%rsp)
    54cc:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    54d6:      	movq	%rax, 0x10(%rsp)
    54db:      	leaq	0x10(%rsp), %rdi
    54e0:      	movl	$0x2e, %eax
    54e5:      	movl	$0x6, %ecx
    54ea:      	movl	0xc(%rsp), %edx
    54ee:      	movl	$0x2e, %esi
    54f3:      	xorl	%eax, %eax
    54f5:      	callq	*%rcx
    54f7:      	jmp	0x4b07 <perf_unwind_dotnet+0x4b07>
    54fc:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    5506:      	movq	%rax, 0x38(%rsp)
    550b:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    5515:      	movq	%rax, 0x30(%rsp)
    551a:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    5524:      	movq	%rax, 0x28(%rsp)
    5529:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    5533:      	movq	%rax, 0x20(%rsp)
    5538:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    5542:      	movq	%rax, 0x18(%rsp)
    5547:      	movabsq	$0x6365732074786554, %rbx # imm = 0x6365732074786554
    5551:      	movq	%rbx, 0x10(%rsp)
    5556:      	movw	$0xa, 0x40(%rsp)
    555d:      	leaq	0x10(%rsp), %rdi
    5562:      	movl	$0x32, %eax
    5567:      	movl	$0x6, %r9d
    556d:      	movq	0xf10(%r14), %rcx
    5574:      	movl	$0x32, %esi
    5579:      	movq	%r13, %rdx
    557c:      	movl	%r12d, %r8d
    557f:      	xorl	%eax, %eax
    5581:      	callq	*%r9
    5584:      	movq	(%rip), %rax            # 0x558b <perf_unwind_dotnet+0x558b>
    558b:      	cmpl	$0x0, (%rax)
    558e:      	je	0x5117 <perf_unwind_dotnet+0x5117>
    5594:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    559e:      	movq	%rax, 0x37(%rsp)
    55a3:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    55ad:      	movq	%rax, 0x30(%rsp)
    55b2:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    55bc:      	movq	%rax, 0x28(%rsp)
    55c1:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    55cb:      	movq	%rax, 0x20(%rsp)
    55d0:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    55da:      	movq	%rax, 0x18(%rsp)
    55df:      	movq	%rbx, 0x10(%rsp)
    55e4:      	leaq	0x10(%rsp), %rdi
    55e9:      	movl	$0x2f, %eax
    55ee:      	movl	$0x6, %r8d
    55f4:      	movq	0xf18(%r14), %rcx
    55fb:      	movq	0xf20(%r14), %rdx
    5602:      	movl	$0x2f, %esi
    5607:      	xorl	%eax, %eax
    5609:      	callq	*%r8
    560c:      	jmp	0x5117 <perf_unwind_dotnet+0x5117>
    5611:      	movabsq	$0xa782520797274, %rax  # imm = 0xA782520797274
    561b:      	movq	%rax, 0x3f(%rsp)
    5620:      	movabsq	$0x746e6520646e6f63, %rax # imm = 0x746E6520646E6F63
    562a:      	movq	%rax, 0x38(%rsp)
    562f:      	movabsq	$0x6573203a786c2520, %rax # imm = 0x6573203A786C2520
    5639:      	movq	%rax, 0x30(%rsp)
    563e:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    5648:      	movq	%rax, 0x28(%rsp)
    564d:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    5657:      	movq	%rax, 0x20(%rsp)
    565c:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    5666:      	movq	%rax, 0x18(%rsp)
    566b:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    5675:      	movq	%rax, 0x10(%rsp)
    567a:      	leaq	0x10(%rsp), %rdi
    567f:      	movl	$0x37, %eax
    5684:      	movl	$0x6, %r8d
    568a:      	movl	$0x37, %esi
    568f:      	movq	%r13, %rdx
    5692:      	movl	%r15d, %ecx
    5695:      	xorl	%eax, %eax
    5697:      	callq	*%r8
    569a:      	xorl	%ecx, %ecx
    569c:      	testl	%r15d, %r15d
    569f:      	jne	0x4bc1 <perf_unwind_dotnet+0x4bc1>
    56a5:      	movq	0x1170(%r14), %rax
    56ac:      	movl	$0xffffff84, %ecx       # imm = 0xFFFFFF84
    56b1:      	testq	%rax, %rax
    56b4:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    56ba:      	movq	0x1168(%r14), %rax
    56c1:      	movl	$0xffffff86, %ecx       # imm = 0xFFFFFF86
    56c6:      	testq	%rax, %rax
    56c9:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    56cf:      	movq	0x1160(%r14), %rax
    56d6:      	movl	$0xffffff88, %ecx       # imm = 0xFFFFFF88
    56db:      	testq	%rax, %rax
    56de:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    56e4:      	movq	0x1158(%r14), %rax
    56eb:      	movl	$0xffffff8a, %ecx       # imm = 0xFFFFFF8A
    56f0:      	testq	%rax, %rax
    56f3:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    56f9:      	movq	0x1150(%r14), %rax
    5700:      	movl	$0xffffff8c, %ecx       # imm = 0xFFFFFF8C
    5705:      	testq	%rax, %rax
    5708:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    570e:      	movq	0x1148(%r14), %rax
    5715:      	movl	$0xffffff8e, %ecx       # imm = 0xFFFFFF8E
    571a:      	testq	%rax, %rax
    571d:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    571f:      	movq	0x1140(%r14), %rax
    5726:      	movl	$0xffffff90, %ecx       # imm = 0xFFFFFF90
    572b:      	testq	%rax, %rax
    572e:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    5730:      	movq	0x1138(%r14), %rax
    5737:      	movl	$0xffffff92, %ecx       # imm = 0xFFFFFF92
    573c:      	testq	%rax, %rax
    573f:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    5741:      	movq	0x1130(%r14), %rax
    5748:      	movl	$0xffffff94, %ecx       # imm = 0xFFFFFF94
    574d:      	testq	%rax, %rax
    5750:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    5752:      	movq	0x1128(%r14), %rax
    5759:      	movl	$0xffffff96, %ecx       # imm = 0xFFFFFF96
    575e:      	testq	%rax, %rax
    5761:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    5763:      	movq	0x1120(%r14), %rax
    576a:      	movl	$0xffffff98, %ecx       # imm = 0xFFFFFF98
    576f:      	testq	%rax, %rax
    5772:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    5774:      	movq	0x1118(%r14), %rax
    577b:      	movl	$0xffffff9a, %ecx       # imm = 0xFFFFFF9A
    5780:      	testq	%rax, %rax
    5783:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    5785:      	movq	0x1110(%r14), %rax
    578c:      	movl	$0xffffff9c, %ecx       # imm = 0xFFFFFF9C
    5791:      	testq	%rax, %rax
    5794:      	je	0x6dc5 <perf_unwind_dotnet+0x6dc5>
    579a:      	xorl	%edx, %edx
    579c:      	movq	%rax, %r15
    579f:      	shrq	$0x20, %r15
    57a3:      	setne	%dl
    57a6:      	cmovel	%eax, %r15d
    57aa:      	subl	%edx, %ecx
    57ac:      	addl	$0x7e, %ecx
    57af:      	movl	%ecx, %eax
    57b1:      	shll	$0x8, %eax
    57b4:      	subq	%rax, %r13
    57b7:      	jb	0x4bcf <perf_unwind_dotnet+0x4bcf>
    57bd:      	movq	(%rip), %rax            # 0x57c4 <perf_unwind_dotnet+0x57c4>
    57c4:      	cmpl	$0x0, (%rax)
    57c7:      	jne	0x588a <perf_unwind_dotnet+0x588a>
    57cd:      	testl	%r15d, %r15d
    57d0:      	jne	0x4ad3 <perf_unwind_dotnet+0x4ad3>
    57d6:      	movl	$0x5f, 0xc(%rsp)
    57de:      	movq	(%rip), %rdi            # 0x57e5 <perf_unwind_dotnet+0x57e5>
    57e5:      	leaq	0xc(%rsp), %rsi
    57ea:      	movl	$0x1, %eax
    57ef:      	callq	*%rax
    57f1:      	testq	%rax, %rax
    57f4:      	je	0x57fb <perf_unwind_dotnet+0x57fb>
    57f6:      	incq	(%rax)
    57f9:      	jmp	0x580b <perf_unwind_dotnet+0x580b>
    57fb:      	movq	(%rip), %rax            # 0x5802 <perf_unwind_dotnet+0x5802>
    5802:      	cmpl	$0x0, (%rax)
    5805:      	jne	0x5e99 <perf_unwind_dotnet+0x5e99>
    580b:      	movl	$0x1773, %edx           # imm = 0x1773
    5810:      	movb	$0x1, %bl
    5812:      	movq	(%rip), %rax            # 0x5819 <perf_unwind_dotnet+0x5819>
    5819:      	cmpl	$0x0, (%rax)
    581c:      	je	0x4b1e <perf_unwind_dotnet+0x4b1e>
    5822:      	movabsq	$0xa642520687469, %rax  # imm = 0xA642520687469
    582c:      	movq	%rax, 0x30(%rsp)
    5831:      	movabsq	$0x772064656c696166, %rax # imm = 0x772064656C696166
    583b:      	movq	%rax, 0x28(%rsp)
    5840:      	movabsq	$0x2074726174735f65, %rax # imm = 0x2074726174735F65
    584a:      	movq	%rax, 0x20(%rsp)
    584f:      	movabsq	$0x646f63203e2d2d20, %rax # imm = 0x646F63203E2D2D20
    5859:      	movq	%rax, 0x18(%rsp)
    585e:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    5868:      	movq	%rax, 0x10(%rsp)
    586d:      	leaq	0x10(%rsp), %rdi
    5872:      	movl	$0x28, %eax
    5877:      	movl	$0x6, %ecx
    587c:      	movl	$0x28, %esi
    5881:      	xorl	%eax, %eax
    5883:      	callq	*%rcx
    5885:      	jmp	0x4b1e <perf_unwind_dotnet+0x4b1e>
    588a:      	movabsq	$0x207972746e65202c, %rax # imm = 0x207972746E65202C
    5894:      	movq	%rax, 0x40(%rsp)
    5899:      	movabsq	$0x6425206465707069, %rax # imm = 0x6425206465707069
    58a3:      	movq	%rax, 0x38(%rsp)
    58a8:      	movabsq	$0x6b73203a786c2520, %rax # imm = 0x6B73203A786C2520
    58b2:      	movq	%rax, 0x30(%rsp)
    58b7:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    58c1:      	movq	%rax, 0x28(%rsp)
    58c6:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    58d0:      	movq	%rax, 0x20(%rsp)
    58d5:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    58df:      	movq	%rax, 0x18(%rsp)
    58e4:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    58ee:      	movq	%rax, 0x10(%rsp)
    58f3:      	movl	$0xa7825, 0x48(%rsp)    # imm = 0xA7825
    58fb:      	leaq	0x10(%rsp), %rdi
    5900:      	movl	$0x3c, %eax
    5905:      	movl	$0x6, %r9d
    590b:      	movl	$0x3c, %esi
    5910:      	movq	%r13, %rdx
    5913:      	movl	%r15d, %r8d
    5916:      	xorl	%eax, %eax
    5918:      	callq	*%r9
    591b:      	testl	%r15d, %r15d
    591e:      	jne	0x4ad3 <perf_unwind_dotnet+0x4ad3>
    5924:      	jmp	0x57d6 <perf_unwind_dotnet+0x57d6>
    5929:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    5933:      	movq	%rax, 0x26(%rsp)
    5938:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    5942:      	movq	%rax, 0x20(%rsp)
    5947:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    5951:      	movq	%rax, 0x18(%rsp)
    5956:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    5960:      	movq	%rax, 0x10(%rsp)
    5965:      	leaq	0x10(%rsp), %rdi
    596a:      	movl	$0x1e, %eax
    596f:      	movl	$0x6, %ecx
    5974:      	movzwl	0x20(%r15), %edx
    5979:      	movl	$0x1e, %esi
    597e:      	xorl	%eax, %eax
    5980:      	callq	*%rcx
    5982:      	movl	0x1380(%r14), %eax
    5989:      	movl	0x20(%r15), %ecx
    598d:      	btl	%ecx, %eax
    5990:      	jb	0x519c <perf_unwind_dotnet+0x519c>
    5996:      	movl	$0x0, 0x68(%rsp)
    599e:      	movq	(%rip), %rdi            # 0x59a5 <perf_unwind_dotnet+0x59a5>
    59a5:      	leaq	0x68(%rsp), %rsi
    59aa:      	movl	$0x1, %eax
    59af:      	callq	*%rax
    59b1:      	testq	%rax, %rax
    59b4:      	je	0x59bb <perf_unwind_dotnet+0x59bb>
    59b6:      	incq	(%rax)
    59b9:      	jmp	0x59cb <perf_unwind_dotnet+0x59cb>
    59bb:      	movq	(%rip), %rax            # 0x59c2 <perf_unwind_dotnet+0x59c2>
    59c2:      	cmpl	$0x0, (%rax)
    59c5:      	jne	0x5ff8 <perf_unwind_dotnet+0x5ff8>
    59cb:      	movzwl	0x20(%r15), %r12d
    59d0:      	cmpl	$0x8, %r12d
    59d4:      	jne	0x8da3 <perf_unwind_dotnet+0x8da3>
    59da:      	movq	0xed0(%r14), %r12
    59e1:      	movq	0xed8(%r14), %rbx
    59e8:      	movq	0xee0(%r14), %r13
    59ef:      	movzbl	0xf30(%r14), %eax
    59f7:      	movb	%al, 0x88(%rsp)
    59fe:      	movq	(%rip), %rax            # 0x5a05 <perf_unwind_dotnet+0x5a05>
    5a05:      	cmpl	$0x0, (%rax)
    5a08:      	jne	0x5df5 <perf_unwind_dotnet+0x5df5>
    5a0e:      	cmpq	%rbx, %r13
    5a11:      	jb	0x77bb <perf_unwind_dotnet+0x77bb>
    5a17:      	leaq	0x2000(%rbx), %rax
    5a1e:      	cmpq	%rax, %r13
    5a21:      	jae	0x77bb <perf_unwind_dotnet+0x77bb>
    5a27:      	movq	0xf10(%r14), %rbp
    5a2e:      	movq	0xf20(%r14), %r15
    5a35:      	movq	%r12, 0x68(%rsp)
    5a3a:      	movb	$0x1, 0xf30(%r14)
    5a42:      	movq	%rbp, %rax
    5a45:      	andq	$-0x80, %rax
    5a49:      	cmpq	$0x80, %rax
    5a4f:      	jne	0x5a93 <perf_unwind_dotnet+0x5a93>
    5a51:      	movq	0xed8(%r14), %rax
    5a58:      	movl	$0x8, %ecx
    5a5d:      	movl	$0x70, %r8d
    5a63:      	movq	0x98(%rsp), %rdi
    5a6b:      	movq	0xed8(%r14), %rdx
    5a72:      	movl	$0x8, %esi
    5a77:      	callq	*%r8
    5a7a:      	testq	%rax, %rax
    5a7d:      	jne	0x19c <perf_unwind_dotnet+0x19c>
    5a83:      	addq	$0x8, 0xed8(%r14)
    5a8b:      	andl	$0x7f, %ebp
    5a8e:      	jmp	0x60ce <perf_unwind_dotnet+0x60ce>
    5a93:      	leaq	0x70(%rsp), %rdi
    5a98:      	movl	$0x10, %eax
    5a9d:      	movl	$0x70, %ecx
    5aa2:      	movl	$0x10, %esi
    5aa7:      	movq	%r13, %rdx
    5aaa:      	callq	*%rcx
    5aac:      	testq	%rax, %rax
    5aaf:      	jne	0x26c <perf_unwind_dotnet+0x26c>
    5ab5:      	addq	$0x10, %r13
    5ab9:      	movq	%r13, 0xed8(%r14)
    5ac0:      	movq	0x70(%rsp), %rax
    5ac5:      	movq	%rax, 0xee0(%r14)
    5acc:      	movq	0x78(%rsp), %rax
    5ad1:      	movq	%rax, 0xed0(%r14)
    5ad8:      	movq	(%rip), %rax            # 0x5adf <perf_unwind_dotnet+0x5adf>
    5adf:      	cmpl	$0x0, (%rax)
    5ae2:      	jne	0x5f14 <perf_unwind_dotnet+0x5f14>
    5ae8:      	cmpq	$0x100, %rbp            # imm = 0x100
    5aef:      	jb	0x60ce <perf_unwind_dotnet+0x60ce>
    5af5:      	movq	0xf10(%r14), %rbp
    5afc:      	movq	0xf20(%r14), %rbx
    5b03:      	movq	%r12, %r13
    5b06:      	subq	%rbx, %r13
    5b09:      	movq	(%rip), %rax            # 0x5b10 <perf_unwind_dotnet+0x5b10>
    5b10:      	cmpl	$0x0, (%rax)
    5b13:      	jne	0x5fb4 <perf_unwind_dotnet+0x5fb4>
    5b19:      	movq	%r13, %r15
    5b1c:      	andq	$-0x4, %r15
    5b20:      	movl	$0x100, %ecx            # imm = 0x100
    5b25:      	movq	%r15, %rax
    5b28:      	xorl	%edx, %edx
    5b2a:      	divq	%rcx
    5b2d:      	movq	%rax, %rcx
    5b30:      	movl	$0x7f, %eax
    5b35:      	subq	%rcx, %rax
    5b38:      	jns	0x5b51 <perf_unwind_dotnet+0x5b51>
    5b3a:      	movl	$0x100, %ecx            # imm = 0x100
    5b3f:      	movq	%r15, %rax
    5b42:      	xorl	%edx, %edx
    5b44:      	divq	%rcx
    5b47:      	leaq	-0x3fc(%rbp,%rax,4), %rbp
    5b4f:      	xorl	%eax, %eax
    5b51:      	movl	$0x80, %ecx
    5b56:      	cqto
    5b58:      	idivq	%rcx
    5b5b:      	movq	0x90(%rsp), %rax
    5b63:      	leaq	(%rax,%rdx,4), %rdi
    5b67:      	movl	$0x200, %eax            # imm = 0x200
    5b6c:      	movl	$0x70, %ecx
    5b71:      	movl	$0x200, %esi            # imm = 0x200
    5b76:      	movq	%rbp, %rdx
    5b79:      	callq	*%rcx
    5b7b:      	testq	%rax, %rax
    5b7e:      	je	0x5bb5 <perf_unwind_dotnet+0x5bb5>
    5b80:      	movq	(%rip), %rax            # 0x5b87 <perf_unwind_dotnet+0x5b87>
    5b87:      	cmpl	$0x0, (%rax)
    5b8a:      	jne	0x5d8a <perf_unwind_dotnet+0x5d8a>
    5b90:      	movl	$0x5e, 0xc(%rsp)
    5b98:      	movq	(%rip), %rdi            # 0x5b9f <perf_unwind_dotnet+0x5b9f>
    5b9f:      	leaq	0xc(%rsp), %rsi
    5ba4:      	movl	$0x1, %eax
    5ba9:      	callq	*%rax
    5bab:      	testq	%rax, %rax
    5bae:      	je	0x5c20 <perf_unwind_dotnet+0x5c20>
    5bb0:      	incq	(%rax)
    5bb3:      	jmp	0x5c30 <perf_unwind_dotnet+0x5c30>
    5bb5:      	movl	0x117c(%r14), %ebp
    5bbc:      	movq	(%rip), %rax            # 0x5bc3 <perf_unwind_dotnet+0x5bc3>
    5bc3:      	cmpl	$0x0, (%rax)
    5bc6:      	jne	0x649e <perf_unwind_dotnet+0x649e>
    5bcc:      	movl	$0x20, %ecx
    5bd1:      	movq	%r15, %rax
    5bd4:      	xorl	%edx, %edx
    5bd6:      	divq	%rcx
    5bd9:      	movl	$0x8, %ecx
    5bde:      	xorl	%edx, %edx
    5be0:      	divq	%rcx
    5be3:      	shll	$0x2, %edx
    5be6:      	movb	$0x1c, %al
    5be8:      	subb	%dl, %al
    5bea:      	shrxl	%eax, %ebp, %r15d
    5bef:      	testl	%r15d, %r15d
    5bf2:      	je	0x5cbd <perf_unwind_dotnet+0x5cbd>
    5bf8:      	andq	$-0x20, %r13
    5bfc:      	movl	%r15d, %ecx
    5bff:      	andl	$0xf, %ecx
    5c02:      	jne	0x6081 <perf_unwind_dotnet+0x6081>
    5c08:      	movl	%r15d, %ecx
    5c0b:      	shrl	$0x4, %ecx
    5c0e:      	andl	$0xf, %ecx
    5c11:      	je	0x5dcd <perf_unwind_dotnet+0x5dcd>
    5c17:      	addq	$-0x20, %r13
    5c1b:      	jmp	0x6081 <perf_unwind_dotnet+0x6081>
    5c20:      	movq	(%rip), %rax            # 0x5c27 <perf_unwind_dotnet+0x5c27>
    5c27:      	cmpl	$0x0, (%rax)
    5c2a:      	jne	0x65aa <perf_unwind_dotnet+0x65aa>
    5c30:      	movl	$0x1772, %edx           # imm = 0x1772
    5c35:      	xorl	%ebx, %ebx
    5c37:      	movq	(%rip), %rax            # 0x5c3e <perf_unwind_dotnet+0x5c3e>
    5c3e:      	cmpl	$0x0, (%rax)
    5c41:      	jne	0x6d5d <perf_unwind_dotnet+0x6d5d>
    5c47:      	movl	$0x1772, %eax           # imm = 0x1772
    5c4c:      	testb	%bl, %bl
    5c4e:      	movq	0x60(%rsp), %r15
    5c53:      	movq	(%rip), %rbp            # 0x5c5a <perf_unwind_dotnet+0x5c5a>
    5c5a:      	je	0x7812 <perf_unwind_dotnet+0x7812>
    5c60:      	movl	0x2c0(%r14), %eax
    5c67:      	cmpq	$0x7e, %rax
    5c6b:      	ja	0x52f <perf_unwind_dotnet+0x52f>
    5c71:      	leal	0x1(%rax), %ecx
    5c74:      	movl	%ecx, 0x2c0(%r14)
    5c7b:      	leaq	(%rax,%rax,2), %rax
    5c7f:      	movq	$0x0, 0x2d0(%r14,%rax,8)
    5c8b:      	movq	$0x1773, 0x2d8(%r14,%rax,8) # imm = 0x1773
    5c97:      	movb	$-0x76, 0x2e0(%r14,%rax,8)
    5ca0:      	movl	$0x0, 0x2e1(%r14,%rax,8)
    5cac:      	movl	$0x0, 0x2e4(%r14,%rax,8)
    5cb8:      	jmp	0x6181 <perf_unwind_dotnet+0x6181>
    5cbd:      	andq	$-0x100, %r13
    5cc4:      	addq	$-0x20, %r13
    5cc8:      	movl	0x1178(%r14), %r15d
    5ccf:      	movq	(%rip), %rax            # 0x5cd6 <perf_unwind_dotnet+0x5cd6>
    5cd6:      	cmpl	$0x0, (%rax)
    5cd9:      	jne	0x673a <perf_unwind_dotnet+0x673a>
    5cdf:      	xorl	%ecx, %ecx
    5ce1:      	testl	%r15d, %r15d
    5ce4:      	je	0x67ce <perf_unwind_dotnet+0x67ce>
    5cea:      	movl	%ecx, %eax
    5cec:      	shll	$0x8, %eax
    5cef:      	subq	%rax, %r13
    5cf2:      	jae	0x6cf8 <perf_unwind_dotnet+0x6cf8>
    5cf8:      	movq	(%rip), %rax            # 0x5cff <perf_unwind_dotnet+0x5cff>
    5cff:      	cmpl	$0x0, (%rax)
    5d02:      	je	0x5b90 <perf_unwind_dotnet+0x5b90>
    5d08:      	movabsq	$0xa657361625f63, %rax  # imm = 0xA657361625F63
    5d12:      	movq	%rax, 0x36(%rsp)
    5d17:      	movabsq	$0x5f637020776f6c65, %rax # imm = 0x5F637020776F6C65
    5d21:      	movq	%rax, 0x30(%rsp)
    5d26:      	movabsq	$0x6220746e65772068, %rax # imm = 0x6220746E65772068
    5d30:      	movq	%rax, 0x28(%rsp)
    5d35:      	movabsq	$0x6372616573207061, %rax # imm = 0x6372616573207061
    5d3f:      	movq	%rax, 0x20(%rsp)
    5d44:      	movabsq	$0x6d20656c6262696e, %rax # imm = 0x6D20656C6262696E
    5d4e:      	movq	%rax, 0x18(%rsp)
    5d53:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    5d5d:      	movq	%rax, 0x10(%rsp)
    5d62:      	leaq	0x10(%rsp), %rdi
    5d67:      	movl	$0x2e, %eax
    5d6c:      	movl	$0x6, %ecx
    5d71:      	movl	$0x2e, %esi
    5d76:      	xorl	%eax, %eax
    5d78:      	callq	*%rcx
    5d7a:      	movq	(%rip), %rax            # 0x5d81 <perf_unwind_dotnet+0x5d81>
    5d81:      	cmpl	$0x0, (%rax)
    5d84:      	je	0x5b90 <perf_unwind_dotnet+0x5b90>
    5d8a:      	movabsq	$0x6e756f6620746f6e, %rax # imm = 0x6E756F6620746F6E
    5d94:      	movq	%rax, 0x18(%rsp)
    5d99:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    5da3:      	movq	%rax, 0x10(%rsp)
    5da8:      	movl	$0xa646e, 0x1f(%rsp)    # imm = 0xA646E
    5db0:      	leaq	0x10(%rsp), %rdi
    5db5:      	movl	$0x13, %eax
    5dba:      	movl	$0x6, %ecx
    5dbf:      	movl	$0x13, %esi
    5dc4:      	xorl	%eax, %eax
    5dc6:      	callq	*%rcx
    5dc8:      	jmp	0x5b90 <perf_unwind_dotnet+0x5b90>
    5dcd:      	movl	%r15d, %ecx
    5dd0:      	shrl	$0x8, %ecx
    5dd3:      	andl	$0xf, %ecx
    5dd6:      	je	0x5de1 <perf_unwind_dotnet+0x5de1>
    5dd8:      	addq	$-0x40, %r13
    5ddc:      	jmp	0x6081 <perf_unwind_dotnet+0x6081>
    5de1:      	movl	%r15d, %ecx
    5de4:      	shrl	$0xc, %ecx
    5de7:      	andl	$0xf, %ecx
    5dea:      	je	0x5e6a <perf_unwind_dotnet+0x5e6a>
    5dec:      	addq	$-0x60, %r13
    5df0:      	jmp	0x6081 <perf_unwind_dotnet+0x6081>
    5df5:      	movabsq	$0x6c25203a7066202c, %rax # imm = 0x6C25203A7066202C
    5dff:      	movq	%rax, 0x28(%rsp)
    5e04:      	movabsq	$0x786c25203a707320, %rax # imm = 0x786C25203A707320
    5e0e:      	movq	%rax, 0x20(%rsp)
    5e13:      	movabsq	$0x2c786c25203a6370, %rax # imm = 0x2C786C25203A6370
    5e1d:      	movq	%rax, 0x18(%rsp)
    5e22:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    5e2c:      	movq	%rax, 0x10(%rsp)
    5e31:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    5e39:      	leaq	0x10(%rsp), %rdi
    5e3e:      	movl	$0x23, %eax
    5e43:      	movl	$0x6, %r9d
    5e49:      	movl	$0x23, %esi
    5e4e:      	movq	%r12, %rdx
    5e51:      	movq	%rbx, %rcx
    5e54:      	movq	%r13, %r8
    5e57:      	xorl	%eax, %eax
    5e59:      	callq	*%r9
    5e5c:      	cmpq	%rbx, %r13
    5e5f:      	jae	0x5a17 <perf_unwind_dotnet+0x5a17>
    5e65:      	jmp	0x77bb <perf_unwind_dotnet+0x77bb>
    5e6a:      	movl	%r15d, %ecx
    5e6d:      	shrl	$0x10, %ecx
    5e70:      	andl	$0xf, %ecx
    5e73:      	je	0x5e7e <perf_unwind_dotnet+0x5e7e>
    5e75:      	addq	$-0x80, %r13
    5e79:      	jmp	0x6081 <perf_unwind_dotnet+0x6081>
    5e7e:      	movl	%r15d, %ecx
    5e81:      	shrl	$0x14, %ecx
    5e84:      	andl	$0xf, %ecx
    5e87:      	je	0x5f99 <perf_unwind_dotnet+0x5f99>
    5e8d:      	addq	$-0xa0, %r13
    5e94:      	jmp	0x6081 <perf_unwind_dotnet+0x6081>
    5e99:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5ea3:      	movq	%rax, 0x36(%rsp)
    5ea8:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5eb2:      	movq	%rax, 0x30(%rsp)
    5eb7:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5ec1:      	movq	%rax, 0x28(%rsp)
    5ec6:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5ed0:      	movq	%rax, 0x20(%rsp)
    5ed5:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5edf:      	movq	%rax, 0x18(%rsp)
    5ee4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5eee:      	movq	%rax, 0x10(%rsp)
    5ef3:      	leaq	0x10(%rsp), %rdi
    5ef8:      	movl	$0x2e, %eax
    5efd:      	movl	$0x6, %ecx
    5f02:      	movl	0xc(%rsp), %edx
    5f06:      	movl	$0x2e, %esi
    5f0b:      	xorl	%eax, %eax
    5f0d:      	callq	*%rcx
    5f0f:      	jmp	0x580b <perf_unwind_dotnet+0x580b>
    5f14:      	movabsq	$0x6c25203a7066202c, %rax # imm = 0x6C25203A7066202C
    5f1e:      	movq	%rax, 0x28(%rsp)
    5f23:      	movabsq	$0x786c25203a707320, %rax # imm = 0x786C25203A707320
    5f2d:      	movq	%rax, 0x20(%rsp)
    5f32:      	movabsq	$0x2c786c25203a6370, %rax # imm = 0x2C786C25203A6370
    5f3c:      	movq	%rax, 0x18(%rsp)
    5f41:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    5f4b:      	movq	%rax, 0x10(%rsp)
    5f50:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    5f58:      	leaq	0x10(%rsp), %rdi
    5f5d:      	movl	$0x23, %eax
    5f62:      	movl	$0x6, %r9d
    5f68:      	movq	0xed0(%r14), %rdx
    5f6f:      	movq	0xed8(%r14), %rcx
    5f76:      	movq	0xee0(%r14), %r8
    5f7d:      	movl	$0x23, %esi
    5f82:      	xorl	%eax, %eax
    5f84:      	callq	*%r9
    5f87:      	cmpq	$0x100, %rbp            # imm = 0x100
    5f8e:      	jae	0x5af5 <perf_unwind_dotnet+0x5af5>
    5f94:      	jmp	0x60ce <perf_unwind_dotnet+0x60ce>
    5f99:      	movl	%r15d, %ecx
    5f9c:      	shrl	$0x18, %ecx
    5f9f:      	andl	$0xf, %ecx
    5fa2:      	je	0x6073 <perf_unwind_dotnet+0x6073>
    5fa8:      	addq	$-0xc0, %r13
    5faf:      	jmp	0x6081 <perf_unwind_dotnet+0x6081>
    5fb4:      	leaq	(%rip), %rsi            # 0x5fbb <perf_unwind_dotnet+0x5fbb>
    5fbb:      	leaq	0x10(%rsp), %rax
    5fc0:      	movl	$0x8, %ecx
    5fc5:      	movq	%rax, %rdi
    5fc8:      	rep		movsq	(%rsi), %es:(%rdi)
    5fcb:      	movw	$0xa, 0x50(%rsp)
    5fd2:      	movl	$0x42, %ecx
    5fd7:      	movl	$0x6, %r9d
    5fdd:      	movq	%rax, %rdi
    5fe0:      	movl	$0x42, %esi
    5fe5:      	movq	%r13, %rdx
    5fe8:      	movq	%rbx, %rcx
    5feb:      	movq	%rbp, %r8
    5fee:      	xorl	%eax, %eax
    5ff0:      	callq	*%r9
    5ff3:      	jmp	0x5b19 <perf_unwind_dotnet+0x5b19>
    5ff8:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    6002:      	movq	%rax, 0x36(%rsp)
    6007:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    6011:      	movq	%rax, 0x30(%rsp)
    6016:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    6020:      	movq	%rax, 0x28(%rsp)
    6025:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    602f:      	movq	%rax, 0x20(%rsp)
    6034:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    603e:      	movq	%rax, 0x18(%rsp)
    6043:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    604d:      	movq	%rax, 0x10(%rsp)
    6052:      	leaq	0x10(%rsp), %rdi
    6057:      	movl	$0x2e, %eax
    605c:      	movl	$0x6, %ecx
    6061:      	movl	0x68(%rsp), %edx
    6065:      	movl	$0x2e, %esi
    606a:      	xorl	%eax, %eax
    606c:      	callq	*%rcx
    606e:      	jmp	0x59cb <perf_unwind_dotnet+0x59cb>
    6073:      	shrl	$0x1c, %r15d
    6077:      	addq	$-0xe0, %r13
    607e:      	movl	%r15d, %ecx
    6081:      	addq	%r13, %rbx
    6084:      	leal	-0x4(,%rcx,4), %r15d
    608c:      	addq	%rbx, %r15
    608f:      	movq	(%rip), %rax            # 0x6096 <perf_unwind_dotnet+0x6096>
    6096:      	cmpl	$0x0, (%rax)
    6099:      	jne	0x652b <perf_unwind_dotnet+0x652b>
    609f:      	leaq	-0x8(%r15), %rdx
    60a3:      	leaq	0x68(%rsp), %rdi
    60a8:      	movl	$0x8, %eax
    60ad:      	movl	$0x70, %ecx
    60b2:      	movl	$0x8, %esi
    60b7:      	callq	*%rcx
    60b9:      	testq	%rax, %rax
    60bc:      	movq	(%rip), %rbp            # 0x60c3 <perf_unwind_dotnet+0x60c3>
    60c3:      	jne	0xbb6 <perf_unwind_dotnet+0xbb6>
    60c9:      	movl	$0x1f, %ebp
    60ce:      	movq	(%rip), %rax            # 0x60d5 <perf_unwind_dotnet+0x60d5>
    60d5:      	cmpl	$0x0, (%rax)
    60d8:      	jne	0x6327 <perf_unwind_dotnet+0x6327>
    60de:      	movl	0x2c0(%r14), %eax
    60e5:      	cmpq	$0x7e, %rax
    60e9:      	ja	0xc0c <perf_unwind_dotnet+0xc0c>
    60ef:      	movq	0x68(%rsp), %rcx
    60f4:      	subq	%r15, %r12
    60f7:      	shlq	$0x5, %rcx
    60fb:      	addq	%rbp, %rcx
    60fe:      	leal	0x1(%rax), %edx
    6101:      	movl	%edx, 0x2c0(%r14)
    6108:      	leaq	(%rax,%rax,2), %rax
    610c:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    6114:      	movq	%r12, 0x2d8(%r14,%rax,8)
    611c:      	movb	$0xa, 0x2e0(%r14,%rax,8)
    6125:      	movzbl	0x88(%rsp), %ecx
    612d:      	movb	%cl, 0x2e1(%r14,%rax,8)
    6135:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    6141:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    614c:      	movl	$0x5b, 0xc(%rsp)
    6154:      	movq	(%rip), %rdi            # 0x615b <perf_unwind_dotnet+0x615b>
    615b:      	leaq	0xc(%rsp), %rsi
    6160:      	movl	$0x1, %eax
    6165:      	callq	*%rax
    6167:      	testq	%rax, %rax
    616a:      	je	0x6171 <perf_unwind_dotnet+0x6171>
    616c:      	incq	(%rax)
    616f:      	jmp	0x6181 <perf_unwind_dotnet+0x6181>
    6171:      	movq	(%rip), %rax            # 0x6178 <perf_unwind_dotnet+0x6178>
    6178:      	cmpl	$0x0, (%rax)
    617b:      	jne	0x6423 <perf_unwind_dotnet+0x6423>
    6181:      	movq	0x98(%rsp), %rax
    6189:      	movq	(%rax), %r13
    618c:      	movq	(%rip), %rax            # 0x6193 <perf_unwind_dotnet+0x6193>
    6193:      	movl	(%rax), %eax
    6195:      	testq	%r13, %r13
    6198:      	je	0x88ec <perf_unwind_dotnet+0x88ec>
    619e:      	testl	%eax, %eax
    61a0:      	jne	0x6386 <perf_unwind_dotnet+0x6386>
    61a6:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    61b0:      	cmpq	%rax, %r13
    61b3:      	ja	0x2516 <perf_unwind_dotnet+0x2516>
    61b9:      	cmpq	$0x1000, %r13           # imm = 0x1000
    61c0:      	jb	0x26b1 <perf_unwind_dotnet+0x26b1>
    61c6:      	movl	(%r14), %eax
    61c9:      	movl	$0x60, 0x70(%rsp)
    61d1:      	movbel	%eax, 0x74(%rsp)
    61d7:      	movbeq	%r13, 0x78(%rsp)
    61de:      	movq	(%rip), %rdi            # 0x61e5 <perf_unwind_dotnet+0x61e5>
    61e5:      	leaq	0x70(%rsp), %rsi
    61ea:      	movl	$0x1, %eax
    61ef:      	callq	*%rax
    61f1:      	testq	%rax, %rax
    61f4:      	je	0x8837 <perf_unwind_dotnet+0x8837>
    61fa:      	movq	0x8(%rax), %r12
    61fe:      	movq	%r12, %rcx
    6201:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    620b:      	andq	%rdx, %rcx
    620e:      	movq	%rcx, 0xf20(%r14)
    6215:      	movq	(%rax), %rax
    6218:      	movq	%rax, 0xf10(%r14)
    621f:      	shrq	$0x38, %r12
    6223:      	movq	%r13, %rax
    6226:      	subq	%rcx, %rax
    6229:      	movq	%rax, 0xf18(%r14)
    6230:      	movq	(%rip), %rax            # 0x6237 <perf_unwind_dotnet+0x6237>
    6237:      	cmpl	$0x0, (%rax)
    623a:      	jne	0x6625 <perf_unwind_dotnet+0x6625>
    6240:      	cmpl	$0x1, %r12d
    6244:      	jne	0x7322 <perf_unwind_dotnet+0x7322>
    624a:      	movq	0xf10(%r14), %rax
    6251:      	movq	%rax, 0x70(%rsp)
    6256:      	movq	0xf18(%r14), %rbx
    625d:      	movq	(%rip), %rdi            # 0x6264 <perf_unwind_dotnet+0x6264>
    6264:      	leaq	0x70(%rsp), %rsi
    6269:      	movl	$0x1, %eax
    626e:      	callq	*%rax
    6270:      	movl	$0x1, %r12d
    6276:      	testq	%rax, %rax
    6279:      	je	0x7322 <perf_unwind_dotnet+0x7322>
    627f:      	movq	%rax, %r15
    6282:      	cmpq	%rbx, (%rax)
    6285:      	ja	0x628d <perf_unwind_dotnet+0x628d>
    6287:      	cmpq	%rbx, 0x8(%r15)
    628b:      	jae	0x62a1 <perf_unwind_dotnet+0x62a1>
    628d:      	cmpq	%rbx, 0x10(%r15)
    6291:      	ja	0x7322 <perf_unwind_dotnet+0x7322>
    6297:      	cmpq	%rbx, 0x18(%r15)
    629b:      	jb	0x7322 <perf_unwind_dotnet+0x7322>
    62a1:      	movq	(%rip), %rax            # 0x62a8 <perf_unwind_dotnet+0x62a8>
    62a8:      	cmpl	$0x0, (%rax)
    62ab:      	jne	0x727b <perf_unwind_dotnet+0x727b>
    62b1:      	movl	0x1380(%r14), %eax
    62b8:      	movl	0x20(%r15), %ecx
    62bc:      	btl	%ecx, %eax
    62bf:      	jae	0x72e8 <perf_unwind_dotnet+0x72e8>
    62c5:      	movq	(%rip), %rax            # 0x62cc <perf_unwind_dotnet+0x62cc>
    62cc:      	cmpl	$0x0, (%rax)
    62cf:      	je	0x7322 <perf_unwind_dotnet+0x7322>
    62d5:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    62df:      	movq	%rax, 0x20(%rsp)
    62e4:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    62ee:      	movq	%rax, 0x18(%rsp)
    62f3:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    62fd:      	movq	%rax, 0x10(%rsp)
    6302:      	movl	$0xa656e, 0x27(%rsp)    # imm = 0xA656E
    630a:      	leaq	0x10(%rsp), %rdi
    630f:      	movl	$0x1b, %eax
    6314:      	movl	$0x6, %ecx
    6319:      	movl	$0x1b, %esi
    631e:      	xorl	%eax, %eax
    6320:      	callq	*%rcx
    6322:      	jmp	0x7322 <perf_unwind_dotnet+0x7322>
    6327:      	leaq	(%rip), %rsi            # 0x632e <perf_unwind_dotnet+0x632e>
    632e:      	leaq	0x10(%rsp), %rax
    6333:      	movl	$0x8, %ecx
    6338:      	movq	%rax, %rdi
    633b:      	rep		movsq	(%rsi), %es:(%rdi)
    633e:      	movb	$0x0, 0x52(%rsp)
    6343:      	movw	$0xa78, 0x50(%rsp)      # imm = 0xA78
    634a:      	movl	$0x43, %ecx
    634f:      	movl	$0x6, %r9d
    6355:      	movq	0x68(%rsp), %rcx
    635a:      	movq	%r12, %r8
    635d:      	subq	%r15, %r8
    6360:      	movq	%rax, %rdi
    6363:      	movl	$0x43, %esi
    6368:      	movq	%r15, %rdx
    636b:      	xorl	%eax, %eax
    636d:      	callq	*%r9
    6370:      	movl	0x2c0(%r14), %eax
    6377:      	cmpq	$0x7e, %rax
    637b:      	ja	0xc0c <perf_unwind_dotnet+0xc0c>
    6381:      	jmp	0x60ef <perf_unwind_dotnet+0x60ef>
    6386:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    6390:      	movq	%rax, 0x38(%rsp)
    6395:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    639f:      	movq	%rax, 0x30(%rsp)
    63a4:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    63ae:      	movq	%rax, 0x28(%rsp)
    63b3:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    63bd:      	movq	%rax, 0x20(%rsp)
    63c2:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    63cc:      	movq	%rax, 0x18(%rsp)
    63d1:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    63db:      	movq	%rax, 0x10(%rsp)
    63e0:      	movb	$0x0, 0x40(%rsp)
    63e5:      	leaq	0x10(%rsp), %rdi
    63ea:      	movl	$0x31, %eax
    63ef:      	movl	$0x6, %ecx
    63f4:      	movl	0x2c0(%r14), %edx
    63fb:      	movl	$0x31, %esi
    6400:      	xorl	%eax, %eax
    6402:      	callq	*%rcx
    6404:      	movq	0xed0(%r14), %r13
    640b:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    6415:      	cmpq	%rax, %r13
    6418:      	ja	0x2516 <perf_unwind_dotnet+0x2516>
    641e:      	jmp	0x61b9 <perf_unwind_dotnet+0x61b9>
    6423:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    642d:      	movq	%rax, 0x36(%rsp)
    6432:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    643c:      	movq	%rax, 0x30(%rsp)
    6441:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    644b:      	movq	%rax, 0x28(%rsp)
    6450:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    645a:      	movq	%rax, 0x20(%rsp)
    645f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    6469:      	movq	%rax, 0x18(%rsp)
    646e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6478:      	movq	%rax, 0x10(%rsp)
    647d:      	leaq	0x10(%rsp), %rdi
    6482:      	movl	$0x2e, %eax
    6487:      	movl	$0x6, %ecx
    648c:      	movl	0xc(%rsp), %edx
    6490:      	movl	$0x2e, %esi
    6495:      	xorl	%eax, %eax
    6497:      	callq	*%rcx
    6499:      	jmp	0x6181 <perf_unwind_dotnet+0x6181>
    649e:      	movabsq	$0xa782520797274, %rax  # imm = 0xA782520797274
    64a8:      	movq	%rax, 0x3e(%rsp)
    64ad:      	movabsq	$0x72746e6520747372, %rax # imm = 0x72746E6520747372
    64b7:      	movq	%rax, 0x38(%rsp)
    64bc:      	movabsq	$0x6966203a786c2520, %rax # imm = 0x6966203A786C2520
    64c6:      	movq	%rax, 0x30(%rsp)
    64cb:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    64d5:      	movq	%rax, 0x28(%rsp)
    64da:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    64e4:      	movq	%rax, 0x20(%rsp)
    64e9:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    64f3:      	movq	%rax, 0x18(%rsp)
    64f8:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    6502:      	movq	%rax, 0x10(%rsp)
    6507:      	leaq	0x10(%rsp), %rdi
    650c:      	movl	$0x36, %eax
    6511:      	movl	$0x6, %r8d
    6517:      	movl	$0x36, %esi
    651c:      	movq	%r15, %rdx
    651f:      	movl	%ebp, %ecx
    6521:      	xorl	%eax, %eax
    6523:      	callq	*%r8
    6526:      	jmp	0x5bcc <perf_unwind_dotnet+0x5bcc>
    652b:      	movabsq	$0xa786c253d7465, %rax  # imm = 0xA786C253D7465
    6535:      	movq	%rax, 0x36(%rsp)
    653a:      	movabsq	$0x746572202c78253d, %rax # imm = 0x746572202C78253D
    6544:      	movq	%rax, 0x30(%rsp)
    6549:      	movabsq	$0x6c6176202c786c25, %rax # imm = 0x6C6176202C786C25
    6553:      	movq	%rax, 0x28(%rsp)
    6558:      	movabsq	$0x203d2061746c6564, %rax # imm = 0x203D2061746C6564
    6562:      	movq	%rax, 0x20(%rsp)
    6567:      	movabsq	$0x5f6370203e2d2d20, %rax # imm = 0x5F6370203E2D2D20
    6571:      	movq	%rax, 0x18(%rsp)
    6576:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    6580:      	movq	%rax, 0x10(%rsp)
    6585:      	leaq	0x10(%rsp), %rdi
    658a:      	movl	$0x2e, %eax
    658f:      	movl	$0x6, %r9d
    6595:      	movl	$0x2e, %esi
    659a:      	movq	%r13, %rdx
    659d:      	movq	%r15, %r8
    65a0:      	xorl	%eax, %eax
    65a2:      	callq	*%r9
    65a5:      	jmp	0x609f <perf_unwind_dotnet+0x609f>
    65aa:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    65b4:      	movq	%rax, 0x36(%rsp)
    65b9:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    65c3:      	movq	%rax, 0x30(%rsp)
    65c8:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    65d2:      	movq	%rax, 0x28(%rsp)
    65d7:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    65e1:      	movq	%rax, 0x20(%rsp)
    65e6:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    65f0:      	movq	%rax, 0x18(%rsp)
    65f5:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    65ff:      	movq	%rax, 0x10(%rsp)
    6604:      	leaq	0x10(%rsp), %rdi
    6609:      	movl	$0x2e, %eax
    660e:      	movl	$0x6, %ecx
    6613:      	movl	0xc(%rsp), %edx
    6617:      	movl	$0x2e, %esi
    661c:      	xorl	%eax, %eax
    661e:      	callq	*%rcx
    6620:      	jmp	0x5c30 <perf_unwind_dotnet+0x5c30>
    6625:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    662f:      	movq	%rax, 0x38(%rsp)
    6634:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    663e:      	movq	%rax, 0x30(%rsp)
    6643:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    664d:      	movq	%rax, 0x28(%rsp)
    6652:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    665c:      	movq	%rax, 0x20(%rsp)
    6661:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    666b:      	movq	%rax, 0x18(%rsp)
    6670:      	movabsq	$0x6365732074786554, %rbx # imm = 0x6365732074786554
    667a:      	movq	%rbx, 0x10(%rsp)
    667f:      	movw	$0xa, 0x40(%rsp)
    6686:      	leaq	0x10(%rsp), %rdi
    668b:      	movl	$0x32, %eax
    6690:      	movl	$0x6, %r9d
    6696:      	movq	0xf10(%r14), %rcx
    669d:      	movl	$0x32, %esi
    66a2:      	movq	%r13, %rdx
    66a5:      	movl	%r12d, %r8d
    66a8:      	xorl	%eax, %eax
    66aa:      	callq	*%r9
    66ad:      	movq	(%rip), %rax            # 0x66b4 <perf_unwind_dotnet+0x66b4>
    66b4:      	cmpl	$0x0, (%rax)
    66b7:      	je	0x6240 <perf_unwind_dotnet+0x6240>
    66bd:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    66c7:      	movq	%rax, 0x37(%rsp)
    66cc:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    66d6:      	movq	%rax, 0x30(%rsp)
    66db:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    66e5:      	movq	%rax, 0x28(%rsp)
    66ea:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    66f4:      	movq	%rax, 0x20(%rsp)
    66f9:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    6703:      	movq	%rax, 0x18(%rsp)
    6708:      	movq	%rbx, 0x10(%rsp)
    670d:      	leaq	0x10(%rsp), %rdi
    6712:      	movl	$0x2f, %eax
    6717:      	movl	$0x6, %r8d
    671d:      	movq	0xf18(%r14), %rcx
    6724:      	movq	0xf20(%r14), %rdx
    672b:      	movl	$0x2f, %esi
    6730:      	xorl	%eax, %eax
    6732:      	callq	*%r8
    6735:      	jmp	0x6240 <perf_unwind_dotnet+0x6240>
    673a:      	movabsq	$0xa782520797274, %rax  # imm = 0xA782520797274
    6744:      	movq	%rax, 0x3f(%rsp)
    6749:      	movabsq	$0x746e6520646e6f63, %rax # imm = 0x746E6520646E6F63
    6753:      	movq	%rax, 0x38(%rsp)
    6758:      	movabsq	$0x6573203a786c2520, %rax # imm = 0x6573203A786C2520
    6762:      	movq	%rax, 0x30(%rsp)
    6767:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    6771:      	movq	%rax, 0x28(%rsp)
    6776:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    6780:      	movq	%rax, 0x20(%rsp)
    6785:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    678f:      	movq	%rax, 0x18(%rsp)
    6794:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    679e:      	movq	%rax, 0x10(%rsp)
    67a3:      	leaq	0x10(%rsp), %rdi
    67a8:      	movl	$0x37, %eax
    67ad:      	movl	$0x6, %r8d
    67b3:      	movl	$0x37, %esi
    67b8:      	movq	%r13, %rdx
    67bb:      	movl	%r15d, %ecx
    67be:      	xorl	%eax, %eax
    67c0:      	callq	*%r8
    67c3:      	xorl	%ecx, %ecx
    67c5:      	testl	%r15d, %r15d
    67c8:      	jne	0x5cea <perf_unwind_dotnet+0x5cea>
    67ce:      	movq	0x1170(%r14), %rax
    67d5:      	movl	$0xffffff84, %ecx       # imm = 0xFFFFFF84
    67da:      	testq	%rax, %rax
    67dd:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    67e3:      	movq	0x1168(%r14), %rax
    67ea:      	movl	$0xffffff86, %ecx       # imm = 0xFFFFFF86
    67ef:      	testq	%rax, %rax
    67f2:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    67f8:      	movq	0x1160(%r14), %rax
    67ff:      	movl	$0xffffff88, %ecx       # imm = 0xFFFFFF88
    6804:      	testq	%rax, %rax
    6807:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    680d:      	movq	0x1158(%r14), %rax
    6814:      	movl	$0xffffff8a, %ecx       # imm = 0xFFFFFF8A
    6819:      	testq	%rax, %rax
    681c:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6822:      	movq	0x1150(%r14), %rax
    6829:      	movl	$0xffffff8c, %ecx       # imm = 0xFFFFFF8C
    682e:      	testq	%rax, %rax
    6831:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6837:      	movq	0x1148(%r14), %rax
    683e:      	movl	$0xffffff8e, %ecx       # imm = 0xFFFFFF8E
    6843:      	testq	%rax, %rax
    6846:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    684c:      	movq	0x1140(%r14), %rax
    6853:      	movl	$0xffffff90, %ecx       # imm = 0xFFFFFF90
    6858:      	testq	%rax, %rax
    685b:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6861:      	movq	0x1138(%r14), %rax
    6868:      	movl	$0xffffff92, %ecx       # imm = 0xFFFFFF92
    686d:      	testq	%rax, %rax
    6870:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6876:      	movq	0x1130(%r14), %rax
    687d:      	movl	$0xffffff94, %ecx       # imm = 0xFFFFFF94
    6882:      	testq	%rax, %rax
    6885:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    688b:      	movq	0x1128(%r14), %rax
    6892:      	movl	$0xffffff96, %ecx       # imm = 0xFFFFFF96
    6897:      	testq	%rax, %rax
    689a:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    68a0:      	movq	0x1120(%r14), %rax
    68a7:      	movl	$0xffffff98, %ecx       # imm = 0xFFFFFF98
    68ac:      	testq	%rax, %rax
    68af:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    68b5:      	movq	0x1118(%r14), %rax
    68bc:      	movl	$0xffffff9a, %ecx       # imm = 0xFFFFFF9A
    68c1:      	testq	%rax, %rax
    68c4:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    68ca:      	movq	0x1110(%r14), %rax
    68d1:      	movl	$0xffffff9c, %ecx       # imm = 0xFFFFFF9C
    68d6:      	testq	%rax, %rax
    68d9:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    68df:      	movq	0x1108(%r14), %rax
    68e6:      	movl	$0xffffff9e, %ecx       # imm = 0xFFFFFF9E
    68eb:      	testq	%rax, %rax
    68ee:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    68f4:      	movq	0x1100(%r14), %rax
    68fb:      	movl	$0xffffffa0, %ecx       # imm = 0xFFFFFFA0
    6900:      	testq	%rax, %rax
    6903:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6909:      	movq	0x10f8(%r14), %rax
    6910:      	movl	$0xffffffa2, %ecx       # imm = 0xFFFFFFA2
    6915:      	testq	%rax, %rax
    6918:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    691e:      	movq	0x10f0(%r14), %rax
    6925:      	movl	$0xffffffa4, %ecx       # imm = 0xFFFFFFA4
    692a:      	testq	%rax, %rax
    692d:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6933:      	movq	0x10e8(%r14), %rax
    693a:      	movl	$0xffffffa6, %ecx       # imm = 0xFFFFFFA6
    693f:      	testq	%rax, %rax
    6942:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6948:      	movq	0x10e0(%r14), %rax
    694f:      	movl	$0xffffffa8, %ecx       # imm = 0xFFFFFFA8
    6954:      	testq	%rax, %rax
    6957:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    695d:      	movq	0x10d8(%r14), %rax
    6964:      	movl	$0xffffffaa, %ecx       # imm = 0xFFFFFFAA
    6969:      	testq	%rax, %rax
    696c:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6972:      	movq	0x10d0(%r14), %rax
    6979:      	movl	$0xffffffac, %ecx       # imm = 0xFFFFFFAC
    697e:      	testq	%rax, %rax
    6981:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6987:      	movq	0x10c8(%r14), %rax
    698e:      	movl	$0xffffffae, %ecx       # imm = 0xFFFFFFAE
    6993:      	testq	%rax, %rax
    6996:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    699c:      	movq	0x10c0(%r14), %rax
    69a3:      	movl	$0xffffffb0, %ecx       # imm = 0xFFFFFFB0
    69a8:      	testq	%rax, %rax
    69ab:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    69b1:      	movq	0x10b8(%r14), %rax
    69b8:      	movl	$0xffffffb2, %ecx       # imm = 0xFFFFFFB2
    69bd:      	testq	%rax, %rax
    69c0:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    69c6:      	movq	0x10b0(%r14), %rax
    69cd:      	movl	$0xffffffb4, %ecx       # imm = 0xFFFFFFB4
    69d2:      	testq	%rax, %rax
    69d5:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    69db:      	movq	0x10a8(%r14), %rax
    69e2:      	movl	$0xffffffb6, %ecx       # imm = 0xFFFFFFB6
    69e7:      	testq	%rax, %rax
    69ea:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    69f0:      	movq	0x10a0(%r14), %rax
    69f7:      	movl	$0xffffffb8, %ecx       # imm = 0xFFFFFFB8
    69fc:      	testq	%rax, %rax
    69ff:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6a05:      	movq	0x1098(%r14), %rax
    6a0c:      	movl	$0xffffffba, %ecx       # imm = 0xFFFFFFBA
    6a11:      	testq	%rax, %rax
    6a14:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6a1a:      	movq	0x1090(%r14), %rax
    6a21:      	movl	$0xffffffbc, %ecx       # imm = 0xFFFFFFBC
    6a26:      	testq	%rax, %rax
    6a29:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6a2f:      	movq	0x1088(%r14), %rax
    6a36:      	movl	$0xffffffbe, %ecx       # imm = 0xFFFFFFBE
    6a3b:      	testq	%rax, %rax
    6a3e:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6a44:      	movq	0x1080(%r14), %rax
    6a4b:      	movl	$0xffffffc0, %ecx       # imm = 0xFFFFFFC0
    6a50:      	testq	%rax, %rax
    6a53:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6a59:      	movq	0x1078(%r14), %rax
    6a60:      	movl	$0xffffffc2, %ecx       # imm = 0xFFFFFFC2
    6a65:      	testq	%rax, %rax
    6a68:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6a6e:      	movq	0x1070(%r14), %rax
    6a75:      	movl	$0xffffffc4, %ecx       # imm = 0xFFFFFFC4
    6a7a:      	testq	%rax, %rax
    6a7d:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6a83:      	movq	0x1068(%r14), %rax
    6a8a:      	movl	$0xffffffc6, %ecx       # imm = 0xFFFFFFC6
    6a8f:      	testq	%rax, %rax
    6a92:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6a98:      	movq	0x1060(%r14), %rax
    6a9f:      	movl	$0xffffffc8, %ecx       # imm = 0xFFFFFFC8
    6aa4:      	testq	%rax, %rax
    6aa7:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6aad:      	movq	0x1058(%r14), %rax
    6ab4:      	movl	$0xffffffca, %ecx       # imm = 0xFFFFFFCA
    6ab9:      	testq	%rax, %rax
    6abc:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6ac2:      	movq	0x1050(%r14), %rax
    6ac9:      	movl	$0xffffffcc, %ecx       # imm = 0xFFFFFFCC
    6ace:      	testq	%rax, %rax
    6ad1:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6ad7:      	movq	0x1048(%r14), %rax
    6ade:      	movl	$0xffffffce, %ecx       # imm = 0xFFFFFFCE
    6ae3:      	testq	%rax, %rax
    6ae6:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6aec:      	movq	0x1040(%r14), %rax
    6af3:      	movl	$0xffffffd0, %ecx       # imm = 0xFFFFFFD0
    6af8:      	testq	%rax, %rax
    6afb:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6b01:      	movq	0x1038(%r14), %rax
    6b08:      	movl	$0xffffffd2, %ecx       # imm = 0xFFFFFFD2
    6b0d:      	testq	%rax, %rax
    6b10:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6b16:      	movq	0x1030(%r14), %rax
    6b1d:      	movl	$0xffffffd4, %ecx       # imm = 0xFFFFFFD4
    6b22:      	testq	%rax, %rax
    6b25:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6b2b:      	movq	0x1028(%r14), %rax
    6b32:      	movl	$0xffffffd6, %ecx       # imm = 0xFFFFFFD6
    6b37:      	testq	%rax, %rax
    6b3a:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6b40:      	movq	0x1020(%r14), %rax
    6b47:      	movl	$0xffffffd8, %ecx       # imm = 0xFFFFFFD8
    6b4c:      	testq	%rax, %rax
    6b4f:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6b55:      	movq	0x1018(%r14), %rax
    6b5c:      	movl	$0xffffffda, %ecx       # imm = 0xFFFFFFDA
    6b61:      	testq	%rax, %rax
    6b64:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6b6a:      	movq	0x1010(%r14), %rax
    6b71:      	movl	$0xffffffdc, %ecx       # imm = 0xFFFFFFDC
    6b76:      	testq	%rax, %rax
    6b79:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6b7f:      	movq	0x1008(%r14), %rax
    6b86:      	movl	$0xffffffde, %ecx       # imm = 0xFFFFFFDE
    6b8b:      	testq	%rax, %rax
    6b8e:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6b94:      	movq	0x1000(%r14), %rax
    6b9b:      	movl	$0xffffffe0, %ecx       # imm = 0xFFFFFFE0
    6ba0:      	testq	%rax, %rax
    6ba3:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6ba9:      	movq	0xff8(%r14), %rax
    6bb0:      	movl	$0xffffffe2, %ecx       # imm = 0xFFFFFFE2
    6bb5:      	testq	%rax, %rax
    6bb8:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6bbe:      	movq	0xff0(%r14), %rax
    6bc5:      	movl	$0xffffffe4, %ecx       # imm = 0xFFFFFFE4
    6bca:      	testq	%rax, %rax
    6bcd:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6bd3:      	movq	0xfe8(%r14), %rax
    6bda:      	movl	$0xffffffe6, %ecx       # imm = 0xFFFFFFE6
    6bdf:      	testq	%rax, %rax
    6be2:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6be8:      	movq	0xfe0(%r14), %rax
    6bef:      	movl	$0xffffffe8, %ecx       # imm = 0xFFFFFFE8
    6bf4:      	testq	%rax, %rax
    6bf7:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6bfd:      	movq	0xfd8(%r14), %rax
    6c04:      	movl	$0xffffffea, %ecx       # imm = 0xFFFFFFEA
    6c09:      	testq	%rax, %rax
    6c0c:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6c12:      	movq	0xfd0(%r14), %rax
    6c19:      	movl	$0xffffffec, %ecx       # imm = 0xFFFFFFEC
    6c1e:      	testq	%rax, %rax
    6c21:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6c27:      	movq	0xfc8(%r14), %rax
    6c2e:      	movl	$0xffffffee, %ecx       # imm = 0xFFFFFFEE
    6c33:      	testq	%rax, %rax
    6c36:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6c3c:      	movq	0xfc0(%r14), %rax
    6c43:      	movl	$0xfffffff0, %ecx       # imm = 0xFFFFFFF0
    6c48:      	testq	%rax, %rax
    6c4b:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6c51:      	movq	0xfb8(%r14), %rax
    6c58:      	movl	$0xfffffff2, %ecx       # imm = 0xFFFFFFF2
    6c5d:      	testq	%rax, %rax
    6c60:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6c62:      	movq	0xfb0(%r14), %rax
    6c69:      	movl	$0xfffffff4, %ecx       # imm = 0xFFFFFFF4
    6c6e:      	testq	%rax, %rax
    6c71:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6c73:      	movq	0xfa8(%r14), %rax
    6c7a:      	movl	$0xfffffff6, %ecx       # imm = 0xFFFFFFF6
    6c7f:      	testq	%rax, %rax
    6c82:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6c84:      	movq	0xfa0(%r14), %rax
    6c8b:      	movl	$0xfffffff8, %ecx       # imm = 0xFFFFFFF8
    6c90:      	testq	%rax, %rax
    6c93:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6c95:      	movq	0xf98(%r14), %rax
    6c9c:      	movl	$0xfffffffa, %ecx       # imm = 0xFFFFFFFA
    6ca1:      	testq	%rax, %rax
    6ca4:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6ca6:      	movq	0xf90(%r14), %rax
    6cad:      	movl	$0xfffffffc, %ecx       # imm = 0xFFFFFFFC
    6cb2:      	testq	%rax, %rax
    6cb5:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6cb7:      	movq	0xf88(%r14), %rax
    6cbe:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    6cc3:      	testq	%rax, %rax
    6cc6:      	jne	0x6cd5 <perf_unwind_dotnet+0x6cd5>
    6cc8:      	movq	0x90(%rsp), %rax
    6cd0:      	movq	(%rax), %rax
    6cd3:      	xorl	%ecx, %ecx
    6cd5:      	xorl	%edx, %edx
    6cd7:      	movq	%rax, %r15
    6cda:      	shrq	$0x20, %r15
    6cde:      	setne	%dl
    6ce1:      	cmovel	%eax, %r15d
    6ce5:      	subl	%edx, %ecx
    6ce7:      	addl	$0x7e, %ecx
    6cea:      	movl	%ecx, %eax
    6cec:      	shll	$0x8, %eax
    6cef:      	subq	%rax, %r13
    6cf2:      	jb	0x5cf8 <perf_unwind_dotnet+0x5cf8>
    6cf8:      	movq	(%rip), %rax            # 0x6cff <perf_unwind_dotnet+0x6cff>
    6cff:      	cmpl	$0x0, (%rax)
    6d02:      	jne	0x71dc <perf_unwind_dotnet+0x71dc>
    6d08:      	testl	%r15d, %r15d
    6d0b:      	jne	0x5bfc <perf_unwind_dotnet+0x5bfc>
    6d11:      	movl	$0x5f, 0xc(%rsp)
    6d19:      	movq	(%rip), %rdi            # 0x6d20 <perf_unwind_dotnet+0x6d20>
    6d20:      	leaq	0xc(%rsp), %rsi
    6d25:      	movl	$0x1, %eax
    6d2a:      	callq	*%rax
    6d2c:      	testq	%rax, %rax
    6d2f:      	je	0x6d36 <perf_unwind_dotnet+0x6d36>
    6d31:      	incq	(%rax)
    6d34:      	jmp	0x6d46 <perf_unwind_dotnet+0x6d46>
    6d36:      	movq	(%rip), %rax            # 0x6d3d <perf_unwind_dotnet+0x6d3d>
    6d3d:      	cmpl	$0x0, (%rax)
    6d40:      	jne	0x7ae0 <perf_unwind_dotnet+0x7ae0>
    6d46:      	movl	$0x1773, %edx           # imm = 0x1773
    6d4b:      	movb	$0x1, %bl
    6d4d:      	movq	(%rip), %rax            # 0x6d54 <perf_unwind_dotnet+0x6d54>
    6d54:      	cmpl	$0x0, (%rax)
    6d57:      	je	0x5c47 <perf_unwind_dotnet+0x5c47>
    6d5d:      	movabsq	$0xa642520687469, %rax  # imm = 0xA642520687469
    6d67:      	movq	%rax, 0x30(%rsp)
    6d6c:      	movabsq	$0x772064656c696166, %rax # imm = 0x772064656C696166
    6d76:      	movq	%rax, 0x28(%rsp)
    6d7b:      	movabsq	$0x2074726174735f65, %rax # imm = 0x2074726174735F65
    6d85:      	movq	%rax, 0x20(%rsp)
    6d8a:      	movabsq	$0x646f63203e2d2d20, %rax # imm = 0x646F63203E2D2D20
    6d94:      	movq	%rax, 0x18(%rsp)
    6d99:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    6da3:      	movq	%rax, 0x10(%rsp)
    6da8:      	leaq	0x10(%rsp), %rdi
    6dad:      	movl	$0x28, %eax
    6db2:      	movl	$0x6, %ecx
    6db7:      	movl	$0x28, %esi
    6dbc:      	xorl	%eax, %eax
    6dbe:      	callq	*%rcx
    6dc0:      	jmp	0x5c47 <perf_unwind_dotnet+0x5c47>
    6dc5:      	movq	0x1108(%r14), %rax
    6dcc:      	movl	$0xffffff9e, %ecx       # imm = 0xFFFFFF9E
    6dd1:      	testq	%rax, %rax
    6dd4:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    6dda:      	movq	0x1100(%r14), %rax
    6de1:      	movl	$0xffffffa0, %ecx       # imm = 0xFFFFFFA0
    6de6:      	testq	%rax, %rax
    6de9:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    6def:      	movq	0x10f8(%r14), %rax
    6df6:      	movl	$0xffffffa2, %ecx       # imm = 0xFFFFFFA2
    6dfb:      	testq	%rax, %rax
    6dfe:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    6e04:      	movq	0x10f0(%r14), %rax
    6e0b:      	movl	$0xffffffa4, %ecx       # imm = 0xFFFFFFA4
    6e10:      	testq	%rax, %rax
    6e13:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    6e19:      	movq	0x10e8(%r14), %rax
    6e20:      	movl	$0xffffffa6, %ecx       # imm = 0xFFFFFFA6
    6e25:      	testq	%rax, %rax
    6e28:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    6e2e:      	movq	0x10e0(%r14), %rax
    6e35:      	movl	$0xffffffa8, %ecx       # imm = 0xFFFFFFA8
    6e3a:      	testq	%rax, %rax
    6e3d:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    6e43:      	movq	0x10d8(%r14), %rax
    6e4a:      	movl	$0xffffffaa, %ecx       # imm = 0xFFFFFFAA
    6e4f:      	testq	%rax, %rax
    6e52:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    6e58:      	movq	0x10d0(%r14), %rax
    6e5f:      	movl	$0xffffffac, %ecx       # imm = 0xFFFFFFAC
    6e64:      	testq	%rax, %rax
    6e67:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    6e6d:      	movq	0x10c8(%r14), %rax
    6e74:      	movl	$0xffffffae, %ecx       # imm = 0xFFFFFFAE
    6e79:      	testq	%rax, %rax
    6e7c:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    6e82:      	movq	0x10c0(%r14), %rax
    6e89:      	movl	$0xffffffb0, %ecx       # imm = 0xFFFFFFB0
    6e8e:      	testq	%rax, %rax
    6e91:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    6e97:      	movq	0x10b8(%r14), %rax
    6e9e:      	movl	$0xffffffb2, %ecx       # imm = 0xFFFFFFB2
    6ea3:      	testq	%rax, %rax
    6ea6:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    6eac:      	movq	0x10b0(%r14), %rax
    6eb3:      	movl	$0xffffffb4, %ecx       # imm = 0xFFFFFFB4
    6eb8:      	testq	%rax, %rax
    6ebb:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    6ec1:      	movq	0x10a8(%r14), %rax
    6ec8:      	movl	$0xffffffb6, %ecx       # imm = 0xFFFFFFB6
    6ecd:      	testq	%rax, %rax
    6ed0:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    6ed6:      	movq	0x10a0(%r14), %rax
    6edd:      	movl	$0xffffffb8, %ecx       # imm = 0xFFFFFFB8
    6ee2:      	testq	%rax, %rax
    6ee5:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    6eeb:      	movq	0x1098(%r14), %rax
    6ef2:      	movl	$0xffffffba, %ecx       # imm = 0xFFFFFFBA
    6ef7:      	testq	%rax, %rax
    6efa:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    6f00:      	movq	0x1090(%r14), %rax
    6f07:      	movl	$0xffffffbc, %ecx       # imm = 0xFFFFFFBC
    6f0c:      	testq	%rax, %rax
    6f0f:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    6f15:      	movq	0x1088(%r14), %rax
    6f1c:      	movl	$0xffffffbe, %ecx       # imm = 0xFFFFFFBE
    6f21:      	testq	%rax, %rax
    6f24:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    6f2a:      	movq	0x1080(%r14), %rax
    6f31:      	movl	$0xffffffc0, %ecx       # imm = 0xFFFFFFC0
    6f36:      	testq	%rax, %rax
    6f39:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    6f3f:      	movq	0x1078(%r14), %rax
    6f46:      	movl	$0xffffffc2, %ecx       # imm = 0xFFFFFFC2
    6f4b:      	testq	%rax, %rax
    6f4e:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    6f54:      	movq	0x1070(%r14), %rax
    6f5b:      	movl	$0xffffffc4, %ecx       # imm = 0xFFFFFFC4
    6f60:      	testq	%rax, %rax
    6f63:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    6f69:      	movq	0x1068(%r14), %rax
    6f70:      	movl	$0xffffffc6, %ecx       # imm = 0xFFFFFFC6
    6f75:      	testq	%rax, %rax
    6f78:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    6f7e:      	movq	0x1060(%r14), %rax
    6f85:      	movl	$0xffffffc8, %ecx       # imm = 0xFFFFFFC8
    6f8a:      	testq	%rax, %rax
    6f8d:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    6f93:      	movq	0x1058(%r14), %rax
    6f9a:      	movl	$0xffffffca, %ecx       # imm = 0xFFFFFFCA
    6f9f:      	testq	%rax, %rax
    6fa2:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    6fa8:      	movq	0x1050(%r14), %rax
    6faf:      	movl	$0xffffffcc, %ecx       # imm = 0xFFFFFFCC
    6fb4:      	testq	%rax, %rax
    6fb7:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    6fbd:      	movq	0x1048(%r14), %rax
    6fc4:      	movl	$0xffffffce, %ecx       # imm = 0xFFFFFFCE
    6fc9:      	testq	%rax, %rax
    6fcc:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    6fd2:      	movq	0x1040(%r14), %rax
    6fd9:      	movl	$0xffffffd0, %ecx       # imm = 0xFFFFFFD0
    6fde:      	testq	%rax, %rax
    6fe1:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    6fe7:      	movq	0x1038(%r14), %rax
    6fee:      	movl	$0xffffffd2, %ecx       # imm = 0xFFFFFFD2
    6ff3:      	testq	%rax, %rax
    6ff6:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    6ffc:      	movq	0x1030(%r14), %rax
    7003:      	movl	$0xffffffd4, %ecx       # imm = 0xFFFFFFD4
    7008:      	testq	%rax, %rax
    700b:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    7011:      	movq	0x1028(%r14), %rax
    7018:      	movl	$0xffffffd6, %ecx       # imm = 0xFFFFFFD6
    701d:      	testq	%rax, %rax
    7020:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    7026:      	movq	0x1020(%r14), %rax
    702d:      	movl	$0xffffffd8, %ecx       # imm = 0xFFFFFFD8
    7032:      	testq	%rax, %rax
    7035:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    703b:      	movq	0x1018(%r14), %rax
    7042:      	movl	$0xffffffda, %ecx       # imm = 0xFFFFFFDA
    7047:      	testq	%rax, %rax
    704a:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    7050:      	movq	0x1010(%r14), %rax
    7057:      	movl	$0xffffffdc, %ecx       # imm = 0xFFFFFFDC
    705c:      	testq	%rax, %rax
    705f:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    7065:      	movq	0x1008(%r14), %rax
    706c:      	movl	$0xffffffde, %ecx       # imm = 0xFFFFFFDE
    7071:      	testq	%rax, %rax
    7074:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    707a:      	movq	0x1000(%r14), %rax
    7081:      	movl	$0xffffffe0, %ecx       # imm = 0xFFFFFFE0
    7086:      	testq	%rax, %rax
    7089:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    708f:      	movq	0xff8(%r14), %rax
    7096:      	movl	$0xffffffe2, %ecx       # imm = 0xFFFFFFE2
    709b:      	testq	%rax, %rax
    709e:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    70a4:      	movq	0xff0(%r14), %rax
    70ab:      	movl	$0xffffffe4, %ecx       # imm = 0xFFFFFFE4
    70b0:      	testq	%rax, %rax
    70b3:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    70b9:      	movq	0xfe8(%r14), %rax
    70c0:      	movl	$0xffffffe6, %ecx       # imm = 0xFFFFFFE6
    70c5:      	testq	%rax, %rax
    70c8:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    70ce:      	movq	0xfe0(%r14), %rax
    70d5:      	movl	$0xffffffe8, %ecx       # imm = 0xFFFFFFE8
    70da:      	testq	%rax, %rax
    70dd:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    70e3:      	movq	0xfd8(%r14), %rax
    70ea:      	movl	$0xffffffea, %ecx       # imm = 0xFFFFFFEA
    70ef:      	testq	%rax, %rax
    70f2:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    70f8:      	movq	0xfd0(%r14), %rax
    70ff:      	movl	$0xffffffec, %ecx       # imm = 0xFFFFFFEC
    7104:      	testq	%rax, %rax
    7107:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    710d:      	movq	0xfc8(%r14), %rax
    7114:      	movl	$0xffffffee, %ecx       # imm = 0xFFFFFFEE
    7119:      	testq	%rax, %rax
    711c:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    7122:      	movq	0xfc0(%r14), %rax
    7129:      	movl	$0xfffffff0, %ecx       # imm = 0xFFFFFFF0
    712e:      	testq	%rax, %rax
    7131:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    7137:      	movq	0xfb8(%r14), %rax
    713e:      	movl	$0xfffffff2, %ecx       # imm = 0xFFFFFFF2
    7143:      	testq	%rax, %rax
    7146:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    714c:      	movq	0xfb0(%r14), %rax
    7153:      	movl	$0xfffffff4, %ecx       # imm = 0xFFFFFFF4
    7158:      	testq	%rax, %rax
    715b:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    7161:      	movq	0xfa8(%r14), %rax
    7168:      	movl	$0xfffffff6, %ecx       # imm = 0xFFFFFFF6
    716d:      	testq	%rax, %rax
    7170:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    7176:      	movq	0xfa0(%r14), %rax
    717d:      	movl	$0xfffffff8, %ecx       # imm = 0xFFFFFFF8
    7182:      	testq	%rax, %rax
    7185:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    718b:      	movq	0xf98(%r14), %rax
    7192:      	movl	$0xfffffffa, %ecx       # imm = 0xFFFFFFFA
    7197:      	testq	%rax, %rax
    719a:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    71a0:      	movq	0xf90(%r14), %rax
    71a7:      	movl	$0xfffffffc, %ecx       # imm = 0xFFFFFFFC
    71ac:      	testq	%rax, %rax
    71af:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    71b5:      	movq	0xf88(%r14), %rax
    71bc:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    71c1:      	testq	%rax, %rax
    71c4:      	jne	0x579a <perf_unwind_dotnet+0x579a>
    71ca:      	movq	0x90(%rsp), %rax
    71d2:      	movq	(%rax), %rax
    71d5:      	xorl	%ecx, %ecx
    71d7:      	jmp	0x579a <perf_unwind_dotnet+0x579a>
    71dc:      	movabsq	$0x207972746e65202c, %rax # imm = 0x207972746E65202C
    71e6:      	movq	%rax, 0x40(%rsp)
    71eb:      	movabsq	$0x6425206465707069, %rax # imm = 0x6425206465707069
    71f5:      	movq	%rax, 0x38(%rsp)
    71fa:      	movabsq	$0x6b73203a786c2520, %rax # imm = 0x6B73203A786C2520
    7204:      	movq	%rax, 0x30(%rsp)
    7209:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    7213:      	movq	%rax, 0x28(%rsp)
    7218:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    7222:      	movq	%rax, 0x20(%rsp)
    7227:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    7231:      	movq	%rax, 0x18(%rsp)
    7236:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    7240:      	movq	%rax, 0x10(%rsp)
    7245:      	movl	$0xa7825, 0x48(%rsp)    # imm = 0xA7825
    724d:      	leaq	0x10(%rsp), %rdi
    7252:      	movl	$0x3c, %eax
    7257:      	movl	$0x6, %r9d
    725d:      	movl	$0x3c, %esi
    7262:      	movq	%r13, %rdx
    7265:      	movl	%r15d, %r8d
    7268:      	xorl	%eax, %eax
    726a:      	callq	*%r9
    726d:      	testl	%r15d, %r15d
    7270:      	jne	0x5bfc <perf_unwind_dotnet+0x5bfc>
    7276:      	jmp	0x6d11 <perf_unwind_dotnet+0x6d11>
    727b:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    7285:      	movq	%rax, 0x26(%rsp)
    728a:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    7294:      	movq	%rax, 0x20(%rsp)
    7299:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    72a3:      	movq	%rax, 0x18(%rsp)
    72a8:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    72b2:      	movq	%rax, 0x10(%rsp)
    72b7:      	leaq	0x10(%rsp), %rdi
    72bc:      	movl	$0x1e, %eax
    72c1:      	movl	$0x6, %ecx
    72c6:      	movzwl	0x20(%r15), %edx
    72cb:      	movl	$0x1e, %esi
    72d0:      	xorl	%eax, %eax
    72d2:      	callq	*%rcx
    72d4:      	movl	0x1380(%r14), %eax
    72db:      	movl	0x20(%r15), %ecx
    72df:      	btl	%ecx, %eax
    72e2:      	jb	0x62c5 <perf_unwind_dotnet+0x62c5>
    72e8:      	movl	$0x0, 0x68(%rsp)
    72f0:      	movq	(%rip), %rdi            # 0x72f7 <perf_unwind_dotnet+0x72f7>
    72f7:      	leaq	0x68(%rsp), %rsi
    72fc:      	movl	$0x1, %eax
    7301:      	callq	*%rax
    7303:      	testq	%rax, %rax
    7306:      	je	0x730d <perf_unwind_dotnet+0x730d>
    7308:      	incq	(%rax)
    730b:      	jmp	0x731d <perf_unwind_dotnet+0x731d>
    730d:      	movq	(%rip), %rax            # 0x7314 <perf_unwind_dotnet+0x7314>
    7314:      	cmpl	$0x0, (%rax)
    7317:      	jne	0x7b5b <perf_unwind_dotnet+0x7b5b>
    731d:      	movzwl	0x20(%r15), %r12d
    7322:      	cmpl	$0x8, %r12d
    7326:      	jne	0x8da3 <perf_unwind_dotnet+0x8da3>
    732c:      	movq	0xed0(%r14), %r12
    7333:      	movq	0xed8(%r14), %rbx
    733a:      	movq	0xee0(%r14), %r13
    7341:      	movzbl	0xf30(%r14), %eax
    7349:      	movb	%al, 0x88(%rsp)
    7350:      	movq	(%rip), %rax            # 0x7357 <perf_unwind_dotnet+0x7357>
    7357:      	cmpl	$0x0, (%rax)
    735a:      	jne	0x774b <perf_unwind_dotnet+0x774b>
    7360:      	cmpq	%rbx, %r13
    7363:      	jb	0x77bb <perf_unwind_dotnet+0x77bb>
    7369:      	leaq	0x2000(%rbx), %rax
    7370:      	cmpq	%rax, %r13
    7373:      	jae	0x77bb <perf_unwind_dotnet+0x77bb>
    7379:      	movq	0xf10(%r14), %rbp
    7380:      	movq	0xf20(%r14), %r15
    7387:      	movq	%r12, 0x68(%rsp)
    738c:      	movb	$0x1, 0xf30(%r14)
    7394:      	movq	%rbp, %rax
    7397:      	andq	$-0x80, %rax
    739b:      	cmpq	$0x80, %rax
    73a1:      	jne	0x73e5 <perf_unwind_dotnet+0x73e5>
    73a3:      	movq	0xed8(%r14), %rax
    73aa:      	movl	$0x8, %ecx
    73af:      	movl	$0x70, %r8d
    73b5:      	movq	0x98(%rsp), %rdi
    73bd:      	movq	0xed8(%r14), %rdx
    73c4:      	movl	$0x8, %esi
    73c9:      	callq	*%r8
    73cc:      	testq	%rax, %rax
    73cf:      	jne	0x19c <perf_unwind_dotnet+0x19c>
    73d5:      	addq	$0x8, 0xed8(%r14)
    73dd:      	andl	$0x7f, %ebp
    73e0:      	jmp	0x85e1 <perf_unwind_dotnet+0x85e1>
    73e5:      	leaq	0x70(%rsp), %rdi
    73ea:      	movl	$0x10, %eax
    73ef:      	movl	$0x70, %ecx
    73f4:      	movl	$0x10, %esi
    73f9:      	movq	%r13, %rdx
    73fc:      	callq	*%rcx
    73fe:      	testq	%rax, %rax
    7401:      	jne	0x26c <perf_unwind_dotnet+0x26c>
    7407:      	addq	$0x10, %r13
    740b:      	movq	%r13, 0xed8(%r14)
    7412:      	movq	0x70(%rsp), %rax
    7417:      	movq	%rax, 0xee0(%r14)
    741e:      	movq	0x78(%rsp), %rax
    7423:      	movq	%rax, 0xed0(%r14)
    742a:      	movq	(%rip), %rax            # 0x7431 <perf_unwind_dotnet+0x7431>
    7431:      	cmpl	$0x0, (%rax)
    7434:      	jne	0x7bd6 <perf_unwind_dotnet+0x7bd6>
    743a:      	cmpq	$0x100, %rbp            # imm = 0x100
    7441:      	jb	0x85e1 <perf_unwind_dotnet+0x85e1>
    7447:      	movq	0xf10(%r14), %rbp
    744e:      	movq	0xf20(%r14), %rbx
    7455:      	movq	%r12, %r13
    7458:      	subq	%rbx, %r13
    745b:      	movq	(%rip), %rax            # 0x7462 <perf_unwind_dotnet+0x7462>
    7462:      	cmpl	$0x0, (%rax)
    7465:      	jne	0x7c5b <perf_unwind_dotnet+0x7c5b>
    746b:      	movq	%r13, %r15
    746e:      	andq	$-0x4, %r15
    7472:      	movl	$0x100, %ecx            # imm = 0x100
    7477:      	movq	%r15, %rax
    747a:      	xorl	%edx, %edx
    747c:      	divq	%rcx
    747f:      	movq	%rax, %rcx
    7482:      	movl	$0x7f, %eax
    7487:      	subq	%rcx, %rax
    748a:      	jns	0x74a3 <perf_unwind_dotnet+0x74a3>
    748c:      	movl	$0x100, %ecx            # imm = 0x100
    7491:      	movq	%r15, %rax
    7494:      	xorl	%edx, %edx
    7496:      	divq	%rcx
    7499:      	leaq	-0x3fc(%rbp,%rax,4), %rbp
    74a1:      	xorl	%eax, %eax
    74a3:      	movl	$0x80, %ecx
    74a8:      	cqto
    74aa:      	idivq	%rcx
    74ad:      	movq	0x90(%rsp), %rax
    74b5:      	leaq	(%rax,%rdx,4), %rdi
    74b9:      	movl	$0x200, %eax            # imm = 0x200
    74be:      	movl	$0x70, %ecx
    74c3:      	movl	$0x200, %esi            # imm = 0x200
    74c8:      	movq	%rbp, %rdx
    74cb:      	callq	*%rcx
    74cd:      	testq	%rax, %rax
    74d0:      	je	0x7507 <perf_unwind_dotnet+0x7507>
    74d2:      	movq	(%rip), %rax            # 0x74d9 <perf_unwind_dotnet+0x74d9>
    74d9:      	cmpl	$0x0, (%rax)
    74dc:      	jne	0x76dc <perf_unwind_dotnet+0x76dc>
    74e2:      	movl	$0x5e, 0xc(%rsp)
    74ea:      	movq	(%rip), %rdi            # 0x74f1 <perf_unwind_dotnet+0x74f1>
    74f1:      	leaq	0xc(%rsp), %rsi
    74f6:      	movl	$0x1, %eax
    74fb:      	callq	*%rax
    74fd:      	testq	%rax, %rax
    7500:      	je	0x7572 <perf_unwind_dotnet+0x7572>
    7502:      	incq	(%rax)
    7505:      	jmp	0x7582 <perf_unwind_dotnet+0x7582>
    7507:      	movl	0x117c(%r14), %ebp
    750e:      	movq	(%rip), %rax            # 0x7515 <perf_unwind_dotnet+0x7515>
    7515:      	cmpl	$0x0, (%rax)
    7518:      	jne	0x7c9f <perf_unwind_dotnet+0x7c9f>
    751e:      	movl	$0x20, %ecx
    7523:      	movq	%r15, %rax
    7526:      	xorl	%edx, %edx
    7528:      	divq	%rcx
    752b:      	movl	$0x8, %ecx
    7530:      	xorl	%edx, %edx
    7532:      	divq	%rcx
    7535:      	shll	$0x2, %edx
    7538:      	movb	$0x1c, %al
    753a:      	subb	%dl, %al
    753c:      	shrxl	%eax, %ebp, %r15d
    7541:      	testl	%r15d, %r15d
    7544:      	je	0x760f <perf_unwind_dotnet+0x760f>
    754a:      	andq	$-0x20, %r13
    754e:      	movl	%r15d, %ecx
    7551:      	andl	$0xf, %ecx
    7554:      	jne	0x8594 <perf_unwind_dotnet+0x8594>
    755a:      	movl	%r15d, %ecx
    755d:      	shrl	$0x4, %ecx
    7560:      	andl	$0xf, %ecx
    7563:      	je	0x771f <perf_unwind_dotnet+0x771f>
    7569:      	addq	$-0x20, %r13
    756d:      	jmp	0x8594 <perf_unwind_dotnet+0x8594>
    7572:      	movq	(%rip), %rax            # 0x7579 <perf_unwind_dotnet+0x7579>
    7579:      	cmpl	$0x0, (%rax)
    757c:      	jne	0x7d2c <perf_unwind_dotnet+0x7d2c>
    7582:      	movl	$0x1772, %edx           # imm = 0x1772
    7587:      	xorl	%ebx, %ebx
    7589:      	movq	(%rip), %rax            # 0x7590 <perf_unwind_dotnet+0x7590>
    7590:      	cmpl	$0x0, (%rax)
    7593:      	jne	0x843f <perf_unwind_dotnet+0x843f>
    7599:      	movl	$0x1772, %eax           # imm = 0x1772
    759e:      	testb	%bl, %bl
    75a0:      	movq	0x60(%rsp), %r15
    75a5:      	movq	(%rip), %rbp            # 0x75ac <perf_unwind_dotnet+0x75ac>
    75ac:      	je	0x7812 <perf_unwind_dotnet+0x7812>
    75b2:      	movl	0x2c0(%r14), %eax
    75b9:      	cmpq	$0x7e, %rax
    75bd:      	ja	0x52f <perf_unwind_dotnet+0x52f>
    75c3:      	leal	0x1(%rax), %ecx
    75c6:      	movl	%ecx, 0x2c0(%r14)
    75cd:      	leaq	(%rax,%rax,2), %rax
    75d1:      	movq	$0x0, 0x2d0(%r14,%rax,8)
    75dd:      	movq	$0x1773, 0x2d8(%r14,%rax,8) # imm = 0x1773
    75e9:      	movb	$-0x76, 0x2e0(%r14,%rax,8)
    75f2:      	movl	$0x0, 0x2e1(%r14,%rax,8)
    75fe:      	movl	$0x0, 0x2e4(%r14,%rax,8)
    760a:      	jmp	0x8694 <perf_unwind_dotnet+0x8694>
    760f:      	andq	$-0x100, %r13
    7616:      	addq	$-0x20, %r13
    761a:      	movl	0x1178(%r14), %r15d
    7621:      	movq	(%rip), %rax            # 0x7628 <perf_unwind_dotnet+0x7628>
    7628:      	cmpl	$0x0, (%rax)
    762b:      	jne	0x7da7 <perf_unwind_dotnet+0x7da7>
    7631:      	xorl	%ecx, %ecx
    7633:      	testl	%r15d, %r15d
    7636:      	je	0x7e3b <perf_unwind_dotnet+0x7e3b>
    763c:      	movl	%ecx, %eax
    763e:      	shll	$0x8, %eax
    7641:      	subq	%rax, %r13
    7644:      	jae	0x8365 <perf_unwind_dotnet+0x8365>
    764a:      	movq	(%rip), %rax            # 0x7651 <perf_unwind_dotnet+0x7651>
    7651:      	cmpl	$0x0, (%rax)
    7654:      	je	0x74e2 <perf_unwind_dotnet+0x74e2>
    765a:      	movabsq	$0xa657361625f63, %rax  # imm = 0xA657361625F63
    7664:      	movq	%rax, 0x36(%rsp)
    7669:      	movabsq	$0x5f637020776f6c65, %rax # imm = 0x5F637020776F6C65
    7673:      	movq	%rax, 0x30(%rsp)
    7678:      	movabsq	$0x6220746e65772068, %rax # imm = 0x6220746E65772068
    7682:      	movq	%rax, 0x28(%rsp)
    7687:      	movabsq	$0x6372616573207061, %rax # imm = 0x6372616573207061
    7691:      	movq	%rax, 0x20(%rsp)
    7696:      	movabsq	$0x6d20656c6262696e, %rax # imm = 0x6D20656C6262696E
    76a0:      	movq	%rax, 0x18(%rsp)
    76a5:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    76af:      	movq	%rax, 0x10(%rsp)
    76b4:      	leaq	0x10(%rsp), %rdi
    76b9:      	movl	$0x2e, %eax
    76be:      	movl	$0x6, %ecx
    76c3:      	movl	$0x2e, %esi
    76c8:      	xorl	%eax, %eax
    76ca:      	callq	*%rcx
    76cc:      	movq	(%rip), %rax            # 0x76d3 <perf_unwind_dotnet+0x76d3>
    76d3:      	cmpl	$0x0, (%rax)
    76d6:      	je	0x74e2 <perf_unwind_dotnet+0x74e2>
    76dc:      	movabsq	$0x6e756f6620746f6e, %rax # imm = 0x6E756F6620746F6E
    76e6:      	movq	%rax, 0x18(%rsp)
    76eb:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    76f5:      	movq	%rax, 0x10(%rsp)
    76fa:      	movl	$0xa646e, 0x1f(%rsp)    # imm = 0xA646E
    7702:      	leaq	0x10(%rsp), %rdi
    7707:      	movl	$0x13, %eax
    770c:      	movl	$0x6, %ecx
    7711:      	movl	$0x13, %esi
    7716:      	xorl	%eax, %eax
    7718:      	callq	*%rcx
    771a:      	jmp	0x74e2 <perf_unwind_dotnet+0x74e2>
    771f:      	movl	%r15d, %ecx
    7722:      	shrl	$0x8, %ecx
    7725:      	andl	$0xf, %ecx
    7728:      	je	0x7733 <perf_unwind_dotnet+0x7733>
    772a:      	addq	$-0x40, %r13
    772e:      	jmp	0x8594 <perf_unwind_dotnet+0x8594>
    7733:      	movl	%r15d, %ecx
    7736:      	shrl	$0xc, %ecx
    7739:      	andl	$0xf, %ecx
    773c:      	je	0x84a7 <perf_unwind_dotnet+0x84a7>
    7742:      	addq	$-0x60, %r13
    7746:      	jmp	0x8594 <perf_unwind_dotnet+0x8594>
    774b:      	movabsq	$0x6c25203a7066202c, %rax # imm = 0x6C25203A7066202C
    7755:      	movq	%rax, 0x28(%rsp)
    775a:      	movabsq	$0x786c25203a707320, %rax # imm = 0x786C25203A707320
    7764:      	movq	%rax, 0x20(%rsp)
    7769:      	movabsq	$0x2c786c25203a6370, %rax # imm = 0x2C786C25203A6370
    7773:      	movq	%rax, 0x18(%rsp)
    7778:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    7782:      	movq	%rax, 0x10(%rsp)
    7787:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    778f:      	leaq	0x10(%rsp), %rdi
    7794:      	movl	$0x23, %eax
    7799:      	movl	$0x6, %r9d
    779f:      	movl	$0x23, %esi
    77a4:      	movq	%r12, %rdx
    77a7:      	movq	%rbx, %rcx
    77aa:      	movq	%r13, %r8
    77ad:      	xorl	%eax, %eax
    77af:      	callq	*%r9
    77b2:      	cmpq	%rbx, %r13
    77b5:      	jae	0x7369 <perf_unwind_dotnet+0x7369>
    77bb:      	movq	0x60(%rsp), %r15
    77c0:      	movq	(%rip), %rax            # 0x77c7 <perf_unwind_dotnet+0x77c7>
    77c7:      	cmpl	$0x0, (%rax)
    77ca:      	jne	0x796b <perf_unwind_dotnet+0x796b>
    77d0:      	movl	$0x5d, 0x68(%rsp)
    77d8:      	movq	(%rip), %rdi            # 0x77df <perf_unwind_dotnet+0x77df>
    77df:      	leaq	0x68(%rsp), %rsi
    77e4:      	movl	$0x1, %eax
    77e9:      	callq	*%rax
    77eb:      	testq	%rax, %rax
    77ee:      	je	0x77fc <perf_unwind_dotnet+0x77fc>
    77f0:      	incq	(%rax)
    77f3:      	movq	(%rip), %rbp            # 0x77fa <perf_unwind_dotnet+0x77fa>
    77fa:      	jmp	0x780d <perf_unwind_dotnet+0x780d>
    77fc:      	movq	(%rip), %rbp            # 0x7803 <perf_unwind_dotnet+0x7803>
    7803:      	cmpl	$0x0, (%rbp)
    7807:      	jne	0x79ea <perf_unwind_dotnet+0x79ea>
    780d:      	movl	$0x1771, %eax           # imm = 0x1771
    7812:      	xorl	%r12d, %r12d
    7815:      	movl	%eax, 0xf2c(%r14)
    781c:      	movl	$0x0, 0x10(%rsp)
    7824:      	movq	(%rip), %rdi            # 0x782b <perf_unwind_dotnet+0x782b>
    782b:      	leaq	0x10(%rsp), %rsi
    7830:      	movl	$0x1, %eax
    7835:      	callq	*%rax
    7837:      	testq	%rax, %rax
    783a:      	je	0x787d <perf_unwind_dotnet+0x787d>
    783c:      	movzbl	0x1384(%rax), %ecx
    7843:      	movl	%r12d, %edx
    7846:      	cmpb	$0x1d, %cl
    7849:      	jb	0x78a3 <perf_unwind_dotnet+0x78a3>
    784b:      	movq	%rax, %rbx
    784e:      	movl	$0x5, 0xf2c(%rax)
    7858:      	movl	$0x44, 0x70(%rsp)
    7860:      	movq	(%rip), %rdi            # 0x7867 <perf_unwind_dotnet+0x7867>
    7867:      	leaq	0x70(%rsp), %rsi
    786c:      	movl	$0x1, %eax
    7871:      	callq	*%rax
    7873:      	testq	%rax, %rax
    7876:      	je	0x788d <perf_unwind_dotnet+0x788d>
    7878:      	incq	(%rax)
    787b:      	jmp	0x7897 <perf_unwind_dotnet+0x7897>
    787d:      	movq	(%rip), %rcx            # 0x7884 <perf_unwind_dotnet+0x7884>
    7884:      	xorl	%edx, %edx
    7886:      	movl	$0xc, %eax
    788b:      	jmp	0x78b9 <perf_unwind_dotnet+0x78b9>
    788d:      	cmpl	$0x0, (%rbp)
    7891:      	jne	0x7a65 <perf_unwind_dotnet+0x7a65>
    7897:      	movq	%rbx, %rax
    789a:      	movzbl	0x1384(%rbx), %ecx
    78a1:      	xorl	%edx, %edx
    78a3:      	incb	%cl
    78a5:      	movb	%cl, 0x1384(%rax)
    78ab:      	movl	%edx, %ecx
    78ad:      	movq	(%rip), %rsi            # 0x78b4 <perf_unwind_dotnet+0x78b4>
    78b4:      	movl	$0xc, %eax
    78b9:      	movq	(%rip), %rsi            # 0x78c0 <perf_unwind_dotnet+0x78c0>
    78c0:      	movq	%r15, %rdi
    78c3:      	callq	*%rax
    78c5:      	cmpl	$0x0, (%rbp)
    78c9:      	jne	0x78e2 <perf_unwind_dotnet+0x78e2>
    78cb:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
    78d0:      	addq	$0xa8, %rsp
    78d7:      	popq	%rbx
    78d8:      	popq	%r12
    78da:      	popq	%r13
    78dc:      	popq	%r14
    78de:      	popq	%r15
    78e0:      	popq	%rbp
    78e1:      	retq
    78e2:      	movabsq	$0xa64656c696166, %rax  # imm = 0xA64656C696166
    78ec:      	movq	%rax, 0x3f(%rsp)
    78f1:      	movabsq	$0x6620296425282072, %rax # imm = 0x6620296425282072
    78fb:      	movq	%rax, 0x38(%rsp)
    7900:      	movabsq	$0x65646e69776e7520, %rax # imm = 0x65646E69776E7520
    790a:      	movq	%rax, 0x30(%rsp)
    790f:      	movabsq	$0x656d617266207478, %rax # imm = 0x656D617266207478
    7919:      	movq	%rax, 0x28(%rsp)
    791e:      	movabsq	$0x656e20726f66206c, %rax # imm = 0x656E20726F66206C
    7928:      	movq	%rax, 0x20(%rsp)
    792d:      	movabsq	$0x6c6163206c696174, %rax # imm = 0x6C6163206C696174
    7937:      	movq	%rax, 0x18(%rsp)
    793c:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    7946:      	movq	%rax, 0x10(%rsp)
    794b:      	leaq	0x10(%rsp), %rdi
    7950:      	movl	$0x37, %eax
    7955:      	movl	$0x6, %ecx
    795a:      	movl	$0x37, %esi
    795f:      	movl	%r12d, %edx
    7962:      	xorl	%eax, %eax
    7964:      	callq	*%rcx
    7966:      	jmp	0x78cb <perf_unwind_dotnet+0x78cb>
    796b:      	movabsq	$0xa786c25202f20, %rax  # imm = 0xA786C25202F20
    7975:      	movq	%rax, 0x35(%rsp)
    797a:      	movabsq	$0x202f20786c252066, %rax # imm = 0x202F20786C252066
    7984:      	movq	%rax, 0x30(%rsp)
    7989:      	movabsq	$0x666f20726166206f, %rax # imm = 0x666F20726166206F
    7993:      	movq	%rax, 0x28(%rsp)
    7998:      	movabsq	$0x6f74207265746e69, %rax # imm = 0x6F74207265746E69
    79a2:      	movq	%rax, 0x20(%rsp)
    79a7:      	movabsq	$0x6f7020656d617266, %rax # imm = 0x6F7020656D617266
    79b1:      	movq	%rax, 0x18(%rsp)
    79b6:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    79c0:      	movq	%rax, 0x10(%rsp)
    79c5:      	leaq	0x10(%rsp), %rdi
    79ca:      	movl	$0x2d, %eax
    79cf:      	movl	$0x6, %r8d
    79d5:      	movl	$0x2d, %esi
    79da:      	movq	%r13, %rdx
    79dd:      	movq	%rbx, %rcx
    79e0:      	xorl	%eax, %eax
    79e2:      	callq	*%r8
    79e5:      	jmp	0x77d0 <perf_unwind_dotnet+0x77d0>
    79ea:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    79f4:      	movq	%rax, 0x36(%rsp)
    79f9:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7a03:      	movq	%rax, 0x30(%rsp)
    7a08:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7a12:      	movq	%rax, 0x28(%rsp)
    7a17:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7a21:      	movq	%rax, 0x20(%rsp)
    7a26:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    7a30:      	movq	%rax, 0x18(%rsp)
    7a35:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7a3f:      	movq	%rax, 0x10(%rsp)
    7a44:      	leaq	0x10(%rsp), %rdi
    7a49:      	movl	$0x2e, %eax
    7a4e:      	movl	$0x6, %ecx
    7a53:      	movl	0x68(%rsp), %edx
    7a57:      	movl	$0x2e, %esi
    7a5c:      	xorl	%eax, %eax
    7a5e:      	callq	*%rcx
    7a60:      	jmp	0x780d <perf_unwind_dotnet+0x780d>
    7a65:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    7a6f:      	movq	%rax, 0x36(%rsp)
    7a74:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7a7e:      	movq	%rax, 0x30(%rsp)
    7a83:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7a8d:      	movq	%rax, 0x28(%rsp)
    7a92:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7a9c:      	movq	%rax, 0x20(%rsp)
    7aa1:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    7aab:      	movq	%rax, 0x18(%rsp)
    7ab0:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7aba:      	movq	%rax, 0x10(%rsp)
    7abf:      	leaq	0x10(%rsp), %rdi
    7ac4:      	movl	$0x2e, %eax
    7ac9:      	movl	$0x6, %ecx
    7ace:      	movl	0x70(%rsp), %edx
    7ad2:      	movl	$0x2e, %esi
    7ad7:      	xorl	%eax, %eax
    7ad9:      	callq	*%rcx
    7adb:      	jmp	0x7897 <perf_unwind_dotnet+0x7897>
    7ae0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    7aea:      	movq	%rax, 0x36(%rsp)
    7aef:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7af9:      	movq	%rax, 0x30(%rsp)
    7afe:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7b08:      	movq	%rax, 0x28(%rsp)
    7b0d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7b17:      	movq	%rax, 0x20(%rsp)
    7b1c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    7b26:      	movq	%rax, 0x18(%rsp)
    7b2b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7b35:      	movq	%rax, 0x10(%rsp)
    7b3a:      	leaq	0x10(%rsp), %rdi
    7b3f:      	movl	$0x2e, %eax
    7b44:      	movl	$0x6, %ecx
    7b49:      	movl	0xc(%rsp), %edx
    7b4d:      	movl	$0x2e, %esi
    7b52:      	xorl	%eax, %eax
    7b54:      	callq	*%rcx
    7b56:      	jmp	0x6d46 <perf_unwind_dotnet+0x6d46>
    7b5b:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    7b65:      	movq	%rax, 0x36(%rsp)
    7b6a:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7b74:      	movq	%rax, 0x30(%rsp)
    7b79:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7b83:      	movq	%rax, 0x28(%rsp)
    7b88:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7b92:      	movq	%rax, 0x20(%rsp)
    7b97:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    7ba1:      	movq	%rax, 0x18(%rsp)
    7ba6:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7bb0:      	movq	%rax, 0x10(%rsp)
    7bb5:      	leaq	0x10(%rsp), %rdi
    7bba:      	movl	$0x2e, %eax
    7bbf:      	movl	$0x6, %ecx
    7bc4:      	movl	0x68(%rsp), %edx
    7bc8:      	movl	$0x2e, %esi
    7bcd:      	xorl	%eax, %eax
    7bcf:      	callq	*%rcx
    7bd1:      	jmp	0x731d <perf_unwind_dotnet+0x731d>
    7bd6:      	movabsq	$0x6c25203a7066202c, %rax # imm = 0x6C25203A7066202C
    7be0:      	movq	%rax, 0x28(%rsp)
    7be5:      	movabsq	$0x786c25203a707320, %rax # imm = 0x786C25203A707320
    7bef:      	movq	%rax, 0x20(%rsp)
    7bf4:      	movabsq	$0x2c786c25203a6370, %rax # imm = 0x2C786C25203A6370
    7bfe:      	movq	%rax, 0x18(%rsp)
    7c03:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    7c0d:      	movq	%rax, 0x10(%rsp)
    7c12:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    7c1a:      	leaq	0x10(%rsp), %rdi
    7c1f:      	movl	$0x23, %eax
    7c24:      	movl	$0x6, %r9d
    7c2a:      	movq	0xed0(%r14), %rdx
    7c31:      	movq	0xed8(%r14), %rcx
    7c38:      	movq	0xee0(%r14), %r8
    7c3f:      	movl	$0x23, %esi
    7c44:      	xorl	%eax, %eax
    7c46:      	callq	*%r9
    7c49:      	cmpq	$0x100, %rbp            # imm = 0x100
    7c50:      	jae	0x7447 <perf_unwind_dotnet+0x7447>
    7c56:      	jmp	0x85e1 <perf_unwind_dotnet+0x85e1>
    7c5b:      	leaq	(%rip), %rsi            # 0x7c62 <perf_unwind_dotnet+0x7c62>
    7c62:      	leaq	0x10(%rsp), %rax
    7c67:      	movl	$0x8, %ecx
    7c6c:      	movq	%rax, %rdi
    7c6f:      	rep		movsq	(%rsi), %es:(%rdi)
    7c72:      	movw	$0xa, 0x50(%rsp)
    7c79:      	movl	$0x42, %ecx
    7c7e:      	movl	$0x6, %r9d
    7c84:      	movq	%rax, %rdi
    7c87:      	movl	$0x42, %esi
    7c8c:      	movq	%r13, %rdx
    7c8f:      	movq	%rbx, %rcx
    7c92:      	movq	%rbp, %r8
    7c95:      	xorl	%eax, %eax
    7c97:      	callq	*%r9
    7c9a:      	jmp	0x746b <perf_unwind_dotnet+0x746b>
    7c9f:      	movabsq	$0xa782520797274, %rax  # imm = 0xA782520797274
    7ca9:      	movq	%rax, 0x3e(%rsp)
    7cae:      	movabsq	$0x72746e6520747372, %rax # imm = 0x72746E6520747372
    7cb8:      	movq	%rax, 0x38(%rsp)
    7cbd:      	movabsq	$0x6966203a786c2520, %rax # imm = 0x6966203A786C2520
    7cc7:      	movq	%rax, 0x30(%rsp)
    7ccc:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    7cd6:      	movq	%rax, 0x28(%rsp)
    7cdb:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    7ce5:      	movq	%rax, 0x20(%rsp)
    7cea:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    7cf4:      	movq	%rax, 0x18(%rsp)
    7cf9:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    7d03:      	movq	%rax, 0x10(%rsp)
    7d08:      	leaq	0x10(%rsp), %rdi
    7d0d:      	movl	$0x36, %eax
    7d12:      	movl	$0x6, %r8d
    7d18:      	movl	$0x36, %esi
    7d1d:      	movq	%r15, %rdx
    7d20:      	movl	%ebp, %ecx
    7d22:      	xorl	%eax, %eax
    7d24:      	callq	*%r8
    7d27:      	jmp	0x751e <perf_unwind_dotnet+0x751e>
    7d2c:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    7d36:      	movq	%rax, 0x36(%rsp)
    7d3b:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7d45:      	movq	%rax, 0x30(%rsp)
    7d4a:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7d54:      	movq	%rax, 0x28(%rsp)
    7d59:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7d63:      	movq	%rax, 0x20(%rsp)
    7d68:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    7d72:      	movq	%rax, 0x18(%rsp)
    7d77:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7d81:      	movq	%rax, 0x10(%rsp)
    7d86:      	leaq	0x10(%rsp), %rdi
    7d8b:      	movl	$0x2e, %eax
    7d90:      	movl	$0x6, %ecx
    7d95:      	movl	0xc(%rsp), %edx
    7d99:      	movl	$0x2e, %esi
    7d9e:      	xorl	%eax, %eax
    7da0:      	callq	*%rcx
    7da2:      	jmp	0x7582 <perf_unwind_dotnet+0x7582>
    7da7:      	movabsq	$0xa782520797274, %rax  # imm = 0xA782520797274
    7db1:      	movq	%rax, 0x3f(%rsp)
    7db6:      	movabsq	$0x746e6520646e6f63, %rax # imm = 0x746E6520646E6F63
    7dc0:      	movq	%rax, 0x38(%rsp)
    7dc5:      	movabsq	$0x6573203a786c2520, %rax # imm = 0x6573203A786C2520
    7dcf:      	movq	%rax, 0x30(%rsp)
    7dd4:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    7dde:      	movq	%rax, 0x28(%rsp)
    7de3:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    7ded:      	movq	%rax, 0x20(%rsp)
    7df2:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    7dfc:      	movq	%rax, 0x18(%rsp)
    7e01:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    7e0b:      	movq	%rax, 0x10(%rsp)
    7e10:      	leaq	0x10(%rsp), %rdi
    7e15:      	movl	$0x37, %eax
    7e1a:      	movl	$0x6, %r8d
    7e20:      	movl	$0x37, %esi
    7e25:      	movq	%r13, %rdx
    7e28:      	movl	%r15d, %ecx
    7e2b:      	xorl	%eax, %eax
    7e2d:      	callq	*%r8
    7e30:      	xorl	%ecx, %ecx
    7e32:      	testl	%r15d, %r15d
    7e35:      	jne	0x763c <perf_unwind_dotnet+0x763c>
    7e3b:      	movq	0x1170(%r14), %rax
    7e42:      	movl	$0xffffff84, %ecx       # imm = 0xFFFFFF84
    7e47:      	testq	%rax, %rax
    7e4a:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    7e50:      	movq	0x1168(%r14), %rax
    7e57:      	movl	$0xffffff86, %ecx       # imm = 0xFFFFFF86
    7e5c:      	testq	%rax, %rax
    7e5f:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    7e65:      	movq	0x1160(%r14), %rax
    7e6c:      	movl	$0xffffff88, %ecx       # imm = 0xFFFFFF88
    7e71:      	testq	%rax, %rax
    7e74:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    7e7a:      	movq	0x1158(%r14), %rax
    7e81:      	movl	$0xffffff8a, %ecx       # imm = 0xFFFFFF8A
    7e86:      	testq	%rax, %rax
    7e89:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    7e8f:      	movq	0x1150(%r14), %rax
    7e96:      	movl	$0xffffff8c, %ecx       # imm = 0xFFFFFF8C
    7e9b:      	testq	%rax, %rax
    7e9e:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    7ea4:      	movq	0x1148(%r14), %rax
    7eab:      	movl	$0xffffff8e, %ecx       # imm = 0xFFFFFF8E
    7eb0:      	testq	%rax, %rax
    7eb3:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    7eb9:      	movq	0x1140(%r14), %rax
    7ec0:      	movl	$0xffffff90, %ecx       # imm = 0xFFFFFF90
    7ec5:      	testq	%rax, %rax
    7ec8:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    7ece:      	movq	0x1138(%r14), %rax
    7ed5:      	movl	$0xffffff92, %ecx       # imm = 0xFFFFFF92
    7eda:      	testq	%rax, %rax
    7edd:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    7ee3:      	movq	0x1130(%r14), %rax
    7eea:      	movl	$0xffffff94, %ecx       # imm = 0xFFFFFF94
    7eef:      	testq	%rax, %rax
    7ef2:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    7ef8:      	movq	0x1128(%r14), %rax
    7eff:      	movl	$0xffffff96, %ecx       # imm = 0xFFFFFF96
    7f04:      	testq	%rax, %rax
    7f07:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    7f0d:      	movq	0x1120(%r14), %rax
    7f14:      	movl	$0xffffff98, %ecx       # imm = 0xFFFFFF98
    7f19:      	testq	%rax, %rax
    7f1c:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    7f22:      	movq	0x1118(%r14), %rax
    7f29:      	movl	$0xffffff9a, %ecx       # imm = 0xFFFFFF9A
    7f2e:      	testq	%rax, %rax
    7f31:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    7f37:      	movq	0x1110(%r14), %rax
    7f3e:      	movl	$0xffffff9c, %ecx       # imm = 0xFFFFFF9C
    7f43:      	testq	%rax, %rax
    7f46:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    7f4c:      	movq	0x1108(%r14), %rax
    7f53:      	movl	$0xffffff9e, %ecx       # imm = 0xFFFFFF9E
    7f58:      	testq	%rax, %rax
    7f5b:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    7f61:      	movq	0x1100(%r14), %rax
    7f68:      	movl	$0xffffffa0, %ecx       # imm = 0xFFFFFFA0
    7f6d:      	testq	%rax, %rax
    7f70:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    7f76:      	movq	0x10f8(%r14), %rax
    7f7d:      	movl	$0xffffffa2, %ecx       # imm = 0xFFFFFFA2
    7f82:      	testq	%rax, %rax
    7f85:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    7f8b:      	movq	0x10f0(%r14), %rax
    7f92:      	movl	$0xffffffa4, %ecx       # imm = 0xFFFFFFA4
    7f97:      	testq	%rax, %rax
    7f9a:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    7fa0:      	movq	0x10e8(%r14), %rax
    7fa7:      	movl	$0xffffffa6, %ecx       # imm = 0xFFFFFFA6
    7fac:      	testq	%rax, %rax
    7faf:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    7fb5:      	movq	0x10e0(%r14), %rax
    7fbc:      	movl	$0xffffffa8, %ecx       # imm = 0xFFFFFFA8
    7fc1:      	testq	%rax, %rax
    7fc4:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    7fca:      	movq	0x10d8(%r14), %rax
    7fd1:      	movl	$0xffffffaa, %ecx       # imm = 0xFFFFFFAA
    7fd6:      	testq	%rax, %rax
    7fd9:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    7fdf:      	movq	0x10d0(%r14), %rax
    7fe6:      	movl	$0xffffffac, %ecx       # imm = 0xFFFFFFAC
    7feb:      	testq	%rax, %rax
    7fee:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    7ff4:      	movq	0x10c8(%r14), %rax
    7ffb:      	movl	$0xffffffae, %ecx       # imm = 0xFFFFFFAE
    8000:      	testq	%rax, %rax
    8003:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    8009:      	movq	0x10c0(%r14), %rax
    8010:      	movl	$0xffffffb0, %ecx       # imm = 0xFFFFFFB0
    8015:      	testq	%rax, %rax
    8018:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    801e:      	movq	0x10b8(%r14), %rax
    8025:      	movl	$0xffffffb2, %ecx       # imm = 0xFFFFFFB2
    802a:      	testq	%rax, %rax
    802d:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    8033:      	movq	0x10b0(%r14), %rax
    803a:      	movl	$0xffffffb4, %ecx       # imm = 0xFFFFFFB4
    803f:      	testq	%rax, %rax
    8042:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    8048:      	movq	0x10a8(%r14), %rax
    804f:      	movl	$0xffffffb6, %ecx       # imm = 0xFFFFFFB6
    8054:      	testq	%rax, %rax
    8057:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    805d:      	movq	0x10a0(%r14), %rax
    8064:      	movl	$0xffffffb8, %ecx       # imm = 0xFFFFFFB8
    8069:      	testq	%rax, %rax
    806c:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    8072:      	movq	0x1098(%r14), %rax
    8079:      	movl	$0xffffffba, %ecx       # imm = 0xFFFFFFBA
    807e:      	testq	%rax, %rax
    8081:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    8087:      	movq	0x1090(%r14), %rax
    808e:      	movl	$0xffffffbc, %ecx       # imm = 0xFFFFFFBC
    8093:      	testq	%rax, %rax
    8096:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    809c:      	movq	0x1088(%r14), %rax
    80a3:      	movl	$0xffffffbe, %ecx       # imm = 0xFFFFFFBE
    80a8:      	testq	%rax, %rax
    80ab:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    80b1:      	movq	0x1080(%r14), %rax
    80b8:      	movl	$0xffffffc0, %ecx       # imm = 0xFFFFFFC0
    80bd:      	testq	%rax, %rax
    80c0:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    80c6:      	movq	0x1078(%r14), %rax
    80cd:      	movl	$0xffffffc2, %ecx       # imm = 0xFFFFFFC2
    80d2:      	testq	%rax, %rax
    80d5:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    80db:      	movq	0x1070(%r14), %rax
    80e2:      	movl	$0xffffffc4, %ecx       # imm = 0xFFFFFFC4
    80e7:      	testq	%rax, %rax
    80ea:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    80f0:      	movq	0x1068(%r14), %rax
    80f7:      	movl	$0xffffffc6, %ecx       # imm = 0xFFFFFFC6
    80fc:      	testq	%rax, %rax
    80ff:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    8105:      	movq	0x1060(%r14), %rax
    810c:      	movl	$0xffffffc8, %ecx       # imm = 0xFFFFFFC8
    8111:      	testq	%rax, %rax
    8114:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    811a:      	movq	0x1058(%r14), %rax
    8121:      	movl	$0xffffffca, %ecx       # imm = 0xFFFFFFCA
    8126:      	testq	%rax, %rax
    8129:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    812f:      	movq	0x1050(%r14), %rax
    8136:      	movl	$0xffffffcc, %ecx       # imm = 0xFFFFFFCC
    813b:      	testq	%rax, %rax
    813e:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    8144:      	movq	0x1048(%r14), %rax
    814b:      	movl	$0xffffffce, %ecx       # imm = 0xFFFFFFCE
    8150:      	testq	%rax, %rax
    8153:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    8159:      	movq	0x1040(%r14), %rax
    8160:      	movl	$0xffffffd0, %ecx       # imm = 0xFFFFFFD0
    8165:      	testq	%rax, %rax
    8168:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    816e:      	movq	0x1038(%r14), %rax
    8175:      	movl	$0xffffffd2, %ecx       # imm = 0xFFFFFFD2
    817a:      	testq	%rax, %rax
    817d:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    8183:      	movq	0x1030(%r14), %rax
    818a:      	movl	$0xffffffd4, %ecx       # imm = 0xFFFFFFD4
    818f:      	testq	%rax, %rax
    8192:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    8198:      	movq	0x1028(%r14), %rax
    819f:      	movl	$0xffffffd6, %ecx       # imm = 0xFFFFFFD6
    81a4:      	testq	%rax, %rax
    81a7:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    81ad:      	movq	0x1020(%r14), %rax
    81b4:      	movl	$0xffffffd8, %ecx       # imm = 0xFFFFFFD8
    81b9:      	testq	%rax, %rax
    81bc:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    81c2:      	movq	0x1018(%r14), %rax
    81c9:      	movl	$0xffffffda, %ecx       # imm = 0xFFFFFFDA
    81ce:      	testq	%rax, %rax
    81d1:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    81d7:      	movq	0x1010(%r14), %rax
    81de:      	movl	$0xffffffdc, %ecx       # imm = 0xFFFFFFDC
    81e3:      	testq	%rax, %rax
    81e6:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    81ec:      	movq	0x1008(%r14), %rax
    81f3:      	movl	$0xffffffde, %ecx       # imm = 0xFFFFFFDE
    81f8:      	testq	%rax, %rax
    81fb:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    8201:      	movq	0x1000(%r14), %rax
    8208:      	movl	$0xffffffe0, %ecx       # imm = 0xFFFFFFE0
    820d:      	testq	%rax, %rax
    8210:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    8216:      	movq	0xff8(%r14), %rax
    821d:      	movl	$0xffffffe2, %ecx       # imm = 0xFFFFFFE2
    8222:      	testq	%rax, %rax
    8225:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    822b:      	movq	0xff0(%r14), %rax
    8232:      	movl	$0xffffffe4, %ecx       # imm = 0xFFFFFFE4
    8237:      	testq	%rax, %rax
    823a:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    8240:      	movq	0xfe8(%r14), %rax
    8247:      	movl	$0xffffffe6, %ecx       # imm = 0xFFFFFFE6
    824c:      	testq	%rax, %rax
    824f:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    8255:      	movq	0xfe0(%r14), %rax
    825c:      	movl	$0xffffffe8, %ecx       # imm = 0xFFFFFFE8
    8261:      	testq	%rax, %rax
    8264:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    826a:      	movq	0xfd8(%r14), %rax
    8271:      	movl	$0xffffffea, %ecx       # imm = 0xFFFFFFEA
    8276:      	testq	%rax, %rax
    8279:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    827f:      	movq	0xfd0(%r14), %rax
    8286:      	movl	$0xffffffec, %ecx       # imm = 0xFFFFFFEC
    828b:      	testq	%rax, %rax
    828e:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    8294:      	movq	0xfc8(%r14), %rax
    829b:      	movl	$0xffffffee, %ecx       # imm = 0xFFFFFFEE
    82a0:      	testq	%rax, %rax
    82a3:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    82a9:      	movq	0xfc0(%r14), %rax
    82b0:      	movl	$0xfffffff0, %ecx       # imm = 0xFFFFFFF0
    82b5:      	testq	%rax, %rax
    82b8:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    82be:      	movq	0xfb8(%r14), %rax
    82c5:      	movl	$0xfffffff2, %ecx       # imm = 0xFFFFFFF2
    82ca:      	testq	%rax, %rax
    82cd:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    82cf:      	movq	0xfb0(%r14), %rax
    82d6:      	movl	$0xfffffff4, %ecx       # imm = 0xFFFFFFF4
    82db:      	testq	%rax, %rax
    82de:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    82e0:      	movq	0xfa8(%r14), %rax
    82e7:      	movl	$0xfffffff6, %ecx       # imm = 0xFFFFFFF6
    82ec:      	testq	%rax, %rax
    82ef:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    82f1:      	movq	0xfa0(%r14), %rax
    82f8:      	movl	$0xfffffff8, %ecx       # imm = 0xFFFFFFF8
    82fd:      	testq	%rax, %rax
    8300:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    8302:      	movq	0xf98(%r14), %rax
    8309:      	movl	$0xfffffffa, %ecx       # imm = 0xFFFFFFFA
    830e:      	testq	%rax, %rax
    8311:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    8313:      	movq	0xf90(%r14), %rax
    831a:      	movl	$0xfffffffc, %ecx       # imm = 0xFFFFFFFC
    831f:      	testq	%rax, %rax
    8322:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    8324:      	movq	0xf88(%r14), %rax
    832b:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    8330:      	testq	%rax, %rax
    8333:      	jne	0x8342 <perf_unwind_dotnet+0x8342>
    8335:      	movq	0x90(%rsp), %rax
    833d:      	movq	(%rax), %rax
    8340:      	xorl	%ecx, %ecx
    8342:      	xorl	%edx, %edx
    8344:      	movq	%rax, %r15
    8347:      	shrq	$0x20, %r15
    834b:      	setne	%dl
    834e:      	cmovel	%eax, %r15d
    8352:      	subl	%edx, %ecx
    8354:      	addl	$0x7e, %ecx
    8357:      	movl	%ecx, %eax
    8359:      	shll	$0x8, %eax
    835c:      	subq	%rax, %r13
    835f:      	jb	0x764a <perf_unwind_dotnet+0x764a>
    8365:      	movq	(%rip), %rax            # 0x836c <perf_unwind_dotnet+0x836c>
    836c:      	cmpl	$0x0, (%rax)
    836f:      	jne	0x84bf <perf_unwind_dotnet+0x84bf>
    8375:      	testl	%r15d, %r15d
    8378:      	jne	0x754e <perf_unwind_dotnet+0x754e>
    837e:      	movl	$0x5f, 0xc(%rsp)
    8386:      	movq	(%rip), %rdi            # 0x838d <perf_unwind_dotnet+0x838d>
    838d:      	leaq	0xc(%rsp), %rsi
    8392:      	movl	$0x1, %eax
    8397:      	callq	*%rax
    8399:      	testq	%rax, %rax
    839c:      	je	0x83a6 <perf_unwind_dotnet+0x83a6>
    839e:      	incq	(%rax)
    83a1:      	jmp	0x8428 <perf_unwind_dotnet+0x8428>
    83a6:      	movq	(%rip), %rax            # 0x83ad <perf_unwind_dotnet+0x83ad>
    83ad:      	cmpl	$0x0, (%rax)
    83b0:      	je	0x8428 <perf_unwind_dotnet+0x8428>
    83b2:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    83bc:      	movq	%rax, 0x36(%rsp)
    83c1:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    83cb:      	movq	%rax, 0x30(%rsp)
    83d0:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    83da:      	movq	%rax, 0x28(%rsp)
    83df:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    83e9:      	movq	%rax, 0x20(%rsp)
    83ee:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    83f8:      	movq	%rax, 0x18(%rsp)
    83fd:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    8407:      	movq	%rax, 0x10(%rsp)
    840c:      	leaq	0x10(%rsp), %rdi
    8411:      	movl	$0x2e, %eax
    8416:      	movl	$0x6, %ecx
    841b:      	movl	0xc(%rsp), %edx
    841f:      	movl	$0x2e, %esi
    8424:      	xorl	%eax, %eax
    8426:      	callq	*%rcx
    8428:      	movl	$0x1773, %edx           # imm = 0x1773
    842d:      	movb	$0x1, %bl
    842f:      	movq	(%rip), %rax            # 0x8436 <perf_unwind_dotnet+0x8436>
    8436:      	cmpl	$0x0, (%rax)
    8439:      	je	0x7599 <perf_unwind_dotnet+0x7599>
    843f:      	movabsq	$0xa642520687469, %rax  # imm = 0xA642520687469
    8449:      	movq	%rax, 0x30(%rsp)
    844e:      	movabsq	$0x772064656c696166, %rax # imm = 0x772064656C696166
    8458:      	movq	%rax, 0x28(%rsp)
    845d:      	movabsq	$0x2074726174735f65, %rax # imm = 0x2074726174735F65
    8467:      	movq	%rax, 0x20(%rsp)
    846c:      	movabsq	$0x646f63203e2d2d20, %rax # imm = 0x646F63203E2D2D20
    8476:      	movq	%rax, 0x18(%rsp)
    847b:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    8485:      	movq	%rax, 0x10(%rsp)
    848a:      	leaq	0x10(%rsp), %rdi
    848f:      	movl	$0x28, %eax
    8494:      	movl	$0x6, %ecx
    8499:      	movl	$0x28, %esi
    849e:      	xorl	%eax, %eax
    84a0:      	callq	*%rcx
    84a2:      	jmp	0x7599 <perf_unwind_dotnet+0x7599>
    84a7:      	movl	%r15d, %ecx
    84aa:      	shrl	$0x10, %ecx
    84ad:      	andl	$0xf, %ecx
    84b0:      	je	0x855e <perf_unwind_dotnet+0x855e>
    84b6:      	addq	$-0x80, %r13
    84ba:      	jmp	0x8594 <perf_unwind_dotnet+0x8594>
    84bf:      	movabsq	$0x207972746e65202c, %rax # imm = 0x207972746E65202C
    84c9:      	movq	%rax, 0x40(%rsp)
    84ce:      	movabsq	$0x6425206465707069, %rax # imm = 0x6425206465707069
    84d8:      	movq	%rax, 0x38(%rsp)
    84dd:      	movabsq	$0x6b73203a786c2520, %rax # imm = 0x6B73203A786C2520
    84e7:      	movq	%rax, 0x30(%rsp)
    84ec:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    84f6:      	movq	%rax, 0x28(%rsp)
    84fb:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    8505:      	movq	%rax, 0x20(%rsp)
    850a:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    8514:      	movq	%rax, 0x18(%rsp)
    8519:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    8523:      	movq	%rax, 0x10(%rsp)
    8528:      	movl	$0xa7825, 0x48(%rsp)    # imm = 0xA7825
    8530:      	leaq	0x10(%rsp), %rdi
    8535:      	movl	$0x3c, %eax
    853a:      	movl	$0x6, %r9d
    8540:      	movl	$0x3c, %esi
    8545:      	movq	%r13, %rdx
    8548:      	movl	%r15d, %r8d
    854b:      	xorl	%eax, %eax
    854d:      	callq	*%r9
    8550:      	testl	%r15d, %r15d
    8553:      	jne	0x754e <perf_unwind_dotnet+0x754e>
    8559:      	jmp	0x837e <perf_unwind_dotnet+0x837e>
    855e:      	movl	%r15d, %ecx
    8561:      	shrl	$0x14, %ecx
    8564:      	andl	$0xf, %ecx
    8567:      	je	0x8572 <perf_unwind_dotnet+0x8572>
    8569:      	addq	$-0xa0, %r13
    8570:      	jmp	0x8594 <perf_unwind_dotnet+0x8594>
    8572:      	movl	%r15d, %ecx
    8575:      	shrl	$0x18, %ecx
    8578:      	andl	$0xf, %ecx
    857b:      	je	0x8586 <perf_unwind_dotnet+0x8586>
    857d:      	addq	$-0xc0, %r13
    8584:      	jmp	0x8594 <perf_unwind_dotnet+0x8594>
    8586:      	shrl	$0x1c, %r15d
    858a:      	addq	$-0xe0, %r13
    8591:      	movl	%r15d, %ecx
    8594:      	addq	%r13, %rbx
    8597:      	leal	-0x4(,%rcx,4), %r15d
    859f:      	addq	%rbx, %r15
    85a2:      	movq	(%rip), %rax            # 0x85a9 <perf_unwind_dotnet+0x85a9>
    85a9:      	cmpl	$0x0, (%rax)
    85ac:      	jne	0x897c <perf_unwind_dotnet+0x897c>
    85b2:      	leaq	-0x8(%r15), %rdx
    85b6:      	leaq	0x68(%rsp), %rdi
    85bb:      	movl	$0x8, %eax
    85c0:      	movl	$0x70, %ecx
    85c5:      	movl	$0x8, %esi
    85ca:      	callq	*%rcx
    85cc:      	testq	%rax, %rax
    85cf:      	movq	(%rip), %rbp            # 0x85d6 <perf_unwind_dotnet+0x85d6>
    85d6:      	jne	0xbb6 <perf_unwind_dotnet+0xbb6>
    85dc:      	movl	$0x1f, %ebp
    85e1:      	movq	(%rip), %rax            # 0x85e8 <perf_unwind_dotnet+0x85e8>
    85e8:      	cmpl	$0x0, (%rax)
    85eb:      	jne	0x89fb <perf_unwind_dotnet+0x89fb>
    85f1:      	movl	0x2c0(%r14), %eax
    85f8:      	cmpq	$0x7e, %rax
    85fc:      	ja	0xc0c <perf_unwind_dotnet+0xc0c>
    8602:      	movq	0x68(%rsp), %rcx
    8607:      	subq	%r15, %r12
    860a:      	shlq	$0x5, %rcx
    860e:      	addq	%rbp, %rcx
    8611:      	leal	0x1(%rax), %edx
    8614:      	movl	%edx, 0x2c0(%r14)
    861b:      	leaq	(%rax,%rax,2), %rax
    861f:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    8627:      	movq	%r12, 0x2d8(%r14,%rax,8)
    862f:      	movb	$0xa, 0x2e0(%r14,%rax,8)
    8638:      	movzbl	0x88(%rsp), %ecx
    8640:      	movb	%cl, 0x2e1(%r14,%rax,8)
    8648:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    8654:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    865f:      	movl	$0x5b, 0xc(%rsp)
    8667:      	movq	(%rip), %rdi            # 0x866e <perf_unwind_dotnet+0x866e>
    866e:      	leaq	0xc(%rsp), %rsi
    8673:      	movl	$0x1, %eax
    8678:      	callq	*%rax
    867a:      	testq	%rax, %rax
    867d:      	je	0x8684 <perf_unwind_dotnet+0x8684>
    867f:      	incq	(%rax)
    8682:      	jmp	0x8694 <perf_unwind_dotnet+0x8694>
    8684:      	movq	(%rip), %rax            # 0x868b <perf_unwind_dotnet+0x868b>
    868b:      	cmpl	$0x0, (%rax)
    868e:      	jne	0x8a5a <perf_unwind_dotnet+0x8a5a>
    8694:      	movq	0x98(%rsp), %rax
    869c:      	movq	(%rax), %r13
    869f:      	movq	(%rip), %rax            # 0x86a6 <perf_unwind_dotnet+0x86a6>
    86a6:      	movl	(%rax), %eax
    86a8:      	testq	%r13, %r13
    86ab:      	je	0x88ec <perf_unwind_dotnet+0x88ec>
    86b1:      	testl	%eax, %eax
    86b3:      	jne	0x8ad5 <perf_unwind_dotnet+0x8ad5>
    86b9:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    86c3:      	cmpq	%rax, %r13
    86c6:      	ja	0x2516 <perf_unwind_dotnet+0x2516>
    86cc:      	cmpq	$0x1000, %r13           # imm = 0x1000
    86d3:      	jb	0x26b1 <perf_unwind_dotnet+0x26b1>
    86d9:      	movl	(%r14), %eax
    86dc:      	movl	$0x60, 0x70(%rsp)
    86e4:      	movbel	%eax, 0x74(%rsp)
    86ea:      	movbeq	%r13, 0x78(%rsp)
    86f1:      	movq	(%rip), %rdi            # 0x86f8 <perf_unwind_dotnet+0x86f8>
    86f8:      	leaq	0x70(%rsp), %rsi
    86fd:      	movl	$0x1, %eax
    8702:      	callq	*%rax
    8704:      	testq	%rax, %rax
    8707:      	je	0x8837 <perf_unwind_dotnet+0x8837>
    870d:      	movq	0x8(%rax), %r12
    8711:      	movabsq	$0xffffffffffffff, %rcx # imm = 0xFFFFFFFFFFFFFF
    871b:      	andq	%r12, %rcx
    871e:      	movq	%rcx, 0xf20(%r14)
    8725:      	movq	(%rax), %rax
    8728:      	movq	%rax, 0xf10(%r14)
    872f:      	shrq	$0x38, %r12
    8733:      	movq	%r13, %rax
    8736:      	subq	%rcx, %rax
    8739:      	movq	%rax, 0xf18(%r14)
    8740:      	movq	(%rip), %rax            # 0x8747 <perf_unwind_dotnet+0x8747>
    8747:      	cmpl	$0x0, (%rax)
    874a:      	jne	0x8b72 <perf_unwind_dotnet+0x8b72>
    8750:      	cmpl	$0x1, %r12d
    8754:      	jne	0x8da3 <perf_unwind_dotnet+0x8da3>
    875a:      	movq	0xf10(%r14), %rax
    8761:      	movq	%rax, 0x70(%rsp)
    8766:      	movq	0xf18(%r14), %rbx
    876d:      	movq	(%rip), %rdi            # 0x8774 <perf_unwind_dotnet+0x8774>
    8774:      	leaq	0x70(%rsp), %rsi
    8779:      	movl	$0x1, %eax
    877e:      	callq	*%rax
    8780:      	movl	$0x1, %r12d
    8786:      	testq	%rax, %rax
    8789:      	je	0x8da3 <perf_unwind_dotnet+0x8da3>
    878f:      	movq	%rax, %r15
    8792:      	cmpq	%rbx, (%rax)
    8795:      	ja	0x879d <perf_unwind_dotnet+0x879d>
    8797:      	cmpq	%rbx, 0x8(%r15)
    879b:      	jae	0x87b1 <perf_unwind_dotnet+0x87b1>
    879d:      	cmpq	%rbx, 0x10(%r15)
    87a1:      	ja	0x8da3 <perf_unwind_dotnet+0x8da3>
    87a7:      	cmpq	%rbx, 0x18(%r15)
    87ab:      	jb	0x8da3 <perf_unwind_dotnet+0x8da3>
    87b1:      	movq	(%rip), %rax            # 0x87b8 <perf_unwind_dotnet+0x87b8>
    87b8:      	cmpl	$0x0, (%rax)
    87bb:      	jne	0x8c87 <perf_unwind_dotnet+0x8c87>
    87c1:      	movl	0x1380(%r14), %eax
    87c8:      	movl	0x20(%r15), %ecx
    87cc:      	btl	%ecx, %eax
    87cf:      	jae	0x8cf4 <perf_unwind_dotnet+0x8cf4>
    87d5:      	movq	(%rip), %rax            # 0x87dc <perf_unwind_dotnet+0x87dc>
    87dc:      	cmpl	$0x0, (%rax)
    87df:      	je	0x8da3 <perf_unwind_dotnet+0x8da3>
    87e5:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    87ef:      	movq	%rax, 0x20(%rsp)
    87f4:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    87fe:      	movq	%rax, 0x18(%rsp)
    8803:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    880d:      	movq	%rax, 0x10(%rsp)
    8812:      	movl	$0xa656e, 0x27(%rsp)    # imm = 0xA656E
    881a:      	leaq	0x10(%rsp), %rdi
    881f:      	movl	$0x1b, %eax
    8824:      	movl	$0x6, %ecx
    8829:      	movl	$0x1b, %esi
    882e:      	xorl	%eax, %eax
    8830:      	callq	*%rcx
    8832:      	jmp	0x8da3 <perf_unwind_dotnet+0x8da3>
    8837:      	movq	0x60(%rsp), %r15
    883c:      	movq	(%rip), %rbp            # 0x8843 <perf_unwind_dotnet+0x8843>
    8843:      	cmpl	$0x0, (%rbp)
    8847:      	jne	0x885e <perf_unwind_dotnet+0x885e>
    8849:      	movl	$0xc, 0xf28(%r14)
    8854:      	movl	$0xfac, %eax            # imm = 0xFAC
    8859:      	jmp	0x7812 <perf_unwind_dotnet+0x7812>
    885e:      	movabsq	$0xa786c2578302043, %rax # imm = 0xA786C2578302043
    8868:      	movq	%rax, 0x40(%rsp)
    886d:      	movabsq	$0x5020726f6620676e, %rax # imm = 0x5020726F6620676E
    8877:      	movq	%rax, 0x38(%rsp)
    887c:      	movabsq	$0x697070616d207972, %rax # imm = 0x697070616D207972
    8886:      	movq	%rax, 0x30(%rsp)
    888b:      	movabsq	$0x6f6d656d206c6176, %rax # imm = 0x6F6D656D206C6176
    8895:      	movq	%rax, 0x28(%rsp)
    889a:      	movabsq	$0x7265746e69207075, %rax # imm = 0x7265746E69207075
    88a4:      	movq	%rax, 0x20(%rsp)
    88a9:      	movabsq	$0x206b6f6f6c206f74, %rax # imm = 0x206B6F6F6C206F74
    88b3:      	movq	%rax, 0x18(%rsp)
    88b8:      	movabsq	$0x206572756c696146, %rax # imm = 0x206572756C696146
    88c2:      	movq	%rax, 0x10(%rsp)
    88c7:      	movb	$0x0, 0x48(%rsp)
    88cc:      	leaq	0x10(%rsp), %rdi
    88d1:      	movl	$0x39, %eax
    88d6:      	movl	$0x6, %ecx
    88db:      	movl	$0x39, %esi
    88e0:      	movq	%r13, %rdx
    88e3:      	xorl	%eax, %eax
    88e5:      	callq	*%rcx
    88e7:      	jmp	0x8849 <perf_unwind_dotnet+0x8849>
    88ec:      	movq	0x60(%rsp), %r15
    88f1:      	movq	(%rip), %rbp            # 0x88f8 <perf_unwind_dotnet+0x88f8>
    88f8:      	testl	%eax, %eax
    88fa:      	je	0x259c <perf_unwind_dotnet+0x259c>
    8900:      	movabsq	$0xa2930203d3d2043, %rax # imm = 0xA2930203D3D2043
    890a:      	movq	%rax, 0x38(%rsp)
    890f:      	movabsq	$0x5028206572756c69, %rax # imm = 0x5028206572756C69
    8919:      	movq	%rax, 0x30(%rsp)
    891e:      	movabsq	$0x616620646e69776e, %rax # imm = 0x616620646E69776E
    8928:      	movq	%rax, 0x28(%rsp)
    892d:      	movabsq	$0x75206f7420657564, %rax # imm = 0x75206F7420657564
    8937:      	movq	%rax, 0x20(%rsp)
    893c:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    8946:      	movq	%rax, 0x18(%rsp)
    894b:      	movabsq	$0x676e6970706f7453, %rax # imm = 0x676E6970706F7453
    8955:      	movq	%rax, 0x10(%rsp)
    895a:      	movb	$0x0, 0x40(%rsp)
    895f:      	leaq	0x10(%rsp), %rdi
    8964:      	movl	$0x31, %eax
    8969:      	movl	$0x6, %ecx
    896e:      	movl	$0x31, %esi
    8973:      	xorl	%eax, %eax
    8975:      	callq	*%rcx
    8977:      	jmp	0x259c <perf_unwind_dotnet+0x259c>
    897c:      	movabsq	$0xa786c253d7465, %rax  # imm = 0xA786C253D7465
    8986:      	movq	%rax, 0x36(%rsp)
    898b:      	movabsq	$0x746572202c78253d, %rax # imm = 0x746572202C78253D
    8995:      	movq	%rax, 0x30(%rsp)
    899a:      	movabsq	$0x6c6176202c786c25, %rax # imm = 0x6C6176202C786C25
    89a4:      	movq	%rax, 0x28(%rsp)
    89a9:      	movabsq	$0x203d2061746c6564, %rax # imm = 0x203D2061746C6564
    89b3:      	movq	%rax, 0x20(%rsp)
    89b8:      	movabsq	$0x5f6370203e2d2d20, %rax # imm = 0x5F6370203E2D2D20
    89c2:      	movq	%rax, 0x18(%rsp)
    89c7:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    89d1:      	movq	%rax, 0x10(%rsp)
    89d6:      	leaq	0x10(%rsp), %rdi
    89db:      	movl	$0x2e, %eax
    89e0:      	movl	$0x6, %r9d
    89e6:      	movl	$0x2e, %esi
    89eb:      	movq	%r13, %rdx
    89ee:      	movq	%r15, %r8
    89f1:      	xorl	%eax, %eax
    89f3:      	callq	*%r9
    89f6:      	jmp	0x85b2 <perf_unwind_dotnet+0x85b2>
    89fb:      	leaq	(%rip), %rsi            # 0x8a02 <perf_unwind_dotnet+0x8a02>
    8a02:      	leaq	0x10(%rsp), %rax
    8a07:      	movl	$0x8, %ecx
    8a0c:      	movq	%rax, %rdi
    8a0f:      	rep		movsq	(%rsi), %es:(%rdi)
    8a12:      	movb	$0x0, 0x52(%rsp)
    8a17:      	movw	$0xa78, 0x50(%rsp)      # imm = 0xA78
    8a1e:      	movl	$0x43, %ecx
    8a23:      	movl	$0x6, %r9d
    8a29:      	movq	0x68(%rsp), %rcx
    8a2e:      	movq	%r12, %r8
    8a31:      	subq	%r15, %r8
    8a34:      	movq	%rax, %rdi
    8a37:      	movl	$0x43, %esi
    8a3c:      	movq	%r15, %rdx
    8a3f:      	xorl	%eax, %eax
    8a41:      	callq	*%r9
    8a44:      	movl	0x2c0(%r14), %eax
    8a4b:      	cmpq	$0x7e, %rax
    8a4f:      	ja	0xc0c <perf_unwind_dotnet+0xc0c>
    8a55:      	jmp	0x8602 <perf_unwind_dotnet+0x8602>
    8a5a:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    8a64:      	movq	%rax, 0x36(%rsp)
    8a69:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    8a73:      	movq	%rax, 0x30(%rsp)
    8a78:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    8a82:      	movq	%rax, 0x28(%rsp)
    8a87:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    8a91:      	movq	%rax, 0x20(%rsp)
    8a96:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    8aa0:      	movq	%rax, 0x18(%rsp)
    8aa5:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    8aaf:      	movq	%rax, 0x10(%rsp)
    8ab4:      	leaq	0x10(%rsp), %rdi
    8ab9:      	movl	$0x2e, %eax
    8abe:      	movl	$0x6, %ecx
    8ac3:      	movl	0xc(%rsp), %edx
    8ac7:      	movl	$0x2e, %esi
    8acc:      	xorl	%eax, %eax
    8ace:      	callq	*%rcx
    8ad0:      	jmp	0x8694 <perf_unwind_dotnet+0x8694>
    8ad5:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    8adf:      	movq	%rax, 0x38(%rsp)
    8ae4:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    8aee:      	movq	%rax, 0x30(%rsp)
    8af3:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    8afd:      	movq	%rax, 0x28(%rsp)
    8b02:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    8b0c:      	movq	%rax, 0x20(%rsp)
    8b11:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    8b1b:      	movq	%rax, 0x18(%rsp)
    8b20:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    8b2a:      	movq	%rax, 0x10(%rsp)
    8b2f:      	movb	$0x0, 0x40(%rsp)
    8b34:      	leaq	0x10(%rsp), %rdi
    8b39:      	movl	$0x31, %eax
    8b3e:      	movl	$0x6, %ecx
    8b43:      	movl	0x2c0(%r14), %edx
    8b4a:      	movl	$0x31, %esi
    8b4f:      	xorl	%eax, %eax
    8b51:      	callq	*%rcx
    8b53:      	movq	0xed0(%r14), %r13
    8b5a:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    8b64:      	cmpq	%rax, %r13
    8b67:      	ja	0x2516 <perf_unwind_dotnet+0x2516>
    8b6d:      	jmp	0x86cc <perf_unwind_dotnet+0x86cc>
    8b72:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    8b7c:      	movq	%rax, 0x38(%rsp)
    8b81:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    8b8b:      	movq	%rax, 0x30(%rsp)
    8b90:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    8b9a:      	movq	%rax, 0x28(%rsp)
    8b9f:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    8ba9:      	movq	%rax, 0x20(%rsp)
    8bae:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    8bb8:      	movq	%rax, 0x18(%rsp)
    8bbd:      	movabsq	$0x6365732074786554, %rbx # imm = 0x6365732074786554
    8bc7:      	movq	%rbx, 0x10(%rsp)
    8bcc:      	movw	$0xa, 0x40(%rsp)
    8bd3:      	leaq	0x10(%rsp), %rdi
    8bd8:      	movl	$0x32, %eax
    8bdd:      	movl	$0x6, %r9d
    8be3:      	movq	0xf10(%r14), %rcx
    8bea:      	movl	$0x32, %esi
    8bef:      	movq	%r13, %rdx
    8bf2:      	movl	%r12d, %r8d
    8bf5:      	xorl	%eax, %eax
    8bf7:      	callq	*%r9
    8bfa:      	movq	(%rip), %rax            # 0x8c01 <perf_unwind_dotnet+0x8c01>
    8c01:      	cmpl	$0x0, (%rax)
    8c04:      	je	0x8750 <perf_unwind_dotnet+0x8750>
    8c0a:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    8c14:      	movq	%rax, 0x37(%rsp)
    8c19:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    8c23:      	movq	%rax, 0x30(%rsp)
    8c28:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    8c32:      	movq	%rax, 0x28(%rsp)
    8c37:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    8c41:      	movq	%rax, 0x20(%rsp)
    8c46:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    8c50:      	movq	%rax, 0x18(%rsp)
    8c55:      	movq	%rbx, 0x10(%rsp)
    8c5a:      	leaq	0x10(%rsp), %rdi
    8c5f:      	movl	$0x2f, %eax
    8c64:      	movl	$0x6, %r8d
    8c6a:      	movq	0xf18(%r14), %rcx
    8c71:      	movq	0xf20(%r14), %rdx
    8c78:      	movl	$0x2f, %esi
    8c7d:      	xorl	%eax, %eax
    8c7f:      	callq	*%r8
    8c82:      	jmp	0x8750 <perf_unwind_dotnet+0x8750>
    8c87:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    8c91:      	movq	%rax, 0x26(%rsp)
    8c96:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    8ca0:      	movq	%rax, 0x20(%rsp)
    8ca5:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    8caf:      	movq	%rax, 0x18(%rsp)
    8cb4:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    8cbe:      	movq	%rax, 0x10(%rsp)
    8cc3:      	leaq	0x10(%rsp), %rdi
    8cc8:      	movl	$0x1e, %eax
    8ccd:      	movl	$0x6, %ecx
    8cd2:      	movzwl	0x20(%r15), %edx
    8cd7:      	movl	$0x1e, %esi
    8cdc:      	xorl	%eax, %eax
    8cde:      	callq	*%rcx
    8ce0:      	movl	0x1380(%r14), %eax
    8ce7:      	movl	0x20(%r15), %ecx
    8ceb:      	btl	%ecx, %eax
    8cee:      	jb	0x87d5 <perf_unwind_dotnet+0x87d5>
    8cf4:      	movl	$0x0, 0x68(%rsp)
    8cfc:      	movq	(%rip), %rdi            # 0x8d03 <perf_unwind_dotnet+0x8d03>
    8d03:      	leaq	0x68(%rsp), %rsi
    8d08:      	movl	$0x1, %eax
    8d0d:      	callq	*%rax
    8d0f:      	testq	%rax, %rax
    8d12:      	je	0x8d1c <perf_unwind_dotnet+0x8d1c>
    8d14:      	incq	(%rax)
    8d17:      	jmp	0x8d9e <perf_unwind_dotnet+0x8d9e>
    8d1c:      	movq	(%rip), %rax            # 0x8d23 <perf_unwind_dotnet+0x8d23>
    8d23:      	cmpl	$0x0, (%rax)
    8d26:      	je	0x8d9e <perf_unwind_dotnet+0x8d9e>
    8d28:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    8d32:      	movq	%rax, 0x36(%rsp)
    8d37:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    8d41:      	movq	%rax, 0x30(%rsp)
    8d46:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    8d50:      	movq	%rax, 0x28(%rsp)
    8d55:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    8d5f:      	movq	%rax, 0x20(%rsp)
    8d64:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    8d6e:      	movq	%rax, 0x18(%rsp)
    8d73:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    8d7d:      	movq	%rax, 0x10(%rsp)
    8d82:      	leaq	0x10(%rsp), %rdi
    8d87:      	movl	$0x2e, %eax
    8d8c:      	movl	$0x6, %ecx
    8d91:      	movl	0x68(%rsp), %edx
    8d95:      	movl	$0x2e, %esi
    8d9a:      	xorl	%eax, %eax
    8d9c:      	callq	*%rcx
    8d9e:      	movzwl	0x20(%r15), %r12d
    8da3:      	movq	0x60(%rsp), %r15
    8da8:      	movq	(%rip), %rbp            # 0x8daf <perf_unwind_dotnet+0x8daf>
    8daf:      	xorl	%eax, %eax
    8db1:      	jmp	0x7815 <perf_unwind_dotnet+0x7815>

Disassembly of section kprobe/unwind_dotnet:

0000000000000000 <kprobe_unwind_dotnet>:
       0:      	pushq	%rbp
       1:      	pushq	%r15
       3:      	pushq	%r14
       5:      	pushq	%r13
       7:      	pushq	%r12
       9:      	pushq	%rbx
       a:      	subq	$0xa8, %rsp
      11:      	movq	%rdi, %r15
      14:      	movl	$0x0, 0x10(%rsp)
      1c:      	movq	(%rip), %rdi            # 0x23 <kprobe_unwind_dotnet+0x23>
      23:      	leaq	0x10(%rsp), %rsi
      28:      	movl	$0x1, %eax
      2d:      	callq	*%rax
      2f:      	testq	%rax, %rax
      32:      	je	0x78cb <kprobe_unwind_dotnet+0x78cb>
      38:      	movq	%rax, %r14
      3b:      	movl	(%rax), %eax
      3d:      	movl	%eax, 0xa4(%rsp)
      44:      	movq	(%rip), %rbp            # 0x4b <kprobe_unwind_dotnet+0x4b>
      4b:      	cmpl	$0x0, (%rbp)
      4f:      	jne	0x753 <kprobe_unwind_dotnet+0x753>
      55:      	movq	(%rip), %rdi            # 0x5c <kprobe_unwind_dotnet+0x5c>
      5c:      	leaq	0xa4(%rsp), %rsi
      64:      	movl	$0x1, %eax
      69:      	callq	*%rax
      6b:      	testq	%rax, %rax
      6e:      	je	0x9d <kprobe_unwind_dotnet+0x9d>
      70:      	movb	$0x2, 0x1385(%r14)
      78:      	movl	$0x5a, 0x70(%rsp)
      80:      	movq	(%rip), %rdi            # 0x87 <kprobe_unwind_dotnet+0x87>
      87:      	leaq	0x70(%rsp), %rsi
      8c:      	movl	$0x1, %eax
      91:      	callq	*%rax
      93:      	testq	%rax, %rax
      96:      	je	0xd3 <kprobe_unwind_dotnet+0xd3>
      98:      	incq	(%rax)
      9b:      	jmp	0xdd <kprobe_unwind_dotnet+0xdd>
      9d:      	cmpl	$0x0, (%rbp)
      a1:      	jne	0x83d <kprobe_unwind_dotnet+0x83d>
      a7:      	movl	$0x5c, 0x70(%rsp)
      af:      	movq	(%rip), %rdi            # 0xb6 <kprobe_unwind_dotnet+0xb6>
      b6:      	leaq	0x70(%rsp), %rsi
      bb:      	movl	$0x1, %eax
      c0:      	callq	*%rax
      c2:      	testq	%rax, %rax
      c5:      	je	0x2ae <kprobe_unwind_dotnet+0x2ae>
      cb:      	incq	(%rax)
      ce:      	jmp	0x2b8 <kprobe_unwind_dotnet+0x2b8>
      d3:      	cmpl	$0x0, (%rbp)
      d7:      	jne	0x8bd <kprobe_unwind_dotnet+0x8bd>
      dd:      	movq	0xed0(%r14), %r12
      e4:      	movq	0xed8(%r14), %rbx
      eb:      	movq	0xee0(%r14), %r13
      f2:      	movzbl	0xf30(%r14), %ecx
      fa:      	cmpl	$0x0, (%rbp)
      fe:      	jne	0x7c4 <kprobe_unwind_dotnet+0x7c4>
     104:      	cmpq	%rbx, %r13
     107:      	jb	0x77c0 <kprobe_unwind_dotnet+0x77c0>
     10d:      	leaq	0x2000(%rbx), %rax
     114:      	cmpq	%rax, %r13
     117:      	jae	0x77c0 <kprobe_unwind_dotnet+0x77c0>
     11d:      	movb	%cl, 0x98(%rsp)
     124:      	movq	%r15, 0x60(%rsp)
     129:      	leaq	0xed0(%r14), %rbx
     130:      	movq	%r14, %rax
     133:      	addq	$0xf80, %rax            # imm = 0xF80
     139:      	movq	%rax, 0x90(%rsp)
     141:      	movq	0xf10(%r14), %rbp
     148:      	movq	0xf20(%r14), %r15
     14f:      	movq	%r12, 0x68(%rsp)
     154:      	movb	$0x1, 0xf30(%r14)
     15c:      	movq	%rbp, %rax
     15f:      	andq	$-0x80, %rax
     163:      	cmpq	$0x80, %rax
     169:      	jne	0x24e <kprobe_unwind_dotnet+0x24e>
     16f:      	movq	0xed8(%r14), %rax
     176:      	movl	$0x8, %ecx
     17b:      	movl	$0x70, %r8d
     181:      	movq	0xed8(%r14), %rdx
     188:      	movq	%rbx, %rdi
     18b:      	movl	$0x8, %esi
     190:      	callq	*%r8
     193:      	testq	%rax, %rax
     196:      	je	0x2c2 <kprobe_unwind_dotnet+0x2c2>
     19c:      	movq	(%rip), %rbp            # 0x1a3 <kprobe_unwind_dotnet+0x1a3>
     1a3:      	cmpl	$0x0, (%rbp)
     1a7:      	jne	0x9ce <kprobe_unwind_dotnet+0x9ce>
     1ad:      	movl	$0x5d, 0xc(%rsp)
     1b5:      	movq	(%rip), %rdi            # 0x1bc <kprobe_unwind_dotnet+0x1bc>
     1bc:      	leaq	0xc(%rsp), %rsi
     1c1:      	movl	$0x1, %eax
     1c6:      	callq	*%rax
     1c8:      	testq	%rax, %rax
     1cb:      	movq	0x60(%rsp), %r15
     1d0:      	jne	0x2a6 <kprobe_unwind_dotnet+0x2a6>
     1d6:      	cmpl	$0x0, (%rbp)
     1da:      	je	0x780d <kprobe_unwind_dotnet+0x780d>
     1e0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     1ea:      	movq	%rax, 0x36(%rsp)
     1ef:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     1f9:      	movq	%rax, 0x30(%rsp)
     1fe:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     208:      	movq	%rax, 0x28(%rsp)
     20d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     217:      	movq	%rax, 0x20(%rsp)
     21c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     226:      	movq	%rax, 0x18(%rsp)
     22b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     235:      	movq	%rax, 0x10(%rsp)
     23a:      	leaq	0x10(%rsp), %rdi
     23f:      	movl	$0x2e, %eax
     244:      	movl	$0x6, %ecx
     249:      	jmp	0x472 <kprobe_unwind_dotnet+0x472>
     24e:      	leaq	0x70(%rsp), %rdi
     253:      	movl	$0x10, %eax
     258:      	movl	$0x70, %ecx
     25d:      	movl	$0x10, %esi
     262:      	movq	%r13, %rdx
     265:      	callq	*%rcx
     267:      	testq	%rax, %rax
     26a:      	je	0x2d2 <kprobe_unwind_dotnet+0x2d2>
     26c:      	movq	(%rip), %rbp            # 0x273 <kprobe_unwind_dotnet+0x273>
     273:      	cmpl	$0x0, (%rbp)
     277:      	jne	0xa27 <kprobe_unwind_dotnet+0xa27>
     27d:      	movl	$0x5d, 0xc(%rsp)
     285:      	movq	(%rip), %rdi            # 0x28c <kprobe_unwind_dotnet+0x28c>
     28c:      	leaq	0xc(%rsp), %rsi
     291:      	movl	$0x1, %eax
     296:      	callq	*%rax
     298:      	testq	%rax, %rax
     29b:      	movq	0x60(%rsp), %r15
     2a0:      	je	0x3ff <kprobe_unwind_dotnet+0x3ff>
     2a6:      	incq	(%rax)
     2a9:      	jmp	0x780d <kprobe_unwind_dotnet+0x780d>
     2ae:      	cmpl	$0x0, (%rbp)
     2b2:      	jne	0x938 <kprobe_unwind_dotnet+0x938>
     2b8:      	movl	$0x1770, %eax           # imm = 0x1770
     2bd:      	jmp	0x7812 <kprobe_unwind_dotnet+0x7812>
     2c2:      	addq	$0x8, 0xed8(%r14)
     2ca:      	andl	$0x7f, %ebp
     2cd:      	jmp	0xbef <kprobe_unwind_dotnet+0xbef>
     2d2:      	addq	$0x10, %r13
     2d6:      	movq	%r13, 0xed8(%r14)
     2dd:      	movq	0x70(%rsp), %rax
     2e2:      	movq	%rax, 0xee0(%r14)
     2e9:      	movq	0x78(%rsp), %rax
     2ee:      	movq	%rax, 0xed0(%r14)
     2f5:      	movq	(%rip), %rax            # 0x2fc <kprobe_unwind_dotnet+0x2fc>
     2fc:      	cmpl	$0x0, (%rax)
     2ff:      	jne	0xa80 <kprobe_unwind_dotnet+0xa80>
     305:      	cmpq	$0x100, %rbp            # imm = 0x100
     30c:      	jb	0xbef <kprobe_unwind_dotnet+0xbef>
     312:      	movq	0xf10(%r14), %rbp
     319:      	movq	0xf20(%r14), %rax
     320:      	movq	%r12, %r13
     323:      	movq	%rax, 0x88(%rsp)
     32b:      	subq	%rax, %r13
     32e:      	movq	(%rip), %rax            # 0x335 <kprobe_unwind_dotnet+0x335>
     335:      	cmpl	$0x0, (%rax)
     338:      	jne	0xb19 <kprobe_unwind_dotnet+0xb19>
     33e:      	movq	%r13, %r15
     341:      	andq	$-0x4, %r15
     345:      	movl	$0x100, %ecx            # imm = 0x100
     34a:      	movq	%r15, %rax
     34d:      	xorl	%edx, %edx
     34f:      	divq	%rcx
     352:      	movq	%rax, %rcx
     355:      	movl	$0x7f, %eax
     35a:      	subq	%rcx, %rax
     35d:      	jns	0x376 <kprobe_unwind_dotnet+0x376>
     35f:      	movl	$0x100, %ecx            # imm = 0x100
     364:      	movq	%r15, %rax
     367:      	xorl	%edx, %edx
     369:      	divq	%rcx
     36c:      	leaq	-0x3fc(%rbp,%rax,4), %rbp
     374:      	xorl	%eax, %eax
     376:      	movl	$0x80, %ecx
     37b:      	cqto
     37d:      	idivq	%rcx
     380:      	movq	0x90(%rsp), %rax
     388:      	leaq	(%rax,%rdx,4), %rdi
     38c:      	movl	$0x200, %eax            # imm = 0x200
     391:      	movl	$0x70, %ecx
     396:      	movl	$0x200, %esi            # imm = 0x200
     39b:      	movq	%rbp, %rdx
     39e:      	callq	*%rcx
     3a0:      	testq	%rax, %rax
     3a3:      	je	0x484 <kprobe_unwind_dotnet+0x484>
     3a9:      	movq	(%rip), %rbp            # 0x3b0 <kprobe_unwind_dotnet+0x3b0>
     3b0:      	cmpl	$0x0, (%rbp)
     3b4:      	jne	0x6fc <kprobe_unwind_dotnet+0x6fc>
     3ba:      	movl	$0x5e, 0xc(%rsp)
     3c2:      	movq	(%rip), %rdi            # 0x3c9 <kprobe_unwind_dotnet+0x3c9>
     3c9:      	leaq	0xc(%rsp), %rsi
     3ce:      	movl	$0x1, %eax
     3d3:      	callq	*%rax
     3d5:      	testq	%rax, %rax
     3d8:      	movq	0x60(%rsp), %r15
     3dd:      	movq	%rbx, %r12
     3e0:      	je	0x4f6 <kprobe_unwind_dotnet+0x4f6>
     3e6:      	incq	(%rax)
     3e9:      	movl	$0x1772, %edx           # imm = 0x1772
     3ee:      	xorl	%ebx, %ebx
     3f0:      	cmpl	$0x0, (%rbp)
     3f4:      	je	0x511 <kprobe_unwind_dotnet+0x511>
     3fa:      	jmp	0x1acf <kprobe_unwind_dotnet+0x1acf>
     3ff:      	cmpl	$0x0, (%rbp)
     403:      	je	0x780d <kprobe_unwind_dotnet+0x780d>
     409:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     413:      	movq	%rax, 0x36(%rsp)
     418:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     422:      	movq	%rax, 0x30(%rsp)
     427:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     431:      	movq	%rax, 0x28(%rsp)
     436:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     440:      	movq	%rax, 0x20(%rsp)
     445:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     44f:      	movq	%rax, 0x18(%rsp)
     454:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     45e:      	movq	%rax, 0x10(%rsp)
     463:      	leaq	0x10(%rsp), %rdi
     468:      	movl	$0x2e, %eax
     46d:      	movl	$0x6, %ecx
     472:      	movl	0xc(%rsp), %edx
     476:      	movl	$0x2e, %esi
     47b:      	xorl	%eax, %eax
     47d:      	callq	*%rcx
     47f:      	jmp	0x780d <kprobe_unwind_dotnet+0x780d>
     484:      	movl	0x117c(%r14), %ebp
     48b:      	movq	(%rip), %rax            # 0x492 <kprobe_unwind_dotnet+0x492>
     492:      	cmpl	$0x0, (%rax)
     495:      	jne	0x1138 <kprobe_unwind_dotnet+0x1138>
     49b:      	movl	$0x20, %ecx
     4a0:      	movq	%r15, %rax
     4a3:      	xorl	%edx, %edx
     4a5:      	divq	%rcx
     4a8:      	movl	$0x8, %ecx
     4ad:      	xorl	%edx, %edx
     4af:      	divq	%rcx
     4b2:      	shll	$0x2, %edx
     4b5:      	movb	$0x1c, %al
     4b7:      	subb	%dl, %al
     4b9:      	shrxl	%eax, %ebp, %r15d
     4be:      	testl	%r15d, %r15d
     4c1:      	je	0x633 <kprobe_unwind_dotnet+0x633>
     4c7:      	andq	$-0x20, %r13
     4cb:      	movq	(%rip), %rbp            # 0x4d2 <kprobe_unwind_dotnet+0x4d2>
     4d2:      	movl	%r15d, %ecx
     4d5:      	andl	$0xf, %ecx
     4d8:      	jne	0xb77 <kprobe_unwind_dotnet+0xb77>
     4de:      	movl	%r15d, %ecx
     4e1:      	shrl	$0x4, %ecx
     4e4:      	andl	$0xf, %ecx
     4e7:      	je	0x73f <kprobe_unwind_dotnet+0x73f>
     4ed:      	addq	$-0x20, %r13
     4f1:      	jmp	0xb77 <kprobe_unwind_dotnet+0xb77>
     4f6:      	cmpl	$0x0, (%rbp)
     4fa:      	jne	0x1244 <kprobe_unwind_dotnet+0x1244>
     500:      	movl	$0x1772, %edx           # imm = 0x1772
     505:      	xorl	%ebx, %ebx
     507:      	cmpl	$0x0, (%rbp)
     50b:      	jne	0x1acf <kprobe_unwind_dotnet+0x1acf>
     511:      	movl	$0x1772, %eax           # imm = 0x1772
     516:      	testb	%bl, %bl
     518:      	je	0x7812 <kprobe_unwind_dotnet+0x7812>
     51e:      	movl	0x2c0(%r14), %eax
     525:      	cmpq	$0x7f, %rax
     529:      	jb	0x5d5 <kprobe_unwind_dotnet+0x5d5>
     52f:      	cmpl	$0x0, (%rbp)
     533:      	jne	0x12d0 <kprobe_unwind_dotnet+0x12d0>
     539:      	movl	$0x2, 0xc(%rsp)
     541:      	movq	(%rip), %rdi            # 0x548 <kprobe_unwind_dotnet+0x548>
     548:      	leaq	0xc(%rsp), %rsi
     54d:      	movl	$0x1, %eax
     552:      	callq	*%rax
     554:      	testq	%rax, %rax
     557:      	jne	0xc42 <kprobe_unwind_dotnet+0xc42>
     55d:      	cmpl	$0x0, (%rbp)
     561:      	je	0xc51 <kprobe_unwind_dotnet+0xc51>
     567:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     571:      	movq	%rax, 0x36(%rsp)
     576:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     580:      	movq	%rax, 0x30(%rsp)
     585:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     58f:      	movq	%rax, 0x28(%rsp)
     594:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     59e:      	movq	%rax, 0x20(%rsp)
     5a3:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     5ad:      	movq	%rax, 0x18(%rsp)
     5b2:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     5bc:      	movq	%rax, 0x10(%rsp)
     5c1:      	leaq	0x10(%rsp), %rdi
     5c6:      	movl	$0x2e, %eax
     5cb:      	movl	$0x6, %ecx
     5d0:      	jmp	0x109c <kprobe_unwind_dotnet+0x109c>
     5d5:      	leal	0x1(%rax), %ecx
     5d8:      	movl	%ecx, 0x2c0(%r14)
     5df:      	leaq	(%rax,%rax,2), %rax
     5e3:      	movq	$0x0, 0x2d0(%r14,%rax,8)
     5ef:      	movq	$0x1773, 0x2d8(%r14,%rax,8) # imm = 0x1773
     5fb:      	movb	$-0x76, 0x2e0(%r14,%rax,8)
     604:      	movl	$0x0, 0x2e1(%r14,%rax,8)
     610:      	movl	$0x0, 0x2e4(%r14,%rax,8)
     61c:      	movq	%r12, %rbx
     61f:      	movq	(%rbx), %r13
     622:      	movl	(%rbp), %eax
     625:      	testq	%r13, %r13
     628:      	jne	0xd8a <kprobe_unwind_dotnet+0xd8a>
     62e:      	jmp	0x2594 <kprobe_unwind_dotnet+0x2594>
     633:      	andq	$-0x100, %r13
     63a:      	addq	$-0x20, %r13
     63e:      	movl	0x1178(%r14), %r15d
     645:      	movq	(%rip), %rbp            # 0x64c <kprobe_unwind_dotnet+0x64c>
     64c:      	cmpl	$0x0, (%rbp)
     650:      	jne	0x14a0 <kprobe_unwind_dotnet+0x14a0>
     656:      	xorl	%ecx, %ecx
     658:      	testl	%r15d, %r15d
     65b:      	je	0x1534 <kprobe_unwind_dotnet+0x1534>
     661:      	movl	%ecx, %eax
     663:      	shll	$0x8, %eax
     666:      	subq	%rax, %r13
     669:      	jae	0x1a5e <kprobe_unwind_dotnet+0x1a5e>
     66f:      	cmpl	$0x0, (%rbp)
     673:      	je	0x3ba <kprobe_unwind_dotnet+0x3ba>
     679:      	movabsq	$0xa657361625f63, %rax  # imm = 0xA657361625F63
     683:      	movq	%rax, 0x36(%rsp)
     688:      	movabsq	$0x5f637020776f6c65, %rax # imm = 0x5F637020776F6C65
     692:      	movq	%rax, 0x30(%rsp)
     697:      	movabsq	$0x6220746e65772068, %rax # imm = 0x6220746E65772068
     6a1:      	movq	%rax, 0x28(%rsp)
     6a6:      	movabsq	$0x6372616573207061, %rax # imm = 0x6372616573207061
     6b0:      	movq	%rax, 0x20(%rsp)
     6b5:      	movabsq	$0x6d20656c6262696e, %rax # imm = 0x6D20656C6262696E
     6bf:      	movq	%rax, 0x18(%rsp)
     6c4:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
     6ce:      	movq	%rax, 0x10(%rsp)
     6d3:      	leaq	0x10(%rsp), %rdi
     6d8:      	movl	$0x2e, %eax
     6dd:      	movl	$0x6, %ecx
     6e2:      	movl	$0x2e, %esi
     6e7:      	xorl	%eax, %eax
     6e9:      	callq	*%rcx
     6eb:      	movq	(%rip), %rbp            # 0x6f2 <kprobe_unwind_dotnet+0x6f2>
     6f2:      	cmpl	$0x0, (%rbp)
     6f6:      	je	0x3ba <kprobe_unwind_dotnet+0x3ba>
     6fc:      	movabsq	$0x6e756f6620746f6e, %rax # imm = 0x6E756F6620746F6E
     706:      	movq	%rax, 0x18(%rsp)
     70b:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
     715:      	movq	%rax, 0x10(%rsp)
     71a:      	movl	$0xa646e, 0x1f(%rsp)    # imm = 0xA646E
     722:      	leaq	0x10(%rsp), %rdi
     727:      	movl	$0x13, %eax
     72c:      	movl	$0x6, %ecx
     731:      	movl	$0x13, %esi
     736:      	xorl	%eax, %eax
     738:      	callq	*%rcx
     73a:      	jmp	0x3ba <kprobe_unwind_dotnet+0x3ba>
     73f:      	movl	%r15d, %ecx
     742:      	shrl	$0x8, %ecx
     745:      	andl	$0xf, %ecx
     748:      	je	0x7ac <kprobe_unwind_dotnet+0x7ac>
     74a:      	addq	$-0x40, %r13
     74e:      	jmp	0xb77 <kprobe_unwind_dotnet+0xb77>
     753:      	movabsq	$0x3d3d206425207465, %rax # imm = 0x3D3D206425207465
     75d:      	movq	%rax, 0x20(%rsp)
     762:      	movabsq	$0x6e746f645f646e69, %rax # imm = 0x6E746F645F646E69
     76c:      	movq	%rax, 0x18(%rsp)
     771:      	movabsq	$0x776e75203d3d3d3d, %rax # imm = 0x776E75203D3D3D3D
     77b:      	movq	%rax, 0x10(%rsp)
     780:      	movl	$0xa3d3d, 0x28(%rsp)    # imm = 0xA3D3D
     788:      	leaq	0x10(%rsp), %rdi
     78d:      	movl	$0x1c, %eax
     792:      	movl	$0x6, %ecx
     797:      	movl	0x2c0(%r14), %edx
     79e:      	movl	$0x1c, %esi
     7a3:      	xorl	%eax, %eax
     7a5:      	callq	*%rcx
     7a7:      	jmp	0x55 <kprobe_unwind_dotnet+0x55>
     7ac:      	movl	%r15d, %ecx
     7af:      	shrl	$0xc, %ecx
     7b2:      	andl	$0xf, %ecx
     7b5:      	je	0x8a5 <kprobe_unwind_dotnet+0x8a5>
     7bb:      	addq	$-0x60, %r13
     7bf:      	jmp	0xb77 <kprobe_unwind_dotnet+0xb77>
     7c4:      	movabsq	$0x6c25203a7066202c, %rax # imm = 0x6C25203A7066202C
     7ce:      	movq	%rax, 0x28(%rsp)
     7d3:      	movabsq	$0x786c25203a707320, %rax # imm = 0x786C25203A707320
     7dd:      	movq	%rax, 0x20(%rsp)
     7e2:      	movabsq	$0x2c786c25203a6370, %rax # imm = 0x2C786C25203A6370
     7ec:      	movq	%rax, 0x18(%rsp)
     7f1:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
     7fb:      	movq	%rax, 0x10(%rsp)
     800:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
     808:      	leaq	0x10(%rsp), %rdi
     80d:      	movl	$0x23, %eax
     812:      	movl	$0x6, %r9d
     818:      	movl	$0x23, %esi
     81d:      	movq	%r12, %rdx
     820:      	movl	%ecx, %ebp
     822:      	movq	%rbx, %rcx
     825:      	movq	%r13, %r8
     828:      	xorl	%eax, %eax
     82a:      	callq	*%r9
     82d:      	movl	%ebp, %ecx
     82f:      	cmpq	%rbx, %r13
     832:      	jae	0x10d <kprobe_unwind_dotnet+0x10d>
     838:      	jmp	0x77c0 <kprobe_unwind_dotnet+0x77c0>
     83d:      	movabsq	$0xa646970207369, %rax  # imm = 0xA646970207369
     847:      	movq	%rax, 0x30(%rsp)
     84c:      	movabsq	$0x687420726f66206f, %rax # imm = 0x687420726F66206F
     856:      	movq	%rax, 0x28(%rsp)
     85b:      	movabsq	$0x666e49636f725074, %rax # imm = 0x666E49636F725074
     865:      	movq	%rax, 0x20(%rsp)
     86a:      	movabsq	$0x656e746f44206f6e, %rax # imm = 0x656E746F44206F6E
     874:      	movq	%rax, 0x18(%rsp)
     879:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
     883:      	movq	%rax, 0x10(%rsp)
     888:      	leaq	0x10(%rsp), %rdi
     88d:      	movl	$0x28, %eax
     892:      	movl	$0x6, %ecx
     897:      	movl	$0x28, %esi
     89c:      	xorl	%eax, %eax
     89e:      	callq	*%rcx
     8a0:      	jmp	0xa7 <kprobe_unwind_dotnet+0xa7>
     8a5:      	movl	%r15d, %ecx
     8a8:      	shrl	$0x10, %ecx
     8ab:      	andl	$0xf, %ecx
     8ae:      	je	0x9b3 <kprobe_unwind_dotnet+0x9b3>
     8b4:      	addq	$-0x80, %r13
     8b8:      	jmp	0xb77 <kprobe_unwind_dotnet+0xb77>
     8bd:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     8c7:      	movq	%rax, 0x36(%rsp)
     8cc:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     8d6:      	movq	%rax, 0x30(%rsp)
     8db:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     8e5:      	movq	%rax, 0x28(%rsp)
     8ea:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     8f4:      	movq	%rax, 0x20(%rsp)
     8f9:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     903:      	movq	%rax, 0x18(%rsp)
     908:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     912:      	movq	%rax, 0x10(%rsp)
     917:      	leaq	0x10(%rsp), %rdi
     91c:      	movl	$0x2e, %eax
     921:      	movl	$0x6, %ecx
     926:      	movl	0x70(%rsp), %edx
     92a:      	movl	$0x2e, %esi
     92f:      	xorl	%eax, %eax
     931:      	callq	*%rcx
     933:      	jmp	0xdd <kprobe_unwind_dotnet+0xdd>
     938:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
     942:      	movq	%rax, 0x36(%rsp)
     947:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
     951:      	movq	%rax, 0x30(%rsp)
     956:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
     960:      	movq	%rax, 0x28(%rsp)
     965:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
     96f:      	movq	%rax, 0x20(%rsp)
     974:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
     97e:      	movq	%rax, 0x18(%rsp)
     983:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
     98d:      	movq	%rax, 0x10(%rsp)
     992:      	leaq	0x10(%rsp), %rdi
     997:      	movl	$0x2e, %eax
     99c:      	movl	$0x6, %ecx
     9a1:      	movl	0x70(%rsp), %edx
     9a5:      	movl	$0x2e, %esi
     9aa:      	xorl	%eax, %eax
     9ac:      	callq	*%rcx
     9ae:      	jmp	0x2b8 <kprobe_unwind_dotnet+0x2b8>
     9b3:      	movl	%r15d, %ecx
     9b6:      	shrl	$0x14, %ecx
     9b9:      	andl	$0xf, %ecx
     9bc:      	je	0xb05 <kprobe_unwind_dotnet+0xb05>
     9c2:      	addq	$-0xa0, %r13
     9c9:      	jmp	0xb70 <kprobe_unwind_dotnet+0xb70>
     9ce:      	movabsq	$0xa7265746e696f, %rax  # imm = 0xA7265746E696F
     9d8:      	movq	%rax, 0x28(%rsp)
     9dd:      	movabsq	$0x70206b6361747320, %rax # imm = 0x70206B6361747320
     9e7:      	movq	%rax, 0x20(%rsp)
     9ec:      	movabsq	$0x646162203e2d2d20, %rax # imm = 0x646162203E2D2D20
     9f6:      	movq	%rax, 0x18(%rsp)
     9fb:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
     a05:      	movq	%rax, 0x10(%rsp)
     a0a:      	leaq	0x10(%rsp), %rdi
     a0f:      	movl	$0x20, %eax
     a14:      	movl	$0x6, %ecx
     a19:      	movl	$0x20, %esi
     a1e:      	xorl	%eax, %eax
     a20:      	callq	*%rcx
     a22:      	jmp	0x1ad <kprobe_unwind_dotnet+0x1ad>
     a27:      	movabsq	$0xa7265746e696f, %rax  # imm = 0xA7265746E696F
     a31:      	movq	%rax, 0x28(%rsp)
     a36:      	movabsq	$0x7020656d61726620, %rax # imm = 0x7020656D61726620
     a40:      	movq	%rax, 0x20(%rsp)
     a45:      	movabsq	$0x646162203e2d2d20, %rax # imm = 0x646162203E2D2D20
     a4f:      	movq	%rax, 0x18(%rsp)
     a54:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
     a5e:      	movq	%rax, 0x10(%rsp)
     a63:      	leaq	0x10(%rsp), %rdi
     a68:      	movl	$0x20, %eax
     a6d:      	movl	$0x6, %ecx
     a72:      	movl	$0x20, %esi
     a77:      	xorl	%eax, %eax
     a79:      	callq	*%rcx
     a7b:      	jmp	0x27d <kprobe_unwind_dotnet+0x27d>
     a80:      	movabsq	$0x6c25203a7066202c, %rax # imm = 0x6C25203A7066202C
     a8a:      	movq	%rax, 0x28(%rsp)
     a8f:      	movabsq	$0x786c25203a707320, %rax # imm = 0x786C25203A707320
     a99:      	movq	%rax, 0x20(%rsp)
     a9e:      	movabsq	$0x2c786c25203a6370, %rax # imm = 0x2C786C25203A6370
     aa8:      	movq	%rax, 0x18(%rsp)
     aad:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
     ab7:      	movq	%rax, 0x10(%rsp)
     abc:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
     ac4:      	leaq	0x10(%rsp), %rdi
     ac9:      	movl	$0x23, %eax
     ace:      	movl	$0x6, %r9d
     ad4:      	movq	0xed0(%r14), %rdx
     adb:      	movq	0xed8(%r14), %rcx
     ae2:      	movq	0xee0(%r14), %r8
     ae9:      	movl	$0x23, %esi
     aee:      	xorl	%eax, %eax
     af0:      	callq	*%r9
     af3:      	cmpq	$0x100, %rbp            # imm = 0x100
     afa:      	jae	0x312 <kprobe_unwind_dotnet+0x312>
     b00:      	jmp	0xbef <kprobe_unwind_dotnet+0xbef>
     b05:      	movl	%r15d, %ecx
     b08:      	shrl	$0x18, %ecx
     b0b:      	andl	$0xf, %ecx
     b0e:      	je	0xb62 <kprobe_unwind_dotnet+0xb62>
     b10:      	addq	$-0xc0, %r13
     b17:      	jmp	0xb70 <kprobe_unwind_dotnet+0xb70>
     b19:      	leaq	(%rip), %rsi            # 0xb20 <kprobe_unwind_dotnet+0xb20>
     b20:      	leaq	0x10(%rsp), %rax
     b25:      	movl	$0x8, %ecx
     b2a:      	movq	%rax, %rdi
     b2d:      	rep		movsq	(%rsi), %es:(%rdi)
     b30:      	movw	$0xa, 0x50(%rsp)
     b37:      	movl	$0x42, %ecx
     b3c:      	movl	$0x6, %r9d
     b42:      	movq	%rax, %rdi
     b45:      	movl	$0x42, %esi
     b4a:      	movq	%r13, %rdx
     b4d:      	movq	0x88(%rsp), %rcx
     b55:      	movq	%rbp, %r8
     b58:      	xorl	%eax, %eax
     b5a:      	callq	*%r9
     b5d:      	jmp	0x33e <kprobe_unwind_dotnet+0x33e>
     b62:      	shrl	$0x1c, %r15d
     b66:      	addq	$-0xe0, %r13
     b6d:      	movl	%r15d, %ecx
     b70:      	movq	(%rip), %rbp            # 0xb77 <kprobe_unwind_dotnet+0xb77>
     b77:      	movq	0x88(%rsp), %rax
     b7f:      	addq	%r13, %rax
     b82:      	leal	-0x4(,%rcx,4), %r15d
     b8a:      	addq	%rax, %r15
     b8d:      	cmpl	$0x0, (%rbp)
     b91:      	jne	0x11c5 <kprobe_unwind_dotnet+0x11c5>
     b97:      	leaq	-0x8(%r15), %rdx
     b9b:      	leaq	0x68(%rsp), %rdi
     ba0:      	movl	$0x8, %eax
     ba5:      	movl	$0x70, %ecx
     baa:      	movl	$0x8, %esi
     baf:      	callq	*%rcx
     bb1:      	testq	%rax, %rax
     bb4:      	je	0xbea <kprobe_unwind_dotnet+0xbea>
     bb6:      	cmpl	$0x0, (%rbp)
     bba:      	jne	0x1338 <kprobe_unwind_dotnet+0x1338>
     bc0:      	movl	$0x5e, 0xc(%rsp)
     bc8:      	movq	(%rip), %rdi            # 0xbcf <kprobe_unwind_dotnet+0xbcf>
     bcf:      	leaq	0xc(%rsp), %rsi
     bd4:      	movl	$0x1, %eax
     bd9:      	callq	*%rax
     bdb:      	testq	%rax, %rax
     bde:      	movq	0x60(%rsp), %r15
     be3:      	je	0xc5b <kprobe_unwind_dotnet+0xc5b>
     be5:      	incq	(%rax)
     be8:      	jmp	0xc65 <kprobe_unwind_dotnet+0xc65>
     bea:      	movl	$0x1f, %ebp
     bef:      	movq	(%rip), %rax            # 0xbf6 <kprobe_unwind_dotnet+0xbf6>
     bf6:      	cmpl	$0x0, (%rax)
     bf9:      	jne	0xc6f <kprobe_unwind_dotnet+0xc6f>
     bfb:      	movl	0x2c0(%r14), %eax
     c02:      	cmpq	$0x7f, %rax
     c06:      	jb	0xcc9 <kprobe_unwind_dotnet+0xcc9>
     c0c:      	movq	(%rip), %rbp            # 0xc13 <kprobe_unwind_dotnet+0xc13>
     c13:      	cmpl	$0x0, (%rbp)
     c17:      	jne	0xdbe <kprobe_unwind_dotnet+0xdbe>
     c1d:      	movl	$0x2, 0xc(%rsp)
     c25:      	movq	(%rip), %rdi            # 0xc2c <kprobe_unwind_dotnet+0xc2c>
     c2c:      	leaq	0xc(%rsp), %rsi
     c31:      	movl	$0x1, %eax
     c36:      	callq	*%rax
     c38:      	testq	%rax, %rax
     c3b:      	movq	0x60(%rsp), %r15
     c40:      	je	0xc47 <kprobe_unwind_dotnet+0xc47>
     c42:      	incq	(%rax)
     c45:      	jmp	0xc51 <kprobe_unwind_dotnet+0xc51>
     c47:      	cmpl	$0x0, (%rbp)
     c4b:      	jne	0x1033 <kprobe_unwind_dotnet+0x1033>
     c51:      	movl	$0x2, %eax
     c56:      	jmp	0x7812 <kprobe_unwind_dotnet+0x7812>
     c5b:      	cmpl	$0x0, (%rbp)
     c5f:      	jne	0x1be3 <kprobe_unwind_dotnet+0x1be3>
     c65:      	movl	$0x1772, %eax           # imm = 0x1772
     c6a:      	jmp	0x7812 <kprobe_unwind_dotnet+0x7812>
     c6f:      	leaq	(%rip), %rsi            # 0xc76 <kprobe_unwind_dotnet+0xc76>
     c76:      	leaq	0x10(%rsp), %rax
     c7b:      	movl	$0x8, %ecx
     c80:      	movq	%rax, %rdi
     c83:      	rep		movsq	(%rsi), %es:(%rdi)
     c86:      	movb	$0x0, 0x52(%rsp)
     c8b:      	movw	$0xa78, 0x50(%rsp)      # imm = 0xA78
     c92:      	movl	$0x43, %ecx
     c97:      	movl	$0x6, %r9d
     c9d:      	movq	0x68(%rsp), %rcx
     ca2:      	movq	%r12, %r8
     ca5:      	subq	%r15, %r8
     ca8:      	movq	%rax, %rdi
     cab:      	movl	$0x43, %esi
     cb0:      	movq	%r15, %rdx
     cb3:      	xorl	%eax, %eax
     cb5:      	callq	*%r9
     cb8:      	movl	0x2c0(%r14), %eax
     cbf:      	cmpq	$0x7f, %rax
     cc3:      	jae	0xc0c <kprobe_unwind_dotnet+0xc0c>
     cc9:      	movq	0x68(%rsp), %rcx
     cce:      	subq	%r15, %r12
     cd1:      	shlq	$0x5, %rcx
     cd5:      	addq	%rbp, %rcx
     cd8:      	leal	0x1(%rax), %edx
     cdb:      	movl	%edx, 0x2c0(%r14)
     ce2:      	leaq	(%rax,%rax,2), %rax
     ce6:      	movq	%rcx, 0x2d0(%r14,%rax,8)
     cee:      	movq	%r12, 0x2d8(%r14,%rax,8)
     cf6:      	movb	$0xa, 0x2e0(%r14,%rax,8)
     cff:      	movzbl	0x98(%rsp), %ecx
     d07:      	movb	%cl, 0x2e1(%r14,%rax,8)
     d0f:      	movl	$0x0, 0x2e2(%r14,%rax,8)
     d1b:      	movw	$0x0, 0x2e6(%r14,%rax,8)
     d26:      	movl	$0x5b, 0xc(%rsp)
     d2e:      	movq	(%rip), %rdi            # 0xd35 <kprobe_unwind_dotnet+0xd35>
     d35:      	leaq	0xc(%rsp), %rsi
     d3a:      	movl	$0x1, %eax
     d3f:      	callq	*%rax
     d41:      	testq	%rax, %rax
     d44:      	je	0xd65 <kprobe_unwind_dotnet+0xd65>
     d46:      	incq	(%rax)
     d49:      	movq	0x60(%rsp), %r15
     d4e:      	movq	(%rip), %rbp            # 0xd55 <kprobe_unwind_dotnet+0xd55>
     d55:      	movq	(%rbx), %r13
     d58:      	movl	(%rbp), %eax
     d5b:      	testq	%r13, %r13
     d5e:      	jne	0xd8a <kprobe_unwind_dotnet+0xd8a>
     d60:      	jmp	0x2594 <kprobe_unwind_dotnet+0x2594>
     d65:      	movq	(%rip), %rbp            # 0xd6c <kprobe_unwind_dotnet+0xd6c>
     d6c:      	cmpl	$0x0, (%rbp)
     d70:      	movq	0x60(%rsp), %r15
     d75:      	jne	0x10ae <kprobe_unwind_dotnet+0x10ae>
     d7b:      	movq	(%rbx), %r13
     d7e:      	movl	(%rbp), %eax
     d81:      	testq	%r13, %r13
     d84:      	je	0x2594 <kprobe_unwind_dotnet+0x2594>
     d8a:      	testl	%eax, %eax
     d8c:      	jne	0xe26 <kprobe_unwind_dotnet+0xe26>
     d92:      	movq	%r13, %rax
     d95:      	shrq	$0x38, %rax
     d99:      	je	0xeb8 <kprobe_unwind_dotnet+0xeb8>
     d9f:      	cmpl	$0x0, (%rbp)
     da3:      	jne	0x252c <kprobe_unwind_dotnet+0x252c>
     da9:      	movl	$0xb, 0xf28(%r14)
     db4:      	movl	$0xfab, %eax            # imm = 0xFAB
     db9:      	jmp	0x7812 <kprobe_unwind_dotnet+0x7812>
     dbe:      	movabsq	$0xa6c6c75662073, %rax  # imm = 0xA6C6C75662073
     dc8:      	movq	%rax, 0x2d(%rsp)
     dcd:      	movabsq	$0x66207369206b6361, %rax # imm = 0x66207369206B6361
     dd7:      	movq	%rax, 0x28(%rsp)
     ddc:      	movabsq	$0x7473203a656d6172, %rax # imm = 0x7473203A656D6172
     de6:      	movq	%rax, 0x20(%rsp)
     deb:      	movabsq	$0x662068737570206f, %rax # imm = 0x662068737570206F
     df5:      	movq	%rax, 0x18(%rsp)
     dfa:      	movabsq	$0x7420656c62616e75, %rax # imm = 0x7420656C62616E75
     e04:      	movq	%rax, 0x10(%rsp)
     e09:      	leaq	0x10(%rsp), %rdi
     e0e:      	movl	$0x25, %eax
     e13:      	movl	$0x6, %ecx
     e18:      	movl	$0x25, %esi
     e1d:      	xorl	%eax, %eax
     e1f:      	callq	*%rcx
     e21:      	jmp	0xc1d <kprobe_unwind_dotnet+0xc1d>
     e26:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
     e30:      	movq	%rax, 0x38(%rsp)
     e35:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
     e3f:      	movq	%rax, 0x30(%rsp)
     e44:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
     e4e:      	movq	%rax, 0x28(%rsp)
     e53:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
     e5d:      	movq	%rax, 0x20(%rsp)
     e62:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
     e6c:      	movq	%rax, 0x18(%rsp)
     e71:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
     e7b:      	movq	%rax, 0x10(%rsp)
     e80:      	movb	$0x0, 0x40(%rsp)
     e85:      	leaq	0x10(%rsp), %rdi
     e8a:      	movl	$0x31, %eax
     e8f:      	movl	$0x6, %ecx
     e94:      	movl	0x2c0(%r14), %edx
     e9b:      	movl	$0x31, %esi
     ea0:      	xorl	%eax, %eax
     ea2:      	callq	*%rcx
     ea4:      	movq	0xed0(%r14), %r13
     eab:      	movq	%r13, %rax
     eae:      	shrq	$0x38, %rax
     eb2:      	jne	0xd9f <kprobe_unwind_dotnet+0xd9f>
     eb8:      	cmpq	$0xfff, %r13            # imm = 0xFFF
     ebf:      	ja	0xee0 <kprobe_unwind_dotnet+0xee0>
     ec1:      	cmpl	$0x0, (%rbp)
     ec5:      	jne	0x26c7 <kprobe_unwind_dotnet+0x26c7>
     ecb:      	movl	$0x31, 0xf28(%r14)
     ed6:      	movl	$0xfae, %eax            # imm = 0xFAE
     edb:      	jmp	0x7812 <kprobe_unwind_dotnet+0x7812>
     ee0:      	movl	(%r14), %eax
     ee3:      	movl	$0x60, 0x70(%rsp)
     eeb:      	movbel	%eax, 0x74(%rsp)
     ef1:      	movbeq	%r13, 0x78(%rsp)
     ef8:      	movq	(%rip), %rdi            # 0xeff <kprobe_unwind_dotnet+0xeff>
     eff:      	leaq	0x70(%rsp), %rsi
     f04:      	movl	$0x1, %eax
     f09:      	callq	*%rax
     f0b:      	testq	%rax, %rax
     f0e:      	je	0x8843 <kprobe_unwind_dotnet+0x8843>
     f14:      	movq	%rbx, 0x98(%rsp)
     f1c:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
     f26:      	movq	0x8(%rax), %r12
     f2a:      	movq	%r12, %rcx
     f2d:      	andq	%rdx, %rcx
     f30:      	movq	%rcx, 0xf20(%r14)
     f37:      	movq	(%rax), %rax
     f3a:      	movq	%rax, 0xf10(%r14)
     f41:      	shrq	$0x38, %r12
     f45:      	movq	%r13, %rax
     f48:      	subq	%rcx, %rax
     f4b:      	movq	%rax, 0xf18(%r14)
     f52:      	cmpl	$0x0, (%rbp)
     f56:      	jne	0x1391 <kprobe_unwind_dotnet+0x1391>
     f5c:      	cmpl	$0x1, %r12d
     f60:      	jne	0x1d0e <kprobe_unwind_dotnet+0x1d0e>
     f66:      	movq	0xf10(%r14), %rax
     f6d:      	movq	%rax, 0x70(%rsp)
     f72:      	movq	0xf18(%r14), %rbx
     f79:      	movq	(%rip), %rdi            # 0xf80 <kprobe_unwind_dotnet+0xf80>
     f80:      	leaq	0x70(%rsp), %rsi
     f85:      	movl	$0x1, %eax
     f8a:      	callq	*%rax
     f8c:      	movl	$0x1, %r12d
     f92:      	testq	%rax, %rax
     f95:      	je	0x1d0e <kprobe_unwind_dotnet+0x1d0e>
     f9b:      	cmpq	%rbx, (%rax)
     f9e:      	ja	0xfa6 <kprobe_unwind_dotnet+0xfa6>
     fa0:      	cmpq	%rbx, 0x8(%rax)
     fa4:      	jae	0xfba <kprobe_unwind_dotnet+0xfba>
     fa6:      	cmpq	%rbx, 0x10(%rax)
     faa:      	ja	0x1d0e <kprobe_unwind_dotnet+0x1d0e>
     fb0:      	cmpq	%rbx, 0x18(%rax)
     fb4:      	jb	0x1d0e <kprobe_unwind_dotnet+0x1d0e>
     fba:      	cmpl	$0x0, (%rbp)
     fbe:      	jne	0x1c5e <kprobe_unwind_dotnet+0x1c5e>
     fc4:      	movl	0x1380(%r14), %ecx
     fcb:      	movl	0x20(%rax), %edx
     fce:      	btl	%edx, %ecx
     fd1:      	jae	0x1cd1 <kprobe_unwind_dotnet+0x1cd1>
     fd7:      	cmpl	$0x0, (%rbp)
     fdb:      	je	0x1d0e <kprobe_unwind_dotnet+0x1d0e>
     fe1:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
     feb:      	movq	%rax, 0x20(%rsp)
     ff0:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
     ffa:      	movq	%rax, 0x18(%rsp)
     fff:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    1009:      	movq	%rax, 0x10(%rsp)
    100e:      	movl	$0xa656e, 0x27(%rsp)    # imm = 0xA656E
    1016:      	leaq	0x10(%rsp), %rdi
    101b:      	movl	$0x1b, %eax
    1020:      	movl	$0x6, %ecx
    1025:      	movl	$0x1b, %esi
    102a:      	xorl	%eax, %eax
    102c:      	callq	*%rcx
    102e:      	jmp	0x1d0e <kprobe_unwind_dotnet+0x1d0e>
    1033:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    103d:      	movq	%rax, 0x36(%rsp)
    1042:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    104c:      	movq	%rax, 0x30(%rsp)
    1051:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    105b:      	movq	%rax, 0x28(%rsp)
    1060:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    106a:      	movq	%rax, 0x20(%rsp)
    106f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1079:      	movq	%rax, 0x18(%rsp)
    107e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1088:      	movq	%rax, 0x10(%rsp)
    108d:      	leaq	0x10(%rsp), %rdi
    1092:      	movl	$0x2e, %eax
    1097:      	movl	$0x6, %ecx
    109c:      	movl	0xc(%rsp), %edx
    10a0:      	movl	$0x2e, %esi
    10a5:      	xorl	%eax, %eax
    10a7:      	callq	*%rcx
    10a9:      	jmp	0xc51 <kprobe_unwind_dotnet+0xc51>
    10ae:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    10b8:      	movq	%rax, 0x36(%rsp)
    10bd:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    10c7:      	movq	%rax, 0x30(%rsp)
    10cc:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    10d6:      	movq	%rax, 0x28(%rsp)
    10db:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    10e5:      	movq	%rax, 0x20(%rsp)
    10ea:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    10f4:      	movq	%rax, 0x18(%rsp)
    10f9:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1103:      	movq	%rax, 0x10(%rsp)
    1108:      	leaq	0x10(%rsp), %rdi
    110d:      	movl	$0x2e, %eax
    1112:      	movl	$0x6, %ecx
    1117:      	movl	0xc(%rsp), %edx
    111b:      	movl	$0x2e, %esi
    1120:      	xorl	%eax, %eax
    1122:      	callq	*%rcx
    1124:      	movq	(%rbx), %r13
    1127:      	movl	(%rbp), %eax
    112a:      	testq	%r13, %r13
    112d:      	jne	0xd8a <kprobe_unwind_dotnet+0xd8a>
    1133:      	jmp	0x2594 <kprobe_unwind_dotnet+0x2594>
    1138:      	movabsq	$0xa782520797274, %rax  # imm = 0xA782520797274
    1142:      	movq	%rax, 0x3e(%rsp)
    1147:      	movabsq	$0x72746e6520747372, %rax # imm = 0x72746E6520747372
    1151:      	movq	%rax, 0x38(%rsp)
    1156:      	movabsq	$0x6966203a786c2520, %rax # imm = 0x6966203A786C2520
    1160:      	movq	%rax, 0x30(%rsp)
    1165:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    116f:      	movq	%rax, 0x28(%rsp)
    1174:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    117e:      	movq	%rax, 0x20(%rsp)
    1183:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    118d:      	movq	%rax, 0x18(%rsp)
    1192:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    119c:      	movq	%rax, 0x10(%rsp)
    11a1:      	leaq	0x10(%rsp), %rdi
    11a6:      	movl	$0x36, %eax
    11ab:      	movl	$0x6, %r8d
    11b1:      	movl	$0x36, %esi
    11b6:      	movq	%r15, %rdx
    11b9:      	movl	%ebp, %ecx
    11bb:      	xorl	%eax, %eax
    11bd:      	callq	*%r8
    11c0:      	jmp	0x49b <kprobe_unwind_dotnet+0x49b>
    11c5:      	movabsq	$0xa786c253d7465, %rax  # imm = 0xA786C253D7465
    11cf:      	movq	%rax, 0x36(%rsp)
    11d4:      	movabsq	$0x746572202c78253d, %rax # imm = 0x746572202C78253D
    11de:      	movq	%rax, 0x30(%rsp)
    11e3:      	movabsq	$0x6c6176202c786c25, %rax # imm = 0x6C6176202C786C25
    11ed:      	movq	%rax, 0x28(%rsp)
    11f2:      	movabsq	$0x203d2061746c6564, %rax # imm = 0x203D2061746C6564
    11fc:      	movq	%rax, 0x20(%rsp)
    1201:      	movabsq	$0x5f6370203e2d2d20, %rax # imm = 0x5F6370203E2D2D20
    120b:      	movq	%rax, 0x18(%rsp)
    1210:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    121a:      	movq	%rax, 0x10(%rsp)
    121f:      	leaq	0x10(%rsp), %rdi
    1224:      	movl	$0x2e, %eax
    1229:      	movl	$0x6, %r9d
    122f:      	movl	$0x2e, %esi
    1234:      	movq	%r13, %rdx
    1237:      	movq	%r15, %r8
    123a:      	xorl	%eax, %eax
    123c:      	callq	*%r9
    123f:      	jmp	0xb97 <kprobe_unwind_dotnet+0xb97>
    1244:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    124e:      	movq	%rax, 0x36(%rsp)
    1253:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    125d:      	movq	%rax, 0x30(%rsp)
    1262:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    126c:      	movq	%rax, 0x28(%rsp)
    1271:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    127b:      	movq	%rax, 0x20(%rsp)
    1280:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    128a:      	movq	%rax, 0x18(%rsp)
    128f:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1299:      	movq	%rax, 0x10(%rsp)
    129e:      	leaq	0x10(%rsp), %rdi
    12a3:      	movl	$0x2e, %eax
    12a8:      	movl	$0x6, %ecx
    12ad:      	movl	0xc(%rsp), %edx
    12b1:      	movl	$0x2e, %esi
    12b6:      	xorl	%eax, %eax
    12b8:      	callq	*%rcx
    12ba:      	movl	$0x1772, %edx           # imm = 0x1772
    12bf:      	xorl	%ebx, %ebx
    12c1:      	cmpl	$0x0, (%rbp)
    12c5:      	je	0x511 <kprobe_unwind_dotnet+0x511>
    12cb:      	jmp	0x1acf <kprobe_unwind_dotnet+0x1acf>
    12d0:      	movabsq	$0xa6c6c75662073, %rax  # imm = 0xA6C6C75662073
    12da:      	movq	%rax, 0x2d(%rsp)
    12df:      	movabsq	$0x66207369206b6361, %rax # imm = 0x66207369206B6361
    12e9:      	movq	%rax, 0x28(%rsp)
    12ee:      	movabsq	$0x7473203a656d6172, %rax # imm = 0x7473203A656D6172
    12f8:      	movq	%rax, 0x20(%rsp)
    12fd:      	movabsq	$0x662068737570206f, %rax # imm = 0x662068737570206F
    1307:      	movq	%rax, 0x18(%rsp)
    130c:      	movabsq	$0x7420656c62616e75, %rax # imm = 0x7420656C62616E75
    1316:      	movq	%rax, 0x10(%rsp)
    131b:      	leaq	0x10(%rsp), %rdi
    1320:      	movl	$0x25, %eax
    1325:      	movl	$0x6, %ecx
    132a:      	movl	$0x25, %esi
    132f:      	xorl	%eax, %eax
    1331:      	callq	*%rcx
    1333:      	jmp	0x539 <kprobe_unwind_dotnet+0x539>
    1338:      	movabsq	$0xa726564616568, %rax  # imm = 0xA726564616568
    1342:      	movq	%rax, 0x26(%rsp)
    1347:      	movabsq	$0x65682065646f6320, %rax # imm = 0x65682065646F6320
    1351:      	movq	%rax, 0x20(%rsp)
    1356:      	movabsq	$0x646162203e2d2d20, %rax # imm = 0x646162203E2D2D20
    1360:      	movq	%rax, 0x18(%rsp)
    1365:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    136f:      	movq	%rax, 0x10(%rsp)
    1374:      	leaq	0x10(%rsp), %rdi
    1379:      	movl	$0x1e, %eax
    137e:      	movl	$0x6, %ecx
    1383:      	movl	$0x1e, %esi
    1388:      	xorl	%eax, %eax
    138a:      	callq	*%rcx
    138c:      	jmp	0xbc0 <kprobe_unwind_dotnet+0xbc0>
    1391:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    139b:      	movq	%rax, 0x38(%rsp)
    13a0:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    13aa:      	movq	%rax, 0x30(%rsp)
    13af:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    13b9:      	movq	%rax, 0x28(%rsp)
    13be:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    13c8:      	movq	%rax, 0x20(%rsp)
    13cd:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    13d7:      	movq	%rax, 0x18(%rsp)
    13dc:      	movabsq	$0x6365732074786554, %rbx # imm = 0x6365732074786554
    13e6:      	movq	%rbx, 0x10(%rsp)
    13eb:      	movw	$0xa, 0x40(%rsp)
    13f2:      	leaq	0x10(%rsp), %rdi
    13f7:      	movl	$0x32, %eax
    13fc:      	movl	$0x6, %r9d
    1402:      	movq	0xf10(%r14), %rcx
    1409:      	movl	$0x32, %esi
    140e:      	movq	%r13, %rdx
    1411:      	movl	%r12d, %r8d
    1414:      	xorl	%eax, %eax
    1416:      	callq	*%r9
    1419:      	cmpl	$0x0, (%rbp)
    141d:      	je	0xf5c <kprobe_unwind_dotnet+0xf5c>
    1423:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    142d:      	movq	%rax, 0x37(%rsp)
    1432:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    143c:      	movq	%rax, 0x30(%rsp)
    1441:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    144b:      	movq	%rax, 0x28(%rsp)
    1450:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    145a:      	movq	%rax, 0x20(%rsp)
    145f:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    1469:      	movq	%rax, 0x18(%rsp)
    146e:      	movq	%rbx, 0x10(%rsp)
    1473:      	leaq	0x10(%rsp), %rdi
    1478:      	movl	$0x2f, %eax
    147d:      	movl	$0x6, %r8d
    1483:      	movq	0xf18(%r14), %rcx
    148a:      	movq	0xf20(%r14), %rdx
    1491:      	movl	$0x2f, %esi
    1496:      	xorl	%eax, %eax
    1498:      	callq	*%r8
    149b:      	jmp	0xf5c <kprobe_unwind_dotnet+0xf5c>
    14a0:      	movabsq	$0xa782520797274, %rax  # imm = 0xA782520797274
    14aa:      	movq	%rax, 0x3f(%rsp)
    14af:      	movabsq	$0x746e6520646e6f63, %rax # imm = 0x746E6520646E6F63
    14b9:      	movq	%rax, 0x38(%rsp)
    14be:      	movabsq	$0x6573203a786c2520, %rax # imm = 0x6573203A786C2520
    14c8:      	movq	%rax, 0x30(%rsp)
    14cd:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    14d7:      	movq	%rax, 0x28(%rsp)
    14dc:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    14e6:      	movq	%rax, 0x20(%rsp)
    14eb:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    14f5:      	movq	%rax, 0x18(%rsp)
    14fa:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    1504:      	movq	%rax, 0x10(%rsp)
    1509:      	leaq	0x10(%rsp), %rdi
    150e:      	movl	$0x37, %eax
    1513:      	movl	$0x6, %r8d
    1519:      	movl	$0x37, %esi
    151e:      	movq	%r13, %rdx
    1521:      	movl	%r15d, %ecx
    1524:      	xorl	%eax, %eax
    1526:      	callq	*%r8
    1529:      	xorl	%ecx, %ecx
    152b:      	testl	%r15d, %r15d
    152e:      	jne	0x661 <kprobe_unwind_dotnet+0x661>
    1534:      	movq	0x1170(%r14), %rax
    153b:      	movl	$0xffffff84, %ecx       # imm = 0xFFFFFF84
    1540:      	testq	%rax, %rax
    1543:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    1549:      	movq	0x1168(%r14), %rax
    1550:      	movl	$0xffffff86, %ecx       # imm = 0xFFFFFF86
    1555:      	testq	%rax, %rax
    1558:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    155e:      	movq	0x1160(%r14), %rax
    1565:      	movl	$0xffffff88, %ecx       # imm = 0xFFFFFF88
    156a:      	testq	%rax, %rax
    156d:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    1573:      	movq	0x1158(%r14), %rax
    157a:      	movl	$0xffffff8a, %ecx       # imm = 0xFFFFFF8A
    157f:      	testq	%rax, %rax
    1582:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    1588:      	movq	0x1150(%r14), %rax
    158f:      	movl	$0xffffff8c, %ecx       # imm = 0xFFFFFF8C
    1594:      	testq	%rax, %rax
    1597:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    159d:      	movq	0x1148(%r14), %rax
    15a4:      	movl	$0xffffff8e, %ecx       # imm = 0xFFFFFF8E
    15a9:      	testq	%rax, %rax
    15ac:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    15b2:      	movq	0x1140(%r14), %rax
    15b9:      	movl	$0xffffff90, %ecx       # imm = 0xFFFFFF90
    15be:      	testq	%rax, %rax
    15c1:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    15c7:      	movq	0x1138(%r14), %rax
    15ce:      	movl	$0xffffff92, %ecx       # imm = 0xFFFFFF92
    15d3:      	testq	%rax, %rax
    15d6:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    15dc:      	movq	0x1130(%r14), %rax
    15e3:      	movl	$0xffffff94, %ecx       # imm = 0xFFFFFF94
    15e8:      	testq	%rax, %rax
    15eb:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    15f1:      	movq	0x1128(%r14), %rax
    15f8:      	movl	$0xffffff96, %ecx       # imm = 0xFFFFFF96
    15fd:      	testq	%rax, %rax
    1600:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    1606:      	movq	0x1120(%r14), %rax
    160d:      	movl	$0xffffff98, %ecx       # imm = 0xFFFFFF98
    1612:      	testq	%rax, %rax
    1615:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    161b:      	movq	0x1118(%r14), %rax
    1622:      	movl	$0xffffff9a, %ecx       # imm = 0xFFFFFF9A
    1627:      	testq	%rax, %rax
    162a:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    1630:      	movq	0x1110(%r14), %rax
    1637:      	movl	$0xffffff9c, %ecx       # imm = 0xFFFFFF9C
    163c:      	testq	%rax, %rax
    163f:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    1645:      	movq	0x1108(%r14), %rax
    164c:      	movl	$0xffffff9e, %ecx       # imm = 0xFFFFFF9E
    1651:      	testq	%rax, %rax
    1654:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    165a:      	movq	0x1100(%r14), %rax
    1661:      	movl	$0xffffffa0, %ecx       # imm = 0xFFFFFFA0
    1666:      	testq	%rax, %rax
    1669:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    166f:      	movq	0x10f8(%r14), %rax
    1676:      	movl	$0xffffffa2, %ecx       # imm = 0xFFFFFFA2
    167b:      	testq	%rax, %rax
    167e:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    1684:      	movq	0x10f0(%r14), %rax
    168b:      	movl	$0xffffffa4, %ecx       # imm = 0xFFFFFFA4
    1690:      	testq	%rax, %rax
    1693:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    1699:      	movq	0x10e8(%r14), %rax
    16a0:      	movl	$0xffffffa6, %ecx       # imm = 0xFFFFFFA6
    16a5:      	testq	%rax, %rax
    16a8:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    16ae:      	movq	0x10e0(%r14), %rax
    16b5:      	movl	$0xffffffa8, %ecx       # imm = 0xFFFFFFA8
    16ba:      	testq	%rax, %rax
    16bd:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    16c3:      	movq	0x10d8(%r14), %rax
    16ca:      	movl	$0xffffffaa, %ecx       # imm = 0xFFFFFFAA
    16cf:      	testq	%rax, %rax
    16d2:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    16d8:      	movq	0x10d0(%r14), %rax
    16df:      	movl	$0xffffffac, %ecx       # imm = 0xFFFFFFAC
    16e4:      	testq	%rax, %rax
    16e7:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    16ed:      	movq	0x10c8(%r14), %rax
    16f4:      	movl	$0xffffffae, %ecx       # imm = 0xFFFFFFAE
    16f9:      	testq	%rax, %rax
    16fc:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    1702:      	movq	0x10c0(%r14), %rax
    1709:      	movl	$0xffffffb0, %ecx       # imm = 0xFFFFFFB0
    170e:      	testq	%rax, %rax
    1711:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    1717:      	movq	0x10b8(%r14), %rax
    171e:      	movl	$0xffffffb2, %ecx       # imm = 0xFFFFFFB2
    1723:      	testq	%rax, %rax
    1726:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    172c:      	movq	0x10b0(%r14), %rax
    1733:      	movl	$0xffffffb4, %ecx       # imm = 0xFFFFFFB4
    1738:      	testq	%rax, %rax
    173b:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    1741:      	movq	0x10a8(%r14), %rax
    1748:      	movl	$0xffffffb6, %ecx       # imm = 0xFFFFFFB6
    174d:      	testq	%rax, %rax
    1750:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    1756:      	movq	0x10a0(%r14), %rax
    175d:      	movl	$0xffffffb8, %ecx       # imm = 0xFFFFFFB8
    1762:      	testq	%rax, %rax
    1765:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    176b:      	movq	0x1098(%r14), %rax
    1772:      	movl	$0xffffffba, %ecx       # imm = 0xFFFFFFBA
    1777:      	testq	%rax, %rax
    177a:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    1780:      	movq	0x1090(%r14), %rax
    1787:      	movl	$0xffffffbc, %ecx       # imm = 0xFFFFFFBC
    178c:      	testq	%rax, %rax
    178f:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    1795:      	movq	0x1088(%r14), %rax
    179c:      	movl	$0xffffffbe, %ecx       # imm = 0xFFFFFFBE
    17a1:      	testq	%rax, %rax
    17a4:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    17aa:      	movq	0x1080(%r14), %rax
    17b1:      	movl	$0xffffffc0, %ecx       # imm = 0xFFFFFFC0
    17b6:      	testq	%rax, %rax
    17b9:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    17bf:      	movq	0x1078(%r14), %rax
    17c6:      	movl	$0xffffffc2, %ecx       # imm = 0xFFFFFFC2
    17cb:      	testq	%rax, %rax
    17ce:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    17d4:      	movq	0x1070(%r14), %rax
    17db:      	movl	$0xffffffc4, %ecx       # imm = 0xFFFFFFC4
    17e0:      	testq	%rax, %rax
    17e3:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    17e9:      	movq	0x1068(%r14), %rax
    17f0:      	movl	$0xffffffc6, %ecx       # imm = 0xFFFFFFC6
    17f5:      	testq	%rax, %rax
    17f8:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    17fe:      	movq	0x1060(%r14), %rax
    1805:      	movl	$0xffffffc8, %ecx       # imm = 0xFFFFFFC8
    180a:      	testq	%rax, %rax
    180d:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    1813:      	movq	0x1058(%r14), %rax
    181a:      	movl	$0xffffffca, %ecx       # imm = 0xFFFFFFCA
    181f:      	testq	%rax, %rax
    1822:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    1828:      	movq	0x1050(%r14), %rax
    182f:      	movl	$0xffffffcc, %ecx       # imm = 0xFFFFFFCC
    1834:      	testq	%rax, %rax
    1837:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    183d:      	movq	0x1048(%r14), %rax
    1844:      	movl	$0xffffffce, %ecx       # imm = 0xFFFFFFCE
    1849:      	testq	%rax, %rax
    184c:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    1852:      	movq	0x1040(%r14), %rax
    1859:      	movl	$0xffffffd0, %ecx       # imm = 0xFFFFFFD0
    185e:      	testq	%rax, %rax
    1861:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    1867:      	movq	0x1038(%r14), %rax
    186e:      	movl	$0xffffffd2, %ecx       # imm = 0xFFFFFFD2
    1873:      	testq	%rax, %rax
    1876:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    187c:      	movq	0x1030(%r14), %rax
    1883:      	movl	$0xffffffd4, %ecx       # imm = 0xFFFFFFD4
    1888:      	testq	%rax, %rax
    188b:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    1891:      	movq	0x1028(%r14), %rax
    1898:      	movl	$0xffffffd6, %ecx       # imm = 0xFFFFFFD6
    189d:      	testq	%rax, %rax
    18a0:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    18a6:      	movq	0x1020(%r14), %rax
    18ad:      	movl	$0xffffffd8, %ecx       # imm = 0xFFFFFFD8
    18b2:      	testq	%rax, %rax
    18b5:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    18bb:      	movq	0x1018(%r14), %rax
    18c2:      	movl	$0xffffffda, %ecx       # imm = 0xFFFFFFDA
    18c7:      	testq	%rax, %rax
    18ca:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    18d0:      	movq	0x1010(%r14), %rax
    18d7:      	movl	$0xffffffdc, %ecx       # imm = 0xFFFFFFDC
    18dc:      	testq	%rax, %rax
    18df:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    18e5:      	movq	0x1008(%r14), %rax
    18ec:      	movl	$0xffffffde, %ecx       # imm = 0xFFFFFFDE
    18f1:      	testq	%rax, %rax
    18f4:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    18fa:      	movq	0x1000(%r14), %rax
    1901:      	movl	$0xffffffe0, %ecx       # imm = 0xFFFFFFE0
    1906:      	testq	%rax, %rax
    1909:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    190f:      	movq	0xff8(%r14), %rax
    1916:      	movl	$0xffffffe2, %ecx       # imm = 0xFFFFFFE2
    191b:      	testq	%rax, %rax
    191e:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    1924:      	movq	0xff0(%r14), %rax
    192b:      	movl	$0xffffffe4, %ecx       # imm = 0xFFFFFFE4
    1930:      	testq	%rax, %rax
    1933:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    1939:      	movq	0xfe8(%r14), %rax
    1940:      	movl	$0xffffffe6, %ecx       # imm = 0xFFFFFFE6
    1945:      	testq	%rax, %rax
    1948:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    194e:      	movq	0xfe0(%r14), %rax
    1955:      	movl	$0xffffffe8, %ecx       # imm = 0xFFFFFFE8
    195a:      	testq	%rax, %rax
    195d:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    1963:      	movq	0xfd8(%r14), %rax
    196a:      	movl	$0xffffffea, %ecx       # imm = 0xFFFFFFEA
    196f:      	testq	%rax, %rax
    1972:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    1978:      	movq	0xfd0(%r14), %rax
    197f:      	movl	$0xffffffec, %ecx       # imm = 0xFFFFFFEC
    1984:      	testq	%rax, %rax
    1987:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    198d:      	movq	0xfc8(%r14), %rax
    1994:      	movl	$0xffffffee, %ecx       # imm = 0xFFFFFFEE
    1999:      	testq	%rax, %rax
    199c:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    19a2:      	movq	0xfc0(%r14), %rax
    19a9:      	movl	$0xfffffff0, %ecx       # imm = 0xFFFFFFF0
    19ae:      	testq	%rax, %rax
    19b1:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    19b7:      	movq	0xfb8(%r14), %rax
    19be:      	movl	$0xfffffff2, %ecx       # imm = 0xFFFFFFF2
    19c3:      	testq	%rax, %rax
    19c6:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    19c8:      	movq	0xfb0(%r14), %rax
    19cf:      	movl	$0xfffffff4, %ecx       # imm = 0xFFFFFFF4
    19d4:      	testq	%rax, %rax
    19d7:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    19d9:      	movq	0xfa8(%r14), %rax
    19e0:      	movl	$0xfffffff6, %ecx       # imm = 0xFFFFFFF6
    19e5:      	testq	%rax, %rax
    19e8:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    19ea:      	movq	0xfa0(%r14), %rax
    19f1:      	movl	$0xfffffff8, %ecx       # imm = 0xFFFFFFF8
    19f6:      	testq	%rax, %rax
    19f9:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    19fb:      	movq	0xf98(%r14), %rax
    1a02:      	movl	$0xfffffffa, %ecx       # imm = 0xFFFFFFFA
    1a07:      	testq	%rax, %rax
    1a0a:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    1a0c:      	movq	0xf90(%r14), %rax
    1a13:      	movl	$0xfffffffc, %ecx       # imm = 0xFFFFFFFC
    1a18:      	testq	%rax, %rax
    1a1b:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    1a1d:      	movq	0xf88(%r14), %rax
    1a24:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    1a29:      	testq	%rax, %rax
    1a2c:      	jne	0x1a3b <kprobe_unwind_dotnet+0x1a3b>
    1a2e:      	movq	0x90(%rsp), %rax
    1a36:      	movq	(%rax), %rax
    1a39:      	xorl	%ecx, %ecx
    1a3b:      	xorl	%edx, %edx
    1a3d:      	movq	%rax, %r15
    1a40:      	shrq	$0x20, %r15
    1a44:      	setne	%dl
    1a47:      	cmovel	%eax, %r15d
    1a4b:      	subl	%edx, %ecx
    1a4d:      	addl	$0x7e, %ecx
    1a50:      	movl	%ecx, %eax
    1a52:      	shll	$0x8, %eax
    1a55:      	subq	%rax, %r13
    1a58:      	jb	0x66f <kprobe_unwind_dotnet+0x66f>
    1a5e:      	cmpl	$0x0, (%rbp)
    1a62:      	jne	0x1b44 <kprobe_unwind_dotnet+0x1b44>
    1a68:      	testl	%r15d, %r15d
    1a6b:      	jne	0x4d2 <kprobe_unwind_dotnet+0x4d2>
    1a71:      	movl	$0x5f, 0xc(%rsp)
    1a79:      	movq	(%rip), %rdi            # 0x1a80 <kprobe_unwind_dotnet+0x1a80>
    1a80:      	leaq	0xc(%rsp), %rsi
    1a85:      	movl	$0x1, %eax
    1a8a:      	callq	*%rax
    1a8c:      	movq	%rbx, %r12
    1a8f:      	testq	%rax, %rax
    1a92:      	je	0x1aaf <kprobe_unwind_dotnet+0x1aaf>
    1a94:      	incq	(%rax)
    1a97:      	movq	0x60(%rsp), %r15
    1a9c:      	movl	$0x1773, %edx           # imm = 0x1773
    1aa1:      	movb	$0x1, %bl
    1aa3:      	cmpl	$0x0, (%rbp)
    1aa7:      	je	0x511 <kprobe_unwind_dotnet+0x511>
    1aad:      	jmp	0x1acf <kprobe_unwind_dotnet+0x1acf>
    1aaf:      	cmpl	$0x0, (%rbp)
    1ab3:      	movq	0x60(%rsp), %r15
    1ab8:      	jne	0x21de <kprobe_unwind_dotnet+0x21de>
    1abe:      	movl	$0x1773, %edx           # imm = 0x1773
    1ac3:      	movb	$0x1, %bl
    1ac5:      	cmpl	$0x0, (%rbp)
    1ac9:      	je	0x511 <kprobe_unwind_dotnet+0x511>
    1acf:      	movabsq	$0xa642520687469, %rax  # imm = 0xA642520687469
    1ad9:      	movq	%rax, 0x30(%rsp)
    1ade:      	movabsq	$0x772064656c696166, %rax # imm = 0x772064656C696166
    1ae8:      	movq	%rax, 0x28(%rsp)
    1aed:      	movabsq	$0x2074726174735f65, %rax # imm = 0x2074726174735F65
    1af7:      	movq	%rax, 0x20(%rsp)
    1afc:      	movabsq	$0x646f63203e2d2d20, %rax # imm = 0x646F63203E2D2D20
    1b06:      	movq	%rax, 0x18(%rsp)
    1b0b:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    1b15:      	movq	%rax, 0x10(%rsp)
    1b1a:      	leaq	0x10(%rsp), %rdi
    1b1f:      	movl	$0x28, %eax
    1b24:      	movl	$0x6, %ecx
    1b29:      	movl	$0x28, %esi
    1b2e:      	xorl	%eax, %eax
    1b30:      	callq	*%rcx
    1b32:      	movl	$0x1772, %eax           # imm = 0x1772
    1b37:      	testb	%bl, %bl
    1b39:      	jne	0x51e <kprobe_unwind_dotnet+0x51e>
    1b3f:      	jmp	0x7812 <kprobe_unwind_dotnet+0x7812>
    1b44:      	movabsq	$0x207972746e65202c, %rax # imm = 0x207972746E65202C
    1b4e:      	movq	%rax, 0x40(%rsp)
    1b53:      	movabsq	$0x6425206465707069, %rax # imm = 0x6425206465707069
    1b5d:      	movq	%rax, 0x38(%rsp)
    1b62:      	movabsq	$0x6b73203a786c2520, %rax # imm = 0x6B73203A786C2520
    1b6c:      	movq	%rax, 0x30(%rsp)
    1b71:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    1b7b:      	movq	%rax, 0x28(%rsp)
    1b80:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    1b8a:      	movq	%rax, 0x20(%rsp)
    1b8f:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    1b99:      	movq	%rax, 0x18(%rsp)
    1b9e:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    1ba8:      	movq	%rax, 0x10(%rsp)
    1bad:      	movl	$0xa7825, 0x48(%rsp)    # imm = 0xA7825
    1bb5:      	leaq	0x10(%rsp), %rdi
    1bba:      	movl	$0x3c, %eax
    1bbf:      	movl	$0x6, %r9d
    1bc5:      	movl	$0x3c, %esi
    1bca:      	movq	%r13, %rdx
    1bcd:      	movl	%r15d, %r8d
    1bd0:      	xorl	%eax, %eax
    1bd2:      	callq	*%r9
    1bd5:      	testl	%r15d, %r15d
    1bd8:      	jne	0x4d2 <kprobe_unwind_dotnet+0x4d2>
    1bde:      	jmp	0x1a71 <kprobe_unwind_dotnet+0x1a71>
    1be3:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    1bed:      	movq	%rax, 0x36(%rsp)
    1bf2:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    1bfc:      	movq	%rax, 0x30(%rsp)
    1c01:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    1c0b:      	movq	%rax, 0x28(%rsp)
    1c10:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    1c1a:      	movq	%rax, 0x20(%rsp)
    1c1f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    1c29:      	movq	%rax, 0x18(%rsp)
    1c2e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    1c38:      	movq	%rax, 0x10(%rsp)
    1c3d:      	leaq	0x10(%rsp), %rdi
    1c42:      	movl	$0x2e, %eax
    1c47:      	movl	$0x6, %ecx
    1c4c:      	movl	0xc(%rsp), %edx
    1c50:      	movl	$0x2e, %esi
    1c55:      	xorl	%eax, %eax
    1c57:      	callq	*%rcx
    1c59:      	jmp	0xc65 <kprobe_unwind_dotnet+0xc65>
    1c5e:      	movabsq	$0xa642520686374, %rcx  # imm = 0xA642520686374
    1c68:      	movq	%rcx, 0x26(%rsp)
    1c6d:      	movabsq	$0x6374616d20737465, %rcx # imm = 0x6374616D20737465
    1c77:      	movq	%rcx, 0x20(%rsp)
    1c7c:      	movabsq	$0x7366666f5f726574, %rcx # imm = 0x7366666F5F726574
    1c86:      	movq	%rcx, 0x18(%rsp)
    1c8b:      	movabsq	$0x6572707265746e69, %rcx # imm = 0x6572707265746E69
    1c95:      	movq	%rcx, 0x10(%rsp)
    1c9a:      	leaq	0x10(%rsp), %rdi
    1c9f:      	movl	$0x1e, %ecx
    1ca4:      	movl	$0x6, %r8d
    1caa:      	movzwl	0x20(%rax), %edx
    1cae:      	movl	$0x1e, %esi
    1cb3:      	movq	%rax, %rbx
    1cb6:      	xorl	%eax, %eax
    1cb8:      	callq	*%r8
    1cbb:      	movq	%rbx, %rax
    1cbe:      	movl	0x1380(%r14), %ecx
    1cc5:      	movl	0x20(%rax), %edx
    1cc8:      	btl	%edx, %ecx
    1ccb:      	jb	0xfd7 <kprobe_unwind_dotnet+0xfd7>
    1cd1:      	movq	%rax, %rbx
    1cd4:      	movl	$0x0, 0x68(%rsp)
    1cdc:      	movq	(%rip), %rdi            # 0x1ce3 <kprobe_unwind_dotnet+0x1ce3>
    1ce3:      	leaq	0x68(%rsp), %rsi
    1ce8:      	movl	$0x1, %eax
    1ced:      	callq	*%rax
    1cef:      	testq	%rax, %rax
    1cf2:      	je	0x1cfc <kprobe_unwind_dotnet+0x1cfc>
    1cf4:      	incq	(%rax)
    1cf7:      	movq	%rbx, %rax
    1cfa:      	jmp	0x1d09 <kprobe_unwind_dotnet+0x1d09>
    1cfc:      	cmpl	$0x0, (%rbp)
    1d00:      	movq	%rbx, %rax
    1d03:      	jne	0x2353 <kprobe_unwind_dotnet+0x2353>
    1d09:      	movzwl	0x20(%rax), %r12d
    1d0e:      	xorl	%eax, %eax
    1d10:      	cmpl	$0x8, %r12d
    1d14:      	jne	0x7815 <kprobe_unwind_dotnet+0x7815>
    1d1a:      	movq	0xed0(%r14), %r12
    1d21:      	movq	0xed8(%r14), %rbx
    1d28:      	movq	0xee0(%r14), %r13
    1d2f:      	movzbl	0xf30(%r14), %ecx
    1d37:      	cmpl	$0x0, (%rbp)
    1d3b:      	jne	0x2136 <kprobe_unwind_dotnet+0x2136>
    1d41:      	cmpq	%rbx, %r13
    1d44:      	jb	0x77c0 <kprobe_unwind_dotnet+0x77c0>
    1d4a:      	leaq	0x2000(%rbx), %rax
    1d51:      	cmpq	%rax, %r13
    1d54:      	jae	0x77c0 <kprobe_unwind_dotnet+0x77c0>
    1d5a:      	movl	%ecx, %ebx
    1d5c:      	movq	0xf10(%r14), %rbp
    1d63:      	movq	0xf20(%r14), %r15
    1d6a:      	movq	%r12, 0x68(%rsp)
    1d6f:      	movb	$0x1, 0xf30(%r14)
    1d77:      	movq	%rbp, %rax
    1d7a:      	andq	$-0x80, %rax
    1d7e:      	cmpq	$0x80, %rax
    1d84:      	jne	0x1dc8 <kprobe_unwind_dotnet+0x1dc8>
    1d86:      	movq	0xed8(%r14), %rax
    1d8d:      	movl	$0x8, %ecx
    1d92:      	movl	$0x70, %r8d
    1d98:      	movq	0x98(%rsp), %rdi
    1da0:      	movq	0xed8(%r14), %rdx
    1da7:      	movl	$0x8, %esi
    1dac:      	callq	*%r8
    1daf:      	testq	%rax, %rax
    1db2:      	jne	0x19c <kprobe_unwind_dotnet+0x19c>
    1db8:      	addq	$0x8, 0xed8(%r14)
    1dc0:      	andl	$0x7f, %ebp
    1dc3:      	jmp	0x2431 <kprobe_unwind_dotnet+0x2431>
    1dc8:      	leaq	0x70(%rsp), %rdi
    1dcd:      	movl	$0x10, %eax
    1dd2:      	movl	$0x70, %ecx
    1dd7:      	movl	$0x10, %esi
    1ddc:      	movq	%r13, %rdx
    1ddf:      	callq	*%rcx
    1de1:      	testq	%rax, %rax
    1de4:      	jne	0x26c <kprobe_unwind_dotnet+0x26c>
    1dea:      	addq	$0x10, %r13
    1dee:      	movq	%r13, 0xed8(%r14)
    1df5:      	movq	0x70(%rsp), %rax
    1dfa:      	movq	%rax, 0xee0(%r14)
    1e01:      	movq	0x78(%rsp), %rax
    1e06:      	movq	%rax, 0xed0(%r14)
    1e0d:      	movq	(%rip), %rax            # 0x1e14 <kprobe_unwind_dotnet+0x1e14>
    1e14:      	cmpl	$0x0, (%rax)
    1e17:      	jne	0x226a <kprobe_unwind_dotnet+0x226a>
    1e1d:      	cmpq	$0x100, %rbp            # imm = 0x100
    1e24:      	jb	0x2431 <kprobe_unwind_dotnet+0x2431>
    1e2a:      	movq	0xf10(%r14), %rbp
    1e31:      	movq	0xf20(%r14), %rax
    1e38:      	movq	%r12, %r13
    1e3b:      	movq	%rax, 0x88(%rsp)
    1e43:      	subq	%rax, %r13
    1e46:      	movq	(%rip), %rax            # 0x1e4d <kprobe_unwind_dotnet+0x1e4d>
    1e4d:      	cmpl	$0x0, (%rax)
    1e50:      	jne	0x230a <kprobe_unwind_dotnet+0x230a>
    1e56:      	movq	%r13, %r15
    1e59:      	andq	$-0x4, %r15
    1e5d:      	movl	$0x100, %ecx            # imm = 0x100
    1e62:      	movq	%r15, %rax
    1e65:      	xorl	%edx, %edx
    1e67:      	divq	%rcx
    1e6a:      	movq	%rax, %rcx
    1e6d:      	movl	$0x7f, %eax
    1e72:      	subq	%rcx, %rax
    1e75:      	jns	0x1e8e <kprobe_unwind_dotnet+0x1e8e>
    1e77:      	movl	$0x100, %ecx            # imm = 0x100
    1e7c:      	movq	%r15, %rax
    1e7f:      	xorl	%edx, %edx
    1e81:      	divq	%rcx
    1e84:      	leaq	-0x3fc(%rbp,%rax,4), %rbp
    1e8c:      	xorl	%eax, %eax
    1e8e:      	movl	$0x80, %ecx
    1e93:      	cqto
    1e95:      	idivq	%rcx
    1e98:      	movq	0x90(%rsp), %rax
    1ea0:      	leaq	(%rax,%rdx,4), %rdi
    1ea4:      	movl	$0x200, %eax            # imm = 0x200
    1ea9:      	movl	$0x70, %ecx
    1eae:      	movl	$0x200, %esi            # imm = 0x200
    1eb3:      	movq	%rbp, %rdx
    1eb6:      	callq	*%rcx
    1eb8:      	testq	%rax, %rax
    1ebb:      	je	0x1ef2 <kprobe_unwind_dotnet+0x1ef2>
    1ebd:      	movq	(%rip), %rax            # 0x1ec4 <kprobe_unwind_dotnet+0x1ec4>
    1ec4:      	cmpl	$0x0, (%rax)
    1ec7:      	jne	0x20c7 <kprobe_unwind_dotnet+0x20c7>
    1ecd:      	movl	$0x5e, 0xc(%rsp)
    1ed5:      	movq	(%rip), %rdi            # 0x1edc <kprobe_unwind_dotnet+0x1edc>
    1edc:      	leaq	0xc(%rsp), %rsi
    1ee1:      	movl	$0x1, %eax
    1ee6:      	callq	*%rax
    1ee8:      	testq	%rax, %rax
    1eeb:      	je	0x1f5d <kprobe_unwind_dotnet+0x1f5d>
    1eed:      	incq	(%rax)
    1ef0:      	jmp	0x1f6d <kprobe_unwind_dotnet+0x1f6d>
    1ef2:      	movl	0x117c(%r14), %ebp
    1ef9:      	movq	(%rip), %rax            # 0x1f00 <kprobe_unwind_dotnet+0x1f00>
    1f00:      	cmpl	$0x0, (%rax)
    1f03:      	jne	0x28ff <kprobe_unwind_dotnet+0x28ff>
    1f09:      	movl	$0x20, %ecx
    1f0e:      	movq	%r15, %rax
    1f11:      	xorl	%edx, %edx
    1f13:      	divq	%rcx
    1f16:      	movl	$0x8, %ecx
    1f1b:      	xorl	%edx, %edx
    1f1d:      	divq	%rcx
    1f20:      	shll	$0x2, %edx
    1f23:      	movb	$0x1c, %al
    1f25:      	subb	%dl, %al
    1f27:      	shrxl	%eax, %ebp, %r15d
    1f2c:      	testl	%r15d, %r15d
    1f2f:      	je	0x1ffa <kprobe_unwind_dotnet+0x1ffa>
    1f35:      	andq	$-0x20, %r13
    1f39:      	movl	%r15d, %ecx
    1f3c:      	andl	$0xf, %ecx
    1f3f:      	jne	0x23dc <kprobe_unwind_dotnet+0x23dc>
    1f45:      	movl	%r15d, %ecx
    1f48:      	shrl	$0x4, %ecx
    1f4b:      	andl	$0xf, %ecx
    1f4e:      	je	0x210a <kprobe_unwind_dotnet+0x210a>
    1f54:      	addq	$-0x20, %r13
    1f58:      	jmp	0x23dc <kprobe_unwind_dotnet+0x23dc>
    1f5d:      	movq	(%rip), %rax            # 0x1f64 <kprobe_unwind_dotnet+0x1f64>
    1f64:      	cmpl	$0x0, (%rax)
    1f67:      	jne	0x2a0b <kprobe_unwind_dotnet+0x2a0b>
    1f6d:      	movl	$0x1772, %edx           # imm = 0x1772
    1f72:      	xorl	%ebx, %ebx
    1f74:      	movq	(%rip), %rax            # 0x1f7b <kprobe_unwind_dotnet+0x1f7b>
    1f7b:      	cmpl	$0x0, (%rax)
    1f7e:      	jne	0x31be <kprobe_unwind_dotnet+0x31be>
    1f84:      	movl	$0x1772, %eax           # imm = 0x1772
    1f89:      	testb	%bl, %bl
    1f8b:      	movq	0x60(%rsp), %r15
    1f90:      	movq	(%rip), %rbp            # 0x1f97 <kprobe_unwind_dotnet+0x1f97>
    1f97:      	je	0x7812 <kprobe_unwind_dotnet+0x7812>
    1f9d:      	movl	0x2c0(%r14), %eax
    1fa4:      	cmpq	$0x7e, %rax
    1fa8:      	ja	0x52f <kprobe_unwind_dotnet+0x52f>
    1fae:      	leal	0x1(%rax), %ecx
    1fb1:      	movl	%ecx, 0x2c0(%r14)
    1fb8:      	leaq	(%rax,%rax,2), %rax
    1fbc:      	movq	$0x0, 0x2d0(%r14,%rax,8)
    1fc8:      	movq	$0x1773, 0x2d8(%r14,%rax,8) # imm = 0x1773
    1fd4:      	movb	$-0x76, 0x2e0(%r14,%rax,8)
    1fdd:      	movl	$0x0, 0x2e1(%r14,%rax,8)
    1fe9:      	movl	$0x0, 0x2e4(%r14,%rax,8)
    1ff5:      	jmp	0x24e4 <kprobe_unwind_dotnet+0x24e4>
    1ffa:      	andq	$-0x100, %r13
    2001:      	addq	$-0x20, %r13
    2005:      	movl	0x1178(%r14), %r15d
    200c:      	movq	(%rip), %rax            # 0x2013 <kprobe_unwind_dotnet+0x2013>
    2013:      	cmpl	$0x0, (%rax)
    2016:      	jne	0x2b9b <kprobe_unwind_dotnet+0x2b9b>
    201c:      	xorl	%ecx, %ecx
    201e:      	testl	%r15d, %r15d
    2021:      	je	0x2c2f <kprobe_unwind_dotnet+0x2c2f>
    2027:      	movl	%ecx, %eax
    2029:      	shll	$0x8, %eax
    202c:      	subq	%rax, %r13
    202f:      	jae	0x3159 <kprobe_unwind_dotnet+0x3159>
    2035:      	movq	(%rip), %rax            # 0x203c <kprobe_unwind_dotnet+0x203c>
    203c:      	cmpl	$0x0, (%rax)
    203f:      	je	0x1ecd <kprobe_unwind_dotnet+0x1ecd>
    2045:      	movabsq	$0xa657361625f63, %rax  # imm = 0xA657361625F63
    204f:      	movq	%rax, 0x36(%rsp)
    2054:      	movabsq	$0x5f637020776f6c65, %rax # imm = 0x5F637020776F6C65
    205e:      	movq	%rax, 0x30(%rsp)
    2063:      	movabsq	$0x6220746e65772068, %rax # imm = 0x6220746E65772068
    206d:      	movq	%rax, 0x28(%rsp)
    2072:      	movabsq	$0x6372616573207061, %rax # imm = 0x6372616573207061
    207c:      	movq	%rax, 0x20(%rsp)
    2081:      	movabsq	$0x6d20656c6262696e, %rax # imm = 0x6D20656C6262696E
    208b:      	movq	%rax, 0x18(%rsp)
    2090:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    209a:      	movq	%rax, 0x10(%rsp)
    209f:      	leaq	0x10(%rsp), %rdi
    20a4:      	movl	$0x2e, %eax
    20a9:      	movl	$0x6, %ecx
    20ae:      	movl	$0x2e, %esi
    20b3:      	xorl	%eax, %eax
    20b5:      	callq	*%rcx
    20b7:      	movq	(%rip), %rax            # 0x20be <kprobe_unwind_dotnet+0x20be>
    20be:      	cmpl	$0x0, (%rax)
    20c1:      	je	0x1ecd <kprobe_unwind_dotnet+0x1ecd>
    20c7:      	movabsq	$0x6e756f6620746f6e, %rax # imm = 0x6E756F6620746F6E
    20d1:      	movq	%rax, 0x18(%rsp)
    20d6:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    20e0:      	movq	%rax, 0x10(%rsp)
    20e5:      	movl	$0xa646e, 0x1f(%rsp)    # imm = 0xA646E
    20ed:      	leaq	0x10(%rsp), %rdi
    20f2:      	movl	$0x13, %eax
    20f7:      	movl	$0x6, %ecx
    20fc:      	movl	$0x13, %esi
    2101:      	xorl	%eax, %eax
    2103:      	callq	*%rcx
    2105:      	jmp	0x1ecd <kprobe_unwind_dotnet+0x1ecd>
    210a:      	movl	%r15d, %ecx
    210d:      	shrl	$0x8, %ecx
    2110:      	andl	$0xf, %ecx
    2113:      	je	0x211e <kprobe_unwind_dotnet+0x211e>
    2115:      	addq	$-0x40, %r13
    2119:      	jmp	0x23dc <kprobe_unwind_dotnet+0x23dc>
    211e:      	movl	%r15d, %ecx
    2121:      	shrl	$0xc, %ecx
    2124:      	andl	$0xf, %ecx
    2127:      	je	0x21af <kprobe_unwind_dotnet+0x21af>
    212d:      	addq	$-0x60, %r13
    2131:      	jmp	0x23dc <kprobe_unwind_dotnet+0x23dc>
    2136:      	movabsq	$0x6c25203a7066202c, %rax # imm = 0x6C25203A7066202C
    2140:      	movq	%rax, 0x28(%rsp)
    2145:      	movabsq	$0x786c25203a707320, %rax # imm = 0x786C25203A707320
    214f:      	movq	%rax, 0x20(%rsp)
    2154:      	movabsq	$0x2c786c25203a6370, %rax # imm = 0x2C786C25203A6370
    215e:      	movq	%rax, 0x18(%rsp)
    2163:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    216d:      	movq	%rax, 0x10(%rsp)
    2172:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    217a:      	leaq	0x10(%rsp), %rdi
    217f:      	movl	$0x23, %eax
    2184:      	movl	$0x6, %r9d
    218a:      	movl	$0x23, %esi
    218f:      	movq	%r12, %rdx
    2192:      	movl	%ecx, %ebp
    2194:      	movq	%rbx, %rcx
    2197:      	movq	%r13, %r8
    219a:      	xorl	%eax, %eax
    219c:      	callq	*%r9
    219f:      	movl	%ebp, %ecx
    21a1:      	cmpq	%rbx, %r13
    21a4:      	jae	0x1d4a <kprobe_unwind_dotnet+0x1d4a>
    21aa:      	jmp	0x77c0 <kprobe_unwind_dotnet+0x77c0>
    21af:      	movl	%r15d, %ecx
    21b2:      	shrl	$0x10, %ecx
    21b5:      	andl	$0xf, %ecx
    21b8:      	je	0x21c3 <kprobe_unwind_dotnet+0x21c3>
    21ba:      	addq	$-0x80, %r13
    21be:      	jmp	0x23dc <kprobe_unwind_dotnet+0x23dc>
    21c3:      	movl	%r15d, %ecx
    21c6:      	shrl	$0x14, %ecx
    21c9:      	andl	$0xf, %ecx
    21cc:      	je	0x22ef <kprobe_unwind_dotnet+0x22ef>
    21d2:      	addq	$-0xa0, %r13
    21d9:      	jmp	0x23dc <kprobe_unwind_dotnet+0x23dc>
    21de:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    21e8:      	movq	%rax, 0x36(%rsp)
    21ed:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    21f7:      	movq	%rax, 0x30(%rsp)
    21fc:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2206:      	movq	%rax, 0x28(%rsp)
    220b:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2215:      	movq	%rax, 0x20(%rsp)
    221a:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2224:      	movq	%rax, 0x18(%rsp)
    2229:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2233:      	movq	%rax, 0x10(%rsp)
    2238:      	leaq	0x10(%rsp), %rdi
    223d:      	movl	$0x2e, %eax
    2242:      	movl	$0x6, %ecx
    2247:      	movl	0xc(%rsp), %edx
    224b:      	movl	$0x2e, %esi
    2250:      	xorl	%eax, %eax
    2252:      	callq	*%rcx
    2254:      	movl	$0x1773, %edx           # imm = 0x1773
    2259:      	movb	$0x1, %bl
    225b:      	cmpl	$0x0, (%rbp)
    225f:      	je	0x511 <kprobe_unwind_dotnet+0x511>
    2265:      	jmp	0x1acf <kprobe_unwind_dotnet+0x1acf>
    226a:      	movabsq	$0x6c25203a7066202c, %rax # imm = 0x6C25203A7066202C
    2274:      	movq	%rax, 0x28(%rsp)
    2279:      	movabsq	$0x786c25203a707320, %rax # imm = 0x786C25203A707320
    2283:      	movq	%rax, 0x20(%rsp)
    2288:      	movabsq	$0x2c786c25203a6370, %rax # imm = 0x2C786C25203A6370
    2292:      	movq	%rax, 0x18(%rsp)
    2297:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    22a1:      	movq	%rax, 0x10(%rsp)
    22a6:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    22ae:      	leaq	0x10(%rsp), %rdi
    22b3:      	movl	$0x23, %eax
    22b8:      	movl	$0x6, %r9d
    22be:      	movq	0xed0(%r14), %rdx
    22c5:      	movq	0xed8(%r14), %rcx
    22cc:      	movq	0xee0(%r14), %r8
    22d3:      	movl	$0x23, %esi
    22d8:      	xorl	%eax, %eax
    22da:      	callq	*%r9
    22dd:      	cmpq	$0x100, %rbp            # imm = 0x100
    22e4:      	jae	0x1e2a <kprobe_unwind_dotnet+0x1e2a>
    22ea:      	jmp	0x2431 <kprobe_unwind_dotnet+0x2431>
    22ef:      	movl	%r15d, %ecx
    22f2:      	shrl	$0x18, %ecx
    22f5:      	andl	$0xf, %ecx
    22f8:      	je	0x23ce <kprobe_unwind_dotnet+0x23ce>
    22fe:      	addq	$-0xc0, %r13
    2305:      	jmp	0x23dc <kprobe_unwind_dotnet+0x23dc>
    230a:      	leaq	(%rip), %rsi            # 0x2311 <kprobe_unwind_dotnet+0x2311>
    2311:      	leaq	0x10(%rsp), %rax
    2316:      	movl	$0x8, %ecx
    231b:      	movq	%rax, %rdi
    231e:      	rep		movsq	(%rsi), %es:(%rdi)
    2321:      	movw	$0xa, 0x50(%rsp)
    2328:      	movl	$0x42, %ecx
    232d:      	movl	$0x6, %r9d
    2333:      	movq	%rax, %rdi
    2336:      	movl	$0x42, %esi
    233b:      	movq	%r13, %rdx
    233e:      	movq	0x88(%rsp), %rcx
    2346:      	movq	%rbp, %r8
    2349:      	xorl	%eax, %eax
    234b:      	callq	*%r9
    234e:      	jmp	0x1e56 <kprobe_unwind_dotnet+0x1e56>
    2353:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    235d:      	movq	%rax, 0x36(%rsp)
    2362:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    236c:      	movq	%rax, 0x30(%rsp)
    2371:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    237b:      	movq	%rax, 0x28(%rsp)
    2380:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    238a:      	movq	%rax, 0x20(%rsp)
    238f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2399:      	movq	%rax, 0x18(%rsp)
    239e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    23a8:      	movq	%rax, 0x10(%rsp)
    23ad:      	leaq	0x10(%rsp), %rdi
    23b2:      	movl	$0x2e, %eax
    23b7:      	movl	$0x6, %ecx
    23bc:      	movl	0x68(%rsp), %edx
    23c0:      	movl	$0x2e, %esi
    23c5:      	xorl	%eax, %eax
    23c7:      	callq	*%rcx
    23c9:      	jmp	0x1cf7 <kprobe_unwind_dotnet+0x1cf7>
    23ce:      	shrl	$0x1c, %r15d
    23d2:      	addq	$-0xe0, %r13
    23d9:      	movl	%r15d, %ecx
    23dc:      	movq	0x88(%rsp), %rax
    23e4:      	addq	%r13, %rax
    23e7:      	leal	-0x4(,%rcx,4), %r15d
    23ef:      	addq	%rax, %r15
    23f2:      	movq	(%rip), %rax            # 0x23f9 <kprobe_unwind_dotnet+0x23f9>
    23f9:      	cmpl	$0x0, (%rax)
    23fc:      	jne	0x298c <kprobe_unwind_dotnet+0x298c>
    2402:      	leaq	-0x8(%r15), %rdx
    2406:      	leaq	0x68(%rsp), %rdi
    240b:      	movl	$0x8, %eax
    2410:      	movl	$0x70, %ecx
    2415:      	movl	$0x8, %esi
    241a:      	callq	*%rcx
    241c:      	testq	%rax, %rax
    241f:      	movq	(%rip), %rbp            # 0x2426 <kprobe_unwind_dotnet+0x2426>
    2426:      	jne	0xbb6 <kprobe_unwind_dotnet+0xbb6>
    242c:      	movl	$0x1f, %ebp
    2431:      	movq	(%rip), %rax            # 0x2438 <kprobe_unwind_dotnet+0x2438>
    2438:      	cmpl	$0x0, (%rax)
    243b:      	jne	0x25b1 <kprobe_unwind_dotnet+0x25b1>
    2441:      	movl	0x2c0(%r14), %eax
    2448:      	cmpq	$0x7e, %rax
    244c:      	ja	0xc0c <kprobe_unwind_dotnet+0xc0c>
    2452:      	movq	0x68(%rsp), %rcx
    2457:      	subq	%r15, %r12
    245a:      	shlq	$0x5, %rcx
    245e:      	addq	%rbp, %rcx
    2461:      	leal	0x1(%rax), %edx
    2464:      	movl	%edx, 0x2c0(%r14)
    246b:      	leaq	(%rax,%rax,2), %rax
    246f:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    2477:      	movq	%r12, 0x2d8(%r14,%rax,8)
    247f:      	movb	$0xa, 0x2e0(%r14,%rax,8)
    2488:      	movb	%bl, 0x2e1(%r14,%rax,8)
    2490:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    249c:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    24a7:      	movl	$0x5b, 0xc(%rsp)
    24af:      	movq	(%rip), %rdi            # 0x24b6 <kprobe_unwind_dotnet+0x24b6>
    24b6:      	leaq	0xc(%rsp), %rsi
    24bb:      	movl	$0x1, %eax
    24c0:      	callq	*%rax
    24c2:      	testq	%rax, %rax
    24c5:      	je	0x24d3 <kprobe_unwind_dotnet+0x24d3>
    24c7:      	incq	(%rax)
    24ca:      	movq	(%rip), %rbp            # 0x24d1 <kprobe_unwind_dotnet+0x24d1>
    24d1:      	jmp	0x24e4 <kprobe_unwind_dotnet+0x24e4>
    24d3:      	movq	(%rip), %rbp            # 0x24da <kprobe_unwind_dotnet+0x24da>
    24da:      	cmpl	$0x0, (%rbp)
    24de:      	jne	0x2884 <kprobe_unwind_dotnet+0x2884>
    24e4:      	movq	0x98(%rsp), %rax
    24ec:      	movq	(%rax), %r13
    24ef:      	movl	(%rbp), %eax
    24f2:      	testq	%r13, %r13
    24f5:      	je	0x258f <kprobe_unwind_dotnet+0x258f>
    24fb:      	testl	%eax, %eax
    24fd:      	jne	0x2610 <kprobe_unwind_dotnet+0x2610>
    2503:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    250d:      	cmpq	%rax, %r13
    2510:      	jbe	0x26a8 <kprobe_unwind_dotnet+0x26a8>
    2516:      	movq	0x60(%rsp), %r15
    251b:      	movq	(%rip), %rbp            # 0x2522 <kprobe_unwind_dotnet+0x2522>
    2522:      	cmpl	$0x0, (%rbp)
    2526:      	je	0xda9 <kprobe_unwind_dotnet+0xda9>
    252c:      	movabsq	$0x7373657264646120, %rax # imm = 0x7373657264646120
    2536:      	movq	%rax, 0x28(%rsp)
    253b:      	movabsq	$0x6c656e72656b2061, %rax # imm = 0x6C656E72656B2061
    2545:      	movq	%rax, 0x20(%rsp)
    254a:      	movabsq	$0x20736920786c2520, %rax # imm = 0x20736920786C2520
    2554:      	movq	%rax, 0x18(%rsp)
    2559:      	movabsq	$0x65756c6176204350, %rax # imm = 0x65756C6176204350
    2563:      	movq	%rax, 0x10(%rsp)
    2568:      	movw	$0xa, 0x30(%rsp)
    256f:      	leaq	0x10(%rsp), %rdi
    2574:      	movl	$0x22, %eax
    2579:      	movl	$0x6, %ecx
    257e:      	movl	$0x22, %esi
    2583:      	movq	%r13, %rdx
    2586:      	xorl	%eax, %eax
    2588:      	callq	*%rcx
    258a:      	jmp	0xda9 <kprobe_unwind_dotnet+0xda9>
    258f:      	movq	0x60(%rsp), %r15
    2594:      	testl	%eax, %eax
    2596:      	jne	0x8900 <kprobe_unwind_dotnet+0x8900>
    259c:      	movl	$0x1, 0xf28(%r14)
    25a7:      	movl	$0xfad, %eax            # imm = 0xFAD
    25ac:      	jmp	0x7812 <kprobe_unwind_dotnet+0x7812>
    25b1:      	leaq	(%rip), %rsi            # 0x25b8 <kprobe_unwind_dotnet+0x25b8>
    25b8:      	leaq	0x10(%rsp), %rax
    25bd:      	movl	$0x8, %ecx
    25c2:      	movq	%rax, %rdi
    25c5:      	rep		movsq	(%rsi), %es:(%rdi)
    25c8:      	movb	$0x0, 0x52(%rsp)
    25cd:      	movw	$0xa78, 0x50(%rsp)      # imm = 0xA78
    25d4:      	movl	$0x43, %ecx
    25d9:      	movl	$0x6, %r9d
    25df:      	movq	0x68(%rsp), %rcx
    25e4:      	movq	%r12, %r8
    25e7:      	subq	%r15, %r8
    25ea:      	movq	%rax, %rdi
    25ed:      	movl	$0x43, %esi
    25f2:      	movq	%r15, %rdx
    25f5:      	xorl	%eax, %eax
    25f7:      	callq	*%r9
    25fa:      	movl	0x2c0(%r14), %eax
    2601:      	cmpq	$0x7e, %rax
    2605:      	ja	0xc0c <kprobe_unwind_dotnet+0xc0c>
    260b:      	jmp	0x2452 <kprobe_unwind_dotnet+0x2452>
    2610:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    261a:      	movq	%rax, 0x38(%rsp)
    261f:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    2629:      	movq	%rax, 0x30(%rsp)
    262e:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    2638:      	movq	%rax, 0x28(%rsp)
    263d:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    2647:      	movq	%rax, 0x20(%rsp)
    264c:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    2656:      	movq	%rax, 0x18(%rsp)
    265b:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    2665:      	movq	%rax, 0x10(%rsp)
    266a:      	movb	$0x0, 0x40(%rsp)
    266f:      	leaq	0x10(%rsp), %rdi
    2674:      	movl	$0x31, %eax
    2679:      	movl	$0x6, %ecx
    267e:      	movl	0x2c0(%r14), %edx
    2685:      	movl	$0x31, %esi
    268a:      	xorl	%eax, %eax
    268c:      	callq	*%rcx
    268e:      	movq	0xed0(%r14), %r13
    2695:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    269f:      	cmpq	%rax, %r13
    26a2:      	ja	0x2516 <kprobe_unwind_dotnet+0x2516>
    26a8:      	cmpq	$0x1000, %r13           # imm = 0x1000
    26af:      	jae	0x2723 <kprobe_unwind_dotnet+0x2723>
    26b1:      	movq	0x60(%rsp), %r15
    26b6:      	movq	(%rip), %rbp            # 0x26bd <kprobe_unwind_dotnet+0x26bd>
    26bd:      	cmpl	$0x0, (%rbp)
    26c1:      	je	0xecb <kprobe_unwind_dotnet+0xecb>
    26c7:      	movabsq	$0xa676e69726f6e, %rax  # imm = 0xA676E69726F6E
    26d1:      	movq	%rax, 0x26(%rsp)
    26d6:      	movabsq	$0x6f6e6769202c786c, %rax # imm = 0x6F6E6769202C786C
    26e0:      	movq	%rax, 0x20(%rsp)
    26e5:      	movabsq	$0x252065756c617620, %rax # imm = 0x252065756C617620
    26ef:      	movq	%rax, 0x18(%rsp)
    26f4:      	movabsq	$0x6370206c6c616d73, %rax # imm = 0x6370206C6C616D73
    26fe:      	movq	%rax, 0x10(%rsp)
    2703:      	leaq	0x10(%rsp), %rdi
    2708:      	movl	$0x1e, %eax
    270d:      	movl	$0x6, %ecx
    2712:      	movl	$0x1e, %esi
    2717:      	movq	%r13, %rdx
    271a:      	xorl	%eax, %eax
    271c:      	callq	*%rcx
    271e:      	jmp	0xecb <kprobe_unwind_dotnet+0xecb>
    2723:      	movl	(%r14), %eax
    2726:      	movl	$0x60, 0x70(%rsp)
    272e:      	movbel	%eax, 0x74(%rsp)
    2734:      	movbeq	%r13, 0x78(%rsp)
    273b:      	movq	(%rip), %rdi            # 0x2742 <kprobe_unwind_dotnet+0x2742>
    2742:      	leaq	0x70(%rsp), %rsi
    2747:      	movl	$0x1, %eax
    274c:      	callq	*%rax
    274e:      	testq	%rax, %rax
    2751:      	je	0x8837 <kprobe_unwind_dotnet+0x8837>
    2757:      	movq	0x8(%rax), %r12
    275b:      	movq	%r12, %rcx
    275e:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    2768:      	andq	%rdx, %rcx
    276b:      	movq	%rcx, 0xf20(%r14)
    2772:      	movq	(%rax), %rax
    2775:      	movq	%rax, 0xf10(%r14)
    277c:      	shrq	$0x38, %r12
    2780:      	movq	%r13, %rax
    2783:      	subq	%rcx, %rax
    2786:      	movq	%rax, 0xf18(%r14)
    278d:      	movq	(%rip), %rax            # 0x2794 <kprobe_unwind_dotnet+0x2794>
    2794:      	cmpl	$0x0, (%rax)
    2797:      	jne	0x2a86 <kprobe_unwind_dotnet+0x2a86>
    279d:      	cmpl	$0x1, %r12d
    27a1:      	jne	0x336c <kprobe_unwind_dotnet+0x336c>
    27a7:      	movq	0xf10(%r14), %rax
    27ae:      	movq	%rax, 0x70(%rsp)
    27b3:      	movq	0xf18(%r14), %rbx
    27ba:      	movq	(%rip), %rdi            # 0x27c1 <kprobe_unwind_dotnet+0x27c1>
    27c1:      	leaq	0x70(%rsp), %rsi
    27c6:      	movl	$0x1, %eax
    27cb:      	callq	*%rax
    27cd:      	movl	$0x1, %r12d
    27d3:      	testq	%rax, %rax
    27d6:      	je	0x336c <kprobe_unwind_dotnet+0x336c>
    27dc:      	movq	%rax, %r15
    27df:      	cmpq	%rbx, (%rax)
    27e2:      	ja	0x27ea <kprobe_unwind_dotnet+0x27ea>
    27e4:      	cmpq	%rbx, 0x8(%r15)
    27e8:      	jae	0x27fe <kprobe_unwind_dotnet+0x27fe>
    27ea:      	cmpq	%rbx, 0x10(%r15)
    27ee:      	ja	0x336c <kprobe_unwind_dotnet+0x336c>
    27f4:      	cmpq	%rbx, 0x18(%r15)
    27f8:      	jb	0x336c <kprobe_unwind_dotnet+0x336c>
    27fe:      	movq	(%rip), %rax            # 0x2805 <kprobe_unwind_dotnet+0x2805>
    2805:      	cmpl	$0x0, (%rax)
    2808:      	jne	0x32c5 <kprobe_unwind_dotnet+0x32c5>
    280e:      	movl	0x1380(%r14), %eax
    2815:      	movl	0x20(%r15), %ecx
    2819:      	btl	%ecx, %eax
    281c:      	jae	0x3332 <kprobe_unwind_dotnet+0x3332>
    2822:      	movq	(%rip), %rax            # 0x2829 <kprobe_unwind_dotnet+0x2829>
    2829:      	cmpl	$0x0, (%rax)
    282c:      	je	0x336c <kprobe_unwind_dotnet+0x336c>
    2832:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    283c:      	movq	%rax, 0x20(%rsp)
    2841:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    284b:      	movq	%rax, 0x18(%rsp)
    2850:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    285a:      	movq	%rax, 0x10(%rsp)
    285f:      	movl	$0xa656e, 0x27(%rsp)    # imm = 0xA656E
    2867:      	leaq	0x10(%rsp), %rdi
    286c:      	movl	$0x1b, %eax
    2871:      	movl	$0x6, %ecx
    2876:      	movl	$0x1b, %esi
    287b:      	xorl	%eax, %eax
    287d:      	callq	*%rcx
    287f:      	jmp	0x336c <kprobe_unwind_dotnet+0x336c>
    2884:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    288e:      	movq	%rax, 0x36(%rsp)
    2893:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    289d:      	movq	%rax, 0x30(%rsp)
    28a2:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    28ac:      	movq	%rax, 0x28(%rsp)
    28b1:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    28bb:      	movq	%rax, 0x20(%rsp)
    28c0:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    28ca:      	movq	%rax, 0x18(%rsp)
    28cf:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    28d9:      	movq	%rax, 0x10(%rsp)
    28de:      	leaq	0x10(%rsp), %rdi
    28e3:      	movl	$0x2e, %eax
    28e8:      	movl	$0x6, %ecx
    28ed:      	movl	0xc(%rsp), %edx
    28f1:      	movl	$0x2e, %esi
    28f6:      	xorl	%eax, %eax
    28f8:      	callq	*%rcx
    28fa:      	jmp	0x24e4 <kprobe_unwind_dotnet+0x24e4>
    28ff:      	movabsq	$0xa782520797274, %rax  # imm = 0xA782520797274
    2909:      	movq	%rax, 0x3e(%rsp)
    290e:      	movabsq	$0x72746e6520747372, %rax # imm = 0x72746E6520747372
    2918:      	movq	%rax, 0x38(%rsp)
    291d:      	movabsq	$0x6966203a786c2520, %rax # imm = 0x6966203A786C2520
    2927:      	movq	%rax, 0x30(%rsp)
    292c:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    2936:      	movq	%rax, 0x28(%rsp)
    293b:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    2945:      	movq	%rax, 0x20(%rsp)
    294a:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    2954:      	movq	%rax, 0x18(%rsp)
    2959:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    2963:      	movq	%rax, 0x10(%rsp)
    2968:      	leaq	0x10(%rsp), %rdi
    296d:      	movl	$0x36, %eax
    2972:      	movl	$0x6, %r8d
    2978:      	movl	$0x36, %esi
    297d:      	movq	%r15, %rdx
    2980:      	movl	%ebp, %ecx
    2982:      	xorl	%eax, %eax
    2984:      	callq	*%r8
    2987:      	jmp	0x1f09 <kprobe_unwind_dotnet+0x1f09>
    298c:      	movabsq	$0xa786c253d7465, %rax  # imm = 0xA786C253D7465
    2996:      	movq	%rax, 0x36(%rsp)
    299b:      	movabsq	$0x746572202c78253d, %rax # imm = 0x746572202C78253D
    29a5:      	movq	%rax, 0x30(%rsp)
    29aa:      	movabsq	$0x6c6176202c786c25, %rax # imm = 0x6C6176202C786C25
    29b4:      	movq	%rax, 0x28(%rsp)
    29b9:      	movabsq	$0x203d2061746c6564, %rax # imm = 0x203D2061746C6564
    29c3:      	movq	%rax, 0x20(%rsp)
    29c8:      	movabsq	$0x5f6370203e2d2d20, %rax # imm = 0x5F6370203E2D2D20
    29d2:      	movq	%rax, 0x18(%rsp)
    29d7:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    29e1:      	movq	%rax, 0x10(%rsp)
    29e6:      	leaq	0x10(%rsp), %rdi
    29eb:      	movl	$0x2e, %eax
    29f0:      	movl	$0x6, %r9d
    29f6:      	movl	$0x2e, %esi
    29fb:      	movq	%r13, %rdx
    29fe:      	movq	%r15, %r8
    2a01:      	xorl	%eax, %eax
    2a03:      	callq	*%r9
    2a06:      	jmp	0x2402 <kprobe_unwind_dotnet+0x2402>
    2a0b:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    2a15:      	movq	%rax, 0x36(%rsp)
    2a1a:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    2a24:      	movq	%rax, 0x30(%rsp)
    2a29:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    2a33:      	movq	%rax, 0x28(%rsp)
    2a38:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    2a42:      	movq	%rax, 0x20(%rsp)
    2a47:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    2a51:      	movq	%rax, 0x18(%rsp)
    2a56:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    2a60:      	movq	%rax, 0x10(%rsp)
    2a65:      	leaq	0x10(%rsp), %rdi
    2a6a:      	movl	$0x2e, %eax
    2a6f:      	movl	$0x6, %ecx
    2a74:      	movl	0xc(%rsp), %edx
    2a78:      	movl	$0x2e, %esi
    2a7d:      	xorl	%eax, %eax
    2a7f:      	callq	*%rcx
    2a81:      	jmp	0x1f6d <kprobe_unwind_dotnet+0x1f6d>
    2a86:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    2a90:      	movq	%rax, 0x38(%rsp)
    2a95:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    2a9f:      	movq	%rax, 0x30(%rsp)
    2aa4:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    2aae:      	movq	%rax, 0x28(%rsp)
    2ab3:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    2abd:      	movq	%rax, 0x20(%rsp)
    2ac2:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    2acc:      	movq	%rax, 0x18(%rsp)
    2ad1:      	movabsq	$0x6365732074786554, %rbx # imm = 0x6365732074786554
    2adb:      	movq	%rbx, 0x10(%rsp)
    2ae0:      	movw	$0xa, 0x40(%rsp)
    2ae7:      	leaq	0x10(%rsp), %rdi
    2aec:      	movl	$0x32, %eax
    2af1:      	movl	$0x6, %r9d
    2af7:      	movq	0xf10(%r14), %rcx
    2afe:      	movl	$0x32, %esi
    2b03:      	movq	%r13, %rdx
    2b06:      	movl	%r12d, %r8d
    2b09:      	xorl	%eax, %eax
    2b0b:      	callq	*%r9
    2b0e:      	movq	(%rip), %rax            # 0x2b15 <kprobe_unwind_dotnet+0x2b15>
    2b15:      	cmpl	$0x0, (%rax)
    2b18:      	je	0x279d <kprobe_unwind_dotnet+0x279d>
    2b1e:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    2b28:      	movq	%rax, 0x37(%rsp)
    2b2d:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    2b37:      	movq	%rax, 0x30(%rsp)
    2b3c:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    2b46:      	movq	%rax, 0x28(%rsp)
    2b4b:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    2b55:      	movq	%rax, 0x20(%rsp)
    2b5a:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    2b64:      	movq	%rax, 0x18(%rsp)
    2b69:      	movq	%rbx, 0x10(%rsp)
    2b6e:      	leaq	0x10(%rsp), %rdi
    2b73:      	movl	$0x2f, %eax
    2b78:      	movl	$0x6, %r8d
    2b7e:      	movq	0xf18(%r14), %rcx
    2b85:      	movq	0xf20(%r14), %rdx
    2b8c:      	movl	$0x2f, %esi
    2b91:      	xorl	%eax, %eax
    2b93:      	callq	*%r8
    2b96:      	jmp	0x279d <kprobe_unwind_dotnet+0x279d>
    2b9b:      	movabsq	$0xa782520797274, %rax  # imm = 0xA782520797274
    2ba5:      	movq	%rax, 0x3f(%rsp)
    2baa:      	movabsq	$0x746e6520646e6f63, %rax # imm = 0x746E6520646E6F63
    2bb4:      	movq	%rax, 0x38(%rsp)
    2bb9:      	movabsq	$0x6573203a786c2520, %rax # imm = 0x6573203A786C2520
    2bc3:      	movq	%rax, 0x30(%rsp)
    2bc8:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    2bd2:      	movq	%rax, 0x28(%rsp)
    2bd7:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    2be1:      	movq	%rax, 0x20(%rsp)
    2be6:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    2bf0:      	movq	%rax, 0x18(%rsp)
    2bf5:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    2bff:      	movq	%rax, 0x10(%rsp)
    2c04:      	leaq	0x10(%rsp), %rdi
    2c09:      	movl	$0x37, %eax
    2c0e:      	movl	$0x6, %r8d
    2c14:      	movl	$0x37, %esi
    2c19:      	movq	%r13, %rdx
    2c1c:      	movl	%r15d, %ecx
    2c1f:      	xorl	%eax, %eax
    2c21:      	callq	*%r8
    2c24:      	xorl	%ecx, %ecx
    2c26:      	testl	%r15d, %r15d
    2c29:      	jne	0x2027 <kprobe_unwind_dotnet+0x2027>
    2c2f:      	movq	0x1170(%r14), %rax
    2c36:      	movl	$0xffffff84, %ecx       # imm = 0xFFFFFF84
    2c3b:      	testq	%rax, %rax
    2c3e:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2c44:      	movq	0x1168(%r14), %rax
    2c4b:      	movl	$0xffffff86, %ecx       # imm = 0xFFFFFF86
    2c50:      	testq	%rax, %rax
    2c53:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2c59:      	movq	0x1160(%r14), %rax
    2c60:      	movl	$0xffffff88, %ecx       # imm = 0xFFFFFF88
    2c65:      	testq	%rax, %rax
    2c68:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2c6e:      	movq	0x1158(%r14), %rax
    2c75:      	movl	$0xffffff8a, %ecx       # imm = 0xFFFFFF8A
    2c7a:      	testq	%rax, %rax
    2c7d:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2c83:      	movq	0x1150(%r14), %rax
    2c8a:      	movl	$0xffffff8c, %ecx       # imm = 0xFFFFFF8C
    2c8f:      	testq	%rax, %rax
    2c92:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2c98:      	movq	0x1148(%r14), %rax
    2c9f:      	movl	$0xffffff8e, %ecx       # imm = 0xFFFFFF8E
    2ca4:      	testq	%rax, %rax
    2ca7:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2cad:      	movq	0x1140(%r14), %rax
    2cb4:      	movl	$0xffffff90, %ecx       # imm = 0xFFFFFF90
    2cb9:      	testq	%rax, %rax
    2cbc:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2cc2:      	movq	0x1138(%r14), %rax
    2cc9:      	movl	$0xffffff92, %ecx       # imm = 0xFFFFFF92
    2cce:      	testq	%rax, %rax
    2cd1:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2cd7:      	movq	0x1130(%r14), %rax
    2cde:      	movl	$0xffffff94, %ecx       # imm = 0xFFFFFF94
    2ce3:      	testq	%rax, %rax
    2ce6:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2cec:      	movq	0x1128(%r14), %rax
    2cf3:      	movl	$0xffffff96, %ecx       # imm = 0xFFFFFF96
    2cf8:      	testq	%rax, %rax
    2cfb:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2d01:      	movq	0x1120(%r14), %rax
    2d08:      	movl	$0xffffff98, %ecx       # imm = 0xFFFFFF98
    2d0d:      	testq	%rax, %rax
    2d10:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2d16:      	movq	0x1118(%r14), %rax
    2d1d:      	movl	$0xffffff9a, %ecx       # imm = 0xFFFFFF9A
    2d22:      	testq	%rax, %rax
    2d25:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2d2b:      	movq	0x1110(%r14), %rax
    2d32:      	movl	$0xffffff9c, %ecx       # imm = 0xFFFFFF9C
    2d37:      	testq	%rax, %rax
    2d3a:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2d40:      	movq	0x1108(%r14), %rax
    2d47:      	movl	$0xffffff9e, %ecx       # imm = 0xFFFFFF9E
    2d4c:      	testq	%rax, %rax
    2d4f:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2d55:      	movq	0x1100(%r14), %rax
    2d5c:      	movl	$0xffffffa0, %ecx       # imm = 0xFFFFFFA0
    2d61:      	testq	%rax, %rax
    2d64:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2d6a:      	movq	0x10f8(%r14), %rax
    2d71:      	movl	$0xffffffa2, %ecx       # imm = 0xFFFFFFA2
    2d76:      	testq	%rax, %rax
    2d79:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2d7f:      	movq	0x10f0(%r14), %rax
    2d86:      	movl	$0xffffffa4, %ecx       # imm = 0xFFFFFFA4
    2d8b:      	testq	%rax, %rax
    2d8e:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2d94:      	movq	0x10e8(%r14), %rax
    2d9b:      	movl	$0xffffffa6, %ecx       # imm = 0xFFFFFFA6
    2da0:      	testq	%rax, %rax
    2da3:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2da9:      	movq	0x10e0(%r14), %rax
    2db0:      	movl	$0xffffffa8, %ecx       # imm = 0xFFFFFFA8
    2db5:      	testq	%rax, %rax
    2db8:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2dbe:      	movq	0x10d8(%r14), %rax
    2dc5:      	movl	$0xffffffaa, %ecx       # imm = 0xFFFFFFAA
    2dca:      	testq	%rax, %rax
    2dcd:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2dd3:      	movq	0x10d0(%r14), %rax
    2dda:      	movl	$0xffffffac, %ecx       # imm = 0xFFFFFFAC
    2ddf:      	testq	%rax, %rax
    2de2:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2de8:      	movq	0x10c8(%r14), %rax
    2def:      	movl	$0xffffffae, %ecx       # imm = 0xFFFFFFAE
    2df4:      	testq	%rax, %rax
    2df7:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2dfd:      	movq	0x10c0(%r14), %rax
    2e04:      	movl	$0xffffffb0, %ecx       # imm = 0xFFFFFFB0
    2e09:      	testq	%rax, %rax
    2e0c:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2e12:      	movq	0x10b8(%r14), %rax
    2e19:      	movl	$0xffffffb2, %ecx       # imm = 0xFFFFFFB2
    2e1e:      	testq	%rax, %rax
    2e21:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2e27:      	movq	0x10b0(%r14), %rax
    2e2e:      	movl	$0xffffffb4, %ecx       # imm = 0xFFFFFFB4
    2e33:      	testq	%rax, %rax
    2e36:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2e3c:      	movq	0x10a8(%r14), %rax
    2e43:      	movl	$0xffffffb6, %ecx       # imm = 0xFFFFFFB6
    2e48:      	testq	%rax, %rax
    2e4b:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2e51:      	movq	0x10a0(%r14), %rax
    2e58:      	movl	$0xffffffb8, %ecx       # imm = 0xFFFFFFB8
    2e5d:      	testq	%rax, %rax
    2e60:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2e66:      	movq	0x1098(%r14), %rax
    2e6d:      	movl	$0xffffffba, %ecx       # imm = 0xFFFFFFBA
    2e72:      	testq	%rax, %rax
    2e75:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2e7b:      	movq	0x1090(%r14), %rax
    2e82:      	movl	$0xffffffbc, %ecx       # imm = 0xFFFFFFBC
    2e87:      	testq	%rax, %rax
    2e8a:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2e90:      	movq	0x1088(%r14), %rax
    2e97:      	movl	$0xffffffbe, %ecx       # imm = 0xFFFFFFBE
    2e9c:      	testq	%rax, %rax
    2e9f:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2ea5:      	movq	0x1080(%r14), %rax
    2eac:      	movl	$0xffffffc0, %ecx       # imm = 0xFFFFFFC0
    2eb1:      	testq	%rax, %rax
    2eb4:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2eba:      	movq	0x1078(%r14), %rax
    2ec1:      	movl	$0xffffffc2, %ecx       # imm = 0xFFFFFFC2
    2ec6:      	testq	%rax, %rax
    2ec9:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2ecf:      	movq	0x1070(%r14), %rax
    2ed6:      	movl	$0xffffffc4, %ecx       # imm = 0xFFFFFFC4
    2edb:      	testq	%rax, %rax
    2ede:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2ee4:      	movq	0x1068(%r14), %rax
    2eeb:      	movl	$0xffffffc6, %ecx       # imm = 0xFFFFFFC6
    2ef0:      	testq	%rax, %rax
    2ef3:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2ef9:      	movq	0x1060(%r14), %rax
    2f00:      	movl	$0xffffffc8, %ecx       # imm = 0xFFFFFFC8
    2f05:      	testq	%rax, %rax
    2f08:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2f0e:      	movq	0x1058(%r14), %rax
    2f15:      	movl	$0xffffffca, %ecx       # imm = 0xFFFFFFCA
    2f1a:      	testq	%rax, %rax
    2f1d:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2f23:      	movq	0x1050(%r14), %rax
    2f2a:      	movl	$0xffffffcc, %ecx       # imm = 0xFFFFFFCC
    2f2f:      	testq	%rax, %rax
    2f32:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2f38:      	movq	0x1048(%r14), %rax
    2f3f:      	movl	$0xffffffce, %ecx       # imm = 0xFFFFFFCE
    2f44:      	testq	%rax, %rax
    2f47:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2f4d:      	movq	0x1040(%r14), %rax
    2f54:      	movl	$0xffffffd0, %ecx       # imm = 0xFFFFFFD0
    2f59:      	testq	%rax, %rax
    2f5c:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2f62:      	movq	0x1038(%r14), %rax
    2f69:      	movl	$0xffffffd2, %ecx       # imm = 0xFFFFFFD2
    2f6e:      	testq	%rax, %rax
    2f71:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2f77:      	movq	0x1030(%r14), %rax
    2f7e:      	movl	$0xffffffd4, %ecx       # imm = 0xFFFFFFD4
    2f83:      	testq	%rax, %rax
    2f86:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2f8c:      	movq	0x1028(%r14), %rax
    2f93:      	movl	$0xffffffd6, %ecx       # imm = 0xFFFFFFD6
    2f98:      	testq	%rax, %rax
    2f9b:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2fa1:      	movq	0x1020(%r14), %rax
    2fa8:      	movl	$0xffffffd8, %ecx       # imm = 0xFFFFFFD8
    2fad:      	testq	%rax, %rax
    2fb0:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2fb6:      	movq	0x1018(%r14), %rax
    2fbd:      	movl	$0xffffffda, %ecx       # imm = 0xFFFFFFDA
    2fc2:      	testq	%rax, %rax
    2fc5:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2fcb:      	movq	0x1010(%r14), %rax
    2fd2:      	movl	$0xffffffdc, %ecx       # imm = 0xFFFFFFDC
    2fd7:      	testq	%rax, %rax
    2fda:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2fe0:      	movq	0x1008(%r14), %rax
    2fe7:      	movl	$0xffffffde, %ecx       # imm = 0xFFFFFFDE
    2fec:      	testq	%rax, %rax
    2fef:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    2ff5:      	movq	0x1000(%r14), %rax
    2ffc:      	movl	$0xffffffe0, %ecx       # imm = 0xFFFFFFE0
    3001:      	testq	%rax, %rax
    3004:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    300a:      	movq	0xff8(%r14), %rax
    3011:      	movl	$0xffffffe2, %ecx       # imm = 0xFFFFFFE2
    3016:      	testq	%rax, %rax
    3019:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    301f:      	movq	0xff0(%r14), %rax
    3026:      	movl	$0xffffffe4, %ecx       # imm = 0xFFFFFFE4
    302b:      	testq	%rax, %rax
    302e:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    3034:      	movq	0xfe8(%r14), %rax
    303b:      	movl	$0xffffffe6, %ecx       # imm = 0xFFFFFFE6
    3040:      	testq	%rax, %rax
    3043:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    3049:      	movq	0xfe0(%r14), %rax
    3050:      	movl	$0xffffffe8, %ecx       # imm = 0xFFFFFFE8
    3055:      	testq	%rax, %rax
    3058:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    305e:      	movq	0xfd8(%r14), %rax
    3065:      	movl	$0xffffffea, %ecx       # imm = 0xFFFFFFEA
    306a:      	testq	%rax, %rax
    306d:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    3073:      	movq	0xfd0(%r14), %rax
    307a:      	movl	$0xffffffec, %ecx       # imm = 0xFFFFFFEC
    307f:      	testq	%rax, %rax
    3082:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    3088:      	movq	0xfc8(%r14), %rax
    308f:      	movl	$0xffffffee, %ecx       # imm = 0xFFFFFFEE
    3094:      	testq	%rax, %rax
    3097:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    309d:      	movq	0xfc0(%r14), %rax
    30a4:      	movl	$0xfffffff0, %ecx       # imm = 0xFFFFFFF0
    30a9:      	testq	%rax, %rax
    30ac:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    30b2:      	movq	0xfb8(%r14), %rax
    30b9:      	movl	$0xfffffff2, %ecx       # imm = 0xFFFFFFF2
    30be:      	testq	%rax, %rax
    30c1:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    30c3:      	movq	0xfb0(%r14), %rax
    30ca:      	movl	$0xfffffff4, %ecx       # imm = 0xFFFFFFF4
    30cf:      	testq	%rax, %rax
    30d2:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    30d4:      	movq	0xfa8(%r14), %rax
    30db:      	movl	$0xfffffff6, %ecx       # imm = 0xFFFFFFF6
    30e0:      	testq	%rax, %rax
    30e3:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    30e5:      	movq	0xfa0(%r14), %rax
    30ec:      	movl	$0xfffffff8, %ecx       # imm = 0xFFFFFFF8
    30f1:      	testq	%rax, %rax
    30f4:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    30f6:      	movq	0xf98(%r14), %rax
    30fd:      	movl	$0xfffffffa, %ecx       # imm = 0xFFFFFFFA
    3102:      	testq	%rax, %rax
    3105:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    3107:      	movq	0xf90(%r14), %rax
    310e:      	movl	$0xfffffffc, %ecx       # imm = 0xFFFFFFFC
    3113:      	testq	%rax, %rax
    3116:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    3118:      	movq	0xf88(%r14), %rax
    311f:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    3124:      	testq	%rax, %rax
    3127:      	jne	0x3136 <kprobe_unwind_dotnet+0x3136>
    3129:      	movq	0x90(%rsp), %rax
    3131:      	movq	(%rax), %rax
    3134:      	xorl	%ecx, %ecx
    3136:      	xorl	%edx, %edx
    3138:      	movq	%rax, %r15
    313b:      	shrq	$0x20, %r15
    313f:      	setne	%dl
    3142:      	cmovel	%eax, %r15d
    3146:      	subl	%edx, %ecx
    3148:      	addl	$0x7e, %ecx
    314b:      	movl	%ecx, %eax
    314d:      	shll	$0x8, %eax
    3150:      	subq	%rax, %r13
    3153:      	jb	0x2035 <kprobe_unwind_dotnet+0x2035>
    3159:      	movq	(%rip), %rax            # 0x3160 <kprobe_unwind_dotnet+0x3160>
    3160:      	cmpl	$0x0, (%rax)
    3163:      	jne	0x3226 <kprobe_unwind_dotnet+0x3226>
    3169:      	testl	%r15d, %r15d
    316c:      	jne	0x1f39 <kprobe_unwind_dotnet+0x1f39>
    3172:      	movl	$0x5f, 0xc(%rsp)
    317a:      	movq	(%rip), %rdi            # 0x3181 <kprobe_unwind_dotnet+0x3181>
    3181:      	leaq	0xc(%rsp), %rsi
    3186:      	movl	$0x1, %eax
    318b:      	callq	*%rax
    318d:      	testq	%rax, %rax
    3190:      	je	0x3197 <kprobe_unwind_dotnet+0x3197>
    3192:      	incq	(%rax)
    3195:      	jmp	0x31a7 <kprobe_unwind_dotnet+0x31a7>
    3197:      	movq	(%rip), %rax            # 0x319e <kprobe_unwind_dotnet+0x319e>
    319e:      	cmpl	$0x0, (%rax)
    31a1:      	jne	0x3835 <kprobe_unwind_dotnet+0x3835>
    31a7:      	movl	$0x1773, %edx           # imm = 0x1773
    31ac:      	movb	$0x1, %bl
    31ae:      	movq	(%rip), %rax            # 0x31b5 <kprobe_unwind_dotnet+0x31b5>
    31b5:      	cmpl	$0x0, (%rax)
    31b8:      	je	0x1f84 <kprobe_unwind_dotnet+0x1f84>
    31be:      	movabsq	$0xa642520687469, %rax  # imm = 0xA642520687469
    31c8:      	movq	%rax, 0x30(%rsp)
    31cd:      	movabsq	$0x772064656c696166, %rax # imm = 0x772064656C696166
    31d7:      	movq	%rax, 0x28(%rsp)
    31dc:      	movabsq	$0x2074726174735f65, %rax # imm = 0x2074726174735F65
    31e6:      	movq	%rax, 0x20(%rsp)
    31eb:      	movabsq	$0x646f63203e2d2d20, %rax # imm = 0x646F63203E2D2D20
    31f5:      	movq	%rax, 0x18(%rsp)
    31fa:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    3204:      	movq	%rax, 0x10(%rsp)
    3209:      	leaq	0x10(%rsp), %rdi
    320e:      	movl	$0x28, %eax
    3213:      	movl	$0x6, %ecx
    3218:      	movl	$0x28, %esi
    321d:      	xorl	%eax, %eax
    321f:      	callq	*%rcx
    3221:      	jmp	0x1f84 <kprobe_unwind_dotnet+0x1f84>
    3226:      	movabsq	$0x207972746e65202c, %rax # imm = 0x207972746E65202C
    3230:      	movq	%rax, 0x40(%rsp)
    3235:      	movabsq	$0x6425206465707069, %rax # imm = 0x6425206465707069
    323f:      	movq	%rax, 0x38(%rsp)
    3244:      	movabsq	$0x6b73203a786c2520, %rax # imm = 0x6B73203A786C2520
    324e:      	movq	%rax, 0x30(%rsp)
    3253:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    325d:      	movq	%rax, 0x28(%rsp)
    3262:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    326c:      	movq	%rax, 0x20(%rsp)
    3271:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    327b:      	movq	%rax, 0x18(%rsp)
    3280:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    328a:      	movq	%rax, 0x10(%rsp)
    328f:      	movl	$0xa7825, 0x48(%rsp)    # imm = 0xA7825
    3297:      	leaq	0x10(%rsp), %rdi
    329c:      	movl	$0x3c, %eax
    32a1:      	movl	$0x6, %r9d
    32a7:      	movl	$0x3c, %esi
    32ac:      	movq	%r13, %rdx
    32af:      	movl	%r15d, %r8d
    32b2:      	xorl	%eax, %eax
    32b4:      	callq	*%r9
    32b7:      	testl	%r15d, %r15d
    32ba:      	jne	0x1f39 <kprobe_unwind_dotnet+0x1f39>
    32c0:      	jmp	0x3172 <kprobe_unwind_dotnet+0x3172>
    32c5:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    32cf:      	movq	%rax, 0x26(%rsp)
    32d4:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    32de:      	movq	%rax, 0x20(%rsp)
    32e3:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    32ed:      	movq	%rax, 0x18(%rsp)
    32f2:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    32fc:      	movq	%rax, 0x10(%rsp)
    3301:      	leaq	0x10(%rsp), %rdi
    3306:      	movl	$0x1e, %eax
    330b:      	movl	$0x6, %ecx
    3310:      	movzwl	0x20(%r15), %edx
    3315:      	movl	$0x1e, %esi
    331a:      	xorl	%eax, %eax
    331c:      	callq	*%rcx
    331e:      	movl	0x1380(%r14), %eax
    3325:      	movl	0x20(%r15), %ecx
    3329:      	btl	%ecx, %eax
    332c:      	jb	0x2822 <kprobe_unwind_dotnet+0x2822>
    3332:      	movl	$0x0, 0x68(%rsp)
    333a:      	movq	(%rip), %rdi            # 0x3341 <kprobe_unwind_dotnet+0x3341>
    3341:      	leaq	0x68(%rsp), %rsi
    3346:      	movl	$0x1, %eax
    334b:      	callq	*%rax
    334d:      	testq	%rax, %rax
    3350:      	je	0x3357 <kprobe_unwind_dotnet+0x3357>
    3352:      	incq	(%rax)
    3355:      	jmp	0x3367 <kprobe_unwind_dotnet+0x3367>
    3357:      	movq	(%rip), %rax            # 0x335e <kprobe_unwind_dotnet+0x335e>
    335e:      	cmpl	$0x0, (%rax)
    3361:      	jne	0x3994 <kprobe_unwind_dotnet+0x3994>
    3367:      	movzwl	0x20(%r15), %r12d
    336c:      	cmpl	$0x8, %r12d
    3370:      	jne	0x8da3 <kprobe_unwind_dotnet+0x8da3>
    3376:      	movq	0xed0(%r14), %r12
    337d:      	movq	0xed8(%r14), %rbx
    3384:      	movq	0xee0(%r14), %r13
    338b:      	movzbl	0xf30(%r14), %eax
    3393:      	movb	%al, 0x88(%rsp)
    339a:      	movq	(%rip), %rax            # 0x33a1 <kprobe_unwind_dotnet+0x33a1>
    33a1:      	cmpl	$0x0, (%rax)
    33a4:      	jne	0x3791 <kprobe_unwind_dotnet+0x3791>
    33aa:      	cmpq	%rbx, %r13
    33ad:      	jb	0x77bb <kprobe_unwind_dotnet+0x77bb>
    33b3:      	leaq	0x2000(%rbx), %rax
    33ba:      	cmpq	%rax, %r13
    33bd:      	jae	0x77bb <kprobe_unwind_dotnet+0x77bb>
    33c3:      	movq	0xf10(%r14), %rbp
    33ca:      	movq	0xf20(%r14), %r15
    33d1:      	movq	%r12, 0x68(%rsp)
    33d6:      	movb	$0x1, 0xf30(%r14)
    33de:      	movq	%rbp, %rax
    33e1:      	andq	$-0x80, %rax
    33e5:      	cmpq	$0x80, %rax
    33eb:      	jne	0x342f <kprobe_unwind_dotnet+0x342f>
    33ed:      	movq	0xed8(%r14), %rax
    33f4:      	movl	$0x8, %ecx
    33f9:      	movl	$0x70, %r8d
    33ff:      	movq	0x98(%rsp), %rdi
    3407:      	movq	0xed8(%r14), %rdx
    340e:      	movl	$0x8, %esi
    3413:      	callq	*%r8
    3416:      	testq	%rax, %rax
    3419:      	jne	0x19c <kprobe_unwind_dotnet+0x19c>
    341f:      	addq	$0x8, 0xed8(%r14)
    3427:      	andl	$0x7f, %ebp
    342a:      	jmp	0x3a6a <kprobe_unwind_dotnet+0x3a6a>
    342f:      	leaq	0x70(%rsp), %rdi
    3434:      	movl	$0x10, %eax
    3439:      	movl	$0x70, %ecx
    343e:      	movl	$0x10, %esi
    3443:      	movq	%r13, %rdx
    3446:      	callq	*%rcx
    3448:      	testq	%rax, %rax
    344b:      	jne	0x26c <kprobe_unwind_dotnet+0x26c>
    3451:      	addq	$0x10, %r13
    3455:      	movq	%r13, 0xed8(%r14)
    345c:      	movq	0x70(%rsp), %rax
    3461:      	movq	%rax, 0xee0(%r14)
    3468:      	movq	0x78(%rsp), %rax
    346d:      	movq	%rax, 0xed0(%r14)
    3474:      	movq	(%rip), %rax            # 0x347b <kprobe_unwind_dotnet+0x347b>
    347b:      	cmpl	$0x0, (%rax)
    347e:      	jne	0x38b0 <kprobe_unwind_dotnet+0x38b0>
    3484:      	cmpq	$0x100, %rbp            # imm = 0x100
    348b:      	jb	0x3a6a <kprobe_unwind_dotnet+0x3a6a>
    3491:      	movq	0xf10(%r14), %rbp
    3498:      	movq	0xf20(%r14), %rbx
    349f:      	movq	%r12, %r13
    34a2:      	subq	%rbx, %r13
    34a5:      	movq	(%rip), %rax            # 0x34ac <kprobe_unwind_dotnet+0x34ac>
    34ac:      	cmpl	$0x0, (%rax)
    34af:      	jne	0x3950 <kprobe_unwind_dotnet+0x3950>
    34b5:      	movq	%r13, %r15
    34b8:      	andq	$-0x4, %r15
    34bc:      	movl	$0x100, %ecx            # imm = 0x100
    34c1:      	movq	%r15, %rax
    34c4:      	xorl	%edx, %edx
    34c6:      	divq	%rcx
    34c9:      	movq	%rax, %rcx
    34cc:      	movl	$0x7f, %eax
    34d1:      	subq	%rcx, %rax
    34d4:      	jns	0x34ed <kprobe_unwind_dotnet+0x34ed>
    34d6:      	movl	$0x100, %ecx            # imm = 0x100
    34db:      	movq	%r15, %rax
    34de:      	xorl	%edx, %edx
    34e0:      	divq	%rcx
    34e3:      	leaq	-0x3fc(%rbp,%rax,4), %rbp
    34eb:      	xorl	%eax, %eax
    34ed:      	movl	$0x80, %ecx
    34f2:      	cqto
    34f4:      	idivq	%rcx
    34f7:      	movq	0x90(%rsp), %rax
    34ff:      	leaq	(%rax,%rdx,4), %rdi
    3503:      	movl	$0x200, %eax            # imm = 0x200
    3508:      	movl	$0x70, %ecx
    350d:      	movl	$0x200, %esi            # imm = 0x200
    3512:      	movq	%rbp, %rdx
    3515:      	callq	*%rcx
    3517:      	testq	%rax, %rax
    351a:      	je	0x3551 <kprobe_unwind_dotnet+0x3551>
    351c:      	movq	(%rip), %rax            # 0x3523 <kprobe_unwind_dotnet+0x3523>
    3523:      	cmpl	$0x0, (%rax)
    3526:      	jne	0x3726 <kprobe_unwind_dotnet+0x3726>
    352c:      	movl	$0x5e, 0xc(%rsp)
    3534:      	movq	(%rip), %rdi            # 0x353b <kprobe_unwind_dotnet+0x353b>
    353b:      	leaq	0xc(%rsp), %rsi
    3540:      	movl	$0x1, %eax
    3545:      	callq	*%rax
    3547:      	testq	%rax, %rax
    354a:      	je	0x35bc <kprobe_unwind_dotnet+0x35bc>
    354c:      	incq	(%rax)
    354f:      	jmp	0x35cc <kprobe_unwind_dotnet+0x35cc>
    3551:      	movl	0x117c(%r14), %ebp
    3558:      	movq	(%rip), %rax            # 0x355f <kprobe_unwind_dotnet+0x355f>
    355f:      	cmpl	$0x0, (%rax)
    3562:      	jne	0x3e3a <kprobe_unwind_dotnet+0x3e3a>
    3568:      	movl	$0x20, %ecx
    356d:      	movq	%r15, %rax
    3570:      	xorl	%edx, %edx
    3572:      	divq	%rcx
    3575:      	movl	$0x8, %ecx
    357a:      	xorl	%edx, %edx
    357c:      	divq	%rcx
    357f:      	shll	$0x2, %edx
    3582:      	movb	$0x1c, %al
    3584:      	subb	%dl, %al
    3586:      	shrxl	%eax, %ebp, %r15d
    358b:      	testl	%r15d, %r15d
    358e:      	je	0x3659 <kprobe_unwind_dotnet+0x3659>
    3594:      	andq	$-0x20, %r13
    3598:      	movl	%r15d, %ecx
    359b:      	andl	$0xf, %ecx
    359e:      	jne	0x3a1d <kprobe_unwind_dotnet+0x3a1d>
    35a4:      	movl	%r15d, %ecx
    35a7:      	shrl	$0x4, %ecx
    35aa:      	andl	$0xf, %ecx
    35ad:      	je	0x3769 <kprobe_unwind_dotnet+0x3769>
    35b3:      	addq	$-0x20, %r13
    35b7:      	jmp	0x3a1d <kprobe_unwind_dotnet+0x3a1d>
    35bc:      	movq	(%rip), %rax            # 0x35c3 <kprobe_unwind_dotnet+0x35c3>
    35c3:      	cmpl	$0x0, (%rax)
    35c6:      	jne	0x3f46 <kprobe_unwind_dotnet+0x3f46>
    35cc:      	movl	$0x1772, %edx           # imm = 0x1772
    35d1:      	xorl	%ebx, %ebx
    35d3:      	movq	(%rip), %rax            # 0x35da <kprobe_unwind_dotnet+0x35da>
    35da:      	cmpl	$0x0, (%rax)
    35dd:      	jne	0x46f9 <kprobe_unwind_dotnet+0x46f9>
    35e3:      	movl	$0x1772, %eax           # imm = 0x1772
    35e8:      	testb	%bl, %bl
    35ea:      	movq	0x60(%rsp), %r15
    35ef:      	movq	(%rip), %rbp            # 0x35f6 <kprobe_unwind_dotnet+0x35f6>
    35f6:      	je	0x7812 <kprobe_unwind_dotnet+0x7812>
    35fc:      	movl	0x2c0(%r14), %eax
    3603:      	cmpq	$0x7e, %rax
    3607:      	ja	0x52f <kprobe_unwind_dotnet+0x52f>
    360d:      	leal	0x1(%rax), %ecx
    3610:      	movl	%ecx, 0x2c0(%r14)
    3617:      	leaq	(%rax,%rax,2), %rax
    361b:      	movq	$0x0, 0x2d0(%r14,%rax,8)
    3627:      	movq	$0x1773, 0x2d8(%r14,%rax,8) # imm = 0x1773
    3633:      	movb	$-0x76, 0x2e0(%r14,%rax,8)
    363c:      	movl	$0x0, 0x2e1(%r14,%rax,8)
    3648:      	movl	$0x0, 0x2e4(%r14,%rax,8)
    3654:      	jmp	0x3b1d <kprobe_unwind_dotnet+0x3b1d>
    3659:      	andq	$-0x100, %r13
    3660:      	addq	$-0x20, %r13
    3664:      	movl	0x1178(%r14), %r15d
    366b:      	movq	(%rip), %rax            # 0x3672 <kprobe_unwind_dotnet+0x3672>
    3672:      	cmpl	$0x0, (%rax)
    3675:      	jne	0x40d6 <kprobe_unwind_dotnet+0x40d6>
    367b:      	xorl	%ecx, %ecx
    367d:      	testl	%r15d, %r15d
    3680:      	je	0x416a <kprobe_unwind_dotnet+0x416a>
    3686:      	movl	%ecx, %eax
    3688:      	shll	$0x8, %eax
    368b:      	subq	%rax, %r13
    368e:      	jae	0x4694 <kprobe_unwind_dotnet+0x4694>
    3694:      	movq	(%rip), %rax            # 0x369b <kprobe_unwind_dotnet+0x369b>
    369b:      	cmpl	$0x0, (%rax)
    369e:      	je	0x352c <kprobe_unwind_dotnet+0x352c>
    36a4:      	movabsq	$0xa657361625f63, %rax  # imm = 0xA657361625F63
    36ae:      	movq	%rax, 0x36(%rsp)
    36b3:      	movabsq	$0x5f637020776f6c65, %rax # imm = 0x5F637020776F6C65
    36bd:      	movq	%rax, 0x30(%rsp)
    36c2:      	movabsq	$0x6220746e65772068, %rax # imm = 0x6220746E65772068
    36cc:      	movq	%rax, 0x28(%rsp)
    36d1:      	movabsq	$0x6372616573207061, %rax # imm = 0x6372616573207061
    36db:      	movq	%rax, 0x20(%rsp)
    36e0:      	movabsq	$0x6d20656c6262696e, %rax # imm = 0x6D20656C6262696E
    36ea:      	movq	%rax, 0x18(%rsp)
    36ef:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    36f9:      	movq	%rax, 0x10(%rsp)
    36fe:      	leaq	0x10(%rsp), %rdi
    3703:      	movl	$0x2e, %eax
    3708:      	movl	$0x6, %ecx
    370d:      	movl	$0x2e, %esi
    3712:      	xorl	%eax, %eax
    3714:      	callq	*%rcx
    3716:      	movq	(%rip), %rax            # 0x371d <kprobe_unwind_dotnet+0x371d>
    371d:      	cmpl	$0x0, (%rax)
    3720:      	je	0x352c <kprobe_unwind_dotnet+0x352c>
    3726:      	movabsq	$0x6e756f6620746f6e, %rax # imm = 0x6E756F6620746F6E
    3730:      	movq	%rax, 0x18(%rsp)
    3735:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    373f:      	movq	%rax, 0x10(%rsp)
    3744:      	movl	$0xa646e, 0x1f(%rsp)    # imm = 0xA646E
    374c:      	leaq	0x10(%rsp), %rdi
    3751:      	movl	$0x13, %eax
    3756:      	movl	$0x6, %ecx
    375b:      	movl	$0x13, %esi
    3760:      	xorl	%eax, %eax
    3762:      	callq	*%rcx
    3764:      	jmp	0x352c <kprobe_unwind_dotnet+0x352c>
    3769:      	movl	%r15d, %ecx
    376c:      	shrl	$0x8, %ecx
    376f:      	andl	$0xf, %ecx
    3772:      	je	0x377d <kprobe_unwind_dotnet+0x377d>
    3774:      	addq	$-0x40, %r13
    3778:      	jmp	0x3a1d <kprobe_unwind_dotnet+0x3a1d>
    377d:      	movl	%r15d, %ecx
    3780:      	shrl	$0xc, %ecx
    3783:      	andl	$0xf, %ecx
    3786:      	je	0x3806 <kprobe_unwind_dotnet+0x3806>
    3788:      	addq	$-0x60, %r13
    378c:      	jmp	0x3a1d <kprobe_unwind_dotnet+0x3a1d>
    3791:      	movabsq	$0x6c25203a7066202c, %rax # imm = 0x6C25203A7066202C
    379b:      	movq	%rax, 0x28(%rsp)
    37a0:      	movabsq	$0x786c25203a707320, %rax # imm = 0x786C25203A707320
    37aa:      	movq	%rax, 0x20(%rsp)
    37af:      	movabsq	$0x2c786c25203a6370, %rax # imm = 0x2C786C25203A6370
    37b9:      	movq	%rax, 0x18(%rsp)
    37be:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    37c8:      	movq	%rax, 0x10(%rsp)
    37cd:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    37d5:      	leaq	0x10(%rsp), %rdi
    37da:      	movl	$0x23, %eax
    37df:      	movl	$0x6, %r9d
    37e5:      	movl	$0x23, %esi
    37ea:      	movq	%r12, %rdx
    37ed:      	movq	%rbx, %rcx
    37f0:      	movq	%r13, %r8
    37f3:      	xorl	%eax, %eax
    37f5:      	callq	*%r9
    37f8:      	cmpq	%rbx, %r13
    37fb:      	jae	0x33b3 <kprobe_unwind_dotnet+0x33b3>
    3801:      	jmp	0x77bb <kprobe_unwind_dotnet+0x77bb>
    3806:      	movl	%r15d, %ecx
    3809:      	shrl	$0x10, %ecx
    380c:      	andl	$0xf, %ecx
    380f:      	je	0x381a <kprobe_unwind_dotnet+0x381a>
    3811:      	addq	$-0x80, %r13
    3815:      	jmp	0x3a1d <kprobe_unwind_dotnet+0x3a1d>
    381a:      	movl	%r15d, %ecx
    381d:      	shrl	$0x14, %ecx
    3820:      	andl	$0xf, %ecx
    3823:      	je	0x3935 <kprobe_unwind_dotnet+0x3935>
    3829:      	addq	$-0xa0, %r13
    3830:      	jmp	0x3a1d <kprobe_unwind_dotnet+0x3a1d>
    3835:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    383f:      	movq	%rax, 0x36(%rsp)
    3844:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    384e:      	movq	%rax, 0x30(%rsp)
    3853:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    385d:      	movq	%rax, 0x28(%rsp)
    3862:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    386c:      	movq	%rax, 0x20(%rsp)
    3871:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    387b:      	movq	%rax, 0x18(%rsp)
    3880:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    388a:      	movq	%rax, 0x10(%rsp)
    388f:      	leaq	0x10(%rsp), %rdi
    3894:      	movl	$0x2e, %eax
    3899:      	movl	$0x6, %ecx
    389e:      	movl	0xc(%rsp), %edx
    38a2:      	movl	$0x2e, %esi
    38a7:      	xorl	%eax, %eax
    38a9:      	callq	*%rcx
    38ab:      	jmp	0x31a7 <kprobe_unwind_dotnet+0x31a7>
    38b0:      	movabsq	$0x6c25203a7066202c, %rax # imm = 0x6C25203A7066202C
    38ba:      	movq	%rax, 0x28(%rsp)
    38bf:      	movabsq	$0x786c25203a707320, %rax # imm = 0x786C25203A707320
    38c9:      	movq	%rax, 0x20(%rsp)
    38ce:      	movabsq	$0x2c786c25203a6370, %rax # imm = 0x2C786C25203A6370
    38d8:      	movq	%rax, 0x18(%rsp)
    38dd:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    38e7:      	movq	%rax, 0x10(%rsp)
    38ec:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    38f4:      	leaq	0x10(%rsp), %rdi
    38f9:      	movl	$0x23, %eax
    38fe:      	movl	$0x6, %r9d
    3904:      	movq	0xed0(%r14), %rdx
    390b:      	movq	0xed8(%r14), %rcx
    3912:      	movq	0xee0(%r14), %r8
    3919:      	movl	$0x23, %esi
    391e:      	xorl	%eax, %eax
    3920:      	callq	*%r9
    3923:      	cmpq	$0x100, %rbp            # imm = 0x100
    392a:      	jae	0x3491 <kprobe_unwind_dotnet+0x3491>
    3930:      	jmp	0x3a6a <kprobe_unwind_dotnet+0x3a6a>
    3935:      	movl	%r15d, %ecx
    3938:      	shrl	$0x18, %ecx
    393b:      	andl	$0xf, %ecx
    393e:      	je	0x3a0f <kprobe_unwind_dotnet+0x3a0f>
    3944:      	addq	$-0xc0, %r13
    394b:      	jmp	0x3a1d <kprobe_unwind_dotnet+0x3a1d>
    3950:      	leaq	(%rip), %rsi            # 0x3957 <kprobe_unwind_dotnet+0x3957>
    3957:      	leaq	0x10(%rsp), %rax
    395c:      	movl	$0x8, %ecx
    3961:      	movq	%rax, %rdi
    3964:      	rep		movsq	(%rsi), %es:(%rdi)
    3967:      	movw	$0xa, 0x50(%rsp)
    396e:      	movl	$0x42, %ecx
    3973:      	movl	$0x6, %r9d
    3979:      	movq	%rax, %rdi
    397c:      	movl	$0x42, %esi
    3981:      	movq	%r13, %rdx
    3984:      	movq	%rbx, %rcx
    3987:      	movq	%rbp, %r8
    398a:      	xorl	%eax, %eax
    398c:      	callq	*%r9
    398f:      	jmp	0x34b5 <kprobe_unwind_dotnet+0x34b5>
    3994:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    399e:      	movq	%rax, 0x36(%rsp)
    39a3:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    39ad:      	movq	%rax, 0x30(%rsp)
    39b2:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    39bc:      	movq	%rax, 0x28(%rsp)
    39c1:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    39cb:      	movq	%rax, 0x20(%rsp)
    39d0:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    39da:      	movq	%rax, 0x18(%rsp)
    39df:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    39e9:      	movq	%rax, 0x10(%rsp)
    39ee:      	leaq	0x10(%rsp), %rdi
    39f3:      	movl	$0x2e, %eax
    39f8:      	movl	$0x6, %ecx
    39fd:      	movl	0x68(%rsp), %edx
    3a01:      	movl	$0x2e, %esi
    3a06:      	xorl	%eax, %eax
    3a08:      	callq	*%rcx
    3a0a:      	jmp	0x3367 <kprobe_unwind_dotnet+0x3367>
    3a0f:      	shrl	$0x1c, %r15d
    3a13:      	addq	$-0xe0, %r13
    3a1a:      	movl	%r15d, %ecx
    3a1d:      	addq	%r13, %rbx
    3a20:      	leal	-0x4(,%rcx,4), %r15d
    3a28:      	addq	%rbx, %r15
    3a2b:      	movq	(%rip), %rax            # 0x3a32 <kprobe_unwind_dotnet+0x3a32>
    3a32:      	cmpl	$0x0, (%rax)
    3a35:      	jne	0x3ec7 <kprobe_unwind_dotnet+0x3ec7>
    3a3b:      	leaq	-0x8(%r15), %rdx
    3a3f:      	leaq	0x68(%rsp), %rdi
    3a44:      	movl	$0x8, %eax
    3a49:      	movl	$0x70, %ecx
    3a4e:      	movl	$0x8, %esi
    3a53:      	callq	*%rcx
    3a55:      	testq	%rax, %rax
    3a58:      	movq	(%rip), %rbp            # 0x3a5f <kprobe_unwind_dotnet+0x3a5f>
    3a5f:      	jne	0xbb6 <kprobe_unwind_dotnet+0xbb6>
    3a65:      	movl	$0x1f, %ebp
    3a6a:      	movq	(%rip), %rax            # 0x3a71 <kprobe_unwind_dotnet+0x3a71>
    3a71:      	cmpl	$0x0, (%rax)
    3a74:      	jne	0x3cc3 <kprobe_unwind_dotnet+0x3cc3>
    3a7a:      	movl	0x2c0(%r14), %eax
    3a81:      	cmpq	$0x7e, %rax
    3a85:      	ja	0xc0c <kprobe_unwind_dotnet+0xc0c>
    3a8b:      	movq	0x68(%rsp), %rcx
    3a90:      	subq	%r15, %r12
    3a93:      	shlq	$0x5, %rcx
    3a97:      	addq	%rbp, %rcx
    3a9a:      	leal	0x1(%rax), %edx
    3a9d:      	movl	%edx, 0x2c0(%r14)
    3aa4:      	leaq	(%rax,%rax,2), %rax
    3aa8:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    3ab0:      	movq	%r12, 0x2d8(%r14,%rax,8)
    3ab8:      	movb	$0xa, 0x2e0(%r14,%rax,8)
    3ac1:      	movzbl	0x88(%rsp), %ecx
    3ac9:      	movb	%cl, 0x2e1(%r14,%rax,8)
    3ad1:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    3add:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    3ae8:      	movl	$0x5b, 0xc(%rsp)
    3af0:      	movq	(%rip), %rdi            # 0x3af7 <kprobe_unwind_dotnet+0x3af7>
    3af7:      	leaq	0xc(%rsp), %rsi
    3afc:      	movl	$0x1, %eax
    3b01:      	callq	*%rax
    3b03:      	testq	%rax, %rax
    3b06:      	je	0x3b0d <kprobe_unwind_dotnet+0x3b0d>
    3b08:      	incq	(%rax)
    3b0b:      	jmp	0x3b1d <kprobe_unwind_dotnet+0x3b1d>
    3b0d:      	movq	(%rip), %rax            # 0x3b14 <kprobe_unwind_dotnet+0x3b14>
    3b14:      	cmpl	$0x0, (%rax)
    3b17:      	jne	0x3dbf <kprobe_unwind_dotnet+0x3dbf>
    3b1d:      	movq	0x98(%rsp), %rax
    3b25:      	movq	(%rax), %r13
    3b28:      	movq	(%rip), %rax            # 0x3b2f <kprobe_unwind_dotnet+0x3b2f>
    3b2f:      	movl	(%rax), %eax
    3b31:      	testq	%r13, %r13
    3b34:      	je	0x88ec <kprobe_unwind_dotnet+0x88ec>
    3b3a:      	testl	%eax, %eax
    3b3c:      	jne	0x3d22 <kprobe_unwind_dotnet+0x3d22>
    3b42:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    3b4c:      	cmpq	%rax, %r13
    3b4f:      	ja	0x2516 <kprobe_unwind_dotnet+0x2516>
    3b55:      	cmpq	$0x1000, %r13           # imm = 0x1000
    3b5c:      	jb	0x26b1 <kprobe_unwind_dotnet+0x26b1>
    3b62:      	movl	(%r14), %eax
    3b65:      	movl	$0x60, 0x70(%rsp)
    3b6d:      	movbel	%eax, 0x74(%rsp)
    3b73:      	movbeq	%r13, 0x78(%rsp)
    3b7a:      	movq	(%rip), %rdi            # 0x3b81 <kprobe_unwind_dotnet+0x3b81>
    3b81:      	leaq	0x70(%rsp), %rsi
    3b86:      	movl	$0x1, %eax
    3b8b:      	callq	*%rax
    3b8d:      	testq	%rax, %rax
    3b90:      	je	0x8837 <kprobe_unwind_dotnet+0x8837>
    3b96:      	movq	0x8(%rax), %r12
    3b9a:      	movq	%r12, %rcx
    3b9d:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    3ba7:      	andq	%rdx, %rcx
    3baa:      	movq	%rcx, 0xf20(%r14)
    3bb1:      	movq	(%rax), %rax
    3bb4:      	movq	%rax, 0xf10(%r14)
    3bbb:      	shrq	$0x38, %r12
    3bbf:      	movq	%r13, %rax
    3bc2:      	subq	%rcx, %rax
    3bc5:      	movq	%rax, 0xf18(%r14)
    3bcc:      	movq	(%rip), %rax            # 0x3bd3 <kprobe_unwind_dotnet+0x3bd3>
    3bd3:      	cmpl	$0x0, (%rax)
    3bd6:      	jne	0x3fc1 <kprobe_unwind_dotnet+0x3fc1>
    3bdc:      	cmpl	$0x1, %r12d
    3be0:      	jne	0x48a7 <kprobe_unwind_dotnet+0x48a7>
    3be6:      	movq	0xf10(%r14), %rax
    3bed:      	movq	%rax, 0x70(%rsp)
    3bf2:      	movq	0xf18(%r14), %rbx
    3bf9:      	movq	(%rip), %rdi            # 0x3c00 <kprobe_unwind_dotnet+0x3c00>
    3c00:      	leaq	0x70(%rsp), %rsi
    3c05:      	movl	$0x1, %eax
    3c0a:      	callq	*%rax
    3c0c:      	movl	$0x1, %r12d
    3c12:      	testq	%rax, %rax
    3c15:      	je	0x48a7 <kprobe_unwind_dotnet+0x48a7>
    3c1b:      	movq	%rax, %r15
    3c1e:      	cmpq	%rbx, (%rax)
    3c21:      	ja	0x3c29 <kprobe_unwind_dotnet+0x3c29>
    3c23:      	cmpq	%rbx, 0x8(%r15)
    3c27:      	jae	0x3c3d <kprobe_unwind_dotnet+0x3c3d>
    3c29:      	cmpq	%rbx, 0x10(%r15)
    3c2d:      	ja	0x48a7 <kprobe_unwind_dotnet+0x48a7>
    3c33:      	cmpq	%rbx, 0x18(%r15)
    3c37:      	jb	0x48a7 <kprobe_unwind_dotnet+0x48a7>
    3c3d:      	movq	(%rip), %rax            # 0x3c44 <kprobe_unwind_dotnet+0x3c44>
    3c44:      	cmpl	$0x0, (%rax)
    3c47:      	jne	0x4800 <kprobe_unwind_dotnet+0x4800>
    3c4d:      	movl	0x1380(%r14), %eax
    3c54:      	movl	0x20(%r15), %ecx
    3c58:      	btl	%ecx, %eax
    3c5b:      	jae	0x486d <kprobe_unwind_dotnet+0x486d>
    3c61:      	movq	(%rip), %rax            # 0x3c68 <kprobe_unwind_dotnet+0x3c68>
    3c68:      	cmpl	$0x0, (%rax)
    3c6b:      	je	0x48a7 <kprobe_unwind_dotnet+0x48a7>
    3c71:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    3c7b:      	movq	%rax, 0x20(%rsp)
    3c80:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    3c8a:      	movq	%rax, 0x18(%rsp)
    3c8f:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    3c99:      	movq	%rax, 0x10(%rsp)
    3c9e:      	movl	$0xa656e, 0x27(%rsp)    # imm = 0xA656E
    3ca6:      	leaq	0x10(%rsp), %rdi
    3cab:      	movl	$0x1b, %eax
    3cb0:      	movl	$0x6, %ecx
    3cb5:      	movl	$0x1b, %esi
    3cba:      	xorl	%eax, %eax
    3cbc:      	callq	*%rcx
    3cbe:      	jmp	0x48a7 <kprobe_unwind_dotnet+0x48a7>
    3cc3:      	leaq	(%rip), %rsi            # 0x3cca <kprobe_unwind_dotnet+0x3cca>
    3cca:      	leaq	0x10(%rsp), %rax
    3ccf:      	movl	$0x8, %ecx
    3cd4:      	movq	%rax, %rdi
    3cd7:      	rep		movsq	(%rsi), %es:(%rdi)
    3cda:      	movb	$0x0, 0x52(%rsp)
    3cdf:      	movw	$0xa78, 0x50(%rsp)      # imm = 0xA78
    3ce6:      	movl	$0x43, %ecx
    3ceb:      	movl	$0x6, %r9d
    3cf1:      	movq	0x68(%rsp), %rcx
    3cf6:      	movq	%r12, %r8
    3cf9:      	subq	%r15, %r8
    3cfc:      	movq	%rax, %rdi
    3cff:      	movl	$0x43, %esi
    3d04:      	movq	%r15, %rdx
    3d07:      	xorl	%eax, %eax
    3d09:      	callq	*%r9
    3d0c:      	movl	0x2c0(%r14), %eax
    3d13:      	cmpq	$0x7e, %rax
    3d17:      	ja	0xc0c <kprobe_unwind_dotnet+0xc0c>
    3d1d:      	jmp	0x3a8b <kprobe_unwind_dotnet+0x3a8b>
    3d22:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    3d2c:      	movq	%rax, 0x38(%rsp)
    3d31:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    3d3b:      	movq	%rax, 0x30(%rsp)
    3d40:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    3d4a:      	movq	%rax, 0x28(%rsp)
    3d4f:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    3d59:      	movq	%rax, 0x20(%rsp)
    3d5e:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    3d68:      	movq	%rax, 0x18(%rsp)
    3d6d:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    3d77:      	movq	%rax, 0x10(%rsp)
    3d7c:      	movb	$0x0, 0x40(%rsp)
    3d81:      	leaq	0x10(%rsp), %rdi
    3d86:      	movl	$0x31, %eax
    3d8b:      	movl	$0x6, %ecx
    3d90:      	movl	0x2c0(%r14), %edx
    3d97:      	movl	$0x31, %esi
    3d9c:      	xorl	%eax, %eax
    3d9e:      	callq	*%rcx
    3da0:      	movq	0xed0(%r14), %r13
    3da7:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    3db1:      	cmpq	%rax, %r13
    3db4:      	ja	0x2516 <kprobe_unwind_dotnet+0x2516>
    3dba:      	jmp	0x3b55 <kprobe_unwind_dotnet+0x3b55>
    3dbf:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3dc9:      	movq	%rax, 0x36(%rsp)
    3dce:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3dd8:      	movq	%rax, 0x30(%rsp)
    3ddd:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3de7:      	movq	%rax, 0x28(%rsp)
    3dec:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3df6:      	movq	%rax, 0x20(%rsp)
    3dfb:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3e05:      	movq	%rax, 0x18(%rsp)
    3e0a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3e14:      	movq	%rax, 0x10(%rsp)
    3e19:      	leaq	0x10(%rsp), %rdi
    3e1e:      	movl	$0x2e, %eax
    3e23:      	movl	$0x6, %ecx
    3e28:      	movl	0xc(%rsp), %edx
    3e2c:      	movl	$0x2e, %esi
    3e31:      	xorl	%eax, %eax
    3e33:      	callq	*%rcx
    3e35:      	jmp	0x3b1d <kprobe_unwind_dotnet+0x3b1d>
    3e3a:      	movabsq	$0xa782520797274, %rax  # imm = 0xA782520797274
    3e44:      	movq	%rax, 0x3e(%rsp)
    3e49:      	movabsq	$0x72746e6520747372, %rax # imm = 0x72746E6520747372
    3e53:      	movq	%rax, 0x38(%rsp)
    3e58:      	movabsq	$0x6966203a786c2520, %rax # imm = 0x6966203A786C2520
    3e62:      	movq	%rax, 0x30(%rsp)
    3e67:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    3e71:      	movq	%rax, 0x28(%rsp)
    3e76:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    3e80:      	movq	%rax, 0x20(%rsp)
    3e85:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    3e8f:      	movq	%rax, 0x18(%rsp)
    3e94:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    3e9e:      	movq	%rax, 0x10(%rsp)
    3ea3:      	leaq	0x10(%rsp), %rdi
    3ea8:      	movl	$0x36, %eax
    3ead:      	movl	$0x6, %r8d
    3eb3:      	movl	$0x36, %esi
    3eb8:      	movq	%r15, %rdx
    3ebb:      	movl	%ebp, %ecx
    3ebd:      	xorl	%eax, %eax
    3ebf:      	callq	*%r8
    3ec2:      	jmp	0x3568 <kprobe_unwind_dotnet+0x3568>
    3ec7:      	movabsq	$0xa786c253d7465, %rax  # imm = 0xA786C253D7465
    3ed1:      	movq	%rax, 0x36(%rsp)
    3ed6:      	movabsq	$0x746572202c78253d, %rax # imm = 0x746572202C78253D
    3ee0:      	movq	%rax, 0x30(%rsp)
    3ee5:      	movabsq	$0x6c6176202c786c25, %rax # imm = 0x6C6176202C786C25
    3eef:      	movq	%rax, 0x28(%rsp)
    3ef4:      	movabsq	$0x203d2061746c6564, %rax # imm = 0x203D2061746C6564
    3efe:      	movq	%rax, 0x20(%rsp)
    3f03:      	movabsq	$0x5f6370203e2d2d20, %rax # imm = 0x5F6370203E2D2D20
    3f0d:      	movq	%rax, 0x18(%rsp)
    3f12:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    3f1c:      	movq	%rax, 0x10(%rsp)
    3f21:      	leaq	0x10(%rsp), %rdi
    3f26:      	movl	$0x2e, %eax
    3f2b:      	movl	$0x6, %r9d
    3f31:      	movl	$0x2e, %esi
    3f36:      	movq	%r13, %rdx
    3f39:      	movq	%r15, %r8
    3f3c:      	xorl	%eax, %eax
    3f3e:      	callq	*%r9
    3f41:      	jmp	0x3a3b <kprobe_unwind_dotnet+0x3a3b>
    3f46:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    3f50:      	movq	%rax, 0x36(%rsp)
    3f55:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    3f5f:      	movq	%rax, 0x30(%rsp)
    3f64:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    3f6e:      	movq	%rax, 0x28(%rsp)
    3f73:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    3f7d:      	movq	%rax, 0x20(%rsp)
    3f82:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    3f8c:      	movq	%rax, 0x18(%rsp)
    3f91:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    3f9b:      	movq	%rax, 0x10(%rsp)
    3fa0:      	leaq	0x10(%rsp), %rdi
    3fa5:      	movl	$0x2e, %eax
    3faa:      	movl	$0x6, %ecx
    3faf:      	movl	0xc(%rsp), %edx
    3fb3:      	movl	$0x2e, %esi
    3fb8:      	xorl	%eax, %eax
    3fba:      	callq	*%rcx
    3fbc:      	jmp	0x35cc <kprobe_unwind_dotnet+0x35cc>
    3fc1:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    3fcb:      	movq	%rax, 0x38(%rsp)
    3fd0:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    3fda:      	movq	%rax, 0x30(%rsp)
    3fdf:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    3fe9:      	movq	%rax, 0x28(%rsp)
    3fee:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    3ff8:      	movq	%rax, 0x20(%rsp)
    3ffd:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    4007:      	movq	%rax, 0x18(%rsp)
    400c:      	movabsq	$0x6365732074786554, %rbx # imm = 0x6365732074786554
    4016:      	movq	%rbx, 0x10(%rsp)
    401b:      	movw	$0xa, 0x40(%rsp)
    4022:      	leaq	0x10(%rsp), %rdi
    4027:      	movl	$0x32, %eax
    402c:      	movl	$0x6, %r9d
    4032:      	movq	0xf10(%r14), %rcx
    4039:      	movl	$0x32, %esi
    403e:      	movq	%r13, %rdx
    4041:      	movl	%r12d, %r8d
    4044:      	xorl	%eax, %eax
    4046:      	callq	*%r9
    4049:      	movq	(%rip), %rax            # 0x4050 <kprobe_unwind_dotnet+0x4050>
    4050:      	cmpl	$0x0, (%rax)
    4053:      	je	0x3bdc <kprobe_unwind_dotnet+0x3bdc>
    4059:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    4063:      	movq	%rax, 0x37(%rsp)
    4068:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    4072:      	movq	%rax, 0x30(%rsp)
    4077:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    4081:      	movq	%rax, 0x28(%rsp)
    4086:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    4090:      	movq	%rax, 0x20(%rsp)
    4095:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    409f:      	movq	%rax, 0x18(%rsp)
    40a4:      	movq	%rbx, 0x10(%rsp)
    40a9:      	leaq	0x10(%rsp), %rdi
    40ae:      	movl	$0x2f, %eax
    40b3:      	movl	$0x6, %r8d
    40b9:      	movq	0xf18(%r14), %rcx
    40c0:      	movq	0xf20(%r14), %rdx
    40c7:      	movl	$0x2f, %esi
    40cc:      	xorl	%eax, %eax
    40ce:      	callq	*%r8
    40d1:      	jmp	0x3bdc <kprobe_unwind_dotnet+0x3bdc>
    40d6:      	movabsq	$0xa782520797274, %rax  # imm = 0xA782520797274
    40e0:      	movq	%rax, 0x3f(%rsp)
    40e5:      	movabsq	$0x746e6520646e6f63, %rax # imm = 0x746E6520646E6F63
    40ef:      	movq	%rax, 0x38(%rsp)
    40f4:      	movabsq	$0x6573203a786c2520, %rax # imm = 0x6573203A786C2520
    40fe:      	movq	%rax, 0x30(%rsp)
    4103:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    410d:      	movq	%rax, 0x28(%rsp)
    4112:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    411c:      	movq	%rax, 0x20(%rsp)
    4121:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    412b:      	movq	%rax, 0x18(%rsp)
    4130:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    413a:      	movq	%rax, 0x10(%rsp)
    413f:      	leaq	0x10(%rsp), %rdi
    4144:      	movl	$0x37, %eax
    4149:      	movl	$0x6, %r8d
    414f:      	movl	$0x37, %esi
    4154:      	movq	%r13, %rdx
    4157:      	movl	%r15d, %ecx
    415a:      	xorl	%eax, %eax
    415c:      	callq	*%r8
    415f:      	xorl	%ecx, %ecx
    4161:      	testl	%r15d, %r15d
    4164:      	jne	0x3686 <kprobe_unwind_dotnet+0x3686>
    416a:      	movq	0x1170(%r14), %rax
    4171:      	movl	$0xffffff84, %ecx       # imm = 0xFFFFFF84
    4176:      	testq	%rax, %rax
    4179:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    417f:      	movq	0x1168(%r14), %rax
    4186:      	movl	$0xffffff86, %ecx       # imm = 0xFFFFFF86
    418b:      	testq	%rax, %rax
    418e:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    4194:      	movq	0x1160(%r14), %rax
    419b:      	movl	$0xffffff88, %ecx       # imm = 0xFFFFFF88
    41a0:      	testq	%rax, %rax
    41a3:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    41a9:      	movq	0x1158(%r14), %rax
    41b0:      	movl	$0xffffff8a, %ecx       # imm = 0xFFFFFF8A
    41b5:      	testq	%rax, %rax
    41b8:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    41be:      	movq	0x1150(%r14), %rax
    41c5:      	movl	$0xffffff8c, %ecx       # imm = 0xFFFFFF8C
    41ca:      	testq	%rax, %rax
    41cd:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    41d3:      	movq	0x1148(%r14), %rax
    41da:      	movl	$0xffffff8e, %ecx       # imm = 0xFFFFFF8E
    41df:      	testq	%rax, %rax
    41e2:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    41e8:      	movq	0x1140(%r14), %rax
    41ef:      	movl	$0xffffff90, %ecx       # imm = 0xFFFFFF90
    41f4:      	testq	%rax, %rax
    41f7:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    41fd:      	movq	0x1138(%r14), %rax
    4204:      	movl	$0xffffff92, %ecx       # imm = 0xFFFFFF92
    4209:      	testq	%rax, %rax
    420c:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    4212:      	movq	0x1130(%r14), %rax
    4219:      	movl	$0xffffff94, %ecx       # imm = 0xFFFFFF94
    421e:      	testq	%rax, %rax
    4221:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    4227:      	movq	0x1128(%r14), %rax
    422e:      	movl	$0xffffff96, %ecx       # imm = 0xFFFFFF96
    4233:      	testq	%rax, %rax
    4236:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    423c:      	movq	0x1120(%r14), %rax
    4243:      	movl	$0xffffff98, %ecx       # imm = 0xFFFFFF98
    4248:      	testq	%rax, %rax
    424b:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    4251:      	movq	0x1118(%r14), %rax
    4258:      	movl	$0xffffff9a, %ecx       # imm = 0xFFFFFF9A
    425d:      	testq	%rax, %rax
    4260:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    4266:      	movq	0x1110(%r14), %rax
    426d:      	movl	$0xffffff9c, %ecx       # imm = 0xFFFFFF9C
    4272:      	testq	%rax, %rax
    4275:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    427b:      	movq	0x1108(%r14), %rax
    4282:      	movl	$0xffffff9e, %ecx       # imm = 0xFFFFFF9E
    4287:      	testq	%rax, %rax
    428a:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    4290:      	movq	0x1100(%r14), %rax
    4297:      	movl	$0xffffffa0, %ecx       # imm = 0xFFFFFFA0
    429c:      	testq	%rax, %rax
    429f:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    42a5:      	movq	0x10f8(%r14), %rax
    42ac:      	movl	$0xffffffa2, %ecx       # imm = 0xFFFFFFA2
    42b1:      	testq	%rax, %rax
    42b4:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    42ba:      	movq	0x10f0(%r14), %rax
    42c1:      	movl	$0xffffffa4, %ecx       # imm = 0xFFFFFFA4
    42c6:      	testq	%rax, %rax
    42c9:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    42cf:      	movq	0x10e8(%r14), %rax
    42d6:      	movl	$0xffffffa6, %ecx       # imm = 0xFFFFFFA6
    42db:      	testq	%rax, %rax
    42de:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    42e4:      	movq	0x10e0(%r14), %rax
    42eb:      	movl	$0xffffffa8, %ecx       # imm = 0xFFFFFFA8
    42f0:      	testq	%rax, %rax
    42f3:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    42f9:      	movq	0x10d8(%r14), %rax
    4300:      	movl	$0xffffffaa, %ecx       # imm = 0xFFFFFFAA
    4305:      	testq	%rax, %rax
    4308:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    430e:      	movq	0x10d0(%r14), %rax
    4315:      	movl	$0xffffffac, %ecx       # imm = 0xFFFFFFAC
    431a:      	testq	%rax, %rax
    431d:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    4323:      	movq	0x10c8(%r14), %rax
    432a:      	movl	$0xffffffae, %ecx       # imm = 0xFFFFFFAE
    432f:      	testq	%rax, %rax
    4332:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    4338:      	movq	0x10c0(%r14), %rax
    433f:      	movl	$0xffffffb0, %ecx       # imm = 0xFFFFFFB0
    4344:      	testq	%rax, %rax
    4347:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    434d:      	movq	0x10b8(%r14), %rax
    4354:      	movl	$0xffffffb2, %ecx       # imm = 0xFFFFFFB2
    4359:      	testq	%rax, %rax
    435c:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    4362:      	movq	0x10b0(%r14), %rax
    4369:      	movl	$0xffffffb4, %ecx       # imm = 0xFFFFFFB4
    436e:      	testq	%rax, %rax
    4371:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    4377:      	movq	0x10a8(%r14), %rax
    437e:      	movl	$0xffffffb6, %ecx       # imm = 0xFFFFFFB6
    4383:      	testq	%rax, %rax
    4386:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    438c:      	movq	0x10a0(%r14), %rax
    4393:      	movl	$0xffffffb8, %ecx       # imm = 0xFFFFFFB8
    4398:      	testq	%rax, %rax
    439b:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    43a1:      	movq	0x1098(%r14), %rax
    43a8:      	movl	$0xffffffba, %ecx       # imm = 0xFFFFFFBA
    43ad:      	testq	%rax, %rax
    43b0:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    43b6:      	movq	0x1090(%r14), %rax
    43bd:      	movl	$0xffffffbc, %ecx       # imm = 0xFFFFFFBC
    43c2:      	testq	%rax, %rax
    43c5:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    43cb:      	movq	0x1088(%r14), %rax
    43d2:      	movl	$0xffffffbe, %ecx       # imm = 0xFFFFFFBE
    43d7:      	testq	%rax, %rax
    43da:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    43e0:      	movq	0x1080(%r14), %rax
    43e7:      	movl	$0xffffffc0, %ecx       # imm = 0xFFFFFFC0
    43ec:      	testq	%rax, %rax
    43ef:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    43f5:      	movq	0x1078(%r14), %rax
    43fc:      	movl	$0xffffffc2, %ecx       # imm = 0xFFFFFFC2
    4401:      	testq	%rax, %rax
    4404:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    440a:      	movq	0x1070(%r14), %rax
    4411:      	movl	$0xffffffc4, %ecx       # imm = 0xFFFFFFC4
    4416:      	testq	%rax, %rax
    4419:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    441f:      	movq	0x1068(%r14), %rax
    4426:      	movl	$0xffffffc6, %ecx       # imm = 0xFFFFFFC6
    442b:      	testq	%rax, %rax
    442e:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    4434:      	movq	0x1060(%r14), %rax
    443b:      	movl	$0xffffffc8, %ecx       # imm = 0xFFFFFFC8
    4440:      	testq	%rax, %rax
    4443:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    4449:      	movq	0x1058(%r14), %rax
    4450:      	movl	$0xffffffca, %ecx       # imm = 0xFFFFFFCA
    4455:      	testq	%rax, %rax
    4458:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    445e:      	movq	0x1050(%r14), %rax
    4465:      	movl	$0xffffffcc, %ecx       # imm = 0xFFFFFFCC
    446a:      	testq	%rax, %rax
    446d:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    4473:      	movq	0x1048(%r14), %rax
    447a:      	movl	$0xffffffce, %ecx       # imm = 0xFFFFFFCE
    447f:      	testq	%rax, %rax
    4482:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    4488:      	movq	0x1040(%r14), %rax
    448f:      	movl	$0xffffffd0, %ecx       # imm = 0xFFFFFFD0
    4494:      	testq	%rax, %rax
    4497:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    449d:      	movq	0x1038(%r14), %rax
    44a4:      	movl	$0xffffffd2, %ecx       # imm = 0xFFFFFFD2
    44a9:      	testq	%rax, %rax
    44ac:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    44b2:      	movq	0x1030(%r14), %rax
    44b9:      	movl	$0xffffffd4, %ecx       # imm = 0xFFFFFFD4
    44be:      	testq	%rax, %rax
    44c1:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    44c7:      	movq	0x1028(%r14), %rax
    44ce:      	movl	$0xffffffd6, %ecx       # imm = 0xFFFFFFD6
    44d3:      	testq	%rax, %rax
    44d6:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    44dc:      	movq	0x1020(%r14), %rax
    44e3:      	movl	$0xffffffd8, %ecx       # imm = 0xFFFFFFD8
    44e8:      	testq	%rax, %rax
    44eb:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    44f1:      	movq	0x1018(%r14), %rax
    44f8:      	movl	$0xffffffda, %ecx       # imm = 0xFFFFFFDA
    44fd:      	testq	%rax, %rax
    4500:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    4506:      	movq	0x1010(%r14), %rax
    450d:      	movl	$0xffffffdc, %ecx       # imm = 0xFFFFFFDC
    4512:      	testq	%rax, %rax
    4515:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    451b:      	movq	0x1008(%r14), %rax
    4522:      	movl	$0xffffffde, %ecx       # imm = 0xFFFFFFDE
    4527:      	testq	%rax, %rax
    452a:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    4530:      	movq	0x1000(%r14), %rax
    4537:      	movl	$0xffffffe0, %ecx       # imm = 0xFFFFFFE0
    453c:      	testq	%rax, %rax
    453f:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    4545:      	movq	0xff8(%r14), %rax
    454c:      	movl	$0xffffffe2, %ecx       # imm = 0xFFFFFFE2
    4551:      	testq	%rax, %rax
    4554:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    455a:      	movq	0xff0(%r14), %rax
    4561:      	movl	$0xffffffe4, %ecx       # imm = 0xFFFFFFE4
    4566:      	testq	%rax, %rax
    4569:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    456f:      	movq	0xfe8(%r14), %rax
    4576:      	movl	$0xffffffe6, %ecx       # imm = 0xFFFFFFE6
    457b:      	testq	%rax, %rax
    457e:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    4584:      	movq	0xfe0(%r14), %rax
    458b:      	movl	$0xffffffe8, %ecx       # imm = 0xFFFFFFE8
    4590:      	testq	%rax, %rax
    4593:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    4599:      	movq	0xfd8(%r14), %rax
    45a0:      	movl	$0xffffffea, %ecx       # imm = 0xFFFFFFEA
    45a5:      	testq	%rax, %rax
    45a8:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    45ae:      	movq	0xfd0(%r14), %rax
    45b5:      	movl	$0xffffffec, %ecx       # imm = 0xFFFFFFEC
    45ba:      	testq	%rax, %rax
    45bd:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    45c3:      	movq	0xfc8(%r14), %rax
    45ca:      	movl	$0xffffffee, %ecx       # imm = 0xFFFFFFEE
    45cf:      	testq	%rax, %rax
    45d2:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    45d8:      	movq	0xfc0(%r14), %rax
    45df:      	movl	$0xfffffff0, %ecx       # imm = 0xFFFFFFF0
    45e4:      	testq	%rax, %rax
    45e7:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    45ed:      	movq	0xfb8(%r14), %rax
    45f4:      	movl	$0xfffffff2, %ecx       # imm = 0xFFFFFFF2
    45f9:      	testq	%rax, %rax
    45fc:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    45fe:      	movq	0xfb0(%r14), %rax
    4605:      	movl	$0xfffffff4, %ecx       # imm = 0xFFFFFFF4
    460a:      	testq	%rax, %rax
    460d:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    460f:      	movq	0xfa8(%r14), %rax
    4616:      	movl	$0xfffffff6, %ecx       # imm = 0xFFFFFFF6
    461b:      	testq	%rax, %rax
    461e:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    4620:      	movq	0xfa0(%r14), %rax
    4627:      	movl	$0xfffffff8, %ecx       # imm = 0xFFFFFFF8
    462c:      	testq	%rax, %rax
    462f:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    4631:      	movq	0xf98(%r14), %rax
    4638:      	movl	$0xfffffffa, %ecx       # imm = 0xFFFFFFFA
    463d:      	testq	%rax, %rax
    4640:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    4642:      	movq	0xf90(%r14), %rax
    4649:      	movl	$0xfffffffc, %ecx       # imm = 0xFFFFFFFC
    464e:      	testq	%rax, %rax
    4651:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    4653:      	movq	0xf88(%r14), %rax
    465a:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    465f:      	testq	%rax, %rax
    4662:      	jne	0x4671 <kprobe_unwind_dotnet+0x4671>
    4664:      	movq	0x90(%rsp), %rax
    466c:      	movq	(%rax), %rax
    466f:      	xorl	%ecx, %ecx
    4671:      	xorl	%edx, %edx
    4673:      	movq	%rax, %r15
    4676:      	shrq	$0x20, %r15
    467a:      	setne	%dl
    467d:      	cmovel	%eax, %r15d
    4681:      	subl	%edx, %ecx
    4683:      	addl	$0x7e, %ecx
    4686:      	movl	%ecx, %eax
    4688:      	shll	$0x8, %eax
    468b:      	subq	%rax, %r13
    468e:      	jb	0x3694 <kprobe_unwind_dotnet+0x3694>
    4694:      	movq	(%rip), %rax            # 0x469b <kprobe_unwind_dotnet+0x469b>
    469b:      	cmpl	$0x0, (%rax)
    469e:      	jne	0x4761 <kprobe_unwind_dotnet+0x4761>
    46a4:      	testl	%r15d, %r15d
    46a7:      	jne	0x3598 <kprobe_unwind_dotnet+0x3598>
    46ad:      	movl	$0x5f, 0xc(%rsp)
    46b5:      	movq	(%rip), %rdi            # 0x46bc <kprobe_unwind_dotnet+0x46bc>
    46bc:      	leaq	0xc(%rsp), %rsi
    46c1:      	movl	$0x1, %eax
    46c6:      	callq	*%rax
    46c8:      	testq	%rax, %rax
    46cb:      	je	0x46d2 <kprobe_unwind_dotnet+0x46d2>
    46cd:      	incq	(%rax)
    46d0:      	jmp	0x46e2 <kprobe_unwind_dotnet+0x46e2>
    46d2:      	movq	(%rip), %rax            # 0x46d9 <kprobe_unwind_dotnet+0x46d9>
    46d9:      	cmpl	$0x0, (%rax)
    46dc:      	jne	0x4d70 <kprobe_unwind_dotnet+0x4d70>
    46e2:      	movl	$0x1773, %edx           # imm = 0x1773
    46e7:      	movb	$0x1, %bl
    46e9:      	movq	(%rip), %rax            # 0x46f0 <kprobe_unwind_dotnet+0x46f0>
    46f0:      	cmpl	$0x0, (%rax)
    46f3:      	je	0x35e3 <kprobe_unwind_dotnet+0x35e3>
    46f9:      	movabsq	$0xa642520687469, %rax  # imm = 0xA642520687469
    4703:      	movq	%rax, 0x30(%rsp)
    4708:      	movabsq	$0x772064656c696166, %rax # imm = 0x772064656C696166
    4712:      	movq	%rax, 0x28(%rsp)
    4717:      	movabsq	$0x2074726174735f65, %rax # imm = 0x2074726174735F65
    4721:      	movq	%rax, 0x20(%rsp)
    4726:      	movabsq	$0x646f63203e2d2d20, %rax # imm = 0x646F63203E2D2D20
    4730:      	movq	%rax, 0x18(%rsp)
    4735:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    473f:      	movq	%rax, 0x10(%rsp)
    4744:      	leaq	0x10(%rsp), %rdi
    4749:      	movl	$0x28, %eax
    474e:      	movl	$0x6, %ecx
    4753:      	movl	$0x28, %esi
    4758:      	xorl	%eax, %eax
    475a:      	callq	*%rcx
    475c:      	jmp	0x35e3 <kprobe_unwind_dotnet+0x35e3>
    4761:      	movabsq	$0x207972746e65202c, %rax # imm = 0x207972746E65202C
    476b:      	movq	%rax, 0x40(%rsp)
    4770:      	movabsq	$0x6425206465707069, %rax # imm = 0x6425206465707069
    477a:      	movq	%rax, 0x38(%rsp)
    477f:      	movabsq	$0x6b73203a786c2520, %rax # imm = 0x6B73203A786C2520
    4789:      	movq	%rax, 0x30(%rsp)
    478e:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    4798:      	movq	%rax, 0x28(%rsp)
    479d:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    47a7:      	movq	%rax, 0x20(%rsp)
    47ac:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    47b6:      	movq	%rax, 0x18(%rsp)
    47bb:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    47c5:      	movq	%rax, 0x10(%rsp)
    47ca:      	movl	$0xa7825, 0x48(%rsp)    # imm = 0xA7825
    47d2:      	leaq	0x10(%rsp), %rdi
    47d7:      	movl	$0x3c, %eax
    47dc:      	movl	$0x6, %r9d
    47e2:      	movl	$0x3c, %esi
    47e7:      	movq	%r13, %rdx
    47ea:      	movl	%r15d, %r8d
    47ed:      	xorl	%eax, %eax
    47ef:      	callq	*%r9
    47f2:      	testl	%r15d, %r15d
    47f5:      	jne	0x3598 <kprobe_unwind_dotnet+0x3598>
    47fb:      	jmp	0x46ad <kprobe_unwind_dotnet+0x46ad>
    4800:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    480a:      	movq	%rax, 0x26(%rsp)
    480f:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    4819:      	movq	%rax, 0x20(%rsp)
    481e:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    4828:      	movq	%rax, 0x18(%rsp)
    482d:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    4837:      	movq	%rax, 0x10(%rsp)
    483c:      	leaq	0x10(%rsp), %rdi
    4841:      	movl	$0x1e, %eax
    4846:      	movl	$0x6, %ecx
    484b:      	movzwl	0x20(%r15), %edx
    4850:      	movl	$0x1e, %esi
    4855:      	xorl	%eax, %eax
    4857:      	callq	*%rcx
    4859:      	movl	0x1380(%r14), %eax
    4860:      	movl	0x20(%r15), %ecx
    4864:      	btl	%ecx, %eax
    4867:      	jb	0x3c61 <kprobe_unwind_dotnet+0x3c61>
    486d:      	movl	$0x0, 0x68(%rsp)
    4875:      	movq	(%rip), %rdi            # 0x487c <kprobe_unwind_dotnet+0x487c>
    487c:      	leaq	0x68(%rsp), %rsi
    4881:      	movl	$0x1, %eax
    4886:      	callq	*%rax
    4888:      	testq	%rax, %rax
    488b:      	je	0x4892 <kprobe_unwind_dotnet+0x4892>
    488d:      	incq	(%rax)
    4890:      	jmp	0x48a2 <kprobe_unwind_dotnet+0x48a2>
    4892:      	movq	(%rip), %rax            # 0x4899 <kprobe_unwind_dotnet+0x4899>
    4899:      	cmpl	$0x0, (%rax)
    489c:      	jne	0x4ecf <kprobe_unwind_dotnet+0x4ecf>
    48a2:      	movzwl	0x20(%r15), %r12d
    48a7:      	cmpl	$0x8, %r12d
    48ab:      	jne	0x8da3 <kprobe_unwind_dotnet+0x8da3>
    48b1:      	movq	0xed0(%r14), %r12
    48b8:      	movq	0xed8(%r14), %rbx
    48bf:      	movq	0xee0(%r14), %r13
    48c6:      	movzbl	0xf30(%r14), %eax
    48ce:      	movb	%al, 0x88(%rsp)
    48d5:      	movq	(%rip), %rax            # 0x48dc <kprobe_unwind_dotnet+0x48dc>
    48dc:      	cmpl	$0x0, (%rax)
    48df:      	jne	0x4ccc <kprobe_unwind_dotnet+0x4ccc>
    48e5:      	cmpq	%rbx, %r13
    48e8:      	jb	0x77bb <kprobe_unwind_dotnet+0x77bb>
    48ee:      	leaq	0x2000(%rbx), %rax
    48f5:      	cmpq	%rax, %r13
    48f8:      	jae	0x77bb <kprobe_unwind_dotnet+0x77bb>
    48fe:      	movq	0xf10(%r14), %rbp
    4905:      	movq	0xf20(%r14), %r15
    490c:      	movq	%r12, 0x68(%rsp)
    4911:      	movb	$0x1, 0xf30(%r14)
    4919:      	movq	%rbp, %rax
    491c:      	andq	$-0x80, %rax
    4920:      	cmpq	$0x80, %rax
    4926:      	jne	0x496a <kprobe_unwind_dotnet+0x496a>
    4928:      	movq	0xed8(%r14), %rax
    492f:      	movl	$0x8, %ecx
    4934:      	movl	$0x70, %r8d
    493a:      	movq	0x98(%rsp), %rdi
    4942:      	movq	0xed8(%r14), %rdx
    4949:      	movl	$0x8, %esi
    494e:      	callq	*%r8
    4951:      	testq	%rax, %rax
    4954:      	jne	0x19c <kprobe_unwind_dotnet+0x19c>
    495a:      	addq	$0x8, 0xed8(%r14)
    4962:      	andl	$0x7f, %ebp
    4965:      	jmp	0x4fa5 <kprobe_unwind_dotnet+0x4fa5>
    496a:      	leaq	0x70(%rsp), %rdi
    496f:      	movl	$0x10, %eax
    4974:      	movl	$0x70, %ecx
    4979:      	movl	$0x10, %esi
    497e:      	movq	%r13, %rdx
    4981:      	callq	*%rcx
    4983:      	testq	%rax, %rax
    4986:      	jne	0x26c <kprobe_unwind_dotnet+0x26c>
    498c:      	addq	$0x10, %r13
    4990:      	movq	%r13, 0xed8(%r14)
    4997:      	movq	0x70(%rsp), %rax
    499c:      	movq	%rax, 0xee0(%r14)
    49a3:      	movq	0x78(%rsp), %rax
    49a8:      	movq	%rax, 0xed0(%r14)
    49af:      	movq	(%rip), %rax            # 0x49b6 <kprobe_unwind_dotnet+0x49b6>
    49b6:      	cmpl	$0x0, (%rax)
    49b9:      	jne	0x4deb <kprobe_unwind_dotnet+0x4deb>
    49bf:      	cmpq	$0x100, %rbp            # imm = 0x100
    49c6:      	jb	0x4fa5 <kprobe_unwind_dotnet+0x4fa5>
    49cc:      	movq	0xf10(%r14), %rbp
    49d3:      	movq	0xf20(%r14), %rbx
    49da:      	movq	%r12, %r13
    49dd:      	subq	%rbx, %r13
    49e0:      	movq	(%rip), %rax            # 0x49e7 <kprobe_unwind_dotnet+0x49e7>
    49e7:      	cmpl	$0x0, (%rax)
    49ea:      	jne	0x4e8b <kprobe_unwind_dotnet+0x4e8b>
    49f0:      	movq	%r13, %r15
    49f3:      	andq	$-0x4, %r15
    49f7:      	movl	$0x100, %ecx            # imm = 0x100
    49fc:      	movq	%r15, %rax
    49ff:      	xorl	%edx, %edx
    4a01:      	divq	%rcx
    4a04:      	movq	%rax, %rcx
    4a07:      	movl	$0x7f, %eax
    4a0c:      	subq	%rcx, %rax
    4a0f:      	jns	0x4a28 <kprobe_unwind_dotnet+0x4a28>
    4a11:      	movl	$0x100, %ecx            # imm = 0x100
    4a16:      	movq	%r15, %rax
    4a19:      	xorl	%edx, %edx
    4a1b:      	divq	%rcx
    4a1e:      	leaq	-0x3fc(%rbp,%rax,4), %rbp
    4a26:      	xorl	%eax, %eax
    4a28:      	movl	$0x80, %ecx
    4a2d:      	cqto
    4a2f:      	idivq	%rcx
    4a32:      	movq	0x90(%rsp), %rax
    4a3a:      	leaq	(%rax,%rdx,4), %rdi
    4a3e:      	movl	$0x200, %eax            # imm = 0x200
    4a43:      	movl	$0x70, %ecx
    4a48:      	movl	$0x200, %esi            # imm = 0x200
    4a4d:      	movq	%rbp, %rdx
    4a50:      	callq	*%rcx
    4a52:      	testq	%rax, %rax
    4a55:      	je	0x4a8c <kprobe_unwind_dotnet+0x4a8c>
    4a57:      	movq	(%rip), %rax            # 0x4a5e <kprobe_unwind_dotnet+0x4a5e>
    4a5e:      	cmpl	$0x0, (%rax)
    4a61:      	jne	0x4c61 <kprobe_unwind_dotnet+0x4c61>
    4a67:      	movl	$0x5e, 0xc(%rsp)
    4a6f:      	movq	(%rip), %rdi            # 0x4a76 <kprobe_unwind_dotnet+0x4a76>
    4a76:      	leaq	0xc(%rsp), %rsi
    4a7b:      	movl	$0x1, %eax
    4a80:      	callq	*%rax
    4a82:      	testq	%rax, %rax
    4a85:      	je	0x4af7 <kprobe_unwind_dotnet+0x4af7>
    4a87:      	incq	(%rax)
    4a8a:      	jmp	0x4b07 <kprobe_unwind_dotnet+0x4b07>
    4a8c:      	movl	0x117c(%r14), %ebp
    4a93:      	movq	(%rip), %rax            # 0x4a9a <kprobe_unwind_dotnet+0x4a9a>
    4a9a:      	cmpl	$0x0, (%rax)
    4a9d:      	jne	0x5375 <kprobe_unwind_dotnet+0x5375>
    4aa3:      	movl	$0x20, %ecx
    4aa8:      	movq	%r15, %rax
    4aab:      	xorl	%edx, %edx
    4aad:      	divq	%rcx
    4ab0:      	movl	$0x8, %ecx
    4ab5:      	xorl	%edx, %edx
    4ab7:      	divq	%rcx
    4aba:      	shll	$0x2, %edx
    4abd:      	movb	$0x1c, %al
    4abf:      	subb	%dl, %al
    4ac1:      	shrxl	%eax, %ebp, %r15d
    4ac6:      	testl	%r15d, %r15d
    4ac9:      	je	0x4b94 <kprobe_unwind_dotnet+0x4b94>
    4acf:      	andq	$-0x20, %r13
    4ad3:      	movl	%r15d, %ecx
    4ad6:      	andl	$0xf, %ecx
    4ad9:      	jne	0x4f58 <kprobe_unwind_dotnet+0x4f58>
    4adf:      	movl	%r15d, %ecx
    4ae2:      	shrl	$0x4, %ecx
    4ae5:      	andl	$0xf, %ecx
    4ae8:      	je	0x4ca4 <kprobe_unwind_dotnet+0x4ca4>
    4aee:      	addq	$-0x20, %r13
    4af2:      	jmp	0x4f58 <kprobe_unwind_dotnet+0x4f58>
    4af7:      	movq	(%rip), %rax            # 0x4afe <kprobe_unwind_dotnet+0x4afe>
    4afe:      	cmpl	$0x0, (%rax)
    4b01:      	jne	0x5481 <kprobe_unwind_dotnet+0x5481>
    4b07:      	movl	$0x1772, %edx           # imm = 0x1772
    4b0c:      	xorl	%ebx, %ebx
    4b0e:      	movq	(%rip), %rax            # 0x4b15 <kprobe_unwind_dotnet+0x4b15>
    4b15:      	cmpl	$0x0, (%rax)
    4b18:      	jne	0x5822 <kprobe_unwind_dotnet+0x5822>
    4b1e:      	movl	$0x1772, %eax           # imm = 0x1772
    4b23:      	testb	%bl, %bl
    4b25:      	movq	0x60(%rsp), %r15
    4b2a:      	movq	(%rip), %rbp            # 0x4b31 <kprobe_unwind_dotnet+0x4b31>
    4b31:      	je	0x7812 <kprobe_unwind_dotnet+0x7812>
    4b37:      	movl	0x2c0(%r14), %eax
    4b3e:      	cmpq	$0x7e, %rax
    4b42:      	ja	0x52f <kprobe_unwind_dotnet+0x52f>
    4b48:      	leal	0x1(%rax), %ecx
    4b4b:      	movl	%ecx, 0x2c0(%r14)
    4b52:      	leaq	(%rax,%rax,2), %rax
    4b56:      	movq	$0x0, 0x2d0(%r14,%rax,8)
    4b62:      	movq	$0x1773, 0x2d8(%r14,%rax,8) # imm = 0x1773
    4b6e:      	movb	$-0x76, 0x2e0(%r14,%rax,8)
    4b77:      	movl	$0x0, 0x2e1(%r14,%rax,8)
    4b83:      	movl	$0x0, 0x2e4(%r14,%rax,8)
    4b8f:      	jmp	0x5058 <kprobe_unwind_dotnet+0x5058>
    4b94:      	andq	$-0x100, %r13
    4b9b:      	addq	$-0x20, %r13
    4b9f:      	movl	0x1178(%r14), %r15d
    4ba6:      	movq	(%rip), %rax            # 0x4bad <kprobe_unwind_dotnet+0x4bad>
    4bad:      	cmpl	$0x0, (%rax)
    4bb0:      	jne	0x5611 <kprobe_unwind_dotnet+0x5611>
    4bb6:      	xorl	%ecx, %ecx
    4bb8:      	testl	%r15d, %r15d
    4bbb:      	je	0x56a5 <kprobe_unwind_dotnet+0x56a5>
    4bc1:      	movl	%ecx, %eax
    4bc3:      	shll	$0x8, %eax
    4bc6:      	subq	%rax, %r13
    4bc9:      	jae	0x57bd <kprobe_unwind_dotnet+0x57bd>
    4bcf:      	movq	(%rip), %rax            # 0x4bd6 <kprobe_unwind_dotnet+0x4bd6>
    4bd6:      	cmpl	$0x0, (%rax)
    4bd9:      	je	0x4a67 <kprobe_unwind_dotnet+0x4a67>
    4bdf:      	movabsq	$0xa657361625f63, %rax  # imm = 0xA657361625F63
    4be9:      	movq	%rax, 0x36(%rsp)
    4bee:      	movabsq	$0x5f637020776f6c65, %rax # imm = 0x5F637020776F6C65
    4bf8:      	movq	%rax, 0x30(%rsp)
    4bfd:      	movabsq	$0x6220746e65772068, %rax # imm = 0x6220746E65772068
    4c07:      	movq	%rax, 0x28(%rsp)
    4c0c:      	movabsq	$0x6372616573207061, %rax # imm = 0x6372616573207061
    4c16:      	movq	%rax, 0x20(%rsp)
    4c1b:      	movabsq	$0x6d20656c6262696e, %rax # imm = 0x6D20656C6262696E
    4c25:      	movq	%rax, 0x18(%rsp)
    4c2a:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    4c34:      	movq	%rax, 0x10(%rsp)
    4c39:      	leaq	0x10(%rsp), %rdi
    4c3e:      	movl	$0x2e, %eax
    4c43:      	movl	$0x6, %ecx
    4c48:      	movl	$0x2e, %esi
    4c4d:      	xorl	%eax, %eax
    4c4f:      	callq	*%rcx
    4c51:      	movq	(%rip), %rax            # 0x4c58 <kprobe_unwind_dotnet+0x4c58>
    4c58:      	cmpl	$0x0, (%rax)
    4c5b:      	je	0x4a67 <kprobe_unwind_dotnet+0x4a67>
    4c61:      	movabsq	$0x6e756f6620746f6e, %rax # imm = 0x6E756F6620746F6E
    4c6b:      	movq	%rax, 0x18(%rsp)
    4c70:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    4c7a:      	movq	%rax, 0x10(%rsp)
    4c7f:      	movl	$0xa646e, 0x1f(%rsp)    # imm = 0xA646E
    4c87:      	leaq	0x10(%rsp), %rdi
    4c8c:      	movl	$0x13, %eax
    4c91:      	movl	$0x6, %ecx
    4c96:      	movl	$0x13, %esi
    4c9b:      	xorl	%eax, %eax
    4c9d:      	callq	*%rcx
    4c9f:      	jmp	0x4a67 <kprobe_unwind_dotnet+0x4a67>
    4ca4:      	movl	%r15d, %ecx
    4ca7:      	shrl	$0x8, %ecx
    4caa:      	andl	$0xf, %ecx
    4cad:      	je	0x4cb8 <kprobe_unwind_dotnet+0x4cb8>
    4caf:      	addq	$-0x40, %r13
    4cb3:      	jmp	0x4f58 <kprobe_unwind_dotnet+0x4f58>
    4cb8:      	movl	%r15d, %ecx
    4cbb:      	shrl	$0xc, %ecx
    4cbe:      	andl	$0xf, %ecx
    4cc1:      	je	0x4d41 <kprobe_unwind_dotnet+0x4d41>
    4cc3:      	addq	$-0x60, %r13
    4cc7:      	jmp	0x4f58 <kprobe_unwind_dotnet+0x4f58>
    4ccc:      	movabsq	$0x6c25203a7066202c, %rax # imm = 0x6C25203A7066202C
    4cd6:      	movq	%rax, 0x28(%rsp)
    4cdb:      	movabsq	$0x786c25203a707320, %rax # imm = 0x786C25203A707320
    4ce5:      	movq	%rax, 0x20(%rsp)
    4cea:      	movabsq	$0x2c786c25203a6370, %rax # imm = 0x2C786C25203A6370
    4cf4:      	movq	%rax, 0x18(%rsp)
    4cf9:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    4d03:      	movq	%rax, 0x10(%rsp)
    4d08:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    4d10:      	leaq	0x10(%rsp), %rdi
    4d15:      	movl	$0x23, %eax
    4d1a:      	movl	$0x6, %r9d
    4d20:      	movl	$0x23, %esi
    4d25:      	movq	%r12, %rdx
    4d28:      	movq	%rbx, %rcx
    4d2b:      	movq	%r13, %r8
    4d2e:      	xorl	%eax, %eax
    4d30:      	callq	*%r9
    4d33:      	cmpq	%rbx, %r13
    4d36:      	jae	0x48ee <kprobe_unwind_dotnet+0x48ee>
    4d3c:      	jmp	0x77bb <kprobe_unwind_dotnet+0x77bb>
    4d41:      	movl	%r15d, %ecx
    4d44:      	shrl	$0x10, %ecx
    4d47:      	andl	$0xf, %ecx
    4d4a:      	je	0x4d55 <kprobe_unwind_dotnet+0x4d55>
    4d4c:      	addq	$-0x80, %r13
    4d50:      	jmp	0x4f58 <kprobe_unwind_dotnet+0x4f58>
    4d55:      	movl	%r15d, %ecx
    4d58:      	shrl	$0x14, %ecx
    4d5b:      	andl	$0xf, %ecx
    4d5e:      	je	0x4e70 <kprobe_unwind_dotnet+0x4e70>
    4d64:      	addq	$-0xa0, %r13
    4d6b:      	jmp	0x4f58 <kprobe_unwind_dotnet+0x4f58>
    4d70:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4d7a:      	movq	%rax, 0x36(%rsp)
    4d7f:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4d89:      	movq	%rax, 0x30(%rsp)
    4d8e:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4d98:      	movq	%rax, 0x28(%rsp)
    4d9d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4da7:      	movq	%rax, 0x20(%rsp)
    4dac:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4db6:      	movq	%rax, 0x18(%rsp)
    4dbb:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4dc5:      	movq	%rax, 0x10(%rsp)
    4dca:      	leaq	0x10(%rsp), %rdi
    4dcf:      	movl	$0x2e, %eax
    4dd4:      	movl	$0x6, %ecx
    4dd9:      	movl	0xc(%rsp), %edx
    4ddd:      	movl	$0x2e, %esi
    4de2:      	xorl	%eax, %eax
    4de4:      	callq	*%rcx
    4de6:      	jmp	0x46e2 <kprobe_unwind_dotnet+0x46e2>
    4deb:      	movabsq	$0x6c25203a7066202c, %rax # imm = 0x6C25203A7066202C
    4df5:      	movq	%rax, 0x28(%rsp)
    4dfa:      	movabsq	$0x786c25203a707320, %rax # imm = 0x786C25203A707320
    4e04:      	movq	%rax, 0x20(%rsp)
    4e09:      	movabsq	$0x2c786c25203a6370, %rax # imm = 0x2C786C25203A6370
    4e13:      	movq	%rax, 0x18(%rsp)
    4e18:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    4e22:      	movq	%rax, 0x10(%rsp)
    4e27:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    4e2f:      	leaq	0x10(%rsp), %rdi
    4e34:      	movl	$0x23, %eax
    4e39:      	movl	$0x6, %r9d
    4e3f:      	movq	0xed0(%r14), %rdx
    4e46:      	movq	0xed8(%r14), %rcx
    4e4d:      	movq	0xee0(%r14), %r8
    4e54:      	movl	$0x23, %esi
    4e59:      	xorl	%eax, %eax
    4e5b:      	callq	*%r9
    4e5e:      	cmpq	$0x100, %rbp            # imm = 0x100
    4e65:      	jae	0x49cc <kprobe_unwind_dotnet+0x49cc>
    4e6b:      	jmp	0x4fa5 <kprobe_unwind_dotnet+0x4fa5>
    4e70:      	movl	%r15d, %ecx
    4e73:      	shrl	$0x18, %ecx
    4e76:      	andl	$0xf, %ecx
    4e79:      	je	0x4f4a <kprobe_unwind_dotnet+0x4f4a>
    4e7f:      	addq	$-0xc0, %r13
    4e86:      	jmp	0x4f58 <kprobe_unwind_dotnet+0x4f58>
    4e8b:      	leaq	(%rip), %rsi            # 0x4e92 <kprobe_unwind_dotnet+0x4e92>
    4e92:      	leaq	0x10(%rsp), %rax
    4e97:      	movl	$0x8, %ecx
    4e9c:      	movq	%rax, %rdi
    4e9f:      	rep		movsq	(%rsi), %es:(%rdi)
    4ea2:      	movw	$0xa, 0x50(%rsp)
    4ea9:      	movl	$0x42, %ecx
    4eae:      	movl	$0x6, %r9d
    4eb4:      	movq	%rax, %rdi
    4eb7:      	movl	$0x42, %esi
    4ebc:      	movq	%r13, %rdx
    4ebf:      	movq	%rbx, %rcx
    4ec2:      	movq	%rbp, %r8
    4ec5:      	xorl	%eax, %eax
    4ec7:      	callq	*%r9
    4eca:      	jmp	0x49f0 <kprobe_unwind_dotnet+0x49f0>
    4ecf:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    4ed9:      	movq	%rax, 0x36(%rsp)
    4ede:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    4ee8:      	movq	%rax, 0x30(%rsp)
    4eed:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    4ef7:      	movq	%rax, 0x28(%rsp)
    4efc:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    4f06:      	movq	%rax, 0x20(%rsp)
    4f0b:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    4f15:      	movq	%rax, 0x18(%rsp)
    4f1a:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    4f24:      	movq	%rax, 0x10(%rsp)
    4f29:      	leaq	0x10(%rsp), %rdi
    4f2e:      	movl	$0x2e, %eax
    4f33:      	movl	$0x6, %ecx
    4f38:      	movl	0x68(%rsp), %edx
    4f3c:      	movl	$0x2e, %esi
    4f41:      	xorl	%eax, %eax
    4f43:      	callq	*%rcx
    4f45:      	jmp	0x48a2 <kprobe_unwind_dotnet+0x48a2>
    4f4a:      	shrl	$0x1c, %r15d
    4f4e:      	addq	$-0xe0, %r13
    4f55:      	movl	%r15d, %ecx
    4f58:      	addq	%r13, %rbx
    4f5b:      	leal	-0x4(,%rcx,4), %r15d
    4f63:      	addq	%rbx, %r15
    4f66:      	movq	(%rip), %rax            # 0x4f6d <kprobe_unwind_dotnet+0x4f6d>
    4f6d:      	cmpl	$0x0, (%rax)
    4f70:      	jne	0x5402 <kprobe_unwind_dotnet+0x5402>
    4f76:      	leaq	-0x8(%r15), %rdx
    4f7a:      	leaq	0x68(%rsp), %rdi
    4f7f:      	movl	$0x8, %eax
    4f84:      	movl	$0x70, %ecx
    4f89:      	movl	$0x8, %esi
    4f8e:      	callq	*%rcx
    4f90:      	testq	%rax, %rax
    4f93:      	movq	(%rip), %rbp            # 0x4f9a <kprobe_unwind_dotnet+0x4f9a>
    4f9a:      	jne	0xbb6 <kprobe_unwind_dotnet+0xbb6>
    4fa0:      	movl	$0x1f, %ebp
    4fa5:      	movq	(%rip), %rax            # 0x4fac <kprobe_unwind_dotnet+0x4fac>
    4fac:      	cmpl	$0x0, (%rax)
    4faf:      	jne	0x51fe <kprobe_unwind_dotnet+0x51fe>
    4fb5:      	movl	0x2c0(%r14), %eax
    4fbc:      	cmpq	$0x7e, %rax
    4fc0:      	ja	0xc0c <kprobe_unwind_dotnet+0xc0c>
    4fc6:      	movq	0x68(%rsp), %rcx
    4fcb:      	subq	%r15, %r12
    4fce:      	shlq	$0x5, %rcx
    4fd2:      	addq	%rbp, %rcx
    4fd5:      	leal	0x1(%rax), %edx
    4fd8:      	movl	%edx, 0x2c0(%r14)
    4fdf:      	leaq	(%rax,%rax,2), %rax
    4fe3:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    4feb:      	movq	%r12, 0x2d8(%r14,%rax,8)
    4ff3:      	movb	$0xa, 0x2e0(%r14,%rax,8)
    4ffc:      	movzbl	0x88(%rsp), %ecx
    5004:      	movb	%cl, 0x2e1(%r14,%rax,8)
    500c:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    5018:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    5023:      	movl	$0x5b, 0xc(%rsp)
    502b:      	movq	(%rip), %rdi            # 0x5032 <kprobe_unwind_dotnet+0x5032>
    5032:      	leaq	0xc(%rsp), %rsi
    5037:      	movl	$0x1, %eax
    503c:      	callq	*%rax
    503e:      	testq	%rax, %rax
    5041:      	je	0x5048 <kprobe_unwind_dotnet+0x5048>
    5043:      	incq	(%rax)
    5046:      	jmp	0x5058 <kprobe_unwind_dotnet+0x5058>
    5048:      	movq	(%rip), %rax            # 0x504f <kprobe_unwind_dotnet+0x504f>
    504f:      	cmpl	$0x0, (%rax)
    5052:      	jne	0x52fa <kprobe_unwind_dotnet+0x52fa>
    5058:      	movq	0x98(%rsp), %rax
    5060:      	movq	(%rax), %r13
    5063:      	movq	(%rip), %rax            # 0x506a <kprobe_unwind_dotnet+0x506a>
    506a:      	movl	(%rax), %eax
    506c:      	testq	%r13, %r13
    506f:      	je	0x88ec <kprobe_unwind_dotnet+0x88ec>
    5075:      	testl	%eax, %eax
    5077:      	jne	0x525d <kprobe_unwind_dotnet+0x525d>
    507d:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    5087:      	cmpq	%rax, %r13
    508a:      	ja	0x2516 <kprobe_unwind_dotnet+0x2516>
    5090:      	cmpq	$0x1000, %r13           # imm = 0x1000
    5097:      	jb	0x26b1 <kprobe_unwind_dotnet+0x26b1>
    509d:      	movl	(%r14), %eax
    50a0:      	movl	$0x60, 0x70(%rsp)
    50a8:      	movbel	%eax, 0x74(%rsp)
    50ae:      	movbeq	%r13, 0x78(%rsp)
    50b5:      	movq	(%rip), %rdi            # 0x50bc <kprobe_unwind_dotnet+0x50bc>
    50bc:      	leaq	0x70(%rsp), %rsi
    50c1:      	movl	$0x1, %eax
    50c6:      	callq	*%rax
    50c8:      	testq	%rax, %rax
    50cb:      	je	0x8837 <kprobe_unwind_dotnet+0x8837>
    50d1:      	movq	0x8(%rax), %r12
    50d5:      	movq	%r12, %rcx
    50d8:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    50e2:      	andq	%rdx, %rcx
    50e5:      	movq	%rcx, 0xf20(%r14)
    50ec:      	movq	(%rax), %rax
    50ef:      	movq	%rax, 0xf10(%r14)
    50f6:      	shrq	$0x38, %r12
    50fa:      	movq	%r13, %rax
    50fd:      	subq	%rcx, %rax
    5100:      	movq	%rax, 0xf18(%r14)
    5107:      	movq	(%rip), %rax            # 0x510e <kprobe_unwind_dotnet+0x510e>
    510e:      	cmpl	$0x0, (%rax)
    5111:      	jne	0x54fc <kprobe_unwind_dotnet+0x54fc>
    5117:      	cmpl	$0x1, %r12d
    511b:      	jne	0x59d0 <kprobe_unwind_dotnet+0x59d0>
    5121:      	movq	0xf10(%r14), %rax
    5128:      	movq	%rax, 0x70(%rsp)
    512d:      	movq	0xf18(%r14), %rbx
    5134:      	movq	(%rip), %rdi            # 0x513b <kprobe_unwind_dotnet+0x513b>
    513b:      	leaq	0x70(%rsp), %rsi
    5140:      	movl	$0x1, %eax
    5145:      	callq	*%rax
    5147:      	movl	$0x1, %r12d
    514d:      	testq	%rax, %rax
    5150:      	je	0x59d0 <kprobe_unwind_dotnet+0x59d0>
    5156:      	movq	%rax, %r15
    5159:      	cmpq	%rbx, (%rax)
    515c:      	ja	0x5164 <kprobe_unwind_dotnet+0x5164>
    515e:      	cmpq	%rbx, 0x8(%r15)
    5162:      	jae	0x5178 <kprobe_unwind_dotnet+0x5178>
    5164:      	cmpq	%rbx, 0x10(%r15)
    5168:      	ja	0x59d0 <kprobe_unwind_dotnet+0x59d0>
    516e:      	cmpq	%rbx, 0x18(%r15)
    5172:      	jb	0x59d0 <kprobe_unwind_dotnet+0x59d0>
    5178:      	movq	(%rip), %rax            # 0x517f <kprobe_unwind_dotnet+0x517f>
    517f:      	cmpl	$0x0, (%rax)
    5182:      	jne	0x5929 <kprobe_unwind_dotnet+0x5929>
    5188:      	movl	0x1380(%r14), %eax
    518f:      	movl	0x20(%r15), %ecx
    5193:      	btl	%ecx, %eax
    5196:      	jae	0x5996 <kprobe_unwind_dotnet+0x5996>
    519c:      	movq	(%rip), %rax            # 0x51a3 <kprobe_unwind_dotnet+0x51a3>
    51a3:      	cmpl	$0x0, (%rax)
    51a6:      	je	0x59d0 <kprobe_unwind_dotnet+0x59d0>
    51ac:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    51b6:      	movq	%rax, 0x20(%rsp)
    51bb:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    51c5:      	movq	%rax, 0x18(%rsp)
    51ca:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    51d4:      	movq	%rax, 0x10(%rsp)
    51d9:      	movl	$0xa656e, 0x27(%rsp)    # imm = 0xA656E
    51e1:      	leaq	0x10(%rsp), %rdi
    51e6:      	movl	$0x1b, %eax
    51eb:      	movl	$0x6, %ecx
    51f0:      	movl	$0x1b, %esi
    51f5:      	xorl	%eax, %eax
    51f7:      	callq	*%rcx
    51f9:      	jmp	0x59d0 <kprobe_unwind_dotnet+0x59d0>
    51fe:      	leaq	(%rip), %rsi            # 0x5205 <kprobe_unwind_dotnet+0x5205>
    5205:      	leaq	0x10(%rsp), %rax
    520a:      	movl	$0x8, %ecx
    520f:      	movq	%rax, %rdi
    5212:      	rep		movsq	(%rsi), %es:(%rdi)
    5215:      	movb	$0x0, 0x52(%rsp)
    521a:      	movw	$0xa78, 0x50(%rsp)      # imm = 0xA78
    5221:      	movl	$0x43, %ecx
    5226:      	movl	$0x6, %r9d
    522c:      	movq	0x68(%rsp), %rcx
    5231:      	movq	%r12, %r8
    5234:      	subq	%r15, %r8
    5237:      	movq	%rax, %rdi
    523a:      	movl	$0x43, %esi
    523f:      	movq	%r15, %rdx
    5242:      	xorl	%eax, %eax
    5244:      	callq	*%r9
    5247:      	movl	0x2c0(%r14), %eax
    524e:      	cmpq	$0x7e, %rax
    5252:      	ja	0xc0c <kprobe_unwind_dotnet+0xc0c>
    5258:      	jmp	0x4fc6 <kprobe_unwind_dotnet+0x4fc6>
    525d:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    5267:      	movq	%rax, 0x38(%rsp)
    526c:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    5276:      	movq	%rax, 0x30(%rsp)
    527b:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    5285:      	movq	%rax, 0x28(%rsp)
    528a:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    5294:      	movq	%rax, 0x20(%rsp)
    5299:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    52a3:      	movq	%rax, 0x18(%rsp)
    52a8:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    52b2:      	movq	%rax, 0x10(%rsp)
    52b7:      	movb	$0x0, 0x40(%rsp)
    52bc:      	leaq	0x10(%rsp), %rdi
    52c1:      	movl	$0x31, %eax
    52c6:      	movl	$0x6, %ecx
    52cb:      	movl	0x2c0(%r14), %edx
    52d2:      	movl	$0x31, %esi
    52d7:      	xorl	%eax, %eax
    52d9:      	callq	*%rcx
    52db:      	movq	0xed0(%r14), %r13
    52e2:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    52ec:      	cmpq	%rax, %r13
    52ef:      	ja	0x2516 <kprobe_unwind_dotnet+0x2516>
    52f5:      	jmp	0x5090 <kprobe_unwind_dotnet+0x5090>
    52fa:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5304:      	movq	%rax, 0x36(%rsp)
    5309:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5313:      	movq	%rax, 0x30(%rsp)
    5318:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5322:      	movq	%rax, 0x28(%rsp)
    5327:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5331:      	movq	%rax, 0x20(%rsp)
    5336:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5340:      	movq	%rax, 0x18(%rsp)
    5345:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    534f:      	movq	%rax, 0x10(%rsp)
    5354:      	leaq	0x10(%rsp), %rdi
    5359:      	movl	$0x2e, %eax
    535e:      	movl	$0x6, %ecx
    5363:      	movl	0xc(%rsp), %edx
    5367:      	movl	$0x2e, %esi
    536c:      	xorl	%eax, %eax
    536e:      	callq	*%rcx
    5370:      	jmp	0x5058 <kprobe_unwind_dotnet+0x5058>
    5375:      	movabsq	$0xa782520797274, %rax  # imm = 0xA782520797274
    537f:      	movq	%rax, 0x3e(%rsp)
    5384:      	movabsq	$0x72746e6520747372, %rax # imm = 0x72746E6520747372
    538e:      	movq	%rax, 0x38(%rsp)
    5393:      	movabsq	$0x6966203a786c2520, %rax # imm = 0x6966203A786C2520
    539d:      	movq	%rax, 0x30(%rsp)
    53a2:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    53ac:      	movq	%rax, 0x28(%rsp)
    53b1:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    53bb:      	movq	%rax, 0x20(%rsp)
    53c0:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    53ca:      	movq	%rax, 0x18(%rsp)
    53cf:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    53d9:      	movq	%rax, 0x10(%rsp)
    53de:      	leaq	0x10(%rsp), %rdi
    53e3:      	movl	$0x36, %eax
    53e8:      	movl	$0x6, %r8d
    53ee:      	movl	$0x36, %esi
    53f3:      	movq	%r15, %rdx
    53f6:      	movl	%ebp, %ecx
    53f8:      	xorl	%eax, %eax
    53fa:      	callq	*%r8
    53fd:      	jmp	0x4aa3 <kprobe_unwind_dotnet+0x4aa3>
    5402:      	movabsq	$0xa786c253d7465, %rax  # imm = 0xA786C253D7465
    540c:      	movq	%rax, 0x36(%rsp)
    5411:      	movabsq	$0x746572202c78253d, %rax # imm = 0x746572202C78253D
    541b:      	movq	%rax, 0x30(%rsp)
    5420:      	movabsq	$0x6c6176202c786c25, %rax # imm = 0x6C6176202C786C25
    542a:      	movq	%rax, 0x28(%rsp)
    542f:      	movabsq	$0x203d2061746c6564, %rax # imm = 0x203D2061746C6564
    5439:      	movq	%rax, 0x20(%rsp)
    543e:      	movabsq	$0x5f6370203e2d2d20, %rax # imm = 0x5F6370203E2D2D20
    5448:      	movq	%rax, 0x18(%rsp)
    544d:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    5457:      	movq	%rax, 0x10(%rsp)
    545c:      	leaq	0x10(%rsp), %rdi
    5461:      	movl	$0x2e, %eax
    5466:      	movl	$0x6, %r9d
    546c:      	movl	$0x2e, %esi
    5471:      	movq	%r13, %rdx
    5474:      	movq	%r15, %r8
    5477:      	xorl	%eax, %eax
    5479:      	callq	*%r9
    547c:      	jmp	0x4f76 <kprobe_unwind_dotnet+0x4f76>
    5481:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    548b:      	movq	%rax, 0x36(%rsp)
    5490:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    549a:      	movq	%rax, 0x30(%rsp)
    549f:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    54a9:      	movq	%rax, 0x28(%rsp)
    54ae:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    54b8:      	movq	%rax, 0x20(%rsp)
    54bd:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    54c7:      	movq	%rax, 0x18(%rsp)
    54cc:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    54d6:      	movq	%rax, 0x10(%rsp)
    54db:      	leaq	0x10(%rsp), %rdi
    54e0:      	movl	$0x2e, %eax
    54e5:      	movl	$0x6, %ecx
    54ea:      	movl	0xc(%rsp), %edx
    54ee:      	movl	$0x2e, %esi
    54f3:      	xorl	%eax, %eax
    54f5:      	callq	*%rcx
    54f7:      	jmp	0x4b07 <kprobe_unwind_dotnet+0x4b07>
    54fc:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    5506:      	movq	%rax, 0x38(%rsp)
    550b:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    5515:      	movq	%rax, 0x30(%rsp)
    551a:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    5524:      	movq	%rax, 0x28(%rsp)
    5529:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    5533:      	movq	%rax, 0x20(%rsp)
    5538:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    5542:      	movq	%rax, 0x18(%rsp)
    5547:      	movabsq	$0x6365732074786554, %rbx # imm = 0x6365732074786554
    5551:      	movq	%rbx, 0x10(%rsp)
    5556:      	movw	$0xa, 0x40(%rsp)
    555d:      	leaq	0x10(%rsp), %rdi
    5562:      	movl	$0x32, %eax
    5567:      	movl	$0x6, %r9d
    556d:      	movq	0xf10(%r14), %rcx
    5574:      	movl	$0x32, %esi
    5579:      	movq	%r13, %rdx
    557c:      	movl	%r12d, %r8d
    557f:      	xorl	%eax, %eax
    5581:      	callq	*%r9
    5584:      	movq	(%rip), %rax            # 0x558b <kprobe_unwind_dotnet+0x558b>
    558b:      	cmpl	$0x0, (%rax)
    558e:      	je	0x5117 <kprobe_unwind_dotnet+0x5117>
    5594:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    559e:      	movq	%rax, 0x37(%rsp)
    55a3:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    55ad:      	movq	%rax, 0x30(%rsp)
    55b2:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    55bc:      	movq	%rax, 0x28(%rsp)
    55c1:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    55cb:      	movq	%rax, 0x20(%rsp)
    55d0:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    55da:      	movq	%rax, 0x18(%rsp)
    55df:      	movq	%rbx, 0x10(%rsp)
    55e4:      	leaq	0x10(%rsp), %rdi
    55e9:      	movl	$0x2f, %eax
    55ee:      	movl	$0x6, %r8d
    55f4:      	movq	0xf18(%r14), %rcx
    55fb:      	movq	0xf20(%r14), %rdx
    5602:      	movl	$0x2f, %esi
    5607:      	xorl	%eax, %eax
    5609:      	callq	*%r8
    560c:      	jmp	0x5117 <kprobe_unwind_dotnet+0x5117>
    5611:      	movabsq	$0xa782520797274, %rax  # imm = 0xA782520797274
    561b:      	movq	%rax, 0x3f(%rsp)
    5620:      	movabsq	$0x746e6520646e6f63, %rax # imm = 0x746E6520646E6F63
    562a:      	movq	%rax, 0x38(%rsp)
    562f:      	movabsq	$0x6573203a786c2520, %rax # imm = 0x6573203A786C2520
    5639:      	movq	%rax, 0x30(%rsp)
    563e:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    5648:      	movq	%rax, 0x28(%rsp)
    564d:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    5657:      	movq	%rax, 0x20(%rsp)
    565c:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    5666:      	movq	%rax, 0x18(%rsp)
    566b:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    5675:      	movq	%rax, 0x10(%rsp)
    567a:      	leaq	0x10(%rsp), %rdi
    567f:      	movl	$0x37, %eax
    5684:      	movl	$0x6, %r8d
    568a:      	movl	$0x37, %esi
    568f:      	movq	%r13, %rdx
    5692:      	movl	%r15d, %ecx
    5695:      	xorl	%eax, %eax
    5697:      	callq	*%r8
    569a:      	xorl	%ecx, %ecx
    569c:      	testl	%r15d, %r15d
    569f:      	jne	0x4bc1 <kprobe_unwind_dotnet+0x4bc1>
    56a5:      	movq	0x1170(%r14), %rax
    56ac:      	movl	$0xffffff84, %ecx       # imm = 0xFFFFFF84
    56b1:      	testq	%rax, %rax
    56b4:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    56ba:      	movq	0x1168(%r14), %rax
    56c1:      	movl	$0xffffff86, %ecx       # imm = 0xFFFFFF86
    56c6:      	testq	%rax, %rax
    56c9:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    56cf:      	movq	0x1160(%r14), %rax
    56d6:      	movl	$0xffffff88, %ecx       # imm = 0xFFFFFF88
    56db:      	testq	%rax, %rax
    56de:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    56e4:      	movq	0x1158(%r14), %rax
    56eb:      	movl	$0xffffff8a, %ecx       # imm = 0xFFFFFF8A
    56f0:      	testq	%rax, %rax
    56f3:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    56f9:      	movq	0x1150(%r14), %rax
    5700:      	movl	$0xffffff8c, %ecx       # imm = 0xFFFFFF8C
    5705:      	testq	%rax, %rax
    5708:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    570e:      	movq	0x1148(%r14), %rax
    5715:      	movl	$0xffffff8e, %ecx       # imm = 0xFFFFFF8E
    571a:      	testq	%rax, %rax
    571d:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    571f:      	movq	0x1140(%r14), %rax
    5726:      	movl	$0xffffff90, %ecx       # imm = 0xFFFFFF90
    572b:      	testq	%rax, %rax
    572e:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    5730:      	movq	0x1138(%r14), %rax
    5737:      	movl	$0xffffff92, %ecx       # imm = 0xFFFFFF92
    573c:      	testq	%rax, %rax
    573f:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    5741:      	movq	0x1130(%r14), %rax
    5748:      	movl	$0xffffff94, %ecx       # imm = 0xFFFFFF94
    574d:      	testq	%rax, %rax
    5750:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    5752:      	movq	0x1128(%r14), %rax
    5759:      	movl	$0xffffff96, %ecx       # imm = 0xFFFFFF96
    575e:      	testq	%rax, %rax
    5761:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    5763:      	movq	0x1120(%r14), %rax
    576a:      	movl	$0xffffff98, %ecx       # imm = 0xFFFFFF98
    576f:      	testq	%rax, %rax
    5772:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    5774:      	movq	0x1118(%r14), %rax
    577b:      	movl	$0xffffff9a, %ecx       # imm = 0xFFFFFF9A
    5780:      	testq	%rax, %rax
    5783:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    5785:      	movq	0x1110(%r14), %rax
    578c:      	movl	$0xffffff9c, %ecx       # imm = 0xFFFFFF9C
    5791:      	testq	%rax, %rax
    5794:      	je	0x6dc5 <kprobe_unwind_dotnet+0x6dc5>
    579a:      	xorl	%edx, %edx
    579c:      	movq	%rax, %r15
    579f:      	shrq	$0x20, %r15
    57a3:      	setne	%dl
    57a6:      	cmovel	%eax, %r15d
    57aa:      	subl	%edx, %ecx
    57ac:      	addl	$0x7e, %ecx
    57af:      	movl	%ecx, %eax
    57b1:      	shll	$0x8, %eax
    57b4:      	subq	%rax, %r13
    57b7:      	jb	0x4bcf <kprobe_unwind_dotnet+0x4bcf>
    57bd:      	movq	(%rip), %rax            # 0x57c4 <kprobe_unwind_dotnet+0x57c4>
    57c4:      	cmpl	$0x0, (%rax)
    57c7:      	jne	0x588a <kprobe_unwind_dotnet+0x588a>
    57cd:      	testl	%r15d, %r15d
    57d0:      	jne	0x4ad3 <kprobe_unwind_dotnet+0x4ad3>
    57d6:      	movl	$0x5f, 0xc(%rsp)
    57de:      	movq	(%rip), %rdi            # 0x57e5 <kprobe_unwind_dotnet+0x57e5>
    57e5:      	leaq	0xc(%rsp), %rsi
    57ea:      	movl	$0x1, %eax
    57ef:      	callq	*%rax
    57f1:      	testq	%rax, %rax
    57f4:      	je	0x57fb <kprobe_unwind_dotnet+0x57fb>
    57f6:      	incq	(%rax)
    57f9:      	jmp	0x580b <kprobe_unwind_dotnet+0x580b>
    57fb:      	movq	(%rip), %rax            # 0x5802 <kprobe_unwind_dotnet+0x5802>
    5802:      	cmpl	$0x0, (%rax)
    5805:      	jne	0x5e99 <kprobe_unwind_dotnet+0x5e99>
    580b:      	movl	$0x1773, %edx           # imm = 0x1773
    5810:      	movb	$0x1, %bl
    5812:      	movq	(%rip), %rax            # 0x5819 <kprobe_unwind_dotnet+0x5819>
    5819:      	cmpl	$0x0, (%rax)
    581c:      	je	0x4b1e <kprobe_unwind_dotnet+0x4b1e>
    5822:      	movabsq	$0xa642520687469, %rax  # imm = 0xA642520687469
    582c:      	movq	%rax, 0x30(%rsp)
    5831:      	movabsq	$0x772064656c696166, %rax # imm = 0x772064656C696166
    583b:      	movq	%rax, 0x28(%rsp)
    5840:      	movabsq	$0x2074726174735f65, %rax # imm = 0x2074726174735F65
    584a:      	movq	%rax, 0x20(%rsp)
    584f:      	movabsq	$0x646f63203e2d2d20, %rax # imm = 0x646F63203E2D2D20
    5859:      	movq	%rax, 0x18(%rsp)
    585e:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    5868:      	movq	%rax, 0x10(%rsp)
    586d:      	leaq	0x10(%rsp), %rdi
    5872:      	movl	$0x28, %eax
    5877:      	movl	$0x6, %ecx
    587c:      	movl	$0x28, %esi
    5881:      	xorl	%eax, %eax
    5883:      	callq	*%rcx
    5885:      	jmp	0x4b1e <kprobe_unwind_dotnet+0x4b1e>
    588a:      	movabsq	$0x207972746e65202c, %rax # imm = 0x207972746E65202C
    5894:      	movq	%rax, 0x40(%rsp)
    5899:      	movabsq	$0x6425206465707069, %rax # imm = 0x6425206465707069
    58a3:      	movq	%rax, 0x38(%rsp)
    58a8:      	movabsq	$0x6b73203a786c2520, %rax # imm = 0x6B73203A786C2520
    58b2:      	movq	%rax, 0x30(%rsp)
    58b7:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    58c1:      	movq	%rax, 0x28(%rsp)
    58c6:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    58d0:      	movq	%rax, 0x20(%rsp)
    58d5:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    58df:      	movq	%rax, 0x18(%rsp)
    58e4:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    58ee:      	movq	%rax, 0x10(%rsp)
    58f3:      	movl	$0xa7825, 0x48(%rsp)    # imm = 0xA7825
    58fb:      	leaq	0x10(%rsp), %rdi
    5900:      	movl	$0x3c, %eax
    5905:      	movl	$0x6, %r9d
    590b:      	movl	$0x3c, %esi
    5910:      	movq	%r13, %rdx
    5913:      	movl	%r15d, %r8d
    5916:      	xorl	%eax, %eax
    5918:      	callq	*%r9
    591b:      	testl	%r15d, %r15d
    591e:      	jne	0x4ad3 <kprobe_unwind_dotnet+0x4ad3>
    5924:      	jmp	0x57d6 <kprobe_unwind_dotnet+0x57d6>
    5929:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    5933:      	movq	%rax, 0x26(%rsp)
    5938:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    5942:      	movq	%rax, 0x20(%rsp)
    5947:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    5951:      	movq	%rax, 0x18(%rsp)
    5956:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    5960:      	movq	%rax, 0x10(%rsp)
    5965:      	leaq	0x10(%rsp), %rdi
    596a:      	movl	$0x1e, %eax
    596f:      	movl	$0x6, %ecx
    5974:      	movzwl	0x20(%r15), %edx
    5979:      	movl	$0x1e, %esi
    597e:      	xorl	%eax, %eax
    5980:      	callq	*%rcx
    5982:      	movl	0x1380(%r14), %eax
    5989:      	movl	0x20(%r15), %ecx
    598d:      	btl	%ecx, %eax
    5990:      	jb	0x519c <kprobe_unwind_dotnet+0x519c>
    5996:      	movl	$0x0, 0x68(%rsp)
    599e:      	movq	(%rip), %rdi            # 0x59a5 <kprobe_unwind_dotnet+0x59a5>
    59a5:      	leaq	0x68(%rsp), %rsi
    59aa:      	movl	$0x1, %eax
    59af:      	callq	*%rax
    59b1:      	testq	%rax, %rax
    59b4:      	je	0x59bb <kprobe_unwind_dotnet+0x59bb>
    59b6:      	incq	(%rax)
    59b9:      	jmp	0x59cb <kprobe_unwind_dotnet+0x59cb>
    59bb:      	movq	(%rip), %rax            # 0x59c2 <kprobe_unwind_dotnet+0x59c2>
    59c2:      	cmpl	$0x0, (%rax)
    59c5:      	jne	0x5ff8 <kprobe_unwind_dotnet+0x5ff8>
    59cb:      	movzwl	0x20(%r15), %r12d
    59d0:      	cmpl	$0x8, %r12d
    59d4:      	jne	0x8da3 <kprobe_unwind_dotnet+0x8da3>
    59da:      	movq	0xed0(%r14), %r12
    59e1:      	movq	0xed8(%r14), %rbx
    59e8:      	movq	0xee0(%r14), %r13
    59ef:      	movzbl	0xf30(%r14), %eax
    59f7:      	movb	%al, 0x88(%rsp)
    59fe:      	movq	(%rip), %rax            # 0x5a05 <kprobe_unwind_dotnet+0x5a05>
    5a05:      	cmpl	$0x0, (%rax)
    5a08:      	jne	0x5df5 <kprobe_unwind_dotnet+0x5df5>
    5a0e:      	cmpq	%rbx, %r13
    5a11:      	jb	0x77bb <kprobe_unwind_dotnet+0x77bb>
    5a17:      	leaq	0x2000(%rbx), %rax
    5a1e:      	cmpq	%rax, %r13
    5a21:      	jae	0x77bb <kprobe_unwind_dotnet+0x77bb>
    5a27:      	movq	0xf10(%r14), %rbp
    5a2e:      	movq	0xf20(%r14), %r15
    5a35:      	movq	%r12, 0x68(%rsp)
    5a3a:      	movb	$0x1, 0xf30(%r14)
    5a42:      	movq	%rbp, %rax
    5a45:      	andq	$-0x80, %rax
    5a49:      	cmpq	$0x80, %rax
    5a4f:      	jne	0x5a93 <kprobe_unwind_dotnet+0x5a93>
    5a51:      	movq	0xed8(%r14), %rax
    5a58:      	movl	$0x8, %ecx
    5a5d:      	movl	$0x70, %r8d
    5a63:      	movq	0x98(%rsp), %rdi
    5a6b:      	movq	0xed8(%r14), %rdx
    5a72:      	movl	$0x8, %esi
    5a77:      	callq	*%r8
    5a7a:      	testq	%rax, %rax
    5a7d:      	jne	0x19c <kprobe_unwind_dotnet+0x19c>
    5a83:      	addq	$0x8, 0xed8(%r14)
    5a8b:      	andl	$0x7f, %ebp
    5a8e:      	jmp	0x60ce <kprobe_unwind_dotnet+0x60ce>
    5a93:      	leaq	0x70(%rsp), %rdi
    5a98:      	movl	$0x10, %eax
    5a9d:      	movl	$0x70, %ecx
    5aa2:      	movl	$0x10, %esi
    5aa7:      	movq	%r13, %rdx
    5aaa:      	callq	*%rcx
    5aac:      	testq	%rax, %rax
    5aaf:      	jne	0x26c <kprobe_unwind_dotnet+0x26c>
    5ab5:      	addq	$0x10, %r13
    5ab9:      	movq	%r13, 0xed8(%r14)
    5ac0:      	movq	0x70(%rsp), %rax
    5ac5:      	movq	%rax, 0xee0(%r14)
    5acc:      	movq	0x78(%rsp), %rax
    5ad1:      	movq	%rax, 0xed0(%r14)
    5ad8:      	movq	(%rip), %rax            # 0x5adf <kprobe_unwind_dotnet+0x5adf>
    5adf:      	cmpl	$0x0, (%rax)
    5ae2:      	jne	0x5f14 <kprobe_unwind_dotnet+0x5f14>
    5ae8:      	cmpq	$0x100, %rbp            # imm = 0x100
    5aef:      	jb	0x60ce <kprobe_unwind_dotnet+0x60ce>
    5af5:      	movq	0xf10(%r14), %rbp
    5afc:      	movq	0xf20(%r14), %rbx
    5b03:      	movq	%r12, %r13
    5b06:      	subq	%rbx, %r13
    5b09:      	movq	(%rip), %rax            # 0x5b10 <kprobe_unwind_dotnet+0x5b10>
    5b10:      	cmpl	$0x0, (%rax)
    5b13:      	jne	0x5fb4 <kprobe_unwind_dotnet+0x5fb4>
    5b19:      	movq	%r13, %r15
    5b1c:      	andq	$-0x4, %r15
    5b20:      	movl	$0x100, %ecx            # imm = 0x100
    5b25:      	movq	%r15, %rax
    5b28:      	xorl	%edx, %edx
    5b2a:      	divq	%rcx
    5b2d:      	movq	%rax, %rcx
    5b30:      	movl	$0x7f, %eax
    5b35:      	subq	%rcx, %rax
    5b38:      	jns	0x5b51 <kprobe_unwind_dotnet+0x5b51>
    5b3a:      	movl	$0x100, %ecx            # imm = 0x100
    5b3f:      	movq	%r15, %rax
    5b42:      	xorl	%edx, %edx
    5b44:      	divq	%rcx
    5b47:      	leaq	-0x3fc(%rbp,%rax,4), %rbp
    5b4f:      	xorl	%eax, %eax
    5b51:      	movl	$0x80, %ecx
    5b56:      	cqto
    5b58:      	idivq	%rcx
    5b5b:      	movq	0x90(%rsp), %rax
    5b63:      	leaq	(%rax,%rdx,4), %rdi
    5b67:      	movl	$0x200, %eax            # imm = 0x200
    5b6c:      	movl	$0x70, %ecx
    5b71:      	movl	$0x200, %esi            # imm = 0x200
    5b76:      	movq	%rbp, %rdx
    5b79:      	callq	*%rcx
    5b7b:      	testq	%rax, %rax
    5b7e:      	je	0x5bb5 <kprobe_unwind_dotnet+0x5bb5>
    5b80:      	movq	(%rip), %rax            # 0x5b87 <kprobe_unwind_dotnet+0x5b87>
    5b87:      	cmpl	$0x0, (%rax)
    5b8a:      	jne	0x5d8a <kprobe_unwind_dotnet+0x5d8a>
    5b90:      	movl	$0x5e, 0xc(%rsp)
    5b98:      	movq	(%rip), %rdi            # 0x5b9f <kprobe_unwind_dotnet+0x5b9f>
    5b9f:      	leaq	0xc(%rsp), %rsi
    5ba4:      	movl	$0x1, %eax
    5ba9:      	callq	*%rax
    5bab:      	testq	%rax, %rax
    5bae:      	je	0x5c20 <kprobe_unwind_dotnet+0x5c20>
    5bb0:      	incq	(%rax)
    5bb3:      	jmp	0x5c30 <kprobe_unwind_dotnet+0x5c30>
    5bb5:      	movl	0x117c(%r14), %ebp
    5bbc:      	movq	(%rip), %rax            # 0x5bc3 <kprobe_unwind_dotnet+0x5bc3>
    5bc3:      	cmpl	$0x0, (%rax)
    5bc6:      	jne	0x649e <kprobe_unwind_dotnet+0x649e>
    5bcc:      	movl	$0x20, %ecx
    5bd1:      	movq	%r15, %rax
    5bd4:      	xorl	%edx, %edx
    5bd6:      	divq	%rcx
    5bd9:      	movl	$0x8, %ecx
    5bde:      	xorl	%edx, %edx
    5be0:      	divq	%rcx
    5be3:      	shll	$0x2, %edx
    5be6:      	movb	$0x1c, %al
    5be8:      	subb	%dl, %al
    5bea:      	shrxl	%eax, %ebp, %r15d
    5bef:      	testl	%r15d, %r15d
    5bf2:      	je	0x5cbd <kprobe_unwind_dotnet+0x5cbd>
    5bf8:      	andq	$-0x20, %r13
    5bfc:      	movl	%r15d, %ecx
    5bff:      	andl	$0xf, %ecx
    5c02:      	jne	0x6081 <kprobe_unwind_dotnet+0x6081>
    5c08:      	movl	%r15d, %ecx
    5c0b:      	shrl	$0x4, %ecx
    5c0e:      	andl	$0xf, %ecx
    5c11:      	je	0x5dcd <kprobe_unwind_dotnet+0x5dcd>
    5c17:      	addq	$-0x20, %r13
    5c1b:      	jmp	0x6081 <kprobe_unwind_dotnet+0x6081>
    5c20:      	movq	(%rip), %rax            # 0x5c27 <kprobe_unwind_dotnet+0x5c27>
    5c27:      	cmpl	$0x0, (%rax)
    5c2a:      	jne	0x65aa <kprobe_unwind_dotnet+0x65aa>
    5c30:      	movl	$0x1772, %edx           # imm = 0x1772
    5c35:      	xorl	%ebx, %ebx
    5c37:      	movq	(%rip), %rax            # 0x5c3e <kprobe_unwind_dotnet+0x5c3e>
    5c3e:      	cmpl	$0x0, (%rax)
    5c41:      	jne	0x6d5d <kprobe_unwind_dotnet+0x6d5d>
    5c47:      	movl	$0x1772, %eax           # imm = 0x1772
    5c4c:      	testb	%bl, %bl
    5c4e:      	movq	0x60(%rsp), %r15
    5c53:      	movq	(%rip), %rbp            # 0x5c5a <kprobe_unwind_dotnet+0x5c5a>
    5c5a:      	je	0x7812 <kprobe_unwind_dotnet+0x7812>
    5c60:      	movl	0x2c0(%r14), %eax
    5c67:      	cmpq	$0x7e, %rax
    5c6b:      	ja	0x52f <kprobe_unwind_dotnet+0x52f>
    5c71:      	leal	0x1(%rax), %ecx
    5c74:      	movl	%ecx, 0x2c0(%r14)
    5c7b:      	leaq	(%rax,%rax,2), %rax
    5c7f:      	movq	$0x0, 0x2d0(%r14,%rax,8)
    5c8b:      	movq	$0x1773, 0x2d8(%r14,%rax,8) # imm = 0x1773
    5c97:      	movb	$-0x76, 0x2e0(%r14,%rax,8)
    5ca0:      	movl	$0x0, 0x2e1(%r14,%rax,8)
    5cac:      	movl	$0x0, 0x2e4(%r14,%rax,8)
    5cb8:      	jmp	0x6181 <kprobe_unwind_dotnet+0x6181>
    5cbd:      	andq	$-0x100, %r13
    5cc4:      	addq	$-0x20, %r13
    5cc8:      	movl	0x1178(%r14), %r15d
    5ccf:      	movq	(%rip), %rax            # 0x5cd6 <kprobe_unwind_dotnet+0x5cd6>
    5cd6:      	cmpl	$0x0, (%rax)
    5cd9:      	jne	0x673a <kprobe_unwind_dotnet+0x673a>
    5cdf:      	xorl	%ecx, %ecx
    5ce1:      	testl	%r15d, %r15d
    5ce4:      	je	0x67ce <kprobe_unwind_dotnet+0x67ce>
    5cea:      	movl	%ecx, %eax
    5cec:      	shll	$0x8, %eax
    5cef:      	subq	%rax, %r13
    5cf2:      	jae	0x6cf8 <kprobe_unwind_dotnet+0x6cf8>
    5cf8:      	movq	(%rip), %rax            # 0x5cff <kprobe_unwind_dotnet+0x5cff>
    5cff:      	cmpl	$0x0, (%rax)
    5d02:      	je	0x5b90 <kprobe_unwind_dotnet+0x5b90>
    5d08:      	movabsq	$0xa657361625f63, %rax  # imm = 0xA657361625F63
    5d12:      	movq	%rax, 0x36(%rsp)
    5d17:      	movabsq	$0x5f637020776f6c65, %rax # imm = 0x5F637020776F6C65
    5d21:      	movq	%rax, 0x30(%rsp)
    5d26:      	movabsq	$0x6220746e65772068, %rax # imm = 0x6220746E65772068
    5d30:      	movq	%rax, 0x28(%rsp)
    5d35:      	movabsq	$0x6372616573207061, %rax # imm = 0x6372616573207061
    5d3f:      	movq	%rax, 0x20(%rsp)
    5d44:      	movabsq	$0x6d20656c6262696e, %rax # imm = 0x6D20656C6262696E
    5d4e:      	movq	%rax, 0x18(%rsp)
    5d53:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    5d5d:      	movq	%rax, 0x10(%rsp)
    5d62:      	leaq	0x10(%rsp), %rdi
    5d67:      	movl	$0x2e, %eax
    5d6c:      	movl	$0x6, %ecx
    5d71:      	movl	$0x2e, %esi
    5d76:      	xorl	%eax, %eax
    5d78:      	callq	*%rcx
    5d7a:      	movq	(%rip), %rax            # 0x5d81 <kprobe_unwind_dotnet+0x5d81>
    5d81:      	cmpl	$0x0, (%rax)
    5d84:      	je	0x5b90 <kprobe_unwind_dotnet+0x5b90>
    5d8a:      	movabsq	$0x6e756f6620746f6e, %rax # imm = 0x6E756F6620746F6E
    5d94:      	movq	%rax, 0x18(%rsp)
    5d99:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    5da3:      	movq	%rax, 0x10(%rsp)
    5da8:      	movl	$0xa646e, 0x1f(%rsp)    # imm = 0xA646E
    5db0:      	leaq	0x10(%rsp), %rdi
    5db5:      	movl	$0x13, %eax
    5dba:      	movl	$0x6, %ecx
    5dbf:      	movl	$0x13, %esi
    5dc4:      	xorl	%eax, %eax
    5dc6:      	callq	*%rcx
    5dc8:      	jmp	0x5b90 <kprobe_unwind_dotnet+0x5b90>
    5dcd:      	movl	%r15d, %ecx
    5dd0:      	shrl	$0x8, %ecx
    5dd3:      	andl	$0xf, %ecx
    5dd6:      	je	0x5de1 <kprobe_unwind_dotnet+0x5de1>
    5dd8:      	addq	$-0x40, %r13
    5ddc:      	jmp	0x6081 <kprobe_unwind_dotnet+0x6081>
    5de1:      	movl	%r15d, %ecx
    5de4:      	shrl	$0xc, %ecx
    5de7:      	andl	$0xf, %ecx
    5dea:      	je	0x5e6a <kprobe_unwind_dotnet+0x5e6a>
    5dec:      	addq	$-0x60, %r13
    5df0:      	jmp	0x6081 <kprobe_unwind_dotnet+0x6081>
    5df5:      	movabsq	$0x6c25203a7066202c, %rax # imm = 0x6C25203A7066202C
    5dff:      	movq	%rax, 0x28(%rsp)
    5e04:      	movabsq	$0x786c25203a707320, %rax # imm = 0x786C25203A707320
    5e0e:      	movq	%rax, 0x20(%rsp)
    5e13:      	movabsq	$0x2c786c25203a6370, %rax # imm = 0x2C786C25203A6370
    5e1d:      	movq	%rax, 0x18(%rsp)
    5e22:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    5e2c:      	movq	%rax, 0x10(%rsp)
    5e31:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    5e39:      	leaq	0x10(%rsp), %rdi
    5e3e:      	movl	$0x23, %eax
    5e43:      	movl	$0x6, %r9d
    5e49:      	movl	$0x23, %esi
    5e4e:      	movq	%r12, %rdx
    5e51:      	movq	%rbx, %rcx
    5e54:      	movq	%r13, %r8
    5e57:      	xorl	%eax, %eax
    5e59:      	callq	*%r9
    5e5c:      	cmpq	%rbx, %r13
    5e5f:      	jae	0x5a17 <kprobe_unwind_dotnet+0x5a17>
    5e65:      	jmp	0x77bb <kprobe_unwind_dotnet+0x77bb>
    5e6a:      	movl	%r15d, %ecx
    5e6d:      	shrl	$0x10, %ecx
    5e70:      	andl	$0xf, %ecx
    5e73:      	je	0x5e7e <kprobe_unwind_dotnet+0x5e7e>
    5e75:      	addq	$-0x80, %r13
    5e79:      	jmp	0x6081 <kprobe_unwind_dotnet+0x6081>
    5e7e:      	movl	%r15d, %ecx
    5e81:      	shrl	$0x14, %ecx
    5e84:      	andl	$0xf, %ecx
    5e87:      	je	0x5f99 <kprobe_unwind_dotnet+0x5f99>
    5e8d:      	addq	$-0xa0, %r13
    5e94:      	jmp	0x6081 <kprobe_unwind_dotnet+0x6081>
    5e99:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    5ea3:      	movq	%rax, 0x36(%rsp)
    5ea8:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    5eb2:      	movq	%rax, 0x30(%rsp)
    5eb7:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    5ec1:      	movq	%rax, 0x28(%rsp)
    5ec6:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    5ed0:      	movq	%rax, 0x20(%rsp)
    5ed5:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    5edf:      	movq	%rax, 0x18(%rsp)
    5ee4:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    5eee:      	movq	%rax, 0x10(%rsp)
    5ef3:      	leaq	0x10(%rsp), %rdi
    5ef8:      	movl	$0x2e, %eax
    5efd:      	movl	$0x6, %ecx
    5f02:      	movl	0xc(%rsp), %edx
    5f06:      	movl	$0x2e, %esi
    5f0b:      	xorl	%eax, %eax
    5f0d:      	callq	*%rcx
    5f0f:      	jmp	0x580b <kprobe_unwind_dotnet+0x580b>
    5f14:      	movabsq	$0x6c25203a7066202c, %rax # imm = 0x6C25203A7066202C
    5f1e:      	movq	%rax, 0x28(%rsp)
    5f23:      	movabsq	$0x786c25203a707320, %rax # imm = 0x786C25203A707320
    5f2d:      	movq	%rax, 0x20(%rsp)
    5f32:      	movabsq	$0x2c786c25203a6370, %rax # imm = 0x2C786C25203A6370
    5f3c:      	movq	%rax, 0x18(%rsp)
    5f41:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    5f4b:      	movq	%rax, 0x10(%rsp)
    5f50:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    5f58:      	leaq	0x10(%rsp), %rdi
    5f5d:      	movl	$0x23, %eax
    5f62:      	movl	$0x6, %r9d
    5f68:      	movq	0xed0(%r14), %rdx
    5f6f:      	movq	0xed8(%r14), %rcx
    5f76:      	movq	0xee0(%r14), %r8
    5f7d:      	movl	$0x23, %esi
    5f82:      	xorl	%eax, %eax
    5f84:      	callq	*%r9
    5f87:      	cmpq	$0x100, %rbp            # imm = 0x100
    5f8e:      	jae	0x5af5 <kprobe_unwind_dotnet+0x5af5>
    5f94:      	jmp	0x60ce <kprobe_unwind_dotnet+0x60ce>
    5f99:      	movl	%r15d, %ecx
    5f9c:      	shrl	$0x18, %ecx
    5f9f:      	andl	$0xf, %ecx
    5fa2:      	je	0x6073 <kprobe_unwind_dotnet+0x6073>
    5fa8:      	addq	$-0xc0, %r13
    5faf:      	jmp	0x6081 <kprobe_unwind_dotnet+0x6081>
    5fb4:      	leaq	(%rip), %rsi            # 0x5fbb <kprobe_unwind_dotnet+0x5fbb>
    5fbb:      	leaq	0x10(%rsp), %rax
    5fc0:      	movl	$0x8, %ecx
    5fc5:      	movq	%rax, %rdi
    5fc8:      	rep		movsq	(%rsi), %es:(%rdi)
    5fcb:      	movw	$0xa, 0x50(%rsp)
    5fd2:      	movl	$0x42, %ecx
    5fd7:      	movl	$0x6, %r9d
    5fdd:      	movq	%rax, %rdi
    5fe0:      	movl	$0x42, %esi
    5fe5:      	movq	%r13, %rdx
    5fe8:      	movq	%rbx, %rcx
    5feb:      	movq	%rbp, %r8
    5fee:      	xorl	%eax, %eax
    5ff0:      	callq	*%r9
    5ff3:      	jmp	0x5b19 <kprobe_unwind_dotnet+0x5b19>
    5ff8:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    6002:      	movq	%rax, 0x36(%rsp)
    6007:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    6011:      	movq	%rax, 0x30(%rsp)
    6016:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    6020:      	movq	%rax, 0x28(%rsp)
    6025:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    602f:      	movq	%rax, 0x20(%rsp)
    6034:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    603e:      	movq	%rax, 0x18(%rsp)
    6043:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    604d:      	movq	%rax, 0x10(%rsp)
    6052:      	leaq	0x10(%rsp), %rdi
    6057:      	movl	$0x2e, %eax
    605c:      	movl	$0x6, %ecx
    6061:      	movl	0x68(%rsp), %edx
    6065:      	movl	$0x2e, %esi
    606a:      	xorl	%eax, %eax
    606c:      	callq	*%rcx
    606e:      	jmp	0x59cb <kprobe_unwind_dotnet+0x59cb>
    6073:      	shrl	$0x1c, %r15d
    6077:      	addq	$-0xe0, %r13
    607e:      	movl	%r15d, %ecx
    6081:      	addq	%r13, %rbx
    6084:      	leal	-0x4(,%rcx,4), %r15d
    608c:      	addq	%rbx, %r15
    608f:      	movq	(%rip), %rax            # 0x6096 <kprobe_unwind_dotnet+0x6096>
    6096:      	cmpl	$0x0, (%rax)
    6099:      	jne	0x652b <kprobe_unwind_dotnet+0x652b>
    609f:      	leaq	-0x8(%r15), %rdx
    60a3:      	leaq	0x68(%rsp), %rdi
    60a8:      	movl	$0x8, %eax
    60ad:      	movl	$0x70, %ecx
    60b2:      	movl	$0x8, %esi
    60b7:      	callq	*%rcx
    60b9:      	testq	%rax, %rax
    60bc:      	movq	(%rip), %rbp            # 0x60c3 <kprobe_unwind_dotnet+0x60c3>
    60c3:      	jne	0xbb6 <kprobe_unwind_dotnet+0xbb6>
    60c9:      	movl	$0x1f, %ebp
    60ce:      	movq	(%rip), %rax            # 0x60d5 <kprobe_unwind_dotnet+0x60d5>
    60d5:      	cmpl	$0x0, (%rax)
    60d8:      	jne	0x6327 <kprobe_unwind_dotnet+0x6327>
    60de:      	movl	0x2c0(%r14), %eax
    60e5:      	cmpq	$0x7e, %rax
    60e9:      	ja	0xc0c <kprobe_unwind_dotnet+0xc0c>
    60ef:      	movq	0x68(%rsp), %rcx
    60f4:      	subq	%r15, %r12
    60f7:      	shlq	$0x5, %rcx
    60fb:      	addq	%rbp, %rcx
    60fe:      	leal	0x1(%rax), %edx
    6101:      	movl	%edx, 0x2c0(%r14)
    6108:      	leaq	(%rax,%rax,2), %rax
    610c:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    6114:      	movq	%r12, 0x2d8(%r14,%rax,8)
    611c:      	movb	$0xa, 0x2e0(%r14,%rax,8)
    6125:      	movzbl	0x88(%rsp), %ecx
    612d:      	movb	%cl, 0x2e1(%r14,%rax,8)
    6135:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    6141:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    614c:      	movl	$0x5b, 0xc(%rsp)
    6154:      	movq	(%rip), %rdi            # 0x615b <kprobe_unwind_dotnet+0x615b>
    615b:      	leaq	0xc(%rsp), %rsi
    6160:      	movl	$0x1, %eax
    6165:      	callq	*%rax
    6167:      	testq	%rax, %rax
    616a:      	je	0x6171 <kprobe_unwind_dotnet+0x6171>
    616c:      	incq	(%rax)
    616f:      	jmp	0x6181 <kprobe_unwind_dotnet+0x6181>
    6171:      	movq	(%rip), %rax            # 0x6178 <kprobe_unwind_dotnet+0x6178>
    6178:      	cmpl	$0x0, (%rax)
    617b:      	jne	0x6423 <kprobe_unwind_dotnet+0x6423>
    6181:      	movq	0x98(%rsp), %rax
    6189:      	movq	(%rax), %r13
    618c:      	movq	(%rip), %rax            # 0x6193 <kprobe_unwind_dotnet+0x6193>
    6193:      	movl	(%rax), %eax
    6195:      	testq	%r13, %r13
    6198:      	je	0x88ec <kprobe_unwind_dotnet+0x88ec>
    619e:      	testl	%eax, %eax
    61a0:      	jne	0x6386 <kprobe_unwind_dotnet+0x6386>
    61a6:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    61b0:      	cmpq	%rax, %r13
    61b3:      	ja	0x2516 <kprobe_unwind_dotnet+0x2516>
    61b9:      	cmpq	$0x1000, %r13           # imm = 0x1000
    61c0:      	jb	0x26b1 <kprobe_unwind_dotnet+0x26b1>
    61c6:      	movl	(%r14), %eax
    61c9:      	movl	$0x60, 0x70(%rsp)
    61d1:      	movbel	%eax, 0x74(%rsp)
    61d7:      	movbeq	%r13, 0x78(%rsp)
    61de:      	movq	(%rip), %rdi            # 0x61e5 <kprobe_unwind_dotnet+0x61e5>
    61e5:      	leaq	0x70(%rsp), %rsi
    61ea:      	movl	$0x1, %eax
    61ef:      	callq	*%rax
    61f1:      	testq	%rax, %rax
    61f4:      	je	0x8837 <kprobe_unwind_dotnet+0x8837>
    61fa:      	movq	0x8(%rax), %r12
    61fe:      	movq	%r12, %rcx
    6201:      	movabsq	$0xffffffffffffff, %rdx # imm = 0xFFFFFFFFFFFFFF
    620b:      	andq	%rdx, %rcx
    620e:      	movq	%rcx, 0xf20(%r14)
    6215:      	movq	(%rax), %rax
    6218:      	movq	%rax, 0xf10(%r14)
    621f:      	shrq	$0x38, %r12
    6223:      	movq	%r13, %rax
    6226:      	subq	%rcx, %rax
    6229:      	movq	%rax, 0xf18(%r14)
    6230:      	movq	(%rip), %rax            # 0x6237 <kprobe_unwind_dotnet+0x6237>
    6237:      	cmpl	$0x0, (%rax)
    623a:      	jne	0x6625 <kprobe_unwind_dotnet+0x6625>
    6240:      	cmpl	$0x1, %r12d
    6244:      	jne	0x7322 <kprobe_unwind_dotnet+0x7322>
    624a:      	movq	0xf10(%r14), %rax
    6251:      	movq	%rax, 0x70(%rsp)
    6256:      	movq	0xf18(%r14), %rbx
    625d:      	movq	(%rip), %rdi            # 0x6264 <kprobe_unwind_dotnet+0x6264>
    6264:      	leaq	0x70(%rsp), %rsi
    6269:      	movl	$0x1, %eax
    626e:      	callq	*%rax
    6270:      	movl	$0x1, %r12d
    6276:      	testq	%rax, %rax
    6279:      	je	0x7322 <kprobe_unwind_dotnet+0x7322>
    627f:      	movq	%rax, %r15
    6282:      	cmpq	%rbx, (%rax)
    6285:      	ja	0x628d <kprobe_unwind_dotnet+0x628d>
    6287:      	cmpq	%rbx, 0x8(%r15)
    628b:      	jae	0x62a1 <kprobe_unwind_dotnet+0x62a1>
    628d:      	cmpq	%rbx, 0x10(%r15)
    6291:      	ja	0x7322 <kprobe_unwind_dotnet+0x7322>
    6297:      	cmpq	%rbx, 0x18(%r15)
    629b:      	jb	0x7322 <kprobe_unwind_dotnet+0x7322>
    62a1:      	movq	(%rip), %rax            # 0x62a8 <kprobe_unwind_dotnet+0x62a8>
    62a8:      	cmpl	$0x0, (%rax)
    62ab:      	jne	0x727b <kprobe_unwind_dotnet+0x727b>
    62b1:      	movl	0x1380(%r14), %eax
    62b8:      	movl	0x20(%r15), %ecx
    62bc:      	btl	%ecx, %eax
    62bf:      	jae	0x72e8 <kprobe_unwind_dotnet+0x72e8>
    62c5:      	movq	(%rip), %rax            # 0x62cc <kprobe_unwind_dotnet+0x62cc>
    62cc:      	cmpl	$0x0, (%rax)
    62cf:      	je	0x7322 <kprobe_unwind_dotnet+0x7322>
    62d5:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    62df:      	movq	%rax, 0x20(%rsp)
    62e4:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    62ee:      	movq	%rax, 0x18(%rsp)
    62f3:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    62fd:      	movq	%rax, 0x10(%rsp)
    6302:      	movl	$0xa656e, 0x27(%rsp)    # imm = 0xA656E
    630a:      	leaq	0x10(%rsp), %rdi
    630f:      	movl	$0x1b, %eax
    6314:      	movl	$0x6, %ecx
    6319:      	movl	$0x1b, %esi
    631e:      	xorl	%eax, %eax
    6320:      	callq	*%rcx
    6322:      	jmp	0x7322 <kprobe_unwind_dotnet+0x7322>
    6327:      	leaq	(%rip), %rsi            # 0x632e <kprobe_unwind_dotnet+0x632e>
    632e:      	leaq	0x10(%rsp), %rax
    6333:      	movl	$0x8, %ecx
    6338:      	movq	%rax, %rdi
    633b:      	rep		movsq	(%rsi), %es:(%rdi)
    633e:      	movb	$0x0, 0x52(%rsp)
    6343:      	movw	$0xa78, 0x50(%rsp)      # imm = 0xA78
    634a:      	movl	$0x43, %ecx
    634f:      	movl	$0x6, %r9d
    6355:      	movq	0x68(%rsp), %rcx
    635a:      	movq	%r12, %r8
    635d:      	subq	%r15, %r8
    6360:      	movq	%rax, %rdi
    6363:      	movl	$0x43, %esi
    6368:      	movq	%r15, %rdx
    636b:      	xorl	%eax, %eax
    636d:      	callq	*%r9
    6370:      	movl	0x2c0(%r14), %eax
    6377:      	cmpq	$0x7e, %rax
    637b:      	ja	0xc0c <kprobe_unwind_dotnet+0xc0c>
    6381:      	jmp	0x60ef <kprobe_unwind_dotnet+0x60ef>
    6386:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    6390:      	movq	%rax, 0x38(%rsp)
    6395:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    639f:      	movq	%rax, 0x30(%rsp)
    63a4:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    63ae:      	movq	%rax, 0x28(%rsp)
    63b3:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    63bd:      	movq	%rax, 0x20(%rsp)
    63c2:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    63cc:      	movq	%rax, 0x18(%rsp)
    63d1:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    63db:      	movq	%rax, 0x10(%rsp)
    63e0:      	movb	$0x0, 0x40(%rsp)
    63e5:      	leaq	0x10(%rsp), %rdi
    63ea:      	movl	$0x31, %eax
    63ef:      	movl	$0x6, %ecx
    63f4:      	movl	0x2c0(%r14), %edx
    63fb:      	movl	$0x31, %esi
    6400:      	xorl	%eax, %eax
    6402:      	callq	*%rcx
    6404:      	movq	0xed0(%r14), %r13
    640b:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    6415:      	cmpq	%rax, %r13
    6418:      	ja	0x2516 <kprobe_unwind_dotnet+0x2516>
    641e:      	jmp	0x61b9 <kprobe_unwind_dotnet+0x61b9>
    6423:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    642d:      	movq	%rax, 0x36(%rsp)
    6432:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    643c:      	movq	%rax, 0x30(%rsp)
    6441:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    644b:      	movq	%rax, 0x28(%rsp)
    6450:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    645a:      	movq	%rax, 0x20(%rsp)
    645f:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    6469:      	movq	%rax, 0x18(%rsp)
    646e:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    6478:      	movq	%rax, 0x10(%rsp)
    647d:      	leaq	0x10(%rsp), %rdi
    6482:      	movl	$0x2e, %eax
    6487:      	movl	$0x6, %ecx
    648c:      	movl	0xc(%rsp), %edx
    6490:      	movl	$0x2e, %esi
    6495:      	xorl	%eax, %eax
    6497:      	callq	*%rcx
    6499:      	jmp	0x6181 <kprobe_unwind_dotnet+0x6181>
    649e:      	movabsq	$0xa782520797274, %rax  # imm = 0xA782520797274
    64a8:      	movq	%rax, 0x3e(%rsp)
    64ad:      	movabsq	$0x72746e6520747372, %rax # imm = 0x72746E6520747372
    64b7:      	movq	%rax, 0x38(%rsp)
    64bc:      	movabsq	$0x6966203a786c2520, %rax # imm = 0x6966203A786C2520
    64c6:      	movq	%rax, 0x30(%rsp)
    64cb:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    64d5:      	movq	%rax, 0x28(%rsp)
    64da:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    64e4:      	movq	%rax, 0x20(%rsp)
    64e9:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    64f3:      	movq	%rax, 0x18(%rsp)
    64f8:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    6502:      	movq	%rax, 0x10(%rsp)
    6507:      	leaq	0x10(%rsp), %rdi
    650c:      	movl	$0x36, %eax
    6511:      	movl	$0x6, %r8d
    6517:      	movl	$0x36, %esi
    651c:      	movq	%r15, %rdx
    651f:      	movl	%ebp, %ecx
    6521:      	xorl	%eax, %eax
    6523:      	callq	*%r8
    6526:      	jmp	0x5bcc <kprobe_unwind_dotnet+0x5bcc>
    652b:      	movabsq	$0xa786c253d7465, %rax  # imm = 0xA786C253D7465
    6535:      	movq	%rax, 0x36(%rsp)
    653a:      	movabsq	$0x746572202c78253d, %rax # imm = 0x746572202C78253D
    6544:      	movq	%rax, 0x30(%rsp)
    6549:      	movabsq	$0x6c6176202c786c25, %rax # imm = 0x6C6176202C786C25
    6553:      	movq	%rax, 0x28(%rsp)
    6558:      	movabsq	$0x203d2061746c6564, %rax # imm = 0x203D2061746C6564
    6562:      	movq	%rax, 0x20(%rsp)
    6567:      	movabsq	$0x5f6370203e2d2d20, %rax # imm = 0x5F6370203E2D2D20
    6571:      	movq	%rax, 0x18(%rsp)
    6576:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    6580:      	movq	%rax, 0x10(%rsp)
    6585:      	leaq	0x10(%rsp), %rdi
    658a:      	movl	$0x2e, %eax
    658f:      	movl	$0x6, %r9d
    6595:      	movl	$0x2e, %esi
    659a:      	movq	%r13, %rdx
    659d:      	movq	%r15, %r8
    65a0:      	xorl	%eax, %eax
    65a2:      	callq	*%r9
    65a5:      	jmp	0x609f <kprobe_unwind_dotnet+0x609f>
    65aa:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    65b4:      	movq	%rax, 0x36(%rsp)
    65b9:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    65c3:      	movq	%rax, 0x30(%rsp)
    65c8:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    65d2:      	movq	%rax, 0x28(%rsp)
    65d7:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    65e1:      	movq	%rax, 0x20(%rsp)
    65e6:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    65f0:      	movq	%rax, 0x18(%rsp)
    65f5:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    65ff:      	movq	%rax, 0x10(%rsp)
    6604:      	leaq	0x10(%rsp), %rdi
    6609:      	movl	$0x2e, %eax
    660e:      	movl	$0x6, %ecx
    6613:      	movl	0xc(%rsp), %edx
    6617:      	movl	$0x2e, %esi
    661c:      	xorl	%eax, %eax
    661e:      	callq	*%rcx
    6620:      	jmp	0x5c30 <kprobe_unwind_dotnet+0x5c30>
    6625:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    662f:      	movq	%rax, 0x38(%rsp)
    6634:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    663e:      	movq	%rax, 0x30(%rsp)
    6643:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    664d:      	movq	%rax, 0x28(%rsp)
    6652:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    665c:      	movq	%rax, 0x20(%rsp)
    6661:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    666b:      	movq	%rax, 0x18(%rsp)
    6670:      	movabsq	$0x6365732074786554, %rbx # imm = 0x6365732074786554
    667a:      	movq	%rbx, 0x10(%rsp)
    667f:      	movw	$0xa, 0x40(%rsp)
    6686:      	leaq	0x10(%rsp), %rdi
    668b:      	movl	$0x32, %eax
    6690:      	movl	$0x6, %r9d
    6696:      	movq	0xf10(%r14), %rcx
    669d:      	movl	$0x32, %esi
    66a2:      	movq	%r13, %rdx
    66a5:      	movl	%r12d, %r8d
    66a8:      	xorl	%eax, %eax
    66aa:      	callq	*%r9
    66ad:      	movq	(%rip), %rax            # 0x66b4 <kprobe_unwind_dotnet+0x66b4>
    66b4:      	cmpl	$0x0, (%rax)
    66b7:      	je	0x6240 <kprobe_unwind_dotnet+0x6240>
    66bd:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    66c7:      	movq	%rax, 0x37(%rsp)
    66cc:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    66d6:      	movq	%rax, 0x30(%rsp)
    66db:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    66e5:      	movq	%rax, 0x28(%rsp)
    66ea:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    66f4:      	movq	%rax, 0x20(%rsp)
    66f9:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    6703:      	movq	%rax, 0x18(%rsp)
    6708:      	movq	%rbx, 0x10(%rsp)
    670d:      	leaq	0x10(%rsp), %rdi
    6712:      	movl	$0x2f, %eax
    6717:      	movl	$0x6, %r8d
    671d:      	movq	0xf18(%r14), %rcx
    6724:      	movq	0xf20(%r14), %rdx
    672b:      	movl	$0x2f, %esi
    6730:      	xorl	%eax, %eax
    6732:      	callq	*%r8
    6735:      	jmp	0x6240 <kprobe_unwind_dotnet+0x6240>
    673a:      	movabsq	$0xa782520797274, %rax  # imm = 0xA782520797274
    6744:      	movq	%rax, 0x3f(%rsp)
    6749:      	movabsq	$0x746e6520646e6f63, %rax # imm = 0x746E6520646E6F63
    6753:      	movq	%rax, 0x38(%rsp)
    6758:      	movabsq	$0x6573203a786c2520, %rax # imm = 0x6573203A786C2520
    6762:      	movq	%rax, 0x30(%rsp)
    6767:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    6771:      	movq	%rax, 0x28(%rsp)
    6776:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    6780:      	movq	%rax, 0x20(%rsp)
    6785:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    678f:      	movq	%rax, 0x18(%rsp)
    6794:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    679e:      	movq	%rax, 0x10(%rsp)
    67a3:      	leaq	0x10(%rsp), %rdi
    67a8:      	movl	$0x37, %eax
    67ad:      	movl	$0x6, %r8d
    67b3:      	movl	$0x37, %esi
    67b8:      	movq	%r13, %rdx
    67bb:      	movl	%r15d, %ecx
    67be:      	xorl	%eax, %eax
    67c0:      	callq	*%r8
    67c3:      	xorl	%ecx, %ecx
    67c5:      	testl	%r15d, %r15d
    67c8:      	jne	0x5cea <kprobe_unwind_dotnet+0x5cea>
    67ce:      	movq	0x1170(%r14), %rax
    67d5:      	movl	$0xffffff84, %ecx       # imm = 0xFFFFFF84
    67da:      	testq	%rax, %rax
    67dd:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    67e3:      	movq	0x1168(%r14), %rax
    67ea:      	movl	$0xffffff86, %ecx       # imm = 0xFFFFFF86
    67ef:      	testq	%rax, %rax
    67f2:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    67f8:      	movq	0x1160(%r14), %rax
    67ff:      	movl	$0xffffff88, %ecx       # imm = 0xFFFFFF88
    6804:      	testq	%rax, %rax
    6807:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    680d:      	movq	0x1158(%r14), %rax
    6814:      	movl	$0xffffff8a, %ecx       # imm = 0xFFFFFF8A
    6819:      	testq	%rax, %rax
    681c:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6822:      	movq	0x1150(%r14), %rax
    6829:      	movl	$0xffffff8c, %ecx       # imm = 0xFFFFFF8C
    682e:      	testq	%rax, %rax
    6831:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6837:      	movq	0x1148(%r14), %rax
    683e:      	movl	$0xffffff8e, %ecx       # imm = 0xFFFFFF8E
    6843:      	testq	%rax, %rax
    6846:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    684c:      	movq	0x1140(%r14), %rax
    6853:      	movl	$0xffffff90, %ecx       # imm = 0xFFFFFF90
    6858:      	testq	%rax, %rax
    685b:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6861:      	movq	0x1138(%r14), %rax
    6868:      	movl	$0xffffff92, %ecx       # imm = 0xFFFFFF92
    686d:      	testq	%rax, %rax
    6870:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6876:      	movq	0x1130(%r14), %rax
    687d:      	movl	$0xffffff94, %ecx       # imm = 0xFFFFFF94
    6882:      	testq	%rax, %rax
    6885:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    688b:      	movq	0x1128(%r14), %rax
    6892:      	movl	$0xffffff96, %ecx       # imm = 0xFFFFFF96
    6897:      	testq	%rax, %rax
    689a:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    68a0:      	movq	0x1120(%r14), %rax
    68a7:      	movl	$0xffffff98, %ecx       # imm = 0xFFFFFF98
    68ac:      	testq	%rax, %rax
    68af:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    68b5:      	movq	0x1118(%r14), %rax
    68bc:      	movl	$0xffffff9a, %ecx       # imm = 0xFFFFFF9A
    68c1:      	testq	%rax, %rax
    68c4:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    68ca:      	movq	0x1110(%r14), %rax
    68d1:      	movl	$0xffffff9c, %ecx       # imm = 0xFFFFFF9C
    68d6:      	testq	%rax, %rax
    68d9:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    68df:      	movq	0x1108(%r14), %rax
    68e6:      	movl	$0xffffff9e, %ecx       # imm = 0xFFFFFF9E
    68eb:      	testq	%rax, %rax
    68ee:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    68f4:      	movq	0x1100(%r14), %rax
    68fb:      	movl	$0xffffffa0, %ecx       # imm = 0xFFFFFFA0
    6900:      	testq	%rax, %rax
    6903:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6909:      	movq	0x10f8(%r14), %rax
    6910:      	movl	$0xffffffa2, %ecx       # imm = 0xFFFFFFA2
    6915:      	testq	%rax, %rax
    6918:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    691e:      	movq	0x10f0(%r14), %rax
    6925:      	movl	$0xffffffa4, %ecx       # imm = 0xFFFFFFA4
    692a:      	testq	%rax, %rax
    692d:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6933:      	movq	0x10e8(%r14), %rax
    693a:      	movl	$0xffffffa6, %ecx       # imm = 0xFFFFFFA6
    693f:      	testq	%rax, %rax
    6942:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6948:      	movq	0x10e0(%r14), %rax
    694f:      	movl	$0xffffffa8, %ecx       # imm = 0xFFFFFFA8
    6954:      	testq	%rax, %rax
    6957:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    695d:      	movq	0x10d8(%r14), %rax
    6964:      	movl	$0xffffffaa, %ecx       # imm = 0xFFFFFFAA
    6969:      	testq	%rax, %rax
    696c:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6972:      	movq	0x10d0(%r14), %rax
    6979:      	movl	$0xffffffac, %ecx       # imm = 0xFFFFFFAC
    697e:      	testq	%rax, %rax
    6981:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6987:      	movq	0x10c8(%r14), %rax
    698e:      	movl	$0xffffffae, %ecx       # imm = 0xFFFFFFAE
    6993:      	testq	%rax, %rax
    6996:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    699c:      	movq	0x10c0(%r14), %rax
    69a3:      	movl	$0xffffffb0, %ecx       # imm = 0xFFFFFFB0
    69a8:      	testq	%rax, %rax
    69ab:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    69b1:      	movq	0x10b8(%r14), %rax
    69b8:      	movl	$0xffffffb2, %ecx       # imm = 0xFFFFFFB2
    69bd:      	testq	%rax, %rax
    69c0:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    69c6:      	movq	0x10b0(%r14), %rax
    69cd:      	movl	$0xffffffb4, %ecx       # imm = 0xFFFFFFB4
    69d2:      	testq	%rax, %rax
    69d5:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    69db:      	movq	0x10a8(%r14), %rax
    69e2:      	movl	$0xffffffb6, %ecx       # imm = 0xFFFFFFB6
    69e7:      	testq	%rax, %rax
    69ea:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    69f0:      	movq	0x10a0(%r14), %rax
    69f7:      	movl	$0xffffffb8, %ecx       # imm = 0xFFFFFFB8
    69fc:      	testq	%rax, %rax
    69ff:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6a05:      	movq	0x1098(%r14), %rax
    6a0c:      	movl	$0xffffffba, %ecx       # imm = 0xFFFFFFBA
    6a11:      	testq	%rax, %rax
    6a14:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6a1a:      	movq	0x1090(%r14), %rax
    6a21:      	movl	$0xffffffbc, %ecx       # imm = 0xFFFFFFBC
    6a26:      	testq	%rax, %rax
    6a29:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6a2f:      	movq	0x1088(%r14), %rax
    6a36:      	movl	$0xffffffbe, %ecx       # imm = 0xFFFFFFBE
    6a3b:      	testq	%rax, %rax
    6a3e:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6a44:      	movq	0x1080(%r14), %rax
    6a4b:      	movl	$0xffffffc0, %ecx       # imm = 0xFFFFFFC0
    6a50:      	testq	%rax, %rax
    6a53:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6a59:      	movq	0x1078(%r14), %rax
    6a60:      	movl	$0xffffffc2, %ecx       # imm = 0xFFFFFFC2
    6a65:      	testq	%rax, %rax
    6a68:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6a6e:      	movq	0x1070(%r14), %rax
    6a75:      	movl	$0xffffffc4, %ecx       # imm = 0xFFFFFFC4
    6a7a:      	testq	%rax, %rax
    6a7d:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6a83:      	movq	0x1068(%r14), %rax
    6a8a:      	movl	$0xffffffc6, %ecx       # imm = 0xFFFFFFC6
    6a8f:      	testq	%rax, %rax
    6a92:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6a98:      	movq	0x1060(%r14), %rax
    6a9f:      	movl	$0xffffffc8, %ecx       # imm = 0xFFFFFFC8
    6aa4:      	testq	%rax, %rax
    6aa7:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6aad:      	movq	0x1058(%r14), %rax
    6ab4:      	movl	$0xffffffca, %ecx       # imm = 0xFFFFFFCA
    6ab9:      	testq	%rax, %rax
    6abc:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6ac2:      	movq	0x1050(%r14), %rax
    6ac9:      	movl	$0xffffffcc, %ecx       # imm = 0xFFFFFFCC
    6ace:      	testq	%rax, %rax
    6ad1:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6ad7:      	movq	0x1048(%r14), %rax
    6ade:      	movl	$0xffffffce, %ecx       # imm = 0xFFFFFFCE
    6ae3:      	testq	%rax, %rax
    6ae6:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6aec:      	movq	0x1040(%r14), %rax
    6af3:      	movl	$0xffffffd0, %ecx       # imm = 0xFFFFFFD0
    6af8:      	testq	%rax, %rax
    6afb:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6b01:      	movq	0x1038(%r14), %rax
    6b08:      	movl	$0xffffffd2, %ecx       # imm = 0xFFFFFFD2
    6b0d:      	testq	%rax, %rax
    6b10:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6b16:      	movq	0x1030(%r14), %rax
    6b1d:      	movl	$0xffffffd4, %ecx       # imm = 0xFFFFFFD4
    6b22:      	testq	%rax, %rax
    6b25:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6b2b:      	movq	0x1028(%r14), %rax
    6b32:      	movl	$0xffffffd6, %ecx       # imm = 0xFFFFFFD6
    6b37:      	testq	%rax, %rax
    6b3a:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6b40:      	movq	0x1020(%r14), %rax
    6b47:      	movl	$0xffffffd8, %ecx       # imm = 0xFFFFFFD8
    6b4c:      	testq	%rax, %rax
    6b4f:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6b55:      	movq	0x1018(%r14), %rax
    6b5c:      	movl	$0xffffffda, %ecx       # imm = 0xFFFFFFDA
    6b61:      	testq	%rax, %rax
    6b64:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6b6a:      	movq	0x1010(%r14), %rax
    6b71:      	movl	$0xffffffdc, %ecx       # imm = 0xFFFFFFDC
    6b76:      	testq	%rax, %rax
    6b79:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6b7f:      	movq	0x1008(%r14), %rax
    6b86:      	movl	$0xffffffde, %ecx       # imm = 0xFFFFFFDE
    6b8b:      	testq	%rax, %rax
    6b8e:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6b94:      	movq	0x1000(%r14), %rax
    6b9b:      	movl	$0xffffffe0, %ecx       # imm = 0xFFFFFFE0
    6ba0:      	testq	%rax, %rax
    6ba3:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6ba9:      	movq	0xff8(%r14), %rax
    6bb0:      	movl	$0xffffffe2, %ecx       # imm = 0xFFFFFFE2
    6bb5:      	testq	%rax, %rax
    6bb8:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6bbe:      	movq	0xff0(%r14), %rax
    6bc5:      	movl	$0xffffffe4, %ecx       # imm = 0xFFFFFFE4
    6bca:      	testq	%rax, %rax
    6bcd:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6bd3:      	movq	0xfe8(%r14), %rax
    6bda:      	movl	$0xffffffe6, %ecx       # imm = 0xFFFFFFE6
    6bdf:      	testq	%rax, %rax
    6be2:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6be8:      	movq	0xfe0(%r14), %rax
    6bef:      	movl	$0xffffffe8, %ecx       # imm = 0xFFFFFFE8
    6bf4:      	testq	%rax, %rax
    6bf7:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6bfd:      	movq	0xfd8(%r14), %rax
    6c04:      	movl	$0xffffffea, %ecx       # imm = 0xFFFFFFEA
    6c09:      	testq	%rax, %rax
    6c0c:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6c12:      	movq	0xfd0(%r14), %rax
    6c19:      	movl	$0xffffffec, %ecx       # imm = 0xFFFFFFEC
    6c1e:      	testq	%rax, %rax
    6c21:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6c27:      	movq	0xfc8(%r14), %rax
    6c2e:      	movl	$0xffffffee, %ecx       # imm = 0xFFFFFFEE
    6c33:      	testq	%rax, %rax
    6c36:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6c3c:      	movq	0xfc0(%r14), %rax
    6c43:      	movl	$0xfffffff0, %ecx       # imm = 0xFFFFFFF0
    6c48:      	testq	%rax, %rax
    6c4b:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6c51:      	movq	0xfb8(%r14), %rax
    6c58:      	movl	$0xfffffff2, %ecx       # imm = 0xFFFFFFF2
    6c5d:      	testq	%rax, %rax
    6c60:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6c62:      	movq	0xfb0(%r14), %rax
    6c69:      	movl	$0xfffffff4, %ecx       # imm = 0xFFFFFFF4
    6c6e:      	testq	%rax, %rax
    6c71:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6c73:      	movq	0xfa8(%r14), %rax
    6c7a:      	movl	$0xfffffff6, %ecx       # imm = 0xFFFFFFF6
    6c7f:      	testq	%rax, %rax
    6c82:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6c84:      	movq	0xfa0(%r14), %rax
    6c8b:      	movl	$0xfffffff8, %ecx       # imm = 0xFFFFFFF8
    6c90:      	testq	%rax, %rax
    6c93:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6c95:      	movq	0xf98(%r14), %rax
    6c9c:      	movl	$0xfffffffa, %ecx       # imm = 0xFFFFFFFA
    6ca1:      	testq	%rax, %rax
    6ca4:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6ca6:      	movq	0xf90(%r14), %rax
    6cad:      	movl	$0xfffffffc, %ecx       # imm = 0xFFFFFFFC
    6cb2:      	testq	%rax, %rax
    6cb5:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6cb7:      	movq	0xf88(%r14), %rax
    6cbe:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    6cc3:      	testq	%rax, %rax
    6cc6:      	jne	0x6cd5 <kprobe_unwind_dotnet+0x6cd5>
    6cc8:      	movq	0x90(%rsp), %rax
    6cd0:      	movq	(%rax), %rax
    6cd3:      	xorl	%ecx, %ecx
    6cd5:      	xorl	%edx, %edx
    6cd7:      	movq	%rax, %r15
    6cda:      	shrq	$0x20, %r15
    6cde:      	setne	%dl
    6ce1:      	cmovel	%eax, %r15d
    6ce5:      	subl	%edx, %ecx
    6ce7:      	addl	$0x7e, %ecx
    6cea:      	movl	%ecx, %eax
    6cec:      	shll	$0x8, %eax
    6cef:      	subq	%rax, %r13
    6cf2:      	jb	0x5cf8 <kprobe_unwind_dotnet+0x5cf8>
    6cf8:      	movq	(%rip), %rax            # 0x6cff <kprobe_unwind_dotnet+0x6cff>
    6cff:      	cmpl	$0x0, (%rax)
    6d02:      	jne	0x71dc <kprobe_unwind_dotnet+0x71dc>
    6d08:      	testl	%r15d, %r15d
    6d0b:      	jne	0x5bfc <kprobe_unwind_dotnet+0x5bfc>
    6d11:      	movl	$0x5f, 0xc(%rsp)
    6d19:      	movq	(%rip), %rdi            # 0x6d20 <kprobe_unwind_dotnet+0x6d20>
    6d20:      	leaq	0xc(%rsp), %rsi
    6d25:      	movl	$0x1, %eax
    6d2a:      	callq	*%rax
    6d2c:      	testq	%rax, %rax
    6d2f:      	je	0x6d36 <kprobe_unwind_dotnet+0x6d36>
    6d31:      	incq	(%rax)
    6d34:      	jmp	0x6d46 <kprobe_unwind_dotnet+0x6d46>
    6d36:      	movq	(%rip), %rax            # 0x6d3d <kprobe_unwind_dotnet+0x6d3d>
    6d3d:      	cmpl	$0x0, (%rax)
    6d40:      	jne	0x7ae0 <kprobe_unwind_dotnet+0x7ae0>
    6d46:      	movl	$0x1773, %edx           # imm = 0x1773
    6d4b:      	movb	$0x1, %bl
    6d4d:      	movq	(%rip), %rax            # 0x6d54 <kprobe_unwind_dotnet+0x6d54>
    6d54:      	cmpl	$0x0, (%rax)
    6d57:      	je	0x5c47 <kprobe_unwind_dotnet+0x5c47>
    6d5d:      	movabsq	$0xa642520687469, %rax  # imm = 0xA642520687469
    6d67:      	movq	%rax, 0x30(%rsp)
    6d6c:      	movabsq	$0x772064656c696166, %rax # imm = 0x772064656C696166
    6d76:      	movq	%rax, 0x28(%rsp)
    6d7b:      	movabsq	$0x2074726174735f65, %rax # imm = 0x2074726174735F65
    6d85:      	movq	%rax, 0x20(%rsp)
    6d8a:      	movabsq	$0x646f63203e2d2d20, %rax # imm = 0x646F63203E2D2D20
    6d94:      	movq	%rax, 0x18(%rsp)
    6d99:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    6da3:      	movq	%rax, 0x10(%rsp)
    6da8:      	leaq	0x10(%rsp), %rdi
    6dad:      	movl	$0x28, %eax
    6db2:      	movl	$0x6, %ecx
    6db7:      	movl	$0x28, %esi
    6dbc:      	xorl	%eax, %eax
    6dbe:      	callq	*%rcx
    6dc0:      	jmp	0x5c47 <kprobe_unwind_dotnet+0x5c47>
    6dc5:      	movq	0x1108(%r14), %rax
    6dcc:      	movl	$0xffffff9e, %ecx       # imm = 0xFFFFFF9E
    6dd1:      	testq	%rax, %rax
    6dd4:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    6dda:      	movq	0x1100(%r14), %rax
    6de1:      	movl	$0xffffffa0, %ecx       # imm = 0xFFFFFFA0
    6de6:      	testq	%rax, %rax
    6de9:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    6def:      	movq	0x10f8(%r14), %rax
    6df6:      	movl	$0xffffffa2, %ecx       # imm = 0xFFFFFFA2
    6dfb:      	testq	%rax, %rax
    6dfe:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    6e04:      	movq	0x10f0(%r14), %rax
    6e0b:      	movl	$0xffffffa4, %ecx       # imm = 0xFFFFFFA4
    6e10:      	testq	%rax, %rax
    6e13:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    6e19:      	movq	0x10e8(%r14), %rax
    6e20:      	movl	$0xffffffa6, %ecx       # imm = 0xFFFFFFA6
    6e25:      	testq	%rax, %rax
    6e28:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    6e2e:      	movq	0x10e0(%r14), %rax
    6e35:      	movl	$0xffffffa8, %ecx       # imm = 0xFFFFFFA8
    6e3a:      	testq	%rax, %rax
    6e3d:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    6e43:      	movq	0x10d8(%r14), %rax
    6e4a:      	movl	$0xffffffaa, %ecx       # imm = 0xFFFFFFAA
    6e4f:      	testq	%rax, %rax
    6e52:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    6e58:      	movq	0x10d0(%r14), %rax
    6e5f:      	movl	$0xffffffac, %ecx       # imm = 0xFFFFFFAC
    6e64:      	testq	%rax, %rax
    6e67:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    6e6d:      	movq	0x10c8(%r14), %rax
    6e74:      	movl	$0xffffffae, %ecx       # imm = 0xFFFFFFAE
    6e79:      	testq	%rax, %rax
    6e7c:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    6e82:      	movq	0x10c0(%r14), %rax
    6e89:      	movl	$0xffffffb0, %ecx       # imm = 0xFFFFFFB0
    6e8e:      	testq	%rax, %rax
    6e91:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    6e97:      	movq	0x10b8(%r14), %rax
    6e9e:      	movl	$0xffffffb2, %ecx       # imm = 0xFFFFFFB2
    6ea3:      	testq	%rax, %rax
    6ea6:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    6eac:      	movq	0x10b0(%r14), %rax
    6eb3:      	movl	$0xffffffb4, %ecx       # imm = 0xFFFFFFB4
    6eb8:      	testq	%rax, %rax
    6ebb:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    6ec1:      	movq	0x10a8(%r14), %rax
    6ec8:      	movl	$0xffffffb6, %ecx       # imm = 0xFFFFFFB6
    6ecd:      	testq	%rax, %rax
    6ed0:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    6ed6:      	movq	0x10a0(%r14), %rax
    6edd:      	movl	$0xffffffb8, %ecx       # imm = 0xFFFFFFB8
    6ee2:      	testq	%rax, %rax
    6ee5:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    6eeb:      	movq	0x1098(%r14), %rax
    6ef2:      	movl	$0xffffffba, %ecx       # imm = 0xFFFFFFBA
    6ef7:      	testq	%rax, %rax
    6efa:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    6f00:      	movq	0x1090(%r14), %rax
    6f07:      	movl	$0xffffffbc, %ecx       # imm = 0xFFFFFFBC
    6f0c:      	testq	%rax, %rax
    6f0f:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    6f15:      	movq	0x1088(%r14), %rax
    6f1c:      	movl	$0xffffffbe, %ecx       # imm = 0xFFFFFFBE
    6f21:      	testq	%rax, %rax
    6f24:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    6f2a:      	movq	0x1080(%r14), %rax
    6f31:      	movl	$0xffffffc0, %ecx       # imm = 0xFFFFFFC0
    6f36:      	testq	%rax, %rax
    6f39:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    6f3f:      	movq	0x1078(%r14), %rax
    6f46:      	movl	$0xffffffc2, %ecx       # imm = 0xFFFFFFC2
    6f4b:      	testq	%rax, %rax
    6f4e:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    6f54:      	movq	0x1070(%r14), %rax
    6f5b:      	movl	$0xffffffc4, %ecx       # imm = 0xFFFFFFC4
    6f60:      	testq	%rax, %rax
    6f63:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    6f69:      	movq	0x1068(%r14), %rax
    6f70:      	movl	$0xffffffc6, %ecx       # imm = 0xFFFFFFC6
    6f75:      	testq	%rax, %rax
    6f78:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    6f7e:      	movq	0x1060(%r14), %rax
    6f85:      	movl	$0xffffffc8, %ecx       # imm = 0xFFFFFFC8
    6f8a:      	testq	%rax, %rax
    6f8d:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    6f93:      	movq	0x1058(%r14), %rax
    6f9a:      	movl	$0xffffffca, %ecx       # imm = 0xFFFFFFCA
    6f9f:      	testq	%rax, %rax
    6fa2:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    6fa8:      	movq	0x1050(%r14), %rax
    6faf:      	movl	$0xffffffcc, %ecx       # imm = 0xFFFFFFCC
    6fb4:      	testq	%rax, %rax
    6fb7:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    6fbd:      	movq	0x1048(%r14), %rax
    6fc4:      	movl	$0xffffffce, %ecx       # imm = 0xFFFFFFCE
    6fc9:      	testq	%rax, %rax
    6fcc:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    6fd2:      	movq	0x1040(%r14), %rax
    6fd9:      	movl	$0xffffffd0, %ecx       # imm = 0xFFFFFFD0
    6fde:      	testq	%rax, %rax
    6fe1:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    6fe7:      	movq	0x1038(%r14), %rax
    6fee:      	movl	$0xffffffd2, %ecx       # imm = 0xFFFFFFD2
    6ff3:      	testq	%rax, %rax
    6ff6:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    6ffc:      	movq	0x1030(%r14), %rax
    7003:      	movl	$0xffffffd4, %ecx       # imm = 0xFFFFFFD4
    7008:      	testq	%rax, %rax
    700b:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    7011:      	movq	0x1028(%r14), %rax
    7018:      	movl	$0xffffffd6, %ecx       # imm = 0xFFFFFFD6
    701d:      	testq	%rax, %rax
    7020:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    7026:      	movq	0x1020(%r14), %rax
    702d:      	movl	$0xffffffd8, %ecx       # imm = 0xFFFFFFD8
    7032:      	testq	%rax, %rax
    7035:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    703b:      	movq	0x1018(%r14), %rax
    7042:      	movl	$0xffffffda, %ecx       # imm = 0xFFFFFFDA
    7047:      	testq	%rax, %rax
    704a:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    7050:      	movq	0x1010(%r14), %rax
    7057:      	movl	$0xffffffdc, %ecx       # imm = 0xFFFFFFDC
    705c:      	testq	%rax, %rax
    705f:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    7065:      	movq	0x1008(%r14), %rax
    706c:      	movl	$0xffffffde, %ecx       # imm = 0xFFFFFFDE
    7071:      	testq	%rax, %rax
    7074:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    707a:      	movq	0x1000(%r14), %rax
    7081:      	movl	$0xffffffe0, %ecx       # imm = 0xFFFFFFE0
    7086:      	testq	%rax, %rax
    7089:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    708f:      	movq	0xff8(%r14), %rax
    7096:      	movl	$0xffffffe2, %ecx       # imm = 0xFFFFFFE2
    709b:      	testq	%rax, %rax
    709e:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    70a4:      	movq	0xff0(%r14), %rax
    70ab:      	movl	$0xffffffe4, %ecx       # imm = 0xFFFFFFE4
    70b0:      	testq	%rax, %rax
    70b3:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    70b9:      	movq	0xfe8(%r14), %rax
    70c0:      	movl	$0xffffffe6, %ecx       # imm = 0xFFFFFFE6
    70c5:      	testq	%rax, %rax
    70c8:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    70ce:      	movq	0xfe0(%r14), %rax
    70d5:      	movl	$0xffffffe8, %ecx       # imm = 0xFFFFFFE8
    70da:      	testq	%rax, %rax
    70dd:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    70e3:      	movq	0xfd8(%r14), %rax
    70ea:      	movl	$0xffffffea, %ecx       # imm = 0xFFFFFFEA
    70ef:      	testq	%rax, %rax
    70f2:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    70f8:      	movq	0xfd0(%r14), %rax
    70ff:      	movl	$0xffffffec, %ecx       # imm = 0xFFFFFFEC
    7104:      	testq	%rax, %rax
    7107:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    710d:      	movq	0xfc8(%r14), %rax
    7114:      	movl	$0xffffffee, %ecx       # imm = 0xFFFFFFEE
    7119:      	testq	%rax, %rax
    711c:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    7122:      	movq	0xfc0(%r14), %rax
    7129:      	movl	$0xfffffff0, %ecx       # imm = 0xFFFFFFF0
    712e:      	testq	%rax, %rax
    7131:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    7137:      	movq	0xfb8(%r14), %rax
    713e:      	movl	$0xfffffff2, %ecx       # imm = 0xFFFFFFF2
    7143:      	testq	%rax, %rax
    7146:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    714c:      	movq	0xfb0(%r14), %rax
    7153:      	movl	$0xfffffff4, %ecx       # imm = 0xFFFFFFF4
    7158:      	testq	%rax, %rax
    715b:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    7161:      	movq	0xfa8(%r14), %rax
    7168:      	movl	$0xfffffff6, %ecx       # imm = 0xFFFFFFF6
    716d:      	testq	%rax, %rax
    7170:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    7176:      	movq	0xfa0(%r14), %rax
    717d:      	movl	$0xfffffff8, %ecx       # imm = 0xFFFFFFF8
    7182:      	testq	%rax, %rax
    7185:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    718b:      	movq	0xf98(%r14), %rax
    7192:      	movl	$0xfffffffa, %ecx       # imm = 0xFFFFFFFA
    7197:      	testq	%rax, %rax
    719a:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    71a0:      	movq	0xf90(%r14), %rax
    71a7:      	movl	$0xfffffffc, %ecx       # imm = 0xFFFFFFFC
    71ac:      	testq	%rax, %rax
    71af:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    71b5:      	movq	0xf88(%r14), %rax
    71bc:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    71c1:      	testq	%rax, %rax
    71c4:      	jne	0x579a <kprobe_unwind_dotnet+0x579a>
    71ca:      	movq	0x90(%rsp), %rax
    71d2:      	movq	(%rax), %rax
    71d5:      	xorl	%ecx, %ecx
    71d7:      	jmp	0x579a <kprobe_unwind_dotnet+0x579a>
    71dc:      	movabsq	$0x207972746e65202c, %rax # imm = 0x207972746E65202C
    71e6:      	movq	%rax, 0x40(%rsp)
    71eb:      	movabsq	$0x6425206465707069, %rax # imm = 0x6425206465707069
    71f5:      	movq	%rax, 0x38(%rsp)
    71fa:      	movabsq	$0x6b73203a786c2520, %rax # imm = 0x6B73203A786C2520
    7204:      	movq	%rax, 0x30(%rsp)
    7209:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    7213:      	movq	%rax, 0x28(%rsp)
    7218:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    7222:      	movq	%rax, 0x20(%rsp)
    7227:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    7231:      	movq	%rax, 0x18(%rsp)
    7236:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    7240:      	movq	%rax, 0x10(%rsp)
    7245:      	movl	$0xa7825, 0x48(%rsp)    # imm = 0xA7825
    724d:      	leaq	0x10(%rsp), %rdi
    7252:      	movl	$0x3c, %eax
    7257:      	movl	$0x6, %r9d
    725d:      	movl	$0x3c, %esi
    7262:      	movq	%r13, %rdx
    7265:      	movl	%r15d, %r8d
    7268:      	xorl	%eax, %eax
    726a:      	callq	*%r9
    726d:      	testl	%r15d, %r15d
    7270:      	jne	0x5bfc <kprobe_unwind_dotnet+0x5bfc>
    7276:      	jmp	0x6d11 <kprobe_unwind_dotnet+0x6d11>
    727b:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    7285:      	movq	%rax, 0x26(%rsp)
    728a:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    7294:      	movq	%rax, 0x20(%rsp)
    7299:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    72a3:      	movq	%rax, 0x18(%rsp)
    72a8:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    72b2:      	movq	%rax, 0x10(%rsp)
    72b7:      	leaq	0x10(%rsp), %rdi
    72bc:      	movl	$0x1e, %eax
    72c1:      	movl	$0x6, %ecx
    72c6:      	movzwl	0x20(%r15), %edx
    72cb:      	movl	$0x1e, %esi
    72d0:      	xorl	%eax, %eax
    72d2:      	callq	*%rcx
    72d4:      	movl	0x1380(%r14), %eax
    72db:      	movl	0x20(%r15), %ecx
    72df:      	btl	%ecx, %eax
    72e2:      	jb	0x62c5 <kprobe_unwind_dotnet+0x62c5>
    72e8:      	movl	$0x0, 0x68(%rsp)
    72f0:      	movq	(%rip), %rdi            # 0x72f7 <kprobe_unwind_dotnet+0x72f7>
    72f7:      	leaq	0x68(%rsp), %rsi
    72fc:      	movl	$0x1, %eax
    7301:      	callq	*%rax
    7303:      	testq	%rax, %rax
    7306:      	je	0x730d <kprobe_unwind_dotnet+0x730d>
    7308:      	incq	(%rax)
    730b:      	jmp	0x731d <kprobe_unwind_dotnet+0x731d>
    730d:      	movq	(%rip), %rax            # 0x7314 <kprobe_unwind_dotnet+0x7314>
    7314:      	cmpl	$0x0, (%rax)
    7317:      	jne	0x7b5b <kprobe_unwind_dotnet+0x7b5b>
    731d:      	movzwl	0x20(%r15), %r12d
    7322:      	cmpl	$0x8, %r12d
    7326:      	jne	0x8da3 <kprobe_unwind_dotnet+0x8da3>
    732c:      	movq	0xed0(%r14), %r12
    7333:      	movq	0xed8(%r14), %rbx
    733a:      	movq	0xee0(%r14), %r13
    7341:      	movzbl	0xf30(%r14), %eax
    7349:      	movb	%al, 0x88(%rsp)
    7350:      	movq	(%rip), %rax            # 0x7357 <kprobe_unwind_dotnet+0x7357>
    7357:      	cmpl	$0x0, (%rax)
    735a:      	jne	0x774b <kprobe_unwind_dotnet+0x774b>
    7360:      	cmpq	%rbx, %r13
    7363:      	jb	0x77bb <kprobe_unwind_dotnet+0x77bb>
    7369:      	leaq	0x2000(%rbx), %rax
    7370:      	cmpq	%rax, %r13
    7373:      	jae	0x77bb <kprobe_unwind_dotnet+0x77bb>
    7379:      	movq	0xf10(%r14), %rbp
    7380:      	movq	0xf20(%r14), %r15
    7387:      	movq	%r12, 0x68(%rsp)
    738c:      	movb	$0x1, 0xf30(%r14)
    7394:      	movq	%rbp, %rax
    7397:      	andq	$-0x80, %rax
    739b:      	cmpq	$0x80, %rax
    73a1:      	jne	0x73e5 <kprobe_unwind_dotnet+0x73e5>
    73a3:      	movq	0xed8(%r14), %rax
    73aa:      	movl	$0x8, %ecx
    73af:      	movl	$0x70, %r8d
    73b5:      	movq	0x98(%rsp), %rdi
    73bd:      	movq	0xed8(%r14), %rdx
    73c4:      	movl	$0x8, %esi
    73c9:      	callq	*%r8
    73cc:      	testq	%rax, %rax
    73cf:      	jne	0x19c <kprobe_unwind_dotnet+0x19c>
    73d5:      	addq	$0x8, 0xed8(%r14)
    73dd:      	andl	$0x7f, %ebp
    73e0:      	jmp	0x85e1 <kprobe_unwind_dotnet+0x85e1>
    73e5:      	leaq	0x70(%rsp), %rdi
    73ea:      	movl	$0x10, %eax
    73ef:      	movl	$0x70, %ecx
    73f4:      	movl	$0x10, %esi
    73f9:      	movq	%r13, %rdx
    73fc:      	callq	*%rcx
    73fe:      	testq	%rax, %rax
    7401:      	jne	0x26c <kprobe_unwind_dotnet+0x26c>
    7407:      	addq	$0x10, %r13
    740b:      	movq	%r13, 0xed8(%r14)
    7412:      	movq	0x70(%rsp), %rax
    7417:      	movq	%rax, 0xee0(%r14)
    741e:      	movq	0x78(%rsp), %rax
    7423:      	movq	%rax, 0xed0(%r14)
    742a:      	movq	(%rip), %rax            # 0x7431 <kprobe_unwind_dotnet+0x7431>
    7431:      	cmpl	$0x0, (%rax)
    7434:      	jne	0x7bd6 <kprobe_unwind_dotnet+0x7bd6>
    743a:      	cmpq	$0x100, %rbp            # imm = 0x100
    7441:      	jb	0x85e1 <kprobe_unwind_dotnet+0x85e1>
    7447:      	movq	0xf10(%r14), %rbp
    744e:      	movq	0xf20(%r14), %rbx
    7455:      	movq	%r12, %r13
    7458:      	subq	%rbx, %r13
    745b:      	movq	(%rip), %rax            # 0x7462 <kprobe_unwind_dotnet+0x7462>
    7462:      	cmpl	$0x0, (%rax)
    7465:      	jne	0x7c5b <kprobe_unwind_dotnet+0x7c5b>
    746b:      	movq	%r13, %r15
    746e:      	andq	$-0x4, %r15
    7472:      	movl	$0x100, %ecx            # imm = 0x100
    7477:      	movq	%r15, %rax
    747a:      	xorl	%edx, %edx
    747c:      	divq	%rcx
    747f:      	movq	%rax, %rcx
    7482:      	movl	$0x7f, %eax
    7487:      	subq	%rcx, %rax
    748a:      	jns	0x74a3 <kprobe_unwind_dotnet+0x74a3>
    748c:      	movl	$0x100, %ecx            # imm = 0x100
    7491:      	movq	%r15, %rax
    7494:      	xorl	%edx, %edx
    7496:      	divq	%rcx
    7499:      	leaq	-0x3fc(%rbp,%rax,4), %rbp
    74a1:      	xorl	%eax, %eax
    74a3:      	movl	$0x80, %ecx
    74a8:      	cqto
    74aa:      	idivq	%rcx
    74ad:      	movq	0x90(%rsp), %rax
    74b5:      	leaq	(%rax,%rdx,4), %rdi
    74b9:      	movl	$0x200, %eax            # imm = 0x200
    74be:      	movl	$0x70, %ecx
    74c3:      	movl	$0x200, %esi            # imm = 0x200
    74c8:      	movq	%rbp, %rdx
    74cb:      	callq	*%rcx
    74cd:      	testq	%rax, %rax
    74d0:      	je	0x7507 <kprobe_unwind_dotnet+0x7507>
    74d2:      	movq	(%rip), %rax            # 0x74d9 <kprobe_unwind_dotnet+0x74d9>
    74d9:      	cmpl	$0x0, (%rax)
    74dc:      	jne	0x76dc <kprobe_unwind_dotnet+0x76dc>
    74e2:      	movl	$0x5e, 0xc(%rsp)
    74ea:      	movq	(%rip), %rdi            # 0x74f1 <kprobe_unwind_dotnet+0x74f1>
    74f1:      	leaq	0xc(%rsp), %rsi
    74f6:      	movl	$0x1, %eax
    74fb:      	callq	*%rax
    74fd:      	testq	%rax, %rax
    7500:      	je	0x7572 <kprobe_unwind_dotnet+0x7572>
    7502:      	incq	(%rax)
    7505:      	jmp	0x7582 <kprobe_unwind_dotnet+0x7582>
    7507:      	movl	0x117c(%r14), %ebp
    750e:      	movq	(%rip), %rax            # 0x7515 <kprobe_unwind_dotnet+0x7515>
    7515:      	cmpl	$0x0, (%rax)
    7518:      	jne	0x7c9f <kprobe_unwind_dotnet+0x7c9f>
    751e:      	movl	$0x20, %ecx
    7523:      	movq	%r15, %rax
    7526:      	xorl	%edx, %edx
    7528:      	divq	%rcx
    752b:      	movl	$0x8, %ecx
    7530:      	xorl	%edx, %edx
    7532:      	divq	%rcx
    7535:      	shll	$0x2, %edx
    7538:      	movb	$0x1c, %al
    753a:      	subb	%dl, %al
    753c:      	shrxl	%eax, %ebp, %r15d
    7541:      	testl	%r15d, %r15d
    7544:      	je	0x760f <kprobe_unwind_dotnet+0x760f>
    754a:      	andq	$-0x20, %r13
    754e:      	movl	%r15d, %ecx
    7551:      	andl	$0xf, %ecx
    7554:      	jne	0x8594 <kprobe_unwind_dotnet+0x8594>
    755a:      	movl	%r15d, %ecx
    755d:      	shrl	$0x4, %ecx
    7560:      	andl	$0xf, %ecx
    7563:      	je	0x771f <kprobe_unwind_dotnet+0x771f>
    7569:      	addq	$-0x20, %r13
    756d:      	jmp	0x8594 <kprobe_unwind_dotnet+0x8594>
    7572:      	movq	(%rip), %rax            # 0x7579 <kprobe_unwind_dotnet+0x7579>
    7579:      	cmpl	$0x0, (%rax)
    757c:      	jne	0x7d2c <kprobe_unwind_dotnet+0x7d2c>
    7582:      	movl	$0x1772, %edx           # imm = 0x1772
    7587:      	xorl	%ebx, %ebx
    7589:      	movq	(%rip), %rax            # 0x7590 <kprobe_unwind_dotnet+0x7590>
    7590:      	cmpl	$0x0, (%rax)
    7593:      	jne	0x843f <kprobe_unwind_dotnet+0x843f>
    7599:      	movl	$0x1772, %eax           # imm = 0x1772
    759e:      	testb	%bl, %bl
    75a0:      	movq	0x60(%rsp), %r15
    75a5:      	movq	(%rip), %rbp            # 0x75ac <kprobe_unwind_dotnet+0x75ac>
    75ac:      	je	0x7812 <kprobe_unwind_dotnet+0x7812>
    75b2:      	movl	0x2c0(%r14), %eax
    75b9:      	cmpq	$0x7e, %rax
    75bd:      	ja	0x52f <kprobe_unwind_dotnet+0x52f>
    75c3:      	leal	0x1(%rax), %ecx
    75c6:      	movl	%ecx, 0x2c0(%r14)
    75cd:      	leaq	(%rax,%rax,2), %rax
    75d1:      	movq	$0x0, 0x2d0(%r14,%rax,8)
    75dd:      	movq	$0x1773, 0x2d8(%r14,%rax,8) # imm = 0x1773
    75e9:      	movb	$-0x76, 0x2e0(%r14,%rax,8)
    75f2:      	movl	$0x0, 0x2e1(%r14,%rax,8)
    75fe:      	movl	$0x0, 0x2e4(%r14,%rax,8)
    760a:      	jmp	0x8694 <kprobe_unwind_dotnet+0x8694>
    760f:      	andq	$-0x100, %r13
    7616:      	addq	$-0x20, %r13
    761a:      	movl	0x1178(%r14), %r15d
    7621:      	movq	(%rip), %rax            # 0x7628 <kprobe_unwind_dotnet+0x7628>
    7628:      	cmpl	$0x0, (%rax)
    762b:      	jne	0x7da7 <kprobe_unwind_dotnet+0x7da7>
    7631:      	xorl	%ecx, %ecx
    7633:      	testl	%r15d, %r15d
    7636:      	je	0x7e3b <kprobe_unwind_dotnet+0x7e3b>
    763c:      	movl	%ecx, %eax
    763e:      	shll	$0x8, %eax
    7641:      	subq	%rax, %r13
    7644:      	jae	0x8365 <kprobe_unwind_dotnet+0x8365>
    764a:      	movq	(%rip), %rax            # 0x7651 <kprobe_unwind_dotnet+0x7651>
    7651:      	cmpl	$0x0, (%rax)
    7654:      	je	0x74e2 <kprobe_unwind_dotnet+0x74e2>
    765a:      	movabsq	$0xa657361625f63, %rax  # imm = 0xA657361625F63
    7664:      	movq	%rax, 0x36(%rsp)
    7669:      	movabsq	$0x5f637020776f6c65, %rax # imm = 0x5F637020776F6C65
    7673:      	movq	%rax, 0x30(%rsp)
    7678:      	movabsq	$0x6220746e65772068, %rax # imm = 0x6220746E65772068
    7682:      	movq	%rax, 0x28(%rsp)
    7687:      	movabsq	$0x6372616573207061, %rax # imm = 0x6372616573207061
    7691:      	movq	%rax, 0x20(%rsp)
    7696:      	movabsq	$0x6d20656c6262696e, %rax # imm = 0x6D20656C6262696E
    76a0:      	movq	%rax, 0x18(%rsp)
    76a5:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    76af:      	movq	%rax, 0x10(%rsp)
    76b4:      	leaq	0x10(%rsp), %rdi
    76b9:      	movl	$0x2e, %eax
    76be:      	movl	$0x6, %ecx
    76c3:      	movl	$0x2e, %esi
    76c8:      	xorl	%eax, %eax
    76ca:      	callq	*%rcx
    76cc:      	movq	(%rip), %rax            # 0x76d3 <kprobe_unwind_dotnet+0x76d3>
    76d3:      	cmpl	$0x0, (%rax)
    76d6:      	je	0x74e2 <kprobe_unwind_dotnet+0x74e2>
    76dc:      	movabsq	$0x6e756f6620746f6e, %rax # imm = 0x6E756F6620746F6E
    76e6:      	movq	%rax, 0x18(%rsp)
    76eb:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    76f5:      	movq	%rax, 0x10(%rsp)
    76fa:      	movl	$0xa646e, 0x1f(%rsp)    # imm = 0xA646E
    7702:      	leaq	0x10(%rsp), %rdi
    7707:      	movl	$0x13, %eax
    770c:      	movl	$0x6, %ecx
    7711:      	movl	$0x13, %esi
    7716:      	xorl	%eax, %eax
    7718:      	callq	*%rcx
    771a:      	jmp	0x74e2 <kprobe_unwind_dotnet+0x74e2>
    771f:      	movl	%r15d, %ecx
    7722:      	shrl	$0x8, %ecx
    7725:      	andl	$0xf, %ecx
    7728:      	je	0x7733 <kprobe_unwind_dotnet+0x7733>
    772a:      	addq	$-0x40, %r13
    772e:      	jmp	0x8594 <kprobe_unwind_dotnet+0x8594>
    7733:      	movl	%r15d, %ecx
    7736:      	shrl	$0xc, %ecx
    7739:      	andl	$0xf, %ecx
    773c:      	je	0x84a7 <kprobe_unwind_dotnet+0x84a7>
    7742:      	addq	$-0x60, %r13
    7746:      	jmp	0x8594 <kprobe_unwind_dotnet+0x8594>
    774b:      	movabsq	$0x6c25203a7066202c, %rax # imm = 0x6C25203A7066202C
    7755:      	movq	%rax, 0x28(%rsp)
    775a:      	movabsq	$0x786c25203a707320, %rax # imm = 0x786C25203A707320
    7764:      	movq	%rax, 0x20(%rsp)
    7769:      	movabsq	$0x2c786c25203a6370, %rax # imm = 0x2C786C25203A6370
    7773:      	movq	%rax, 0x18(%rsp)
    7778:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    7782:      	movq	%rax, 0x10(%rsp)
    7787:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    778f:      	leaq	0x10(%rsp), %rdi
    7794:      	movl	$0x23, %eax
    7799:      	movl	$0x6, %r9d
    779f:      	movl	$0x23, %esi
    77a4:      	movq	%r12, %rdx
    77a7:      	movq	%rbx, %rcx
    77aa:      	movq	%r13, %r8
    77ad:      	xorl	%eax, %eax
    77af:      	callq	*%r9
    77b2:      	cmpq	%rbx, %r13
    77b5:      	jae	0x7369 <kprobe_unwind_dotnet+0x7369>
    77bb:      	movq	0x60(%rsp), %r15
    77c0:      	movq	(%rip), %rax            # 0x77c7 <kprobe_unwind_dotnet+0x77c7>
    77c7:      	cmpl	$0x0, (%rax)
    77ca:      	jne	0x796b <kprobe_unwind_dotnet+0x796b>
    77d0:      	movl	$0x5d, 0x68(%rsp)
    77d8:      	movq	(%rip), %rdi            # 0x77df <kprobe_unwind_dotnet+0x77df>
    77df:      	leaq	0x68(%rsp), %rsi
    77e4:      	movl	$0x1, %eax
    77e9:      	callq	*%rax
    77eb:      	testq	%rax, %rax
    77ee:      	je	0x77fc <kprobe_unwind_dotnet+0x77fc>
    77f0:      	incq	(%rax)
    77f3:      	movq	(%rip), %rbp            # 0x77fa <kprobe_unwind_dotnet+0x77fa>
    77fa:      	jmp	0x780d <kprobe_unwind_dotnet+0x780d>
    77fc:      	movq	(%rip), %rbp            # 0x7803 <kprobe_unwind_dotnet+0x7803>
    7803:      	cmpl	$0x0, (%rbp)
    7807:      	jne	0x79ea <kprobe_unwind_dotnet+0x79ea>
    780d:      	movl	$0x1771, %eax           # imm = 0x1771
    7812:      	xorl	%r12d, %r12d
    7815:      	movl	%eax, 0xf2c(%r14)
    781c:      	movl	$0x0, 0x10(%rsp)
    7824:      	movq	(%rip), %rdi            # 0x782b <kprobe_unwind_dotnet+0x782b>
    782b:      	leaq	0x10(%rsp), %rsi
    7830:      	movl	$0x1, %eax
    7835:      	callq	*%rax
    7837:      	testq	%rax, %rax
    783a:      	je	0x787d <kprobe_unwind_dotnet+0x787d>
    783c:      	movzbl	0x1384(%rax), %ecx
    7843:      	movl	%r12d, %edx
    7846:      	cmpb	$0x1d, %cl
    7849:      	jb	0x78a3 <kprobe_unwind_dotnet+0x78a3>
    784b:      	movq	%rax, %rbx
    784e:      	movl	$0x5, 0xf2c(%rax)
    7858:      	movl	$0x44, 0x70(%rsp)
    7860:      	movq	(%rip), %rdi            # 0x7867 <kprobe_unwind_dotnet+0x7867>
    7867:      	leaq	0x70(%rsp), %rsi
    786c:      	movl	$0x1, %eax
    7871:      	callq	*%rax
    7873:      	testq	%rax, %rax
    7876:      	je	0x788d <kprobe_unwind_dotnet+0x788d>
    7878:      	incq	(%rax)
    787b:      	jmp	0x7897 <kprobe_unwind_dotnet+0x7897>
    787d:      	movq	(%rip), %rcx            # 0x7884 <kprobe_unwind_dotnet+0x7884>
    7884:      	xorl	%edx, %edx
    7886:      	movl	$0xc, %eax
    788b:      	jmp	0x78b9 <kprobe_unwind_dotnet+0x78b9>
    788d:      	cmpl	$0x0, (%rbp)
    7891:      	jne	0x7a65 <kprobe_unwind_dotnet+0x7a65>
    7897:      	movq	%rbx, %rax
    789a:      	movzbl	0x1384(%rbx), %ecx
    78a1:      	xorl	%edx, %edx
    78a3:      	incb	%cl
    78a5:      	movb	%cl, 0x1384(%rax)
    78ab:      	movl	%edx, %ecx
    78ad:      	movq	(%rip), %rsi            # 0x78b4 <kprobe_unwind_dotnet+0x78b4>
    78b4:      	movl	$0xc, %eax
    78b9:      	movq	(%rip), %rsi            # 0x78c0 <kprobe_unwind_dotnet+0x78c0>
    78c0:      	movq	%r15, %rdi
    78c3:      	callq	*%rax
    78c5:      	cmpl	$0x0, (%rbp)
    78c9:      	jne	0x78e2 <kprobe_unwind_dotnet+0x78e2>
    78cb:      	movl	$0xffffffff, %eax       # imm = 0xFFFFFFFF
    78d0:      	addq	$0xa8, %rsp
    78d7:      	popq	%rbx
    78d8:      	popq	%r12
    78da:      	popq	%r13
    78dc:      	popq	%r14
    78de:      	popq	%r15
    78e0:      	popq	%rbp
    78e1:      	retq
    78e2:      	movabsq	$0xa64656c696166, %rax  # imm = 0xA64656C696166
    78ec:      	movq	%rax, 0x3f(%rsp)
    78f1:      	movabsq	$0x6620296425282072, %rax # imm = 0x6620296425282072
    78fb:      	movq	%rax, 0x38(%rsp)
    7900:      	movabsq	$0x65646e69776e7520, %rax # imm = 0x65646E69776E7520
    790a:      	movq	%rax, 0x30(%rsp)
    790f:      	movabsq	$0x656d617266207478, %rax # imm = 0x656D617266207478
    7919:      	movq	%rax, 0x28(%rsp)
    791e:      	movabsq	$0x656e20726f66206c, %rax # imm = 0x656E20726F66206C
    7928:      	movq	%rax, 0x20(%rsp)
    792d:      	movabsq	$0x6c6163206c696174, %rax # imm = 0x6C6163206C696174
    7937:      	movq	%rax, 0x18(%rsp)
    793c:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    7946:      	movq	%rax, 0x10(%rsp)
    794b:      	leaq	0x10(%rsp), %rdi
    7950:      	movl	$0x37, %eax
    7955:      	movl	$0x6, %ecx
    795a:      	movl	$0x37, %esi
    795f:      	movl	%r12d, %edx
    7962:      	xorl	%eax, %eax
    7964:      	callq	*%rcx
    7966:      	jmp	0x78cb <kprobe_unwind_dotnet+0x78cb>
    796b:      	movabsq	$0xa786c25202f20, %rax  # imm = 0xA786C25202F20
    7975:      	movq	%rax, 0x35(%rsp)
    797a:      	movabsq	$0x202f20786c252066, %rax # imm = 0x202F20786C252066
    7984:      	movq	%rax, 0x30(%rsp)
    7989:      	movabsq	$0x666f20726166206f, %rax # imm = 0x666F20726166206F
    7993:      	movq	%rax, 0x28(%rsp)
    7998:      	movabsq	$0x6f74207265746e69, %rax # imm = 0x6F74207265746E69
    79a2:      	movq	%rax, 0x20(%rsp)
    79a7:      	movabsq	$0x6f7020656d617266, %rax # imm = 0x6F7020656D617266
    79b1:      	movq	%rax, 0x18(%rsp)
    79b6:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    79c0:      	movq	%rax, 0x10(%rsp)
    79c5:      	leaq	0x10(%rsp), %rdi
    79ca:      	movl	$0x2d, %eax
    79cf:      	movl	$0x6, %r8d
    79d5:      	movl	$0x2d, %esi
    79da:      	movq	%r13, %rdx
    79dd:      	movq	%rbx, %rcx
    79e0:      	xorl	%eax, %eax
    79e2:      	callq	*%r8
    79e5:      	jmp	0x77d0 <kprobe_unwind_dotnet+0x77d0>
    79ea:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    79f4:      	movq	%rax, 0x36(%rsp)
    79f9:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7a03:      	movq	%rax, 0x30(%rsp)
    7a08:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7a12:      	movq	%rax, 0x28(%rsp)
    7a17:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7a21:      	movq	%rax, 0x20(%rsp)
    7a26:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    7a30:      	movq	%rax, 0x18(%rsp)
    7a35:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7a3f:      	movq	%rax, 0x10(%rsp)
    7a44:      	leaq	0x10(%rsp), %rdi
    7a49:      	movl	$0x2e, %eax
    7a4e:      	movl	$0x6, %ecx
    7a53:      	movl	0x68(%rsp), %edx
    7a57:      	movl	$0x2e, %esi
    7a5c:      	xorl	%eax, %eax
    7a5e:      	callq	*%rcx
    7a60:      	jmp	0x780d <kprobe_unwind_dotnet+0x780d>
    7a65:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    7a6f:      	movq	%rax, 0x36(%rsp)
    7a74:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7a7e:      	movq	%rax, 0x30(%rsp)
    7a83:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7a8d:      	movq	%rax, 0x28(%rsp)
    7a92:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7a9c:      	movq	%rax, 0x20(%rsp)
    7aa1:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    7aab:      	movq	%rax, 0x18(%rsp)
    7ab0:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7aba:      	movq	%rax, 0x10(%rsp)
    7abf:      	leaq	0x10(%rsp), %rdi
    7ac4:      	movl	$0x2e, %eax
    7ac9:      	movl	$0x6, %ecx
    7ace:      	movl	0x70(%rsp), %edx
    7ad2:      	movl	$0x2e, %esi
    7ad7:      	xorl	%eax, %eax
    7ad9:      	callq	*%rcx
    7adb:      	jmp	0x7897 <kprobe_unwind_dotnet+0x7897>
    7ae0:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    7aea:      	movq	%rax, 0x36(%rsp)
    7aef:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7af9:      	movq	%rax, 0x30(%rsp)
    7afe:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7b08:      	movq	%rax, 0x28(%rsp)
    7b0d:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7b17:      	movq	%rax, 0x20(%rsp)
    7b1c:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    7b26:      	movq	%rax, 0x18(%rsp)
    7b2b:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7b35:      	movq	%rax, 0x10(%rsp)
    7b3a:      	leaq	0x10(%rsp), %rdi
    7b3f:      	movl	$0x2e, %eax
    7b44:      	movl	$0x6, %ecx
    7b49:      	movl	0xc(%rsp), %edx
    7b4d:      	movl	$0x2e, %esi
    7b52:      	xorl	%eax, %eax
    7b54:      	callq	*%rcx
    7b56:      	jmp	0x6d46 <kprobe_unwind_dotnet+0x6d46>
    7b5b:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    7b65:      	movq	%rax, 0x36(%rsp)
    7b6a:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7b74:      	movq	%rax, 0x30(%rsp)
    7b79:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7b83:      	movq	%rax, 0x28(%rsp)
    7b88:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7b92:      	movq	%rax, 0x20(%rsp)
    7b97:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    7ba1:      	movq	%rax, 0x18(%rsp)
    7ba6:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7bb0:      	movq	%rax, 0x10(%rsp)
    7bb5:      	leaq	0x10(%rsp), %rdi
    7bba:      	movl	$0x2e, %eax
    7bbf:      	movl	$0x6, %ecx
    7bc4:      	movl	0x68(%rsp), %edx
    7bc8:      	movl	$0x2e, %esi
    7bcd:      	xorl	%eax, %eax
    7bcf:      	callq	*%rcx
    7bd1:      	jmp	0x731d <kprobe_unwind_dotnet+0x731d>
    7bd6:      	movabsq	$0x6c25203a7066202c, %rax # imm = 0x6C25203A7066202C
    7be0:      	movq	%rax, 0x28(%rsp)
    7be5:      	movabsq	$0x786c25203a707320, %rax # imm = 0x786C25203A707320
    7bef:      	movq	%rax, 0x20(%rsp)
    7bf4:      	movabsq	$0x2c786c25203a6370, %rax # imm = 0x2C786C25203A6370
    7bfe:      	movq	%rax, 0x18(%rsp)
    7c03:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    7c0d:      	movq	%rax, 0x10(%rsp)
    7c12:      	movl	$0xa786c, 0x2f(%rsp)    # imm = 0xA786C
    7c1a:      	leaq	0x10(%rsp), %rdi
    7c1f:      	movl	$0x23, %eax
    7c24:      	movl	$0x6, %r9d
    7c2a:      	movq	0xed0(%r14), %rdx
    7c31:      	movq	0xed8(%r14), %rcx
    7c38:      	movq	0xee0(%r14), %r8
    7c3f:      	movl	$0x23, %esi
    7c44:      	xorl	%eax, %eax
    7c46:      	callq	*%r9
    7c49:      	cmpq	$0x100, %rbp            # imm = 0x100
    7c50:      	jae	0x7447 <kprobe_unwind_dotnet+0x7447>
    7c56:      	jmp	0x85e1 <kprobe_unwind_dotnet+0x85e1>
    7c5b:      	leaq	(%rip), %rsi            # 0x7c62 <kprobe_unwind_dotnet+0x7c62>
    7c62:      	leaq	0x10(%rsp), %rax
    7c67:      	movl	$0x8, %ecx
    7c6c:      	movq	%rax, %rdi
    7c6f:      	rep		movsq	(%rsi), %es:(%rdi)
    7c72:      	movw	$0xa, 0x50(%rsp)
    7c79:      	movl	$0x42, %ecx
    7c7e:      	movl	$0x6, %r9d
    7c84:      	movq	%rax, %rdi
    7c87:      	movl	$0x42, %esi
    7c8c:      	movq	%r13, %rdx
    7c8f:      	movq	%rbx, %rcx
    7c92:      	movq	%rbp, %r8
    7c95:      	xorl	%eax, %eax
    7c97:      	callq	*%r9
    7c9a:      	jmp	0x746b <kprobe_unwind_dotnet+0x746b>
    7c9f:      	movabsq	$0xa782520797274, %rax  # imm = 0xA782520797274
    7ca9:      	movq	%rax, 0x3e(%rsp)
    7cae:      	movabsq	$0x72746e6520747372, %rax # imm = 0x72746E6520747372
    7cb8:      	movq	%rax, 0x38(%rsp)
    7cbd:      	movabsq	$0x6966203a786c2520, %rax # imm = 0x6966203A786C2520
    7cc7:      	movq	%rax, 0x30(%rsp)
    7ccc:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    7cd6:      	movq	%rax, 0x28(%rsp)
    7cdb:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    7ce5:      	movq	%rax, 0x20(%rsp)
    7cea:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    7cf4:      	movq	%rax, 0x18(%rsp)
    7cf9:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    7d03:      	movq	%rax, 0x10(%rsp)
    7d08:      	leaq	0x10(%rsp), %rdi
    7d0d:      	movl	$0x36, %eax
    7d12:      	movl	$0x6, %r8d
    7d18:      	movl	$0x36, %esi
    7d1d:      	movq	%r15, %rdx
    7d20:      	movl	%ebp, %ecx
    7d22:      	xorl	%eax, %eax
    7d24:      	callq	*%r8
    7d27:      	jmp	0x751e <kprobe_unwind_dotnet+0x751e>
    7d2c:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    7d36:      	movq	%rax, 0x36(%rsp)
    7d3b:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    7d45:      	movq	%rax, 0x30(%rsp)
    7d4a:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    7d54:      	movq	%rax, 0x28(%rsp)
    7d59:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    7d63:      	movq	%rax, 0x20(%rsp)
    7d68:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    7d72:      	movq	%rax, 0x18(%rsp)
    7d77:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    7d81:      	movq	%rax, 0x10(%rsp)
    7d86:      	leaq	0x10(%rsp), %rdi
    7d8b:      	movl	$0x2e, %eax
    7d90:      	movl	$0x6, %ecx
    7d95:      	movl	0xc(%rsp), %edx
    7d99:      	movl	$0x2e, %esi
    7d9e:      	xorl	%eax, %eax
    7da0:      	callq	*%rcx
    7da2:      	jmp	0x7582 <kprobe_unwind_dotnet+0x7582>
    7da7:      	movabsq	$0xa782520797274, %rax  # imm = 0xA782520797274
    7db1:      	movq	%rax, 0x3f(%rsp)
    7db6:      	movabsq	$0x746e6520646e6f63, %rax # imm = 0x746E6520646E6F63
    7dc0:      	movq	%rax, 0x38(%rsp)
    7dc5:      	movabsq	$0x6573203a786c2520, %rax # imm = 0x6573203A786C2520
    7dcf:      	movq	%rax, 0x30(%rsp)
    7dd4:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    7dde:      	movq	%rax, 0x28(%rsp)
    7de3:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    7ded:      	movq	%rax, 0x20(%rsp)
    7df2:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    7dfc:      	movq	%rax, 0x18(%rsp)
    7e01:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    7e0b:      	movq	%rax, 0x10(%rsp)
    7e10:      	leaq	0x10(%rsp), %rdi
    7e15:      	movl	$0x37, %eax
    7e1a:      	movl	$0x6, %r8d
    7e20:      	movl	$0x37, %esi
    7e25:      	movq	%r13, %rdx
    7e28:      	movl	%r15d, %ecx
    7e2b:      	xorl	%eax, %eax
    7e2d:      	callq	*%r8
    7e30:      	xorl	%ecx, %ecx
    7e32:      	testl	%r15d, %r15d
    7e35:      	jne	0x763c <kprobe_unwind_dotnet+0x763c>
    7e3b:      	movq	0x1170(%r14), %rax
    7e42:      	movl	$0xffffff84, %ecx       # imm = 0xFFFFFF84
    7e47:      	testq	%rax, %rax
    7e4a:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    7e50:      	movq	0x1168(%r14), %rax
    7e57:      	movl	$0xffffff86, %ecx       # imm = 0xFFFFFF86
    7e5c:      	testq	%rax, %rax
    7e5f:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    7e65:      	movq	0x1160(%r14), %rax
    7e6c:      	movl	$0xffffff88, %ecx       # imm = 0xFFFFFF88
    7e71:      	testq	%rax, %rax
    7e74:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    7e7a:      	movq	0x1158(%r14), %rax
    7e81:      	movl	$0xffffff8a, %ecx       # imm = 0xFFFFFF8A
    7e86:      	testq	%rax, %rax
    7e89:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    7e8f:      	movq	0x1150(%r14), %rax
    7e96:      	movl	$0xffffff8c, %ecx       # imm = 0xFFFFFF8C
    7e9b:      	testq	%rax, %rax
    7e9e:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    7ea4:      	movq	0x1148(%r14), %rax
    7eab:      	movl	$0xffffff8e, %ecx       # imm = 0xFFFFFF8E
    7eb0:      	testq	%rax, %rax
    7eb3:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    7eb9:      	movq	0x1140(%r14), %rax
    7ec0:      	movl	$0xffffff90, %ecx       # imm = 0xFFFFFF90
    7ec5:      	testq	%rax, %rax
    7ec8:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    7ece:      	movq	0x1138(%r14), %rax
    7ed5:      	movl	$0xffffff92, %ecx       # imm = 0xFFFFFF92
    7eda:      	testq	%rax, %rax
    7edd:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    7ee3:      	movq	0x1130(%r14), %rax
    7eea:      	movl	$0xffffff94, %ecx       # imm = 0xFFFFFF94
    7eef:      	testq	%rax, %rax
    7ef2:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    7ef8:      	movq	0x1128(%r14), %rax
    7eff:      	movl	$0xffffff96, %ecx       # imm = 0xFFFFFF96
    7f04:      	testq	%rax, %rax
    7f07:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    7f0d:      	movq	0x1120(%r14), %rax
    7f14:      	movl	$0xffffff98, %ecx       # imm = 0xFFFFFF98
    7f19:      	testq	%rax, %rax
    7f1c:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    7f22:      	movq	0x1118(%r14), %rax
    7f29:      	movl	$0xffffff9a, %ecx       # imm = 0xFFFFFF9A
    7f2e:      	testq	%rax, %rax
    7f31:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    7f37:      	movq	0x1110(%r14), %rax
    7f3e:      	movl	$0xffffff9c, %ecx       # imm = 0xFFFFFF9C
    7f43:      	testq	%rax, %rax
    7f46:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    7f4c:      	movq	0x1108(%r14), %rax
    7f53:      	movl	$0xffffff9e, %ecx       # imm = 0xFFFFFF9E
    7f58:      	testq	%rax, %rax
    7f5b:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    7f61:      	movq	0x1100(%r14), %rax
    7f68:      	movl	$0xffffffa0, %ecx       # imm = 0xFFFFFFA0
    7f6d:      	testq	%rax, %rax
    7f70:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    7f76:      	movq	0x10f8(%r14), %rax
    7f7d:      	movl	$0xffffffa2, %ecx       # imm = 0xFFFFFFA2
    7f82:      	testq	%rax, %rax
    7f85:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    7f8b:      	movq	0x10f0(%r14), %rax
    7f92:      	movl	$0xffffffa4, %ecx       # imm = 0xFFFFFFA4
    7f97:      	testq	%rax, %rax
    7f9a:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    7fa0:      	movq	0x10e8(%r14), %rax
    7fa7:      	movl	$0xffffffa6, %ecx       # imm = 0xFFFFFFA6
    7fac:      	testq	%rax, %rax
    7faf:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    7fb5:      	movq	0x10e0(%r14), %rax
    7fbc:      	movl	$0xffffffa8, %ecx       # imm = 0xFFFFFFA8
    7fc1:      	testq	%rax, %rax
    7fc4:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    7fca:      	movq	0x10d8(%r14), %rax
    7fd1:      	movl	$0xffffffaa, %ecx       # imm = 0xFFFFFFAA
    7fd6:      	testq	%rax, %rax
    7fd9:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    7fdf:      	movq	0x10d0(%r14), %rax
    7fe6:      	movl	$0xffffffac, %ecx       # imm = 0xFFFFFFAC
    7feb:      	testq	%rax, %rax
    7fee:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    7ff4:      	movq	0x10c8(%r14), %rax
    7ffb:      	movl	$0xffffffae, %ecx       # imm = 0xFFFFFFAE
    8000:      	testq	%rax, %rax
    8003:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    8009:      	movq	0x10c0(%r14), %rax
    8010:      	movl	$0xffffffb0, %ecx       # imm = 0xFFFFFFB0
    8015:      	testq	%rax, %rax
    8018:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    801e:      	movq	0x10b8(%r14), %rax
    8025:      	movl	$0xffffffb2, %ecx       # imm = 0xFFFFFFB2
    802a:      	testq	%rax, %rax
    802d:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    8033:      	movq	0x10b0(%r14), %rax
    803a:      	movl	$0xffffffb4, %ecx       # imm = 0xFFFFFFB4
    803f:      	testq	%rax, %rax
    8042:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    8048:      	movq	0x10a8(%r14), %rax
    804f:      	movl	$0xffffffb6, %ecx       # imm = 0xFFFFFFB6
    8054:      	testq	%rax, %rax
    8057:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    805d:      	movq	0x10a0(%r14), %rax
    8064:      	movl	$0xffffffb8, %ecx       # imm = 0xFFFFFFB8
    8069:      	testq	%rax, %rax
    806c:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    8072:      	movq	0x1098(%r14), %rax
    8079:      	movl	$0xffffffba, %ecx       # imm = 0xFFFFFFBA
    807e:      	testq	%rax, %rax
    8081:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    8087:      	movq	0x1090(%r14), %rax
    808e:      	movl	$0xffffffbc, %ecx       # imm = 0xFFFFFFBC
    8093:      	testq	%rax, %rax
    8096:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    809c:      	movq	0x1088(%r14), %rax
    80a3:      	movl	$0xffffffbe, %ecx       # imm = 0xFFFFFFBE
    80a8:      	testq	%rax, %rax
    80ab:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    80b1:      	movq	0x1080(%r14), %rax
    80b8:      	movl	$0xffffffc0, %ecx       # imm = 0xFFFFFFC0
    80bd:      	testq	%rax, %rax
    80c0:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    80c6:      	movq	0x1078(%r14), %rax
    80cd:      	movl	$0xffffffc2, %ecx       # imm = 0xFFFFFFC2
    80d2:      	testq	%rax, %rax
    80d5:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    80db:      	movq	0x1070(%r14), %rax
    80e2:      	movl	$0xffffffc4, %ecx       # imm = 0xFFFFFFC4
    80e7:      	testq	%rax, %rax
    80ea:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    80f0:      	movq	0x1068(%r14), %rax
    80f7:      	movl	$0xffffffc6, %ecx       # imm = 0xFFFFFFC6
    80fc:      	testq	%rax, %rax
    80ff:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    8105:      	movq	0x1060(%r14), %rax
    810c:      	movl	$0xffffffc8, %ecx       # imm = 0xFFFFFFC8
    8111:      	testq	%rax, %rax
    8114:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    811a:      	movq	0x1058(%r14), %rax
    8121:      	movl	$0xffffffca, %ecx       # imm = 0xFFFFFFCA
    8126:      	testq	%rax, %rax
    8129:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    812f:      	movq	0x1050(%r14), %rax
    8136:      	movl	$0xffffffcc, %ecx       # imm = 0xFFFFFFCC
    813b:      	testq	%rax, %rax
    813e:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    8144:      	movq	0x1048(%r14), %rax
    814b:      	movl	$0xffffffce, %ecx       # imm = 0xFFFFFFCE
    8150:      	testq	%rax, %rax
    8153:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    8159:      	movq	0x1040(%r14), %rax
    8160:      	movl	$0xffffffd0, %ecx       # imm = 0xFFFFFFD0
    8165:      	testq	%rax, %rax
    8168:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    816e:      	movq	0x1038(%r14), %rax
    8175:      	movl	$0xffffffd2, %ecx       # imm = 0xFFFFFFD2
    817a:      	testq	%rax, %rax
    817d:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    8183:      	movq	0x1030(%r14), %rax
    818a:      	movl	$0xffffffd4, %ecx       # imm = 0xFFFFFFD4
    818f:      	testq	%rax, %rax
    8192:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    8198:      	movq	0x1028(%r14), %rax
    819f:      	movl	$0xffffffd6, %ecx       # imm = 0xFFFFFFD6
    81a4:      	testq	%rax, %rax
    81a7:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    81ad:      	movq	0x1020(%r14), %rax
    81b4:      	movl	$0xffffffd8, %ecx       # imm = 0xFFFFFFD8
    81b9:      	testq	%rax, %rax
    81bc:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    81c2:      	movq	0x1018(%r14), %rax
    81c9:      	movl	$0xffffffda, %ecx       # imm = 0xFFFFFFDA
    81ce:      	testq	%rax, %rax
    81d1:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    81d7:      	movq	0x1010(%r14), %rax
    81de:      	movl	$0xffffffdc, %ecx       # imm = 0xFFFFFFDC
    81e3:      	testq	%rax, %rax
    81e6:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    81ec:      	movq	0x1008(%r14), %rax
    81f3:      	movl	$0xffffffde, %ecx       # imm = 0xFFFFFFDE
    81f8:      	testq	%rax, %rax
    81fb:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    8201:      	movq	0x1000(%r14), %rax
    8208:      	movl	$0xffffffe0, %ecx       # imm = 0xFFFFFFE0
    820d:      	testq	%rax, %rax
    8210:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    8216:      	movq	0xff8(%r14), %rax
    821d:      	movl	$0xffffffe2, %ecx       # imm = 0xFFFFFFE2
    8222:      	testq	%rax, %rax
    8225:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    822b:      	movq	0xff0(%r14), %rax
    8232:      	movl	$0xffffffe4, %ecx       # imm = 0xFFFFFFE4
    8237:      	testq	%rax, %rax
    823a:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    8240:      	movq	0xfe8(%r14), %rax
    8247:      	movl	$0xffffffe6, %ecx       # imm = 0xFFFFFFE6
    824c:      	testq	%rax, %rax
    824f:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    8255:      	movq	0xfe0(%r14), %rax
    825c:      	movl	$0xffffffe8, %ecx       # imm = 0xFFFFFFE8
    8261:      	testq	%rax, %rax
    8264:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    826a:      	movq	0xfd8(%r14), %rax
    8271:      	movl	$0xffffffea, %ecx       # imm = 0xFFFFFFEA
    8276:      	testq	%rax, %rax
    8279:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    827f:      	movq	0xfd0(%r14), %rax
    8286:      	movl	$0xffffffec, %ecx       # imm = 0xFFFFFFEC
    828b:      	testq	%rax, %rax
    828e:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    8294:      	movq	0xfc8(%r14), %rax
    829b:      	movl	$0xffffffee, %ecx       # imm = 0xFFFFFFEE
    82a0:      	testq	%rax, %rax
    82a3:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    82a9:      	movq	0xfc0(%r14), %rax
    82b0:      	movl	$0xfffffff0, %ecx       # imm = 0xFFFFFFF0
    82b5:      	testq	%rax, %rax
    82b8:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    82be:      	movq	0xfb8(%r14), %rax
    82c5:      	movl	$0xfffffff2, %ecx       # imm = 0xFFFFFFF2
    82ca:      	testq	%rax, %rax
    82cd:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    82cf:      	movq	0xfb0(%r14), %rax
    82d6:      	movl	$0xfffffff4, %ecx       # imm = 0xFFFFFFF4
    82db:      	testq	%rax, %rax
    82de:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    82e0:      	movq	0xfa8(%r14), %rax
    82e7:      	movl	$0xfffffff6, %ecx       # imm = 0xFFFFFFF6
    82ec:      	testq	%rax, %rax
    82ef:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    82f1:      	movq	0xfa0(%r14), %rax
    82f8:      	movl	$0xfffffff8, %ecx       # imm = 0xFFFFFFF8
    82fd:      	testq	%rax, %rax
    8300:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    8302:      	movq	0xf98(%r14), %rax
    8309:      	movl	$0xfffffffa, %ecx       # imm = 0xFFFFFFFA
    830e:      	testq	%rax, %rax
    8311:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    8313:      	movq	0xf90(%r14), %rax
    831a:      	movl	$0xfffffffc, %ecx       # imm = 0xFFFFFFFC
    831f:      	testq	%rax, %rax
    8322:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    8324:      	movq	0xf88(%r14), %rax
    832b:      	movl	$0xfffffffe, %ecx       # imm = 0xFFFFFFFE
    8330:      	testq	%rax, %rax
    8333:      	jne	0x8342 <kprobe_unwind_dotnet+0x8342>
    8335:      	movq	0x90(%rsp), %rax
    833d:      	movq	(%rax), %rax
    8340:      	xorl	%ecx, %ecx
    8342:      	xorl	%edx, %edx
    8344:      	movq	%rax, %r15
    8347:      	shrq	$0x20, %r15
    834b:      	setne	%dl
    834e:      	cmovel	%eax, %r15d
    8352:      	subl	%edx, %ecx
    8354:      	addl	$0x7e, %ecx
    8357:      	movl	%ecx, %eax
    8359:      	shll	$0x8, %eax
    835c:      	subq	%rax, %r13
    835f:      	jb	0x764a <kprobe_unwind_dotnet+0x764a>
    8365:      	movq	(%rip), %rax            # 0x836c <kprobe_unwind_dotnet+0x836c>
    836c:      	cmpl	$0x0, (%rax)
    836f:      	jne	0x84bf <kprobe_unwind_dotnet+0x84bf>
    8375:      	testl	%r15d, %r15d
    8378:      	jne	0x754e <kprobe_unwind_dotnet+0x754e>
    837e:      	movl	$0x5f, 0xc(%rsp)
    8386:      	movq	(%rip), %rdi            # 0x838d <kprobe_unwind_dotnet+0x838d>
    838d:      	leaq	0xc(%rsp), %rsi
    8392:      	movl	$0x1, %eax
    8397:      	callq	*%rax
    8399:      	testq	%rax, %rax
    839c:      	je	0x83a6 <kprobe_unwind_dotnet+0x83a6>
    839e:      	incq	(%rax)
    83a1:      	jmp	0x8428 <kprobe_unwind_dotnet+0x8428>
    83a6:      	movq	(%rip), %rax            # 0x83ad <kprobe_unwind_dotnet+0x83ad>
    83ad:      	cmpl	$0x0, (%rax)
    83b0:      	je	0x8428 <kprobe_unwind_dotnet+0x8428>
    83b2:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    83bc:      	movq	%rax, 0x36(%rsp)
    83c1:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    83cb:      	movq	%rax, 0x30(%rsp)
    83d0:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    83da:      	movq	%rax, 0x28(%rsp)
    83df:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    83e9:      	movq	%rax, 0x20(%rsp)
    83ee:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    83f8:      	movq	%rax, 0x18(%rsp)
    83fd:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    8407:      	movq	%rax, 0x10(%rsp)
    840c:      	leaq	0x10(%rsp), %rdi
    8411:      	movl	$0x2e, %eax
    8416:      	movl	$0x6, %ecx
    841b:      	movl	0xc(%rsp), %edx
    841f:      	movl	$0x2e, %esi
    8424:      	xorl	%eax, %eax
    8426:      	callq	*%rcx
    8428:      	movl	$0x1773, %edx           # imm = 0x1773
    842d:      	movb	$0x1, %bl
    842f:      	movq	(%rip), %rax            # 0x8436 <kprobe_unwind_dotnet+0x8436>
    8436:      	cmpl	$0x0, (%rax)
    8439:      	je	0x7599 <kprobe_unwind_dotnet+0x7599>
    843f:      	movabsq	$0xa642520687469, %rax  # imm = 0xA642520687469
    8449:      	movq	%rax, 0x30(%rsp)
    844e:      	movabsq	$0x772064656c696166, %rax # imm = 0x772064656C696166
    8458:      	movq	%rax, 0x28(%rsp)
    845d:      	movabsq	$0x2074726174735f65, %rax # imm = 0x2074726174735F65
    8467:      	movq	%rax, 0x20(%rsp)
    846c:      	movabsq	$0x646f63203e2d2d20, %rax # imm = 0x646F63203E2D2D20
    8476:      	movq	%rax, 0x18(%rsp)
    847b:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    8485:      	movq	%rax, 0x10(%rsp)
    848a:      	leaq	0x10(%rsp), %rdi
    848f:      	movl	$0x28, %eax
    8494:      	movl	$0x6, %ecx
    8499:      	movl	$0x28, %esi
    849e:      	xorl	%eax, %eax
    84a0:      	callq	*%rcx
    84a2:      	jmp	0x7599 <kprobe_unwind_dotnet+0x7599>
    84a7:      	movl	%r15d, %ecx
    84aa:      	shrl	$0x10, %ecx
    84ad:      	andl	$0xf, %ecx
    84b0:      	je	0x855e <kprobe_unwind_dotnet+0x855e>
    84b6:      	addq	$-0x80, %r13
    84ba:      	jmp	0x8594 <kprobe_unwind_dotnet+0x8594>
    84bf:      	movabsq	$0x207972746e65202c, %rax # imm = 0x207972746E65202C
    84c9:      	movq	%rax, 0x40(%rsp)
    84ce:      	movabsq	$0x6425206465707069, %rax # imm = 0x6425206465707069
    84d8:      	movq	%rax, 0x38(%rsp)
    84dd:      	movabsq	$0x6b73203a786c2520, %rax # imm = 0x6B73203A786C2520
    84e7:      	movq	%rax, 0x30(%rsp)
    84ec:      	movabsq	$0x726f662074726174, %rax # imm = 0x726F662074726174
    84f6:      	movq	%rax, 0x28(%rsp)
    84fb:      	movabsq	$0x732065646f632064, %rax # imm = 0x732065646F632064
    8505:      	movq	%rax, 0x20(%rsp)
    850a:      	movabsq	$0x6e6966203e2d2d20, %rax # imm = 0x6E6966203E2D2D20
    8514:      	movq	%rax, 0x18(%rsp)
    8519:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    8523:      	movq	%rax, 0x10(%rsp)
    8528:      	movl	$0xa7825, 0x48(%rsp)    # imm = 0xA7825
    8530:      	leaq	0x10(%rsp), %rdi
    8535:      	movl	$0x3c, %eax
    853a:      	movl	$0x6, %r9d
    8540:      	movl	$0x3c, %esi
    8545:      	movq	%r13, %rdx
    8548:      	movl	%r15d, %r8d
    854b:      	xorl	%eax, %eax
    854d:      	callq	*%r9
    8550:      	testl	%r15d, %r15d
    8553:      	jne	0x754e <kprobe_unwind_dotnet+0x754e>
    8559:      	jmp	0x837e <kprobe_unwind_dotnet+0x837e>
    855e:      	movl	%r15d, %ecx
    8561:      	shrl	$0x14, %ecx
    8564:      	andl	$0xf, %ecx
    8567:      	je	0x8572 <kprobe_unwind_dotnet+0x8572>
    8569:      	addq	$-0xa0, %r13
    8570:      	jmp	0x8594 <kprobe_unwind_dotnet+0x8594>
    8572:      	movl	%r15d, %ecx
    8575:      	shrl	$0x18, %ecx
    8578:      	andl	$0xf, %ecx
    857b:      	je	0x8586 <kprobe_unwind_dotnet+0x8586>
    857d:      	addq	$-0xc0, %r13
    8584:      	jmp	0x8594 <kprobe_unwind_dotnet+0x8594>
    8586:      	shrl	$0x1c, %r15d
    858a:      	addq	$-0xe0, %r13
    8591:      	movl	%r15d, %ecx
    8594:      	addq	%r13, %rbx
    8597:      	leal	-0x4(,%rcx,4), %r15d
    859f:      	addq	%rbx, %r15
    85a2:      	movq	(%rip), %rax            # 0x85a9 <kprobe_unwind_dotnet+0x85a9>
    85a9:      	cmpl	$0x0, (%rax)
    85ac:      	jne	0x897c <kprobe_unwind_dotnet+0x897c>
    85b2:      	leaq	-0x8(%r15), %rdx
    85b6:      	leaq	0x68(%rsp), %rdi
    85bb:      	movl	$0x8, %eax
    85c0:      	movl	$0x70, %ecx
    85c5:      	movl	$0x8, %esi
    85ca:      	callq	*%rcx
    85cc:      	testq	%rax, %rax
    85cf:      	movq	(%rip), %rbp            # 0x85d6 <kprobe_unwind_dotnet+0x85d6>
    85d6:      	jne	0xbb6 <kprobe_unwind_dotnet+0xbb6>
    85dc:      	movl	$0x1f, %ebp
    85e1:      	movq	(%rip), %rax            # 0x85e8 <kprobe_unwind_dotnet+0x85e8>
    85e8:      	cmpl	$0x0, (%rax)
    85eb:      	jne	0x89fb <kprobe_unwind_dotnet+0x89fb>
    85f1:      	movl	0x2c0(%r14), %eax
    85f8:      	cmpq	$0x7e, %rax
    85fc:      	ja	0xc0c <kprobe_unwind_dotnet+0xc0c>
    8602:      	movq	0x68(%rsp), %rcx
    8607:      	subq	%r15, %r12
    860a:      	shlq	$0x5, %rcx
    860e:      	addq	%rbp, %rcx
    8611:      	leal	0x1(%rax), %edx
    8614:      	movl	%edx, 0x2c0(%r14)
    861b:      	leaq	(%rax,%rax,2), %rax
    861f:      	movq	%rcx, 0x2d0(%r14,%rax,8)
    8627:      	movq	%r12, 0x2d8(%r14,%rax,8)
    862f:      	movb	$0xa, 0x2e0(%r14,%rax,8)
    8638:      	movzbl	0x88(%rsp), %ecx
    8640:      	movb	%cl, 0x2e1(%r14,%rax,8)
    8648:      	movl	$0x0, 0x2e2(%r14,%rax,8)
    8654:      	movw	$0x0, 0x2e6(%r14,%rax,8)
    865f:      	movl	$0x5b, 0xc(%rsp)
    8667:      	movq	(%rip), %rdi            # 0x866e <kprobe_unwind_dotnet+0x866e>
    866e:      	leaq	0xc(%rsp), %rsi
    8673:      	movl	$0x1, %eax
    8678:      	callq	*%rax
    867a:      	testq	%rax, %rax
    867d:      	je	0x8684 <kprobe_unwind_dotnet+0x8684>
    867f:      	incq	(%rax)
    8682:      	jmp	0x8694 <kprobe_unwind_dotnet+0x8694>
    8684:      	movq	(%rip), %rax            # 0x868b <kprobe_unwind_dotnet+0x868b>
    868b:      	cmpl	$0x0, (%rax)
    868e:      	jne	0x8a5a <kprobe_unwind_dotnet+0x8a5a>
    8694:      	movq	0x98(%rsp), %rax
    869c:      	movq	(%rax), %r13
    869f:      	movq	(%rip), %rax            # 0x86a6 <kprobe_unwind_dotnet+0x86a6>
    86a6:      	movl	(%rax), %eax
    86a8:      	testq	%r13, %r13
    86ab:      	je	0x88ec <kprobe_unwind_dotnet+0x88ec>
    86b1:      	testl	%eax, %eax
    86b3:      	jne	0x8ad5 <kprobe_unwind_dotnet+0x8ad5>
    86b9:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    86c3:      	cmpq	%rax, %r13
    86c6:      	ja	0x2516 <kprobe_unwind_dotnet+0x2516>
    86cc:      	cmpq	$0x1000, %r13           # imm = 0x1000
    86d3:      	jb	0x26b1 <kprobe_unwind_dotnet+0x26b1>
    86d9:      	movl	(%r14), %eax
    86dc:      	movl	$0x60, 0x70(%rsp)
    86e4:      	movbel	%eax, 0x74(%rsp)
    86ea:      	movbeq	%r13, 0x78(%rsp)
    86f1:      	movq	(%rip), %rdi            # 0x86f8 <kprobe_unwind_dotnet+0x86f8>
    86f8:      	leaq	0x70(%rsp), %rsi
    86fd:      	movl	$0x1, %eax
    8702:      	callq	*%rax
    8704:      	testq	%rax, %rax
    8707:      	je	0x8837 <kprobe_unwind_dotnet+0x8837>
    870d:      	movq	0x8(%rax), %r12
    8711:      	movabsq	$0xffffffffffffff, %rcx # imm = 0xFFFFFFFFFFFFFF
    871b:      	andq	%r12, %rcx
    871e:      	movq	%rcx, 0xf20(%r14)
    8725:      	movq	(%rax), %rax
    8728:      	movq	%rax, 0xf10(%r14)
    872f:      	shrq	$0x38, %r12
    8733:      	movq	%r13, %rax
    8736:      	subq	%rcx, %rax
    8739:      	movq	%rax, 0xf18(%r14)
    8740:      	movq	(%rip), %rax            # 0x8747 <kprobe_unwind_dotnet+0x8747>
    8747:      	cmpl	$0x0, (%rax)
    874a:      	jne	0x8b72 <kprobe_unwind_dotnet+0x8b72>
    8750:      	cmpl	$0x1, %r12d
    8754:      	jne	0x8da3 <kprobe_unwind_dotnet+0x8da3>
    875a:      	movq	0xf10(%r14), %rax
    8761:      	movq	%rax, 0x70(%rsp)
    8766:      	movq	0xf18(%r14), %rbx
    876d:      	movq	(%rip), %rdi            # 0x8774 <kprobe_unwind_dotnet+0x8774>
    8774:      	leaq	0x70(%rsp), %rsi
    8779:      	movl	$0x1, %eax
    877e:      	callq	*%rax
    8780:      	movl	$0x1, %r12d
    8786:      	testq	%rax, %rax
    8789:      	je	0x8da3 <kprobe_unwind_dotnet+0x8da3>
    878f:      	movq	%rax, %r15
    8792:      	cmpq	%rbx, (%rax)
    8795:      	ja	0x879d <kprobe_unwind_dotnet+0x879d>
    8797:      	cmpq	%rbx, 0x8(%r15)
    879b:      	jae	0x87b1 <kprobe_unwind_dotnet+0x87b1>
    879d:      	cmpq	%rbx, 0x10(%r15)
    87a1:      	ja	0x8da3 <kprobe_unwind_dotnet+0x8da3>
    87a7:      	cmpq	%rbx, 0x18(%r15)
    87ab:      	jb	0x8da3 <kprobe_unwind_dotnet+0x8da3>
    87b1:      	movq	(%rip), %rax            # 0x87b8 <kprobe_unwind_dotnet+0x87b8>
    87b8:      	cmpl	$0x0, (%rax)
    87bb:      	jne	0x8c87 <kprobe_unwind_dotnet+0x8c87>
    87c1:      	movl	0x1380(%r14), %eax
    87c8:      	movl	0x20(%r15), %ecx
    87cc:      	btl	%ecx, %eax
    87cf:      	jae	0x8cf4 <kprobe_unwind_dotnet+0x8cf4>
    87d5:      	movq	(%rip), %rax            # 0x87dc <kprobe_unwind_dotnet+0x87dc>
    87dc:      	cmpl	$0x0, (%rax)
    87df:      	je	0x8da3 <kprobe_unwind_dotnet+0x8da3>
    87e5:      	movabsq	$0x6e6f64207265646e, %rax # imm = 0x6E6F64207265646E
    87ef:      	movq	%rax, 0x20(%rsp)
    87f4:      	movabsq	$0x69776e7520726574, %rax # imm = 0x69776E7520726574
    87fe:      	movq	%rax, 0x18(%rsp)
    8803:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    880d:      	movq	%rax, 0x10(%rsp)
    8812:      	movl	$0xa656e, 0x27(%rsp)    # imm = 0xA656E
    881a:      	leaq	0x10(%rsp), %rdi
    881f:      	movl	$0x1b, %eax
    8824:      	movl	$0x6, %ecx
    8829:      	movl	$0x1b, %esi
    882e:      	xorl	%eax, %eax
    8830:      	callq	*%rcx
    8832:      	jmp	0x8da3 <kprobe_unwind_dotnet+0x8da3>
    8837:      	movq	0x60(%rsp), %r15
    883c:      	movq	(%rip), %rbp            # 0x8843 <kprobe_unwind_dotnet+0x8843>
    8843:      	cmpl	$0x0, (%rbp)
    8847:      	jne	0x885e <kprobe_unwind_dotnet+0x885e>
    8849:      	movl	$0xc, 0xf28(%r14)
    8854:      	movl	$0xfac, %eax            # imm = 0xFAC
    8859:      	jmp	0x7812 <kprobe_unwind_dotnet+0x7812>
    885e:      	movabsq	$0xa786c2578302043, %rax # imm = 0xA786C2578302043
    8868:      	movq	%rax, 0x40(%rsp)
    886d:      	movabsq	$0x5020726f6620676e, %rax # imm = 0x5020726F6620676E
    8877:      	movq	%rax, 0x38(%rsp)
    887c:      	movabsq	$0x697070616d207972, %rax # imm = 0x697070616D207972
    8886:      	movq	%rax, 0x30(%rsp)
    888b:      	movabsq	$0x6f6d656d206c6176, %rax # imm = 0x6F6D656D206C6176
    8895:      	movq	%rax, 0x28(%rsp)
    889a:      	movabsq	$0x7265746e69207075, %rax # imm = 0x7265746E69207075
    88a4:      	movq	%rax, 0x20(%rsp)
    88a9:      	movabsq	$0x206b6f6f6c206f74, %rax # imm = 0x206B6F6F6C206F74
    88b3:      	movq	%rax, 0x18(%rsp)
    88b8:      	movabsq	$0x206572756c696146, %rax # imm = 0x206572756C696146
    88c2:      	movq	%rax, 0x10(%rsp)
    88c7:      	movb	$0x0, 0x48(%rsp)
    88cc:      	leaq	0x10(%rsp), %rdi
    88d1:      	movl	$0x39, %eax
    88d6:      	movl	$0x6, %ecx
    88db:      	movl	$0x39, %esi
    88e0:      	movq	%r13, %rdx
    88e3:      	xorl	%eax, %eax
    88e5:      	callq	*%rcx
    88e7:      	jmp	0x8849 <kprobe_unwind_dotnet+0x8849>
    88ec:      	movq	0x60(%rsp), %r15
    88f1:      	movq	(%rip), %rbp            # 0x88f8 <kprobe_unwind_dotnet+0x88f8>
    88f8:      	testl	%eax, %eax
    88fa:      	je	0x259c <kprobe_unwind_dotnet+0x259c>
    8900:      	movabsq	$0xa2930203d3d2043, %rax # imm = 0xA2930203D3D2043
    890a:      	movq	%rax, 0x38(%rsp)
    890f:      	movabsq	$0x5028206572756c69, %rax # imm = 0x5028206572756C69
    8919:      	movq	%rax, 0x30(%rsp)
    891e:      	movabsq	$0x616620646e69776e, %rax # imm = 0x616620646E69776E
    8928:      	movq	%rax, 0x28(%rsp)
    892d:      	movabsq	$0x75206f7420657564, %rax # imm = 0x75206F7420657564
    8937:      	movq	%rax, 0x20(%rsp)
    893c:      	movabsq	$0x20646e69776e7520, %rax # imm = 0x20646E69776E7520
    8946:      	movq	%rax, 0x18(%rsp)
    894b:      	movabsq	$0x676e6970706f7453, %rax # imm = 0x676E6970706F7453
    8955:      	movq	%rax, 0x10(%rsp)
    895a:      	movb	$0x0, 0x40(%rsp)
    895f:      	leaq	0x10(%rsp), %rdi
    8964:      	movl	$0x31, %eax
    8969:      	movl	$0x6, %ecx
    896e:      	movl	$0x31, %esi
    8973:      	xorl	%eax, %eax
    8975:      	callq	*%rcx
    8977:      	jmp	0x259c <kprobe_unwind_dotnet+0x259c>
    897c:      	movabsq	$0xa786c253d7465, %rax  # imm = 0xA786C253D7465
    8986:      	movq	%rax, 0x36(%rsp)
    898b:      	movabsq	$0x746572202c78253d, %rax # imm = 0x746572202C78253D
    8995:      	movq	%rax, 0x30(%rsp)
    899a:      	movabsq	$0x6c6176202c786c25, %rax # imm = 0x6C6176202C786C25
    89a4:      	movq	%rax, 0x28(%rsp)
    89a9:      	movabsq	$0x203d2061746c6564, %rax # imm = 0x203D2061746C6564
    89b3:      	movq	%rax, 0x20(%rsp)
    89b8:      	movabsq	$0x5f6370203e2d2d20, %rax # imm = 0x5F6370203E2D2D20
    89c2:      	movq	%rax, 0x18(%rsp)
    89c7:      	movabsq	$0x203a74656e746f64, %rax # imm = 0x203A74656E746F64
    89d1:      	movq	%rax, 0x10(%rsp)
    89d6:      	leaq	0x10(%rsp), %rdi
    89db:      	movl	$0x2e, %eax
    89e0:      	movl	$0x6, %r9d
    89e6:      	movl	$0x2e, %esi
    89eb:      	movq	%r13, %rdx
    89ee:      	movq	%r15, %r8
    89f1:      	xorl	%eax, %eax
    89f3:      	callq	*%r9
    89f6:      	jmp	0x85b2 <kprobe_unwind_dotnet+0x85b2>
    89fb:      	leaq	(%rip), %rsi            # 0x8a02 <kprobe_unwind_dotnet+0x8a02>
    8a02:      	leaq	0x10(%rsp), %rax
    8a07:      	movl	$0x8, %ecx
    8a0c:      	movq	%rax, %rdi
    8a0f:      	rep		movsq	(%rsi), %es:(%rdi)
    8a12:      	movb	$0x0, 0x52(%rsp)
    8a17:      	movw	$0xa78, 0x50(%rsp)      # imm = 0xA78
    8a1e:      	movl	$0x43, %ecx
    8a23:      	movl	$0x6, %r9d
    8a29:      	movq	0x68(%rsp), %rcx
    8a2e:      	movq	%r12, %r8
    8a31:      	subq	%r15, %r8
    8a34:      	movq	%rax, %rdi
    8a37:      	movl	$0x43, %esi
    8a3c:      	movq	%r15, %rdx
    8a3f:      	xorl	%eax, %eax
    8a41:      	callq	*%r9
    8a44:      	movl	0x2c0(%r14), %eax
    8a4b:      	cmpq	$0x7e, %rax
    8a4f:      	ja	0xc0c <kprobe_unwind_dotnet+0xc0c>
    8a55:      	jmp	0x8602 <kprobe_unwind_dotnet+0x8602>
    8a5a:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    8a64:      	movq	%rax, 0x36(%rsp)
    8a69:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    8a73:      	movq	%rax, 0x30(%rsp)
    8a78:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    8a82:      	movq	%rax, 0x28(%rsp)
    8a87:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    8a91:      	movq	%rax, 0x20(%rsp)
    8a96:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    8aa0:      	movq	%rax, 0x18(%rsp)
    8aa5:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    8aaf:      	movq	%rax, 0x10(%rsp)
    8ab4:      	leaq	0x10(%rsp), %rdi
    8ab9:      	movl	$0x2e, %eax
    8abe:      	movl	$0x6, %ecx
    8ac3:      	movl	0xc(%rsp), %edx
    8ac7:      	movl	$0x2e, %esi
    8acc:      	xorl	%eax, %eax
    8ace:      	callq	*%rcx
    8ad0:      	jmp	0x8694 <kprobe_unwind_dotnet+0x8694>
    8ad5:      	movabsq	$0xa3d3d3d3d206425, %rax # imm = 0xA3D3D3D3D206425
    8adf:      	movq	%rax, 0x38(%rsp)
    8ae4:      	movabsq	$0x20656d617266203a, %rax # imm = 0x20656D617266203A
    8aee:      	movq	%rax, 0x30(%rsp)
    8af3:      	movabsq	$0x7265646e69776e75, %rax # imm = 0x7265646E69776E75
    8afd:      	movq	%rax, 0x28(%rsp)
    8b02:      	movabsq	$0x20656d6172662074, %rax # imm = 0x20656D6172662074
    8b0c:      	movq	%rax, 0x20(%rsp)
    8b11:      	movabsq	$0x78656e2065766c6f, %rax # imm = 0x78656E2065766C6F
    8b1b:      	movq	%rax, 0x18(%rsp)
    8b20:      	movabsq	$0x736552203d3d3d3d, %rax # imm = 0x736552203D3D3D3D
    8b2a:      	movq	%rax, 0x10(%rsp)
    8b2f:      	movb	$0x0, 0x40(%rsp)
    8b34:      	leaq	0x10(%rsp), %rdi
    8b39:      	movl	$0x31, %eax
    8b3e:      	movl	$0x6, %ecx
    8b43:      	movl	0x2c0(%r14), %edx
    8b4a:      	movl	$0x31, %esi
    8b4f:      	xorl	%eax, %eax
    8b51:      	callq	*%rcx
    8b53:      	movq	0xed0(%r14), %r13
    8b5a:      	movabsq	$0xffffffffffffff, %rax # imm = 0xFFFFFFFFFFFFFF
    8b64:      	cmpq	%rax, %r13
    8b67:      	ja	0x2516 <kprobe_unwind_dotnet+0x2516>
    8b6d:      	jmp	0x86cc <kprobe_unwind_dotnet+0x86cc>
    8b72:      	movabsq	$0x296425207265646e, %rax # imm = 0x296425207265646E
    8b7c:      	movq	%rax, 0x38(%rsp)
    8b81:      	movabsq	$0x69776e752820786c, %rax # imm = 0x69776E752820786C
    8b8b:      	movq	%rax, 0x30(%rsp)
    8b90:      	movabsq	$0x6c2520736920786c, %rax # imm = 0x6C2520736920786C
    8b9a:      	movq	%rax, 0x28(%rsp)
    8b9f:      	movabsq	$0x2520435020726f66, %rax # imm = 0x2520435020726F66
    8ba9:      	movq	%rax, 0x20(%rsp)
    8bae:      	movabsq	$0x206469206e6f6974, %rax # imm = 0x206469206E6F6974
    8bb8:      	movq	%rax, 0x18(%rsp)
    8bbd:      	movabsq	$0x6365732074786554, %rbx # imm = 0x6365732074786554
    8bc7:      	movq	%rbx, 0x10(%rsp)
    8bcc:      	movw	$0xa, 0x40(%rsp)
    8bd3:      	leaq	0x10(%rsp), %rdi
    8bd8:      	movl	$0x32, %eax
    8bdd:      	movl	$0x6, %r9d
    8be3:      	movq	0xf10(%r14), %rcx
    8bea:      	movl	$0x32, %esi
    8bef:      	movq	%r13, %rdx
    8bf2:      	movl	%r12d, %r8d
    8bf5:      	xorl	%eax, %eax
    8bf7:      	callq	*%r9
    8bfa:      	movq	(%rip), %rax            # 0x8c01 <kprobe_unwind_dotnet+0x8c01>
    8c01:      	cmpl	$0x0, (%rax)
    8c04:      	je	0x8750 <kprobe_unwind_dotnet+0x8750>
    8c0a:      	movabsq	$0xa786c6c252073, %rax  # imm = 0xA786C6C252073
    8c14:      	movq	%rax, 0x37(%rsp)
    8c19:      	movabsq	$0x7369207465736666, %rax # imm = 0x7369207465736666
    8c23:      	movq	%rax, 0x30(%rsp)
    8c28:      	movabsq	$0x6f20646e61202c78, %rax # imm = 0x6F20646E61202C78
    8c32:      	movq	%rax, 0x28(%rsp)
    8c37:      	movabsq	$0x6c6c252073692073, %rax # imm = 0x6C6C252073692073
    8c41:      	movq	%rax, 0x20(%rsp)
    8c46:      	movabsq	$0x616962206e6f6974, %rax # imm = 0x616962206E6F6974
    8c50:      	movq	%rax, 0x18(%rsp)
    8c55:      	movq	%rbx, 0x10(%rsp)
    8c5a:      	leaq	0x10(%rsp), %rdi
    8c5f:      	movl	$0x2f, %eax
    8c64:      	movl	$0x6, %r8d
    8c6a:      	movq	0xf18(%r14), %rcx
    8c71:      	movq	0xf20(%r14), %rdx
    8c78:      	movl	$0x2f, %esi
    8c7d:      	xorl	%eax, %eax
    8c7f:      	callq	*%r8
    8c82:      	jmp	0x8750 <kprobe_unwind_dotnet+0x8750>
    8c87:      	movabsq	$0xa642520686374, %rax  # imm = 0xA642520686374
    8c91:      	movq	%rax, 0x26(%rsp)
    8c96:      	movabsq	$0x6374616d20737465, %rax # imm = 0x6374616D20737465
    8ca0:      	movq	%rax, 0x20(%rsp)
    8ca5:      	movabsq	$0x7366666f5f726574, %rax # imm = 0x7366666F5F726574
    8caf:      	movq	%rax, 0x18(%rsp)
    8cb4:      	movabsq	$0x6572707265746e69, %rax # imm = 0x6572707265746E69
    8cbe:      	movq	%rax, 0x10(%rsp)
    8cc3:      	leaq	0x10(%rsp), %rdi
    8cc8:      	movl	$0x1e, %eax
    8ccd:      	movl	$0x6, %ecx
    8cd2:      	movzwl	0x20(%r15), %edx
    8cd7:      	movl	$0x1e, %esi
    8cdc:      	xorl	%eax, %eax
    8cde:      	callq	*%rcx
    8ce0:      	movl	0x1380(%r14), %eax
    8ce7:      	movl	0x20(%r15), %ecx
    8ceb:      	btl	%ecx, %eax
    8cee:      	jb	0x87d5 <kprobe_unwind_dotnet+0x87d5>
    8cf4:      	movl	$0x0, 0x68(%rsp)
    8cfc:      	movq	(%rip), %rdi            # 0x8d03 <kprobe_unwind_dotnet+0x8d03>
    8d03:      	leaq	0x68(%rsp), %rsi
    8d08:      	movl	$0x1, %eax
    8d0d:      	callq	*%rax
    8d0f:      	testq	%rax, %rax
    8d12:      	je	0x8d1c <kprobe_unwind_dotnet+0x8d1c>
    8d14:      	incq	(%rax)
    8d17:      	jmp	0x8d9e <kprobe_unwind_dotnet+0x8d9e>
    8d1c:      	movq	(%rip), %rax            # 0x8d23 <kprobe_unwind_dotnet+0x8d23>
    8d23:      	cmpl	$0x0, (%rax)
    8d26:      	je	0x8d9e <kprobe_unwind_dotnet+0x8d9e>
    8d28:      	movabsq	$0xa642520444963, %rax  # imm = 0xA642520444963
    8d32:      	movq	%rax, 0x36(%rsp)
    8d37:      	movabsq	$0x4963697274656d20, %rax # imm = 0x4963697274656D20
    8d41:      	movq	%rax, 0x30(%rsp)
    8d46:      	movabsq	$0x726f662070616d20, %rax # imm = 0x726F662070616D20
    8d50:      	movq	%rax, 0x28(%rsp)
    8d55:      	movabsq	$0x7363697274656d20, %rax # imm = 0x7363697274656D20
    8d5f:      	movq	%rax, 0x20(%rsp)
    8d64:      	movabsq	$0x70756b6f6f6c206f, %rax # imm = 0x70756B6F6F6C206F
    8d6e:      	movq	%rax, 0x18(%rsp)
    8d73:      	movabsq	$0x742064656c696146, %rax # imm = 0x742064656C696146
    8d7d:      	movq	%rax, 0x10(%rsp)
    8d82:      	leaq	0x10(%rsp), %rdi
    8d87:      	movl	$0x2e, %eax
    8d8c:      	movl	$0x6, %ecx
    8d91:      	movl	0x68(%rsp), %edx
    8d95:      	movl	$0x2e, %esi
    8d9a:      	xorl	%eax, %eax
    8d9c:      	callq	*%rcx
    8d9e:      	movzwl	0x20(%r15), %r12d
    8da3:      	movq	0x60(%rsp), %r15
    8da8:      	movq	(%rip), %rbp            # 0x8daf <kprobe_unwind_dotnet+0x8daf>
    8daf:      	xorl	%eax, %eax
    8db1:      	jmp	0x7815 <kprobe_unwind_dotnet+0x7815>
