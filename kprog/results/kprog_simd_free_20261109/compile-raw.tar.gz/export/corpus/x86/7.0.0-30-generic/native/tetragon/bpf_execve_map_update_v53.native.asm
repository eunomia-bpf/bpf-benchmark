
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tetragon/bpf_execve_map_update_v53.native.o:	file format elf64-x86-64

Disassembly of section socket:

0000000000000000 <execve_map_update>:
       0:      	pushq	%r15
       2:      	pushq	%r14
       4:      	pushq	%r13
       6:      	pushq	%r12
       8:      	pushq	%rbx
       9:      	subq	$0x10, %rsp
       d:      	movl	$0x0, 0x8(%rsp)
      15:      	movq	(%rip), %rdi            # 0x1c <execve_map_update+0x1c>
      1c:      	leaq	0x8(%rsp), %rsi
      21:      	movl	$0x1, %eax
      26:      	callq	*%rax
      28:      	testq	%rax, %rax
      2b:      	je	0x97 <execve_map_update+0x97>
      2d:      	movq	%rax, %r14
      30:      	xorl	%ebx, %ebx
      32:      	movq	(%rip), %r15            # 0x39 <execve_map_update+0x39>
      39:      	leaq	0xc(%rsp), %r12
      3e:      	xorl	%r13d, %r13d
      41:      	jmp	0x5c <execve_map_update+0x5c>
      43:      	nopw	%cs:(%rax,%rax)
      50:      	incq	%r13
      53:      	cmpq	$0x400, %r13            # imm = 0x400
      5a:      	je	0x9c <execve_map_update+0x9c>
      5c:      	movl	0x4(%r14), %eax
      60:      	cmpq	%rax, %r13
      63:      	je	0x9c <execve_map_update+0x9c>
      65:      	movl	0x8(%r14,%r13,4), %eax
      6a:      	movl	%eax, 0xc(%rsp)
      6e:      	movl	$0x1, %eax
      73:      	movq	%r15, %rdi
      76:      	movq	%r12, %rsi
      79:      	callq	*%rax
      7b:      	testq	%rax, %rax
      7e:      	je	0x50 <execve_map_update+0x50>
      80:      	movzbl	(%r14), %ecx
      84:      	movl	$0xfffffffe, %edx       # imm = 0xFFFFFFFE
      89:      	roll	%cl, %edx
      8b:      	movslq	%edx, %rcx
      8e:      	andq	%rcx, 0x370(%rax)
      95:      	jmp	0x50 <execve_map_update+0x50>
      97:      	movl	$0xffffffff, %ebx       # imm = 0xFFFFFFFF
      9c:      	movl	%ebx, %eax
      9e:      	addq	$0x10, %rsp
      a2:      	popq	%rbx
      a3:      	popq	%r12
      a5:      	popq	%r13
      a7:      	popq	%r14
      a9:      	popq	%r15
      ab:      	retq
