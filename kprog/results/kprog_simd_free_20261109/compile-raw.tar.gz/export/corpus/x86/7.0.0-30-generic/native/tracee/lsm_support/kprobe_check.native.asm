
/var/tmp/kprog-tmp/S14/export/corpus/x86/7.0.0-30-generic/native/tracee/lsm_support/kprobe_check.native.o:	file format elf64-x86-64

Disassembly of section kprobe/security_bpf:

0000000000000000 <security_bpf_kprobe>:
       0:      	pushq	%rax
       1:      	movl	$0x0, 0x4(%rsp)
       9:      	movb	$0x1, 0x3(%rsp)
       e:      	movq	(%rip), %rdi            # 0x15 <security_bpf_kprobe+0x15>
      15:      	xorl	%ecx, %ecx
      17:      	leaq	0x4(%rsp), %rsi
      1c:      	leaq	0x3(%rsp), %rdx
      21:      	movl	$0x2, %eax
      26:      	xorl	%ecx, %ecx
      28:      	callq	*%rax
      2a:      	xorl	%eax, %eax
      2c:      	popq	%rcx
      2d:      	retq
